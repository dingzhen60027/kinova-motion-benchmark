NAME LGCS_GCS_Eq5_5_projected
ROWS
 N  OBJ
 E  R0      
 L  R1      
 E  R2      
 E  R3      
 E  R4      
 E  R5      
 E  R6      
 E  R7      
 E  R8      
 E  R9      
 L  R10     
 E  R11     
 E  R12     
 E  R13     
 E  R14     
 E  R15     
 E  R16     
 E  R17     
 E  R18     
 L  R19     
 E  R20     
 E  R21     
 E  R22     
 E  R23     
 E  R24     
 E  R25     
 E  R26     
 E  R27     
 L  R28     
 E  R29     
 E  R30     
 E  R31     
 E  R32     
 E  R33     
 E  R34     
 E  R35     
 E  R36     
 L  R37     
 E  R38     
 E  R39     
 E  R40     
 E  R41     
 E  R42     
 E  R43     
 E  R44     
 E  R45     
 L  R46     
 E  R47     
 E  R48     
 E  R49     
 E  R50     
 E  R51     
 E  R52     
 E  R53     
 E  R54     
 E  R55     
 L  R56     
 L  R57     
 L  R58     
 L  R59     
 L  R60     
 L  R61     
 L  R62     
 L  R63     
 L  R64     
 L  R65     
 L  R66     
 L  R67     
 L  R68     
 L  R69     
 L  R70     
 L  R71     
 L  R72     
 L  R73     
 L  R74     
 L  R75     
 L  R76     
 L  R77     
 L  R78     
 L  R79     
 L  R80     
 L  R81     
 L  R82     
 L  R83     
 L  R84     
 L  R85     
 L  R86     
 L  R87     
 L  R88     
 L  R89     
 L  R90     
 L  R91     
 L  R92     
 L  R93     
 L  R94     
 L  R95     
 L  R96     
 L  R97     
 L  R98     
 L  R99     
 L  R100    
 L  R101    
 L  R102    
 L  R103    
 L  R104    
 L  R105    
 L  R106    
 L  R107    
 L  R108    
 L  R109    
 L  R110    
 L  R111    
 L  R112    
 L  R113    
 L  R114    
 L  R115    
 L  R116    
 L  R117    
 L  R118    
 L  R119    
 L  R120    
 L  R121    
 L  R122    
 L  R123    
 L  R124    
 L  R125    
 L  R126    
 L  R127    
 L  R128    
 L  R129    
 L  R130    
 L  R131    
 L  R132    
 L  R133    
 L  R134    
 L  R135    
 L  R136    
 L  R137    
 L  R138    
 L  R139    
 L  R140    
 L  R141    
 L  R142    
 L  R143    
 L  R144    
 L  R145    
 L  R146    
 L  R147    
 L  R148    
 L  R149    
 L  R150    
 L  R151    
 L  R152    
 L  R153    
 L  R154    
 L  R155    
 L  R156    
 L  R157    
 L  R158    
 L  R159    
 L  R160    
 L  R161    
 L  R162    
 L  R163    
 L  R164    
 L  R165    
 L  R166    
 L  R167    
 L  R168    
 L  R169    
 L  R170    
 L  R171    
 L  R172    
 L  R173    
 L  R174    
 L  R175    
 L  R176    
 L  R177    
 L  R178    
 L  R179    
 L  R180    
 L  R181    
 L  R182    
 L  R183    
 L  R184    
 L  R185    
 L  R186    
 L  R187    
 L  R188    
 L  R189    
 L  R190    
 L  R191    
 L  R192    
 L  R193    
 L  R194    
 L  R195    
 L  R196    
 L  R197    
 L  R198    
 L  R199    
 L  R200    
 L  R201    
 L  R202    
 L  R203    
 L  R204    
 L  R205    
 L  R206    
 L  R207    
 L  R208    
 L  R209    
 L  R210    
 L  R211    
 L  R212    
 L  R213    
 L  R214    
 L  R215    
 L  R216    
 L  R217    
 L  R218    
 L  R219    
 L  R220    
 L  R221    
 L  R222    
 L  R223    
 L  R224    
 L  R225    
 L  R226    
 L  R227    
 L  R228    
 L  R229    
 L  R230    
 L  R231    
 L  R232    
 L  R233    
 L  R234    
 L  R235    
 L  R236    
 L  R237    
 L  R238    
 L  R239    
 L  R240    
 L  R241    
 L  R242    
 L  R243    
 L  R244    
 L  R245    
 L  R246    
 L  R247    
 L  R248    
 L  R249    
 L  R250    
 L  R251    
 L  R252    
 L  R253    
 L  R254    
 L  R255    
 L  R256    
 L  R257    
 L  R258    
 L  R259    
 L  R260    
 L  R261    
 L  R262    
 L  R263    
 L  R264    
 L  R265    
 L  R266    
 L  R267    
 L  R268    
 L  R269    
 L  R270    
 L  R271    
 L  R272    
 L  R273    
 L  R274    
 L  R275    
 L  R276    
 L  R277    
 L  R278    
 L  R279    
 L  R280    
 L  R281    
 L  R282    
 L  R283    
 L  R284    
 L  R285    
 L  R286    
 L  R287    
 L  R288    
 L  R289    
 L  R290    
 L  R291    
 L  R292    
 L  R293    
 L  R294    
 L  R295    
 L  R296    
 L  R297    
 L  R298    
 L  R299    
 L  R300    
 L  R301    
 L  R302    
 L  R303    
 L  R304    
 L  R305    
 L  R306    
 L  R307    
 L  R308    
 L  R309    
 L  R310    
 L  R311    
 L  R312    
 L  R313    
 L  R314    
 L  R315    
 L  R316    
 L  R317    
 L  R318    
 L  R319    
 L  R320    
 L  R321    
 L  R322    
 L  R323    
 L  R324    
 L  R325    
 L  R326    
 L  R327    
 L  R328    
 L  R329    
 L  R330    
 L  R331    
 L  R332    
 L  R333    
 L  R334    
 L  R335    
 L  R336    
 L  R337    
 L  R338    
 L  R339    
 L  R340    
 L  R341    
 L  R342    
 L  R343    
 L  R344    
 L  R345    
 L  R346    
 L  R347    
 L  R348    
 L  R349    
 L  R350    
 L  R351    
 L  R352    
 L  R353    
 L  R354    
 L  R355    
 L  R356    
 L  R357    
 L  R358    
 L  R359    
 L  R360    
 L  R361    
 L  R362    
 L  R363    
 L  R364    
 L  R365    
 L  R366    
 L  R367    
 L  R368    
 L  R369    
 L  R370    
 L  R371    
 L  R372    
 L  R373    
 L  R374    
 L  R375    
 L  R376    
 L  R377    
 L  R378    
 L  R379    
 L  R380    
 L  R381    
 L  R382    
 L  R383    
 L  R384    
 L  R385    
 L  R386    
 L  R387    
 L  R388    
 L  R389    
 L  R390    
 L  R391    
 L  R392    
 L  R393    
 L  R394    
 L  R395    
 L  R396    
 L  R397    
 L  R398    
 L  R399    
 L  R400    
 L  R401    
 L  R402    
 L  R403    
 L  R404    
 L  R405    
 L  R406    
 L  R407    
 L  R408    
 L  R409    
 L  R410    
 L  R411    
 L  R412    
 L  R413    
 L  R414    
 L  R415    
 L  R416    
 L  R417    
 L  R418    
 L  R419    
 L  R420    
 L  R421    
 L  R422    
 L  R423    
 L  R424    
 L  R425    
 L  R426    
 L  R427    
 L  R428    
 L  R429    
 L  R430    
 L  R431    
 L  R432    
 L  R433    
 L  R434    
 L  R435    
 L  R436    
 L  R437    
 L  R438    
 L  R439    
 L  R440    
 L  R441    
 L  R442    
 L  R443    
 L  R444    
 L  R445    
 L  R446    
 L  R447    
 L  R448    
 L  R449    
 L  R450    
 L  R451    
 L  R452    
 L  R453    
 L  R454    
 L  R455    
 L  R456    
 L  R457    
 L  R458    
 L  R459    
 L  R460    
 L  R461    
 L  R462    
 L  R463    
 L  R464    
 L  R465    
 L  R466    
 L  R467    
 L  R468    
 L  R469    
 L  R470    
 L  R471    
 L  R472    
 L  R473    
 L  R474    
 L  R475    
 L  R476    
 L  R477    
 L  R478    
 L  R479    
 L  R480    
 L  R481    
 L  R482    
 L  R483    
 L  R484    
 L  R485    
 L  R486    
 L  R487    
 L  R488    
 L  R489    
 L  R490    
 L  R491    
 L  R492    
 L  R493    
 L  R494    
 L  R495    
 L  R496    
 L  R497    
 L  R498    
 L  R499    
 L  R500    
 L  R501    
 L  R502    
 L  R503    
 L  R504    
 L  R505    
 L  R506    
 L  R507    
 L  R508    
 L  R509    
 L  R510    
 L  R511    
 L  R512    
 L  R513    
 L  R514    
 L  R515    
 L  R516    
 L  R517    
 L  R518    
 L  R519    
 L  R520    
 L  R521    
 L  R522    
 L  R523    
 L  R524    
 L  R525    
 L  R526    
 L  R527    
 L  R528    
 L  R529    
 L  R530    
 L  R531    
 L  R532    
 L  R533    
 L  R534    
 L  R535    
 L  R536    
 L  R537    
 L  R538    
 L  R539    
 L  R540    
 L  R541    
 L  R542    
 L  R543    
 L  R544    
 L  R545    
 L  R546    
 L  R547    
 L  R548    
 L  R549    
 L  R550    
 L  R551    
 L  R552    
 L  R553    
 L  R554    
 L  R555    
 L  R556    
 L  R557    
 L  R558    
 L  R559    
 L  R560    
 L  R561    
 L  R562    
 L  R563    
 L  R564    
 L  R565    
 L  R566    
 L  R567    
 L  R568    
 L  R569    
 L  R570    
 L  R571    
 L  R572    
 L  R573    
 L  R574    
 L  R575    
 L  R576    
 L  R577    
 L  R578    
 L  R579    
 L  R580    
 L  R581    
 L  R582    
 L  R583    
 L  R584    
 L  R585    
 L  R586    
 L  R587    
 L  R588    
 L  R589    
 L  R590    
 L  R591    
 L  R592    
 L  R593    
 L  R594    
 L  R595    
 L  R596    
 L  R597    
 L  R598    
 L  R599    
 L  R600    
 L  R601    
 L  R602    
 L  R603    
 L  R604    
 L  R605    
 L  R606    
 L  R607    
 L  R608    
 L  R609    
 L  R610    
 L  R611    
 L  R612    
 L  R613    
 L  R614    
 L  R615    
 L  R616    
 L  R617    
 L  R618    
 L  R619    
 L  R620    
 L  R621    
 L  R622    
 L  R623    
 L  R624    
 L  R625    
 L  R626    
 L  R627    
 L  R628    
 L  R629    
 L  R630    
 L  R631    
 L  R632    
 L  R633    
 L  R634    
 L  R635    
 L  R636    
 L  R637    
 L  R638    
 L  R639    
 L  R640    
 L  R641    
 L  R642    
 L  R643    
 L  R644    
 L  R645    
 L  R646    
 L  R647    
 L  R648    
 L  R649    
 L  R650    
 L  R651    
 L  R652    
 L  R653    
 L  R654    
 L  R655    
 L  R656    
 L  R657    
 L  R658    
 L  R659    
 L  R660    
 L  R661    
 L  R662    
 L  R663    
 L  R664    
 L  R665    
 L  R666    
 L  R667    
 L  R668    
 L  R669    
 L  R670    
 L  R671    
 L  R672    
 L  R673    
 L  R674    
 L  R675    
 L  R676    
 L  R677    
 L  R678    
 L  R679    
 L  R680    
 L  R681    
 L  R682    
 L  R683    
 L  R684    
 L  R685    
 L  R686    
 L  R687    
 L  R688    
 L  R689    
 L  R690    
 L  R691    
 L  R692    
 L  R693    
 L  R694    
 L  R695    
 L  R696    
 L  R697    
 L  R698    
 L  R699    
 L  R700    
 L  R701    
 L  R702    
 L  R703    
 L  R704    
 L  R705    
 L  R706    
 L  R707    
 L  R708    
 L  R709    
 L  R710    
 L  R711    
 L  R712    
 L  R713    
 L  R714    
 L  R715    
 L  R716    
 L  R717    
 L  R718    
 L  R719    
 L  R720    
 L  R721    
 L  R722    
 L  R723    
 L  R724    
 L  R725    
 L  R726    
 L  R727    
 L  R728    
 L  R729    
 L  R730    
 L  R731    
 L  R732    
 L  R733    
 L  R734    
 L  R735    
 L  R736    
 L  R737    
 L  R738    
 L  R739    
 L  R740    
 L  R741    
 L  R742    
 L  R743    
 L  R744    
 L  R745    
 L  R746    
 L  R747    
 L  R748    
 L  R749    
 L  R750    
 L  R751    
 L  R752    
 L  R753    
 L  R754    
 L  R755    
 L  R756    
 L  R757    
 L  R758    
 L  R759    
 L  R760    
 L  R761    
 L  R762    
 L  R763    
 L  R764    
 L  R765    
 L  R766    
 L  R767    
 L  R768    
 L  R769    
 L  R770    
 L  R771    
 L  R772    
 L  R773    
 L  R774    
 L  R775    
 L  R776    
 L  R777    
 L  R778    
 L  R779    
 L  R780    
 L  R781    
 L  R782    
 L  R783    
 L  R784    
 L  R785    
 L  R786    
 L  R787    
 L  R788    
 L  R789    
 L  R790    
 L  R791    
 L  R792    
 L  R793    
 L  R794    
 L  R795    
 L  R796    
 L  R797    
 L  R798    
 L  R799    
 L  R800    
 L  R801    
 L  R802    
 L  R803    
 L  R804    
 L  R805    
 L  R806    
 L  R807    
 L  R808    
 L  R809    
 L  R810    
 L  R811    
 L  R812    
 L  R813    
 L  R814    
 L  R815    
 L  R816    
 L  R817    
 L  R818    
 L  R819    
 L  R820    
 L  R821    
 L  R822    
 L  R823    
 L  R824    
 L  R825    
 L  R826    
 L  R827    
 L  R828    
 L  R829    
 L  R830    
 L  R831    
 L  R832    
 L  R833    
 L  R834    
 L  R835    
 L  R836    
 L  R837    
 L  R838    
 L  R839    
 L  R840    
 L  R841    
 L  R842    
 L  R843    
 L  R844    
 L  R845    
 L  R846    
 L  R847    
 L  R848    
 L  R849    
 L  R850    
 L  R851    
 L  R852    
 L  R853    
 L  R854    
 L  R855    
 L  R856    
 L  R857    
 L  R858    
 L  R859    
 L  R860    
 L  R861    
 L  R862    
 L  R863    
 L  R864    
 L  R865    
 L  R866    
 L  R867    
 L  R868    
 L  R869    
 L  R870    
 L  R871    
 L  R872    
 L  R873    
 L  R874    
 L  R875    
 L  R876    
 L  R877    
 L  R878    
 L  R879    
 L  R880    
 L  R881    
 L  R882    
 L  R883    
 L  R884    
 L  R885    
 L  R886    
 L  R887    
 L  R888    
 L  R889    
 L  R890    
 L  R891    
 L  R892    
 L  R893    
 L  R894    
 L  R895    
 L  R896    
 L  R897    
 L  R898    
 L  R899    
 L  R900    
 L  R901    
 L  R902    
 L  R903    
 L  R904    
 L  R905    
 L  R906    
 L  R907    
 L  R908    
 L  R909    
 L  R910    
 L  R911    
 L  R912    
 L  R913    
 L  R914    
 L  R915    
 L  R916    
 L  R917    
 L  R918    
 L  R919    
 L  R920    
 L  R921    
 L  R922    
 L  R923    
 L  R924    
 L  R925    
 L  R926    
 L  R927    
 L  R928    
 L  R929    
 L  R930    
 L  R931    
 L  R932    
 L  R933    
 L  R934    
 L  R935    
 L  R936    
 L  R937    
 L  R938    
 L  R939    
 L  R940    
 L  R941    
 L  R942    
 L  R943    
 L  R944    
 L  R945    
 L  R946    
 L  R947    
 L  R948    
 L  R949    
 L  R950    
 L  R951    
 L  R952    
 L  R953    
 L  R954    
 L  R955    
 L  R956    
 L  R957    
 L  R958    
 L  R959    
 L  R960    
 L  R961    
 L  R962    
 L  R963    
 L  R964    
 L  R965    
 L  R966    
 L  R967    
 L  R968    
 L  R969    
 L  R970    
 L  R971    
 L  R972    
 L  R973    
 L  R974    
 L  R975    
 L  R976    
 L  R977    
 L  R978    
 L  R979    
 L  R980    
 L  R981    
 L  R982    
 L  R983    
 L  R984    
 L  R985    
 L  R986    
 L  R987    
 L  R988    
 L  R989    
 L  R990    
 L  R991    
 L  R992    
 L  R993    
 L  R994    
 L  R995    
 L  R996    
 L  R997    
 L  R998    
 L  R999    
 L  R1000   
 L  R1001   
 L  R1002   
 L  R1003   
 L  R1004   
 L  R1005   
 L  R1006   
 L  R1007   
 L  R1008   
 L  R1009   
 L  R1010   
 L  R1011   
 L  R1012   
 L  R1013   
 L  R1014   
 L  R1015   
 L  R1016   
 L  R1017   
 L  R1018   
 L  R1019   
 L  R1020   
 L  R1021   
 L  R1022   
 L  R1023   
 L  R1024   
 L  R1025   
 L  R1026   
 L  R1027   
 L  R1028   
 L  R1029   
 L  R1030   
 L  R1031   
 L  R1032   
 L  R1033   
 L  R1034   
 L  R1035   
 L  R1036   
 L  R1037   
 L  R1038   
 L  R1039   
 L  R1040   
 L  R1041   
 L  R1042   
 L  R1043   
 L  R1044   
 L  R1045   
 L  R1046   
 L  R1047   
 L  R1048   
 L  R1049   
 L  R1050   
 L  R1051   
 L  R1052   
 L  R1053   
 L  R1054   
 L  R1055   
 L  R1056   
 L  R1057   
 L  R1058   
 L  R1059   
 L  R1060   
 L  R1061   
 L  R1062   
 L  R1063   
 L  R1064   
 L  R1065   
 L  R1066   
 L  R1067   
 L  R1068   
 L  R1069   
 L  R1070   
 L  R1071   
 L  R1072   
 L  R1073   
 L  R1074   
 L  R1075   
 L  R1076   
 L  R1077   
 L  R1078   
 L  R1079   
 L  R1080   
 L  R1081   
 L  R1082   
 L  R1083   
 L  R1084   
 L  R1085   
 L  R1086   
 L  R1087   
 L  R1088   
 L  R1089   
 L  R1090   
 L  R1091   
 L  R1092   
 L  R1093   
 L  R1094   
 L  R1095   
 L  R1096   
 L  R1097   
 L  R1098   
 L  R1099   
 L  R1100   
 L  R1101   
 L  R1102   
 L  R1103   
 L  R1104   
 L  R1105   
 L  R1106   
 L  R1107   
 L  R1108   
 L  R1109   
 L  R1110   
 L  R1111   
 L  R1112   
 L  R1113   
 L  R1114   
 L  R1115   
 L  R1116   
 L  R1117   
 L  R1118   
 L  R1119   
 L  R1120   
 L  R1121   
 L  R1122   
 L  R1123   
 L  R1124   
 L  R1125   
 L  R1126   
 L  R1127   
 L  R1128   
 L  R1129   
 L  R1130   
 L  R1131   
 L  R1132   
 L  R1133   
 L  R1134   
 L  R1135   
 L  R1136   
 L  R1137   
 L  R1138   
 L  R1139   
 L  R1140   
 L  R1141   
 L  R1142   
 L  R1143   
 L  R1144   
 L  R1145   
 L  R1146   
 L  R1147   
 L  R1148   
 L  R1149   
 L  R1150   
 L  R1151   
 L  R1152   
 L  R1153   
 L  R1154   
 L  R1155   
 L  R1156   
 L  R1157   
 L  R1158   
 L  R1159   
 L  R1160   
 L  R1161   
 L  R1162   
 L  R1163   
 L  R1164   
 L  R1165   
 L  R1166   
 L  R1167   
 L  R1168   
 L  R1169   
 L  R1170   
 L  R1171   
 L  R1172   
 L  R1173   
 L  R1174   
 L  R1175   
 L  R1176   
 L  R1177   
 L  R1178   
 L  R1179   
 L  R1180   
 L  R1181   
 L  R1182   
 L  R1183   
 L  R1184   
 L  R1185   
 L  R1186   
 L  R1187   
 L  R1188   
 L  R1189   
 L  R1190   
 L  R1191   
 L  R1192   
 L  R1193   
 L  R1194   
 L  R1195   
 L  R1196   
 L  R1197   
 L  R1198   
 L  R1199   
 L  R1200   
 L  R1201   
 L  R1202   
 L  R1203   
 L  R1204   
 L  R1205   
 L  R1206   
 L  R1207   
 L  R1208   
 L  R1209   
 L  R1210   
 L  R1211   
 L  R1212   
 L  R1213   
 L  R1214   
 L  R1215   
 L  R1216   
 L  R1217   
 L  R1218   
 L  R1219   
 L  R1220   
 L  R1221   
 L  R1222   
 L  R1223   
 L  R1224   
 L  R1225   
 L  R1226   
 L  R1227   
 L  R1228   
 L  R1229   
 L  R1230   
 L  R1231   
 L  R1232   
 L  R1233   
 L  R1234   
 L  R1235   
 L  R1236   
 L  R1237   
 L  R1238   
 L  R1239   
 L  R1240   
 L  R1241   
 L  R1242   
 L  R1243   
 L  R1244   
 L  R1245   
 L  R1246   
 L  R1247   
 L  R1248   
 L  R1249   
 L  R1250   
 L  R1251   
 L  R1252   
 L  R1253   
 L  R1254   
 L  R1255   
 L  R1256   
 L  R1257   
 L  R1258   
 L  R1259   
 L  R1260   
 L  R1261   
 L  R1262   
 L  R1263   
 L  R1264   
 L  R1265   
 L  R1266   
 L  R1267   
 L  R1268   
 L  R1269   
 L  R1270   
 L  R1271   
 L  R1272   
 L  R1273   
 L  R1274   
 L  R1275   
 L  R1276   
 L  R1277   
 L  R1278   
 L  R1279   
 L  R1280   
 L  R1281   
 L  R1282   
 L  R1283   
 L  R1284   
 L  R1285   
 L  R1286   
 L  R1287   
 L  R1288   
 L  R1289   
 L  R1290   
 L  R1291   
 L  R1292   
 L  R1293   
 L  R1294   
 L  R1295   
 L  R1296   
 L  R1297   
 L  R1298   
 L  R1299   
 L  R1300   
 L  R1301   
 L  R1302   
 L  R1303   
 L  R1304   
 L  R1305   
 L  R1306   
 L  R1307   
 L  R1308   
 L  R1309   
 L  R1310   
 L  R1311   
 L  R1312   
 L  R1313   
 L  R1314   
 L  R1315   
 L  R1316   
 L  R1317   
 L  R1318   
 L  R1319   
 L  R1320   
 L  R1321   
 L  R1322   
 L  R1323   
 L  R1324   
 L  R1325   
 L  R1326   
 L  R1327   
 L  R1328   
 L  R1329   
 L  R1330   
 L  R1331   
 L  R1332   
 L  R1333   
 L  R1334   
 L  R1335   
 L  R1336   
 L  R1337   
 L  R1338   
 L  R1339   
 L  R1340   
 L  R1341   
 L  R1342   
 L  R1343   
 L  R1344   
 L  R1345   
 L  R1346   
 L  R1347   
 L  R1348   
 L  R1349   
 L  R1350   
 L  R1351   
 L  R1352   
 L  R1353   
 L  R1354   
 L  R1355   
 L  R1356   
 L  R1357   
 L  R1358   
 L  R1359   
 L  R1360   
 L  R1361   
 L  R1362   
 L  R1363   
 L  R1364   
 L  R1365   
 L  R1366   
 L  R1367   
 L  R1368   
 L  R1369   
 L  R1370   
 L  R1371   
 L  R1372   
 L  R1373   
 L  R1374   
 L  R1375   
 L  R1376   
 L  R1377   
 L  R1378   
 L  R1379   
 L  R1380   
 L  R1381   
 L  R1382   
 L  R1383   
 L  R1384   
 L  R1385   
 L  R1386   
 L  R1387   
 L  R1388   
 L  R1389   
 L  R1390   
 L  R1391   
 L  R1392   
 L  R1393   
 L  R1394   
 L  R1395   
 L  R1396   
 L  R1397   
 L  R1398   
 L  R1399   
 L  R1400   
 L  R1401   
 L  R1402   
 L  R1403   
 L  R1404   
 L  R1405   
 L  R1406   
 L  R1407   
 L  R1408   
 L  R1409   
 L  R1410   
 L  R1411   
 L  R1412   
 L  R1413   
 L  R1414   
 L  R1415   
 L  R1416   
 L  R1417   
 L  R1418   
 L  R1419   
 L  R1420   
 L  R1421   
 L  R1422   
 L  R1423   
 L  R1424   
 L  R1425   
 L  R1426   
 L  R1427   
 L  R1428   
 L  R1429   
 L  R1430   
 L  R1431   
 L  R1432   
 L  R1433   
 L  R1434   
 L  R1435   
 L  R1436   
 L  R1437   
 L  R1438   
 L  R1439   
 L  R1440   
 L  R1441   
 L  R1442   
 L  R1443   
 L  R1444   
 L  R1445   
 L  R1446   
 L  R1447   
 L  R1448   
 L  R1449   
 L  R1450   
 L  R1451   
 L  R1452   
 L  R1453   
 L  R1454   
 L  R1455   
 L  R1456   
 L  R1457   
 L  R1458   
 L  R1459   
 L  R1460   
 L  R1461   
 L  R1462   
 L  R1463   
 L  R1464   
 L  R1465   
 L  R1466   
 L  R1467   
 L  R1468   
 L  R1469   
 L  R1470   
 L  R1471   
 L  R1472   
 L  R1473   
 L  R1474   
 L  R1475   
 L  R1476   
 L  R1477   
 L  R1478   
 L  R1479   
 L  R1480   
 L  R1481   
 L  R1482   
 L  R1483   
 L  R1484   
 L  R1485   
 L  R1486   
 L  R1487   
 L  R1488   
 L  R1489   
 L  R1490   
 L  R1491   
 L  R1492   
 L  R1493   
 L  R1494   
 L  R1495   
 L  R1496   
 L  R1497   
 L  R1498   
 L  R1499   
 L  R1500   
 L  R1501   
 L  R1502   
 L  R1503   
 L  R1504   
 L  R1505   
 L  R1506   
 L  R1507   
 L  R1508   
 L  R1509   
 L  R1510   
 L  R1511   
 L  R1512   
 L  R1513   
 L  R1514   
 L  R1515   
 L  R1516   
 L  R1517   
 L  R1518   
 L  R1519   
 L  R1520   
 L  R1521   
 L  R1522   
 L  R1523   
 L  R1524   
 L  R1525   
 L  R1526   
 L  R1527   
 L  R1528   
 L  R1529   
 L  R1530   
 L  R1531   
 L  R1532   
 L  R1533   
 L  R1534   
 L  R1535   
 L  R1536   
 L  R1537   
 L  R1538   
 L  R1539   
 L  R1540   
 L  R1541   
 L  R1542   
 L  R1543   
 L  R1544   
 L  R1545   
 L  R1546   
 L  R1547   
 L  R1548   
 L  R1549   
 L  R1550   
 L  R1551   
 L  R1552   
 L  R1553   
 L  R1554   
 L  R1555   
 L  R1556   
 L  R1557   
 L  R1558   
 L  R1559   
 L  R1560   
 L  R1561   
 L  R1562   
 L  R1563   
 L  R1564   
 L  R1565   
 L  R1566   
 L  R1567   
 L  R1568   
 L  R1569   
 L  R1570   
 L  R1571   
 L  R1572   
 L  R1573   
 L  R1574   
 L  R1575   
 L  R1576   
 L  R1577   
 L  R1578   
 L  R1579   
 L  R1580   
 L  R1581   
 L  R1582   
 L  R1583   
 L  R1584   
 L  R1585   
 L  R1586   
 L  R1587   
 L  R1588   
 L  R1589   
 L  R1590   
 L  R1591   
 L  R1592   
 L  R1593   
 L  R1594   
 L  R1595   
 L  R1596   
 L  R1597   
 L  R1598   
 L  R1599   
 L  R1600   
 L  R1601   
 L  R1602   
 L  R1603   
 L  R1604   
 L  R1605   
 L  R1606   
 L  R1607   
 L  R1608   
 L  R1609   
 L  R1610   
 L  R1611   
 L  R1612   
 L  R1613   
 L  R1614   
 L  R1615   
 L  R1616   
 L  R1617   
 L  R1618   
 L  R1619   
 L  R1620   
 L  R1621   
 L  R1622   
 L  R1623   
 L  R1624   
 L  R1625   
 L  R1626   
 L  R1627   
 L  R1628   
 L  R1629   
 L  R1630   
 L  R1631   
 L  R1632   
 L  R1633   
 L  R1634   
 L  R1635   
 L  R1636   
 L  R1637   
 L  R1638   
 L  R1639   
 L  R1640   
 L  R1641   
 L  R1642   
 L  R1643   
 L  R1644   
 L  R1645   
 L  R1646   
 L  R1647   
 L  R1648   
 L  R1649   
 L  R1650   
 L  R1651   
 L  R1652   
 L  R1653   
 L  R1654   
 L  R1655   
 L  R1656   
 L  R1657   
 L  R1658   
 L  R1659   
 L  R1660   
 L  R1661   
 L  R1662   
 L  R1663   
 L  R1664   
 L  R1665   
 L  R1666   
 L  R1667   
 L  R1668   
 L  R1669   
 L  R1670   
 L  R1671   
 L  R1672   
 L  R1673   
 L  R1674   
 L  R1675   
 L  R1676   
 L  R1677   
 L  R1678   
 L  R1679   
 L  R1680   
 L  R1681   
 L  R1682   
 L  R1683   
 L  R1684   
 L  R1685   
 L  R1686   
 L  R1687   
 L  R1688   
 L  R1689   
 L  R1690   
 L  R1691   
 L  R1692   
 L  R1693   
 L  R1694   
 L  R1695   
 L  R1696   
 L  R1697   
 L  R1698   
 L  R1699   
 L  R1700   
 L  R1701   
 L  R1702   
 L  R1703   
 L  R1704   
 L  R1705   
 L  R1706   
 L  R1707   
 L  R1708   
 L  R1709   
 L  R1710   
 L  R1711   
 L  R1712   
 L  R1713   
 L  R1714   
 L  R1715   
 L  R1716   
 L  R1717   
 L  R1718   
 L  R1719   
 L  R1720   
 L  R1721   
 L  R1722   
 L  R1723   
 L  R1724   
 L  R1725   
 L  R1726   
 L  R1727   
 L  R1728   
 L  R1729   
 L  R1730   
 L  R1731   
 L  R1732   
 L  R1733   
 L  R1734   
 L  R1735   
 L  R1736   
 L  R1737   
 L  R1738   
 L  R1739   
 L  R1740   
 L  R1741   
 L  R1742   
 L  R1743   
 L  R1744   
 L  R1745   
 L  R1746   
 L  R1747   
 L  R1748   
 L  R1749   
 L  R1750   
 L  R1751   
 L  R1752   
 L  R1753   
 L  R1754   
 L  R1755   
 L  R1756   
 L  R1757   
 L  R1758   
 L  R1759   
 L  R1760   
 L  R1761   
 L  R1762   
 L  R1763   
 L  R1764   
 L  R1765   
 L  R1766   
 L  R1767   
 L  R1768   
 L  R1769   
 L  R1770   
 L  R1771   
 L  R1772   
 L  R1773   
 L  R1774   
 L  R1775   
 L  R1776   
 L  R1777   
 L  R1778   
 L  R1779   
 L  R1780   
 L  R1781   
 L  R1782   
 L  R1783   
 L  R1784   
 L  R1785   
 L  R1786   
 L  R1787   
 L  R1788   
 L  R1789   
 L  R1790   
 L  R1791   
 L  R1792   
 L  R1793   
 L  R1794   
 L  R1795   
 L  R1796   
 L  R1797   
 L  R1798   
 L  R1799   
 L  R1800   
 L  R1801   
 L  R1802   
 L  R1803   
 L  R1804   
 L  R1805   
 L  R1806   
 L  R1807   
 L  R1808   
 L  R1809   
 L  R1810   
 L  R1811   
 L  R1812   
 L  R1813   
 L  R1814   
 L  R1815   
 L  R1816   
 L  R1817   
 L  R1818   
 L  R1819   
 L  R1820   
 L  R1821   
 L  R1822   
 L  R1823   
 L  R1824   
 L  R1825   
 L  R1826   
 L  R1827   
 L  R1828   
 L  R1829   
 L  R1830   
 L  R1831   
 L  R1832   
 L  R1833   
 L  R1834   
 L  R1835   
 L  R1836   
 L  R1837   
 L  R1838   
 L  R1839   
 L  R1840   
 L  R1841   
 L  R1842   
 L  R1843   
 L  R1844   
 L  R1845   
 L  R1846   
 L  R1847   
 L  R1848   
 L  R1849   
 L  R1850   
 L  R1851   
 L  R1852   
 L  R1853   
 L  R1854   
 L  R1855   
 L  R1856   
 L  R1857   
 L  R1858   
 L  R1859   
 L  R1860   
 L  R1861   
 L  R1862   
 L  R1863   
 L  R1864   
 L  R1865   
 L  R1866   
 L  R1867   
 L  R1868   
 L  R1869   
 L  R1870   
 L  R1871   
 L  R1872   
 L  R1873   
 L  R1874   
 L  R1875   
 L  R1876   
 L  R1877   
 L  R1878   
 L  R1879   
 L  R1880   
 L  R1881   
 L  R1882   
 L  R1883   
 L  R1884   
 L  R1885   
 L  R1886   
 L  R1887   
 L  R1888   
 L  R1889   
 L  R1890   
 L  R1891   
 L  R1892   
 L  R1893   
 L  R1894   
 L  R1895   
 L  R1896   
 L  R1897   
 L  R1898   
 L  R1899   
 L  R1900   
 L  R1901   
 L  R1902   
 L  R1903   
 L  R1904   
 L  R1905   
 L  R1906   
 L  R1907   
 L  R1908   
 L  R1909   
 L  R1910   
 L  R1911   
 L  R1912   
 L  R1913   
 L  R1914   
 L  R1915   
 L  R1916   
 L  R1917   
 L  R1918   
 L  R1919   
 L  R1920   
 L  R1921   
 L  R1922   
 L  R1923   
 L  R1924   
 L  R1925   
 L  R1926   
 L  R1927   
 L  R1928   
 L  R1929   
 L  R1930   
 L  R1931   
 L  R1932   
 L  R1933   
 L  R1934   
 L  R1935   
 L  R1936   
 L  R1937   
 L  R1938   
 L  R1939   
 L  R1940   
 L  R1941   
 L  R1942   
 L  R1943   
 L  R1944   
 L  R1945   
 L  R1946   
 L  R1947   
 L  R1948   
 L  R1949   
 L  R1950   
 L  R1951   
 L  R1952   
 L  R1953   
 L  R1954   
 L  R1955   
 L  R1956   
 L  R1957   
 L  R1958   
 L  R1959   
 L  R1960   
 L  R1961   
 L  R1962   
 L  R1963   
 L  R1964   
 L  R1965   
 L  R1966   
 L  R1967   
 L  R1968   
 L  R1969   
 L  R1970   
 L  R1971   
 L  R1972   
 L  R1973   
 L  R1974   
 L  R1975   
 L  R1976   
 L  R1977   
 L  R1978   
 L  R1979   
 L  R1980   
 L  R1981   
 L  R1982   
 L  R1983   
 L  R1984   
 L  R1985   
 L  R1986   
 L  R1987   
 L  R1988   
 L  R1989   
 L  R1990   
 L  R1991   
 L  R1992   
 L  R1993   
 L  R1994   
 L  R1995   
 L  R1996   
 L  R1997   
 L  R1998   
 L  R1999   
 L  R2000   
 L  R2001   
 L  R2002   
 L  R2003   
 L  R2004   
 L  R2005   
 L  R2006   
 L  R2007   
 L  R2008   
 L  R2009   
 L  R2010   
 L  R2011   
 L  R2012   
 L  R2013   
 L  R2014   
 L  R2015   
 L  R2016   
 L  R2017   
 L  R2018   
 L  R2019   
 L  R2020   
 L  R2021   
 L  R2022   
 L  R2023   
 L  R2024   
 L  R2025   
 L  R2026   
 L  R2027   
 L  R2028   
 L  R2029   
 L  R2030   
 L  R2031   
 L  R2032   
 L  R2033   
 L  R2034   
 L  R2035   
 L  R2036   
 L  R2037   
 L  R2038   
 L  R2039   
 L  R2040   
 L  R2041   
 L  R2042   
 L  R2043   
 L  R2044   
 L  R2045   
 L  R2046   
 L  R2047   
 L  R2048   
 L  R2049   
 L  R2050   
 L  R2051   
 L  R2052   
 L  R2053   
 L  R2054   
 L  R2055   
 L  R2056   
 L  R2057   
 L  R2058   
 L  R2059   
 L  R2060   
 L  R2061   
 L  R2062   
 L  R2063   
 L  R2064   
 L  R2065   
 L  R2066   
 L  R2067   
 L  R2068   
 L  R2069   
 L  R2070   
 L  R2071   
 L  R2072   
 L  R2073   
 L  R2074   
 L  R2075   
 L  R2076   
 L  R2077   
 L  R2078   
 L  R2079   
 L  R2080   
 L  R2081   
 L  R2082   
 L  R2083   
 L  R2084   
 L  R2085   
 L  R2086   
 L  R2087   
 L  R2088   
 L  R2089   
 L  R2090   
 L  R2091   
 L  R2092   
 L  R2093   
 L  R2094   
 L  R2095   
 L  R2096   
 L  R2097   
 L  R2098   
 L  R2099   
 L  R2100   
 L  R2101   
 L  R2102   
 L  R2103   
 L  R2104   
 L  R2105   
 L  R2106   
 L  R2107   
 L  R2108   
 L  R2109   
 L  R2110   
 L  R2111   
 L  R2112   
 L  R2113   
 L  R2114   
 L  R2115   
 L  R2116   
 L  R2117   
 L  R2118   
 L  R2119   
 L  R2120   
 L  R2121   
 L  R2122   
 L  R2123   
 L  R2124   
 L  R2125   
 L  R2126   
 L  R2127   
 L  R2128   
 L  R2129   
 L  R2130   
 L  R2131   
 L  R2132   
 L  R2133   
 L  R2134   
 L  R2135   
 L  R2136   
 L  R2137   
 L  R2138   
 L  R2139   
 L  R2140   
 L  R2141   
 L  R2142   
 L  R2143   
 L  R2144   
 L  R2145   
 L  R2146   
 L  R2147   
 L  R2148   
 L  R2149   
 L  R2150   
 L  R2151   
 L  R2152   
 L  R2153   
 L  R2154   
 L  R2155   
 L  R2156   
 L  R2157   
 L  R2158   
 L  R2159   
 L  R2160   
 L  R2161   
 L  R2162   
 L  R2163   
 L  R2164   
 L  R2165   
 L  R2166   
 L  R2167   
 L  R2168   
 L  R2169   
 L  R2170   
 L  R2171   
 L  R2172   
 L  R2173   
 L  R2174   
 L  R2175   
 L  R2176   
 L  R2177   
 L  R2178   
 L  R2179   
 L  R2180   
 L  R2181   
 L  R2182   
 L  R2183   
 L  R2184   
 L  R2185   
 L  R2186   
 L  R2187   
 L  R2188   
 L  R2189   
 L  R2190   
 L  R2191   
 L  R2192   
 L  R2193   
 L  R2194   
 L  R2195   
 L  R2196   
 L  R2197   
 L  R2198   
 L  R2199   
 L  R2200   
 L  R2201   
 L  R2202   
 L  R2203   
 L  R2204   
 L  R2205   
 L  R2206   
 L  R2207   
 L  R2208   
 L  R2209   
 L  R2210   
 L  R2211   
 L  R2212   
 L  R2213   
 L  R2214   
 L  R2215   
 L  R2216   
 L  R2217   
 L  R2218   
 L  R2219   
 L  R2220   
 L  R2221   
 L  R2222   
 L  R2223   
 L  R2224   
 L  R2225   
 L  R2226   
 L  R2227   
 L  R2228   
 L  R2229   
 L  R2230   
 L  R2231   
 L  R2232   
 L  R2233   
 L  R2234   
 L  R2235   
 L  R2236   
 L  R2237   
 L  R2238   
 L  R2239   
 L  R2240   
 L  R2241   
 L  R2242   
 L  R2243   
 L  R2244   
 L  R2245   
 L  R2246   
 L  R2247   
 L  R2248   
 L  R2249   
 L  R2250   
 L  R2251   
 L  R2252   
 L  R2253   
 L  R2254   
 L  R2255   
 L  R2256   
 L  R2257   
 L  R2258   
 L  R2259   
 L  R2260   
 L  R2261   
 L  R2262   
 L  R2263   
 L  R2264   
 L  R2265   
 L  R2266   
 L  R2267   
 L  R2268   
 L  R2269   
 L  R2270   
 L  R2271   
 L  R2272   
 L  R2273   
 L  R2274   
 L  R2275   
 L  R2276   
 L  R2277   
 L  R2278   
 L  R2279   
 L  R2280   
 L  R2281   
 L  R2282   
 L  R2283   
 L  R2284   
 L  R2285   
 L  R2286   
 L  R2287   
 L  R2288   
 L  R2289   
 L  R2290   
 L  R2291   
 L  R2292   
 L  R2293   
 L  R2294   
 L  R2295   
 L  R2296   
 L  R2297   
 L  R2298   
 L  R2299   
 L  R2300   
 L  R2301   
 L  R2302   
 L  R2303   
 L  R2304   
 L  R2305   
 L  R2306   
 L  R2307   
 L  R2308   
 L  R2309   
 L  R2310   
 L  R2311   
 L  R2312   
 L  R2313   
 L  R2314   
 L  R2315   
 L  R2316   
 L  R2317   
 L  R2318   
 L  R2319   
 L  R2320   
 L  R2321   
 L  R2322   
 L  R2323   
 L  R2324   
 L  R2325   
 L  R2326   
 L  R2327   
 L  R2328   
 L  R2329   
 L  R2330   
 L  R2331   
 L  R2332   
 L  R2333   
 L  R2334   
 L  R2335   
 L  R2336   
 L  R2337   
 L  R2338   
 L  R2339   
 L  R2340   
 L  R2341   
 L  R2342   
 L  R2343   
 L  R2344   
 L  R2345   
 L  R2346   
 L  R2347   
 L  R2348   
 L  R2349   
 L  R2350   
 L  R2351   
 L  R2352   
 L  R2353   
 L  R2354   
 L  R2355   
 L  R2356   
 L  R2357   
 L  R2358   
 L  R2359   
 L  R2360   
 L  R2361   
 L  R2362   
 L  R2363   
 L  R2364   
 L  R2365   
 L  R2366   
 L  R2367   
 L  R2368   
 L  R2369   
 L  R2370   
 L  R2371   
 L  R2372   
 L  R2373   
 L  R2374   
 L  R2375   
 L  R2376   
 L  R2377   
 L  R2378   
 L  R2379   
 L  R2380   
 L  R2381   
 L  R2382   
 L  R2383   
 L  R2384   
 L  R2385   
 L  R2386   
 L  R2387   
 L  R2388   
 L  R2389   
 L  R2390   
 L  R2391   
 L  R2392   
 L  R2393   
 L  R2394   
 L  R2395   
 L  R2396   
 L  R2397   
 L  R2398   
 L  R2399   
 L  R2400   
 L  R2401   
 L  R2402   
 L  R2403   
 L  R2404   
 L  R2405   
 L  R2406   
 L  R2407   
 L  R2408   
 L  R2409   
 L  R2410   
 L  R2411   
 L  R2412   
 L  R2413   
 L  R2414   
 L  R2415   
 L  R2416   
 L  R2417   
 L  R2418   
 L  R2419   
 L  R2420   
 L  R2421   
 L  R2422   
 L  R2423   
 L  R2424   
 L  R2425   
 L  R2426   
 L  R2427   
 L  R2428   
 L  R2429   
 L  R2430   
 L  R2431   
 L  R2432   
 L  R2433   
 L  R2434   
 L  R2435   
 L  R2436   
 L  R2437   
 L  R2438   
 L  R2439   
 L  R2440   
 L  R2441   
 L  R2442   
 L  R2443   
 L  R2444   
 L  R2445   
 L  R2446   
 L  R2447   
 L  R2448   
 L  R2449   
 L  R2450   
 L  R2451   
 L  R2452   
 L  R2453   
 L  R2454   
 L  R2455   
 L  R2456   
 L  R2457   
 L  R2458   
 L  R2459   
 L  R2460   
 L  R2461   
 L  R2462   
 L  R2463   
 L  R2464   
 L  R2465   
 L  R2466   
 L  R2467   
 L  R2468   
 L  R2469   
 L  R2470   
 L  R2471   
 L  R2472   
 L  R2473   
 L  R2474   
 L  R2475   
 L  R2476   
 L  R2477   
 L  R2478   
 L  R2479   
 L  R2480   
 L  R2481   
 L  R2482   
 L  R2483   
 L  R2484   
 L  R2485   
 L  R2486   
 L  R2487   
 L  R2488   
 L  R2489   
 L  R2490   
 L  R2491   
 L  R2492   
 L  R2493   
 L  R2494   
 L  R2495   
 L  R2496   
 L  R2497   
 L  R2498   
 L  R2499   
 L  R2500   
 L  R2501   
 L  R2502   
 L  R2503   
 L  R2504   
 L  R2505   
 L  R2506   
 L  R2507   
 L  R2508   
 L  R2509   
 L  R2510   
 L  R2511   
 L  R2512   
 L  R2513   
 L  R2514   
 L  R2515   
 L  R2516   
 L  R2517   
 L  R2518   
 L  R2519   
 L  R2520   
 L  R2521   
 L  R2522   
 L  R2523   
 L  R2524   
 L  R2525   
 L  R2526   
 L  R2527   
 L  R2528   
 L  R2529   
 L  R2530   
 L  R2531   
 L  R2532   
 L  R2533   
 L  R2534   
 L  R2535   
 L  R2536   
 L  R2537   
 L  R2538   
 L  R2539   
 L  R2540   
 L  R2541   
 L  R2542   
 L  R2543   
 L  R2544   
 L  R2545   
 L  R2546   
 L  R2547   
 L  R2548   
 L  R2549   
 L  R2550   
 L  R2551   
 L  R2552   
 L  R2553   
 L  R2554   
 L  R2555   
 L  R2556   
 L  R2557   
 L  R2558   
 L  R2559   
 L  R2560   
 L  R2561   
 L  R2562   
 L  R2563   
 L  R2564   
 L  R2565   
 L  R2566   
 L  R2567   
 L  R2568   
 L  R2569   
 L  R2570   
 L  R2571   
 L  R2572   
 L  R2573   
 L  R2574   
 L  R2575   
 L  R2576   
 L  R2577   
 L  R2578   
 L  R2579   
 L  R2580   
 L  R2581   
 L  R2582   
 L  R2583   
 L  R2584   
 L  R2585   
 L  R2586   
 L  R2587   
 L  R2588   
 L  R2589   
 L  R2590   
 L  R2591   
 L  R2592   
 L  R2593   
 L  R2594   
 L  R2595   
 L  R2596   
 L  R2597   
 L  R2598   
 L  R2599   
 L  R2600   
 L  R2601   
 L  R2602   
 L  R2603   
 L  R2604   
 L  R2605   
 L  R2606   
 L  R2607   
 L  R2608   
 L  R2609   
 L  R2610   
 L  R2611   
 L  R2612   
 L  R2613   
 L  R2614   
 L  R2615   
 L  R2616   
 L  R2617   
 L  R2618   
 L  R2619   
 L  R2620   
 L  R2621   
 L  R2622   
 L  R2623   
 L  R2624   
 L  R2625   
 L  R2626   
 L  R2627   
 L  R2628   
 L  R2629   
 L  R2630   
 L  R2631   
 L  R2632   
 L  R2633   
 L  R2634   
 L  R2635   
 L  R2636   
 L  R2637   
 L  R2638   
 L  R2639   
 L  R2640   
 L  R2641   
 L  R2642   
 L  R2643   
 L  R2644   
 L  R2645   
 L  qc0     
 L  qc1     
 L  qc2     
 L  qc3     
 L  qc4     
 L  qc5     
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    phi[0,1]  R0        1
    phi[0,1]  R1        1
    phi[0,1]  R9        -1
    phi[0,1]  R56       -3.0999999046325684e+00
    phi[0,1]  R57       -3.0999999046325684e+00
    phi[0,1]  R58       -2.2400000095367432e+00
    phi[0,1]  R59       -2.2400000095367432e+00
    phi[0,1]  R60       -3.0999999046325684e+00
    phi[0,1]  R61       -3.0999999046325684e+00
    phi[0,1]  R62       -2.5699999332427979e+00
    phi[0,1]  R63       -2.5699999332427979e+00
    phi[0,1]  R64       -3.0999999046325684e+00
    phi[0,1]  R65       -3.0999999046325684e+00
    phi[0,1]  R66       -2.0899999141693115e+00
    phi[0,1]  R67       -2.0899999141693115e+00
    phi[0,1]  R68       -3.0999999046325684e+00
    phi[0,1]  R69       -3.0999999046325684e+00
    phi[0,1]  R70       -1.4610990881919861e-01
    phi[0,1]  R71       8.0248171091079712e-01
    phi[0,1]  R72       4.5802196860313416e-01
    phi[0,1]  R73       -3.4451760351657867e-02
    phi[0,1]  R74       -2.7420103549957275e-01
    phi[0,1]  R75       -4.7015488147735596e-01
    phi[0,1]  R76       5.9532690048217773e-01
    phi[0,1]  R77       1.8066960573196411e-01
    phi[0,1]  R78       9.5075249671936035e-01
    phi[0,1]  R79       1.8501701951026917e-01
    phi[0,1]  R80       -4.2700031399726868e-01
    phi[0,1]  R81       2.3579079657793045e-02
    phi[0,1]  R82       1.4015294611454010e-01
    phi[0,1]  R83       2.2315458953380585e-01
    phi[0,1]  R84       6.8645328283309937e-01
    phi[0,1]  R85       -6.8876773118972778e-01
    phi[0,1]  R86       -1.4252930879592896e+00
    phi[0,1]  R87       -1.4122997522354126e+00
    phi[0,1]  R88       -8.9936751127243042e-01
    phi[0,1]  R89       -5.0741457939147949e-01
    phi[0,1]  R90       -2.5308969020843506e+00
    phi[0,1]  R91       -2.2411015033721924e+00
    phi[0,1]  R92       -1.7581125497817993e+00
    phi[0,1]  R93       -1.0500463247299194e+00
    phi[0,1]  R94       -7.1725195646286011e-01
    phi[0,1]  R95       -2.2032005786895752e+00
    phi[0,1]  R96       -2.1184623241424561e+00
    phi[0,1]  R97       -1.1565734148025513e+00
    phi[0,1]  R98       -1.17945396900177
    phi[0,1]  R99       -1.0087952613830566e+00
    phi[0,1]  R100      4.8072883486747742e-01
    phi[0,1]  R101      9.2672121524810791e-01
    phi[0,1]  R102      5.6869786977767944e-01
    phi[0,1]  R103      1.1835095882415771e+00
    phi[0,1]  R104      6.2269258499145508e-01
    phi[0,1]  R105      8.2096248865127563e-01
    phi[0,1]  R106      7.8266811370849609e-01
    phi[0,1]  R107      -0.921746551990509
    phi[0,1]  R108      -6.5485566854476929e-02
    phi[0,1]  R109      2.6129174232482910e-01
    phi[0,1]  R110      -1.4315564632415771e+00
    phi[0,1]  R111      -6.4470881223678589e-01
    phi[0,1]  R112      -1.8094162940979004e+00
    phi[0,1]  R113      -5.4818183183670044e-01
    phi[0,1]  R114      -2.6221022605895996e+00
    phi[0,1]  R115      -2.6999969482421875e+00
    phi[0,1]  R116      -1.38058602809906
    phi[0,1]  R117      -5.3599423170089722e-01
    phi[0,1]  R118      -7.7736479043960571e-01
    phi[0,1]  R119      -1.4018226861953735e+00
    phi[0,1]  R120      -1.9024895429611206e+00
    phi[0,1]  R121      -1.3222129642963409e-01
    phi[0,1]  R122      -1.1159085035324097e+00
    phi[0,1]  R123      -3.6070916056632996e-01
    phi[0,1]  R124      -3.2501956820487976e-01
    phi[0,1]  R125      -6.9768828153610229e-01
    phi[0,1]  R126      -1.1073216199874878e+00
    phi[0,1]  R127      1.8805004656314850e-01
    phi[0,1]  R128      -2.70127534866333
    phi[0,1]  R129      3.6966949701309204e-01
    phi[0,1]  R130      -1.6612381935119629e+00
    phi[0,1]  R131      -3.3356863260269165e-01
    phi[0,1]  R132      -2.6370186805725098e+00
    phi[0,1]  R133      -6.3232409954071045e-01
    phi[0,1]  R134      -1.5593767166137695e+00
    phi[0,1]  R135      -2.8109071254730225e+00
    phi[0,1]  R136      1.4483878016471863e-01
    phi[0,1]  R137      -1.6609480977058411e-01
    phi[0,1]  R138      -1.8052299022674561e+00
    phi[0,1]  R139      1.1386805772781372e-01
    phi[0,1]  R140      -8.1957006454467773e-01
    phi[0,1]  R141      5.2390500903129578e-02
    phi[0,1]  R142      -1.5301643610000610e+00
    phi[0,1]  R143      -1.7575470209121704e+00
    phi[0,1]  R144      -2.8501877784729004e+00
    phi[0,1]  R145      -1.7915084958076477e-01
    phi[0,1]  R146      3.0303642153739929e-01
    phi[0,1]  R147      -3.3715620040893555e+00
    phi[0,1]  R148      -2.0060298442840576e+00
    phi[0,1]  R149      -2.7238237857818604e+00
    phi[0,1]  R150      -6.8031489849090576e-01
    phi[0,1]  R151      -2.4363405704498291e+00
    phi[0,1]  R152      -2.1277897357940674e+00
    phi[0,1]  R153      -1.1200655698776245e+00
    phi[0,1]  R154      -1.7033793926239014e+00
    phi[0,1]  R155      -1.0668233633041382e+00
    phi[0,1]  R156      -1.9567710161209106e+00
    phi[0,1]  R157      3.6862635612487793e-01
    phi[0,1]  R158      -3.3069546222686768e+00
    phi[0,1]  R159      -5.7969087362289429e-01
    phi[0,1]  R160      -1.7152290344238281e+00
    phi[0,1]  R161      -1.2254465818405151e+00
    phi[0,1]  R162      -1.4950339794158936e+00
    phi[0,1]  R163      -2.0501000881195068e+00
    phi[0,1]  R164      7.9432517290115356e-01
    phi[0,1]  R165      -2.4705444276332855e-01
    phi[0,1]  R166      -1.4063506126403809e+00
    phi[0,1]  R167      -1.3665323257446289e+00
    phi[0,1]  R168      -1.0960564613342285e+00
    phi[0,1]  R169      -3.1379339098930359e-01
    phi[0,1]  R170      -2.0460108295083046e-02
    phi[0,1]  R171      -1.5683376789093018e+00
    phi[0,1]  R172      -3.0081846714019775e+00
    phi[0,1]  R173      -9.8765993118286133e-01
    phi[0,1]  R174      1.5325158834457397e-01
    phi[0,1]  R175      -2.1035239696502686e+00
    phi[0,1]  R176      -3.0840060710906982e+00
    phi[0,1]  R177      -1.5645678341388702e-01
    phi[0,1]  R178      -8.3870381116867065e-02
    phi[0,1]  R179      6.7055028676986694e-01
    phi[0,1]  R180      -6.3917613029479980e-01
    phi[0,1]  R181      -2.1533746719360352e+00
    phi[0,1]  R182      -4.2741081118583679e-01
    phi[0,1]  R183      -4.1643595695495605e-01
    phi[0,1]  R184      -2.7875313535332680e-02
    phi[0,1]  R185      -2.0998630523681641e+00
    phi[0,1]  R186      -0.545108437538147
    phi[0,1]  R187      -8.1084616482257843e-02
    phi[0,1]  R188      3.1806731224060059e-01
    phi[0,1]  R189      5.6769472360610962e-01
    phi[0,1]  R190      -1.9940903186798096e+00
    phi[0,1]  R191      -1.8269952535629272e+00
    phi[0,1]  R192      -0.849909245967865
    phi[0,1]  R193      3.3973476290702820e-01
    phi[0,1]  R194      4.1951507329940796e-01
    phi[0,1]  R195      -1.2691330909729004e+00
    phi[0,1]  R196      -2.1943695843219757e-01
    phi[0,1]  R197      -3.0348873138427734e+00
    phi[0,1]  R198      1.0143363475799561e+00
    phi[0,1]  R199      4.4909524917602539e-01
    phi[1,0]  R0        -1
    phi[1,0]  R9        1
    phi[1,0]  R10       1
    phi[1,0]  R200      -3.0999999046325684e+00
    phi[1,0]  R201      -3.0999999046325684e+00
    phi[1,0]  R202      -2.2400000095367432e+00
    phi[1,0]  R203      -2.2400000095367432e+00
    phi[1,0]  R204      -3.0999999046325684e+00
    phi[1,0]  R205      -3.0999999046325684e+00
    phi[1,0]  R206      -2.5699999332427979e+00
    phi[1,0]  R207      -2.5699999332427979e+00
    phi[1,0]  R208      -3.0999999046325684e+00
    phi[1,0]  R209      -3.0999999046325684e+00
    phi[1,0]  R210      -2.0899999141693115e+00
    phi[1,0]  R211      -2.0899999141693115e+00
    phi[1,0]  R212      -3.0999999046325684e+00
    phi[1,0]  R213      -3.0999999046325684e+00
    phi[1,0]  R214      4.8072883486747742e-01
    phi[1,0]  R215      9.2672121524810791e-01
    phi[1,0]  R216      5.6869786977767944e-01
    phi[1,0]  R217      1.1835095882415771e+00
    phi[1,0]  R218      6.2269258499145508e-01
    phi[1,0]  R219      8.2096248865127563e-01
    phi[1,0]  R220      7.8266811370849609e-01
    phi[1,0]  R221      -0.921746551990509
    phi[1,0]  R222      -6.5485566854476929e-02
    phi[1,0]  R223      2.6129174232482910e-01
    phi[1,0]  R224      -1.4315564632415771e+00
    phi[1,0]  R225      -6.4470881223678589e-01
    phi[1,0]  R226      -1.8094162940979004e+00
    phi[1,0]  R227      -5.4818183183670044e-01
    phi[1,0]  R228      -2.6221022605895996e+00
    phi[1,0]  R229      -2.6999969482421875e+00
    phi[1,0]  R230      -1.38058602809906
    phi[1,0]  R231      -5.3599423170089722e-01
    phi[1,0]  R232      -7.7736479043960571e-01
    phi[1,0]  R233      -1.4018226861953735e+00
    phi[1,0]  R234      -1.9024895429611206e+00
    phi[1,0]  R235      -1.3222129642963409e-01
    phi[1,0]  R236      -1.1159085035324097e+00
    phi[1,0]  R237      -3.6070916056632996e-01
    phi[1,0]  R238      -3.2501956820487976e-01
    phi[1,0]  R239      -6.9768828153610229e-01
    phi[1,0]  R240      -1.1073216199874878e+00
    phi[1,0]  R241      1.8805004656314850e-01
    phi[1,0]  R242      -2.70127534866333
    phi[1,0]  R243      3.6966949701309204e-01
    phi[1,0]  R244      -1.6612381935119629e+00
    phi[1,0]  R245      -3.3356863260269165e-01
    phi[1,0]  R246      -2.6370186805725098e+00
    phi[1,0]  R247      -6.3232409954071045e-01
    phi[1,0]  R248      -1.5593767166137695e+00
    phi[1,0]  R249      -2.8109071254730225e+00
    phi[1,0]  R250      1.4483878016471863e-01
    phi[1,0]  R251      -1.6609480977058411e-01
    phi[1,0]  R252      -1.8052299022674561e+00
    phi[1,0]  R253      1.1386805772781372e-01
    phi[1,0]  R254      -8.1957006454467773e-01
    phi[1,0]  R255      5.2390500903129578e-02
    phi[1,0]  R256      -1.5301643610000610e+00
    phi[1,0]  R257      -1.7575470209121704e+00
    phi[1,0]  R258      -2.8501877784729004e+00
    phi[1,0]  R259      -1.7915084958076477e-01
    phi[1,0]  R260      3.0303642153739929e-01
    phi[1,0]  R261      -3.3715620040893555e+00
    phi[1,0]  R262      -2.0060298442840576e+00
    phi[1,0]  R263      -2.7238237857818604e+00
    phi[1,0]  R264      -6.8031489849090576e-01
    phi[1,0]  R265      -2.4363405704498291e+00
    phi[1,0]  R266      -2.1277897357940674e+00
    phi[1,0]  R267      -1.1200655698776245e+00
    phi[1,0]  R268      -1.7033793926239014e+00
    phi[1,0]  R269      -1.0668233633041382e+00
    phi[1,0]  R270      -1.9567710161209106e+00
    phi[1,0]  R271      3.6862635612487793e-01
    phi[1,0]  R272      -3.3069546222686768e+00
    phi[1,0]  R273      -5.7969087362289429e-01
    phi[1,0]  R274      -1.7152290344238281e+00
    phi[1,0]  R275      -1.2254465818405151e+00
    phi[1,0]  R276      -1.4950339794158936e+00
    phi[1,0]  R277      -2.0501000881195068e+00
    phi[1,0]  R278      7.9432517290115356e-01
    phi[1,0]  R279      -2.4705444276332855e-01
    phi[1,0]  R280      -1.4063506126403809e+00
    phi[1,0]  R281      -1.3665323257446289e+00
    phi[1,0]  R282      -1.0960564613342285e+00
    phi[1,0]  R283      -3.1379339098930359e-01
    phi[1,0]  R284      -2.0460108295083046e-02
    phi[1,0]  R285      -1.5683376789093018e+00
    phi[1,0]  R286      -3.0081846714019775e+00
    phi[1,0]  R287      -9.8765993118286133e-01
    phi[1,0]  R288      1.5325158834457397e-01
    phi[1,0]  R289      -2.1035239696502686e+00
    phi[1,0]  R290      -3.0840060710906982e+00
    phi[1,0]  R291      -1.5645678341388702e-01
    phi[1,0]  R292      -8.3870381116867065e-02
    phi[1,0]  R293      6.7055028676986694e-01
    phi[1,0]  R294      -6.3917613029479980e-01
    phi[1,0]  R295      -2.1533746719360352e+00
    phi[1,0]  R296      -4.2741081118583679e-01
    phi[1,0]  R297      -4.1643595695495605e-01
    phi[1,0]  R298      -2.7875313535332680e-02
    phi[1,0]  R299      -2.0998630523681641e+00
    phi[1,0]  R300      -0.545108437538147
    phi[1,0]  R301      -8.1084616482257843e-02
    phi[1,0]  R302      3.1806731224060059e-01
    phi[1,0]  R303      5.6769472360610962e-01
    phi[1,0]  R304      -1.9940903186798096e+00
    phi[1,0]  R305      -1.8269952535629272e+00
    phi[1,0]  R306      -0.849909245967865
    phi[1,0]  R307      3.3973476290702820e-01
    phi[1,0]  R308      4.1951507329940796e-01
    phi[1,0]  R309      -1.2691330909729004e+00
    phi[1,0]  R310      -2.1943695843219757e-01
    phi[1,0]  R311      -3.0348873138427734e+00
    phi[1,0]  R312      1.0143363475799561e+00
    phi[1,0]  R313      4.4909524917602539e-01
    phi[1,0]  R314      -1.4610990881919861e-01
    phi[1,0]  R315      8.0248171091079712e-01
    phi[1,0]  R316      4.5802196860313416e-01
    phi[1,0]  R317      -3.4451760351657867e-02
    phi[1,0]  R318      -2.7420103549957275e-01
    phi[1,0]  R319      -4.7015488147735596e-01
    phi[1,0]  R320      5.9532690048217773e-01
    phi[1,0]  R321      1.8066960573196411e-01
    phi[1,0]  R322      9.5075249671936035e-01
    phi[1,0]  R323      1.8501701951026917e-01
    phi[1,0]  R324      -4.2700031399726868e-01
    phi[1,0]  R325      2.3579079657793045e-02
    phi[1,0]  R326      1.4015294611454010e-01
    phi[1,0]  R327      2.2315458953380585e-01
    phi[1,0]  R328      6.8645328283309937e-01
    phi[1,0]  R329      -6.8876773118972778e-01
    phi[1,0]  R330      -1.4252930879592896e+00
    phi[1,0]  R331      -1.4122997522354126e+00
    phi[1,0]  R332      -8.9936751127243042e-01
    phi[1,0]  R333      -5.0741457939147949e-01
    phi[1,0]  R334      -2.5308969020843506e+00
    phi[1,0]  R335      -2.2411015033721924e+00
    phi[1,0]  R336      -1.7581125497817993e+00
    phi[1,0]  R337      -1.0500463247299194e+00
    phi[1,0]  R338      -7.1725195646286011e-01
    phi[1,0]  R339      -2.2032005786895752e+00
    phi[1,0]  R340      -2.1184623241424561e+00
    phi[1,0]  R341      -1.1565734148025513e+00
    phi[1,0]  R342      -1.17945396900177
    phi[1,0]  R343      -1.0087952613830566e+00
    phi[0,3]  R0        1
    phi[0,3]  R1        1
    phi[0,3]  R27       -1
    phi[0,3]  R344      -3.0999999046325684e+00
    phi[0,3]  R345      -3.0999999046325684e+00
    phi[0,3]  R346      -2.2400000095367432e+00
    phi[0,3]  R347      -2.2400000095367432e+00
    phi[0,3]  R348      -3.0999999046325684e+00
    phi[0,3]  R349      -3.0999999046325684e+00
    phi[0,3]  R350      -2.5699999332427979e+00
    phi[0,3]  R351      -2.5699999332427979e+00
    phi[0,3]  R352      -3.0999999046325684e+00
    phi[0,3]  R353      -3.0999999046325684e+00
    phi[0,3]  R354      -2.0899999141693115e+00
    phi[0,3]  R355      -2.0899999141693115e+00
    phi[0,3]  R356      -3.0999999046325684e+00
    phi[0,3]  R357      -3.0999999046325684e+00
    phi[0,3]  R358      -1.4610990881919861e-01
    phi[0,3]  R359      8.0248171091079712e-01
    phi[0,3]  R360      4.5802196860313416e-01
    phi[0,3]  R361      -3.4451760351657867e-02
    phi[0,3]  R362      -2.7420103549957275e-01
    phi[0,3]  R363      -4.7015488147735596e-01
    phi[0,3]  R364      5.9532690048217773e-01
    phi[0,3]  R365      1.8066960573196411e-01
    phi[0,3]  R366      9.5075249671936035e-01
    phi[0,3]  R367      1.8501701951026917e-01
    phi[0,3]  R368      -4.2700031399726868e-01
    phi[0,3]  R369      2.3579079657793045e-02
    phi[0,3]  R370      1.4015294611454010e-01
    phi[0,3]  R371      2.2315458953380585e-01
    phi[0,3]  R372      6.8645328283309937e-01
    phi[0,3]  R373      -6.8876773118972778e-01
    phi[0,3]  R374      -1.4252930879592896e+00
    phi[0,3]  R375      -1.4122997522354126e+00
    phi[0,3]  R376      -8.9936751127243042e-01
    phi[0,3]  R377      -5.0741457939147949e-01
    phi[0,3]  R378      -2.5308969020843506e+00
    phi[0,3]  R379      -2.2411015033721924e+00
    phi[0,3]  R380      -1.7581125497817993e+00
    phi[0,3]  R381      -1.0500463247299194e+00
    phi[0,3]  R382      -7.1725195646286011e-01
    phi[0,3]  R383      -2.2032005786895752e+00
    phi[0,3]  R384      -2.1184623241424561e+00
    phi[0,3]  R385      -1.1565734148025513e+00
    phi[0,3]  R386      -1.17945396900177
    phi[0,3]  R387      -1.0087952613830566e+00
    phi[0,3]  R388      -3.2968717813491821e-01
    phi[0,3]  R389      -1.2211954221129417e-02
    phi[0,3]  R390      -3.4851789474487305e-01
    phi[0,3]  R391      -1.1398665904998779e+00
    phi[0,3]  R392      -7.5816625356674194e-01
    phi[0,3]  R393      -1.5279697179794312e+00
    phi[0,3]  R394      -5.8744627237319946e-01
    phi[0,3]  R395      -1.2614113092422485e+00
    phi[0,3]  R396      -1.1854155063629150e+00
    phi[0,3]  R397      -1.1917587518692017e+00
    phi[0,3]  R398      -1.2978274822235107e+00
    phi[0,3]  R399      -1.4058381319046021e+00
    phi[0,3]  R400      -1.5953806638717651e+00
    phi[0,3]  R401      -1.3632627725601196e+00
    phi[0,3]  R402      -1.2271962165832520e+00
    phi[0,3]  R403      -9.3819248676300049e-01
    phi[0,3]  R404      -1.3784978389739990e+00
    phi[0,3]  R405      -9.8652297258377075e-01
    phi[0,3]  R406      -9.5166873931884766e-01
    phi[0,3]  R407      -1.1387225389480591e+00
    phi[0,3]  R408      -2.0393207073211670e+00
    phi[0,3]  R409      -2.0319168567657471e+00
    phi[0,3]  R410      -2.6202960014343262e+00
    phi[0,3]  R411      -2.3855347633361816e+00
    phi[0,3]  R412      -1.2479273080825806e+00
    phi[0,3]  R413      -1.9184724092483521e+00
    phi[0,3]  R414      -1.0541521310806274e+00
    phi[0,3]  R415      -4.6252837777137756e-01
    phi[0,3]  R416      -1.1056755781173706e+00
    phi[0,3]  R417      -1.0360604524612427e+00
    phi[0,3]  R418      -1.4064215421676636e+00
    phi[0,3]  R419      -1.2700172662734985e+00
    phi[0,3]  R420      2.0566029846668243e-01
    phi[0,3]  R421      -5.2357822656631470e-02
    phi[0,3]  R422      -1.9598065614700317e+00
    phi[0,3]  R423      -9.4095975160598755e-01
    phi[0,3]  R424      -2.1293458342552185e-01
    phi[0,3]  R425      -0.780885636806488
    phi[0,3]  R426      -4.7005674242973328e-01
    phi[0,3]  R427      -6.3670128583908081e-01
    phi[0,3]  R428      -1.0486072301864624e+00
    phi[0,3]  R429      -1.7706523835659027e-01
    phi[0,3]  R430      -2.1285901069641113e+00
    phi[0,3]  R431      -4.2146947979927063e-01
    phi[0,3]  R432      -5.2710980176925659e-02
    phi[0,3]  R433      -1.7450313568115234e+00
    phi[0,3]  R434      -1.2242896556854248e+00
    phi[0,3]  R435      -1.4072865247726440e+00
    phi[0,3]  R436      -5.6963962316513062e-01
    phi[0,3]  R437      -2.33205246925354
    phi[3,0]  R0        -1
    phi[3,0]  R27       1
    phi[3,0]  R28       1
    phi[3,0]  R438      -3.0999999046325684e+00
    phi[3,0]  R439      -3.0999999046325684e+00
    phi[3,0]  R440      -2.2400000095367432e+00
    phi[3,0]  R441      -2.2400000095367432e+00
    phi[3,0]  R442      -3.0999999046325684e+00
    phi[3,0]  R443      -3.0999999046325684e+00
    phi[3,0]  R444      -2.5699999332427979e+00
    phi[3,0]  R445      -2.5699999332427979e+00
    phi[3,0]  R446      -3.0999999046325684e+00
    phi[3,0]  R447      -3.0999999046325684e+00
    phi[3,0]  R448      -2.0899999141693115e+00
    phi[3,0]  R449      -2.0899999141693115e+00
    phi[3,0]  R450      -3.0999999046325684e+00
    phi[3,0]  R451      -3.0999999046325684e+00
    phi[3,0]  R452      -3.2968717813491821e-01
    phi[3,0]  R453      -1.2211954221129417e-02
    phi[3,0]  R454      -3.4851789474487305e-01
    phi[3,0]  R455      -1.1398665904998779e+00
    phi[3,0]  R456      -7.5816625356674194e-01
    phi[3,0]  R457      -1.5279697179794312e+00
    phi[3,0]  R458      -5.8744627237319946e-01
    phi[3,0]  R459      -1.2614113092422485e+00
    phi[3,0]  R460      -1.1854155063629150e+00
    phi[3,0]  R461      -1.1917587518692017e+00
    phi[3,0]  R462      -1.2978274822235107e+00
    phi[3,0]  R463      -1.4058381319046021e+00
    phi[3,0]  R464      -1.5953806638717651e+00
    phi[3,0]  R465      -1.3632627725601196e+00
    phi[3,0]  R466      -1.2271962165832520e+00
    phi[3,0]  R467      -9.3819248676300049e-01
    phi[3,0]  R468      -1.3784978389739990e+00
    phi[3,0]  R469      -9.8652297258377075e-01
    phi[3,0]  R470      -9.5166873931884766e-01
    phi[3,0]  R471      -1.1387225389480591e+00
    phi[3,0]  R472      -2.0393207073211670e+00
    phi[3,0]  R473      -2.0319168567657471e+00
    phi[3,0]  R474      -2.6202960014343262e+00
    phi[3,0]  R475      -2.3855347633361816e+00
    phi[3,0]  R476      -1.2479273080825806e+00
    phi[3,0]  R477      -1.9184724092483521e+00
    phi[3,0]  R478      -1.0541521310806274e+00
    phi[3,0]  R479      -4.6252837777137756e-01
    phi[3,0]  R480      -1.1056755781173706e+00
    phi[3,0]  R481      -1.0360604524612427e+00
    phi[3,0]  R482      -1.4064215421676636e+00
    phi[3,0]  R483      -1.2700172662734985e+00
    phi[3,0]  R484      2.0566029846668243e-01
    phi[3,0]  R485      -5.2357822656631470e-02
    phi[3,0]  R486      -1.9598065614700317e+00
    phi[3,0]  R487      -9.4095975160598755e-01
    phi[3,0]  R488      -2.1293458342552185e-01
    phi[3,0]  R489      -0.780885636806488
    phi[3,0]  R490      -4.7005674242973328e-01
    phi[3,0]  R491      -6.3670128583908081e-01
    phi[3,0]  R492      -1.0486072301864624e+00
    phi[3,0]  R493      -1.7706523835659027e-01
    phi[3,0]  R494      -2.1285901069641113e+00
    phi[3,0]  R495      -4.2146947979927063e-01
    phi[3,0]  R496      -5.2710980176925659e-02
    phi[3,0]  R497      -1.7450313568115234e+00
    phi[3,0]  R498      -1.2242896556854248e+00
    phi[3,0]  R499      -1.4072865247726440e+00
    phi[3,0]  R500      -5.6963962316513062e-01
    phi[3,0]  R501      -2.33205246925354
    phi[3,0]  R502      -1.4610990881919861e-01
    phi[3,0]  R503      8.0248171091079712e-01
    phi[3,0]  R504      4.5802196860313416e-01
    phi[3,0]  R505      -3.4451760351657867e-02
    phi[3,0]  R506      -2.7420103549957275e-01
    phi[3,0]  R507      -4.7015488147735596e-01
    phi[3,0]  R508      5.9532690048217773e-01
    phi[3,0]  R509      1.8066960573196411e-01
    phi[3,0]  R510      9.5075249671936035e-01
    phi[3,0]  R511      1.8501701951026917e-01
    phi[3,0]  R512      -4.2700031399726868e-01
    phi[3,0]  R513      2.3579079657793045e-02
    phi[3,0]  R514      1.4015294611454010e-01
    phi[3,0]  R515      2.2315458953380585e-01
    phi[3,0]  R516      6.8645328283309937e-01
    phi[3,0]  R517      -6.8876773118972778e-01
    phi[3,0]  R518      -1.4252930879592896e+00
    phi[3,0]  R519      -1.4122997522354126e+00
    phi[3,0]  R520      -8.9936751127243042e-01
    phi[3,0]  R521      -5.0741457939147949e-01
    phi[3,0]  R522      -2.5308969020843506e+00
    phi[3,0]  R523      -2.2411015033721924e+00
    phi[3,0]  R524      -1.7581125497817993e+00
    phi[3,0]  R525      -1.0500463247299194e+00
    phi[3,0]  R526      -7.1725195646286011e-01
    phi[3,0]  R527      -2.2032005786895752e+00
    phi[3,0]  R528      -2.1184623241424561e+00
    phi[3,0]  R529      -1.1565734148025513e+00
    phi[3,0]  R530      -1.17945396900177
    phi[3,0]  R531      -1.0087952613830566e+00
    phi[0,4]  R0        1
    phi[0,4]  R1        1
    phi[0,4]  R36       -1
    phi[0,4]  R532      -3.0999999046325684e+00
    phi[0,4]  R533      -3.0999999046325684e+00
    phi[0,4]  R534      -2.2400000095367432e+00
    phi[0,4]  R535      -2.2400000095367432e+00
    phi[0,4]  R536      -3.0999999046325684e+00
    phi[0,4]  R537      -3.0999999046325684e+00
    phi[0,4]  R538      -2.5699999332427979e+00
    phi[0,4]  R539      -2.5699999332427979e+00
    phi[0,4]  R540      -3.0999999046325684e+00
    phi[0,4]  R541      -3.0999999046325684e+00
    phi[0,4]  R542      -2.0899999141693115e+00
    phi[0,4]  R543      -2.0899999141693115e+00
    phi[0,4]  R544      -3.0999999046325684e+00
    phi[0,4]  R545      -3.0999999046325684e+00
    phi[0,4]  R546      -1.4610990881919861e-01
    phi[0,4]  R547      8.0248171091079712e-01
    phi[0,4]  R548      4.5802196860313416e-01
    phi[0,4]  R549      -3.4451760351657867e-02
    phi[0,4]  R550      -2.7420103549957275e-01
    phi[0,4]  R551      -4.7015488147735596e-01
    phi[0,4]  R552      5.9532690048217773e-01
    phi[0,4]  R553      1.8066960573196411e-01
    phi[0,4]  R554      9.5075249671936035e-01
    phi[0,4]  R555      1.8501701951026917e-01
    phi[0,4]  R556      -4.2700031399726868e-01
    phi[0,4]  R557      2.3579079657793045e-02
    phi[0,4]  R558      1.4015294611454010e-01
    phi[0,4]  R559      2.2315458953380585e-01
    phi[0,4]  R560      6.8645328283309937e-01
    phi[0,4]  R561      -6.8876773118972778e-01
    phi[0,4]  R562      -1.4252930879592896e+00
    phi[0,4]  R563      -1.4122997522354126e+00
    phi[0,4]  R564      -8.9936751127243042e-01
    phi[0,4]  R565      -5.0741457939147949e-01
    phi[0,4]  R566      -2.5308969020843506e+00
    phi[0,4]  R567      -2.2411015033721924e+00
    phi[0,4]  R568      -1.7581125497817993e+00
    phi[0,4]  R569      -1.0500463247299194e+00
    phi[0,4]  R570      -7.1725195646286011e-01
    phi[0,4]  R571      -2.2032005786895752e+00
    phi[0,4]  R572      -2.1184623241424561e+00
    phi[0,4]  R573      -1.1565734148025513e+00
    phi[0,4]  R574      -1.17945396900177
    phi[0,4]  R575      -1.0087952613830566e+00
    phi[0,4]  R576      -1.6758900880813599e+00
    phi[0,4]  R577      -2.3637080192565918e-01
    phi[0,4]  R578      -2.0622079074382782e-01
    phi[0,4]  R579      -1.2147315740585327e+00
    phi[0,4]  R580      -3.8451308012008667e-01
    phi[0,4]  R581      -5.1501029729843140e-01
    phi[0,4]  R582      -3.3885970711708069e-01
    phi[0,4]  R583      -3.6920243501663208e-01
    phi[0,4]  R584      -4.9957668781280518e-01
    phi[0,4]  R585      -4.3707442283630371e-01
    phi[0,4]  R586      -7.7058243751525879e-01
    phi[0,4]  R587      -1.6418419778347015e-01
    phi[0,4]  R588      -4.0055418014526367e-01
    phi[0,4]  R589      -4.5955479145050049e-01
    phi[0,4]  R590      -3.0197986960411072e-01
    phi[0,4]  R591      -6.3234555721282959e-01
    phi[0,4]  R592      -4.3850201368331909e-01
    phi[0,4]  R593      -1.6481919586658478e-01
    phi[0,4]  R594      1.8553861975669861e-01
    phi[0,4]  R595      -9.7381758689880371e-01
    phi[0,4]  R596      -4.7962141036987305e-01
    phi[0,4]  R597      -0.418389230966568
    phi[0,4]  R598      -8.0814039707183838e-01
    phi[0,4]  R599      -9.3466180562973022e-01
    phi[0,4]  R600      -5.4314595460891724e-01
    phi[0,4]  R601      -8.1450074911117554e-01
    phi[0,4]  R602      -0.547443151473999
    phi[0,4]  R603      -7.7373385429382324e-01
    phi[0,4]  R604      -6.6778451204299927e-01
    phi[0,4]  R605      -0.730191707611084
    phi[0,4]  R606      -2.7379900217056274e-01
    phi[0,4]  R607      -3.4759387373924255e-01
    phi[0,4]  R608      -4.5646631717681885e-01
    phi[0,4]  R609      -4.08668851852417
    phi[0,4]  R610      -4.7927138209342957e-01
    phi[0,4]  R611      -5.3723651170730591e-01
    phi[0,4]  R612      -1.5418027639389038e+00
    phi[0,4]  R613      -0.942437469959259
    phi[0,4]  R614      -1.0453855991363525e+00
    phi[0,4]  R615      -9.0489536523818970e-01
    phi[4,0]  R0        -1
    phi[4,0]  R36       1
    phi[4,0]  R37       1
    phi[4,0]  R616      -3.0999999046325684e+00
    phi[4,0]  R617      -3.0999999046325684e+00
    phi[4,0]  R618      -2.2400000095367432e+00
    phi[4,0]  R619      -2.2400000095367432e+00
    phi[4,0]  R620      -3.0999999046325684e+00
    phi[4,0]  R621      -3.0999999046325684e+00
    phi[4,0]  R622      -2.5699999332427979e+00
    phi[4,0]  R623      -2.5699999332427979e+00
    phi[4,0]  R624      -3.0999999046325684e+00
    phi[4,0]  R625      -3.0999999046325684e+00
    phi[4,0]  R626      -2.0899999141693115e+00
    phi[4,0]  R627      -2.0899999141693115e+00
    phi[4,0]  R628      -3.0999999046325684e+00
    phi[4,0]  R629      -3.0999999046325684e+00
    phi[4,0]  R630      -1.6758900880813599e+00
    phi[4,0]  R631      -2.3637080192565918e-01
    phi[4,0]  R632      -2.0622079074382782e-01
    phi[4,0]  R633      -1.2147315740585327e+00
    phi[4,0]  R634      -3.8451308012008667e-01
    phi[4,0]  R635      -5.1501029729843140e-01
    phi[4,0]  R636      -3.3885970711708069e-01
    phi[4,0]  R637      -3.6920243501663208e-01
    phi[4,0]  R638      -4.9957668781280518e-01
    phi[4,0]  R639      -4.3707442283630371e-01
    phi[4,0]  R640      -7.7058243751525879e-01
    phi[4,0]  R641      -1.6418419778347015e-01
    phi[4,0]  R642      -4.0055418014526367e-01
    phi[4,0]  R643      -4.5955479145050049e-01
    phi[4,0]  R644      -3.0197986960411072e-01
    phi[4,0]  R645      -6.3234555721282959e-01
    phi[4,0]  R646      -4.3850201368331909e-01
    phi[4,0]  R647      -1.6481919586658478e-01
    phi[4,0]  R648      1.8553861975669861e-01
    phi[4,0]  R649      -9.7381758689880371e-01
    phi[4,0]  R650      -4.7962141036987305e-01
    phi[4,0]  R651      -0.418389230966568
    phi[4,0]  R652      -8.0814039707183838e-01
    phi[4,0]  R653      -9.3466180562973022e-01
    phi[4,0]  R654      -5.4314595460891724e-01
    phi[4,0]  R655      -8.1450074911117554e-01
    phi[4,0]  R656      -0.547443151473999
    phi[4,0]  R657      -7.7373385429382324e-01
    phi[4,0]  R658      -6.6778451204299927e-01
    phi[4,0]  R659      -0.730191707611084
    phi[4,0]  R660      -2.7379900217056274e-01
    phi[4,0]  R661      -3.4759387373924255e-01
    phi[4,0]  R662      -4.5646631717681885e-01
    phi[4,0]  R663      -4.08668851852417
    phi[4,0]  R664      -4.7927138209342957e-01
    phi[4,0]  R665      -5.3723651170730591e-01
    phi[4,0]  R666      -1.5418027639389038e+00
    phi[4,0]  R667      -0.942437469959259
    phi[4,0]  R668      -1.0453855991363525e+00
    phi[4,0]  R669      -9.0489536523818970e-01
    phi[4,0]  R670      -1.4610990881919861e-01
    phi[4,0]  R671      8.0248171091079712e-01
    phi[4,0]  R672      4.5802196860313416e-01
    phi[4,0]  R673      -3.4451760351657867e-02
    phi[4,0]  R674      -2.7420103549957275e-01
    phi[4,0]  R675      -4.7015488147735596e-01
    phi[4,0]  R676      5.9532690048217773e-01
    phi[4,0]  R677      1.8066960573196411e-01
    phi[4,0]  R678      9.5075249671936035e-01
    phi[4,0]  R679      1.8501701951026917e-01
    phi[4,0]  R680      -4.2700031399726868e-01
    phi[4,0]  R681      2.3579079657793045e-02
    phi[4,0]  R682      1.4015294611454010e-01
    phi[4,0]  R683      2.2315458953380585e-01
    phi[4,0]  R684      6.8645328283309937e-01
    phi[4,0]  R685      -6.8876773118972778e-01
    phi[4,0]  R686      -1.4252930879592896e+00
    phi[4,0]  R687      -1.4122997522354126e+00
    phi[4,0]  R688      -8.9936751127243042e-01
    phi[4,0]  R689      -5.0741457939147949e-01
    phi[4,0]  R690      -2.5308969020843506e+00
    phi[4,0]  R691      -2.2411015033721924e+00
    phi[4,0]  R692      -1.7581125497817993e+00
    phi[4,0]  R693      -1.0500463247299194e+00
    phi[4,0]  R694      -7.1725195646286011e-01
    phi[4,0]  R695      -2.2032005786895752e+00
    phi[4,0]  R696      -2.1184623241424561e+00
    phi[4,0]  R697      -1.1565734148025513e+00
    phi[4,0]  R698      -1.17945396900177
    phi[4,0]  R699      -1.0087952613830566e+00
    phi[6,0]  R0        -1
    phi[6,0]  R2        1.5197964678523905e+00
    phi[6,0]  R3        4.5888251338591068e-01
    phi[6,0]  R4        -2.5444511900494429e+00
    phi[6,0]  R5        6.8956310608525584e-02
    phi[6,0]  R6        -0.501981060803316
    phi[6,0]  R7        1.0307052680528703e+00
    phi[6,0]  R8        2.87249774576471
    phi[6,0]  R54       1
    phi[6,0]  R700      -4.6197963724849593e+00
    phi[6,0]  R701      -1.5802034367801778e+00
    phi[6,0]  R702      -2.6988825229226538e+00
    phi[6,0]  R703      -1.7811174961508325e+00
    phi[6,0]  R704      -5.5554871458312549e-01
    phi[6,0]  R705      -5.6444510946820117e+00
    phi[6,0]  R706      -2.6389562438513234e+00
    phi[6,0]  R707      -2.5010436226342723e+00
    phi[6,0]  R708      -2.5980188438292524e+00
    phi[6,0]  R709      -3.6019809654358843e+00
    phi[6,0]  R710      -3.1207051822221819e+00
    phi[6,0]  R711      -1.0592946461164412e+00
    phi[6,0]  R712      -5.9724976503972780e+00
    phi[6,0]  R713      -2.2750215886785830e-01
    phi[6,0]  R714      -1.2655780592779646e+00
    phi[6,0]  R715      -0.45295658185846
    phi[6,0]  R716      -1.1060484804517199e+00
    phi[6,0]  R717      -2.2180228658670231e-01
    phi[6,0]  R718      -1.4001104449895707e+00
    phi[6,0]  R719      -1.7094087837966525e+00
    phi[6,0]  R720      -2.4002961789431920e-01
    phi[6,0]  R721      -2.5298006321537414e-01
    phi[6,0]  R722      -8.5889802057228626e-01
    phi[6,0]  R723      -2.9393207397615195e-01
    phi[6,0]  R724      -4.7546327947759703e-01
    phi[6,0]  R725      -4.8885078040304608e-01
    phi[6,0]  R726      -5.0787004732950114e-01
    phi[6,0]  R727      -5.4810080316461685e-01
    phi[6,0]  R728      -5.4984885600190370e-01
    phi[6,0]  R729      -5.7607635859454243e-01
    phi[6,0]  R730      -5.8981053313359488e-01
    phi[6,0]  R731      -6.1199130301507509e-01
    phi[6,0]  R732      -1.3381947787674511e+00
    phi[6,0]  R733      -6.8392456318495354e-01
    phi[6,0]  R734      -6.9297019254653014e-01
    phi[6,0]  R735      -7.3618972752608380e-01
    phi[6,0]  R736      -8.7493864133066857e-01
    phi[6,0]  R737      -9.2441569216069785e-01
    phi[6,0]  R738      -9.2965966002052158e-01
    phi[6,0]  R739      -9.3016636392563634e-01
    phi[6,0]  R740      -1.1008095778054692e+00
    phi[6,0]  R741      -1.1061298220618592e+00
    phi[6,0]  R742      -1.1122766396496482e+00
    phi[6,0]  R743      -1.3290084053770301e+00
    phi[1,2]  R9        1
    phi[1,2]  R10       1
    phi[1,2]  R18       -1
    phi[1,2]  R744      -3.0999999046325684e+00
    phi[1,2]  R745      -3.0999999046325684e+00
    phi[1,2]  R746      -2.2400000095367432e+00
    phi[1,2]  R747      -2.2400000095367432e+00
    phi[1,2]  R748      -3.0999999046325684e+00
    phi[1,2]  R749      -3.0999999046325684e+00
    phi[1,2]  R750      -2.5699999332427979e+00
    phi[1,2]  R751      -2.5699999332427979e+00
    phi[1,2]  R752      -3.0999999046325684e+00
    phi[1,2]  R753      -3.0999999046325684e+00
    phi[1,2]  R754      -2.0899999141693115e+00
    phi[1,2]  R755      -2.0899999141693115e+00
    phi[1,2]  R756      -3.0999999046325684e+00
    phi[1,2]  R757      -3.0999999046325684e+00
    phi[1,2]  R758      4.8072883486747742e-01
    phi[1,2]  R759      9.2672121524810791e-01
    phi[1,2]  R760      5.6869786977767944e-01
    phi[1,2]  R761      1.1835095882415771e+00
    phi[1,2]  R762      6.2269258499145508e-01
    phi[1,2]  R763      8.2096248865127563e-01
    phi[1,2]  R764      7.8266811370849609e-01
    phi[1,2]  R765      -0.921746551990509
    phi[1,2]  R766      -6.5485566854476929e-02
    phi[1,2]  R767      2.6129174232482910e-01
    phi[1,2]  R768      -1.4315564632415771e+00
    phi[1,2]  R769      -6.4470881223678589e-01
    phi[1,2]  R770      -1.8094162940979004e+00
    phi[1,2]  R771      -5.4818183183670044e-01
    phi[1,2]  R772      -2.6221022605895996e+00
    phi[1,2]  R773      -2.6999969482421875e+00
    phi[1,2]  R774      -1.38058602809906
    phi[1,2]  R775      -5.3599423170089722e-01
    phi[1,2]  R776      -7.7736479043960571e-01
    phi[1,2]  R777      -1.4018226861953735e+00
    phi[1,2]  R778      -1.9024895429611206e+00
    phi[1,2]  R779      -1.3222129642963409e-01
    phi[1,2]  R780      -1.1159085035324097e+00
    phi[1,2]  R781      -3.6070916056632996e-01
    phi[1,2]  R782      -3.2501956820487976e-01
    phi[1,2]  R783      -6.9768828153610229e-01
    phi[1,2]  R784      -1.1073216199874878e+00
    phi[1,2]  R785      1.8805004656314850e-01
    phi[1,2]  R786      -2.70127534866333
    phi[1,2]  R787      3.6966949701309204e-01
    phi[1,2]  R788      -1.6612381935119629e+00
    phi[1,2]  R789      -3.3356863260269165e-01
    phi[1,2]  R790      -2.6370186805725098e+00
    phi[1,2]  R791      -6.3232409954071045e-01
    phi[1,2]  R792      -1.5593767166137695e+00
    phi[1,2]  R793      -2.8109071254730225e+00
    phi[1,2]  R794      1.4483878016471863e-01
    phi[1,2]  R795      -1.6609480977058411e-01
    phi[1,2]  R796      -1.8052299022674561e+00
    phi[1,2]  R797      1.1386805772781372e-01
    phi[1,2]  R798      -8.1957006454467773e-01
    phi[1,2]  R799      5.2390500903129578e-02
    phi[1,2]  R800      -1.5301643610000610e+00
    phi[1,2]  R801      -1.7575470209121704e+00
    phi[1,2]  R802      -2.8501877784729004e+00
    phi[1,2]  R803      -1.7915084958076477e-01
    phi[1,2]  R804      3.0303642153739929e-01
    phi[1,2]  R805      -3.3715620040893555e+00
    phi[1,2]  R806      -2.0060298442840576e+00
    phi[1,2]  R807      -2.7238237857818604e+00
    phi[1,2]  R808      -6.8031489849090576e-01
    phi[1,2]  R809      -2.4363405704498291e+00
    phi[1,2]  R810      -2.1277897357940674e+00
    phi[1,2]  R811      -1.1200655698776245e+00
    phi[1,2]  R812      -1.7033793926239014e+00
    phi[1,2]  R813      -1.0668233633041382e+00
    phi[1,2]  R814      -1.9567710161209106e+00
    phi[1,2]  R815      3.6862635612487793e-01
    phi[1,2]  R816      -3.3069546222686768e+00
    phi[1,2]  R817      -5.7969087362289429e-01
    phi[1,2]  R818      -1.7152290344238281e+00
    phi[1,2]  R819      -1.2254465818405151e+00
    phi[1,2]  R820      -1.4950339794158936e+00
    phi[1,2]  R821      -2.0501000881195068e+00
    phi[1,2]  R822      7.9432517290115356e-01
    phi[1,2]  R823      -2.4705444276332855e-01
    phi[1,2]  R824      -1.4063506126403809e+00
    phi[1,2]  R825      -1.3665323257446289e+00
    phi[1,2]  R826      -1.0960564613342285e+00
    phi[1,2]  R827      -3.1379339098930359e-01
    phi[1,2]  R828      -2.0460108295083046e-02
    phi[1,2]  R829      -1.5683376789093018e+00
    phi[1,2]  R830      -3.0081846714019775e+00
    phi[1,2]  R831      -9.8765993118286133e-01
    phi[1,2]  R832      1.5325158834457397e-01
    phi[1,2]  R833      -2.1035239696502686e+00
    phi[1,2]  R834      -3.0840060710906982e+00
    phi[1,2]  R835      -1.5645678341388702e-01
    phi[1,2]  R836      -8.3870381116867065e-02
    phi[1,2]  R837      6.7055028676986694e-01
    phi[1,2]  R838      -6.3917613029479980e-01
    phi[1,2]  R839      -2.1533746719360352e+00
    phi[1,2]  R840      -4.2741081118583679e-01
    phi[1,2]  R841      -4.1643595695495605e-01
    phi[1,2]  R842      -2.7875313535332680e-02
    phi[1,2]  R843      -2.0998630523681641e+00
    phi[1,2]  R844      -0.545108437538147
    phi[1,2]  R845      -8.1084616482257843e-02
    phi[1,2]  R846      3.1806731224060059e-01
    phi[1,2]  R847      5.6769472360610962e-01
    phi[1,2]  R848      -1.9940903186798096e+00
    phi[1,2]  R849      -1.8269952535629272e+00
    phi[1,2]  R850      -0.849909245967865
    phi[1,2]  R851      3.3973476290702820e-01
    phi[1,2]  R852      4.1951507329940796e-01
    phi[1,2]  R853      -1.2691330909729004e+00
    phi[1,2]  R854      -2.1943695843219757e-01
    phi[1,2]  R855      -3.0348873138427734e+00
    phi[1,2]  R856      1.0143363475799561e+00
    phi[1,2]  R857      4.4909524917602539e-01
    phi[1,2]  R858      -1.4811532199382782e-01
    phi[1,2]  R859      -1.4165000617504120e-01
    phi[1,2]  R860      1.4599986076354980e+00
    phi[1,2]  R861      -1.5486198663711548e+00
    phi[1,2]  R862      1.1294338703155518e+00
    phi[1,2]  R863      1.8009097576141357e+00
    phi[1,2]  R864      2.2220847606658936e+00
    phi[1,2]  R865      0.531309962272644
    phi[1,2]  R866      4.3408146500587463e-01
    phi[1,2]  R867      -1.5024748444557190e-01
    phi[1,2]  R868      -1.7340061664581299e+00
    phi[1,2]  R869      -6.2100455164909363e-02
    phi[1,2]  R870      -1.6835961341857910e+00
    phi[1,2]  R871      -6.1145722866058350e-01
    phi[1,2]  R872      -6.5656119585037231e-01
    phi[1,2]  R873      -7.4085032939910889e-01
    phi[1,2]  R874      -0.0375056266784668
    phi[1,2]  R875      -1.6793100833892822e+00
    phi[1,2]  R876      -3.7340819835662842e-01
    phi[1,2]  R877      -5.9820175170898438e-01
    phi[2,1]  R9        -1
    phi[2,1]  R18       1
    phi[2,1]  R19       1
    phi[2,1]  R878      -3.0999999046325684e+00
    phi[2,1]  R879      -3.0999999046325684e+00
    phi[2,1]  R880      -2.2400000095367432e+00
    phi[2,1]  R881      -2.2400000095367432e+00
    phi[2,1]  R882      -3.0999999046325684e+00
    phi[2,1]  R883      -3.0999999046325684e+00
    phi[2,1]  R884      -2.5699999332427979e+00
    phi[2,1]  R885      -2.5699999332427979e+00
    phi[2,1]  R886      -3.0999999046325684e+00
    phi[2,1]  R887      -3.0999999046325684e+00
    phi[2,1]  R888      -2.0899999141693115e+00
    phi[2,1]  R889      -2.0899999141693115e+00
    phi[2,1]  R890      -3.0999999046325684e+00
    phi[2,1]  R891      -3.0999999046325684e+00
    phi[2,1]  R892      -1.4811532199382782e-01
    phi[2,1]  R893      -1.4165000617504120e-01
    phi[2,1]  R894      1.4599986076354980e+00
    phi[2,1]  R895      -1.5486198663711548e+00
    phi[2,1]  R896      1.1294338703155518e+00
    phi[2,1]  R897      1.8009097576141357e+00
    phi[2,1]  R898      2.2220847606658936e+00
    phi[2,1]  R899      0.531309962272644
    phi[2,1]  R900      4.3408146500587463e-01
    phi[2,1]  R901      -1.5024748444557190e-01
    phi[2,1]  R902      -1.7340061664581299e+00
    phi[2,1]  R903      -6.2100455164909363e-02
    phi[2,1]  R904      -1.6835961341857910e+00
    phi[2,1]  R905      -6.1145722866058350e-01
    phi[2,1]  R906      -6.5656119585037231e-01
    phi[2,1]  R907      -7.4085032939910889e-01
    phi[2,1]  R908      -0.0375056266784668
    phi[2,1]  R909      -1.6793100833892822e+00
    phi[2,1]  R910      -3.7340819835662842e-01
    phi[2,1]  R911      -5.9820175170898438e-01
    phi[2,1]  R912      4.8072883486747742e-01
    phi[2,1]  R913      9.2672121524810791e-01
    phi[2,1]  R914      5.6869786977767944e-01
    phi[2,1]  R915      1.1835095882415771e+00
    phi[2,1]  R916      6.2269258499145508e-01
    phi[2,1]  R917      8.2096248865127563e-01
    phi[2,1]  R918      7.8266811370849609e-01
    phi[2,1]  R919      -0.921746551990509
    phi[2,1]  R920      -6.5485566854476929e-02
    phi[2,1]  R921      2.6129174232482910e-01
    phi[2,1]  R922      -1.4315564632415771e+00
    phi[2,1]  R923      -6.4470881223678589e-01
    phi[2,1]  R924      -1.8094162940979004e+00
    phi[2,1]  R925      -5.4818183183670044e-01
    phi[2,1]  R926      -2.6221022605895996e+00
    phi[2,1]  R927      -2.6999969482421875e+00
    phi[2,1]  R928      -1.38058602809906
    phi[2,1]  R929      -5.3599423170089722e-01
    phi[2,1]  R930      -7.7736479043960571e-01
    phi[2,1]  R931      -1.4018226861953735e+00
    phi[2,1]  R932      -1.9024895429611206e+00
    phi[2,1]  R933      -1.3222129642963409e-01
    phi[2,1]  R934      -1.1159085035324097e+00
    phi[2,1]  R935      -3.6070916056632996e-01
    phi[2,1]  R936      -3.2501956820487976e-01
    phi[2,1]  R937      -6.9768828153610229e-01
    phi[2,1]  R938      -1.1073216199874878e+00
    phi[2,1]  R939      1.8805004656314850e-01
    phi[2,1]  R940      -2.70127534866333
    phi[2,1]  R941      3.6966949701309204e-01
    phi[2,1]  R942      -1.6612381935119629e+00
    phi[2,1]  R943      -3.3356863260269165e-01
    phi[2,1]  R944      -2.6370186805725098e+00
    phi[2,1]  R945      -6.3232409954071045e-01
    phi[2,1]  R946      -1.5593767166137695e+00
    phi[2,1]  R947      -2.8109071254730225e+00
    phi[2,1]  R948      1.4483878016471863e-01
    phi[2,1]  R949      -1.6609480977058411e-01
    phi[2,1]  R950      -1.8052299022674561e+00
    phi[2,1]  R951      1.1386805772781372e-01
    phi[2,1]  R952      -8.1957006454467773e-01
    phi[2,1]  R953      5.2390500903129578e-02
    phi[2,1]  R954      -1.5301643610000610e+00
    phi[2,1]  R955      -1.7575470209121704e+00
    phi[2,1]  R956      -2.8501877784729004e+00
    phi[2,1]  R957      -1.7915084958076477e-01
    phi[2,1]  R958      3.0303642153739929e-01
    phi[2,1]  R959      -3.3715620040893555e+00
    phi[2,1]  R960      -2.0060298442840576e+00
    phi[2,1]  R961      -2.7238237857818604e+00
    phi[2,1]  R962      -6.8031489849090576e-01
    phi[2,1]  R963      -2.4363405704498291e+00
    phi[2,1]  R964      -2.1277897357940674e+00
    phi[2,1]  R965      -1.1200655698776245e+00
    phi[2,1]  R966      -1.7033793926239014e+00
    phi[2,1]  R967      -1.0668233633041382e+00
    phi[2,1]  R968      -1.9567710161209106e+00
    phi[2,1]  R969      3.6862635612487793e-01
    phi[2,1]  R970      -3.3069546222686768e+00
    phi[2,1]  R971      -5.7969087362289429e-01
    phi[2,1]  R972      -1.7152290344238281e+00
    phi[2,1]  R973      -1.2254465818405151e+00
    phi[2,1]  R974      -1.4950339794158936e+00
    phi[2,1]  R975      -2.0501000881195068e+00
    phi[2,1]  R976      7.9432517290115356e-01
    phi[2,1]  R977      -2.4705444276332855e-01
    phi[2,1]  R978      -1.4063506126403809e+00
    phi[2,1]  R979      -1.3665323257446289e+00
    phi[2,1]  R980      -1.0960564613342285e+00
    phi[2,1]  R981      -3.1379339098930359e-01
    phi[2,1]  R982      -2.0460108295083046e-02
    phi[2,1]  R983      -1.5683376789093018e+00
    phi[2,1]  R984      -3.0081846714019775e+00
    phi[2,1]  R985      -9.8765993118286133e-01
    phi[2,1]  R986      1.5325158834457397e-01
    phi[2,1]  R987      -2.1035239696502686e+00
    phi[2,1]  R988      -3.0840060710906982e+00
    phi[2,1]  R989      -1.5645678341388702e-01
    phi[2,1]  R990      -8.3870381116867065e-02
    phi[2,1]  R991      6.7055028676986694e-01
    phi[2,1]  R992      -6.3917613029479980e-01
    phi[2,1]  R993      -2.1533746719360352e+00
    phi[2,1]  R994      -4.2741081118583679e-01
    phi[2,1]  R995      -4.1643595695495605e-01
    phi[2,1]  R996      -2.7875313535332680e-02
    phi[2,1]  R997      -2.0998630523681641e+00
    phi[2,1]  R998      -0.545108437538147
    phi[2,1]  R999      -8.1084616482257843e-02
    phi[2,1]  R1000     3.1806731224060059e-01
    phi[2,1]  R1001     5.6769472360610962e-01
    phi[2,1]  R1002     -1.9940903186798096e+00
    phi[2,1]  R1003     -1.8269952535629272e+00
    phi[2,1]  R1004     -0.849909245967865
    phi[2,1]  R1005     3.3973476290702820e-01
    phi[2,1]  R1006     4.1951507329940796e-01
    phi[2,1]  R1007     -1.2691330909729004e+00
    phi[2,1]  R1008     -2.1943695843219757e-01
    phi[2,1]  R1009     -3.0348873138427734e+00
    phi[2,1]  R1010     1.0143363475799561e+00
    phi[2,1]  R1011     4.4909524917602539e-01
    phi[1,3]  R9        1
    phi[1,3]  R10       1
    phi[1,3]  R27       -1
    phi[1,3]  R1012     -3.0999999046325684e+00
    phi[1,3]  R1013     -3.0999999046325684e+00
    phi[1,3]  R1014     -2.2400000095367432e+00
    phi[1,3]  R1015     -2.2400000095367432e+00
    phi[1,3]  R1016     -3.0999999046325684e+00
    phi[1,3]  R1017     -3.0999999046325684e+00
    phi[1,3]  R1018     -2.5699999332427979e+00
    phi[1,3]  R1019     -2.5699999332427979e+00
    phi[1,3]  R1020     -3.0999999046325684e+00
    phi[1,3]  R1021     -3.0999999046325684e+00
    phi[1,3]  R1022     -2.0899999141693115e+00
    phi[1,3]  R1023     -2.0899999141693115e+00
    phi[1,3]  R1024     -3.0999999046325684e+00
    phi[1,3]  R1025     -3.0999999046325684e+00
    phi[1,3]  R1026     4.8072883486747742e-01
    phi[1,3]  R1027     9.2672121524810791e-01
    phi[1,3]  R1028     5.6869786977767944e-01
    phi[1,3]  R1029     1.1835095882415771e+00
    phi[1,3]  R1030     6.2269258499145508e-01
    phi[1,3]  R1031     8.2096248865127563e-01
    phi[1,3]  R1032     7.8266811370849609e-01
    phi[1,3]  R1033     -0.921746551990509
    phi[1,3]  R1034     -6.5485566854476929e-02
    phi[1,3]  R1035     2.6129174232482910e-01
    phi[1,3]  R1036     -1.4315564632415771e+00
    phi[1,3]  R1037     -6.4470881223678589e-01
    phi[1,3]  R1038     -1.8094162940979004e+00
    phi[1,3]  R1039     -5.4818183183670044e-01
    phi[1,3]  R1040     -2.6221022605895996e+00
    phi[1,3]  R1041     -2.6999969482421875e+00
    phi[1,3]  R1042     -1.38058602809906
    phi[1,3]  R1043     -5.3599423170089722e-01
    phi[1,3]  R1044     -7.7736479043960571e-01
    phi[1,3]  R1045     -1.4018226861953735e+00
    phi[1,3]  R1046     -1.9024895429611206e+00
    phi[1,3]  R1047     -1.3222129642963409e-01
    phi[1,3]  R1048     -1.1159085035324097e+00
    phi[1,3]  R1049     -3.6070916056632996e-01
    phi[1,3]  R1050     -3.2501956820487976e-01
    phi[1,3]  R1051     -6.9768828153610229e-01
    phi[1,3]  R1052     -1.1073216199874878e+00
    phi[1,3]  R1053     1.8805004656314850e-01
    phi[1,3]  R1054     -2.70127534866333
    phi[1,3]  R1055     3.6966949701309204e-01
    phi[1,3]  R1056     -1.6612381935119629e+00
    phi[1,3]  R1057     -3.3356863260269165e-01
    phi[1,3]  R1058     -2.6370186805725098e+00
    phi[1,3]  R1059     -6.3232409954071045e-01
    phi[1,3]  R1060     -1.5593767166137695e+00
    phi[1,3]  R1061     -2.8109071254730225e+00
    phi[1,3]  R1062     1.4483878016471863e-01
    phi[1,3]  R1063     -1.6609480977058411e-01
    phi[1,3]  R1064     -1.8052299022674561e+00
    phi[1,3]  R1065     1.1386805772781372e-01
    phi[1,3]  R1066     -8.1957006454467773e-01
    phi[1,3]  R1067     5.2390500903129578e-02
    phi[1,3]  R1068     -1.5301643610000610e+00
    phi[1,3]  R1069     -1.7575470209121704e+00
    phi[1,3]  R1070     -2.8501877784729004e+00
    phi[1,3]  R1071     -1.7915084958076477e-01
    phi[1,3]  R1072     3.0303642153739929e-01
    phi[1,3]  R1073     -3.3715620040893555e+00
    phi[1,3]  R1074     -2.0060298442840576e+00
    phi[1,3]  R1075     -2.7238237857818604e+00
    phi[1,3]  R1076     -6.8031489849090576e-01
    phi[1,3]  R1077     -2.4363405704498291e+00
    phi[1,3]  R1078     -2.1277897357940674e+00
    phi[1,3]  R1079     -1.1200655698776245e+00
    phi[1,3]  R1080     -1.7033793926239014e+00
    phi[1,3]  R1081     -1.0668233633041382e+00
    phi[1,3]  R1082     -1.9567710161209106e+00
    phi[1,3]  R1083     3.6862635612487793e-01
    phi[1,3]  R1084     -3.3069546222686768e+00
    phi[1,3]  R1085     -5.7969087362289429e-01
    phi[1,3]  R1086     -1.7152290344238281e+00
    phi[1,3]  R1087     -1.2254465818405151e+00
    phi[1,3]  R1088     -1.4950339794158936e+00
    phi[1,3]  R1089     -2.0501000881195068e+00
    phi[1,3]  R1090     7.9432517290115356e-01
    phi[1,3]  R1091     -2.4705444276332855e-01
    phi[1,3]  R1092     -1.4063506126403809e+00
    phi[1,3]  R1093     -1.3665323257446289e+00
    phi[1,3]  R1094     -1.0960564613342285e+00
    phi[1,3]  R1095     -3.1379339098930359e-01
    phi[1,3]  R1096     -2.0460108295083046e-02
    phi[1,3]  R1097     -1.5683376789093018e+00
    phi[1,3]  R1098     -3.0081846714019775e+00
    phi[1,3]  R1099     -9.8765993118286133e-01
    phi[1,3]  R1100     1.5325158834457397e-01
    phi[1,3]  R1101     -2.1035239696502686e+00
    phi[1,3]  R1102     -3.0840060710906982e+00
    phi[1,3]  R1103     -1.5645678341388702e-01
    phi[1,3]  R1104     -8.3870381116867065e-02
    phi[1,3]  R1105     6.7055028676986694e-01
    phi[1,3]  R1106     -6.3917613029479980e-01
    phi[1,3]  R1107     -2.1533746719360352e+00
    phi[1,3]  R1108     -4.2741081118583679e-01
    phi[1,3]  R1109     -4.1643595695495605e-01
    phi[1,3]  R1110     -2.7875313535332680e-02
    phi[1,3]  R1111     -2.0998630523681641e+00
    phi[1,3]  R1112     -0.545108437538147
    phi[1,3]  R1113     -8.1084616482257843e-02
    phi[1,3]  R1114     3.1806731224060059e-01
    phi[1,3]  R1115     5.6769472360610962e-01
    phi[1,3]  R1116     -1.9940903186798096e+00
    phi[1,3]  R1117     -1.8269952535629272e+00
    phi[1,3]  R1118     -0.849909245967865
    phi[1,3]  R1119     3.3973476290702820e-01
    phi[1,3]  R1120     4.1951507329940796e-01
    phi[1,3]  R1121     -1.2691330909729004e+00
    phi[1,3]  R1122     -2.1943695843219757e-01
    phi[1,3]  R1123     -3.0348873138427734e+00
    phi[1,3]  R1124     1.0143363475799561e+00
    phi[1,3]  R1125     4.4909524917602539e-01
    phi[1,3]  R1126     -3.2968717813491821e-01
    phi[1,3]  R1127     -1.2211954221129417e-02
    phi[1,3]  R1128     -3.4851789474487305e-01
    phi[1,3]  R1129     -1.1398665904998779e+00
    phi[1,3]  R1130     -7.5816625356674194e-01
    phi[1,3]  R1131     -1.5279697179794312e+00
    phi[1,3]  R1132     -5.8744627237319946e-01
    phi[1,3]  R1133     -1.2614113092422485e+00
    phi[1,3]  R1134     -1.1854155063629150e+00
    phi[1,3]  R1135     -1.1917587518692017e+00
    phi[1,3]  R1136     -1.2978274822235107e+00
    phi[1,3]  R1137     -1.4058381319046021e+00
    phi[1,3]  R1138     -1.5953806638717651e+00
    phi[1,3]  R1139     -1.3632627725601196e+00
    phi[1,3]  R1140     -1.2271962165832520e+00
    phi[1,3]  R1141     -9.3819248676300049e-01
    phi[1,3]  R1142     -1.3784978389739990e+00
    phi[1,3]  R1143     -9.8652297258377075e-01
    phi[1,3]  R1144     -9.5166873931884766e-01
    phi[1,3]  R1145     -1.1387225389480591e+00
    phi[1,3]  R1146     -2.0393207073211670e+00
    phi[1,3]  R1147     -2.0319168567657471e+00
    phi[1,3]  R1148     -2.6202960014343262e+00
    phi[1,3]  R1149     -2.3855347633361816e+00
    phi[1,3]  R1150     -1.2479273080825806e+00
    phi[1,3]  R1151     -1.9184724092483521e+00
    phi[1,3]  R1152     -1.0541521310806274e+00
    phi[1,3]  R1153     -4.6252837777137756e-01
    phi[1,3]  R1154     -1.1056755781173706e+00
    phi[1,3]  R1155     -1.0360604524612427e+00
    phi[1,3]  R1156     -1.4064215421676636e+00
    phi[1,3]  R1157     -1.2700172662734985e+00
    phi[1,3]  R1158     2.0566029846668243e-01
    phi[1,3]  R1159     -5.2357822656631470e-02
    phi[1,3]  R1160     -1.9598065614700317e+00
    phi[1,3]  R1161     -9.4095975160598755e-01
    phi[1,3]  R1162     -2.1293458342552185e-01
    phi[1,3]  R1163     -0.780885636806488
    phi[1,3]  R1164     -4.7005674242973328e-01
    phi[1,3]  R1165     -6.3670128583908081e-01
    phi[1,3]  R1166     -1.0486072301864624e+00
    phi[1,3]  R1167     -1.7706523835659027e-01
    phi[1,3]  R1168     -2.1285901069641113e+00
    phi[1,3]  R1169     -4.2146947979927063e-01
    phi[1,3]  R1170     -5.2710980176925659e-02
    phi[1,3]  R1171     -1.7450313568115234e+00
    phi[1,3]  R1172     -1.2242896556854248e+00
    phi[1,3]  R1173     -1.4072865247726440e+00
    phi[1,3]  R1174     -5.6963962316513062e-01
    phi[1,3]  R1175     -2.33205246925354
    phi[3,1]  R9        -1
    phi[3,1]  R27       1
    phi[3,1]  R28       1
    phi[3,1]  R1176     -3.0999999046325684e+00
    phi[3,1]  R1177     -3.0999999046325684e+00
    phi[3,1]  R1178     -2.2400000095367432e+00
    phi[3,1]  R1179     -2.2400000095367432e+00
    phi[3,1]  R1180     -3.0999999046325684e+00
    phi[3,1]  R1181     -3.0999999046325684e+00
    phi[3,1]  R1182     -2.5699999332427979e+00
    phi[3,1]  R1183     -2.5699999332427979e+00
    phi[3,1]  R1184     -3.0999999046325684e+00
    phi[3,1]  R1185     -3.0999999046325684e+00
    phi[3,1]  R1186     -2.0899999141693115e+00
    phi[3,1]  R1187     -2.0899999141693115e+00
    phi[3,1]  R1188     -3.0999999046325684e+00
    phi[3,1]  R1189     -3.0999999046325684e+00
    phi[3,1]  R1190     -3.2968717813491821e-01
    phi[3,1]  R1191     -1.2211954221129417e-02
    phi[3,1]  R1192     -3.4851789474487305e-01
    phi[3,1]  R1193     -1.1398665904998779e+00
    phi[3,1]  R1194     -7.5816625356674194e-01
    phi[3,1]  R1195     -1.5279697179794312e+00
    phi[3,1]  R1196     -5.8744627237319946e-01
    phi[3,1]  R1197     -1.2614113092422485e+00
    phi[3,1]  R1198     -1.1854155063629150e+00
    phi[3,1]  R1199     -1.1917587518692017e+00
    phi[3,1]  R1200     -1.2978274822235107e+00
    phi[3,1]  R1201     -1.4058381319046021e+00
    phi[3,1]  R1202     -1.5953806638717651e+00
    phi[3,1]  R1203     -1.3632627725601196e+00
    phi[3,1]  R1204     -1.2271962165832520e+00
    phi[3,1]  R1205     -9.3819248676300049e-01
    phi[3,1]  R1206     -1.3784978389739990e+00
    phi[3,1]  R1207     -9.8652297258377075e-01
    phi[3,1]  R1208     -9.5166873931884766e-01
    phi[3,1]  R1209     -1.1387225389480591e+00
    phi[3,1]  R1210     -2.0393207073211670e+00
    phi[3,1]  R1211     -2.0319168567657471e+00
    phi[3,1]  R1212     -2.6202960014343262e+00
    phi[3,1]  R1213     -2.3855347633361816e+00
    phi[3,1]  R1214     -1.2479273080825806e+00
    phi[3,1]  R1215     -1.9184724092483521e+00
    phi[3,1]  R1216     -1.0541521310806274e+00
    phi[3,1]  R1217     -4.6252837777137756e-01
    phi[3,1]  R1218     -1.1056755781173706e+00
    phi[3,1]  R1219     -1.0360604524612427e+00
    phi[3,1]  R1220     -1.4064215421676636e+00
    phi[3,1]  R1221     -1.2700172662734985e+00
    phi[3,1]  R1222     2.0566029846668243e-01
    phi[3,1]  R1223     -5.2357822656631470e-02
    phi[3,1]  R1224     -1.9598065614700317e+00
    phi[3,1]  R1225     -9.4095975160598755e-01
    phi[3,1]  R1226     -2.1293458342552185e-01
    phi[3,1]  R1227     -0.780885636806488
    phi[3,1]  R1228     -4.7005674242973328e-01
    phi[3,1]  R1229     -6.3670128583908081e-01
    phi[3,1]  R1230     -1.0486072301864624e+00
    phi[3,1]  R1231     -1.7706523835659027e-01
    phi[3,1]  R1232     -2.1285901069641113e+00
    phi[3,1]  R1233     -4.2146947979927063e-01
    phi[3,1]  R1234     -5.2710980176925659e-02
    phi[3,1]  R1235     -1.7450313568115234e+00
    phi[3,1]  R1236     -1.2242896556854248e+00
    phi[3,1]  R1237     -1.4072865247726440e+00
    phi[3,1]  R1238     -5.6963962316513062e-01
    phi[3,1]  R1239     -2.33205246925354
    phi[3,1]  R1240     4.8072883486747742e-01
    phi[3,1]  R1241     9.2672121524810791e-01
    phi[3,1]  R1242     5.6869786977767944e-01
    phi[3,1]  R1243     1.1835095882415771e+00
    phi[3,1]  R1244     6.2269258499145508e-01
    phi[3,1]  R1245     8.2096248865127563e-01
    phi[3,1]  R1246     7.8266811370849609e-01
    phi[3,1]  R1247     -0.921746551990509
    phi[3,1]  R1248     -6.5485566854476929e-02
    phi[3,1]  R1249     2.6129174232482910e-01
    phi[3,1]  R1250     -1.4315564632415771e+00
    phi[3,1]  R1251     -6.4470881223678589e-01
    phi[3,1]  R1252     -1.8094162940979004e+00
    phi[3,1]  R1253     -5.4818183183670044e-01
    phi[3,1]  R1254     -2.6221022605895996e+00
    phi[3,1]  R1255     -2.6999969482421875e+00
    phi[3,1]  R1256     -1.38058602809906
    phi[3,1]  R1257     -5.3599423170089722e-01
    phi[3,1]  R1258     -7.7736479043960571e-01
    phi[3,1]  R1259     -1.4018226861953735e+00
    phi[3,1]  R1260     -1.9024895429611206e+00
    phi[3,1]  R1261     -1.3222129642963409e-01
    phi[3,1]  R1262     -1.1159085035324097e+00
    phi[3,1]  R1263     -3.6070916056632996e-01
    phi[3,1]  R1264     -3.2501956820487976e-01
    phi[3,1]  R1265     -6.9768828153610229e-01
    phi[3,1]  R1266     -1.1073216199874878e+00
    phi[3,1]  R1267     1.8805004656314850e-01
    phi[3,1]  R1268     -2.70127534866333
    phi[3,1]  R1269     3.6966949701309204e-01
    phi[3,1]  R1270     -1.6612381935119629e+00
    phi[3,1]  R1271     -3.3356863260269165e-01
    phi[3,1]  R1272     -2.6370186805725098e+00
    phi[3,1]  R1273     -6.3232409954071045e-01
    phi[3,1]  R1274     -1.5593767166137695e+00
    phi[3,1]  R1275     -2.8109071254730225e+00
    phi[3,1]  R1276     1.4483878016471863e-01
    phi[3,1]  R1277     -1.6609480977058411e-01
    phi[3,1]  R1278     -1.8052299022674561e+00
    phi[3,1]  R1279     1.1386805772781372e-01
    phi[3,1]  R1280     -8.1957006454467773e-01
    phi[3,1]  R1281     5.2390500903129578e-02
    phi[3,1]  R1282     -1.5301643610000610e+00
    phi[3,1]  R1283     -1.7575470209121704e+00
    phi[3,1]  R1284     -2.8501877784729004e+00
    phi[3,1]  R1285     -1.7915084958076477e-01
    phi[3,1]  R1286     3.0303642153739929e-01
    phi[3,1]  R1287     -3.3715620040893555e+00
    phi[3,1]  R1288     -2.0060298442840576e+00
    phi[3,1]  R1289     -2.7238237857818604e+00
    phi[3,1]  R1290     -6.8031489849090576e-01
    phi[3,1]  R1291     -2.4363405704498291e+00
    phi[3,1]  R1292     -2.1277897357940674e+00
    phi[3,1]  R1293     -1.1200655698776245e+00
    phi[3,1]  R1294     -1.7033793926239014e+00
    phi[3,1]  R1295     -1.0668233633041382e+00
    phi[3,1]  R1296     -1.9567710161209106e+00
    phi[3,1]  R1297     3.6862635612487793e-01
    phi[3,1]  R1298     -3.3069546222686768e+00
    phi[3,1]  R1299     -5.7969087362289429e-01
    phi[3,1]  R1300     -1.7152290344238281e+00
    phi[3,1]  R1301     -1.2254465818405151e+00
    phi[3,1]  R1302     -1.4950339794158936e+00
    phi[3,1]  R1303     -2.0501000881195068e+00
    phi[3,1]  R1304     7.9432517290115356e-01
    phi[3,1]  R1305     -2.4705444276332855e-01
    phi[3,1]  R1306     -1.4063506126403809e+00
    phi[3,1]  R1307     -1.3665323257446289e+00
    phi[3,1]  R1308     -1.0960564613342285e+00
    phi[3,1]  R1309     -3.1379339098930359e-01
    phi[3,1]  R1310     -2.0460108295083046e-02
    phi[3,1]  R1311     -1.5683376789093018e+00
    phi[3,1]  R1312     -3.0081846714019775e+00
    phi[3,1]  R1313     -9.8765993118286133e-01
    phi[3,1]  R1314     1.5325158834457397e-01
    phi[3,1]  R1315     -2.1035239696502686e+00
    phi[3,1]  R1316     -3.0840060710906982e+00
    phi[3,1]  R1317     -1.5645678341388702e-01
    phi[3,1]  R1318     -8.3870381116867065e-02
    phi[3,1]  R1319     6.7055028676986694e-01
    phi[3,1]  R1320     -6.3917613029479980e-01
    phi[3,1]  R1321     -2.1533746719360352e+00
    phi[3,1]  R1322     -4.2741081118583679e-01
    phi[3,1]  R1323     -4.1643595695495605e-01
    phi[3,1]  R1324     -2.7875313535332680e-02
    phi[3,1]  R1325     -2.0998630523681641e+00
    phi[3,1]  R1326     -0.545108437538147
    phi[3,1]  R1327     -8.1084616482257843e-02
    phi[3,1]  R1328     3.1806731224060059e-01
    phi[3,1]  R1329     5.6769472360610962e-01
    phi[3,1]  R1330     -1.9940903186798096e+00
    phi[3,1]  R1331     -1.8269952535629272e+00
    phi[3,1]  R1332     -0.849909245967865
    phi[3,1]  R1333     3.3973476290702820e-01
    phi[3,1]  R1334     4.1951507329940796e-01
    phi[3,1]  R1335     -1.2691330909729004e+00
    phi[3,1]  R1336     -2.1943695843219757e-01
    phi[3,1]  R1337     -3.0348873138427734e+00
    phi[3,1]  R1338     1.0143363475799561e+00
    phi[3,1]  R1339     4.4909524917602539e-01
    phi[1,4]  R9        1
    phi[1,4]  R10       1
    phi[1,4]  R36       -1
    phi[1,4]  R1340     -3.0999999046325684e+00
    phi[1,4]  R1341     -3.0999999046325684e+00
    phi[1,4]  R1342     -2.2400000095367432e+00
    phi[1,4]  R1343     -2.2400000095367432e+00
    phi[1,4]  R1344     -3.0999999046325684e+00
    phi[1,4]  R1345     -3.0999999046325684e+00
    phi[1,4]  R1346     -2.5699999332427979e+00
    phi[1,4]  R1347     -2.5699999332427979e+00
    phi[1,4]  R1348     -3.0999999046325684e+00
    phi[1,4]  R1349     -3.0999999046325684e+00
    phi[1,4]  R1350     -2.0899999141693115e+00
    phi[1,4]  R1351     -2.0899999141693115e+00
    phi[1,4]  R1352     -3.0999999046325684e+00
    phi[1,4]  R1353     -3.0999999046325684e+00
    phi[1,4]  R1354     4.8072883486747742e-01
    phi[1,4]  R1355     9.2672121524810791e-01
    phi[1,4]  R1356     5.6869786977767944e-01
    phi[1,4]  R1357     1.1835095882415771e+00
    phi[1,4]  R1358     6.2269258499145508e-01
    phi[1,4]  R1359     8.2096248865127563e-01
    phi[1,4]  R1360     7.8266811370849609e-01
    phi[1,4]  R1361     -0.921746551990509
    phi[1,4]  R1362     -6.5485566854476929e-02
    phi[1,4]  R1363     2.6129174232482910e-01
    phi[1,4]  R1364     -1.4315564632415771e+00
    phi[1,4]  R1365     -6.4470881223678589e-01
    phi[1,4]  R1366     -1.8094162940979004e+00
    phi[1,4]  R1367     -5.4818183183670044e-01
    phi[1,4]  R1368     -2.6221022605895996e+00
    phi[1,4]  R1369     -2.6999969482421875e+00
    phi[1,4]  R1370     -1.38058602809906
    phi[1,4]  R1371     -5.3599423170089722e-01
    phi[1,4]  R1372     -7.7736479043960571e-01
    phi[1,4]  R1373     -1.4018226861953735e+00
    phi[1,4]  R1374     -1.9024895429611206e+00
    phi[1,4]  R1375     -1.3222129642963409e-01
    phi[1,4]  R1376     -1.1159085035324097e+00
    phi[1,4]  R1377     -3.6070916056632996e-01
    phi[1,4]  R1378     -3.2501956820487976e-01
    phi[1,4]  R1379     -6.9768828153610229e-01
    phi[1,4]  R1380     -1.1073216199874878e+00
    phi[1,4]  R1381     1.8805004656314850e-01
    phi[1,4]  R1382     -2.70127534866333
    phi[1,4]  R1383     3.6966949701309204e-01
    phi[1,4]  R1384     -1.6612381935119629e+00
    phi[1,4]  R1385     -3.3356863260269165e-01
    phi[1,4]  R1386     -2.6370186805725098e+00
    phi[1,4]  R1387     -6.3232409954071045e-01
    phi[1,4]  R1388     -1.5593767166137695e+00
    phi[1,4]  R1389     -2.8109071254730225e+00
    phi[1,4]  R1390     1.4483878016471863e-01
    phi[1,4]  R1391     -1.6609480977058411e-01
    phi[1,4]  R1392     -1.8052299022674561e+00
    phi[1,4]  R1393     1.1386805772781372e-01
    phi[1,4]  R1394     -8.1957006454467773e-01
    phi[1,4]  R1395     5.2390500903129578e-02
    phi[1,4]  R1396     -1.5301643610000610e+00
    phi[1,4]  R1397     -1.7575470209121704e+00
    phi[1,4]  R1398     -2.8501877784729004e+00
    phi[1,4]  R1399     -1.7915084958076477e-01
    phi[1,4]  R1400     3.0303642153739929e-01
    phi[1,4]  R1401     -3.3715620040893555e+00
    phi[1,4]  R1402     -2.0060298442840576e+00
    phi[1,4]  R1403     -2.7238237857818604e+00
    phi[1,4]  R1404     -6.8031489849090576e-01
    phi[1,4]  R1405     -2.4363405704498291e+00
    phi[1,4]  R1406     -2.1277897357940674e+00
    phi[1,4]  R1407     -1.1200655698776245e+00
    phi[1,4]  R1408     -1.7033793926239014e+00
    phi[1,4]  R1409     -1.0668233633041382e+00
    phi[1,4]  R1410     -1.9567710161209106e+00
    phi[1,4]  R1411     3.6862635612487793e-01
    phi[1,4]  R1412     -3.3069546222686768e+00
    phi[1,4]  R1413     -5.7969087362289429e-01
    phi[1,4]  R1414     -1.7152290344238281e+00
    phi[1,4]  R1415     -1.2254465818405151e+00
    phi[1,4]  R1416     -1.4950339794158936e+00
    phi[1,4]  R1417     -2.0501000881195068e+00
    phi[1,4]  R1418     7.9432517290115356e-01
    phi[1,4]  R1419     -2.4705444276332855e-01
    phi[1,4]  R1420     -1.4063506126403809e+00
    phi[1,4]  R1421     -1.3665323257446289e+00
    phi[1,4]  R1422     -1.0960564613342285e+00
    phi[1,4]  R1423     -3.1379339098930359e-01
    phi[1,4]  R1424     -2.0460108295083046e-02
    phi[1,4]  R1425     -1.5683376789093018e+00
    phi[1,4]  R1426     -3.0081846714019775e+00
    phi[1,4]  R1427     -9.8765993118286133e-01
    phi[1,4]  R1428     1.5325158834457397e-01
    phi[1,4]  R1429     -2.1035239696502686e+00
    phi[1,4]  R1430     -3.0840060710906982e+00
    phi[1,4]  R1431     -1.5645678341388702e-01
    phi[1,4]  R1432     -8.3870381116867065e-02
    phi[1,4]  R1433     6.7055028676986694e-01
    phi[1,4]  R1434     -6.3917613029479980e-01
    phi[1,4]  R1435     -2.1533746719360352e+00
    phi[1,4]  R1436     -4.2741081118583679e-01
    phi[1,4]  R1437     -4.1643595695495605e-01
    phi[1,4]  R1438     -2.7875313535332680e-02
    phi[1,4]  R1439     -2.0998630523681641e+00
    phi[1,4]  R1440     -0.545108437538147
    phi[1,4]  R1441     -8.1084616482257843e-02
    phi[1,4]  R1442     3.1806731224060059e-01
    phi[1,4]  R1443     5.6769472360610962e-01
    phi[1,4]  R1444     -1.9940903186798096e+00
    phi[1,4]  R1445     -1.8269952535629272e+00
    phi[1,4]  R1446     -0.849909245967865
    phi[1,4]  R1447     3.3973476290702820e-01
    phi[1,4]  R1448     4.1951507329940796e-01
    phi[1,4]  R1449     -1.2691330909729004e+00
    phi[1,4]  R1450     -2.1943695843219757e-01
    phi[1,4]  R1451     -3.0348873138427734e+00
    phi[1,4]  R1452     1.0143363475799561e+00
    phi[1,4]  R1453     4.4909524917602539e-01
    phi[1,4]  R1454     -1.6758900880813599e+00
    phi[1,4]  R1455     -2.3637080192565918e-01
    phi[1,4]  R1456     -2.0622079074382782e-01
    phi[1,4]  R1457     -1.2147315740585327e+00
    phi[1,4]  R1458     -3.8451308012008667e-01
    phi[1,4]  R1459     -5.1501029729843140e-01
    phi[1,4]  R1460     -3.3885970711708069e-01
    phi[1,4]  R1461     -3.6920243501663208e-01
    phi[1,4]  R1462     -4.9957668781280518e-01
    phi[1,4]  R1463     -4.3707442283630371e-01
    phi[1,4]  R1464     -7.7058243751525879e-01
    phi[1,4]  R1465     -1.6418419778347015e-01
    phi[1,4]  R1466     -4.0055418014526367e-01
    phi[1,4]  R1467     -4.5955479145050049e-01
    phi[1,4]  R1468     -3.0197986960411072e-01
    phi[1,4]  R1469     -6.3234555721282959e-01
    phi[1,4]  R1470     -4.3850201368331909e-01
    phi[1,4]  R1471     -1.6481919586658478e-01
    phi[1,4]  R1472     1.8553861975669861e-01
    phi[1,4]  R1473     -9.7381758689880371e-01
    phi[1,4]  R1474     -4.7962141036987305e-01
    phi[1,4]  R1475     -0.418389230966568
    phi[1,4]  R1476     -8.0814039707183838e-01
    phi[1,4]  R1477     -9.3466180562973022e-01
    phi[1,4]  R1478     -5.4314595460891724e-01
    phi[1,4]  R1479     -8.1450074911117554e-01
    phi[1,4]  R1480     -0.547443151473999
    phi[1,4]  R1481     -7.7373385429382324e-01
    phi[1,4]  R1482     -6.6778451204299927e-01
    phi[1,4]  R1483     -0.730191707611084
    phi[1,4]  R1484     -2.7379900217056274e-01
    phi[1,4]  R1485     -3.4759387373924255e-01
    phi[1,4]  R1486     -4.5646631717681885e-01
    phi[1,4]  R1487     -4.08668851852417
    phi[1,4]  R1488     -4.7927138209342957e-01
    phi[1,4]  R1489     -5.3723651170730591e-01
    phi[1,4]  R1490     -1.5418027639389038e+00
    phi[1,4]  R1491     -0.942437469959259
    phi[1,4]  R1492     -1.0453855991363525e+00
    phi[1,4]  R1493     -9.0489536523818970e-01
    phi[4,1]  R9        -1
    phi[4,1]  R36       1
    phi[4,1]  R37       1
    phi[4,1]  R1494     -3.0999999046325684e+00
    phi[4,1]  R1495     -3.0999999046325684e+00
    phi[4,1]  R1496     -2.2400000095367432e+00
    phi[4,1]  R1497     -2.2400000095367432e+00
    phi[4,1]  R1498     -3.0999999046325684e+00
    phi[4,1]  R1499     -3.0999999046325684e+00
    phi[4,1]  R1500     -2.5699999332427979e+00
    phi[4,1]  R1501     -2.5699999332427979e+00
    phi[4,1]  R1502     -3.0999999046325684e+00
    phi[4,1]  R1503     -3.0999999046325684e+00
    phi[4,1]  R1504     -2.0899999141693115e+00
    phi[4,1]  R1505     -2.0899999141693115e+00
    phi[4,1]  R1506     -3.0999999046325684e+00
    phi[4,1]  R1507     -3.0999999046325684e+00
    phi[4,1]  R1508     -1.6758900880813599e+00
    phi[4,1]  R1509     -2.3637080192565918e-01
    phi[4,1]  R1510     -2.0622079074382782e-01
    phi[4,1]  R1511     -1.2147315740585327e+00
    phi[4,1]  R1512     -3.8451308012008667e-01
    phi[4,1]  R1513     -5.1501029729843140e-01
    phi[4,1]  R1514     -3.3885970711708069e-01
    phi[4,1]  R1515     -3.6920243501663208e-01
    phi[4,1]  R1516     -4.9957668781280518e-01
    phi[4,1]  R1517     -4.3707442283630371e-01
    phi[4,1]  R1518     -7.7058243751525879e-01
    phi[4,1]  R1519     -1.6418419778347015e-01
    phi[4,1]  R1520     -4.0055418014526367e-01
    phi[4,1]  R1521     -4.5955479145050049e-01
    phi[4,1]  R1522     -3.0197986960411072e-01
    phi[4,1]  R1523     -6.3234555721282959e-01
    phi[4,1]  R1524     -4.3850201368331909e-01
    phi[4,1]  R1525     -1.6481919586658478e-01
    phi[4,1]  R1526     1.8553861975669861e-01
    phi[4,1]  R1527     -9.7381758689880371e-01
    phi[4,1]  R1528     -4.7962141036987305e-01
    phi[4,1]  R1529     -0.418389230966568
    phi[4,1]  R1530     -8.0814039707183838e-01
    phi[4,1]  R1531     -9.3466180562973022e-01
    phi[4,1]  R1532     -5.4314595460891724e-01
    phi[4,1]  R1533     -8.1450074911117554e-01
    phi[4,1]  R1534     -0.547443151473999
    phi[4,1]  R1535     -7.7373385429382324e-01
    phi[4,1]  R1536     -6.6778451204299927e-01
    phi[4,1]  R1537     -0.730191707611084
    phi[4,1]  R1538     -2.7379900217056274e-01
    phi[4,1]  R1539     -3.4759387373924255e-01
    phi[4,1]  R1540     -4.5646631717681885e-01
    phi[4,1]  R1541     -4.08668851852417
    phi[4,1]  R1542     -4.7927138209342957e-01
    phi[4,1]  R1543     -5.3723651170730591e-01
    phi[4,1]  R1544     -1.5418027639389038e+00
    phi[4,1]  R1545     -0.942437469959259
    phi[4,1]  R1546     -1.0453855991363525e+00
    phi[4,1]  R1547     -9.0489536523818970e-01
    phi[4,1]  R1548     4.8072883486747742e-01
    phi[4,1]  R1549     9.2672121524810791e-01
    phi[4,1]  R1550     5.6869786977767944e-01
    phi[4,1]  R1551     1.1835095882415771e+00
    phi[4,1]  R1552     6.2269258499145508e-01
    phi[4,1]  R1553     8.2096248865127563e-01
    phi[4,1]  R1554     7.8266811370849609e-01
    phi[4,1]  R1555     -0.921746551990509
    phi[4,1]  R1556     -6.5485566854476929e-02
    phi[4,1]  R1557     2.6129174232482910e-01
    phi[4,1]  R1558     -1.4315564632415771e+00
    phi[4,1]  R1559     -6.4470881223678589e-01
    phi[4,1]  R1560     -1.8094162940979004e+00
    phi[4,1]  R1561     -5.4818183183670044e-01
    phi[4,1]  R1562     -2.6221022605895996e+00
    phi[4,1]  R1563     -2.6999969482421875e+00
    phi[4,1]  R1564     -1.38058602809906
    phi[4,1]  R1565     -5.3599423170089722e-01
    phi[4,1]  R1566     -7.7736479043960571e-01
    phi[4,1]  R1567     -1.4018226861953735e+00
    phi[4,1]  R1568     -1.9024895429611206e+00
    phi[4,1]  R1569     -1.3222129642963409e-01
    phi[4,1]  R1570     -1.1159085035324097e+00
    phi[4,1]  R1571     -3.6070916056632996e-01
    phi[4,1]  R1572     -3.2501956820487976e-01
    phi[4,1]  R1573     -6.9768828153610229e-01
    phi[4,1]  R1574     -1.1073216199874878e+00
    phi[4,1]  R1575     1.8805004656314850e-01
    phi[4,1]  R1576     -2.70127534866333
    phi[4,1]  R1577     3.6966949701309204e-01
    phi[4,1]  R1578     -1.6612381935119629e+00
    phi[4,1]  R1579     -3.3356863260269165e-01
    phi[4,1]  R1580     -2.6370186805725098e+00
    phi[4,1]  R1581     -6.3232409954071045e-01
    phi[4,1]  R1582     -1.5593767166137695e+00
    phi[4,1]  R1583     -2.8109071254730225e+00
    phi[4,1]  R1584     1.4483878016471863e-01
    phi[4,1]  R1585     -1.6609480977058411e-01
    phi[4,1]  R1586     -1.8052299022674561e+00
    phi[4,1]  R1587     1.1386805772781372e-01
    phi[4,1]  R1588     -8.1957006454467773e-01
    phi[4,1]  R1589     5.2390500903129578e-02
    phi[4,1]  R1590     -1.5301643610000610e+00
    phi[4,1]  R1591     -1.7575470209121704e+00
    phi[4,1]  R1592     -2.8501877784729004e+00
    phi[4,1]  R1593     -1.7915084958076477e-01
    phi[4,1]  R1594     3.0303642153739929e-01
    phi[4,1]  R1595     -3.3715620040893555e+00
    phi[4,1]  R1596     -2.0060298442840576e+00
    phi[4,1]  R1597     -2.7238237857818604e+00
    phi[4,1]  R1598     -6.8031489849090576e-01
    phi[4,1]  R1599     -2.4363405704498291e+00
    phi[4,1]  R1600     -2.1277897357940674e+00
    phi[4,1]  R1601     -1.1200655698776245e+00
    phi[4,1]  R1602     -1.7033793926239014e+00
    phi[4,1]  R1603     -1.0668233633041382e+00
    phi[4,1]  R1604     -1.9567710161209106e+00
    phi[4,1]  R1605     3.6862635612487793e-01
    phi[4,1]  R1606     -3.3069546222686768e+00
    phi[4,1]  R1607     -5.7969087362289429e-01
    phi[4,1]  R1608     -1.7152290344238281e+00
    phi[4,1]  R1609     -1.2254465818405151e+00
    phi[4,1]  R1610     -1.4950339794158936e+00
    phi[4,1]  R1611     -2.0501000881195068e+00
    phi[4,1]  R1612     7.9432517290115356e-01
    phi[4,1]  R1613     -2.4705444276332855e-01
    phi[4,1]  R1614     -1.4063506126403809e+00
    phi[4,1]  R1615     -1.3665323257446289e+00
    phi[4,1]  R1616     -1.0960564613342285e+00
    phi[4,1]  R1617     -3.1379339098930359e-01
    phi[4,1]  R1618     -2.0460108295083046e-02
    phi[4,1]  R1619     -1.5683376789093018e+00
    phi[4,1]  R1620     -3.0081846714019775e+00
    phi[4,1]  R1621     -9.8765993118286133e-01
    phi[4,1]  R1622     1.5325158834457397e-01
    phi[4,1]  R1623     -2.1035239696502686e+00
    phi[4,1]  R1624     -3.0840060710906982e+00
    phi[4,1]  R1625     -1.5645678341388702e-01
    phi[4,1]  R1626     -8.3870381116867065e-02
    phi[4,1]  R1627     6.7055028676986694e-01
    phi[4,1]  R1628     -6.3917613029479980e-01
    phi[4,1]  R1629     -2.1533746719360352e+00
    phi[4,1]  R1630     -4.2741081118583679e-01
    phi[4,1]  R1631     -4.1643595695495605e-01
    phi[4,1]  R1632     -2.7875313535332680e-02
    phi[4,1]  R1633     -2.0998630523681641e+00
    phi[4,1]  R1634     -0.545108437538147
    phi[4,1]  R1635     -8.1084616482257843e-02
    phi[4,1]  R1636     3.1806731224060059e-01
    phi[4,1]  R1637     5.6769472360610962e-01
    phi[4,1]  R1638     -1.9940903186798096e+00
    phi[4,1]  R1639     -1.8269952535629272e+00
    phi[4,1]  R1640     -0.849909245967865
    phi[4,1]  R1641     3.3973476290702820e-01
    phi[4,1]  R1642     4.1951507329940796e-01
    phi[4,1]  R1643     -1.2691330909729004e+00
    phi[4,1]  R1644     -2.1943695843219757e-01
    phi[4,1]  R1645     -3.0348873138427734e+00
    phi[4,1]  R1646     1.0143363475799561e+00
    phi[4,1]  R1647     4.4909524917602539e-01
    phi[1,5]  R9        1
    phi[1,5]  R10       1
    phi[1,5]  R45       -1
    phi[1,5]  R1648     -3.0999999046325684e+00
    phi[1,5]  R1649     -3.0999999046325684e+00
    phi[1,5]  R1650     -2.2400000095367432e+00
    phi[1,5]  R1651     -2.2400000095367432e+00
    phi[1,5]  R1652     -3.0999999046325684e+00
    phi[1,5]  R1653     -3.0999999046325684e+00
    phi[1,5]  R1654     -2.5699999332427979e+00
    phi[1,5]  R1655     -2.5699999332427979e+00
    phi[1,5]  R1656     -3.0999999046325684e+00
    phi[1,5]  R1657     -3.0999999046325684e+00
    phi[1,5]  R1658     -2.0899999141693115e+00
    phi[1,5]  R1659     -2.0899999141693115e+00
    phi[1,5]  R1660     -3.0999999046325684e+00
    phi[1,5]  R1661     -3.0999999046325684e+00
    phi[1,5]  R1662     4.8072883486747742e-01
    phi[1,5]  R1663     9.2672121524810791e-01
    phi[1,5]  R1664     5.6869786977767944e-01
    phi[1,5]  R1665     1.1835095882415771e+00
    phi[1,5]  R1666     6.2269258499145508e-01
    phi[1,5]  R1667     8.2096248865127563e-01
    phi[1,5]  R1668     7.8266811370849609e-01
    phi[1,5]  R1669     -0.921746551990509
    phi[1,5]  R1670     -6.5485566854476929e-02
    phi[1,5]  R1671     2.6129174232482910e-01
    phi[1,5]  R1672     -1.4315564632415771e+00
    phi[1,5]  R1673     -6.4470881223678589e-01
    phi[1,5]  R1674     -1.8094162940979004e+00
    phi[1,5]  R1675     -5.4818183183670044e-01
    phi[1,5]  R1676     -2.6221022605895996e+00
    phi[1,5]  R1677     -2.6999969482421875e+00
    phi[1,5]  R1678     -1.38058602809906
    phi[1,5]  R1679     -5.3599423170089722e-01
    phi[1,5]  R1680     -7.7736479043960571e-01
    phi[1,5]  R1681     -1.4018226861953735e+00
    phi[1,5]  R1682     -1.9024895429611206e+00
    phi[1,5]  R1683     -1.3222129642963409e-01
    phi[1,5]  R1684     -1.1159085035324097e+00
    phi[1,5]  R1685     -3.6070916056632996e-01
    phi[1,5]  R1686     -3.2501956820487976e-01
    phi[1,5]  R1687     -6.9768828153610229e-01
    phi[1,5]  R1688     -1.1073216199874878e+00
    phi[1,5]  R1689     1.8805004656314850e-01
    phi[1,5]  R1690     -2.70127534866333
    phi[1,5]  R1691     3.6966949701309204e-01
    phi[1,5]  R1692     -1.6612381935119629e+00
    phi[1,5]  R1693     -3.3356863260269165e-01
    phi[1,5]  R1694     -2.6370186805725098e+00
    phi[1,5]  R1695     -6.3232409954071045e-01
    phi[1,5]  R1696     -1.5593767166137695e+00
    phi[1,5]  R1697     -2.8109071254730225e+00
    phi[1,5]  R1698     1.4483878016471863e-01
    phi[1,5]  R1699     -1.6609480977058411e-01
    phi[1,5]  R1700     -1.8052299022674561e+00
    phi[1,5]  R1701     1.1386805772781372e-01
    phi[1,5]  R1702     -8.1957006454467773e-01
    phi[1,5]  R1703     5.2390500903129578e-02
    phi[1,5]  R1704     -1.5301643610000610e+00
    phi[1,5]  R1705     -1.7575470209121704e+00
    phi[1,5]  R1706     -2.8501877784729004e+00
    phi[1,5]  R1707     -1.7915084958076477e-01
    phi[1,5]  R1708     3.0303642153739929e-01
    phi[1,5]  R1709     -3.3715620040893555e+00
    phi[1,5]  R1710     -2.0060298442840576e+00
    phi[1,5]  R1711     -2.7238237857818604e+00
    phi[1,5]  R1712     -6.8031489849090576e-01
    phi[1,5]  R1713     -2.4363405704498291e+00
    phi[1,5]  R1714     -2.1277897357940674e+00
    phi[1,5]  R1715     -1.1200655698776245e+00
    phi[1,5]  R1716     -1.7033793926239014e+00
    phi[1,5]  R1717     -1.0668233633041382e+00
    phi[1,5]  R1718     -1.9567710161209106e+00
    phi[1,5]  R1719     3.6862635612487793e-01
    phi[1,5]  R1720     -3.3069546222686768e+00
    phi[1,5]  R1721     -5.7969087362289429e-01
    phi[1,5]  R1722     -1.7152290344238281e+00
    phi[1,5]  R1723     -1.2254465818405151e+00
    phi[1,5]  R1724     -1.4950339794158936e+00
    phi[1,5]  R1725     -2.0501000881195068e+00
    phi[1,5]  R1726     7.9432517290115356e-01
    phi[1,5]  R1727     -2.4705444276332855e-01
    phi[1,5]  R1728     -1.4063506126403809e+00
    phi[1,5]  R1729     -1.3665323257446289e+00
    phi[1,5]  R1730     -1.0960564613342285e+00
    phi[1,5]  R1731     -3.1379339098930359e-01
    phi[1,5]  R1732     -2.0460108295083046e-02
    phi[1,5]  R1733     -1.5683376789093018e+00
    phi[1,5]  R1734     -3.0081846714019775e+00
    phi[1,5]  R1735     -9.8765993118286133e-01
    phi[1,5]  R1736     1.5325158834457397e-01
    phi[1,5]  R1737     -2.1035239696502686e+00
    phi[1,5]  R1738     -3.0840060710906982e+00
    phi[1,5]  R1739     -1.5645678341388702e-01
    phi[1,5]  R1740     -8.3870381116867065e-02
    phi[1,5]  R1741     6.7055028676986694e-01
    phi[1,5]  R1742     -6.3917613029479980e-01
    phi[1,5]  R1743     -2.1533746719360352e+00
    phi[1,5]  R1744     -4.2741081118583679e-01
    phi[1,5]  R1745     -4.1643595695495605e-01
    phi[1,5]  R1746     -2.7875313535332680e-02
    phi[1,5]  R1747     -2.0998630523681641e+00
    phi[1,5]  R1748     -0.545108437538147
    phi[1,5]  R1749     -8.1084616482257843e-02
    phi[1,5]  R1750     3.1806731224060059e-01
    phi[1,5]  R1751     5.6769472360610962e-01
    phi[1,5]  R1752     -1.9940903186798096e+00
    phi[1,5]  R1753     -1.8269952535629272e+00
    phi[1,5]  R1754     -0.849909245967865
    phi[1,5]  R1755     3.3973476290702820e-01
    phi[1,5]  R1756     4.1951507329940796e-01
    phi[1,5]  R1757     -1.2691330909729004e+00
    phi[1,5]  R1758     -2.1943695843219757e-01
    phi[1,5]  R1759     -3.0348873138427734e+00
    phi[1,5]  R1760     1.0143363475799561e+00
    phi[1,5]  R1761     4.4909524917602539e-01
    phi[1,5]  R1762     1.6160950660705566e+00
    phi[1,5]  R1763     1.5525077581405640e+00
    phi[1,5]  R1764     1.2035214900970459e+00
    phi[1,5]  R1765     1.6387071609497070e+00
    phi[1,5]  R1766     0.531485915184021
    phi[1,5]  R1767     9.4283801317214966e-01
    phi[1,5]  R1768     2.9424183368682861e+00
    phi[1,5]  R1769     2.5396635532379150e+00
    phi[1,5]  R1770     1.5825518369674683e+00
    phi[1,5]  R1771     -3.7100253105163574e+00
    phi[1,5]  R1772     -2.6541557312011719e+00
    phi[1,5]  R1773     -1.1085237264633179e+00
    phi[1,5]  R1774     -1.8074454069137573e+00
    phi[1,5]  R1775     -1.2962071895599365e+00
    phi[1,5]  R1776     -2.3853738307952881e+00
    phi[1,5]  R1777     -2.2767009735107422e+00
    phi[1,5]  R1778     -1.5357433557510376e+00
    phi[1,5]  R1779     -2.29524302482605
    phi[5,1]  R9        -1
    phi[5,1]  R45       1
    phi[5,1]  R46       1
    phi[5,1]  R1780     -3.0999999046325684e+00
    phi[5,1]  R1781     -3.0999999046325684e+00
    phi[5,1]  R1782     -2.2400000095367432e+00
    phi[5,1]  R1783     -2.2400000095367432e+00
    phi[5,1]  R1784     -3.0999999046325684e+00
    phi[5,1]  R1785     -3.0999999046325684e+00
    phi[5,1]  R1786     -2.5699999332427979e+00
    phi[5,1]  R1787     -2.5699999332427979e+00
    phi[5,1]  R1788     -3.0999999046325684e+00
    phi[5,1]  R1789     -3.0999999046325684e+00
    phi[5,1]  R1790     -2.0899999141693115e+00
    phi[5,1]  R1791     -2.0899999141693115e+00
    phi[5,1]  R1792     -3.0999999046325684e+00
    phi[5,1]  R1793     -3.0999999046325684e+00
    phi[5,1]  R1794     1.6160950660705566e+00
    phi[5,1]  R1795     1.5525077581405640e+00
    phi[5,1]  R1796     1.2035214900970459e+00
    phi[5,1]  R1797     1.6387071609497070e+00
    phi[5,1]  R1798     0.531485915184021
    phi[5,1]  R1799     9.4283801317214966e-01
    phi[5,1]  R1800     2.9424183368682861e+00
    phi[5,1]  R1801     2.5396635532379150e+00
    phi[5,1]  R1802     1.5825518369674683e+00
    phi[5,1]  R1803     -3.7100253105163574e+00
    phi[5,1]  R1804     -2.6541557312011719e+00
    phi[5,1]  R1805     -1.1085237264633179e+00
    phi[5,1]  R1806     -1.8074454069137573e+00
    phi[5,1]  R1807     -1.2962071895599365e+00
    phi[5,1]  R1808     -2.3853738307952881e+00
    phi[5,1]  R1809     -2.2767009735107422e+00
    phi[5,1]  R1810     -1.5357433557510376e+00
    phi[5,1]  R1811     -2.29524302482605
    phi[5,1]  R1812     4.8072883486747742e-01
    phi[5,1]  R1813     9.2672121524810791e-01
    phi[5,1]  R1814     5.6869786977767944e-01
    phi[5,1]  R1815     1.1835095882415771e+00
    phi[5,1]  R1816     6.2269258499145508e-01
    phi[5,1]  R1817     8.2096248865127563e-01
    phi[5,1]  R1818     7.8266811370849609e-01
    phi[5,1]  R1819     -0.921746551990509
    phi[5,1]  R1820     -6.5485566854476929e-02
    phi[5,1]  R1821     2.6129174232482910e-01
    phi[5,1]  R1822     -1.4315564632415771e+00
    phi[5,1]  R1823     -6.4470881223678589e-01
    phi[5,1]  R1824     -1.8094162940979004e+00
    phi[5,1]  R1825     -5.4818183183670044e-01
    phi[5,1]  R1826     -2.6221022605895996e+00
    phi[5,1]  R1827     -2.6999969482421875e+00
    phi[5,1]  R1828     -1.38058602809906
    phi[5,1]  R1829     -5.3599423170089722e-01
    phi[5,1]  R1830     -7.7736479043960571e-01
    phi[5,1]  R1831     -1.4018226861953735e+00
    phi[5,1]  R1832     -1.9024895429611206e+00
    phi[5,1]  R1833     -1.3222129642963409e-01
    phi[5,1]  R1834     -1.1159085035324097e+00
    phi[5,1]  R1835     -3.6070916056632996e-01
    phi[5,1]  R1836     -3.2501956820487976e-01
    phi[5,1]  R1837     -6.9768828153610229e-01
    phi[5,1]  R1838     -1.1073216199874878e+00
    phi[5,1]  R1839     1.8805004656314850e-01
    phi[5,1]  R1840     -2.70127534866333
    phi[5,1]  R1841     3.6966949701309204e-01
    phi[5,1]  R1842     -1.6612381935119629e+00
    phi[5,1]  R1843     -3.3356863260269165e-01
    phi[5,1]  R1844     -2.6370186805725098e+00
    phi[5,1]  R1845     -6.3232409954071045e-01
    phi[5,1]  R1846     -1.5593767166137695e+00
    phi[5,1]  R1847     -2.8109071254730225e+00
    phi[5,1]  R1848     1.4483878016471863e-01
    phi[5,1]  R1849     -1.6609480977058411e-01
    phi[5,1]  R1850     -1.8052299022674561e+00
    phi[5,1]  R1851     1.1386805772781372e-01
    phi[5,1]  R1852     -8.1957006454467773e-01
    phi[5,1]  R1853     5.2390500903129578e-02
    phi[5,1]  R1854     -1.5301643610000610e+00
    phi[5,1]  R1855     -1.7575470209121704e+00
    phi[5,1]  R1856     -2.8501877784729004e+00
    phi[5,1]  R1857     -1.7915084958076477e-01
    phi[5,1]  R1858     3.0303642153739929e-01
    phi[5,1]  R1859     -3.3715620040893555e+00
    phi[5,1]  R1860     -2.0060298442840576e+00
    phi[5,1]  R1861     -2.7238237857818604e+00
    phi[5,1]  R1862     -6.8031489849090576e-01
    phi[5,1]  R1863     -2.4363405704498291e+00
    phi[5,1]  R1864     -2.1277897357940674e+00
    phi[5,1]  R1865     -1.1200655698776245e+00
    phi[5,1]  R1866     -1.7033793926239014e+00
    phi[5,1]  R1867     -1.0668233633041382e+00
    phi[5,1]  R1868     -1.9567710161209106e+00
    phi[5,1]  R1869     3.6862635612487793e-01
    phi[5,1]  R1870     -3.3069546222686768e+00
    phi[5,1]  R1871     -5.7969087362289429e-01
    phi[5,1]  R1872     -1.7152290344238281e+00
    phi[5,1]  R1873     -1.2254465818405151e+00
    phi[5,1]  R1874     -1.4950339794158936e+00
    phi[5,1]  R1875     -2.0501000881195068e+00
    phi[5,1]  R1876     7.9432517290115356e-01
    phi[5,1]  R1877     -2.4705444276332855e-01
    phi[5,1]  R1878     -1.4063506126403809e+00
    phi[5,1]  R1879     -1.3665323257446289e+00
    phi[5,1]  R1880     -1.0960564613342285e+00
    phi[5,1]  R1881     -3.1379339098930359e-01
    phi[5,1]  R1882     -2.0460108295083046e-02
    phi[5,1]  R1883     -1.5683376789093018e+00
    phi[5,1]  R1884     -3.0081846714019775e+00
    phi[5,1]  R1885     -9.8765993118286133e-01
    phi[5,1]  R1886     1.5325158834457397e-01
    phi[5,1]  R1887     -2.1035239696502686e+00
    phi[5,1]  R1888     -3.0840060710906982e+00
    phi[5,1]  R1889     -1.5645678341388702e-01
    phi[5,1]  R1890     -8.3870381116867065e-02
    phi[5,1]  R1891     6.7055028676986694e-01
    phi[5,1]  R1892     -6.3917613029479980e-01
    phi[5,1]  R1893     -2.1533746719360352e+00
    phi[5,1]  R1894     -4.2741081118583679e-01
    phi[5,1]  R1895     -4.1643595695495605e-01
    phi[5,1]  R1896     -2.7875313535332680e-02
    phi[5,1]  R1897     -2.0998630523681641e+00
    phi[5,1]  R1898     -0.545108437538147
    phi[5,1]  R1899     -8.1084616482257843e-02
    phi[5,1]  R1900     3.1806731224060059e-01
    phi[5,1]  R1901     5.6769472360610962e-01
    phi[5,1]  R1902     -1.9940903186798096e+00
    phi[5,1]  R1903     -1.8269952535629272e+00
    phi[5,1]  R1904     -0.849909245967865
    phi[5,1]  R1905     3.3973476290702820e-01
    phi[5,1]  R1906     4.1951507329940796e-01
    phi[5,1]  R1907     -1.2691330909729004e+00
    phi[5,1]  R1908     -2.1943695843219757e-01
    phi[5,1]  R1909     -3.0348873138427734e+00
    phi[5,1]  R1910     1.0143363475799561e+00
    phi[5,1]  R1911     4.4909524917602539e-01
    phi[2,4]  R18       1
    phi[2,4]  R19       1
    phi[2,4]  R36       -1
    phi[2,4]  R1912     -3.0999999046325684e+00
    phi[2,4]  R1913     -3.0999999046325684e+00
    phi[2,4]  R1914     -2.2400000095367432e+00
    phi[2,4]  R1915     -2.2400000095367432e+00
    phi[2,4]  R1916     -3.0999999046325684e+00
    phi[2,4]  R1917     -3.0999999046325684e+00
    phi[2,4]  R1918     -2.5699999332427979e+00
    phi[2,4]  R1919     -2.5699999332427979e+00
    phi[2,4]  R1920     -3.0999999046325684e+00
    phi[2,4]  R1921     -3.0999999046325684e+00
    phi[2,4]  R1922     -2.0899999141693115e+00
    phi[2,4]  R1923     -2.0899999141693115e+00
    phi[2,4]  R1924     -3.0999999046325684e+00
    phi[2,4]  R1925     -3.0999999046325684e+00
    phi[2,4]  R1926     -1.4811532199382782e-01
    phi[2,4]  R1927     -1.4165000617504120e-01
    phi[2,4]  R1928     1.4599986076354980e+00
    phi[2,4]  R1929     -1.5486198663711548e+00
    phi[2,4]  R1930     1.1294338703155518e+00
    phi[2,4]  R1931     1.8009097576141357e+00
    phi[2,4]  R1932     2.2220847606658936e+00
    phi[2,4]  R1933     0.531309962272644
    phi[2,4]  R1934     4.3408146500587463e-01
    phi[2,4]  R1935     -1.5024748444557190e-01
    phi[2,4]  R1936     -1.7340061664581299e+00
    phi[2,4]  R1937     -6.2100455164909363e-02
    phi[2,4]  R1938     -1.6835961341857910e+00
    phi[2,4]  R1939     -6.1145722866058350e-01
    phi[2,4]  R1940     -6.5656119585037231e-01
    phi[2,4]  R1941     -7.4085032939910889e-01
    phi[2,4]  R1942     -0.0375056266784668
    phi[2,4]  R1943     -1.6793100833892822e+00
    phi[2,4]  R1944     -3.7340819835662842e-01
    phi[2,4]  R1945     -5.9820175170898438e-01
    phi[2,4]  R1946     -1.6758900880813599e+00
    phi[2,4]  R1947     -2.3637080192565918e-01
    phi[2,4]  R1948     -2.0622079074382782e-01
    phi[2,4]  R1949     -1.2147315740585327e+00
    phi[2,4]  R1950     -3.8451308012008667e-01
    phi[2,4]  R1951     -5.1501029729843140e-01
    phi[2,4]  R1952     -3.3885970711708069e-01
    phi[2,4]  R1953     -3.6920243501663208e-01
    phi[2,4]  R1954     -4.9957668781280518e-01
    phi[2,4]  R1955     -4.3707442283630371e-01
    phi[2,4]  R1956     -7.7058243751525879e-01
    phi[2,4]  R1957     -1.6418419778347015e-01
    phi[2,4]  R1958     -4.0055418014526367e-01
    phi[2,4]  R1959     -4.5955479145050049e-01
    phi[2,4]  R1960     -3.0197986960411072e-01
    phi[2,4]  R1961     -6.3234555721282959e-01
    phi[2,4]  R1962     -4.3850201368331909e-01
    phi[2,4]  R1963     -1.6481919586658478e-01
    phi[2,4]  R1964     1.8553861975669861e-01
    phi[2,4]  R1965     -9.7381758689880371e-01
    phi[2,4]  R1966     -4.7962141036987305e-01
    phi[2,4]  R1967     -0.418389230966568
    phi[2,4]  R1968     -8.0814039707183838e-01
    phi[2,4]  R1969     -9.3466180562973022e-01
    phi[2,4]  R1970     -5.4314595460891724e-01
    phi[2,4]  R1971     -8.1450074911117554e-01
    phi[2,4]  R1972     -0.547443151473999
    phi[2,4]  R1973     -7.7373385429382324e-01
    phi[2,4]  R1974     -6.6778451204299927e-01
    phi[2,4]  R1975     -0.730191707611084
    phi[2,4]  R1976     -2.7379900217056274e-01
    phi[2,4]  R1977     -3.4759387373924255e-01
    phi[2,4]  R1978     -4.5646631717681885e-01
    phi[2,4]  R1979     -4.08668851852417
    phi[2,4]  R1980     -4.7927138209342957e-01
    phi[2,4]  R1981     -5.3723651170730591e-01
    phi[2,4]  R1982     -1.5418027639389038e+00
    phi[2,4]  R1983     -0.942437469959259
    phi[2,4]  R1984     -1.0453855991363525e+00
    phi[2,4]  R1985     -9.0489536523818970e-01
    phi[4,2]  R18       -1
    phi[4,2]  R36       1
    phi[4,2]  R37       1
    phi[4,2]  R1986     -3.0999999046325684e+00
    phi[4,2]  R1987     -3.0999999046325684e+00
    phi[4,2]  R1988     -2.2400000095367432e+00
    phi[4,2]  R1989     -2.2400000095367432e+00
    phi[4,2]  R1990     -3.0999999046325684e+00
    phi[4,2]  R1991     -3.0999999046325684e+00
    phi[4,2]  R1992     -2.5699999332427979e+00
    phi[4,2]  R1993     -2.5699999332427979e+00
    phi[4,2]  R1994     -3.0999999046325684e+00
    phi[4,2]  R1995     -3.0999999046325684e+00
    phi[4,2]  R1996     -2.0899999141693115e+00
    phi[4,2]  R1997     -2.0899999141693115e+00
    phi[4,2]  R1998     -3.0999999046325684e+00
    phi[4,2]  R1999     -3.0999999046325684e+00
    phi[4,2]  R2000     -1.6758900880813599e+00
    phi[4,2]  R2001     -2.3637080192565918e-01
    phi[4,2]  R2002     -2.0622079074382782e-01
    phi[4,2]  R2003     -1.2147315740585327e+00
    phi[4,2]  R2004     -3.8451308012008667e-01
    phi[4,2]  R2005     -5.1501029729843140e-01
    phi[4,2]  R2006     -3.3885970711708069e-01
    phi[4,2]  R2007     -3.6920243501663208e-01
    phi[4,2]  R2008     -4.9957668781280518e-01
    phi[4,2]  R2009     -4.3707442283630371e-01
    phi[4,2]  R2010     -7.7058243751525879e-01
    phi[4,2]  R2011     -1.6418419778347015e-01
    phi[4,2]  R2012     -4.0055418014526367e-01
    phi[4,2]  R2013     -4.5955479145050049e-01
    phi[4,2]  R2014     -3.0197986960411072e-01
    phi[4,2]  R2015     -6.3234555721282959e-01
    phi[4,2]  R2016     -4.3850201368331909e-01
    phi[4,2]  R2017     -1.6481919586658478e-01
    phi[4,2]  R2018     1.8553861975669861e-01
    phi[4,2]  R2019     -9.7381758689880371e-01
    phi[4,2]  R2020     -4.7962141036987305e-01
    phi[4,2]  R2021     -0.418389230966568
    phi[4,2]  R2022     -8.0814039707183838e-01
    phi[4,2]  R2023     -9.3466180562973022e-01
    phi[4,2]  R2024     -5.4314595460891724e-01
    phi[4,2]  R2025     -8.1450074911117554e-01
    phi[4,2]  R2026     -0.547443151473999
    phi[4,2]  R2027     -7.7373385429382324e-01
    phi[4,2]  R2028     -6.6778451204299927e-01
    phi[4,2]  R2029     -0.730191707611084
    phi[4,2]  R2030     -2.7379900217056274e-01
    phi[4,2]  R2031     -3.4759387373924255e-01
    phi[4,2]  R2032     -4.5646631717681885e-01
    phi[4,2]  R2033     -4.08668851852417
    phi[4,2]  R2034     -4.7927138209342957e-01
    phi[4,2]  R2035     -5.3723651170730591e-01
    phi[4,2]  R2036     -1.5418027639389038e+00
    phi[4,2]  R2037     -0.942437469959259
    phi[4,2]  R2038     -1.0453855991363525e+00
    phi[4,2]  R2039     -9.0489536523818970e-01
    phi[4,2]  R2040     -1.4811532199382782e-01
    phi[4,2]  R2041     -1.4165000617504120e-01
    phi[4,2]  R2042     1.4599986076354980e+00
    phi[4,2]  R2043     -1.5486198663711548e+00
    phi[4,2]  R2044     1.1294338703155518e+00
    phi[4,2]  R2045     1.8009097576141357e+00
    phi[4,2]  R2046     2.2220847606658936e+00
    phi[4,2]  R2047     0.531309962272644
    phi[4,2]  R2048     4.3408146500587463e-01
    phi[4,2]  R2049     -1.5024748444557190e-01
    phi[4,2]  R2050     -1.7340061664581299e+00
    phi[4,2]  R2051     -6.2100455164909363e-02
    phi[4,2]  R2052     -1.6835961341857910e+00
    phi[4,2]  R2053     -6.1145722866058350e-01
    phi[4,2]  R2054     -6.5656119585037231e-01
    phi[4,2]  R2055     -7.4085032939910889e-01
    phi[4,2]  R2056     -0.0375056266784668
    phi[4,2]  R2057     -1.6793100833892822e+00
    phi[4,2]  R2058     -3.7340819835662842e-01
    phi[4,2]  R2059     -5.9820175170898438e-01
    phi[2,5]  R18       1
    phi[2,5]  R19       1
    phi[2,5]  R45       -1
    phi[2,5]  R2060     -3.0999999046325684e+00
    phi[2,5]  R2061     -3.0999999046325684e+00
    phi[2,5]  R2062     -2.2400000095367432e+00
    phi[2,5]  R2063     -2.2400000095367432e+00
    phi[2,5]  R2064     -3.0999999046325684e+00
    phi[2,5]  R2065     -3.0999999046325684e+00
    phi[2,5]  R2066     -2.5699999332427979e+00
    phi[2,5]  R2067     -2.5699999332427979e+00
    phi[2,5]  R2068     -3.0999999046325684e+00
    phi[2,5]  R2069     -3.0999999046325684e+00
    phi[2,5]  R2070     -2.0899999141693115e+00
    phi[2,5]  R2071     -2.0899999141693115e+00
    phi[2,5]  R2072     -3.0999999046325684e+00
    phi[2,5]  R2073     -3.0999999046325684e+00
    phi[2,5]  R2074     -1.4811532199382782e-01
    phi[2,5]  R2075     -1.4165000617504120e-01
    phi[2,5]  R2076     1.4599986076354980e+00
    phi[2,5]  R2077     -1.5486198663711548e+00
    phi[2,5]  R2078     1.1294338703155518e+00
    phi[2,5]  R2079     1.8009097576141357e+00
    phi[2,5]  R2080     2.2220847606658936e+00
    phi[2,5]  R2081     0.531309962272644
    phi[2,5]  R2082     4.3408146500587463e-01
    phi[2,5]  R2083     -1.5024748444557190e-01
    phi[2,5]  R2084     -1.7340061664581299e+00
    phi[2,5]  R2085     -6.2100455164909363e-02
    phi[2,5]  R2086     -1.6835961341857910e+00
    phi[2,5]  R2087     -6.1145722866058350e-01
    phi[2,5]  R2088     -6.5656119585037231e-01
    phi[2,5]  R2089     -7.4085032939910889e-01
    phi[2,5]  R2090     -0.0375056266784668
    phi[2,5]  R2091     -1.6793100833892822e+00
    phi[2,5]  R2092     -3.7340819835662842e-01
    phi[2,5]  R2093     -5.9820175170898438e-01
    phi[2,5]  R2094     1.6160950660705566e+00
    phi[2,5]  R2095     1.5525077581405640e+00
    phi[2,5]  R2096     1.2035214900970459e+00
    phi[2,5]  R2097     1.6387071609497070e+00
    phi[2,5]  R2098     0.531485915184021
    phi[2,5]  R2099     9.4283801317214966e-01
    phi[2,5]  R2100     2.9424183368682861e+00
    phi[2,5]  R2101     2.5396635532379150e+00
    phi[2,5]  R2102     1.5825518369674683e+00
    phi[2,5]  R2103     -3.7100253105163574e+00
    phi[2,5]  R2104     -2.6541557312011719e+00
    phi[2,5]  R2105     -1.1085237264633179e+00
    phi[2,5]  R2106     -1.8074454069137573e+00
    phi[2,5]  R2107     -1.2962071895599365e+00
    phi[2,5]  R2108     -2.3853738307952881e+00
    phi[2,5]  R2109     -2.2767009735107422e+00
    phi[2,5]  R2110     -1.5357433557510376e+00
    phi[2,5]  R2111     -2.29524302482605
    phi[5,2]  R18       -1
    phi[5,2]  R45       1
    phi[5,2]  R46       1
    phi[5,2]  R2112     -3.0999999046325684e+00
    phi[5,2]  R2113     -3.0999999046325684e+00
    phi[5,2]  R2114     -2.2400000095367432e+00
    phi[5,2]  R2115     -2.2400000095367432e+00
    phi[5,2]  R2116     -3.0999999046325684e+00
    phi[5,2]  R2117     -3.0999999046325684e+00
    phi[5,2]  R2118     -2.5699999332427979e+00
    phi[5,2]  R2119     -2.5699999332427979e+00
    phi[5,2]  R2120     -3.0999999046325684e+00
    phi[5,2]  R2121     -3.0999999046325684e+00
    phi[5,2]  R2122     -2.0899999141693115e+00
    phi[5,2]  R2123     -2.0899999141693115e+00
    phi[5,2]  R2124     -3.0999999046325684e+00
    phi[5,2]  R2125     -3.0999999046325684e+00
    phi[5,2]  R2126     1.6160950660705566e+00
    phi[5,2]  R2127     1.5525077581405640e+00
    phi[5,2]  R2128     1.2035214900970459e+00
    phi[5,2]  R2129     1.6387071609497070e+00
    phi[5,2]  R2130     0.531485915184021
    phi[5,2]  R2131     9.4283801317214966e-01
    phi[5,2]  R2132     2.9424183368682861e+00
    phi[5,2]  R2133     2.5396635532379150e+00
    phi[5,2]  R2134     1.5825518369674683e+00
    phi[5,2]  R2135     -3.7100253105163574e+00
    phi[5,2]  R2136     -2.6541557312011719e+00
    phi[5,2]  R2137     -1.1085237264633179e+00
    phi[5,2]  R2138     -1.8074454069137573e+00
    phi[5,2]  R2139     -1.2962071895599365e+00
    phi[5,2]  R2140     -2.3853738307952881e+00
    phi[5,2]  R2141     -2.2767009735107422e+00
    phi[5,2]  R2142     -1.5357433557510376e+00
    phi[5,2]  R2143     -2.29524302482605
    phi[5,2]  R2144     -1.4811532199382782e-01
    phi[5,2]  R2145     -1.4165000617504120e-01
    phi[5,2]  R2146     1.4599986076354980e+00
    phi[5,2]  R2147     -1.5486198663711548e+00
    phi[5,2]  R2148     1.1294338703155518e+00
    phi[5,2]  R2149     1.8009097576141357e+00
    phi[5,2]  R2150     2.2220847606658936e+00
    phi[5,2]  R2151     0.531309962272644
    phi[5,2]  R2152     4.3408146500587463e-01
    phi[5,2]  R2153     -1.5024748444557190e-01
    phi[5,2]  R2154     -1.7340061664581299e+00
    phi[5,2]  R2155     -6.2100455164909363e-02
    phi[5,2]  R2156     -1.6835961341857910e+00
    phi[5,2]  R2157     -6.1145722866058350e-01
    phi[5,2]  R2158     -6.5656119585037231e-01
    phi[5,2]  R2159     -7.4085032939910889e-01
    phi[5,2]  R2160     -0.0375056266784668
    phi[5,2]  R2161     -1.6793100833892822e+00
    phi[5,2]  R2162     -3.7340819835662842e-01
    phi[5,2]  R2163     -5.9820175170898438e-01
    phi[2,7]  R18       1
    phi[2,7]  R19       1
    phi[2,7]  R20       -1.3174708830569632e+00
    phi[2,7]  R21       1.1961691749814782e+00
    phi[2,7]  R22       -1.7349882850569718e+00
    phi[2,7]  R23       -1.8829962717285631e+00
    phi[2,7]  R24       7.1344331022470131e-01
    phi[2,7]  R25       -2.0168091293500976e+00
    phi[2,7]  R26       2.6893778962089789e+00
    phi[2,7]  R55       -1
    phi[2,7]  R2164     -4.4174707876895312e+00
    phi[2,7]  R2165     -1.7825290215756051e+00
    phi[2,7]  R2166     -1.0438308345552649e+00
    phi[2,7]  R2167     -3.4361691845182216e+00
    phi[2,7]  R2168     -4.83498818968954
    phi[2,7]  R2169     -1.3650116195755966e+00
    phi[2,7]  R2170     -4.4529962049713614e+00
    phi[2,7]  R2171     -6.8700366151423475e-01
    phi[2,7]  R2172     -2.3865565944078670e+00
    phi[2,7]  R2173     -3.8134432148572697e+00
    phi[2,7]  R2174     -4.1068090435194087e+00
    phi[2,7]  R2175     -7.3190784819213928e-02
    phi[2,7]  R2176     -4.1062200842358942e-01
    phi[2,7]  R2177     -5.7893778008415477e+00
    phi[2,7]  R2178     -3.1175146972632184e-02
    phi[2,7]  R2179     -3.8889918568785764e-02
    phi[2,7]  R2180     -3.9922963872136119e-02
    phi[2,7]  R2181     -4.3050476254751224e-02
    phi[2,7]  R2182     -5.0900534113472951e-02
    phi[2,7]  R2183     -1.0451671335496893e-01
    phi[2,7]  R2184     -1.5782346887760879e-01
    phi[2,7]  R2185     -1.7584086677492903e+00
    phi[2,7]  R2186     -2.3645652962599311e+00
    phi[2,7]  R2187     -2.2262517418857732e+00
    phi[2,7]  R2188     -1.9425075250074797e-01
    phi[2,7]  R2189     -2.8082121025290896e-01
    phi[2,7]  R2190     -3.0255264521380520e-01
    phi[2,7]  R2191     -4.8987233709437872e-01
    phi[2,7]  R2192     -5.3990141735339714e-01
    phi[2,7]  R2193     -1.5528209263572186e+00
    phi[2,7]  R2194     -1.1440363977376529e+00
    phi[2,7]  R2195     -1.0412920629780980e+00
    phi[2,7]  R2196     -2.9413152778673237e+00
    phi[2,7]  R2197     -3.1996064051202877e+00
    phi[3,4]  R27       1
    phi[3,4]  R28       1
    phi[3,4]  R36       -1
    phi[3,4]  R2198     -3.0999999046325684e+00
    phi[3,4]  R2199     -3.0999999046325684e+00
    phi[3,4]  R2200     -2.2400000095367432e+00
    phi[3,4]  R2201     -2.2400000095367432e+00
    phi[3,4]  R2202     -3.0999999046325684e+00
    phi[3,4]  R2203     -3.0999999046325684e+00
    phi[3,4]  R2204     -2.5699999332427979e+00
    phi[3,4]  R2205     -2.5699999332427979e+00
    phi[3,4]  R2206     -3.0999999046325684e+00
    phi[3,4]  R2207     -3.0999999046325684e+00
    phi[3,4]  R2208     -2.0899999141693115e+00
    phi[3,4]  R2209     -2.0899999141693115e+00
    phi[3,4]  R2210     -3.0999999046325684e+00
    phi[3,4]  R2211     -3.0999999046325684e+00
    phi[3,4]  R2212     -3.2968717813491821e-01
    phi[3,4]  R2213     -1.2211954221129417e-02
    phi[3,4]  R2214     -3.4851789474487305e-01
    phi[3,4]  R2215     -1.1398665904998779e+00
    phi[3,4]  R2216     -7.5816625356674194e-01
    phi[3,4]  R2217     -1.5279697179794312e+00
    phi[3,4]  R2218     -5.8744627237319946e-01
    phi[3,4]  R2219     -1.2614113092422485e+00
    phi[3,4]  R2220     -1.1854155063629150e+00
    phi[3,4]  R2221     -1.1917587518692017e+00
    phi[3,4]  R2222     -1.2978274822235107e+00
    phi[3,4]  R2223     -1.4058381319046021e+00
    phi[3,4]  R2224     -1.5953806638717651e+00
    phi[3,4]  R2225     -1.3632627725601196e+00
    phi[3,4]  R2226     -1.2271962165832520e+00
    phi[3,4]  R2227     -9.3819248676300049e-01
    phi[3,4]  R2228     -1.3784978389739990e+00
    phi[3,4]  R2229     -9.8652297258377075e-01
    phi[3,4]  R2230     -9.5166873931884766e-01
    phi[3,4]  R2231     -1.1387225389480591e+00
    phi[3,4]  R2232     -2.0393207073211670e+00
    phi[3,4]  R2233     -2.0319168567657471e+00
    phi[3,4]  R2234     -2.6202960014343262e+00
    phi[3,4]  R2235     -2.3855347633361816e+00
    phi[3,4]  R2236     -1.2479273080825806e+00
    phi[3,4]  R2237     -1.9184724092483521e+00
    phi[3,4]  R2238     -1.0541521310806274e+00
    phi[3,4]  R2239     -4.6252837777137756e-01
    phi[3,4]  R2240     -1.1056755781173706e+00
    phi[3,4]  R2241     -1.0360604524612427e+00
    phi[3,4]  R2242     -1.4064215421676636e+00
    phi[3,4]  R2243     -1.2700172662734985e+00
    phi[3,4]  R2244     2.0566029846668243e-01
    phi[3,4]  R2245     -5.2357822656631470e-02
    phi[3,4]  R2246     -1.9598065614700317e+00
    phi[3,4]  R2247     -9.4095975160598755e-01
    phi[3,4]  R2248     -2.1293458342552185e-01
    phi[3,4]  R2249     -0.780885636806488
    phi[3,4]  R2250     -4.7005674242973328e-01
    phi[3,4]  R2251     -6.3670128583908081e-01
    phi[3,4]  R2252     -1.0486072301864624e+00
    phi[3,4]  R2253     -1.7706523835659027e-01
    phi[3,4]  R2254     -2.1285901069641113e+00
    phi[3,4]  R2255     -4.2146947979927063e-01
    phi[3,4]  R2256     -5.2710980176925659e-02
    phi[3,4]  R2257     -1.7450313568115234e+00
    phi[3,4]  R2258     -1.2242896556854248e+00
    phi[3,4]  R2259     -1.4072865247726440e+00
    phi[3,4]  R2260     -5.6963962316513062e-01
    phi[3,4]  R2261     -2.33205246925354
    phi[3,4]  R2262     -1.6758900880813599e+00
    phi[3,4]  R2263     -2.3637080192565918e-01
    phi[3,4]  R2264     -2.0622079074382782e-01
    phi[3,4]  R2265     -1.2147315740585327e+00
    phi[3,4]  R2266     -3.8451308012008667e-01
    phi[3,4]  R2267     -5.1501029729843140e-01
    phi[3,4]  R2268     -3.3885970711708069e-01
    phi[3,4]  R2269     -3.6920243501663208e-01
    phi[3,4]  R2270     -4.9957668781280518e-01
    phi[3,4]  R2271     -4.3707442283630371e-01
    phi[3,4]  R2272     -7.7058243751525879e-01
    phi[3,4]  R2273     -1.6418419778347015e-01
    phi[3,4]  R2274     -4.0055418014526367e-01
    phi[3,4]  R2275     -4.5955479145050049e-01
    phi[3,4]  R2276     -3.0197986960411072e-01
    phi[3,4]  R2277     -6.3234555721282959e-01
    phi[3,4]  R2278     -4.3850201368331909e-01
    phi[3,4]  R2279     -1.6481919586658478e-01
    phi[3,4]  R2280     1.8553861975669861e-01
    phi[3,4]  R2281     -9.7381758689880371e-01
    phi[3,4]  R2282     -4.7962141036987305e-01
    phi[3,4]  R2283     -0.418389230966568
    phi[3,4]  R2284     -8.0814039707183838e-01
    phi[3,4]  R2285     -9.3466180562973022e-01
    phi[3,4]  R2286     -5.4314595460891724e-01
    phi[3,4]  R2287     -8.1450074911117554e-01
    phi[3,4]  R2288     -0.547443151473999
    phi[3,4]  R2289     -7.7373385429382324e-01
    phi[3,4]  R2290     -6.6778451204299927e-01
    phi[3,4]  R2291     -0.730191707611084
    phi[3,4]  R2292     -2.7379900217056274e-01
    phi[3,4]  R2293     -3.4759387373924255e-01
    phi[3,4]  R2294     -4.5646631717681885e-01
    phi[3,4]  R2295     -4.08668851852417
    phi[3,4]  R2296     -4.7927138209342957e-01
    phi[3,4]  R2297     -5.3723651170730591e-01
    phi[3,4]  R2298     -1.5418027639389038e+00
    phi[3,4]  R2299     -0.942437469959259
    phi[3,4]  R2300     -1.0453855991363525e+00
    phi[3,4]  R2301     -9.0489536523818970e-01
    phi[4,3]  R27       -1
    phi[4,3]  R36       1
    phi[4,3]  R37       1
    phi[4,3]  R2302     -3.0999999046325684e+00
    phi[4,3]  R2303     -3.0999999046325684e+00
    phi[4,3]  R2304     -2.2400000095367432e+00
    phi[4,3]  R2305     -2.2400000095367432e+00
    phi[4,3]  R2306     -3.0999999046325684e+00
    phi[4,3]  R2307     -3.0999999046325684e+00
    phi[4,3]  R2308     -2.5699999332427979e+00
    phi[4,3]  R2309     -2.5699999332427979e+00
    phi[4,3]  R2310     -3.0999999046325684e+00
    phi[4,3]  R2311     -3.0999999046325684e+00
    phi[4,3]  R2312     -2.0899999141693115e+00
    phi[4,3]  R2313     -2.0899999141693115e+00
    phi[4,3]  R2314     -3.0999999046325684e+00
    phi[4,3]  R2315     -3.0999999046325684e+00
    phi[4,3]  R2316     -1.6758900880813599e+00
    phi[4,3]  R2317     -2.3637080192565918e-01
    phi[4,3]  R2318     -2.0622079074382782e-01
    phi[4,3]  R2319     -1.2147315740585327e+00
    phi[4,3]  R2320     -3.8451308012008667e-01
    phi[4,3]  R2321     -5.1501029729843140e-01
    phi[4,3]  R2322     -3.3885970711708069e-01
    phi[4,3]  R2323     -3.6920243501663208e-01
    phi[4,3]  R2324     -4.9957668781280518e-01
    phi[4,3]  R2325     -4.3707442283630371e-01
    phi[4,3]  R2326     -7.7058243751525879e-01
    phi[4,3]  R2327     -1.6418419778347015e-01
    phi[4,3]  R2328     -4.0055418014526367e-01
    phi[4,3]  R2329     -4.5955479145050049e-01
    phi[4,3]  R2330     -3.0197986960411072e-01
    phi[4,3]  R2331     -6.3234555721282959e-01
    phi[4,3]  R2332     -4.3850201368331909e-01
    phi[4,3]  R2333     -1.6481919586658478e-01
    phi[4,3]  R2334     1.8553861975669861e-01
    phi[4,3]  R2335     -9.7381758689880371e-01
    phi[4,3]  R2336     -4.7962141036987305e-01
    phi[4,3]  R2337     -0.418389230966568
    phi[4,3]  R2338     -8.0814039707183838e-01
    phi[4,3]  R2339     -9.3466180562973022e-01
    phi[4,3]  R2340     -5.4314595460891724e-01
    phi[4,3]  R2341     -8.1450074911117554e-01
    phi[4,3]  R2342     -0.547443151473999
    phi[4,3]  R2343     -7.7373385429382324e-01
    phi[4,3]  R2344     -6.6778451204299927e-01
    phi[4,3]  R2345     -0.730191707611084
    phi[4,3]  R2346     -2.7379900217056274e-01
    phi[4,3]  R2347     -3.4759387373924255e-01
    phi[4,3]  R2348     -4.5646631717681885e-01
    phi[4,3]  R2349     -4.08668851852417
    phi[4,3]  R2350     -4.7927138209342957e-01
    phi[4,3]  R2351     -5.3723651170730591e-01
    phi[4,3]  R2352     -1.5418027639389038e+00
    phi[4,3]  R2353     -0.942437469959259
    phi[4,3]  R2354     -1.0453855991363525e+00
    phi[4,3]  R2355     -9.0489536523818970e-01
    phi[4,3]  R2356     -3.2968717813491821e-01
    phi[4,3]  R2357     -1.2211954221129417e-02
    phi[4,3]  R2358     -3.4851789474487305e-01
    phi[4,3]  R2359     -1.1398665904998779e+00
    phi[4,3]  R2360     -7.5816625356674194e-01
    phi[4,3]  R2361     -1.5279697179794312e+00
    phi[4,3]  R2362     -5.8744627237319946e-01
    phi[4,3]  R2363     -1.2614113092422485e+00
    phi[4,3]  R2364     -1.1854155063629150e+00
    phi[4,3]  R2365     -1.1917587518692017e+00
    phi[4,3]  R2366     -1.2978274822235107e+00
    phi[4,3]  R2367     -1.4058381319046021e+00
    phi[4,3]  R2368     -1.5953806638717651e+00
    phi[4,3]  R2369     -1.3632627725601196e+00
    phi[4,3]  R2370     -1.2271962165832520e+00
    phi[4,3]  R2371     -9.3819248676300049e-01
    phi[4,3]  R2372     -1.3784978389739990e+00
    phi[4,3]  R2373     -9.8652297258377075e-01
    phi[4,3]  R2374     -9.5166873931884766e-01
    phi[4,3]  R2375     -1.1387225389480591e+00
    phi[4,3]  R2376     -2.0393207073211670e+00
    phi[4,3]  R2377     -2.0319168567657471e+00
    phi[4,3]  R2378     -2.6202960014343262e+00
    phi[4,3]  R2379     -2.3855347633361816e+00
    phi[4,3]  R2380     -1.2479273080825806e+00
    phi[4,3]  R2381     -1.9184724092483521e+00
    phi[4,3]  R2382     -1.0541521310806274e+00
    phi[4,3]  R2383     -4.6252837777137756e-01
    phi[4,3]  R2384     -1.1056755781173706e+00
    phi[4,3]  R2385     -1.0360604524612427e+00
    phi[4,3]  R2386     -1.4064215421676636e+00
    phi[4,3]  R2387     -1.2700172662734985e+00
    phi[4,3]  R2388     2.0566029846668243e-01
    phi[4,3]  R2389     -5.2357822656631470e-02
    phi[4,3]  R2390     -1.9598065614700317e+00
    phi[4,3]  R2391     -9.4095975160598755e-01
    phi[4,3]  R2392     -2.1293458342552185e-01
    phi[4,3]  R2393     -0.780885636806488
    phi[4,3]  R2394     -4.7005674242973328e-01
    phi[4,3]  R2395     -6.3670128583908081e-01
    phi[4,3]  R2396     -1.0486072301864624e+00
    phi[4,3]  R2397     -1.7706523835659027e-01
    phi[4,3]  R2398     -2.1285901069641113e+00
    phi[4,3]  R2399     -4.2146947979927063e-01
    phi[4,3]  R2400     -5.2710980176925659e-02
    phi[4,3]  R2401     -1.7450313568115234e+00
    phi[4,3]  R2402     -1.2242896556854248e+00
    phi[4,3]  R2403     -1.4072865247726440e+00
    phi[4,3]  R2404     -5.6963962316513062e-01
    phi[4,3]  R2405     -2.33205246925354
    phi[6,3]  R27       -1
    phi[6,3]  R29       1.5197964678523905e+00
    phi[6,3]  R30       4.5888251338591068e-01
    phi[6,3]  R31       -2.5444511900494429e+00
    phi[6,3]  R32       6.8956310608525584e-02
    phi[6,3]  R33       -0.501981060803316
    phi[6,3]  R34       1.0307052680528703e+00
    phi[6,3]  R35       2.87249774576471
    phi[6,3]  R54       1
    phi[6,3]  R2406     -4.6197963724849593e+00
    phi[6,3]  R2407     -1.5802034367801778e+00
    phi[6,3]  R2408     -2.6988825229226538e+00
    phi[6,3]  R2409     -1.7811174961508325e+00
    phi[6,3]  R2410     -5.5554871458312549e-01
    phi[6,3]  R2411     -5.6444510946820117e+00
    phi[6,3]  R2412     -2.6389562438513234e+00
    phi[6,3]  R2413     -2.5010436226342723e+00
    phi[6,3]  R2414     -2.5980188438292524e+00
    phi[6,3]  R2415     -3.6019809654358843e+00
    phi[6,3]  R2416     -3.1207051822221819e+00
    phi[6,3]  R2417     -1.0592946461164412e+00
    phi[6,3]  R2418     -5.9724976503972780e+00
    phi[6,3]  R2419     -2.2750215886785830e-01
    phi[6,3]  R2420     -4.0429938041814817e-01
    phi[6,3]  R2421     -4.5777044081555668e-01
    phi[6,3]  R2422     -4.6705770019422910e-01
    phi[6,3]  R2423     -4.8601441585529626e-01
    phi[6,3]  R2424     -4.9884119009668931e-01
    phi[6,3]  R2425     -5.0659111016736924e-01
    phi[6,3]  R2426     -1.6116803660969381e+00
    phi[6,3]  R2427     -2.3412683481772687e+00
    phi[6,3]  R2428     -3.0838619465689816e+00
    phi[6,3]  R2429     -3.29847268034931
    phi[6,3]  R2430     -5.8752515828957708e-01
    phi[6,3]  R2431     -0.597430374991344
    phi[6,3]  R2432     -5.9915544226114270e-01
    phi[6,3]  R2433     -6.0924609447760281e-01
    phi[6,3]  R2434     -6.1028897808465410e-01
    phi[6,3]  R2435     -6.2400949028369079e-01
    phi[6,3]  R2436     -6.2440701862759118e-01
    phi[6,3]  R2437     -6.3533398674390007e-01
    phi[6,3]  R2438     -6.4423849112365073e-01
    phi[6,3]  R2439     -6.7375313692631345e-01
    phi[6,3]  R2440     -7.5715479448644474e-01
    phi[6,3]  R2441     -8.2939442823220344e-01
    phi[6,3]  R2442     -8.4105564254809573e-01
    phi[6,3]  R2443     -8.4190513859648308e-01
    phi[6,3]  R2444     -8.4252872171570514e-01
    phi[6,3]  R2445     -8.6553089964885555e-01
    phi[6,3]  R2446     -9.3170418808904143e-01
    phi[6,3]  R2447     -9.3781805243034011e-01
    phi[6,3]  R2448     -9.3976517257202008e-01
    phi[6,3]  R2449     -9.7316642329203606e-01
    phi[6,3]  R2450     -3.7631706649914176e-01
    phi[6,3]  R2451     -4.4322795762464073e-01
    phi[6,3]  R2452     -9.4039385900137629e-01
    phi[6,3]  R2453     -1.0026059341671920e+00
    phi[6,3]  R2454     -1.0147483164681081e+00
    phi[6,3]  R2455     -3.9786540486261779e+00
    phi[6,3]  R2456     -1.0415096808330793e+00
    phi[6,3]  R2457     -1.1591476600322421e+00
    phi[6,3]  R2458     -1.1661464659748324e+00
    phi[6,3]  R2459     -1.1968686570989990e+00
    phi[6,3]  R2460     -0.6506614139194
    phi[6,3]  R2461     -7.1180964498982036e-01
    phi[6,3]  R2462     -4.4723585062338174e+00
    phi[6,3]  R2463     -7.9603454330787193e-01
    phi[6,3]  R2464     -1.8313455506889369e+00
    phi[6,3]  R2465     -1.1697167307776852e+00
    phi[6,3]  R2466     -1.2838067674494342e+00
    phi[6,3]  R2467     -1.2907178113747082e+00
    phi[6,3]  R2468     -1.3109830713762833e+00
    phi[6,3]  R2469     -4.6494649071787233e+00
    phi[4,5]  R36       1
    phi[4,5]  R37       1
    phi[4,5]  R45       -1
    phi[4,5]  R2470     -3.0999999046325684e+00
    phi[4,5]  R2471     -3.0999999046325684e+00
    phi[4,5]  R2472     -2.2400000095367432e+00
    phi[4,5]  R2473     -2.2400000095367432e+00
    phi[4,5]  R2474     -3.0999999046325684e+00
    phi[4,5]  R2475     -3.0999999046325684e+00
    phi[4,5]  R2476     -2.5699999332427979e+00
    phi[4,5]  R2477     -2.5699999332427979e+00
    phi[4,5]  R2478     -3.0999999046325684e+00
    phi[4,5]  R2479     -3.0999999046325684e+00
    phi[4,5]  R2480     -2.0899999141693115e+00
    phi[4,5]  R2481     -2.0899999141693115e+00
    phi[4,5]  R2482     -3.0999999046325684e+00
    phi[4,5]  R2483     -3.0999999046325684e+00
    phi[4,5]  R2484     -1.6758900880813599e+00
    phi[4,5]  R2485     -2.3637080192565918e-01
    phi[4,5]  R2486     -2.0622079074382782e-01
    phi[4,5]  R2487     -1.2147315740585327e+00
    phi[4,5]  R2488     -3.8451308012008667e-01
    phi[4,5]  R2489     -5.1501029729843140e-01
    phi[4,5]  R2490     -3.3885970711708069e-01
    phi[4,5]  R2491     -3.6920243501663208e-01
    phi[4,5]  R2492     -4.9957668781280518e-01
    phi[4,5]  R2493     -4.3707442283630371e-01
    phi[4,5]  R2494     -7.7058243751525879e-01
    phi[4,5]  R2495     -1.6418419778347015e-01
    phi[4,5]  R2496     -4.0055418014526367e-01
    phi[4,5]  R2497     -4.5955479145050049e-01
    phi[4,5]  R2498     -3.0197986960411072e-01
    phi[4,5]  R2499     -6.3234555721282959e-01
    phi[4,5]  R2500     -4.3850201368331909e-01
    phi[4,5]  R2501     -1.6481919586658478e-01
    phi[4,5]  R2502     1.8553861975669861e-01
    phi[4,5]  R2503     -9.7381758689880371e-01
    phi[4,5]  R2504     -4.7962141036987305e-01
    phi[4,5]  R2505     -0.418389230966568
    phi[4,5]  R2506     -8.0814039707183838e-01
    phi[4,5]  R2507     -9.3466180562973022e-01
    phi[4,5]  R2508     -5.4314595460891724e-01
    phi[4,5]  R2509     -8.1450074911117554e-01
    phi[4,5]  R2510     -0.547443151473999
    phi[4,5]  R2511     -7.7373385429382324e-01
    phi[4,5]  R2512     -6.6778451204299927e-01
    phi[4,5]  R2513     -0.730191707611084
    phi[4,5]  R2514     -2.7379900217056274e-01
    phi[4,5]  R2515     -3.4759387373924255e-01
    phi[4,5]  R2516     -4.5646631717681885e-01
    phi[4,5]  R2517     -4.08668851852417
    phi[4,5]  R2518     -4.7927138209342957e-01
    phi[4,5]  R2519     -5.3723651170730591e-01
    phi[4,5]  R2520     -1.5418027639389038e+00
    phi[4,5]  R2521     -0.942437469959259
    phi[4,5]  R2522     -1.0453855991363525e+00
    phi[4,5]  R2523     -9.0489536523818970e-01
    phi[4,5]  R2524     1.6160950660705566e+00
    phi[4,5]  R2525     1.5525077581405640e+00
    phi[4,5]  R2526     1.2035214900970459e+00
    phi[4,5]  R2527     1.6387071609497070e+00
    phi[4,5]  R2528     0.531485915184021
    phi[4,5]  R2529     9.4283801317214966e-01
    phi[4,5]  R2530     2.9424183368682861e+00
    phi[4,5]  R2531     2.5396635532379150e+00
    phi[4,5]  R2532     1.5825518369674683e+00
    phi[4,5]  R2533     -3.7100253105163574e+00
    phi[4,5]  R2534     -2.6541557312011719e+00
    phi[4,5]  R2535     -1.1085237264633179e+00
    phi[4,5]  R2536     -1.8074454069137573e+00
    phi[4,5]  R2537     -1.2962071895599365e+00
    phi[4,5]  R2538     -2.3853738307952881e+00
    phi[4,5]  R2539     -2.2767009735107422e+00
    phi[4,5]  R2540     -1.5357433557510376e+00
    phi[4,5]  R2541     -2.29524302482605
    phi[5,4]  R36       -1
    phi[5,4]  R45       1
    phi[5,4]  R46       1
    phi[5,4]  R2542     -3.0999999046325684e+00
    phi[5,4]  R2543     -3.0999999046325684e+00
    phi[5,4]  R2544     -2.2400000095367432e+00
    phi[5,4]  R2545     -2.2400000095367432e+00
    phi[5,4]  R2546     -3.0999999046325684e+00
    phi[5,4]  R2547     -3.0999999046325684e+00
    phi[5,4]  R2548     -2.5699999332427979e+00
    phi[5,4]  R2549     -2.5699999332427979e+00
    phi[5,4]  R2550     -3.0999999046325684e+00
    phi[5,4]  R2551     -3.0999999046325684e+00
    phi[5,4]  R2552     -2.0899999141693115e+00
    phi[5,4]  R2553     -2.0899999141693115e+00
    phi[5,4]  R2554     -3.0999999046325684e+00
    phi[5,4]  R2555     -3.0999999046325684e+00
    phi[5,4]  R2556     1.6160950660705566e+00
    phi[5,4]  R2557     1.5525077581405640e+00
    phi[5,4]  R2558     1.2035214900970459e+00
    phi[5,4]  R2559     1.6387071609497070e+00
    phi[5,4]  R2560     0.531485915184021
    phi[5,4]  R2561     9.4283801317214966e-01
    phi[5,4]  R2562     2.9424183368682861e+00
    phi[5,4]  R2563     2.5396635532379150e+00
    phi[5,4]  R2564     1.5825518369674683e+00
    phi[5,4]  R2565     -3.7100253105163574e+00
    phi[5,4]  R2566     -2.6541557312011719e+00
    phi[5,4]  R2567     -1.1085237264633179e+00
    phi[5,4]  R2568     -1.8074454069137573e+00
    phi[5,4]  R2569     -1.2962071895599365e+00
    phi[5,4]  R2570     -2.3853738307952881e+00
    phi[5,4]  R2571     -2.2767009735107422e+00
    phi[5,4]  R2572     -1.5357433557510376e+00
    phi[5,4]  R2573     -2.29524302482605
    phi[5,4]  R2574     -1.6758900880813599e+00
    phi[5,4]  R2575     -2.3637080192565918e-01
    phi[5,4]  R2576     -2.0622079074382782e-01
    phi[5,4]  R2577     -1.2147315740585327e+00
    phi[5,4]  R2578     -3.8451308012008667e-01
    phi[5,4]  R2579     -5.1501029729843140e-01
    phi[5,4]  R2580     -3.3885970711708069e-01
    phi[5,4]  R2581     -3.6920243501663208e-01
    phi[5,4]  R2582     -4.9957668781280518e-01
    phi[5,4]  R2583     -4.3707442283630371e-01
    phi[5,4]  R2584     -7.7058243751525879e-01
    phi[5,4]  R2585     -1.6418419778347015e-01
    phi[5,4]  R2586     -4.0055418014526367e-01
    phi[5,4]  R2587     -4.5955479145050049e-01
    phi[5,4]  R2588     -3.0197986960411072e-01
    phi[5,4]  R2589     -6.3234555721282959e-01
    phi[5,4]  R2590     -4.3850201368331909e-01
    phi[5,4]  R2591     -1.6481919586658478e-01
    phi[5,4]  R2592     1.8553861975669861e-01
    phi[5,4]  R2593     -9.7381758689880371e-01
    phi[5,4]  R2594     -4.7962141036987305e-01
    phi[5,4]  R2595     -0.418389230966568
    phi[5,4]  R2596     -8.0814039707183838e-01
    phi[5,4]  R2597     -9.3466180562973022e-01
    phi[5,4]  R2598     -5.4314595460891724e-01
    phi[5,4]  R2599     -8.1450074911117554e-01
    phi[5,4]  R2600     -0.547443151473999
    phi[5,4]  R2601     -7.7373385429382324e-01
    phi[5,4]  R2602     -6.6778451204299927e-01
    phi[5,4]  R2603     -0.730191707611084
    phi[5,4]  R2604     -2.7379900217056274e-01
    phi[5,4]  R2605     -3.4759387373924255e-01
    phi[5,4]  R2606     -4.5646631717681885e-01
    phi[5,4]  R2607     -4.08668851852417
    phi[5,4]  R2608     -4.7927138209342957e-01
    phi[5,4]  R2609     -5.3723651170730591e-01
    phi[5,4]  R2610     -1.5418027639389038e+00
    phi[5,4]  R2611     -0.942437469959259
    phi[5,4]  R2612     -1.0453855991363525e+00
    phi[5,4]  R2613     -9.0489536523818970e-01
    phi[5,7]  R45       1
    phi[5,7]  R46       1
    phi[5,7]  R47       -1.3174708830569632e+00
    phi[5,7]  R48       1.1961691749814782e+00
    phi[5,7]  R49       -1.7349882850569718e+00
    phi[5,7]  R50       -1.8829962717285631e+00
    phi[5,7]  R51       7.1344331022470131e-01
    phi[5,7]  R52       -2.0168091293500976e+00
    phi[5,7]  R53       2.6893778962089789e+00
    phi[5,7]  R55       -1
    phi[5,7]  R2614     -4.4174707876895312e+00
    phi[5,7]  R2615     -1.7825290215756051e+00
    phi[5,7]  R2616     -1.0438308345552649e+00
    phi[5,7]  R2617     -3.4361691845182216e+00
    phi[5,7]  R2618     -4.83498818968954
    phi[5,7]  R2619     -1.3650116195755966e+00
    phi[5,7]  R2620     -4.4529962049713614e+00
    phi[5,7]  R2621     -6.8700366151423475e-01
    phi[5,7]  R2622     -2.3865565944078670e+00
    phi[5,7]  R2623     -3.8134432148572697e+00
    phi[5,7]  R2624     -4.1068090435194087e+00
    phi[5,7]  R2625     -7.3190784819213928e-02
    phi[5,7]  R2626     -4.1062200842358942e-01
    phi[5,7]  R2627     -5.7893778008415477e+00
    phi[5,7]  R2628     -4.8253782592929451e-02
    phi[5,7]  R2629     -5.3227604974402043e-02
    phi[5,7]  R2630     -5.7735619777655511e-02
    phi[5,7]  R2631     -6.0346609690752340e-02
    phi[5,7]  R2632     -8.5890909624669720e-02
    phi[5,7]  R2633     -1.2606835777023284e-01
    phi[5,7]  R2634     -1.2833735553709147e-01
    phi[5,7]  R2635     -1.2892434722681312e-01
    phi[5,7]  R2636     -1.3291753934000816e-01
    phi[5,7]  R2637     -3.4693318038124588e-02
    phi[5,7]  R2638     -2.7280252822665751e-01
    phi[5,7]  R2639     -2.9675340115548710e-01
    phi[5,7]  R2640     -3.9138717396885303e-01
    phi[5,7]  R2641     -4.0361885441096013e-01
    phi[5,7]  R2642     -6.6883518278393583e-01
    phi[5,7]  R2643     -1.3868212373720323e+00
    phi[5,7]  R2644     -1.2365320197988019e+00
    phi[5,7]  R2645     -1.1012264513323098e+00
    MARKER    'MARKER'                 'INTEND'
    z[0,1,0]  R2        -1
    z[0,1,0]  R11       1
    z[0,1,0]  R56       -1
    z[0,1,0]  R57       1
    z[0,1,0]  R70       5.4950445890426636e-01
    z[0,1,0]  R71       2.2566643357276917e-01
    z[0,1,0]  R72       2.4773228168487549e-01
    z[0,1,0]  R73       5.1257789134979248e-01
    z[0,1,0]  R74       3.0807298421859741e-01
    z[0,1,0]  R75       3.7118816375732422e-01
    z[0,1,0]  R76       1.8057993054389954e-01
    z[0,1,0]  R77       2.5131982564926147e-01
    z[0,1,0]  R78       4.9685359001159668e-02
    z[0,1,0]  R79       2.3485079407691956e-01
    z[0,1,0]  R80       -5.6858336925506592e-01
    z[0,1,0]  R81       -6.2251865863800049e-01
    z[0,1,0]  R82       -8.0886995792388916e-01
    z[0,1,0]  R83       -0.775996744632721
    z[0,1,0]  R84       -8.7849384546279907e-01
    z[0,1,0]  R85       -3.0261451005935669e-01
    z[0,1,0]  R86       1.0116262733936310e-01
    z[0,1,0]  R87       -5.1856734789907932e-03
    z[0,1,0]  R88       -2.1734762191772461e-01
    z[0,1,0]  R89       -8.6758226156234741e-02
    z[0,1,0]  R90       7.4900770187377930e-01
    z[0,1,0]  R91       4.9384614825248718e-01
    z[0,1,0]  R92       1.6647800803184509e-01
    z[0,1,0]  R93       2.4530504643917084e-01
    z[0,1,0]  R94       -2.5162574648857117e-01
    z[0,1,0]  R95       -6.1069391667842865e-02
    z[0,1,0]  R96       2.7642402052879333e-01
    z[0,1,0]  R97       -1.0552392154932022e-01
    z[0,1,0]  R98       -5.4880715906620026e-02
    z[0,1,0]  R99       0.0477621927857399
    z[0,1,0]  R100      2.7963241934776306e-01
    z[0,1,0]  R101      3.4242463111877441e-01
    z[0,1,0]  R102      2.7918154001235962e-01
    z[0,1,0]  R103      1.7188704013824463e-01
    z[0,1,0]  R104      2.6724824309349060e-01
    z[0,1,0]  R105      3.3592095971107483e-01
    z[0,1,0]  R106      2.6670613884925842e-01
    z[0,1,0]  R107      2.9679268598556519e-01
    z[0,1,0]  R108      3.2342132925987244e-01
    z[0,1,0]  R109      4.2374247312545776e-01
    z[0,1,0]  R110      5.6757301092147827e-01
    z[0,1,0]  R111      4.6850016713142395e-01
    z[0,1,0]  R112      6.9135004281997681e-01
    z[0,1,0]  R113      5.3372144699096680e-01
    z[0,1,0]  R114      6.4588135480880737e-01
    z[0,1,0]  R115      5.4391831159591675e-01
    z[0,1,0]  R116      2.6483288407325745e-01
    z[0,1,0]  R117      1.2983353435993195e-01
    z[0,1,0]  R118      3.0205753445625305e-01
    z[0,1,0]  R119      -2.7663335204124451e-02
    z[0,1,0]  R120      4.8140409588813782e-01
    z[0,1,0]  R121      -3.3962267637252808e-01
    z[0,1,0]  R122      -9.4367347657680511e-02
    z[0,1,0]  R123      -2.3696716129779816e-01
    z[0,1,0]  R124      -4.0758627653121948e-01
    z[0,1,0]  R125      -3.8331297039985657e-01
    z[0,1,0]  R126      1.3147702813148499e-01
    z[0,1,0]  R127      -6.6205447912216187e-01
    z[0,1,0]  R128      0.0634799376130104
    z[0,1,0]  R129      -4.9066832661628723e-01
    z[0,1,0]  R130      2.5178718566894531e-01
    z[0,1,0]  R131      -1.9391223788261414e-01
    z[0,1,0]  R132      4.9170383810997009e-01
    z[0,1,0]  R133      -2.4322444200515747e-01
    z[0,1,0]  R134      1.0009628534317017e-01
    z[0,1,0]  R135      4.7080019116401672e-01
    z[0,1,0]  R136      -1.3195669651031494e-01
    z[0,1,0]  R137      1.1216656118631363e-01
    z[0,1,0]  R138      5.4910188913345337e-01
    z[0,1,0]  R139      -3.1269797682762146e-01
    z[0,1,0]  R140      4.4816821813583374e-02
    z[0,1,0]  R141      -2.6699263602495193e-02
    z[0,1,0]  R142      5.7596504688262939e-01
    z[0,1,0]  R143      3.8244676589965820e-01
    z[0,1,0]  R144      7.2887712717056274e-01
    z[0,1,0]  R145      1.1982088536024094e-01
    z[0,1,0]  R146      -9.3095436692237854e-02
    z[0,1,0]  R147      7.0091545581817627e-01
    z[0,1,0]  R148      6.5625959634780884e-01
    z[0,1,0]  R149      0.729515790939331
    z[0,1,0]  R150      3.9137899875640869e-01
    z[0,1,0]  R151      5.6989258527755737e-01
    z[0,1,0]  R152      4.3833982944488525e-01
    z[0,1,0]  R153      -0.166781947016716
    z[0,1,0]  R154      -8.5881259292364120e-03
    z[0,1,0]  R155      -1.9071486592292786e-01
    z[0,1,0]  R156      2.8914827108383179e-01
    z[0,1,0]  R157      -3.4472441673278809e-01
    z[0,1,0]  R158      5.1635402441024780e-01
    z[0,1,0]  R159      7.0207953453063965e-02
    z[0,1,0]  R160      5.7533466815948486e-01
    z[0,1,0]  R161      1.5542012453079224e-01
    z[0,1,0]  R162      2.3176409304141998e-01
    z[0,1,0]  R163      -1.0020636767148972e-01
    z[0,1,0]  R164      -0.573139488697052
    z[0,1,0]  R165      -1.4173206686973572e-01
    z[0,1,0]  R166      -4.1580238938331604e-01
    z[0,1,0]  R167      -7.9225033521652222e-01
    z[0,1,0]  R168      -4.2027789354324341e-01
    z[0,1,0]  R169      -3.3313852548599243e-01
    z[0,1,0]  R170      2.9472494125366211e-01
    z[0,1,0]  R171      4.7758859395980835e-01
    z[0,1,0]  R172      0.695899486541748
    z[0,1,0]  R173      4.3001008033752441e-01
    z[0,1,0]  R174      1.0595851391553879e-01
    z[0,1,0]  R175      5.8363842964172363e-01
    z[0,1,0]  R176      0.500739574432373
    z[0,1,0]  R177      -6.7276030778884888e-01
    z[0,1,0]  R178      -0.639201819896698
    z[0,1,0]  R179      -4.3315351009368896e-01
    z[0,1,0]  R180      5.0770324468612671e-01
    z[0,1,0]  R181      6.2168218195438385e-02
    z[0,1,0]  R182      -7.0578551292419434e-01
    z[0,1,0]  R183      -2.9588720202445984e-01
    z[0,1,0]  R184      -4.6263718605041504e-01
    z[0,1,0]  R185      -6.7708253860473633e-01
    z[0,1,0]  R186      -4.0369123220443726e-01
    z[0,1,0]  R187      -6.2100154161453247e-01
    z[0,1,0]  R188      -7.3160064220428467e-01
    z[0,1,0]  R189      -6.7369800806045532e-01
    z[0,1,0]  R190      6.7131519317626953e-01
    z[0,1,0]  R191      3.7447464466094971e-01
    z[0,1,0]  R192      -2.2601333260536194e-01
    z[0,1,0]  R193      -5.8531010150909424e-01
    z[0,1,0]  R194      -2.4237510561943054e-01
    z[0,1,0]  R195      -2.5561258196830750e-01
    z[0,1,0]  R196      -8.8041287660598755e-01
    z[0,1,0]  R197      -5.3718191385269165e-01
    z[0,1,0]  R198      -7.6415562629699707e-01
    z[0,1,0]  R199      -8.0009514093399048e-01
    z[0,1,1]  R3        -1
    z[0,1,1]  R12       1
    z[0,1,1]  R58       -1
    z[0,1,1]  R59       1
    z[0,1,1]  R70       2.2765761613845825e-01
    z[0,1,1]  R71       2.4081312119960785e-01
    z[0,1,1]  R72       -2.9183927178382874e-01
    z[0,1,1]  R73       2.5947010517120361e-01
    z[0,1,1]  R74       4.7376653552055359e-01
    z[0,1,1]  R75       -2.9329755902290344e-01
    z[0,1,1]  R76       -9.7342170774936676e-02
    z[0,1,1]  R77       2.8164383769035339e-01
    z[0,1,1]  R78       -0.471004843711853
    z[0,1,1]  R79       -4.0136891603469849e-01
    z[0,1,1]  R80       -2.5692740082740784e-01
    z[0,1,1]  R81       -1.9757397472858429e-01
    z[0,1,1]  R82       1.1519086360931396e-01
    z[0,1,1]  R83       1.1629398167133331e-01
    z[0,1,1]  R84       -5.3413126617670059e-02
    z[0,1,1]  R85       -1.8432384729385376e-01
    z[0,1,1]  R86       -5.4583436250686646e-01
    z[0,1,1]  R87       -5.0999552011489868e-01
    z[0,1,1]  R88       -8.1726336479187012e-01
    z[0,1,1]  R89       -6.0983031988143921e-01
    z[0,1,1]  R90       3.8077855110168457e-01
    z[0,1,1]  R91       4.7441112995147705e-01
    z[0,1,1]  R92       -7.8147470951080322e-01
    z[0,1,1]  R93       -7.9768645763397217e-01
    z[0,1,1]  R94       8.7103432416915894e-01
    z[0,1,1]  R95       -4.1648185253143311e-01
    z[0,1,1]  R96       1.2210686504840851e-01
    z[0,1,1]  R97       0.944161593914032
    z[0,1,1]  R98       0.759667694568634
    z[0,1,1]  R99       -4.7425386309623718e-01
    z[0,1,1]  R100      3.4309035539627075e-01
    z[0,1,1]  R101      3.0812993645668030e-01
    z[0,1,1]  R102      2.3934613168239594e-01
    z[0,1,1]  R103      -2.9777586460113525e-01
    z[0,1,1]  R104      -1.9624061882495880e-01
    z[0,1,1]  R105      4.1178426146507263e-01
    z[0,1,1]  R106      1.6529412567615509e-01
    z[0,1,1]  R107      5.1155781745910645e-01
    z[0,1,1]  R108      1.5445442497730255e-01
    z[0,1,1]  R109      -3.6533939838409424e-01
    z[0,1,1]  R110      -6.5492558479309082e-01
    z[0,1,1]  R111      -6.9631791114807129e-01
    z[0,1,1]  R112      -5.1652860641479492e-01
    z[0,1,1]  R113      -6.4939856529235840e-01
    z[0,1,1]  R114      -3.6016201972961426e-01
    z[0,1,1]  R115      -4.1192224621772766e-01
    z[0,1,1]  R116      -5.5285841226577759e-01
    z[0,1,1]  R117      -6.5408545732498169e-01
    z[0,1,1]  R118      -4.8382645845413208e-01
    z[0,1,1]  R119      -4.7620588541030884e-01
    z[0,1,1]  R120      0.547591507434845
    z[0,1,1]  R121      2.6197345927357674e-02
    z[0,1,1]  R122      2.6048806309700012e-01
    z[0,1,1]  R123      2.1758790314197540e-01
    z[0,1,1]  R124      1.6954356431961060e-01
    z[0,1,1]  R125      3.9316490292549133e-01
    z[0,1,1]  R126      -7.7843718230724335e-02
    z[0,1,1]  R127      1.7736643552780151e-01
    z[0,1,1]  R128      3.7261933088302612e-01
    z[0,1,1]  R129      3.1868198513984680e-01
    z[0,1,1]  R130      -6.4168584346771240e-01
    z[0,1,1]  R131      -5.1873183250427246e-01
    z[0,1,1]  R132      -5.3301793336868286e-01
    z[0,1,1]  R133      -4.2163071036338806e-01
    z[0,1,1]  R134      -5.7585906237363815e-02
    z[0,1,1]  R135      6.8187665939331055e-01
    z[0,1,1]  R136      -7.6996523141860962e-01
    z[0,1,1]  R137      -5.8149510622024536e-01
    z[0,1,1]  R138      4.9429732561111450e-01
    z[0,1,1]  R139      -4.6810075640678406e-01
    z[0,1,1]  R140      -7.8278720378875732e-01
    z[0,1,1]  R141      -8.3292537927627563e-01
    z[0,1,1]  R142      -5.1259505748748779e-01
    z[0,1,1]  R143      -6.0324513912200928e-01
    z[0,1,1]  R144      3.1696164608001709e-01
    z[0,1,1]  R145      -7.5302451848983765e-01
    z[0,1,1]  R146      -8.0823796987533569e-01
    z[0,1,1]  R147      -3.2325261831283569e-01
    z[0,1,1]  R148      -5.0754940509796143e-01
    z[0,1,1]  R149      3.8729032874107361e-01
    z[0,1,1]  R150      -8.6260598897933960e-01
    z[0,1,1]  R151      6.4150685071945190e-01
    z[0,1,1]  R152      5.9370237588882446e-01
    z[0,1,1]  R153      -6.1903841793537140e-02
    z[0,1,1]  R154      7.4042327702045441e-02
    z[0,1,1]  R155      6.0816723108291626e-01
    z[0,1,1]  R156      2.5047263503074646e-01
    z[0,1,1]  R157      -2.0845349133014679e-01
    z[0,1,1]  R158      3.9893460273742676e-01
    z[0,1,1]  R159      3.3393295598216355e-04
    z[0,1,1]  R160      5.4899090528488159e-01
    z[0,1,1]  R161      -8.4485612809658051e-02
    z[0,1,1]  R162      3.0647762119770050e-02
    z[0,1,1]  R163      3.6442461609840393e-01
    z[0,1,1]  R164      1.4070263504981995e-01
    z[0,1,1]  R165      0.718567967414856
    z[0,1,1]  R166      -1.8699440360069275e-01
    z[0,1,1]  R167      3.5574089735746384e-02
    z[0,1,1]  R168      1.3084031641483307e-01
    z[0,1,1]  R169      -3.3618080615997314e-01
    z[0,1,1]  R170      -0.850028932094574
    z[0,1,1]  R171      -6.1846506595611572e-01
    z[0,1,1]  R172      -3.7172517180442810e-01
    z[0,1,1]  R173      -5.4303795099258423e-01
    z[0,1,1]  R174      -6.5986555814743042e-01
    z[0,1,1]  R175      4.8054805397987366e-01
    z[0,1,1]  R176      1.3738648593425751e-01
    z[0,1,1]  R177      2.1112720668315887e-01
    z[0,1,1]  R178      -9.5226854085922241e-02
    z[0,1,1]  R179      2.2615295648574829e-01
    z[0,1,1]  R180      -6.8314230442047119e-01
    z[0,1,1]  R181      2.7245259284973145e-01
    z[0,1,1]  R182      -1.2807795405387878e-01
    z[0,1,1]  R183      1.5993210673332214e-01
    z[0,1,1]  R184      5.6421858072280884e-01
    z[0,1,1]  R185      1.5317335724830627e-01
    z[0,1,1]  R186      7.8978991508483887e-01
    z[0,1,1]  R187      4.4707828760147095e-01
    z[0,1,1]  R188      4.8379644751548767e-01
    z[0,1,1]  R189      4.0550419688224792e-01
    z[0,1,1]  R190      5.6089580059051514e-01
    z[0,1,1]  R191      -6.9278383255004883e-01
    z[0,1,1]  R192      1.0703387856483459e-01
    z[0,1,1]  R193      9.6009485423564911e-03
    z[0,1,1]  R194      -7.1844294667243958e-02
    z[0,1,1]  R195      -9.6338622272014618e-02
    z[0,1,1]  R196      0.212177112698555
    z[0,1,1]  R197      -3.5925975441932678e-01
    z[0,1,1]  R198      2.7371007204055786e-01
    z[0,1,1]  R199      4.9748173356056213e-01
    z[0,1,2]  R4        -1
    z[0,1,2]  R13       1
    z[0,1,2]  R60       -1
    z[0,1,2]  R61       1
    z[0,1,2]  R70       1.9580762088298798e-01
    z[0,1,2]  R71       3.1615075469017029e-01
    z[0,1,2]  R72       3.2304674386978149e-01
    z[0,1,2]  R73       1.4591987431049347e-01
    z[0,1,2]  R74       2.3431833088397980e-01
    z[0,1,2]  R75       4.8229777812957764e-01
    z[0,1,2]  R76       3.7313434481620789e-01
    z[0,1,2]  R77       4.3597152829170227e-01
    z[0,1,2]  R78       4.0399962663650513e-01
    z[0,1,2]  R79       5.3727221488952637e-01
    z[0,1,2]  R80       -9.5796346664428711e-02
    z[0,1,2]  R81       -0.360103964805603
    z[0,1,2]  R82       -3.0828937888145447e-01
    z[0,1,2]  R83       -1.4103728532791138e-01
    z[0,1,2]  R84       -6.1354603618383408e-02
    z[0,1,2]  R85       -3.6202916502952576e-01
    z[0,1,2]  R86       -2.9099497199058533e-01
    z[0,1,2]  R87       -5.0199472904205322e-01
    z[0,1,2]  R88       1.4629521965980530e-01
    z[0,1,2]  R89       -5.5146467685699463e-01
    z[0,1,2]  R90       -1.1649450659751892e-01
    z[0,1,2]  R91       3.7766832113265991e-01
    z[0,1,2]  R92       -4.6529714018106461e-02
    z[0,1,2]  R93       -3.2391363382339478e-01
    z[0,1,2]  R94       1.1710018664598465e-01
    z[0,1,2]  R95       8.9965946972370148e-02
    z[0,1,2]  R96       -2.5769764184951782e-01
    z[0,1,2]  R97       -1.6945490241050720e-01
    z[0,1,2]  R98       -3.6154675483703613e-01
    z[0,1,2]  R99       -3.6417570710182190e-01
    z[0,1,2]  R100      0.410097599029541
    z[0,1,2]  R101      1.9897668063640594e-01
    z[0,1,2]  R102      3.2608810067176819e-01
    z[0,1,2]  R103      3.4057784080505371e-01
    z[0,1,2]  R104      3.6706885695457458e-01
    z[0,1,2]  R105      2.4889845401048660e-02
    z[0,1,2]  R106      7.7606640756130219e-02
    z[0,1,2]  R107      4.7487378120422363e-01
    z[0,1,2]  R108      2.1392826735973358e-01
    z[0,1,2]  R109      3.6713370680809021e-01
    z[0,1,2]  R110      1.0967803001403809e-01
    z[0,1,2]  R111      -4.1845682263374329e-01
    z[0,1,2]  R112      -1.2607865035533905e-01
    z[0,1,2]  R113      -0.486369788646698
    z[0,1,2]  R114      5.4819411039352417e-01
    z[0,1,2]  R115      0.567703127861023
    z[0,1,2]  R116      3.9514392614364624e-02
    z[0,1,2]  R117      4.5630556344985962e-01
    z[0,1,2]  R118      -2.2555316984653473e-01
    z[0,1,2]  R119      3.5645312070846558e-01
    z[0,1,2]  R120      -4.2175155878067017e-01
    z[0,1,2]  R121      1.6420675441622734e-02
    z[0,1,2]  R122      4.6600274741649628e-02
    z[0,1,2]  R123      -1.8738220632076263e-01
    z[0,1,2]  R124      1.6186399757862091e-01
    z[0,1,2]  R125      1.7931106686592102e-01
    z[0,1,2]  R126      -3.0865499377250671e-01
    z[0,1,2]  R127      -7.1684408187866211e-01
    z[0,1,2]  R128      5.0356465578079224e-01
    z[0,1,2]  R129      -7.8330940008163452e-01
    z[0,1,2]  R130      4.0173164010047913e-01
    z[0,1,2]  R131      6.7916172742843628e-01
    z[0,1,2]  R132      5.6552004814147949e-01
    z[0,1,2]  R133      6.2351912260055542e-01
    z[0,1,2]  R134      2.7996173501014709e-01
    z[0,1,2]  R135      1.4014796912670135e-01
    z[0,1,2]  R136      2.6978957653045654e-01
    z[0,1,2]  R137      -1.8271125853061676e-01
    z[0,1,2]  R138      -3.0887761712074280e-01
    z[0,1,2]  R139      1.8305076658725739e-01
    z[0,1,2]  R140      4.6575519442558289e-01
    z[0,1,2]  R141      4.3002769351005554e-02
    z[0,1,2]  R142      1.5302455425262451e-01
    z[0,1,2]  R143      1.3386055361479521e-03
    z[0,1,2]  R144      1.3925452530384064e-01
    z[0,1,2]  R145      3.2627224922180176e-01
    z[0,1,2]  R146      -7.9252235591411591e-02
    z[0,1,2]  R147      4.8510608077049255e-01
    z[0,1,2]  R148      -1.7540137469768524e-01
    z[0,1,2]  R149      -1.7894359305500984e-02
    z[0,1,2]  R150      -1.7448730766773224e-01
    z[0,1,2]  R151      1.3207750022411346e-01
    z[0,1,2]  R152      -3.6221626400947571e-01
    z[0,1,2]  R153      1.9669516384601593e-01
    z[0,1,2]  R154      4.0278702974319458e-01
    z[0,1,2]  R155      -2.0718200504779816e-01
    z[0,1,2]  R156      -3.5573190450668335e-01
    z[0,1,2]  R157      -6.5912526845932007e-01
    z[0,1,2]  R158      1.1744274944067001e-01
    z[0,1,2]  R159      -7.6905059814453125e-01
    z[0,1,2]  R160      -9.8168686032295227e-02
    z[0,1,2]  R161      9.7359839128330350e-04
    z[0,1,2]  R162      -1.1752710491418839e-01
    z[0,1,2]  R163      1.9486773014068604e-01
    z[0,1,2]  R164      -5.7592725753784180e-01
    z[0,1,2]  R165      -0.561223030090332
    z[0,1,2]  R166      -5.7908612489700317e-01
    z[0,1,2]  R167      -2.6552328467369080e-01
    z[0,1,2]  R168      -6.9777297973632812e-01
    z[0,1,2]  R169      -7.7856051921844482e-01
    z[0,1,2]  R170      -9.9403075873851776e-02
    z[0,1,2]  R171      3.4059146046638489e-01
    z[0,1,2]  R172      1.4632999897003174e-01
    z[0,1,2]  R173      3.2667240500450134e-01
    z[0,1,2]  R174      1.5998254716396332e-01
    z[0,1,2]  R175      -2.1347789466381073e-01
    z[0,1,2]  R176      2.0259141921997070e-01
    z[0,1,2]  R177      -4.5913219451904297e-01
    z[0,1,2]  R178      -5.9972470998764038e-01
    z[0,1,2]  R179      -6.4753305912017822e-01
    z[0,1,2]  R180      -3.3333367109298706e-01
    z[0,1,2]  R181      3.7514597177505493e-01
    z[0,1,2]  R182      -2.6433351635932922e-01
    z[0,1,2]  R183      -7.7267253398895264e-01
    z[0,1,2]  R184      -1.0950347036123276e-01
    z[0,1,2]  R185      4.1314274072647095e-01
    z[0,1,2]  R186      -2.7503243088722229e-01
    z[0,1,2]  R187      -1.9831565022468567e-01
    z[0,1,2]  R188      -8.4968388080596924e-02
    z[0,1,2]  R189      -1.5004470944404602e-01
    z[0,1,2]  R190      -0.174790620803833
    z[0,1,2]  R191      3.1620880961418152e-01
    z[0,1,2]  R192      -6.8193428218364716e-02
    z[0,1,2]  R193      -6.0812151432037354e-01
    z[0,1,2]  R194      -7.1764141321182251e-01
    z[0,1,2]  R195      -8.1184077262878418e-01
    z[0,1,2]  R196      -1.2061801552772522e-01
    z[0,1,2]  R197      1.9096738100051880e-01
    z[0,1,2]  R198      -2.4020045995712280e-01
    z[0,1,2]  R199      -3.7953026592731476e-02
    z[0,1,3]  R5        -1
    z[0,1,3]  R14       1
    z[0,1,3]  R62       -1
    z[0,1,3]  R63       1
    z[0,1,3]  R70       -3.4916356205940247e-01
    z[0,1,3]  R71       -1.7162297666072845e-01
    z[0,1,3]  R72       -1.8864282965660095e-01
    z[0,1,3]  R73       2.3550543934106827e-02
    z[0,1,3]  R74       -0.0916028618812561
    z[0,1,3]  R75       -4.5122930407524109e-01
    z[0,1,3]  R76       1.0401997715234756e-01
    z[0,1,3]  R77       -2.1718591451644897e-01
    z[0,1,3]  R78       -4.6430063247680664e-01
    z[0,1,3]  R79       -5.0557094812393188e-01
    z[0,1,3]  R80       7.0558679103851318e-01
    z[0,1,3]  R81       6.3520252704620361e-01
    z[0,1,3]  R82       4.2031729221343994e-01
    z[0,1,3]  R83       4.5855760574340820e-01
    z[0,1,3]  R84       0.428813636302948
    z[0,1,3]  R85       7.3850327730178833e-01
    z[0,1,3]  R86       6.8741393089294434e-01
    z[0,1,3]  R87       5.9327334165573120e-01
    z[0,1,3]  R88       4.7143629193305969e-01
    z[0,1,3]  R89       3.4902539849281311e-01
    z[0,1,3]  R90       -2.2027720510959625e-01
    z[0,1,3]  R91       -1.4997886121273041e-01
    z[0,1,3]  R92       -1.0772560536861420e-01
    z[0,1,3]  R93       -1.4694376289844513e-01
    z[0,1,3]  R94       -3.6388251930475235e-02
    z[0,1,3]  R95       1.1856950819492340e-01
    z[0,1,3]  R96       -4.1951787471771240e-01
    z[0,1,3]  R97       -8.6664058268070221e-02
    z[0,1,3]  R98       -1.7696432769298553e-03
    z[0,1,3]  R99       -5.7630473375320435e-01
    z[0,1,3]  R100      -1.8432404100894928e-01
    z[0,1,3]  R101      -5.1463800668716431e-01
    z[0,1,3]  R102      -6.4134937524795532e-01
    z[0,1,3]  R103      -4.0266942977905273e-01
    z[0,1,3]  R104      -4.4890768826007843e-02
    z[0,1,3]  R105      -4.6394917368888855e-01
    z[0,1,3]  R106      -3.5040271282196045e-01
    z[0,1,3]  R107      -8.3797693252563477e-02
    z[0,1,3]  R108      -2.0538680255413055e-03
    z[0,1,3]  R109      -3.6634132266044617e-01
    z[0,1,3]  R110      2.8865441679954529e-01
    z[0,1,3]  R111      3.6795396357774734e-02
    z[0,1,3]  R112      -1.4961647987365723e-01
    z[0,1,3]  R113      1.3712696731090546e-01
    z[0,1,3]  R114      6.4623266458511353e-02
    z[0,1,3]  R115      -9.1978013515472412e-02
    z[0,1,3]  R116      5.1226603984832764e-01
    z[0,1,3]  R117      -3.9801809191703796e-01
    z[0,1,3]  R118      -6.0857552289962769e-01
    z[0,1,3]  R119      -5.7703101634979248e-01
    z[0,1,3]  R120      2.6602050662040710e-01
    z[0,1,3]  R121      1.8930549919605255e-01
    z[0,1,3]  R122      6.5145730972290039e-01
    z[0,1,3]  R123      4.7060206532478333e-01
    z[0,1,3]  R124      4.4231966137886047e-01
    z[0,1,3]  R125      3.7852790951728821e-01
    z[0,1,3]  R126      2.2586712241172791e-01
    z[0,1,3]  R127      4.2727984488010406e-02
    z[0,1,3]  R128      5.4297196865081787e-01
    z[0,1,3]  R129      1.6417096555233002e-01
    z[0,1,3]  R130      -4.0744277834892273e-01
    z[0,1,3]  R131      -4.2608398199081421e-01
    z[0,1,3]  R132      1.6876373440027237e-02
    z[0,1,3]  R133      -5.5595141649246216e-01
    z[0,1,3]  R134      0.510107696056366
    z[0,1,3]  R135      2.4046397209167480e-01
    z[0,1,3]  R136      -3.1315666437149048e-01
    z[0,1,3]  R137      2.9579216241836548e-01
    z[0,1,3]  R138      3.9032116532325745e-01
    z[0,1,3]  R139      -7.2604638338088989e-01
    z[0,1,3]  R140      -1.0772946476936340e-01
    z[0,1,3]  R141      -7.8980810940265656e-02
    z[0,1,3]  R142      1.8345648050308228e-01
    z[0,1,3]  R143      3.1382623314857483e-01
    z[0,1,3]  R144      1.4028945565223694e-01
    z[0,1,3]  R145      -4.3615886569023132e-01
    z[0,1,3]  R146      -4.3881252408027649e-01
    z[0,1,3]  R147      1.0959044843912125e-01
    z[0,1,3]  R148      4.7214669175446033e-03
    z[0,1,3]  R149      -1.2928792834281921e-01
    z[0,1,3]  R150      -1.7415136098861694e-01
    z[0,1,3]  R151      7.4559003114700317e-02
    z[0,1,3]  R152      -1.0413333028554916e-01
    z[0,1,3]  R153      1.8462552130222321e-01
    z[0,1,3]  R154      0.713071882724762
    z[0,1,3]  R155      4.2764917016029358e-01
    z[0,1,3]  R156      6.1980700492858887e-01
    z[0,1,3]  R157      3.4250319004058838e-01
    z[0,1,3]  R158      0.574138879776001
    z[0,1,3]  R159      3.9793962240219116e-01
    z[0,1,3]  R160      -6.0092996805906296e-02
    z[0,1,3]  R161      0.777245819568634
    z[0,1,3]  R162      4.5326781272888184e-01
    z[0,1,3]  R163      2.7885380387306213e-01
    z[0,1,3]  R164      3.5766753554344177e-01
    z[0,1,3]  R165      3.2030284404754639e-01
    z[0,1,3]  R166      3.1763064861297607e-01
    z[0,1,3]  R167      3.8000747561454773e-01
    z[0,1,3]  R168      1.2909834086894989e-01
    z[0,1,3]  R169      -2.4669134616851807e-01
    z[0,1,3]  R170      -2.9174787923693657e-03
    z[0,1,3]  R171      -2.8880032896995544e-01
    z[0,1,3]  R172      4.0354898571968079e-01
    z[0,1,3]  R173      1.3501471281051636e-01
    z[0,1,3]  R174      -4.7309798002243042e-01
    z[0,1,3]  R175      -2.9963061213493347e-01
    z[0,1,3]  R176      5.4995840787887573e-01
    z[0,1,3]  R177      4.1433700919151306e-01
    z[0,1,3]  R178      4.0481972694396973e-01
    z[0,1,3]  R179      3.9746868610382080e-01
    z[0,1,3]  R180      -2.1642296016216278e-01
    z[0,1,3]  R181      6.3129258155822754e-01
    z[0,1,3]  R182      4.3214264512062073e-01
    z[0,1,3]  R183      3.4522926807403564e-01
    z[0,1,3]  R184      4.1966402530670166e-01
    z[0,1,3]  R185      3.2063734531402588e-01
    z[0,1,3]  R186      -1.9523462653160095e-01
    z[0,1,3]  R187      -5.5567425489425659e-01
    z[0,1,3]  R188      -4.6835356950759888e-01
    z[0,1,3]  R189      -4.9415045976638794e-01
    z[0,1,3]  R190      -1.4836981892585754e-01
    z[0,1,3]  R191      2.6959040760993958e-01
    z[0,1,3]  R192      5.1917874813079834e-01
    z[0,1,3]  R193      4.2698773741722107e-01
    z[0,1,3]  R194      3.9615362882614136e-01
    z[0,1,3]  R195      2.7314865589141846e-01
    z[0,1,3]  R196      2.4443480372428894e-01
    z[0,1,3]  R197      3.0787822604179382e-01
    z[0,1,3]  R198      -5.2298015356063843e-01
    z[0,1,3]  R199      -2.9256063699722290e-01
    z[0,1,4]  R6        -1
    z[0,1,4]  R15       1
    z[0,1,4]  R64       -1
    z[0,1,4]  R65       1
    z[0,1,4]  R70       2.4349787831306458e-01
    z[0,1,4]  R71       4.0638846158981323e-01
    z[0,1,4]  R72       -8.8096439838409424e-02
    z[0,1,4]  R73       -2.2533057257533073e-02
    z[0,1,4]  R74       -2.1347071230411530e-01
    z[0,1,4]  R75       -3.6403140425682068e-01
    z[0,1,4]  R76       5.3892578929662704e-02
    z[0,1,4]  R77       -2.7593040466308594e-01
    z[0,1,4]  R78       4.3897935748100281e-01
    z[0,1,4]  R79       -1.3020625710487366e-01
    z[0,1,4]  R80       1.1973444372415543e-01
    z[0,1,4]  R81       1.1419614404439926e-01
    z[0,1,4]  R82       -3.6403417587280273e-02
    z[0,1,4]  R83       3.3790281414985657e-01
    z[0,1,4]  R84       1.8731196224689484e-01
    z[0,1,4]  R85       -3.8630706071853638e-01
    z[0,1,4]  R86       2.4383902549743652e-01
    z[0,1,4]  R87       -6.3059397041797638e-02
    z[0,1,4]  R88       -0.080388642847538
    z[0,1,4]  R89       -0.14909727871418
    z[0,1,4]  R90       -0.154183492064476
    z[0,1,4]  R91       5.5469684302806854e-02
    z[0,1,4]  R92       -2.9021957516670227e-01
    z[0,1,4]  R93       2.2349886596202850e-01
    z[0,1,4]  R94       3.6730057001113892e-01
    z[0,1,4]  R95       -2.8336179256439209e-01
    z[0,1,4]  R96       -7.6043003797531128e-01
    z[0,1,4]  R97       -1.2781850062310696e-02
    z[0,1,4]  R98       3.2220616936683655e-01
    z[0,1,4]  R99       -3.0423709750175476e-01
    z[0,1,4]  R100      1.3935865461826324e-01
    z[0,1,4]  R101      -3.3856093883514404e-02
    z[0,1,4]  R102      2.6250863075256348e-01
    z[0,1,4]  R103      2.3572713136672974e-02
    z[0,1,4]  R104      3.6814704537391663e-01
    z[0,1,4]  R105      1.7465278506278992e-01
    z[0,1,4]  R106      3.3341392874717712e-01
    z[0,1,4]  R107      -7.4151274748146534e-04
    z[0,1,4]  R108      2.8366908431053162e-01
    z[0,1,4]  R109      5.4026669263839722e-01
    z[0,1,4]  R110      -2.5515180826187134e-01
    z[0,1,4]  R111      -2.7427467703819275e-01
    z[0,1,4]  R112      -4.2240446805953979e-01
    z[0,1,4]  R113      2.7976479381322861e-02
    z[0,1,4]  R114      -1.7387789487838745e-01
    z[0,1,4]  R115      -4.3352580070495605e-01
    z[0,1,4]  R116      4.0010169148445129e-01
    z[0,1,4]  R117      6.9646663963794708e-02
    z[0,1,4]  R118      -5.0047025084495544e-02
    z[0,1,4]  R119      -4.9046209454536438e-01
    z[0,1,4]  R120      -3.5990697145462036e-01
    z[0,1,4]  R121      9.0682750940322876e-01
    z[0,1,4]  R122      6.9490909576416016e-01
    z[0,1,4]  R123      7.9154515266418457e-01
    z[0,1,4]  R124      7.2009402513504028e-01
    z[0,1,4]  R125      7.0644110441207886e-01
    z[0,1,4]  R126      8.1561535596847534e-01
    z[0,1,4]  R127      -7.3069550096988678e-02
    z[0,1,4]  R128      4.5287674665451050e-01
    z[0,1,4]  R129      1.2962979078292847e-01
    z[0,1,4]  R130      7.9473212361335754e-02
    z[0,1,4]  R131      -1.3623583316802979e-01
    z[0,1,4]  R132      2.1712502837181091e-01
    z[0,1,4]  R133      8.6590774357318878e-02
    z[0,1,4]  R134      7.9303735494613647e-01
    z[0,1,4]  R135      -1.8995349109172821e-01
    z[0,1,4]  R136      4.6238112449645996e-01
    z[0,1,4]  R137      7.1789878606796265e-01
    z[0,1,4]  R138      4.2612543702125549e-01
    z[0,1,4]  R139      -2.2465731203556061e-01
    z[0,1,4]  R140      1.1231165379285812e-01
    z[0,1,4]  R141      4.8143625259399414e-01
    z[0,1,4]  R142      3.1954690814018250e-01
    z[0,1,4]  R143      3.2098862528800964e-01
    z[0,1,4]  R144      -4.3746823072433472e-01
    z[0,1,4]  R145      -1.7073710262775421e-01
    z[0,1,4]  R146      -2.0819954574108124e-02
    z[0,1,4]  R147      -0.0989551842212677
    z[0,1,4]  R148      2.5268995761871338e-01
    z[0,1,4]  R149      1.5949079394340515e-01
    z[0,1,4]  R150      0.136853888630867
    z[0,1,4]  R151      1.7795832455158234e-01
    z[0,1,4]  R152      -1.3361354172229767e-01
    z[0,1,4]  R153      8.3230429887771606e-01
    z[0,1,4]  R154      4.1093739867210388e-01
    z[0,1,4]  R155      5.3052127361297607e-01
    z[0,1,4]  R156      5.1477003097534180e-01
    z[0,1,4]  R157      5.0155729055404663e-01
    z[0,1,4]  R158      2.9172223806381226e-01
    z[0,1,4]  R159      4.8056846857070923e-01
    z[0,1,4]  R160      2.6530984044075012e-01
    z[0,1,4]  R161      5.4606622457504272e-01
    z[0,1,4]  R162      7.8615558147430420e-01
    z[0,1,4]  R163      6.2929922342300415e-01
    z[0,1,4]  R164      2.6644504070281982e-01
    z[0,1,4]  R165      -3.8745053112506866e-02
    z[0,1,4]  R166      2.0344233512878418e-01
    z[0,1,4]  R167      1.7360401153564453e-01
    z[0,1,4]  R168      5.9470452368259430e-02
    z[0,1,4]  R169      2.6736825704574585e-02
    z[0,1,4]  R170      3.3870872855186462e-01
    z[0,1,4]  R171      5.5658571422100067e-02
    z[0,1,4]  R172      -7.8829256817698479e-03
    z[0,1,4]  R173      7.8902617096900940e-02
    z[0,1,4]  R174      1.1656423658132553e-01
    z[0,1,4]  R175      2.7199275791645050e-02
    z[0,1,4]  R176      4.8117798566818237e-01
    z[0,1,4]  R177      3.0255025625228882e-01
    z[0,1,4]  R178      3.3595968037843704e-02
    z[0,1,4]  R179      1.6369393467903137e-01
    z[0,1,4]  R180      -2.9842811822891235e-01
    z[0,1,4]  R181      5.3670382499694824e-01
    z[0,1,4]  R182      4.7548791766166687e-01
    z[0,1,4]  R183      2.9210817813873291e-01
    z[0,1,4]  R184      4.8938098549842834e-01
    z[0,1,4]  R185      3.6667466163635254e-01
    z[0,1,4]  R186      -3.0993974208831787e-01
    z[0,1,4]  R187      -2.1801907569169998e-02
    z[0,1,4]  R188      -6.2543079257011414e-02
    z[0,1,4]  R189      -2.3602099716663361e-01
    z[0,1,4]  R190      8.2893833518028259e-02
    z[0,1,4]  R191      2.8686946630477905e-01
    z[0,1,4]  R192      7.8496611118316650e-01
    z[0,1,4]  R193      1.9304936751723289e-02
    z[0,1,4]  R194      0.449378103017807
    z[0,1,4]  R195      -3.3246347308158875e-01
    z[0,1,4]  R196      -1.7195332795381546e-02
    z[0,1,4]  R197      2.4461318552494049e-01
    z[0,1,4]  R198      1.0814021341502666e-02
    z[0,1,4]  R199      1.1211378872394562e-01
    z[0,1,5]  R7        -1
    z[0,1,5]  R16       1
    z[0,1,5]  R66       -1
    z[0,1,5]  R67       1
    z[0,1,5]  R70       -5.8974957466125488e-01
    z[0,1,5]  R71       -7.7146071195602417e-01
    z[0,1,5]  R72       -8.3842861652374268e-01
    z[0,1,5]  R73       -8.0394911766052246e-01
    z[0,1,5]  R74       -7.3026913404464722e-01
    z[0,1,5]  R75       -4.5336017012596130e-01
    z[0,1,5]  R76       -8.5456639528274536e-01
    z[0,1,5]  R77       -6.8966847658157349e-01
    z[0,1,5]  R78       -4.5109590888023376e-01
    z[0,1,5]  R79       -3.1475964188575745e-01
    z[0,1,5]  R80       2.5751274824142456e-01
    z[0,1,5]  R81       6.0638688504695892e-02
    z[0,1,5]  R82       1.7596489191055298e-01
    z[0,1,5]  R83       1.9838280975818634e-01
    z[0,1,5]  R84       -4.4085253030061722e-02
    z[0,1,5]  R85       -0.192597433924675
    z[0,1,5]  R86       2.7409407496452332e-01
    z[0,1,5]  R87       2.9440104961395264e-01
    z[0,1,5]  R88       4.5299485325813293e-02
    z[0,1,5]  R89       -1.4888846874237061e-01
    z[0,1,5]  R90       4.4473049044609070e-01
    z[0,1,5]  R91       4.8155647516250610e-01
    z[0,1,5]  R92       0.50826096534729
    z[0,1,5]  R93       2.1873778104782104e-01
    z[0,1,5]  R94       1.6478934884071350e-01
    z[0,1,5]  R95       8.0048346519470215e-01
    z[0,1,5]  R96       1.8756695091724396e-01
    z[0,1,5]  R97       4.3293926864862442e-02
    z[0,1,5]  R98       1.7215389013290405e-01
    z[0,1,5]  R99       9.0370990335941315e-02
    z[0,1,5]  R100      -7.4647432565689087e-01
    z[0,1,5]  R101      -6.3916242122650146e-01
    z[0,1,5]  R102      -5.0884467363357544e-01
    z[0,1,5]  R103      -7.2125869989395142e-01
    z[0,1,5]  R104      -7.8055894374847412e-01
    z[0,1,5]  R105      -6.7628163099288940e-01
    z[0,1,5]  R106      -7.5406205654144287e-01
    z[0,1,5]  R107      -5.4106724262237549e-01
    z[0,1,5]  R108      -7.7640181779861450e-01
    z[0,1,5]  R109      -3.3120352029800415e-01
    z[0,1,5]  R110      -1.7839916050434113e-01
    z[0,1,5]  R111      3.4148350358009338e-02
    z[0,1,5]  R112      1.8258308991789818e-02
    z[0,1,5]  R113      -1.8633460998535156e-01
    z[0,1,5]  R114      -1.9224444031715393e-01
    z[0,1,5]  R115      1.1763998866081238e-01
    z[0,1,5]  R116      2.6581385731697083e-01
    z[0,1,5]  R117      -3.4957072138786316e-01
    z[0,1,5]  R118      9.1608978807926178e-02
    z[0,1,5]  R119      4.0881808847188950e-02
    z[0,1,5]  R120      2.3601700365543365e-01
    z[0,1,5]  R121      1.3677023351192474e-01
    z[0,1,5]  R122      7.3405399918556213e-02
    z[0,1,5]  R123      1.0969126969575882e-01
    z[0,1,5]  R124      9.2714056372642517e-02
    z[0,1,5]  R125      1.4815928041934967e-01
    z[0,1,5]  R126      2.1618127822875977e-01
    z[0,1,5]  R127      8.9850440621376038e-02
    z[0,1,5]  R128      3.2188418507575989e-01
    z[0,1,5]  R129      1.1667750775814056e-02
    z[0,1,5]  R130      3.9937481284141541e-01
    z[0,1,5]  R131      -8.7309010326862335e-02
    z[0,1,5]  R132      2.4414394795894623e-01
    z[0,1,5]  R133      2.3820179700851440e-01
    z[0,1,5]  R134      1.0241446644067764e-01
    z[0,1,5]  R135      4.2090556025505066e-01
    z[0,1,5]  R136      -6.4658693969249725e-02
    z[0,1,5]  R137      -1.1355581879615784e-01
    z[0,1,5]  R138      1.5739759802818298e-01
    z[0,1,5]  R139      2.3948132991790771e-01
    z[0,1,5]  R140      2.2364287078380585e-01
    z[0,1,5]  R141      1.7969799041748047e-01
    z[0,1,5]  R142      -3.2613289356231689e-01
    z[0,1,5]  R143      4.9317643046379089e-01
    z[0,1,5]  R144      3.1518206000328064e-01
    z[0,1,5]  R145      -3.0196252465248108e-01
    z[0,1,5]  R146      2.6776146888732910e-01
    z[0,1,5]  R147      3.0875065922737122e-01
    z[0,1,5]  R148      1.9810175895690918e-01
    z[0,1,5]  R149      4.8662075400352478e-01
    z[0,1,5]  R150      1.3925476372241974e-01
    z[0,1,5]  R151      4.4187238812446594e-01
    z[0,1,5]  R152      3.6108088493347168e-01
    z[0,1,5]  R153      4.4546341896057129e-01
    z[0,1,5]  R154      1.2333232164382935e-01
    z[0,1,5]  R155      -1.0340360924601555e-02
    z[0,1,5]  R156      2.5306472182273865e-01
    z[0,1,5]  R157      3.0567046254873276e-02
    z[0,1,5]  R158      1.1456538736820221e-01
    z[0,1,5]  R159      4.9303401261568069e-02
    z[0,1,5]  R160      4.6101510524749756e-01
    z[0,1,5]  R161      3.7257452495396137e-03
    z[0,1,5]  R162      1.2055249512195587e-01
    z[0,1,5]  R163      1.0165440291166306e-01
    z[0,1,5]  R164      -3.0589890480041504e-01
    z[0,1,5]  R165      -1.5219344198703766e-01
    z[0,1,5]  R166      -8.9321933686733246e-02
    z[0,1,5]  R167      -6.7859692499041557e-03
    z[0,1,5]  R168      -1.3576747849583626e-02
    z[0,1,5]  R169      1.4903441071510315e-01
    z[0,1,5]  R170      -0.248980313539505
    z[0,1,5]  R171      -0.105091892182827
    z[0,1,5]  R172      4.3572276830673218e-01
    z[0,1,5]  R173      -5.9681254625320435e-01
    z[0,1,5]  R174      -4.2099773883819580e-01
    z[0,1,5]  R175      4.4694775342941284e-01
    z[0,1,5]  R176      2.5101962685585022e-01
    z[0,1,5]  R177      -1.2519478797912598e-01
    z[0,1,5]  R178      -2.3776248097419739e-01
    z[0,1,5]  R179      -8.8280171155929565e-02
    z[0,1,5]  R180      -1.3381315767765045e-01
    z[0,1,5]  R181      2.9748940467834473e-01
    z[0,1,5]  R182      4.6417381614446640e-02
    z[0,1,5]  R183      -8.5791319608688354e-02
    z[0,1,5]  R184      -1.8986134231090546e-01
    z[0,1,5]  R185      1.2778806686401367e-01
    z[0,1,5]  R186      0.00913998018950224
    z[0,1,5]  R187      1.4865861833095551e-01
    z[0,1,5]  R188      -2.4004525039345026e-03
    z[0,1,5]  R189      -2.4128738045692444e-01
    z[0,1,5]  R190      0.412727415561676
    z[0,1,5]  R191      2.9499068856239319e-01
    z[0,1,5]  R192      2.1359564363956451e-01
    z[0,1,5]  R193      -1.1896307766437531e-01
    z[0,1,5]  R194      2.3534636944532394e-02
    z[0,1,5]  R195      -1.2104593962430954e-01
    z[0,1,5]  R196      6.8074040114879608e-02
    z[0,1,5]  R197      1.6482903063297272e-01
    z[0,1,5]  R198      -8.3766825497150421e-02
    z[0,1,5]  R199      -2.2390339523553848e-02
    z[0,1,6]  R8        -1
    z[0,1,6]  R17       1
    z[0,1,6]  R68       -1
    z[0,1,6]  R69       1
    z[0,1,6]  R70       -2.8082942962646484e-01
    z[0,1,6]  R71       3.7076551467180252e-02
    z[0,1,6]  R72       -5.2817560732364655e-02
    z[0,1,6]  R73       3.5354100167751312e-02
    z[0,1,6]  R74       -1.9615635275840759e-01
    z[0,1,6]  R75       -0.0438479483127594
    z[0,1,6]  R76       2.7327290177345276e-01
    z[0,1,6]  R77       2.6171356439590454e-01
    z[0,1,6]  R78       2.6546157896518707e-02
    z[0,1,6]  R79       3.5136502981185913e-01
    z[0,1,6]  R80       1.5173150599002838e-01
    z[0,1,6]  R81       -1.5349340438842773e-01
    z[0,1,6]  R82       -1.6870924830436707e-01
    z[0,1,6]  R83       -2.4577870965003967e-02
    z[0,1,6]  R84       2.6848694309592247e-02
    z[0,1,6]  R85       -1.0802821815013885e-01
    z[0,1,6]  R86       -5.4732402786612511e-03
    z[0,1,6]  R87       -2.1273775398731232e-01
    z[0,1,6]  R88       1.8075324594974518e-01
    z[0,1,6]  R89       -3.8762119412422180e-01
    z[0,1,6]  R90       -1.0170713067054749e-01
    z[0,1,6]  R91       3.6186963319778442e-01
    z[0,1,6]  R92       0.0724979117512703
    z[0,1,6]  R93       -2.8144511580467224e-01
    z[0,1,6]  R94       2.9696589335799217e-02
    z[0,1,6]  R95       2.8212261199951172e-01
    z[0,1,6]  R96       -0.229871928691864
    z[0,1,6]  R97       -2.4322873353958130e-01
    z[0,1,6]  R98       -0.394614040851593
    z[0,1,6]  R99       -4.5532837510108948e-01
    z[0,1,6]  R100      1.5904265642166138e-01
    z[0,1,6]  R101      0.271445095539093
    z[0,1,6]  R102      -1.3883425295352936e-01
    z[0,1,6]  R103      2.8788670897483826e-01
    z[0,1,6]  R104      9.2242740094661713e-02
    z[0,1,6]  R105      -1.1773692071437836e-01
    z[0,1,6]  R106      -0.304904043674469
    z[0,1,6]  R107      -3.5347026586532593e-01
    z[0,1,6]  R108      -3.7749823927879333e-01
    z[0,1,6]  R109      1.2803323566913605e-01
    z[0,1,6]  R110      2.3802106082439423e-01
    z[0,1,6]  R111      2.0687267184257507e-01
    z[0,1,6]  R112      -1.9543178379535675e-01
    z[0,1,6]  R113      -5.0599705427885056e-02
    z[0,1,6]  R114      -2.8501942753791809e-01
    z[0,1,6]  R115      -4.4072084128856659e-02
    z[0,1,6]  R116      3.5985404253005981e-01
    z[0,1,6]  R117      -2.4825769662857056e-01
    z[0,1,6]  R118      -4.9248144030570984e-01
    z[0,1,6]  R119      -2.6498025655746460e-01
    z[0,1,6]  R120      1.8578261137008667e-01
    z[0,1,6]  R121      -0.0825931504368782
    z[0,1,6]  R122      9.1572798788547516e-02
    z[0,1,6]  R123      3.6711718887090683e-02
    z[0,1,6]  R124      2.3696108162403107e-01
    z[0,1,6]  R125      4.5238483697175980e-02
    z[0,1,6]  R126      -3.4410390257835388e-01
    z[0,1,6]  R127      -0.0334925651550293
    z[0,1,6]  R128      -4.7413217835128307e-03
    z[0,1,6]  R129      -1.4855190180242062e-02
    z[0,1,6]  R130      -1.7784331738948822e-01
    z[0,1,6]  R131      1.5596219897270203e-01
    z[0,1,6]  R132      -2.1742123365402222e-01
    z[0,1,6]  R133      -3.1197572126984596e-02
    z[0,1,6]  R134      -9.3162119388580322e-02
    z[0,1,6]  R135      1.5060979127883911e-01
    z[0,1,6]  R136      -3.0172318220138550e-02
    z[0,1,6]  R137      1.1491342447698116e-02
    z[0,1,6]  R138      -6.6568199545145035e-03
    z[0,1,6]  R139      1.2094780057668686e-01
    z[0,1,6]  R140      3.0671152472496033e-01
    z[0,1,6]  R141      1.8265551328659058e-01
    z[0,1,6]  R142      -3.7411868572235107e-01
    z[0,1,6]  R143      2.1233037114143372e-01
    z[0,1,6]  R144      0.196168914437294
    z[0,1,6]  R145      -3.9702009409666061e-02
    z[0,1,6]  R146      2.5907030701637268e-01
    z[0,1,6]  R147      -2.2752623260021210e-01
    z[0,1,6]  R148      -4.2170169949531555e-01
    z[0,1,6]  R149      -1.9631689786911011e-01
    z[0,1,6]  R150      -6.1951391398906708e-02
    z[0,1,6]  R151      1.1733530461788177e-01
    z[0,1,6]  R152      -4.0632402896881104e-01
    z[0,1,6]  R153      -6.6393963992595673e-02
    z[0,1,6]  R154      3.7370380759239197e-01
    z[0,1,6]  R155      -2.9392614960670471e-01
    z[0,1,6]  R156      -1.1798671633005142e-01
    z[0,1,6]  R157      1.8293111026287079e-01
    z[0,1,6]  R158      -3.6410754919052124e-01
    z[0,1,6]  R159      -1.0908308625221252e-01
    z[0,1,6]  R160      2.6725763082504272e-01
    z[0,1,6]  R161      2.5766745209693909e-01
    z[0,1,6]  R162      -3.0579122900962830e-01
    z[0,1,6]  R163      -5.7885181903839111e-01
    z[0,1,6]  R164      1.6591729223728180e-01
    z[0,1,6]  R165      1.4609168469905853e-01
    z[0,1,6]  R166      -5.5366444587707520e-01
    z[0,1,6]  R167      -3.5493856668472290e-01
    z[0,1,6]  R168      -0.546783983707428
    z[0,1,6]  R169      -2.9336306452751160e-01
    z[0,1,6]  R170      -6.3115954399108887e-02
    z[0,1,6]  R171      -4.1935643553733826e-01
    z[0,1,6]  R172      5.7996802031993866e-02
    z[0,1,6]  R173      -1.8123584985733032e-01
    z[0,1,6]  R174      -0.336314857006073
    z[0,1,6]  R175      -3.0428001284599304e-01
    z[0,1,6]  R176      -3.0388179421424866e-01
    z[0,1,6]  R177      -1.1459008604288101e-01
    z[0,1,6]  R178      -3.3831059932708740e-02
    z[0,1,6]  R179      3.8647550344467163e-01
    z[0,1,6]  R180      -1.0314249992370605e-01
    z[0,1,6]  R181      7.8031592071056366e-02
    z[0,1,6]  R182      -2.4493908509612083e-02
    z[0,1,6]  R183      -2.7924704551696777e-01
    z[0,1,6]  R184      6.3042402267456055e-02
    z[0,1,6]  R185      -3.0630344152450562e-01
    z[0,1,6]  R186      -5.7962872087955475e-02
    z[0,1,6]  R187      -2.0928554236888885e-01
    z[0,1,6]  R188      1.4468098059296608e-02
    z[0,1,6]  R189      3.2767906785011292e-02
    z[0,1,6]  R190      -7.0363827049732208e-02
    z[0,1,6]  R191      1.9452148675918579e-01
    z[0,1,6]  R192      -3.8339901715517044e-02
    z[0,1,6]  R193      3.0110573768615723e-01
    z[0,1,6]  R194      2.4829675257205963e-01
    z[0,1,6]  R195      -2.5787854194641113e-01
    z[0,1,6]  R196      3.1721785664558411e-01
    z[0,1,6]  R197      -6.0341215133666992e-01
    z[0,1,6]  R198      5.3015735000371933e-02
    z[0,1,6]  R199      1.1071027070283890e-01
    z[1,0,0]  R2        1
    z[1,0,0]  R11       -1
    z[1,0,0]  R200      -1
    z[1,0,0]  R201      1
    z[1,0,0]  R214      2.7963241934776306e-01
    z[1,0,0]  R215      3.4242463111877441e-01
    z[1,0,0]  R216      2.7918154001235962e-01
    z[1,0,0]  R217      1.7188704013824463e-01
    z[1,0,0]  R218      2.6724824309349060e-01
    z[1,0,0]  R219      3.3592095971107483e-01
    z[1,0,0]  R220      2.6670613884925842e-01
    z[1,0,0]  R221      2.9679268598556519e-01
    z[1,0,0]  R222      3.2342132925987244e-01
    z[1,0,0]  R223      4.2374247312545776e-01
    z[1,0,0]  R224      5.6757301092147827e-01
    z[1,0,0]  R225      4.6850016713142395e-01
    z[1,0,0]  R226      6.9135004281997681e-01
    z[1,0,0]  R227      5.3372144699096680e-01
    z[1,0,0]  R228      6.4588135480880737e-01
    z[1,0,0]  R229      5.4391831159591675e-01
    z[1,0,0]  R230      2.6483288407325745e-01
    z[1,0,0]  R231      1.2983353435993195e-01
    z[1,0,0]  R232      3.0205753445625305e-01
    z[1,0,0]  R233      -2.7663335204124451e-02
    z[1,0,0]  R234      4.8140409588813782e-01
    z[1,0,0]  R235      -3.3962267637252808e-01
    z[1,0,0]  R236      -9.4367347657680511e-02
    z[1,0,0]  R237      -2.3696716129779816e-01
    z[1,0,0]  R238      -4.0758627653121948e-01
    z[1,0,0]  R239      -3.8331297039985657e-01
    z[1,0,0]  R240      1.3147702813148499e-01
    z[1,0,0]  R241      -6.6205447912216187e-01
    z[1,0,0]  R242      0.0634799376130104
    z[1,0,0]  R243      -4.9066832661628723e-01
    z[1,0,0]  R244      2.5178718566894531e-01
    z[1,0,0]  R245      -1.9391223788261414e-01
    z[1,0,0]  R246      4.9170383810997009e-01
    z[1,0,0]  R247      -2.4322444200515747e-01
    z[1,0,0]  R248      1.0009628534317017e-01
    z[1,0,0]  R249      4.7080019116401672e-01
    z[1,0,0]  R250      -1.3195669651031494e-01
    z[1,0,0]  R251      1.1216656118631363e-01
    z[1,0,0]  R252      5.4910188913345337e-01
    z[1,0,0]  R253      -3.1269797682762146e-01
    z[1,0,0]  R254      4.4816821813583374e-02
    z[1,0,0]  R255      -2.6699263602495193e-02
    z[1,0,0]  R256      5.7596504688262939e-01
    z[1,0,0]  R257      3.8244676589965820e-01
    z[1,0,0]  R258      7.2887712717056274e-01
    z[1,0,0]  R259      1.1982088536024094e-01
    z[1,0,0]  R260      -9.3095436692237854e-02
    z[1,0,0]  R261      7.0091545581817627e-01
    z[1,0,0]  R262      6.5625959634780884e-01
    z[1,0,0]  R263      0.729515790939331
    z[1,0,0]  R264      3.9137899875640869e-01
    z[1,0,0]  R265      5.6989258527755737e-01
    z[1,0,0]  R266      4.3833982944488525e-01
    z[1,0,0]  R267      -0.166781947016716
    z[1,0,0]  R268      -8.5881259292364120e-03
    z[1,0,0]  R269      -1.9071486592292786e-01
    z[1,0,0]  R270      2.8914827108383179e-01
    z[1,0,0]  R271      -3.4472441673278809e-01
    z[1,0,0]  R272      5.1635402441024780e-01
    z[1,0,0]  R273      7.0207953453063965e-02
    z[1,0,0]  R274      5.7533466815948486e-01
    z[1,0,0]  R275      1.5542012453079224e-01
    z[1,0,0]  R276      2.3176409304141998e-01
    z[1,0,0]  R277      -1.0020636767148972e-01
    z[1,0,0]  R278      -0.573139488697052
    z[1,0,0]  R279      -1.4173206686973572e-01
    z[1,0,0]  R280      -4.1580238938331604e-01
    z[1,0,0]  R281      -7.9225033521652222e-01
    z[1,0,0]  R282      -4.2027789354324341e-01
    z[1,0,0]  R283      -3.3313852548599243e-01
    z[1,0,0]  R284      2.9472494125366211e-01
    z[1,0,0]  R285      4.7758859395980835e-01
    z[1,0,0]  R286      0.695899486541748
    z[1,0,0]  R287      4.3001008033752441e-01
    z[1,0,0]  R288      1.0595851391553879e-01
    z[1,0,0]  R289      5.8363842964172363e-01
    z[1,0,0]  R290      0.500739574432373
    z[1,0,0]  R291      -6.7276030778884888e-01
    z[1,0,0]  R292      -0.639201819896698
    z[1,0,0]  R293      -4.3315351009368896e-01
    z[1,0,0]  R294      5.0770324468612671e-01
    z[1,0,0]  R295      6.2168218195438385e-02
    z[1,0,0]  R296      -7.0578551292419434e-01
    z[1,0,0]  R297      -2.9588720202445984e-01
    z[1,0,0]  R298      -4.6263718605041504e-01
    z[1,0,0]  R299      -6.7708253860473633e-01
    z[1,0,0]  R300      -4.0369123220443726e-01
    z[1,0,0]  R301      -6.2100154161453247e-01
    z[1,0,0]  R302      -7.3160064220428467e-01
    z[1,0,0]  R303      -6.7369800806045532e-01
    z[1,0,0]  R304      6.7131519317626953e-01
    z[1,0,0]  R305      3.7447464466094971e-01
    z[1,0,0]  R306      -2.2601333260536194e-01
    z[1,0,0]  R307      -5.8531010150909424e-01
    z[1,0,0]  R308      -2.4237510561943054e-01
    z[1,0,0]  R309      -2.5561258196830750e-01
    z[1,0,0]  R310      -8.8041287660598755e-01
    z[1,0,0]  R311      -5.3718191385269165e-01
    z[1,0,0]  R312      -7.6415562629699707e-01
    z[1,0,0]  R313      -8.0009514093399048e-01
    z[1,0,0]  R314      5.4950445890426636e-01
    z[1,0,0]  R315      2.2566643357276917e-01
    z[1,0,0]  R316      2.4773228168487549e-01
    z[1,0,0]  R317      5.1257789134979248e-01
    z[1,0,0]  R318      3.0807298421859741e-01
    z[1,0,0]  R319      3.7118816375732422e-01
    z[1,0,0]  R320      1.8057993054389954e-01
    z[1,0,0]  R321      2.5131982564926147e-01
    z[1,0,0]  R322      4.9685359001159668e-02
    z[1,0,0]  R323      2.3485079407691956e-01
    z[1,0,0]  R324      -5.6858336925506592e-01
    z[1,0,0]  R325      -6.2251865863800049e-01
    z[1,0,0]  R326      -8.0886995792388916e-01
    z[1,0,0]  R327      -0.775996744632721
    z[1,0,0]  R328      -8.7849384546279907e-01
    z[1,0,0]  R329      -3.0261451005935669e-01
    z[1,0,0]  R330      1.0116262733936310e-01
    z[1,0,0]  R331      -5.1856734789907932e-03
    z[1,0,0]  R332      -2.1734762191772461e-01
    z[1,0,0]  R333      -8.6758226156234741e-02
    z[1,0,0]  R334      7.4900770187377930e-01
    z[1,0,0]  R335      4.9384614825248718e-01
    z[1,0,0]  R336      1.6647800803184509e-01
    z[1,0,0]  R337      2.4530504643917084e-01
    z[1,0,0]  R338      -2.5162574648857117e-01
    z[1,0,0]  R339      -6.1069391667842865e-02
    z[1,0,0]  R340      2.7642402052879333e-01
    z[1,0,0]  R341      -1.0552392154932022e-01
    z[1,0,0]  R342      -5.4880715906620026e-02
    z[1,0,0]  R343      0.0477621927857399
    z[1,0,1]  R3        1
    z[1,0,1]  R12       -1
    z[1,0,1]  R202      -1
    z[1,0,1]  R203      1
    z[1,0,1]  R214      3.4309035539627075e-01
    z[1,0,1]  R215      3.0812993645668030e-01
    z[1,0,1]  R216      2.3934613168239594e-01
    z[1,0,1]  R217      -2.9777586460113525e-01
    z[1,0,1]  R218      -1.9624061882495880e-01
    z[1,0,1]  R219      4.1178426146507263e-01
    z[1,0,1]  R220      1.6529412567615509e-01
    z[1,0,1]  R221      5.1155781745910645e-01
    z[1,0,1]  R222      1.5445442497730255e-01
    z[1,0,1]  R223      -3.6533939838409424e-01
    z[1,0,1]  R224      -6.5492558479309082e-01
    z[1,0,1]  R225      -6.9631791114807129e-01
    z[1,0,1]  R226      -5.1652860641479492e-01
    z[1,0,1]  R227      -6.4939856529235840e-01
    z[1,0,1]  R228      -3.6016201972961426e-01
    z[1,0,1]  R229      -4.1192224621772766e-01
    z[1,0,1]  R230      -5.5285841226577759e-01
    z[1,0,1]  R231      -6.5408545732498169e-01
    z[1,0,1]  R232      -4.8382645845413208e-01
    z[1,0,1]  R233      -4.7620588541030884e-01
    z[1,0,1]  R234      0.547591507434845
    z[1,0,1]  R235      2.6197345927357674e-02
    z[1,0,1]  R236      2.6048806309700012e-01
    z[1,0,1]  R237      2.1758790314197540e-01
    z[1,0,1]  R238      1.6954356431961060e-01
    z[1,0,1]  R239      3.9316490292549133e-01
    z[1,0,1]  R240      -7.7843718230724335e-02
    z[1,0,1]  R241      1.7736643552780151e-01
    z[1,0,1]  R242      3.7261933088302612e-01
    z[1,0,1]  R243      3.1868198513984680e-01
    z[1,0,1]  R244      -6.4168584346771240e-01
    z[1,0,1]  R245      -5.1873183250427246e-01
    z[1,0,1]  R246      -5.3301793336868286e-01
    z[1,0,1]  R247      -4.2163071036338806e-01
    z[1,0,1]  R248      -5.7585906237363815e-02
    z[1,0,1]  R249      6.8187665939331055e-01
    z[1,0,1]  R250      -7.6996523141860962e-01
    z[1,0,1]  R251      -5.8149510622024536e-01
    z[1,0,1]  R252      4.9429732561111450e-01
    z[1,0,1]  R253      -4.6810075640678406e-01
    z[1,0,1]  R254      -7.8278720378875732e-01
    z[1,0,1]  R255      -8.3292537927627563e-01
    z[1,0,1]  R256      -5.1259505748748779e-01
    z[1,0,1]  R257      -6.0324513912200928e-01
    z[1,0,1]  R258      3.1696164608001709e-01
    z[1,0,1]  R259      -7.5302451848983765e-01
    z[1,0,1]  R260      -8.0823796987533569e-01
    z[1,0,1]  R261      -3.2325261831283569e-01
    z[1,0,1]  R262      -5.0754940509796143e-01
    z[1,0,1]  R263      3.8729032874107361e-01
    z[1,0,1]  R264      -8.6260598897933960e-01
    z[1,0,1]  R265      6.4150685071945190e-01
    z[1,0,1]  R266      5.9370237588882446e-01
    z[1,0,1]  R267      -6.1903841793537140e-02
    z[1,0,1]  R268      7.4042327702045441e-02
    z[1,0,1]  R269      6.0816723108291626e-01
    z[1,0,1]  R270      2.5047263503074646e-01
    z[1,0,1]  R271      -2.0845349133014679e-01
    z[1,0,1]  R272      3.9893460273742676e-01
    z[1,0,1]  R273      3.3393295598216355e-04
    z[1,0,1]  R274      5.4899090528488159e-01
    z[1,0,1]  R275      -8.4485612809658051e-02
    z[1,0,1]  R276      3.0647762119770050e-02
    z[1,0,1]  R277      3.6442461609840393e-01
    z[1,0,1]  R278      1.4070263504981995e-01
    z[1,0,1]  R279      0.718567967414856
    z[1,0,1]  R280      -1.8699440360069275e-01
    z[1,0,1]  R281      3.5574089735746384e-02
    z[1,0,1]  R282      1.3084031641483307e-01
    z[1,0,1]  R283      -3.3618080615997314e-01
    z[1,0,1]  R284      -0.850028932094574
    z[1,0,1]  R285      -6.1846506595611572e-01
    z[1,0,1]  R286      -3.7172517180442810e-01
    z[1,0,1]  R287      -5.4303795099258423e-01
    z[1,0,1]  R288      -6.5986555814743042e-01
    z[1,0,1]  R289      4.8054805397987366e-01
    z[1,0,1]  R290      1.3738648593425751e-01
    z[1,0,1]  R291      2.1112720668315887e-01
    z[1,0,1]  R292      -9.5226854085922241e-02
    z[1,0,1]  R293      2.2615295648574829e-01
    z[1,0,1]  R294      -6.8314230442047119e-01
    z[1,0,1]  R295      2.7245259284973145e-01
    z[1,0,1]  R296      -1.2807795405387878e-01
    z[1,0,1]  R297      1.5993210673332214e-01
    z[1,0,1]  R298      5.6421858072280884e-01
    z[1,0,1]  R299      1.5317335724830627e-01
    z[1,0,1]  R300      7.8978991508483887e-01
    z[1,0,1]  R301      4.4707828760147095e-01
    z[1,0,1]  R302      4.8379644751548767e-01
    z[1,0,1]  R303      4.0550419688224792e-01
    z[1,0,1]  R304      5.6089580059051514e-01
    z[1,0,1]  R305      -6.9278383255004883e-01
    z[1,0,1]  R306      1.0703387856483459e-01
    z[1,0,1]  R307      9.6009485423564911e-03
    z[1,0,1]  R308      -7.1844294667243958e-02
    z[1,0,1]  R309      -9.6338622272014618e-02
    z[1,0,1]  R310      0.212177112698555
    z[1,0,1]  R311      -3.5925975441932678e-01
    z[1,0,1]  R312      2.7371007204055786e-01
    z[1,0,1]  R313      4.9748173356056213e-01
    z[1,0,1]  R314      2.2765761613845825e-01
    z[1,0,1]  R315      2.4081312119960785e-01
    z[1,0,1]  R316      -2.9183927178382874e-01
    z[1,0,1]  R317      2.5947010517120361e-01
    z[1,0,1]  R318      4.7376653552055359e-01
    z[1,0,1]  R319      -2.9329755902290344e-01
    z[1,0,1]  R320      -9.7342170774936676e-02
    z[1,0,1]  R321      2.8164383769035339e-01
    z[1,0,1]  R322      -0.471004843711853
    z[1,0,1]  R323      -4.0136891603469849e-01
    z[1,0,1]  R324      -2.5692740082740784e-01
    z[1,0,1]  R325      -1.9757397472858429e-01
    z[1,0,1]  R326      1.1519086360931396e-01
    z[1,0,1]  R327      1.1629398167133331e-01
    z[1,0,1]  R328      -5.3413126617670059e-02
    z[1,0,1]  R329      -1.8432384729385376e-01
    z[1,0,1]  R330      -5.4583436250686646e-01
    z[1,0,1]  R331      -5.0999552011489868e-01
    z[1,0,1]  R332      -8.1726336479187012e-01
    z[1,0,1]  R333      -6.0983031988143921e-01
    z[1,0,1]  R334      3.8077855110168457e-01
    z[1,0,1]  R335      4.7441112995147705e-01
    z[1,0,1]  R336      -7.8147470951080322e-01
    z[1,0,1]  R337      -7.9768645763397217e-01
    z[1,0,1]  R338      8.7103432416915894e-01
    z[1,0,1]  R339      -4.1648185253143311e-01
    z[1,0,1]  R340      1.2210686504840851e-01
    z[1,0,1]  R341      0.944161593914032
    z[1,0,1]  R342      0.759667694568634
    z[1,0,1]  R343      -4.7425386309623718e-01
    z[1,0,2]  R4        1
    z[1,0,2]  R13       -1
    z[1,0,2]  R204      -1
    z[1,0,2]  R205      1
    z[1,0,2]  R214      0.410097599029541
    z[1,0,2]  R215      1.9897668063640594e-01
    z[1,0,2]  R216      3.2608810067176819e-01
    z[1,0,2]  R217      3.4057784080505371e-01
    z[1,0,2]  R218      3.6706885695457458e-01
    z[1,0,2]  R219      2.4889845401048660e-02
    z[1,0,2]  R220      7.7606640756130219e-02
    z[1,0,2]  R221      4.7487378120422363e-01
    z[1,0,2]  R222      2.1392826735973358e-01
    z[1,0,2]  R223      3.6713370680809021e-01
    z[1,0,2]  R224      1.0967803001403809e-01
    z[1,0,2]  R225      -4.1845682263374329e-01
    z[1,0,2]  R226      -1.2607865035533905e-01
    z[1,0,2]  R227      -0.486369788646698
    z[1,0,2]  R228      5.4819411039352417e-01
    z[1,0,2]  R229      0.567703127861023
    z[1,0,2]  R230      3.9514392614364624e-02
    z[1,0,2]  R231      4.5630556344985962e-01
    z[1,0,2]  R232      -2.2555316984653473e-01
    z[1,0,2]  R233      3.5645312070846558e-01
    z[1,0,2]  R234      -4.2175155878067017e-01
    z[1,0,2]  R235      1.6420675441622734e-02
    z[1,0,2]  R236      4.6600274741649628e-02
    z[1,0,2]  R237      -1.8738220632076263e-01
    z[1,0,2]  R238      1.6186399757862091e-01
    z[1,0,2]  R239      1.7931106686592102e-01
    z[1,0,2]  R240      -3.0865499377250671e-01
    z[1,0,2]  R241      -7.1684408187866211e-01
    z[1,0,2]  R242      5.0356465578079224e-01
    z[1,0,2]  R243      -7.8330940008163452e-01
    z[1,0,2]  R244      4.0173164010047913e-01
    z[1,0,2]  R245      6.7916172742843628e-01
    z[1,0,2]  R246      5.6552004814147949e-01
    z[1,0,2]  R247      6.2351912260055542e-01
    z[1,0,2]  R248      2.7996173501014709e-01
    z[1,0,2]  R249      1.4014796912670135e-01
    z[1,0,2]  R250      2.6978957653045654e-01
    z[1,0,2]  R251      -1.8271125853061676e-01
    z[1,0,2]  R252      -3.0887761712074280e-01
    z[1,0,2]  R253      1.8305076658725739e-01
    z[1,0,2]  R254      4.6575519442558289e-01
    z[1,0,2]  R255      4.3002769351005554e-02
    z[1,0,2]  R256      1.5302455425262451e-01
    z[1,0,2]  R257      1.3386055361479521e-03
    z[1,0,2]  R258      1.3925452530384064e-01
    z[1,0,2]  R259      3.2627224922180176e-01
    z[1,0,2]  R260      -7.9252235591411591e-02
    z[1,0,2]  R261      4.8510608077049255e-01
    z[1,0,2]  R262      -1.7540137469768524e-01
    z[1,0,2]  R263      -1.7894359305500984e-02
    z[1,0,2]  R264      -1.7448730766773224e-01
    z[1,0,2]  R265      1.3207750022411346e-01
    z[1,0,2]  R266      -3.6221626400947571e-01
    z[1,0,2]  R267      1.9669516384601593e-01
    z[1,0,2]  R268      4.0278702974319458e-01
    z[1,0,2]  R269      -2.0718200504779816e-01
    z[1,0,2]  R270      -3.5573190450668335e-01
    z[1,0,2]  R271      -6.5912526845932007e-01
    z[1,0,2]  R272      1.1744274944067001e-01
    z[1,0,2]  R273      -7.6905059814453125e-01
    z[1,0,2]  R274      -9.8168686032295227e-02
    z[1,0,2]  R275      9.7359839128330350e-04
    z[1,0,2]  R276      -1.1752710491418839e-01
    z[1,0,2]  R277      1.9486773014068604e-01
    z[1,0,2]  R278      -5.7592725753784180e-01
    z[1,0,2]  R279      -0.561223030090332
    z[1,0,2]  R280      -5.7908612489700317e-01
    z[1,0,2]  R281      -2.6552328467369080e-01
    z[1,0,2]  R282      -6.9777297973632812e-01
    z[1,0,2]  R283      -7.7856051921844482e-01
    z[1,0,2]  R284      -9.9403075873851776e-02
    z[1,0,2]  R285      3.4059146046638489e-01
    z[1,0,2]  R286      1.4632999897003174e-01
    z[1,0,2]  R287      3.2667240500450134e-01
    z[1,0,2]  R288      1.5998254716396332e-01
    z[1,0,2]  R289      -2.1347789466381073e-01
    z[1,0,2]  R290      2.0259141921997070e-01
    z[1,0,2]  R291      -4.5913219451904297e-01
    z[1,0,2]  R292      -5.9972470998764038e-01
    z[1,0,2]  R293      -6.4753305912017822e-01
    z[1,0,2]  R294      -3.3333367109298706e-01
    z[1,0,2]  R295      3.7514597177505493e-01
    z[1,0,2]  R296      -2.6433351635932922e-01
    z[1,0,2]  R297      -7.7267253398895264e-01
    z[1,0,2]  R298      -1.0950347036123276e-01
    z[1,0,2]  R299      4.1314274072647095e-01
    z[1,0,2]  R300      -2.7503243088722229e-01
    z[1,0,2]  R301      -1.9831565022468567e-01
    z[1,0,2]  R302      -8.4968388080596924e-02
    z[1,0,2]  R303      -1.5004470944404602e-01
    z[1,0,2]  R304      -0.174790620803833
    z[1,0,2]  R305      3.1620880961418152e-01
    z[1,0,2]  R306      -6.8193428218364716e-02
    z[1,0,2]  R307      -6.0812151432037354e-01
    z[1,0,2]  R308      -7.1764141321182251e-01
    z[1,0,2]  R309      -8.1184077262878418e-01
    z[1,0,2]  R310      -1.2061801552772522e-01
    z[1,0,2]  R311      1.9096738100051880e-01
    z[1,0,2]  R312      -2.4020045995712280e-01
    z[1,0,2]  R313      -3.7953026592731476e-02
    z[1,0,2]  R314      1.9580762088298798e-01
    z[1,0,2]  R315      3.1615075469017029e-01
    z[1,0,2]  R316      3.2304674386978149e-01
    z[1,0,2]  R317      1.4591987431049347e-01
    z[1,0,2]  R318      2.3431833088397980e-01
    z[1,0,2]  R319      4.8229777812957764e-01
    z[1,0,2]  R320      3.7313434481620789e-01
    z[1,0,2]  R321      4.3597152829170227e-01
    z[1,0,2]  R322      4.0399962663650513e-01
    z[1,0,2]  R323      5.3727221488952637e-01
    z[1,0,2]  R324      -9.5796346664428711e-02
    z[1,0,2]  R325      -0.360103964805603
    z[1,0,2]  R326      -3.0828937888145447e-01
    z[1,0,2]  R327      -1.4103728532791138e-01
    z[1,0,2]  R328      -6.1354603618383408e-02
    z[1,0,2]  R329      -3.6202916502952576e-01
    z[1,0,2]  R330      -2.9099497199058533e-01
    z[1,0,2]  R331      -5.0199472904205322e-01
    z[1,0,2]  R332      1.4629521965980530e-01
    z[1,0,2]  R333      -5.5146467685699463e-01
    z[1,0,2]  R334      -1.1649450659751892e-01
    z[1,0,2]  R335      3.7766832113265991e-01
    z[1,0,2]  R336      -4.6529714018106461e-02
    z[1,0,2]  R337      -3.2391363382339478e-01
    z[1,0,2]  R338      1.1710018664598465e-01
    z[1,0,2]  R339      8.9965946972370148e-02
    z[1,0,2]  R340      -2.5769764184951782e-01
    z[1,0,2]  R341      -1.6945490241050720e-01
    z[1,0,2]  R342      -3.6154675483703613e-01
    z[1,0,2]  R343      -3.6417570710182190e-01
    z[1,0,3]  R5        1
    z[1,0,3]  R14       -1
    z[1,0,3]  R206      -1
    z[1,0,3]  R207      1
    z[1,0,3]  R214      -1.8432404100894928e-01
    z[1,0,3]  R215      -5.1463800668716431e-01
    z[1,0,3]  R216      -6.4134937524795532e-01
    z[1,0,3]  R217      -4.0266942977905273e-01
    z[1,0,3]  R218      -4.4890768826007843e-02
    z[1,0,3]  R219      -4.6394917368888855e-01
    z[1,0,3]  R220      -3.5040271282196045e-01
    z[1,0,3]  R221      -8.3797693252563477e-02
    z[1,0,3]  R222      -2.0538680255413055e-03
    z[1,0,3]  R223      -3.6634132266044617e-01
    z[1,0,3]  R224      2.8865441679954529e-01
    z[1,0,3]  R225      3.6795396357774734e-02
    z[1,0,3]  R226      -1.4961647987365723e-01
    z[1,0,3]  R227      1.3712696731090546e-01
    z[1,0,3]  R228      6.4623266458511353e-02
    z[1,0,3]  R229      -9.1978013515472412e-02
    z[1,0,3]  R230      5.1226603984832764e-01
    z[1,0,3]  R231      -3.9801809191703796e-01
    z[1,0,3]  R232      -6.0857552289962769e-01
    z[1,0,3]  R233      -5.7703101634979248e-01
    z[1,0,3]  R234      2.6602050662040710e-01
    z[1,0,3]  R235      1.8930549919605255e-01
    z[1,0,3]  R236      6.5145730972290039e-01
    z[1,0,3]  R237      4.7060206532478333e-01
    z[1,0,3]  R238      4.4231966137886047e-01
    z[1,0,3]  R239      3.7852790951728821e-01
    z[1,0,3]  R240      2.2586712241172791e-01
    z[1,0,3]  R241      4.2727984488010406e-02
    z[1,0,3]  R242      5.4297196865081787e-01
    z[1,0,3]  R243      1.6417096555233002e-01
    z[1,0,3]  R244      -4.0744277834892273e-01
    z[1,0,3]  R245      -4.2608398199081421e-01
    z[1,0,3]  R246      1.6876373440027237e-02
    z[1,0,3]  R247      -5.5595141649246216e-01
    z[1,0,3]  R248      0.510107696056366
    z[1,0,3]  R249      2.4046397209167480e-01
    z[1,0,3]  R250      -3.1315666437149048e-01
    z[1,0,3]  R251      2.9579216241836548e-01
    z[1,0,3]  R252      3.9032116532325745e-01
    z[1,0,3]  R253      -7.2604638338088989e-01
    z[1,0,3]  R254      -1.0772946476936340e-01
    z[1,0,3]  R255      -7.8980810940265656e-02
    z[1,0,3]  R256      1.8345648050308228e-01
    z[1,0,3]  R257      3.1382623314857483e-01
    z[1,0,3]  R258      1.4028945565223694e-01
    z[1,0,3]  R259      -4.3615886569023132e-01
    z[1,0,3]  R260      -4.3881252408027649e-01
    z[1,0,3]  R261      1.0959044843912125e-01
    z[1,0,3]  R262      4.7214669175446033e-03
    z[1,0,3]  R263      -1.2928792834281921e-01
    z[1,0,3]  R264      -1.7415136098861694e-01
    z[1,0,3]  R265      7.4559003114700317e-02
    z[1,0,3]  R266      -1.0413333028554916e-01
    z[1,0,3]  R267      1.8462552130222321e-01
    z[1,0,3]  R268      0.713071882724762
    z[1,0,3]  R269      4.2764917016029358e-01
    z[1,0,3]  R270      6.1980700492858887e-01
    z[1,0,3]  R271      3.4250319004058838e-01
    z[1,0,3]  R272      0.574138879776001
    z[1,0,3]  R273      3.9793962240219116e-01
    z[1,0,3]  R274      -6.0092996805906296e-02
    z[1,0,3]  R275      0.777245819568634
    z[1,0,3]  R276      4.5326781272888184e-01
    z[1,0,3]  R277      2.7885380387306213e-01
    z[1,0,3]  R278      3.5766753554344177e-01
    z[1,0,3]  R279      3.2030284404754639e-01
    z[1,0,3]  R280      3.1763064861297607e-01
    z[1,0,3]  R281      3.8000747561454773e-01
    z[1,0,3]  R282      1.2909834086894989e-01
    z[1,0,3]  R283      -2.4669134616851807e-01
    z[1,0,3]  R284      -2.9174787923693657e-03
    z[1,0,3]  R285      -2.8880032896995544e-01
    z[1,0,3]  R286      4.0354898571968079e-01
    z[1,0,3]  R287      1.3501471281051636e-01
    z[1,0,3]  R288      -4.7309798002243042e-01
    z[1,0,3]  R289      -2.9963061213493347e-01
    z[1,0,3]  R290      5.4995840787887573e-01
    z[1,0,3]  R291      4.1433700919151306e-01
    z[1,0,3]  R292      4.0481972694396973e-01
    z[1,0,3]  R293      3.9746868610382080e-01
    z[1,0,3]  R294      -2.1642296016216278e-01
    z[1,0,3]  R295      6.3129258155822754e-01
    z[1,0,3]  R296      4.3214264512062073e-01
    z[1,0,3]  R297      3.4522926807403564e-01
    z[1,0,3]  R298      4.1966402530670166e-01
    z[1,0,3]  R299      3.2063734531402588e-01
    z[1,0,3]  R300      -1.9523462653160095e-01
    z[1,0,3]  R301      -5.5567425489425659e-01
    z[1,0,3]  R302      -4.6835356950759888e-01
    z[1,0,3]  R303      -4.9415045976638794e-01
    z[1,0,3]  R304      -1.4836981892585754e-01
    z[1,0,3]  R305      2.6959040760993958e-01
    z[1,0,3]  R306      5.1917874813079834e-01
    z[1,0,3]  R307      4.2698773741722107e-01
    z[1,0,3]  R308      3.9615362882614136e-01
    z[1,0,3]  R309      2.7314865589141846e-01
    z[1,0,3]  R310      2.4443480372428894e-01
    z[1,0,3]  R311      3.0787822604179382e-01
    z[1,0,3]  R312      -5.2298015356063843e-01
    z[1,0,3]  R313      -2.9256063699722290e-01
    z[1,0,3]  R314      -3.4916356205940247e-01
    z[1,0,3]  R315      -1.7162297666072845e-01
    z[1,0,3]  R316      -1.8864282965660095e-01
    z[1,0,3]  R317      2.3550543934106827e-02
    z[1,0,3]  R318      -0.0916028618812561
    z[1,0,3]  R319      -4.5122930407524109e-01
    z[1,0,3]  R320      1.0401997715234756e-01
    z[1,0,3]  R321      -2.1718591451644897e-01
    z[1,0,3]  R322      -4.6430063247680664e-01
    z[1,0,3]  R323      -5.0557094812393188e-01
    z[1,0,3]  R324      7.0558679103851318e-01
    z[1,0,3]  R325      6.3520252704620361e-01
    z[1,0,3]  R326      4.2031729221343994e-01
    z[1,0,3]  R327      4.5855760574340820e-01
    z[1,0,3]  R328      0.428813636302948
    z[1,0,3]  R329      7.3850327730178833e-01
    z[1,0,3]  R330      6.8741393089294434e-01
    z[1,0,3]  R331      5.9327334165573120e-01
    z[1,0,3]  R332      4.7143629193305969e-01
    z[1,0,3]  R333      3.4902539849281311e-01
    z[1,0,3]  R334      -2.2027720510959625e-01
    z[1,0,3]  R335      -1.4997886121273041e-01
    z[1,0,3]  R336      -1.0772560536861420e-01
    z[1,0,3]  R337      -1.4694376289844513e-01
    z[1,0,3]  R338      -3.6388251930475235e-02
    z[1,0,3]  R339      1.1856950819492340e-01
    z[1,0,3]  R340      -4.1951787471771240e-01
    z[1,0,3]  R341      -8.6664058268070221e-02
    z[1,0,3]  R342      -1.7696432769298553e-03
    z[1,0,3]  R343      -5.7630473375320435e-01
    z[1,0,4]  R6        1
    z[1,0,4]  R15       -1
    z[1,0,4]  R208      -1
    z[1,0,4]  R209      1
    z[1,0,4]  R214      1.3935865461826324e-01
    z[1,0,4]  R215      -3.3856093883514404e-02
    z[1,0,4]  R216      2.6250863075256348e-01
    z[1,0,4]  R217      2.3572713136672974e-02
    z[1,0,4]  R218      3.6814704537391663e-01
    z[1,0,4]  R219      1.7465278506278992e-01
    z[1,0,4]  R220      3.3341392874717712e-01
    z[1,0,4]  R221      -7.4151274748146534e-04
    z[1,0,4]  R222      2.8366908431053162e-01
    z[1,0,4]  R223      5.4026669263839722e-01
    z[1,0,4]  R224      -2.5515180826187134e-01
    z[1,0,4]  R225      -2.7427467703819275e-01
    z[1,0,4]  R226      -4.2240446805953979e-01
    z[1,0,4]  R227      2.7976479381322861e-02
    z[1,0,4]  R228      -1.7387789487838745e-01
    z[1,0,4]  R229      -4.3352580070495605e-01
    z[1,0,4]  R230      4.0010169148445129e-01
    z[1,0,4]  R231      6.9646663963794708e-02
    z[1,0,4]  R232      -5.0047025084495544e-02
    z[1,0,4]  R233      -4.9046209454536438e-01
    z[1,0,4]  R234      -3.5990697145462036e-01
    z[1,0,4]  R235      9.0682750940322876e-01
    z[1,0,4]  R236      6.9490909576416016e-01
    z[1,0,4]  R237      7.9154515266418457e-01
    z[1,0,4]  R238      7.2009402513504028e-01
    z[1,0,4]  R239      7.0644110441207886e-01
    z[1,0,4]  R240      8.1561535596847534e-01
    z[1,0,4]  R241      -7.3069550096988678e-02
    z[1,0,4]  R242      4.5287674665451050e-01
    z[1,0,4]  R243      1.2962979078292847e-01
    z[1,0,4]  R244      7.9473212361335754e-02
    z[1,0,4]  R245      -1.3623583316802979e-01
    z[1,0,4]  R246      2.1712502837181091e-01
    z[1,0,4]  R247      8.6590774357318878e-02
    z[1,0,4]  R248      7.9303735494613647e-01
    z[1,0,4]  R249      -1.8995349109172821e-01
    z[1,0,4]  R250      4.6238112449645996e-01
    z[1,0,4]  R251      7.1789878606796265e-01
    z[1,0,4]  R252      4.2612543702125549e-01
    z[1,0,4]  R253      -2.2465731203556061e-01
    z[1,0,4]  R254      1.1231165379285812e-01
    z[1,0,4]  R255      4.8143625259399414e-01
    z[1,0,4]  R256      3.1954690814018250e-01
    z[1,0,4]  R257      3.2098862528800964e-01
    z[1,0,4]  R258      -4.3746823072433472e-01
    z[1,0,4]  R259      -1.7073710262775421e-01
    z[1,0,4]  R260      -2.0819954574108124e-02
    z[1,0,4]  R261      -0.0989551842212677
    z[1,0,4]  R262      2.5268995761871338e-01
    z[1,0,4]  R263      1.5949079394340515e-01
    z[1,0,4]  R264      0.136853888630867
    z[1,0,4]  R265      1.7795832455158234e-01
    z[1,0,4]  R266      -1.3361354172229767e-01
    z[1,0,4]  R267      8.3230429887771606e-01
    z[1,0,4]  R268      4.1093739867210388e-01
    z[1,0,4]  R269      5.3052127361297607e-01
    z[1,0,4]  R270      5.1477003097534180e-01
    z[1,0,4]  R271      5.0155729055404663e-01
    z[1,0,4]  R272      2.9172223806381226e-01
    z[1,0,4]  R273      4.8056846857070923e-01
    z[1,0,4]  R274      2.6530984044075012e-01
    z[1,0,4]  R275      5.4606622457504272e-01
    z[1,0,4]  R276      7.8615558147430420e-01
    z[1,0,4]  R277      6.2929922342300415e-01
    z[1,0,4]  R278      2.6644504070281982e-01
    z[1,0,4]  R279      -3.8745053112506866e-02
    z[1,0,4]  R280      2.0344233512878418e-01
    z[1,0,4]  R281      1.7360401153564453e-01
    z[1,0,4]  R282      5.9470452368259430e-02
    z[1,0,4]  R283      2.6736825704574585e-02
    z[1,0,4]  R284      3.3870872855186462e-01
    z[1,0,4]  R285      5.5658571422100067e-02
    z[1,0,4]  R286      -7.8829256817698479e-03
    z[1,0,4]  R287      7.8902617096900940e-02
    z[1,0,4]  R288      1.1656423658132553e-01
    z[1,0,4]  R289      2.7199275791645050e-02
    z[1,0,4]  R290      4.8117798566818237e-01
    z[1,0,4]  R291      3.0255025625228882e-01
    z[1,0,4]  R292      3.3595968037843704e-02
    z[1,0,4]  R293      1.6369393467903137e-01
    z[1,0,4]  R294      -2.9842811822891235e-01
    z[1,0,4]  R295      5.3670382499694824e-01
    z[1,0,4]  R296      4.7548791766166687e-01
    z[1,0,4]  R297      2.9210817813873291e-01
    z[1,0,4]  R298      4.8938098549842834e-01
    z[1,0,4]  R299      3.6667466163635254e-01
    z[1,0,4]  R300      -3.0993974208831787e-01
    z[1,0,4]  R301      -2.1801907569169998e-02
    z[1,0,4]  R302      -6.2543079257011414e-02
    z[1,0,4]  R303      -2.3602099716663361e-01
    z[1,0,4]  R304      8.2893833518028259e-02
    z[1,0,4]  R305      2.8686946630477905e-01
    z[1,0,4]  R306      7.8496611118316650e-01
    z[1,0,4]  R307      1.9304936751723289e-02
    z[1,0,4]  R308      0.449378103017807
    z[1,0,4]  R309      -3.3246347308158875e-01
    z[1,0,4]  R310      -1.7195332795381546e-02
    z[1,0,4]  R311      2.4461318552494049e-01
    z[1,0,4]  R312      1.0814021341502666e-02
    z[1,0,4]  R313      1.1211378872394562e-01
    z[1,0,4]  R314      2.4349787831306458e-01
    z[1,0,4]  R315      4.0638846158981323e-01
    z[1,0,4]  R316      -8.8096439838409424e-02
    z[1,0,4]  R317      -2.2533057257533073e-02
    z[1,0,4]  R318      -2.1347071230411530e-01
    z[1,0,4]  R319      -3.6403140425682068e-01
    z[1,0,4]  R320      5.3892578929662704e-02
    z[1,0,4]  R321      -2.7593040466308594e-01
    z[1,0,4]  R322      4.3897935748100281e-01
    z[1,0,4]  R323      -1.3020625710487366e-01
    z[1,0,4]  R324      1.1973444372415543e-01
    z[1,0,4]  R325      1.1419614404439926e-01
    z[1,0,4]  R326      -3.6403417587280273e-02
    z[1,0,4]  R327      3.3790281414985657e-01
    z[1,0,4]  R328      1.8731196224689484e-01
    z[1,0,4]  R329      -3.8630706071853638e-01
    z[1,0,4]  R330      2.4383902549743652e-01
    z[1,0,4]  R331      -6.3059397041797638e-02
    z[1,0,4]  R332      -0.080388642847538
    z[1,0,4]  R333      -0.14909727871418
    z[1,0,4]  R334      -0.154183492064476
    z[1,0,4]  R335      5.5469684302806854e-02
    z[1,0,4]  R336      -2.9021957516670227e-01
    z[1,0,4]  R337      2.2349886596202850e-01
    z[1,0,4]  R338      3.6730057001113892e-01
    z[1,0,4]  R339      -2.8336179256439209e-01
    z[1,0,4]  R340      -7.6043003797531128e-01
    z[1,0,4]  R341      -1.2781850062310696e-02
    z[1,0,4]  R342      3.2220616936683655e-01
    z[1,0,4]  R343      -3.0423709750175476e-01
    z[1,0,5]  R7        1
    z[1,0,5]  R16       -1
    z[1,0,5]  R210      -1
    z[1,0,5]  R211      1
    z[1,0,5]  R214      -7.4647432565689087e-01
    z[1,0,5]  R215      -6.3916242122650146e-01
    z[1,0,5]  R216      -5.0884467363357544e-01
    z[1,0,5]  R217      -7.2125869989395142e-01
    z[1,0,5]  R218      -7.8055894374847412e-01
    z[1,0,5]  R219      -6.7628163099288940e-01
    z[1,0,5]  R220      -7.5406205654144287e-01
    z[1,0,5]  R221      -5.4106724262237549e-01
    z[1,0,5]  R222      -7.7640181779861450e-01
    z[1,0,5]  R223      -3.3120352029800415e-01
    z[1,0,5]  R224      -1.7839916050434113e-01
    z[1,0,5]  R225      3.4148350358009338e-02
    z[1,0,5]  R226      1.8258308991789818e-02
    z[1,0,5]  R227      -1.8633460998535156e-01
    z[1,0,5]  R228      -1.9224444031715393e-01
    z[1,0,5]  R229      1.1763998866081238e-01
    z[1,0,5]  R230      2.6581385731697083e-01
    z[1,0,5]  R231      -3.4957072138786316e-01
    z[1,0,5]  R232      9.1608978807926178e-02
    z[1,0,5]  R233      4.0881808847188950e-02
    z[1,0,5]  R234      2.3601700365543365e-01
    z[1,0,5]  R235      1.3677023351192474e-01
    z[1,0,5]  R236      7.3405399918556213e-02
    z[1,0,5]  R237      1.0969126969575882e-01
    z[1,0,5]  R238      9.2714056372642517e-02
    z[1,0,5]  R239      1.4815928041934967e-01
    z[1,0,5]  R240      2.1618127822875977e-01
    z[1,0,5]  R241      8.9850440621376038e-02
    z[1,0,5]  R242      3.2188418507575989e-01
    z[1,0,5]  R243      1.1667750775814056e-02
    z[1,0,5]  R244      3.9937481284141541e-01
    z[1,0,5]  R245      -8.7309010326862335e-02
    z[1,0,5]  R246      2.4414394795894623e-01
    z[1,0,5]  R247      2.3820179700851440e-01
    z[1,0,5]  R248      1.0241446644067764e-01
    z[1,0,5]  R249      4.2090556025505066e-01
    z[1,0,5]  R250      -6.4658693969249725e-02
    z[1,0,5]  R251      -1.1355581879615784e-01
    z[1,0,5]  R252      1.5739759802818298e-01
    z[1,0,5]  R253      2.3948132991790771e-01
    z[1,0,5]  R254      2.2364287078380585e-01
    z[1,0,5]  R255      1.7969799041748047e-01
    z[1,0,5]  R256      -3.2613289356231689e-01
    z[1,0,5]  R257      4.9317643046379089e-01
    z[1,0,5]  R258      3.1518206000328064e-01
    z[1,0,5]  R259      -3.0196252465248108e-01
    z[1,0,5]  R260      2.6776146888732910e-01
    z[1,0,5]  R261      3.0875065922737122e-01
    z[1,0,5]  R262      1.9810175895690918e-01
    z[1,0,5]  R263      4.8662075400352478e-01
    z[1,0,5]  R264      1.3925476372241974e-01
    z[1,0,5]  R265      4.4187238812446594e-01
    z[1,0,5]  R266      3.6108088493347168e-01
    z[1,0,5]  R267      4.4546341896057129e-01
    z[1,0,5]  R268      1.2333232164382935e-01
    z[1,0,5]  R269      -1.0340360924601555e-02
    z[1,0,5]  R270      2.5306472182273865e-01
    z[1,0,5]  R271      3.0567046254873276e-02
    z[1,0,5]  R272      1.1456538736820221e-01
    z[1,0,5]  R273      4.9303401261568069e-02
    z[1,0,5]  R274      4.6101510524749756e-01
    z[1,0,5]  R275      3.7257452495396137e-03
    z[1,0,5]  R276      1.2055249512195587e-01
    z[1,0,5]  R277      1.0165440291166306e-01
    z[1,0,5]  R278      -3.0589890480041504e-01
    z[1,0,5]  R279      -1.5219344198703766e-01
    z[1,0,5]  R280      -8.9321933686733246e-02
    z[1,0,5]  R281      -6.7859692499041557e-03
    z[1,0,5]  R282      -1.3576747849583626e-02
    z[1,0,5]  R283      1.4903441071510315e-01
    z[1,0,5]  R284      -0.248980313539505
    z[1,0,5]  R285      -0.105091892182827
    z[1,0,5]  R286      4.3572276830673218e-01
    z[1,0,5]  R287      -5.9681254625320435e-01
    z[1,0,5]  R288      -4.2099773883819580e-01
    z[1,0,5]  R289      4.4694775342941284e-01
    z[1,0,5]  R290      2.5101962685585022e-01
    z[1,0,5]  R291      -1.2519478797912598e-01
    z[1,0,5]  R292      -2.3776248097419739e-01
    z[1,0,5]  R293      -8.8280171155929565e-02
    z[1,0,5]  R294      -1.3381315767765045e-01
    z[1,0,5]  R295      2.9748940467834473e-01
    z[1,0,5]  R296      4.6417381614446640e-02
    z[1,0,5]  R297      -8.5791319608688354e-02
    z[1,0,5]  R298      -1.8986134231090546e-01
    z[1,0,5]  R299      1.2778806686401367e-01
    z[1,0,5]  R300      0.00913998018950224
    z[1,0,5]  R301      1.4865861833095551e-01
    z[1,0,5]  R302      -2.4004525039345026e-03
    z[1,0,5]  R303      -2.4128738045692444e-01
    z[1,0,5]  R304      0.412727415561676
    z[1,0,5]  R305      2.9499068856239319e-01
    z[1,0,5]  R306      2.1359564363956451e-01
    z[1,0,5]  R307      -1.1896307766437531e-01
    z[1,0,5]  R308      2.3534636944532394e-02
    z[1,0,5]  R309      -1.2104593962430954e-01
    z[1,0,5]  R310      6.8074040114879608e-02
    z[1,0,5]  R311      1.6482903063297272e-01
    z[1,0,5]  R312      -8.3766825497150421e-02
    z[1,0,5]  R313      -2.2390339523553848e-02
    z[1,0,5]  R314      -5.8974957466125488e-01
    z[1,0,5]  R315      -7.7146071195602417e-01
    z[1,0,5]  R316      -8.3842861652374268e-01
    z[1,0,5]  R317      -8.0394911766052246e-01
    z[1,0,5]  R318      -7.3026913404464722e-01
    z[1,0,5]  R319      -4.5336017012596130e-01
    z[1,0,5]  R320      -8.5456639528274536e-01
    z[1,0,5]  R321      -6.8966847658157349e-01
    z[1,0,5]  R322      -4.5109590888023376e-01
    z[1,0,5]  R323      -3.1475964188575745e-01
    z[1,0,5]  R324      2.5751274824142456e-01
    z[1,0,5]  R325      6.0638688504695892e-02
    z[1,0,5]  R326      1.7596489191055298e-01
    z[1,0,5]  R327      1.9838280975818634e-01
    z[1,0,5]  R328      -4.4085253030061722e-02
    z[1,0,5]  R329      -0.192597433924675
    z[1,0,5]  R330      2.7409407496452332e-01
    z[1,0,5]  R331      2.9440104961395264e-01
    z[1,0,5]  R332      4.5299485325813293e-02
    z[1,0,5]  R333      -1.4888846874237061e-01
    z[1,0,5]  R334      4.4473049044609070e-01
    z[1,0,5]  R335      4.8155647516250610e-01
    z[1,0,5]  R336      0.50826096534729
    z[1,0,5]  R337      2.1873778104782104e-01
    z[1,0,5]  R338      1.6478934884071350e-01
    z[1,0,5]  R339      8.0048346519470215e-01
    z[1,0,5]  R340      1.8756695091724396e-01
    z[1,0,5]  R341      4.3293926864862442e-02
    z[1,0,5]  R342      1.7215389013290405e-01
    z[1,0,5]  R343      9.0370990335941315e-02
    z[1,0,6]  R8        1
    z[1,0,6]  R17       -1
    z[1,0,6]  R212      -1
    z[1,0,6]  R213      1
    z[1,0,6]  R214      1.5904265642166138e-01
    z[1,0,6]  R215      0.271445095539093
    z[1,0,6]  R216      -1.3883425295352936e-01
    z[1,0,6]  R217      2.8788670897483826e-01
    z[1,0,6]  R218      9.2242740094661713e-02
    z[1,0,6]  R219      -1.1773692071437836e-01
    z[1,0,6]  R220      -0.304904043674469
    z[1,0,6]  R221      -3.5347026586532593e-01
    z[1,0,6]  R222      -3.7749823927879333e-01
    z[1,0,6]  R223      1.2803323566913605e-01
    z[1,0,6]  R224      2.3802106082439423e-01
    z[1,0,6]  R225      2.0687267184257507e-01
    z[1,0,6]  R226      -1.9543178379535675e-01
    z[1,0,6]  R227      -5.0599705427885056e-02
    z[1,0,6]  R228      -2.8501942753791809e-01
    z[1,0,6]  R229      -4.4072084128856659e-02
    z[1,0,6]  R230      3.5985404253005981e-01
    z[1,0,6]  R231      -2.4825769662857056e-01
    z[1,0,6]  R232      -4.9248144030570984e-01
    z[1,0,6]  R233      -2.6498025655746460e-01
    z[1,0,6]  R234      1.8578261137008667e-01
    z[1,0,6]  R235      -0.0825931504368782
    z[1,0,6]  R236      9.1572798788547516e-02
    z[1,0,6]  R237      3.6711718887090683e-02
    z[1,0,6]  R238      2.3696108162403107e-01
    z[1,0,6]  R239      4.5238483697175980e-02
    z[1,0,6]  R240      -3.4410390257835388e-01
    z[1,0,6]  R241      -0.0334925651550293
    z[1,0,6]  R242      -4.7413217835128307e-03
    z[1,0,6]  R243      -1.4855190180242062e-02
    z[1,0,6]  R244      -1.7784331738948822e-01
    z[1,0,6]  R245      1.5596219897270203e-01
    z[1,0,6]  R246      -2.1742123365402222e-01
    z[1,0,6]  R247      -3.1197572126984596e-02
    z[1,0,6]  R248      -9.3162119388580322e-02
    z[1,0,6]  R249      1.5060979127883911e-01
    z[1,0,6]  R250      -3.0172318220138550e-02
    z[1,0,6]  R251      1.1491342447698116e-02
    z[1,0,6]  R252      -6.6568199545145035e-03
    z[1,0,6]  R253      1.2094780057668686e-01
    z[1,0,6]  R254      3.0671152472496033e-01
    z[1,0,6]  R255      1.8265551328659058e-01
    z[1,0,6]  R256      -3.7411868572235107e-01
    z[1,0,6]  R257      2.1233037114143372e-01
    z[1,0,6]  R258      0.196168914437294
    z[1,0,6]  R259      -3.9702009409666061e-02
    z[1,0,6]  R260      2.5907030701637268e-01
    z[1,0,6]  R261      -2.2752623260021210e-01
    z[1,0,6]  R262      -4.2170169949531555e-01
    z[1,0,6]  R263      -1.9631689786911011e-01
    z[1,0,6]  R264      -6.1951391398906708e-02
    z[1,0,6]  R265      1.1733530461788177e-01
    z[1,0,6]  R266      -4.0632402896881104e-01
    z[1,0,6]  R267      -6.6393963992595673e-02
    z[1,0,6]  R268      3.7370380759239197e-01
    z[1,0,6]  R269      -2.9392614960670471e-01
    z[1,0,6]  R270      -1.1798671633005142e-01
    z[1,0,6]  R271      1.8293111026287079e-01
    z[1,0,6]  R272      -3.6410754919052124e-01
    z[1,0,6]  R273      -1.0908308625221252e-01
    z[1,0,6]  R274      2.6725763082504272e-01
    z[1,0,6]  R275      2.5766745209693909e-01
    z[1,0,6]  R276      -3.0579122900962830e-01
    z[1,0,6]  R277      -5.7885181903839111e-01
    z[1,0,6]  R278      1.6591729223728180e-01
    z[1,0,6]  R279      1.4609168469905853e-01
    z[1,0,6]  R280      -5.5366444587707520e-01
    z[1,0,6]  R281      -3.5493856668472290e-01
    z[1,0,6]  R282      -0.546783983707428
    z[1,0,6]  R283      -2.9336306452751160e-01
    z[1,0,6]  R284      -6.3115954399108887e-02
    z[1,0,6]  R285      -4.1935643553733826e-01
    z[1,0,6]  R286      5.7996802031993866e-02
    z[1,0,6]  R287      -1.8123584985733032e-01
    z[1,0,6]  R288      -0.336314857006073
    z[1,0,6]  R289      -3.0428001284599304e-01
    z[1,0,6]  R290      -3.0388179421424866e-01
    z[1,0,6]  R291      -1.1459008604288101e-01
    z[1,0,6]  R292      -3.3831059932708740e-02
    z[1,0,6]  R293      3.8647550344467163e-01
    z[1,0,6]  R294      -1.0314249992370605e-01
    z[1,0,6]  R295      7.8031592071056366e-02
    z[1,0,6]  R296      -2.4493908509612083e-02
    z[1,0,6]  R297      -2.7924704551696777e-01
    z[1,0,6]  R298      6.3042402267456055e-02
    z[1,0,6]  R299      -3.0630344152450562e-01
    z[1,0,6]  R300      -5.7962872087955475e-02
    z[1,0,6]  R301      -2.0928554236888885e-01
    z[1,0,6]  R302      1.4468098059296608e-02
    z[1,0,6]  R303      3.2767906785011292e-02
    z[1,0,6]  R304      -7.0363827049732208e-02
    z[1,0,6]  R305      1.9452148675918579e-01
    z[1,0,6]  R306      -3.8339901715517044e-02
    z[1,0,6]  R307      3.0110573768615723e-01
    z[1,0,6]  R308      2.4829675257205963e-01
    z[1,0,6]  R309      -2.5787854194641113e-01
    z[1,0,6]  R310      3.1721785664558411e-01
    z[1,0,6]  R311      -6.0341215133666992e-01
    z[1,0,6]  R312      5.3015735000371933e-02
    z[1,0,6]  R313      1.1071027070283890e-01
    z[1,0,6]  R314      -2.8082942962646484e-01
    z[1,0,6]  R315      3.7076551467180252e-02
    z[1,0,6]  R316      -5.2817560732364655e-02
    z[1,0,6]  R317      3.5354100167751312e-02
    z[1,0,6]  R318      -1.9615635275840759e-01
    z[1,0,6]  R319      -0.0438479483127594
    z[1,0,6]  R320      2.7327290177345276e-01
    z[1,0,6]  R321      2.6171356439590454e-01
    z[1,0,6]  R322      2.6546157896518707e-02
    z[1,0,6]  R323      3.5136502981185913e-01
    z[1,0,6]  R324      1.5173150599002838e-01
    z[1,0,6]  R325      -1.5349340438842773e-01
    z[1,0,6]  R326      -1.6870924830436707e-01
    z[1,0,6]  R327      -2.4577870965003967e-02
    z[1,0,6]  R328      2.6848694309592247e-02
    z[1,0,6]  R329      -1.0802821815013885e-01
    z[1,0,6]  R330      -5.4732402786612511e-03
    z[1,0,6]  R331      -2.1273775398731232e-01
    z[1,0,6]  R332      1.8075324594974518e-01
    z[1,0,6]  R333      -3.8762119412422180e-01
    z[1,0,6]  R334      -1.0170713067054749e-01
    z[1,0,6]  R335      3.6186963319778442e-01
    z[1,0,6]  R336      0.0724979117512703
    z[1,0,6]  R337      -2.8144511580467224e-01
    z[1,0,6]  R338      2.9696589335799217e-02
    z[1,0,6]  R339      2.8212261199951172e-01
    z[1,0,6]  R340      -0.229871928691864
    z[1,0,6]  R341      -2.4322873353958130e-01
    z[1,0,6]  R342      -0.394614040851593
    z[1,0,6]  R343      -4.5532837510108948e-01
    z[0,3,0]  R2        -1
    z[0,3,0]  R29       1
    z[0,3,0]  R344      -1
    z[0,3,0]  R345      1
    z[0,3,0]  R358      5.4950445890426636e-01
    z[0,3,0]  R359      2.2566643357276917e-01
    z[0,3,0]  R360      2.4773228168487549e-01
    z[0,3,0]  R361      5.1257789134979248e-01
    z[0,3,0]  R362      3.0807298421859741e-01
    z[0,3,0]  R363      3.7118816375732422e-01
    z[0,3,0]  R364      1.8057993054389954e-01
    z[0,3,0]  R365      2.5131982564926147e-01
    z[0,3,0]  R366      4.9685359001159668e-02
    z[0,3,0]  R367      2.3485079407691956e-01
    z[0,3,0]  R368      -5.6858336925506592e-01
    z[0,3,0]  R369      -6.2251865863800049e-01
    z[0,3,0]  R370      -8.0886995792388916e-01
    z[0,3,0]  R371      -0.775996744632721
    z[0,3,0]  R372      -8.7849384546279907e-01
    z[0,3,0]  R373      -3.0261451005935669e-01
    z[0,3,0]  R374      1.0116262733936310e-01
    z[0,3,0]  R375      -5.1856734789907932e-03
    z[0,3,0]  R376      -2.1734762191772461e-01
    z[0,3,0]  R377      -8.6758226156234741e-02
    z[0,3,0]  R378      7.4900770187377930e-01
    z[0,3,0]  R379      4.9384614825248718e-01
    z[0,3,0]  R380      1.6647800803184509e-01
    z[0,3,0]  R381      2.4530504643917084e-01
    z[0,3,0]  R382      -2.5162574648857117e-01
    z[0,3,0]  R383      -6.1069391667842865e-02
    z[0,3,0]  R384      2.7642402052879333e-01
    z[0,3,0]  R385      -1.0552392154932022e-01
    z[0,3,0]  R386      -5.4880715906620026e-02
    z[0,3,0]  R387      0.0477621927857399
    z[0,3,0]  R388      -5.7539260387420654e-01
    z[0,3,0]  R389      -4.6624532341957092e-01
    z[0,3,0]  R390      -5.0899642705917358e-01
    z[0,3,0]  R391      -1.2014885246753693e-01
    z[0,3,0]  R392      -5.0082010030746460e-01
    z[0,3,0]  R393      5.9517875313758850e-02
    z[0,3,0]  R394      -1.1326623708009720e-01
    z[0,3,0]  R395      1.3849098980426788e-01
    z[0,3,0]  R396      4.2004132270812988e-01
    z[0,3,0]  R397      1.9014729559421539e-01
    z[0,3,0]  R398      5.7204455137252808e-01
    z[0,3,0]  R399      0.572113037109375
    z[0,3,0]  R400      5.7787096500396729e-01
    z[0,3,0]  R401      5.3382194042205811e-01
    z[0,3,0]  R402      1.7811340093612671e-01
    z[0,3,0]  R403      5.7484441995620728e-01
    z[0,3,0]  R404      0.334280788898468
    z[0,3,0]  R405      5.1705837249755859e-02
    z[0,3,0]  R406      3.4049415588378906e-01
    z[0,3,0]  R407      6.3084119558334351e-01
    z[0,3,0]  R408      9.9886313080787659e-02
    z[0,3,0]  R409      0.684758722782135
    z[0,3,0]  R410      5.9450703859329224e-01
    z[0,3,0]  R411      5.3604131937026978e-01
    z[0,3,0]  R412      5.7761001586914062e-01
    z[0,3,0]  R413      5.9616720676422119e-01
    z[0,3,0]  R414      5.5288159847259521e-01
    z[0,3,0]  R415      6.0106503963470459e-01
    z[0,3,0]  R416      4.5466482639312744e-01
    z[0,3,0]  R417      6.2489295005798340e-01
    z[0,3,0]  R418      -4.3019089847803116e-02
    z[0,3,0]  R419      -4.8385281115770340e-02
    z[0,3,0]  R420      -5.2565336227416992e-01
    z[0,3,0]  R421      -1.6974531114101410e-01
    z[0,3,0]  R422      7.1861910820007324e-01
    z[0,3,0]  R423      -4.3361854553222656e-01
    z[0,3,0]  R424      -5.8581691980361938e-01
    z[0,3,0]  R425      -8.2092887163162231e-01
    z[0,3,0]  R426      -7.8789454698562622e-01
    z[0,3,0]  R427      -7.9566174745559692e-01
    z[0,3,0]  R428      9.5633447170257568e-02
    z[0,3,0]  R429      7.3859155178070068e-02
    z[0,3,0]  R430      1.6299448907375336e-01
    z[0,3,0]  R431      -0.557685136795044
    z[0,3,0]  R432      -2.3144088685512543e-01
    z[0,3,0]  R433      8.0284041166305542e-01
    z[0,3,0]  R434      -0.42790487408638
    z[0,3,0]  R435      -4.4375672936439514e-01
    z[0,3,0]  R436      -1.8512088805437088e-02
    z[0,3,0]  R437      3.3699741959571838e-01
    z[0,3,1]  R3        -1
    z[0,3,1]  R30       1
    z[0,3,1]  R346      -1
    z[0,3,1]  R347      1
    z[0,3,1]  R358      2.2765761613845825e-01
    z[0,3,1]  R359      2.4081312119960785e-01
    z[0,3,1]  R360      -2.9183927178382874e-01
    z[0,3,1]  R361      2.5947010517120361e-01
    z[0,3,1]  R362      4.7376653552055359e-01
    z[0,3,1]  R363      -2.9329755902290344e-01
    z[0,3,1]  R364      -9.7342170774936676e-02
    z[0,3,1]  R365      2.8164383769035339e-01
    z[0,3,1]  R366      -0.471004843711853
    z[0,3,1]  R367      -4.0136891603469849e-01
    z[0,3,1]  R368      -2.5692740082740784e-01
    z[0,3,1]  R369      -1.9757397472858429e-01
    z[0,3,1]  R370      1.1519086360931396e-01
    z[0,3,1]  R371      1.1629398167133331e-01
    z[0,3,1]  R372      -5.3413126617670059e-02
    z[0,3,1]  R373      -1.8432384729385376e-01
    z[0,3,1]  R374      -5.4583436250686646e-01
    z[0,3,1]  R375      -5.0999552011489868e-01
    z[0,3,1]  R376      -8.1726336479187012e-01
    z[0,3,1]  R377      -6.0983031988143921e-01
    z[0,3,1]  R378      3.8077855110168457e-01
    z[0,3,1]  R379      4.7441112995147705e-01
    z[0,3,1]  R380      -7.8147470951080322e-01
    z[0,3,1]  R381      -7.9768645763397217e-01
    z[0,3,1]  R382      8.7103432416915894e-01
    z[0,3,1]  R383      -4.1648185253143311e-01
    z[0,3,1]  R384      1.2210686504840851e-01
    z[0,3,1]  R385      0.944161593914032
    z[0,3,1]  R386      0.759667694568634
    z[0,3,1]  R387      -4.7425386309623718e-01
    z[0,3,1]  R388      5.3784084320068359e-01
    z[0,3,1]  R389      4.0997806191444397e-01
    z[0,3,1]  R390      3.5884803533554077e-01
    z[0,3,1]  R391      6.3315761089324951e-01
    z[0,3,1]  R392      6.0678112506866455e-01
    z[0,3,1]  R393      1.5981715917587280e-01
    z[0,3,1]  R394      -6.0067433118820190e-01
    z[0,3,1]  R395      -5.6848269701004028e-01
    z[0,3,1]  R396      -6.1022669076919556e-01
    z[0,3,1]  R397      -4.7365039587020874e-01
    z[0,3,1]  R398      -7.7890610694885254e-01
    z[0,3,1]  R399      -0.734073281288147
    z[0,3,1]  R400      -7.1233463287353516e-01
    z[0,3,1]  R401      -7.4874430894851685e-01
    z[0,3,1]  R402      -8.8062816858291626e-01
    z[0,3,1]  R403      -7.2288483381271362e-01
    z[0,3,1]  R404      -8.5410809516906738e-01
    z[0,3,1]  R405      -8.4017670154571533e-01
    z[0,3,1]  R406      -8.2712328433990479e-01
    z[0,3,1]  R407      -6.3271623849868774e-01
    z[0,3,1]  R408      -2.8168407082557678e-01
    z[0,3,1]  R409      4.9736425280570984e-01
    z[0,3,1]  R410      4.9484935402870178e-01
    z[0,3,1]  R411      5.2616351842880249e-01
    z[0,3,1]  R412      4.0387737751007080e-01
    z[0,3,1]  R413      3.4215039014816284e-01
    z[0,3,1]  R414      5.1828610897064209e-01
    z[0,3,1]  R415      3.5125705599784851e-01
    z[0,3,1]  R416      4.8839551210403442e-01
    z[0,3,1]  R417      3.7105610966682434e-01
    z[0,3,1]  R418      3.2518428564071655e-01
    z[0,3,1]  R419      -1.1943493038415909e-01
    z[0,3,1]  R420      -4.5852270722389221e-01
    z[0,3,1]  R421      -4.6201723814010620e-01
    z[0,3,1]  R422      3.0634099245071411e-01
    z[0,3,1]  R423      -3.5620772838592529e-01
    z[0,3,1]  R424      -5.4595535993576050e-01
    z[0,3,1]  R425      -0.424570769071579
    z[0,3,1]  R426      -0.507512629032135
    z[0,3,1]  R427      -5.1523089408874512e-01
    z[0,3,1]  R428      -1.7358395457267761e-01
    z[0,3,1]  R429      -6.7534017562866211e-01
    z[0,3,1]  R430      -5.6824922561645508e-01
    z[0,3,1]  R431      -7.2195613384246826e-01
    z[0,3,1]  R432      -2.6490309834480286e-01
    z[0,3,1]  R433      3.6142560839653015e-01
    z[0,3,1]  R434      -2.9764235019683838e-01
    z[0,3,1]  R435      -0.304245263338089
    z[0,3,1]  R436      -2.3560518398880959e-02
    z[0,3,1]  R437      3.8852196931838989e-01
    z[0,3,2]  R4        -1
    z[0,3,2]  R31       1
    z[0,3,2]  R348      -1
    z[0,3,2]  R349      1
    z[0,3,2]  R358      1.9580762088298798e-01
    z[0,3,2]  R359      3.1615075469017029e-01
    z[0,3,2]  R360      3.2304674386978149e-01
    z[0,3,2]  R361      1.4591987431049347e-01
    z[0,3,2]  R362      2.3431833088397980e-01
    z[0,3,2]  R363      4.8229777812957764e-01
    z[0,3,2]  R364      3.7313434481620789e-01
    z[0,3,2]  R365      4.3597152829170227e-01
    z[0,3,2]  R366      4.0399962663650513e-01
    z[0,3,2]  R367      5.3727221488952637e-01
    z[0,3,2]  R368      -9.5796346664428711e-02
    z[0,3,2]  R369      -0.360103964805603
    z[0,3,2]  R370      -3.0828937888145447e-01
    z[0,3,2]  R371      -1.4103728532791138e-01
    z[0,3,2]  R372      -6.1354603618383408e-02
    z[0,3,2]  R373      -3.6202916502952576e-01
    z[0,3,2]  R374      -2.9099497199058533e-01
    z[0,3,2]  R375      -5.0199472904205322e-01
    z[0,3,2]  R376      1.4629521965980530e-01
    z[0,3,2]  R377      -5.5146467685699463e-01
    z[0,3,2]  R378      -1.1649450659751892e-01
    z[0,3,2]  R379      3.7766832113265991e-01
    z[0,3,2]  R380      -4.6529714018106461e-02
    z[0,3,2]  R381      -3.2391363382339478e-01
    z[0,3,2]  R382      1.1710018664598465e-01
    z[0,3,2]  R383      8.9965946972370148e-02
    z[0,3,2]  R384      -2.5769764184951782e-01
    z[0,3,2]  R385      -1.6945490241050720e-01
    z[0,3,2]  R386      -3.6154675483703613e-01
    z[0,3,2]  R387      -3.6417570710182190e-01
    z[0,3,2]  R388      -3.1495407223701477e-01
    z[0,3,2]  R389      -2.7223592996597290e-01
    z[0,3,2]  R390      1.9476598501205444e-01
    z[0,3,2]  R391      -3.0419480800628662e-01
    z[0,3,2]  R392      4.5412972569465637e-02
    z[0,3,2]  R393      -4.4046494364738464e-01
    z[0,3,2]  R394      5.1188701391220093e-01
    z[0,3,2]  R395      6.8993842601776123e-01
    z[0,3,2]  R396      5.3733807802200317e-01
    z[0,3,2]  R397      7.7381551265716553e-01
    z[0,3,2]  R398      -1.6695824265480042e-01
    z[0,3,2]  R399      -1.0524638742208481e-01
    z[0,3,2]  R400      -2.3312093317508698e-01
    z[0,3,2]  R401      -9.8969843238592148e-03
    z[0,3,2]  R402      -3.2058599591255188e-01
    z[0,3,2]  R403      -7.9349176958203316e-03
    z[0,3,2]  R404      -1.4685305953025818e-01
    z[0,3,2]  R405      -2.5821053981781006e-01
    z[0,3,2]  R406      -4.5450992882251740e-02
    z[0,3,2]  R407      3.5034954547882080e-01
    z[0,3,2]  R408      -1.6533946618437767e-02
    z[0,3,2]  R409      -1.4327681064605713e-01
    z[0,3,2]  R410      -1.1226122081279755e-01
    z[0,3,2]  R411      -1.1739084869623184e-01
    z[0,3,2]  R412      1.3021047413349152e-01
    z[0,3,2]  R413      -6.5592072904109955e-02
    z[0,3,2]  R414      1.4451918005943298e-01
    z[0,3,2]  R415      2.1304875612258911e-01
    z[0,3,2]  R416      1.1093472689390182e-01
    z[0,3,2]  R417      -6.2649093568325043e-02
    z[0,3,2]  R418      0.0575115866959095
    z[0,3,2]  R419      2.1006904542446136e-01
    z[0,3,2]  R420      -2.1441720426082611e-01
    z[0,3,2]  R421      -2.3992931842803955e-01
    z[0,3,2]  R422      3.1207486987113953e-01
    z[0,3,2]  R423      3.0928462743759155e-02
    z[0,3,2]  R424      -0.0356932133436203
    z[0,3,2]  R425      -1.3485740125179291e-01
    z[0,3,2]  R426      -1.8079439178109169e-02
    z[0,3,2]  R427      -2.6221296191215515e-01
    z[0,3,2]  R428      -2.2966243326663971e-01
    z[0,3,2]  R429      -7.7399136498570442e-03
    z[0,3,2]  R430      2.4974639713764191e-01
    z[0,3,2]  R431      -6.7057803273200989e-02
    z[0,3,2]  R432      1.5775233507156372e-01
    z[0,3,2]  R433      -8.3998069167137146e-03
    z[0,3,2]  R434      -2.7235758304595947e-01
    z[0,3,2]  R435      -9.1737903654575348e-02
    z[0,3,2]  R436      5.3540718555450439e-01
    z[0,3,2]  R437      0.501573920249939
    z[0,3,3]  R5        -1
    z[0,3,3]  R32       1
    z[0,3,3]  R350      -1
    z[0,3,3]  R351      1
    z[0,3,3]  R358      -3.4916356205940247e-01
    z[0,3,3]  R359      -1.7162297666072845e-01
    z[0,3,3]  R360      -1.8864282965660095e-01
    z[0,3,3]  R361      2.3550543934106827e-02
    z[0,3,3]  R362      -0.0916028618812561
    z[0,3,3]  R363      -4.5122930407524109e-01
    z[0,3,3]  R364      1.0401997715234756e-01
    z[0,3,3]  R365      -2.1718591451644897e-01
    z[0,3,3]  R366      -4.6430063247680664e-01
    z[0,3,3]  R367      -5.0557094812393188e-01
    z[0,3,3]  R368      7.0558679103851318e-01
    z[0,3,3]  R369      6.3520252704620361e-01
    z[0,3,3]  R370      4.2031729221343994e-01
    z[0,3,3]  R371      4.5855760574340820e-01
    z[0,3,3]  R372      0.428813636302948
    z[0,3,3]  R373      7.3850327730178833e-01
    z[0,3,3]  R374      6.8741393089294434e-01
    z[0,3,3]  R375      5.9327334165573120e-01
    z[0,3,3]  R376      4.7143629193305969e-01
    z[0,3,3]  R377      3.4902539849281311e-01
    z[0,3,3]  R378      -2.2027720510959625e-01
    z[0,3,3]  R379      -1.4997886121273041e-01
    z[0,3,3]  R380      -1.0772560536861420e-01
    z[0,3,3]  R381      -1.4694376289844513e-01
    z[0,3,3]  R382      -3.6388251930475235e-02
    z[0,3,3]  R383      1.1856950819492340e-01
    z[0,3,3]  R384      -4.1951787471771240e-01
    z[0,3,3]  R385      -8.6664058268070221e-02
    z[0,3,3]  R386      -1.7696432769298553e-03
    z[0,3,3]  R387      -5.7630473375320435e-01
    z[0,3,3]  R388      3.4320011734962463e-01
    z[0,3,3]  R389      3.5711315274238586e-01
    z[0,3,3]  R390      6.5942478179931641e-01
    z[0,3,3]  R391      5.9538805484771729e-01
    z[0,3,3]  R392      3.4576657414436340e-01
    z[0,3,3]  R393      7.0035117864608765e-01
    z[0,3,3]  R394      -0.530301034450531
    z[0,3,3]  R395      -2.6191276311874390e-01
    z[0,3,3]  R396      -3.3637505024671555e-02
    z[0,3,3]  R397      -3.3186116814613342e-01
    z[0,3,3]  R398      -7.4687272310256958e-02
    z[0,3,3]  R399      1.0632331669330597e-01
    z[0,3,3]  R400      2.7038154006004333e-01
    z[0,3,3]  R401      1.2183093279600143e-01
    z[0,3,3]  R402      3.7542287260293961e-02
    z[0,3,3]  R403      1.1555763334035873e-01
    z[0,3,3]  R404      2.9953292012214661e-01
    z[0,3,3]  R405      4.1325652599334717e-01
    z[0,3,3]  R406      2.7058649063110352e-01
    z[0,3,3]  R407      -4.5007247477769852e-02
    z[0,3,3]  R408      3.1242930889129639e-01
    z[0,3,3]  R409      -0.39503213763237
    z[0,3,3]  R410      -5.6164044141769409e-01
    z[0,3,3]  R411      -5.4107069969177246e-01
    z[0,3,3]  R412      -6.1921846866607666e-01
    z[0,3,3]  R413      -5.1277482509613037e-01
    z[0,3,3]  R414      -4.6367436647415161e-01
    z[0,3,3]  R415      -4.8262152075767517e-01
    z[0,3,3]  R416      -6.2656527757644653e-01
    z[0,3,3]  R417      -4.8673585057258606e-01
    z[0,3,3]  R418      7.2669649124145508e-01
    z[0,3,3]  R419      0.762295126914978
    z[0,3,3]  R420      -5.7686185836791992e-01
    z[0,3,3]  R421      -5.2052670717239380e-01
    z[0,3,3]  R422      -3.6024487018585205e-01
    z[0,3,3]  R423      -4.5294648408889771e-01
    z[0,3,3]  R424      -4.4176250696182251e-01
    z[0,3,3]  R425      -1.0698555409908295e-01
    z[0,3,3]  R426      -2.1624748408794403e-01
    z[0,3,3]  R427      -1.4532610774040222e-01
    z[0,3,3]  R428      8.5010147094726562e-01
    z[0,3,3]  R429      -5.5896854400634766e-01
    z[0,3,3]  R430      -5.5401455610990524e-02
    z[0,3,3]  R431      -2.5027725100517273e-01
    z[0,3,3]  R432      -3.6608001589775085e-01
    z[0,3,3]  R433      -2.4820853024721146e-02
    z[0,3,3]  R434      -5.3497594594955444e-01
    z[0,3,3]  R435      -4.3160125613212585e-01
    z[0,3,3]  R436      -2.8032356500625610e-01
    z[0,3,3]  R437      3.5390022397041321e-01
    z[0,3,4]  R6        -1
    z[0,3,4]  R33       1
    z[0,3,4]  R352      -1
    z[0,3,4]  R353      1
    z[0,3,4]  R358      2.4349787831306458e-01
    z[0,3,4]  R359      4.0638846158981323e-01
    z[0,3,4]  R360      -8.8096439838409424e-02
    z[0,3,4]  R361      -2.2533057257533073e-02
    z[0,3,4]  R362      -2.1347071230411530e-01
    z[0,3,4]  R363      -3.6403140425682068e-01
    z[0,3,4]  R364      5.3892578929662704e-02
    z[0,3,4]  R365      -2.7593040466308594e-01
    z[0,3,4]  R366      4.3897935748100281e-01
    z[0,3,4]  R367      -1.3020625710487366e-01
    z[0,3,4]  R368      1.1973444372415543e-01
    z[0,3,4]  R369      1.1419614404439926e-01
    z[0,3,4]  R370      -3.6403417587280273e-02
    z[0,3,4]  R371      3.3790281414985657e-01
    z[0,3,4]  R372      1.8731196224689484e-01
    z[0,3,4]  R373      -3.8630706071853638e-01
    z[0,3,4]  R374      2.4383902549743652e-01
    z[0,3,4]  R375      -6.3059397041797638e-02
    z[0,3,4]  R376      -0.080388642847538
    z[0,3,4]  R377      -0.14909727871418
    z[0,3,4]  R378      -0.154183492064476
    z[0,3,4]  R379      5.5469684302806854e-02
    z[0,3,4]  R380      -2.9021957516670227e-01
    z[0,3,4]  R381      2.2349886596202850e-01
    z[0,3,4]  R382      3.6730057001113892e-01
    z[0,3,4]  R383      -2.8336179256439209e-01
    z[0,3,4]  R384      -7.6043003797531128e-01
    z[0,3,4]  R385      -1.2781850062310696e-02
    z[0,3,4]  R386      3.2220616936683655e-01
    z[0,3,4]  R387      -3.0423709750175476e-01
    z[0,3,4]  R388      1.5212135016918182e-01
    z[0,3,4]  R389      6.0544836521148682e-01
    z[0,3,4]  R390      1.1388329416513443e-01
    z[0,3,4]  R391      -2.4923862516880035e-01
    z[0,3,4]  R392      -4.1099062561988831e-01
    z[0,3,4]  R393      7.6116546988487244e-02
    z[0,3,4]  R394      -1.4724639058113098e-01
    z[0,3,4]  R395      -1.4814375340938568e-01
    z[0,3,4]  R396      1.4779733121395111e-01
    z[0,3,4]  R397      -1.4857585728168488e-01
    z[0,3,4]  R398      -1.5054804086685181e-01
    z[0,3,4]  R399      -2.9473719000816345e-01
    z[0,3,4]  R400      -0.156258225440979
    z[0,3,4]  R401      2.5375029444694519e-01
    z[0,3,4]  R402      -2.8916954994201660e-01
    z[0,3,4]  R403      1.9727160036563873e-01
    z[0,3,4]  R404      1.4298303425312042e-01
    z[0,3,4]  R405      1.8206825852394104e-01
    z[0,3,4]  R406      2.2723200917243958e-01
    z[0,3,4]  R407      4.6563889831304550e-02
    z[0,3,4]  R408      -1.5930096805095673e-01
    z[0,3,4]  R409      -2.0812867581844330e-01
    z[0,3,4]  R410      -2.5409471988677979e-01
    z[0,3,4]  R411      -3.5411116480827332e-01
    z[0,3,4]  R412      -2.4435031414031982e-01
    z[0,3,4]  R413      -1.3521975278854370e-01
    z[0,3,4]  R414      2.3473742604255676e-01
    z[0,3,4]  R415      1.3703167438507080e-01
    z[0,3,4]  R416      1.8078124523162842e-01
    z[0,3,4]  R417      3.0565834045410156e-01
    z[0,3,4]  R418      -0.0800301805138588
    z[0,3,4]  R419      1.5295787155628204e-01
    z[0,3,4]  R420      1.1559443175792694e-01
    z[0,3,4]  R421      6.0622924566268921e-01
    z[0,3,4]  R422      0.179230198264122
    z[0,3,4]  R423      -1.0031496174633503e-02
    z[0,3,4]  R424      3.5202977061271667e-01
    z[0,3,4]  R425      -2.7851012349128723e-01
    z[0,3,4]  R426      -1.1431746929883957e-01
    z[0,3,4]  R427      1.8334053456783295e-02
    z[0,3,4]  R428      1.1465849727392197e-01
    z[0,3,4]  R429      -1.5079215168952942e-01
    z[0,3,4]  R430      1.2787835299968719e-01
    z[0,3,4]  R431      1.1395392566919327e-01
    z[0,3,4]  R432      -1.2181679904460907e-01
    z[0,3,4]  R433      2.8046944737434387e-01
    z[0,3,4]  R434      -5.1584386825561523e-01
    z[0,3,4]  R435      -6.2819540500640869e-01
    z[0,3,4]  R436      7.1900326013565063e-01
    z[0,3,4]  R437      1.1113435961306095e-02
    z[0,3,5]  R7        -1
    z[0,3,5]  R34       1
    z[0,3,5]  R354      -1
    z[0,3,5]  R355      1
    z[0,3,5]  R358      -5.8974957466125488e-01
    z[0,3,5]  R359      -7.7146071195602417e-01
    z[0,3,5]  R360      -8.3842861652374268e-01
    z[0,3,5]  R361      -8.0394911766052246e-01
    z[0,3,5]  R362      -7.3026913404464722e-01
    z[0,3,5]  R363      -4.5336017012596130e-01
    z[0,3,5]  R364      -8.5456639528274536e-01
    z[0,3,5]  R365      -6.8966847658157349e-01
    z[0,3,5]  R366      -4.5109590888023376e-01
    z[0,3,5]  R367      -3.1475964188575745e-01
    z[0,3,5]  R368      2.5751274824142456e-01
    z[0,3,5]  R369      6.0638688504695892e-02
    z[0,3,5]  R370      1.7596489191055298e-01
    z[0,3,5]  R371      1.9838280975818634e-01
    z[0,3,5]  R372      -4.4085253030061722e-02
    z[0,3,5]  R373      -0.192597433924675
    z[0,3,5]  R374      2.7409407496452332e-01
    z[0,3,5]  R375      2.9440104961395264e-01
    z[0,3,5]  R376      4.5299485325813293e-02
    z[0,3,5]  R377      -1.4888846874237061e-01
    z[0,3,5]  R378      4.4473049044609070e-01
    z[0,3,5]  R379      4.8155647516250610e-01
    z[0,3,5]  R380      0.50826096534729
    z[0,3,5]  R381      2.1873778104782104e-01
    z[0,3,5]  R382      1.6478934884071350e-01
    z[0,3,5]  R383      8.0048346519470215e-01
    z[0,3,5]  R384      1.8756695091724396e-01
    z[0,3,5]  R385      4.3293926864862442e-02
    z[0,3,5]  R386      1.7215389013290405e-01
    z[0,3,5]  R387      9.0370990335941315e-02
    z[0,3,5]  R388      3.2471993565559387e-01
    z[0,3,5]  R389      1.3615280389785767e-01
    z[0,3,5]  R390      -2.1183695644140244e-02
    z[0,3,5]  R391      1.8469187617301941e-01
    z[0,3,5]  R392      2.7607583999633789e-01
    z[0,3,5]  R393      4.6119844913482666e-01
    z[0,3,5]  R394      1.7270718514919281e-01
    z[0,3,5]  R395      2.6913151144981384e-01
    z[0,3,5]  R396      -3.3632940053939819e-01
    z[0,3,5]  R397      -6.1255201697349548e-02
    z[0,3,5]  R398      -1.2070265598595142e-02
    z[0,3,5]  R399      -1.5667583048343658e-01
    z[0,3,5]  R400      -1.0563275776803493e-02
    z[0,3,5]  R401      2.7180045843124390e-01
    z[0,3,5]  R402      -1.4757966622710228e-02
    z[0,3,5]  R403      -3.0287897586822510e-01
    z[0,3,5]  R404      1.5523275732994080e-01
    z[0,3,5]  R405      -1.2730531394481659e-01
    z[0,3,5]  R406      -2.3361420631408691e-01
    z[0,3,5]  R407      -5.3906790912151337e-02
    z[0,3,5]  R408      0.88450688123703
    z[0,3,5]  R409      -2.3509602248668671e-01
    z[0,3,5]  R410      6.0226183384656906e-02
    z[0,3,5]  R411      -5.1337979733943939e-02
    z[0,3,5]  R412      -1.9504806399345398e-01
    z[0,3,5]  R413      -4.8167926073074341e-01
    z[0,3,5]  R414      -3.6643886566162109e-01
    z[0,3,5]  R415      -0.439810574054718
    z[0,3,5]  R416      -0.342242568731308
    z[0,3,5]  R417      -2.5903207063674927e-01
    z[0,3,5]  R418      5.7846188545227051e-01
    z[0,3,5]  R419      4.4787231087684631e-01
    z[0,3,5]  R420      -3.3854490518569946e-01
    z[0,3,5]  R421      -1.1588786542415619e-01
    z[0,3,5]  R422      3.4957417845726013e-01
    z[0,3,5]  R423      -2.5847530364990234e-01
    z[0,3,5]  R424      1.7605029046535492e-01
    z[0,3,5]  R425      1.0050392150878906e-01
    z[0,3,5]  R426      -5.0245508551597595e-02
    z[0,3,5]  R427      9.4093777239322662e-02
    z[0,3,5]  R428      -4.1067236661911011e-01
    z[0,3,5]  R429      -4.5013588666915894e-01
    z[0,3,5]  R430      3.2189333438873291e-01
    z[0,3,5]  R431      2.5142475962638855e-01
    z[0,3,5]  R432      -0.837743878364563
    z[0,3,5]  R433      2.1290406584739685e-01
    z[0,3,5]  R434      2.7396622300148010e-01
    z[0,3,5]  R435      3.4762862324714661e-01
    z[0,3,5]  R436      1.4043180644512177e-01
    z[0,3,5]  R437      -3.5550388693809509e-01
    z[0,3,6]  R8        -1
    z[0,3,6]  R35       1
    z[0,3,6]  R356      -1
    z[0,3,6]  R357      1
    z[0,3,6]  R358      -2.8082942962646484e-01
    z[0,3,6]  R359      3.7076551467180252e-02
    z[0,3,6]  R360      -5.2817560732364655e-02
    z[0,3,6]  R361      3.5354100167751312e-02
    z[0,3,6]  R362      -1.9615635275840759e-01
    z[0,3,6]  R363      -0.0438479483127594
    z[0,3,6]  R364      2.7327290177345276e-01
    z[0,3,6]  R365      2.6171356439590454e-01
    z[0,3,6]  R366      2.6546157896518707e-02
    z[0,3,6]  R367      3.5136502981185913e-01
    z[0,3,6]  R368      1.5173150599002838e-01
    z[0,3,6]  R369      -1.5349340438842773e-01
    z[0,3,6]  R370      -1.6870924830436707e-01
    z[0,3,6]  R371      -2.4577870965003967e-02
    z[0,3,6]  R372      2.6848694309592247e-02
    z[0,3,6]  R373      -1.0802821815013885e-01
    z[0,3,6]  R374      -5.4732402786612511e-03
    z[0,3,6]  R375      -2.1273775398731232e-01
    z[0,3,6]  R376      1.8075324594974518e-01
    z[0,3,6]  R377      -3.8762119412422180e-01
    z[0,3,6]  R378      -1.0170713067054749e-01
    z[0,3,6]  R379      3.6186963319778442e-01
    z[0,3,6]  R380      0.0724979117512703
    z[0,3,6]  R381      -2.8144511580467224e-01
    z[0,3,6]  R382      2.9696589335799217e-02
    z[0,3,6]  R383      2.8212261199951172e-01
    z[0,3,6]  R384      -0.229871928691864
    z[0,3,6]  R385      -2.4322873353958130e-01
    z[0,3,6]  R386      -0.394614040851593
    z[0,3,6]  R387      -4.5532837510108948e-01
    z[0,3,6]  R388      -1.8461908400058746e-01
    z[0,3,6]  R389      -1.6669057309627533e-01
    z[0,3,6]  R390      3.5490524768829346e-01
    z[0,3,6]  R391      -2.0352724194526672e-01
    z[0,3,6]  R392      1.1936455219984055e-01
    z[0,3,6]  R393      -2.6060926914215088e-01
    z[0,3,6]  R394      1.7777577042579651e-01
    z[0,3,6]  R395      1.3658711314201355e-01
    z[0,3,6]  R396      -1.6236859560012817e-01
    z[0,3,6]  R397      -6.8921104073524475e-02
    z[0,3,6]  R398      -9.9029108881950378e-02
    z[0,3,6]  R399      4.9343584105372429e-03
    z[0,3,6]  R400      -8.1637494266033173e-02
    z[0,3,6]  R401      3.4795474261045456e-02
    z[0,3,6]  R402      -6.8906836211681366e-02
    z[0,3,6]  R403      5.4065424948930740e-02
    z[0,3,6]  R404      5.4115884006023407e-02
    z[0,3,6]  R405      0.0679747611284256
    z[0,3,6]  R406      1.3578702509403229e-01
    z[0,3,6]  R407      2.6807633042335510e-01
    z[0,3,6]  R408      7.1148246526718140e-02
    z[0,3,6]  R409      -9.2562668025493622e-02
    z[0,3,6]  R410      7.3835469782352448e-02
    z[0,3,6]  R411      3.5258814692497253e-02
    z[0,3,6]  R412      -7.1503028273582458e-02
    z[0,3,6]  R413      9.9891006946563721e-02
    z[0,3,6]  R414      -2.1038312464952469e-02
    z[0,3,6]  R415      -1.5752756595611572e-01
    z[0,3,6]  R416      6.8824617192149162e-03
    z[0,3,6]  R417      -2.6545220613479614e-01
    z[0,3,6]  R418      1.4137212932109833e-01
    z[0,3,6]  R419      3.6631348729133606e-01
    z[0,3,6]  R420      -8.2015588879585266e-02
    z[0,3,6]  R421      -2.1970118582248688e-01
    z[0,3,6]  R422      0.0908239483833313
    z[0,3,6]  R423      -0.641921877861023
    z[0,3,6]  R424      8.6049064993858337e-02
    z[0,3,6]  R425      1.6886119544506073e-01
    z[0,3,6]  R426      2.4283771216869354e-01
    z[0,3,6]  R427      4.8933181911706924e-02
    z[0,3,6]  R428      0.0592205636203289
    z[0,3,6]  R429      2.4375896900892258e-02
    z[0,3,6]  R430      -6.8199324607849121e-01
    z[0,3,6]  R431      1.5630531311035156e-01
    z[0,3,6]  R432      -2.6589466258883476e-02
    z[0,3,6]  R433      -3.1645059585571289e-01
    z[0,3,6]  R434      -1.6363418102264404e-01
    z[0,3,6]  R435      1.8553754314780235e-02
    z[0,3,6]  R436      3.1172606348991394e-01
    z[0,3,6]  R437      -4.8182481527328491e-01
    z[3,0,0]  R2        1
    z[3,0,0]  R29       -1
    z[3,0,0]  R438      -1
    z[3,0,0]  R439      1
    z[3,0,0]  R452      -5.7539260387420654e-01
    z[3,0,0]  R453      -4.6624532341957092e-01
    z[3,0,0]  R454      -5.0899642705917358e-01
    z[3,0,0]  R455      -1.2014885246753693e-01
    z[3,0,0]  R456      -5.0082010030746460e-01
    z[3,0,0]  R457      5.9517875313758850e-02
    z[3,0,0]  R458      -1.1326623708009720e-01
    z[3,0,0]  R459      1.3849098980426788e-01
    z[3,0,0]  R460      4.2004132270812988e-01
    z[3,0,0]  R461      1.9014729559421539e-01
    z[3,0,0]  R462      5.7204455137252808e-01
    z[3,0,0]  R463      0.572113037109375
    z[3,0,0]  R464      5.7787096500396729e-01
    z[3,0,0]  R465      5.3382194042205811e-01
    z[3,0,0]  R466      1.7811340093612671e-01
    z[3,0,0]  R467      5.7484441995620728e-01
    z[3,0,0]  R468      0.334280788898468
    z[3,0,0]  R469      5.1705837249755859e-02
    z[3,0,0]  R470      3.4049415588378906e-01
    z[3,0,0]  R471      6.3084119558334351e-01
    z[3,0,0]  R472      9.9886313080787659e-02
    z[3,0,0]  R473      0.684758722782135
    z[3,0,0]  R474      5.9450703859329224e-01
    z[3,0,0]  R475      5.3604131937026978e-01
    z[3,0,0]  R476      5.7761001586914062e-01
    z[3,0,0]  R477      5.9616720676422119e-01
    z[3,0,0]  R478      5.5288159847259521e-01
    z[3,0,0]  R479      6.0106503963470459e-01
    z[3,0,0]  R480      4.5466482639312744e-01
    z[3,0,0]  R481      6.2489295005798340e-01
    z[3,0,0]  R482      -4.3019089847803116e-02
    z[3,0,0]  R483      -4.8385281115770340e-02
    z[3,0,0]  R484      -5.2565336227416992e-01
    z[3,0,0]  R485      -1.6974531114101410e-01
    z[3,0,0]  R486      7.1861910820007324e-01
    z[3,0,0]  R487      -4.3361854553222656e-01
    z[3,0,0]  R488      -5.8581691980361938e-01
    z[3,0,0]  R489      -8.2092887163162231e-01
    z[3,0,0]  R490      -7.8789454698562622e-01
    z[3,0,0]  R491      -7.9566174745559692e-01
    z[3,0,0]  R492      9.5633447170257568e-02
    z[3,0,0]  R493      7.3859155178070068e-02
    z[3,0,0]  R494      1.6299448907375336e-01
    z[3,0,0]  R495      -0.557685136795044
    z[3,0,0]  R496      -2.3144088685512543e-01
    z[3,0,0]  R497      8.0284041166305542e-01
    z[3,0,0]  R498      -0.42790487408638
    z[3,0,0]  R499      -4.4375672936439514e-01
    z[3,0,0]  R500      -1.8512088805437088e-02
    z[3,0,0]  R501      3.3699741959571838e-01
    z[3,0,0]  R502      5.4950445890426636e-01
    z[3,0,0]  R503      2.2566643357276917e-01
    z[3,0,0]  R504      2.4773228168487549e-01
    z[3,0,0]  R505      5.1257789134979248e-01
    z[3,0,0]  R506      3.0807298421859741e-01
    z[3,0,0]  R507      3.7118816375732422e-01
    z[3,0,0]  R508      1.8057993054389954e-01
    z[3,0,0]  R509      2.5131982564926147e-01
    z[3,0,0]  R510      4.9685359001159668e-02
    z[3,0,0]  R511      2.3485079407691956e-01
    z[3,0,0]  R512      -5.6858336925506592e-01
    z[3,0,0]  R513      -6.2251865863800049e-01
    z[3,0,0]  R514      -8.0886995792388916e-01
    z[3,0,0]  R515      -0.775996744632721
    z[3,0,0]  R516      -8.7849384546279907e-01
    z[3,0,0]  R517      -3.0261451005935669e-01
    z[3,0,0]  R518      1.0116262733936310e-01
    z[3,0,0]  R519      -5.1856734789907932e-03
    z[3,0,0]  R520      -2.1734762191772461e-01
    z[3,0,0]  R521      -8.6758226156234741e-02
    z[3,0,0]  R522      7.4900770187377930e-01
    z[3,0,0]  R523      4.9384614825248718e-01
    z[3,0,0]  R524      1.6647800803184509e-01
    z[3,0,0]  R525      2.4530504643917084e-01
    z[3,0,0]  R526      -2.5162574648857117e-01
    z[3,0,0]  R527      -6.1069391667842865e-02
    z[3,0,0]  R528      2.7642402052879333e-01
    z[3,0,0]  R529      -1.0552392154932022e-01
    z[3,0,0]  R530      -5.4880715906620026e-02
    z[3,0,0]  R531      0.0477621927857399
    z[3,0,1]  R3        1
    z[3,0,1]  R30       -1
    z[3,0,1]  R440      -1
    z[3,0,1]  R441      1
    z[3,0,1]  R452      5.3784084320068359e-01
    z[3,0,1]  R453      4.0997806191444397e-01
    z[3,0,1]  R454      3.5884803533554077e-01
    z[3,0,1]  R455      6.3315761089324951e-01
    z[3,0,1]  R456      6.0678112506866455e-01
    z[3,0,1]  R457      1.5981715917587280e-01
    z[3,0,1]  R458      -6.0067433118820190e-01
    z[3,0,1]  R459      -5.6848269701004028e-01
    z[3,0,1]  R460      -6.1022669076919556e-01
    z[3,0,1]  R461      -4.7365039587020874e-01
    z[3,0,1]  R462      -7.7890610694885254e-01
    z[3,0,1]  R463      -0.734073281288147
    z[3,0,1]  R464      -7.1233463287353516e-01
    z[3,0,1]  R465      -7.4874430894851685e-01
    z[3,0,1]  R466      -8.8062816858291626e-01
    z[3,0,1]  R467      -7.2288483381271362e-01
    z[3,0,1]  R468      -8.5410809516906738e-01
    z[3,0,1]  R469      -8.4017670154571533e-01
    z[3,0,1]  R470      -8.2712328433990479e-01
    z[3,0,1]  R471      -6.3271623849868774e-01
    z[3,0,1]  R472      -2.8168407082557678e-01
    z[3,0,1]  R473      4.9736425280570984e-01
    z[3,0,1]  R474      4.9484935402870178e-01
    z[3,0,1]  R475      5.2616351842880249e-01
    z[3,0,1]  R476      4.0387737751007080e-01
    z[3,0,1]  R477      3.4215039014816284e-01
    z[3,0,1]  R478      5.1828610897064209e-01
    z[3,0,1]  R479      3.5125705599784851e-01
    z[3,0,1]  R480      4.8839551210403442e-01
    z[3,0,1]  R481      3.7105610966682434e-01
    z[3,0,1]  R482      3.2518428564071655e-01
    z[3,0,1]  R483      -1.1943493038415909e-01
    z[3,0,1]  R484      -4.5852270722389221e-01
    z[3,0,1]  R485      -4.6201723814010620e-01
    z[3,0,1]  R486      3.0634099245071411e-01
    z[3,0,1]  R487      -3.5620772838592529e-01
    z[3,0,1]  R488      -5.4595535993576050e-01
    z[3,0,1]  R489      -0.424570769071579
    z[3,0,1]  R490      -0.507512629032135
    z[3,0,1]  R491      -5.1523089408874512e-01
    z[3,0,1]  R492      -1.7358395457267761e-01
    z[3,0,1]  R493      -6.7534017562866211e-01
    z[3,0,1]  R494      -5.6824922561645508e-01
    z[3,0,1]  R495      -7.2195613384246826e-01
    z[3,0,1]  R496      -2.6490309834480286e-01
    z[3,0,1]  R497      3.6142560839653015e-01
    z[3,0,1]  R498      -2.9764235019683838e-01
    z[3,0,1]  R499      -0.304245263338089
    z[3,0,1]  R500      -2.3560518398880959e-02
    z[3,0,1]  R501      3.8852196931838989e-01
    z[3,0,1]  R502      2.2765761613845825e-01
    z[3,0,1]  R503      2.4081312119960785e-01
    z[3,0,1]  R504      -2.9183927178382874e-01
    z[3,0,1]  R505      2.5947010517120361e-01
    z[3,0,1]  R506      4.7376653552055359e-01
    z[3,0,1]  R507      -2.9329755902290344e-01
    z[3,0,1]  R508      -9.7342170774936676e-02
    z[3,0,1]  R509      2.8164383769035339e-01
    z[3,0,1]  R510      -0.471004843711853
    z[3,0,1]  R511      -4.0136891603469849e-01
    z[3,0,1]  R512      -2.5692740082740784e-01
    z[3,0,1]  R513      -1.9757397472858429e-01
    z[3,0,1]  R514      1.1519086360931396e-01
    z[3,0,1]  R515      1.1629398167133331e-01
    z[3,0,1]  R516      -5.3413126617670059e-02
    z[3,0,1]  R517      -1.8432384729385376e-01
    z[3,0,1]  R518      -5.4583436250686646e-01
    z[3,0,1]  R519      -5.0999552011489868e-01
    z[3,0,1]  R520      -8.1726336479187012e-01
    z[3,0,1]  R521      -6.0983031988143921e-01
    z[3,0,1]  R522      3.8077855110168457e-01
    z[3,0,1]  R523      4.7441112995147705e-01
    z[3,0,1]  R524      -7.8147470951080322e-01
    z[3,0,1]  R525      -7.9768645763397217e-01
    z[3,0,1]  R526      8.7103432416915894e-01
    z[3,0,1]  R527      -4.1648185253143311e-01
    z[3,0,1]  R528      1.2210686504840851e-01
    z[3,0,1]  R529      0.944161593914032
    z[3,0,1]  R530      0.759667694568634
    z[3,0,1]  R531      -4.7425386309623718e-01
    z[3,0,2]  R4        1
    z[3,0,2]  R31       -1
    z[3,0,2]  R442      -1
    z[3,0,2]  R443      1
    z[3,0,2]  R452      -3.1495407223701477e-01
    z[3,0,2]  R453      -2.7223592996597290e-01
    z[3,0,2]  R454      1.9476598501205444e-01
    z[3,0,2]  R455      -3.0419480800628662e-01
    z[3,0,2]  R456      4.5412972569465637e-02
    z[3,0,2]  R457      -4.4046494364738464e-01
    z[3,0,2]  R458      5.1188701391220093e-01
    z[3,0,2]  R459      6.8993842601776123e-01
    z[3,0,2]  R460      5.3733807802200317e-01
    z[3,0,2]  R461      7.7381551265716553e-01
    z[3,0,2]  R462      -1.6695824265480042e-01
    z[3,0,2]  R463      -1.0524638742208481e-01
    z[3,0,2]  R464      -2.3312093317508698e-01
    z[3,0,2]  R465      -9.8969843238592148e-03
    z[3,0,2]  R466      -3.2058599591255188e-01
    z[3,0,2]  R467      -7.9349176958203316e-03
    z[3,0,2]  R468      -1.4685305953025818e-01
    z[3,0,2]  R469      -2.5821053981781006e-01
    z[3,0,2]  R470      -4.5450992882251740e-02
    z[3,0,2]  R471      3.5034954547882080e-01
    z[3,0,2]  R472      -1.6533946618437767e-02
    z[3,0,2]  R473      -1.4327681064605713e-01
    z[3,0,2]  R474      -1.1226122081279755e-01
    z[3,0,2]  R475      -1.1739084869623184e-01
    z[3,0,2]  R476      1.3021047413349152e-01
    z[3,0,2]  R477      -6.5592072904109955e-02
    z[3,0,2]  R478      1.4451918005943298e-01
    z[3,0,2]  R479      2.1304875612258911e-01
    z[3,0,2]  R480      1.1093472689390182e-01
    z[3,0,2]  R481      -6.2649093568325043e-02
    z[3,0,2]  R482      0.0575115866959095
    z[3,0,2]  R483      2.1006904542446136e-01
    z[3,0,2]  R484      -2.1441720426082611e-01
    z[3,0,2]  R485      -2.3992931842803955e-01
    z[3,0,2]  R486      3.1207486987113953e-01
    z[3,0,2]  R487      3.0928462743759155e-02
    z[3,0,2]  R488      -0.0356932133436203
    z[3,0,2]  R489      -1.3485740125179291e-01
    z[3,0,2]  R490      -1.8079439178109169e-02
    z[3,0,2]  R491      -2.6221296191215515e-01
    z[3,0,2]  R492      -2.2966243326663971e-01
    z[3,0,2]  R493      -7.7399136498570442e-03
    z[3,0,2]  R494      2.4974639713764191e-01
    z[3,0,2]  R495      -6.7057803273200989e-02
    z[3,0,2]  R496      1.5775233507156372e-01
    z[3,0,2]  R497      -8.3998069167137146e-03
    z[3,0,2]  R498      -2.7235758304595947e-01
    z[3,0,2]  R499      -9.1737903654575348e-02
    z[3,0,2]  R500      5.3540718555450439e-01
    z[3,0,2]  R501      0.501573920249939
    z[3,0,2]  R502      1.9580762088298798e-01
    z[3,0,2]  R503      3.1615075469017029e-01
    z[3,0,2]  R504      3.2304674386978149e-01
    z[3,0,2]  R505      1.4591987431049347e-01
    z[3,0,2]  R506      2.3431833088397980e-01
    z[3,0,2]  R507      4.8229777812957764e-01
    z[3,0,2]  R508      3.7313434481620789e-01
    z[3,0,2]  R509      4.3597152829170227e-01
    z[3,0,2]  R510      4.0399962663650513e-01
    z[3,0,2]  R511      5.3727221488952637e-01
    z[3,0,2]  R512      -9.5796346664428711e-02
    z[3,0,2]  R513      -0.360103964805603
    z[3,0,2]  R514      -3.0828937888145447e-01
    z[3,0,2]  R515      -1.4103728532791138e-01
    z[3,0,2]  R516      -6.1354603618383408e-02
    z[3,0,2]  R517      -3.6202916502952576e-01
    z[3,0,2]  R518      -2.9099497199058533e-01
    z[3,0,2]  R519      -5.0199472904205322e-01
    z[3,0,2]  R520      1.4629521965980530e-01
    z[3,0,2]  R521      -5.5146467685699463e-01
    z[3,0,2]  R522      -1.1649450659751892e-01
    z[3,0,2]  R523      3.7766832113265991e-01
    z[3,0,2]  R524      -4.6529714018106461e-02
    z[3,0,2]  R525      -3.2391363382339478e-01
    z[3,0,2]  R526      1.1710018664598465e-01
    z[3,0,2]  R527      8.9965946972370148e-02
    z[3,0,2]  R528      -2.5769764184951782e-01
    z[3,0,2]  R529      -1.6945490241050720e-01
    z[3,0,2]  R530      -3.6154675483703613e-01
    z[3,0,2]  R531      -3.6417570710182190e-01
    z[3,0,3]  R5        1
    z[3,0,3]  R32       -1
    z[3,0,3]  R444      -1
    z[3,0,3]  R445      1
    z[3,0,3]  R452      3.4320011734962463e-01
    z[3,0,3]  R453      3.5711315274238586e-01
    z[3,0,3]  R454      6.5942478179931641e-01
    z[3,0,3]  R455      5.9538805484771729e-01
    z[3,0,3]  R456      3.4576657414436340e-01
    z[3,0,3]  R457      7.0035117864608765e-01
    z[3,0,3]  R458      -0.530301034450531
    z[3,0,3]  R459      -2.6191276311874390e-01
    z[3,0,3]  R460      -3.3637505024671555e-02
    z[3,0,3]  R461      -3.3186116814613342e-01
    z[3,0,3]  R462      -7.4687272310256958e-02
    z[3,0,3]  R463      1.0632331669330597e-01
    z[3,0,3]  R464      2.7038154006004333e-01
    z[3,0,3]  R465      1.2183093279600143e-01
    z[3,0,3]  R466      3.7542287260293961e-02
    z[3,0,3]  R467      1.1555763334035873e-01
    z[3,0,3]  R468      2.9953292012214661e-01
    z[3,0,3]  R469      4.1325652599334717e-01
    z[3,0,3]  R470      2.7058649063110352e-01
    z[3,0,3]  R471      -4.5007247477769852e-02
    z[3,0,3]  R472      3.1242930889129639e-01
    z[3,0,3]  R473      -0.39503213763237
    z[3,0,3]  R474      -5.6164044141769409e-01
    z[3,0,3]  R475      -5.4107069969177246e-01
    z[3,0,3]  R476      -6.1921846866607666e-01
    z[3,0,3]  R477      -5.1277482509613037e-01
    z[3,0,3]  R478      -4.6367436647415161e-01
    z[3,0,3]  R479      -4.8262152075767517e-01
    z[3,0,3]  R480      -6.2656527757644653e-01
    z[3,0,3]  R481      -4.8673585057258606e-01
    z[3,0,3]  R482      7.2669649124145508e-01
    z[3,0,3]  R483      0.762295126914978
    z[3,0,3]  R484      -5.7686185836791992e-01
    z[3,0,3]  R485      -5.2052670717239380e-01
    z[3,0,3]  R486      -3.6024487018585205e-01
    z[3,0,3]  R487      -4.5294648408889771e-01
    z[3,0,3]  R488      -4.4176250696182251e-01
    z[3,0,3]  R489      -1.0698555409908295e-01
    z[3,0,3]  R490      -2.1624748408794403e-01
    z[3,0,3]  R491      -1.4532610774040222e-01
    z[3,0,3]  R492      8.5010147094726562e-01
    z[3,0,3]  R493      -5.5896854400634766e-01
    z[3,0,3]  R494      -5.5401455610990524e-02
    z[3,0,3]  R495      -2.5027725100517273e-01
    z[3,0,3]  R496      -3.6608001589775085e-01
    z[3,0,3]  R497      -2.4820853024721146e-02
    z[3,0,3]  R498      -5.3497594594955444e-01
    z[3,0,3]  R499      -4.3160125613212585e-01
    z[3,0,3]  R500      -2.8032356500625610e-01
    z[3,0,3]  R501      3.5390022397041321e-01
    z[3,0,3]  R502      -3.4916356205940247e-01
    z[3,0,3]  R503      -1.7162297666072845e-01
    z[3,0,3]  R504      -1.8864282965660095e-01
    z[3,0,3]  R505      2.3550543934106827e-02
    z[3,0,3]  R506      -0.0916028618812561
    z[3,0,3]  R507      -4.5122930407524109e-01
    z[3,0,3]  R508      1.0401997715234756e-01
    z[3,0,3]  R509      -2.1718591451644897e-01
    z[3,0,3]  R510      -4.6430063247680664e-01
    z[3,0,3]  R511      -5.0557094812393188e-01
    z[3,0,3]  R512      7.0558679103851318e-01
    z[3,0,3]  R513      6.3520252704620361e-01
    z[3,0,3]  R514      4.2031729221343994e-01
    z[3,0,3]  R515      4.5855760574340820e-01
    z[3,0,3]  R516      0.428813636302948
    z[3,0,3]  R517      7.3850327730178833e-01
    z[3,0,3]  R518      6.8741393089294434e-01
    z[3,0,3]  R519      5.9327334165573120e-01
    z[3,0,3]  R520      4.7143629193305969e-01
    z[3,0,3]  R521      3.4902539849281311e-01
    z[3,0,3]  R522      -2.2027720510959625e-01
    z[3,0,3]  R523      -1.4997886121273041e-01
    z[3,0,3]  R524      -1.0772560536861420e-01
    z[3,0,3]  R525      -1.4694376289844513e-01
    z[3,0,3]  R526      -3.6388251930475235e-02
    z[3,0,3]  R527      1.1856950819492340e-01
    z[3,0,3]  R528      -4.1951787471771240e-01
    z[3,0,3]  R529      -8.6664058268070221e-02
    z[3,0,3]  R530      -1.7696432769298553e-03
    z[3,0,3]  R531      -5.7630473375320435e-01
    z[3,0,4]  R6        1
    z[3,0,4]  R33       -1
    z[3,0,4]  R446      -1
    z[3,0,4]  R447      1
    z[3,0,4]  R452      1.5212135016918182e-01
    z[3,0,4]  R453      6.0544836521148682e-01
    z[3,0,4]  R454      1.1388329416513443e-01
    z[3,0,4]  R455      -2.4923862516880035e-01
    z[3,0,4]  R456      -4.1099062561988831e-01
    z[3,0,4]  R457      7.6116546988487244e-02
    z[3,0,4]  R458      -1.4724639058113098e-01
    z[3,0,4]  R459      -1.4814375340938568e-01
    z[3,0,4]  R460      1.4779733121395111e-01
    z[3,0,4]  R461      -1.4857585728168488e-01
    z[3,0,4]  R462      -1.5054804086685181e-01
    z[3,0,4]  R463      -2.9473719000816345e-01
    z[3,0,4]  R464      -0.156258225440979
    z[3,0,4]  R465      2.5375029444694519e-01
    z[3,0,4]  R466      -2.8916954994201660e-01
    z[3,0,4]  R467      1.9727160036563873e-01
    z[3,0,4]  R468      1.4298303425312042e-01
    z[3,0,4]  R469      1.8206825852394104e-01
    z[3,0,4]  R470      2.2723200917243958e-01
    z[3,0,4]  R471      4.6563889831304550e-02
    z[3,0,4]  R472      -1.5930096805095673e-01
    z[3,0,4]  R473      -2.0812867581844330e-01
    z[3,0,4]  R474      -2.5409471988677979e-01
    z[3,0,4]  R475      -3.5411116480827332e-01
    z[3,0,4]  R476      -2.4435031414031982e-01
    z[3,0,4]  R477      -1.3521975278854370e-01
    z[3,0,4]  R478      2.3473742604255676e-01
    z[3,0,4]  R479      1.3703167438507080e-01
    z[3,0,4]  R480      1.8078124523162842e-01
    z[3,0,4]  R481      3.0565834045410156e-01
    z[3,0,4]  R482      -0.0800301805138588
    z[3,0,4]  R483      1.5295787155628204e-01
    z[3,0,4]  R484      1.1559443175792694e-01
    z[3,0,4]  R485      6.0622924566268921e-01
    z[3,0,4]  R486      0.179230198264122
    z[3,0,4]  R487      -1.0031496174633503e-02
    z[3,0,4]  R488      3.5202977061271667e-01
    z[3,0,4]  R489      -2.7851012349128723e-01
    z[3,0,4]  R490      -1.1431746929883957e-01
    z[3,0,4]  R491      1.8334053456783295e-02
    z[3,0,4]  R492      1.1465849727392197e-01
    z[3,0,4]  R493      -1.5079215168952942e-01
    z[3,0,4]  R494      1.2787835299968719e-01
    z[3,0,4]  R495      1.1395392566919327e-01
    z[3,0,4]  R496      -1.2181679904460907e-01
    z[3,0,4]  R497      2.8046944737434387e-01
    z[3,0,4]  R498      -5.1584386825561523e-01
    z[3,0,4]  R499      -6.2819540500640869e-01
    z[3,0,4]  R500      7.1900326013565063e-01
    z[3,0,4]  R501      1.1113435961306095e-02
    z[3,0,4]  R502      2.4349787831306458e-01
    z[3,0,4]  R503      4.0638846158981323e-01
    z[3,0,4]  R504      -8.8096439838409424e-02
    z[3,0,4]  R505      -2.2533057257533073e-02
    z[3,0,4]  R506      -2.1347071230411530e-01
    z[3,0,4]  R507      -3.6403140425682068e-01
    z[3,0,4]  R508      5.3892578929662704e-02
    z[3,0,4]  R509      -2.7593040466308594e-01
    z[3,0,4]  R510      4.3897935748100281e-01
    z[3,0,4]  R511      -1.3020625710487366e-01
    z[3,0,4]  R512      1.1973444372415543e-01
    z[3,0,4]  R513      1.1419614404439926e-01
    z[3,0,4]  R514      -3.6403417587280273e-02
    z[3,0,4]  R515      3.3790281414985657e-01
    z[3,0,4]  R516      1.8731196224689484e-01
    z[3,0,4]  R517      -3.8630706071853638e-01
    z[3,0,4]  R518      2.4383902549743652e-01
    z[3,0,4]  R519      -6.3059397041797638e-02
    z[3,0,4]  R520      -0.080388642847538
    z[3,0,4]  R521      -0.14909727871418
    z[3,0,4]  R522      -0.154183492064476
    z[3,0,4]  R523      5.5469684302806854e-02
    z[3,0,4]  R524      -2.9021957516670227e-01
    z[3,0,4]  R525      2.2349886596202850e-01
    z[3,0,4]  R526      3.6730057001113892e-01
    z[3,0,4]  R527      -2.8336179256439209e-01
    z[3,0,4]  R528      -7.6043003797531128e-01
    z[3,0,4]  R529      -1.2781850062310696e-02
    z[3,0,4]  R530      3.2220616936683655e-01
    z[3,0,4]  R531      -3.0423709750175476e-01
    z[3,0,5]  R7        1
    z[3,0,5]  R34       -1
    z[3,0,5]  R448      -1
    z[3,0,5]  R449      1
    z[3,0,5]  R452      3.2471993565559387e-01
    z[3,0,5]  R453      1.3615280389785767e-01
    z[3,0,5]  R454      -2.1183695644140244e-02
    z[3,0,5]  R455      1.8469187617301941e-01
    z[3,0,5]  R456      2.7607583999633789e-01
    z[3,0,5]  R457      4.6119844913482666e-01
    z[3,0,5]  R458      1.7270718514919281e-01
    z[3,0,5]  R459      2.6913151144981384e-01
    z[3,0,5]  R460      -3.3632940053939819e-01
    z[3,0,5]  R461      -6.1255201697349548e-02
    z[3,0,5]  R462      -1.2070265598595142e-02
    z[3,0,5]  R463      -1.5667583048343658e-01
    z[3,0,5]  R464      -1.0563275776803493e-02
    z[3,0,5]  R465      2.7180045843124390e-01
    z[3,0,5]  R466      -1.4757966622710228e-02
    z[3,0,5]  R467      -3.0287897586822510e-01
    z[3,0,5]  R468      1.5523275732994080e-01
    z[3,0,5]  R469      -1.2730531394481659e-01
    z[3,0,5]  R470      -2.3361420631408691e-01
    z[3,0,5]  R471      -5.3906790912151337e-02
    z[3,0,5]  R472      0.88450688123703
    z[3,0,5]  R473      -2.3509602248668671e-01
    z[3,0,5]  R474      6.0226183384656906e-02
    z[3,0,5]  R475      -5.1337979733943939e-02
    z[3,0,5]  R476      -1.9504806399345398e-01
    z[3,0,5]  R477      -4.8167926073074341e-01
    z[3,0,5]  R478      -3.6643886566162109e-01
    z[3,0,5]  R479      -0.439810574054718
    z[3,0,5]  R480      -0.342242568731308
    z[3,0,5]  R481      -2.5903207063674927e-01
    z[3,0,5]  R482      5.7846188545227051e-01
    z[3,0,5]  R483      4.4787231087684631e-01
    z[3,0,5]  R484      -3.3854490518569946e-01
    z[3,0,5]  R485      -1.1588786542415619e-01
    z[3,0,5]  R486      3.4957417845726013e-01
    z[3,0,5]  R487      -2.5847530364990234e-01
    z[3,0,5]  R488      1.7605029046535492e-01
    z[3,0,5]  R489      1.0050392150878906e-01
    z[3,0,5]  R490      -5.0245508551597595e-02
    z[3,0,5]  R491      9.4093777239322662e-02
    z[3,0,5]  R492      -4.1067236661911011e-01
    z[3,0,5]  R493      -4.5013588666915894e-01
    z[3,0,5]  R494      3.2189333438873291e-01
    z[3,0,5]  R495      2.5142475962638855e-01
    z[3,0,5]  R496      -0.837743878364563
    z[3,0,5]  R497      2.1290406584739685e-01
    z[3,0,5]  R498      2.7396622300148010e-01
    z[3,0,5]  R499      3.4762862324714661e-01
    z[3,0,5]  R500      1.4043180644512177e-01
    z[3,0,5]  R501      -3.5550388693809509e-01
    z[3,0,5]  R502      -5.8974957466125488e-01
    z[3,0,5]  R503      -7.7146071195602417e-01
    z[3,0,5]  R504      -8.3842861652374268e-01
    z[3,0,5]  R505      -8.0394911766052246e-01
    z[3,0,5]  R506      -7.3026913404464722e-01
    z[3,0,5]  R507      -4.5336017012596130e-01
    z[3,0,5]  R508      -8.5456639528274536e-01
    z[3,0,5]  R509      -6.8966847658157349e-01
    z[3,0,5]  R510      -4.5109590888023376e-01
    z[3,0,5]  R511      -3.1475964188575745e-01
    z[3,0,5]  R512      2.5751274824142456e-01
    z[3,0,5]  R513      6.0638688504695892e-02
    z[3,0,5]  R514      1.7596489191055298e-01
    z[3,0,5]  R515      1.9838280975818634e-01
    z[3,0,5]  R516      -4.4085253030061722e-02
    z[3,0,5]  R517      -0.192597433924675
    z[3,0,5]  R518      2.7409407496452332e-01
    z[3,0,5]  R519      2.9440104961395264e-01
    z[3,0,5]  R520      4.5299485325813293e-02
    z[3,0,5]  R521      -1.4888846874237061e-01
    z[3,0,5]  R522      4.4473049044609070e-01
    z[3,0,5]  R523      4.8155647516250610e-01
    z[3,0,5]  R524      0.50826096534729
    z[3,0,5]  R525      2.1873778104782104e-01
    z[3,0,5]  R526      1.6478934884071350e-01
    z[3,0,5]  R527      8.0048346519470215e-01
    z[3,0,5]  R528      1.8756695091724396e-01
    z[3,0,5]  R529      4.3293926864862442e-02
    z[3,0,5]  R530      1.7215389013290405e-01
    z[3,0,5]  R531      9.0370990335941315e-02
    z[3,0,6]  R8        1
    z[3,0,6]  R35       -1
    z[3,0,6]  R450      -1
    z[3,0,6]  R451      1
    z[3,0,6]  R452      -1.8461908400058746e-01
    z[3,0,6]  R453      -1.6669057309627533e-01
    z[3,0,6]  R454      3.5490524768829346e-01
    z[3,0,6]  R455      -2.0352724194526672e-01
    z[3,0,6]  R456      1.1936455219984055e-01
    z[3,0,6]  R457      -2.6060926914215088e-01
    z[3,0,6]  R458      1.7777577042579651e-01
    z[3,0,6]  R459      1.3658711314201355e-01
    z[3,0,6]  R460      -1.6236859560012817e-01
    z[3,0,6]  R461      -6.8921104073524475e-02
    z[3,0,6]  R462      -9.9029108881950378e-02
    z[3,0,6]  R463      4.9343584105372429e-03
    z[3,0,6]  R464      -8.1637494266033173e-02
    z[3,0,6]  R465      3.4795474261045456e-02
    z[3,0,6]  R466      -6.8906836211681366e-02
    z[3,0,6]  R467      5.4065424948930740e-02
    z[3,0,6]  R468      5.4115884006023407e-02
    z[3,0,6]  R469      0.0679747611284256
    z[3,0,6]  R470      1.3578702509403229e-01
    z[3,0,6]  R471      2.6807633042335510e-01
    z[3,0,6]  R472      7.1148246526718140e-02
    z[3,0,6]  R473      -9.2562668025493622e-02
    z[3,0,6]  R474      7.3835469782352448e-02
    z[3,0,6]  R475      3.5258814692497253e-02
    z[3,0,6]  R476      -7.1503028273582458e-02
    z[3,0,6]  R477      9.9891006946563721e-02
    z[3,0,6]  R478      -2.1038312464952469e-02
    z[3,0,6]  R479      -1.5752756595611572e-01
    z[3,0,6]  R480      6.8824617192149162e-03
    z[3,0,6]  R481      -2.6545220613479614e-01
    z[3,0,6]  R482      1.4137212932109833e-01
    z[3,0,6]  R483      3.6631348729133606e-01
    z[3,0,6]  R484      -8.2015588879585266e-02
    z[3,0,6]  R485      -2.1970118582248688e-01
    z[3,0,6]  R486      0.0908239483833313
    z[3,0,6]  R487      -0.641921877861023
    z[3,0,6]  R488      8.6049064993858337e-02
    z[3,0,6]  R489      1.6886119544506073e-01
    z[3,0,6]  R490      2.4283771216869354e-01
    z[3,0,6]  R491      4.8933181911706924e-02
    z[3,0,6]  R492      0.0592205636203289
    z[3,0,6]  R493      2.4375896900892258e-02
    z[3,0,6]  R494      -6.8199324607849121e-01
    z[3,0,6]  R495      1.5630531311035156e-01
    z[3,0,6]  R496      -2.6589466258883476e-02
    z[3,0,6]  R497      -3.1645059585571289e-01
    z[3,0,6]  R498      -1.6363418102264404e-01
    z[3,0,6]  R499      1.8553754314780235e-02
    z[3,0,6]  R500      3.1172606348991394e-01
    z[3,0,6]  R501      -4.8182481527328491e-01
    z[3,0,6]  R502      -2.8082942962646484e-01
    z[3,0,6]  R503      3.7076551467180252e-02
    z[3,0,6]  R504      -5.2817560732364655e-02
    z[3,0,6]  R505      3.5354100167751312e-02
    z[3,0,6]  R506      -1.9615635275840759e-01
    z[3,0,6]  R507      -0.0438479483127594
    z[3,0,6]  R508      2.7327290177345276e-01
    z[3,0,6]  R509      2.6171356439590454e-01
    z[3,0,6]  R510      2.6546157896518707e-02
    z[3,0,6]  R511      3.5136502981185913e-01
    z[3,0,6]  R512      1.5173150599002838e-01
    z[3,0,6]  R513      -1.5349340438842773e-01
    z[3,0,6]  R514      -1.6870924830436707e-01
    z[3,0,6]  R515      -2.4577870965003967e-02
    z[3,0,6]  R516      2.6848694309592247e-02
    z[3,0,6]  R517      -1.0802821815013885e-01
    z[3,0,6]  R518      -5.4732402786612511e-03
    z[3,0,6]  R519      -2.1273775398731232e-01
    z[3,0,6]  R520      1.8075324594974518e-01
    z[3,0,6]  R521      -3.8762119412422180e-01
    z[3,0,6]  R522      -1.0170713067054749e-01
    z[3,0,6]  R523      3.6186963319778442e-01
    z[3,0,6]  R524      0.0724979117512703
    z[3,0,6]  R525      -2.8144511580467224e-01
    z[3,0,6]  R526      2.9696589335799217e-02
    z[3,0,6]  R527      2.8212261199951172e-01
    z[3,0,6]  R528      -0.229871928691864
    z[3,0,6]  R529      -2.4322873353958130e-01
    z[3,0,6]  R530      -0.394614040851593
    z[3,0,6]  R531      -4.5532837510108948e-01
    z[0,4,0]  R2        -1
    z[0,4,0]  R38       1
    z[0,4,0]  R532      -1
    z[0,4,0]  R533      1
    z[0,4,0]  R546      5.4950445890426636e-01
    z[0,4,0]  R547      2.2566643357276917e-01
    z[0,4,0]  R548      2.4773228168487549e-01
    z[0,4,0]  R549      5.1257789134979248e-01
    z[0,4,0]  R550      3.0807298421859741e-01
    z[0,4,0]  R551      3.7118816375732422e-01
    z[0,4,0]  R552      1.8057993054389954e-01
    z[0,4,0]  R553      2.5131982564926147e-01
    z[0,4,0]  R554      4.9685359001159668e-02
    z[0,4,0]  R555      2.3485079407691956e-01
    z[0,4,0]  R556      -5.6858336925506592e-01
    z[0,4,0]  R557      -6.2251865863800049e-01
    z[0,4,0]  R558      -8.0886995792388916e-01
    z[0,4,0]  R559      -0.775996744632721
    z[0,4,0]  R560      -8.7849384546279907e-01
    z[0,4,0]  R561      -3.0261451005935669e-01
    z[0,4,0]  R562      1.0116262733936310e-01
    z[0,4,0]  R563      -5.1856734789907932e-03
    z[0,4,0]  R564      -2.1734762191772461e-01
    z[0,4,0]  R565      -8.6758226156234741e-02
    z[0,4,0]  R566      7.4900770187377930e-01
    z[0,4,0]  R567      4.9384614825248718e-01
    z[0,4,0]  R568      1.6647800803184509e-01
    z[0,4,0]  R569      2.4530504643917084e-01
    z[0,4,0]  R570      -2.5162574648857117e-01
    z[0,4,0]  R571      -6.1069391667842865e-02
    z[0,4,0]  R572      2.7642402052879333e-01
    z[0,4,0]  R573      -1.0552392154932022e-01
    z[0,4,0]  R574      -5.4880715906620026e-02
    z[0,4,0]  R575      0.0477621927857399
    z[0,4,0]  R576      7.2173547744750977e-01
    z[0,4,0]  R577      -2.6034882664680481e-01
    z[0,4,0]  R578      -8.8026374578475952e-02
    z[0,4,0]  R579      7.0207589864730835e-01
    z[0,4,0]  R580      1.3437853753566742e-01
    z[0,4,0]  R581      6.1883461475372314e-01
    z[0,4,0]  R582      5.5191999673843384e-01
    z[0,4,0]  R583      5.7589358091354370e-01
    z[0,4,0]  R584      1.9529409706592560e-01
    z[0,4,0]  R585      8.8348609209060669e-01
    z[0,4,0]  R586      0.498344749212265
    z[0,4,0]  R587      -5.7064223289489746e-01
    z[0,4,0]  R588      -3.8162621855735779e-01
    z[0,4,0]  R589      -5.8480417728424072e-01
    z[0,4,0]  R590      -4.7194001078605652e-01
    z[0,4,0]  R591      -4.4435703754425049e-01
    z[0,4,0]  R592      -4.1637751460075378e-01
    z[0,4,0]  R593      -4.7644710540771484e-01
    z[0,4,0]  R594      -6.2589657306671143e-01
    z[0,4,0]  R595      -3.0824321508407593e-01
    z[0,4,0]  R596      6.4118367433547974e-01
    z[0,4,0]  R597      5.4827427864074707e-01
    z[0,4,0]  R598      3.2010135054588318e-01
    z[0,4,0]  R599      1.3908789493143559e-02
    z[0,4,0]  R600      3.6178115010261536e-01
    z[0,4,0]  R601      3.5426384210586548e-01
    z[0,4,0]  R602      3.4391263127326965e-01
    z[0,4,0]  R603      -3.3993339538574219e-01
    z[0,4,0]  R604      -0.0794341191649437
    z[0,4,0]  R605      -1.8189454078674316e-01
    z[0,4,0]  R606      6.8536871671676636e-01
    z[0,4,0]  R607      6.1935573816299438e-01
    z[0,4,0]  R608      -4.0746080875396729e-01
    z[0,4,0]  R609      4.1207635402679443e-01
    z[0,4,0]  R610      -3.0557766556739807e-02
    z[0,4,0]  R611      1.9815362989902496e-01
    z[0,4,0]  R612      -1.0177161544561386e-01
    z[0,4,0]  R613      -3.2355093955993652e-01
    z[0,4,0]  R614      -3.2967633008956909e-01
    z[0,4,0]  R615      -5.7720702886581421e-01
    z[0,4,1]  R3        -1
    z[0,4,1]  R39       1
    z[0,4,1]  R534      -1
    z[0,4,1]  R535      1
    z[0,4,1]  R546      2.2765761613845825e-01
    z[0,4,1]  R547      2.4081312119960785e-01
    z[0,4,1]  R548      -2.9183927178382874e-01
    z[0,4,1]  R549      2.5947010517120361e-01
    z[0,4,1]  R550      4.7376653552055359e-01
    z[0,4,1]  R551      -2.9329755902290344e-01
    z[0,4,1]  R552      -9.7342170774936676e-02
    z[0,4,1]  R553      2.8164383769035339e-01
    z[0,4,1]  R554      -0.471004843711853
    z[0,4,1]  R555      -4.0136891603469849e-01
    z[0,4,1]  R556      -2.5692740082740784e-01
    z[0,4,1]  R557      -1.9757397472858429e-01
    z[0,4,1]  R558      1.1519086360931396e-01
    z[0,4,1]  R559      1.1629398167133331e-01
    z[0,4,1]  R560      -5.3413126617670059e-02
    z[0,4,1]  R561      -1.8432384729385376e-01
    z[0,4,1]  R562      -5.4583436250686646e-01
    z[0,4,1]  R563      -5.0999552011489868e-01
    z[0,4,1]  R564      -8.1726336479187012e-01
    z[0,4,1]  R565      -6.0983031988143921e-01
    z[0,4,1]  R566      3.8077855110168457e-01
    z[0,4,1]  R567      4.7441112995147705e-01
    z[0,4,1]  R568      -7.8147470951080322e-01
    z[0,4,1]  R569      -7.9768645763397217e-01
    z[0,4,1]  R570      8.7103432416915894e-01
    z[0,4,1]  R571      -4.1648185253143311e-01
    z[0,4,1]  R572      1.2210686504840851e-01
    z[0,4,1]  R573      0.944161593914032
    z[0,4,1]  R574      0.759667694568634
    z[0,4,1]  R575      -4.7425386309623718e-01
    z[0,4,1]  R576      4.7464835643768311e-01
    z[0,4,1]  R577      -3.7263244390487671e-01
    z[0,4,1]  R578      -5.8896821737289429e-01
    z[0,4,1]  R579      5.5480856448411942e-02
    z[0,4,1]  R580      -0.356360524892807
    z[0,4,1]  R581      -2.9439383745193481e-01
    z[0,4,1]  R582      -3.9077866077423096e-01
    z[0,4,1]  R583      4.5883551239967346e-01
    z[0,4,1]  R584      -2.5890287756919861e-01
    z[0,4,1]  R585      1.8817149102687836e-01
    z[0,4,1]  R586      -3.1648527830839157e-02
    z[0,4,1]  R587      4.7781169414520264e-01
    z[0,4,1]  R588      4.4560694694519043e-01
    z[0,4,1]  R589      5.7730001211166382e-01
    z[0,4,1]  R590      3.6223095655441284e-01
    z[0,4,1]  R591      4.5222055912017822e-01
    z[0,4,1]  R592      5.4885065555572510e-01
    z[0,4,1]  R593      5.3115218877792358e-01
    z[0,4,1]  R594      5.1203662157058716e-01
    z[0,4,1]  R595      -3.8567224144935608e-01
    z[0,4,1]  R596      -4.6898555010557175e-02
    z[0,4,1]  R597      1.9691698253154755e-01
    z[0,4,1]  R598      -3.3078789710998535e-01
    z[0,4,1]  R599      -2.5322714447975159e-01
    z[0,4,1]  R600      -0.521737277507782
    z[0,4,1]  R601      2.8693714737892151e-01
    z[0,4,1]  R602      -4.4296371936798096e-01
    z[0,4,1]  R603      -6.5261906385421753e-01
    z[0,4,1]  R604      5.0646450370550156e-02
    z[0,4,1]  R605      -8.7560421228408813e-01
    z[0,4,1]  R606      8.7547548115253448e-02
    z[0,4,1]  R607      -5.1780784130096436e-01
    z[0,4,1]  R608      -5.1614469289779663e-01
    z[0,4,1]  R609      -1.3408043980598450e-01
    z[0,4,1]  R610      -1.9141638278961182e-01
    z[0,4,1]  R611      5.2375458180904388e-02
    z[0,4,1]  R612      1.0893474519252777e-01
    z[0,4,1]  R613      -1.1364394426345825e-01
    z[0,4,1]  R614      -2.2669158875942230e-01
    z[0,4,1]  R615      -0.592122495174408
    z[0,4,2]  R4        -1
    z[0,4,2]  R40       1
    z[0,4,2]  R536      -1
    z[0,4,2]  R537      1
    z[0,4,2]  R546      1.9580762088298798e-01
    z[0,4,2]  R547      3.1615075469017029e-01
    z[0,4,2]  R548      3.2304674386978149e-01
    z[0,4,2]  R549      1.4591987431049347e-01
    z[0,4,2]  R550      2.3431833088397980e-01
    z[0,4,2]  R551      4.8229777812957764e-01
    z[0,4,2]  R552      3.7313434481620789e-01
    z[0,4,2]  R553      4.3597152829170227e-01
    z[0,4,2]  R554      4.0399962663650513e-01
    z[0,4,2]  R555      5.3727221488952637e-01
    z[0,4,2]  R556      -9.5796346664428711e-02
    z[0,4,2]  R557      -0.360103964805603
    z[0,4,2]  R558      -3.0828937888145447e-01
    z[0,4,2]  R559      -1.4103728532791138e-01
    z[0,4,2]  R560      -6.1354603618383408e-02
    z[0,4,2]  R561      -3.6202916502952576e-01
    z[0,4,2]  R562      -2.9099497199058533e-01
    z[0,4,2]  R563      -5.0199472904205322e-01
    z[0,4,2]  R564      1.4629521965980530e-01
    z[0,4,2]  R565      -5.5146467685699463e-01
    z[0,4,2]  R566      -1.1649450659751892e-01
    z[0,4,2]  R567      3.7766832113265991e-01
    z[0,4,2]  R568      -4.6529714018106461e-02
    z[0,4,2]  R569      -3.2391363382339478e-01
    z[0,4,2]  R570      1.1710018664598465e-01
    z[0,4,2]  R571      8.9965946972370148e-02
    z[0,4,2]  R572      -2.5769764184951782e-01
    z[0,4,2]  R573      -1.6945490241050720e-01
    z[0,4,2]  R574      -3.6154675483703613e-01
    z[0,4,2]  R575      -3.6417570710182190e-01
    z[0,4,2]  R576      2.0658016204833984e-01
    z[0,4,2]  R577      5.1609843969345093e-01
    z[0,4,2]  R578      6.4757645130157471e-01
    z[0,4,2]  R579      9.8929800093173981e-02
    z[0,4,2]  R580      5.5037707090377808e-01
    z[0,4,2]  R581      1.7464052140712738e-01
    z[0,4,2]  R582      -2.3853220045566559e-01
    z[0,4,2]  R583      5.0685471296310425e-01
    z[0,4,2]  R584      2.4018318951129913e-01
    z[0,4,2]  R585      9.5787599682807922e-02
    z[0,4,2]  R586      -5.3479593992233276e-01
    z[0,4,2]  R587      -5.9657585620880127e-01
    z[0,4,2]  R588      -7.1719348430633545e-01
    z[0,4,2]  R589      -4.3153610825538635e-01
    z[0,4,2]  R590      -6.7312496900558472e-01
    z[0,4,2]  R591      -6.3912689685821533e-01
    z[0,4,2]  R592      -6.0853153467178345e-01
    z[0,4,2]  R593      -4.1915518045425415e-01
    z[0,4,2]  R594      -3.3209469914436340e-01
    z[0,4,2]  R595      -8.0496203899383545e-01
    z[0,4,2]  R596      -4.6399781107902527e-01
    z[0,4,2]  R597      -5.1879197359085083e-01
    z[0,4,2]  R598      -4.1803181171417236e-01
    z[0,4,2]  R599      1.7579983174800873e-01
    z[0,4,2]  R600      -2.2754608094692230e-01
    z[0,4,2]  R601      -2.3996305465698242e-01
    z[0,4,2]  R602      1.5741537511348724e-01
    z[0,4,2]  R603      -4.3415728211402893e-01
    z[0,4,2]  R604      0.576196551322937
    z[0,4,2]  R605      -4.0394324064254761e-01
    z[0,4,2]  R606      -0.0334198921918869
    z[0,4,2]  R607      1.4081464707851410e-01
    z[0,4,2]  R608      1.9569399952888489e-01
    z[0,4,2]  R609      1.2754398584365845e-01
    z[0,4,2]  R610      3.7761977314949036e-01
    z[0,4,2]  R611      0.517429530620575
    z[0,4,2]  R612      7.9806648194789886e-02
    z[0,4,2]  R613      -7.7853941917419434e-01
    z[0,4,2]  R614      -7.5481927394866943e-01
    z[0,4,2]  R615      -3.2312935590744019e-01
    z[0,4,3]  R5        -1
    z[0,4,3]  R41       1
    z[0,4,3]  R538      -1
    z[0,4,3]  R539      1
    z[0,4,3]  R546      -3.4916356205940247e-01
    z[0,4,3]  R547      -1.7162297666072845e-01
    z[0,4,3]  R548      -1.8864282965660095e-01
    z[0,4,3]  R549      2.3550543934106827e-02
    z[0,4,3]  R550      -0.0916028618812561
    z[0,4,3]  R551      -4.5122930407524109e-01
    z[0,4,3]  R552      1.0401997715234756e-01
    z[0,4,3]  R553      -2.1718591451644897e-01
    z[0,4,3]  R554      -4.6430063247680664e-01
    z[0,4,3]  R555      -5.0557094812393188e-01
    z[0,4,3]  R556      7.0558679103851318e-01
    z[0,4,3]  R557      6.3520252704620361e-01
    z[0,4,3]  R558      4.2031729221343994e-01
    z[0,4,3]  R559      4.5855760574340820e-01
    z[0,4,3]  R560      0.428813636302948
    z[0,4,3]  R561      7.3850327730178833e-01
    z[0,4,3]  R562      6.8741393089294434e-01
    z[0,4,3]  R563      5.9327334165573120e-01
    z[0,4,3]  R564      4.7143629193305969e-01
    z[0,4,3]  R565      3.4902539849281311e-01
    z[0,4,3]  R566      -2.2027720510959625e-01
    z[0,4,3]  R567      -1.4997886121273041e-01
    z[0,4,3]  R568      -1.0772560536861420e-01
    z[0,4,3]  R569      -1.4694376289844513e-01
    z[0,4,3]  R570      -3.6388251930475235e-02
    z[0,4,3]  R571      1.1856950819492340e-01
    z[0,4,3]  R572      -4.1951787471771240e-01
    z[0,4,3]  R573      -8.6664058268070221e-02
    z[0,4,3]  R574      -1.7696432769298553e-03
    z[0,4,3]  R575      -5.7630473375320435e-01
    z[0,4,3]  R576      8.6531199514865875e-02
    z[0,4,3]  R577      -5.8207309246063232e-01
    z[0,4,3]  R578      -3.2332116365432739e-01
    z[0,4,3]  R579      -1.1367462575435638e-01
    z[0,4,3]  R580      -5.6814730167388916e-01
    z[0,4,3]  R581      -3.3525720238685608e-01
    z[0,4,3]  R582      -1.4600183814764023e-02
    z[0,4,3]  R583      1.4067446812987328e-02
    z[0,4,3]  R584      -8.1641548871994019e-01
    z[0,4,3]  R585      -2.7022278308868408e-01
    z[0,4,3]  R586      2.8645089268684387e-01
    z[0,4,3]  R587      2.1356928348541260e-01
    z[0,4,3]  R588      2.5227975845336914e-01
    z[0,4,3]  R589      2.4058888852596283e-01
    z[0,4,3]  R590      3.8215324282646179e-01
    z[0,4,3]  R591      2.8521296381950378e-01
    z[0,4,3]  R592      3.2522711157798767e-01
    z[0,4,3]  R593      1.5950119495391846e-01
    z[0,4,3]  R594      1.9036103785037994e-01
    z[0,4,3]  R595      1.2890487909317017e-01
    z[0,4,3]  R596      -3.3502274751663208e-01
    z[0,4,3]  R597      5.0122457742691040e-01
    z[0,4,3]  R598      3.6730784177780151e-01
    z[0,4,3]  R599      -1.6924814879894257e-01
    z[0,4,3]  R600      0.257690966129303
    z[0,4,3]  R601      2.8943282365798950e-01
    z[0,4,3]  R602      3.2569810282438993e-03
    z[0,4,3]  R603      -3.0136129260063171e-01
    z[0,4,3]  R604      7.9324334859848022e-02
    z[0,4,3]  R605      -5.9938136488199234e-02
    z[0,4,3]  R606      1.2918472290039062e-01
    z[0,4,3]  R607      -5.5456644296646118e-01
    z[0,4,3]  R608      -3.4559625387191772e-01
    z[0,4,3]  R609      4.1245266795158386e-01
    z[0,4,3]  R610      2.6273833587765694e-02
    z[0,4,3]  R611      0.0676998421549797
    z[0,4,3]  R612      3.5153287649154663e-01
    z[0,4,3]  R613      4.7362190485000610e-01
    z[0,4,3]  R614      2.2187928855419159e-01
    z[0,4,3]  R615      3.4765559434890747e-01
    z[0,4,4]  R6        -1
    z[0,4,4]  R42       1
    z[0,4,4]  R540      -1
    z[0,4,4]  R541      1
    z[0,4,4]  R546      2.4349787831306458e-01
    z[0,4,4]  R547      4.0638846158981323e-01
    z[0,4,4]  R548      -8.8096439838409424e-02
    z[0,4,4]  R549      -2.2533057257533073e-02
    z[0,4,4]  R550      -2.1347071230411530e-01
    z[0,4,4]  R551      -3.6403140425682068e-01
    z[0,4,4]  R552      5.3892578929662704e-02
    z[0,4,4]  R553      -2.7593040466308594e-01
    z[0,4,4]  R554      4.3897935748100281e-01
    z[0,4,4]  R555      -1.3020625710487366e-01
    z[0,4,4]  R556      1.1973444372415543e-01
    z[0,4,4]  R557      1.1419614404439926e-01
    z[0,4,4]  R558      -3.6403417587280273e-02
    z[0,4,4]  R559      3.3790281414985657e-01
    z[0,4,4]  R560      1.8731196224689484e-01
    z[0,4,4]  R561      -3.8630706071853638e-01
    z[0,4,4]  R562      2.4383902549743652e-01
    z[0,4,4]  R563      -6.3059397041797638e-02
    z[0,4,4]  R564      -0.080388642847538
    z[0,4,4]  R565      -0.14909727871418
    z[0,4,4]  R566      -0.154183492064476
    z[0,4,4]  R567      5.5469684302806854e-02
    z[0,4,4]  R568      -2.9021957516670227e-01
    z[0,4,4]  R569      2.2349886596202850e-01
    z[0,4,4]  R570      3.6730057001113892e-01
    z[0,4,4]  R571      -2.8336179256439209e-01
    z[0,4,4]  R572      -7.6043003797531128e-01
    z[0,4,4]  R573      -1.2781850062310696e-02
    z[0,4,4]  R574      3.2220616936683655e-01
    z[0,4,4]  R575      -3.0423709750175476e-01
    z[0,4,4]  R576      -5.9527806937694550e-02
    z[0,4,4]  R577      -4.2494454979896545e-01
    z[0,4,4]  R578      1.4411987364292145e-01
    z[0,4,4]  R579      -5.6752490997314453e-01
    z[0,4,4]  R580      0.381523460149765
    z[0,4,4]  R581      5.0421410799026489e-01
    z[0,4,4]  R582      4.7919169068336487e-01
    z[0,4,4]  R583      4.1130978614091873e-02
    z[0,4,4]  R584      -8.1844948232173920e-02
    z[0,4,4]  R585      -1.9448215141892433e-02
    z[0,4,4]  R586      3.3866535872220993e-02
    z[0,4,4]  R587      6.8474814295768738e-02
    z[0,4,4]  R588      5.6055169552564621e-02
    z[0,4,4]  R589      -8.0082856118679047e-02
    z[0,4,4]  R590      -8.5795380175113678e-02
    z[0,4,4]  R591      -2.0354405045509338e-01
    z[0,4,4]  R592      -2.2154681384563446e-01
    z[0,4,4]  R593      -2.5517880916595459e-01
    z[0,4,4]  R594      5.2798591786995530e-04
    z[0,4,4]  R595      -1.6653573513031006e-01
    z[0,4,4]  R596      -0.0630049929022789
    z[0,4,4]  R597      5.7364720851182938e-03
    z[0,4,4]  R598      1.0685495287179947e-01
    z[0,4,4]  R599      -1.5308807790279388e-01
    z[0,4,4]  R600      -1.3211238384246826e-01
    z[0,4,4]  R601      6.2557297945022583e-01
    z[0,4,4]  R602      -0.349031537771225
    z[0,4,4]  R603      3.6674781586043537e-04
    z[0,4,4]  R604      9.4423428177833557e-02
    z[0,4,4]  R605      -1.2037818878889084e-01
    z[0,4,4]  R606      -1.4261111617088318e-01
    z[0,4,4]  R607      -7.8513838350772858e-02
    z[0,4,4]  R608      1.2679681181907654e-01
    z[0,4,4]  R609      7.3971919715404510e-02
    z[0,4,4]  R610      -1.2156744301319122e-01
    z[0,4,4]  R611      -4.2790338397026062e-02
    z[0,4,4]  R612      6.2806212902069092e-01
    z[0,4,4]  R613      1.0061531327664852e-02
    z[0,4,4]  R614      1.9800265133380890e-01
    z[0,4,4]  R615      1.0502353310585022e-01
    z[0,4,5]  R7        -1
    z[0,4,5]  R43       1
    z[0,4,5]  R542      -1
    z[0,4,5]  R543      1
    z[0,4,5]  R546      -5.8974957466125488e-01
    z[0,4,5]  R547      -7.7146071195602417e-01
    z[0,4,5]  R548      -8.3842861652374268e-01
    z[0,4,5]  R549      -8.0394911766052246e-01
    z[0,4,5]  R550      -7.3026913404464722e-01
    z[0,4,5]  R551      -4.5336017012596130e-01
    z[0,4,5]  R552      -8.5456639528274536e-01
    z[0,4,5]  R553      -6.8966847658157349e-01
    z[0,4,5]  R554      -4.5109590888023376e-01
    z[0,4,5]  R555      -3.1475964188575745e-01
    z[0,4,5]  R556      2.5751274824142456e-01
    z[0,4,5]  R557      6.0638688504695892e-02
    z[0,4,5]  R558      1.7596489191055298e-01
    z[0,4,5]  R559      1.9838280975818634e-01
    z[0,4,5]  R560      -4.4085253030061722e-02
    z[0,4,5]  R561      -0.192597433924675
    z[0,4,5]  R562      2.7409407496452332e-01
    z[0,4,5]  R563      2.9440104961395264e-01
    z[0,4,5]  R564      4.5299485325813293e-02
    z[0,4,5]  R565      -1.4888846874237061e-01
    z[0,4,5]  R566      4.4473049044609070e-01
    z[0,4,5]  R567      4.8155647516250610e-01
    z[0,4,5]  R568      0.50826096534729
    z[0,4,5]  R569      2.1873778104782104e-01
    z[0,4,5]  R570      1.6478934884071350e-01
    z[0,4,5]  R571      8.0048346519470215e-01
    z[0,4,5]  R572      1.8756695091724396e-01
    z[0,4,5]  R573      4.3293926864862442e-02
    z[0,4,5]  R574      1.7215389013290405e-01
    z[0,4,5]  R575      9.0370990335941315e-02
    z[0,4,5]  R576      -2.1922864019870758e-01
    z[0,4,5]  R577      -1.3864994049072266e-02
    z[0,4,5]  R578      9.8382443189620972e-02
    z[0,4,5]  R579      -3.9890626072883606e-01
    z[0,4,5]  R580      2.2245287895202637e-01
    z[0,4,5]  R581      -1.1194667965173721e-01
    z[0,4,5]  R582      -0.370022714138031
    z[0,4,5]  R583      0.0323251374065876
    z[0,4,5]  R584      2.7211108803749084e-01
    z[0,4,5]  R585      -3.1022295355796814e-01
    z[0,4,5]  R586      3.7785702943801880e-01
    z[0,4,5]  R587      1.9872845709323883e-01
    z[0,4,5]  R588      2.5526142120361328e-01
    z[0,4,5]  R589      2.6845550537109375e-01
    z[0,4,5]  R590      1.2860564887523651e-01
    z[0,4,5]  R591      2.4986462295055389e-01
    z[0,4,5]  R592      -3.5493888426572084e-03
    z[0,4,5]  R593      2.2794951498508453e-01
    z[0,4,5]  R594      0.0433090478181839
    z[0,4,5]  R595      2.3948150873184204e-01
    z[0,4,5]  R596      5.0294625759124756e-01
    z[0,4,5]  R597      -7.3644906282424927e-02
    z[0,4,5]  R598      4.1580373048782349e-01
    z[0,4,5]  R599      -7.5626122951507568e-01
    z[0,4,5]  R600      -1.0397802293300629e-01
    z[0,4,5]  R601      5.0789028406143188e-01
    z[0,4,5]  R602      -5.9557819366455078e-01
    z[0,4,5]  R603      2.0194037258625031e-01
    z[0,4,5]  R604      -7.8010231256484985e-01
    z[0,4,5]  R605      -1.3690859079360962e-01
    z[0,4,5]  R606      1.3491770625114441e-01
    z[0,4,5]  R607      -1.1217781901359558e-01
    z[0,4,5]  R608      -3.0806851387023926e-01
    z[0,4,5]  R609      5.2376675605773926e-01
    z[0,4,5]  R610      -8.8750118017196655e-01
    z[0,4,5]  R611      -0.826915442943573
    z[0,4,5]  R612      6.7276149988174438e-01
    z[0,4,5]  R613      2.2474014759063721e-01
    z[0,4,5]  R614      3.0902171134948730e-01
    z[0,4,5]  R615      1.7537845671176910e-01
    z[0,4,6]  R8        -1
    z[0,4,6]  R44       1
    z[0,4,6]  R544      -1
    z[0,4,6]  R545      1
    z[0,4,6]  R546      -2.8082942962646484e-01
    z[0,4,6]  R547      3.7076551467180252e-02
    z[0,4,6]  R548      -5.2817560732364655e-02
    z[0,4,6]  R549      3.5354100167751312e-02
    z[0,4,6]  R550      -1.9615635275840759e-01
    z[0,4,6]  R551      -0.0438479483127594
    z[0,4,6]  R552      2.7327290177345276e-01
    z[0,4,6]  R553      2.6171356439590454e-01
    z[0,4,6]  R554      2.6546157896518707e-02
    z[0,4,6]  R555      3.5136502981185913e-01
    z[0,4,6]  R556      1.5173150599002838e-01
    z[0,4,6]  R557      -1.5349340438842773e-01
    z[0,4,6]  R558      -1.6870924830436707e-01
    z[0,4,6]  R559      -2.4577870965003967e-02
    z[0,4,6]  R560      2.6848694309592247e-02
    z[0,4,6]  R561      -1.0802821815013885e-01
    z[0,4,6]  R562      -5.4732402786612511e-03
    z[0,4,6]  R563      -2.1273775398731232e-01
    z[0,4,6]  R564      1.8075324594974518e-01
    z[0,4,6]  R565      -3.8762119412422180e-01
    z[0,4,6]  R566      -1.0170713067054749e-01
    z[0,4,6]  R567      3.6186963319778442e-01
    z[0,4,6]  R568      0.0724979117512703
    z[0,4,6]  R569      -2.8144511580467224e-01
    z[0,4,6]  R570      2.9696589335799217e-02
    z[0,4,6]  R571      2.8212261199951172e-01
    z[0,4,6]  R572      -0.229871928691864
    z[0,4,6]  R573      -2.4322873353958130e-01
    z[0,4,6]  R574      -0.394614040851593
    z[0,4,6]  R575      -4.5532837510108948e-01
    z[0,4,6]  R576      -3.8992151618003845e-01
    z[0,4,6]  R577      8.6179308593273163e-02
    z[0,4,6]  R578      0.301705539226532
    z[0,4,6]  R579      0.00955789815634489
    z[0,4,6]  R580      -1.8492631614208221e-01
    z[0,4,6]  R581      -3.4744119644165039e-01
    z[0,4,6]  R582      -3.4499862790107727e-01
    z[0,4,6]  R583      4.4494986534118652e-01
    z[0,4,6]  R584      -0.299773633480072
    z[0,4,6]  R585      -7.2330847382545471e-02
    z[0,4,6]  R586      4.8853579163551331e-01
    z[0,4,6]  R587      -1.9156420603394508e-02
    z[0,4,6]  R588      -0.0973849669098854
    z[0,4,6]  R589      -4.6267926692962646e-02
    z[0,4,6]  R590      1.5173251926898956e-01
    z[0,4,6]  R591      -0.065963514149189
    z[0,4,6]  R592      -0.0146268829703331
    z[0,4,6]  R593      4.1553181409835815e-01
    z[0,4,6]  R594      4.4460281729698181e-01
    z[0,4,6]  R595      -0.0810999944806099
    z[0,4,6]  R596      0.0471709668636322
    z[0,4,6]  R597      3.6713933944702148e-01
    z[0,4,6]  R598      5.4234504699707031e-01
    z[0,4,6]  R599      -5.2987277507781982e-01
    z[0,4,6]  R600      0.671161413192749
    z[0,4,6]  R601      3.8942303508520126e-02
    z[0,4,6]  R602      0.429162859916687
    z[0,4,6]  R603      -3.7207847833633423e-01
    z[0,4,6]  R604      -1.8802908062934875e-01
    z[0,4,6]  R605      1.5293040312826633e-02
    z[0,4,6]  R606      6.8283146619796753e-01
    z[0,4,6]  R607      4.6395670622587204e-02
    z[0,4,6]  R608      -5.4667526483535767e-01
    z[0,4,6]  R609      -0.588240921497345
    z[0,4,6]  R610      -1.2923638522624969e-01
    z[0,4,6]  R611      -7.4335299432277679e-03
    z[0,4,6]  R612      -2.7590328827500343e-02
    z[0,4,6]  R613      3.6730885505676270e-02
    z[0,4,6]  R614      -2.9367044568061829e-01
    z[0,4,6]  R615      2.2171714901924133e-01
    z[4,0,0]  R2        1
    z[4,0,0]  R38       -1
    z[4,0,0]  R616      -1
    z[4,0,0]  R617      1
    z[4,0,0]  R630      7.2173547744750977e-01
    z[4,0,0]  R631      -2.6034882664680481e-01
    z[4,0,0]  R632      -8.8026374578475952e-02
    z[4,0,0]  R633      7.0207589864730835e-01
    z[4,0,0]  R634      1.3437853753566742e-01
    z[4,0,0]  R635      6.1883461475372314e-01
    z[4,0,0]  R636      5.5191999673843384e-01
    z[4,0,0]  R637      5.7589358091354370e-01
    z[4,0,0]  R638      1.9529409706592560e-01
    z[4,0,0]  R639      8.8348609209060669e-01
    z[4,0,0]  R640      0.498344749212265
    z[4,0,0]  R641      -5.7064223289489746e-01
    z[4,0,0]  R642      -3.8162621855735779e-01
    z[4,0,0]  R643      -5.8480417728424072e-01
    z[4,0,0]  R644      -4.7194001078605652e-01
    z[4,0,0]  R645      -4.4435703754425049e-01
    z[4,0,0]  R646      -4.1637751460075378e-01
    z[4,0,0]  R647      -4.7644710540771484e-01
    z[4,0,0]  R648      -6.2589657306671143e-01
    z[4,0,0]  R649      -3.0824321508407593e-01
    z[4,0,0]  R650      6.4118367433547974e-01
    z[4,0,0]  R651      5.4827427864074707e-01
    z[4,0,0]  R652      3.2010135054588318e-01
    z[4,0,0]  R653      1.3908789493143559e-02
    z[4,0,0]  R654      3.6178115010261536e-01
    z[4,0,0]  R655      3.5426384210586548e-01
    z[4,0,0]  R656      3.4391263127326965e-01
    z[4,0,0]  R657      -3.3993339538574219e-01
    z[4,0,0]  R658      -0.0794341191649437
    z[4,0,0]  R659      -1.8189454078674316e-01
    z[4,0,0]  R660      6.8536871671676636e-01
    z[4,0,0]  R661      6.1935573816299438e-01
    z[4,0,0]  R662      -4.0746080875396729e-01
    z[4,0,0]  R663      4.1207635402679443e-01
    z[4,0,0]  R664      -3.0557766556739807e-02
    z[4,0,0]  R665      1.9815362989902496e-01
    z[4,0,0]  R666      -1.0177161544561386e-01
    z[4,0,0]  R667      -3.2355093955993652e-01
    z[4,0,0]  R668      -3.2967633008956909e-01
    z[4,0,0]  R669      -5.7720702886581421e-01
    z[4,0,0]  R670      5.4950445890426636e-01
    z[4,0,0]  R671      2.2566643357276917e-01
    z[4,0,0]  R672      2.4773228168487549e-01
    z[4,0,0]  R673      5.1257789134979248e-01
    z[4,0,0]  R674      3.0807298421859741e-01
    z[4,0,0]  R675      3.7118816375732422e-01
    z[4,0,0]  R676      1.8057993054389954e-01
    z[4,0,0]  R677      2.5131982564926147e-01
    z[4,0,0]  R678      4.9685359001159668e-02
    z[4,0,0]  R679      2.3485079407691956e-01
    z[4,0,0]  R680      -5.6858336925506592e-01
    z[4,0,0]  R681      -6.2251865863800049e-01
    z[4,0,0]  R682      -8.0886995792388916e-01
    z[4,0,0]  R683      -0.775996744632721
    z[4,0,0]  R684      -8.7849384546279907e-01
    z[4,0,0]  R685      -3.0261451005935669e-01
    z[4,0,0]  R686      1.0116262733936310e-01
    z[4,0,0]  R687      -5.1856734789907932e-03
    z[4,0,0]  R688      -2.1734762191772461e-01
    z[4,0,0]  R689      -8.6758226156234741e-02
    z[4,0,0]  R690      7.4900770187377930e-01
    z[4,0,0]  R691      4.9384614825248718e-01
    z[4,0,0]  R692      1.6647800803184509e-01
    z[4,0,0]  R693      2.4530504643917084e-01
    z[4,0,0]  R694      -2.5162574648857117e-01
    z[4,0,0]  R695      -6.1069391667842865e-02
    z[4,0,0]  R696      2.7642402052879333e-01
    z[4,0,0]  R697      -1.0552392154932022e-01
    z[4,0,0]  R698      -5.4880715906620026e-02
    z[4,0,0]  R699      0.0477621927857399
    z[4,0,1]  R3        1
    z[4,0,1]  R39       -1
    z[4,0,1]  R618      -1
    z[4,0,1]  R619      1
    z[4,0,1]  R630      4.7464835643768311e-01
    z[4,0,1]  R631      -3.7263244390487671e-01
    z[4,0,1]  R632      -5.8896821737289429e-01
    z[4,0,1]  R633      5.5480856448411942e-02
    z[4,0,1]  R634      -0.356360524892807
    z[4,0,1]  R635      -2.9439383745193481e-01
    z[4,0,1]  R636      -3.9077866077423096e-01
    z[4,0,1]  R637      4.5883551239967346e-01
    z[4,0,1]  R638      -2.5890287756919861e-01
    z[4,0,1]  R639      1.8817149102687836e-01
    z[4,0,1]  R640      -3.1648527830839157e-02
    z[4,0,1]  R641      4.7781169414520264e-01
    z[4,0,1]  R642      4.4560694694519043e-01
    z[4,0,1]  R643      5.7730001211166382e-01
    z[4,0,1]  R644      3.6223095655441284e-01
    z[4,0,1]  R645      4.5222055912017822e-01
    z[4,0,1]  R646      5.4885065555572510e-01
    z[4,0,1]  R647      5.3115218877792358e-01
    z[4,0,1]  R648      5.1203662157058716e-01
    z[4,0,1]  R649      -3.8567224144935608e-01
    z[4,0,1]  R650      -4.6898555010557175e-02
    z[4,0,1]  R651      1.9691698253154755e-01
    z[4,0,1]  R652      -3.3078789710998535e-01
    z[4,0,1]  R653      -2.5322714447975159e-01
    z[4,0,1]  R654      -0.521737277507782
    z[4,0,1]  R655      2.8693714737892151e-01
    z[4,0,1]  R656      -4.4296371936798096e-01
    z[4,0,1]  R657      -6.5261906385421753e-01
    z[4,0,1]  R658      5.0646450370550156e-02
    z[4,0,1]  R659      -8.7560421228408813e-01
    z[4,0,1]  R660      8.7547548115253448e-02
    z[4,0,1]  R661      -5.1780784130096436e-01
    z[4,0,1]  R662      -5.1614469289779663e-01
    z[4,0,1]  R663      -1.3408043980598450e-01
    z[4,0,1]  R664      -1.9141638278961182e-01
    z[4,0,1]  R665      5.2375458180904388e-02
    z[4,0,1]  R666      1.0893474519252777e-01
    z[4,0,1]  R667      -1.1364394426345825e-01
    z[4,0,1]  R668      -2.2669158875942230e-01
    z[4,0,1]  R669      -0.592122495174408
    z[4,0,1]  R670      2.2765761613845825e-01
    z[4,0,1]  R671      2.4081312119960785e-01
    z[4,0,1]  R672      -2.9183927178382874e-01
    z[4,0,1]  R673      2.5947010517120361e-01
    z[4,0,1]  R674      4.7376653552055359e-01
    z[4,0,1]  R675      -2.9329755902290344e-01
    z[4,0,1]  R676      -9.7342170774936676e-02
    z[4,0,1]  R677      2.8164383769035339e-01
    z[4,0,1]  R678      -0.471004843711853
    z[4,0,1]  R679      -4.0136891603469849e-01
    z[4,0,1]  R680      -2.5692740082740784e-01
    z[4,0,1]  R681      -1.9757397472858429e-01
    z[4,0,1]  R682      1.1519086360931396e-01
    z[4,0,1]  R683      1.1629398167133331e-01
    z[4,0,1]  R684      -5.3413126617670059e-02
    z[4,0,1]  R685      -1.8432384729385376e-01
    z[4,0,1]  R686      -5.4583436250686646e-01
    z[4,0,1]  R687      -5.0999552011489868e-01
    z[4,0,1]  R688      -8.1726336479187012e-01
    z[4,0,1]  R689      -6.0983031988143921e-01
    z[4,0,1]  R690      3.8077855110168457e-01
    z[4,0,1]  R691      4.7441112995147705e-01
    z[4,0,1]  R692      -7.8147470951080322e-01
    z[4,0,1]  R693      -7.9768645763397217e-01
    z[4,0,1]  R694      8.7103432416915894e-01
    z[4,0,1]  R695      -4.1648185253143311e-01
    z[4,0,1]  R696      1.2210686504840851e-01
    z[4,0,1]  R697      0.944161593914032
    z[4,0,1]  R698      0.759667694568634
    z[4,0,1]  R699      -4.7425386309623718e-01
    z[4,0,2]  R4        1
    z[4,0,2]  R40       -1
    z[4,0,2]  R620      -1
    z[4,0,2]  R621      1
    z[4,0,2]  R630      2.0658016204833984e-01
    z[4,0,2]  R631      5.1609843969345093e-01
    z[4,0,2]  R632      6.4757645130157471e-01
    z[4,0,2]  R633      9.8929800093173981e-02
    z[4,0,2]  R634      5.5037707090377808e-01
    z[4,0,2]  R635      1.7464052140712738e-01
    z[4,0,2]  R636      -2.3853220045566559e-01
    z[4,0,2]  R637      5.0685471296310425e-01
    z[4,0,2]  R638      2.4018318951129913e-01
    z[4,0,2]  R639      9.5787599682807922e-02
    z[4,0,2]  R640      -5.3479593992233276e-01
    z[4,0,2]  R641      -5.9657585620880127e-01
    z[4,0,2]  R642      -7.1719348430633545e-01
    z[4,0,2]  R643      -4.3153610825538635e-01
    z[4,0,2]  R644      -6.7312496900558472e-01
    z[4,0,2]  R645      -6.3912689685821533e-01
    z[4,0,2]  R646      -6.0853153467178345e-01
    z[4,0,2]  R647      -4.1915518045425415e-01
    z[4,0,2]  R648      -3.3209469914436340e-01
    z[4,0,2]  R649      -8.0496203899383545e-01
    z[4,0,2]  R650      -4.6399781107902527e-01
    z[4,0,2]  R651      -5.1879197359085083e-01
    z[4,0,2]  R652      -4.1803181171417236e-01
    z[4,0,2]  R653      1.7579983174800873e-01
    z[4,0,2]  R654      -2.2754608094692230e-01
    z[4,0,2]  R655      -2.3996305465698242e-01
    z[4,0,2]  R656      1.5741537511348724e-01
    z[4,0,2]  R657      -4.3415728211402893e-01
    z[4,0,2]  R658      0.576196551322937
    z[4,0,2]  R659      -4.0394324064254761e-01
    z[4,0,2]  R660      -0.0334198921918869
    z[4,0,2]  R661      1.4081464707851410e-01
    z[4,0,2]  R662      1.9569399952888489e-01
    z[4,0,2]  R663      1.2754398584365845e-01
    z[4,0,2]  R664      3.7761977314949036e-01
    z[4,0,2]  R665      0.517429530620575
    z[4,0,2]  R666      7.9806648194789886e-02
    z[4,0,2]  R667      -7.7853941917419434e-01
    z[4,0,2]  R668      -7.5481927394866943e-01
    z[4,0,2]  R669      -3.2312935590744019e-01
    z[4,0,2]  R670      1.9580762088298798e-01
    z[4,0,2]  R671      3.1615075469017029e-01
    z[4,0,2]  R672      3.2304674386978149e-01
    z[4,0,2]  R673      1.4591987431049347e-01
    z[4,0,2]  R674      2.3431833088397980e-01
    z[4,0,2]  R675      4.8229777812957764e-01
    z[4,0,2]  R676      3.7313434481620789e-01
    z[4,0,2]  R677      4.3597152829170227e-01
    z[4,0,2]  R678      4.0399962663650513e-01
    z[4,0,2]  R679      5.3727221488952637e-01
    z[4,0,2]  R680      -9.5796346664428711e-02
    z[4,0,2]  R681      -0.360103964805603
    z[4,0,2]  R682      -3.0828937888145447e-01
    z[4,0,2]  R683      -1.4103728532791138e-01
    z[4,0,2]  R684      -6.1354603618383408e-02
    z[4,0,2]  R685      -3.6202916502952576e-01
    z[4,0,2]  R686      -2.9099497199058533e-01
    z[4,0,2]  R687      -5.0199472904205322e-01
    z[4,0,2]  R688      1.4629521965980530e-01
    z[4,0,2]  R689      -5.5146467685699463e-01
    z[4,0,2]  R690      -1.1649450659751892e-01
    z[4,0,2]  R691      3.7766832113265991e-01
    z[4,0,2]  R692      -4.6529714018106461e-02
    z[4,0,2]  R693      -3.2391363382339478e-01
    z[4,0,2]  R694      1.1710018664598465e-01
    z[4,0,2]  R695      8.9965946972370148e-02
    z[4,0,2]  R696      -2.5769764184951782e-01
    z[4,0,2]  R697      -1.6945490241050720e-01
    z[4,0,2]  R698      -3.6154675483703613e-01
    z[4,0,2]  R699      -3.6417570710182190e-01
    z[4,0,3]  R5        1
    z[4,0,3]  R41       -1
    z[4,0,3]  R622      -1
    z[4,0,3]  R623      1
    z[4,0,3]  R630      8.6531199514865875e-02
    z[4,0,3]  R631      -5.8207309246063232e-01
    z[4,0,3]  R632      -3.2332116365432739e-01
    z[4,0,3]  R633      -1.1367462575435638e-01
    z[4,0,3]  R634      -5.6814730167388916e-01
    z[4,0,3]  R635      -3.3525720238685608e-01
    z[4,0,3]  R636      -1.4600183814764023e-02
    z[4,0,3]  R637      1.4067446812987328e-02
    z[4,0,3]  R638      -8.1641548871994019e-01
    z[4,0,3]  R639      -2.7022278308868408e-01
    z[4,0,3]  R640      2.8645089268684387e-01
    z[4,0,3]  R641      2.1356928348541260e-01
    z[4,0,3]  R642      2.5227975845336914e-01
    z[4,0,3]  R643      2.4058888852596283e-01
    z[4,0,3]  R644      3.8215324282646179e-01
    z[4,0,3]  R645      2.8521296381950378e-01
    z[4,0,3]  R646      3.2522711157798767e-01
    z[4,0,3]  R647      1.5950119495391846e-01
    z[4,0,3]  R648      1.9036103785037994e-01
    z[4,0,3]  R649      1.2890487909317017e-01
    z[4,0,3]  R650      -3.3502274751663208e-01
    z[4,0,3]  R651      5.0122457742691040e-01
    z[4,0,3]  R652      3.6730784177780151e-01
    z[4,0,3]  R653      -1.6924814879894257e-01
    z[4,0,3]  R654      0.257690966129303
    z[4,0,3]  R655      2.8943282365798950e-01
    z[4,0,3]  R656      3.2569810282438993e-03
    z[4,0,3]  R657      -3.0136129260063171e-01
    z[4,0,3]  R658      7.9324334859848022e-02
    z[4,0,3]  R659      -5.9938136488199234e-02
    z[4,0,3]  R660      1.2918472290039062e-01
    z[4,0,3]  R661      -5.5456644296646118e-01
    z[4,0,3]  R662      -3.4559625387191772e-01
    z[4,0,3]  R663      4.1245266795158386e-01
    z[4,0,3]  R664      2.6273833587765694e-02
    z[4,0,3]  R665      0.0676998421549797
    z[4,0,3]  R666      3.5153287649154663e-01
    z[4,0,3]  R667      4.7362190485000610e-01
    z[4,0,3]  R668      2.2187928855419159e-01
    z[4,0,3]  R669      3.4765559434890747e-01
    z[4,0,3]  R670      -3.4916356205940247e-01
    z[4,0,3]  R671      -1.7162297666072845e-01
    z[4,0,3]  R672      -1.8864282965660095e-01
    z[4,0,3]  R673      2.3550543934106827e-02
    z[4,0,3]  R674      -0.0916028618812561
    z[4,0,3]  R675      -4.5122930407524109e-01
    z[4,0,3]  R676      1.0401997715234756e-01
    z[4,0,3]  R677      -2.1718591451644897e-01
    z[4,0,3]  R678      -4.6430063247680664e-01
    z[4,0,3]  R679      -5.0557094812393188e-01
    z[4,0,3]  R680      7.0558679103851318e-01
    z[4,0,3]  R681      6.3520252704620361e-01
    z[4,0,3]  R682      4.2031729221343994e-01
    z[4,0,3]  R683      4.5855760574340820e-01
    z[4,0,3]  R684      0.428813636302948
    z[4,0,3]  R685      7.3850327730178833e-01
    z[4,0,3]  R686      6.8741393089294434e-01
    z[4,0,3]  R687      5.9327334165573120e-01
    z[4,0,3]  R688      4.7143629193305969e-01
    z[4,0,3]  R689      3.4902539849281311e-01
    z[4,0,3]  R690      -2.2027720510959625e-01
    z[4,0,3]  R691      -1.4997886121273041e-01
    z[4,0,3]  R692      -1.0772560536861420e-01
    z[4,0,3]  R693      -1.4694376289844513e-01
    z[4,0,3]  R694      -3.6388251930475235e-02
    z[4,0,3]  R695      1.1856950819492340e-01
    z[4,0,3]  R696      -4.1951787471771240e-01
    z[4,0,3]  R697      -8.6664058268070221e-02
    z[4,0,3]  R698      -1.7696432769298553e-03
    z[4,0,3]  R699      -5.7630473375320435e-01
    z[4,0,4]  R6        1
    z[4,0,4]  R42       -1
    z[4,0,4]  R624      -1
    z[4,0,4]  R625      1
    z[4,0,4]  R630      -5.9527806937694550e-02
    z[4,0,4]  R631      -4.2494454979896545e-01
    z[4,0,4]  R632      1.4411987364292145e-01
    z[4,0,4]  R633      -5.6752490997314453e-01
    z[4,0,4]  R634      0.381523460149765
    z[4,0,4]  R635      5.0421410799026489e-01
    z[4,0,4]  R636      4.7919169068336487e-01
    z[4,0,4]  R637      4.1130978614091873e-02
    z[4,0,4]  R638      -8.1844948232173920e-02
    z[4,0,4]  R639      -1.9448215141892433e-02
    z[4,0,4]  R640      3.3866535872220993e-02
    z[4,0,4]  R641      6.8474814295768738e-02
    z[4,0,4]  R642      5.6055169552564621e-02
    z[4,0,4]  R643      -8.0082856118679047e-02
    z[4,0,4]  R644      -8.5795380175113678e-02
    z[4,0,4]  R645      -2.0354405045509338e-01
    z[4,0,4]  R646      -2.2154681384563446e-01
    z[4,0,4]  R647      -2.5517880916595459e-01
    z[4,0,4]  R648      5.2798591786995530e-04
    z[4,0,4]  R649      -1.6653573513031006e-01
    z[4,0,4]  R650      -0.0630049929022789
    z[4,0,4]  R651      5.7364720851182938e-03
    z[4,0,4]  R652      1.0685495287179947e-01
    z[4,0,4]  R653      -1.5308807790279388e-01
    z[4,0,4]  R654      -1.3211238384246826e-01
    z[4,0,4]  R655      6.2557297945022583e-01
    z[4,0,4]  R656      -0.349031537771225
    z[4,0,4]  R657      3.6674781586043537e-04
    z[4,0,4]  R658      9.4423428177833557e-02
    z[4,0,4]  R659      -1.2037818878889084e-01
    z[4,0,4]  R660      -1.4261111617088318e-01
    z[4,0,4]  R661      -7.8513838350772858e-02
    z[4,0,4]  R662      1.2679681181907654e-01
    z[4,0,4]  R663      7.3971919715404510e-02
    z[4,0,4]  R664      -1.2156744301319122e-01
    z[4,0,4]  R665      -4.2790338397026062e-02
    z[4,0,4]  R666      6.2806212902069092e-01
    z[4,0,4]  R667      1.0061531327664852e-02
    z[4,0,4]  R668      1.9800265133380890e-01
    z[4,0,4]  R669      1.0502353310585022e-01
    z[4,0,4]  R670      2.4349787831306458e-01
    z[4,0,4]  R671      4.0638846158981323e-01
    z[4,0,4]  R672      -8.8096439838409424e-02
    z[4,0,4]  R673      -2.2533057257533073e-02
    z[4,0,4]  R674      -2.1347071230411530e-01
    z[4,0,4]  R675      -3.6403140425682068e-01
    z[4,0,4]  R676      5.3892578929662704e-02
    z[4,0,4]  R677      -2.7593040466308594e-01
    z[4,0,4]  R678      4.3897935748100281e-01
    z[4,0,4]  R679      -1.3020625710487366e-01
    z[4,0,4]  R680      1.1973444372415543e-01
    z[4,0,4]  R681      1.1419614404439926e-01
    z[4,0,4]  R682      -3.6403417587280273e-02
    z[4,0,4]  R683      3.3790281414985657e-01
    z[4,0,4]  R684      1.8731196224689484e-01
    z[4,0,4]  R685      -3.8630706071853638e-01
    z[4,0,4]  R686      2.4383902549743652e-01
    z[4,0,4]  R687      -6.3059397041797638e-02
    z[4,0,4]  R688      -0.080388642847538
    z[4,0,4]  R689      -0.14909727871418
    z[4,0,4]  R690      -0.154183492064476
    z[4,0,4]  R691      5.5469684302806854e-02
    z[4,0,4]  R692      -2.9021957516670227e-01
    z[4,0,4]  R693      2.2349886596202850e-01
    z[4,0,4]  R694      3.6730057001113892e-01
    z[4,0,4]  R695      -2.8336179256439209e-01
    z[4,0,4]  R696      -7.6043003797531128e-01
    z[4,0,4]  R697      -1.2781850062310696e-02
    z[4,0,4]  R698      3.2220616936683655e-01
    z[4,0,4]  R699      -3.0423709750175476e-01
    z[4,0,5]  R7        1
    z[4,0,5]  R43       -1
    z[4,0,5]  R626      -1
    z[4,0,5]  R627      1
    z[4,0,5]  R630      -2.1922864019870758e-01
    z[4,0,5]  R631      -1.3864994049072266e-02
    z[4,0,5]  R632      9.8382443189620972e-02
    z[4,0,5]  R633      -3.9890626072883606e-01
    z[4,0,5]  R634      2.2245287895202637e-01
    z[4,0,5]  R635      -1.1194667965173721e-01
    z[4,0,5]  R636      -0.370022714138031
    z[4,0,5]  R637      0.0323251374065876
    z[4,0,5]  R638      2.7211108803749084e-01
    z[4,0,5]  R639      -3.1022295355796814e-01
    z[4,0,5]  R640      3.7785702943801880e-01
    z[4,0,5]  R641      1.9872845709323883e-01
    z[4,0,5]  R642      2.5526142120361328e-01
    z[4,0,5]  R643      2.6845550537109375e-01
    z[4,0,5]  R644      1.2860564887523651e-01
    z[4,0,5]  R645      2.4986462295055389e-01
    z[4,0,5]  R646      -3.5493888426572084e-03
    z[4,0,5]  R647      2.2794951498508453e-01
    z[4,0,5]  R648      0.0433090478181839
    z[4,0,5]  R649      2.3948150873184204e-01
    z[4,0,5]  R650      5.0294625759124756e-01
    z[4,0,5]  R651      -7.3644906282424927e-02
    z[4,0,5]  R652      4.1580373048782349e-01
    z[4,0,5]  R653      -7.5626122951507568e-01
    z[4,0,5]  R654      -1.0397802293300629e-01
    z[4,0,5]  R655      5.0789028406143188e-01
    z[4,0,5]  R656      -5.9557819366455078e-01
    z[4,0,5]  R657      2.0194037258625031e-01
    z[4,0,5]  R658      -7.8010231256484985e-01
    z[4,0,5]  R659      -1.3690859079360962e-01
    z[4,0,5]  R660      1.3491770625114441e-01
    z[4,0,5]  R661      -1.1217781901359558e-01
    z[4,0,5]  R662      -3.0806851387023926e-01
    z[4,0,5]  R663      5.2376675605773926e-01
    z[4,0,5]  R664      -8.8750118017196655e-01
    z[4,0,5]  R665      -0.826915442943573
    z[4,0,5]  R666      6.7276149988174438e-01
    z[4,0,5]  R667      2.2474014759063721e-01
    z[4,0,5]  R668      3.0902171134948730e-01
    z[4,0,5]  R669      1.7537845671176910e-01
    z[4,0,5]  R670      -5.8974957466125488e-01
    z[4,0,5]  R671      -7.7146071195602417e-01
    z[4,0,5]  R672      -8.3842861652374268e-01
    z[4,0,5]  R673      -8.0394911766052246e-01
    z[4,0,5]  R674      -7.3026913404464722e-01
    z[4,0,5]  R675      -4.5336017012596130e-01
    z[4,0,5]  R676      -8.5456639528274536e-01
    z[4,0,5]  R677      -6.8966847658157349e-01
    z[4,0,5]  R678      -4.5109590888023376e-01
    z[4,0,5]  R679      -3.1475964188575745e-01
    z[4,0,5]  R680      2.5751274824142456e-01
    z[4,0,5]  R681      6.0638688504695892e-02
    z[4,0,5]  R682      1.7596489191055298e-01
    z[4,0,5]  R683      1.9838280975818634e-01
    z[4,0,5]  R684      -4.4085253030061722e-02
    z[4,0,5]  R685      -0.192597433924675
    z[4,0,5]  R686      2.7409407496452332e-01
    z[4,0,5]  R687      2.9440104961395264e-01
    z[4,0,5]  R688      4.5299485325813293e-02
    z[4,0,5]  R689      -1.4888846874237061e-01
    z[4,0,5]  R690      4.4473049044609070e-01
    z[4,0,5]  R691      4.8155647516250610e-01
    z[4,0,5]  R692      0.50826096534729
    z[4,0,5]  R693      2.1873778104782104e-01
    z[4,0,5]  R694      1.6478934884071350e-01
    z[4,0,5]  R695      8.0048346519470215e-01
    z[4,0,5]  R696      1.8756695091724396e-01
    z[4,0,5]  R697      4.3293926864862442e-02
    z[4,0,5]  R698      1.7215389013290405e-01
    z[4,0,5]  R699      9.0370990335941315e-02
    z[4,0,6]  R8        1
    z[4,0,6]  R44       -1
    z[4,0,6]  R628      -1
    z[4,0,6]  R629      1
    z[4,0,6]  R630      -3.8992151618003845e-01
    z[4,0,6]  R631      8.6179308593273163e-02
    z[4,0,6]  R632      0.301705539226532
    z[4,0,6]  R633      0.00955789815634489
    z[4,0,6]  R634      -1.8492631614208221e-01
    z[4,0,6]  R635      -3.4744119644165039e-01
    z[4,0,6]  R636      -3.4499862790107727e-01
    z[4,0,6]  R637      4.4494986534118652e-01
    z[4,0,6]  R638      -0.299773633480072
    z[4,0,6]  R639      -7.2330847382545471e-02
    z[4,0,6]  R640      4.8853579163551331e-01
    z[4,0,6]  R641      -1.9156420603394508e-02
    z[4,0,6]  R642      -0.0973849669098854
    z[4,0,6]  R643      -4.6267926692962646e-02
    z[4,0,6]  R644      1.5173251926898956e-01
    z[4,0,6]  R645      -0.065963514149189
    z[4,0,6]  R646      -0.0146268829703331
    z[4,0,6]  R647      4.1553181409835815e-01
    z[4,0,6]  R648      4.4460281729698181e-01
    z[4,0,6]  R649      -0.0810999944806099
    z[4,0,6]  R650      0.0471709668636322
    z[4,0,6]  R651      3.6713933944702148e-01
    z[4,0,6]  R652      5.4234504699707031e-01
    z[4,0,6]  R653      -5.2987277507781982e-01
    z[4,0,6]  R654      0.671161413192749
    z[4,0,6]  R655      3.8942303508520126e-02
    z[4,0,6]  R656      0.429162859916687
    z[4,0,6]  R657      -3.7207847833633423e-01
    z[4,0,6]  R658      -1.8802908062934875e-01
    z[4,0,6]  R659      1.5293040312826633e-02
    z[4,0,6]  R660      6.8283146619796753e-01
    z[4,0,6]  R661      4.6395670622587204e-02
    z[4,0,6]  R662      -5.4667526483535767e-01
    z[4,0,6]  R663      -0.588240921497345
    z[4,0,6]  R664      -1.2923638522624969e-01
    z[4,0,6]  R665      -7.4335299432277679e-03
    z[4,0,6]  R666      -2.7590328827500343e-02
    z[4,0,6]  R667      3.6730885505676270e-02
    z[4,0,6]  R668      -2.9367044568061829e-01
    z[4,0,6]  R669      2.2171714901924133e-01
    z[4,0,6]  R670      -2.8082942962646484e-01
    z[4,0,6]  R671      3.7076551467180252e-02
    z[4,0,6]  R672      -5.2817560732364655e-02
    z[4,0,6]  R673      3.5354100167751312e-02
    z[4,0,6]  R674      -1.9615635275840759e-01
    z[4,0,6]  R675      -0.0438479483127594
    z[4,0,6]  R676      2.7327290177345276e-01
    z[4,0,6]  R677      2.6171356439590454e-01
    z[4,0,6]  R678      2.6546157896518707e-02
    z[4,0,6]  R679      3.5136502981185913e-01
    z[4,0,6]  R680      1.5173150599002838e-01
    z[4,0,6]  R681      -1.5349340438842773e-01
    z[4,0,6]  R682      -1.6870924830436707e-01
    z[4,0,6]  R683      -2.4577870965003967e-02
    z[4,0,6]  R684      2.6848694309592247e-02
    z[4,0,6]  R685      -1.0802821815013885e-01
    z[4,0,6]  R686      -5.4732402786612511e-03
    z[4,0,6]  R687      -2.1273775398731232e-01
    z[4,0,6]  R688      1.8075324594974518e-01
    z[4,0,6]  R689      -3.8762119412422180e-01
    z[4,0,6]  R690      -1.0170713067054749e-01
    z[4,0,6]  R691      3.6186963319778442e-01
    z[4,0,6]  R692      0.0724979117512703
    z[4,0,6]  R693      -2.8144511580467224e-01
    z[4,0,6]  R694      2.9696589335799217e-02
    z[4,0,6]  R695      2.8212261199951172e-01
    z[4,0,6]  R696      -0.229871928691864
    z[4,0,6]  R697      -2.4322873353958130e-01
    z[4,0,6]  R698      -0.394614040851593
    z[4,0,6]  R699      -4.5532837510108948e-01
    z[1,2,0]  R11       -1
    z[1,2,0]  R20       1
    z[1,2,0]  R744      -1
    z[1,2,0]  R745      1
    z[1,2,0]  R758      2.7963241934776306e-01
    z[1,2,0]  R759      3.4242463111877441e-01
    z[1,2,0]  R760      2.7918154001235962e-01
    z[1,2,0]  R761      1.7188704013824463e-01
    z[1,2,0]  R762      2.6724824309349060e-01
    z[1,2,0]  R763      3.3592095971107483e-01
    z[1,2,0]  R764      2.6670613884925842e-01
    z[1,2,0]  R765      2.9679268598556519e-01
    z[1,2,0]  R766      3.2342132925987244e-01
    z[1,2,0]  R767      4.2374247312545776e-01
    z[1,2,0]  R768      5.6757301092147827e-01
    z[1,2,0]  R769      4.6850016713142395e-01
    z[1,2,0]  R770      6.9135004281997681e-01
    z[1,2,0]  R771      5.3372144699096680e-01
    z[1,2,0]  R772      6.4588135480880737e-01
    z[1,2,0]  R773      5.4391831159591675e-01
    z[1,2,0]  R774      2.6483288407325745e-01
    z[1,2,0]  R775      1.2983353435993195e-01
    z[1,2,0]  R776      3.0205753445625305e-01
    z[1,2,0]  R777      -2.7663335204124451e-02
    z[1,2,0]  R778      4.8140409588813782e-01
    z[1,2,0]  R779      -3.3962267637252808e-01
    z[1,2,0]  R780      -9.4367347657680511e-02
    z[1,2,0]  R781      -2.3696716129779816e-01
    z[1,2,0]  R782      -4.0758627653121948e-01
    z[1,2,0]  R783      -3.8331297039985657e-01
    z[1,2,0]  R784      1.3147702813148499e-01
    z[1,2,0]  R785      -6.6205447912216187e-01
    z[1,2,0]  R786      0.0634799376130104
    z[1,2,0]  R787      -4.9066832661628723e-01
    z[1,2,0]  R788      2.5178718566894531e-01
    z[1,2,0]  R789      -1.9391223788261414e-01
    z[1,2,0]  R790      4.9170383810997009e-01
    z[1,2,0]  R791      -2.4322444200515747e-01
    z[1,2,0]  R792      1.0009628534317017e-01
    z[1,2,0]  R793      4.7080019116401672e-01
    z[1,2,0]  R794      -1.3195669651031494e-01
    z[1,2,0]  R795      1.1216656118631363e-01
    z[1,2,0]  R796      5.4910188913345337e-01
    z[1,2,0]  R797      -3.1269797682762146e-01
    z[1,2,0]  R798      4.4816821813583374e-02
    z[1,2,0]  R799      -2.6699263602495193e-02
    z[1,2,0]  R800      5.7596504688262939e-01
    z[1,2,0]  R801      3.8244676589965820e-01
    z[1,2,0]  R802      7.2887712717056274e-01
    z[1,2,0]  R803      1.1982088536024094e-01
    z[1,2,0]  R804      -9.3095436692237854e-02
    z[1,2,0]  R805      7.0091545581817627e-01
    z[1,2,0]  R806      6.5625959634780884e-01
    z[1,2,0]  R807      0.729515790939331
    z[1,2,0]  R808      3.9137899875640869e-01
    z[1,2,0]  R809      5.6989258527755737e-01
    z[1,2,0]  R810      4.3833982944488525e-01
    z[1,2,0]  R811      -0.166781947016716
    z[1,2,0]  R812      -8.5881259292364120e-03
    z[1,2,0]  R813      -1.9071486592292786e-01
    z[1,2,0]  R814      2.8914827108383179e-01
    z[1,2,0]  R815      -3.4472441673278809e-01
    z[1,2,0]  R816      5.1635402441024780e-01
    z[1,2,0]  R817      7.0207953453063965e-02
    z[1,2,0]  R818      5.7533466815948486e-01
    z[1,2,0]  R819      1.5542012453079224e-01
    z[1,2,0]  R820      2.3176409304141998e-01
    z[1,2,0]  R821      -1.0020636767148972e-01
    z[1,2,0]  R822      -0.573139488697052
    z[1,2,0]  R823      -1.4173206686973572e-01
    z[1,2,0]  R824      -4.1580238938331604e-01
    z[1,2,0]  R825      -7.9225033521652222e-01
    z[1,2,0]  R826      -4.2027789354324341e-01
    z[1,2,0]  R827      -3.3313852548599243e-01
    z[1,2,0]  R828      2.9472494125366211e-01
    z[1,2,0]  R829      4.7758859395980835e-01
    z[1,2,0]  R830      0.695899486541748
    z[1,2,0]  R831      4.3001008033752441e-01
    z[1,2,0]  R832      1.0595851391553879e-01
    z[1,2,0]  R833      5.8363842964172363e-01
    z[1,2,0]  R834      0.500739574432373
    z[1,2,0]  R835      -6.7276030778884888e-01
    z[1,2,0]  R836      -0.639201819896698
    z[1,2,0]  R837      -4.3315351009368896e-01
    z[1,2,0]  R838      5.0770324468612671e-01
    z[1,2,0]  R839      6.2168218195438385e-02
    z[1,2,0]  R840      -7.0578551292419434e-01
    z[1,2,0]  R841      -2.9588720202445984e-01
    z[1,2,0]  R842      -4.6263718605041504e-01
    z[1,2,0]  R843      -6.7708253860473633e-01
    z[1,2,0]  R844      -4.0369123220443726e-01
    z[1,2,0]  R845      -6.2100154161453247e-01
    z[1,2,0]  R846      -7.3160064220428467e-01
    z[1,2,0]  R847      -6.7369800806045532e-01
    z[1,2,0]  R848      6.7131519317626953e-01
    z[1,2,0]  R849      3.7447464466094971e-01
    z[1,2,0]  R850      -2.2601333260536194e-01
    z[1,2,0]  R851      -5.8531010150909424e-01
    z[1,2,0]  R852      -2.4237510561943054e-01
    z[1,2,0]  R853      -2.5561258196830750e-01
    z[1,2,0]  R854      -8.8041287660598755e-01
    z[1,2,0]  R855      -5.3718191385269165e-01
    z[1,2,0]  R856      -7.6415562629699707e-01
    z[1,2,0]  R857      -8.0009514093399048e-01
    z[1,2,0]  R858      7.4829590320587158e-01
    z[1,2,0]  R859      5.1608401536941528e-01
    z[1,2,0]  R860      0.537086009979248
    z[1,2,0]  R861      4.9732410907745361e-01
    z[1,2,0]  R862      4.7364082932472229e-01
    z[1,2,0]  R863      -7.3809754848480225e-01
    z[1,2,0]  R864      -2.6245564222335815e-01
    z[1,2,0]  R865      -3.8120758533477783e-01
    z[1,2,0]  R866      1.0940525680780411e-01
    z[1,2,0]  R867      -3.2202787697315216e-03
    z[1,2,0]  R868      1.4168143272399902e-01
    z[1,2,0]  R869      -4.6991547942161560e-01
    z[1,2,0]  R870      -2.5674232840538025e-01
    z[1,2,0]  R871      3.3428356051445007e-01
    z[1,2,0]  R872      0.565673291683197
    z[1,2,0]  R873      -1.8310900032520294e-01
    z[1,2,0]  R874      -2.4000744521617889e-01
    z[1,2,0]  R875      -3.2580006122589111e-01
    z[1,2,0]  R876      0.0563129186630249
    z[1,2,0]  R877      -2.3766435682773590e-01
    z[1,2,1]  R12       -1
    z[1,2,1]  R21       1
    z[1,2,1]  R746      -1
    z[1,2,1]  R747      1
    z[1,2,1]  R758      3.4309035539627075e-01
    z[1,2,1]  R759      3.0812993645668030e-01
    z[1,2,1]  R760      2.3934613168239594e-01
    z[1,2,1]  R761      -2.9777586460113525e-01
    z[1,2,1]  R762      -1.9624061882495880e-01
    z[1,2,1]  R763      4.1178426146507263e-01
    z[1,2,1]  R764      1.6529412567615509e-01
    z[1,2,1]  R765      5.1155781745910645e-01
    z[1,2,1]  R766      1.5445442497730255e-01
    z[1,2,1]  R767      -3.6533939838409424e-01
    z[1,2,1]  R768      -6.5492558479309082e-01
    z[1,2,1]  R769      -6.9631791114807129e-01
    z[1,2,1]  R770      -5.1652860641479492e-01
    z[1,2,1]  R771      -6.4939856529235840e-01
    z[1,2,1]  R772      -3.6016201972961426e-01
    z[1,2,1]  R773      -4.1192224621772766e-01
    z[1,2,1]  R774      -5.5285841226577759e-01
    z[1,2,1]  R775      -6.5408545732498169e-01
    z[1,2,1]  R776      -4.8382645845413208e-01
    z[1,2,1]  R777      -4.7620588541030884e-01
    z[1,2,1]  R778      0.547591507434845
    z[1,2,1]  R779      2.6197345927357674e-02
    z[1,2,1]  R780      2.6048806309700012e-01
    z[1,2,1]  R781      2.1758790314197540e-01
    z[1,2,1]  R782      1.6954356431961060e-01
    z[1,2,1]  R783      3.9316490292549133e-01
    z[1,2,1]  R784      -7.7843718230724335e-02
    z[1,2,1]  R785      1.7736643552780151e-01
    z[1,2,1]  R786      3.7261933088302612e-01
    z[1,2,1]  R787      3.1868198513984680e-01
    z[1,2,1]  R788      -6.4168584346771240e-01
    z[1,2,1]  R789      -5.1873183250427246e-01
    z[1,2,1]  R790      -5.3301793336868286e-01
    z[1,2,1]  R791      -4.2163071036338806e-01
    z[1,2,1]  R792      -5.7585906237363815e-02
    z[1,2,1]  R793      6.8187665939331055e-01
    z[1,2,1]  R794      -7.6996523141860962e-01
    z[1,2,1]  R795      -5.8149510622024536e-01
    z[1,2,1]  R796      4.9429732561111450e-01
    z[1,2,1]  R797      -4.6810075640678406e-01
    z[1,2,1]  R798      -7.8278720378875732e-01
    z[1,2,1]  R799      -8.3292537927627563e-01
    z[1,2,1]  R800      -5.1259505748748779e-01
    z[1,2,1]  R801      -6.0324513912200928e-01
    z[1,2,1]  R802      3.1696164608001709e-01
    z[1,2,1]  R803      -7.5302451848983765e-01
    z[1,2,1]  R804      -8.0823796987533569e-01
    z[1,2,1]  R805      -3.2325261831283569e-01
    z[1,2,1]  R806      -5.0754940509796143e-01
    z[1,2,1]  R807      3.8729032874107361e-01
    z[1,2,1]  R808      -8.6260598897933960e-01
    z[1,2,1]  R809      6.4150685071945190e-01
    z[1,2,1]  R810      5.9370237588882446e-01
    z[1,2,1]  R811      -6.1903841793537140e-02
    z[1,2,1]  R812      7.4042327702045441e-02
    z[1,2,1]  R813      6.0816723108291626e-01
    z[1,2,1]  R814      2.5047263503074646e-01
    z[1,2,1]  R815      -2.0845349133014679e-01
    z[1,2,1]  R816      3.9893460273742676e-01
    z[1,2,1]  R817      3.3393295598216355e-04
    z[1,2,1]  R818      5.4899090528488159e-01
    z[1,2,1]  R819      -8.4485612809658051e-02
    z[1,2,1]  R820      3.0647762119770050e-02
    z[1,2,1]  R821      3.6442461609840393e-01
    z[1,2,1]  R822      1.4070263504981995e-01
    z[1,2,1]  R823      0.718567967414856
    z[1,2,1]  R824      -1.8699440360069275e-01
    z[1,2,1]  R825      3.5574089735746384e-02
    z[1,2,1]  R826      1.3084031641483307e-01
    z[1,2,1]  R827      -3.3618080615997314e-01
    z[1,2,1]  R828      -0.850028932094574
    z[1,2,1]  R829      -6.1846506595611572e-01
    z[1,2,1]  R830      -3.7172517180442810e-01
    z[1,2,1]  R831      -5.4303795099258423e-01
    z[1,2,1]  R832      -6.5986555814743042e-01
    z[1,2,1]  R833      4.8054805397987366e-01
    z[1,2,1]  R834      1.3738648593425751e-01
    z[1,2,1]  R835      2.1112720668315887e-01
    z[1,2,1]  R836      -9.5226854085922241e-02
    z[1,2,1]  R837      2.2615295648574829e-01
    z[1,2,1]  R838      -6.8314230442047119e-01
    z[1,2,1]  R839      2.7245259284973145e-01
    z[1,2,1]  R840      -1.2807795405387878e-01
    z[1,2,1]  R841      1.5993210673332214e-01
    z[1,2,1]  R842      5.6421858072280884e-01
    z[1,2,1]  R843      1.5317335724830627e-01
    z[1,2,1]  R844      7.8978991508483887e-01
    z[1,2,1]  R845      4.4707828760147095e-01
    z[1,2,1]  R846      4.8379644751548767e-01
    z[1,2,1]  R847      4.0550419688224792e-01
    z[1,2,1]  R848      5.6089580059051514e-01
    z[1,2,1]  R849      -6.9278383255004883e-01
    z[1,2,1]  R850      1.0703387856483459e-01
    z[1,2,1]  R851      9.6009485423564911e-03
    z[1,2,1]  R852      -7.1844294667243958e-02
    z[1,2,1]  R853      -9.6338622272014618e-02
    z[1,2,1]  R854      0.212177112698555
    z[1,2,1]  R855      -3.5925975441932678e-01
    z[1,2,1]  R856      2.7371007204055786e-01
    z[1,2,1]  R857      4.9748173356056213e-01
    z[1,2,1]  R858      -3.2144561409950256e-01
    z[1,2,1]  R859      -2.0471605658531189e-01
    z[1,2,1]  R860      -3.1970420479774475e-01
    z[1,2,1]  R861      -1.8541653454303741e-01
    z[1,2,1]  R862      1.3635165989398956e-01
    z[1,2,1]  R863      -1.0374334640800953e-02
    z[1,2,1]  R864      -2.3291751742362976e-01
    z[1,2,1]  R865      3.8018960505723953e-02
    z[1,2,1]  R866      6.7745143175125122e-01
    z[1,2,1]  R867      0.726978063583374
    z[1,2,1]  R868      3.9020961523056030e-01
    z[1,2,1]  R869      -2.1759761869907379e-01
    z[1,2,1]  R870      -3.1393334269523621e-01
    z[1,2,1]  R871      5.5078876018524170e-01
    z[1,2,1]  R872      0.0785161480307579
    z[1,2,1]  R873      -8.9253157377243042e-02
    z[1,2,1]  R874      -2.2639174759387970e-01
    z[1,2,1]  R875      -4.4696471095085144e-01
    z[1,2,1]  R876      8.1399637460708618e-01
    z[1,2,1]  R877      7.4620097875595093e-01
    z[1,2,2]  R13       -1
    z[1,2,2]  R22       1
    z[1,2,2]  R748      -1
    z[1,2,2]  R749      1
    z[1,2,2]  R758      0.410097599029541
    z[1,2,2]  R759      1.9897668063640594e-01
    z[1,2,2]  R760      3.2608810067176819e-01
    z[1,2,2]  R761      3.4057784080505371e-01
    z[1,2,2]  R762      3.6706885695457458e-01
    z[1,2,2]  R763      2.4889845401048660e-02
    z[1,2,2]  R764      7.7606640756130219e-02
    z[1,2,2]  R765      4.7487378120422363e-01
    z[1,2,2]  R766      2.1392826735973358e-01
    z[1,2,2]  R767      3.6713370680809021e-01
    z[1,2,2]  R768      1.0967803001403809e-01
    z[1,2,2]  R769      -4.1845682263374329e-01
    z[1,2,2]  R770      -1.2607865035533905e-01
    z[1,2,2]  R771      -0.486369788646698
    z[1,2,2]  R772      5.4819411039352417e-01
    z[1,2,2]  R773      0.567703127861023
    z[1,2,2]  R774      3.9514392614364624e-02
    z[1,2,2]  R775      4.5630556344985962e-01
    z[1,2,2]  R776      -2.2555316984653473e-01
    z[1,2,2]  R777      3.5645312070846558e-01
    z[1,2,2]  R778      -4.2175155878067017e-01
    z[1,2,2]  R779      1.6420675441622734e-02
    z[1,2,2]  R780      4.6600274741649628e-02
    z[1,2,2]  R781      -1.8738220632076263e-01
    z[1,2,2]  R782      1.6186399757862091e-01
    z[1,2,2]  R783      1.7931106686592102e-01
    z[1,2,2]  R784      -3.0865499377250671e-01
    z[1,2,2]  R785      -7.1684408187866211e-01
    z[1,2,2]  R786      5.0356465578079224e-01
    z[1,2,2]  R787      -7.8330940008163452e-01
    z[1,2,2]  R788      4.0173164010047913e-01
    z[1,2,2]  R789      6.7916172742843628e-01
    z[1,2,2]  R790      5.6552004814147949e-01
    z[1,2,2]  R791      6.2351912260055542e-01
    z[1,2,2]  R792      2.7996173501014709e-01
    z[1,2,2]  R793      1.4014796912670135e-01
    z[1,2,2]  R794      2.6978957653045654e-01
    z[1,2,2]  R795      -1.8271125853061676e-01
    z[1,2,2]  R796      -3.0887761712074280e-01
    z[1,2,2]  R797      1.8305076658725739e-01
    z[1,2,2]  R798      4.6575519442558289e-01
    z[1,2,2]  R799      4.3002769351005554e-02
    z[1,2,2]  R800      1.5302455425262451e-01
    z[1,2,2]  R801      1.3386055361479521e-03
    z[1,2,2]  R802      1.3925452530384064e-01
    z[1,2,2]  R803      3.2627224922180176e-01
    z[1,2,2]  R804      -7.9252235591411591e-02
    z[1,2,2]  R805      4.8510608077049255e-01
    z[1,2,2]  R806      -1.7540137469768524e-01
    z[1,2,2]  R807      -1.7894359305500984e-02
    z[1,2,2]  R808      -1.7448730766773224e-01
    z[1,2,2]  R809      1.3207750022411346e-01
    z[1,2,2]  R810      -3.6221626400947571e-01
    z[1,2,2]  R811      1.9669516384601593e-01
    z[1,2,2]  R812      4.0278702974319458e-01
    z[1,2,2]  R813      -2.0718200504779816e-01
    z[1,2,2]  R814      -3.5573190450668335e-01
    z[1,2,2]  R815      -6.5912526845932007e-01
    z[1,2,2]  R816      1.1744274944067001e-01
    z[1,2,2]  R817      -7.6905059814453125e-01
    z[1,2,2]  R818      -9.8168686032295227e-02
    z[1,2,2]  R819      9.7359839128330350e-04
    z[1,2,2]  R820      -1.1752710491418839e-01
    z[1,2,2]  R821      1.9486773014068604e-01
    z[1,2,2]  R822      -5.7592725753784180e-01
    z[1,2,2]  R823      -0.561223030090332
    z[1,2,2]  R824      -5.7908612489700317e-01
    z[1,2,2]  R825      -2.6552328467369080e-01
    z[1,2,2]  R826      -6.9777297973632812e-01
    z[1,2,2]  R827      -7.7856051921844482e-01
    z[1,2,2]  R828      -9.9403075873851776e-02
    z[1,2,2]  R829      3.4059146046638489e-01
    z[1,2,2]  R830      1.4632999897003174e-01
    z[1,2,2]  R831      3.2667240500450134e-01
    z[1,2,2]  R832      1.5998254716396332e-01
    z[1,2,2]  R833      -2.1347789466381073e-01
    z[1,2,2]  R834      2.0259141921997070e-01
    z[1,2,2]  R835      -4.5913219451904297e-01
    z[1,2,2]  R836      -5.9972470998764038e-01
    z[1,2,2]  R837      -6.4753305912017822e-01
    z[1,2,2]  R838      -3.3333367109298706e-01
    z[1,2,2]  R839      3.7514597177505493e-01
    z[1,2,2]  R840      -2.6433351635932922e-01
    z[1,2,2]  R841      -7.7267253398895264e-01
    z[1,2,2]  R842      -1.0950347036123276e-01
    z[1,2,2]  R843      4.1314274072647095e-01
    z[1,2,2]  R844      -2.7503243088722229e-01
    z[1,2,2]  R845      -1.9831565022468567e-01
    z[1,2,2]  R846      -8.4968388080596924e-02
    z[1,2,2]  R847      -1.5004470944404602e-01
    z[1,2,2]  R848      -0.174790620803833
    z[1,2,2]  R849      3.1620880961418152e-01
    z[1,2,2]  R850      -6.8193428218364716e-02
    z[1,2,2]  R851      -6.0812151432037354e-01
    z[1,2,2]  R852      -7.1764141321182251e-01
    z[1,2,2]  R853      -8.1184077262878418e-01
    z[1,2,2]  R854      -1.2061801552772522e-01
    z[1,2,2]  R855      1.9096738100051880e-01
    z[1,2,2]  R856      -2.4020045995712280e-01
    z[1,2,2]  R857      -3.7953026592731476e-02
    z[1,2,2]  R858      -0.515376091003418
    z[1,2,2]  R859      4.1804668307304382e-01
    z[1,2,2]  R860      1.2986409664154053e-01
    z[1,2,2]  R861      4.5868310332298279e-01
    z[1,2,2]  R862      3.5329717397689819e-01
    z[1,2,2]  R863      2.0457613468170166e-01
    z[1,2,2]  R864      -1.2198117375373840e-01
    z[1,2,2]  R865      -0.887882649898529
    z[1,2,2]  R866      -3.7543609738349915e-01
    z[1,2,2]  R867      -4.6628442406654358e-01
    z[1,2,2]  R868      1.2427022308111191e-01
    z[1,2,2]  R869      -2.0072016119956970e-01
    z[1,2,2]  R870      3.8638854026794434e-01
    z[1,2,2]  R871      -0.310772567987442
    z[1,2,2]  R872      2.9522114992141724e-01
    z[1,2,2]  R873      -8.5445863008499146e-01
    z[1,2,2]  R874      -9.0961974859237671e-01
    z[1,2,2]  R875      -6.8891471624374390e-01
    z[1,2,2]  R876      -8.8315911591053009e-02
    z[1,2,2]  R877      -2.7855682373046875e-01
    z[1,2,3]  R14       -1
    z[1,2,3]  R23       1
    z[1,2,3]  R750      -1
    z[1,2,3]  R751      1
    z[1,2,3]  R758      -1.8432404100894928e-01
    z[1,2,3]  R759      -5.1463800668716431e-01
    z[1,2,3]  R760      -6.4134937524795532e-01
    z[1,2,3]  R761      -4.0266942977905273e-01
    z[1,2,3]  R762      -4.4890768826007843e-02
    z[1,2,3]  R763      -4.6394917368888855e-01
    z[1,2,3]  R764      -3.5040271282196045e-01
    z[1,2,3]  R765      -8.3797693252563477e-02
    z[1,2,3]  R766      -2.0538680255413055e-03
    z[1,2,3]  R767      -3.6634132266044617e-01
    z[1,2,3]  R768      2.8865441679954529e-01
    z[1,2,3]  R769      3.6795396357774734e-02
    z[1,2,3]  R770      -1.4961647987365723e-01
    z[1,2,3]  R771      1.3712696731090546e-01
    z[1,2,3]  R772      6.4623266458511353e-02
    z[1,2,3]  R773      -9.1978013515472412e-02
    z[1,2,3]  R774      5.1226603984832764e-01
    z[1,2,3]  R775      -3.9801809191703796e-01
    z[1,2,3]  R776      -6.0857552289962769e-01
    z[1,2,3]  R777      -5.7703101634979248e-01
    z[1,2,3]  R778      2.6602050662040710e-01
    z[1,2,3]  R779      1.8930549919605255e-01
    z[1,2,3]  R780      6.5145730972290039e-01
    z[1,2,3]  R781      4.7060206532478333e-01
    z[1,2,3]  R782      4.4231966137886047e-01
    z[1,2,3]  R783      3.7852790951728821e-01
    z[1,2,3]  R784      2.2586712241172791e-01
    z[1,2,3]  R785      4.2727984488010406e-02
    z[1,2,3]  R786      5.4297196865081787e-01
    z[1,2,3]  R787      1.6417096555233002e-01
    z[1,2,3]  R788      -4.0744277834892273e-01
    z[1,2,3]  R789      -4.2608398199081421e-01
    z[1,2,3]  R790      1.6876373440027237e-02
    z[1,2,3]  R791      -5.5595141649246216e-01
    z[1,2,3]  R792      0.510107696056366
    z[1,2,3]  R793      2.4046397209167480e-01
    z[1,2,3]  R794      -3.1315666437149048e-01
    z[1,2,3]  R795      2.9579216241836548e-01
    z[1,2,3]  R796      3.9032116532325745e-01
    z[1,2,3]  R797      -7.2604638338088989e-01
    z[1,2,3]  R798      -1.0772946476936340e-01
    z[1,2,3]  R799      -7.8980810940265656e-02
    z[1,2,3]  R800      1.8345648050308228e-01
    z[1,2,3]  R801      3.1382623314857483e-01
    z[1,2,3]  R802      1.4028945565223694e-01
    z[1,2,3]  R803      -4.3615886569023132e-01
    z[1,2,3]  R804      -4.3881252408027649e-01
    z[1,2,3]  R805      1.0959044843912125e-01
    z[1,2,3]  R806      4.7214669175446033e-03
    z[1,2,3]  R807      -1.2928792834281921e-01
    z[1,2,3]  R808      -1.7415136098861694e-01
    z[1,2,3]  R809      7.4559003114700317e-02
    z[1,2,3]  R810      -1.0413333028554916e-01
    z[1,2,3]  R811      1.8462552130222321e-01
    z[1,2,3]  R812      0.713071882724762
    z[1,2,3]  R813      4.2764917016029358e-01
    z[1,2,3]  R814      6.1980700492858887e-01
    z[1,2,3]  R815      3.4250319004058838e-01
    z[1,2,3]  R816      0.574138879776001
    z[1,2,3]  R817      3.9793962240219116e-01
    z[1,2,3]  R818      -6.0092996805906296e-02
    z[1,2,3]  R819      0.777245819568634
    z[1,2,3]  R820      4.5326781272888184e-01
    z[1,2,3]  R821      2.7885380387306213e-01
    z[1,2,3]  R822      3.5766753554344177e-01
    z[1,2,3]  R823      3.2030284404754639e-01
    z[1,2,3]  R824      3.1763064861297607e-01
    z[1,2,3]  R825      3.8000747561454773e-01
    z[1,2,3]  R826      1.2909834086894989e-01
    z[1,2,3]  R827      -2.4669134616851807e-01
    z[1,2,3]  R828      -2.9174787923693657e-03
    z[1,2,3]  R829      -2.8880032896995544e-01
    z[1,2,3]  R830      4.0354898571968079e-01
    z[1,2,3]  R831      1.3501471281051636e-01
    z[1,2,3]  R832      -4.7309798002243042e-01
    z[1,2,3]  R833      -2.9963061213493347e-01
    z[1,2,3]  R834      5.4995840787887573e-01
    z[1,2,3]  R835      4.1433700919151306e-01
    z[1,2,3]  R836      4.0481972694396973e-01
    z[1,2,3]  R837      3.9746868610382080e-01
    z[1,2,3]  R838      -2.1642296016216278e-01
    z[1,2,3]  R839      6.3129258155822754e-01
    z[1,2,3]  R840      4.3214264512062073e-01
    z[1,2,3]  R841      3.4522926807403564e-01
    z[1,2,3]  R842      4.1966402530670166e-01
    z[1,2,3]  R843      3.2063734531402588e-01
    z[1,2,3]  R844      -1.9523462653160095e-01
    z[1,2,3]  R845      -5.5567425489425659e-01
    z[1,2,3]  R846      -4.6835356950759888e-01
    z[1,2,3]  R847      -4.9415045976638794e-01
    z[1,2,3]  R848      -1.4836981892585754e-01
    z[1,2,3]  R849      2.6959040760993958e-01
    z[1,2,3]  R850      5.1917874813079834e-01
    z[1,2,3]  R851      4.2698773741722107e-01
    z[1,2,3]  R852      3.9615362882614136e-01
    z[1,2,3]  R853      2.7314865589141846e-01
    z[1,2,3]  R854      2.4443480372428894e-01
    z[1,2,3]  R855      3.0787822604179382e-01
    z[1,2,3]  R856      -5.2298015356063843e-01
    z[1,2,3]  R857      -2.9256063699722290e-01
    z[1,2,3]  R858      1.5286819636821747e-01
    z[1,2,3]  R859      -5.1591819524765015e-01
    z[1,2,3]  R860      -4.9240902066230774e-01
    z[1,2,3]  R861      -1.6610951721668243e-01
    z[1,2,3]  R862      -3.2557976245880127e-01
    z[1,2,3]  R863      -6.2602853775024414e-01
    z[1,2,3]  R864      -0.666356086730957
    z[1,2,3]  R865      1.1362785845994949e-01
    z[1,2,3]  R866      1.0532516241073608e-01
    z[1,2,3]  R867      0.0982937142252922
    z[1,2,3]  R868      6.8599176406860352e-01
    z[1,2,3]  R869      5.1633769273757935e-01
    z[1,2,3]  R870      6.7470401525497437e-01
    z[1,2,3]  R871      -3.8525089621543884e-01
    z[1,2,3]  R872      4.1681462526321411e-01
    z[1,2,3]  R873      3.9265963435173035e-01
    z[1,2,3]  R874      5.7291448116302490e-02
    z[1,2,3]  R875      3.3894369006156921e-01
    z[1,2,3]  R876      -1.3183162547647953e-02
    z[1,2,3]  R877      8.3016470074653625e-02
    z[1,2,4]  R15       -1
    z[1,2,4]  R24       1
    z[1,2,4]  R752      -1
    z[1,2,4]  R753      1
    z[1,2,4]  R758      1.3935865461826324e-01
    z[1,2,4]  R759      -3.3856093883514404e-02
    z[1,2,4]  R760      2.6250863075256348e-01
    z[1,2,4]  R761      2.3572713136672974e-02
    z[1,2,4]  R762      3.6814704537391663e-01
    z[1,2,4]  R763      1.7465278506278992e-01
    z[1,2,4]  R764      3.3341392874717712e-01
    z[1,2,4]  R765      -7.4151274748146534e-04
    z[1,2,4]  R766      2.8366908431053162e-01
    z[1,2,4]  R767      5.4026669263839722e-01
    z[1,2,4]  R768      -2.5515180826187134e-01
    z[1,2,4]  R769      -2.7427467703819275e-01
    z[1,2,4]  R770      -4.2240446805953979e-01
    z[1,2,4]  R771      2.7976479381322861e-02
    z[1,2,4]  R772      -1.7387789487838745e-01
    z[1,2,4]  R773      -4.3352580070495605e-01
    z[1,2,4]  R774      4.0010169148445129e-01
    z[1,2,4]  R775      6.9646663963794708e-02
    z[1,2,4]  R776      -5.0047025084495544e-02
    z[1,2,4]  R777      -4.9046209454536438e-01
    z[1,2,4]  R778      -3.5990697145462036e-01
    z[1,2,4]  R779      9.0682750940322876e-01
    z[1,2,4]  R780      6.9490909576416016e-01
    z[1,2,4]  R781      7.9154515266418457e-01
    z[1,2,4]  R782      7.2009402513504028e-01
    z[1,2,4]  R783      7.0644110441207886e-01
    z[1,2,4]  R784      8.1561535596847534e-01
    z[1,2,4]  R785      -7.3069550096988678e-02
    z[1,2,4]  R786      4.5287674665451050e-01
    z[1,2,4]  R787      1.2962979078292847e-01
    z[1,2,4]  R788      7.9473212361335754e-02
    z[1,2,4]  R789      -1.3623583316802979e-01
    z[1,2,4]  R790      2.1712502837181091e-01
    z[1,2,4]  R791      8.6590774357318878e-02
    z[1,2,4]  R792      7.9303735494613647e-01
    z[1,2,4]  R793      -1.8995349109172821e-01
    z[1,2,4]  R794      4.6238112449645996e-01
    z[1,2,4]  R795      7.1789878606796265e-01
    z[1,2,4]  R796      4.2612543702125549e-01
    z[1,2,4]  R797      -2.2465731203556061e-01
    z[1,2,4]  R798      1.1231165379285812e-01
    z[1,2,4]  R799      4.8143625259399414e-01
    z[1,2,4]  R800      3.1954690814018250e-01
    z[1,2,4]  R801      3.2098862528800964e-01
    z[1,2,4]  R802      -4.3746823072433472e-01
    z[1,2,4]  R803      -1.7073710262775421e-01
    z[1,2,4]  R804      -2.0819954574108124e-02
    z[1,2,4]  R805      -0.0989551842212677
    z[1,2,4]  R806      2.5268995761871338e-01
    z[1,2,4]  R807      1.5949079394340515e-01
    z[1,2,4]  R808      0.136853888630867
    z[1,2,4]  R809      1.7795832455158234e-01
    z[1,2,4]  R810      -1.3361354172229767e-01
    z[1,2,4]  R811      8.3230429887771606e-01
    z[1,2,4]  R812      4.1093739867210388e-01
    z[1,2,4]  R813      5.3052127361297607e-01
    z[1,2,4]  R814      5.1477003097534180e-01
    z[1,2,4]  R815      5.0155729055404663e-01
    z[1,2,4]  R816      2.9172223806381226e-01
    z[1,2,4]  R817      4.8056846857070923e-01
    z[1,2,4]  R818      2.6530984044075012e-01
    z[1,2,4]  R819      5.4606622457504272e-01
    z[1,2,4]  R820      7.8615558147430420e-01
    z[1,2,4]  R821      6.2929922342300415e-01
    z[1,2,4]  R822      2.6644504070281982e-01
    z[1,2,4]  R823      -3.8745053112506866e-02
    z[1,2,4]  R824      2.0344233512878418e-01
    z[1,2,4]  R825      1.7360401153564453e-01
    z[1,2,4]  R826      5.9470452368259430e-02
    z[1,2,4]  R827      2.6736825704574585e-02
    z[1,2,4]  R828      3.3870872855186462e-01
    z[1,2,4]  R829      5.5658571422100067e-02
    z[1,2,4]  R830      -7.8829256817698479e-03
    z[1,2,4]  R831      7.8902617096900940e-02
    z[1,2,4]  R832      1.1656423658132553e-01
    z[1,2,4]  R833      2.7199275791645050e-02
    z[1,2,4]  R834      4.8117798566818237e-01
    z[1,2,4]  R835      3.0255025625228882e-01
    z[1,2,4]  R836      3.3595968037843704e-02
    z[1,2,4]  R837      1.6369393467903137e-01
    z[1,2,4]  R838      -2.9842811822891235e-01
    z[1,2,4]  R839      5.3670382499694824e-01
    z[1,2,4]  R840      4.7548791766166687e-01
    z[1,2,4]  R841      2.9210817813873291e-01
    z[1,2,4]  R842      4.8938098549842834e-01
    z[1,2,4]  R843      3.6667466163635254e-01
    z[1,2,4]  R844      -3.0993974208831787e-01
    z[1,2,4]  R845      -2.1801907569169998e-02
    z[1,2,4]  R846      -6.2543079257011414e-02
    z[1,2,4]  R847      -2.3602099716663361e-01
    z[1,2,4]  R848      8.2893833518028259e-02
    z[1,2,4]  R849      2.8686946630477905e-01
    z[1,2,4]  R850      7.8496611118316650e-01
    z[1,2,4]  R851      1.9304936751723289e-02
    z[1,2,4]  R852      0.449378103017807
    z[1,2,4]  R853      -3.3246347308158875e-01
    z[1,2,4]  R854      -1.7195332795381546e-02
    z[1,2,4]  R855      2.4461318552494049e-01
    z[1,2,4]  R856      1.0814021341502666e-02
    z[1,2,4]  R857      1.1211378872394562e-01
    z[1,2,4]  R858      1.4716325700283051e-01
    z[1,2,4]  R859      1.8556064367294312e-01
    z[1,2,4]  R860      -6.7625559866428375e-02
    z[1,2,4]  R861      -6.6623234748840332e-01
    z[1,2,4]  R862      6.1862188577651978e-01
    z[1,2,4]  R863      1.4586891233921051e-01
    z[1,2,4]  R864      -2.1497756242752075e-01
    z[1,2,4]  R865      -1.0132491588592529e-01
    z[1,2,4]  R866      1.1973230540752411e-01
    z[1,2,4]  R867      0.300994336605072
    z[1,2,4]  R868      2.9803445935249329e-01
    z[1,2,4]  R869      0.651832640171051
    z[1,2,4]  R870      4.7439518570899963e-01
    z[1,2,4]  R871      1.4170329086482525e-02
    z[1,2,4]  R872      2.2644495964050293e-01
    z[1,2,4]  R873      -1.3397192955017090e-01
    z[1,2,4]  R874      1.1349140852689743e-01
    z[1,2,4]  R875      -1.2802682816982269e-01
    z[1,2,4]  R876      -2.5850141048431396e-01
    z[1,2,4]  R877      -0.37811079621315
    z[1,2,5]  R16       -1
    z[1,2,5]  R25       1
    z[1,2,5]  R754      -1
    z[1,2,5]  R755      1
    z[1,2,5]  R758      -7.4647432565689087e-01
    z[1,2,5]  R759      -6.3916242122650146e-01
    z[1,2,5]  R760      -5.0884467363357544e-01
    z[1,2,5]  R761      -7.2125869989395142e-01
    z[1,2,5]  R762      -7.8055894374847412e-01
    z[1,2,5]  R763      -6.7628163099288940e-01
    z[1,2,5]  R764      -7.5406205654144287e-01
    z[1,2,5]  R765      -5.4106724262237549e-01
    z[1,2,5]  R766      -7.7640181779861450e-01
    z[1,2,5]  R767      -3.3120352029800415e-01
    z[1,2,5]  R768      -1.7839916050434113e-01
    z[1,2,5]  R769      3.4148350358009338e-02
    z[1,2,5]  R770      1.8258308991789818e-02
    z[1,2,5]  R771      -1.8633460998535156e-01
    z[1,2,5]  R772      -1.9224444031715393e-01
    z[1,2,5]  R773      1.1763998866081238e-01
    z[1,2,5]  R774      2.6581385731697083e-01
    z[1,2,5]  R775      -3.4957072138786316e-01
    z[1,2,5]  R776      9.1608978807926178e-02
    z[1,2,5]  R777      4.0881808847188950e-02
    z[1,2,5]  R778      2.3601700365543365e-01
    z[1,2,5]  R779      1.3677023351192474e-01
    z[1,2,5]  R780      7.3405399918556213e-02
    z[1,2,5]  R781      1.0969126969575882e-01
    z[1,2,5]  R782      9.2714056372642517e-02
    z[1,2,5]  R783      1.4815928041934967e-01
    z[1,2,5]  R784      2.1618127822875977e-01
    z[1,2,5]  R785      8.9850440621376038e-02
    z[1,2,5]  R786      3.2188418507575989e-01
    z[1,2,5]  R787      1.1667750775814056e-02
    z[1,2,5]  R788      3.9937481284141541e-01
    z[1,2,5]  R789      -8.7309010326862335e-02
    z[1,2,5]  R790      2.4414394795894623e-01
    z[1,2,5]  R791      2.3820179700851440e-01
    z[1,2,5]  R792      1.0241446644067764e-01
    z[1,2,5]  R793      4.2090556025505066e-01
    z[1,2,5]  R794      -6.4658693969249725e-02
    z[1,2,5]  R795      -1.1355581879615784e-01
    z[1,2,5]  R796      1.5739759802818298e-01
    z[1,2,5]  R797      2.3948132991790771e-01
    z[1,2,5]  R798      2.2364287078380585e-01
    z[1,2,5]  R799      1.7969799041748047e-01
    z[1,2,5]  R800      -3.2613289356231689e-01
    z[1,2,5]  R801      4.9317643046379089e-01
    z[1,2,5]  R802      3.1518206000328064e-01
    z[1,2,5]  R803      -3.0196252465248108e-01
    z[1,2,5]  R804      2.6776146888732910e-01
    z[1,2,5]  R805      3.0875065922737122e-01
    z[1,2,5]  R806      1.9810175895690918e-01
    z[1,2,5]  R807      4.8662075400352478e-01
    z[1,2,5]  R808      1.3925476372241974e-01
    z[1,2,5]  R809      4.4187238812446594e-01
    z[1,2,5]  R810      3.6108088493347168e-01
    z[1,2,5]  R811      4.4546341896057129e-01
    z[1,2,5]  R812      1.2333232164382935e-01
    z[1,2,5]  R813      -1.0340360924601555e-02
    z[1,2,5]  R814      2.5306472182273865e-01
    z[1,2,5]  R815      3.0567046254873276e-02
    z[1,2,5]  R816      1.1456538736820221e-01
    z[1,2,5]  R817      4.9303401261568069e-02
    z[1,2,5]  R818      4.6101510524749756e-01
    z[1,2,5]  R819      3.7257452495396137e-03
    z[1,2,5]  R820      1.2055249512195587e-01
    z[1,2,5]  R821      1.0165440291166306e-01
    z[1,2,5]  R822      -3.0589890480041504e-01
    z[1,2,5]  R823      -1.5219344198703766e-01
    z[1,2,5]  R824      -8.9321933686733246e-02
    z[1,2,5]  R825      -6.7859692499041557e-03
    z[1,2,5]  R826      -1.3576747849583626e-02
    z[1,2,5]  R827      1.4903441071510315e-01
    z[1,2,5]  R828      -0.248980313539505
    z[1,2,5]  R829      -0.105091892182827
    z[1,2,5]  R830      4.3572276830673218e-01
    z[1,2,5]  R831      -5.9681254625320435e-01
    z[1,2,5]  R832      -4.2099773883819580e-01
    z[1,2,5]  R833      4.4694775342941284e-01
    z[1,2,5]  R834      2.5101962685585022e-01
    z[1,2,5]  R835      -1.2519478797912598e-01
    z[1,2,5]  R836      -2.3776248097419739e-01
    z[1,2,5]  R837      -8.8280171155929565e-02
    z[1,2,5]  R838      -1.3381315767765045e-01
    z[1,2,5]  R839      2.9748940467834473e-01
    z[1,2,5]  R840      4.6417381614446640e-02
    z[1,2,5]  R841      -8.5791319608688354e-02
    z[1,2,5]  R842      -1.8986134231090546e-01
    z[1,2,5]  R843      1.2778806686401367e-01
    z[1,2,5]  R844      0.00913998018950224
    z[1,2,5]  R845      1.4865861833095551e-01
    z[1,2,5]  R846      -2.4004525039345026e-03
    z[1,2,5]  R847      -2.4128738045692444e-01
    z[1,2,5]  R848      0.412727415561676
    z[1,2,5]  R849      2.9499068856239319e-01
    z[1,2,5]  R850      2.1359564363956451e-01
    z[1,2,5]  R851      -1.1896307766437531e-01
    z[1,2,5]  R852      2.3534636944532394e-02
    z[1,2,5]  R853      -1.2104593962430954e-01
    z[1,2,5]  R854      6.8074040114879608e-02
    z[1,2,5]  R855      1.6482903063297272e-01
    z[1,2,5]  R856      -8.3766825497150421e-02
    z[1,2,5]  R857      -2.2390339523553848e-02
    z[1,2,5]  R858      -8.9536219835281372e-02
    z[1,2,5]  R859      -4.3601948022842407e-01
    z[1,2,5]  R860      -4.3901872634887695e-01
    z[1,2,5]  R861      -1.8987026810646057e-01
    z[1,2,5]  R862      -1.1239253729581833e-01
    z[1,2,5]  R863      1.7196870176121593e-03
    z[1,2,5]  R864      -6.0424745082855225e-01
    z[1,2,5]  R865      2.7948565781116486e-02
    z[1,2,5]  R866      -5.8154165744781494e-01
    z[1,2,5]  R867      -3.6647930741310120e-01
    z[1,2,5]  R868      -0.28862264752388
    z[1,2,5]  R869      2.3364624939858913e-04
    z[1,2,5]  R870      -0.0412154383957386
    z[1,2,5]  R871      2.4114564061164856e-02
    z[1,2,5]  R872      -2.6987118646502495e-02
    z[1,2,5]  R873      1.8430331349372864e-01
    z[1,2,5]  R874      2.1725286543369293e-01
    z[1,2,5]  R875      1.8040643632411957e-01
    z[1,2,5]  R876      -2.1415190398693085e-01
    z[1,2,5]  R877      -2.1765044331550598e-01
    z[1,2,6]  R17       -1
    z[1,2,6]  R26       1
    z[1,2,6]  R756      -1
    z[1,2,6]  R757      1
    z[1,2,6]  R758      1.5904265642166138e-01
    z[1,2,6]  R759      0.271445095539093
    z[1,2,6]  R760      -1.3883425295352936e-01
    z[1,2,6]  R761      2.8788670897483826e-01
    z[1,2,6]  R762      9.2242740094661713e-02
    z[1,2,6]  R763      -1.1773692071437836e-01
    z[1,2,6]  R764      -0.304904043674469
    z[1,2,6]  R765      -3.5347026586532593e-01
    z[1,2,6]  R766      -3.7749823927879333e-01
    z[1,2,6]  R767      1.2803323566913605e-01
    z[1,2,6]  R768      2.3802106082439423e-01
    z[1,2,6]  R769      2.0687267184257507e-01
    z[1,2,6]  R770      -1.9543178379535675e-01
    z[1,2,6]  R771      -5.0599705427885056e-02
    z[1,2,6]  R772      -2.8501942753791809e-01
    z[1,2,6]  R773      -4.4072084128856659e-02
    z[1,2,6]  R774      3.5985404253005981e-01
    z[1,2,6]  R775      -2.4825769662857056e-01
    z[1,2,6]  R776      -4.9248144030570984e-01
    z[1,2,6]  R777      -2.6498025655746460e-01
    z[1,2,6]  R778      1.8578261137008667e-01
    z[1,2,6]  R779      -0.0825931504368782
    z[1,2,6]  R780      9.1572798788547516e-02
    z[1,2,6]  R781      3.6711718887090683e-02
    z[1,2,6]  R782      2.3696108162403107e-01
    z[1,2,6]  R783      4.5238483697175980e-02
    z[1,2,6]  R784      -3.4410390257835388e-01
    z[1,2,6]  R785      -0.0334925651550293
    z[1,2,6]  R786      -4.7413217835128307e-03
    z[1,2,6]  R787      -1.4855190180242062e-02
    z[1,2,6]  R788      -1.7784331738948822e-01
    z[1,2,6]  R789      1.5596219897270203e-01
    z[1,2,6]  R790      -2.1742123365402222e-01
    z[1,2,6]  R791      -3.1197572126984596e-02
    z[1,2,6]  R792      -9.3162119388580322e-02
    z[1,2,6]  R793      1.5060979127883911e-01
    z[1,2,6]  R794      -3.0172318220138550e-02
    z[1,2,6]  R795      1.1491342447698116e-02
    z[1,2,6]  R796      -6.6568199545145035e-03
    z[1,2,6]  R797      1.2094780057668686e-01
    z[1,2,6]  R798      3.0671152472496033e-01
    z[1,2,6]  R799      1.8265551328659058e-01
    z[1,2,6]  R800      -3.7411868572235107e-01
    z[1,2,6]  R801      2.1233037114143372e-01
    z[1,2,6]  R802      0.196168914437294
    z[1,2,6]  R803      -3.9702009409666061e-02
    z[1,2,6]  R804      2.5907030701637268e-01
    z[1,2,6]  R805      -2.2752623260021210e-01
    z[1,2,6]  R806      -4.2170169949531555e-01
    z[1,2,6]  R807      -1.9631689786911011e-01
    z[1,2,6]  R808      -6.1951391398906708e-02
    z[1,2,6]  R809      1.1733530461788177e-01
    z[1,2,6]  R810      -4.0632402896881104e-01
    z[1,2,6]  R811      -6.6393963992595673e-02
    z[1,2,6]  R812      3.7370380759239197e-01
    z[1,2,6]  R813      -2.9392614960670471e-01
    z[1,2,6]  R814      -1.1798671633005142e-01
    z[1,2,6]  R815      1.8293111026287079e-01
    z[1,2,6]  R816      -3.6410754919052124e-01
    z[1,2,6]  R817      -1.0908308625221252e-01
    z[1,2,6]  R818      2.6725763082504272e-01
    z[1,2,6]  R819      2.5766745209693909e-01
    z[1,2,6]  R820      -3.0579122900962830e-01
    z[1,2,6]  R821      -5.7885181903839111e-01
    z[1,2,6]  R822      1.6591729223728180e-01
    z[1,2,6]  R823      1.4609168469905853e-01
    z[1,2,6]  R824      -5.5366444587707520e-01
    z[1,2,6]  R825      -3.5493856668472290e-01
    z[1,2,6]  R826      -0.546783983707428
    z[1,2,6]  R827      -2.9336306452751160e-01
    z[1,2,6]  R828      -6.3115954399108887e-02
    z[1,2,6]  R829      -4.1935643553733826e-01
    z[1,2,6]  R830      5.7996802031993866e-02
    z[1,2,6]  R831      -1.8123584985733032e-01
    z[1,2,6]  R832      -0.336314857006073
    z[1,2,6]  R833      -3.0428001284599304e-01
    z[1,2,6]  R834      -3.0388179421424866e-01
    z[1,2,6]  R835      -1.1459008604288101e-01
    z[1,2,6]  R836      -3.3831059932708740e-02
    z[1,2,6]  R837      3.8647550344467163e-01
    z[1,2,6]  R838      -1.0314249992370605e-01
    z[1,2,6]  R839      7.8031592071056366e-02
    z[1,2,6]  R840      -2.4493908509612083e-02
    z[1,2,6]  R841      -2.7924704551696777e-01
    z[1,2,6]  R842      6.3042402267456055e-02
    z[1,2,6]  R843      -3.0630344152450562e-01
    z[1,2,6]  R844      -5.7962872087955475e-02
    z[1,2,6]  R845      -2.0928554236888885e-01
    z[1,2,6]  R846      1.4468098059296608e-02
    z[1,2,6]  R847      3.2767906785011292e-02
    z[1,2,6]  R848      -7.0363827049732208e-02
    z[1,2,6]  R849      1.9452148675918579e-01
    z[1,2,6]  R850      -3.8339901715517044e-02
    z[1,2,6]  R851      3.0110573768615723e-01
    z[1,2,6]  R852      2.4829675257205963e-01
    z[1,2,6]  R853      -2.5787854194641113e-01
    z[1,2,6]  R854      3.1721785664558411e-01
    z[1,2,6]  R855      -6.0341215133666992e-01
    z[1,2,6]  R856      5.3015735000371933e-02
    z[1,2,6]  R857      1.1071027070283890e-01
    z[1,2,6]  R858      1.3442881405353546e-01
    z[1,2,6]  R859      -1.6207480430603027e-01
    z[1,2,6]  R860      3.9075037837028503e-01
    z[1,2,6]  R861      -1.9765419885516167e-02
    z[1,2,6]  R862      3.6183750629425049e-01
    z[1,2,6]  R863      0.00778647605329752
    z[1,2,6]  R864      -0.0814017578959465
    z[1,2,6]  R865      2.0233786106109619e-01
    z[1,2,6]  R866      1.5658171474933624e-01
    z[1,2,6]  R867      -1.3966041803359985e-01
    z[1,2,6]  R868      -4.1171273589134216e-01
    z[1,2,6]  R869      7.1930252015590668e-03
    z[1,2,6]  R870      6.5253138542175293e-02
    z[1,2,6]  R871      -0.582328200340271
    z[1,2,6]  R872      6.0079389810562134e-01
    z[1,2,6]  R873      1.4935743808746338e-01
    z[1,2,6]  R874      -1.9328398630023003e-02
    z[1,2,6]  R875      -0.235909104347229
    z[1,2,6]  R876      0.462148517370224
    z[1,2,6]  R877      3.3447670936584473e-01
    z[2,1,0]  R11       1
    z[2,1,0]  R20       -1
    z[2,1,0]  R878      -1
    z[2,1,0]  R879      1
    z[2,1,0]  R892      7.4829590320587158e-01
    z[2,1,0]  R893      5.1608401536941528e-01
    z[2,1,0]  R894      0.537086009979248
    z[2,1,0]  R895      4.9732410907745361e-01
    z[2,1,0]  R896      4.7364082932472229e-01
    z[2,1,0]  R897      -7.3809754848480225e-01
    z[2,1,0]  R898      -2.6245564222335815e-01
    z[2,1,0]  R899      -3.8120758533477783e-01
    z[2,1,0]  R900      1.0940525680780411e-01
    z[2,1,0]  R901      -3.2202787697315216e-03
    z[2,1,0]  R902      1.4168143272399902e-01
    z[2,1,0]  R903      -4.6991547942161560e-01
    z[2,1,0]  R904      -2.5674232840538025e-01
    z[2,1,0]  R905      3.3428356051445007e-01
    z[2,1,0]  R906      0.565673291683197
    z[2,1,0]  R907      -1.8310900032520294e-01
    z[2,1,0]  R908      -2.4000744521617889e-01
    z[2,1,0]  R909      -3.2580006122589111e-01
    z[2,1,0]  R910      0.0563129186630249
    z[2,1,0]  R911      -2.3766435682773590e-01
    z[2,1,0]  R912      2.7963241934776306e-01
    z[2,1,0]  R913      3.4242463111877441e-01
    z[2,1,0]  R914      2.7918154001235962e-01
    z[2,1,0]  R915      1.7188704013824463e-01
    z[2,1,0]  R916      2.6724824309349060e-01
    z[2,1,0]  R917      3.3592095971107483e-01
    z[2,1,0]  R918      2.6670613884925842e-01
    z[2,1,0]  R919      2.9679268598556519e-01
    z[2,1,0]  R920      3.2342132925987244e-01
    z[2,1,0]  R921      4.2374247312545776e-01
    z[2,1,0]  R922      5.6757301092147827e-01
    z[2,1,0]  R923      4.6850016713142395e-01
    z[2,1,0]  R924      6.9135004281997681e-01
    z[2,1,0]  R925      5.3372144699096680e-01
    z[2,1,0]  R926      6.4588135480880737e-01
    z[2,1,0]  R927      5.4391831159591675e-01
    z[2,1,0]  R928      2.6483288407325745e-01
    z[2,1,0]  R929      1.2983353435993195e-01
    z[2,1,0]  R930      3.0205753445625305e-01
    z[2,1,0]  R931      -2.7663335204124451e-02
    z[2,1,0]  R932      4.8140409588813782e-01
    z[2,1,0]  R933      -3.3962267637252808e-01
    z[2,1,0]  R934      -9.4367347657680511e-02
    z[2,1,0]  R935      -2.3696716129779816e-01
    z[2,1,0]  R936      -4.0758627653121948e-01
    z[2,1,0]  R937      -3.8331297039985657e-01
    z[2,1,0]  R938      1.3147702813148499e-01
    z[2,1,0]  R939      -6.6205447912216187e-01
    z[2,1,0]  R940      0.0634799376130104
    z[2,1,0]  R941      -4.9066832661628723e-01
    z[2,1,0]  R942      2.5178718566894531e-01
    z[2,1,0]  R943      -1.9391223788261414e-01
    z[2,1,0]  R944      4.9170383810997009e-01
    z[2,1,0]  R945      -2.4322444200515747e-01
    z[2,1,0]  R946      1.0009628534317017e-01
    z[2,1,0]  R947      4.7080019116401672e-01
    z[2,1,0]  R948      -1.3195669651031494e-01
    z[2,1,0]  R949      1.1216656118631363e-01
    z[2,1,0]  R950      5.4910188913345337e-01
    z[2,1,0]  R951      -3.1269797682762146e-01
    z[2,1,0]  R952      4.4816821813583374e-02
    z[2,1,0]  R953      -2.6699263602495193e-02
    z[2,1,0]  R954      5.7596504688262939e-01
    z[2,1,0]  R955      3.8244676589965820e-01
    z[2,1,0]  R956      7.2887712717056274e-01
    z[2,1,0]  R957      1.1982088536024094e-01
    z[2,1,0]  R958      -9.3095436692237854e-02
    z[2,1,0]  R959      7.0091545581817627e-01
    z[2,1,0]  R960      6.5625959634780884e-01
    z[2,1,0]  R961      0.729515790939331
    z[2,1,0]  R962      3.9137899875640869e-01
    z[2,1,0]  R963      5.6989258527755737e-01
    z[2,1,0]  R964      4.3833982944488525e-01
    z[2,1,0]  R965      -0.166781947016716
    z[2,1,0]  R966      -8.5881259292364120e-03
    z[2,1,0]  R967      -1.9071486592292786e-01
    z[2,1,0]  R968      2.8914827108383179e-01
    z[2,1,0]  R969      -3.4472441673278809e-01
    z[2,1,0]  R970      5.1635402441024780e-01
    z[2,1,0]  R971      7.0207953453063965e-02
    z[2,1,0]  R972      5.7533466815948486e-01
    z[2,1,0]  R973      1.5542012453079224e-01
    z[2,1,0]  R974      2.3176409304141998e-01
    z[2,1,0]  R975      -1.0020636767148972e-01
    z[2,1,0]  R976      -0.573139488697052
    z[2,1,0]  R977      -1.4173206686973572e-01
    z[2,1,0]  R978      -4.1580238938331604e-01
    z[2,1,0]  R979      -7.9225033521652222e-01
    z[2,1,0]  R980      -4.2027789354324341e-01
    z[2,1,0]  R981      -3.3313852548599243e-01
    z[2,1,0]  R982      2.9472494125366211e-01
    z[2,1,0]  R983      4.7758859395980835e-01
    z[2,1,0]  R984      0.695899486541748
    z[2,1,0]  R985      4.3001008033752441e-01
    z[2,1,0]  R986      1.0595851391553879e-01
    z[2,1,0]  R987      5.8363842964172363e-01
    z[2,1,0]  R988      0.500739574432373
    z[2,1,0]  R989      -6.7276030778884888e-01
    z[2,1,0]  R990      -0.639201819896698
    z[2,1,0]  R991      -4.3315351009368896e-01
    z[2,1,0]  R992      5.0770324468612671e-01
    z[2,1,0]  R993      6.2168218195438385e-02
    z[2,1,0]  R994      -7.0578551292419434e-01
    z[2,1,0]  R995      -2.9588720202445984e-01
    z[2,1,0]  R996      -4.6263718605041504e-01
    z[2,1,0]  R997      -6.7708253860473633e-01
    z[2,1,0]  R998      -4.0369123220443726e-01
    z[2,1,0]  R999      -6.2100154161453247e-01
    z[2,1,0]  R1000     -7.3160064220428467e-01
    z[2,1,0]  R1001     -6.7369800806045532e-01
    z[2,1,0]  R1002     6.7131519317626953e-01
    z[2,1,0]  R1003     3.7447464466094971e-01
    z[2,1,0]  R1004     -2.2601333260536194e-01
    z[2,1,0]  R1005     -5.8531010150909424e-01
    z[2,1,0]  R1006     -2.4237510561943054e-01
    z[2,1,0]  R1007     -2.5561258196830750e-01
    z[2,1,0]  R1008     -8.8041287660598755e-01
    z[2,1,0]  R1009     -5.3718191385269165e-01
    z[2,1,0]  R1010     -7.6415562629699707e-01
    z[2,1,0]  R1011     -8.0009514093399048e-01
    z[2,1,1]  R12       1
    z[2,1,1]  R21       -1
    z[2,1,1]  R880      -1
    z[2,1,1]  R881      1
    z[2,1,1]  R892      -3.2144561409950256e-01
    z[2,1,1]  R893      -2.0471605658531189e-01
    z[2,1,1]  R894      -3.1970420479774475e-01
    z[2,1,1]  R895      -1.8541653454303741e-01
    z[2,1,1]  R896      1.3635165989398956e-01
    z[2,1,1]  R897      -1.0374334640800953e-02
    z[2,1,1]  R898      -2.3291751742362976e-01
    z[2,1,1]  R899      3.8018960505723953e-02
    z[2,1,1]  R900      6.7745143175125122e-01
    z[2,1,1]  R901      0.726978063583374
    z[2,1,1]  R902      3.9020961523056030e-01
    z[2,1,1]  R903      -2.1759761869907379e-01
    z[2,1,1]  R904      -3.1393334269523621e-01
    z[2,1,1]  R905      5.5078876018524170e-01
    z[2,1,1]  R906      0.0785161480307579
    z[2,1,1]  R907      -8.9253157377243042e-02
    z[2,1,1]  R908      -2.2639174759387970e-01
    z[2,1,1]  R909      -4.4696471095085144e-01
    z[2,1,1]  R910      8.1399637460708618e-01
    z[2,1,1]  R911      7.4620097875595093e-01
    z[2,1,1]  R912      3.4309035539627075e-01
    z[2,1,1]  R913      3.0812993645668030e-01
    z[2,1,1]  R914      2.3934613168239594e-01
    z[2,1,1]  R915      -2.9777586460113525e-01
    z[2,1,1]  R916      -1.9624061882495880e-01
    z[2,1,1]  R917      4.1178426146507263e-01
    z[2,1,1]  R918      1.6529412567615509e-01
    z[2,1,1]  R919      5.1155781745910645e-01
    z[2,1,1]  R920      1.5445442497730255e-01
    z[2,1,1]  R921      -3.6533939838409424e-01
    z[2,1,1]  R922      -6.5492558479309082e-01
    z[2,1,1]  R923      -6.9631791114807129e-01
    z[2,1,1]  R924      -5.1652860641479492e-01
    z[2,1,1]  R925      -6.4939856529235840e-01
    z[2,1,1]  R926      -3.6016201972961426e-01
    z[2,1,1]  R927      -4.1192224621772766e-01
    z[2,1,1]  R928      -5.5285841226577759e-01
    z[2,1,1]  R929      -6.5408545732498169e-01
    z[2,1,1]  R930      -4.8382645845413208e-01
    z[2,1,1]  R931      -4.7620588541030884e-01
    z[2,1,1]  R932      0.547591507434845
    z[2,1,1]  R933      2.6197345927357674e-02
    z[2,1,1]  R934      2.6048806309700012e-01
    z[2,1,1]  R935      2.1758790314197540e-01
    z[2,1,1]  R936      1.6954356431961060e-01
    z[2,1,1]  R937      3.9316490292549133e-01
    z[2,1,1]  R938      -7.7843718230724335e-02
    z[2,1,1]  R939      1.7736643552780151e-01
    z[2,1,1]  R940      3.7261933088302612e-01
    z[2,1,1]  R941      3.1868198513984680e-01
    z[2,1,1]  R942      -6.4168584346771240e-01
    z[2,1,1]  R943      -5.1873183250427246e-01
    z[2,1,1]  R944      -5.3301793336868286e-01
    z[2,1,1]  R945      -4.2163071036338806e-01
    z[2,1,1]  R946      -5.7585906237363815e-02
    z[2,1,1]  R947      6.8187665939331055e-01
    z[2,1,1]  R948      -7.6996523141860962e-01
    z[2,1,1]  R949      -5.8149510622024536e-01
    z[2,1,1]  R950      4.9429732561111450e-01
    z[2,1,1]  R951      -4.6810075640678406e-01
    z[2,1,1]  R952      -7.8278720378875732e-01
    z[2,1,1]  R953      -8.3292537927627563e-01
    z[2,1,1]  R954      -5.1259505748748779e-01
    z[2,1,1]  R955      -6.0324513912200928e-01
    z[2,1,1]  R956      3.1696164608001709e-01
    z[2,1,1]  R957      -7.5302451848983765e-01
    z[2,1,1]  R958      -8.0823796987533569e-01
    z[2,1,1]  R959      -3.2325261831283569e-01
    z[2,1,1]  R960      -5.0754940509796143e-01
    z[2,1,1]  R961      3.8729032874107361e-01
    z[2,1,1]  R962      -8.6260598897933960e-01
    z[2,1,1]  R963      6.4150685071945190e-01
    z[2,1,1]  R964      5.9370237588882446e-01
    z[2,1,1]  R965      -6.1903841793537140e-02
    z[2,1,1]  R966      7.4042327702045441e-02
    z[2,1,1]  R967      6.0816723108291626e-01
    z[2,1,1]  R968      2.5047263503074646e-01
    z[2,1,1]  R969      -2.0845349133014679e-01
    z[2,1,1]  R970      3.9893460273742676e-01
    z[2,1,1]  R971      3.3393295598216355e-04
    z[2,1,1]  R972      5.4899090528488159e-01
    z[2,1,1]  R973      -8.4485612809658051e-02
    z[2,1,1]  R974      3.0647762119770050e-02
    z[2,1,1]  R975      3.6442461609840393e-01
    z[2,1,1]  R976      1.4070263504981995e-01
    z[2,1,1]  R977      0.718567967414856
    z[2,1,1]  R978      -1.8699440360069275e-01
    z[2,1,1]  R979      3.5574089735746384e-02
    z[2,1,1]  R980      1.3084031641483307e-01
    z[2,1,1]  R981      -3.3618080615997314e-01
    z[2,1,1]  R982      -0.850028932094574
    z[2,1,1]  R983      -6.1846506595611572e-01
    z[2,1,1]  R984      -3.7172517180442810e-01
    z[2,1,1]  R985      -5.4303795099258423e-01
    z[2,1,1]  R986      -6.5986555814743042e-01
    z[2,1,1]  R987      4.8054805397987366e-01
    z[2,1,1]  R988      1.3738648593425751e-01
    z[2,1,1]  R989      2.1112720668315887e-01
    z[2,1,1]  R990      -9.5226854085922241e-02
    z[2,1,1]  R991      2.2615295648574829e-01
    z[2,1,1]  R992      -6.8314230442047119e-01
    z[2,1,1]  R993      2.7245259284973145e-01
    z[2,1,1]  R994      -1.2807795405387878e-01
    z[2,1,1]  R995      1.5993210673332214e-01
    z[2,1,1]  R996      5.6421858072280884e-01
    z[2,1,1]  R997      1.5317335724830627e-01
    z[2,1,1]  R998      7.8978991508483887e-01
    z[2,1,1]  R999      4.4707828760147095e-01
    z[2,1,1]  R1000     4.8379644751548767e-01
    z[2,1,1]  R1001     4.0550419688224792e-01
    z[2,1,1]  R1002     5.6089580059051514e-01
    z[2,1,1]  R1003     -6.9278383255004883e-01
    z[2,1,1]  R1004     1.0703387856483459e-01
    z[2,1,1]  R1005     9.6009485423564911e-03
    z[2,1,1]  R1006     -7.1844294667243958e-02
    z[2,1,1]  R1007     -9.6338622272014618e-02
    z[2,1,1]  R1008     0.212177112698555
    z[2,1,1]  R1009     -3.5925975441932678e-01
    z[2,1,1]  R1010     2.7371007204055786e-01
    z[2,1,1]  R1011     4.9748173356056213e-01
    z[2,1,2]  R13       1
    z[2,1,2]  R22       -1
    z[2,1,2]  R882      -1
    z[2,1,2]  R883      1
    z[2,1,2]  R892      -0.515376091003418
    z[2,1,2]  R893      4.1804668307304382e-01
    z[2,1,2]  R894      1.2986409664154053e-01
    z[2,1,2]  R895      4.5868310332298279e-01
    z[2,1,2]  R896      3.5329717397689819e-01
    z[2,1,2]  R897      2.0457613468170166e-01
    z[2,1,2]  R898      -1.2198117375373840e-01
    z[2,1,2]  R899      -0.887882649898529
    z[2,1,2]  R900      -3.7543609738349915e-01
    z[2,1,2]  R901      -4.6628442406654358e-01
    z[2,1,2]  R902      1.2427022308111191e-01
    z[2,1,2]  R903      -2.0072016119956970e-01
    z[2,1,2]  R904      3.8638854026794434e-01
    z[2,1,2]  R905      -0.310772567987442
    z[2,1,2]  R906      2.9522114992141724e-01
    z[2,1,2]  R907      -8.5445863008499146e-01
    z[2,1,2]  R908      -9.0961974859237671e-01
    z[2,1,2]  R909      -6.8891471624374390e-01
    z[2,1,2]  R910      -8.8315911591053009e-02
    z[2,1,2]  R911      -2.7855682373046875e-01
    z[2,1,2]  R912      0.410097599029541
    z[2,1,2]  R913      1.9897668063640594e-01
    z[2,1,2]  R914      3.2608810067176819e-01
    z[2,1,2]  R915      3.4057784080505371e-01
    z[2,1,2]  R916      3.6706885695457458e-01
    z[2,1,2]  R917      2.4889845401048660e-02
    z[2,1,2]  R918      7.7606640756130219e-02
    z[2,1,2]  R919      4.7487378120422363e-01
    z[2,1,2]  R920      2.1392826735973358e-01
    z[2,1,2]  R921      3.6713370680809021e-01
    z[2,1,2]  R922      1.0967803001403809e-01
    z[2,1,2]  R923      -4.1845682263374329e-01
    z[2,1,2]  R924      -1.2607865035533905e-01
    z[2,1,2]  R925      -0.486369788646698
    z[2,1,2]  R926      5.4819411039352417e-01
    z[2,1,2]  R927      0.567703127861023
    z[2,1,2]  R928      3.9514392614364624e-02
    z[2,1,2]  R929      4.5630556344985962e-01
    z[2,1,2]  R930      -2.2555316984653473e-01
    z[2,1,2]  R931      3.5645312070846558e-01
    z[2,1,2]  R932      -4.2175155878067017e-01
    z[2,1,2]  R933      1.6420675441622734e-02
    z[2,1,2]  R934      4.6600274741649628e-02
    z[2,1,2]  R935      -1.8738220632076263e-01
    z[2,1,2]  R936      1.6186399757862091e-01
    z[2,1,2]  R937      1.7931106686592102e-01
    z[2,1,2]  R938      -3.0865499377250671e-01
    z[2,1,2]  R939      -7.1684408187866211e-01
    z[2,1,2]  R940      5.0356465578079224e-01
    z[2,1,2]  R941      -7.8330940008163452e-01
    z[2,1,2]  R942      4.0173164010047913e-01
    z[2,1,2]  R943      6.7916172742843628e-01
    z[2,1,2]  R944      5.6552004814147949e-01
    z[2,1,2]  R945      6.2351912260055542e-01
    z[2,1,2]  R946      2.7996173501014709e-01
    z[2,1,2]  R947      1.4014796912670135e-01
    z[2,1,2]  R948      2.6978957653045654e-01
    z[2,1,2]  R949      -1.8271125853061676e-01
    z[2,1,2]  R950      -3.0887761712074280e-01
    z[2,1,2]  R951      1.8305076658725739e-01
    z[2,1,2]  R952      4.6575519442558289e-01
    z[2,1,2]  R953      4.3002769351005554e-02
    z[2,1,2]  R954      1.5302455425262451e-01
    z[2,1,2]  R955      1.3386055361479521e-03
    z[2,1,2]  R956      1.3925452530384064e-01
    z[2,1,2]  R957      3.2627224922180176e-01
    z[2,1,2]  R958      -7.9252235591411591e-02
    z[2,1,2]  R959      4.8510608077049255e-01
    z[2,1,2]  R960      -1.7540137469768524e-01
    z[2,1,2]  R961      -1.7894359305500984e-02
    z[2,1,2]  R962      -1.7448730766773224e-01
    z[2,1,2]  R963      1.3207750022411346e-01
    z[2,1,2]  R964      -3.6221626400947571e-01
    z[2,1,2]  R965      1.9669516384601593e-01
    z[2,1,2]  R966      4.0278702974319458e-01
    z[2,1,2]  R967      -2.0718200504779816e-01
    z[2,1,2]  R968      -3.5573190450668335e-01
    z[2,1,2]  R969      -6.5912526845932007e-01
    z[2,1,2]  R970      1.1744274944067001e-01
    z[2,1,2]  R971      -7.6905059814453125e-01
    z[2,1,2]  R972      -9.8168686032295227e-02
    z[2,1,2]  R973      9.7359839128330350e-04
    z[2,1,2]  R974      -1.1752710491418839e-01
    z[2,1,2]  R975      1.9486773014068604e-01
    z[2,1,2]  R976      -5.7592725753784180e-01
    z[2,1,2]  R977      -0.561223030090332
    z[2,1,2]  R978      -5.7908612489700317e-01
    z[2,1,2]  R979      -2.6552328467369080e-01
    z[2,1,2]  R980      -6.9777297973632812e-01
    z[2,1,2]  R981      -7.7856051921844482e-01
    z[2,1,2]  R982      -9.9403075873851776e-02
    z[2,1,2]  R983      3.4059146046638489e-01
    z[2,1,2]  R984      1.4632999897003174e-01
    z[2,1,2]  R985      3.2667240500450134e-01
    z[2,1,2]  R986      1.5998254716396332e-01
    z[2,1,2]  R987      -2.1347789466381073e-01
    z[2,1,2]  R988      2.0259141921997070e-01
    z[2,1,2]  R989      -4.5913219451904297e-01
    z[2,1,2]  R990      -5.9972470998764038e-01
    z[2,1,2]  R991      -6.4753305912017822e-01
    z[2,1,2]  R992      -3.3333367109298706e-01
    z[2,1,2]  R993      3.7514597177505493e-01
    z[2,1,2]  R994      -2.6433351635932922e-01
    z[2,1,2]  R995      -7.7267253398895264e-01
    z[2,1,2]  R996      -1.0950347036123276e-01
    z[2,1,2]  R997      4.1314274072647095e-01
    z[2,1,2]  R998      -2.7503243088722229e-01
    z[2,1,2]  R999      -1.9831565022468567e-01
    z[2,1,2]  R1000     -8.4968388080596924e-02
    z[2,1,2]  R1001     -1.5004470944404602e-01
    z[2,1,2]  R1002     -0.174790620803833
    z[2,1,2]  R1003     3.1620880961418152e-01
    z[2,1,2]  R1004     -6.8193428218364716e-02
    z[2,1,2]  R1005     -6.0812151432037354e-01
    z[2,1,2]  R1006     -7.1764141321182251e-01
    z[2,1,2]  R1007     -8.1184077262878418e-01
    z[2,1,2]  R1008     -1.2061801552772522e-01
    z[2,1,2]  R1009     1.9096738100051880e-01
    z[2,1,2]  R1010     -2.4020045995712280e-01
    z[2,1,2]  R1011     -3.7953026592731476e-02
    z[2,1,3]  R14       1
    z[2,1,3]  R23       -1
    z[2,1,3]  R884      -1
    z[2,1,3]  R885      1
    z[2,1,3]  R892      1.5286819636821747e-01
    z[2,1,3]  R893      -5.1591819524765015e-01
    z[2,1,3]  R894      -4.9240902066230774e-01
    z[2,1,3]  R895      -1.6610951721668243e-01
    z[2,1,3]  R896      -3.2557976245880127e-01
    z[2,1,3]  R897      -6.2602853775024414e-01
    z[2,1,3]  R898      -0.666356086730957
    z[2,1,3]  R899      1.1362785845994949e-01
    z[2,1,3]  R900      1.0532516241073608e-01
    z[2,1,3]  R901      0.0982937142252922
    z[2,1,3]  R902      6.8599176406860352e-01
    z[2,1,3]  R903      5.1633769273757935e-01
    z[2,1,3]  R904      6.7470401525497437e-01
    z[2,1,3]  R905      -3.8525089621543884e-01
    z[2,1,3]  R906      4.1681462526321411e-01
    z[2,1,3]  R907      3.9265963435173035e-01
    z[2,1,3]  R908      5.7291448116302490e-02
    z[2,1,3]  R909      3.3894369006156921e-01
    z[2,1,3]  R910      -1.3183162547647953e-02
    z[2,1,3]  R911      8.3016470074653625e-02
    z[2,1,3]  R912      -1.8432404100894928e-01
    z[2,1,3]  R913      -5.1463800668716431e-01
    z[2,1,3]  R914      -6.4134937524795532e-01
    z[2,1,3]  R915      -4.0266942977905273e-01
    z[2,1,3]  R916      -4.4890768826007843e-02
    z[2,1,3]  R917      -4.6394917368888855e-01
    z[2,1,3]  R918      -3.5040271282196045e-01
    z[2,1,3]  R919      -8.3797693252563477e-02
    z[2,1,3]  R920      -2.0538680255413055e-03
    z[2,1,3]  R921      -3.6634132266044617e-01
    z[2,1,3]  R922      2.8865441679954529e-01
    z[2,1,3]  R923      3.6795396357774734e-02
    z[2,1,3]  R924      -1.4961647987365723e-01
    z[2,1,3]  R925      1.3712696731090546e-01
    z[2,1,3]  R926      6.4623266458511353e-02
    z[2,1,3]  R927      -9.1978013515472412e-02
    z[2,1,3]  R928      5.1226603984832764e-01
    z[2,1,3]  R929      -3.9801809191703796e-01
    z[2,1,3]  R930      -6.0857552289962769e-01
    z[2,1,3]  R931      -5.7703101634979248e-01
    z[2,1,3]  R932      2.6602050662040710e-01
    z[2,1,3]  R933      1.8930549919605255e-01
    z[2,1,3]  R934      6.5145730972290039e-01
    z[2,1,3]  R935      4.7060206532478333e-01
    z[2,1,3]  R936      4.4231966137886047e-01
    z[2,1,3]  R937      3.7852790951728821e-01
    z[2,1,3]  R938      2.2586712241172791e-01
    z[2,1,3]  R939      4.2727984488010406e-02
    z[2,1,3]  R940      5.4297196865081787e-01
    z[2,1,3]  R941      1.6417096555233002e-01
    z[2,1,3]  R942      -4.0744277834892273e-01
    z[2,1,3]  R943      -4.2608398199081421e-01
    z[2,1,3]  R944      1.6876373440027237e-02
    z[2,1,3]  R945      -5.5595141649246216e-01
    z[2,1,3]  R946      0.510107696056366
    z[2,1,3]  R947      2.4046397209167480e-01
    z[2,1,3]  R948      -3.1315666437149048e-01
    z[2,1,3]  R949      2.9579216241836548e-01
    z[2,1,3]  R950      3.9032116532325745e-01
    z[2,1,3]  R951      -7.2604638338088989e-01
    z[2,1,3]  R952      -1.0772946476936340e-01
    z[2,1,3]  R953      -7.8980810940265656e-02
    z[2,1,3]  R954      1.8345648050308228e-01
    z[2,1,3]  R955      3.1382623314857483e-01
    z[2,1,3]  R956      1.4028945565223694e-01
    z[2,1,3]  R957      -4.3615886569023132e-01
    z[2,1,3]  R958      -4.3881252408027649e-01
    z[2,1,3]  R959      1.0959044843912125e-01
    z[2,1,3]  R960      4.7214669175446033e-03
    z[2,1,3]  R961      -1.2928792834281921e-01
    z[2,1,3]  R962      -1.7415136098861694e-01
    z[2,1,3]  R963      7.4559003114700317e-02
    z[2,1,3]  R964      -1.0413333028554916e-01
    z[2,1,3]  R965      1.8462552130222321e-01
    z[2,1,3]  R966      0.713071882724762
    z[2,1,3]  R967      4.2764917016029358e-01
    z[2,1,3]  R968      6.1980700492858887e-01
    z[2,1,3]  R969      3.4250319004058838e-01
    z[2,1,3]  R970      0.574138879776001
    z[2,1,3]  R971      3.9793962240219116e-01
    z[2,1,3]  R972      -6.0092996805906296e-02
    z[2,1,3]  R973      0.777245819568634
    z[2,1,3]  R974      4.5326781272888184e-01
    z[2,1,3]  R975      2.7885380387306213e-01
    z[2,1,3]  R976      3.5766753554344177e-01
    z[2,1,3]  R977      3.2030284404754639e-01
    z[2,1,3]  R978      3.1763064861297607e-01
    z[2,1,3]  R979      3.8000747561454773e-01
    z[2,1,3]  R980      1.2909834086894989e-01
    z[2,1,3]  R981      -2.4669134616851807e-01
    z[2,1,3]  R982      -2.9174787923693657e-03
    z[2,1,3]  R983      -2.8880032896995544e-01
    z[2,1,3]  R984      4.0354898571968079e-01
    z[2,1,3]  R985      1.3501471281051636e-01
    z[2,1,3]  R986      -4.7309798002243042e-01
    z[2,1,3]  R987      -2.9963061213493347e-01
    z[2,1,3]  R988      5.4995840787887573e-01
    z[2,1,3]  R989      4.1433700919151306e-01
    z[2,1,3]  R990      4.0481972694396973e-01
    z[2,1,3]  R991      3.9746868610382080e-01
    z[2,1,3]  R992      -2.1642296016216278e-01
    z[2,1,3]  R993      6.3129258155822754e-01
    z[2,1,3]  R994      4.3214264512062073e-01
    z[2,1,3]  R995      3.4522926807403564e-01
    z[2,1,3]  R996      4.1966402530670166e-01
    z[2,1,3]  R997      3.2063734531402588e-01
    z[2,1,3]  R998      -1.9523462653160095e-01
    z[2,1,3]  R999      -5.5567425489425659e-01
    z[2,1,3]  R1000     -4.6835356950759888e-01
    z[2,1,3]  R1001     -4.9415045976638794e-01
    z[2,1,3]  R1002     -1.4836981892585754e-01
    z[2,1,3]  R1003     2.6959040760993958e-01
    z[2,1,3]  R1004     5.1917874813079834e-01
    z[2,1,3]  R1005     4.2698773741722107e-01
    z[2,1,3]  R1006     3.9615362882614136e-01
    z[2,1,3]  R1007     2.7314865589141846e-01
    z[2,1,3]  R1008     2.4443480372428894e-01
    z[2,1,3]  R1009     3.0787822604179382e-01
    z[2,1,3]  R1010     -5.2298015356063843e-01
    z[2,1,3]  R1011     -2.9256063699722290e-01
    z[2,1,4]  R15       1
    z[2,1,4]  R24       -1
    z[2,1,4]  R886      -1
    z[2,1,4]  R887      1
    z[2,1,4]  R892      1.4716325700283051e-01
    z[2,1,4]  R893      1.8556064367294312e-01
    z[2,1,4]  R894      -6.7625559866428375e-02
    z[2,1,4]  R895      -6.6623234748840332e-01
    z[2,1,4]  R896      6.1862188577651978e-01
    z[2,1,4]  R897      1.4586891233921051e-01
    z[2,1,4]  R898      -2.1497756242752075e-01
    z[2,1,4]  R899      -1.0132491588592529e-01
    z[2,1,4]  R900      1.1973230540752411e-01
    z[2,1,4]  R901      0.300994336605072
    z[2,1,4]  R902      2.9803445935249329e-01
    z[2,1,4]  R903      0.651832640171051
    z[2,1,4]  R904      4.7439518570899963e-01
    z[2,1,4]  R905      1.4170329086482525e-02
    z[2,1,4]  R906      2.2644495964050293e-01
    z[2,1,4]  R907      -1.3397192955017090e-01
    z[2,1,4]  R908      1.1349140852689743e-01
    z[2,1,4]  R909      -1.2802682816982269e-01
    z[2,1,4]  R910      -2.5850141048431396e-01
    z[2,1,4]  R911      -0.37811079621315
    z[2,1,4]  R912      1.3935865461826324e-01
    z[2,1,4]  R913      -3.3856093883514404e-02
    z[2,1,4]  R914      2.6250863075256348e-01
    z[2,1,4]  R915      2.3572713136672974e-02
    z[2,1,4]  R916      3.6814704537391663e-01
    z[2,1,4]  R917      1.7465278506278992e-01
    z[2,1,4]  R918      3.3341392874717712e-01
    z[2,1,4]  R919      -7.4151274748146534e-04
    z[2,1,4]  R920      2.8366908431053162e-01
    z[2,1,4]  R921      5.4026669263839722e-01
    z[2,1,4]  R922      -2.5515180826187134e-01
    z[2,1,4]  R923      -2.7427467703819275e-01
    z[2,1,4]  R924      -4.2240446805953979e-01
    z[2,1,4]  R925      2.7976479381322861e-02
    z[2,1,4]  R926      -1.7387789487838745e-01
    z[2,1,4]  R927      -4.3352580070495605e-01
    z[2,1,4]  R928      4.0010169148445129e-01
    z[2,1,4]  R929      6.9646663963794708e-02
    z[2,1,4]  R930      -5.0047025084495544e-02
    z[2,1,4]  R931      -4.9046209454536438e-01
    z[2,1,4]  R932      -3.5990697145462036e-01
    z[2,1,4]  R933      9.0682750940322876e-01
    z[2,1,4]  R934      6.9490909576416016e-01
    z[2,1,4]  R935      7.9154515266418457e-01
    z[2,1,4]  R936      7.2009402513504028e-01
    z[2,1,4]  R937      7.0644110441207886e-01
    z[2,1,4]  R938      8.1561535596847534e-01
    z[2,1,4]  R939      -7.3069550096988678e-02
    z[2,1,4]  R940      4.5287674665451050e-01
    z[2,1,4]  R941      1.2962979078292847e-01
    z[2,1,4]  R942      7.9473212361335754e-02
    z[2,1,4]  R943      -1.3623583316802979e-01
    z[2,1,4]  R944      2.1712502837181091e-01
    z[2,1,4]  R945      8.6590774357318878e-02
    z[2,1,4]  R946      7.9303735494613647e-01
    z[2,1,4]  R947      -1.8995349109172821e-01
    z[2,1,4]  R948      4.6238112449645996e-01
    z[2,1,4]  R949      7.1789878606796265e-01
    z[2,1,4]  R950      4.2612543702125549e-01
    z[2,1,4]  R951      -2.2465731203556061e-01
    z[2,1,4]  R952      1.1231165379285812e-01
    z[2,1,4]  R953      4.8143625259399414e-01
    z[2,1,4]  R954      3.1954690814018250e-01
    z[2,1,4]  R955      3.2098862528800964e-01
    z[2,1,4]  R956      -4.3746823072433472e-01
    z[2,1,4]  R957      -1.7073710262775421e-01
    z[2,1,4]  R958      -2.0819954574108124e-02
    z[2,1,4]  R959      -0.0989551842212677
    z[2,1,4]  R960      2.5268995761871338e-01
    z[2,1,4]  R961      1.5949079394340515e-01
    z[2,1,4]  R962      0.136853888630867
    z[2,1,4]  R963      1.7795832455158234e-01
    z[2,1,4]  R964      -1.3361354172229767e-01
    z[2,1,4]  R965      8.3230429887771606e-01
    z[2,1,4]  R966      4.1093739867210388e-01
    z[2,1,4]  R967      5.3052127361297607e-01
    z[2,1,4]  R968      5.1477003097534180e-01
    z[2,1,4]  R969      5.0155729055404663e-01
    z[2,1,4]  R970      2.9172223806381226e-01
    z[2,1,4]  R971      4.8056846857070923e-01
    z[2,1,4]  R972      2.6530984044075012e-01
    z[2,1,4]  R973      5.4606622457504272e-01
    z[2,1,4]  R974      7.8615558147430420e-01
    z[2,1,4]  R975      6.2929922342300415e-01
    z[2,1,4]  R976      2.6644504070281982e-01
    z[2,1,4]  R977      -3.8745053112506866e-02
    z[2,1,4]  R978      2.0344233512878418e-01
    z[2,1,4]  R979      1.7360401153564453e-01
    z[2,1,4]  R980      5.9470452368259430e-02
    z[2,1,4]  R981      2.6736825704574585e-02
    z[2,1,4]  R982      3.3870872855186462e-01
    z[2,1,4]  R983      5.5658571422100067e-02
    z[2,1,4]  R984      -7.8829256817698479e-03
    z[2,1,4]  R985      7.8902617096900940e-02
    z[2,1,4]  R986      1.1656423658132553e-01
    z[2,1,4]  R987      2.7199275791645050e-02
    z[2,1,4]  R988      4.8117798566818237e-01
    z[2,1,4]  R989      3.0255025625228882e-01
    z[2,1,4]  R990      3.3595968037843704e-02
    z[2,1,4]  R991      1.6369393467903137e-01
    z[2,1,4]  R992      -2.9842811822891235e-01
    z[2,1,4]  R993      5.3670382499694824e-01
    z[2,1,4]  R994      4.7548791766166687e-01
    z[2,1,4]  R995      2.9210817813873291e-01
    z[2,1,4]  R996      4.8938098549842834e-01
    z[2,1,4]  R997      3.6667466163635254e-01
    z[2,1,4]  R998      -3.0993974208831787e-01
    z[2,1,4]  R999      -2.1801907569169998e-02
    z[2,1,4]  R1000     -6.2543079257011414e-02
    z[2,1,4]  R1001     -2.3602099716663361e-01
    z[2,1,4]  R1002     8.2893833518028259e-02
    z[2,1,4]  R1003     2.8686946630477905e-01
    z[2,1,4]  R1004     7.8496611118316650e-01
    z[2,1,4]  R1005     1.9304936751723289e-02
    z[2,1,4]  R1006     0.449378103017807
    z[2,1,4]  R1007     -3.3246347308158875e-01
    z[2,1,4]  R1008     -1.7195332795381546e-02
    z[2,1,4]  R1009     2.4461318552494049e-01
    z[2,1,4]  R1010     1.0814021341502666e-02
    z[2,1,4]  R1011     1.1211378872394562e-01
    z[2,1,5]  R16       1
    z[2,1,5]  R25       -1
    z[2,1,5]  R888      -1
    z[2,1,5]  R889      1
    z[2,1,5]  R892      -8.9536219835281372e-02
    z[2,1,5]  R893      -4.3601948022842407e-01
    z[2,1,5]  R894      -4.3901872634887695e-01
    z[2,1,5]  R895      -1.8987026810646057e-01
    z[2,1,5]  R896      -1.1239253729581833e-01
    z[2,1,5]  R897      1.7196870176121593e-03
    z[2,1,5]  R898      -6.0424745082855225e-01
    z[2,1,5]  R899      2.7948565781116486e-02
    z[2,1,5]  R900      -5.8154165744781494e-01
    z[2,1,5]  R901      -3.6647930741310120e-01
    z[2,1,5]  R902      -0.28862264752388
    z[2,1,5]  R903      2.3364624939858913e-04
    z[2,1,5]  R904      -0.0412154383957386
    z[2,1,5]  R905      2.4114564061164856e-02
    z[2,1,5]  R906      -2.6987118646502495e-02
    z[2,1,5]  R907      1.8430331349372864e-01
    z[2,1,5]  R908      2.1725286543369293e-01
    z[2,1,5]  R909      1.8040643632411957e-01
    z[2,1,5]  R910      -2.1415190398693085e-01
    z[2,1,5]  R911      -2.1765044331550598e-01
    z[2,1,5]  R912      -7.4647432565689087e-01
    z[2,1,5]  R913      -6.3916242122650146e-01
    z[2,1,5]  R914      -5.0884467363357544e-01
    z[2,1,5]  R915      -7.2125869989395142e-01
    z[2,1,5]  R916      -7.8055894374847412e-01
    z[2,1,5]  R917      -6.7628163099288940e-01
    z[2,1,5]  R918      -7.5406205654144287e-01
    z[2,1,5]  R919      -5.4106724262237549e-01
    z[2,1,5]  R920      -7.7640181779861450e-01
    z[2,1,5]  R921      -3.3120352029800415e-01
    z[2,1,5]  R922      -1.7839916050434113e-01
    z[2,1,5]  R923      3.4148350358009338e-02
    z[2,1,5]  R924      1.8258308991789818e-02
    z[2,1,5]  R925      -1.8633460998535156e-01
    z[2,1,5]  R926      -1.9224444031715393e-01
    z[2,1,5]  R927      1.1763998866081238e-01
    z[2,1,5]  R928      2.6581385731697083e-01
    z[2,1,5]  R929      -3.4957072138786316e-01
    z[2,1,5]  R930      9.1608978807926178e-02
    z[2,1,5]  R931      4.0881808847188950e-02
    z[2,1,5]  R932      2.3601700365543365e-01
    z[2,1,5]  R933      1.3677023351192474e-01
    z[2,1,5]  R934      7.3405399918556213e-02
    z[2,1,5]  R935      1.0969126969575882e-01
    z[2,1,5]  R936      9.2714056372642517e-02
    z[2,1,5]  R937      1.4815928041934967e-01
    z[2,1,5]  R938      2.1618127822875977e-01
    z[2,1,5]  R939      8.9850440621376038e-02
    z[2,1,5]  R940      3.2188418507575989e-01
    z[2,1,5]  R941      1.1667750775814056e-02
    z[2,1,5]  R942      3.9937481284141541e-01
    z[2,1,5]  R943      -8.7309010326862335e-02
    z[2,1,5]  R944      2.4414394795894623e-01
    z[2,1,5]  R945      2.3820179700851440e-01
    z[2,1,5]  R946      1.0241446644067764e-01
    z[2,1,5]  R947      4.2090556025505066e-01
    z[2,1,5]  R948      -6.4658693969249725e-02
    z[2,1,5]  R949      -1.1355581879615784e-01
    z[2,1,5]  R950      1.5739759802818298e-01
    z[2,1,5]  R951      2.3948132991790771e-01
    z[2,1,5]  R952      2.2364287078380585e-01
    z[2,1,5]  R953      1.7969799041748047e-01
    z[2,1,5]  R954      -3.2613289356231689e-01
    z[2,1,5]  R955      4.9317643046379089e-01
    z[2,1,5]  R956      3.1518206000328064e-01
    z[2,1,5]  R957      -3.0196252465248108e-01
    z[2,1,5]  R958      2.6776146888732910e-01
    z[2,1,5]  R959      3.0875065922737122e-01
    z[2,1,5]  R960      1.9810175895690918e-01
    z[2,1,5]  R961      4.8662075400352478e-01
    z[2,1,5]  R962      1.3925476372241974e-01
    z[2,1,5]  R963      4.4187238812446594e-01
    z[2,1,5]  R964      3.6108088493347168e-01
    z[2,1,5]  R965      4.4546341896057129e-01
    z[2,1,5]  R966      1.2333232164382935e-01
    z[2,1,5]  R967      -1.0340360924601555e-02
    z[2,1,5]  R968      2.5306472182273865e-01
    z[2,1,5]  R969      3.0567046254873276e-02
    z[2,1,5]  R970      1.1456538736820221e-01
    z[2,1,5]  R971      4.9303401261568069e-02
    z[2,1,5]  R972      4.6101510524749756e-01
    z[2,1,5]  R973      3.7257452495396137e-03
    z[2,1,5]  R974      1.2055249512195587e-01
    z[2,1,5]  R975      1.0165440291166306e-01
    z[2,1,5]  R976      -3.0589890480041504e-01
    z[2,1,5]  R977      -1.5219344198703766e-01
    z[2,1,5]  R978      -8.9321933686733246e-02
    z[2,1,5]  R979      -6.7859692499041557e-03
    z[2,1,5]  R980      -1.3576747849583626e-02
    z[2,1,5]  R981      1.4903441071510315e-01
    z[2,1,5]  R982      -0.248980313539505
    z[2,1,5]  R983      -0.105091892182827
    z[2,1,5]  R984      4.3572276830673218e-01
    z[2,1,5]  R985      -5.9681254625320435e-01
    z[2,1,5]  R986      -4.2099773883819580e-01
    z[2,1,5]  R987      4.4694775342941284e-01
    z[2,1,5]  R988      2.5101962685585022e-01
    z[2,1,5]  R989      -1.2519478797912598e-01
    z[2,1,5]  R990      -2.3776248097419739e-01
    z[2,1,5]  R991      -8.8280171155929565e-02
    z[2,1,5]  R992      -1.3381315767765045e-01
    z[2,1,5]  R993      2.9748940467834473e-01
    z[2,1,5]  R994      4.6417381614446640e-02
    z[2,1,5]  R995      -8.5791319608688354e-02
    z[2,1,5]  R996      -1.8986134231090546e-01
    z[2,1,5]  R997      1.2778806686401367e-01
    z[2,1,5]  R998      0.00913998018950224
    z[2,1,5]  R999      1.4865861833095551e-01
    z[2,1,5]  R1000     -2.4004525039345026e-03
    z[2,1,5]  R1001     -2.4128738045692444e-01
    z[2,1,5]  R1002     0.412727415561676
    z[2,1,5]  R1003     2.9499068856239319e-01
    z[2,1,5]  R1004     2.1359564363956451e-01
    z[2,1,5]  R1005     -1.1896307766437531e-01
    z[2,1,5]  R1006     2.3534636944532394e-02
    z[2,1,5]  R1007     -1.2104593962430954e-01
    z[2,1,5]  R1008     6.8074040114879608e-02
    z[2,1,5]  R1009     1.6482903063297272e-01
    z[2,1,5]  R1010     -8.3766825497150421e-02
    z[2,1,5]  R1011     -2.2390339523553848e-02
    z[2,1,6]  R17       1
    z[2,1,6]  R26       -1
    z[2,1,6]  R890      -1
    z[2,1,6]  R891      1
    z[2,1,6]  R892      1.3442881405353546e-01
    z[2,1,6]  R893      -1.6207480430603027e-01
    z[2,1,6]  R894      3.9075037837028503e-01
    z[2,1,6]  R895      -1.9765419885516167e-02
    z[2,1,6]  R896      3.6183750629425049e-01
    z[2,1,6]  R897      0.00778647605329752
    z[2,1,6]  R898      -0.0814017578959465
    z[2,1,6]  R899      2.0233786106109619e-01
    z[2,1,6]  R900      1.5658171474933624e-01
    z[2,1,6]  R901      -1.3966041803359985e-01
    z[2,1,6]  R902      -4.1171273589134216e-01
    z[2,1,6]  R903      7.1930252015590668e-03
    z[2,1,6]  R904      6.5253138542175293e-02
    z[2,1,6]  R905      -0.582328200340271
    z[2,1,6]  R906      6.0079389810562134e-01
    z[2,1,6]  R907      1.4935743808746338e-01
    z[2,1,6]  R908      -1.9328398630023003e-02
    z[2,1,6]  R909      -0.235909104347229
    z[2,1,6]  R910      0.462148517370224
    z[2,1,6]  R911      3.3447670936584473e-01
    z[2,1,6]  R912      1.5904265642166138e-01
    z[2,1,6]  R913      0.271445095539093
    z[2,1,6]  R914      -1.3883425295352936e-01
    z[2,1,6]  R915      2.8788670897483826e-01
    z[2,1,6]  R916      9.2242740094661713e-02
    z[2,1,6]  R917      -1.1773692071437836e-01
    z[2,1,6]  R918      -0.304904043674469
    z[2,1,6]  R919      -3.5347026586532593e-01
    z[2,1,6]  R920      -3.7749823927879333e-01
    z[2,1,6]  R921      1.2803323566913605e-01
    z[2,1,6]  R922      2.3802106082439423e-01
    z[2,1,6]  R923      2.0687267184257507e-01
    z[2,1,6]  R924      -1.9543178379535675e-01
    z[2,1,6]  R925      -5.0599705427885056e-02
    z[2,1,6]  R926      -2.8501942753791809e-01
    z[2,1,6]  R927      -4.4072084128856659e-02
    z[2,1,6]  R928      3.5985404253005981e-01
    z[2,1,6]  R929      -2.4825769662857056e-01
    z[2,1,6]  R930      -4.9248144030570984e-01
    z[2,1,6]  R931      -2.6498025655746460e-01
    z[2,1,6]  R932      1.8578261137008667e-01
    z[2,1,6]  R933      -0.0825931504368782
    z[2,1,6]  R934      9.1572798788547516e-02
    z[2,1,6]  R935      3.6711718887090683e-02
    z[2,1,6]  R936      2.3696108162403107e-01
    z[2,1,6]  R937      4.5238483697175980e-02
    z[2,1,6]  R938      -3.4410390257835388e-01
    z[2,1,6]  R939      -0.0334925651550293
    z[2,1,6]  R940      -4.7413217835128307e-03
    z[2,1,6]  R941      -1.4855190180242062e-02
    z[2,1,6]  R942      -1.7784331738948822e-01
    z[2,1,6]  R943      1.5596219897270203e-01
    z[2,1,6]  R944      -2.1742123365402222e-01
    z[2,1,6]  R945      -3.1197572126984596e-02
    z[2,1,6]  R946      -9.3162119388580322e-02
    z[2,1,6]  R947      1.5060979127883911e-01
    z[2,1,6]  R948      -3.0172318220138550e-02
    z[2,1,6]  R949      1.1491342447698116e-02
    z[2,1,6]  R950      -6.6568199545145035e-03
    z[2,1,6]  R951      1.2094780057668686e-01
    z[2,1,6]  R952      3.0671152472496033e-01
    z[2,1,6]  R953      1.8265551328659058e-01
    z[2,1,6]  R954      -3.7411868572235107e-01
    z[2,1,6]  R955      2.1233037114143372e-01
    z[2,1,6]  R956      0.196168914437294
    z[2,1,6]  R957      -3.9702009409666061e-02
    z[2,1,6]  R958      2.5907030701637268e-01
    z[2,1,6]  R959      -2.2752623260021210e-01
    z[2,1,6]  R960      -4.2170169949531555e-01
    z[2,1,6]  R961      -1.9631689786911011e-01
    z[2,1,6]  R962      -6.1951391398906708e-02
    z[2,1,6]  R963      1.1733530461788177e-01
    z[2,1,6]  R964      -4.0632402896881104e-01
    z[2,1,6]  R965      -6.6393963992595673e-02
    z[2,1,6]  R966      3.7370380759239197e-01
    z[2,1,6]  R967      -2.9392614960670471e-01
    z[2,1,6]  R968      -1.1798671633005142e-01
    z[2,1,6]  R969      1.8293111026287079e-01
    z[2,1,6]  R970      -3.6410754919052124e-01
    z[2,1,6]  R971      -1.0908308625221252e-01
    z[2,1,6]  R972      2.6725763082504272e-01
    z[2,1,6]  R973      2.5766745209693909e-01
    z[2,1,6]  R974      -3.0579122900962830e-01
    z[2,1,6]  R975      -5.7885181903839111e-01
    z[2,1,6]  R976      1.6591729223728180e-01
    z[2,1,6]  R977      1.4609168469905853e-01
    z[2,1,6]  R978      -5.5366444587707520e-01
    z[2,1,6]  R979      -3.5493856668472290e-01
    z[2,1,6]  R980      -0.546783983707428
    z[2,1,6]  R981      -2.9336306452751160e-01
    z[2,1,6]  R982      -6.3115954399108887e-02
    z[2,1,6]  R983      -4.1935643553733826e-01
    z[2,1,6]  R984      5.7996802031993866e-02
    z[2,1,6]  R985      -1.8123584985733032e-01
    z[2,1,6]  R986      -0.336314857006073
    z[2,1,6]  R987      -3.0428001284599304e-01
    z[2,1,6]  R988      -3.0388179421424866e-01
    z[2,1,6]  R989      -1.1459008604288101e-01
    z[2,1,6]  R990      -3.3831059932708740e-02
    z[2,1,6]  R991      3.8647550344467163e-01
    z[2,1,6]  R992      -1.0314249992370605e-01
    z[2,1,6]  R993      7.8031592071056366e-02
    z[2,1,6]  R994      -2.4493908509612083e-02
    z[2,1,6]  R995      -2.7924704551696777e-01
    z[2,1,6]  R996      6.3042402267456055e-02
    z[2,1,6]  R997      -3.0630344152450562e-01
    z[2,1,6]  R998      -5.7962872087955475e-02
    z[2,1,6]  R999      -2.0928554236888885e-01
    z[2,1,6]  R1000     1.4468098059296608e-02
    z[2,1,6]  R1001     3.2767906785011292e-02
    z[2,1,6]  R1002     -7.0363827049732208e-02
    z[2,1,6]  R1003     1.9452148675918579e-01
    z[2,1,6]  R1004     -3.8339901715517044e-02
    z[2,1,6]  R1005     3.0110573768615723e-01
    z[2,1,6]  R1006     2.4829675257205963e-01
    z[2,1,6]  R1007     -2.5787854194641113e-01
    z[2,1,6]  R1008     3.1721785664558411e-01
    z[2,1,6]  R1009     -6.0341215133666992e-01
    z[2,1,6]  R1010     5.3015735000371933e-02
    z[2,1,6]  R1011     1.1071027070283890e-01
    z[1,3,0]  R11       -1
    z[1,3,0]  R29       1
    z[1,3,0]  R1012     -1
    z[1,3,0]  R1013     1
    z[1,3,0]  R1026     2.7963241934776306e-01
    z[1,3,0]  R1027     3.4242463111877441e-01
    z[1,3,0]  R1028     2.7918154001235962e-01
    z[1,3,0]  R1029     1.7188704013824463e-01
    z[1,3,0]  R1030     2.6724824309349060e-01
    z[1,3,0]  R1031     3.3592095971107483e-01
    z[1,3,0]  R1032     2.6670613884925842e-01
    z[1,3,0]  R1033     2.9679268598556519e-01
    z[1,3,0]  R1034     3.2342132925987244e-01
    z[1,3,0]  R1035     4.2374247312545776e-01
    z[1,3,0]  R1036     5.6757301092147827e-01
    z[1,3,0]  R1037     4.6850016713142395e-01
    z[1,3,0]  R1038     6.9135004281997681e-01
    z[1,3,0]  R1039     5.3372144699096680e-01
    z[1,3,0]  R1040     6.4588135480880737e-01
    z[1,3,0]  R1041     5.4391831159591675e-01
    z[1,3,0]  R1042     2.6483288407325745e-01
    z[1,3,0]  R1043     1.2983353435993195e-01
    z[1,3,0]  R1044     3.0205753445625305e-01
    z[1,3,0]  R1045     -2.7663335204124451e-02
    z[1,3,0]  R1046     4.8140409588813782e-01
    z[1,3,0]  R1047     -3.3962267637252808e-01
    z[1,3,0]  R1048     -9.4367347657680511e-02
    z[1,3,0]  R1049     -2.3696716129779816e-01
    z[1,3,0]  R1050     -4.0758627653121948e-01
    z[1,3,0]  R1051     -3.8331297039985657e-01
    z[1,3,0]  R1052     1.3147702813148499e-01
    z[1,3,0]  R1053     -6.6205447912216187e-01
    z[1,3,0]  R1054     0.0634799376130104
    z[1,3,0]  R1055     -4.9066832661628723e-01
    z[1,3,0]  R1056     2.5178718566894531e-01
    z[1,3,0]  R1057     -1.9391223788261414e-01
    z[1,3,0]  R1058     4.9170383810997009e-01
    z[1,3,0]  R1059     -2.4322444200515747e-01
    z[1,3,0]  R1060     1.0009628534317017e-01
    z[1,3,0]  R1061     4.7080019116401672e-01
    z[1,3,0]  R1062     -1.3195669651031494e-01
    z[1,3,0]  R1063     1.1216656118631363e-01
    z[1,3,0]  R1064     5.4910188913345337e-01
    z[1,3,0]  R1065     -3.1269797682762146e-01
    z[1,3,0]  R1066     4.4816821813583374e-02
    z[1,3,0]  R1067     -2.6699263602495193e-02
    z[1,3,0]  R1068     5.7596504688262939e-01
    z[1,3,0]  R1069     3.8244676589965820e-01
    z[1,3,0]  R1070     7.2887712717056274e-01
    z[1,3,0]  R1071     1.1982088536024094e-01
    z[1,3,0]  R1072     -9.3095436692237854e-02
    z[1,3,0]  R1073     7.0091545581817627e-01
    z[1,3,0]  R1074     6.5625959634780884e-01
    z[1,3,0]  R1075     0.729515790939331
    z[1,3,0]  R1076     3.9137899875640869e-01
    z[1,3,0]  R1077     5.6989258527755737e-01
    z[1,3,0]  R1078     4.3833982944488525e-01
    z[1,3,0]  R1079     -0.166781947016716
    z[1,3,0]  R1080     -8.5881259292364120e-03
    z[1,3,0]  R1081     -1.9071486592292786e-01
    z[1,3,0]  R1082     2.8914827108383179e-01
    z[1,3,0]  R1083     -3.4472441673278809e-01
    z[1,3,0]  R1084     5.1635402441024780e-01
    z[1,3,0]  R1085     7.0207953453063965e-02
    z[1,3,0]  R1086     5.7533466815948486e-01
    z[1,3,0]  R1087     1.5542012453079224e-01
    z[1,3,0]  R1088     2.3176409304141998e-01
    z[1,3,0]  R1089     -1.0020636767148972e-01
    z[1,3,0]  R1090     -0.573139488697052
    z[1,3,0]  R1091     -1.4173206686973572e-01
    z[1,3,0]  R1092     -4.1580238938331604e-01
    z[1,3,0]  R1093     -7.9225033521652222e-01
    z[1,3,0]  R1094     -4.2027789354324341e-01
    z[1,3,0]  R1095     -3.3313852548599243e-01
    z[1,3,0]  R1096     2.9472494125366211e-01
    z[1,3,0]  R1097     4.7758859395980835e-01
    z[1,3,0]  R1098     0.695899486541748
    z[1,3,0]  R1099     4.3001008033752441e-01
    z[1,3,0]  R1100     1.0595851391553879e-01
    z[1,3,0]  R1101     5.8363842964172363e-01
    z[1,3,0]  R1102     0.500739574432373
    z[1,3,0]  R1103     -6.7276030778884888e-01
    z[1,3,0]  R1104     -0.639201819896698
    z[1,3,0]  R1105     -4.3315351009368896e-01
    z[1,3,0]  R1106     5.0770324468612671e-01
    z[1,3,0]  R1107     6.2168218195438385e-02
    z[1,3,0]  R1108     -7.0578551292419434e-01
    z[1,3,0]  R1109     -2.9588720202445984e-01
    z[1,3,0]  R1110     -4.6263718605041504e-01
    z[1,3,0]  R1111     -6.7708253860473633e-01
    z[1,3,0]  R1112     -4.0369123220443726e-01
    z[1,3,0]  R1113     -6.2100154161453247e-01
    z[1,3,0]  R1114     -7.3160064220428467e-01
    z[1,3,0]  R1115     -6.7369800806045532e-01
    z[1,3,0]  R1116     6.7131519317626953e-01
    z[1,3,0]  R1117     3.7447464466094971e-01
    z[1,3,0]  R1118     -2.2601333260536194e-01
    z[1,3,0]  R1119     -5.8531010150909424e-01
    z[1,3,0]  R1120     -2.4237510561943054e-01
    z[1,3,0]  R1121     -2.5561258196830750e-01
    z[1,3,0]  R1122     -8.8041287660598755e-01
    z[1,3,0]  R1123     -5.3718191385269165e-01
    z[1,3,0]  R1124     -7.6415562629699707e-01
    z[1,3,0]  R1125     -8.0009514093399048e-01
    z[1,3,0]  R1126     -5.7539260387420654e-01
    z[1,3,0]  R1127     -4.6624532341957092e-01
    z[1,3,0]  R1128     -5.0899642705917358e-01
    z[1,3,0]  R1129     -1.2014885246753693e-01
    z[1,3,0]  R1130     -5.0082010030746460e-01
    z[1,3,0]  R1131     5.9517875313758850e-02
    z[1,3,0]  R1132     -1.1326623708009720e-01
    z[1,3,0]  R1133     1.3849098980426788e-01
    z[1,3,0]  R1134     4.2004132270812988e-01
    z[1,3,0]  R1135     1.9014729559421539e-01
    z[1,3,0]  R1136     5.7204455137252808e-01
    z[1,3,0]  R1137     0.572113037109375
    z[1,3,0]  R1138     5.7787096500396729e-01
    z[1,3,0]  R1139     5.3382194042205811e-01
    z[1,3,0]  R1140     1.7811340093612671e-01
    z[1,3,0]  R1141     5.7484441995620728e-01
    z[1,3,0]  R1142     0.334280788898468
    z[1,3,0]  R1143     5.1705837249755859e-02
    z[1,3,0]  R1144     3.4049415588378906e-01
    z[1,3,0]  R1145     6.3084119558334351e-01
    z[1,3,0]  R1146     9.9886313080787659e-02
    z[1,3,0]  R1147     0.684758722782135
    z[1,3,0]  R1148     5.9450703859329224e-01
    z[1,3,0]  R1149     5.3604131937026978e-01
    z[1,3,0]  R1150     5.7761001586914062e-01
    z[1,3,0]  R1151     5.9616720676422119e-01
    z[1,3,0]  R1152     5.5288159847259521e-01
    z[1,3,0]  R1153     6.0106503963470459e-01
    z[1,3,0]  R1154     4.5466482639312744e-01
    z[1,3,0]  R1155     6.2489295005798340e-01
    z[1,3,0]  R1156     -4.3019089847803116e-02
    z[1,3,0]  R1157     -4.8385281115770340e-02
    z[1,3,0]  R1158     -5.2565336227416992e-01
    z[1,3,0]  R1159     -1.6974531114101410e-01
    z[1,3,0]  R1160     7.1861910820007324e-01
    z[1,3,0]  R1161     -4.3361854553222656e-01
    z[1,3,0]  R1162     -5.8581691980361938e-01
    z[1,3,0]  R1163     -8.2092887163162231e-01
    z[1,3,0]  R1164     -7.8789454698562622e-01
    z[1,3,0]  R1165     -7.9566174745559692e-01
    z[1,3,0]  R1166     9.5633447170257568e-02
    z[1,3,0]  R1167     7.3859155178070068e-02
    z[1,3,0]  R1168     1.6299448907375336e-01
    z[1,3,0]  R1169     -0.557685136795044
    z[1,3,0]  R1170     -2.3144088685512543e-01
    z[1,3,0]  R1171     8.0284041166305542e-01
    z[1,3,0]  R1172     -0.42790487408638
    z[1,3,0]  R1173     -4.4375672936439514e-01
    z[1,3,0]  R1174     -1.8512088805437088e-02
    z[1,3,0]  R1175     3.3699741959571838e-01
    z[1,3,1]  R12       -1
    z[1,3,1]  R30       1
    z[1,3,1]  R1014     -1
    z[1,3,1]  R1015     1
    z[1,3,1]  R1026     3.4309035539627075e-01
    z[1,3,1]  R1027     3.0812993645668030e-01
    z[1,3,1]  R1028     2.3934613168239594e-01
    z[1,3,1]  R1029     -2.9777586460113525e-01
    z[1,3,1]  R1030     -1.9624061882495880e-01
    z[1,3,1]  R1031     4.1178426146507263e-01
    z[1,3,1]  R1032     1.6529412567615509e-01
    z[1,3,1]  R1033     5.1155781745910645e-01
    z[1,3,1]  R1034     1.5445442497730255e-01
    z[1,3,1]  R1035     -3.6533939838409424e-01
    z[1,3,1]  R1036     -6.5492558479309082e-01
    z[1,3,1]  R1037     -6.9631791114807129e-01
    z[1,3,1]  R1038     -5.1652860641479492e-01
    z[1,3,1]  R1039     -6.4939856529235840e-01
    z[1,3,1]  R1040     -3.6016201972961426e-01
    z[1,3,1]  R1041     -4.1192224621772766e-01
    z[1,3,1]  R1042     -5.5285841226577759e-01
    z[1,3,1]  R1043     -6.5408545732498169e-01
    z[1,3,1]  R1044     -4.8382645845413208e-01
    z[1,3,1]  R1045     -4.7620588541030884e-01
    z[1,3,1]  R1046     0.547591507434845
    z[1,3,1]  R1047     2.6197345927357674e-02
    z[1,3,1]  R1048     2.6048806309700012e-01
    z[1,3,1]  R1049     2.1758790314197540e-01
    z[1,3,1]  R1050     1.6954356431961060e-01
    z[1,3,1]  R1051     3.9316490292549133e-01
    z[1,3,1]  R1052     -7.7843718230724335e-02
    z[1,3,1]  R1053     1.7736643552780151e-01
    z[1,3,1]  R1054     3.7261933088302612e-01
    z[1,3,1]  R1055     3.1868198513984680e-01
    z[1,3,1]  R1056     -6.4168584346771240e-01
    z[1,3,1]  R1057     -5.1873183250427246e-01
    z[1,3,1]  R1058     -5.3301793336868286e-01
    z[1,3,1]  R1059     -4.2163071036338806e-01
    z[1,3,1]  R1060     -5.7585906237363815e-02
    z[1,3,1]  R1061     6.8187665939331055e-01
    z[1,3,1]  R1062     -7.6996523141860962e-01
    z[1,3,1]  R1063     -5.8149510622024536e-01
    z[1,3,1]  R1064     4.9429732561111450e-01
    z[1,3,1]  R1065     -4.6810075640678406e-01
    z[1,3,1]  R1066     -7.8278720378875732e-01
    z[1,3,1]  R1067     -8.3292537927627563e-01
    z[1,3,1]  R1068     -5.1259505748748779e-01
    z[1,3,1]  R1069     -6.0324513912200928e-01
    z[1,3,1]  R1070     3.1696164608001709e-01
    z[1,3,1]  R1071     -7.5302451848983765e-01
    z[1,3,1]  R1072     -8.0823796987533569e-01
    z[1,3,1]  R1073     -3.2325261831283569e-01
    z[1,3,1]  R1074     -5.0754940509796143e-01
    z[1,3,1]  R1075     3.8729032874107361e-01
    z[1,3,1]  R1076     -8.6260598897933960e-01
    z[1,3,1]  R1077     6.4150685071945190e-01
    z[1,3,1]  R1078     5.9370237588882446e-01
    z[1,3,1]  R1079     -6.1903841793537140e-02
    z[1,3,1]  R1080     7.4042327702045441e-02
    z[1,3,1]  R1081     6.0816723108291626e-01
    z[1,3,1]  R1082     2.5047263503074646e-01
    z[1,3,1]  R1083     -2.0845349133014679e-01
    z[1,3,1]  R1084     3.9893460273742676e-01
    z[1,3,1]  R1085     3.3393295598216355e-04
    z[1,3,1]  R1086     5.4899090528488159e-01
    z[1,3,1]  R1087     -8.4485612809658051e-02
    z[1,3,1]  R1088     3.0647762119770050e-02
    z[1,3,1]  R1089     3.6442461609840393e-01
    z[1,3,1]  R1090     1.4070263504981995e-01
    z[1,3,1]  R1091     0.718567967414856
    z[1,3,1]  R1092     -1.8699440360069275e-01
    z[1,3,1]  R1093     3.5574089735746384e-02
    z[1,3,1]  R1094     1.3084031641483307e-01
    z[1,3,1]  R1095     -3.3618080615997314e-01
    z[1,3,1]  R1096     -0.850028932094574
    z[1,3,1]  R1097     -6.1846506595611572e-01
    z[1,3,1]  R1098     -3.7172517180442810e-01
    z[1,3,1]  R1099     -5.4303795099258423e-01
    z[1,3,1]  R1100     -6.5986555814743042e-01
    z[1,3,1]  R1101     4.8054805397987366e-01
    z[1,3,1]  R1102     1.3738648593425751e-01
    z[1,3,1]  R1103     2.1112720668315887e-01
    z[1,3,1]  R1104     -9.5226854085922241e-02
    z[1,3,1]  R1105     2.2615295648574829e-01
    z[1,3,1]  R1106     -6.8314230442047119e-01
    z[1,3,1]  R1107     2.7245259284973145e-01
    z[1,3,1]  R1108     -1.2807795405387878e-01
    z[1,3,1]  R1109     1.5993210673332214e-01
    z[1,3,1]  R1110     5.6421858072280884e-01
    z[1,3,1]  R1111     1.5317335724830627e-01
    z[1,3,1]  R1112     7.8978991508483887e-01
    z[1,3,1]  R1113     4.4707828760147095e-01
    z[1,3,1]  R1114     4.8379644751548767e-01
    z[1,3,1]  R1115     4.0550419688224792e-01
    z[1,3,1]  R1116     5.6089580059051514e-01
    z[1,3,1]  R1117     -6.9278383255004883e-01
    z[1,3,1]  R1118     1.0703387856483459e-01
    z[1,3,1]  R1119     9.6009485423564911e-03
    z[1,3,1]  R1120     -7.1844294667243958e-02
    z[1,3,1]  R1121     -9.6338622272014618e-02
    z[1,3,1]  R1122     0.212177112698555
    z[1,3,1]  R1123     -3.5925975441932678e-01
    z[1,3,1]  R1124     2.7371007204055786e-01
    z[1,3,1]  R1125     4.9748173356056213e-01
    z[1,3,1]  R1126     5.3784084320068359e-01
    z[1,3,1]  R1127     4.0997806191444397e-01
    z[1,3,1]  R1128     3.5884803533554077e-01
    z[1,3,1]  R1129     6.3315761089324951e-01
    z[1,3,1]  R1130     6.0678112506866455e-01
    z[1,3,1]  R1131     1.5981715917587280e-01
    z[1,3,1]  R1132     -6.0067433118820190e-01
    z[1,3,1]  R1133     -5.6848269701004028e-01
    z[1,3,1]  R1134     -6.1022669076919556e-01
    z[1,3,1]  R1135     -4.7365039587020874e-01
    z[1,3,1]  R1136     -7.7890610694885254e-01
    z[1,3,1]  R1137     -0.734073281288147
    z[1,3,1]  R1138     -7.1233463287353516e-01
    z[1,3,1]  R1139     -7.4874430894851685e-01
    z[1,3,1]  R1140     -8.8062816858291626e-01
    z[1,3,1]  R1141     -7.2288483381271362e-01
    z[1,3,1]  R1142     -8.5410809516906738e-01
    z[1,3,1]  R1143     -8.4017670154571533e-01
    z[1,3,1]  R1144     -8.2712328433990479e-01
    z[1,3,1]  R1145     -6.3271623849868774e-01
    z[1,3,1]  R1146     -2.8168407082557678e-01
    z[1,3,1]  R1147     4.9736425280570984e-01
    z[1,3,1]  R1148     4.9484935402870178e-01
    z[1,3,1]  R1149     5.2616351842880249e-01
    z[1,3,1]  R1150     4.0387737751007080e-01
    z[1,3,1]  R1151     3.4215039014816284e-01
    z[1,3,1]  R1152     5.1828610897064209e-01
    z[1,3,1]  R1153     3.5125705599784851e-01
    z[1,3,1]  R1154     4.8839551210403442e-01
    z[1,3,1]  R1155     3.7105610966682434e-01
    z[1,3,1]  R1156     3.2518428564071655e-01
    z[1,3,1]  R1157     -1.1943493038415909e-01
    z[1,3,1]  R1158     -4.5852270722389221e-01
    z[1,3,1]  R1159     -4.6201723814010620e-01
    z[1,3,1]  R1160     3.0634099245071411e-01
    z[1,3,1]  R1161     -3.5620772838592529e-01
    z[1,3,1]  R1162     -5.4595535993576050e-01
    z[1,3,1]  R1163     -0.424570769071579
    z[1,3,1]  R1164     -0.507512629032135
    z[1,3,1]  R1165     -5.1523089408874512e-01
    z[1,3,1]  R1166     -1.7358395457267761e-01
    z[1,3,1]  R1167     -6.7534017562866211e-01
    z[1,3,1]  R1168     -5.6824922561645508e-01
    z[1,3,1]  R1169     -7.2195613384246826e-01
    z[1,3,1]  R1170     -2.6490309834480286e-01
    z[1,3,1]  R1171     3.6142560839653015e-01
    z[1,3,1]  R1172     -2.9764235019683838e-01
    z[1,3,1]  R1173     -0.304245263338089
    z[1,3,1]  R1174     -2.3560518398880959e-02
    z[1,3,1]  R1175     3.8852196931838989e-01
    z[1,3,2]  R13       -1
    z[1,3,2]  R31       1
    z[1,3,2]  R1016     -1
    z[1,3,2]  R1017     1
    z[1,3,2]  R1026     0.410097599029541
    z[1,3,2]  R1027     1.9897668063640594e-01
    z[1,3,2]  R1028     3.2608810067176819e-01
    z[1,3,2]  R1029     3.4057784080505371e-01
    z[1,3,2]  R1030     3.6706885695457458e-01
    z[1,3,2]  R1031     2.4889845401048660e-02
    z[1,3,2]  R1032     7.7606640756130219e-02
    z[1,3,2]  R1033     4.7487378120422363e-01
    z[1,3,2]  R1034     2.1392826735973358e-01
    z[1,3,2]  R1035     3.6713370680809021e-01
    z[1,3,2]  R1036     1.0967803001403809e-01
    z[1,3,2]  R1037     -4.1845682263374329e-01
    z[1,3,2]  R1038     -1.2607865035533905e-01
    z[1,3,2]  R1039     -0.486369788646698
    z[1,3,2]  R1040     5.4819411039352417e-01
    z[1,3,2]  R1041     0.567703127861023
    z[1,3,2]  R1042     3.9514392614364624e-02
    z[1,3,2]  R1043     4.5630556344985962e-01
    z[1,3,2]  R1044     -2.2555316984653473e-01
    z[1,3,2]  R1045     3.5645312070846558e-01
    z[1,3,2]  R1046     -4.2175155878067017e-01
    z[1,3,2]  R1047     1.6420675441622734e-02
    z[1,3,2]  R1048     4.6600274741649628e-02
    z[1,3,2]  R1049     -1.8738220632076263e-01
    z[1,3,2]  R1050     1.6186399757862091e-01
    z[1,3,2]  R1051     1.7931106686592102e-01
    z[1,3,2]  R1052     -3.0865499377250671e-01
    z[1,3,2]  R1053     -7.1684408187866211e-01
    z[1,3,2]  R1054     5.0356465578079224e-01
    z[1,3,2]  R1055     -7.8330940008163452e-01
    z[1,3,2]  R1056     4.0173164010047913e-01
    z[1,3,2]  R1057     6.7916172742843628e-01
    z[1,3,2]  R1058     5.6552004814147949e-01
    z[1,3,2]  R1059     6.2351912260055542e-01
    z[1,3,2]  R1060     2.7996173501014709e-01
    z[1,3,2]  R1061     1.4014796912670135e-01
    z[1,3,2]  R1062     2.6978957653045654e-01
    z[1,3,2]  R1063     -1.8271125853061676e-01
    z[1,3,2]  R1064     -3.0887761712074280e-01
    z[1,3,2]  R1065     1.8305076658725739e-01
    z[1,3,2]  R1066     4.6575519442558289e-01
    z[1,3,2]  R1067     4.3002769351005554e-02
    z[1,3,2]  R1068     1.5302455425262451e-01
    z[1,3,2]  R1069     1.3386055361479521e-03
    z[1,3,2]  R1070     1.3925452530384064e-01
    z[1,3,2]  R1071     3.2627224922180176e-01
    z[1,3,2]  R1072     -7.9252235591411591e-02
    z[1,3,2]  R1073     4.8510608077049255e-01
    z[1,3,2]  R1074     -1.7540137469768524e-01
    z[1,3,2]  R1075     -1.7894359305500984e-02
    z[1,3,2]  R1076     -1.7448730766773224e-01
    z[1,3,2]  R1077     1.3207750022411346e-01
    z[1,3,2]  R1078     -3.6221626400947571e-01
    z[1,3,2]  R1079     1.9669516384601593e-01
    z[1,3,2]  R1080     4.0278702974319458e-01
    z[1,3,2]  R1081     -2.0718200504779816e-01
    z[1,3,2]  R1082     -3.5573190450668335e-01
    z[1,3,2]  R1083     -6.5912526845932007e-01
    z[1,3,2]  R1084     1.1744274944067001e-01
    z[1,3,2]  R1085     -7.6905059814453125e-01
    z[1,3,2]  R1086     -9.8168686032295227e-02
    z[1,3,2]  R1087     9.7359839128330350e-04
    z[1,3,2]  R1088     -1.1752710491418839e-01
    z[1,3,2]  R1089     1.9486773014068604e-01
    z[1,3,2]  R1090     -5.7592725753784180e-01
    z[1,3,2]  R1091     -0.561223030090332
    z[1,3,2]  R1092     -5.7908612489700317e-01
    z[1,3,2]  R1093     -2.6552328467369080e-01
    z[1,3,2]  R1094     -6.9777297973632812e-01
    z[1,3,2]  R1095     -7.7856051921844482e-01
    z[1,3,2]  R1096     -9.9403075873851776e-02
    z[1,3,2]  R1097     3.4059146046638489e-01
    z[1,3,2]  R1098     1.4632999897003174e-01
    z[1,3,2]  R1099     3.2667240500450134e-01
    z[1,3,2]  R1100     1.5998254716396332e-01
    z[1,3,2]  R1101     -2.1347789466381073e-01
    z[1,3,2]  R1102     2.0259141921997070e-01
    z[1,3,2]  R1103     -4.5913219451904297e-01
    z[1,3,2]  R1104     -5.9972470998764038e-01
    z[1,3,2]  R1105     -6.4753305912017822e-01
    z[1,3,2]  R1106     -3.3333367109298706e-01
    z[1,3,2]  R1107     3.7514597177505493e-01
    z[1,3,2]  R1108     -2.6433351635932922e-01
    z[1,3,2]  R1109     -7.7267253398895264e-01
    z[1,3,2]  R1110     -1.0950347036123276e-01
    z[1,3,2]  R1111     4.1314274072647095e-01
    z[1,3,2]  R1112     -2.7503243088722229e-01
    z[1,3,2]  R1113     -1.9831565022468567e-01
    z[1,3,2]  R1114     -8.4968388080596924e-02
    z[1,3,2]  R1115     -1.5004470944404602e-01
    z[1,3,2]  R1116     -0.174790620803833
    z[1,3,2]  R1117     3.1620880961418152e-01
    z[1,3,2]  R1118     -6.8193428218364716e-02
    z[1,3,2]  R1119     -6.0812151432037354e-01
    z[1,3,2]  R1120     -7.1764141321182251e-01
    z[1,3,2]  R1121     -8.1184077262878418e-01
    z[1,3,2]  R1122     -1.2061801552772522e-01
    z[1,3,2]  R1123     1.9096738100051880e-01
    z[1,3,2]  R1124     -2.4020045995712280e-01
    z[1,3,2]  R1125     -3.7953026592731476e-02
    z[1,3,2]  R1126     -3.1495407223701477e-01
    z[1,3,2]  R1127     -2.7223592996597290e-01
    z[1,3,2]  R1128     1.9476598501205444e-01
    z[1,3,2]  R1129     -3.0419480800628662e-01
    z[1,3,2]  R1130     4.5412972569465637e-02
    z[1,3,2]  R1131     -4.4046494364738464e-01
    z[1,3,2]  R1132     5.1188701391220093e-01
    z[1,3,2]  R1133     6.8993842601776123e-01
    z[1,3,2]  R1134     5.3733807802200317e-01
    z[1,3,2]  R1135     7.7381551265716553e-01
    z[1,3,2]  R1136     -1.6695824265480042e-01
    z[1,3,2]  R1137     -1.0524638742208481e-01
    z[1,3,2]  R1138     -2.3312093317508698e-01
    z[1,3,2]  R1139     -9.8969843238592148e-03
    z[1,3,2]  R1140     -3.2058599591255188e-01
    z[1,3,2]  R1141     -7.9349176958203316e-03
    z[1,3,2]  R1142     -1.4685305953025818e-01
    z[1,3,2]  R1143     -2.5821053981781006e-01
    z[1,3,2]  R1144     -4.5450992882251740e-02
    z[1,3,2]  R1145     3.5034954547882080e-01
    z[1,3,2]  R1146     -1.6533946618437767e-02
    z[1,3,2]  R1147     -1.4327681064605713e-01
    z[1,3,2]  R1148     -1.1226122081279755e-01
    z[1,3,2]  R1149     -1.1739084869623184e-01
    z[1,3,2]  R1150     1.3021047413349152e-01
    z[1,3,2]  R1151     -6.5592072904109955e-02
    z[1,3,2]  R1152     1.4451918005943298e-01
    z[1,3,2]  R1153     2.1304875612258911e-01
    z[1,3,2]  R1154     1.1093472689390182e-01
    z[1,3,2]  R1155     -6.2649093568325043e-02
    z[1,3,2]  R1156     0.0575115866959095
    z[1,3,2]  R1157     2.1006904542446136e-01
    z[1,3,2]  R1158     -2.1441720426082611e-01
    z[1,3,2]  R1159     -2.3992931842803955e-01
    z[1,3,2]  R1160     3.1207486987113953e-01
    z[1,3,2]  R1161     3.0928462743759155e-02
    z[1,3,2]  R1162     -0.0356932133436203
    z[1,3,2]  R1163     -1.3485740125179291e-01
    z[1,3,2]  R1164     -1.8079439178109169e-02
    z[1,3,2]  R1165     -2.6221296191215515e-01
    z[1,3,2]  R1166     -2.2966243326663971e-01
    z[1,3,2]  R1167     -7.7399136498570442e-03
    z[1,3,2]  R1168     2.4974639713764191e-01
    z[1,3,2]  R1169     -6.7057803273200989e-02
    z[1,3,2]  R1170     1.5775233507156372e-01
    z[1,3,2]  R1171     -8.3998069167137146e-03
    z[1,3,2]  R1172     -2.7235758304595947e-01
    z[1,3,2]  R1173     -9.1737903654575348e-02
    z[1,3,2]  R1174     5.3540718555450439e-01
    z[1,3,2]  R1175     0.501573920249939
    z[1,3,3]  R14       -1
    z[1,3,3]  R32       1
    z[1,3,3]  R1018     -1
    z[1,3,3]  R1019     1
    z[1,3,3]  R1026     -1.8432404100894928e-01
    z[1,3,3]  R1027     -5.1463800668716431e-01
    z[1,3,3]  R1028     -6.4134937524795532e-01
    z[1,3,3]  R1029     -4.0266942977905273e-01
    z[1,3,3]  R1030     -4.4890768826007843e-02
    z[1,3,3]  R1031     -4.6394917368888855e-01
    z[1,3,3]  R1032     -3.5040271282196045e-01
    z[1,3,3]  R1033     -8.3797693252563477e-02
    z[1,3,3]  R1034     -2.0538680255413055e-03
    z[1,3,3]  R1035     -3.6634132266044617e-01
    z[1,3,3]  R1036     2.8865441679954529e-01
    z[1,3,3]  R1037     3.6795396357774734e-02
    z[1,3,3]  R1038     -1.4961647987365723e-01
    z[1,3,3]  R1039     1.3712696731090546e-01
    z[1,3,3]  R1040     6.4623266458511353e-02
    z[1,3,3]  R1041     -9.1978013515472412e-02
    z[1,3,3]  R1042     5.1226603984832764e-01
    z[1,3,3]  R1043     -3.9801809191703796e-01
    z[1,3,3]  R1044     -6.0857552289962769e-01
    z[1,3,3]  R1045     -5.7703101634979248e-01
    z[1,3,3]  R1046     2.6602050662040710e-01
    z[1,3,3]  R1047     1.8930549919605255e-01
    z[1,3,3]  R1048     6.5145730972290039e-01
    z[1,3,3]  R1049     4.7060206532478333e-01
    z[1,3,3]  R1050     4.4231966137886047e-01
    z[1,3,3]  R1051     3.7852790951728821e-01
    z[1,3,3]  R1052     2.2586712241172791e-01
    z[1,3,3]  R1053     4.2727984488010406e-02
    z[1,3,3]  R1054     5.4297196865081787e-01
    z[1,3,3]  R1055     1.6417096555233002e-01
    z[1,3,3]  R1056     -4.0744277834892273e-01
    z[1,3,3]  R1057     -4.2608398199081421e-01
    z[1,3,3]  R1058     1.6876373440027237e-02
    z[1,3,3]  R1059     -5.5595141649246216e-01
    z[1,3,3]  R1060     0.510107696056366
    z[1,3,3]  R1061     2.4046397209167480e-01
    z[1,3,3]  R1062     -3.1315666437149048e-01
    z[1,3,3]  R1063     2.9579216241836548e-01
    z[1,3,3]  R1064     3.9032116532325745e-01
    z[1,3,3]  R1065     -7.2604638338088989e-01
    z[1,3,3]  R1066     -1.0772946476936340e-01
    z[1,3,3]  R1067     -7.8980810940265656e-02
    z[1,3,3]  R1068     1.8345648050308228e-01
    z[1,3,3]  R1069     3.1382623314857483e-01
    z[1,3,3]  R1070     1.4028945565223694e-01
    z[1,3,3]  R1071     -4.3615886569023132e-01
    z[1,3,3]  R1072     -4.3881252408027649e-01
    z[1,3,3]  R1073     1.0959044843912125e-01
    z[1,3,3]  R1074     4.7214669175446033e-03
    z[1,3,3]  R1075     -1.2928792834281921e-01
    z[1,3,3]  R1076     -1.7415136098861694e-01
    z[1,3,3]  R1077     7.4559003114700317e-02
    z[1,3,3]  R1078     -1.0413333028554916e-01
    z[1,3,3]  R1079     1.8462552130222321e-01
    z[1,3,3]  R1080     0.713071882724762
    z[1,3,3]  R1081     4.2764917016029358e-01
    z[1,3,3]  R1082     6.1980700492858887e-01
    z[1,3,3]  R1083     3.4250319004058838e-01
    z[1,3,3]  R1084     0.574138879776001
    z[1,3,3]  R1085     3.9793962240219116e-01
    z[1,3,3]  R1086     -6.0092996805906296e-02
    z[1,3,3]  R1087     0.777245819568634
    z[1,3,3]  R1088     4.5326781272888184e-01
    z[1,3,3]  R1089     2.7885380387306213e-01
    z[1,3,3]  R1090     3.5766753554344177e-01
    z[1,3,3]  R1091     3.2030284404754639e-01
    z[1,3,3]  R1092     3.1763064861297607e-01
    z[1,3,3]  R1093     3.8000747561454773e-01
    z[1,3,3]  R1094     1.2909834086894989e-01
    z[1,3,3]  R1095     -2.4669134616851807e-01
    z[1,3,3]  R1096     -2.9174787923693657e-03
    z[1,3,3]  R1097     -2.8880032896995544e-01
    z[1,3,3]  R1098     4.0354898571968079e-01
    z[1,3,3]  R1099     1.3501471281051636e-01
    z[1,3,3]  R1100     -4.7309798002243042e-01
    z[1,3,3]  R1101     -2.9963061213493347e-01
    z[1,3,3]  R1102     5.4995840787887573e-01
    z[1,3,3]  R1103     4.1433700919151306e-01
    z[1,3,3]  R1104     4.0481972694396973e-01
    z[1,3,3]  R1105     3.9746868610382080e-01
    z[1,3,3]  R1106     -2.1642296016216278e-01
    z[1,3,3]  R1107     6.3129258155822754e-01
    z[1,3,3]  R1108     4.3214264512062073e-01
    z[1,3,3]  R1109     3.4522926807403564e-01
    z[1,3,3]  R1110     4.1966402530670166e-01
    z[1,3,3]  R1111     3.2063734531402588e-01
    z[1,3,3]  R1112     -1.9523462653160095e-01
    z[1,3,3]  R1113     -5.5567425489425659e-01
    z[1,3,3]  R1114     -4.6835356950759888e-01
    z[1,3,3]  R1115     -4.9415045976638794e-01
    z[1,3,3]  R1116     -1.4836981892585754e-01
    z[1,3,3]  R1117     2.6959040760993958e-01
    z[1,3,3]  R1118     5.1917874813079834e-01
    z[1,3,3]  R1119     4.2698773741722107e-01
    z[1,3,3]  R1120     3.9615362882614136e-01
    z[1,3,3]  R1121     2.7314865589141846e-01
    z[1,3,3]  R1122     2.4443480372428894e-01
    z[1,3,3]  R1123     3.0787822604179382e-01
    z[1,3,3]  R1124     -5.2298015356063843e-01
    z[1,3,3]  R1125     -2.9256063699722290e-01
    z[1,3,3]  R1126     3.4320011734962463e-01
    z[1,3,3]  R1127     3.5711315274238586e-01
    z[1,3,3]  R1128     6.5942478179931641e-01
    z[1,3,3]  R1129     5.9538805484771729e-01
    z[1,3,3]  R1130     3.4576657414436340e-01
    z[1,3,3]  R1131     7.0035117864608765e-01
    z[1,3,3]  R1132     -0.530301034450531
    z[1,3,3]  R1133     -2.6191276311874390e-01
    z[1,3,3]  R1134     -3.3637505024671555e-02
    z[1,3,3]  R1135     -3.3186116814613342e-01
    z[1,3,3]  R1136     -7.4687272310256958e-02
    z[1,3,3]  R1137     1.0632331669330597e-01
    z[1,3,3]  R1138     2.7038154006004333e-01
    z[1,3,3]  R1139     1.2183093279600143e-01
    z[1,3,3]  R1140     3.7542287260293961e-02
    z[1,3,3]  R1141     1.1555763334035873e-01
    z[1,3,3]  R1142     2.9953292012214661e-01
    z[1,3,3]  R1143     4.1325652599334717e-01
    z[1,3,3]  R1144     2.7058649063110352e-01
    z[1,3,3]  R1145     -4.5007247477769852e-02
    z[1,3,3]  R1146     3.1242930889129639e-01
    z[1,3,3]  R1147     -0.39503213763237
    z[1,3,3]  R1148     -5.6164044141769409e-01
    z[1,3,3]  R1149     -5.4107069969177246e-01
    z[1,3,3]  R1150     -6.1921846866607666e-01
    z[1,3,3]  R1151     -5.1277482509613037e-01
    z[1,3,3]  R1152     -4.6367436647415161e-01
    z[1,3,3]  R1153     -4.8262152075767517e-01
    z[1,3,3]  R1154     -6.2656527757644653e-01
    z[1,3,3]  R1155     -4.8673585057258606e-01
    z[1,3,3]  R1156     7.2669649124145508e-01
    z[1,3,3]  R1157     0.762295126914978
    z[1,3,3]  R1158     -5.7686185836791992e-01
    z[1,3,3]  R1159     -5.2052670717239380e-01
    z[1,3,3]  R1160     -3.6024487018585205e-01
    z[1,3,3]  R1161     -4.5294648408889771e-01
    z[1,3,3]  R1162     -4.4176250696182251e-01
    z[1,3,3]  R1163     -1.0698555409908295e-01
    z[1,3,3]  R1164     -2.1624748408794403e-01
    z[1,3,3]  R1165     -1.4532610774040222e-01
    z[1,3,3]  R1166     8.5010147094726562e-01
    z[1,3,3]  R1167     -5.5896854400634766e-01
    z[1,3,3]  R1168     -5.5401455610990524e-02
    z[1,3,3]  R1169     -2.5027725100517273e-01
    z[1,3,3]  R1170     -3.6608001589775085e-01
    z[1,3,3]  R1171     -2.4820853024721146e-02
    z[1,3,3]  R1172     -5.3497594594955444e-01
    z[1,3,3]  R1173     -4.3160125613212585e-01
    z[1,3,3]  R1174     -2.8032356500625610e-01
    z[1,3,3]  R1175     3.5390022397041321e-01
    z[1,3,4]  R15       -1
    z[1,3,4]  R33       1
    z[1,3,4]  R1020     -1
    z[1,3,4]  R1021     1
    z[1,3,4]  R1026     1.3935865461826324e-01
    z[1,3,4]  R1027     -3.3856093883514404e-02
    z[1,3,4]  R1028     2.6250863075256348e-01
    z[1,3,4]  R1029     2.3572713136672974e-02
    z[1,3,4]  R1030     3.6814704537391663e-01
    z[1,3,4]  R1031     1.7465278506278992e-01
    z[1,3,4]  R1032     3.3341392874717712e-01
    z[1,3,4]  R1033     -7.4151274748146534e-04
    z[1,3,4]  R1034     2.8366908431053162e-01
    z[1,3,4]  R1035     5.4026669263839722e-01
    z[1,3,4]  R1036     -2.5515180826187134e-01
    z[1,3,4]  R1037     -2.7427467703819275e-01
    z[1,3,4]  R1038     -4.2240446805953979e-01
    z[1,3,4]  R1039     2.7976479381322861e-02
    z[1,3,4]  R1040     -1.7387789487838745e-01
    z[1,3,4]  R1041     -4.3352580070495605e-01
    z[1,3,4]  R1042     4.0010169148445129e-01
    z[1,3,4]  R1043     6.9646663963794708e-02
    z[1,3,4]  R1044     -5.0047025084495544e-02
    z[1,3,4]  R1045     -4.9046209454536438e-01
    z[1,3,4]  R1046     -3.5990697145462036e-01
    z[1,3,4]  R1047     9.0682750940322876e-01
    z[1,3,4]  R1048     6.9490909576416016e-01
    z[1,3,4]  R1049     7.9154515266418457e-01
    z[1,3,4]  R1050     7.2009402513504028e-01
    z[1,3,4]  R1051     7.0644110441207886e-01
    z[1,3,4]  R1052     8.1561535596847534e-01
    z[1,3,4]  R1053     -7.3069550096988678e-02
    z[1,3,4]  R1054     4.5287674665451050e-01
    z[1,3,4]  R1055     1.2962979078292847e-01
    z[1,3,4]  R1056     7.9473212361335754e-02
    z[1,3,4]  R1057     -1.3623583316802979e-01
    z[1,3,4]  R1058     2.1712502837181091e-01
    z[1,3,4]  R1059     8.6590774357318878e-02
    z[1,3,4]  R1060     7.9303735494613647e-01
    z[1,3,4]  R1061     -1.8995349109172821e-01
    z[1,3,4]  R1062     4.6238112449645996e-01
    z[1,3,4]  R1063     7.1789878606796265e-01
    z[1,3,4]  R1064     4.2612543702125549e-01
    z[1,3,4]  R1065     -2.2465731203556061e-01
    z[1,3,4]  R1066     1.1231165379285812e-01
    z[1,3,4]  R1067     4.8143625259399414e-01
    z[1,3,4]  R1068     3.1954690814018250e-01
    z[1,3,4]  R1069     3.2098862528800964e-01
    z[1,3,4]  R1070     -4.3746823072433472e-01
    z[1,3,4]  R1071     -1.7073710262775421e-01
    z[1,3,4]  R1072     -2.0819954574108124e-02
    z[1,3,4]  R1073     -0.0989551842212677
    z[1,3,4]  R1074     2.5268995761871338e-01
    z[1,3,4]  R1075     1.5949079394340515e-01
    z[1,3,4]  R1076     0.136853888630867
    z[1,3,4]  R1077     1.7795832455158234e-01
    z[1,3,4]  R1078     -1.3361354172229767e-01
    z[1,3,4]  R1079     8.3230429887771606e-01
    z[1,3,4]  R1080     4.1093739867210388e-01
    z[1,3,4]  R1081     5.3052127361297607e-01
    z[1,3,4]  R1082     5.1477003097534180e-01
    z[1,3,4]  R1083     5.0155729055404663e-01
    z[1,3,4]  R1084     2.9172223806381226e-01
    z[1,3,4]  R1085     4.8056846857070923e-01
    z[1,3,4]  R1086     2.6530984044075012e-01
    z[1,3,4]  R1087     5.4606622457504272e-01
    z[1,3,4]  R1088     7.8615558147430420e-01
    z[1,3,4]  R1089     6.2929922342300415e-01
    z[1,3,4]  R1090     2.6644504070281982e-01
    z[1,3,4]  R1091     -3.8745053112506866e-02
    z[1,3,4]  R1092     2.0344233512878418e-01
    z[1,3,4]  R1093     1.7360401153564453e-01
    z[1,3,4]  R1094     5.9470452368259430e-02
    z[1,3,4]  R1095     2.6736825704574585e-02
    z[1,3,4]  R1096     3.3870872855186462e-01
    z[1,3,4]  R1097     5.5658571422100067e-02
    z[1,3,4]  R1098     -7.8829256817698479e-03
    z[1,3,4]  R1099     7.8902617096900940e-02
    z[1,3,4]  R1100     1.1656423658132553e-01
    z[1,3,4]  R1101     2.7199275791645050e-02
    z[1,3,4]  R1102     4.8117798566818237e-01
    z[1,3,4]  R1103     3.0255025625228882e-01
    z[1,3,4]  R1104     3.3595968037843704e-02
    z[1,3,4]  R1105     1.6369393467903137e-01
    z[1,3,4]  R1106     -2.9842811822891235e-01
    z[1,3,4]  R1107     5.3670382499694824e-01
    z[1,3,4]  R1108     4.7548791766166687e-01
    z[1,3,4]  R1109     2.9210817813873291e-01
    z[1,3,4]  R1110     4.8938098549842834e-01
    z[1,3,4]  R1111     3.6667466163635254e-01
    z[1,3,4]  R1112     -3.0993974208831787e-01
    z[1,3,4]  R1113     -2.1801907569169998e-02
    z[1,3,4]  R1114     -6.2543079257011414e-02
    z[1,3,4]  R1115     -2.3602099716663361e-01
    z[1,3,4]  R1116     8.2893833518028259e-02
    z[1,3,4]  R1117     2.8686946630477905e-01
    z[1,3,4]  R1118     7.8496611118316650e-01
    z[1,3,4]  R1119     1.9304936751723289e-02
    z[1,3,4]  R1120     0.449378103017807
    z[1,3,4]  R1121     -3.3246347308158875e-01
    z[1,3,4]  R1122     -1.7195332795381546e-02
    z[1,3,4]  R1123     2.4461318552494049e-01
    z[1,3,4]  R1124     1.0814021341502666e-02
    z[1,3,4]  R1125     1.1211378872394562e-01
    z[1,3,4]  R1126     1.5212135016918182e-01
    z[1,3,4]  R1127     6.0544836521148682e-01
    z[1,3,4]  R1128     1.1388329416513443e-01
    z[1,3,4]  R1129     -2.4923862516880035e-01
    z[1,3,4]  R1130     -4.1099062561988831e-01
    z[1,3,4]  R1131     7.6116546988487244e-02
    z[1,3,4]  R1132     -1.4724639058113098e-01
    z[1,3,4]  R1133     -1.4814375340938568e-01
    z[1,3,4]  R1134     1.4779733121395111e-01
    z[1,3,4]  R1135     -1.4857585728168488e-01
    z[1,3,4]  R1136     -1.5054804086685181e-01
    z[1,3,4]  R1137     -2.9473719000816345e-01
    z[1,3,4]  R1138     -0.156258225440979
    z[1,3,4]  R1139     2.5375029444694519e-01
    z[1,3,4]  R1140     -2.8916954994201660e-01
    z[1,3,4]  R1141     1.9727160036563873e-01
    z[1,3,4]  R1142     1.4298303425312042e-01
    z[1,3,4]  R1143     1.8206825852394104e-01
    z[1,3,4]  R1144     2.2723200917243958e-01
    z[1,3,4]  R1145     4.6563889831304550e-02
    z[1,3,4]  R1146     -1.5930096805095673e-01
    z[1,3,4]  R1147     -2.0812867581844330e-01
    z[1,3,4]  R1148     -2.5409471988677979e-01
    z[1,3,4]  R1149     -3.5411116480827332e-01
    z[1,3,4]  R1150     -2.4435031414031982e-01
    z[1,3,4]  R1151     -1.3521975278854370e-01
    z[1,3,4]  R1152     2.3473742604255676e-01
    z[1,3,4]  R1153     1.3703167438507080e-01
    z[1,3,4]  R1154     1.8078124523162842e-01
    z[1,3,4]  R1155     3.0565834045410156e-01
    z[1,3,4]  R1156     -0.0800301805138588
    z[1,3,4]  R1157     1.5295787155628204e-01
    z[1,3,4]  R1158     1.1559443175792694e-01
    z[1,3,4]  R1159     6.0622924566268921e-01
    z[1,3,4]  R1160     0.179230198264122
    z[1,3,4]  R1161     -1.0031496174633503e-02
    z[1,3,4]  R1162     3.5202977061271667e-01
    z[1,3,4]  R1163     -2.7851012349128723e-01
    z[1,3,4]  R1164     -1.1431746929883957e-01
    z[1,3,4]  R1165     1.8334053456783295e-02
    z[1,3,4]  R1166     1.1465849727392197e-01
    z[1,3,4]  R1167     -1.5079215168952942e-01
    z[1,3,4]  R1168     1.2787835299968719e-01
    z[1,3,4]  R1169     1.1395392566919327e-01
    z[1,3,4]  R1170     -1.2181679904460907e-01
    z[1,3,4]  R1171     2.8046944737434387e-01
    z[1,3,4]  R1172     -5.1584386825561523e-01
    z[1,3,4]  R1173     -6.2819540500640869e-01
    z[1,3,4]  R1174     7.1900326013565063e-01
    z[1,3,4]  R1175     1.1113435961306095e-02
    z[1,3,5]  R16       -1
    z[1,3,5]  R34       1
    z[1,3,5]  R1022     -1
    z[1,3,5]  R1023     1
    z[1,3,5]  R1026     -7.4647432565689087e-01
    z[1,3,5]  R1027     -6.3916242122650146e-01
    z[1,3,5]  R1028     -5.0884467363357544e-01
    z[1,3,5]  R1029     -7.2125869989395142e-01
    z[1,3,5]  R1030     -7.8055894374847412e-01
    z[1,3,5]  R1031     -6.7628163099288940e-01
    z[1,3,5]  R1032     -7.5406205654144287e-01
    z[1,3,5]  R1033     -5.4106724262237549e-01
    z[1,3,5]  R1034     -7.7640181779861450e-01
    z[1,3,5]  R1035     -3.3120352029800415e-01
    z[1,3,5]  R1036     -1.7839916050434113e-01
    z[1,3,5]  R1037     3.4148350358009338e-02
    z[1,3,5]  R1038     1.8258308991789818e-02
    z[1,3,5]  R1039     -1.8633460998535156e-01
    z[1,3,5]  R1040     -1.9224444031715393e-01
    z[1,3,5]  R1041     1.1763998866081238e-01
    z[1,3,5]  R1042     2.6581385731697083e-01
    z[1,3,5]  R1043     -3.4957072138786316e-01
    z[1,3,5]  R1044     9.1608978807926178e-02
    z[1,3,5]  R1045     4.0881808847188950e-02
    z[1,3,5]  R1046     2.3601700365543365e-01
    z[1,3,5]  R1047     1.3677023351192474e-01
    z[1,3,5]  R1048     7.3405399918556213e-02
    z[1,3,5]  R1049     1.0969126969575882e-01
    z[1,3,5]  R1050     9.2714056372642517e-02
    z[1,3,5]  R1051     1.4815928041934967e-01
    z[1,3,5]  R1052     2.1618127822875977e-01
    z[1,3,5]  R1053     8.9850440621376038e-02
    z[1,3,5]  R1054     3.2188418507575989e-01
    z[1,3,5]  R1055     1.1667750775814056e-02
    z[1,3,5]  R1056     3.9937481284141541e-01
    z[1,3,5]  R1057     -8.7309010326862335e-02
    z[1,3,5]  R1058     2.4414394795894623e-01
    z[1,3,5]  R1059     2.3820179700851440e-01
    z[1,3,5]  R1060     1.0241446644067764e-01
    z[1,3,5]  R1061     4.2090556025505066e-01
    z[1,3,5]  R1062     -6.4658693969249725e-02
    z[1,3,5]  R1063     -1.1355581879615784e-01
    z[1,3,5]  R1064     1.5739759802818298e-01
    z[1,3,5]  R1065     2.3948132991790771e-01
    z[1,3,5]  R1066     2.2364287078380585e-01
    z[1,3,5]  R1067     1.7969799041748047e-01
    z[1,3,5]  R1068     -3.2613289356231689e-01
    z[1,3,5]  R1069     4.9317643046379089e-01
    z[1,3,5]  R1070     3.1518206000328064e-01
    z[1,3,5]  R1071     -3.0196252465248108e-01
    z[1,3,5]  R1072     2.6776146888732910e-01
    z[1,3,5]  R1073     3.0875065922737122e-01
    z[1,3,5]  R1074     1.9810175895690918e-01
    z[1,3,5]  R1075     4.8662075400352478e-01
    z[1,3,5]  R1076     1.3925476372241974e-01
    z[1,3,5]  R1077     4.4187238812446594e-01
    z[1,3,5]  R1078     3.6108088493347168e-01
    z[1,3,5]  R1079     4.4546341896057129e-01
    z[1,3,5]  R1080     1.2333232164382935e-01
    z[1,3,5]  R1081     -1.0340360924601555e-02
    z[1,3,5]  R1082     2.5306472182273865e-01
    z[1,3,5]  R1083     3.0567046254873276e-02
    z[1,3,5]  R1084     1.1456538736820221e-01
    z[1,3,5]  R1085     4.9303401261568069e-02
    z[1,3,5]  R1086     4.6101510524749756e-01
    z[1,3,5]  R1087     3.7257452495396137e-03
    z[1,3,5]  R1088     1.2055249512195587e-01
    z[1,3,5]  R1089     1.0165440291166306e-01
    z[1,3,5]  R1090     -3.0589890480041504e-01
    z[1,3,5]  R1091     -1.5219344198703766e-01
    z[1,3,5]  R1092     -8.9321933686733246e-02
    z[1,3,5]  R1093     -6.7859692499041557e-03
    z[1,3,5]  R1094     -1.3576747849583626e-02
    z[1,3,5]  R1095     1.4903441071510315e-01
    z[1,3,5]  R1096     -0.248980313539505
    z[1,3,5]  R1097     -0.105091892182827
    z[1,3,5]  R1098     4.3572276830673218e-01
    z[1,3,5]  R1099     -5.9681254625320435e-01
    z[1,3,5]  R1100     -4.2099773883819580e-01
    z[1,3,5]  R1101     4.4694775342941284e-01
    z[1,3,5]  R1102     2.5101962685585022e-01
    z[1,3,5]  R1103     -1.2519478797912598e-01
    z[1,3,5]  R1104     -2.3776248097419739e-01
    z[1,3,5]  R1105     -8.8280171155929565e-02
    z[1,3,5]  R1106     -1.3381315767765045e-01
    z[1,3,5]  R1107     2.9748940467834473e-01
    z[1,3,5]  R1108     4.6417381614446640e-02
    z[1,3,5]  R1109     -8.5791319608688354e-02
    z[1,3,5]  R1110     -1.8986134231090546e-01
    z[1,3,5]  R1111     1.2778806686401367e-01
    z[1,3,5]  R1112     0.00913998018950224
    z[1,3,5]  R1113     1.4865861833095551e-01
    z[1,3,5]  R1114     -2.4004525039345026e-03
    z[1,3,5]  R1115     -2.4128738045692444e-01
    z[1,3,5]  R1116     0.412727415561676
    z[1,3,5]  R1117     2.9499068856239319e-01
    z[1,3,5]  R1118     2.1359564363956451e-01
    z[1,3,5]  R1119     -1.1896307766437531e-01
    z[1,3,5]  R1120     2.3534636944532394e-02
    z[1,3,5]  R1121     -1.2104593962430954e-01
    z[1,3,5]  R1122     6.8074040114879608e-02
    z[1,3,5]  R1123     1.6482903063297272e-01
    z[1,3,5]  R1124     -8.3766825497150421e-02
    z[1,3,5]  R1125     -2.2390339523553848e-02
    z[1,3,5]  R1126     3.2471993565559387e-01
    z[1,3,5]  R1127     1.3615280389785767e-01
    z[1,3,5]  R1128     -2.1183695644140244e-02
    z[1,3,5]  R1129     1.8469187617301941e-01
    z[1,3,5]  R1130     2.7607583999633789e-01
    z[1,3,5]  R1131     4.6119844913482666e-01
    z[1,3,5]  R1132     1.7270718514919281e-01
    z[1,3,5]  R1133     2.6913151144981384e-01
    z[1,3,5]  R1134     -3.3632940053939819e-01
    z[1,3,5]  R1135     -6.1255201697349548e-02
    z[1,3,5]  R1136     -1.2070265598595142e-02
    z[1,3,5]  R1137     -1.5667583048343658e-01
    z[1,3,5]  R1138     -1.0563275776803493e-02
    z[1,3,5]  R1139     2.7180045843124390e-01
    z[1,3,5]  R1140     -1.4757966622710228e-02
    z[1,3,5]  R1141     -3.0287897586822510e-01
    z[1,3,5]  R1142     1.5523275732994080e-01
    z[1,3,5]  R1143     -1.2730531394481659e-01
    z[1,3,5]  R1144     -2.3361420631408691e-01
    z[1,3,5]  R1145     -5.3906790912151337e-02
    z[1,3,5]  R1146     0.88450688123703
    z[1,3,5]  R1147     -2.3509602248668671e-01
    z[1,3,5]  R1148     6.0226183384656906e-02
    z[1,3,5]  R1149     -5.1337979733943939e-02
    z[1,3,5]  R1150     -1.9504806399345398e-01
    z[1,3,5]  R1151     -4.8167926073074341e-01
    z[1,3,5]  R1152     -3.6643886566162109e-01
    z[1,3,5]  R1153     -0.439810574054718
    z[1,3,5]  R1154     -0.342242568731308
    z[1,3,5]  R1155     -2.5903207063674927e-01
    z[1,3,5]  R1156     5.7846188545227051e-01
    z[1,3,5]  R1157     4.4787231087684631e-01
    z[1,3,5]  R1158     -3.3854490518569946e-01
    z[1,3,5]  R1159     -1.1588786542415619e-01
    z[1,3,5]  R1160     3.4957417845726013e-01
    z[1,3,5]  R1161     -2.5847530364990234e-01
    z[1,3,5]  R1162     1.7605029046535492e-01
    z[1,3,5]  R1163     1.0050392150878906e-01
    z[1,3,5]  R1164     -5.0245508551597595e-02
    z[1,3,5]  R1165     9.4093777239322662e-02
    z[1,3,5]  R1166     -4.1067236661911011e-01
    z[1,3,5]  R1167     -4.5013588666915894e-01
    z[1,3,5]  R1168     3.2189333438873291e-01
    z[1,3,5]  R1169     2.5142475962638855e-01
    z[1,3,5]  R1170     -0.837743878364563
    z[1,3,5]  R1171     2.1290406584739685e-01
    z[1,3,5]  R1172     2.7396622300148010e-01
    z[1,3,5]  R1173     3.4762862324714661e-01
    z[1,3,5]  R1174     1.4043180644512177e-01
    z[1,3,5]  R1175     -3.5550388693809509e-01
    z[1,3,6]  R17       -1
    z[1,3,6]  R35       1
    z[1,3,6]  R1024     -1
    z[1,3,6]  R1025     1
    z[1,3,6]  R1026     1.5904265642166138e-01
    z[1,3,6]  R1027     0.271445095539093
    z[1,3,6]  R1028     -1.3883425295352936e-01
    z[1,3,6]  R1029     2.8788670897483826e-01
    z[1,3,6]  R1030     9.2242740094661713e-02
    z[1,3,6]  R1031     -1.1773692071437836e-01
    z[1,3,6]  R1032     -0.304904043674469
    z[1,3,6]  R1033     -3.5347026586532593e-01
    z[1,3,6]  R1034     -3.7749823927879333e-01
    z[1,3,6]  R1035     1.2803323566913605e-01
    z[1,3,6]  R1036     2.3802106082439423e-01
    z[1,3,6]  R1037     2.0687267184257507e-01
    z[1,3,6]  R1038     -1.9543178379535675e-01
    z[1,3,6]  R1039     -5.0599705427885056e-02
    z[1,3,6]  R1040     -2.8501942753791809e-01
    z[1,3,6]  R1041     -4.4072084128856659e-02
    z[1,3,6]  R1042     3.5985404253005981e-01
    z[1,3,6]  R1043     -2.4825769662857056e-01
    z[1,3,6]  R1044     -4.9248144030570984e-01
    z[1,3,6]  R1045     -2.6498025655746460e-01
    z[1,3,6]  R1046     1.8578261137008667e-01
    z[1,3,6]  R1047     -0.0825931504368782
    z[1,3,6]  R1048     9.1572798788547516e-02
    z[1,3,6]  R1049     3.6711718887090683e-02
    z[1,3,6]  R1050     2.3696108162403107e-01
    z[1,3,6]  R1051     4.5238483697175980e-02
    z[1,3,6]  R1052     -3.4410390257835388e-01
    z[1,3,6]  R1053     -0.0334925651550293
    z[1,3,6]  R1054     -4.7413217835128307e-03
    z[1,3,6]  R1055     -1.4855190180242062e-02
    z[1,3,6]  R1056     -1.7784331738948822e-01
    z[1,3,6]  R1057     1.5596219897270203e-01
    z[1,3,6]  R1058     -2.1742123365402222e-01
    z[1,3,6]  R1059     -3.1197572126984596e-02
    z[1,3,6]  R1060     -9.3162119388580322e-02
    z[1,3,6]  R1061     1.5060979127883911e-01
    z[1,3,6]  R1062     -3.0172318220138550e-02
    z[1,3,6]  R1063     1.1491342447698116e-02
    z[1,3,6]  R1064     -6.6568199545145035e-03
    z[1,3,6]  R1065     1.2094780057668686e-01
    z[1,3,6]  R1066     3.0671152472496033e-01
    z[1,3,6]  R1067     1.8265551328659058e-01
    z[1,3,6]  R1068     -3.7411868572235107e-01
    z[1,3,6]  R1069     2.1233037114143372e-01
    z[1,3,6]  R1070     0.196168914437294
    z[1,3,6]  R1071     -3.9702009409666061e-02
    z[1,3,6]  R1072     2.5907030701637268e-01
    z[1,3,6]  R1073     -2.2752623260021210e-01
    z[1,3,6]  R1074     -4.2170169949531555e-01
    z[1,3,6]  R1075     -1.9631689786911011e-01
    z[1,3,6]  R1076     -6.1951391398906708e-02
    z[1,3,6]  R1077     1.1733530461788177e-01
    z[1,3,6]  R1078     -4.0632402896881104e-01
    z[1,3,6]  R1079     -6.6393963992595673e-02
    z[1,3,6]  R1080     3.7370380759239197e-01
    z[1,3,6]  R1081     -2.9392614960670471e-01
    z[1,3,6]  R1082     -1.1798671633005142e-01
    z[1,3,6]  R1083     1.8293111026287079e-01
    z[1,3,6]  R1084     -3.6410754919052124e-01
    z[1,3,6]  R1085     -1.0908308625221252e-01
    z[1,3,6]  R1086     2.6725763082504272e-01
    z[1,3,6]  R1087     2.5766745209693909e-01
    z[1,3,6]  R1088     -3.0579122900962830e-01
    z[1,3,6]  R1089     -5.7885181903839111e-01
    z[1,3,6]  R1090     1.6591729223728180e-01
    z[1,3,6]  R1091     1.4609168469905853e-01
    z[1,3,6]  R1092     -5.5366444587707520e-01
    z[1,3,6]  R1093     -3.5493856668472290e-01
    z[1,3,6]  R1094     -0.546783983707428
    z[1,3,6]  R1095     -2.9336306452751160e-01
    z[1,3,6]  R1096     -6.3115954399108887e-02
    z[1,3,6]  R1097     -4.1935643553733826e-01
    z[1,3,6]  R1098     5.7996802031993866e-02
    z[1,3,6]  R1099     -1.8123584985733032e-01
    z[1,3,6]  R1100     -0.336314857006073
    z[1,3,6]  R1101     -3.0428001284599304e-01
    z[1,3,6]  R1102     -3.0388179421424866e-01
    z[1,3,6]  R1103     -1.1459008604288101e-01
    z[1,3,6]  R1104     -3.3831059932708740e-02
    z[1,3,6]  R1105     3.8647550344467163e-01
    z[1,3,6]  R1106     -1.0314249992370605e-01
    z[1,3,6]  R1107     7.8031592071056366e-02
    z[1,3,6]  R1108     -2.4493908509612083e-02
    z[1,3,6]  R1109     -2.7924704551696777e-01
    z[1,3,6]  R1110     6.3042402267456055e-02
    z[1,3,6]  R1111     -3.0630344152450562e-01
    z[1,3,6]  R1112     -5.7962872087955475e-02
    z[1,3,6]  R1113     -2.0928554236888885e-01
    z[1,3,6]  R1114     1.4468098059296608e-02
    z[1,3,6]  R1115     3.2767906785011292e-02
    z[1,3,6]  R1116     -7.0363827049732208e-02
    z[1,3,6]  R1117     1.9452148675918579e-01
    z[1,3,6]  R1118     -3.8339901715517044e-02
    z[1,3,6]  R1119     3.0110573768615723e-01
    z[1,3,6]  R1120     2.4829675257205963e-01
    z[1,3,6]  R1121     -2.5787854194641113e-01
    z[1,3,6]  R1122     3.1721785664558411e-01
    z[1,3,6]  R1123     -6.0341215133666992e-01
    z[1,3,6]  R1124     5.3015735000371933e-02
    z[1,3,6]  R1125     1.1071027070283890e-01
    z[1,3,6]  R1126     -1.8461908400058746e-01
    z[1,3,6]  R1127     -1.6669057309627533e-01
    z[1,3,6]  R1128     3.5490524768829346e-01
    z[1,3,6]  R1129     -2.0352724194526672e-01
    z[1,3,6]  R1130     1.1936455219984055e-01
    z[1,3,6]  R1131     -2.6060926914215088e-01
    z[1,3,6]  R1132     1.7777577042579651e-01
    z[1,3,6]  R1133     1.3658711314201355e-01
    z[1,3,6]  R1134     -1.6236859560012817e-01
    z[1,3,6]  R1135     -6.8921104073524475e-02
    z[1,3,6]  R1136     -9.9029108881950378e-02
    z[1,3,6]  R1137     4.9343584105372429e-03
    z[1,3,6]  R1138     -8.1637494266033173e-02
    z[1,3,6]  R1139     3.4795474261045456e-02
    z[1,3,6]  R1140     -6.8906836211681366e-02
    z[1,3,6]  R1141     5.4065424948930740e-02
    z[1,3,6]  R1142     5.4115884006023407e-02
    z[1,3,6]  R1143     0.0679747611284256
    z[1,3,6]  R1144     1.3578702509403229e-01
    z[1,3,6]  R1145     2.6807633042335510e-01
    z[1,3,6]  R1146     7.1148246526718140e-02
    z[1,3,6]  R1147     -9.2562668025493622e-02
    z[1,3,6]  R1148     7.3835469782352448e-02
    z[1,3,6]  R1149     3.5258814692497253e-02
    z[1,3,6]  R1150     -7.1503028273582458e-02
    z[1,3,6]  R1151     9.9891006946563721e-02
    z[1,3,6]  R1152     -2.1038312464952469e-02
    z[1,3,6]  R1153     -1.5752756595611572e-01
    z[1,3,6]  R1154     6.8824617192149162e-03
    z[1,3,6]  R1155     -2.6545220613479614e-01
    z[1,3,6]  R1156     1.4137212932109833e-01
    z[1,3,6]  R1157     3.6631348729133606e-01
    z[1,3,6]  R1158     -8.2015588879585266e-02
    z[1,3,6]  R1159     -2.1970118582248688e-01
    z[1,3,6]  R1160     0.0908239483833313
    z[1,3,6]  R1161     -0.641921877861023
    z[1,3,6]  R1162     8.6049064993858337e-02
    z[1,3,6]  R1163     1.6886119544506073e-01
    z[1,3,6]  R1164     2.4283771216869354e-01
    z[1,3,6]  R1165     4.8933181911706924e-02
    z[1,3,6]  R1166     0.0592205636203289
    z[1,3,6]  R1167     2.4375896900892258e-02
    z[1,3,6]  R1168     -6.8199324607849121e-01
    z[1,3,6]  R1169     1.5630531311035156e-01
    z[1,3,6]  R1170     -2.6589466258883476e-02
    z[1,3,6]  R1171     -3.1645059585571289e-01
    z[1,3,6]  R1172     -1.6363418102264404e-01
    z[1,3,6]  R1173     1.8553754314780235e-02
    z[1,3,6]  R1174     3.1172606348991394e-01
    z[1,3,6]  R1175     -4.8182481527328491e-01
    z[3,1,0]  R11       1
    z[3,1,0]  R29       -1
    z[3,1,0]  R1176     -1
    z[3,1,0]  R1177     1
    z[3,1,0]  R1190     -5.7539260387420654e-01
    z[3,1,0]  R1191     -4.6624532341957092e-01
    z[3,1,0]  R1192     -5.0899642705917358e-01
    z[3,1,0]  R1193     -1.2014885246753693e-01
    z[3,1,0]  R1194     -5.0082010030746460e-01
    z[3,1,0]  R1195     5.9517875313758850e-02
    z[3,1,0]  R1196     -1.1326623708009720e-01
    z[3,1,0]  R1197     1.3849098980426788e-01
    z[3,1,0]  R1198     4.2004132270812988e-01
    z[3,1,0]  R1199     1.9014729559421539e-01
    z[3,1,0]  R1200     5.7204455137252808e-01
    z[3,1,0]  R1201     0.572113037109375
    z[3,1,0]  R1202     5.7787096500396729e-01
    z[3,1,0]  R1203     5.3382194042205811e-01
    z[3,1,0]  R1204     1.7811340093612671e-01
    z[3,1,0]  R1205     5.7484441995620728e-01
    z[3,1,0]  R1206     0.334280788898468
    z[3,1,0]  R1207     5.1705837249755859e-02
    z[3,1,0]  R1208     3.4049415588378906e-01
    z[3,1,0]  R1209     6.3084119558334351e-01
    z[3,1,0]  R1210     9.9886313080787659e-02
    z[3,1,0]  R1211     0.684758722782135
    z[3,1,0]  R1212     5.9450703859329224e-01
    z[3,1,0]  R1213     5.3604131937026978e-01
    z[3,1,0]  R1214     5.7761001586914062e-01
    z[3,1,0]  R1215     5.9616720676422119e-01
    z[3,1,0]  R1216     5.5288159847259521e-01
    z[3,1,0]  R1217     6.0106503963470459e-01
    z[3,1,0]  R1218     4.5466482639312744e-01
    z[3,1,0]  R1219     6.2489295005798340e-01
    z[3,1,0]  R1220     -4.3019089847803116e-02
    z[3,1,0]  R1221     -4.8385281115770340e-02
    z[3,1,0]  R1222     -5.2565336227416992e-01
    z[3,1,0]  R1223     -1.6974531114101410e-01
    z[3,1,0]  R1224     7.1861910820007324e-01
    z[3,1,0]  R1225     -4.3361854553222656e-01
    z[3,1,0]  R1226     -5.8581691980361938e-01
    z[3,1,0]  R1227     -8.2092887163162231e-01
    z[3,1,0]  R1228     -7.8789454698562622e-01
    z[3,1,0]  R1229     -7.9566174745559692e-01
    z[3,1,0]  R1230     9.5633447170257568e-02
    z[3,1,0]  R1231     7.3859155178070068e-02
    z[3,1,0]  R1232     1.6299448907375336e-01
    z[3,1,0]  R1233     -0.557685136795044
    z[3,1,0]  R1234     -2.3144088685512543e-01
    z[3,1,0]  R1235     8.0284041166305542e-01
    z[3,1,0]  R1236     -0.42790487408638
    z[3,1,0]  R1237     -4.4375672936439514e-01
    z[3,1,0]  R1238     -1.8512088805437088e-02
    z[3,1,0]  R1239     3.3699741959571838e-01
    z[3,1,0]  R1240     2.7963241934776306e-01
    z[3,1,0]  R1241     3.4242463111877441e-01
    z[3,1,0]  R1242     2.7918154001235962e-01
    z[3,1,0]  R1243     1.7188704013824463e-01
    z[3,1,0]  R1244     2.6724824309349060e-01
    z[3,1,0]  R1245     3.3592095971107483e-01
    z[3,1,0]  R1246     2.6670613884925842e-01
    z[3,1,0]  R1247     2.9679268598556519e-01
    z[3,1,0]  R1248     3.2342132925987244e-01
    z[3,1,0]  R1249     4.2374247312545776e-01
    z[3,1,0]  R1250     5.6757301092147827e-01
    z[3,1,0]  R1251     4.6850016713142395e-01
    z[3,1,0]  R1252     6.9135004281997681e-01
    z[3,1,0]  R1253     5.3372144699096680e-01
    z[3,1,0]  R1254     6.4588135480880737e-01
    z[3,1,0]  R1255     5.4391831159591675e-01
    z[3,1,0]  R1256     2.6483288407325745e-01
    z[3,1,0]  R1257     1.2983353435993195e-01
    z[3,1,0]  R1258     3.0205753445625305e-01
    z[3,1,0]  R1259     -2.7663335204124451e-02
    z[3,1,0]  R1260     4.8140409588813782e-01
    z[3,1,0]  R1261     -3.3962267637252808e-01
    z[3,1,0]  R1262     -9.4367347657680511e-02
    z[3,1,0]  R1263     -2.3696716129779816e-01
    z[3,1,0]  R1264     -4.0758627653121948e-01
    z[3,1,0]  R1265     -3.8331297039985657e-01
    z[3,1,0]  R1266     1.3147702813148499e-01
    z[3,1,0]  R1267     -6.6205447912216187e-01
    z[3,1,0]  R1268     0.0634799376130104
    z[3,1,0]  R1269     -4.9066832661628723e-01
    z[3,1,0]  R1270     2.5178718566894531e-01
    z[3,1,0]  R1271     -1.9391223788261414e-01
    z[3,1,0]  R1272     4.9170383810997009e-01
    z[3,1,0]  R1273     -2.4322444200515747e-01
    z[3,1,0]  R1274     1.0009628534317017e-01
    z[3,1,0]  R1275     4.7080019116401672e-01
    z[3,1,0]  R1276     -1.3195669651031494e-01
    z[3,1,0]  R1277     1.1216656118631363e-01
    z[3,1,0]  R1278     5.4910188913345337e-01
    z[3,1,0]  R1279     -3.1269797682762146e-01
    z[3,1,0]  R1280     4.4816821813583374e-02
    z[3,1,0]  R1281     -2.6699263602495193e-02
    z[3,1,0]  R1282     5.7596504688262939e-01
    z[3,1,0]  R1283     3.8244676589965820e-01
    z[3,1,0]  R1284     7.2887712717056274e-01
    z[3,1,0]  R1285     1.1982088536024094e-01
    z[3,1,0]  R1286     -9.3095436692237854e-02
    z[3,1,0]  R1287     7.0091545581817627e-01
    z[3,1,0]  R1288     6.5625959634780884e-01
    z[3,1,0]  R1289     0.729515790939331
    z[3,1,0]  R1290     3.9137899875640869e-01
    z[3,1,0]  R1291     5.6989258527755737e-01
    z[3,1,0]  R1292     4.3833982944488525e-01
    z[3,1,0]  R1293     -0.166781947016716
    z[3,1,0]  R1294     -8.5881259292364120e-03
    z[3,1,0]  R1295     -1.9071486592292786e-01
    z[3,1,0]  R1296     2.8914827108383179e-01
    z[3,1,0]  R1297     -3.4472441673278809e-01
    z[3,1,0]  R1298     5.1635402441024780e-01
    z[3,1,0]  R1299     7.0207953453063965e-02
    z[3,1,0]  R1300     5.7533466815948486e-01
    z[3,1,0]  R1301     1.5542012453079224e-01
    z[3,1,0]  R1302     2.3176409304141998e-01
    z[3,1,0]  R1303     -1.0020636767148972e-01
    z[3,1,0]  R1304     -0.573139488697052
    z[3,1,0]  R1305     -1.4173206686973572e-01
    z[3,1,0]  R1306     -4.1580238938331604e-01
    z[3,1,0]  R1307     -7.9225033521652222e-01
    z[3,1,0]  R1308     -4.2027789354324341e-01
    z[3,1,0]  R1309     -3.3313852548599243e-01
    z[3,1,0]  R1310     2.9472494125366211e-01
    z[3,1,0]  R1311     4.7758859395980835e-01
    z[3,1,0]  R1312     0.695899486541748
    z[3,1,0]  R1313     4.3001008033752441e-01
    z[3,1,0]  R1314     1.0595851391553879e-01
    z[3,1,0]  R1315     5.8363842964172363e-01
    z[3,1,0]  R1316     0.500739574432373
    z[3,1,0]  R1317     -6.7276030778884888e-01
    z[3,1,0]  R1318     -0.639201819896698
    z[3,1,0]  R1319     -4.3315351009368896e-01
    z[3,1,0]  R1320     5.0770324468612671e-01
    z[3,1,0]  R1321     6.2168218195438385e-02
    z[3,1,0]  R1322     -7.0578551292419434e-01
    z[3,1,0]  R1323     -2.9588720202445984e-01
    z[3,1,0]  R1324     -4.6263718605041504e-01
    z[3,1,0]  R1325     -6.7708253860473633e-01
    z[3,1,0]  R1326     -4.0369123220443726e-01
    z[3,1,0]  R1327     -6.2100154161453247e-01
    z[3,1,0]  R1328     -7.3160064220428467e-01
    z[3,1,0]  R1329     -6.7369800806045532e-01
    z[3,1,0]  R1330     6.7131519317626953e-01
    z[3,1,0]  R1331     3.7447464466094971e-01
    z[3,1,0]  R1332     -2.2601333260536194e-01
    z[3,1,0]  R1333     -5.8531010150909424e-01
    z[3,1,0]  R1334     -2.4237510561943054e-01
    z[3,1,0]  R1335     -2.5561258196830750e-01
    z[3,1,0]  R1336     -8.8041287660598755e-01
    z[3,1,0]  R1337     -5.3718191385269165e-01
    z[3,1,0]  R1338     -7.6415562629699707e-01
    z[3,1,0]  R1339     -8.0009514093399048e-01
    z[3,1,1]  R12       1
    z[3,1,1]  R30       -1
    z[3,1,1]  R1178     -1
    z[3,1,1]  R1179     1
    z[3,1,1]  R1190     5.3784084320068359e-01
    z[3,1,1]  R1191     4.0997806191444397e-01
    z[3,1,1]  R1192     3.5884803533554077e-01
    z[3,1,1]  R1193     6.3315761089324951e-01
    z[3,1,1]  R1194     6.0678112506866455e-01
    z[3,1,1]  R1195     1.5981715917587280e-01
    z[3,1,1]  R1196     -6.0067433118820190e-01
    z[3,1,1]  R1197     -5.6848269701004028e-01
    z[3,1,1]  R1198     -6.1022669076919556e-01
    z[3,1,1]  R1199     -4.7365039587020874e-01
    z[3,1,1]  R1200     -7.7890610694885254e-01
    z[3,1,1]  R1201     -0.734073281288147
    z[3,1,1]  R1202     -7.1233463287353516e-01
    z[3,1,1]  R1203     -7.4874430894851685e-01
    z[3,1,1]  R1204     -8.8062816858291626e-01
    z[3,1,1]  R1205     -7.2288483381271362e-01
    z[3,1,1]  R1206     -8.5410809516906738e-01
    z[3,1,1]  R1207     -8.4017670154571533e-01
    z[3,1,1]  R1208     -8.2712328433990479e-01
    z[3,1,1]  R1209     -6.3271623849868774e-01
    z[3,1,1]  R1210     -2.8168407082557678e-01
    z[3,1,1]  R1211     4.9736425280570984e-01
    z[3,1,1]  R1212     4.9484935402870178e-01
    z[3,1,1]  R1213     5.2616351842880249e-01
    z[3,1,1]  R1214     4.0387737751007080e-01
    z[3,1,1]  R1215     3.4215039014816284e-01
    z[3,1,1]  R1216     5.1828610897064209e-01
    z[3,1,1]  R1217     3.5125705599784851e-01
    z[3,1,1]  R1218     4.8839551210403442e-01
    z[3,1,1]  R1219     3.7105610966682434e-01
    z[3,1,1]  R1220     3.2518428564071655e-01
    z[3,1,1]  R1221     -1.1943493038415909e-01
    z[3,1,1]  R1222     -4.5852270722389221e-01
    z[3,1,1]  R1223     -4.6201723814010620e-01
    z[3,1,1]  R1224     3.0634099245071411e-01
    z[3,1,1]  R1225     -3.5620772838592529e-01
    z[3,1,1]  R1226     -5.4595535993576050e-01
    z[3,1,1]  R1227     -0.424570769071579
    z[3,1,1]  R1228     -0.507512629032135
    z[3,1,1]  R1229     -5.1523089408874512e-01
    z[3,1,1]  R1230     -1.7358395457267761e-01
    z[3,1,1]  R1231     -6.7534017562866211e-01
    z[3,1,1]  R1232     -5.6824922561645508e-01
    z[3,1,1]  R1233     -7.2195613384246826e-01
    z[3,1,1]  R1234     -2.6490309834480286e-01
    z[3,1,1]  R1235     3.6142560839653015e-01
    z[3,1,1]  R1236     -2.9764235019683838e-01
    z[3,1,1]  R1237     -0.304245263338089
    z[3,1,1]  R1238     -2.3560518398880959e-02
    z[3,1,1]  R1239     3.8852196931838989e-01
    z[3,1,1]  R1240     3.4309035539627075e-01
    z[3,1,1]  R1241     3.0812993645668030e-01
    z[3,1,1]  R1242     2.3934613168239594e-01
    z[3,1,1]  R1243     -2.9777586460113525e-01
    z[3,1,1]  R1244     -1.9624061882495880e-01
    z[3,1,1]  R1245     4.1178426146507263e-01
    z[3,1,1]  R1246     1.6529412567615509e-01
    z[3,1,1]  R1247     5.1155781745910645e-01
    z[3,1,1]  R1248     1.5445442497730255e-01
    z[3,1,1]  R1249     -3.6533939838409424e-01
    z[3,1,1]  R1250     -6.5492558479309082e-01
    z[3,1,1]  R1251     -6.9631791114807129e-01
    z[3,1,1]  R1252     -5.1652860641479492e-01
    z[3,1,1]  R1253     -6.4939856529235840e-01
    z[3,1,1]  R1254     -3.6016201972961426e-01
    z[3,1,1]  R1255     -4.1192224621772766e-01
    z[3,1,1]  R1256     -5.5285841226577759e-01
    z[3,1,1]  R1257     -6.5408545732498169e-01
    z[3,1,1]  R1258     -4.8382645845413208e-01
    z[3,1,1]  R1259     -4.7620588541030884e-01
    z[3,1,1]  R1260     0.547591507434845
    z[3,1,1]  R1261     2.6197345927357674e-02
    z[3,1,1]  R1262     2.6048806309700012e-01
    z[3,1,1]  R1263     2.1758790314197540e-01
    z[3,1,1]  R1264     1.6954356431961060e-01
    z[3,1,1]  R1265     3.9316490292549133e-01
    z[3,1,1]  R1266     -7.7843718230724335e-02
    z[3,1,1]  R1267     1.7736643552780151e-01
    z[3,1,1]  R1268     3.7261933088302612e-01
    z[3,1,1]  R1269     3.1868198513984680e-01
    z[3,1,1]  R1270     -6.4168584346771240e-01
    z[3,1,1]  R1271     -5.1873183250427246e-01
    z[3,1,1]  R1272     -5.3301793336868286e-01
    z[3,1,1]  R1273     -4.2163071036338806e-01
    z[3,1,1]  R1274     -5.7585906237363815e-02
    z[3,1,1]  R1275     6.8187665939331055e-01
    z[3,1,1]  R1276     -7.6996523141860962e-01
    z[3,1,1]  R1277     -5.8149510622024536e-01
    z[3,1,1]  R1278     4.9429732561111450e-01
    z[3,1,1]  R1279     -4.6810075640678406e-01
    z[3,1,1]  R1280     -7.8278720378875732e-01
    z[3,1,1]  R1281     -8.3292537927627563e-01
    z[3,1,1]  R1282     -5.1259505748748779e-01
    z[3,1,1]  R1283     -6.0324513912200928e-01
    z[3,1,1]  R1284     3.1696164608001709e-01
    z[3,1,1]  R1285     -7.5302451848983765e-01
    z[3,1,1]  R1286     -8.0823796987533569e-01
    z[3,1,1]  R1287     -3.2325261831283569e-01
    z[3,1,1]  R1288     -5.0754940509796143e-01
    z[3,1,1]  R1289     3.8729032874107361e-01
    z[3,1,1]  R1290     -8.6260598897933960e-01
    z[3,1,1]  R1291     6.4150685071945190e-01
    z[3,1,1]  R1292     5.9370237588882446e-01
    z[3,1,1]  R1293     -6.1903841793537140e-02
    z[3,1,1]  R1294     7.4042327702045441e-02
    z[3,1,1]  R1295     6.0816723108291626e-01
    z[3,1,1]  R1296     2.5047263503074646e-01
    z[3,1,1]  R1297     -2.0845349133014679e-01
    z[3,1,1]  R1298     3.9893460273742676e-01
    z[3,1,1]  R1299     3.3393295598216355e-04
    z[3,1,1]  R1300     5.4899090528488159e-01
    z[3,1,1]  R1301     -8.4485612809658051e-02
    z[3,1,1]  R1302     3.0647762119770050e-02
    z[3,1,1]  R1303     3.6442461609840393e-01
    z[3,1,1]  R1304     1.4070263504981995e-01
    z[3,1,1]  R1305     0.718567967414856
    z[3,1,1]  R1306     -1.8699440360069275e-01
    z[3,1,1]  R1307     3.5574089735746384e-02
    z[3,1,1]  R1308     1.3084031641483307e-01
    z[3,1,1]  R1309     -3.3618080615997314e-01
    z[3,1,1]  R1310     -0.850028932094574
    z[3,1,1]  R1311     -6.1846506595611572e-01
    z[3,1,1]  R1312     -3.7172517180442810e-01
    z[3,1,1]  R1313     -5.4303795099258423e-01
    z[3,1,1]  R1314     -6.5986555814743042e-01
    z[3,1,1]  R1315     4.8054805397987366e-01
    z[3,1,1]  R1316     1.3738648593425751e-01
    z[3,1,1]  R1317     2.1112720668315887e-01
    z[3,1,1]  R1318     -9.5226854085922241e-02
    z[3,1,1]  R1319     2.2615295648574829e-01
    z[3,1,1]  R1320     -6.8314230442047119e-01
    z[3,1,1]  R1321     2.7245259284973145e-01
    z[3,1,1]  R1322     -1.2807795405387878e-01
    z[3,1,1]  R1323     1.5993210673332214e-01
    z[3,1,1]  R1324     5.6421858072280884e-01
    z[3,1,1]  R1325     1.5317335724830627e-01
    z[3,1,1]  R1326     7.8978991508483887e-01
    z[3,1,1]  R1327     4.4707828760147095e-01
    z[3,1,1]  R1328     4.8379644751548767e-01
    z[3,1,1]  R1329     4.0550419688224792e-01
    z[3,1,1]  R1330     5.6089580059051514e-01
    z[3,1,1]  R1331     -6.9278383255004883e-01
    z[3,1,1]  R1332     1.0703387856483459e-01
    z[3,1,1]  R1333     9.6009485423564911e-03
    z[3,1,1]  R1334     -7.1844294667243958e-02
    z[3,1,1]  R1335     -9.6338622272014618e-02
    z[3,1,1]  R1336     0.212177112698555
    z[3,1,1]  R1337     -3.5925975441932678e-01
    z[3,1,1]  R1338     2.7371007204055786e-01
    z[3,1,1]  R1339     4.9748173356056213e-01
    z[3,1,2]  R13       1
    z[3,1,2]  R31       -1
    z[3,1,2]  R1180     -1
    z[3,1,2]  R1181     1
    z[3,1,2]  R1190     -3.1495407223701477e-01
    z[3,1,2]  R1191     -2.7223592996597290e-01
    z[3,1,2]  R1192     1.9476598501205444e-01
    z[3,1,2]  R1193     -3.0419480800628662e-01
    z[3,1,2]  R1194     4.5412972569465637e-02
    z[3,1,2]  R1195     -4.4046494364738464e-01
    z[3,1,2]  R1196     5.1188701391220093e-01
    z[3,1,2]  R1197     6.8993842601776123e-01
    z[3,1,2]  R1198     5.3733807802200317e-01
    z[3,1,2]  R1199     7.7381551265716553e-01
    z[3,1,2]  R1200     -1.6695824265480042e-01
    z[3,1,2]  R1201     -1.0524638742208481e-01
    z[3,1,2]  R1202     -2.3312093317508698e-01
    z[3,1,2]  R1203     -9.8969843238592148e-03
    z[3,1,2]  R1204     -3.2058599591255188e-01
    z[3,1,2]  R1205     -7.9349176958203316e-03
    z[3,1,2]  R1206     -1.4685305953025818e-01
    z[3,1,2]  R1207     -2.5821053981781006e-01
    z[3,1,2]  R1208     -4.5450992882251740e-02
    z[3,1,2]  R1209     3.5034954547882080e-01
    z[3,1,2]  R1210     -1.6533946618437767e-02
    z[3,1,2]  R1211     -1.4327681064605713e-01
    z[3,1,2]  R1212     -1.1226122081279755e-01
    z[3,1,2]  R1213     -1.1739084869623184e-01
    z[3,1,2]  R1214     1.3021047413349152e-01
    z[3,1,2]  R1215     -6.5592072904109955e-02
    z[3,1,2]  R1216     1.4451918005943298e-01
    z[3,1,2]  R1217     2.1304875612258911e-01
    z[3,1,2]  R1218     1.1093472689390182e-01
    z[3,1,2]  R1219     -6.2649093568325043e-02
    z[3,1,2]  R1220     0.0575115866959095
    z[3,1,2]  R1221     2.1006904542446136e-01
    z[3,1,2]  R1222     -2.1441720426082611e-01
    z[3,1,2]  R1223     -2.3992931842803955e-01
    z[3,1,2]  R1224     3.1207486987113953e-01
    z[3,1,2]  R1225     3.0928462743759155e-02
    z[3,1,2]  R1226     -0.0356932133436203
    z[3,1,2]  R1227     -1.3485740125179291e-01
    z[3,1,2]  R1228     -1.8079439178109169e-02
    z[3,1,2]  R1229     -2.6221296191215515e-01
    z[3,1,2]  R1230     -2.2966243326663971e-01
    z[3,1,2]  R1231     -7.7399136498570442e-03
    z[3,1,2]  R1232     2.4974639713764191e-01
    z[3,1,2]  R1233     -6.7057803273200989e-02
    z[3,1,2]  R1234     1.5775233507156372e-01
    z[3,1,2]  R1235     -8.3998069167137146e-03
    z[3,1,2]  R1236     -2.7235758304595947e-01
    z[3,1,2]  R1237     -9.1737903654575348e-02
    z[3,1,2]  R1238     5.3540718555450439e-01
    z[3,1,2]  R1239     0.501573920249939
    z[3,1,2]  R1240     0.410097599029541
    z[3,1,2]  R1241     1.9897668063640594e-01
    z[3,1,2]  R1242     3.2608810067176819e-01
    z[3,1,2]  R1243     3.4057784080505371e-01
    z[3,1,2]  R1244     3.6706885695457458e-01
    z[3,1,2]  R1245     2.4889845401048660e-02
    z[3,1,2]  R1246     7.7606640756130219e-02
    z[3,1,2]  R1247     4.7487378120422363e-01
    z[3,1,2]  R1248     2.1392826735973358e-01
    z[3,1,2]  R1249     3.6713370680809021e-01
    z[3,1,2]  R1250     1.0967803001403809e-01
    z[3,1,2]  R1251     -4.1845682263374329e-01
    z[3,1,2]  R1252     -1.2607865035533905e-01
    z[3,1,2]  R1253     -0.486369788646698
    z[3,1,2]  R1254     5.4819411039352417e-01
    z[3,1,2]  R1255     0.567703127861023
    z[3,1,2]  R1256     3.9514392614364624e-02
    z[3,1,2]  R1257     4.5630556344985962e-01
    z[3,1,2]  R1258     -2.2555316984653473e-01
    z[3,1,2]  R1259     3.5645312070846558e-01
    z[3,1,2]  R1260     -4.2175155878067017e-01
    z[3,1,2]  R1261     1.6420675441622734e-02
    z[3,1,2]  R1262     4.6600274741649628e-02
    z[3,1,2]  R1263     -1.8738220632076263e-01
    z[3,1,2]  R1264     1.6186399757862091e-01
    z[3,1,2]  R1265     1.7931106686592102e-01
    z[3,1,2]  R1266     -3.0865499377250671e-01
    z[3,1,2]  R1267     -7.1684408187866211e-01
    z[3,1,2]  R1268     5.0356465578079224e-01
    z[3,1,2]  R1269     -7.8330940008163452e-01
    z[3,1,2]  R1270     4.0173164010047913e-01
    z[3,1,2]  R1271     6.7916172742843628e-01
    z[3,1,2]  R1272     5.6552004814147949e-01
    z[3,1,2]  R1273     6.2351912260055542e-01
    z[3,1,2]  R1274     2.7996173501014709e-01
    z[3,1,2]  R1275     1.4014796912670135e-01
    z[3,1,2]  R1276     2.6978957653045654e-01
    z[3,1,2]  R1277     -1.8271125853061676e-01
    z[3,1,2]  R1278     -3.0887761712074280e-01
    z[3,1,2]  R1279     1.8305076658725739e-01
    z[3,1,2]  R1280     4.6575519442558289e-01
    z[3,1,2]  R1281     4.3002769351005554e-02
    z[3,1,2]  R1282     1.5302455425262451e-01
    z[3,1,2]  R1283     1.3386055361479521e-03
    z[3,1,2]  R1284     1.3925452530384064e-01
    z[3,1,2]  R1285     3.2627224922180176e-01
    z[3,1,2]  R1286     -7.9252235591411591e-02
    z[3,1,2]  R1287     4.8510608077049255e-01
    z[3,1,2]  R1288     -1.7540137469768524e-01
    z[3,1,2]  R1289     -1.7894359305500984e-02
    z[3,1,2]  R1290     -1.7448730766773224e-01
    z[3,1,2]  R1291     1.3207750022411346e-01
    z[3,1,2]  R1292     -3.6221626400947571e-01
    z[3,1,2]  R1293     1.9669516384601593e-01
    z[3,1,2]  R1294     4.0278702974319458e-01
    z[3,1,2]  R1295     -2.0718200504779816e-01
    z[3,1,2]  R1296     -3.5573190450668335e-01
    z[3,1,2]  R1297     -6.5912526845932007e-01
    z[3,1,2]  R1298     1.1744274944067001e-01
    z[3,1,2]  R1299     -7.6905059814453125e-01
    z[3,1,2]  R1300     -9.8168686032295227e-02
    z[3,1,2]  R1301     9.7359839128330350e-04
    z[3,1,2]  R1302     -1.1752710491418839e-01
    z[3,1,2]  R1303     1.9486773014068604e-01
    z[3,1,2]  R1304     -5.7592725753784180e-01
    z[3,1,2]  R1305     -0.561223030090332
    z[3,1,2]  R1306     -5.7908612489700317e-01
    z[3,1,2]  R1307     -2.6552328467369080e-01
    z[3,1,2]  R1308     -6.9777297973632812e-01
    z[3,1,2]  R1309     -7.7856051921844482e-01
    z[3,1,2]  R1310     -9.9403075873851776e-02
    z[3,1,2]  R1311     3.4059146046638489e-01
    z[3,1,2]  R1312     1.4632999897003174e-01
    z[3,1,2]  R1313     3.2667240500450134e-01
    z[3,1,2]  R1314     1.5998254716396332e-01
    z[3,1,2]  R1315     -2.1347789466381073e-01
    z[3,1,2]  R1316     2.0259141921997070e-01
    z[3,1,2]  R1317     -4.5913219451904297e-01
    z[3,1,2]  R1318     -5.9972470998764038e-01
    z[3,1,2]  R1319     -6.4753305912017822e-01
    z[3,1,2]  R1320     -3.3333367109298706e-01
    z[3,1,2]  R1321     3.7514597177505493e-01
    z[3,1,2]  R1322     -2.6433351635932922e-01
    z[3,1,2]  R1323     -7.7267253398895264e-01
    z[3,1,2]  R1324     -1.0950347036123276e-01
    z[3,1,2]  R1325     4.1314274072647095e-01
    z[3,1,2]  R1326     -2.7503243088722229e-01
    z[3,1,2]  R1327     -1.9831565022468567e-01
    z[3,1,2]  R1328     -8.4968388080596924e-02
    z[3,1,2]  R1329     -1.5004470944404602e-01
    z[3,1,2]  R1330     -0.174790620803833
    z[3,1,2]  R1331     3.1620880961418152e-01
    z[3,1,2]  R1332     -6.8193428218364716e-02
    z[3,1,2]  R1333     -6.0812151432037354e-01
    z[3,1,2]  R1334     -7.1764141321182251e-01
    z[3,1,2]  R1335     -8.1184077262878418e-01
    z[3,1,2]  R1336     -1.2061801552772522e-01
    z[3,1,2]  R1337     1.9096738100051880e-01
    z[3,1,2]  R1338     -2.4020045995712280e-01
    z[3,1,2]  R1339     -3.7953026592731476e-02
    z[3,1,3]  R14       1
    z[3,1,3]  R32       -1
    z[3,1,3]  R1182     -1
    z[3,1,3]  R1183     1
    z[3,1,3]  R1190     3.4320011734962463e-01
    z[3,1,3]  R1191     3.5711315274238586e-01
    z[3,1,3]  R1192     6.5942478179931641e-01
    z[3,1,3]  R1193     5.9538805484771729e-01
    z[3,1,3]  R1194     3.4576657414436340e-01
    z[3,1,3]  R1195     7.0035117864608765e-01
    z[3,1,3]  R1196     -0.530301034450531
    z[3,1,3]  R1197     -2.6191276311874390e-01
    z[3,1,3]  R1198     -3.3637505024671555e-02
    z[3,1,3]  R1199     -3.3186116814613342e-01
    z[3,1,3]  R1200     -7.4687272310256958e-02
    z[3,1,3]  R1201     1.0632331669330597e-01
    z[3,1,3]  R1202     2.7038154006004333e-01
    z[3,1,3]  R1203     1.2183093279600143e-01
    z[3,1,3]  R1204     3.7542287260293961e-02
    z[3,1,3]  R1205     1.1555763334035873e-01
    z[3,1,3]  R1206     2.9953292012214661e-01
    z[3,1,3]  R1207     4.1325652599334717e-01
    z[3,1,3]  R1208     2.7058649063110352e-01
    z[3,1,3]  R1209     -4.5007247477769852e-02
    z[3,1,3]  R1210     3.1242930889129639e-01
    z[3,1,3]  R1211     -0.39503213763237
    z[3,1,3]  R1212     -5.6164044141769409e-01
    z[3,1,3]  R1213     -5.4107069969177246e-01
    z[3,1,3]  R1214     -6.1921846866607666e-01
    z[3,1,3]  R1215     -5.1277482509613037e-01
    z[3,1,3]  R1216     -4.6367436647415161e-01
    z[3,1,3]  R1217     -4.8262152075767517e-01
    z[3,1,3]  R1218     -6.2656527757644653e-01
    z[3,1,3]  R1219     -4.8673585057258606e-01
    z[3,1,3]  R1220     7.2669649124145508e-01
    z[3,1,3]  R1221     0.762295126914978
    z[3,1,3]  R1222     -5.7686185836791992e-01
    z[3,1,3]  R1223     -5.2052670717239380e-01
    z[3,1,3]  R1224     -3.6024487018585205e-01
    z[3,1,3]  R1225     -4.5294648408889771e-01
    z[3,1,3]  R1226     -4.4176250696182251e-01
    z[3,1,3]  R1227     -1.0698555409908295e-01
    z[3,1,3]  R1228     -2.1624748408794403e-01
    z[3,1,3]  R1229     -1.4532610774040222e-01
    z[3,1,3]  R1230     8.5010147094726562e-01
    z[3,1,3]  R1231     -5.5896854400634766e-01
    z[3,1,3]  R1232     -5.5401455610990524e-02
    z[3,1,3]  R1233     -2.5027725100517273e-01
    z[3,1,3]  R1234     -3.6608001589775085e-01
    z[3,1,3]  R1235     -2.4820853024721146e-02
    z[3,1,3]  R1236     -5.3497594594955444e-01
    z[3,1,3]  R1237     -4.3160125613212585e-01
    z[3,1,3]  R1238     -2.8032356500625610e-01
    z[3,1,3]  R1239     3.5390022397041321e-01
    z[3,1,3]  R1240     -1.8432404100894928e-01
    z[3,1,3]  R1241     -5.1463800668716431e-01
    z[3,1,3]  R1242     -6.4134937524795532e-01
    z[3,1,3]  R1243     -4.0266942977905273e-01
    z[3,1,3]  R1244     -4.4890768826007843e-02
    z[3,1,3]  R1245     -4.6394917368888855e-01
    z[3,1,3]  R1246     -3.5040271282196045e-01
    z[3,1,3]  R1247     -8.3797693252563477e-02
    z[3,1,3]  R1248     -2.0538680255413055e-03
    z[3,1,3]  R1249     -3.6634132266044617e-01
    z[3,1,3]  R1250     2.8865441679954529e-01
    z[3,1,3]  R1251     3.6795396357774734e-02
    z[3,1,3]  R1252     -1.4961647987365723e-01
    z[3,1,3]  R1253     1.3712696731090546e-01
    z[3,1,3]  R1254     6.4623266458511353e-02
    z[3,1,3]  R1255     -9.1978013515472412e-02
    z[3,1,3]  R1256     5.1226603984832764e-01
    z[3,1,3]  R1257     -3.9801809191703796e-01
    z[3,1,3]  R1258     -6.0857552289962769e-01
    z[3,1,3]  R1259     -5.7703101634979248e-01
    z[3,1,3]  R1260     2.6602050662040710e-01
    z[3,1,3]  R1261     1.8930549919605255e-01
    z[3,1,3]  R1262     6.5145730972290039e-01
    z[3,1,3]  R1263     4.7060206532478333e-01
    z[3,1,3]  R1264     4.4231966137886047e-01
    z[3,1,3]  R1265     3.7852790951728821e-01
    z[3,1,3]  R1266     2.2586712241172791e-01
    z[3,1,3]  R1267     4.2727984488010406e-02
    z[3,1,3]  R1268     5.4297196865081787e-01
    z[3,1,3]  R1269     1.6417096555233002e-01
    z[3,1,3]  R1270     -4.0744277834892273e-01
    z[3,1,3]  R1271     -4.2608398199081421e-01
    z[3,1,3]  R1272     1.6876373440027237e-02
    z[3,1,3]  R1273     -5.5595141649246216e-01
    z[3,1,3]  R1274     0.510107696056366
    z[3,1,3]  R1275     2.4046397209167480e-01
    z[3,1,3]  R1276     -3.1315666437149048e-01
    z[3,1,3]  R1277     2.9579216241836548e-01
    z[3,1,3]  R1278     3.9032116532325745e-01
    z[3,1,3]  R1279     -7.2604638338088989e-01
    z[3,1,3]  R1280     -1.0772946476936340e-01
    z[3,1,3]  R1281     -7.8980810940265656e-02
    z[3,1,3]  R1282     1.8345648050308228e-01
    z[3,1,3]  R1283     3.1382623314857483e-01
    z[3,1,3]  R1284     1.4028945565223694e-01
    z[3,1,3]  R1285     -4.3615886569023132e-01
    z[3,1,3]  R1286     -4.3881252408027649e-01
    z[3,1,3]  R1287     1.0959044843912125e-01
    z[3,1,3]  R1288     4.7214669175446033e-03
    z[3,1,3]  R1289     -1.2928792834281921e-01
    z[3,1,3]  R1290     -1.7415136098861694e-01
    z[3,1,3]  R1291     7.4559003114700317e-02
    z[3,1,3]  R1292     -1.0413333028554916e-01
    z[3,1,3]  R1293     1.8462552130222321e-01
    z[3,1,3]  R1294     0.713071882724762
    z[3,1,3]  R1295     4.2764917016029358e-01
    z[3,1,3]  R1296     6.1980700492858887e-01
    z[3,1,3]  R1297     3.4250319004058838e-01
    z[3,1,3]  R1298     0.574138879776001
    z[3,1,3]  R1299     3.9793962240219116e-01
    z[3,1,3]  R1300     -6.0092996805906296e-02
    z[3,1,3]  R1301     0.777245819568634
    z[3,1,3]  R1302     4.5326781272888184e-01
    z[3,1,3]  R1303     2.7885380387306213e-01
    z[3,1,3]  R1304     3.5766753554344177e-01
    z[3,1,3]  R1305     3.2030284404754639e-01
    z[3,1,3]  R1306     3.1763064861297607e-01
    z[3,1,3]  R1307     3.8000747561454773e-01
    z[3,1,3]  R1308     1.2909834086894989e-01
    z[3,1,3]  R1309     -2.4669134616851807e-01
    z[3,1,3]  R1310     -2.9174787923693657e-03
    z[3,1,3]  R1311     -2.8880032896995544e-01
    z[3,1,3]  R1312     4.0354898571968079e-01
    z[3,1,3]  R1313     1.3501471281051636e-01
    z[3,1,3]  R1314     -4.7309798002243042e-01
    z[3,1,3]  R1315     -2.9963061213493347e-01
    z[3,1,3]  R1316     5.4995840787887573e-01
    z[3,1,3]  R1317     4.1433700919151306e-01
    z[3,1,3]  R1318     4.0481972694396973e-01
    z[3,1,3]  R1319     3.9746868610382080e-01
    z[3,1,3]  R1320     -2.1642296016216278e-01
    z[3,1,3]  R1321     6.3129258155822754e-01
    z[3,1,3]  R1322     4.3214264512062073e-01
    z[3,1,3]  R1323     3.4522926807403564e-01
    z[3,1,3]  R1324     4.1966402530670166e-01
    z[3,1,3]  R1325     3.2063734531402588e-01
    z[3,1,3]  R1326     -1.9523462653160095e-01
    z[3,1,3]  R1327     -5.5567425489425659e-01
    z[3,1,3]  R1328     -4.6835356950759888e-01
    z[3,1,3]  R1329     -4.9415045976638794e-01
    z[3,1,3]  R1330     -1.4836981892585754e-01
    z[3,1,3]  R1331     2.6959040760993958e-01
    z[3,1,3]  R1332     5.1917874813079834e-01
    z[3,1,3]  R1333     4.2698773741722107e-01
    z[3,1,3]  R1334     3.9615362882614136e-01
    z[3,1,3]  R1335     2.7314865589141846e-01
    z[3,1,3]  R1336     2.4443480372428894e-01
    z[3,1,3]  R1337     3.0787822604179382e-01
    z[3,1,3]  R1338     -5.2298015356063843e-01
    z[3,1,3]  R1339     -2.9256063699722290e-01
    z[3,1,4]  R15       1
    z[3,1,4]  R33       -1
    z[3,1,4]  R1184     -1
    z[3,1,4]  R1185     1
    z[3,1,4]  R1190     1.5212135016918182e-01
    z[3,1,4]  R1191     6.0544836521148682e-01
    z[3,1,4]  R1192     1.1388329416513443e-01
    z[3,1,4]  R1193     -2.4923862516880035e-01
    z[3,1,4]  R1194     -4.1099062561988831e-01
    z[3,1,4]  R1195     7.6116546988487244e-02
    z[3,1,4]  R1196     -1.4724639058113098e-01
    z[3,1,4]  R1197     -1.4814375340938568e-01
    z[3,1,4]  R1198     1.4779733121395111e-01
    z[3,1,4]  R1199     -1.4857585728168488e-01
    z[3,1,4]  R1200     -1.5054804086685181e-01
    z[3,1,4]  R1201     -2.9473719000816345e-01
    z[3,1,4]  R1202     -0.156258225440979
    z[3,1,4]  R1203     2.5375029444694519e-01
    z[3,1,4]  R1204     -2.8916954994201660e-01
    z[3,1,4]  R1205     1.9727160036563873e-01
    z[3,1,4]  R1206     1.4298303425312042e-01
    z[3,1,4]  R1207     1.8206825852394104e-01
    z[3,1,4]  R1208     2.2723200917243958e-01
    z[3,1,4]  R1209     4.6563889831304550e-02
    z[3,1,4]  R1210     -1.5930096805095673e-01
    z[3,1,4]  R1211     -2.0812867581844330e-01
    z[3,1,4]  R1212     -2.5409471988677979e-01
    z[3,1,4]  R1213     -3.5411116480827332e-01
    z[3,1,4]  R1214     -2.4435031414031982e-01
    z[3,1,4]  R1215     -1.3521975278854370e-01
    z[3,1,4]  R1216     2.3473742604255676e-01
    z[3,1,4]  R1217     1.3703167438507080e-01
    z[3,1,4]  R1218     1.8078124523162842e-01
    z[3,1,4]  R1219     3.0565834045410156e-01
    z[3,1,4]  R1220     -0.0800301805138588
    z[3,1,4]  R1221     1.5295787155628204e-01
    z[3,1,4]  R1222     1.1559443175792694e-01
    z[3,1,4]  R1223     6.0622924566268921e-01
    z[3,1,4]  R1224     0.179230198264122
    z[3,1,4]  R1225     -1.0031496174633503e-02
    z[3,1,4]  R1226     3.5202977061271667e-01
    z[3,1,4]  R1227     -2.7851012349128723e-01
    z[3,1,4]  R1228     -1.1431746929883957e-01
    z[3,1,4]  R1229     1.8334053456783295e-02
    z[3,1,4]  R1230     1.1465849727392197e-01
    z[3,1,4]  R1231     -1.5079215168952942e-01
    z[3,1,4]  R1232     1.2787835299968719e-01
    z[3,1,4]  R1233     1.1395392566919327e-01
    z[3,1,4]  R1234     -1.2181679904460907e-01
    z[3,1,4]  R1235     2.8046944737434387e-01
    z[3,1,4]  R1236     -5.1584386825561523e-01
    z[3,1,4]  R1237     -6.2819540500640869e-01
    z[3,1,4]  R1238     7.1900326013565063e-01
    z[3,1,4]  R1239     1.1113435961306095e-02
    z[3,1,4]  R1240     1.3935865461826324e-01
    z[3,1,4]  R1241     -3.3856093883514404e-02
    z[3,1,4]  R1242     2.6250863075256348e-01
    z[3,1,4]  R1243     2.3572713136672974e-02
    z[3,1,4]  R1244     3.6814704537391663e-01
    z[3,1,4]  R1245     1.7465278506278992e-01
    z[3,1,4]  R1246     3.3341392874717712e-01
    z[3,1,4]  R1247     -7.4151274748146534e-04
    z[3,1,4]  R1248     2.8366908431053162e-01
    z[3,1,4]  R1249     5.4026669263839722e-01
    z[3,1,4]  R1250     -2.5515180826187134e-01
    z[3,1,4]  R1251     -2.7427467703819275e-01
    z[3,1,4]  R1252     -4.2240446805953979e-01
    z[3,1,4]  R1253     2.7976479381322861e-02
    z[3,1,4]  R1254     -1.7387789487838745e-01
    z[3,1,4]  R1255     -4.3352580070495605e-01
    z[3,1,4]  R1256     4.0010169148445129e-01
    z[3,1,4]  R1257     6.9646663963794708e-02
    z[3,1,4]  R1258     -5.0047025084495544e-02
    z[3,1,4]  R1259     -4.9046209454536438e-01
    z[3,1,4]  R1260     -3.5990697145462036e-01
    z[3,1,4]  R1261     9.0682750940322876e-01
    z[3,1,4]  R1262     6.9490909576416016e-01
    z[3,1,4]  R1263     7.9154515266418457e-01
    z[3,1,4]  R1264     7.2009402513504028e-01
    z[3,1,4]  R1265     7.0644110441207886e-01
    z[3,1,4]  R1266     8.1561535596847534e-01
    z[3,1,4]  R1267     -7.3069550096988678e-02
    z[3,1,4]  R1268     4.5287674665451050e-01
    z[3,1,4]  R1269     1.2962979078292847e-01
    z[3,1,4]  R1270     7.9473212361335754e-02
    z[3,1,4]  R1271     -1.3623583316802979e-01
    z[3,1,4]  R1272     2.1712502837181091e-01
    z[3,1,4]  R1273     8.6590774357318878e-02
    z[3,1,4]  R1274     7.9303735494613647e-01
    z[3,1,4]  R1275     -1.8995349109172821e-01
    z[3,1,4]  R1276     4.6238112449645996e-01
    z[3,1,4]  R1277     7.1789878606796265e-01
    z[3,1,4]  R1278     4.2612543702125549e-01
    z[3,1,4]  R1279     -2.2465731203556061e-01
    z[3,1,4]  R1280     1.1231165379285812e-01
    z[3,1,4]  R1281     4.8143625259399414e-01
    z[3,1,4]  R1282     3.1954690814018250e-01
    z[3,1,4]  R1283     3.2098862528800964e-01
    z[3,1,4]  R1284     -4.3746823072433472e-01
    z[3,1,4]  R1285     -1.7073710262775421e-01
    z[3,1,4]  R1286     -2.0819954574108124e-02
    z[3,1,4]  R1287     -0.0989551842212677
    z[3,1,4]  R1288     2.5268995761871338e-01
    z[3,1,4]  R1289     1.5949079394340515e-01
    z[3,1,4]  R1290     0.136853888630867
    z[3,1,4]  R1291     1.7795832455158234e-01
    z[3,1,4]  R1292     -1.3361354172229767e-01
    z[3,1,4]  R1293     8.3230429887771606e-01
    z[3,1,4]  R1294     4.1093739867210388e-01
    z[3,1,4]  R1295     5.3052127361297607e-01
    z[3,1,4]  R1296     5.1477003097534180e-01
    z[3,1,4]  R1297     5.0155729055404663e-01
    z[3,1,4]  R1298     2.9172223806381226e-01
    z[3,1,4]  R1299     4.8056846857070923e-01
    z[3,1,4]  R1300     2.6530984044075012e-01
    z[3,1,4]  R1301     5.4606622457504272e-01
    z[3,1,4]  R1302     7.8615558147430420e-01
    z[3,1,4]  R1303     6.2929922342300415e-01
    z[3,1,4]  R1304     2.6644504070281982e-01
    z[3,1,4]  R1305     -3.8745053112506866e-02
    z[3,1,4]  R1306     2.0344233512878418e-01
    z[3,1,4]  R1307     1.7360401153564453e-01
    z[3,1,4]  R1308     5.9470452368259430e-02
    z[3,1,4]  R1309     2.6736825704574585e-02
    z[3,1,4]  R1310     3.3870872855186462e-01
    z[3,1,4]  R1311     5.5658571422100067e-02
    z[3,1,4]  R1312     -7.8829256817698479e-03
    z[3,1,4]  R1313     7.8902617096900940e-02
    z[3,1,4]  R1314     1.1656423658132553e-01
    z[3,1,4]  R1315     2.7199275791645050e-02
    z[3,1,4]  R1316     4.8117798566818237e-01
    z[3,1,4]  R1317     3.0255025625228882e-01
    z[3,1,4]  R1318     3.3595968037843704e-02
    z[3,1,4]  R1319     1.6369393467903137e-01
    z[3,1,4]  R1320     -2.9842811822891235e-01
    z[3,1,4]  R1321     5.3670382499694824e-01
    z[3,1,4]  R1322     4.7548791766166687e-01
    z[3,1,4]  R1323     2.9210817813873291e-01
    z[3,1,4]  R1324     4.8938098549842834e-01
    z[3,1,4]  R1325     3.6667466163635254e-01
    z[3,1,4]  R1326     -3.0993974208831787e-01
    z[3,1,4]  R1327     -2.1801907569169998e-02
    z[3,1,4]  R1328     -6.2543079257011414e-02
    z[3,1,4]  R1329     -2.3602099716663361e-01
    z[3,1,4]  R1330     8.2893833518028259e-02
    z[3,1,4]  R1331     2.8686946630477905e-01
    z[3,1,4]  R1332     7.8496611118316650e-01
    z[3,1,4]  R1333     1.9304936751723289e-02
    z[3,1,4]  R1334     0.449378103017807
    z[3,1,4]  R1335     -3.3246347308158875e-01
    z[3,1,4]  R1336     -1.7195332795381546e-02
    z[3,1,4]  R1337     2.4461318552494049e-01
    z[3,1,4]  R1338     1.0814021341502666e-02
    z[3,1,4]  R1339     1.1211378872394562e-01
    z[3,1,5]  R16       1
    z[3,1,5]  R34       -1
    z[3,1,5]  R1186     -1
    z[3,1,5]  R1187     1
    z[3,1,5]  R1190     3.2471993565559387e-01
    z[3,1,5]  R1191     1.3615280389785767e-01
    z[3,1,5]  R1192     -2.1183695644140244e-02
    z[3,1,5]  R1193     1.8469187617301941e-01
    z[3,1,5]  R1194     2.7607583999633789e-01
    z[3,1,5]  R1195     4.6119844913482666e-01
    z[3,1,5]  R1196     1.7270718514919281e-01
    z[3,1,5]  R1197     2.6913151144981384e-01
    z[3,1,5]  R1198     -3.3632940053939819e-01
    z[3,1,5]  R1199     -6.1255201697349548e-02
    z[3,1,5]  R1200     -1.2070265598595142e-02
    z[3,1,5]  R1201     -1.5667583048343658e-01
    z[3,1,5]  R1202     -1.0563275776803493e-02
    z[3,1,5]  R1203     2.7180045843124390e-01
    z[3,1,5]  R1204     -1.4757966622710228e-02
    z[3,1,5]  R1205     -3.0287897586822510e-01
    z[3,1,5]  R1206     1.5523275732994080e-01
    z[3,1,5]  R1207     -1.2730531394481659e-01
    z[3,1,5]  R1208     -2.3361420631408691e-01
    z[3,1,5]  R1209     -5.3906790912151337e-02
    z[3,1,5]  R1210     0.88450688123703
    z[3,1,5]  R1211     -2.3509602248668671e-01
    z[3,1,5]  R1212     6.0226183384656906e-02
    z[3,1,5]  R1213     -5.1337979733943939e-02
    z[3,1,5]  R1214     -1.9504806399345398e-01
    z[3,1,5]  R1215     -4.8167926073074341e-01
    z[3,1,5]  R1216     -3.6643886566162109e-01
    z[3,1,5]  R1217     -0.439810574054718
    z[3,1,5]  R1218     -0.342242568731308
    z[3,1,5]  R1219     -2.5903207063674927e-01
    z[3,1,5]  R1220     5.7846188545227051e-01
    z[3,1,5]  R1221     4.4787231087684631e-01
    z[3,1,5]  R1222     -3.3854490518569946e-01
    z[3,1,5]  R1223     -1.1588786542415619e-01
    z[3,1,5]  R1224     3.4957417845726013e-01
    z[3,1,5]  R1225     -2.5847530364990234e-01
    z[3,1,5]  R1226     1.7605029046535492e-01
    z[3,1,5]  R1227     1.0050392150878906e-01
    z[3,1,5]  R1228     -5.0245508551597595e-02
    z[3,1,5]  R1229     9.4093777239322662e-02
    z[3,1,5]  R1230     -4.1067236661911011e-01
    z[3,1,5]  R1231     -4.5013588666915894e-01
    z[3,1,5]  R1232     3.2189333438873291e-01
    z[3,1,5]  R1233     2.5142475962638855e-01
    z[3,1,5]  R1234     -0.837743878364563
    z[3,1,5]  R1235     2.1290406584739685e-01
    z[3,1,5]  R1236     2.7396622300148010e-01
    z[3,1,5]  R1237     3.4762862324714661e-01
    z[3,1,5]  R1238     1.4043180644512177e-01
    z[3,1,5]  R1239     -3.5550388693809509e-01
    z[3,1,5]  R1240     -7.4647432565689087e-01
    z[3,1,5]  R1241     -6.3916242122650146e-01
    z[3,1,5]  R1242     -5.0884467363357544e-01
    z[3,1,5]  R1243     -7.2125869989395142e-01
    z[3,1,5]  R1244     -7.8055894374847412e-01
    z[3,1,5]  R1245     -6.7628163099288940e-01
    z[3,1,5]  R1246     -7.5406205654144287e-01
    z[3,1,5]  R1247     -5.4106724262237549e-01
    z[3,1,5]  R1248     -7.7640181779861450e-01
    z[3,1,5]  R1249     -3.3120352029800415e-01
    z[3,1,5]  R1250     -1.7839916050434113e-01
    z[3,1,5]  R1251     3.4148350358009338e-02
    z[3,1,5]  R1252     1.8258308991789818e-02
    z[3,1,5]  R1253     -1.8633460998535156e-01
    z[3,1,5]  R1254     -1.9224444031715393e-01
    z[3,1,5]  R1255     1.1763998866081238e-01
    z[3,1,5]  R1256     2.6581385731697083e-01
    z[3,1,5]  R1257     -3.4957072138786316e-01
    z[3,1,5]  R1258     9.1608978807926178e-02
    z[3,1,5]  R1259     4.0881808847188950e-02
    z[3,1,5]  R1260     2.3601700365543365e-01
    z[3,1,5]  R1261     1.3677023351192474e-01
    z[3,1,5]  R1262     7.3405399918556213e-02
    z[3,1,5]  R1263     1.0969126969575882e-01
    z[3,1,5]  R1264     9.2714056372642517e-02
    z[3,1,5]  R1265     1.4815928041934967e-01
    z[3,1,5]  R1266     2.1618127822875977e-01
    z[3,1,5]  R1267     8.9850440621376038e-02
    z[3,1,5]  R1268     3.2188418507575989e-01
    z[3,1,5]  R1269     1.1667750775814056e-02
    z[3,1,5]  R1270     3.9937481284141541e-01
    z[3,1,5]  R1271     -8.7309010326862335e-02
    z[3,1,5]  R1272     2.4414394795894623e-01
    z[3,1,5]  R1273     2.3820179700851440e-01
    z[3,1,5]  R1274     1.0241446644067764e-01
    z[3,1,5]  R1275     4.2090556025505066e-01
    z[3,1,5]  R1276     -6.4658693969249725e-02
    z[3,1,5]  R1277     -1.1355581879615784e-01
    z[3,1,5]  R1278     1.5739759802818298e-01
    z[3,1,5]  R1279     2.3948132991790771e-01
    z[3,1,5]  R1280     2.2364287078380585e-01
    z[3,1,5]  R1281     1.7969799041748047e-01
    z[3,1,5]  R1282     -3.2613289356231689e-01
    z[3,1,5]  R1283     4.9317643046379089e-01
    z[3,1,5]  R1284     3.1518206000328064e-01
    z[3,1,5]  R1285     -3.0196252465248108e-01
    z[3,1,5]  R1286     2.6776146888732910e-01
    z[3,1,5]  R1287     3.0875065922737122e-01
    z[3,1,5]  R1288     1.9810175895690918e-01
    z[3,1,5]  R1289     4.8662075400352478e-01
    z[3,1,5]  R1290     1.3925476372241974e-01
    z[3,1,5]  R1291     4.4187238812446594e-01
    z[3,1,5]  R1292     3.6108088493347168e-01
    z[3,1,5]  R1293     4.4546341896057129e-01
    z[3,1,5]  R1294     1.2333232164382935e-01
    z[3,1,5]  R1295     -1.0340360924601555e-02
    z[3,1,5]  R1296     2.5306472182273865e-01
    z[3,1,5]  R1297     3.0567046254873276e-02
    z[3,1,5]  R1298     1.1456538736820221e-01
    z[3,1,5]  R1299     4.9303401261568069e-02
    z[3,1,5]  R1300     4.6101510524749756e-01
    z[3,1,5]  R1301     3.7257452495396137e-03
    z[3,1,5]  R1302     1.2055249512195587e-01
    z[3,1,5]  R1303     1.0165440291166306e-01
    z[3,1,5]  R1304     -3.0589890480041504e-01
    z[3,1,5]  R1305     -1.5219344198703766e-01
    z[3,1,5]  R1306     -8.9321933686733246e-02
    z[3,1,5]  R1307     -6.7859692499041557e-03
    z[3,1,5]  R1308     -1.3576747849583626e-02
    z[3,1,5]  R1309     1.4903441071510315e-01
    z[3,1,5]  R1310     -0.248980313539505
    z[3,1,5]  R1311     -0.105091892182827
    z[3,1,5]  R1312     4.3572276830673218e-01
    z[3,1,5]  R1313     -5.9681254625320435e-01
    z[3,1,5]  R1314     -4.2099773883819580e-01
    z[3,1,5]  R1315     4.4694775342941284e-01
    z[3,1,5]  R1316     2.5101962685585022e-01
    z[3,1,5]  R1317     -1.2519478797912598e-01
    z[3,1,5]  R1318     -2.3776248097419739e-01
    z[3,1,5]  R1319     -8.8280171155929565e-02
    z[3,1,5]  R1320     -1.3381315767765045e-01
    z[3,1,5]  R1321     2.9748940467834473e-01
    z[3,1,5]  R1322     4.6417381614446640e-02
    z[3,1,5]  R1323     -8.5791319608688354e-02
    z[3,1,5]  R1324     -1.8986134231090546e-01
    z[3,1,5]  R1325     1.2778806686401367e-01
    z[3,1,5]  R1326     0.00913998018950224
    z[3,1,5]  R1327     1.4865861833095551e-01
    z[3,1,5]  R1328     -2.4004525039345026e-03
    z[3,1,5]  R1329     -2.4128738045692444e-01
    z[3,1,5]  R1330     0.412727415561676
    z[3,1,5]  R1331     2.9499068856239319e-01
    z[3,1,5]  R1332     2.1359564363956451e-01
    z[3,1,5]  R1333     -1.1896307766437531e-01
    z[3,1,5]  R1334     2.3534636944532394e-02
    z[3,1,5]  R1335     -1.2104593962430954e-01
    z[3,1,5]  R1336     6.8074040114879608e-02
    z[3,1,5]  R1337     1.6482903063297272e-01
    z[3,1,5]  R1338     -8.3766825497150421e-02
    z[3,1,5]  R1339     -2.2390339523553848e-02
    z[3,1,6]  R17       1
    z[3,1,6]  R35       -1
    z[3,1,6]  R1188     -1
    z[3,1,6]  R1189     1
    z[3,1,6]  R1190     -1.8461908400058746e-01
    z[3,1,6]  R1191     -1.6669057309627533e-01
    z[3,1,6]  R1192     3.5490524768829346e-01
    z[3,1,6]  R1193     -2.0352724194526672e-01
    z[3,1,6]  R1194     1.1936455219984055e-01
    z[3,1,6]  R1195     -2.6060926914215088e-01
    z[3,1,6]  R1196     1.7777577042579651e-01
    z[3,1,6]  R1197     1.3658711314201355e-01
    z[3,1,6]  R1198     -1.6236859560012817e-01
    z[3,1,6]  R1199     -6.8921104073524475e-02
    z[3,1,6]  R1200     -9.9029108881950378e-02
    z[3,1,6]  R1201     4.9343584105372429e-03
    z[3,1,6]  R1202     -8.1637494266033173e-02
    z[3,1,6]  R1203     3.4795474261045456e-02
    z[3,1,6]  R1204     -6.8906836211681366e-02
    z[3,1,6]  R1205     5.4065424948930740e-02
    z[3,1,6]  R1206     5.4115884006023407e-02
    z[3,1,6]  R1207     0.0679747611284256
    z[3,1,6]  R1208     1.3578702509403229e-01
    z[3,1,6]  R1209     2.6807633042335510e-01
    z[3,1,6]  R1210     7.1148246526718140e-02
    z[3,1,6]  R1211     -9.2562668025493622e-02
    z[3,1,6]  R1212     7.3835469782352448e-02
    z[3,1,6]  R1213     3.5258814692497253e-02
    z[3,1,6]  R1214     -7.1503028273582458e-02
    z[3,1,6]  R1215     9.9891006946563721e-02
    z[3,1,6]  R1216     -2.1038312464952469e-02
    z[3,1,6]  R1217     -1.5752756595611572e-01
    z[3,1,6]  R1218     6.8824617192149162e-03
    z[3,1,6]  R1219     -2.6545220613479614e-01
    z[3,1,6]  R1220     1.4137212932109833e-01
    z[3,1,6]  R1221     3.6631348729133606e-01
    z[3,1,6]  R1222     -8.2015588879585266e-02
    z[3,1,6]  R1223     -2.1970118582248688e-01
    z[3,1,6]  R1224     0.0908239483833313
    z[3,1,6]  R1225     -0.641921877861023
    z[3,1,6]  R1226     8.6049064993858337e-02
    z[3,1,6]  R1227     1.6886119544506073e-01
    z[3,1,6]  R1228     2.4283771216869354e-01
    z[3,1,6]  R1229     4.8933181911706924e-02
    z[3,1,6]  R1230     0.0592205636203289
    z[3,1,6]  R1231     2.4375896900892258e-02
    z[3,1,6]  R1232     -6.8199324607849121e-01
    z[3,1,6]  R1233     1.5630531311035156e-01
    z[3,1,6]  R1234     -2.6589466258883476e-02
    z[3,1,6]  R1235     -3.1645059585571289e-01
    z[3,1,6]  R1236     -1.6363418102264404e-01
    z[3,1,6]  R1237     1.8553754314780235e-02
    z[3,1,6]  R1238     3.1172606348991394e-01
    z[3,1,6]  R1239     -4.8182481527328491e-01
    z[3,1,6]  R1240     1.5904265642166138e-01
    z[3,1,6]  R1241     0.271445095539093
    z[3,1,6]  R1242     -1.3883425295352936e-01
    z[3,1,6]  R1243     2.8788670897483826e-01
    z[3,1,6]  R1244     9.2242740094661713e-02
    z[3,1,6]  R1245     -1.1773692071437836e-01
    z[3,1,6]  R1246     -0.304904043674469
    z[3,1,6]  R1247     -3.5347026586532593e-01
    z[3,1,6]  R1248     -3.7749823927879333e-01
    z[3,1,6]  R1249     1.2803323566913605e-01
    z[3,1,6]  R1250     2.3802106082439423e-01
    z[3,1,6]  R1251     2.0687267184257507e-01
    z[3,1,6]  R1252     -1.9543178379535675e-01
    z[3,1,6]  R1253     -5.0599705427885056e-02
    z[3,1,6]  R1254     -2.8501942753791809e-01
    z[3,1,6]  R1255     -4.4072084128856659e-02
    z[3,1,6]  R1256     3.5985404253005981e-01
    z[3,1,6]  R1257     -2.4825769662857056e-01
    z[3,1,6]  R1258     -4.9248144030570984e-01
    z[3,1,6]  R1259     -2.6498025655746460e-01
    z[3,1,6]  R1260     1.8578261137008667e-01
    z[3,1,6]  R1261     -0.0825931504368782
    z[3,1,6]  R1262     9.1572798788547516e-02
    z[3,1,6]  R1263     3.6711718887090683e-02
    z[3,1,6]  R1264     2.3696108162403107e-01
    z[3,1,6]  R1265     4.5238483697175980e-02
    z[3,1,6]  R1266     -3.4410390257835388e-01
    z[3,1,6]  R1267     -0.0334925651550293
    z[3,1,6]  R1268     -4.7413217835128307e-03
    z[3,1,6]  R1269     -1.4855190180242062e-02
    z[3,1,6]  R1270     -1.7784331738948822e-01
    z[3,1,6]  R1271     1.5596219897270203e-01
    z[3,1,6]  R1272     -2.1742123365402222e-01
    z[3,1,6]  R1273     -3.1197572126984596e-02
    z[3,1,6]  R1274     -9.3162119388580322e-02
    z[3,1,6]  R1275     1.5060979127883911e-01
    z[3,1,6]  R1276     -3.0172318220138550e-02
    z[3,1,6]  R1277     1.1491342447698116e-02
    z[3,1,6]  R1278     -6.6568199545145035e-03
    z[3,1,6]  R1279     1.2094780057668686e-01
    z[3,1,6]  R1280     3.0671152472496033e-01
    z[3,1,6]  R1281     1.8265551328659058e-01
    z[3,1,6]  R1282     -3.7411868572235107e-01
    z[3,1,6]  R1283     2.1233037114143372e-01
    z[3,1,6]  R1284     0.196168914437294
    z[3,1,6]  R1285     -3.9702009409666061e-02
    z[3,1,6]  R1286     2.5907030701637268e-01
    z[3,1,6]  R1287     -2.2752623260021210e-01
    z[3,1,6]  R1288     -4.2170169949531555e-01
    z[3,1,6]  R1289     -1.9631689786911011e-01
    z[3,1,6]  R1290     -6.1951391398906708e-02
    z[3,1,6]  R1291     1.1733530461788177e-01
    z[3,1,6]  R1292     -4.0632402896881104e-01
    z[3,1,6]  R1293     -6.6393963992595673e-02
    z[3,1,6]  R1294     3.7370380759239197e-01
    z[3,1,6]  R1295     -2.9392614960670471e-01
    z[3,1,6]  R1296     -1.1798671633005142e-01
    z[3,1,6]  R1297     1.8293111026287079e-01
    z[3,1,6]  R1298     -3.6410754919052124e-01
    z[3,1,6]  R1299     -1.0908308625221252e-01
    z[3,1,6]  R1300     2.6725763082504272e-01
    z[3,1,6]  R1301     2.5766745209693909e-01
    z[3,1,6]  R1302     -3.0579122900962830e-01
    z[3,1,6]  R1303     -5.7885181903839111e-01
    z[3,1,6]  R1304     1.6591729223728180e-01
    z[3,1,6]  R1305     1.4609168469905853e-01
    z[3,1,6]  R1306     -5.5366444587707520e-01
    z[3,1,6]  R1307     -3.5493856668472290e-01
    z[3,1,6]  R1308     -0.546783983707428
    z[3,1,6]  R1309     -2.9336306452751160e-01
    z[3,1,6]  R1310     -6.3115954399108887e-02
    z[3,1,6]  R1311     -4.1935643553733826e-01
    z[3,1,6]  R1312     5.7996802031993866e-02
    z[3,1,6]  R1313     -1.8123584985733032e-01
    z[3,1,6]  R1314     -0.336314857006073
    z[3,1,6]  R1315     -3.0428001284599304e-01
    z[3,1,6]  R1316     -3.0388179421424866e-01
    z[3,1,6]  R1317     -1.1459008604288101e-01
    z[3,1,6]  R1318     -3.3831059932708740e-02
    z[3,1,6]  R1319     3.8647550344467163e-01
    z[3,1,6]  R1320     -1.0314249992370605e-01
    z[3,1,6]  R1321     7.8031592071056366e-02
    z[3,1,6]  R1322     -2.4493908509612083e-02
    z[3,1,6]  R1323     -2.7924704551696777e-01
    z[3,1,6]  R1324     6.3042402267456055e-02
    z[3,1,6]  R1325     -3.0630344152450562e-01
    z[3,1,6]  R1326     -5.7962872087955475e-02
    z[3,1,6]  R1327     -2.0928554236888885e-01
    z[3,1,6]  R1328     1.4468098059296608e-02
    z[3,1,6]  R1329     3.2767906785011292e-02
    z[3,1,6]  R1330     -7.0363827049732208e-02
    z[3,1,6]  R1331     1.9452148675918579e-01
    z[3,1,6]  R1332     -3.8339901715517044e-02
    z[3,1,6]  R1333     3.0110573768615723e-01
    z[3,1,6]  R1334     2.4829675257205963e-01
    z[3,1,6]  R1335     -2.5787854194641113e-01
    z[3,1,6]  R1336     3.1721785664558411e-01
    z[3,1,6]  R1337     -6.0341215133666992e-01
    z[3,1,6]  R1338     5.3015735000371933e-02
    z[3,1,6]  R1339     1.1071027070283890e-01
    z[1,4,0]  R11       -1
    z[1,4,0]  R38       1
    z[1,4,0]  R1340     -1
    z[1,4,0]  R1341     1
    z[1,4,0]  R1354     2.7963241934776306e-01
    z[1,4,0]  R1355     3.4242463111877441e-01
    z[1,4,0]  R1356     2.7918154001235962e-01
    z[1,4,0]  R1357     1.7188704013824463e-01
    z[1,4,0]  R1358     2.6724824309349060e-01
    z[1,4,0]  R1359     3.3592095971107483e-01
    z[1,4,0]  R1360     2.6670613884925842e-01
    z[1,4,0]  R1361     2.9679268598556519e-01
    z[1,4,0]  R1362     3.2342132925987244e-01
    z[1,4,0]  R1363     4.2374247312545776e-01
    z[1,4,0]  R1364     5.6757301092147827e-01
    z[1,4,0]  R1365     4.6850016713142395e-01
    z[1,4,0]  R1366     6.9135004281997681e-01
    z[1,4,0]  R1367     5.3372144699096680e-01
    z[1,4,0]  R1368     6.4588135480880737e-01
    z[1,4,0]  R1369     5.4391831159591675e-01
    z[1,4,0]  R1370     2.6483288407325745e-01
    z[1,4,0]  R1371     1.2983353435993195e-01
    z[1,4,0]  R1372     3.0205753445625305e-01
    z[1,4,0]  R1373     -2.7663335204124451e-02
    z[1,4,0]  R1374     4.8140409588813782e-01
    z[1,4,0]  R1375     -3.3962267637252808e-01
    z[1,4,0]  R1376     -9.4367347657680511e-02
    z[1,4,0]  R1377     -2.3696716129779816e-01
    z[1,4,0]  R1378     -4.0758627653121948e-01
    z[1,4,0]  R1379     -3.8331297039985657e-01
    z[1,4,0]  R1380     1.3147702813148499e-01
    z[1,4,0]  R1381     -6.6205447912216187e-01
    z[1,4,0]  R1382     0.0634799376130104
    z[1,4,0]  R1383     -4.9066832661628723e-01
    z[1,4,0]  R1384     2.5178718566894531e-01
    z[1,4,0]  R1385     -1.9391223788261414e-01
    z[1,4,0]  R1386     4.9170383810997009e-01
    z[1,4,0]  R1387     -2.4322444200515747e-01
    z[1,4,0]  R1388     1.0009628534317017e-01
    z[1,4,0]  R1389     4.7080019116401672e-01
    z[1,4,0]  R1390     -1.3195669651031494e-01
    z[1,4,0]  R1391     1.1216656118631363e-01
    z[1,4,0]  R1392     5.4910188913345337e-01
    z[1,4,0]  R1393     -3.1269797682762146e-01
    z[1,4,0]  R1394     4.4816821813583374e-02
    z[1,4,0]  R1395     -2.6699263602495193e-02
    z[1,4,0]  R1396     5.7596504688262939e-01
    z[1,4,0]  R1397     3.8244676589965820e-01
    z[1,4,0]  R1398     7.2887712717056274e-01
    z[1,4,0]  R1399     1.1982088536024094e-01
    z[1,4,0]  R1400     -9.3095436692237854e-02
    z[1,4,0]  R1401     7.0091545581817627e-01
    z[1,4,0]  R1402     6.5625959634780884e-01
    z[1,4,0]  R1403     0.729515790939331
    z[1,4,0]  R1404     3.9137899875640869e-01
    z[1,4,0]  R1405     5.6989258527755737e-01
    z[1,4,0]  R1406     4.3833982944488525e-01
    z[1,4,0]  R1407     -0.166781947016716
    z[1,4,0]  R1408     -8.5881259292364120e-03
    z[1,4,0]  R1409     -1.9071486592292786e-01
    z[1,4,0]  R1410     2.8914827108383179e-01
    z[1,4,0]  R1411     -3.4472441673278809e-01
    z[1,4,0]  R1412     5.1635402441024780e-01
    z[1,4,0]  R1413     7.0207953453063965e-02
    z[1,4,0]  R1414     5.7533466815948486e-01
    z[1,4,0]  R1415     1.5542012453079224e-01
    z[1,4,0]  R1416     2.3176409304141998e-01
    z[1,4,0]  R1417     -1.0020636767148972e-01
    z[1,4,0]  R1418     -0.573139488697052
    z[1,4,0]  R1419     -1.4173206686973572e-01
    z[1,4,0]  R1420     -4.1580238938331604e-01
    z[1,4,0]  R1421     -7.9225033521652222e-01
    z[1,4,0]  R1422     -4.2027789354324341e-01
    z[1,4,0]  R1423     -3.3313852548599243e-01
    z[1,4,0]  R1424     2.9472494125366211e-01
    z[1,4,0]  R1425     4.7758859395980835e-01
    z[1,4,0]  R1426     0.695899486541748
    z[1,4,0]  R1427     4.3001008033752441e-01
    z[1,4,0]  R1428     1.0595851391553879e-01
    z[1,4,0]  R1429     5.8363842964172363e-01
    z[1,4,0]  R1430     0.500739574432373
    z[1,4,0]  R1431     -6.7276030778884888e-01
    z[1,4,0]  R1432     -0.639201819896698
    z[1,4,0]  R1433     -4.3315351009368896e-01
    z[1,4,0]  R1434     5.0770324468612671e-01
    z[1,4,0]  R1435     6.2168218195438385e-02
    z[1,4,0]  R1436     -7.0578551292419434e-01
    z[1,4,0]  R1437     -2.9588720202445984e-01
    z[1,4,0]  R1438     -4.6263718605041504e-01
    z[1,4,0]  R1439     -6.7708253860473633e-01
    z[1,4,0]  R1440     -4.0369123220443726e-01
    z[1,4,0]  R1441     -6.2100154161453247e-01
    z[1,4,0]  R1442     -7.3160064220428467e-01
    z[1,4,0]  R1443     -6.7369800806045532e-01
    z[1,4,0]  R1444     6.7131519317626953e-01
    z[1,4,0]  R1445     3.7447464466094971e-01
    z[1,4,0]  R1446     -2.2601333260536194e-01
    z[1,4,0]  R1447     -5.8531010150909424e-01
    z[1,4,0]  R1448     -2.4237510561943054e-01
    z[1,4,0]  R1449     -2.5561258196830750e-01
    z[1,4,0]  R1450     -8.8041287660598755e-01
    z[1,4,0]  R1451     -5.3718191385269165e-01
    z[1,4,0]  R1452     -7.6415562629699707e-01
    z[1,4,0]  R1453     -8.0009514093399048e-01
    z[1,4,0]  R1454     7.2173547744750977e-01
    z[1,4,0]  R1455     -2.6034882664680481e-01
    z[1,4,0]  R1456     -8.8026374578475952e-02
    z[1,4,0]  R1457     7.0207589864730835e-01
    z[1,4,0]  R1458     1.3437853753566742e-01
    z[1,4,0]  R1459     6.1883461475372314e-01
    z[1,4,0]  R1460     5.5191999673843384e-01
    z[1,4,0]  R1461     5.7589358091354370e-01
    z[1,4,0]  R1462     1.9529409706592560e-01
    z[1,4,0]  R1463     8.8348609209060669e-01
    z[1,4,0]  R1464     0.498344749212265
    z[1,4,0]  R1465     -5.7064223289489746e-01
    z[1,4,0]  R1466     -3.8162621855735779e-01
    z[1,4,0]  R1467     -5.8480417728424072e-01
    z[1,4,0]  R1468     -4.7194001078605652e-01
    z[1,4,0]  R1469     -4.4435703754425049e-01
    z[1,4,0]  R1470     -4.1637751460075378e-01
    z[1,4,0]  R1471     -4.7644710540771484e-01
    z[1,4,0]  R1472     -6.2589657306671143e-01
    z[1,4,0]  R1473     -3.0824321508407593e-01
    z[1,4,0]  R1474     6.4118367433547974e-01
    z[1,4,0]  R1475     5.4827427864074707e-01
    z[1,4,0]  R1476     3.2010135054588318e-01
    z[1,4,0]  R1477     1.3908789493143559e-02
    z[1,4,0]  R1478     3.6178115010261536e-01
    z[1,4,0]  R1479     3.5426384210586548e-01
    z[1,4,0]  R1480     3.4391263127326965e-01
    z[1,4,0]  R1481     -3.3993339538574219e-01
    z[1,4,0]  R1482     -0.0794341191649437
    z[1,4,0]  R1483     -1.8189454078674316e-01
    z[1,4,0]  R1484     6.8536871671676636e-01
    z[1,4,0]  R1485     6.1935573816299438e-01
    z[1,4,0]  R1486     -4.0746080875396729e-01
    z[1,4,0]  R1487     4.1207635402679443e-01
    z[1,4,0]  R1488     -3.0557766556739807e-02
    z[1,4,0]  R1489     1.9815362989902496e-01
    z[1,4,0]  R1490     -1.0177161544561386e-01
    z[1,4,0]  R1491     -3.2355093955993652e-01
    z[1,4,0]  R1492     -3.2967633008956909e-01
    z[1,4,0]  R1493     -5.7720702886581421e-01
    z[1,4,1]  R12       -1
    z[1,4,1]  R39       1
    z[1,4,1]  R1342     -1
    z[1,4,1]  R1343     1
    z[1,4,1]  R1354     3.4309035539627075e-01
    z[1,4,1]  R1355     3.0812993645668030e-01
    z[1,4,1]  R1356     2.3934613168239594e-01
    z[1,4,1]  R1357     -2.9777586460113525e-01
    z[1,4,1]  R1358     -1.9624061882495880e-01
    z[1,4,1]  R1359     4.1178426146507263e-01
    z[1,4,1]  R1360     1.6529412567615509e-01
    z[1,4,1]  R1361     5.1155781745910645e-01
    z[1,4,1]  R1362     1.5445442497730255e-01
    z[1,4,1]  R1363     -3.6533939838409424e-01
    z[1,4,1]  R1364     -6.5492558479309082e-01
    z[1,4,1]  R1365     -6.9631791114807129e-01
    z[1,4,1]  R1366     -5.1652860641479492e-01
    z[1,4,1]  R1367     -6.4939856529235840e-01
    z[1,4,1]  R1368     -3.6016201972961426e-01
    z[1,4,1]  R1369     -4.1192224621772766e-01
    z[1,4,1]  R1370     -5.5285841226577759e-01
    z[1,4,1]  R1371     -6.5408545732498169e-01
    z[1,4,1]  R1372     -4.8382645845413208e-01
    z[1,4,1]  R1373     -4.7620588541030884e-01
    z[1,4,1]  R1374     0.547591507434845
    z[1,4,1]  R1375     2.6197345927357674e-02
    z[1,4,1]  R1376     2.6048806309700012e-01
    z[1,4,1]  R1377     2.1758790314197540e-01
    z[1,4,1]  R1378     1.6954356431961060e-01
    z[1,4,1]  R1379     3.9316490292549133e-01
    z[1,4,1]  R1380     -7.7843718230724335e-02
    z[1,4,1]  R1381     1.7736643552780151e-01
    z[1,4,1]  R1382     3.7261933088302612e-01
    z[1,4,1]  R1383     3.1868198513984680e-01
    z[1,4,1]  R1384     -6.4168584346771240e-01
    z[1,4,1]  R1385     -5.1873183250427246e-01
    z[1,4,1]  R1386     -5.3301793336868286e-01
    z[1,4,1]  R1387     -4.2163071036338806e-01
    z[1,4,1]  R1388     -5.7585906237363815e-02
    z[1,4,1]  R1389     6.8187665939331055e-01
    z[1,4,1]  R1390     -7.6996523141860962e-01
    z[1,4,1]  R1391     -5.8149510622024536e-01
    z[1,4,1]  R1392     4.9429732561111450e-01
    z[1,4,1]  R1393     -4.6810075640678406e-01
    z[1,4,1]  R1394     -7.8278720378875732e-01
    z[1,4,1]  R1395     -8.3292537927627563e-01
    z[1,4,1]  R1396     -5.1259505748748779e-01
    z[1,4,1]  R1397     -6.0324513912200928e-01
    z[1,4,1]  R1398     3.1696164608001709e-01
    z[1,4,1]  R1399     -7.5302451848983765e-01
    z[1,4,1]  R1400     -8.0823796987533569e-01
    z[1,4,1]  R1401     -3.2325261831283569e-01
    z[1,4,1]  R1402     -5.0754940509796143e-01
    z[1,4,1]  R1403     3.8729032874107361e-01
    z[1,4,1]  R1404     -8.6260598897933960e-01
    z[1,4,1]  R1405     6.4150685071945190e-01
    z[1,4,1]  R1406     5.9370237588882446e-01
    z[1,4,1]  R1407     -6.1903841793537140e-02
    z[1,4,1]  R1408     7.4042327702045441e-02
    z[1,4,1]  R1409     6.0816723108291626e-01
    z[1,4,1]  R1410     2.5047263503074646e-01
    z[1,4,1]  R1411     -2.0845349133014679e-01
    z[1,4,1]  R1412     3.9893460273742676e-01
    z[1,4,1]  R1413     3.3393295598216355e-04
    z[1,4,1]  R1414     5.4899090528488159e-01
    z[1,4,1]  R1415     -8.4485612809658051e-02
    z[1,4,1]  R1416     3.0647762119770050e-02
    z[1,4,1]  R1417     3.6442461609840393e-01
    z[1,4,1]  R1418     1.4070263504981995e-01
    z[1,4,1]  R1419     0.718567967414856
    z[1,4,1]  R1420     -1.8699440360069275e-01
    z[1,4,1]  R1421     3.5574089735746384e-02
    z[1,4,1]  R1422     1.3084031641483307e-01
    z[1,4,1]  R1423     -3.3618080615997314e-01
    z[1,4,1]  R1424     -0.850028932094574
    z[1,4,1]  R1425     -6.1846506595611572e-01
    z[1,4,1]  R1426     -3.7172517180442810e-01
    z[1,4,1]  R1427     -5.4303795099258423e-01
    z[1,4,1]  R1428     -6.5986555814743042e-01
    z[1,4,1]  R1429     4.8054805397987366e-01
    z[1,4,1]  R1430     1.3738648593425751e-01
    z[1,4,1]  R1431     2.1112720668315887e-01
    z[1,4,1]  R1432     -9.5226854085922241e-02
    z[1,4,1]  R1433     2.2615295648574829e-01
    z[1,4,1]  R1434     -6.8314230442047119e-01
    z[1,4,1]  R1435     2.7245259284973145e-01
    z[1,4,1]  R1436     -1.2807795405387878e-01
    z[1,4,1]  R1437     1.5993210673332214e-01
    z[1,4,1]  R1438     5.6421858072280884e-01
    z[1,4,1]  R1439     1.5317335724830627e-01
    z[1,4,1]  R1440     7.8978991508483887e-01
    z[1,4,1]  R1441     4.4707828760147095e-01
    z[1,4,1]  R1442     4.8379644751548767e-01
    z[1,4,1]  R1443     4.0550419688224792e-01
    z[1,4,1]  R1444     5.6089580059051514e-01
    z[1,4,1]  R1445     -6.9278383255004883e-01
    z[1,4,1]  R1446     1.0703387856483459e-01
    z[1,4,1]  R1447     9.6009485423564911e-03
    z[1,4,1]  R1448     -7.1844294667243958e-02
    z[1,4,1]  R1449     -9.6338622272014618e-02
    z[1,4,1]  R1450     0.212177112698555
    z[1,4,1]  R1451     -3.5925975441932678e-01
    z[1,4,1]  R1452     2.7371007204055786e-01
    z[1,4,1]  R1453     4.9748173356056213e-01
    z[1,4,1]  R1454     4.7464835643768311e-01
    z[1,4,1]  R1455     -3.7263244390487671e-01
    z[1,4,1]  R1456     -5.8896821737289429e-01
    z[1,4,1]  R1457     5.5480856448411942e-02
    z[1,4,1]  R1458     -0.356360524892807
    z[1,4,1]  R1459     -2.9439383745193481e-01
    z[1,4,1]  R1460     -3.9077866077423096e-01
    z[1,4,1]  R1461     4.5883551239967346e-01
    z[1,4,1]  R1462     -2.5890287756919861e-01
    z[1,4,1]  R1463     1.8817149102687836e-01
    z[1,4,1]  R1464     -3.1648527830839157e-02
    z[1,4,1]  R1465     4.7781169414520264e-01
    z[1,4,1]  R1466     4.4560694694519043e-01
    z[1,4,1]  R1467     5.7730001211166382e-01
    z[1,4,1]  R1468     3.6223095655441284e-01
    z[1,4,1]  R1469     4.5222055912017822e-01
    z[1,4,1]  R1470     5.4885065555572510e-01
    z[1,4,1]  R1471     5.3115218877792358e-01
    z[1,4,1]  R1472     5.1203662157058716e-01
    z[1,4,1]  R1473     -3.8567224144935608e-01
    z[1,4,1]  R1474     -4.6898555010557175e-02
    z[1,4,1]  R1475     1.9691698253154755e-01
    z[1,4,1]  R1476     -3.3078789710998535e-01
    z[1,4,1]  R1477     -2.5322714447975159e-01
    z[1,4,1]  R1478     -0.521737277507782
    z[1,4,1]  R1479     2.8693714737892151e-01
    z[1,4,1]  R1480     -4.4296371936798096e-01
    z[1,4,1]  R1481     -6.5261906385421753e-01
    z[1,4,1]  R1482     5.0646450370550156e-02
    z[1,4,1]  R1483     -8.7560421228408813e-01
    z[1,4,1]  R1484     8.7547548115253448e-02
    z[1,4,1]  R1485     -5.1780784130096436e-01
    z[1,4,1]  R1486     -5.1614469289779663e-01
    z[1,4,1]  R1487     -1.3408043980598450e-01
    z[1,4,1]  R1488     -1.9141638278961182e-01
    z[1,4,1]  R1489     5.2375458180904388e-02
    z[1,4,1]  R1490     1.0893474519252777e-01
    z[1,4,1]  R1491     -1.1364394426345825e-01
    z[1,4,1]  R1492     -2.2669158875942230e-01
    z[1,4,1]  R1493     -0.592122495174408
    z[1,4,2]  R13       -1
    z[1,4,2]  R40       1
    z[1,4,2]  R1344     -1
    z[1,4,2]  R1345     1
    z[1,4,2]  R1354     0.410097599029541
    z[1,4,2]  R1355     1.9897668063640594e-01
    z[1,4,2]  R1356     3.2608810067176819e-01
    z[1,4,2]  R1357     3.4057784080505371e-01
    z[1,4,2]  R1358     3.6706885695457458e-01
    z[1,4,2]  R1359     2.4889845401048660e-02
    z[1,4,2]  R1360     7.7606640756130219e-02
    z[1,4,2]  R1361     4.7487378120422363e-01
    z[1,4,2]  R1362     2.1392826735973358e-01
    z[1,4,2]  R1363     3.6713370680809021e-01
    z[1,4,2]  R1364     1.0967803001403809e-01
    z[1,4,2]  R1365     -4.1845682263374329e-01
    z[1,4,2]  R1366     -1.2607865035533905e-01
    z[1,4,2]  R1367     -0.486369788646698
    z[1,4,2]  R1368     5.4819411039352417e-01
    z[1,4,2]  R1369     0.567703127861023
    z[1,4,2]  R1370     3.9514392614364624e-02
    z[1,4,2]  R1371     4.5630556344985962e-01
    z[1,4,2]  R1372     -2.2555316984653473e-01
    z[1,4,2]  R1373     3.5645312070846558e-01
    z[1,4,2]  R1374     -4.2175155878067017e-01
    z[1,4,2]  R1375     1.6420675441622734e-02
    z[1,4,2]  R1376     4.6600274741649628e-02
    z[1,4,2]  R1377     -1.8738220632076263e-01
    z[1,4,2]  R1378     1.6186399757862091e-01
    z[1,4,2]  R1379     1.7931106686592102e-01
    z[1,4,2]  R1380     -3.0865499377250671e-01
    z[1,4,2]  R1381     -7.1684408187866211e-01
    z[1,4,2]  R1382     5.0356465578079224e-01
    z[1,4,2]  R1383     -7.8330940008163452e-01
    z[1,4,2]  R1384     4.0173164010047913e-01
    z[1,4,2]  R1385     6.7916172742843628e-01
    z[1,4,2]  R1386     5.6552004814147949e-01
    z[1,4,2]  R1387     6.2351912260055542e-01
    z[1,4,2]  R1388     2.7996173501014709e-01
    z[1,4,2]  R1389     1.4014796912670135e-01
    z[1,4,2]  R1390     2.6978957653045654e-01
    z[1,4,2]  R1391     -1.8271125853061676e-01
    z[1,4,2]  R1392     -3.0887761712074280e-01
    z[1,4,2]  R1393     1.8305076658725739e-01
    z[1,4,2]  R1394     4.6575519442558289e-01
    z[1,4,2]  R1395     4.3002769351005554e-02
    z[1,4,2]  R1396     1.5302455425262451e-01
    z[1,4,2]  R1397     1.3386055361479521e-03
    z[1,4,2]  R1398     1.3925452530384064e-01
    z[1,4,2]  R1399     3.2627224922180176e-01
    z[1,4,2]  R1400     -7.9252235591411591e-02
    z[1,4,2]  R1401     4.8510608077049255e-01
    z[1,4,2]  R1402     -1.7540137469768524e-01
    z[1,4,2]  R1403     -1.7894359305500984e-02
    z[1,4,2]  R1404     -1.7448730766773224e-01
    z[1,4,2]  R1405     1.3207750022411346e-01
    z[1,4,2]  R1406     -3.6221626400947571e-01
    z[1,4,2]  R1407     1.9669516384601593e-01
    z[1,4,2]  R1408     4.0278702974319458e-01
    z[1,4,2]  R1409     -2.0718200504779816e-01
    z[1,4,2]  R1410     -3.5573190450668335e-01
    z[1,4,2]  R1411     -6.5912526845932007e-01
    z[1,4,2]  R1412     1.1744274944067001e-01
    z[1,4,2]  R1413     -7.6905059814453125e-01
    z[1,4,2]  R1414     -9.8168686032295227e-02
    z[1,4,2]  R1415     9.7359839128330350e-04
    z[1,4,2]  R1416     -1.1752710491418839e-01
    z[1,4,2]  R1417     1.9486773014068604e-01
    z[1,4,2]  R1418     -5.7592725753784180e-01
    z[1,4,2]  R1419     -0.561223030090332
    z[1,4,2]  R1420     -5.7908612489700317e-01
    z[1,4,2]  R1421     -2.6552328467369080e-01
    z[1,4,2]  R1422     -6.9777297973632812e-01
    z[1,4,2]  R1423     -7.7856051921844482e-01
    z[1,4,2]  R1424     -9.9403075873851776e-02
    z[1,4,2]  R1425     3.4059146046638489e-01
    z[1,4,2]  R1426     1.4632999897003174e-01
    z[1,4,2]  R1427     3.2667240500450134e-01
    z[1,4,2]  R1428     1.5998254716396332e-01
    z[1,4,2]  R1429     -2.1347789466381073e-01
    z[1,4,2]  R1430     2.0259141921997070e-01
    z[1,4,2]  R1431     -4.5913219451904297e-01
    z[1,4,2]  R1432     -5.9972470998764038e-01
    z[1,4,2]  R1433     -6.4753305912017822e-01
    z[1,4,2]  R1434     -3.3333367109298706e-01
    z[1,4,2]  R1435     3.7514597177505493e-01
    z[1,4,2]  R1436     -2.6433351635932922e-01
    z[1,4,2]  R1437     -7.7267253398895264e-01
    z[1,4,2]  R1438     -1.0950347036123276e-01
    z[1,4,2]  R1439     4.1314274072647095e-01
    z[1,4,2]  R1440     -2.7503243088722229e-01
    z[1,4,2]  R1441     -1.9831565022468567e-01
    z[1,4,2]  R1442     -8.4968388080596924e-02
    z[1,4,2]  R1443     -1.5004470944404602e-01
    z[1,4,2]  R1444     -0.174790620803833
    z[1,4,2]  R1445     3.1620880961418152e-01
    z[1,4,2]  R1446     -6.8193428218364716e-02
    z[1,4,2]  R1447     -6.0812151432037354e-01
    z[1,4,2]  R1448     -7.1764141321182251e-01
    z[1,4,2]  R1449     -8.1184077262878418e-01
    z[1,4,2]  R1450     -1.2061801552772522e-01
    z[1,4,2]  R1451     1.9096738100051880e-01
    z[1,4,2]  R1452     -2.4020045995712280e-01
    z[1,4,2]  R1453     -3.7953026592731476e-02
    z[1,4,2]  R1454     2.0658016204833984e-01
    z[1,4,2]  R1455     5.1609843969345093e-01
    z[1,4,2]  R1456     6.4757645130157471e-01
    z[1,4,2]  R1457     9.8929800093173981e-02
    z[1,4,2]  R1458     5.5037707090377808e-01
    z[1,4,2]  R1459     1.7464052140712738e-01
    z[1,4,2]  R1460     -2.3853220045566559e-01
    z[1,4,2]  R1461     5.0685471296310425e-01
    z[1,4,2]  R1462     2.4018318951129913e-01
    z[1,4,2]  R1463     9.5787599682807922e-02
    z[1,4,2]  R1464     -5.3479593992233276e-01
    z[1,4,2]  R1465     -5.9657585620880127e-01
    z[1,4,2]  R1466     -7.1719348430633545e-01
    z[1,4,2]  R1467     -4.3153610825538635e-01
    z[1,4,2]  R1468     -6.7312496900558472e-01
    z[1,4,2]  R1469     -6.3912689685821533e-01
    z[1,4,2]  R1470     -6.0853153467178345e-01
    z[1,4,2]  R1471     -4.1915518045425415e-01
    z[1,4,2]  R1472     -3.3209469914436340e-01
    z[1,4,2]  R1473     -8.0496203899383545e-01
    z[1,4,2]  R1474     -4.6399781107902527e-01
    z[1,4,2]  R1475     -5.1879197359085083e-01
    z[1,4,2]  R1476     -4.1803181171417236e-01
    z[1,4,2]  R1477     1.7579983174800873e-01
    z[1,4,2]  R1478     -2.2754608094692230e-01
    z[1,4,2]  R1479     -2.3996305465698242e-01
    z[1,4,2]  R1480     1.5741537511348724e-01
    z[1,4,2]  R1481     -4.3415728211402893e-01
    z[1,4,2]  R1482     0.576196551322937
    z[1,4,2]  R1483     -4.0394324064254761e-01
    z[1,4,2]  R1484     -0.0334198921918869
    z[1,4,2]  R1485     1.4081464707851410e-01
    z[1,4,2]  R1486     1.9569399952888489e-01
    z[1,4,2]  R1487     1.2754398584365845e-01
    z[1,4,2]  R1488     3.7761977314949036e-01
    z[1,4,2]  R1489     0.517429530620575
    z[1,4,2]  R1490     7.9806648194789886e-02
    z[1,4,2]  R1491     -7.7853941917419434e-01
    z[1,4,2]  R1492     -7.5481927394866943e-01
    z[1,4,2]  R1493     -3.2312935590744019e-01
    z[1,4,3]  R14       -1
    z[1,4,3]  R41       1
    z[1,4,3]  R1346     -1
    z[1,4,3]  R1347     1
    z[1,4,3]  R1354     -1.8432404100894928e-01
    z[1,4,3]  R1355     -5.1463800668716431e-01
    z[1,4,3]  R1356     -6.4134937524795532e-01
    z[1,4,3]  R1357     -4.0266942977905273e-01
    z[1,4,3]  R1358     -4.4890768826007843e-02
    z[1,4,3]  R1359     -4.6394917368888855e-01
    z[1,4,3]  R1360     -3.5040271282196045e-01
    z[1,4,3]  R1361     -8.3797693252563477e-02
    z[1,4,3]  R1362     -2.0538680255413055e-03
    z[1,4,3]  R1363     -3.6634132266044617e-01
    z[1,4,3]  R1364     2.8865441679954529e-01
    z[1,4,3]  R1365     3.6795396357774734e-02
    z[1,4,3]  R1366     -1.4961647987365723e-01
    z[1,4,3]  R1367     1.3712696731090546e-01
    z[1,4,3]  R1368     6.4623266458511353e-02
    z[1,4,3]  R1369     -9.1978013515472412e-02
    z[1,4,3]  R1370     5.1226603984832764e-01
    z[1,4,3]  R1371     -3.9801809191703796e-01
    z[1,4,3]  R1372     -6.0857552289962769e-01
    z[1,4,3]  R1373     -5.7703101634979248e-01
    z[1,4,3]  R1374     2.6602050662040710e-01
    z[1,4,3]  R1375     1.8930549919605255e-01
    z[1,4,3]  R1376     6.5145730972290039e-01
    z[1,4,3]  R1377     4.7060206532478333e-01
    z[1,4,3]  R1378     4.4231966137886047e-01
    z[1,4,3]  R1379     3.7852790951728821e-01
    z[1,4,3]  R1380     2.2586712241172791e-01
    z[1,4,3]  R1381     4.2727984488010406e-02
    z[1,4,3]  R1382     5.4297196865081787e-01
    z[1,4,3]  R1383     1.6417096555233002e-01
    z[1,4,3]  R1384     -4.0744277834892273e-01
    z[1,4,3]  R1385     -4.2608398199081421e-01
    z[1,4,3]  R1386     1.6876373440027237e-02
    z[1,4,3]  R1387     -5.5595141649246216e-01
    z[1,4,3]  R1388     0.510107696056366
    z[1,4,3]  R1389     2.4046397209167480e-01
    z[1,4,3]  R1390     -3.1315666437149048e-01
    z[1,4,3]  R1391     2.9579216241836548e-01
    z[1,4,3]  R1392     3.9032116532325745e-01
    z[1,4,3]  R1393     -7.2604638338088989e-01
    z[1,4,3]  R1394     -1.0772946476936340e-01
    z[1,4,3]  R1395     -7.8980810940265656e-02
    z[1,4,3]  R1396     1.8345648050308228e-01
    z[1,4,3]  R1397     3.1382623314857483e-01
    z[1,4,3]  R1398     1.4028945565223694e-01
    z[1,4,3]  R1399     -4.3615886569023132e-01
    z[1,4,3]  R1400     -4.3881252408027649e-01
    z[1,4,3]  R1401     1.0959044843912125e-01
    z[1,4,3]  R1402     4.7214669175446033e-03
    z[1,4,3]  R1403     -1.2928792834281921e-01
    z[1,4,3]  R1404     -1.7415136098861694e-01
    z[1,4,3]  R1405     7.4559003114700317e-02
    z[1,4,3]  R1406     -1.0413333028554916e-01
    z[1,4,3]  R1407     1.8462552130222321e-01
    z[1,4,3]  R1408     0.713071882724762
    z[1,4,3]  R1409     4.2764917016029358e-01
    z[1,4,3]  R1410     6.1980700492858887e-01
    z[1,4,3]  R1411     3.4250319004058838e-01
    z[1,4,3]  R1412     0.574138879776001
    z[1,4,3]  R1413     3.9793962240219116e-01
    z[1,4,3]  R1414     -6.0092996805906296e-02
    z[1,4,3]  R1415     0.777245819568634
    z[1,4,3]  R1416     4.5326781272888184e-01
    z[1,4,3]  R1417     2.7885380387306213e-01
    z[1,4,3]  R1418     3.5766753554344177e-01
    z[1,4,3]  R1419     3.2030284404754639e-01
    z[1,4,3]  R1420     3.1763064861297607e-01
    z[1,4,3]  R1421     3.8000747561454773e-01
    z[1,4,3]  R1422     1.2909834086894989e-01
    z[1,4,3]  R1423     -2.4669134616851807e-01
    z[1,4,3]  R1424     -2.9174787923693657e-03
    z[1,4,3]  R1425     -2.8880032896995544e-01
    z[1,4,3]  R1426     4.0354898571968079e-01
    z[1,4,3]  R1427     1.3501471281051636e-01
    z[1,4,3]  R1428     -4.7309798002243042e-01
    z[1,4,3]  R1429     -2.9963061213493347e-01
    z[1,4,3]  R1430     5.4995840787887573e-01
    z[1,4,3]  R1431     4.1433700919151306e-01
    z[1,4,3]  R1432     4.0481972694396973e-01
    z[1,4,3]  R1433     3.9746868610382080e-01
    z[1,4,3]  R1434     -2.1642296016216278e-01
    z[1,4,3]  R1435     6.3129258155822754e-01
    z[1,4,3]  R1436     4.3214264512062073e-01
    z[1,4,3]  R1437     3.4522926807403564e-01
    z[1,4,3]  R1438     4.1966402530670166e-01
    z[1,4,3]  R1439     3.2063734531402588e-01
    z[1,4,3]  R1440     -1.9523462653160095e-01
    z[1,4,3]  R1441     -5.5567425489425659e-01
    z[1,4,3]  R1442     -4.6835356950759888e-01
    z[1,4,3]  R1443     -4.9415045976638794e-01
    z[1,4,3]  R1444     -1.4836981892585754e-01
    z[1,4,3]  R1445     2.6959040760993958e-01
    z[1,4,3]  R1446     5.1917874813079834e-01
    z[1,4,3]  R1447     4.2698773741722107e-01
    z[1,4,3]  R1448     3.9615362882614136e-01
    z[1,4,3]  R1449     2.7314865589141846e-01
    z[1,4,3]  R1450     2.4443480372428894e-01
    z[1,4,3]  R1451     3.0787822604179382e-01
    z[1,4,3]  R1452     -5.2298015356063843e-01
    z[1,4,3]  R1453     -2.9256063699722290e-01
    z[1,4,3]  R1454     8.6531199514865875e-02
    z[1,4,3]  R1455     -5.8207309246063232e-01
    z[1,4,3]  R1456     -3.2332116365432739e-01
    z[1,4,3]  R1457     -1.1367462575435638e-01
    z[1,4,3]  R1458     -5.6814730167388916e-01
    z[1,4,3]  R1459     -3.3525720238685608e-01
    z[1,4,3]  R1460     -1.4600183814764023e-02
    z[1,4,3]  R1461     1.4067446812987328e-02
    z[1,4,3]  R1462     -8.1641548871994019e-01
    z[1,4,3]  R1463     -2.7022278308868408e-01
    z[1,4,3]  R1464     2.8645089268684387e-01
    z[1,4,3]  R1465     2.1356928348541260e-01
    z[1,4,3]  R1466     2.5227975845336914e-01
    z[1,4,3]  R1467     2.4058888852596283e-01
    z[1,4,3]  R1468     3.8215324282646179e-01
    z[1,4,3]  R1469     2.8521296381950378e-01
    z[1,4,3]  R1470     3.2522711157798767e-01
    z[1,4,3]  R1471     1.5950119495391846e-01
    z[1,4,3]  R1472     1.9036103785037994e-01
    z[1,4,3]  R1473     1.2890487909317017e-01
    z[1,4,3]  R1474     -3.3502274751663208e-01
    z[1,4,3]  R1475     5.0122457742691040e-01
    z[1,4,3]  R1476     3.6730784177780151e-01
    z[1,4,3]  R1477     -1.6924814879894257e-01
    z[1,4,3]  R1478     0.257690966129303
    z[1,4,3]  R1479     2.8943282365798950e-01
    z[1,4,3]  R1480     3.2569810282438993e-03
    z[1,4,3]  R1481     -3.0136129260063171e-01
    z[1,4,3]  R1482     7.9324334859848022e-02
    z[1,4,3]  R1483     -5.9938136488199234e-02
    z[1,4,3]  R1484     1.2918472290039062e-01
    z[1,4,3]  R1485     -5.5456644296646118e-01
    z[1,4,3]  R1486     -3.4559625387191772e-01
    z[1,4,3]  R1487     4.1245266795158386e-01
    z[1,4,3]  R1488     2.6273833587765694e-02
    z[1,4,3]  R1489     0.0676998421549797
    z[1,4,3]  R1490     3.5153287649154663e-01
    z[1,4,3]  R1491     4.7362190485000610e-01
    z[1,4,3]  R1492     2.2187928855419159e-01
    z[1,4,3]  R1493     3.4765559434890747e-01
    z[1,4,4]  R15       -1
    z[1,4,4]  R42       1
    z[1,4,4]  R1348     -1
    z[1,4,4]  R1349     1
    z[1,4,4]  R1354     1.3935865461826324e-01
    z[1,4,4]  R1355     -3.3856093883514404e-02
    z[1,4,4]  R1356     2.6250863075256348e-01
    z[1,4,4]  R1357     2.3572713136672974e-02
    z[1,4,4]  R1358     3.6814704537391663e-01
    z[1,4,4]  R1359     1.7465278506278992e-01
    z[1,4,4]  R1360     3.3341392874717712e-01
    z[1,4,4]  R1361     -7.4151274748146534e-04
    z[1,4,4]  R1362     2.8366908431053162e-01
    z[1,4,4]  R1363     5.4026669263839722e-01
    z[1,4,4]  R1364     -2.5515180826187134e-01
    z[1,4,4]  R1365     -2.7427467703819275e-01
    z[1,4,4]  R1366     -4.2240446805953979e-01
    z[1,4,4]  R1367     2.7976479381322861e-02
    z[1,4,4]  R1368     -1.7387789487838745e-01
    z[1,4,4]  R1369     -4.3352580070495605e-01
    z[1,4,4]  R1370     4.0010169148445129e-01
    z[1,4,4]  R1371     6.9646663963794708e-02
    z[1,4,4]  R1372     -5.0047025084495544e-02
    z[1,4,4]  R1373     -4.9046209454536438e-01
    z[1,4,4]  R1374     -3.5990697145462036e-01
    z[1,4,4]  R1375     9.0682750940322876e-01
    z[1,4,4]  R1376     6.9490909576416016e-01
    z[1,4,4]  R1377     7.9154515266418457e-01
    z[1,4,4]  R1378     7.2009402513504028e-01
    z[1,4,4]  R1379     7.0644110441207886e-01
    z[1,4,4]  R1380     8.1561535596847534e-01
    z[1,4,4]  R1381     -7.3069550096988678e-02
    z[1,4,4]  R1382     4.5287674665451050e-01
    z[1,4,4]  R1383     1.2962979078292847e-01
    z[1,4,4]  R1384     7.9473212361335754e-02
    z[1,4,4]  R1385     -1.3623583316802979e-01
    z[1,4,4]  R1386     2.1712502837181091e-01
    z[1,4,4]  R1387     8.6590774357318878e-02
    z[1,4,4]  R1388     7.9303735494613647e-01
    z[1,4,4]  R1389     -1.8995349109172821e-01
    z[1,4,4]  R1390     4.6238112449645996e-01
    z[1,4,4]  R1391     7.1789878606796265e-01
    z[1,4,4]  R1392     4.2612543702125549e-01
    z[1,4,4]  R1393     -2.2465731203556061e-01
    z[1,4,4]  R1394     1.1231165379285812e-01
    z[1,4,4]  R1395     4.8143625259399414e-01
    z[1,4,4]  R1396     3.1954690814018250e-01
    z[1,4,4]  R1397     3.2098862528800964e-01
    z[1,4,4]  R1398     -4.3746823072433472e-01
    z[1,4,4]  R1399     -1.7073710262775421e-01
    z[1,4,4]  R1400     -2.0819954574108124e-02
    z[1,4,4]  R1401     -0.0989551842212677
    z[1,4,4]  R1402     2.5268995761871338e-01
    z[1,4,4]  R1403     1.5949079394340515e-01
    z[1,4,4]  R1404     0.136853888630867
    z[1,4,4]  R1405     1.7795832455158234e-01
    z[1,4,4]  R1406     -1.3361354172229767e-01
    z[1,4,4]  R1407     8.3230429887771606e-01
    z[1,4,4]  R1408     4.1093739867210388e-01
    z[1,4,4]  R1409     5.3052127361297607e-01
    z[1,4,4]  R1410     5.1477003097534180e-01
    z[1,4,4]  R1411     5.0155729055404663e-01
    z[1,4,4]  R1412     2.9172223806381226e-01
    z[1,4,4]  R1413     4.8056846857070923e-01
    z[1,4,4]  R1414     2.6530984044075012e-01
    z[1,4,4]  R1415     5.4606622457504272e-01
    z[1,4,4]  R1416     7.8615558147430420e-01
    z[1,4,4]  R1417     6.2929922342300415e-01
    z[1,4,4]  R1418     2.6644504070281982e-01
    z[1,4,4]  R1419     -3.8745053112506866e-02
    z[1,4,4]  R1420     2.0344233512878418e-01
    z[1,4,4]  R1421     1.7360401153564453e-01
    z[1,4,4]  R1422     5.9470452368259430e-02
    z[1,4,4]  R1423     2.6736825704574585e-02
    z[1,4,4]  R1424     3.3870872855186462e-01
    z[1,4,4]  R1425     5.5658571422100067e-02
    z[1,4,4]  R1426     -7.8829256817698479e-03
    z[1,4,4]  R1427     7.8902617096900940e-02
    z[1,4,4]  R1428     1.1656423658132553e-01
    z[1,4,4]  R1429     2.7199275791645050e-02
    z[1,4,4]  R1430     4.8117798566818237e-01
    z[1,4,4]  R1431     3.0255025625228882e-01
    z[1,4,4]  R1432     3.3595968037843704e-02
    z[1,4,4]  R1433     1.6369393467903137e-01
    z[1,4,4]  R1434     -2.9842811822891235e-01
    z[1,4,4]  R1435     5.3670382499694824e-01
    z[1,4,4]  R1436     4.7548791766166687e-01
    z[1,4,4]  R1437     2.9210817813873291e-01
    z[1,4,4]  R1438     4.8938098549842834e-01
    z[1,4,4]  R1439     3.6667466163635254e-01
    z[1,4,4]  R1440     -3.0993974208831787e-01
    z[1,4,4]  R1441     -2.1801907569169998e-02
    z[1,4,4]  R1442     -6.2543079257011414e-02
    z[1,4,4]  R1443     -2.3602099716663361e-01
    z[1,4,4]  R1444     8.2893833518028259e-02
    z[1,4,4]  R1445     2.8686946630477905e-01
    z[1,4,4]  R1446     7.8496611118316650e-01
    z[1,4,4]  R1447     1.9304936751723289e-02
    z[1,4,4]  R1448     0.449378103017807
    z[1,4,4]  R1449     -3.3246347308158875e-01
    z[1,4,4]  R1450     -1.7195332795381546e-02
    z[1,4,4]  R1451     2.4461318552494049e-01
    z[1,4,4]  R1452     1.0814021341502666e-02
    z[1,4,4]  R1453     1.1211378872394562e-01
    z[1,4,4]  R1454     -5.9527806937694550e-02
    z[1,4,4]  R1455     -4.2494454979896545e-01
    z[1,4,4]  R1456     1.4411987364292145e-01
    z[1,4,4]  R1457     -5.6752490997314453e-01
    z[1,4,4]  R1458     0.381523460149765
    z[1,4,4]  R1459     5.0421410799026489e-01
    z[1,4,4]  R1460     4.7919169068336487e-01
    z[1,4,4]  R1461     4.1130978614091873e-02
    z[1,4,4]  R1462     -8.1844948232173920e-02
    z[1,4,4]  R1463     -1.9448215141892433e-02
    z[1,4,4]  R1464     3.3866535872220993e-02
    z[1,4,4]  R1465     6.8474814295768738e-02
    z[1,4,4]  R1466     5.6055169552564621e-02
    z[1,4,4]  R1467     -8.0082856118679047e-02
    z[1,4,4]  R1468     -8.5795380175113678e-02
    z[1,4,4]  R1469     -2.0354405045509338e-01
    z[1,4,4]  R1470     -2.2154681384563446e-01
    z[1,4,4]  R1471     -2.5517880916595459e-01
    z[1,4,4]  R1472     5.2798591786995530e-04
    z[1,4,4]  R1473     -1.6653573513031006e-01
    z[1,4,4]  R1474     -0.0630049929022789
    z[1,4,4]  R1475     5.7364720851182938e-03
    z[1,4,4]  R1476     1.0685495287179947e-01
    z[1,4,4]  R1477     -1.5308807790279388e-01
    z[1,4,4]  R1478     -1.3211238384246826e-01
    z[1,4,4]  R1479     6.2557297945022583e-01
    z[1,4,4]  R1480     -0.349031537771225
    z[1,4,4]  R1481     3.6674781586043537e-04
    z[1,4,4]  R1482     9.4423428177833557e-02
    z[1,4,4]  R1483     -1.2037818878889084e-01
    z[1,4,4]  R1484     -1.4261111617088318e-01
    z[1,4,4]  R1485     -7.8513838350772858e-02
    z[1,4,4]  R1486     1.2679681181907654e-01
    z[1,4,4]  R1487     7.3971919715404510e-02
    z[1,4,4]  R1488     -1.2156744301319122e-01
    z[1,4,4]  R1489     -4.2790338397026062e-02
    z[1,4,4]  R1490     6.2806212902069092e-01
    z[1,4,4]  R1491     1.0061531327664852e-02
    z[1,4,4]  R1492     1.9800265133380890e-01
    z[1,4,4]  R1493     1.0502353310585022e-01
    z[1,4,5]  R16       -1
    z[1,4,5]  R43       1
    z[1,4,5]  R1350     -1
    z[1,4,5]  R1351     1
    z[1,4,5]  R1354     -7.4647432565689087e-01
    z[1,4,5]  R1355     -6.3916242122650146e-01
    z[1,4,5]  R1356     -5.0884467363357544e-01
    z[1,4,5]  R1357     -7.2125869989395142e-01
    z[1,4,5]  R1358     -7.8055894374847412e-01
    z[1,4,5]  R1359     -6.7628163099288940e-01
    z[1,4,5]  R1360     -7.5406205654144287e-01
    z[1,4,5]  R1361     -5.4106724262237549e-01
    z[1,4,5]  R1362     -7.7640181779861450e-01
    z[1,4,5]  R1363     -3.3120352029800415e-01
    z[1,4,5]  R1364     -1.7839916050434113e-01
    z[1,4,5]  R1365     3.4148350358009338e-02
    z[1,4,5]  R1366     1.8258308991789818e-02
    z[1,4,5]  R1367     -1.8633460998535156e-01
    z[1,4,5]  R1368     -1.9224444031715393e-01
    z[1,4,5]  R1369     1.1763998866081238e-01
    z[1,4,5]  R1370     2.6581385731697083e-01
    z[1,4,5]  R1371     -3.4957072138786316e-01
    z[1,4,5]  R1372     9.1608978807926178e-02
    z[1,4,5]  R1373     4.0881808847188950e-02
    z[1,4,5]  R1374     2.3601700365543365e-01
    z[1,4,5]  R1375     1.3677023351192474e-01
    z[1,4,5]  R1376     7.3405399918556213e-02
    z[1,4,5]  R1377     1.0969126969575882e-01
    z[1,4,5]  R1378     9.2714056372642517e-02
    z[1,4,5]  R1379     1.4815928041934967e-01
    z[1,4,5]  R1380     2.1618127822875977e-01
    z[1,4,5]  R1381     8.9850440621376038e-02
    z[1,4,5]  R1382     3.2188418507575989e-01
    z[1,4,5]  R1383     1.1667750775814056e-02
    z[1,4,5]  R1384     3.9937481284141541e-01
    z[1,4,5]  R1385     -8.7309010326862335e-02
    z[1,4,5]  R1386     2.4414394795894623e-01
    z[1,4,5]  R1387     2.3820179700851440e-01
    z[1,4,5]  R1388     1.0241446644067764e-01
    z[1,4,5]  R1389     4.2090556025505066e-01
    z[1,4,5]  R1390     -6.4658693969249725e-02
    z[1,4,5]  R1391     -1.1355581879615784e-01
    z[1,4,5]  R1392     1.5739759802818298e-01
    z[1,4,5]  R1393     2.3948132991790771e-01
    z[1,4,5]  R1394     2.2364287078380585e-01
    z[1,4,5]  R1395     1.7969799041748047e-01
    z[1,4,5]  R1396     -3.2613289356231689e-01
    z[1,4,5]  R1397     4.9317643046379089e-01
    z[1,4,5]  R1398     3.1518206000328064e-01
    z[1,4,5]  R1399     -3.0196252465248108e-01
    z[1,4,5]  R1400     2.6776146888732910e-01
    z[1,4,5]  R1401     3.0875065922737122e-01
    z[1,4,5]  R1402     1.9810175895690918e-01
    z[1,4,5]  R1403     4.8662075400352478e-01
    z[1,4,5]  R1404     1.3925476372241974e-01
    z[1,4,5]  R1405     4.4187238812446594e-01
    z[1,4,5]  R1406     3.6108088493347168e-01
    z[1,4,5]  R1407     4.4546341896057129e-01
    z[1,4,5]  R1408     1.2333232164382935e-01
    z[1,4,5]  R1409     -1.0340360924601555e-02
    z[1,4,5]  R1410     2.5306472182273865e-01
    z[1,4,5]  R1411     3.0567046254873276e-02
    z[1,4,5]  R1412     1.1456538736820221e-01
    z[1,4,5]  R1413     4.9303401261568069e-02
    z[1,4,5]  R1414     4.6101510524749756e-01
    z[1,4,5]  R1415     3.7257452495396137e-03
    z[1,4,5]  R1416     1.2055249512195587e-01
    z[1,4,5]  R1417     1.0165440291166306e-01
    z[1,4,5]  R1418     -3.0589890480041504e-01
    z[1,4,5]  R1419     -1.5219344198703766e-01
    z[1,4,5]  R1420     -8.9321933686733246e-02
    z[1,4,5]  R1421     -6.7859692499041557e-03
    z[1,4,5]  R1422     -1.3576747849583626e-02
    z[1,4,5]  R1423     1.4903441071510315e-01
    z[1,4,5]  R1424     -0.248980313539505
    z[1,4,5]  R1425     -0.105091892182827
    z[1,4,5]  R1426     4.3572276830673218e-01
    z[1,4,5]  R1427     -5.9681254625320435e-01
    z[1,4,5]  R1428     -4.2099773883819580e-01
    z[1,4,5]  R1429     4.4694775342941284e-01
    z[1,4,5]  R1430     2.5101962685585022e-01
    z[1,4,5]  R1431     -1.2519478797912598e-01
    z[1,4,5]  R1432     -2.3776248097419739e-01
    z[1,4,5]  R1433     -8.8280171155929565e-02
    z[1,4,5]  R1434     -1.3381315767765045e-01
    z[1,4,5]  R1435     2.9748940467834473e-01
    z[1,4,5]  R1436     4.6417381614446640e-02
    z[1,4,5]  R1437     -8.5791319608688354e-02
    z[1,4,5]  R1438     -1.8986134231090546e-01
    z[1,4,5]  R1439     1.2778806686401367e-01
    z[1,4,5]  R1440     0.00913998018950224
    z[1,4,5]  R1441     1.4865861833095551e-01
    z[1,4,5]  R1442     -2.4004525039345026e-03
    z[1,4,5]  R1443     -2.4128738045692444e-01
    z[1,4,5]  R1444     0.412727415561676
    z[1,4,5]  R1445     2.9499068856239319e-01
    z[1,4,5]  R1446     2.1359564363956451e-01
    z[1,4,5]  R1447     -1.1896307766437531e-01
    z[1,4,5]  R1448     2.3534636944532394e-02
    z[1,4,5]  R1449     -1.2104593962430954e-01
    z[1,4,5]  R1450     6.8074040114879608e-02
    z[1,4,5]  R1451     1.6482903063297272e-01
    z[1,4,5]  R1452     -8.3766825497150421e-02
    z[1,4,5]  R1453     -2.2390339523553848e-02
    z[1,4,5]  R1454     -2.1922864019870758e-01
    z[1,4,5]  R1455     -1.3864994049072266e-02
    z[1,4,5]  R1456     9.8382443189620972e-02
    z[1,4,5]  R1457     -3.9890626072883606e-01
    z[1,4,5]  R1458     2.2245287895202637e-01
    z[1,4,5]  R1459     -1.1194667965173721e-01
    z[1,4,5]  R1460     -0.370022714138031
    z[1,4,5]  R1461     0.0323251374065876
    z[1,4,5]  R1462     2.7211108803749084e-01
    z[1,4,5]  R1463     -3.1022295355796814e-01
    z[1,4,5]  R1464     3.7785702943801880e-01
    z[1,4,5]  R1465     1.9872845709323883e-01
    z[1,4,5]  R1466     2.5526142120361328e-01
    z[1,4,5]  R1467     2.6845550537109375e-01
    z[1,4,5]  R1468     1.2860564887523651e-01
    z[1,4,5]  R1469     2.4986462295055389e-01
    z[1,4,5]  R1470     -3.5493888426572084e-03
    z[1,4,5]  R1471     2.2794951498508453e-01
    z[1,4,5]  R1472     0.0433090478181839
    z[1,4,5]  R1473     2.3948150873184204e-01
    z[1,4,5]  R1474     5.0294625759124756e-01
    z[1,4,5]  R1475     -7.3644906282424927e-02
    z[1,4,5]  R1476     4.1580373048782349e-01
    z[1,4,5]  R1477     -7.5626122951507568e-01
    z[1,4,5]  R1478     -1.0397802293300629e-01
    z[1,4,5]  R1479     5.0789028406143188e-01
    z[1,4,5]  R1480     -5.9557819366455078e-01
    z[1,4,5]  R1481     2.0194037258625031e-01
    z[1,4,5]  R1482     -7.8010231256484985e-01
    z[1,4,5]  R1483     -1.3690859079360962e-01
    z[1,4,5]  R1484     1.3491770625114441e-01
    z[1,4,5]  R1485     -1.1217781901359558e-01
    z[1,4,5]  R1486     -3.0806851387023926e-01
    z[1,4,5]  R1487     5.2376675605773926e-01
    z[1,4,5]  R1488     -8.8750118017196655e-01
    z[1,4,5]  R1489     -0.826915442943573
    z[1,4,5]  R1490     6.7276149988174438e-01
    z[1,4,5]  R1491     2.2474014759063721e-01
    z[1,4,5]  R1492     3.0902171134948730e-01
    z[1,4,5]  R1493     1.7537845671176910e-01
    z[1,4,6]  R17       -1
    z[1,4,6]  R44       1
    z[1,4,6]  R1352     -1
    z[1,4,6]  R1353     1
    z[1,4,6]  R1354     1.5904265642166138e-01
    z[1,4,6]  R1355     0.271445095539093
    z[1,4,6]  R1356     -1.3883425295352936e-01
    z[1,4,6]  R1357     2.8788670897483826e-01
    z[1,4,6]  R1358     9.2242740094661713e-02
    z[1,4,6]  R1359     -1.1773692071437836e-01
    z[1,4,6]  R1360     -0.304904043674469
    z[1,4,6]  R1361     -3.5347026586532593e-01
    z[1,4,6]  R1362     -3.7749823927879333e-01
    z[1,4,6]  R1363     1.2803323566913605e-01
    z[1,4,6]  R1364     2.3802106082439423e-01
    z[1,4,6]  R1365     2.0687267184257507e-01
    z[1,4,6]  R1366     -1.9543178379535675e-01
    z[1,4,6]  R1367     -5.0599705427885056e-02
    z[1,4,6]  R1368     -2.8501942753791809e-01
    z[1,4,6]  R1369     -4.4072084128856659e-02
    z[1,4,6]  R1370     3.5985404253005981e-01
    z[1,4,6]  R1371     -2.4825769662857056e-01
    z[1,4,6]  R1372     -4.9248144030570984e-01
    z[1,4,6]  R1373     -2.6498025655746460e-01
    z[1,4,6]  R1374     1.8578261137008667e-01
    z[1,4,6]  R1375     -0.0825931504368782
    z[1,4,6]  R1376     9.1572798788547516e-02
    z[1,4,6]  R1377     3.6711718887090683e-02
    z[1,4,6]  R1378     2.3696108162403107e-01
    z[1,4,6]  R1379     4.5238483697175980e-02
    z[1,4,6]  R1380     -3.4410390257835388e-01
    z[1,4,6]  R1381     -0.0334925651550293
    z[1,4,6]  R1382     -4.7413217835128307e-03
    z[1,4,6]  R1383     -1.4855190180242062e-02
    z[1,4,6]  R1384     -1.7784331738948822e-01
    z[1,4,6]  R1385     1.5596219897270203e-01
    z[1,4,6]  R1386     -2.1742123365402222e-01
    z[1,4,6]  R1387     -3.1197572126984596e-02
    z[1,4,6]  R1388     -9.3162119388580322e-02
    z[1,4,6]  R1389     1.5060979127883911e-01
    z[1,4,6]  R1390     -3.0172318220138550e-02
    z[1,4,6]  R1391     1.1491342447698116e-02
    z[1,4,6]  R1392     -6.6568199545145035e-03
    z[1,4,6]  R1393     1.2094780057668686e-01
    z[1,4,6]  R1394     3.0671152472496033e-01
    z[1,4,6]  R1395     1.8265551328659058e-01
    z[1,4,6]  R1396     -3.7411868572235107e-01
    z[1,4,6]  R1397     2.1233037114143372e-01
    z[1,4,6]  R1398     0.196168914437294
    z[1,4,6]  R1399     -3.9702009409666061e-02
    z[1,4,6]  R1400     2.5907030701637268e-01
    z[1,4,6]  R1401     -2.2752623260021210e-01
    z[1,4,6]  R1402     -4.2170169949531555e-01
    z[1,4,6]  R1403     -1.9631689786911011e-01
    z[1,4,6]  R1404     -6.1951391398906708e-02
    z[1,4,6]  R1405     1.1733530461788177e-01
    z[1,4,6]  R1406     -4.0632402896881104e-01
    z[1,4,6]  R1407     -6.6393963992595673e-02
    z[1,4,6]  R1408     3.7370380759239197e-01
    z[1,4,6]  R1409     -2.9392614960670471e-01
    z[1,4,6]  R1410     -1.1798671633005142e-01
    z[1,4,6]  R1411     1.8293111026287079e-01
    z[1,4,6]  R1412     -3.6410754919052124e-01
    z[1,4,6]  R1413     -1.0908308625221252e-01
    z[1,4,6]  R1414     2.6725763082504272e-01
    z[1,4,6]  R1415     2.5766745209693909e-01
    z[1,4,6]  R1416     -3.0579122900962830e-01
    z[1,4,6]  R1417     -5.7885181903839111e-01
    z[1,4,6]  R1418     1.6591729223728180e-01
    z[1,4,6]  R1419     1.4609168469905853e-01
    z[1,4,6]  R1420     -5.5366444587707520e-01
    z[1,4,6]  R1421     -3.5493856668472290e-01
    z[1,4,6]  R1422     -0.546783983707428
    z[1,4,6]  R1423     -2.9336306452751160e-01
    z[1,4,6]  R1424     -6.3115954399108887e-02
    z[1,4,6]  R1425     -4.1935643553733826e-01
    z[1,4,6]  R1426     5.7996802031993866e-02
    z[1,4,6]  R1427     -1.8123584985733032e-01
    z[1,4,6]  R1428     -0.336314857006073
    z[1,4,6]  R1429     -3.0428001284599304e-01
    z[1,4,6]  R1430     -3.0388179421424866e-01
    z[1,4,6]  R1431     -1.1459008604288101e-01
    z[1,4,6]  R1432     -3.3831059932708740e-02
    z[1,4,6]  R1433     3.8647550344467163e-01
    z[1,4,6]  R1434     -1.0314249992370605e-01
    z[1,4,6]  R1435     7.8031592071056366e-02
    z[1,4,6]  R1436     -2.4493908509612083e-02
    z[1,4,6]  R1437     -2.7924704551696777e-01
    z[1,4,6]  R1438     6.3042402267456055e-02
    z[1,4,6]  R1439     -3.0630344152450562e-01
    z[1,4,6]  R1440     -5.7962872087955475e-02
    z[1,4,6]  R1441     -2.0928554236888885e-01
    z[1,4,6]  R1442     1.4468098059296608e-02
    z[1,4,6]  R1443     3.2767906785011292e-02
    z[1,4,6]  R1444     -7.0363827049732208e-02
    z[1,4,6]  R1445     1.9452148675918579e-01
    z[1,4,6]  R1446     -3.8339901715517044e-02
    z[1,4,6]  R1447     3.0110573768615723e-01
    z[1,4,6]  R1448     2.4829675257205963e-01
    z[1,4,6]  R1449     -2.5787854194641113e-01
    z[1,4,6]  R1450     3.1721785664558411e-01
    z[1,4,6]  R1451     -6.0341215133666992e-01
    z[1,4,6]  R1452     5.3015735000371933e-02
    z[1,4,6]  R1453     1.1071027070283890e-01
    z[1,4,6]  R1454     -3.8992151618003845e-01
    z[1,4,6]  R1455     8.6179308593273163e-02
    z[1,4,6]  R1456     0.301705539226532
    z[1,4,6]  R1457     0.00955789815634489
    z[1,4,6]  R1458     -1.8492631614208221e-01
    z[1,4,6]  R1459     -3.4744119644165039e-01
    z[1,4,6]  R1460     -3.4499862790107727e-01
    z[1,4,6]  R1461     4.4494986534118652e-01
    z[1,4,6]  R1462     -0.299773633480072
    z[1,4,6]  R1463     -7.2330847382545471e-02
    z[1,4,6]  R1464     4.8853579163551331e-01
    z[1,4,6]  R1465     -1.9156420603394508e-02
    z[1,4,6]  R1466     -0.0973849669098854
    z[1,4,6]  R1467     -4.6267926692962646e-02
    z[1,4,6]  R1468     1.5173251926898956e-01
    z[1,4,6]  R1469     -0.065963514149189
    z[1,4,6]  R1470     -0.0146268829703331
    z[1,4,6]  R1471     4.1553181409835815e-01
    z[1,4,6]  R1472     4.4460281729698181e-01
    z[1,4,6]  R1473     -0.0810999944806099
    z[1,4,6]  R1474     0.0471709668636322
    z[1,4,6]  R1475     3.6713933944702148e-01
    z[1,4,6]  R1476     5.4234504699707031e-01
    z[1,4,6]  R1477     -5.2987277507781982e-01
    z[1,4,6]  R1478     0.671161413192749
    z[1,4,6]  R1479     3.8942303508520126e-02
    z[1,4,6]  R1480     0.429162859916687
    z[1,4,6]  R1481     -3.7207847833633423e-01
    z[1,4,6]  R1482     -1.8802908062934875e-01
    z[1,4,6]  R1483     1.5293040312826633e-02
    z[1,4,6]  R1484     6.8283146619796753e-01
    z[1,4,6]  R1485     4.6395670622587204e-02
    z[1,4,6]  R1486     -5.4667526483535767e-01
    z[1,4,6]  R1487     -0.588240921497345
    z[1,4,6]  R1488     -1.2923638522624969e-01
    z[1,4,6]  R1489     -7.4335299432277679e-03
    z[1,4,6]  R1490     -2.7590328827500343e-02
    z[1,4,6]  R1491     3.6730885505676270e-02
    z[1,4,6]  R1492     -2.9367044568061829e-01
    z[1,4,6]  R1493     2.2171714901924133e-01
    z[4,1,0]  R11       1
    z[4,1,0]  R38       -1
    z[4,1,0]  R1494     -1
    z[4,1,0]  R1495     1
    z[4,1,0]  R1508     7.2173547744750977e-01
    z[4,1,0]  R1509     -2.6034882664680481e-01
    z[4,1,0]  R1510     -8.8026374578475952e-02
    z[4,1,0]  R1511     7.0207589864730835e-01
    z[4,1,0]  R1512     1.3437853753566742e-01
    z[4,1,0]  R1513     6.1883461475372314e-01
    z[4,1,0]  R1514     5.5191999673843384e-01
    z[4,1,0]  R1515     5.7589358091354370e-01
    z[4,1,0]  R1516     1.9529409706592560e-01
    z[4,1,0]  R1517     8.8348609209060669e-01
    z[4,1,0]  R1518     0.498344749212265
    z[4,1,0]  R1519     -5.7064223289489746e-01
    z[4,1,0]  R1520     -3.8162621855735779e-01
    z[4,1,0]  R1521     -5.8480417728424072e-01
    z[4,1,0]  R1522     -4.7194001078605652e-01
    z[4,1,0]  R1523     -4.4435703754425049e-01
    z[4,1,0]  R1524     -4.1637751460075378e-01
    z[4,1,0]  R1525     -4.7644710540771484e-01
    z[4,1,0]  R1526     -6.2589657306671143e-01
    z[4,1,0]  R1527     -3.0824321508407593e-01
    z[4,1,0]  R1528     6.4118367433547974e-01
    z[4,1,0]  R1529     5.4827427864074707e-01
    z[4,1,0]  R1530     3.2010135054588318e-01
    z[4,1,0]  R1531     1.3908789493143559e-02
    z[4,1,0]  R1532     3.6178115010261536e-01
    z[4,1,0]  R1533     3.5426384210586548e-01
    z[4,1,0]  R1534     3.4391263127326965e-01
    z[4,1,0]  R1535     -3.3993339538574219e-01
    z[4,1,0]  R1536     -0.0794341191649437
    z[4,1,0]  R1537     -1.8189454078674316e-01
    z[4,1,0]  R1538     6.8536871671676636e-01
    z[4,1,0]  R1539     6.1935573816299438e-01
    z[4,1,0]  R1540     -4.0746080875396729e-01
    z[4,1,0]  R1541     4.1207635402679443e-01
    z[4,1,0]  R1542     -3.0557766556739807e-02
    z[4,1,0]  R1543     1.9815362989902496e-01
    z[4,1,0]  R1544     -1.0177161544561386e-01
    z[4,1,0]  R1545     -3.2355093955993652e-01
    z[4,1,0]  R1546     -3.2967633008956909e-01
    z[4,1,0]  R1547     -5.7720702886581421e-01
    z[4,1,0]  R1548     2.7963241934776306e-01
    z[4,1,0]  R1549     3.4242463111877441e-01
    z[4,1,0]  R1550     2.7918154001235962e-01
    z[4,1,0]  R1551     1.7188704013824463e-01
    z[4,1,0]  R1552     2.6724824309349060e-01
    z[4,1,0]  R1553     3.3592095971107483e-01
    z[4,1,0]  R1554     2.6670613884925842e-01
    z[4,1,0]  R1555     2.9679268598556519e-01
    z[4,1,0]  R1556     3.2342132925987244e-01
    z[4,1,0]  R1557     4.2374247312545776e-01
    z[4,1,0]  R1558     5.6757301092147827e-01
    z[4,1,0]  R1559     4.6850016713142395e-01
    z[4,1,0]  R1560     6.9135004281997681e-01
    z[4,1,0]  R1561     5.3372144699096680e-01
    z[4,1,0]  R1562     6.4588135480880737e-01
    z[4,1,0]  R1563     5.4391831159591675e-01
    z[4,1,0]  R1564     2.6483288407325745e-01
    z[4,1,0]  R1565     1.2983353435993195e-01
    z[4,1,0]  R1566     3.0205753445625305e-01
    z[4,1,0]  R1567     -2.7663335204124451e-02
    z[4,1,0]  R1568     4.8140409588813782e-01
    z[4,1,0]  R1569     -3.3962267637252808e-01
    z[4,1,0]  R1570     -9.4367347657680511e-02
    z[4,1,0]  R1571     -2.3696716129779816e-01
    z[4,1,0]  R1572     -4.0758627653121948e-01
    z[4,1,0]  R1573     -3.8331297039985657e-01
    z[4,1,0]  R1574     1.3147702813148499e-01
    z[4,1,0]  R1575     -6.6205447912216187e-01
    z[4,1,0]  R1576     0.0634799376130104
    z[4,1,0]  R1577     -4.9066832661628723e-01
    z[4,1,0]  R1578     2.5178718566894531e-01
    z[4,1,0]  R1579     -1.9391223788261414e-01
    z[4,1,0]  R1580     4.9170383810997009e-01
    z[4,1,0]  R1581     -2.4322444200515747e-01
    z[4,1,0]  R1582     1.0009628534317017e-01
    z[4,1,0]  R1583     4.7080019116401672e-01
    z[4,1,0]  R1584     -1.3195669651031494e-01
    z[4,1,0]  R1585     1.1216656118631363e-01
    z[4,1,0]  R1586     5.4910188913345337e-01
    z[4,1,0]  R1587     -3.1269797682762146e-01
    z[4,1,0]  R1588     4.4816821813583374e-02
    z[4,1,0]  R1589     -2.6699263602495193e-02
    z[4,1,0]  R1590     5.7596504688262939e-01
    z[4,1,0]  R1591     3.8244676589965820e-01
    z[4,1,0]  R1592     7.2887712717056274e-01
    z[4,1,0]  R1593     1.1982088536024094e-01
    z[4,1,0]  R1594     -9.3095436692237854e-02
    z[4,1,0]  R1595     7.0091545581817627e-01
    z[4,1,0]  R1596     6.5625959634780884e-01
    z[4,1,0]  R1597     0.729515790939331
    z[4,1,0]  R1598     3.9137899875640869e-01
    z[4,1,0]  R1599     5.6989258527755737e-01
    z[4,1,0]  R1600     4.3833982944488525e-01
    z[4,1,0]  R1601     -0.166781947016716
    z[4,1,0]  R1602     -8.5881259292364120e-03
    z[4,1,0]  R1603     -1.9071486592292786e-01
    z[4,1,0]  R1604     2.8914827108383179e-01
    z[4,1,0]  R1605     -3.4472441673278809e-01
    z[4,1,0]  R1606     5.1635402441024780e-01
    z[4,1,0]  R1607     7.0207953453063965e-02
    z[4,1,0]  R1608     5.7533466815948486e-01
    z[4,1,0]  R1609     1.5542012453079224e-01
    z[4,1,0]  R1610     2.3176409304141998e-01
    z[4,1,0]  R1611     -1.0020636767148972e-01
    z[4,1,0]  R1612     -0.573139488697052
    z[4,1,0]  R1613     -1.4173206686973572e-01
    z[4,1,0]  R1614     -4.1580238938331604e-01
    z[4,1,0]  R1615     -7.9225033521652222e-01
    z[4,1,0]  R1616     -4.2027789354324341e-01
    z[4,1,0]  R1617     -3.3313852548599243e-01
    z[4,1,0]  R1618     2.9472494125366211e-01
    z[4,1,0]  R1619     4.7758859395980835e-01
    z[4,1,0]  R1620     0.695899486541748
    z[4,1,0]  R1621     4.3001008033752441e-01
    z[4,1,0]  R1622     1.0595851391553879e-01
    z[4,1,0]  R1623     5.8363842964172363e-01
    z[4,1,0]  R1624     0.500739574432373
    z[4,1,0]  R1625     -6.7276030778884888e-01
    z[4,1,0]  R1626     -0.639201819896698
    z[4,1,0]  R1627     -4.3315351009368896e-01
    z[4,1,0]  R1628     5.0770324468612671e-01
    z[4,1,0]  R1629     6.2168218195438385e-02
    z[4,1,0]  R1630     -7.0578551292419434e-01
    z[4,1,0]  R1631     -2.9588720202445984e-01
    z[4,1,0]  R1632     -4.6263718605041504e-01
    z[4,1,0]  R1633     -6.7708253860473633e-01
    z[4,1,0]  R1634     -4.0369123220443726e-01
    z[4,1,0]  R1635     -6.2100154161453247e-01
    z[4,1,0]  R1636     -7.3160064220428467e-01
    z[4,1,0]  R1637     -6.7369800806045532e-01
    z[4,1,0]  R1638     6.7131519317626953e-01
    z[4,1,0]  R1639     3.7447464466094971e-01
    z[4,1,0]  R1640     -2.2601333260536194e-01
    z[4,1,0]  R1641     -5.8531010150909424e-01
    z[4,1,0]  R1642     -2.4237510561943054e-01
    z[4,1,0]  R1643     -2.5561258196830750e-01
    z[4,1,0]  R1644     -8.8041287660598755e-01
    z[4,1,0]  R1645     -5.3718191385269165e-01
    z[4,1,0]  R1646     -7.6415562629699707e-01
    z[4,1,0]  R1647     -8.0009514093399048e-01
    z[4,1,1]  R12       1
    z[4,1,1]  R39       -1
    z[4,1,1]  R1496     -1
    z[4,1,1]  R1497     1
    z[4,1,1]  R1508     4.7464835643768311e-01
    z[4,1,1]  R1509     -3.7263244390487671e-01
    z[4,1,1]  R1510     -5.8896821737289429e-01
    z[4,1,1]  R1511     5.5480856448411942e-02
    z[4,1,1]  R1512     -0.356360524892807
    z[4,1,1]  R1513     -2.9439383745193481e-01
    z[4,1,1]  R1514     -3.9077866077423096e-01
    z[4,1,1]  R1515     4.5883551239967346e-01
    z[4,1,1]  R1516     -2.5890287756919861e-01
    z[4,1,1]  R1517     1.8817149102687836e-01
    z[4,1,1]  R1518     -3.1648527830839157e-02
    z[4,1,1]  R1519     4.7781169414520264e-01
    z[4,1,1]  R1520     4.4560694694519043e-01
    z[4,1,1]  R1521     5.7730001211166382e-01
    z[4,1,1]  R1522     3.6223095655441284e-01
    z[4,1,1]  R1523     4.5222055912017822e-01
    z[4,1,1]  R1524     5.4885065555572510e-01
    z[4,1,1]  R1525     5.3115218877792358e-01
    z[4,1,1]  R1526     5.1203662157058716e-01
    z[4,1,1]  R1527     -3.8567224144935608e-01
    z[4,1,1]  R1528     -4.6898555010557175e-02
    z[4,1,1]  R1529     1.9691698253154755e-01
    z[4,1,1]  R1530     -3.3078789710998535e-01
    z[4,1,1]  R1531     -2.5322714447975159e-01
    z[4,1,1]  R1532     -0.521737277507782
    z[4,1,1]  R1533     2.8693714737892151e-01
    z[4,1,1]  R1534     -4.4296371936798096e-01
    z[4,1,1]  R1535     -6.5261906385421753e-01
    z[4,1,1]  R1536     5.0646450370550156e-02
    z[4,1,1]  R1537     -8.7560421228408813e-01
    z[4,1,1]  R1538     8.7547548115253448e-02
    z[4,1,1]  R1539     -5.1780784130096436e-01
    z[4,1,1]  R1540     -5.1614469289779663e-01
    z[4,1,1]  R1541     -1.3408043980598450e-01
    z[4,1,1]  R1542     -1.9141638278961182e-01
    z[4,1,1]  R1543     5.2375458180904388e-02
    z[4,1,1]  R1544     1.0893474519252777e-01
    z[4,1,1]  R1545     -1.1364394426345825e-01
    z[4,1,1]  R1546     -2.2669158875942230e-01
    z[4,1,1]  R1547     -0.592122495174408
    z[4,1,1]  R1548     3.4309035539627075e-01
    z[4,1,1]  R1549     3.0812993645668030e-01
    z[4,1,1]  R1550     2.3934613168239594e-01
    z[4,1,1]  R1551     -2.9777586460113525e-01
    z[4,1,1]  R1552     -1.9624061882495880e-01
    z[4,1,1]  R1553     4.1178426146507263e-01
    z[4,1,1]  R1554     1.6529412567615509e-01
    z[4,1,1]  R1555     5.1155781745910645e-01
    z[4,1,1]  R1556     1.5445442497730255e-01
    z[4,1,1]  R1557     -3.6533939838409424e-01
    z[4,1,1]  R1558     -6.5492558479309082e-01
    z[4,1,1]  R1559     -6.9631791114807129e-01
    z[4,1,1]  R1560     -5.1652860641479492e-01
    z[4,1,1]  R1561     -6.4939856529235840e-01
    z[4,1,1]  R1562     -3.6016201972961426e-01
    z[4,1,1]  R1563     -4.1192224621772766e-01
    z[4,1,1]  R1564     -5.5285841226577759e-01
    z[4,1,1]  R1565     -6.5408545732498169e-01
    z[4,1,1]  R1566     -4.8382645845413208e-01
    z[4,1,1]  R1567     -4.7620588541030884e-01
    z[4,1,1]  R1568     0.547591507434845
    z[4,1,1]  R1569     2.6197345927357674e-02
    z[4,1,1]  R1570     2.6048806309700012e-01
    z[4,1,1]  R1571     2.1758790314197540e-01
    z[4,1,1]  R1572     1.6954356431961060e-01
    z[4,1,1]  R1573     3.9316490292549133e-01
    z[4,1,1]  R1574     -7.7843718230724335e-02
    z[4,1,1]  R1575     1.7736643552780151e-01
    z[4,1,1]  R1576     3.7261933088302612e-01
    z[4,1,1]  R1577     3.1868198513984680e-01
    z[4,1,1]  R1578     -6.4168584346771240e-01
    z[4,1,1]  R1579     -5.1873183250427246e-01
    z[4,1,1]  R1580     -5.3301793336868286e-01
    z[4,1,1]  R1581     -4.2163071036338806e-01
    z[4,1,1]  R1582     -5.7585906237363815e-02
    z[4,1,1]  R1583     6.8187665939331055e-01
    z[4,1,1]  R1584     -7.6996523141860962e-01
    z[4,1,1]  R1585     -5.8149510622024536e-01
    z[4,1,1]  R1586     4.9429732561111450e-01
    z[4,1,1]  R1587     -4.6810075640678406e-01
    z[4,1,1]  R1588     -7.8278720378875732e-01
    z[4,1,1]  R1589     -8.3292537927627563e-01
    z[4,1,1]  R1590     -5.1259505748748779e-01
    z[4,1,1]  R1591     -6.0324513912200928e-01
    z[4,1,1]  R1592     3.1696164608001709e-01
    z[4,1,1]  R1593     -7.5302451848983765e-01
    z[4,1,1]  R1594     -8.0823796987533569e-01
    z[4,1,1]  R1595     -3.2325261831283569e-01
    z[4,1,1]  R1596     -5.0754940509796143e-01
    z[4,1,1]  R1597     3.8729032874107361e-01
    z[4,1,1]  R1598     -8.6260598897933960e-01
    z[4,1,1]  R1599     6.4150685071945190e-01
    z[4,1,1]  R1600     5.9370237588882446e-01
    z[4,1,1]  R1601     -6.1903841793537140e-02
    z[4,1,1]  R1602     7.4042327702045441e-02
    z[4,1,1]  R1603     6.0816723108291626e-01
    z[4,1,1]  R1604     2.5047263503074646e-01
    z[4,1,1]  R1605     -2.0845349133014679e-01
    z[4,1,1]  R1606     3.9893460273742676e-01
    z[4,1,1]  R1607     3.3393295598216355e-04
    z[4,1,1]  R1608     5.4899090528488159e-01
    z[4,1,1]  R1609     -8.4485612809658051e-02
    z[4,1,1]  R1610     3.0647762119770050e-02
    z[4,1,1]  R1611     3.6442461609840393e-01
    z[4,1,1]  R1612     1.4070263504981995e-01
    z[4,1,1]  R1613     0.718567967414856
    z[4,1,1]  R1614     -1.8699440360069275e-01
    z[4,1,1]  R1615     3.5574089735746384e-02
    z[4,1,1]  R1616     1.3084031641483307e-01
    z[4,1,1]  R1617     -3.3618080615997314e-01
    z[4,1,1]  R1618     -0.850028932094574
    z[4,1,1]  R1619     -6.1846506595611572e-01
    z[4,1,1]  R1620     -3.7172517180442810e-01
    z[4,1,1]  R1621     -5.4303795099258423e-01
    z[4,1,1]  R1622     -6.5986555814743042e-01
    z[4,1,1]  R1623     4.8054805397987366e-01
    z[4,1,1]  R1624     1.3738648593425751e-01
    z[4,1,1]  R1625     2.1112720668315887e-01
    z[4,1,1]  R1626     -9.5226854085922241e-02
    z[4,1,1]  R1627     2.2615295648574829e-01
    z[4,1,1]  R1628     -6.8314230442047119e-01
    z[4,1,1]  R1629     2.7245259284973145e-01
    z[4,1,1]  R1630     -1.2807795405387878e-01
    z[4,1,1]  R1631     1.5993210673332214e-01
    z[4,1,1]  R1632     5.6421858072280884e-01
    z[4,1,1]  R1633     1.5317335724830627e-01
    z[4,1,1]  R1634     7.8978991508483887e-01
    z[4,1,1]  R1635     4.4707828760147095e-01
    z[4,1,1]  R1636     4.8379644751548767e-01
    z[4,1,1]  R1637     4.0550419688224792e-01
    z[4,1,1]  R1638     5.6089580059051514e-01
    z[4,1,1]  R1639     -6.9278383255004883e-01
    z[4,1,1]  R1640     1.0703387856483459e-01
    z[4,1,1]  R1641     9.6009485423564911e-03
    z[4,1,1]  R1642     -7.1844294667243958e-02
    z[4,1,1]  R1643     -9.6338622272014618e-02
    z[4,1,1]  R1644     0.212177112698555
    z[4,1,1]  R1645     -3.5925975441932678e-01
    z[4,1,1]  R1646     2.7371007204055786e-01
    z[4,1,1]  R1647     4.9748173356056213e-01
    z[4,1,2]  R13       1
    z[4,1,2]  R40       -1
    z[4,1,2]  R1498     -1
    z[4,1,2]  R1499     1
    z[4,1,2]  R1508     2.0658016204833984e-01
    z[4,1,2]  R1509     5.1609843969345093e-01
    z[4,1,2]  R1510     6.4757645130157471e-01
    z[4,1,2]  R1511     9.8929800093173981e-02
    z[4,1,2]  R1512     5.5037707090377808e-01
    z[4,1,2]  R1513     1.7464052140712738e-01
    z[4,1,2]  R1514     -2.3853220045566559e-01
    z[4,1,2]  R1515     5.0685471296310425e-01
    z[4,1,2]  R1516     2.4018318951129913e-01
    z[4,1,2]  R1517     9.5787599682807922e-02
    z[4,1,2]  R1518     -5.3479593992233276e-01
    z[4,1,2]  R1519     -5.9657585620880127e-01
    z[4,1,2]  R1520     -7.1719348430633545e-01
    z[4,1,2]  R1521     -4.3153610825538635e-01
    z[4,1,2]  R1522     -6.7312496900558472e-01
    z[4,1,2]  R1523     -6.3912689685821533e-01
    z[4,1,2]  R1524     -6.0853153467178345e-01
    z[4,1,2]  R1525     -4.1915518045425415e-01
    z[4,1,2]  R1526     -3.3209469914436340e-01
    z[4,1,2]  R1527     -8.0496203899383545e-01
    z[4,1,2]  R1528     -4.6399781107902527e-01
    z[4,1,2]  R1529     -5.1879197359085083e-01
    z[4,1,2]  R1530     -4.1803181171417236e-01
    z[4,1,2]  R1531     1.7579983174800873e-01
    z[4,1,2]  R1532     -2.2754608094692230e-01
    z[4,1,2]  R1533     -2.3996305465698242e-01
    z[4,1,2]  R1534     1.5741537511348724e-01
    z[4,1,2]  R1535     -4.3415728211402893e-01
    z[4,1,2]  R1536     0.576196551322937
    z[4,1,2]  R1537     -4.0394324064254761e-01
    z[4,1,2]  R1538     -0.0334198921918869
    z[4,1,2]  R1539     1.4081464707851410e-01
    z[4,1,2]  R1540     1.9569399952888489e-01
    z[4,1,2]  R1541     1.2754398584365845e-01
    z[4,1,2]  R1542     3.7761977314949036e-01
    z[4,1,2]  R1543     0.517429530620575
    z[4,1,2]  R1544     7.9806648194789886e-02
    z[4,1,2]  R1545     -7.7853941917419434e-01
    z[4,1,2]  R1546     -7.5481927394866943e-01
    z[4,1,2]  R1547     -3.2312935590744019e-01
    z[4,1,2]  R1548     0.410097599029541
    z[4,1,2]  R1549     1.9897668063640594e-01
    z[4,1,2]  R1550     3.2608810067176819e-01
    z[4,1,2]  R1551     3.4057784080505371e-01
    z[4,1,2]  R1552     3.6706885695457458e-01
    z[4,1,2]  R1553     2.4889845401048660e-02
    z[4,1,2]  R1554     7.7606640756130219e-02
    z[4,1,2]  R1555     4.7487378120422363e-01
    z[4,1,2]  R1556     2.1392826735973358e-01
    z[4,1,2]  R1557     3.6713370680809021e-01
    z[4,1,2]  R1558     1.0967803001403809e-01
    z[4,1,2]  R1559     -4.1845682263374329e-01
    z[4,1,2]  R1560     -1.2607865035533905e-01
    z[4,1,2]  R1561     -0.486369788646698
    z[4,1,2]  R1562     5.4819411039352417e-01
    z[4,1,2]  R1563     0.567703127861023
    z[4,1,2]  R1564     3.9514392614364624e-02
    z[4,1,2]  R1565     4.5630556344985962e-01
    z[4,1,2]  R1566     -2.2555316984653473e-01
    z[4,1,2]  R1567     3.5645312070846558e-01
    z[4,1,2]  R1568     -4.2175155878067017e-01
    z[4,1,2]  R1569     1.6420675441622734e-02
    z[4,1,2]  R1570     4.6600274741649628e-02
    z[4,1,2]  R1571     -1.8738220632076263e-01
    z[4,1,2]  R1572     1.6186399757862091e-01
    z[4,1,2]  R1573     1.7931106686592102e-01
    z[4,1,2]  R1574     -3.0865499377250671e-01
    z[4,1,2]  R1575     -7.1684408187866211e-01
    z[4,1,2]  R1576     5.0356465578079224e-01
    z[4,1,2]  R1577     -7.8330940008163452e-01
    z[4,1,2]  R1578     4.0173164010047913e-01
    z[4,1,2]  R1579     6.7916172742843628e-01
    z[4,1,2]  R1580     5.6552004814147949e-01
    z[4,1,2]  R1581     6.2351912260055542e-01
    z[4,1,2]  R1582     2.7996173501014709e-01
    z[4,1,2]  R1583     1.4014796912670135e-01
    z[4,1,2]  R1584     2.6978957653045654e-01
    z[4,1,2]  R1585     -1.8271125853061676e-01
    z[4,1,2]  R1586     -3.0887761712074280e-01
    z[4,1,2]  R1587     1.8305076658725739e-01
    z[4,1,2]  R1588     4.6575519442558289e-01
    z[4,1,2]  R1589     4.3002769351005554e-02
    z[4,1,2]  R1590     1.5302455425262451e-01
    z[4,1,2]  R1591     1.3386055361479521e-03
    z[4,1,2]  R1592     1.3925452530384064e-01
    z[4,1,2]  R1593     3.2627224922180176e-01
    z[4,1,2]  R1594     -7.9252235591411591e-02
    z[4,1,2]  R1595     4.8510608077049255e-01
    z[4,1,2]  R1596     -1.7540137469768524e-01
    z[4,1,2]  R1597     -1.7894359305500984e-02
    z[4,1,2]  R1598     -1.7448730766773224e-01
    z[4,1,2]  R1599     1.3207750022411346e-01
    z[4,1,2]  R1600     -3.6221626400947571e-01
    z[4,1,2]  R1601     1.9669516384601593e-01
    z[4,1,2]  R1602     4.0278702974319458e-01
    z[4,1,2]  R1603     -2.0718200504779816e-01
    z[4,1,2]  R1604     -3.5573190450668335e-01
    z[4,1,2]  R1605     -6.5912526845932007e-01
    z[4,1,2]  R1606     1.1744274944067001e-01
    z[4,1,2]  R1607     -7.6905059814453125e-01
    z[4,1,2]  R1608     -9.8168686032295227e-02
    z[4,1,2]  R1609     9.7359839128330350e-04
    z[4,1,2]  R1610     -1.1752710491418839e-01
    z[4,1,2]  R1611     1.9486773014068604e-01
    z[4,1,2]  R1612     -5.7592725753784180e-01
    z[4,1,2]  R1613     -0.561223030090332
    z[4,1,2]  R1614     -5.7908612489700317e-01
    z[4,1,2]  R1615     -2.6552328467369080e-01
    z[4,1,2]  R1616     -6.9777297973632812e-01
    z[4,1,2]  R1617     -7.7856051921844482e-01
    z[4,1,2]  R1618     -9.9403075873851776e-02
    z[4,1,2]  R1619     3.4059146046638489e-01
    z[4,1,2]  R1620     1.4632999897003174e-01
    z[4,1,2]  R1621     3.2667240500450134e-01
    z[4,1,2]  R1622     1.5998254716396332e-01
    z[4,1,2]  R1623     -2.1347789466381073e-01
    z[4,1,2]  R1624     2.0259141921997070e-01
    z[4,1,2]  R1625     -4.5913219451904297e-01
    z[4,1,2]  R1626     -5.9972470998764038e-01
    z[4,1,2]  R1627     -6.4753305912017822e-01
    z[4,1,2]  R1628     -3.3333367109298706e-01
    z[4,1,2]  R1629     3.7514597177505493e-01
    z[4,1,2]  R1630     -2.6433351635932922e-01
    z[4,1,2]  R1631     -7.7267253398895264e-01
    z[4,1,2]  R1632     -1.0950347036123276e-01
    z[4,1,2]  R1633     4.1314274072647095e-01
    z[4,1,2]  R1634     -2.7503243088722229e-01
    z[4,1,2]  R1635     -1.9831565022468567e-01
    z[4,1,2]  R1636     -8.4968388080596924e-02
    z[4,1,2]  R1637     -1.5004470944404602e-01
    z[4,1,2]  R1638     -0.174790620803833
    z[4,1,2]  R1639     3.1620880961418152e-01
    z[4,1,2]  R1640     -6.8193428218364716e-02
    z[4,1,2]  R1641     -6.0812151432037354e-01
    z[4,1,2]  R1642     -7.1764141321182251e-01
    z[4,1,2]  R1643     -8.1184077262878418e-01
    z[4,1,2]  R1644     -1.2061801552772522e-01
    z[4,1,2]  R1645     1.9096738100051880e-01
    z[4,1,2]  R1646     -2.4020045995712280e-01
    z[4,1,2]  R1647     -3.7953026592731476e-02
    z[4,1,3]  R14       1
    z[4,1,3]  R41       -1
    z[4,1,3]  R1500     -1
    z[4,1,3]  R1501     1
    z[4,1,3]  R1508     8.6531199514865875e-02
    z[4,1,3]  R1509     -5.8207309246063232e-01
    z[4,1,3]  R1510     -3.2332116365432739e-01
    z[4,1,3]  R1511     -1.1367462575435638e-01
    z[4,1,3]  R1512     -5.6814730167388916e-01
    z[4,1,3]  R1513     -3.3525720238685608e-01
    z[4,1,3]  R1514     -1.4600183814764023e-02
    z[4,1,3]  R1515     1.4067446812987328e-02
    z[4,1,3]  R1516     -8.1641548871994019e-01
    z[4,1,3]  R1517     -2.7022278308868408e-01
    z[4,1,3]  R1518     2.8645089268684387e-01
    z[4,1,3]  R1519     2.1356928348541260e-01
    z[4,1,3]  R1520     2.5227975845336914e-01
    z[4,1,3]  R1521     2.4058888852596283e-01
    z[4,1,3]  R1522     3.8215324282646179e-01
    z[4,1,3]  R1523     2.8521296381950378e-01
    z[4,1,3]  R1524     3.2522711157798767e-01
    z[4,1,3]  R1525     1.5950119495391846e-01
    z[4,1,3]  R1526     1.9036103785037994e-01
    z[4,1,3]  R1527     1.2890487909317017e-01
    z[4,1,3]  R1528     -3.3502274751663208e-01
    z[4,1,3]  R1529     5.0122457742691040e-01
    z[4,1,3]  R1530     3.6730784177780151e-01
    z[4,1,3]  R1531     -1.6924814879894257e-01
    z[4,1,3]  R1532     0.257690966129303
    z[4,1,3]  R1533     2.8943282365798950e-01
    z[4,1,3]  R1534     3.2569810282438993e-03
    z[4,1,3]  R1535     -3.0136129260063171e-01
    z[4,1,3]  R1536     7.9324334859848022e-02
    z[4,1,3]  R1537     -5.9938136488199234e-02
    z[4,1,3]  R1538     1.2918472290039062e-01
    z[4,1,3]  R1539     -5.5456644296646118e-01
    z[4,1,3]  R1540     -3.4559625387191772e-01
    z[4,1,3]  R1541     4.1245266795158386e-01
    z[4,1,3]  R1542     2.6273833587765694e-02
    z[4,1,3]  R1543     0.0676998421549797
    z[4,1,3]  R1544     3.5153287649154663e-01
    z[4,1,3]  R1545     4.7362190485000610e-01
    z[4,1,3]  R1546     2.2187928855419159e-01
    z[4,1,3]  R1547     3.4765559434890747e-01
    z[4,1,3]  R1548     -1.8432404100894928e-01
    z[4,1,3]  R1549     -5.1463800668716431e-01
    z[4,1,3]  R1550     -6.4134937524795532e-01
    z[4,1,3]  R1551     -4.0266942977905273e-01
    z[4,1,3]  R1552     -4.4890768826007843e-02
    z[4,1,3]  R1553     -4.6394917368888855e-01
    z[4,1,3]  R1554     -3.5040271282196045e-01
    z[4,1,3]  R1555     -8.3797693252563477e-02
    z[4,1,3]  R1556     -2.0538680255413055e-03
    z[4,1,3]  R1557     -3.6634132266044617e-01
    z[4,1,3]  R1558     2.8865441679954529e-01
    z[4,1,3]  R1559     3.6795396357774734e-02
    z[4,1,3]  R1560     -1.4961647987365723e-01
    z[4,1,3]  R1561     1.3712696731090546e-01
    z[4,1,3]  R1562     6.4623266458511353e-02
    z[4,1,3]  R1563     -9.1978013515472412e-02
    z[4,1,3]  R1564     5.1226603984832764e-01
    z[4,1,3]  R1565     -3.9801809191703796e-01
    z[4,1,3]  R1566     -6.0857552289962769e-01
    z[4,1,3]  R1567     -5.7703101634979248e-01
    z[4,1,3]  R1568     2.6602050662040710e-01
    z[4,1,3]  R1569     1.8930549919605255e-01
    z[4,1,3]  R1570     6.5145730972290039e-01
    z[4,1,3]  R1571     4.7060206532478333e-01
    z[4,1,3]  R1572     4.4231966137886047e-01
    z[4,1,3]  R1573     3.7852790951728821e-01
    z[4,1,3]  R1574     2.2586712241172791e-01
    z[4,1,3]  R1575     4.2727984488010406e-02
    z[4,1,3]  R1576     5.4297196865081787e-01
    z[4,1,3]  R1577     1.6417096555233002e-01
    z[4,1,3]  R1578     -4.0744277834892273e-01
    z[4,1,3]  R1579     -4.2608398199081421e-01
    z[4,1,3]  R1580     1.6876373440027237e-02
    z[4,1,3]  R1581     -5.5595141649246216e-01
    z[4,1,3]  R1582     0.510107696056366
    z[4,1,3]  R1583     2.4046397209167480e-01
    z[4,1,3]  R1584     -3.1315666437149048e-01
    z[4,1,3]  R1585     2.9579216241836548e-01
    z[4,1,3]  R1586     3.9032116532325745e-01
    z[4,1,3]  R1587     -7.2604638338088989e-01
    z[4,1,3]  R1588     -1.0772946476936340e-01
    z[4,1,3]  R1589     -7.8980810940265656e-02
    z[4,1,3]  R1590     1.8345648050308228e-01
    z[4,1,3]  R1591     3.1382623314857483e-01
    z[4,1,3]  R1592     1.4028945565223694e-01
    z[4,1,3]  R1593     -4.3615886569023132e-01
    z[4,1,3]  R1594     -4.3881252408027649e-01
    z[4,1,3]  R1595     1.0959044843912125e-01
    z[4,1,3]  R1596     4.7214669175446033e-03
    z[4,1,3]  R1597     -1.2928792834281921e-01
    z[4,1,3]  R1598     -1.7415136098861694e-01
    z[4,1,3]  R1599     7.4559003114700317e-02
    z[4,1,3]  R1600     -1.0413333028554916e-01
    z[4,1,3]  R1601     1.8462552130222321e-01
    z[4,1,3]  R1602     0.713071882724762
    z[4,1,3]  R1603     4.2764917016029358e-01
    z[4,1,3]  R1604     6.1980700492858887e-01
    z[4,1,3]  R1605     3.4250319004058838e-01
    z[4,1,3]  R1606     0.574138879776001
    z[4,1,3]  R1607     3.9793962240219116e-01
    z[4,1,3]  R1608     -6.0092996805906296e-02
    z[4,1,3]  R1609     0.777245819568634
    z[4,1,3]  R1610     4.5326781272888184e-01
    z[4,1,3]  R1611     2.7885380387306213e-01
    z[4,1,3]  R1612     3.5766753554344177e-01
    z[4,1,3]  R1613     3.2030284404754639e-01
    z[4,1,3]  R1614     3.1763064861297607e-01
    z[4,1,3]  R1615     3.8000747561454773e-01
    z[4,1,3]  R1616     1.2909834086894989e-01
    z[4,1,3]  R1617     -2.4669134616851807e-01
    z[4,1,3]  R1618     -2.9174787923693657e-03
    z[4,1,3]  R1619     -2.8880032896995544e-01
    z[4,1,3]  R1620     4.0354898571968079e-01
    z[4,1,3]  R1621     1.3501471281051636e-01
    z[4,1,3]  R1622     -4.7309798002243042e-01
    z[4,1,3]  R1623     -2.9963061213493347e-01
    z[4,1,3]  R1624     5.4995840787887573e-01
    z[4,1,3]  R1625     4.1433700919151306e-01
    z[4,1,3]  R1626     4.0481972694396973e-01
    z[4,1,3]  R1627     3.9746868610382080e-01
    z[4,1,3]  R1628     -2.1642296016216278e-01
    z[4,1,3]  R1629     6.3129258155822754e-01
    z[4,1,3]  R1630     4.3214264512062073e-01
    z[4,1,3]  R1631     3.4522926807403564e-01
    z[4,1,3]  R1632     4.1966402530670166e-01
    z[4,1,3]  R1633     3.2063734531402588e-01
    z[4,1,3]  R1634     -1.9523462653160095e-01
    z[4,1,3]  R1635     -5.5567425489425659e-01
    z[4,1,3]  R1636     -4.6835356950759888e-01
    z[4,1,3]  R1637     -4.9415045976638794e-01
    z[4,1,3]  R1638     -1.4836981892585754e-01
    z[4,1,3]  R1639     2.6959040760993958e-01
    z[4,1,3]  R1640     5.1917874813079834e-01
    z[4,1,3]  R1641     4.2698773741722107e-01
    z[4,1,3]  R1642     3.9615362882614136e-01
    z[4,1,3]  R1643     2.7314865589141846e-01
    z[4,1,3]  R1644     2.4443480372428894e-01
    z[4,1,3]  R1645     3.0787822604179382e-01
    z[4,1,3]  R1646     -5.2298015356063843e-01
    z[4,1,3]  R1647     -2.9256063699722290e-01
    z[4,1,4]  R15       1
    z[4,1,4]  R42       -1
    z[4,1,4]  R1502     -1
    z[4,1,4]  R1503     1
    z[4,1,4]  R1508     -5.9527806937694550e-02
    z[4,1,4]  R1509     -4.2494454979896545e-01
    z[4,1,4]  R1510     1.4411987364292145e-01
    z[4,1,4]  R1511     -5.6752490997314453e-01
    z[4,1,4]  R1512     0.381523460149765
    z[4,1,4]  R1513     5.0421410799026489e-01
    z[4,1,4]  R1514     4.7919169068336487e-01
    z[4,1,4]  R1515     4.1130978614091873e-02
    z[4,1,4]  R1516     -8.1844948232173920e-02
    z[4,1,4]  R1517     -1.9448215141892433e-02
    z[4,1,4]  R1518     3.3866535872220993e-02
    z[4,1,4]  R1519     6.8474814295768738e-02
    z[4,1,4]  R1520     5.6055169552564621e-02
    z[4,1,4]  R1521     -8.0082856118679047e-02
    z[4,1,4]  R1522     -8.5795380175113678e-02
    z[4,1,4]  R1523     -2.0354405045509338e-01
    z[4,1,4]  R1524     -2.2154681384563446e-01
    z[4,1,4]  R1525     -2.5517880916595459e-01
    z[4,1,4]  R1526     5.2798591786995530e-04
    z[4,1,4]  R1527     -1.6653573513031006e-01
    z[4,1,4]  R1528     -0.0630049929022789
    z[4,1,4]  R1529     5.7364720851182938e-03
    z[4,1,4]  R1530     1.0685495287179947e-01
    z[4,1,4]  R1531     -1.5308807790279388e-01
    z[4,1,4]  R1532     -1.3211238384246826e-01
    z[4,1,4]  R1533     6.2557297945022583e-01
    z[4,1,4]  R1534     -0.349031537771225
    z[4,1,4]  R1535     3.6674781586043537e-04
    z[4,1,4]  R1536     9.4423428177833557e-02
    z[4,1,4]  R1537     -1.2037818878889084e-01
    z[4,1,4]  R1538     -1.4261111617088318e-01
    z[4,1,4]  R1539     -7.8513838350772858e-02
    z[4,1,4]  R1540     1.2679681181907654e-01
    z[4,1,4]  R1541     7.3971919715404510e-02
    z[4,1,4]  R1542     -1.2156744301319122e-01
    z[4,1,4]  R1543     -4.2790338397026062e-02
    z[4,1,4]  R1544     6.2806212902069092e-01
    z[4,1,4]  R1545     1.0061531327664852e-02
    z[4,1,4]  R1546     1.9800265133380890e-01
    z[4,1,4]  R1547     1.0502353310585022e-01
    z[4,1,4]  R1548     1.3935865461826324e-01
    z[4,1,4]  R1549     -3.3856093883514404e-02
    z[4,1,4]  R1550     2.6250863075256348e-01
    z[4,1,4]  R1551     2.3572713136672974e-02
    z[4,1,4]  R1552     3.6814704537391663e-01
    z[4,1,4]  R1553     1.7465278506278992e-01
    z[4,1,4]  R1554     3.3341392874717712e-01
    z[4,1,4]  R1555     -7.4151274748146534e-04
    z[4,1,4]  R1556     2.8366908431053162e-01
    z[4,1,4]  R1557     5.4026669263839722e-01
    z[4,1,4]  R1558     -2.5515180826187134e-01
    z[4,1,4]  R1559     -2.7427467703819275e-01
    z[4,1,4]  R1560     -4.2240446805953979e-01
    z[4,1,4]  R1561     2.7976479381322861e-02
    z[4,1,4]  R1562     -1.7387789487838745e-01
    z[4,1,4]  R1563     -4.3352580070495605e-01
    z[4,1,4]  R1564     4.0010169148445129e-01
    z[4,1,4]  R1565     6.9646663963794708e-02
    z[4,1,4]  R1566     -5.0047025084495544e-02
    z[4,1,4]  R1567     -4.9046209454536438e-01
    z[4,1,4]  R1568     -3.5990697145462036e-01
    z[4,1,4]  R1569     9.0682750940322876e-01
    z[4,1,4]  R1570     6.9490909576416016e-01
    z[4,1,4]  R1571     7.9154515266418457e-01
    z[4,1,4]  R1572     7.2009402513504028e-01
    z[4,1,4]  R1573     7.0644110441207886e-01
    z[4,1,4]  R1574     8.1561535596847534e-01
    z[4,1,4]  R1575     -7.3069550096988678e-02
    z[4,1,4]  R1576     4.5287674665451050e-01
    z[4,1,4]  R1577     1.2962979078292847e-01
    z[4,1,4]  R1578     7.9473212361335754e-02
    z[4,1,4]  R1579     -1.3623583316802979e-01
    z[4,1,4]  R1580     2.1712502837181091e-01
    z[4,1,4]  R1581     8.6590774357318878e-02
    z[4,1,4]  R1582     7.9303735494613647e-01
    z[4,1,4]  R1583     -1.8995349109172821e-01
    z[4,1,4]  R1584     4.6238112449645996e-01
    z[4,1,4]  R1585     7.1789878606796265e-01
    z[4,1,4]  R1586     4.2612543702125549e-01
    z[4,1,4]  R1587     -2.2465731203556061e-01
    z[4,1,4]  R1588     1.1231165379285812e-01
    z[4,1,4]  R1589     4.8143625259399414e-01
    z[4,1,4]  R1590     3.1954690814018250e-01
    z[4,1,4]  R1591     3.2098862528800964e-01
    z[4,1,4]  R1592     -4.3746823072433472e-01
    z[4,1,4]  R1593     -1.7073710262775421e-01
    z[4,1,4]  R1594     -2.0819954574108124e-02
    z[4,1,4]  R1595     -0.0989551842212677
    z[4,1,4]  R1596     2.5268995761871338e-01
    z[4,1,4]  R1597     1.5949079394340515e-01
    z[4,1,4]  R1598     0.136853888630867
    z[4,1,4]  R1599     1.7795832455158234e-01
    z[4,1,4]  R1600     -1.3361354172229767e-01
    z[4,1,4]  R1601     8.3230429887771606e-01
    z[4,1,4]  R1602     4.1093739867210388e-01
    z[4,1,4]  R1603     5.3052127361297607e-01
    z[4,1,4]  R1604     5.1477003097534180e-01
    z[4,1,4]  R1605     5.0155729055404663e-01
    z[4,1,4]  R1606     2.9172223806381226e-01
    z[4,1,4]  R1607     4.8056846857070923e-01
    z[4,1,4]  R1608     2.6530984044075012e-01
    z[4,1,4]  R1609     5.4606622457504272e-01
    z[4,1,4]  R1610     7.8615558147430420e-01
    z[4,1,4]  R1611     6.2929922342300415e-01
    z[4,1,4]  R1612     2.6644504070281982e-01
    z[4,1,4]  R1613     -3.8745053112506866e-02
    z[4,1,4]  R1614     2.0344233512878418e-01
    z[4,1,4]  R1615     1.7360401153564453e-01
    z[4,1,4]  R1616     5.9470452368259430e-02
    z[4,1,4]  R1617     2.6736825704574585e-02
    z[4,1,4]  R1618     3.3870872855186462e-01
    z[4,1,4]  R1619     5.5658571422100067e-02
    z[4,1,4]  R1620     -7.8829256817698479e-03
    z[4,1,4]  R1621     7.8902617096900940e-02
    z[4,1,4]  R1622     1.1656423658132553e-01
    z[4,1,4]  R1623     2.7199275791645050e-02
    z[4,1,4]  R1624     4.8117798566818237e-01
    z[4,1,4]  R1625     3.0255025625228882e-01
    z[4,1,4]  R1626     3.3595968037843704e-02
    z[4,1,4]  R1627     1.6369393467903137e-01
    z[4,1,4]  R1628     -2.9842811822891235e-01
    z[4,1,4]  R1629     5.3670382499694824e-01
    z[4,1,4]  R1630     4.7548791766166687e-01
    z[4,1,4]  R1631     2.9210817813873291e-01
    z[4,1,4]  R1632     4.8938098549842834e-01
    z[4,1,4]  R1633     3.6667466163635254e-01
    z[4,1,4]  R1634     -3.0993974208831787e-01
    z[4,1,4]  R1635     -2.1801907569169998e-02
    z[4,1,4]  R1636     -6.2543079257011414e-02
    z[4,1,4]  R1637     -2.3602099716663361e-01
    z[4,1,4]  R1638     8.2893833518028259e-02
    z[4,1,4]  R1639     2.8686946630477905e-01
    z[4,1,4]  R1640     7.8496611118316650e-01
    z[4,1,4]  R1641     1.9304936751723289e-02
    z[4,1,4]  R1642     0.449378103017807
    z[4,1,4]  R1643     -3.3246347308158875e-01
    z[4,1,4]  R1644     -1.7195332795381546e-02
    z[4,1,4]  R1645     2.4461318552494049e-01
    z[4,1,4]  R1646     1.0814021341502666e-02
    z[4,1,4]  R1647     1.1211378872394562e-01
    z[4,1,5]  R16       1
    z[4,1,5]  R43       -1
    z[4,1,5]  R1504     -1
    z[4,1,5]  R1505     1
    z[4,1,5]  R1508     -2.1922864019870758e-01
    z[4,1,5]  R1509     -1.3864994049072266e-02
    z[4,1,5]  R1510     9.8382443189620972e-02
    z[4,1,5]  R1511     -3.9890626072883606e-01
    z[4,1,5]  R1512     2.2245287895202637e-01
    z[4,1,5]  R1513     -1.1194667965173721e-01
    z[4,1,5]  R1514     -0.370022714138031
    z[4,1,5]  R1515     0.0323251374065876
    z[4,1,5]  R1516     2.7211108803749084e-01
    z[4,1,5]  R1517     -3.1022295355796814e-01
    z[4,1,5]  R1518     3.7785702943801880e-01
    z[4,1,5]  R1519     1.9872845709323883e-01
    z[4,1,5]  R1520     2.5526142120361328e-01
    z[4,1,5]  R1521     2.6845550537109375e-01
    z[4,1,5]  R1522     1.2860564887523651e-01
    z[4,1,5]  R1523     2.4986462295055389e-01
    z[4,1,5]  R1524     -3.5493888426572084e-03
    z[4,1,5]  R1525     2.2794951498508453e-01
    z[4,1,5]  R1526     0.0433090478181839
    z[4,1,5]  R1527     2.3948150873184204e-01
    z[4,1,5]  R1528     5.0294625759124756e-01
    z[4,1,5]  R1529     -7.3644906282424927e-02
    z[4,1,5]  R1530     4.1580373048782349e-01
    z[4,1,5]  R1531     -7.5626122951507568e-01
    z[4,1,5]  R1532     -1.0397802293300629e-01
    z[4,1,5]  R1533     5.0789028406143188e-01
    z[4,1,5]  R1534     -5.9557819366455078e-01
    z[4,1,5]  R1535     2.0194037258625031e-01
    z[4,1,5]  R1536     -7.8010231256484985e-01
    z[4,1,5]  R1537     -1.3690859079360962e-01
    z[4,1,5]  R1538     1.3491770625114441e-01
    z[4,1,5]  R1539     -1.1217781901359558e-01
    z[4,1,5]  R1540     -3.0806851387023926e-01
    z[4,1,5]  R1541     5.2376675605773926e-01
    z[4,1,5]  R1542     -8.8750118017196655e-01
    z[4,1,5]  R1543     -0.826915442943573
    z[4,1,5]  R1544     6.7276149988174438e-01
    z[4,1,5]  R1545     2.2474014759063721e-01
    z[4,1,5]  R1546     3.0902171134948730e-01
    z[4,1,5]  R1547     1.7537845671176910e-01
    z[4,1,5]  R1548     -7.4647432565689087e-01
    z[4,1,5]  R1549     -6.3916242122650146e-01
    z[4,1,5]  R1550     -5.0884467363357544e-01
    z[4,1,5]  R1551     -7.2125869989395142e-01
    z[4,1,5]  R1552     -7.8055894374847412e-01
    z[4,1,5]  R1553     -6.7628163099288940e-01
    z[4,1,5]  R1554     -7.5406205654144287e-01
    z[4,1,5]  R1555     -5.4106724262237549e-01
    z[4,1,5]  R1556     -7.7640181779861450e-01
    z[4,1,5]  R1557     -3.3120352029800415e-01
    z[4,1,5]  R1558     -1.7839916050434113e-01
    z[4,1,5]  R1559     3.4148350358009338e-02
    z[4,1,5]  R1560     1.8258308991789818e-02
    z[4,1,5]  R1561     -1.8633460998535156e-01
    z[4,1,5]  R1562     -1.9224444031715393e-01
    z[4,1,5]  R1563     1.1763998866081238e-01
    z[4,1,5]  R1564     2.6581385731697083e-01
    z[4,1,5]  R1565     -3.4957072138786316e-01
    z[4,1,5]  R1566     9.1608978807926178e-02
    z[4,1,5]  R1567     4.0881808847188950e-02
    z[4,1,5]  R1568     2.3601700365543365e-01
    z[4,1,5]  R1569     1.3677023351192474e-01
    z[4,1,5]  R1570     7.3405399918556213e-02
    z[4,1,5]  R1571     1.0969126969575882e-01
    z[4,1,5]  R1572     9.2714056372642517e-02
    z[4,1,5]  R1573     1.4815928041934967e-01
    z[4,1,5]  R1574     2.1618127822875977e-01
    z[4,1,5]  R1575     8.9850440621376038e-02
    z[4,1,5]  R1576     3.2188418507575989e-01
    z[4,1,5]  R1577     1.1667750775814056e-02
    z[4,1,5]  R1578     3.9937481284141541e-01
    z[4,1,5]  R1579     -8.7309010326862335e-02
    z[4,1,5]  R1580     2.4414394795894623e-01
    z[4,1,5]  R1581     2.3820179700851440e-01
    z[4,1,5]  R1582     1.0241446644067764e-01
    z[4,1,5]  R1583     4.2090556025505066e-01
    z[4,1,5]  R1584     -6.4658693969249725e-02
    z[4,1,5]  R1585     -1.1355581879615784e-01
    z[4,1,5]  R1586     1.5739759802818298e-01
    z[4,1,5]  R1587     2.3948132991790771e-01
    z[4,1,5]  R1588     2.2364287078380585e-01
    z[4,1,5]  R1589     1.7969799041748047e-01
    z[4,1,5]  R1590     -3.2613289356231689e-01
    z[4,1,5]  R1591     4.9317643046379089e-01
    z[4,1,5]  R1592     3.1518206000328064e-01
    z[4,1,5]  R1593     -3.0196252465248108e-01
    z[4,1,5]  R1594     2.6776146888732910e-01
    z[4,1,5]  R1595     3.0875065922737122e-01
    z[4,1,5]  R1596     1.9810175895690918e-01
    z[4,1,5]  R1597     4.8662075400352478e-01
    z[4,1,5]  R1598     1.3925476372241974e-01
    z[4,1,5]  R1599     4.4187238812446594e-01
    z[4,1,5]  R1600     3.6108088493347168e-01
    z[4,1,5]  R1601     4.4546341896057129e-01
    z[4,1,5]  R1602     1.2333232164382935e-01
    z[4,1,5]  R1603     -1.0340360924601555e-02
    z[4,1,5]  R1604     2.5306472182273865e-01
    z[4,1,5]  R1605     3.0567046254873276e-02
    z[4,1,5]  R1606     1.1456538736820221e-01
    z[4,1,5]  R1607     4.9303401261568069e-02
    z[4,1,5]  R1608     4.6101510524749756e-01
    z[4,1,5]  R1609     3.7257452495396137e-03
    z[4,1,5]  R1610     1.2055249512195587e-01
    z[4,1,5]  R1611     1.0165440291166306e-01
    z[4,1,5]  R1612     -3.0589890480041504e-01
    z[4,1,5]  R1613     -1.5219344198703766e-01
    z[4,1,5]  R1614     -8.9321933686733246e-02
    z[4,1,5]  R1615     -6.7859692499041557e-03
    z[4,1,5]  R1616     -1.3576747849583626e-02
    z[4,1,5]  R1617     1.4903441071510315e-01
    z[4,1,5]  R1618     -0.248980313539505
    z[4,1,5]  R1619     -0.105091892182827
    z[4,1,5]  R1620     4.3572276830673218e-01
    z[4,1,5]  R1621     -5.9681254625320435e-01
    z[4,1,5]  R1622     -4.2099773883819580e-01
    z[4,1,5]  R1623     4.4694775342941284e-01
    z[4,1,5]  R1624     2.5101962685585022e-01
    z[4,1,5]  R1625     -1.2519478797912598e-01
    z[4,1,5]  R1626     -2.3776248097419739e-01
    z[4,1,5]  R1627     -8.8280171155929565e-02
    z[4,1,5]  R1628     -1.3381315767765045e-01
    z[4,1,5]  R1629     2.9748940467834473e-01
    z[4,1,5]  R1630     4.6417381614446640e-02
    z[4,1,5]  R1631     -8.5791319608688354e-02
    z[4,1,5]  R1632     -1.8986134231090546e-01
    z[4,1,5]  R1633     1.2778806686401367e-01
    z[4,1,5]  R1634     0.00913998018950224
    z[4,1,5]  R1635     1.4865861833095551e-01
    z[4,1,5]  R1636     -2.4004525039345026e-03
    z[4,1,5]  R1637     -2.4128738045692444e-01
    z[4,1,5]  R1638     0.412727415561676
    z[4,1,5]  R1639     2.9499068856239319e-01
    z[4,1,5]  R1640     2.1359564363956451e-01
    z[4,1,5]  R1641     -1.1896307766437531e-01
    z[4,1,5]  R1642     2.3534636944532394e-02
    z[4,1,5]  R1643     -1.2104593962430954e-01
    z[4,1,5]  R1644     6.8074040114879608e-02
    z[4,1,5]  R1645     1.6482903063297272e-01
    z[4,1,5]  R1646     -8.3766825497150421e-02
    z[4,1,5]  R1647     -2.2390339523553848e-02
    z[4,1,6]  R17       1
    z[4,1,6]  R44       -1
    z[4,1,6]  R1506     -1
    z[4,1,6]  R1507     1
    z[4,1,6]  R1508     -3.8992151618003845e-01
    z[4,1,6]  R1509     8.6179308593273163e-02
    z[4,1,6]  R1510     0.301705539226532
    z[4,1,6]  R1511     0.00955789815634489
    z[4,1,6]  R1512     -1.8492631614208221e-01
    z[4,1,6]  R1513     -3.4744119644165039e-01
    z[4,1,6]  R1514     -3.4499862790107727e-01
    z[4,1,6]  R1515     4.4494986534118652e-01
    z[4,1,6]  R1516     -0.299773633480072
    z[4,1,6]  R1517     -7.2330847382545471e-02
    z[4,1,6]  R1518     4.8853579163551331e-01
    z[4,1,6]  R1519     -1.9156420603394508e-02
    z[4,1,6]  R1520     -0.0973849669098854
    z[4,1,6]  R1521     -4.6267926692962646e-02
    z[4,1,6]  R1522     1.5173251926898956e-01
    z[4,1,6]  R1523     -0.065963514149189
    z[4,1,6]  R1524     -0.0146268829703331
    z[4,1,6]  R1525     4.1553181409835815e-01
    z[4,1,6]  R1526     4.4460281729698181e-01
    z[4,1,6]  R1527     -0.0810999944806099
    z[4,1,6]  R1528     0.0471709668636322
    z[4,1,6]  R1529     3.6713933944702148e-01
    z[4,1,6]  R1530     5.4234504699707031e-01
    z[4,1,6]  R1531     -5.2987277507781982e-01
    z[4,1,6]  R1532     0.671161413192749
    z[4,1,6]  R1533     3.8942303508520126e-02
    z[4,1,6]  R1534     0.429162859916687
    z[4,1,6]  R1535     -3.7207847833633423e-01
    z[4,1,6]  R1536     -1.8802908062934875e-01
    z[4,1,6]  R1537     1.5293040312826633e-02
    z[4,1,6]  R1538     6.8283146619796753e-01
    z[4,1,6]  R1539     4.6395670622587204e-02
    z[4,1,6]  R1540     -5.4667526483535767e-01
    z[4,1,6]  R1541     -0.588240921497345
    z[4,1,6]  R1542     -1.2923638522624969e-01
    z[4,1,6]  R1543     -7.4335299432277679e-03
    z[4,1,6]  R1544     -2.7590328827500343e-02
    z[4,1,6]  R1545     3.6730885505676270e-02
    z[4,1,6]  R1546     -2.9367044568061829e-01
    z[4,1,6]  R1547     2.2171714901924133e-01
    z[4,1,6]  R1548     1.5904265642166138e-01
    z[4,1,6]  R1549     0.271445095539093
    z[4,1,6]  R1550     -1.3883425295352936e-01
    z[4,1,6]  R1551     2.8788670897483826e-01
    z[4,1,6]  R1552     9.2242740094661713e-02
    z[4,1,6]  R1553     -1.1773692071437836e-01
    z[4,1,6]  R1554     -0.304904043674469
    z[4,1,6]  R1555     -3.5347026586532593e-01
    z[4,1,6]  R1556     -3.7749823927879333e-01
    z[4,1,6]  R1557     1.2803323566913605e-01
    z[4,1,6]  R1558     2.3802106082439423e-01
    z[4,1,6]  R1559     2.0687267184257507e-01
    z[4,1,6]  R1560     -1.9543178379535675e-01
    z[4,1,6]  R1561     -5.0599705427885056e-02
    z[4,1,6]  R1562     -2.8501942753791809e-01
    z[4,1,6]  R1563     -4.4072084128856659e-02
    z[4,1,6]  R1564     3.5985404253005981e-01
    z[4,1,6]  R1565     -2.4825769662857056e-01
    z[4,1,6]  R1566     -4.9248144030570984e-01
    z[4,1,6]  R1567     -2.6498025655746460e-01
    z[4,1,6]  R1568     1.8578261137008667e-01
    z[4,1,6]  R1569     -0.0825931504368782
    z[4,1,6]  R1570     9.1572798788547516e-02
    z[4,1,6]  R1571     3.6711718887090683e-02
    z[4,1,6]  R1572     2.3696108162403107e-01
    z[4,1,6]  R1573     4.5238483697175980e-02
    z[4,1,6]  R1574     -3.4410390257835388e-01
    z[4,1,6]  R1575     -0.0334925651550293
    z[4,1,6]  R1576     -4.7413217835128307e-03
    z[4,1,6]  R1577     -1.4855190180242062e-02
    z[4,1,6]  R1578     -1.7784331738948822e-01
    z[4,1,6]  R1579     1.5596219897270203e-01
    z[4,1,6]  R1580     -2.1742123365402222e-01
    z[4,1,6]  R1581     -3.1197572126984596e-02
    z[4,1,6]  R1582     -9.3162119388580322e-02
    z[4,1,6]  R1583     1.5060979127883911e-01
    z[4,1,6]  R1584     -3.0172318220138550e-02
    z[4,1,6]  R1585     1.1491342447698116e-02
    z[4,1,6]  R1586     -6.6568199545145035e-03
    z[4,1,6]  R1587     1.2094780057668686e-01
    z[4,1,6]  R1588     3.0671152472496033e-01
    z[4,1,6]  R1589     1.8265551328659058e-01
    z[4,1,6]  R1590     -3.7411868572235107e-01
    z[4,1,6]  R1591     2.1233037114143372e-01
    z[4,1,6]  R1592     0.196168914437294
    z[4,1,6]  R1593     -3.9702009409666061e-02
    z[4,1,6]  R1594     2.5907030701637268e-01
    z[4,1,6]  R1595     -2.2752623260021210e-01
    z[4,1,6]  R1596     -4.2170169949531555e-01
    z[4,1,6]  R1597     -1.9631689786911011e-01
    z[4,1,6]  R1598     -6.1951391398906708e-02
    z[4,1,6]  R1599     1.1733530461788177e-01
    z[4,1,6]  R1600     -4.0632402896881104e-01
    z[4,1,6]  R1601     -6.6393963992595673e-02
    z[4,1,6]  R1602     3.7370380759239197e-01
    z[4,1,6]  R1603     -2.9392614960670471e-01
    z[4,1,6]  R1604     -1.1798671633005142e-01
    z[4,1,6]  R1605     1.8293111026287079e-01
    z[4,1,6]  R1606     -3.6410754919052124e-01
    z[4,1,6]  R1607     -1.0908308625221252e-01
    z[4,1,6]  R1608     2.6725763082504272e-01
    z[4,1,6]  R1609     2.5766745209693909e-01
    z[4,1,6]  R1610     -3.0579122900962830e-01
    z[4,1,6]  R1611     -5.7885181903839111e-01
    z[4,1,6]  R1612     1.6591729223728180e-01
    z[4,1,6]  R1613     1.4609168469905853e-01
    z[4,1,6]  R1614     -5.5366444587707520e-01
    z[4,1,6]  R1615     -3.5493856668472290e-01
    z[4,1,6]  R1616     -0.546783983707428
    z[4,1,6]  R1617     -2.9336306452751160e-01
    z[4,1,6]  R1618     -6.3115954399108887e-02
    z[4,1,6]  R1619     -4.1935643553733826e-01
    z[4,1,6]  R1620     5.7996802031993866e-02
    z[4,1,6]  R1621     -1.8123584985733032e-01
    z[4,1,6]  R1622     -0.336314857006073
    z[4,1,6]  R1623     -3.0428001284599304e-01
    z[4,1,6]  R1624     -3.0388179421424866e-01
    z[4,1,6]  R1625     -1.1459008604288101e-01
    z[4,1,6]  R1626     -3.3831059932708740e-02
    z[4,1,6]  R1627     3.8647550344467163e-01
    z[4,1,6]  R1628     -1.0314249992370605e-01
    z[4,1,6]  R1629     7.8031592071056366e-02
    z[4,1,6]  R1630     -2.4493908509612083e-02
    z[4,1,6]  R1631     -2.7924704551696777e-01
    z[4,1,6]  R1632     6.3042402267456055e-02
    z[4,1,6]  R1633     -3.0630344152450562e-01
    z[4,1,6]  R1634     -5.7962872087955475e-02
    z[4,1,6]  R1635     -2.0928554236888885e-01
    z[4,1,6]  R1636     1.4468098059296608e-02
    z[4,1,6]  R1637     3.2767906785011292e-02
    z[4,1,6]  R1638     -7.0363827049732208e-02
    z[4,1,6]  R1639     1.9452148675918579e-01
    z[4,1,6]  R1640     -3.8339901715517044e-02
    z[4,1,6]  R1641     3.0110573768615723e-01
    z[4,1,6]  R1642     2.4829675257205963e-01
    z[4,1,6]  R1643     -2.5787854194641113e-01
    z[4,1,6]  R1644     3.1721785664558411e-01
    z[4,1,6]  R1645     -6.0341215133666992e-01
    z[4,1,6]  R1646     5.3015735000371933e-02
    z[4,1,6]  R1647     1.1071027070283890e-01
    z[1,5,0]  R11       -1
    z[1,5,0]  R47       1
    z[1,5,0]  R1648     -1
    z[1,5,0]  R1649     1
    z[1,5,0]  R1662     2.7963241934776306e-01
    z[1,5,0]  R1663     3.4242463111877441e-01
    z[1,5,0]  R1664     2.7918154001235962e-01
    z[1,5,0]  R1665     1.7188704013824463e-01
    z[1,5,0]  R1666     2.6724824309349060e-01
    z[1,5,0]  R1667     3.3592095971107483e-01
    z[1,5,0]  R1668     2.6670613884925842e-01
    z[1,5,0]  R1669     2.9679268598556519e-01
    z[1,5,0]  R1670     3.2342132925987244e-01
    z[1,5,0]  R1671     4.2374247312545776e-01
    z[1,5,0]  R1672     5.6757301092147827e-01
    z[1,5,0]  R1673     4.6850016713142395e-01
    z[1,5,0]  R1674     6.9135004281997681e-01
    z[1,5,0]  R1675     5.3372144699096680e-01
    z[1,5,0]  R1676     6.4588135480880737e-01
    z[1,5,0]  R1677     5.4391831159591675e-01
    z[1,5,0]  R1678     2.6483288407325745e-01
    z[1,5,0]  R1679     1.2983353435993195e-01
    z[1,5,0]  R1680     3.0205753445625305e-01
    z[1,5,0]  R1681     -2.7663335204124451e-02
    z[1,5,0]  R1682     4.8140409588813782e-01
    z[1,5,0]  R1683     -3.3962267637252808e-01
    z[1,5,0]  R1684     -9.4367347657680511e-02
    z[1,5,0]  R1685     -2.3696716129779816e-01
    z[1,5,0]  R1686     -4.0758627653121948e-01
    z[1,5,0]  R1687     -3.8331297039985657e-01
    z[1,5,0]  R1688     1.3147702813148499e-01
    z[1,5,0]  R1689     -6.6205447912216187e-01
    z[1,5,0]  R1690     0.0634799376130104
    z[1,5,0]  R1691     -4.9066832661628723e-01
    z[1,5,0]  R1692     2.5178718566894531e-01
    z[1,5,0]  R1693     -1.9391223788261414e-01
    z[1,5,0]  R1694     4.9170383810997009e-01
    z[1,5,0]  R1695     -2.4322444200515747e-01
    z[1,5,0]  R1696     1.0009628534317017e-01
    z[1,5,0]  R1697     4.7080019116401672e-01
    z[1,5,0]  R1698     -1.3195669651031494e-01
    z[1,5,0]  R1699     1.1216656118631363e-01
    z[1,5,0]  R1700     5.4910188913345337e-01
    z[1,5,0]  R1701     -3.1269797682762146e-01
    z[1,5,0]  R1702     4.4816821813583374e-02
    z[1,5,0]  R1703     -2.6699263602495193e-02
    z[1,5,0]  R1704     5.7596504688262939e-01
    z[1,5,0]  R1705     3.8244676589965820e-01
    z[1,5,0]  R1706     7.2887712717056274e-01
    z[1,5,0]  R1707     1.1982088536024094e-01
    z[1,5,0]  R1708     -9.3095436692237854e-02
    z[1,5,0]  R1709     7.0091545581817627e-01
    z[1,5,0]  R1710     6.5625959634780884e-01
    z[1,5,0]  R1711     0.729515790939331
    z[1,5,0]  R1712     3.9137899875640869e-01
    z[1,5,0]  R1713     5.6989258527755737e-01
    z[1,5,0]  R1714     4.3833982944488525e-01
    z[1,5,0]  R1715     -0.166781947016716
    z[1,5,0]  R1716     -8.5881259292364120e-03
    z[1,5,0]  R1717     -1.9071486592292786e-01
    z[1,5,0]  R1718     2.8914827108383179e-01
    z[1,5,0]  R1719     -3.4472441673278809e-01
    z[1,5,0]  R1720     5.1635402441024780e-01
    z[1,5,0]  R1721     7.0207953453063965e-02
    z[1,5,0]  R1722     5.7533466815948486e-01
    z[1,5,0]  R1723     1.5542012453079224e-01
    z[1,5,0]  R1724     2.3176409304141998e-01
    z[1,5,0]  R1725     -1.0020636767148972e-01
    z[1,5,0]  R1726     -0.573139488697052
    z[1,5,0]  R1727     -1.4173206686973572e-01
    z[1,5,0]  R1728     -4.1580238938331604e-01
    z[1,5,0]  R1729     -7.9225033521652222e-01
    z[1,5,0]  R1730     -4.2027789354324341e-01
    z[1,5,0]  R1731     -3.3313852548599243e-01
    z[1,5,0]  R1732     2.9472494125366211e-01
    z[1,5,0]  R1733     4.7758859395980835e-01
    z[1,5,0]  R1734     0.695899486541748
    z[1,5,0]  R1735     4.3001008033752441e-01
    z[1,5,0]  R1736     1.0595851391553879e-01
    z[1,5,0]  R1737     5.8363842964172363e-01
    z[1,5,0]  R1738     0.500739574432373
    z[1,5,0]  R1739     -6.7276030778884888e-01
    z[1,5,0]  R1740     -0.639201819896698
    z[1,5,0]  R1741     -4.3315351009368896e-01
    z[1,5,0]  R1742     5.0770324468612671e-01
    z[1,5,0]  R1743     6.2168218195438385e-02
    z[1,5,0]  R1744     -7.0578551292419434e-01
    z[1,5,0]  R1745     -2.9588720202445984e-01
    z[1,5,0]  R1746     -4.6263718605041504e-01
    z[1,5,0]  R1747     -6.7708253860473633e-01
    z[1,5,0]  R1748     -4.0369123220443726e-01
    z[1,5,0]  R1749     -6.2100154161453247e-01
    z[1,5,0]  R1750     -7.3160064220428467e-01
    z[1,5,0]  R1751     -6.7369800806045532e-01
    z[1,5,0]  R1752     6.7131519317626953e-01
    z[1,5,0]  R1753     3.7447464466094971e-01
    z[1,5,0]  R1754     -2.2601333260536194e-01
    z[1,5,0]  R1755     -5.8531010150909424e-01
    z[1,5,0]  R1756     -2.4237510561943054e-01
    z[1,5,0]  R1757     -2.5561258196830750e-01
    z[1,5,0]  R1758     -8.8041287660598755e-01
    z[1,5,0]  R1759     -5.3718191385269165e-01
    z[1,5,0]  R1760     -7.6415562629699707e-01
    z[1,5,0]  R1761     -8.0009514093399048e-01
    z[1,5,0]  R1762     0.465468168258667
    z[1,5,0]  R1763     4.8361030220985413e-01
    z[1,5,0]  R1764     3.9293155074119568e-01
    z[1,5,0]  R1765     4.5623803138732910e-01
    z[1,5,0]  R1766     6.6259825229644775e-01
    z[1,5,0]  R1767     4.4954261183738708e-01
    z[1,5,0]  R1768     -6.7470502853393555e-01
    z[1,5,0]  R1769     -6.7426276206970215e-01
    z[1,5,0]  R1770     -7.7380383014678955e-01
    z[1,5,0]  R1771     5.5530810356140137e-01
    z[1,5,0]  R1772     5.7968068122863770e-01
    z[1,5,0]  R1773     -3.3840614557266235e-01
    z[1,5,0]  R1774     -4.5139434933662415e-01
    z[1,5,0]  R1775     -0.545189619064331
    z[1,5,0]  R1776     -1.6080382466316223e-01
    z[1,5,0]  R1777     -1.4969871938228607e-01
    z[1,5,0]  R1778     -2.0674932003021240e-01
    z[1,5,0]  R1779     -1.6465358436107635e-01
    z[1,5,1]  R12       -1
    z[1,5,1]  R48       1
    z[1,5,1]  R1650     -1
    z[1,5,1]  R1651     1
    z[1,5,1]  R1662     3.4309035539627075e-01
    z[1,5,1]  R1663     3.0812993645668030e-01
    z[1,5,1]  R1664     2.3934613168239594e-01
    z[1,5,1]  R1665     -2.9777586460113525e-01
    z[1,5,1]  R1666     -1.9624061882495880e-01
    z[1,5,1]  R1667     4.1178426146507263e-01
    z[1,5,1]  R1668     1.6529412567615509e-01
    z[1,5,1]  R1669     5.1155781745910645e-01
    z[1,5,1]  R1670     1.5445442497730255e-01
    z[1,5,1]  R1671     -3.6533939838409424e-01
    z[1,5,1]  R1672     -6.5492558479309082e-01
    z[1,5,1]  R1673     -6.9631791114807129e-01
    z[1,5,1]  R1674     -5.1652860641479492e-01
    z[1,5,1]  R1675     -6.4939856529235840e-01
    z[1,5,1]  R1676     -3.6016201972961426e-01
    z[1,5,1]  R1677     -4.1192224621772766e-01
    z[1,5,1]  R1678     -5.5285841226577759e-01
    z[1,5,1]  R1679     -6.5408545732498169e-01
    z[1,5,1]  R1680     -4.8382645845413208e-01
    z[1,5,1]  R1681     -4.7620588541030884e-01
    z[1,5,1]  R1682     0.547591507434845
    z[1,5,1]  R1683     2.6197345927357674e-02
    z[1,5,1]  R1684     2.6048806309700012e-01
    z[1,5,1]  R1685     2.1758790314197540e-01
    z[1,5,1]  R1686     1.6954356431961060e-01
    z[1,5,1]  R1687     3.9316490292549133e-01
    z[1,5,1]  R1688     -7.7843718230724335e-02
    z[1,5,1]  R1689     1.7736643552780151e-01
    z[1,5,1]  R1690     3.7261933088302612e-01
    z[1,5,1]  R1691     3.1868198513984680e-01
    z[1,5,1]  R1692     -6.4168584346771240e-01
    z[1,5,1]  R1693     -5.1873183250427246e-01
    z[1,5,1]  R1694     -5.3301793336868286e-01
    z[1,5,1]  R1695     -4.2163071036338806e-01
    z[1,5,1]  R1696     -5.7585906237363815e-02
    z[1,5,1]  R1697     6.8187665939331055e-01
    z[1,5,1]  R1698     -7.6996523141860962e-01
    z[1,5,1]  R1699     -5.8149510622024536e-01
    z[1,5,1]  R1700     4.9429732561111450e-01
    z[1,5,1]  R1701     -4.6810075640678406e-01
    z[1,5,1]  R1702     -7.8278720378875732e-01
    z[1,5,1]  R1703     -8.3292537927627563e-01
    z[1,5,1]  R1704     -5.1259505748748779e-01
    z[1,5,1]  R1705     -6.0324513912200928e-01
    z[1,5,1]  R1706     3.1696164608001709e-01
    z[1,5,1]  R1707     -7.5302451848983765e-01
    z[1,5,1]  R1708     -8.0823796987533569e-01
    z[1,5,1]  R1709     -3.2325261831283569e-01
    z[1,5,1]  R1710     -5.0754940509796143e-01
    z[1,5,1]  R1711     3.8729032874107361e-01
    z[1,5,1]  R1712     -8.6260598897933960e-01
    z[1,5,1]  R1713     6.4150685071945190e-01
    z[1,5,1]  R1714     5.9370237588882446e-01
    z[1,5,1]  R1715     -6.1903841793537140e-02
    z[1,5,1]  R1716     7.4042327702045441e-02
    z[1,5,1]  R1717     6.0816723108291626e-01
    z[1,5,1]  R1718     2.5047263503074646e-01
    z[1,5,1]  R1719     -2.0845349133014679e-01
    z[1,5,1]  R1720     3.9893460273742676e-01
    z[1,5,1]  R1721     3.3393295598216355e-04
    z[1,5,1]  R1722     5.4899090528488159e-01
    z[1,5,1]  R1723     -8.4485612809658051e-02
    z[1,5,1]  R1724     3.0647762119770050e-02
    z[1,5,1]  R1725     3.6442461609840393e-01
    z[1,5,1]  R1726     1.4070263504981995e-01
    z[1,5,1]  R1727     0.718567967414856
    z[1,5,1]  R1728     -1.8699440360069275e-01
    z[1,5,1]  R1729     3.5574089735746384e-02
    z[1,5,1]  R1730     1.3084031641483307e-01
    z[1,5,1]  R1731     -3.3618080615997314e-01
    z[1,5,1]  R1732     -0.850028932094574
    z[1,5,1]  R1733     -6.1846506595611572e-01
    z[1,5,1]  R1734     -3.7172517180442810e-01
    z[1,5,1]  R1735     -5.4303795099258423e-01
    z[1,5,1]  R1736     -6.5986555814743042e-01
    z[1,5,1]  R1737     4.8054805397987366e-01
    z[1,5,1]  R1738     1.3738648593425751e-01
    z[1,5,1]  R1739     2.1112720668315887e-01
    z[1,5,1]  R1740     -9.5226854085922241e-02
    z[1,5,1]  R1741     2.2615295648574829e-01
    z[1,5,1]  R1742     -6.8314230442047119e-01
    z[1,5,1]  R1743     2.7245259284973145e-01
    z[1,5,1]  R1744     -1.2807795405387878e-01
    z[1,5,1]  R1745     1.5993210673332214e-01
    z[1,5,1]  R1746     5.6421858072280884e-01
    z[1,5,1]  R1747     1.5317335724830627e-01
    z[1,5,1]  R1748     7.8978991508483887e-01
    z[1,5,1]  R1749     4.4707828760147095e-01
    z[1,5,1]  R1750     4.8379644751548767e-01
    z[1,5,1]  R1751     4.0550419688224792e-01
    z[1,5,1]  R1752     5.6089580059051514e-01
    z[1,5,1]  R1753     -6.9278383255004883e-01
    z[1,5,1]  R1754     1.0703387856483459e-01
    z[1,5,1]  R1755     9.6009485423564911e-03
    z[1,5,1]  R1756     -7.1844294667243958e-02
    z[1,5,1]  R1757     -9.6338622272014618e-02
    z[1,5,1]  R1758     0.212177112698555
    z[1,5,1]  R1759     -3.5925975441932678e-01
    z[1,5,1]  R1760     2.7371007204055786e-01
    z[1,5,1]  R1761     4.9748173356056213e-01
    z[1,5,1]  R1762     -2.6089332997798920e-02
    z[1,5,1]  R1763     -1.7964828014373779e-01
    z[1,5,1]  R1764     -2.0432645082473755e-01
    z[1,5,1]  R1765     -0.0886748731136322
    z[1,5,1]  R1766     -9.4480365514755249e-02
    z[1,5,1]  R1767     8.1957143545150757e-01
    z[1,5,1]  R1768     -1.0136871039867401e-01
    z[1,5,1]  R1769     -1.5375743806362152e-01
    z[1,5,1]  R1770     -1.6285133361816406e-01
    z[1,5,1]  R1771     -2.9200801253318787e-01
    z[1,5,1]  R1772     2.3025064170360565e-01
    z[1,5,1]  R1773     3.2131013274192810e-01
    z[1,5,1]  R1774     5.4254125803709030e-02
    z[1,5,1]  R1775     -0.13618203997612
    z[1,5,1]  R1776     -4.6495974063873291e-01
    z[1,5,1]  R1777     1.3007128611207008e-02
    z[1,5,1]  R1778     2.0443606376647949e-01
    z[1,5,1]  R1779     2.2308218479156494e-01
    z[1,5,2]  R13       -1
    z[1,5,2]  R49       1
    z[1,5,2]  R1652     -1
    z[1,5,2]  R1653     1
    z[1,5,2]  R1662     0.410097599029541
    z[1,5,2]  R1663     1.9897668063640594e-01
    z[1,5,2]  R1664     3.2608810067176819e-01
    z[1,5,2]  R1665     3.4057784080505371e-01
    z[1,5,2]  R1666     3.6706885695457458e-01
    z[1,5,2]  R1667     2.4889845401048660e-02
    z[1,5,2]  R1668     7.7606640756130219e-02
    z[1,5,2]  R1669     4.7487378120422363e-01
    z[1,5,2]  R1670     2.1392826735973358e-01
    z[1,5,2]  R1671     3.6713370680809021e-01
    z[1,5,2]  R1672     1.0967803001403809e-01
    z[1,5,2]  R1673     -4.1845682263374329e-01
    z[1,5,2]  R1674     -1.2607865035533905e-01
    z[1,5,2]  R1675     -0.486369788646698
    z[1,5,2]  R1676     5.4819411039352417e-01
    z[1,5,2]  R1677     0.567703127861023
    z[1,5,2]  R1678     3.9514392614364624e-02
    z[1,5,2]  R1679     4.5630556344985962e-01
    z[1,5,2]  R1680     -2.2555316984653473e-01
    z[1,5,2]  R1681     3.5645312070846558e-01
    z[1,5,2]  R1682     -4.2175155878067017e-01
    z[1,5,2]  R1683     1.6420675441622734e-02
    z[1,5,2]  R1684     4.6600274741649628e-02
    z[1,5,2]  R1685     -1.8738220632076263e-01
    z[1,5,2]  R1686     1.6186399757862091e-01
    z[1,5,2]  R1687     1.7931106686592102e-01
    z[1,5,2]  R1688     -3.0865499377250671e-01
    z[1,5,2]  R1689     -7.1684408187866211e-01
    z[1,5,2]  R1690     5.0356465578079224e-01
    z[1,5,2]  R1691     -7.8330940008163452e-01
    z[1,5,2]  R1692     4.0173164010047913e-01
    z[1,5,2]  R1693     6.7916172742843628e-01
    z[1,5,2]  R1694     5.6552004814147949e-01
    z[1,5,2]  R1695     6.2351912260055542e-01
    z[1,5,2]  R1696     2.7996173501014709e-01
    z[1,5,2]  R1697     1.4014796912670135e-01
    z[1,5,2]  R1698     2.6978957653045654e-01
    z[1,5,2]  R1699     -1.8271125853061676e-01
    z[1,5,2]  R1700     -3.0887761712074280e-01
    z[1,5,2]  R1701     1.8305076658725739e-01
    z[1,5,2]  R1702     4.6575519442558289e-01
    z[1,5,2]  R1703     4.3002769351005554e-02
    z[1,5,2]  R1704     1.5302455425262451e-01
    z[1,5,2]  R1705     1.3386055361479521e-03
    z[1,5,2]  R1706     1.3925452530384064e-01
    z[1,5,2]  R1707     3.2627224922180176e-01
    z[1,5,2]  R1708     -7.9252235591411591e-02
    z[1,5,2]  R1709     4.8510608077049255e-01
    z[1,5,2]  R1710     -1.7540137469768524e-01
    z[1,5,2]  R1711     -1.7894359305500984e-02
    z[1,5,2]  R1712     -1.7448730766773224e-01
    z[1,5,2]  R1713     1.3207750022411346e-01
    z[1,5,2]  R1714     -3.6221626400947571e-01
    z[1,5,2]  R1715     1.9669516384601593e-01
    z[1,5,2]  R1716     4.0278702974319458e-01
    z[1,5,2]  R1717     -2.0718200504779816e-01
    z[1,5,2]  R1718     -3.5573190450668335e-01
    z[1,5,2]  R1719     -6.5912526845932007e-01
    z[1,5,2]  R1720     1.1744274944067001e-01
    z[1,5,2]  R1721     -7.6905059814453125e-01
    z[1,5,2]  R1722     -9.8168686032295227e-02
    z[1,5,2]  R1723     9.7359839128330350e-04
    z[1,5,2]  R1724     -1.1752710491418839e-01
    z[1,5,2]  R1725     1.9486773014068604e-01
    z[1,5,2]  R1726     -5.7592725753784180e-01
    z[1,5,2]  R1727     -0.561223030090332
    z[1,5,2]  R1728     -5.7908612489700317e-01
    z[1,5,2]  R1729     -2.6552328467369080e-01
    z[1,5,2]  R1730     -6.9777297973632812e-01
    z[1,5,2]  R1731     -7.7856051921844482e-01
    z[1,5,2]  R1732     -9.9403075873851776e-02
    z[1,5,2]  R1733     3.4059146046638489e-01
    z[1,5,2]  R1734     1.4632999897003174e-01
    z[1,5,2]  R1735     3.2667240500450134e-01
    z[1,5,2]  R1736     1.5998254716396332e-01
    z[1,5,2]  R1737     -2.1347789466381073e-01
    z[1,5,2]  R1738     2.0259141921997070e-01
    z[1,5,2]  R1739     -4.5913219451904297e-01
    z[1,5,2]  R1740     -5.9972470998764038e-01
    z[1,5,2]  R1741     -6.4753305912017822e-01
    z[1,5,2]  R1742     -3.3333367109298706e-01
    z[1,5,2]  R1743     3.7514597177505493e-01
    z[1,5,2]  R1744     -2.6433351635932922e-01
    z[1,5,2]  R1745     -7.7267253398895264e-01
    z[1,5,2]  R1746     -1.0950347036123276e-01
    z[1,5,2]  R1747     4.1314274072647095e-01
    z[1,5,2]  R1748     -2.7503243088722229e-01
    z[1,5,2]  R1749     -1.9831565022468567e-01
    z[1,5,2]  R1750     -8.4968388080596924e-02
    z[1,5,2]  R1751     -1.5004470944404602e-01
    z[1,5,2]  R1752     -0.174790620803833
    z[1,5,2]  R1753     3.1620880961418152e-01
    z[1,5,2]  R1754     -6.8193428218364716e-02
    z[1,5,2]  R1755     -6.0812151432037354e-01
    z[1,5,2]  R1756     -7.1764141321182251e-01
    z[1,5,2]  R1757     -8.1184077262878418e-01
    z[1,5,2]  R1758     -1.2061801552772522e-01
    z[1,5,2]  R1759     1.9096738100051880e-01
    z[1,5,2]  R1760     -2.4020045995712280e-01
    z[1,5,2]  R1761     -3.7953026592731476e-02
    z[1,5,2]  R1762     2.7867025136947632e-01
    z[1,5,2]  R1763     -1.0877050459384918e-01
    z[1,5,2]  R1764     1.4166106283664703e-01
    z[1,5,2]  R1765     -1.6703473031520844e-01
    z[1,5,2]  R1766     -0.681039571762085
    z[1,5,2]  R1767     -7.1422152221202850e-02
    z[1,5,2]  R1768     -2.3632074892520905e-01
    z[1,5,2]  R1769     1.2734462320804596e-01
    z[1,5,2]  R1770     2.0489895343780518e-01
    z[1,5,2]  R1771     5.6785231828689575e-01
    z[1,5,2]  R1772     1.4935834705829620e-01
    z[1,5,2]  R1773     5.2744146436452866e-02
    z[1,5,2]  R1774     -3.7843767553567886e-02
    z[1,5,2]  R1775     -2.2276104986667633e-01
    z[1,5,2]  R1776     5.8946889638900757e-01
    z[1,5,2]  R1777     3.7942177057266235e-01
    z[1,5,2]  R1778     6.0760462284088135e-01
    z[1,5,2]  R1779     6.2808138132095337e-01
    z[1,5,3]  R14       -1
    z[1,5,3]  R50       1
    z[1,5,3]  R1654     -1
    z[1,5,3]  R1655     1
    z[1,5,3]  R1662     -1.8432404100894928e-01
    z[1,5,3]  R1663     -5.1463800668716431e-01
    z[1,5,3]  R1664     -6.4134937524795532e-01
    z[1,5,3]  R1665     -4.0266942977905273e-01
    z[1,5,3]  R1666     -4.4890768826007843e-02
    z[1,5,3]  R1667     -4.6394917368888855e-01
    z[1,5,3]  R1668     -3.5040271282196045e-01
    z[1,5,3]  R1669     -8.3797693252563477e-02
    z[1,5,3]  R1670     -2.0538680255413055e-03
    z[1,5,3]  R1671     -3.6634132266044617e-01
    z[1,5,3]  R1672     2.8865441679954529e-01
    z[1,5,3]  R1673     3.6795396357774734e-02
    z[1,5,3]  R1674     -1.4961647987365723e-01
    z[1,5,3]  R1675     1.3712696731090546e-01
    z[1,5,3]  R1676     6.4623266458511353e-02
    z[1,5,3]  R1677     -9.1978013515472412e-02
    z[1,5,3]  R1678     5.1226603984832764e-01
    z[1,5,3]  R1679     -3.9801809191703796e-01
    z[1,5,3]  R1680     -6.0857552289962769e-01
    z[1,5,3]  R1681     -5.7703101634979248e-01
    z[1,5,3]  R1682     2.6602050662040710e-01
    z[1,5,3]  R1683     1.8930549919605255e-01
    z[1,5,3]  R1684     6.5145730972290039e-01
    z[1,5,3]  R1685     4.7060206532478333e-01
    z[1,5,3]  R1686     4.4231966137886047e-01
    z[1,5,3]  R1687     3.7852790951728821e-01
    z[1,5,3]  R1688     2.2586712241172791e-01
    z[1,5,3]  R1689     4.2727984488010406e-02
    z[1,5,3]  R1690     5.4297196865081787e-01
    z[1,5,3]  R1691     1.6417096555233002e-01
    z[1,5,3]  R1692     -4.0744277834892273e-01
    z[1,5,3]  R1693     -4.2608398199081421e-01
    z[1,5,3]  R1694     1.6876373440027237e-02
    z[1,5,3]  R1695     -5.5595141649246216e-01
    z[1,5,3]  R1696     0.510107696056366
    z[1,5,3]  R1697     2.4046397209167480e-01
    z[1,5,3]  R1698     -3.1315666437149048e-01
    z[1,5,3]  R1699     2.9579216241836548e-01
    z[1,5,3]  R1700     3.9032116532325745e-01
    z[1,5,3]  R1701     -7.2604638338088989e-01
    z[1,5,3]  R1702     -1.0772946476936340e-01
    z[1,5,3]  R1703     -7.8980810940265656e-02
    z[1,5,3]  R1704     1.8345648050308228e-01
    z[1,5,3]  R1705     3.1382623314857483e-01
    z[1,5,3]  R1706     1.4028945565223694e-01
    z[1,5,3]  R1707     -4.3615886569023132e-01
    z[1,5,3]  R1708     -4.3881252408027649e-01
    z[1,5,3]  R1709     1.0959044843912125e-01
    z[1,5,3]  R1710     4.7214669175446033e-03
    z[1,5,3]  R1711     -1.2928792834281921e-01
    z[1,5,3]  R1712     -1.7415136098861694e-01
    z[1,5,3]  R1713     7.4559003114700317e-02
    z[1,5,3]  R1714     -1.0413333028554916e-01
    z[1,5,3]  R1715     1.8462552130222321e-01
    z[1,5,3]  R1716     0.713071882724762
    z[1,5,3]  R1717     4.2764917016029358e-01
    z[1,5,3]  R1718     6.1980700492858887e-01
    z[1,5,3]  R1719     3.4250319004058838e-01
    z[1,5,3]  R1720     0.574138879776001
    z[1,5,3]  R1721     3.9793962240219116e-01
    z[1,5,3]  R1722     -6.0092996805906296e-02
    z[1,5,3]  R1723     0.777245819568634
    z[1,5,3]  R1724     4.5326781272888184e-01
    z[1,5,3]  R1725     2.7885380387306213e-01
    z[1,5,3]  R1726     3.5766753554344177e-01
    z[1,5,3]  R1727     3.2030284404754639e-01
    z[1,5,3]  R1728     3.1763064861297607e-01
    z[1,5,3]  R1729     3.8000747561454773e-01
    z[1,5,3]  R1730     1.2909834086894989e-01
    z[1,5,3]  R1731     -2.4669134616851807e-01
    z[1,5,3]  R1732     -2.9174787923693657e-03
    z[1,5,3]  R1733     -2.8880032896995544e-01
    z[1,5,3]  R1734     4.0354898571968079e-01
    z[1,5,3]  R1735     1.3501471281051636e-01
    z[1,5,3]  R1736     -4.7309798002243042e-01
    z[1,5,3]  R1737     -2.9963061213493347e-01
    z[1,5,3]  R1738     5.4995840787887573e-01
    z[1,5,3]  R1739     4.1433700919151306e-01
    z[1,5,3]  R1740     4.0481972694396973e-01
    z[1,5,3]  R1741     3.9746868610382080e-01
    z[1,5,3]  R1742     -2.1642296016216278e-01
    z[1,5,3]  R1743     6.3129258155822754e-01
    z[1,5,3]  R1744     4.3214264512062073e-01
    z[1,5,3]  R1745     3.4522926807403564e-01
    z[1,5,3]  R1746     4.1966402530670166e-01
    z[1,5,3]  R1747     3.2063734531402588e-01
    z[1,5,3]  R1748     -1.9523462653160095e-01
    z[1,5,3]  R1749     -5.5567425489425659e-01
    z[1,5,3]  R1750     -4.6835356950759888e-01
    z[1,5,3]  R1751     -4.9415045976638794e-01
    z[1,5,3]  R1752     -1.4836981892585754e-01
    z[1,5,3]  R1753     2.6959040760993958e-01
    z[1,5,3]  R1754     5.1917874813079834e-01
    z[1,5,3]  R1755     4.2698773741722107e-01
    z[1,5,3]  R1756     3.9615362882614136e-01
    z[1,5,3]  R1757     2.7314865589141846e-01
    z[1,5,3]  R1758     2.4443480372428894e-01
    z[1,5,3]  R1759     3.0787822604179382e-01
    z[1,5,3]  R1760     -5.2298015356063843e-01
    z[1,5,3]  R1761     -2.9256063699722290e-01
    z[1,5,3]  R1762     -5.6948989629745483e-01
    z[1,5,3]  R1763     -4.2881119251251221e-01
    z[1,5,3]  R1764     -7.5719755887985229e-01
    z[1,5,3]  R1765     0.0762195810675621
    z[1,5,3]  R1766     4.4908598065376282e-02
    z[1,5,3]  R1767     8.4992036223411560e-02
    z[1,5,3]  R1768     -6.5855622291564941e-01
    z[1,5,3]  R1769     -5.6091868877410889e-01
    z[1,5,3]  R1770     -4.3509653210639954e-01
    z[1,5,3]  R1771     0.442421019077301
    z[1,5,3]  R1772     -1.7582742869853973e-01
    z[1,5,3]  R1773     -2.8553646802902222e-01
    z[1,5,3]  R1774     7.1413803100585938e-01
    z[1,5,3]  R1775     6.9978368282318115e-01
    z[1,5,3]  R1776     -9.4671607017517090e-02
    z[1,5,3]  R1777     0.0948103740811348
    z[1,5,3]  R1778     5.7832002639770508e-02
    z[1,5,3]  R1779     4.1294094175100327e-02
    z[1,5,4]  R15       -1
    z[1,5,4]  R51       1
    z[1,5,4]  R1656     -1
    z[1,5,4]  R1657     1
    z[1,5,4]  R1662     1.3935865461826324e-01
    z[1,5,4]  R1663     -3.3856093883514404e-02
    z[1,5,4]  R1664     2.6250863075256348e-01
    z[1,5,4]  R1665     2.3572713136672974e-02
    z[1,5,4]  R1666     3.6814704537391663e-01
    z[1,5,4]  R1667     1.7465278506278992e-01
    z[1,5,4]  R1668     3.3341392874717712e-01
    z[1,5,4]  R1669     -7.4151274748146534e-04
    z[1,5,4]  R1670     2.8366908431053162e-01
    z[1,5,4]  R1671     5.4026669263839722e-01
    z[1,5,4]  R1672     -2.5515180826187134e-01
    z[1,5,4]  R1673     -2.7427467703819275e-01
    z[1,5,4]  R1674     -4.2240446805953979e-01
    z[1,5,4]  R1675     2.7976479381322861e-02
    z[1,5,4]  R1676     -1.7387789487838745e-01
    z[1,5,4]  R1677     -4.3352580070495605e-01
    z[1,5,4]  R1678     4.0010169148445129e-01
    z[1,5,4]  R1679     6.9646663963794708e-02
    z[1,5,4]  R1680     -5.0047025084495544e-02
    z[1,5,4]  R1681     -4.9046209454536438e-01
    z[1,5,4]  R1682     -3.5990697145462036e-01
    z[1,5,4]  R1683     9.0682750940322876e-01
    z[1,5,4]  R1684     6.9490909576416016e-01
    z[1,5,4]  R1685     7.9154515266418457e-01
    z[1,5,4]  R1686     7.2009402513504028e-01
    z[1,5,4]  R1687     7.0644110441207886e-01
    z[1,5,4]  R1688     8.1561535596847534e-01
    z[1,5,4]  R1689     -7.3069550096988678e-02
    z[1,5,4]  R1690     4.5287674665451050e-01
    z[1,5,4]  R1691     1.2962979078292847e-01
    z[1,5,4]  R1692     7.9473212361335754e-02
    z[1,5,4]  R1693     -1.3623583316802979e-01
    z[1,5,4]  R1694     2.1712502837181091e-01
    z[1,5,4]  R1695     8.6590774357318878e-02
    z[1,5,4]  R1696     7.9303735494613647e-01
    z[1,5,4]  R1697     -1.8995349109172821e-01
    z[1,5,4]  R1698     4.6238112449645996e-01
    z[1,5,4]  R1699     7.1789878606796265e-01
    z[1,5,4]  R1700     4.2612543702125549e-01
    z[1,5,4]  R1701     -2.2465731203556061e-01
    z[1,5,4]  R1702     1.1231165379285812e-01
    z[1,5,4]  R1703     4.8143625259399414e-01
    z[1,5,4]  R1704     3.1954690814018250e-01
    z[1,5,4]  R1705     3.2098862528800964e-01
    z[1,5,4]  R1706     -4.3746823072433472e-01
    z[1,5,4]  R1707     -1.7073710262775421e-01
    z[1,5,4]  R1708     -2.0819954574108124e-02
    z[1,5,4]  R1709     -0.0989551842212677
    z[1,5,4]  R1710     2.5268995761871338e-01
    z[1,5,4]  R1711     1.5949079394340515e-01
    z[1,5,4]  R1712     0.136853888630867
    z[1,5,4]  R1713     1.7795832455158234e-01
    z[1,5,4]  R1714     -1.3361354172229767e-01
    z[1,5,4]  R1715     8.3230429887771606e-01
    z[1,5,4]  R1716     4.1093739867210388e-01
    z[1,5,4]  R1717     5.3052127361297607e-01
    z[1,5,4]  R1718     5.1477003097534180e-01
    z[1,5,4]  R1719     5.0155729055404663e-01
    z[1,5,4]  R1720     2.9172223806381226e-01
    z[1,5,4]  R1721     4.8056846857070923e-01
    z[1,5,4]  R1722     2.6530984044075012e-01
    z[1,5,4]  R1723     5.4606622457504272e-01
    z[1,5,4]  R1724     7.8615558147430420e-01
    z[1,5,4]  R1725     6.2929922342300415e-01
    z[1,5,4]  R1726     2.6644504070281982e-01
    z[1,5,4]  R1727     -3.8745053112506866e-02
    z[1,5,4]  R1728     2.0344233512878418e-01
    z[1,5,4]  R1729     1.7360401153564453e-01
    z[1,5,4]  R1730     5.9470452368259430e-02
    z[1,5,4]  R1731     2.6736825704574585e-02
    z[1,5,4]  R1732     3.3870872855186462e-01
    z[1,5,4]  R1733     5.5658571422100067e-02
    z[1,5,4]  R1734     -7.8829256817698479e-03
    z[1,5,4]  R1735     7.8902617096900940e-02
    z[1,5,4]  R1736     1.1656423658132553e-01
    z[1,5,4]  R1737     2.7199275791645050e-02
    z[1,5,4]  R1738     4.8117798566818237e-01
    z[1,5,4]  R1739     3.0255025625228882e-01
    z[1,5,4]  R1740     3.3595968037843704e-02
    z[1,5,4]  R1741     1.6369393467903137e-01
    z[1,5,4]  R1742     -2.9842811822891235e-01
    z[1,5,4]  R1743     5.3670382499694824e-01
    z[1,5,4]  R1744     4.7548791766166687e-01
    z[1,5,4]  R1745     2.9210817813873291e-01
    z[1,5,4]  R1746     4.8938098549842834e-01
    z[1,5,4]  R1747     3.6667466163635254e-01
    z[1,5,4]  R1748     -3.0993974208831787e-01
    z[1,5,4]  R1749     -2.1801907569169998e-02
    z[1,5,4]  R1750     -6.2543079257011414e-02
    z[1,5,4]  R1751     -2.3602099716663361e-01
    z[1,5,4]  R1752     8.2893833518028259e-02
    z[1,5,4]  R1753     2.8686946630477905e-01
    z[1,5,4]  R1754     7.8496611118316650e-01
    z[1,5,4]  R1755     1.9304936751723289e-02
    z[1,5,4]  R1756     0.449378103017807
    z[1,5,4]  R1757     -3.3246347308158875e-01
    z[1,5,4]  R1758     -1.7195332795381546e-02
    z[1,5,4]  R1759     2.4461318552494049e-01
    z[1,5,4]  R1760     1.0814021341502666e-02
    z[1,5,4]  R1761     1.1211378872394562e-01
    z[1,5,4]  R1762     5.4164677858352661e-02
    z[1,5,4]  R1763     4.6782290935516357e-01
    z[1,5,4]  R1764     -1.3765020668506622e-01
    z[1,5,4]  R1765     6.3581025600433350e-01
    z[1,5,4]  R1766     2.3368719220161438e-01
    z[1,5,4]  R1767     3.0189290642738342e-01
    z[1,5,4]  R1768     1.0823497176170349e-01
    z[1,5,4]  R1769     1.3297668099403381e-01
    z[1,5,4]  R1770     3.7571147084236145e-01
    z[1,5,4]  R1771     -1.9383493065834045e-01
    z[1,5,4]  R1772     -5.8535319566726685e-01
    z[1,5,4]  R1773     -4.5141065120697021e-01
    z[1,5,4]  R1774     3.5576120018959045e-01
    z[1,5,4]  R1775     3.0308127403259277e-01
    z[1,5,4]  R1776     -6.1856800317764282e-01
    z[1,5,4]  R1777     -8.9350748062133789e-01
    z[1,5,4]  R1778     -6.5405994653701782e-01
    z[1,5,4]  R1779     -7.2544282674789429e-01
    z[1,5,5]  R16       -1
    z[1,5,5]  R52       1
    z[1,5,5]  R1658     -1
    z[1,5,5]  R1659     1
    z[1,5,5]  R1662     -7.4647432565689087e-01
    z[1,5,5]  R1663     -6.3916242122650146e-01
    z[1,5,5]  R1664     -5.0884467363357544e-01
    z[1,5,5]  R1665     -7.2125869989395142e-01
    z[1,5,5]  R1666     -7.8055894374847412e-01
    z[1,5,5]  R1667     -6.7628163099288940e-01
    z[1,5,5]  R1668     -7.5406205654144287e-01
    z[1,5,5]  R1669     -5.4106724262237549e-01
    z[1,5,5]  R1670     -7.7640181779861450e-01
    z[1,5,5]  R1671     -3.3120352029800415e-01
    z[1,5,5]  R1672     -1.7839916050434113e-01
    z[1,5,5]  R1673     3.4148350358009338e-02
    z[1,5,5]  R1674     1.8258308991789818e-02
    z[1,5,5]  R1675     -1.8633460998535156e-01
    z[1,5,5]  R1676     -1.9224444031715393e-01
    z[1,5,5]  R1677     1.1763998866081238e-01
    z[1,5,5]  R1678     2.6581385731697083e-01
    z[1,5,5]  R1679     -3.4957072138786316e-01
    z[1,5,5]  R1680     9.1608978807926178e-02
    z[1,5,5]  R1681     4.0881808847188950e-02
    z[1,5,5]  R1682     2.3601700365543365e-01
    z[1,5,5]  R1683     1.3677023351192474e-01
    z[1,5,5]  R1684     7.3405399918556213e-02
    z[1,5,5]  R1685     1.0969126969575882e-01
    z[1,5,5]  R1686     9.2714056372642517e-02
    z[1,5,5]  R1687     1.4815928041934967e-01
    z[1,5,5]  R1688     2.1618127822875977e-01
    z[1,5,5]  R1689     8.9850440621376038e-02
    z[1,5,5]  R1690     3.2188418507575989e-01
    z[1,5,5]  R1691     1.1667750775814056e-02
    z[1,5,5]  R1692     3.9937481284141541e-01
    z[1,5,5]  R1693     -8.7309010326862335e-02
    z[1,5,5]  R1694     2.4414394795894623e-01
    z[1,5,5]  R1695     2.3820179700851440e-01
    z[1,5,5]  R1696     1.0241446644067764e-01
    z[1,5,5]  R1697     4.2090556025505066e-01
    z[1,5,5]  R1698     -6.4658693969249725e-02
    z[1,5,5]  R1699     -1.1355581879615784e-01
    z[1,5,5]  R1700     1.5739759802818298e-01
    z[1,5,5]  R1701     2.3948132991790771e-01
    z[1,5,5]  R1702     2.2364287078380585e-01
    z[1,5,5]  R1703     1.7969799041748047e-01
    z[1,5,5]  R1704     -3.2613289356231689e-01
    z[1,5,5]  R1705     4.9317643046379089e-01
    z[1,5,5]  R1706     3.1518206000328064e-01
    z[1,5,5]  R1707     -3.0196252465248108e-01
    z[1,5,5]  R1708     2.6776146888732910e-01
    z[1,5,5]  R1709     3.0875065922737122e-01
    z[1,5,5]  R1710     1.9810175895690918e-01
    z[1,5,5]  R1711     4.8662075400352478e-01
    z[1,5,5]  R1712     1.3925476372241974e-01
    z[1,5,5]  R1713     4.4187238812446594e-01
    z[1,5,5]  R1714     3.6108088493347168e-01
    z[1,5,5]  R1715     4.4546341896057129e-01
    z[1,5,5]  R1716     1.2333232164382935e-01
    z[1,5,5]  R1717     -1.0340360924601555e-02
    z[1,5,5]  R1718     2.5306472182273865e-01
    z[1,5,5]  R1719     3.0567046254873276e-02
    z[1,5,5]  R1720     1.1456538736820221e-01
    z[1,5,5]  R1721     4.9303401261568069e-02
    z[1,5,5]  R1722     4.6101510524749756e-01
    z[1,5,5]  R1723     3.7257452495396137e-03
    z[1,5,5]  R1724     1.2055249512195587e-01
    z[1,5,5]  R1725     1.0165440291166306e-01
    z[1,5,5]  R1726     -3.0589890480041504e-01
    z[1,5,5]  R1727     -1.5219344198703766e-01
    z[1,5,5]  R1728     -8.9321933686733246e-02
    z[1,5,5]  R1729     -6.7859692499041557e-03
    z[1,5,5]  R1730     -1.3576747849583626e-02
    z[1,5,5]  R1731     1.4903441071510315e-01
    z[1,5,5]  R1732     -0.248980313539505
    z[1,5,5]  R1733     -0.105091892182827
    z[1,5,5]  R1734     4.3572276830673218e-01
    z[1,5,5]  R1735     -5.9681254625320435e-01
    z[1,5,5]  R1736     -4.2099773883819580e-01
    z[1,5,5]  R1737     4.4694775342941284e-01
    z[1,5,5]  R1738     2.5101962685585022e-01
    z[1,5,5]  R1739     -1.2519478797912598e-01
    z[1,5,5]  R1740     -2.3776248097419739e-01
    z[1,5,5]  R1741     -8.8280171155929565e-02
    z[1,5,5]  R1742     -1.3381315767765045e-01
    z[1,5,5]  R1743     2.9748940467834473e-01
    z[1,5,5]  R1744     4.6417381614446640e-02
    z[1,5,5]  R1745     -8.5791319608688354e-02
    z[1,5,5]  R1746     -1.8986134231090546e-01
    z[1,5,5]  R1747     1.2778806686401367e-01
    z[1,5,5]  R1748     0.00913998018950224
    z[1,5,5]  R1749     1.4865861833095551e-01
    z[1,5,5]  R1750     -2.4004525039345026e-03
    z[1,5,5]  R1751     -2.4128738045692444e-01
    z[1,5,5]  R1752     0.412727415561676
    z[1,5,5]  R1753     2.9499068856239319e-01
    z[1,5,5]  R1754     2.1359564363956451e-01
    z[1,5,5]  R1755     -1.1896307766437531e-01
    z[1,5,5]  R1756     2.3534636944532394e-02
    z[1,5,5]  R1757     -1.2104593962430954e-01
    z[1,5,5]  R1758     6.8074040114879608e-02
    z[1,5,5]  R1759     1.6482903063297272e-01
    z[1,5,5]  R1760     -8.3766825497150421e-02
    z[1,5,5]  R1761     -2.2390339523553848e-02
    z[1,5,5]  R1762     -1.4287843368947506e-02
    z[1,5,5]  R1763     -5.6503123044967651e-01
    z[1,5,5]  R1764     -4.3702629208564758e-01
    z[1,5,5]  R1765     -1.3089406490325928e-01
    z[1,5,5]  R1766     -1.7761671543121338e-01
    z[1,5,5]  R1767     -1.0719674080610275e-01
    z[1,5,5]  R1768     -5.2818857133388519e-02
    z[1,5,5]  R1769     -4.0881308913230896e-01
    z[1,5,5]  R1770     -2.4879913777112961e-02
    z[1,5,5]  R1771     1.7187925055623055e-02
    z[1,5,5]  R1772     2.3088967800140381e-01
    z[1,5,5]  R1773     -5.8473899960517883e-02
    z[1,5,5]  R1774     -4.6503199264407158e-03
    z[1,5,5]  R1775     7.1491762995719910e-02
    z[1,5,5]  R1776     1.2345013022422791e-01
    z[1,5,5]  R1777     -1.6062812507152557e-01
    z[1,5,5]  R1778     -3.3547499775886536e-01
    z[1,5,5]  R1779     -2.1850788965821266e-02
    z[1,5,6]  R17       -1
    z[1,5,6]  R53       1
    z[1,5,6]  R1660     -1
    z[1,5,6]  R1661     1
    z[1,5,6]  R1662     1.5904265642166138e-01
    z[1,5,6]  R1663     0.271445095539093
    z[1,5,6]  R1664     -1.3883425295352936e-01
    z[1,5,6]  R1665     2.8788670897483826e-01
    z[1,5,6]  R1666     9.2242740094661713e-02
    z[1,5,6]  R1667     -1.1773692071437836e-01
    z[1,5,6]  R1668     -0.304904043674469
    z[1,5,6]  R1669     -3.5347026586532593e-01
    z[1,5,6]  R1670     -3.7749823927879333e-01
    z[1,5,6]  R1671     1.2803323566913605e-01
    z[1,5,6]  R1672     2.3802106082439423e-01
    z[1,5,6]  R1673     2.0687267184257507e-01
    z[1,5,6]  R1674     -1.9543178379535675e-01
    z[1,5,6]  R1675     -5.0599705427885056e-02
    z[1,5,6]  R1676     -2.8501942753791809e-01
    z[1,5,6]  R1677     -4.4072084128856659e-02
    z[1,5,6]  R1678     3.5985404253005981e-01
    z[1,5,6]  R1679     -2.4825769662857056e-01
    z[1,5,6]  R1680     -4.9248144030570984e-01
    z[1,5,6]  R1681     -2.6498025655746460e-01
    z[1,5,6]  R1682     1.8578261137008667e-01
    z[1,5,6]  R1683     -0.0825931504368782
    z[1,5,6]  R1684     9.1572798788547516e-02
    z[1,5,6]  R1685     3.6711718887090683e-02
    z[1,5,6]  R1686     2.3696108162403107e-01
    z[1,5,6]  R1687     4.5238483697175980e-02
    z[1,5,6]  R1688     -3.4410390257835388e-01
    z[1,5,6]  R1689     -0.0334925651550293
    z[1,5,6]  R1690     -4.7413217835128307e-03
    z[1,5,6]  R1691     -1.4855190180242062e-02
    z[1,5,6]  R1692     -1.7784331738948822e-01
    z[1,5,6]  R1693     1.5596219897270203e-01
    z[1,5,6]  R1694     -2.1742123365402222e-01
    z[1,5,6]  R1695     -3.1197572126984596e-02
    z[1,5,6]  R1696     -9.3162119388580322e-02
    z[1,5,6]  R1697     1.5060979127883911e-01
    z[1,5,6]  R1698     -3.0172318220138550e-02
    z[1,5,6]  R1699     1.1491342447698116e-02
    z[1,5,6]  R1700     -6.6568199545145035e-03
    z[1,5,6]  R1701     1.2094780057668686e-01
    z[1,5,6]  R1702     3.0671152472496033e-01
    z[1,5,6]  R1703     1.8265551328659058e-01
    z[1,5,6]  R1704     -3.7411868572235107e-01
    z[1,5,6]  R1705     2.1233037114143372e-01
    z[1,5,6]  R1706     0.196168914437294
    z[1,5,6]  R1707     -3.9702009409666061e-02
    z[1,5,6]  R1708     2.5907030701637268e-01
    z[1,5,6]  R1709     -2.2752623260021210e-01
    z[1,5,6]  R1710     -4.2170169949531555e-01
    z[1,5,6]  R1711     -1.9631689786911011e-01
    z[1,5,6]  R1712     -6.1951391398906708e-02
    z[1,5,6]  R1713     1.1733530461788177e-01
    z[1,5,6]  R1714     -4.0632402896881104e-01
    z[1,5,6]  R1715     -6.6393963992595673e-02
    z[1,5,6]  R1716     3.7370380759239197e-01
    z[1,5,6]  R1717     -2.9392614960670471e-01
    z[1,5,6]  R1718     -1.1798671633005142e-01
    z[1,5,6]  R1719     1.8293111026287079e-01
    z[1,5,6]  R1720     -3.6410754919052124e-01
    z[1,5,6]  R1721     -1.0908308625221252e-01
    z[1,5,6]  R1722     2.6725763082504272e-01
    z[1,5,6]  R1723     2.5766745209693909e-01
    z[1,5,6]  R1724     -3.0579122900962830e-01
    z[1,5,6]  R1725     -5.7885181903839111e-01
    z[1,5,6]  R1726     1.6591729223728180e-01
    z[1,5,6]  R1727     1.4609168469905853e-01
    z[1,5,6]  R1728     -5.5366444587707520e-01
    z[1,5,6]  R1729     -3.5493856668472290e-01
    z[1,5,6]  R1730     -0.546783983707428
    z[1,5,6]  R1731     -2.9336306452751160e-01
    z[1,5,6]  R1732     -6.3115954399108887e-02
    z[1,5,6]  R1733     -4.1935643553733826e-01
    z[1,5,6]  R1734     5.7996802031993866e-02
    z[1,5,6]  R1735     -1.8123584985733032e-01
    z[1,5,6]  R1736     -0.336314857006073
    z[1,5,6]  R1737     -3.0428001284599304e-01
    z[1,5,6]  R1738     -3.0388179421424866e-01
    z[1,5,6]  R1739     -1.1459008604288101e-01
    z[1,5,6]  R1740     -3.3831059932708740e-02
    z[1,5,6]  R1741     3.8647550344467163e-01
    z[1,5,6]  R1742     -1.0314249992370605e-01
    z[1,5,6]  R1743     7.8031592071056366e-02
    z[1,5,6]  R1744     -2.4493908509612083e-02
    z[1,5,6]  R1745     -2.7924704551696777e-01
    z[1,5,6]  R1746     6.3042402267456055e-02
    z[1,5,6]  R1747     -3.0630344152450562e-01
    z[1,5,6]  R1748     -5.7962872087955475e-02
    z[1,5,6]  R1749     -2.0928554236888885e-01
    z[1,5,6]  R1750     1.4468098059296608e-02
    z[1,5,6]  R1751     3.2767906785011292e-02
    z[1,5,6]  R1752     -7.0363827049732208e-02
    z[1,5,6]  R1753     1.9452148675918579e-01
    z[1,5,6]  R1754     -3.8339901715517044e-02
    z[1,5,6]  R1755     3.0110573768615723e-01
    z[1,5,6]  R1756     2.4829675257205963e-01
    z[1,5,6]  R1757     -2.5787854194641113e-01
    z[1,5,6]  R1758     3.1721785664558411e-01
    z[1,5,6]  R1759     -6.0341215133666992e-01
    z[1,5,6]  R1760     5.3015735000371933e-02
    z[1,5,6]  R1761     1.1071027070283890e-01
    z[1,5,6]  R1762     6.1444687843322754e-01
    z[1,5,6]  R1763     -4.3590404093265533e-03
    z[1,5,6]  R1764     2.2357994690537453e-02
    z[1,5,6]  R1765     5.7348549365997314e-01
    z[1,5,6]  R1766     -6.9269933737814426e-03
    z[1,5,6]  R1767     1.0610774904489517e-01
    z[1,5,6]  R1768     1.7449681460857391e-01
    z[1,5,6]  R1769     7.7917866408824921e-02
    z[1,5,6]  R1770     4.0451128035783768e-02
    z[1,5,6]  R1771     -2.2428588569164276e-01
    z[1,5,6]  R1772     -4.0222319960594177e-01
    z[1,5,6]  R1773     -7.0052641630172729e-01
    z[1,5,6]  R1774     -3.9406427741050720e-01
    z[1,5,6]  R1775     -2.1893793344497681e-01
    z[1,5,6]  R1776     0.0604308545589447
    z[1,5,6]  R1777     1.7724696546792984e-02
    z[1,5,6]  R1778     5.0938300788402557e-02
    z[1,5,6]  R1779     -1.3692008331418037e-02
    z[5,1,0]  R11       1
    z[5,1,0]  R47       -1
    z[5,1,0]  R1780     -1
    z[5,1,0]  R1781     1
    z[5,1,0]  R1794     0.465468168258667
    z[5,1,0]  R1795     4.8361030220985413e-01
    z[5,1,0]  R1796     3.9293155074119568e-01
    z[5,1,0]  R1797     4.5623803138732910e-01
    z[5,1,0]  R1798     6.6259825229644775e-01
    z[5,1,0]  R1799     4.4954261183738708e-01
    z[5,1,0]  R1800     -6.7470502853393555e-01
    z[5,1,0]  R1801     -6.7426276206970215e-01
    z[5,1,0]  R1802     -7.7380383014678955e-01
    z[5,1,0]  R1803     5.5530810356140137e-01
    z[5,1,0]  R1804     5.7968068122863770e-01
    z[5,1,0]  R1805     -3.3840614557266235e-01
    z[5,1,0]  R1806     -4.5139434933662415e-01
    z[5,1,0]  R1807     -0.545189619064331
    z[5,1,0]  R1808     -1.6080382466316223e-01
    z[5,1,0]  R1809     -1.4969871938228607e-01
    z[5,1,0]  R1810     -2.0674932003021240e-01
    z[5,1,0]  R1811     -1.6465358436107635e-01
    z[5,1,0]  R1812     2.7963241934776306e-01
    z[5,1,0]  R1813     3.4242463111877441e-01
    z[5,1,0]  R1814     2.7918154001235962e-01
    z[5,1,0]  R1815     1.7188704013824463e-01
    z[5,1,0]  R1816     2.6724824309349060e-01
    z[5,1,0]  R1817     3.3592095971107483e-01
    z[5,1,0]  R1818     2.6670613884925842e-01
    z[5,1,0]  R1819     2.9679268598556519e-01
    z[5,1,0]  R1820     3.2342132925987244e-01
    z[5,1,0]  R1821     4.2374247312545776e-01
    z[5,1,0]  R1822     5.6757301092147827e-01
    z[5,1,0]  R1823     4.6850016713142395e-01
    z[5,1,0]  R1824     6.9135004281997681e-01
    z[5,1,0]  R1825     5.3372144699096680e-01
    z[5,1,0]  R1826     6.4588135480880737e-01
    z[5,1,0]  R1827     5.4391831159591675e-01
    z[5,1,0]  R1828     2.6483288407325745e-01
    z[5,1,0]  R1829     1.2983353435993195e-01
    z[5,1,0]  R1830     3.0205753445625305e-01
    z[5,1,0]  R1831     -2.7663335204124451e-02
    z[5,1,0]  R1832     4.8140409588813782e-01
    z[5,1,0]  R1833     -3.3962267637252808e-01
    z[5,1,0]  R1834     -9.4367347657680511e-02
    z[5,1,0]  R1835     -2.3696716129779816e-01
    z[5,1,0]  R1836     -4.0758627653121948e-01
    z[5,1,0]  R1837     -3.8331297039985657e-01
    z[5,1,0]  R1838     1.3147702813148499e-01
    z[5,1,0]  R1839     -6.6205447912216187e-01
    z[5,1,0]  R1840     0.0634799376130104
    z[5,1,0]  R1841     -4.9066832661628723e-01
    z[5,1,0]  R1842     2.5178718566894531e-01
    z[5,1,0]  R1843     -1.9391223788261414e-01
    z[5,1,0]  R1844     4.9170383810997009e-01
    z[5,1,0]  R1845     -2.4322444200515747e-01
    z[5,1,0]  R1846     1.0009628534317017e-01
    z[5,1,0]  R1847     4.7080019116401672e-01
    z[5,1,0]  R1848     -1.3195669651031494e-01
    z[5,1,0]  R1849     1.1216656118631363e-01
    z[5,1,0]  R1850     5.4910188913345337e-01
    z[5,1,0]  R1851     -3.1269797682762146e-01
    z[5,1,0]  R1852     4.4816821813583374e-02
    z[5,1,0]  R1853     -2.6699263602495193e-02
    z[5,1,0]  R1854     5.7596504688262939e-01
    z[5,1,0]  R1855     3.8244676589965820e-01
    z[5,1,0]  R1856     7.2887712717056274e-01
    z[5,1,0]  R1857     1.1982088536024094e-01
    z[5,1,0]  R1858     -9.3095436692237854e-02
    z[5,1,0]  R1859     7.0091545581817627e-01
    z[5,1,0]  R1860     6.5625959634780884e-01
    z[5,1,0]  R1861     0.729515790939331
    z[5,1,0]  R1862     3.9137899875640869e-01
    z[5,1,0]  R1863     5.6989258527755737e-01
    z[5,1,0]  R1864     4.3833982944488525e-01
    z[5,1,0]  R1865     -0.166781947016716
    z[5,1,0]  R1866     -8.5881259292364120e-03
    z[5,1,0]  R1867     -1.9071486592292786e-01
    z[5,1,0]  R1868     2.8914827108383179e-01
    z[5,1,0]  R1869     -3.4472441673278809e-01
    z[5,1,0]  R1870     5.1635402441024780e-01
    z[5,1,0]  R1871     7.0207953453063965e-02
    z[5,1,0]  R1872     5.7533466815948486e-01
    z[5,1,0]  R1873     1.5542012453079224e-01
    z[5,1,0]  R1874     2.3176409304141998e-01
    z[5,1,0]  R1875     -1.0020636767148972e-01
    z[5,1,0]  R1876     -0.573139488697052
    z[5,1,0]  R1877     -1.4173206686973572e-01
    z[5,1,0]  R1878     -4.1580238938331604e-01
    z[5,1,0]  R1879     -7.9225033521652222e-01
    z[5,1,0]  R1880     -4.2027789354324341e-01
    z[5,1,0]  R1881     -3.3313852548599243e-01
    z[5,1,0]  R1882     2.9472494125366211e-01
    z[5,1,0]  R1883     4.7758859395980835e-01
    z[5,1,0]  R1884     0.695899486541748
    z[5,1,0]  R1885     4.3001008033752441e-01
    z[5,1,0]  R1886     1.0595851391553879e-01
    z[5,1,0]  R1887     5.8363842964172363e-01
    z[5,1,0]  R1888     0.500739574432373
    z[5,1,0]  R1889     -6.7276030778884888e-01
    z[5,1,0]  R1890     -0.639201819896698
    z[5,1,0]  R1891     -4.3315351009368896e-01
    z[5,1,0]  R1892     5.0770324468612671e-01
    z[5,1,0]  R1893     6.2168218195438385e-02
    z[5,1,0]  R1894     -7.0578551292419434e-01
    z[5,1,0]  R1895     -2.9588720202445984e-01
    z[5,1,0]  R1896     -4.6263718605041504e-01
    z[5,1,0]  R1897     -6.7708253860473633e-01
    z[5,1,0]  R1898     -4.0369123220443726e-01
    z[5,1,0]  R1899     -6.2100154161453247e-01
    z[5,1,0]  R1900     -7.3160064220428467e-01
    z[5,1,0]  R1901     -6.7369800806045532e-01
    z[5,1,0]  R1902     6.7131519317626953e-01
    z[5,1,0]  R1903     3.7447464466094971e-01
    z[5,1,0]  R1904     -2.2601333260536194e-01
    z[5,1,0]  R1905     -5.8531010150909424e-01
    z[5,1,0]  R1906     -2.4237510561943054e-01
    z[5,1,0]  R1907     -2.5561258196830750e-01
    z[5,1,0]  R1908     -8.8041287660598755e-01
    z[5,1,0]  R1909     -5.3718191385269165e-01
    z[5,1,0]  R1910     -7.6415562629699707e-01
    z[5,1,0]  R1911     -8.0009514093399048e-01
    z[5,1,1]  R12       1
    z[5,1,1]  R48       -1
    z[5,1,1]  R1782     -1
    z[5,1,1]  R1783     1
    z[5,1,1]  R1794     -2.6089332997798920e-02
    z[5,1,1]  R1795     -1.7964828014373779e-01
    z[5,1,1]  R1796     -2.0432645082473755e-01
    z[5,1,1]  R1797     -0.0886748731136322
    z[5,1,1]  R1798     -9.4480365514755249e-02
    z[5,1,1]  R1799     8.1957143545150757e-01
    z[5,1,1]  R1800     -1.0136871039867401e-01
    z[5,1,1]  R1801     -1.5375743806362152e-01
    z[5,1,1]  R1802     -1.6285133361816406e-01
    z[5,1,1]  R1803     -2.9200801253318787e-01
    z[5,1,1]  R1804     2.3025064170360565e-01
    z[5,1,1]  R1805     3.2131013274192810e-01
    z[5,1,1]  R1806     5.4254125803709030e-02
    z[5,1,1]  R1807     -0.13618203997612
    z[5,1,1]  R1808     -4.6495974063873291e-01
    z[5,1,1]  R1809     1.3007128611207008e-02
    z[5,1,1]  R1810     2.0443606376647949e-01
    z[5,1,1]  R1811     2.2308218479156494e-01
    z[5,1,1]  R1812     3.4309035539627075e-01
    z[5,1,1]  R1813     3.0812993645668030e-01
    z[5,1,1]  R1814     2.3934613168239594e-01
    z[5,1,1]  R1815     -2.9777586460113525e-01
    z[5,1,1]  R1816     -1.9624061882495880e-01
    z[5,1,1]  R1817     4.1178426146507263e-01
    z[5,1,1]  R1818     1.6529412567615509e-01
    z[5,1,1]  R1819     5.1155781745910645e-01
    z[5,1,1]  R1820     1.5445442497730255e-01
    z[5,1,1]  R1821     -3.6533939838409424e-01
    z[5,1,1]  R1822     -6.5492558479309082e-01
    z[5,1,1]  R1823     -6.9631791114807129e-01
    z[5,1,1]  R1824     -5.1652860641479492e-01
    z[5,1,1]  R1825     -6.4939856529235840e-01
    z[5,1,1]  R1826     -3.6016201972961426e-01
    z[5,1,1]  R1827     -4.1192224621772766e-01
    z[5,1,1]  R1828     -5.5285841226577759e-01
    z[5,1,1]  R1829     -6.5408545732498169e-01
    z[5,1,1]  R1830     -4.8382645845413208e-01
    z[5,1,1]  R1831     -4.7620588541030884e-01
    z[5,1,1]  R1832     0.547591507434845
    z[5,1,1]  R1833     2.6197345927357674e-02
    z[5,1,1]  R1834     2.6048806309700012e-01
    z[5,1,1]  R1835     2.1758790314197540e-01
    z[5,1,1]  R1836     1.6954356431961060e-01
    z[5,1,1]  R1837     3.9316490292549133e-01
    z[5,1,1]  R1838     -7.7843718230724335e-02
    z[5,1,1]  R1839     1.7736643552780151e-01
    z[5,1,1]  R1840     3.7261933088302612e-01
    z[5,1,1]  R1841     3.1868198513984680e-01
    z[5,1,1]  R1842     -6.4168584346771240e-01
    z[5,1,1]  R1843     -5.1873183250427246e-01
    z[5,1,1]  R1844     -5.3301793336868286e-01
    z[5,1,1]  R1845     -4.2163071036338806e-01
    z[5,1,1]  R1846     -5.7585906237363815e-02
    z[5,1,1]  R1847     6.8187665939331055e-01
    z[5,1,1]  R1848     -7.6996523141860962e-01
    z[5,1,1]  R1849     -5.8149510622024536e-01
    z[5,1,1]  R1850     4.9429732561111450e-01
    z[5,1,1]  R1851     -4.6810075640678406e-01
    z[5,1,1]  R1852     -7.8278720378875732e-01
    z[5,1,1]  R1853     -8.3292537927627563e-01
    z[5,1,1]  R1854     -5.1259505748748779e-01
    z[5,1,1]  R1855     -6.0324513912200928e-01
    z[5,1,1]  R1856     3.1696164608001709e-01
    z[5,1,1]  R1857     -7.5302451848983765e-01
    z[5,1,1]  R1858     -8.0823796987533569e-01
    z[5,1,1]  R1859     -3.2325261831283569e-01
    z[5,1,1]  R1860     -5.0754940509796143e-01
    z[5,1,1]  R1861     3.8729032874107361e-01
    z[5,1,1]  R1862     -8.6260598897933960e-01
    z[5,1,1]  R1863     6.4150685071945190e-01
    z[5,1,1]  R1864     5.9370237588882446e-01
    z[5,1,1]  R1865     -6.1903841793537140e-02
    z[5,1,1]  R1866     7.4042327702045441e-02
    z[5,1,1]  R1867     6.0816723108291626e-01
    z[5,1,1]  R1868     2.5047263503074646e-01
    z[5,1,1]  R1869     -2.0845349133014679e-01
    z[5,1,1]  R1870     3.9893460273742676e-01
    z[5,1,1]  R1871     3.3393295598216355e-04
    z[5,1,1]  R1872     5.4899090528488159e-01
    z[5,1,1]  R1873     -8.4485612809658051e-02
    z[5,1,1]  R1874     3.0647762119770050e-02
    z[5,1,1]  R1875     3.6442461609840393e-01
    z[5,1,1]  R1876     1.4070263504981995e-01
    z[5,1,1]  R1877     0.718567967414856
    z[5,1,1]  R1878     -1.8699440360069275e-01
    z[5,1,1]  R1879     3.5574089735746384e-02
    z[5,1,1]  R1880     1.3084031641483307e-01
    z[5,1,1]  R1881     -3.3618080615997314e-01
    z[5,1,1]  R1882     -0.850028932094574
    z[5,1,1]  R1883     -6.1846506595611572e-01
    z[5,1,1]  R1884     -3.7172517180442810e-01
    z[5,1,1]  R1885     -5.4303795099258423e-01
    z[5,1,1]  R1886     -6.5986555814743042e-01
    z[5,1,1]  R1887     4.8054805397987366e-01
    z[5,1,1]  R1888     1.3738648593425751e-01
    z[5,1,1]  R1889     2.1112720668315887e-01
    z[5,1,1]  R1890     -9.5226854085922241e-02
    z[5,1,1]  R1891     2.2615295648574829e-01
    z[5,1,1]  R1892     -6.8314230442047119e-01
    z[5,1,1]  R1893     2.7245259284973145e-01
    z[5,1,1]  R1894     -1.2807795405387878e-01
    z[5,1,1]  R1895     1.5993210673332214e-01
    z[5,1,1]  R1896     5.6421858072280884e-01
    z[5,1,1]  R1897     1.5317335724830627e-01
    z[5,1,1]  R1898     7.8978991508483887e-01
    z[5,1,1]  R1899     4.4707828760147095e-01
    z[5,1,1]  R1900     4.8379644751548767e-01
    z[5,1,1]  R1901     4.0550419688224792e-01
    z[5,1,1]  R1902     5.6089580059051514e-01
    z[5,1,1]  R1903     -6.9278383255004883e-01
    z[5,1,1]  R1904     1.0703387856483459e-01
    z[5,1,1]  R1905     9.6009485423564911e-03
    z[5,1,1]  R1906     -7.1844294667243958e-02
    z[5,1,1]  R1907     -9.6338622272014618e-02
    z[5,1,1]  R1908     0.212177112698555
    z[5,1,1]  R1909     -3.5925975441932678e-01
    z[5,1,1]  R1910     2.7371007204055786e-01
    z[5,1,1]  R1911     4.9748173356056213e-01
    z[5,1,2]  R13       1
    z[5,1,2]  R49       -1
    z[5,1,2]  R1784     -1
    z[5,1,2]  R1785     1
    z[5,1,2]  R1794     2.7867025136947632e-01
    z[5,1,2]  R1795     -1.0877050459384918e-01
    z[5,1,2]  R1796     1.4166106283664703e-01
    z[5,1,2]  R1797     -1.6703473031520844e-01
    z[5,1,2]  R1798     -0.681039571762085
    z[5,1,2]  R1799     -7.1422152221202850e-02
    z[5,1,2]  R1800     -2.3632074892520905e-01
    z[5,1,2]  R1801     1.2734462320804596e-01
    z[5,1,2]  R1802     2.0489895343780518e-01
    z[5,1,2]  R1803     5.6785231828689575e-01
    z[5,1,2]  R1804     1.4935834705829620e-01
    z[5,1,2]  R1805     5.2744146436452866e-02
    z[5,1,2]  R1806     -3.7843767553567886e-02
    z[5,1,2]  R1807     -2.2276104986667633e-01
    z[5,1,2]  R1808     5.8946889638900757e-01
    z[5,1,2]  R1809     3.7942177057266235e-01
    z[5,1,2]  R1810     6.0760462284088135e-01
    z[5,1,2]  R1811     6.2808138132095337e-01
    z[5,1,2]  R1812     0.410097599029541
    z[5,1,2]  R1813     1.9897668063640594e-01
    z[5,1,2]  R1814     3.2608810067176819e-01
    z[5,1,2]  R1815     3.4057784080505371e-01
    z[5,1,2]  R1816     3.6706885695457458e-01
    z[5,1,2]  R1817     2.4889845401048660e-02
    z[5,1,2]  R1818     7.7606640756130219e-02
    z[5,1,2]  R1819     4.7487378120422363e-01
    z[5,1,2]  R1820     2.1392826735973358e-01
    z[5,1,2]  R1821     3.6713370680809021e-01
    z[5,1,2]  R1822     1.0967803001403809e-01
    z[5,1,2]  R1823     -4.1845682263374329e-01
    z[5,1,2]  R1824     -1.2607865035533905e-01
    z[5,1,2]  R1825     -0.486369788646698
    z[5,1,2]  R1826     5.4819411039352417e-01
    z[5,1,2]  R1827     0.567703127861023
    z[5,1,2]  R1828     3.9514392614364624e-02
    z[5,1,2]  R1829     4.5630556344985962e-01
    z[5,1,2]  R1830     -2.2555316984653473e-01
    z[5,1,2]  R1831     3.5645312070846558e-01
    z[5,1,2]  R1832     -4.2175155878067017e-01
    z[5,1,2]  R1833     1.6420675441622734e-02
    z[5,1,2]  R1834     4.6600274741649628e-02
    z[5,1,2]  R1835     -1.8738220632076263e-01
    z[5,1,2]  R1836     1.6186399757862091e-01
    z[5,1,2]  R1837     1.7931106686592102e-01
    z[5,1,2]  R1838     -3.0865499377250671e-01
    z[5,1,2]  R1839     -7.1684408187866211e-01
    z[5,1,2]  R1840     5.0356465578079224e-01
    z[5,1,2]  R1841     -7.8330940008163452e-01
    z[5,1,2]  R1842     4.0173164010047913e-01
    z[5,1,2]  R1843     6.7916172742843628e-01
    z[5,1,2]  R1844     5.6552004814147949e-01
    z[5,1,2]  R1845     6.2351912260055542e-01
    z[5,1,2]  R1846     2.7996173501014709e-01
    z[5,1,2]  R1847     1.4014796912670135e-01
    z[5,1,2]  R1848     2.6978957653045654e-01
    z[5,1,2]  R1849     -1.8271125853061676e-01
    z[5,1,2]  R1850     -3.0887761712074280e-01
    z[5,1,2]  R1851     1.8305076658725739e-01
    z[5,1,2]  R1852     4.6575519442558289e-01
    z[5,1,2]  R1853     4.3002769351005554e-02
    z[5,1,2]  R1854     1.5302455425262451e-01
    z[5,1,2]  R1855     1.3386055361479521e-03
    z[5,1,2]  R1856     1.3925452530384064e-01
    z[5,1,2]  R1857     3.2627224922180176e-01
    z[5,1,2]  R1858     -7.9252235591411591e-02
    z[5,1,2]  R1859     4.8510608077049255e-01
    z[5,1,2]  R1860     -1.7540137469768524e-01
    z[5,1,2]  R1861     -1.7894359305500984e-02
    z[5,1,2]  R1862     -1.7448730766773224e-01
    z[5,1,2]  R1863     1.3207750022411346e-01
    z[5,1,2]  R1864     -3.6221626400947571e-01
    z[5,1,2]  R1865     1.9669516384601593e-01
    z[5,1,2]  R1866     4.0278702974319458e-01
    z[5,1,2]  R1867     -2.0718200504779816e-01
    z[5,1,2]  R1868     -3.5573190450668335e-01
    z[5,1,2]  R1869     -6.5912526845932007e-01
    z[5,1,2]  R1870     1.1744274944067001e-01
    z[5,1,2]  R1871     -7.6905059814453125e-01
    z[5,1,2]  R1872     -9.8168686032295227e-02
    z[5,1,2]  R1873     9.7359839128330350e-04
    z[5,1,2]  R1874     -1.1752710491418839e-01
    z[5,1,2]  R1875     1.9486773014068604e-01
    z[5,1,2]  R1876     -5.7592725753784180e-01
    z[5,1,2]  R1877     -0.561223030090332
    z[5,1,2]  R1878     -5.7908612489700317e-01
    z[5,1,2]  R1879     -2.6552328467369080e-01
    z[5,1,2]  R1880     -6.9777297973632812e-01
    z[5,1,2]  R1881     -7.7856051921844482e-01
    z[5,1,2]  R1882     -9.9403075873851776e-02
    z[5,1,2]  R1883     3.4059146046638489e-01
    z[5,1,2]  R1884     1.4632999897003174e-01
    z[5,1,2]  R1885     3.2667240500450134e-01
    z[5,1,2]  R1886     1.5998254716396332e-01
    z[5,1,2]  R1887     -2.1347789466381073e-01
    z[5,1,2]  R1888     2.0259141921997070e-01
    z[5,1,2]  R1889     -4.5913219451904297e-01
    z[5,1,2]  R1890     -5.9972470998764038e-01
    z[5,1,2]  R1891     -6.4753305912017822e-01
    z[5,1,2]  R1892     -3.3333367109298706e-01
    z[5,1,2]  R1893     3.7514597177505493e-01
    z[5,1,2]  R1894     -2.6433351635932922e-01
    z[5,1,2]  R1895     -7.7267253398895264e-01
    z[5,1,2]  R1896     -1.0950347036123276e-01
    z[5,1,2]  R1897     4.1314274072647095e-01
    z[5,1,2]  R1898     -2.7503243088722229e-01
    z[5,1,2]  R1899     -1.9831565022468567e-01
    z[5,1,2]  R1900     -8.4968388080596924e-02
    z[5,1,2]  R1901     -1.5004470944404602e-01
    z[5,1,2]  R1902     -0.174790620803833
    z[5,1,2]  R1903     3.1620880961418152e-01
    z[5,1,2]  R1904     -6.8193428218364716e-02
    z[5,1,2]  R1905     -6.0812151432037354e-01
    z[5,1,2]  R1906     -7.1764141321182251e-01
    z[5,1,2]  R1907     -8.1184077262878418e-01
    z[5,1,2]  R1908     -1.2061801552772522e-01
    z[5,1,2]  R1909     1.9096738100051880e-01
    z[5,1,2]  R1910     -2.4020045995712280e-01
    z[5,1,2]  R1911     -3.7953026592731476e-02
    z[5,1,3]  R14       1
    z[5,1,3]  R50       -1
    z[5,1,3]  R1786     -1
    z[5,1,3]  R1787     1
    z[5,1,3]  R1794     -5.6948989629745483e-01
    z[5,1,3]  R1795     -4.2881119251251221e-01
    z[5,1,3]  R1796     -7.5719755887985229e-01
    z[5,1,3]  R1797     0.0762195810675621
    z[5,1,3]  R1798     4.4908598065376282e-02
    z[5,1,3]  R1799     8.4992036223411560e-02
    z[5,1,3]  R1800     -6.5855622291564941e-01
    z[5,1,3]  R1801     -5.6091868877410889e-01
    z[5,1,3]  R1802     -4.3509653210639954e-01
    z[5,1,3]  R1803     0.442421019077301
    z[5,1,3]  R1804     -1.7582742869853973e-01
    z[5,1,3]  R1805     -2.8553646802902222e-01
    z[5,1,3]  R1806     7.1413803100585938e-01
    z[5,1,3]  R1807     6.9978368282318115e-01
    z[5,1,3]  R1808     -9.4671607017517090e-02
    z[5,1,3]  R1809     0.0948103740811348
    z[5,1,3]  R1810     5.7832002639770508e-02
    z[5,1,3]  R1811     4.1294094175100327e-02
    z[5,1,3]  R1812     -1.8432404100894928e-01
    z[5,1,3]  R1813     -5.1463800668716431e-01
    z[5,1,3]  R1814     -6.4134937524795532e-01
    z[5,1,3]  R1815     -4.0266942977905273e-01
    z[5,1,3]  R1816     -4.4890768826007843e-02
    z[5,1,3]  R1817     -4.6394917368888855e-01
    z[5,1,3]  R1818     -3.5040271282196045e-01
    z[5,1,3]  R1819     -8.3797693252563477e-02
    z[5,1,3]  R1820     -2.0538680255413055e-03
    z[5,1,3]  R1821     -3.6634132266044617e-01
    z[5,1,3]  R1822     2.8865441679954529e-01
    z[5,1,3]  R1823     3.6795396357774734e-02
    z[5,1,3]  R1824     -1.4961647987365723e-01
    z[5,1,3]  R1825     1.3712696731090546e-01
    z[5,1,3]  R1826     6.4623266458511353e-02
    z[5,1,3]  R1827     -9.1978013515472412e-02
    z[5,1,3]  R1828     5.1226603984832764e-01
    z[5,1,3]  R1829     -3.9801809191703796e-01
    z[5,1,3]  R1830     -6.0857552289962769e-01
    z[5,1,3]  R1831     -5.7703101634979248e-01
    z[5,1,3]  R1832     2.6602050662040710e-01
    z[5,1,3]  R1833     1.8930549919605255e-01
    z[5,1,3]  R1834     6.5145730972290039e-01
    z[5,1,3]  R1835     4.7060206532478333e-01
    z[5,1,3]  R1836     4.4231966137886047e-01
    z[5,1,3]  R1837     3.7852790951728821e-01
    z[5,1,3]  R1838     2.2586712241172791e-01
    z[5,1,3]  R1839     4.2727984488010406e-02
    z[5,1,3]  R1840     5.4297196865081787e-01
    z[5,1,3]  R1841     1.6417096555233002e-01
    z[5,1,3]  R1842     -4.0744277834892273e-01
    z[5,1,3]  R1843     -4.2608398199081421e-01
    z[5,1,3]  R1844     1.6876373440027237e-02
    z[5,1,3]  R1845     -5.5595141649246216e-01
    z[5,1,3]  R1846     0.510107696056366
    z[5,1,3]  R1847     2.4046397209167480e-01
    z[5,1,3]  R1848     -3.1315666437149048e-01
    z[5,1,3]  R1849     2.9579216241836548e-01
    z[5,1,3]  R1850     3.9032116532325745e-01
    z[5,1,3]  R1851     -7.2604638338088989e-01
    z[5,1,3]  R1852     -1.0772946476936340e-01
    z[5,1,3]  R1853     -7.8980810940265656e-02
    z[5,1,3]  R1854     1.8345648050308228e-01
    z[5,1,3]  R1855     3.1382623314857483e-01
    z[5,1,3]  R1856     1.4028945565223694e-01
    z[5,1,3]  R1857     -4.3615886569023132e-01
    z[5,1,3]  R1858     -4.3881252408027649e-01
    z[5,1,3]  R1859     1.0959044843912125e-01
    z[5,1,3]  R1860     4.7214669175446033e-03
    z[5,1,3]  R1861     -1.2928792834281921e-01
    z[5,1,3]  R1862     -1.7415136098861694e-01
    z[5,1,3]  R1863     7.4559003114700317e-02
    z[5,1,3]  R1864     -1.0413333028554916e-01
    z[5,1,3]  R1865     1.8462552130222321e-01
    z[5,1,3]  R1866     0.713071882724762
    z[5,1,3]  R1867     4.2764917016029358e-01
    z[5,1,3]  R1868     6.1980700492858887e-01
    z[5,1,3]  R1869     3.4250319004058838e-01
    z[5,1,3]  R1870     0.574138879776001
    z[5,1,3]  R1871     3.9793962240219116e-01
    z[5,1,3]  R1872     -6.0092996805906296e-02
    z[5,1,3]  R1873     0.777245819568634
    z[5,1,3]  R1874     4.5326781272888184e-01
    z[5,1,3]  R1875     2.7885380387306213e-01
    z[5,1,3]  R1876     3.5766753554344177e-01
    z[5,1,3]  R1877     3.2030284404754639e-01
    z[5,1,3]  R1878     3.1763064861297607e-01
    z[5,1,3]  R1879     3.8000747561454773e-01
    z[5,1,3]  R1880     1.2909834086894989e-01
    z[5,1,3]  R1881     -2.4669134616851807e-01
    z[5,1,3]  R1882     -2.9174787923693657e-03
    z[5,1,3]  R1883     -2.8880032896995544e-01
    z[5,1,3]  R1884     4.0354898571968079e-01
    z[5,1,3]  R1885     1.3501471281051636e-01
    z[5,1,3]  R1886     -4.7309798002243042e-01
    z[5,1,3]  R1887     -2.9963061213493347e-01
    z[5,1,3]  R1888     5.4995840787887573e-01
    z[5,1,3]  R1889     4.1433700919151306e-01
    z[5,1,3]  R1890     4.0481972694396973e-01
    z[5,1,3]  R1891     3.9746868610382080e-01
    z[5,1,3]  R1892     -2.1642296016216278e-01
    z[5,1,3]  R1893     6.3129258155822754e-01
    z[5,1,3]  R1894     4.3214264512062073e-01
    z[5,1,3]  R1895     3.4522926807403564e-01
    z[5,1,3]  R1896     4.1966402530670166e-01
    z[5,1,3]  R1897     3.2063734531402588e-01
    z[5,1,3]  R1898     -1.9523462653160095e-01
    z[5,1,3]  R1899     -5.5567425489425659e-01
    z[5,1,3]  R1900     -4.6835356950759888e-01
    z[5,1,3]  R1901     -4.9415045976638794e-01
    z[5,1,3]  R1902     -1.4836981892585754e-01
    z[5,1,3]  R1903     2.6959040760993958e-01
    z[5,1,3]  R1904     5.1917874813079834e-01
    z[5,1,3]  R1905     4.2698773741722107e-01
    z[5,1,3]  R1906     3.9615362882614136e-01
    z[5,1,3]  R1907     2.7314865589141846e-01
    z[5,1,3]  R1908     2.4443480372428894e-01
    z[5,1,3]  R1909     3.0787822604179382e-01
    z[5,1,3]  R1910     -5.2298015356063843e-01
    z[5,1,3]  R1911     -2.9256063699722290e-01
    z[5,1,4]  R15       1
    z[5,1,4]  R51       -1
    z[5,1,4]  R1788     -1
    z[5,1,4]  R1789     1
    z[5,1,4]  R1794     5.4164677858352661e-02
    z[5,1,4]  R1795     4.6782290935516357e-01
    z[5,1,4]  R1796     -1.3765020668506622e-01
    z[5,1,4]  R1797     6.3581025600433350e-01
    z[5,1,4]  R1798     2.3368719220161438e-01
    z[5,1,4]  R1799     3.0189290642738342e-01
    z[5,1,4]  R1800     1.0823497176170349e-01
    z[5,1,4]  R1801     1.3297668099403381e-01
    z[5,1,4]  R1802     3.7571147084236145e-01
    z[5,1,4]  R1803     -1.9383493065834045e-01
    z[5,1,4]  R1804     -5.8535319566726685e-01
    z[5,1,4]  R1805     -4.5141065120697021e-01
    z[5,1,4]  R1806     3.5576120018959045e-01
    z[5,1,4]  R1807     3.0308127403259277e-01
    z[5,1,4]  R1808     -6.1856800317764282e-01
    z[5,1,4]  R1809     -8.9350748062133789e-01
    z[5,1,4]  R1810     -6.5405994653701782e-01
    z[5,1,4]  R1811     -7.2544282674789429e-01
    z[5,1,4]  R1812     1.3935865461826324e-01
    z[5,1,4]  R1813     -3.3856093883514404e-02
    z[5,1,4]  R1814     2.6250863075256348e-01
    z[5,1,4]  R1815     2.3572713136672974e-02
    z[5,1,4]  R1816     3.6814704537391663e-01
    z[5,1,4]  R1817     1.7465278506278992e-01
    z[5,1,4]  R1818     3.3341392874717712e-01
    z[5,1,4]  R1819     -7.4151274748146534e-04
    z[5,1,4]  R1820     2.8366908431053162e-01
    z[5,1,4]  R1821     5.4026669263839722e-01
    z[5,1,4]  R1822     -2.5515180826187134e-01
    z[5,1,4]  R1823     -2.7427467703819275e-01
    z[5,1,4]  R1824     -4.2240446805953979e-01
    z[5,1,4]  R1825     2.7976479381322861e-02
    z[5,1,4]  R1826     -1.7387789487838745e-01
    z[5,1,4]  R1827     -4.3352580070495605e-01
    z[5,1,4]  R1828     4.0010169148445129e-01
    z[5,1,4]  R1829     6.9646663963794708e-02
    z[5,1,4]  R1830     -5.0047025084495544e-02
    z[5,1,4]  R1831     -4.9046209454536438e-01
    z[5,1,4]  R1832     -3.5990697145462036e-01
    z[5,1,4]  R1833     9.0682750940322876e-01
    z[5,1,4]  R1834     6.9490909576416016e-01
    z[5,1,4]  R1835     7.9154515266418457e-01
    z[5,1,4]  R1836     7.2009402513504028e-01
    z[5,1,4]  R1837     7.0644110441207886e-01
    z[5,1,4]  R1838     8.1561535596847534e-01
    z[5,1,4]  R1839     -7.3069550096988678e-02
    z[5,1,4]  R1840     4.5287674665451050e-01
    z[5,1,4]  R1841     1.2962979078292847e-01
    z[5,1,4]  R1842     7.9473212361335754e-02
    z[5,1,4]  R1843     -1.3623583316802979e-01
    z[5,1,4]  R1844     2.1712502837181091e-01
    z[5,1,4]  R1845     8.6590774357318878e-02
    z[5,1,4]  R1846     7.9303735494613647e-01
    z[5,1,4]  R1847     -1.8995349109172821e-01
    z[5,1,4]  R1848     4.6238112449645996e-01
    z[5,1,4]  R1849     7.1789878606796265e-01
    z[5,1,4]  R1850     4.2612543702125549e-01
    z[5,1,4]  R1851     -2.2465731203556061e-01
    z[5,1,4]  R1852     1.1231165379285812e-01
    z[5,1,4]  R1853     4.8143625259399414e-01
    z[5,1,4]  R1854     3.1954690814018250e-01
    z[5,1,4]  R1855     3.2098862528800964e-01
    z[5,1,4]  R1856     -4.3746823072433472e-01
    z[5,1,4]  R1857     -1.7073710262775421e-01
    z[5,1,4]  R1858     -2.0819954574108124e-02
    z[5,1,4]  R1859     -0.0989551842212677
    z[5,1,4]  R1860     2.5268995761871338e-01
    z[5,1,4]  R1861     1.5949079394340515e-01
    z[5,1,4]  R1862     0.136853888630867
    z[5,1,4]  R1863     1.7795832455158234e-01
    z[5,1,4]  R1864     -1.3361354172229767e-01
    z[5,1,4]  R1865     8.3230429887771606e-01
    z[5,1,4]  R1866     4.1093739867210388e-01
    z[5,1,4]  R1867     5.3052127361297607e-01
    z[5,1,4]  R1868     5.1477003097534180e-01
    z[5,1,4]  R1869     5.0155729055404663e-01
    z[5,1,4]  R1870     2.9172223806381226e-01
    z[5,1,4]  R1871     4.8056846857070923e-01
    z[5,1,4]  R1872     2.6530984044075012e-01
    z[5,1,4]  R1873     5.4606622457504272e-01
    z[5,1,4]  R1874     7.8615558147430420e-01
    z[5,1,4]  R1875     6.2929922342300415e-01
    z[5,1,4]  R1876     2.6644504070281982e-01
    z[5,1,4]  R1877     -3.8745053112506866e-02
    z[5,1,4]  R1878     2.0344233512878418e-01
    z[5,1,4]  R1879     1.7360401153564453e-01
    z[5,1,4]  R1880     5.9470452368259430e-02
    z[5,1,4]  R1881     2.6736825704574585e-02
    z[5,1,4]  R1882     3.3870872855186462e-01
    z[5,1,4]  R1883     5.5658571422100067e-02
    z[5,1,4]  R1884     -7.8829256817698479e-03
    z[5,1,4]  R1885     7.8902617096900940e-02
    z[5,1,4]  R1886     1.1656423658132553e-01
    z[5,1,4]  R1887     2.7199275791645050e-02
    z[5,1,4]  R1888     4.8117798566818237e-01
    z[5,1,4]  R1889     3.0255025625228882e-01
    z[5,1,4]  R1890     3.3595968037843704e-02
    z[5,1,4]  R1891     1.6369393467903137e-01
    z[5,1,4]  R1892     -2.9842811822891235e-01
    z[5,1,4]  R1893     5.3670382499694824e-01
    z[5,1,4]  R1894     4.7548791766166687e-01
    z[5,1,4]  R1895     2.9210817813873291e-01
    z[5,1,4]  R1896     4.8938098549842834e-01
    z[5,1,4]  R1897     3.6667466163635254e-01
    z[5,1,4]  R1898     -3.0993974208831787e-01
    z[5,1,4]  R1899     -2.1801907569169998e-02
    z[5,1,4]  R1900     -6.2543079257011414e-02
    z[5,1,4]  R1901     -2.3602099716663361e-01
    z[5,1,4]  R1902     8.2893833518028259e-02
    z[5,1,4]  R1903     2.8686946630477905e-01
    z[5,1,4]  R1904     7.8496611118316650e-01
    z[5,1,4]  R1905     1.9304936751723289e-02
    z[5,1,4]  R1906     0.449378103017807
    z[5,1,4]  R1907     -3.3246347308158875e-01
    z[5,1,4]  R1908     -1.7195332795381546e-02
    z[5,1,4]  R1909     2.4461318552494049e-01
    z[5,1,4]  R1910     1.0814021341502666e-02
    z[5,1,4]  R1911     1.1211378872394562e-01
    z[5,1,5]  R16       1
    z[5,1,5]  R52       -1
    z[5,1,5]  R1790     -1
    z[5,1,5]  R1791     1
    z[5,1,5]  R1794     -1.4287843368947506e-02
    z[5,1,5]  R1795     -5.6503123044967651e-01
    z[5,1,5]  R1796     -4.3702629208564758e-01
    z[5,1,5]  R1797     -1.3089406490325928e-01
    z[5,1,5]  R1798     -1.7761671543121338e-01
    z[5,1,5]  R1799     -1.0719674080610275e-01
    z[5,1,5]  R1800     -5.2818857133388519e-02
    z[5,1,5]  R1801     -4.0881308913230896e-01
    z[5,1,5]  R1802     -2.4879913777112961e-02
    z[5,1,5]  R1803     1.7187925055623055e-02
    z[5,1,5]  R1804     2.3088967800140381e-01
    z[5,1,5]  R1805     -5.8473899960517883e-02
    z[5,1,5]  R1806     -4.6503199264407158e-03
    z[5,1,5]  R1807     7.1491762995719910e-02
    z[5,1,5]  R1808     1.2345013022422791e-01
    z[5,1,5]  R1809     -1.6062812507152557e-01
    z[5,1,5]  R1810     -3.3547499775886536e-01
    z[5,1,5]  R1811     -2.1850788965821266e-02
    z[5,1,5]  R1812     -7.4647432565689087e-01
    z[5,1,5]  R1813     -6.3916242122650146e-01
    z[5,1,5]  R1814     -5.0884467363357544e-01
    z[5,1,5]  R1815     -7.2125869989395142e-01
    z[5,1,5]  R1816     -7.8055894374847412e-01
    z[5,1,5]  R1817     -6.7628163099288940e-01
    z[5,1,5]  R1818     -7.5406205654144287e-01
    z[5,1,5]  R1819     -5.4106724262237549e-01
    z[5,1,5]  R1820     -7.7640181779861450e-01
    z[5,1,5]  R1821     -3.3120352029800415e-01
    z[5,1,5]  R1822     -1.7839916050434113e-01
    z[5,1,5]  R1823     3.4148350358009338e-02
    z[5,1,5]  R1824     1.8258308991789818e-02
    z[5,1,5]  R1825     -1.8633460998535156e-01
    z[5,1,5]  R1826     -1.9224444031715393e-01
    z[5,1,5]  R1827     1.1763998866081238e-01
    z[5,1,5]  R1828     2.6581385731697083e-01
    z[5,1,5]  R1829     -3.4957072138786316e-01
    z[5,1,5]  R1830     9.1608978807926178e-02
    z[5,1,5]  R1831     4.0881808847188950e-02
    z[5,1,5]  R1832     2.3601700365543365e-01
    z[5,1,5]  R1833     1.3677023351192474e-01
    z[5,1,5]  R1834     7.3405399918556213e-02
    z[5,1,5]  R1835     1.0969126969575882e-01
    z[5,1,5]  R1836     9.2714056372642517e-02
    z[5,1,5]  R1837     1.4815928041934967e-01
    z[5,1,5]  R1838     2.1618127822875977e-01
    z[5,1,5]  R1839     8.9850440621376038e-02
    z[5,1,5]  R1840     3.2188418507575989e-01
    z[5,1,5]  R1841     1.1667750775814056e-02
    z[5,1,5]  R1842     3.9937481284141541e-01
    z[5,1,5]  R1843     -8.7309010326862335e-02
    z[5,1,5]  R1844     2.4414394795894623e-01
    z[5,1,5]  R1845     2.3820179700851440e-01
    z[5,1,5]  R1846     1.0241446644067764e-01
    z[5,1,5]  R1847     4.2090556025505066e-01
    z[5,1,5]  R1848     -6.4658693969249725e-02
    z[5,1,5]  R1849     -1.1355581879615784e-01
    z[5,1,5]  R1850     1.5739759802818298e-01
    z[5,1,5]  R1851     2.3948132991790771e-01
    z[5,1,5]  R1852     2.2364287078380585e-01
    z[5,1,5]  R1853     1.7969799041748047e-01
    z[5,1,5]  R1854     -3.2613289356231689e-01
    z[5,1,5]  R1855     4.9317643046379089e-01
    z[5,1,5]  R1856     3.1518206000328064e-01
    z[5,1,5]  R1857     -3.0196252465248108e-01
    z[5,1,5]  R1858     2.6776146888732910e-01
    z[5,1,5]  R1859     3.0875065922737122e-01
    z[5,1,5]  R1860     1.9810175895690918e-01
    z[5,1,5]  R1861     4.8662075400352478e-01
    z[5,1,5]  R1862     1.3925476372241974e-01
    z[5,1,5]  R1863     4.4187238812446594e-01
    z[5,1,5]  R1864     3.6108088493347168e-01
    z[5,1,5]  R1865     4.4546341896057129e-01
    z[5,1,5]  R1866     1.2333232164382935e-01
    z[5,1,5]  R1867     -1.0340360924601555e-02
    z[5,1,5]  R1868     2.5306472182273865e-01
    z[5,1,5]  R1869     3.0567046254873276e-02
    z[5,1,5]  R1870     1.1456538736820221e-01
    z[5,1,5]  R1871     4.9303401261568069e-02
    z[5,1,5]  R1872     4.6101510524749756e-01
    z[5,1,5]  R1873     3.7257452495396137e-03
    z[5,1,5]  R1874     1.2055249512195587e-01
    z[5,1,5]  R1875     1.0165440291166306e-01
    z[5,1,5]  R1876     -3.0589890480041504e-01
    z[5,1,5]  R1877     -1.5219344198703766e-01
    z[5,1,5]  R1878     -8.9321933686733246e-02
    z[5,1,5]  R1879     -6.7859692499041557e-03
    z[5,1,5]  R1880     -1.3576747849583626e-02
    z[5,1,5]  R1881     1.4903441071510315e-01
    z[5,1,5]  R1882     -0.248980313539505
    z[5,1,5]  R1883     -0.105091892182827
    z[5,1,5]  R1884     4.3572276830673218e-01
    z[5,1,5]  R1885     -5.9681254625320435e-01
    z[5,1,5]  R1886     -4.2099773883819580e-01
    z[5,1,5]  R1887     4.4694775342941284e-01
    z[5,1,5]  R1888     2.5101962685585022e-01
    z[5,1,5]  R1889     -1.2519478797912598e-01
    z[5,1,5]  R1890     -2.3776248097419739e-01
    z[5,1,5]  R1891     -8.8280171155929565e-02
    z[5,1,5]  R1892     -1.3381315767765045e-01
    z[5,1,5]  R1893     2.9748940467834473e-01
    z[5,1,5]  R1894     4.6417381614446640e-02
    z[5,1,5]  R1895     -8.5791319608688354e-02
    z[5,1,5]  R1896     -1.8986134231090546e-01
    z[5,1,5]  R1897     1.2778806686401367e-01
    z[5,1,5]  R1898     0.00913998018950224
    z[5,1,5]  R1899     1.4865861833095551e-01
    z[5,1,5]  R1900     -2.4004525039345026e-03
    z[5,1,5]  R1901     -2.4128738045692444e-01
    z[5,1,5]  R1902     0.412727415561676
    z[5,1,5]  R1903     2.9499068856239319e-01
    z[5,1,5]  R1904     2.1359564363956451e-01
    z[5,1,5]  R1905     -1.1896307766437531e-01
    z[5,1,5]  R1906     2.3534636944532394e-02
    z[5,1,5]  R1907     -1.2104593962430954e-01
    z[5,1,5]  R1908     6.8074040114879608e-02
    z[5,1,5]  R1909     1.6482903063297272e-01
    z[5,1,5]  R1910     -8.3766825497150421e-02
    z[5,1,5]  R1911     -2.2390339523553848e-02
    z[5,1,6]  R17       1
    z[5,1,6]  R53       -1
    z[5,1,6]  R1792     -1
    z[5,1,6]  R1793     1
    z[5,1,6]  R1794     6.1444687843322754e-01
    z[5,1,6]  R1795     -4.3590404093265533e-03
    z[5,1,6]  R1796     2.2357994690537453e-02
    z[5,1,6]  R1797     5.7348549365997314e-01
    z[5,1,6]  R1798     -6.9269933737814426e-03
    z[5,1,6]  R1799     1.0610774904489517e-01
    z[5,1,6]  R1800     1.7449681460857391e-01
    z[5,1,6]  R1801     7.7917866408824921e-02
    z[5,1,6]  R1802     4.0451128035783768e-02
    z[5,1,6]  R1803     -2.2428588569164276e-01
    z[5,1,6]  R1804     -4.0222319960594177e-01
    z[5,1,6]  R1805     -7.0052641630172729e-01
    z[5,1,6]  R1806     -3.9406427741050720e-01
    z[5,1,6]  R1807     -2.1893793344497681e-01
    z[5,1,6]  R1808     0.0604308545589447
    z[5,1,6]  R1809     1.7724696546792984e-02
    z[5,1,6]  R1810     5.0938300788402557e-02
    z[5,1,6]  R1811     -1.3692008331418037e-02
    z[5,1,6]  R1812     1.5904265642166138e-01
    z[5,1,6]  R1813     0.271445095539093
    z[5,1,6]  R1814     -1.3883425295352936e-01
    z[5,1,6]  R1815     2.8788670897483826e-01
    z[5,1,6]  R1816     9.2242740094661713e-02
    z[5,1,6]  R1817     -1.1773692071437836e-01
    z[5,1,6]  R1818     -0.304904043674469
    z[5,1,6]  R1819     -3.5347026586532593e-01
    z[5,1,6]  R1820     -3.7749823927879333e-01
    z[5,1,6]  R1821     1.2803323566913605e-01
    z[5,1,6]  R1822     2.3802106082439423e-01
    z[5,1,6]  R1823     2.0687267184257507e-01
    z[5,1,6]  R1824     -1.9543178379535675e-01
    z[5,1,6]  R1825     -5.0599705427885056e-02
    z[5,1,6]  R1826     -2.8501942753791809e-01
    z[5,1,6]  R1827     -4.4072084128856659e-02
    z[5,1,6]  R1828     3.5985404253005981e-01
    z[5,1,6]  R1829     -2.4825769662857056e-01
    z[5,1,6]  R1830     -4.9248144030570984e-01
    z[5,1,6]  R1831     -2.6498025655746460e-01
    z[5,1,6]  R1832     1.8578261137008667e-01
    z[5,1,6]  R1833     -0.0825931504368782
    z[5,1,6]  R1834     9.1572798788547516e-02
    z[5,1,6]  R1835     3.6711718887090683e-02
    z[5,1,6]  R1836     2.3696108162403107e-01
    z[5,1,6]  R1837     4.5238483697175980e-02
    z[5,1,6]  R1838     -3.4410390257835388e-01
    z[5,1,6]  R1839     -0.0334925651550293
    z[5,1,6]  R1840     -4.7413217835128307e-03
    z[5,1,6]  R1841     -1.4855190180242062e-02
    z[5,1,6]  R1842     -1.7784331738948822e-01
    z[5,1,6]  R1843     1.5596219897270203e-01
    z[5,1,6]  R1844     -2.1742123365402222e-01
    z[5,1,6]  R1845     -3.1197572126984596e-02
    z[5,1,6]  R1846     -9.3162119388580322e-02
    z[5,1,6]  R1847     1.5060979127883911e-01
    z[5,1,6]  R1848     -3.0172318220138550e-02
    z[5,1,6]  R1849     1.1491342447698116e-02
    z[5,1,6]  R1850     -6.6568199545145035e-03
    z[5,1,6]  R1851     1.2094780057668686e-01
    z[5,1,6]  R1852     3.0671152472496033e-01
    z[5,1,6]  R1853     1.8265551328659058e-01
    z[5,1,6]  R1854     -3.7411868572235107e-01
    z[5,1,6]  R1855     2.1233037114143372e-01
    z[5,1,6]  R1856     0.196168914437294
    z[5,1,6]  R1857     -3.9702009409666061e-02
    z[5,1,6]  R1858     2.5907030701637268e-01
    z[5,1,6]  R1859     -2.2752623260021210e-01
    z[5,1,6]  R1860     -4.2170169949531555e-01
    z[5,1,6]  R1861     -1.9631689786911011e-01
    z[5,1,6]  R1862     -6.1951391398906708e-02
    z[5,1,6]  R1863     1.1733530461788177e-01
    z[5,1,6]  R1864     -4.0632402896881104e-01
    z[5,1,6]  R1865     -6.6393963992595673e-02
    z[5,1,6]  R1866     3.7370380759239197e-01
    z[5,1,6]  R1867     -2.9392614960670471e-01
    z[5,1,6]  R1868     -1.1798671633005142e-01
    z[5,1,6]  R1869     1.8293111026287079e-01
    z[5,1,6]  R1870     -3.6410754919052124e-01
    z[5,1,6]  R1871     -1.0908308625221252e-01
    z[5,1,6]  R1872     2.6725763082504272e-01
    z[5,1,6]  R1873     2.5766745209693909e-01
    z[5,1,6]  R1874     -3.0579122900962830e-01
    z[5,1,6]  R1875     -5.7885181903839111e-01
    z[5,1,6]  R1876     1.6591729223728180e-01
    z[5,1,6]  R1877     1.4609168469905853e-01
    z[5,1,6]  R1878     -5.5366444587707520e-01
    z[5,1,6]  R1879     -3.5493856668472290e-01
    z[5,1,6]  R1880     -0.546783983707428
    z[5,1,6]  R1881     -2.9336306452751160e-01
    z[5,1,6]  R1882     -6.3115954399108887e-02
    z[5,1,6]  R1883     -4.1935643553733826e-01
    z[5,1,6]  R1884     5.7996802031993866e-02
    z[5,1,6]  R1885     -1.8123584985733032e-01
    z[5,1,6]  R1886     -0.336314857006073
    z[5,1,6]  R1887     -3.0428001284599304e-01
    z[5,1,6]  R1888     -3.0388179421424866e-01
    z[5,1,6]  R1889     -1.1459008604288101e-01
    z[5,1,6]  R1890     -3.3831059932708740e-02
    z[5,1,6]  R1891     3.8647550344467163e-01
    z[5,1,6]  R1892     -1.0314249992370605e-01
    z[5,1,6]  R1893     7.8031592071056366e-02
    z[5,1,6]  R1894     -2.4493908509612083e-02
    z[5,1,6]  R1895     -2.7924704551696777e-01
    z[5,1,6]  R1896     6.3042402267456055e-02
    z[5,1,6]  R1897     -3.0630344152450562e-01
    z[5,1,6]  R1898     -5.7962872087955475e-02
    z[5,1,6]  R1899     -2.0928554236888885e-01
    z[5,1,6]  R1900     1.4468098059296608e-02
    z[5,1,6]  R1901     3.2767906785011292e-02
    z[5,1,6]  R1902     -7.0363827049732208e-02
    z[5,1,6]  R1903     1.9452148675918579e-01
    z[5,1,6]  R1904     -3.8339901715517044e-02
    z[5,1,6]  R1905     3.0110573768615723e-01
    z[5,1,6]  R1906     2.4829675257205963e-01
    z[5,1,6]  R1907     -2.5787854194641113e-01
    z[5,1,6]  R1908     3.1721785664558411e-01
    z[5,1,6]  R1909     -6.0341215133666992e-01
    z[5,1,6]  R1910     5.3015735000371933e-02
    z[5,1,6]  R1911     1.1071027070283890e-01
    z[2,4,0]  R20       -1
    z[2,4,0]  R38       1
    z[2,4,0]  R1912     -1
    z[2,4,0]  R1913     1
    z[2,4,0]  R1926     7.4829590320587158e-01
    z[2,4,0]  R1927     5.1608401536941528e-01
    z[2,4,0]  R1928     0.537086009979248
    z[2,4,0]  R1929     4.9732410907745361e-01
    z[2,4,0]  R1930     4.7364082932472229e-01
    z[2,4,0]  R1931     -7.3809754848480225e-01
    z[2,4,0]  R1932     -2.6245564222335815e-01
    z[2,4,0]  R1933     -3.8120758533477783e-01
    z[2,4,0]  R1934     1.0940525680780411e-01
    z[2,4,0]  R1935     -3.2202787697315216e-03
    z[2,4,0]  R1936     1.4168143272399902e-01
    z[2,4,0]  R1937     -4.6991547942161560e-01
    z[2,4,0]  R1938     -2.5674232840538025e-01
    z[2,4,0]  R1939     3.3428356051445007e-01
    z[2,4,0]  R1940     0.565673291683197
    z[2,4,0]  R1941     -1.8310900032520294e-01
    z[2,4,0]  R1942     -2.4000744521617889e-01
    z[2,4,0]  R1943     -3.2580006122589111e-01
    z[2,4,0]  R1944     0.0563129186630249
    z[2,4,0]  R1945     -2.3766435682773590e-01
    z[2,4,0]  R1946     7.2173547744750977e-01
    z[2,4,0]  R1947     -2.6034882664680481e-01
    z[2,4,0]  R1948     -8.8026374578475952e-02
    z[2,4,0]  R1949     7.0207589864730835e-01
    z[2,4,0]  R1950     1.3437853753566742e-01
    z[2,4,0]  R1951     6.1883461475372314e-01
    z[2,4,0]  R1952     5.5191999673843384e-01
    z[2,4,0]  R1953     5.7589358091354370e-01
    z[2,4,0]  R1954     1.9529409706592560e-01
    z[2,4,0]  R1955     8.8348609209060669e-01
    z[2,4,0]  R1956     0.498344749212265
    z[2,4,0]  R1957     -5.7064223289489746e-01
    z[2,4,0]  R1958     -3.8162621855735779e-01
    z[2,4,0]  R1959     -5.8480417728424072e-01
    z[2,4,0]  R1960     -4.7194001078605652e-01
    z[2,4,0]  R1961     -4.4435703754425049e-01
    z[2,4,0]  R1962     -4.1637751460075378e-01
    z[2,4,0]  R1963     -4.7644710540771484e-01
    z[2,4,0]  R1964     -6.2589657306671143e-01
    z[2,4,0]  R1965     -3.0824321508407593e-01
    z[2,4,0]  R1966     6.4118367433547974e-01
    z[2,4,0]  R1967     5.4827427864074707e-01
    z[2,4,0]  R1968     3.2010135054588318e-01
    z[2,4,0]  R1969     1.3908789493143559e-02
    z[2,4,0]  R1970     3.6178115010261536e-01
    z[2,4,0]  R1971     3.5426384210586548e-01
    z[2,4,0]  R1972     3.4391263127326965e-01
    z[2,4,0]  R1973     -3.3993339538574219e-01
    z[2,4,0]  R1974     -0.0794341191649437
    z[2,4,0]  R1975     -1.8189454078674316e-01
    z[2,4,0]  R1976     6.8536871671676636e-01
    z[2,4,0]  R1977     6.1935573816299438e-01
    z[2,4,0]  R1978     -4.0746080875396729e-01
    z[2,4,0]  R1979     4.1207635402679443e-01
    z[2,4,0]  R1980     -3.0557766556739807e-02
    z[2,4,0]  R1981     1.9815362989902496e-01
    z[2,4,0]  R1982     -1.0177161544561386e-01
    z[2,4,0]  R1983     -3.2355093955993652e-01
    z[2,4,0]  R1984     -3.2967633008956909e-01
    z[2,4,0]  R1985     -5.7720702886581421e-01
    z[2,4,1]  R21       -1
    z[2,4,1]  R39       1
    z[2,4,1]  R1914     -1
    z[2,4,1]  R1915     1
    z[2,4,1]  R1926     -3.2144561409950256e-01
    z[2,4,1]  R1927     -2.0471605658531189e-01
    z[2,4,1]  R1928     -3.1970420479774475e-01
    z[2,4,1]  R1929     -1.8541653454303741e-01
    z[2,4,1]  R1930     1.3635165989398956e-01
    z[2,4,1]  R1931     -1.0374334640800953e-02
    z[2,4,1]  R1932     -2.3291751742362976e-01
    z[2,4,1]  R1933     3.8018960505723953e-02
    z[2,4,1]  R1934     6.7745143175125122e-01
    z[2,4,1]  R1935     0.726978063583374
    z[2,4,1]  R1936     3.9020961523056030e-01
    z[2,4,1]  R1937     -2.1759761869907379e-01
    z[2,4,1]  R1938     -3.1393334269523621e-01
    z[2,4,1]  R1939     5.5078876018524170e-01
    z[2,4,1]  R1940     0.0785161480307579
    z[2,4,1]  R1941     -8.9253157377243042e-02
    z[2,4,1]  R1942     -2.2639174759387970e-01
    z[2,4,1]  R1943     -4.4696471095085144e-01
    z[2,4,1]  R1944     8.1399637460708618e-01
    z[2,4,1]  R1945     7.4620097875595093e-01
    z[2,4,1]  R1946     4.7464835643768311e-01
    z[2,4,1]  R1947     -3.7263244390487671e-01
    z[2,4,1]  R1948     -5.8896821737289429e-01
    z[2,4,1]  R1949     5.5480856448411942e-02
    z[2,4,1]  R1950     -0.356360524892807
    z[2,4,1]  R1951     -2.9439383745193481e-01
    z[2,4,1]  R1952     -3.9077866077423096e-01
    z[2,4,1]  R1953     4.5883551239967346e-01
    z[2,4,1]  R1954     -2.5890287756919861e-01
    z[2,4,1]  R1955     1.8817149102687836e-01
    z[2,4,1]  R1956     -3.1648527830839157e-02
    z[2,4,1]  R1957     4.7781169414520264e-01
    z[2,4,1]  R1958     4.4560694694519043e-01
    z[2,4,1]  R1959     5.7730001211166382e-01
    z[2,4,1]  R1960     3.6223095655441284e-01
    z[2,4,1]  R1961     4.5222055912017822e-01
    z[2,4,1]  R1962     5.4885065555572510e-01
    z[2,4,1]  R1963     5.3115218877792358e-01
    z[2,4,1]  R1964     5.1203662157058716e-01
    z[2,4,1]  R1965     -3.8567224144935608e-01
    z[2,4,1]  R1966     -4.6898555010557175e-02
    z[2,4,1]  R1967     1.9691698253154755e-01
    z[2,4,1]  R1968     -3.3078789710998535e-01
    z[2,4,1]  R1969     -2.5322714447975159e-01
    z[2,4,1]  R1970     -0.521737277507782
    z[2,4,1]  R1971     2.8693714737892151e-01
    z[2,4,1]  R1972     -4.4296371936798096e-01
    z[2,4,1]  R1973     -6.5261906385421753e-01
    z[2,4,1]  R1974     5.0646450370550156e-02
    z[2,4,1]  R1975     -8.7560421228408813e-01
    z[2,4,1]  R1976     8.7547548115253448e-02
    z[2,4,1]  R1977     -5.1780784130096436e-01
    z[2,4,1]  R1978     -5.1614469289779663e-01
    z[2,4,1]  R1979     -1.3408043980598450e-01
    z[2,4,1]  R1980     -1.9141638278961182e-01
    z[2,4,1]  R1981     5.2375458180904388e-02
    z[2,4,1]  R1982     1.0893474519252777e-01
    z[2,4,1]  R1983     -1.1364394426345825e-01
    z[2,4,1]  R1984     -2.2669158875942230e-01
    z[2,4,1]  R1985     -0.592122495174408
    z[2,4,2]  R22       -1
    z[2,4,2]  R40       1
    z[2,4,2]  R1916     -1
    z[2,4,2]  R1917     1
    z[2,4,2]  R1926     -0.515376091003418
    z[2,4,2]  R1927     4.1804668307304382e-01
    z[2,4,2]  R1928     1.2986409664154053e-01
    z[2,4,2]  R1929     4.5868310332298279e-01
    z[2,4,2]  R1930     3.5329717397689819e-01
    z[2,4,2]  R1931     2.0457613468170166e-01
    z[2,4,2]  R1932     -1.2198117375373840e-01
    z[2,4,2]  R1933     -0.887882649898529
    z[2,4,2]  R1934     -3.7543609738349915e-01
    z[2,4,2]  R1935     -4.6628442406654358e-01
    z[2,4,2]  R1936     1.2427022308111191e-01
    z[2,4,2]  R1937     -2.0072016119956970e-01
    z[2,4,2]  R1938     3.8638854026794434e-01
    z[2,4,2]  R1939     -0.310772567987442
    z[2,4,2]  R1940     2.9522114992141724e-01
    z[2,4,2]  R1941     -8.5445863008499146e-01
    z[2,4,2]  R1942     -9.0961974859237671e-01
    z[2,4,2]  R1943     -6.8891471624374390e-01
    z[2,4,2]  R1944     -8.8315911591053009e-02
    z[2,4,2]  R1945     -2.7855682373046875e-01
    z[2,4,2]  R1946     2.0658016204833984e-01
    z[2,4,2]  R1947     5.1609843969345093e-01
    z[2,4,2]  R1948     6.4757645130157471e-01
    z[2,4,2]  R1949     9.8929800093173981e-02
    z[2,4,2]  R1950     5.5037707090377808e-01
    z[2,4,2]  R1951     1.7464052140712738e-01
    z[2,4,2]  R1952     -2.3853220045566559e-01
    z[2,4,2]  R1953     5.0685471296310425e-01
    z[2,4,2]  R1954     2.4018318951129913e-01
    z[2,4,2]  R1955     9.5787599682807922e-02
    z[2,4,2]  R1956     -5.3479593992233276e-01
    z[2,4,2]  R1957     -5.9657585620880127e-01
    z[2,4,2]  R1958     -7.1719348430633545e-01
    z[2,4,2]  R1959     -4.3153610825538635e-01
    z[2,4,2]  R1960     -6.7312496900558472e-01
    z[2,4,2]  R1961     -6.3912689685821533e-01
    z[2,4,2]  R1962     -6.0853153467178345e-01
    z[2,4,2]  R1963     -4.1915518045425415e-01
    z[2,4,2]  R1964     -3.3209469914436340e-01
    z[2,4,2]  R1965     -8.0496203899383545e-01
    z[2,4,2]  R1966     -4.6399781107902527e-01
    z[2,4,2]  R1967     -5.1879197359085083e-01
    z[2,4,2]  R1968     -4.1803181171417236e-01
    z[2,4,2]  R1969     1.7579983174800873e-01
    z[2,4,2]  R1970     -2.2754608094692230e-01
    z[2,4,2]  R1971     -2.3996305465698242e-01
    z[2,4,2]  R1972     1.5741537511348724e-01
    z[2,4,2]  R1973     -4.3415728211402893e-01
    z[2,4,2]  R1974     0.576196551322937
    z[2,4,2]  R1975     -4.0394324064254761e-01
    z[2,4,2]  R1976     -0.0334198921918869
    z[2,4,2]  R1977     1.4081464707851410e-01
    z[2,4,2]  R1978     1.9569399952888489e-01
    z[2,4,2]  R1979     1.2754398584365845e-01
    z[2,4,2]  R1980     3.7761977314949036e-01
    z[2,4,2]  R1981     0.517429530620575
    z[2,4,2]  R1982     7.9806648194789886e-02
    z[2,4,2]  R1983     -7.7853941917419434e-01
    z[2,4,2]  R1984     -7.5481927394866943e-01
    z[2,4,2]  R1985     -3.2312935590744019e-01
    z[2,4,3]  R23       -1
    z[2,4,3]  R41       1
    z[2,4,3]  R1918     -1
    z[2,4,3]  R1919     1
    z[2,4,3]  R1926     1.5286819636821747e-01
    z[2,4,3]  R1927     -5.1591819524765015e-01
    z[2,4,3]  R1928     -4.9240902066230774e-01
    z[2,4,3]  R1929     -1.6610951721668243e-01
    z[2,4,3]  R1930     -3.2557976245880127e-01
    z[2,4,3]  R1931     -6.2602853775024414e-01
    z[2,4,3]  R1932     -0.666356086730957
    z[2,4,3]  R1933     1.1362785845994949e-01
    z[2,4,3]  R1934     1.0532516241073608e-01
    z[2,4,3]  R1935     0.0982937142252922
    z[2,4,3]  R1936     6.8599176406860352e-01
    z[2,4,3]  R1937     5.1633769273757935e-01
    z[2,4,3]  R1938     6.7470401525497437e-01
    z[2,4,3]  R1939     -3.8525089621543884e-01
    z[2,4,3]  R1940     4.1681462526321411e-01
    z[2,4,3]  R1941     3.9265963435173035e-01
    z[2,4,3]  R1942     5.7291448116302490e-02
    z[2,4,3]  R1943     3.3894369006156921e-01
    z[2,4,3]  R1944     -1.3183162547647953e-02
    z[2,4,3]  R1945     8.3016470074653625e-02
    z[2,4,3]  R1946     8.6531199514865875e-02
    z[2,4,3]  R1947     -5.8207309246063232e-01
    z[2,4,3]  R1948     -3.2332116365432739e-01
    z[2,4,3]  R1949     -1.1367462575435638e-01
    z[2,4,3]  R1950     -5.6814730167388916e-01
    z[2,4,3]  R1951     -3.3525720238685608e-01
    z[2,4,3]  R1952     -1.4600183814764023e-02
    z[2,4,3]  R1953     1.4067446812987328e-02
    z[2,4,3]  R1954     -8.1641548871994019e-01
    z[2,4,3]  R1955     -2.7022278308868408e-01
    z[2,4,3]  R1956     2.8645089268684387e-01
    z[2,4,3]  R1957     2.1356928348541260e-01
    z[2,4,3]  R1958     2.5227975845336914e-01
    z[2,4,3]  R1959     2.4058888852596283e-01
    z[2,4,3]  R1960     3.8215324282646179e-01
    z[2,4,3]  R1961     2.8521296381950378e-01
    z[2,4,3]  R1962     3.2522711157798767e-01
    z[2,4,3]  R1963     1.5950119495391846e-01
    z[2,4,3]  R1964     1.9036103785037994e-01
    z[2,4,3]  R1965     1.2890487909317017e-01
    z[2,4,3]  R1966     -3.3502274751663208e-01
    z[2,4,3]  R1967     5.0122457742691040e-01
    z[2,4,3]  R1968     3.6730784177780151e-01
    z[2,4,3]  R1969     -1.6924814879894257e-01
    z[2,4,3]  R1970     0.257690966129303
    z[2,4,3]  R1971     2.8943282365798950e-01
    z[2,4,3]  R1972     3.2569810282438993e-03
    z[2,4,3]  R1973     -3.0136129260063171e-01
    z[2,4,3]  R1974     7.9324334859848022e-02
    z[2,4,3]  R1975     -5.9938136488199234e-02
    z[2,4,3]  R1976     1.2918472290039062e-01
    z[2,4,3]  R1977     -5.5456644296646118e-01
    z[2,4,3]  R1978     -3.4559625387191772e-01
    z[2,4,3]  R1979     4.1245266795158386e-01
    z[2,4,3]  R1980     2.6273833587765694e-02
    z[2,4,3]  R1981     0.0676998421549797
    z[2,4,3]  R1982     3.5153287649154663e-01
    z[2,4,3]  R1983     4.7362190485000610e-01
    z[2,4,3]  R1984     2.2187928855419159e-01
    z[2,4,3]  R1985     3.4765559434890747e-01
    z[2,4,4]  R24       -1
    z[2,4,4]  R42       1
    z[2,4,4]  R1920     -1
    z[2,4,4]  R1921     1
    z[2,4,4]  R1926     1.4716325700283051e-01
    z[2,4,4]  R1927     1.8556064367294312e-01
    z[2,4,4]  R1928     -6.7625559866428375e-02
    z[2,4,4]  R1929     -6.6623234748840332e-01
    z[2,4,4]  R1930     6.1862188577651978e-01
    z[2,4,4]  R1931     1.4586891233921051e-01
    z[2,4,4]  R1932     -2.1497756242752075e-01
    z[2,4,4]  R1933     -1.0132491588592529e-01
    z[2,4,4]  R1934     1.1973230540752411e-01
    z[2,4,4]  R1935     0.300994336605072
    z[2,4,4]  R1936     2.9803445935249329e-01
    z[2,4,4]  R1937     0.651832640171051
    z[2,4,4]  R1938     4.7439518570899963e-01
    z[2,4,4]  R1939     1.4170329086482525e-02
    z[2,4,4]  R1940     2.2644495964050293e-01
    z[2,4,4]  R1941     -1.3397192955017090e-01
    z[2,4,4]  R1942     1.1349140852689743e-01
    z[2,4,4]  R1943     -1.2802682816982269e-01
    z[2,4,4]  R1944     -2.5850141048431396e-01
    z[2,4,4]  R1945     -0.37811079621315
    z[2,4,4]  R1946     -5.9527806937694550e-02
    z[2,4,4]  R1947     -4.2494454979896545e-01
    z[2,4,4]  R1948     1.4411987364292145e-01
    z[2,4,4]  R1949     -5.6752490997314453e-01
    z[2,4,4]  R1950     0.381523460149765
    z[2,4,4]  R1951     5.0421410799026489e-01
    z[2,4,4]  R1952     4.7919169068336487e-01
    z[2,4,4]  R1953     4.1130978614091873e-02
    z[2,4,4]  R1954     -8.1844948232173920e-02
    z[2,4,4]  R1955     -1.9448215141892433e-02
    z[2,4,4]  R1956     3.3866535872220993e-02
    z[2,4,4]  R1957     6.8474814295768738e-02
    z[2,4,4]  R1958     5.6055169552564621e-02
    z[2,4,4]  R1959     -8.0082856118679047e-02
    z[2,4,4]  R1960     -8.5795380175113678e-02
    z[2,4,4]  R1961     -2.0354405045509338e-01
    z[2,4,4]  R1962     -2.2154681384563446e-01
    z[2,4,4]  R1963     -2.5517880916595459e-01
    z[2,4,4]  R1964     5.2798591786995530e-04
    z[2,4,4]  R1965     -1.6653573513031006e-01
    z[2,4,4]  R1966     -0.0630049929022789
    z[2,4,4]  R1967     5.7364720851182938e-03
    z[2,4,4]  R1968     1.0685495287179947e-01
    z[2,4,4]  R1969     -1.5308807790279388e-01
    z[2,4,4]  R1970     -1.3211238384246826e-01
    z[2,4,4]  R1971     6.2557297945022583e-01
    z[2,4,4]  R1972     -0.349031537771225
    z[2,4,4]  R1973     3.6674781586043537e-04
    z[2,4,4]  R1974     9.4423428177833557e-02
    z[2,4,4]  R1975     -1.2037818878889084e-01
    z[2,4,4]  R1976     -1.4261111617088318e-01
    z[2,4,4]  R1977     -7.8513838350772858e-02
    z[2,4,4]  R1978     1.2679681181907654e-01
    z[2,4,4]  R1979     7.3971919715404510e-02
    z[2,4,4]  R1980     -1.2156744301319122e-01
    z[2,4,4]  R1981     -4.2790338397026062e-02
    z[2,4,4]  R1982     6.2806212902069092e-01
    z[2,4,4]  R1983     1.0061531327664852e-02
    z[2,4,4]  R1984     1.9800265133380890e-01
    z[2,4,4]  R1985     1.0502353310585022e-01
    z[2,4,5]  R25       -1
    z[2,4,5]  R43       1
    z[2,4,5]  R1922     -1
    z[2,4,5]  R1923     1
    z[2,4,5]  R1926     -8.9536219835281372e-02
    z[2,4,5]  R1927     -4.3601948022842407e-01
    z[2,4,5]  R1928     -4.3901872634887695e-01
    z[2,4,5]  R1929     -1.8987026810646057e-01
    z[2,4,5]  R1930     -1.1239253729581833e-01
    z[2,4,5]  R1931     1.7196870176121593e-03
    z[2,4,5]  R1932     -6.0424745082855225e-01
    z[2,4,5]  R1933     2.7948565781116486e-02
    z[2,4,5]  R1934     -5.8154165744781494e-01
    z[2,4,5]  R1935     -3.6647930741310120e-01
    z[2,4,5]  R1936     -0.28862264752388
    z[2,4,5]  R1937     2.3364624939858913e-04
    z[2,4,5]  R1938     -0.0412154383957386
    z[2,4,5]  R1939     2.4114564061164856e-02
    z[2,4,5]  R1940     -2.6987118646502495e-02
    z[2,4,5]  R1941     1.8430331349372864e-01
    z[2,4,5]  R1942     2.1725286543369293e-01
    z[2,4,5]  R1943     1.8040643632411957e-01
    z[2,4,5]  R1944     -2.1415190398693085e-01
    z[2,4,5]  R1945     -2.1765044331550598e-01
    z[2,4,5]  R1946     -2.1922864019870758e-01
    z[2,4,5]  R1947     -1.3864994049072266e-02
    z[2,4,5]  R1948     9.8382443189620972e-02
    z[2,4,5]  R1949     -3.9890626072883606e-01
    z[2,4,5]  R1950     2.2245287895202637e-01
    z[2,4,5]  R1951     -1.1194667965173721e-01
    z[2,4,5]  R1952     -0.370022714138031
    z[2,4,5]  R1953     0.0323251374065876
    z[2,4,5]  R1954     2.7211108803749084e-01
    z[2,4,5]  R1955     -3.1022295355796814e-01
    z[2,4,5]  R1956     3.7785702943801880e-01
    z[2,4,5]  R1957     1.9872845709323883e-01
    z[2,4,5]  R1958     2.5526142120361328e-01
    z[2,4,5]  R1959     2.6845550537109375e-01
    z[2,4,5]  R1960     1.2860564887523651e-01
    z[2,4,5]  R1961     2.4986462295055389e-01
    z[2,4,5]  R1962     -3.5493888426572084e-03
    z[2,4,5]  R1963     2.2794951498508453e-01
    z[2,4,5]  R1964     0.0433090478181839
    z[2,4,5]  R1965     2.3948150873184204e-01
    z[2,4,5]  R1966     5.0294625759124756e-01
    z[2,4,5]  R1967     -7.3644906282424927e-02
    z[2,4,5]  R1968     4.1580373048782349e-01
    z[2,4,5]  R1969     -7.5626122951507568e-01
    z[2,4,5]  R1970     -1.0397802293300629e-01
    z[2,4,5]  R1971     5.0789028406143188e-01
    z[2,4,5]  R1972     -5.9557819366455078e-01
    z[2,4,5]  R1973     2.0194037258625031e-01
    z[2,4,5]  R1974     -7.8010231256484985e-01
    z[2,4,5]  R1975     -1.3690859079360962e-01
    z[2,4,5]  R1976     1.3491770625114441e-01
    z[2,4,5]  R1977     -1.1217781901359558e-01
    z[2,4,5]  R1978     -3.0806851387023926e-01
    z[2,4,5]  R1979     5.2376675605773926e-01
    z[2,4,5]  R1980     -8.8750118017196655e-01
    z[2,4,5]  R1981     -0.826915442943573
    z[2,4,5]  R1982     6.7276149988174438e-01
    z[2,4,5]  R1983     2.2474014759063721e-01
    z[2,4,5]  R1984     3.0902171134948730e-01
    z[2,4,5]  R1985     1.7537845671176910e-01
    z[2,4,6]  R26       -1
    z[2,4,6]  R44       1
    z[2,4,6]  R1924     -1
    z[2,4,6]  R1925     1
    z[2,4,6]  R1926     1.3442881405353546e-01
    z[2,4,6]  R1927     -1.6207480430603027e-01
    z[2,4,6]  R1928     3.9075037837028503e-01
    z[2,4,6]  R1929     -1.9765419885516167e-02
    z[2,4,6]  R1930     3.6183750629425049e-01
    z[2,4,6]  R1931     0.00778647605329752
    z[2,4,6]  R1932     -0.0814017578959465
    z[2,4,6]  R1933     2.0233786106109619e-01
    z[2,4,6]  R1934     1.5658171474933624e-01
    z[2,4,6]  R1935     -1.3966041803359985e-01
    z[2,4,6]  R1936     -4.1171273589134216e-01
    z[2,4,6]  R1937     7.1930252015590668e-03
    z[2,4,6]  R1938     6.5253138542175293e-02
    z[2,4,6]  R1939     -0.582328200340271
    z[2,4,6]  R1940     6.0079389810562134e-01
    z[2,4,6]  R1941     1.4935743808746338e-01
    z[2,4,6]  R1942     -1.9328398630023003e-02
    z[2,4,6]  R1943     -0.235909104347229
    z[2,4,6]  R1944     0.462148517370224
    z[2,4,6]  R1945     3.3447670936584473e-01
    z[2,4,6]  R1946     -3.8992151618003845e-01
    z[2,4,6]  R1947     8.6179308593273163e-02
    z[2,4,6]  R1948     0.301705539226532
    z[2,4,6]  R1949     0.00955789815634489
    z[2,4,6]  R1950     -1.8492631614208221e-01
    z[2,4,6]  R1951     -3.4744119644165039e-01
    z[2,4,6]  R1952     -3.4499862790107727e-01
    z[2,4,6]  R1953     4.4494986534118652e-01
    z[2,4,6]  R1954     -0.299773633480072
    z[2,4,6]  R1955     -7.2330847382545471e-02
    z[2,4,6]  R1956     4.8853579163551331e-01
    z[2,4,6]  R1957     -1.9156420603394508e-02
    z[2,4,6]  R1958     -0.0973849669098854
    z[2,4,6]  R1959     -4.6267926692962646e-02
    z[2,4,6]  R1960     1.5173251926898956e-01
    z[2,4,6]  R1961     -0.065963514149189
    z[2,4,6]  R1962     -0.0146268829703331
    z[2,4,6]  R1963     4.1553181409835815e-01
    z[2,4,6]  R1964     4.4460281729698181e-01
    z[2,4,6]  R1965     -0.0810999944806099
    z[2,4,6]  R1966     0.0471709668636322
    z[2,4,6]  R1967     3.6713933944702148e-01
    z[2,4,6]  R1968     5.4234504699707031e-01
    z[2,4,6]  R1969     -5.2987277507781982e-01
    z[2,4,6]  R1970     0.671161413192749
    z[2,4,6]  R1971     3.8942303508520126e-02
    z[2,4,6]  R1972     0.429162859916687
    z[2,4,6]  R1973     -3.7207847833633423e-01
    z[2,4,6]  R1974     -1.8802908062934875e-01
    z[2,4,6]  R1975     1.5293040312826633e-02
    z[2,4,6]  R1976     6.8283146619796753e-01
    z[2,4,6]  R1977     4.6395670622587204e-02
    z[2,4,6]  R1978     -5.4667526483535767e-01
    z[2,4,6]  R1979     -0.588240921497345
    z[2,4,6]  R1980     -1.2923638522624969e-01
    z[2,4,6]  R1981     -7.4335299432277679e-03
    z[2,4,6]  R1982     -2.7590328827500343e-02
    z[2,4,6]  R1983     3.6730885505676270e-02
    z[2,4,6]  R1984     -2.9367044568061829e-01
    z[2,4,6]  R1985     2.2171714901924133e-01
    z[4,2,0]  R20       1
    z[4,2,0]  R38       -1
    z[4,2,0]  R1986     -1
    z[4,2,0]  R1987     1
    z[4,2,0]  R2000     7.2173547744750977e-01
    z[4,2,0]  R2001     -2.6034882664680481e-01
    z[4,2,0]  R2002     -8.8026374578475952e-02
    z[4,2,0]  R2003     7.0207589864730835e-01
    z[4,2,0]  R2004     1.3437853753566742e-01
    z[4,2,0]  R2005     6.1883461475372314e-01
    z[4,2,0]  R2006     5.5191999673843384e-01
    z[4,2,0]  R2007     5.7589358091354370e-01
    z[4,2,0]  R2008     1.9529409706592560e-01
    z[4,2,0]  R2009     8.8348609209060669e-01
    z[4,2,0]  R2010     0.498344749212265
    z[4,2,0]  R2011     -5.7064223289489746e-01
    z[4,2,0]  R2012     -3.8162621855735779e-01
    z[4,2,0]  R2013     -5.8480417728424072e-01
    z[4,2,0]  R2014     -4.7194001078605652e-01
    z[4,2,0]  R2015     -4.4435703754425049e-01
    z[4,2,0]  R2016     -4.1637751460075378e-01
    z[4,2,0]  R2017     -4.7644710540771484e-01
    z[4,2,0]  R2018     -6.2589657306671143e-01
    z[4,2,0]  R2019     -3.0824321508407593e-01
    z[4,2,0]  R2020     6.4118367433547974e-01
    z[4,2,0]  R2021     5.4827427864074707e-01
    z[4,2,0]  R2022     3.2010135054588318e-01
    z[4,2,0]  R2023     1.3908789493143559e-02
    z[4,2,0]  R2024     3.6178115010261536e-01
    z[4,2,0]  R2025     3.5426384210586548e-01
    z[4,2,0]  R2026     3.4391263127326965e-01
    z[4,2,0]  R2027     -3.3993339538574219e-01
    z[4,2,0]  R2028     -0.0794341191649437
    z[4,2,0]  R2029     -1.8189454078674316e-01
    z[4,2,0]  R2030     6.8536871671676636e-01
    z[4,2,0]  R2031     6.1935573816299438e-01
    z[4,2,0]  R2032     -4.0746080875396729e-01
    z[4,2,0]  R2033     4.1207635402679443e-01
    z[4,2,0]  R2034     -3.0557766556739807e-02
    z[4,2,0]  R2035     1.9815362989902496e-01
    z[4,2,0]  R2036     -1.0177161544561386e-01
    z[4,2,0]  R2037     -3.2355093955993652e-01
    z[4,2,0]  R2038     -3.2967633008956909e-01
    z[4,2,0]  R2039     -5.7720702886581421e-01
    z[4,2,0]  R2040     7.4829590320587158e-01
    z[4,2,0]  R2041     5.1608401536941528e-01
    z[4,2,0]  R2042     0.537086009979248
    z[4,2,0]  R2043     4.9732410907745361e-01
    z[4,2,0]  R2044     4.7364082932472229e-01
    z[4,2,0]  R2045     -7.3809754848480225e-01
    z[4,2,0]  R2046     -2.6245564222335815e-01
    z[4,2,0]  R2047     -3.8120758533477783e-01
    z[4,2,0]  R2048     1.0940525680780411e-01
    z[4,2,0]  R2049     -3.2202787697315216e-03
    z[4,2,0]  R2050     1.4168143272399902e-01
    z[4,2,0]  R2051     -4.6991547942161560e-01
    z[4,2,0]  R2052     -2.5674232840538025e-01
    z[4,2,0]  R2053     3.3428356051445007e-01
    z[4,2,0]  R2054     0.565673291683197
    z[4,2,0]  R2055     -1.8310900032520294e-01
    z[4,2,0]  R2056     -2.4000744521617889e-01
    z[4,2,0]  R2057     -3.2580006122589111e-01
    z[4,2,0]  R2058     0.0563129186630249
    z[4,2,0]  R2059     -2.3766435682773590e-01
    z[4,2,1]  R21       1
    z[4,2,1]  R39       -1
    z[4,2,1]  R1988     -1
    z[4,2,1]  R1989     1
    z[4,2,1]  R2000     4.7464835643768311e-01
    z[4,2,1]  R2001     -3.7263244390487671e-01
    z[4,2,1]  R2002     -5.8896821737289429e-01
    z[4,2,1]  R2003     5.5480856448411942e-02
    z[4,2,1]  R2004     -0.356360524892807
    z[4,2,1]  R2005     -2.9439383745193481e-01
    z[4,2,1]  R2006     -3.9077866077423096e-01
    z[4,2,1]  R2007     4.5883551239967346e-01
    z[4,2,1]  R2008     -2.5890287756919861e-01
    z[4,2,1]  R2009     1.8817149102687836e-01
    z[4,2,1]  R2010     -3.1648527830839157e-02
    z[4,2,1]  R2011     4.7781169414520264e-01
    z[4,2,1]  R2012     4.4560694694519043e-01
    z[4,2,1]  R2013     5.7730001211166382e-01
    z[4,2,1]  R2014     3.6223095655441284e-01
    z[4,2,1]  R2015     4.5222055912017822e-01
    z[4,2,1]  R2016     5.4885065555572510e-01
    z[4,2,1]  R2017     5.3115218877792358e-01
    z[4,2,1]  R2018     5.1203662157058716e-01
    z[4,2,1]  R2019     -3.8567224144935608e-01
    z[4,2,1]  R2020     -4.6898555010557175e-02
    z[4,2,1]  R2021     1.9691698253154755e-01
    z[4,2,1]  R2022     -3.3078789710998535e-01
    z[4,2,1]  R2023     -2.5322714447975159e-01
    z[4,2,1]  R2024     -0.521737277507782
    z[4,2,1]  R2025     2.8693714737892151e-01
    z[4,2,1]  R2026     -4.4296371936798096e-01
    z[4,2,1]  R2027     -6.5261906385421753e-01
    z[4,2,1]  R2028     5.0646450370550156e-02
    z[4,2,1]  R2029     -8.7560421228408813e-01
    z[4,2,1]  R2030     8.7547548115253448e-02
    z[4,2,1]  R2031     -5.1780784130096436e-01
    z[4,2,1]  R2032     -5.1614469289779663e-01
    z[4,2,1]  R2033     -1.3408043980598450e-01
    z[4,2,1]  R2034     -1.9141638278961182e-01
    z[4,2,1]  R2035     5.2375458180904388e-02
    z[4,2,1]  R2036     1.0893474519252777e-01
    z[4,2,1]  R2037     -1.1364394426345825e-01
    z[4,2,1]  R2038     -2.2669158875942230e-01
    z[4,2,1]  R2039     -0.592122495174408
    z[4,2,1]  R2040     -3.2144561409950256e-01
    z[4,2,1]  R2041     -2.0471605658531189e-01
    z[4,2,1]  R2042     -3.1970420479774475e-01
    z[4,2,1]  R2043     -1.8541653454303741e-01
    z[4,2,1]  R2044     1.3635165989398956e-01
    z[4,2,1]  R2045     -1.0374334640800953e-02
    z[4,2,1]  R2046     -2.3291751742362976e-01
    z[4,2,1]  R2047     3.8018960505723953e-02
    z[4,2,1]  R2048     6.7745143175125122e-01
    z[4,2,1]  R2049     0.726978063583374
    z[4,2,1]  R2050     3.9020961523056030e-01
    z[4,2,1]  R2051     -2.1759761869907379e-01
    z[4,2,1]  R2052     -3.1393334269523621e-01
    z[4,2,1]  R2053     5.5078876018524170e-01
    z[4,2,1]  R2054     0.0785161480307579
    z[4,2,1]  R2055     -8.9253157377243042e-02
    z[4,2,1]  R2056     -2.2639174759387970e-01
    z[4,2,1]  R2057     -4.4696471095085144e-01
    z[4,2,1]  R2058     8.1399637460708618e-01
    z[4,2,1]  R2059     7.4620097875595093e-01
    z[4,2,2]  R22       1
    z[4,2,2]  R40       -1
    z[4,2,2]  R1990     -1
    z[4,2,2]  R1991     1
    z[4,2,2]  R2000     2.0658016204833984e-01
    z[4,2,2]  R2001     5.1609843969345093e-01
    z[4,2,2]  R2002     6.4757645130157471e-01
    z[4,2,2]  R2003     9.8929800093173981e-02
    z[4,2,2]  R2004     5.5037707090377808e-01
    z[4,2,2]  R2005     1.7464052140712738e-01
    z[4,2,2]  R2006     -2.3853220045566559e-01
    z[4,2,2]  R2007     5.0685471296310425e-01
    z[4,2,2]  R2008     2.4018318951129913e-01
    z[4,2,2]  R2009     9.5787599682807922e-02
    z[4,2,2]  R2010     -5.3479593992233276e-01
    z[4,2,2]  R2011     -5.9657585620880127e-01
    z[4,2,2]  R2012     -7.1719348430633545e-01
    z[4,2,2]  R2013     -4.3153610825538635e-01
    z[4,2,2]  R2014     -6.7312496900558472e-01
    z[4,2,2]  R2015     -6.3912689685821533e-01
    z[4,2,2]  R2016     -6.0853153467178345e-01
    z[4,2,2]  R2017     -4.1915518045425415e-01
    z[4,2,2]  R2018     -3.3209469914436340e-01
    z[4,2,2]  R2019     -8.0496203899383545e-01
    z[4,2,2]  R2020     -4.6399781107902527e-01
    z[4,2,2]  R2021     -5.1879197359085083e-01
    z[4,2,2]  R2022     -4.1803181171417236e-01
    z[4,2,2]  R2023     1.7579983174800873e-01
    z[4,2,2]  R2024     -2.2754608094692230e-01
    z[4,2,2]  R2025     -2.3996305465698242e-01
    z[4,2,2]  R2026     1.5741537511348724e-01
    z[4,2,2]  R2027     -4.3415728211402893e-01
    z[4,2,2]  R2028     0.576196551322937
    z[4,2,2]  R2029     -4.0394324064254761e-01
    z[4,2,2]  R2030     -0.0334198921918869
    z[4,2,2]  R2031     1.4081464707851410e-01
    z[4,2,2]  R2032     1.9569399952888489e-01
    z[4,2,2]  R2033     1.2754398584365845e-01
    z[4,2,2]  R2034     3.7761977314949036e-01
    z[4,2,2]  R2035     0.517429530620575
    z[4,2,2]  R2036     7.9806648194789886e-02
    z[4,2,2]  R2037     -7.7853941917419434e-01
    z[4,2,2]  R2038     -7.5481927394866943e-01
    z[4,2,2]  R2039     -3.2312935590744019e-01
    z[4,2,2]  R2040     -0.515376091003418
    z[4,2,2]  R2041     4.1804668307304382e-01
    z[4,2,2]  R2042     1.2986409664154053e-01
    z[4,2,2]  R2043     4.5868310332298279e-01
    z[4,2,2]  R2044     3.5329717397689819e-01
    z[4,2,2]  R2045     2.0457613468170166e-01
    z[4,2,2]  R2046     -1.2198117375373840e-01
    z[4,2,2]  R2047     -0.887882649898529
    z[4,2,2]  R2048     -3.7543609738349915e-01
    z[4,2,2]  R2049     -4.6628442406654358e-01
    z[4,2,2]  R2050     1.2427022308111191e-01
    z[4,2,2]  R2051     -2.0072016119956970e-01
    z[4,2,2]  R2052     3.8638854026794434e-01
    z[4,2,2]  R2053     -0.310772567987442
    z[4,2,2]  R2054     2.9522114992141724e-01
    z[4,2,2]  R2055     -8.5445863008499146e-01
    z[4,2,2]  R2056     -9.0961974859237671e-01
    z[4,2,2]  R2057     -6.8891471624374390e-01
    z[4,2,2]  R2058     -8.8315911591053009e-02
    z[4,2,2]  R2059     -2.7855682373046875e-01
    z[4,2,3]  R23       1
    z[4,2,3]  R41       -1
    z[4,2,3]  R1992     -1
    z[4,2,3]  R1993     1
    z[4,2,3]  R2000     8.6531199514865875e-02
    z[4,2,3]  R2001     -5.8207309246063232e-01
    z[4,2,3]  R2002     -3.2332116365432739e-01
    z[4,2,3]  R2003     -1.1367462575435638e-01
    z[4,2,3]  R2004     -5.6814730167388916e-01
    z[4,2,3]  R2005     -3.3525720238685608e-01
    z[4,2,3]  R2006     -1.4600183814764023e-02
    z[4,2,3]  R2007     1.4067446812987328e-02
    z[4,2,3]  R2008     -8.1641548871994019e-01
    z[4,2,3]  R2009     -2.7022278308868408e-01
    z[4,2,3]  R2010     2.8645089268684387e-01
    z[4,2,3]  R2011     2.1356928348541260e-01
    z[4,2,3]  R2012     2.5227975845336914e-01
    z[4,2,3]  R2013     2.4058888852596283e-01
    z[4,2,3]  R2014     3.8215324282646179e-01
    z[4,2,3]  R2015     2.8521296381950378e-01
    z[4,2,3]  R2016     3.2522711157798767e-01
    z[4,2,3]  R2017     1.5950119495391846e-01
    z[4,2,3]  R2018     1.9036103785037994e-01
    z[4,2,3]  R2019     1.2890487909317017e-01
    z[4,2,3]  R2020     -3.3502274751663208e-01
    z[4,2,3]  R2021     5.0122457742691040e-01
    z[4,2,3]  R2022     3.6730784177780151e-01
    z[4,2,3]  R2023     -1.6924814879894257e-01
    z[4,2,3]  R2024     0.257690966129303
    z[4,2,3]  R2025     2.8943282365798950e-01
    z[4,2,3]  R2026     3.2569810282438993e-03
    z[4,2,3]  R2027     -3.0136129260063171e-01
    z[4,2,3]  R2028     7.9324334859848022e-02
    z[4,2,3]  R2029     -5.9938136488199234e-02
    z[4,2,3]  R2030     1.2918472290039062e-01
    z[4,2,3]  R2031     -5.5456644296646118e-01
    z[4,2,3]  R2032     -3.4559625387191772e-01
    z[4,2,3]  R2033     4.1245266795158386e-01
    z[4,2,3]  R2034     2.6273833587765694e-02
    z[4,2,3]  R2035     0.0676998421549797
    z[4,2,3]  R2036     3.5153287649154663e-01
    z[4,2,3]  R2037     4.7362190485000610e-01
    z[4,2,3]  R2038     2.2187928855419159e-01
    z[4,2,3]  R2039     3.4765559434890747e-01
    z[4,2,3]  R2040     1.5286819636821747e-01
    z[4,2,3]  R2041     -5.1591819524765015e-01
    z[4,2,3]  R2042     -4.9240902066230774e-01
    z[4,2,3]  R2043     -1.6610951721668243e-01
    z[4,2,3]  R2044     -3.2557976245880127e-01
    z[4,2,3]  R2045     -6.2602853775024414e-01
    z[4,2,3]  R2046     -0.666356086730957
    z[4,2,3]  R2047     1.1362785845994949e-01
    z[4,2,3]  R2048     1.0532516241073608e-01
    z[4,2,3]  R2049     0.0982937142252922
    z[4,2,3]  R2050     6.8599176406860352e-01
    z[4,2,3]  R2051     5.1633769273757935e-01
    z[4,2,3]  R2052     6.7470401525497437e-01
    z[4,2,3]  R2053     -3.8525089621543884e-01
    z[4,2,3]  R2054     4.1681462526321411e-01
    z[4,2,3]  R2055     3.9265963435173035e-01
    z[4,2,3]  R2056     5.7291448116302490e-02
    z[4,2,3]  R2057     3.3894369006156921e-01
    z[4,2,3]  R2058     -1.3183162547647953e-02
    z[4,2,3]  R2059     8.3016470074653625e-02
    z[4,2,4]  R24       1
    z[4,2,4]  R42       -1
    z[4,2,4]  R1994     -1
    z[4,2,4]  R1995     1
    z[4,2,4]  R2000     -5.9527806937694550e-02
    z[4,2,4]  R2001     -4.2494454979896545e-01
    z[4,2,4]  R2002     1.4411987364292145e-01
    z[4,2,4]  R2003     -5.6752490997314453e-01
    z[4,2,4]  R2004     0.381523460149765
    z[4,2,4]  R2005     5.0421410799026489e-01
    z[4,2,4]  R2006     4.7919169068336487e-01
    z[4,2,4]  R2007     4.1130978614091873e-02
    z[4,2,4]  R2008     -8.1844948232173920e-02
    z[4,2,4]  R2009     -1.9448215141892433e-02
    z[4,2,4]  R2010     3.3866535872220993e-02
    z[4,2,4]  R2011     6.8474814295768738e-02
    z[4,2,4]  R2012     5.6055169552564621e-02
    z[4,2,4]  R2013     -8.0082856118679047e-02
    z[4,2,4]  R2014     -8.5795380175113678e-02
    z[4,2,4]  R2015     -2.0354405045509338e-01
    z[4,2,4]  R2016     -2.2154681384563446e-01
    z[4,2,4]  R2017     -2.5517880916595459e-01
    z[4,2,4]  R2018     5.2798591786995530e-04
    z[4,2,4]  R2019     -1.6653573513031006e-01
    z[4,2,4]  R2020     -0.0630049929022789
    z[4,2,4]  R2021     5.7364720851182938e-03
    z[4,2,4]  R2022     1.0685495287179947e-01
    z[4,2,4]  R2023     -1.5308807790279388e-01
    z[4,2,4]  R2024     -1.3211238384246826e-01
    z[4,2,4]  R2025     6.2557297945022583e-01
    z[4,2,4]  R2026     -0.349031537771225
    z[4,2,4]  R2027     3.6674781586043537e-04
    z[4,2,4]  R2028     9.4423428177833557e-02
    z[4,2,4]  R2029     -1.2037818878889084e-01
    z[4,2,4]  R2030     -1.4261111617088318e-01
    z[4,2,4]  R2031     -7.8513838350772858e-02
    z[4,2,4]  R2032     1.2679681181907654e-01
    z[4,2,4]  R2033     7.3971919715404510e-02
    z[4,2,4]  R2034     -1.2156744301319122e-01
    z[4,2,4]  R2035     -4.2790338397026062e-02
    z[4,2,4]  R2036     6.2806212902069092e-01
    z[4,2,4]  R2037     1.0061531327664852e-02
    z[4,2,4]  R2038     1.9800265133380890e-01
    z[4,2,4]  R2039     1.0502353310585022e-01
    z[4,2,4]  R2040     1.4716325700283051e-01
    z[4,2,4]  R2041     1.8556064367294312e-01
    z[4,2,4]  R2042     -6.7625559866428375e-02
    z[4,2,4]  R2043     -6.6623234748840332e-01
    z[4,2,4]  R2044     6.1862188577651978e-01
    z[4,2,4]  R2045     1.4586891233921051e-01
    z[4,2,4]  R2046     -2.1497756242752075e-01
    z[4,2,4]  R2047     -1.0132491588592529e-01
    z[4,2,4]  R2048     1.1973230540752411e-01
    z[4,2,4]  R2049     0.300994336605072
    z[4,2,4]  R2050     2.9803445935249329e-01
    z[4,2,4]  R2051     0.651832640171051
    z[4,2,4]  R2052     4.7439518570899963e-01
    z[4,2,4]  R2053     1.4170329086482525e-02
    z[4,2,4]  R2054     2.2644495964050293e-01
    z[4,2,4]  R2055     -1.3397192955017090e-01
    z[4,2,4]  R2056     1.1349140852689743e-01
    z[4,2,4]  R2057     -1.2802682816982269e-01
    z[4,2,4]  R2058     -2.5850141048431396e-01
    z[4,2,4]  R2059     -0.37811079621315
    z[4,2,5]  R25       1
    z[4,2,5]  R43       -1
    z[4,2,5]  R1996     -1
    z[4,2,5]  R1997     1
    z[4,2,5]  R2000     -2.1922864019870758e-01
    z[4,2,5]  R2001     -1.3864994049072266e-02
    z[4,2,5]  R2002     9.8382443189620972e-02
    z[4,2,5]  R2003     -3.9890626072883606e-01
    z[4,2,5]  R2004     2.2245287895202637e-01
    z[4,2,5]  R2005     -1.1194667965173721e-01
    z[4,2,5]  R2006     -0.370022714138031
    z[4,2,5]  R2007     0.0323251374065876
    z[4,2,5]  R2008     2.7211108803749084e-01
    z[4,2,5]  R2009     -3.1022295355796814e-01
    z[4,2,5]  R2010     3.7785702943801880e-01
    z[4,2,5]  R2011     1.9872845709323883e-01
    z[4,2,5]  R2012     2.5526142120361328e-01
    z[4,2,5]  R2013     2.6845550537109375e-01
    z[4,2,5]  R2014     1.2860564887523651e-01
    z[4,2,5]  R2015     2.4986462295055389e-01
    z[4,2,5]  R2016     -3.5493888426572084e-03
    z[4,2,5]  R2017     2.2794951498508453e-01
    z[4,2,5]  R2018     0.0433090478181839
    z[4,2,5]  R2019     2.3948150873184204e-01
    z[4,2,5]  R2020     5.0294625759124756e-01
    z[4,2,5]  R2021     -7.3644906282424927e-02
    z[4,2,5]  R2022     4.1580373048782349e-01
    z[4,2,5]  R2023     -7.5626122951507568e-01
    z[4,2,5]  R2024     -1.0397802293300629e-01
    z[4,2,5]  R2025     5.0789028406143188e-01
    z[4,2,5]  R2026     -5.9557819366455078e-01
    z[4,2,5]  R2027     2.0194037258625031e-01
    z[4,2,5]  R2028     -7.8010231256484985e-01
    z[4,2,5]  R2029     -1.3690859079360962e-01
    z[4,2,5]  R2030     1.3491770625114441e-01
    z[4,2,5]  R2031     -1.1217781901359558e-01
    z[4,2,5]  R2032     -3.0806851387023926e-01
    z[4,2,5]  R2033     5.2376675605773926e-01
    z[4,2,5]  R2034     -8.8750118017196655e-01
    z[4,2,5]  R2035     -0.826915442943573
    z[4,2,5]  R2036     6.7276149988174438e-01
    z[4,2,5]  R2037     2.2474014759063721e-01
    z[4,2,5]  R2038     3.0902171134948730e-01
    z[4,2,5]  R2039     1.7537845671176910e-01
    z[4,2,5]  R2040     -8.9536219835281372e-02
    z[4,2,5]  R2041     -4.3601948022842407e-01
    z[4,2,5]  R2042     -4.3901872634887695e-01
    z[4,2,5]  R2043     -1.8987026810646057e-01
    z[4,2,5]  R2044     -1.1239253729581833e-01
    z[4,2,5]  R2045     1.7196870176121593e-03
    z[4,2,5]  R2046     -6.0424745082855225e-01
    z[4,2,5]  R2047     2.7948565781116486e-02
    z[4,2,5]  R2048     -5.8154165744781494e-01
    z[4,2,5]  R2049     -3.6647930741310120e-01
    z[4,2,5]  R2050     -0.28862264752388
    z[4,2,5]  R2051     2.3364624939858913e-04
    z[4,2,5]  R2052     -0.0412154383957386
    z[4,2,5]  R2053     2.4114564061164856e-02
    z[4,2,5]  R2054     -2.6987118646502495e-02
    z[4,2,5]  R2055     1.8430331349372864e-01
    z[4,2,5]  R2056     2.1725286543369293e-01
    z[4,2,5]  R2057     1.8040643632411957e-01
    z[4,2,5]  R2058     -2.1415190398693085e-01
    z[4,2,5]  R2059     -2.1765044331550598e-01
    z[4,2,6]  R26       1
    z[4,2,6]  R44       -1
    z[4,2,6]  R1998     -1
    z[4,2,6]  R1999     1
    z[4,2,6]  R2000     -3.8992151618003845e-01
    z[4,2,6]  R2001     8.6179308593273163e-02
    z[4,2,6]  R2002     0.301705539226532
    z[4,2,6]  R2003     0.00955789815634489
    z[4,2,6]  R2004     -1.8492631614208221e-01
    z[4,2,6]  R2005     -3.4744119644165039e-01
    z[4,2,6]  R2006     -3.4499862790107727e-01
    z[4,2,6]  R2007     4.4494986534118652e-01
    z[4,2,6]  R2008     -0.299773633480072
    z[4,2,6]  R2009     -7.2330847382545471e-02
    z[4,2,6]  R2010     4.8853579163551331e-01
    z[4,2,6]  R2011     -1.9156420603394508e-02
    z[4,2,6]  R2012     -0.0973849669098854
    z[4,2,6]  R2013     -4.6267926692962646e-02
    z[4,2,6]  R2014     1.5173251926898956e-01
    z[4,2,6]  R2015     -0.065963514149189
    z[4,2,6]  R2016     -0.0146268829703331
    z[4,2,6]  R2017     4.1553181409835815e-01
    z[4,2,6]  R2018     4.4460281729698181e-01
    z[4,2,6]  R2019     -0.0810999944806099
    z[4,2,6]  R2020     0.0471709668636322
    z[4,2,6]  R2021     3.6713933944702148e-01
    z[4,2,6]  R2022     5.4234504699707031e-01
    z[4,2,6]  R2023     -5.2987277507781982e-01
    z[4,2,6]  R2024     0.671161413192749
    z[4,2,6]  R2025     3.8942303508520126e-02
    z[4,2,6]  R2026     0.429162859916687
    z[4,2,6]  R2027     -3.7207847833633423e-01
    z[4,2,6]  R2028     -1.8802908062934875e-01
    z[4,2,6]  R2029     1.5293040312826633e-02
    z[4,2,6]  R2030     6.8283146619796753e-01
    z[4,2,6]  R2031     4.6395670622587204e-02
    z[4,2,6]  R2032     -5.4667526483535767e-01
    z[4,2,6]  R2033     -0.588240921497345
    z[4,2,6]  R2034     -1.2923638522624969e-01
    z[4,2,6]  R2035     -7.4335299432277679e-03
    z[4,2,6]  R2036     -2.7590328827500343e-02
    z[4,2,6]  R2037     3.6730885505676270e-02
    z[4,2,6]  R2038     -2.9367044568061829e-01
    z[4,2,6]  R2039     2.2171714901924133e-01
    z[4,2,6]  R2040     1.3442881405353546e-01
    z[4,2,6]  R2041     -1.6207480430603027e-01
    z[4,2,6]  R2042     3.9075037837028503e-01
    z[4,2,6]  R2043     -1.9765419885516167e-02
    z[4,2,6]  R2044     3.6183750629425049e-01
    z[4,2,6]  R2045     0.00778647605329752
    z[4,2,6]  R2046     -0.0814017578959465
    z[4,2,6]  R2047     2.0233786106109619e-01
    z[4,2,6]  R2048     1.5658171474933624e-01
    z[4,2,6]  R2049     -1.3966041803359985e-01
    z[4,2,6]  R2050     -4.1171273589134216e-01
    z[4,2,6]  R2051     7.1930252015590668e-03
    z[4,2,6]  R2052     6.5253138542175293e-02
    z[4,2,6]  R2053     -0.582328200340271
    z[4,2,6]  R2054     6.0079389810562134e-01
    z[4,2,6]  R2055     1.4935743808746338e-01
    z[4,2,6]  R2056     -1.9328398630023003e-02
    z[4,2,6]  R2057     -0.235909104347229
    z[4,2,6]  R2058     0.462148517370224
    z[4,2,6]  R2059     3.3447670936584473e-01
    z[2,5,0]  R20       -1
    z[2,5,0]  R47       1
    z[2,5,0]  R2060     -1
    z[2,5,0]  R2061     1
    z[2,5,0]  R2074     7.4829590320587158e-01
    z[2,5,0]  R2075     5.1608401536941528e-01
    z[2,5,0]  R2076     0.537086009979248
    z[2,5,0]  R2077     4.9732410907745361e-01
    z[2,5,0]  R2078     4.7364082932472229e-01
    z[2,5,0]  R2079     -7.3809754848480225e-01
    z[2,5,0]  R2080     -2.6245564222335815e-01
    z[2,5,0]  R2081     -3.8120758533477783e-01
    z[2,5,0]  R2082     1.0940525680780411e-01
    z[2,5,0]  R2083     -3.2202787697315216e-03
    z[2,5,0]  R2084     1.4168143272399902e-01
    z[2,5,0]  R2085     -4.6991547942161560e-01
    z[2,5,0]  R2086     -2.5674232840538025e-01
    z[2,5,0]  R2087     3.3428356051445007e-01
    z[2,5,0]  R2088     0.565673291683197
    z[2,5,0]  R2089     -1.8310900032520294e-01
    z[2,5,0]  R2090     -2.4000744521617889e-01
    z[2,5,0]  R2091     -3.2580006122589111e-01
    z[2,5,0]  R2092     0.0563129186630249
    z[2,5,0]  R2093     -2.3766435682773590e-01
    z[2,5,0]  R2094     0.465468168258667
    z[2,5,0]  R2095     4.8361030220985413e-01
    z[2,5,0]  R2096     3.9293155074119568e-01
    z[2,5,0]  R2097     4.5623803138732910e-01
    z[2,5,0]  R2098     6.6259825229644775e-01
    z[2,5,0]  R2099     4.4954261183738708e-01
    z[2,5,0]  R2100     -6.7470502853393555e-01
    z[2,5,0]  R2101     -6.7426276206970215e-01
    z[2,5,0]  R2102     -7.7380383014678955e-01
    z[2,5,0]  R2103     5.5530810356140137e-01
    z[2,5,0]  R2104     5.7968068122863770e-01
    z[2,5,0]  R2105     -3.3840614557266235e-01
    z[2,5,0]  R2106     -4.5139434933662415e-01
    z[2,5,0]  R2107     -0.545189619064331
    z[2,5,0]  R2108     -1.6080382466316223e-01
    z[2,5,0]  R2109     -1.4969871938228607e-01
    z[2,5,0]  R2110     -2.0674932003021240e-01
    z[2,5,0]  R2111     -1.6465358436107635e-01
    z[2,5,1]  R21       -1
    z[2,5,1]  R48       1
    z[2,5,1]  R2062     -1
    z[2,5,1]  R2063     1
    z[2,5,1]  R2074     -3.2144561409950256e-01
    z[2,5,1]  R2075     -2.0471605658531189e-01
    z[2,5,1]  R2076     -3.1970420479774475e-01
    z[2,5,1]  R2077     -1.8541653454303741e-01
    z[2,5,1]  R2078     1.3635165989398956e-01
    z[2,5,1]  R2079     -1.0374334640800953e-02
    z[2,5,1]  R2080     -2.3291751742362976e-01
    z[2,5,1]  R2081     3.8018960505723953e-02
    z[2,5,1]  R2082     6.7745143175125122e-01
    z[2,5,1]  R2083     0.726978063583374
    z[2,5,1]  R2084     3.9020961523056030e-01
    z[2,5,1]  R2085     -2.1759761869907379e-01
    z[2,5,1]  R2086     -3.1393334269523621e-01
    z[2,5,1]  R2087     5.5078876018524170e-01
    z[2,5,1]  R2088     0.0785161480307579
    z[2,5,1]  R2089     -8.9253157377243042e-02
    z[2,5,1]  R2090     -2.2639174759387970e-01
    z[2,5,1]  R2091     -4.4696471095085144e-01
    z[2,5,1]  R2092     8.1399637460708618e-01
    z[2,5,1]  R2093     7.4620097875595093e-01
    z[2,5,1]  R2094     -2.6089332997798920e-02
    z[2,5,1]  R2095     -1.7964828014373779e-01
    z[2,5,1]  R2096     -2.0432645082473755e-01
    z[2,5,1]  R2097     -0.0886748731136322
    z[2,5,1]  R2098     -9.4480365514755249e-02
    z[2,5,1]  R2099     8.1957143545150757e-01
    z[2,5,1]  R2100     -1.0136871039867401e-01
    z[2,5,1]  R2101     -1.5375743806362152e-01
    z[2,5,1]  R2102     -1.6285133361816406e-01
    z[2,5,1]  R2103     -2.9200801253318787e-01
    z[2,5,1]  R2104     2.3025064170360565e-01
    z[2,5,1]  R2105     3.2131013274192810e-01
    z[2,5,1]  R2106     5.4254125803709030e-02
    z[2,5,1]  R2107     -0.13618203997612
    z[2,5,1]  R2108     -4.6495974063873291e-01
    z[2,5,1]  R2109     1.3007128611207008e-02
    z[2,5,1]  R2110     2.0443606376647949e-01
    z[2,5,1]  R2111     2.2308218479156494e-01
    z[2,5,2]  R22       -1
    z[2,5,2]  R49       1
    z[2,5,2]  R2064     -1
    z[2,5,2]  R2065     1
    z[2,5,2]  R2074     -0.515376091003418
    z[2,5,2]  R2075     4.1804668307304382e-01
    z[2,5,2]  R2076     1.2986409664154053e-01
    z[2,5,2]  R2077     4.5868310332298279e-01
    z[2,5,2]  R2078     3.5329717397689819e-01
    z[2,5,2]  R2079     2.0457613468170166e-01
    z[2,5,2]  R2080     -1.2198117375373840e-01
    z[2,5,2]  R2081     -0.887882649898529
    z[2,5,2]  R2082     -3.7543609738349915e-01
    z[2,5,2]  R2083     -4.6628442406654358e-01
    z[2,5,2]  R2084     1.2427022308111191e-01
    z[2,5,2]  R2085     -2.0072016119956970e-01
    z[2,5,2]  R2086     3.8638854026794434e-01
    z[2,5,2]  R2087     -0.310772567987442
    z[2,5,2]  R2088     2.9522114992141724e-01
    z[2,5,2]  R2089     -8.5445863008499146e-01
    z[2,5,2]  R2090     -9.0961974859237671e-01
    z[2,5,2]  R2091     -6.8891471624374390e-01
    z[2,5,2]  R2092     -8.8315911591053009e-02
    z[2,5,2]  R2093     -2.7855682373046875e-01
    z[2,5,2]  R2094     2.7867025136947632e-01
    z[2,5,2]  R2095     -1.0877050459384918e-01
    z[2,5,2]  R2096     1.4166106283664703e-01
    z[2,5,2]  R2097     -1.6703473031520844e-01
    z[2,5,2]  R2098     -0.681039571762085
    z[2,5,2]  R2099     -7.1422152221202850e-02
    z[2,5,2]  R2100     -2.3632074892520905e-01
    z[2,5,2]  R2101     1.2734462320804596e-01
    z[2,5,2]  R2102     2.0489895343780518e-01
    z[2,5,2]  R2103     5.6785231828689575e-01
    z[2,5,2]  R2104     1.4935834705829620e-01
    z[2,5,2]  R2105     5.2744146436452866e-02
    z[2,5,2]  R2106     -3.7843767553567886e-02
    z[2,5,2]  R2107     -2.2276104986667633e-01
    z[2,5,2]  R2108     5.8946889638900757e-01
    z[2,5,2]  R2109     3.7942177057266235e-01
    z[2,5,2]  R2110     6.0760462284088135e-01
    z[2,5,2]  R2111     6.2808138132095337e-01
    z[2,5,3]  R23       -1
    z[2,5,3]  R50       1
    z[2,5,3]  R2066     -1
    z[2,5,3]  R2067     1
    z[2,5,3]  R2074     1.5286819636821747e-01
    z[2,5,3]  R2075     -5.1591819524765015e-01
    z[2,5,3]  R2076     -4.9240902066230774e-01
    z[2,5,3]  R2077     -1.6610951721668243e-01
    z[2,5,3]  R2078     -3.2557976245880127e-01
    z[2,5,3]  R2079     -6.2602853775024414e-01
    z[2,5,3]  R2080     -0.666356086730957
    z[2,5,3]  R2081     1.1362785845994949e-01
    z[2,5,3]  R2082     1.0532516241073608e-01
    z[2,5,3]  R2083     0.0982937142252922
    z[2,5,3]  R2084     6.8599176406860352e-01
    z[2,5,3]  R2085     5.1633769273757935e-01
    z[2,5,3]  R2086     6.7470401525497437e-01
    z[2,5,3]  R2087     -3.8525089621543884e-01
    z[2,5,3]  R2088     4.1681462526321411e-01
    z[2,5,3]  R2089     3.9265963435173035e-01
    z[2,5,3]  R2090     5.7291448116302490e-02
    z[2,5,3]  R2091     3.3894369006156921e-01
    z[2,5,3]  R2092     -1.3183162547647953e-02
    z[2,5,3]  R2093     8.3016470074653625e-02
    z[2,5,3]  R2094     -5.6948989629745483e-01
    z[2,5,3]  R2095     -4.2881119251251221e-01
    z[2,5,3]  R2096     -7.5719755887985229e-01
    z[2,5,3]  R2097     0.0762195810675621
    z[2,5,3]  R2098     4.4908598065376282e-02
    z[2,5,3]  R2099     8.4992036223411560e-02
    z[2,5,3]  R2100     -6.5855622291564941e-01
    z[2,5,3]  R2101     -5.6091868877410889e-01
    z[2,5,3]  R2102     -4.3509653210639954e-01
    z[2,5,3]  R2103     0.442421019077301
    z[2,5,3]  R2104     -1.7582742869853973e-01
    z[2,5,3]  R2105     -2.8553646802902222e-01
    z[2,5,3]  R2106     7.1413803100585938e-01
    z[2,5,3]  R2107     6.9978368282318115e-01
    z[2,5,3]  R2108     -9.4671607017517090e-02
    z[2,5,3]  R2109     0.0948103740811348
    z[2,5,3]  R2110     5.7832002639770508e-02
    z[2,5,3]  R2111     4.1294094175100327e-02
    z[2,5,4]  R24       -1
    z[2,5,4]  R51       1
    z[2,5,4]  R2068     -1
    z[2,5,4]  R2069     1
    z[2,5,4]  R2074     1.4716325700283051e-01
    z[2,5,4]  R2075     1.8556064367294312e-01
    z[2,5,4]  R2076     -6.7625559866428375e-02
    z[2,5,4]  R2077     -6.6623234748840332e-01
    z[2,5,4]  R2078     6.1862188577651978e-01
    z[2,5,4]  R2079     1.4586891233921051e-01
    z[2,5,4]  R2080     -2.1497756242752075e-01
    z[2,5,4]  R2081     -1.0132491588592529e-01
    z[2,5,4]  R2082     1.1973230540752411e-01
    z[2,5,4]  R2083     0.300994336605072
    z[2,5,4]  R2084     2.9803445935249329e-01
    z[2,5,4]  R2085     0.651832640171051
    z[2,5,4]  R2086     4.7439518570899963e-01
    z[2,5,4]  R2087     1.4170329086482525e-02
    z[2,5,4]  R2088     2.2644495964050293e-01
    z[2,5,4]  R2089     -1.3397192955017090e-01
    z[2,5,4]  R2090     1.1349140852689743e-01
    z[2,5,4]  R2091     -1.2802682816982269e-01
    z[2,5,4]  R2092     -2.5850141048431396e-01
    z[2,5,4]  R2093     -0.37811079621315
    z[2,5,4]  R2094     5.4164677858352661e-02
    z[2,5,4]  R2095     4.6782290935516357e-01
    z[2,5,4]  R2096     -1.3765020668506622e-01
    z[2,5,4]  R2097     6.3581025600433350e-01
    z[2,5,4]  R2098     2.3368719220161438e-01
    z[2,5,4]  R2099     3.0189290642738342e-01
    z[2,5,4]  R2100     1.0823497176170349e-01
    z[2,5,4]  R2101     1.3297668099403381e-01
    z[2,5,4]  R2102     3.7571147084236145e-01
    z[2,5,4]  R2103     -1.9383493065834045e-01
    z[2,5,4]  R2104     -5.8535319566726685e-01
    z[2,5,4]  R2105     -4.5141065120697021e-01
    z[2,5,4]  R2106     3.5576120018959045e-01
    z[2,5,4]  R2107     3.0308127403259277e-01
    z[2,5,4]  R2108     -6.1856800317764282e-01
    z[2,5,4]  R2109     -8.9350748062133789e-01
    z[2,5,4]  R2110     -6.5405994653701782e-01
    z[2,5,4]  R2111     -7.2544282674789429e-01
    z[2,5,5]  R25       -1
    z[2,5,5]  R52       1
    z[2,5,5]  R2070     -1
    z[2,5,5]  R2071     1
    z[2,5,5]  R2074     -8.9536219835281372e-02
    z[2,5,5]  R2075     -4.3601948022842407e-01
    z[2,5,5]  R2076     -4.3901872634887695e-01
    z[2,5,5]  R2077     -1.8987026810646057e-01
    z[2,5,5]  R2078     -1.1239253729581833e-01
    z[2,5,5]  R2079     1.7196870176121593e-03
    z[2,5,5]  R2080     -6.0424745082855225e-01
    z[2,5,5]  R2081     2.7948565781116486e-02
    z[2,5,5]  R2082     -5.8154165744781494e-01
    z[2,5,5]  R2083     -3.6647930741310120e-01
    z[2,5,5]  R2084     -0.28862264752388
    z[2,5,5]  R2085     2.3364624939858913e-04
    z[2,5,5]  R2086     -0.0412154383957386
    z[2,5,5]  R2087     2.4114564061164856e-02
    z[2,5,5]  R2088     -2.6987118646502495e-02
    z[2,5,5]  R2089     1.8430331349372864e-01
    z[2,5,5]  R2090     2.1725286543369293e-01
    z[2,5,5]  R2091     1.8040643632411957e-01
    z[2,5,5]  R2092     -2.1415190398693085e-01
    z[2,5,5]  R2093     -2.1765044331550598e-01
    z[2,5,5]  R2094     -1.4287843368947506e-02
    z[2,5,5]  R2095     -5.6503123044967651e-01
    z[2,5,5]  R2096     -4.3702629208564758e-01
    z[2,5,5]  R2097     -1.3089406490325928e-01
    z[2,5,5]  R2098     -1.7761671543121338e-01
    z[2,5,5]  R2099     -1.0719674080610275e-01
    z[2,5,5]  R2100     -5.2818857133388519e-02
    z[2,5,5]  R2101     -4.0881308913230896e-01
    z[2,5,5]  R2102     -2.4879913777112961e-02
    z[2,5,5]  R2103     1.7187925055623055e-02
    z[2,5,5]  R2104     2.3088967800140381e-01
    z[2,5,5]  R2105     -5.8473899960517883e-02
    z[2,5,5]  R2106     -4.6503199264407158e-03
    z[2,5,5]  R2107     7.1491762995719910e-02
    z[2,5,5]  R2108     1.2345013022422791e-01
    z[2,5,5]  R2109     -1.6062812507152557e-01
    z[2,5,5]  R2110     -3.3547499775886536e-01
    z[2,5,5]  R2111     -2.1850788965821266e-02
    z[2,5,6]  R26       -1
    z[2,5,6]  R53       1
    z[2,5,6]  R2072     -1
    z[2,5,6]  R2073     1
    z[2,5,6]  R2074     1.3442881405353546e-01
    z[2,5,6]  R2075     -1.6207480430603027e-01
    z[2,5,6]  R2076     3.9075037837028503e-01
    z[2,5,6]  R2077     -1.9765419885516167e-02
    z[2,5,6]  R2078     3.6183750629425049e-01
    z[2,5,6]  R2079     0.00778647605329752
    z[2,5,6]  R2080     -0.0814017578959465
    z[2,5,6]  R2081     2.0233786106109619e-01
    z[2,5,6]  R2082     1.5658171474933624e-01
    z[2,5,6]  R2083     -1.3966041803359985e-01
    z[2,5,6]  R2084     -4.1171273589134216e-01
    z[2,5,6]  R2085     7.1930252015590668e-03
    z[2,5,6]  R2086     6.5253138542175293e-02
    z[2,5,6]  R2087     -0.582328200340271
    z[2,5,6]  R2088     6.0079389810562134e-01
    z[2,5,6]  R2089     1.4935743808746338e-01
    z[2,5,6]  R2090     -1.9328398630023003e-02
    z[2,5,6]  R2091     -0.235909104347229
    z[2,5,6]  R2092     0.462148517370224
    z[2,5,6]  R2093     3.3447670936584473e-01
    z[2,5,6]  R2094     6.1444687843322754e-01
    z[2,5,6]  R2095     -4.3590404093265533e-03
    z[2,5,6]  R2096     2.2357994690537453e-02
    z[2,5,6]  R2097     5.7348549365997314e-01
    z[2,5,6]  R2098     -6.9269933737814426e-03
    z[2,5,6]  R2099     1.0610774904489517e-01
    z[2,5,6]  R2100     1.7449681460857391e-01
    z[2,5,6]  R2101     7.7917866408824921e-02
    z[2,5,6]  R2102     4.0451128035783768e-02
    z[2,5,6]  R2103     -2.2428588569164276e-01
    z[2,5,6]  R2104     -4.0222319960594177e-01
    z[2,5,6]  R2105     -7.0052641630172729e-01
    z[2,5,6]  R2106     -3.9406427741050720e-01
    z[2,5,6]  R2107     -2.1893793344497681e-01
    z[2,5,6]  R2108     0.0604308545589447
    z[2,5,6]  R2109     1.7724696546792984e-02
    z[2,5,6]  R2110     5.0938300788402557e-02
    z[2,5,6]  R2111     -1.3692008331418037e-02
    z[5,2,0]  R20       1
    z[5,2,0]  R47       -1
    z[5,2,0]  R2112     -1
    z[5,2,0]  R2113     1
    z[5,2,0]  R2126     0.465468168258667
    z[5,2,0]  R2127     4.8361030220985413e-01
    z[5,2,0]  R2128     3.9293155074119568e-01
    z[5,2,0]  R2129     4.5623803138732910e-01
    z[5,2,0]  R2130     6.6259825229644775e-01
    z[5,2,0]  R2131     4.4954261183738708e-01
    z[5,2,0]  R2132     -6.7470502853393555e-01
    z[5,2,0]  R2133     -6.7426276206970215e-01
    z[5,2,0]  R2134     -7.7380383014678955e-01
    z[5,2,0]  R2135     5.5530810356140137e-01
    z[5,2,0]  R2136     5.7968068122863770e-01
    z[5,2,0]  R2137     -3.3840614557266235e-01
    z[5,2,0]  R2138     -4.5139434933662415e-01
    z[5,2,0]  R2139     -0.545189619064331
    z[5,2,0]  R2140     -1.6080382466316223e-01
    z[5,2,0]  R2141     -1.4969871938228607e-01
    z[5,2,0]  R2142     -2.0674932003021240e-01
    z[5,2,0]  R2143     -1.6465358436107635e-01
    z[5,2,0]  R2144     7.4829590320587158e-01
    z[5,2,0]  R2145     5.1608401536941528e-01
    z[5,2,0]  R2146     0.537086009979248
    z[5,2,0]  R2147     4.9732410907745361e-01
    z[5,2,0]  R2148     4.7364082932472229e-01
    z[5,2,0]  R2149     -7.3809754848480225e-01
    z[5,2,0]  R2150     -2.6245564222335815e-01
    z[5,2,0]  R2151     -3.8120758533477783e-01
    z[5,2,0]  R2152     1.0940525680780411e-01
    z[5,2,0]  R2153     -3.2202787697315216e-03
    z[5,2,0]  R2154     1.4168143272399902e-01
    z[5,2,0]  R2155     -4.6991547942161560e-01
    z[5,2,0]  R2156     -2.5674232840538025e-01
    z[5,2,0]  R2157     3.3428356051445007e-01
    z[5,2,0]  R2158     0.565673291683197
    z[5,2,0]  R2159     -1.8310900032520294e-01
    z[5,2,0]  R2160     -2.4000744521617889e-01
    z[5,2,0]  R2161     -3.2580006122589111e-01
    z[5,2,0]  R2162     0.0563129186630249
    z[5,2,0]  R2163     -2.3766435682773590e-01
    z[5,2,1]  R21       1
    z[5,2,1]  R48       -1
    z[5,2,1]  R2114     -1
    z[5,2,1]  R2115     1
    z[5,2,1]  R2126     -2.6089332997798920e-02
    z[5,2,1]  R2127     -1.7964828014373779e-01
    z[5,2,1]  R2128     -2.0432645082473755e-01
    z[5,2,1]  R2129     -0.0886748731136322
    z[5,2,1]  R2130     -9.4480365514755249e-02
    z[5,2,1]  R2131     8.1957143545150757e-01
    z[5,2,1]  R2132     -1.0136871039867401e-01
    z[5,2,1]  R2133     -1.5375743806362152e-01
    z[5,2,1]  R2134     -1.6285133361816406e-01
    z[5,2,1]  R2135     -2.9200801253318787e-01
    z[5,2,1]  R2136     2.3025064170360565e-01
    z[5,2,1]  R2137     3.2131013274192810e-01
    z[5,2,1]  R2138     5.4254125803709030e-02
    z[5,2,1]  R2139     -0.13618203997612
    z[5,2,1]  R2140     -4.6495974063873291e-01
    z[5,2,1]  R2141     1.3007128611207008e-02
    z[5,2,1]  R2142     2.0443606376647949e-01
    z[5,2,1]  R2143     2.2308218479156494e-01
    z[5,2,1]  R2144     -3.2144561409950256e-01
    z[5,2,1]  R2145     -2.0471605658531189e-01
    z[5,2,1]  R2146     -3.1970420479774475e-01
    z[5,2,1]  R2147     -1.8541653454303741e-01
    z[5,2,1]  R2148     1.3635165989398956e-01
    z[5,2,1]  R2149     -1.0374334640800953e-02
    z[5,2,1]  R2150     -2.3291751742362976e-01
    z[5,2,1]  R2151     3.8018960505723953e-02
    z[5,2,1]  R2152     6.7745143175125122e-01
    z[5,2,1]  R2153     0.726978063583374
    z[5,2,1]  R2154     3.9020961523056030e-01
    z[5,2,1]  R2155     -2.1759761869907379e-01
    z[5,2,1]  R2156     -3.1393334269523621e-01
    z[5,2,1]  R2157     5.5078876018524170e-01
    z[5,2,1]  R2158     0.0785161480307579
    z[5,2,1]  R2159     -8.9253157377243042e-02
    z[5,2,1]  R2160     -2.2639174759387970e-01
    z[5,2,1]  R2161     -4.4696471095085144e-01
    z[5,2,1]  R2162     8.1399637460708618e-01
    z[5,2,1]  R2163     7.4620097875595093e-01
    z[5,2,2]  R22       1
    z[5,2,2]  R49       -1
    z[5,2,2]  R2116     -1
    z[5,2,2]  R2117     1
    z[5,2,2]  R2126     2.7867025136947632e-01
    z[5,2,2]  R2127     -1.0877050459384918e-01
    z[5,2,2]  R2128     1.4166106283664703e-01
    z[5,2,2]  R2129     -1.6703473031520844e-01
    z[5,2,2]  R2130     -0.681039571762085
    z[5,2,2]  R2131     -7.1422152221202850e-02
    z[5,2,2]  R2132     -2.3632074892520905e-01
    z[5,2,2]  R2133     1.2734462320804596e-01
    z[5,2,2]  R2134     2.0489895343780518e-01
    z[5,2,2]  R2135     5.6785231828689575e-01
    z[5,2,2]  R2136     1.4935834705829620e-01
    z[5,2,2]  R2137     5.2744146436452866e-02
    z[5,2,2]  R2138     -3.7843767553567886e-02
    z[5,2,2]  R2139     -2.2276104986667633e-01
    z[5,2,2]  R2140     5.8946889638900757e-01
    z[5,2,2]  R2141     3.7942177057266235e-01
    z[5,2,2]  R2142     6.0760462284088135e-01
    z[5,2,2]  R2143     6.2808138132095337e-01
    z[5,2,2]  R2144     -0.515376091003418
    z[5,2,2]  R2145     4.1804668307304382e-01
    z[5,2,2]  R2146     1.2986409664154053e-01
    z[5,2,2]  R2147     4.5868310332298279e-01
    z[5,2,2]  R2148     3.5329717397689819e-01
    z[5,2,2]  R2149     2.0457613468170166e-01
    z[5,2,2]  R2150     -1.2198117375373840e-01
    z[5,2,2]  R2151     -0.887882649898529
    z[5,2,2]  R2152     -3.7543609738349915e-01
    z[5,2,2]  R2153     -4.6628442406654358e-01
    z[5,2,2]  R2154     1.2427022308111191e-01
    z[5,2,2]  R2155     -2.0072016119956970e-01
    z[5,2,2]  R2156     3.8638854026794434e-01
    z[5,2,2]  R2157     -0.310772567987442
    z[5,2,2]  R2158     2.9522114992141724e-01
    z[5,2,2]  R2159     -8.5445863008499146e-01
    z[5,2,2]  R2160     -9.0961974859237671e-01
    z[5,2,2]  R2161     -6.8891471624374390e-01
    z[5,2,2]  R2162     -8.8315911591053009e-02
    z[5,2,2]  R2163     -2.7855682373046875e-01
    z[5,2,3]  R23       1
    z[5,2,3]  R50       -1
    z[5,2,3]  R2118     -1
    z[5,2,3]  R2119     1
    z[5,2,3]  R2126     -5.6948989629745483e-01
    z[5,2,3]  R2127     -4.2881119251251221e-01
    z[5,2,3]  R2128     -7.5719755887985229e-01
    z[5,2,3]  R2129     0.0762195810675621
    z[5,2,3]  R2130     4.4908598065376282e-02
    z[5,2,3]  R2131     8.4992036223411560e-02
    z[5,2,3]  R2132     -6.5855622291564941e-01
    z[5,2,3]  R2133     -5.6091868877410889e-01
    z[5,2,3]  R2134     -4.3509653210639954e-01
    z[5,2,3]  R2135     0.442421019077301
    z[5,2,3]  R2136     -1.7582742869853973e-01
    z[5,2,3]  R2137     -2.8553646802902222e-01
    z[5,2,3]  R2138     7.1413803100585938e-01
    z[5,2,3]  R2139     6.9978368282318115e-01
    z[5,2,3]  R2140     -9.4671607017517090e-02
    z[5,2,3]  R2141     0.0948103740811348
    z[5,2,3]  R2142     5.7832002639770508e-02
    z[5,2,3]  R2143     4.1294094175100327e-02
    z[5,2,3]  R2144     1.5286819636821747e-01
    z[5,2,3]  R2145     -5.1591819524765015e-01
    z[5,2,3]  R2146     -4.9240902066230774e-01
    z[5,2,3]  R2147     -1.6610951721668243e-01
    z[5,2,3]  R2148     -3.2557976245880127e-01
    z[5,2,3]  R2149     -6.2602853775024414e-01
    z[5,2,3]  R2150     -0.666356086730957
    z[5,2,3]  R2151     1.1362785845994949e-01
    z[5,2,3]  R2152     1.0532516241073608e-01
    z[5,2,3]  R2153     0.0982937142252922
    z[5,2,3]  R2154     6.8599176406860352e-01
    z[5,2,3]  R2155     5.1633769273757935e-01
    z[5,2,3]  R2156     6.7470401525497437e-01
    z[5,2,3]  R2157     -3.8525089621543884e-01
    z[5,2,3]  R2158     4.1681462526321411e-01
    z[5,2,3]  R2159     3.9265963435173035e-01
    z[5,2,3]  R2160     5.7291448116302490e-02
    z[5,2,3]  R2161     3.3894369006156921e-01
    z[5,2,3]  R2162     -1.3183162547647953e-02
    z[5,2,3]  R2163     8.3016470074653625e-02
    z[5,2,4]  R24       1
    z[5,2,4]  R51       -1
    z[5,2,4]  R2120     -1
    z[5,2,4]  R2121     1
    z[5,2,4]  R2126     5.4164677858352661e-02
    z[5,2,4]  R2127     4.6782290935516357e-01
    z[5,2,4]  R2128     -1.3765020668506622e-01
    z[5,2,4]  R2129     6.3581025600433350e-01
    z[5,2,4]  R2130     2.3368719220161438e-01
    z[5,2,4]  R2131     3.0189290642738342e-01
    z[5,2,4]  R2132     1.0823497176170349e-01
    z[5,2,4]  R2133     1.3297668099403381e-01
    z[5,2,4]  R2134     3.7571147084236145e-01
    z[5,2,4]  R2135     -1.9383493065834045e-01
    z[5,2,4]  R2136     -5.8535319566726685e-01
    z[5,2,4]  R2137     -4.5141065120697021e-01
    z[5,2,4]  R2138     3.5576120018959045e-01
    z[5,2,4]  R2139     3.0308127403259277e-01
    z[5,2,4]  R2140     -6.1856800317764282e-01
    z[5,2,4]  R2141     -8.9350748062133789e-01
    z[5,2,4]  R2142     -6.5405994653701782e-01
    z[5,2,4]  R2143     -7.2544282674789429e-01
    z[5,2,4]  R2144     1.4716325700283051e-01
    z[5,2,4]  R2145     1.8556064367294312e-01
    z[5,2,4]  R2146     -6.7625559866428375e-02
    z[5,2,4]  R2147     -6.6623234748840332e-01
    z[5,2,4]  R2148     6.1862188577651978e-01
    z[5,2,4]  R2149     1.4586891233921051e-01
    z[5,2,4]  R2150     -2.1497756242752075e-01
    z[5,2,4]  R2151     -1.0132491588592529e-01
    z[5,2,4]  R2152     1.1973230540752411e-01
    z[5,2,4]  R2153     0.300994336605072
    z[5,2,4]  R2154     2.9803445935249329e-01
    z[5,2,4]  R2155     0.651832640171051
    z[5,2,4]  R2156     4.7439518570899963e-01
    z[5,2,4]  R2157     1.4170329086482525e-02
    z[5,2,4]  R2158     2.2644495964050293e-01
    z[5,2,4]  R2159     -1.3397192955017090e-01
    z[5,2,4]  R2160     1.1349140852689743e-01
    z[5,2,4]  R2161     -1.2802682816982269e-01
    z[5,2,4]  R2162     -2.5850141048431396e-01
    z[5,2,4]  R2163     -0.37811079621315
    z[5,2,5]  R25       1
    z[5,2,5]  R52       -1
    z[5,2,5]  R2122     -1
    z[5,2,5]  R2123     1
    z[5,2,5]  R2126     -1.4287843368947506e-02
    z[5,2,5]  R2127     -5.6503123044967651e-01
    z[5,2,5]  R2128     -4.3702629208564758e-01
    z[5,2,5]  R2129     -1.3089406490325928e-01
    z[5,2,5]  R2130     -1.7761671543121338e-01
    z[5,2,5]  R2131     -1.0719674080610275e-01
    z[5,2,5]  R2132     -5.2818857133388519e-02
    z[5,2,5]  R2133     -4.0881308913230896e-01
    z[5,2,5]  R2134     -2.4879913777112961e-02
    z[5,2,5]  R2135     1.7187925055623055e-02
    z[5,2,5]  R2136     2.3088967800140381e-01
    z[5,2,5]  R2137     -5.8473899960517883e-02
    z[5,2,5]  R2138     -4.6503199264407158e-03
    z[5,2,5]  R2139     7.1491762995719910e-02
    z[5,2,5]  R2140     1.2345013022422791e-01
    z[5,2,5]  R2141     -1.6062812507152557e-01
    z[5,2,5]  R2142     -3.3547499775886536e-01
    z[5,2,5]  R2143     -2.1850788965821266e-02
    z[5,2,5]  R2144     -8.9536219835281372e-02
    z[5,2,5]  R2145     -4.3601948022842407e-01
    z[5,2,5]  R2146     -4.3901872634887695e-01
    z[5,2,5]  R2147     -1.8987026810646057e-01
    z[5,2,5]  R2148     -1.1239253729581833e-01
    z[5,2,5]  R2149     1.7196870176121593e-03
    z[5,2,5]  R2150     -6.0424745082855225e-01
    z[5,2,5]  R2151     2.7948565781116486e-02
    z[5,2,5]  R2152     -5.8154165744781494e-01
    z[5,2,5]  R2153     -3.6647930741310120e-01
    z[5,2,5]  R2154     -0.28862264752388
    z[5,2,5]  R2155     2.3364624939858913e-04
    z[5,2,5]  R2156     -0.0412154383957386
    z[5,2,5]  R2157     2.4114564061164856e-02
    z[5,2,5]  R2158     -2.6987118646502495e-02
    z[5,2,5]  R2159     1.8430331349372864e-01
    z[5,2,5]  R2160     2.1725286543369293e-01
    z[5,2,5]  R2161     1.8040643632411957e-01
    z[5,2,5]  R2162     -2.1415190398693085e-01
    z[5,2,5]  R2163     -2.1765044331550598e-01
    z[5,2,6]  R26       1
    z[5,2,6]  R53       -1
    z[5,2,6]  R2124     -1
    z[5,2,6]  R2125     1
    z[5,2,6]  R2126     6.1444687843322754e-01
    z[5,2,6]  R2127     -4.3590404093265533e-03
    z[5,2,6]  R2128     2.2357994690537453e-02
    z[5,2,6]  R2129     5.7348549365997314e-01
    z[5,2,6]  R2130     -6.9269933737814426e-03
    z[5,2,6]  R2131     1.0610774904489517e-01
    z[5,2,6]  R2132     1.7449681460857391e-01
    z[5,2,6]  R2133     7.7917866408824921e-02
    z[5,2,6]  R2134     4.0451128035783768e-02
    z[5,2,6]  R2135     -2.2428588569164276e-01
    z[5,2,6]  R2136     -4.0222319960594177e-01
    z[5,2,6]  R2137     -7.0052641630172729e-01
    z[5,2,6]  R2138     -3.9406427741050720e-01
    z[5,2,6]  R2139     -2.1893793344497681e-01
    z[5,2,6]  R2140     0.0604308545589447
    z[5,2,6]  R2141     1.7724696546792984e-02
    z[5,2,6]  R2142     5.0938300788402557e-02
    z[5,2,6]  R2143     -1.3692008331418037e-02
    z[5,2,6]  R2144     1.3442881405353546e-01
    z[5,2,6]  R2145     -1.6207480430603027e-01
    z[5,2,6]  R2146     3.9075037837028503e-01
    z[5,2,6]  R2147     -1.9765419885516167e-02
    z[5,2,6]  R2148     3.6183750629425049e-01
    z[5,2,6]  R2149     0.00778647605329752
    z[5,2,6]  R2150     -0.0814017578959465
    z[5,2,6]  R2151     2.0233786106109619e-01
    z[5,2,6]  R2152     1.5658171474933624e-01
    z[5,2,6]  R2153     -1.3966041803359985e-01
    z[5,2,6]  R2154     -4.1171273589134216e-01
    z[5,2,6]  R2155     7.1930252015590668e-03
    z[5,2,6]  R2156     6.5253138542175293e-02
    z[5,2,6]  R2157     -0.582328200340271
    z[5,2,6]  R2158     6.0079389810562134e-01
    z[5,2,6]  R2159     1.4935743808746338e-01
    z[5,2,6]  R2160     -1.9328398630023003e-02
    z[5,2,6]  R2161     -0.235909104347229
    z[5,2,6]  R2162     0.462148517370224
    z[5,2,6]  R2163     3.3447670936584473e-01
    z[3,4,0]  R29       -1
    z[3,4,0]  R38       1
    z[3,4,0]  R2198     -1
    z[3,4,0]  R2199     1
    z[3,4,0]  R2212     -5.7539260387420654e-01
    z[3,4,0]  R2213     -4.6624532341957092e-01
    z[3,4,0]  R2214     -5.0899642705917358e-01
    z[3,4,0]  R2215     -1.2014885246753693e-01
    z[3,4,0]  R2216     -5.0082010030746460e-01
    z[3,4,0]  R2217     5.9517875313758850e-02
    z[3,4,0]  R2218     -1.1326623708009720e-01
    z[3,4,0]  R2219     1.3849098980426788e-01
    z[3,4,0]  R2220     4.2004132270812988e-01
    z[3,4,0]  R2221     1.9014729559421539e-01
    z[3,4,0]  R2222     5.7204455137252808e-01
    z[3,4,0]  R2223     0.572113037109375
    z[3,4,0]  R2224     5.7787096500396729e-01
    z[3,4,0]  R2225     5.3382194042205811e-01
    z[3,4,0]  R2226     1.7811340093612671e-01
    z[3,4,0]  R2227     5.7484441995620728e-01
    z[3,4,0]  R2228     0.334280788898468
    z[3,4,0]  R2229     5.1705837249755859e-02
    z[3,4,0]  R2230     3.4049415588378906e-01
    z[3,4,0]  R2231     6.3084119558334351e-01
    z[3,4,0]  R2232     9.9886313080787659e-02
    z[3,4,0]  R2233     0.684758722782135
    z[3,4,0]  R2234     5.9450703859329224e-01
    z[3,4,0]  R2235     5.3604131937026978e-01
    z[3,4,0]  R2236     5.7761001586914062e-01
    z[3,4,0]  R2237     5.9616720676422119e-01
    z[3,4,0]  R2238     5.5288159847259521e-01
    z[3,4,0]  R2239     6.0106503963470459e-01
    z[3,4,0]  R2240     4.5466482639312744e-01
    z[3,4,0]  R2241     6.2489295005798340e-01
    z[3,4,0]  R2242     -4.3019089847803116e-02
    z[3,4,0]  R2243     -4.8385281115770340e-02
    z[3,4,0]  R2244     -5.2565336227416992e-01
    z[3,4,0]  R2245     -1.6974531114101410e-01
    z[3,4,0]  R2246     7.1861910820007324e-01
    z[3,4,0]  R2247     -4.3361854553222656e-01
    z[3,4,0]  R2248     -5.8581691980361938e-01
    z[3,4,0]  R2249     -8.2092887163162231e-01
    z[3,4,0]  R2250     -7.8789454698562622e-01
    z[3,4,0]  R2251     -7.9566174745559692e-01
    z[3,4,0]  R2252     9.5633447170257568e-02
    z[3,4,0]  R2253     7.3859155178070068e-02
    z[3,4,0]  R2254     1.6299448907375336e-01
    z[3,4,0]  R2255     -0.557685136795044
    z[3,4,0]  R2256     -2.3144088685512543e-01
    z[3,4,0]  R2257     8.0284041166305542e-01
    z[3,4,0]  R2258     -0.42790487408638
    z[3,4,0]  R2259     -4.4375672936439514e-01
    z[3,4,0]  R2260     -1.8512088805437088e-02
    z[3,4,0]  R2261     3.3699741959571838e-01
    z[3,4,0]  R2262     7.2173547744750977e-01
    z[3,4,0]  R2263     -2.6034882664680481e-01
    z[3,4,0]  R2264     -8.8026374578475952e-02
    z[3,4,0]  R2265     7.0207589864730835e-01
    z[3,4,0]  R2266     1.3437853753566742e-01
    z[3,4,0]  R2267     6.1883461475372314e-01
    z[3,4,0]  R2268     5.5191999673843384e-01
    z[3,4,0]  R2269     5.7589358091354370e-01
    z[3,4,0]  R2270     1.9529409706592560e-01
    z[3,4,0]  R2271     8.8348609209060669e-01
    z[3,4,0]  R2272     0.498344749212265
    z[3,4,0]  R2273     -5.7064223289489746e-01
    z[3,4,0]  R2274     -3.8162621855735779e-01
    z[3,4,0]  R2275     -5.8480417728424072e-01
    z[3,4,0]  R2276     -4.7194001078605652e-01
    z[3,4,0]  R2277     -4.4435703754425049e-01
    z[3,4,0]  R2278     -4.1637751460075378e-01
    z[3,4,0]  R2279     -4.7644710540771484e-01
    z[3,4,0]  R2280     -6.2589657306671143e-01
    z[3,4,0]  R2281     -3.0824321508407593e-01
    z[3,4,0]  R2282     6.4118367433547974e-01
    z[3,4,0]  R2283     5.4827427864074707e-01
    z[3,4,0]  R2284     3.2010135054588318e-01
    z[3,4,0]  R2285     1.3908789493143559e-02
    z[3,4,0]  R2286     3.6178115010261536e-01
    z[3,4,0]  R2287     3.5426384210586548e-01
    z[3,4,0]  R2288     3.4391263127326965e-01
    z[3,4,0]  R2289     -3.3993339538574219e-01
    z[3,4,0]  R2290     -0.0794341191649437
    z[3,4,0]  R2291     -1.8189454078674316e-01
    z[3,4,0]  R2292     6.8536871671676636e-01
    z[3,4,0]  R2293     6.1935573816299438e-01
    z[3,4,0]  R2294     -4.0746080875396729e-01
    z[3,4,0]  R2295     4.1207635402679443e-01
    z[3,4,0]  R2296     -3.0557766556739807e-02
    z[3,4,0]  R2297     1.9815362989902496e-01
    z[3,4,0]  R2298     -1.0177161544561386e-01
    z[3,4,0]  R2299     -3.2355093955993652e-01
    z[3,4,0]  R2300     -3.2967633008956909e-01
    z[3,4,0]  R2301     -5.7720702886581421e-01
    z[3,4,1]  R30       -1
    z[3,4,1]  R39       1
    z[3,4,1]  R2200     -1
    z[3,4,1]  R2201     1
    z[3,4,1]  R2212     5.3784084320068359e-01
    z[3,4,1]  R2213     4.0997806191444397e-01
    z[3,4,1]  R2214     3.5884803533554077e-01
    z[3,4,1]  R2215     6.3315761089324951e-01
    z[3,4,1]  R2216     6.0678112506866455e-01
    z[3,4,1]  R2217     1.5981715917587280e-01
    z[3,4,1]  R2218     -6.0067433118820190e-01
    z[3,4,1]  R2219     -5.6848269701004028e-01
    z[3,4,1]  R2220     -6.1022669076919556e-01
    z[3,4,1]  R2221     -4.7365039587020874e-01
    z[3,4,1]  R2222     -7.7890610694885254e-01
    z[3,4,1]  R2223     -0.734073281288147
    z[3,4,1]  R2224     -7.1233463287353516e-01
    z[3,4,1]  R2225     -7.4874430894851685e-01
    z[3,4,1]  R2226     -8.8062816858291626e-01
    z[3,4,1]  R2227     -7.2288483381271362e-01
    z[3,4,1]  R2228     -8.5410809516906738e-01
    z[3,4,1]  R2229     -8.4017670154571533e-01
    z[3,4,1]  R2230     -8.2712328433990479e-01
    z[3,4,1]  R2231     -6.3271623849868774e-01
    z[3,4,1]  R2232     -2.8168407082557678e-01
    z[3,4,1]  R2233     4.9736425280570984e-01
    z[3,4,1]  R2234     4.9484935402870178e-01
    z[3,4,1]  R2235     5.2616351842880249e-01
    z[3,4,1]  R2236     4.0387737751007080e-01
    z[3,4,1]  R2237     3.4215039014816284e-01
    z[3,4,1]  R2238     5.1828610897064209e-01
    z[3,4,1]  R2239     3.5125705599784851e-01
    z[3,4,1]  R2240     4.8839551210403442e-01
    z[3,4,1]  R2241     3.7105610966682434e-01
    z[3,4,1]  R2242     3.2518428564071655e-01
    z[3,4,1]  R2243     -1.1943493038415909e-01
    z[3,4,1]  R2244     -4.5852270722389221e-01
    z[3,4,1]  R2245     -4.6201723814010620e-01
    z[3,4,1]  R2246     3.0634099245071411e-01
    z[3,4,1]  R2247     -3.5620772838592529e-01
    z[3,4,1]  R2248     -5.4595535993576050e-01
    z[3,4,1]  R2249     -0.424570769071579
    z[3,4,1]  R2250     -0.507512629032135
    z[3,4,1]  R2251     -5.1523089408874512e-01
    z[3,4,1]  R2252     -1.7358395457267761e-01
    z[3,4,1]  R2253     -6.7534017562866211e-01
    z[3,4,1]  R2254     -5.6824922561645508e-01
    z[3,4,1]  R2255     -7.2195613384246826e-01
    z[3,4,1]  R2256     -2.6490309834480286e-01
    z[3,4,1]  R2257     3.6142560839653015e-01
    z[3,4,1]  R2258     -2.9764235019683838e-01
    z[3,4,1]  R2259     -0.304245263338089
    z[3,4,1]  R2260     -2.3560518398880959e-02
    z[3,4,1]  R2261     3.8852196931838989e-01
    z[3,4,1]  R2262     4.7464835643768311e-01
    z[3,4,1]  R2263     -3.7263244390487671e-01
    z[3,4,1]  R2264     -5.8896821737289429e-01
    z[3,4,1]  R2265     5.5480856448411942e-02
    z[3,4,1]  R2266     -0.356360524892807
    z[3,4,1]  R2267     -2.9439383745193481e-01
    z[3,4,1]  R2268     -3.9077866077423096e-01
    z[3,4,1]  R2269     4.5883551239967346e-01
    z[3,4,1]  R2270     -2.5890287756919861e-01
    z[3,4,1]  R2271     1.8817149102687836e-01
    z[3,4,1]  R2272     -3.1648527830839157e-02
    z[3,4,1]  R2273     4.7781169414520264e-01
    z[3,4,1]  R2274     4.4560694694519043e-01
    z[3,4,1]  R2275     5.7730001211166382e-01
    z[3,4,1]  R2276     3.6223095655441284e-01
    z[3,4,1]  R2277     4.5222055912017822e-01
    z[3,4,1]  R2278     5.4885065555572510e-01
    z[3,4,1]  R2279     5.3115218877792358e-01
    z[3,4,1]  R2280     5.1203662157058716e-01
    z[3,4,1]  R2281     -3.8567224144935608e-01
    z[3,4,1]  R2282     -4.6898555010557175e-02
    z[3,4,1]  R2283     1.9691698253154755e-01
    z[3,4,1]  R2284     -3.3078789710998535e-01
    z[3,4,1]  R2285     -2.5322714447975159e-01
    z[3,4,1]  R2286     -0.521737277507782
    z[3,4,1]  R2287     2.8693714737892151e-01
    z[3,4,1]  R2288     -4.4296371936798096e-01
    z[3,4,1]  R2289     -6.5261906385421753e-01
    z[3,4,1]  R2290     5.0646450370550156e-02
    z[3,4,1]  R2291     -8.7560421228408813e-01
    z[3,4,1]  R2292     8.7547548115253448e-02
    z[3,4,1]  R2293     -5.1780784130096436e-01
    z[3,4,1]  R2294     -5.1614469289779663e-01
    z[3,4,1]  R2295     -1.3408043980598450e-01
    z[3,4,1]  R2296     -1.9141638278961182e-01
    z[3,4,1]  R2297     5.2375458180904388e-02
    z[3,4,1]  R2298     1.0893474519252777e-01
    z[3,4,1]  R2299     -1.1364394426345825e-01
    z[3,4,1]  R2300     -2.2669158875942230e-01
    z[3,4,1]  R2301     -0.592122495174408
    z[3,4,2]  R31       -1
    z[3,4,2]  R40       1
    z[3,4,2]  R2202     -1
    z[3,4,2]  R2203     1
    z[3,4,2]  R2212     -3.1495407223701477e-01
    z[3,4,2]  R2213     -2.7223592996597290e-01
    z[3,4,2]  R2214     1.9476598501205444e-01
    z[3,4,2]  R2215     -3.0419480800628662e-01
    z[3,4,2]  R2216     4.5412972569465637e-02
    z[3,4,2]  R2217     -4.4046494364738464e-01
    z[3,4,2]  R2218     5.1188701391220093e-01
    z[3,4,2]  R2219     6.8993842601776123e-01
    z[3,4,2]  R2220     5.3733807802200317e-01
    z[3,4,2]  R2221     7.7381551265716553e-01
    z[3,4,2]  R2222     -1.6695824265480042e-01
    z[3,4,2]  R2223     -1.0524638742208481e-01
    z[3,4,2]  R2224     -2.3312093317508698e-01
    z[3,4,2]  R2225     -9.8969843238592148e-03
    z[3,4,2]  R2226     -3.2058599591255188e-01
    z[3,4,2]  R2227     -7.9349176958203316e-03
    z[3,4,2]  R2228     -1.4685305953025818e-01
    z[3,4,2]  R2229     -2.5821053981781006e-01
    z[3,4,2]  R2230     -4.5450992882251740e-02
    z[3,4,2]  R2231     3.5034954547882080e-01
    z[3,4,2]  R2232     -1.6533946618437767e-02
    z[3,4,2]  R2233     -1.4327681064605713e-01
    z[3,4,2]  R2234     -1.1226122081279755e-01
    z[3,4,2]  R2235     -1.1739084869623184e-01
    z[3,4,2]  R2236     1.3021047413349152e-01
    z[3,4,2]  R2237     -6.5592072904109955e-02
    z[3,4,2]  R2238     1.4451918005943298e-01
    z[3,4,2]  R2239     2.1304875612258911e-01
    z[3,4,2]  R2240     1.1093472689390182e-01
    z[3,4,2]  R2241     -6.2649093568325043e-02
    z[3,4,2]  R2242     0.0575115866959095
    z[3,4,2]  R2243     2.1006904542446136e-01
    z[3,4,2]  R2244     -2.1441720426082611e-01
    z[3,4,2]  R2245     -2.3992931842803955e-01
    z[3,4,2]  R2246     3.1207486987113953e-01
    z[3,4,2]  R2247     3.0928462743759155e-02
    z[3,4,2]  R2248     -0.0356932133436203
    z[3,4,2]  R2249     -1.3485740125179291e-01
    z[3,4,2]  R2250     -1.8079439178109169e-02
    z[3,4,2]  R2251     -2.6221296191215515e-01
    z[3,4,2]  R2252     -2.2966243326663971e-01
    z[3,4,2]  R2253     -7.7399136498570442e-03
    z[3,4,2]  R2254     2.4974639713764191e-01
    z[3,4,2]  R2255     -6.7057803273200989e-02
    z[3,4,2]  R2256     1.5775233507156372e-01
    z[3,4,2]  R2257     -8.3998069167137146e-03
    z[3,4,2]  R2258     -2.7235758304595947e-01
    z[3,4,2]  R2259     -9.1737903654575348e-02
    z[3,4,2]  R2260     5.3540718555450439e-01
    z[3,4,2]  R2261     0.501573920249939
    z[3,4,2]  R2262     2.0658016204833984e-01
    z[3,4,2]  R2263     5.1609843969345093e-01
    z[3,4,2]  R2264     6.4757645130157471e-01
    z[3,4,2]  R2265     9.8929800093173981e-02
    z[3,4,2]  R2266     5.5037707090377808e-01
    z[3,4,2]  R2267     1.7464052140712738e-01
    z[3,4,2]  R2268     -2.3853220045566559e-01
    z[3,4,2]  R2269     5.0685471296310425e-01
    z[3,4,2]  R2270     2.4018318951129913e-01
    z[3,4,2]  R2271     9.5787599682807922e-02
    z[3,4,2]  R2272     -5.3479593992233276e-01
    z[3,4,2]  R2273     -5.9657585620880127e-01
    z[3,4,2]  R2274     -7.1719348430633545e-01
    z[3,4,2]  R2275     -4.3153610825538635e-01
    z[3,4,2]  R2276     -6.7312496900558472e-01
    z[3,4,2]  R2277     -6.3912689685821533e-01
    z[3,4,2]  R2278     -6.0853153467178345e-01
    z[3,4,2]  R2279     -4.1915518045425415e-01
    z[3,4,2]  R2280     -3.3209469914436340e-01
    z[3,4,2]  R2281     -8.0496203899383545e-01
    z[3,4,2]  R2282     -4.6399781107902527e-01
    z[3,4,2]  R2283     -5.1879197359085083e-01
    z[3,4,2]  R2284     -4.1803181171417236e-01
    z[3,4,2]  R2285     1.7579983174800873e-01
    z[3,4,2]  R2286     -2.2754608094692230e-01
    z[3,4,2]  R2287     -2.3996305465698242e-01
    z[3,4,2]  R2288     1.5741537511348724e-01
    z[3,4,2]  R2289     -4.3415728211402893e-01
    z[3,4,2]  R2290     0.576196551322937
    z[3,4,2]  R2291     -4.0394324064254761e-01
    z[3,4,2]  R2292     -0.0334198921918869
    z[3,4,2]  R2293     1.4081464707851410e-01
    z[3,4,2]  R2294     1.9569399952888489e-01
    z[3,4,2]  R2295     1.2754398584365845e-01
    z[3,4,2]  R2296     3.7761977314949036e-01
    z[3,4,2]  R2297     0.517429530620575
    z[3,4,2]  R2298     7.9806648194789886e-02
    z[3,4,2]  R2299     -7.7853941917419434e-01
    z[3,4,2]  R2300     -7.5481927394866943e-01
    z[3,4,2]  R2301     -3.2312935590744019e-01
    z[3,4,3]  R32       -1
    z[3,4,3]  R41       1
    z[3,4,3]  R2204     -1
    z[3,4,3]  R2205     1
    z[3,4,3]  R2212     3.4320011734962463e-01
    z[3,4,3]  R2213     3.5711315274238586e-01
    z[3,4,3]  R2214     6.5942478179931641e-01
    z[3,4,3]  R2215     5.9538805484771729e-01
    z[3,4,3]  R2216     3.4576657414436340e-01
    z[3,4,3]  R2217     7.0035117864608765e-01
    z[3,4,3]  R2218     -0.530301034450531
    z[3,4,3]  R2219     -2.6191276311874390e-01
    z[3,4,3]  R2220     -3.3637505024671555e-02
    z[3,4,3]  R2221     -3.3186116814613342e-01
    z[3,4,3]  R2222     -7.4687272310256958e-02
    z[3,4,3]  R2223     1.0632331669330597e-01
    z[3,4,3]  R2224     2.7038154006004333e-01
    z[3,4,3]  R2225     1.2183093279600143e-01
    z[3,4,3]  R2226     3.7542287260293961e-02
    z[3,4,3]  R2227     1.1555763334035873e-01
    z[3,4,3]  R2228     2.9953292012214661e-01
    z[3,4,3]  R2229     4.1325652599334717e-01
    z[3,4,3]  R2230     2.7058649063110352e-01
    z[3,4,3]  R2231     -4.5007247477769852e-02
    z[3,4,3]  R2232     3.1242930889129639e-01
    z[3,4,3]  R2233     -0.39503213763237
    z[3,4,3]  R2234     -5.6164044141769409e-01
    z[3,4,3]  R2235     -5.4107069969177246e-01
    z[3,4,3]  R2236     -6.1921846866607666e-01
    z[3,4,3]  R2237     -5.1277482509613037e-01
    z[3,4,3]  R2238     -4.6367436647415161e-01
    z[3,4,3]  R2239     -4.8262152075767517e-01
    z[3,4,3]  R2240     -6.2656527757644653e-01
    z[3,4,3]  R2241     -4.8673585057258606e-01
    z[3,4,3]  R2242     7.2669649124145508e-01
    z[3,4,3]  R2243     0.762295126914978
    z[3,4,3]  R2244     -5.7686185836791992e-01
    z[3,4,3]  R2245     -5.2052670717239380e-01
    z[3,4,3]  R2246     -3.6024487018585205e-01
    z[3,4,3]  R2247     -4.5294648408889771e-01
    z[3,4,3]  R2248     -4.4176250696182251e-01
    z[3,4,3]  R2249     -1.0698555409908295e-01
    z[3,4,3]  R2250     -2.1624748408794403e-01
    z[3,4,3]  R2251     -1.4532610774040222e-01
    z[3,4,3]  R2252     8.5010147094726562e-01
    z[3,4,3]  R2253     -5.5896854400634766e-01
    z[3,4,3]  R2254     -5.5401455610990524e-02
    z[3,4,3]  R2255     -2.5027725100517273e-01
    z[3,4,3]  R2256     -3.6608001589775085e-01
    z[3,4,3]  R2257     -2.4820853024721146e-02
    z[3,4,3]  R2258     -5.3497594594955444e-01
    z[3,4,3]  R2259     -4.3160125613212585e-01
    z[3,4,3]  R2260     -2.8032356500625610e-01
    z[3,4,3]  R2261     3.5390022397041321e-01
    z[3,4,3]  R2262     8.6531199514865875e-02
    z[3,4,3]  R2263     -5.8207309246063232e-01
    z[3,4,3]  R2264     -3.2332116365432739e-01
    z[3,4,3]  R2265     -1.1367462575435638e-01
    z[3,4,3]  R2266     -5.6814730167388916e-01
    z[3,4,3]  R2267     -3.3525720238685608e-01
    z[3,4,3]  R2268     -1.4600183814764023e-02
    z[3,4,3]  R2269     1.4067446812987328e-02
    z[3,4,3]  R2270     -8.1641548871994019e-01
    z[3,4,3]  R2271     -2.7022278308868408e-01
    z[3,4,3]  R2272     2.8645089268684387e-01
    z[3,4,3]  R2273     2.1356928348541260e-01
    z[3,4,3]  R2274     2.5227975845336914e-01
    z[3,4,3]  R2275     2.4058888852596283e-01
    z[3,4,3]  R2276     3.8215324282646179e-01
    z[3,4,3]  R2277     2.8521296381950378e-01
    z[3,4,3]  R2278     3.2522711157798767e-01
    z[3,4,3]  R2279     1.5950119495391846e-01
    z[3,4,3]  R2280     1.9036103785037994e-01
    z[3,4,3]  R2281     1.2890487909317017e-01
    z[3,4,3]  R2282     -3.3502274751663208e-01
    z[3,4,3]  R2283     5.0122457742691040e-01
    z[3,4,3]  R2284     3.6730784177780151e-01
    z[3,4,3]  R2285     -1.6924814879894257e-01
    z[3,4,3]  R2286     0.257690966129303
    z[3,4,3]  R2287     2.8943282365798950e-01
    z[3,4,3]  R2288     3.2569810282438993e-03
    z[3,4,3]  R2289     -3.0136129260063171e-01
    z[3,4,3]  R2290     7.9324334859848022e-02
    z[3,4,3]  R2291     -5.9938136488199234e-02
    z[3,4,3]  R2292     1.2918472290039062e-01
    z[3,4,3]  R2293     -5.5456644296646118e-01
    z[3,4,3]  R2294     -3.4559625387191772e-01
    z[3,4,3]  R2295     4.1245266795158386e-01
    z[3,4,3]  R2296     2.6273833587765694e-02
    z[3,4,3]  R2297     0.0676998421549797
    z[3,4,3]  R2298     3.5153287649154663e-01
    z[3,4,3]  R2299     4.7362190485000610e-01
    z[3,4,3]  R2300     2.2187928855419159e-01
    z[3,4,3]  R2301     3.4765559434890747e-01
    z[3,4,4]  R33       -1
    z[3,4,4]  R42       1
    z[3,4,4]  R2206     -1
    z[3,4,4]  R2207     1
    z[3,4,4]  R2212     1.5212135016918182e-01
    z[3,4,4]  R2213     6.0544836521148682e-01
    z[3,4,4]  R2214     1.1388329416513443e-01
    z[3,4,4]  R2215     -2.4923862516880035e-01
    z[3,4,4]  R2216     -4.1099062561988831e-01
    z[3,4,4]  R2217     7.6116546988487244e-02
    z[3,4,4]  R2218     -1.4724639058113098e-01
    z[3,4,4]  R2219     -1.4814375340938568e-01
    z[3,4,4]  R2220     1.4779733121395111e-01
    z[3,4,4]  R2221     -1.4857585728168488e-01
    z[3,4,4]  R2222     -1.5054804086685181e-01
    z[3,4,4]  R2223     -2.9473719000816345e-01
    z[3,4,4]  R2224     -0.156258225440979
    z[3,4,4]  R2225     2.5375029444694519e-01
    z[3,4,4]  R2226     -2.8916954994201660e-01
    z[3,4,4]  R2227     1.9727160036563873e-01
    z[3,4,4]  R2228     1.4298303425312042e-01
    z[3,4,4]  R2229     1.8206825852394104e-01
    z[3,4,4]  R2230     2.2723200917243958e-01
    z[3,4,4]  R2231     4.6563889831304550e-02
    z[3,4,4]  R2232     -1.5930096805095673e-01
    z[3,4,4]  R2233     -2.0812867581844330e-01
    z[3,4,4]  R2234     -2.5409471988677979e-01
    z[3,4,4]  R2235     -3.5411116480827332e-01
    z[3,4,4]  R2236     -2.4435031414031982e-01
    z[3,4,4]  R2237     -1.3521975278854370e-01
    z[3,4,4]  R2238     2.3473742604255676e-01
    z[3,4,4]  R2239     1.3703167438507080e-01
    z[3,4,4]  R2240     1.8078124523162842e-01
    z[3,4,4]  R2241     3.0565834045410156e-01
    z[3,4,4]  R2242     -0.0800301805138588
    z[3,4,4]  R2243     1.5295787155628204e-01
    z[3,4,4]  R2244     1.1559443175792694e-01
    z[3,4,4]  R2245     6.0622924566268921e-01
    z[3,4,4]  R2246     0.179230198264122
    z[3,4,4]  R2247     -1.0031496174633503e-02
    z[3,4,4]  R2248     3.5202977061271667e-01
    z[3,4,4]  R2249     -2.7851012349128723e-01
    z[3,4,4]  R2250     -1.1431746929883957e-01
    z[3,4,4]  R2251     1.8334053456783295e-02
    z[3,4,4]  R2252     1.1465849727392197e-01
    z[3,4,4]  R2253     -1.5079215168952942e-01
    z[3,4,4]  R2254     1.2787835299968719e-01
    z[3,4,4]  R2255     1.1395392566919327e-01
    z[3,4,4]  R2256     -1.2181679904460907e-01
    z[3,4,4]  R2257     2.8046944737434387e-01
    z[3,4,4]  R2258     -5.1584386825561523e-01
    z[3,4,4]  R2259     -6.2819540500640869e-01
    z[3,4,4]  R2260     7.1900326013565063e-01
    z[3,4,4]  R2261     1.1113435961306095e-02
    z[3,4,4]  R2262     -5.9527806937694550e-02
    z[3,4,4]  R2263     -4.2494454979896545e-01
    z[3,4,4]  R2264     1.4411987364292145e-01
    z[3,4,4]  R2265     -5.6752490997314453e-01
    z[3,4,4]  R2266     0.381523460149765
    z[3,4,4]  R2267     5.0421410799026489e-01
    z[3,4,4]  R2268     4.7919169068336487e-01
    z[3,4,4]  R2269     4.1130978614091873e-02
    z[3,4,4]  R2270     -8.1844948232173920e-02
    z[3,4,4]  R2271     -1.9448215141892433e-02
    z[3,4,4]  R2272     3.3866535872220993e-02
    z[3,4,4]  R2273     6.8474814295768738e-02
    z[3,4,4]  R2274     5.6055169552564621e-02
    z[3,4,4]  R2275     -8.0082856118679047e-02
    z[3,4,4]  R2276     -8.5795380175113678e-02
    z[3,4,4]  R2277     -2.0354405045509338e-01
    z[3,4,4]  R2278     -2.2154681384563446e-01
    z[3,4,4]  R2279     -2.5517880916595459e-01
    z[3,4,4]  R2280     5.2798591786995530e-04
    z[3,4,4]  R2281     -1.6653573513031006e-01
    z[3,4,4]  R2282     -0.0630049929022789
    z[3,4,4]  R2283     5.7364720851182938e-03
    z[3,4,4]  R2284     1.0685495287179947e-01
    z[3,4,4]  R2285     -1.5308807790279388e-01
    z[3,4,4]  R2286     -1.3211238384246826e-01
    z[3,4,4]  R2287     6.2557297945022583e-01
    z[3,4,4]  R2288     -0.349031537771225
    z[3,4,4]  R2289     3.6674781586043537e-04
    z[3,4,4]  R2290     9.4423428177833557e-02
    z[3,4,4]  R2291     -1.2037818878889084e-01
    z[3,4,4]  R2292     -1.4261111617088318e-01
    z[3,4,4]  R2293     -7.8513838350772858e-02
    z[3,4,4]  R2294     1.2679681181907654e-01
    z[3,4,4]  R2295     7.3971919715404510e-02
    z[3,4,4]  R2296     -1.2156744301319122e-01
    z[3,4,4]  R2297     -4.2790338397026062e-02
    z[3,4,4]  R2298     6.2806212902069092e-01
    z[3,4,4]  R2299     1.0061531327664852e-02
    z[3,4,4]  R2300     1.9800265133380890e-01
    z[3,4,4]  R2301     1.0502353310585022e-01
    z[3,4,5]  R34       -1
    z[3,4,5]  R43       1
    z[3,4,5]  R2208     -1
    z[3,4,5]  R2209     1
    z[3,4,5]  R2212     3.2471993565559387e-01
    z[3,4,5]  R2213     1.3615280389785767e-01
    z[3,4,5]  R2214     -2.1183695644140244e-02
    z[3,4,5]  R2215     1.8469187617301941e-01
    z[3,4,5]  R2216     2.7607583999633789e-01
    z[3,4,5]  R2217     4.6119844913482666e-01
    z[3,4,5]  R2218     1.7270718514919281e-01
    z[3,4,5]  R2219     2.6913151144981384e-01
    z[3,4,5]  R2220     -3.3632940053939819e-01
    z[3,4,5]  R2221     -6.1255201697349548e-02
    z[3,4,5]  R2222     -1.2070265598595142e-02
    z[3,4,5]  R2223     -1.5667583048343658e-01
    z[3,4,5]  R2224     -1.0563275776803493e-02
    z[3,4,5]  R2225     2.7180045843124390e-01
    z[3,4,5]  R2226     -1.4757966622710228e-02
    z[3,4,5]  R2227     -3.0287897586822510e-01
    z[3,4,5]  R2228     1.5523275732994080e-01
    z[3,4,5]  R2229     -1.2730531394481659e-01
    z[3,4,5]  R2230     -2.3361420631408691e-01
    z[3,4,5]  R2231     -5.3906790912151337e-02
    z[3,4,5]  R2232     0.88450688123703
    z[3,4,5]  R2233     -2.3509602248668671e-01
    z[3,4,5]  R2234     6.0226183384656906e-02
    z[3,4,5]  R2235     -5.1337979733943939e-02
    z[3,4,5]  R2236     -1.9504806399345398e-01
    z[3,4,5]  R2237     -4.8167926073074341e-01
    z[3,4,5]  R2238     -3.6643886566162109e-01
    z[3,4,5]  R2239     -0.439810574054718
    z[3,4,5]  R2240     -0.342242568731308
    z[3,4,5]  R2241     -2.5903207063674927e-01
    z[3,4,5]  R2242     5.7846188545227051e-01
    z[3,4,5]  R2243     4.4787231087684631e-01
    z[3,4,5]  R2244     -3.3854490518569946e-01
    z[3,4,5]  R2245     -1.1588786542415619e-01
    z[3,4,5]  R2246     3.4957417845726013e-01
    z[3,4,5]  R2247     -2.5847530364990234e-01
    z[3,4,5]  R2248     1.7605029046535492e-01
    z[3,4,5]  R2249     1.0050392150878906e-01
    z[3,4,5]  R2250     -5.0245508551597595e-02
    z[3,4,5]  R2251     9.4093777239322662e-02
    z[3,4,5]  R2252     -4.1067236661911011e-01
    z[3,4,5]  R2253     -4.5013588666915894e-01
    z[3,4,5]  R2254     3.2189333438873291e-01
    z[3,4,5]  R2255     2.5142475962638855e-01
    z[3,4,5]  R2256     -0.837743878364563
    z[3,4,5]  R2257     2.1290406584739685e-01
    z[3,4,5]  R2258     2.7396622300148010e-01
    z[3,4,5]  R2259     3.4762862324714661e-01
    z[3,4,5]  R2260     1.4043180644512177e-01
    z[3,4,5]  R2261     -3.5550388693809509e-01
    z[3,4,5]  R2262     -2.1922864019870758e-01
    z[3,4,5]  R2263     -1.3864994049072266e-02
    z[3,4,5]  R2264     9.8382443189620972e-02
    z[3,4,5]  R2265     -3.9890626072883606e-01
    z[3,4,5]  R2266     2.2245287895202637e-01
    z[3,4,5]  R2267     -1.1194667965173721e-01
    z[3,4,5]  R2268     -0.370022714138031
    z[3,4,5]  R2269     0.0323251374065876
    z[3,4,5]  R2270     2.7211108803749084e-01
    z[3,4,5]  R2271     -3.1022295355796814e-01
    z[3,4,5]  R2272     3.7785702943801880e-01
    z[3,4,5]  R2273     1.9872845709323883e-01
    z[3,4,5]  R2274     2.5526142120361328e-01
    z[3,4,5]  R2275     2.6845550537109375e-01
    z[3,4,5]  R2276     1.2860564887523651e-01
    z[3,4,5]  R2277     2.4986462295055389e-01
    z[3,4,5]  R2278     -3.5493888426572084e-03
    z[3,4,5]  R2279     2.2794951498508453e-01
    z[3,4,5]  R2280     0.0433090478181839
    z[3,4,5]  R2281     2.3948150873184204e-01
    z[3,4,5]  R2282     5.0294625759124756e-01
    z[3,4,5]  R2283     -7.3644906282424927e-02
    z[3,4,5]  R2284     4.1580373048782349e-01
    z[3,4,5]  R2285     -7.5626122951507568e-01
    z[3,4,5]  R2286     -1.0397802293300629e-01
    z[3,4,5]  R2287     5.0789028406143188e-01
    z[3,4,5]  R2288     -5.9557819366455078e-01
    z[3,4,5]  R2289     2.0194037258625031e-01
    z[3,4,5]  R2290     -7.8010231256484985e-01
    z[3,4,5]  R2291     -1.3690859079360962e-01
    z[3,4,5]  R2292     1.3491770625114441e-01
    z[3,4,5]  R2293     -1.1217781901359558e-01
    z[3,4,5]  R2294     -3.0806851387023926e-01
    z[3,4,5]  R2295     5.2376675605773926e-01
    z[3,4,5]  R2296     -8.8750118017196655e-01
    z[3,4,5]  R2297     -0.826915442943573
    z[3,4,5]  R2298     6.7276149988174438e-01
    z[3,4,5]  R2299     2.2474014759063721e-01
    z[3,4,5]  R2300     3.0902171134948730e-01
    z[3,4,5]  R2301     1.7537845671176910e-01
    z[3,4,6]  R35       -1
    z[3,4,6]  R44       1
    z[3,4,6]  R2210     -1
    z[3,4,6]  R2211     1
    z[3,4,6]  R2212     -1.8461908400058746e-01
    z[3,4,6]  R2213     -1.6669057309627533e-01
    z[3,4,6]  R2214     3.5490524768829346e-01
    z[3,4,6]  R2215     -2.0352724194526672e-01
    z[3,4,6]  R2216     1.1936455219984055e-01
    z[3,4,6]  R2217     -2.6060926914215088e-01
    z[3,4,6]  R2218     1.7777577042579651e-01
    z[3,4,6]  R2219     1.3658711314201355e-01
    z[3,4,6]  R2220     -1.6236859560012817e-01
    z[3,4,6]  R2221     -6.8921104073524475e-02
    z[3,4,6]  R2222     -9.9029108881950378e-02
    z[3,4,6]  R2223     4.9343584105372429e-03
    z[3,4,6]  R2224     -8.1637494266033173e-02
    z[3,4,6]  R2225     3.4795474261045456e-02
    z[3,4,6]  R2226     -6.8906836211681366e-02
    z[3,4,6]  R2227     5.4065424948930740e-02
    z[3,4,6]  R2228     5.4115884006023407e-02
    z[3,4,6]  R2229     0.0679747611284256
    z[3,4,6]  R2230     1.3578702509403229e-01
    z[3,4,6]  R2231     2.6807633042335510e-01
    z[3,4,6]  R2232     7.1148246526718140e-02
    z[3,4,6]  R2233     -9.2562668025493622e-02
    z[3,4,6]  R2234     7.3835469782352448e-02
    z[3,4,6]  R2235     3.5258814692497253e-02
    z[3,4,6]  R2236     -7.1503028273582458e-02
    z[3,4,6]  R2237     9.9891006946563721e-02
    z[3,4,6]  R2238     -2.1038312464952469e-02
    z[3,4,6]  R2239     -1.5752756595611572e-01
    z[3,4,6]  R2240     6.8824617192149162e-03
    z[3,4,6]  R2241     -2.6545220613479614e-01
    z[3,4,6]  R2242     1.4137212932109833e-01
    z[3,4,6]  R2243     3.6631348729133606e-01
    z[3,4,6]  R2244     -8.2015588879585266e-02
    z[3,4,6]  R2245     -2.1970118582248688e-01
    z[3,4,6]  R2246     0.0908239483833313
    z[3,4,6]  R2247     -0.641921877861023
    z[3,4,6]  R2248     8.6049064993858337e-02
    z[3,4,6]  R2249     1.6886119544506073e-01
    z[3,4,6]  R2250     2.4283771216869354e-01
    z[3,4,6]  R2251     4.8933181911706924e-02
    z[3,4,6]  R2252     0.0592205636203289
    z[3,4,6]  R2253     2.4375896900892258e-02
    z[3,4,6]  R2254     -6.8199324607849121e-01
    z[3,4,6]  R2255     1.5630531311035156e-01
    z[3,4,6]  R2256     -2.6589466258883476e-02
    z[3,4,6]  R2257     -3.1645059585571289e-01
    z[3,4,6]  R2258     -1.6363418102264404e-01
    z[3,4,6]  R2259     1.8553754314780235e-02
    z[3,4,6]  R2260     3.1172606348991394e-01
    z[3,4,6]  R2261     -4.8182481527328491e-01
    z[3,4,6]  R2262     -3.8992151618003845e-01
    z[3,4,6]  R2263     8.6179308593273163e-02
    z[3,4,6]  R2264     0.301705539226532
    z[3,4,6]  R2265     0.00955789815634489
    z[3,4,6]  R2266     -1.8492631614208221e-01
    z[3,4,6]  R2267     -3.4744119644165039e-01
    z[3,4,6]  R2268     -3.4499862790107727e-01
    z[3,4,6]  R2269     4.4494986534118652e-01
    z[3,4,6]  R2270     -0.299773633480072
    z[3,4,6]  R2271     -7.2330847382545471e-02
    z[3,4,6]  R2272     4.8853579163551331e-01
    z[3,4,6]  R2273     -1.9156420603394508e-02
    z[3,4,6]  R2274     -0.0973849669098854
    z[3,4,6]  R2275     -4.6267926692962646e-02
    z[3,4,6]  R2276     1.5173251926898956e-01
    z[3,4,6]  R2277     -0.065963514149189
    z[3,4,6]  R2278     -0.0146268829703331
    z[3,4,6]  R2279     4.1553181409835815e-01
    z[3,4,6]  R2280     4.4460281729698181e-01
    z[3,4,6]  R2281     -0.0810999944806099
    z[3,4,6]  R2282     0.0471709668636322
    z[3,4,6]  R2283     3.6713933944702148e-01
    z[3,4,6]  R2284     5.4234504699707031e-01
    z[3,4,6]  R2285     -5.2987277507781982e-01
    z[3,4,6]  R2286     0.671161413192749
    z[3,4,6]  R2287     3.8942303508520126e-02
    z[3,4,6]  R2288     0.429162859916687
    z[3,4,6]  R2289     -3.7207847833633423e-01
    z[3,4,6]  R2290     -1.8802908062934875e-01
    z[3,4,6]  R2291     1.5293040312826633e-02
    z[3,4,6]  R2292     6.8283146619796753e-01
    z[3,4,6]  R2293     4.6395670622587204e-02
    z[3,4,6]  R2294     -5.4667526483535767e-01
    z[3,4,6]  R2295     -0.588240921497345
    z[3,4,6]  R2296     -1.2923638522624969e-01
    z[3,4,6]  R2297     -7.4335299432277679e-03
    z[3,4,6]  R2298     -2.7590328827500343e-02
    z[3,4,6]  R2299     3.6730885505676270e-02
    z[3,4,6]  R2300     -2.9367044568061829e-01
    z[3,4,6]  R2301     2.2171714901924133e-01
    z[4,3,0]  R29       1
    z[4,3,0]  R38       -1
    z[4,3,0]  R2302     -1
    z[4,3,0]  R2303     1
    z[4,3,0]  R2316     7.2173547744750977e-01
    z[4,3,0]  R2317     -2.6034882664680481e-01
    z[4,3,0]  R2318     -8.8026374578475952e-02
    z[4,3,0]  R2319     7.0207589864730835e-01
    z[4,3,0]  R2320     1.3437853753566742e-01
    z[4,3,0]  R2321     6.1883461475372314e-01
    z[4,3,0]  R2322     5.5191999673843384e-01
    z[4,3,0]  R2323     5.7589358091354370e-01
    z[4,3,0]  R2324     1.9529409706592560e-01
    z[4,3,0]  R2325     8.8348609209060669e-01
    z[4,3,0]  R2326     0.498344749212265
    z[4,3,0]  R2327     -5.7064223289489746e-01
    z[4,3,0]  R2328     -3.8162621855735779e-01
    z[4,3,0]  R2329     -5.8480417728424072e-01
    z[4,3,0]  R2330     -4.7194001078605652e-01
    z[4,3,0]  R2331     -4.4435703754425049e-01
    z[4,3,0]  R2332     -4.1637751460075378e-01
    z[4,3,0]  R2333     -4.7644710540771484e-01
    z[4,3,0]  R2334     -6.2589657306671143e-01
    z[4,3,0]  R2335     -3.0824321508407593e-01
    z[4,3,0]  R2336     6.4118367433547974e-01
    z[4,3,0]  R2337     5.4827427864074707e-01
    z[4,3,0]  R2338     3.2010135054588318e-01
    z[4,3,0]  R2339     1.3908789493143559e-02
    z[4,3,0]  R2340     3.6178115010261536e-01
    z[4,3,0]  R2341     3.5426384210586548e-01
    z[4,3,0]  R2342     3.4391263127326965e-01
    z[4,3,0]  R2343     -3.3993339538574219e-01
    z[4,3,0]  R2344     -0.0794341191649437
    z[4,3,0]  R2345     -1.8189454078674316e-01
    z[4,3,0]  R2346     6.8536871671676636e-01
    z[4,3,0]  R2347     6.1935573816299438e-01
    z[4,3,0]  R2348     -4.0746080875396729e-01
    z[4,3,0]  R2349     4.1207635402679443e-01
    z[4,3,0]  R2350     -3.0557766556739807e-02
    z[4,3,0]  R2351     1.9815362989902496e-01
    z[4,3,0]  R2352     -1.0177161544561386e-01
    z[4,3,0]  R2353     -3.2355093955993652e-01
    z[4,3,0]  R2354     -3.2967633008956909e-01
    z[4,3,0]  R2355     -5.7720702886581421e-01
    z[4,3,0]  R2356     -5.7539260387420654e-01
    z[4,3,0]  R2357     -4.6624532341957092e-01
    z[4,3,0]  R2358     -5.0899642705917358e-01
    z[4,3,0]  R2359     -1.2014885246753693e-01
    z[4,3,0]  R2360     -5.0082010030746460e-01
    z[4,3,0]  R2361     5.9517875313758850e-02
    z[4,3,0]  R2362     -1.1326623708009720e-01
    z[4,3,0]  R2363     1.3849098980426788e-01
    z[4,3,0]  R2364     4.2004132270812988e-01
    z[4,3,0]  R2365     1.9014729559421539e-01
    z[4,3,0]  R2366     5.7204455137252808e-01
    z[4,3,0]  R2367     0.572113037109375
    z[4,3,0]  R2368     5.7787096500396729e-01
    z[4,3,0]  R2369     5.3382194042205811e-01
    z[4,3,0]  R2370     1.7811340093612671e-01
    z[4,3,0]  R2371     5.7484441995620728e-01
    z[4,3,0]  R2372     0.334280788898468
    z[4,3,0]  R2373     5.1705837249755859e-02
    z[4,3,0]  R2374     3.4049415588378906e-01
    z[4,3,0]  R2375     6.3084119558334351e-01
    z[4,3,0]  R2376     9.9886313080787659e-02
    z[4,3,0]  R2377     0.684758722782135
    z[4,3,0]  R2378     5.9450703859329224e-01
    z[4,3,0]  R2379     5.3604131937026978e-01
    z[4,3,0]  R2380     5.7761001586914062e-01
    z[4,3,0]  R2381     5.9616720676422119e-01
    z[4,3,0]  R2382     5.5288159847259521e-01
    z[4,3,0]  R2383     6.0106503963470459e-01
    z[4,3,0]  R2384     4.5466482639312744e-01
    z[4,3,0]  R2385     6.2489295005798340e-01
    z[4,3,0]  R2386     -4.3019089847803116e-02
    z[4,3,0]  R2387     -4.8385281115770340e-02
    z[4,3,0]  R2388     -5.2565336227416992e-01
    z[4,3,0]  R2389     -1.6974531114101410e-01
    z[4,3,0]  R2390     7.1861910820007324e-01
    z[4,3,0]  R2391     -4.3361854553222656e-01
    z[4,3,0]  R2392     -5.8581691980361938e-01
    z[4,3,0]  R2393     -8.2092887163162231e-01
    z[4,3,0]  R2394     -7.8789454698562622e-01
    z[4,3,0]  R2395     -7.9566174745559692e-01
    z[4,3,0]  R2396     9.5633447170257568e-02
    z[4,3,0]  R2397     7.3859155178070068e-02
    z[4,3,0]  R2398     1.6299448907375336e-01
    z[4,3,0]  R2399     -0.557685136795044
    z[4,3,0]  R2400     -2.3144088685512543e-01
    z[4,3,0]  R2401     8.0284041166305542e-01
    z[4,3,0]  R2402     -0.42790487408638
    z[4,3,0]  R2403     -4.4375672936439514e-01
    z[4,3,0]  R2404     -1.8512088805437088e-02
    z[4,3,0]  R2405     3.3699741959571838e-01
    z[4,3,1]  R30       1
    z[4,3,1]  R39       -1
    z[4,3,1]  R2304     -1
    z[4,3,1]  R2305     1
    z[4,3,1]  R2316     4.7464835643768311e-01
    z[4,3,1]  R2317     -3.7263244390487671e-01
    z[4,3,1]  R2318     -5.8896821737289429e-01
    z[4,3,1]  R2319     5.5480856448411942e-02
    z[4,3,1]  R2320     -0.356360524892807
    z[4,3,1]  R2321     -2.9439383745193481e-01
    z[4,3,1]  R2322     -3.9077866077423096e-01
    z[4,3,1]  R2323     4.5883551239967346e-01
    z[4,3,1]  R2324     -2.5890287756919861e-01
    z[4,3,1]  R2325     1.8817149102687836e-01
    z[4,3,1]  R2326     -3.1648527830839157e-02
    z[4,3,1]  R2327     4.7781169414520264e-01
    z[4,3,1]  R2328     4.4560694694519043e-01
    z[4,3,1]  R2329     5.7730001211166382e-01
    z[4,3,1]  R2330     3.6223095655441284e-01
    z[4,3,1]  R2331     4.5222055912017822e-01
    z[4,3,1]  R2332     5.4885065555572510e-01
    z[4,3,1]  R2333     5.3115218877792358e-01
    z[4,3,1]  R2334     5.1203662157058716e-01
    z[4,3,1]  R2335     -3.8567224144935608e-01
    z[4,3,1]  R2336     -4.6898555010557175e-02
    z[4,3,1]  R2337     1.9691698253154755e-01
    z[4,3,1]  R2338     -3.3078789710998535e-01
    z[4,3,1]  R2339     -2.5322714447975159e-01
    z[4,3,1]  R2340     -0.521737277507782
    z[4,3,1]  R2341     2.8693714737892151e-01
    z[4,3,1]  R2342     -4.4296371936798096e-01
    z[4,3,1]  R2343     -6.5261906385421753e-01
    z[4,3,1]  R2344     5.0646450370550156e-02
    z[4,3,1]  R2345     -8.7560421228408813e-01
    z[4,3,1]  R2346     8.7547548115253448e-02
    z[4,3,1]  R2347     -5.1780784130096436e-01
    z[4,3,1]  R2348     -5.1614469289779663e-01
    z[4,3,1]  R2349     -1.3408043980598450e-01
    z[4,3,1]  R2350     -1.9141638278961182e-01
    z[4,3,1]  R2351     5.2375458180904388e-02
    z[4,3,1]  R2352     1.0893474519252777e-01
    z[4,3,1]  R2353     -1.1364394426345825e-01
    z[4,3,1]  R2354     -2.2669158875942230e-01
    z[4,3,1]  R2355     -0.592122495174408
    z[4,3,1]  R2356     5.3784084320068359e-01
    z[4,3,1]  R2357     4.0997806191444397e-01
    z[4,3,1]  R2358     3.5884803533554077e-01
    z[4,3,1]  R2359     6.3315761089324951e-01
    z[4,3,1]  R2360     6.0678112506866455e-01
    z[4,3,1]  R2361     1.5981715917587280e-01
    z[4,3,1]  R2362     -6.0067433118820190e-01
    z[4,3,1]  R2363     -5.6848269701004028e-01
    z[4,3,1]  R2364     -6.1022669076919556e-01
    z[4,3,1]  R2365     -4.7365039587020874e-01
    z[4,3,1]  R2366     -7.7890610694885254e-01
    z[4,3,1]  R2367     -0.734073281288147
    z[4,3,1]  R2368     -7.1233463287353516e-01
    z[4,3,1]  R2369     -7.4874430894851685e-01
    z[4,3,1]  R2370     -8.8062816858291626e-01
    z[4,3,1]  R2371     -7.2288483381271362e-01
    z[4,3,1]  R2372     -8.5410809516906738e-01
    z[4,3,1]  R2373     -8.4017670154571533e-01
    z[4,3,1]  R2374     -8.2712328433990479e-01
    z[4,3,1]  R2375     -6.3271623849868774e-01
    z[4,3,1]  R2376     -2.8168407082557678e-01
    z[4,3,1]  R2377     4.9736425280570984e-01
    z[4,3,1]  R2378     4.9484935402870178e-01
    z[4,3,1]  R2379     5.2616351842880249e-01
    z[4,3,1]  R2380     4.0387737751007080e-01
    z[4,3,1]  R2381     3.4215039014816284e-01
    z[4,3,1]  R2382     5.1828610897064209e-01
    z[4,3,1]  R2383     3.5125705599784851e-01
    z[4,3,1]  R2384     4.8839551210403442e-01
    z[4,3,1]  R2385     3.7105610966682434e-01
    z[4,3,1]  R2386     3.2518428564071655e-01
    z[4,3,1]  R2387     -1.1943493038415909e-01
    z[4,3,1]  R2388     -4.5852270722389221e-01
    z[4,3,1]  R2389     -4.6201723814010620e-01
    z[4,3,1]  R2390     3.0634099245071411e-01
    z[4,3,1]  R2391     -3.5620772838592529e-01
    z[4,3,1]  R2392     -5.4595535993576050e-01
    z[4,3,1]  R2393     -0.424570769071579
    z[4,3,1]  R2394     -0.507512629032135
    z[4,3,1]  R2395     -5.1523089408874512e-01
    z[4,3,1]  R2396     -1.7358395457267761e-01
    z[4,3,1]  R2397     -6.7534017562866211e-01
    z[4,3,1]  R2398     -5.6824922561645508e-01
    z[4,3,1]  R2399     -7.2195613384246826e-01
    z[4,3,1]  R2400     -2.6490309834480286e-01
    z[4,3,1]  R2401     3.6142560839653015e-01
    z[4,3,1]  R2402     -2.9764235019683838e-01
    z[4,3,1]  R2403     -0.304245263338089
    z[4,3,1]  R2404     -2.3560518398880959e-02
    z[4,3,1]  R2405     3.8852196931838989e-01
    z[4,3,2]  R31       1
    z[4,3,2]  R40       -1
    z[4,3,2]  R2306     -1
    z[4,3,2]  R2307     1
    z[4,3,2]  R2316     2.0658016204833984e-01
    z[4,3,2]  R2317     5.1609843969345093e-01
    z[4,3,2]  R2318     6.4757645130157471e-01
    z[4,3,2]  R2319     9.8929800093173981e-02
    z[4,3,2]  R2320     5.5037707090377808e-01
    z[4,3,2]  R2321     1.7464052140712738e-01
    z[4,3,2]  R2322     -2.3853220045566559e-01
    z[4,3,2]  R2323     5.0685471296310425e-01
    z[4,3,2]  R2324     2.4018318951129913e-01
    z[4,3,2]  R2325     9.5787599682807922e-02
    z[4,3,2]  R2326     -5.3479593992233276e-01
    z[4,3,2]  R2327     -5.9657585620880127e-01
    z[4,3,2]  R2328     -7.1719348430633545e-01
    z[4,3,2]  R2329     -4.3153610825538635e-01
    z[4,3,2]  R2330     -6.7312496900558472e-01
    z[4,3,2]  R2331     -6.3912689685821533e-01
    z[4,3,2]  R2332     -6.0853153467178345e-01
    z[4,3,2]  R2333     -4.1915518045425415e-01
    z[4,3,2]  R2334     -3.3209469914436340e-01
    z[4,3,2]  R2335     -8.0496203899383545e-01
    z[4,3,2]  R2336     -4.6399781107902527e-01
    z[4,3,2]  R2337     -5.1879197359085083e-01
    z[4,3,2]  R2338     -4.1803181171417236e-01
    z[4,3,2]  R2339     1.7579983174800873e-01
    z[4,3,2]  R2340     -2.2754608094692230e-01
    z[4,3,2]  R2341     -2.3996305465698242e-01
    z[4,3,2]  R2342     1.5741537511348724e-01
    z[4,3,2]  R2343     -4.3415728211402893e-01
    z[4,3,2]  R2344     0.576196551322937
    z[4,3,2]  R2345     -4.0394324064254761e-01
    z[4,3,2]  R2346     -0.0334198921918869
    z[4,3,2]  R2347     1.4081464707851410e-01
    z[4,3,2]  R2348     1.9569399952888489e-01
    z[4,3,2]  R2349     1.2754398584365845e-01
    z[4,3,2]  R2350     3.7761977314949036e-01
    z[4,3,2]  R2351     0.517429530620575
    z[4,3,2]  R2352     7.9806648194789886e-02
    z[4,3,2]  R2353     -7.7853941917419434e-01
    z[4,3,2]  R2354     -7.5481927394866943e-01
    z[4,3,2]  R2355     -3.2312935590744019e-01
    z[4,3,2]  R2356     -3.1495407223701477e-01
    z[4,3,2]  R2357     -2.7223592996597290e-01
    z[4,3,2]  R2358     1.9476598501205444e-01
    z[4,3,2]  R2359     -3.0419480800628662e-01
    z[4,3,2]  R2360     4.5412972569465637e-02
    z[4,3,2]  R2361     -4.4046494364738464e-01
    z[4,3,2]  R2362     5.1188701391220093e-01
    z[4,3,2]  R2363     6.8993842601776123e-01
    z[4,3,2]  R2364     5.3733807802200317e-01
    z[4,3,2]  R2365     7.7381551265716553e-01
    z[4,3,2]  R2366     -1.6695824265480042e-01
    z[4,3,2]  R2367     -1.0524638742208481e-01
    z[4,3,2]  R2368     -2.3312093317508698e-01
    z[4,3,2]  R2369     -9.8969843238592148e-03
    z[4,3,2]  R2370     -3.2058599591255188e-01
    z[4,3,2]  R2371     -7.9349176958203316e-03
    z[4,3,2]  R2372     -1.4685305953025818e-01
    z[4,3,2]  R2373     -2.5821053981781006e-01
    z[4,3,2]  R2374     -4.5450992882251740e-02
    z[4,3,2]  R2375     3.5034954547882080e-01
    z[4,3,2]  R2376     -1.6533946618437767e-02
    z[4,3,2]  R2377     -1.4327681064605713e-01
    z[4,3,2]  R2378     -1.1226122081279755e-01
    z[4,3,2]  R2379     -1.1739084869623184e-01
    z[4,3,2]  R2380     1.3021047413349152e-01
    z[4,3,2]  R2381     -6.5592072904109955e-02
    z[4,3,2]  R2382     1.4451918005943298e-01
    z[4,3,2]  R2383     2.1304875612258911e-01
    z[4,3,2]  R2384     1.1093472689390182e-01
    z[4,3,2]  R2385     -6.2649093568325043e-02
    z[4,3,2]  R2386     0.0575115866959095
    z[4,3,2]  R2387     2.1006904542446136e-01
    z[4,3,2]  R2388     -2.1441720426082611e-01
    z[4,3,2]  R2389     -2.3992931842803955e-01
    z[4,3,2]  R2390     3.1207486987113953e-01
    z[4,3,2]  R2391     3.0928462743759155e-02
    z[4,3,2]  R2392     -0.0356932133436203
    z[4,3,2]  R2393     -1.3485740125179291e-01
    z[4,3,2]  R2394     -1.8079439178109169e-02
    z[4,3,2]  R2395     -2.6221296191215515e-01
    z[4,3,2]  R2396     -2.2966243326663971e-01
    z[4,3,2]  R2397     -7.7399136498570442e-03
    z[4,3,2]  R2398     2.4974639713764191e-01
    z[4,3,2]  R2399     -6.7057803273200989e-02
    z[4,3,2]  R2400     1.5775233507156372e-01
    z[4,3,2]  R2401     -8.3998069167137146e-03
    z[4,3,2]  R2402     -2.7235758304595947e-01
    z[4,3,2]  R2403     -9.1737903654575348e-02
    z[4,3,2]  R2404     5.3540718555450439e-01
    z[4,3,2]  R2405     0.501573920249939
    z[4,3,3]  R32       1
    z[4,3,3]  R41       -1
    z[4,3,3]  R2308     -1
    z[4,3,3]  R2309     1
    z[4,3,3]  R2316     8.6531199514865875e-02
    z[4,3,3]  R2317     -5.8207309246063232e-01
    z[4,3,3]  R2318     -3.2332116365432739e-01
    z[4,3,3]  R2319     -1.1367462575435638e-01
    z[4,3,3]  R2320     -5.6814730167388916e-01
    z[4,3,3]  R2321     -3.3525720238685608e-01
    z[4,3,3]  R2322     -1.4600183814764023e-02
    z[4,3,3]  R2323     1.4067446812987328e-02
    z[4,3,3]  R2324     -8.1641548871994019e-01
    z[4,3,3]  R2325     -2.7022278308868408e-01
    z[4,3,3]  R2326     2.8645089268684387e-01
    z[4,3,3]  R2327     2.1356928348541260e-01
    z[4,3,3]  R2328     2.5227975845336914e-01
    z[4,3,3]  R2329     2.4058888852596283e-01
    z[4,3,3]  R2330     3.8215324282646179e-01
    z[4,3,3]  R2331     2.8521296381950378e-01
    z[4,3,3]  R2332     3.2522711157798767e-01
    z[4,3,3]  R2333     1.5950119495391846e-01
    z[4,3,3]  R2334     1.9036103785037994e-01
    z[4,3,3]  R2335     1.2890487909317017e-01
    z[4,3,3]  R2336     -3.3502274751663208e-01
    z[4,3,3]  R2337     5.0122457742691040e-01
    z[4,3,3]  R2338     3.6730784177780151e-01
    z[4,3,3]  R2339     -1.6924814879894257e-01
    z[4,3,3]  R2340     0.257690966129303
    z[4,3,3]  R2341     2.8943282365798950e-01
    z[4,3,3]  R2342     3.2569810282438993e-03
    z[4,3,3]  R2343     -3.0136129260063171e-01
    z[4,3,3]  R2344     7.9324334859848022e-02
    z[4,3,3]  R2345     -5.9938136488199234e-02
    z[4,3,3]  R2346     1.2918472290039062e-01
    z[4,3,3]  R2347     -5.5456644296646118e-01
    z[4,3,3]  R2348     -3.4559625387191772e-01
    z[4,3,3]  R2349     4.1245266795158386e-01
    z[4,3,3]  R2350     2.6273833587765694e-02
    z[4,3,3]  R2351     0.0676998421549797
    z[4,3,3]  R2352     3.5153287649154663e-01
    z[4,3,3]  R2353     4.7362190485000610e-01
    z[4,3,3]  R2354     2.2187928855419159e-01
    z[4,3,3]  R2355     3.4765559434890747e-01
    z[4,3,3]  R2356     3.4320011734962463e-01
    z[4,3,3]  R2357     3.5711315274238586e-01
    z[4,3,3]  R2358     6.5942478179931641e-01
    z[4,3,3]  R2359     5.9538805484771729e-01
    z[4,3,3]  R2360     3.4576657414436340e-01
    z[4,3,3]  R2361     7.0035117864608765e-01
    z[4,3,3]  R2362     -0.530301034450531
    z[4,3,3]  R2363     -2.6191276311874390e-01
    z[4,3,3]  R2364     -3.3637505024671555e-02
    z[4,3,3]  R2365     -3.3186116814613342e-01
    z[4,3,3]  R2366     -7.4687272310256958e-02
    z[4,3,3]  R2367     1.0632331669330597e-01
    z[4,3,3]  R2368     2.7038154006004333e-01
    z[4,3,3]  R2369     1.2183093279600143e-01
    z[4,3,3]  R2370     3.7542287260293961e-02
    z[4,3,3]  R2371     1.1555763334035873e-01
    z[4,3,3]  R2372     2.9953292012214661e-01
    z[4,3,3]  R2373     4.1325652599334717e-01
    z[4,3,3]  R2374     2.7058649063110352e-01
    z[4,3,3]  R2375     -4.5007247477769852e-02
    z[4,3,3]  R2376     3.1242930889129639e-01
    z[4,3,3]  R2377     -0.39503213763237
    z[4,3,3]  R2378     -5.6164044141769409e-01
    z[4,3,3]  R2379     -5.4107069969177246e-01
    z[4,3,3]  R2380     -6.1921846866607666e-01
    z[4,3,3]  R2381     -5.1277482509613037e-01
    z[4,3,3]  R2382     -4.6367436647415161e-01
    z[4,3,3]  R2383     -4.8262152075767517e-01
    z[4,3,3]  R2384     -6.2656527757644653e-01
    z[4,3,3]  R2385     -4.8673585057258606e-01
    z[4,3,3]  R2386     7.2669649124145508e-01
    z[4,3,3]  R2387     0.762295126914978
    z[4,3,3]  R2388     -5.7686185836791992e-01
    z[4,3,3]  R2389     -5.2052670717239380e-01
    z[4,3,3]  R2390     -3.6024487018585205e-01
    z[4,3,3]  R2391     -4.5294648408889771e-01
    z[4,3,3]  R2392     -4.4176250696182251e-01
    z[4,3,3]  R2393     -1.0698555409908295e-01
    z[4,3,3]  R2394     -2.1624748408794403e-01
    z[4,3,3]  R2395     -1.4532610774040222e-01
    z[4,3,3]  R2396     8.5010147094726562e-01
    z[4,3,3]  R2397     -5.5896854400634766e-01
    z[4,3,3]  R2398     -5.5401455610990524e-02
    z[4,3,3]  R2399     -2.5027725100517273e-01
    z[4,3,3]  R2400     -3.6608001589775085e-01
    z[4,3,3]  R2401     -2.4820853024721146e-02
    z[4,3,3]  R2402     -5.3497594594955444e-01
    z[4,3,3]  R2403     -4.3160125613212585e-01
    z[4,3,3]  R2404     -2.8032356500625610e-01
    z[4,3,3]  R2405     3.5390022397041321e-01
    z[4,3,4]  R33       1
    z[4,3,4]  R42       -1
    z[4,3,4]  R2310     -1
    z[4,3,4]  R2311     1
    z[4,3,4]  R2316     -5.9527806937694550e-02
    z[4,3,4]  R2317     -4.2494454979896545e-01
    z[4,3,4]  R2318     1.4411987364292145e-01
    z[4,3,4]  R2319     -5.6752490997314453e-01
    z[4,3,4]  R2320     0.381523460149765
    z[4,3,4]  R2321     5.0421410799026489e-01
    z[4,3,4]  R2322     4.7919169068336487e-01
    z[4,3,4]  R2323     4.1130978614091873e-02
    z[4,3,4]  R2324     -8.1844948232173920e-02
    z[4,3,4]  R2325     -1.9448215141892433e-02
    z[4,3,4]  R2326     3.3866535872220993e-02
    z[4,3,4]  R2327     6.8474814295768738e-02
    z[4,3,4]  R2328     5.6055169552564621e-02
    z[4,3,4]  R2329     -8.0082856118679047e-02
    z[4,3,4]  R2330     -8.5795380175113678e-02
    z[4,3,4]  R2331     -2.0354405045509338e-01
    z[4,3,4]  R2332     -2.2154681384563446e-01
    z[4,3,4]  R2333     -2.5517880916595459e-01
    z[4,3,4]  R2334     5.2798591786995530e-04
    z[4,3,4]  R2335     -1.6653573513031006e-01
    z[4,3,4]  R2336     -0.0630049929022789
    z[4,3,4]  R2337     5.7364720851182938e-03
    z[4,3,4]  R2338     1.0685495287179947e-01
    z[4,3,4]  R2339     -1.5308807790279388e-01
    z[4,3,4]  R2340     -1.3211238384246826e-01
    z[4,3,4]  R2341     6.2557297945022583e-01
    z[4,3,4]  R2342     -0.349031537771225
    z[4,3,4]  R2343     3.6674781586043537e-04
    z[4,3,4]  R2344     9.4423428177833557e-02
    z[4,3,4]  R2345     -1.2037818878889084e-01
    z[4,3,4]  R2346     -1.4261111617088318e-01
    z[4,3,4]  R2347     -7.8513838350772858e-02
    z[4,3,4]  R2348     1.2679681181907654e-01
    z[4,3,4]  R2349     7.3971919715404510e-02
    z[4,3,4]  R2350     -1.2156744301319122e-01
    z[4,3,4]  R2351     -4.2790338397026062e-02
    z[4,3,4]  R2352     6.2806212902069092e-01
    z[4,3,4]  R2353     1.0061531327664852e-02
    z[4,3,4]  R2354     1.9800265133380890e-01
    z[4,3,4]  R2355     1.0502353310585022e-01
    z[4,3,4]  R2356     1.5212135016918182e-01
    z[4,3,4]  R2357     6.0544836521148682e-01
    z[4,3,4]  R2358     1.1388329416513443e-01
    z[4,3,4]  R2359     -2.4923862516880035e-01
    z[4,3,4]  R2360     -4.1099062561988831e-01
    z[4,3,4]  R2361     7.6116546988487244e-02
    z[4,3,4]  R2362     -1.4724639058113098e-01
    z[4,3,4]  R2363     -1.4814375340938568e-01
    z[4,3,4]  R2364     1.4779733121395111e-01
    z[4,3,4]  R2365     -1.4857585728168488e-01
    z[4,3,4]  R2366     -1.5054804086685181e-01
    z[4,3,4]  R2367     -2.9473719000816345e-01
    z[4,3,4]  R2368     -0.156258225440979
    z[4,3,4]  R2369     2.5375029444694519e-01
    z[4,3,4]  R2370     -2.8916954994201660e-01
    z[4,3,4]  R2371     1.9727160036563873e-01
    z[4,3,4]  R2372     1.4298303425312042e-01
    z[4,3,4]  R2373     1.8206825852394104e-01
    z[4,3,4]  R2374     2.2723200917243958e-01
    z[4,3,4]  R2375     4.6563889831304550e-02
    z[4,3,4]  R2376     -1.5930096805095673e-01
    z[4,3,4]  R2377     -2.0812867581844330e-01
    z[4,3,4]  R2378     -2.5409471988677979e-01
    z[4,3,4]  R2379     -3.5411116480827332e-01
    z[4,3,4]  R2380     -2.4435031414031982e-01
    z[4,3,4]  R2381     -1.3521975278854370e-01
    z[4,3,4]  R2382     2.3473742604255676e-01
    z[4,3,4]  R2383     1.3703167438507080e-01
    z[4,3,4]  R2384     1.8078124523162842e-01
    z[4,3,4]  R2385     3.0565834045410156e-01
    z[4,3,4]  R2386     -0.0800301805138588
    z[4,3,4]  R2387     1.5295787155628204e-01
    z[4,3,4]  R2388     1.1559443175792694e-01
    z[4,3,4]  R2389     6.0622924566268921e-01
    z[4,3,4]  R2390     0.179230198264122
    z[4,3,4]  R2391     -1.0031496174633503e-02
    z[4,3,4]  R2392     3.5202977061271667e-01
    z[4,3,4]  R2393     -2.7851012349128723e-01
    z[4,3,4]  R2394     -1.1431746929883957e-01
    z[4,3,4]  R2395     1.8334053456783295e-02
    z[4,3,4]  R2396     1.1465849727392197e-01
    z[4,3,4]  R2397     -1.5079215168952942e-01
    z[4,3,4]  R2398     1.2787835299968719e-01
    z[4,3,4]  R2399     1.1395392566919327e-01
    z[4,3,4]  R2400     -1.2181679904460907e-01
    z[4,3,4]  R2401     2.8046944737434387e-01
    z[4,3,4]  R2402     -5.1584386825561523e-01
    z[4,3,4]  R2403     -6.2819540500640869e-01
    z[4,3,4]  R2404     7.1900326013565063e-01
    z[4,3,4]  R2405     1.1113435961306095e-02
    z[4,3,5]  R34       1
    z[4,3,5]  R43       -1
    z[4,3,5]  R2312     -1
    z[4,3,5]  R2313     1
    z[4,3,5]  R2316     -2.1922864019870758e-01
    z[4,3,5]  R2317     -1.3864994049072266e-02
    z[4,3,5]  R2318     9.8382443189620972e-02
    z[4,3,5]  R2319     -3.9890626072883606e-01
    z[4,3,5]  R2320     2.2245287895202637e-01
    z[4,3,5]  R2321     -1.1194667965173721e-01
    z[4,3,5]  R2322     -0.370022714138031
    z[4,3,5]  R2323     0.0323251374065876
    z[4,3,5]  R2324     2.7211108803749084e-01
    z[4,3,5]  R2325     -3.1022295355796814e-01
    z[4,3,5]  R2326     3.7785702943801880e-01
    z[4,3,5]  R2327     1.9872845709323883e-01
    z[4,3,5]  R2328     2.5526142120361328e-01
    z[4,3,5]  R2329     2.6845550537109375e-01
    z[4,3,5]  R2330     1.2860564887523651e-01
    z[4,3,5]  R2331     2.4986462295055389e-01
    z[4,3,5]  R2332     -3.5493888426572084e-03
    z[4,3,5]  R2333     2.2794951498508453e-01
    z[4,3,5]  R2334     0.0433090478181839
    z[4,3,5]  R2335     2.3948150873184204e-01
    z[4,3,5]  R2336     5.0294625759124756e-01
    z[4,3,5]  R2337     -7.3644906282424927e-02
    z[4,3,5]  R2338     4.1580373048782349e-01
    z[4,3,5]  R2339     -7.5626122951507568e-01
    z[4,3,5]  R2340     -1.0397802293300629e-01
    z[4,3,5]  R2341     5.0789028406143188e-01
    z[4,3,5]  R2342     -5.9557819366455078e-01
    z[4,3,5]  R2343     2.0194037258625031e-01
    z[4,3,5]  R2344     -7.8010231256484985e-01
    z[4,3,5]  R2345     -1.3690859079360962e-01
    z[4,3,5]  R2346     1.3491770625114441e-01
    z[4,3,5]  R2347     -1.1217781901359558e-01
    z[4,3,5]  R2348     -3.0806851387023926e-01
    z[4,3,5]  R2349     5.2376675605773926e-01
    z[4,3,5]  R2350     -8.8750118017196655e-01
    z[4,3,5]  R2351     -0.826915442943573
    z[4,3,5]  R2352     6.7276149988174438e-01
    z[4,3,5]  R2353     2.2474014759063721e-01
    z[4,3,5]  R2354     3.0902171134948730e-01
    z[4,3,5]  R2355     1.7537845671176910e-01
    z[4,3,5]  R2356     3.2471993565559387e-01
    z[4,3,5]  R2357     1.3615280389785767e-01
    z[4,3,5]  R2358     -2.1183695644140244e-02
    z[4,3,5]  R2359     1.8469187617301941e-01
    z[4,3,5]  R2360     2.7607583999633789e-01
    z[4,3,5]  R2361     4.6119844913482666e-01
    z[4,3,5]  R2362     1.7270718514919281e-01
    z[4,3,5]  R2363     2.6913151144981384e-01
    z[4,3,5]  R2364     -3.3632940053939819e-01
    z[4,3,5]  R2365     -6.1255201697349548e-02
    z[4,3,5]  R2366     -1.2070265598595142e-02
    z[4,3,5]  R2367     -1.5667583048343658e-01
    z[4,3,5]  R2368     -1.0563275776803493e-02
    z[4,3,5]  R2369     2.7180045843124390e-01
    z[4,3,5]  R2370     -1.4757966622710228e-02
    z[4,3,5]  R2371     -3.0287897586822510e-01
    z[4,3,5]  R2372     1.5523275732994080e-01
    z[4,3,5]  R2373     -1.2730531394481659e-01
    z[4,3,5]  R2374     -2.3361420631408691e-01
    z[4,3,5]  R2375     -5.3906790912151337e-02
    z[4,3,5]  R2376     0.88450688123703
    z[4,3,5]  R2377     -2.3509602248668671e-01
    z[4,3,5]  R2378     6.0226183384656906e-02
    z[4,3,5]  R2379     -5.1337979733943939e-02
    z[4,3,5]  R2380     -1.9504806399345398e-01
    z[4,3,5]  R2381     -4.8167926073074341e-01
    z[4,3,5]  R2382     -3.6643886566162109e-01
    z[4,3,5]  R2383     -0.439810574054718
    z[4,3,5]  R2384     -0.342242568731308
    z[4,3,5]  R2385     -2.5903207063674927e-01
    z[4,3,5]  R2386     5.7846188545227051e-01
    z[4,3,5]  R2387     4.4787231087684631e-01
    z[4,3,5]  R2388     -3.3854490518569946e-01
    z[4,3,5]  R2389     -1.1588786542415619e-01
    z[4,3,5]  R2390     3.4957417845726013e-01
    z[4,3,5]  R2391     -2.5847530364990234e-01
    z[4,3,5]  R2392     1.7605029046535492e-01
    z[4,3,5]  R2393     1.0050392150878906e-01
    z[4,3,5]  R2394     -5.0245508551597595e-02
    z[4,3,5]  R2395     9.4093777239322662e-02
    z[4,3,5]  R2396     -4.1067236661911011e-01
    z[4,3,5]  R2397     -4.5013588666915894e-01
    z[4,3,5]  R2398     3.2189333438873291e-01
    z[4,3,5]  R2399     2.5142475962638855e-01
    z[4,3,5]  R2400     -0.837743878364563
    z[4,3,5]  R2401     2.1290406584739685e-01
    z[4,3,5]  R2402     2.7396622300148010e-01
    z[4,3,5]  R2403     3.4762862324714661e-01
    z[4,3,5]  R2404     1.4043180644512177e-01
    z[4,3,5]  R2405     -3.5550388693809509e-01
    z[4,3,6]  R35       1
    z[4,3,6]  R44       -1
    z[4,3,6]  R2314     -1
    z[4,3,6]  R2315     1
    z[4,3,6]  R2316     -3.8992151618003845e-01
    z[4,3,6]  R2317     8.6179308593273163e-02
    z[4,3,6]  R2318     0.301705539226532
    z[4,3,6]  R2319     0.00955789815634489
    z[4,3,6]  R2320     -1.8492631614208221e-01
    z[4,3,6]  R2321     -3.4744119644165039e-01
    z[4,3,6]  R2322     -3.4499862790107727e-01
    z[4,3,6]  R2323     4.4494986534118652e-01
    z[4,3,6]  R2324     -0.299773633480072
    z[4,3,6]  R2325     -7.2330847382545471e-02
    z[4,3,6]  R2326     4.8853579163551331e-01
    z[4,3,6]  R2327     -1.9156420603394508e-02
    z[4,3,6]  R2328     -0.0973849669098854
    z[4,3,6]  R2329     -4.6267926692962646e-02
    z[4,3,6]  R2330     1.5173251926898956e-01
    z[4,3,6]  R2331     -0.065963514149189
    z[4,3,6]  R2332     -0.0146268829703331
    z[4,3,6]  R2333     4.1553181409835815e-01
    z[4,3,6]  R2334     4.4460281729698181e-01
    z[4,3,6]  R2335     -0.0810999944806099
    z[4,3,6]  R2336     0.0471709668636322
    z[4,3,6]  R2337     3.6713933944702148e-01
    z[4,3,6]  R2338     5.4234504699707031e-01
    z[4,3,6]  R2339     -5.2987277507781982e-01
    z[4,3,6]  R2340     0.671161413192749
    z[4,3,6]  R2341     3.8942303508520126e-02
    z[4,3,6]  R2342     0.429162859916687
    z[4,3,6]  R2343     -3.7207847833633423e-01
    z[4,3,6]  R2344     -1.8802908062934875e-01
    z[4,3,6]  R2345     1.5293040312826633e-02
    z[4,3,6]  R2346     6.8283146619796753e-01
    z[4,3,6]  R2347     4.6395670622587204e-02
    z[4,3,6]  R2348     -5.4667526483535767e-01
    z[4,3,6]  R2349     -0.588240921497345
    z[4,3,6]  R2350     -1.2923638522624969e-01
    z[4,3,6]  R2351     -7.4335299432277679e-03
    z[4,3,6]  R2352     -2.7590328827500343e-02
    z[4,3,6]  R2353     3.6730885505676270e-02
    z[4,3,6]  R2354     -2.9367044568061829e-01
    z[4,3,6]  R2355     2.2171714901924133e-01
    z[4,3,6]  R2356     -1.8461908400058746e-01
    z[4,3,6]  R2357     -1.6669057309627533e-01
    z[4,3,6]  R2358     3.5490524768829346e-01
    z[4,3,6]  R2359     -2.0352724194526672e-01
    z[4,3,6]  R2360     1.1936455219984055e-01
    z[4,3,6]  R2361     -2.6060926914215088e-01
    z[4,3,6]  R2362     1.7777577042579651e-01
    z[4,3,6]  R2363     1.3658711314201355e-01
    z[4,3,6]  R2364     -1.6236859560012817e-01
    z[4,3,6]  R2365     -6.8921104073524475e-02
    z[4,3,6]  R2366     -9.9029108881950378e-02
    z[4,3,6]  R2367     4.9343584105372429e-03
    z[4,3,6]  R2368     -8.1637494266033173e-02
    z[4,3,6]  R2369     3.4795474261045456e-02
    z[4,3,6]  R2370     -6.8906836211681366e-02
    z[4,3,6]  R2371     5.4065424948930740e-02
    z[4,3,6]  R2372     5.4115884006023407e-02
    z[4,3,6]  R2373     0.0679747611284256
    z[4,3,6]  R2374     1.3578702509403229e-01
    z[4,3,6]  R2375     2.6807633042335510e-01
    z[4,3,6]  R2376     7.1148246526718140e-02
    z[4,3,6]  R2377     -9.2562668025493622e-02
    z[4,3,6]  R2378     7.3835469782352448e-02
    z[4,3,6]  R2379     3.5258814692497253e-02
    z[4,3,6]  R2380     -7.1503028273582458e-02
    z[4,3,6]  R2381     9.9891006946563721e-02
    z[4,3,6]  R2382     -2.1038312464952469e-02
    z[4,3,6]  R2383     -1.5752756595611572e-01
    z[4,3,6]  R2384     6.8824617192149162e-03
    z[4,3,6]  R2385     -2.6545220613479614e-01
    z[4,3,6]  R2386     1.4137212932109833e-01
    z[4,3,6]  R2387     3.6631348729133606e-01
    z[4,3,6]  R2388     -8.2015588879585266e-02
    z[4,3,6]  R2389     -2.1970118582248688e-01
    z[4,3,6]  R2390     0.0908239483833313
    z[4,3,6]  R2391     -0.641921877861023
    z[4,3,6]  R2392     8.6049064993858337e-02
    z[4,3,6]  R2393     1.6886119544506073e-01
    z[4,3,6]  R2394     2.4283771216869354e-01
    z[4,3,6]  R2395     4.8933181911706924e-02
    z[4,3,6]  R2396     0.0592205636203289
    z[4,3,6]  R2397     2.4375896900892258e-02
    z[4,3,6]  R2398     -6.8199324607849121e-01
    z[4,3,6]  R2399     1.5630531311035156e-01
    z[4,3,6]  R2400     -2.6589466258883476e-02
    z[4,3,6]  R2401     -3.1645059585571289e-01
    z[4,3,6]  R2402     -1.6363418102264404e-01
    z[4,3,6]  R2403     1.8553754314780235e-02
    z[4,3,6]  R2404     3.1172606348991394e-01
    z[4,3,6]  R2405     -4.8182481527328491e-01
    z[4,5,0]  R38       -1
    z[4,5,0]  R47       1
    z[4,5,0]  R2470     -1
    z[4,5,0]  R2471     1
    z[4,5,0]  R2484     7.2173547744750977e-01
    z[4,5,0]  R2485     -2.6034882664680481e-01
    z[4,5,0]  R2486     -8.8026374578475952e-02
    z[4,5,0]  R2487     7.0207589864730835e-01
    z[4,5,0]  R2488     1.3437853753566742e-01
    z[4,5,0]  R2489     6.1883461475372314e-01
    z[4,5,0]  R2490     5.5191999673843384e-01
    z[4,5,0]  R2491     5.7589358091354370e-01
    z[4,5,0]  R2492     1.9529409706592560e-01
    z[4,5,0]  R2493     8.8348609209060669e-01
    z[4,5,0]  R2494     0.498344749212265
    z[4,5,0]  R2495     -5.7064223289489746e-01
    z[4,5,0]  R2496     -3.8162621855735779e-01
    z[4,5,0]  R2497     -5.8480417728424072e-01
    z[4,5,0]  R2498     -4.7194001078605652e-01
    z[4,5,0]  R2499     -4.4435703754425049e-01
    z[4,5,0]  R2500     -4.1637751460075378e-01
    z[4,5,0]  R2501     -4.7644710540771484e-01
    z[4,5,0]  R2502     -6.2589657306671143e-01
    z[4,5,0]  R2503     -3.0824321508407593e-01
    z[4,5,0]  R2504     6.4118367433547974e-01
    z[4,5,0]  R2505     5.4827427864074707e-01
    z[4,5,0]  R2506     3.2010135054588318e-01
    z[4,5,0]  R2507     1.3908789493143559e-02
    z[4,5,0]  R2508     3.6178115010261536e-01
    z[4,5,0]  R2509     3.5426384210586548e-01
    z[4,5,0]  R2510     3.4391263127326965e-01
    z[4,5,0]  R2511     -3.3993339538574219e-01
    z[4,5,0]  R2512     -0.0794341191649437
    z[4,5,0]  R2513     -1.8189454078674316e-01
    z[4,5,0]  R2514     6.8536871671676636e-01
    z[4,5,0]  R2515     6.1935573816299438e-01
    z[4,5,0]  R2516     -4.0746080875396729e-01
    z[4,5,0]  R2517     4.1207635402679443e-01
    z[4,5,0]  R2518     -3.0557766556739807e-02
    z[4,5,0]  R2519     1.9815362989902496e-01
    z[4,5,0]  R2520     -1.0177161544561386e-01
    z[4,5,0]  R2521     -3.2355093955993652e-01
    z[4,5,0]  R2522     -3.2967633008956909e-01
    z[4,5,0]  R2523     -5.7720702886581421e-01
    z[4,5,0]  R2524     0.465468168258667
    z[4,5,0]  R2525     4.8361030220985413e-01
    z[4,5,0]  R2526     3.9293155074119568e-01
    z[4,5,0]  R2527     4.5623803138732910e-01
    z[4,5,0]  R2528     6.6259825229644775e-01
    z[4,5,0]  R2529     4.4954261183738708e-01
    z[4,5,0]  R2530     -6.7470502853393555e-01
    z[4,5,0]  R2531     -6.7426276206970215e-01
    z[4,5,0]  R2532     -7.7380383014678955e-01
    z[4,5,0]  R2533     5.5530810356140137e-01
    z[4,5,0]  R2534     5.7968068122863770e-01
    z[4,5,0]  R2535     -3.3840614557266235e-01
    z[4,5,0]  R2536     -4.5139434933662415e-01
    z[4,5,0]  R2537     -0.545189619064331
    z[4,5,0]  R2538     -1.6080382466316223e-01
    z[4,5,0]  R2539     -1.4969871938228607e-01
    z[4,5,0]  R2540     -2.0674932003021240e-01
    z[4,5,0]  R2541     -1.6465358436107635e-01
    z[4,5,1]  R39       -1
    z[4,5,1]  R48       1
    z[4,5,1]  R2472     -1
    z[4,5,1]  R2473     1
    z[4,5,1]  R2484     4.7464835643768311e-01
    z[4,5,1]  R2485     -3.7263244390487671e-01
    z[4,5,1]  R2486     -5.8896821737289429e-01
    z[4,5,1]  R2487     5.5480856448411942e-02
    z[4,5,1]  R2488     -0.356360524892807
    z[4,5,1]  R2489     -2.9439383745193481e-01
    z[4,5,1]  R2490     -3.9077866077423096e-01
    z[4,5,1]  R2491     4.5883551239967346e-01
    z[4,5,1]  R2492     -2.5890287756919861e-01
    z[4,5,1]  R2493     1.8817149102687836e-01
    z[4,5,1]  R2494     -3.1648527830839157e-02
    z[4,5,1]  R2495     4.7781169414520264e-01
    z[4,5,1]  R2496     4.4560694694519043e-01
    z[4,5,1]  R2497     5.7730001211166382e-01
    z[4,5,1]  R2498     3.6223095655441284e-01
    z[4,5,1]  R2499     4.5222055912017822e-01
    z[4,5,1]  R2500     5.4885065555572510e-01
    z[4,5,1]  R2501     5.3115218877792358e-01
    z[4,5,1]  R2502     5.1203662157058716e-01
    z[4,5,1]  R2503     -3.8567224144935608e-01
    z[4,5,1]  R2504     -4.6898555010557175e-02
    z[4,5,1]  R2505     1.9691698253154755e-01
    z[4,5,1]  R2506     -3.3078789710998535e-01
    z[4,5,1]  R2507     -2.5322714447975159e-01
    z[4,5,1]  R2508     -0.521737277507782
    z[4,5,1]  R2509     2.8693714737892151e-01
    z[4,5,1]  R2510     -4.4296371936798096e-01
    z[4,5,1]  R2511     -6.5261906385421753e-01
    z[4,5,1]  R2512     5.0646450370550156e-02
    z[4,5,1]  R2513     -8.7560421228408813e-01
    z[4,5,1]  R2514     8.7547548115253448e-02
    z[4,5,1]  R2515     -5.1780784130096436e-01
    z[4,5,1]  R2516     -5.1614469289779663e-01
    z[4,5,1]  R2517     -1.3408043980598450e-01
    z[4,5,1]  R2518     -1.9141638278961182e-01
    z[4,5,1]  R2519     5.2375458180904388e-02
    z[4,5,1]  R2520     1.0893474519252777e-01
    z[4,5,1]  R2521     -1.1364394426345825e-01
    z[4,5,1]  R2522     -2.2669158875942230e-01
    z[4,5,1]  R2523     -0.592122495174408
    z[4,5,1]  R2524     -2.6089332997798920e-02
    z[4,5,1]  R2525     -1.7964828014373779e-01
    z[4,5,1]  R2526     -2.0432645082473755e-01
    z[4,5,1]  R2527     -0.0886748731136322
    z[4,5,1]  R2528     -9.4480365514755249e-02
    z[4,5,1]  R2529     8.1957143545150757e-01
    z[4,5,1]  R2530     -1.0136871039867401e-01
    z[4,5,1]  R2531     -1.5375743806362152e-01
    z[4,5,1]  R2532     -1.6285133361816406e-01
    z[4,5,1]  R2533     -2.9200801253318787e-01
    z[4,5,1]  R2534     2.3025064170360565e-01
    z[4,5,1]  R2535     3.2131013274192810e-01
    z[4,5,1]  R2536     5.4254125803709030e-02
    z[4,5,1]  R2537     -0.13618203997612
    z[4,5,1]  R2538     -4.6495974063873291e-01
    z[4,5,1]  R2539     1.3007128611207008e-02
    z[4,5,1]  R2540     2.0443606376647949e-01
    z[4,5,1]  R2541     2.2308218479156494e-01
    z[4,5,2]  R40       -1
    z[4,5,2]  R49       1
    z[4,5,2]  R2474     -1
    z[4,5,2]  R2475     1
    z[4,5,2]  R2484     2.0658016204833984e-01
    z[4,5,2]  R2485     5.1609843969345093e-01
    z[4,5,2]  R2486     6.4757645130157471e-01
    z[4,5,2]  R2487     9.8929800093173981e-02
    z[4,5,2]  R2488     5.5037707090377808e-01
    z[4,5,2]  R2489     1.7464052140712738e-01
    z[4,5,2]  R2490     -2.3853220045566559e-01
    z[4,5,2]  R2491     5.0685471296310425e-01
    z[4,5,2]  R2492     2.4018318951129913e-01
    z[4,5,2]  R2493     9.5787599682807922e-02
    z[4,5,2]  R2494     -5.3479593992233276e-01
    z[4,5,2]  R2495     -5.9657585620880127e-01
    z[4,5,2]  R2496     -7.1719348430633545e-01
    z[4,5,2]  R2497     -4.3153610825538635e-01
    z[4,5,2]  R2498     -6.7312496900558472e-01
    z[4,5,2]  R2499     -6.3912689685821533e-01
    z[4,5,2]  R2500     -6.0853153467178345e-01
    z[4,5,2]  R2501     -4.1915518045425415e-01
    z[4,5,2]  R2502     -3.3209469914436340e-01
    z[4,5,2]  R2503     -8.0496203899383545e-01
    z[4,5,2]  R2504     -4.6399781107902527e-01
    z[4,5,2]  R2505     -5.1879197359085083e-01
    z[4,5,2]  R2506     -4.1803181171417236e-01
    z[4,5,2]  R2507     1.7579983174800873e-01
    z[4,5,2]  R2508     -2.2754608094692230e-01
    z[4,5,2]  R2509     -2.3996305465698242e-01
    z[4,5,2]  R2510     1.5741537511348724e-01
    z[4,5,2]  R2511     -4.3415728211402893e-01
    z[4,5,2]  R2512     0.576196551322937
    z[4,5,2]  R2513     -4.0394324064254761e-01
    z[4,5,2]  R2514     -0.0334198921918869
    z[4,5,2]  R2515     1.4081464707851410e-01
    z[4,5,2]  R2516     1.9569399952888489e-01
    z[4,5,2]  R2517     1.2754398584365845e-01
    z[4,5,2]  R2518     3.7761977314949036e-01
    z[4,5,2]  R2519     0.517429530620575
    z[4,5,2]  R2520     7.9806648194789886e-02
    z[4,5,2]  R2521     -7.7853941917419434e-01
    z[4,5,2]  R2522     -7.5481927394866943e-01
    z[4,5,2]  R2523     -3.2312935590744019e-01
    z[4,5,2]  R2524     2.7867025136947632e-01
    z[4,5,2]  R2525     -1.0877050459384918e-01
    z[4,5,2]  R2526     1.4166106283664703e-01
    z[4,5,2]  R2527     -1.6703473031520844e-01
    z[4,5,2]  R2528     -0.681039571762085
    z[4,5,2]  R2529     -7.1422152221202850e-02
    z[4,5,2]  R2530     -2.3632074892520905e-01
    z[4,5,2]  R2531     1.2734462320804596e-01
    z[4,5,2]  R2532     2.0489895343780518e-01
    z[4,5,2]  R2533     5.6785231828689575e-01
    z[4,5,2]  R2534     1.4935834705829620e-01
    z[4,5,2]  R2535     5.2744146436452866e-02
    z[4,5,2]  R2536     -3.7843767553567886e-02
    z[4,5,2]  R2537     -2.2276104986667633e-01
    z[4,5,2]  R2538     5.8946889638900757e-01
    z[4,5,2]  R2539     3.7942177057266235e-01
    z[4,5,2]  R2540     6.0760462284088135e-01
    z[4,5,2]  R2541     6.2808138132095337e-01
    z[4,5,3]  R41       -1
    z[4,5,3]  R50       1
    z[4,5,3]  R2476     -1
    z[4,5,3]  R2477     1
    z[4,5,3]  R2484     8.6531199514865875e-02
    z[4,5,3]  R2485     -5.8207309246063232e-01
    z[4,5,3]  R2486     -3.2332116365432739e-01
    z[4,5,3]  R2487     -1.1367462575435638e-01
    z[4,5,3]  R2488     -5.6814730167388916e-01
    z[4,5,3]  R2489     -3.3525720238685608e-01
    z[4,5,3]  R2490     -1.4600183814764023e-02
    z[4,5,3]  R2491     1.4067446812987328e-02
    z[4,5,3]  R2492     -8.1641548871994019e-01
    z[4,5,3]  R2493     -2.7022278308868408e-01
    z[4,5,3]  R2494     2.8645089268684387e-01
    z[4,5,3]  R2495     2.1356928348541260e-01
    z[4,5,3]  R2496     2.5227975845336914e-01
    z[4,5,3]  R2497     2.4058888852596283e-01
    z[4,5,3]  R2498     3.8215324282646179e-01
    z[4,5,3]  R2499     2.8521296381950378e-01
    z[4,5,3]  R2500     3.2522711157798767e-01
    z[4,5,3]  R2501     1.5950119495391846e-01
    z[4,5,3]  R2502     1.9036103785037994e-01
    z[4,5,3]  R2503     1.2890487909317017e-01
    z[4,5,3]  R2504     -3.3502274751663208e-01
    z[4,5,3]  R2505     5.0122457742691040e-01
    z[4,5,3]  R2506     3.6730784177780151e-01
    z[4,5,3]  R2507     -1.6924814879894257e-01
    z[4,5,3]  R2508     0.257690966129303
    z[4,5,3]  R2509     2.8943282365798950e-01
    z[4,5,3]  R2510     3.2569810282438993e-03
    z[4,5,3]  R2511     -3.0136129260063171e-01
    z[4,5,3]  R2512     7.9324334859848022e-02
    z[4,5,3]  R2513     -5.9938136488199234e-02
    z[4,5,3]  R2514     1.2918472290039062e-01
    z[4,5,3]  R2515     -5.5456644296646118e-01
    z[4,5,3]  R2516     -3.4559625387191772e-01
    z[4,5,3]  R2517     4.1245266795158386e-01
    z[4,5,3]  R2518     2.6273833587765694e-02
    z[4,5,3]  R2519     0.0676998421549797
    z[4,5,3]  R2520     3.5153287649154663e-01
    z[4,5,3]  R2521     4.7362190485000610e-01
    z[4,5,3]  R2522     2.2187928855419159e-01
    z[4,5,3]  R2523     3.4765559434890747e-01
    z[4,5,3]  R2524     -5.6948989629745483e-01
    z[4,5,3]  R2525     -4.2881119251251221e-01
    z[4,5,3]  R2526     -7.5719755887985229e-01
    z[4,5,3]  R2527     0.0762195810675621
    z[4,5,3]  R2528     4.4908598065376282e-02
    z[4,5,3]  R2529     8.4992036223411560e-02
    z[4,5,3]  R2530     -6.5855622291564941e-01
    z[4,5,3]  R2531     -5.6091868877410889e-01
    z[4,5,3]  R2532     -4.3509653210639954e-01
    z[4,5,3]  R2533     0.442421019077301
    z[4,5,3]  R2534     -1.7582742869853973e-01
    z[4,5,3]  R2535     -2.8553646802902222e-01
    z[4,5,3]  R2536     7.1413803100585938e-01
    z[4,5,3]  R2537     6.9978368282318115e-01
    z[4,5,3]  R2538     -9.4671607017517090e-02
    z[4,5,3]  R2539     0.0948103740811348
    z[4,5,3]  R2540     5.7832002639770508e-02
    z[4,5,3]  R2541     4.1294094175100327e-02
    z[4,5,4]  R42       -1
    z[4,5,4]  R51       1
    z[4,5,4]  R2478     -1
    z[4,5,4]  R2479     1
    z[4,5,4]  R2484     -5.9527806937694550e-02
    z[4,5,4]  R2485     -4.2494454979896545e-01
    z[4,5,4]  R2486     1.4411987364292145e-01
    z[4,5,4]  R2487     -5.6752490997314453e-01
    z[4,5,4]  R2488     0.381523460149765
    z[4,5,4]  R2489     5.0421410799026489e-01
    z[4,5,4]  R2490     4.7919169068336487e-01
    z[4,5,4]  R2491     4.1130978614091873e-02
    z[4,5,4]  R2492     -8.1844948232173920e-02
    z[4,5,4]  R2493     -1.9448215141892433e-02
    z[4,5,4]  R2494     3.3866535872220993e-02
    z[4,5,4]  R2495     6.8474814295768738e-02
    z[4,5,4]  R2496     5.6055169552564621e-02
    z[4,5,4]  R2497     -8.0082856118679047e-02
    z[4,5,4]  R2498     -8.5795380175113678e-02
    z[4,5,4]  R2499     -2.0354405045509338e-01
    z[4,5,4]  R2500     -2.2154681384563446e-01
    z[4,5,4]  R2501     -2.5517880916595459e-01
    z[4,5,4]  R2502     5.2798591786995530e-04
    z[4,5,4]  R2503     -1.6653573513031006e-01
    z[4,5,4]  R2504     -0.0630049929022789
    z[4,5,4]  R2505     5.7364720851182938e-03
    z[4,5,4]  R2506     1.0685495287179947e-01
    z[4,5,4]  R2507     -1.5308807790279388e-01
    z[4,5,4]  R2508     -1.3211238384246826e-01
    z[4,5,4]  R2509     6.2557297945022583e-01
    z[4,5,4]  R2510     -0.349031537771225
    z[4,5,4]  R2511     3.6674781586043537e-04
    z[4,5,4]  R2512     9.4423428177833557e-02
    z[4,5,4]  R2513     -1.2037818878889084e-01
    z[4,5,4]  R2514     -1.4261111617088318e-01
    z[4,5,4]  R2515     -7.8513838350772858e-02
    z[4,5,4]  R2516     1.2679681181907654e-01
    z[4,5,4]  R2517     7.3971919715404510e-02
    z[4,5,4]  R2518     -1.2156744301319122e-01
    z[4,5,4]  R2519     -4.2790338397026062e-02
    z[4,5,4]  R2520     6.2806212902069092e-01
    z[4,5,4]  R2521     1.0061531327664852e-02
    z[4,5,4]  R2522     1.9800265133380890e-01
    z[4,5,4]  R2523     1.0502353310585022e-01
    z[4,5,4]  R2524     5.4164677858352661e-02
    z[4,5,4]  R2525     4.6782290935516357e-01
    z[4,5,4]  R2526     -1.3765020668506622e-01
    z[4,5,4]  R2527     6.3581025600433350e-01
    z[4,5,4]  R2528     2.3368719220161438e-01
    z[4,5,4]  R2529     3.0189290642738342e-01
    z[4,5,4]  R2530     1.0823497176170349e-01
    z[4,5,4]  R2531     1.3297668099403381e-01
    z[4,5,4]  R2532     3.7571147084236145e-01
    z[4,5,4]  R2533     -1.9383493065834045e-01
    z[4,5,4]  R2534     -5.8535319566726685e-01
    z[4,5,4]  R2535     -4.5141065120697021e-01
    z[4,5,4]  R2536     3.5576120018959045e-01
    z[4,5,4]  R2537     3.0308127403259277e-01
    z[4,5,4]  R2538     -6.1856800317764282e-01
    z[4,5,4]  R2539     -8.9350748062133789e-01
    z[4,5,4]  R2540     -6.5405994653701782e-01
    z[4,5,4]  R2541     -7.2544282674789429e-01
    z[4,5,5]  R43       -1
    z[4,5,5]  R52       1
    z[4,5,5]  R2480     -1
    z[4,5,5]  R2481     1
    z[4,5,5]  R2484     -2.1922864019870758e-01
    z[4,5,5]  R2485     -1.3864994049072266e-02
    z[4,5,5]  R2486     9.8382443189620972e-02
    z[4,5,5]  R2487     -3.9890626072883606e-01
    z[4,5,5]  R2488     2.2245287895202637e-01
    z[4,5,5]  R2489     -1.1194667965173721e-01
    z[4,5,5]  R2490     -0.370022714138031
    z[4,5,5]  R2491     0.0323251374065876
    z[4,5,5]  R2492     2.7211108803749084e-01
    z[4,5,5]  R2493     -3.1022295355796814e-01
    z[4,5,5]  R2494     3.7785702943801880e-01
    z[4,5,5]  R2495     1.9872845709323883e-01
    z[4,5,5]  R2496     2.5526142120361328e-01
    z[4,5,5]  R2497     2.6845550537109375e-01
    z[4,5,5]  R2498     1.2860564887523651e-01
    z[4,5,5]  R2499     2.4986462295055389e-01
    z[4,5,5]  R2500     -3.5493888426572084e-03
    z[4,5,5]  R2501     2.2794951498508453e-01
    z[4,5,5]  R2502     0.0433090478181839
    z[4,5,5]  R2503     2.3948150873184204e-01
    z[4,5,5]  R2504     5.0294625759124756e-01
    z[4,5,5]  R2505     -7.3644906282424927e-02
    z[4,5,5]  R2506     4.1580373048782349e-01
    z[4,5,5]  R2507     -7.5626122951507568e-01
    z[4,5,5]  R2508     -1.0397802293300629e-01
    z[4,5,5]  R2509     5.0789028406143188e-01
    z[4,5,5]  R2510     -5.9557819366455078e-01
    z[4,5,5]  R2511     2.0194037258625031e-01
    z[4,5,5]  R2512     -7.8010231256484985e-01
    z[4,5,5]  R2513     -1.3690859079360962e-01
    z[4,5,5]  R2514     1.3491770625114441e-01
    z[4,5,5]  R2515     -1.1217781901359558e-01
    z[4,5,5]  R2516     -3.0806851387023926e-01
    z[4,5,5]  R2517     5.2376675605773926e-01
    z[4,5,5]  R2518     -8.8750118017196655e-01
    z[4,5,5]  R2519     -0.826915442943573
    z[4,5,5]  R2520     6.7276149988174438e-01
    z[4,5,5]  R2521     2.2474014759063721e-01
    z[4,5,5]  R2522     3.0902171134948730e-01
    z[4,5,5]  R2523     1.7537845671176910e-01
    z[4,5,5]  R2524     -1.4287843368947506e-02
    z[4,5,5]  R2525     -5.6503123044967651e-01
    z[4,5,5]  R2526     -4.3702629208564758e-01
    z[4,5,5]  R2527     -1.3089406490325928e-01
    z[4,5,5]  R2528     -1.7761671543121338e-01
    z[4,5,5]  R2529     -1.0719674080610275e-01
    z[4,5,5]  R2530     -5.2818857133388519e-02
    z[4,5,5]  R2531     -4.0881308913230896e-01
    z[4,5,5]  R2532     -2.4879913777112961e-02
    z[4,5,5]  R2533     1.7187925055623055e-02
    z[4,5,5]  R2534     2.3088967800140381e-01
    z[4,5,5]  R2535     -5.8473899960517883e-02
    z[4,5,5]  R2536     -4.6503199264407158e-03
    z[4,5,5]  R2537     7.1491762995719910e-02
    z[4,5,5]  R2538     1.2345013022422791e-01
    z[4,5,5]  R2539     -1.6062812507152557e-01
    z[4,5,5]  R2540     -3.3547499775886536e-01
    z[4,5,5]  R2541     -2.1850788965821266e-02
    z[4,5,6]  R44       -1
    z[4,5,6]  R53       1
    z[4,5,6]  R2482     -1
    z[4,5,6]  R2483     1
    z[4,5,6]  R2484     -3.8992151618003845e-01
    z[4,5,6]  R2485     8.6179308593273163e-02
    z[4,5,6]  R2486     0.301705539226532
    z[4,5,6]  R2487     0.00955789815634489
    z[4,5,6]  R2488     -1.8492631614208221e-01
    z[4,5,6]  R2489     -3.4744119644165039e-01
    z[4,5,6]  R2490     -3.4499862790107727e-01
    z[4,5,6]  R2491     4.4494986534118652e-01
    z[4,5,6]  R2492     -0.299773633480072
    z[4,5,6]  R2493     -7.2330847382545471e-02
    z[4,5,6]  R2494     4.8853579163551331e-01
    z[4,5,6]  R2495     -1.9156420603394508e-02
    z[4,5,6]  R2496     -0.0973849669098854
    z[4,5,6]  R2497     -4.6267926692962646e-02
    z[4,5,6]  R2498     1.5173251926898956e-01
    z[4,5,6]  R2499     -0.065963514149189
    z[4,5,6]  R2500     -0.0146268829703331
    z[4,5,6]  R2501     4.1553181409835815e-01
    z[4,5,6]  R2502     4.4460281729698181e-01
    z[4,5,6]  R2503     -0.0810999944806099
    z[4,5,6]  R2504     0.0471709668636322
    z[4,5,6]  R2505     3.6713933944702148e-01
    z[4,5,6]  R2506     5.4234504699707031e-01
    z[4,5,6]  R2507     -5.2987277507781982e-01
    z[4,5,6]  R2508     0.671161413192749
    z[4,5,6]  R2509     3.8942303508520126e-02
    z[4,5,6]  R2510     0.429162859916687
    z[4,5,6]  R2511     -3.7207847833633423e-01
    z[4,5,6]  R2512     -1.8802908062934875e-01
    z[4,5,6]  R2513     1.5293040312826633e-02
    z[4,5,6]  R2514     6.8283146619796753e-01
    z[4,5,6]  R2515     4.6395670622587204e-02
    z[4,5,6]  R2516     -5.4667526483535767e-01
    z[4,5,6]  R2517     -0.588240921497345
    z[4,5,6]  R2518     -1.2923638522624969e-01
    z[4,5,6]  R2519     -7.4335299432277679e-03
    z[4,5,6]  R2520     -2.7590328827500343e-02
    z[4,5,6]  R2521     3.6730885505676270e-02
    z[4,5,6]  R2522     -2.9367044568061829e-01
    z[4,5,6]  R2523     2.2171714901924133e-01
    z[4,5,6]  R2524     6.1444687843322754e-01
    z[4,5,6]  R2525     -4.3590404093265533e-03
    z[4,5,6]  R2526     2.2357994690537453e-02
    z[4,5,6]  R2527     5.7348549365997314e-01
    z[4,5,6]  R2528     -6.9269933737814426e-03
    z[4,5,6]  R2529     1.0610774904489517e-01
    z[4,5,6]  R2530     1.7449681460857391e-01
    z[4,5,6]  R2531     7.7917866408824921e-02
    z[4,5,6]  R2532     4.0451128035783768e-02
    z[4,5,6]  R2533     -2.2428588569164276e-01
    z[4,5,6]  R2534     -4.0222319960594177e-01
    z[4,5,6]  R2535     -7.0052641630172729e-01
    z[4,5,6]  R2536     -3.9406427741050720e-01
    z[4,5,6]  R2537     -2.1893793344497681e-01
    z[4,5,6]  R2538     0.0604308545589447
    z[4,5,6]  R2539     1.7724696546792984e-02
    z[4,5,6]  R2540     5.0938300788402557e-02
    z[4,5,6]  R2541     -1.3692008331418037e-02
    z[5,4,0]  R38       1
    z[5,4,0]  R47       -1
    z[5,4,0]  R2542     -1
    z[5,4,0]  R2543     1
    z[5,4,0]  R2556     0.465468168258667
    z[5,4,0]  R2557     4.8361030220985413e-01
    z[5,4,0]  R2558     3.9293155074119568e-01
    z[5,4,0]  R2559     4.5623803138732910e-01
    z[5,4,0]  R2560     6.6259825229644775e-01
    z[5,4,0]  R2561     4.4954261183738708e-01
    z[5,4,0]  R2562     -6.7470502853393555e-01
    z[5,4,0]  R2563     -6.7426276206970215e-01
    z[5,4,0]  R2564     -7.7380383014678955e-01
    z[5,4,0]  R2565     5.5530810356140137e-01
    z[5,4,0]  R2566     5.7968068122863770e-01
    z[5,4,0]  R2567     -3.3840614557266235e-01
    z[5,4,0]  R2568     -4.5139434933662415e-01
    z[5,4,0]  R2569     -0.545189619064331
    z[5,4,0]  R2570     -1.6080382466316223e-01
    z[5,4,0]  R2571     -1.4969871938228607e-01
    z[5,4,0]  R2572     -2.0674932003021240e-01
    z[5,4,0]  R2573     -1.6465358436107635e-01
    z[5,4,0]  R2574     7.2173547744750977e-01
    z[5,4,0]  R2575     -2.6034882664680481e-01
    z[5,4,0]  R2576     -8.8026374578475952e-02
    z[5,4,0]  R2577     7.0207589864730835e-01
    z[5,4,0]  R2578     1.3437853753566742e-01
    z[5,4,0]  R2579     6.1883461475372314e-01
    z[5,4,0]  R2580     5.5191999673843384e-01
    z[5,4,0]  R2581     5.7589358091354370e-01
    z[5,4,0]  R2582     1.9529409706592560e-01
    z[5,4,0]  R2583     8.8348609209060669e-01
    z[5,4,0]  R2584     0.498344749212265
    z[5,4,0]  R2585     -5.7064223289489746e-01
    z[5,4,0]  R2586     -3.8162621855735779e-01
    z[5,4,0]  R2587     -5.8480417728424072e-01
    z[5,4,0]  R2588     -4.7194001078605652e-01
    z[5,4,0]  R2589     -4.4435703754425049e-01
    z[5,4,0]  R2590     -4.1637751460075378e-01
    z[5,4,0]  R2591     -4.7644710540771484e-01
    z[5,4,0]  R2592     -6.2589657306671143e-01
    z[5,4,0]  R2593     -3.0824321508407593e-01
    z[5,4,0]  R2594     6.4118367433547974e-01
    z[5,4,0]  R2595     5.4827427864074707e-01
    z[5,4,0]  R2596     3.2010135054588318e-01
    z[5,4,0]  R2597     1.3908789493143559e-02
    z[5,4,0]  R2598     3.6178115010261536e-01
    z[5,4,0]  R2599     3.5426384210586548e-01
    z[5,4,0]  R2600     3.4391263127326965e-01
    z[5,4,0]  R2601     -3.3993339538574219e-01
    z[5,4,0]  R2602     -0.0794341191649437
    z[5,4,0]  R2603     -1.8189454078674316e-01
    z[5,4,0]  R2604     6.8536871671676636e-01
    z[5,4,0]  R2605     6.1935573816299438e-01
    z[5,4,0]  R2606     -4.0746080875396729e-01
    z[5,4,0]  R2607     4.1207635402679443e-01
    z[5,4,0]  R2608     -3.0557766556739807e-02
    z[5,4,0]  R2609     1.9815362989902496e-01
    z[5,4,0]  R2610     -1.0177161544561386e-01
    z[5,4,0]  R2611     -3.2355093955993652e-01
    z[5,4,0]  R2612     -3.2967633008956909e-01
    z[5,4,0]  R2613     -5.7720702886581421e-01
    z[5,4,1]  R39       1
    z[5,4,1]  R48       -1
    z[5,4,1]  R2544     -1
    z[5,4,1]  R2545     1
    z[5,4,1]  R2556     -2.6089332997798920e-02
    z[5,4,1]  R2557     -1.7964828014373779e-01
    z[5,4,1]  R2558     -2.0432645082473755e-01
    z[5,4,1]  R2559     -0.0886748731136322
    z[5,4,1]  R2560     -9.4480365514755249e-02
    z[5,4,1]  R2561     8.1957143545150757e-01
    z[5,4,1]  R2562     -1.0136871039867401e-01
    z[5,4,1]  R2563     -1.5375743806362152e-01
    z[5,4,1]  R2564     -1.6285133361816406e-01
    z[5,4,1]  R2565     -2.9200801253318787e-01
    z[5,4,1]  R2566     2.3025064170360565e-01
    z[5,4,1]  R2567     3.2131013274192810e-01
    z[5,4,1]  R2568     5.4254125803709030e-02
    z[5,4,1]  R2569     -0.13618203997612
    z[5,4,1]  R2570     -4.6495974063873291e-01
    z[5,4,1]  R2571     1.3007128611207008e-02
    z[5,4,1]  R2572     2.0443606376647949e-01
    z[5,4,1]  R2573     2.2308218479156494e-01
    z[5,4,1]  R2574     4.7464835643768311e-01
    z[5,4,1]  R2575     -3.7263244390487671e-01
    z[5,4,1]  R2576     -5.8896821737289429e-01
    z[5,4,1]  R2577     5.5480856448411942e-02
    z[5,4,1]  R2578     -0.356360524892807
    z[5,4,1]  R2579     -2.9439383745193481e-01
    z[5,4,1]  R2580     -3.9077866077423096e-01
    z[5,4,1]  R2581     4.5883551239967346e-01
    z[5,4,1]  R2582     -2.5890287756919861e-01
    z[5,4,1]  R2583     1.8817149102687836e-01
    z[5,4,1]  R2584     -3.1648527830839157e-02
    z[5,4,1]  R2585     4.7781169414520264e-01
    z[5,4,1]  R2586     4.4560694694519043e-01
    z[5,4,1]  R2587     5.7730001211166382e-01
    z[5,4,1]  R2588     3.6223095655441284e-01
    z[5,4,1]  R2589     4.5222055912017822e-01
    z[5,4,1]  R2590     5.4885065555572510e-01
    z[5,4,1]  R2591     5.3115218877792358e-01
    z[5,4,1]  R2592     5.1203662157058716e-01
    z[5,4,1]  R2593     -3.8567224144935608e-01
    z[5,4,1]  R2594     -4.6898555010557175e-02
    z[5,4,1]  R2595     1.9691698253154755e-01
    z[5,4,1]  R2596     -3.3078789710998535e-01
    z[5,4,1]  R2597     -2.5322714447975159e-01
    z[5,4,1]  R2598     -0.521737277507782
    z[5,4,1]  R2599     2.8693714737892151e-01
    z[5,4,1]  R2600     -4.4296371936798096e-01
    z[5,4,1]  R2601     -6.5261906385421753e-01
    z[5,4,1]  R2602     5.0646450370550156e-02
    z[5,4,1]  R2603     -8.7560421228408813e-01
    z[5,4,1]  R2604     8.7547548115253448e-02
    z[5,4,1]  R2605     -5.1780784130096436e-01
    z[5,4,1]  R2606     -5.1614469289779663e-01
    z[5,4,1]  R2607     -1.3408043980598450e-01
    z[5,4,1]  R2608     -1.9141638278961182e-01
    z[5,4,1]  R2609     5.2375458180904388e-02
    z[5,4,1]  R2610     1.0893474519252777e-01
    z[5,4,1]  R2611     -1.1364394426345825e-01
    z[5,4,1]  R2612     -2.2669158875942230e-01
    z[5,4,1]  R2613     -0.592122495174408
    z[5,4,2]  R40       1
    z[5,4,2]  R49       -1
    z[5,4,2]  R2546     -1
    z[5,4,2]  R2547     1
    z[5,4,2]  R2556     2.7867025136947632e-01
    z[5,4,2]  R2557     -1.0877050459384918e-01
    z[5,4,2]  R2558     1.4166106283664703e-01
    z[5,4,2]  R2559     -1.6703473031520844e-01
    z[5,4,2]  R2560     -0.681039571762085
    z[5,4,2]  R2561     -7.1422152221202850e-02
    z[5,4,2]  R2562     -2.3632074892520905e-01
    z[5,4,2]  R2563     1.2734462320804596e-01
    z[5,4,2]  R2564     2.0489895343780518e-01
    z[5,4,2]  R2565     5.6785231828689575e-01
    z[5,4,2]  R2566     1.4935834705829620e-01
    z[5,4,2]  R2567     5.2744146436452866e-02
    z[5,4,2]  R2568     -3.7843767553567886e-02
    z[5,4,2]  R2569     -2.2276104986667633e-01
    z[5,4,2]  R2570     5.8946889638900757e-01
    z[5,4,2]  R2571     3.7942177057266235e-01
    z[5,4,2]  R2572     6.0760462284088135e-01
    z[5,4,2]  R2573     6.2808138132095337e-01
    z[5,4,2]  R2574     2.0658016204833984e-01
    z[5,4,2]  R2575     5.1609843969345093e-01
    z[5,4,2]  R2576     6.4757645130157471e-01
    z[5,4,2]  R2577     9.8929800093173981e-02
    z[5,4,2]  R2578     5.5037707090377808e-01
    z[5,4,2]  R2579     1.7464052140712738e-01
    z[5,4,2]  R2580     -2.3853220045566559e-01
    z[5,4,2]  R2581     5.0685471296310425e-01
    z[5,4,2]  R2582     2.4018318951129913e-01
    z[5,4,2]  R2583     9.5787599682807922e-02
    z[5,4,2]  R2584     -5.3479593992233276e-01
    z[5,4,2]  R2585     -5.9657585620880127e-01
    z[5,4,2]  R2586     -7.1719348430633545e-01
    z[5,4,2]  R2587     -4.3153610825538635e-01
    z[5,4,2]  R2588     -6.7312496900558472e-01
    z[5,4,2]  R2589     -6.3912689685821533e-01
    z[5,4,2]  R2590     -6.0853153467178345e-01
    z[5,4,2]  R2591     -4.1915518045425415e-01
    z[5,4,2]  R2592     -3.3209469914436340e-01
    z[5,4,2]  R2593     -8.0496203899383545e-01
    z[5,4,2]  R2594     -4.6399781107902527e-01
    z[5,4,2]  R2595     -5.1879197359085083e-01
    z[5,4,2]  R2596     -4.1803181171417236e-01
    z[5,4,2]  R2597     1.7579983174800873e-01
    z[5,4,2]  R2598     -2.2754608094692230e-01
    z[5,4,2]  R2599     -2.3996305465698242e-01
    z[5,4,2]  R2600     1.5741537511348724e-01
    z[5,4,2]  R2601     -4.3415728211402893e-01
    z[5,4,2]  R2602     0.576196551322937
    z[5,4,2]  R2603     -4.0394324064254761e-01
    z[5,4,2]  R2604     -0.0334198921918869
    z[5,4,2]  R2605     1.4081464707851410e-01
    z[5,4,2]  R2606     1.9569399952888489e-01
    z[5,4,2]  R2607     1.2754398584365845e-01
    z[5,4,2]  R2608     3.7761977314949036e-01
    z[5,4,2]  R2609     0.517429530620575
    z[5,4,2]  R2610     7.9806648194789886e-02
    z[5,4,2]  R2611     -7.7853941917419434e-01
    z[5,4,2]  R2612     -7.5481927394866943e-01
    z[5,4,2]  R2613     -3.2312935590744019e-01
    z[5,4,3]  R41       1
    z[5,4,3]  R50       -1
    z[5,4,3]  R2548     -1
    z[5,4,3]  R2549     1
    z[5,4,3]  R2556     -5.6948989629745483e-01
    z[5,4,3]  R2557     -4.2881119251251221e-01
    z[5,4,3]  R2558     -7.5719755887985229e-01
    z[5,4,3]  R2559     0.0762195810675621
    z[5,4,3]  R2560     4.4908598065376282e-02
    z[5,4,3]  R2561     8.4992036223411560e-02
    z[5,4,3]  R2562     -6.5855622291564941e-01
    z[5,4,3]  R2563     -5.6091868877410889e-01
    z[5,4,3]  R2564     -4.3509653210639954e-01
    z[5,4,3]  R2565     0.442421019077301
    z[5,4,3]  R2566     -1.7582742869853973e-01
    z[5,4,3]  R2567     -2.8553646802902222e-01
    z[5,4,3]  R2568     7.1413803100585938e-01
    z[5,4,3]  R2569     6.9978368282318115e-01
    z[5,4,3]  R2570     -9.4671607017517090e-02
    z[5,4,3]  R2571     0.0948103740811348
    z[5,4,3]  R2572     5.7832002639770508e-02
    z[5,4,3]  R2573     4.1294094175100327e-02
    z[5,4,3]  R2574     8.6531199514865875e-02
    z[5,4,3]  R2575     -5.8207309246063232e-01
    z[5,4,3]  R2576     -3.2332116365432739e-01
    z[5,4,3]  R2577     -1.1367462575435638e-01
    z[5,4,3]  R2578     -5.6814730167388916e-01
    z[5,4,3]  R2579     -3.3525720238685608e-01
    z[5,4,3]  R2580     -1.4600183814764023e-02
    z[5,4,3]  R2581     1.4067446812987328e-02
    z[5,4,3]  R2582     -8.1641548871994019e-01
    z[5,4,3]  R2583     -2.7022278308868408e-01
    z[5,4,3]  R2584     2.8645089268684387e-01
    z[5,4,3]  R2585     2.1356928348541260e-01
    z[5,4,3]  R2586     2.5227975845336914e-01
    z[5,4,3]  R2587     2.4058888852596283e-01
    z[5,4,3]  R2588     3.8215324282646179e-01
    z[5,4,3]  R2589     2.8521296381950378e-01
    z[5,4,3]  R2590     3.2522711157798767e-01
    z[5,4,3]  R2591     1.5950119495391846e-01
    z[5,4,3]  R2592     1.9036103785037994e-01
    z[5,4,3]  R2593     1.2890487909317017e-01
    z[5,4,3]  R2594     -3.3502274751663208e-01
    z[5,4,3]  R2595     5.0122457742691040e-01
    z[5,4,3]  R2596     3.6730784177780151e-01
    z[5,4,3]  R2597     -1.6924814879894257e-01
    z[5,4,3]  R2598     0.257690966129303
    z[5,4,3]  R2599     2.8943282365798950e-01
    z[5,4,3]  R2600     3.2569810282438993e-03
    z[5,4,3]  R2601     -3.0136129260063171e-01
    z[5,4,3]  R2602     7.9324334859848022e-02
    z[5,4,3]  R2603     -5.9938136488199234e-02
    z[5,4,3]  R2604     1.2918472290039062e-01
    z[5,4,3]  R2605     -5.5456644296646118e-01
    z[5,4,3]  R2606     -3.4559625387191772e-01
    z[5,4,3]  R2607     4.1245266795158386e-01
    z[5,4,3]  R2608     2.6273833587765694e-02
    z[5,4,3]  R2609     0.0676998421549797
    z[5,4,3]  R2610     3.5153287649154663e-01
    z[5,4,3]  R2611     4.7362190485000610e-01
    z[5,4,3]  R2612     2.2187928855419159e-01
    z[5,4,3]  R2613     3.4765559434890747e-01
    z[5,4,4]  R42       1
    z[5,4,4]  R51       -1
    z[5,4,4]  R2550     -1
    z[5,4,4]  R2551     1
    z[5,4,4]  R2556     5.4164677858352661e-02
    z[5,4,4]  R2557     4.6782290935516357e-01
    z[5,4,4]  R2558     -1.3765020668506622e-01
    z[5,4,4]  R2559     6.3581025600433350e-01
    z[5,4,4]  R2560     2.3368719220161438e-01
    z[5,4,4]  R2561     3.0189290642738342e-01
    z[5,4,4]  R2562     1.0823497176170349e-01
    z[5,4,4]  R2563     1.3297668099403381e-01
    z[5,4,4]  R2564     3.7571147084236145e-01
    z[5,4,4]  R2565     -1.9383493065834045e-01
    z[5,4,4]  R2566     -5.8535319566726685e-01
    z[5,4,4]  R2567     -4.5141065120697021e-01
    z[5,4,4]  R2568     3.5576120018959045e-01
    z[5,4,4]  R2569     3.0308127403259277e-01
    z[5,4,4]  R2570     -6.1856800317764282e-01
    z[5,4,4]  R2571     -8.9350748062133789e-01
    z[5,4,4]  R2572     -6.5405994653701782e-01
    z[5,4,4]  R2573     -7.2544282674789429e-01
    z[5,4,4]  R2574     -5.9527806937694550e-02
    z[5,4,4]  R2575     -4.2494454979896545e-01
    z[5,4,4]  R2576     1.4411987364292145e-01
    z[5,4,4]  R2577     -5.6752490997314453e-01
    z[5,4,4]  R2578     0.381523460149765
    z[5,4,4]  R2579     5.0421410799026489e-01
    z[5,4,4]  R2580     4.7919169068336487e-01
    z[5,4,4]  R2581     4.1130978614091873e-02
    z[5,4,4]  R2582     -8.1844948232173920e-02
    z[5,4,4]  R2583     -1.9448215141892433e-02
    z[5,4,4]  R2584     3.3866535872220993e-02
    z[5,4,4]  R2585     6.8474814295768738e-02
    z[5,4,4]  R2586     5.6055169552564621e-02
    z[5,4,4]  R2587     -8.0082856118679047e-02
    z[5,4,4]  R2588     -8.5795380175113678e-02
    z[5,4,4]  R2589     -2.0354405045509338e-01
    z[5,4,4]  R2590     -2.2154681384563446e-01
    z[5,4,4]  R2591     -2.5517880916595459e-01
    z[5,4,4]  R2592     5.2798591786995530e-04
    z[5,4,4]  R2593     -1.6653573513031006e-01
    z[5,4,4]  R2594     -0.0630049929022789
    z[5,4,4]  R2595     5.7364720851182938e-03
    z[5,4,4]  R2596     1.0685495287179947e-01
    z[5,4,4]  R2597     -1.5308807790279388e-01
    z[5,4,4]  R2598     -1.3211238384246826e-01
    z[5,4,4]  R2599     6.2557297945022583e-01
    z[5,4,4]  R2600     -0.349031537771225
    z[5,4,4]  R2601     3.6674781586043537e-04
    z[5,4,4]  R2602     9.4423428177833557e-02
    z[5,4,4]  R2603     -1.2037818878889084e-01
    z[5,4,4]  R2604     -1.4261111617088318e-01
    z[5,4,4]  R2605     -7.8513838350772858e-02
    z[5,4,4]  R2606     1.2679681181907654e-01
    z[5,4,4]  R2607     7.3971919715404510e-02
    z[5,4,4]  R2608     -1.2156744301319122e-01
    z[5,4,4]  R2609     -4.2790338397026062e-02
    z[5,4,4]  R2610     6.2806212902069092e-01
    z[5,4,4]  R2611     1.0061531327664852e-02
    z[5,4,4]  R2612     1.9800265133380890e-01
    z[5,4,4]  R2613     1.0502353310585022e-01
    z[5,4,5]  R43       1
    z[5,4,5]  R52       -1
    z[5,4,5]  R2552     -1
    z[5,4,5]  R2553     1
    z[5,4,5]  R2556     -1.4287843368947506e-02
    z[5,4,5]  R2557     -5.6503123044967651e-01
    z[5,4,5]  R2558     -4.3702629208564758e-01
    z[5,4,5]  R2559     -1.3089406490325928e-01
    z[5,4,5]  R2560     -1.7761671543121338e-01
    z[5,4,5]  R2561     -1.0719674080610275e-01
    z[5,4,5]  R2562     -5.2818857133388519e-02
    z[5,4,5]  R2563     -4.0881308913230896e-01
    z[5,4,5]  R2564     -2.4879913777112961e-02
    z[5,4,5]  R2565     1.7187925055623055e-02
    z[5,4,5]  R2566     2.3088967800140381e-01
    z[5,4,5]  R2567     -5.8473899960517883e-02
    z[5,4,5]  R2568     -4.6503199264407158e-03
    z[5,4,5]  R2569     7.1491762995719910e-02
    z[5,4,5]  R2570     1.2345013022422791e-01
    z[5,4,5]  R2571     -1.6062812507152557e-01
    z[5,4,5]  R2572     -3.3547499775886536e-01
    z[5,4,5]  R2573     -2.1850788965821266e-02
    z[5,4,5]  R2574     -2.1922864019870758e-01
    z[5,4,5]  R2575     -1.3864994049072266e-02
    z[5,4,5]  R2576     9.8382443189620972e-02
    z[5,4,5]  R2577     -3.9890626072883606e-01
    z[5,4,5]  R2578     2.2245287895202637e-01
    z[5,4,5]  R2579     -1.1194667965173721e-01
    z[5,4,5]  R2580     -0.370022714138031
    z[5,4,5]  R2581     0.0323251374065876
    z[5,4,5]  R2582     2.7211108803749084e-01
    z[5,4,5]  R2583     -3.1022295355796814e-01
    z[5,4,5]  R2584     3.7785702943801880e-01
    z[5,4,5]  R2585     1.9872845709323883e-01
    z[5,4,5]  R2586     2.5526142120361328e-01
    z[5,4,5]  R2587     2.6845550537109375e-01
    z[5,4,5]  R2588     1.2860564887523651e-01
    z[5,4,5]  R2589     2.4986462295055389e-01
    z[5,4,5]  R2590     -3.5493888426572084e-03
    z[5,4,5]  R2591     2.2794951498508453e-01
    z[5,4,5]  R2592     0.0433090478181839
    z[5,4,5]  R2593     2.3948150873184204e-01
    z[5,4,5]  R2594     5.0294625759124756e-01
    z[5,4,5]  R2595     -7.3644906282424927e-02
    z[5,4,5]  R2596     4.1580373048782349e-01
    z[5,4,5]  R2597     -7.5626122951507568e-01
    z[5,4,5]  R2598     -1.0397802293300629e-01
    z[5,4,5]  R2599     5.0789028406143188e-01
    z[5,4,5]  R2600     -5.9557819366455078e-01
    z[5,4,5]  R2601     2.0194037258625031e-01
    z[5,4,5]  R2602     -7.8010231256484985e-01
    z[5,4,5]  R2603     -1.3690859079360962e-01
    z[5,4,5]  R2604     1.3491770625114441e-01
    z[5,4,5]  R2605     -1.1217781901359558e-01
    z[5,4,5]  R2606     -3.0806851387023926e-01
    z[5,4,5]  R2607     5.2376675605773926e-01
    z[5,4,5]  R2608     -8.8750118017196655e-01
    z[5,4,5]  R2609     -0.826915442943573
    z[5,4,5]  R2610     6.7276149988174438e-01
    z[5,4,5]  R2611     2.2474014759063721e-01
    z[5,4,5]  R2612     3.0902171134948730e-01
    z[5,4,5]  R2613     1.7537845671176910e-01
    z[5,4,6]  R44       1
    z[5,4,6]  R53       -1
    z[5,4,6]  R2554     -1
    z[5,4,6]  R2555     1
    z[5,4,6]  R2556     6.1444687843322754e-01
    z[5,4,6]  R2557     -4.3590404093265533e-03
    z[5,4,6]  R2558     2.2357994690537453e-02
    z[5,4,6]  R2559     5.7348549365997314e-01
    z[5,4,6]  R2560     -6.9269933737814426e-03
    z[5,4,6]  R2561     1.0610774904489517e-01
    z[5,4,6]  R2562     1.7449681460857391e-01
    z[5,4,6]  R2563     7.7917866408824921e-02
    z[5,4,6]  R2564     4.0451128035783768e-02
    z[5,4,6]  R2565     -2.2428588569164276e-01
    z[5,4,6]  R2566     -4.0222319960594177e-01
    z[5,4,6]  R2567     -7.0052641630172729e-01
    z[5,4,6]  R2568     -3.9406427741050720e-01
    z[5,4,6]  R2569     -2.1893793344497681e-01
    z[5,4,6]  R2570     0.0604308545589447
    z[5,4,6]  R2571     1.7724696546792984e-02
    z[5,4,6]  R2572     5.0938300788402557e-02
    z[5,4,6]  R2573     -1.3692008331418037e-02
    z[5,4,6]  R2574     -3.8992151618003845e-01
    z[5,4,6]  R2575     8.6179308593273163e-02
    z[5,4,6]  R2576     0.301705539226532
    z[5,4,6]  R2577     0.00955789815634489
    z[5,4,6]  R2578     -1.8492631614208221e-01
    z[5,4,6]  R2579     -3.4744119644165039e-01
    z[5,4,6]  R2580     -3.4499862790107727e-01
    z[5,4,6]  R2581     4.4494986534118652e-01
    z[5,4,6]  R2582     -0.299773633480072
    z[5,4,6]  R2583     -7.2330847382545471e-02
    z[5,4,6]  R2584     4.8853579163551331e-01
    z[5,4,6]  R2585     -1.9156420603394508e-02
    z[5,4,6]  R2586     -0.0973849669098854
    z[5,4,6]  R2587     -4.6267926692962646e-02
    z[5,4,6]  R2588     1.5173251926898956e-01
    z[5,4,6]  R2589     -0.065963514149189
    z[5,4,6]  R2590     -0.0146268829703331
    z[5,4,6]  R2591     4.1553181409835815e-01
    z[5,4,6]  R2592     4.4460281729698181e-01
    z[5,4,6]  R2593     -0.0810999944806099
    z[5,4,6]  R2594     0.0471709668636322
    z[5,4,6]  R2595     3.6713933944702148e-01
    z[5,4,6]  R2596     5.4234504699707031e-01
    z[5,4,6]  R2597     -5.2987277507781982e-01
    z[5,4,6]  R2598     0.671161413192749
    z[5,4,6]  R2599     3.8942303508520126e-02
    z[5,4,6]  R2600     0.429162859916687
    z[5,4,6]  R2601     -3.7207847833633423e-01
    z[5,4,6]  R2602     -1.8802908062934875e-01
    z[5,4,6]  R2603     1.5293040312826633e-02
    z[5,4,6]  R2604     6.8283146619796753e-01
    z[5,4,6]  R2605     4.6395670622587204e-02
    z[5,4,6]  R2606     -5.4667526483535767e-01
    z[5,4,6]  R2607     -0.588240921497345
    z[5,4,6]  R2608     -1.2923638522624969e-01
    z[5,4,6]  R2609     -7.4335299432277679e-03
    z[5,4,6]  R2610     -2.7590328827500343e-02
    z[5,4,6]  R2611     3.6730885505676270e-02
    z[5,4,6]  R2612     -2.9367044568061829e-01
    z[5,4,6]  R2613     2.2171714901924133e-01
    length[0]  OBJ       1
    length[1]  OBJ       1
    length[2]  OBJ       1
    length[3]  OBJ       1
    length[4]  OBJ       1
    length[5]  OBJ       1
    delta[0,0]  R2        1
    delta[0,1]  R3        1
    delta[0,2]  R4        1
    delta[0,3]  R5        1
    delta[0,4]  R6        1
    delta[0,5]  R7        1
    delta[0,6]  R8        1
    delta[1,0]  R11       1
    delta[1,1]  R12       1
    delta[1,2]  R13       1
    delta[1,3]  R14       1
    delta[1,4]  R15       1
    delta[1,5]  R16       1
    delta[1,6]  R17       1
    delta[2,0]  R20       1
    delta[2,1]  R21       1
    delta[2,2]  R22       1
    delta[2,3]  R23       1
    delta[2,4]  R24       1
    delta[2,5]  R25       1
    delta[2,6]  R26       1
    delta[3,0]  R29       1
    delta[3,1]  R30       1
    delta[3,2]  R31       1
    delta[3,3]  R32       1
    delta[3,4]  R33       1
    delta[3,5]  R34       1
    delta[3,6]  R35       1
    delta[4,0]  R38       1
    delta[4,1]  R39       1
    delta[4,2]  R40       1
    delta[4,3]  R41       1
    delta[4,4]  R42       1
    delta[4,5]  R43       1
    delta[4,6]  R44       1
    delta[5,0]  R47       1
    delta[5,1]  R48       1
    delta[5,2]  R49       1
    delta[5,3]  R50       1
    delta[5,4]  R51       1
    delta[5,5]  R52       1
    delta[5,6]  R53       1
RHS
    RHS1      R1        1
    RHS1      R10       1
    RHS1      R19       1
    RHS1      R28       1
    RHS1      R37       1
    RHS1      R46       1
    RHS1      R54       1
    RHS1      R55       -1
BOUNDS
 BV BND1      phi[0,1]
 BV BND1      phi[1,0]
 BV BND1      phi[0,3]
 BV BND1      phi[3,0]
 BV BND1      phi[0,4]
 BV BND1      phi[4,0]
 BV BND1      phi[6,0]
 BV BND1      phi[1,2]
 BV BND1      phi[2,1]
 BV BND1      phi[1,3]
 BV BND1      phi[3,1]
 BV BND1      phi[1,4]
 BV BND1      phi[4,1]
 BV BND1      phi[1,5]
 BV BND1      phi[5,1]
 BV BND1      phi[2,4]
 BV BND1      phi[4,2]
 BV BND1      phi[2,5]
 BV BND1      phi[5,2]
 BV BND1      phi[2,7]
 BV BND1      phi[3,4]
 BV BND1      phi[4,3]
 BV BND1      phi[6,3]
 BV BND1      phi[4,5]
 BV BND1      phi[5,4]
 BV BND1      phi[5,7]
 FR BND1      z[0,1,0]
 FR BND1      z[0,1,1]
 FR BND1      z[0,1,2]
 FR BND1      z[0,1,3]
 FR BND1      z[0,1,4]
 FR BND1      z[0,1,5]
 FR BND1      z[0,1,6]
 FR BND1      z[1,0,0]
 FR BND1      z[1,0,1]
 FR BND1      z[1,0,2]
 FR BND1      z[1,0,3]
 FR BND1      z[1,0,4]
 FR BND1      z[1,0,5]
 FR BND1      z[1,0,6]
 FR BND1      z[0,3,0]
 FR BND1      z[0,3,1]
 FR BND1      z[0,3,2]
 FR BND1      z[0,3,3]
 FR BND1      z[0,3,4]
 FR BND1      z[0,3,5]
 FR BND1      z[0,3,6]
 FR BND1      z[3,0,0]
 FR BND1      z[3,0,1]
 FR BND1      z[3,0,2]
 FR BND1      z[3,0,3]
 FR BND1      z[3,0,4]
 FR BND1      z[3,0,5]
 FR BND1      z[3,0,6]
 FR BND1      z[0,4,0]
 FR BND1      z[0,4,1]
 FR BND1      z[0,4,2]
 FR BND1      z[0,4,3]
 FR BND1      z[0,4,4]
 FR BND1      z[0,4,5]
 FR BND1      z[0,4,6]
 FR BND1      z[4,0,0]
 FR BND1      z[4,0,1]
 FR BND1      z[4,0,2]
 FR BND1      z[4,0,3]
 FR BND1      z[4,0,4]
 FR BND1      z[4,0,5]
 FR BND1      z[4,0,6]
 FR BND1      z[1,2,0]
 FR BND1      z[1,2,1]
 FR BND1      z[1,2,2]
 FR BND1      z[1,2,3]
 FR BND1      z[1,2,4]
 FR BND1      z[1,2,5]
 FR BND1      z[1,2,6]
 FR BND1      z[2,1,0]
 FR BND1      z[2,1,1]
 FR BND1      z[2,1,2]
 FR BND1      z[2,1,3]
 FR BND1      z[2,1,4]
 FR BND1      z[2,1,5]
 FR BND1      z[2,1,6]
 FR BND1      z[1,3,0]
 FR BND1      z[1,3,1]
 FR BND1      z[1,3,2]
 FR BND1      z[1,3,3]
 FR BND1      z[1,3,4]
 FR BND1      z[1,3,5]
 FR BND1      z[1,3,6]
 FR BND1      z[3,1,0]
 FR BND1      z[3,1,1]
 FR BND1      z[3,1,2]
 FR BND1      z[3,1,3]
 FR BND1      z[3,1,4]
 FR BND1      z[3,1,5]
 FR BND1      z[3,1,6]
 FR BND1      z[1,4,0]
 FR BND1      z[1,4,1]
 FR BND1      z[1,4,2]
 FR BND1      z[1,4,3]
 FR BND1      z[1,4,4]
 FR BND1      z[1,4,5]
 FR BND1      z[1,4,6]
 FR BND1      z[4,1,0]
 FR BND1      z[4,1,1]
 FR BND1      z[4,1,2]
 FR BND1      z[4,1,3]
 FR BND1      z[4,1,4]
 FR BND1      z[4,1,5]
 FR BND1      z[4,1,6]
 FR BND1      z[1,5,0]
 FR BND1      z[1,5,1]
 FR BND1      z[1,5,2]
 FR BND1      z[1,5,3]
 FR BND1      z[1,5,4]
 FR BND1      z[1,5,5]
 FR BND1      z[1,5,6]
 FR BND1      z[5,1,0]
 FR BND1      z[5,1,1]
 FR BND1      z[5,1,2]
 FR BND1      z[5,1,3]
 FR BND1      z[5,1,4]
 FR BND1      z[5,1,5]
 FR BND1      z[5,1,6]
 FR BND1      z[2,4,0]
 FR BND1      z[2,4,1]
 FR BND1      z[2,4,2]
 FR BND1      z[2,4,3]
 FR BND1      z[2,4,4]
 FR BND1      z[2,4,5]
 FR BND1      z[2,4,6]
 FR BND1      z[4,2,0]
 FR BND1      z[4,2,1]
 FR BND1      z[4,2,2]
 FR BND1      z[4,2,3]
 FR BND1      z[4,2,4]
 FR BND1      z[4,2,5]
 FR BND1      z[4,2,6]
 FR BND1      z[2,5,0]
 FR BND1      z[2,5,1]
 FR BND1      z[2,5,2]
 FR BND1      z[2,5,3]
 FR BND1      z[2,5,4]
 FR BND1      z[2,5,5]
 FR BND1      z[2,5,6]
 FR BND1      z[5,2,0]
 FR BND1      z[5,2,1]
 FR BND1      z[5,2,2]
 FR BND1      z[5,2,3]
 FR BND1      z[5,2,4]
 FR BND1      z[5,2,5]
 FR BND1      z[5,2,6]
 FR BND1      z[3,4,0]
 FR BND1      z[3,4,1]
 FR BND1      z[3,4,2]
 FR BND1      z[3,4,3]
 FR BND1      z[3,4,4]
 FR BND1      z[3,4,5]
 FR BND1      z[3,4,6]
 FR BND1      z[4,3,0]
 FR BND1      z[4,3,1]
 FR BND1      z[4,3,2]
 FR BND1      z[4,3,3]
 FR BND1      z[4,3,4]
 FR BND1      z[4,3,5]
 FR BND1      z[4,3,6]
 FR BND1      z[4,5,0]
 FR BND1      z[4,5,1]
 FR BND1      z[4,5,2]
 FR BND1      z[4,5,3]
 FR BND1      z[4,5,4]
 FR BND1      z[4,5,5]
 FR BND1      z[4,5,6]
 FR BND1      z[5,4,0]
 FR BND1      z[5,4,1]
 FR BND1      z[5,4,2]
 FR BND1      z[5,4,3]
 FR BND1      z[5,4,4]
 FR BND1      z[5,4,5]
 FR BND1      z[5,4,6]
 FR BND1      delta[0,0]
 FR BND1      delta[0,1]
 FR BND1      delta[0,2]
 FR BND1      delta[0,3]
 FR BND1      delta[0,4]
 FR BND1      delta[0,5]
 FR BND1      delta[0,6]
 FR BND1      delta[1,0]
 FR BND1      delta[1,1]
 FR BND1      delta[1,2]
 FR BND1      delta[1,3]
 FR BND1      delta[1,4]
 FR BND1      delta[1,5]
 FR BND1      delta[1,6]
 FR BND1      delta[2,0]
 FR BND1      delta[2,1]
 FR BND1      delta[2,2]
 FR BND1      delta[2,3]
 FR BND1      delta[2,4]
 FR BND1      delta[2,5]
 FR BND1      delta[2,6]
 FR BND1      delta[3,0]
 FR BND1      delta[3,1]
 FR BND1      delta[3,2]
 FR BND1      delta[3,3]
 FR BND1      delta[3,4]
 FR BND1      delta[3,5]
 FR BND1      delta[3,6]
 FR BND1      delta[4,0]
 FR BND1      delta[4,1]
 FR BND1      delta[4,2]
 FR BND1      delta[4,3]
 FR BND1      delta[4,4]
 FR BND1      delta[4,5]
 FR BND1      delta[4,6]
 FR BND1      delta[5,0]
 FR BND1      delta[5,1]
 FR BND1      delta[5,2]
 FR BND1      delta[5,3]
 FR BND1      delta[5,4]
 FR BND1      delta[5,5]
 FR BND1      delta[5,6]
QCMATRIX   qc0     
    length[0]  length[0]  -1
    delta[0,0]  delta[0,0]  1
    delta[0,1]  delta[0,1]  1
    delta[0,2]  delta[0,2]  1
    delta[0,3]  delta[0,3]  1
    delta[0,4]  delta[0,4]  1
    delta[0,5]  delta[0,5]  1
    delta[0,6]  delta[0,6]  1
QCMATRIX   qc1     
    length[1]  length[1]  -1
    delta[1,0]  delta[1,0]  1
    delta[1,1]  delta[1,1]  1
    delta[1,2]  delta[1,2]  1
    delta[1,3]  delta[1,3]  1
    delta[1,4]  delta[1,4]  1
    delta[1,5]  delta[1,5]  1
    delta[1,6]  delta[1,6]  1
QCMATRIX   qc2     
    length[2]  length[2]  -1
    delta[2,0]  delta[2,0]  1
    delta[2,1]  delta[2,1]  1
    delta[2,2]  delta[2,2]  1
    delta[2,3]  delta[2,3]  1
    delta[2,4]  delta[2,4]  1
    delta[2,5]  delta[2,5]  1
    delta[2,6]  delta[2,6]  1
QCMATRIX   qc3     
    length[3]  length[3]  -1
    delta[3,0]  delta[3,0]  1
    delta[3,1]  delta[3,1]  1
    delta[3,2]  delta[3,2]  1
    delta[3,3]  delta[3,3]  1
    delta[3,4]  delta[3,4]  1
    delta[3,5]  delta[3,5]  1
    delta[3,6]  delta[3,6]  1
QCMATRIX   qc4     
    length[4]  length[4]  -1
    delta[4,0]  delta[4,0]  1
    delta[4,1]  delta[4,1]  1
    delta[4,2]  delta[4,2]  1
    delta[4,3]  delta[4,3]  1
    delta[4,4]  delta[4,4]  1
    delta[4,5]  delta[4,5]  1
    delta[4,6]  delta[4,6]  1
QCMATRIX   qc5     
    length[5]  length[5]  -1
    delta[5,0]  delta[5,0]  1
    delta[5,1]  delta[5,1]  1
    delta[5,2]  delta[5,2]  1
    delta[5,3]  delta[5,3]  1
    delta[5,4]  delta[5,4]  1
    delta[5,5]  delta[5,5]  1
    delta[5,6]  delta[5,6]  1
ENDATA
