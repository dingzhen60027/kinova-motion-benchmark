NAME LGCS_GCS_Eq5_5_projected
ROWS
 N  OBJ
 E  R0      
 L  R1      
 E  R2      
 E  R3      
 E  R4      
 E  R5      
 E  R6      
 E  R7      
 E  R8      
 E  R9      
 L  R10     
 E  R11     
 E  R12     
 E  R13     
 E  R14     
 E  R15     
 E  R16     
 E  R17     
 E  R18     
 L  R19     
 E  R20     
 E  R21     
 E  R22     
 E  R23     
 E  R24     
 E  R25     
 E  R26     
 E  R27     
 L  R28     
 E  R29     
 E  R30     
 E  R31     
 E  R32     
 E  R33     
 E  R34     
 E  R35     
 E  R36     
 L  R37     
 E  R38     
 E  R39     
 E  R40     
 E  R41     
 E  R42     
 E  R43     
 E  R44     
 E  R45     
 L  R46     
 E  R47     
 E  R48     
 E  R49     
 E  R50     
 E  R51     
 E  R52     
 E  R53     
 E  R54     
 L  R55     
 E  R56     
 E  R57     
 E  R58     
 E  R59     
 E  R60     
 E  R61     
 E  R62     
 E  R63     
 L  R64     
 E  R65     
 E  R66     
 E  R67     
 E  R68     
 E  R69     
 E  R70     
 E  R71     
 E  R72     
 L  R73     
 E  R74     
 E  R75     
 E  R76     
 E  R77     
 E  R78     
 E  R79     
 E  R80     
 E  R81     
 L  R82     
 E  R83     
 E  R84     
 E  R85     
 E  R86     
 E  R87     
 E  R88     
 E  R89     
 E  R90     
 L  R91     
 E  R92     
 E  R93     
 E  R94     
 E  R95     
 E  R96     
 E  R97     
 E  R98     
 E  R99     
 E  R100    
 L  R101    
 L  R102    
 L  R103    
 L  R104    
 L  R105    
 L  R106    
 L  R107    
 L  R108    
 L  R109    
 L  R110    
 L  R111    
 L  R112    
 L  R113    
 L  R114    
 L  R115    
 L  R116    
 L  R117    
 L  R118    
 L  R119    
 L  R120    
 L  R121    
 L  R122    
 L  R123    
 L  R124    
 L  R125    
 L  R126    
 L  R127    
 L  R128    
 L  R129    
 L  R130    
 L  R131    
 L  R132    
 L  R133    
 L  R134    
 L  R135    
 L  R136    
 L  R137    
 L  R138    
 L  R139    
 L  R140    
 L  R141    
 L  R142    
 L  R143    
 L  R144    
 L  R145    
 L  R146    
 L  R147    
 L  R148    
 L  R149    
 L  R150    
 L  R151    
 L  R152    
 L  R153    
 L  R154    
 L  R155    
 L  R156    
 L  R157    
 L  R158    
 L  R159    
 L  R160    
 L  R161    
 L  R162    
 L  R163    
 L  R164    
 L  R165    
 L  R166    
 L  R167    
 L  R168    
 L  R169    
 L  R170    
 L  R171    
 L  R172    
 L  R173    
 L  R174    
 L  R175    
 L  R176    
 L  R177    
 L  R178    
 L  R179    
 L  R180    
 L  R181    
 L  R182    
 L  R183    
 L  R184    
 L  R185    
 L  R186    
 L  R187    
 L  R188    
 L  R189    
 L  R190    
 L  R191    
 L  R192    
 L  R193    
 L  R194    
 L  R195    
 L  R196    
 L  R197    
 L  R198    
 L  R199    
 L  R200    
 L  R201    
 L  R202    
 L  R203    
 L  R204    
 L  R205    
 L  R206    
 L  R207    
 L  R208    
 L  R209    
 L  R210    
 L  R211    
 L  R212    
 L  R213    
 L  R214    
 L  R215    
 L  R216    
 L  R217    
 L  R218    
 L  R219    
 L  R220    
 L  R221    
 L  R222    
 L  R223    
 L  R224    
 L  R225    
 L  R226    
 L  R227    
 L  R228    
 L  R229    
 L  R230    
 L  R231    
 L  R232    
 L  R233    
 L  R234    
 L  R235    
 L  R236    
 L  R237    
 L  R238    
 L  R239    
 L  R240    
 L  R241    
 L  R242    
 L  R243    
 L  R244    
 L  R245    
 L  R246    
 L  R247    
 L  R248    
 L  R249    
 L  R250    
 L  R251    
 L  R252    
 L  R253    
 L  R254    
 L  R255    
 L  R256    
 L  R257    
 L  R258    
 L  R259    
 L  R260    
 L  R261    
 L  R262    
 L  R263    
 L  R264    
 L  R265    
 L  R266    
 L  R267    
 L  R268    
 L  R269    
 L  R270    
 L  R271    
 L  R272    
 L  R273    
 L  R274    
 L  R275    
 L  R276    
 L  R277    
 L  R278    
 L  R279    
 L  R280    
 L  R281    
 L  R282    
 L  R283    
 L  R284    
 L  R285    
 L  R286    
 L  R287    
 L  R288    
 L  R289    
 L  R290    
 L  R291    
 L  R292    
 L  R293    
 L  R294    
 L  R295    
 L  R296    
 L  R297    
 L  R298    
 L  R299    
 L  R300    
 L  R301    
 L  R302    
 L  R303    
 L  R304    
 L  R305    
 L  R306    
 L  R307    
 L  R308    
 L  R309    
 L  R310    
 L  R311    
 L  R312    
 L  R313    
 L  R314    
 L  R315    
 L  R316    
 L  R317    
 L  R318    
 L  R319    
 L  R320    
 L  R321    
 L  R322    
 L  R323    
 L  R324    
 L  R325    
 L  R326    
 L  R327    
 L  R328    
 L  R329    
 L  R330    
 L  R331    
 L  R332    
 L  R333    
 L  R334    
 L  R335    
 L  R336    
 L  R337    
 L  R338    
 L  R339    
 L  R340    
 L  R341    
 L  R342    
 L  R343    
 L  R344    
 L  R345    
 L  R346    
 L  R347    
 L  R348    
 L  R349    
 L  R350    
 L  R351    
 L  R352    
 L  R353    
 L  R354    
 L  R355    
 L  R356    
 L  R357    
 L  R358    
 L  R359    
 L  R360    
 L  R361    
 L  R362    
 L  R363    
 L  R364    
 L  R365    
 L  R366    
 L  R367    
 L  R368    
 L  R369    
 L  R370    
 L  R371    
 L  R372    
 L  R373    
 L  R374    
 L  R375    
 L  R376    
 L  R377    
 L  R378    
 L  R379    
 L  R380    
 L  R381    
 L  R382    
 L  R383    
 L  R384    
 L  R385    
 L  R386    
 L  R387    
 L  R388    
 L  R389    
 L  R390    
 L  R391    
 L  R392    
 L  R393    
 L  R394    
 L  R395    
 L  R396    
 L  R397    
 L  R398    
 L  R399    
 L  R400    
 L  R401    
 L  R402    
 L  R403    
 L  R404    
 L  R405    
 L  R406    
 L  R407    
 L  R408    
 L  R409    
 L  R410    
 L  R411    
 L  R412    
 L  R413    
 L  R414    
 L  R415    
 L  R416    
 L  R417    
 L  R418    
 L  R419    
 L  R420    
 L  R421    
 L  R422    
 L  R423    
 L  R424    
 L  R425    
 L  R426    
 L  R427    
 L  R428    
 L  R429    
 L  R430    
 L  R431    
 L  R432    
 L  R433    
 L  R434    
 L  R435    
 L  R436    
 L  R437    
 L  R438    
 L  R439    
 L  R440    
 L  R441    
 L  R442    
 L  R443    
 L  R444    
 L  R445    
 L  R446    
 L  R447    
 L  R448    
 L  R449    
 L  R450    
 L  R451    
 L  R452    
 L  R453    
 L  R454    
 L  R455    
 L  R456    
 L  R457    
 L  R458    
 L  R459    
 L  R460    
 L  R461    
 L  R462    
 L  R463    
 L  R464    
 L  R465    
 L  R466    
 L  R467    
 L  R468    
 L  R469    
 L  R470    
 L  R471    
 L  R472    
 L  R473    
 L  R474    
 L  R475    
 L  R476    
 L  R477    
 L  R478    
 L  R479    
 L  R480    
 L  R481    
 L  R482    
 L  R483    
 L  R484    
 L  R485    
 L  R486    
 L  R487    
 L  R488    
 L  R489    
 L  R490    
 L  R491    
 L  R492    
 L  R493    
 L  R494    
 L  R495    
 L  R496    
 L  R497    
 L  R498    
 L  R499    
 L  R500    
 L  R501    
 L  R502    
 L  R503    
 L  R504    
 L  R505    
 L  R506    
 L  R507    
 L  R508    
 L  R509    
 L  R510    
 L  R511    
 L  R512    
 L  R513    
 L  R514    
 L  R515    
 L  R516    
 L  R517    
 L  R518    
 L  R519    
 L  R520    
 L  R521    
 L  R522    
 L  R523    
 L  R524    
 L  R525    
 L  R526    
 L  R527    
 L  R528    
 L  R529    
 L  R530    
 L  R531    
 L  R532    
 L  R533    
 L  R534    
 L  R535    
 L  R536    
 L  R537    
 L  R538    
 L  R539    
 L  R540    
 L  R541    
 L  R542    
 L  R543    
 L  R544    
 L  R545    
 L  R546    
 L  R547    
 L  R548    
 L  R549    
 L  R550    
 L  R551    
 L  R552    
 L  R553    
 L  R554    
 L  R555    
 L  R556    
 L  R557    
 L  R558    
 L  R559    
 L  R560    
 L  R561    
 L  R562    
 L  R563    
 L  R564    
 L  R565    
 L  R566    
 L  R567    
 L  R568    
 L  R569    
 L  R570    
 L  R571    
 L  R572    
 L  R573    
 L  R574    
 L  R575    
 L  R576    
 L  R577    
 L  R578    
 L  R579    
 L  R580    
 L  R581    
 L  R582    
 L  R583    
 L  R584    
 L  R585    
 L  R586    
 L  R587    
 L  R588    
 L  R589    
 L  R590    
 L  R591    
 L  R592    
 L  R593    
 L  R594    
 L  R595    
 L  R596    
 L  R597    
 L  R598    
 L  R599    
 L  R600    
 L  R601    
 L  R602    
 L  R603    
 L  R604    
 L  R605    
 L  R606    
 L  R607    
 L  R608    
 L  R609    
 L  R610    
 L  R611    
 L  R612    
 L  R613    
 L  R614    
 L  R615    
 L  R616    
 L  R617    
 L  R618    
 L  R619    
 L  R620    
 L  R621    
 L  R622    
 L  R623    
 L  R624    
 L  R625    
 L  R626    
 L  R627    
 L  R628    
 L  R629    
 L  R630    
 L  R631    
 L  R632    
 L  R633    
 L  R634    
 L  R635    
 L  R636    
 L  R637    
 L  R638    
 L  R639    
 L  R640    
 L  R641    
 L  R642    
 L  R643    
 L  R644    
 L  R645    
 L  R646    
 L  R647    
 L  R648    
 L  R649    
 L  R650    
 L  R651    
 L  R652    
 L  R653    
 L  R654    
 L  R655    
 L  R656    
 L  R657    
 L  R658    
 L  R659    
 L  R660    
 L  R661    
 L  R662    
 L  R663    
 L  R664    
 L  R665    
 L  R666    
 L  R667    
 L  R668    
 L  R669    
 L  R670    
 L  R671    
 L  R672    
 L  R673    
 L  R674    
 L  R675    
 L  R676    
 L  R677    
 L  R678    
 L  R679    
 L  R680    
 L  R681    
 L  R682    
 L  R683    
 L  R684    
 L  R685    
 L  R686    
 L  R687    
 L  R688    
 L  R689    
 L  R690    
 L  R691    
 L  R692    
 L  R693    
 L  R694    
 L  R695    
 L  R696    
 L  R697    
 L  R698    
 L  R699    
 L  R700    
 L  R701    
 L  R702    
 L  R703    
 L  R704    
 L  R705    
 L  R706    
 L  R707    
 L  R708    
 L  R709    
 L  R710    
 L  R711    
 L  R712    
 L  R713    
 L  R714    
 L  R715    
 L  R716    
 L  R717    
 L  R718    
 L  R719    
 L  R720    
 L  R721    
 L  R722    
 L  R723    
 L  R724    
 L  R725    
 L  R726    
 L  R727    
 L  R728    
 L  R729    
 L  R730    
 L  R731    
 L  R732    
 L  R733    
 L  R734    
 L  R735    
 L  R736    
 L  R737    
 L  R738    
 L  R739    
 L  R740    
 L  R741    
 L  R742    
 L  R743    
 L  R744    
 L  R745    
 L  R746    
 L  R747    
 L  R748    
 L  R749    
 L  R750    
 L  R751    
 L  R752    
 L  R753    
 L  R754    
 L  R755    
 L  R756    
 L  R757    
 L  R758    
 L  R759    
 L  R760    
 L  R761    
 L  R762    
 L  R763    
 L  R764    
 L  R765    
 L  R766    
 L  R767    
 L  R768    
 L  R769    
 L  R770    
 L  R771    
 L  R772    
 L  R773    
 L  R774    
 L  R775    
 L  R776    
 L  R777    
 L  R778    
 L  R779    
 L  R780    
 L  R781    
 L  R782    
 L  R783    
 L  R784    
 L  R785    
 L  R786    
 L  R787    
 L  R788    
 L  R789    
 L  R790    
 L  R791    
 L  R792    
 L  R793    
 L  R794    
 L  R795    
 L  R796    
 L  R797    
 L  R798    
 L  R799    
 L  R800    
 L  R801    
 L  R802    
 L  R803    
 L  R804    
 L  R805    
 L  R806    
 L  R807    
 L  R808    
 L  R809    
 L  R810    
 L  R811    
 L  R812    
 L  R813    
 L  R814    
 L  R815    
 L  R816    
 L  R817    
 L  R818    
 L  R819    
 L  R820    
 L  R821    
 L  R822    
 L  R823    
 L  R824    
 L  R825    
 L  R826    
 L  R827    
 L  R828    
 L  R829    
 L  R830    
 L  R831    
 L  R832    
 L  R833    
 L  R834    
 L  R835    
 L  R836    
 L  R837    
 L  R838    
 L  R839    
 L  R840    
 L  R841    
 L  R842    
 L  R843    
 L  R844    
 L  R845    
 L  R846    
 L  R847    
 L  R848    
 L  R849    
 L  R850    
 L  R851    
 L  R852    
 L  R853    
 L  R854    
 L  R855    
 L  R856    
 L  R857    
 L  R858    
 L  R859    
 L  R860    
 L  R861    
 L  R862    
 L  R863    
 L  R864    
 L  R865    
 L  R866    
 L  R867    
 L  R868    
 L  R869    
 L  R870    
 L  R871    
 L  R872    
 L  R873    
 L  R874    
 L  R875    
 L  R876    
 L  R877    
 L  R878    
 L  R879    
 L  R880    
 L  R881    
 L  R882    
 L  R883    
 L  R884    
 L  R885    
 L  R886    
 L  R887    
 L  R888    
 L  R889    
 L  R890    
 L  R891    
 L  R892    
 L  R893    
 L  R894    
 L  R895    
 L  R896    
 L  R897    
 L  R898    
 L  R899    
 L  R900    
 L  R901    
 L  R902    
 L  R903    
 L  R904    
 L  R905    
 L  R906    
 L  R907    
 L  R908    
 L  R909    
 L  R910    
 L  R911    
 L  R912    
 L  R913    
 L  R914    
 L  R915    
 L  R916    
 L  R917    
 L  R918    
 L  R919    
 L  R920    
 L  R921    
 L  R922    
 L  R923    
 L  R924    
 L  R925    
 L  R926    
 L  R927    
 L  R928    
 L  R929    
 L  R930    
 L  R931    
 L  R932    
 L  R933    
 L  R934    
 L  R935    
 L  R936    
 L  R937    
 L  R938    
 L  R939    
 L  R940    
 L  R941    
 L  R942    
 L  R943    
 L  R944    
 L  R945    
 L  R946    
 L  R947    
 L  R948    
 L  R949    
 L  R950    
 L  R951    
 L  R952    
 L  R953    
 L  R954    
 L  R955    
 L  R956    
 L  R957    
 L  R958    
 L  R959    
 L  R960    
 L  R961    
 L  R962    
 L  R963    
 L  R964    
 L  R965    
 L  R966    
 L  R967    
 L  R968    
 L  R969    
 L  R970    
 L  R971    
 L  R972    
 L  R973    
 L  R974    
 L  R975    
 L  R976    
 L  R977    
 L  R978    
 L  R979    
 L  R980    
 L  R981    
 L  R982    
 L  R983    
 L  R984    
 L  R985    
 L  R986    
 L  R987    
 L  R988    
 L  R989    
 L  R990    
 L  R991    
 L  R992    
 L  R993    
 L  R994    
 L  R995    
 L  R996    
 L  R997    
 L  R998    
 L  R999    
 L  R1000   
 L  R1001   
 L  R1002   
 L  R1003   
 L  R1004   
 L  R1005   
 L  R1006   
 L  R1007   
 L  R1008   
 L  R1009   
 L  R1010   
 L  R1011   
 L  R1012   
 L  R1013   
 L  R1014   
 L  R1015   
 L  R1016   
 L  R1017   
 L  R1018   
 L  R1019   
 L  R1020   
 L  R1021   
 L  R1022   
 L  R1023   
 L  R1024   
 L  R1025   
 L  R1026   
 L  R1027   
 L  R1028   
 L  R1029   
 L  R1030   
 L  R1031   
 L  R1032   
 L  R1033   
 L  R1034   
 L  R1035   
 L  R1036   
 L  R1037   
 L  R1038   
 L  R1039   
 L  R1040   
 L  R1041   
 L  R1042   
 L  R1043   
 L  R1044   
 L  R1045   
 L  R1046   
 L  R1047   
 L  R1048   
 L  R1049   
 L  R1050   
 L  R1051   
 L  R1052   
 L  R1053   
 L  R1054   
 L  R1055   
 L  R1056   
 L  R1057   
 L  R1058   
 L  R1059   
 L  R1060   
 L  R1061   
 L  R1062   
 L  R1063   
 L  R1064   
 L  R1065   
 L  R1066   
 L  R1067   
 L  R1068   
 L  R1069   
 L  R1070   
 L  R1071   
 L  R1072   
 L  R1073   
 L  R1074   
 L  R1075   
 L  R1076   
 L  R1077   
 L  R1078   
 L  R1079   
 L  R1080   
 L  R1081   
 L  R1082   
 L  R1083   
 L  R1084   
 L  R1085   
 L  R1086   
 L  R1087   
 L  R1088   
 L  R1089   
 L  R1090   
 L  R1091   
 L  R1092   
 L  R1093   
 L  R1094   
 L  R1095   
 L  R1096   
 L  R1097   
 L  R1098   
 L  R1099   
 L  R1100   
 L  R1101   
 L  R1102   
 L  R1103   
 L  R1104   
 L  R1105   
 L  R1106   
 L  R1107   
 L  R1108   
 L  R1109   
 L  R1110   
 L  R1111   
 L  R1112   
 L  R1113   
 L  R1114   
 L  R1115   
 L  R1116   
 L  R1117   
 L  R1118   
 L  R1119   
 L  R1120   
 L  R1121   
 L  R1122   
 L  R1123   
 L  R1124   
 L  R1125   
 L  R1126   
 L  R1127   
 L  R1128   
 L  R1129   
 L  R1130   
 L  R1131   
 L  R1132   
 L  R1133   
 L  R1134   
 L  R1135   
 L  R1136   
 L  R1137   
 L  R1138   
 L  R1139   
 L  R1140   
 L  R1141   
 L  R1142   
 L  R1143   
 L  R1144   
 L  R1145   
 L  R1146   
 L  R1147   
 L  R1148   
 L  R1149   
 L  R1150   
 L  R1151   
 L  R1152   
 L  R1153   
 L  R1154   
 L  R1155   
 L  R1156   
 L  R1157   
 L  R1158   
 L  R1159   
 L  R1160   
 L  R1161   
 L  R1162   
 L  R1163   
 L  R1164   
 L  R1165   
 L  R1166   
 L  R1167   
 L  R1168   
 L  R1169   
 L  R1170   
 L  R1171   
 L  R1172   
 L  R1173   
 L  R1174   
 L  R1175   
 L  R1176   
 L  R1177   
 L  R1178   
 L  R1179   
 L  R1180   
 L  R1181   
 L  R1182   
 L  R1183   
 L  R1184   
 L  R1185   
 L  R1186   
 L  R1187   
 L  R1188   
 L  R1189   
 L  R1190   
 L  R1191   
 L  R1192   
 L  R1193   
 L  R1194   
 L  R1195   
 L  R1196   
 L  R1197   
 L  R1198   
 L  R1199   
 L  R1200   
 L  R1201   
 L  R1202   
 L  R1203   
 L  R1204   
 L  R1205   
 L  R1206   
 L  R1207   
 L  R1208   
 L  R1209   
 L  R1210   
 L  R1211   
 L  R1212   
 L  R1213   
 L  R1214   
 L  R1215   
 L  R1216   
 L  R1217   
 L  R1218   
 L  R1219   
 L  R1220   
 L  R1221   
 L  R1222   
 L  R1223   
 L  R1224   
 L  R1225   
 L  R1226   
 L  R1227   
 L  R1228   
 L  R1229   
 L  R1230   
 L  R1231   
 L  R1232   
 L  R1233   
 L  R1234   
 L  R1235   
 L  R1236   
 L  R1237   
 L  R1238   
 L  R1239   
 L  R1240   
 L  R1241   
 L  R1242   
 L  R1243   
 L  R1244   
 L  R1245   
 L  R1246   
 L  R1247   
 L  R1248   
 L  R1249   
 L  R1250   
 L  R1251   
 L  R1252   
 L  R1253   
 L  R1254   
 L  R1255   
 L  R1256   
 L  R1257   
 L  R1258   
 L  R1259   
 L  R1260   
 L  R1261   
 L  R1262   
 L  R1263   
 L  R1264   
 L  R1265   
 L  R1266   
 L  R1267   
 L  R1268   
 L  R1269   
 L  R1270   
 L  R1271   
 L  R1272   
 L  R1273   
 L  R1274   
 L  R1275   
 L  R1276   
 L  R1277   
 L  R1278   
 L  R1279   
 L  R1280   
 L  R1281   
 L  R1282   
 L  R1283   
 L  R1284   
 L  R1285   
 L  R1286   
 L  R1287   
 L  R1288   
 L  R1289   
 L  R1290   
 L  R1291   
 L  R1292   
 L  R1293   
 L  R1294   
 L  R1295   
 L  R1296   
 L  R1297   
 L  R1298   
 L  R1299   
 L  R1300   
 L  R1301   
 L  R1302   
 L  R1303   
 L  R1304   
 L  R1305   
 L  R1306   
 L  R1307   
 L  R1308   
 L  R1309   
 L  R1310   
 L  R1311   
 L  R1312   
 L  R1313   
 L  R1314   
 L  R1315   
 L  R1316   
 L  R1317   
 L  R1318   
 L  R1319   
 L  R1320   
 L  R1321   
 L  R1322   
 L  R1323   
 L  R1324   
 L  R1325   
 L  R1326   
 L  R1327   
 L  R1328   
 L  R1329   
 L  R1330   
 L  R1331   
 L  R1332   
 L  R1333   
 L  R1334   
 L  R1335   
 L  R1336   
 L  R1337   
 L  R1338   
 L  R1339   
 L  R1340   
 L  R1341   
 L  R1342   
 L  R1343   
 L  R1344   
 L  R1345   
 L  R1346   
 L  R1347   
 L  R1348   
 L  R1349   
 L  R1350   
 L  R1351   
 L  R1352   
 L  R1353   
 L  R1354   
 L  R1355   
 L  R1356   
 L  R1357   
 L  R1358   
 L  R1359   
 L  R1360   
 L  R1361   
 L  R1362   
 L  R1363   
 L  R1364   
 L  R1365   
 L  R1366   
 L  R1367   
 L  R1368   
 L  R1369   
 L  R1370   
 L  R1371   
 L  R1372   
 L  R1373   
 L  R1374   
 L  R1375   
 L  R1376   
 L  R1377   
 L  R1378   
 L  R1379   
 L  R1380   
 L  R1381   
 L  R1382   
 L  R1383   
 L  R1384   
 L  R1385   
 L  R1386   
 L  R1387   
 L  R1388   
 L  R1389   
 L  R1390   
 L  R1391   
 L  R1392   
 L  R1393   
 L  R1394   
 L  R1395   
 L  R1396   
 L  R1397   
 L  R1398   
 L  R1399   
 L  R1400   
 L  R1401   
 L  R1402   
 L  R1403   
 L  R1404   
 L  R1405   
 L  R1406   
 L  R1407   
 L  R1408   
 L  R1409   
 L  R1410   
 L  R1411   
 L  R1412   
 L  R1413   
 L  R1414   
 L  R1415   
 L  R1416   
 L  R1417   
 L  R1418   
 L  R1419   
 L  R1420   
 L  R1421   
 L  R1422   
 L  R1423   
 L  R1424   
 L  R1425   
 L  R1426   
 L  R1427   
 L  R1428   
 L  R1429   
 L  R1430   
 L  R1431   
 L  R1432   
 L  R1433   
 L  R1434   
 L  R1435   
 L  R1436   
 L  R1437   
 L  R1438   
 L  R1439   
 L  R1440   
 L  R1441   
 L  R1442   
 L  R1443   
 L  R1444   
 L  R1445   
 L  R1446   
 L  R1447   
 L  R1448   
 L  R1449   
 L  R1450   
 L  R1451   
 L  R1452   
 L  R1453   
 L  R1454   
 L  R1455   
 L  R1456   
 L  R1457   
 L  R1458   
 L  R1459   
 L  R1460   
 L  R1461   
 L  R1462   
 L  R1463   
 L  R1464   
 L  R1465   
 L  R1466   
 L  R1467   
 L  R1468   
 L  R1469   
 L  R1470   
 L  R1471   
 L  R1472   
 L  R1473   
 L  R1474   
 L  R1475   
 L  R1476   
 L  R1477   
 L  R1478   
 L  R1479   
 L  R1480   
 L  R1481   
 L  R1482   
 L  R1483   
 L  R1484   
 L  R1485   
 L  R1486   
 L  R1487   
 L  R1488   
 L  R1489   
 L  R1490   
 L  R1491   
 L  R1492   
 L  R1493   
 L  R1494   
 L  R1495   
 L  R1496   
 L  R1497   
 L  R1498   
 L  R1499   
 L  R1500   
 L  R1501   
 L  R1502   
 L  R1503   
 L  R1504   
 L  R1505   
 L  R1506   
 L  R1507   
 L  R1508   
 L  R1509   
 L  R1510   
 L  R1511   
 L  R1512   
 L  R1513   
 L  R1514   
 L  R1515   
 L  R1516   
 L  R1517   
 L  R1518   
 L  R1519   
 L  R1520   
 L  R1521   
 L  R1522   
 L  R1523   
 L  R1524   
 L  R1525   
 L  R1526   
 L  R1527   
 L  R1528   
 L  R1529   
 L  R1530   
 L  R1531   
 L  R1532   
 L  R1533   
 L  R1534   
 L  R1535   
 L  R1536   
 L  R1537   
 L  R1538   
 L  R1539   
 L  R1540   
 L  R1541   
 L  R1542   
 L  R1543   
 L  R1544   
 L  R1545   
 L  R1546   
 L  R1547   
 L  R1548   
 L  R1549   
 L  R1550   
 L  R1551   
 L  R1552   
 L  R1553   
 L  R1554   
 L  R1555   
 L  R1556   
 L  R1557   
 L  R1558   
 L  R1559   
 L  R1560   
 L  R1561   
 L  R1562   
 L  R1563   
 L  R1564   
 L  R1565   
 L  R1566   
 L  R1567   
 L  R1568   
 L  R1569   
 L  R1570   
 L  R1571   
 L  R1572   
 L  R1573   
 L  R1574   
 L  R1575   
 L  R1576   
 L  R1577   
 L  R1578   
 L  R1579   
 L  R1580   
 L  R1581   
 L  R1582   
 L  R1583   
 L  R1584   
 L  R1585   
 L  R1586   
 L  R1587   
 L  R1588   
 L  R1589   
 L  R1590   
 L  R1591   
 L  R1592   
 L  R1593   
 L  R1594   
 L  R1595   
 L  R1596   
 L  R1597   
 L  R1598   
 L  R1599   
 L  R1600   
 L  R1601   
 L  R1602   
 L  R1603   
 L  R1604   
 L  R1605   
 L  R1606   
 L  R1607   
 L  R1608   
 L  R1609   
 L  R1610   
 L  R1611   
 L  R1612   
 L  R1613   
 L  R1614   
 L  R1615   
 L  R1616   
 L  R1617   
 L  R1618   
 L  R1619   
 L  R1620   
 L  R1621   
 L  R1622   
 L  R1623   
 L  R1624   
 L  R1625   
 L  R1626   
 L  R1627   
 L  R1628   
 L  R1629   
 L  R1630   
 L  R1631   
 L  R1632   
 L  R1633   
 L  R1634   
 L  R1635   
 L  R1636   
 L  R1637   
 L  R1638   
 L  R1639   
 L  R1640   
 L  R1641   
 L  R1642   
 L  R1643   
 L  R1644   
 L  R1645   
 L  R1646   
 L  R1647   
 L  R1648   
 L  R1649   
 L  R1650   
 L  R1651   
 L  R1652   
 L  R1653   
 L  R1654   
 L  R1655   
 L  R1656   
 L  R1657   
 L  R1658   
 L  R1659   
 L  R1660   
 L  R1661   
 L  R1662   
 L  R1663   
 L  R1664   
 L  R1665   
 L  R1666   
 L  R1667   
 L  R1668   
 L  R1669   
 L  R1670   
 L  R1671   
 L  R1672   
 L  R1673   
 L  R1674   
 L  R1675   
 L  R1676   
 L  R1677   
 L  R1678   
 L  R1679   
 L  R1680   
 L  R1681   
 L  R1682   
 L  R1683   
 L  R1684   
 L  R1685   
 L  R1686   
 L  R1687   
 L  R1688   
 L  R1689   
 L  R1690   
 L  R1691   
 L  R1692   
 L  R1693   
 L  R1694   
 L  R1695   
 L  R1696   
 L  R1697   
 L  R1698   
 L  R1699   
 L  R1700   
 L  R1701   
 L  R1702   
 L  R1703   
 L  R1704   
 L  R1705   
 L  R1706   
 L  R1707   
 L  R1708   
 L  R1709   
 L  R1710   
 L  R1711   
 L  R1712   
 L  R1713   
 L  R1714   
 L  R1715   
 L  R1716   
 L  R1717   
 L  R1718   
 L  R1719   
 L  R1720   
 L  R1721   
 L  R1722   
 L  R1723   
 L  R1724   
 L  R1725   
 L  R1726   
 L  R1727   
 L  R1728   
 L  R1729   
 L  R1730   
 L  R1731   
 L  R1732   
 L  R1733   
 L  R1734   
 L  R1735   
 L  R1736   
 L  R1737   
 L  R1738   
 L  R1739   
 L  R1740   
 L  R1741   
 L  R1742   
 L  R1743   
 L  R1744   
 L  R1745   
 L  R1746   
 L  R1747   
 L  R1748   
 L  R1749   
 L  R1750   
 L  R1751   
 L  R1752   
 L  R1753   
 L  R1754   
 L  R1755   
 L  R1756   
 L  R1757   
 L  R1758   
 L  R1759   
 L  R1760   
 L  R1761   
 L  R1762   
 L  R1763   
 L  R1764   
 L  R1765   
 L  R1766   
 L  R1767   
 L  R1768   
 L  R1769   
 L  R1770   
 L  R1771   
 L  R1772   
 L  R1773   
 L  R1774   
 L  R1775   
 L  R1776   
 L  R1777   
 L  R1778   
 L  R1779   
 L  R1780   
 L  R1781   
 L  R1782   
 L  R1783   
 L  R1784   
 L  R1785   
 L  R1786   
 L  R1787   
 L  R1788   
 L  R1789   
 L  R1790   
 L  R1791   
 L  R1792   
 L  R1793   
 L  R1794   
 L  R1795   
 L  R1796   
 L  R1797   
 L  R1798   
 L  R1799   
 L  R1800   
 L  R1801   
 L  R1802   
 L  R1803   
 L  R1804   
 L  R1805   
 L  R1806   
 L  R1807   
 L  R1808   
 L  R1809   
 L  R1810   
 L  R1811   
 L  R1812   
 L  R1813   
 L  R1814   
 L  R1815   
 L  R1816   
 L  R1817   
 L  R1818   
 L  R1819   
 L  R1820   
 L  R1821   
 L  R1822   
 L  R1823   
 L  R1824   
 L  R1825   
 L  R1826   
 L  R1827   
 L  R1828   
 L  R1829   
 L  R1830   
 L  R1831   
 L  R1832   
 L  R1833   
 L  R1834   
 L  R1835   
 L  R1836   
 L  R1837   
 L  R1838   
 L  R1839   
 L  R1840   
 L  R1841   
 L  R1842   
 L  R1843   
 L  R1844   
 L  R1845   
 L  R1846   
 L  R1847   
 L  R1848   
 L  R1849   
 L  R1850   
 L  R1851   
 L  R1852   
 L  R1853   
 L  R1854   
 L  R1855   
 L  R1856   
 L  R1857   
 L  R1858   
 L  R1859   
 L  R1860   
 L  R1861   
 L  R1862   
 L  R1863   
 L  R1864   
 L  R1865   
 L  R1866   
 L  R1867   
 L  R1868   
 L  R1869   
 L  R1870   
 L  R1871   
 L  R1872   
 L  R1873   
 L  R1874   
 L  R1875   
 L  R1876   
 L  R1877   
 L  R1878   
 L  R1879   
 L  R1880   
 L  R1881   
 L  R1882   
 L  R1883   
 L  R1884   
 L  R1885   
 L  R1886   
 L  R1887   
 L  R1888   
 L  R1889   
 L  R1890   
 L  R1891   
 L  R1892   
 L  R1893   
 L  R1894   
 L  R1895   
 L  R1896   
 L  R1897   
 L  R1898   
 L  R1899   
 L  R1900   
 L  R1901   
 L  R1902   
 L  R1903   
 L  R1904   
 L  R1905   
 L  R1906   
 L  R1907   
 L  R1908   
 L  R1909   
 L  R1910   
 L  R1911   
 L  R1912   
 L  R1913   
 L  R1914   
 L  R1915   
 L  R1916   
 L  R1917   
 L  R1918   
 L  R1919   
 L  R1920   
 L  R1921   
 L  R1922   
 L  R1923   
 L  R1924   
 L  R1925   
 L  R1926   
 L  R1927   
 L  R1928   
 L  R1929   
 L  R1930   
 L  R1931   
 L  R1932   
 L  R1933   
 L  R1934   
 L  R1935   
 L  R1936   
 L  R1937   
 L  R1938   
 L  R1939   
 L  R1940   
 L  R1941   
 L  R1942   
 L  R1943   
 L  R1944   
 L  R1945   
 L  R1946   
 L  R1947   
 L  R1948   
 L  R1949   
 L  R1950   
 L  R1951   
 L  R1952   
 L  R1953   
 L  R1954   
 L  R1955   
 L  R1956   
 L  R1957   
 L  R1958   
 L  R1959   
 L  R1960   
 L  R1961   
 L  R1962   
 L  R1963   
 L  R1964   
 L  R1965   
 L  R1966   
 L  R1967   
 L  R1968   
 L  R1969   
 L  R1970   
 L  R1971   
 L  R1972   
 L  R1973   
 L  R1974   
 L  R1975   
 L  R1976   
 L  R1977   
 L  R1978   
 L  R1979   
 L  R1980   
 L  R1981   
 L  R1982   
 L  R1983   
 L  R1984   
 L  R1985   
 L  R1986   
 L  R1987   
 L  R1988   
 L  R1989   
 L  R1990   
 L  R1991   
 L  R1992   
 L  R1993   
 L  R1994   
 L  R1995   
 L  R1996   
 L  R1997   
 L  R1998   
 L  R1999   
 L  R2000   
 L  R2001   
 L  R2002   
 L  R2003   
 L  R2004   
 L  R2005   
 L  R2006   
 L  R2007   
 L  R2008   
 L  R2009   
 L  R2010   
 L  R2011   
 L  R2012   
 L  R2013   
 L  R2014   
 L  R2015   
 L  R2016   
 L  R2017   
 L  R2018   
 L  R2019   
 L  R2020   
 L  R2021   
 L  R2022   
 L  R2023   
 L  R2024   
 L  R2025   
 L  R2026   
 L  R2027   
 L  R2028   
 L  R2029   
 L  R2030   
 L  R2031   
 L  R2032   
 L  R2033   
 L  R2034   
 L  R2035   
 L  R2036   
 L  R2037   
 L  R2038   
 L  R2039   
 L  R2040   
 L  R2041   
 L  R2042   
 L  R2043   
 L  R2044   
 L  R2045   
 L  R2046   
 L  R2047   
 L  R2048   
 L  R2049   
 L  R2050   
 L  R2051   
 L  R2052   
 L  R2053   
 L  R2054   
 L  R2055   
 L  R2056   
 L  R2057   
 L  R2058   
 L  R2059   
 L  R2060   
 L  R2061   
 L  R2062   
 L  R2063   
 L  R2064   
 L  R2065   
 L  R2066   
 L  R2067   
 L  R2068   
 L  R2069   
 L  R2070   
 L  R2071   
 L  R2072   
 L  R2073   
 L  R2074   
 L  R2075   
 L  R2076   
 L  R2077   
 L  R2078   
 L  R2079   
 L  R2080   
 L  R2081   
 L  R2082   
 L  R2083   
 L  R2084   
 L  R2085   
 L  R2086   
 L  R2087   
 L  R2088   
 L  R2089   
 L  R2090   
 L  R2091   
 L  R2092   
 L  R2093   
 L  R2094   
 L  R2095   
 L  R2096   
 L  R2097   
 L  R2098   
 L  R2099   
 L  R2100   
 L  R2101   
 L  R2102   
 L  R2103   
 L  R2104   
 L  R2105   
 L  R2106   
 L  R2107   
 L  R2108   
 L  R2109   
 L  R2110   
 L  R2111   
 L  R2112   
 L  R2113   
 L  R2114   
 L  R2115   
 L  R2116   
 L  R2117   
 L  R2118   
 L  R2119   
 L  R2120   
 L  R2121   
 L  R2122   
 L  R2123   
 L  R2124   
 L  R2125   
 L  R2126   
 L  R2127   
 L  R2128   
 L  R2129   
 L  R2130   
 L  R2131   
 L  R2132   
 L  R2133   
 L  R2134   
 L  R2135   
 L  R2136   
 L  R2137   
 L  R2138   
 L  R2139   
 L  R2140   
 L  R2141   
 L  R2142   
 L  R2143   
 L  R2144   
 L  R2145   
 L  R2146   
 L  R2147   
 L  R2148   
 L  R2149   
 L  R2150   
 L  R2151   
 L  R2152   
 L  R2153   
 L  R2154   
 L  R2155   
 L  R2156   
 L  R2157   
 L  R2158   
 L  R2159   
 L  R2160   
 L  R2161   
 L  R2162   
 L  R2163   
 L  R2164   
 L  R2165   
 L  R2166   
 L  R2167   
 L  R2168   
 L  R2169   
 L  R2170   
 L  R2171   
 L  R2172   
 L  R2173   
 L  R2174   
 L  R2175   
 L  R2176   
 L  R2177   
 L  R2178   
 L  R2179   
 L  R2180   
 L  R2181   
 L  R2182   
 L  R2183   
 L  R2184   
 L  R2185   
 L  R2186   
 L  R2187   
 L  R2188   
 L  R2189   
 L  R2190   
 L  R2191   
 L  R2192   
 L  R2193   
 L  R2194   
 L  R2195   
 L  R2196   
 L  R2197   
 L  R2198   
 L  R2199   
 L  R2200   
 L  R2201   
 L  R2202   
 L  R2203   
 L  R2204   
 L  R2205   
 L  R2206   
 L  R2207   
 L  R2208   
 L  R2209   
 L  R2210   
 L  R2211   
 L  R2212   
 L  R2213   
 L  R2214   
 L  R2215   
 L  R2216   
 L  R2217   
 L  R2218   
 L  R2219   
 L  R2220   
 L  R2221   
 L  R2222   
 L  R2223   
 L  R2224   
 L  R2225   
 L  R2226   
 L  R2227   
 L  R2228   
 L  R2229   
 L  R2230   
 L  R2231   
 L  R2232   
 L  R2233   
 L  R2234   
 L  R2235   
 L  R2236   
 L  R2237   
 L  R2238   
 L  R2239   
 L  R2240   
 L  R2241   
 L  R2242   
 L  R2243   
 L  R2244   
 L  R2245   
 L  R2246   
 L  R2247   
 L  R2248   
 L  R2249   
 L  R2250   
 L  R2251   
 L  R2252   
 L  R2253   
 L  R2254   
 L  R2255   
 L  R2256   
 L  R2257   
 L  R2258   
 L  R2259   
 L  R2260   
 L  R2261   
 L  R2262   
 L  R2263   
 L  R2264   
 L  R2265   
 L  R2266   
 L  R2267   
 L  R2268   
 L  R2269   
 L  R2270   
 L  R2271   
 L  R2272   
 L  R2273   
 L  R2274   
 L  R2275   
 L  R2276   
 L  R2277   
 L  R2278   
 L  R2279   
 L  R2280   
 L  R2281   
 L  R2282   
 L  R2283   
 L  R2284   
 L  R2285   
 L  R2286   
 L  R2287   
 L  R2288   
 L  R2289   
 L  R2290   
 L  R2291   
 L  R2292   
 L  R2293   
 L  R2294   
 L  R2295   
 L  R2296   
 L  R2297   
 L  R2298   
 L  R2299   
 L  R2300   
 L  R2301   
 L  R2302   
 L  R2303   
 L  R2304   
 L  R2305   
 L  R2306   
 L  R2307   
 L  R2308   
 L  R2309   
 L  R2310   
 L  R2311   
 L  R2312   
 L  R2313   
 L  R2314   
 L  R2315   
 L  R2316   
 L  R2317   
 L  R2318   
 L  R2319   
 L  R2320   
 L  R2321   
 L  R2322   
 L  R2323   
 L  R2324   
 L  R2325   
 L  R2326   
 L  R2327   
 L  R2328   
 L  R2329   
 L  R2330   
 L  R2331   
 L  R2332   
 L  R2333   
 L  R2334   
 L  R2335   
 L  R2336   
 L  R2337   
 L  R2338   
 L  R2339   
 L  R2340   
 L  R2341   
 L  R2342   
 L  R2343   
 L  R2344   
 L  R2345   
 L  R2346   
 L  R2347   
 L  R2348   
 L  R2349   
 L  R2350   
 L  R2351   
 L  R2352   
 L  R2353   
 L  R2354   
 L  R2355   
 L  R2356   
 L  R2357   
 L  R2358   
 L  R2359   
 L  R2360   
 L  R2361   
 L  R2362   
 L  R2363   
 L  R2364   
 L  R2365   
 L  R2366   
 L  R2367   
 L  R2368   
 L  R2369   
 L  R2370   
 L  R2371   
 L  R2372   
 L  R2373   
 L  R2374   
 L  R2375   
 L  R2376   
 L  R2377   
 L  R2378   
 L  R2379   
 L  R2380   
 L  R2381   
 L  R2382   
 L  R2383   
 L  R2384   
 L  R2385   
 L  R2386   
 L  R2387   
 L  R2388   
 L  R2389   
 L  R2390   
 L  R2391   
 L  R2392   
 L  R2393   
 L  R2394   
 L  R2395   
 L  R2396   
 L  R2397   
 L  R2398   
 L  R2399   
 L  R2400   
 L  R2401   
 L  R2402   
 L  R2403   
 L  R2404   
 L  R2405   
 L  R2406   
 L  R2407   
 L  R2408   
 L  R2409   
 L  R2410   
 L  R2411   
 L  R2412   
 L  R2413   
 L  R2414   
 L  R2415   
 L  R2416   
 L  R2417   
 L  R2418   
 L  R2419   
 L  R2420   
 L  R2421   
 L  R2422   
 L  R2423   
 L  R2424   
 L  R2425   
 L  R2426   
 L  R2427   
 L  R2428   
 L  R2429   
 L  R2430   
 L  R2431   
 L  R2432   
 L  R2433   
 L  R2434   
 L  R2435   
 L  R2436   
 L  R2437   
 L  R2438   
 L  R2439   
 L  R2440   
 L  R2441   
 L  R2442   
 L  R2443   
 L  R2444   
 L  R2445   
 L  R2446   
 L  R2447   
 L  R2448   
 L  R2449   
 L  R2450   
 L  R2451   
 L  R2452   
 L  R2453   
 L  R2454   
 L  R2455   
 L  R2456   
 L  R2457   
 L  R2458   
 L  R2459   
 L  R2460   
 L  R2461   
 L  R2462   
 L  R2463   
 L  R2464   
 L  R2465   
 L  R2466   
 L  R2467   
 L  R2468   
 L  R2469   
 L  R2470   
 L  R2471   
 L  R2472   
 L  R2473   
 L  R2474   
 L  R2475   
 L  R2476   
 L  R2477   
 L  R2478   
 L  R2479   
 L  R2480   
 L  R2481   
 L  R2482   
 L  R2483   
 L  R2484   
 L  R2485   
 L  R2486   
 L  R2487   
 L  R2488   
 L  R2489   
 L  R2490   
 L  R2491   
 L  R2492   
 L  R2493   
 L  R2494   
 L  R2495   
 L  R2496   
 L  R2497   
 L  R2498   
 L  R2499   
 L  R2500   
 L  R2501   
 L  R2502   
 L  R2503   
 L  R2504   
 L  R2505   
 L  R2506   
 L  R2507   
 L  R2508   
 L  R2509   
 L  R2510   
 L  R2511   
 L  R2512   
 L  R2513   
 L  R2514   
 L  R2515   
 L  R2516   
 L  R2517   
 L  R2518   
 L  R2519   
 L  R2520   
 L  R2521   
 L  R2522   
 L  R2523   
 L  R2524   
 L  R2525   
 L  R2526   
 L  R2527   
 L  R2528   
 L  R2529   
 L  R2530   
 L  R2531   
 L  R2532   
 L  R2533   
 L  R2534   
 L  R2535   
 L  R2536   
 L  R2537   
 L  R2538   
 L  R2539   
 L  R2540   
 L  R2541   
 L  R2542   
 L  R2543   
 L  R2544   
 L  R2545   
 L  R2546   
 L  R2547   
 L  R2548   
 L  R2549   
 L  R2550   
 L  R2551   
 L  R2552   
 L  R2553   
 L  R2554   
 L  R2555   
 L  R2556   
 L  R2557   
 L  R2558   
 L  R2559   
 L  R2560   
 L  R2561   
 L  R2562   
 L  R2563   
 L  R2564   
 L  R2565   
 L  R2566   
 L  R2567   
 L  R2568   
 L  R2569   
 L  R2570   
 L  R2571   
 L  R2572   
 L  R2573   
 L  R2574   
 L  R2575   
 L  R2576   
 L  R2577   
 L  R2578   
 L  R2579   
 L  R2580   
 L  R2581   
 L  R2582   
 L  R2583   
 L  R2584   
 L  R2585   
 L  R2586   
 L  R2587   
 L  R2588   
 L  R2589   
 L  R2590   
 L  R2591   
 L  R2592   
 L  R2593   
 L  R2594   
 L  R2595   
 L  R2596   
 L  R2597   
 L  R2598   
 L  R2599   
 L  R2600   
 L  R2601   
 L  R2602   
 L  R2603   
 L  R2604   
 L  R2605   
 L  R2606   
 L  R2607   
 L  R2608   
 L  R2609   
 L  R2610   
 L  R2611   
 L  R2612   
 L  R2613   
 L  R2614   
 L  R2615   
 L  R2616   
 L  R2617   
 L  R2618   
 L  R2619   
 L  R2620   
 L  R2621   
 L  R2622   
 L  R2623   
 L  R2624   
 L  R2625   
 L  R2626   
 L  R2627   
 L  R2628   
 L  R2629   
 L  R2630   
 L  R2631   
 L  R2632   
 L  R2633   
 L  R2634   
 L  R2635   
 L  R2636   
 L  R2637   
 L  R2638   
 L  R2639   
 L  R2640   
 L  R2641   
 L  R2642   
 L  R2643   
 L  R2644   
 L  R2645   
 L  R2646   
 L  R2647   
 L  R2648   
 L  R2649   
 L  R2650   
 L  R2651   
 L  R2652   
 L  R2653   
 L  R2654   
 L  R2655   
 L  R2656   
 L  R2657   
 L  R2658   
 L  R2659   
 L  R2660   
 L  R2661   
 L  R2662   
 L  R2663   
 L  R2664   
 L  R2665   
 L  R2666   
 L  R2667   
 L  R2668   
 L  R2669   
 L  R2670   
 L  R2671   
 L  R2672   
 L  R2673   
 L  R2674   
 L  R2675   
 L  R2676   
 L  R2677   
 L  R2678   
 L  R2679   
 L  R2680   
 L  R2681   
 L  R2682   
 L  R2683   
 L  R2684   
 L  R2685   
 L  R2686   
 L  R2687   
 L  R2688   
 L  R2689   
 L  R2690   
 L  R2691   
 L  R2692   
 L  R2693   
 L  R2694   
 L  R2695   
 L  R2696   
 L  R2697   
 L  R2698   
 L  R2699   
 L  R2700   
 L  R2701   
 L  R2702   
 L  R2703   
 L  R2704   
 L  R2705   
 L  R2706   
 L  R2707   
 L  R2708   
 L  R2709   
 L  R2710   
 L  R2711   
 L  R2712   
 L  R2713   
 L  R2714   
 L  R2715   
 L  R2716   
 L  R2717   
 L  R2718   
 L  R2719   
 L  R2720   
 L  R2721   
 L  R2722   
 L  R2723   
 L  R2724   
 L  R2725   
 L  R2726   
 L  R2727   
 L  R2728   
 L  R2729   
 L  R2730   
 L  R2731   
 L  R2732   
 L  R2733   
 L  R2734   
 L  R2735   
 L  R2736   
 L  R2737   
 L  R2738   
 L  R2739   
 L  R2740   
 L  R2741   
 L  R2742   
 L  R2743   
 L  R2744   
 L  R2745   
 L  R2746   
 L  R2747   
 L  R2748   
 L  R2749   
 L  R2750   
 L  R2751   
 L  R2752   
 L  R2753   
 L  R2754   
 L  R2755   
 L  R2756   
 L  R2757   
 L  R2758   
 L  R2759   
 L  R2760   
 L  R2761   
 L  R2762   
 L  R2763   
 L  R2764   
 L  R2765   
 L  R2766   
 L  R2767   
 L  R2768   
 L  R2769   
 L  R2770   
 L  R2771   
 L  R2772   
 L  R2773   
 L  R2774   
 L  R2775   
 L  R2776   
 L  R2777   
 L  R2778   
 L  R2779   
 L  R2780   
 L  R2781   
 L  R2782   
 L  R2783   
 L  R2784   
 L  R2785   
 L  R2786   
 L  R2787   
 L  R2788   
 L  R2789   
 L  R2790   
 L  R2791   
 L  R2792   
 L  R2793   
 L  R2794   
 L  R2795   
 L  R2796   
 L  R2797   
 L  R2798   
 L  R2799   
 L  R2800   
 L  R2801   
 L  R2802   
 L  R2803   
 L  R2804   
 L  R2805   
 L  R2806   
 L  R2807   
 L  R2808   
 L  R2809   
 L  R2810   
 L  R2811   
 L  R2812   
 L  R2813   
 L  R2814   
 L  R2815   
 L  R2816   
 L  R2817   
 L  R2818   
 L  R2819   
 L  R2820   
 L  R2821   
 L  R2822   
 L  R2823   
 L  R2824   
 L  R2825   
 L  R2826   
 L  R2827   
 L  R2828   
 L  R2829   
 L  R2830   
 L  R2831   
 L  R2832   
 L  R2833   
 L  R2834   
 L  R2835   
 L  R2836   
 L  R2837   
 L  R2838   
 L  R2839   
 L  R2840   
 L  R2841   
 L  R2842   
 L  R2843   
 L  R2844   
 L  R2845   
 L  R2846   
 L  R2847   
 L  R2848   
 L  R2849   
 L  R2850   
 L  R2851   
 L  R2852   
 L  R2853   
 L  R2854   
 L  R2855   
 L  R2856   
 L  R2857   
 L  R2858   
 L  R2859   
 L  R2860   
 L  R2861   
 L  R2862   
 L  R2863   
 L  R2864   
 L  R2865   
 L  R2866   
 L  R2867   
 L  R2868   
 L  R2869   
 L  R2870   
 L  R2871   
 L  R2872   
 L  R2873   
 L  R2874   
 L  R2875   
 L  R2876   
 L  R2877   
 L  R2878   
 L  R2879   
 L  R2880   
 L  R2881   
 L  R2882   
 L  R2883   
 L  R2884   
 L  R2885   
 L  R2886   
 L  R2887   
 L  R2888   
 L  R2889   
 L  R2890   
 L  R2891   
 L  R2892   
 L  R2893   
 L  R2894   
 L  R2895   
 L  R2896   
 L  R2897   
 L  R2898   
 L  R2899   
 L  R2900   
 L  R2901   
 L  R2902   
 L  R2903   
 L  R2904   
 L  R2905   
 L  R2906   
 L  R2907   
 L  R2908   
 L  R2909   
 L  R2910   
 L  R2911   
 L  R2912   
 L  R2913   
 L  R2914   
 L  R2915   
 L  R2916   
 L  R2917   
 L  R2918   
 L  R2919   
 L  R2920   
 L  R2921   
 L  R2922   
 L  R2923   
 L  R2924   
 L  R2925   
 L  R2926   
 L  R2927   
 L  R2928   
 L  R2929   
 L  R2930   
 L  R2931   
 L  R2932   
 L  R2933   
 L  R2934   
 L  R2935   
 L  R2936   
 L  R2937   
 L  R2938   
 L  R2939   
 L  R2940   
 L  R2941   
 L  R2942   
 L  R2943   
 L  R2944   
 L  R2945   
 L  R2946   
 L  R2947   
 L  R2948   
 L  R2949   
 L  R2950   
 L  R2951   
 L  R2952   
 L  R2953   
 L  R2954   
 L  R2955   
 L  R2956   
 L  R2957   
 L  R2958   
 L  qc0     
 L  qc1     
 L  qc2     
 L  qc3     
 L  qc4     
 L  qc5     
 L  qc6     
 L  qc7     
 L  qc8     
 L  qc9     
 L  qc10    
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    phi[0,1]  R0        1
    phi[0,1]  R1        1
    phi[0,1]  R9        -1
    phi[0,1]  R101      -3.0999999046325684e+00
    phi[0,1]  R102      -3.0999999046325684e+00
    phi[0,1]  R103      -2.2400000095367432e+00
    phi[0,1]  R104      -2.2400000095367432e+00
    phi[0,1]  R105      -3.0999999046325684e+00
    phi[0,1]  R106      -3.0999999046325684e+00
    phi[0,1]  R107      -2.5699999332427979e+00
    phi[0,1]  R108      -2.5699999332427979e+00
    phi[0,1]  R109      -3.0999999046325684e+00
    phi[0,1]  R110      -3.0999999046325684e+00
    phi[0,1]  R111      -2.0899999141693115e+00
    phi[0,1]  R112      -2.0899999141693115e+00
    phi[0,1]  R113      -3.0999999046325684e+00
    phi[0,1]  R114      -3.0999999046325684e+00
    phi[0,1]  R115      1.2732566595077515e+00
    phi[0,1]  R116      2.4039466381073
    phi[0,1]  R117      7.2219443321228027e-01
    phi[0,1]  R118      1.1041049957275391e+00
    phi[0,1]  R119      2.6227312088012695e+00
    phi[0,1]  R120      1.1290185898542404e-01
    phi[0,1]  R121      2.5240004062652588e+00
    phi[0,1]  R122      -2.1776015758514404e+00
    phi[0,1]  R123      1.1262403726577759e+00
    phi[0,1]  R124      -2.1952571868896484e+00
    phi[0,1]  R125      -2.4411914348602295e+00
    phi[0,1]  R126      -7.9984384775161743e-01
    phi[0,1]  R127      -2.3936245441436768e+00
    phi[0,1]  R128      -3.3198397159576416e+00
    phi[0,1]  R129      -3.4106125831604004e+00
    phi[0,1]  R130      -6.9768935441970825e-01
    phi[0,1]  R131      -1.1338572502136230e+00
    phi[0,1]  R132      -2.3098442554473877e+00
    phi[0,1]  R133      -1.1261866092681885e+00
    phi[0,1]  R134      -1.0962711572647095e+00
    phi[0,1]  R135      -2.6852643489837646e+00
    phi[0,1]  R136      -1.4701672792434692e+00
    phi[0,1]  R137      -1.8630604743957520e+00
    phi[0,1]  R138      2.2919808328151703e-01
    phi[0,1]  R139      2.8804185986518860e-01
    phi[0,1]  R140      -1.2245234251022339e+00
    phi[0,1]  R141      -1.0225090980529785e+00
    phi[0,1]  R142      1.1850929260253906e+00
    phi[0,1]  R143      -2.1842439472675323e-01
    phi[0,1]  R144      1.0159870386123657e+00
    phi[0,1]  R145      -3.0435693264007568e+00
    phi[0,1]  R146      -1.5722063779830933e+00
    phi[0,1]  R147      -2.7935438156127930e+00
    phi[0,1]  R148      -1.7241683006286621e+00
    phi[0,1]  R149      1.4721995592117310e-01
    phi[0,1]  R150      -2.8266220092773438e+00
    phi[0,1]  R151      -1.9209899902343750e+00
    phi[0,1]  R152      1.2040123939514160e+00
    phi[0,1]  R153      1.1302450895309448e+00
    phi[0,1]  R154      0.913649320602417
    phi[0,1]  R155      -0.527452826499939
    phi[0,1]  R156      -3.0764443874359131e+00
    phi[0,1]  R157      -9.8476374149322510e-01
    phi[0,1]  R158      -1.7955628633499146e+00
    phi[0,1]  R159      1.9315412044525146e+00
    phi[0,1]  R160      1.5906586647033691e+00
    phi[0,1]  R161      1.1110296249389648e+00
    phi[0,1]  R162      -1.5534268617630005e+00
    phi[0,1]  R163      -8.7159639596939087e-01
    phi[0,1]  R164      -2.0879349708557129e+00
    phi[0,1]  R165      -3.1508414745330811e+00
    phi[0,1]  R166      -2.2445325851440430e+00
    phi[0,1]  R167      1.17326819896698
    phi[0,1]  R168      1.4023456573486328e+00
    phi[0,1]  R169      1.4953075647354126e+00
    phi[0,1]  R170      -1.2993433475494385e+00
    phi[0,1]  R171      -1.4291827678680420e+00
    phi[0,1]  R172      -3.1352877616882324e+00
    phi[0,1]  R173      -3.4542803764343262e+00
    phi[0,1]  R174      -4.0842313766479492e+00
    phi[0,1]  R175      3.2227265834808350e+00
    phi[0,1]  R176      3.1713694334030151e-01
    phi[0,1]  R177      2.2432742118835449e+00
    phi[0,1]  R178      2.3145313262939453e+00
    phi[0,1]  R179      3.0965423583984375e+00
    phi[0,1]  R180      2.3720088005065918e+00
    phi[0,1]  R181      1.7727290391921997e+00
    phi[0,1]  R182      2.9377622604370117e+00
    phi[0,1]  R183      3.4812824726104736e+00
    phi[0,1]  R184      2.2325367927551270e+00
    phi[0,1]  R185      -1.5239905118942261e+00
    phi[0,1]  R186      -1.3950996398925781e+00
    phi[0,1]  R187      -1.3092980384826660e+00
    phi[0,1]  R188      -1.1301237344741821e+00
    phi[0,1]  R189      8.1604743003845215e-01
    phi[0,1]  R190      -4.4895958900451660e-01
    phi[0,1]  R191      -1.8077356815338135e+00
    phi[0,1]  R192      -3.9988920688629150e+00
    phi[0,1]  R193      7.7600412070751190e-02
    phi[0,1]  R194      -2.3916368484497070e+00
    phi[0,1]  R195      -6.6441535949707031e-01
    phi[0,1]  R196      -3.5897789001464844e+00
    phi[0,1]  R197      -1.0424206256866455e+00
    phi[0,1]  R198      1.9101600348949432e-01
    phi[0,1]  R199      -2.9318368434906006e+00
    phi[0,1]  R200      -2.9790697097778320e+00
    phi[0,1]  R201      -2.6490008831024170e+00
    phi[0,1]  R202      -3.0681662559509277e+00
    phi[0,1]  R203      -3.6486954689025879e+00
    phi[0,1]  R204      -2.2273890972137451e+00
    phi[0,1]  R205      -6.3124144077301025e-01
    phi[0,1]  R206      -2.5563473701477051e+00
    phi[0,1]  R207      -3.45406436920166
    phi[0,1]  R208      -3.2198812961578369e+00
    phi[0,1]  R209      1.0125267505645752e+00
    phi[0,1]  R210      -3.2126188278198242e+00
    phi[0,1]  R211      1.9098457098007202e+00
    phi[0,1]  R212      -8.6104571819305420e-01
    phi[0,1]  R213      -1.4163419008255005e+00
    phi[0,1]  R214      -1.9607166051864624e+00
    phi[1,0]  R0        -1
    phi[1,0]  R9        1
    phi[1,0]  R10       1
    phi[1,0]  R215      -3.0999999046325684e+00
    phi[1,0]  R216      -3.0999999046325684e+00
    phi[1,0]  R217      -2.2400000095367432e+00
    phi[1,0]  R218      -2.2400000095367432e+00
    phi[1,0]  R219      -3.0999999046325684e+00
    phi[1,0]  R220      -3.0999999046325684e+00
    phi[1,0]  R221      -2.5699999332427979e+00
    phi[1,0]  R222      -2.5699999332427979e+00
    phi[1,0]  R223      -3.0999999046325684e+00
    phi[1,0]  R224      -3.0999999046325684e+00
    phi[1,0]  R225      -2.0899999141693115e+00
    phi[1,0]  R226      -2.0899999141693115e+00
    phi[1,0]  R227      -3.0999999046325684e+00
    phi[1,0]  R228      -3.0999999046325684e+00
    phi[1,0]  R229      3.2227265834808350e+00
    phi[1,0]  R230      3.1713694334030151e-01
    phi[1,0]  R231      2.2432742118835449e+00
    phi[1,0]  R232      2.3145313262939453e+00
    phi[1,0]  R233      3.0965423583984375e+00
    phi[1,0]  R234      2.3720088005065918e+00
    phi[1,0]  R235      1.7727290391921997e+00
    phi[1,0]  R236      2.9377622604370117e+00
    phi[1,0]  R237      3.4812824726104736e+00
    phi[1,0]  R238      2.2325367927551270e+00
    phi[1,0]  R239      -1.5239905118942261e+00
    phi[1,0]  R240      -1.3950996398925781e+00
    phi[1,0]  R241      -1.3092980384826660e+00
    phi[1,0]  R242      -1.1301237344741821e+00
    phi[1,0]  R243      8.1604743003845215e-01
    phi[1,0]  R244      -4.4895958900451660e-01
    phi[1,0]  R245      -1.8077356815338135e+00
    phi[1,0]  R246      -3.9988920688629150e+00
    phi[1,0]  R247      7.7600412070751190e-02
    phi[1,0]  R248      -2.3916368484497070e+00
    phi[1,0]  R249      -6.6441535949707031e-01
    phi[1,0]  R250      -3.5897789001464844e+00
    phi[1,0]  R251      -1.0424206256866455e+00
    phi[1,0]  R252      1.9101600348949432e-01
    phi[1,0]  R253      -2.9318368434906006e+00
    phi[1,0]  R254      -2.9790697097778320e+00
    phi[1,0]  R255      -2.6490008831024170e+00
    phi[1,0]  R256      -3.0681662559509277e+00
    phi[1,0]  R257      -3.6486954689025879e+00
    phi[1,0]  R258      -2.2273890972137451e+00
    phi[1,0]  R259      -6.3124144077301025e-01
    phi[1,0]  R260      -2.5563473701477051e+00
    phi[1,0]  R261      -3.45406436920166
    phi[1,0]  R262      -3.2198812961578369e+00
    phi[1,0]  R263      1.0125267505645752e+00
    phi[1,0]  R264      -3.2126188278198242e+00
    phi[1,0]  R265      1.9098457098007202e+00
    phi[1,0]  R266      -8.6104571819305420e-01
    phi[1,0]  R267      -1.4163419008255005e+00
    phi[1,0]  R268      -1.9607166051864624e+00
    phi[1,0]  R269      1.2732566595077515e+00
    phi[1,0]  R270      2.4039466381073
    phi[1,0]  R271      7.2219443321228027e-01
    phi[1,0]  R272      1.1041049957275391e+00
    phi[1,0]  R273      2.6227312088012695e+00
    phi[1,0]  R274      1.1290185898542404e-01
    phi[1,0]  R275      2.5240004062652588e+00
    phi[1,0]  R276      -2.1776015758514404e+00
    phi[1,0]  R277      1.1262403726577759e+00
    phi[1,0]  R278      -2.1952571868896484e+00
    phi[1,0]  R279      -2.4411914348602295e+00
    phi[1,0]  R280      -7.9984384775161743e-01
    phi[1,0]  R281      -2.3936245441436768e+00
    phi[1,0]  R282      -3.3198397159576416e+00
    phi[1,0]  R283      -3.4106125831604004e+00
    phi[1,0]  R284      -6.9768935441970825e-01
    phi[1,0]  R285      -1.1338572502136230e+00
    phi[1,0]  R286      -2.3098442554473877e+00
    phi[1,0]  R287      -1.1261866092681885e+00
    phi[1,0]  R288      -1.0962711572647095e+00
    phi[1,0]  R289      -2.6852643489837646e+00
    phi[1,0]  R290      -1.4701672792434692e+00
    phi[1,0]  R291      -1.8630604743957520e+00
    phi[1,0]  R292      2.2919808328151703e-01
    phi[1,0]  R293      2.8804185986518860e-01
    phi[1,0]  R294      -1.2245234251022339e+00
    phi[1,0]  R295      -1.0225090980529785e+00
    phi[1,0]  R296      1.1850929260253906e+00
    phi[1,0]  R297      -2.1842439472675323e-01
    phi[1,0]  R298      1.0159870386123657e+00
    phi[1,0]  R299      -3.0435693264007568e+00
    phi[1,0]  R300      -1.5722063779830933e+00
    phi[1,0]  R301      -2.7935438156127930e+00
    phi[1,0]  R302      -1.7241683006286621e+00
    phi[1,0]  R303      1.4721995592117310e-01
    phi[1,0]  R304      -2.8266220092773438e+00
    phi[1,0]  R305      -1.9209899902343750e+00
    phi[1,0]  R306      1.2040123939514160e+00
    phi[1,0]  R307      1.1302450895309448e+00
    phi[1,0]  R308      0.913649320602417
    phi[1,0]  R309      -0.527452826499939
    phi[1,0]  R310      -3.0764443874359131e+00
    phi[1,0]  R311      -9.8476374149322510e-01
    phi[1,0]  R312      -1.7955628633499146e+00
    phi[1,0]  R313      1.9315412044525146e+00
    phi[1,0]  R314      1.5906586647033691e+00
    phi[1,0]  R315      1.1110296249389648e+00
    phi[1,0]  R316      -1.5534268617630005e+00
    phi[1,0]  R317      -8.7159639596939087e-01
    phi[1,0]  R318      -2.0879349708557129e+00
    phi[1,0]  R319      -3.1508414745330811e+00
    phi[1,0]  R320      -2.2445325851440430e+00
    phi[1,0]  R321      1.17326819896698
    phi[1,0]  R322      1.4023456573486328e+00
    phi[1,0]  R323      1.4953075647354126e+00
    phi[1,0]  R324      -1.2993433475494385e+00
    phi[1,0]  R325      -1.4291827678680420e+00
    phi[1,0]  R326      -3.1352877616882324e+00
    phi[1,0]  R327      -3.4542803764343262e+00
    phi[1,0]  R328      -4.0842313766479492e+00
    phi[0,4]  R0        1
    phi[0,4]  R1        1
    phi[0,4]  R36       -1
    phi[0,4]  R329      -3.0999999046325684e+00
    phi[0,4]  R330      -3.0999999046325684e+00
    phi[0,4]  R331      -2.2400000095367432e+00
    phi[0,4]  R332      -2.2400000095367432e+00
    phi[0,4]  R333      -3.0999999046325684e+00
    phi[0,4]  R334      -3.0999999046325684e+00
    phi[0,4]  R335      -2.5699999332427979e+00
    phi[0,4]  R336      -2.5699999332427979e+00
    phi[0,4]  R337      -3.0999999046325684e+00
    phi[0,4]  R338      -3.0999999046325684e+00
    phi[0,4]  R339      -2.0899999141693115e+00
    phi[0,4]  R340      -2.0899999141693115e+00
    phi[0,4]  R341      -3.0999999046325684e+00
    phi[0,4]  R342      -3.0999999046325684e+00
    phi[0,4]  R343      1.2732566595077515e+00
    phi[0,4]  R344      2.4039466381073
    phi[0,4]  R345      7.2219443321228027e-01
    phi[0,4]  R346      1.1041049957275391e+00
    phi[0,4]  R347      2.6227312088012695e+00
    phi[0,4]  R348      1.1290185898542404e-01
    phi[0,4]  R349      2.5240004062652588e+00
    phi[0,4]  R350      -2.1776015758514404e+00
    phi[0,4]  R351      1.1262403726577759e+00
    phi[0,4]  R352      -2.1952571868896484e+00
    phi[0,4]  R353      -2.4411914348602295e+00
    phi[0,4]  R354      -7.9984384775161743e-01
    phi[0,4]  R355      -2.3936245441436768e+00
    phi[0,4]  R356      -3.3198397159576416e+00
    phi[0,4]  R357      -3.4106125831604004e+00
    phi[0,4]  R358      -6.9768935441970825e-01
    phi[0,4]  R359      -1.1338572502136230e+00
    phi[0,4]  R360      -2.3098442554473877e+00
    phi[0,4]  R361      -1.1261866092681885e+00
    phi[0,4]  R362      -1.0962711572647095e+00
    phi[0,4]  R363      -2.6852643489837646e+00
    phi[0,4]  R364      -1.4701672792434692e+00
    phi[0,4]  R365      -1.8630604743957520e+00
    phi[0,4]  R366      2.2919808328151703e-01
    phi[0,4]  R367      2.8804185986518860e-01
    phi[0,4]  R368      -1.2245234251022339e+00
    phi[0,4]  R369      -1.0225090980529785e+00
    phi[0,4]  R370      1.1850929260253906e+00
    phi[0,4]  R371      -2.1842439472675323e-01
    phi[0,4]  R372      1.0159870386123657e+00
    phi[0,4]  R373      -3.0435693264007568e+00
    phi[0,4]  R374      -1.5722063779830933e+00
    phi[0,4]  R375      -2.7935438156127930e+00
    phi[0,4]  R376      -1.7241683006286621e+00
    phi[0,4]  R377      1.4721995592117310e-01
    phi[0,4]  R378      -2.8266220092773438e+00
    phi[0,4]  R379      -1.9209899902343750e+00
    phi[0,4]  R380      1.2040123939514160e+00
    phi[0,4]  R381      1.1302450895309448e+00
    phi[0,4]  R382      0.913649320602417
    phi[0,4]  R383      -0.527452826499939
    phi[0,4]  R384      -3.0764443874359131e+00
    phi[0,4]  R385      -9.8476374149322510e-01
    phi[0,4]  R386      -1.7955628633499146e+00
    phi[0,4]  R387      1.9315412044525146e+00
    phi[0,4]  R388      1.5906586647033691e+00
    phi[0,4]  R389      1.1110296249389648e+00
    phi[0,4]  R390      -1.5534268617630005e+00
    phi[0,4]  R391      -8.7159639596939087e-01
    phi[0,4]  R392      -2.0879349708557129e+00
    phi[0,4]  R393      -3.1508414745330811e+00
    phi[0,4]  R394      -2.2445325851440430e+00
    phi[0,4]  R395      1.17326819896698
    phi[0,4]  R396      1.4023456573486328e+00
    phi[0,4]  R397      1.4953075647354126e+00
    phi[0,4]  R398      -1.2993433475494385e+00
    phi[0,4]  R399      -1.4291827678680420e+00
    phi[0,4]  R400      -3.1352877616882324e+00
    phi[0,4]  R401      -3.4542803764343262e+00
    phi[0,4]  R402      -4.0842313766479492e+00
    phi[0,4]  R403      1.3253046274185181e+00
    phi[0,4]  R404      3.9761909842491150e-01
    phi[0,4]  R405      5.2724522352218628e-01
    phi[0,4]  R406      -0.0084505844861269
    phi[0,4]  R407      2.5511163473129272e-01
    phi[0,4]  R408      7.4777173995971680e-01
    phi[0,4]  R409      7.2634738683700562e-01
    phi[0,4]  R410      9.9240273237228394e-01
    phi[0,4]  R411      0.546148955821991
    phi[0,4]  R412      5.5241447687149048e-01
    phi[0,4]  R413      -1.1435811519622803e+00
    phi[0,4]  R414      -1.5849117040634155e+00
    phi[0,4]  R415      -1.6014122962951660e+00
    phi[0,4]  R416      -1.9174997806549072e+00
    phi[0,4]  R417      -5.8350926637649536e-01
    phi[0,4]  R418      -2.0852053165435791e+00
    phi[0,4]  R419      -1.0248399972915649e+00
    phi[0,4]  R420      -1.4011521339416504e+00
    phi[0,4]  R421      -2.0342090129852295e+00
    phi[0,4]  R422      -2.6230406761169434e+00
    phi[0,4]  R423      -1.5807336568832397e+00
    phi[0,4]  R424      -1.7757858037948608e+00
    phi[0,4]  R425      -2.0689892768859863e+00
    phi[0,4]  R426      -1.9513186216354370e+00
    phi[0,4]  R427      -2.2459280490875244e+00
    phi[0,4]  R428      -7.1136569976806641e-01
    phi[0,4]  R429      -1.8230395317077637e+00
    phi[0,4]  R430      -1.8808318376541138e+00
    phi[0,4]  R431      -8.9955651760101318e-01
    phi[0,4]  R432      -1.7513449490070343e-01
    phi[0,4]  R433      -1.1597578525543213e+00
    phi[0,4]  R434      -1.7768043279647827e+00
    phi[0,4]  R435      -8.8181060552597046e-01
    phi[0,4]  R436      -9.9230170249938965e-01
    phi[0,4]  R437      -5.7461428642272949e-01
    phi[0,4]  R438      -1.5933365821838379e+00
    phi[0,4]  R439      -1.5120373964309692e+00
    phi[0,4]  R440      -0.900452196598053
    phi[0,4]  R441      -1.3337709903717041e+00
    phi[0,4]  R442      -9.3368732929229736e-01
    phi[0,4]  R443      -2.25651216506958
    phi[0,4]  R444      -1.9074938297271729e+00
    phi[0,4]  R445      -1.2941697835922241e+00
    phi[0,4]  R446      -1.8284888267517090e+00
    phi[0,4]  R447      -1.1415930986404419e+00
    phi[0,4]  R448      -1.7610708475112915e+00
    phi[0,4]  R449      -3.4316429495811462e-01
    phi[0,4]  R450      1.1219238489866257e-01
    phi[0,4]  R451      -1.1211214959621429e-01
    phi[0,4]  R452      -3.7155583500862122e-01
    phi[4,0]  R0        -1
    phi[4,0]  R36       1
    phi[4,0]  R37       1
    phi[4,0]  R453      -3.0999999046325684e+00
    phi[4,0]  R454      -3.0999999046325684e+00
    phi[4,0]  R455      -2.2400000095367432e+00
    phi[4,0]  R456      -2.2400000095367432e+00
    phi[4,0]  R457      -3.0999999046325684e+00
    phi[4,0]  R458      -3.0999999046325684e+00
    phi[4,0]  R459      -2.5699999332427979e+00
    phi[4,0]  R460      -2.5699999332427979e+00
    phi[4,0]  R461      -3.0999999046325684e+00
    phi[4,0]  R462      -3.0999999046325684e+00
    phi[4,0]  R463      -2.0899999141693115e+00
    phi[4,0]  R464      -2.0899999141693115e+00
    phi[4,0]  R465      -3.0999999046325684e+00
    phi[4,0]  R466      -3.0999999046325684e+00
    phi[4,0]  R467      1.3253046274185181e+00
    phi[4,0]  R468      3.9761909842491150e-01
    phi[4,0]  R469      5.2724522352218628e-01
    phi[4,0]  R470      -0.0084505844861269
    phi[4,0]  R471      2.5511163473129272e-01
    phi[4,0]  R472      7.4777173995971680e-01
    phi[4,0]  R473      7.2634738683700562e-01
    phi[4,0]  R474      9.9240273237228394e-01
    phi[4,0]  R475      0.546148955821991
    phi[4,0]  R476      5.5241447687149048e-01
    phi[4,0]  R477      -1.1435811519622803e+00
    phi[4,0]  R478      -1.5849117040634155e+00
    phi[4,0]  R479      -1.6014122962951660e+00
    phi[4,0]  R480      -1.9174997806549072e+00
    phi[4,0]  R481      -5.8350926637649536e-01
    phi[4,0]  R482      -2.0852053165435791e+00
    phi[4,0]  R483      -1.0248399972915649e+00
    phi[4,0]  R484      -1.4011521339416504e+00
    phi[4,0]  R485      -2.0342090129852295e+00
    phi[4,0]  R486      -2.6230406761169434e+00
    phi[4,0]  R487      -1.5807336568832397e+00
    phi[4,0]  R488      -1.7757858037948608e+00
    phi[4,0]  R489      -2.0689892768859863e+00
    phi[4,0]  R490      -1.9513186216354370e+00
    phi[4,0]  R491      -2.2459280490875244e+00
    phi[4,0]  R492      -7.1136569976806641e-01
    phi[4,0]  R493      -1.8230395317077637e+00
    phi[4,0]  R494      -1.8808318376541138e+00
    phi[4,0]  R495      -8.9955651760101318e-01
    phi[4,0]  R496      -1.7513449490070343e-01
    phi[4,0]  R497      -1.1597578525543213e+00
    phi[4,0]  R498      -1.7768043279647827e+00
    phi[4,0]  R499      -8.8181060552597046e-01
    phi[4,0]  R500      -9.9230170249938965e-01
    phi[4,0]  R501      -5.7461428642272949e-01
    phi[4,0]  R502      -1.5933365821838379e+00
    phi[4,0]  R503      -1.5120373964309692e+00
    phi[4,0]  R504      -0.900452196598053
    phi[4,0]  R505      -1.3337709903717041e+00
    phi[4,0]  R506      -9.3368732929229736e-01
    phi[4,0]  R507      -2.25651216506958
    phi[4,0]  R508      -1.9074938297271729e+00
    phi[4,0]  R509      -1.2941697835922241e+00
    phi[4,0]  R510      -1.8284888267517090e+00
    phi[4,0]  R511      -1.1415930986404419e+00
    phi[4,0]  R512      -1.7610708475112915e+00
    phi[4,0]  R513      -3.4316429495811462e-01
    phi[4,0]  R514      1.1219238489866257e-01
    phi[4,0]  R515      -1.1211214959621429e-01
    phi[4,0]  R516      -3.7155583500862122e-01
    phi[4,0]  R517      1.2732566595077515e+00
    phi[4,0]  R518      2.4039466381073
    phi[4,0]  R519      7.2219443321228027e-01
    phi[4,0]  R520      1.1041049957275391e+00
    phi[4,0]  R521      2.6227312088012695e+00
    phi[4,0]  R522      1.1290185898542404e-01
    phi[4,0]  R523      2.5240004062652588e+00
    phi[4,0]  R524      -2.1776015758514404e+00
    phi[4,0]  R525      1.1262403726577759e+00
    phi[4,0]  R526      -2.1952571868896484e+00
    phi[4,0]  R527      -2.4411914348602295e+00
    phi[4,0]  R528      -7.9984384775161743e-01
    phi[4,0]  R529      -2.3936245441436768e+00
    phi[4,0]  R530      -3.3198397159576416e+00
    phi[4,0]  R531      -3.4106125831604004e+00
    phi[4,0]  R532      -6.9768935441970825e-01
    phi[4,0]  R533      -1.1338572502136230e+00
    phi[4,0]  R534      -2.3098442554473877e+00
    phi[4,0]  R535      -1.1261866092681885e+00
    phi[4,0]  R536      -1.0962711572647095e+00
    phi[4,0]  R537      -2.6852643489837646e+00
    phi[4,0]  R538      -1.4701672792434692e+00
    phi[4,0]  R539      -1.8630604743957520e+00
    phi[4,0]  R540      2.2919808328151703e-01
    phi[4,0]  R541      2.8804185986518860e-01
    phi[4,0]  R542      -1.2245234251022339e+00
    phi[4,0]  R543      -1.0225090980529785e+00
    phi[4,0]  R544      1.1850929260253906e+00
    phi[4,0]  R545      -2.1842439472675323e-01
    phi[4,0]  R546      1.0159870386123657e+00
    phi[4,0]  R547      -3.0435693264007568e+00
    phi[4,0]  R548      -1.5722063779830933e+00
    phi[4,0]  R549      -2.7935438156127930e+00
    phi[4,0]  R550      -1.7241683006286621e+00
    phi[4,0]  R551      1.4721995592117310e-01
    phi[4,0]  R552      -2.8266220092773438e+00
    phi[4,0]  R553      -1.9209899902343750e+00
    phi[4,0]  R554      1.2040123939514160e+00
    phi[4,0]  R555      1.1302450895309448e+00
    phi[4,0]  R556      0.913649320602417
    phi[4,0]  R557      -0.527452826499939
    phi[4,0]  R558      -3.0764443874359131e+00
    phi[4,0]  R559      -9.8476374149322510e-01
    phi[4,0]  R560      -1.7955628633499146e+00
    phi[4,0]  R561      1.9315412044525146e+00
    phi[4,0]  R562      1.5906586647033691e+00
    phi[4,0]  R563      1.1110296249389648e+00
    phi[4,0]  R564      -1.5534268617630005e+00
    phi[4,0]  R565      -8.7159639596939087e-01
    phi[4,0]  R566      -2.0879349708557129e+00
    phi[4,0]  R567      -3.1508414745330811e+00
    phi[4,0]  R568      -2.2445325851440430e+00
    phi[4,0]  R569      1.17326819896698
    phi[4,0]  R570      1.4023456573486328e+00
    phi[4,0]  R571      1.4953075647354126e+00
    phi[4,0]  R572      -1.2993433475494385e+00
    phi[4,0]  R573      -1.4291827678680420e+00
    phi[4,0]  R574      -3.1352877616882324e+00
    phi[4,0]  R575      -3.4542803764343262e+00
    phi[4,0]  R576      -4.0842313766479492e+00
    phi[11,0]  R0        -1
    phi[11,0]  R2        1.2877988374356453e+00
    phi[11,0]  R3        -1.2366243616616113e+00
    phi[11,0]  R4        2.8414682753985034e+00
    phi[11,0]  R5        -1.3629511530561120e+00
    phi[11,0]  R6        1.7827265202085179e+00
    phi[11,0]  R7        0.887332484368538
    phi[11,0]  R8        1.1092358773438646e+00
    phi[11,0]  R99       1
    phi[11,0]  R577      -4.3877987420682132e+00
    phi[11,0]  R578      -1.8122010671969231e+00
    phi[11,0]  R579      -1.0033756478751319e+00
    phi[11,0]  R580      -3.4766243711983544e+00
    phi[11,0]  R581      -5.9414681800310714e+00
    phi[11,0]  R582      -2.5853162923406492e-01
    phi[11,0]  R583      -1.2070487801866858e+00
    phi[11,0]  R584      -3.93295108629891
    phi[11,0]  R585      -4.8827264248410867e+00
    phi[11,0]  R586      -1.3172733844240505e+00
    phi[11,0]  R587      -2.9773323985378495e+00
    phi[11,0]  R588      -1.2026674298007736e+00
    phi[11,0]  R589      -4.2092357819764334e+00
    phi[11,0]  R590      -1.9907640272887037e+00
    phi[11,0]  R591      -4.2802644588414873e-01
    phi[11,0]  R592      -5.7153857994217017e-01
    phi[11,0]  R593      -5.7681205953075132e-01
    phi[11,0]  R594      -5.9563400057076388e-01
    phi[11,0]  R595      -0.960228954353834
    phi[11,0]  R596      -6.1653858598870948e-01
    phi[11,0]  R597      -6.2055035477847120e-01
    phi[11,0]  R598      -0.635065137725549
    phi[11,0]  R599      -6.5502577139403884e-01
    phi[11,0]  R600      -6.6817214402833858e-01
    phi[11,0]  R601      -4.0498825313059506e-01
    phi[11,0]  R602      -4.2585156718650585e-01
    phi[11,0]  R603      -5.1059782269448117e-01
    phi[11,0]  R604      -5.4390458163734134e-01
    phi[11,0]  R605      -0.546802160600965
    phi[11,0]  R606      -5.4811803716575858e-01
    phi[11,0]  R607      -5.8878733456510868e-01
    phi[11,0]  R608      -6.1812680869808267e-01
    phi[11,0]  R609      -6.3666398601077390e-01
    phi[11,0]  R610      -6.6345317338490339e-01
    phi[11,0]  R611      -3.5937220630951172e-01
    phi[11,0]  R612      -4.4523180873311352e-01
    phi[11,0]  R613      -4.9381146370918216e-01
    phi[11,0]  R614      -0.541705734477727
    phi[11,0]  R615      -6.0396037535962521e-01
    phi[11,0]  R616      -6.2427191652153491e-01
    phi[11,0]  R617      -6.3289756992791024e-01
    phi[11,0]  R618      -6.4132149732399113e-01
    phi[11,0]  R619      -0.698214281347041
    phi[11,0]  R620      -7.0684618520393228e-01
    phi[11,0]  R621      -3.3103451025613628e-01
    phi[11,0]  R622      -4.4711869065877208e-01
    phi[11,0]  R623      -5.0303718254197038e-01
    phi[11,0]  R624      -5.2360871857864733e-01
    phi[11,0]  R625      -5.4611815262832253e-01
    phi[11,0]  R626      -6.1161977816179158e-01
    phi[11,0]  R627      -7.1548331157607881e-01
    phi[11,0]  R628      -7.9090630473678436e-01
    phi[11,0]  R629      -7.9756604669046016e-01
    phi[11,0]  R630      -8.1443182301048012e-01
    phi[11,0]  R631      -3.6192788614657834e-01
    phi[11,0]  R632      -0.510046070366363
    phi[11,0]  R633      -7.2827707495847427e-01
    phi[11,0]  R634      -7.8648978994970631e-01
    phi[11,0]  R635      -8.1862555717207108e-01
    phi[11,0]  R636      -8.8184417530089254e-01
    phi[11,0]  R637      -0.916907340573176
    phi[11,0]  R638      -9.7387213391786009e-01
    phi[11,0]  R639      -1.0020077691497751e+00
    phi[11,0]  R640      -1.1010569187089598e+00
    phi[11,0]  R641      -3.6978087776970048e-01
    phi[11,0]  R642      -4.4947229545042022e-01
    phi[11,0]  R643      -7.9083245329597673e-01
    phi[11,0]  R644      -8.2546619469242222e-01
    phi[11,0]  R645      -8.8244898511960690e-01
    phi[11,0]  R646      -9.3057003078774092e-01
    phi[11,0]  R647      -1.0984477493305573e+00
    phi[11,0]  R648      -1.1663971040562673e+00
    phi[11,0]  R649      -1.1726347981469329e+00
    phi[11,0]  R650      -1.2202869490616375e+00
    phi[1,2]  R9        1
    phi[1,2]  R10       1
    phi[1,2]  R18       -1
    phi[1,2]  R651      -3.0999999046325684e+00
    phi[1,2]  R652      -3.0999999046325684e+00
    phi[1,2]  R653      -2.2400000095367432e+00
    phi[1,2]  R654      -2.2400000095367432e+00
    phi[1,2]  R655      -3.0999999046325684e+00
    phi[1,2]  R656      -3.0999999046325684e+00
    phi[1,2]  R657      -2.5699999332427979e+00
    phi[1,2]  R658      -2.5699999332427979e+00
    phi[1,2]  R659      -3.0999999046325684e+00
    phi[1,2]  R660      -3.0999999046325684e+00
    phi[1,2]  R661      -2.0899999141693115e+00
    phi[1,2]  R662      -2.0899999141693115e+00
    phi[1,2]  R663      -3.0999999046325684e+00
    phi[1,2]  R664      -3.0999999046325684e+00
    phi[1,2]  R665      3.2227265834808350e+00
    phi[1,2]  R666      3.1713694334030151e-01
    phi[1,2]  R667      2.2432742118835449e+00
    phi[1,2]  R668      2.3145313262939453e+00
    phi[1,2]  R669      3.0965423583984375e+00
    phi[1,2]  R670      2.3720088005065918e+00
    phi[1,2]  R671      1.7727290391921997e+00
    phi[1,2]  R672      2.9377622604370117e+00
    phi[1,2]  R673      3.4812824726104736e+00
    phi[1,2]  R674      2.2325367927551270e+00
    phi[1,2]  R675      -1.5239905118942261e+00
    phi[1,2]  R676      -1.3950996398925781e+00
    phi[1,2]  R677      -1.3092980384826660e+00
    phi[1,2]  R678      -1.1301237344741821e+00
    phi[1,2]  R679      8.1604743003845215e-01
    phi[1,2]  R680      -4.4895958900451660e-01
    phi[1,2]  R681      -1.8077356815338135e+00
    phi[1,2]  R682      -3.9988920688629150e+00
    phi[1,2]  R683      7.7600412070751190e-02
    phi[1,2]  R684      -2.3916368484497070e+00
    phi[1,2]  R685      -6.6441535949707031e-01
    phi[1,2]  R686      -3.5897789001464844e+00
    phi[1,2]  R687      -1.0424206256866455e+00
    phi[1,2]  R688      1.9101600348949432e-01
    phi[1,2]  R689      -2.9318368434906006e+00
    phi[1,2]  R690      -2.9790697097778320e+00
    phi[1,2]  R691      -2.6490008831024170e+00
    phi[1,2]  R692      -3.0681662559509277e+00
    phi[1,2]  R693      -3.6486954689025879e+00
    phi[1,2]  R694      -2.2273890972137451e+00
    phi[1,2]  R695      -6.3124144077301025e-01
    phi[1,2]  R696      -2.5563473701477051e+00
    phi[1,2]  R697      -3.45406436920166
    phi[1,2]  R698      -3.2198812961578369e+00
    phi[1,2]  R699      1.0125267505645752e+00
    phi[1,2]  R700      -3.2126188278198242e+00
    phi[1,2]  R701      1.9098457098007202e+00
    phi[1,2]  R702      -8.6104571819305420e-01
    phi[1,2]  R703      -1.4163419008255005e+00
    phi[1,2]  R704      -1.9607166051864624e+00
    phi[1,2]  R705      2.3538410663604736e+00
    phi[1,2]  R706      3.1688454151153564e+00
    phi[1,2]  R707      3.1361231803894043e+00
    phi[1,2]  R708      2.9912164211273193e+00
    phi[1,2]  R709      1.8295576572418213e+00
    phi[1,2]  R710      -3.19368314743042
    phi[1,2]  R711      6.6947031021118164e-01
    phi[1,2]  R712      -3.4445145130157471e+00
    phi[1,2]  R713      -1.0808966159820557e+00
    phi[1,2]  R714      -2.2311987876892090e+00
    phi[1,2]  R715      -1.2591081857681274e+00
    phi[1,2]  R716      -1.7305009365081787e+00
    phi[1,2]  R717      -2.0959346294403076e+00
    phi[1,2]  R718      -2.29142427444458
    phi[1,2]  R719      -2.6617805957794189e+00
    phi[1,2]  R720      -2.2382667064666748e+00
    phi[1,2]  R721      -1.2151820659637451e+00
    phi[1,2]  R722      -2.9765939712524414e+00
    phi[1,2]  R723      -9.6944558620452881e-01
    phi[1,2]  R724      -1.7960803508758545e+00
    phi[1,2]  R725      -3.1995387077331543e+00
    phi[1,2]  R726      -1.5766398906707764e+00
    phi[1,2]  R727      -1.6137137413024902e+00
    phi[1,2]  R728      -2.0580091476440430e+00
    phi[1,2]  R729      -1.8448010683059692e+00
    phi[1,2]  R730      -2.3914577960968018e+00
    phi[1,2]  R731      -2.0228438377380371e+00
    phi[1,2]  R732      6.5702641010284424e-01
    phi[1,2]  R733      -9.7103720903396606e-01
    phi[1,2]  R734      -7.4370419979095459e-01
    phi[1,2]  R735      -1.0047582387924194e+00
    phi[1,2]  R736      -2.6662669181823730e+00
    phi[1,2]  R737      -2.0306110382080078e+00
    phi[1,2]  R738      -1.6265916824340820e+00
    phi[1,2]  R739      8.2635164260864258e-01
    phi[1,2]  R740      4.7496187686920166e-01
    phi[1,2]  R741      4.1604065895080566e-01
    phi[1,2]  R742      -2.0428361892700195e+00
    phi[1,2]  R743      0.805109977722168
    phi[1,2]  R744      -1.9300761222839355e+00
    phi[1,2]  R745      -3.6203892230987549e+00
    phi[1,2]  R746      1.0046698898077011e-01
    phi[1,2]  R747      -1.9774116277694702e+00
    phi[1,2]  R748      -8.0881166458129883e-01
    phi[1,2]  R749      1.0769218206405640e+00
    phi[1,2]  R750      -2.4481225013732910e+00
    phi[1,2]  R751      -2.7345349788665771e+00
    phi[1,2]  R752      -3.0040547847747803e+00
    phi[1,2]  R753      -2.7625505924224854e+00
    phi[2,1]  R9        -1
    phi[2,1]  R18       1
    phi[2,1]  R19       1
    phi[2,1]  R754      -3.0999999046325684e+00
    phi[2,1]  R755      -3.0999999046325684e+00
    phi[2,1]  R756      -2.2400000095367432e+00
    phi[2,1]  R757      -2.2400000095367432e+00
    phi[2,1]  R758      -3.0999999046325684e+00
    phi[2,1]  R759      -3.0999999046325684e+00
    phi[2,1]  R760      -2.5699999332427979e+00
    phi[2,1]  R761      -2.5699999332427979e+00
    phi[2,1]  R762      -3.0999999046325684e+00
    phi[2,1]  R763      -3.0999999046325684e+00
    phi[2,1]  R764      -2.0899999141693115e+00
    phi[2,1]  R765      -2.0899999141693115e+00
    phi[2,1]  R766      -3.0999999046325684e+00
    phi[2,1]  R767      -3.0999999046325684e+00
    phi[2,1]  R768      2.3538410663604736e+00
    phi[2,1]  R769      3.1688454151153564e+00
    phi[2,1]  R770      3.1361231803894043e+00
    phi[2,1]  R771      2.9912164211273193e+00
    phi[2,1]  R772      1.8295576572418213e+00
    phi[2,1]  R773      -3.19368314743042
    phi[2,1]  R774      6.6947031021118164e-01
    phi[2,1]  R775      -3.4445145130157471e+00
    phi[2,1]  R776      -1.0808966159820557e+00
    phi[2,1]  R777      -2.2311987876892090e+00
    phi[2,1]  R778      -1.2591081857681274e+00
    phi[2,1]  R779      -1.7305009365081787e+00
    phi[2,1]  R780      -2.0959346294403076e+00
    phi[2,1]  R781      -2.29142427444458
    phi[2,1]  R782      -2.6617805957794189e+00
    phi[2,1]  R783      -2.2382667064666748e+00
    phi[2,1]  R784      -1.2151820659637451e+00
    phi[2,1]  R785      -2.9765939712524414e+00
    phi[2,1]  R786      -9.6944558620452881e-01
    phi[2,1]  R787      -1.7960803508758545e+00
    phi[2,1]  R788      -3.1995387077331543e+00
    phi[2,1]  R789      -1.5766398906707764e+00
    phi[2,1]  R790      -1.6137137413024902e+00
    phi[2,1]  R791      -2.0580091476440430e+00
    phi[2,1]  R792      -1.8448010683059692e+00
    phi[2,1]  R793      -2.3914577960968018e+00
    phi[2,1]  R794      -2.0228438377380371e+00
    phi[2,1]  R795      6.5702641010284424e-01
    phi[2,1]  R796      -9.7103720903396606e-01
    phi[2,1]  R797      -7.4370419979095459e-01
    phi[2,1]  R798      -1.0047582387924194e+00
    phi[2,1]  R799      -2.6662669181823730e+00
    phi[2,1]  R800      -2.0306110382080078e+00
    phi[2,1]  R801      -1.6265916824340820e+00
    phi[2,1]  R802      8.2635164260864258e-01
    phi[2,1]  R803      4.7496187686920166e-01
    phi[2,1]  R804      4.1604065895080566e-01
    phi[2,1]  R805      -2.0428361892700195e+00
    phi[2,1]  R806      0.805109977722168
    phi[2,1]  R807      -1.9300761222839355e+00
    phi[2,1]  R808      -3.6203892230987549e+00
    phi[2,1]  R809      1.0046698898077011e-01
    phi[2,1]  R810      -1.9774116277694702e+00
    phi[2,1]  R811      -8.0881166458129883e-01
    phi[2,1]  R812      1.0769218206405640e+00
    phi[2,1]  R813      -2.4481225013732910e+00
    phi[2,1]  R814      -2.7345349788665771e+00
    phi[2,1]  R815      -3.0040547847747803e+00
    phi[2,1]  R816      -2.7625505924224854e+00
    phi[2,1]  R817      3.2227265834808350e+00
    phi[2,1]  R818      3.1713694334030151e-01
    phi[2,1]  R819      2.2432742118835449e+00
    phi[2,1]  R820      2.3145313262939453e+00
    phi[2,1]  R821      3.0965423583984375e+00
    phi[2,1]  R822      2.3720088005065918e+00
    phi[2,1]  R823      1.7727290391921997e+00
    phi[2,1]  R824      2.9377622604370117e+00
    phi[2,1]  R825      3.4812824726104736e+00
    phi[2,1]  R826      2.2325367927551270e+00
    phi[2,1]  R827      -1.5239905118942261e+00
    phi[2,1]  R828      -1.3950996398925781e+00
    phi[2,1]  R829      -1.3092980384826660e+00
    phi[2,1]  R830      -1.1301237344741821e+00
    phi[2,1]  R831      8.1604743003845215e-01
    phi[2,1]  R832      -4.4895958900451660e-01
    phi[2,1]  R833      -1.8077356815338135e+00
    phi[2,1]  R834      -3.9988920688629150e+00
    phi[2,1]  R835      7.7600412070751190e-02
    phi[2,1]  R836      -2.3916368484497070e+00
    phi[2,1]  R837      -6.6441535949707031e-01
    phi[2,1]  R838      -3.5897789001464844e+00
    phi[2,1]  R839      -1.0424206256866455e+00
    phi[2,1]  R840      1.9101600348949432e-01
    phi[2,1]  R841      -2.9318368434906006e+00
    phi[2,1]  R842      -2.9790697097778320e+00
    phi[2,1]  R843      -2.6490008831024170e+00
    phi[2,1]  R844      -3.0681662559509277e+00
    phi[2,1]  R845      -3.6486954689025879e+00
    phi[2,1]  R846      -2.2273890972137451e+00
    phi[2,1]  R847      -6.3124144077301025e-01
    phi[2,1]  R848      -2.5563473701477051e+00
    phi[2,1]  R849      -3.45406436920166
    phi[2,1]  R850      -3.2198812961578369e+00
    phi[2,1]  R851      1.0125267505645752e+00
    phi[2,1]  R852      -3.2126188278198242e+00
    phi[2,1]  R853      1.9098457098007202e+00
    phi[2,1]  R854      -8.6104571819305420e-01
    phi[2,1]  R855      -1.4163419008255005e+00
    phi[2,1]  R856      -1.9607166051864624e+00
    phi[2,3]  R18       1
    phi[2,3]  R19       1
    phi[2,3]  R27       -1
    phi[2,3]  R857      -3.0999999046325684e+00
    phi[2,3]  R858      -3.0999999046325684e+00
    phi[2,3]  R859      -2.2400000095367432e+00
    phi[2,3]  R860      -2.2400000095367432e+00
    phi[2,3]  R861      -3.0999999046325684e+00
    phi[2,3]  R862      -3.0999999046325684e+00
    phi[2,3]  R863      -2.5699999332427979e+00
    phi[2,3]  R864      -2.5699999332427979e+00
    phi[2,3]  R865      -3.0999999046325684e+00
    phi[2,3]  R866      -3.0999999046325684e+00
    phi[2,3]  R867      -2.0899999141693115e+00
    phi[2,3]  R868      -2.0899999141693115e+00
    phi[2,3]  R869      -3.0999999046325684e+00
    phi[2,3]  R870      -3.0999999046325684e+00
    phi[2,3]  R871      2.3538410663604736e+00
    phi[2,3]  R872      3.1688454151153564e+00
    phi[2,3]  R873      3.1361231803894043e+00
    phi[2,3]  R874      2.9912164211273193e+00
    phi[2,3]  R875      1.8295576572418213e+00
    phi[2,3]  R876      -3.19368314743042
    phi[2,3]  R877      6.6947031021118164e-01
    phi[2,3]  R878      -3.4445145130157471e+00
    phi[2,3]  R879      -1.0808966159820557e+00
    phi[2,3]  R880      -2.2311987876892090e+00
    phi[2,3]  R881      -1.2591081857681274e+00
    phi[2,3]  R882      -1.7305009365081787e+00
    phi[2,3]  R883      -2.0959346294403076e+00
    phi[2,3]  R884      -2.29142427444458
    phi[2,3]  R885      -2.6617805957794189e+00
    phi[2,3]  R886      -2.2382667064666748e+00
    phi[2,3]  R887      -1.2151820659637451e+00
    phi[2,3]  R888      -2.9765939712524414e+00
    phi[2,3]  R889      -9.6944558620452881e-01
    phi[2,3]  R890      -1.7960803508758545e+00
    phi[2,3]  R891      -3.1995387077331543e+00
    phi[2,3]  R892      -1.5766398906707764e+00
    phi[2,3]  R893      -1.6137137413024902e+00
    phi[2,3]  R894      -2.0580091476440430e+00
    phi[2,3]  R895      -1.8448010683059692e+00
    phi[2,3]  R896      -2.3914577960968018e+00
    phi[2,3]  R897      -2.0228438377380371e+00
    phi[2,3]  R898      6.5702641010284424e-01
    phi[2,3]  R899      -9.7103720903396606e-01
    phi[2,3]  R900      -7.4370419979095459e-01
    phi[2,3]  R901      -1.0047582387924194e+00
    phi[2,3]  R902      -2.6662669181823730e+00
    phi[2,3]  R903      -2.0306110382080078e+00
    phi[2,3]  R904      -1.6265916824340820e+00
    phi[2,3]  R905      8.2635164260864258e-01
    phi[2,3]  R906      4.7496187686920166e-01
    phi[2,3]  R907      4.1604065895080566e-01
    phi[2,3]  R908      -2.0428361892700195e+00
    phi[2,3]  R909      0.805109977722168
    phi[2,3]  R910      -1.9300761222839355e+00
    phi[2,3]  R911      -3.6203892230987549e+00
    phi[2,3]  R912      1.0046698898077011e-01
    phi[2,3]  R913      -1.9774116277694702e+00
    phi[2,3]  R914      -8.0881166458129883e-01
    phi[2,3]  R915      1.0769218206405640e+00
    phi[2,3]  R916      -2.4481225013732910e+00
    phi[2,3]  R917      -2.7345349788665771e+00
    phi[2,3]  R918      -3.0040547847747803e+00
    phi[2,3]  R919      -2.7625505924224854e+00
    phi[2,3]  R920      1.0798842906951904e+00
    phi[2,3]  R921      -0.59750896692276
    phi[2,3]  R922      4.2518103122711182e-01
    phi[2,3]  R923      4.6684658527374268e-01
    phi[2,3]  R924      8.2515043020248413e-01
    phi[2,3]  R925      -7.8722901642322540e-02
    phi[2,3]  R926      1.6394654512405396e+00
    phi[2,3]  R927      2.5442276000976562e+00
    phi[2,3]  R928      1.2507046759128571e-01
    phi[2,3]  R929      1.6426980495452881e+00
    phi[2,3]  R930      -2.7137744426727295e+00
    phi[2,3]  R931      -3.9888422489166260e+00
    phi[2,3]  R932      -3.1454153060913086e+00
    phi[2,3]  R933      -4.1362495422363281e+00
    phi[2,3]  R934      -3.3785805702209473e+00
    phi[2,3]  R935      -2.4628889560699463e+00
    phi[2,3]  R936      -2.5663504600524902e+00
    phi[2,3]  R937      -1.6674994230270386e+00
    phi[2,3]  R938      -1.5608620643615723e+00
    phi[2,3]  R939      -3.2919411659240723e+00
    phi[2,3]  R940      -1.4330687522888184e+00
    phi[2,3]  R941      2.9237198829650879e-01
    phi[2,3]  R942      -1.6780118942260742e+00
    phi[2,3]  R943      -2.3134617805480957e+00
    phi[2,3]  R944      -6.6249656677246094e-01
    phi[2,3]  R945      5.4922741651535034e-01
    phi[2,3]  R946      7.5848260894417763e-03
    phi[2,3]  R947      -7.6035803556442261e-01
    phi[2,3]  R948      -2.3523557186126709e-01
    phi[2,3]  R949      -6.8577539920806885e-01
    phi[2,3]  R950      -4.7650939226150513e-01
    phi[2,3]  R951      -2.3743910789489746e+00
    phi[2,3]  R952      4.3360877037048340e-01
    phi[2,3]  R953      -1.8561365604400635e+00
    phi[2,3]  R954      -2.2723183631896973e+00
    phi[2,3]  R955      -2.3256626129150391e+00
    phi[2,3]  R956      4.4216984510421753e-01
    phi[2,3]  R957      -2.7211077213287354e+00
    phi[2,3]  R958      4.0807131677865982e-02
    phi[2,3]  R959      -1.0204231739044189e+00
    phi[2,3]  R960      -2.7367684245109558e-01
    phi[2,3]  R961      -3.8462462425231934e+00
    phi[2,3]  R962      -1.8324840068817139e+00
    phi[2,3]  R963      -1.2517206668853760e+00
    phi[2,3]  R964      -1.8497455120086670e+00
    phi[2,3]  R965      -2.1677372455596924e+00
    phi[2,3]  R966      -1.6088999509811401e+00
    phi[2,3]  R967      -1.1517937183380127e+00
    phi[2,3]  R968      0.957203209400177
    phi[2,3]  R969      3.01701283454895
    phi[2,3]  R970      -1.9385575056076050e+00
    phi[2,3]  R971      -9.5563519001007080e-01
    phi[2,3]  R972      7.5243420898914337e-02
    phi[2,3]  R973      -7.1222299337387085e-01
    phi[2,3]  R974      -1.1193968057632446e+00
    phi[2,3]  R975      -3.7669193744659424e-01
    phi[2,3]  R976      -2.1881020069122314e+00
    phi[2,3]  R977      8.6858719587326050e-01
    phi[2,3]  R978      -2.6590192317962646e-01
    phi[2,3]  R979      -3.1796100139617920e+00
    phi[2,3]  R980      -2.4320273399353027e+00
    phi[2,3]  R981      -5.5871522426605225e-01
    phi[2,3]  R982      -1.5804009437561035e+00
    phi[2,3]  R983      -8.0338603258132935e-01
    phi[2,3]  R984      -2.8337957859039307e+00
    phi[2,3]  R985      4.0964207053184509e-01
    phi[2,3]  R986      2.6495447158813477e+00
    phi[2,3]  R987      1.1807355880737305e+00
    phi[2,3]  R988      -1.6776765584945679e+00
    phi[2,3]  R989      -8.5490250587463379e-01
    phi[3,2]  R18       -1
    phi[3,2]  R27       1
    phi[3,2]  R28       1
    phi[3,2]  R990      -3.0999999046325684e+00
    phi[3,2]  R991      -3.0999999046325684e+00
    phi[3,2]  R992      -2.2400000095367432e+00
    phi[3,2]  R993      -2.2400000095367432e+00
    phi[3,2]  R994      -3.0999999046325684e+00
    phi[3,2]  R995      -3.0999999046325684e+00
    phi[3,2]  R996      -2.5699999332427979e+00
    phi[3,2]  R997      -2.5699999332427979e+00
    phi[3,2]  R998      -3.0999999046325684e+00
    phi[3,2]  R999      -3.0999999046325684e+00
    phi[3,2]  R1000     -2.0899999141693115e+00
    phi[3,2]  R1001     -2.0899999141693115e+00
    phi[3,2]  R1002     -3.0999999046325684e+00
    phi[3,2]  R1003     -3.0999999046325684e+00
    phi[3,2]  R1004     1.0798842906951904e+00
    phi[3,2]  R1005     -0.59750896692276
    phi[3,2]  R1006     4.2518103122711182e-01
    phi[3,2]  R1007     4.6684658527374268e-01
    phi[3,2]  R1008     8.2515043020248413e-01
    phi[3,2]  R1009     -7.8722901642322540e-02
    phi[3,2]  R1010     1.6394654512405396e+00
    phi[3,2]  R1011     2.5442276000976562e+00
    phi[3,2]  R1012     1.2507046759128571e-01
    phi[3,2]  R1013     1.6426980495452881e+00
    phi[3,2]  R1014     -2.7137744426727295e+00
    phi[3,2]  R1015     -3.9888422489166260e+00
    phi[3,2]  R1016     -3.1454153060913086e+00
    phi[3,2]  R1017     -4.1362495422363281e+00
    phi[3,2]  R1018     -3.3785805702209473e+00
    phi[3,2]  R1019     -2.4628889560699463e+00
    phi[3,2]  R1020     -2.5663504600524902e+00
    phi[3,2]  R1021     -1.6674994230270386e+00
    phi[3,2]  R1022     -1.5608620643615723e+00
    phi[3,2]  R1023     -3.2919411659240723e+00
    phi[3,2]  R1024     -1.4330687522888184e+00
    phi[3,2]  R1025     2.9237198829650879e-01
    phi[3,2]  R1026     -1.6780118942260742e+00
    phi[3,2]  R1027     -2.3134617805480957e+00
    phi[3,2]  R1028     -6.6249656677246094e-01
    phi[3,2]  R1029     5.4922741651535034e-01
    phi[3,2]  R1030     7.5848260894417763e-03
    phi[3,2]  R1031     -7.6035803556442261e-01
    phi[3,2]  R1032     -2.3523557186126709e-01
    phi[3,2]  R1033     -6.8577539920806885e-01
    phi[3,2]  R1034     -4.7650939226150513e-01
    phi[3,2]  R1035     -2.3743910789489746e+00
    phi[3,2]  R1036     4.3360877037048340e-01
    phi[3,2]  R1037     -1.8561365604400635e+00
    phi[3,2]  R1038     -2.2723183631896973e+00
    phi[3,2]  R1039     -2.3256626129150391e+00
    phi[3,2]  R1040     4.4216984510421753e-01
    phi[3,2]  R1041     -2.7211077213287354e+00
    phi[3,2]  R1042     4.0807131677865982e-02
    phi[3,2]  R1043     -1.0204231739044189e+00
    phi[3,2]  R1044     -2.7367684245109558e-01
    phi[3,2]  R1045     -3.8462462425231934e+00
    phi[3,2]  R1046     -1.8324840068817139e+00
    phi[3,2]  R1047     -1.2517206668853760e+00
    phi[3,2]  R1048     -1.8497455120086670e+00
    phi[3,2]  R1049     -2.1677372455596924e+00
    phi[3,2]  R1050     -1.6088999509811401e+00
    phi[3,2]  R1051     -1.1517937183380127e+00
    phi[3,2]  R1052     0.957203209400177
    phi[3,2]  R1053     3.01701283454895
    phi[3,2]  R1054     -1.9385575056076050e+00
    phi[3,2]  R1055     -9.5563519001007080e-01
    phi[3,2]  R1056     7.5243420898914337e-02
    phi[3,2]  R1057     -7.1222299337387085e-01
    phi[3,2]  R1058     -1.1193968057632446e+00
    phi[3,2]  R1059     -3.7669193744659424e-01
    phi[3,2]  R1060     -2.1881020069122314e+00
    phi[3,2]  R1061     8.6858719587326050e-01
    phi[3,2]  R1062     -2.6590192317962646e-01
    phi[3,2]  R1063     -3.1796100139617920e+00
    phi[3,2]  R1064     -2.4320273399353027e+00
    phi[3,2]  R1065     -5.5871522426605225e-01
    phi[3,2]  R1066     -1.5804009437561035e+00
    phi[3,2]  R1067     -8.0338603258132935e-01
    phi[3,2]  R1068     -2.8337957859039307e+00
    phi[3,2]  R1069     4.0964207053184509e-01
    phi[3,2]  R1070     2.6495447158813477e+00
    phi[3,2]  R1071     1.1807355880737305e+00
    phi[3,2]  R1072     -1.6776765584945679e+00
    phi[3,2]  R1073     -8.5490250587463379e-01
    phi[3,2]  R1074     2.3538410663604736e+00
    phi[3,2]  R1075     3.1688454151153564e+00
    phi[3,2]  R1076     3.1361231803894043e+00
    phi[3,2]  R1077     2.9912164211273193e+00
    phi[3,2]  R1078     1.8295576572418213e+00
    phi[3,2]  R1079     -3.19368314743042
    phi[3,2]  R1080     6.6947031021118164e-01
    phi[3,2]  R1081     -3.4445145130157471e+00
    phi[3,2]  R1082     -1.0808966159820557e+00
    phi[3,2]  R1083     -2.2311987876892090e+00
    phi[3,2]  R1084     -1.2591081857681274e+00
    phi[3,2]  R1085     -1.7305009365081787e+00
    phi[3,2]  R1086     -2.0959346294403076e+00
    phi[3,2]  R1087     -2.29142427444458
    phi[3,2]  R1088     -2.6617805957794189e+00
    phi[3,2]  R1089     -2.2382667064666748e+00
    phi[3,2]  R1090     -1.2151820659637451e+00
    phi[3,2]  R1091     -2.9765939712524414e+00
    phi[3,2]  R1092     -9.6944558620452881e-01
    phi[3,2]  R1093     -1.7960803508758545e+00
    phi[3,2]  R1094     -3.1995387077331543e+00
    phi[3,2]  R1095     -1.5766398906707764e+00
    phi[3,2]  R1096     -1.6137137413024902e+00
    phi[3,2]  R1097     -2.0580091476440430e+00
    phi[3,2]  R1098     -1.8448010683059692e+00
    phi[3,2]  R1099     -2.3914577960968018e+00
    phi[3,2]  R1100     -2.0228438377380371e+00
    phi[3,2]  R1101     6.5702641010284424e-01
    phi[3,2]  R1102     -9.7103720903396606e-01
    phi[3,2]  R1103     -7.4370419979095459e-01
    phi[3,2]  R1104     -1.0047582387924194e+00
    phi[3,2]  R1105     -2.6662669181823730e+00
    phi[3,2]  R1106     -2.0306110382080078e+00
    phi[3,2]  R1107     -1.6265916824340820e+00
    phi[3,2]  R1108     8.2635164260864258e-01
    phi[3,2]  R1109     4.7496187686920166e-01
    phi[3,2]  R1110     4.1604065895080566e-01
    phi[3,2]  R1111     -2.0428361892700195e+00
    phi[3,2]  R1112     0.805109977722168
    phi[3,2]  R1113     -1.9300761222839355e+00
    phi[3,2]  R1114     -3.6203892230987549e+00
    phi[3,2]  R1115     1.0046698898077011e-01
    phi[3,2]  R1116     -1.9774116277694702e+00
    phi[3,2]  R1117     -8.0881166458129883e-01
    phi[3,2]  R1118     1.0769218206405640e+00
    phi[3,2]  R1119     -2.4481225013732910e+00
    phi[3,2]  R1120     -2.7345349788665771e+00
    phi[3,2]  R1121     -3.0040547847747803e+00
    phi[3,2]  R1122     -2.7625505924224854e+00
    phi[2,10]  R18       1
    phi[2,10]  R19       1
    phi[2,10]  R90       -1
    phi[2,10]  R1123     -3.0999999046325684e+00
    phi[2,10]  R1124     -3.0999999046325684e+00
    phi[2,10]  R1125     -2.2400000095367432e+00
    phi[2,10]  R1126     -2.2400000095367432e+00
    phi[2,10]  R1127     -3.0999999046325684e+00
    phi[2,10]  R1128     -3.0999999046325684e+00
    phi[2,10]  R1129     -2.5699999332427979e+00
    phi[2,10]  R1130     -2.5699999332427979e+00
    phi[2,10]  R1131     -3.0999999046325684e+00
    phi[2,10]  R1132     -3.0999999046325684e+00
    phi[2,10]  R1133     -2.0899999141693115e+00
    phi[2,10]  R1134     -2.0899999141693115e+00
    phi[2,10]  R1135     -3.0999999046325684e+00
    phi[2,10]  R1136     -3.0999999046325684e+00
    phi[2,10]  R1137     2.3538410663604736e+00
    phi[2,10]  R1138     3.1688454151153564e+00
    phi[2,10]  R1139     3.1361231803894043e+00
    phi[2,10]  R1140     2.9912164211273193e+00
    phi[2,10]  R1141     1.8295576572418213e+00
    phi[2,10]  R1142     -3.19368314743042
    phi[2,10]  R1143     6.6947031021118164e-01
    phi[2,10]  R1144     -3.4445145130157471e+00
    phi[2,10]  R1145     -1.0808966159820557e+00
    phi[2,10]  R1146     -2.2311987876892090e+00
    phi[2,10]  R1147     -1.2591081857681274e+00
    phi[2,10]  R1148     -1.7305009365081787e+00
    phi[2,10]  R1149     -2.0959346294403076e+00
    phi[2,10]  R1150     -2.29142427444458
    phi[2,10]  R1151     -2.6617805957794189e+00
    phi[2,10]  R1152     -2.2382667064666748e+00
    phi[2,10]  R1153     -1.2151820659637451e+00
    phi[2,10]  R1154     -2.9765939712524414e+00
    phi[2,10]  R1155     -9.6944558620452881e-01
    phi[2,10]  R1156     -1.7960803508758545e+00
    phi[2,10]  R1157     -3.1995387077331543e+00
    phi[2,10]  R1158     -1.5766398906707764e+00
    phi[2,10]  R1159     -1.6137137413024902e+00
    phi[2,10]  R1160     -2.0580091476440430e+00
    phi[2,10]  R1161     -1.8448010683059692e+00
    phi[2,10]  R1162     -2.3914577960968018e+00
    phi[2,10]  R1163     -2.0228438377380371e+00
    phi[2,10]  R1164     6.5702641010284424e-01
    phi[2,10]  R1165     -9.7103720903396606e-01
    phi[2,10]  R1166     -7.4370419979095459e-01
    phi[2,10]  R1167     -1.0047582387924194e+00
    phi[2,10]  R1168     -2.6662669181823730e+00
    phi[2,10]  R1169     -2.0306110382080078e+00
    phi[2,10]  R1170     -1.6265916824340820e+00
    phi[2,10]  R1171     8.2635164260864258e-01
    phi[2,10]  R1172     4.7496187686920166e-01
    phi[2,10]  R1173     4.1604065895080566e-01
    phi[2,10]  R1174     -2.0428361892700195e+00
    phi[2,10]  R1175     0.805109977722168
    phi[2,10]  R1176     -1.9300761222839355e+00
    phi[2,10]  R1177     -3.6203892230987549e+00
    phi[2,10]  R1178     1.0046698898077011e-01
    phi[2,10]  R1179     -1.9774116277694702e+00
    phi[2,10]  R1180     -8.0881166458129883e-01
    phi[2,10]  R1181     1.0769218206405640e+00
    phi[2,10]  R1182     -2.4481225013732910e+00
    phi[2,10]  R1183     -2.7345349788665771e+00
    phi[2,10]  R1184     -3.0040547847747803e+00
    phi[2,10]  R1185     -2.7625505924224854e+00
    phi[2,10]  R1186     1.5985418558120728e+00
    phi[2,10]  R1187     5.8380788564682007e-01
    phi[2,10]  R1188     1.8765554428100586e+00
    phi[2,10]  R1189     1.0134727954864502e+00
    phi[2,10]  R1190     1.5521807670593262e+00
    phi[2,10]  R1191     -3.1512522697448730e-01
    phi[2,10]  R1192     2.0058498382568359e+00
    phi[2,10]  R1193     1.5670864582061768e+00
    phi[2,10]  R1194     -2.2531807422637939e-01
    phi[2,10]  R1195     -1.4889042377471924e+00
    phi[2,10]  R1196     -2.8928515911102295e+00
    phi[2,10]  R1197     -1.9395288228988647e+00
    phi[2,10]  R1198     -1.8933738470077515e+00
    phi[2,10]  R1199     -3.5338141918182373e+00
    phi[2,10]  R1200     -1.6068809032440186e+00
    phi[2,10]  R1201     2.1437532901763916e+00
    phi[2,10]  R1202     -2.3747682571411133e+00
    phi[2,10]  R1203     -2.94879412651062
    phi[2,10]  R1204     -9.8583489656448364e-01
    phi[2,10]  R1205     -2.7908730506896973e+00
    phi[2,10]  R1206     -2.4305260181427
    phi[2,10]  R1207     -3.0656330585479736e+00
    phi[2,10]  R1208     -3.1409878730773926e+00
    phi[2,10]  R1209     -1.6800541877746582e+00
    phi[2,10]  R1210     -1.1210966110229492e+00
    phi[2,10]  R1211     6.4095509052276611e-01
    phi[2,10]  R1212     1.0346718132495880e-01
    phi[2,10]  R1213     -5.0856810808181763e-01
    phi[2,10]  R1214     2.5213744640350342e+00
    phi[2,10]  R1215     -5.8772259950637817e-01
    phi[2,10]  R1216     -1.3815438747406006e+00
    phi[2,10]  R1217     -2.6550364494323730e+00
    phi[2,10]  R1218     -1.7782332897186279e+00
    phi[2,10]  R1219     -1.7554315328598022e+00
    phi[2,10]  R1220     -2.4815697669982910e+00
    phi[2,10]  R1221     2.5347137451171875e-01
    phi[2,10]  R1222     -1.2748326361179352e-01
    phi[2,10]  R1223     -7.2897094488143921e-01
    phi[2,10]  R1224     4.9220538139343262e-01
    phi[2,10]  R1225     2.5374369621276855e+00
    phi[10,2]  R18       -1
    phi[10,2]  R90       1
    phi[10,2]  R91       1
    phi[10,2]  R1226     -3.0999999046325684e+00
    phi[10,2]  R1227     -3.0999999046325684e+00
    phi[10,2]  R1228     -2.2400000095367432e+00
    phi[10,2]  R1229     -2.2400000095367432e+00
    phi[10,2]  R1230     -3.0999999046325684e+00
    phi[10,2]  R1231     -3.0999999046325684e+00
    phi[10,2]  R1232     -2.5699999332427979e+00
    phi[10,2]  R1233     -2.5699999332427979e+00
    phi[10,2]  R1234     -3.0999999046325684e+00
    phi[10,2]  R1235     -3.0999999046325684e+00
    phi[10,2]  R1236     -2.0899999141693115e+00
    phi[10,2]  R1237     -2.0899999141693115e+00
    phi[10,2]  R1238     -3.0999999046325684e+00
    phi[10,2]  R1239     -3.0999999046325684e+00
    phi[10,2]  R1240     1.5985418558120728e+00
    phi[10,2]  R1241     5.8380788564682007e-01
    phi[10,2]  R1242     1.8765554428100586e+00
    phi[10,2]  R1243     1.0134727954864502e+00
    phi[10,2]  R1244     1.5521807670593262e+00
    phi[10,2]  R1245     -3.1512522697448730e-01
    phi[10,2]  R1246     2.0058498382568359e+00
    phi[10,2]  R1247     1.5670864582061768e+00
    phi[10,2]  R1248     -2.2531807422637939e-01
    phi[10,2]  R1249     -1.4889042377471924e+00
    phi[10,2]  R1250     -2.8928515911102295e+00
    phi[10,2]  R1251     -1.9395288228988647e+00
    phi[10,2]  R1252     -1.8933738470077515e+00
    phi[10,2]  R1253     -3.5338141918182373e+00
    phi[10,2]  R1254     -1.6068809032440186e+00
    phi[10,2]  R1255     2.1437532901763916e+00
    phi[10,2]  R1256     -2.3747682571411133e+00
    phi[10,2]  R1257     -2.94879412651062
    phi[10,2]  R1258     -9.8583489656448364e-01
    phi[10,2]  R1259     -2.7908730506896973e+00
    phi[10,2]  R1260     -2.4305260181427
    phi[10,2]  R1261     -3.0656330585479736e+00
    phi[10,2]  R1262     -3.1409878730773926e+00
    phi[10,2]  R1263     -1.6800541877746582e+00
    phi[10,2]  R1264     -1.1210966110229492e+00
    phi[10,2]  R1265     6.4095509052276611e-01
    phi[10,2]  R1266     1.0346718132495880e-01
    phi[10,2]  R1267     -5.0856810808181763e-01
    phi[10,2]  R1268     2.5213744640350342e+00
    phi[10,2]  R1269     -5.8772259950637817e-01
    phi[10,2]  R1270     -1.3815438747406006e+00
    phi[10,2]  R1271     -2.6550364494323730e+00
    phi[10,2]  R1272     -1.7782332897186279e+00
    phi[10,2]  R1273     -1.7554315328598022e+00
    phi[10,2]  R1274     -2.4815697669982910e+00
    phi[10,2]  R1275     2.5347137451171875e-01
    phi[10,2]  R1276     -1.2748326361179352e-01
    phi[10,2]  R1277     -7.2897094488143921e-01
    phi[10,2]  R1278     4.9220538139343262e-01
    phi[10,2]  R1279     2.5374369621276855e+00
    phi[10,2]  R1280     2.3538410663604736e+00
    phi[10,2]  R1281     3.1688454151153564e+00
    phi[10,2]  R1282     3.1361231803894043e+00
    phi[10,2]  R1283     2.9912164211273193e+00
    phi[10,2]  R1284     1.8295576572418213e+00
    phi[10,2]  R1285     -3.19368314743042
    phi[10,2]  R1286     6.6947031021118164e-01
    phi[10,2]  R1287     -3.4445145130157471e+00
    phi[10,2]  R1288     -1.0808966159820557e+00
    phi[10,2]  R1289     -2.2311987876892090e+00
    phi[10,2]  R1290     -1.2591081857681274e+00
    phi[10,2]  R1291     -1.7305009365081787e+00
    phi[10,2]  R1292     -2.0959346294403076e+00
    phi[10,2]  R1293     -2.29142427444458
    phi[10,2]  R1294     -2.6617805957794189e+00
    phi[10,2]  R1295     -2.2382667064666748e+00
    phi[10,2]  R1296     -1.2151820659637451e+00
    phi[10,2]  R1297     -2.9765939712524414e+00
    phi[10,2]  R1298     -9.6944558620452881e-01
    phi[10,2]  R1299     -1.7960803508758545e+00
    phi[10,2]  R1300     -3.1995387077331543e+00
    phi[10,2]  R1301     -1.5766398906707764e+00
    phi[10,2]  R1302     -1.6137137413024902e+00
    phi[10,2]  R1303     -2.0580091476440430e+00
    phi[10,2]  R1304     -1.8448010683059692e+00
    phi[10,2]  R1305     -2.3914577960968018e+00
    phi[10,2]  R1306     -2.0228438377380371e+00
    phi[10,2]  R1307     6.5702641010284424e-01
    phi[10,2]  R1308     -9.7103720903396606e-01
    phi[10,2]  R1309     -7.4370419979095459e-01
    phi[10,2]  R1310     -1.0047582387924194e+00
    phi[10,2]  R1311     -2.6662669181823730e+00
    phi[10,2]  R1312     -2.0306110382080078e+00
    phi[10,2]  R1313     -1.6265916824340820e+00
    phi[10,2]  R1314     8.2635164260864258e-01
    phi[10,2]  R1315     4.7496187686920166e-01
    phi[10,2]  R1316     4.1604065895080566e-01
    phi[10,2]  R1317     -2.0428361892700195e+00
    phi[10,2]  R1318     0.805109977722168
    phi[10,2]  R1319     -1.9300761222839355e+00
    phi[10,2]  R1320     -3.6203892230987549e+00
    phi[10,2]  R1321     1.0046698898077011e-01
    phi[10,2]  R1322     -1.9774116277694702e+00
    phi[10,2]  R1323     -8.0881166458129883e-01
    phi[10,2]  R1324     1.0769218206405640e+00
    phi[10,2]  R1325     -2.4481225013732910e+00
    phi[10,2]  R1326     -2.7345349788665771e+00
    phi[10,2]  R1327     -3.0040547847747803e+00
    phi[10,2]  R1328     -2.7625505924224854e+00
    phi[3,10]  R27       1
    phi[3,10]  R28       1
    phi[3,10]  R90       -1
    phi[3,10]  R1329     -3.0999999046325684e+00
    phi[3,10]  R1330     -3.0999999046325684e+00
    phi[3,10]  R1331     -2.2400000095367432e+00
    phi[3,10]  R1332     -2.2400000095367432e+00
    phi[3,10]  R1333     -3.0999999046325684e+00
    phi[3,10]  R1334     -3.0999999046325684e+00
    phi[3,10]  R1335     -2.5699999332427979e+00
    phi[3,10]  R1336     -2.5699999332427979e+00
    phi[3,10]  R1337     -3.0999999046325684e+00
    phi[3,10]  R1338     -3.0999999046325684e+00
    phi[3,10]  R1339     -2.0899999141693115e+00
    phi[3,10]  R1340     -2.0899999141693115e+00
    phi[3,10]  R1341     -3.0999999046325684e+00
    phi[3,10]  R1342     -3.0999999046325684e+00
    phi[3,10]  R1343     1.0798842906951904e+00
    phi[3,10]  R1344     -0.59750896692276
    phi[3,10]  R1345     4.2518103122711182e-01
    phi[3,10]  R1346     4.6684658527374268e-01
    phi[3,10]  R1347     8.2515043020248413e-01
    phi[3,10]  R1348     -7.8722901642322540e-02
    phi[3,10]  R1349     1.6394654512405396e+00
    phi[3,10]  R1350     2.5442276000976562e+00
    phi[3,10]  R1351     1.2507046759128571e-01
    phi[3,10]  R1352     1.6426980495452881e+00
    phi[3,10]  R1353     -2.7137744426727295e+00
    phi[3,10]  R1354     -3.9888422489166260e+00
    phi[3,10]  R1355     -3.1454153060913086e+00
    phi[3,10]  R1356     -4.1362495422363281e+00
    phi[3,10]  R1357     -3.3785805702209473e+00
    phi[3,10]  R1358     -2.4628889560699463e+00
    phi[3,10]  R1359     -2.5663504600524902e+00
    phi[3,10]  R1360     -1.6674994230270386e+00
    phi[3,10]  R1361     -1.5608620643615723e+00
    phi[3,10]  R1362     -3.2919411659240723e+00
    phi[3,10]  R1363     -1.4330687522888184e+00
    phi[3,10]  R1364     2.9237198829650879e-01
    phi[3,10]  R1365     -1.6780118942260742e+00
    phi[3,10]  R1366     -2.3134617805480957e+00
    phi[3,10]  R1367     -6.6249656677246094e-01
    phi[3,10]  R1368     5.4922741651535034e-01
    phi[3,10]  R1369     7.5848260894417763e-03
    phi[3,10]  R1370     -7.6035803556442261e-01
    phi[3,10]  R1371     -2.3523557186126709e-01
    phi[3,10]  R1372     -6.8577539920806885e-01
    phi[3,10]  R1373     -4.7650939226150513e-01
    phi[3,10]  R1374     -2.3743910789489746e+00
    phi[3,10]  R1375     4.3360877037048340e-01
    phi[3,10]  R1376     -1.8561365604400635e+00
    phi[3,10]  R1377     -2.2723183631896973e+00
    phi[3,10]  R1378     -2.3256626129150391e+00
    phi[3,10]  R1379     4.4216984510421753e-01
    phi[3,10]  R1380     -2.7211077213287354e+00
    phi[3,10]  R1381     4.0807131677865982e-02
    phi[3,10]  R1382     -1.0204231739044189e+00
    phi[3,10]  R1383     -2.7367684245109558e-01
    phi[3,10]  R1384     -3.8462462425231934e+00
    phi[3,10]  R1385     -1.8324840068817139e+00
    phi[3,10]  R1386     -1.2517206668853760e+00
    phi[3,10]  R1387     -1.8497455120086670e+00
    phi[3,10]  R1388     -2.1677372455596924e+00
    phi[3,10]  R1389     -1.6088999509811401e+00
    phi[3,10]  R1390     -1.1517937183380127e+00
    phi[3,10]  R1391     0.957203209400177
    phi[3,10]  R1392     3.01701283454895
    phi[3,10]  R1393     -1.9385575056076050e+00
    phi[3,10]  R1394     -9.5563519001007080e-01
    phi[3,10]  R1395     7.5243420898914337e-02
    phi[3,10]  R1396     -7.1222299337387085e-01
    phi[3,10]  R1397     -1.1193968057632446e+00
    phi[3,10]  R1398     -3.7669193744659424e-01
    phi[3,10]  R1399     -2.1881020069122314e+00
    phi[3,10]  R1400     8.6858719587326050e-01
    phi[3,10]  R1401     -2.6590192317962646e-01
    phi[3,10]  R1402     -3.1796100139617920e+00
    phi[3,10]  R1403     -2.4320273399353027e+00
    phi[3,10]  R1404     -5.5871522426605225e-01
    phi[3,10]  R1405     -1.5804009437561035e+00
    phi[3,10]  R1406     -8.0338603258132935e-01
    phi[3,10]  R1407     -2.8337957859039307e+00
    phi[3,10]  R1408     4.0964207053184509e-01
    phi[3,10]  R1409     2.6495447158813477e+00
    phi[3,10]  R1410     1.1807355880737305e+00
    phi[3,10]  R1411     -1.6776765584945679e+00
    phi[3,10]  R1412     -8.5490250587463379e-01
    phi[3,10]  R1413     1.5985418558120728e+00
    phi[3,10]  R1414     5.8380788564682007e-01
    phi[3,10]  R1415     1.8765554428100586e+00
    phi[3,10]  R1416     1.0134727954864502e+00
    phi[3,10]  R1417     1.5521807670593262e+00
    phi[3,10]  R1418     -3.1512522697448730e-01
    phi[3,10]  R1419     2.0058498382568359e+00
    phi[3,10]  R1420     1.5670864582061768e+00
    phi[3,10]  R1421     -2.2531807422637939e-01
    phi[3,10]  R1422     -1.4889042377471924e+00
    phi[3,10]  R1423     -2.8928515911102295e+00
    phi[3,10]  R1424     -1.9395288228988647e+00
    phi[3,10]  R1425     -1.8933738470077515e+00
    phi[3,10]  R1426     -3.5338141918182373e+00
    phi[3,10]  R1427     -1.6068809032440186e+00
    phi[3,10]  R1428     2.1437532901763916e+00
    phi[3,10]  R1429     -2.3747682571411133e+00
    phi[3,10]  R1430     -2.94879412651062
    phi[3,10]  R1431     -9.8583489656448364e-01
    phi[3,10]  R1432     -2.7908730506896973e+00
    phi[3,10]  R1433     -2.4305260181427
    phi[3,10]  R1434     -3.0656330585479736e+00
    phi[3,10]  R1435     -3.1409878730773926e+00
    phi[3,10]  R1436     -1.6800541877746582e+00
    phi[3,10]  R1437     -1.1210966110229492e+00
    phi[3,10]  R1438     6.4095509052276611e-01
    phi[3,10]  R1439     1.0346718132495880e-01
    phi[3,10]  R1440     -5.0856810808181763e-01
    phi[3,10]  R1441     2.5213744640350342e+00
    phi[3,10]  R1442     -5.8772259950637817e-01
    phi[3,10]  R1443     -1.3815438747406006e+00
    phi[3,10]  R1444     -2.6550364494323730e+00
    phi[3,10]  R1445     -1.7782332897186279e+00
    phi[3,10]  R1446     -1.7554315328598022e+00
    phi[3,10]  R1447     -2.4815697669982910e+00
    phi[3,10]  R1448     2.5347137451171875e-01
    phi[3,10]  R1449     -1.2748326361179352e-01
    phi[3,10]  R1450     -7.2897094488143921e-01
    phi[3,10]  R1451     4.9220538139343262e-01
    phi[3,10]  R1452     2.5374369621276855e+00
    phi[10,3]  R27       -1
    phi[10,3]  R90       1
    phi[10,3]  R91       1
    phi[10,3]  R1453     -3.0999999046325684e+00
    phi[10,3]  R1454     -3.0999999046325684e+00
    phi[10,3]  R1455     -2.2400000095367432e+00
    phi[10,3]  R1456     -2.2400000095367432e+00
    phi[10,3]  R1457     -3.0999999046325684e+00
    phi[10,3]  R1458     -3.0999999046325684e+00
    phi[10,3]  R1459     -2.5699999332427979e+00
    phi[10,3]  R1460     -2.5699999332427979e+00
    phi[10,3]  R1461     -3.0999999046325684e+00
    phi[10,3]  R1462     -3.0999999046325684e+00
    phi[10,3]  R1463     -2.0899999141693115e+00
    phi[10,3]  R1464     -2.0899999141693115e+00
    phi[10,3]  R1465     -3.0999999046325684e+00
    phi[10,3]  R1466     -3.0999999046325684e+00
    phi[10,3]  R1467     1.5985418558120728e+00
    phi[10,3]  R1468     5.8380788564682007e-01
    phi[10,3]  R1469     1.8765554428100586e+00
    phi[10,3]  R1470     1.0134727954864502e+00
    phi[10,3]  R1471     1.5521807670593262e+00
    phi[10,3]  R1472     -3.1512522697448730e-01
    phi[10,3]  R1473     2.0058498382568359e+00
    phi[10,3]  R1474     1.5670864582061768e+00
    phi[10,3]  R1475     -2.2531807422637939e-01
    phi[10,3]  R1476     -1.4889042377471924e+00
    phi[10,3]  R1477     -2.8928515911102295e+00
    phi[10,3]  R1478     -1.9395288228988647e+00
    phi[10,3]  R1479     -1.8933738470077515e+00
    phi[10,3]  R1480     -3.5338141918182373e+00
    phi[10,3]  R1481     -1.6068809032440186e+00
    phi[10,3]  R1482     2.1437532901763916e+00
    phi[10,3]  R1483     -2.3747682571411133e+00
    phi[10,3]  R1484     -2.94879412651062
    phi[10,3]  R1485     -9.8583489656448364e-01
    phi[10,3]  R1486     -2.7908730506896973e+00
    phi[10,3]  R1487     -2.4305260181427
    phi[10,3]  R1488     -3.0656330585479736e+00
    phi[10,3]  R1489     -3.1409878730773926e+00
    phi[10,3]  R1490     -1.6800541877746582e+00
    phi[10,3]  R1491     -1.1210966110229492e+00
    phi[10,3]  R1492     6.4095509052276611e-01
    phi[10,3]  R1493     1.0346718132495880e-01
    phi[10,3]  R1494     -5.0856810808181763e-01
    phi[10,3]  R1495     2.5213744640350342e+00
    phi[10,3]  R1496     -5.8772259950637817e-01
    phi[10,3]  R1497     -1.3815438747406006e+00
    phi[10,3]  R1498     -2.6550364494323730e+00
    phi[10,3]  R1499     -1.7782332897186279e+00
    phi[10,3]  R1500     -1.7554315328598022e+00
    phi[10,3]  R1501     -2.4815697669982910e+00
    phi[10,3]  R1502     2.5347137451171875e-01
    phi[10,3]  R1503     -1.2748326361179352e-01
    phi[10,3]  R1504     -7.2897094488143921e-01
    phi[10,3]  R1505     4.9220538139343262e-01
    phi[10,3]  R1506     2.5374369621276855e+00
    phi[10,3]  R1507     1.0798842906951904e+00
    phi[10,3]  R1508     -0.59750896692276
    phi[10,3]  R1509     4.2518103122711182e-01
    phi[10,3]  R1510     4.6684658527374268e-01
    phi[10,3]  R1511     8.2515043020248413e-01
    phi[10,3]  R1512     -7.8722901642322540e-02
    phi[10,3]  R1513     1.6394654512405396e+00
    phi[10,3]  R1514     2.5442276000976562e+00
    phi[10,3]  R1515     1.2507046759128571e-01
    phi[10,3]  R1516     1.6426980495452881e+00
    phi[10,3]  R1517     -2.7137744426727295e+00
    phi[10,3]  R1518     -3.9888422489166260e+00
    phi[10,3]  R1519     -3.1454153060913086e+00
    phi[10,3]  R1520     -4.1362495422363281e+00
    phi[10,3]  R1521     -3.3785805702209473e+00
    phi[10,3]  R1522     -2.4628889560699463e+00
    phi[10,3]  R1523     -2.5663504600524902e+00
    phi[10,3]  R1524     -1.6674994230270386e+00
    phi[10,3]  R1525     -1.5608620643615723e+00
    phi[10,3]  R1526     -3.2919411659240723e+00
    phi[10,3]  R1527     -1.4330687522888184e+00
    phi[10,3]  R1528     2.9237198829650879e-01
    phi[10,3]  R1529     -1.6780118942260742e+00
    phi[10,3]  R1530     -2.3134617805480957e+00
    phi[10,3]  R1531     -6.6249656677246094e-01
    phi[10,3]  R1532     5.4922741651535034e-01
    phi[10,3]  R1533     7.5848260894417763e-03
    phi[10,3]  R1534     -7.6035803556442261e-01
    phi[10,3]  R1535     -2.3523557186126709e-01
    phi[10,3]  R1536     -6.8577539920806885e-01
    phi[10,3]  R1537     -4.7650939226150513e-01
    phi[10,3]  R1538     -2.3743910789489746e+00
    phi[10,3]  R1539     4.3360877037048340e-01
    phi[10,3]  R1540     -1.8561365604400635e+00
    phi[10,3]  R1541     -2.2723183631896973e+00
    phi[10,3]  R1542     -2.3256626129150391e+00
    phi[10,3]  R1543     4.4216984510421753e-01
    phi[10,3]  R1544     -2.7211077213287354e+00
    phi[10,3]  R1545     4.0807131677865982e-02
    phi[10,3]  R1546     -1.0204231739044189e+00
    phi[10,3]  R1547     -2.7367684245109558e-01
    phi[10,3]  R1548     -3.8462462425231934e+00
    phi[10,3]  R1549     -1.8324840068817139e+00
    phi[10,3]  R1550     -1.2517206668853760e+00
    phi[10,3]  R1551     -1.8497455120086670e+00
    phi[10,3]  R1552     -2.1677372455596924e+00
    phi[10,3]  R1553     -1.6088999509811401e+00
    phi[10,3]  R1554     -1.1517937183380127e+00
    phi[10,3]  R1555     0.957203209400177
    phi[10,3]  R1556     3.01701283454895
    phi[10,3]  R1557     -1.9385575056076050e+00
    phi[10,3]  R1558     -9.5563519001007080e-01
    phi[10,3]  R1559     7.5243420898914337e-02
    phi[10,3]  R1560     -7.1222299337387085e-01
    phi[10,3]  R1561     -1.1193968057632446e+00
    phi[10,3]  R1562     -3.7669193744659424e-01
    phi[10,3]  R1563     -2.1881020069122314e+00
    phi[10,3]  R1564     8.6858719587326050e-01
    phi[10,3]  R1565     -2.6590192317962646e-01
    phi[10,3]  R1566     -3.1796100139617920e+00
    phi[10,3]  R1567     -2.4320273399353027e+00
    phi[10,3]  R1568     -5.5871522426605225e-01
    phi[10,3]  R1569     -1.5804009437561035e+00
    phi[10,3]  R1570     -8.0338603258132935e-01
    phi[10,3]  R1571     -2.8337957859039307e+00
    phi[10,3]  R1572     4.0964207053184509e-01
    phi[10,3]  R1573     2.6495447158813477e+00
    phi[10,3]  R1574     1.1807355880737305e+00
    phi[10,3]  R1575     -1.6776765584945679e+00
    phi[10,3]  R1576     -8.5490250587463379e-01
    phi[3,12]  R27       1
    phi[3,12]  R28       1
    phi[3,12]  R29       1.9933044912139959e+00
    phi[3,12]  R30       -1.4009757778449381e+00
    phi[3,12]  R31       -1.2154758672111909e+00
    phi[3,12]  R32       -9.3886620060333836e-01
    phi[3,12]  R33       2.2911676762182753e+00
    phi[3,12]  R34       8.8766089629573086e-01
    phi[3,12]  R35       2.3022944713510531e+00
    phi[3,12]  R100      -1
    phi[3,12]  R1577     -1.1066954134185725e+00
    phi[3,12]  R1578     -5.0933043958465642e+00
    phi[3,12]  R1579     -3.6409757873816813e+00
    phi[3,12]  R1580     -8.3902423169180507e-01
    phi[3,12]  R1581     -4.31547577184376
    phi[3,12]  R1582     -1.8845240374213774e+00
    phi[3,12]  R1583     -3.5088661338461362e+00
    phi[3,12]  R1584     -1.6311337326394595e+00
    phi[3,12]  R1585     -0.808832228414293
    phi[3,12]  R1586     -5.3911675808508441e+00
    phi[3,12]  R1587     -1.2023390178735807e+00
    phi[3,12]  R1588     -2.9776608104650424e+00
    phi[3,12]  R1589     -7.9770543328151522e-01
    phi[3,12]  R1590     -5.4022943759836215e+00
    phi[3,12]  R1591     -0.655249876293404
    phi[3,12]  R1592     -6.3462579740632086e-01
    phi[3,12]  R1593     -8.5377452255870323e-01
    phi[3,12]  R1594     -5.8149205232554624e-01
    phi[3,12]  R1595     -5.3791553359213840e-01
    phi[3,12]  R1596     -0.817961096309996
    phi[3,12]  R1597     -4.5045439299981371e-01
    phi[3,12]  R1598     -4.5843479922036767e-01
    phi[3,12]  R1599     -4.9122944522149381e-01
    phi[3,12]  R1600     -4.9984599649821337e-01
    phi[3,12]  R1601     -8.3564970942005457e-01
    phi[3,12]  R1602     -1.1256325129744549e+00
    phi[3,12]  R1603     -3.9782118178037962e-01
    phi[3,12]  R1604     -3.2849863444581207e-01
    phi[3,12]  R1605     -3.4229497517073870e-01
    phi[3,12]  R1606     -3.6252237693912859e-01
    phi[3,12]  R1607     -3.7790428647125163e-01
    phi[3,12]  R1608     -4.2089262018688567e-01
    phi[3,12]  R1609     -4.2916479454699319e-01
    phi[3,12]  R1610     -0.95774876003175
    phi[3,12]  R1611     -6.2283792284522510e-01
    phi[3,12]  R1612     -7.4268650849390649e-01
    phi[3,12]  R1613     -1.8260847933086526e+00
    phi[3,12]  R1614     -3.3360167582948330e-01
    phi[3,12]  R1615     -3.5757105133337952e-01
    phi[3,12]  R1616     -5.5074604089457124e-01
    phi[3,12]  R1617     -4.9768777543993581e-01
    phi[3,12]  R1618     -1.1456786894923434e+00
    phi[3,12]  R1619     -4.1238933693136115e-01
    phi[3,12]  R1620     -4.2399082053716164e-01
    phi[3,12]  R1621     -1.0468957992373227e+00
    phi[3,12]  R1622     -2.1563006913042537e-01
    phi[3,12]  R1623     -8.4531466596917260e-01
    phi[3,12]  R1624     -2.5516931011764266e-01
    phi[3,12]  R1625     -7.0540608798416415e-01
    phi[3,12]  R1626     -1.0387246148407130e+00
    phi[3,12]  R1627     -3.0976983420934867e-01
    phi[3,12]  R1628     -1.9305786711389596e+00
    phi[3,12]  R1629     -3.2901847104543980e-01
    phi[3,12]  R1630     -0.348420295563997
    phi[3,12]  R1631     -2.5751892486977646e-01
    phi[3,12]  R1632     -1.0799945531787873e+00
    phi[3,12]  R1633     -9.7133831089082490e-01
    phi[3,12]  R1634     -2.9594580043716479e-01
    phi[3,12]  R1635     -6.2409650619900758e-01
    phi[3,12]  R1636     -0.344070256622129
    phi[3,12]  R1637     -1.2290788360804557e+00
    phi[3,12]  R1638     -1.8282241786786395e+00
    phi[3,12]  R1639     -4.4864267056121254e-01
    phi[3,12]  R1640     -5.0539609368202232e-01
    phi[3,12]  R1641     -7.4510998758679348e-01
    phi[3,12]  R1642     -9.5807857782757555e-01
    phi[3,12]  R1643     -5.8128708993361977e-01
    phi[3,12]  R1644     -6.4221422735562284e-01
    phi[3,12]  R1645     -2.8091578747078061e-01
    phi[3,12]  R1646     -5.5914503351295042e-01
    phi[3,12]  R1647     -1.8516055567745042e+00
    phi[3,12]  R1648     -3.1829511186027104e-01
    phi[3,12]  R1649     -3.2516080597163743e-01
    phi[3,12]  R1650     -3.5203223456704347e-01
    phi[3,12]  R1651     -9.6151494169837726e-01
    phi[3,12]  R1652     -5.2119648796027107e-01
    phi[3,12]  R1653     -2.3882040932901272e-01
    phi[3,12]  R1654     -2.4002536353550430e-01
    phi[3,12]  R1655     -3.2653670383741584e-01
    phi[3,12]  R1656     -3.3349298203810818e-01
    phi[3,12]  R1657     -3.7552006042285946e-01
    phi[3,12]  R1658     -6.2828966831855770e-01
    phi[3,12]  R1659     -1.8086425173579819e+00
    phi[3,12]  R1660     -1.9917883400306007e+00
    phi[4,5]  R36       1
    phi[4,5]  R37       1
    phi[4,5]  R45       -1
    phi[4,5]  R1661     -3.0999999046325684e+00
    phi[4,5]  R1662     -3.0999999046325684e+00
    phi[4,5]  R1663     -2.2400000095367432e+00
    phi[4,5]  R1664     -2.2400000095367432e+00
    phi[4,5]  R1665     -3.0999999046325684e+00
    phi[4,5]  R1666     -3.0999999046325684e+00
    phi[4,5]  R1667     -2.5699999332427979e+00
    phi[4,5]  R1668     -2.5699999332427979e+00
    phi[4,5]  R1669     -3.0999999046325684e+00
    phi[4,5]  R1670     -3.0999999046325684e+00
    phi[4,5]  R1671     -2.0899999141693115e+00
    phi[4,5]  R1672     -2.0899999141693115e+00
    phi[4,5]  R1673     -3.0999999046325684e+00
    phi[4,5]  R1674     -3.0999999046325684e+00
    phi[4,5]  R1675     1.3253046274185181e+00
    phi[4,5]  R1676     3.9761909842491150e-01
    phi[4,5]  R1677     5.2724522352218628e-01
    phi[4,5]  R1678     -0.0084505844861269
    phi[4,5]  R1679     2.5511163473129272e-01
    phi[4,5]  R1680     7.4777173995971680e-01
    phi[4,5]  R1681     7.2634738683700562e-01
    phi[4,5]  R1682     9.9240273237228394e-01
    phi[4,5]  R1683     0.546148955821991
    phi[4,5]  R1684     5.5241447687149048e-01
    phi[4,5]  R1685     -1.1435811519622803e+00
    phi[4,5]  R1686     -1.5849117040634155e+00
    phi[4,5]  R1687     -1.6014122962951660e+00
    phi[4,5]  R1688     -1.9174997806549072e+00
    phi[4,5]  R1689     -5.8350926637649536e-01
    phi[4,5]  R1690     -2.0852053165435791e+00
    phi[4,5]  R1691     -1.0248399972915649e+00
    phi[4,5]  R1692     -1.4011521339416504e+00
    phi[4,5]  R1693     -2.0342090129852295e+00
    phi[4,5]  R1694     -2.6230406761169434e+00
    phi[4,5]  R1695     -1.5807336568832397e+00
    phi[4,5]  R1696     -1.7757858037948608e+00
    phi[4,5]  R1697     -2.0689892768859863e+00
    phi[4,5]  R1698     -1.9513186216354370e+00
    phi[4,5]  R1699     -2.2459280490875244e+00
    phi[4,5]  R1700     -7.1136569976806641e-01
    phi[4,5]  R1701     -1.8230395317077637e+00
    phi[4,5]  R1702     -1.8808318376541138e+00
    phi[4,5]  R1703     -8.9955651760101318e-01
    phi[4,5]  R1704     -1.7513449490070343e-01
    phi[4,5]  R1705     -1.1597578525543213e+00
    phi[4,5]  R1706     -1.7768043279647827e+00
    phi[4,5]  R1707     -8.8181060552597046e-01
    phi[4,5]  R1708     -9.9230170249938965e-01
    phi[4,5]  R1709     -5.7461428642272949e-01
    phi[4,5]  R1710     -1.5933365821838379e+00
    phi[4,5]  R1711     -1.5120373964309692e+00
    phi[4,5]  R1712     -0.900452196598053
    phi[4,5]  R1713     -1.3337709903717041e+00
    phi[4,5]  R1714     -9.3368732929229736e-01
    phi[4,5]  R1715     -2.25651216506958
    phi[4,5]  R1716     -1.9074938297271729e+00
    phi[4,5]  R1717     -1.2941697835922241e+00
    phi[4,5]  R1718     -1.8284888267517090e+00
    phi[4,5]  R1719     -1.1415930986404419e+00
    phi[4,5]  R1720     -1.7610708475112915e+00
    phi[4,5]  R1721     -3.4316429495811462e-01
    phi[4,5]  R1722     1.1219238489866257e-01
    phi[4,5]  R1723     -1.1211214959621429e-01
    phi[4,5]  R1724     -3.7155583500862122e-01
    phi[4,5]  R1725     -9.8686635494232178e-01
    phi[4,5]  R1726     -5.3069496154785156e-01
    phi[4,5]  R1727     -9.9010002613067627e-01
    phi[4,5]  R1728     4.8152637481689453e-01
    phi[4,5]  R1729     3.4690135717391968e-01
    phi[4,5]  R1730     -3.2946936786174774e-02
    phi[4,5]  R1731     -7.8122121095657349e-01
    phi[4,5]  R1732     4.1269031167030334e-01
    phi[4,5]  R1733     3.8940995931625366e-01
    phi[4,5]  R1734     -4.2851552367210388e-01
    phi[4,5]  R1735     -7.7629715204238892e-01
    phi[4,5]  R1736     -1.2039066553115845e+00
    phi[4,5]  R1737     -4.2492717504501343e-01
    phi[4,5]  R1738     -2.2598148882389069e-01
    phi[4,5]  R1739     -7.9831713438034058e-01
    phi[4,5]  R1740     -8.2729059457778931e-01
    phi[4,5]  R1741     -7.3914241790771484e-01
    phi[4,5]  R1742     -6.2965881824493408e-01
    phi[4,5]  R1743     -1.5382294654846191e+00
    phi[4,5]  R1744     -1.1506986618041992e+00
    phi[4,5]  R1745     1.6882311552762985e-02
    phi[4,5]  R1746     1.6482468694448471e-02
    phi[4,5]  R1747     -3.3365927636623383e-02
    phi[4,5]  R1748     -0.412221223115921
    phi[4,5]  R1749     -4.2553678154945374e-01
    phi[4,5]  R1750     1.1894398927688599e-01
    phi[4,5]  R1751     -5.1690834760665894e-01
    phi[4,5]  R1752     -5.5130845308303833e-01
    phi[4,5]  R1753     -6.7140018939971924e-01
    phi[4,5]  R1754     -1.5641337633132935e-01
    phi[4,5]  R1755     -2.1706800460815430e+00
    phi[4,5]  R1756     -2.0906336307525635e+00
    phi[4,5]  R1757     -1.9306709766387939e+00
    phi[4,5]  R1758     -1.4324448108673096e+00
    phi[4,5]  R1759     -2.1201727390289307e+00
    phi[4,5]  R1760     -2.0642352104187012e+00
    phi[4,5]  R1761     -2.2820627689361572e+00
    phi[4,5]  R1762     -1.9405242204666138e+00
    phi[4,5]  R1763     -2.2564084529876709e+00
    phi[4,5]  R1764     -2.0456309318542480e+00
    phi[4,5]  R1765     -1.2514673471450806e+00
    phi[4,5]  R1766     -0.719072699546814
    phi[4,5]  R1767     -1.1390861272811890e+00
    phi[4,5]  R1768     -1.4606775045394897e+00
    phi[4,5]  R1769     -1.9181317090988159e+00
    phi[4,5]  R1770     -2.9044425487518311e+00
    phi[4,5]  R1771     -1.2925461530685425e+00
    phi[4,5]  R1772     -2.9720606803894043e+00
    phi[4,5]  R1773     -2.3584203720092773e+00
    phi[4,5]  R1774     -2.0036325454711914e+00
    phi[5,4]  R36       -1
    phi[5,4]  R45       1
    phi[5,4]  R46       1
    phi[5,4]  R1775     -3.0999999046325684e+00
    phi[5,4]  R1776     -3.0999999046325684e+00
    phi[5,4]  R1777     -2.2400000095367432e+00
    phi[5,4]  R1778     -2.2400000095367432e+00
    phi[5,4]  R1779     -3.0999999046325684e+00
    phi[5,4]  R1780     -3.0999999046325684e+00
    phi[5,4]  R1781     -2.5699999332427979e+00
    phi[5,4]  R1782     -2.5699999332427979e+00
    phi[5,4]  R1783     -3.0999999046325684e+00
    phi[5,4]  R1784     -3.0999999046325684e+00
    phi[5,4]  R1785     -2.0899999141693115e+00
    phi[5,4]  R1786     -2.0899999141693115e+00
    phi[5,4]  R1787     -3.0999999046325684e+00
    phi[5,4]  R1788     -3.0999999046325684e+00
    phi[5,4]  R1789     -9.8686635494232178e-01
    phi[5,4]  R1790     -5.3069496154785156e-01
    phi[5,4]  R1791     -9.9010002613067627e-01
    phi[5,4]  R1792     4.8152637481689453e-01
    phi[5,4]  R1793     3.4690135717391968e-01
    phi[5,4]  R1794     -3.2946936786174774e-02
    phi[5,4]  R1795     -7.8122121095657349e-01
    phi[5,4]  R1796     4.1269031167030334e-01
    phi[5,4]  R1797     3.8940995931625366e-01
    phi[5,4]  R1798     -4.2851552367210388e-01
    phi[5,4]  R1799     -7.7629715204238892e-01
    phi[5,4]  R1800     -1.2039066553115845e+00
    phi[5,4]  R1801     -4.2492717504501343e-01
    phi[5,4]  R1802     -2.2598148882389069e-01
    phi[5,4]  R1803     -7.9831713438034058e-01
    phi[5,4]  R1804     -8.2729059457778931e-01
    phi[5,4]  R1805     -7.3914241790771484e-01
    phi[5,4]  R1806     -6.2965881824493408e-01
    phi[5,4]  R1807     -1.5382294654846191e+00
    phi[5,4]  R1808     -1.1506986618041992e+00
    phi[5,4]  R1809     1.6882311552762985e-02
    phi[5,4]  R1810     1.6482468694448471e-02
    phi[5,4]  R1811     -3.3365927636623383e-02
    phi[5,4]  R1812     -0.412221223115921
    phi[5,4]  R1813     -4.2553678154945374e-01
    phi[5,4]  R1814     1.1894398927688599e-01
    phi[5,4]  R1815     -5.1690834760665894e-01
    phi[5,4]  R1816     -5.5130845308303833e-01
    phi[5,4]  R1817     -6.7140018939971924e-01
    phi[5,4]  R1818     -1.5641337633132935e-01
    phi[5,4]  R1819     -2.1706800460815430e+00
    phi[5,4]  R1820     -2.0906336307525635e+00
    phi[5,4]  R1821     -1.9306709766387939e+00
    phi[5,4]  R1822     -1.4324448108673096e+00
    phi[5,4]  R1823     -2.1201727390289307e+00
    phi[5,4]  R1824     -2.0642352104187012e+00
    phi[5,4]  R1825     -2.2820627689361572e+00
    phi[5,4]  R1826     -1.9405242204666138e+00
    phi[5,4]  R1827     -2.2564084529876709e+00
    phi[5,4]  R1828     -2.0456309318542480e+00
    phi[5,4]  R1829     -1.2514673471450806e+00
    phi[5,4]  R1830     -0.719072699546814
    phi[5,4]  R1831     -1.1390861272811890e+00
    phi[5,4]  R1832     -1.4606775045394897e+00
    phi[5,4]  R1833     -1.9181317090988159e+00
    phi[5,4]  R1834     -2.9044425487518311e+00
    phi[5,4]  R1835     -1.2925461530685425e+00
    phi[5,4]  R1836     -2.9720606803894043e+00
    phi[5,4]  R1837     -2.3584203720092773e+00
    phi[5,4]  R1838     -2.0036325454711914e+00
    phi[5,4]  R1839     1.3253046274185181e+00
    phi[5,4]  R1840     3.9761909842491150e-01
    phi[5,4]  R1841     5.2724522352218628e-01
    phi[5,4]  R1842     -0.0084505844861269
    phi[5,4]  R1843     2.5511163473129272e-01
    phi[5,4]  R1844     7.4777173995971680e-01
    phi[5,4]  R1845     7.2634738683700562e-01
    phi[5,4]  R1846     9.9240273237228394e-01
    phi[5,4]  R1847     0.546148955821991
    phi[5,4]  R1848     5.5241447687149048e-01
    phi[5,4]  R1849     -1.1435811519622803e+00
    phi[5,4]  R1850     -1.5849117040634155e+00
    phi[5,4]  R1851     -1.6014122962951660e+00
    phi[5,4]  R1852     -1.9174997806549072e+00
    phi[5,4]  R1853     -5.8350926637649536e-01
    phi[5,4]  R1854     -2.0852053165435791e+00
    phi[5,4]  R1855     -1.0248399972915649e+00
    phi[5,4]  R1856     -1.4011521339416504e+00
    phi[5,4]  R1857     -2.0342090129852295e+00
    phi[5,4]  R1858     -2.6230406761169434e+00
    phi[5,4]  R1859     -1.5807336568832397e+00
    phi[5,4]  R1860     -1.7757858037948608e+00
    phi[5,4]  R1861     -2.0689892768859863e+00
    phi[5,4]  R1862     -1.9513186216354370e+00
    phi[5,4]  R1863     -2.2459280490875244e+00
    phi[5,4]  R1864     -7.1136569976806641e-01
    phi[5,4]  R1865     -1.8230395317077637e+00
    phi[5,4]  R1866     -1.8808318376541138e+00
    phi[5,4]  R1867     -8.9955651760101318e-01
    phi[5,4]  R1868     -1.7513449490070343e-01
    phi[5,4]  R1869     -1.1597578525543213e+00
    phi[5,4]  R1870     -1.7768043279647827e+00
    phi[5,4]  R1871     -8.8181060552597046e-01
    phi[5,4]  R1872     -9.9230170249938965e-01
    phi[5,4]  R1873     -5.7461428642272949e-01
    phi[5,4]  R1874     -1.5933365821838379e+00
    phi[5,4]  R1875     -1.5120373964309692e+00
    phi[5,4]  R1876     -0.900452196598053
    phi[5,4]  R1877     -1.3337709903717041e+00
    phi[5,4]  R1878     -9.3368732929229736e-01
    phi[5,4]  R1879     -2.25651216506958
    phi[5,4]  R1880     -1.9074938297271729e+00
    phi[5,4]  R1881     -1.2941697835922241e+00
    phi[5,4]  R1882     -1.8284888267517090e+00
    phi[5,4]  R1883     -1.1415930986404419e+00
    phi[5,4]  R1884     -1.7610708475112915e+00
    phi[5,4]  R1885     -3.4316429495811462e-01
    phi[5,4]  R1886     1.1219238489866257e-01
    phi[5,4]  R1887     -1.1211214959621429e-01
    phi[5,4]  R1888     -3.7155583500862122e-01
    phi[11,4]  R36       -1
    phi[11,4]  R38       1.2877988374356453e+00
    phi[11,4]  R39       -1.2366243616616113e+00
    phi[11,4]  R40       2.8414682753985034e+00
    phi[11,4]  R41       -1.3629511530561120e+00
    phi[11,4]  R42       1.7827265202085179e+00
    phi[11,4]  R43       0.887332484368538
    phi[11,4]  R44       1.1092358773438646e+00
    phi[11,4]  R99       1
    phi[11,4]  R1889     -4.3877987420682132e+00
    phi[11,4]  R1890     -1.8122010671969231e+00
    phi[11,4]  R1891     -1.0033756478751319e+00
    phi[11,4]  R1892     -3.4766243711983544e+00
    phi[11,4]  R1893     -5.9414681800310714e+00
    phi[11,4]  R1894     -2.5853162923406492e-01
    phi[11,4]  R1895     -1.2070487801866858e+00
    phi[11,4]  R1896     -3.93295108629891
    phi[11,4]  R1897     -4.8827264248410867e+00
    phi[11,4]  R1898     -1.3172733844240505e+00
    phi[11,4]  R1899     -2.9773323985378495e+00
    phi[11,4]  R1900     -1.2026674298007736e+00
    phi[11,4]  R1901     -4.2092357819764334e+00
    phi[11,4]  R1902     -1.9907640272887037e+00
    phi[11,4]  R1903     -2.2445015152102021e-01
    phi[11,4]  R1904     -2.2460168549791326e-01
    phi[11,4]  R1905     -2.2570470588876479e-01
    phi[11,4]  R1906     -2.3163743214694171e-01
    phi[11,4]  R1907     -2.5197841156759493e-01
    phi[11,4]  R1908     -2.5867333158927464e-01
    phi[11,4]  R1909     -2.6860696237582105e-01
    phi[11,4]  R1910     -2.7579368255296610e-01
    phi[11,4]  R1911     -2.8173853826347406e-01
    phi[11,4]  R1912     -2.8470611768377818e-01
    phi[11,4]  R1913     -5.2422964161885244e-01
    phi[11,4]  R1914     -5.6369550216069908e-01
    phi[11,4]  R1915     -5.7191414617725655e-01
    phi[11,4]  R1916     -5.7858418556302782e-01
    phi[11,4]  R1917     -5.8910192920583793e-01
    phi[11,4]  R1918     -6.1397004266659350e-01
    phi[11,4]  R1919     -0.621066650821016
    phi[11,4]  R1920     -6.5443476435787507e-01
    phi[11,4]  R1921     -6.5880943338607834e-01
    phi[11,4]  R1922     -6.7723976508849959e-01
    phi[11,4]  R1923     -3.5380607342727011e-01
    phi[11,4]  R1924     -4.2025466293881064e-01
    phi[11,4]  R1925     -4.6036255104972179e-01
    phi[11,4]  R1926     -5.0947045238302291e-01
    phi[11,4]  R1927     -5.5119068333669352e-01
    phi[11,4]  R1928     -5.9784167540458977e-01
    phi[11,4]  R1929     -6.2450736635522563e-01
    phi[11,4]  R1930     -0.65828113030331
    phi[11,4]  R1931     -9.0376925139465258e-01
    phi[11,4]  R1932     -1.7028806435073915e+00
    phi[11,4]  R1933     -3.6554835616480941e-01
    phi[11,4]  R1934     -3.6799843719038905e-01
    phi[11,4]  R1935     -3.7826830893764973e-01
    phi[11,4]  R1936     -3.8702176832180624e-01
    phi[11,4]  R1937     -4.6011170386687739e-01
    phi[11,4]  R1938     -4.6014911118787638e-01
    phi[11,4]  R1939     -4.7409146167210348e-01
    phi[11,4]  R1940     -4.8187180340812952e-01
    phi[11,4]  R1941     -5.8002716970936863e-01
    phi[11,4]  R1942     -6.1693070871409206e-01
    phi[11,4]  R1943     -3.1634576315598895e-01
    phi[11,4]  R1944     -3.3914181548107925e-01
    phi[11,4]  R1945     -3.7738150349896737e-01
    phi[11,4]  R1946     -4.3623280188026192e-01
    phi[11,4]  R1947     -4.4108639186773391e-01
    phi[11,4]  R1948     -4.7683481011420170e-01
    phi[11,4]  R1949     -1.2013230341107191e+00
    phi[11,4]  R1950     -1.2741371468557
    phi[11,4]  R1951     -1.30313943858595
    phi[11,4]  R1952     -1.3336532804561763e+00
    phi[5,6]  R45       1
    phi[5,6]  R46       1
    phi[5,6]  R54       -1
    phi[5,6]  R1953     -3.0999999046325684e+00
    phi[5,6]  R1954     -3.0999999046325684e+00
    phi[5,6]  R1955     -2.2400000095367432e+00
    phi[5,6]  R1956     -2.2400000095367432e+00
    phi[5,6]  R1957     -3.0999999046325684e+00
    phi[5,6]  R1958     -3.0999999046325684e+00
    phi[5,6]  R1959     -2.5699999332427979e+00
    phi[5,6]  R1960     -2.5699999332427979e+00
    phi[5,6]  R1961     -3.0999999046325684e+00
    phi[5,6]  R1962     -3.0999999046325684e+00
    phi[5,6]  R1963     -2.0899999141693115e+00
    phi[5,6]  R1964     -2.0899999141693115e+00
    phi[5,6]  R1965     -3.0999999046325684e+00
    phi[5,6]  R1966     -3.0999999046325684e+00
    phi[5,6]  R1967     -9.8686635494232178e-01
    phi[5,6]  R1968     -5.3069496154785156e-01
    phi[5,6]  R1969     -9.9010002613067627e-01
    phi[5,6]  R1970     4.8152637481689453e-01
    phi[5,6]  R1971     3.4690135717391968e-01
    phi[5,6]  R1972     -3.2946936786174774e-02
    phi[5,6]  R1973     -7.8122121095657349e-01
    phi[5,6]  R1974     4.1269031167030334e-01
    phi[5,6]  R1975     3.8940995931625366e-01
    phi[5,6]  R1976     -4.2851552367210388e-01
    phi[5,6]  R1977     -7.7629715204238892e-01
    phi[5,6]  R1978     -1.2039066553115845e+00
    phi[5,6]  R1979     -4.2492717504501343e-01
    phi[5,6]  R1980     -2.2598148882389069e-01
    phi[5,6]  R1981     -7.9831713438034058e-01
    phi[5,6]  R1982     -8.2729059457778931e-01
    phi[5,6]  R1983     -7.3914241790771484e-01
    phi[5,6]  R1984     -6.2965881824493408e-01
    phi[5,6]  R1985     -1.5382294654846191e+00
    phi[5,6]  R1986     -1.1506986618041992e+00
    phi[5,6]  R1987     1.6882311552762985e-02
    phi[5,6]  R1988     1.6482468694448471e-02
    phi[5,6]  R1989     -3.3365927636623383e-02
    phi[5,6]  R1990     -0.412221223115921
    phi[5,6]  R1991     -4.2553678154945374e-01
    phi[5,6]  R1992     1.1894398927688599e-01
    phi[5,6]  R1993     -5.1690834760665894e-01
    phi[5,6]  R1994     -5.5130845308303833e-01
    phi[5,6]  R1995     -6.7140018939971924e-01
    phi[5,6]  R1996     -1.5641337633132935e-01
    phi[5,6]  R1997     -2.1706800460815430e+00
    phi[5,6]  R1998     -2.0906336307525635e+00
    phi[5,6]  R1999     -1.9306709766387939e+00
    phi[5,6]  R2000     -1.4324448108673096e+00
    phi[5,6]  R2001     -2.1201727390289307e+00
    phi[5,6]  R2002     -2.0642352104187012e+00
    phi[5,6]  R2003     -2.2820627689361572e+00
    phi[5,6]  R2004     -1.9405242204666138e+00
    phi[5,6]  R2005     -2.2564084529876709e+00
    phi[5,6]  R2006     -2.0456309318542480e+00
    phi[5,6]  R2007     -1.2514673471450806e+00
    phi[5,6]  R2008     -0.719072699546814
    phi[5,6]  R2009     -1.1390861272811890e+00
    phi[5,6]  R2010     -1.4606775045394897e+00
    phi[5,6]  R2011     -1.9181317090988159e+00
    phi[5,6]  R2012     -2.9044425487518311e+00
    phi[5,6]  R2013     -1.2925461530685425e+00
    phi[5,6]  R2014     -2.9720606803894043e+00
    phi[5,6]  R2015     -2.3584203720092773e+00
    phi[5,6]  R2016     -2.0036325454711914e+00
    phi[5,6]  R2017     -2.5107380747795105e-01
    phi[5,6]  R2018     7.8692682087421417e-02
    phi[5,6]  R2019     8.2429057359695435e-01
    phi[5,6]  R2020     6.5496039390563965e-01
    phi[5,6]  R2021     -7.1435517072677612e-01
    phi[5,6]  R2022     0.382831335067749
    phi[5,6]  R2023     -5.0395943224430084e-02
    phi[5,6]  R2024     -3.1594058871269226e-01
    phi[5,6]  R2025     -4.4800704717636108e-01
    phi[5,6]  R2026     -5.1839929819107056e-01
    phi[5,6]  R2027     2.3605480790138245e-01
    phi[5,6]  R2028     1.8184982240200043e-01
    phi[5,6]  R2029     3.4960158169269562e-02
    phi[5,6]  R2030     -8.3682194352149963e-02
    phi[5,6]  R2031     -5.8781856298446655e-01
    phi[5,6]  R2032     -5.1351386308670044e-01
    phi[5,6]  R2033     -7.1346193552017212e-01
    phi[5,6]  R2034     -1.7517569065093994e+00
    phi[5,6]  R2035     -3.3006760478019714e-01
    phi[5,6]  R2036     -4.1332679986953735e-01
    phi[5,6]  R2037     -3.1534438133239746e+00
    phi[5,6]  R2038     4.7877541184425354e-01
    phi[5,6]  R2039     -2.51725697517395
    phi[5,6]  R2040     -1.4820883274078369e+00
    phi[5,6]  R2041     4.2407834529876709e-01
    phi[5,6]  R2042     4.7412845492362976e-01
    phi[5,6]  R2043     -5.2871920168399811e-02
    phi[5,6]  R2044     -2.6557227596640587e-02
    phi[5,6]  R2045     -1.3724645376205444e+00
    phi[5,6]  R2046     -2.6744249463081360e-01
    phi[6,5]  R45       -1
    phi[6,5]  R54       1
    phi[6,5]  R55       1
    phi[6,5]  R2047     -3.0999999046325684e+00
    phi[6,5]  R2048     -3.0999999046325684e+00
    phi[6,5]  R2049     -2.2400000095367432e+00
    phi[6,5]  R2050     -2.2400000095367432e+00
    phi[6,5]  R2051     -3.0999999046325684e+00
    phi[6,5]  R2052     -3.0999999046325684e+00
    phi[6,5]  R2053     -2.5699999332427979e+00
    phi[6,5]  R2054     -2.5699999332427979e+00
    phi[6,5]  R2055     -3.0999999046325684e+00
    phi[6,5]  R2056     -3.0999999046325684e+00
    phi[6,5]  R2057     -2.0899999141693115e+00
    phi[6,5]  R2058     -2.0899999141693115e+00
    phi[6,5]  R2059     -3.0999999046325684e+00
    phi[6,5]  R2060     -3.0999999046325684e+00
    phi[6,5]  R2061     -2.5107380747795105e-01
    phi[6,5]  R2062     7.8692682087421417e-02
    phi[6,5]  R2063     8.2429057359695435e-01
    phi[6,5]  R2064     6.5496039390563965e-01
    phi[6,5]  R2065     -7.1435517072677612e-01
    phi[6,5]  R2066     0.382831335067749
    phi[6,5]  R2067     -5.0395943224430084e-02
    phi[6,5]  R2068     -3.1594058871269226e-01
    phi[6,5]  R2069     -4.4800704717636108e-01
    phi[6,5]  R2070     -5.1839929819107056e-01
    phi[6,5]  R2071     2.3605480790138245e-01
    phi[6,5]  R2072     1.8184982240200043e-01
    phi[6,5]  R2073     3.4960158169269562e-02
    phi[6,5]  R2074     -8.3682194352149963e-02
    phi[6,5]  R2075     -5.8781856298446655e-01
    phi[6,5]  R2076     -5.1351386308670044e-01
    phi[6,5]  R2077     -7.1346193552017212e-01
    phi[6,5]  R2078     -1.7517569065093994e+00
    phi[6,5]  R2079     -3.3006760478019714e-01
    phi[6,5]  R2080     -4.1332679986953735e-01
    phi[6,5]  R2081     -3.1534438133239746e+00
    phi[6,5]  R2082     4.7877541184425354e-01
    phi[6,5]  R2083     -2.51725697517395
    phi[6,5]  R2084     -1.4820883274078369e+00
    phi[6,5]  R2085     4.2407834529876709e-01
    phi[6,5]  R2086     4.7412845492362976e-01
    phi[6,5]  R2087     -5.2871920168399811e-02
    phi[6,5]  R2088     -2.6557227596640587e-02
    phi[6,5]  R2089     -1.3724645376205444e+00
    phi[6,5]  R2090     -2.6744249463081360e-01
    phi[6,5]  R2091     -9.8686635494232178e-01
    phi[6,5]  R2092     -5.3069496154785156e-01
    phi[6,5]  R2093     -9.9010002613067627e-01
    phi[6,5]  R2094     4.8152637481689453e-01
    phi[6,5]  R2095     3.4690135717391968e-01
    phi[6,5]  R2096     -3.2946936786174774e-02
    phi[6,5]  R2097     -7.8122121095657349e-01
    phi[6,5]  R2098     4.1269031167030334e-01
    phi[6,5]  R2099     3.8940995931625366e-01
    phi[6,5]  R2100     -4.2851552367210388e-01
    phi[6,5]  R2101     -7.7629715204238892e-01
    phi[6,5]  R2102     -1.2039066553115845e+00
    phi[6,5]  R2103     -4.2492717504501343e-01
    phi[6,5]  R2104     -2.2598148882389069e-01
    phi[6,5]  R2105     -7.9831713438034058e-01
    phi[6,5]  R2106     -8.2729059457778931e-01
    phi[6,5]  R2107     -7.3914241790771484e-01
    phi[6,5]  R2108     -6.2965881824493408e-01
    phi[6,5]  R2109     -1.5382294654846191e+00
    phi[6,5]  R2110     -1.1506986618041992e+00
    phi[6,5]  R2111     1.6882311552762985e-02
    phi[6,5]  R2112     1.6482468694448471e-02
    phi[6,5]  R2113     -3.3365927636623383e-02
    phi[6,5]  R2114     -0.412221223115921
    phi[6,5]  R2115     -4.2553678154945374e-01
    phi[6,5]  R2116     1.1894398927688599e-01
    phi[6,5]  R2117     -5.1690834760665894e-01
    phi[6,5]  R2118     -5.5130845308303833e-01
    phi[6,5]  R2119     -6.7140018939971924e-01
    phi[6,5]  R2120     -1.5641337633132935e-01
    phi[6,5]  R2121     -2.1706800460815430e+00
    phi[6,5]  R2122     -2.0906336307525635e+00
    phi[6,5]  R2123     -1.9306709766387939e+00
    phi[6,5]  R2124     -1.4324448108673096e+00
    phi[6,5]  R2125     -2.1201727390289307e+00
    phi[6,5]  R2126     -2.0642352104187012e+00
    phi[6,5]  R2127     -2.2820627689361572e+00
    phi[6,5]  R2128     -1.9405242204666138e+00
    phi[6,5]  R2129     -2.2564084529876709e+00
    phi[6,5]  R2130     -2.0456309318542480e+00
    phi[6,5]  R2131     -1.2514673471450806e+00
    phi[6,5]  R2132     -0.719072699546814
    phi[6,5]  R2133     -1.1390861272811890e+00
    phi[6,5]  R2134     -1.4606775045394897e+00
    phi[6,5]  R2135     -1.9181317090988159e+00
    phi[6,5]  R2136     -2.9044425487518311e+00
    phi[6,5]  R2137     -1.2925461530685425e+00
    phi[6,5]  R2138     -2.9720606803894043e+00
    phi[6,5]  R2139     -2.3584203720092773e+00
    phi[6,5]  R2140     -2.0036325454711914e+00
    phi[6,7]  R54       1
    phi[6,7]  R55       1
    phi[6,7]  R63       -1
    phi[6,7]  R2141     -3.0999999046325684e+00
    phi[6,7]  R2142     -3.0999999046325684e+00
    phi[6,7]  R2143     -2.2400000095367432e+00
    phi[6,7]  R2144     -2.2400000095367432e+00
    phi[6,7]  R2145     -3.0999999046325684e+00
    phi[6,7]  R2146     -3.0999999046325684e+00
    phi[6,7]  R2147     -2.5699999332427979e+00
    phi[6,7]  R2148     -2.5699999332427979e+00
    phi[6,7]  R2149     -3.0999999046325684e+00
    phi[6,7]  R2150     -3.0999999046325684e+00
    phi[6,7]  R2151     -2.0899999141693115e+00
    phi[6,7]  R2152     -2.0899999141693115e+00
    phi[6,7]  R2153     -3.0999999046325684e+00
    phi[6,7]  R2154     -3.0999999046325684e+00
    phi[6,7]  R2155     -2.5107380747795105e-01
    phi[6,7]  R2156     7.8692682087421417e-02
    phi[6,7]  R2157     8.2429057359695435e-01
    phi[6,7]  R2158     6.5496039390563965e-01
    phi[6,7]  R2159     -7.1435517072677612e-01
    phi[6,7]  R2160     0.382831335067749
    phi[6,7]  R2161     -5.0395943224430084e-02
    phi[6,7]  R2162     -3.1594058871269226e-01
    phi[6,7]  R2163     -4.4800704717636108e-01
    phi[6,7]  R2164     -5.1839929819107056e-01
    phi[6,7]  R2165     2.3605480790138245e-01
    phi[6,7]  R2166     1.8184982240200043e-01
    phi[6,7]  R2167     3.4960158169269562e-02
    phi[6,7]  R2168     -8.3682194352149963e-02
    phi[6,7]  R2169     -5.8781856298446655e-01
    phi[6,7]  R2170     -5.1351386308670044e-01
    phi[6,7]  R2171     -7.1346193552017212e-01
    phi[6,7]  R2172     -1.7517569065093994e+00
    phi[6,7]  R2173     -3.3006760478019714e-01
    phi[6,7]  R2174     -4.1332679986953735e-01
    phi[6,7]  R2175     -3.1534438133239746e+00
    phi[6,7]  R2176     4.7877541184425354e-01
    phi[6,7]  R2177     -2.51725697517395
    phi[6,7]  R2178     -1.4820883274078369e+00
    phi[6,7]  R2179     4.2407834529876709e-01
    phi[6,7]  R2180     4.7412845492362976e-01
    phi[6,7]  R2181     -5.2871920168399811e-02
    phi[6,7]  R2182     -2.6557227596640587e-02
    phi[6,7]  R2183     -1.3724645376205444e+00
    phi[6,7]  R2184     -2.6744249463081360e-01
    phi[6,7]  R2185     -1.4853662252426147e+00
    phi[6,7]  R2186     1.6534509658813477e+00
    phi[6,7]  R2187     2.6570501327514648e+00
    phi[6,7]  R2188     2.4139111042022705e+00
    phi[6,7]  R2189     2.2593832015991211e+00
    phi[6,7]  R2190     -4.4596129655838013e-01
    phi[6,7]  R2191     -7.4171268939971924e-01
    phi[6,7]  R2192     -1.1056965589523315e+00
    phi[6,7]  R2193     -1.4087408781051636e+00
    phi[6,7]  R2194     2.2821922600269318e-01
    phi[6,7]  R2195     -2.4127058982849121e+00
    phi[6,7]  R2196     -2.5301005840301514e+00
    phi[6,7]  R2197     -1.0717992782592773e+00
    phi[6,7]  R2198     -1.0688967704772949e+00
    phi[6,7]  R2199     -1.1976864337921143e+00
    phi[6,7]  R2200     -1.83369779586792
    phi[6,7]  R2201     -2.8576216697692871e+00
    phi[6,7]  R2202     -2.7126562595367432e+00
    phi[6,7]  R2203     -1.8530180454254150e+00
    phi[6,7]  R2204     -2.1962954998016357e+00
    phi[6,7]  R2205     -8.9216637611389160e-01
    phi[6,7]  R2206     -1.2378330230712891e+00
    phi[6,7]  R2207     2.9268577694892883e-01
    phi[6,7]  R2208     -5.1070320606231689e-01
    phi[6,7]  R2209     -3.1480839848518372e-01
    phi[6,7]  R2210     3.5252118110656738e-01
    phi[6,7]  R2211     0.777516782283783
    phi[6,7]  R2212     1.2123949527740479e+00
    phi[6,7]  R2213     -1.3434786796569824e+00
    phi[6,7]  R2214     1.2827174663543701e+00
    phi[6,7]  R2215     -6.8459969758987427e-01
    phi[6,7]  R2216     2.3528122901916504e+00
    phi[6,7]  R2217     -9.8032486438751221e-01
    phi[6,7]  R2218     6.8936920166015625e-01
    phi[6,7]  R2219     -3.7237949669361115e-02
    phi[6,7]  R2220     -3.9116922020912170e-01
    phi[6,7]  R2221     5.0104331970214844e-01
    phi[6,7]  R2222     -3.6856824159622192e-01
    phi[6,7]  R2223     -4.3512535095214844e-01
    phi[7,6]  R54       -1
    phi[7,6]  R63       1
    phi[7,6]  R64       1
    phi[7,6]  R2224     -3.0999999046325684e+00
    phi[7,6]  R2225     -3.0999999046325684e+00
    phi[7,6]  R2226     -2.2400000095367432e+00
    phi[7,6]  R2227     -2.2400000095367432e+00
    phi[7,6]  R2228     -3.0999999046325684e+00
    phi[7,6]  R2229     -3.0999999046325684e+00
    phi[7,6]  R2230     -2.5699999332427979e+00
    phi[7,6]  R2231     -2.5699999332427979e+00
    phi[7,6]  R2232     -3.0999999046325684e+00
    phi[7,6]  R2233     -3.0999999046325684e+00
    phi[7,6]  R2234     -2.0899999141693115e+00
    phi[7,6]  R2235     -2.0899999141693115e+00
    phi[7,6]  R2236     -3.0999999046325684e+00
    phi[7,6]  R2237     -3.0999999046325684e+00
    phi[7,6]  R2238     -1.4853662252426147e+00
    phi[7,6]  R2239     1.6534509658813477e+00
    phi[7,6]  R2240     2.6570501327514648e+00
    phi[7,6]  R2241     2.4139111042022705e+00
    phi[7,6]  R2242     2.2593832015991211e+00
    phi[7,6]  R2243     -4.4596129655838013e-01
    phi[7,6]  R2244     -7.4171268939971924e-01
    phi[7,6]  R2245     -1.1056965589523315e+00
    phi[7,6]  R2246     -1.4087408781051636e+00
    phi[7,6]  R2247     2.2821922600269318e-01
    phi[7,6]  R2248     -2.4127058982849121e+00
    phi[7,6]  R2249     -2.5301005840301514e+00
    phi[7,6]  R2250     -1.0717992782592773e+00
    phi[7,6]  R2251     -1.0688967704772949e+00
    phi[7,6]  R2252     -1.1976864337921143e+00
    phi[7,6]  R2253     -1.83369779586792
    phi[7,6]  R2254     -2.8576216697692871e+00
    phi[7,6]  R2255     -2.7126562595367432e+00
    phi[7,6]  R2256     -1.8530180454254150e+00
    phi[7,6]  R2257     -2.1962954998016357e+00
    phi[7,6]  R2258     -8.9216637611389160e-01
    phi[7,6]  R2259     -1.2378330230712891e+00
    phi[7,6]  R2260     2.9268577694892883e-01
    phi[7,6]  R2261     -5.1070320606231689e-01
    phi[7,6]  R2262     -3.1480839848518372e-01
    phi[7,6]  R2263     3.5252118110656738e-01
    phi[7,6]  R2264     0.777516782283783
    phi[7,6]  R2265     1.2123949527740479e+00
    phi[7,6]  R2266     -1.3434786796569824e+00
    phi[7,6]  R2267     1.2827174663543701e+00
    phi[7,6]  R2268     -6.8459969758987427e-01
    phi[7,6]  R2269     2.3528122901916504e+00
    phi[7,6]  R2270     -9.8032486438751221e-01
    phi[7,6]  R2271     6.8936920166015625e-01
    phi[7,6]  R2272     -3.7237949669361115e-02
    phi[7,6]  R2273     -3.9116922020912170e-01
    phi[7,6]  R2274     5.0104331970214844e-01
    phi[7,6]  R2275     -3.6856824159622192e-01
    phi[7,6]  R2276     -4.3512535095214844e-01
    phi[7,6]  R2277     -2.5107380747795105e-01
    phi[7,6]  R2278     7.8692682087421417e-02
    phi[7,6]  R2279     8.2429057359695435e-01
    phi[7,6]  R2280     6.5496039390563965e-01
    phi[7,6]  R2281     -7.1435517072677612e-01
    phi[7,6]  R2282     0.382831335067749
    phi[7,6]  R2283     -5.0395943224430084e-02
    phi[7,6]  R2284     -3.1594058871269226e-01
    phi[7,6]  R2285     -4.4800704717636108e-01
    phi[7,6]  R2286     -5.1839929819107056e-01
    phi[7,6]  R2287     2.3605480790138245e-01
    phi[7,6]  R2288     1.8184982240200043e-01
    phi[7,6]  R2289     3.4960158169269562e-02
    phi[7,6]  R2290     -8.3682194352149963e-02
    phi[7,6]  R2291     -5.8781856298446655e-01
    phi[7,6]  R2292     -5.1351386308670044e-01
    phi[7,6]  R2293     -7.1346193552017212e-01
    phi[7,6]  R2294     -1.7517569065093994e+00
    phi[7,6]  R2295     -3.3006760478019714e-01
    phi[7,6]  R2296     -4.1332679986953735e-01
    phi[7,6]  R2297     -3.1534438133239746e+00
    phi[7,6]  R2298     4.7877541184425354e-01
    phi[7,6]  R2299     -2.51725697517395
    phi[7,6]  R2300     -1.4820883274078369e+00
    phi[7,6]  R2301     4.2407834529876709e-01
    phi[7,6]  R2302     4.7412845492362976e-01
    phi[7,6]  R2303     -5.2871920168399811e-02
    phi[7,6]  R2304     -2.6557227596640587e-02
    phi[7,6]  R2305     -1.3724645376205444e+00
    phi[7,6]  R2306     -2.6744249463081360e-01
    phi[7,8]  R63       1
    phi[7,8]  R64       1
    phi[7,8]  R72       -1
    phi[7,8]  R2307     -3.0999999046325684e+00
    phi[7,8]  R2308     -3.0999999046325684e+00
    phi[7,8]  R2309     -2.2400000095367432e+00
    phi[7,8]  R2310     -2.2400000095367432e+00
    phi[7,8]  R2311     -3.0999999046325684e+00
    phi[7,8]  R2312     -3.0999999046325684e+00
    phi[7,8]  R2313     -2.5699999332427979e+00
    phi[7,8]  R2314     -2.5699999332427979e+00
    phi[7,8]  R2315     -3.0999999046325684e+00
    phi[7,8]  R2316     -3.0999999046325684e+00
    phi[7,8]  R2317     -2.0899999141693115e+00
    phi[7,8]  R2318     -2.0899999141693115e+00
    phi[7,8]  R2319     -3.0999999046325684e+00
    phi[7,8]  R2320     -3.0999999046325684e+00
    phi[7,8]  R2321     -1.4853662252426147e+00
    phi[7,8]  R2322     1.6534509658813477e+00
    phi[7,8]  R2323     2.6570501327514648e+00
    phi[7,8]  R2324     2.4139111042022705e+00
    phi[7,8]  R2325     2.2593832015991211e+00
    phi[7,8]  R2326     -4.4596129655838013e-01
    phi[7,8]  R2327     -7.4171268939971924e-01
    phi[7,8]  R2328     -1.1056965589523315e+00
    phi[7,8]  R2329     -1.4087408781051636e+00
    phi[7,8]  R2330     2.2821922600269318e-01
    phi[7,8]  R2331     -2.4127058982849121e+00
    phi[7,8]  R2332     -2.5301005840301514e+00
    phi[7,8]  R2333     -1.0717992782592773e+00
    phi[7,8]  R2334     -1.0688967704772949e+00
    phi[7,8]  R2335     -1.1976864337921143e+00
    phi[7,8]  R2336     -1.83369779586792
    phi[7,8]  R2337     -2.8576216697692871e+00
    phi[7,8]  R2338     -2.7126562595367432e+00
    phi[7,8]  R2339     -1.8530180454254150e+00
    phi[7,8]  R2340     -2.1962954998016357e+00
    phi[7,8]  R2341     -8.9216637611389160e-01
    phi[7,8]  R2342     -1.2378330230712891e+00
    phi[7,8]  R2343     2.9268577694892883e-01
    phi[7,8]  R2344     -5.1070320606231689e-01
    phi[7,8]  R2345     -3.1480839848518372e-01
    phi[7,8]  R2346     3.5252118110656738e-01
    phi[7,8]  R2347     0.777516782283783
    phi[7,8]  R2348     1.2123949527740479e+00
    phi[7,8]  R2349     -1.3434786796569824e+00
    phi[7,8]  R2350     1.2827174663543701e+00
    phi[7,8]  R2351     -6.8459969758987427e-01
    phi[7,8]  R2352     2.3528122901916504e+00
    phi[7,8]  R2353     -9.8032486438751221e-01
    phi[7,8]  R2354     6.8936920166015625e-01
    phi[7,8]  R2355     -3.7237949669361115e-02
    phi[7,8]  R2356     -3.9116922020912170e-01
    phi[7,8]  R2357     5.0104331970214844e-01
    phi[7,8]  R2358     -3.6856824159622192e-01
    phi[7,8]  R2359     -4.3512535095214844e-01
    phi[7,8]  R2360     2.5066015124320984e-01
    phi[7,8]  R2361     1.3978984951972961e-01
    phi[7,8]  R2362     1.2431781291961670e+00
    phi[7,8]  R2363     1.1731899976730347e+00
    phi[7,8]  R2364     -5.2747726440429688e-01
    phi[7,8]  R2365     1.5036419630050659e+00
    phi[7,8]  R2366     2.8522339463233948e-01
    phi[7,8]  R2367     1.5807143449783325e+00
    phi[7,8]  R2368     2.5216004848480225e+00
    phi[7,8]  R2369     1.6859062910079956e+00
    phi[7,8]  R2370     -3.6506819725036621e+00
    phi[7,8]  R2371     -2.4281208515167236e+00
    phi[7,8]  R2372     7.4852830171585083e-01
    phi[7,8]  R2373     9.6715521812438965e-01
    phi[7,8]  R2374     -3.2735447883605957e+00
    phi[7,8]  R2375     -2.8394782543182373e-01
    phi[7,8]  R2376     -2.4272768497467041e+00
    phi[7,8]  R2377     -2.4388277530670166e+00
    phi[7,8]  R2378     -2.0191102027893066e+00
    phi[7,8]  R2379     -1.7299532890319824e+00
    phi[7,8]  R2380     -2.6376559734344482e+00
    phi[7,8]  R2381     -1.1543844938278198e+00
    phi[7,8]  R2382     -2.3202095031738281e+00
    phi[7,8]  R2383     -1.0307776927947998e+00
    phi[7,8]  R2384     -1.6586560010910034e+00
    phi[7,8]  R2385     -9.3515825271606445e-01
    phi[7,8]  R2386     6.1683833599090576e-02
    phi[7,8]  R2387     7.2133266925811768e-01
    phi[7,8]  R2388     8.0181114375591278e-02
    phi[7,8]  R2389     2.1829934418201447e-01
    phi[7,8]  R2390     1.7059228420257568e+00
    phi[7,8]  R2391     -1.8701533079147339e+00
    phi[7,8]  R2392     2.3010098934173584e+00
    phi[7,8]  R2393     4.3423545360565186e-01
    phi[7,8]  R2394     -2.8814435005187988e+00
    phi[7,8]  R2395     1.8875710964202881e+00
    phi[7,8]  R2396     -1.1382663249969482e+00
    phi[7,8]  R2397     -1.4407877922058105e+00
    phi[7,8]  R2398     -1.1249930858612061e+00
    phi[7,8]  R2399     2.4859089851379395e+00
    phi[7,8]  R2400     7.5005650520324707e-02
    phi[7,8]  R2401     -2.4521486759185791e+00
    phi[7,8]  R2402     1.4906034469604492e+00
    phi[7,8]  R2403     9.5230972766876221e-01
    phi[7,8]  R2404     1.9197340309619904e-01
    phi[7,8]  R2405     1.0262948274612427e+00
    phi[7,8]  R2406     2.7885069847106934e+00
    phi[7,8]  R2407     4.6533304452896118e-01
    phi[7,8]  R2408     4.2471304535865784e-01
    phi[7,8]  R2409     1.6023153066635132e-01
    phi[8,7]  R63       -1
    phi[8,7]  R72       1
    phi[8,7]  R73       1
    phi[8,7]  R2410     -3.0999999046325684e+00
    phi[8,7]  R2411     -3.0999999046325684e+00
    phi[8,7]  R2412     -2.2400000095367432e+00
    phi[8,7]  R2413     -2.2400000095367432e+00
    phi[8,7]  R2414     -3.0999999046325684e+00
    phi[8,7]  R2415     -3.0999999046325684e+00
    phi[8,7]  R2416     -2.5699999332427979e+00
    phi[8,7]  R2417     -2.5699999332427979e+00
    phi[8,7]  R2418     -3.0999999046325684e+00
    phi[8,7]  R2419     -3.0999999046325684e+00
    phi[8,7]  R2420     -2.0899999141693115e+00
    phi[8,7]  R2421     -2.0899999141693115e+00
    phi[8,7]  R2422     -3.0999999046325684e+00
    phi[8,7]  R2423     -3.0999999046325684e+00
    phi[8,7]  R2424     2.5066015124320984e-01
    phi[8,7]  R2425     1.3978984951972961e-01
    phi[8,7]  R2426     1.2431781291961670e+00
    phi[8,7]  R2427     1.1731899976730347e+00
    phi[8,7]  R2428     -5.2747726440429688e-01
    phi[8,7]  R2429     1.5036419630050659e+00
    phi[8,7]  R2430     2.8522339463233948e-01
    phi[8,7]  R2431     1.5807143449783325e+00
    phi[8,7]  R2432     2.5216004848480225e+00
    phi[8,7]  R2433     1.6859062910079956e+00
    phi[8,7]  R2434     -3.6506819725036621e+00
    phi[8,7]  R2435     -2.4281208515167236e+00
    phi[8,7]  R2436     7.4852830171585083e-01
    phi[8,7]  R2437     9.6715521812438965e-01
    phi[8,7]  R2438     -3.2735447883605957e+00
    phi[8,7]  R2439     -2.8394782543182373e-01
    phi[8,7]  R2440     -2.4272768497467041e+00
    phi[8,7]  R2441     -2.4388277530670166e+00
    phi[8,7]  R2442     -2.0191102027893066e+00
    phi[8,7]  R2443     -1.7299532890319824e+00
    phi[8,7]  R2444     -2.6376559734344482e+00
    phi[8,7]  R2445     -1.1543844938278198e+00
    phi[8,7]  R2446     -2.3202095031738281e+00
    phi[8,7]  R2447     -1.0307776927947998e+00
    phi[8,7]  R2448     -1.6586560010910034e+00
    phi[8,7]  R2449     -9.3515825271606445e-01
    phi[8,7]  R2450     6.1683833599090576e-02
    phi[8,7]  R2451     7.2133266925811768e-01
    phi[8,7]  R2452     8.0181114375591278e-02
    phi[8,7]  R2453     2.1829934418201447e-01
    phi[8,7]  R2454     1.7059228420257568e+00
    phi[8,7]  R2455     -1.8701533079147339e+00
    phi[8,7]  R2456     2.3010098934173584e+00
    phi[8,7]  R2457     4.3423545360565186e-01
    phi[8,7]  R2458     -2.8814435005187988e+00
    phi[8,7]  R2459     1.8875710964202881e+00
    phi[8,7]  R2460     -1.1382663249969482e+00
    phi[8,7]  R2461     -1.4407877922058105e+00
    phi[8,7]  R2462     -1.1249930858612061e+00
    phi[8,7]  R2463     2.4859089851379395e+00
    phi[8,7]  R2464     7.5005650520324707e-02
    phi[8,7]  R2465     -2.4521486759185791e+00
    phi[8,7]  R2466     1.4906034469604492e+00
    phi[8,7]  R2467     9.5230972766876221e-01
    phi[8,7]  R2468     1.9197340309619904e-01
    phi[8,7]  R2469     1.0262948274612427e+00
    phi[8,7]  R2470     2.7885069847106934e+00
    phi[8,7]  R2471     4.6533304452896118e-01
    phi[8,7]  R2472     4.2471304535865784e-01
    phi[8,7]  R2473     1.6023153066635132e-01
    phi[8,7]  R2474     -1.4853662252426147e+00
    phi[8,7]  R2475     1.6534509658813477e+00
    phi[8,7]  R2476     2.6570501327514648e+00
    phi[8,7]  R2477     2.4139111042022705e+00
    phi[8,7]  R2478     2.2593832015991211e+00
    phi[8,7]  R2479     -4.4596129655838013e-01
    phi[8,7]  R2480     -7.4171268939971924e-01
    phi[8,7]  R2481     -1.1056965589523315e+00
    phi[8,7]  R2482     -1.4087408781051636e+00
    phi[8,7]  R2483     2.2821922600269318e-01
    phi[8,7]  R2484     -2.4127058982849121e+00
    phi[8,7]  R2485     -2.5301005840301514e+00
    phi[8,7]  R2486     -1.0717992782592773e+00
    phi[8,7]  R2487     -1.0688967704772949e+00
    phi[8,7]  R2488     -1.1976864337921143e+00
    phi[8,7]  R2489     -1.83369779586792
    phi[8,7]  R2490     -2.8576216697692871e+00
    phi[8,7]  R2491     -2.7126562595367432e+00
    phi[8,7]  R2492     -1.8530180454254150e+00
    phi[8,7]  R2493     -2.1962954998016357e+00
    phi[8,7]  R2494     -8.9216637611389160e-01
    phi[8,7]  R2495     -1.2378330230712891e+00
    phi[8,7]  R2496     2.9268577694892883e-01
    phi[8,7]  R2497     -5.1070320606231689e-01
    phi[8,7]  R2498     -3.1480839848518372e-01
    phi[8,7]  R2499     3.5252118110656738e-01
    phi[8,7]  R2500     0.777516782283783
    phi[8,7]  R2501     1.2123949527740479e+00
    phi[8,7]  R2502     -1.3434786796569824e+00
    phi[8,7]  R2503     1.2827174663543701e+00
    phi[8,7]  R2504     -6.8459969758987427e-01
    phi[8,7]  R2505     2.3528122901916504e+00
    phi[8,7]  R2506     -9.8032486438751221e-01
    phi[8,7]  R2507     6.8936920166015625e-01
    phi[8,7]  R2508     -3.7237949669361115e-02
    phi[8,7]  R2509     -3.9116922020912170e-01
    phi[8,7]  R2510     5.0104331970214844e-01
    phi[8,7]  R2511     -3.6856824159622192e-01
    phi[8,7]  R2512     -4.3512535095214844e-01
    phi[8,9]  R72       1
    phi[8,9]  R73       1
    phi[8,9]  R81       -1
    phi[8,9]  R2513     -3.0999999046325684e+00
    phi[8,9]  R2514     -3.0999999046325684e+00
    phi[8,9]  R2515     -2.2400000095367432e+00
    phi[8,9]  R2516     -2.2400000095367432e+00
    phi[8,9]  R2517     -3.0999999046325684e+00
    phi[8,9]  R2518     -3.0999999046325684e+00
    phi[8,9]  R2519     -2.5699999332427979e+00
    phi[8,9]  R2520     -2.5699999332427979e+00
    phi[8,9]  R2521     -3.0999999046325684e+00
    phi[8,9]  R2522     -3.0999999046325684e+00
    phi[8,9]  R2523     -2.0899999141693115e+00
    phi[8,9]  R2524     -2.0899999141693115e+00
    phi[8,9]  R2525     -3.0999999046325684e+00
    phi[8,9]  R2526     -3.0999999046325684e+00
    phi[8,9]  R2527     2.5066015124320984e-01
    phi[8,9]  R2528     1.3978984951972961e-01
    phi[8,9]  R2529     1.2431781291961670e+00
    phi[8,9]  R2530     1.1731899976730347e+00
    phi[8,9]  R2531     -5.2747726440429688e-01
    phi[8,9]  R2532     1.5036419630050659e+00
    phi[8,9]  R2533     2.8522339463233948e-01
    phi[8,9]  R2534     1.5807143449783325e+00
    phi[8,9]  R2535     2.5216004848480225e+00
    phi[8,9]  R2536     1.6859062910079956e+00
    phi[8,9]  R2537     -3.6506819725036621e+00
    phi[8,9]  R2538     -2.4281208515167236e+00
    phi[8,9]  R2539     7.4852830171585083e-01
    phi[8,9]  R2540     9.6715521812438965e-01
    phi[8,9]  R2541     -3.2735447883605957e+00
    phi[8,9]  R2542     -2.8394782543182373e-01
    phi[8,9]  R2543     -2.4272768497467041e+00
    phi[8,9]  R2544     -2.4388277530670166e+00
    phi[8,9]  R2545     -2.0191102027893066e+00
    phi[8,9]  R2546     -1.7299532890319824e+00
    phi[8,9]  R2547     -2.6376559734344482e+00
    phi[8,9]  R2548     -1.1543844938278198e+00
    phi[8,9]  R2549     -2.3202095031738281e+00
    phi[8,9]  R2550     -1.0307776927947998e+00
    phi[8,9]  R2551     -1.6586560010910034e+00
    phi[8,9]  R2552     -9.3515825271606445e-01
    phi[8,9]  R2553     6.1683833599090576e-02
    phi[8,9]  R2554     7.2133266925811768e-01
    phi[8,9]  R2555     8.0181114375591278e-02
    phi[8,9]  R2556     2.1829934418201447e-01
    phi[8,9]  R2557     1.7059228420257568e+00
    phi[8,9]  R2558     -1.8701533079147339e+00
    phi[8,9]  R2559     2.3010098934173584e+00
    phi[8,9]  R2560     4.3423545360565186e-01
    phi[8,9]  R2561     -2.8814435005187988e+00
    phi[8,9]  R2562     1.8875710964202881e+00
    phi[8,9]  R2563     -1.1382663249969482e+00
    phi[8,9]  R2564     -1.4407877922058105e+00
    phi[8,9]  R2565     -1.1249930858612061e+00
    phi[8,9]  R2566     2.4859089851379395e+00
    phi[8,9]  R2567     7.5005650520324707e-02
    phi[8,9]  R2568     -2.4521486759185791e+00
    phi[8,9]  R2569     1.4906034469604492e+00
    phi[8,9]  R2570     9.5230972766876221e-01
    phi[8,9]  R2571     1.9197340309619904e-01
    phi[8,9]  R2572     1.0262948274612427e+00
    phi[8,9]  R2573     2.7885069847106934e+00
    phi[8,9]  R2574     4.6533304452896118e-01
    phi[8,9]  R2575     4.2471304535865784e-01
    phi[8,9]  R2576     1.6023153066635132e-01
    phi[8,9]  R2577     1.0027934312820435e+00
    phi[8,9]  R2578     8.3381354808807373e-01
    phi[8,9]  R2579     1.7219812870025635e+00
    phi[8,9]  R2580     -1.0042651891708374e+00
    phi[8,9]  R2581     1.6229294538497925e+00
    phi[8,9]  R2582     3.5058948397636414e-01
    phi[8,9]  R2583     2.5720973014831543e+00
    phi[8,9]  R2584     2.4920377731323242e+00
    phi[8,9]  R2585     1.7450097799301147e+00
    phi[8,9]  R2586     2.7962107658386230e+00
    phi[8,9]  R2587     -1.9602245092391968e+00
    phi[8,9]  R2588     -3.1749649047851562e+00
    phi[8,9]  R2589     -1.6601054668426514e+00
    phi[8,9]  R2590     -3.0586068630218506e+00
    phi[8,9]  R2591     -2.7548179626464844e+00
    phi[8,9]  R2592     -1.9556419849395752e+00
    phi[8,9]  R2593     -1.5780589580535889e+00
    phi[8,9]  R2594     -2.9529213905334473e+00
    phi[8,9]  R2595     -2.6807627677917480e+00
    phi[8,9]  R2596     -2.9962100982666016e+00
    phi[8,9]  R2597     -2.4738800525665283e+00
    phi[8,9]  R2598     -2.5845723152160645e+00
    phi[8,9]  R2599     -3.2534070014953613e+00
    phi[8,9]  R2600     -3.2127389907836914e+00
    phi[8,9]  R2601     -2.4754526615142822e+00
    phi[8,9]  R2602     -3.0101046562194824e+00
    phi[8,9]  R2603     -2.6814196109771729e+00
    phi[8,9]  R2604     -2.6337335109710693e+00
    phi[8,9]  R2605     -1.9390234947204590e+00
    phi[8,9]  R2606     -2.6822500228881836e+00
    phi[8,9]  R2607     1.3754380941390991e+00
    phi[8,9]  R2608     -1.4931761026382446e+00
    phi[8,9]  R2609     -3.0424292087554932e+00
    phi[8,9]  R2610     -2.8672156333923340e+00
    phi[8,9]  R2611     -1.6808737516403198e+00
    phi[8,9]  R2612     -2.1011133193969727e+00
    phi[8,9]  R2613     -2.4073097705841064e+00
    phi[8,9]  R2614     -8.6528354883193970e-01
    phi[8,9]  R2615     -1.4549417495727539e+00
    phi[9,8]  R72       -1
    phi[9,8]  R81       1
    phi[9,8]  R82       1
    phi[9,8]  R2616     -3.0999999046325684e+00
    phi[9,8]  R2617     -3.0999999046325684e+00
    phi[9,8]  R2618     -2.2400000095367432e+00
    phi[9,8]  R2619     -2.2400000095367432e+00
    phi[9,8]  R2620     -3.0999999046325684e+00
    phi[9,8]  R2621     -3.0999999046325684e+00
    phi[9,8]  R2622     -2.5699999332427979e+00
    phi[9,8]  R2623     -2.5699999332427979e+00
    phi[9,8]  R2624     -3.0999999046325684e+00
    phi[9,8]  R2625     -3.0999999046325684e+00
    phi[9,8]  R2626     -2.0899999141693115e+00
    phi[9,8]  R2627     -2.0899999141693115e+00
    phi[9,8]  R2628     -3.0999999046325684e+00
    phi[9,8]  R2629     -3.0999999046325684e+00
    phi[9,8]  R2630     1.0027934312820435e+00
    phi[9,8]  R2631     8.3381354808807373e-01
    phi[9,8]  R2632     1.7219812870025635e+00
    phi[9,8]  R2633     -1.0042651891708374e+00
    phi[9,8]  R2634     1.6229294538497925e+00
    phi[9,8]  R2635     3.5058948397636414e-01
    phi[9,8]  R2636     2.5720973014831543e+00
    phi[9,8]  R2637     2.4920377731323242e+00
    phi[9,8]  R2638     1.7450097799301147e+00
    phi[9,8]  R2639     2.7962107658386230e+00
    phi[9,8]  R2640     -1.9602245092391968e+00
    phi[9,8]  R2641     -3.1749649047851562e+00
    phi[9,8]  R2642     -1.6601054668426514e+00
    phi[9,8]  R2643     -3.0586068630218506e+00
    phi[9,8]  R2644     -2.7548179626464844e+00
    phi[9,8]  R2645     -1.9556419849395752e+00
    phi[9,8]  R2646     -1.5780589580535889e+00
    phi[9,8]  R2647     -2.9529213905334473e+00
    phi[9,8]  R2648     -2.6807627677917480e+00
    phi[9,8]  R2649     -2.9962100982666016e+00
    phi[9,8]  R2650     -2.4738800525665283e+00
    phi[9,8]  R2651     -2.5845723152160645e+00
    phi[9,8]  R2652     -3.2534070014953613e+00
    phi[9,8]  R2653     -3.2127389907836914e+00
    phi[9,8]  R2654     -2.4754526615142822e+00
    phi[9,8]  R2655     -3.0101046562194824e+00
    phi[9,8]  R2656     -2.6814196109771729e+00
    phi[9,8]  R2657     -2.6337335109710693e+00
    phi[9,8]  R2658     -1.9390234947204590e+00
    phi[9,8]  R2659     -2.6822500228881836e+00
    phi[9,8]  R2660     1.3754380941390991e+00
    phi[9,8]  R2661     -1.4931761026382446e+00
    phi[9,8]  R2662     -3.0424292087554932e+00
    phi[9,8]  R2663     -2.8672156333923340e+00
    phi[9,8]  R2664     -1.6808737516403198e+00
    phi[9,8]  R2665     -2.1011133193969727e+00
    phi[9,8]  R2666     -2.4073097705841064e+00
    phi[9,8]  R2667     -8.6528354883193970e-01
    phi[9,8]  R2668     -1.4549417495727539e+00
    phi[9,8]  R2669     2.5066015124320984e-01
    phi[9,8]  R2670     1.3978984951972961e-01
    phi[9,8]  R2671     1.2431781291961670e+00
    phi[9,8]  R2672     1.1731899976730347e+00
    phi[9,8]  R2673     -5.2747726440429688e-01
    phi[9,8]  R2674     1.5036419630050659e+00
    phi[9,8]  R2675     2.8522339463233948e-01
    phi[9,8]  R2676     1.5807143449783325e+00
    phi[9,8]  R2677     2.5216004848480225e+00
    phi[9,8]  R2678     1.6859062910079956e+00
    phi[9,8]  R2679     -3.6506819725036621e+00
    phi[9,8]  R2680     -2.4281208515167236e+00
    phi[9,8]  R2681     7.4852830171585083e-01
    phi[9,8]  R2682     9.6715521812438965e-01
    phi[9,8]  R2683     -3.2735447883605957e+00
    phi[9,8]  R2684     -2.8394782543182373e-01
    phi[9,8]  R2685     -2.4272768497467041e+00
    phi[9,8]  R2686     -2.4388277530670166e+00
    phi[9,8]  R2687     -2.0191102027893066e+00
    phi[9,8]  R2688     -1.7299532890319824e+00
    phi[9,8]  R2689     -2.6376559734344482e+00
    phi[9,8]  R2690     -1.1543844938278198e+00
    phi[9,8]  R2691     -2.3202095031738281e+00
    phi[9,8]  R2692     -1.0307776927947998e+00
    phi[9,8]  R2693     -1.6586560010910034e+00
    phi[9,8]  R2694     -9.3515825271606445e-01
    phi[9,8]  R2695     6.1683833599090576e-02
    phi[9,8]  R2696     7.2133266925811768e-01
    phi[9,8]  R2697     8.0181114375591278e-02
    phi[9,8]  R2698     2.1829934418201447e-01
    phi[9,8]  R2699     1.7059228420257568e+00
    phi[9,8]  R2700     -1.8701533079147339e+00
    phi[9,8]  R2701     2.3010098934173584e+00
    phi[9,8]  R2702     4.3423545360565186e-01
    phi[9,8]  R2703     -2.8814435005187988e+00
    phi[9,8]  R2704     1.8875710964202881e+00
    phi[9,8]  R2705     -1.1382663249969482e+00
    phi[9,8]  R2706     -1.4407877922058105e+00
    phi[9,8]  R2707     -1.1249930858612061e+00
    phi[9,8]  R2708     2.4859089851379395e+00
    phi[9,8]  R2709     7.5005650520324707e-02
    phi[9,8]  R2710     -2.4521486759185791e+00
    phi[9,8]  R2711     1.4906034469604492e+00
    phi[9,8]  R2712     9.5230972766876221e-01
    phi[9,8]  R2713     1.9197340309619904e-01
    phi[9,8]  R2714     1.0262948274612427e+00
    phi[9,8]  R2715     2.7885069847106934e+00
    phi[9,8]  R2716     4.6533304452896118e-01
    phi[9,8]  R2717     4.2471304535865784e-01
    phi[9,8]  R2718     1.6023153066635132e-01
    phi[9,10]  R81       1
    phi[9,10]  R82       1
    phi[9,10]  R90       -1
    phi[9,10]  R2719     -3.0999999046325684e+00
    phi[9,10]  R2720     -3.0999999046325684e+00
    phi[9,10]  R2721     -2.2400000095367432e+00
    phi[9,10]  R2722     -2.2400000095367432e+00
    phi[9,10]  R2723     -3.0999999046325684e+00
    phi[9,10]  R2724     -3.0999999046325684e+00
    phi[9,10]  R2725     -2.5699999332427979e+00
    phi[9,10]  R2726     -2.5699999332427979e+00
    phi[9,10]  R2727     -3.0999999046325684e+00
    phi[9,10]  R2728     -3.0999999046325684e+00
    phi[9,10]  R2729     -2.0899999141693115e+00
    phi[9,10]  R2730     -2.0899999141693115e+00
    phi[9,10]  R2731     -3.0999999046325684e+00
    phi[9,10]  R2732     -3.0999999046325684e+00
    phi[9,10]  R2733     1.0027934312820435e+00
    phi[9,10]  R2734     8.3381354808807373e-01
    phi[9,10]  R2735     1.7219812870025635e+00
    phi[9,10]  R2736     -1.0042651891708374e+00
    phi[9,10]  R2737     1.6229294538497925e+00
    phi[9,10]  R2738     3.5058948397636414e-01
    phi[9,10]  R2739     2.5720973014831543e+00
    phi[9,10]  R2740     2.4920377731323242e+00
    phi[9,10]  R2741     1.7450097799301147e+00
    phi[9,10]  R2742     2.7962107658386230e+00
    phi[9,10]  R2743     -1.9602245092391968e+00
    phi[9,10]  R2744     -3.1749649047851562e+00
    phi[9,10]  R2745     -1.6601054668426514e+00
    phi[9,10]  R2746     -3.0586068630218506e+00
    phi[9,10]  R2747     -2.7548179626464844e+00
    phi[9,10]  R2748     -1.9556419849395752e+00
    phi[9,10]  R2749     -1.5780589580535889e+00
    phi[9,10]  R2750     -2.9529213905334473e+00
    phi[9,10]  R2751     -2.6807627677917480e+00
    phi[9,10]  R2752     -2.9962100982666016e+00
    phi[9,10]  R2753     -2.4738800525665283e+00
    phi[9,10]  R2754     -2.5845723152160645e+00
    phi[9,10]  R2755     -3.2534070014953613e+00
    phi[9,10]  R2756     -3.2127389907836914e+00
    phi[9,10]  R2757     -2.4754526615142822e+00
    phi[9,10]  R2758     -3.0101046562194824e+00
    phi[9,10]  R2759     -2.6814196109771729e+00
    phi[9,10]  R2760     -2.6337335109710693e+00
    phi[9,10]  R2761     -1.9390234947204590e+00
    phi[9,10]  R2762     -2.6822500228881836e+00
    phi[9,10]  R2763     1.3754380941390991e+00
    phi[9,10]  R2764     -1.4931761026382446e+00
    phi[9,10]  R2765     -3.0424292087554932e+00
    phi[9,10]  R2766     -2.8672156333923340e+00
    phi[9,10]  R2767     -1.6808737516403198e+00
    phi[9,10]  R2768     -2.1011133193969727e+00
    phi[9,10]  R2769     -2.4073097705841064e+00
    phi[9,10]  R2770     -8.6528354883193970e-01
    phi[9,10]  R2771     -1.4549417495727539e+00
    phi[9,10]  R2772     1.5985418558120728e+00
    phi[9,10]  R2773     5.8380788564682007e-01
    phi[9,10]  R2774     1.8765554428100586e+00
    phi[9,10]  R2775     1.0134727954864502e+00
    phi[9,10]  R2776     1.5521807670593262e+00
    phi[9,10]  R2777     -3.1512522697448730e-01
    phi[9,10]  R2778     2.0058498382568359e+00
    phi[9,10]  R2779     1.5670864582061768e+00
    phi[9,10]  R2780     -2.2531807422637939e-01
    phi[9,10]  R2781     -1.4889042377471924e+00
    phi[9,10]  R2782     -2.8928515911102295e+00
    phi[9,10]  R2783     -1.9395288228988647e+00
    phi[9,10]  R2784     -1.8933738470077515e+00
    phi[9,10]  R2785     -3.5338141918182373e+00
    phi[9,10]  R2786     -1.6068809032440186e+00
    phi[9,10]  R2787     2.1437532901763916e+00
    phi[9,10]  R2788     -2.3747682571411133e+00
    phi[9,10]  R2789     -2.94879412651062
    phi[9,10]  R2790     -9.8583489656448364e-01
    phi[9,10]  R2791     -2.7908730506896973e+00
    phi[9,10]  R2792     -2.4305260181427
    phi[9,10]  R2793     -3.0656330585479736e+00
    phi[9,10]  R2794     -3.1409878730773926e+00
    phi[9,10]  R2795     -1.6800541877746582e+00
    phi[9,10]  R2796     -1.1210966110229492e+00
    phi[9,10]  R2797     6.4095509052276611e-01
    phi[9,10]  R2798     1.0346718132495880e-01
    phi[9,10]  R2799     -5.0856810808181763e-01
    phi[9,10]  R2800     2.5213744640350342e+00
    phi[9,10]  R2801     -5.8772259950637817e-01
    phi[9,10]  R2802     -1.3815438747406006e+00
    phi[9,10]  R2803     -2.6550364494323730e+00
    phi[9,10]  R2804     -1.7782332897186279e+00
    phi[9,10]  R2805     -1.7554315328598022e+00
    phi[9,10]  R2806     -2.4815697669982910e+00
    phi[9,10]  R2807     2.5347137451171875e-01
    phi[9,10]  R2808     -1.2748326361179352e-01
    phi[9,10]  R2809     -7.2897094488143921e-01
    phi[9,10]  R2810     4.9220538139343262e-01
    phi[9,10]  R2811     2.5374369621276855e+00
    phi[10,9]  R81       -1
    phi[10,9]  R90       1
    phi[10,9]  R91       1
    phi[10,9]  R2812     -3.0999999046325684e+00
    phi[10,9]  R2813     -3.0999999046325684e+00
    phi[10,9]  R2814     -2.2400000095367432e+00
    phi[10,9]  R2815     -2.2400000095367432e+00
    phi[10,9]  R2816     -3.0999999046325684e+00
    phi[10,9]  R2817     -3.0999999046325684e+00
    phi[10,9]  R2818     -2.5699999332427979e+00
    phi[10,9]  R2819     -2.5699999332427979e+00
    phi[10,9]  R2820     -3.0999999046325684e+00
    phi[10,9]  R2821     -3.0999999046325684e+00
    phi[10,9]  R2822     -2.0899999141693115e+00
    phi[10,9]  R2823     -2.0899999141693115e+00
    phi[10,9]  R2824     -3.0999999046325684e+00
    phi[10,9]  R2825     -3.0999999046325684e+00
    phi[10,9]  R2826     1.5985418558120728e+00
    phi[10,9]  R2827     5.8380788564682007e-01
    phi[10,9]  R2828     1.8765554428100586e+00
    phi[10,9]  R2829     1.0134727954864502e+00
    phi[10,9]  R2830     1.5521807670593262e+00
    phi[10,9]  R2831     -3.1512522697448730e-01
    phi[10,9]  R2832     2.0058498382568359e+00
    phi[10,9]  R2833     1.5670864582061768e+00
    phi[10,9]  R2834     -2.2531807422637939e-01
    phi[10,9]  R2835     -1.4889042377471924e+00
    phi[10,9]  R2836     -2.8928515911102295e+00
    phi[10,9]  R2837     -1.9395288228988647e+00
    phi[10,9]  R2838     -1.8933738470077515e+00
    phi[10,9]  R2839     -3.5338141918182373e+00
    phi[10,9]  R2840     -1.6068809032440186e+00
    phi[10,9]  R2841     2.1437532901763916e+00
    phi[10,9]  R2842     -2.3747682571411133e+00
    phi[10,9]  R2843     -2.94879412651062
    phi[10,9]  R2844     -9.8583489656448364e-01
    phi[10,9]  R2845     -2.7908730506896973e+00
    phi[10,9]  R2846     -2.4305260181427
    phi[10,9]  R2847     -3.0656330585479736e+00
    phi[10,9]  R2848     -3.1409878730773926e+00
    phi[10,9]  R2849     -1.6800541877746582e+00
    phi[10,9]  R2850     -1.1210966110229492e+00
    phi[10,9]  R2851     6.4095509052276611e-01
    phi[10,9]  R2852     1.0346718132495880e-01
    phi[10,9]  R2853     -5.0856810808181763e-01
    phi[10,9]  R2854     2.5213744640350342e+00
    phi[10,9]  R2855     -5.8772259950637817e-01
    phi[10,9]  R2856     -1.3815438747406006e+00
    phi[10,9]  R2857     -2.6550364494323730e+00
    phi[10,9]  R2858     -1.7782332897186279e+00
    phi[10,9]  R2859     -1.7554315328598022e+00
    phi[10,9]  R2860     -2.4815697669982910e+00
    phi[10,9]  R2861     2.5347137451171875e-01
    phi[10,9]  R2862     -1.2748326361179352e-01
    phi[10,9]  R2863     -7.2897094488143921e-01
    phi[10,9]  R2864     4.9220538139343262e-01
    phi[10,9]  R2865     2.5374369621276855e+00
    phi[10,9]  R2866     1.0027934312820435e+00
    phi[10,9]  R2867     8.3381354808807373e-01
    phi[10,9]  R2868     1.7219812870025635e+00
    phi[10,9]  R2869     -1.0042651891708374e+00
    phi[10,9]  R2870     1.6229294538497925e+00
    phi[10,9]  R2871     3.5058948397636414e-01
    phi[10,9]  R2872     2.5720973014831543e+00
    phi[10,9]  R2873     2.4920377731323242e+00
    phi[10,9]  R2874     1.7450097799301147e+00
    phi[10,9]  R2875     2.7962107658386230e+00
    phi[10,9]  R2876     -1.9602245092391968e+00
    phi[10,9]  R2877     -3.1749649047851562e+00
    phi[10,9]  R2878     -1.6601054668426514e+00
    phi[10,9]  R2879     -3.0586068630218506e+00
    phi[10,9]  R2880     -2.7548179626464844e+00
    phi[10,9]  R2881     -1.9556419849395752e+00
    phi[10,9]  R2882     -1.5780589580535889e+00
    phi[10,9]  R2883     -2.9529213905334473e+00
    phi[10,9]  R2884     -2.6807627677917480e+00
    phi[10,9]  R2885     -2.9962100982666016e+00
    phi[10,9]  R2886     -2.4738800525665283e+00
    phi[10,9]  R2887     -2.5845723152160645e+00
    phi[10,9]  R2888     -3.2534070014953613e+00
    phi[10,9]  R2889     -3.2127389907836914e+00
    phi[10,9]  R2890     -2.4754526615142822e+00
    phi[10,9]  R2891     -3.0101046562194824e+00
    phi[10,9]  R2892     -2.6814196109771729e+00
    phi[10,9]  R2893     -2.6337335109710693e+00
    phi[10,9]  R2894     -1.9390234947204590e+00
    phi[10,9]  R2895     -2.6822500228881836e+00
    phi[10,9]  R2896     1.3754380941390991e+00
    phi[10,9]  R2897     -1.4931761026382446e+00
    phi[10,9]  R2898     -3.0424292087554932e+00
    phi[10,9]  R2899     -2.8672156333923340e+00
    phi[10,9]  R2900     -1.6808737516403198e+00
    phi[10,9]  R2901     -2.1011133193969727e+00
    phi[10,9]  R2902     -2.4073097705841064e+00
    phi[10,9]  R2903     -8.6528354883193970e-01
    phi[10,9]  R2904     -1.4549417495727539e+00
    phi[10,12]  R90       1
    phi[10,12]  R91       1
    phi[10,12]  R92       1.9933044912139959e+00
    phi[10,12]  R93       -1.4009757778449381e+00
    phi[10,12]  R94       -1.2154758672111909e+00
    phi[10,12]  R95       -9.3886620060333836e-01
    phi[10,12]  R96       2.2911676762182753e+00
    phi[10,12]  R97       8.8766089629573086e-01
    phi[10,12]  R98       2.3022944713510531e+00
    phi[10,12]  R100      -1
    phi[10,12]  R2905     -1.1066954134185725e+00
    phi[10,12]  R2906     -5.0933043958465642e+00
    phi[10,12]  R2907     -3.6409757873816813e+00
    phi[10,12]  R2908     -8.3902423169180507e-01
    phi[10,12]  R2909     -4.31547577184376
    phi[10,12]  R2910     -1.8845240374213774e+00
    phi[10,12]  R2911     -3.5088661338461362e+00
    phi[10,12]  R2912     -1.6311337326394595e+00
    phi[10,12]  R2913     -0.808832228414293
    phi[10,12]  R2914     -5.3911675808508441e+00
    phi[10,12]  R2915     -1.2023390178735807e+00
    phi[10,12]  R2916     -2.9776608104650424e+00
    phi[10,12]  R2917     -7.9770543328151522e-01
    phi[10,12]  R2918     -5.4022943759836215e+00
    phi[10,12]  R2919     -6.3750127722928873e-02
    phi[10,12]  R2920     -0.954120208349726
    phi[10,12]  R2921     -2.3655790226838214e-01
    phi[10,12]  R2922     -4.2963051872387803e-01
    phi[10,12]  R2923     -5.0196795368613945e-01
    phi[10,12]  R2924     -5.1642145303052678e-01
    phi[10,12]  R2925     -5.8684054965868260e-01
    phi[10,12]  R2926     -6.2582138596582926e-01
    phi[10,12]  R2927     -6.8714947188635356e-01
    phi[10,12]  R2928     -7.1614106773954145e-01
    phi[10,12]  R2929     -2.4185482829080929e-01
    phi[10,12]  R2930     -1.5459581285864283e+00
    phi[10,12]  R2931     -3.0929459645064794e-01
    phi[10,12]  R2932     -3.2311926176486105e-01
    phi[10,12]  R2933     -5.3223733297627063e-01
    phi[10,12]  R2934     -6.5653553684517441e-01
    phi[10,12]  R2935     -6.9828558238627325e-01
    phi[10,12]  R2936     -7.0234015504607727e-01
    phi[10,12]  R2937     -7.1155870481612371e-01
    phi[10,12]  R2938     -7.4806649959471017e-01
    phi[10,12]  R2939     -1.1841468833947226e+00
    phi[10,12]  R2940     -1.4622264720458711e-01
    phi[10,12]  R2941     -1.6122032987069090e-01
    phi[10,12]  R2942     -2.1548205397878317e-01
    phi[10,12]  R2943     -4.0713803992841924e-01
    phi[10,12]  R2944     -4.1624375572081562e-01
    phi[10,12]  R2945     -4.5214879074180692e-01
    phi[10,12]  R2946     -4.5320138630947571e-01
    phi[10,12]  R2947     -4.5932866364858427e-01
    phi[10,12]  R2948     -4.7463792498319785e-01
    phi[10,12]  R2949     -1.1249712402680223e-01
    phi[10,12]  R2950     -1.1889495105662196e-01
    phi[10,12]  R2951     -2.4302834569766745e+00
    phi[10,12]  R2952     -9.5334696235551153e-01
    phi[10,12]  R2953     -2.0505076184644544e-01
    phi[10,12]  R2954     -0.538228651262729
    phi[10,12]  R2955     -3.0257640081507176e-01
    phi[10,12]  R2956     -3.2254940000734816e-01
    phi[10,12]  R2957     -3.5925845692359437e-01
    phi[10,12]  R2958     -3.8560051323141664e-01
    MARKER    'MARKER'                 'INTEND'
    z[0,1,0]  R2        -1
    z[0,1,0]  R11       1
    z[0,1,0]  R101      -1
    z[0,1,0]  R102      1
    z[0,1,0]  R115      -6.9029080867767334e-01
    z[0,1,0]  R116      -4.7948607802391052e-01
    z[0,1,0]  R117      -3.6352571845054626e-01
    z[0,1,0]  R118      3.1492796540260315e-01
    z[0,1,0]  R119      -6.8361979722976685e-01
    z[0,1,0]  R120      -3.9291390776634216e-01
    z[0,1,0]  R121      -6.2230610847473145e-01
    z[0,1,0]  R122      4.3786278367042542e-01
    z[0,1,0]  R123      -9.7427040338516235e-02
    z[0,1,0]  R124      3.1236737966537476e-01
    z[0,1,0]  R125      6.8013924360275269e-01
    z[0,1,0]  R126      5.9047341346740723e-01
    z[0,1,0]  R127      4.2939627170562744e-01
    z[0,1,0]  R128      2.4498873949050903e-01
    z[0,1,0]  R129      5.3376400470733643e-01
    z[0,1,0]  R130      4.9152234196662903e-01
    z[0,1,0]  R131      0.437198281288147
    z[0,1,0]  R132      4.2546495795249939e-01
    z[0,1,0]  R133      4.9120023846626282e-01
    z[0,1,0]  R134      6.6296797990798950e-01
    z[0,1,0]  R135      6.9182682037353516e-01
    z[0,1,0]  R136      8.6664527654647827e-01
    z[0,1,0]  R137      4.6247753500938416e-01
    z[0,1,0]  R138      4.8343020677566528e-01
    z[0,1,0]  R139      3.7243533134460449e-01
    z[0,1,0]  R140      -2.7585852146148682e-01
    z[0,1,0]  R141      -5.0596201419830322e-01
    z[0,1,0]  R142      -2.4157655239105225e-01
    z[0,1,0]  R143      1.1826107278466225e-02
    z[0,1,0]  R144      -8.6852979660034180e-01
    z[0,1,0]  R145      5.3969722986221313e-01
    z[0,1,0]  R146      7.3571568727493286e-01
    z[0,1,0]  R147      3.1171849370002747e-01
    z[0,1,0]  R148      5.9647589921951294e-01
    z[0,1,0]  R149      4.7417908906936646e-01
    z[0,1,0]  R150      3.1378906965255737e-01
    z[0,1,0]  R151      -2.1871018409729004e-01
    z[0,1,0]  R152      1.9904276728630066e-01
    z[0,1,0]  R153      -8.0036675930023193e-01
    z[0,1,0]  R154      -6.4029139280319214e-01
    z[0,1,0]  R155      7.1646350622177124e-01
    z[0,1,0]  R156      1.7705178260803223e-01
    z[0,1,0]  R157      -2.1720215678215027e-01
    z[0,1,0]  R158      8.9121591299772263e-03
    z[0,1,0]  R159      -5.6046193838119507e-01
    z[0,1,0]  R160      -5.5888706445693970e-01
    z[0,1,0]  R161      -4.9922522902488708e-01
    z[0,1,0]  R162      -6.4466184377670288e-01
    z[0,1,0]  R163      -4.9271151423454285e-01
    z[0,1,0]  R164      -3.0665445327758789e-01
    z[0,1,0]  R165      3.5255894064903259e-01
    z[0,1,0]  R166      2.5943002104759216e-01
    z[0,1,0]  R167      -5.9411031007766724e-01
    z[0,1,0]  R168      -7.7178573608398438e-01
    z[0,1,0]  R169      -0.617535412311554
    z[0,1,0]  R170      -0.663107693195343
    z[0,1,0]  R171      -4.2091947793960571e-01
    z[0,1,0]  R172      1.9382099807262421e-01
    z[0,1,0]  R173      1.1183512210845947e-01
    z[0,1,0]  R174      2.4639831483364105e-01
    z[0,1,0]  R175      -1.3894502818584442e-01
    z[0,1,0]  R176      1.3602147996425629e-01
    z[0,1,0]  R177      -9.3008416891098022e-01
    z[0,1,0]  R178      -8.4046369791030884e-01
    z[0,1,0]  R179      -7.8733968734741211e-01
    z[0,1,0]  R180      -8.8880550861358643e-01
    z[0,1,0]  R181      -9.0660637617111206e-01
    z[0,1,0]  R182      -8.6132991313934326e-01
    z[0,1,0]  R183      -7.4839603900909424e-01
    z[0,1,0]  R184      -9.2447394132614136e-01
    z[0,1,0]  R185      -6.3099667429924011e-02
    z[0,1,0]  R186      4.1129431128501892e-01
    z[0,1,0]  R187      -3.1831058859825134e-01
    z[0,1,0]  R188      4.7566571831703186e-01
    z[0,1,0]  R189      -1.3901624083518982e-01
    z[0,1,0]  R190      -4.0207871794700623e-01
    z[0,1,0]  R191      3.2552149891853333e-01
    z[0,1,0]  R192      5.9157520532608032e-01
    z[0,1,0]  R193      8.1628121435642242e-02
    z[0,1,0]  R194      8.0147922039031982e-01
    z[0,1,0]  R195      -3.5144484043121338e-01
    z[0,1,0]  R196      -1.4187182486057281e-01
    z[0,1,0]  R197      2.7030315995216370e-01
    z[0,1,0]  R198      2.3140832781791687e-02
    z[0,1,0]  R199      8.6315566301345825e-01
    z[0,1,0]  R200      8.6348617076873779e-01
    z[0,1,0]  R201      8.1512153148651123e-01
    z[0,1,0]  R202      8.0033266544342041e-01
    z[0,1,0]  R203      7.6406925916671753e-01
    z[0,1,0]  R204      0.789068341255188
    z[0,1,0]  R205      4.6590375900268555e-01
    z[0,1,0]  R206      1.5367440879344940e-01
    z[0,1,0]  R207      3.1646621227264404e-01
    z[0,1,0]  R208      5.1167792081832886e-01
    z[0,1,0]  R209      -5.7876616716384888e-01
    z[0,1,0]  R210      9.7735965251922607e-01
    z[0,1,0]  R211      -5.6773281097412109e-01
    z[0,1,0]  R212      -1.3762372732162476e-01
    z[0,1,0]  R213      2.2838750854134560e-02
    z[0,1,0]  R214      2.4538686871528625e-01
    z[0,1,1]  R3        -1
    z[0,1,1]  R12       1
    z[0,1,1]  R103      -1
    z[0,1,1]  R104      1
    z[0,1,1]  R115      6.8876188993453979e-01
    z[0,1,1]  R116      5.5734479427337646e-01
    z[0,1,1]  R117      6.5846377611160278e-01
    z[0,1,1]  R118      -2.3913277685642242e-01
    z[0,1,1]  R119      3.0663841962814331e-01
    z[0,1,1]  R120      6.6253763437271118e-01
    z[0,1,1]  R121      3.6166846752166748e-01
    z[0,1,1]  R122      -4.9874192476272583e-01
    z[0,1,1]  R123      7.7765363454818726e-01
    z[0,1,1]  R124      -8.5132378339767456e-01
    z[0,1,1]  R125      -3.8043260574340820e-01
    z[0,1,1]  R126      -6.4856219291687012e-01
    z[0,1,1]  R127      -4.4086936116218567e-01
    z[0,1,1]  R128      -1.3169863820075989e-01
    z[0,1,1]  R129      -2.3086988925933838e-01
    z[0,1,1]  R130      -2.3843519389629364e-01
    z[0,1,1]  R131      -2.6134535670280457e-01
    z[0,1,1]  R132      -4.0785002708435059e-01
    z[0,1,1]  R133      -0.0882725715637207
    z[0,1,1]  R134      -1.3807876408100128e-01
    z[0,1,1]  R135      -3.0949419736862183e-01
    z[0,1,1]  R136      -1.7820264399051666e-01
    z[0,1,1]  R137      -3.8250735402107239e-01
    z[0,1,1]  R138      2.9533011838793755e-03
    z[0,1,1]  R139      -1.4792908728122711e-01
    z[0,1,1]  R140      -7.5608861446380615e-01
    z[0,1,1]  R141      -6.2702518701553345e-01
    z[0,1,1]  R142      6.7242813110351562e-01
    z[0,1,1]  R143      8.3544468879699707e-01
    z[0,1,1]  R144      -2.9309463500976562e-01
    z[0,1,1]  R145      -4.7128647565841675e-01
    z[0,1,1]  R146      -1.7082288861274719e-01
    z[0,1,1]  R147      -2.7031362056732178e-01
    z[0,1,1]  R148      -1.0288413614034653e-01
    z[0,1,1]  R149      -5.4447576403617859e-02
    z[0,1,1]  R150      4.7189202159643173e-02
    z[0,1,1]  R151      -5.4218143224716187e-01
    z[0,1,1]  R152      -2.1132104098796844e-01
    z[0,1,1]  R153      -1.0854940116405487e-01
    z[0,1,1]  R154      8.0984160304069519e-02
    z[0,1,1]  R155      -2.1249166131019592e-01
    z[0,1,1]  R156      -1.7520454525947571e-01
    z[0,1,1]  R157      -8.4995454549789429e-01
    z[0,1,1]  R158      -8.7925010919570923e-01
    z[0,1,1]  R159      1.9589031115174294e-02
    z[0,1,1]  R160      -3.1845444440841675e-01
    z[0,1,1]  R161      -4.0104719996452332e-01
    z[0,1,1]  R162      -2.9031151533126831e-01
    z[0,1,1]  R163      -2.0443591475486755e-01
    z[0,1,1]  R164      -7.5759190320968628e-01
    z[0,1,1]  R165      -1.7950202524662018e-01
    z[0,1,1]  R166      -3.3796465396881104e-01
    z[0,1,1]  R167      -2.9013815522193909e-01
    z[0,1,1]  R168      -2.6815903186798096e-01
    z[0,1,1]  R169      -1.3203978538513184e-01
    z[0,1,1]  R170      -2.8501585125923157e-01
    z[0,1,1]  R171      -7.5110089778900146e-01
    z[0,1,1]  R172      2.6301905512809753e-01
    z[0,1,1]  R173      0.227512925863266
    z[0,1,1]  R174      1.8195466697216034e-01
    z[0,1,1]  R175      4.5714911073446274e-02
    z[0,1,1]  R176      9.5595233142375946e-02
    z[0,1,1]  R177      -1.5452742576599121e-01
    z[0,1,1]  R178      -3.0428934097290039e-01
    z[0,1,1]  R179      -1.7054866254329681e-01
    z[0,1,1]  R180      -2.4879324436187744e-01
    z[0,1,1]  R181      -2.3625767230987549e-01
    z[0,1,1]  R182      -2.0802576839923859e-01
    z[0,1,1]  R183      -2.8309798240661621e-01
    z[0,1,1]  R184      8.6726211011409760e-02
    z[0,1,1]  R185      6.4761382341384888e-01
    z[0,1,1]  R186      0.524172842502594
    z[0,1,1]  R187      4.9181440472602844e-01
    z[0,1,1]  R188      1.8394406139850616e-01
    z[0,1,1]  R189      1.9864578545093536e-01
    z[0,1,1]  R190      3.9298623800277710e-01
    z[0,1,1]  R191      4.8723950982093811e-01
    z[0,1,1]  R192      3.2236889004707336e-01
    z[0,1,1]  R193      1.7612237483263016e-02
    z[0,1,1]  R194      1.1396908015012741e-01
    z[0,1,1]  R195      6.6057032346725464e-01
    z[0,1,1]  R196      0.470954954624176
    z[0,1,1]  R197      4.3172460794448853e-01
    z[0,1,1]  R198      4.9238261580467224e-01
    z[0,1,1]  R199      1.4013834297657013e-01
    z[0,1,1]  R200      2.7400064468383789e-01
    z[0,1,1]  R201      1.6780835390090942e-01
    z[0,1,1]  R202      -4.7978889197111130e-02
    z[0,1,1]  R203      -2.1913725137710571e-01
    z[0,1,1]  R204      1.0546435415744781e-01
    z[0,1,1]  R205      2.3242063820362091e-01
    z[0,1,1]  R206      6.2136089801788330e-01
    z[0,1,1]  R207      5.8741199970245361e-01
    z[0,1,1]  R208      5.3919184207916260e-01
    z[0,1,1]  R209      3.9454418420791626e-01
    z[0,1,1]  R210      3.5307902842760086e-02
    z[0,1,1]  R211      3.3526644110679626e-02
    z[0,1,1]  R212      -9.3011397123336792e-01
    z[0,1,1]  R213      -9.3885004520416260e-01
    z[0,1,1]  R214      -8.6740863323211670e-01
    z[0,1,2]  R4        -1
    z[0,1,2]  R13       1
    z[0,1,2]  R105      -1
    z[0,1,2]  R106      1
    z[0,1,2]  R115      1.1417567729949951e-01
    z[0,1,2]  R116      -0.574375331401825
    z[0,1,2]  R117      -5.9017833322286606e-02
    z[0,1,2]  R118      -8.5726588964462280e-01
    z[0,1,2]  R119      -5.6133270263671875e-01
    z[0,1,2]  R120      -3.2849911600351334e-02
    z[0,1,2]  R121      -5.9648370742797852e-01
    z[0,1,2]  R122      7.4725419282913208e-02
    z[0,1,2]  R123      -2.9491904377937317e-01
    z[0,1,2]  R124      1.0105685144662857e-01
    z[0,1,2]  R125      2.7553543448448181e-01
    z[0,1,2]  R126      -4.1228145360946655e-01
    z[0,1,2]  R127      9.3121513724327087e-02
    z[0,1,2]  R128      4.8655167222023010e-01
    z[0,1,2]  R129      3.1604412198066711e-01
    z[0,1,2]  R130      -2.5727536529302597e-02
    z[0,1,2]  R131      1.7459660768508911e-01
    z[0,1,2]  R132      2.6592442393302917e-01
    z[0,1,2]  R133      -3.9491853117942810e-01
    z[0,1,2]  R134      -4.3716830015182495e-01
    z[0,1,2]  R135      -3.9838417433202267e-03
    z[0,1,2]  R136      -3.2771885395050049e-01
    z[0,1,2]  R137      3.0730563402175903e-01
    z[0,1,2]  R138      -7.7303111553192139e-01
    z[0,1,2]  R139      -0.675874650478363
    z[0,1,2]  R140      3.4612563252449036e-01
    z[0,1,2]  R141      0.34788778424263
    z[0,1,2]  R142      -4.6885243058204651e-01
    z[0,1,2]  R143      -1.5088966488838196e-01
    z[0,1,2]  R144      -9.6128843724727631e-02
    z[0,1,2]  R145      5.2127641439437866e-01
    z[0,1,2]  R146      -1.7546087503433228e-02
    z[0,1,2]  R147      7.1646285057067871e-01
    z[0,1,2]  R148      -9.8113827407360077e-02
    z[0,1,2]  R149      -7.1265298128128052e-01
    z[0,1,2]  R150      0.572374165058136
    z[0,1,2]  R151      1.8950580060482025e-01
    z[0,1,2]  R152      -7.4307578802108765e-01
    z[0,1,2]  R153      -1.7928022146224976e-01
    z[0,1,2]  R154      -3.9722275733947754e-01
    z[0,1,2]  R155      -5.4388207197189331e-01
    z[0,1,2]  R156      5.6201952695846558e-01
    z[0,1,2]  R157      -4.2331553995609283e-02
    z[0,1,2]  R158      8.4929078817367554e-02
    z[0,1,2]  R159      -5.8321011066436768e-01
    z[0,1,2]  R160      -5.6509381532669067e-01
    z[0,1,2]  R161      -6.0826295614242554e-01
    z[0,1,2]  R162      9.1853000223636627e-02
    z[0,1,2]  R163      2.4066691100597382e-01
    z[0,1,2]  R164      -1.8711318075656891e-01
    z[0,1,2]  R165      8.0392867326736450e-01
    z[0,1,2]  R166      6.3776248693466187e-01
    z[0,1,2]  R167      -5.3402411937713623e-01
    z[0,1,2]  R168      -1.8136838078498840e-01
    z[0,1,2]  R169      -5.2615791559219360e-01
    z[0,1,2]  R170      8.3538889884948730e-02
    z[0,1,2]  R171      -1.2947911024093628e-01
    z[0,1,2]  R172      2.0583336055278778e-01
    z[0,1,2]  R173      2.0269340276718140e-01
    z[0,1,2]  R174      1.9157193601131439e-01
    z[0,1,2]  R175      -3.4589764475822449e-01
    z[0,1,2]  R176      6.7459084093570709e-02
    z[0,1,2]  R177      -3.8910549134016037e-02
    z[0,1,2]  R178      -2.6638289913535118e-02
    z[0,1,2]  R179      -4.0393546223640442e-01
    z[0,1,2]  R180      1.1216019839048386e-01
    z[0,1,2]  R181      8.4725886583328247e-02
    z[0,1,2]  R182      -2.9832099098712206e-03
    z[0,1,2]  R183      -2.7745479345321655e-01
    z[0,1,2]  R184      -3.1092030927538872e-02
    z[0,1,2]  R185      4.8684078454971313e-01
    z[0,1,2]  R186      -4.1123846173286438e-01
    z[0,1,2]  R187      2.3864111304283142e-01
    z[0,1,2]  R188      -2.2743576765060425e-01
    z[0,1,2]  R189      -5.5330187082290649e-01
    z[0,1,2]  R190      -4.2811136692762375e-02
    z[0,1,2]  R191      -6.3877038657665253e-02
    z[0,1,2]  R192      4.2054817080497742e-01
    z[0,1,2]  R193      -4.1802123188972473e-01
    z[0,1,2]  R194      8.6916297674179077e-02
    z[0,1,2]  R195      -1.8759422004222870e-01
    z[0,1,2]  R196      6.2493032217025757e-01
    z[0,1,2]  R197      1.5951023995876312e-01
    z[0,1,2]  R198      -3.9223572611808777e-01
    z[0,1,2]  R199      -1.4474473893642426e-02
    z[0,1,2]  R200      -0.140329509973526
    z[0,1,2]  R201      1.3617476820945740e-01
    z[0,1,2]  R202      -1.8472173810005188e-01
    z[0,1,2]  R203      2.9430523514747620e-01
    z[0,1,2]  R204      -6.5737059339880943e-03
    z[0,1,2]  R205      -3.7296712398529053e-01
    z[0,1,2]  R206      6.6249914467334747e-02
    z[0,1,2]  R207      2.2753553465008736e-02
    z[0,1,2]  R208      -2.7140554785728455e-01
    z[0,1,2]  R209      -2.4743634462356567e-01
    z[0,1,2]  R210      3.6267023533582687e-02
    z[0,1,2]  R211      -1.7865149676799774e-01
    z[0,1,2]  R212      1.5413431823253632e-01
    z[0,1,2]  R213      2.7333769202232361e-01
    z[0,1,2]  R214      2.0702511072158813e-01
    z[0,1,3]  R5        -1
    z[0,1,3]  R14       1
    z[0,1,3]  R107      -1
    z[0,1,3]  R108      1
    z[0,1,3]  R115      -0.0678451657295227
    z[0,1,3]  R116      -1.3548433780670166e-01
    z[0,1,3]  R117      -1.1063421517610550e-01
    z[0,1,3]  R118      -9.4647333025932312e-02
    z[0,1,3]  R119      1.0969156399369240e-02
    z[0,1,3]  R120      1.9984103739261627e-01
    z[0,1,3]  R121      4.2276620864868164e-02
    z[0,1,3]  R122      9.7874358296394348e-02
    z[0,1,3]  R123      -3.2411184906959534e-01
    z[0,1,3]  R124      2.3762327432632446e-01
    z[0,1,3]  R125      -2.5731608271598816e-01
    z[0,1,3]  R126      -8.6852097883820534e-03
    z[0,1,3]  R127      2.9908770322799683e-01
    z[0,1,3]  R128      0.393938809633255
    z[0,1,3]  R129      2.0770454406738281e-01
    z[0,1,3]  R130      -0.369414746761322
    z[0,1,3]  R131      -3.6439445614814758e-01
    z[0,1,3]  R132      -3.8094222545623779e-02
    z[0,1,3]  R133      1.3926652073860168e-01
    z[0,1,3]  R134      -9.5875173807144165e-02
    z[0,1,3]  R135      2.1542407572269440e-01
    z[0,1,3]  R136      -1.9525042176246643e-01
    z[0,1,3]  R137      -1.9396646320819855e-01
    z[0,1,3]  R138      -2.9219649732112885e-02
    z[0,1,3]  R139      -1.3671833276748657e-01
    z[0,1,3]  R140      2.2687381505966187e-01
    z[0,1,3]  R141      3.5593304038047791e-01
    z[0,1,3]  R142      5.0011351704597473e-02
    z[0,1,3]  R143      -1.1290618032217026e-01
    z[0,1,3]  R144      3.2332947850227356e-01
    z[0,1,3]  R145      4.1120469570159912e-02
    z[0,1,3]  R146      -2.9871767759323120e-01
    z[0,1,3]  R147      -1.4645922183990479e-01
    z[0,1,3]  R148      -1.4632616937160492e-01
    z[0,1,3]  R149      -2.7534502441994846e-04
    z[0,1,3]  R150      2.5992043316364288e-02
    z[0,1,3]  R151      0.542360246181488
    z[0,1,3]  R152      -2.6507434248924255e-01
    z[0,1,3]  R153      2.2793164849281311e-01
    z[0,1,3]  R154      3.4473106265068054e-01
    z[0,1,3]  R155      -0.0948726087808609
    z[0,1,3]  R156      3.2306537032127380e-01
    z[0,1,3]  R157      3.7537211179733276e-01
    z[0,1,3]  R158      2.6692369580268860e-01
    z[0,1,3]  R159      5.3066551685333252e-02
    z[0,1,3]  R160      1.3132546842098236e-01
    z[0,1,3]  R161      3.8658934831619263e-01
    z[0,1,3]  R162      3.2547989487648010e-01
    z[0,1,3]  R163      1.7181062698364258e-01
    z[0,1,3]  R164      -4.1411802172660828e-01
    z[0,1,3]  R165      -1.2294325232505798e-01
    z[0,1,3]  R166      -2.5055891275405884e-01
    z[0,1,3]  R167      3.5662662982940674e-01
    z[0,1,3]  R168      1.3685664534568787e-01
    z[0,1,3]  R169      2.9205927252769470e-01
    z[0,1,3]  R170      3.8362291455268860e-01
    z[0,1,3]  R171      -1.6145074367523193e-01
    z[0,1,3]  R172      -8.5773169994354248e-01
    z[0,1,3]  R173      -8.7036657333374023e-01
    z[0,1,3]  R174      -7.2870439291000366e-01
    z[0,1,3]  R175      -9.1660672426223755e-01
    z[0,1,3]  R176      -8.1101936101913452e-01
    z[0,1,3]  R177      -4.3476864695549011e-02
    z[0,1,3]  R178      -1.2680803239345551e-01
    z[0,1,3]  R179      -7.1115955710411072e-02
    z[0,1,3]  R180      -2.5599592924118042e-01
    z[0,1,3]  R181      3.2942626625299454e-02
    z[0,1,3]  R182      -0.411723792552948
    z[0,1,3]  R183      -4.6243837475776672e-01
    z[0,1,3]  R184      -3.5735196433961391e-03
    z[0,1,3]  R185      -1.7720645666122437e-01
    z[0,1,3]  R186      -4.6511989086866379e-02
    z[0,1,3]  R187      1.3114874064922333e-01
    z[0,1,3]  R188      2.3564623668789864e-02
    z[0,1,3]  R189      1.1789546906948090e-01
    z[0,1,3]  R190      3.9691349864006042e-01
    z[0,1,3]  R191      2.0991069078445435e-01
    z[0,1,3]  R192      1.3820931315422058e-01
    z[0,1,3]  R193      1.0030884295701981e-01
    z[0,1,3]  R194      -1.2336043268442154e-01
    z[0,1,3]  R195      0.185865581035614
    z[0,1,3]  R196      3.3921965956687927e-01
    z[0,1,3]  R197      -2.6427122950553894e-01
    z[0,1,3]  R198      1.5687417984008789e-01
    z[0,1,3]  R199      1.2083962559700012e-01
    z[0,1,3]  R200      0.269723504781723
    z[0,1,3]  R201      -1.8055105209350586e-01
    z[0,1,3]  R202      3.8706335425376892e-01
    z[0,1,3]  R203      1.7415404319763184e-01
    z[0,1,3]  R204      -1.6753622889518738e-01
    z[0,1,3]  R205      -2.6583081483840942e-01
    z[0,1,3]  R206      1.6575561463832855e-01
    z[0,1,3]  R207      3.2966342568397522e-01
    z[0,1,3]  R208      5.3757125139236450e-01
    z[0,1,3]  R209      1.4396762847900391e-01
    z[0,1,3]  R210      0.0681452751159668
    z[0,1,3]  R211      -2.2184237837791443e-01
    z[0,1,3]  R212      1.6380879282951355e-01
    z[0,1,3]  R213      8.4882482886314392e-02
    z[0,1,3]  R214      1.5975062549114227e-01
    z[0,1,4]  R6        -1
    z[0,1,4]  R15       1
    z[0,1,4]  R109      -1
    z[0,1,4]  R110      1
    z[0,1,4]  R115      -1.2120189517736435e-01
    z[0,1,4]  R116      -1.6644150018692017e-02
    z[0,1,4]  R117      -4.0243282914161682e-01
    z[0,1,4]  R118      -1.0758836567401886e-01
    z[0,1,4]  R119      -1.4688777923583984e-01
    z[0,1,4]  R120      5.7627922296524048e-01
    z[0,1,4]  R121      1.5947715938091278e-01
    z[0,1,4]  R122      -3.0412566661834717e-01
    z[0,1,4]  R123      -3.5344353318214417e-01
    z[0,1,4]  R124      1.1140636354684830e-01
    z[0,1,4]  R125      -2.8949698805809021e-01
    z[0,1,4]  R126      3.9010590407997370e-03
    z[0,1,4]  R127      3.7130358815193176e-01
    z[0,1,4]  R128      3.9439356327056885e-01
    z[0,1,4]  R129      2.1075166761875153e-01
    z[0,1,4]  R130      -4.3483439087867737e-01
    z[0,1,4]  R131      -2.6787722110748291e-01
    z[0,1,4]  R132      3.9472463726997375e-01
    z[0,1,4]  R133      7.2351747751235962e-01
    z[0,1,4]  R134      4.5562589168548584e-01
    z[0,1,4]  R135      3.8099324703216553e-01
    z[0,1,4]  R136      1.6383874416351318e-01
    z[0,1,4]  R137      -4.2869547009468079e-01
    z[0,1,4]  R138      1.1872775852680206e-01
    z[0,1,4]  R139      -1.6867731511592865e-01
    z[0,1,4]  R140      -2.4987480044364929e-01
    z[0,1,4]  R141      -2.3909607529640198e-01
    z[0,1,4]  R142      1.6473528742790222e-01
    z[0,1,4]  R143      2.0090369880199432e-01
    z[0,1,4]  R144      -2.1071296185255051e-02
    z[0,1,4]  R145      2.1560238301753998e-01
    z[0,1,4]  R146      -4.2910999059677124e-01
    z[0,1,4]  R147      -4.8600274324417114e-01
    z[0,1,4]  R148      -2.2981595993041992e-01
    z[0,1,4]  R149      4.6965587139129639e-01
    z[0,1,4]  R150      -1.6751392185688019e-01
    z[0,1,4]  R151      5.6711727380752563e-01
    z[0,1,4]  R152      -5.4128672927618027e-02
    z[0,1,4]  R153      -3.8084489107131958e-01
    z[0,1,4]  R154      2.7243146300315857e-01
    z[0,1,4]  R155      3.1633153557777405e-01
    z[0,1,4]  R156      1.5265546739101410e-01
    z[0,1,4]  R157      -1.4113360643386841e-01
    z[0,1,4]  R158      -1.2006637454032898e-01
    z[0,1,4]  R159      -4.4512525200843811e-01
    z[0,1,4]  R160      -3.4826430678367615e-01
    z[0,1,4]  R161      1.4216047525405884e-01
    z[0,1,4]  R162      3.1747040152549744e-01
    z[0,1,4]  R163      2.5590106844902039e-01
    z[0,1,4]  R164      2.0995254814624786e-01
    z[0,1,4]  R165      -3.6104434728622437e-01
    z[0,1,4]  R166      -2.8809291124343872e-01
    z[0,1,4]  R167      6.2319129705429077e-02
    z[0,1,4]  R168      -4.6922415494918823e-01
    z[0,1,4]  R169      -1.2612015008926392e-01
    z[0,1,4]  R170      3.4273722767829895e-01
    z[0,1,4]  R171      2.7127549052238464e-01
    z[0,1,4]  R172      2.9080295562744141e-01
    z[0,1,4]  R173      3.5414847731590271e-01
    z[0,1,4]  R174      5.3716570138931274e-01
    z[0,1,4]  R175      1.2073950469493866e-01
    z[0,1,4]  R176      -3.8818454742431641e-01
    z[0,1,4]  R177      -2.2023659944534302e-01
    z[0,1,4]  R178      -0.362755686044693
    z[0,1,4]  R179      -3.7469755858182907e-02
    z[0,1,4]  R180      -1.0215345025062561e-01
    z[0,1,4]  R181      -5.6431770324707031e-02
    z[0,1,4]  R182      -1.9362926483154297e-01
    z[0,1,4]  R183      -2.3312574625015259e-01
    z[0,1,4]  R184      2.0571598410606384e-01
    z[0,1,4]  R185      2.6713365316390991e-01
    z[0,1,4]  R186      -3.4226661920547485e-01
    z[0,1,4]  R187      3.6679524183273315e-01
    z[0,1,4]  R188      6.4701634645462036e-01
    z[0,1,4]  R189      3.2485261559486389e-01
    z[0,1,4]  R190      3.8113960623741150e-01
    z[0,1,4]  R191      2.6097622513771057e-01
    z[0,1,4]  R192      1.7337530851364136e-01
    z[0,1,4]  R193      4.5824062824249268e-01
    z[0,1,4]  R194      3.9034643769264221e-01
    z[0,1,4]  R195      -3.6595097184181213e-01
    z[0,1,4]  R196      -4.7360396385192871e-01
    z[0,1,4]  R197      4.6043559908866882e-01
    z[0,1,4]  R198      0.595091700553894
    z[0,1,4]  R199      -1.8384316563606262e-01
    z[0,1,4]  R200      1.9511753320693970e-01
    z[0,1,4]  R201      -1.5140847861766815e-01
    z[0,1,4]  R202      -3.7934783101081848e-01
    z[0,1,4]  R203      -4.6128010749816895e-01
    z[0,1,4]  R204      2.3113496601581573e-01
    z[0,1,4]  R205      5.4704319685697556e-02
    z[0,1,4]  R206      2.3262333869934082e-01
    z[0,1,4]  R207      -2.5647675991058350e-01
    z[0,1,4]  R208      8.6517877876758575e-02
    z[0,1,4]  R209      5.6493538618087769e-01
    z[0,1,4]  R210      0.00974711962044239
    z[0,1,4]  R211      4.3350827693939209e-01
    z[0,1,4]  R212      1.5536113083362579e-01
    z[0,1,4]  R213      -8.9821442961692810e-02
    z[0,1,4]  R214      6.9815821945667267e-02
    z[0,1,5]  R7        -1
    z[0,1,5]  R16       1
    z[0,1,5]  R111      -1
    z[0,1,5]  R112      1
    z[0,1,5]  R115      -2.2441111505031586e-02
    z[0,1,5]  R116      -3.2206451892852783e-01
    z[0,1,5]  R117      3.4362614154815674e-01
    z[0,1,5]  R118      2.6856040954589844e-01
    z[0,1,5]  R119      -2.2042410075664520e-01
    z[0,1,5]  R120      1.0946364700794220e-01
    z[0,1,5]  R121      -1.1709731072187424e-01
    z[0,1,5]  R122      6.2703627347946167e-01
    z[0,1,5]  R123      2.3887772858142853e-01
    z[0,1,5]  R124      2.0065395534038544e-01
    z[0,1,5]  R125      -2.8457227349281311e-01
    z[0,1,5]  R126      1.7556734383106232e-01
    z[0,1,5]  R127      5.7907629013061523e-01
    z[0,1,5]  R128      5.7281899452209473e-01
    z[0,1,5]  R129      1.8540093302726746e-01
    z[0,1,5]  R130      2.2422537207603455e-01
    z[0,1,5]  R131      -8.2233786582946777e-02
    z[0,1,5]  R132      -5.5447822809219360e-01
    z[0,1,5]  R133      2.4402387440204620e-02
    z[0,1,5]  R134      -3.6432299017906189e-01
    z[0,1,5]  R135      3.5972729325294495e-01
    z[0,1,5]  R136      -1.3474673032760620e-01
    z[0,1,5]  R137      4.1070944070816040e-01
    z[0,1,5]  R138      2.6845881342887878e-01
    z[0,1,5]  R139      -1.5600410103797913e-01
    z[0,1,5]  R140      1.5160793066024780e-01
    z[0,1,5]  R141      2.1437972784042358e-01
    z[0,1,5]  R142      4.8980495333671570e-01
    z[0,1,5]  R143      -7.4408024549484253e-02
    z[0,1,5]  R144      -2.1193774044513702e-01
    z[0,1,5]  R145      7.8503206372261047e-02
    z[0,1,5]  R146      3.9419022202491760e-01
    z[0,1,5]  R147      0.241140216588974
    z[0,1,5]  R148      -3.0998522415757179e-02
    z[0,1,5]  R149      0.0473196879029274
    z[0,1,5]  R150      7.3381590843200684e-01
    z[0,1,5]  R151      -6.0118723660707474e-02
    z[0,1,5]  R152      -5.0032156705856323e-01
    z[0,1,5]  R153      1.2722863256931305e-01
    z[0,1,5]  R154      -1.9989706575870514e-01
    z[0,1,5]  R155      4.3923646211624146e-02
    z[0,1,5]  R156      7.0017236471176147e-01
    z[0,1,5]  R157      1.4569871127605438e-01
    z[0,1,5]  R158      -1.4300954341888428e-01
    z[0,1,5]  R159      1.4630545675754547e-01
    z[0,1,5]  R160      -1.2696520984172821e-01
    z[0,1,5]  R161      2.1517179906368256e-01
    z[0,1,5]  R162      9.5603436231613159e-02
    z[0,1,5]  R163      -7.4994713068008423e-01
    z[0,1,5]  R164      -2.0519596338272095e-01
    z[0,1,5]  R165      6.0436416417360306e-02
    z[0,1,5]  R166      -4.9589961767196655e-01
    z[0,1,5]  R167      -8.8590532541275024e-02
    z[0,1,5]  R168      1.7978367209434509e-01
    z[0,1,5]  R169      4.7062897682189941e-01
    z[0,1,5]  R170      4.7685805708169937e-02
    z[0,1,5]  R171      -3.7317976355552673e-01
    z[0,1,5]  R172      -1.5483933687210083e-01
    z[0,1,5]  R173      -0.0720822662115097
    z[0,1,5]  R174      2.0726247131824493e-01
    z[0,1,5]  R175      6.4826227724552155e-02
    z[0,1,5]  R176      -3.6471477150917053e-01
    z[0,1,5]  R177      -1.2993569672107697e-01
    z[0,1,5]  R178      1.7994967103004456e-01
    z[0,1,5]  R179      3.3526977896690369e-01
    z[0,1,5]  R180      -9.7117766737937927e-02
    z[0,1,5]  R181      -2.2050876915454865e-01
    z[0,1,5]  R182      8.6020655930042267e-02
    z[0,1,5]  R183      5.7687617838382721e-02
    z[0,1,5]  R184      0.306393027305603
    z[0,1,5]  R185      4.8279735445976257e-01
    z[0,1,5]  R186      4.7796574234962463e-01
    z[0,1,5]  R187      -6.6919738054275513e-01
    z[0,1,5]  R188      -4.2582523822784424e-01
    z[0,1,5]  R189      -5.5297189950942993e-01
    z[0,1,5]  R190      -1.5411454439163208e-01
    z[0,1,5]  R191      3.0449718236923218e-01
    z[0,1,5]  R192      -1.1277583241462708e-01
    z[0,1,5]  R193      -7.4774503707885742e-01
    z[0,1,5]  R194      -6.0351870954036713e-02
    z[0,1,5]  R195      2.8867387771606445e-01
    z[0,1,5]  R196      3.3210732042789459e-02
    z[0,1,5]  R197      -2.9398688673973083e-01
    z[0,1,5]  R198      2.9158812761306763e-01
    z[0,1,5]  R199      3.6807906627655029e-01
    z[0,1,5]  R200      1.7831854522228241e-01
    z[0,1,5]  R201      -2.4189151823520660e-02
    z[0,1,5]  R202      3.1507951207458973e-03
    z[0,1,5]  R203      -9.9269665777683258e-02
    z[0,1,5]  R204      -5.3119486570358276e-01
    z[0,1,5]  R205      -7.1827238798141479e-01
    z[0,1,5]  R206      -4.0602588653564453e-01
    z[0,1,5]  R207      -0.578844428062439
    z[0,1,5]  R208      -2.2811302542686462e-01
    z[0,1,5]  R209      -4.8963002860546112e-02
    z[0,1,5]  R210      -1.6502182185649872e-01
    z[0,1,5]  R211      -6.3835185766220093e-01
    z[0,1,5]  R212      2.0172986388206482e-01
    z[0,1,5]  R213      1.1101662367582321e-01
    z[0,1,5]  R214      2.6964783668518066e-01
    z[0,1,6]  R8        -1
    z[0,1,6]  R17       1
    z[0,1,6]  R113      -1
    z[0,1,6]  R114      1
    z[0,1,6]  R115      -1.2756648659706116e-01
    z[0,1,6]  R116      8.4818363189697266e-02
    z[0,1,6]  R117      3.7218338251113892e-01
    z[0,1,6]  R118      -1.2677906453609467e-01
    z[0,1,6]  R119      -2.3077972233295441e-01
    z[0,1,6]  R120      -1.4685744047164917e-01
    z[0,1,6]  R121      -2.9190099239349365e-01
    z[0,1,6]  R122      2.4228583276271820e-01
    z[0,1,6]  R123      1.0840741544961929e-01
    z[0,1,6]  R124      -2.4150301516056061e-01
    z[0,1,6]  R125      2.9284858703613281e-01
    z[0,1,6]  R126      -1.7267785966396332e-01
    z[0,1,6]  R127      -2.2345557808876038e-01
    z[0,1,6]  R128      2.1690483391284943e-01
    z[0,1,6]  R129      6.6331011056900024e-01
    z[0,1,6]  R130      -5.7014679908752441e-01
    z[0,1,6]  R131      -7.0623534917831421e-01
    z[0,1,6]  R132      -0.342369943857193
    z[0,1,6]  R133      -2.2693943977355957e-01
    z[0,1,6]  R134      2.7805598452687263e-02
    z[0,1,6]  R135      3.2342830300331116e-01
    z[0,1,6]  R136      1.6324064135551453e-01
    z[0,1,6]  R137      -3.9405685663223267e-01
    z[0,1,6]  R138      2.8581345081329346e-01
    z[0,1,6]  R139      5.5778241157531738e-01
    z[0,1,6]  R140      -3.0908763408660889e-01
    z[0,1,6]  R141      -1.4259695308282971e-03
    z[0,1,6]  R142      -1.0526964440941811e-02
    z[0,1,6]  R143      4.6955081820487976e-01
    z[0,1,6]  R144      -2.4644516408443451e-02
    z[0,1,6]  R145      -4.0068548917770386e-01
    z[0,1,6]  R146      2.1922437474131584e-02
    z[0,1,6]  R147      -2.5409638881683350e-02
    z[0,1,6]  R148      7.4082213640213013e-01
    z[0,1,6]  R149      -2.0371438562870026e-01
    z[0,1,6]  R150      -0.0668964833021164
    z[0,1,6]  R151      0.053868368268013
    z[0,1,6]  R152      -2.0011919736862183e-01
    z[0,1,6]  R153      3.1985294818878174e-01
    z[0,1,6]  R154      4.3893656134605408e-01
    z[0,1,6]  R155      -1.8634347617626190e-01
    z[0,1,6]  R156      6.4604885876178741e-02
    z[0,1,6]  R157      2.1577186882495880e-01
    z[0,1,6]  R158      3.3691400289535522e-01
    z[0,1,6]  R159      3.5072332620620728e-01
    z[0,1,6]  R160      3.3503195643424988e-01
    z[0,1,6]  R161      -6.3178554177284241e-02
    z[0,1,6]  R162      5.2519404888153076e-01
    z[0,1,6]  R163      9.7945248708128929e-03
    z[0,1,6]  R164      1.9831065833568573e-01
    z[0,1,6]  R165      2.1922451257705688e-01
    z[0,1,6]  R166      -1.4156721532344818e-01
    z[0,1,6]  R167      3.7250018119812012e-01
    z[0,1,6]  R168      -1.6828449070453644e-01
    z[0,1,6]  R169      -4.0948797017335892e-02
    z[0,1,6]  R170      4.5295268297195435e-01
    z[0,1,6]  R171      -5.4676569998264313e-02
    z[0,1,6]  R172      -8.1497155129909515e-02
    z[0,1,6]  R173      8.0568544566631317e-02
    z[0,1,6]  R174      8.3461239933967590e-02
    z[0,1,6]  R175      -3.3042957074940205e-03
    z[0,1,6]  R176      -1.6233417391777039e-01
    z[0,1,6]  R177      2.0560391247272491e-01
    z[0,1,6]  R178      -1.4235657453536987e-01
    z[0,1,6]  R179      -2.6263710856437683e-01
    z[0,1,6]  R180      -2.2393219172954559e-01
    z[0,1,6]  R181      -2.4934880435466766e-01
    z[0,1,6]  R182      -2.0466949790716171e-02
    z[0,1,6]  R183      -1.0608077049255371e-01
    z[0,1,6]  R184      2.5520170107483864e-02
    z[0,1,6]  R185      6.1196144670248032e-02
    z[0,1,6]  R186      -1.9799458980560303e-01
    z[0,1,6]  R187      -1.6837205737829208e-02
    z[0,1,6]  R188      -2.9608628153800964e-01
    z[0,1,6]  R189      4.5811015367507935e-01
    z[0,1,6]  R190      5.9624046087265015e-01
    z[0,1,6]  R191      6.6907656192779541e-01
    z[0,1,6]  R192      -5.5441600084304810e-01
    z[0,1,6]  R193      -1.9777742028236389e-01
    z[0,1,6]  R194      -4.0725570917129517e-01
    z[0,1,6]  R195      3.9133498072624207e-01
    z[0,1,6]  R196      1.6450621187686920e-01
    z[0,1,6]  R197      5.8892941474914551e-01
    z[0,1,6]  R198      3.7337329983711243e-01
    z[0,1,6]  R199      2.2634324431419373e-01
    z[0,1,6]  R200      1.3039888441562653e-01
    z[0,1,6]  R201      4.8245757818222046e-01
    z[0,1,6]  R202      1.7120416462421417e-01
    z[0,1,6]  R203      -1.6910965740680695e-01
    z[0,1,6]  R204      5.0452504307031631e-02
    z[0,1,6]  R205      -1.5364871360361576e-02
    z[0,1,6]  R206      -5.8263218402862549e-01
    z[0,1,6]  R207      2.1156400442123413e-01
    z[0,1,6]  R208      -1.5903815627098083e-01
    z[0,1,6]  R209      -3.2536724209785461e-01
    z[0,1,6]  R210      -1.0116910934448242e-01
    z[0,1,6]  R211      1.5987172955647111e-03
    z[0,1,6]  R212      -2.2914621978998184e-02
    z[0,1,6]  R213      -1.2541098892688751e-01
    z[0,1,6]  R214      -2.0352834463119507e-01
    z[1,0,0]  R2        1
    z[1,0,0]  R11       -1
    z[1,0,0]  R215      -1
    z[1,0,0]  R216      1
    z[1,0,0]  R229      -1.3894502818584442e-01
    z[1,0,0]  R230      1.3602147996425629e-01
    z[1,0,0]  R231      -9.3008416891098022e-01
    z[1,0,0]  R232      -8.4046369791030884e-01
    z[1,0,0]  R233      -7.8733968734741211e-01
    z[1,0,0]  R234      -8.8880550861358643e-01
    z[1,0,0]  R235      -9.0660637617111206e-01
    z[1,0,0]  R236      -8.6132991313934326e-01
    z[1,0,0]  R237      -7.4839603900909424e-01
    z[1,0,0]  R238      -9.2447394132614136e-01
    z[1,0,0]  R239      -6.3099667429924011e-02
    z[1,0,0]  R240      4.1129431128501892e-01
    z[1,0,0]  R241      -3.1831058859825134e-01
    z[1,0,0]  R242      4.7566571831703186e-01
    z[1,0,0]  R243      -1.3901624083518982e-01
    z[1,0,0]  R244      -4.0207871794700623e-01
    z[1,0,0]  R245      3.2552149891853333e-01
    z[1,0,0]  R246      5.9157520532608032e-01
    z[1,0,0]  R247      8.1628121435642242e-02
    z[1,0,0]  R248      8.0147922039031982e-01
    z[1,0,0]  R249      -3.5144484043121338e-01
    z[1,0,0]  R250      -1.4187182486057281e-01
    z[1,0,0]  R251      2.7030315995216370e-01
    z[1,0,0]  R252      2.3140832781791687e-02
    z[1,0,0]  R253      8.6315566301345825e-01
    z[1,0,0]  R254      8.6348617076873779e-01
    z[1,0,0]  R255      8.1512153148651123e-01
    z[1,0,0]  R256      8.0033266544342041e-01
    z[1,0,0]  R257      7.6406925916671753e-01
    z[1,0,0]  R258      0.789068341255188
    z[1,0,0]  R259      4.6590375900268555e-01
    z[1,0,0]  R260      1.5367440879344940e-01
    z[1,0,0]  R261      3.1646621227264404e-01
    z[1,0,0]  R262      5.1167792081832886e-01
    z[1,0,0]  R263      -5.7876616716384888e-01
    z[1,0,0]  R264      9.7735965251922607e-01
    z[1,0,0]  R265      -5.6773281097412109e-01
    z[1,0,0]  R266      -1.3762372732162476e-01
    z[1,0,0]  R267      2.2838750854134560e-02
    z[1,0,0]  R268      2.4538686871528625e-01
    z[1,0,0]  R269      -6.9029080867767334e-01
    z[1,0,0]  R270      -4.7948607802391052e-01
    z[1,0,0]  R271      -3.6352571845054626e-01
    z[1,0,0]  R272      3.1492796540260315e-01
    z[1,0,0]  R273      -6.8361979722976685e-01
    z[1,0,0]  R274      -3.9291390776634216e-01
    z[1,0,0]  R275      -6.2230610847473145e-01
    z[1,0,0]  R276      4.3786278367042542e-01
    z[1,0,0]  R277      -9.7427040338516235e-02
    z[1,0,0]  R278      3.1236737966537476e-01
    z[1,0,0]  R279      6.8013924360275269e-01
    z[1,0,0]  R280      5.9047341346740723e-01
    z[1,0,0]  R281      4.2939627170562744e-01
    z[1,0,0]  R282      2.4498873949050903e-01
    z[1,0,0]  R283      5.3376400470733643e-01
    z[1,0,0]  R284      4.9152234196662903e-01
    z[1,0,0]  R285      0.437198281288147
    z[1,0,0]  R286      4.2546495795249939e-01
    z[1,0,0]  R287      4.9120023846626282e-01
    z[1,0,0]  R288      6.6296797990798950e-01
    z[1,0,0]  R289      6.9182682037353516e-01
    z[1,0,0]  R290      8.6664527654647827e-01
    z[1,0,0]  R291      4.6247753500938416e-01
    z[1,0,0]  R292      4.8343020677566528e-01
    z[1,0,0]  R293      3.7243533134460449e-01
    z[1,0,0]  R294      -2.7585852146148682e-01
    z[1,0,0]  R295      -5.0596201419830322e-01
    z[1,0,0]  R296      -2.4157655239105225e-01
    z[1,0,0]  R297      1.1826107278466225e-02
    z[1,0,0]  R298      -8.6852979660034180e-01
    z[1,0,0]  R299      5.3969722986221313e-01
    z[1,0,0]  R300      7.3571568727493286e-01
    z[1,0,0]  R301      3.1171849370002747e-01
    z[1,0,0]  R302      5.9647589921951294e-01
    z[1,0,0]  R303      4.7417908906936646e-01
    z[1,0,0]  R304      3.1378906965255737e-01
    z[1,0,0]  R305      -2.1871018409729004e-01
    z[1,0,0]  R306      1.9904276728630066e-01
    z[1,0,0]  R307      -8.0036675930023193e-01
    z[1,0,0]  R308      -6.4029139280319214e-01
    z[1,0,0]  R309      7.1646350622177124e-01
    z[1,0,0]  R310      1.7705178260803223e-01
    z[1,0,0]  R311      -2.1720215678215027e-01
    z[1,0,0]  R312      8.9121591299772263e-03
    z[1,0,0]  R313      -5.6046193838119507e-01
    z[1,0,0]  R314      -5.5888706445693970e-01
    z[1,0,0]  R315      -4.9922522902488708e-01
    z[1,0,0]  R316      -6.4466184377670288e-01
    z[1,0,0]  R317      -4.9271151423454285e-01
    z[1,0,0]  R318      -3.0665445327758789e-01
    z[1,0,0]  R319      3.5255894064903259e-01
    z[1,0,0]  R320      2.5943002104759216e-01
    z[1,0,0]  R321      -5.9411031007766724e-01
    z[1,0,0]  R322      -7.7178573608398438e-01
    z[1,0,0]  R323      -0.617535412311554
    z[1,0,0]  R324      -0.663107693195343
    z[1,0,0]  R325      -4.2091947793960571e-01
    z[1,0,0]  R326      1.9382099807262421e-01
    z[1,0,0]  R327      1.1183512210845947e-01
    z[1,0,0]  R328      2.4639831483364105e-01
    z[1,0,1]  R3        1
    z[1,0,1]  R12       -1
    z[1,0,1]  R217      -1
    z[1,0,1]  R218      1
    z[1,0,1]  R229      4.5714911073446274e-02
    z[1,0,1]  R230      9.5595233142375946e-02
    z[1,0,1]  R231      -1.5452742576599121e-01
    z[1,0,1]  R232      -3.0428934097290039e-01
    z[1,0,1]  R233      -1.7054866254329681e-01
    z[1,0,1]  R234      -2.4879324436187744e-01
    z[1,0,1]  R235      -2.3625767230987549e-01
    z[1,0,1]  R236      -2.0802576839923859e-01
    z[1,0,1]  R237      -2.8309798240661621e-01
    z[1,0,1]  R238      8.6726211011409760e-02
    z[1,0,1]  R239      6.4761382341384888e-01
    z[1,0,1]  R240      0.524172842502594
    z[1,0,1]  R241      4.9181440472602844e-01
    z[1,0,1]  R242      1.8394406139850616e-01
    z[1,0,1]  R243      1.9864578545093536e-01
    z[1,0,1]  R244      3.9298623800277710e-01
    z[1,0,1]  R245      4.8723950982093811e-01
    z[1,0,1]  R246      3.2236889004707336e-01
    z[1,0,1]  R247      1.7612237483263016e-02
    z[1,0,1]  R248      1.1396908015012741e-01
    z[1,0,1]  R249      6.6057032346725464e-01
    z[1,0,1]  R250      0.470954954624176
    z[1,0,1]  R251      4.3172460794448853e-01
    z[1,0,1]  R252      4.9238261580467224e-01
    z[1,0,1]  R253      1.4013834297657013e-01
    z[1,0,1]  R254      2.7400064468383789e-01
    z[1,0,1]  R255      1.6780835390090942e-01
    z[1,0,1]  R256      -4.7978889197111130e-02
    z[1,0,1]  R257      -2.1913725137710571e-01
    z[1,0,1]  R258      1.0546435415744781e-01
    z[1,0,1]  R259      2.3242063820362091e-01
    z[1,0,1]  R260      6.2136089801788330e-01
    z[1,0,1]  R261      5.8741199970245361e-01
    z[1,0,1]  R262      5.3919184207916260e-01
    z[1,0,1]  R263      3.9454418420791626e-01
    z[1,0,1]  R264      3.5307902842760086e-02
    z[1,0,1]  R265      3.3526644110679626e-02
    z[1,0,1]  R266      -9.3011397123336792e-01
    z[1,0,1]  R267      -9.3885004520416260e-01
    z[1,0,1]  R268      -8.6740863323211670e-01
    z[1,0,1]  R269      6.8876188993453979e-01
    z[1,0,1]  R270      5.5734479427337646e-01
    z[1,0,1]  R271      6.5846377611160278e-01
    z[1,0,1]  R272      -2.3913277685642242e-01
    z[1,0,1]  R273      3.0663841962814331e-01
    z[1,0,1]  R274      6.6253763437271118e-01
    z[1,0,1]  R275      3.6166846752166748e-01
    z[1,0,1]  R276      -4.9874192476272583e-01
    z[1,0,1]  R277      7.7765363454818726e-01
    z[1,0,1]  R278      -8.5132378339767456e-01
    z[1,0,1]  R279      -3.8043260574340820e-01
    z[1,0,1]  R280      -6.4856219291687012e-01
    z[1,0,1]  R281      -4.4086936116218567e-01
    z[1,0,1]  R282      -1.3169863820075989e-01
    z[1,0,1]  R283      -2.3086988925933838e-01
    z[1,0,1]  R284      -2.3843519389629364e-01
    z[1,0,1]  R285      -2.6134535670280457e-01
    z[1,0,1]  R286      -4.0785002708435059e-01
    z[1,0,1]  R287      -0.0882725715637207
    z[1,0,1]  R288      -1.3807876408100128e-01
    z[1,0,1]  R289      -3.0949419736862183e-01
    z[1,0,1]  R290      -1.7820264399051666e-01
    z[1,0,1]  R291      -3.8250735402107239e-01
    z[1,0,1]  R292      2.9533011838793755e-03
    z[1,0,1]  R293      -1.4792908728122711e-01
    z[1,0,1]  R294      -7.5608861446380615e-01
    z[1,0,1]  R295      -6.2702518701553345e-01
    z[1,0,1]  R296      6.7242813110351562e-01
    z[1,0,1]  R297      8.3544468879699707e-01
    z[1,0,1]  R298      -2.9309463500976562e-01
    z[1,0,1]  R299      -4.7128647565841675e-01
    z[1,0,1]  R300      -1.7082288861274719e-01
    z[1,0,1]  R301      -2.7031362056732178e-01
    z[1,0,1]  R302      -1.0288413614034653e-01
    z[1,0,1]  R303      -5.4447576403617859e-02
    z[1,0,1]  R304      4.7189202159643173e-02
    z[1,0,1]  R305      -5.4218143224716187e-01
    z[1,0,1]  R306      -2.1132104098796844e-01
    z[1,0,1]  R307      -1.0854940116405487e-01
    z[1,0,1]  R308      8.0984160304069519e-02
    z[1,0,1]  R309      -2.1249166131019592e-01
    z[1,0,1]  R310      -1.7520454525947571e-01
    z[1,0,1]  R311      -8.4995454549789429e-01
    z[1,0,1]  R312      -8.7925010919570923e-01
    z[1,0,1]  R313      1.9589031115174294e-02
    z[1,0,1]  R314      -3.1845444440841675e-01
    z[1,0,1]  R315      -4.0104719996452332e-01
    z[1,0,1]  R316      -2.9031151533126831e-01
    z[1,0,1]  R317      -2.0443591475486755e-01
    z[1,0,1]  R318      -7.5759190320968628e-01
    z[1,0,1]  R319      -1.7950202524662018e-01
    z[1,0,1]  R320      -3.3796465396881104e-01
    z[1,0,1]  R321      -2.9013815522193909e-01
    z[1,0,1]  R322      -2.6815903186798096e-01
    z[1,0,1]  R323      -1.3203978538513184e-01
    z[1,0,1]  R324      -2.8501585125923157e-01
    z[1,0,1]  R325      -7.5110089778900146e-01
    z[1,0,1]  R326      2.6301905512809753e-01
    z[1,0,1]  R327      0.227512925863266
    z[1,0,1]  R328      1.8195466697216034e-01
    z[1,0,2]  R4        1
    z[1,0,2]  R13       -1
    z[1,0,2]  R219      -1
    z[1,0,2]  R220      1
    z[1,0,2]  R229      -3.4589764475822449e-01
    z[1,0,2]  R230      6.7459084093570709e-02
    z[1,0,2]  R231      -3.8910549134016037e-02
    z[1,0,2]  R232      -2.6638289913535118e-02
    z[1,0,2]  R233      -4.0393546223640442e-01
    z[1,0,2]  R234      1.1216019839048386e-01
    z[1,0,2]  R235      8.4725886583328247e-02
    z[1,0,2]  R236      -2.9832099098712206e-03
    z[1,0,2]  R237      -2.7745479345321655e-01
    z[1,0,2]  R238      -3.1092030927538872e-02
    z[1,0,2]  R239      4.8684078454971313e-01
    z[1,0,2]  R240      -4.1123846173286438e-01
    z[1,0,2]  R241      2.3864111304283142e-01
    z[1,0,2]  R242      -2.2743576765060425e-01
    z[1,0,2]  R243      -5.5330187082290649e-01
    z[1,0,2]  R244      -4.2811136692762375e-02
    z[1,0,2]  R245      -6.3877038657665253e-02
    z[1,0,2]  R246      4.2054817080497742e-01
    z[1,0,2]  R247      -4.1802123188972473e-01
    z[1,0,2]  R248      8.6916297674179077e-02
    z[1,0,2]  R249      -1.8759422004222870e-01
    z[1,0,2]  R250      6.2493032217025757e-01
    z[1,0,2]  R251      1.5951023995876312e-01
    z[1,0,2]  R252      -3.9223572611808777e-01
    z[1,0,2]  R253      -1.4474473893642426e-02
    z[1,0,2]  R254      -0.140329509973526
    z[1,0,2]  R255      1.3617476820945740e-01
    z[1,0,2]  R256      -1.8472173810005188e-01
    z[1,0,2]  R257      2.9430523514747620e-01
    z[1,0,2]  R258      -6.5737059339880943e-03
    z[1,0,2]  R259      -3.7296712398529053e-01
    z[1,0,2]  R260      6.6249914467334747e-02
    z[1,0,2]  R261      2.2753553465008736e-02
    z[1,0,2]  R262      -2.7140554785728455e-01
    z[1,0,2]  R263      -2.4743634462356567e-01
    z[1,0,2]  R264      3.6267023533582687e-02
    z[1,0,2]  R265      -1.7865149676799774e-01
    z[1,0,2]  R266      1.5413431823253632e-01
    z[1,0,2]  R267      2.7333769202232361e-01
    z[1,0,2]  R268      2.0702511072158813e-01
    z[1,0,2]  R269      1.1417567729949951e-01
    z[1,0,2]  R270      -0.574375331401825
    z[1,0,2]  R271      -5.9017833322286606e-02
    z[1,0,2]  R272      -8.5726588964462280e-01
    z[1,0,2]  R273      -5.6133270263671875e-01
    z[1,0,2]  R274      -3.2849911600351334e-02
    z[1,0,2]  R275      -5.9648370742797852e-01
    z[1,0,2]  R276      7.4725419282913208e-02
    z[1,0,2]  R277      -2.9491904377937317e-01
    z[1,0,2]  R278      1.0105685144662857e-01
    z[1,0,2]  R279      2.7553543448448181e-01
    z[1,0,2]  R280      -4.1228145360946655e-01
    z[1,0,2]  R281      9.3121513724327087e-02
    z[1,0,2]  R282      4.8655167222023010e-01
    z[1,0,2]  R283      3.1604412198066711e-01
    z[1,0,2]  R284      -2.5727536529302597e-02
    z[1,0,2]  R285      1.7459660768508911e-01
    z[1,0,2]  R286      2.6592442393302917e-01
    z[1,0,2]  R287      -3.9491853117942810e-01
    z[1,0,2]  R288      -4.3716830015182495e-01
    z[1,0,2]  R289      -3.9838417433202267e-03
    z[1,0,2]  R290      -3.2771885395050049e-01
    z[1,0,2]  R291      3.0730563402175903e-01
    z[1,0,2]  R292      -7.7303111553192139e-01
    z[1,0,2]  R293      -0.675874650478363
    z[1,0,2]  R294      3.4612563252449036e-01
    z[1,0,2]  R295      0.34788778424263
    z[1,0,2]  R296      -4.6885243058204651e-01
    z[1,0,2]  R297      -1.5088966488838196e-01
    z[1,0,2]  R298      -9.6128843724727631e-02
    z[1,0,2]  R299      5.2127641439437866e-01
    z[1,0,2]  R300      -1.7546087503433228e-02
    z[1,0,2]  R301      7.1646285057067871e-01
    z[1,0,2]  R302      -9.8113827407360077e-02
    z[1,0,2]  R303      -7.1265298128128052e-01
    z[1,0,2]  R304      0.572374165058136
    z[1,0,2]  R305      1.8950580060482025e-01
    z[1,0,2]  R306      -7.4307578802108765e-01
    z[1,0,2]  R307      -1.7928022146224976e-01
    z[1,0,2]  R308      -3.9722275733947754e-01
    z[1,0,2]  R309      -5.4388207197189331e-01
    z[1,0,2]  R310      5.6201952695846558e-01
    z[1,0,2]  R311      -4.2331553995609283e-02
    z[1,0,2]  R312      8.4929078817367554e-02
    z[1,0,2]  R313      -5.8321011066436768e-01
    z[1,0,2]  R314      -5.6509381532669067e-01
    z[1,0,2]  R315      -6.0826295614242554e-01
    z[1,0,2]  R316      9.1853000223636627e-02
    z[1,0,2]  R317      2.4066691100597382e-01
    z[1,0,2]  R318      -1.8711318075656891e-01
    z[1,0,2]  R319      8.0392867326736450e-01
    z[1,0,2]  R320      6.3776248693466187e-01
    z[1,0,2]  R321      -5.3402411937713623e-01
    z[1,0,2]  R322      -1.8136838078498840e-01
    z[1,0,2]  R323      -5.2615791559219360e-01
    z[1,0,2]  R324      8.3538889884948730e-02
    z[1,0,2]  R325      -1.2947911024093628e-01
    z[1,0,2]  R326      2.0583336055278778e-01
    z[1,0,2]  R327      2.0269340276718140e-01
    z[1,0,2]  R328      1.9157193601131439e-01
    z[1,0,3]  R5        1
    z[1,0,3]  R14       -1
    z[1,0,3]  R221      -1
    z[1,0,3]  R222      1
    z[1,0,3]  R229      -9.1660672426223755e-01
    z[1,0,3]  R230      -8.1101936101913452e-01
    z[1,0,3]  R231      -4.3476864695549011e-02
    z[1,0,3]  R232      -1.2680803239345551e-01
    z[1,0,3]  R233      -7.1115955710411072e-02
    z[1,0,3]  R234      -2.5599592924118042e-01
    z[1,0,3]  R235      3.2942626625299454e-02
    z[1,0,3]  R236      -0.411723792552948
    z[1,0,3]  R237      -4.6243837475776672e-01
    z[1,0,3]  R238      -3.5735196433961391e-03
    z[1,0,3]  R239      -1.7720645666122437e-01
    z[1,0,3]  R240      -4.6511989086866379e-02
    z[1,0,3]  R241      1.3114874064922333e-01
    z[1,0,3]  R242      2.3564623668789864e-02
    z[1,0,3]  R243      1.1789546906948090e-01
    z[1,0,3]  R244      3.9691349864006042e-01
    z[1,0,3]  R245      2.0991069078445435e-01
    z[1,0,3]  R246      1.3820931315422058e-01
    z[1,0,3]  R247      1.0030884295701981e-01
    z[1,0,3]  R248      -1.2336043268442154e-01
    z[1,0,3]  R249      0.185865581035614
    z[1,0,3]  R250      3.3921965956687927e-01
    z[1,0,3]  R251      -2.6427122950553894e-01
    z[1,0,3]  R252      1.5687417984008789e-01
    z[1,0,3]  R253      1.2083962559700012e-01
    z[1,0,3]  R254      0.269723504781723
    z[1,0,3]  R255      -1.8055105209350586e-01
    z[1,0,3]  R256      3.8706335425376892e-01
    z[1,0,3]  R257      1.7415404319763184e-01
    z[1,0,3]  R258      -1.6753622889518738e-01
    z[1,0,3]  R259      -2.6583081483840942e-01
    z[1,0,3]  R260      1.6575561463832855e-01
    z[1,0,3]  R261      3.2966342568397522e-01
    z[1,0,3]  R262      5.3757125139236450e-01
    z[1,0,3]  R263      1.4396762847900391e-01
    z[1,0,3]  R264      0.0681452751159668
    z[1,0,3]  R265      -2.2184237837791443e-01
    z[1,0,3]  R266      1.6380879282951355e-01
    z[1,0,3]  R267      8.4882482886314392e-02
    z[1,0,3]  R268      1.5975062549114227e-01
    z[1,0,3]  R269      -0.0678451657295227
    z[1,0,3]  R270      -1.3548433780670166e-01
    z[1,0,3]  R271      -1.1063421517610550e-01
    z[1,0,3]  R272      -9.4647333025932312e-02
    z[1,0,3]  R273      1.0969156399369240e-02
    z[1,0,3]  R274      1.9984103739261627e-01
    z[1,0,3]  R275      4.2276620864868164e-02
    z[1,0,3]  R276      9.7874358296394348e-02
    z[1,0,3]  R277      -3.2411184906959534e-01
    z[1,0,3]  R278      2.3762327432632446e-01
    z[1,0,3]  R279      -2.5731608271598816e-01
    z[1,0,3]  R280      -8.6852097883820534e-03
    z[1,0,3]  R281      2.9908770322799683e-01
    z[1,0,3]  R282      0.393938809633255
    z[1,0,3]  R283      2.0770454406738281e-01
    z[1,0,3]  R284      -0.369414746761322
    z[1,0,3]  R285      -3.6439445614814758e-01
    z[1,0,3]  R286      -3.8094222545623779e-02
    z[1,0,3]  R287      1.3926652073860168e-01
    z[1,0,3]  R288      -9.5875173807144165e-02
    z[1,0,3]  R289      2.1542407572269440e-01
    z[1,0,3]  R290      -1.9525042176246643e-01
    z[1,0,3]  R291      -1.9396646320819855e-01
    z[1,0,3]  R292      -2.9219649732112885e-02
    z[1,0,3]  R293      -1.3671833276748657e-01
    z[1,0,3]  R294      2.2687381505966187e-01
    z[1,0,3]  R295      3.5593304038047791e-01
    z[1,0,3]  R296      5.0011351704597473e-02
    z[1,0,3]  R297      -1.1290618032217026e-01
    z[1,0,3]  R298      3.2332947850227356e-01
    z[1,0,3]  R299      4.1120469570159912e-02
    z[1,0,3]  R300      -2.9871767759323120e-01
    z[1,0,3]  R301      -1.4645922183990479e-01
    z[1,0,3]  R302      -1.4632616937160492e-01
    z[1,0,3]  R303      -2.7534502441994846e-04
    z[1,0,3]  R304      2.5992043316364288e-02
    z[1,0,3]  R305      0.542360246181488
    z[1,0,3]  R306      -2.6507434248924255e-01
    z[1,0,3]  R307      2.2793164849281311e-01
    z[1,0,3]  R308      3.4473106265068054e-01
    z[1,0,3]  R309      -0.0948726087808609
    z[1,0,3]  R310      3.2306537032127380e-01
    z[1,0,3]  R311      3.7537211179733276e-01
    z[1,0,3]  R312      2.6692369580268860e-01
    z[1,0,3]  R313      5.3066551685333252e-02
    z[1,0,3]  R314      1.3132546842098236e-01
    z[1,0,3]  R315      3.8658934831619263e-01
    z[1,0,3]  R316      3.2547989487648010e-01
    z[1,0,3]  R317      1.7181062698364258e-01
    z[1,0,3]  R318      -4.1411802172660828e-01
    z[1,0,3]  R319      -1.2294325232505798e-01
    z[1,0,3]  R320      -2.5055891275405884e-01
    z[1,0,3]  R321      3.5662662982940674e-01
    z[1,0,3]  R322      1.3685664534568787e-01
    z[1,0,3]  R323      2.9205927252769470e-01
    z[1,0,3]  R324      3.8362291455268860e-01
    z[1,0,3]  R325      -1.6145074367523193e-01
    z[1,0,3]  R326      -8.5773169994354248e-01
    z[1,0,3]  R327      -8.7036657333374023e-01
    z[1,0,3]  R328      -7.2870439291000366e-01
    z[1,0,4]  R6        1
    z[1,0,4]  R15       -1
    z[1,0,4]  R223      -1
    z[1,0,4]  R224      1
    z[1,0,4]  R229      1.2073950469493866e-01
    z[1,0,4]  R230      -3.8818454742431641e-01
    z[1,0,4]  R231      -2.2023659944534302e-01
    z[1,0,4]  R232      -0.362755686044693
    z[1,0,4]  R233      -3.7469755858182907e-02
    z[1,0,4]  R234      -1.0215345025062561e-01
    z[1,0,4]  R235      -5.6431770324707031e-02
    z[1,0,4]  R236      -1.9362926483154297e-01
    z[1,0,4]  R237      -2.3312574625015259e-01
    z[1,0,4]  R238      2.0571598410606384e-01
    z[1,0,4]  R239      2.6713365316390991e-01
    z[1,0,4]  R240      -3.4226661920547485e-01
    z[1,0,4]  R241      3.6679524183273315e-01
    z[1,0,4]  R242      6.4701634645462036e-01
    z[1,0,4]  R243      3.2485261559486389e-01
    z[1,0,4]  R244      3.8113960623741150e-01
    z[1,0,4]  R245      2.6097622513771057e-01
    z[1,0,4]  R246      1.7337530851364136e-01
    z[1,0,4]  R247      4.5824062824249268e-01
    z[1,0,4]  R248      3.9034643769264221e-01
    z[1,0,4]  R249      -3.6595097184181213e-01
    z[1,0,4]  R250      -4.7360396385192871e-01
    z[1,0,4]  R251      4.6043559908866882e-01
    z[1,0,4]  R252      0.595091700553894
    z[1,0,4]  R253      -1.8384316563606262e-01
    z[1,0,4]  R254      1.9511753320693970e-01
    z[1,0,4]  R255      -1.5140847861766815e-01
    z[1,0,4]  R256      -3.7934783101081848e-01
    z[1,0,4]  R257      -4.6128010749816895e-01
    z[1,0,4]  R258      2.3113496601581573e-01
    z[1,0,4]  R259      5.4704319685697556e-02
    z[1,0,4]  R260      2.3262333869934082e-01
    z[1,0,4]  R261      -2.5647675991058350e-01
    z[1,0,4]  R262      8.6517877876758575e-02
    z[1,0,4]  R263      5.6493538618087769e-01
    z[1,0,4]  R264      0.00974711962044239
    z[1,0,4]  R265      4.3350827693939209e-01
    z[1,0,4]  R266      1.5536113083362579e-01
    z[1,0,4]  R267      -8.9821442961692810e-02
    z[1,0,4]  R268      6.9815821945667267e-02
    z[1,0,4]  R269      -1.2120189517736435e-01
    z[1,0,4]  R270      -1.6644150018692017e-02
    z[1,0,4]  R271      -4.0243282914161682e-01
    z[1,0,4]  R272      -1.0758836567401886e-01
    z[1,0,4]  R273      -1.4688777923583984e-01
    z[1,0,4]  R274      5.7627922296524048e-01
    z[1,0,4]  R275      1.5947715938091278e-01
    z[1,0,4]  R276      -3.0412566661834717e-01
    z[1,0,4]  R277      -3.5344353318214417e-01
    z[1,0,4]  R278      1.1140636354684830e-01
    z[1,0,4]  R279      -2.8949698805809021e-01
    z[1,0,4]  R280      3.9010590407997370e-03
    z[1,0,4]  R281      3.7130358815193176e-01
    z[1,0,4]  R282      3.9439356327056885e-01
    z[1,0,4]  R283      2.1075166761875153e-01
    z[1,0,4]  R284      -4.3483439087867737e-01
    z[1,0,4]  R285      -2.6787722110748291e-01
    z[1,0,4]  R286      3.9472463726997375e-01
    z[1,0,4]  R287      7.2351747751235962e-01
    z[1,0,4]  R288      4.5562589168548584e-01
    z[1,0,4]  R289      3.8099324703216553e-01
    z[1,0,4]  R290      1.6383874416351318e-01
    z[1,0,4]  R291      -4.2869547009468079e-01
    z[1,0,4]  R292      1.1872775852680206e-01
    z[1,0,4]  R293      -1.6867731511592865e-01
    z[1,0,4]  R294      -2.4987480044364929e-01
    z[1,0,4]  R295      -2.3909607529640198e-01
    z[1,0,4]  R296      1.6473528742790222e-01
    z[1,0,4]  R297      2.0090369880199432e-01
    z[1,0,4]  R298      -2.1071296185255051e-02
    z[1,0,4]  R299      2.1560238301753998e-01
    z[1,0,4]  R300      -4.2910999059677124e-01
    z[1,0,4]  R301      -4.8600274324417114e-01
    z[1,0,4]  R302      -2.2981595993041992e-01
    z[1,0,4]  R303      4.6965587139129639e-01
    z[1,0,4]  R304      -1.6751392185688019e-01
    z[1,0,4]  R305      5.6711727380752563e-01
    z[1,0,4]  R306      -5.4128672927618027e-02
    z[1,0,4]  R307      -3.8084489107131958e-01
    z[1,0,4]  R308      2.7243146300315857e-01
    z[1,0,4]  R309      3.1633153557777405e-01
    z[1,0,4]  R310      1.5265546739101410e-01
    z[1,0,4]  R311      -1.4113360643386841e-01
    z[1,0,4]  R312      -1.2006637454032898e-01
    z[1,0,4]  R313      -4.4512525200843811e-01
    z[1,0,4]  R314      -3.4826430678367615e-01
    z[1,0,4]  R315      1.4216047525405884e-01
    z[1,0,4]  R316      3.1747040152549744e-01
    z[1,0,4]  R317      2.5590106844902039e-01
    z[1,0,4]  R318      2.0995254814624786e-01
    z[1,0,4]  R319      -3.6104434728622437e-01
    z[1,0,4]  R320      -2.8809291124343872e-01
    z[1,0,4]  R321      6.2319129705429077e-02
    z[1,0,4]  R322      -4.6922415494918823e-01
    z[1,0,4]  R323      -1.2612015008926392e-01
    z[1,0,4]  R324      3.4273722767829895e-01
    z[1,0,4]  R325      2.7127549052238464e-01
    z[1,0,4]  R326      2.9080295562744141e-01
    z[1,0,4]  R327      3.5414847731590271e-01
    z[1,0,4]  R328      5.3716570138931274e-01
    z[1,0,5]  R7        1
    z[1,0,5]  R16       -1
    z[1,0,5]  R225      -1
    z[1,0,5]  R226      1
    z[1,0,5]  R229      6.4826227724552155e-02
    z[1,0,5]  R230      -3.6471477150917053e-01
    z[1,0,5]  R231      -1.2993569672107697e-01
    z[1,0,5]  R232      1.7994967103004456e-01
    z[1,0,5]  R233      3.3526977896690369e-01
    z[1,0,5]  R234      -9.7117766737937927e-02
    z[1,0,5]  R235      -2.2050876915454865e-01
    z[1,0,5]  R236      8.6020655930042267e-02
    z[1,0,5]  R237      5.7687617838382721e-02
    z[1,0,5]  R238      0.306393027305603
    z[1,0,5]  R239      4.8279735445976257e-01
    z[1,0,5]  R240      4.7796574234962463e-01
    z[1,0,5]  R241      -6.6919738054275513e-01
    z[1,0,5]  R242      -4.2582523822784424e-01
    z[1,0,5]  R243      -5.5297189950942993e-01
    z[1,0,5]  R244      -1.5411454439163208e-01
    z[1,0,5]  R245      3.0449718236923218e-01
    z[1,0,5]  R246      -1.1277583241462708e-01
    z[1,0,5]  R247      -7.4774503707885742e-01
    z[1,0,5]  R248      -6.0351870954036713e-02
    z[1,0,5]  R249      2.8867387771606445e-01
    z[1,0,5]  R250      3.3210732042789459e-02
    z[1,0,5]  R251      -2.9398688673973083e-01
    z[1,0,5]  R252      2.9158812761306763e-01
    z[1,0,5]  R253      3.6807906627655029e-01
    z[1,0,5]  R254      1.7831854522228241e-01
    z[1,0,5]  R255      -2.4189151823520660e-02
    z[1,0,5]  R256      3.1507951207458973e-03
    z[1,0,5]  R257      -9.9269665777683258e-02
    z[1,0,5]  R258      -5.3119486570358276e-01
    z[1,0,5]  R259      -7.1827238798141479e-01
    z[1,0,5]  R260      -4.0602588653564453e-01
    z[1,0,5]  R261      -0.578844428062439
    z[1,0,5]  R262      -2.2811302542686462e-01
    z[1,0,5]  R263      -4.8963002860546112e-02
    z[1,0,5]  R264      -1.6502182185649872e-01
    z[1,0,5]  R265      -6.3835185766220093e-01
    z[1,0,5]  R266      2.0172986388206482e-01
    z[1,0,5]  R267      1.1101662367582321e-01
    z[1,0,5]  R268      2.6964783668518066e-01
    z[1,0,5]  R269      -2.2441111505031586e-02
    z[1,0,5]  R270      -3.2206451892852783e-01
    z[1,0,5]  R271      3.4362614154815674e-01
    z[1,0,5]  R272      2.6856040954589844e-01
    z[1,0,5]  R273      -2.2042410075664520e-01
    z[1,0,5]  R274      1.0946364700794220e-01
    z[1,0,5]  R275      -1.1709731072187424e-01
    z[1,0,5]  R276      6.2703627347946167e-01
    z[1,0,5]  R277      2.3887772858142853e-01
    z[1,0,5]  R278      2.0065395534038544e-01
    z[1,0,5]  R279      -2.8457227349281311e-01
    z[1,0,5]  R280      1.7556734383106232e-01
    z[1,0,5]  R281      5.7907629013061523e-01
    z[1,0,5]  R282      5.7281899452209473e-01
    z[1,0,5]  R283      1.8540093302726746e-01
    z[1,0,5]  R284      2.2422537207603455e-01
    z[1,0,5]  R285      -8.2233786582946777e-02
    z[1,0,5]  R286      -5.5447822809219360e-01
    z[1,0,5]  R287      2.4402387440204620e-02
    z[1,0,5]  R288      -3.6432299017906189e-01
    z[1,0,5]  R289      3.5972729325294495e-01
    z[1,0,5]  R290      -1.3474673032760620e-01
    z[1,0,5]  R291      4.1070944070816040e-01
    z[1,0,5]  R292      2.6845881342887878e-01
    z[1,0,5]  R293      -1.5600410103797913e-01
    z[1,0,5]  R294      1.5160793066024780e-01
    z[1,0,5]  R295      2.1437972784042358e-01
    z[1,0,5]  R296      4.8980495333671570e-01
    z[1,0,5]  R297      -7.4408024549484253e-02
    z[1,0,5]  R298      -2.1193774044513702e-01
    z[1,0,5]  R299      7.8503206372261047e-02
    z[1,0,5]  R300      3.9419022202491760e-01
    z[1,0,5]  R301      0.241140216588974
    z[1,0,5]  R302      -3.0998522415757179e-02
    z[1,0,5]  R303      0.0473196879029274
    z[1,0,5]  R304      7.3381590843200684e-01
    z[1,0,5]  R305      -6.0118723660707474e-02
    z[1,0,5]  R306      -5.0032156705856323e-01
    z[1,0,5]  R307      1.2722863256931305e-01
    z[1,0,5]  R308      -1.9989706575870514e-01
    z[1,0,5]  R309      4.3923646211624146e-02
    z[1,0,5]  R310      7.0017236471176147e-01
    z[1,0,5]  R311      1.4569871127605438e-01
    z[1,0,5]  R312      -1.4300954341888428e-01
    z[1,0,5]  R313      1.4630545675754547e-01
    z[1,0,5]  R314      -1.2696520984172821e-01
    z[1,0,5]  R315      2.1517179906368256e-01
    z[1,0,5]  R316      9.5603436231613159e-02
    z[1,0,5]  R317      -7.4994713068008423e-01
    z[1,0,5]  R318      -2.0519596338272095e-01
    z[1,0,5]  R319      6.0436416417360306e-02
    z[1,0,5]  R320      -4.9589961767196655e-01
    z[1,0,5]  R321      -8.8590532541275024e-02
    z[1,0,5]  R322      1.7978367209434509e-01
    z[1,0,5]  R323      4.7062897682189941e-01
    z[1,0,5]  R324      4.7685805708169937e-02
    z[1,0,5]  R325      -3.7317976355552673e-01
    z[1,0,5]  R326      -1.5483933687210083e-01
    z[1,0,5]  R327      -0.0720822662115097
    z[1,0,5]  R328      2.0726247131824493e-01
    z[1,0,6]  R8        1
    z[1,0,6]  R17       -1
    z[1,0,6]  R227      -1
    z[1,0,6]  R228      1
    z[1,0,6]  R229      -3.3042957074940205e-03
    z[1,0,6]  R230      -1.6233417391777039e-01
    z[1,0,6]  R231      2.0560391247272491e-01
    z[1,0,6]  R232      -1.4235657453536987e-01
    z[1,0,6]  R233      -2.6263710856437683e-01
    z[1,0,6]  R234      -2.2393219172954559e-01
    z[1,0,6]  R235      -2.4934880435466766e-01
    z[1,0,6]  R236      -2.0466949790716171e-02
    z[1,0,6]  R237      -1.0608077049255371e-01
    z[1,0,6]  R238      2.5520170107483864e-02
    z[1,0,6]  R239      6.1196144670248032e-02
    z[1,0,6]  R240      -1.9799458980560303e-01
    z[1,0,6]  R241      -1.6837205737829208e-02
    z[1,0,6]  R242      -2.9608628153800964e-01
    z[1,0,6]  R243      4.5811015367507935e-01
    z[1,0,6]  R244      5.9624046087265015e-01
    z[1,0,6]  R245      6.6907656192779541e-01
    z[1,0,6]  R246      -5.5441600084304810e-01
    z[1,0,6]  R247      -1.9777742028236389e-01
    z[1,0,6]  R248      -4.0725570917129517e-01
    z[1,0,6]  R249      3.9133498072624207e-01
    z[1,0,6]  R250      1.6450621187686920e-01
    z[1,0,6]  R251      5.8892941474914551e-01
    z[1,0,6]  R252      3.7337329983711243e-01
    z[1,0,6]  R253      2.2634324431419373e-01
    z[1,0,6]  R254      1.3039888441562653e-01
    z[1,0,6]  R255      4.8245757818222046e-01
    z[1,0,6]  R256      1.7120416462421417e-01
    z[1,0,6]  R257      -1.6910965740680695e-01
    z[1,0,6]  R258      5.0452504307031631e-02
    z[1,0,6]  R259      -1.5364871360361576e-02
    z[1,0,6]  R260      -5.8263218402862549e-01
    z[1,0,6]  R261      2.1156400442123413e-01
    z[1,0,6]  R262      -1.5903815627098083e-01
    z[1,0,6]  R263      -3.2536724209785461e-01
    z[1,0,6]  R264      -1.0116910934448242e-01
    z[1,0,6]  R265      1.5987172955647111e-03
    z[1,0,6]  R266      -2.2914621978998184e-02
    z[1,0,6]  R267      -1.2541098892688751e-01
    z[1,0,6]  R268      -2.0352834463119507e-01
    z[1,0,6]  R269      -1.2756648659706116e-01
    z[1,0,6]  R270      8.4818363189697266e-02
    z[1,0,6]  R271      3.7218338251113892e-01
    z[1,0,6]  R272      -1.2677906453609467e-01
    z[1,0,6]  R273      -2.3077972233295441e-01
    z[1,0,6]  R274      -1.4685744047164917e-01
    z[1,0,6]  R275      -2.9190099239349365e-01
    z[1,0,6]  R276      2.4228583276271820e-01
    z[1,0,6]  R277      1.0840741544961929e-01
    z[1,0,6]  R278      -2.4150301516056061e-01
    z[1,0,6]  R279      2.9284858703613281e-01
    z[1,0,6]  R280      -1.7267785966396332e-01
    z[1,0,6]  R281      -2.2345557808876038e-01
    z[1,0,6]  R282      2.1690483391284943e-01
    z[1,0,6]  R283      6.6331011056900024e-01
    z[1,0,6]  R284      -5.7014679908752441e-01
    z[1,0,6]  R285      -7.0623534917831421e-01
    z[1,0,6]  R286      -0.342369943857193
    z[1,0,6]  R287      -2.2693943977355957e-01
    z[1,0,6]  R288      2.7805598452687263e-02
    z[1,0,6]  R289      3.2342830300331116e-01
    z[1,0,6]  R290      1.6324064135551453e-01
    z[1,0,6]  R291      -3.9405685663223267e-01
    z[1,0,6]  R292      2.8581345081329346e-01
    z[1,0,6]  R293      5.5778241157531738e-01
    z[1,0,6]  R294      -3.0908763408660889e-01
    z[1,0,6]  R295      -1.4259695308282971e-03
    z[1,0,6]  R296      -1.0526964440941811e-02
    z[1,0,6]  R297      4.6955081820487976e-01
    z[1,0,6]  R298      -2.4644516408443451e-02
    z[1,0,6]  R299      -4.0068548917770386e-01
    z[1,0,6]  R300      2.1922437474131584e-02
    z[1,0,6]  R301      -2.5409638881683350e-02
    z[1,0,6]  R302      7.4082213640213013e-01
    z[1,0,6]  R303      -2.0371438562870026e-01
    z[1,0,6]  R304      -0.0668964833021164
    z[1,0,6]  R305      0.053868368268013
    z[1,0,6]  R306      -2.0011919736862183e-01
    z[1,0,6]  R307      3.1985294818878174e-01
    z[1,0,6]  R308      4.3893656134605408e-01
    z[1,0,6]  R309      -1.8634347617626190e-01
    z[1,0,6]  R310      6.4604885876178741e-02
    z[1,0,6]  R311      2.1577186882495880e-01
    z[1,0,6]  R312      3.3691400289535522e-01
    z[1,0,6]  R313      3.5072332620620728e-01
    z[1,0,6]  R314      3.3503195643424988e-01
    z[1,0,6]  R315      -6.3178554177284241e-02
    z[1,0,6]  R316      5.2519404888153076e-01
    z[1,0,6]  R317      9.7945248708128929e-03
    z[1,0,6]  R318      1.9831065833568573e-01
    z[1,0,6]  R319      2.1922451257705688e-01
    z[1,0,6]  R320      -1.4156721532344818e-01
    z[1,0,6]  R321      3.7250018119812012e-01
    z[1,0,6]  R322      -1.6828449070453644e-01
    z[1,0,6]  R323      -4.0948797017335892e-02
    z[1,0,6]  R324      4.5295268297195435e-01
    z[1,0,6]  R325      -5.4676569998264313e-02
    z[1,0,6]  R326      -8.1497155129909515e-02
    z[1,0,6]  R327      8.0568544566631317e-02
    z[1,0,6]  R328      8.3461239933967590e-02
    z[0,4,0]  R2        -1
    z[0,4,0]  R38       1
    z[0,4,0]  R329      -1
    z[0,4,0]  R330      1
    z[0,4,0]  R343      -6.9029080867767334e-01
    z[0,4,0]  R344      -4.7948607802391052e-01
    z[0,4,0]  R345      -3.6352571845054626e-01
    z[0,4,0]  R346      3.1492796540260315e-01
    z[0,4,0]  R347      -6.8361979722976685e-01
    z[0,4,0]  R348      -3.9291390776634216e-01
    z[0,4,0]  R349      -6.2230610847473145e-01
    z[0,4,0]  R350      4.3786278367042542e-01
    z[0,4,0]  R351      -9.7427040338516235e-02
    z[0,4,0]  R352      3.1236737966537476e-01
    z[0,4,0]  R353      6.8013924360275269e-01
    z[0,4,0]  R354      5.9047341346740723e-01
    z[0,4,0]  R355      4.2939627170562744e-01
    z[0,4,0]  R356      2.4498873949050903e-01
    z[0,4,0]  R357      5.3376400470733643e-01
    z[0,4,0]  R358      4.9152234196662903e-01
    z[0,4,0]  R359      0.437198281288147
    z[0,4,0]  R360      4.2546495795249939e-01
    z[0,4,0]  R361      4.9120023846626282e-01
    z[0,4,0]  R362      6.6296797990798950e-01
    z[0,4,0]  R363      6.9182682037353516e-01
    z[0,4,0]  R364      8.6664527654647827e-01
    z[0,4,0]  R365      4.6247753500938416e-01
    z[0,4,0]  R366      4.8343020677566528e-01
    z[0,4,0]  R367      3.7243533134460449e-01
    z[0,4,0]  R368      -2.7585852146148682e-01
    z[0,4,0]  R369      -5.0596201419830322e-01
    z[0,4,0]  R370      -2.4157655239105225e-01
    z[0,4,0]  R371      1.1826107278466225e-02
    z[0,4,0]  R372      -8.6852979660034180e-01
    z[0,4,0]  R373      5.3969722986221313e-01
    z[0,4,0]  R374      7.3571568727493286e-01
    z[0,4,0]  R375      3.1171849370002747e-01
    z[0,4,0]  R376      5.9647589921951294e-01
    z[0,4,0]  R377      4.7417908906936646e-01
    z[0,4,0]  R378      3.1378906965255737e-01
    z[0,4,0]  R379      -2.1871018409729004e-01
    z[0,4,0]  R380      1.9904276728630066e-01
    z[0,4,0]  R381      -8.0036675930023193e-01
    z[0,4,0]  R382      -6.4029139280319214e-01
    z[0,4,0]  R383      7.1646350622177124e-01
    z[0,4,0]  R384      1.7705178260803223e-01
    z[0,4,0]  R385      -2.1720215678215027e-01
    z[0,4,0]  R386      8.9121591299772263e-03
    z[0,4,0]  R387      -5.6046193838119507e-01
    z[0,4,0]  R388      -5.5888706445693970e-01
    z[0,4,0]  R389      -4.9922522902488708e-01
    z[0,4,0]  R390      -6.4466184377670288e-01
    z[0,4,0]  R391      -4.9271151423454285e-01
    z[0,4,0]  R392      -3.0665445327758789e-01
    z[0,4,0]  R393      3.5255894064903259e-01
    z[0,4,0]  R394      2.5943002104759216e-01
    z[0,4,0]  R395      -5.9411031007766724e-01
    z[0,4,0]  R396      -7.7178573608398438e-01
    z[0,4,0]  R397      -0.617535412311554
    z[0,4,0]  R398      -0.663107693195343
    z[0,4,0]  R399      -4.2091947793960571e-01
    z[0,4,0]  R400      1.9382099807262421e-01
    z[0,4,0]  R401      1.1183512210845947e-01
    z[0,4,0]  R402      2.4639831483364105e-01
    z[0,4,0]  R403      -9.5272815227508545e-01
    z[0,4,0]  R404      -6.5755039453506470e-01
    z[0,4,0]  R405      -7.4672192335128784e-01
    z[0,4,0]  R406      -5.6827926635742188e-01
    z[0,4,0]  R407      -0.697720468044281
    z[0,4,0]  R408      -8.0624312162399292e-01
    z[0,4,0]  R409      -7.0575207471847534e-01
    z[0,4,0]  R410      -7.9680454730987549e-01
    z[0,4,0]  R411      -6.2853616476058960e-01
    z[0,4,0]  R412      -6.3414430618286133e-01
    z[0,4,0]  R413      4.7217079997062683e-01
    z[0,4,0]  R414      4.8192718625068665e-01
    z[0,4,0]  R415      5.3638529777526855e-01
    z[0,4,0]  R416      5.5831915140151978e-01
    z[0,4,0]  R417      3.1635567545890808e-01
    z[0,4,0]  R418      3.6004063487052917e-01
    z[0,4,0]  R419      4.6988460421562195e-01
    z[0,4,0]  R420      4.5945248007774353e-01
    z[0,4,0]  R421      6.3387542963027954e-01
    z[0,4,0]  R422      7.6060456037521362e-01
    z[0,4,0]  R423      7.5892186164855957e-01
    z[0,4,0]  R424      8.2507163286209106e-01
    z[0,4,0]  R425      0.69380784034729
    z[0,4,0]  R426      7.7515572309494019e-01
    z[0,4,0]  R427      5.9738069772720337e-01
    z[0,4,0]  R428      4.7916504740715027e-01
    z[0,4,0]  R429      1.2520797550678253e-01
    z[0,4,0]  R430      0.694004237651825
    z[0,4,0]  R431      -1.4771226048469543e-01
    z[0,4,0]  R432      -3.7355810403823853e-02
    z[0,4,0]  R433      6.8568706512451172e-01
    z[0,4,0]  R434      7.5445693731307983e-01
    z[0,4,0]  R435      5.5920267105102539e-01
    z[0,4,0]  R436      4.9857971072196960e-01
    z[0,4,0]  R437      4.4080206751823425e-01
    z[0,4,0]  R438      5.3665673732757568e-01
    z[0,4,0]  R439      7.3393128812313080e-02
    z[0,4,0]  R440      6.6152709722518921e-01
    z[0,4,0]  R441      4.3288326263427734e-01
    z[0,4,0]  R442      -1.9117283821105957e-01
    z[0,4,0]  R443      9.3395346403121948e-01
    z[0,4,0]  R444      8.2453894615173340e-01
    z[0,4,0]  R445      6.0545265674591064e-01
    z[0,4,0]  R446      6.8986546993255615e-01
    z[0,4,0]  R447      5.1483350992202759e-01
    z[0,4,0]  R448      4.2101282626390457e-02
    z[0,4,0]  R449      7.5327016413211823e-02
    z[0,4,0]  R450      -1.8716026842594147e-01
    z[0,4,0]  R451      -2.4608166888356209e-02
    z[0,4,0]  R452      -1.4167489111423492e-01
    z[0,4,1]  R3        -1
    z[0,4,1]  R39       1
    z[0,4,1]  R331      -1
    z[0,4,1]  R332      1
    z[0,4,1]  R343      6.8876188993453979e-01
    z[0,4,1]  R344      5.5734479427337646e-01
    z[0,4,1]  R345      6.5846377611160278e-01
    z[0,4,1]  R346      -2.3913277685642242e-01
    z[0,4,1]  R347      3.0663841962814331e-01
    z[0,4,1]  R348      6.6253763437271118e-01
    z[0,4,1]  R349      3.6166846752166748e-01
    z[0,4,1]  R350      -4.9874192476272583e-01
    z[0,4,1]  R351      7.7765363454818726e-01
    z[0,4,1]  R352      -8.5132378339767456e-01
    z[0,4,1]  R353      -3.8043260574340820e-01
    z[0,4,1]  R354      -6.4856219291687012e-01
    z[0,4,1]  R355      -4.4086936116218567e-01
    z[0,4,1]  R356      -1.3169863820075989e-01
    z[0,4,1]  R357      -2.3086988925933838e-01
    z[0,4,1]  R358      -2.3843519389629364e-01
    z[0,4,1]  R359      -2.6134535670280457e-01
    z[0,4,1]  R360      -4.0785002708435059e-01
    z[0,4,1]  R361      -0.0882725715637207
    z[0,4,1]  R362      -1.3807876408100128e-01
    z[0,4,1]  R363      -3.0949419736862183e-01
    z[0,4,1]  R364      -1.7820264399051666e-01
    z[0,4,1]  R365      -3.8250735402107239e-01
    z[0,4,1]  R366      2.9533011838793755e-03
    z[0,4,1]  R367      -1.4792908728122711e-01
    z[0,4,1]  R368      -7.5608861446380615e-01
    z[0,4,1]  R369      -6.2702518701553345e-01
    z[0,4,1]  R370      6.7242813110351562e-01
    z[0,4,1]  R371      8.3544468879699707e-01
    z[0,4,1]  R372      -2.9309463500976562e-01
    z[0,4,1]  R373      -4.7128647565841675e-01
    z[0,4,1]  R374      -1.7082288861274719e-01
    z[0,4,1]  R375      -2.7031362056732178e-01
    z[0,4,1]  R376      -1.0288413614034653e-01
    z[0,4,1]  R377      -5.4447576403617859e-02
    z[0,4,1]  R378      4.7189202159643173e-02
    z[0,4,1]  R379      -5.4218143224716187e-01
    z[0,4,1]  R380      -2.1132104098796844e-01
    z[0,4,1]  R381      -1.0854940116405487e-01
    z[0,4,1]  R382      8.0984160304069519e-02
    z[0,4,1]  R383      -2.1249166131019592e-01
    z[0,4,1]  R384      -1.7520454525947571e-01
    z[0,4,1]  R385      -8.4995454549789429e-01
    z[0,4,1]  R386      -8.7925010919570923e-01
    z[0,4,1]  R387      1.9589031115174294e-02
    z[0,4,1]  R388      -3.1845444440841675e-01
    z[0,4,1]  R389      -4.0104719996452332e-01
    z[0,4,1]  R390      -2.9031151533126831e-01
    z[0,4,1]  R391      -2.0443591475486755e-01
    z[0,4,1]  R392      -7.5759190320968628e-01
    z[0,4,1]  R393      -1.7950202524662018e-01
    z[0,4,1]  R394      -3.3796465396881104e-01
    z[0,4,1]  R395      -2.9013815522193909e-01
    z[0,4,1]  R396      -2.6815903186798096e-01
    z[0,4,1]  R397      -1.3203978538513184e-01
    z[0,4,1]  R398      -2.8501585125923157e-01
    z[0,4,1]  R399      -7.5110089778900146e-01
    z[0,4,1]  R400      2.6301905512809753e-01
    z[0,4,1]  R401      0.227512925863266
    z[0,4,1]  R402      1.8195466697216034e-01
    z[0,4,1]  R403      2.3143243044614792e-02
    z[0,4,1]  R404      -0.0182262621819973
    z[0,4,1]  R405      -5.7639140635728836e-02
    z[0,4,1]  R406      -2.4348567426204681e-01
    z[0,4,1]  R407      -1.9047854840755463e-01
    z[0,4,1]  R408      -2.0784406363964081e-01
    z[0,4,1]  R409      1.7566837370395660e-02
    z[0,4,1]  R410      -2.8242090344429016e-01
    z[0,4,1]  R411      -2.1849890053272247e-01
    z[0,4,1]  R412      -2.5236135721206665e-01
    z[0,4,1]  R413      -2.2388954460620880e-01
    z[0,4,1]  R414      -3.6125013232231140e-01
    z[0,4,1]  R415      -2.9774361848831177e-01
    z[0,4,1]  R416      -4.0703916549682617e-01
    z[0,4,1]  R417      -1.4761309325695038e-01
    z[0,4,1]  R418      -7.2857493162155151e-01
    z[0,4,1]  R419      -1.8686607480049133e-01
    z[0,4,1]  R420      -2.0314499735832214e-01
    z[0,4,1]  R421      -2.7796500921249390e-01
    z[0,4,1]  R422      -2.6957890391349792e-01
    z[0,4,1]  R423      -2.6112228631973267e-01
    z[0,4,1]  R424      2.5459733605384827e-01
    z[0,4,1]  R425      -5.5696594715118408e-01
    z[0,4,1]  R426      -3.5624718666076660e-01
    z[0,4,1]  R427      -3.3118823170661926e-01
    z[0,4,1]  R428      1.8527182936668396e-01
    z[0,4,1]  R429      -8.8961702585220337e-01
    z[0,4,1]  R430      1.8973752856254578e-01
    z[0,4,1]  R431      -4.8082154989242554e-01
    z[0,4,1]  R432      9.8477828502655029e-01
    z[0,4,1]  R433      1.2013015151023865e-01
    z[0,4,1]  R434      -2.5330534577369690e-01
    z[0,4,1]  R435      -7.9348884522914886e-02
    z[0,4,1]  R436      -3.7134587764739990e-01
    z[0,4,1]  R437      -1.4715818688273430e-02
    z[0,4,1]  R438      -2.4932594597339630e-01
    z[0,4,1]  R439      -9.3254148960113525e-01
    z[0,4,1]  R440      1.9009114801883698e-01
    z[0,4,1]  R441      6.9467514753341675e-02
    z[0,4,1]  R442      -8.2899713516235352e-01
    z[0,4,1]  R443      -2.2529418766498566e-01
    z[0,4,1]  R444      -2.6308485865592957e-01
    z[0,4,1]  R445      -1.4774477481842041e-01
    z[0,4,1]  R446      9.8536713048815727e-03
    z[0,4,1]  R447      -2.4957950413227081e-01
    z[0,4,1]  R448      -0.924492597579956
    z[0,4,1]  R449      9.8405432701110840e-01
    z[0,4,1]  R450      9.2263603210449219e-01
    z[0,4,1]  R451      9.3988919258117676e-01
    z[0,4,1]  R452      9.3019974231719971e-01
    z[0,4,2]  R4        -1
    z[0,4,2]  R40       1
    z[0,4,2]  R333      -1
    z[0,4,2]  R334      1
    z[0,4,2]  R343      1.1417567729949951e-01
    z[0,4,2]  R344      -0.574375331401825
    z[0,4,2]  R345      -5.9017833322286606e-02
    z[0,4,2]  R346      -8.5726588964462280e-01
    z[0,4,2]  R347      -5.6133270263671875e-01
    z[0,4,2]  R348      -3.2849911600351334e-02
    z[0,4,2]  R349      -5.9648370742797852e-01
    z[0,4,2]  R350      7.4725419282913208e-02
    z[0,4,2]  R351      -2.9491904377937317e-01
    z[0,4,2]  R352      1.0105685144662857e-01
    z[0,4,2]  R353      2.7553543448448181e-01
    z[0,4,2]  R354      -4.1228145360946655e-01
    z[0,4,2]  R355      9.3121513724327087e-02
    z[0,4,2]  R356      4.8655167222023010e-01
    z[0,4,2]  R357      3.1604412198066711e-01
    z[0,4,2]  R358      -2.5727536529302597e-02
    z[0,4,2]  R359      1.7459660768508911e-01
    z[0,4,2]  R360      2.6592442393302917e-01
    z[0,4,2]  R361      -3.9491853117942810e-01
    z[0,4,2]  R362      -4.3716830015182495e-01
    z[0,4,2]  R363      -3.9838417433202267e-03
    z[0,4,2]  R364      -3.2771885395050049e-01
    z[0,4,2]  R365      3.0730563402175903e-01
    z[0,4,2]  R366      -7.7303111553192139e-01
    z[0,4,2]  R367      -0.675874650478363
    z[0,4,2]  R368      3.4612563252449036e-01
    z[0,4,2]  R369      0.34788778424263
    z[0,4,2]  R370      -4.6885243058204651e-01
    z[0,4,2]  R371      -1.5088966488838196e-01
    z[0,4,2]  R372      -9.6128843724727631e-02
    z[0,4,2]  R373      5.2127641439437866e-01
    z[0,4,2]  R374      -1.7546087503433228e-02
    z[0,4,2]  R375      7.1646285057067871e-01
    z[0,4,2]  R376      -9.8113827407360077e-02
    z[0,4,2]  R377      -7.1265298128128052e-01
    z[0,4,2]  R378      0.572374165058136
    z[0,4,2]  R379      1.8950580060482025e-01
    z[0,4,2]  R380      -7.4307578802108765e-01
    z[0,4,2]  R381      -1.7928022146224976e-01
    z[0,4,2]  R382      -3.9722275733947754e-01
    z[0,4,2]  R383      -5.4388207197189331e-01
    z[0,4,2]  R384      5.6201952695846558e-01
    z[0,4,2]  R385      -4.2331553995609283e-02
    z[0,4,2]  R386      8.4929078817367554e-02
    z[0,4,2]  R387      -5.8321011066436768e-01
    z[0,4,2]  R388      -5.6509381532669067e-01
    z[0,4,2]  R389      -6.0826295614242554e-01
    z[0,4,2]  R390      9.1853000223636627e-02
    z[0,4,2]  R391      2.4066691100597382e-01
    z[0,4,2]  R392      -1.8711318075656891e-01
    z[0,4,2]  R393      8.0392867326736450e-01
    z[0,4,2]  R394      6.3776248693466187e-01
    z[0,4,2]  R395      -5.3402411937713623e-01
    z[0,4,2]  R396      -1.8136838078498840e-01
    z[0,4,2]  R397      -5.2615791559219360e-01
    z[0,4,2]  R398      8.3538889884948730e-02
    z[0,4,2]  R399      -1.2947911024093628e-01
    z[0,4,2]  R400      2.0583336055278778e-01
    z[0,4,2]  R401      2.0269340276718140e-01
    z[0,4,2]  R402      1.9157193601131439e-01
    z[0,4,2]  R403      -1.3083437085151672e-01
    z[0,4,2]  R404      2.2364251315593719e-02
    z[0,4,2]  R405      1.8938867747783661e-01
    z[0,4,2]  R406      2.9510036110877991e-01
    z[0,4,2]  R407      2.1735161542892456e-01
    z[0,4,2]  R408      3.0615091323852539e-01
    z[0,4,2]  R409      0.246908500790596
    z[0,4,2]  R410      -1.1430247128009796e-01
    z[0,4,2]  R411      2.8599098324775696e-01
    z[0,4,2]  R412      2.8773880004882812e-01
    z[0,4,2]  R413      -4.3195471167564392e-01
    z[0,4,2]  R414      -4.9419918656349182e-01
    z[0,4,2]  R415      -1.1149150878190994e-01
    z[0,4,2]  R416      -3.0816671252250671e-01
    z[0,4,2]  R417      -6.4465612173080444e-01
    z[0,4,2]  R418      -9.4892911612987518e-02
    z[0,4,2]  R419      -5.4666769504547119e-01
    z[0,4,2]  R420      -2.1985243260860443e-01
    z[0,4,2]  R421      1.8002183735370636e-01
    z[0,4,2]  R422      2.0883961021900177e-01
    z[0,4,2]  R423      0.0620284229516983
    z[0,4,2]  R424      3.3178892731666565e-01
    z[0,4,2]  R425      -2.5202444195747375e-01
    z[0,4,2]  R426      -7.3056198656558990e-02
    z[0,4,2]  R427      2.6410454511642456e-01
    z[0,4,2]  R428      -1.9367748871445656e-02
    z[0,4,2]  R429      2.7567037940025330e-01
    z[0,4,2]  R430      5.5395156145095825e-02
    z[0,4,2]  R431      -3.5112449526786804e-01
    z[0,4,2]  R432      1.4774592593312263e-02
    z[0,4,2]  R433      -3.2486429810523987e-01
    z[0,4,2]  R434      -3.2689192891120911e-01
    z[0,4,2]  R435      -4.9133110046386719e-01
    z[0,4,2]  R436      -0.49920454621315
    z[0,4,2]  R437      -3.4168452024459839e-02
    z[0,4,2]  R438      -2.0973436534404755e-01
    z[0,4,2]  R439      -0.209557443857193
    z[0,4,2]  R440      -3.0824416875839233e-01
    z[0,4,2]  R441      4.1353002190589905e-02
    z[0,4,2]  R442      -1.6549435257911682e-01
    z[0,4,2]  R443      3.0575854703783989e-02
    z[0,4,2]  R444      1.6815306246280670e-01
    z[0,4,2]  R445      -3.1875157356262207e-01
    z[0,4,2]  R446      -1.3141167163848877e-01
    z[0,4,2]  R447      -4.8377791047096252e-01
    z[0,4,2]  R448      2.1243350580334663e-02
    z[0,4,2]  R449      -4.4571772217750549e-02
    z[0,4,2]  R450      7.3673419654369354e-02
    z[0,4,2]  R451      4.2845621705055237e-02
    z[0,4,2]  R452      2.4338749051094055e-01
    z[0,4,3]  R5        -1
    z[0,4,3]  R41       1
    z[0,4,3]  R335      -1
    z[0,4,3]  R336      1
    z[0,4,3]  R343      -0.0678451657295227
    z[0,4,3]  R344      -1.3548433780670166e-01
    z[0,4,3]  R345      -1.1063421517610550e-01
    z[0,4,3]  R346      -9.4647333025932312e-02
    z[0,4,3]  R347      1.0969156399369240e-02
    z[0,4,3]  R348      1.9984103739261627e-01
    z[0,4,3]  R349      4.2276620864868164e-02
    z[0,4,3]  R350      9.7874358296394348e-02
    z[0,4,3]  R351      -3.2411184906959534e-01
    z[0,4,3]  R352      2.3762327432632446e-01
    z[0,4,3]  R353      -2.5731608271598816e-01
    z[0,4,3]  R354      -8.6852097883820534e-03
    z[0,4,3]  R355      2.9908770322799683e-01
    z[0,4,3]  R356      0.393938809633255
    z[0,4,3]  R357      2.0770454406738281e-01
    z[0,4,3]  R358      -0.369414746761322
    z[0,4,3]  R359      -3.6439445614814758e-01
    z[0,4,3]  R360      -3.8094222545623779e-02
    z[0,4,3]  R361      1.3926652073860168e-01
    z[0,4,3]  R362      -9.5875173807144165e-02
    z[0,4,3]  R363      2.1542407572269440e-01
    z[0,4,3]  R364      -1.9525042176246643e-01
    z[0,4,3]  R365      -1.9396646320819855e-01
    z[0,4,3]  R366      -2.9219649732112885e-02
    z[0,4,3]  R367      -1.3671833276748657e-01
    z[0,4,3]  R368      2.2687381505966187e-01
    z[0,4,3]  R369      3.5593304038047791e-01
    z[0,4,3]  R370      5.0011351704597473e-02
    z[0,4,3]  R371      -1.1290618032217026e-01
    z[0,4,3]  R372      3.2332947850227356e-01
    z[0,4,3]  R373      4.1120469570159912e-02
    z[0,4,3]  R374      -2.9871767759323120e-01
    z[0,4,3]  R375      -1.4645922183990479e-01
    z[0,4,3]  R376      -1.4632616937160492e-01
    z[0,4,3]  R377      -2.7534502441994846e-04
    z[0,4,3]  R378      2.5992043316364288e-02
    z[0,4,3]  R379      0.542360246181488
    z[0,4,3]  R380      -2.6507434248924255e-01
    z[0,4,3]  R381      2.2793164849281311e-01
    z[0,4,3]  R382      3.4473106265068054e-01
    z[0,4,3]  R383      -0.0948726087808609
    z[0,4,3]  R384      3.2306537032127380e-01
    z[0,4,3]  R385      3.7537211179733276e-01
    z[0,4,3]  R386      2.6692369580268860e-01
    z[0,4,3]  R387      5.3066551685333252e-02
    z[0,4,3]  R388      1.3132546842098236e-01
    z[0,4,3]  R389      3.8658934831619263e-01
    z[0,4,3]  R390      3.2547989487648010e-01
    z[0,4,3]  R391      1.7181062698364258e-01
    z[0,4,3]  R392      -4.1411802172660828e-01
    z[0,4,3]  R393      -1.2294325232505798e-01
    z[0,4,3]  R394      -2.5055891275405884e-01
    z[0,4,3]  R395      3.5662662982940674e-01
    z[0,4,3]  R396      1.3685664534568787e-01
    z[0,4,3]  R397      2.9205927252769470e-01
    z[0,4,3]  R398      3.8362291455268860e-01
    z[0,4,3]  R399      -1.6145074367523193e-01
    z[0,4,3]  R400      -8.5773169994354248e-01
    z[0,4,3]  R401      -8.7036657333374023e-01
    z[0,4,3]  R402      -7.2870439291000366e-01
    z[0,4,3]  R403      1.9385917484760284e-01
    z[0,4,3]  R404      5.9133011102676392e-01
    z[0,4,3]  R405      5.2878916263580322e-01
    z[0,4,3]  R406      6.8688517808914185e-01
    z[0,4,3]  R407      2.6613193750381470e-01
    z[0,4,3]  R408      2.1375413239002228e-01
    z[0,4,3]  R409      3.1471309065818787e-01
    z[0,4,3]  R410      1.5877273678779602e-01
    z[0,4,3]  R411      4.8079448938369751e-01
    z[0,4,3]  R412      4.6509143710136414e-01
    z[0,4,3]  R413      -3.2676982879638672e-01
    z[0,4,3]  R414      2.9687242582440376e-02
    z[0,4,3]  R415      4.3849018216133118e-01
    z[0,4,3]  R416      -3.6967954039573669e-01
    z[0,4,3]  R417      -3.6924713850021362e-01
    z[0,4,3]  R418      2.6742484420537949e-02
    z[0,4,3]  R419      -5.3775870800018311e-01
    z[0,4,3]  R420      -4.3696826696395874e-01
    z[0,4,3]  R421      2.2469219565391541e-01
    z[0,4,3]  R422      3.9729416370391846e-01
    z[0,4,3]  R423      2.2414935752749443e-02
    z[0,4,3]  R424      2.4273928999900818e-01
    z[0,4,3]  R425      -3.1692928075790405e-01
    z[0,4,3]  R426      -1.5646527707576752e-01
    z[0,4,3]  R427      2.3036557435989380e-01
    z[0,4,3]  R428      -4.0395253896713257e-01
    z[0,4,3]  R429      2.2190262377262115e-01
    z[0,4,3]  R430      -3.8582831621170044e-01
    z[0,4,3]  R431      -6.2994945049285889e-01
    z[0,4,3]  R432      7.1100570261478424e-02
    z[0,4,3]  R433      1.2340092658996582e-01
    z[0,4,3]  R434      3.7269029766321182e-02
    z[0,4,3]  R435      -1.8431878089904785e-01
    z[0,4,3]  R436      -2.5028491020202637e-01
    z[0,4,3]  R437      -0.586895227432251
    z[0,4,3]  R438      -6.0425555706024170e-01
    z[0,4,3]  R439      2.6788461953401566e-02
    z[0,4,3]  R440      -6.0113370418548584e-01
    z[0,4,3]  R441      -4.2124190926551819e-01
    z[0,4,3]  R442      -0.409285306930542
    z[0,4,3]  R443      7.6864279806613922e-02
    z[0,4,3]  R444      -1.6593851149082184e-01
    z[0,4,3]  R445      -4.5895448327064514e-01
    z[0,4,3]  R446      -1.0087624192237854e-01
    z[0,4,3]  R447      -6.4555007219314575e-01
    z[0,4,3]  R448      2.0760118961334229e-01
    z[0,4,3]  R449      -1.0306254029273987e-01
    z[0,4,3]  R450      -2.0503188669681549e-01
    z[0,4,3]  R451      -4.0007106959819794e-02
    z[0,4,3]  R452      -1.8252540379762650e-02
    z[0,4,4]  R6        -1
    z[0,4,4]  R42       1
    z[0,4,4]  R337      -1
    z[0,4,4]  R338      1
    z[0,4,4]  R343      -1.2120189517736435e-01
    z[0,4,4]  R344      -1.6644150018692017e-02
    z[0,4,4]  R345      -4.0243282914161682e-01
    z[0,4,4]  R346      -1.0758836567401886e-01
    z[0,4,4]  R347      -1.4688777923583984e-01
    z[0,4,4]  R348      5.7627922296524048e-01
    z[0,4,4]  R349      1.5947715938091278e-01
    z[0,4,4]  R350      -3.0412566661834717e-01
    z[0,4,4]  R351      -3.5344353318214417e-01
    z[0,4,4]  R352      1.1140636354684830e-01
    z[0,4,4]  R353      -2.8949698805809021e-01
    z[0,4,4]  R354      3.9010590407997370e-03
    z[0,4,4]  R355      3.7130358815193176e-01
    z[0,4,4]  R356      3.9439356327056885e-01
    z[0,4,4]  R357      2.1075166761875153e-01
    z[0,4,4]  R358      -4.3483439087867737e-01
    z[0,4,4]  R359      -2.6787722110748291e-01
    z[0,4,4]  R360      3.9472463726997375e-01
    z[0,4,4]  R361      7.2351747751235962e-01
    z[0,4,4]  R362      4.5562589168548584e-01
    z[0,4,4]  R363      3.8099324703216553e-01
    z[0,4,4]  R364      1.6383874416351318e-01
    z[0,4,4]  R365      -4.2869547009468079e-01
    z[0,4,4]  R366      1.1872775852680206e-01
    z[0,4,4]  R367      -1.6867731511592865e-01
    z[0,4,4]  R368      -2.4987480044364929e-01
    z[0,4,4]  R369      -2.3909607529640198e-01
    z[0,4,4]  R370      1.6473528742790222e-01
    z[0,4,4]  R371      2.0090369880199432e-01
    z[0,4,4]  R372      -2.1071296185255051e-02
    z[0,4,4]  R373      2.1560238301753998e-01
    z[0,4,4]  R374      -4.2910999059677124e-01
    z[0,4,4]  R375      -4.8600274324417114e-01
    z[0,4,4]  R376      -2.2981595993041992e-01
    z[0,4,4]  R377      4.6965587139129639e-01
    z[0,4,4]  R378      -1.6751392185688019e-01
    z[0,4,4]  R379      5.6711727380752563e-01
    z[0,4,4]  R380      -5.4128672927618027e-02
    z[0,4,4]  R381      -3.8084489107131958e-01
    z[0,4,4]  R382      2.7243146300315857e-01
    z[0,4,4]  R383      3.1633153557777405e-01
    z[0,4,4]  R384      1.5265546739101410e-01
    z[0,4,4]  R385      -1.4113360643386841e-01
    z[0,4,4]  R386      -1.2006637454032898e-01
    z[0,4,4]  R387      -4.4512525200843811e-01
    z[0,4,4]  R388      -3.4826430678367615e-01
    z[0,4,4]  R389      1.4216047525405884e-01
    z[0,4,4]  R390      3.1747040152549744e-01
    z[0,4,4]  R391      2.5590106844902039e-01
    z[0,4,4]  R392      2.0995254814624786e-01
    z[0,4,4]  R393      -3.6104434728622437e-01
    z[0,4,4]  R394      -2.8809291124343872e-01
    z[0,4,4]  R395      6.2319129705429077e-02
    z[0,4,4]  R396      -4.6922415494918823e-01
    z[0,4,4]  R397      -1.2612015008926392e-01
    z[0,4,4]  R398      3.4273722767829895e-01
    z[0,4,4]  R399      2.7127549052238464e-01
    z[0,4,4]  R400      2.9080295562744141e-01
    z[0,4,4]  R401      3.5414847731590271e-01
    z[0,4,4]  R402      5.3716570138931274e-01
    z[0,4,4]  R403      1.7594453692436218e-01
    z[0,4,4]  R404      2.6468461751937866e-01
    z[0,4,4]  R405      -8.4509648382663727e-02
    z[0,4,4]  R406      1.7926141619682312e-01
    z[0,4,4]  R407      1.1906246095895767e-01
    z[0,4,4]  R408      -1.5413333475589752e-01
    z[0,4,4]  R409      2.1042092144489288e-01
    z[0,4,4]  R410      -1.7308202385902405e-01
    z[0,4,4]  R411      -2.1921980381011963e-01
    z[0,4,4]  R412      -1.5550107927992940e-03
    z[0,4,4]  R413      -1.2728112936019897e-01
    z[0,4,4]  R414      4.4021272659301758e-01
    z[0,4,4]  R415      3.7656059861183167e-01
    z[0,4,4]  R416      0.293820321559906
    z[0,4,4]  R417      2.9863053560256958e-01
    z[0,4,4]  R418      -1.9770273566246033e-01
    z[0,4,4]  R419      3.4514042735099792e-01
    z[0,4,4]  R420      3.7323823571205139e-01
    z[0,4,4]  R421      -3.2541158795356750e-01
    z[0,4,4]  R422      2.5673272088170052e-02
    z[0,4,4]  R423      -1.8125078082084656e-01
    z[0,4,4]  R424      1.7340712249279022e-01
    z[0,4,4]  R425      9.8382413387298584e-02
    z[0,4,4]  R426      3.0576035380363464e-01
    z[0,4,4]  R427      3.2145464420318604e-01
    z[0,4,4]  R428      1.4233171939849854e-01
    z[0,4,4]  R429      -2.2503726184368134e-01
    z[0,4,4]  R430      -2.6704880595207214e-01
    z[0,4,4]  R431      -3.6939030885696411e-01
    z[0,4,4]  R432      -1.3780309259891510e-01
    z[0,4,4]  R433      5.5130505561828613e-01
    z[0,4,4]  R434      3.3232355117797852e-01
    z[0,4,4]  R435      5.5513274669647217e-01
    z[0,4,4]  R436      3.6872851848602295e-01
    z[0,4,4]  R437      -3.5058757662773132e-01
    z[0,4,4]  R438      -2.2812278568744659e-01
    z[0,4,4]  R439      0.24508036673069
    z[0,4,4]  R440      9.6251070499420166e-02
    z[0,4,4]  R441      1.5524534881114960e-01
    z[0,4,4]  R442      -2.3286515474319458e-01
    z[0,4,4]  R443      6.7009791731834412e-02
    z[0,4,4]  R444      4.9650236964225769e-02
    z[0,4,4]  R445      3.7223309278488159e-01
    z[0,4,4]  R446      0.444194495677948
    z[0,4,4]  R447      7.9294638708233833e-03
    z[0,4,4]  R448      5.3112413734197617e-02
    z[0,4,4]  R449      1.0073860734701157e-01
    z[0,4,4]  R450      -1.8034411966800690e-01
    z[0,4,4]  R451      4.9704242497682571e-02
    z[0,4,4]  R452      -0.199087455868721
    z[0,4,5]  R7        -1
    z[0,4,5]  R43       1
    z[0,4,5]  R339      -1
    z[0,4,5]  R340      1
    z[0,4,5]  R343      -2.2441111505031586e-02
    z[0,4,5]  R344      -3.2206451892852783e-01
    z[0,4,5]  R345      3.4362614154815674e-01
    z[0,4,5]  R346      2.6856040954589844e-01
    z[0,4,5]  R347      -2.2042410075664520e-01
    z[0,4,5]  R348      1.0946364700794220e-01
    z[0,4,5]  R349      -1.1709731072187424e-01
    z[0,4,5]  R350      6.2703627347946167e-01
    z[0,4,5]  R351      2.3887772858142853e-01
    z[0,4,5]  R352      2.0065395534038544e-01
    z[0,4,5]  R353      -2.8457227349281311e-01
    z[0,4,5]  R354      1.7556734383106232e-01
    z[0,4,5]  R355      5.7907629013061523e-01
    z[0,4,5]  R356      5.7281899452209473e-01
    z[0,4,5]  R357      1.8540093302726746e-01
    z[0,4,5]  R358      2.2422537207603455e-01
    z[0,4,5]  R359      -8.2233786582946777e-02
    z[0,4,5]  R360      -5.5447822809219360e-01
    z[0,4,5]  R361      2.4402387440204620e-02
    z[0,4,5]  R362      -3.6432299017906189e-01
    z[0,4,5]  R363      3.5972729325294495e-01
    z[0,4,5]  R364      -1.3474673032760620e-01
    z[0,4,5]  R365      4.1070944070816040e-01
    z[0,4,5]  R366      2.6845881342887878e-01
    z[0,4,5]  R367      -1.5600410103797913e-01
    z[0,4,5]  R368      1.5160793066024780e-01
    z[0,4,5]  R369      2.1437972784042358e-01
    z[0,4,5]  R370      4.8980495333671570e-01
    z[0,4,5]  R371      -7.4408024549484253e-02
    z[0,4,5]  R372      -2.1193774044513702e-01
    z[0,4,5]  R373      7.8503206372261047e-02
    z[0,4,5]  R374      3.9419022202491760e-01
    z[0,4,5]  R375      0.241140216588974
    z[0,4,5]  R376      -3.0998522415757179e-02
    z[0,4,5]  R377      0.0473196879029274
    z[0,4,5]  R378      7.3381590843200684e-01
    z[0,4,5]  R379      -6.0118723660707474e-02
    z[0,4,5]  R380      -5.0032156705856323e-01
    z[0,4,5]  R381      1.2722863256931305e-01
    z[0,4,5]  R382      -1.9989706575870514e-01
    z[0,4,5]  R383      4.3923646211624146e-02
    z[0,4,5]  R384      7.0017236471176147e-01
    z[0,4,5]  R385      1.4569871127605438e-01
    z[0,4,5]  R386      -1.4300954341888428e-01
    z[0,4,5]  R387      1.4630545675754547e-01
    z[0,4,5]  R388      -1.2696520984172821e-01
    z[0,4,5]  R389      2.1517179906368256e-01
    z[0,4,5]  R390      9.5603436231613159e-02
    z[0,4,5]  R391      -7.4994713068008423e-01
    z[0,4,5]  R392      -2.0519596338272095e-01
    z[0,4,5]  R393      6.0436416417360306e-02
    z[0,4,5]  R394      -4.9589961767196655e-01
    z[0,4,5]  R395      -8.8590532541275024e-02
    z[0,4,5]  R396      1.7978367209434509e-01
    z[0,4,5]  R397      4.7062897682189941e-01
    z[0,4,5]  R398      4.7685805708169937e-02
    z[0,4,5]  R399      -3.7317976355552673e-01
    z[0,4,5]  R400      -1.5483933687210083e-01
    z[0,4,5]  R401      -0.0720822662115097
    z[0,4,5]  R402      2.0726247131824493e-01
    z[0,4,5]  R403      7.1452908217906952e-02
    z[0,4,5]  R404      3.5677134990692139e-01
    z[0,4,5]  R405      2.7081233263015747e-01
    z[0,4,5]  R406      1.2114244699478149e-01
    z[0,4,5]  R407      2.8844168782234192e-01
    z[0,4,5]  R408      -1.7791172862052917e-01
    z[0,4,5]  R409      -1.4570856094360352e-01
    z[0,4,5]  R410      -2.2133085131645203e-01
    z[0,4,5]  R411      -3.6881619691848755e-01
    z[0,4,5]  R412      -4.7811937332153320e-01
    z[0,4,5]  R413      3.1066227704286575e-02
    z[0,4,5]  R414      1.8571242690086365e-01
    z[0,4,5]  R415      -2.9998105764389038e-01
    z[0,4,5]  R416      0.337121844291687
    z[0,4,5]  R417      -2.7562108635902405e-01
    z[0,4,5]  R418      3.5566347837448120e-01
    z[0,4,5]  R419      -1.8380945920944214e-01
    z[0,4,5]  R420      -7.1242645382881165e-02
    z[0,4,5]  R421      -5.2340172231197357e-02
    z[0,4,5]  R422      2.8898137807846069e-01
    z[0,4,5]  R423      -3.9129644632339478e-01
    z[0,4,5]  R424      -0.0736314207315445
    z[0,4,5]  R425      1.8468746542930603e-01
    z[0,4,5]  R426      -2.2853343188762665e-01
    z[0,4,5]  R427      1.2016015499830246e-01
    z[0,4,5]  R428      -5.9180450439453125e-01
    z[0,4,5]  R429      -1.2782792747020721e-01
    z[0,4,5]  R430      5.0256609916687012e-01
    z[0,4,5]  R431      2.6800256967544556e-01
    z[0,4,5]  R432      -3.1151911243796349e-02
    z[0,4,5]  R433      -1.4227263629436493e-01
    z[0,4,5]  R434      1.1875028163194656e-01
    z[0,4,5]  R435      -2.9758533835411072e-01
    z[0,4,5]  R436      -3.4854629635810852e-01
    z[0,4,5]  R437      -5.7962417602539062e-01
    z[0,4,5]  R438      4.2994111776351929e-01
    z[0,4,5]  R439      1.0444504767656326e-01
    z[0,4,5]  R440      -2.2317662835121155e-01
    z[0,4,5]  R441      1.7396973073482513e-01
    z[0,4,5]  R442      4.5839063823223114e-02
    z[0,4,5]  R443      1.9528928399085999e-01
    z[0,4,5]  R444      -2.0145791769027710e-01
    z[0,4,5]  R445      1.7320029437541962e-02
    z[0,4,5]  R446      4.0903955698013306e-01
    z[0,4,5]  R447      9.8281085491180420e-02
    z[0,4,5]  R448      3.0730363726615906e-01
    z[0,4,5]  R449      5.3372409194707870e-02
    z[0,4,5]  R450      -1.8346744775772095e-01
    z[0,4,5]  R451      -3.3059573173522949e-01
    z[0,4,5]  R452      1.0094561427831650e-01
    z[0,4,6]  R8        -1
    z[0,4,6]  R44       1
    z[0,4,6]  R341      -1
    z[0,4,6]  R342      1
    z[0,4,6]  R343      -1.2756648659706116e-01
    z[0,4,6]  R344      8.4818363189697266e-02
    z[0,4,6]  R345      3.7218338251113892e-01
    z[0,4,6]  R346      -1.2677906453609467e-01
    z[0,4,6]  R347      -2.3077972233295441e-01
    z[0,4,6]  R348      -1.4685744047164917e-01
    z[0,4,6]  R349      -2.9190099239349365e-01
    z[0,4,6]  R350      2.4228583276271820e-01
    z[0,4,6]  R351      1.0840741544961929e-01
    z[0,4,6]  R352      -2.4150301516056061e-01
    z[0,4,6]  R353      2.9284858703613281e-01
    z[0,4,6]  R354      -1.7267785966396332e-01
    z[0,4,6]  R355      -2.2345557808876038e-01
    z[0,4,6]  R356      2.1690483391284943e-01
    z[0,4,6]  R357      6.6331011056900024e-01
    z[0,4,6]  R358      -5.7014679908752441e-01
    z[0,4,6]  R359      -7.0623534917831421e-01
    z[0,4,6]  R360      -0.342369943857193
    z[0,4,6]  R361      -2.2693943977355957e-01
    z[0,4,6]  R362      2.7805598452687263e-02
    z[0,4,6]  R363      3.2342830300331116e-01
    z[0,4,6]  R364      1.6324064135551453e-01
    z[0,4,6]  R365      -3.9405685663223267e-01
    z[0,4,6]  R366      2.8581345081329346e-01
    z[0,4,6]  R367      5.5778241157531738e-01
    z[0,4,6]  R368      -3.0908763408660889e-01
    z[0,4,6]  R369      -1.4259695308282971e-03
    z[0,4,6]  R370      -1.0526964440941811e-02
    z[0,4,6]  R371      4.6955081820487976e-01
    z[0,4,6]  R372      -2.4644516408443451e-02
    z[0,4,6]  R373      -4.0068548917770386e-01
    z[0,4,6]  R374      2.1922437474131584e-02
    z[0,4,6]  R375      -2.5409638881683350e-02
    z[0,4,6]  R376      7.4082213640213013e-01
    z[0,4,6]  R377      -2.0371438562870026e-01
    z[0,4,6]  R378      -0.0668964833021164
    z[0,4,6]  R379      0.053868368268013
    z[0,4,6]  R380      -2.0011919736862183e-01
    z[0,4,6]  R381      3.1985294818878174e-01
    z[0,4,6]  R382      4.3893656134605408e-01
    z[0,4,6]  R383      -1.8634347617626190e-01
    z[0,4,6]  R384      6.4604885876178741e-02
    z[0,4,6]  R385      2.1577186882495880e-01
    z[0,4,6]  R386      3.3691400289535522e-01
    z[0,4,6]  R387      3.5072332620620728e-01
    z[0,4,6]  R388      3.3503195643424988e-01
    z[0,4,6]  R389      -6.3178554177284241e-02
    z[0,4,6]  R390      5.2519404888153076e-01
    z[0,4,6]  R391      9.7945248708128929e-03
    z[0,4,6]  R392      1.9831065833568573e-01
    z[0,4,6]  R393      2.1922451257705688e-01
    z[0,4,6]  R394      -1.4156721532344818e-01
    z[0,4,6]  R395      3.7250018119812012e-01
    z[0,4,6]  R396      -1.6828449070453644e-01
    z[0,4,6]  R397      -4.0948797017335892e-02
    z[0,4,6]  R398      4.5295268297195435e-01
    z[0,4,6]  R399      -5.4676569998264313e-02
    z[0,4,6]  R400      -8.1497155129909515e-02
    z[0,4,6]  R401      8.0568544566631317e-02
    z[0,4,6]  R402      8.3461239933967590e-02
    z[0,4,6]  R403      -3.1818527728319168e-02
    z[0,4,6]  R404      1.4064137637615204e-01
    z[0,4,6]  R405      2.0764620602130890e-01
    z[0,4,6]  R406      -1.0985297709703445e-01
    z[0,4,6]  R407      -5.1133328676223755e-01
    z[0,4,6]  R408      -3.3458021283149719e-01
    z[0,4,6]  R409      -5.2544206380844116e-01
    z[0,4,6]  R410      4.1002756357192993e-01
    z[0,4,6]  R411      2.4528257548809052e-01
    z[0,4,6]  R412      -8.0440282821655273e-02
    z[0,4,6]  R413      6.4529007673263550e-01
    z[0,4,6]  R414      4.0478876233100891e-01
    z[0,4,6]  R415      4.3260720372200012e-01
    z[0,4,6]  R416      -3.0164131522178650e-01
    z[0,4,6]  R417      4.0131950378417969e-01
    z[0,4,6]  R418      4.0527349710464478e-01
    z[0,4,6]  R419      -5.7893428951501846e-02
    z[0,4,6]  R420      -6.0330498218536377e-01
    z[0,4,6]  R421      5.7394319772720337e-01
    z[0,4,6]  R422      2.5136026740074158e-01
    z[0,4,6]  R423      4.0686386823654175e-01
    z[0,4,6]  R424      -2.2347070276737213e-01
    z[0,4,6]  R425      -2.5894997641444206e-02
    z[0,4,6]  R426      -3.1094381213188171e-01
    z[0,4,6]  R427      -5.4116499423980713e-01
    z[0,4,6]  R428      -4.4947916269302368e-01
    z[0,4,6]  R429      -2.6228001341223717e-02
    z[0,4,6]  R430      -8.0857515335083008e-02
    z[0,4,6]  R431      1.3635386526584625e-01
    z[0,4,6]  R432      5.9855472296476364e-02
    z[0,4,6]  R433      2.6544073224067688e-01
    z[0,4,6]  R434      3.6584597826004028e-01
    z[0,4,6]  R435      0.0942707434296608
    z[0,4,6]  R436      2.1030361950397491e-01
    z[0,4,6]  R437      -3.1426653265953064e-02
    z[0,4,6]  R438      -0.0619150847196579
    z[0,4,6]  R439      -9.6823170781135559e-02
    z[0,4,6]  R440      -1.0391784459352493e-01
    z[0,4,6]  R441      -7.5780266523361206e-01
    z[0,4,6]  R442      -1.5807080268859863e-01
    z[0,4,6]  R443      1.6583777964115143e-01
    z[0,4,6]  R444      -3.8994929194450378e-01
    z[0,4,6]  R445      -4.0062373876571655e-01
    z[0,4,6]  R446      -3.6320978403091431e-01
    z[0,4,6]  R447      1.1026592552661896e-01
    z[0,4,6]  R448      -5.2296765148639679e-02
    z[0,4,6]  R449      1.8907051533460617e-02
    z[0,4,6]  R450      -7.9683875665068626e-03
    z[0,4,6]  R451      2.8325811028480530e-02
    z[0,4,6]  R452      -7.2527416050434113e-02
    z[4,0,0]  R2        1
    z[4,0,0]  R38       -1
    z[4,0,0]  R453      -1
    z[4,0,0]  R454      1
    z[4,0,0]  R467      -9.5272815227508545e-01
    z[4,0,0]  R468      -6.5755039453506470e-01
    z[4,0,0]  R469      -7.4672192335128784e-01
    z[4,0,0]  R470      -5.6827926635742188e-01
    z[4,0,0]  R471      -0.697720468044281
    z[4,0,0]  R472      -8.0624312162399292e-01
    z[4,0,0]  R473      -7.0575207471847534e-01
    z[4,0,0]  R474      -7.9680454730987549e-01
    z[4,0,0]  R475      -6.2853616476058960e-01
    z[4,0,0]  R476      -6.3414430618286133e-01
    z[4,0,0]  R477      4.7217079997062683e-01
    z[4,0,0]  R478      4.8192718625068665e-01
    z[4,0,0]  R479      5.3638529777526855e-01
    z[4,0,0]  R480      5.5831915140151978e-01
    z[4,0,0]  R481      3.1635567545890808e-01
    z[4,0,0]  R482      3.6004063487052917e-01
    z[4,0,0]  R483      4.6988460421562195e-01
    z[4,0,0]  R484      4.5945248007774353e-01
    z[4,0,0]  R485      6.3387542963027954e-01
    z[4,0,0]  R486      7.6060456037521362e-01
    z[4,0,0]  R487      7.5892186164855957e-01
    z[4,0,0]  R488      8.2507163286209106e-01
    z[4,0,0]  R489      0.69380784034729
    z[4,0,0]  R490      7.7515572309494019e-01
    z[4,0,0]  R491      5.9738069772720337e-01
    z[4,0,0]  R492      4.7916504740715027e-01
    z[4,0,0]  R493      1.2520797550678253e-01
    z[4,0,0]  R494      0.694004237651825
    z[4,0,0]  R495      -1.4771226048469543e-01
    z[4,0,0]  R496      -3.7355810403823853e-02
    z[4,0,0]  R497      6.8568706512451172e-01
    z[4,0,0]  R498      7.5445693731307983e-01
    z[4,0,0]  R499      5.5920267105102539e-01
    z[4,0,0]  R500      4.9857971072196960e-01
    z[4,0,0]  R501      4.4080206751823425e-01
    z[4,0,0]  R502      5.3665673732757568e-01
    z[4,0,0]  R503      7.3393128812313080e-02
    z[4,0,0]  R504      6.6152709722518921e-01
    z[4,0,0]  R505      4.3288326263427734e-01
    z[4,0,0]  R506      -1.9117283821105957e-01
    z[4,0,0]  R507      9.3395346403121948e-01
    z[4,0,0]  R508      8.2453894615173340e-01
    z[4,0,0]  R509      6.0545265674591064e-01
    z[4,0,0]  R510      6.8986546993255615e-01
    z[4,0,0]  R511      5.1483350992202759e-01
    z[4,0,0]  R512      4.2101282626390457e-02
    z[4,0,0]  R513      7.5327016413211823e-02
    z[4,0,0]  R514      -1.8716026842594147e-01
    z[4,0,0]  R515      -2.4608166888356209e-02
    z[4,0,0]  R516      -1.4167489111423492e-01
    z[4,0,0]  R517      -6.9029080867767334e-01
    z[4,0,0]  R518      -4.7948607802391052e-01
    z[4,0,0]  R519      -3.6352571845054626e-01
    z[4,0,0]  R520      3.1492796540260315e-01
    z[4,0,0]  R521      -6.8361979722976685e-01
    z[4,0,0]  R522      -3.9291390776634216e-01
    z[4,0,0]  R523      -6.2230610847473145e-01
    z[4,0,0]  R524      4.3786278367042542e-01
    z[4,0,0]  R525      -9.7427040338516235e-02
    z[4,0,0]  R526      3.1236737966537476e-01
    z[4,0,0]  R527      6.8013924360275269e-01
    z[4,0,0]  R528      5.9047341346740723e-01
    z[4,0,0]  R529      4.2939627170562744e-01
    z[4,0,0]  R530      2.4498873949050903e-01
    z[4,0,0]  R531      5.3376400470733643e-01
    z[4,0,0]  R532      4.9152234196662903e-01
    z[4,0,0]  R533      0.437198281288147
    z[4,0,0]  R534      4.2546495795249939e-01
    z[4,0,0]  R535      4.9120023846626282e-01
    z[4,0,0]  R536      6.6296797990798950e-01
    z[4,0,0]  R537      6.9182682037353516e-01
    z[4,0,0]  R538      8.6664527654647827e-01
    z[4,0,0]  R539      4.6247753500938416e-01
    z[4,0,0]  R540      4.8343020677566528e-01
    z[4,0,0]  R541      3.7243533134460449e-01
    z[4,0,0]  R542      -2.7585852146148682e-01
    z[4,0,0]  R543      -5.0596201419830322e-01
    z[4,0,0]  R544      -2.4157655239105225e-01
    z[4,0,0]  R545      1.1826107278466225e-02
    z[4,0,0]  R546      -8.6852979660034180e-01
    z[4,0,0]  R547      5.3969722986221313e-01
    z[4,0,0]  R548      7.3571568727493286e-01
    z[4,0,0]  R549      3.1171849370002747e-01
    z[4,0,0]  R550      5.9647589921951294e-01
    z[4,0,0]  R551      4.7417908906936646e-01
    z[4,0,0]  R552      3.1378906965255737e-01
    z[4,0,0]  R553      -2.1871018409729004e-01
    z[4,0,0]  R554      1.9904276728630066e-01
    z[4,0,0]  R555      -8.0036675930023193e-01
    z[4,0,0]  R556      -6.4029139280319214e-01
    z[4,0,0]  R557      7.1646350622177124e-01
    z[4,0,0]  R558      1.7705178260803223e-01
    z[4,0,0]  R559      -2.1720215678215027e-01
    z[4,0,0]  R560      8.9121591299772263e-03
    z[4,0,0]  R561      -5.6046193838119507e-01
    z[4,0,0]  R562      -5.5888706445693970e-01
    z[4,0,0]  R563      -4.9922522902488708e-01
    z[4,0,0]  R564      -6.4466184377670288e-01
    z[4,0,0]  R565      -4.9271151423454285e-01
    z[4,0,0]  R566      -3.0665445327758789e-01
    z[4,0,0]  R567      3.5255894064903259e-01
    z[4,0,0]  R568      2.5943002104759216e-01
    z[4,0,0]  R569      -5.9411031007766724e-01
    z[4,0,0]  R570      -7.7178573608398438e-01
    z[4,0,0]  R571      -0.617535412311554
    z[4,0,0]  R572      -0.663107693195343
    z[4,0,0]  R573      -4.2091947793960571e-01
    z[4,0,0]  R574      1.9382099807262421e-01
    z[4,0,0]  R575      1.1183512210845947e-01
    z[4,0,0]  R576      2.4639831483364105e-01
    z[4,0,1]  R3        1
    z[4,0,1]  R39       -1
    z[4,0,1]  R455      -1
    z[4,0,1]  R456      1
    z[4,0,1]  R467      2.3143243044614792e-02
    z[4,0,1]  R468      -0.0182262621819973
    z[4,0,1]  R469      -5.7639140635728836e-02
    z[4,0,1]  R470      -2.4348567426204681e-01
    z[4,0,1]  R471      -1.9047854840755463e-01
    z[4,0,1]  R472      -2.0784406363964081e-01
    z[4,0,1]  R473      1.7566837370395660e-02
    z[4,0,1]  R474      -2.8242090344429016e-01
    z[4,0,1]  R475      -2.1849890053272247e-01
    z[4,0,1]  R476      -2.5236135721206665e-01
    z[4,0,1]  R477      -2.2388954460620880e-01
    z[4,0,1]  R478      -3.6125013232231140e-01
    z[4,0,1]  R479      -2.9774361848831177e-01
    z[4,0,1]  R480      -4.0703916549682617e-01
    z[4,0,1]  R481      -1.4761309325695038e-01
    z[4,0,1]  R482      -7.2857493162155151e-01
    z[4,0,1]  R483      -1.8686607480049133e-01
    z[4,0,1]  R484      -2.0314499735832214e-01
    z[4,0,1]  R485      -2.7796500921249390e-01
    z[4,0,1]  R486      -2.6957890391349792e-01
    z[4,0,1]  R487      -2.6112228631973267e-01
    z[4,0,1]  R488      2.5459733605384827e-01
    z[4,0,1]  R489      -5.5696594715118408e-01
    z[4,0,1]  R490      -3.5624718666076660e-01
    z[4,0,1]  R491      -3.3118823170661926e-01
    z[4,0,1]  R492      1.8527182936668396e-01
    z[4,0,1]  R493      -8.8961702585220337e-01
    z[4,0,1]  R494      1.8973752856254578e-01
    z[4,0,1]  R495      -4.8082154989242554e-01
    z[4,0,1]  R496      9.8477828502655029e-01
    z[4,0,1]  R497      1.2013015151023865e-01
    z[4,0,1]  R498      -2.5330534577369690e-01
    z[4,0,1]  R499      -7.9348884522914886e-02
    z[4,0,1]  R500      -3.7134587764739990e-01
    z[4,0,1]  R501      -1.4715818688273430e-02
    z[4,0,1]  R502      -2.4932594597339630e-01
    z[4,0,1]  R503      -9.3254148960113525e-01
    z[4,0,1]  R504      1.9009114801883698e-01
    z[4,0,1]  R505      6.9467514753341675e-02
    z[4,0,1]  R506      -8.2899713516235352e-01
    z[4,0,1]  R507      -2.2529418766498566e-01
    z[4,0,1]  R508      -2.6308485865592957e-01
    z[4,0,1]  R509      -1.4774477481842041e-01
    z[4,0,1]  R510      9.8536713048815727e-03
    z[4,0,1]  R511      -2.4957950413227081e-01
    z[4,0,1]  R512      -0.924492597579956
    z[4,0,1]  R513      9.8405432701110840e-01
    z[4,0,1]  R514      9.2263603210449219e-01
    z[4,0,1]  R515      9.3988919258117676e-01
    z[4,0,1]  R516      9.3019974231719971e-01
    z[4,0,1]  R517      6.8876188993453979e-01
    z[4,0,1]  R518      5.5734479427337646e-01
    z[4,0,1]  R519      6.5846377611160278e-01
    z[4,0,1]  R520      -2.3913277685642242e-01
    z[4,0,1]  R521      3.0663841962814331e-01
    z[4,0,1]  R522      6.6253763437271118e-01
    z[4,0,1]  R523      3.6166846752166748e-01
    z[4,0,1]  R524      -4.9874192476272583e-01
    z[4,0,1]  R525      7.7765363454818726e-01
    z[4,0,1]  R526      -8.5132378339767456e-01
    z[4,0,1]  R527      -3.8043260574340820e-01
    z[4,0,1]  R528      -6.4856219291687012e-01
    z[4,0,1]  R529      -4.4086936116218567e-01
    z[4,0,1]  R530      -1.3169863820075989e-01
    z[4,0,1]  R531      -2.3086988925933838e-01
    z[4,0,1]  R532      -2.3843519389629364e-01
    z[4,0,1]  R533      -2.6134535670280457e-01
    z[4,0,1]  R534      -4.0785002708435059e-01
    z[4,0,1]  R535      -0.0882725715637207
    z[4,0,1]  R536      -1.3807876408100128e-01
    z[4,0,1]  R537      -3.0949419736862183e-01
    z[4,0,1]  R538      -1.7820264399051666e-01
    z[4,0,1]  R539      -3.8250735402107239e-01
    z[4,0,1]  R540      2.9533011838793755e-03
    z[4,0,1]  R541      -1.4792908728122711e-01
    z[4,0,1]  R542      -7.5608861446380615e-01
    z[4,0,1]  R543      -6.2702518701553345e-01
    z[4,0,1]  R544      6.7242813110351562e-01
    z[4,0,1]  R545      8.3544468879699707e-01
    z[4,0,1]  R546      -2.9309463500976562e-01
    z[4,0,1]  R547      -4.7128647565841675e-01
    z[4,0,1]  R548      -1.7082288861274719e-01
    z[4,0,1]  R549      -2.7031362056732178e-01
    z[4,0,1]  R550      -1.0288413614034653e-01
    z[4,0,1]  R551      -5.4447576403617859e-02
    z[4,0,1]  R552      4.7189202159643173e-02
    z[4,0,1]  R553      -5.4218143224716187e-01
    z[4,0,1]  R554      -2.1132104098796844e-01
    z[4,0,1]  R555      -1.0854940116405487e-01
    z[4,0,1]  R556      8.0984160304069519e-02
    z[4,0,1]  R557      -2.1249166131019592e-01
    z[4,0,1]  R558      -1.7520454525947571e-01
    z[4,0,1]  R559      -8.4995454549789429e-01
    z[4,0,1]  R560      -8.7925010919570923e-01
    z[4,0,1]  R561      1.9589031115174294e-02
    z[4,0,1]  R562      -3.1845444440841675e-01
    z[4,0,1]  R563      -4.0104719996452332e-01
    z[4,0,1]  R564      -2.9031151533126831e-01
    z[4,0,1]  R565      -2.0443591475486755e-01
    z[4,0,1]  R566      -7.5759190320968628e-01
    z[4,0,1]  R567      -1.7950202524662018e-01
    z[4,0,1]  R568      -3.3796465396881104e-01
    z[4,0,1]  R569      -2.9013815522193909e-01
    z[4,0,1]  R570      -2.6815903186798096e-01
    z[4,0,1]  R571      -1.3203978538513184e-01
    z[4,0,1]  R572      -2.8501585125923157e-01
    z[4,0,1]  R573      -7.5110089778900146e-01
    z[4,0,1]  R574      2.6301905512809753e-01
    z[4,0,1]  R575      0.227512925863266
    z[4,0,1]  R576      1.8195466697216034e-01
    z[4,0,2]  R4        1
    z[4,0,2]  R40       -1
    z[4,0,2]  R457      -1
    z[4,0,2]  R458      1
    z[4,0,2]  R467      -1.3083437085151672e-01
    z[4,0,2]  R468      2.2364251315593719e-02
    z[4,0,2]  R469      1.8938867747783661e-01
    z[4,0,2]  R470      2.9510036110877991e-01
    z[4,0,2]  R471      2.1735161542892456e-01
    z[4,0,2]  R472      3.0615091323852539e-01
    z[4,0,2]  R473      0.246908500790596
    z[4,0,2]  R474      -1.1430247128009796e-01
    z[4,0,2]  R475      2.8599098324775696e-01
    z[4,0,2]  R476      2.8773880004882812e-01
    z[4,0,2]  R477      -4.3195471167564392e-01
    z[4,0,2]  R478      -4.9419918656349182e-01
    z[4,0,2]  R479      -1.1149150878190994e-01
    z[4,0,2]  R480      -3.0816671252250671e-01
    z[4,0,2]  R481      -6.4465612173080444e-01
    z[4,0,2]  R482      -9.4892911612987518e-02
    z[4,0,2]  R483      -5.4666769504547119e-01
    z[4,0,2]  R484      -2.1985243260860443e-01
    z[4,0,2]  R485      1.8002183735370636e-01
    z[4,0,2]  R486      2.0883961021900177e-01
    z[4,0,2]  R487      0.0620284229516983
    z[4,0,2]  R488      3.3178892731666565e-01
    z[4,0,2]  R489      -2.5202444195747375e-01
    z[4,0,2]  R490      -7.3056198656558990e-02
    z[4,0,2]  R491      2.6410454511642456e-01
    z[4,0,2]  R492      -1.9367748871445656e-02
    z[4,0,2]  R493      2.7567037940025330e-01
    z[4,0,2]  R494      5.5395156145095825e-02
    z[4,0,2]  R495      -3.5112449526786804e-01
    z[4,0,2]  R496      1.4774592593312263e-02
    z[4,0,2]  R497      -3.2486429810523987e-01
    z[4,0,2]  R498      -3.2689192891120911e-01
    z[4,0,2]  R499      -4.9133110046386719e-01
    z[4,0,2]  R500      -0.49920454621315
    z[4,0,2]  R501      -3.4168452024459839e-02
    z[4,0,2]  R502      -2.0973436534404755e-01
    z[4,0,2]  R503      -0.209557443857193
    z[4,0,2]  R504      -3.0824416875839233e-01
    z[4,0,2]  R505      4.1353002190589905e-02
    z[4,0,2]  R506      -1.6549435257911682e-01
    z[4,0,2]  R507      3.0575854703783989e-02
    z[4,0,2]  R508      1.6815306246280670e-01
    z[4,0,2]  R509      -3.1875157356262207e-01
    z[4,0,2]  R510      -1.3141167163848877e-01
    z[4,0,2]  R511      -4.8377791047096252e-01
    z[4,0,2]  R512      2.1243350580334663e-02
    z[4,0,2]  R513      -4.4571772217750549e-02
    z[4,0,2]  R514      7.3673419654369354e-02
    z[4,0,2]  R515      4.2845621705055237e-02
    z[4,0,2]  R516      2.4338749051094055e-01
    z[4,0,2]  R517      1.1417567729949951e-01
    z[4,0,2]  R518      -0.574375331401825
    z[4,0,2]  R519      -5.9017833322286606e-02
    z[4,0,2]  R520      -8.5726588964462280e-01
    z[4,0,2]  R521      -5.6133270263671875e-01
    z[4,0,2]  R522      -3.2849911600351334e-02
    z[4,0,2]  R523      -5.9648370742797852e-01
    z[4,0,2]  R524      7.4725419282913208e-02
    z[4,0,2]  R525      -2.9491904377937317e-01
    z[4,0,2]  R526      1.0105685144662857e-01
    z[4,0,2]  R527      2.7553543448448181e-01
    z[4,0,2]  R528      -4.1228145360946655e-01
    z[4,0,2]  R529      9.3121513724327087e-02
    z[4,0,2]  R530      4.8655167222023010e-01
    z[4,0,2]  R531      3.1604412198066711e-01
    z[4,0,2]  R532      -2.5727536529302597e-02
    z[4,0,2]  R533      1.7459660768508911e-01
    z[4,0,2]  R534      2.6592442393302917e-01
    z[4,0,2]  R535      -3.9491853117942810e-01
    z[4,0,2]  R536      -4.3716830015182495e-01
    z[4,0,2]  R537      -3.9838417433202267e-03
    z[4,0,2]  R538      -3.2771885395050049e-01
    z[4,0,2]  R539      3.0730563402175903e-01
    z[4,0,2]  R540      -7.7303111553192139e-01
    z[4,0,2]  R541      -0.675874650478363
    z[4,0,2]  R542      3.4612563252449036e-01
    z[4,0,2]  R543      0.34788778424263
    z[4,0,2]  R544      -4.6885243058204651e-01
    z[4,0,2]  R545      -1.5088966488838196e-01
    z[4,0,2]  R546      -9.6128843724727631e-02
    z[4,0,2]  R547      5.2127641439437866e-01
    z[4,0,2]  R548      -1.7546087503433228e-02
    z[4,0,2]  R549      7.1646285057067871e-01
    z[4,0,2]  R550      -9.8113827407360077e-02
    z[4,0,2]  R551      -7.1265298128128052e-01
    z[4,0,2]  R552      0.572374165058136
    z[4,0,2]  R553      1.8950580060482025e-01
    z[4,0,2]  R554      -7.4307578802108765e-01
    z[4,0,2]  R555      -1.7928022146224976e-01
    z[4,0,2]  R556      -3.9722275733947754e-01
    z[4,0,2]  R557      -5.4388207197189331e-01
    z[4,0,2]  R558      5.6201952695846558e-01
    z[4,0,2]  R559      -4.2331553995609283e-02
    z[4,0,2]  R560      8.4929078817367554e-02
    z[4,0,2]  R561      -5.8321011066436768e-01
    z[4,0,2]  R562      -5.6509381532669067e-01
    z[4,0,2]  R563      -6.0826295614242554e-01
    z[4,0,2]  R564      9.1853000223636627e-02
    z[4,0,2]  R565      2.4066691100597382e-01
    z[4,0,2]  R566      -1.8711318075656891e-01
    z[4,0,2]  R567      8.0392867326736450e-01
    z[4,0,2]  R568      6.3776248693466187e-01
    z[4,0,2]  R569      -5.3402411937713623e-01
    z[4,0,2]  R570      -1.8136838078498840e-01
    z[4,0,2]  R571      -5.2615791559219360e-01
    z[4,0,2]  R572      8.3538889884948730e-02
    z[4,0,2]  R573      -1.2947911024093628e-01
    z[4,0,2]  R574      2.0583336055278778e-01
    z[4,0,2]  R575      2.0269340276718140e-01
    z[4,0,2]  R576      1.9157193601131439e-01
    z[4,0,3]  R5        1
    z[4,0,3]  R41       -1
    z[4,0,3]  R459      -1
    z[4,0,3]  R460      1
    z[4,0,3]  R467      1.9385917484760284e-01
    z[4,0,3]  R468      5.9133011102676392e-01
    z[4,0,3]  R469      5.2878916263580322e-01
    z[4,0,3]  R470      6.8688517808914185e-01
    z[4,0,3]  R471      2.6613193750381470e-01
    z[4,0,3]  R472      2.1375413239002228e-01
    z[4,0,3]  R473      3.1471309065818787e-01
    z[4,0,3]  R474      1.5877273678779602e-01
    z[4,0,3]  R475      4.8079448938369751e-01
    z[4,0,3]  R476      4.6509143710136414e-01
    z[4,0,3]  R477      -3.2676982879638672e-01
    z[4,0,3]  R478      2.9687242582440376e-02
    z[4,0,3]  R479      4.3849018216133118e-01
    z[4,0,3]  R480      -3.6967954039573669e-01
    z[4,0,3]  R481      -3.6924713850021362e-01
    z[4,0,3]  R482      2.6742484420537949e-02
    z[4,0,3]  R483      -5.3775870800018311e-01
    z[4,0,3]  R484      -4.3696826696395874e-01
    z[4,0,3]  R485      2.2469219565391541e-01
    z[4,0,3]  R486      3.9729416370391846e-01
    z[4,0,3]  R487      2.2414935752749443e-02
    z[4,0,3]  R488      2.4273928999900818e-01
    z[4,0,3]  R489      -3.1692928075790405e-01
    z[4,0,3]  R490      -1.5646527707576752e-01
    z[4,0,3]  R491      2.3036557435989380e-01
    z[4,0,3]  R492      -4.0395253896713257e-01
    z[4,0,3]  R493      2.2190262377262115e-01
    z[4,0,3]  R494      -3.8582831621170044e-01
    z[4,0,3]  R495      -6.2994945049285889e-01
    z[4,0,3]  R496      7.1100570261478424e-02
    z[4,0,3]  R497      1.2340092658996582e-01
    z[4,0,3]  R498      3.7269029766321182e-02
    z[4,0,3]  R499      -1.8431878089904785e-01
    z[4,0,3]  R500      -2.5028491020202637e-01
    z[4,0,3]  R501      -0.586895227432251
    z[4,0,3]  R502      -6.0425555706024170e-01
    z[4,0,3]  R503      2.6788461953401566e-02
    z[4,0,3]  R504      -6.0113370418548584e-01
    z[4,0,3]  R505      -4.2124190926551819e-01
    z[4,0,3]  R506      -0.409285306930542
    z[4,0,3]  R507      7.6864279806613922e-02
    z[4,0,3]  R508      -1.6593851149082184e-01
    z[4,0,3]  R509      -4.5895448327064514e-01
    z[4,0,3]  R510      -1.0087624192237854e-01
    z[4,0,3]  R511      -6.4555007219314575e-01
    z[4,0,3]  R512      2.0760118961334229e-01
    z[4,0,3]  R513      -1.0306254029273987e-01
    z[4,0,3]  R514      -2.0503188669681549e-01
    z[4,0,3]  R515      -4.0007106959819794e-02
    z[4,0,3]  R516      -1.8252540379762650e-02
    z[4,0,3]  R517      -0.0678451657295227
    z[4,0,3]  R518      -1.3548433780670166e-01
    z[4,0,3]  R519      -1.1063421517610550e-01
    z[4,0,3]  R520      -9.4647333025932312e-02
    z[4,0,3]  R521      1.0969156399369240e-02
    z[4,0,3]  R522      1.9984103739261627e-01
    z[4,0,3]  R523      4.2276620864868164e-02
    z[4,0,3]  R524      9.7874358296394348e-02
    z[4,0,3]  R525      -3.2411184906959534e-01
    z[4,0,3]  R526      2.3762327432632446e-01
    z[4,0,3]  R527      -2.5731608271598816e-01
    z[4,0,3]  R528      -8.6852097883820534e-03
    z[4,0,3]  R529      2.9908770322799683e-01
    z[4,0,3]  R530      0.393938809633255
    z[4,0,3]  R531      2.0770454406738281e-01
    z[4,0,3]  R532      -0.369414746761322
    z[4,0,3]  R533      -3.6439445614814758e-01
    z[4,0,3]  R534      -3.8094222545623779e-02
    z[4,0,3]  R535      1.3926652073860168e-01
    z[4,0,3]  R536      -9.5875173807144165e-02
    z[4,0,3]  R537      2.1542407572269440e-01
    z[4,0,3]  R538      -1.9525042176246643e-01
    z[4,0,3]  R539      -1.9396646320819855e-01
    z[4,0,3]  R540      -2.9219649732112885e-02
    z[4,0,3]  R541      -1.3671833276748657e-01
    z[4,0,3]  R542      2.2687381505966187e-01
    z[4,0,3]  R543      3.5593304038047791e-01
    z[4,0,3]  R544      5.0011351704597473e-02
    z[4,0,3]  R545      -1.1290618032217026e-01
    z[4,0,3]  R546      3.2332947850227356e-01
    z[4,0,3]  R547      4.1120469570159912e-02
    z[4,0,3]  R548      -2.9871767759323120e-01
    z[4,0,3]  R549      -1.4645922183990479e-01
    z[4,0,3]  R550      -1.4632616937160492e-01
    z[4,0,3]  R551      -2.7534502441994846e-04
    z[4,0,3]  R552      2.5992043316364288e-02
    z[4,0,3]  R553      0.542360246181488
    z[4,0,3]  R554      -2.6507434248924255e-01
    z[4,0,3]  R555      2.2793164849281311e-01
    z[4,0,3]  R556      3.4473106265068054e-01
    z[4,0,3]  R557      -0.0948726087808609
    z[4,0,3]  R558      3.2306537032127380e-01
    z[4,0,3]  R559      3.7537211179733276e-01
    z[4,0,3]  R560      2.6692369580268860e-01
    z[4,0,3]  R561      5.3066551685333252e-02
    z[4,0,3]  R562      1.3132546842098236e-01
    z[4,0,3]  R563      3.8658934831619263e-01
    z[4,0,3]  R564      3.2547989487648010e-01
    z[4,0,3]  R565      1.7181062698364258e-01
    z[4,0,3]  R566      -4.1411802172660828e-01
    z[4,0,3]  R567      -1.2294325232505798e-01
    z[4,0,3]  R568      -2.5055891275405884e-01
    z[4,0,3]  R569      3.5662662982940674e-01
    z[4,0,3]  R570      1.3685664534568787e-01
    z[4,0,3]  R571      2.9205927252769470e-01
    z[4,0,3]  R572      3.8362291455268860e-01
    z[4,0,3]  R573      -1.6145074367523193e-01
    z[4,0,3]  R574      -8.5773169994354248e-01
    z[4,0,3]  R575      -8.7036657333374023e-01
    z[4,0,3]  R576      -7.2870439291000366e-01
    z[4,0,4]  R6        1
    z[4,0,4]  R42       -1
    z[4,0,4]  R461      -1
    z[4,0,4]  R462      1
    z[4,0,4]  R467      1.7594453692436218e-01
    z[4,0,4]  R468      2.6468461751937866e-01
    z[4,0,4]  R469      -8.4509648382663727e-02
    z[4,0,4]  R470      1.7926141619682312e-01
    z[4,0,4]  R471      1.1906246095895767e-01
    z[4,0,4]  R472      -1.5413333475589752e-01
    z[4,0,4]  R473      2.1042092144489288e-01
    z[4,0,4]  R474      -1.7308202385902405e-01
    z[4,0,4]  R475      -2.1921980381011963e-01
    z[4,0,4]  R476      -1.5550107927992940e-03
    z[4,0,4]  R477      -1.2728112936019897e-01
    z[4,0,4]  R478      4.4021272659301758e-01
    z[4,0,4]  R479      3.7656059861183167e-01
    z[4,0,4]  R480      0.293820321559906
    z[4,0,4]  R481      2.9863053560256958e-01
    z[4,0,4]  R482      -1.9770273566246033e-01
    z[4,0,4]  R483      3.4514042735099792e-01
    z[4,0,4]  R484      3.7323823571205139e-01
    z[4,0,4]  R485      -3.2541158795356750e-01
    z[4,0,4]  R486      2.5673272088170052e-02
    z[4,0,4]  R487      -1.8125078082084656e-01
    z[4,0,4]  R488      1.7340712249279022e-01
    z[4,0,4]  R489      9.8382413387298584e-02
    z[4,0,4]  R490      3.0576035380363464e-01
    z[4,0,4]  R491      3.2145464420318604e-01
    z[4,0,4]  R492      1.4233171939849854e-01
    z[4,0,4]  R493      -2.2503726184368134e-01
    z[4,0,4]  R494      -2.6704880595207214e-01
    z[4,0,4]  R495      -3.6939030885696411e-01
    z[4,0,4]  R496      -1.3780309259891510e-01
    z[4,0,4]  R497      5.5130505561828613e-01
    z[4,0,4]  R498      3.3232355117797852e-01
    z[4,0,4]  R499      5.5513274669647217e-01
    z[4,0,4]  R500      3.6872851848602295e-01
    z[4,0,4]  R501      -3.5058757662773132e-01
    z[4,0,4]  R502      -2.2812278568744659e-01
    z[4,0,4]  R503      0.24508036673069
    z[4,0,4]  R504      9.6251070499420166e-02
    z[4,0,4]  R505      1.5524534881114960e-01
    z[4,0,4]  R506      -2.3286515474319458e-01
    z[4,0,4]  R507      6.7009791731834412e-02
    z[4,0,4]  R508      4.9650236964225769e-02
    z[4,0,4]  R509      3.7223309278488159e-01
    z[4,0,4]  R510      0.444194495677948
    z[4,0,4]  R511      7.9294638708233833e-03
    z[4,0,4]  R512      5.3112413734197617e-02
    z[4,0,4]  R513      1.0073860734701157e-01
    z[4,0,4]  R514      -1.8034411966800690e-01
    z[4,0,4]  R515      4.9704242497682571e-02
    z[4,0,4]  R516      -0.199087455868721
    z[4,0,4]  R517      -1.2120189517736435e-01
    z[4,0,4]  R518      -1.6644150018692017e-02
    z[4,0,4]  R519      -4.0243282914161682e-01
    z[4,0,4]  R520      -1.0758836567401886e-01
    z[4,0,4]  R521      -1.4688777923583984e-01
    z[4,0,4]  R522      5.7627922296524048e-01
    z[4,0,4]  R523      1.5947715938091278e-01
    z[4,0,4]  R524      -3.0412566661834717e-01
    z[4,0,4]  R525      -3.5344353318214417e-01
    z[4,0,4]  R526      1.1140636354684830e-01
    z[4,0,4]  R527      -2.8949698805809021e-01
    z[4,0,4]  R528      3.9010590407997370e-03
    z[4,0,4]  R529      3.7130358815193176e-01
    z[4,0,4]  R530      3.9439356327056885e-01
    z[4,0,4]  R531      2.1075166761875153e-01
    z[4,0,4]  R532      -4.3483439087867737e-01
    z[4,0,4]  R533      -2.6787722110748291e-01
    z[4,0,4]  R534      3.9472463726997375e-01
    z[4,0,4]  R535      7.2351747751235962e-01
    z[4,0,4]  R536      4.5562589168548584e-01
    z[4,0,4]  R537      3.8099324703216553e-01
    z[4,0,4]  R538      1.6383874416351318e-01
    z[4,0,4]  R539      -4.2869547009468079e-01
    z[4,0,4]  R540      1.1872775852680206e-01
    z[4,0,4]  R541      -1.6867731511592865e-01
    z[4,0,4]  R542      -2.4987480044364929e-01
    z[4,0,4]  R543      -2.3909607529640198e-01
    z[4,0,4]  R544      1.6473528742790222e-01
    z[4,0,4]  R545      2.0090369880199432e-01
    z[4,0,4]  R546      -2.1071296185255051e-02
    z[4,0,4]  R547      2.1560238301753998e-01
    z[4,0,4]  R548      -4.2910999059677124e-01
    z[4,0,4]  R549      -4.8600274324417114e-01
    z[4,0,4]  R550      -2.2981595993041992e-01
    z[4,0,4]  R551      4.6965587139129639e-01
    z[4,0,4]  R552      -1.6751392185688019e-01
    z[4,0,4]  R553      5.6711727380752563e-01
    z[4,0,4]  R554      -5.4128672927618027e-02
    z[4,0,4]  R555      -3.8084489107131958e-01
    z[4,0,4]  R556      2.7243146300315857e-01
    z[4,0,4]  R557      3.1633153557777405e-01
    z[4,0,4]  R558      1.5265546739101410e-01
    z[4,0,4]  R559      -1.4113360643386841e-01
    z[4,0,4]  R560      -1.2006637454032898e-01
    z[4,0,4]  R561      -4.4512525200843811e-01
    z[4,0,4]  R562      -3.4826430678367615e-01
    z[4,0,4]  R563      1.4216047525405884e-01
    z[4,0,4]  R564      3.1747040152549744e-01
    z[4,0,4]  R565      2.5590106844902039e-01
    z[4,0,4]  R566      2.0995254814624786e-01
    z[4,0,4]  R567      -3.6104434728622437e-01
    z[4,0,4]  R568      -2.8809291124343872e-01
    z[4,0,4]  R569      6.2319129705429077e-02
    z[4,0,4]  R570      -4.6922415494918823e-01
    z[4,0,4]  R571      -1.2612015008926392e-01
    z[4,0,4]  R572      3.4273722767829895e-01
    z[4,0,4]  R573      2.7127549052238464e-01
    z[4,0,4]  R574      2.9080295562744141e-01
    z[4,0,4]  R575      3.5414847731590271e-01
    z[4,0,4]  R576      5.3716570138931274e-01
    z[4,0,5]  R7        1
    z[4,0,5]  R43       -1
    z[4,0,5]  R463      -1
    z[4,0,5]  R464      1
    z[4,0,5]  R467      7.1452908217906952e-02
    z[4,0,5]  R468      3.5677134990692139e-01
    z[4,0,5]  R469      2.7081233263015747e-01
    z[4,0,5]  R470      1.2114244699478149e-01
    z[4,0,5]  R471      2.8844168782234192e-01
    z[4,0,5]  R472      -1.7791172862052917e-01
    z[4,0,5]  R473      -1.4570856094360352e-01
    z[4,0,5]  R474      -2.2133085131645203e-01
    z[4,0,5]  R475      -3.6881619691848755e-01
    z[4,0,5]  R476      -4.7811937332153320e-01
    z[4,0,5]  R477      3.1066227704286575e-02
    z[4,0,5]  R478      1.8571242690086365e-01
    z[4,0,5]  R479      -2.9998105764389038e-01
    z[4,0,5]  R480      0.337121844291687
    z[4,0,5]  R481      -2.7562108635902405e-01
    z[4,0,5]  R482      3.5566347837448120e-01
    z[4,0,5]  R483      -1.8380945920944214e-01
    z[4,0,5]  R484      -7.1242645382881165e-02
    z[4,0,5]  R485      -5.2340172231197357e-02
    z[4,0,5]  R486      2.8898137807846069e-01
    z[4,0,5]  R487      -3.9129644632339478e-01
    z[4,0,5]  R488      -0.0736314207315445
    z[4,0,5]  R489      1.8468746542930603e-01
    z[4,0,5]  R490      -2.2853343188762665e-01
    z[4,0,5]  R491      1.2016015499830246e-01
    z[4,0,5]  R492      -5.9180450439453125e-01
    z[4,0,5]  R493      -1.2782792747020721e-01
    z[4,0,5]  R494      5.0256609916687012e-01
    z[4,0,5]  R495      2.6800256967544556e-01
    z[4,0,5]  R496      -3.1151911243796349e-02
    z[4,0,5]  R497      -1.4227263629436493e-01
    z[4,0,5]  R498      1.1875028163194656e-01
    z[4,0,5]  R499      -2.9758533835411072e-01
    z[4,0,5]  R500      -3.4854629635810852e-01
    z[4,0,5]  R501      -5.7962417602539062e-01
    z[4,0,5]  R502      4.2994111776351929e-01
    z[4,0,5]  R503      1.0444504767656326e-01
    z[4,0,5]  R504      -2.2317662835121155e-01
    z[4,0,5]  R505      1.7396973073482513e-01
    z[4,0,5]  R506      4.5839063823223114e-02
    z[4,0,5]  R507      1.9528928399085999e-01
    z[4,0,5]  R508      -2.0145791769027710e-01
    z[4,0,5]  R509      1.7320029437541962e-02
    z[4,0,5]  R510      4.0903955698013306e-01
    z[4,0,5]  R511      9.8281085491180420e-02
    z[4,0,5]  R512      3.0730363726615906e-01
    z[4,0,5]  R513      5.3372409194707870e-02
    z[4,0,5]  R514      -1.8346744775772095e-01
    z[4,0,5]  R515      -3.3059573173522949e-01
    z[4,0,5]  R516      1.0094561427831650e-01
    z[4,0,5]  R517      -2.2441111505031586e-02
    z[4,0,5]  R518      -3.2206451892852783e-01
    z[4,0,5]  R519      3.4362614154815674e-01
    z[4,0,5]  R520      2.6856040954589844e-01
    z[4,0,5]  R521      -2.2042410075664520e-01
    z[4,0,5]  R522      1.0946364700794220e-01
    z[4,0,5]  R523      -1.1709731072187424e-01
    z[4,0,5]  R524      6.2703627347946167e-01
    z[4,0,5]  R525      2.3887772858142853e-01
    z[4,0,5]  R526      2.0065395534038544e-01
    z[4,0,5]  R527      -2.8457227349281311e-01
    z[4,0,5]  R528      1.7556734383106232e-01
    z[4,0,5]  R529      5.7907629013061523e-01
    z[4,0,5]  R530      5.7281899452209473e-01
    z[4,0,5]  R531      1.8540093302726746e-01
    z[4,0,5]  R532      2.2422537207603455e-01
    z[4,0,5]  R533      -8.2233786582946777e-02
    z[4,0,5]  R534      -5.5447822809219360e-01
    z[4,0,5]  R535      2.4402387440204620e-02
    z[4,0,5]  R536      -3.6432299017906189e-01
    z[4,0,5]  R537      3.5972729325294495e-01
    z[4,0,5]  R538      -1.3474673032760620e-01
    z[4,0,5]  R539      4.1070944070816040e-01
    z[4,0,5]  R540      2.6845881342887878e-01
    z[4,0,5]  R541      -1.5600410103797913e-01
    z[4,0,5]  R542      1.5160793066024780e-01
    z[4,0,5]  R543      2.1437972784042358e-01
    z[4,0,5]  R544      4.8980495333671570e-01
    z[4,0,5]  R545      -7.4408024549484253e-02
    z[4,0,5]  R546      -2.1193774044513702e-01
    z[4,0,5]  R547      7.8503206372261047e-02
    z[4,0,5]  R548      3.9419022202491760e-01
    z[4,0,5]  R549      0.241140216588974
    z[4,0,5]  R550      -3.0998522415757179e-02
    z[4,0,5]  R551      0.0473196879029274
    z[4,0,5]  R552      7.3381590843200684e-01
    z[4,0,5]  R553      -6.0118723660707474e-02
    z[4,0,5]  R554      -5.0032156705856323e-01
    z[4,0,5]  R555      1.2722863256931305e-01
    z[4,0,5]  R556      -1.9989706575870514e-01
    z[4,0,5]  R557      4.3923646211624146e-02
    z[4,0,5]  R558      7.0017236471176147e-01
    z[4,0,5]  R559      1.4569871127605438e-01
    z[4,0,5]  R560      -1.4300954341888428e-01
    z[4,0,5]  R561      1.4630545675754547e-01
    z[4,0,5]  R562      -1.2696520984172821e-01
    z[4,0,5]  R563      2.1517179906368256e-01
    z[4,0,5]  R564      9.5603436231613159e-02
    z[4,0,5]  R565      -7.4994713068008423e-01
    z[4,0,5]  R566      -2.0519596338272095e-01
    z[4,0,5]  R567      6.0436416417360306e-02
    z[4,0,5]  R568      -4.9589961767196655e-01
    z[4,0,5]  R569      -8.8590532541275024e-02
    z[4,0,5]  R570      1.7978367209434509e-01
    z[4,0,5]  R571      4.7062897682189941e-01
    z[4,0,5]  R572      4.7685805708169937e-02
    z[4,0,5]  R573      -3.7317976355552673e-01
    z[4,0,5]  R574      -1.5483933687210083e-01
    z[4,0,5]  R575      -0.0720822662115097
    z[4,0,5]  R576      2.0726247131824493e-01
    z[4,0,6]  R8        1
    z[4,0,6]  R44       -1
    z[4,0,6]  R465      -1
    z[4,0,6]  R466      1
    z[4,0,6]  R467      -3.1818527728319168e-02
    z[4,0,6]  R468      1.4064137637615204e-01
    z[4,0,6]  R469      2.0764620602130890e-01
    z[4,0,6]  R470      -1.0985297709703445e-01
    z[4,0,6]  R471      -5.1133328676223755e-01
    z[4,0,6]  R472      -3.3458021283149719e-01
    z[4,0,6]  R473      -5.2544206380844116e-01
    z[4,0,6]  R474      4.1002756357192993e-01
    z[4,0,6]  R475      2.4528257548809052e-01
    z[4,0,6]  R476      -8.0440282821655273e-02
    z[4,0,6]  R477      6.4529007673263550e-01
    z[4,0,6]  R478      4.0478876233100891e-01
    z[4,0,6]  R479      4.3260720372200012e-01
    z[4,0,6]  R480      -3.0164131522178650e-01
    z[4,0,6]  R481      4.0131950378417969e-01
    z[4,0,6]  R482      4.0527349710464478e-01
    z[4,0,6]  R483      -5.7893428951501846e-02
    z[4,0,6]  R484      -6.0330498218536377e-01
    z[4,0,6]  R485      5.7394319772720337e-01
    z[4,0,6]  R486      2.5136026740074158e-01
    z[4,0,6]  R487      4.0686386823654175e-01
    z[4,0,6]  R488      -2.2347070276737213e-01
    z[4,0,6]  R489      -2.5894997641444206e-02
    z[4,0,6]  R490      -3.1094381213188171e-01
    z[4,0,6]  R491      -5.4116499423980713e-01
    z[4,0,6]  R492      -4.4947916269302368e-01
    z[4,0,6]  R493      -2.6228001341223717e-02
    z[4,0,6]  R494      -8.0857515335083008e-02
    z[4,0,6]  R495      1.3635386526584625e-01
    z[4,0,6]  R496      5.9855472296476364e-02
    z[4,0,6]  R497      2.6544073224067688e-01
    z[4,0,6]  R498      3.6584597826004028e-01
    z[4,0,6]  R499      0.0942707434296608
    z[4,0,6]  R500      2.1030361950397491e-01
    z[4,0,6]  R501      -3.1426653265953064e-02
    z[4,0,6]  R502      -0.0619150847196579
    z[4,0,6]  R503      -9.6823170781135559e-02
    z[4,0,6]  R504      -1.0391784459352493e-01
    z[4,0,6]  R505      -7.5780266523361206e-01
    z[4,0,6]  R506      -1.5807080268859863e-01
    z[4,0,6]  R507      1.6583777964115143e-01
    z[4,0,6]  R508      -3.8994929194450378e-01
    z[4,0,6]  R509      -4.0062373876571655e-01
    z[4,0,6]  R510      -3.6320978403091431e-01
    z[4,0,6]  R511      1.1026592552661896e-01
    z[4,0,6]  R512      -5.2296765148639679e-02
    z[4,0,6]  R513      1.8907051533460617e-02
    z[4,0,6]  R514      -7.9683875665068626e-03
    z[4,0,6]  R515      2.8325811028480530e-02
    z[4,0,6]  R516      -7.2527416050434113e-02
    z[4,0,6]  R517      -1.2756648659706116e-01
    z[4,0,6]  R518      8.4818363189697266e-02
    z[4,0,6]  R519      3.7218338251113892e-01
    z[4,0,6]  R520      -1.2677906453609467e-01
    z[4,0,6]  R521      -2.3077972233295441e-01
    z[4,0,6]  R522      -1.4685744047164917e-01
    z[4,0,6]  R523      -2.9190099239349365e-01
    z[4,0,6]  R524      2.4228583276271820e-01
    z[4,0,6]  R525      1.0840741544961929e-01
    z[4,0,6]  R526      -2.4150301516056061e-01
    z[4,0,6]  R527      2.9284858703613281e-01
    z[4,0,6]  R528      -1.7267785966396332e-01
    z[4,0,6]  R529      -2.2345557808876038e-01
    z[4,0,6]  R530      2.1690483391284943e-01
    z[4,0,6]  R531      6.6331011056900024e-01
    z[4,0,6]  R532      -5.7014679908752441e-01
    z[4,0,6]  R533      -7.0623534917831421e-01
    z[4,0,6]  R534      -0.342369943857193
    z[4,0,6]  R535      -2.2693943977355957e-01
    z[4,0,6]  R536      2.7805598452687263e-02
    z[4,0,6]  R537      3.2342830300331116e-01
    z[4,0,6]  R538      1.6324064135551453e-01
    z[4,0,6]  R539      -3.9405685663223267e-01
    z[4,0,6]  R540      2.8581345081329346e-01
    z[4,0,6]  R541      5.5778241157531738e-01
    z[4,0,6]  R542      -3.0908763408660889e-01
    z[4,0,6]  R543      -1.4259695308282971e-03
    z[4,0,6]  R544      -1.0526964440941811e-02
    z[4,0,6]  R545      4.6955081820487976e-01
    z[4,0,6]  R546      -2.4644516408443451e-02
    z[4,0,6]  R547      -4.0068548917770386e-01
    z[4,0,6]  R548      2.1922437474131584e-02
    z[4,0,6]  R549      -2.5409638881683350e-02
    z[4,0,6]  R550      7.4082213640213013e-01
    z[4,0,6]  R551      -2.0371438562870026e-01
    z[4,0,6]  R552      -0.0668964833021164
    z[4,0,6]  R553      0.053868368268013
    z[4,0,6]  R554      -2.0011919736862183e-01
    z[4,0,6]  R555      3.1985294818878174e-01
    z[4,0,6]  R556      4.3893656134605408e-01
    z[4,0,6]  R557      -1.8634347617626190e-01
    z[4,0,6]  R558      6.4604885876178741e-02
    z[4,0,6]  R559      2.1577186882495880e-01
    z[4,0,6]  R560      3.3691400289535522e-01
    z[4,0,6]  R561      3.5072332620620728e-01
    z[4,0,6]  R562      3.3503195643424988e-01
    z[4,0,6]  R563      -6.3178554177284241e-02
    z[4,0,6]  R564      5.2519404888153076e-01
    z[4,0,6]  R565      9.7945248708128929e-03
    z[4,0,6]  R566      1.9831065833568573e-01
    z[4,0,6]  R567      2.1922451257705688e-01
    z[4,0,6]  R568      -1.4156721532344818e-01
    z[4,0,6]  R569      3.7250018119812012e-01
    z[4,0,6]  R570      -1.6828449070453644e-01
    z[4,0,6]  R571      -4.0948797017335892e-02
    z[4,0,6]  R572      4.5295268297195435e-01
    z[4,0,6]  R573      -5.4676569998264313e-02
    z[4,0,6]  R574      -8.1497155129909515e-02
    z[4,0,6]  R575      8.0568544566631317e-02
    z[4,0,6]  R576      8.3461239933967590e-02
    z[1,2,0]  R11       -1
    z[1,2,0]  R20       1
    z[1,2,0]  R651      -1
    z[1,2,0]  R652      1
    z[1,2,0]  R665      -1.3894502818584442e-01
    z[1,2,0]  R666      1.3602147996425629e-01
    z[1,2,0]  R667      -9.3008416891098022e-01
    z[1,2,0]  R668      -8.4046369791030884e-01
    z[1,2,0]  R669      -7.8733968734741211e-01
    z[1,2,0]  R670      -8.8880550861358643e-01
    z[1,2,0]  R671      -9.0660637617111206e-01
    z[1,2,0]  R672      -8.6132991313934326e-01
    z[1,2,0]  R673      -7.4839603900909424e-01
    z[1,2,0]  R674      -9.2447394132614136e-01
    z[1,2,0]  R675      -6.3099667429924011e-02
    z[1,2,0]  R676      4.1129431128501892e-01
    z[1,2,0]  R677      -3.1831058859825134e-01
    z[1,2,0]  R678      4.7566571831703186e-01
    z[1,2,0]  R679      -1.3901624083518982e-01
    z[1,2,0]  R680      -4.0207871794700623e-01
    z[1,2,0]  R681      3.2552149891853333e-01
    z[1,2,0]  R682      5.9157520532608032e-01
    z[1,2,0]  R683      8.1628121435642242e-02
    z[1,2,0]  R684      8.0147922039031982e-01
    z[1,2,0]  R685      -3.5144484043121338e-01
    z[1,2,0]  R686      -1.4187182486057281e-01
    z[1,2,0]  R687      2.7030315995216370e-01
    z[1,2,0]  R688      2.3140832781791687e-02
    z[1,2,0]  R689      8.6315566301345825e-01
    z[1,2,0]  R690      8.6348617076873779e-01
    z[1,2,0]  R691      8.1512153148651123e-01
    z[1,2,0]  R692      8.0033266544342041e-01
    z[1,2,0]  R693      7.6406925916671753e-01
    z[1,2,0]  R694      0.789068341255188
    z[1,2,0]  R695      4.6590375900268555e-01
    z[1,2,0]  R696      1.5367440879344940e-01
    z[1,2,0]  R697      3.1646621227264404e-01
    z[1,2,0]  R698      5.1167792081832886e-01
    z[1,2,0]  R699      -5.7876616716384888e-01
    z[1,2,0]  R700      9.7735965251922607e-01
    z[1,2,0]  R701      -5.6773281097412109e-01
    z[1,2,0]  R702      -1.3762372732162476e-01
    z[1,2,0]  R703      2.2838750854134560e-02
    z[1,2,0]  R704      2.4538686871528625e-01
    z[1,2,0]  R705      1.7375077307224274e-01
    z[1,2,0]  R706      1.0416479408740997e-01
    z[1,2,0]  R707      3.5076405853033066e-02
    z[1,2,0]  R708      1.1815072596073151e-01
    z[1,2,0]  R709      1.3126258552074432e-01
    z[1,2,0]  R710      4.0457978844642639e-02
    z[1,2,0]  R711      -3.9107404649257660e-02
    z[1,2,0]  R712      -7.3462487198412418e-03
    z[1,2,0]  R713      -2.0507071912288666e-01
    z[1,2,0]  R714      5.1161199808120728e-02
    z[1,2,0]  R715      -5.0340861082077026e-02
    z[1,2,0]  R716      1.0358274728059769e-01
    z[1,2,0]  R717      -1.6905583441257477e-02
    z[1,2,0]  R718      1.8200548365712166e-02
    z[1,2,0]  R719      -1.5195293724536896e-01
    z[1,2,0]  R720      -1.0875476151704788e-01
    z[1,2,0]  R721      -1.0530030727386475e-01
    z[1,2,0]  R722      -1.1921381205320358e-01
    z[1,2,0]  R723      -9.4531789422035217e-02
    z[1,2,0]  R724      -9.7032509744167328e-02
    z[1,2,0]  R725      -1.1137016862630844e-01
    z[1,2,0]  R726      -1.5104120969772339e-01
    z[1,2,0]  R727      -8.7838634848594666e-02
    z[1,2,0]  R728      -9.9680311977863312e-02
    z[1,2,0]  R729      -1.4754776656627655e-01
    z[1,2,0]  R730      -6.5765053033828735e-02
    z[1,2,0]  R731      -1.2139682471752167e-01
    z[1,2,0]  R732      2.1158248186111450e-02
    z[1,2,0]  R733      -1.4087593555450439e-01
    z[1,2,0]  R734      9.5251291990280151e-02
    z[1,2,0]  R735      -0.0731421485543251
    z[1,2,0]  R736      -1.8635485321283340e-02
    z[1,2,0]  R737      -1.7498539388179779e-01
    z[1,2,0]  R738      -1.8789456784725189e-01
    z[1,2,0]  R739      -2.5243632495403290e-02
    z[1,2,0]  R740      -5.5284440517425537e-02
    z[1,2,0]  R741      -6.9861665368080139e-02
    z[1,2,0]  R742      8.2318651676177979e-01
    z[1,2,0]  R743      -5.5996431037783623e-03
    z[1,2,0]  R744      -8.5662461817264557e-02
    z[1,2,0]  R745      -3.8488205522298813e-02
    z[1,2,0]  R746      -9.2685915529727936e-02
    z[1,2,0]  R747      -1.4319211244583130e-01
    z[1,2,0]  R748      -1.0172440856695175e-01
    z[1,2,0]  R749      -8.5732407867908478e-02
    z[1,2,0]  R750      6.5032929182052612e-01
    z[1,2,0]  R751      6.3057667016983032e-01
    z[1,2,0]  R752      6.4594465494155884e-01
    z[1,2,0]  R753      7.2314405441284180e-01
    z[1,2,1]  R12       -1
    z[1,2,1]  R21       1
    z[1,2,1]  R653      -1
    z[1,2,1]  R654      1
    z[1,2,1]  R665      4.5714911073446274e-02
    z[1,2,1]  R666      9.5595233142375946e-02
    z[1,2,1]  R667      -1.5452742576599121e-01
    z[1,2,1]  R668      -3.0428934097290039e-01
    z[1,2,1]  R669      -1.7054866254329681e-01
    z[1,2,1]  R670      -2.4879324436187744e-01
    z[1,2,1]  R671      -2.3625767230987549e-01
    z[1,2,1]  R672      -2.0802576839923859e-01
    z[1,2,1]  R673      -2.8309798240661621e-01
    z[1,2,1]  R674      8.6726211011409760e-02
    z[1,2,1]  R675      6.4761382341384888e-01
    z[1,2,1]  R676      0.524172842502594
    z[1,2,1]  R677      4.9181440472602844e-01
    z[1,2,1]  R678      1.8394406139850616e-01
    z[1,2,1]  R679      1.9864578545093536e-01
    z[1,2,1]  R680      3.9298623800277710e-01
    z[1,2,1]  R681      4.8723950982093811e-01
    z[1,2,1]  R682      3.2236889004707336e-01
    z[1,2,1]  R683      1.7612237483263016e-02
    z[1,2,1]  R684      1.1396908015012741e-01
    z[1,2,1]  R685      6.6057032346725464e-01
    z[1,2,1]  R686      0.470954954624176
    z[1,2,1]  R687      4.3172460794448853e-01
    z[1,2,1]  R688      4.9238261580467224e-01
    z[1,2,1]  R689      1.4013834297657013e-01
    z[1,2,1]  R690      2.7400064468383789e-01
    z[1,2,1]  R691      1.6780835390090942e-01
    z[1,2,1]  R692      -4.7978889197111130e-02
    z[1,2,1]  R693      -2.1913725137710571e-01
    z[1,2,1]  R694      1.0546435415744781e-01
    z[1,2,1]  R695      2.3242063820362091e-01
    z[1,2,1]  R696      6.2136089801788330e-01
    z[1,2,1]  R697      5.8741199970245361e-01
    z[1,2,1]  R698      5.3919184207916260e-01
    z[1,2,1]  R699      3.9454418420791626e-01
    z[1,2,1]  R700      3.5307902842760086e-02
    z[1,2,1]  R701      3.3526644110679626e-02
    z[1,2,1]  R702      -9.3011397123336792e-01
    z[1,2,1]  R703      -9.3885004520416260e-01
    z[1,2,1]  R704      -8.6740863323211670e-01
    z[1,2,1]  R705      -0.188704252243042
    z[1,2,1]  R706      -2.4665230512619019e-01
    z[1,2,1]  R707      -7.5864009559154510e-02
    z[1,2,1]  R708      -1.4523386955261230e-01
    z[1,2,1]  R709      3.9027415215969086e-02
    z[1,2,1]  R710      3.2125559449195862e-01
    z[1,2,1]  R711      -8.7640094757080078e-01
    z[1,2,1]  R712      2.4323654174804688e-01
    z[1,2,1]  R713      -7.8582540154457092e-02
    z[1,2,1]  R714      9.0698373317718506e-01
    z[1,2,1]  R715      7.7767539024353027e-01
    z[1,2,1]  R716      7.6909792423248291e-01
    z[1,2,1]  R717      7.4120289087295532e-01
    z[1,2,1]  R718      0.731759786605835
    z[1,2,1]  R719      6.7997241020202637e-01
    z[1,2,1]  R720      6.6865491867065430e-01
    z[1,2,1]  R721      0.649121105670929
    z[1,2,1]  R722      0.642539918422699
    z[1,2,1]  R723      6.3295543193817139e-01
    z[1,2,1]  R724      5.9669071435928345e-01
    z[1,2,1]  R725      -1.3306954503059387e-01
    z[1,2,1]  R726      -5.5064046382904053e-01
    z[1,2,1]  R727      -0.590140163898468
    z[1,2,1]  R728      -4.8204281926155090e-01
    z[1,2,1]  R729      -3.4903496503829956e-01
    z[1,2,1]  R730      -2.7629068493843079e-01
    z[1,2,1]  R731      -4.7363707423210144e-01
    z[1,2,1]  R732      -9.0629106760025024e-01
    z[1,2,1]  R733      -5.0873714685440063e-01
    z[1,2,1]  R734      8.0913090705871582e-01
    z[1,2,1]  R735      6.0107976198196411e-01
    z[1,2,1]  R736      5.5919289588928223e-01
    z[1,2,1]  R737      -1.8453678488731384e-01
    z[1,2,1]  R738      -2.1710814535617828e-01
    z[1,2,1]  R739      -9.4162505865097046e-01
    z[1,2,1]  R740      -9.0053504705429077e-01
    z[1,2,1]  R741      -8.9092463254928589e-01
    z[1,2,1]  R742      -5.0908583402633667e-01
    z[1,2,1]  R743      -8.8902920484542847e-01
    z[1,2,1]  R744      8.2013344764709473e-01
    z[1,2,1]  R745      6.7155414819717407e-01
    z[1,2,1]  R746      4.3844765424728394e-01
    z[1,2,1]  R747      -9.7919665277004242e-02
    z[1,2,1]  R748      -5.9339928627014160e-01
    z[1,2,1]  R749      -8.5561513900756836e-01
    z[1,2,1]  R750      -5.1422142982482910e-01
    z[1,2,1]  R751      -5.1929527521133423e-01
    z[1,2,1]  R752      -0.442984014749527
    z[1,2,1]  R753      -2.8734889626502991e-01
    z[1,2,2]  R13       -1
    z[1,2,2]  R22       1
    z[1,2,2]  R655      -1
    z[1,2,2]  R656      1
    z[1,2,2]  R665      -3.4589764475822449e-01
    z[1,2,2]  R666      6.7459084093570709e-02
    z[1,2,2]  R667      -3.8910549134016037e-02
    z[1,2,2]  R668      -2.6638289913535118e-02
    z[1,2,2]  R669      -4.0393546223640442e-01
    z[1,2,2]  R670      1.1216019839048386e-01
    z[1,2,2]  R671      8.4725886583328247e-02
    z[1,2,2]  R672      -2.9832099098712206e-03
    z[1,2,2]  R673      -2.7745479345321655e-01
    z[1,2,2]  R674      -3.1092030927538872e-02
    z[1,2,2]  R675      4.8684078454971313e-01
    z[1,2,2]  R676      -4.1123846173286438e-01
    z[1,2,2]  R677      2.3864111304283142e-01
    z[1,2,2]  R678      -2.2743576765060425e-01
    z[1,2,2]  R679      -5.5330187082290649e-01
    z[1,2,2]  R680      -4.2811136692762375e-02
    z[1,2,2]  R681      -6.3877038657665253e-02
    z[1,2,2]  R682      4.2054817080497742e-01
    z[1,2,2]  R683      -4.1802123188972473e-01
    z[1,2,2]  R684      8.6916297674179077e-02
    z[1,2,2]  R685      -1.8759422004222870e-01
    z[1,2,2]  R686      6.2493032217025757e-01
    z[1,2,2]  R687      1.5951023995876312e-01
    z[1,2,2]  R688      -3.9223572611808777e-01
    z[1,2,2]  R689      -1.4474473893642426e-02
    z[1,2,2]  R690      -0.140329509973526
    z[1,2,2]  R691      1.3617476820945740e-01
    z[1,2,2]  R692      -1.8472173810005188e-01
    z[1,2,2]  R693      2.9430523514747620e-01
    z[1,2,2]  R694      -6.5737059339880943e-03
    z[1,2,2]  R695      -3.7296712398529053e-01
    z[1,2,2]  R696      6.6249914467334747e-02
    z[1,2,2]  R697      2.2753553465008736e-02
    z[1,2,2]  R698      -2.7140554785728455e-01
    z[1,2,2]  R699      -2.4743634462356567e-01
    z[1,2,2]  R700      3.6267023533582687e-02
    z[1,2,2]  R701      -1.7865149676799774e-01
    z[1,2,2]  R702      1.5413431823253632e-01
    z[1,2,2]  R703      2.7333769202232361e-01
    z[1,2,2]  R704      2.0702511072158813e-01
    z[1,2,2]  R705      -4.4951781630516052e-01
    z[1,2,2]  R706      -5.7896214723587036e-01
    z[1,2,2]  R707      -7.5325781106948853e-01
    z[1,2,2]  R708      -6.0198068618774414e-01
    z[1,2,2]  R709      2.7803765609860420e-02
    z[1,2,2]  R710      4.9266871809959412e-01
    z[1,2,2]  R711      1.9959209859371185e-01
    z[1,2,2]  R712      6.3347554206848145e-01
    z[1,2,2]  R713      3.4610655903816223e-01
    z[1,2,2]  R714      -9.4338893890380859e-02
    z[1,2,2]  R715      -2.8370854258537292e-01
    z[1,2,2]  R716      1.4953862130641937e-01
    z[1,2,2]  R717      2.9757255315780640e-01
    z[1,2,2]  R718      5.3267461061477661e-01
    z[1,2,2]  R719      4.1305556893348694e-01
    z[1,2,2]  R720      1.0275747627019882e-01
    z[1,2,2]  R721      2.9723986983299255e-01
    z[1,2,2]  R722      2.5612899661064148e-01
    z[1,2,2]  R723      1.3214507699012756e-01
    z[1,2,2]  R724      8.6175657808780670e-02
    z[1,2,2]  R725      4.3202412128448486e-01
    z[1,2,2]  R726      4.8419484496116638e-01
    z[1,2,2]  R727      3.3047696948051453e-01
    z[1,2,2]  R728      5.3097373247146606e-01
    z[1,2,2]  R729      4.6801841259002686e-01
    z[1,2,2]  R730      2.5067463517189026e-01
    z[1,2,2]  R731      3.1835344433784485e-01
    z[1,2,2]  R732      2.5098061561584473e-01
    z[1,2,2]  R733      1.9846871495246887e-01
    z[1,2,2]  R734      2.8659293428063393e-02
    z[1,2,2]  R735      -2.0808011293411255e-01
    z[1,2,2]  R736      5.2410387992858887e-01
    z[1,2,2]  R737      0.0869893953204155
    z[1,2,2]  R738      4.6075470745563507e-02
    z[1,2,2]  R739      -9.9441379308700562e-02
    z[1,2,2]  R740      2.8549528121948242e-01
    z[1,2,2]  R741      1.1278945207595825e-01
    z[1,2,2]  R742      4.9462612718343735e-02
    z[1,2,2]  R743      -1.4428270515054464e-03
    z[1,2,2]  R744      1.0920712351799011e-01
    z[1,2,2]  R745      2.8010737895965576e-01
    z[1,2,2]  R746      2.0575119182467461e-02
    z[1,2,2]  R747      -0.0702795684337616
    z[1,2,2]  R748      -0.0913701057434082
    z[1,2,2]  R749      2.1251454949378967e-01
    z[1,2,2]  R750      2.9008436203002930e-01
    z[1,2,2]  R751      3.0944174528121948e-01
    z[1,2,2]  R752      4.6052265167236328e-01
    z[1,2,2]  R753      -8.3492629230022430e-02
    z[1,2,3]  R14       -1
    z[1,2,3]  R23       1
    z[1,2,3]  R657      -1
    z[1,2,3]  R658      1
    z[1,2,3]  R665      -9.1660672426223755e-01
    z[1,2,3]  R666      -8.1101936101913452e-01
    z[1,2,3]  R667      -4.3476864695549011e-02
    z[1,2,3]  R668      -1.2680803239345551e-01
    z[1,2,3]  R669      -7.1115955710411072e-02
    z[1,2,3]  R670      -2.5599592924118042e-01
    z[1,2,3]  R671      3.2942626625299454e-02
    z[1,2,3]  R672      -0.411723792552948
    z[1,2,3]  R673      -4.6243837475776672e-01
    z[1,2,3]  R674      -3.5735196433961391e-03
    z[1,2,3]  R675      -1.7720645666122437e-01
    z[1,2,3]  R676      -4.6511989086866379e-02
    z[1,2,3]  R677      1.3114874064922333e-01
    z[1,2,3]  R678      2.3564623668789864e-02
    z[1,2,3]  R679      1.1789546906948090e-01
    z[1,2,3]  R680      3.9691349864006042e-01
    z[1,2,3]  R681      2.0991069078445435e-01
    z[1,2,3]  R682      1.3820931315422058e-01
    z[1,2,3]  R683      1.0030884295701981e-01
    z[1,2,3]  R684      -1.2336043268442154e-01
    z[1,2,3]  R685      0.185865581035614
    z[1,2,3]  R686      3.3921965956687927e-01
    z[1,2,3]  R687      -2.6427122950553894e-01
    z[1,2,3]  R688      1.5687417984008789e-01
    z[1,2,3]  R689      1.2083962559700012e-01
    z[1,2,3]  R690      0.269723504781723
    z[1,2,3]  R691      -1.8055105209350586e-01
    z[1,2,3]  R692      3.8706335425376892e-01
    z[1,2,3]  R693      1.7415404319763184e-01
    z[1,2,3]  R694      -1.6753622889518738e-01
    z[1,2,3]  R695      -2.6583081483840942e-01
    z[1,2,3]  R696      1.6575561463832855e-01
    z[1,2,3]  R697      3.2966342568397522e-01
    z[1,2,3]  R698      5.3757125139236450e-01
    z[1,2,3]  R699      1.4396762847900391e-01
    z[1,2,3]  R700      0.0681452751159668
    z[1,2,3]  R701      -2.2184237837791443e-01
    z[1,2,3]  R702      1.6380879282951355e-01
    z[1,2,3]  R703      8.4882482886314392e-02
    z[1,2,3]  R704      1.5975062549114227e-01
    z[1,2,3]  R705      -7.4526280164718628e-01
    z[1,2,3]  R706      -6.8571335077285767e-01
    z[1,2,3]  R707      -3.4381410479545593e-01
    z[1,2,3]  R708      -4.9803760647773743e-01
    z[1,2,3]  R709      -8.3985865116119385e-01
    z[1,2,3]  R710      -0.0569143183529377
    z[1,2,3]  R711      1.1172537505626678e-01
    z[1,2,3]  R712      2.8988546133041382e-01
    z[1,2,3]  R713      3.5846811532974243e-01
    z[1,2,3]  R714      7.7495403587818146e-02
    z[1,2,3]  R715      1.9534422457218170e-01
    z[1,2,3]  R716      2.9060753062367439e-02
    z[1,2,3]  R717      -5.9179320931434631e-02
    z[1,2,3]  R718      -3.4050792455673218e-01
    z[1,2,3]  R719      3.6460673809051514e-01
    z[1,2,3]  R720      5.4198390245437622e-01
    z[1,2,3]  R721      0.00823516957461834
    z[1,2,3]  R722      4.8303452134132385e-01
    z[1,2,3]  R723      1.5749073028564453e-01
    z[1,2,3]  R724      4.3526706099510193e-01
    z[1,2,3]  R725      7.9342108964920044e-01
    z[1,2,3]  R726      6.5937399864196777e-01
    z[1,2,3]  R727      6.5896546840667725e-01
    z[1,2,3]  R728      6.2674939632415771e-01
    z[1,2,3]  R729      6.7736089229583740e-01
    z[1,2,3]  R730      7.3747175931930542e-01
    z[1,2,3]  R731      6.9485068321228027e-01
    z[1,2,3]  R732      -5.8983918279409409e-03
    z[1,2,3]  R733      7.4100762605667114e-01
    z[1,2,3]  R734      -5.2359545230865479e-01
    z[1,2,3]  R735      1.0568166524171829e-01
    z[1,2,3]  R736      -4.7711357474327087e-03
    z[1,2,3]  R737      0.899384617805481
    z[1,2,3]  R738      9.2336362600326538e-01
    z[1,2,3]  R739      2.6426756381988525e-01
    z[1,2,3]  R740      6.7940421402454376e-02
    z[1,2,3]  R741      2.9856231808662415e-01
    z[1,2,3]  R742      2.1147172152996063e-01
    z[1,2,3]  R743      1.3571204245090485e-01
    z[1,2,3]  R744      2.6888519525527954e-01
    z[1,2,3]  R745      3.7405043840408325e-01
    z[1,2,3]  R746      -1.7554442584514618e-01
    z[1,2,3]  R747      9.7027087211608887e-01
    z[1,2,3]  R748      7.2116440534591675e-01
    z[1,2,3]  R749      1.2738877534866333e-01
    z[1,2,3]  R750      0.232284277677536
    z[1,2,3]  R751      1.7936527729034424e-01
    z[1,2,3]  R752      5.1085177809000015e-02
    z[1,2,3]  R753      3.9830267429351807e-01
    z[1,2,4]  R15       -1
    z[1,2,4]  R24       1
    z[1,2,4]  R659      -1
    z[1,2,4]  R660      1
    z[1,2,4]  R665      1.2073950469493866e-01
    z[1,2,4]  R666      -3.8818454742431641e-01
    z[1,2,4]  R667      -2.2023659944534302e-01
    z[1,2,4]  R668      -0.362755686044693
    z[1,2,4]  R669      -3.7469755858182907e-02
    z[1,2,4]  R670      -1.0215345025062561e-01
    z[1,2,4]  R671      -5.6431770324707031e-02
    z[1,2,4]  R672      -1.9362926483154297e-01
    z[1,2,4]  R673      -2.3312574625015259e-01
    z[1,2,4]  R674      2.0571598410606384e-01
    z[1,2,4]  R675      2.6713365316390991e-01
    z[1,2,4]  R676      -3.4226661920547485e-01
    z[1,2,4]  R677      3.6679524183273315e-01
    z[1,2,4]  R678      6.4701634645462036e-01
    z[1,2,4]  R679      3.2485261559486389e-01
    z[1,2,4]  R680      3.8113960623741150e-01
    z[1,2,4]  R681      2.6097622513771057e-01
    z[1,2,4]  R682      1.7337530851364136e-01
    z[1,2,4]  R683      4.5824062824249268e-01
    z[1,2,4]  R684      3.9034643769264221e-01
    z[1,2,4]  R685      -3.6595097184181213e-01
    z[1,2,4]  R686      -4.7360396385192871e-01
    z[1,2,4]  R687      4.6043559908866882e-01
    z[1,2,4]  R688      0.595091700553894
    z[1,2,4]  R689      -1.8384316563606262e-01
    z[1,2,4]  R690      1.9511753320693970e-01
    z[1,2,4]  R691      -1.5140847861766815e-01
    z[1,2,4]  R692      -3.7934783101081848e-01
    z[1,2,4]  R693      -4.6128010749816895e-01
    z[1,2,4]  R694      2.3113496601581573e-01
    z[1,2,4]  R695      5.4704319685697556e-02
    z[1,2,4]  R696      2.3262333869934082e-01
    z[1,2,4]  R697      -2.5647675991058350e-01
    z[1,2,4]  R698      8.6517877876758575e-02
    z[1,2,4]  R699      5.6493538618087769e-01
    z[1,2,4]  R700      0.00974711962044239
    z[1,2,4]  R701      4.3350827693939209e-01
    z[1,2,4]  R702      1.5536113083362579e-01
    z[1,2,4]  R703      -8.9821442961692810e-02
    z[1,2,4]  R704      6.9815821945667267e-02
    z[1,2,4]  R705      -3.7721905112266541e-01
    z[1,2,4]  R706      7.5825735926628113e-02
    z[1,2,4]  R707      1.9991464912891388e-01
    z[1,2,4]  R708      4.4819310307502747e-01
    z[1,2,4]  R709      4.4935014843940735e-01
    z[1,2,4]  R710      -7.5711631774902344e-01
    z[1,2,4]  R711      3.1309577822685242e-01
    z[1,2,4]  R712      8.7982267141342163e-02
    z[1,2,4]  R713      4.1028323769569397e-01
    z[1,2,4]  R714      -1.1457324773073196e-01
    z[1,2,4]  R715      2.8668063879013062e-01
    z[1,2,4]  R716      3.5323154926300049e-01
    z[1,2,4]  R717      -2.6967665553092957e-01
    z[1,2,4]  R718      -1.3486875593662262e-01
    z[1,2,4]  R719      3.0621844530105591e-01
    z[1,2,4]  R720      3.8816508650779724e-01
    z[1,2,4]  R721      6.6257226467132568e-01
    z[1,2,4]  R722      -2.9584395885467529e-01
    z[1,2,4]  R723      5.8784645795822144e-01
    z[1,2,4]  R724      1.3013081252574921e-01
    z[1,2,4]  R725      -3.3607015013694763e-01
    z[1,2,4]  R726      4.4919040054082870e-02
    z[1,2,4]  R727      -2.5752422213554382e-01
    z[1,2,4]  R728      -1.4710766077041626e-01
    z[1,2,4]  R729      -6.0857083648443222e-02
    z[1,2,4]  R730      -4.1886419057846069e-01
    z[1,2,4]  R731      -2.7050018310546875e-01
    z[1,2,4]  R732      -0.0910007506608963
    z[1,2,4]  R733      1.0590924322605133e-01
    z[1,2,4]  R734      -9.0013951063156128e-02
    z[1,2,4]  R735      -2.6118251681327820e-01
    z[1,2,4]  R736      0.267488956451416
    z[1,2,4]  R737      -2.1014265716075897e-01
    z[1,2,4]  R738      1.6813451051712036e-01
    z[1,2,4]  R739      -1.6713267564773560e-01
    z[1,2,4]  R740      -0.00890843104571104
    z[1,2,4]  R741      1.3897763192653656e-01
    z[1,2,4]  R742      1.1517754197120667e-01
    z[1,2,4]  R743      1.5052539110183716e-01
    z[1,2,4]  R744      4.7526782751083374e-01
    z[1,2,4]  R745      -5.2258223295211792e-01
    z[1,2,4]  R746      6.3477098941802979e-01
    z[1,2,4]  R747      -9.3176737427711487e-02
    z[1,2,4]  R748      -1.1465954780578613e-01
    z[1,2,4]  R749      4.3941894173622131e-01
    z[1,2,4]  R750      -1.8070462346076965e-01
    z[1,2,4]  R751      -3.7156096100807190e-01
    z[1,2,4]  R752      -2.0955021679401398e-01
    z[1,2,4]  R753      -3.6808863282203674e-01
    z[1,2,5]  R16       -1
    z[1,2,5]  R25       1
    z[1,2,5]  R661      -1
    z[1,2,5]  R662      1
    z[1,2,5]  R665      6.4826227724552155e-02
    z[1,2,5]  R666      -3.6471477150917053e-01
    z[1,2,5]  R667      -1.2993569672107697e-01
    z[1,2,5]  R668      1.7994967103004456e-01
    z[1,2,5]  R669      3.3526977896690369e-01
    z[1,2,5]  R670      -9.7117766737937927e-02
    z[1,2,5]  R671      -2.2050876915454865e-01
    z[1,2,5]  R672      8.6020655930042267e-02
    z[1,2,5]  R673      5.7687617838382721e-02
    z[1,2,5]  R674      0.306393027305603
    z[1,2,5]  R675      4.8279735445976257e-01
    z[1,2,5]  R676      4.7796574234962463e-01
    z[1,2,5]  R677      -6.6919738054275513e-01
    z[1,2,5]  R678      -4.2582523822784424e-01
    z[1,2,5]  R679      -5.5297189950942993e-01
    z[1,2,5]  R680      -1.5411454439163208e-01
    z[1,2,5]  R681      3.0449718236923218e-01
    z[1,2,5]  R682      -1.1277583241462708e-01
    z[1,2,5]  R683      -7.4774503707885742e-01
    z[1,2,5]  R684      -6.0351870954036713e-02
    z[1,2,5]  R685      2.8867387771606445e-01
    z[1,2,5]  R686      3.3210732042789459e-02
    z[1,2,5]  R687      -2.9398688673973083e-01
    z[1,2,5]  R688      2.9158812761306763e-01
    z[1,2,5]  R689      3.6807906627655029e-01
    z[1,2,5]  R690      1.7831854522228241e-01
    z[1,2,5]  R691      -2.4189151823520660e-02
    z[1,2,5]  R692      3.1507951207458973e-03
    z[1,2,5]  R693      -9.9269665777683258e-02
    z[1,2,5]  R694      -5.3119486570358276e-01
    z[1,2,5]  R695      -7.1827238798141479e-01
    z[1,2,5]  R696      -4.0602588653564453e-01
    z[1,2,5]  R697      -0.578844428062439
    z[1,2,5]  R698      -2.2811302542686462e-01
    z[1,2,5]  R699      -4.8963002860546112e-02
    z[1,2,5]  R700      -1.6502182185649872e-01
    z[1,2,5]  R701      -6.3835185766220093e-01
    z[1,2,5]  R702      2.0172986388206482e-01
    z[1,2,5]  R703      1.1101662367582321e-01
    z[1,2,5]  R704      2.6964783668518066e-01
    z[1,2,5]  R705      1.0752414911985397e-01
    z[1,2,5]  R706      -2.2847658395767212e-01
    z[1,2,5]  R707      2.9388007521629333e-01
    z[1,2,5]  R708      2.6284396648406982e-01
    z[1,2,5]  R709      1.8035946786403656e-01
    z[1,2,5]  R710      -2.6458916068077087e-01
    z[1,2,5]  R711      -1.8782602250576019e-01
    z[1,2,5]  R712      7.1179017424583435e-02
    z[1,2,5]  R713      1.4700101315975189e-01
    z[1,2,5]  R714      4.8983491957187653e-02
    z[1,2,5]  R715      -4.3268904089927673e-01
    z[1,2,5]  R716      4.4912725687026978e-02
    z[1,2,5]  R717      3.6912506818771362e-01
    z[1,2,5]  R718      -1.0355526208877563e-01
    z[1,2,5]  R719      -2.3538687825202942e-01
    z[1,2,5]  R720      2.3491522669792175e-01
    z[1,2,5]  R721      -9.9665679037570953e-02
    z[1,2,5]  R722      8.0978050827980042e-02
    z[1,2,5]  R723      4.3259942531585693e-01
    z[1,2,5]  R724      6.2491351366043091e-01
    z[1,2,5]  R725      -1.2104964256286621e-01
    z[1,2,5]  R726      -1.2605790980160236e-02
    z[1,2,5]  R727      1.3747389614582062e-01
    z[1,2,5]  R728      2.0527207851409912e-01
    z[1,2,5]  R729      3.8007053732872009e-01
    z[1,2,5]  R730      3.0109593272209167e-01
    z[1,2,5]  R731      -3.2173928618431091e-01
    z[1,2,5]  R732      2.9975953698158264e-01
    z[1,2,5]  R733      3.4868037700653076e-01
    z[1,2,5]  R734      2.1847660839557648e-01
    z[1,2,5]  R735      -1.3078860938549042e-01
    z[1,2,5]  R736      -4.5007985830307007e-01
    z[1,2,5]  R737      -1.0398718714714050e-01
    z[1,2,5]  R738      -1.8376775085926056e-01
    z[1,2,5]  R739      -0.0701352059841156
    z[1,2,5]  R740      -2.6097044348716736e-01
    z[1,2,5]  R741      -2.7366024255752563e-01
    z[1,2,5]  R742      -0.0517178550362587
    z[1,2,5]  R743      -0.257789671421051
    z[1,2,5]  R744      1.8757749348878860e-02
    z[1,2,5]  R745      -2.3568439483642578e-01
    z[1,2,5]  R746      -4.6486797928810120e-01
    z[1,2,5]  R747      8.8016845285892487e-02
    z[1,2,5]  R748      -2.8265652060508728e-01
    z[1,2,5]  R749      -1.3760939240455627e-02
    z[1,2,5]  R750      3.7209907174110413e-01
    z[1,2,5]  R751      1.3777013123035431e-01
    z[1,2,5]  R752      -7.4434436857700348e-02
    z[1,2,5]  R753      2.9123359918594360e-01
    z[1,2,6]  R17       -1
    z[1,2,6]  R26       1
    z[1,2,6]  R663      -1
    z[1,2,6]  R664      1
    z[1,2,6]  R665      -3.3042957074940205e-03
    z[1,2,6]  R666      -1.6233417391777039e-01
    z[1,2,6]  R667      2.0560391247272491e-01
    z[1,2,6]  R668      -1.4235657453536987e-01
    z[1,2,6]  R669      -2.6263710856437683e-01
    z[1,2,6]  R670      -2.2393219172954559e-01
    z[1,2,6]  R671      -2.4934880435466766e-01
    z[1,2,6]  R672      -2.0466949790716171e-02
    z[1,2,6]  R673      -1.0608077049255371e-01
    z[1,2,6]  R674      2.5520170107483864e-02
    z[1,2,6]  R675      6.1196144670248032e-02
    z[1,2,6]  R676      -1.9799458980560303e-01
    z[1,2,6]  R677      -1.6837205737829208e-02
    z[1,2,6]  R678      -2.9608628153800964e-01
    z[1,2,6]  R679      4.5811015367507935e-01
    z[1,2,6]  R680      5.9624046087265015e-01
    z[1,2,6]  R681      6.6907656192779541e-01
    z[1,2,6]  R682      -5.5441600084304810e-01
    z[1,2,6]  R683      -1.9777742028236389e-01
    z[1,2,6]  R684      -4.0725570917129517e-01
    z[1,2,6]  R685      3.9133498072624207e-01
    z[1,2,6]  R686      1.6450621187686920e-01
    z[1,2,6]  R687      5.8892941474914551e-01
    z[1,2,6]  R688      3.7337329983711243e-01
    z[1,2,6]  R689      2.2634324431419373e-01
    z[1,2,6]  R690      1.3039888441562653e-01
    z[1,2,6]  R691      4.8245757818222046e-01
    z[1,2,6]  R692      1.7120416462421417e-01
    z[1,2,6]  R693      -1.6910965740680695e-01
    z[1,2,6]  R694      5.0452504307031631e-02
    z[1,2,6]  R695      -1.5364871360361576e-02
    z[1,2,6]  R696      -5.8263218402862549e-01
    z[1,2,6]  R697      2.1156400442123413e-01
    z[1,2,6]  R698      -1.5903815627098083e-01
    z[1,2,6]  R699      -3.2536724209785461e-01
    z[1,2,6]  R700      -1.0116910934448242e-01
    z[1,2,6]  R701      1.5987172955647111e-03
    z[1,2,6]  R702      -2.2914621978998184e-02
    z[1,2,6]  R703      -1.2541098892688751e-01
    z[1,2,6]  R704      -2.0352834463119507e-01
    z[1,2,6]  R705      1.5120458602905273e-01
    z[1,2,6]  R706      2.5487518310546875e-01
    z[1,2,6]  R707      4.2553195357322693e-01
    z[1,2,6]  R708      -2.9079419374465942e-01
    z[1,2,6]  R709      -2.0165875554084778e-01
    z[1,2,6]  R710      7.7225565910339355e-02
    z[1,2,6]  R711      -2.1157729625701904e-01
    z[1,2,6]  R712      -6.6531932353973389e-01
    z[1,2,6]  R713      7.1661704778671265e-01
    z[1,2,6]  R714      -3.7990954518318176e-01
    z[1,2,6]  R715      -0.0680527314543724
    z[1,2,6]  R716      4.9775806069374084e-01
    z[1,2,6]  R717      3.8639616966247559e-01
    z[1,2,6]  R718      1.8866670131683350e-01
    z[1,2,6]  R719      2.4863265454769135e-01
    z[1,2,6]  R720      -0.175812765955925
    z[1,2,6]  R721      1.7377892136573792e-01
    z[1,2,6]  R722      4.2417564988136292e-01
    z[1,2,6]  R723      1.2433759123086929e-01
    z[1,2,6]  R724      1.7381101846694946e-01
    z[1,2,6]  R725      -1.6165116429328918e-01
    z[1,2,6]  R726      5.0855990499258041e-02
    z[1,2,6]  R727      -1.2389753758907318e-01
    z[1,2,6]  R728      -1.3846738636493683e-01
    z[1,2,6]  R729      1.7432193458080292e-01
    z[1,2,6]  R730      -2.1570816636085510e-01
    z[1,2,6]  R731      8.8239498436450958e-03
    z[1,2,6]  R732      -1.3048341870307922e-01
    z[1,2,6]  R733      7.9777045175433159e-03
    z[1,2,6]  R734      7.3663994669914246e-02
    z[1,2,6]  R735      7.0254206657409668e-01
    z[1,2,6]  R736      -3.7165313959121704e-01
    z[1,2,6]  R737      2.5277087092399597e-01
    z[1,2,6]  R738      2.8222542256116867e-02
    z[1,2,6]  R739      -1.1257118545472622e-02
    z[1,2,6]  R740      1.7796604335308075e-01
    z[1,2,6]  R741      -7.2849661111831665e-02
    z[1,2,6]  R742      9.3854013830423355e-03
    z[1,2,6]  R743      -3.1947249174118042e-01
    z[1,2,6]  R744      -0.0979093536734581
    z[1,2,6]  R745      2.2815231233835220e-02
    z[1,2,6]  R746      3.8587224483489990e-01
    z[1,2,6]  R747      -8.4345191717147827e-02
    z[1,2,6]  R748      -1.2673306465148926e-01
    z[1,2,6]  R749      7.6837375760078430e-02
    z[1,2,6]  R750      -5.8577362447977066e-02
    z[1,2,6]  R751      -2.1849749982357025e-01
    z[1,2,6]  R752      -3.4982562065124512e-01
    z[1,2,6]  R753      9.2579156160354614e-02
    z[2,1,0]  R11       1
    z[2,1,0]  R20       -1
    z[2,1,0]  R754      -1
    z[2,1,0]  R755      1
    z[2,1,0]  R768      1.7375077307224274e-01
    z[2,1,0]  R769      1.0416479408740997e-01
    z[2,1,0]  R770      3.5076405853033066e-02
    z[2,1,0]  R771      1.1815072596073151e-01
    z[2,1,0]  R772      1.3126258552074432e-01
    z[2,1,0]  R773      4.0457978844642639e-02
    z[2,1,0]  R774      -3.9107404649257660e-02
    z[2,1,0]  R775      -7.3462487198412418e-03
    z[2,1,0]  R776      -2.0507071912288666e-01
    z[2,1,0]  R777      5.1161199808120728e-02
    z[2,1,0]  R778      -5.0340861082077026e-02
    z[2,1,0]  R779      1.0358274728059769e-01
    z[2,1,0]  R780      -1.6905583441257477e-02
    z[2,1,0]  R781      1.8200548365712166e-02
    z[2,1,0]  R782      -1.5195293724536896e-01
    z[2,1,0]  R783      -1.0875476151704788e-01
    z[2,1,0]  R784      -1.0530030727386475e-01
    z[2,1,0]  R785      -1.1921381205320358e-01
    z[2,1,0]  R786      -9.4531789422035217e-02
    z[2,1,0]  R787      -9.7032509744167328e-02
    z[2,1,0]  R788      -1.1137016862630844e-01
    z[2,1,0]  R789      -1.5104120969772339e-01
    z[2,1,0]  R790      -8.7838634848594666e-02
    z[2,1,0]  R791      -9.9680311977863312e-02
    z[2,1,0]  R792      -1.4754776656627655e-01
    z[2,1,0]  R793      -6.5765053033828735e-02
    z[2,1,0]  R794      -1.2139682471752167e-01
    z[2,1,0]  R795      2.1158248186111450e-02
    z[2,1,0]  R796      -1.4087593555450439e-01
    z[2,1,0]  R797      9.5251291990280151e-02
    z[2,1,0]  R798      -0.0731421485543251
    z[2,1,0]  R799      -1.8635485321283340e-02
    z[2,1,0]  R800      -1.7498539388179779e-01
    z[2,1,0]  R801      -1.8789456784725189e-01
    z[2,1,0]  R802      -2.5243632495403290e-02
    z[2,1,0]  R803      -5.5284440517425537e-02
    z[2,1,0]  R804      -6.9861665368080139e-02
    z[2,1,0]  R805      8.2318651676177979e-01
    z[2,1,0]  R806      -5.5996431037783623e-03
    z[2,1,0]  R807      -8.5662461817264557e-02
    z[2,1,0]  R808      -3.8488205522298813e-02
    z[2,1,0]  R809      -9.2685915529727936e-02
    z[2,1,0]  R810      -1.4319211244583130e-01
    z[2,1,0]  R811      -1.0172440856695175e-01
    z[2,1,0]  R812      -8.5732407867908478e-02
    z[2,1,0]  R813      6.5032929182052612e-01
    z[2,1,0]  R814      6.3057667016983032e-01
    z[2,1,0]  R815      6.4594465494155884e-01
    z[2,1,0]  R816      7.2314405441284180e-01
    z[2,1,0]  R817      -1.3894502818584442e-01
    z[2,1,0]  R818      1.3602147996425629e-01
    z[2,1,0]  R819      -9.3008416891098022e-01
    z[2,1,0]  R820      -8.4046369791030884e-01
    z[2,1,0]  R821      -7.8733968734741211e-01
    z[2,1,0]  R822      -8.8880550861358643e-01
    z[2,1,0]  R823      -9.0660637617111206e-01
    z[2,1,0]  R824      -8.6132991313934326e-01
    z[2,1,0]  R825      -7.4839603900909424e-01
    z[2,1,0]  R826      -9.2447394132614136e-01
    z[2,1,0]  R827      -6.3099667429924011e-02
    z[2,1,0]  R828      4.1129431128501892e-01
    z[2,1,0]  R829      -3.1831058859825134e-01
    z[2,1,0]  R830      4.7566571831703186e-01
    z[2,1,0]  R831      -1.3901624083518982e-01
    z[2,1,0]  R832      -4.0207871794700623e-01
    z[2,1,0]  R833      3.2552149891853333e-01
    z[2,1,0]  R834      5.9157520532608032e-01
    z[2,1,0]  R835      8.1628121435642242e-02
    z[2,1,0]  R836      8.0147922039031982e-01
    z[2,1,0]  R837      -3.5144484043121338e-01
    z[2,1,0]  R838      -1.4187182486057281e-01
    z[2,1,0]  R839      2.7030315995216370e-01
    z[2,1,0]  R840      2.3140832781791687e-02
    z[2,1,0]  R841      8.6315566301345825e-01
    z[2,1,0]  R842      8.6348617076873779e-01
    z[2,1,0]  R843      8.1512153148651123e-01
    z[2,1,0]  R844      8.0033266544342041e-01
    z[2,1,0]  R845      7.6406925916671753e-01
    z[2,1,0]  R846      0.789068341255188
    z[2,1,0]  R847      4.6590375900268555e-01
    z[2,1,0]  R848      1.5367440879344940e-01
    z[2,1,0]  R849      3.1646621227264404e-01
    z[2,1,0]  R850      5.1167792081832886e-01
    z[2,1,0]  R851      -5.7876616716384888e-01
    z[2,1,0]  R852      9.7735965251922607e-01
    z[2,1,0]  R853      -5.6773281097412109e-01
    z[2,1,0]  R854      -1.3762372732162476e-01
    z[2,1,0]  R855      2.2838750854134560e-02
    z[2,1,0]  R856      2.4538686871528625e-01
    z[2,1,1]  R12       1
    z[2,1,1]  R21       -1
    z[2,1,1]  R756      -1
    z[2,1,1]  R757      1
    z[2,1,1]  R768      -0.188704252243042
    z[2,1,1]  R769      -2.4665230512619019e-01
    z[2,1,1]  R770      -7.5864009559154510e-02
    z[2,1,1]  R771      -1.4523386955261230e-01
    z[2,1,1]  R772      3.9027415215969086e-02
    z[2,1,1]  R773      3.2125559449195862e-01
    z[2,1,1]  R774      -8.7640094757080078e-01
    z[2,1,1]  R775      2.4323654174804688e-01
    z[2,1,1]  R776      -7.8582540154457092e-02
    z[2,1,1]  R777      9.0698373317718506e-01
    z[2,1,1]  R778      7.7767539024353027e-01
    z[2,1,1]  R779      7.6909792423248291e-01
    z[2,1,1]  R780      7.4120289087295532e-01
    z[2,1,1]  R781      0.731759786605835
    z[2,1,1]  R782      6.7997241020202637e-01
    z[2,1,1]  R783      6.6865491867065430e-01
    z[2,1,1]  R784      0.649121105670929
    z[2,1,1]  R785      0.642539918422699
    z[2,1,1]  R786      6.3295543193817139e-01
    z[2,1,1]  R787      5.9669071435928345e-01
    z[2,1,1]  R788      -1.3306954503059387e-01
    z[2,1,1]  R789      -5.5064046382904053e-01
    z[2,1,1]  R790      -0.590140163898468
    z[2,1,1]  R791      -4.8204281926155090e-01
    z[2,1,1]  R792      -3.4903496503829956e-01
    z[2,1,1]  R793      -2.7629068493843079e-01
    z[2,1,1]  R794      -4.7363707423210144e-01
    z[2,1,1]  R795      -9.0629106760025024e-01
    z[2,1,1]  R796      -5.0873714685440063e-01
    z[2,1,1]  R797      8.0913090705871582e-01
    z[2,1,1]  R798      6.0107976198196411e-01
    z[2,1,1]  R799      5.5919289588928223e-01
    z[2,1,1]  R800      -1.8453678488731384e-01
    z[2,1,1]  R801      -2.1710814535617828e-01
    z[2,1,1]  R802      -9.4162505865097046e-01
    z[2,1,1]  R803      -9.0053504705429077e-01
    z[2,1,1]  R804      -8.9092463254928589e-01
    z[2,1,1]  R805      -5.0908583402633667e-01
    z[2,1,1]  R806      -8.8902920484542847e-01
    z[2,1,1]  R807      8.2013344764709473e-01
    z[2,1,1]  R808      6.7155414819717407e-01
    z[2,1,1]  R809      4.3844765424728394e-01
    z[2,1,1]  R810      -9.7919665277004242e-02
    z[2,1,1]  R811      -5.9339928627014160e-01
    z[2,1,1]  R812      -8.5561513900756836e-01
    z[2,1,1]  R813      -5.1422142982482910e-01
    z[2,1,1]  R814      -5.1929527521133423e-01
    z[2,1,1]  R815      -0.442984014749527
    z[2,1,1]  R816      -2.8734889626502991e-01
    z[2,1,1]  R817      4.5714911073446274e-02
    z[2,1,1]  R818      9.5595233142375946e-02
    z[2,1,1]  R819      -1.5452742576599121e-01
    z[2,1,1]  R820      -3.0428934097290039e-01
    z[2,1,1]  R821      -1.7054866254329681e-01
    z[2,1,1]  R822      -2.4879324436187744e-01
    z[2,1,1]  R823      -2.3625767230987549e-01
    z[2,1,1]  R824      -2.0802576839923859e-01
    z[2,1,1]  R825      -2.8309798240661621e-01
    z[2,1,1]  R826      8.6726211011409760e-02
    z[2,1,1]  R827      6.4761382341384888e-01
    z[2,1,1]  R828      0.524172842502594
    z[2,1,1]  R829      4.9181440472602844e-01
    z[2,1,1]  R830      1.8394406139850616e-01
    z[2,1,1]  R831      1.9864578545093536e-01
    z[2,1,1]  R832      3.9298623800277710e-01
    z[2,1,1]  R833      4.8723950982093811e-01
    z[2,1,1]  R834      3.2236889004707336e-01
    z[2,1,1]  R835      1.7612237483263016e-02
    z[2,1,1]  R836      1.1396908015012741e-01
    z[2,1,1]  R837      6.6057032346725464e-01
    z[2,1,1]  R838      0.470954954624176
    z[2,1,1]  R839      4.3172460794448853e-01
    z[2,1,1]  R840      4.9238261580467224e-01
    z[2,1,1]  R841      1.4013834297657013e-01
    z[2,1,1]  R842      2.7400064468383789e-01
    z[2,1,1]  R843      1.6780835390090942e-01
    z[2,1,1]  R844      -4.7978889197111130e-02
    z[2,1,1]  R845      -2.1913725137710571e-01
    z[2,1,1]  R846      1.0546435415744781e-01
    z[2,1,1]  R847      2.3242063820362091e-01
    z[2,1,1]  R848      6.2136089801788330e-01
    z[2,1,1]  R849      5.8741199970245361e-01
    z[2,1,1]  R850      5.3919184207916260e-01
    z[2,1,1]  R851      3.9454418420791626e-01
    z[2,1,1]  R852      3.5307902842760086e-02
    z[2,1,1]  R853      3.3526644110679626e-02
    z[2,1,1]  R854      -9.3011397123336792e-01
    z[2,1,1]  R855      -9.3885004520416260e-01
    z[2,1,1]  R856      -8.6740863323211670e-01
    z[2,1,2]  R13       1
    z[2,1,2]  R22       -1
    z[2,1,2]  R758      -1
    z[2,1,2]  R759      1
    z[2,1,2]  R768      -4.4951781630516052e-01
    z[2,1,2]  R769      -5.7896214723587036e-01
    z[2,1,2]  R770      -7.5325781106948853e-01
    z[2,1,2]  R771      -6.0198068618774414e-01
    z[2,1,2]  R772      2.7803765609860420e-02
    z[2,1,2]  R773      4.9266871809959412e-01
    z[2,1,2]  R774      1.9959209859371185e-01
    z[2,1,2]  R775      6.3347554206848145e-01
    z[2,1,2]  R776      3.4610655903816223e-01
    z[2,1,2]  R777      -9.4338893890380859e-02
    z[2,1,2]  R778      -2.8370854258537292e-01
    z[2,1,2]  R779      1.4953862130641937e-01
    z[2,1,2]  R780      2.9757255315780640e-01
    z[2,1,2]  R781      5.3267461061477661e-01
    z[2,1,2]  R782      4.1305556893348694e-01
    z[2,1,2]  R783      1.0275747627019882e-01
    z[2,1,2]  R784      2.9723986983299255e-01
    z[2,1,2]  R785      2.5612899661064148e-01
    z[2,1,2]  R786      1.3214507699012756e-01
    z[2,1,2]  R787      8.6175657808780670e-02
    z[2,1,2]  R788      4.3202412128448486e-01
    z[2,1,2]  R789      4.8419484496116638e-01
    z[2,1,2]  R790      3.3047696948051453e-01
    z[2,1,2]  R791      5.3097373247146606e-01
    z[2,1,2]  R792      4.6801841259002686e-01
    z[2,1,2]  R793      2.5067463517189026e-01
    z[2,1,2]  R794      3.1835344433784485e-01
    z[2,1,2]  R795      2.5098061561584473e-01
    z[2,1,2]  R796      1.9846871495246887e-01
    z[2,1,2]  R797      2.8659293428063393e-02
    z[2,1,2]  R798      -2.0808011293411255e-01
    z[2,1,2]  R799      5.2410387992858887e-01
    z[2,1,2]  R800      0.0869893953204155
    z[2,1,2]  R801      4.6075470745563507e-02
    z[2,1,2]  R802      -9.9441379308700562e-02
    z[2,1,2]  R803      2.8549528121948242e-01
    z[2,1,2]  R804      1.1278945207595825e-01
    z[2,1,2]  R805      4.9462612718343735e-02
    z[2,1,2]  R806      -1.4428270515054464e-03
    z[2,1,2]  R807      1.0920712351799011e-01
    z[2,1,2]  R808      2.8010737895965576e-01
    z[2,1,2]  R809      2.0575119182467461e-02
    z[2,1,2]  R810      -0.0702795684337616
    z[2,1,2]  R811      -0.0913701057434082
    z[2,1,2]  R812      2.1251454949378967e-01
    z[2,1,2]  R813      2.9008436203002930e-01
    z[2,1,2]  R814      3.0944174528121948e-01
    z[2,1,2]  R815      4.6052265167236328e-01
    z[2,1,2]  R816      -8.3492629230022430e-02
    z[2,1,2]  R817      -3.4589764475822449e-01
    z[2,1,2]  R818      6.7459084093570709e-02
    z[2,1,2]  R819      -3.8910549134016037e-02
    z[2,1,2]  R820      -2.6638289913535118e-02
    z[2,1,2]  R821      -4.0393546223640442e-01
    z[2,1,2]  R822      1.1216019839048386e-01
    z[2,1,2]  R823      8.4725886583328247e-02
    z[2,1,2]  R824      -2.9832099098712206e-03
    z[2,1,2]  R825      -2.7745479345321655e-01
    z[2,1,2]  R826      -3.1092030927538872e-02
    z[2,1,2]  R827      4.8684078454971313e-01
    z[2,1,2]  R828      -4.1123846173286438e-01
    z[2,1,2]  R829      2.3864111304283142e-01
    z[2,1,2]  R830      -2.2743576765060425e-01
    z[2,1,2]  R831      -5.5330187082290649e-01
    z[2,1,2]  R832      -4.2811136692762375e-02
    z[2,1,2]  R833      -6.3877038657665253e-02
    z[2,1,2]  R834      4.2054817080497742e-01
    z[2,1,2]  R835      -4.1802123188972473e-01
    z[2,1,2]  R836      8.6916297674179077e-02
    z[2,1,2]  R837      -1.8759422004222870e-01
    z[2,1,2]  R838      6.2493032217025757e-01
    z[2,1,2]  R839      1.5951023995876312e-01
    z[2,1,2]  R840      -3.9223572611808777e-01
    z[2,1,2]  R841      -1.4474473893642426e-02
    z[2,1,2]  R842      -0.140329509973526
    z[2,1,2]  R843      1.3617476820945740e-01
    z[2,1,2]  R844      -1.8472173810005188e-01
    z[2,1,2]  R845      2.9430523514747620e-01
    z[2,1,2]  R846      -6.5737059339880943e-03
    z[2,1,2]  R847      -3.7296712398529053e-01
    z[2,1,2]  R848      6.6249914467334747e-02
    z[2,1,2]  R849      2.2753553465008736e-02
    z[2,1,2]  R850      -2.7140554785728455e-01
    z[2,1,2]  R851      -2.4743634462356567e-01
    z[2,1,2]  R852      3.6267023533582687e-02
    z[2,1,2]  R853      -1.7865149676799774e-01
    z[2,1,2]  R854      1.5413431823253632e-01
    z[2,1,2]  R855      2.7333769202232361e-01
    z[2,1,2]  R856      2.0702511072158813e-01
    z[2,1,3]  R14       1
    z[2,1,3]  R23       -1
    z[2,1,3]  R760      -1
    z[2,1,3]  R761      1
    z[2,1,3]  R768      -7.4526280164718628e-01
    z[2,1,3]  R769      -6.8571335077285767e-01
    z[2,1,3]  R770      -3.4381410479545593e-01
    z[2,1,3]  R771      -4.9803760647773743e-01
    z[2,1,3]  R772      -8.3985865116119385e-01
    z[2,1,3]  R773      -0.0569143183529377
    z[2,1,3]  R774      1.1172537505626678e-01
    z[2,1,3]  R775      2.8988546133041382e-01
    z[2,1,3]  R776      3.5846811532974243e-01
    z[2,1,3]  R777      7.7495403587818146e-02
    z[2,1,3]  R778      1.9534422457218170e-01
    z[2,1,3]  R779      2.9060753062367439e-02
    z[2,1,3]  R780      -5.9179320931434631e-02
    z[2,1,3]  R781      -3.4050792455673218e-01
    z[2,1,3]  R782      3.6460673809051514e-01
    z[2,1,3]  R783      5.4198390245437622e-01
    z[2,1,3]  R784      0.00823516957461834
    z[2,1,3]  R785      4.8303452134132385e-01
    z[2,1,3]  R786      1.5749073028564453e-01
    z[2,1,3]  R787      4.3526706099510193e-01
    z[2,1,3]  R788      7.9342108964920044e-01
    z[2,1,3]  R789      6.5937399864196777e-01
    z[2,1,3]  R790      6.5896546840667725e-01
    z[2,1,3]  R791      6.2674939632415771e-01
    z[2,1,3]  R792      6.7736089229583740e-01
    z[2,1,3]  R793      7.3747175931930542e-01
    z[2,1,3]  R794      6.9485068321228027e-01
    z[2,1,3]  R795      -5.8983918279409409e-03
    z[2,1,3]  R796      7.4100762605667114e-01
    z[2,1,3]  R797      -5.2359545230865479e-01
    z[2,1,3]  R798      1.0568166524171829e-01
    z[2,1,3]  R799      -4.7711357474327087e-03
    z[2,1,3]  R800      0.899384617805481
    z[2,1,3]  R801      9.2336362600326538e-01
    z[2,1,3]  R802      2.6426756381988525e-01
    z[2,1,3]  R803      6.7940421402454376e-02
    z[2,1,3]  R804      2.9856231808662415e-01
    z[2,1,3]  R805      2.1147172152996063e-01
    z[2,1,3]  R806      1.3571204245090485e-01
    z[2,1,3]  R807      2.6888519525527954e-01
    z[2,1,3]  R808      3.7405043840408325e-01
    z[2,1,3]  R809      -1.7554442584514618e-01
    z[2,1,3]  R810      9.7027087211608887e-01
    z[2,1,3]  R811      7.2116440534591675e-01
    z[2,1,3]  R812      1.2738877534866333e-01
    z[2,1,3]  R813      0.232284277677536
    z[2,1,3]  R814      1.7936527729034424e-01
    z[2,1,3]  R815      5.1085177809000015e-02
    z[2,1,3]  R816      3.9830267429351807e-01
    z[2,1,3]  R817      -9.1660672426223755e-01
    z[2,1,3]  R818      -8.1101936101913452e-01
    z[2,1,3]  R819      -4.3476864695549011e-02
    z[2,1,3]  R820      -1.2680803239345551e-01
    z[2,1,3]  R821      -7.1115955710411072e-02
    z[2,1,3]  R822      -2.5599592924118042e-01
    z[2,1,3]  R823      3.2942626625299454e-02
    z[2,1,3]  R824      -0.411723792552948
    z[2,1,3]  R825      -4.6243837475776672e-01
    z[2,1,3]  R826      -3.5735196433961391e-03
    z[2,1,3]  R827      -1.7720645666122437e-01
    z[2,1,3]  R828      -4.6511989086866379e-02
    z[2,1,3]  R829      1.3114874064922333e-01
    z[2,1,3]  R830      2.3564623668789864e-02
    z[2,1,3]  R831      1.1789546906948090e-01
    z[2,1,3]  R832      3.9691349864006042e-01
    z[2,1,3]  R833      2.0991069078445435e-01
    z[2,1,3]  R834      1.3820931315422058e-01
    z[2,1,3]  R835      1.0030884295701981e-01
    z[2,1,3]  R836      -1.2336043268442154e-01
    z[2,1,3]  R837      0.185865581035614
    z[2,1,3]  R838      3.3921965956687927e-01
    z[2,1,3]  R839      -2.6427122950553894e-01
    z[2,1,3]  R840      1.5687417984008789e-01
    z[2,1,3]  R841      1.2083962559700012e-01
    z[2,1,3]  R842      0.269723504781723
    z[2,1,3]  R843      -1.8055105209350586e-01
    z[2,1,3]  R844      3.8706335425376892e-01
    z[2,1,3]  R845      1.7415404319763184e-01
    z[2,1,3]  R846      -1.6753622889518738e-01
    z[2,1,3]  R847      -2.6583081483840942e-01
    z[2,1,3]  R848      1.6575561463832855e-01
    z[2,1,3]  R849      3.2966342568397522e-01
    z[2,1,3]  R850      5.3757125139236450e-01
    z[2,1,3]  R851      1.4396762847900391e-01
    z[2,1,3]  R852      0.0681452751159668
    z[2,1,3]  R853      -2.2184237837791443e-01
    z[2,1,3]  R854      1.6380879282951355e-01
    z[2,1,3]  R855      8.4882482886314392e-02
    z[2,1,3]  R856      1.5975062549114227e-01
    z[2,1,4]  R15       1
    z[2,1,4]  R24       -1
    z[2,1,4]  R762      -1
    z[2,1,4]  R763      1
    z[2,1,4]  R768      -3.7721905112266541e-01
    z[2,1,4]  R769      7.5825735926628113e-02
    z[2,1,4]  R770      1.9991464912891388e-01
    z[2,1,4]  R771      4.4819310307502747e-01
    z[2,1,4]  R772      4.4935014843940735e-01
    z[2,1,4]  R773      -7.5711631774902344e-01
    z[2,1,4]  R774      3.1309577822685242e-01
    z[2,1,4]  R775      8.7982267141342163e-02
    z[2,1,4]  R776      4.1028323769569397e-01
    z[2,1,4]  R777      -1.1457324773073196e-01
    z[2,1,4]  R778      2.8668063879013062e-01
    z[2,1,4]  R779      3.5323154926300049e-01
    z[2,1,4]  R780      -2.6967665553092957e-01
    z[2,1,4]  R781      -1.3486875593662262e-01
    z[2,1,4]  R782      3.0621844530105591e-01
    z[2,1,4]  R783      3.8816508650779724e-01
    z[2,1,4]  R784      6.6257226467132568e-01
    z[2,1,4]  R785      -2.9584395885467529e-01
    z[2,1,4]  R786      5.8784645795822144e-01
    z[2,1,4]  R787      1.3013081252574921e-01
    z[2,1,4]  R788      -3.3607015013694763e-01
    z[2,1,4]  R789      4.4919040054082870e-02
    z[2,1,4]  R790      -2.5752422213554382e-01
    z[2,1,4]  R791      -1.4710766077041626e-01
    z[2,1,4]  R792      -6.0857083648443222e-02
    z[2,1,4]  R793      -4.1886419057846069e-01
    z[2,1,4]  R794      -2.7050018310546875e-01
    z[2,1,4]  R795      -0.0910007506608963
    z[2,1,4]  R796      1.0590924322605133e-01
    z[2,1,4]  R797      -9.0013951063156128e-02
    z[2,1,4]  R798      -2.6118251681327820e-01
    z[2,1,4]  R799      0.267488956451416
    z[2,1,4]  R800      -2.1014265716075897e-01
    z[2,1,4]  R801      1.6813451051712036e-01
    z[2,1,4]  R802      -1.6713267564773560e-01
    z[2,1,4]  R803      -0.00890843104571104
    z[2,1,4]  R804      1.3897763192653656e-01
    z[2,1,4]  R805      1.1517754197120667e-01
    z[2,1,4]  R806      1.5052539110183716e-01
    z[2,1,4]  R807      4.7526782751083374e-01
    z[2,1,4]  R808      -5.2258223295211792e-01
    z[2,1,4]  R809      6.3477098941802979e-01
    z[2,1,4]  R810      -9.3176737427711487e-02
    z[2,1,4]  R811      -1.1465954780578613e-01
    z[2,1,4]  R812      4.3941894173622131e-01
    z[2,1,4]  R813      -1.8070462346076965e-01
    z[2,1,4]  R814      -3.7156096100807190e-01
    z[2,1,4]  R815      -2.0955021679401398e-01
    z[2,1,4]  R816      -3.6808863282203674e-01
    z[2,1,4]  R817      1.2073950469493866e-01
    z[2,1,4]  R818      -3.8818454742431641e-01
    z[2,1,4]  R819      -2.2023659944534302e-01
    z[2,1,4]  R820      -0.362755686044693
    z[2,1,4]  R821      -3.7469755858182907e-02
    z[2,1,4]  R822      -1.0215345025062561e-01
    z[2,1,4]  R823      -5.6431770324707031e-02
    z[2,1,4]  R824      -1.9362926483154297e-01
    z[2,1,4]  R825      -2.3312574625015259e-01
    z[2,1,4]  R826      2.0571598410606384e-01
    z[2,1,4]  R827      2.6713365316390991e-01
    z[2,1,4]  R828      -3.4226661920547485e-01
    z[2,1,4]  R829      3.6679524183273315e-01
    z[2,1,4]  R830      6.4701634645462036e-01
    z[2,1,4]  R831      3.2485261559486389e-01
    z[2,1,4]  R832      3.8113960623741150e-01
    z[2,1,4]  R833      2.6097622513771057e-01
    z[2,1,4]  R834      1.7337530851364136e-01
    z[2,1,4]  R835      4.5824062824249268e-01
    z[2,1,4]  R836      3.9034643769264221e-01
    z[2,1,4]  R837      -3.6595097184181213e-01
    z[2,1,4]  R838      -4.7360396385192871e-01
    z[2,1,4]  R839      4.6043559908866882e-01
    z[2,1,4]  R840      0.595091700553894
    z[2,1,4]  R841      -1.8384316563606262e-01
    z[2,1,4]  R842      1.9511753320693970e-01
    z[2,1,4]  R843      -1.5140847861766815e-01
    z[2,1,4]  R844      -3.7934783101081848e-01
    z[2,1,4]  R845      -4.6128010749816895e-01
    z[2,1,4]  R846      2.3113496601581573e-01
    z[2,1,4]  R847      5.4704319685697556e-02
    z[2,1,4]  R848      2.3262333869934082e-01
    z[2,1,4]  R849      -2.5647675991058350e-01
    z[2,1,4]  R850      8.6517877876758575e-02
    z[2,1,4]  R851      5.6493538618087769e-01
    z[2,1,4]  R852      0.00974711962044239
    z[2,1,4]  R853      4.3350827693939209e-01
    z[2,1,4]  R854      1.5536113083362579e-01
    z[2,1,4]  R855      -8.9821442961692810e-02
    z[2,1,4]  R856      6.9815821945667267e-02
    z[2,1,5]  R16       1
    z[2,1,5]  R25       -1
    z[2,1,5]  R764      -1
    z[2,1,5]  R765      1
    z[2,1,5]  R768      1.0752414911985397e-01
    z[2,1,5]  R769      -2.2847658395767212e-01
    z[2,1,5]  R770      2.9388007521629333e-01
    z[2,1,5]  R771      2.6284396648406982e-01
    z[2,1,5]  R772      1.8035946786403656e-01
    z[2,1,5]  R773      -2.6458916068077087e-01
    z[2,1,5]  R774      -1.8782602250576019e-01
    z[2,1,5]  R775      7.1179017424583435e-02
    z[2,1,5]  R776      1.4700101315975189e-01
    z[2,1,5]  R777      4.8983491957187653e-02
    z[2,1,5]  R778      -4.3268904089927673e-01
    z[2,1,5]  R779      4.4912725687026978e-02
    z[2,1,5]  R780      3.6912506818771362e-01
    z[2,1,5]  R781      -1.0355526208877563e-01
    z[2,1,5]  R782      -2.3538687825202942e-01
    z[2,1,5]  R783      2.3491522669792175e-01
    z[2,1,5]  R784      -9.9665679037570953e-02
    z[2,1,5]  R785      8.0978050827980042e-02
    z[2,1,5]  R786      4.3259942531585693e-01
    z[2,1,5]  R787      6.2491351366043091e-01
    z[2,1,5]  R788      -1.2104964256286621e-01
    z[2,1,5]  R789      -1.2605790980160236e-02
    z[2,1,5]  R790      1.3747389614582062e-01
    z[2,1,5]  R791      2.0527207851409912e-01
    z[2,1,5]  R792      3.8007053732872009e-01
    z[2,1,5]  R793      3.0109593272209167e-01
    z[2,1,5]  R794      -3.2173928618431091e-01
    z[2,1,5]  R795      2.9975953698158264e-01
    z[2,1,5]  R796      3.4868037700653076e-01
    z[2,1,5]  R797      2.1847660839557648e-01
    z[2,1,5]  R798      -1.3078860938549042e-01
    z[2,1,5]  R799      -4.5007985830307007e-01
    z[2,1,5]  R800      -1.0398718714714050e-01
    z[2,1,5]  R801      -1.8376775085926056e-01
    z[2,1,5]  R802      -0.0701352059841156
    z[2,1,5]  R803      -2.6097044348716736e-01
    z[2,1,5]  R804      -2.7366024255752563e-01
    z[2,1,5]  R805      -0.0517178550362587
    z[2,1,5]  R806      -0.257789671421051
    z[2,1,5]  R807      1.8757749348878860e-02
    z[2,1,5]  R808      -2.3568439483642578e-01
    z[2,1,5]  R809      -4.6486797928810120e-01
    z[2,1,5]  R810      8.8016845285892487e-02
    z[2,1,5]  R811      -2.8265652060508728e-01
    z[2,1,5]  R812      -1.3760939240455627e-02
    z[2,1,5]  R813      3.7209907174110413e-01
    z[2,1,5]  R814      1.3777013123035431e-01
    z[2,1,5]  R815      -7.4434436857700348e-02
    z[2,1,5]  R816      2.9123359918594360e-01
    z[2,1,5]  R817      6.4826227724552155e-02
    z[2,1,5]  R818      -3.6471477150917053e-01
    z[2,1,5]  R819      -1.2993569672107697e-01
    z[2,1,5]  R820      1.7994967103004456e-01
    z[2,1,5]  R821      3.3526977896690369e-01
    z[2,1,5]  R822      -9.7117766737937927e-02
    z[2,1,5]  R823      -2.2050876915454865e-01
    z[2,1,5]  R824      8.6020655930042267e-02
    z[2,1,5]  R825      5.7687617838382721e-02
    z[2,1,5]  R826      0.306393027305603
    z[2,1,5]  R827      4.8279735445976257e-01
    z[2,1,5]  R828      4.7796574234962463e-01
    z[2,1,5]  R829      -6.6919738054275513e-01
    z[2,1,5]  R830      -4.2582523822784424e-01
    z[2,1,5]  R831      -5.5297189950942993e-01
    z[2,1,5]  R832      -1.5411454439163208e-01
    z[2,1,5]  R833      3.0449718236923218e-01
    z[2,1,5]  R834      -1.1277583241462708e-01
    z[2,1,5]  R835      -7.4774503707885742e-01
    z[2,1,5]  R836      -6.0351870954036713e-02
    z[2,1,5]  R837      2.8867387771606445e-01
    z[2,1,5]  R838      3.3210732042789459e-02
    z[2,1,5]  R839      -2.9398688673973083e-01
    z[2,1,5]  R840      2.9158812761306763e-01
    z[2,1,5]  R841      3.6807906627655029e-01
    z[2,1,5]  R842      1.7831854522228241e-01
    z[2,1,5]  R843      -2.4189151823520660e-02
    z[2,1,5]  R844      3.1507951207458973e-03
    z[2,1,5]  R845      -9.9269665777683258e-02
    z[2,1,5]  R846      -5.3119486570358276e-01
    z[2,1,5]  R847      -7.1827238798141479e-01
    z[2,1,5]  R848      -4.0602588653564453e-01
    z[2,1,5]  R849      -0.578844428062439
    z[2,1,5]  R850      -2.2811302542686462e-01
    z[2,1,5]  R851      -4.8963002860546112e-02
    z[2,1,5]  R852      -1.6502182185649872e-01
    z[2,1,5]  R853      -6.3835185766220093e-01
    z[2,1,5]  R854      2.0172986388206482e-01
    z[2,1,5]  R855      1.1101662367582321e-01
    z[2,1,5]  R856      2.6964783668518066e-01
    z[2,1,6]  R17       1
    z[2,1,6]  R26       -1
    z[2,1,6]  R766      -1
    z[2,1,6]  R767      1
    z[2,1,6]  R768      1.5120458602905273e-01
    z[2,1,6]  R769      2.5487518310546875e-01
    z[2,1,6]  R770      4.2553195357322693e-01
    z[2,1,6]  R771      -2.9079419374465942e-01
    z[2,1,6]  R772      -2.0165875554084778e-01
    z[2,1,6]  R773      7.7225565910339355e-02
    z[2,1,6]  R774      -2.1157729625701904e-01
    z[2,1,6]  R775      -6.6531932353973389e-01
    z[2,1,6]  R776      7.1661704778671265e-01
    z[2,1,6]  R777      -3.7990954518318176e-01
    z[2,1,6]  R778      -0.0680527314543724
    z[2,1,6]  R779      4.9775806069374084e-01
    z[2,1,6]  R780      3.8639616966247559e-01
    z[2,1,6]  R781      1.8866670131683350e-01
    z[2,1,6]  R782      2.4863265454769135e-01
    z[2,1,6]  R783      -0.175812765955925
    z[2,1,6]  R784      1.7377892136573792e-01
    z[2,1,6]  R785      4.2417564988136292e-01
    z[2,1,6]  R786      1.2433759123086929e-01
    z[2,1,6]  R787      1.7381101846694946e-01
    z[2,1,6]  R788      -1.6165116429328918e-01
    z[2,1,6]  R789      5.0855990499258041e-02
    z[2,1,6]  R790      -1.2389753758907318e-01
    z[2,1,6]  R791      -1.3846738636493683e-01
    z[2,1,6]  R792      1.7432193458080292e-01
    z[2,1,6]  R793      -2.1570816636085510e-01
    z[2,1,6]  R794      8.8239498436450958e-03
    z[2,1,6]  R795      -1.3048341870307922e-01
    z[2,1,6]  R796      7.9777045175433159e-03
    z[2,1,6]  R797      7.3663994669914246e-02
    z[2,1,6]  R798      7.0254206657409668e-01
    z[2,1,6]  R799      -3.7165313959121704e-01
    z[2,1,6]  R800      2.5277087092399597e-01
    z[2,1,6]  R801      2.8222542256116867e-02
    z[2,1,6]  R802      -1.1257118545472622e-02
    z[2,1,6]  R803      1.7796604335308075e-01
    z[2,1,6]  R804      -7.2849661111831665e-02
    z[2,1,6]  R805      9.3854013830423355e-03
    z[2,1,6]  R806      -3.1947249174118042e-01
    z[2,1,6]  R807      -0.0979093536734581
    z[2,1,6]  R808      2.2815231233835220e-02
    z[2,1,6]  R809      3.8587224483489990e-01
    z[2,1,6]  R810      -8.4345191717147827e-02
    z[2,1,6]  R811      -1.2673306465148926e-01
    z[2,1,6]  R812      7.6837375760078430e-02
    z[2,1,6]  R813      -5.8577362447977066e-02
    z[2,1,6]  R814      -2.1849749982357025e-01
    z[2,1,6]  R815      -3.4982562065124512e-01
    z[2,1,6]  R816      9.2579156160354614e-02
    z[2,1,6]  R817      -3.3042957074940205e-03
    z[2,1,6]  R818      -1.6233417391777039e-01
    z[2,1,6]  R819      2.0560391247272491e-01
    z[2,1,6]  R820      -1.4235657453536987e-01
    z[2,1,6]  R821      -2.6263710856437683e-01
    z[2,1,6]  R822      -2.2393219172954559e-01
    z[2,1,6]  R823      -2.4934880435466766e-01
    z[2,1,6]  R824      -2.0466949790716171e-02
    z[2,1,6]  R825      -1.0608077049255371e-01
    z[2,1,6]  R826      2.5520170107483864e-02
    z[2,1,6]  R827      6.1196144670248032e-02
    z[2,1,6]  R828      -1.9799458980560303e-01
    z[2,1,6]  R829      -1.6837205737829208e-02
    z[2,1,6]  R830      -2.9608628153800964e-01
    z[2,1,6]  R831      4.5811015367507935e-01
    z[2,1,6]  R832      5.9624046087265015e-01
    z[2,1,6]  R833      6.6907656192779541e-01
    z[2,1,6]  R834      -5.5441600084304810e-01
    z[2,1,6]  R835      -1.9777742028236389e-01
    z[2,1,6]  R836      -4.0725570917129517e-01
    z[2,1,6]  R837      3.9133498072624207e-01
    z[2,1,6]  R838      1.6450621187686920e-01
    z[2,1,6]  R839      5.8892941474914551e-01
    z[2,1,6]  R840      3.7337329983711243e-01
    z[2,1,6]  R841      2.2634324431419373e-01
    z[2,1,6]  R842      1.3039888441562653e-01
    z[2,1,6]  R843      4.8245757818222046e-01
    z[2,1,6]  R844      1.7120416462421417e-01
    z[2,1,6]  R845      -1.6910965740680695e-01
    z[2,1,6]  R846      5.0452504307031631e-02
    z[2,1,6]  R847      -1.5364871360361576e-02
    z[2,1,6]  R848      -5.8263218402862549e-01
    z[2,1,6]  R849      2.1156400442123413e-01
    z[2,1,6]  R850      -1.5903815627098083e-01
    z[2,1,6]  R851      -3.2536724209785461e-01
    z[2,1,6]  R852      -1.0116910934448242e-01
    z[2,1,6]  R853      1.5987172955647111e-03
    z[2,1,6]  R854      -2.2914621978998184e-02
    z[2,1,6]  R855      -1.2541098892688751e-01
    z[2,1,6]  R856      -2.0352834463119507e-01
    z[2,3,0]  R20       -1
    z[2,3,0]  R29       1
    z[2,3,0]  R857      -1
    z[2,3,0]  R858      1
    z[2,3,0]  R871      1.7375077307224274e-01
    z[2,3,0]  R872      1.0416479408740997e-01
    z[2,3,0]  R873      3.5076405853033066e-02
    z[2,3,0]  R874      1.1815072596073151e-01
    z[2,3,0]  R875      1.3126258552074432e-01
    z[2,3,0]  R876      4.0457978844642639e-02
    z[2,3,0]  R877      -3.9107404649257660e-02
    z[2,3,0]  R878      -7.3462487198412418e-03
    z[2,3,0]  R879      -2.0507071912288666e-01
    z[2,3,0]  R880      5.1161199808120728e-02
    z[2,3,0]  R881      -5.0340861082077026e-02
    z[2,3,0]  R882      1.0358274728059769e-01
    z[2,3,0]  R883      -1.6905583441257477e-02
    z[2,3,0]  R884      1.8200548365712166e-02
    z[2,3,0]  R885      -1.5195293724536896e-01
    z[2,3,0]  R886      -1.0875476151704788e-01
    z[2,3,0]  R887      -1.0530030727386475e-01
    z[2,3,0]  R888      -1.1921381205320358e-01
    z[2,3,0]  R889      -9.4531789422035217e-02
    z[2,3,0]  R890      -9.7032509744167328e-02
    z[2,3,0]  R891      -1.1137016862630844e-01
    z[2,3,0]  R892      -1.5104120969772339e-01
    z[2,3,0]  R893      -8.7838634848594666e-02
    z[2,3,0]  R894      -9.9680311977863312e-02
    z[2,3,0]  R895      -1.4754776656627655e-01
    z[2,3,0]  R896      -6.5765053033828735e-02
    z[2,3,0]  R897      -1.2139682471752167e-01
    z[2,3,0]  R898      2.1158248186111450e-02
    z[2,3,0]  R899      -1.4087593555450439e-01
    z[2,3,0]  R900      9.5251291990280151e-02
    z[2,3,0]  R901      -0.0731421485543251
    z[2,3,0]  R902      -1.8635485321283340e-02
    z[2,3,0]  R903      -1.7498539388179779e-01
    z[2,3,0]  R904      -1.8789456784725189e-01
    z[2,3,0]  R905      -2.5243632495403290e-02
    z[2,3,0]  R906      -5.5284440517425537e-02
    z[2,3,0]  R907      -6.9861665368080139e-02
    z[2,3,0]  R908      8.2318651676177979e-01
    z[2,3,0]  R909      -5.5996431037783623e-03
    z[2,3,0]  R910      -8.5662461817264557e-02
    z[2,3,0]  R911      -3.8488205522298813e-02
    z[2,3,0]  R912      -9.2685915529727936e-02
    z[2,3,0]  R913      -1.4319211244583130e-01
    z[2,3,0]  R914      -1.0172440856695175e-01
    z[2,3,0]  R915      -8.5732407867908478e-02
    z[2,3,0]  R916      6.5032929182052612e-01
    z[2,3,0]  R917      6.3057667016983032e-01
    z[2,3,0]  R918      6.4594465494155884e-01
    z[2,3,0]  R919      7.2314405441284180e-01
    z[2,3,0]  R920      -7.0556834340095520e-02
    z[2,3,0]  R921      -2.9663050174713135e-01
    z[2,3,0]  R922      -1.2225360423326492e-01
    z[2,3,0]  R923      -5.9042003005743027e-02
    z[2,3,0]  R924      -0.0837436318397522
    z[2,3,0]  R925      -1.9234749674797058e-01
    z[2,3,0]  R926      8.1895852088928223e-01
    z[2,3,0]  R927      7.8993266820907593e-01
    z[2,3,0]  R928      1.4451588690280914e-01
    z[2,3,0]  R929      -3.3854654431343079e-01
    z[2,3,0]  R930      -7.5919860601425171e-01
    z[2,3,0]  R931      -4.4023331999778748e-01
    z[2,3,0]  R932      -4.6406522393226624e-01
    z[2,3,0]  R933      -4.5787465572357178e-01
    z[2,3,0]  R934      -6.8517088890075684e-01
    z[2,3,0]  R935      -1.8491105735301971e-01
    z[2,3,0]  R936      -3.3509409427642822e-01
    z[2,3,0]  R937      -2.8206023573875427e-01
    z[2,3,0]  R938      2.7938228845596313e-01
    z[2,3,0]  R939      -4.2142361402511597e-01
    z[2,3,0]  R940      -0.584001362323761
    z[2,3,0]  R941      4.0572577714920044e-01
    z[2,3,0]  R942      1.0785473138093948e-01
    z[2,3,0]  R943      -0.830449104309082
    z[2,3,0]  R944      1.7969982326030731e-01
    z[2,3,0]  R945      -0.642325758934021
    z[2,3,0]  R946      1.1066393554210663e-01
    z[2,3,0]  R947      -1.7487633228302002e-01
    z[2,3,0]  R948      -6.8146413564682007e-01
    z[2,3,0]  R949      4.7118470072746277e-01
    z[2,3,0]  R950      -1.8216333119198680e-03
    z[2,3,0]  R951      -6.6865408420562744e-01
    z[2,3,0]  R952      6.5221273899078369e-01
    z[2,3,0]  R953      -6.6511653363704681e-02
    z[2,3,0]  R954      3.7986478209495544e-01
    z[2,3,0]  R955      -4.3224725127220154e-01
    z[2,3,0]  R956      2.6944720745086670e-01
    z[2,3,0]  R957      -1.1762320250272751e-01
    z[2,3,0]  R958      5.9010595083236694e-01
    z[2,3,0]  R959      -6.5369868278503418e-01
    z[2,3,0]  R960      1.5902586281299591e-01
    z[2,3,0]  R961      -6.5894013643264771e-01
    z[2,3,0]  R962      3.0720660090446472e-01
    z[2,3,0]  R963      2.7164104580879211e-01
    z[2,3,0]  R964      -4.1422676295042038e-02
    z[2,3,0]  R965      -2.6115933060646057e-01
    z[2,3,0]  R966      -4.4731575250625610e-01
    z[2,3,0]  R967      -5.7417166233062744e-01
    z[2,3,0]  R968      0.747056782245636
    z[2,3,0]  R969      0.775826096534729
    z[2,3,0]  R970      -1.7995016276836395e-01
    z[2,3,0]  R971      1.1530910432338715e-01
    z[2,3,0]  R972      -3.6128619313240051e-01
    z[2,3,0]  R973      -4.2039236426353455e-01
    z[2,3,0]  R974      -2.6028716564178467e-01
    z[2,3,0]  R975      -5.2616310119628906e-01
    z[2,3,0]  R976      -3.8607782125473022e-01
    z[2,3,0]  R977      0.791607677936554
    z[2,3,0]  R978      5.4138455539941788e-02
    z[2,3,0]  R979      1.5371054410934448e-01
    z[2,3,0]  R980      1.1704263836145401e-01
    z[2,3,0]  R981      -4.8452970385551453e-01
    z[2,3,0]  R982      9.5285169780254364e-02
    z[2,3,0]  R983      1.9031725823879242e-01
    z[2,3,0]  R984      -3.6664411425590515e-01
    z[2,3,0]  R985      2.4678209424018860e-01
    z[2,3,0]  R986      9.0622341632843018e-01
    z[2,3,0]  R987      6.1857986450195312e-01
    z[2,3,0]  R988      1.1635594815015793e-01
    z[2,3,0]  R989      -1.5081866644322872e-02
    z[2,3,1]  R21       -1
    z[2,3,1]  R30       1
    z[2,3,1]  R859      -1
    z[2,3,1]  R860      1
    z[2,3,1]  R871      -0.188704252243042
    z[2,3,1]  R872      -2.4665230512619019e-01
    z[2,3,1]  R873      -7.5864009559154510e-02
    z[2,3,1]  R874      -1.4523386955261230e-01
    z[2,3,1]  R875      3.9027415215969086e-02
    z[2,3,1]  R876      3.2125559449195862e-01
    z[2,3,1]  R877      -8.7640094757080078e-01
    z[2,3,1]  R878      2.4323654174804688e-01
    z[2,3,1]  R879      -7.8582540154457092e-02
    z[2,3,1]  R880      9.0698373317718506e-01
    z[2,3,1]  R881      7.7767539024353027e-01
    z[2,3,1]  R882      7.6909792423248291e-01
    z[2,3,1]  R883      7.4120289087295532e-01
    z[2,3,1]  R884      0.731759786605835
    z[2,3,1]  R885      6.7997241020202637e-01
    z[2,3,1]  R886      6.6865491867065430e-01
    z[2,3,1]  R887      0.649121105670929
    z[2,3,1]  R888      0.642539918422699
    z[2,3,1]  R889      6.3295543193817139e-01
    z[2,3,1]  R890      5.9669071435928345e-01
    z[2,3,1]  R891      -1.3306954503059387e-01
    z[2,3,1]  R892      -5.5064046382904053e-01
    z[2,3,1]  R893      -0.590140163898468
    z[2,3,1]  R894      -4.8204281926155090e-01
    z[2,3,1]  R895      -3.4903496503829956e-01
    z[2,3,1]  R896      -2.7629068493843079e-01
    z[2,3,1]  R897      -4.7363707423210144e-01
    z[2,3,1]  R898      -9.0629106760025024e-01
    z[2,3,1]  R899      -5.0873714685440063e-01
    z[2,3,1]  R900      8.0913090705871582e-01
    z[2,3,1]  R901      6.0107976198196411e-01
    z[2,3,1]  R902      5.5919289588928223e-01
    z[2,3,1]  R903      -1.8453678488731384e-01
    z[2,3,1]  R904      -2.1710814535617828e-01
    z[2,3,1]  R905      -9.4162505865097046e-01
    z[2,3,1]  R906      -9.0053504705429077e-01
    z[2,3,1]  R907      -8.9092463254928589e-01
    z[2,3,1]  R908      -5.0908583402633667e-01
    z[2,3,1]  R909      -8.8902920484542847e-01
    z[2,3,1]  R910      8.2013344764709473e-01
    z[2,3,1]  R911      6.7155414819717407e-01
    z[2,3,1]  R912      4.3844765424728394e-01
    z[2,3,1]  R913      -9.7919665277004242e-02
    z[2,3,1]  R914      -5.9339928627014160e-01
    z[2,3,1]  R915      -8.5561513900756836e-01
    z[2,3,1]  R916      -5.1422142982482910e-01
    z[2,3,1]  R917      -5.1929527521133423e-01
    z[2,3,1]  R918      -0.442984014749527
    z[2,3,1]  R919      -2.8734889626502991e-01
    z[2,3,1]  R920      -1.8147509545087814e-02
    z[2,3,1]  R921      -2.6586961001157761e-02
    z[2,3,1]  R922      0.00369931454770267
    z[2,3,1]  R923      6.3879147171974182e-02
    z[2,3,1]  R924      -1.9923512637615204e-01
    z[2,3,1]  R925      -1.0005772858858109e-01
    z[2,3,1]  R926      7.6027326285839081e-02
    z[2,3,1]  R927      1.4623862504959106e-01
    z[2,3,1]  R928      1.8217091262340546e-01
    z[2,3,1]  R929      -1.3551914691925049e-01
    z[2,3,1]  R930      -2.8927680850028992e-01
    z[2,3,1]  R931      2.6945912837982178e-01
    z[2,3,1]  R932      -2.3118519783020020e-01
    z[2,3,1]  R933      5.8011960983276367e-01
    z[2,3,1]  R934      2.3392921686172485e-01
    z[2,3,1]  R935      7.2063136100769043e-01
    z[2,3,1]  R936      2.6466074585914612e-01
    z[2,3,1]  R937      7.8480696678161621e-01
    z[2,3,1]  R938      5.6278330087661743e-01
    z[2,3,1]  R939      3.4769752621650696e-01
    z[2,3,1]  R940      5.1476502418518066e-01
    z[2,3,1]  R941      4.7450292110443115e-01
    z[2,3,1]  R942      4.6423131227493286e-01
    z[2,3,1]  R943      3.0879806727170944e-02
    z[2,3,1]  R944      7.7803015708923340e-01
    z[2,3,1]  R945      -1.0528992861509323e-01
    z[2,3,1]  R946      4.0154322981834412e-01
    z[2,3,1]  R947      3.8039916753768921e-01
    z[2,3,1]  R948      -3.7814763188362122e-01
    z[2,3,1]  R949      5.5834829807281494e-01
    z[2,3,1]  R950      7.5402897596359253e-01
    z[2,3,1]  R951      4.1881687939167023e-02
    z[2,3,1]  R952      5.8069932460784912e-01
    z[2,3,1]  R953      0.658522367477417
    z[2,3,1]  R954      5.2583056688308716e-01
    z[2,3,1]  R955      4.9912261962890625e-01
    z[2,3,1]  R956      5.3118276596069336e-01
    z[2,3,1]  R957      4.6213954687118530e-01
    z[2,3,1]  R958      6.0919177532196045e-01
    z[2,3,1]  R959      -3.1659671664237976e-01
    z[2,3,1]  R960      6.4564794301986694e-01
    z[2,3,1]  R961      5.5827665328979492e-01
    z[2,3,1]  R962      4.9820753931999207e-01
    z[2,3,1]  R963      5.0807380676269531e-01
    z[2,3,1]  R964      3.1307044625282288e-01
    z[2,3,1]  R965      2.9546493291854858e-01
    z[2,3,1]  R966      3.7226030230522156e-01
    z[2,3,1]  R967      2.3870619013905525e-02
    z[2,3,1]  R968      1.4187602698802948e-01
    z[2,3,1]  R969      -2.5463572144508362e-01
    z[2,3,1]  R970      8.2051777839660645e-01
    z[2,3,1]  R971      7.2249752283096313e-01
    z[2,3,1]  R972      -1.9844371825456619e-02
    z[2,3,1]  R973      1.3561069965362549e-01
    z[2,3,1]  R974      2.0917631685733795e-01
    z[2,3,1]  R975      -3.0464905500411987e-01
    z[2,3,1]  R976      -8.9196532964706421e-02
    z[2,3,1]  R977      5.2294093370437622e-01
    z[2,3,1]  R978      5.9315097332000732e-01
    z[2,3,1]  R979      0.555571973323822
    z[2,3,1]  R980      6.8589460849761963e-01
    z[2,3,1]  R981      -0.271817684173584
    z[2,3,1]  R982      7.6071041822433472e-01
    z[2,3,1]  R983      6.5266501903533936e-01
    z[2,3,1]  R984      -7.4946634471416473e-02
    z[2,3,1]  R985      7.4575155973434448e-01
    z[2,3,1]  R986      -3.2170295715332031e-02
    z[2,3,1]  R987      -6.4777153730392456e-01
    z[2,3,1]  R988      -6.4375817775726318e-01
    z[2,3,1]  R989      -8.7924355268478394e-01
    z[2,3,2]  R22       -1
    z[2,3,2]  R31       1
    z[2,3,2]  R861      -1
    z[2,3,2]  R862      1
    z[2,3,2]  R871      -4.4951781630516052e-01
    z[2,3,2]  R872      -5.7896214723587036e-01
    z[2,3,2]  R873      -7.5325781106948853e-01
    z[2,3,2]  R874      -6.0198068618774414e-01
    z[2,3,2]  R875      2.7803765609860420e-02
    z[2,3,2]  R876      4.9266871809959412e-01
    z[2,3,2]  R877      1.9959209859371185e-01
    z[2,3,2]  R878      6.3347554206848145e-01
    z[2,3,2]  R879      3.4610655903816223e-01
    z[2,3,2]  R880      -9.4338893890380859e-02
    z[2,3,2]  R881      -2.8370854258537292e-01
    z[2,3,2]  R882      1.4953862130641937e-01
    z[2,3,2]  R883      2.9757255315780640e-01
    z[2,3,2]  R884      5.3267461061477661e-01
    z[2,3,2]  R885      4.1305556893348694e-01
    z[2,3,2]  R886      1.0275747627019882e-01
    z[2,3,2]  R887      2.9723986983299255e-01
    z[2,3,2]  R888      2.5612899661064148e-01
    z[2,3,2]  R889      1.3214507699012756e-01
    z[2,3,2]  R890      8.6175657808780670e-02
    z[2,3,2]  R891      4.3202412128448486e-01
    z[2,3,2]  R892      4.8419484496116638e-01
    z[2,3,2]  R893      3.3047696948051453e-01
    z[2,3,2]  R894      5.3097373247146606e-01
    z[2,3,2]  R895      4.6801841259002686e-01
    z[2,3,2]  R896      2.5067463517189026e-01
    z[2,3,2]  R897      3.1835344433784485e-01
    z[2,3,2]  R898      2.5098061561584473e-01
    z[2,3,2]  R899      1.9846871495246887e-01
    z[2,3,2]  R900      2.8659293428063393e-02
    z[2,3,2]  R901      -2.0808011293411255e-01
    z[2,3,2]  R902      5.2410387992858887e-01
    z[2,3,2]  R903      0.0869893953204155
    z[2,3,2]  R904      4.6075470745563507e-02
    z[2,3,2]  R905      -9.9441379308700562e-02
    z[2,3,2]  R906      2.8549528121948242e-01
    z[2,3,2]  R907      1.1278945207595825e-01
    z[2,3,2]  R908      4.9462612718343735e-02
    z[2,3,2]  R909      -1.4428270515054464e-03
    z[2,3,2]  R910      1.0920712351799011e-01
    z[2,3,2]  R911      2.8010737895965576e-01
    z[2,3,2]  R912      2.0575119182467461e-02
    z[2,3,2]  R913      -0.0702795684337616
    z[2,3,2]  R914      -0.0913701057434082
    z[2,3,2]  R915      2.1251454949378967e-01
    z[2,3,2]  R916      2.9008436203002930e-01
    z[2,3,2]  R917      3.0944174528121948e-01
    z[2,3,2]  R918      4.6052265167236328e-01
    z[2,3,2]  R919      -8.3492629230022430e-02
    z[2,3,2]  R920      2.0380039513111115e-01
    z[2,3,2]  R921      1.6424112021923065e-01
    z[2,3,2]  R922      1.9458401203155518e-01
    z[2,3,2]  R923      1.3415600359439850e-01
    z[2,3,2]  R924      1.6791100800037384e-01
    z[2,3,2]  R925      0.255410760641098
    z[2,3,2]  R926      -3.5475820302963257e-01
    z[2,3,2]  R927      -3.3877888321876526e-01
    z[2,3,2]  R928      -6.6418254375457764e-01
    z[2,3,2]  R929      -3.8884088397026062e-01
    z[2,3,2]  R930      4.8751473426818848e-01
    z[2,3,2]  R931      6.6513568162918091e-01
    z[2,3,2]  R932      6.8369269371032715e-01
    z[2,3,2]  R933      2.1148090064525604e-01
    z[2,3,2]  R934      1.4423067867755890e-01
    z[2,3,2]  R935      -2.1882466971874237e-01
    z[2,3,2]  R936      0.378388911485672
    z[2,3,2]  R937      -2.1996329724788666e-01
    z[2,3,2]  R938      4.2632156610488892e-01
    z[2,3,2]  R939      -2.0593171939253807e-02
    z[2,3,2]  R940      -1.3001163303852081e-01
    z[2,3,2]  R941      8.7742239236831665e-02
    z[2,3,2]  R942      6.3745164871215820e-01
    z[2,3,2]  R943      -2.4686776101589203e-01
    z[2,3,2]  R944      -4.6482320874929428e-02
    z[2,3,2]  R945      -5.6497758626937866e-01
    z[2,3,2]  R946      -4.6835571527481079e-01
    z[2,3,2]  R947      -2.2003506124019623e-01
    z[2,3,2]  R948      -1.1988830566406250e-01
    z[2,3,2]  R949      -1.6529999673366547e-01
    z[2,3,2]  R950      -3.4255844354629517e-01
    z[2,3,2]  R951      2.1844626963138580e-01
    z[2,3,2]  R952      0.0618012435734272
    z[2,3,2]  R953      -2.6322066783905029e-01
    z[2,3,2]  R954      4.9342596530914307e-01
    z[2,3,2]  R955      -2.3038223385810852e-01
    z[2,3,2]  R956      -1.2890572845935822e-01
    z[2,3,2]  R957      4.1803103685379028e-01
    z[2,3,2]  R958      1.0757859796285629e-01
    z[2,3,2]  R959      1.4735744893550873e-01
    z[2,3,2]  R960      1.1390602588653564e-01
    z[2,3,2]  R961      1.5017402172088623e-01
    z[2,3,2]  R962      6.4315325021743774e-01
    z[2,3,2]  R963      3.0384641885757446e-01
    z[2,3,2]  R964      6.2764132022857666e-01
    z[2,3,2]  R965      4.3027636408805847e-01
    z[2,3,2]  R966      1.6781453788280487e-01
    z[2,3,2]  R967      6.8919695913791656e-02
    z[2,3,2]  R968      -6.2851980328559875e-02
    z[2,3,2]  R969      -1.3999626040458679e-01
    z[2,3,2]  R970      7.3459409177303314e-02
    z[2,3,2]  R971      3.7138587236404419e-01
    z[2,3,2]  R972      2.0932666957378387e-01
    z[2,3,2]  R973      2.2971647977828979e-01
    z[2,3,2]  R974      3.4135237336158752e-01
    z[2,3,2]  R975      1.6996251046657562e-01
    z[2,3,2]  R976      8.2678878307342529e-01
    z[2,3,2]  R977      2.2051315754652023e-02
    z[2,3,2]  R978      -6.0025709867477417e-01
    z[2,3,2]  R979      1.9501638412475586e-01
    z[2,3,2]  R980      4.6038147807121277e-01
    z[2,3,2]  R981      3.8770639896392822e-01
    z[2,3,2]  R982      -3.3164015412330627e-01
    z[2,3,2]  R983      1.6177296638488770e-01
    z[2,3,2]  R984      7.0908272266387939e-01
    z[2,3,2]  R985      -0.51152503490448
    z[2,3,2]  R986      7.7022803016006947e-03
    z[2,3,2]  R987      -3.3185330033302307e-01
    z[2,3,2]  R988      1.8339410424232483e-01
    z[2,3,2]  R989      2.6918539777398109e-02
    z[2,3,3]  R23       -1
    z[2,3,3]  R32       1
    z[2,3,3]  R863      -1
    z[2,3,3]  R864      1
    z[2,3,3]  R871      -7.4526280164718628e-01
    z[2,3,3]  R872      -6.8571335077285767e-01
    z[2,3,3]  R873      -3.4381410479545593e-01
    z[2,3,3]  R874      -4.9803760647773743e-01
    z[2,3,3]  R875      -8.3985865116119385e-01
    z[2,3,3]  R876      -0.0569143183529377
    z[2,3,3]  R877      1.1172537505626678e-01
    z[2,3,3]  R878      2.8988546133041382e-01
    z[2,3,3]  R879      3.5846811532974243e-01
    z[2,3,3]  R880      7.7495403587818146e-02
    z[2,3,3]  R881      1.9534422457218170e-01
    z[2,3,3]  R882      2.9060753062367439e-02
    z[2,3,3]  R883      -5.9179320931434631e-02
    z[2,3,3]  R884      -3.4050792455673218e-01
    z[2,3,3]  R885      3.6460673809051514e-01
    z[2,3,3]  R886      5.4198390245437622e-01
    z[2,3,3]  R887      0.00823516957461834
    z[2,3,3]  R888      4.8303452134132385e-01
    z[2,3,3]  R889      1.5749073028564453e-01
    z[2,3,3]  R890      4.3526706099510193e-01
    z[2,3,3]  R891      7.9342108964920044e-01
    z[2,3,3]  R892      6.5937399864196777e-01
    z[2,3,3]  R893      6.5896546840667725e-01
    z[2,3,3]  R894      6.2674939632415771e-01
    z[2,3,3]  R895      6.7736089229583740e-01
    z[2,3,3]  R896      7.3747175931930542e-01
    z[2,3,3]  R897      6.9485068321228027e-01
    z[2,3,3]  R898      -5.8983918279409409e-03
    z[2,3,3]  R899      7.4100762605667114e-01
    z[2,3,3]  R900      -5.2359545230865479e-01
    z[2,3,3]  R901      1.0568166524171829e-01
    z[2,3,3]  R902      -4.7711357474327087e-03
    z[2,3,3]  R903      0.899384617805481
    z[2,3,3]  R904      9.2336362600326538e-01
    z[2,3,3]  R905      2.6426756381988525e-01
    z[2,3,3]  R906      6.7940421402454376e-02
    z[2,3,3]  R907      2.9856231808662415e-01
    z[2,3,3]  R908      2.1147172152996063e-01
    z[2,3,3]  R909      1.3571204245090485e-01
    z[2,3,3]  R910      2.6888519525527954e-01
    z[2,3,3]  R911      3.7405043840408325e-01
    z[2,3,3]  R912      -1.7554442584514618e-01
    z[2,3,3]  R913      9.7027087211608887e-01
    z[2,3,3]  R914      7.2116440534591675e-01
    z[2,3,3]  R915      1.2738877534866333e-01
    z[2,3,3]  R916      0.232284277677536
    z[2,3,3]  R917      1.7936527729034424e-01
    z[2,3,3]  R918      5.1085177809000015e-02
    z[2,3,3]  R919      3.9830267429351807e-01
    z[2,3,3]  R920      -7.9531884193420410e-01
    z[2,3,3]  R921      -2.1419633924961090e-01
    z[2,3,3]  R922      -7.8271585702896118e-01
    z[2,3,3]  R923      -0.861125111579895
    z[2,3,3]  R924      -8.1278353929519653e-01
    z[2,3,3]  R925      -1.5331903100013733e-01
    z[2,3,3]  R926      7.7234938740730286e-02
    z[2,3,3]  R927      6.7612268030643463e-02
    z[2,3,3]  R928      2.5660252571105957e-01
    z[2,3,3]  R929      -6.4098340272903442e-01
    z[2,3,3]  R930      5.8287929743528366e-02
    z[2,3,3]  R931      2.7959231287240982e-02
    z[2,3,3]  R932      -1.0461293160915375e-01
    z[2,3,3]  R933      1.8379074335098267e-01
    z[2,3,3]  R934      1.5539652109146118e-01
    z[2,3,3]  R935      4.1253589093685150e-02
    z[2,3,3]  R936      -1.8871749937534332e-01
    z[2,3,3]  R937      -4.9115356802940369e-01
    z[2,3,3]  R938      -3.8400459289550781e-01
    z[2,3,3]  R939      5.5019551515579224e-01
    z[2,3,3]  R940      -3.8510710000991821e-01
    z[2,3,3]  R941      -1.6262365877628326e-01
    z[2,3,3]  R942      1.7351378500461578e-01
    z[2,3,3]  R943      -8.0030553042888641e-02
    z[2,3,3]  R944      -4.0627697110176086e-01
    z[2,3,3]  R945      -3.0941897630691528e-01
    z[2,3,3]  R946      1.0074589401483536e-01
    z[2,3,3]  R947      -6.4366863807663321e-04
    z[2,3,3]  R948      -0.552621603012085
    z[2,3,3]  R949      5.6718343496322632e-01
    z[2,3,3]  R950      2.0407845079898834e-01
    z[2,3,3]  R951      -5.3206861019134521e-01
    z[2,3,3]  R952      2.4289989471435547e-01
    z[2,3,3]  R953      1.6189590096473694e-02
    z[2,3,3]  R954      4.3716889619827271e-01
    z[2,3,3]  R955      5.6508713960647583e-01
    z[2,3,3]  R956      -0.0973648726940155
    z[2,3,3]  R957      5.7831853628158569e-01
    z[2,3,3]  R958      -6.6572129726409912e-02
    z[2,3,3]  R959      -2.7399215102195740e-01
    z[2,3,3]  R960      -6.6143953800201416e-01
    z[2,3,3]  R961      4.1986754536628723e-01
    z[2,3,3]  R962      -2.3869954049587250e-01
    z[2,3,3]  R963      -3.1929448246955872e-01
    z[2,3,3]  R964      -3.4203460812568665e-01
    z[2,3,3]  R965      -2.7745443582534790e-01
    z[2,3,3]  R966      -1.5969966351985931e-01
    z[2,3,3]  R967      -2.3088859394192696e-02
    z[2,3,3]  R968      1.9278062880039215e-01
    z[2,3,3]  R969      -1.4659017324447632e-01
    z[2,3,3]  R970      -1.0071203112602234e-02
    z[2,3,3]  R971      -4.1415423154830933e-01
    z[2,3,3]  R972      -8.4944957494735718e-01
    z[2,3,3]  R973      -5.6782656908035278e-01
    z[2,3,3]  R974      -5.3837972879409790e-01
    z[2,3,3]  R975      -1.9293190538883209e-01
    z[2,3,3]  R976      1.9563492387533188e-02
    z[2,3,3]  R977      -1.4713719487190247e-01
    z[2,3,3]  R978      3.4421697258949280e-01
    z[2,3,3]  R979      6.0054361820220947e-01
    z[2,3,3]  R980      -1.2486293166875839e-01
    z[2,3,3]  R981      -5.4064434766769409e-01
    z[2,3,3]  R982      3.0994030833244324e-01
    z[2,3,3]  R983      -6.5386700630187988e-01
    z[2,3,3]  R984      -2.6555222272872925e-01
    z[2,3,3]  R985      2.4559656158089638e-02
    z[2,3,3]  R986      -5.6275906972587109e-03
    z[2,3,3]  R987      -1.1046132072806358e-02
    z[2,3,3]  R988      5.8191090822219849e-01
    z[2,3,3]  R989      4.4353199005126953e-01
    z[2,3,4]  R24       -1
    z[2,3,4]  R33       1
    z[2,3,4]  R865      -1
    z[2,3,4]  R866      1
    z[2,3,4]  R871      -3.7721905112266541e-01
    z[2,3,4]  R872      7.5825735926628113e-02
    z[2,3,4]  R873      1.9991464912891388e-01
    z[2,3,4]  R874      4.4819310307502747e-01
    z[2,3,4]  R875      4.4935014843940735e-01
    z[2,3,4]  R876      -7.5711631774902344e-01
    z[2,3,4]  R877      3.1309577822685242e-01
    z[2,3,4]  R878      8.7982267141342163e-02
    z[2,3,4]  R879      4.1028323769569397e-01
    z[2,3,4]  R880      -1.1457324773073196e-01
    z[2,3,4]  R881      2.8668063879013062e-01
    z[2,3,4]  R882      3.5323154926300049e-01
    z[2,3,4]  R883      -2.6967665553092957e-01
    z[2,3,4]  R884      -1.3486875593662262e-01
    z[2,3,4]  R885      3.0621844530105591e-01
    z[2,3,4]  R886      3.8816508650779724e-01
    z[2,3,4]  R887      6.6257226467132568e-01
    z[2,3,4]  R888      -2.9584395885467529e-01
    z[2,3,4]  R889      5.8784645795822144e-01
    z[2,3,4]  R890      1.3013081252574921e-01
    z[2,3,4]  R891      -3.3607015013694763e-01
    z[2,3,4]  R892      4.4919040054082870e-02
    z[2,3,4]  R893      -2.5752422213554382e-01
    z[2,3,4]  R894      -1.4710766077041626e-01
    z[2,3,4]  R895      -6.0857083648443222e-02
    z[2,3,4]  R896      -4.1886419057846069e-01
    z[2,3,4]  R897      -2.7050018310546875e-01
    z[2,3,4]  R898      -0.0910007506608963
    z[2,3,4]  R899      1.0590924322605133e-01
    z[2,3,4]  R900      -9.0013951063156128e-02
    z[2,3,4]  R901      -2.6118251681327820e-01
    z[2,3,4]  R902      0.267488956451416
    z[2,3,4]  R903      -2.1014265716075897e-01
    z[2,3,4]  R904      1.6813451051712036e-01
    z[2,3,4]  R905      -1.6713267564773560e-01
    z[2,3,4]  R906      -0.00890843104571104
    z[2,3,4]  R907      1.3897763192653656e-01
    z[2,3,4]  R908      1.1517754197120667e-01
    z[2,3,4]  R909      1.5052539110183716e-01
    z[2,3,4]  R910      4.7526782751083374e-01
    z[2,3,4]  R911      -5.2258223295211792e-01
    z[2,3,4]  R912      6.3477098941802979e-01
    z[2,3,4]  R913      -9.3176737427711487e-02
    z[2,3,4]  R914      -1.1465954780578613e-01
    z[2,3,4]  R915      4.3941894173622131e-01
    z[2,3,4]  R916      -1.8070462346076965e-01
    z[2,3,4]  R917      -3.7156096100807190e-01
    z[2,3,4]  R918      -2.0955021679401398e-01
    z[2,3,4]  R919      -3.6808863282203674e-01
    z[2,3,4]  R920      4.5091444253921509e-01
    z[2,3,4]  R921      3.5913035273551941e-01
    z[2,3,4]  R922      -1.0920819640159607e-01
    z[2,3,4]  R923      -1.9991688430309296e-01
    z[2,3,4]  R924      -1.6100019216537476e-01
    z[2,3,4]  R925      8.1068587303161621e-01
    z[2,3,4]  R926      8.9609727263450623e-02
    z[2,3,4]  R927      2.7591744065284729e-01
    z[2,3,4]  R928      -0.0668027475476265
    z[2,3,4]  R929      5.3418558835983276e-01
    z[2,3,4]  R930      1.4315286278724670e-01
    z[2,3,4]  R931      -4.9541953206062317e-01
    z[2,3,4]  R932      -2.9208657145500183e-01
    z[2,3,4]  R933      -1.8198199570178986e-01
    z[2,3,4]  R934      1.9836862385272980e-01
    z[2,3,4]  R935      -4.6531128883361816e-01
    z[2,3,4]  R936      1.8763022124767303e-01
    z[2,3,4]  R937      -1.1969381570816040e-01
    z[2,3,4]  R938      -4.3034926056861877e-02
    z[2,3,4]  R939      -3.5530057549476624e-01
    z[2,3,4]  R940      3.1916370987892151e-01
    z[2,3,4]  R941      1.7346268892288208e-01
    z[2,3,4]  R942      3.7924036383628845e-01
    z[2,3,4]  R943      -0.402294784784317
    z[2,3,4]  R944      1.5069231390953064e-01
    z[2,3,4]  R945      1.5406759083271027e-01
    z[2,3,4]  R946      -2.8166621923446655e-01
    z[2,3,4]  R947      -2.3513855040073395e-01
    z[2,3,4]  R948      -8.8977195322513580e-02
    z[2,3,4]  R949      2.2409638762474060e-01
    z[2,3,4]  R950      0.154669389128685
    z[2,3,4]  R951      -4.5688340067863464e-01
    z[2,3,4]  R952      3.1223863363265991e-01
    z[2,3,4]  R953      -6.3753414154052734e-01
    z[2,3,4]  R954      3.0572861433029175e-02
    z[2,3,4]  R955      1.2119908630847931e-01
    z[2,3,4]  R956      0.698492169380188
    z[2,3,4]  R957      -4.4865887612104416e-02
    z[2,3,4]  R958      3.1009644269943237e-01
    z[2,3,4]  R959      4.3205186724662781e-01
    z[2,3,4]  R960      0.206967294216156
    z[2,3,4]  R961      1.5200087428092957e-01
    z[2,3,4]  R962      -0.355514258146286
    z[2,3,4]  R963      -2.3040850460529327e-01
    z[2,3,4]  R964      3.6587229371070862e-01
    z[2,3,4]  R965      4.1439098119735718e-01
    z[2,3,4]  R966      4.6595939993858337e-01
    z[2,3,4]  R967      -3.7213604897260666e-02
    z[2,3,4]  R968      -2.6540291309356689e-01
    z[2,3,4]  R969      1.5093008987605572e-02
    z[2,3,4]  R970      4.3244457244873047e-01
    z[2,3,4]  R971      3.5639411211013794e-01
    z[2,3,4]  R972      1.0726187378168106e-01
    z[2,3,4]  R973      4.2680940032005310e-01
    z[2,3,4]  R974      4.7016337513923645e-01
    z[2,3,4]  R975      6.8323320150375366e-01
    z[2,3,4]  R976      2.3376402258872986e-01
    z[2,3,4]  R977      -6.5653212368488312e-02
    z[2,3,4]  R978      1.4682777225971222e-01
    z[2,3,4]  R979      -3.3612582087516785e-01
    z[2,3,4]  R980      -4.4868391752243042e-01
    z[2,3,4]  R981      3.8247746229171753e-01
    z[2,3,4]  R982      -2.6561981439590454e-01
    z[2,3,4]  R983      -2.7899253368377686e-01
    z[2,3,4]  R984      -1.0250168852508068e-02
    z[2,3,4]  R985      3.3220660686492920e-01
    z[2,3,4]  R986      3.8770094513893127e-01
    z[2,3,4]  R987      -1.7438489198684692e-01
    z[2,3,4]  R988      -1.4591903984546661e-01
    z[2,3,4]  R989      -1.5090203844010830e-02
    z[2,3,5]  R25       -1
    z[2,3,5]  R34       1
    z[2,3,5]  R867      -1
    z[2,3,5]  R868      1
    z[2,3,5]  R871      1.0752414911985397e-01
    z[2,3,5]  R872      -2.2847658395767212e-01
    z[2,3,5]  R873      2.9388007521629333e-01
    z[2,3,5]  R874      2.6284396648406982e-01
    z[2,3,5]  R875      1.8035946786403656e-01
    z[2,3,5]  R876      -2.6458916068077087e-01
    z[2,3,5]  R877      -1.8782602250576019e-01
    z[2,3,5]  R878      7.1179017424583435e-02
    z[2,3,5]  R879      1.4700101315975189e-01
    z[2,3,5]  R880      4.8983491957187653e-02
    z[2,3,5]  R881      -4.3268904089927673e-01
    z[2,3,5]  R882      4.4912725687026978e-02
    z[2,3,5]  R883      3.6912506818771362e-01
    z[2,3,5]  R884      -1.0355526208877563e-01
    z[2,3,5]  R885      -2.3538687825202942e-01
    z[2,3,5]  R886      2.3491522669792175e-01
    z[2,3,5]  R887      -9.9665679037570953e-02
    z[2,3,5]  R888      8.0978050827980042e-02
    z[2,3,5]  R889      4.3259942531585693e-01
    z[2,3,5]  R890      6.2491351366043091e-01
    z[2,3,5]  R891      -1.2104964256286621e-01
    z[2,3,5]  R892      -1.2605790980160236e-02
    z[2,3,5]  R893      1.3747389614582062e-01
    z[2,3,5]  R894      2.0527207851409912e-01
    z[2,3,5]  R895      3.8007053732872009e-01
    z[2,3,5]  R896      3.0109593272209167e-01
    z[2,3,5]  R897      -3.2173928618431091e-01
    z[2,3,5]  R898      2.9975953698158264e-01
    z[2,3,5]  R899      3.4868037700653076e-01
    z[2,3,5]  R900      2.1847660839557648e-01
    z[2,3,5]  R901      -1.3078860938549042e-01
    z[2,3,5]  R902      -4.5007985830307007e-01
    z[2,3,5]  R903      -1.0398718714714050e-01
    z[2,3,5]  R904      -1.8376775085926056e-01
    z[2,3,5]  R905      -0.0701352059841156
    z[2,3,5]  R906      -2.6097044348716736e-01
    z[2,3,5]  R907      -2.7366024255752563e-01
    z[2,3,5]  R908      -0.0517178550362587
    z[2,3,5]  R909      -0.257789671421051
    z[2,3,5]  R910      1.8757749348878860e-02
    z[2,3,5]  R911      -2.3568439483642578e-01
    z[2,3,5]  R912      -4.6486797928810120e-01
    z[2,3,5]  R913      8.8016845285892487e-02
    z[2,3,5]  R914      -2.8265652060508728e-01
    z[2,3,5]  R915      -1.3760939240455627e-02
    z[2,3,5]  R916      3.7209907174110413e-01
    z[2,3,5]  R917      1.3777013123035431e-01
    z[2,3,5]  R918      -7.4434436857700348e-02
    z[2,3,5]  R919      2.9123359918594360e-01
    z[2,3,5]  R920      -2.4964088201522827e-01
    z[2,3,5]  R921      -8.1494313478469849e-01
    z[2,3,5]  R922      4.0266877412796021e-01
    z[2,3,5]  R923      8.6275830864906311e-02
    z[2,3,5]  R924      -6.1682611703872681e-02
    z[2,3,5]  R925      -4.3264696002006531e-01
    z[2,3,5]  R926      3.9988461136817932e-01
    z[2,3,5]  R927      3.7383088469505310e-01
    z[2,3,5]  R928      6.3645350933074951e-01
    z[2,3,5]  R929      8.7714329361915588e-02
    z[2,3,5]  R930      1.3221102952957153e-01
    z[2,3,5]  R931      -9.0258710086345673e-02
    z[2,3,5]  R932      1.4950045943260193e-01
    z[2,3,5]  R933      1.0186498612165451e-01
    z[2,3,5]  R934      -4.4034279882907867e-02
    z[2,3,5]  R935      4.1084337234497070e-01
    z[2,3,5]  R936      3.4483358263969421e-01
    z[2,3,5]  R937      -2.2557886317372322e-02
    z[2,3,5]  R938      3.2967728376388550e-01
    z[2,3,5]  R939      5.1698958873748779e-01
    z[2,3,5]  R940      -3.5127472877502441e-01
    z[2,3,5]  R941      0.733608067035675
    z[2,3,5]  R942      -2.3174121975898743e-01
    z[2,3,5]  R943      -2.0580349862575531e-01
    z[2,3,5]  R944      3.1133580207824707e-01
    z[2,3,5]  R945      1.8946586549282074e-01
    z[2,3,5]  R946      -4.0162327885627747e-01
    z[2,3,5]  R947      -3.1405779719352722e-01
    z[2,3,5]  R948      -3.9064630866050720e-02
    z[2,3,5]  R949      -5.4667103104293346e-03
    z[2,3,5]  R950      -8.8266089558601379e-02
    z[2,3,5]  R951      -9.2325031757354736e-02
    z[2,3,5]  R952      -1.6009141504764557e-01
    z[2,3,5]  R953      -5.7933915406465530e-02
    z[2,3,5]  R954      1.6093787550926208e-01
    z[2,3,5]  R955      4.1721498966217041e-01
    z[2,3,5]  R956      -9.5735192298889160e-02
    z[2,3,5]  R957      2.5789514183998108e-01
    z[2,3,5]  R958      -3.9667010307312012e-01
    z[2,3,5]  R959      -3.6002573370933533e-01
    z[2,3,5]  R960      -2.4313493072986603e-01
    z[2,3,5]  R961      -7.2068810462951660e-02
    z[2,3,5]  R962      1.2798270583152771e-01
    z[2,3,5]  R963      -6.2841761112213135e-01
    z[2,3,5]  R964      6.1056271195411682e-02
    z[2,3,5]  R965      -1.8165180087089539e-01
    z[2,3,5]  R966      5.8593624830245972e-01
    z[2,3,5]  R967      3.5766917467117310e-01
    z[2,3,5]  R968      5.3547525405883789e-01
    z[2,3,5]  R969      4.1101586073637009e-02
    z[2,3,5]  R970      1.0764109343290329e-01
    z[2,3,5]  R971      -1.5185199677944183e-01
    z[2,3,5]  R972      2.6983284950256348e-01
    z[2,3,5]  R973      4.1258224844932556e-01
    z[2,3,5]  R974      -2.1482808515429497e-02
    z[2,3,5]  R975      -1.9362571835517883e-01
    z[2,3,5]  R976      9.8400317132472992e-02
    z[2,3,5]  R977      2.6339009404182434e-01
    z[2,3,5]  R978      3.6060410737991333e-01
    z[2,3,5]  R979      -3.3307597041130066e-01
    z[2,3,5]  R980      9.8236635327339172e-02
    z[2,3,5]  R981      2.1155847609043121e-01
    z[2,3,5]  R982      3.4791359305381775e-01
    z[2,3,5]  R983      3.7651412189006805e-02
    z[2,3,5]  R984      -3.4793993830680847e-01
    z[2,3,5]  R985      -1.0101927816867828e-01
    z[2,3,5]  R986      1.5086345374584198e-01
    z[2,3,5]  R987      1.3020054996013641e-01
    z[2,3,5]  R988      -3.7766936421394348e-01
    z[2,3,5]  R989      7.4742093682289124e-02
    z[2,3,6]  R26       -1
    z[2,3,6]  R35       1
    z[2,3,6]  R869      -1
    z[2,3,6]  R870      1
    z[2,3,6]  R871      1.5120458602905273e-01
    z[2,3,6]  R872      2.5487518310546875e-01
    z[2,3,6]  R873      4.2553195357322693e-01
    z[2,3,6]  R874      -2.9079419374465942e-01
    z[2,3,6]  R875      -2.0165875554084778e-01
    z[2,3,6]  R876      7.7225565910339355e-02
    z[2,3,6]  R877      -2.1157729625701904e-01
    z[2,3,6]  R878      -6.6531932353973389e-01
    z[2,3,6]  R879      7.1661704778671265e-01
    z[2,3,6]  R880      -3.7990954518318176e-01
    z[2,3,6]  R881      -0.0680527314543724
    z[2,3,6]  R882      4.9775806069374084e-01
    z[2,3,6]  R883      3.8639616966247559e-01
    z[2,3,6]  R884      1.8866670131683350e-01
    z[2,3,6]  R885      2.4863265454769135e-01
    z[2,3,6]  R886      -0.175812765955925
    z[2,3,6]  R887      1.7377892136573792e-01
    z[2,3,6]  R888      4.2417564988136292e-01
    z[2,3,6]  R889      1.2433759123086929e-01
    z[2,3,6]  R890      1.7381101846694946e-01
    z[2,3,6]  R891      -1.6165116429328918e-01
    z[2,3,6]  R892      5.0855990499258041e-02
    z[2,3,6]  R893      -1.2389753758907318e-01
    z[2,3,6]  R894      -1.3846738636493683e-01
    z[2,3,6]  R895      1.7432193458080292e-01
    z[2,3,6]  R896      -2.1570816636085510e-01
    z[2,3,6]  R897      8.8239498436450958e-03
    z[2,3,6]  R898      -1.3048341870307922e-01
    z[2,3,6]  R899      7.9777045175433159e-03
    z[2,3,6]  R900      7.3663994669914246e-02
    z[2,3,6]  R901      7.0254206657409668e-01
    z[2,3,6]  R902      -3.7165313959121704e-01
    z[2,3,6]  R903      2.5277087092399597e-01
    z[2,3,6]  R904      2.8222542256116867e-02
    z[2,3,6]  R905      -1.1257118545472622e-02
    z[2,3,6]  R906      1.7796604335308075e-01
    z[2,3,6]  R907      -7.2849661111831665e-02
    z[2,3,6]  R908      9.3854013830423355e-03
    z[2,3,6]  R909      -3.1947249174118042e-01
    z[2,3,6]  R910      -0.0979093536734581
    z[2,3,6]  R911      2.2815231233835220e-02
    z[2,3,6]  R912      3.8587224483489990e-01
    z[2,3,6]  R913      -8.4345191717147827e-02
    z[2,3,6]  R914      -1.2673306465148926e-01
    z[2,3,6]  R915      7.6837375760078430e-02
    z[2,3,6]  R916      -5.8577362447977066e-02
    z[2,3,6]  R917      -2.1849749982357025e-01
    z[2,3,6]  R918      -3.4982562065124512e-01
    z[2,3,6]  R919      9.2579156160354614e-02
    z[2,3,6]  R920      2.3448066413402557e-01
    z[2,3,6]  R921      2.1293486654758453e-01
    z[2,3,6]  R922      4.0058061480522156e-01
    z[2,3,6]  R923      4.3068426847457886e-01
    z[2,3,6]  R924      0.484515517950058
    z[2,3,6]  R925      -1.4090597629547119e-01
    z[2,3,6]  R926      -1.5417706966400146e-01
    z[2,3,6]  R927      1.3927669823169708e-01
    z[2,3,6]  R928      -1.7149336636066437e-01
    z[2,3,6]  R929      1.0915964841842651e-01
    z[2,3,6]  R930      -2.4677093327045441e-01
    z[2,3,6]  R931      1.9186499714851379e-01
    z[2,3,6]  R932      -3.8098847866058350e-01
    z[2,3,6]  R933      -5.7603371143341064e-01
    z[2,3,6]  R934      -6.2416213750839233e-01
    z[2,3,6]  R935      -1.0772877931594849e-01
    z[2,3,6]  R936      -6.9624620676040649e-01
    z[2,3,6]  R937      -8.2980375736951828e-03
    z[2,3,6]  R938      -4.0678212046623230e-01
    z[2,3,6]  R939      -6.9660849869251251e-02
    z[2,3,6]  R940      0.0590716190636158
    z[2,3,6]  R941      -8.8420487940311432e-02
    z[2,3,6]  R942      3.7266305088996887e-01
    z[2,3,6]  R943      1.9456608593463898e-01
    z[2,3,6]  R944      -2.7480429410934448e-01
    z[2,3,6]  R945      3.1899476051330566e-01
    z[2,3,6]  R946      5.9696954488754272e-01
    z[2,3,6]  R947      7.8890842199325562e-01
    z[2,3,6]  R948      0.251801997423172
    z[2,3,6]  R949      -2.5877025723457336e-01
    z[2,3,6]  R950      4.9064162373542786e-01
    z[2,3,6]  R951      5.5366568267345428e-02
    z[2,3,6]  R952      2.2685837745666504e-01
    z[2,3,6]  R953      2.8735220432281494e-01
    z[2,3,6]  R954      -3.4319585561752319e-01
    z[2,3,6]  R955      -5.3683228790760040e-02
    z[2,3,6]  R956      -0.34941366314888
    z[2,3,6]  R957      4.4143715500831604e-01
    z[2,3,6]  R958      -1.0558591037988663e-01
    z[2,3,6]  R959      -0.243662029504776
    z[2,3,6]  R960      -7.3637999594211578e-02
    z[2,3,6]  R961      -1.6427341103553772e-01
    z[2,3,6]  R962      2.0980919897556305e-01
    z[2,3,6]  R963      1.6063556075096130e-01
    z[2,3,6]  R964      -5.0175631046295166e-01
    z[2,3,6]  R965      -6.1454075574874878e-01
    z[2,3,6]  R966      -2.1731488406658173e-01
    z[2,3,6]  R967      7.3154765367507935e-01
    z[2,3,6]  R968      1.5326510369777679e-01
    z[2,3,6]  R969      5.3874832391738892e-01
    z[2,3,6]  R970      -3.0045926570892334e-01
    z[2,3,6]  R971      0.0719318613409996
    z[2,3,6]  R972      1.3921739161014557e-01
    z[2,3,6]  R973      -0.278016060590744
    z[2,3,6]  R974      -5.1049643754959106e-01
    z[2,3,6]  R975      -0.24481201171875
    z[2,3,6]  R976      3.0772894620895386e-01
    z[2,3,6]  R977      6.3795872032642365e-02
    z[2,3,6]  R978      -1.2187448143959045e-01
    z[2,3,6]  R979      -2.1238806843757629e-01
    z[2,3,6]  R980      2.7810081839561462e-01
    z[2,3,6]  R981      -2.4018239974975586e-01
    z[2,3,6]  R982      -1.2080726772546768e-01
    z[2,3,6]  R983      6.9574706256389618e-02
    z[2,3,6]  R984      -4.0678188204765320e-01
    z[2,3,6]  R985      1.1225664988160133e-02
    z[2,3,6]  R986      6.7537270486354828e-02
    z[2,3,6]  R987      -2.0034988224506378e-01
    z[2,3,6]  R988      1.8935823440551758e-01
    z[2,3,6]  R989      1.5311431884765625e-01
    z[3,2,0]  R20       1
    z[3,2,0]  R29       -1
    z[3,2,0]  R990      -1
    z[3,2,0]  R991      1
    z[3,2,0]  R1004     -7.0556834340095520e-02
    z[3,2,0]  R1005     -2.9663050174713135e-01
    z[3,2,0]  R1006     -1.2225360423326492e-01
    z[3,2,0]  R1007     -5.9042003005743027e-02
    z[3,2,0]  R1008     -0.0837436318397522
    z[3,2,0]  R1009     -1.9234749674797058e-01
    z[3,2,0]  R1010     8.1895852088928223e-01
    z[3,2,0]  R1011     7.8993266820907593e-01
    z[3,2,0]  R1012     1.4451588690280914e-01
    z[3,2,0]  R1013     -3.3854654431343079e-01
    z[3,2,0]  R1014     -7.5919860601425171e-01
    z[3,2,0]  R1015     -4.4023331999778748e-01
    z[3,2,0]  R1016     -4.6406522393226624e-01
    z[3,2,0]  R1017     -4.5787465572357178e-01
    z[3,2,0]  R1018     -6.8517088890075684e-01
    z[3,2,0]  R1019     -1.8491105735301971e-01
    z[3,2,0]  R1020     -3.3509409427642822e-01
    z[3,2,0]  R1021     -2.8206023573875427e-01
    z[3,2,0]  R1022     2.7938228845596313e-01
    z[3,2,0]  R1023     -4.2142361402511597e-01
    z[3,2,0]  R1024     -0.584001362323761
    z[3,2,0]  R1025     4.0572577714920044e-01
    z[3,2,0]  R1026     1.0785473138093948e-01
    z[3,2,0]  R1027     -0.830449104309082
    z[3,2,0]  R1028     1.7969982326030731e-01
    z[3,2,0]  R1029     -0.642325758934021
    z[3,2,0]  R1030     1.1066393554210663e-01
    z[3,2,0]  R1031     -1.7487633228302002e-01
    z[3,2,0]  R1032     -6.8146413564682007e-01
    z[3,2,0]  R1033     4.7118470072746277e-01
    z[3,2,0]  R1034     -1.8216333119198680e-03
    z[3,2,0]  R1035     -6.6865408420562744e-01
    z[3,2,0]  R1036     6.5221273899078369e-01
    z[3,2,0]  R1037     -6.6511653363704681e-02
    z[3,2,0]  R1038     3.7986478209495544e-01
    z[3,2,0]  R1039     -4.3224725127220154e-01
    z[3,2,0]  R1040     2.6944720745086670e-01
    z[3,2,0]  R1041     -1.1762320250272751e-01
    z[3,2,0]  R1042     5.9010595083236694e-01
    z[3,2,0]  R1043     -6.5369868278503418e-01
    z[3,2,0]  R1044     1.5902586281299591e-01
    z[3,2,0]  R1045     -6.5894013643264771e-01
    z[3,2,0]  R1046     3.0720660090446472e-01
    z[3,2,0]  R1047     2.7164104580879211e-01
    z[3,2,0]  R1048     -4.1422676295042038e-02
    z[3,2,0]  R1049     -2.6115933060646057e-01
    z[3,2,0]  R1050     -4.4731575250625610e-01
    z[3,2,0]  R1051     -5.7417166233062744e-01
    z[3,2,0]  R1052     0.747056782245636
    z[3,2,0]  R1053     0.775826096534729
    z[3,2,0]  R1054     -1.7995016276836395e-01
    z[3,2,0]  R1055     1.1530910432338715e-01
    z[3,2,0]  R1056     -3.6128619313240051e-01
    z[3,2,0]  R1057     -4.2039236426353455e-01
    z[3,2,0]  R1058     -2.6028716564178467e-01
    z[3,2,0]  R1059     -5.2616310119628906e-01
    z[3,2,0]  R1060     -3.8607782125473022e-01
    z[3,2,0]  R1061     0.791607677936554
    z[3,2,0]  R1062     5.4138455539941788e-02
    z[3,2,0]  R1063     1.5371054410934448e-01
    z[3,2,0]  R1064     1.1704263836145401e-01
    z[3,2,0]  R1065     -4.8452970385551453e-01
    z[3,2,0]  R1066     9.5285169780254364e-02
    z[3,2,0]  R1067     1.9031725823879242e-01
    z[3,2,0]  R1068     -3.6664411425590515e-01
    z[3,2,0]  R1069     2.4678209424018860e-01
    z[3,2,0]  R1070     9.0622341632843018e-01
    z[3,2,0]  R1071     6.1857986450195312e-01
    z[3,2,0]  R1072     1.1635594815015793e-01
    z[3,2,0]  R1073     -1.5081866644322872e-02
    z[3,2,0]  R1074     1.7375077307224274e-01
    z[3,2,0]  R1075     1.0416479408740997e-01
    z[3,2,0]  R1076     3.5076405853033066e-02
    z[3,2,0]  R1077     1.1815072596073151e-01
    z[3,2,0]  R1078     1.3126258552074432e-01
    z[3,2,0]  R1079     4.0457978844642639e-02
    z[3,2,0]  R1080     -3.9107404649257660e-02
    z[3,2,0]  R1081     -7.3462487198412418e-03
    z[3,2,0]  R1082     -2.0507071912288666e-01
    z[3,2,0]  R1083     5.1161199808120728e-02
    z[3,2,0]  R1084     -5.0340861082077026e-02
    z[3,2,0]  R1085     1.0358274728059769e-01
    z[3,2,0]  R1086     -1.6905583441257477e-02
    z[3,2,0]  R1087     1.8200548365712166e-02
    z[3,2,0]  R1088     -1.5195293724536896e-01
    z[3,2,0]  R1089     -1.0875476151704788e-01
    z[3,2,0]  R1090     -1.0530030727386475e-01
    z[3,2,0]  R1091     -1.1921381205320358e-01
    z[3,2,0]  R1092     -9.4531789422035217e-02
    z[3,2,0]  R1093     -9.7032509744167328e-02
    z[3,2,0]  R1094     -1.1137016862630844e-01
    z[3,2,0]  R1095     -1.5104120969772339e-01
    z[3,2,0]  R1096     -8.7838634848594666e-02
    z[3,2,0]  R1097     -9.9680311977863312e-02
    z[3,2,0]  R1098     -1.4754776656627655e-01
    z[3,2,0]  R1099     -6.5765053033828735e-02
    z[3,2,0]  R1100     -1.2139682471752167e-01
    z[3,2,0]  R1101     2.1158248186111450e-02
    z[3,2,0]  R1102     -1.4087593555450439e-01
    z[3,2,0]  R1103     9.5251291990280151e-02
    z[3,2,0]  R1104     -0.0731421485543251
    z[3,2,0]  R1105     -1.8635485321283340e-02
    z[3,2,0]  R1106     -1.7498539388179779e-01
    z[3,2,0]  R1107     -1.8789456784725189e-01
    z[3,2,0]  R1108     -2.5243632495403290e-02
    z[3,2,0]  R1109     -5.5284440517425537e-02
    z[3,2,0]  R1110     -6.9861665368080139e-02
    z[3,2,0]  R1111     8.2318651676177979e-01
    z[3,2,0]  R1112     -5.5996431037783623e-03
    z[3,2,0]  R1113     -8.5662461817264557e-02
    z[3,2,0]  R1114     -3.8488205522298813e-02
    z[3,2,0]  R1115     -9.2685915529727936e-02
    z[3,2,0]  R1116     -1.4319211244583130e-01
    z[3,2,0]  R1117     -1.0172440856695175e-01
    z[3,2,0]  R1118     -8.5732407867908478e-02
    z[3,2,0]  R1119     6.5032929182052612e-01
    z[3,2,0]  R1120     6.3057667016983032e-01
    z[3,2,0]  R1121     6.4594465494155884e-01
    z[3,2,0]  R1122     7.2314405441284180e-01
    z[3,2,1]  R21       1
    z[3,2,1]  R30       -1
    z[3,2,1]  R992      -1
    z[3,2,1]  R993      1
    z[3,2,1]  R1004     -1.8147509545087814e-02
    z[3,2,1]  R1005     -2.6586961001157761e-02
    z[3,2,1]  R1006     0.00369931454770267
    z[3,2,1]  R1007     6.3879147171974182e-02
    z[3,2,1]  R1008     -1.9923512637615204e-01
    z[3,2,1]  R1009     -1.0005772858858109e-01
    z[3,2,1]  R1010     7.6027326285839081e-02
    z[3,2,1]  R1011     1.4623862504959106e-01
    z[3,2,1]  R1012     1.8217091262340546e-01
    z[3,2,1]  R1013     -1.3551914691925049e-01
    z[3,2,1]  R1014     -2.8927680850028992e-01
    z[3,2,1]  R1015     2.6945912837982178e-01
    z[3,2,1]  R1016     -2.3118519783020020e-01
    z[3,2,1]  R1017     5.8011960983276367e-01
    z[3,2,1]  R1018     2.3392921686172485e-01
    z[3,2,1]  R1019     7.2063136100769043e-01
    z[3,2,1]  R1020     2.6466074585914612e-01
    z[3,2,1]  R1021     7.8480696678161621e-01
    z[3,2,1]  R1022     5.6278330087661743e-01
    z[3,2,1]  R1023     3.4769752621650696e-01
    z[3,2,1]  R1024     5.1476502418518066e-01
    z[3,2,1]  R1025     4.7450292110443115e-01
    z[3,2,1]  R1026     4.6423131227493286e-01
    z[3,2,1]  R1027     3.0879806727170944e-02
    z[3,2,1]  R1028     7.7803015708923340e-01
    z[3,2,1]  R1029     -1.0528992861509323e-01
    z[3,2,1]  R1030     4.0154322981834412e-01
    z[3,2,1]  R1031     3.8039916753768921e-01
    z[3,2,1]  R1032     -3.7814763188362122e-01
    z[3,2,1]  R1033     5.5834829807281494e-01
    z[3,2,1]  R1034     7.5402897596359253e-01
    z[3,2,1]  R1035     4.1881687939167023e-02
    z[3,2,1]  R1036     5.8069932460784912e-01
    z[3,2,1]  R1037     0.658522367477417
    z[3,2,1]  R1038     5.2583056688308716e-01
    z[3,2,1]  R1039     4.9912261962890625e-01
    z[3,2,1]  R1040     5.3118276596069336e-01
    z[3,2,1]  R1041     4.6213954687118530e-01
    z[3,2,1]  R1042     6.0919177532196045e-01
    z[3,2,1]  R1043     -3.1659671664237976e-01
    z[3,2,1]  R1044     6.4564794301986694e-01
    z[3,2,1]  R1045     5.5827665328979492e-01
    z[3,2,1]  R1046     4.9820753931999207e-01
    z[3,2,1]  R1047     5.0807380676269531e-01
    z[3,2,1]  R1048     3.1307044625282288e-01
    z[3,2,1]  R1049     2.9546493291854858e-01
    z[3,2,1]  R1050     3.7226030230522156e-01
    z[3,2,1]  R1051     2.3870619013905525e-02
    z[3,2,1]  R1052     1.4187602698802948e-01
    z[3,2,1]  R1053     -2.5463572144508362e-01
    z[3,2,1]  R1054     8.2051777839660645e-01
    z[3,2,1]  R1055     7.2249752283096313e-01
    z[3,2,1]  R1056     -1.9844371825456619e-02
    z[3,2,1]  R1057     1.3561069965362549e-01
    z[3,2,1]  R1058     2.0917631685733795e-01
    z[3,2,1]  R1059     -3.0464905500411987e-01
    z[3,2,1]  R1060     -8.9196532964706421e-02
    z[3,2,1]  R1061     5.2294093370437622e-01
    z[3,2,1]  R1062     5.9315097332000732e-01
    z[3,2,1]  R1063     0.555571973323822
    z[3,2,1]  R1064     6.8589460849761963e-01
    z[3,2,1]  R1065     -0.271817684173584
    z[3,2,1]  R1066     7.6071041822433472e-01
    z[3,2,1]  R1067     6.5266501903533936e-01
    z[3,2,1]  R1068     -7.4946634471416473e-02
    z[3,2,1]  R1069     7.4575155973434448e-01
    z[3,2,1]  R1070     -3.2170295715332031e-02
    z[3,2,1]  R1071     -6.4777153730392456e-01
    z[3,2,1]  R1072     -6.4375817775726318e-01
    z[3,2,1]  R1073     -8.7924355268478394e-01
    z[3,2,1]  R1074     -0.188704252243042
    z[3,2,1]  R1075     -2.4665230512619019e-01
    z[3,2,1]  R1076     -7.5864009559154510e-02
    z[3,2,1]  R1077     -1.4523386955261230e-01
    z[3,2,1]  R1078     3.9027415215969086e-02
    z[3,2,1]  R1079     3.2125559449195862e-01
    z[3,2,1]  R1080     -8.7640094757080078e-01
    z[3,2,1]  R1081     2.4323654174804688e-01
    z[3,2,1]  R1082     -7.8582540154457092e-02
    z[3,2,1]  R1083     9.0698373317718506e-01
    z[3,2,1]  R1084     7.7767539024353027e-01
    z[3,2,1]  R1085     7.6909792423248291e-01
    z[3,2,1]  R1086     7.4120289087295532e-01
    z[3,2,1]  R1087     0.731759786605835
    z[3,2,1]  R1088     6.7997241020202637e-01
    z[3,2,1]  R1089     6.6865491867065430e-01
    z[3,2,1]  R1090     0.649121105670929
    z[3,2,1]  R1091     0.642539918422699
    z[3,2,1]  R1092     6.3295543193817139e-01
    z[3,2,1]  R1093     5.9669071435928345e-01
    z[3,2,1]  R1094     -1.3306954503059387e-01
    z[3,2,1]  R1095     -5.5064046382904053e-01
    z[3,2,1]  R1096     -0.590140163898468
    z[3,2,1]  R1097     -4.8204281926155090e-01
    z[3,2,1]  R1098     -3.4903496503829956e-01
    z[3,2,1]  R1099     -2.7629068493843079e-01
    z[3,2,1]  R1100     -4.7363707423210144e-01
    z[3,2,1]  R1101     -9.0629106760025024e-01
    z[3,2,1]  R1102     -5.0873714685440063e-01
    z[3,2,1]  R1103     8.0913090705871582e-01
    z[3,2,1]  R1104     6.0107976198196411e-01
    z[3,2,1]  R1105     5.5919289588928223e-01
    z[3,2,1]  R1106     -1.8453678488731384e-01
    z[3,2,1]  R1107     -2.1710814535617828e-01
    z[3,2,1]  R1108     -9.4162505865097046e-01
    z[3,2,1]  R1109     -9.0053504705429077e-01
    z[3,2,1]  R1110     -8.9092463254928589e-01
    z[3,2,1]  R1111     -5.0908583402633667e-01
    z[3,2,1]  R1112     -8.8902920484542847e-01
    z[3,2,1]  R1113     8.2013344764709473e-01
    z[3,2,1]  R1114     6.7155414819717407e-01
    z[3,2,1]  R1115     4.3844765424728394e-01
    z[3,2,1]  R1116     -9.7919665277004242e-02
    z[3,2,1]  R1117     -5.9339928627014160e-01
    z[3,2,1]  R1118     -8.5561513900756836e-01
    z[3,2,1]  R1119     -5.1422142982482910e-01
    z[3,2,1]  R1120     -5.1929527521133423e-01
    z[3,2,1]  R1121     -0.442984014749527
    z[3,2,1]  R1122     -2.8734889626502991e-01
    z[3,2,2]  R22       1
    z[3,2,2]  R31       -1
    z[3,2,2]  R994      -1
    z[3,2,2]  R995      1
    z[3,2,2]  R1004     2.0380039513111115e-01
    z[3,2,2]  R1005     1.6424112021923065e-01
    z[3,2,2]  R1006     1.9458401203155518e-01
    z[3,2,2]  R1007     1.3415600359439850e-01
    z[3,2,2]  R1008     1.6791100800037384e-01
    z[3,2,2]  R1009     0.255410760641098
    z[3,2,2]  R1010     -3.5475820302963257e-01
    z[3,2,2]  R1011     -3.3877888321876526e-01
    z[3,2,2]  R1012     -6.6418254375457764e-01
    z[3,2,2]  R1013     -3.8884088397026062e-01
    z[3,2,2]  R1014     4.8751473426818848e-01
    z[3,2,2]  R1015     6.6513568162918091e-01
    z[3,2,2]  R1016     6.8369269371032715e-01
    z[3,2,2]  R1017     2.1148090064525604e-01
    z[3,2,2]  R1018     1.4423067867755890e-01
    z[3,2,2]  R1019     -2.1882466971874237e-01
    z[3,2,2]  R1020     0.378388911485672
    z[3,2,2]  R1021     -2.1996329724788666e-01
    z[3,2,2]  R1022     4.2632156610488892e-01
    z[3,2,2]  R1023     -2.0593171939253807e-02
    z[3,2,2]  R1024     -1.3001163303852081e-01
    z[3,2,2]  R1025     8.7742239236831665e-02
    z[3,2,2]  R1026     6.3745164871215820e-01
    z[3,2,2]  R1027     -2.4686776101589203e-01
    z[3,2,2]  R1028     -4.6482320874929428e-02
    z[3,2,2]  R1029     -5.6497758626937866e-01
    z[3,2,2]  R1030     -4.6835571527481079e-01
    z[3,2,2]  R1031     -2.2003506124019623e-01
    z[3,2,2]  R1032     -1.1988830566406250e-01
    z[3,2,2]  R1033     -1.6529999673366547e-01
    z[3,2,2]  R1034     -3.4255844354629517e-01
    z[3,2,2]  R1035     2.1844626963138580e-01
    z[3,2,2]  R1036     0.0618012435734272
    z[3,2,2]  R1037     -2.6322066783905029e-01
    z[3,2,2]  R1038     4.9342596530914307e-01
    z[3,2,2]  R1039     -2.3038223385810852e-01
    z[3,2,2]  R1040     -1.2890572845935822e-01
    z[3,2,2]  R1041     4.1803103685379028e-01
    z[3,2,2]  R1042     1.0757859796285629e-01
    z[3,2,2]  R1043     1.4735744893550873e-01
    z[3,2,2]  R1044     1.1390602588653564e-01
    z[3,2,2]  R1045     1.5017402172088623e-01
    z[3,2,2]  R1046     6.4315325021743774e-01
    z[3,2,2]  R1047     3.0384641885757446e-01
    z[3,2,2]  R1048     6.2764132022857666e-01
    z[3,2,2]  R1049     4.3027636408805847e-01
    z[3,2,2]  R1050     1.6781453788280487e-01
    z[3,2,2]  R1051     6.8919695913791656e-02
    z[3,2,2]  R1052     -6.2851980328559875e-02
    z[3,2,2]  R1053     -1.3999626040458679e-01
    z[3,2,2]  R1054     7.3459409177303314e-02
    z[3,2,2]  R1055     3.7138587236404419e-01
    z[3,2,2]  R1056     2.0932666957378387e-01
    z[3,2,2]  R1057     2.2971647977828979e-01
    z[3,2,2]  R1058     3.4135237336158752e-01
    z[3,2,2]  R1059     1.6996251046657562e-01
    z[3,2,2]  R1060     8.2678878307342529e-01
    z[3,2,2]  R1061     2.2051315754652023e-02
    z[3,2,2]  R1062     -6.0025709867477417e-01
    z[3,2,2]  R1063     1.9501638412475586e-01
    z[3,2,2]  R1064     4.6038147807121277e-01
    z[3,2,2]  R1065     3.8770639896392822e-01
    z[3,2,2]  R1066     -3.3164015412330627e-01
    z[3,2,2]  R1067     1.6177296638488770e-01
    z[3,2,2]  R1068     7.0908272266387939e-01
    z[3,2,2]  R1069     -0.51152503490448
    z[3,2,2]  R1070     7.7022803016006947e-03
    z[3,2,2]  R1071     -3.3185330033302307e-01
    z[3,2,2]  R1072     1.8339410424232483e-01
    z[3,2,2]  R1073     2.6918539777398109e-02
    z[3,2,2]  R1074     -4.4951781630516052e-01
    z[3,2,2]  R1075     -5.7896214723587036e-01
    z[3,2,2]  R1076     -7.5325781106948853e-01
    z[3,2,2]  R1077     -6.0198068618774414e-01
    z[3,2,2]  R1078     2.7803765609860420e-02
    z[3,2,2]  R1079     4.9266871809959412e-01
    z[3,2,2]  R1080     1.9959209859371185e-01
    z[3,2,2]  R1081     6.3347554206848145e-01
    z[3,2,2]  R1082     3.4610655903816223e-01
    z[3,2,2]  R1083     -9.4338893890380859e-02
    z[3,2,2]  R1084     -2.8370854258537292e-01
    z[3,2,2]  R1085     1.4953862130641937e-01
    z[3,2,2]  R1086     2.9757255315780640e-01
    z[3,2,2]  R1087     5.3267461061477661e-01
    z[3,2,2]  R1088     4.1305556893348694e-01
    z[3,2,2]  R1089     1.0275747627019882e-01
    z[3,2,2]  R1090     2.9723986983299255e-01
    z[3,2,2]  R1091     2.5612899661064148e-01
    z[3,2,2]  R1092     1.3214507699012756e-01
    z[3,2,2]  R1093     8.6175657808780670e-02
    z[3,2,2]  R1094     4.3202412128448486e-01
    z[3,2,2]  R1095     4.8419484496116638e-01
    z[3,2,2]  R1096     3.3047696948051453e-01
    z[3,2,2]  R1097     5.3097373247146606e-01
    z[3,2,2]  R1098     4.6801841259002686e-01
    z[3,2,2]  R1099     2.5067463517189026e-01
    z[3,2,2]  R1100     3.1835344433784485e-01
    z[3,2,2]  R1101     2.5098061561584473e-01
    z[3,2,2]  R1102     1.9846871495246887e-01
    z[3,2,2]  R1103     2.8659293428063393e-02
    z[3,2,2]  R1104     -2.0808011293411255e-01
    z[3,2,2]  R1105     5.2410387992858887e-01
    z[3,2,2]  R1106     0.0869893953204155
    z[3,2,2]  R1107     4.6075470745563507e-02
    z[3,2,2]  R1108     -9.9441379308700562e-02
    z[3,2,2]  R1109     2.8549528121948242e-01
    z[3,2,2]  R1110     1.1278945207595825e-01
    z[3,2,2]  R1111     4.9462612718343735e-02
    z[3,2,2]  R1112     -1.4428270515054464e-03
    z[3,2,2]  R1113     1.0920712351799011e-01
    z[3,2,2]  R1114     2.8010737895965576e-01
    z[3,2,2]  R1115     2.0575119182467461e-02
    z[3,2,2]  R1116     -0.0702795684337616
    z[3,2,2]  R1117     -0.0913701057434082
    z[3,2,2]  R1118     2.1251454949378967e-01
    z[3,2,2]  R1119     2.9008436203002930e-01
    z[3,2,2]  R1120     3.0944174528121948e-01
    z[3,2,2]  R1121     4.6052265167236328e-01
    z[3,2,2]  R1122     -8.3492629230022430e-02
    z[3,2,3]  R23       1
    z[3,2,3]  R32       -1
    z[3,2,3]  R996      -1
    z[3,2,3]  R997      1
    z[3,2,3]  R1004     -7.9531884193420410e-01
    z[3,2,3]  R1005     -2.1419633924961090e-01
    z[3,2,3]  R1006     -7.8271585702896118e-01
    z[3,2,3]  R1007     -0.861125111579895
    z[3,2,3]  R1008     -8.1278353929519653e-01
    z[3,2,3]  R1009     -1.5331903100013733e-01
    z[3,2,3]  R1010     7.7234938740730286e-02
    z[3,2,3]  R1011     6.7612268030643463e-02
    z[3,2,3]  R1012     2.5660252571105957e-01
    z[3,2,3]  R1013     -6.4098340272903442e-01
    z[3,2,3]  R1014     5.8287929743528366e-02
    z[3,2,3]  R1015     2.7959231287240982e-02
    z[3,2,3]  R1016     -1.0461293160915375e-01
    z[3,2,3]  R1017     1.8379074335098267e-01
    z[3,2,3]  R1018     1.5539652109146118e-01
    z[3,2,3]  R1019     4.1253589093685150e-02
    z[3,2,3]  R1020     -1.8871749937534332e-01
    z[3,2,3]  R1021     -4.9115356802940369e-01
    z[3,2,3]  R1022     -3.8400459289550781e-01
    z[3,2,3]  R1023     5.5019551515579224e-01
    z[3,2,3]  R1024     -3.8510710000991821e-01
    z[3,2,3]  R1025     -1.6262365877628326e-01
    z[3,2,3]  R1026     1.7351378500461578e-01
    z[3,2,3]  R1027     -8.0030553042888641e-02
    z[3,2,3]  R1028     -4.0627697110176086e-01
    z[3,2,3]  R1029     -3.0941897630691528e-01
    z[3,2,3]  R1030     1.0074589401483536e-01
    z[3,2,3]  R1031     -6.4366863807663321e-04
    z[3,2,3]  R1032     -0.552621603012085
    z[3,2,3]  R1033     5.6718343496322632e-01
    z[3,2,3]  R1034     2.0407845079898834e-01
    z[3,2,3]  R1035     -5.3206861019134521e-01
    z[3,2,3]  R1036     2.4289989471435547e-01
    z[3,2,3]  R1037     1.6189590096473694e-02
    z[3,2,3]  R1038     4.3716889619827271e-01
    z[3,2,3]  R1039     5.6508713960647583e-01
    z[3,2,3]  R1040     -0.0973648726940155
    z[3,2,3]  R1041     5.7831853628158569e-01
    z[3,2,3]  R1042     -6.6572129726409912e-02
    z[3,2,3]  R1043     -2.7399215102195740e-01
    z[3,2,3]  R1044     -6.6143953800201416e-01
    z[3,2,3]  R1045     4.1986754536628723e-01
    z[3,2,3]  R1046     -2.3869954049587250e-01
    z[3,2,3]  R1047     -3.1929448246955872e-01
    z[3,2,3]  R1048     -3.4203460812568665e-01
    z[3,2,3]  R1049     -2.7745443582534790e-01
    z[3,2,3]  R1050     -1.5969966351985931e-01
    z[3,2,3]  R1051     -2.3088859394192696e-02
    z[3,2,3]  R1052     1.9278062880039215e-01
    z[3,2,3]  R1053     -1.4659017324447632e-01
    z[3,2,3]  R1054     -1.0071203112602234e-02
    z[3,2,3]  R1055     -4.1415423154830933e-01
    z[3,2,3]  R1056     -8.4944957494735718e-01
    z[3,2,3]  R1057     -5.6782656908035278e-01
    z[3,2,3]  R1058     -5.3837972879409790e-01
    z[3,2,3]  R1059     -1.9293190538883209e-01
    z[3,2,3]  R1060     1.9563492387533188e-02
    z[3,2,3]  R1061     -1.4713719487190247e-01
    z[3,2,3]  R1062     3.4421697258949280e-01
    z[3,2,3]  R1063     6.0054361820220947e-01
    z[3,2,3]  R1064     -1.2486293166875839e-01
    z[3,2,3]  R1065     -5.4064434766769409e-01
    z[3,2,3]  R1066     3.0994030833244324e-01
    z[3,2,3]  R1067     -6.5386700630187988e-01
    z[3,2,3]  R1068     -2.6555222272872925e-01
    z[3,2,3]  R1069     2.4559656158089638e-02
    z[3,2,3]  R1070     -5.6275906972587109e-03
    z[3,2,3]  R1071     -1.1046132072806358e-02
    z[3,2,3]  R1072     5.8191090822219849e-01
    z[3,2,3]  R1073     4.4353199005126953e-01
    z[3,2,3]  R1074     -7.4526280164718628e-01
    z[3,2,3]  R1075     -6.8571335077285767e-01
    z[3,2,3]  R1076     -3.4381410479545593e-01
    z[3,2,3]  R1077     -4.9803760647773743e-01
    z[3,2,3]  R1078     -8.3985865116119385e-01
    z[3,2,3]  R1079     -0.0569143183529377
    z[3,2,3]  R1080     1.1172537505626678e-01
    z[3,2,3]  R1081     2.8988546133041382e-01
    z[3,2,3]  R1082     3.5846811532974243e-01
    z[3,2,3]  R1083     7.7495403587818146e-02
    z[3,2,3]  R1084     1.9534422457218170e-01
    z[3,2,3]  R1085     2.9060753062367439e-02
    z[3,2,3]  R1086     -5.9179320931434631e-02
    z[3,2,3]  R1087     -3.4050792455673218e-01
    z[3,2,3]  R1088     3.6460673809051514e-01
    z[3,2,3]  R1089     5.4198390245437622e-01
    z[3,2,3]  R1090     0.00823516957461834
    z[3,2,3]  R1091     4.8303452134132385e-01
    z[3,2,3]  R1092     1.5749073028564453e-01
    z[3,2,3]  R1093     4.3526706099510193e-01
    z[3,2,3]  R1094     7.9342108964920044e-01
    z[3,2,3]  R1095     6.5937399864196777e-01
    z[3,2,3]  R1096     6.5896546840667725e-01
    z[3,2,3]  R1097     6.2674939632415771e-01
    z[3,2,3]  R1098     6.7736089229583740e-01
    z[3,2,3]  R1099     7.3747175931930542e-01
    z[3,2,3]  R1100     6.9485068321228027e-01
    z[3,2,3]  R1101     -5.8983918279409409e-03
    z[3,2,3]  R1102     7.4100762605667114e-01
    z[3,2,3]  R1103     -5.2359545230865479e-01
    z[3,2,3]  R1104     1.0568166524171829e-01
    z[3,2,3]  R1105     -4.7711357474327087e-03
    z[3,2,3]  R1106     0.899384617805481
    z[3,2,3]  R1107     9.2336362600326538e-01
    z[3,2,3]  R1108     2.6426756381988525e-01
    z[3,2,3]  R1109     6.7940421402454376e-02
    z[3,2,3]  R1110     2.9856231808662415e-01
    z[3,2,3]  R1111     2.1147172152996063e-01
    z[3,2,3]  R1112     1.3571204245090485e-01
    z[3,2,3]  R1113     2.6888519525527954e-01
    z[3,2,3]  R1114     3.7405043840408325e-01
    z[3,2,3]  R1115     -1.7554442584514618e-01
    z[3,2,3]  R1116     9.7027087211608887e-01
    z[3,2,3]  R1117     7.2116440534591675e-01
    z[3,2,3]  R1118     1.2738877534866333e-01
    z[3,2,3]  R1119     0.232284277677536
    z[3,2,3]  R1120     1.7936527729034424e-01
    z[3,2,3]  R1121     5.1085177809000015e-02
    z[3,2,3]  R1122     3.9830267429351807e-01
    z[3,2,4]  R24       1
    z[3,2,4]  R33       -1
    z[3,2,4]  R998      -1
    z[3,2,4]  R999      1
    z[3,2,4]  R1004     4.5091444253921509e-01
    z[3,2,4]  R1005     3.5913035273551941e-01
    z[3,2,4]  R1006     -1.0920819640159607e-01
    z[3,2,4]  R1007     -1.9991688430309296e-01
    z[3,2,4]  R1008     -1.6100019216537476e-01
    z[3,2,4]  R1009     8.1068587303161621e-01
    z[3,2,4]  R1010     8.9609727263450623e-02
    z[3,2,4]  R1011     2.7591744065284729e-01
    z[3,2,4]  R1012     -0.0668027475476265
    z[3,2,4]  R1013     5.3418558835983276e-01
    z[3,2,4]  R1014     1.4315286278724670e-01
    z[3,2,4]  R1015     -4.9541953206062317e-01
    z[3,2,4]  R1016     -2.9208657145500183e-01
    z[3,2,4]  R1017     -1.8198199570178986e-01
    z[3,2,4]  R1018     1.9836862385272980e-01
    z[3,2,4]  R1019     -4.6531128883361816e-01
    z[3,2,4]  R1020     1.8763022124767303e-01
    z[3,2,4]  R1021     -1.1969381570816040e-01
    z[3,2,4]  R1022     -4.3034926056861877e-02
    z[3,2,4]  R1023     -3.5530057549476624e-01
    z[3,2,4]  R1024     3.1916370987892151e-01
    z[3,2,4]  R1025     1.7346268892288208e-01
    z[3,2,4]  R1026     3.7924036383628845e-01
    z[3,2,4]  R1027     -0.402294784784317
    z[3,2,4]  R1028     1.5069231390953064e-01
    z[3,2,4]  R1029     1.5406759083271027e-01
    z[3,2,4]  R1030     -2.8166621923446655e-01
    z[3,2,4]  R1031     -2.3513855040073395e-01
    z[3,2,4]  R1032     -8.8977195322513580e-02
    z[3,2,4]  R1033     2.2409638762474060e-01
    z[3,2,4]  R1034     0.154669389128685
    z[3,2,4]  R1035     -4.5688340067863464e-01
    z[3,2,4]  R1036     3.1223863363265991e-01
    z[3,2,4]  R1037     -6.3753414154052734e-01
    z[3,2,4]  R1038     3.0572861433029175e-02
    z[3,2,4]  R1039     1.2119908630847931e-01
    z[3,2,4]  R1040     0.698492169380188
    z[3,2,4]  R1041     -4.4865887612104416e-02
    z[3,2,4]  R1042     3.1009644269943237e-01
    z[3,2,4]  R1043     4.3205186724662781e-01
    z[3,2,4]  R1044     0.206967294216156
    z[3,2,4]  R1045     1.5200087428092957e-01
    z[3,2,4]  R1046     -0.355514258146286
    z[3,2,4]  R1047     -2.3040850460529327e-01
    z[3,2,4]  R1048     3.6587229371070862e-01
    z[3,2,4]  R1049     4.1439098119735718e-01
    z[3,2,4]  R1050     4.6595939993858337e-01
    z[3,2,4]  R1051     -3.7213604897260666e-02
    z[3,2,4]  R1052     -2.6540291309356689e-01
    z[3,2,4]  R1053     1.5093008987605572e-02
    z[3,2,4]  R1054     4.3244457244873047e-01
    z[3,2,4]  R1055     3.5639411211013794e-01
    z[3,2,4]  R1056     1.0726187378168106e-01
    z[3,2,4]  R1057     4.2680940032005310e-01
    z[3,2,4]  R1058     4.7016337513923645e-01
    z[3,2,4]  R1059     6.8323320150375366e-01
    z[3,2,4]  R1060     2.3376402258872986e-01
    z[3,2,4]  R1061     -6.5653212368488312e-02
    z[3,2,4]  R1062     1.4682777225971222e-01
    z[3,2,4]  R1063     -3.3612582087516785e-01
    z[3,2,4]  R1064     -4.4868391752243042e-01
    z[3,2,4]  R1065     3.8247746229171753e-01
    z[3,2,4]  R1066     -2.6561981439590454e-01
    z[3,2,4]  R1067     -2.7899253368377686e-01
    z[3,2,4]  R1068     -1.0250168852508068e-02
    z[3,2,4]  R1069     3.3220660686492920e-01
    z[3,2,4]  R1070     3.8770094513893127e-01
    z[3,2,4]  R1071     -1.7438489198684692e-01
    z[3,2,4]  R1072     -1.4591903984546661e-01
    z[3,2,4]  R1073     -1.5090203844010830e-02
    z[3,2,4]  R1074     -3.7721905112266541e-01
    z[3,2,4]  R1075     7.5825735926628113e-02
    z[3,2,4]  R1076     1.9991464912891388e-01
    z[3,2,4]  R1077     4.4819310307502747e-01
    z[3,2,4]  R1078     4.4935014843940735e-01
    z[3,2,4]  R1079     -7.5711631774902344e-01
    z[3,2,4]  R1080     3.1309577822685242e-01
    z[3,2,4]  R1081     8.7982267141342163e-02
    z[3,2,4]  R1082     4.1028323769569397e-01
    z[3,2,4]  R1083     -1.1457324773073196e-01
    z[3,2,4]  R1084     2.8668063879013062e-01
    z[3,2,4]  R1085     3.5323154926300049e-01
    z[3,2,4]  R1086     -2.6967665553092957e-01
    z[3,2,4]  R1087     -1.3486875593662262e-01
    z[3,2,4]  R1088     3.0621844530105591e-01
    z[3,2,4]  R1089     3.8816508650779724e-01
    z[3,2,4]  R1090     6.6257226467132568e-01
    z[3,2,4]  R1091     -2.9584395885467529e-01
    z[3,2,4]  R1092     5.8784645795822144e-01
    z[3,2,4]  R1093     1.3013081252574921e-01
    z[3,2,4]  R1094     -3.3607015013694763e-01
    z[3,2,4]  R1095     4.4919040054082870e-02
    z[3,2,4]  R1096     -2.5752422213554382e-01
    z[3,2,4]  R1097     -1.4710766077041626e-01
    z[3,2,4]  R1098     -6.0857083648443222e-02
    z[3,2,4]  R1099     -4.1886419057846069e-01
    z[3,2,4]  R1100     -2.7050018310546875e-01
    z[3,2,4]  R1101     -0.0910007506608963
    z[3,2,4]  R1102     1.0590924322605133e-01
    z[3,2,4]  R1103     -9.0013951063156128e-02
    z[3,2,4]  R1104     -2.6118251681327820e-01
    z[3,2,4]  R1105     0.267488956451416
    z[3,2,4]  R1106     -2.1014265716075897e-01
    z[3,2,4]  R1107     1.6813451051712036e-01
    z[3,2,4]  R1108     -1.6713267564773560e-01
    z[3,2,4]  R1109     -0.00890843104571104
    z[3,2,4]  R1110     1.3897763192653656e-01
    z[3,2,4]  R1111     1.1517754197120667e-01
    z[3,2,4]  R1112     1.5052539110183716e-01
    z[3,2,4]  R1113     4.7526782751083374e-01
    z[3,2,4]  R1114     -5.2258223295211792e-01
    z[3,2,4]  R1115     6.3477098941802979e-01
    z[3,2,4]  R1116     -9.3176737427711487e-02
    z[3,2,4]  R1117     -1.1465954780578613e-01
    z[3,2,4]  R1118     4.3941894173622131e-01
    z[3,2,4]  R1119     -1.8070462346076965e-01
    z[3,2,4]  R1120     -3.7156096100807190e-01
    z[3,2,4]  R1121     -2.0955021679401398e-01
    z[3,2,4]  R1122     -3.6808863282203674e-01
    z[3,2,5]  R25       1
    z[3,2,5]  R34       -1
    z[3,2,5]  R1000     -1
    z[3,2,5]  R1001     1
    z[3,2,5]  R1004     -2.4964088201522827e-01
    z[3,2,5]  R1005     -8.1494313478469849e-01
    z[3,2,5]  R1006     4.0266877412796021e-01
    z[3,2,5]  R1007     8.6275830864906311e-02
    z[3,2,5]  R1008     -6.1682611703872681e-02
    z[3,2,5]  R1009     -4.3264696002006531e-01
    z[3,2,5]  R1010     3.9988461136817932e-01
    z[3,2,5]  R1011     3.7383088469505310e-01
    z[3,2,5]  R1012     6.3645350933074951e-01
    z[3,2,5]  R1013     8.7714329361915588e-02
    z[3,2,5]  R1014     1.3221102952957153e-01
    z[3,2,5]  R1015     -9.0258710086345673e-02
    z[3,2,5]  R1016     1.4950045943260193e-01
    z[3,2,5]  R1017     1.0186498612165451e-01
    z[3,2,5]  R1018     -4.4034279882907867e-02
    z[3,2,5]  R1019     4.1084337234497070e-01
    z[3,2,5]  R1020     3.4483358263969421e-01
    z[3,2,5]  R1021     -2.2557886317372322e-02
    z[3,2,5]  R1022     3.2967728376388550e-01
    z[3,2,5]  R1023     5.1698958873748779e-01
    z[3,2,5]  R1024     -3.5127472877502441e-01
    z[3,2,5]  R1025     0.733608067035675
    z[3,2,5]  R1026     -2.3174121975898743e-01
    z[3,2,5]  R1027     -2.0580349862575531e-01
    z[3,2,5]  R1028     3.1133580207824707e-01
    z[3,2,5]  R1029     1.8946586549282074e-01
    z[3,2,5]  R1030     -4.0162327885627747e-01
    z[3,2,5]  R1031     -3.1405779719352722e-01
    z[3,2,5]  R1032     -3.9064630866050720e-02
    z[3,2,5]  R1033     -5.4667103104293346e-03
    z[3,2,5]  R1034     -8.8266089558601379e-02
    z[3,2,5]  R1035     -9.2325031757354736e-02
    z[3,2,5]  R1036     -1.6009141504764557e-01
    z[3,2,5]  R1037     -5.7933915406465530e-02
    z[3,2,5]  R1038     1.6093787550926208e-01
    z[3,2,5]  R1039     4.1721498966217041e-01
    z[3,2,5]  R1040     -9.5735192298889160e-02
    z[3,2,5]  R1041     2.5789514183998108e-01
    z[3,2,5]  R1042     -3.9667010307312012e-01
    z[3,2,5]  R1043     -3.6002573370933533e-01
    z[3,2,5]  R1044     -2.4313493072986603e-01
    z[3,2,5]  R1045     -7.2068810462951660e-02
    z[3,2,5]  R1046     1.2798270583152771e-01
    z[3,2,5]  R1047     -6.2841761112213135e-01
    z[3,2,5]  R1048     6.1056271195411682e-02
    z[3,2,5]  R1049     -1.8165180087089539e-01
    z[3,2,5]  R1050     5.8593624830245972e-01
    z[3,2,5]  R1051     3.5766917467117310e-01
    z[3,2,5]  R1052     5.3547525405883789e-01
    z[3,2,5]  R1053     4.1101586073637009e-02
    z[3,2,5]  R1054     1.0764109343290329e-01
    z[3,2,5]  R1055     -1.5185199677944183e-01
    z[3,2,5]  R1056     2.6983284950256348e-01
    z[3,2,5]  R1057     4.1258224844932556e-01
    z[3,2,5]  R1058     -2.1482808515429497e-02
    z[3,2,5]  R1059     -1.9362571835517883e-01
    z[3,2,5]  R1060     9.8400317132472992e-02
    z[3,2,5]  R1061     2.6339009404182434e-01
    z[3,2,5]  R1062     3.6060410737991333e-01
    z[3,2,5]  R1063     -3.3307597041130066e-01
    z[3,2,5]  R1064     9.8236635327339172e-02
    z[3,2,5]  R1065     2.1155847609043121e-01
    z[3,2,5]  R1066     3.4791359305381775e-01
    z[3,2,5]  R1067     3.7651412189006805e-02
    z[3,2,5]  R1068     -3.4793993830680847e-01
    z[3,2,5]  R1069     -1.0101927816867828e-01
    z[3,2,5]  R1070     1.5086345374584198e-01
    z[3,2,5]  R1071     1.3020054996013641e-01
    z[3,2,5]  R1072     -3.7766936421394348e-01
    z[3,2,5]  R1073     7.4742093682289124e-02
    z[3,2,5]  R1074     1.0752414911985397e-01
    z[3,2,5]  R1075     -2.2847658395767212e-01
    z[3,2,5]  R1076     2.9388007521629333e-01
    z[3,2,5]  R1077     2.6284396648406982e-01
    z[3,2,5]  R1078     1.8035946786403656e-01
    z[3,2,5]  R1079     -2.6458916068077087e-01
    z[3,2,5]  R1080     -1.8782602250576019e-01
    z[3,2,5]  R1081     7.1179017424583435e-02
    z[3,2,5]  R1082     1.4700101315975189e-01
    z[3,2,5]  R1083     4.8983491957187653e-02
    z[3,2,5]  R1084     -4.3268904089927673e-01
    z[3,2,5]  R1085     4.4912725687026978e-02
    z[3,2,5]  R1086     3.6912506818771362e-01
    z[3,2,5]  R1087     -1.0355526208877563e-01
    z[3,2,5]  R1088     -2.3538687825202942e-01
    z[3,2,5]  R1089     2.3491522669792175e-01
    z[3,2,5]  R1090     -9.9665679037570953e-02
    z[3,2,5]  R1091     8.0978050827980042e-02
    z[3,2,5]  R1092     4.3259942531585693e-01
    z[3,2,5]  R1093     6.2491351366043091e-01
    z[3,2,5]  R1094     -1.2104964256286621e-01
    z[3,2,5]  R1095     -1.2605790980160236e-02
    z[3,2,5]  R1096     1.3747389614582062e-01
    z[3,2,5]  R1097     2.0527207851409912e-01
    z[3,2,5]  R1098     3.8007053732872009e-01
    z[3,2,5]  R1099     3.0109593272209167e-01
    z[3,2,5]  R1100     -3.2173928618431091e-01
    z[3,2,5]  R1101     2.9975953698158264e-01
    z[3,2,5]  R1102     3.4868037700653076e-01
    z[3,2,5]  R1103     2.1847660839557648e-01
    z[3,2,5]  R1104     -1.3078860938549042e-01
    z[3,2,5]  R1105     -4.5007985830307007e-01
    z[3,2,5]  R1106     -1.0398718714714050e-01
    z[3,2,5]  R1107     -1.8376775085926056e-01
    z[3,2,5]  R1108     -0.0701352059841156
    z[3,2,5]  R1109     -2.6097044348716736e-01
    z[3,2,5]  R1110     -2.7366024255752563e-01
    z[3,2,5]  R1111     -0.0517178550362587
    z[3,2,5]  R1112     -0.257789671421051
    z[3,2,5]  R1113     1.8757749348878860e-02
    z[3,2,5]  R1114     -2.3568439483642578e-01
    z[3,2,5]  R1115     -4.6486797928810120e-01
    z[3,2,5]  R1116     8.8016845285892487e-02
    z[3,2,5]  R1117     -2.8265652060508728e-01
    z[3,2,5]  R1118     -1.3760939240455627e-02
    z[3,2,5]  R1119     3.7209907174110413e-01
    z[3,2,5]  R1120     1.3777013123035431e-01
    z[3,2,5]  R1121     -7.4434436857700348e-02
    z[3,2,5]  R1122     2.9123359918594360e-01
    z[3,2,6]  R26       1
    z[3,2,6]  R35       -1
    z[3,2,6]  R1002     -1
    z[3,2,6]  R1003     1
    z[3,2,6]  R1004     2.3448066413402557e-01
    z[3,2,6]  R1005     2.1293486654758453e-01
    z[3,2,6]  R1006     4.0058061480522156e-01
    z[3,2,6]  R1007     4.3068426847457886e-01
    z[3,2,6]  R1008     0.484515517950058
    z[3,2,6]  R1009     -1.4090597629547119e-01
    z[3,2,6]  R1010     -1.5417706966400146e-01
    z[3,2,6]  R1011     1.3927669823169708e-01
    z[3,2,6]  R1012     -1.7149336636066437e-01
    z[3,2,6]  R1013     1.0915964841842651e-01
    z[3,2,6]  R1014     -2.4677093327045441e-01
    z[3,2,6]  R1015     1.9186499714851379e-01
    z[3,2,6]  R1016     -3.8098847866058350e-01
    z[3,2,6]  R1017     -5.7603371143341064e-01
    z[3,2,6]  R1018     -6.2416213750839233e-01
    z[3,2,6]  R1019     -1.0772877931594849e-01
    z[3,2,6]  R1020     -6.9624620676040649e-01
    z[3,2,6]  R1021     -8.2980375736951828e-03
    z[3,2,6]  R1022     -4.0678212046623230e-01
    z[3,2,6]  R1023     -6.9660849869251251e-02
    z[3,2,6]  R1024     0.0590716190636158
    z[3,2,6]  R1025     -8.8420487940311432e-02
    z[3,2,6]  R1026     3.7266305088996887e-01
    z[3,2,6]  R1027     1.9456608593463898e-01
    z[3,2,6]  R1028     -2.7480429410934448e-01
    z[3,2,6]  R1029     3.1899476051330566e-01
    z[3,2,6]  R1030     5.9696954488754272e-01
    z[3,2,6]  R1031     7.8890842199325562e-01
    z[3,2,6]  R1032     0.251801997423172
    z[3,2,6]  R1033     -2.5877025723457336e-01
    z[3,2,6]  R1034     4.9064162373542786e-01
    z[3,2,6]  R1035     5.5366568267345428e-02
    z[3,2,6]  R1036     2.2685837745666504e-01
    z[3,2,6]  R1037     2.8735220432281494e-01
    z[3,2,6]  R1038     -3.4319585561752319e-01
    z[3,2,6]  R1039     -5.3683228790760040e-02
    z[3,2,6]  R1040     -0.34941366314888
    z[3,2,6]  R1041     4.4143715500831604e-01
    z[3,2,6]  R1042     -1.0558591037988663e-01
    z[3,2,6]  R1043     -0.243662029504776
    z[3,2,6]  R1044     -7.3637999594211578e-02
    z[3,2,6]  R1045     -1.6427341103553772e-01
    z[3,2,6]  R1046     2.0980919897556305e-01
    z[3,2,6]  R1047     1.6063556075096130e-01
    z[3,2,6]  R1048     -5.0175631046295166e-01
    z[3,2,6]  R1049     -6.1454075574874878e-01
    z[3,2,6]  R1050     -2.1731488406658173e-01
    z[3,2,6]  R1051     7.3154765367507935e-01
    z[3,2,6]  R1052     1.5326510369777679e-01
    z[3,2,6]  R1053     5.3874832391738892e-01
    z[3,2,6]  R1054     -3.0045926570892334e-01
    z[3,2,6]  R1055     0.0719318613409996
    z[3,2,6]  R1056     1.3921739161014557e-01
    z[3,2,6]  R1057     -0.278016060590744
    z[3,2,6]  R1058     -5.1049643754959106e-01
    z[3,2,6]  R1059     -0.24481201171875
    z[3,2,6]  R1060     3.0772894620895386e-01
    z[3,2,6]  R1061     6.3795872032642365e-02
    z[3,2,6]  R1062     -1.2187448143959045e-01
    z[3,2,6]  R1063     -2.1238806843757629e-01
    z[3,2,6]  R1064     2.7810081839561462e-01
    z[3,2,6]  R1065     -2.4018239974975586e-01
    z[3,2,6]  R1066     -1.2080726772546768e-01
    z[3,2,6]  R1067     6.9574706256389618e-02
    z[3,2,6]  R1068     -4.0678188204765320e-01
    z[3,2,6]  R1069     1.1225664988160133e-02
    z[3,2,6]  R1070     6.7537270486354828e-02
    z[3,2,6]  R1071     -2.0034988224506378e-01
    z[3,2,6]  R1072     1.8935823440551758e-01
    z[3,2,6]  R1073     1.5311431884765625e-01
    z[3,2,6]  R1074     1.5120458602905273e-01
    z[3,2,6]  R1075     2.5487518310546875e-01
    z[3,2,6]  R1076     4.2553195357322693e-01
    z[3,2,6]  R1077     -2.9079419374465942e-01
    z[3,2,6]  R1078     -2.0165875554084778e-01
    z[3,2,6]  R1079     7.7225565910339355e-02
    z[3,2,6]  R1080     -2.1157729625701904e-01
    z[3,2,6]  R1081     -6.6531932353973389e-01
    z[3,2,6]  R1082     7.1661704778671265e-01
    z[3,2,6]  R1083     -3.7990954518318176e-01
    z[3,2,6]  R1084     -0.0680527314543724
    z[3,2,6]  R1085     4.9775806069374084e-01
    z[3,2,6]  R1086     3.8639616966247559e-01
    z[3,2,6]  R1087     1.8866670131683350e-01
    z[3,2,6]  R1088     2.4863265454769135e-01
    z[3,2,6]  R1089     -0.175812765955925
    z[3,2,6]  R1090     1.7377892136573792e-01
    z[3,2,6]  R1091     4.2417564988136292e-01
    z[3,2,6]  R1092     1.2433759123086929e-01
    z[3,2,6]  R1093     1.7381101846694946e-01
    z[3,2,6]  R1094     -1.6165116429328918e-01
    z[3,2,6]  R1095     5.0855990499258041e-02
    z[3,2,6]  R1096     -1.2389753758907318e-01
    z[3,2,6]  R1097     -1.3846738636493683e-01
    z[3,2,6]  R1098     1.7432193458080292e-01
    z[3,2,6]  R1099     -2.1570816636085510e-01
    z[3,2,6]  R1100     8.8239498436450958e-03
    z[3,2,6]  R1101     -1.3048341870307922e-01
    z[3,2,6]  R1102     7.9777045175433159e-03
    z[3,2,6]  R1103     7.3663994669914246e-02
    z[3,2,6]  R1104     7.0254206657409668e-01
    z[3,2,6]  R1105     -3.7165313959121704e-01
    z[3,2,6]  R1106     2.5277087092399597e-01
    z[3,2,6]  R1107     2.8222542256116867e-02
    z[3,2,6]  R1108     -1.1257118545472622e-02
    z[3,2,6]  R1109     1.7796604335308075e-01
    z[3,2,6]  R1110     -7.2849661111831665e-02
    z[3,2,6]  R1111     9.3854013830423355e-03
    z[3,2,6]  R1112     -3.1947249174118042e-01
    z[3,2,6]  R1113     -0.0979093536734581
    z[3,2,6]  R1114     2.2815231233835220e-02
    z[3,2,6]  R1115     3.8587224483489990e-01
    z[3,2,6]  R1116     -8.4345191717147827e-02
    z[3,2,6]  R1117     -1.2673306465148926e-01
    z[3,2,6]  R1118     7.6837375760078430e-02
    z[3,2,6]  R1119     -5.8577362447977066e-02
    z[3,2,6]  R1120     -2.1849749982357025e-01
    z[3,2,6]  R1121     -3.4982562065124512e-01
    z[3,2,6]  R1122     9.2579156160354614e-02
    z[2,10,0]  R20       -1
    z[2,10,0]  R92       1
    z[2,10,0]  R1123     -1
    z[2,10,0]  R1124     1
    z[2,10,0]  R1137     1.7375077307224274e-01
    z[2,10,0]  R1138     1.0416479408740997e-01
    z[2,10,0]  R1139     3.5076405853033066e-02
    z[2,10,0]  R1140     1.1815072596073151e-01
    z[2,10,0]  R1141     1.3126258552074432e-01
    z[2,10,0]  R1142     4.0457978844642639e-02
    z[2,10,0]  R1143     -3.9107404649257660e-02
    z[2,10,0]  R1144     -7.3462487198412418e-03
    z[2,10,0]  R1145     -2.0507071912288666e-01
    z[2,10,0]  R1146     5.1161199808120728e-02
    z[2,10,0]  R1147     -5.0340861082077026e-02
    z[2,10,0]  R1148     1.0358274728059769e-01
    z[2,10,0]  R1149     -1.6905583441257477e-02
    z[2,10,0]  R1150     1.8200548365712166e-02
    z[2,10,0]  R1151     -1.5195293724536896e-01
    z[2,10,0]  R1152     -1.0875476151704788e-01
    z[2,10,0]  R1153     -1.0530030727386475e-01
    z[2,10,0]  R1154     -1.1921381205320358e-01
    z[2,10,0]  R1155     -9.4531789422035217e-02
    z[2,10,0]  R1156     -9.7032509744167328e-02
    z[2,10,0]  R1157     -1.1137016862630844e-01
    z[2,10,0]  R1158     -1.5104120969772339e-01
    z[2,10,0]  R1159     -8.7838634848594666e-02
    z[2,10,0]  R1160     -9.9680311977863312e-02
    z[2,10,0]  R1161     -1.4754776656627655e-01
    z[2,10,0]  R1162     -6.5765053033828735e-02
    z[2,10,0]  R1163     -1.2139682471752167e-01
    z[2,10,0]  R1164     2.1158248186111450e-02
    z[2,10,0]  R1165     -1.4087593555450439e-01
    z[2,10,0]  R1166     9.5251291990280151e-02
    z[2,10,0]  R1167     -0.0731421485543251
    z[2,10,0]  R1168     -1.8635485321283340e-02
    z[2,10,0]  R1169     -1.7498539388179779e-01
    z[2,10,0]  R1170     -1.8789456784725189e-01
    z[2,10,0]  R1171     -2.5243632495403290e-02
    z[2,10,0]  R1172     -5.5284440517425537e-02
    z[2,10,0]  R1173     -6.9861665368080139e-02
    z[2,10,0]  R1174     8.2318651676177979e-01
    z[2,10,0]  R1175     -5.5996431037783623e-03
    z[2,10,0]  R1176     -8.5662461817264557e-02
    z[2,10,0]  R1177     -3.8488205522298813e-02
    z[2,10,0]  R1178     -9.2685915529727936e-02
    z[2,10,0]  R1179     -1.4319211244583130e-01
    z[2,10,0]  R1180     -1.0172440856695175e-01
    z[2,10,0]  R1181     -8.5732407867908478e-02
    z[2,10,0]  R1182     6.5032929182052612e-01
    z[2,10,0]  R1183     6.3057667016983032e-01
    z[2,10,0]  R1184     6.4594465494155884e-01
    z[2,10,0]  R1185     7.2314405441284180e-01
    z[2,10,0]  R1186     -0.0322338342666626
    z[2,10,0]  R1187     -3.8929153233766556e-02
    z[2,10,0]  R1188     -2.8456223011016846e-01
    z[2,10,0]  R1189     -9.5431968569755554e-02
    z[2,10,0]  R1190     4.8519930243492126e-01
    z[2,10,0]  R1191     2.9040375351905823e-01
    z[2,10,0]  R1192     6.2423527240753174e-01
    z[2,10,0]  R1193     0.68561190366745
    z[2,10,0]  R1194     3.9377138018608093e-01
    z[2,10,0]  R1195     4.7939980030059814e-01
    z[2,10,0]  R1196     -1.3835345208644867e-01
    z[2,10,0]  R1197     -2.6231449842453003e-01
    z[2,10,0]  R1198     -8.1875901669263840e-03
    z[2,10,0]  R1199     -7.8163832426071167e-01
    z[2,10,0]  R1200     -4.8524963855743408e-01
    z[2,10,0]  R1201     7.1659278869628906e-01
    z[2,10,0]  R1202     4.5273523777723312e-02
    z[2,10,0]  R1203     -4.5310713350772858e-02
    z[2,10,0]  R1204     6.3448154926300049e-01
    z[2,10,0]  R1205     3.3574381470680237e-01
    z[2,10,0]  R1206     -7.6139461994171143e-01
    z[2,10,0]  R1207     -7.8718638420104980e-01
    z[2,10,0]  R1208     -5.9369087219238281e-01
    z[2,10,0]  R1209     -5.3711426258087158e-01
    z[2,10,0]  R1210     1.0929322987794876e-01
    z[2,10,0]  R1211     2.8275832533836365e-01
    z[2,10,0]  R1212     7.5258262455463409e-02
    z[2,10,0]  R1213     5.1826828718185425e-01
    z[2,10,0]  R1214     8.6387908458709717e-01
    z[2,10,0]  R1215     2.2995744645595551e-01
    z[2,10,0]  R1216     -4.4182431697845459e-01
    z[2,10,0]  R1217     -4.4682115316390991e-01
    z[2,10,0]  R1218     -2.6626887917518616e-01
    z[2,10,0]  R1219     -2.6983499526977539e-01
    z[2,10,0]  R1220     -2.8977537155151367e-01
    z[2,10,0]  R1221     1.8678304553031921e-01
    z[2,10,0]  R1222     1.8696199357509613e-01
    z[2,10,0]  R1223     3.3619109541177750e-02
    z[2,10,0]  R1224     5.5952310562133789e-01
    z[2,10,0]  R1225     9.2262578010559082e-01
    z[2,10,1]  R21       -1
    z[2,10,1]  R93       1
    z[2,10,1]  R1125     -1
    z[2,10,1]  R1126     1
    z[2,10,1]  R1137     -0.188704252243042
    z[2,10,1]  R1138     -2.4665230512619019e-01
    z[2,10,1]  R1139     -7.5864009559154510e-02
    z[2,10,1]  R1140     -1.4523386955261230e-01
    z[2,10,1]  R1141     3.9027415215969086e-02
    z[2,10,1]  R1142     3.2125559449195862e-01
    z[2,10,1]  R1143     -8.7640094757080078e-01
    z[2,10,1]  R1144     2.4323654174804688e-01
    z[2,10,1]  R1145     -7.8582540154457092e-02
    z[2,10,1]  R1146     9.0698373317718506e-01
    z[2,10,1]  R1147     7.7767539024353027e-01
    z[2,10,1]  R1148     7.6909792423248291e-01
    z[2,10,1]  R1149     7.4120289087295532e-01
    z[2,10,1]  R1150     0.731759786605835
    z[2,10,1]  R1151     6.7997241020202637e-01
    z[2,10,1]  R1152     6.6865491867065430e-01
    z[2,10,1]  R1153     0.649121105670929
    z[2,10,1]  R1154     0.642539918422699
    z[2,10,1]  R1155     6.3295543193817139e-01
    z[2,10,1]  R1156     5.9669071435928345e-01
    z[2,10,1]  R1157     -1.3306954503059387e-01
    z[2,10,1]  R1158     -5.5064046382904053e-01
    z[2,10,1]  R1159     -0.590140163898468
    z[2,10,1]  R1160     -4.8204281926155090e-01
    z[2,10,1]  R1161     -3.4903496503829956e-01
    z[2,10,1]  R1162     -2.7629068493843079e-01
    z[2,10,1]  R1163     -4.7363707423210144e-01
    z[2,10,1]  R1164     -9.0629106760025024e-01
    z[2,10,1]  R1165     -5.0873714685440063e-01
    z[2,10,1]  R1166     8.0913090705871582e-01
    z[2,10,1]  R1167     6.0107976198196411e-01
    z[2,10,1]  R1168     5.5919289588928223e-01
    z[2,10,1]  R1169     -1.8453678488731384e-01
    z[2,10,1]  R1170     -2.1710814535617828e-01
    z[2,10,1]  R1171     -9.4162505865097046e-01
    z[2,10,1]  R1172     -9.0053504705429077e-01
    z[2,10,1]  R1173     -8.9092463254928589e-01
    z[2,10,1]  R1174     -5.0908583402633667e-01
    z[2,10,1]  R1175     -8.8902920484542847e-01
    z[2,10,1]  R1176     8.2013344764709473e-01
    z[2,10,1]  R1177     6.7155414819717407e-01
    z[2,10,1]  R1178     4.3844765424728394e-01
    z[2,10,1]  R1179     -9.7919665277004242e-02
    z[2,10,1]  R1180     -5.9339928627014160e-01
    z[2,10,1]  R1181     -8.5561513900756836e-01
    z[2,10,1]  R1182     -5.1422142982482910e-01
    z[2,10,1]  R1183     -5.1929527521133423e-01
    z[2,10,1]  R1184     -0.442984014749527
    z[2,10,1]  R1185     -2.8734889626502991e-01
    z[2,10,1]  R1186     5.9495024383068085e-02
    z[2,10,1]  R1187     -1.7787255346775055e-01
    z[2,10,1]  R1188     -3.7116494774818420e-01
    z[2,10,1]  R1189     2.7456842362880707e-02
    z[2,10,1]  R1190     5.0318706035614014e-01
    z[2,10,1]  R1191     2.7592509984970093e-01
    z[2,10,1]  R1192     1.3301257789134979e-01
    z[2,10,1]  R1193     1.5204125642776489e-01
    z[2,10,1]  R1194     4.5381143689155579e-01
    z[2,10,1]  R1195     3.1715300679206848e-01
    z[2,10,1]  R1196     -5.4111443459987640e-02
    z[2,10,1]  R1197     -3.6944654583930969e-01
    z[2,10,1]  R1198     8.8989585638046265e-01
    z[2,10,1]  R1199     -1.0060093551874161e-01
    z[2,10,1]  R1200     4.9054840207099915e-01
    z[2,10,1]  R1201     -3.6201146245002747e-01
    z[2,10,1]  R1202     3.4500020742416382e-01
    z[2,10,1]  R1203     7.2072863578796387e-01
    z[2,10,1]  R1204     4.4959199428558350e-01
    z[2,10,1]  R1205     5.7441401481628418e-01
    z[2,10,1]  R1206     -1.9486187398433685e-01
    z[2,10,1]  R1207     2.4525374174118042e-01
    z[2,10,1]  R1208     5.0622463226318359e-01
    z[2,10,1]  R1209     -5.3992480039596558e-01
    z[2,10,1]  R1210     4.0347132086753845e-01
    z[2,10,1]  R1211     3.0033415555953979e-01
    z[2,10,1]  R1212     4.7502881288528442e-01
    z[2,10,1]  R1213     5.4198604822158813e-01
    z[2,10,1]  R1214     9.3117982149124146e-02
    z[2,10,1]  R1215     5.5350724607706070e-02
    z[2,10,1]  R1216     -6.3070565462112427e-01
    z[2,10,1]  R1217     0.666795015335083
    z[2,10,1]  R1218     2.4894419312477112e-01
    z[2,10,1]  R1219     5.1834475994110107e-01
    z[2,10,1]  R1220     0.744705855846405
    z[2,10,1]  R1221     0.777864396572113
    z[2,10,1]  R1222     4.4287830591201782e-01
    z[2,10,1]  R1223     3.9503553509712219e-01
    z[2,10,1]  R1224     4.4211441278457642e-01
    z[2,10,1]  R1225     -4.0771577507257462e-02
    z[2,10,2]  R22       -1
    z[2,10,2]  R94       1
    z[2,10,2]  R1127     -1
    z[2,10,2]  R1128     1
    z[2,10,2]  R1137     -4.4951781630516052e-01
    z[2,10,2]  R1138     -5.7896214723587036e-01
    z[2,10,2]  R1139     -7.5325781106948853e-01
    z[2,10,2]  R1140     -6.0198068618774414e-01
    z[2,10,2]  R1141     2.7803765609860420e-02
    z[2,10,2]  R1142     4.9266871809959412e-01
    z[2,10,2]  R1143     1.9959209859371185e-01
    z[2,10,2]  R1144     6.3347554206848145e-01
    z[2,10,2]  R1145     3.4610655903816223e-01
    z[2,10,2]  R1146     -9.4338893890380859e-02
    z[2,10,2]  R1147     -2.8370854258537292e-01
    z[2,10,2]  R1148     1.4953862130641937e-01
    z[2,10,2]  R1149     2.9757255315780640e-01
    z[2,10,2]  R1150     5.3267461061477661e-01
    z[2,10,2]  R1151     4.1305556893348694e-01
    z[2,10,2]  R1152     1.0275747627019882e-01
    z[2,10,2]  R1153     2.9723986983299255e-01
    z[2,10,2]  R1154     2.5612899661064148e-01
    z[2,10,2]  R1155     1.3214507699012756e-01
    z[2,10,2]  R1156     8.6175657808780670e-02
    z[2,10,2]  R1157     4.3202412128448486e-01
    z[2,10,2]  R1158     4.8419484496116638e-01
    z[2,10,2]  R1159     3.3047696948051453e-01
    z[2,10,2]  R1160     5.3097373247146606e-01
    z[2,10,2]  R1161     4.6801841259002686e-01
    z[2,10,2]  R1162     2.5067463517189026e-01
    z[2,10,2]  R1163     3.1835344433784485e-01
    z[2,10,2]  R1164     2.5098061561584473e-01
    z[2,10,2]  R1165     1.9846871495246887e-01
    z[2,10,2]  R1166     2.8659293428063393e-02
    z[2,10,2]  R1167     -2.0808011293411255e-01
    z[2,10,2]  R1168     5.2410387992858887e-01
    z[2,10,2]  R1169     0.0869893953204155
    z[2,10,2]  R1170     4.6075470745563507e-02
    z[2,10,2]  R1171     -9.9441379308700562e-02
    z[2,10,2]  R1172     2.8549528121948242e-01
    z[2,10,2]  R1173     1.1278945207595825e-01
    z[2,10,2]  R1174     4.9462612718343735e-02
    z[2,10,2]  R1175     -1.4428270515054464e-03
    z[2,10,2]  R1176     1.0920712351799011e-01
    z[2,10,2]  R1177     2.8010737895965576e-01
    z[2,10,2]  R1178     2.0575119182467461e-02
    z[2,10,2]  R1179     -0.0702795684337616
    z[2,10,2]  R1180     -0.0913701057434082
    z[2,10,2]  R1181     2.1251454949378967e-01
    z[2,10,2]  R1182     2.9008436203002930e-01
    z[2,10,2]  R1183     3.0944174528121948e-01
    z[2,10,2]  R1184     4.6052265167236328e-01
    z[2,10,2]  R1185     -8.3492629230022430e-02
    z[2,10,2]  R1186     -0.724852442741394
    z[2,10,2]  R1187     -0.00740482984110713
    z[2,10,2]  R1188     -4.8283287882804871e-01
    z[2,10,2]  R1189     2.7693548798561096e-01
    z[2,10,2]  R1190     -3.0036973953247070e-01
    z[2,10,2]  R1191     -5.8482116460800171e-01
    z[2,10,2]  R1192     -4.4869095087051392e-01
    z[2,10,2]  R1193     -3.9584168791770935e-01
    z[2,10,2]  R1194     -3.1886133551597595e-01
    z[2,10,2]  R1195     -6.8888276815414429e-02
    z[2,10,2]  R1196     1.9236966967582703e-01
    z[2,10,2]  R1197     -2.3499862849712372e-01
    z[2,10,2]  R1198     -1.2824200093746185e-01
    z[2,10,2]  R1199     4.8321297764778137e-01
    z[2,10,2]  R1200     -4.0007346868515015e-01
    z[2,10,2]  R1201     -3.2211970537900925e-02
    z[2,10,2]  R1202     -2.3078870773315430e-01
    z[2,10,2]  R1203     4.5992609858512878e-01
    z[2,10,2]  R1204     3.2394322752952576e-01
    z[2,10,2]  R1205     1.2365873157978058e-01
    z[2,10,2]  R1206     5.4677021503448486e-01
    z[2,10,2]  R1207     -0.00409313291311264
    z[2,10,2]  R1208     4.9141440540552139e-02
    z[2,10,2]  R1209     -2.1499194204807281e-01
    z[2,10,2]  R1210     -4.8322245478630066e-01
    z[2,10,2]  R1211     -4.3023490905761719e-01
    z[2,10,2]  R1212     -3.2550308108329773e-01
    z[2,10,2]  R1213     -1.5176175534725189e-01
    z[2,10,2]  R1214     5.5523775517940521e-02
    z[2,10,2]  R1215     -5.1858407258987427e-01
    z[2,10,2]  R1216     4.1414242982864380e-01
    z[2,10,2]  R1217     -1.7898446321487427e-01
    z[2,10,2]  R1218     4.4153865426778793e-02
    z[2,10,2]  R1219     4.3548453599214554e-02
    z[2,10,2]  R1220     2.8381463885307312e-01
    z[2,10,2]  R1221     -3.0663815140724182e-01
    z[2,10,2]  R1222     -5.5600476264953613e-01
    z[2,10,2]  R1223     -6.0695797204971313e-01
    z[2,10,2]  R1224     -4.2058983445167542e-01
    z[2,10,2]  R1225     -1.8685944378376007e-02
    z[2,10,3]  R23       -1
    z[2,10,3]  R95       1
    z[2,10,3]  R1129     -1
    z[2,10,3]  R1130     1
    z[2,10,3]  R1137     -7.4526280164718628e-01
    z[2,10,3]  R1138     -6.8571335077285767e-01
    z[2,10,3]  R1139     -3.4381410479545593e-01
    z[2,10,3]  R1140     -4.9803760647773743e-01
    z[2,10,3]  R1141     -8.3985865116119385e-01
    z[2,10,3]  R1142     -0.0569143183529377
    z[2,10,3]  R1143     1.1172537505626678e-01
    z[2,10,3]  R1144     2.8988546133041382e-01
    z[2,10,3]  R1145     3.5846811532974243e-01
    z[2,10,3]  R1146     7.7495403587818146e-02
    z[2,10,3]  R1147     1.9534422457218170e-01
    z[2,10,3]  R1148     2.9060753062367439e-02
    z[2,10,3]  R1149     -5.9179320931434631e-02
    z[2,10,3]  R1150     -3.4050792455673218e-01
    z[2,10,3]  R1151     3.6460673809051514e-01
    z[2,10,3]  R1152     5.4198390245437622e-01
    z[2,10,3]  R1153     0.00823516957461834
    z[2,10,3]  R1154     4.8303452134132385e-01
    z[2,10,3]  R1155     1.5749073028564453e-01
    z[2,10,3]  R1156     4.3526706099510193e-01
    z[2,10,3]  R1157     7.9342108964920044e-01
    z[2,10,3]  R1158     6.5937399864196777e-01
    z[2,10,3]  R1159     6.5896546840667725e-01
    z[2,10,3]  R1160     6.2674939632415771e-01
    z[2,10,3]  R1161     6.7736089229583740e-01
    z[2,10,3]  R1162     7.3747175931930542e-01
    z[2,10,3]  R1163     6.9485068321228027e-01
    z[2,10,3]  R1164     -5.8983918279409409e-03
    z[2,10,3]  R1165     7.4100762605667114e-01
    z[2,10,3]  R1166     -5.2359545230865479e-01
    z[2,10,3]  R1167     1.0568166524171829e-01
    z[2,10,3]  R1168     -4.7711357474327087e-03
    z[2,10,3]  R1169     0.899384617805481
    z[2,10,3]  R1170     9.2336362600326538e-01
    z[2,10,3]  R1171     2.6426756381988525e-01
    z[2,10,3]  R1172     6.7940421402454376e-02
    z[2,10,3]  R1173     2.9856231808662415e-01
    z[2,10,3]  R1174     2.1147172152996063e-01
    z[2,10,3]  R1175     1.3571204245090485e-01
    z[2,10,3]  R1176     2.6888519525527954e-01
    z[2,10,3]  R1177     3.7405043840408325e-01
    z[2,10,3]  R1178     -1.7554442584514618e-01
    z[2,10,3]  R1179     9.7027087211608887e-01
    z[2,10,3]  R1180     7.2116440534591675e-01
    z[2,10,3]  R1181     1.2738877534866333e-01
    z[2,10,3]  R1182     0.232284277677536
    z[2,10,3]  R1183     1.7936527729034424e-01
    z[2,10,3]  R1184     5.1085177809000015e-02
    z[2,10,3]  R1185     3.9830267429351807e-01
    z[2,10,3]  R1186     -0.585458517074585
    z[2,10,3]  R1187     -5.2857035398483276e-01
    z[2,10,3]  R1188     -4.2818996310234070e-01
    z[2,10,3]  R1189     -8.7082099914550781e-01
    z[2,10,3]  R1190     2.9156097769737244e-01
    z[2,10,3]  R1191     4.1652080416679382e-01
    z[2,10,3]  R1192     1.2389941513538361e-01
    z[2,10,3]  R1193     2.0483785867691040e-01
    z[2,10,3]  R1194     5.9187458828091621e-03
    z[2,10,3]  R1195     1.0321240127086639e-01
    z[2,10,3]  R1196     5.7243430055677891e-03
    z[2,10,3]  R1197     5.3754359483718872e-01
    z[2,10,3]  R1198     1.8291927874088287e-01
    z[2,10,3]  R1199     2.3596415296196938e-02
    z[2,10,3]  R1200     4.3839433789253235e-01
    z[2,10,3]  R1201     -2.7212709188461304e-01
    z[2,10,3]  R1202     5.7946640253067017e-01
    z[2,10,3]  R1203     -0.231314554810524
    z[2,10,3]  R1204     -4.0604448318481445e-01
    z[2,10,3]  R1205     -2.2802665829658508e-01
    z[2,10,3]  R1206     1.3147830963134766e-01
    z[2,10,3]  R1207     2.5725081562995911e-01
    z[2,10,3]  R1208     5.6381557136774063e-02
    z[2,10,3]  R1209     3.9758530259132385e-01
    z[2,10,3]  R1210     7.1642249822616577e-01
    z[2,10,3]  R1211     6.4207404851913452e-01
    z[2,10,3]  R1212     4.8567295074462891e-01
    z[2,10,3]  R1213     6.1398875713348389e-01
    z[2,10,3]  R1214     1.0109191387891769e-01
    z[2,10,3]  R1215     0.778455913066864
    z[2,10,3]  R1216     -3.1388387084007263e-01
    z[2,10,3]  R1217     9.2800423502922058e-02
    z[2,10,3]  R1218     1.0242816060781479e-01
    z[2,10,3]  R1219     -1.6660006344318390e-01
    z[2,10,3]  R1220     -3.7849491834640503e-01
    z[2,10,3]  R1221     2.5698107481002808e-01
    z[2,10,3]  R1222     4.8226529359817505e-01
    z[2,10,3]  R1223     0.67186039686203
    z[2,10,3]  R1224     5.2164858579635620e-01
    z[2,10,3]  R1225     -1.0438710451126099e-01
    z[2,10,4]  R24       -1
    z[2,10,4]  R96       1
    z[2,10,4]  R1131     -1
    z[2,10,4]  R1132     1
    z[2,10,4]  R1137     -3.7721905112266541e-01
    z[2,10,4]  R1138     7.5825735926628113e-02
    z[2,10,4]  R1139     1.9991464912891388e-01
    z[2,10,4]  R1140     4.4819310307502747e-01
    z[2,10,4]  R1141     4.4935014843940735e-01
    z[2,10,4]  R1142     -7.5711631774902344e-01
    z[2,10,4]  R1143     3.1309577822685242e-01
    z[2,10,4]  R1144     8.7982267141342163e-02
    z[2,10,4]  R1145     4.1028323769569397e-01
    z[2,10,4]  R1146     -1.1457324773073196e-01
    z[2,10,4]  R1147     2.8668063879013062e-01
    z[2,10,4]  R1148     3.5323154926300049e-01
    z[2,10,4]  R1149     -2.6967665553092957e-01
    z[2,10,4]  R1150     -1.3486875593662262e-01
    z[2,10,4]  R1151     3.0621844530105591e-01
    z[2,10,4]  R1152     3.8816508650779724e-01
    z[2,10,4]  R1153     6.6257226467132568e-01
    z[2,10,4]  R1154     -2.9584395885467529e-01
    z[2,10,4]  R1155     5.8784645795822144e-01
    z[2,10,4]  R1156     1.3013081252574921e-01
    z[2,10,4]  R1157     -3.3607015013694763e-01
    z[2,10,4]  R1158     4.4919040054082870e-02
    z[2,10,4]  R1159     -2.5752422213554382e-01
    z[2,10,4]  R1160     -1.4710766077041626e-01
    z[2,10,4]  R1161     -6.0857083648443222e-02
    z[2,10,4]  R1162     -4.1886419057846069e-01
    z[2,10,4]  R1163     -2.7050018310546875e-01
    z[2,10,4]  R1164     -0.0910007506608963
    z[2,10,4]  R1165     1.0590924322605133e-01
    z[2,10,4]  R1166     -9.0013951063156128e-02
    z[2,10,4]  R1167     -2.6118251681327820e-01
    z[2,10,4]  R1168     0.267488956451416
    z[2,10,4]  R1169     -2.1014265716075897e-01
    z[2,10,4]  R1170     1.6813451051712036e-01
    z[2,10,4]  R1171     -1.6713267564773560e-01
    z[2,10,4]  R1172     -0.00890843104571104
    z[2,10,4]  R1173     1.3897763192653656e-01
    z[2,10,4]  R1174     1.1517754197120667e-01
    z[2,10,4]  R1175     1.5052539110183716e-01
    z[2,10,4]  R1176     4.7526782751083374e-01
    z[2,10,4]  R1177     -5.2258223295211792e-01
    z[2,10,4]  R1178     6.3477098941802979e-01
    z[2,10,4]  R1179     -9.3176737427711487e-02
    z[2,10,4]  R1180     -1.1465954780578613e-01
    z[2,10,4]  R1181     4.3941894173622131e-01
    z[2,10,4]  R1182     -1.8070462346076965e-01
    z[2,10,4]  R1183     -3.7156096100807190e-01
    z[2,10,4]  R1184     -2.0955021679401398e-01
    z[2,10,4]  R1185     -3.6808863282203674e-01
    z[2,10,4]  R1186     -1.6976216435432434e-01
    z[2,10,4]  R1187     -4.0392079949378967e-01
    z[2,10,4]  R1188     0.598517656326294
    z[2,10,4]  R1189     1.3599993288516998e-01
    z[2,10,4]  R1190     4.9204263091087341e-01
    z[2,10,4]  R1191     1.4729213714599609e-01
    z[2,10,4]  R1192     6.0209494829177856e-01
    z[2,10,4]  R1193     4.2323696613311768e-01
    z[2,10,4]  R1194     4.7182390093803406e-01
    z[2,10,4]  R1195     -3.3233314752578735e-01
    z[2,10,4]  R1196     -5.8718425035476685e-01
    z[2,10,4]  R1197     -1.7536464333534241e-01
    z[2,10,4]  R1198     8.0129742622375488e-02
    z[2,10,4]  R1199     -2.6915794610977173e-01
    z[2,10,4]  R1200     1.4086230099201202e-01
    z[2,10,4]  R1201     3.5032492876052856e-01
    z[2,10,4]  R1202     -6.6820669174194336e-01
    z[2,10,4]  R1203     -4.1844749450683594e-01
    z[2,10,4]  R1204     -1.4110292494297028e-01
    z[2,10,4]  R1205     -4.7072374820709229e-01
    z[2,10,4]  R1206     1.8801175057888031e-01
    z[2,10,4]  R1207     1.6922098398208618e-01
    z[2,10,4]  R1208     -5.7497894763946533e-01
    z[2,10,4]  R1209     -4.0878134965896606e-01
    z[2,10,4]  R1210     -2.5134158134460449e-01
    z[2,10,4]  R1211     4.7637414932250977e-01
    z[2,10,4]  R1212     5.9170957654714584e-02
    z[2,10,4]  R1213     -1.1432316154241562e-01
    z[2,10,4]  R1214     3.2425925135612488e-01
    z[2,10,4]  R1215     -3.0830618925392628e-03
    z[2,10,4]  R1216     -3.5209706425666809e-01
    z[2,10,4]  R1217     -5.3375250101089478e-01
    z[2,10,4]  R1218     1.4306859672069550e-01
    z[2,10,4]  R1219     3.9614674448966980e-01
    z[2,10,4]  R1220     -8.5101991891860962e-02
    z[2,10,4]  R1221     4.0996676683425903e-01
    z[2,10,4]  R1222     3.1603109836578369e-01
    z[2,10,4]  R1223     7.8276596963405609e-02
    z[2,10,4]  R1224     -4.5020073652267456e-02
    z[2,10,4]  R1225     2.4737946689128876e-01
    z[2,10,5]  R25       -1
    z[2,10,5]  R97       1
    z[2,10,5]  R1133     -1
    z[2,10,5]  R1134     1
    z[2,10,5]  R1137     1.0752414911985397e-01
    z[2,10,5]  R1138     -2.2847658395767212e-01
    z[2,10,5]  R1139     2.9388007521629333e-01
    z[2,10,5]  R1140     2.6284396648406982e-01
    z[2,10,5]  R1141     1.8035946786403656e-01
    z[2,10,5]  R1142     -2.6458916068077087e-01
    z[2,10,5]  R1143     -1.8782602250576019e-01
    z[2,10,5]  R1144     7.1179017424583435e-02
    z[2,10,5]  R1145     1.4700101315975189e-01
    z[2,10,5]  R1146     4.8983491957187653e-02
    z[2,10,5]  R1147     -4.3268904089927673e-01
    z[2,10,5]  R1148     4.4912725687026978e-02
    z[2,10,5]  R1149     3.6912506818771362e-01
    z[2,10,5]  R1150     -1.0355526208877563e-01
    z[2,10,5]  R1151     -2.3538687825202942e-01
    z[2,10,5]  R1152     2.3491522669792175e-01
    z[2,10,5]  R1153     -9.9665679037570953e-02
    z[2,10,5]  R1154     8.0978050827980042e-02
    z[2,10,5]  R1155     4.3259942531585693e-01
    z[2,10,5]  R1156     6.2491351366043091e-01
    z[2,10,5]  R1157     -1.2104964256286621e-01
    z[2,10,5]  R1158     -1.2605790980160236e-02
    z[2,10,5]  R1159     1.3747389614582062e-01
    z[2,10,5]  R1160     2.0527207851409912e-01
    z[2,10,5]  R1161     3.8007053732872009e-01
    z[2,10,5]  R1162     3.0109593272209167e-01
    z[2,10,5]  R1163     -3.2173928618431091e-01
    z[2,10,5]  R1164     2.9975953698158264e-01
    z[2,10,5]  R1165     3.4868037700653076e-01
    z[2,10,5]  R1166     2.1847660839557648e-01
    z[2,10,5]  R1167     -1.3078860938549042e-01
    z[2,10,5]  R1168     -4.5007985830307007e-01
    z[2,10,5]  R1169     -1.0398718714714050e-01
    z[2,10,5]  R1170     -1.8376775085926056e-01
    z[2,10,5]  R1171     -0.0701352059841156
    z[2,10,5]  R1172     -2.6097044348716736e-01
    z[2,10,5]  R1173     -2.7366024255752563e-01
    z[2,10,5]  R1174     -0.0517178550362587
    z[2,10,5]  R1175     -0.257789671421051
    z[2,10,5]  R1176     1.8757749348878860e-02
    z[2,10,5]  R1177     -2.3568439483642578e-01
    z[2,10,5]  R1178     -4.6486797928810120e-01
    z[2,10,5]  R1179     8.8016845285892487e-02
    z[2,10,5]  R1180     -2.8265652060508728e-01
    z[2,10,5]  R1181     -1.3760939240455627e-02
    z[2,10,5]  R1182     3.7209907174110413e-01
    z[2,10,5]  R1183     1.3777013123035431e-01
    z[2,10,5]  R1184     -7.4434436857700348e-02
    z[2,10,5]  R1185     2.9123359918594360e-01
    z[2,10,5]  R1186     1.4835315942764282e-01
    z[2,10,5]  R1187     2.6637926697731018e-01
    z[2,10,5]  R1188     -2.7432022616267204e-02
    z[2,10,5]  R1189     3.6502219736576080e-02
    z[2,10,5]  R1190     -1.0321357101202011e-01
    z[2,10,5]  R1191     3.5617381334304810e-01
    z[2,10,5]  R1192     -7.1311786770820618e-02
    z[2,10,5]  R1193     2.9279375076293945e-01
    z[2,10,5]  R1194     -4.5880886912345886e-01
    z[2,10,5]  R1195     5.8623600006103516e-01
    z[2,10,5]  R1196     5.1523530483245850e-01
    z[2,10,5]  R1197     0.631995439529419
    z[2,10,5]  R1198     2.4163471162319183e-01
    z[2,10,5]  R1199     -0.213162362575531
    z[2,10,5]  R1200     -3.3033466339111328e-01
    z[2,10,5]  R1201     3.2594287395477295e-01
    z[2,10,5]  R1202     5.4186254739761353e-02
    z[2,10,5]  R1203     -1.5071900188922882e-01
    z[2,10,5]  R1204     -2.9552176594734192e-01
    z[2,10,5]  R1205     -4.7624596953392029e-01
    z[2,10,5]  R1206     -4.1224356740713120e-02
    z[2,10,5]  R1207     -1.0179454833269119e-01
    z[2,10,5]  R1208     -1.2646009027957916e-01
    z[2,10,5]  R1209     -2.1688570082187653e-01
    z[2,10,5]  R1210     1.2357288040220737e-02
    z[2,10,5]  R1211     -7.3192939162254333e-02
    z[2,10,5]  R1212     -3.3099305629730225e-01
    z[2,10,5]  R1213     1.2673702836036682e-01
    z[2,10,5]  R1214     -1.1368635110557079e-02
    z[2,10,5]  R1215     1.4075355231761932e-01
    z[2,10,5]  R1216     -8.0980204045772552e-02
    z[2,10,5]  R1217     -1.8685216084122658e-02
    z[2,10,5]  R1218     8.7871748208999634e-01
    z[2,10,5]  R1219     5.2634340524673462e-01
    z[2,10,5]  R1220     2.1733374893665314e-01
    z[2,10,5]  R1221     4.6922564506530762e-02
    z[2,10,5]  R1222     1.9103546440601349e-01
    z[2,10,5]  R1223     6.2783464789390564e-02
    z[2,10,5]  R1224     1.5240314602851868e-01
    z[2,10,5]  R1225     2.6976841688156128e-01
    z[2,10,6]  R26       -1
    z[2,10,6]  R98       1
    z[2,10,6]  R1135     -1
    z[2,10,6]  R1136     1
    z[2,10,6]  R1137     1.5120458602905273e-01
    z[2,10,6]  R1138     2.5487518310546875e-01
    z[2,10,6]  R1139     4.2553195357322693e-01
    z[2,10,6]  R1140     -2.9079419374465942e-01
    z[2,10,6]  R1141     -2.0165875554084778e-01
    z[2,10,6]  R1142     7.7225565910339355e-02
    z[2,10,6]  R1143     -2.1157729625701904e-01
    z[2,10,6]  R1144     -6.6531932353973389e-01
    z[2,10,6]  R1145     7.1661704778671265e-01
    z[2,10,6]  R1146     -3.7990954518318176e-01
    z[2,10,6]  R1147     -0.0680527314543724
    z[2,10,6]  R1148     4.9775806069374084e-01
    z[2,10,6]  R1149     3.8639616966247559e-01
    z[2,10,6]  R1150     1.8866670131683350e-01
    z[2,10,6]  R1151     2.4863265454769135e-01
    z[2,10,6]  R1152     -0.175812765955925
    z[2,10,6]  R1153     1.7377892136573792e-01
    z[2,10,6]  R1154     4.2417564988136292e-01
    z[2,10,6]  R1155     1.2433759123086929e-01
    z[2,10,6]  R1156     1.7381101846694946e-01
    z[2,10,6]  R1157     -1.6165116429328918e-01
    z[2,10,6]  R1158     5.0855990499258041e-02
    z[2,10,6]  R1159     -1.2389753758907318e-01
    z[2,10,6]  R1160     -1.3846738636493683e-01
    z[2,10,6]  R1161     1.7432193458080292e-01
    z[2,10,6]  R1162     -2.1570816636085510e-01
    z[2,10,6]  R1163     8.8239498436450958e-03
    z[2,10,6]  R1164     -1.3048341870307922e-01
    z[2,10,6]  R1165     7.9777045175433159e-03
    z[2,10,6]  R1166     7.3663994669914246e-02
    z[2,10,6]  R1167     7.0254206657409668e-01
    z[2,10,6]  R1168     -3.7165313959121704e-01
    z[2,10,6]  R1169     2.5277087092399597e-01
    z[2,10,6]  R1170     2.8222542256116867e-02
    z[2,10,6]  R1171     -1.1257118545472622e-02
    z[2,10,6]  R1172     1.7796604335308075e-01
    z[2,10,6]  R1173     -7.2849661111831665e-02
    z[2,10,6]  R1174     9.3854013830423355e-03
    z[2,10,6]  R1175     -3.1947249174118042e-01
    z[2,10,6]  R1176     -0.0979093536734581
    z[2,10,6]  R1177     2.2815231233835220e-02
    z[2,10,6]  R1178     3.8587224483489990e-01
    z[2,10,6]  R1179     -8.4345191717147827e-02
    z[2,10,6]  R1180     -1.2673306465148926e-01
    z[2,10,6]  R1181     7.6837375760078430e-02
    z[2,10,6]  R1182     -5.8577362447977066e-02
    z[2,10,6]  R1183     -2.1849749982357025e-01
    z[2,10,6]  R1184     -3.4982562065124512e-01
    z[2,10,6]  R1185     9.2579156160354614e-02
    z[2,10,6]  R1186     2.7644306421279907e-01
    z[2,10,6]  R1187     6.7327147722244263e-01
    z[2,10,6]  R1188     -7.6228022575378418e-02
    z[2,10,6]  R1189     3.6781498789787292e-01
    z[2,10,6]  R1190     2.8878265619277954e-01
    z[2,10,6]  R1191     -4.1889244318008423e-01
    z[2,10,6]  R1192     -9.1430976986885071e-02
    z[2,10,6]  R1193     -2.0811778306961060e-01
    z[2,10,6]  R1194     -3.2275122404098511e-01
    z[2,10,6]  R1195     -4.4729572534561157e-01
    z[2,10,6]  R1196     -5.7501184940338135e-01
    z[2,10,6]  R1197     -1.4265993237495422e-01
    z[2,10,6]  R1198     -3.0545833706855774e-01
    z[2,10,6]  R1199     -1.6427166759967804e-01
    z[2,10,6]  R1200     2.0659960806369781e-01
    z[2,10,6]  R1201     -2.2668333351612091e-01
    z[2,10,6]  R1202     2.0110729336738586e-01
    z[2,10,6]  R1203     1.2507688999176025e-01
    z[2,10,6]  R1204     -1.3507668673992157e-01
    z[2,10,6]  R1205     -2.0407313108444214e-01
    z[2,10,6]  R1206     1.7033822834491730e-01
    z[2,10,6]  R1207     -4.6367627382278442e-01
    z[2,10,6]  R1208     0.197689488530159
    z[2,10,6]  R1209     3.9398968219757080e-02
    z[2,10,6]  R1210     1.2318865209817886e-01
    z[2,10,6]  R1211     -1.4014187268912792e-02
    z[2,10,6]  R1212     5.6017464399337769e-01
    z[2,10,6]  R1213     9.2212647199630737e-02
    z[2,10,6]  R1214     3.5562083125114441e-01
    z[2,10,6]  R1215     -2.2206236422061920e-01
    z[2,10,6]  R1216     -8.0214828252792358e-02
    z[2,10,6]  R1217     1.7276298999786377e-01
    z[2,10,6]  R1218     2.4914576113224030e-01
    z[2,10,6]  R1219     -4.4145914912223816e-01
    z[2,10,6]  R1220     -2.8837126493453979e-01
    z[2,10,6]  R1221     1.7233215272426605e-01
    z[2,10,6]  R1222     -3.0135154724121094e-01
    z[2,10,6]  R1223     -1.1381273716688156e-01
    z[2,10,6]  R1224     1.3115748763084412e-01
    z[2,10,6]  R1225     4.3380558490753174e-02
    z[10,2,0]  R20       1
    z[10,2,0]  R92       -1
    z[10,2,0]  R1226     -1
    z[10,2,0]  R1227     1
    z[10,2,0]  R1240     -0.0322338342666626
    z[10,2,0]  R1241     -3.8929153233766556e-02
    z[10,2,0]  R1242     -2.8456223011016846e-01
    z[10,2,0]  R1243     -9.5431968569755554e-02
    z[10,2,0]  R1244     4.8519930243492126e-01
    z[10,2,0]  R1245     2.9040375351905823e-01
    z[10,2,0]  R1246     6.2423527240753174e-01
    z[10,2,0]  R1247     0.68561190366745
    z[10,2,0]  R1248     3.9377138018608093e-01
    z[10,2,0]  R1249     4.7939980030059814e-01
    z[10,2,0]  R1250     -1.3835345208644867e-01
    z[10,2,0]  R1251     -2.6231449842453003e-01
    z[10,2,0]  R1252     -8.1875901669263840e-03
    z[10,2,0]  R1253     -7.8163832426071167e-01
    z[10,2,0]  R1254     -4.8524963855743408e-01
    z[10,2,0]  R1255     7.1659278869628906e-01
    z[10,2,0]  R1256     4.5273523777723312e-02
    z[10,2,0]  R1257     -4.5310713350772858e-02
    z[10,2,0]  R1258     6.3448154926300049e-01
    z[10,2,0]  R1259     3.3574381470680237e-01
    z[10,2,0]  R1260     -7.6139461994171143e-01
    z[10,2,0]  R1261     -7.8718638420104980e-01
    z[10,2,0]  R1262     -5.9369087219238281e-01
    z[10,2,0]  R1263     -5.3711426258087158e-01
    z[10,2,0]  R1264     1.0929322987794876e-01
    z[10,2,0]  R1265     2.8275832533836365e-01
    z[10,2,0]  R1266     7.5258262455463409e-02
    z[10,2,0]  R1267     5.1826828718185425e-01
    z[10,2,0]  R1268     8.6387908458709717e-01
    z[10,2,0]  R1269     2.2995744645595551e-01
    z[10,2,0]  R1270     -4.4182431697845459e-01
    z[10,2,0]  R1271     -4.4682115316390991e-01
    z[10,2,0]  R1272     -2.6626887917518616e-01
    z[10,2,0]  R1273     -2.6983499526977539e-01
    z[10,2,0]  R1274     -2.8977537155151367e-01
    z[10,2,0]  R1275     1.8678304553031921e-01
    z[10,2,0]  R1276     1.8696199357509613e-01
    z[10,2,0]  R1277     3.3619109541177750e-02
    z[10,2,0]  R1278     5.5952310562133789e-01
    z[10,2,0]  R1279     9.2262578010559082e-01
    z[10,2,0]  R1280     1.7375077307224274e-01
    z[10,2,0]  R1281     1.0416479408740997e-01
    z[10,2,0]  R1282     3.5076405853033066e-02
    z[10,2,0]  R1283     1.1815072596073151e-01
    z[10,2,0]  R1284     1.3126258552074432e-01
    z[10,2,0]  R1285     4.0457978844642639e-02
    z[10,2,0]  R1286     -3.9107404649257660e-02
    z[10,2,0]  R1287     -7.3462487198412418e-03
    z[10,2,0]  R1288     -2.0507071912288666e-01
    z[10,2,0]  R1289     5.1161199808120728e-02
    z[10,2,0]  R1290     -5.0340861082077026e-02
    z[10,2,0]  R1291     1.0358274728059769e-01
    z[10,2,0]  R1292     -1.6905583441257477e-02
    z[10,2,0]  R1293     1.8200548365712166e-02
    z[10,2,0]  R1294     -1.5195293724536896e-01
    z[10,2,0]  R1295     -1.0875476151704788e-01
    z[10,2,0]  R1296     -1.0530030727386475e-01
    z[10,2,0]  R1297     -1.1921381205320358e-01
    z[10,2,0]  R1298     -9.4531789422035217e-02
    z[10,2,0]  R1299     -9.7032509744167328e-02
    z[10,2,0]  R1300     -1.1137016862630844e-01
    z[10,2,0]  R1301     -1.5104120969772339e-01
    z[10,2,0]  R1302     -8.7838634848594666e-02
    z[10,2,0]  R1303     -9.9680311977863312e-02
    z[10,2,0]  R1304     -1.4754776656627655e-01
    z[10,2,0]  R1305     -6.5765053033828735e-02
    z[10,2,0]  R1306     -1.2139682471752167e-01
    z[10,2,0]  R1307     2.1158248186111450e-02
    z[10,2,0]  R1308     -1.4087593555450439e-01
    z[10,2,0]  R1309     9.5251291990280151e-02
    z[10,2,0]  R1310     -0.0731421485543251
    z[10,2,0]  R1311     -1.8635485321283340e-02
    z[10,2,0]  R1312     -1.7498539388179779e-01
    z[10,2,0]  R1313     -1.8789456784725189e-01
    z[10,2,0]  R1314     -2.5243632495403290e-02
    z[10,2,0]  R1315     -5.5284440517425537e-02
    z[10,2,0]  R1316     -6.9861665368080139e-02
    z[10,2,0]  R1317     8.2318651676177979e-01
    z[10,2,0]  R1318     -5.5996431037783623e-03
    z[10,2,0]  R1319     -8.5662461817264557e-02
    z[10,2,0]  R1320     -3.8488205522298813e-02
    z[10,2,0]  R1321     -9.2685915529727936e-02
    z[10,2,0]  R1322     -1.4319211244583130e-01
    z[10,2,0]  R1323     -1.0172440856695175e-01
    z[10,2,0]  R1324     -8.5732407867908478e-02
    z[10,2,0]  R1325     6.5032929182052612e-01
    z[10,2,0]  R1326     6.3057667016983032e-01
    z[10,2,0]  R1327     6.4594465494155884e-01
    z[10,2,0]  R1328     7.2314405441284180e-01
    z[10,2,1]  R21       1
    z[10,2,1]  R93       -1
    z[10,2,1]  R1228     -1
    z[10,2,1]  R1229     1
    z[10,2,1]  R1240     5.9495024383068085e-02
    z[10,2,1]  R1241     -1.7787255346775055e-01
    z[10,2,1]  R1242     -3.7116494774818420e-01
    z[10,2,1]  R1243     2.7456842362880707e-02
    z[10,2,1]  R1244     5.0318706035614014e-01
    z[10,2,1]  R1245     2.7592509984970093e-01
    z[10,2,1]  R1246     1.3301257789134979e-01
    z[10,2,1]  R1247     1.5204125642776489e-01
    z[10,2,1]  R1248     4.5381143689155579e-01
    z[10,2,1]  R1249     3.1715300679206848e-01
    z[10,2,1]  R1250     -5.4111443459987640e-02
    z[10,2,1]  R1251     -3.6944654583930969e-01
    z[10,2,1]  R1252     8.8989585638046265e-01
    z[10,2,1]  R1253     -1.0060093551874161e-01
    z[10,2,1]  R1254     4.9054840207099915e-01
    z[10,2,1]  R1255     -3.6201146245002747e-01
    z[10,2,1]  R1256     3.4500020742416382e-01
    z[10,2,1]  R1257     7.2072863578796387e-01
    z[10,2,1]  R1258     4.4959199428558350e-01
    z[10,2,1]  R1259     5.7441401481628418e-01
    z[10,2,1]  R1260     -1.9486187398433685e-01
    z[10,2,1]  R1261     2.4525374174118042e-01
    z[10,2,1]  R1262     5.0622463226318359e-01
    z[10,2,1]  R1263     -5.3992480039596558e-01
    z[10,2,1]  R1264     4.0347132086753845e-01
    z[10,2,1]  R1265     3.0033415555953979e-01
    z[10,2,1]  R1266     4.7502881288528442e-01
    z[10,2,1]  R1267     5.4198604822158813e-01
    z[10,2,1]  R1268     9.3117982149124146e-02
    z[10,2,1]  R1269     5.5350724607706070e-02
    z[10,2,1]  R1270     -6.3070565462112427e-01
    z[10,2,1]  R1271     0.666795015335083
    z[10,2,1]  R1272     2.4894419312477112e-01
    z[10,2,1]  R1273     5.1834475994110107e-01
    z[10,2,1]  R1274     0.744705855846405
    z[10,2,1]  R1275     0.777864396572113
    z[10,2,1]  R1276     4.4287830591201782e-01
    z[10,2,1]  R1277     3.9503553509712219e-01
    z[10,2,1]  R1278     4.4211441278457642e-01
    z[10,2,1]  R1279     -4.0771577507257462e-02
    z[10,2,1]  R1280     -0.188704252243042
    z[10,2,1]  R1281     -2.4665230512619019e-01
    z[10,2,1]  R1282     -7.5864009559154510e-02
    z[10,2,1]  R1283     -1.4523386955261230e-01
    z[10,2,1]  R1284     3.9027415215969086e-02
    z[10,2,1]  R1285     3.2125559449195862e-01
    z[10,2,1]  R1286     -8.7640094757080078e-01
    z[10,2,1]  R1287     2.4323654174804688e-01
    z[10,2,1]  R1288     -7.8582540154457092e-02
    z[10,2,1]  R1289     9.0698373317718506e-01
    z[10,2,1]  R1290     7.7767539024353027e-01
    z[10,2,1]  R1291     7.6909792423248291e-01
    z[10,2,1]  R1292     7.4120289087295532e-01
    z[10,2,1]  R1293     0.731759786605835
    z[10,2,1]  R1294     6.7997241020202637e-01
    z[10,2,1]  R1295     6.6865491867065430e-01
    z[10,2,1]  R1296     0.649121105670929
    z[10,2,1]  R1297     0.642539918422699
    z[10,2,1]  R1298     6.3295543193817139e-01
    z[10,2,1]  R1299     5.9669071435928345e-01
    z[10,2,1]  R1300     -1.3306954503059387e-01
    z[10,2,1]  R1301     -5.5064046382904053e-01
    z[10,2,1]  R1302     -0.590140163898468
    z[10,2,1]  R1303     -4.8204281926155090e-01
    z[10,2,1]  R1304     -3.4903496503829956e-01
    z[10,2,1]  R1305     -2.7629068493843079e-01
    z[10,2,1]  R1306     -4.7363707423210144e-01
    z[10,2,1]  R1307     -9.0629106760025024e-01
    z[10,2,1]  R1308     -5.0873714685440063e-01
    z[10,2,1]  R1309     8.0913090705871582e-01
    z[10,2,1]  R1310     6.0107976198196411e-01
    z[10,2,1]  R1311     5.5919289588928223e-01
    z[10,2,1]  R1312     -1.8453678488731384e-01
    z[10,2,1]  R1313     -2.1710814535617828e-01
    z[10,2,1]  R1314     -9.4162505865097046e-01
    z[10,2,1]  R1315     -9.0053504705429077e-01
    z[10,2,1]  R1316     -8.9092463254928589e-01
    z[10,2,1]  R1317     -5.0908583402633667e-01
    z[10,2,1]  R1318     -8.8902920484542847e-01
    z[10,2,1]  R1319     8.2013344764709473e-01
    z[10,2,1]  R1320     6.7155414819717407e-01
    z[10,2,1]  R1321     4.3844765424728394e-01
    z[10,2,1]  R1322     -9.7919665277004242e-02
    z[10,2,1]  R1323     -5.9339928627014160e-01
    z[10,2,1]  R1324     -8.5561513900756836e-01
    z[10,2,1]  R1325     -5.1422142982482910e-01
    z[10,2,1]  R1326     -5.1929527521133423e-01
    z[10,2,1]  R1327     -0.442984014749527
    z[10,2,1]  R1328     -2.8734889626502991e-01
    z[10,2,2]  R22       1
    z[10,2,2]  R94       -1
    z[10,2,2]  R1230     -1
    z[10,2,2]  R1231     1
    z[10,2,2]  R1240     -0.724852442741394
    z[10,2,2]  R1241     -0.00740482984110713
    z[10,2,2]  R1242     -4.8283287882804871e-01
    z[10,2,2]  R1243     2.7693548798561096e-01
    z[10,2,2]  R1244     -3.0036973953247070e-01
    z[10,2,2]  R1245     -5.8482116460800171e-01
    z[10,2,2]  R1246     -4.4869095087051392e-01
    z[10,2,2]  R1247     -3.9584168791770935e-01
    z[10,2,2]  R1248     -3.1886133551597595e-01
    z[10,2,2]  R1249     -6.8888276815414429e-02
    z[10,2,2]  R1250     1.9236966967582703e-01
    z[10,2,2]  R1251     -2.3499862849712372e-01
    z[10,2,2]  R1252     -1.2824200093746185e-01
    z[10,2,2]  R1253     4.8321297764778137e-01
    z[10,2,2]  R1254     -4.0007346868515015e-01
    z[10,2,2]  R1255     -3.2211970537900925e-02
    z[10,2,2]  R1256     -2.3078870773315430e-01
    z[10,2,2]  R1257     4.5992609858512878e-01
    z[10,2,2]  R1258     3.2394322752952576e-01
    z[10,2,2]  R1259     1.2365873157978058e-01
    z[10,2,2]  R1260     5.4677021503448486e-01
    z[10,2,2]  R1261     -0.00409313291311264
    z[10,2,2]  R1262     4.9141440540552139e-02
    z[10,2,2]  R1263     -2.1499194204807281e-01
    z[10,2,2]  R1264     -4.8322245478630066e-01
    z[10,2,2]  R1265     -4.3023490905761719e-01
    z[10,2,2]  R1266     -3.2550308108329773e-01
    z[10,2,2]  R1267     -1.5176175534725189e-01
    z[10,2,2]  R1268     5.5523775517940521e-02
    z[10,2,2]  R1269     -5.1858407258987427e-01
    z[10,2,2]  R1270     4.1414242982864380e-01
    z[10,2,2]  R1271     -1.7898446321487427e-01
    z[10,2,2]  R1272     4.4153865426778793e-02
    z[10,2,2]  R1273     4.3548453599214554e-02
    z[10,2,2]  R1274     2.8381463885307312e-01
    z[10,2,2]  R1275     -3.0663815140724182e-01
    z[10,2,2]  R1276     -5.5600476264953613e-01
    z[10,2,2]  R1277     -6.0695797204971313e-01
    z[10,2,2]  R1278     -4.2058983445167542e-01
    z[10,2,2]  R1279     -1.8685944378376007e-02
    z[10,2,2]  R1280     -4.4951781630516052e-01
    z[10,2,2]  R1281     -5.7896214723587036e-01
    z[10,2,2]  R1282     -7.5325781106948853e-01
    z[10,2,2]  R1283     -6.0198068618774414e-01
    z[10,2,2]  R1284     2.7803765609860420e-02
    z[10,2,2]  R1285     4.9266871809959412e-01
    z[10,2,2]  R1286     1.9959209859371185e-01
    z[10,2,2]  R1287     6.3347554206848145e-01
    z[10,2,2]  R1288     3.4610655903816223e-01
    z[10,2,2]  R1289     -9.4338893890380859e-02
    z[10,2,2]  R1290     -2.8370854258537292e-01
    z[10,2,2]  R1291     1.4953862130641937e-01
    z[10,2,2]  R1292     2.9757255315780640e-01
    z[10,2,2]  R1293     5.3267461061477661e-01
    z[10,2,2]  R1294     4.1305556893348694e-01
    z[10,2,2]  R1295     1.0275747627019882e-01
    z[10,2,2]  R1296     2.9723986983299255e-01
    z[10,2,2]  R1297     2.5612899661064148e-01
    z[10,2,2]  R1298     1.3214507699012756e-01
    z[10,2,2]  R1299     8.6175657808780670e-02
    z[10,2,2]  R1300     4.3202412128448486e-01
    z[10,2,2]  R1301     4.8419484496116638e-01
    z[10,2,2]  R1302     3.3047696948051453e-01
    z[10,2,2]  R1303     5.3097373247146606e-01
    z[10,2,2]  R1304     4.6801841259002686e-01
    z[10,2,2]  R1305     2.5067463517189026e-01
    z[10,2,2]  R1306     3.1835344433784485e-01
    z[10,2,2]  R1307     2.5098061561584473e-01
    z[10,2,2]  R1308     1.9846871495246887e-01
    z[10,2,2]  R1309     2.8659293428063393e-02
    z[10,2,2]  R1310     -2.0808011293411255e-01
    z[10,2,2]  R1311     5.2410387992858887e-01
    z[10,2,2]  R1312     0.0869893953204155
    z[10,2,2]  R1313     4.6075470745563507e-02
    z[10,2,2]  R1314     -9.9441379308700562e-02
    z[10,2,2]  R1315     2.8549528121948242e-01
    z[10,2,2]  R1316     1.1278945207595825e-01
    z[10,2,2]  R1317     4.9462612718343735e-02
    z[10,2,2]  R1318     -1.4428270515054464e-03
    z[10,2,2]  R1319     1.0920712351799011e-01
    z[10,2,2]  R1320     2.8010737895965576e-01
    z[10,2,2]  R1321     2.0575119182467461e-02
    z[10,2,2]  R1322     -0.0702795684337616
    z[10,2,2]  R1323     -0.0913701057434082
    z[10,2,2]  R1324     2.1251454949378967e-01
    z[10,2,2]  R1325     2.9008436203002930e-01
    z[10,2,2]  R1326     3.0944174528121948e-01
    z[10,2,2]  R1327     4.6052265167236328e-01
    z[10,2,2]  R1328     -8.3492629230022430e-02
    z[10,2,3]  R23       1
    z[10,2,3]  R95       -1
    z[10,2,3]  R1232     -1
    z[10,2,3]  R1233     1
    z[10,2,3]  R1240     -0.585458517074585
    z[10,2,3]  R1241     -5.2857035398483276e-01
    z[10,2,3]  R1242     -4.2818996310234070e-01
    z[10,2,3]  R1243     -8.7082099914550781e-01
    z[10,2,3]  R1244     2.9156097769737244e-01
    z[10,2,3]  R1245     4.1652080416679382e-01
    z[10,2,3]  R1246     1.2389941513538361e-01
    z[10,2,3]  R1247     2.0483785867691040e-01
    z[10,2,3]  R1248     5.9187458828091621e-03
    z[10,2,3]  R1249     1.0321240127086639e-01
    z[10,2,3]  R1250     5.7243430055677891e-03
    z[10,2,3]  R1251     5.3754359483718872e-01
    z[10,2,3]  R1252     1.8291927874088287e-01
    z[10,2,3]  R1253     2.3596415296196938e-02
    z[10,2,3]  R1254     4.3839433789253235e-01
    z[10,2,3]  R1255     -2.7212709188461304e-01
    z[10,2,3]  R1256     5.7946640253067017e-01
    z[10,2,3]  R1257     -0.231314554810524
    z[10,2,3]  R1258     -4.0604448318481445e-01
    z[10,2,3]  R1259     -2.2802665829658508e-01
    z[10,2,3]  R1260     1.3147830963134766e-01
    z[10,2,3]  R1261     2.5725081562995911e-01
    z[10,2,3]  R1262     5.6381557136774063e-02
    z[10,2,3]  R1263     3.9758530259132385e-01
    z[10,2,3]  R1264     7.1642249822616577e-01
    z[10,2,3]  R1265     6.4207404851913452e-01
    z[10,2,3]  R1266     4.8567295074462891e-01
    z[10,2,3]  R1267     6.1398875713348389e-01
    z[10,2,3]  R1268     1.0109191387891769e-01
    z[10,2,3]  R1269     0.778455913066864
    z[10,2,3]  R1270     -3.1388387084007263e-01
    z[10,2,3]  R1271     9.2800423502922058e-02
    z[10,2,3]  R1272     1.0242816060781479e-01
    z[10,2,3]  R1273     -1.6660006344318390e-01
    z[10,2,3]  R1274     -3.7849491834640503e-01
    z[10,2,3]  R1275     2.5698107481002808e-01
    z[10,2,3]  R1276     4.8226529359817505e-01
    z[10,2,3]  R1277     0.67186039686203
    z[10,2,3]  R1278     5.2164858579635620e-01
    z[10,2,3]  R1279     -1.0438710451126099e-01
    z[10,2,3]  R1280     -7.4526280164718628e-01
    z[10,2,3]  R1281     -6.8571335077285767e-01
    z[10,2,3]  R1282     -3.4381410479545593e-01
    z[10,2,3]  R1283     -4.9803760647773743e-01
    z[10,2,3]  R1284     -8.3985865116119385e-01
    z[10,2,3]  R1285     -0.0569143183529377
    z[10,2,3]  R1286     1.1172537505626678e-01
    z[10,2,3]  R1287     2.8988546133041382e-01
    z[10,2,3]  R1288     3.5846811532974243e-01
    z[10,2,3]  R1289     7.7495403587818146e-02
    z[10,2,3]  R1290     1.9534422457218170e-01
    z[10,2,3]  R1291     2.9060753062367439e-02
    z[10,2,3]  R1292     -5.9179320931434631e-02
    z[10,2,3]  R1293     -3.4050792455673218e-01
    z[10,2,3]  R1294     3.6460673809051514e-01
    z[10,2,3]  R1295     5.4198390245437622e-01
    z[10,2,3]  R1296     0.00823516957461834
    z[10,2,3]  R1297     4.8303452134132385e-01
    z[10,2,3]  R1298     1.5749073028564453e-01
    z[10,2,3]  R1299     4.3526706099510193e-01
    z[10,2,3]  R1300     7.9342108964920044e-01
    z[10,2,3]  R1301     6.5937399864196777e-01
    z[10,2,3]  R1302     6.5896546840667725e-01
    z[10,2,3]  R1303     6.2674939632415771e-01
    z[10,2,3]  R1304     6.7736089229583740e-01
    z[10,2,3]  R1305     7.3747175931930542e-01
    z[10,2,3]  R1306     6.9485068321228027e-01
    z[10,2,3]  R1307     -5.8983918279409409e-03
    z[10,2,3]  R1308     7.4100762605667114e-01
    z[10,2,3]  R1309     -5.2359545230865479e-01
    z[10,2,3]  R1310     1.0568166524171829e-01
    z[10,2,3]  R1311     -4.7711357474327087e-03
    z[10,2,3]  R1312     0.899384617805481
    z[10,2,3]  R1313     9.2336362600326538e-01
    z[10,2,3]  R1314     2.6426756381988525e-01
    z[10,2,3]  R1315     6.7940421402454376e-02
    z[10,2,3]  R1316     2.9856231808662415e-01
    z[10,2,3]  R1317     2.1147172152996063e-01
    z[10,2,3]  R1318     1.3571204245090485e-01
    z[10,2,3]  R1319     2.6888519525527954e-01
    z[10,2,3]  R1320     3.7405043840408325e-01
    z[10,2,3]  R1321     -1.7554442584514618e-01
    z[10,2,3]  R1322     9.7027087211608887e-01
    z[10,2,3]  R1323     7.2116440534591675e-01
    z[10,2,3]  R1324     1.2738877534866333e-01
    z[10,2,3]  R1325     0.232284277677536
    z[10,2,3]  R1326     1.7936527729034424e-01
    z[10,2,3]  R1327     5.1085177809000015e-02
    z[10,2,3]  R1328     3.9830267429351807e-01
    z[10,2,4]  R24       1
    z[10,2,4]  R96       -1
    z[10,2,4]  R1234     -1
    z[10,2,4]  R1235     1
    z[10,2,4]  R1240     -1.6976216435432434e-01
    z[10,2,4]  R1241     -4.0392079949378967e-01
    z[10,2,4]  R1242     0.598517656326294
    z[10,2,4]  R1243     1.3599993288516998e-01
    z[10,2,4]  R1244     4.9204263091087341e-01
    z[10,2,4]  R1245     1.4729213714599609e-01
    z[10,2,4]  R1246     6.0209494829177856e-01
    z[10,2,4]  R1247     4.2323696613311768e-01
    z[10,2,4]  R1248     4.7182390093803406e-01
    z[10,2,4]  R1249     -3.3233314752578735e-01
    z[10,2,4]  R1250     -5.8718425035476685e-01
    z[10,2,4]  R1251     -1.7536464333534241e-01
    z[10,2,4]  R1252     8.0129742622375488e-02
    z[10,2,4]  R1253     -2.6915794610977173e-01
    z[10,2,4]  R1254     1.4086230099201202e-01
    z[10,2,4]  R1255     3.5032492876052856e-01
    z[10,2,4]  R1256     -6.6820669174194336e-01
    z[10,2,4]  R1257     -4.1844749450683594e-01
    z[10,2,4]  R1258     -1.4110292494297028e-01
    z[10,2,4]  R1259     -4.7072374820709229e-01
    z[10,2,4]  R1260     1.8801175057888031e-01
    z[10,2,4]  R1261     1.6922098398208618e-01
    z[10,2,4]  R1262     -5.7497894763946533e-01
    z[10,2,4]  R1263     -4.0878134965896606e-01
    z[10,2,4]  R1264     -2.5134158134460449e-01
    z[10,2,4]  R1265     4.7637414932250977e-01
    z[10,2,4]  R1266     5.9170957654714584e-02
    z[10,2,4]  R1267     -1.1432316154241562e-01
    z[10,2,4]  R1268     3.2425925135612488e-01
    z[10,2,4]  R1269     -3.0830618925392628e-03
    z[10,2,4]  R1270     -3.5209706425666809e-01
    z[10,2,4]  R1271     -5.3375250101089478e-01
    z[10,2,4]  R1272     1.4306859672069550e-01
    z[10,2,4]  R1273     3.9614674448966980e-01
    z[10,2,4]  R1274     -8.5101991891860962e-02
    z[10,2,4]  R1275     4.0996676683425903e-01
    z[10,2,4]  R1276     3.1603109836578369e-01
    z[10,2,4]  R1277     7.8276596963405609e-02
    z[10,2,4]  R1278     -4.5020073652267456e-02
    z[10,2,4]  R1279     2.4737946689128876e-01
    z[10,2,4]  R1280     -3.7721905112266541e-01
    z[10,2,4]  R1281     7.5825735926628113e-02
    z[10,2,4]  R1282     1.9991464912891388e-01
    z[10,2,4]  R1283     4.4819310307502747e-01
    z[10,2,4]  R1284     4.4935014843940735e-01
    z[10,2,4]  R1285     -7.5711631774902344e-01
    z[10,2,4]  R1286     3.1309577822685242e-01
    z[10,2,4]  R1287     8.7982267141342163e-02
    z[10,2,4]  R1288     4.1028323769569397e-01
    z[10,2,4]  R1289     -1.1457324773073196e-01
    z[10,2,4]  R1290     2.8668063879013062e-01
    z[10,2,4]  R1291     3.5323154926300049e-01
    z[10,2,4]  R1292     -2.6967665553092957e-01
    z[10,2,4]  R1293     -1.3486875593662262e-01
    z[10,2,4]  R1294     3.0621844530105591e-01
    z[10,2,4]  R1295     3.8816508650779724e-01
    z[10,2,4]  R1296     6.6257226467132568e-01
    z[10,2,4]  R1297     -2.9584395885467529e-01
    z[10,2,4]  R1298     5.8784645795822144e-01
    z[10,2,4]  R1299     1.3013081252574921e-01
    z[10,2,4]  R1300     -3.3607015013694763e-01
    z[10,2,4]  R1301     4.4919040054082870e-02
    z[10,2,4]  R1302     -2.5752422213554382e-01
    z[10,2,4]  R1303     -1.4710766077041626e-01
    z[10,2,4]  R1304     -6.0857083648443222e-02
    z[10,2,4]  R1305     -4.1886419057846069e-01
    z[10,2,4]  R1306     -2.7050018310546875e-01
    z[10,2,4]  R1307     -0.0910007506608963
    z[10,2,4]  R1308     1.0590924322605133e-01
    z[10,2,4]  R1309     -9.0013951063156128e-02
    z[10,2,4]  R1310     -2.6118251681327820e-01
    z[10,2,4]  R1311     0.267488956451416
    z[10,2,4]  R1312     -2.1014265716075897e-01
    z[10,2,4]  R1313     1.6813451051712036e-01
    z[10,2,4]  R1314     -1.6713267564773560e-01
    z[10,2,4]  R1315     -0.00890843104571104
    z[10,2,4]  R1316     1.3897763192653656e-01
    z[10,2,4]  R1317     1.1517754197120667e-01
    z[10,2,4]  R1318     1.5052539110183716e-01
    z[10,2,4]  R1319     4.7526782751083374e-01
    z[10,2,4]  R1320     -5.2258223295211792e-01
    z[10,2,4]  R1321     6.3477098941802979e-01
    z[10,2,4]  R1322     -9.3176737427711487e-02
    z[10,2,4]  R1323     -1.1465954780578613e-01
    z[10,2,4]  R1324     4.3941894173622131e-01
    z[10,2,4]  R1325     -1.8070462346076965e-01
    z[10,2,4]  R1326     -3.7156096100807190e-01
    z[10,2,4]  R1327     -2.0955021679401398e-01
    z[10,2,4]  R1328     -3.6808863282203674e-01
    z[10,2,5]  R25       1
    z[10,2,5]  R97       -1
    z[10,2,5]  R1236     -1
    z[10,2,5]  R1237     1
    z[10,2,5]  R1240     1.4835315942764282e-01
    z[10,2,5]  R1241     2.6637926697731018e-01
    z[10,2,5]  R1242     -2.7432022616267204e-02
    z[10,2,5]  R1243     3.6502219736576080e-02
    z[10,2,5]  R1244     -1.0321357101202011e-01
    z[10,2,5]  R1245     3.5617381334304810e-01
    z[10,2,5]  R1246     -7.1311786770820618e-02
    z[10,2,5]  R1247     2.9279375076293945e-01
    z[10,2,5]  R1248     -4.5880886912345886e-01
    z[10,2,5]  R1249     5.8623600006103516e-01
    z[10,2,5]  R1250     5.1523530483245850e-01
    z[10,2,5]  R1251     0.631995439529419
    z[10,2,5]  R1252     2.4163471162319183e-01
    z[10,2,5]  R1253     -0.213162362575531
    z[10,2,5]  R1254     -3.3033466339111328e-01
    z[10,2,5]  R1255     3.2594287395477295e-01
    z[10,2,5]  R1256     5.4186254739761353e-02
    z[10,2,5]  R1257     -1.5071900188922882e-01
    z[10,2,5]  R1258     -2.9552176594734192e-01
    z[10,2,5]  R1259     -4.7624596953392029e-01
    z[10,2,5]  R1260     -4.1224356740713120e-02
    z[10,2,5]  R1261     -1.0179454833269119e-01
    z[10,2,5]  R1262     -1.2646009027957916e-01
    z[10,2,5]  R1263     -2.1688570082187653e-01
    z[10,2,5]  R1264     1.2357288040220737e-02
    z[10,2,5]  R1265     -7.3192939162254333e-02
    z[10,2,5]  R1266     -3.3099305629730225e-01
    z[10,2,5]  R1267     1.2673702836036682e-01
    z[10,2,5]  R1268     -1.1368635110557079e-02
    z[10,2,5]  R1269     1.4075355231761932e-01
    z[10,2,5]  R1270     -8.0980204045772552e-02
    z[10,2,5]  R1271     -1.8685216084122658e-02
    z[10,2,5]  R1272     8.7871748208999634e-01
    z[10,2,5]  R1273     5.2634340524673462e-01
    z[10,2,5]  R1274     2.1733374893665314e-01
    z[10,2,5]  R1275     4.6922564506530762e-02
    z[10,2,5]  R1276     1.9103546440601349e-01
    z[10,2,5]  R1277     6.2783464789390564e-02
    z[10,2,5]  R1278     1.5240314602851868e-01
    z[10,2,5]  R1279     2.6976841688156128e-01
    z[10,2,5]  R1280     1.0752414911985397e-01
    z[10,2,5]  R1281     -2.2847658395767212e-01
    z[10,2,5]  R1282     2.9388007521629333e-01
    z[10,2,5]  R1283     2.6284396648406982e-01
    z[10,2,5]  R1284     1.8035946786403656e-01
    z[10,2,5]  R1285     -2.6458916068077087e-01
    z[10,2,5]  R1286     -1.8782602250576019e-01
    z[10,2,5]  R1287     7.1179017424583435e-02
    z[10,2,5]  R1288     1.4700101315975189e-01
    z[10,2,5]  R1289     4.8983491957187653e-02
    z[10,2,5]  R1290     -4.3268904089927673e-01
    z[10,2,5]  R1291     4.4912725687026978e-02
    z[10,2,5]  R1292     3.6912506818771362e-01
    z[10,2,5]  R1293     -1.0355526208877563e-01
    z[10,2,5]  R1294     -2.3538687825202942e-01
    z[10,2,5]  R1295     2.3491522669792175e-01
    z[10,2,5]  R1296     -9.9665679037570953e-02
    z[10,2,5]  R1297     8.0978050827980042e-02
    z[10,2,5]  R1298     4.3259942531585693e-01
    z[10,2,5]  R1299     6.2491351366043091e-01
    z[10,2,5]  R1300     -1.2104964256286621e-01
    z[10,2,5]  R1301     -1.2605790980160236e-02
    z[10,2,5]  R1302     1.3747389614582062e-01
    z[10,2,5]  R1303     2.0527207851409912e-01
    z[10,2,5]  R1304     3.8007053732872009e-01
    z[10,2,5]  R1305     3.0109593272209167e-01
    z[10,2,5]  R1306     -3.2173928618431091e-01
    z[10,2,5]  R1307     2.9975953698158264e-01
    z[10,2,5]  R1308     3.4868037700653076e-01
    z[10,2,5]  R1309     2.1847660839557648e-01
    z[10,2,5]  R1310     -1.3078860938549042e-01
    z[10,2,5]  R1311     -4.5007985830307007e-01
    z[10,2,5]  R1312     -1.0398718714714050e-01
    z[10,2,5]  R1313     -1.8376775085926056e-01
    z[10,2,5]  R1314     -0.0701352059841156
    z[10,2,5]  R1315     -2.6097044348716736e-01
    z[10,2,5]  R1316     -2.7366024255752563e-01
    z[10,2,5]  R1317     -0.0517178550362587
    z[10,2,5]  R1318     -0.257789671421051
    z[10,2,5]  R1319     1.8757749348878860e-02
    z[10,2,5]  R1320     -2.3568439483642578e-01
    z[10,2,5]  R1321     -4.6486797928810120e-01
    z[10,2,5]  R1322     8.8016845285892487e-02
    z[10,2,5]  R1323     -2.8265652060508728e-01
    z[10,2,5]  R1324     -1.3760939240455627e-02
    z[10,2,5]  R1325     3.7209907174110413e-01
    z[10,2,5]  R1326     1.3777013123035431e-01
    z[10,2,5]  R1327     -7.4434436857700348e-02
    z[10,2,5]  R1328     2.9123359918594360e-01
    z[10,2,6]  R26       1
    z[10,2,6]  R98       -1
    z[10,2,6]  R1238     -1
    z[10,2,6]  R1239     1
    z[10,2,6]  R1240     2.7644306421279907e-01
    z[10,2,6]  R1241     6.7327147722244263e-01
    z[10,2,6]  R1242     -7.6228022575378418e-02
    z[10,2,6]  R1243     3.6781498789787292e-01
    z[10,2,6]  R1244     2.8878265619277954e-01
    z[10,2,6]  R1245     -4.1889244318008423e-01
    z[10,2,6]  R1246     -9.1430976986885071e-02
    z[10,2,6]  R1247     -2.0811778306961060e-01
    z[10,2,6]  R1248     -3.2275122404098511e-01
    z[10,2,6]  R1249     -4.4729572534561157e-01
    z[10,2,6]  R1250     -5.7501184940338135e-01
    z[10,2,6]  R1251     -1.4265993237495422e-01
    z[10,2,6]  R1252     -3.0545833706855774e-01
    z[10,2,6]  R1253     -1.6427166759967804e-01
    z[10,2,6]  R1254     2.0659960806369781e-01
    z[10,2,6]  R1255     -2.2668333351612091e-01
    z[10,2,6]  R1256     2.0110729336738586e-01
    z[10,2,6]  R1257     1.2507688999176025e-01
    z[10,2,6]  R1258     -1.3507668673992157e-01
    z[10,2,6]  R1259     -2.0407313108444214e-01
    z[10,2,6]  R1260     1.7033822834491730e-01
    z[10,2,6]  R1261     -4.6367627382278442e-01
    z[10,2,6]  R1262     0.197689488530159
    z[10,2,6]  R1263     3.9398968219757080e-02
    z[10,2,6]  R1264     1.2318865209817886e-01
    z[10,2,6]  R1265     -1.4014187268912792e-02
    z[10,2,6]  R1266     5.6017464399337769e-01
    z[10,2,6]  R1267     9.2212647199630737e-02
    z[10,2,6]  R1268     3.5562083125114441e-01
    z[10,2,6]  R1269     -2.2206236422061920e-01
    z[10,2,6]  R1270     -8.0214828252792358e-02
    z[10,2,6]  R1271     1.7276298999786377e-01
    z[10,2,6]  R1272     2.4914576113224030e-01
    z[10,2,6]  R1273     -4.4145914912223816e-01
    z[10,2,6]  R1274     -2.8837126493453979e-01
    z[10,2,6]  R1275     1.7233215272426605e-01
    z[10,2,6]  R1276     -3.0135154724121094e-01
    z[10,2,6]  R1277     -1.1381273716688156e-01
    z[10,2,6]  R1278     1.3115748763084412e-01
    z[10,2,6]  R1279     4.3380558490753174e-02
    z[10,2,6]  R1280     1.5120458602905273e-01
    z[10,2,6]  R1281     2.5487518310546875e-01
    z[10,2,6]  R1282     4.2553195357322693e-01
    z[10,2,6]  R1283     -2.9079419374465942e-01
    z[10,2,6]  R1284     -2.0165875554084778e-01
    z[10,2,6]  R1285     7.7225565910339355e-02
    z[10,2,6]  R1286     -2.1157729625701904e-01
    z[10,2,6]  R1287     -6.6531932353973389e-01
    z[10,2,6]  R1288     7.1661704778671265e-01
    z[10,2,6]  R1289     -3.7990954518318176e-01
    z[10,2,6]  R1290     -0.0680527314543724
    z[10,2,6]  R1291     4.9775806069374084e-01
    z[10,2,6]  R1292     3.8639616966247559e-01
    z[10,2,6]  R1293     1.8866670131683350e-01
    z[10,2,6]  R1294     2.4863265454769135e-01
    z[10,2,6]  R1295     -0.175812765955925
    z[10,2,6]  R1296     1.7377892136573792e-01
    z[10,2,6]  R1297     4.2417564988136292e-01
    z[10,2,6]  R1298     1.2433759123086929e-01
    z[10,2,6]  R1299     1.7381101846694946e-01
    z[10,2,6]  R1300     -1.6165116429328918e-01
    z[10,2,6]  R1301     5.0855990499258041e-02
    z[10,2,6]  R1302     -1.2389753758907318e-01
    z[10,2,6]  R1303     -1.3846738636493683e-01
    z[10,2,6]  R1304     1.7432193458080292e-01
    z[10,2,6]  R1305     -2.1570816636085510e-01
    z[10,2,6]  R1306     8.8239498436450958e-03
    z[10,2,6]  R1307     -1.3048341870307922e-01
    z[10,2,6]  R1308     7.9777045175433159e-03
    z[10,2,6]  R1309     7.3663994669914246e-02
    z[10,2,6]  R1310     7.0254206657409668e-01
    z[10,2,6]  R1311     -3.7165313959121704e-01
    z[10,2,6]  R1312     2.5277087092399597e-01
    z[10,2,6]  R1313     2.8222542256116867e-02
    z[10,2,6]  R1314     -1.1257118545472622e-02
    z[10,2,6]  R1315     1.7796604335308075e-01
    z[10,2,6]  R1316     -7.2849661111831665e-02
    z[10,2,6]  R1317     9.3854013830423355e-03
    z[10,2,6]  R1318     -3.1947249174118042e-01
    z[10,2,6]  R1319     -0.0979093536734581
    z[10,2,6]  R1320     2.2815231233835220e-02
    z[10,2,6]  R1321     3.8587224483489990e-01
    z[10,2,6]  R1322     -8.4345191717147827e-02
    z[10,2,6]  R1323     -1.2673306465148926e-01
    z[10,2,6]  R1324     7.6837375760078430e-02
    z[10,2,6]  R1325     -5.8577362447977066e-02
    z[10,2,6]  R1326     -2.1849749982357025e-01
    z[10,2,6]  R1327     -3.4982562065124512e-01
    z[10,2,6]  R1328     9.2579156160354614e-02
    z[3,10,0]  R29       -1
    z[3,10,0]  R92       1
    z[3,10,0]  R1329     -1
    z[3,10,0]  R1330     1
    z[3,10,0]  R1343     -7.0556834340095520e-02
    z[3,10,0]  R1344     -2.9663050174713135e-01
    z[3,10,0]  R1345     -1.2225360423326492e-01
    z[3,10,0]  R1346     -5.9042003005743027e-02
    z[3,10,0]  R1347     -0.0837436318397522
    z[3,10,0]  R1348     -1.9234749674797058e-01
    z[3,10,0]  R1349     8.1895852088928223e-01
    z[3,10,0]  R1350     7.8993266820907593e-01
    z[3,10,0]  R1351     1.4451588690280914e-01
    z[3,10,0]  R1352     -3.3854654431343079e-01
    z[3,10,0]  R1353     -7.5919860601425171e-01
    z[3,10,0]  R1354     -4.4023331999778748e-01
    z[3,10,0]  R1355     -4.6406522393226624e-01
    z[3,10,0]  R1356     -4.5787465572357178e-01
    z[3,10,0]  R1357     -6.8517088890075684e-01
    z[3,10,0]  R1358     -1.8491105735301971e-01
    z[3,10,0]  R1359     -3.3509409427642822e-01
    z[3,10,0]  R1360     -2.8206023573875427e-01
    z[3,10,0]  R1361     2.7938228845596313e-01
    z[3,10,0]  R1362     -4.2142361402511597e-01
    z[3,10,0]  R1363     -0.584001362323761
    z[3,10,0]  R1364     4.0572577714920044e-01
    z[3,10,0]  R1365     1.0785473138093948e-01
    z[3,10,0]  R1366     -0.830449104309082
    z[3,10,0]  R1367     1.7969982326030731e-01
    z[3,10,0]  R1368     -0.642325758934021
    z[3,10,0]  R1369     1.1066393554210663e-01
    z[3,10,0]  R1370     -1.7487633228302002e-01
    z[3,10,0]  R1371     -6.8146413564682007e-01
    z[3,10,0]  R1372     4.7118470072746277e-01
    z[3,10,0]  R1373     -1.8216333119198680e-03
    z[3,10,0]  R1374     -6.6865408420562744e-01
    z[3,10,0]  R1375     6.5221273899078369e-01
    z[3,10,0]  R1376     -6.6511653363704681e-02
    z[3,10,0]  R1377     3.7986478209495544e-01
    z[3,10,0]  R1378     -4.3224725127220154e-01
    z[3,10,0]  R1379     2.6944720745086670e-01
    z[3,10,0]  R1380     -1.1762320250272751e-01
    z[3,10,0]  R1381     5.9010595083236694e-01
    z[3,10,0]  R1382     -6.5369868278503418e-01
    z[3,10,0]  R1383     1.5902586281299591e-01
    z[3,10,0]  R1384     -6.5894013643264771e-01
    z[3,10,0]  R1385     3.0720660090446472e-01
    z[3,10,0]  R1386     2.7164104580879211e-01
    z[3,10,0]  R1387     -4.1422676295042038e-02
    z[3,10,0]  R1388     -2.6115933060646057e-01
    z[3,10,0]  R1389     -4.4731575250625610e-01
    z[3,10,0]  R1390     -5.7417166233062744e-01
    z[3,10,0]  R1391     0.747056782245636
    z[3,10,0]  R1392     0.775826096534729
    z[3,10,0]  R1393     -1.7995016276836395e-01
    z[3,10,0]  R1394     1.1530910432338715e-01
    z[3,10,0]  R1395     -3.6128619313240051e-01
    z[3,10,0]  R1396     -4.2039236426353455e-01
    z[3,10,0]  R1397     -2.6028716564178467e-01
    z[3,10,0]  R1398     -5.2616310119628906e-01
    z[3,10,0]  R1399     -3.8607782125473022e-01
    z[3,10,0]  R1400     0.791607677936554
    z[3,10,0]  R1401     5.4138455539941788e-02
    z[3,10,0]  R1402     1.5371054410934448e-01
    z[3,10,0]  R1403     1.1704263836145401e-01
    z[3,10,0]  R1404     -4.8452970385551453e-01
    z[3,10,0]  R1405     9.5285169780254364e-02
    z[3,10,0]  R1406     1.9031725823879242e-01
    z[3,10,0]  R1407     -3.6664411425590515e-01
    z[3,10,0]  R1408     2.4678209424018860e-01
    z[3,10,0]  R1409     9.0622341632843018e-01
    z[3,10,0]  R1410     6.1857986450195312e-01
    z[3,10,0]  R1411     1.1635594815015793e-01
    z[3,10,0]  R1412     -1.5081866644322872e-02
    z[3,10,0]  R1413     -0.0322338342666626
    z[3,10,0]  R1414     -3.8929153233766556e-02
    z[3,10,0]  R1415     -2.8456223011016846e-01
    z[3,10,0]  R1416     -9.5431968569755554e-02
    z[3,10,0]  R1417     4.8519930243492126e-01
    z[3,10,0]  R1418     2.9040375351905823e-01
    z[3,10,0]  R1419     6.2423527240753174e-01
    z[3,10,0]  R1420     0.68561190366745
    z[3,10,0]  R1421     3.9377138018608093e-01
    z[3,10,0]  R1422     4.7939980030059814e-01
    z[3,10,0]  R1423     -1.3835345208644867e-01
    z[3,10,0]  R1424     -2.6231449842453003e-01
    z[3,10,0]  R1425     -8.1875901669263840e-03
    z[3,10,0]  R1426     -7.8163832426071167e-01
    z[3,10,0]  R1427     -4.8524963855743408e-01
    z[3,10,0]  R1428     7.1659278869628906e-01
    z[3,10,0]  R1429     4.5273523777723312e-02
    z[3,10,0]  R1430     -4.5310713350772858e-02
    z[3,10,0]  R1431     6.3448154926300049e-01
    z[3,10,0]  R1432     3.3574381470680237e-01
    z[3,10,0]  R1433     -7.6139461994171143e-01
    z[3,10,0]  R1434     -7.8718638420104980e-01
    z[3,10,0]  R1435     -5.9369087219238281e-01
    z[3,10,0]  R1436     -5.3711426258087158e-01
    z[3,10,0]  R1437     1.0929322987794876e-01
    z[3,10,0]  R1438     2.8275832533836365e-01
    z[3,10,0]  R1439     7.5258262455463409e-02
    z[3,10,0]  R1440     5.1826828718185425e-01
    z[3,10,0]  R1441     8.6387908458709717e-01
    z[3,10,0]  R1442     2.2995744645595551e-01
    z[3,10,0]  R1443     -4.4182431697845459e-01
    z[3,10,0]  R1444     -4.4682115316390991e-01
    z[3,10,0]  R1445     -2.6626887917518616e-01
    z[3,10,0]  R1446     -2.6983499526977539e-01
    z[3,10,0]  R1447     -2.8977537155151367e-01
    z[3,10,0]  R1448     1.8678304553031921e-01
    z[3,10,0]  R1449     1.8696199357509613e-01
    z[3,10,0]  R1450     3.3619109541177750e-02
    z[3,10,0]  R1451     5.5952310562133789e-01
    z[3,10,0]  R1452     9.2262578010559082e-01
    z[3,10,1]  R30       -1
    z[3,10,1]  R93       1
    z[3,10,1]  R1331     -1
    z[3,10,1]  R1332     1
    z[3,10,1]  R1343     -1.8147509545087814e-02
    z[3,10,1]  R1344     -2.6586961001157761e-02
    z[3,10,1]  R1345     0.00369931454770267
    z[3,10,1]  R1346     6.3879147171974182e-02
    z[3,10,1]  R1347     -1.9923512637615204e-01
    z[3,10,1]  R1348     -1.0005772858858109e-01
    z[3,10,1]  R1349     7.6027326285839081e-02
    z[3,10,1]  R1350     1.4623862504959106e-01
    z[3,10,1]  R1351     1.8217091262340546e-01
    z[3,10,1]  R1352     -1.3551914691925049e-01
    z[3,10,1]  R1353     -2.8927680850028992e-01
    z[3,10,1]  R1354     2.6945912837982178e-01
    z[3,10,1]  R1355     -2.3118519783020020e-01
    z[3,10,1]  R1356     5.8011960983276367e-01
    z[3,10,1]  R1357     2.3392921686172485e-01
    z[3,10,1]  R1358     7.2063136100769043e-01
    z[3,10,1]  R1359     2.6466074585914612e-01
    z[3,10,1]  R1360     7.8480696678161621e-01
    z[3,10,1]  R1361     5.6278330087661743e-01
    z[3,10,1]  R1362     3.4769752621650696e-01
    z[3,10,1]  R1363     5.1476502418518066e-01
    z[3,10,1]  R1364     4.7450292110443115e-01
    z[3,10,1]  R1365     4.6423131227493286e-01
    z[3,10,1]  R1366     3.0879806727170944e-02
    z[3,10,1]  R1367     7.7803015708923340e-01
    z[3,10,1]  R1368     -1.0528992861509323e-01
    z[3,10,1]  R1369     4.0154322981834412e-01
    z[3,10,1]  R1370     3.8039916753768921e-01
    z[3,10,1]  R1371     -3.7814763188362122e-01
    z[3,10,1]  R1372     5.5834829807281494e-01
    z[3,10,1]  R1373     7.5402897596359253e-01
    z[3,10,1]  R1374     4.1881687939167023e-02
    z[3,10,1]  R1375     5.8069932460784912e-01
    z[3,10,1]  R1376     0.658522367477417
    z[3,10,1]  R1377     5.2583056688308716e-01
    z[3,10,1]  R1378     4.9912261962890625e-01
    z[3,10,1]  R1379     5.3118276596069336e-01
    z[3,10,1]  R1380     4.6213954687118530e-01
    z[3,10,1]  R1381     6.0919177532196045e-01
    z[3,10,1]  R1382     -3.1659671664237976e-01
    z[3,10,1]  R1383     6.4564794301986694e-01
    z[3,10,1]  R1384     5.5827665328979492e-01
    z[3,10,1]  R1385     4.9820753931999207e-01
    z[3,10,1]  R1386     5.0807380676269531e-01
    z[3,10,1]  R1387     3.1307044625282288e-01
    z[3,10,1]  R1388     2.9546493291854858e-01
    z[3,10,1]  R1389     3.7226030230522156e-01
    z[3,10,1]  R1390     2.3870619013905525e-02
    z[3,10,1]  R1391     1.4187602698802948e-01
    z[3,10,1]  R1392     -2.5463572144508362e-01
    z[3,10,1]  R1393     8.2051777839660645e-01
    z[3,10,1]  R1394     7.2249752283096313e-01
    z[3,10,1]  R1395     -1.9844371825456619e-02
    z[3,10,1]  R1396     1.3561069965362549e-01
    z[3,10,1]  R1397     2.0917631685733795e-01
    z[3,10,1]  R1398     -3.0464905500411987e-01
    z[3,10,1]  R1399     -8.9196532964706421e-02
    z[3,10,1]  R1400     5.2294093370437622e-01
    z[3,10,1]  R1401     5.9315097332000732e-01
    z[3,10,1]  R1402     0.555571973323822
    z[3,10,1]  R1403     6.8589460849761963e-01
    z[3,10,1]  R1404     -0.271817684173584
    z[3,10,1]  R1405     7.6071041822433472e-01
    z[3,10,1]  R1406     6.5266501903533936e-01
    z[3,10,1]  R1407     -7.4946634471416473e-02
    z[3,10,1]  R1408     7.4575155973434448e-01
    z[3,10,1]  R1409     -3.2170295715332031e-02
    z[3,10,1]  R1410     -6.4777153730392456e-01
    z[3,10,1]  R1411     -6.4375817775726318e-01
    z[3,10,1]  R1412     -8.7924355268478394e-01
    z[3,10,1]  R1413     5.9495024383068085e-02
    z[3,10,1]  R1414     -1.7787255346775055e-01
    z[3,10,1]  R1415     -3.7116494774818420e-01
    z[3,10,1]  R1416     2.7456842362880707e-02
    z[3,10,1]  R1417     5.0318706035614014e-01
    z[3,10,1]  R1418     2.7592509984970093e-01
    z[3,10,1]  R1419     1.3301257789134979e-01
    z[3,10,1]  R1420     1.5204125642776489e-01
    z[3,10,1]  R1421     4.5381143689155579e-01
    z[3,10,1]  R1422     3.1715300679206848e-01
    z[3,10,1]  R1423     -5.4111443459987640e-02
    z[3,10,1]  R1424     -3.6944654583930969e-01
    z[3,10,1]  R1425     8.8989585638046265e-01
    z[3,10,1]  R1426     -1.0060093551874161e-01
    z[3,10,1]  R1427     4.9054840207099915e-01
    z[3,10,1]  R1428     -3.6201146245002747e-01
    z[3,10,1]  R1429     3.4500020742416382e-01
    z[3,10,1]  R1430     7.2072863578796387e-01
    z[3,10,1]  R1431     4.4959199428558350e-01
    z[3,10,1]  R1432     5.7441401481628418e-01
    z[3,10,1]  R1433     -1.9486187398433685e-01
    z[3,10,1]  R1434     2.4525374174118042e-01
    z[3,10,1]  R1435     5.0622463226318359e-01
    z[3,10,1]  R1436     -5.3992480039596558e-01
    z[3,10,1]  R1437     4.0347132086753845e-01
    z[3,10,1]  R1438     3.0033415555953979e-01
    z[3,10,1]  R1439     4.7502881288528442e-01
    z[3,10,1]  R1440     5.4198604822158813e-01
    z[3,10,1]  R1441     9.3117982149124146e-02
    z[3,10,1]  R1442     5.5350724607706070e-02
    z[3,10,1]  R1443     -6.3070565462112427e-01
    z[3,10,1]  R1444     0.666795015335083
    z[3,10,1]  R1445     2.4894419312477112e-01
    z[3,10,1]  R1446     5.1834475994110107e-01
    z[3,10,1]  R1447     0.744705855846405
    z[3,10,1]  R1448     0.777864396572113
    z[3,10,1]  R1449     4.4287830591201782e-01
    z[3,10,1]  R1450     3.9503553509712219e-01
    z[3,10,1]  R1451     4.4211441278457642e-01
    z[3,10,1]  R1452     -4.0771577507257462e-02
    z[3,10,2]  R31       -1
    z[3,10,2]  R94       1
    z[3,10,2]  R1333     -1
    z[3,10,2]  R1334     1
    z[3,10,2]  R1343     2.0380039513111115e-01
    z[3,10,2]  R1344     1.6424112021923065e-01
    z[3,10,2]  R1345     1.9458401203155518e-01
    z[3,10,2]  R1346     1.3415600359439850e-01
    z[3,10,2]  R1347     1.6791100800037384e-01
    z[3,10,2]  R1348     0.255410760641098
    z[3,10,2]  R1349     -3.5475820302963257e-01
    z[3,10,2]  R1350     -3.3877888321876526e-01
    z[3,10,2]  R1351     -6.6418254375457764e-01
    z[3,10,2]  R1352     -3.8884088397026062e-01
    z[3,10,2]  R1353     4.8751473426818848e-01
    z[3,10,2]  R1354     6.6513568162918091e-01
    z[3,10,2]  R1355     6.8369269371032715e-01
    z[3,10,2]  R1356     2.1148090064525604e-01
    z[3,10,2]  R1357     1.4423067867755890e-01
    z[3,10,2]  R1358     -2.1882466971874237e-01
    z[3,10,2]  R1359     0.378388911485672
    z[3,10,2]  R1360     -2.1996329724788666e-01
    z[3,10,2]  R1361     4.2632156610488892e-01
    z[3,10,2]  R1362     -2.0593171939253807e-02
    z[3,10,2]  R1363     -1.3001163303852081e-01
    z[3,10,2]  R1364     8.7742239236831665e-02
    z[3,10,2]  R1365     6.3745164871215820e-01
    z[3,10,2]  R1366     -2.4686776101589203e-01
    z[3,10,2]  R1367     -4.6482320874929428e-02
    z[3,10,2]  R1368     -5.6497758626937866e-01
    z[3,10,2]  R1369     -4.6835571527481079e-01
    z[3,10,2]  R1370     -2.2003506124019623e-01
    z[3,10,2]  R1371     -1.1988830566406250e-01
    z[3,10,2]  R1372     -1.6529999673366547e-01
    z[3,10,2]  R1373     -3.4255844354629517e-01
    z[3,10,2]  R1374     2.1844626963138580e-01
    z[3,10,2]  R1375     0.0618012435734272
    z[3,10,2]  R1376     -2.6322066783905029e-01
    z[3,10,2]  R1377     4.9342596530914307e-01
    z[3,10,2]  R1378     -2.3038223385810852e-01
    z[3,10,2]  R1379     -1.2890572845935822e-01
    z[3,10,2]  R1380     4.1803103685379028e-01
    z[3,10,2]  R1381     1.0757859796285629e-01
    z[3,10,2]  R1382     1.4735744893550873e-01
    z[3,10,2]  R1383     1.1390602588653564e-01
    z[3,10,2]  R1384     1.5017402172088623e-01
    z[3,10,2]  R1385     6.4315325021743774e-01
    z[3,10,2]  R1386     3.0384641885757446e-01
    z[3,10,2]  R1387     6.2764132022857666e-01
    z[3,10,2]  R1388     4.3027636408805847e-01
    z[3,10,2]  R1389     1.6781453788280487e-01
    z[3,10,2]  R1390     6.8919695913791656e-02
    z[3,10,2]  R1391     -6.2851980328559875e-02
    z[3,10,2]  R1392     -1.3999626040458679e-01
    z[3,10,2]  R1393     7.3459409177303314e-02
    z[3,10,2]  R1394     3.7138587236404419e-01
    z[3,10,2]  R1395     2.0932666957378387e-01
    z[3,10,2]  R1396     2.2971647977828979e-01
    z[3,10,2]  R1397     3.4135237336158752e-01
    z[3,10,2]  R1398     1.6996251046657562e-01
    z[3,10,2]  R1399     8.2678878307342529e-01
    z[3,10,2]  R1400     2.2051315754652023e-02
    z[3,10,2]  R1401     -6.0025709867477417e-01
    z[3,10,2]  R1402     1.9501638412475586e-01
    z[3,10,2]  R1403     4.6038147807121277e-01
    z[3,10,2]  R1404     3.8770639896392822e-01
    z[3,10,2]  R1405     -3.3164015412330627e-01
    z[3,10,2]  R1406     1.6177296638488770e-01
    z[3,10,2]  R1407     7.0908272266387939e-01
    z[3,10,2]  R1408     -0.51152503490448
    z[3,10,2]  R1409     7.7022803016006947e-03
    z[3,10,2]  R1410     -3.3185330033302307e-01
    z[3,10,2]  R1411     1.8339410424232483e-01
    z[3,10,2]  R1412     2.6918539777398109e-02
    z[3,10,2]  R1413     -0.724852442741394
    z[3,10,2]  R1414     -0.00740482984110713
    z[3,10,2]  R1415     -4.8283287882804871e-01
    z[3,10,2]  R1416     2.7693548798561096e-01
    z[3,10,2]  R1417     -3.0036973953247070e-01
    z[3,10,2]  R1418     -5.8482116460800171e-01
    z[3,10,2]  R1419     -4.4869095087051392e-01
    z[3,10,2]  R1420     -3.9584168791770935e-01
    z[3,10,2]  R1421     -3.1886133551597595e-01
    z[3,10,2]  R1422     -6.8888276815414429e-02
    z[3,10,2]  R1423     1.9236966967582703e-01
    z[3,10,2]  R1424     -2.3499862849712372e-01
    z[3,10,2]  R1425     -1.2824200093746185e-01
    z[3,10,2]  R1426     4.8321297764778137e-01
    z[3,10,2]  R1427     -4.0007346868515015e-01
    z[3,10,2]  R1428     -3.2211970537900925e-02
    z[3,10,2]  R1429     -2.3078870773315430e-01
    z[3,10,2]  R1430     4.5992609858512878e-01
    z[3,10,2]  R1431     3.2394322752952576e-01
    z[3,10,2]  R1432     1.2365873157978058e-01
    z[3,10,2]  R1433     5.4677021503448486e-01
    z[3,10,2]  R1434     -0.00409313291311264
    z[3,10,2]  R1435     4.9141440540552139e-02
    z[3,10,2]  R1436     -2.1499194204807281e-01
    z[3,10,2]  R1437     -4.8322245478630066e-01
    z[3,10,2]  R1438     -4.3023490905761719e-01
    z[3,10,2]  R1439     -3.2550308108329773e-01
    z[3,10,2]  R1440     -1.5176175534725189e-01
    z[3,10,2]  R1441     5.5523775517940521e-02
    z[3,10,2]  R1442     -5.1858407258987427e-01
    z[3,10,2]  R1443     4.1414242982864380e-01
    z[3,10,2]  R1444     -1.7898446321487427e-01
    z[3,10,2]  R1445     4.4153865426778793e-02
    z[3,10,2]  R1446     4.3548453599214554e-02
    z[3,10,2]  R1447     2.8381463885307312e-01
    z[3,10,2]  R1448     -3.0663815140724182e-01
    z[3,10,2]  R1449     -5.5600476264953613e-01
    z[3,10,2]  R1450     -6.0695797204971313e-01
    z[3,10,2]  R1451     -4.2058983445167542e-01
    z[3,10,2]  R1452     -1.8685944378376007e-02
    z[3,10,3]  R32       -1
    z[3,10,3]  R95       1
    z[3,10,3]  R1335     -1
    z[3,10,3]  R1336     1
    z[3,10,3]  R1343     -7.9531884193420410e-01
    z[3,10,3]  R1344     -2.1419633924961090e-01
    z[3,10,3]  R1345     -7.8271585702896118e-01
    z[3,10,3]  R1346     -0.861125111579895
    z[3,10,3]  R1347     -8.1278353929519653e-01
    z[3,10,3]  R1348     -1.5331903100013733e-01
    z[3,10,3]  R1349     7.7234938740730286e-02
    z[3,10,3]  R1350     6.7612268030643463e-02
    z[3,10,3]  R1351     2.5660252571105957e-01
    z[3,10,3]  R1352     -6.4098340272903442e-01
    z[3,10,3]  R1353     5.8287929743528366e-02
    z[3,10,3]  R1354     2.7959231287240982e-02
    z[3,10,3]  R1355     -1.0461293160915375e-01
    z[3,10,3]  R1356     1.8379074335098267e-01
    z[3,10,3]  R1357     1.5539652109146118e-01
    z[3,10,3]  R1358     4.1253589093685150e-02
    z[3,10,3]  R1359     -1.8871749937534332e-01
    z[3,10,3]  R1360     -4.9115356802940369e-01
    z[3,10,3]  R1361     -3.8400459289550781e-01
    z[3,10,3]  R1362     5.5019551515579224e-01
    z[3,10,3]  R1363     -3.8510710000991821e-01
    z[3,10,3]  R1364     -1.6262365877628326e-01
    z[3,10,3]  R1365     1.7351378500461578e-01
    z[3,10,3]  R1366     -8.0030553042888641e-02
    z[3,10,3]  R1367     -4.0627697110176086e-01
    z[3,10,3]  R1368     -3.0941897630691528e-01
    z[3,10,3]  R1369     1.0074589401483536e-01
    z[3,10,3]  R1370     -6.4366863807663321e-04
    z[3,10,3]  R1371     -0.552621603012085
    z[3,10,3]  R1372     5.6718343496322632e-01
    z[3,10,3]  R1373     2.0407845079898834e-01
    z[3,10,3]  R1374     -5.3206861019134521e-01
    z[3,10,3]  R1375     2.4289989471435547e-01
    z[3,10,3]  R1376     1.6189590096473694e-02
    z[3,10,3]  R1377     4.3716889619827271e-01
    z[3,10,3]  R1378     5.6508713960647583e-01
    z[3,10,3]  R1379     -0.0973648726940155
    z[3,10,3]  R1380     5.7831853628158569e-01
    z[3,10,3]  R1381     -6.6572129726409912e-02
    z[3,10,3]  R1382     -2.7399215102195740e-01
    z[3,10,3]  R1383     -6.6143953800201416e-01
    z[3,10,3]  R1384     4.1986754536628723e-01
    z[3,10,3]  R1385     -2.3869954049587250e-01
    z[3,10,3]  R1386     -3.1929448246955872e-01
    z[3,10,3]  R1387     -3.4203460812568665e-01
    z[3,10,3]  R1388     -2.7745443582534790e-01
    z[3,10,3]  R1389     -1.5969966351985931e-01
    z[3,10,3]  R1390     -2.3088859394192696e-02
    z[3,10,3]  R1391     1.9278062880039215e-01
    z[3,10,3]  R1392     -1.4659017324447632e-01
    z[3,10,3]  R1393     -1.0071203112602234e-02
    z[3,10,3]  R1394     -4.1415423154830933e-01
    z[3,10,3]  R1395     -8.4944957494735718e-01
    z[3,10,3]  R1396     -5.6782656908035278e-01
    z[3,10,3]  R1397     -5.3837972879409790e-01
    z[3,10,3]  R1398     -1.9293190538883209e-01
    z[3,10,3]  R1399     1.9563492387533188e-02
    z[3,10,3]  R1400     -1.4713719487190247e-01
    z[3,10,3]  R1401     3.4421697258949280e-01
    z[3,10,3]  R1402     6.0054361820220947e-01
    z[3,10,3]  R1403     -1.2486293166875839e-01
    z[3,10,3]  R1404     -5.4064434766769409e-01
    z[3,10,3]  R1405     3.0994030833244324e-01
    z[3,10,3]  R1406     -6.5386700630187988e-01
    z[3,10,3]  R1407     -2.6555222272872925e-01
    z[3,10,3]  R1408     2.4559656158089638e-02
    z[3,10,3]  R1409     -5.6275906972587109e-03
    z[3,10,3]  R1410     -1.1046132072806358e-02
    z[3,10,3]  R1411     5.8191090822219849e-01
    z[3,10,3]  R1412     4.4353199005126953e-01
    z[3,10,3]  R1413     -0.585458517074585
    z[3,10,3]  R1414     -5.2857035398483276e-01
    z[3,10,3]  R1415     -4.2818996310234070e-01
    z[3,10,3]  R1416     -8.7082099914550781e-01
    z[3,10,3]  R1417     2.9156097769737244e-01
    z[3,10,3]  R1418     4.1652080416679382e-01
    z[3,10,3]  R1419     1.2389941513538361e-01
    z[3,10,3]  R1420     2.0483785867691040e-01
    z[3,10,3]  R1421     5.9187458828091621e-03
    z[3,10,3]  R1422     1.0321240127086639e-01
    z[3,10,3]  R1423     5.7243430055677891e-03
    z[3,10,3]  R1424     5.3754359483718872e-01
    z[3,10,3]  R1425     1.8291927874088287e-01
    z[3,10,3]  R1426     2.3596415296196938e-02
    z[3,10,3]  R1427     4.3839433789253235e-01
    z[3,10,3]  R1428     -2.7212709188461304e-01
    z[3,10,3]  R1429     5.7946640253067017e-01
    z[3,10,3]  R1430     -0.231314554810524
    z[3,10,3]  R1431     -4.0604448318481445e-01
    z[3,10,3]  R1432     -2.2802665829658508e-01
    z[3,10,3]  R1433     1.3147830963134766e-01
    z[3,10,3]  R1434     2.5725081562995911e-01
    z[3,10,3]  R1435     5.6381557136774063e-02
    z[3,10,3]  R1436     3.9758530259132385e-01
    z[3,10,3]  R1437     7.1642249822616577e-01
    z[3,10,3]  R1438     6.4207404851913452e-01
    z[3,10,3]  R1439     4.8567295074462891e-01
    z[3,10,3]  R1440     6.1398875713348389e-01
    z[3,10,3]  R1441     1.0109191387891769e-01
    z[3,10,3]  R1442     0.778455913066864
    z[3,10,3]  R1443     -3.1388387084007263e-01
    z[3,10,3]  R1444     9.2800423502922058e-02
    z[3,10,3]  R1445     1.0242816060781479e-01
    z[3,10,3]  R1446     -1.6660006344318390e-01
    z[3,10,3]  R1447     -3.7849491834640503e-01
    z[3,10,3]  R1448     2.5698107481002808e-01
    z[3,10,3]  R1449     4.8226529359817505e-01
    z[3,10,3]  R1450     0.67186039686203
    z[3,10,3]  R1451     5.2164858579635620e-01
    z[3,10,3]  R1452     -1.0438710451126099e-01
    z[3,10,4]  R33       -1
    z[3,10,4]  R96       1
    z[3,10,4]  R1337     -1
    z[3,10,4]  R1338     1
    z[3,10,4]  R1343     4.5091444253921509e-01
    z[3,10,4]  R1344     3.5913035273551941e-01
    z[3,10,4]  R1345     -1.0920819640159607e-01
    z[3,10,4]  R1346     -1.9991688430309296e-01
    z[3,10,4]  R1347     -1.6100019216537476e-01
    z[3,10,4]  R1348     8.1068587303161621e-01
    z[3,10,4]  R1349     8.9609727263450623e-02
    z[3,10,4]  R1350     2.7591744065284729e-01
    z[3,10,4]  R1351     -0.0668027475476265
    z[3,10,4]  R1352     5.3418558835983276e-01
    z[3,10,4]  R1353     1.4315286278724670e-01
    z[3,10,4]  R1354     -4.9541953206062317e-01
    z[3,10,4]  R1355     -2.9208657145500183e-01
    z[3,10,4]  R1356     -1.8198199570178986e-01
    z[3,10,4]  R1357     1.9836862385272980e-01
    z[3,10,4]  R1358     -4.6531128883361816e-01
    z[3,10,4]  R1359     1.8763022124767303e-01
    z[3,10,4]  R1360     -1.1969381570816040e-01
    z[3,10,4]  R1361     -4.3034926056861877e-02
    z[3,10,4]  R1362     -3.5530057549476624e-01
    z[3,10,4]  R1363     3.1916370987892151e-01
    z[3,10,4]  R1364     1.7346268892288208e-01
    z[3,10,4]  R1365     3.7924036383628845e-01
    z[3,10,4]  R1366     -0.402294784784317
    z[3,10,4]  R1367     1.5069231390953064e-01
    z[3,10,4]  R1368     1.5406759083271027e-01
    z[3,10,4]  R1369     -2.8166621923446655e-01
    z[3,10,4]  R1370     -2.3513855040073395e-01
    z[3,10,4]  R1371     -8.8977195322513580e-02
    z[3,10,4]  R1372     2.2409638762474060e-01
    z[3,10,4]  R1373     0.154669389128685
    z[3,10,4]  R1374     -4.5688340067863464e-01
    z[3,10,4]  R1375     3.1223863363265991e-01
    z[3,10,4]  R1376     -6.3753414154052734e-01
    z[3,10,4]  R1377     3.0572861433029175e-02
    z[3,10,4]  R1378     1.2119908630847931e-01
    z[3,10,4]  R1379     0.698492169380188
    z[3,10,4]  R1380     -4.4865887612104416e-02
    z[3,10,4]  R1381     3.1009644269943237e-01
    z[3,10,4]  R1382     4.3205186724662781e-01
    z[3,10,4]  R1383     0.206967294216156
    z[3,10,4]  R1384     1.5200087428092957e-01
    z[3,10,4]  R1385     -0.355514258146286
    z[3,10,4]  R1386     -2.3040850460529327e-01
    z[3,10,4]  R1387     3.6587229371070862e-01
    z[3,10,4]  R1388     4.1439098119735718e-01
    z[3,10,4]  R1389     4.6595939993858337e-01
    z[3,10,4]  R1390     -3.7213604897260666e-02
    z[3,10,4]  R1391     -2.6540291309356689e-01
    z[3,10,4]  R1392     1.5093008987605572e-02
    z[3,10,4]  R1393     4.3244457244873047e-01
    z[3,10,4]  R1394     3.5639411211013794e-01
    z[3,10,4]  R1395     1.0726187378168106e-01
    z[3,10,4]  R1396     4.2680940032005310e-01
    z[3,10,4]  R1397     4.7016337513923645e-01
    z[3,10,4]  R1398     6.8323320150375366e-01
    z[3,10,4]  R1399     2.3376402258872986e-01
    z[3,10,4]  R1400     -6.5653212368488312e-02
    z[3,10,4]  R1401     1.4682777225971222e-01
    z[3,10,4]  R1402     -3.3612582087516785e-01
    z[3,10,4]  R1403     -4.4868391752243042e-01
    z[3,10,4]  R1404     3.8247746229171753e-01
    z[3,10,4]  R1405     -2.6561981439590454e-01
    z[3,10,4]  R1406     -2.7899253368377686e-01
    z[3,10,4]  R1407     -1.0250168852508068e-02
    z[3,10,4]  R1408     3.3220660686492920e-01
    z[3,10,4]  R1409     3.8770094513893127e-01
    z[3,10,4]  R1410     -1.7438489198684692e-01
    z[3,10,4]  R1411     -1.4591903984546661e-01
    z[3,10,4]  R1412     -1.5090203844010830e-02
    z[3,10,4]  R1413     -1.6976216435432434e-01
    z[3,10,4]  R1414     -4.0392079949378967e-01
    z[3,10,4]  R1415     0.598517656326294
    z[3,10,4]  R1416     1.3599993288516998e-01
    z[3,10,4]  R1417     4.9204263091087341e-01
    z[3,10,4]  R1418     1.4729213714599609e-01
    z[3,10,4]  R1419     6.0209494829177856e-01
    z[3,10,4]  R1420     4.2323696613311768e-01
    z[3,10,4]  R1421     4.7182390093803406e-01
    z[3,10,4]  R1422     -3.3233314752578735e-01
    z[3,10,4]  R1423     -5.8718425035476685e-01
    z[3,10,4]  R1424     -1.7536464333534241e-01
    z[3,10,4]  R1425     8.0129742622375488e-02
    z[3,10,4]  R1426     -2.6915794610977173e-01
    z[3,10,4]  R1427     1.4086230099201202e-01
    z[3,10,4]  R1428     3.5032492876052856e-01
    z[3,10,4]  R1429     -6.6820669174194336e-01
    z[3,10,4]  R1430     -4.1844749450683594e-01
    z[3,10,4]  R1431     -1.4110292494297028e-01
    z[3,10,4]  R1432     -4.7072374820709229e-01
    z[3,10,4]  R1433     1.8801175057888031e-01
    z[3,10,4]  R1434     1.6922098398208618e-01
    z[3,10,4]  R1435     -5.7497894763946533e-01
    z[3,10,4]  R1436     -4.0878134965896606e-01
    z[3,10,4]  R1437     -2.5134158134460449e-01
    z[3,10,4]  R1438     4.7637414932250977e-01
    z[3,10,4]  R1439     5.9170957654714584e-02
    z[3,10,4]  R1440     -1.1432316154241562e-01
    z[3,10,4]  R1441     3.2425925135612488e-01
    z[3,10,4]  R1442     -3.0830618925392628e-03
    z[3,10,4]  R1443     -3.5209706425666809e-01
    z[3,10,4]  R1444     -5.3375250101089478e-01
    z[3,10,4]  R1445     1.4306859672069550e-01
    z[3,10,4]  R1446     3.9614674448966980e-01
    z[3,10,4]  R1447     -8.5101991891860962e-02
    z[3,10,4]  R1448     4.0996676683425903e-01
    z[3,10,4]  R1449     3.1603109836578369e-01
    z[3,10,4]  R1450     7.8276596963405609e-02
    z[3,10,4]  R1451     -4.5020073652267456e-02
    z[3,10,4]  R1452     2.4737946689128876e-01
    z[3,10,5]  R34       -1
    z[3,10,5]  R97       1
    z[3,10,5]  R1339     -1
    z[3,10,5]  R1340     1
    z[3,10,5]  R1343     -2.4964088201522827e-01
    z[3,10,5]  R1344     -8.1494313478469849e-01
    z[3,10,5]  R1345     4.0266877412796021e-01
    z[3,10,5]  R1346     8.6275830864906311e-02
    z[3,10,5]  R1347     -6.1682611703872681e-02
    z[3,10,5]  R1348     -4.3264696002006531e-01
    z[3,10,5]  R1349     3.9988461136817932e-01
    z[3,10,5]  R1350     3.7383088469505310e-01
    z[3,10,5]  R1351     6.3645350933074951e-01
    z[3,10,5]  R1352     8.7714329361915588e-02
    z[3,10,5]  R1353     1.3221102952957153e-01
    z[3,10,5]  R1354     -9.0258710086345673e-02
    z[3,10,5]  R1355     1.4950045943260193e-01
    z[3,10,5]  R1356     1.0186498612165451e-01
    z[3,10,5]  R1357     -4.4034279882907867e-02
    z[3,10,5]  R1358     4.1084337234497070e-01
    z[3,10,5]  R1359     3.4483358263969421e-01
    z[3,10,5]  R1360     -2.2557886317372322e-02
    z[3,10,5]  R1361     3.2967728376388550e-01
    z[3,10,5]  R1362     5.1698958873748779e-01
    z[3,10,5]  R1363     -3.5127472877502441e-01
    z[3,10,5]  R1364     0.733608067035675
    z[3,10,5]  R1365     -2.3174121975898743e-01
    z[3,10,5]  R1366     -2.0580349862575531e-01
    z[3,10,5]  R1367     3.1133580207824707e-01
    z[3,10,5]  R1368     1.8946586549282074e-01
    z[3,10,5]  R1369     -4.0162327885627747e-01
    z[3,10,5]  R1370     -3.1405779719352722e-01
    z[3,10,5]  R1371     -3.9064630866050720e-02
    z[3,10,5]  R1372     -5.4667103104293346e-03
    z[3,10,5]  R1373     -8.8266089558601379e-02
    z[3,10,5]  R1374     -9.2325031757354736e-02
    z[3,10,5]  R1375     -1.6009141504764557e-01
    z[3,10,5]  R1376     -5.7933915406465530e-02
    z[3,10,5]  R1377     1.6093787550926208e-01
    z[3,10,5]  R1378     4.1721498966217041e-01
    z[3,10,5]  R1379     -9.5735192298889160e-02
    z[3,10,5]  R1380     2.5789514183998108e-01
    z[3,10,5]  R1381     -3.9667010307312012e-01
    z[3,10,5]  R1382     -3.6002573370933533e-01
    z[3,10,5]  R1383     -2.4313493072986603e-01
    z[3,10,5]  R1384     -7.2068810462951660e-02
    z[3,10,5]  R1385     1.2798270583152771e-01
    z[3,10,5]  R1386     -6.2841761112213135e-01
    z[3,10,5]  R1387     6.1056271195411682e-02
    z[3,10,5]  R1388     -1.8165180087089539e-01
    z[3,10,5]  R1389     5.8593624830245972e-01
    z[3,10,5]  R1390     3.5766917467117310e-01
    z[3,10,5]  R1391     5.3547525405883789e-01
    z[3,10,5]  R1392     4.1101586073637009e-02
    z[3,10,5]  R1393     1.0764109343290329e-01
    z[3,10,5]  R1394     -1.5185199677944183e-01
    z[3,10,5]  R1395     2.6983284950256348e-01
    z[3,10,5]  R1396     4.1258224844932556e-01
    z[3,10,5]  R1397     -2.1482808515429497e-02
    z[3,10,5]  R1398     -1.9362571835517883e-01
    z[3,10,5]  R1399     9.8400317132472992e-02
    z[3,10,5]  R1400     2.6339009404182434e-01
    z[3,10,5]  R1401     3.6060410737991333e-01
    z[3,10,5]  R1402     -3.3307597041130066e-01
    z[3,10,5]  R1403     9.8236635327339172e-02
    z[3,10,5]  R1404     2.1155847609043121e-01
    z[3,10,5]  R1405     3.4791359305381775e-01
    z[3,10,5]  R1406     3.7651412189006805e-02
    z[3,10,5]  R1407     -3.4793993830680847e-01
    z[3,10,5]  R1408     -1.0101927816867828e-01
    z[3,10,5]  R1409     1.5086345374584198e-01
    z[3,10,5]  R1410     1.3020054996013641e-01
    z[3,10,5]  R1411     -3.7766936421394348e-01
    z[3,10,5]  R1412     7.4742093682289124e-02
    z[3,10,5]  R1413     1.4835315942764282e-01
    z[3,10,5]  R1414     2.6637926697731018e-01
    z[3,10,5]  R1415     -2.7432022616267204e-02
    z[3,10,5]  R1416     3.6502219736576080e-02
    z[3,10,5]  R1417     -1.0321357101202011e-01
    z[3,10,5]  R1418     3.5617381334304810e-01
    z[3,10,5]  R1419     -7.1311786770820618e-02
    z[3,10,5]  R1420     2.9279375076293945e-01
    z[3,10,5]  R1421     -4.5880886912345886e-01
    z[3,10,5]  R1422     5.8623600006103516e-01
    z[3,10,5]  R1423     5.1523530483245850e-01
    z[3,10,5]  R1424     0.631995439529419
    z[3,10,5]  R1425     2.4163471162319183e-01
    z[3,10,5]  R1426     -0.213162362575531
    z[3,10,5]  R1427     -3.3033466339111328e-01
    z[3,10,5]  R1428     3.2594287395477295e-01
    z[3,10,5]  R1429     5.4186254739761353e-02
    z[3,10,5]  R1430     -1.5071900188922882e-01
    z[3,10,5]  R1431     -2.9552176594734192e-01
    z[3,10,5]  R1432     -4.7624596953392029e-01
    z[3,10,5]  R1433     -4.1224356740713120e-02
    z[3,10,5]  R1434     -1.0179454833269119e-01
    z[3,10,5]  R1435     -1.2646009027957916e-01
    z[3,10,5]  R1436     -2.1688570082187653e-01
    z[3,10,5]  R1437     1.2357288040220737e-02
    z[3,10,5]  R1438     -7.3192939162254333e-02
    z[3,10,5]  R1439     -3.3099305629730225e-01
    z[3,10,5]  R1440     1.2673702836036682e-01
    z[3,10,5]  R1441     -1.1368635110557079e-02
    z[3,10,5]  R1442     1.4075355231761932e-01
    z[3,10,5]  R1443     -8.0980204045772552e-02
    z[3,10,5]  R1444     -1.8685216084122658e-02
    z[3,10,5]  R1445     8.7871748208999634e-01
    z[3,10,5]  R1446     5.2634340524673462e-01
    z[3,10,5]  R1447     2.1733374893665314e-01
    z[3,10,5]  R1448     4.6922564506530762e-02
    z[3,10,5]  R1449     1.9103546440601349e-01
    z[3,10,5]  R1450     6.2783464789390564e-02
    z[3,10,5]  R1451     1.5240314602851868e-01
    z[3,10,5]  R1452     2.6976841688156128e-01
    z[3,10,6]  R35       -1
    z[3,10,6]  R98       1
    z[3,10,6]  R1341     -1
    z[3,10,6]  R1342     1
    z[3,10,6]  R1343     2.3448066413402557e-01
    z[3,10,6]  R1344     2.1293486654758453e-01
    z[3,10,6]  R1345     4.0058061480522156e-01
    z[3,10,6]  R1346     4.3068426847457886e-01
    z[3,10,6]  R1347     0.484515517950058
    z[3,10,6]  R1348     -1.4090597629547119e-01
    z[3,10,6]  R1349     -1.5417706966400146e-01
    z[3,10,6]  R1350     1.3927669823169708e-01
    z[3,10,6]  R1351     -1.7149336636066437e-01
    z[3,10,6]  R1352     1.0915964841842651e-01
    z[3,10,6]  R1353     -2.4677093327045441e-01
    z[3,10,6]  R1354     1.9186499714851379e-01
    z[3,10,6]  R1355     -3.8098847866058350e-01
    z[3,10,6]  R1356     -5.7603371143341064e-01
    z[3,10,6]  R1357     -6.2416213750839233e-01
    z[3,10,6]  R1358     -1.0772877931594849e-01
    z[3,10,6]  R1359     -6.9624620676040649e-01
    z[3,10,6]  R1360     -8.2980375736951828e-03
    z[3,10,6]  R1361     -4.0678212046623230e-01
    z[3,10,6]  R1362     -6.9660849869251251e-02
    z[3,10,6]  R1363     0.0590716190636158
    z[3,10,6]  R1364     -8.8420487940311432e-02
    z[3,10,6]  R1365     3.7266305088996887e-01
    z[3,10,6]  R1366     1.9456608593463898e-01
    z[3,10,6]  R1367     -2.7480429410934448e-01
    z[3,10,6]  R1368     3.1899476051330566e-01
    z[3,10,6]  R1369     5.9696954488754272e-01
    z[3,10,6]  R1370     7.8890842199325562e-01
    z[3,10,6]  R1371     0.251801997423172
    z[3,10,6]  R1372     -2.5877025723457336e-01
    z[3,10,6]  R1373     4.9064162373542786e-01
    z[3,10,6]  R1374     5.5366568267345428e-02
    z[3,10,6]  R1375     2.2685837745666504e-01
    z[3,10,6]  R1376     2.8735220432281494e-01
    z[3,10,6]  R1377     -3.4319585561752319e-01
    z[3,10,6]  R1378     -5.3683228790760040e-02
    z[3,10,6]  R1379     -0.34941366314888
    z[3,10,6]  R1380     4.4143715500831604e-01
    z[3,10,6]  R1381     -1.0558591037988663e-01
    z[3,10,6]  R1382     -0.243662029504776
    z[3,10,6]  R1383     -7.3637999594211578e-02
    z[3,10,6]  R1384     -1.6427341103553772e-01
    z[3,10,6]  R1385     2.0980919897556305e-01
    z[3,10,6]  R1386     1.6063556075096130e-01
    z[3,10,6]  R1387     -5.0175631046295166e-01
    z[3,10,6]  R1388     -6.1454075574874878e-01
    z[3,10,6]  R1389     -2.1731488406658173e-01
    z[3,10,6]  R1390     7.3154765367507935e-01
    z[3,10,6]  R1391     1.5326510369777679e-01
    z[3,10,6]  R1392     5.3874832391738892e-01
    z[3,10,6]  R1393     -3.0045926570892334e-01
    z[3,10,6]  R1394     0.0719318613409996
    z[3,10,6]  R1395     1.3921739161014557e-01
    z[3,10,6]  R1396     -0.278016060590744
    z[3,10,6]  R1397     -5.1049643754959106e-01
    z[3,10,6]  R1398     -0.24481201171875
    z[3,10,6]  R1399     3.0772894620895386e-01
    z[3,10,6]  R1400     6.3795872032642365e-02
    z[3,10,6]  R1401     -1.2187448143959045e-01
    z[3,10,6]  R1402     -2.1238806843757629e-01
    z[3,10,6]  R1403     2.7810081839561462e-01
    z[3,10,6]  R1404     -2.4018239974975586e-01
    z[3,10,6]  R1405     -1.2080726772546768e-01
    z[3,10,6]  R1406     6.9574706256389618e-02
    z[3,10,6]  R1407     -4.0678188204765320e-01
    z[3,10,6]  R1408     1.1225664988160133e-02
    z[3,10,6]  R1409     6.7537270486354828e-02
    z[3,10,6]  R1410     -2.0034988224506378e-01
    z[3,10,6]  R1411     1.8935823440551758e-01
    z[3,10,6]  R1412     1.5311431884765625e-01
    z[3,10,6]  R1413     2.7644306421279907e-01
    z[3,10,6]  R1414     6.7327147722244263e-01
    z[3,10,6]  R1415     -7.6228022575378418e-02
    z[3,10,6]  R1416     3.6781498789787292e-01
    z[3,10,6]  R1417     2.8878265619277954e-01
    z[3,10,6]  R1418     -4.1889244318008423e-01
    z[3,10,6]  R1419     -9.1430976986885071e-02
    z[3,10,6]  R1420     -2.0811778306961060e-01
    z[3,10,6]  R1421     -3.2275122404098511e-01
    z[3,10,6]  R1422     -4.4729572534561157e-01
    z[3,10,6]  R1423     -5.7501184940338135e-01
    z[3,10,6]  R1424     -1.4265993237495422e-01
    z[3,10,6]  R1425     -3.0545833706855774e-01
    z[3,10,6]  R1426     -1.6427166759967804e-01
    z[3,10,6]  R1427     2.0659960806369781e-01
    z[3,10,6]  R1428     -2.2668333351612091e-01
    z[3,10,6]  R1429     2.0110729336738586e-01
    z[3,10,6]  R1430     1.2507688999176025e-01
    z[3,10,6]  R1431     -1.3507668673992157e-01
    z[3,10,6]  R1432     -2.0407313108444214e-01
    z[3,10,6]  R1433     1.7033822834491730e-01
    z[3,10,6]  R1434     -4.6367627382278442e-01
    z[3,10,6]  R1435     0.197689488530159
    z[3,10,6]  R1436     3.9398968219757080e-02
    z[3,10,6]  R1437     1.2318865209817886e-01
    z[3,10,6]  R1438     -1.4014187268912792e-02
    z[3,10,6]  R1439     5.6017464399337769e-01
    z[3,10,6]  R1440     9.2212647199630737e-02
    z[3,10,6]  R1441     3.5562083125114441e-01
    z[3,10,6]  R1442     -2.2206236422061920e-01
    z[3,10,6]  R1443     -8.0214828252792358e-02
    z[3,10,6]  R1444     1.7276298999786377e-01
    z[3,10,6]  R1445     2.4914576113224030e-01
    z[3,10,6]  R1446     -4.4145914912223816e-01
    z[3,10,6]  R1447     -2.8837126493453979e-01
    z[3,10,6]  R1448     1.7233215272426605e-01
    z[3,10,6]  R1449     -3.0135154724121094e-01
    z[3,10,6]  R1450     -1.1381273716688156e-01
    z[3,10,6]  R1451     1.3115748763084412e-01
    z[3,10,6]  R1452     4.3380558490753174e-02
    z[10,3,0]  R29       1
    z[10,3,0]  R92       -1
    z[10,3,0]  R1453     -1
    z[10,3,0]  R1454     1
    z[10,3,0]  R1467     -0.0322338342666626
    z[10,3,0]  R1468     -3.8929153233766556e-02
    z[10,3,0]  R1469     -2.8456223011016846e-01
    z[10,3,0]  R1470     -9.5431968569755554e-02
    z[10,3,0]  R1471     4.8519930243492126e-01
    z[10,3,0]  R1472     2.9040375351905823e-01
    z[10,3,0]  R1473     6.2423527240753174e-01
    z[10,3,0]  R1474     0.68561190366745
    z[10,3,0]  R1475     3.9377138018608093e-01
    z[10,3,0]  R1476     4.7939980030059814e-01
    z[10,3,0]  R1477     -1.3835345208644867e-01
    z[10,3,0]  R1478     -2.6231449842453003e-01
    z[10,3,0]  R1479     -8.1875901669263840e-03
    z[10,3,0]  R1480     -7.8163832426071167e-01
    z[10,3,0]  R1481     -4.8524963855743408e-01
    z[10,3,0]  R1482     7.1659278869628906e-01
    z[10,3,0]  R1483     4.5273523777723312e-02
    z[10,3,0]  R1484     -4.5310713350772858e-02
    z[10,3,0]  R1485     6.3448154926300049e-01
    z[10,3,0]  R1486     3.3574381470680237e-01
    z[10,3,0]  R1487     -7.6139461994171143e-01
    z[10,3,0]  R1488     -7.8718638420104980e-01
    z[10,3,0]  R1489     -5.9369087219238281e-01
    z[10,3,0]  R1490     -5.3711426258087158e-01
    z[10,3,0]  R1491     1.0929322987794876e-01
    z[10,3,0]  R1492     2.8275832533836365e-01
    z[10,3,0]  R1493     7.5258262455463409e-02
    z[10,3,0]  R1494     5.1826828718185425e-01
    z[10,3,0]  R1495     8.6387908458709717e-01
    z[10,3,0]  R1496     2.2995744645595551e-01
    z[10,3,0]  R1497     -4.4182431697845459e-01
    z[10,3,0]  R1498     -4.4682115316390991e-01
    z[10,3,0]  R1499     -2.6626887917518616e-01
    z[10,3,0]  R1500     -2.6983499526977539e-01
    z[10,3,0]  R1501     -2.8977537155151367e-01
    z[10,3,0]  R1502     1.8678304553031921e-01
    z[10,3,0]  R1503     1.8696199357509613e-01
    z[10,3,0]  R1504     3.3619109541177750e-02
    z[10,3,0]  R1505     5.5952310562133789e-01
    z[10,3,0]  R1506     9.2262578010559082e-01
    z[10,3,0]  R1507     -7.0556834340095520e-02
    z[10,3,0]  R1508     -2.9663050174713135e-01
    z[10,3,0]  R1509     -1.2225360423326492e-01
    z[10,3,0]  R1510     -5.9042003005743027e-02
    z[10,3,0]  R1511     -0.0837436318397522
    z[10,3,0]  R1512     -1.9234749674797058e-01
    z[10,3,0]  R1513     8.1895852088928223e-01
    z[10,3,0]  R1514     7.8993266820907593e-01
    z[10,3,0]  R1515     1.4451588690280914e-01
    z[10,3,0]  R1516     -3.3854654431343079e-01
    z[10,3,0]  R1517     -7.5919860601425171e-01
    z[10,3,0]  R1518     -4.4023331999778748e-01
    z[10,3,0]  R1519     -4.6406522393226624e-01
    z[10,3,0]  R1520     -4.5787465572357178e-01
    z[10,3,0]  R1521     -6.8517088890075684e-01
    z[10,3,0]  R1522     -1.8491105735301971e-01
    z[10,3,0]  R1523     -3.3509409427642822e-01
    z[10,3,0]  R1524     -2.8206023573875427e-01
    z[10,3,0]  R1525     2.7938228845596313e-01
    z[10,3,0]  R1526     -4.2142361402511597e-01
    z[10,3,0]  R1527     -0.584001362323761
    z[10,3,0]  R1528     4.0572577714920044e-01
    z[10,3,0]  R1529     1.0785473138093948e-01
    z[10,3,0]  R1530     -0.830449104309082
    z[10,3,0]  R1531     1.7969982326030731e-01
    z[10,3,0]  R1532     -0.642325758934021
    z[10,3,0]  R1533     1.1066393554210663e-01
    z[10,3,0]  R1534     -1.7487633228302002e-01
    z[10,3,0]  R1535     -6.8146413564682007e-01
    z[10,3,0]  R1536     4.7118470072746277e-01
    z[10,3,0]  R1537     -1.8216333119198680e-03
    z[10,3,0]  R1538     -6.6865408420562744e-01
    z[10,3,0]  R1539     6.5221273899078369e-01
    z[10,3,0]  R1540     -6.6511653363704681e-02
    z[10,3,0]  R1541     3.7986478209495544e-01
    z[10,3,0]  R1542     -4.3224725127220154e-01
    z[10,3,0]  R1543     2.6944720745086670e-01
    z[10,3,0]  R1544     -1.1762320250272751e-01
    z[10,3,0]  R1545     5.9010595083236694e-01
    z[10,3,0]  R1546     -6.5369868278503418e-01
    z[10,3,0]  R1547     1.5902586281299591e-01
    z[10,3,0]  R1548     -6.5894013643264771e-01
    z[10,3,0]  R1549     3.0720660090446472e-01
    z[10,3,0]  R1550     2.7164104580879211e-01
    z[10,3,0]  R1551     -4.1422676295042038e-02
    z[10,3,0]  R1552     -2.6115933060646057e-01
    z[10,3,0]  R1553     -4.4731575250625610e-01
    z[10,3,0]  R1554     -5.7417166233062744e-01
    z[10,3,0]  R1555     0.747056782245636
    z[10,3,0]  R1556     0.775826096534729
    z[10,3,0]  R1557     -1.7995016276836395e-01
    z[10,3,0]  R1558     1.1530910432338715e-01
    z[10,3,0]  R1559     -3.6128619313240051e-01
    z[10,3,0]  R1560     -4.2039236426353455e-01
    z[10,3,0]  R1561     -2.6028716564178467e-01
    z[10,3,0]  R1562     -5.2616310119628906e-01
    z[10,3,0]  R1563     -3.8607782125473022e-01
    z[10,3,0]  R1564     0.791607677936554
    z[10,3,0]  R1565     5.4138455539941788e-02
    z[10,3,0]  R1566     1.5371054410934448e-01
    z[10,3,0]  R1567     1.1704263836145401e-01
    z[10,3,0]  R1568     -4.8452970385551453e-01
    z[10,3,0]  R1569     9.5285169780254364e-02
    z[10,3,0]  R1570     1.9031725823879242e-01
    z[10,3,0]  R1571     -3.6664411425590515e-01
    z[10,3,0]  R1572     2.4678209424018860e-01
    z[10,3,0]  R1573     9.0622341632843018e-01
    z[10,3,0]  R1574     6.1857986450195312e-01
    z[10,3,0]  R1575     1.1635594815015793e-01
    z[10,3,0]  R1576     -1.5081866644322872e-02
    z[10,3,1]  R30       1
    z[10,3,1]  R93       -1
    z[10,3,1]  R1455     -1
    z[10,3,1]  R1456     1
    z[10,3,1]  R1467     5.9495024383068085e-02
    z[10,3,1]  R1468     -1.7787255346775055e-01
    z[10,3,1]  R1469     -3.7116494774818420e-01
    z[10,3,1]  R1470     2.7456842362880707e-02
    z[10,3,1]  R1471     5.0318706035614014e-01
    z[10,3,1]  R1472     2.7592509984970093e-01
    z[10,3,1]  R1473     1.3301257789134979e-01
    z[10,3,1]  R1474     1.5204125642776489e-01
    z[10,3,1]  R1475     4.5381143689155579e-01
    z[10,3,1]  R1476     3.1715300679206848e-01
    z[10,3,1]  R1477     -5.4111443459987640e-02
    z[10,3,1]  R1478     -3.6944654583930969e-01
    z[10,3,1]  R1479     8.8989585638046265e-01
    z[10,3,1]  R1480     -1.0060093551874161e-01
    z[10,3,1]  R1481     4.9054840207099915e-01
    z[10,3,1]  R1482     -3.6201146245002747e-01
    z[10,3,1]  R1483     3.4500020742416382e-01
    z[10,3,1]  R1484     7.2072863578796387e-01
    z[10,3,1]  R1485     4.4959199428558350e-01
    z[10,3,1]  R1486     5.7441401481628418e-01
    z[10,3,1]  R1487     -1.9486187398433685e-01
    z[10,3,1]  R1488     2.4525374174118042e-01
    z[10,3,1]  R1489     5.0622463226318359e-01
    z[10,3,1]  R1490     -5.3992480039596558e-01
    z[10,3,1]  R1491     4.0347132086753845e-01
    z[10,3,1]  R1492     3.0033415555953979e-01
    z[10,3,1]  R1493     4.7502881288528442e-01
    z[10,3,1]  R1494     5.4198604822158813e-01
    z[10,3,1]  R1495     9.3117982149124146e-02
    z[10,3,1]  R1496     5.5350724607706070e-02
    z[10,3,1]  R1497     -6.3070565462112427e-01
    z[10,3,1]  R1498     0.666795015335083
    z[10,3,1]  R1499     2.4894419312477112e-01
    z[10,3,1]  R1500     5.1834475994110107e-01
    z[10,3,1]  R1501     0.744705855846405
    z[10,3,1]  R1502     0.777864396572113
    z[10,3,1]  R1503     4.4287830591201782e-01
    z[10,3,1]  R1504     3.9503553509712219e-01
    z[10,3,1]  R1505     4.4211441278457642e-01
    z[10,3,1]  R1506     -4.0771577507257462e-02
    z[10,3,1]  R1507     -1.8147509545087814e-02
    z[10,3,1]  R1508     -2.6586961001157761e-02
    z[10,3,1]  R1509     0.00369931454770267
    z[10,3,1]  R1510     6.3879147171974182e-02
    z[10,3,1]  R1511     -1.9923512637615204e-01
    z[10,3,1]  R1512     -1.0005772858858109e-01
    z[10,3,1]  R1513     7.6027326285839081e-02
    z[10,3,1]  R1514     1.4623862504959106e-01
    z[10,3,1]  R1515     1.8217091262340546e-01
    z[10,3,1]  R1516     -1.3551914691925049e-01
    z[10,3,1]  R1517     -2.8927680850028992e-01
    z[10,3,1]  R1518     2.6945912837982178e-01
    z[10,3,1]  R1519     -2.3118519783020020e-01
    z[10,3,1]  R1520     5.8011960983276367e-01
    z[10,3,1]  R1521     2.3392921686172485e-01
    z[10,3,1]  R1522     7.2063136100769043e-01
    z[10,3,1]  R1523     2.6466074585914612e-01
    z[10,3,1]  R1524     7.8480696678161621e-01
    z[10,3,1]  R1525     5.6278330087661743e-01
    z[10,3,1]  R1526     3.4769752621650696e-01
    z[10,3,1]  R1527     5.1476502418518066e-01
    z[10,3,1]  R1528     4.7450292110443115e-01
    z[10,3,1]  R1529     4.6423131227493286e-01
    z[10,3,1]  R1530     3.0879806727170944e-02
    z[10,3,1]  R1531     7.7803015708923340e-01
    z[10,3,1]  R1532     -1.0528992861509323e-01
    z[10,3,1]  R1533     4.0154322981834412e-01
    z[10,3,1]  R1534     3.8039916753768921e-01
    z[10,3,1]  R1535     -3.7814763188362122e-01
    z[10,3,1]  R1536     5.5834829807281494e-01
    z[10,3,1]  R1537     7.5402897596359253e-01
    z[10,3,1]  R1538     4.1881687939167023e-02
    z[10,3,1]  R1539     5.8069932460784912e-01
    z[10,3,1]  R1540     0.658522367477417
    z[10,3,1]  R1541     5.2583056688308716e-01
    z[10,3,1]  R1542     4.9912261962890625e-01
    z[10,3,1]  R1543     5.3118276596069336e-01
    z[10,3,1]  R1544     4.6213954687118530e-01
    z[10,3,1]  R1545     6.0919177532196045e-01
    z[10,3,1]  R1546     -3.1659671664237976e-01
    z[10,3,1]  R1547     6.4564794301986694e-01
    z[10,3,1]  R1548     5.5827665328979492e-01
    z[10,3,1]  R1549     4.9820753931999207e-01
    z[10,3,1]  R1550     5.0807380676269531e-01
    z[10,3,1]  R1551     3.1307044625282288e-01
    z[10,3,1]  R1552     2.9546493291854858e-01
    z[10,3,1]  R1553     3.7226030230522156e-01
    z[10,3,1]  R1554     2.3870619013905525e-02
    z[10,3,1]  R1555     1.4187602698802948e-01
    z[10,3,1]  R1556     -2.5463572144508362e-01
    z[10,3,1]  R1557     8.2051777839660645e-01
    z[10,3,1]  R1558     7.2249752283096313e-01
    z[10,3,1]  R1559     -1.9844371825456619e-02
    z[10,3,1]  R1560     1.3561069965362549e-01
    z[10,3,1]  R1561     2.0917631685733795e-01
    z[10,3,1]  R1562     -3.0464905500411987e-01
    z[10,3,1]  R1563     -8.9196532964706421e-02
    z[10,3,1]  R1564     5.2294093370437622e-01
    z[10,3,1]  R1565     5.9315097332000732e-01
    z[10,3,1]  R1566     0.555571973323822
    z[10,3,1]  R1567     6.8589460849761963e-01
    z[10,3,1]  R1568     -0.271817684173584
    z[10,3,1]  R1569     7.6071041822433472e-01
    z[10,3,1]  R1570     6.5266501903533936e-01
    z[10,3,1]  R1571     -7.4946634471416473e-02
    z[10,3,1]  R1572     7.4575155973434448e-01
    z[10,3,1]  R1573     -3.2170295715332031e-02
    z[10,3,1]  R1574     -6.4777153730392456e-01
    z[10,3,1]  R1575     -6.4375817775726318e-01
    z[10,3,1]  R1576     -8.7924355268478394e-01
    z[10,3,2]  R31       1
    z[10,3,2]  R94       -1
    z[10,3,2]  R1457     -1
    z[10,3,2]  R1458     1
    z[10,3,2]  R1467     -0.724852442741394
    z[10,3,2]  R1468     -0.00740482984110713
    z[10,3,2]  R1469     -4.8283287882804871e-01
    z[10,3,2]  R1470     2.7693548798561096e-01
    z[10,3,2]  R1471     -3.0036973953247070e-01
    z[10,3,2]  R1472     -5.8482116460800171e-01
    z[10,3,2]  R1473     -4.4869095087051392e-01
    z[10,3,2]  R1474     -3.9584168791770935e-01
    z[10,3,2]  R1475     -3.1886133551597595e-01
    z[10,3,2]  R1476     -6.8888276815414429e-02
    z[10,3,2]  R1477     1.9236966967582703e-01
    z[10,3,2]  R1478     -2.3499862849712372e-01
    z[10,3,2]  R1479     -1.2824200093746185e-01
    z[10,3,2]  R1480     4.8321297764778137e-01
    z[10,3,2]  R1481     -4.0007346868515015e-01
    z[10,3,2]  R1482     -3.2211970537900925e-02
    z[10,3,2]  R1483     -2.3078870773315430e-01
    z[10,3,2]  R1484     4.5992609858512878e-01
    z[10,3,2]  R1485     3.2394322752952576e-01
    z[10,3,2]  R1486     1.2365873157978058e-01
    z[10,3,2]  R1487     5.4677021503448486e-01
    z[10,3,2]  R1488     -0.00409313291311264
    z[10,3,2]  R1489     4.9141440540552139e-02
    z[10,3,2]  R1490     -2.1499194204807281e-01
    z[10,3,2]  R1491     -4.8322245478630066e-01
    z[10,3,2]  R1492     -4.3023490905761719e-01
    z[10,3,2]  R1493     -3.2550308108329773e-01
    z[10,3,2]  R1494     -1.5176175534725189e-01
    z[10,3,2]  R1495     5.5523775517940521e-02
    z[10,3,2]  R1496     -5.1858407258987427e-01
    z[10,3,2]  R1497     4.1414242982864380e-01
    z[10,3,2]  R1498     -1.7898446321487427e-01
    z[10,3,2]  R1499     4.4153865426778793e-02
    z[10,3,2]  R1500     4.3548453599214554e-02
    z[10,3,2]  R1501     2.8381463885307312e-01
    z[10,3,2]  R1502     -3.0663815140724182e-01
    z[10,3,2]  R1503     -5.5600476264953613e-01
    z[10,3,2]  R1504     -6.0695797204971313e-01
    z[10,3,2]  R1505     -4.2058983445167542e-01
    z[10,3,2]  R1506     -1.8685944378376007e-02
    z[10,3,2]  R1507     2.0380039513111115e-01
    z[10,3,2]  R1508     1.6424112021923065e-01
    z[10,3,2]  R1509     1.9458401203155518e-01
    z[10,3,2]  R1510     1.3415600359439850e-01
    z[10,3,2]  R1511     1.6791100800037384e-01
    z[10,3,2]  R1512     0.255410760641098
    z[10,3,2]  R1513     -3.5475820302963257e-01
    z[10,3,2]  R1514     -3.3877888321876526e-01
    z[10,3,2]  R1515     -6.6418254375457764e-01
    z[10,3,2]  R1516     -3.8884088397026062e-01
    z[10,3,2]  R1517     4.8751473426818848e-01
    z[10,3,2]  R1518     6.6513568162918091e-01
    z[10,3,2]  R1519     6.8369269371032715e-01
    z[10,3,2]  R1520     2.1148090064525604e-01
    z[10,3,2]  R1521     1.4423067867755890e-01
    z[10,3,2]  R1522     -2.1882466971874237e-01
    z[10,3,2]  R1523     0.378388911485672
    z[10,3,2]  R1524     -2.1996329724788666e-01
    z[10,3,2]  R1525     4.2632156610488892e-01
    z[10,3,2]  R1526     -2.0593171939253807e-02
    z[10,3,2]  R1527     -1.3001163303852081e-01
    z[10,3,2]  R1528     8.7742239236831665e-02
    z[10,3,2]  R1529     6.3745164871215820e-01
    z[10,3,2]  R1530     -2.4686776101589203e-01
    z[10,3,2]  R1531     -4.6482320874929428e-02
    z[10,3,2]  R1532     -5.6497758626937866e-01
    z[10,3,2]  R1533     -4.6835571527481079e-01
    z[10,3,2]  R1534     -2.2003506124019623e-01
    z[10,3,2]  R1535     -1.1988830566406250e-01
    z[10,3,2]  R1536     -1.6529999673366547e-01
    z[10,3,2]  R1537     -3.4255844354629517e-01
    z[10,3,2]  R1538     2.1844626963138580e-01
    z[10,3,2]  R1539     0.0618012435734272
    z[10,3,2]  R1540     -2.6322066783905029e-01
    z[10,3,2]  R1541     4.9342596530914307e-01
    z[10,3,2]  R1542     -2.3038223385810852e-01
    z[10,3,2]  R1543     -1.2890572845935822e-01
    z[10,3,2]  R1544     4.1803103685379028e-01
    z[10,3,2]  R1545     1.0757859796285629e-01
    z[10,3,2]  R1546     1.4735744893550873e-01
    z[10,3,2]  R1547     1.1390602588653564e-01
    z[10,3,2]  R1548     1.5017402172088623e-01
    z[10,3,2]  R1549     6.4315325021743774e-01
    z[10,3,2]  R1550     3.0384641885757446e-01
    z[10,3,2]  R1551     6.2764132022857666e-01
    z[10,3,2]  R1552     4.3027636408805847e-01
    z[10,3,2]  R1553     1.6781453788280487e-01
    z[10,3,2]  R1554     6.8919695913791656e-02
    z[10,3,2]  R1555     -6.2851980328559875e-02
    z[10,3,2]  R1556     -1.3999626040458679e-01
    z[10,3,2]  R1557     7.3459409177303314e-02
    z[10,3,2]  R1558     3.7138587236404419e-01
    z[10,3,2]  R1559     2.0932666957378387e-01
    z[10,3,2]  R1560     2.2971647977828979e-01
    z[10,3,2]  R1561     3.4135237336158752e-01
    z[10,3,2]  R1562     1.6996251046657562e-01
    z[10,3,2]  R1563     8.2678878307342529e-01
    z[10,3,2]  R1564     2.2051315754652023e-02
    z[10,3,2]  R1565     -6.0025709867477417e-01
    z[10,3,2]  R1566     1.9501638412475586e-01
    z[10,3,2]  R1567     4.6038147807121277e-01
    z[10,3,2]  R1568     3.8770639896392822e-01
    z[10,3,2]  R1569     -3.3164015412330627e-01
    z[10,3,2]  R1570     1.6177296638488770e-01
    z[10,3,2]  R1571     7.0908272266387939e-01
    z[10,3,2]  R1572     -0.51152503490448
    z[10,3,2]  R1573     7.7022803016006947e-03
    z[10,3,2]  R1574     -3.3185330033302307e-01
    z[10,3,2]  R1575     1.8339410424232483e-01
    z[10,3,2]  R1576     2.6918539777398109e-02
    z[10,3,3]  R32       1
    z[10,3,3]  R95       -1
    z[10,3,3]  R1459     -1
    z[10,3,3]  R1460     1
    z[10,3,3]  R1467     -0.585458517074585
    z[10,3,3]  R1468     -5.2857035398483276e-01
    z[10,3,3]  R1469     -4.2818996310234070e-01
    z[10,3,3]  R1470     -8.7082099914550781e-01
    z[10,3,3]  R1471     2.9156097769737244e-01
    z[10,3,3]  R1472     4.1652080416679382e-01
    z[10,3,3]  R1473     1.2389941513538361e-01
    z[10,3,3]  R1474     2.0483785867691040e-01
    z[10,3,3]  R1475     5.9187458828091621e-03
    z[10,3,3]  R1476     1.0321240127086639e-01
    z[10,3,3]  R1477     5.7243430055677891e-03
    z[10,3,3]  R1478     5.3754359483718872e-01
    z[10,3,3]  R1479     1.8291927874088287e-01
    z[10,3,3]  R1480     2.3596415296196938e-02
    z[10,3,3]  R1481     4.3839433789253235e-01
    z[10,3,3]  R1482     -2.7212709188461304e-01
    z[10,3,3]  R1483     5.7946640253067017e-01
    z[10,3,3]  R1484     -0.231314554810524
    z[10,3,3]  R1485     -4.0604448318481445e-01
    z[10,3,3]  R1486     -2.2802665829658508e-01
    z[10,3,3]  R1487     1.3147830963134766e-01
    z[10,3,3]  R1488     2.5725081562995911e-01
    z[10,3,3]  R1489     5.6381557136774063e-02
    z[10,3,3]  R1490     3.9758530259132385e-01
    z[10,3,3]  R1491     7.1642249822616577e-01
    z[10,3,3]  R1492     6.4207404851913452e-01
    z[10,3,3]  R1493     4.8567295074462891e-01
    z[10,3,3]  R1494     6.1398875713348389e-01
    z[10,3,3]  R1495     1.0109191387891769e-01
    z[10,3,3]  R1496     0.778455913066864
    z[10,3,3]  R1497     -3.1388387084007263e-01
    z[10,3,3]  R1498     9.2800423502922058e-02
    z[10,3,3]  R1499     1.0242816060781479e-01
    z[10,3,3]  R1500     -1.6660006344318390e-01
    z[10,3,3]  R1501     -3.7849491834640503e-01
    z[10,3,3]  R1502     2.5698107481002808e-01
    z[10,3,3]  R1503     4.8226529359817505e-01
    z[10,3,3]  R1504     0.67186039686203
    z[10,3,3]  R1505     5.2164858579635620e-01
    z[10,3,3]  R1506     -1.0438710451126099e-01
    z[10,3,3]  R1507     -7.9531884193420410e-01
    z[10,3,3]  R1508     -2.1419633924961090e-01
    z[10,3,3]  R1509     -7.8271585702896118e-01
    z[10,3,3]  R1510     -0.861125111579895
    z[10,3,3]  R1511     -8.1278353929519653e-01
    z[10,3,3]  R1512     -1.5331903100013733e-01
    z[10,3,3]  R1513     7.7234938740730286e-02
    z[10,3,3]  R1514     6.7612268030643463e-02
    z[10,3,3]  R1515     2.5660252571105957e-01
    z[10,3,3]  R1516     -6.4098340272903442e-01
    z[10,3,3]  R1517     5.8287929743528366e-02
    z[10,3,3]  R1518     2.7959231287240982e-02
    z[10,3,3]  R1519     -1.0461293160915375e-01
    z[10,3,3]  R1520     1.8379074335098267e-01
    z[10,3,3]  R1521     1.5539652109146118e-01
    z[10,3,3]  R1522     4.1253589093685150e-02
    z[10,3,3]  R1523     -1.8871749937534332e-01
    z[10,3,3]  R1524     -4.9115356802940369e-01
    z[10,3,3]  R1525     -3.8400459289550781e-01
    z[10,3,3]  R1526     5.5019551515579224e-01
    z[10,3,3]  R1527     -3.8510710000991821e-01
    z[10,3,3]  R1528     -1.6262365877628326e-01
    z[10,3,3]  R1529     1.7351378500461578e-01
    z[10,3,3]  R1530     -8.0030553042888641e-02
    z[10,3,3]  R1531     -4.0627697110176086e-01
    z[10,3,3]  R1532     -3.0941897630691528e-01
    z[10,3,3]  R1533     1.0074589401483536e-01
    z[10,3,3]  R1534     -6.4366863807663321e-04
    z[10,3,3]  R1535     -0.552621603012085
    z[10,3,3]  R1536     5.6718343496322632e-01
    z[10,3,3]  R1537     2.0407845079898834e-01
    z[10,3,3]  R1538     -5.3206861019134521e-01
    z[10,3,3]  R1539     2.4289989471435547e-01
    z[10,3,3]  R1540     1.6189590096473694e-02
    z[10,3,3]  R1541     4.3716889619827271e-01
    z[10,3,3]  R1542     5.6508713960647583e-01
    z[10,3,3]  R1543     -0.0973648726940155
    z[10,3,3]  R1544     5.7831853628158569e-01
    z[10,3,3]  R1545     -6.6572129726409912e-02
    z[10,3,3]  R1546     -2.7399215102195740e-01
    z[10,3,3]  R1547     -6.6143953800201416e-01
    z[10,3,3]  R1548     4.1986754536628723e-01
    z[10,3,3]  R1549     -2.3869954049587250e-01
    z[10,3,3]  R1550     -3.1929448246955872e-01
    z[10,3,3]  R1551     -3.4203460812568665e-01
    z[10,3,3]  R1552     -2.7745443582534790e-01
    z[10,3,3]  R1553     -1.5969966351985931e-01
    z[10,3,3]  R1554     -2.3088859394192696e-02
    z[10,3,3]  R1555     1.9278062880039215e-01
    z[10,3,3]  R1556     -1.4659017324447632e-01
    z[10,3,3]  R1557     -1.0071203112602234e-02
    z[10,3,3]  R1558     -4.1415423154830933e-01
    z[10,3,3]  R1559     -8.4944957494735718e-01
    z[10,3,3]  R1560     -5.6782656908035278e-01
    z[10,3,3]  R1561     -5.3837972879409790e-01
    z[10,3,3]  R1562     -1.9293190538883209e-01
    z[10,3,3]  R1563     1.9563492387533188e-02
    z[10,3,3]  R1564     -1.4713719487190247e-01
    z[10,3,3]  R1565     3.4421697258949280e-01
    z[10,3,3]  R1566     6.0054361820220947e-01
    z[10,3,3]  R1567     -1.2486293166875839e-01
    z[10,3,3]  R1568     -5.4064434766769409e-01
    z[10,3,3]  R1569     3.0994030833244324e-01
    z[10,3,3]  R1570     -6.5386700630187988e-01
    z[10,3,3]  R1571     -2.6555222272872925e-01
    z[10,3,3]  R1572     2.4559656158089638e-02
    z[10,3,3]  R1573     -5.6275906972587109e-03
    z[10,3,3]  R1574     -1.1046132072806358e-02
    z[10,3,3]  R1575     5.8191090822219849e-01
    z[10,3,3]  R1576     4.4353199005126953e-01
    z[10,3,4]  R33       1
    z[10,3,4]  R96       -1
    z[10,3,4]  R1461     -1
    z[10,3,4]  R1462     1
    z[10,3,4]  R1467     -1.6976216435432434e-01
    z[10,3,4]  R1468     -4.0392079949378967e-01
    z[10,3,4]  R1469     0.598517656326294
    z[10,3,4]  R1470     1.3599993288516998e-01
    z[10,3,4]  R1471     4.9204263091087341e-01
    z[10,3,4]  R1472     1.4729213714599609e-01
    z[10,3,4]  R1473     6.0209494829177856e-01
    z[10,3,4]  R1474     4.2323696613311768e-01
    z[10,3,4]  R1475     4.7182390093803406e-01
    z[10,3,4]  R1476     -3.3233314752578735e-01
    z[10,3,4]  R1477     -5.8718425035476685e-01
    z[10,3,4]  R1478     -1.7536464333534241e-01
    z[10,3,4]  R1479     8.0129742622375488e-02
    z[10,3,4]  R1480     -2.6915794610977173e-01
    z[10,3,4]  R1481     1.4086230099201202e-01
    z[10,3,4]  R1482     3.5032492876052856e-01
    z[10,3,4]  R1483     -6.6820669174194336e-01
    z[10,3,4]  R1484     -4.1844749450683594e-01
    z[10,3,4]  R1485     -1.4110292494297028e-01
    z[10,3,4]  R1486     -4.7072374820709229e-01
    z[10,3,4]  R1487     1.8801175057888031e-01
    z[10,3,4]  R1488     1.6922098398208618e-01
    z[10,3,4]  R1489     -5.7497894763946533e-01
    z[10,3,4]  R1490     -4.0878134965896606e-01
    z[10,3,4]  R1491     -2.5134158134460449e-01
    z[10,3,4]  R1492     4.7637414932250977e-01
    z[10,3,4]  R1493     5.9170957654714584e-02
    z[10,3,4]  R1494     -1.1432316154241562e-01
    z[10,3,4]  R1495     3.2425925135612488e-01
    z[10,3,4]  R1496     -3.0830618925392628e-03
    z[10,3,4]  R1497     -3.5209706425666809e-01
    z[10,3,4]  R1498     -5.3375250101089478e-01
    z[10,3,4]  R1499     1.4306859672069550e-01
    z[10,3,4]  R1500     3.9614674448966980e-01
    z[10,3,4]  R1501     -8.5101991891860962e-02
    z[10,3,4]  R1502     4.0996676683425903e-01
    z[10,3,4]  R1503     3.1603109836578369e-01
    z[10,3,4]  R1504     7.8276596963405609e-02
    z[10,3,4]  R1505     -4.5020073652267456e-02
    z[10,3,4]  R1506     2.4737946689128876e-01
    z[10,3,4]  R1507     4.5091444253921509e-01
    z[10,3,4]  R1508     3.5913035273551941e-01
    z[10,3,4]  R1509     -1.0920819640159607e-01
    z[10,3,4]  R1510     -1.9991688430309296e-01
    z[10,3,4]  R1511     -1.6100019216537476e-01
    z[10,3,4]  R1512     8.1068587303161621e-01
    z[10,3,4]  R1513     8.9609727263450623e-02
    z[10,3,4]  R1514     2.7591744065284729e-01
    z[10,3,4]  R1515     -0.0668027475476265
    z[10,3,4]  R1516     5.3418558835983276e-01
    z[10,3,4]  R1517     1.4315286278724670e-01
    z[10,3,4]  R1518     -4.9541953206062317e-01
    z[10,3,4]  R1519     -2.9208657145500183e-01
    z[10,3,4]  R1520     -1.8198199570178986e-01
    z[10,3,4]  R1521     1.9836862385272980e-01
    z[10,3,4]  R1522     -4.6531128883361816e-01
    z[10,3,4]  R1523     1.8763022124767303e-01
    z[10,3,4]  R1524     -1.1969381570816040e-01
    z[10,3,4]  R1525     -4.3034926056861877e-02
    z[10,3,4]  R1526     -3.5530057549476624e-01
    z[10,3,4]  R1527     3.1916370987892151e-01
    z[10,3,4]  R1528     1.7346268892288208e-01
    z[10,3,4]  R1529     3.7924036383628845e-01
    z[10,3,4]  R1530     -0.402294784784317
    z[10,3,4]  R1531     1.5069231390953064e-01
    z[10,3,4]  R1532     1.5406759083271027e-01
    z[10,3,4]  R1533     -2.8166621923446655e-01
    z[10,3,4]  R1534     -2.3513855040073395e-01
    z[10,3,4]  R1535     -8.8977195322513580e-02
    z[10,3,4]  R1536     2.2409638762474060e-01
    z[10,3,4]  R1537     0.154669389128685
    z[10,3,4]  R1538     -4.5688340067863464e-01
    z[10,3,4]  R1539     3.1223863363265991e-01
    z[10,3,4]  R1540     -6.3753414154052734e-01
    z[10,3,4]  R1541     3.0572861433029175e-02
    z[10,3,4]  R1542     1.2119908630847931e-01
    z[10,3,4]  R1543     0.698492169380188
    z[10,3,4]  R1544     -4.4865887612104416e-02
    z[10,3,4]  R1545     3.1009644269943237e-01
    z[10,3,4]  R1546     4.3205186724662781e-01
    z[10,3,4]  R1547     0.206967294216156
    z[10,3,4]  R1548     1.5200087428092957e-01
    z[10,3,4]  R1549     -0.355514258146286
    z[10,3,4]  R1550     -2.3040850460529327e-01
    z[10,3,4]  R1551     3.6587229371070862e-01
    z[10,3,4]  R1552     4.1439098119735718e-01
    z[10,3,4]  R1553     4.6595939993858337e-01
    z[10,3,4]  R1554     -3.7213604897260666e-02
    z[10,3,4]  R1555     -2.6540291309356689e-01
    z[10,3,4]  R1556     1.5093008987605572e-02
    z[10,3,4]  R1557     4.3244457244873047e-01
    z[10,3,4]  R1558     3.5639411211013794e-01
    z[10,3,4]  R1559     1.0726187378168106e-01
    z[10,3,4]  R1560     4.2680940032005310e-01
    z[10,3,4]  R1561     4.7016337513923645e-01
    z[10,3,4]  R1562     6.8323320150375366e-01
    z[10,3,4]  R1563     2.3376402258872986e-01
    z[10,3,4]  R1564     -6.5653212368488312e-02
    z[10,3,4]  R1565     1.4682777225971222e-01
    z[10,3,4]  R1566     -3.3612582087516785e-01
    z[10,3,4]  R1567     -4.4868391752243042e-01
    z[10,3,4]  R1568     3.8247746229171753e-01
    z[10,3,4]  R1569     -2.6561981439590454e-01
    z[10,3,4]  R1570     -2.7899253368377686e-01
    z[10,3,4]  R1571     -1.0250168852508068e-02
    z[10,3,4]  R1572     3.3220660686492920e-01
    z[10,3,4]  R1573     3.8770094513893127e-01
    z[10,3,4]  R1574     -1.7438489198684692e-01
    z[10,3,4]  R1575     -1.4591903984546661e-01
    z[10,3,4]  R1576     -1.5090203844010830e-02
    z[10,3,5]  R34       1
    z[10,3,5]  R97       -1
    z[10,3,5]  R1463     -1
    z[10,3,5]  R1464     1
    z[10,3,5]  R1467     1.4835315942764282e-01
    z[10,3,5]  R1468     2.6637926697731018e-01
    z[10,3,5]  R1469     -2.7432022616267204e-02
    z[10,3,5]  R1470     3.6502219736576080e-02
    z[10,3,5]  R1471     -1.0321357101202011e-01
    z[10,3,5]  R1472     3.5617381334304810e-01
    z[10,3,5]  R1473     -7.1311786770820618e-02
    z[10,3,5]  R1474     2.9279375076293945e-01
    z[10,3,5]  R1475     -4.5880886912345886e-01
    z[10,3,5]  R1476     5.8623600006103516e-01
    z[10,3,5]  R1477     5.1523530483245850e-01
    z[10,3,5]  R1478     0.631995439529419
    z[10,3,5]  R1479     2.4163471162319183e-01
    z[10,3,5]  R1480     -0.213162362575531
    z[10,3,5]  R1481     -3.3033466339111328e-01
    z[10,3,5]  R1482     3.2594287395477295e-01
    z[10,3,5]  R1483     5.4186254739761353e-02
    z[10,3,5]  R1484     -1.5071900188922882e-01
    z[10,3,5]  R1485     -2.9552176594734192e-01
    z[10,3,5]  R1486     -4.7624596953392029e-01
    z[10,3,5]  R1487     -4.1224356740713120e-02
    z[10,3,5]  R1488     -1.0179454833269119e-01
    z[10,3,5]  R1489     -1.2646009027957916e-01
    z[10,3,5]  R1490     -2.1688570082187653e-01
    z[10,3,5]  R1491     1.2357288040220737e-02
    z[10,3,5]  R1492     -7.3192939162254333e-02
    z[10,3,5]  R1493     -3.3099305629730225e-01
    z[10,3,5]  R1494     1.2673702836036682e-01
    z[10,3,5]  R1495     -1.1368635110557079e-02
    z[10,3,5]  R1496     1.4075355231761932e-01
    z[10,3,5]  R1497     -8.0980204045772552e-02
    z[10,3,5]  R1498     -1.8685216084122658e-02
    z[10,3,5]  R1499     8.7871748208999634e-01
    z[10,3,5]  R1500     5.2634340524673462e-01
    z[10,3,5]  R1501     2.1733374893665314e-01
    z[10,3,5]  R1502     4.6922564506530762e-02
    z[10,3,5]  R1503     1.9103546440601349e-01
    z[10,3,5]  R1504     6.2783464789390564e-02
    z[10,3,5]  R1505     1.5240314602851868e-01
    z[10,3,5]  R1506     2.6976841688156128e-01
    z[10,3,5]  R1507     -2.4964088201522827e-01
    z[10,3,5]  R1508     -8.1494313478469849e-01
    z[10,3,5]  R1509     4.0266877412796021e-01
    z[10,3,5]  R1510     8.6275830864906311e-02
    z[10,3,5]  R1511     -6.1682611703872681e-02
    z[10,3,5]  R1512     -4.3264696002006531e-01
    z[10,3,5]  R1513     3.9988461136817932e-01
    z[10,3,5]  R1514     3.7383088469505310e-01
    z[10,3,5]  R1515     6.3645350933074951e-01
    z[10,3,5]  R1516     8.7714329361915588e-02
    z[10,3,5]  R1517     1.3221102952957153e-01
    z[10,3,5]  R1518     -9.0258710086345673e-02
    z[10,3,5]  R1519     1.4950045943260193e-01
    z[10,3,5]  R1520     1.0186498612165451e-01
    z[10,3,5]  R1521     -4.4034279882907867e-02
    z[10,3,5]  R1522     4.1084337234497070e-01
    z[10,3,5]  R1523     3.4483358263969421e-01
    z[10,3,5]  R1524     -2.2557886317372322e-02
    z[10,3,5]  R1525     3.2967728376388550e-01
    z[10,3,5]  R1526     5.1698958873748779e-01
    z[10,3,5]  R1527     -3.5127472877502441e-01
    z[10,3,5]  R1528     0.733608067035675
    z[10,3,5]  R1529     -2.3174121975898743e-01
    z[10,3,5]  R1530     -2.0580349862575531e-01
    z[10,3,5]  R1531     3.1133580207824707e-01
    z[10,3,5]  R1532     1.8946586549282074e-01
    z[10,3,5]  R1533     -4.0162327885627747e-01
    z[10,3,5]  R1534     -3.1405779719352722e-01
    z[10,3,5]  R1535     -3.9064630866050720e-02
    z[10,3,5]  R1536     -5.4667103104293346e-03
    z[10,3,5]  R1537     -8.8266089558601379e-02
    z[10,3,5]  R1538     -9.2325031757354736e-02
    z[10,3,5]  R1539     -1.6009141504764557e-01
    z[10,3,5]  R1540     -5.7933915406465530e-02
    z[10,3,5]  R1541     1.6093787550926208e-01
    z[10,3,5]  R1542     4.1721498966217041e-01
    z[10,3,5]  R1543     -9.5735192298889160e-02
    z[10,3,5]  R1544     2.5789514183998108e-01
    z[10,3,5]  R1545     -3.9667010307312012e-01
    z[10,3,5]  R1546     -3.6002573370933533e-01
    z[10,3,5]  R1547     -2.4313493072986603e-01
    z[10,3,5]  R1548     -7.2068810462951660e-02
    z[10,3,5]  R1549     1.2798270583152771e-01
    z[10,3,5]  R1550     -6.2841761112213135e-01
    z[10,3,5]  R1551     6.1056271195411682e-02
    z[10,3,5]  R1552     -1.8165180087089539e-01
    z[10,3,5]  R1553     5.8593624830245972e-01
    z[10,3,5]  R1554     3.5766917467117310e-01
    z[10,3,5]  R1555     5.3547525405883789e-01
    z[10,3,5]  R1556     4.1101586073637009e-02
    z[10,3,5]  R1557     1.0764109343290329e-01
    z[10,3,5]  R1558     -1.5185199677944183e-01
    z[10,3,5]  R1559     2.6983284950256348e-01
    z[10,3,5]  R1560     4.1258224844932556e-01
    z[10,3,5]  R1561     -2.1482808515429497e-02
    z[10,3,5]  R1562     -1.9362571835517883e-01
    z[10,3,5]  R1563     9.8400317132472992e-02
    z[10,3,5]  R1564     2.6339009404182434e-01
    z[10,3,5]  R1565     3.6060410737991333e-01
    z[10,3,5]  R1566     -3.3307597041130066e-01
    z[10,3,5]  R1567     9.8236635327339172e-02
    z[10,3,5]  R1568     2.1155847609043121e-01
    z[10,3,5]  R1569     3.4791359305381775e-01
    z[10,3,5]  R1570     3.7651412189006805e-02
    z[10,3,5]  R1571     -3.4793993830680847e-01
    z[10,3,5]  R1572     -1.0101927816867828e-01
    z[10,3,5]  R1573     1.5086345374584198e-01
    z[10,3,5]  R1574     1.3020054996013641e-01
    z[10,3,5]  R1575     -3.7766936421394348e-01
    z[10,3,5]  R1576     7.4742093682289124e-02
    z[10,3,6]  R35       1
    z[10,3,6]  R98       -1
    z[10,3,6]  R1465     -1
    z[10,3,6]  R1466     1
    z[10,3,6]  R1467     2.7644306421279907e-01
    z[10,3,6]  R1468     6.7327147722244263e-01
    z[10,3,6]  R1469     -7.6228022575378418e-02
    z[10,3,6]  R1470     3.6781498789787292e-01
    z[10,3,6]  R1471     2.8878265619277954e-01
    z[10,3,6]  R1472     -4.1889244318008423e-01
    z[10,3,6]  R1473     -9.1430976986885071e-02
    z[10,3,6]  R1474     -2.0811778306961060e-01
    z[10,3,6]  R1475     -3.2275122404098511e-01
    z[10,3,6]  R1476     -4.4729572534561157e-01
    z[10,3,6]  R1477     -5.7501184940338135e-01
    z[10,3,6]  R1478     -1.4265993237495422e-01
    z[10,3,6]  R1479     -3.0545833706855774e-01
    z[10,3,6]  R1480     -1.6427166759967804e-01
    z[10,3,6]  R1481     2.0659960806369781e-01
    z[10,3,6]  R1482     -2.2668333351612091e-01
    z[10,3,6]  R1483     2.0110729336738586e-01
    z[10,3,6]  R1484     1.2507688999176025e-01
    z[10,3,6]  R1485     -1.3507668673992157e-01
    z[10,3,6]  R1486     -2.0407313108444214e-01
    z[10,3,6]  R1487     1.7033822834491730e-01
    z[10,3,6]  R1488     -4.6367627382278442e-01
    z[10,3,6]  R1489     0.197689488530159
    z[10,3,6]  R1490     3.9398968219757080e-02
    z[10,3,6]  R1491     1.2318865209817886e-01
    z[10,3,6]  R1492     -1.4014187268912792e-02
    z[10,3,6]  R1493     5.6017464399337769e-01
    z[10,3,6]  R1494     9.2212647199630737e-02
    z[10,3,6]  R1495     3.5562083125114441e-01
    z[10,3,6]  R1496     -2.2206236422061920e-01
    z[10,3,6]  R1497     -8.0214828252792358e-02
    z[10,3,6]  R1498     1.7276298999786377e-01
    z[10,3,6]  R1499     2.4914576113224030e-01
    z[10,3,6]  R1500     -4.4145914912223816e-01
    z[10,3,6]  R1501     -2.8837126493453979e-01
    z[10,3,6]  R1502     1.7233215272426605e-01
    z[10,3,6]  R1503     -3.0135154724121094e-01
    z[10,3,6]  R1504     -1.1381273716688156e-01
    z[10,3,6]  R1505     1.3115748763084412e-01
    z[10,3,6]  R1506     4.3380558490753174e-02
    z[10,3,6]  R1507     2.3448066413402557e-01
    z[10,3,6]  R1508     2.1293486654758453e-01
    z[10,3,6]  R1509     4.0058061480522156e-01
    z[10,3,6]  R1510     4.3068426847457886e-01
    z[10,3,6]  R1511     0.484515517950058
    z[10,3,6]  R1512     -1.4090597629547119e-01
    z[10,3,6]  R1513     -1.5417706966400146e-01
    z[10,3,6]  R1514     1.3927669823169708e-01
    z[10,3,6]  R1515     -1.7149336636066437e-01
    z[10,3,6]  R1516     1.0915964841842651e-01
    z[10,3,6]  R1517     -2.4677093327045441e-01
    z[10,3,6]  R1518     1.9186499714851379e-01
    z[10,3,6]  R1519     -3.8098847866058350e-01
    z[10,3,6]  R1520     -5.7603371143341064e-01
    z[10,3,6]  R1521     -6.2416213750839233e-01
    z[10,3,6]  R1522     -1.0772877931594849e-01
    z[10,3,6]  R1523     -6.9624620676040649e-01
    z[10,3,6]  R1524     -8.2980375736951828e-03
    z[10,3,6]  R1525     -4.0678212046623230e-01
    z[10,3,6]  R1526     -6.9660849869251251e-02
    z[10,3,6]  R1527     0.0590716190636158
    z[10,3,6]  R1528     -8.8420487940311432e-02
    z[10,3,6]  R1529     3.7266305088996887e-01
    z[10,3,6]  R1530     1.9456608593463898e-01
    z[10,3,6]  R1531     -2.7480429410934448e-01
    z[10,3,6]  R1532     3.1899476051330566e-01
    z[10,3,6]  R1533     5.9696954488754272e-01
    z[10,3,6]  R1534     7.8890842199325562e-01
    z[10,3,6]  R1535     0.251801997423172
    z[10,3,6]  R1536     -2.5877025723457336e-01
    z[10,3,6]  R1537     4.9064162373542786e-01
    z[10,3,6]  R1538     5.5366568267345428e-02
    z[10,3,6]  R1539     2.2685837745666504e-01
    z[10,3,6]  R1540     2.8735220432281494e-01
    z[10,3,6]  R1541     -3.4319585561752319e-01
    z[10,3,6]  R1542     -5.3683228790760040e-02
    z[10,3,6]  R1543     -0.34941366314888
    z[10,3,6]  R1544     4.4143715500831604e-01
    z[10,3,6]  R1545     -1.0558591037988663e-01
    z[10,3,6]  R1546     -0.243662029504776
    z[10,3,6]  R1547     -7.3637999594211578e-02
    z[10,3,6]  R1548     -1.6427341103553772e-01
    z[10,3,6]  R1549     2.0980919897556305e-01
    z[10,3,6]  R1550     1.6063556075096130e-01
    z[10,3,6]  R1551     -5.0175631046295166e-01
    z[10,3,6]  R1552     -6.1454075574874878e-01
    z[10,3,6]  R1553     -2.1731488406658173e-01
    z[10,3,6]  R1554     7.3154765367507935e-01
    z[10,3,6]  R1555     1.5326510369777679e-01
    z[10,3,6]  R1556     5.3874832391738892e-01
    z[10,3,6]  R1557     -3.0045926570892334e-01
    z[10,3,6]  R1558     0.0719318613409996
    z[10,3,6]  R1559     1.3921739161014557e-01
    z[10,3,6]  R1560     -0.278016060590744
    z[10,3,6]  R1561     -5.1049643754959106e-01
    z[10,3,6]  R1562     -0.24481201171875
    z[10,3,6]  R1563     3.0772894620895386e-01
    z[10,3,6]  R1564     6.3795872032642365e-02
    z[10,3,6]  R1565     -1.2187448143959045e-01
    z[10,3,6]  R1566     -2.1238806843757629e-01
    z[10,3,6]  R1567     2.7810081839561462e-01
    z[10,3,6]  R1568     -2.4018239974975586e-01
    z[10,3,6]  R1569     -1.2080726772546768e-01
    z[10,3,6]  R1570     6.9574706256389618e-02
    z[10,3,6]  R1571     -4.0678188204765320e-01
    z[10,3,6]  R1572     1.1225664988160133e-02
    z[10,3,6]  R1573     6.7537270486354828e-02
    z[10,3,6]  R1574     -2.0034988224506378e-01
    z[10,3,6]  R1575     1.8935823440551758e-01
    z[10,3,6]  R1576     1.5311431884765625e-01
    z[4,5,0]  R38       -1
    z[4,5,0]  R47       1
    z[4,5,0]  R1661     -1
    z[4,5,0]  R1662     1
    z[4,5,0]  R1675     -9.5272815227508545e-01
    z[4,5,0]  R1676     -6.5755039453506470e-01
    z[4,5,0]  R1677     -7.4672192335128784e-01
    z[4,5,0]  R1678     -5.6827926635742188e-01
    z[4,5,0]  R1679     -0.697720468044281
    z[4,5,0]  R1680     -8.0624312162399292e-01
    z[4,5,0]  R1681     -7.0575207471847534e-01
    z[4,5,0]  R1682     -7.9680454730987549e-01
    z[4,5,0]  R1683     -6.2853616476058960e-01
    z[4,5,0]  R1684     -6.3414430618286133e-01
    z[4,5,0]  R1685     4.7217079997062683e-01
    z[4,5,0]  R1686     4.8192718625068665e-01
    z[4,5,0]  R1687     5.3638529777526855e-01
    z[4,5,0]  R1688     5.5831915140151978e-01
    z[4,5,0]  R1689     3.1635567545890808e-01
    z[4,5,0]  R1690     3.6004063487052917e-01
    z[4,5,0]  R1691     4.6988460421562195e-01
    z[4,5,0]  R1692     4.5945248007774353e-01
    z[4,5,0]  R1693     6.3387542963027954e-01
    z[4,5,0]  R1694     7.6060456037521362e-01
    z[4,5,0]  R1695     7.5892186164855957e-01
    z[4,5,0]  R1696     8.2507163286209106e-01
    z[4,5,0]  R1697     0.69380784034729
    z[4,5,0]  R1698     7.7515572309494019e-01
    z[4,5,0]  R1699     5.9738069772720337e-01
    z[4,5,0]  R1700     4.7916504740715027e-01
    z[4,5,0]  R1701     1.2520797550678253e-01
    z[4,5,0]  R1702     0.694004237651825
    z[4,5,0]  R1703     -1.4771226048469543e-01
    z[4,5,0]  R1704     -3.7355810403823853e-02
    z[4,5,0]  R1705     6.8568706512451172e-01
    z[4,5,0]  R1706     7.5445693731307983e-01
    z[4,5,0]  R1707     5.5920267105102539e-01
    z[4,5,0]  R1708     4.9857971072196960e-01
    z[4,5,0]  R1709     4.4080206751823425e-01
    z[4,5,0]  R1710     5.3665673732757568e-01
    z[4,5,0]  R1711     7.3393128812313080e-02
    z[4,5,0]  R1712     6.6152709722518921e-01
    z[4,5,0]  R1713     4.3288326263427734e-01
    z[4,5,0]  R1714     -1.9117283821105957e-01
    z[4,5,0]  R1715     9.3395346403121948e-01
    z[4,5,0]  R1716     8.2453894615173340e-01
    z[4,5,0]  R1717     6.0545265674591064e-01
    z[4,5,0]  R1718     6.8986546993255615e-01
    z[4,5,0]  R1719     5.1483350992202759e-01
    z[4,5,0]  R1720     4.2101282626390457e-02
    z[4,5,0]  R1721     7.5327016413211823e-02
    z[4,5,0]  R1722     -1.8716026842594147e-01
    z[4,5,0]  R1723     -2.4608166888356209e-02
    z[4,5,0]  R1724     -1.4167489111423492e-01
    z[4,5,0]  R1725     0.290393203496933
    z[4,5,0]  R1726     1.1789184808731079e-01
    z[4,5,0]  R1727     4.6540299057960510e-01
    z[4,5,0]  R1728     -2.3550014197826385e-01
    z[4,5,0]  R1729     0.0439508818089962
    z[4,5,0]  R1730     7.0555157959461212e-02
    z[4,5,0]  R1731     1.8429741263389587e-01
    z[4,5,0]  R1732     -1.2201659381389618e-01
    z[4,5,0]  R1733     -1.9457355141639709e-02
    z[4,5,0]  R1734     -2.6659536361694336e-01
    z[4,5,0]  R1735     -8.8465720415115356e-01
    z[4,5,0]  R1736     -8.8275516033172607e-01
    z[4,5,0]  R1737     -8.3729118108749390e-01
    z[4,5,0]  R1738     -8.3234339952468872e-01
    z[4,5,0]  R1739     -8.2923251390457153e-01
    z[4,5,0]  R1740     -8.2676589488983154e-01
    z[4,5,0]  R1741     -8.2746756076812744e-01
    z[4,5,0]  R1742     -7.9120177030563354e-01
    z[4,5,0]  R1743     -7.5296068191528320e-01
    z[4,5,0]  R1744     2.5739872455596924e-01
    z[4,5,0]  R1745     1.2290877103805542e-01
    z[4,5,0]  R1746     8.6141891777515411e-02
    z[4,5,0]  R1747     -8.3922937512397766e-02
    z[4,5,0]  R1748     1.2700876593589783e-01
    z[4,5,0]  R1749     1.8221594393253326e-01
    z[4,5,0]  R1750     -6.2401881441473961e-03
    z[4,5,0]  R1751     2.1518439054489136e-01
    z[4,5,0]  R1752     1.5994463860988617e-01
    z[4,5,0]  R1753     1.6754741966724396e-01
    z[4,5,0]  R1754     1.8137775361537933e-01
    z[4,5,0]  R1755     5.9688808396458626e-03
    z[4,5,0]  R1756     2.1250111982226372e-02
    z[4,5,0]  R1757     6.2775678932666779e-02
    z[4,5,0]  R1758     3.7722158432006836e-01
    z[4,5,0]  R1759     1.1136939376592636e-01
    z[4,5,0]  R1760     1.2851694226264954e-01
    z[4,5,0]  R1761     -4.2825754731893539e-02
    z[4,5,0]  R1762     -1.4160597324371338e-01
    z[4,5,0]  R1763     1.8544195592403412e-01
    z[4,5,0]  R1764     1.0569975525140762e-01
    z[4,5,0]  R1765     -3.0331939458847046e-01
    z[4,5,0]  R1766     3.3793774247169495e-01
    z[4,5,0]  R1767     3.0217203497886658e-01
    z[4,5,0]  R1768     4.0725100040435791e-01
    z[4,5,0]  R1769     1.4683434367179871e-01
    z[4,5,0]  R1770     6.0486119985580444e-01
    z[4,5,0]  R1771     -1.9973242655396461e-02
    z[4,5,0]  R1772     5.2902978658676147e-01
    z[4,5,0]  R1773     3.6606675386428833e-01
    z[4,5,0]  R1774     -1.0453700087964535e-02
    z[4,5,1]  R39       -1
    z[4,5,1]  R48       1
    z[4,5,1]  R1663     -1
    z[4,5,1]  R1664     1
    z[4,5,1]  R1675     2.3143243044614792e-02
    z[4,5,1]  R1676     -0.0182262621819973
    z[4,5,1]  R1677     -5.7639140635728836e-02
    z[4,5,1]  R1678     -2.4348567426204681e-01
    z[4,5,1]  R1679     -1.9047854840755463e-01
    z[4,5,1]  R1680     -2.0784406363964081e-01
    z[4,5,1]  R1681     1.7566837370395660e-02
    z[4,5,1]  R1682     -2.8242090344429016e-01
    z[4,5,1]  R1683     -2.1849890053272247e-01
    z[4,5,1]  R1684     -2.5236135721206665e-01
    z[4,5,1]  R1685     -2.2388954460620880e-01
    z[4,5,1]  R1686     -3.6125013232231140e-01
    z[4,5,1]  R1687     -2.9774361848831177e-01
    z[4,5,1]  R1688     -4.0703916549682617e-01
    z[4,5,1]  R1689     -1.4761309325695038e-01
    z[4,5,1]  R1690     -7.2857493162155151e-01
    z[4,5,1]  R1691     -1.8686607480049133e-01
    z[4,5,1]  R1692     -2.0314499735832214e-01
    z[4,5,1]  R1693     -2.7796500921249390e-01
    z[4,5,1]  R1694     -2.6957890391349792e-01
    z[4,5,1]  R1695     -2.6112228631973267e-01
    z[4,5,1]  R1696     2.5459733605384827e-01
    z[4,5,1]  R1697     -5.5696594715118408e-01
    z[4,5,1]  R1698     -3.5624718666076660e-01
    z[4,5,1]  R1699     -3.3118823170661926e-01
    z[4,5,1]  R1700     1.8527182936668396e-01
    z[4,5,1]  R1701     -8.8961702585220337e-01
    z[4,5,1]  R1702     1.8973752856254578e-01
    z[4,5,1]  R1703     -4.8082154989242554e-01
    z[4,5,1]  R1704     9.8477828502655029e-01
    z[4,5,1]  R1705     1.2013015151023865e-01
    z[4,5,1]  R1706     -2.5330534577369690e-01
    z[4,5,1]  R1707     -7.9348884522914886e-02
    z[4,5,1]  R1708     -3.7134587764739990e-01
    z[4,5,1]  R1709     -1.4715818688273430e-02
    z[4,5,1]  R1710     -2.4932594597339630e-01
    z[4,5,1]  R1711     -9.3254148960113525e-01
    z[4,5,1]  R1712     1.9009114801883698e-01
    z[4,5,1]  R1713     6.9467514753341675e-02
    z[4,5,1]  R1714     -8.2899713516235352e-01
    z[4,5,1]  R1715     -2.2529418766498566e-01
    z[4,5,1]  R1716     -2.6308485865592957e-01
    z[4,5,1]  R1717     -1.4774477481842041e-01
    z[4,5,1]  R1718     9.8536713048815727e-03
    z[4,5,1]  R1719     -2.4957950413227081e-01
    z[4,5,1]  R1720     -0.924492597579956
    z[4,5,1]  R1721     9.8405432701110840e-01
    z[4,5,1]  R1722     9.2263603210449219e-01
    z[4,5,1]  R1723     9.3988919258117676e-01
    z[4,5,1]  R1724     9.3019974231719971e-01
    z[4,5,1]  R1725     -5.4126262664794922e-01
    z[4,5,1]  R1726     -0.527815043926239
    z[4,5,1]  R1727     -4.0310895442962646e-01
    z[4,5,1]  R1728     -5.1441872119903564e-01
    z[4,5,1]  R1729     -3.0516985058784485e-01
    z[4,5,1]  R1730     -5.3298741579055786e-01
    z[4,5,1]  R1731     -5.1865673065185547e-01
    z[4,5,1]  R1732     -2.9804956912994385e-01
    z[4,5,1]  R1733     -1.1388030648231506e-01
    z[4,5,1]  R1734     -3.3869579434394836e-01
    z[4,5,1]  R1735     2.4482125043869019e-01
    z[4,5,1]  R1736     -5.7958744466304779e-02
    z[4,5,1]  R1737     2.7509590983390808e-01
    z[4,5,1]  R1738     2.9442688822746277e-01
    z[4,5,1]  R1739     2.1309331059455872e-01
    z[4,5,1]  R1740     9.9954180419445038e-02
    z[4,5,1]  R1741     1.0732129961252213e-01
    z[4,5,1]  R1742     2.8265592455863953e-01
    z[4,5,1]  R1743     2.1035017073154449e-01
    z[4,5,1]  R1744     3.1727030873298645e-01
    z[4,5,1]  R1745     9.6432214975357056e-01
    z[4,5,1]  R1746     9.6649235486984253e-01
    z[4,5,1]  R1747     9.3329089879989624e-01
    z[4,5,1]  R1748     9.3658292293548584e-01
    z[4,5,1]  R1749     9.0506297349929810e-01
    z[4,5,1]  R1750     9.1943162679672241e-01
    z[4,5,1]  R1751     8.8576912879943848e-01
    z[4,5,1]  R1752     8.7752628326416016e-01
    z[4,5,1]  R1753     8.8975477218627930e-01
    z[4,5,1]  R1754     9.0900379419326782e-01
    z[4,5,1]  R1755     -5.1484632492065430e-01
    z[4,5,1]  R1756     -1.8647789955139160e-01
    z[4,5,1]  R1757     -3.6952864378690720e-02
    z[4,5,1]  R1758     5.3254729509353638e-01
    z[4,5,1]  R1759     1.9414755702018738e-01
    z[4,5,1]  R1760     1.8129315972328186e-01
    z[4,5,1]  R1761     -4.4702622294425964e-01
    z[4,5,1]  R1762     -4.6301969885826111e-01
    z[4,5,1]  R1763     8.1563852727413177e-02
    z[4,5,1]  R1764     -1.2047359347343445e-01
    z[4,5,1]  R1765     -4.7547608613967896e-01
    z[4,5,1]  R1766     2.9762217402458191e-01
    z[4,5,1]  R1767     0.292923241853714
    z[4,5,1]  R1768     3.3576118946075439e-01
    z[4,5,1]  R1769     -3.5782107710838318e-01
    z[4,5,1]  R1770     -1.0087995976209641e-01
    z[4,5,1]  R1771     4.2413991689682007e-01
    z[4,5,1]  R1772     -1.9266135990619659e-01
    z[4,5,1]  R1773     8.0619163811206818e-02
    z[4,5,1]  R1774     5.3010061383247375e-02
    z[4,5,2]  R40       -1
    z[4,5,2]  R49       1
    z[4,5,2]  R1665     -1
    z[4,5,2]  R1666     1
    z[4,5,2]  R1675     -1.3083437085151672e-01
    z[4,5,2]  R1676     2.2364251315593719e-02
    z[4,5,2]  R1677     1.8938867747783661e-01
    z[4,5,2]  R1678     2.9510036110877991e-01
    z[4,5,2]  R1679     2.1735161542892456e-01
    z[4,5,2]  R1680     3.0615091323852539e-01
    z[4,5,2]  R1681     0.246908500790596
    z[4,5,2]  R1682     -1.1430247128009796e-01
    z[4,5,2]  R1683     2.8599098324775696e-01
    z[4,5,2]  R1684     2.8773880004882812e-01
    z[4,5,2]  R1685     -4.3195471167564392e-01
    z[4,5,2]  R1686     -4.9419918656349182e-01
    z[4,5,2]  R1687     -1.1149150878190994e-01
    z[4,5,2]  R1688     -3.0816671252250671e-01
    z[4,5,2]  R1689     -6.4465612173080444e-01
    z[4,5,2]  R1690     -9.4892911612987518e-02
    z[4,5,2]  R1691     -5.4666769504547119e-01
    z[4,5,2]  R1692     -2.1985243260860443e-01
    z[4,5,2]  R1693     1.8002183735370636e-01
    z[4,5,2]  R1694     2.0883961021900177e-01
    z[4,5,2]  R1695     0.0620284229516983
    z[4,5,2]  R1696     3.3178892731666565e-01
    z[4,5,2]  R1697     -2.5202444195747375e-01
    z[4,5,2]  R1698     -7.3056198656558990e-02
    z[4,5,2]  R1699     2.6410454511642456e-01
    z[4,5,2]  R1700     -1.9367748871445656e-02
    z[4,5,2]  R1701     2.7567037940025330e-01
    z[4,5,2]  R1702     5.5395156145095825e-02
    z[4,5,2]  R1703     -3.5112449526786804e-01
    z[4,5,2]  R1704     1.4774592593312263e-02
    z[4,5,2]  R1705     -3.2486429810523987e-01
    z[4,5,2]  R1706     -3.2689192891120911e-01
    z[4,5,2]  R1707     -4.9133110046386719e-01
    z[4,5,2]  R1708     -0.49920454621315
    z[4,5,2]  R1709     -3.4168452024459839e-02
    z[4,5,2]  R1710     -2.0973436534404755e-01
    z[4,5,2]  R1711     -0.209557443857193
    z[4,5,2]  R1712     -3.0824416875839233e-01
    z[4,5,2]  R1713     4.1353002190589905e-02
    z[4,5,2]  R1714     -1.6549435257911682e-01
    z[4,5,2]  R1715     3.0575854703783989e-02
    z[4,5,2]  R1716     1.6815306246280670e-01
    z[4,5,2]  R1717     -3.1875157356262207e-01
    z[4,5,2]  R1718     -1.3141167163848877e-01
    z[4,5,2]  R1719     -4.8377791047096252e-01
    z[4,5,2]  R1720     2.1243350580334663e-02
    z[4,5,2]  R1721     -4.4571772217750549e-02
    z[4,5,2]  R1722     7.3673419654369354e-02
    z[4,5,2]  R1723     4.2845621705055237e-02
    z[4,5,2]  R1724     2.4338749051094055e-01
    z[4,5,2]  R1725     5.0011879205703735e-01
    z[4,5,2]  R1726     5.7912456989288330e-01
    z[4,5,2]  R1727     4.1385686397552490e-01
    z[4,5,2]  R1728     4.1221617721021175e-03
    z[4,5,2]  R1729     2.9576846957206726e-01
    z[4,5,2]  R1730     1.0213791392743587e-02
    z[4,5,2]  R1731     7.9286046326160431e-02
    z[4,5,2]  R1732     -1.4119987189769745e-01
    z[4,5,2]  R1733     7.5469903647899628e-02
    z[4,5,2]  R1734     8.5755802690982819e-02
    z[4,5,2]  R1735     1.5370386838912964e-01
    z[4,5,2]  R1736     -4.9505002796649933e-02
    z[4,5,2]  R1737     -1.8806798756122589e-01
    z[4,5,2]  R1738     -3.7738022208213806e-01
    z[4,5,2]  R1739     -6.8416267633438110e-02
    z[4,5,2]  R1740     -0.0820479691028595
    z[4,5,2]  R1741     -3.6171787977218628e-01
    z[4,5,2]  R1742     -3.1313976645469666e-01
    z[4,5,2]  R1743     4.4587758183479309e-01
    z[4,5,2]  R1744     5.4044306278228760e-01
    z[4,5,2]  R1745     8.6287543177604675e-02
    z[4,5,2]  R1746     -1.0716758668422699e-01
    z[4,5,2]  R1747     -1.1453446745872498e-01
    z[4,5,2]  R1748     1.8362710252404213e-02
    z[4,5,2]  R1749     1.6968338750302792e-03
    z[4,5,2]  R1750     -2.2201403975486755e-01
    z[4,5,2]  R1751     9.5056831836700439e-02
    z[4,5,2]  R1752     1.5280073881149292e-01
    z[4,5,2]  R1753     -6.3114441931247711e-02
    z[4,5,2]  R1754     2.0639857277274132e-02
    z[4,5,2]  R1755     9.0547293424606323e-02
    z[4,5,2]  R1756     -1.0910715162754059e-01
    z[4,5,2]  R1757     -1.8891464173793793e-01
    z[4,5,2]  R1758     4.9798309803009033e-01
    z[4,5,2]  R1759     4.4809807091951370e-02
    z[4,5,2]  R1760     -1.9111575558781624e-02
    z[4,5,2]  R1761     -1.5248617529869080e-01
    z[4,5,2]  R1762     -3.0039435625076294e-01
    z[4,5,2]  R1763     5.9113286435604095e-02
    z[4,5,2]  R1764     -2.2162710130214691e-01
    z[4,5,2]  R1765     -4.8571833968162537e-01
    z[4,5,2]  R1766     4.9689537286758423e-01
    z[4,5,2]  R1767     5.6850421428680420e-01
    z[4,5,2]  R1768     6.2127900123596191e-01
    z[4,5,2]  R1769     3.0722004175186157e-01
    z[4,5,2]  R1770     -7.4626475572586060e-01
    z[4,5,2]  R1771     -1.4325246214866638e-01
    z[4,5,2]  R1772     -6.5372610092163086e-01
    z[4,5,2]  R1773     -8.2315278053283691e-01
    z[4,5,2]  R1774     -9.1736966371536255e-01
    z[4,5,3]  R41       -1
    z[4,5,3]  R50       1
    z[4,5,3]  R1667     -1
    z[4,5,3]  R1668     1
    z[4,5,3]  R1675     1.9385917484760284e-01
    z[4,5,3]  R1676     5.9133011102676392e-01
    z[4,5,3]  R1677     5.2878916263580322e-01
    z[4,5,3]  R1678     6.8688517808914185e-01
    z[4,5,3]  R1679     2.6613193750381470e-01
    z[4,5,3]  R1680     2.1375413239002228e-01
    z[4,5,3]  R1681     3.1471309065818787e-01
    z[4,5,3]  R1682     1.5877273678779602e-01
    z[4,5,3]  R1683     4.8079448938369751e-01
    z[4,5,3]  R1684     4.6509143710136414e-01
    z[4,5,3]  R1685     -3.2676982879638672e-01
    z[4,5,3]  R1686     2.9687242582440376e-02
    z[4,5,3]  R1687     4.3849018216133118e-01
    z[4,5,3]  R1688     -3.6967954039573669e-01
    z[4,5,3]  R1689     -3.6924713850021362e-01
    z[4,5,3]  R1690     2.6742484420537949e-02
    z[4,5,3]  R1691     -5.3775870800018311e-01
    z[4,5,3]  R1692     -4.3696826696395874e-01
    z[4,5,3]  R1693     2.2469219565391541e-01
    z[4,5,3]  R1694     3.9729416370391846e-01
    z[4,5,3]  R1695     2.2414935752749443e-02
    z[4,5,3]  R1696     2.4273928999900818e-01
    z[4,5,3]  R1697     -3.1692928075790405e-01
    z[4,5,3]  R1698     -1.5646527707576752e-01
    z[4,5,3]  R1699     2.3036557435989380e-01
    z[4,5,3]  R1700     -4.0395253896713257e-01
    z[4,5,3]  R1701     2.2190262377262115e-01
    z[4,5,3]  R1702     -3.8582831621170044e-01
    z[4,5,3]  R1703     -6.2994945049285889e-01
    z[4,5,3]  R1704     7.1100570261478424e-02
    z[4,5,3]  R1705     1.2340092658996582e-01
    z[4,5,3]  R1706     3.7269029766321182e-02
    z[4,5,3]  R1707     -1.8431878089904785e-01
    z[4,5,3]  R1708     -2.5028491020202637e-01
    z[4,5,3]  R1709     -0.586895227432251
    z[4,5,3]  R1710     -6.0425555706024170e-01
    z[4,5,3]  R1711     2.6788461953401566e-02
    z[4,5,3]  R1712     -6.0113370418548584e-01
    z[4,5,3]  R1713     -4.2124190926551819e-01
    z[4,5,3]  R1714     -0.409285306930542
    z[4,5,3]  R1715     7.6864279806613922e-02
    z[4,5,3]  R1716     -1.6593851149082184e-01
    z[4,5,3]  R1717     -4.5895448327064514e-01
    z[4,5,3]  R1718     -1.0087624192237854e-01
    z[4,5,3]  R1719     -6.4555007219314575e-01
    z[4,5,3]  R1720     2.0760118961334229e-01
    z[4,5,3]  R1721     -1.0306254029273987e-01
    z[4,5,3]  R1722     -2.0503188669681549e-01
    z[4,5,3]  R1723     -4.0007106959819794e-02
    z[4,5,3]  R1724     -1.8252540379762650e-02
    z[4,5,3]  R1725     -2.7117517590522766e-01
    z[4,5,3]  R1726     -4.7600927948951721e-01
    z[4,5,3]  R1727     -1.4765599370002747e-01
    z[4,5,3]  R1728     -5.6458425521850586e-01
    z[4,5,3]  R1729     -5.9491634368896484e-01
    z[4,5,3]  R1730     -7.0506691932678223e-02
    z[4,5,3]  R1731     -1.9790592789649963e-01
    z[4,5,3]  R1732     -7.9035305976867676e-01
    z[4,5,3]  R1733     -9.4377058744430542e-01
    z[4,5,3]  R1734     -3.5162830352783203e-01
    z[4,5,3]  R1735     2.9121702909469604e-01
    z[4,5,3]  R1736     3.5964709520339966e-01
    z[4,5,3]  R1737     2.8630918264389038e-01
    z[4,5,3]  R1738     1.8204185366630554e-01
    z[4,5,3]  R1739     3.5189661383628845e-01
    z[4,5,3]  R1740     0.126349076628685
    z[4,5,3]  R1741     3.8119003176689148e-01
    z[4,5,3]  R1742     1.9082163274288177e-01
    z[4,5,3]  R1743     2.0349277555942535e-01
    z[4,5,3]  R1744     4.1314536333084106e-01
    z[4,5,3]  R1745     -1.8382082879543304e-01
    z[4,5,3]  R1746     5.0531368702650070e-02
    z[4,5,3]  R1747     -4.7703683376312256e-02
    z[4,5,3]  R1748     7.3058776557445526e-02
    z[4,5,3]  R1749     6.2073368579149246e-02
    z[4,5,3]  R1750     -1.0537737607955933e-01
    z[4,5,3]  R1751     -1.1009852588176727e-01
    z[4,5,3]  R1752     -1.0544041544198990e-01
    z[4,5,3]  R1753     3.4839308261871338e-01
    z[4,5,3]  R1754     -9.7356185317039490e-02
    z[4,5,3]  R1755     7.9540932178497314e-01
    z[4,5,3]  R1756     9.0241980552673340e-01
    z[4,5,3]  R1757     7.6731526851654053e-01
    z[4,5,3]  R1758     4.5390194654464722e-01
    z[4,5,3]  R1759     7.6387959718704224e-01
    z[4,5,3]  R1760     7.3146307468414307e-01
    z[4,5,3]  R1761     8.1268757581710815e-01
    z[4,5,3]  R1762     0.729589581489563
    z[4,5,3]  R1763     9.1657906770706177e-01
    z[4,5,3]  R1764     8.6012172698974609e-01
    z[4,5,3]  R1765     1.6754928231239319e-01
    z[4,5,3]  R1766     1.0054871439933777e-01
    z[4,5,3]  R1767     0.241428405046463
    z[4,5,3]  R1768     4.9155864119529724e-01
    z[4,5,3]  R1769     6.8617177009582520e-01
    z[4,5,3]  R1770     5.5428307503461838e-02
    z[4,5,3]  R1771     6.7632216215133667e-01
    z[4,5,3]  R1772     0.325797438621521
    z[4,5,3]  R1773     3.2319170236587524e-01
    z[4,5,3]  R1774     1.0108335316181183e-01
    z[4,5,4]  R42       -1
    z[4,5,4]  R51       1
    z[4,5,4]  R1669     -1
    z[4,5,4]  R1670     1
    z[4,5,4]  R1675     1.7594453692436218e-01
    z[4,5,4]  R1676     2.6468461751937866e-01
    z[4,5,4]  R1677     -8.4509648382663727e-02
    z[4,5,4]  R1678     1.7926141619682312e-01
    z[4,5,4]  R1679     1.1906246095895767e-01
    z[4,5,4]  R1680     -1.5413333475589752e-01
    z[4,5,4]  R1681     2.1042092144489288e-01
    z[4,5,4]  R1682     -1.7308202385902405e-01
    z[4,5,4]  R1683     -2.1921980381011963e-01
    z[4,5,4]  R1684     -1.5550107927992940e-03
    z[4,5,4]  R1685     -1.2728112936019897e-01
    z[4,5,4]  R1686     4.4021272659301758e-01
    z[4,5,4]  R1687     3.7656059861183167e-01
    z[4,5,4]  R1688     0.293820321559906
    z[4,5,4]  R1689     2.9863053560256958e-01
    z[4,5,4]  R1690     -1.9770273566246033e-01
    z[4,5,4]  R1691     3.4514042735099792e-01
    z[4,5,4]  R1692     3.7323823571205139e-01
    z[4,5,4]  R1693     -3.2541158795356750e-01
    z[4,5,4]  R1694     2.5673272088170052e-02
    z[4,5,4]  R1695     -1.8125078082084656e-01
    z[4,5,4]  R1696     1.7340712249279022e-01
    z[4,5,4]  R1697     9.8382413387298584e-02
    z[4,5,4]  R1698     3.0576035380363464e-01
    z[4,5,4]  R1699     3.2145464420318604e-01
    z[4,5,4]  R1700     1.4233171939849854e-01
    z[4,5,4]  R1701     -2.2503726184368134e-01
    z[4,5,4]  R1702     -2.6704880595207214e-01
    z[4,5,4]  R1703     -3.6939030885696411e-01
    z[4,5,4]  R1704     -1.3780309259891510e-01
    z[4,5,4]  R1705     5.5130505561828613e-01
    z[4,5,4]  R1706     3.3232355117797852e-01
    z[4,5,4]  R1707     5.5513274669647217e-01
    z[4,5,4]  R1708     3.6872851848602295e-01
    z[4,5,4]  R1709     -3.5058757662773132e-01
    z[4,5,4]  R1710     -2.2812278568744659e-01
    z[4,5,4]  R1711     0.24508036673069
    z[4,5,4]  R1712     9.6251070499420166e-02
    z[4,5,4]  R1713     1.5524534881114960e-01
    z[4,5,4]  R1714     -2.3286515474319458e-01
    z[4,5,4]  R1715     6.7009791731834412e-02
    z[4,5,4]  R1716     4.9650236964225769e-02
    z[4,5,4]  R1717     3.7223309278488159e-01
    z[4,5,4]  R1718     0.444194495677948
    z[4,5,4]  R1719     7.9294638708233833e-03
    z[4,5,4]  R1720     5.3112413734197617e-02
    z[4,5,4]  R1721     1.0073860734701157e-01
    z[4,5,4]  R1722     -1.8034411966800690e-01
    z[4,5,4]  R1723     4.9704242497682571e-02
    z[4,5,4]  R1724     -0.199087455868721
    z[4,5,4]  R1725     3.1745424866676331e-01
    z[4,5,4]  R1726     1.5100608766078949e-01
    z[4,5,4]  R1727     -3.3366572111845016e-02
    z[4,5,4]  R1728     2.5212485343217850e-02
    z[4,5,4]  R1729     6.1498713493347168e-01
    z[4,5,4]  R1730     5.4473882913589478e-01
    z[4,5,4]  R1731     -5.6062227487564087e-01
    z[4,5,4]  R1732     4.1211530566215515e-01
    z[4,5,4]  R1733     -2.3611399531364441e-01
    z[4,5,4]  R1734     -0.600864052772522
    z[4,5,4]  R1735     1.2062467634677887e-01
    z[4,5,4]  R1736     2.7103051543235779e-03
    z[4,5,4]  R1737     -1.8362168967723846e-01
    z[4,5,4]  R1738     1.9852147996425629e-01
    z[4,5,4]  R1739     -1.8536148965358734e-01
    z[4,5,4]  R1740     1.7913419753313065e-02
    z[4,5,4]  R1741     -1.5416552312672138e-02
    z[4,5,4]  R1742     5.2506614476442337e-02
    z[4,5,4]  R1743     -1.8905505537986755e-01
    z[4,5,4]  R1744     -1.3442958891391754e-01
    z[4,5,4]  R1745     1.0738671571016312e-01
    z[4,5,4]  R1746     1.3071611523628235e-01
    z[4,5,4]  R1747     -2.6124227046966553e-01
    z[4,5,4]  R1748     1.3985583186149597e-01
    z[4,5,4]  R1749     1.9706407189369202e-01
    z[4,5,4]  R1750     2.5986665487289429e-01
    z[4,5,4]  R1751     -1.3944509625434875e-01
    z[4,5,4]  R1752     -3.5721737146377563e-01
    z[4,5,4]  R1753     4.8260069452226162e-03
    z[4,5,4]  R1754     -1.7051011323928833e-01
    z[4,5,4]  R1755     -1.7310780286788940e-01
    z[4,5,4]  R1756     1.7404425144195557e-01
    z[4,5,4]  R1757     2.8719502687454224e-01
    z[4,5,4]  R1758     3.1693622469902039e-01
    z[4,5,4]  R1759     -8.1531301140785217e-02
    z[4,5,4]  R1760     3.3749639987945557e-04
    z[4,5,4]  R1761     -2.8895176947116852e-02
    z[4,5,4]  R1762     2.4756672978401184e-01
    z[4,5,4]  R1763     -1.2850125133991241e-01
    z[4,5,4]  R1764     1.2128808349370956e-01
    z[4,5,4]  R1765     -6.8351209163665771e-02
    z[4,5,4]  R1766     -2.2629013657569885e-01
    z[4,5,4]  R1767     -4.3072330951690674e-01
    z[4,5,4]  R1768     3.0957112088799477e-02
    z[4,5,4]  R1769     -2.9939287900924683e-01
    z[4,5,4]  R1770     -1.8057155609130859e-01
    z[4,5,4]  R1771     4.8926612734794617e-01
    z[4,5,4]  R1772     -1.1993906646966934e-01
    z[4,5,4]  R1773     -2.6092376559972763e-02
    z[4,5,4]  R1774     -3.5483011603355408e-01
    z[4,5,5]  R43       -1
    z[4,5,5]  R52       1
    z[4,5,5]  R1671     -1
    z[4,5,5]  R1672     1
    z[4,5,5]  R1675     7.1452908217906952e-02
    z[4,5,5]  R1676     3.5677134990692139e-01
    z[4,5,5]  R1677     2.7081233263015747e-01
    z[4,5,5]  R1678     1.2114244699478149e-01
    z[4,5,5]  R1679     2.8844168782234192e-01
    z[4,5,5]  R1680     -1.7791172862052917e-01
    z[4,5,5]  R1681     -1.4570856094360352e-01
    z[4,5,5]  R1682     -2.2133085131645203e-01
    z[4,5,5]  R1683     -3.6881619691848755e-01
    z[4,5,5]  R1684     -4.7811937332153320e-01
    z[4,5,5]  R1685     3.1066227704286575e-02
    z[4,5,5]  R1686     1.8571242690086365e-01
    z[4,5,5]  R1687     -2.9998105764389038e-01
    z[4,5,5]  R1688     0.337121844291687
    z[4,5,5]  R1689     -2.7562108635902405e-01
    z[4,5,5]  R1690     3.5566347837448120e-01
    z[4,5,5]  R1691     -1.8380945920944214e-01
    z[4,5,5]  R1692     -7.1242645382881165e-02
    z[4,5,5]  R1693     -5.2340172231197357e-02
    z[4,5,5]  R1694     2.8898137807846069e-01
    z[4,5,5]  R1695     -3.9129644632339478e-01
    z[4,5,5]  R1696     -0.0736314207315445
    z[4,5,5]  R1697     1.8468746542930603e-01
    z[4,5,5]  R1698     -2.2853343188762665e-01
    z[4,5,5]  R1699     1.2016015499830246e-01
    z[4,5,5]  R1700     -5.9180450439453125e-01
    z[4,5,5]  R1701     -1.2782792747020721e-01
    z[4,5,5]  R1702     5.0256609916687012e-01
    z[4,5,5]  R1703     2.6800256967544556e-01
    z[4,5,5]  R1704     -3.1151911243796349e-02
    z[4,5,5]  R1705     -1.4227263629436493e-01
    z[4,5,5]  R1706     1.1875028163194656e-01
    z[4,5,5]  R1707     -2.9758533835411072e-01
    z[4,5,5]  R1708     -3.4854629635810852e-01
    z[4,5,5]  R1709     -5.7962417602539062e-01
    z[4,5,5]  R1710     4.2994111776351929e-01
    z[4,5,5]  R1711     1.0444504767656326e-01
    z[4,5,5]  R1712     -2.2317662835121155e-01
    z[4,5,5]  R1713     1.7396973073482513e-01
    z[4,5,5]  R1714     4.5839063823223114e-02
    z[4,5,5]  R1715     1.9528928399085999e-01
    z[4,5,5]  R1716     -2.0145791769027710e-01
    z[4,5,5]  R1717     1.7320029437541962e-02
    z[4,5,5]  R1718     4.0903955698013306e-01
    z[4,5,5]  R1719     9.8281085491180420e-02
    z[4,5,5]  R1720     3.0730363726615906e-01
    z[4,5,5]  R1721     5.3372409194707870e-02
    z[4,5,5]  R1722     -1.8346744775772095e-01
    z[4,5,5]  R1723     -3.3059573173522949e-01
    z[4,5,5]  R1724     1.0094561427831650e-01
    z[4,5,5]  R1725     4.3785876035690308e-01
    z[4,5,5]  R1726     6.6495560109615326e-02
    z[4,5,5]  R1727     9.5870628952980042e-02
    z[4,5,5]  R1728     -5.5189430713653564e-01
    z[4,5,5]  R1729     -2.6647770404815674e-01
    z[4,5,5]  R1730     -5.6386363506317139e-01
    z[4,5,5]  R1731     -0.0724416971206665
    z[4,5,5]  R1732     2.3566253483295441e-01
    z[4,5,5]  R1733     1.8732255324721336e-02
    z[4,5,5]  R1734     1.3279426097869873e-01
    z[4,5,5]  R1735     -2.3404514417052269e-02
    z[4,5,5]  R1736     2.1368764340877533e-01
    z[4,5,5]  R1737     -2.6740193367004395e-01
    z[4,5,5]  R1738     4.6200025826692581e-02
    z[4,5,5]  R1739     -1.7845694720745087e-01
    z[4,5,5]  R1740     6.7630611360073090e-02
    z[4,5,5]  R1741     1.6359809041023254e-01
    z[4,5,5]  R1742     3.9603692293167114e-01
    z[4,5,5]  R1743     2.8254750370979309e-01
    z[4,5,5]  R1744     -5.0018376111984253e-01
    z[4,5,5]  R1745     4.6970881521701813e-02
    z[4,5,5]  R1746     -8.5598759353160858e-02
    z[4,5,5]  R1747     -1.7107465537264943e-03
    z[4,5,5]  R1748     2.8520816564559937e-01
    z[4,5,5]  R1749     2.7119019627571106e-01
    z[4,5,5]  R1750     1.1809702217578888e-01
    z[4,5,5]  R1751     2.9165685176849365e-01
    z[4,5,5]  R1752     2.0493675768375397e-01
    z[4,5,5]  R1753     1.4271101355552673e-01
    z[4,5,5]  R1754     -1.5288364887237549e-01
    z[4,5,5]  R1755     -9.8025634884834290e-02
    z[4,5,5]  R1756     3.1905624270439148e-01
    z[4,5,5]  R1757     5.2297419309616089e-01
    z[4,5,5]  R1758     5.7966765016317368e-02
    z[4,5,5]  R1759     5.9351056814193726e-01
    z[4,5,5]  R1760     6.4435964822769165e-01
    z[4,5,5]  R1761     3.3072790503501892e-01
    z[4,5,5]  R1762     2.7507367730140686e-01
    z[4,5,5]  R1763     3.1214219331741333e-01
    z[4,5,5]  R1764     2.7602595090866089e-01
    z[4,5,5]  R1765     6.4252525568008423e-01
    z[4,5,5]  R1766     -6.9482362270355225e-01
    z[4,5,5]  R1767     -4.7868281602859497e-01
    z[4,5,5]  R1768     -2.6825106143951416e-01
    z[4,5,5]  R1769     -4.0879970788955688e-01
    z[4,5,5]  R1770     1.0618981719017029e-01
    z[4,5,5]  R1771     -2.7660626173019409e-01
    z[4,5,5]  R1772     -0.265129953622818
    z[4,5,5]  R1773     -0.184409961104393
    z[4,5,5]  R1774     -1.3089528679847717e-01
    z[4,5,6]  R44       -1
    z[4,5,6]  R53       1
    z[4,5,6]  R1673     -1
    z[4,5,6]  R1674     1
    z[4,5,6]  R1675     -3.1818527728319168e-02
    z[4,5,6]  R1676     1.4064137637615204e-01
    z[4,5,6]  R1677     2.0764620602130890e-01
    z[4,5,6]  R1678     -1.0985297709703445e-01
    z[4,5,6]  R1679     -5.1133328676223755e-01
    z[4,5,6]  R1680     -3.3458021283149719e-01
    z[4,5,6]  R1681     -5.2544206380844116e-01
    z[4,5,6]  R1682     4.1002756357192993e-01
    z[4,5,6]  R1683     2.4528257548809052e-01
    z[4,5,6]  R1684     -8.0440282821655273e-02
    z[4,5,6]  R1685     6.4529007673263550e-01
    z[4,5,6]  R1686     4.0478876233100891e-01
    z[4,5,6]  R1687     4.3260720372200012e-01
    z[4,5,6]  R1688     -3.0164131522178650e-01
    z[4,5,6]  R1689     4.0131950378417969e-01
    z[4,5,6]  R1690     4.0527349710464478e-01
    z[4,5,6]  R1691     -5.7893428951501846e-02
    z[4,5,6]  R1692     -6.0330498218536377e-01
    z[4,5,6]  R1693     5.7394319772720337e-01
    z[4,5,6]  R1694     2.5136026740074158e-01
    z[4,5,6]  R1695     4.0686386823654175e-01
    z[4,5,6]  R1696     -2.2347070276737213e-01
    z[4,5,6]  R1697     -2.5894997641444206e-02
    z[4,5,6]  R1698     -3.1094381213188171e-01
    z[4,5,6]  R1699     -5.4116499423980713e-01
    z[4,5,6]  R1700     -4.4947916269302368e-01
    z[4,5,6]  R1701     -2.6228001341223717e-02
    z[4,5,6]  R1702     -8.0857515335083008e-02
    z[4,5,6]  R1703     1.3635386526584625e-01
    z[4,5,6]  R1704     5.9855472296476364e-02
    z[4,5,6]  R1705     2.6544073224067688e-01
    z[4,5,6]  R1706     3.6584597826004028e-01
    z[4,5,6]  R1707     0.0942707434296608
    z[4,5,6]  R1708     2.1030361950397491e-01
    z[4,5,6]  R1709     -3.1426653265953064e-02
    z[4,5,6]  R1710     -0.0619150847196579
    z[4,5,6]  R1711     -9.6823170781135559e-02
    z[4,5,6]  R1712     -1.0391784459352493e-01
    z[4,5,6]  R1713     -7.5780266523361206e-01
    z[4,5,6]  R1714     -1.5807080268859863e-01
    z[4,5,6]  R1715     1.6583777964115143e-01
    z[4,5,6]  R1716     -3.8994929194450378e-01
    z[4,5,6]  R1717     -4.0062373876571655e-01
    z[4,5,6]  R1718     -3.6320978403091431e-01
    z[4,5,6]  R1719     1.1026592552661896e-01
    z[4,5,6]  R1720     -5.2296765148639679e-02
    z[4,5,6]  R1721     1.8907051533460617e-02
    z[4,5,6]  R1722     -7.9683875665068626e-03
    z[4,5,6]  R1723     2.8325811028480530e-02
    z[4,5,6]  R1724     -7.2527416050434113e-02
    z[4,5,6]  R1725     8.0957688391208649e-02
    z[4,5,6]  R1726     -3.4397414326667786e-01
    z[4,5,6]  R1727     6.4615708589553833e-01
    z[4,5,6]  R1728     -2.3646888136863708e-01
    z[4,5,6]  R1729     -1.1964805424213409e-01
    z[4,5,6]  R1730     3.0197387933731079e-01
    z[4,5,6]  R1731     5.7622170448303223e-01
    z[4,5,6]  R1732     1.6219522058963776e-01
    z[4,5,6]  R1733     1.8480627238750458e-01
    z[4,5,6]  R1734     -5.5185484886169434e-01
    z[4,5,6]  R1735     -1.8415758013725281e-01
    z[4,5,6]  R1736     1.9979397952556610e-01
    z[4,5,6]  R1737     2.6502721011638641e-02
    z[4,5,6]  R1738     5.8454845100641251e-02
    z[4,5,6]  R1739     2.6878777146339417e-01
    z[4,5,6]  R1740     5.2808779478073120e-01
    z[4,5,6]  R1741     0.0251354668289423
    z[4,5,6]  R1742     5.8104624040424824e-03
    z[4,5,6]  R1743     1.8169216811656952e-01
    z[4,5,6]  R1744     -3.1947222352027893e-01
    z[4,5,6]  R1745     1.5235188184306026e-03
    z[4,5,6]  R1746     1.4149212837219238e-01
    z[4,5,6]  R1747     -1.9565482437610626e-01
    z[4,5,6]  R1748     1.0147751308977604e-02
    z[4,5,6]  R1749     1.7726825177669525e-01
    z[4,5,6]  R1750     1.1284652352333069e-01
    z[4,5,6]  R1751     2.0842906832695007e-01
    z[4,5,6]  R1752     1.7213482409715652e-02
    z[4,5,6]  R1753     1.8577785789966583e-01
    z[4,5,6]  R1754     2.8011232614517212e-01
    z[4,5,6]  R1755     -2.3333968222141266e-01
    z[4,5,6]  R1756     -8.0126136541366577e-02
    z[4,5,6]  R1757     1.1936999112367630e-01
    z[4,5,6]  R1758     -0.127571240067482
    z[4,5,6]  R1759     -7.4037462472915649e-02
    z[4,5,6]  R1760     3.6459332332015038e-03
    z[4,5,6]  R1761     -6.6365584731101990e-02
    z[4,5,6]  R1762     -7.7897600829601288e-02
    z[4,5,6]  R1763     3.7438657134771347e-02
    z[4,5,6]  R1764     3.0738350749015808e-01
    z[4,5,6]  R1765     -2.0351428538560867e-02
    z[4,5,6]  R1766     7.8848786652088165e-02
    z[4,5,6]  R1767     -1.6353467106819153e-01
    z[4,5,6]  R1768     -1.4448726177215576e-01
    z[4,5,6]  R1769     -1.6862553358078003e-01
    z[4,5,6]  R1770     -1.4177618920803070e-01
    z[4,5,6]  R1771     -1.6087600588798523e-01
    z[4,5,6]  R1772     -2.5461369752883911e-01
    z[4,5,6]  R1773     2.0681983232498169e-01
    z[4,5,6]  R1774     -4.7515518963336945e-02
    z[5,4,0]  R38       1
    z[5,4,0]  R47       -1
    z[5,4,0]  R1775     -1
    z[5,4,0]  R1776     1
    z[5,4,0]  R1789     0.290393203496933
    z[5,4,0]  R1790     1.1789184808731079e-01
    z[5,4,0]  R1791     4.6540299057960510e-01
    z[5,4,0]  R1792     -2.3550014197826385e-01
    z[5,4,0]  R1793     0.0439508818089962
    z[5,4,0]  R1794     7.0555157959461212e-02
    z[5,4,0]  R1795     1.8429741263389587e-01
    z[5,4,0]  R1796     -1.2201659381389618e-01
    z[5,4,0]  R1797     -1.9457355141639709e-02
    z[5,4,0]  R1798     -2.6659536361694336e-01
    z[5,4,0]  R1799     -8.8465720415115356e-01
    z[5,4,0]  R1800     -8.8275516033172607e-01
    z[5,4,0]  R1801     -8.3729118108749390e-01
    z[5,4,0]  R1802     -8.3234339952468872e-01
    z[5,4,0]  R1803     -8.2923251390457153e-01
    z[5,4,0]  R1804     -8.2676589488983154e-01
    z[5,4,0]  R1805     -8.2746756076812744e-01
    z[5,4,0]  R1806     -7.9120177030563354e-01
    z[5,4,0]  R1807     -7.5296068191528320e-01
    z[5,4,0]  R1808     2.5739872455596924e-01
    z[5,4,0]  R1809     1.2290877103805542e-01
    z[5,4,0]  R1810     8.6141891777515411e-02
    z[5,4,0]  R1811     -8.3922937512397766e-02
    z[5,4,0]  R1812     1.2700876593589783e-01
    z[5,4,0]  R1813     1.8221594393253326e-01
    z[5,4,0]  R1814     -6.2401881441473961e-03
    z[5,4,0]  R1815     2.1518439054489136e-01
    z[5,4,0]  R1816     1.5994463860988617e-01
    z[5,4,0]  R1817     1.6754741966724396e-01
    z[5,4,0]  R1818     1.8137775361537933e-01
    z[5,4,0]  R1819     5.9688808396458626e-03
    z[5,4,0]  R1820     2.1250111982226372e-02
    z[5,4,0]  R1821     6.2775678932666779e-02
    z[5,4,0]  R1822     3.7722158432006836e-01
    z[5,4,0]  R1823     1.1136939376592636e-01
    z[5,4,0]  R1824     1.2851694226264954e-01
    z[5,4,0]  R1825     -4.2825754731893539e-02
    z[5,4,0]  R1826     -1.4160597324371338e-01
    z[5,4,0]  R1827     1.8544195592403412e-01
    z[5,4,0]  R1828     1.0569975525140762e-01
    z[5,4,0]  R1829     -3.0331939458847046e-01
    z[5,4,0]  R1830     3.3793774247169495e-01
    z[5,4,0]  R1831     3.0217203497886658e-01
    z[5,4,0]  R1832     4.0725100040435791e-01
    z[5,4,0]  R1833     1.4683434367179871e-01
    z[5,4,0]  R1834     6.0486119985580444e-01
    z[5,4,0]  R1835     -1.9973242655396461e-02
    z[5,4,0]  R1836     5.2902978658676147e-01
    z[5,4,0]  R1837     3.6606675386428833e-01
    z[5,4,0]  R1838     -1.0453700087964535e-02
    z[5,4,0]  R1839     -9.5272815227508545e-01
    z[5,4,0]  R1840     -6.5755039453506470e-01
    z[5,4,0]  R1841     -7.4672192335128784e-01
    z[5,4,0]  R1842     -5.6827926635742188e-01
    z[5,4,0]  R1843     -0.697720468044281
    z[5,4,0]  R1844     -8.0624312162399292e-01
    z[5,4,0]  R1845     -7.0575207471847534e-01
    z[5,4,0]  R1846     -7.9680454730987549e-01
    z[5,4,0]  R1847     -6.2853616476058960e-01
    z[5,4,0]  R1848     -6.3414430618286133e-01
    z[5,4,0]  R1849     4.7217079997062683e-01
    z[5,4,0]  R1850     4.8192718625068665e-01
    z[5,4,0]  R1851     5.3638529777526855e-01
    z[5,4,0]  R1852     5.5831915140151978e-01
    z[5,4,0]  R1853     3.1635567545890808e-01
    z[5,4,0]  R1854     3.6004063487052917e-01
    z[5,4,0]  R1855     4.6988460421562195e-01
    z[5,4,0]  R1856     4.5945248007774353e-01
    z[5,4,0]  R1857     6.3387542963027954e-01
    z[5,4,0]  R1858     7.6060456037521362e-01
    z[5,4,0]  R1859     7.5892186164855957e-01
    z[5,4,0]  R1860     8.2507163286209106e-01
    z[5,4,0]  R1861     0.69380784034729
    z[5,4,0]  R1862     7.7515572309494019e-01
    z[5,4,0]  R1863     5.9738069772720337e-01
    z[5,4,0]  R1864     4.7916504740715027e-01
    z[5,4,0]  R1865     1.2520797550678253e-01
    z[5,4,0]  R1866     0.694004237651825
    z[5,4,0]  R1867     -1.4771226048469543e-01
    z[5,4,0]  R1868     -3.7355810403823853e-02
    z[5,4,0]  R1869     6.8568706512451172e-01
    z[5,4,0]  R1870     7.5445693731307983e-01
    z[5,4,0]  R1871     5.5920267105102539e-01
    z[5,4,0]  R1872     4.9857971072196960e-01
    z[5,4,0]  R1873     4.4080206751823425e-01
    z[5,4,0]  R1874     5.3665673732757568e-01
    z[5,4,0]  R1875     7.3393128812313080e-02
    z[5,4,0]  R1876     6.6152709722518921e-01
    z[5,4,0]  R1877     4.3288326263427734e-01
    z[5,4,0]  R1878     -1.9117283821105957e-01
    z[5,4,0]  R1879     9.3395346403121948e-01
    z[5,4,0]  R1880     8.2453894615173340e-01
    z[5,4,0]  R1881     6.0545265674591064e-01
    z[5,4,0]  R1882     6.8986546993255615e-01
    z[5,4,0]  R1883     5.1483350992202759e-01
    z[5,4,0]  R1884     4.2101282626390457e-02
    z[5,4,0]  R1885     7.5327016413211823e-02
    z[5,4,0]  R1886     -1.8716026842594147e-01
    z[5,4,0]  R1887     -2.4608166888356209e-02
    z[5,4,0]  R1888     -1.4167489111423492e-01
    z[5,4,1]  R39       1
    z[5,4,1]  R48       -1
    z[5,4,1]  R1777     -1
    z[5,4,1]  R1778     1
    z[5,4,1]  R1789     -5.4126262664794922e-01
    z[5,4,1]  R1790     -0.527815043926239
    z[5,4,1]  R1791     -4.0310895442962646e-01
    z[5,4,1]  R1792     -5.1441872119903564e-01
    z[5,4,1]  R1793     -3.0516985058784485e-01
    z[5,4,1]  R1794     -5.3298741579055786e-01
    z[5,4,1]  R1795     -5.1865673065185547e-01
    z[5,4,1]  R1796     -2.9804956912994385e-01
    z[5,4,1]  R1797     -1.1388030648231506e-01
    z[5,4,1]  R1798     -3.3869579434394836e-01
    z[5,4,1]  R1799     2.4482125043869019e-01
    z[5,4,1]  R1800     -5.7958744466304779e-02
    z[5,4,1]  R1801     2.7509590983390808e-01
    z[5,4,1]  R1802     2.9442688822746277e-01
    z[5,4,1]  R1803     2.1309331059455872e-01
    z[5,4,1]  R1804     9.9954180419445038e-02
    z[5,4,1]  R1805     1.0732129961252213e-01
    z[5,4,1]  R1806     2.8265592455863953e-01
    z[5,4,1]  R1807     2.1035017073154449e-01
    z[5,4,1]  R1808     3.1727030873298645e-01
    z[5,4,1]  R1809     9.6432214975357056e-01
    z[5,4,1]  R1810     9.6649235486984253e-01
    z[5,4,1]  R1811     9.3329089879989624e-01
    z[5,4,1]  R1812     9.3658292293548584e-01
    z[5,4,1]  R1813     9.0506297349929810e-01
    z[5,4,1]  R1814     9.1943162679672241e-01
    z[5,4,1]  R1815     8.8576912879943848e-01
    z[5,4,1]  R1816     8.7752628326416016e-01
    z[5,4,1]  R1817     8.8975477218627930e-01
    z[5,4,1]  R1818     9.0900379419326782e-01
    z[5,4,1]  R1819     -5.1484632492065430e-01
    z[5,4,1]  R1820     -1.8647789955139160e-01
    z[5,4,1]  R1821     -3.6952864378690720e-02
    z[5,4,1]  R1822     5.3254729509353638e-01
    z[5,4,1]  R1823     1.9414755702018738e-01
    z[5,4,1]  R1824     1.8129315972328186e-01
    z[5,4,1]  R1825     -4.4702622294425964e-01
    z[5,4,1]  R1826     -4.6301969885826111e-01
    z[5,4,1]  R1827     8.1563852727413177e-02
    z[5,4,1]  R1828     -1.2047359347343445e-01
    z[5,4,1]  R1829     -4.7547608613967896e-01
    z[5,4,1]  R1830     2.9762217402458191e-01
    z[5,4,1]  R1831     0.292923241853714
    z[5,4,1]  R1832     3.3576118946075439e-01
    z[5,4,1]  R1833     -3.5782107710838318e-01
    z[5,4,1]  R1834     -1.0087995976209641e-01
    z[5,4,1]  R1835     4.2413991689682007e-01
    z[5,4,1]  R1836     -1.9266135990619659e-01
    z[5,4,1]  R1837     8.0619163811206818e-02
    z[5,4,1]  R1838     5.3010061383247375e-02
    z[5,4,1]  R1839     2.3143243044614792e-02
    z[5,4,1]  R1840     -0.0182262621819973
    z[5,4,1]  R1841     -5.7639140635728836e-02
    z[5,4,1]  R1842     -2.4348567426204681e-01
    z[5,4,1]  R1843     -1.9047854840755463e-01
    z[5,4,1]  R1844     -2.0784406363964081e-01
    z[5,4,1]  R1845     1.7566837370395660e-02
    z[5,4,1]  R1846     -2.8242090344429016e-01
    z[5,4,1]  R1847     -2.1849890053272247e-01
    z[5,4,1]  R1848     -2.5236135721206665e-01
    z[5,4,1]  R1849     -2.2388954460620880e-01
    z[5,4,1]  R1850     -3.6125013232231140e-01
    z[5,4,1]  R1851     -2.9774361848831177e-01
    z[5,4,1]  R1852     -4.0703916549682617e-01
    z[5,4,1]  R1853     -1.4761309325695038e-01
    z[5,4,1]  R1854     -7.2857493162155151e-01
    z[5,4,1]  R1855     -1.8686607480049133e-01
    z[5,4,1]  R1856     -2.0314499735832214e-01
    z[5,4,1]  R1857     -2.7796500921249390e-01
    z[5,4,1]  R1858     -2.6957890391349792e-01
    z[5,4,1]  R1859     -2.6112228631973267e-01
    z[5,4,1]  R1860     2.5459733605384827e-01
    z[5,4,1]  R1861     -5.5696594715118408e-01
    z[5,4,1]  R1862     -3.5624718666076660e-01
    z[5,4,1]  R1863     -3.3118823170661926e-01
    z[5,4,1]  R1864     1.8527182936668396e-01
    z[5,4,1]  R1865     -8.8961702585220337e-01
    z[5,4,1]  R1866     1.8973752856254578e-01
    z[5,4,1]  R1867     -4.8082154989242554e-01
    z[5,4,1]  R1868     9.8477828502655029e-01
    z[5,4,1]  R1869     1.2013015151023865e-01
    z[5,4,1]  R1870     -2.5330534577369690e-01
    z[5,4,1]  R1871     -7.9348884522914886e-02
    z[5,4,1]  R1872     -3.7134587764739990e-01
    z[5,4,1]  R1873     -1.4715818688273430e-02
    z[5,4,1]  R1874     -2.4932594597339630e-01
    z[5,4,1]  R1875     -9.3254148960113525e-01
    z[5,4,1]  R1876     1.9009114801883698e-01
    z[5,4,1]  R1877     6.9467514753341675e-02
    z[5,4,1]  R1878     -8.2899713516235352e-01
    z[5,4,1]  R1879     -2.2529418766498566e-01
    z[5,4,1]  R1880     -2.6308485865592957e-01
    z[5,4,1]  R1881     -1.4774477481842041e-01
    z[5,4,1]  R1882     9.8536713048815727e-03
    z[5,4,1]  R1883     -2.4957950413227081e-01
    z[5,4,1]  R1884     -0.924492597579956
    z[5,4,1]  R1885     9.8405432701110840e-01
    z[5,4,1]  R1886     9.2263603210449219e-01
    z[5,4,1]  R1887     9.3988919258117676e-01
    z[5,4,1]  R1888     9.3019974231719971e-01
    z[5,4,2]  R40       1
    z[5,4,2]  R49       -1
    z[5,4,2]  R1779     -1
    z[5,4,2]  R1780     1
    z[5,4,2]  R1789     5.0011879205703735e-01
    z[5,4,2]  R1790     5.7912456989288330e-01
    z[5,4,2]  R1791     4.1385686397552490e-01
    z[5,4,2]  R1792     4.1221617721021175e-03
    z[5,4,2]  R1793     2.9576846957206726e-01
    z[5,4,2]  R1794     1.0213791392743587e-02
    z[5,4,2]  R1795     7.9286046326160431e-02
    z[5,4,2]  R1796     -1.4119987189769745e-01
    z[5,4,2]  R1797     7.5469903647899628e-02
    z[5,4,2]  R1798     8.5755802690982819e-02
    z[5,4,2]  R1799     1.5370386838912964e-01
    z[5,4,2]  R1800     -4.9505002796649933e-02
    z[5,4,2]  R1801     -1.8806798756122589e-01
    z[5,4,2]  R1802     -3.7738022208213806e-01
    z[5,4,2]  R1803     -6.8416267633438110e-02
    z[5,4,2]  R1804     -0.0820479691028595
    z[5,4,2]  R1805     -3.6171787977218628e-01
    z[5,4,2]  R1806     -3.1313976645469666e-01
    z[5,4,2]  R1807     4.4587758183479309e-01
    z[5,4,2]  R1808     5.4044306278228760e-01
    z[5,4,2]  R1809     8.6287543177604675e-02
    z[5,4,2]  R1810     -1.0716758668422699e-01
    z[5,4,2]  R1811     -1.1453446745872498e-01
    z[5,4,2]  R1812     1.8362710252404213e-02
    z[5,4,2]  R1813     1.6968338750302792e-03
    z[5,4,2]  R1814     -2.2201403975486755e-01
    z[5,4,2]  R1815     9.5056831836700439e-02
    z[5,4,2]  R1816     1.5280073881149292e-01
    z[5,4,2]  R1817     -6.3114441931247711e-02
    z[5,4,2]  R1818     2.0639857277274132e-02
    z[5,4,2]  R1819     9.0547293424606323e-02
    z[5,4,2]  R1820     -1.0910715162754059e-01
    z[5,4,2]  R1821     -1.8891464173793793e-01
    z[5,4,2]  R1822     4.9798309803009033e-01
    z[5,4,2]  R1823     4.4809807091951370e-02
    z[5,4,2]  R1824     -1.9111575558781624e-02
    z[5,4,2]  R1825     -1.5248617529869080e-01
    z[5,4,2]  R1826     -3.0039435625076294e-01
    z[5,4,2]  R1827     5.9113286435604095e-02
    z[5,4,2]  R1828     -2.2162710130214691e-01
    z[5,4,2]  R1829     -4.8571833968162537e-01
    z[5,4,2]  R1830     4.9689537286758423e-01
    z[5,4,2]  R1831     5.6850421428680420e-01
    z[5,4,2]  R1832     6.2127900123596191e-01
    z[5,4,2]  R1833     3.0722004175186157e-01
    z[5,4,2]  R1834     -7.4626475572586060e-01
    z[5,4,2]  R1835     -1.4325246214866638e-01
    z[5,4,2]  R1836     -6.5372610092163086e-01
    z[5,4,2]  R1837     -8.2315278053283691e-01
    z[5,4,2]  R1838     -9.1736966371536255e-01
    z[5,4,2]  R1839     -1.3083437085151672e-01
    z[5,4,2]  R1840     2.2364251315593719e-02
    z[5,4,2]  R1841     1.8938867747783661e-01
    z[5,4,2]  R1842     2.9510036110877991e-01
    z[5,4,2]  R1843     2.1735161542892456e-01
    z[5,4,2]  R1844     3.0615091323852539e-01
    z[5,4,2]  R1845     0.246908500790596
    z[5,4,2]  R1846     -1.1430247128009796e-01
    z[5,4,2]  R1847     2.8599098324775696e-01
    z[5,4,2]  R1848     2.8773880004882812e-01
    z[5,4,2]  R1849     -4.3195471167564392e-01
    z[5,4,2]  R1850     -4.9419918656349182e-01
    z[5,4,2]  R1851     -1.1149150878190994e-01
    z[5,4,2]  R1852     -3.0816671252250671e-01
    z[5,4,2]  R1853     -6.4465612173080444e-01
    z[5,4,2]  R1854     -9.4892911612987518e-02
    z[5,4,2]  R1855     -5.4666769504547119e-01
    z[5,4,2]  R1856     -2.1985243260860443e-01
    z[5,4,2]  R1857     1.8002183735370636e-01
    z[5,4,2]  R1858     2.0883961021900177e-01
    z[5,4,2]  R1859     0.0620284229516983
    z[5,4,2]  R1860     3.3178892731666565e-01
    z[5,4,2]  R1861     -2.5202444195747375e-01
    z[5,4,2]  R1862     -7.3056198656558990e-02
    z[5,4,2]  R1863     2.6410454511642456e-01
    z[5,4,2]  R1864     -1.9367748871445656e-02
    z[5,4,2]  R1865     2.7567037940025330e-01
    z[5,4,2]  R1866     5.5395156145095825e-02
    z[5,4,2]  R1867     -3.5112449526786804e-01
    z[5,4,2]  R1868     1.4774592593312263e-02
    z[5,4,2]  R1869     -3.2486429810523987e-01
    z[5,4,2]  R1870     -3.2689192891120911e-01
    z[5,4,2]  R1871     -4.9133110046386719e-01
    z[5,4,2]  R1872     -0.49920454621315
    z[5,4,2]  R1873     -3.4168452024459839e-02
    z[5,4,2]  R1874     -2.0973436534404755e-01
    z[5,4,2]  R1875     -0.209557443857193
    z[5,4,2]  R1876     -3.0824416875839233e-01
    z[5,4,2]  R1877     4.1353002190589905e-02
    z[5,4,2]  R1878     -1.6549435257911682e-01
    z[5,4,2]  R1879     3.0575854703783989e-02
    z[5,4,2]  R1880     1.6815306246280670e-01
    z[5,4,2]  R1881     -3.1875157356262207e-01
    z[5,4,2]  R1882     -1.3141167163848877e-01
    z[5,4,2]  R1883     -4.8377791047096252e-01
    z[5,4,2]  R1884     2.1243350580334663e-02
    z[5,4,2]  R1885     -4.4571772217750549e-02
    z[5,4,2]  R1886     7.3673419654369354e-02
    z[5,4,2]  R1887     4.2845621705055237e-02
    z[5,4,2]  R1888     2.4338749051094055e-01
    z[5,4,3]  R41       1
    z[5,4,3]  R50       -1
    z[5,4,3]  R1781     -1
    z[5,4,3]  R1782     1
    z[5,4,3]  R1789     -2.7117517590522766e-01
    z[5,4,3]  R1790     -4.7600927948951721e-01
    z[5,4,3]  R1791     -1.4765599370002747e-01
    z[5,4,3]  R1792     -5.6458425521850586e-01
    z[5,4,3]  R1793     -5.9491634368896484e-01
    z[5,4,3]  R1794     -7.0506691932678223e-02
    z[5,4,3]  R1795     -1.9790592789649963e-01
    z[5,4,3]  R1796     -7.9035305976867676e-01
    z[5,4,3]  R1797     -9.4377058744430542e-01
    z[5,4,3]  R1798     -3.5162830352783203e-01
    z[5,4,3]  R1799     2.9121702909469604e-01
    z[5,4,3]  R1800     3.5964709520339966e-01
    z[5,4,3]  R1801     2.8630918264389038e-01
    z[5,4,3]  R1802     1.8204185366630554e-01
    z[5,4,3]  R1803     3.5189661383628845e-01
    z[5,4,3]  R1804     0.126349076628685
    z[5,4,3]  R1805     3.8119003176689148e-01
    z[5,4,3]  R1806     1.9082163274288177e-01
    z[5,4,3]  R1807     2.0349277555942535e-01
    z[5,4,3]  R1808     4.1314536333084106e-01
    z[5,4,3]  R1809     -1.8382082879543304e-01
    z[5,4,3]  R1810     5.0531368702650070e-02
    z[5,4,3]  R1811     -4.7703683376312256e-02
    z[5,4,3]  R1812     7.3058776557445526e-02
    z[5,4,3]  R1813     6.2073368579149246e-02
    z[5,4,3]  R1814     -1.0537737607955933e-01
    z[5,4,3]  R1815     -1.1009852588176727e-01
    z[5,4,3]  R1816     -1.0544041544198990e-01
    z[5,4,3]  R1817     3.4839308261871338e-01
    z[5,4,3]  R1818     -9.7356185317039490e-02
    z[5,4,3]  R1819     7.9540932178497314e-01
    z[5,4,3]  R1820     9.0241980552673340e-01
    z[5,4,3]  R1821     7.6731526851654053e-01
    z[5,4,3]  R1822     4.5390194654464722e-01
    z[5,4,3]  R1823     7.6387959718704224e-01
    z[5,4,3]  R1824     7.3146307468414307e-01
    z[5,4,3]  R1825     8.1268757581710815e-01
    z[5,4,3]  R1826     0.729589581489563
    z[5,4,3]  R1827     9.1657906770706177e-01
    z[5,4,3]  R1828     8.6012172698974609e-01
    z[5,4,3]  R1829     1.6754928231239319e-01
    z[5,4,3]  R1830     1.0054871439933777e-01
    z[5,4,3]  R1831     0.241428405046463
    z[5,4,3]  R1832     4.9155864119529724e-01
    z[5,4,3]  R1833     6.8617177009582520e-01
    z[5,4,3]  R1834     5.5428307503461838e-02
    z[5,4,3]  R1835     6.7632216215133667e-01
    z[5,4,3]  R1836     0.325797438621521
    z[5,4,3]  R1837     3.2319170236587524e-01
    z[5,4,3]  R1838     1.0108335316181183e-01
    z[5,4,3]  R1839     1.9385917484760284e-01
    z[5,4,3]  R1840     5.9133011102676392e-01
    z[5,4,3]  R1841     5.2878916263580322e-01
    z[5,4,3]  R1842     6.8688517808914185e-01
    z[5,4,3]  R1843     2.6613193750381470e-01
    z[5,4,3]  R1844     2.1375413239002228e-01
    z[5,4,3]  R1845     3.1471309065818787e-01
    z[5,4,3]  R1846     1.5877273678779602e-01
    z[5,4,3]  R1847     4.8079448938369751e-01
    z[5,4,3]  R1848     4.6509143710136414e-01
    z[5,4,3]  R1849     -3.2676982879638672e-01
    z[5,4,3]  R1850     2.9687242582440376e-02
    z[5,4,3]  R1851     4.3849018216133118e-01
    z[5,4,3]  R1852     -3.6967954039573669e-01
    z[5,4,3]  R1853     -3.6924713850021362e-01
    z[5,4,3]  R1854     2.6742484420537949e-02
    z[5,4,3]  R1855     -5.3775870800018311e-01
    z[5,4,3]  R1856     -4.3696826696395874e-01
    z[5,4,3]  R1857     2.2469219565391541e-01
    z[5,4,3]  R1858     3.9729416370391846e-01
    z[5,4,3]  R1859     2.2414935752749443e-02
    z[5,4,3]  R1860     2.4273928999900818e-01
    z[5,4,3]  R1861     -3.1692928075790405e-01
    z[5,4,3]  R1862     -1.5646527707576752e-01
    z[5,4,3]  R1863     2.3036557435989380e-01
    z[5,4,3]  R1864     -4.0395253896713257e-01
    z[5,4,3]  R1865     2.2190262377262115e-01
    z[5,4,3]  R1866     -3.8582831621170044e-01
    z[5,4,3]  R1867     -6.2994945049285889e-01
    z[5,4,3]  R1868     7.1100570261478424e-02
    z[5,4,3]  R1869     1.2340092658996582e-01
    z[5,4,3]  R1870     3.7269029766321182e-02
    z[5,4,3]  R1871     -1.8431878089904785e-01
    z[5,4,3]  R1872     -2.5028491020202637e-01
    z[5,4,3]  R1873     -0.586895227432251
    z[5,4,3]  R1874     -6.0425555706024170e-01
    z[5,4,3]  R1875     2.6788461953401566e-02
    z[5,4,3]  R1876     -6.0113370418548584e-01
    z[5,4,3]  R1877     -4.2124190926551819e-01
    z[5,4,3]  R1878     -0.409285306930542
    z[5,4,3]  R1879     7.6864279806613922e-02
    z[5,4,3]  R1880     -1.6593851149082184e-01
    z[5,4,3]  R1881     -4.5895448327064514e-01
    z[5,4,3]  R1882     -1.0087624192237854e-01
    z[5,4,3]  R1883     -6.4555007219314575e-01
    z[5,4,3]  R1884     2.0760118961334229e-01
    z[5,4,3]  R1885     -1.0306254029273987e-01
    z[5,4,3]  R1886     -2.0503188669681549e-01
    z[5,4,3]  R1887     -4.0007106959819794e-02
    z[5,4,3]  R1888     -1.8252540379762650e-02
    z[5,4,4]  R42       1
    z[5,4,4]  R51       -1
    z[5,4,4]  R1783     -1
    z[5,4,4]  R1784     1
    z[5,4,4]  R1789     3.1745424866676331e-01
    z[5,4,4]  R1790     1.5100608766078949e-01
    z[5,4,4]  R1791     -3.3366572111845016e-02
    z[5,4,4]  R1792     2.5212485343217850e-02
    z[5,4,4]  R1793     6.1498713493347168e-01
    z[5,4,4]  R1794     5.4473882913589478e-01
    z[5,4,4]  R1795     -5.6062227487564087e-01
    z[5,4,4]  R1796     4.1211530566215515e-01
    z[5,4,4]  R1797     -2.3611399531364441e-01
    z[5,4,4]  R1798     -0.600864052772522
    z[5,4,4]  R1799     1.2062467634677887e-01
    z[5,4,4]  R1800     2.7103051543235779e-03
    z[5,4,4]  R1801     -1.8362168967723846e-01
    z[5,4,4]  R1802     1.9852147996425629e-01
    z[5,4,4]  R1803     -1.8536148965358734e-01
    z[5,4,4]  R1804     1.7913419753313065e-02
    z[5,4,4]  R1805     -1.5416552312672138e-02
    z[5,4,4]  R1806     5.2506614476442337e-02
    z[5,4,4]  R1807     -1.8905505537986755e-01
    z[5,4,4]  R1808     -1.3442958891391754e-01
    z[5,4,4]  R1809     1.0738671571016312e-01
    z[5,4,4]  R1810     1.3071611523628235e-01
    z[5,4,4]  R1811     -2.6124227046966553e-01
    z[5,4,4]  R1812     1.3985583186149597e-01
    z[5,4,4]  R1813     1.9706407189369202e-01
    z[5,4,4]  R1814     2.5986665487289429e-01
    z[5,4,4]  R1815     -1.3944509625434875e-01
    z[5,4,4]  R1816     -3.5721737146377563e-01
    z[5,4,4]  R1817     4.8260069452226162e-03
    z[5,4,4]  R1818     -1.7051011323928833e-01
    z[5,4,4]  R1819     -1.7310780286788940e-01
    z[5,4,4]  R1820     1.7404425144195557e-01
    z[5,4,4]  R1821     2.8719502687454224e-01
    z[5,4,4]  R1822     3.1693622469902039e-01
    z[5,4,4]  R1823     -8.1531301140785217e-02
    z[5,4,4]  R1824     3.3749639987945557e-04
    z[5,4,4]  R1825     -2.8895176947116852e-02
    z[5,4,4]  R1826     2.4756672978401184e-01
    z[5,4,4]  R1827     -1.2850125133991241e-01
    z[5,4,4]  R1828     1.2128808349370956e-01
    z[5,4,4]  R1829     -6.8351209163665771e-02
    z[5,4,4]  R1830     -2.2629013657569885e-01
    z[5,4,4]  R1831     -4.3072330951690674e-01
    z[5,4,4]  R1832     3.0957112088799477e-02
    z[5,4,4]  R1833     -2.9939287900924683e-01
    z[5,4,4]  R1834     -1.8057155609130859e-01
    z[5,4,4]  R1835     4.8926612734794617e-01
    z[5,4,4]  R1836     -1.1993906646966934e-01
    z[5,4,4]  R1837     -2.6092376559972763e-02
    z[5,4,4]  R1838     -3.5483011603355408e-01
    z[5,4,4]  R1839     1.7594453692436218e-01
    z[5,4,4]  R1840     2.6468461751937866e-01
    z[5,4,4]  R1841     -8.4509648382663727e-02
    z[5,4,4]  R1842     1.7926141619682312e-01
    z[5,4,4]  R1843     1.1906246095895767e-01
    z[5,4,4]  R1844     -1.5413333475589752e-01
    z[5,4,4]  R1845     2.1042092144489288e-01
    z[5,4,4]  R1846     -1.7308202385902405e-01
    z[5,4,4]  R1847     -2.1921980381011963e-01
    z[5,4,4]  R1848     -1.5550107927992940e-03
    z[5,4,4]  R1849     -1.2728112936019897e-01
    z[5,4,4]  R1850     4.4021272659301758e-01
    z[5,4,4]  R1851     3.7656059861183167e-01
    z[5,4,4]  R1852     0.293820321559906
    z[5,4,4]  R1853     2.9863053560256958e-01
    z[5,4,4]  R1854     -1.9770273566246033e-01
    z[5,4,4]  R1855     3.4514042735099792e-01
    z[5,4,4]  R1856     3.7323823571205139e-01
    z[5,4,4]  R1857     -3.2541158795356750e-01
    z[5,4,4]  R1858     2.5673272088170052e-02
    z[5,4,4]  R1859     -1.8125078082084656e-01
    z[5,4,4]  R1860     1.7340712249279022e-01
    z[5,4,4]  R1861     9.8382413387298584e-02
    z[5,4,4]  R1862     3.0576035380363464e-01
    z[5,4,4]  R1863     3.2145464420318604e-01
    z[5,4,4]  R1864     1.4233171939849854e-01
    z[5,4,4]  R1865     -2.2503726184368134e-01
    z[5,4,4]  R1866     -2.6704880595207214e-01
    z[5,4,4]  R1867     -3.6939030885696411e-01
    z[5,4,4]  R1868     -1.3780309259891510e-01
    z[5,4,4]  R1869     5.5130505561828613e-01
    z[5,4,4]  R1870     3.3232355117797852e-01
    z[5,4,4]  R1871     5.5513274669647217e-01
    z[5,4,4]  R1872     3.6872851848602295e-01
    z[5,4,4]  R1873     -3.5058757662773132e-01
    z[5,4,4]  R1874     -2.2812278568744659e-01
    z[5,4,4]  R1875     0.24508036673069
    z[5,4,4]  R1876     9.6251070499420166e-02
    z[5,4,4]  R1877     1.5524534881114960e-01
    z[5,4,4]  R1878     -2.3286515474319458e-01
    z[5,4,4]  R1879     6.7009791731834412e-02
    z[5,4,4]  R1880     4.9650236964225769e-02
    z[5,4,4]  R1881     3.7223309278488159e-01
    z[5,4,4]  R1882     0.444194495677948
    z[5,4,4]  R1883     7.9294638708233833e-03
    z[5,4,4]  R1884     5.3112413734197617e-02
    z[5,4,4]  R1885     1.0073860734701157e-01
    z[5,4,4]  R1886     -1.8034411966800690e-01
    z[5,4,4]  R1887     4.9704242497682571e-02
    z[5,4,4]  R1888     -0.199087455868721
    z[5,4,5]  R43       1
    z[5,4,5]  R52       -1
    z[5,4,5]  R1785     -1
    z[5,4,5]  R1786     1
    z[5,4,5]  R1789     4.3785876035690308e-01
    z[5,4,5]  R1790     6.6495560109615326e-02
    z[5,4,5]  R1791     9.5870628952980042e-02
    z[5,4,5]  R1792     -5.5189430713653564e-01
    z[5,4,5]  R1793     -2.6647770404815674e-01
    z[5,4,5]  R1794     -5.6386363506317139e-01
    z[5,4,5]  R1795     -0.0724416971206665
    z[5,4,5]  R1796     2.3566253483295441e-01
    z[5,4,5]  R1797     1.8732255324721336e-02
    z[5,4,5]  R1798     1.3279426097869873e-01
    z[5,4,5]  R1799     -2.3404514417052269e-02
    z[5,4,5]  R1800     2.1368764340877533e-01
    z[5,4,5]  R1801     -2.6740193367004395e-01
    z[5,4,5]  R1802     4.6200025826692581e-02
    z[5,4,5]  R1803     -1.7845694720745087e-01
    z[5,4,5]  R1804     6.7630611360073090e-02
    z[5,4,5]  R1805     1.6359809041023254e-01
    z[5,4,5]  R1806     3.9603692293167114e-01
    z[5,4,5]  R1807     2.8254750370979309e-01
    z[5,4,5]  R1808     -5.0018376111984253e-01
    z[5,4,5]  R1809     4.6970881521701813e-02
    z[5,4,5]  R1810     -8.5598759353160858e-02
    z[5,4,5]  R1811     -1.7107465537264943e-03
    z[5,4,5]  R1812     2.8520816564559937e-01
    z[5,4,5]  R1813     2.7119019627571106e-01
    z[5,4,5]  R1814     1.1809702217578888e-01
    z[5,4,5]  R1815     2.9165685176849365e-01
    z[5,4,5]  R1816     2.0493675768375397e-01
    z[5,4,5]  R1817     1.4271101355552673e-01
    z[5,4,5]  R1818     -1.5288364887237549e-01
    z[5,4,5]  R1819     -9.8025634884834290e-02
    z[5,4,5]  R1820     3.1905624270439148e-01
    z[5,4,5]  R1821     5.2297419309616089e-01
    z[5,4,5]  R1822     5.7966765016317368e-02
    z[5,4,5]  R1823     5.9351056814193726e-01
    z[5,4,5]  R1824     6.4435964822769165e-01
    z[5,4,5]  R1825     3.3072790503501892e-01
    z[5,4,5]  R1826     2.7507367730140686e-01
    z[5,4,5]  R1827     3.1214219331741333e-01
    z[5,4,5]  R1828     2.7602595090866089e-01
    z[5,4,5]  R1829     6.4252525568008423e-01
    z[5,4,5]  R1830     -6.9482362270355225e-01
    z[5,4,5]  R1831     -4.7868281602859497e-01
    z[5,4,5]  R1832     -2.6825106143951416e-01
    z[5,4,5]  R1833     -4.0879970788955688e-01
    z[5,4,5]  R1834     1.0618981719017029e-01
    z[5,4,5]  R1835     -2.7660626173019409e-01
    z[5,4,5]  R1836     -0.265129953622818
    z[5,4,5]  R1837     -0.184409961104393
    z[5,4,5]  R1838     -1.3089528679847717e-01
    z[5,4,5]  R1839     7.1452908217906952e-02
    z[5,4,5]  R1840     3.5677134990692139e-01
    z[5,4,5]  R1841     2.7081233263015747e-01
    z[5,4,5]  R1842     1.2114244699478149e-01
    z[5,4,5]  R1843     2.8844168782234192e-01
    z[5,4,5]  R1844     -1.7791172862052917e-01
    z[5,4,5]  R1845     -1.4570856094360352e-01
    z[5,4,5]  R1846     -2.2133085131645203e-01
    z[5,4,5]  R1847     -3.6881619691848755e-01
    z[5,4,5]  R1848     -4.7811937332153320e-01
    z[5,4,5]  R1849     3.1066227704286575e-02
    z[5,4,5]  R1850     1.8571242690086365e-01
    z[5,4,5]  R1851     -2.9998105764389038e-01
    z[5,4,5]  R1852     0.337121844291687
    z[5,4,5]  R1853     -2.7562108635902405e-01
    z[5,4,5]  R1854     3.5566347837448120e-01
    z[5,4,5]  R1855     -1.8380945920944214e-01
    z[5,4,5]  R1856     -7.1242645382881165e-02
    z[5,4,5]  R1857     -5.2340172231197357e-02
    z[5,4,5]  R1858     2.8898137807846069e-01
    z[5,4,5]  R1859     -3.9129644632339478e-01
    z[5,4,5]  R1860     -0.0736314207315445
    z[5,4,5]  R1861     1.8468746542930603e-01
    z[5,4,5]  R1862     -2.2853343188762665e-01
    z[5,4,5]  R1863     1.2016015499830246e-01
    z[5,4,5]  R1864     -5.9180450439453125e-01
    z[5,4,5]  R1865     -1.2782792747020721e-01
    z[5,4,5]  R1866     5.0256609916687012e-01
    z[5,4,5]  R1867     2.6800256967544556e-01
    z[5,4,5]  R1868     -3.1151911243796349e-02
    z[5,4,5]  R1869     -1.4227263629436493e-01
    z[5,4,5]  R1870     1.1875028163194656e-01
    z[5,4,5]  R1871     -2.9758533835411072e-01
    z[5,4,5]  R1872     -3.4854629635810852e-01
    z[5,4,5]  R1873     -5.7962417602539062e-01
    z[5,4,5]  R1874     4.2994111776351929e-01
    z[5,4,5]  R1875     1.0444504767656326e-01
    z[5,4,5]  R1876     -2.2317662835121155e-01
    z[5,4,5]  R1877     1.7396973073482513e-01
    z[5,4,5]  R1878     4.5839063823223114e-02
    z[5,4,5]  R1879     1.9528928399085999e-01
    z[5,4,5]  R1880     -2.0145791769027710e-01
    z[5,4,5]  R1881     1.7320029437541962e-02
    z[5,4,5]  R1882     4.0903955698013306e-01
    z[5,4,5]  R1883     9.8281085491180420e-02
    z[5,4,5]  R1884     3.0730363726615906e-01
    z[5,4,5]  R1885     5.3372409194707870e-02
    z[5,4,5]  R1886     -1.8346744775772095e-01
    z[5,4,5]  R1887     -3.3059573173522949e-01
    z[5,4,5]  R1888     1.0094561427831650e-01
    z[5,4,6]  R44       1
    z[5,4,6]  R53       -1
    z[5,4,6]  R1787     -1
    z[5,4,6]  R1788     1
    z[5,4,6]  R1789     8.0957688391208649e-02
    z[5,4,6]  R1790     -3.4397414326667786e-01
    z[5,4,6]  R1791     6.4615708589553833e-01
    z[5,4,6]  R1792     -2.3646888136863708e-01
    z[5,4,6]  R1793     -1.1964805424213409e-01
    z[5,4,6]  R1794     3.0197387933731079e-01
    z[5,4,6]  R1795     5.7622170448303223e-01
    z[5,4,6]  R1796     1.6219522058963776e-01
    z[5,4,6]  R1797     1.8480627238750458e-01
    z[5,4,6]  R1798     -5.5185484886169434e-01
    z[5,4,6]  R1799     -1.8415758013725281e-01
    z[5,4,6]  R1800     1.9979397952556610e-01
    z[5,4,6]  R1801     2.6502721011638641e-02
    z[5,4,6]  R1802     5.8454845100641251e-02
    z[5,4,6]  R1803     2.6878777146339417e-01
    z[5,4,6]  R1804     5.2808779478073120e-01
    z[5,4,6]  R1805     0.0251354668289423
    z[5,4,6]  R1806     5.8104624040424824e-03
    z[5,4,6]  R1807     1.8169216811656952e-01
    z[5,4,6]  R1808     -3.1947222352027893e-01
    z[5,4,6]  R1809     1.5235188184306026e-03
    z[5,4,6]  R1810     1.4149212837219238e-01
    z[5,4,6]  R1811     -1.9565482437610626e-01
    z[5,4,6]  R1812     1.0147751308977604e-02
    z[5,4,6]  R1813     1.7726825177669525e-01
    z[5,4,6]  R1814     1.1284652352333069e-01
    z[5,4,6]  R1815     2.0842906832695007e-01
    z[5,4,6]  R1816     1.7213482409715652e-02
    z[5,4,6]  R1817     1.8577785789966583e-01
    z[5,4,6]  R1818     2.8011232614517212e-01
    z[5,4,6]  R1819     -2.3333968222141266e-01
    z[5,4,6]  R1820     -8.0126136541366577e-02
    z[5,4,6]  R1821     1.1936999112367630e-01
    z[5,4,6]  R1822     -0.127571240067482
    z[5,4,6]  R1823     -7.4037462472915649e-02
    z[5,4,6]  R1824     3.6459332332015038e-03
    z[5,4,6]  R1825     -6.6365584731101990e-02
    z[5,4,6]  R1826     -7.7897600829601288e-02
    z[5,4,6]  R1827     3.7438657134771347e-02
    z[5,4,6]  R1828     3.0738350749015808e-01
    z[5,4,6]  R1829     -2.0351428538560867e-02
    z[5,4,6]  R1830     7.8848786652088165e-02
    z[5,4,6]  R1831     -1.6353467106819153e-01
    z[5,4,6]  R1832     -1.4448726177215576e-01
    z[5,4,6]  R1833     -1.6862553358078003e-01
    z[5,4,6]  R1834     -1.4177618920803070e-01
    z[5,4,6]  R1835     -1.6087600588798523e-01
    z[5,4,6]  R1836     -2.5461369752883911e-01
    z[5,4,6]  R1837     2.0681983232498169e-01
    z[5,4,6]  R1838     -4.7515518963336945e-02
    z[5,4,6]  R1839     -3.1818527728319168e-02
    z[5,4,6]  R1840     1.4064137637615204e-01
    z[5,4,6]  R1841     2.0764620602130890e-01
    z[5,4,6]  R1842     -1.0985297709703445e-01
    z[5,4,6]  R1843     -5.1133328676223755e-01
    z[5,4,6]  R1844     -3.3458021283149719e-01
    z[5,4,6]  R1845     -5.2544206380844116e-01
    z[5,4,6]  R1846     4.1002756357192993e-01
    z[5,4,6]  R1847     2.4528257548809052e-01
    z[5,4,6]  R1848     -8.0440282821655273e-02
    z[5,4,6]  R1849     6.4529007673263550e-01
    z[5,4,6]  R1850     4.0478876233100891e-01
    z[5,4,6]  R1851     4.3260720372200012e-01
    z[5,4,6]  R1852     -3.0164131522178650e-01
    z[5,4,6]  R1853     4.0131950378417969e-01
    z[5,4,6]  R1854     4.0527349710464478e-01
    z[5,4,6]  R1855     -5.7893428951501846e-02
    z[5,4,6]  R1856     -6.0330498218536377e-01
    z[5,4,6]  R1857     5.7394319772720337e-01
    z[5,4,6]  R1858     2.5136026740074158e-01
    z[5,4,6]  R1859     4.0686386823654175e-01
    z[5,4,6]  R1860     -2.2347070276737213e-01
    z[5,4,6]  R1861     -2.5894997641444206e-02
    z[5,4,6]  R1862     -3.1094381213188171e-01
    z[5,4,6]  R1863     -5.4116499423980713e-01
    z[5,4,6]  R1864     -4.4947916269302368e-01
    z[5,4,6]  R1865     -2.6228001341223717e-02
    z[5,4,6]  R1866     -8.0857515335083008e-02
    z[5,4,6]  R1867     1.3635386526584625e-01
    z[5,4,6]  R1868     5.9855472296476364e-02
    z[5,4,6]  R1869     2.6544073224067688e-01
    z[5,4,6]  R1870     3.6584597826004028e-01
    z[5,4,6]  R1871     0.0942707434296608
    z[5,4,6]  R1872     2.1030361950397491e-01
    z[5,4,6]  R1873     -3.1426653265953064e-02
    z[5,4,6]  R1874     -0.0619150847196579
    z[5,4,6]  R1875     -9.6823170781135559e-02
    z[5,4,6]  R1876     -1.0391784459352493e-01
    z[5,4,6]  R1877     -7.5780266523361206e-01
    z[5,4,6]  R1878     -1.5807080268859863e-01
    z[5,4,6]  R1879     1.6583777964115143e-01
    z[5,4,6]  R1880     -3.8994929194450378e-01
    z[5,4,6]  R1881     -4.0062373876571655e-01
    z[5,4,6]  R1882     -3.6320978403091431e-01
    z[5,4,6]  R1883     1.1026592552661896e-01
    z[5,4,6]  R1884     -5.2296765148639679e-02
    z[5,4,6]  R1885     1.8907051533460617e-02
    z[5,4,6]  R1886     -7.9683875665068626e-03
    z[5,4,6]  R1887     2.8325811028480530e-02
    z[5,4,6]  R1888     -7.2527416050434113e-02
    z[5,6,0]  R47       -1
    z[5,6,0]  R56       1
    z[5,6,0]  R1953     -1
    z[5,6,0]  R1954     1
    z[5,6,0]  R1967     0.290393203496933
    z[5,6,0]  R1968     1.1789184808731079e-01
    z[5,6,0]  R1969     4.6540299057960510e-01
    z[5,6,0]  R1970     -2.3550014197826385e-01
    z[5,6,0]  R1971     0.0439508818089962
    z[5,6,0]  R1972     7.0555157959461212e-02
    z[5,6,0]  R1973     1.8429741263389587e-01
    z[5,6,0]  R1974     -1.2201659381389618e-01
    z[5,6,0]  R1975     -1.9457355141639709e-02
    z[5,6,0]  R1976     -2.6659536361694336e-01
    z[5,6,0]  R1977     -8.8465720415115356e-01
    z[5,6,0]  R1978     -8.8275516033172607e-01
    z[5,6,0]  R1979     -8.3729118108749390e-01
    z[5,6,0]  R1980     -8.3234339952468872e-01
    z[5,6,0]  R1981     -8.2923251390457153e-01
    z[5,6,0]  R1982     -8.2676589488983154e-01
    z[5,6,0]  R1983     -8.2746756076812744e-01
    z[5,6,0]  R1984     -7.9120177030563354e-01
    z[5,6,0]  R1985     -7.5296068191528320e-01
    z[5,6,0]  R1986     2.5739872455596924e-01
    z[5,6,0]  R1987     1.2290877103805542e-01
    z[5,6,0]  R1988     8.6141891777515411e-02
    z[5,6,0]  R1989     -8.3922937512397766e-02
    z[5,6,0]  R1990     1.2700876593589783e-01
    z[5,6,0]  R1991     1.8221594393253326e-01
    z[5,6,0]  R1992     -6.2401881441473961e-03
    z[5,6,0]  R1993     2.1518439054489136e-01
    z[5,6,0]  R1994     1.5994463860988617e-01
    z[5,6,0]  R1995     1.6754741966724396e-01
    z[5,6,0]  R1996     1.8137775361537933e-01
    z[5,6,0]  R1997     5.9688808396458626e-03
    z[5,6,0]  R1998     2.1250111982226372e-02
    z[5,6,0]  R1999     6.2775678932666779e-02
    z[5,6,0]  R2000     3.7722158432006836e-01
    z[5,6,0]  R2001     1.1136939376592636e-01
    z[5,6,0]  R2002     1.2851694226264954e-01
    z[5,6,0]  R2003     -4.2825754731893539e-02
    z[5,6,0]  R2004     -1.4160597324371338e-01
    z[5,6,0]  R2005     1.8544195592403412e-01
    z[5,6,0]  R2006     1.0569975525140762e-01
    z[5,6,0]  R2007     -3.0331939458847046e-01
    z[5,6,0]  R2008     3.3793774247169495e-01
    z[5,6,0]  R2009     3.0217203497886658e-01
    z[5,6,0]  R2010     4.0725100040435791e-01
    z[5,6,0]  R2011     1.4683434367179871e-01
    z[5,6,0]  R2012     6.0486119985580444e-01
    z[5,6,0]  R2013     -1.9973242655396461e-02
    z[5,6,0]  R2014     5.2902978658676147e-01
    z[5,6,0]  R2015     3.6606675386428833e-01
    z[5,6,0]  R2016     -1.0453700087964535e-02
    z[5,6,0]  R2017     4.4093447923660278e-01
    z[5,6,0]  R2018     5.4805117845535278e-01
    z[5,6,0]  R2019     4.2255589365959167e-01
    z[5,6,0]  R2020     2.7814289927482605e-01
    z[5,6,0]  R2021     8.4848684072494507e-01
    z[5,6,0]  R2022     0.589670717716217
    z[5,6,0]  R2023     7.0288866758346558e-01
    z[5,6,0]  R2024     5.5329144001007080e-01
    z[5,6,0]  R2025     -3.2655516266822815e-01
    z[5,6,0]  R2026     -5.2858823537826538e-01
    z[5,6,0]  R2027     -8.0339974164962769e-01
    z[5,6,0]  R2028     -6.9192576408386230e-01
    z[5,6,0]  R2029     -8.2773417234420776e-01
    z[5,6,0]  R2030     -6.3882762193679810e-01
    z[5,6,0]  R2031     -6.0439628362655640e-01
    z[5,6,0]  R2032     -7.2977793216705322e-01
    z[5,6,0]  R2033     -0.559395968914032
    z[5,6,0]  R2034     -5.0156968832015991e-01
    z[5,6,0]  R2035     3.1622976064682007e-01
    z[5,6,0]  R2036     0.315693736076355
    z[5,6,0]  R2037     -2.8708526492118835e-01
    z[5,6,0]  R2038     -7.2947657108306885e-01
    z[5,6,0]  R2039     -0.335328608751297
    z[5,6,0]  R2040     -4.7691029310226440e-01
    z[5,6,0]  R2041     -2.0829641819000244e-01
    z[5,6,0]  R2042     -3.3500516414642334e-01
    z[5,6,0]  R2043     -3.4237566590309143e-01
    z[5,6,0]  R2044     -4.5555812120437622e-01
    z[5,6,0]  R2045     -3.1280595064163208e-01
    z[5,6,0]  R2046     -4.9793234467506409e-01
    z[5,6,1]  R48       -1
    z[5,6,1]  R57       1
    z[5,6,1]  R1955     -1
    z[5,6,1]  R1956     1
    z[5,6,1]  R1967     -5.4126262664794922e-01
    z[5,6,1]  R1968     -0.527815043926239
    z[5,6,1]  R1969     -4.0310895442962646e-01
    z[5,6,1]  R1970     -5.1441872119903564e-01
    z[5,6,1]  R1971     -3.0516985058784485e-01
    z[5,6,1]  R1972     -5.3298741579055786e-01
    z[5,6,1]  R1973     -5.1865673065185547e-01
    z[5,6,1]  R1974     -2.9804956912994385e-01
    z[5,6,1]  R1975     -1.1388030648231506e-01
    z[5,6,1]  R1976     -3.3869579434394836e-01
    z[5,6,1]  R1977     2.4482125043869019e-01
    z[5,6,1]  R1978     -5.7958744466304779e-02
    z[5,6,1]  R1979     2.7509590983390808e-01
    z[5,6,1]  R1980     2.9442688822746277e-01
    z[5,6,1]  R1981     2.1309331059455872e-01
    z[5,6,1]  R1982     9.9954180419445038e-02
    z[5,6,1]  R1983     1.0732129961252213e-01
    z[5,6,1]  R1984     2.8265592455863953e-01
    z[5,6,1]  R1985     2.1035017073154449e-01
    z[5,6,1]  R1986     3.1727030873298645e-01
    z[5,6,1]  R1987     9.6432214975357056e-01
    z[5,6,1]  R1988     9.6649235486984253e-01
    z[5,6,1]  R1989     9.3329089879989624e-01
    z[5,6,1]  R1990     9.3658292293548584e-01
    z[5,6,1]  R1991     9.0506297349929810e-01
    z[5,6,1]  R1992     9.1943162679672241e-01
    z[5,6,1]  R1993     8.8576912879943848e-01
    z[5,6,1]  R1994     8.7752628326416016e-01
    z[5,6,1]  R1995     8.8975477218627930e-01
    z[5,6,1]  R1996     9.0900379419326782e-01
    z[5,6,1]  R1997     -5.1484632492065430e-01
    z[5,6,1]  R1998     -1.8647789955139160e-01
    z[5,6,1]  R1999     -3.6952864378690720e-02
    z[5,6,1]  R2000     5.3254729509353638e-01
    z[5,6,1]  R2001     1.9414755702018738e-01
    z[5,6,1]  R2002     1.8129315972328186e-01
    z[5,6,1]  R2003     -4.4702622294425964e-01
    z[5,6,1]  R2004     -4.6301969885826111e-01
    z[5,6,1]  R2005     8.1563852727413177e-02
    z[5,6,1]  R2006     -1.2047359347343445e-01
    z[5,6,1]  R2007     -4.7547608613967896e-01
    z[5,6,1]  R2008     2.9762217402458191e-01
    z[5,6,1]  R2009     0.292923241853714
    z[5,6,1]  R2010     3.3576118946075439e-01
    z[5,6,1]  R2011     -3.5782107710838318e-01
    z[5,6,1]  R2012     -1.0087995976209641e-01
    z[5,6,1]  R2013     4.2413991689682007e-01
    z[5,6,1]  R2014     -1.9266135990619659e-01
    z[5,6,1]  R2015     8.0619163811206818e-02
    z[5,6,1]  R2016     5.3010061383247375e-02
    z[5,6,1]  R2017     -4.4560983777046204e-01
    z[5,6,1]  R2018     -2.3848210275173187e-01
    z[5,6,1]  R2019     -2.3731166124343872e-01
    z[5,6,1]  R2020     -3.2478284835815430e-01
    z[5,6,1]  R2021     -1.8467797338962555e-01
    z[5,6,1]  R2022     -2.2657305002212524e-01
    z[5,6,1]  R2023     5.1507562398910522e-02
    z[5,6,1]  R2024     -2.2879233956336975e-01
    z[5,6,1]  R2025     -4.6031586825847626e-02
    z[5,6,1]  R2026     -1.5255342423915863e-01
    z[5,6,1]  R2027     0.450044721364975
    z[5,6,1]  R2028     5.4803127050399780e-01
    z[5,6,1]  R2029     4.2429828643798828e-01
    z[5,6,1]  R2030     6.0195136070251465e-01
    z[5,6,1]  R2031     5.9679871797561646e-01
    z[5,6,1]  R2032     4.4608011841773987e-01
    z[5,6,1]  R2033     5.3579425811767578e-01
    z[5,6,1]  R2034     -5.9169030189514160e-01
    z[5,6,1]  R2035     5.9061861038208008e-01
    z[5,6,1]  R2036     5.8953213691711426e-01
    z[5,6,1]  R2037     -7.0820778608322144e-01
    z[5,6,1]  R2038     5.7110726833343506e-01
    z[5,6,1]  R2039     -7.0824992656707764e-01
    z[5,6,1]  R2040     -6.5907132625579834e-01
    z[5,6,1]  R2041     7.7580267190933228e-01
    z[5,6,1]  R2042     6.1687922477722168e-01
    z[5,6,1]  R2043     0.546272873878479
    z[5,6,1]  R2044     3.2558700442314148e-01
    z[5,6,1]  R2045     -9.1125704348087311e-02
    z[5,6,1]  R2046     -4.3750718235969543e-01
    z[5,6,2]  R49       -1
    z[5,6,2]  R58       1
    z[5,6,2]  R1957     -1
    z[5,6,2]  R1958     1
    z[5,6,2]  R1967     5.0011879205703735e-01
    z[5,6,2]  R1968     5.7912456989288330e-01
    z[5,6,2]  R1969     4.1385686397552490e-01
    z[5,6,2]  R1970     4.1221617721021175e-03
    z[5,6,2]  R1971     2.9576846957206726e-01
    z[5,6,2]  R1972     1.0213791392743587e-02
    z[5,6,2]  R1973     7.9286046326160431e-02
    z[5,6,2]  R1974     -1.4119987189769745e-01
    z[5,6,2]  R1975     7.5469903647899628e-02
    z[5,6,2]  R1976     8.5755802690982819e-02
    z[5,6,2]  R1977     1.5370386838912964e-01
    z[5,6,2]  R1978     -4.9505002796649933e-02
    z[5,6,2]  R1979     -1.8806798756122589e-01
    z[5,6,2]  R1980     -3.7738022208213806e-01
    z[5,6,2]  R1981     -6.8416267633438110e-02
    z[5,6,2]  R1982     -0.0820479691028595
    z[5,6,2]  R1983     -3.6171787977218628e-01
    z[5,6,2]  R1984     -3.1313976645469666e-01
    z[5,6,2]  R1985     4.4587758183479309e-01
    z[5,6,2]  R1986     5.4044306278228760e-01
    z[5,6,2]  R1987     8.6287543177604675e-02
    z[5,6,2]  R1988     -1.0716758668422699e-01
    z[5,6,2]  R1989     -1.1453446745872498e-01
    z[5,6,2]  R1990     1.8362710252404213e-02
    z[5,6,2]  R1991     1.6968338750302792e-03
    z[5,6,2]  R1992     -2.2201403975486755e-01
    z[5,6,2]  R1993     9.5056831836700439e-02
    z[5,6,2]  R1994     1.5280073881149292e-01
    z[5,6,2]  R1995     -6.3114441931247711e-02
    z[5,6,2]  R1996     2.0639857277274132e-02
    z[5,6,2]  R1997     9.0547293424606323e-02
    z[5,6,2]  R1998     -1.0910715162754059e-01
    z[5,6,2]  R1999     -1.8891464173793793e-01
    z[5,6,2]  R2000     4.9798309803009033e-01
    z[5,6,2]  R2001     4.4809807091951370e-02
    z[5,6,2]  R2002     -1.9111575558781624e-02
    z[5,6,2]  R2003     -1.5248617529869080e-01
    z[5,6,2]  R2004     -3.0039435625076294e-01
    z[5,6,2]  R2005     5.9113286435604095e-02
    z[5,6,2]  R2006     -2.2162710130214691e-01
    z[5,6,2]  R2007     -4.8571833968162537e-01
    z[5,6,2]  R2008     4.9689537286758423e-01
    z[5,6,2]  R2009     5.6850421428680420e-01
    z[5,6,2]  R2010     6.2127900123596191e-01
    z[5,6,2]  R2011     3.0722004175186157e-01
    z[5,6,2]  R2012     -7.4626475572586060e-01
    z[5,6,2]  R2013     -1.4325246214866638e-01
    z[5,6,2]  R2014     -6.5372610092163086e-01
    z[5,6,2]  R2015     -8.2315278053283691e-01
    z[5,6,2]  R2016     -9.1736966371536255e-01
    z[5,6,2]  R2017     3.1769603490829468e-01
    z[5,6,2]  R2018     3.5631069540977478e-01
    z[5,6,2]  R2019     -3.4127756953239441e-01
    z[5,6,2]  R2020     -1.3834577798843384e-01
    z[5,6,2]  R2021     2.5545054674148560e-01
    z[5,6,2]  R2022     5.3873889148235321e-02
    z[5,6,2]  R2023     3.5022327303886414e-01
    z[5,6,2]  R2024     -7.5893305242061615e-02
    z[5,6,2]  R2025     2.6665067672729492e-01
    z[5,6,2]  R2026     2.3423585295677185e-01
    z[5,6,2]  R2027     -2.8111422061920166e-01
    z[5,6,2]  R2028     -0.0395394004881382
    z[5,6,2]  R2029     5.5197715759277344e-02
    z[5,6,2]  R2030     -2.1367651224136353e-01
    z[5,6,2]  R2031     1.0339756309986115e-01
    z[5,6,2]  R2032     -4.5027423650026321e-02
    z[5,6,2]  R2033     4.0264445543289185e-01
    z[5,6,2]  R2034     -3.8716900348663330e-01
    z[5,6,2]  R2035     -4.8465827107429504e-01
    z[5,6,2]  R2036     -5.4945284128189087e-01
    z[5,6,2]  R2037     4.0996581315994263e-01
    z[5,6,2]  R2038     -1.1819826811552048e-01
    z[5,6,2]  R2039     2.2840917110443115e-01
    z[5,6,2]  R2040     4.3458785861730576e-02
    z[5,6,2]  R2041     1.2112908810377121e-01
    z[5,6,2]  R2042     0.15046426653862
    z[5,6,2]  R2043     0.585498571395874
    z[5,6,2]  R2044     1.1618865281343460e-01
    z[5,6,2]  R2045     -1.2154792249202728e-01
    z[5,6,2]  R2046     -6.2610512971878052e-01
    z[5,6,3]  R50       -1
    z[5,6,3]  R59       1
    z[5,6,3]  R1959     -1
    z[5,6,3]  R1960     1
    z[5,6,3]  R1967     -2.7117517590522766e-01
    z[5,6,3]  R1968     -4.7600927948951721e-01
    z[5,6,3]  R1969     -1.4765599370002747e-01
    z[5,6,3]  R1970     -5.6458425521850586e-01
    z[5,6,3]  R1971     -5.9491634368896484e-01
    z[5,6,3]  R1972     -7.0506691932678223e-02
    z[5,6,3]  R1973     -1.9790592789649963e-01
    z[5,6,3]  R1974     -7.9035305976867676e-01
    z[5,6,3]  R1975     -9.4377058744430542e-01
    z[5,6,3]  R1976     -3.5162830352783203e-01
    z[5,6,3]  R1977     2.9121702909469604e-01
    z[5,6,3]  R1978     3.5964709520339966e-01
    z[5,6,3]  R1979     2.8630918264389038e-01
    z[5,6,3]  R1980     1.8204185366630554e-01
    z[5,6,3]  R1981     3.5189661383628845e-01
    z[5,6,3]  R1982     0.126349076628685
    z[5,6,3]  R1983     3.8119003176689148e-01
    z[5,6,3]  R1984     1.9082163274288177e-01
    z[5,6,3]  R1985     2.0349277555942535e-01
    z[5,6,3]  R1986     4.1314536333084106e-01
    z[5,6,3]  R1987     -1.8382082879543304e-01
    z[5,6,3]  R1988     5.0531368702650070e-02
    z[5,6,3]  R1989     -4.7703683376312256e-02
    z[5,6,3]  R1990     7.3058776557445526e-02
    z[5,6,3]  R1991     6.2073368579149246e-02
    z[5,6,3]  R1992     -1.0537737607955933e-01
    z[5,6,3]  R1993     -1.1009852588176727e-01
    z[5,6,3]  R1994     -1.0544041544198990e-01
    z[5,6,3]  R1995     3.4839308261871338e-01
    z[5,6,3]  R1996     -9.7356185317039490e-02
    z[5,6,3]  R1997     7.9540932178497314e-01
    z[5,6,3]  R1998     9.0241980552673340e-01
    z[5,6,3]  R1999     7.6731526851654053e-01
    z[5,6,3]  R2000     4.5390194654464722e-01
    z[5,6,3]  R2001     7.6387959718704224e-01
    z[5,6,3]  R2002     7.3146307468414307e-01
    z[5,6,3]  R2003     8.1268757581710815e-01
    z[5,6,3]  R2004     0.729589581489563
    z[5,6,3]  R2005     9.1657906770706177e-01
    z[5,6,3]  R2006     8.6012172698974609e-01
    z[5,6,3]  R2007     1.6754928231239319e-01
    z[5,6,3]  R2008     1.0054871439933777e-01
    z[5,6,3]  R2009     0.241428405046463
    z[5,6,3]  R2010     4.9155864119529724e-01
    z[5,6,3]  R2011     6.8617177009582520e-01
    z[5,6,3]  R2012     5.5428307503461838e-02
    z[5,6,3]  R2013     6.7632216215133667e-01
    z[5,6,3]  R2014     0.325797438621521
    z[5,6,3]  R2015     3.2319170236587524e-01
    z[5,6,3]  R2016     1.0108335316181183e-01
    z[5,6,3]  R2017     -4.3482255935668945e-01
    z[5,6,3]  R2018     -6.6880708932876587e-01
    z[5,6,3]  R2019     -6.3091719150543213e-01
    z[5,6,3]  R2020     -8.8773626089096069e-01
    z[5,6,3]  R2021     3.5299104452133179e-01
    z[5,6,3]  R2022     -2.0625099539756775e-01
    z[5,6,3]  R2023     -5.3459867835044861e-02
    z[5,6,3]  R2024     -1.4415368437767029e-01
    z[5,6,3]  R2025     1.8515148758888245e-01
    z[5,6,3]  R2026     -4.0621495246887207e-01
    z[5,6,3]  R2027     5.9914374724030495e-03
    z[5,6,3]  R2028     -1.2339998036623001e-01
    z[5,6,3]  R2029     -9.4395920634269714e-02
    z[5,6,3]  R2030     3.3934372663497925e-01
    z[5,6,3]  R2031     3.5664927959442139e-01
    z[5,6,3]  R2032     2.5923115015029907e-01
    z[5,6,3]  R2033     2.4068602919578552e-01
    z[5,6,3]  R2034     3.6081379652023315e-01
    z[5,6,3]  R2035     3.6737982183694839e-02
    z[5,6,3]  R2036     4.8667289316654205e-02
    z[5,6,3]  R2037     3.9427277445793152e-01
    z[5,6,3]  R2038     -3.2009461522102356e-01
    z[5,6,3]  R2039     4.8703688383102417e-01
    z[5,6,3]  R2040     1.5347819030284882e-01
    z[5,6,3]  R2041     -1.8350031971931458e-01
    z[5,6,3]  R2042     -4.3879628181457520e-02
    z[5,6,3]  R2043     -3.5146945714950562e-01
    z[5,6,3]  R2044     1.9466623663902283e-01
    z[5,6,3]  R2045     8.0216413736343384e-01
    z[5,6,3]  R2046     2.5773268938064575e-01
    z[5,6,4]  R51       -1
    z[5,6,4]  R60       1
    z[5,6,4]  R1961     -1
    z[5,6,4]  R1962     1
    z[5,6,4]  R1967     3.1745424866676331e-01
    z[5,6,4]  R1968     1.5100608766078949e-01
    z[5,6,4]  R1969     -3.3366572111845016e-02
    z[5,6,4]  R1970     2.5212485343217850e-02
    z[5,6,4]  R1971     6.1498713493347168e-01
    z[5,6,4]  R1972     5.4473882913589478e-01
    z[5,6,4]  R1973     -5.6062227487564087e-01
    z[5,6,4]  R1974     4.1211530566215515e-01
    z[5,6,4]  R1975     -2.3611399531364441e-01
    z[5,6,4]  R1976     -0.600864052772522
    z[5,6,4]  R1977     1.2062467634677887e-01
    z[5,6,4]  R1978     2.7103051543235779e-03
    z[5,6,4]  R1979     -1.8362168967723846e-01
    z[5,6,4]  R1980     1.9852147996425629e-01
    z[5,6,4]  R1981     -1.8536148965358734e-01
    z[5,6,4]  R1982     1.7913419753313065e-02
    z[5,6,4]  R1983     -1.5416552312672138e-02
    z[5,6,4]  R1984     5.2506614476442337e-02
    z[5,6,4]  R1985     -1.8905505537986755e-01
    z[5,6,4]  R1986     -1.3442958891391754e-01
    z[5,6,4]  R1987     1.0738671571016312e-01
    z[5,6,4]  R1988     1.3071611523628235e-01
    z[5,6,4]  R1989     -2.6124227046966553e-01
    z[5,6,4]  R1990     1.3985583186149597e-01
    z[5,6,4]  R1991     1.9706407189369202e-01
    z[5,6,4]  R1992     2.5986665487289429e-01
    z[5,6,4]  R1993     -1.3944509625434875e-01
    z[5,6,4]  R1994     -3.5721737146377563e-01
    z[5,6,4]  R1995     4.8260069452226162e-03
    z[5,6,4]  R1996     -1.7051011323928833e-01
    z[5,6,4]  R1997     -1.7310780286788940e-01
    z[5,6,4]  R1998     1.7404425144195557e-01
    z[5,6,4]  R1999     2.8719502687454224e-01
    z[5,6,4]  R2000     3.1693622469902039e-01
    z[5,6,4]  R2001     -8.1531301140785217e-02
    z[5,6,4]  R2002     3.3749639987945557e-04
    z[5,6,4]  R2003     -2.8895176947116852e-02
    z[5,6,4]  R2004     2.4756672978401184e-01
    z[5,6,4]  R2005     -1.2850125133991241e-01
    z[5,6,4]  R2006     1.2128808349370956e-01
    z[5,6,4]  R2007     -6.8351209163665771e-02
    z[5,6,4]  R2008     -2.2629013657569885e-01
    z[5,6,4]  R2009     -4.3072330951690674e-01
    z[5,6,4]  R2010     3.0957112088799477e-02
    z[5,6,4]  R2011     -2.9939287900924683e-01
    z[5,6,4]  R2012     -1.8057155609130859e-01
    z[5,6,4]  R2013     4.8926612734794617e-01
    z[5,6,4]  R2014     -1.1993906646966934e-01
    z[5,6,4]  R2015     -2.6092376559972763e-02
    z[5,6,4]  R2016     -3.5483011603355408e-01
    z[5,6,4]  R2017     2.7873623371124268e-01
    z[5,6,4]  R2018     -2.4634149670600891e-01
    z[5,6,4]  R2019     3.8980942964553833e-01
    z[5,6,4]  R2020     -2.7859557420015335e-02
    z[5,6,4]  R2021     1.5316751599311829e-01
    z[5,6,4]  R2022     2.8971980791538954e-03
    z[5,6,4]  R2023     -1.4241434633731842e-01
    z[5,6,4]  R2024     -6.5232515335083008e-01
    z[5,6,4]  R2025     6.6785824298858643e-01
    z[5,6,4]  R2026     6.4231920242309570e-01
    z[5,6,4]  R2027     -2.2686882317066193e-01
    z[5,6,4]  R2028     -4.1900625824928284e-01
    z[5,6,4]  R2029     -3.0104938149452209e-01
    z[5,6,4]  R2030     -8.7487086653709412e-02
    z[5,6,4]  R2031     5.2652070298790932e-03
    z[5,6,4]  R2032     -6.4254850149154663e-02
    z[5,6,4]  R2033     -3.3562248945236206e-01
    z[5,6,4]  R2034     -2.0347152650356293e-01
    z[5,6,4]  R2035     -7.7061526477336884e-02
    z[5,6,4]  R2036     -1.4298850297927856e-01
    z[5,6,4]  R2037     -1.4109261333942413e-01
    z[5,6,4]  R2038     5.5168453603982925e-02
    z[5,6,4]  R2039     -1.1341971345245838e-02
    z[5,6,4]  R2040     -3.9437130093574524e-01
    z[5,6,4]  R2041     5.0103694200515747e-01
    z[5,6,4]  R2042     5.6099700927734375e-01
    z[5,6,4]  R2043     8.3675779402256012e-02
    z[5,6,4]  R2044     7.0127105712890625e-01
    z[5,6,4]  R2045     -4.7330036759376526e-01
    z[5,6,4]  R2046     1.8838801980018616e-01
    z[5,6,5]  R52       -1
    z[5,6,5]  R61       1
    z[5,6,5]  R1963     -1
    z[5,6,5]  R1964     1
    z[5,6,5]  R1967     4.3785876035690308e-01
    z[5,6,5]  R1968     6.6495560109615326e-02
    z[5,6,5]  R1969     9.5870628952980042e-02
    z[5,6,5]  R1970     -5.5189430713653564e-01
    z[5,6,5]  R1971     -2.6647770404815674e-01
    z[5,6,5]  R1972     -5.6386363506317139e-01
    z[5,6,5]  R1973     -0.0724416971206665
    z[5,6,5]  R1974     2.3566253483295441e-01
    z[5,6,5]  R1975     1.8732255324721336e-02
    z[5,6,5]  R1976     1.3279426097869873e-01
    z[5,6,5]  R1977     -2.3404514417052269e-02
    z[5,6,5]  R1978     2.1368764340877533e-01
    z[5,6,5]  R1979     -2.6740193367004395e-01
    z[5,6,5]  R1980     4.6200025826692581e-02
    z[5,6,5]  R1981     -1.7845694720745087e-01
    z[5,6,5]  R1982     6.7630611360073090e-02
    z[5,6,5]  R1983     1.6359809041023254e-01
    z[5,6,5]  R1984     3.9603692293167114e-01
    z[5,6,5]  R1985     2.8254750370979309e-01
    z[5,6,5]  R1986     -5.0018376111984253e-01
    z[5,6,5]  R1987     4.6970881521701813e-02
    z[5,6,5]  R1988     -8.5598759353160858e-02
    z[5,6,5]  R1989     -1.7107465537264943e-03
    z[5,6,5]  R1990     2.8520816564559937e-01
    z[5,6,5]  R1991     2.7119019627571106e-01
    z[5,6,5]  R1992     1.1809702217578888e-01
    z[5,6,5]  R1993     2.9165685176849365e-01
    z[5,6,5]  R1994     2.0493675768375397e-01
    z[5,6,5]  R1995     1.4271101355552673e-01
    z[5,6,5]  R1996     -1.5288364887237549e-01
    z[5,6,5]  R1997     -9.8025634884834290e-02
    z[5,6,5]  R1998     3.1905624270439148e-01
    z[5,6,5]  R1999     5.2297419309616089e-01
    z[5,6,5]  R2000     5.7966765016317368e-02
    z[5,6,5]  R2001     5.9351056814193726e-01
    z[5,6,5]  R2002     6.4435964822769165e-01
    z[5,6,5]  R2003     3.3072790503501892e-01
    z[5,6,5]  R2004     2.7507367730140686e-01
    z[5,6,5]  R2005     3.1214219331741333e-01
    z[5,6,5]  R2006     2.7602595090866089e-01
    z[5,6,5]  R2007     6.4252525568008423e-01
    z[5,6,5]  R2008     -6.9482362270355225e-01
    z[5,6,5]  R2009     -4.7868281602859497e-01
    z[5,6,5]  R2010     -2.6825106143951416e-01
    z[5,6,5]  R2011     -4.0879970788955688e-01
    z[5,6,5]  R2012     1.0618981719017029e-01
    z[5,6,5]  R2013     -2.7660626173019409e-01
    z[5,6,5]  R2014     -0.265129953622818
    z[5,6,5]  R2015     -0.184409961104393
    z[5,6,5]  R2016     -1.3089528679847717e-01
    z[5,6,5]  R2017     -7.4104122817516327e-02
    z[5,6,5]  R2018     -8.7971940636634827e-02
    z[5,6,5]  R2019     1.7152974009513855e-01
    z[5,6,5]  R2020     9.0885631740093231e-02
    z[5,6,5]  R2021     4.3337102979421616e-03
    z[5,6,5]  R2022     -3.8824877142906189e-01
    z[5,6,5]  R2023     -2.2742530703544617e-01
    z[5,6,5]  R2024     2.0665295422077179e-01
    z[5,6,5]  R2025     -5.5211347341537476e-01
    z[5,6,5]  R2026     -2.3046933114528656e-01
    z[5,6,5]  R2027     4.7852255403995514e-02
    z[5,6,5]  R2028     2.6644130703061819e-03
    z[5,6,5]  R2029     -1.5615621209144592e-01
    z[5,6,5]  R2030     1.6076974570751190e-01
    z[5,6,5]  R2031     2.3430469632148743e-01
    z[5,6,5]  R2032     2.4470695853233337e-01
    z[5,6,5]  R2033     -0.0658566951751709
    z[5,6,5]  R2034     3.4708563238382339e-02
    z[5,6,5]  R2035     -3.5051450133323669e-01
    z[5,6,5]  R2036     -2.0083734393119812e-01
    z[5,6,5]  R2037     2.6920095086097717e-01
    z[5,6,5]  R2038     1.4070644974708557e-01
    z[5,6,5]  R2039     -1.1504362523555756e-01
    z[5,6,5]  R2040     -3.6810681223869324e-01
    z[5,6,5]  R2041     0.126405268907547
    z[5,6,5]  R2042     -2.9695412516593933e-01
    z[5,6,5]  R2043     -2.9155787825584412e-01
    z[5,6,5]  R2044     -3.6707469820976257e-01
    z[5,6,5]  R2045     -1.0693305730819702e-01
    z[5,6,5]  R2046     -2.5623857975006104e-01
    z[5,6,6]  R53       -1
    z[5,6,6]  R62       1
    z[5,6,6]  R1965     -1
    z[5,6,6]  R1966     1
    z[5,6,6]  R1967     8.0957688391208649e-02
    z[5,6,6]  R1968     -3.4397414326667786e-01
    z[5,6,6]  R1969     6.4615708589553833e-01
    z[5,6,6]  R1970     -2.3646888136863708e-01
    z[5,6,6]  R1971     -1.1964805424213409e-01
    z[5,6,6]  R1972     3.0197387933731079e-01
    z[5,6,6]  R1973     5.7622170448303223e-01
    z[5,6,6]  R1974     1.6219522058963776e-01
    z[5,6,6]  R1975     1.8480627238750458e-01
    z[5,6,6]  R1976     -5.5185484886169434e-01
    z[5,6,6]  R1977     -1.8415758013725281e-01
    z[5,6,6]  R1978     1.9979397952556610e-01
    z[5,6,6]  R1979     2.6502721011638641e-02
    z[5,6,6]  R1980     5.8454845100641251e-02
    z[5,6,6]  R1981     2.6878777146339417e-01
    z[5,6,6]  R1982     5.2808779478073120e-01
    z[5,6,6]  R1983     0.0251354668289423
    z[5,6,6]  R1984     5.8104624040424824e-03
    z[5,6,6]  R1985     1.8169216811656952e-01
    z[5,6,6]  R1986     -3.1947222352027893e-01
    z[5,6,6]  R1987     1.5235188184306026e-03
    z[5,6,6]  R1988     1.4149212837219238e-01
    z[5,6,6]  R1989     -1.9565482437610626e-01
    z[5,6,6]  R1990     1.0147751308977604e-02
    z[5,6,6]  R1991     1.7726825177669525e-01
    z[5,6,6]  R1992     1.1284652352333069e-01
    z[5,6,6]  R1993     2.0842906832695007e-01
    z[5,6,6]  R1994     1.7213482409715652e-02
    z[5,6,6]  R1995     1.8577785789966583e-01
    z[5,6,6]  R1996     2.8011232614517212e-01
    z[5,6,6]  R1997     -2.3333968222141266e-01
    z[5,6,6]  R1998     -8.0126136541366577e-02
    z[5,6,6]  R1999     1.1936999112367630e-01
    z[5,6,6]  R2000     -0.127571240067482
    z[5,6,6]  R2001     -7.4037462472915649e-02
    z[5,6,6]  R2002     3.6459332332015038e-03
    z[5,6,6]  R2003     -6.6365584731101990e-02
    z[5,6,6]  R2004     -7.7897600829601288e-02
    z[5,6,6]  R2005     3.7438657134771347e-02
    z[5,6,6]  R2006     3.0738350749015808e-01
    z[5,6,6]  R2007     -2.0351428538560867e-02
    z[5,6,6]  R2008     7.8848786652088165e-02
    z[5,6,6]  R2009     -1.6353467106819153e-01
    z[5,6,6]  R2010     -1.4448726177215576e-01
    z[5,6,6]  R2011     -1.6862553358078003e-01
    z[5,6,6]  R2012     -1.4177618920803070e-01
    z[5,6,6]  R2013     -1.6087600588798523e-01
    z[5,6,6]  R2014     -2.5461369752883911e-01
    z[5,6,6]  R2015     2.0681983232498169e-01
    z[5,6,6]  R2016     -4.7515518963336945e-02
    z[5,6,6]  R2017     4.8355132341384888e-01
    z[5,6,6]  R2018     -9.0920282527804375e-03
    z[5,6,6]  R2019     -2.6311388611793518e-01
    z[5,6,6]  R2020     -3.0015598982572556e-02
    z[5,6,6]  R2021     -1.8063063919544220e-01
    z[5,6,6]  R2022     -6.3621199131011963e-01
    z[5,6,6]  R2023     -5.5297023057937622e-01
    z[5,6,6]  R2024     -0.383078396320343
    z[5,6,6]  R2025     -1.8707031011581421e-01
    z[5,6,6]  R2026     -1.0841947793960571e-01
    z[5,6,6]  R2027     -1.3852114975452423e-01
    z[5,6,6]  R2028     -1.6892676055431366e-01
    z[5,6,6]  R2029     8.8624767959117889e-02
    z[5,6,6]  R2030     -1.8772609531879425e-01
    z[5,6,6]  R2031     2.9278010129928589e-01
    z[5,6,6]  R2032     3.6769318580627441e-01
    z[5,6,6]  R2033     2.5093591213226318e-01
    z[5,6,6]  R2034     -2.7502483129501343e-01
    z[5,6,6]  R2035     4.3142339587211609e-01
    z[5,6,6]  R2036     4.3329083919525146e-01
    z[5,6,6]  R2037     1.1154074221849442e-02
    z[5,6,6]  R2038     4.9266304820775986e-02
    z[5,6,6]  R2039     -2.8843957185745239e-01
    z[5,6,6]  R2040     -1.4732936024665833e-01
    z[5,6,6]  R2041     -1.9844852387905121e-01
    z[5,6,6]  R2042     -2.8243076801300049e-01
    z[5,6,6]  R2043     1.6130003333091736e-01
    z[5,6,6]  R2044     9.2413134872913361e-02
    z[5,6,6]  R2045     -1.2626359239220619e-02
    z[5,6,6]  R2046     -3.2690886408090591e-02
    z[6,5,0]  R47       1
    z[6,5,0]  R56       -1
    z[6,5,0]  R2047     -1
    z[6,5,0]  R2048     1
    z[6,5,0]  R2061     4.4093447923660278e-01
    z[6,5,0]  R2062     5.4805117845535278e-01
    z[6,5,0]  R2063     4.2255589365959167e-01
    z[6,5,0]  R2064     2.7814289927482605e-01
    z[6,5,0]  R2065     8.4848684072494507e-01
    z[6,5,0]  R2066     0.589670717716217
    z[6,5,0]  R2067     7.0288866758346558e-01
    z[6,5,0]  R2068     5.5329144001007080e-01
    z[6,5,0]  R2069     -3.2655516266822815e-01
    z[6,5,0]  R2070     -5.2858823537826538e-01
    z[6,5,0]  R2071     -8.0339974164962769e-01
    z[6,5,0]  R2072     -6.9192576408386230e-01
    z[6,5,0]  R2073     -8.2773417234420776e-01
    z[6,5,0]  R2074     -6.3882762193679810e-01
    z[6,5,0]  R2075     -6.0439628362655640e-01
    z[6,5,0]  R2076     -7.2977793216705322e-01
    z[6,5,0]  R2077     -0.559395968914032
    z[6,5,0]  R2078     -5.0156968832015991e-01
    z[6,5,0]  R2079     3.1622976064682007e-01
    z[6,5,0]  R2080     0.315693736076355
    z[6,5,0]  R2081     -2.8708526492118835e-01
    z[6,5,0]  R2082     -7.2947657108306885e-01
    z[6,5,0]  R2083     -0.335328608751297
    z[6,5,0]  R2084     -4.7691029310226440e-01
    z[6,5,0]  R2085     -2.0829641819000244e-01
    z[6,5,0]  R2086     -3.3500516414642334e-01
    z[6,5,0]  R2087     -3.4237566590309143e-01
    z[6,5,0]  R2088     -4.5555812120437622e-01
    z[6,5,0]  R2089     -3.1280595064163208e-01
    z[6,5,0]  R2090     -4.9793234467506409e-01
    z[6,5,0]  R2091     0.290393203496933
    z[6,5,0]  R2092     1.1789184808731079e-01
    z[6,5,0]  R2093     4.6540299057960510e-01
    z[6,5,0]  R2094     -2.3550014197826385e-01
    z[6,5,0]  R2095     0.0439508818089962
    z[6,5,0]  R2096     7.0555157959461212e-02
    z[6,5,0]  R2097     1.8429741263389587e-01
    z[6,5,0]  R2098     -1.2201659381389618e-01
    z[6,5,0]  R2099     -1.9457355141639709e-02
    z[6,5,0]  R2100     -2.6659536361694336e-01
    z[6,5,0]  R2101     -8.8465720415115356e-01
    z[6,5,0]  R2102     -8.8275516033172607e-01
    z[6,5,0]  R2103     -8.3729118108749390e-01
    z[6,5,0]  R2104     -8.3234339952468872e-01
    z[6,5,0]  R2105     -8.2923251390457153e-01
    z[6,5,0]  R2106     -8.2676589488983154e-01
    z[6,5,0]  R2107     -8.2746756076812744e-01
    z[6,5,0]  R2108     -7.9120177030563354e-01
    z[6,5,0]  R2109     -7.5296068191528320e-01
    z[6,5,0]  R2110     2.5739872455596924e-01
    z[6,5,0]  R2111     1.2290877103805542e-01
    z[6,5,0]  R2112     8.6141891777515411e-02
    z[6,5,0]  R2113     -8.3922937512397766e-02
    z[6,5,0]  R2114     1.2700876593589783e-01
    z[6,5,0]  R2115     1.8221594393253326e-01
    z[6,5,0]  R2116     -6.2401881441473961e-03
    z[6,5,0]  R2117     2.1518439054489136e-01
    z[6,5,0]  R2118     1.5994463860988617e-01
    z[6,5,0]  R2119     1.6754741966724396e-01
    z[6,5,0]  R2120     1.8137775361537933e-01
    z[6,5,0]  R2121     5.9688808396458626e-03
    z[6,5,0]  R2122     2.1250111982226372e-02
    z[6,5,0]  R2123     6.2775678932666779e-02
    z[6,5,0]  R2124     3.7722158432006836e-01
    z[6,5,0]  R2125     1.1136939376592636e-01
    z[6,5,0]  R2126     1.2851694226264954e-01
    z[6,5,0]  R2127     -4.2825754731893539e-02
    z[6,5,0]  R2128     -1.4160597324371338e-01
    z[6,5,0]  R2129     1.8544195592403412e-01
    z[6,5,0]  R2130     1.0569975525140762e-01
    z[6,5,0]  R2131     -3.0331939458847046e-01
    z[6,5,0]  R2132     3.3793774247169495e-01
    z[6,5,0]  R2133     3.0217203497886658e-01
    z[6,5,0]  R2134     4.0725100040435791e-01
    z[6,5,0]  R2135     1.4683434367179871e-01
    z[6,5,0]  R2136     6.0486119985580444e-01
    z[6,5,0]  R2137     -1.9973242655396461e-02
    z[6,5,0]  R2138     5.2902978658676147e-01
    z[6,5,0]  R2139     3.6606675386428833e-01
    z[6,5,0]  R2140     -1.0453700087964535e-02
    z[6,5,1]  R48       1
    z[6,5,1]  R57       -1
    z[6,5,1]  R2049     -1
    z[6,5,1]  R2050     1
    z[6,5,1]  R2061     -4.4560983777046204e-01
    z[6,5,1]  R2062     -2.3848210275173187e-01
    z[6,5,1]  R2063     -2.3731166124343872e-01
    z[6,5,1]  R2064     -3.2478284835815430e-01
    z[6,5,1]  R2065     -1.8467797338962555e-01
    z[6,5,1]  R2066     -2.2657305002212524e-01
    z[6,5,1]  R2067     5.1507562398910522e-02
    z[6,5,1]  R2068     -2.2879233956336975e-01
    z[6,5,1]  R2069     -4.6031586825847626e-02
    z[6,5,1]  R2070     -1.5255342423915863e-01
    z[6,5,1]  R2071     0.450044721364975
    z[6,5,1]  R2072     5.4803127050399780e-01
    z[6,5,1]  R2073     4.2429828643798828e-01
    z[6,5,1]  R2074     6.0195136070251465e-01
    z[6,5,1]  R2075     5.9679871797561646e-01
    z[6,5,1]  R2076     4.4608011841773987e-01
    z[6,5,1]  R2077     5.3579425811767578e-01
    z[6,5,1]  R2078     -5.9169030189514160e-01
    z[6,5,1]  R2079     5.9061861038208008e-01
    z[6,5,1]  R2080     5.8953213691711426e-01
    z[6,5,1]  R2081     -7.0820778608322144e-01
    z[6,5,1]  R2082     5.7110726833343506e-01
    z[6,5,1]  R2083     -7.0824992656707764e-01
    z[6,5,1]  R2084     -6.5907132625579834e-01
    z[6,5,1]  R2085     7.7580267190933228e-01
    z[6,5,1]  R2086     6.1687922477722168e-01
    z[6,5,1]  R2087     0.546272873878479
    z[6,5,1]  R2088     3.2558700442314148e-01
    z[6,5,1]  R2089     -9.1125704348087311e-02
    z[6,5,1]  R2090     -4.3750718235969543e-01
    z[6,5,1]  R2091     -5.4126262664794922e-01
    z[6,5,1]  R2092     -0.527815043926239
    z[6,5,1]  R2093     -4.0310895442962646e-01
    z[6,5,1]  R2094     -5.1441872119903564e-01
    z[6,5,1]  R2095     -3.0516985058784485e-01
    z[6,5,1]  R2096     -5.3298741579055786e-01
    z[6,5,1]  R2097     -5.1865673065185547e-01
    z[6,5,1]  R2098     -2.9804956912994385e-01
    z[6,5,1]  R2099     -1.1388030648231506e-01
    z[6,5,1]  R2100     -3.3869579434394836e-01
    z[6,5,1]  R2101     2.4482125043869019e-01
    z[6,5,1]  R2102     -5.7958744466304779e-02
    z[6,5,1]  R2103     2.7509590983390808e-01
    z[6,5,1]  R2104     2.9442688822746277e-01
    z[6,5,1]  R2105     2.1309331059455872e-01
    z[6,5,1]  R2106     9.9954180419445038e-02
    z[6,5,1]  R2107     1.0732129961252213e-01
    z[6,5,1]  R2108     2.8265592455863953e-01
    z[6,5,1]  R2109     2.1035017073154449e-01
    z[6,5,1]  R2110     3.1727030873298645e-01
    z[6,5,1]  R2111     9.6432214975357056e-01
    z[6,5,1]  R2112     9.6649235486984253e-01
    z[6,5,1]  R2113     9.3329089879989624e-01
    z[6,5,1]  R2114     9.3658292293548584e-01
    z[6,5,1]  R2115     9.0506297349929810e-01
    z[6,5,1]  R2116     9.1943162679672241e-01
    z[6,5,1]  R2117     8.8576912879943848e-01
    z[6,5,1]  R2118     8.7752628326416016e-01
    z[6,5,1]  R2119     8.8975477218627930e-01
    z[6,5,1]  R2120     9.0900379419326782e-01
    z[6,5,1]  R2121     -5.1484632492065430e-01
    z[6,5,1]  R2122     -1.8647789955139160e-01
    z[6,5,1]  R2123     -3.6952864378690720e-02
    z[6,5,1]  R2124     5.3254729509353638e-01
    z[6,5,1]  R2125     1.9414755702018738e-01
    z[6,5,1]  R2126     1.8129315972328186e-01
    z[6,5,1]  R2127     -4.4702622294425964e-01
    z[6,5,1]  R2128     -4.6301969885826111e-01
    z[6,5,1]  R2129     8.1563852727413177e-02
    z[6,5,1]  R2130     -1.2047359347343445e-01
    z[6,5,1]  R2131     -4.7547608613967896e-01
    z[6,5,1]  R2132     2.9762217402458191e-01
    z[6,5,1]  R2133     0.292923241853714
    z[6,5,1]  R2134     3.3576118946075439e-01
    z[6,5,1]  R2135     -3.5782107710838318e-01
    z[6,5,1]  R2136     -1.0087995976209641e-01
    z[6,5,1]  R2137     4.2413991689682007e-01
    z[6,5,1]  R2138     -1.9266135990619659e-01
    z[6,5,1]  R2139     8.0619163811206818e-02
    z[6,5,1]  R2140     5.3010061383247375e-02
    z[6,5,2]  R49       1
    z[6,5,2]  R58       -1
    z[6,5,2]  R2051     -1
    z[6,5,2]  R2052     1
    z[6,5,2]  R2061     3.1769603490829468e-01
    z[6,5,2]  R2062     3.5631069540977478e-01
    z[6,5,2]  R2063     -3.4127756953239441e-01
    z[6,5,2]  R2064     -1.3834577798843384e-01
    z[6,5,2]  R2065     2.5545054674148560e-01
    z[6,5,2]  R2066     5.3873889148235321e-02
    z[6,5,2]  R2067     3.5022327303886414e-01
    z[6,5,2]  R2068     -7.5893305242061615e-02
    z[6,5,2]  R2069     2.6665067672729492e-01
    z[6,5,2]  R2070     2.3423585295677185e-01
    z[6,5,2]  R2071     -2.8111422061920166e-01
    z[6,5,2]  R2072     -0.0395394004881382
    z[6,5,2]  R2073     5.5197715759277344e-02
    z[6,5,2]  R2074     -2.1367651224136353e-01
    z[6,5,2]  R2075     1.0339756309986115e-01
    z[6,5,2]  R2076     -4.5027423650026321e-02
    z[6,5,2]  R2077     4.0264445543289185e-01
    z[6,5,2]  R2078     -3.8716900348663330e-01
    z[6,5,2]  R2079     -4.8465827107429504e-01
    z[6,5,2]  R2080     -5.4945284128189087e-01
    z[6,5,2]  R2081     4.0996581315994263e-01
    z[6,5,2]  R2082     -1.1819826811552048e-01
    z[6,5,2]  R2083     2.2840917110443115e-01
    z[6,5,2]  R2084     4.3458785861730576e-02
    z[6,5,2]  R2085     1.2112908810377121e-01
    z[6,5,2]  R2086     0.15046426653862
    z[6,5,2]  R2087     0.585498571395874
    z[6,5,2]  R2088     1.1618865281343460e-01
    z[6,5,2]  R2089     -1.2154792249202728e-01
    z[6,5,2]  R2090     -6.2610512971878052e-01
    z[6,5,2]  R2091     5.0011879205703735e-01
    z[6,5,2]  R2092     5.7912456989288330e-01
    z[6,5,2]  R2093     4.1385686397552490e-01
    z[6,5,2]  R2094     4.1221617721021175e-03
    z[6,5,2]  R2095     2.9576846957206726e-01
    z[6,5,2]  R2096     1.0213791392743587e-02
    z[6,5,2]  R2097     7.9286046326160431e-02
    z[6,5,2]  R2098     -1.4119987189769745e-01
    z[6,5,2]  R2099     7.5469903647899628e-02
    z[6,5,2]  R2100     8.5755802690982819e-02
    z[6,5,2]  R2101     1.5370386838912964e-01
    z[6,5,2]  R2102     -4.9505002796649933e-02
    z[6,5,2]  R2103     -1.8806798756122589e-01
    z[6,5,2]  R2104     -3.7738022208213806e-01
    z[6,5,2]  R2105     -6.8416267633438110e-02
    z[6,5,2]  R2106     -0.0820479691028595
    z[6,5,2]  R2107     -3.6171787977218628e-01
    z[6,5,2]  R2108     -3.1313976645469666e-01
    z[6,5,2]  R2109     4.4587758183479309e-01
    z[6,5,2]  R2110     5.4044306278228760e-01
    z[6,5,2]  R2111     8.6287543177604675e-02
    z[6,5,2]  R2112     -1.0716758668422699e-01
    z[6,5,2]  R2113     -1.1453446745872498e-01
    z[6,5,2]  R2114     1.8362710252404213e-02
    z[6,5,2]  R2115     1.6968338750302792e-03
    z[6,5,2]  R2116     -2.2201403975486755e-01
    z[6,5,2]  R2117     9.5056831836700439e-02
    z[6,5,2]  R2118     1.5280073881149292e-01
    z[6,5,2]  R2119     -6.3114441931247711e-02
    z[6,5,2]  R2120     2.0639857277274132e-02
    z[6,5,2]  R2121     9.0547293424606323e-02
    z[6,5,2]  R2122     -1.0910715162754059e-01
    z[6,5,2]  R2123     -1.8891464173793793e-01
    z[6,5,2]  R2124     4.9798309803009033e-01
    z[6,5,2]  R2125     4.4809807091951370e-02
    z[6,5,2]  R2126     -1.9111575558781624e-02
    z[6,5,2]  R2127     -1.5248617529869080e-01
    z[6,5,2]  R2128     -3.0039435625076294e-01
    z[6,5,2]  R2129     5.9113286435604095e-02
    z[6,5,2]  R2130     -2.2162710130214691e-01
    z[6,5,2]  R2131     -4.8571833968162537e-01
    z[6,5,2]  R2132     4.9689537286758423e-01
    z[6,5,2]  R2133     5.6850421428680420e-01
    z[6,5,2]  R2134     6.2127900123596191e-01
    z[6,5,2]  R2135     3.0722004175186157e-01
    z[6,5,2]  R2136     -7.4626475572586060e-01
    z[6,5,2]  R2137     -1.4325246214866638e-01
    z[6,5,2]  R2138     -6.5372610092163086e-01
    z[6,5,2]  R2139     -8.2315278053283691e-01
    z[6,5,2]  R2140     -9.1736966371536255e-01
    z[6,5,3]  R50       1
    z[6,5,3]  R59       -1
    z[6,5,3]  R2053     -1
    z[6,5,3]  R2054     1
    z[6,5,3]  R2061     -4.3482255935668945e-01
    z[6,5,3]  R2062     -6.6880708932876587e-01
    z[6,5,3]  R2063     -6.3091719150543213e-01
    z[6,5,3]  R2064     -8.8773626089096069e-01
    z[6,5,3]  R2065     3.5299104452133179e-01
    z[6,5,3]  R2066     -2.0625099539756775e-01
    z[6,5,3]  R2067     -5.3459867835044861e-02
    z[6,5,3]  R2068     -1.4415368437767029e-01
    z[6,5,3]  R2069     1.8515148758888245e-01
    z[6,5,3]  R2070     -4.0621495246887207e-01
    z[6,5,3]  R2071     5.9914374724030495e-03
    z[6,5,3]  R2072     -1.2339998036623001e-01
    z[6,5,3]  R2073     -9.4395920634269714e-02
    z[6,5,3]  R2074     3.3934372663497925e-01
    z[6,5,3]  R2075     3.5664927959442139e-01
    z[6,5,3]  R2076     2.5923115015029907e-01
    z[6,5,3]  R2077     2.4068602919578552e-01
    z[6,5,3]  R2078     3.6081379652023315e-01
    z[6,5,3]  R2079     3.6737982183694839e-02
    z[6,5,3]  R2080     4.8667289316654205e-02
    z[6,5,3]  R2081     3.9427277445793152e-01
    z[6,5,3]  R2082     -3.2009461522102356e-01
    z[6,5,3]  R2083     4.8703688383102417e-01
    z[6,5,3]  R2084     1.5347819030284882e-01
    z[6,5,3]  R2085     -1.8350031971931458e-01
    z[6,5,3]  R2086     -4.3879628181457520e-02
    z[6,5,3]  R2087     -3.5146945714950562e-01
    z[6,5,3]  R2088     1.9466623663902283e-01
    z[6,5,3]  R2089     8.0216413736343384e-01
    z[6,5,3]  R2090     2.5773268938064575e-01
    z[6,5,3]  R2091     -2.7117517590522766e-01
    z[6,5,3]  R2092     -4.7600927948951721e-01
    z[6,5,3]  R2093     -1.4765599370002747e-01
    z[6,5,3]  R2094     -5.6458425521850586e-01
    z[6,5,3]  R2095     -5.9491634368896484e-01
    z[6,5,3]  R2096     -7.0506691932678223e-02
    z[6,5,3]  R2097     -1.9790592789649963e-01
    z[6,5,3]  R2098     -7.9035305976867676e-01
    z[6,5,3]  R2099     -9.4377058744430542e-01
    z[6,5,3]  R2100     -3.5162830352783203e-01
    z[6,5,3]  R2101     2.9121702909469604e-01
    z[6,5,3]  R2102     3.5964709520339966e-01
    z[6,5,3]  R2103     2.8630918264389038e-01
    z[6,5,3]  R2104     1.8204185366630554e-01
    z[6,5,3]  R2105     3.5189661383628845e-01
    z[6,5,3]  R2106     0.126349076628685
    z[6,5,3]  R2107     3.8119003176689148e-01
    z[6,5,3]  R2108     1.9082163274288177e-01
    z[6,5,3]  R2109     2.0349277555942535e-01
    z[6,5,3]  R2110     4.1314536333084106e-01
    z[6,5,3]  R2111     -1.8382082879543304e-01
    z[6,5,3]  R2112     5.0531368702650070e-02
    z[6,5,3]  R2113     -4.7703683376312256e-02
    z[6,5,3]  R2114     7.3058776557445526e-02
    z[6,5,3]  R2115     6.2073368579149246e-02
    z[6,5,3]  R2116     -1.0537737607955933e-01
    z[6,5,3]  R2117     -1.1009852588176727e-01
    z[6,5,3]  R2118     -1.0544041544198990e-01
    z[6,5,3]  R2119     3.4839308261871338e-01
    z[6,5,3]  R2120     -9.7356185317039490e-02
    z[6,5,3]  R2121     7.9540932178497314e-01
    z[6,5,3]  R2122     9.0241980552673340e-01
    z[6,5,3]  R2123     7.6731526851654053e-01
    z[6,5,3]  R2124     4.5390194654464722e-01
    z[6,5,3]  R2125     7.6387959718704224e-01
    z[6,5,3]  R2126     7.3146307468414307e-01
    z[6,5,3]  R2127     8.1268757581710815e-01
    z[6,5,3]  R2128     0.729589581489563
    z[6,5,3]  R2129     9.1657906770706177e-01
    z[6,5,3]  R2130     8.6012172698974609e-01
    z[6,5,3]  R2131     1.6754928231239319e-01
    z[6,5,3]  R2132     1.0054871439933777e-01
    z[6,5,3]  R2133     0.241428405046463
    z[6,5,3]  R2134     4.9155864119529724e-01
    z[6,5,3]  R2135     6.8617177009582520e-01
    z[6,5,3]  R2136     5.5428307503461838e-02
    z[6,5,3]  R2137     6.7632216215133667e-01
    z[6,5,3]  R2138     0.325797438621521
    z[6,5,3]  R2139     3.2319170236587524e-01
    z[6,5,3]  R2140     1.0108335316181183e-01
    z[6,5,4]  R51       1
    z[6,5,4]  R60       -1
    z[6,5,4]  R2055     -1
    z[6,5,4]  R2056     1
    z[6,5,4]  R2061     2.7873623371124268e-01
    z[6,5,4]  R2062     -2.4634149670600891e-01
    z[6,5,4]  R2063     3.8980942964553833e-01
    z[6,5,4]  R2064     -2.7859557420015335e-02
    z[6,5,4]  R2065     1.5316751599311829e-01
    z[6,5,4]  R2066     2.8971980791538954e-03
    z[6,5,4]  R2067     -1.4241434633731842e-01
    z[6,5,4]  R2068     -6.5232515335083008e-01
    z[6,5,4]  R2069     6.6785824298858643e-01
    z[6,5,4]  R2070     6.4231920242309570e-01
    z[6,5,4]  R2071     -2.2686882317066193e-01
    z[6,5,4]  R2072     -4.1900625824928284e-01
    z[6,5,4]  R2073     -3.0104938149452209e-01
    z[6,5,4]  R2074     -8.7487086653709412e-02
    z[6,5,4]  R2075     5.2652070298790932e-03
    z[6,5,4]  R2076     -6.4254850149154663e-02
    z[6,5,4]  R2077     -3.3562248945236206e-01
    z[6,5,4]  R2078     -2.0347152650356293e-01
    z[6,5,4]  R2079     -7.7061526477336884e-02
    z[6,5,4]  R2080     -1.4298850297927856e-01
    z[6,5,4]  R2081     -1.4109261333942413e-01
    z[6,5,4]  R2082     5.5168453603982925e-02
    z[6,5,4]  R2083     -1.1341971345245838e-02
    z[6,5,4]  R2084     -3.9437130093574524e-01
    z[6,5,4]  R2085     5.0103694200515747e-01
    z[6,5,4]  R2086     5.6099700927734375e-01
    z[6,5,4]  R2087     8.3675779402256012e-02
    z[6,5,4]  R2088     7.0127105712890625e-01
    z[6,5,4]  R2089     -4.7330036759376526e-01
    z[6,5,4]  R2090     1.8838801980018616e-01
    z[6,5,4]  R2091     3.1745424866676331e-01
    z[6,5,4]  R2092     1.5100608766078949e-01
    z[6,5,4]  R2093     -3.3366572111845016e-02
    z[6,5,4]  R2094     2.5212485343217850e-02
    z[6,5,4]  R2095     6.1498713493347168e-01
    z[6,5,4]  R2096     5.4473882913589478e-01
    z[6,5,4]  R2097     -5.6062227487564087e-01
    z[6,5,4]  R2098     4.1211530566215515e-01
    z[6,5,4]  R2099     -2.3611399531364441e-01
    z[6,5,4]  R2100     -0.600864052772522
    z[6,5,4]  R2101     1.2062467634677887e-01
    z[6,5,4]  R2102     2.7103051543235779e-03
    z[6,5,4]  R2103     -1.8362168967723846e-01
    z[6,5,4]  R2104     1.9852147996425629e-01
    z[6,5,4]  R2105     -1.8536148965358734e-01
    z[6,5,4]  R2106     1.7913419753313065e-02
    z[6,5,4]  R2107     -1.5416552312672138e-02
    z[6,5,4]  R2108     5.2506614476442337e-02
    z[6,5,4]  R2109     -1.8905505537986755e-01
    z[6,5,4]  R2110     -1.3442958891391754e-01
    z[6,5,4]  R2111     1.0738671571016312e-01
    z[6,5,4]  R2112     1.3071611523628235e-01
    z[6,5,4]  R2113     -2.6124227046966553e-01
    z[6,5,4]  R2114     1.3985583186149597e-01
    z[6,5,4]  R2115     1.9706407189369202e-01
    z[6,5,4]  R2116     2.5986665487289429e-01
    z[6,5,4]  R2117     -1.3944509625434875e-01
    z[6,5,4]  R2118     -3.5721737146377563e-01
    z[6,5,4]  R2119     4.8260069452226162e-03
    z[6,5,4]  R2120     -1.7051011323928833e-01
    z[6,5,4]  R2121     -1.7310780286788940e-01
    z[6,5,4]  R2122     1.7404425144195557e-01
    z[6,5,4]  R2123     2.8719502687454224e-01
    z[6,5,4]  R2124     3.1693622469902039e-01
    z[6,5,4]  R2125     -8.1531301140785217e-02
    z[6,5,4]  R2126     3.3749639987945557e-04
    z[6,5,4]  R2127     -2.8895176947116852e-02
    z[6,5,4]  R2128     2.4756672978401184e-01
    z[6,5,4]  R2129     -1.2850125133991241e-01
    z[6,5,4]  R2130     1.2128808349370956e-01
    z[6,5,4]  R2131     -6.8351209163665771e-02
    z[6,5,4]  R2132     -2.2629013657569885e-01
    z[6,5,4]  R2133     -4.3072330951690674e-01
    z[6,5,4]  R2134     3.0957112088799477e-02
    z[6,5,4]  R2135     -2.9939287900924683e-01
    z[6,5,4]  R2136     -1.8057155609130859e-01
    z[6,5,4]  R2137     4.8926612734794617e-01
    z[6,5,4]  R2138     -1.1993906646966934e-01
    z[6,5,4]  R2139     -2.6092376559972763e-02
    z[6,5,4]  R2140     -3.5483011603355408e-01
    z[6,5,5]  R52       1
    z[6,5,5]  R61       -1
    z[6,5,5]  R2057     -1
    z[6,5,5]  R2058     1
    z[6,5,5]  R2061     -7.4104122817516327e-02
    z[6,5,5]  R2062     -8.7971940636634827e-02
    z[6,5,5]  R2063     1.7152974009513855e-01
    z[6,5,5]  R2064     9.0885631740093231e-02
    z[6,5,5]  R2065     4.3337102979421616e-03
    z[6,5,5]  R2066     -3.8824877142906189e-01
    z[6,5,5]  R2067     -2.2742530703544617e-01
    z[6,5,5]  R2068     2.0665295422077179e-01
    z[6,5,5]  R2069     -5.5211347341537476e-01
    z[6,5,5]  R2070     -2.3046933114528656e-01
    z[6,5,5]  R2071     4.7852255403995514e-02
    z[6,5,5]  R2072     2.6644130703061819e-03
    z[6,5,5]  R2073     -1.5615621209144592e-01
    z[6,5,5]  R2074     1.6076974570751190e-01
    z[6,5,5]  R2075     2.3430469632148743e-01
    z[6,5,5]  R2076     2.4470695853233337e-01
    z[6,5,5]  R2077     -0.0658566951751709
    z[6,5,5]  R2078     3.4708563238382339e-02
    z[6,5,5]  R2079     -3.5051450133323669e-01
    z[6,5,5]  R2080     -2.0083734393119812e-01
    z[6,5,5]  R2081     2.6920095086097717e-01
    z[6,5,5]  R2082     1.4070644974708557e-01
    z[6,5,5]  R2083     -1.1504362523555756e-01
    z[6,5,5]  R2084     -3.6810681223869324e-01
    z[6,5,5]  R2085     0.126405268907547
    z[6,5,5]  R2086     -2.9695412516593933e-01
    z[6,5,5]  R2087     -2.9155787825584412e-01
    z[6,5,5]  R2088     -3.6707469820976257e-01
    z[6,5,5]  R2089     -1.0693305730819702e-01
    z[6,5,5]  R2090     -2.5623857975006104e-01
    z[6,5,5]  R2091     4.3785876035690308e-01
    z[6,5,5]  R2092     6.6495560109615326e-02
    z[6,5,5]  R2093     9.5870628952980042e-02
    z[6,5,5]  R2094     -5.5189430713653564e-01
    z[6,5,5]  R2095     -2.6647770404815674e-01
    z[6,5,5]  R2096     -5.6386363506317139e-01
    z[6,5,5]  R2097     -0.0724416971206665
    z[6,5,5]  R2098     2.3566253483295441e-01
    z[6,5,5]  R2099     1.8732255324721336e-02
    z[6,5,5]  R2100     1.3279426097869873e-01
    z[6,5,5]  R2101     -2.3404514417052269e-02
    z[6,5,5]  R2102     2.1368764340877533e-01
    z[6,5,5]  R2103     -2.6740193367004395e-01
    z[6,5,5]  R2104     4.6200025826692581e-02
    z[6,5,5]  R2105     -1.7845694720745087e-01
    z[6,5,5]  R2106     6.7630611360073090e-02
    z[6,5,5]  R2107     1.6359809041023254e-01
    z[6,5,5]  R2108     3.9603692293167114e-01
    z[6,5,5]  R2109     2.8254750370979309e-01
    z[6,5,5]  R2110     -5.0018376111984253e-01
    z[6,5,5]  R2111     4.6970881521701813e-02
    z[6,5,5]  R2112     -8.5598759353160858e-02
    z[6,5,5]  R2113     -1.7107465537264943e-03
    z[6,5,5]  R2114     2.8520816564559937e-01
    z[6,5,5]  R2115     2.7119019627571106e-01
    z[6,5,5]  R2116     1.1809702217578888e-01
    z[6,5,5]  R2117     2.9165685176849365e-01
    z[6,5,5]  R2118     2.0493675768375397e-01
    z[6,5,5]  R2119     1.4271101355552673e-01
    z[6,5,5]  R2120     -1.5288364887237549e-01
    z[6,5,5]  R2121     -9.8025634884834290e-02
    z[6,5,5]  R2122     3.1905624270439148e-01
    z[6,5,5]  R2123     5.2297419309616089e-01
    z[6,5,5]  R2124     5.7966765016317368e-02
    z[6,5,5]  R2125     5.9351056814193726e-01
    z[6,5,5]  R2126     6.4435964822769165e-01
    z[6,5,5]  R2127     3.3072790503501892e-01
    z[6,5,5]  R2128     2.7507367730140686e-01
    z[6,5,5]  R2129     3.1214219331741333e-01
    z[6,5,5]  R2130     2.7602595090866089e-01
    z[6,5,5]  R2131     6.4252525568008423e-01
    z[6,5,5]  R2132     -6.9482362270355225e-01
    z[6,5,5]  R2133     -4.7868281602859497e-01
    z[6,5,5]  R2134     -2.6825106143951416e-01
    z[6,5,5]  R2135     -4.0879970788955688e-01
    z[6,5,5]  R2136     1.0618981719017029e-01
    z[6,5,5]  R2137     -2.7660626173019409e-01
    z[6,5,5]  R2138     -0.265129953622818
    z[6,5,5]  R2139     -0.184409961104393
    z[6,5,5]  R2140     -1.3089528679847717e-01
    z[6,5,6]  R53       1
    z[6,5,6]  R62       -1
    z[6,5,6]  R2059     -1
    z[6,5,6]  R2060     1
    z[6,5,6]  R2061     4.8355132341384888e-01
    z[6,5,6]  R2062     -9.0920282527804375e-03
    z[6,5,6]  R2063     -2.6311388611793518e-01
    z[6,5,6]  R2064     -3.0015598982572556e-02
    z[6,5,6]  R2065     -1.8063063919544220e-01
    z[6,5,6]  R2066     -6.3621199131011963e-01
    z[6,5,6]  R2067     -5.5297023057937622e-01
    z[6,5,6]  R2068     -0.383078396320343
    z[6,5,6]  R2069     -1.8707031011581421e-01
    z[6,5,6]  R2070     -1.0841947793960571e-01
    z[6,5,6]  R2071     -1.3852114975452423e-01
    z[6,5,6]  R2072     -1.6892676055431366e-01
    z[6,5,6]  R2073     8.8624767959117889e-02
    z[6,5,6]  R2074     -1.8772609531879425e-01
    z[6,5,6]  R2075     2.9278010129928589e-01
    z[6,5,6]  R2076     3.6769318580627441e-01
    z[6,5,6]  R2077     2.5093591213226318e-01
    z[6,5,6]  R2078     -2.7502483129501343e-01
    z[6,5,6]  R2079     4.3142339587211609e-01
    z[6,5,6]  R2080     4.3329083919525146e-01
    z[6,5,6]  R2081     1.1154074221849442e-02
    z[6,5,6]  R2082     4.9266304820775986e-02
    z[6,5,6]  R2083     -2.8843957185745239e-01
    z[6,5,6]  R2084     -1.4732936024665833e-01
    z[6,5,6]  R2085     -1.9844852387905121e-01
    z[6,5,6]  R2086     -2.8243076801300049e-01
    z[6,5,6]  R2087     1.6130003333091736e-01
    z[6,5,6]  R2088     9.2413134872913361e-02
    z[6,5,6]  R2089     -1.2626359239220619e-02
    z[6,5,6]  R2090     -3.2690886408090591e-02
    z[6,5,6]  R2091     8.0957688391208649e-02
    z[6,5,6]  R2092     -3.4397414326667786e-01
    z[6,5,6]  R2093     6.4615708589553833e-01
    z[6,5,6]  R2094     -2.3646888136863708e-01
    z[6,5,6]  R2095     -1.1964805424213409e-01
    z[6,5,6]  R2096     3.0197387933731079e-01
    z[6,5,6]  R2097     5.7622170448303223e-01
    z[6,5,6]  R2098     1.6219522058963776e-01
    z[6,5,6]  R2099     1.8480627238750458e-01
    z[6,5,6]  R2100     -5.5185484886169434e-01
    z[6,5,6]  R2101     -1.8415758013725281e-01
    z[6,5,6]  R2102     1.9979397952556610e-01
    z[6,5,6]  R2103     2.6502721011638641e-02
    z[6,5,6]  R2104     5.8454845100641251e-02
    z[6,5,6]  R2105     2.6878777146339417e-01
    z[6,5,6]  R2106     5.2808779478073120e-01
    z[6,5,6]  R2107     0.0251354668289423
    z[6,5,6]  R2108     5.8104624040424824e-03
    z[6,5,6]  R2109     1.8169216811656952e-01
    z[6,5,6]  R2110     -3.1947222352027893e-01
    z[6,5,6]  R2111     1.5235188184306026e-03
    z[6,5,6]  R2112     1.4149212837219238e-01
    z[6,5,6]  R2113     -1.9565482437610626e-01
    z[6,5,6]  R2114     1.0147751308977604e-02
    z[6,5,6]  R2115     1.7726825177669525e-01
    z[6,5,6]  R2116     1.1284652352333069e-01
    z[6,5,6]  R2117     2.0842906832695007e-01
    z[6,5,6]  R2118     1.7213482409715652e-02
    z[6,5,6]  R2119     1.8577785789966583e-01
    z[6,5,6]  R2120     2.8011232614517212e-01
    z[6,5,6]  R2121     -2.3333968222141266e-01
    z[6,5,6]  R2122     -8.0126136541366577e-02
    z[6,5,6]  R2123     1.1936999112367630e-01
    z[6,5,6]  R2124     -0.127571240067482
    z[6,5,6]  R2125     -7.4037462472915649e-02
    z[6,5,6]  R2126     3.6459332332015038e-03
    z[6,5,6]  R2127     -6.6365584731101990e-02
    z[6,5,6]  R2128     -7.7897600829601288e-02
    z[6,5,6]  R2129     3.7438657134771347e-02
    z[6,5,6]  R2130     3.0738350749015808e-01
    z[6,5,6]  R2131     -2.0351428538560867e-02
    z[6,5,6]  R2132     7.8848786652088165e-02
    z[6,5,6]  R2133     -1.6353467106819153e-01
    z[6,5,6]  R2134     -1.4448726177215576e-01
    z[6,5,6]  R2135     -1.6862553358078003e-01
    z[6,5,6]  R2136     -1.4177618920803070e-01
    z[6,5,6]  R2137     -1.6087600588798523e-01
    z[6,5,6]  R2138     -2.5461369752883911e-01
    z[6,5,6]  R2139     2.0681983232498169e-01
    z[6,5,6]  R2140     -4.7515518963336945e-02
    z[6,7,0]  R56       -1
    z[6,7,0]  R65       1
    z[6,7,0]  R2141     -1
    z[6,7,0]  R2142     1
    z[6,7,0]  R2155     4.4093447923660278e-01
    z[6,7,0]  R2156     5.4805117845535278e-01
    z[6,7,0]  R2157     4.2255589365959167e-01
    z[6,7,0]  R2158     2.7814289927482605e-01
    z[6,7,0]  R2159     8.4848684072494507e-01
    z[6,7,0]  R2160     0.589670717716217
    z[6,7,0]  R2161     7.0288866758346558e-01
    z[6,7,0]  R2162     5.5329144001007080e-01
    z[6,7,0]  R2163     -3.2655516266822815e-01
    z[6,7,0]  R2164     -5.2858823537826538e-01
    z[6,7,0]  R2165     -8.0339974164962769e-01
    z[6,7,0]  R2166     -6.9192576408386230e-01
    z[6,7,0]  R2167     -8.2773417234420776e-01
    z[6,7,0]  R2168     -6.3882762193679810e-01
    z[6,7,0]  R2169     -6.0439628362655640e-01
    z[6,7,0]  R2170     -7.2977793216705322e-01
    z[6,7,0]  R2171     -0.559395968914032
    z[6,7,0]  R2172     -5.0156968832015991e-01
    z[6,7,0]  R2173     3.1622976064682007e-01
    z[6,7,0]  R2174     0.315693736076355
    z[6,7,0]  R2175     -2.8708526492118835e-01
    z[6,7,0]  R2176     -7.2947657108306885e-01
    z[6,7,0]  R2177     -0.335328608751297
    z[6,7,0]  R2178     -4.7691029310226440e-01
    z[6,7,0]  R2179     -2.0829641819000244e-01
    z[6,7,0]  R2180     -3.3500516414642334e-01
    z[6,7,0]  R2181     -3.4237566590309143e-01
    z[6,7,0]  R2182     -4.5555812120437622e-01
    z[6,7,0]  R2183     -3.1280595064163208e-01
    z[6,7,0]  R2184     -4.9793234467506409e-01
    z[6,7,0]  R2185     -1.8409195542335510e-01
    z[6,7,0]  R2186     -0.286214679479599
    z[6,7,0]  R2187     -1.7760060727596283e-01
    z[6,7,0]  R2188     6.9870322942733765e-02
    z[6,7,0]  R2189     -4.9463465809822083e-02
    z[6,7,0]  R2190     -1.1441210657358170e-01
    z[6,7,0]  R2191     -2.2823843359947205e-01
    z[6,7,0]  R2192     2.3409046232700348e-01
    z[6,7,0]  R2193     1.5582002699375153e-01
    z[6,7,0]  R2194     3.5205134749412537e-01
    z[6,7,0]  R2195     -8.0105133354663849e-02
    z[6,7,0]  R2196     -2.0721285045146942e-01
    z[6,7,0]  R2197     2.8006890416145325e-01
    z[6,7,0]  R2198     -2.6431012153625488e-01
    z[6,7,0]  R2199     -1.7840294539928436e-01
    z[6,7,0]  R2200     3.0782647430896759e-02
    z[6,7,0]  R2201     -0.241979718208313
    z[6,7,0]  R2202     -0.274396151304245
    z[6,7,0]  R2203     2.2456000745296478e-01
    z[6,7,0]  R2204     2.8472054004669189e-01
    z[6,7,0]  R2205     1.5407499670982361e-01
    z[6,7,0]  R2206     -4.5860470272600651e-03
    z[6,7,0]  R2207     -4.5927211642265320e-02
    z[6,7,0]  R2208     1.8447707593441010e-01
    z[6,7,0]  R2209     1.8028499186038971e-01
    z[6,7,0]  R2210     -0.0827464833855629
    z[6,7,0]  R2211     8.5019731521606445e-01
    z[6,7,0]  R2212     7.8297829627990723e-01
    z[6,7,0]  R2213     6.7507582902908325e-01
    z[6,7,0]  R2214     6.6264832019805908e-01
    z[6,7,0]  R2215     -3.6828601360321045e-01
    z[6,7,0]  R2216     4.8666980117559433e-02
    z[6,7,0]  R2217     2.9973436146974564e-02
    z[6,7,0]  R2218     -1.4538391493260860e-02
    z[6,7,0]  R2219     -3.9435279369354248e-01
    z[6,7,0]  R2220     -1.8094129860401154e-01
    z[6,7,0]  R2221     6.6815757751464844e-01
    z[6,7,0]  R2222     9.5584966242313385e-02
    z[6,7,0]  R2223     -4.8523190617561340e-01
    z[6,7,1]  R57       -1
    z[6,7,1]  R66       1
    z[6,7,1]  R2143     -1
    z[6,7,1]  R2144     1
    z[6,7,1]  R2155     -4.4560983777046204e-01
    z[6,7,1]  R2156     -2.3848210275173187e-01
    z[6,7,1]  R2157     -2.3731166124343872e-01
    z[6,7,1]  R2158     -3.2478284835815430e-01
    z[6,7,1]  R2159     -1.8467797338962555e-01
    z[6,7,1]  R2160     -2.2657305002212524e-01
    z[6,7,1]  R2161     5.1507562398910522e-02
    z[6,7,1]  R2162     -2.2879233956336975e-01
    z[6,7,1]  R2163     -4.6031586825847626e-02
    z[6,7,1]  R2164     -1.5255342423915863e-01
    z[6,7,1]  R2165     0.450044721364975
    z[6,7,1]  R2166     5.4803127050399780e-01
    z[6,7,1]  R2167     4.2429828643798828e-01
    z[6,7,1]  R2168     6.0195136070251465e-01
    z[6,7,1]  R2169     5.9679871797561646e-01
    z[6,7,1]  R2170     4.4608011841773987e-01
    z[6,7,1]  R2171     5.3579425811767578e-01
    z[6,7,1]  R2172     -5.9169030189514160e-01
    z[6,7,1]  R2173     5.9061861038208008e-01
    z[6,7,1]  R2174     5.8953213691711426e-01
    z[6,7,1]  R2175     -7.0820778608322144e-01
    z[6,7,1]  R2176     5.7110726833343506e-01
    z[6,7,1]  R2177     -7.0824992656707764e-01
    z[6,7,1]  R2178     -6.5907132625579834e-01
    z[6,7,1]  R2179     7.7580267190933228e-01
    z[6,7,1]  R2180     6.1687922477722168e-01
    z[6,7,1]  R2181     0.546272873878479
    z[6,7,1]  R2182     3.2558700442314148e-01
    z[6,7,1]  R2183     -9.1125704348087311e-02
    z[6,7,1]  R2184     -4.3750718235969543e-01
    z[6,7,1]  R2185     -1.5911084413528442e-01
    z[6,7,1]  R2186     5.5689144134521484e-01
    z[6,7,1]  R2187     0.486074298620224
    z[6,7,1]  R2188     6.2916010618209839e-01
    z[6,7,1]  R2189     7.9231232404708862e-01
    z[6,7,1]  R2190     -1.3732153177261353e-01
    z[6,7,1]  R2191     -3.6912813782691956e-01
    z[6,7,1]  R2192     -1.3534417748451233e-01
    z[6,7,1]  R2193     -7.3680929839611053e-02
    z[6,7,1]  R2194     -0.0723814144730568
    z[6,7,1]  R2195     -7.2034609317779541e-01
    z[6,7,1]  R2196     -0.61319500207901
    z[6,7,1]  R2197     -9.4503128528594971e-01
    z[6,7,1]  R2198     -7.6930946111679077e-01
    z[6,7,1]  R2199     2.6116809248924255e-01
    z[6,7,1]  R2200     3.6502429842948914e-01
    z[6,7,1]  R2201     -1.9301742315292358e-01
    z[6,7,1]  R2202     -3.6066219210624695e-02
    z[6,7,1]  R2203     0.0985545814037323
    z[6,7,1]  R2204     9.0866394340991974e-02
    z[6,7,1]  R2205     -8.9232005178928375e-02
    z[6,7,1]  R2206     1.0712014138698578e-01
    z[6,7,1]  R2207     -2.0952789485454559e-01
    z[6,7,1]  R2208     1.0200225561857224e-01
    z[6,7,1]  R2209     -2.9675036668777466e-01
    z[6,7,1]  R2210     -3.8716565817594528e-02
    z[6,7,1]  R2211     2.2629378736019135e-01
    z[6,7,1]  R2212     1.1142539232969284e-01
    z[6,7,1]  R2213     -4.9738310277462006e-02
    z[6,7,1]  R2214     1.3619263470172882e-01
    z[6,7,1]  R2215     -2.9825264215469360e-01
    z[6,7,1]  R2216     0.158810555934906
    z[6,7,1]  R2217     6.5514102578163147e-02
    z[6,7,1]  R2218     2.4066442251205444e-01
    z[6,7,1]  R2219     8.1417721509933472e-01
    z[6,7,1]  R2220     7.5963789224624634e-01
    z[6,7,1]  R2221     9.3840479850769043e-02
    z[6,7,1]  R2222     7.4448043107986450e-01
    z[6,7,1]  R2223     5.1961439847946167e-01
    z[6,7,2]  R58       -1
    z[6,7,2]  R67       1
    z[6,7,2]  R2145     -1
    z[6,7,2]  R2146     1
    z[6,7,2]  R2155     3.1769603490829468e-01
    z[6,7,2]  R2156     3.5631069540977478e-01
    z[6,7,2]  R2157     -3.4127756953239441e-01
    z[6,7,2]  R2158     -1.3834577798843384e-01
    z[6,7,2]  R2159     2.5545054674148560e-01
    z[6,7,2]  R2160     5.3873889148235321e-02
    z[6,7,2]  R2161     3.5022327303886414e-01
    z[6,7,2]  R2162     -7.5893305242061615e-02
    z[6,7,2]  R2163     2.6665067672729492e-01
    z[6,7,2]  R2164     2.3423585295677185e-01
    z[6,7,2]  R2165     -2.8111422061920166e-01
    z[6,7,2]  R2166     -0.0395394004881382
    z[6,7,2]  R2167     5.5197715759277344e-02
    z[6,7,2]  R2168     -2.1367651224136353e-01
    z[6,7,2]  R2169     1.0339756309986115e-01
    z[6,7,2]  R2170     -4.5027423650026321e-02
    z[6,7,2]  R2171     4.0264445543289185e-01
    z[6,7,2]  R2172     -3.8716900348663330e-01
    z[6,7,2]  R2173     -4.8465827107429504e-01
    z[6,7,2]  R2174     -5.4945284128189087e-01
    z[6,7,2]  R2175     4.0996581315994263e-01
    z[6,7,2]  R2176     -1.1819826811552048e-01
    z[6,7,2]  R2177     2.2840917110443115e-01
    z[6,7,2]  R2178     4.3458785861730576e-02
    z[6,7,2]  R2179     1.2112908810377121e-01
    z[6,7,2]  R2180     0.15046426653862
    z[6,7,2]  R2181     0.585498571395874
    z[6,7,2]  R2182     1.1618865281343460e-01
    z[6,7,2]  R2183     -1.2154792249202728e-01
    z[6,7,2]  R2184     -6.2610512971878052e-01
    z[6,7,2]  R2185     4.7734364867210388e-01
    z[6,7,2]  R2186     -6.9811606407165527e-01
    z[6,7,2]  R2187     -0.759968638420105
    z[6,7,2]  R2188     -5.7033151388168335e-01
    z[6,7,2]  R2189     -3.0093312263488770e-01
    z[6,7,2]  R2190     0.409659206867218
    z[6,7,2]  R2191     0.425683856010437
    z[6,7,2]  R2192     0.727834939956665
    z[6,7,2]  R2193     3.4167951345443726e-01
    z[6,7,2]  R2194     3.2505834102630615e-01
    z[6,7,2]  R2195     4.1031163930892944e-01
    z[6,7,2]  R2196     4.7157713770866394e-01
    z[6,7,2]  R2197     -6.8214975297451019e-02
    z[6,7,2]  R2198     -1.5069937705993652e-01
    z[6,7,2]  R2199     0.854481041431427
    z[6,7,2]  R2200     1.1533088982105255e-01
    z[6,7,2]  R2201     -8.7620846927165985e-02
    z[6,7,2]  R2202     -6.3486829400062561e-02
    z[6,7,2]  R2203     1.2221843935549259e-02
    z[6,7,2]  R2204     2.0777745544910431e-01
    z[6,7,2]  R2205     0.566098690032959
    z[6,7,2]  R2206     8.9974778890609741e-01
    z[6,7,2]  R2207     3.7261152267456055e-01
    z[6,7,2]  R2208     7.3742020130157471e-01
    z[6,7,2]  R2209     5.4701465368270874e-01
    z[6,7,2]  R2210     3.7120354175567627e-01
    z[6,7,2]  R2211     1.7128667235374451e-01
    z[6,7,2]  R2212     8.9861951768398285e-02
    z[6,7,2]  R2213     4.6292895078659058e-01
    z[6,7,2]  R2214     -1.5902958810329437e-01
    z[6,7,2]  R2215     5.0795876979827881e-01
    z[6,7,2]  R2216     -8.3484035730361938e-01
    z[6,7,2]  R2217     7.7183127403259277e-01
    z[6,7,2]  R2218     -2.4677228927612305e-01
    z[6,7,2]  R2219     3.4455919265747070e-01
    z[6,7,2]  R2220     1.7628923058509827e-01
    z[6,7,2]  R2221     -2.6017928123474121e-01
    z[6,7,2]  R2222     1.0638079047203064e-01
    z[6,7,2]  R2223     1.4143446087837219e-01
    z[6,7,3]  R59       -1
    z[6,7,3]  R68       1
    z[6,7,3]  R2147     -1
    z[6,7,3]  R2148     1
    z[6,7,3]  R2155     -4.3482255935668945e-01
    z[6,7,3]  R2156     -6.6880708932876587e-01
    z[6,7,3]  R2157     -6.3091719150543213e-01
    z[6,7,3]  R2158     -8.8773626089096069e-01
    z[6,7,3]  R2159     3.5299104452133179e-01
    z[6,7,3]  R2160     -2.0625099539756775e-01
    z[6,7,3]  R2161     -5.3459867835044861e-02
    z[6,7,3]  R2162     -1.4415368437767029e-01
    z[6,7,3]  R2163     1.8515148758888245e-01
    z[6,7,3]  R2164     -4.0621495246887207e-01
    z[6,7,3]  R2165     5.9914374724030495e-03
    z[6,7,3]  R2166     -1.2339998036623001e-01
    z[6,7,3]  R2167     -9.4395920634269714e-02
    z[6,7,3]  R2168     3.3934372663497925e-01
    z[6,7,3]  R2169     3.5664927959442139e-01
    z[6,7,3]  R2170     2.5923115015029907e-01
    z[6,7,3]  R2171     2.4068602919578552e-01
    z[6,7,3]  R2172     3.6081379652023315e-01
    z[6,7,3]  R2173     3.6737982183694839e-02
    z[6,7,3]  R2174     4.8667289316654205e-02
    z[6,7,3]  R2175     3.9427277445793152e-01
    z[6,7,3]  R2176     -3.2009461522102356e-01
    z[6,7,3]  R2177     4.8703688383102417e-01
    z[6,7,3]  R2178     1.5347819030284882e-01
    z[6,7,3]  R2179     -1.8350031971931458e-01
    z[6,7,3]  R2180     -4.3879628181457520e-02
    z[6,7,3]  R2181     -3.5146945714950562e-01
    z[6,7,3]  R2182     1.9466623663902283e-01
    z[6,7,3]  R2183     8.0216413736343384e-01
    z[6,7,3]  R2184     2.5773268938064575e-01
    z[6,7,3]  R2185     -3.1089496612548828e-01
    z[6,7,3]  R2186     -4.5976629480719566e-03
    z[6,7,3]  R2187     -1.9953125715255737e-01
    z[6,7,3]  R2188     1.4465105533599854e-01
    z[6,7,3]  R2189     -1.1274618655443192e-01
    z[6,7,3]  R2190     -5.4057633876800537e-01
    z[6,7,3]  R2191     -6.1465138196945190e-01
    z[6,7,3]  R2192     -7.2582453489303589e-02
    z[6,7,3]  R2193     2.4491086602210999e-01
    z[6,7,3]  R2194     7.6523773372173309e-02
    z[6,7,3]  R2195     -2.3758205771446228e-01
    z[6,7,3]  R2196     5.9345021843910217e-02
    z[6,7,3]  R2197     -1.0046973824501038e-01
    z[6,7,3]  R2198     -2.6489657163619995e-01
    z[6,7,3]  R2199     -1.1019768565893173e-01
    z[6,7,3]  R2200     7.7369767427444458e-01
    z[6,7,3]  R2201     6.9227272272109985e-01
    z[6,7,3]  R2202     5.7540297508239746e-01
    z[6,7,3]  R2203     5.9350687265396118e-01
    z[6,7,3]  R2204     0.672277569770813
    z[6,7,3]  R2205     1.3080467283725739e-01
    z[6,7,3]  R2206     -1.2148908525705338e-01
    z[6,7,3]  R2207     -2.7065485715866089e-01
    z[6,7,3]  R2208     1.1624167859554291e-01
    z[6,7,3]  R2209     -1.5676201879978180e-01
    z[6,7,3]  R2210     -3.5875433683395386e-01
    z[6,7,3]  R2211     -4.3203625082969666e-01
    z[6,7,3]  R2212     -5.5732291936874390e-01
    z[6,7,3]  R2213     4.2104315757751465e-01
    z[6,7,3]  R2214     -6.8754607439041138e-01
    z[6,7,3]  R2215     -5.0349420309066772e-01
    z[6,7,3]  R2216     -1.9803847372531891e-01
    z[6,7,3]  R2217     -1.1736599728465080e-02
    z[6,7,3]  R2218     -2.4125337600708008e-01
    z[6,7,3]  R2219     6.0481783002614975e-02
    z[6,7,3]  R2220     8.9068122208118439e-02
    z[6,7,3]  R2221     -2.5103783607482910e-01
    z[6,7,3]  R2222     0.502587616443634
    z[6,7,3]  R2223     -3.6166378855705261e-01
    z[6,7,4]  R60       -1
    z[6,7,4]  R69       1
    z[6,7,4]  R2149     -1
    z[6,7,4]  R2150     1
    z[6,7,4]  R2155     2.7873623371124268e-01
    z[6,7,4]  R2156     -2.4634149670600891e-01
    z[6,7,4]  R2157     3.8980942964553833e-01
    z[6,7,4]  R2158     -2.7859557420015335e-02
    z[6,7,4]  R2159     1.5316751599311829e-01
    z[6,7,4]  R2160     2.8971980791538954e-03
    z[6,7,4]  R2161     -1.4241434633731842e-01
    z[6,7,4]  R2162     -6.5232515335083008e-01
    z[6,7,4]  R2163     6.6785824298858643e-01
    z[6,7,4]  R2164     6.4231920242309570e-01
    z[6,7,4]  R2165     -2.2686882317066193e-01
    z[6,7,4]  R2166     -4.1900625824928284e-01
    z[6,7,4]  R2167     -3.0104938149452209e-01
    z[6,7,4]  R2168     -8.7487086653709412e-02
    z[6,7,4]  R2169     5.2652070298790932e-03
    z[6,7,4]  R2170     -6.4254850149154663e-02
    z[6,7,4]  R2171     -3.3562248945236206e-01
    z[6,7,4]  R2172     -2.0347152650356293e-01
    z[6,7,4]  R2173     -7.7061526477336884e-02
    z[6,7,4]  R2174     -1.4298850297927856e-01
    z[6,7,4]  R2175     -1.4109261333942413e-01
    z[6,7,4]  R2176     5.5168453603982925e-02
    z[6,7,4]  R2177     -1.1341971345245838e-02
    z[6,7,4]  R2178     -3.9437130093574524e-01
    z[6,7,4]  R2179     5.0103694200515747e-01
    z[6,7,4]  R2180     5.6099700927734375e-01
    z[6,7,4]  R2181     8.3675779402256012e-02
    z[6,7,4]  R2182     7.0127105712890625e-01
    z[6,7,4]  R2183     -4.7330036759376526e-01
    z[6,7,4]  R2184     1.8838801980018616e-01
    z[6,7,4]  R2185     -4.2951282858848572e-01
    z[6,7,4]  R2186     -3.1544342637062073e-01
    z[6,7,4]  R2187     -2.0930638536810875e-02
    z[6,7,4]  R2188     -2.9720824956893921e-01
    z[6,7,4]  R2189     -2.6059493422508240e-01
    z[6,7,4]  R2190     -5.3116768598556519e-01
    z[6,7,4]  R2191     4.5812425017356873e-01
    z[6,7,4]  R2192     -5.1798480749130249e-01
    z[6,7,4]  R2193     8.3333963155746460e-01
    z[6,7,4]  R2194     6.1238336563110352e-01
    z[6,7,4]  R2195     2.2035986185073853e-01
    z[6,7,4]  R2196     1.0738736391067505e-01
    z[6,7,4]  R2197     0.0919412299990654
    z[6,7,4]  R2198     -3.5267257690429688e-01
    z[6,7,4]  R2199     3.7516683340072632e-01
    z[6,7,4]  R2200     1.6356931626796722e-01
    z[6,7,4]  R2201     3.1342211365699768e-01
    z[6,7,4]  R2202     1.6645228862762451e-01
    z[6,7,4]  R2203     3.8846645504236221e-02
    z[6,7,4]  R2204     -5.2337568253278732e-02
    z[6,7,4]  R2205     7.2469997406005859e-01
    z[6,7,4]  R2206     3.1810739636421204e-01
    z[6,7,4]  R2207     2.3945939540863037e-01
    z[6,7,4]  R2208     -7.5018614530563354e-02
    z[6,7,4]  R2209     2.9431456327438354e-01
    z[6,7,4]  R2210     5.8305406570434570e-01
    z[6,7,4]  R2211     8.7009154260158539e-02
    z[6,7,4]  R2212     -1.7532825469970703e-02
    z[6,7,4]  R2213     -5.7780440896749496e-02
    z[6,7,4]  R2214     1.6788609325885773e-01
    z[6,7,4]  R2215     -2.7590867877006531e-01
    z[6,7,4]  R2216     -3.0516344308853149e-01
    z[6,7,4]  R2217     5.5181443691253662e-01
    z[6,7,4]  R2218     -0.774170458316803
    z[6,7,4]  R2219     7.4755914509296417e-02
    z[6,7,4]  R2220     3.0793941020965576e-01
    z[6,7,4]  R2221     -4.9027469754219055e-01
    z[6,7,4]  R2222     2.8126803040504456e-01
    z[6,7,4]  R2223     2.7190479636192322e-01
    z[6,7,5]  R61       -1
    z[6,7,5]  R70       1
    z[6,7,5]  R2151     -1
    z[6,7,5]  R2152     1
    z[6,7,5]  R2155     -7.4104122817516327e-02
    z[6,7,5]  R2156     -8.7971940636634827e-02
    z[6,7,5]  R2157     1.7152974009513855e-01
    z[6,7,5]  R2158     9.0885631740093231e-02
    z[6,7,5]  R2159     4.3337102979421616e-03
    z[6,7,5]  R2160     -3.8824877142906189e-01
    z[6,7,5]  R2161     -2.2742530703544617e-01
    z[6,7,5]  R2162     2.0665295422077179e-01
    z[6,7,5]  R2163     -5.5211347341537476e-01
    z[6,7,5]  R2164     -2.3046933114528656e-01
    z[6,7,5]  R2165     4.7852255403995514e-02
    z[6,7,5]  R2166     2.6644130703061819e-03
    z[6,7,5]  R2167     -1.5615621209144592e-01
    z[6,7,5]  R2168     1.6076974570751190e-01
    z[6,7,5]  R2169     2.3430469632148743e-01
    z[6,7,5]  R2170     2.4470695853233337e-01
    z[6,7,5]  R2171     -0.0658566951751709
    z[6,7,5]  R2172     3.4708563238382339e-02
    z[6,7,5]  R2173     -3.5051450133323669e-01
    z[6,7,5]  R2174     -2.0083734393119812e-01
    z[6,7,5]  R2175     2.6920095086097717e-01
    z[6,7,5]  R2176     1.4070644974708557e-01
    z[6,7,5]  R2177     -1.1504362523555756e-01
    z[6,7,5]  R2178     -3.6810681223869324e-01
    z[6,7,5]  R2179     0.126405268907547
    z[6,7,5]  R2180     -2.9695412516593933e-01
    z[6,7,5]  R2181     -2.9155787825584412e-01
    z[6,7,5]  R2182     -3.6707469820976257e-01
    z[6,7,5]  R2183     -1.0693305730819702e-01
    z[6,7,5]  R2184     -2.5623857975006104e-01
    z[6,7,5]  R2185     2.1249738335609436e-01
    z[6,7,5]  R2186     9.7575500607490540e-02
    z[6,7,5]  R2187     -2.8740197420120239e-01
    z[6,7,5]  R2188     -4.0070423483848572e-01
    z[6,7,5]  R2189     -2.6399818062782288e-01
    z[6,7,5]  R2190     -3.3271342515945435e-02
    z[6,7,5]  R2191     -1.6200518608093262e-01
    z[6,7,5]  R2192     -2.4048025906085968e-01
    z[6,7,5]  R2193     1.5181684494018555e-01
    z[6,7,5]  R2194     -5.8379513025283813e-01
    z[6,7,5]  R2195     0.448576956987381
    z[6,7,5]  R2196     1.0339719057083130e-01
    z[6,7,5]  R2197     2.7096045669168234e-03
    z[6,7,5]  R2198     -1.6674175858497620e-02
    z[6,7,5]  R2199     -1.2662614881992340e-01
    z[6,7,5]  R2200     4.7588792443275452e-01
    z[6,7,5]  R2201     5.2533394098281860e-01
    z[6,7,5]  R2202     7.4735182523727417e-01
    z[6,7,5]  R2203     0.757960855960846
    z[6,7,5]  R2204     6.1516475677490234e-01
    z[6,7,5]  R2205     -3.2071188092231750e-01
    z[6,7,5]  R2206     -1.7135214805603027e-01
    z[6,7,5]  R2207     -8.2692736387252808e-01
    z[6,7,5]  R2208     -6.2636774778366089e-01
    z[6,7,5]  R2209     -6.6426640748977661e-01
    z[6,7,5]  R2210     -5.6905966997146606e-01
    z[6,7,5]  R2211     3.7096012383699417e-02
    z[6,7,5]  R2212     -2.2875617444515228e-01
    z[6,7,5]  R2213     2.0202431082725525e-01
    z[6,7,5]  R2214     9.1030269861221313e-02
    z[6,7,5]  R2215     -4.3095922470092773e-01
    z[6,7,5]  R2216     -1.9343747198581696e-01
    z[6,7,5]  R2217     -3.0414286255836487e-01
    z[6,7,5]  R2218     2.2270156443119049e-01
    z[6,7,5]  R2219     -5.6840542703866959e-02
    z[6,7,5]  R2220     4.9189507961273193e-01
    z[6,7,5]  R2221     2.0848602056503296e-01
    z[6,7,5]  R2222     2.7616280317306519e-01
    z[6,7,5]  R2223     0.472983181476593
    z[6,7,6]  R62       -1
    z[6,7,6]  R71       1
    z[6,7,6]  R2153     -1
    z[6,7,6]  R2154     1
    z[6,7,6]  R2155     4.8355132341384888e-01
    z[6,7,6]  R2156     -9.0920282527804375e-03
    z[6,7,6]  R2157     -2.6311388611793518e-01
    z[6,7,6]  R2158     -3.0015598982572556e-02
    z[6,7,6]  R2159     -1.8063063919544220e-01
    z[6,7,6]  R2160     -6.3621199131011963e-01
    z[6,7,6]  R2161     -5.5297023057937622e-01
    z[6,7,6]  R2162     -0.383078396320343
    z[6,7,6]  R2163     -1.8707031011581421e-01
    z[6,7,6]  R2164     -1.0841947793960571e-01
    z[6,7,6]  R2165     -1.3852114975452423e-01
    z[6,7,6]  R2166     -1.6892676055431366e-01
    z[6,7,6]  R2167     8.8624767959117889e-02
    z[6,7,6]  R2168     -1.8772609531879425e-01
    z[6,7,6]  R2169     2.9278010129928589e-01
    z[6,7,6]  R2170     3.6769318580627441e-01
    z[6,7,6]  R2171     2.5093591213226318e-01
    z[6,7,6]  R2172     -2.7502483129501343e-01
    z[6,7,6]  R2173     4.3142339587211609e-01
    z[6,7,6]  R2174     4.3329083919525146e-01
    z[6,7,6]  R2175     1.1154074221849442e-02
    z[6,7,6]  R2176     4.9266304820775986e-02
    z[6,7,6]  R2177     -2.8843957185745239e-01
    z[6,7,6]  R2178     -1.4732936024665833e-01
    z[6,7,6]  R2179     -1.9844852387905121e-01
    z[6,7,6]  R2180     -2.8243076801300049e-01
    z[6,7,6]  R2181     1.6130003333091736e-01
    z[6,7,6]  R2182     9.2413134872913361e-02
    z[6,7,6]  R2183     -1.2626359239220619e-02
    z[6,7,6]  R2184     -3.2690886408090591e-02
    z[6,7,6]  R2185     6.2180775403976440e-01
    z[6,7,6]  R2186     -1.0742650181055069e-01
    z[6,7,6]  R2187     1.7828810214996338e-01
    z[6,7,6]  R2188     0.0646311566233635
    z[6,7,6]  R2189     3.5905060172080994e-01
    z[6,7,6]  R2190     4.7409194707870483e-01
    z[6,7,6]  R2191     1.2854970991611481e-01
    z[6,7,6]  R2192     2.5638380646705627e-01
    z[6,7,6]  R2193     -2.7579295635223389e-01
    z[6,7,6]  R2194     0.208499014377594
    z[6,7,6]  R2195     1.0201370343565941e-02
    z[6,7,6]  R2196     -5.7699644565582275e-01
    z[6,7,6]  R2197     7.2591170668601990e-02
    z[6,7,6]  R2198     -3.4751501679420471e-01
    z[6,7,6]  R2199     2.9964936897158623e-02
    z[6,7,6]  R2200     -2.6002980768680573e-02
    z[6,7,6]  R2201     2.0751388370990753e-01
    z[6,7,6]  R2202     4.5229196548461914e-02
    z[6,7,6]  R2203     -1.0698702931404114e-01
    z[6,7,6]  R2204     1.8542423844337463e-01
    z[6,7,6]  R2205     -5.1717776805162430e-02
    z[6,7,6]  R2206     1.8342463672161102e-01
    z[6,7,6]  R2207     2.7305299416184425e-02
    z[6,7,6]  R2208     -1.7285240814089775e-02
    z[6,7,6]  R2209     1.6663244366645813e-01
    z[6,7,6]  R2210     2.4774271249771118e-01
    z[6,7,6]  R2211     -3.1851489096879959e-02
    z[6,7,6]  R2212     -5.6645363569259644e-02
    z[6,7,6]  R2213     3.2567736506462097e-01
    z[6,7,6]  R2214     -8.8693656027317047e-02
    z[6,7,6]  R2215     -4.5062169432640076e-02
    z[6,7,6]  R2216     3.2510063052177429e-01
    z[6,7,6]  R2217     4.4114418327808380e-02
    z[6,7,6]  R2218     4.1693365573883057e-01
    z[6,7,6]  R2219     -2.2450645267963409e-01
    z[6,7,6]  R2220     1.2004944682121277e-01
    z[6,7,6]  R2221     -3.6084678769111633e-01
    z[6,7,6]  R2222     -1.3161915540695190e-01
    z[6,7,6]  R2223     2.1471166610717773e-01
    z[7,6,0]  R56       1
    z[7,6,0]  R65       -1
    z[7,6,0]  R2224     -1
    z[7,6,0]  R2225     1
    z[7,6,0]  R2238     -1.8409195542335510e-01
    z[7,6,0]  R2239     -0.286214679479599
    z[7,6,0]  R2240     -1.7760060727596283e-01
    z[7,6,0]  R2241     6.9870322942733765e-02
    z[7,6,0]  R2242     -4.9463465809822083e-02
    z[7,6,0]  R2243     -1.1441210657358170e-01
    z[7,6,0]  R2244     -2.2823843359947205e-01
    z[7,6,0]  R2245     2.3409046232700348e-01
    z[7,6,0]  R2246     1.5582002699375153e-01
    z[7,6,0]  R2247     3.5205134749412537e-01
    z[7,6,0]  R2248     -8.0105133354663849e-02
    z[7,6,0]  R2249     -2.0721285045146942e-01
    z[7,6,0]  R2250     2.8006890416145325e-01
    z[7,6,0]  R2251     -2.6431012153625488e-01
    z[7,6,0]  R2252     -1.7840294539928436e-01
    z[7,6,0]  R2253     3.0782647430896759e-02
    z[7,6,0]  R2254     -0.241979718208313
    z[7,6,0]  R2255     -0.274396151304245
    z[7,6,0]  R2256     2.2456000745296478e-01
    z[7,6,0]  R2257     2.8472054004669189e-01
    z[7,6,0]  R2258     1.5407499670982361e-01
    z[7,6,0]  R2259     -4.5860470272600651e-03
    z[7,6,0]  R2260     -4.5927211642265320e-02
    z[7,6,0]  R2261     1.8447707593441010e-01
    z[7,6,0]  R2262     1.8028499186038971e-01
    z[7,6,0]  R2263     -0.0827464833855629
    z[7,6,0]  R2264     8.5019731521606445e-01
    z[7,6,0]  R2265     7.8297829627990723e-01
    z[7,6,0]  R2266     6.7507582902908325e-01
    z[7,6,0]  R2267     6.6264832019805908e-01
    z[7,6,0]  R2268     -3.6828601360321045e-01
    z[7,6,0]  R2269     4.8666980117559433e-02
    z[7,6,0]  R2270     2.9973436146974564e-02
    z[7,6,0]  R2271     -1.4538391493260860e-02
    z[7,6,0]  R2272     -3.9435279369354248e-01
    z[7,6,0]  R2273     -1.8094129860401154e-01
    z[7,6,0]  R2274     6.6815757751464844e-01
    z[7,6,0]  R2275     9.5584966242313385e-02
    z[7,6,0]  R2276     -4.8523190617561340e-01
    z[7,6,0]  R2277     4.4093447923660278e-01
    z[7,6,0]  R2278     5.4805117845535278e-01
    z[7,6,0]  R2279     4.2255589365959167e-01
    z[7,6,0]  R2280     2.7814289927482605e-01
    z[7,6,0]  R2281     8.4848684072494507e-01
    z[7,6,0]  R2282     0.589670717716217
    z[7,6,0]  R2283     7.0288866758346558e-01
    z[7,6,0]  R2284     5.5329144001007080e-01
    z[7,6,0]  R2285     -3.2655516266822815e-01
    z[7,6,0]  R2286     -5.2858823537826538e-01
    z[7,6,0]  R2287     -8.0339974164962769e-01
    z[7,6,0]  R2288     -6.9192576408386230e-01
    z[7,6,0]  R2289     -8.2773417234420776e-01
    z[7,6,0]  R2290     -6.3882762193679810e-01
    z[7,6,0]  R2291     -6.0439628362655640e-01
    z[7,6,0]  R2292     -7.2977793216705322e-01
    z[7,6,0]  R2293     -0.559395968914032
    z[7,6,0]  R2294     -5.0156968832015991e-01
    z[7,6,0]  R2295     3.1622976064682007e-01
    z[7,6,0]  R2296     0.315693736076355
    z[7,6,0]  R2297     -2.8708526492118835e-01
    z[7,6,0]  R2298     -7.2947657108306885e-01
    z[7,6,0]  R2299     -0.335328608751297
    z[7,6,0]  R2300     -4.7691029310226440e-01
    z[7,6,0]  R2301     -2.0829641819000244e-01
    z[7,6,0]  R2302     -3.3500516414642334e-01
    z[7,6,0]  R2303     -3.4237566590309143e-01
    z[7,6,0]  R2304     -4.5555812120437622e-01
    z[7,6,0]  R2305     -3.1280595064163208e-01
    z[7,6,0]  R2306     -4.9793234467506409e-01
    z[7,6,1]  R57       1
    z[7,6,1]  R66       -1
    z[7,6,1]  R2226     -1
    z[7,6,1]  R2227     1
    z[7,6,1]  R2238     -1.5911084413528442e-01
    z[7,6,1]  R2239     5.5689144134521484e-01
    z[7,6,1]  R2240     0.486074298620224
    z[7,6,1]  R2241     6.2916010618209839e-01
    z[7,6,1]  R2242     7.9231232404708862e-01
    z[7,6,1]  R2243     -1.3732153177261353e-01
    z[7,6,1]  R2244     -3.6912813782691956e-01
    z[7,6,1]  R2245     -1.3534417748451233e-01
    z[7,6,1]  R2246     -7.3680929839611053e-02
    z[7,6,1]  R2247     -0.0723814144730568
    z[7,6,1]  R2248     -7.2034609317779541e-01
    z[7,6,1]  R2249     -0.61319500207901
    z[7,6,1]  R2250     -9.4503128528594971e-01
    z[7,6,1]  R2251     -7.6930946111679077e-01
    z[7,6,1]  R2252     2.6116809248924255e-01
    z[7,6,1]  R2253     3.6502429842948914e-01
    z[7,6,1]  R2254     -1.9301742315292358e-01
    z[7,6,1]  R2255     -3.6066219210624695e-02
    z[7,6,1]  R2256     0.0985545814037323
    z[7,6,1]  R2257     9.0866394340991974e-02
    z[7,6,1]  R2258     -8.9232005178928375e-02
    z[7,6,1]  R2259     1.0712014138698578e-01
    z[7,6,1]  R2260     -2.0952789485454559e-01
    z[7,6,1]  R2261     1.0200225561857224e-01
    z[7,6,1]  R2262     -2.9675036668777466e-01
    z[7,6,1]  R2263     -3.8716565817594528e-02
    z[7,6,1]  R2264     2.2629378736019135e-01
    z[7,6,1]  R2265     1.1142539232969284e-01
    z[7,6,1]  R2266     -4.9738310277462006e-02
    z[7,6,1]  R2267     1.3619263470172882e-01
    z[7,6,1]  R2268     -2.9825264215469360e-01
    z[7,6,1]  R2269     0.158810555934906
    z[7,6,1]  R2270     6.5514102578163147e-02
    z[7,6,1]  R2271     2.4066442251205444e-01
    z[7,6,1]  R2272     8.1417721509933472e-01
    z[7,6,1]  R2273     7.5963789224624634e-01
    z[7,6,1]  R2274     9.3840479850769043e-02
    z[7,6,1]  R2275     7.4448043107986450e-01
    z[7,6,1]  R2276     5.1961439847946167e-01
    z[7,6,1]  R2277     -4.4560983777046204e-01
    z[7,6,1]  R2278     -2.3848210275173187e-01
    z[7,6,1]  R2279     -2.3731166124343872e-01
    z[7,6,1]  R2280     -3.2478284835815430e-01
    z[7,6,1]  R2281     -1.8467797338962555e-01
    z[7,6,1]  R2282     -2.2657305002212524e-01
    z[7,6,1]  R2283     5.1507562398910522e-02
    z[7,6,1]  R2284     -2.2879233956336975e-01
    z[7,6,1]  R2285     -4.6031586825847626e-02
    z[7,6,1]  R2286     -1.5255342423915863e-01
    z[7,6,1]  R2287     0.450044721364975
    z[7,6,1]  R2288     5.4803127050399780e-01
    z[7,6,1]  R2289     4.2429828643798828e-01
    z[7,6,1]  R2290     6.0195136070251465e-01
    z[7,6,1]  R2291     5.9679871797561646e-01
    z[7,6,1]  R2292     4.4608011841773987e-01
    z[7,6,1]  R2293     5.3579425811767578e-01
    z[7,6,1]  R2294     -5.9169030189514160e-01
    z[7,6,1]  R2295     5.9061861038208008e-01
    z[7,6,1]  R2296     5.8953213691711426e-01
    z[7,6,1]  R2297     -7.0820778608322144e-01
    z[7,6,1]  R2298     5.7110726833343506e-01
    z[7,6,1]  R2299     -7.0824992656707764e-01
    z[7,6,1]  R2300     -6.5907132625579834e-01
    z[7,6,1]  R2301     7.7580267190933228e-01
    z[7,6,1]  R2302     6.1687922477722168e-01
    z[7,6,1]  R2303     0.546272873878479
    z[7,6,1]  R2304     3.2558700442314148e-01
    z[7,6,1]  R2305     -9.1125704348087311e-02
    z[7,6,1]  R2306     -4.3750718235969543e-01
    z[7,6,2]  R58       1
    z[7,6,2]  R67       -1
    z[7,6,2]  R2228     -1
    z[7,6,2]  R2229     1
    z[7,6,2]  R2238     4.7734364867210388e-01
    z[7,6,2]  R2239     -6.9811606407165527e-01
    z[7,6,2]  R2240     -0.759968638420105
    z[7,6,2]  R2241     -5.7033151388168335e-01
    z[7,6,2]  R2242     -3.0093312263488770e-01
    z[7,6,2]  R2243     0.409659206867218
    z[7,6,2]  R2244     0.425683856010437
    z[7,6,2]  R2245     0.727834939956665
    z[7,6,2]  R2246     3.4167951345443726e-01
    z[7,6,2]  R2247     3.2505834102630615e-01
    z[7,6,2]  R2248     4.1031163930892944e-01
    z[7,6,2]  R2249     4.7157713770866394e-01
    z[7,6,2]  R2250     -6.8214975297451019e-02
    z[7,6,2]  R2251     -1.5069937705993652e-01
    z[7,6,2]  R2252     0.854481041431427
    z[7,6,2]  R2253     1.1533088982105255e-01
    z[7,6,2]  R2254     -8.7620846927165985e-02
    z[7,6,2]  R2255     -6.3486829400062561e-02
    z[7,6,2]  R2256     1.2221843935549259e-02
    z[7,6,2]  R2257     2.0777745544910431e-01
    z[7,6,2]  R2258     0.566098690032959
    z[7,6,2]  R2259     8.9974778890609741e-01
    z[7,6,2]  R2260     3.7261152267456055e-01
    z[7,6,2]  R2261     7.3742020130157471e-01
    z[7,6,2]  R2262     5.4701465368270874e-01
    z[7,6,2]  R2263     3.7120354175567627e-01
    z[7,6,2]  R2264     1.7128667235374451e-01
    z[7,6,2]  R2265     8.9861951768398285e-02
    z[7,6,2]  R2266     4.6292895078659058e-01
    z[7,6,2]  R2267     -1.5902958810329437e-01
    z[7,6,2]  R2268     5.0795876979827881e-01
    z[7,6,2]  R2269     -8.3484035730361938e-01
    z[7,6,2]  R2270     7.7183127403259277e-01
    z[7,6,2]  R2271     -2.4677228927612305e-01
    z[7,6,2]  R2272     3.4455919265747070e-01
    z[7,6,2]  R2273     1.7628923058509827e-01
    z[7,6,2]  R2274     -2.6017928123474121e-01
    z[7,6,2]  R2275     1.0638079047203064e-01
    z[7,6,2]  R2276     1.4143446087837219e-01
    z[7,6,2]  R2277     3.1769603490829468e-01
    z[7,6,2]  R2278     3.5631069540977478e-01
    z[7,6,2]  R2279     -3.4127756953239441e-01
    z[7,6,2]  R2280     -1.3834577798843384e-01
    z[7,6,2]  R2281     2.5545054674148560e-01
    z[7,6,2]  R2282     5.3873889148235321e-02
    z[7,6,2]  R2283     3.5022327303886414e-01
    z[7,6,2]  R2284     -7.5893305242061615e-02
    z[7,6,2]  R2285     2.6665067672729492e-01
    z[7,6,2]  R2286     2.3423585295677185e-01
    z[7,6,2]  R2287     -2.8111422061920166e-01
    z[7,6,2]  R2288     -0.0395394004881382
    z[7,6,2]  R2289     5.5197715759277344e-02
    z[7,6,2]  R2290     -2.1367651224136353e-01
    z[7,6,2]  R2291     1.0339756309986115e-01
    z[7,6,2]  R2292     -4.5027423650026321e-02
    z[7,6,2]  R2293     4.0264445543289185e-01
    z[7,6,2]  R2294     -3.8716900348663330e-01
    z[7,6,2]  R2295     -4.8465827107429504e-01
    z[7,6,2]  R2296     -5.4945284128189087e-01
    z[7,6,2]  R2297     4.0996581315994263e-01
    z[7,6,2]  R2298     -1.1819826811552048e-01
    z[7,6,2]  R2299     2.2840917110443115e-01
    z[7,6,2]  R2300     4.3458785861730576e-02
    z[7,6,2]  R2301     1.2112908810377121e-01
    z[7,6,2]  R2302     0.15046426653862
    z[7,6,2]  R2303     0.585498571395874
    z[7,6,2]  R2304     1.1618865281343460e-01
    z[7,6,2]  R2305     -1.2154792249202728e-01
    z[7,6,2]  R2306     -6.2610512971878052e-01
    z[7,6,3]  R59       1
    z[7,6,3]  R68       -1
    z[7,6,3]  R2230     -1
    z[7,6,3]  R2231     1
    z[7,6,3]  R2238     -3.1089496612548828e-01
    z[7,6,3]  R2239     -4.5976629480719566e-03
    z[7,6,3]  R2240     -1.9953125715255737e-01
    z[7,6,3]  R2241     1.4465105533599854e-01
    z[7,6,3]  R2242     -1.1274618655443192e-01
    z[7,6,3]  R2243     -5.4057633876800537e-01
    z[7,6,3]  R2244     -6.1465138196945190e-01
    z[7,6,3]  R2245     -7.2582453489303589e-02
    z[7,6,3]  R2246     2.4491086602210999e-01
    z[7,6,3]  R2247     7.6523773372173309e-02
    z[7,6,3]  R2248     -2.3758205771446228e-01
    z[7,6,3]  R2249     5.9345021843910217e-02
    z[7,6,3]  R2250     -1.0046973824501038e-01
    z[7,6,3]  R2251     -2.6489657163619995e-01
    z[7,6,3]  R2252     -1.1019768565893173e-01
    z[7,6,3]  R2253     7.7369767427444458e-01
    z[7,6,3]  R2254     6.9227272272109985e-01
    z[7,6,3]  R2255     5.7540297508239746e-01
    z[7,6,3]  R2256     5.9350687265396118e-01
    z[7,6,3]  R2257     0.672277569770813
    z[7,6,3]  R2258     1.3080467283725739e-01
    z[7,6,3]  R2259     -1.2148908525705338e-01
    z[7,6,3]  R2260     -2.7065485715866089e-01
    z[7,6,3]  R2261     1.1624167859554291e-01
    z[7,6,3]  R2262     -1.5676201879978180e-01
    z[7,6,3]  R2263     -3.5875433683395386e-01
    z[7,6,3]  R2264     -4.3203625082969666e-01
    z[7,6,3]  R2265     -5.5732291936874390e-01
    z[7,6,3]  R2266     4.2104315757751465e-01
    z[7,6,3]  R2267     -6.8754607439041138e-01
    z[7,6,3]  R2268     -5.0349420309066772e-01
    z[7,6,3]  R2269     -1.9803847372531891e-01
    z[7,6,3]  R2270     -1.1736599728465080e-02
    z[7,6,3]  R2271     -2.4125337600708008e-01
    z[7,6,3]  R2272     6.0481783002614975e-02
    z[7,6,3]  R2273     8.9068122208118439e-02
    z[7,6,3]  R2274     -2.5103783607482910e-01
    z[7,6,3]  R2275     0.502587616443634
    z[7,6,3]  R2276     -3.6166378855705261e-01
    z[7,6,3]  R2277     -4.3482255935668945e-01
    z[7,6,3]  R2278     -6.6880708932876587e-01
    z[7,6,3]  R2279     -6.3091719150543213e-01
    z[7,6,3]  R2280     -8.8773626089096069e-01
    z[7,6,3]  R2281     3.5299104452133179e-01
    z[7,6,3]  R2282     -2.0625099539756775e-01
    z[7,6,3]  R2283     -5.3459867835044861e-02
    z[7,6,3]  R2284     -1.4415368437767029e-01
    z[7,6,3]  R2285     1.8515148758888245e-01
    z[7,6,3]  R2286     -4.0621495246887207e-01
    z[7,6,3]  R2287     5.9914374724030495e-03
    z[7,6,3]  R2288     -1.2339998036623001e-01
    z[7,6,3]  R2289     -9.4395920634269714e-02
    z[7,6,3]  R2290     3.3934372663497925e-01
    z[7,6,3]  R2291     3.5664927959442139e-01
    z[7,6,3]  R2292     2.5923115015029907e-01
    z[7,6,3]  R2293     2.4068602919578552e-01
    z[7,6,3]  R2294     3.6081379652023315e-01
    z[7,6,3]  R2295     3.6737982183694839e-02
    z[7,6,3]  R2296     4.8667289316654205e-02
    z[7,6,3]  R2297     3.9427277445793152e-01
    z[7,6,3]  R2298     -3.2009461522102356e-01
    z[7,6,3]  R2299     4.8703688383102417e-01
    z[7,6,3]  R2300     1.5347819030284882e-01
    z[7,6,3]  R2301     -1.8350031971931458e-01
    z[7,6,3]  R2302     -4.3879628181457520e-02
    z[7,6,3]  R2303     -3.5146945714950562e-01
    z[7,6,3]  R2304     1.9466623663902283e-01
    z[7,6,3]  R2305     8.0216413736343384e-01
    z[7,6,3]  R2306     2.5773268938064575e-01
    z[7,6,4]  R60       1
    z[7,6,4]  R69       -1
    z[7,6,4]  R2232     -1
    z[7,6,4]  R2233     1
    z[7,6,4]  R2238     -4.2951282858848572e-01
    z[7,6,4]  R2239     -3.1544342637062073e-01
    z[7,6,4]  R2240     -2.0930638536810875e-02
    z[7,6,4]  R2241     -2.9720824956893921e-01
    z[7,6,4]  R2242     -2.6059493422508240e-01
    z[7,6,4]  R2243     -5.3116768598556519e-01
    z[7,6,4]  R2244     4.5812425017356873e-01
    z[7,6,4]  R2245     -5.1798480749130249e-01
    z[7,6,4]  R2246     8.3333963155746460e-01
    z[7,6,4]  R2247     6.1238336563110352e-01
    z[7,6,4]  R2248     2.2035986185073853e-01
    z[7,6,4]  R2249     1.0738736391067505e-01
    z[7,6,4]  R2250     0.0919412299990654
    z[7,6,4]  R2251     -3.5267257690429688e-01
    z[7,6,4]  R2252     3.7516683340072632e-01
    z[7,6,4]  R2253     1.6356931626796722e-01
    z[7,6,4]  R2254     3.1342211365699768e-01
    z[7,6,4]  R2255     1.6645228862762451e-01
    z[7,6,4]  R2256     3.8846645504236221e-02
    z[7,6,4]  R2257     -5.2337568253278732e-02
    z[7,6,4]  R2258     7.2469997406005859e-01
    z[7,6,4]  R2259     3.1810739636421204e-01
    z[7,6,4]  R2260     2.3945939540863037e-01
    z[7,6,4]  R2261     -7.5018614530563354e-02
    z[7,6,4]  R2262     2.9431456327438354e-01
    z[7,6,4]  R2263     5.8305406570434570e-01
    z[7,6,4]  R2264     8.7009154260158539e-02
    z[7,6,4]  R2265     -1.7532825469970703e-02
    z[7,6,4]  R2266     -5.7780440896749496e-02
    z[7,6,4]  R2267     1.6788609325885773e-01
    z[7,6,4]  R2268     -2.7590867877006531e-01
    z[7,6,4]  R2269     -3.0516344308853149e-01
    z[7,6,4]  R2270     5.5181443691253662e-01
    z[7,6,4]  R2271     -0.774170458316803
    z[7,6,4]  R2272     7.4755914509296417e-02
    z[7,6,4]  R2273     3.0793941020965576e-01
    z[7,6,4]  R2274     -4.9027469754219055e-01
    z[7,6,4]  R2275     2.8126803040504456e-01
    z[7,6,4]  R2276     2.7190479636192322e-01
    z[7,6,4]  R2277     2.7873623371124268e-01
    z[7,6,4]  R2278     -2.4634149670600891e-01
    z[7,6,4]  R2279     3.8980942964553833e-01
    z[7,6,4]  R2280     -2.7859557420015335e-02
    z[7,6,4]  R2281     1.5316751599311829e-01
    z[7,6,4]  R2282     2.8971980791538954e-03
    z[7,6,4]  R2283     -1.4241434633731842e-01
    z[7,6,4]  R2284     -6.5232515335083008e-01
    z[7,6,4]  R2285     6.6785824298858643e-01
    z[7,6,4]  R2286     6.4231920242309570e-01
    z[7,6,4]  R2287     -2.2686882317066193e-01
    z[7,6,4]  R2288     -4.1900625824928284e-01
    z[7,6,4]  R2289     -3.0104938149452209e-01
    z[7,6,4]  R2290     -8.7487086653709412e-02
    z[7,6,4]  R2291     5.2652070298790932e-03
    z[7,6,4]  R2292     -6.4254850149154663e-02
    z[7,6,4]  R2293     -3.3562248945236206e-01
    z[7,6,4]  R2294     -2.0347152650356293e-01
    z[7,6,4]  R2295     -7.7061526477336884e-02
    z[7,6,4]  R2296     -1.4298850297927856e-01
    z[7,6,4]  R2297     -1.4109261333942413e-01
    z[7,6,4]  R2298     5.5168453603982925e-02
    z[7,6,4]  R2299     -1.1341971345245838e-02
    z[7,6,4]  R2300     -3.9437130093574524e-01
    z[7,6,4]  R2301     5.0103694200515747e-01
    z[7,6,4]  R2302     5.6099700927734375e-01
    z[7,6,4]  R2303     8.3675779402256012e-02
    z[7,6,4]  R2304     7.0127105712890625e-01
    z[7,6,4]  R2305     -4.7330036759376526e-01
    z[7,6,4]  R2306     1.8838801980018616e-01
    z[7,6,5]  R61       1
    z[7,6,5]  R70       -1
    z[7,6,5]  R2234     -1
    z[7,6,5]  R2235     1
    z[7,6,5]  R2238     2.1249738335609436e-01
    z[7,6,5]  R2239     9.7575500607490540e-02
    z[7,6,5]  R2240     -2.8740197420120239e-01
    z[7,6,5]  R2241     -4.0070423483848572e-01
    z[7,6,5]  R2242     -2.6399818062782288e-01
    z[7,6,5]  R2243     -3.3271342515945435e-02
    z[7,6,5]  R2244     -1.6200518608093262e-01
    z[7,6,5]  R2245     -2.4048025906085968e-01
    z[7,6,5]  R2246     1.5181684494018555e-01
    z[7,6,5]  R2247     -5.8379513025283813e-01
    z[7,6,5]  R2248     0.448576956987381
    z[7,6,5]  R2249     1.0339719057083130e-01
    z[7,6,5]  R2250     2.7096045669168234e-03
    z[7,6,5]  R2251     -1.6674175858497620e-02
    z[7,6,5]  R2252     -1.2662614881992340e-01
    z[7,6,5]  R2253     4.7588792443275452e-01
    z[7,6,5]  R2254     5.2533394098281860e-01
    z[7,6,5]  R2255     7.4735182523727417e-01
    z[7,6,5]  R2256     0.757960855960846
    z[7,6,5]  R2257     6.1516475677490234e-01
    z[7,6,5]  R2258     -3.2071188092231750e-01
    z[7,6,5]  R2259     -1.7135214805603027e-01
    z[7,6,5]  R2260     -8.2692736387252808e-01
    z[7,6,5]  R2261     -6.2636774778366089e-01
    z[7,6,5]  R2262     -6.6426640748977661e-01
    z[7,6,5]  R2263     -5.6905966997146606e-01
    z[7,6,5]  R2264     3.7096012383699417e-02
    z[7,6,5]  R2265     -2.2875617444515228e-01
    z[7,6,5]  R2266     2.0202431082725525e-01
    z[7,6,5]  R2267     9.1030269861221313e-02
    z[7,6,5]  R2268     -4.3095922470092773e-01
    z[7,6,5]  R2269     -1.9343747198581696e-01
    z[7,6,5]  R2270     -3.0414286255836487e-01
    z[7,6,5]  R2271     2.2270156443119049e-01
    z[7,6,5]  R2272     -5.6840542703866959e-02
    z[7,6,5]  R2273     4.9189507961273193e-01
    z[7,6,5]  R2274     2.0848602056503296e-01
    z[7,6,5]  R2275     2.7616280317306519e-01
    z[7,6,5]  R2276     0.472983181476593
    z[7,6,5]  R2277     -7.4104122817516327e-02
    z[7,6,5]  R2278     -8.7971940636634827e-02
    z[7,6,5]  R2279     1.7152974009513855e-01
    z[7,6,5]  R2280     9.0885631740093231e-02
    z[7,6,5]  R2281     4.3337102979421616e-03
    z[7,6,5]  R2282     -3.8824877142906189e-01
    z[7,6,5]  R2283     -2.2742530703544617e-01
    z[7,6,5]  R2284     2.0665295422077179e-01
    z[7,6,5]  R2285     -5.5211347341537476e-01
    z[7,6,5]  R2286     -2.3046933114528656e-01
    z[7,6,5]  R2287     4.7852255403995514e-02
    z[7,6,5]  R2288     2.6644130703061819e-03
    z[7,6,5]  R2289     -1.5615621209144592e-01
    z[7,6,5]  R2290     1.6076974570751190e-01
    z[7,6,5]  R2291     2.3430469632148743e-01
    z[7,6,5]  R2292     2.4470695853233337e-01
    z[7,6,5]  R2293     -0.0658566951751709
    z[7,6,5]  R2294     3.4708563238382339e-02
    z[7,6,5]  R2295     -3.5051450133323669e-01
    z[7,6,5]  R2296     -2.0083734393119812e-01
    z[7,6,5]  R2297     2.6920095086097717e-01
    z[7,6,5]  R2298     1.4070644974708557e-01
    z[7,6,5]  R2299     -1.1504362523555756e-01
    z[7,6,5]  R2300     -3.6810681223869324e-01
    z[7,6,5]  R2301     0.126405268907547
    z[7,6,5]  R2302     -2.9695412516593933e-01
    z[7,6,5]  R2303     -2.9155787825584412e-01
    z[7,6,5]  R2304     -3.6707469820976257e-01
    z[7,6,5]  R2305     -1.0693305730819702e-01
    z[7,6,5]  R2306     -2.5623857975006104e-01
    z[7,6,6]  R62       1
    z[7,6,6]  R71       -1
    z[7,6,6]  R2236     -1
    z[7,6,6]  R2237     1
    z[7,6,6]  R2238     6.2180775403976440e-01
    z[7,6,6]  R2239     -1.0742650181055069e-01
    z[7,6,6]  R2240     1.7828810214996338e-01
    z[7,6,6]  R2241     0.0646311566233635
    z[7,6,6]  R2242     3.5905060172080994e-01
    z[7,6,6]  R2243     4.7409194707870483e-01
    z[7,6,6]  R2244     1.2854970991611481e-01
    z[7,6,6]  R2245     2.5638380646705627e-01
    z[7,6,6]  R2246     -2.7579295635223389e-01
    z[7,6,6]  R2247     0.208499014377594
    z[7,6,6]  R2248     1.0201370343565941e-02
    z[7,6,6]  R2249     -5.7699644565582275e-01
    z[7,6,6]  R2250     7.2591170668601990e-02
    z[7,6,6]  R2251     -3.4751501679420471e-01
    z[7,6,6]  R2252     2.9964936897158623e-02
    z[7,6,6]  R2253     -2.6002980768680573e-02
    z[7,6,6]  R2254     2.0751388370990753e-01
    z[7,6,6]  R2255     4.5229196548461914e-02
    z[7,6,6]  R2256     -1.0698702931404114e-01
    z[7,6,6]  R2257     1.8542423844337463e-01
    z[7,6,6]  R2258     -5.1717776805162430e-02
    z[7,6,6]  R2259     1.8342463672161102e-01
    z[7,6,6]  R2260     2.7305299416184425e-02
    z[7,6,6]  R2261     -1.7285240814089775e-02
    z[7,6,6]  R2262     1.6663244366645813e-01
    z[7,6,6]  R2263     2.4774271249771118e-01
    z[7,6,6]  R2264     -3.1851489096879959e-02
    z[7,6,6]  R2265     -5.6645363569259644e-02
    z[7,6,6]  R2266     3.2567736506462097e-01
    z[7,6,6]  R2267     -8.8693656027317047e-02
    z[7,6,6]  R2268     -4.5062169432640076e-02
    z[7,6,6]  R2269     3.2510063052177429e-01
    z[7,6,6]  R2270     4.4114418327808380e-02
    z[7,6,6]  R2271     4.1693365573883057e-01
    z[7,6,6]  R2272     -2.2450645267963409e-01
    z[7,6,6]  R2273     1.2004944682121277e-01
    z[7,6,6]  R2274     -3.6084678769111633e-01
    z[7,6,6]  R2275     -1.3161915540695190e-01
    z[7,6,6]  R2276     2.1471166610717773e-01
    z[7,6,6]  R2277     4.8355132341384888e-01
    z[7,6,6]  R2278     -9.0920282527804375e-03
    z[7,6,6]  R2279     -2.6311388611793518e-01
    z[7,6,6]  R2280     -3.0015598982572556e-02
    z[7,6,6]  R2281     -1.8063063919544220e-01
    z[7,6,6]  R2282     -6.3621199131011963e-01
    z[7,6,6]  R2283     -5.5297023057937622e-01
    z[7,6,6]  R2284     -0.383078396320343
    z[7,6,6]  R2285     -1.8707031011581421e-01
    z[7,6,6]  R2286     -1.0841947793960571e-01
    z[7,6,6]  R2287     -1.3852114975452423e-01
    z[7,6,6]  R2288     -1.6892676055431366e-01
    z[7,6,6]  R2289     8.8624767959117889e-02
    z[7,6,6]  R2290     -1.8772609531879425e-01
    z[7,6,6]  R2291     2.9278010129928589e-01
    z[7,6,6]  R2292     3.6769318580627441e-01
    z[7,6,6]  R2293     2.5093591213226318e-01
    z[7,6,6]  R2294     -2.7502483129501343e-01
    z[7,6,6]  R2295     4.3142339587211609e-01
    z[7,6,6]  R2296     4.3329083919525146e-01
    z[7,6,6]  R2297     1.1154074221849442e-02
    z[7,6,6]  R2298     4.9266304820775986e-02
    z[7,6,6]  R2299     -2.8843957185745239e-01
    z[7,6,6]  R2300     -1.4732936024665833e-01
    z[7,6,6]  R2301     -1.9844852387905121e-01
    z[7,6,6]  R2302     -2.8243076801300049e-01
    z[7,6,6]  R2303     1.6130003333091736e-01
    z[7,6,6]  R2304     9.2413134872913361e-02
    z[7,6,6]  R2305     -1.2626359239220619e-02
    z[7,6,6]  R2306     -3.2690886408090591e-02
    z[7,8,0]  R65       -1
    z[7,8,0]  R74       1
    z[7,8,0]  R2307     -1
    z[7,8,0]  R2308     1
    z[7,8,0]  R2321     -1.8409195542335510e-01
    z[7,8,0]  R2322     -0.286214679479599
    z[7,8,0]  R2323     -1.7760060727596283e-01
    z[7,8,0]  R2324     6.9870322942733765e-02
    z[7,8,0]  R2325     -4.9463465809822083e-02
    z[7,8,0]  R2326     -1.1441210657358170e-01
    z[7,8,0]  R2327     -2.2823843359947205e-01
    z[7,8,0]  R2328     2.3409046232700348e-01
    z[7,8,0]  R2329     1.5582002699375153e-01
    z[7,8,0]  R2330     3.5205134749412537e-01
    z[7,8,0]  R2331     -8.0105133354663849e-02
    z[7,8,0]  R2332     -2.0721285045146942e-01
    z[7,8,0]  R2333     2.8006890416145325e-01
    z[7,8,0]  R2334     -2.6431012153625488e-01
    z[7,8,0]  R2335     -1.7840294539928436e-01
    z[7,8,0]  R2336     3.0782647430896759e-02
    z[7,8,0]  R2337     -0.241979718208313
    z[7,8,0]  R2338     -0.274396151304245
    z[7,8,0]  R2339     2.2456000745296478e-01
    z[7,8,0]  R2340     2.8472054004669189e-01
    z[7,8,0]  R2341     1.5407499670982361e-01
    z[7,8,0]  R2342     -4.5860470272600651e-03
    z[7,8,0]  R2343     -4.5927211642265320e-02
    z[7,8,0]  R2344     1.8447707593441010e-01
    z[7,8,0]  R2345     1.8028499186038971e-01
    z[7,8,0]  R2346     -0.0827464833855629
    z[7,8,0]  R2347     8.5019731521606445e-01
    z[7,8,0]  R2348     7.8297829627990723e-01
    z[7,8,0]  R2349     6.7507582902908325e-01
    z[7,8,0]  R2350     6.6264832019805908e-01
    z[7,8,0]  R2351     -3.6828601360321045e-01
    z[7,8,0]  R2352     4.8666980117559433e-02
    z[7,8,0]  R2353     2.9973436146974564e-02
    z[7,8,0]  R2354     -1.4538391493260860e-02
    z[7,8,0]  R2355     -3.9435279369354248e-01
    z[7,8,0]  R2356     -1.8094129860401154e-01
    z[7,8,0]  R2357     6.6815757751464844e-01
    z[7,8,0]  R2358     9.5584966242313385e-02
    z[7,8,0]  R2359     -4.8523190617561340e-01
    z[7,8,0]  R2360     7.5502716004848480e-02
    z[7,8,0]  R2361     1.1088728159666061e-01
    z[7,8,0]  R2362     4.6042829751968384e-01
    z[7,8,0]  R2363     -4.7907486557960510e-02
    z[7,8,0]  R2364     -3.7452426552772522e-01
    z[7,8,0]  R2365     3.7386223673820496e-01
    z[7,8,0]  R2366     7.8686732053756714e-01
    z[7,8,0]  R2367     6.3473963737487793e-01
    z[7,8,0]  R2368     6.6608524322509766e-01
    z[7,8,0]  R2369     2.2632005810737610e-01
    z[7,8,0]  R2370     -1.8951016664505005e-01
    z[7,8,0]  R2371     1.8030634522438049e-01
    z[7,8,0]  R2372     -1.7487324774265289e-01
    z[7,8,0]  R2373     3.4759301692247391e-02
    z[7,8,0]  R2374     -1.9547063112258911e-01
    z[7,8,0]  R2375     1.5211117267608643e-01
    z[7,8,0]  R2376     8.7116084992885590e-02
    z[7,8,0]  R2377     -9.8972775042057037e-02
    z[7,8,0]  R2378     1.0068482719361782e-02
    z[7,8,0]  R2379     -8.6382992565631866e-02
    z[7,8,0]  R2380     -2.9037365317344666e-01
    z[7,8,0]  R2381     1.0343021899461746e-01
    z[7,8,0]  R2382     1.0587554425001144e-01
    z[7,8,0]  R2383     -7.3766030371189117e-02
    z[7,8,0]  R2384     2.1661940217018127e-01
    z[7,8,0]  R2385     2.9797169566154480e-01
    z[7,8,0]  R2386     1.5126696228981018e-01
    z[7,8,0]  R2387     2.0977418124675751e-01
    z[7,8,0]  R2388     -1.0889665782451630e-01
    z[7,8,0]  R2389     4.3689113855361938e-01
    z[7,8,0]  R2390     9.4676986336708069e-02
    z[7,8,0]  R2391     5.3207892179489136e-01
    z[7,8,0]  R2392     9.9957488477230072e-02
    z[7,8,0]  R2393     2.4007444083690643e-01
    z[7,8,0]  R2394     -1.1455266922712326e-01
    z[7,8,0]  R2395     1.6327553987503052e-01
    z[7,8,0]  R2396     -3.9882576093077660e-03
    z[7,8,0]  R2397     2.0957697927951813e-01
    z[7,8,0]  R2398     2.9569080471992493e-01
    z[7,8,0]  R2399     -8.5495337843894958e-03
    z[7,8,0]  R2400     -2.0459544658660889e-01
    z[7,8,0]  R2401     3.1395334005355835e-01
    z[7,8,0]  R2402     2.4114730954170227e-01
    z[7,8,0]  R2403     3.2360625267028809e-01
    z[7,8,0]  R2404     6.8792569637298584e-01
    z[7,8,0]  R2405     5.9601086378097534e-01
    z[7,8,0]  R2406     1.6062282025814056e-01
    z[7,8,0]  R2407     7.6208159327507019e-02
    z[7,8,0]  R2408     1.8776229023933411e-01
    z[7,8,0]  R2409     2.9219251871109009e-01
    z[7,8,1]  R66       -1
    z[7,8,1]  R75       1
    z[7,8,1]  R2309     -1
    z[7,8,1]  R2310     1
    z[7,8,1]  R2321     -1.5911084413528442e-01
    z[7,8,1]  R2322     5.5689144134521484e-01
    z[7,8,1]  R2323     0.486074298620224
    z[7,8,1]  R2324     6.2916010618209839e-01
    z[7,8,1]  R2325     7.9231232404708862e-01
    z[7,8,1]  R2326     -1.3732153177261353e-01
    z[7,8,1]  R2327     -3.6912813782691956e-01
    z[7,8,1]  R2328     -1.3534417748451233e-01
    z[7,8,1]  R2329     -7.3680929839611053e-02
    z[7,8,1]  R2330     -0.0723814144730568
    z[7,8,1]  R2331     -7.2034609317779541e-01
    z[7,8,1]  R2332     -0.61319500207901
    z[7,8,1]  R2333     -9.4503128528594971e-01
    z[7,8,1]  R2334     -7.6930946111679077e-01
    z[7,8,1]  R2335     2.6116809248924255e-01
    z[7,8,1]  R2336     3.6502429842948914e-01
    z[7,8,1]  R2337     -1.9301742315292358e-01
    z[7,8,1]  R2338     -3.6066219210624695e-02
    z[7,8,1]  R2339     0.0985545814037323
    z[7,8,1]  R2340     9.0866394340991974e-02
    z[7,8,1]  R2341     -8.9232005178928375e-02
    z[7,8,1]  R2342     1.0712014138698578e-01
    z[7,8,1]  R2343     -2.0952789485454559e-01
    z[7,8,1]  R2344     1.0200225561857224e-01
    z[7,8,1]  R2345     -2.9675036668777466e-01
    z[7,8,1]  R2346     -3.8716565817594528e-02
    z[7,8,1]  R2347     2.2629378736019135e-01
    z[7,8,1]  R2348     1.1142539232969284e-01
    z[7,8,1]  R2349     -4.9738310277462006e-02
    z[7,8,1]  R2350     1.3619263470172882e-01
    z[7,8,1]  R2351     -2.9825264215469360e-01
    z[7,8,1]  R2352     0.158810555934906
    z[7,8,1]  R2353     6.5514102578163147e-02
    z[7,8,1]  R2354     2.4066442251205444e-01
    z[7,8,1]  R2355     8.1417721509933472e-01
    z[7,8,1]  R2356     7.5963789224624634e-01
    z[7,8,1]  R2357     9.3840479850769043e-02
    z[7,8,1]  R2358     7.4448043107986450e-01
    z[7,8,1]  R2359     5.1961439847946167e-01
    z[7,8,1]  R2360     -1.1067306250333786e-01
    z[7,8,1]  R2361     -1.0375775396823883e-01
    z[7,8,1]  R2362     -1.3680014014244080e-01
    z[7,8,1]  R2363     -6.6274926066398621e-02
    z[7,8,1]  R2364     -8.4054440259933472e-02
    z[7,8,1]  R2365     -0.0701156035065651
    z[7,8,1]  R2366     -2.2179307416081429e-02
    z[7,8,1]  R2367     5.2454501390457153e-01
    z[7,8,1]  R2368     0.493733674287796
    z[7,8,1]  R2369     -5.9646263718605042e-02
    z[7,8,1]  R2370     -2.1950985491275787e-01
    z[7,8,1]  R2371     -4.4922783970832825e-01
    z[7,8,1]  R2372     8.3052909374237061e-01
    z[7,8,1]  R2373     6.8209058046340942e-01
    z[7,8,1]  R2374     -4.4528263807296753e-01
    z[7,8,1]  R2375     5.5602818727493286e-01
    z[7,8,1]  R2376     -9.5779865980148315e-02
    z[7,8,1]  R2377     -2.1436543762683868e-01
    z[7,8,1]  R2378     2.4146403372287750e-01
    z[7,8,1]  R2379     -2.3044308647513390e-02
    z[7,8,1]  R2380     -6.6871589422225952e-01
    z[7,8,1]  R2381     -3.9978951215744019e-01
    z[7,8,1]  R2382     -8.5582023859024048e-01
    z[7,8,1]  R2383     -7.2121411561965942e-01
    z[7,8,1]  R2384     -6.7721736431121826e-01
    z[7,8,1]  R2385     -5.3825116157531738e-01
    z[7,8,1]  R2386     6.8262583017349243e-01
    z[7,8,1]  R2387     6.5230381488800049e-01
    z[7,8,1]  R2388     5.9098637104034424e-01
    z[7,8,1]  R2389     3.7552586197853088e-01
    z[7,8,1]  R2390     7.5368750095367432e-01
    z[7,8,1]  R2391     -1.2656638026237488e-01
    z[7,8,1]  R2392     8.1298571825027466e-01
    z[7,8,1]  R2393     0.571906566619873
    z[7,8,1]  R2394     -0.194657102227211
    z[7,8,1]  R2395     5.4000097513198853e-01
    z[7,8,1]  R2396     6.7094784975051880e-01
    z[7,8,1]  R2397     1.6056393086910248e-01
    z[7,8,1]  R2398     3.6845106631517410e-02
    z[7,8,1]  R2399     6.9970452785491943e-01
    z[7,8,1]  R2400     -5.3066217899322510e-01
    z[7,8,1]  R2401     -4.5293325185775757e-01
    z[7,8,1]  R2402     8.5955935716629028e-01
    z[7,8,1]  R2403     8.4101319313049316e-01
    z[7,8,1]  R2404     -2.3749370872974396e-01
    z[7,8,1]  R2405     3.9434126019477844e-01
    z[7,8,1]  R2406     2.2372731566429138e-01
    z[7,8,1]  R2407     -5.1802724599838257e-01
    z[7,8,1]  R2408     -4.8616993427276611e-01
    z[7,8,1]  R2409     -5.2370971441268921e-01
    z[7,8,2]  R67       -1
    z[7,8,2]  R76       1
    z[7,8,2]  R2311     -1
    z[7,8,2]  R2312     1
    z[7,8,2]  R2321     4.7734364867210388e-01
    z[7,8,2]  R2322     -6.9811606407165527e-01
    z[7,8,2]  R2323     -0.759968638420105
    z[7,8,2]  R2324     -5.7033151388168335e-01
    z[7,8,2]  R2325     -3.0093312263488770e-01
    z[7,8,2]  R2326     0.409659206867218
    z[7,8,2]  R2327     0.425683856010437
    z[7,8,2]  R2328     0.727834939956665
    z[7,8,2]  R2329     3.4167951345443726e-01
    z[7,8,2]  R2330     3.2505834102630615e-01
    z[7,8,2]  R2331     4.1031163930892944e-01
    z[7,8,2]  R2332     4.7157713770866394e-01
    z[7,8,2]  R2333     -6.8214975297451019e-02
    z[7,8,2]  R2334     -1.5069937705993652e-01
    z[7,8,2]  R2335     0.854481041431427
    z[7,8,2]  R2336     1.1533088982105255e-01
    z[7,8,2]  R2337     -8.7620846927165985e-02
    z[7,8,2]  R2338     -6.3486829400062561e-02
    z[7,8,2]  R2339     1.2221843935549259e-02
    z[7,8,2]  R2340     2.0777745544910431e-01
    z[7,8,2]  R2341     0.566098690032959
    z[7,8,2]  R2342     8.9974778890609741e-01
    z[7,8,2]  R2343     3.7261152267456055e-01
    z[7,8,2]  R2344     7.3742020130157471e-01
    z[7,8,2]  R2345     5.4701465368270874e-01
    z[7,8,2]  R2346     3.7120354175567627e-01
    z[7,8,2]  R2347     1.7128667235374451e-01
    z[7,8,2]  R2348     8.9861951768398285e-02
    z[7,8,2]  R2349     4.6292895078659058e-01
    z[7,8,2]  R2350     -1.5902958810329437e-01
    z[7,8,2]  R2351     5.0795876979827881e-01
    z[7,8,2]  R2352     -8.3484035730361938e-01
    z[7,8,2]  R2353     7.7183127403259277e-01
    z[7,8,2]  R2354     -2.4677228927612305e-01
    z[7,8,2]  R2355     3.4455919265747070e-01
    z[7,8,2]  R2356     1.7628923058509827e-01
    z[7,8,2]  R2357     -2.6017928123474121e-01
    z[7,8,2]  R2358     1.0638079047203064e-01
    z[7,8,2]  R2359     1.4143446087837219e-01
    z[7,8,2]  R2360     3.7904572486877441e-01
    z[7,8,2]  R2361     3.7979254126548767e-01
    z[7,8,2]  R2362     3.2405778765678406e-01
    z[7,8,2]  R2363     2.1882160007953644e-01
    z[7,8,2]  R2364     3.9865878224372864e-01
    z[7,8,2]  R2365     2.0446313917636871e-01
    z[7,8,2]  R2366     5.1931917667388916e-01
    z[7,8,2]  R2367     2.7487581968307495e-01
    z[7,8,2]  R2368     -1.6449946165084839e-01
    z[7,8,2]  R2369     2.2594226896762848e-01
    z[7,8,2]  R2370     0.7100790143013
    z[7,8,2]  R2371     4.3023586273193359e-01
    z[7,8,2]  R2372     -4.8305816948413849e-02
    z[7,8,2]  R2373     -2.1928794682025909e-01
    z[7,8,2]  R2374     5.6980025768280029e-01
    z[7,8,2]  R2375     -0.0349474772810936
    z[7,8,2]  R2376     1.2344136089086533e-01
    z[7,8,2]  R2377     -2.3615586757659912e-01
    z[7,8,2]  R2378     8.0060847103595734e-02
    z[7,8,2]  R2379     -3.9585116505622864e-01
    z[7,8,2]  R2380     6.3608062267303467e-01
    z[7,8,2]  R2381     7.9112827777862549e-01
    z[7,8,2]  R2382     1.4244359731674194e-01
    z[7,8,2]  R2383     -2.0884594321250916e-01
    z[7,8,2]  R2384     -2.1701818332076073e-02
    z[7,8,2]  R2385     -9.9197268486022949e-02
    z[7,8,2]  R2386     5.0201827287673950e-01
    z[7,8,2]  R2387     -2.5773242115974426e-01
    z[7,8,2]  R2388     4.9454274773597717e-01
    z[7,8,2]  R2389     -2.9461485147476196e-01
    z[7,8,2]  R2390     1.1328115314245224e-01
    z[7,8,2]  R2391     0.539489209651947
    z[7,8,2]  R2392     -4.4375345110893250e-01
    z[7,8,2]  R2393     3.7113359570503235e-01
    z[7,8,2]  R2394     -0.0311265978962183
    z[7,8,2]  R2395     3.3781643956899643e-02
    z[7,8,2]  R2396     0.557063639163971
    z[7,8,2]  R2397     -1.0965149849653244e-01
    z[7,8,2]  R2398     3.7170931696891785e-01
    z[7,8,2]  R2399     -1.2720093131065369e-01
    z[7,8,2]  R2400     -1.4464257657527924e-01
    z[7,8,2]  R2401     0.362500935792923
    z[7,8,2]  R2402     2.4618411064147949e-01
    z[7,8,2]  R2403     1.8544629216194153e-01
    z[7,8,2]  R2404     1.9276790320873260e-01
    z[7,8,2]  R2405     -1.4643782377243042e-01
    z[7,8,2]  R2406     -7.2910618782043457e-01
    z[7,8,2]  R2407     -5.5241280794143677e-01
    z[7,8,2]  R2408     -6.4018994569778442e-01
    z[7,8,2]  R2409     -4.1414281725883484e-01
    z[7,8,3]  R68       -1
    z[7,8,3]  R77       1
    z[7,8,3]  R2313     -1
    z[7,8,3]  R2314     1
    z[7,8,3]  R2321     -3.1089496612548828e-01
    z[7,8,3]  R2322     -4.5976629480719566e-03
    z[7,8,3]  R2323     -1.9953125715255737e-01
    z[7,8,3]  R2324     1.4465105533599854e-01
    z[7,8,3]  R2325     -1.1274618655443192e-01
    z[7,8,3]  R2326     -5.4057633876800537e-01
    z[7,8,3]  R2327     -6.1465138196945190e-01
    z[7,8,3]  R2328     -7.2582453489303589e-02
    z[7,8,3]  R2329     2.4491086602210999e-01
    z[7,8,3]  R2330     7.6523773372173309e-02
    z[7,8,3]  R2331     -2.3758205771446228e-01
    z[7,8,3]  R2332     5.9345021843910217e-02
    z[7,8,3]  R2333     -1.0046973824501038e-01
    z[7,8,3]  R2334     -2.6489657163619995e-01
    z[7,8,3]  R2335     -1.1019768565893173e-01
    z[7,8,3]  R2336     7.7369767427444458e-01
    z[7,8,3]  R2337     6.9227272272109985e-01
    z[7,8,3]  R2338     5.7540297508239746e-01
    z[7,8,3]  R2339     5.9350687265396118e-01
    z[7,8,3]  R2340     0.672277569770813
    z[7,8,3]  R2341     1.3080467283725739e-01
    z[7,8,3]  R2342     -1.2148908525705338e-01
    z[7,8,3]  R2343     -2.7065485715866089e-01
    z[7,8,3]  R2344     1.1624167859554291e-01
    z[7,8,3]  R2345     -1.5676201879978180e-01
    z[7,8,3]  R2346     -3.5875433683395386e-01
    z[7,8,3]  R2347     -4.3203625082969666e-01
    z[7,8,3]  R2348     -5.5732291936874390e-01
    z[7,8,3]  R2349     4.2104315757751465e-01
    z[7,8,3]  R2350     -6.8754607439041138e-01
    z[7,8,3]  R2351     -5.0349420309066772e-01
    z[7,8,3]  R2352     -1.9803847372531891e-01
    z[7,8,3]  R2353     -1.1736599728465080e-02
    z[7,8,3]  R2354     -2.4125337600708008e-01
    z[7,8,3]  R2355     6.0481783002614975e-02
    z[7,8,3]  R2356     8.9068122208118439e-02
    z[7,8,3]  R2357     -2.5103783607482910e-01
    z[7,8,3]  R2358     0.502587616443634
    z[7,8,3]  R2359     -3.6166378855705261e-01
    z[7,8,3]  R2360     -6.5457421541213989e-01
    z[7,8,3]  R2361     -6.6768777370452881e-01
    z[7,8,3]  R2362     -6.5568876266479492e-01
    z[7,8,3]  R2363     -9.6324187517166138e-01
    z[7,8,3]  R2364     -4.2995592951774597e-01
    z[7,8,3]  R2365     -0.778999388217926
    z[7,8,3]  R2366     -1.0544988512992859e-01
    z[7,8,3]  R2367     -8.3067983388900757e-02
    z[7,8,3]  R2368     -1.6315115988254547e-01
    z[7,8,3]  R2369     -0.58922278881073
    z[7,8,3]  R2370     3.8525944948196411e-01
    z[7,8,3]  R2371     4.7354760766029358e-01
    z[7,8,3]  R2372     1.7770472168922424e-01
    z[7,8,3]  R2373     1.1444151401519775e-01
    z[7,8,3]  R2374     5.2813404798507690e-01
    z[7,8,3]  R2375     7.9734158515930176e-01
    z[7,8,3]  R2376     5.4116570949554443e-01
    z[7,8,3]  R2377     8.3188760280609131e-01
    z[7,8,3]  R2378     0.582718014717102
    z[7,8,3]  R2379     6.8307328224182129e-01
    z[7,8,3]  R2380     -1.0596045106649399e-01
    z[7,8,3]  R2381     -2.8089922666549683e-01
    z[7,8,3]  R2382     2.3523949086666107e-01
    z[7,8,3]  R2383     -3.9567625522613525e-01
    z[7,8,3]  R2384     -7.2056323289871216e-02
    z[7,8,3]  R2385     -2.4559414386749268e-01
    z[7,8,3]  R2386     2.6950702071189880e-01
    z[7,8,3]  R2387     1.8879303336143494e-01
    z[7,8,3]  R2388     -2.4986344575881958e-01
    z[7,8,3]  R2389     3.7655803561210632e-01
    z[7,8,3]  R2390     -7.9082868993282318e-02
    z[7,8,3]  R2391     3.0169525742530823e-01
    z[7,8,3]  R2392     1.5044022351503372e-02
    z[7,8,3]  R2393     4.2207580804824829e-01
    z[7,8,3]  R2394     8.4545487165451050e-01
    z[7,8,3]  R2395     -6.9718080759048462e-01
    z[7,8,3]  R2396     3.2106384634971619e-01
    z[7,8,3]  R2397     6.7443537712097168e-01
    z[7,8,3]  R2398     -1.7858897149562836e-01
    z[7,8,3]  R2399     -5.9162354469299316e-01
    z[7,8,3]  R2400     -6.4128756523132324e-01
    z[7,8,3]  R2401     2.7004736661911011e-01
    z[7,8,3]  R2402     -1.6026093065738678e-01
    z[7,8,3]  R2403     2.8299784660339355e-01
    z[7,8,3]  R2404     -3.7891450524330139e-01
    z[7,8,3]  R2405     4.3775388039648533e-03
    z[7,8,3]  R2406     -5.9918439388275146e-01
    z[7,8,3]  R2407     3.7036202847957611e-02
    z[7,8,3]  R2408     1.2741230428218842e-01
    z[7,8,3]  R2409     1.5791422128677368e-01
    z[7,8,4]  R69       -1
    z[7,8,4]  R78       1
    z[7,8,4]  R2315     -1
    z[7,8,4]  R2316     1
    z[7,8,4]  R2321     -4.2951282858848572e-01
    z[7,8,4]  R2322     -3.1544342637062073e-01
    z[7,8,4]  R2323     -2.0930638536810875e-02
    z[7,8,4]  R2324     -2.9720824956893921e-01
    z[7,8,4]  R2325     -2.6059493422508240e-01
    z[7,8,4]  R2326     -5.3116768598556519e-01
    z[7,8,4]  R2327     4.5812425017356873e-01
    z[7,8,4]  R2328     -5.1798480749130249e-01
    z[7,8,4]  R2329     8.3333963155746460e-01
    z[7,8,4]  R2330     6.1238336563110352e-01
    z[7,8,4]  R2331     2.2035986185073853e-01
    z[7,8,4]  R2332     1.0738736391067505e-01
    z[7,8,4]  R2333     0.0919412299990654
    z[7,8,4]  R2334     -3.5267257690429688e-01
    z[7,8,4]  R2335     3.7516683340072632e-01
    z[7,8,4]  R2336     1.6356931626796722e-01
    z[7,8,4]  R2337     3.1342211365699768e-01
    z[7,8,4]  R2338     1.6645228862762451e-01
    z[7,8,4]  R2339     3.8846645504236221e-02
    z[7,8,4]  R2340     -5.2337568253278732e-02
    z[7,8,4]  R2341     7.2469997406005859e-01
    z[7,8,4]  R2342     3.1810739636421204e-01
    z[7,8,4]  R2343     2.3945939540863037e-01
    z[7,8,4]  R2344     -7.5018614530563354e-02
    z[7,8,4]  R2345     2.9431456327438354e-01
    z[7,8,4]  R2346     5.8305406570434570e-01
    z[7,8,4]  R2347     8.7009154260158539e-02
    z[7,8,4]  R2348     -1.7532825469970703e-02
    z[7,8,4]  R2349     -5.7780440896749496e-02
    z[7,8,4]  R2350     1.6788609325885773e-01
    z[7,8,4]  R2351     -2.7590867877006531e-01
    z[7,8,4]  R2352     -3.0516344308853149e-01
    z[7,8,4]  R2353     5.5181443691253662e-01
    z[7,8,4]  R2354     -0.774170458316803
    z[7,8,4]  R2355     7.4755914509296417e-02
    z[7,8,4]  R2356     3.0793941020965576e-01
    z[7,8,4]  R2357     -4.9027469754219055e-01
    z[7,8,4]  R2358     2.8126803040504456e-01
    z[7,8,4]  R2359     2.7190479636192322e-01
    z[7,8,4]  R2360     -5.5894082784652710e-01
    z[7,8,4]  R2361     -2.3572048544883728e-01
    z[7,8,4]  R2362     -3.8936766982078552e-01
    z[7,8,4]  R2363     9.9085070192813873e-02
    z[7,8,4]  R2364     0.656181275844574
    z[7,8,4]  R2365     4.0824091434478760e-01
    z[7,8,4]  R2366     -2.9309365153312683e-01
    z[7,8,4]  R2367     -2.0477418601512909e-01
    z[7,8,4]  R2368     -5.3559523075819016e-02
    z[7,8,4]  R2369     3.5402661561965942e-01
    z[7,8,4]  R2370     -5.0177015364170074e-02
    z[7,8,4]  R2371     4.5993265509605408e-01
    z[7,8,4]  R2372     1.7349453270435333e-01
    z[7,8,4]  R2373     -2.1278150379657745e-01
    z[7,8,4]  R2374     1.9889779388904572e-01
    z[7,8,4]  R2375     9.2982076108455658e-02
    z[7,8,4]  R2376     3.0479785799980164e-01
    z[7,8,4]  R2377     2.0064502954483032e-01
    z[7,8,4]  R2378     1.7051550745964050e-01
    z[7,8,4]  R2379     2.2355923056602478e-01
    z[7,8,4]  R2380     3.4694934729486704e-03
    z[7,8,4]  R2381     -1.5218140557408333e-02
    z[7,8,4]  R2382     -1.9779246300458908e-02
    z[7,8,4]  R2383     -0.30018350481987
    z[7,8,4]  R2384     -3.7041577696800232e-01
    z[7,8,4]  R2385     0.285529762506485
    z[7,8,4]  R2386     -2.4301761388778687e-01
    z[7,8,4]  R2387     2.9491928219795227e-01
    z[7,8,4]  R2388     4.4511565566062927e-01
    z[7,8,4]  R2389     0.0792914554476738
    z[7,8,4]  R2390     4.6958619356155396e-01
    z[7,8,4]  R2391     2.1743603050708771e-01
    z[7,8,4]  R2392     3.6259678006172180e-01
    z[7,8,4]  R2393     -3.0477797612547874e-02
    z[7,8,4]  R2394     2.1184088289737701e-01
    z[7,8,4]  R2395     1.3928785920143127e-01
    z[7,8,4]  R2396     -2.4499006569385529e-02
    z[7,8,4]  R2397     3.6405530571937561e-01
    z[7,8,4]  R2398     -2.1614167839288712e-02
    z[7,8,4]  R2399     3.6386170983314514e-01
    z[7,8,4]  R2400     4.8812088370323181e-01
    z[7,8,4]  R2401     3.5133868455886841e-01
    z[7,8,4]  R2402     1.9273412227630615e-01
    z[7,8,4]  R2403     1.5269558131694794e-01
    z[7,8,4]  R2404     0.191655695438385
    z[7,8,4]  R2405     -4.9689346551895142e-01
    z[7,8,4]  R2406     -0.0610814169049263
    z[7,8,4]  R2407     1.5813528001308441e-01
    z[7,8,4]  R2408     1.6630642116069794e-01
    z[7,8,4]  R2409     -3.2762092351913452e-01
    z[7,8,5]  R70       -1
    z[7,8,5]  R79       1
    z[7,8,5]  R2317     -1
    z[7,8,5]  R2318     1
    z[7,8,5]  R2321     2.1249738335609436e-01
    z[7,8,5]  R2322     9.7575500607490540e-02
    z[7,8,5]  R2323     -2.8740197420120239e-01
    z[7,8,5]  R2324     -4.0070423483848572e-01
    z[7,8,5]  R2325     -2.6399818062782288e-01
    z[7,8,5]  R2326     -3.3271342515945435e-02
    z[7,8,5]  R2327     -1.6200518608093262e-01
    z[7,8,5]  R2328     -2.4048025906085968e-01
    z[7,8,5]  R2329     1.5181684494018555e-01
    z[7,8,5]  R2330     -5.8379513025283813e-01
    z[7,8,5]  R2331     0.448576956987381
    z[7,8,5]  R2332     1.0339719057083130e-01
    z[7,8,5]  R2333     2.7096045669168234e-03
    z[7,8,5]  R2334     -1.6674175858497620e-02
    z[7,8,5]  R2335     -1.2662614881992340e-01
    z[7,8,5]  R2336     4.7588792443275452e-01
    z[7,8,5]  R2337     5.2533394098281860e-01
    z[7,8,5]  R2338     7.4735182523727417e-01
    z[7,8,5]  R2339     0.757960855960846
    z[7,8,5]  R2340     6.1516475677490234e-01
    z[7,8,5]  R2341     -3.2071188092231750e-01
    z[7,8,5]  R2342     -1.7135214805603027e-01
    z[7,8,5]  R2343     -8.2692736387252808e-01
    z[7,8,5]  R2344     -6.2636774778366089e-01
    z[7,8,5]  R2345     -6.6426640748977661e-01
    z[7,8,5]  R2346     -5.6905966997146606e-01
    z[7,8,5]  R2347     3.7096012383699417e-02
    z[7,8,5]  R2348     -2.2875617444515228e-01
    z[7,8,5]  R2349     2.0202431082725525e-01
    z[7,8,5]  R2350     9.1030269861221313e-02
    z[7,8,5]  R2351     -4.3095922470092773e-01
    z[7,8,5]  R2352     -1.9343747198581696e-01
    z[7,8,5]  R2353     -3.0414286255836487e-01
    z[7,8,5]  R2354     2.2270156443119049e-01
    z[7,8,5]  R2355     -5.6840542703866959e-02
    z[7,8,5]  R2356     4.9189507961273193e-01
    z[7,8,5]  R2357     2.0848602056503296e-01
    z[7,8,5]  R2358     2.7616280317306519e-01
    z[7,8,5]  R2359     0.472983181476593
    z[7,8,5]  R2360     -3.1899135559797287e-02
    z[7,8,5]  R2361     1.0000067949295044e-01
    z[7,8,5]  R2362     -1.7074528336524963e-01
    z[7,8,5]  R2363     -4.8373702913522720e-02
    z[7,8,5]  R2364     -1.9924034178256989e-01
    z[7,8,5]  R2365     6.7977467551827431e-03
    z[7,8,5]  R2366     -6.9073170423507690e-02
    z[7,8,5]  R2367     -5.7707138359546661e-02
    z[7,8,5]  R2368     -9.5456736162304878e-03
    z[7,8,5]  R2369     -6.4375180006027222e-01
    z[7,8,5]  R2370     5.1057100296020508e-01
    z[7,8,5]  R2371     9.1915823519229889e-02
    z[7,8,5]  R2372     -1.0320584289729595e-02
    z[7,8,5]  R2373     1.2849740684032440e-01
    z[7,8,5]  R2374     -3.7093784660100937e-02
    z[7,8,5]  R2375     -1.2073376774787903e-01
    z[7,8,5]  R2376     7.2403180599212646e-01
    z[7,8,5]  R2377     3.4957897663116455e-01
    z[7,8,5]  R2378     6.7242693901062012e-01
    z[7,8,5]  R2379     5.4841673374176025e-01
    z[7,8,5]  R2380     -4.7684319317340851e-02
    z[7,8,5]  R2381     -3.4641712903976440e-01
    z[7,8,5]  R2382     -2.5175441056489944e-02
    z[7,8,5]  R2383     4.0283703804016113e-01
    z[7,8,5]  R2384     5.8064728975296021e-01
    z[7,8,5]  R2385     6.5710562467575073e-01
    z[7,8,5]  R2386     -2.6476913690567017e-01
    z[7,8,5]  R2387     5.7118421792984009e-01
    z[7,8,5]  R2388     1.9922176003456116e-01
    z[7,8,5]  R2389     6.0836696624755859e-01
    z[7,8,5]  R2390     -2.1318690478801727e-01
    z[7,8,5]  R2391     4.8148801922798157e-01
    z[7,8,5]  R2392     0.000552017183508724
    z[7,8,5]  R2393     -5.3339886665344238e-01
    z[7,8,5]  R2394     4.3316060304641724e-01
    z[7,8,5]  R2395     3.7018787860870361e-01
    z[7,8,5]  R2396     3.0541330575942993e-01
    z[7,8,5]  R2397     5.6640452146530151e-01
    z[7,8,5]  R2398     8.3132719993591309e-01
    z[7,8,5]  R2399     3.5497869830578566e-03
    z[7,8,5]  R2400     3.1524743884801865e-02
    z[7,8,5]  R2401     5.4014086723327637e-01
    z[7,8,5]  R2402     1.7370861768722534e-01
    z[7,8,5]  R2403     8.1648379564285278e-02
    z[7,8,5]  R2404     4.9909746646881104e-01
    z[7,8,5]  R2405     4.5959451794624329e-01
    z[7,8,5]  R2406     -1.0670639574527740e-02
    z[7,8,5]  R2407     -5.2475303411483765e-01
    z[7,8,5]  R2408     -3.1629088521003723e-01
    z[7,8,5]  R2409     -5.7126820087432861e-01
    z[7,8,6]  R71       -1
    z[7,8,6]  R80       1
    z[7,8,6]  R2319     -1
    z[7,8,6]  R2320     1
    z[7,8,6]  R2321     6.2180775403976440e-01
    z[7,8,6]  R2322     -1.0742650181055069e-01
    z[7,8,6]  R2323     1.7828810214996338e-01
    z[7,8,6]  R2324     0.0646311566233635
    z[7,8,6]  R2325     3.5905060172080994e-01
    z[7,8,6]  R2326     4.7409194707870483e-01
    z[7,8,6]  R2327     1.2854970991611481e-01
    z[7,8,6]  R2328     2.5638380646705627e-01
    z[7,8,6]  R2329     -2.7579295635223389e-01
    z[7,8,6]  R2330     0.208499014377594
    z[7,8,6]  R2331     1.0201370343565941e-02
    z[7,8,6]  R2332     -5.7699644565582275e-01
    z[7,8,6]  R2333     7.2591170668601990e-02
    z[7,8,6]  R2334     -3.4751501679420471e-01
    z[7,8,6]  R2335     2.9964936897158623e-02
    z[7,8,6]  R2336     -2.6002980768680573e-02
    z[7,8,6]  R2337     2.0751388370990753e-01
    z[7,8,6]  R2338     4.5229196548461914e-02
    z[7,8,6]  R2339     -1.0698702931404114e-01
    z[7,8,6]  R2340     1.8542423844337463e-01
    z[7,8,6]  R2341     -5.1717776805162430e-02
    z[7,8,6]  R2342     1.8342463672161102e-01
    z[7,8,6]  R2343     2.7305299416184425e-02
    z[7,8,6]  R2344     -1.7285240814089775e-02
    z[7,8,6]  R2345     1.6663244366645813e-01
    z[7,8,6]  R2346     2.4774271249771118e-01
    z[7,8,6]  R2347     -3.1851489096879959e-02
    z[7,8,6]  R2348     -5.6645363569259644e-02
    z[7,8,6]  R2349     3.2567736506462097e-01
    z[7,8,6]  R2350     -8.8693656027317047e-02
    z[7,8,6]  R2351     -4.5062169432640076e-02
    z[7,8,6]  R2352     3.2510063052177429e-01
    z[7,8,6]  R2353     4.4114418327808380e-02
    z[7,8,6]  R2354     4.1693365573883057e-01
    z[7,8,6]  R2355     -2.2450645267963409e-01
    z[7,8,6]  R2356     1.2004944682121277e-01
    z[7,8,6]  R2357     -3.6084678769111633e-01
    z[7,8,6]  R2358     -1.3161915540695190e-01
    z[7,8,6]  R2359     2.1471166610717773e-01
    z[7,8,6]  R2360     3.1060501933097839e-01
    z[7,8,6]  R2361     5.6685513257980347e-01
    z[7,8,6]  R2362     -2.3149332404136658e-01
    z[7,8,6]  R2363     0.0737343579530716
    z[7,8,6]  R2364     1.9648127257823944e-01
    z[7,8,6]  R2365     -1.9989684224128723e-01
    z[7,8,6]  R2366     0.0941309928894043
    z[7,8,6]  R2367     -4.4072490930557251e-01
    z[7,8,6]  R2368     -5.0588476657867432e-01
    z[7,8,6]  R2369     -8.5069760680198669e-02
    z[7,8,6]  R2370     0.00797953736037016
    z[7,8,6]  R2371     -3.6925220489501953e-01
    z[7,8,6]  R2372     4.6424284577369690e-01
    z[7,8,6]  R2373     6.4075940847396851e-01
    z[7,8,6]  R2374     -3.4493547677993774e-01
    z[7,8,6]  R2375     8.6588621139526367e-02
    z[7,8,6]  R2376     -2.4086345732212067e-01
    z[7,8,6]  R2377     1.8434047698974609e-01
    z[7,8,6]  R2378     3.3821606636047363e-01
    z[7,8,6]  R2379     1.3408949971199036e-01
    z[7,8,6]  R2380     -2.2447763383388519e-01
    z[7,8,6]  R2381     6.6678076982498169e-02
    z[7,8,6]  R2382     4.2392125725746155e-01
    z[7,8,6]  R2383     1.4779888093471527e-01
    z[7,8,6]  R2384     -1.2012717127799988e-01
    z[7,8,6]  R2385     1.9500507414340973e-01
    z[7,8,6]  R2386     2.3942349851131439e-01
    z[7,8,6]  R2387     -1.2327600270509720e-01
    z[7,8,6]  R2388     -3.0668407678604126e-01
    z[7,8,6]  R2389     -2.5122725963592529e-01
    z[7,8,6]  R2390     -3.7140941619873047e-01
    z[7,8,6]  R2391     1.9923628866672516e-01
    z[7,8,6]  R2392     2.1036686375737190e-02
    z[7,8,6]  R2393     -1.1813435703516006e-01
    z[7,8,6]  R2394     -2.6810990646481514e-02
    z[7,8,6]  R2395     -1.9518600404262543e-01
    z[7,8,6]  R2396     2.0623704791069031e-01
    z[7,8,6]  R2397     1.0029902309179306e-01
    z[7,8,6]  R2398     -2.2265580296516418e-01
    z[7,8,6]  R2399     -1.0832364857196808e-01
    z[7,8,6]  R2400     7.1492679417133331e-02
    z[7,8,6]  R2401     2.7705797553062439e-01
    z[7,8,6]  R2402     -2.2224839031696320e-01
    z[7,8,6]  R2403     -2.0860308408737183e-01
    z[7,8,6]  R2404     6.1555508524179459e-02
    z[7,8,6]  R2405     9.8349370062351227e-02
    z[7,8,6]  R2406     1.7228952050209045e-01
    z[7,8,6]  R2407     -3.4487095475196838e-01
    z[7,8,6]  R2408     -4.1786277294158936e-01
    z[7,8,6]  R2409     -1.0108210891485214e-01
    z[8,7,0]  R65       1
    z[8,7,0]  R74       -1
    z[8,7,0]  R2410     -1
    z[8,7,0]  R2411     1
    z[8,7,0]  R2424     7.5502716004848480e-02
    z[8,7,0]  R2425     1.1088728159666061e-01
    z[8,7,0]  R2426     4.6042829751968384e-01
    z[8,7,0]  R2427     -4.7907486557960510e-02
    z[8,7,0]  R2428     -3.7452426552772522e-01
    z[8,7,0]  R2429     3.7386223673820496e-01
    z[8,7,0]  R2430     7.8686732053756714e-01
    z[8,7,0]  R2431     6.3473963737487793e-01
    z[8,7,0]  R2432     6.6608524322509766e-01
    z[8,7,0]  R2433     2.2632005810737610e-01
    z[8,7,0]  R2434     -1.8951016664505005e-01
    z[8,7,0]  R2435     1.8030634522438049e-01
    z[8,7,0]  R2436     -1.7487324774265289e-01
    z[8,7,0]  R2437     3.4759301692247391e-02
    z[8,7,0]  R2438     -1.9547063112258911e-01
    z[8,7,0]  R2439     1.5211117267608643e-01
    z[8,7,0]  R2440     8.7116084992885590e-02
    z[8,7,0]  R2441     -9.8972775042057037e-02
    z[8,7,0]  R2442     1.0068482719361782e-02
    z[8,7,0]  R2443     -8.6382992565631866e-02
    z[8,7,0]  R2444     -2.9037365317344666e-01
    z[8,7,0]  R2445     1.0343021899461746e-01
    z[8,7,0]  R2446     1.0587554425001144e-01
    z[8,7,0]  R2447     -7.3766030371189117e-02
    z[8,7,0]  R2448     2.1661940217018127e-01
    z[8,7,0]  R2449     2.9797169566154480e-01
    z[8,7,0]  R2450     1.5126696228981018e-01
    z[8,7,0]  R2451     2.0977418124675751e-01
    z[8,7,0]  R2452     -1.0889665782451630e-01
    z[8,7,0]  R2453     4.3689113855361938e-01
    z[8,7,0]  R2454     9.4676986336708069e-02
    z[8,7,0]  R2455     5.3207892179489136e-01
    z[8,7,0]  R2456     9.9957488477230072e-02
    z[8,7,0]  R2457     2.4007444083690643e-01
    z[8,7,0]  R2458     -1.1455266922712326e-01
    z[8,7,0]  R2459     1.6327553987503052e-01
    z[8,7,0]  R2460     -3.9882576093077660e-03
    z[8,7,0]  R2461     2.0957697927951813e-01
    z[8,7,0]  R2462     2.9569080471992493e-01
    z[8,7,0]  R2463     -8.5495337843894958e-03
    z[8,7,0]  R2464     -2.0459544658660889e-01
    z[8,7,0]  R2465     3.1395334005355835e-01
    z[8,7,0]  R2466     2.4114730954170227e-01
    z[8,7,0]  R2467     3.2360625267028809e-01
    z[8,7,0]  R2468     6.8792569637298584e-01
    z[8,7,0]  R2469     5.9601086378097534e-01
    z[8,7,0]  R2470     1.6062282025814056e-01
    z[8,7,0]  R2471     7.6208159327507019e-02
    z[8,7,0]  R2472     1.8776229023933411e-01
    z[8,7,0]  R2473     2.9219251871109009e-01
    z[8,7,0]  R2474     -1.8409195542335510e-01
    z[8,7,0]  R2475     -0.286214679479599
    z[8,7,0]  R2476     -1.7760060727596283e-01
    z[8,7,0]  R2477     6.9870322942733765e-02
    z[8,7,0]  R2478     -4.9463465809822083e-02
    z[8,7,0]  R2479     -1.1441210657358170e-01
    z[8,7,0]  R2480     -2.2823843359947205e-01
    z[8,7,0]  R2481     2.3409046232700348e-01
    z[8,7,0]  R2482     1.5582002699375153e-01
    z[8,7,0]  R2483     3.5205134749412537e-01
    z[8,7,0]  R2484     -8.0105133354663849e-02
    z[8,7,0]  R2485     -2.0721285045146942e-01
    z[8,7,0]  R2486     2.8006890416145325e-01
    z[8,7,0]  R2487     -2.6431012153625488e-01
    z[8,7,0]  R2488     -1.7840294539928436e-01
    z[8,7,0]  R2489     3.0782647430896759e-02
    z[8,7,0]  R2490     -0.241979718208313
    z[8,7,0]  R2491     -0.274396151304245
    z[8,7,0]  R2492     2.2456000745296478e-01
    z[8,7,0]  R2493     2.8472054004669189e-01
    z[8,7,0]  R2494     1.5407499670982361e-01
    z[8,7,0]  R2495     -4.5860470272600651e-03
    z[8,7,0]  R2496     -4.5927211642265320e-02
    z[8,7,0]  R2497     1.8447707593441010e-01
    z[8,7,0]  R2498     1.8028499186038971e-01
    z[8,7,0]  R2499     -0.0827464833855629
    z[8,7,0]  R2500     8.5019731521606445e-01
    z[8,7,0]  R2501     7.8297829627990723e-01
    z[8,7,0]  R2502     6.7507582902908325e-01
    z[8,7,0]  R2503     6.6264832019805908e-01
    z[8,7,0]  R2504     -3.6828601360321045e-01
    z[8,7,0]  R2505     4.8666980117559433e-02
    z[8,7,0]  R2506     2.9973436146974564e-02
    z[8,7,0]  R2507     -1.4538391493260860e-02
    z[8,7,0]  R2508     -3.9435279369354248e-01
    z[8,7,0]  R2509     -1.8094129860401154e-01
    z[8,7,0]  R2510     6.6815757751464844e-01
    z[8,7,0]  R2511     9.5584966242313385e-02
    z[8,7,0]  R2512     -4.8523190617561340e-01
    z[8,7,1]  R66       1
    z[8,7,1]  R75       -1
    z[8,7,1]  R2412     -1
    z[8,7,1]  R2413     1
    z[8,7,1]  R2424     -1.1067306250333786e-01
    z[8,7,1]  R2425     -1.0375775396823883e-01
    z[8,7,1]  R2426     -1.3680014014244080e-01
    z[8,7,1]  R2427     -6.6274926066398621e-02
    z[8,7,1]  R2428     -8.4054440259933472e-02
    z[8,7,1]  R2429     -0.0701156035065651
    z[8,7,1]  R2430     -2.2179307416081429e-02
    z[8,7,1]  R2431     5.2454501390457153e-01
    z[8,7,1]  R2432     0.493733674287796
    z[8,7,1]  R2433     -5.9646263718605042e-02
    z[8,7,1]  R2434     -2.1950985491275787e-01
    z[8,7,1]  R2435     -4.4922783970832825e-01
    z[8,7,1]  R2436     8.3052909374237061e-01
    z[8,7,1]  R2437     6.8209058046340942e-01
    z[8,7,1]  R2438     -4.4528263807296753e-01
    z[8,7,1]  R2439     5.5602818727493286e-01
    z[8,7,1]  R2440     -9.5779865980148315e-02
    z[8,7,1]  R2441     -2.1436543762683868e-01
    z[8,7,1]  R2442     2.4146403372287750e-01
    z[8,7,1]  R2443     -2.3044308647513390e-02
    z[8,7,1]  R2444     -6.6871589422225952e-01
    z[8,7,1]  R2445     -3.9978951215744019e-01
    z[8,7,1]  R2446     -8.5582023859024048e-01
    z[8,7,1]  R2447     -7.2121411561965942e-01
    z[8,7,1]  R2448     -6.7721736431121826e-01
    z[8,7,1]  R2449     -5.3825116157531738e-01
    z[8,7,1]  R2450     6.8262583017349243e-01
    z[8,7,1]  R2451     6.5230381488800049e-01
    z[8,7,1]  R2452     5.9098637104034424e-01
    z[8,7,1]  R2453     3.7552586197853088e-01
    z[8,7,1]  R2454     7.5368750095367432e-01
    z[8,7,1]  R2455     -1.2656638026237488e-01
    z[8,7,1]  R2456     8.1298571825027466e-01
    z[8,7,1]  R2457     0.571906566619873
    z[8,7,1]  R2458     -0.194657102227211
    z[8,7,1]  R2459     5.4000097513198853e-01
    z[8,7,1]  R2460     6.7094784975051880e-01
    z[8,7,1]  R2461     1.6056393086910248e-01
    z[8,7,1]  R2462     3.6845106631517410e-02
    z[8,7,1]  R2463     6.9970452785491943e-01
    z[8,7,1]  R2464     -5.3066217899322510e-01
    z[8,7,1]  R2465     -4.5293325185775757e-01
    z[8,7,1]  R2466     8.5955935716629028e-01
    z[8,7,1]  R2467     8.4101319313049316e-01
    z[8,7,1]  R2468     -2.3749370872974396e-01
    z[8,7,1]  R2469     3.9434126019477844e-01
    z[8,7,1]  R2470     2.2372731566429138e-01
    z[8,7,1]  R2471     -5.1802724599838257e-01
    z[8,7,1]  R2472     -4.8616993427276611e-01
    z[8,7,1]  R2473     -5.2370971441268921e-01
    z[8,7,1]  R2474     -1.5911084413528442e-01
    z[8,7,1]  R2475     5.5689144134521484e-01
    z[8,7,1]  R2476     0.486074298620224
    z[8,7,1]  R2477     6.2916010618209839e-01
    z[8,7,1]  R2478     7.9231232404708862e-01
    z[8,7,1]  R2479     -1.3732153177261353e-01
    z[8,7,1]  R2480     -3.6912813782691956e-01
    z[8,7,1]  R2481     -1.3534417748451233e-01
    z[8,7,1]  R2482     -7.3680929839611053e-02
    z[8,7,1]  R2483     -0.0723814144730568
    z[8,7,1]  R2484     -7.2034609317779541e-01
    z[8,7,1]  R2485     -0.61319500207901
    z[8,7,1]  R2486     -9.4503128528594971e-01
    z[8,7,1]  R2487     -7.6930946111679077e-01
    z[8,7,1]  R2488     2.6116809248924255e-01
    z[8,7,1]  R2489     3.6502429842948914e-01
    z[8,7,1]  R2490     -1.9301742315292358e-01
    z[8,7,1]  R2491     -3.6066219210624695e-02
    z[8,7,1]  R2492     0.0985545814037323
    z[8,7,1]  R2493     9.0866394340991974e-02
    z[8,7,1]  R2494     -8.9232005178928375e-02
    z[8,7,1]  R2495     1.0712014138698578e-01
    z[8,7,1]  R2496     -2.0952789485454559e-01
    z[8,7,1]  R2497     1.0200225561857224e-01
    z[8,7,1]  R2498     -2.9675036668777466e-01
    z[8,7,1]  R2499     -3.8716565817594528e-02
    z[8,7,1]  R2500     2.2629378736019135e-01
    z[8,7,1]  R2501     1.1142539232969284e-01
    z[8,7,1]  R2502     -4.9738310277462006e-02
    z[8,7,1]  R2503     1.3619263470172882e-01
    z[8,7,1]  R2504     -2.9825264215469360e-01
    z[8,7,1]  R2505     0.158810555934906
    z[8,7,1]  R2506     6.5514102578163147e-02
    z[8,7,1]  R2507     2.4066442251205444e-01
    z[8,7,1]  R2508     8.1417721509933472e-01
    z[8,7,1]  R2509     7.5963789224624634e-01
    z[8,7,1]  R2510     9.3840479850769043e-02
    z[8,7,1]  R2511     7.4448043107986450e-01
    z[8,7,1]  R2512     5.1961439847946167e-01
    z[8,7,2]  R67       1
    z[8,7,2]  R76       -1
    z[8,7,2]  R2414     -1
    z[8,7,2]  R2415     1
    z[8,7,2]  R2424     3.7904572486877441e-01
    z[8,7,2]  R2425     3.7979254126548767e-01
    z[8,7,2]  R2426     3.2405778765678406e-01
    z[8,7,2]  R2427     2.1882160007953644e-01
    z[8,7,2]  R2428     3.9865878224372864e-01
    z[8,7,2]  R2429     2.0446313917636871e-01
    z[8,7,2]  R2430     5.1931917667388916e-01
    z[8,7,2]  R2431     2.7487581968307495e-01
    z[8,7,2]  R2432     -1.6449946165084839e-01
    z[8,7,2]  R2433     2.2594226896762848e-01
    z[8,7,2]  R2434     0.7100790143013
    z[8,7,2]  R2435     4.3023586273193359e-01
    z[8,7,2]  R2436     -4.8305816948413849e-02
    z[8,7,2]  R2437     -2.1928794682025909e-01
    z[8,7,2]  R2438     5.6980025768280029e-01
    z[8,7,2]  R2439     -0.0349474772810936
    z[8,7,2]  R2440     1.2344136089086533e-01
    z[8,7,2]  R2441     -2.3615586757659912e-01
    z[8,7,2]  R2442     8.0060847103595734e-02
    z[8,7,2]  R2443     -3.9585116505622864e-01
    z[8,7,2]  R2444     6.3608062267303467e-01
    z[8,7,2]  R2445     7.9112827777862549e-01
    z[8,7,2]  R2446     1.4244359731674194e-01
    z[8,7,2]  R2447     -2.0884594321250916e-01
    z[8,7,2]  R2448     -2.1701818332076073e-02
    z[8,7,2]  R2449     -9.9197268486022949e-02
    z[8,7,2]  R2450     5.0201827287673950e-01
    z[8,7,2]  R2451     -2.5773242115974426e-01
    z[8,7,2]  R2452     4.9454274773597717e-01
    z[8,7,2]  R2453     -2.9461485147476196e-01
    z[8,7,2]  R2454     1.1328115314245224e-01
    z[8,7,2]  R2455     0.539489209651947
    z[8,7,2]  R2456     -4.4375345110893250e-01
    z[8,7,2]  R2457     3.7113359570503235e-01
    z[8,7,2]  R2458     -0.0311265978962183
    z[8,7,2]  R2459     3.3781643956899643e-02
    z[8,7,2]  R2460     0.557063639163971
    z[8,7,2]  R2461     -1.0965149849653244e-01
    z[8,7,2]  R2462     3.7170931696891785e-01
    z[8,7,2]  R2463     -1.2720093131065369e-01
    z[8,7,2]  R2464     -1.4464257657527924e-01
    z[8,7,2]  R2465     0.362500935792923
    z[8,7,2]  R2466     2.4618411064147949e-01
    z[8,7,2]  R2467     1.8544629216194153e-01
    z[8,7,2]  R2468     1.9276790320873260e-01
    z[8,7,2]  R2469     -1.4643782377243042e-01
    z[8,7,2]  R2470     -7.2910618782043457e-01
    z[8,7,2]  R2471     -5.5241280794143677e-01
    z[8,7,2]  R2472     -6.4018994569778442e-01
    z[8,7,2]  R2473     -4.1414281725883484e-01
    z[8,7,2]  R2474     4.7734364867210388e-01
    z[8,7,2]  R2475     -6.9811606407165527e-01
    z[8,7,2]  R2476     -0.759968638420105
    z[8,7,2]  R2477     -5.7033151388168335e-01
    z[8,7,2]  R2478     -3.0093312263488770e-01
    z[8,7,2]  R2479     0.409659206867218
    z[8,7,2]  R2480     0.425683856010437
    z[8,7,2]  R2481     0.727834939956665
    z[8,7,2]  R2482     3.4167951345443726e-01
    z[8,7,2]  R2483     3.2505834102630615e-01
    z[8,7,2]  R2484     4.1031163930892944e-01
    z[8,7,2]  R2485     4.7157713770866394e-01
    z[8,7,2]  R2486     -6.8214975297451019e-02
    z[8,7,2]  R2487     -1.5069937705993652e-01
    z[8,7,2]  R2488     0.854481041431427
    z[8,7,2]  R2489     1.1533088982105255e-01
    z[8,7,2]  R2490     -8.7620846927165985e-02
    z[8,7,2]  R2491     -6.3486829400062561e-02
    z[8,7,2]  R2492     1.2221843935549259e-02
    z[8,7,2]  R2493     2.0777745544910431e-01
    z[8,7,2]  R2494     0.566098690032959
    z[8,7,2]  R2495     8.9974778890609741e-01
    z[8,7,2]  R2496     3.7261152267456055e-01
    z[8,7,2]  R2497     7.3742020130157471e-01
    z[8,7,2]  R2498     5.4701465368270874e-01
    z[8,7,2]  R2499     3.7120354175567627e-01
    z[8,7,2]  R2500     1.7128667235374451e-01
    z[8,7,2]  R2501     8.9861951768398285e-02
    z[8,7,2]  R2502     4.6292895078659058e-01
    z[8,7,2]  R2503     -1.5902958810329437e-01
    z[8,7,2]  R2504     5.0795876979827881e-01
    z[8,7,2]  R2505     -8.3484035730361938e-01
    z[8,7,2]  R2506     7.7183127403259277e-01
    z[8,7,2]  R2507     -2.4677228927612305e-01
    z[8,7,2]  R2508     3.4455919265747070e-01
    z[8,7,2]  R2509     1.7628923058509827e-01
    z[8,7,2]  R2510     -2.6017928123474121e-01
    z[8,7,2]  R2511     1.0638079047203064e-01
    z[8,7,2]  R2512     1.4143446087837219e-01
    z[8,7,3]  R68       1
    z[8,7,3]  R77       -1
    z[8,7,3]  R2416     -1
    z[8,7,3]  R2417     1
    z[8,7,3]  R2424     -6.5457421541213989e-01
    z[8,7,3]  R2425     -6.6768777370452881e-01
    z[8,7,3]  R2426     -6.5568876266479492e-01
    z[8,7,3]  R2427     -9.6324187517166138e-01
    z[8,7,3]  R2428     -4.2995592951774597e-01
    z[8,7,3]  R2429     -0.778999388217926
    z[8,7,3]  R2430     -1.0544988512992859e-01
    z[8,7,3]  R2431     -8.3067983388900757e-02
    z[8,7,3]  R2432     -1.6315115988254547e-01
    z[8,7,3]  R2433     -0.58922278881073
    z[8,7,3]  R2434     3.8525944948196411e-01
    z[8,7,3]  R2435     4.7354760766029358e-01
    z[8,7,3]  R2436     1.7770472168922424e-01
    z[8,7,3]  R2437     1.1444151401519775e-01
    z[8,7,3]  R2438     5.2813404798507690e-01
    z[8,7,3]  R2439     7.9734158515930176e-01
    z[8,7,3]  R2440     5.4116570949554443e-01
    z[8,7,3]  R2441     8.3188760280609131e-01
    z[8,7,3]  R2442     0.582718014717102
    z[8,7,3]  R2443     6.8307328224182129e-01
    z[8,7,3]  R2444     -1.0596045106649399e-01
    z[8,7,3]  R2445     -2.8089922666549683e-01
    z[8,7,3]  R2446     2.3523949086666107e-01
    z[8,7,3]  R2447     -3.9567625522613525e-01
    z[8,7,3]  R2448     -7.2056323289871216e-02
    z[8,7,3]  R2449     -2.4559414386749268e-01
    z[8,7,3]  R2450     2.6950702071189880e-01
    z[8,7,3]  R2451     1.8879303336143494e-01
    z[8,7,3]  R2452     -2.4986344575881958e-01
    z[8,7,3]  R2453     3.7655803561210632e-01
    z[8,7,3]  R2454     -7.9082868993282318e-02
    z[8,7,3]  R2455     3.0169525742530823e-01
    z[8,7,3]  R2456     1.5044022351503372e-02
    z[8,7,3]  R2457     4.2207580804824829e-01
    z[8,7,3]  R2458     8.4545487165451050e-01
    z[8,7,3]  R2459     -6.9718080759048462e-01
    z[8,7,3]  R2460     3.2106384634971619e-01
    z[8,7,3]  R2461     6.7443537712097168e-01
    z[8,7,3]  R2462     -1.7858897149562836e-01
    z[8,7,3]  R2463     -5.9162354469299316e-01
    z[8,7,3]  R2464     -6.4128756523132324e-01
    z[8,7,3]  R2465     2.7004736661911011e-01
    z[8,7,3]  R2466     -1.6026093065738678e-01
    z[8,7,3]  R2467     2.8299784660339355e-01
    z[8,7,3]  R2468     -3.7891450524330139e-01
    z[8,7,3]  R2469     4.3775388039648533e-03
    z[8,7,3]  R2470     -5.9918439388275146e-01
    z[8,7,3]  R2471     3.7036202847957611e-02
    z[8,7,3]  R2472     1.2741230428218842e-01
    z[8,7,3]  R2473     1.5791422128677368e-01
    z[8,7,3]  R2474     -3.1089496612548828e-01
    z[8,7,3]  R2475     -4.5976629480719566e-03
    z[8,7,3]  R2476     -1.9953125715255737e-01
    z[8,7,3]  R2477     1.4465105533599854e-01
    z[8,7,3]  R2478     -1.1274618655443192e-01
    z[8,7,3]  R2479     -5.4057633876800537e-01
    z[8,7,3]  R2480     -6.1465138196945190e-01
    z[8,7,3]  R2481     -7.2582453489303589e-02
    z[8,7,3]  R2482     2.4491086602210999e-01
    z[8,7,3]  R2483     7.6523773372173309e-02
    z[8,7,3]  R2484     -2.3758205771446228e-01
    z[8,7,3]  R2485     5.9345021843910217e-02
    z[8,7,3]  R2486     -1.0046973824501038e-01
    z[8,7,3]  R2487     -2.6489657163619995e-01
    z[8,7,3]  R2488     -1.1019768565893173e-01
    z[8,7,3]  R2489     7.7369767427444458e-01
    z[8,7,3]  R2490     6.9227272272109985e-01
    z[8,7,3]  R2491     5.7540297508239746e-01
    z[8,7,3]  R2492     5.9350687265396118e-01
    z[8,7,3]  R2493     0.672277569770813
    z[8,7,3]  R2494     1.3080467283725739e-01
    z[8,7,3]  R2495     -1.2148908525705338e-01
    z[8,7,3]  R2496     -2.7065485715866089e-01
    z[8,7,3]  R2497     1.1624167859554291e-01
    z[8,7,3]  R2498     -1.5676201879978180e-01
    z[8,7,3]  R2499     -3.5875433683395386e-01
    z[8,7,3]  R2500     -4.3203625082969666e-01
    z[8,7,3]  R2501     -5.5732291936874390e-01
    z[8,7,3]  R2502     4.2104315757751465e-01
    z[8,7,3]  R2503     -6.8754607439041138e-01
    z[8,7,3]  R2504     -5.0349420309066772e-01
    z[8,7,3]  R2505     -1.9803847372531891e-01
    z[8,7,3]  R2506     -1.1736599728465080e-02
    z[8,7,3]  R2507     -2.4125337600708008e-01
    z[8,7,3]  R2508     6.0481783002614975e-02
    z[8,7,3]  R2509     8.9068122208118439e-02
    z[8,7,3]  R2510     -2.5103783607482910e-01
    z[8,7,3]  R2511     0.502587616443634
    z[8,7,3]  R2512     -3.6166378855705261e-01
    z[8,7,4]  R69       1
    z[8,7,4]  R78       -1
    z[8,7,4]  R2418     -1
    z[8,7,4]  R2419     1
    z[8,7,4]  R2424     -5.5894082784652710e-01
    z[8,7,4]  R2425     -2.3572048544883728e-01
    z[8,7,4]  R2426     -3.8936766982078552e-01
    z[8,7,4]  R2427     9.9085070192813873e-02
    z[8,7,4]  R2428     0.656181275844574
    z[8,7,4]  R2429     4.0824091434478760e-01
    z[8,7,4]  R2430     -2.9309365153312683e-01
    z[8,7,4]  R2431     -2.0477418601512909e-01
    z[8,7,4]  R2432     -5.3559523075819016e-02
    z[8,7,4]  R2433     3.5402661561965942e-01
    z[8,7,4]  R2434     -5.0177015364170074e-02
    z[8,7,4]  R2435     4.5993265509605408e-01
    z[8,7,4]  R2436     1.7349453270435333e-01
    z[8,7,4]  R2437     -2.1278150379657745e-01
    z[8,7,4]  R2438     1.9889779388904572e-01
    z[8,7,4]  R2439     9.2982076108455658e-02
    z[8,7,4]  R2440     3.0479785799980164e-01
    z[8,7,4]  R2441     2.0064502954483032e-01
    z[8,7,4]  R2442     1.7051550745964050e-01
    z[8,7,4]  R2443     2.2355923056602478e-01
    z[8,7,4]  R2444     3.4694934729486704e-03
    z[8,7,4]  R2445     -1.5218140557408333e-02
    z[8,7,4]  R2446     -1.9779246300458908e-02
    z[8,7,4]  R2447     -0.30018350481987
    z[8,7,4]  R2448     -3.7041577696800232e-01
    z[8,7,4]  R2449     0.285529762506485
    z[8,7,4]  R2450     -2.4301761388778687e-01
    z[8,7,4]  R2451     2.9491928219795227e-01
    z[8,7,4]  R2452     4.4511565566062927e-01
    z[8,7,4]  R2453     0.0792914554476738
    z[8,7,4]  R2454     4.6958619356155396e-01
    z[8,7,4]  R2455     2.1743603050708771e-01
    z[8,7,4]  R2456     3.6259678006172180e-01
    z[8,7,4]  R2457     -3.0477797612547874e-02
    z[8,7,4]  R2458     2.1184088289737701e-01
    z[8,7,4]  R2459     1.3928785920143127e-01
    z[8,7,4]  R2460     -2.4499006569385529e-02
    z[8,7,4]  R2461     3.6405530571937561e-01
    z[8,7,4]  R2462     -2.1614167839288712e-02
    z[8,7,4]  R2463     3.6386170983314514e-01
    z[8,7,4]  R2464     4.8812088370323181e-01
    z[8,7,4]  R2465     3.5133868455886841e-01
    z[8,7,4]  R2466     1.9273412227630615e-01
    z[8,7,4]  R2467     1.5269558131694794e-01
    z[8,7,4]  R2468     0.191655695438385
    z[8,7,4]  R2469     -4.9689346551895142e-01
    z[8,7,4]  R2470     -0.0610814169049263
    z[8,7,4]  R2471     1.5813528001308441e-01
    z[8,7,4]  R2472     1.6630642116069794e-01
    z[8,7,4]  R2473     -3.2762092351913452e-01
    z[8,7,4]  R2474     -4.2951282858848572e-01
    z[8,7,4]  R2475     -3.1544342637062073e-01
    z[8,7,4]  R2476     -2.0930638536810875e-02
    z[8,7,4]  R2477     -2.9720824956893921e-01
    z[8,7,4]  R2478     -2.6059493422508240e-01
    z[8,7,4]  R2479     -5.3116768598556519e-01
    z[8,7,4]  R2480     4.5812425017356873e-01
    z[8,7,4]  R2481     -5.1798480749130249e-01
    z[8,7,4]  R2482     8.3333963155746460e-01
    z[8,7,4]  R2483     6.1238336563110352e-01
    z[8,7,4]  R2484     2.2035986185073853e-01
    z[8,7,4]  R2485     1.0738736391067505e-01
    z[8,7,4]  R2486     0.0919412299990654
    z[8,7,4]  R2487     -3.5267257690429688e-01
    z[8,7,4]  R2488     3.7516683340072632e-01
    z[8,7,4]  R2489     1.6356931626796722e-01
    z[8,7,4]  R2490     3.1342211365699768e-01
    z[8,7,4]  R2491     1.6645228862762451e-01
    z[8,7,4]  R2492     3.8846645504236221e-02
    z[8,7,4]  R2493     -5.2337568253278732e-02
    z[8,7,4]  R2494     7.2469997406005859e-01
    z[8,7,4]  R2495     3.1810739636421204e-01
    z[8,7,4]  R2496     2.3945939540863037e-01
    z[8,7,4]  R2497     -7.5018614530563354e-02
    z[8,7,4]  R2498     2.9431456327438354e-01
    z[8,7,4]  R2499     5.8305406570434570e-01
    z[8,7,4]  R2500     8.7009154260158539e-02
    z[8,7,4]  R2501     -1.7532825469970703e-02
    z[8,7,4]  R2502     -5.7780440896749496e-02
    z[8,7,4]  R2503     1.6788609325885773e-01
    z[8,7,4]  R2504     -2.7590867877006531e-01
    z[8,7,4]  R2505     -3.0516344308853149e-01
    z[8,7,4]  R2506     5.5181443691253662e-01
    z[8,7,4]  R2507     -0.774170458316803
    z[8,7,4]  R2508     7.4755914509296417e-02
    z[8,7,4]  R2509     3.0793941020965576e-01
    z[8,7,4]  R2510     -4.9027469754219055e-01
    z[8,7,4]  R2511     2.8126803040504456e-01
    z[8,7,4]  R2512     2.7190479636192322e-01
    z[8,7,5]  R70       1
    z[8,7,5]  R79       -1
    z[8,7,5]  R2420     -1
    z[8,7,5]  R2421     1
    z[8,7,5]  R2424     -3.1899135559797287e-02
    z[8,7,5]  R2425     1.0000067949295044e-01
    z[8,7,5]  R2426     -1.7074528336524963e-01
    z[8,7,5]  R2427     -4.8373702913522720e-02
    z[8,7,5]  R2428     -1.9924034178256989e-01
    z[8,7,5]  R2429     6.7977467551827431e-03
    z[8,7,5]  R2430     -6.9073170423507690e-02
    z[8,7,5]  R2431     -5.7707138359546661e-02
    z[8,7,5]  R2432     -9.5456736162304878e-03
    z[8,7,5]  R2433     -6.4375180006027222e-01
    z[8,7,5]  R2434     5.1057100296020508e-01
    z[8,7,5]  R2435     9.1915823519229889e-02
    z[8,7,5]  R2436     -1.0320584289729595e-02
    z[8,7,5]  R2437     1.2849740684032440e-01
    z[8,7,5]  R2438     -3.7093784660100937e-02
    z[8,7,5]  R2439     -1.2073376774787903e-01
    z[8,7,5]  R2440     7.2403180599212646e-01
    z[8,7,5]  R2441     3.4957897663116455e-01
    z[8,7,5]  R2442     6.7242693901062012e-01
    z[8,7,5]  R2443     5.4841673374176025e-01
    z[8,7,5]  R2444     -4.7684319317340851e-02
    z[8,7,5]  R2445     -3.4641712903976440e-01
    z[8,7,5]  R2446     -2.5175441056489944e-02
    z[8,7,5]  R2447     4.0283703804016113e-01
    z[8,7,5]  R2448     5.8064728975296021e-01
    z[8,7,5]  R2449     6.5710562467575073e-01
    z[8,7,5]  R2450     -2.6476913690567017e-01
    z[8,7,5]  R2451     5.7118421792984009e-01
    z[8,7,5]  R2452     1.9922176003456116e-01
    z[8,7,5]  R2453     6.0836696624755859e-01
    z[8,7,5]  R2454     -2.1318690478801727e-01
    z[8,7,5]  R2455     4.8148801922798157e-01
    z[8,7,5]  R2456     0.000552017183508724
    z[8,7,5]  R2457     -5.3339886665344238e-01
    z[8,7,5]  R2458     4.3316060304641724e-01
    z[8,7,5]  R2459     3.7018787860870361e-01
    z[8,7,5]  R2460     3.0541330575942993e-01
    z[8,7,5]  R2461     5.6640452146530151e-01
    z[8,7,5]  R2462     8.3132719993591309e-01
    z[8,7,5]  R2463     3.5497869830578566e-03
    z[8,7,5]  R2464     3.1524743884801865e-02
    z[8,7,5]  R2465     5.4014086723327637e-01
    z[8,7,5]  R2466     1.7370861768722534e-01
    z[8,7,5]  R2467     8.1648379564285278e-02
    z[8,7,5]  R2468     4.9909746646881104e-01
    z[8,7,5]  R2469     4.5959451794624329e-01
    z[8,7,5]  R2470     -1.0670639574527740e-02
    z[8,7,5]  R2471     -5.2475303411483765e-01
    z[8,7,5]  R2472     -3.1629088521003723e-01
    z[8,7,5]  R2473     -5.7126820087432861e-01
    z[8,7,5]  R2474     2.1249738335609436e-01
    z[8,7,5]  R2475     9.7575500607490540e-02
    z[8,7,5]  R2476     -2.8740197420120239e-01
    z[8,7,5]  R2477     -4.0070423483848572e-01
    z[8,7,5]  R2478     -2.6399818062782288e-01
    z[8,7,5]  R2479     -3.3271342515945435e-02
    z[8,7,5]  R2480     -1.6200518608093262e-01
    z[8,7,5]  R2481     -2.4048025906085968e-01
    z[8,7,5]  R2482     1.5181684494018555e-01
    z[8,7,5]  R2483     -5.8379513025283813e-01
    z[8,7,5]  R2484     0.448576956987381
    z[8,7,5]  R2485     1.0339719057083130e-01
    z[8,7,5]  R2486     2.7096045669168234e-03
    z[8,7,5]  R2487     -1.6674175858497620e-02
    z[8,7,5]  R2488     -1.2662614881992340e-01
    z[8,7,5]  R2489     4.7588792443275452e-01
    z[8,7,5]  R2490     5.2533394098281860e-01
    z[8,7,5]  R2491     7.4735182523727417e-01
    z[8,7,5]  R2492     0.757960855960846
    z[8,7,5]  R2493     6.1516475677490234e-01
    z[8,7,5]  R2494     -3.2071188092231750e-01
    z[8,7,5]  R2495     -1.7135214805603027e-01
    z[8,7,5]  R2496     -8.2692736387252808e-01
    z[8,7,5]  R2497     -6.2636774778366089e-01
    z[8,7,5]  R2498     -6.6426640748977661e-01
    z[8,7,5]  R2499     -5.6905966997146606e-01
    z[8,7,5]  R2500     3.7096012383699417e-02
    z[8,7,5]  R2501     -2.2875617444515228e-01
    z[8,7,5]  R2502     2.0202431082725525e-01
    z[8,7,5]  R2503     9.1030269861221313e-02
    z[8,7,5]  R2504     -4.3095922470092773e-01
    z[8,7,5]  R2505     -1.9343747198581696e-01
    z[8,7,5]  R2506     -3.0414286255836487e-01
    z[8,7,5]  R2507     2.2270156443119049e-01
    z[8,7,5]  R2508     -5.6840542703866959e-02
    z[8,7,5]  R2509     4.9189507961273193e-01
    z[8,7,5]  R2510     2.0848602056503296e-01
    z[8,7,5]  R2511     2.7616280317306519e-01
    z[8,7,5]  R2512     0.472983181476593
    z[8,7,6]  R71       1
    z[8,7,6]  R80       -1
    z[8,7,6]  R2422     -1
    z[8,7,6]  R2423     1
    z[8,7,6]  R2424     3.1060501933097839e-01
    z[8,7,6]  R2425     5.6685513257980347e-01
    z[8,7,6]  R2426     -2.3149332404136658e-01
    z[8,7,6]  R2427     0.0737343579530716
    z[8,7,6]  R2428     1.9648127257823944e-01
    z[8,7,6]  R2429     -1.9989684224128723e-01
    z[8,7,6]  R2430     0.0941309928894043
    z[8,7,6]  R2431     -4.4072490930557251e-01
    z[8,7,6]  R2432     -5.0588476657867432e-01
    z[8,7,6]  R2433     -8.5069760680198669e-02
    z[8,7,6]  R2434     0.00797953736037016
    z[8,7,6]  R2435     -3.6925220489501953e-01
    z[8,7,6]  R2436     4.6424284577369690e-01
    z[8,7,6]  R2437     6.4075940847396851e-01
    z[8,7,6]  R2438     -3.4493547677993774e-01
    z[8,7,6]  R2439     8.6588621139526367e-02
    z[8,7,6]  R2440     -2.4086345732212067e-01
    z[8,7,6]  R2441     1.8434047698974609e-01
    z[8,7,6]  R2442     3.3821606636047363e-01
    z[8,7,6]  R2443     1.3408949971199036e-01
    z[8,7,6]  R2444     -2.2447763383388519e-01
    z[8,7,6]  R2445     6.6678076982498169e-02
    z[8,7,6]  R2446     4.2392125725746155e-01
    z[8,7,6]  R2447     1.4779888093471527e-01
    z[8,7,6]  R2448     -1.2012717127799988e-01
    z[8,7,6]  R2449     1.9500507414340973e-01
    z[8,7,6]  R2450     2.3942349851131439e-01
    z[8,7,6]  R2451     -1.2327600270509720e-01
    z[8,7,6]  R2452     -3.0668407678604126e-01
    z[8,7,6]  R2453     -2.5122725963592529e-01
    z[8,7,6]  R2454     -3.7140941619873047e-01
    z[8,7,6]  R2455     1.9923628866672516e-01
    z[8,7,6]  R2456     2.1036686375737190e-02
    z[8,7,6]  R2457     -1.1813435703516006e-01
    z[8,7,6]  R2458     -2.6810990646481514e-02
    z[8,7,6]  R2459     -1.9518600404262543e-01
    z[8,7,6]  R2460     2.0623704791069031e-01
    z[8,7,6]  R2461     1.0029902309179306e-01
    z[8,7,6]  R2462     -2.2265580296516418e-01
    z[8,7,6]  R2463     -1.0832364857196808e-01
    z[8,7,6]  R2464     7.1492679417133331e-02
    z[8,7,6]  R2465     2.7705797553062439e-01
    z[8,7,6]  R2466     -2.2224839031696320e-01
    z[8,7,6]  R2467     -2.0860308408737183e-01
    z[8,7,6]  R2468     6.1555508524179459e-02
    z[8,7,6]  R2469     9.8349370062351227e-02
    z[8,7,6]  R2470     1.7228952050209045e-01
    z[8,7,6]  R2471     -3.4487095475196838e-01
    z[8,7,6]  R2472     -4.1786277294158936e-01
    z[8,7,6]  R2473     -1.0108210891485214e-01
    z[8,7,6]  R2474     6.2180775403976440e-01
    z[8,7,6]  R2475     -1.0742650181055069e-01
    z[8,7,6]  R2476     1.7828810214996338e-01
    z[8,7,6]  R2477     0.0646311566233635
    z[8,7,6]  R2478     3.5905060172080994e-01
    z[8,7,6]  R2479     4.7409194707870483e-01
    z[8,7,6]  R2480     1.2854970991611481e-01
    z[8,7,6]  R2481     2.5638380646705627e-01
    z[8,7,6]  R2482     -2.7579295635223389e-01
    z[8,7,6]  R2483     0.208499014377594
    z[8,7,6]  R2484     1.0201370343565941e-02
    z[8,7,6]  R2485     -5.7699644565582275e-01
    z[8,7,6]  R2486     7.2591170668601990e-02
    z[8,7,6]  R2487     -3.4751501679420471e-01
    z[8,7,6]  R2488     2.9964936897158623e-02
    z[8,7,6]  R2489     -2.6002980768680573e-02
    z[8,7,6]  R2490     2.0751388370990753e-01
    z[8,7,6]  R2491     4.5229196548461914e-02
    z[8,7,6]  R2492     -1.0698702931404114e-01
    z[8,7,6]  R2493     1.8542423844337463e-01
    z[8,7,6]  R2494     -5.1717776805162430e-02
    z[8,7,6]  R2495     1.8342463672161102e-01
    z[8,7,6]  R2496     2.7305299416184425e-02
    z[8,7,6]  R2497     -1.7285240814089775e-02
    z[8,7,6]  R2498     1.6663244366645813e-01
    z[8,7,6]  R2499     2.4774271249771118e-01
    z[8,7,6]  R2500     -3.1851489096879959e-02
    z[8,7,6]  R2501     -5.6645363569259644e-02
    z[8,7,6]  R2502     3.2567736506462097e-01
    z[8,7,6]  R2503     -8.8693656027317047e-02
    z[8,7,6]  R2504     -4.5062169432640076e-02
    z[8,7,6]  R2505     3.2510063052177429e-01
    z[8,7,6]  R2506     4.4114418327808380e-02
    z[8,7,6]  R2507     4.1693365573883057e-01
    z[8,7,6]  R2508     -2.2450645267963409e-01
    z[8,7,6]  R2509     1.2004944682121277e-01
    z[8,7,6]  R2510     -3.6084678769111633e-01
    z[8,7,6]  R2511     -1.3161915540695190e-01
    z[8,7,6]  R2512     2.1471166610717773e-01
    z[8,9,0]  R74       -1
    z[8,9,0]  R83       1
    z[8,9,0]  R2513     -1
    z[8,9,0]  R2514     1
    z[8,9,0]  R2527     7.5502716004848480e-02
    z[8,9,0]  R2528     1.1088728159666061e-01
    z[8,9,0]  R2529     4.6042829751968384e-01
    z[8,9,0]  R2530     -4.7907486557960510e-02
    z[8,9,0]  R2531     -3.7452426552772522e-01
    z[8,9,0]  R2532     3.7386223673820496e-01
    z[8,9,0]  R2533     7.8686732053756714e-01
    z[8,9,0]  R2534     6.3473963737487793e-01
    z[8,9,0]  R2535     6.6608524322509766e-01
    z[8,9,0]  R2536     2.2632005810737610e-01
    z[8,9,0]  R2537     -1.8951016664505005e-01
    z[8,9,0]  R2538     1.8030634522438049e-01
    z[8,9,0]  R2539     -1.7487324774265289e-01
    z[8,9,0]  R2540     3.4759301692247391e-02
    z[8,9,0]  R2541     -1.9547063112258911e-01
    z[8,9,0]  R2542     1.5211117267608643e-01
    z[8,9,0]  R2543     8.7116084992885590e-02
    z[8,9,0]  R2544     -9.8972775042057037e-02
    z[8,9,0]  R2545     1.0068482719361782e-02
    z[8,9,0]  R2546     -8.6382992565631866e-02
    z[8,9,0]  R2547     -2.9037365317344666e-01
    z[8,9,0]  R2548     1.0343021899461746e-01
    z[8,9,0]  R2549     1.0587554425001144e-01
    z[8,9,0]  R2550     -7.3766030371189117e-02
    z[8,9,0]  R2551     2.1661940217018127e-01
    z[8,9,0]  R2552     2.9797169566154480e-01
    z[8,9,0]  R2553     1.5126696228981018e-01
    z[8,9,0]  R2554     2.0977418124675751e-01
    z[8,9,0]  R2555     -1.0889665782451630e-01
    z[8,9,0]  R2556     4.3689113855361938e-01
    z[8,9,0]  R2557     9.4676986336708069e-02
    z[8,9,0]  R2558     5.3207892179489136e-01
    z[8,9,0]  R2559     9.9957488477230072e-02
    z[8,9,0]  R2560     2.4007444083690643e-01
    z[8,9,0]  R2561     -1.1455266922712326e-01
    z[8,9,0]  R2562     1.6327553987503052e-01
    z[8,9,0]  R2563     -3.9882576093077660e-03
    z[8,9,0]  R2564     2.0957697927951813e-01
    z[8,9,0]  R2565     2.9569080471992493e-01
    z[8,9,0]  R2566     -8.5495337843894958e-03
    z[8,9,0]  R2567     -2.0459544658660889e-01
    z[8,9,0]  R2568     3.1395334005355835e-01
    z[8,9,0]  R2569     2.4114730954170227e-01
    z[8,9,0]  R2570     3.2360625267028809e-01
    z[8,9,0]  R2571     6.8792569637298584e-01
    z[8,9,0]  R2572     5.9601086378097534e-01
    z[8,9,0]  R2573     1.6062282025814056e-01
    z[8,9,0]  R2574     7.6208159327507019e-02
    z[8,9,0]  R2575     1.8776229023933411e-01
    z[8,9,0]  R2576     2.9219251871109009e-01
    z[8,9,0]  R2577     -1.1226820200681686e-01
    z[8,9,0]  R2578     -2.9766298830509186e-03
    z[8,9,0]  R2579     -5.9259835630655289e-02
    z[8,9,0]  R2580     -1.3733139634132385e-01
    z[8,9,0]  R2581     -1.6203567385673523e-02
    z[8,9,0]  R2582     -2.8471872210502625e-01
    z[8,9,0]  R2583     9.4680595397949219e-01
    z[8,9,0]  R2584     9.3098402023315430e-01
    z[8,9,0]  R2585     9.1860550642013550e-01
    z[8,9,0]  R2586     8.8751626014709473e-01
    z[8,9,0]  R2587     -6.1334443092346191e-01
    z[8,9,0]  R2588     -2.9817822575569153e-01
    z[8,9,0]  R2589     9.3357026576995850e-02
    z[8,9,0]  R2590     -1.1157221347093582e-01
    z[8,9,0]  R2591     -1.5873283147811890e-01
    z[8,9,0]  R2592     1.2745600193738937e-02
    z[8,9,0]  R2593     -2.2245932370424271e-02
    z[8,9,0]  R2594     -0.060992531478405
    z[8,9,0]  R2595     -1.1587447673082352e-01
    z[8,9,0]  R2596     -1.8560811877250671e-01
    z[8,9,0]  R2597     -4.2634120583534241e-01
    z[8,9,0]  R2598     -1.3205859065055847e-01
    z[8,9,0]  R2599     -0.000888276903424412
    z[8,9,0]  R2600     -1.3749279081821442e-01
    z[8,9,0]  R2601     -1.6728754341602325e-01
    z[8,9,0]  R2602     -8.9038275182247162e-02
    z[8,9,0]  R2603     -1.6110089421272278e-01
    z[8,9,0]  R2604     -1.5334102511405945e-01
    z[8,9,0]  R2605     -6.4253114163875580e-02
    z[8,9,0]  R2606     1.0551518946886063e-01
    z[8,9,0]  R2607     6.7918163537979126e-01
    z[8,9,0]  R2608     2.8729543089866638e-01
    z[8,9,0]  R2609     -8.0463126301765442e-02
    z[8,9,0]  R2610     -2.2232008632272482e-03
    z[8,9,0]  R2611     1.1726172268390656e-01
    z[8,9,0]  R2612     -1.7584471404552460e-01
    z[8,9,0]  R2613     -1.8058015406131744e-01
    z[8,9,0]  R2614     -7.9893134534358978e-02
    z[8,9,0]  R2615     -1.4695121347904205e-01
    z[8,9,1]  R75       -1
    z[8,9,1]  R84       1
    z[8,9,1]  R2515     -1
    z[8,9,1]  R2516     1
    z[8,9,1]  R2527     -1.1067306250333786e-01
    z[8,9,1]  R2528     -1.0375775396823883e-01
    z[8,9,1]  R2529     -1.3680014014244080e-01
    z[8,9,1]  R2530     -6.6274926066398621e-02
    z[8,9,1]  R2531     -8.4054440259933472e-02
    z[8,9,1]  R2532     -0.0701156035065651
    z[8,9,1]  R2533     -2.2179307416081429e-02
    z[8,9,1]  R2534     5.2454501390457153e-01
    z[8,9,1]  R2535     0.493733674287796
    z[8,9,1]  R2536     -5.9646263718605042e-02
    z[8,9,1]  R2537     -2.1950985491275787e-01
    z[8,9,1]  R2538     -4.4922783970832825e-01
    z[8,9,1]  R2539     8.3052909374237061e-01
    z[8,9,1]  R2540     6.8209058046340942e-01
    z[8,9,1]  R2541     -4.4528263807296753e-01
    z[8,9,1]  R2542     5.5602818727493286e-01
    z[8,9,1]  R2543     -9.5779865980148315e-02
    z[8,9,1]  R2544     -2.1436543762683868e-01
    z[8,9,1]  R2545     2.4146403372287750e-01
    z[8,9,1]  R2546     -2.3044308647513390e-02
    z[8,9,1]  R2547     -6.6871589422225952e-01
    z[8,9,1]  R2548     -3.9978951215744019e-01
    z[8,9,1]  R2549     -8.5582023859024048e-01
    z[8,9,1]  R2550     -7.2121411561965942e-01
    z[8,9,1]  R2551     -6.7721736431121826e-01
    z[8,9,1]  R2552     -5.3825116157531738e-01
    z[8,9,1]  R2553     6.8262583017349243e-01
    z[8,9,1]  R2554     6.5230381488800049e-01
    z[8,9,1]  R2555     5.9098637104034424e-01
    z[8,9,1]  R2556     3.7552586197853088e-01
    z[8,9,1]  R2557     7.5368750095367432e-01
    z[8,9,1]  R2558     -1.2656638026237488e-01
    z[8,9,1]  R2559     8.1298571825027466e-01
    z[8,9,1]  R2560     0.571906566619873
    z[8,9,1]  R2561     -0.194657102227211
    z[8,9,1]  R2562     5.4000097513198853e-01
    z[8,9,1]  R2563     6.7094784975051880e-01
    z[8,9,1]  R2564     1.6056393086910248e-01
    z[8,9,1]  R2565     3.6845106631517410e-02
    z[8,9,1]  R2566     6.9970452785491943e-01
    z[8,9,1]  R2567     -5.3066217899322510e-01
    z[8,9,1]  R2568     -4.5293325185775757e-01
    z[8,9,1]  R2569     8.5955935716629028e-01
    z[8,9,1]  R2570     8.4101319313049316e-01
    z[8,9,1]  R2571     -2.3749370872974396e-01
    z[8,9,1]  R2572     3.9434126019477844e-01
    z[8,9,1]  R2573     2.2372731566429138e-01
    z[8,9,1]  R2574     -5.1802724599838257e-01
    z[8,9,1]  R2575     -4.8616993427276611e-01
    z[8,9,1]  R2576     -5.2370971441268921e-01
    z[8,9,1]  R2577     -0.0619843415915966
    z[8,9,1]  R2578     9.2010758817195892e-02
    z[8,9,1]  R2579     5.7703733444213867e-02
    z[8,9,1]  R2580     -1.2753465771675110e-01
    z[8,9,1]  R2581     -1.2947869300842285e-01
    z[8,9,1]  R2582     2.1319158375263214e-02
    z[8,9,1]  R2583     3.1947411596775055e-02
    z[8,9,1]  R2584     -1.4657779037952423e-01
    z[8,9,1]  R2585     -1.2175092846155167e-01
    z[8,9,1]  R2586     -1.3593797385692596e-01
    z[8,9,1]  R2587     4.0202805399894714e-01
    z[8,9,1]  R2588     1.7121504247188568e-01
    z[8,9,1]  R2589     8.6095374822616577e-01
    z[8,9,1]  R2590     -9.3606638908386230e-01
    z[8,9,1]  R2591     -9.4337177276611328e-01
    z[8,9,1]  R2592     -9.2986398935317993e-01
    z[8,9,1]  R2593     -9.3202722072601318e-01
    z[8,9,1]  R2594     -9.1925334930419922e-01
    z[8,9,1]  R2595     -9.1619348526000977e-01
    z[8,9,1]  R2596     -9.0627974271774292e-01
    z[8,9,1]  R2597     2.1944376826286316e-01
    z[8,9,1]  R2598     -6.3455426692962646e-01
    z[8,9,1]  R2599     -6.2975788116455078e-01
    z[8,9,1]  R2600     -0.53675377368927
    z[8,9,1]  R2601     -4.9162584543228149e-01
    z[8,9,1]  R2602     -4.4674062728881836e-01
    z[8,9,1]  R2603     -5.8175098896026611e-01
    z[8,9,1]  R2604     -4.9923619627952576e-01
    z[8,9,1]  R2605     -7.7833518385887146e-02
    z[8,9,1]  R2606     -5.4391577839851379e-02
    z[8,9,1]  R2607     -5.0886329263448715e-02
    z[8,9,1]  R2608     -3.9508793503046036e-02
    z[8,9,1]  R2609     -9.5183652639389038e-01
    z[8,9,1]  R2610     -9.5026838779449463e-01
    z[8,9,1]  R2611     -9.3119555711746216e-01
    z[8,9,1]  R2612     -8.8639110326766968e-01
    z[8,9,1]  R2613     -6.0358375310897827e-01
    z[8,9,1]  R2614     -2.6260793209075928e-01
    z[8,9,1]  R2615     -3.1257179379463196e-01
    z[8,9,2]  R76       -1
    z[8,9,2]  R85       1
    z[8,9,2]  R2517     -1
    z[8,9,2]  R2518     1
    z[8,9,2]  R2527     3.7904572486877441e-01
    z[8,9,2]  R2528     3.7979254126548767e-01
    z[8,9,2]  R2529     3.2405778765678406e-01
    z[8,9,2]  R2530     2.1882160007953644e-01
    z[8,9,2]  R2531     3.9865878224372864e-01
    z[8,9,2]  R2532     2.0446313917636871e-01
    z[8,9,2]  R2533     5.1931917667388916e-01
    z[8,9,2]  R2534     2.7487581968307495e-01
    z[8,9,2]  R2535     -1.6449946165084839e-01
    z[8,9,2]  R2536     2.2594226896762848e-01
    z[8,9,2]  R2537     0.7100790143013
    z[8,9,2]  R2538     4.3023586273193359e-01
    z[8,9,2]  R2539     -4.8305816948413849e-02
    z[8,9,2]  R2540     -2.1928794682025909e-01
    z[8,9,2]  R2541     5.6980025768280029e-01
    z[8,9,2]  R2542     -0.0349474772810936
    z[8,9,2]  R2543     1.2344136089086533e-01
    z[8,9,2]  R2544     -2.3615586757659912e-01
    z[8,9,2]  R2545     8.0060847103595734e-02
    z[8,9,2]  R2546     -3.9585116505622864e-01
    z[8,9,2]  R2547     6.3608062267303467e-01
    z[8,9,2]  R2548     7.9112827777862549e-01
    z[8,9,2]  R2549     1.4244359731674194e-01
    z[8,9,2]  R2550     -2.0884594321250916e-01
    z[8,9,2]  R2551     -2.1701818332076073e-02
    z[8,9,2]  R2552     -9.9197268486022949e-02
    z[8,9,2]  R2553     5.0201827287673950e-01
    z[8,9,2]  R2554     -2.5773242115974426e-01
    z[8,9,2]  R2555     4.9454274773597717e-01
    z[8,9,2]  R2556     -2.9461485147476196e-01
    z[8,9,2]  R2557     1.1328115314245224e-01
    z[8,9,2]  R2558     0.539489209651947
    z[8,9,2]  R2559     -4.4375345110893250e-01
    z[8,9,2]  R2560     3.7113359570503235e-01
    z[8,9,2]  R2561     -0.0311265978962183
    z[8,9,2]  R2562     3.3781643956899643e-02
    z[8,9,2]  R2563     0.557063639163971
    z[8,9,2]  R2564     -1.0965149849653244e-01
    z[8,9,2]  R2565     3.7170931696891785e-01
    z[8,9,2]  R2566     -1.2720093131065369e-01
    z[8,9,2]  R2567     -1.4464257657527924e-01
    z[8,9,2]  R2568     0.362500935792923
    z[8,9,2]  R2569     2.4618411064147949e-01
    z[8,9,2]  R2570     1.8544629216194153e-01
    z[8,9,2]  R2571     1.9276790320873260e-01
    z[8,9,2]  R2572     -1.4643782377243042e-01
    z[8,9,2]  R2573     -7.2910618782043457e-01
    z[8,9,2]  R2574     -5.5241280794143677e-01
    z[8,9,2]  R2575     -6.4018994569778442e-01
    z[8,9,2]  R2576     -4.1414281725883484e-01
    z[8,9,2]  R2577     -7.4411070346832275e-01
    z[8,9,2]  R2578     -3.6822758615016937e-02
    z[8,9,2]  R2579     -7.7068406343460083e-01
    z[8,9,2]  R2580     3.2374224066734314e-01
    z[8,9,2]  R2581     -8.4436124563217163e-01
    z[8,9,2]  R2582     -6.0189658403396606e-01
    z[8,9,2]  R2583     -3.3512271940708160e-02
    z[8,9,2]  R2584     0.0568292960524559
    z[8,9,2]  R2585     7.6525114476680756e-02
    z[8,9,2]  R2586     2.6634183526039124e-01
    z[8,9,2]  R2587     2.8374445438385010e-01
    z[8,9,2]  R2588     -2.0799554884433746e-01
    z[8,9,2]  R2589     2.7511257678270340e-02
    z[8,9,2]  R2590     1.4409109950065613e-01
    z[8,9,2]  R2591     2.4562698602676392e-01
    z[8,9,2]  R2592     7.0352025330066681e-02
    z[8,9,2]  R2593     1.3667736947536469e-01
    z[8,9,2]  R2594     2.1717865020036697e-02
    z[8,9,2]  R2595     1.2249117344617844e-01
    z[8,9,2]  R2596     2.9887804761528969e-02
    z[8,9,2]  R2597     6.9608017802238464e-02
    z[8,9,2]  R2598     6.9652813673019409e-01
    z[8,9,2]  R2599     6.6887855529785156e-01
    z[8,9,2]  R2600     7.8212898969650269e-01
    z[8,9,2]  R2601     7.3169898986816406e-01
    z[8,9,2]  R2602     8.6300361156463623e-01
    z[8,9,2]  R2603     6.7788320779800415e-01
    z[8,9,2]  R2604     6.0109579563140869e-01
    z[8,9,2]  R2605     5.0276088714599609e-01
    z[8,9,2]  R2606     5.2670013904571533e-01
    z[8,9,2]  R2607     -3.9953124523162842e-01
    z[8,9,2]  R2608     9.0667629241943359e-01
    z[8,9,2]  R2609     1.6216188669204712e-01
    z[8,9,2]  R2610     1.7469123005867004e-01
    z[8,9,2]  R2611     -0.0906200259923935
    z[8,9,2]  R2612     1.3017450273036957e-01
    z[8,9,2]  R2613     6.1005896329879761e-01
    z[8,9,2]  R2614     -5.0542913377285004e-02
    z[8,9,2]  R2615     1.2443476915359497e-01
    z[8,9,3]  R77       -1
    z[8,9,3]  R86       1
    z[8,9,3]  R2519     -1
    z[8,9,3]  R2520     1
    z[8,9,3]  R2527     -6.5457421541213989e-01
    z[8,9,3]  R2528     -6.6768777370452881e-01
    z[8,9,3]  R2529     -6.5568876266479492e-01
    z[8,9,3]  R2530     -9.6324187517166138e-01
    z[8,9,3]  R2531     -4.2995592951774597e-01
    z[8,9,3]  R2532     -0.778999388217926
    z[8,9,3]  R2533     -1.0544988512992859e-01
    z[8,9,3]  R2534     -8.3067983388900757e-02
    z[8,9,3]  R2535     -1.6315115988254547e-01
    z[8,9,3]  R2536     -0.58922278881073
    z[8,9,3]  R2537     3.8525944948196411e-01
    z[8,9,3]  R2538     4.7354760766029358e-01
    z[8,9,3]  R2539     1.7770472168922424e-01
    z[8,9,3]  R2540     1.1444151401519775e-01
    z[8,9,3]  R2541     5.2813404798507690e-01
    z[8,9,3]  R2542     7.9734158515930176e-01
    z[8,9,3]  R2543     5.4116570949554443e-01
    z[8,9,3]  R2544     8.3188760280609131e-01
    z[8,9,3]  R2545     0.582718014717102
    z[8,9,3]  R2546     6.8307328224182129e-01
    z[8,9,3]  R2547     -1.0596045106649399e-01
    z[8,9,3]  R2548     -2.8089922666549683e-01
    z[8,9,3]  R2549     2.3523949086666107e-01
    z[8,9,3]  R2550     -3.9567625522613525e-01
    z[8,9,3]  R2551     -7.2056323289871216e-02
    z[8,9,3]  R2552     -2.4559414386749268e-01
    z[8,9,3]  R2553     2.6950702071189880e-01
    z[8,9,3]  R2554     1.8879303336143494e-01
    z[8,9,3]  R2555     -2.4986344575881958e-01
    z[8,9,3]  R2556     3.7655803561210632e-01
    z[8,9,3]  R2557     -7.9082868993282318e-02
    z[8,9,3]  R2558     3.0169525742530823e-01
    z[8,9,3]  R2559     1.5044022351503372e-02
    z[8,9,3]  R2560     4.2207580804824829e-01
    z[8,9,3]  R2561     8.4545487165451050e-01
    z[8,9,3]  R2562     -6.9718080759048462e-01
    z[8,9,3]  R2563     3.2106384634971619e-01
    z[8,9,3]  R2564     6.7443537712097168e-01
    z[8,9,3]  R2565     -1.7858897149562836e-01
    z[8,9,3]  R2566     -5.9162354469299316e-01
    z[8,9,3]  R2567     -6.4128756523132324e-01
    z[8,9,3]  R2568     2.7004736661911011e-01
    z[8,9,3]  R2569     -1.6026093065738678e-01
    z[8,9,3]  R2570     2.8299784660339355e-01
    z[8,9,3]  R2571     -3.7891450524330139e-01
    z[8,9,3]  R2572     4.3775388039648533e-03
    z[8,9,3]  R2573     -5.9918439388275146e-01
    z[8,9,3]  R2574     3.7036202847957611e-02
    z[8,9,3]  R2575     1.2741230428218842e-01
    z[8,9,3]  R2576     1.5791422128677368e-01
    z[8,9,3]  R2577     -4.3053078651428223e-01
    z[8,9,3]  R2578     -9.3980270624160767e-01
    z[8,9,3]  R2579     -5.1413238048553467e-01
    z[8,9,3]  R2580     -6.2300980091094971e-01
    z[8,9,3]  R2581     -4.6185851097106934e-01
    z[8,9,3]  R2582     -1.7539054155349731e-01
    z[8,9,3]  R2583     1.3005690276622772e-01
    z[8,9,3]  R2584     -2.9131261631846428e-02
    z[8,9,3]  R2585     1.1493502184748650e-02
    z[8,9,3]  R2586     -2.9282045364379883e-01
    z[8,9,3]  R2587     8.9619427919387817e-02
    z[8,9,3]  R2588     6.1843365430831909e-01
    z[8,9,3]  R2589     4.4111892580986023e-01
    z[8,9,3]  R2590     2.7013510465621948e-01
    z[8,9,3]  R2591     -7.9233951866626740e-02
    z[8,9,3]  R2592     2.0521600544452667e-01
    z[8,9,3]  R2593     -0.0388173945248127
    z[8,9,3]  R2594     2.7757605910301208e-01
    z[8,9,3]  R2595     1.4280018210411072e-01
    z[8,9,3]  R2596     1.9982960820198059e-01
    z[8,9,3]  R2597     2.0239561796188354e-01
    z[8,9,3]  R2598     -8.1577703356742859e-02
    z[8,9,3]  R2599     -4.0708336979150772e-02
    z[8,9,3]  R2600     6.0909765306860209e-04
    z[8,9,3]  R2601     -1.7282111942768097e-01
    z[8,9,3]  R2602     3.4197799861431122e-02
    z[8,9,3]  R2603     -5.0887301564216614e-02
    z[8,9,3]  R2604     -2.4098031222820282e-01
    z[8,9,3]  R2605     4.2497617006301880e-01
    z[8,9,3]  R2606     -9.6796251833438873e-02
    z[8,9,3]  R2607     1.9511635601520538e-01
    z[8,9,3]  R2608     1.8201845884323120e-01
    z[8,9,3]  R2609     1.9035039842128754e-01
    z[8,9,3]  R2610     1.9925527274608612e-02
    z[8,9,3]  R2611     2.2156937420368195e-01
    z[8,9,3]  R2612     -3.2070521265268326e-02
    z[8,9,3]  R2613     -3.7685963511466980e-01
    z[8,9,3]  R2614     3.5592874884605408e-01
    z[8,9,3]  R2615     3.8340842723846436e-01
    z[8,9,4]  R78       -1
    z[8,9,4]  R87       1
    z[8,9,4]  R2521     -1
    z[8,9,4]  R2522     1
    z[8,9,4]  R2527     -5.5894082784652710e-01
    z[8,9,4]  R2528     -2.3572048544883728e-01
    z[8,9,4]  R2529     -3.8936766982078552e-01
    z[8,9,4]  R2530     9.9085070192813873e-02
    z[8,9,4]  R2531     0.656181275844574
    z[8,9,4]  R2532     4.0824091434478760e-01
    z[8,9,4]  R2533     -2.9309365153312683e-01
    z[8,9,4]  R2534     -2.0477418601512909e-01
    z[8,9,4]  R2535     -5.3559523075819016e-02
    z[8,9,4]  R2536     3.5402661561965942e-01
    z[8,9,4]  R2537     -5.0177015364170074e-02
    z[8,9,4]  R2538     4.5993265509605408e-01
    z[8,9,4]  R2539     1.7349453270435333e-01
    z[8,9,4]  R2540     -2.1278150379657745e-01
    z[8,9,4]  R2541     1.9889779388904572e-01
    z[8,9,4]  R2542     9.2982076108455658e-02
    z[8,9,4]  R2543     3.0479785799980164e-01
    z[8,9,4]  R2544     2.0064502954483032e-01
    z[8,9,4]  R2545     1.7051550745964050e-01
    z[8,9,4]  R2546     2.2355923056602478e-01
    z[8,9,4]  R2547     3.4694934729486704e-03
    z[8,9,4]  R2548     -1.5218140557408333e-02
    z[8,9,4]  R2549     -1.9779246300458908e-02
    z[8,9,4]  R2550     -0.30018350481987
    z[8,9,4]  R2551     -3.7041577696800232e-01
    z[8,9,4]  R2552     0.285529762506485
    z[8,9,4]  R2553     -2.4301761388778687e-01
    z[8,9,4]  R2554     2.9491928219795227e-01
    z[8,9,4]  R2555     4.4511565566062927e-01
    z[8,9,4]  R2556     0.0792914554476738
    z[8,9,4]  R2557     4.6958619356155396e-01
    z[8,9,4]  R2558     2.1743603050708771e-01
    z[8,9,4]  R2559     3.6259678006172180e-01
    z[8,9,4]  R2560     -3.0477797612547874e-02
    z[8,9,4]  R2561     2.1184088289737701e-01
    z[8,9,4]  R2562     1.3928785920143127e-01
    z[8,9,4]  R2563     -2.4499006569385529e-02
    z[8,9,4]  R2564     3.6405530571937561e-01
    z[8,9,4]  R2565     -2.1614167839288712e-02
    z[8,9,4]  R2566     3.6386170983314514e-01
    z[8,9,4]  R2567     4.8812088370323181e-01
    z[8,9,4]  R2568     3.5133868455886841e-01
    z[8,9,4]  R2569     1.9273412227630615e-01
    z[8,9,4]  R2570     1.5269558131694794e-01
    z[8,9,4]  R2571     0.191655695438385
    z[8,9,4]  R2572     -4.9689346551895142e-01
    z[8,9,4]  R2573     -0.0610814169049263
    z[8,9,4]  R2574     1.5813528001308441e-01
    z[8,9,4]  R2575     1.6630642116069794e-01
    z[8,9,4]  R2576     -3.2762092351913452e-01
    z[8,9,4]  R2577     -3.2824802398681641e-01
    z[8,9,4]  R2578     -2.3531022667884827e-01
    z[8,9,4]  R2579     -8.2215756177902222e-02
    z[8,9,4]  R2580     -6.8515396118164062e-01
    z[8,9,4]  R2581     -2.2942136228084564e-01
    z[8,9,4]  R2582     4.9723929166793823e-01
    z[8,9,4]  R2583     2.4729619920253754e-01
    z[8,9,4]  R2584     -1.1167253553867340e-01
    z[8,9,4]  R2585     -3.6528801918029785e-01
    z[8,9,4]  R2586     1.5953122079372406e-01
    z[8,9,4]  R2587     4.1583743691444397e-01
    z[8,9,4]  R2588     -5.4390925168991089e-01
    z[8,9,4]  R2589     -9.9856853485107422e-02
    z[8,9,4]  R2590     -3.2047357410192490e-02
    z[8,9,4]  R2591     -9.3093447387218475e-02
    z[8,9,4]  R2592     1.0573543608188629e-01
    z[8,9,4]  R2593     1.9736097753047943e-01
    z[8,9,4]  R2594     1.5574443340301514e-01
    z[8,9,4]  R2595     5.8930486440658569e-02
    z[8,9,4]  R2596     -2.2155632078647614e-01
    z[8,9,4]  R2597     -1.8620832264423370e-01
    z[8,9,4]  R2598     -8.2071825861930847e-02
    z[8,9,4]  R2599     -7.1168504655361176e-02
    z[8,9,4]  R2600     1.1733083426952362e-01
    z[8,9,4]  R2601     2.0120418071746826e-01
    z[8,9,4]  R2602     3.0511077493429184e-02
    z[8,9,4]  R2603     3.6816290020942688e-01
    z[8,9,4]  R2604     3.6784145236015320e-01
    z[8,9,4]  R2605     7.4541878700256348e-01
    z[8,9,4]  R2606     -3.1434498727321625e-02
    z[8,9,4]  R2607     2.7726659551262856e-02
    z[8,9,4]  R2608     -2.1740216016769409e-01
    z[8,9,4]  R2609     -3.1457386910915375e-02
    z[8,9,4]  R2610     -1.2729303538799286e-01
    z[8,9,4]  R2611     1.9173143804073334e-01
    z[8,9,4]  R2612     3.3662948012351990e-01
    z[8,9,4]  R2613     1.8153899908065796e-01
    z[8,9,4]  R2614     0.685374915599823
    z[8,9,4]  R2615     6.6990822553634644e-01
    z[8,9,5]  R79       -1
    z[8,9,5]  R88       1
    z[8,9,5]  R2523     -1
    z[8,9,5]  R2524     1
    z[8,9,5]  R2527     -3.1899135559797287e-02
    z[8,9,5]  R2528     1.0000067949295044e-01
    z[8,9,5]  R2529     -1.7074528336524963e-01
    z[8,9,5]  R2530     -4.8373702913522720e-02
    z[8,9,5]  R2531     -1.9924034178256989e-01
    z[8,9,5]  R2532     6.7977467551827431e-03
    z[8,9,5]  R2533     -6.9073170423507690e-02
    z[8,9,5]  R2534     -5.7707138359546661e-02
    z[8,9,5]  R2535     -9.5456736162304878e-03
    z[8,9,5]  R2536     -6.4375180006027222e-01
    z[8,9,5]  R2537     5.1057100296020508e-01
    z[8,9,5]  R2538     9.1915823519229889e-02
    z[8,9,5]  R2539     -1.0320584289729595e-02
    z[8,9,5]  R2540     1.2849740684032440e-01
    z[8,9,5]  R2541     -3.7093784660100937e-02
    z[8,9,5]  R2542     -1.2073376774787903e-01
    z[8,9,5]  R2543     7.2403180599212646e-01
    z[8,9,5]  R2544     3.4957897663116455e-01
    z[8,9,5]  R2545     6.7242693901062012e-01
    z[8,9,5]  R2546     5.4841673374176025e-01
    z[8,9,5]  R2547     -4.7684319317340851e-02
    z[8,9,5]  R2548     -3.4641712903976440e-01
    z[8,9,5]  R2549     -2.5175441056489944e-02
    z[8,9,5]  R2550     4.0283703804016113e-01
    z[8,9,5]  R2551     5.8064728975296021e-01
    z[8,9,5]  R2552     6.5710562467575073e-01
    z[8,9,5]  R2553     -2.6476913690567017e-01
    z[8,9,5]  R2554     5.7118421792984009e-01
    z[8,9,5]  R2555     1.9922176003456116e-01
    z[8,9,5]  R2556     6.0836696624755859e-01
    z[8,9,5]  R2557     -2.1318690478801727e-01
    z[8,9,5]  R2558     4.8148801922798157e-01
    z[8,9,5]  R2559     0.000552017183508724
    z[8,9,5]  R2560     -5.3339886665344238e-01
    z[8,9,5]  R2561     4.3316060304641724e-01
    z[8,9,5]  R2562     3.7018787860870361e-01
    z[8,9,5]  R2563     3.0541330575942993e-01
    z[8,9,5]  R2564     5.6640452146530151e-01
    z[8,9,5]  R2565     8.3132719993591309e-01
    z[8,9,5]  R2566     3.5497869830578566e-03
    z[8,9,5]  R2567     3.1524743884801865e-02
    z[8,9,5]  R2568     5.4014086723327637e-01
    z[8,9,5]  R2569     1.7370861768722534e-01
    z[8,9,5]  R2570     8.1648379564285278e-02
    z[8,9,5]  R2571     4.9909746646881104e-01
    z[8,9,5]  R2572     4.5959451794624329e-01
    z[8,9,5]  R2573     -1.0670639574527740e-02
    z[8,9,5]  R2574     -5.2475303411483765e-01
    z[8,9,5]  R2575     -3.1629088521003723e-01
    z[8,9,5]  R2576     -5.7126820087432861e-01
    z[8,9,5]  R2577     -3.0798682570457458e-01
    z[8,9,5]  R2578     1.4860284328460693e-01
    z[8,9,5]  R2579     1.3143165409564972e-01
    z[8,9,5]  R2580     -4.7444548457860947e-02
    z[8,9,5]  R2581     3.9492752403020859e-02
    z[8,9,5]  R2582     1.9374240934848785e-01
    z[8,9,5]  R2583     1.3711906969547272e-01
    z[8,9,5]  R2584     -2.9747816920280457e-01
    z[8,9,5]  R2585     -4.3755255639553070e-02
    z[8,9,5]  R2586     -0.0848124623298645
    z[8,9,5]  R2587     2.2649076581001282e-01
    z[8,9,5]  R2588     3.8646966218948364e-01
    z[8,9,5]  R2589     -1.1627568304538727e-01
    z[8,9,5]  R2590     -6.1962295148987323e-05
    z[8,9,5]  R2591     1.3801721855998039e-02
    z[8,9,5]  R2592     -1.6287380456924438e-01
    z[8,9,5]  R2593     -2.6721358299255371e-01
    z[8,9,5]  R2594     1.9771657884120941e-01
    z[8,9,5]  R2595     -1.9833786785602570e-01
    z[8,9,5]  R2596     -2.3138357698917389e-01
    z[8,9,5]  R2597     7.0894765853881836e-01
    z[8,9,5]  R2598     -2.1792107820510864e-01
    z[8,9,5]  R2599     1.7922244966030121e-01
    z[8,9,5]  R2600     -1.1435023508965969e-02
    z[8,9,5]  R2601     -1.9206321239471436e-01
    z[8,9,5]  R2602     -1.3912537693977356e-01
    z[8,9,5]  R2603     1.3890877366065979e-01
    z[8,9,5]  R2604     3.0398979783058167e-01
    z[8,9,5]  R2605     2.2490348666906357e-02
    z[8,9,5]  R2606     5.2938252687454224e-01
    z[8,9,5]  R2607     1.2335211969912052e-02
    z[8,9,5]  R2608     -1.1504899710416794e-01
    z[8,9,5]  R2609     -1.7226109281182289e-02
    z[8,9,5]  R2610     1.8691466748714447e-01
    z[8,9,5]  R2611     4.3174274265766144e-02
    z[8,9,5]  R2612     6.5808288753032684e-02
    z[8,9,5]  R2613     1.3632968068122864e-01
    z[8,9,5]  R2614     -1.5600356459617615e-01
    z[8,9,5]  R2615     -2.0979729294776917e-01
    z[8,9,6]  R80       -1
    z[8,9,6]  R89       1
    z[8,9,6]  R2525     -1
    z[8,9,6]  R2526     1
    z[8,9,6]  R2527     3.1060501933097839e-01
    z[8,9,6]  R2528     5.6685513257980347e-01
    z[8,9,6]  R2529     -2.3149332404136658e-01
    z[8,9,6]  R2530     0.0737343579530716
    z[8,9,6]  R2531     1.9648127257823944e-01
    z[8,9,6]  R2532     -1.9989684224128723e-01
    z[8,9,6]  R2533     0.0941309928894043
    z[8,9,6]  R2534     -4.4072490930557251e-01
    z[8,9,6]  R2535     -5.0588476657867432e-01
    z[8,9,6]  R2536     -8.5069760680198669e-02
    z[8,9,6]  R2537     0.00797953736037016
    z[8,9,6]  R2538     -3.6925220489501953e-01
    z[8,9,6]  R2539     4.6424284577369690e-01
    z[8,9,6]  R2540     6.4075940847396851e-01
    z[8,9,6]  R2541     -3.4493547677993774e-01
    z[8,9,6]  R2542     8.6588621139526367e-02
    z[8,9,6]  R2543     -2.4086345732212067e-01
    z[8,9,6]  R2544     1.8434047698974609e-01
    z[8,9,6]  R2545     3.3821606636047363e-01
    z[8,9,6]  R2546     1.3408949971199036e-01
    z[8,9,6]  R2547     -2.2447763383388519e-01
    z[8,9,6]  R2548     6.6678076982498169e-02
    z[8,9,6]  R2549     4.2392125725746155e-01
    z[8,9,6]  R2550     1.4779888093471527e-01
    z[8,9,6]  R2551     -1.2012717127799988e-01
    z[8,9,6]  R2552     1.9500507414340973e-01
    z[8,9,6]  R2553     2.3942349851131439e-01
    z[8,9,6]  R2554     -1.2327600270509720e-01
    z[8,9,6]  R2555     -3.0668407678604126e-01
    z[8,9,6]  R2556     -2.5122725963592529e-01
    z[8,9,6]  R2557     -3.7140941619873047e-01
    z[8,9,6]  R2558     1.9923628866672516e-01
    z[8,9,6]  R2559     2.1036686375737190e-02
    z[8,9,6]  R2560     -1.1813435703516006e-01
    z[8,9,6]  R2561     -2.6810990646481514e-02
    z[8,9,6]  R2562     -1.9518600404262543e-01
    z[8,9,6]  R2563     2.0623704791069031e-01
    z[8,9,6]  R2564     1.0029902309179306e-01
    z[8,9,6]  R2565     -2.2265580296516418e-01
    z[8,9,6]  R2566     -1.0832364857196808e-01
    z[8,9,6]  R2567     7.1492679417133331e-02
    z[8,9,6]  R2568     2.7705797553062439e-01
    z[8,9,6]  R2569     -2.2224839031696320e-01
    z[8,9,6]  R2570     -2.0860308408737183e-01
    z[8,9,6]  R2571     6.1555508524179459e-02
    z[8,9,6]  R2572     9.8349370062351227e-02
    z[8,9,6]  R2573     1.7228952050209045e-01
    z[8,9,6]  R2574     -3.4487095475196838e-01
    z[8,9,6]  R2575     -4.1786277294158936e-01
    z[8,9,6]  R2576     -1.0108210891485214e-01
    z[8,9,6]  R2577     -2.0467959344387054e-01
    z[8,9,6]  R2578     1.7171584069728851e-01
    z[8,9,6]  R2579     3.3292478322982788e-01
    z[8,9,6]  R2580     1.5424039214849472e-02
    z[8,9,6]  R2581     5.0195235759019852e-02
    z[8,9,6]  R2582     -4.9056738615036011e-01
    z[8,9,6]  R2583     0.0674024224281311
    z[8,9,6]  R2584     -8.2106389105319977e-02
    z[8,9,6]  R2585     1.6777482815086842e-03
    z[8,9,6]  R2586     6.7161314189434052e-02
    z[8,9,6]  R2587     3.8654974102973938e-01
    z[8,9,6]  R2588     -1.0419576615095139e-01
    z[8,9,6]  R2589     1.7666088044643402e-01
    z[8,9,6]  R2590     1.2872123718261719e-01
    z[8,9,6]  R2591     9.6881859004497528e-02
    z[8,9,6]  R2592     2.2454324364662170e-01
    z[8,9,6]  R2593     -1.6983805224299431e-02
    z[8,9,6]  R2594     -1.0190619528293610e-01
    z[8,9,6]  R2595     -2.6259443163871765e-01
    z[8,9,6]  R2596     -2.7493588626384735e-02
    z[8,9,6]  R2597     4.3242105841636658e-01
    z[8,9,6]  R2598     1.8403728306293488e-01
    z[8,9,6]  R2599     -3.4229072928428650e-01
    z[8,9,6]  R2600     -2.5955277681350708e-01
    z[8,9,6]  R2601     -2.9613664746284485e-01
    z[8,9,6]  R2602     -1.6206017136573792e-01
    z[8,9,6]  R2603     1.3659252226352692e-01
    z[8,9,6]  R2604     -2.8309881687164307e-01
    z[8,9,6]  R2605     1.6889926046133041e-02
    z[8,9,6]  R2606     -6.4644539356231689e-01
    z[8,9,6]  R2607     -5.8095294237136841e-01
    z[8,9,6]  R2608     -1.4411937445402145e-02
    z[8,9,6]  R2609     -1.5400281548500061e-01
    z[8,9,6]  R2610     -1.2219013273715973e-01
    z[8,9,6]  R2611     1.5229758620262146e-01
    z[8,9,6]  R2612     0.218552827835083
    z[8,9,6]  R2613     -1.9323615729808807e-01
    z[8,9,6]  R2614     5.4894298315048218e-01
    z[8,9,6]  R2615     4.7479081153869629e-01
    z[9,8,0]  R74       1
    z[9,8,0]  R83       -1
    z[9,8,0]  R2616     -1
    z[9,8,0]  R2617     1
    z[9,8,0]  R2630     -1.1226820200681686e-01
    z[9,8,0]  R2631     -2.9766298830509186e-03
    z[9,8,0]  R2632     -5.9259835630655289e-02
    z[9,8,0]  R2633     -1.3733139634132385e-01
    z[9,8,0]  R2634     -1.6203567385673523e-02
    z[9,8,0]  R2635     -2.8471872210502625e-01
    z[9,8,0]  R2636     9.4680595397949219e-01
    z[9,8,0]  R2637     9.3098402023315430e-01
    z[9,8,0]  R2638     9.1860550642013550e-01
    z[9,8,0]  R2639     8.8751626014709473e-01
    z[9,8,0]  R2640     -6.1334443092346191e-01
    z[9,8,0]  R2641     -2.9817822575569153e-01
    z[9,8,0]  R2642     9.3357026576995850e-02
    z[9,8,0]  R2643     -1.1157221347093582e-01
    z[9,8,0]  R2644     -1.5873283147811890e-01
    z[9,8,0]  R2645     1.2745600193738937e-02
    z[9,8,0]  R2646     -2.2245932370424271e-02
    z[9,8,0]  R2647     -0.060992531478405
    z[9,8,0]  R2648     -1.1587447673082352e-01
    z[9,8,0]  R2649     -1.8560811877250671e-01
    z[9,8,0]  R2650     -4.2634120583534241e-01
    z[9,8,0]  R2651     -1.3205859065055847e-01
    z[9,8,0]  R2652     -0.000888276903424412
    z[9,8,0]  R2653     -1.3749279081821442e-01
    z[9,8,0]  R2654     -1.6728754341602325e-01
    z[9,8,0]  R2655     -8.9038275182247162e-02
    z[9,8,0]  R2656     -1.6110089421272278e-01
    z[9,8,0]  R2657     -1.5334102511405945e-01
    z[9,8,0]  R2658     -6.4253114163875580e-02
    z[9,8,0]  R2659     1.0551518946886063e-01
    z[9,8,0]  R2660     6.7918163537979126e-01
    z[9,8,0]  R2661     2.8729543089866638e-01
    z[9,8,0]  R2662     -8.0463126301765442e-02
    z[9,8,0]  R2663     -2.2232008632272482e-03
    z[9,8,0]  R2664     1.1726172268390656e-01
    z[9,8,0]  R2665     -1.7584471404552460e-01
    z[9,8,0]  R2666     -1.8058015406131744e-01
    z[9,8,0]  R2667     -7.9893134534358978e-02
    z[9,8,0]  R2668     -1.4695121347904205e-01
    z[9,8,0]  R2669     7.5502716004848480e-02
    z[9,8,0]  R2670     1.1088728159666061e-01
    z[9,8,0]  R2671     4.6042829751968384e-01
    z[9,8,0]  R2672     -4.7907486557960510e-02
    z[9,8,0]  R2673     -3.7452426552772522e-01
    z[9,8,0]  R2674     3.7386223673820496e-01
    z[9,8,0]  R2675     7.8686732053756714e-01
    z[9,8,0]  R2676     6.3473963737487793e-01
    z[9,8,0]  R2677     6.6608524322509766e-01
    z[9,8,0]  R2678     2.2632005810737610e-01
    z[9,8,0]  R2679     -1.8951016664505005e-01
    z[9,8,0]  R2680     1.8030634522438049e-01
    z[9,8,0]  R2681     -1.7487324774265289e-01
    z[9,8,0]  R2682     3.4759301692247391e-02
    z[9,8,0]  R2683     -1.9547063112258911e-01
    z[9,8,0]  R2684     1.5211117267608643e-01
    z[9,8,0]  R2685     8.7116084992885590e-02
    z[9,8,0]  R2686     -9.8972775042057037e-02
    z[9,8,0]  R2687     1.0068482719361782e-02
    z[9,8,0]  R2688     -8.6382992565631866e-02
    z[9,8,0]  R2689     -2.9037365317344666e-01
    z[9,8,0]  R2690     1.0343021899461746e-01
    z[9,8,0]  R2691     1.0587554425001144e-01
    z[9,8,0]  R2692     -7.3766030371189117e-02
    z[9,8,0]  R2693     2.1661940217018127e-01
    z[9,8,0]  R2694     2.9797169566154480e-01
    z[9,8,0]  R2695     1.5126696228981018e-01
    z[9,8,0]  R2696     2.0977418124675751e-01
    z[9,8,0]  R2697     -1.0889665782451630e-01
    z[9,8,0]  R2698     4.3689113855361938e-01
    z[9,8,0]  R2699     9.4676986336708069e-02
    z[9,8,0]  R2700     5.3207892179489136e-01
    z[9,8,0]  R2701     9.9957488477230072e-02
    z[9,8,0]  R2702     2.4007444083690643e-01
    z[9,8,0]  R2703     -1.1455266922712326e-01
    z[9,8,0]  R2704     1.6327553987503052e-01
    z[9,8,0]  R2705     -3.9882576093077660e-03
    z[9,8,0]  R2706     2.0957697927951813e-01
    z[9,8,0]  R2707     2.9569080471992493e-01
    z[9,8,0]  R2708     -8.5495337843894958e-03
    z[9,8,0]  R2709     -2.0459544658660889e-01
    z[9,8,0]  R2710     3.1395334005355835e-01
    z[9,8,0]  R2711     2.4114730954170227e-01
    z[9,8,0]  R2712     3.2360625267028809e-01
    z[9,8,0]  R2713     6.8792569637298584e-01
    z[9,8,0]  R2714     5.9601086378097534e-01
    z[9,8,0]  R2715     1.6062282025814056e-01
    z[9,8,0]  R2716     7.6208159327507019e-02
    z[9,8,0]  R2717     1.8776229023933411e-01
    z[9,8,0]  R2718     2.9219251871109009e-01
    z[9,8,1]  R75       1
    z[9,8,1]  R84       -1
    z[9,8,1]  R2618     -1
    z[9,8,1]  R2619     1
    z[9,8,1]  R2630     -0.0619843415915966
    z[9,8,1]  R2631     9.2010758817195892e-02
    z[9,8,1]  R2632     5.7703733444213867e-02
    z[9,8,1]  R2633     -1.2753465771675110e-01
    z[9,8,1]  R2634     -1.2947869300842285e-01
    z[9,8,1]  R2635     2.1319158375263214e-02
    z[9,8,1]  R2636     3.1947411596775055e-02
    z[9,8,1]  R2637     -1.4657779037952423e-01
    z[9,8,1]  R2638     -1.2175092846155167e-01
    z[9,8,1]  R2639     -1.3593797385692596e-01
    z[9,8,1]  R2640     4.0202805399894714e-01
    z[9,8,1]  R2641     1.7121504247188568e-01
    z[9,8,1]  R2642     8.6095374822616577e-01
    z[9,8,1]  R2643     -9.3606638908386230e-01
    z[9,8,1]  R2644     -9.4337177276611328e-01
    z[9,8,1]  R2645     -9.2986398935317993e-01
    z[9,8,1]  R2646     -9.3202722072601318e-01
    z[9,8,1]  R2647     -9.1925334930419922e-01
    z[9,8,1]  R2648     -9.1619348526000977e-01
    z[9,8,1]  R2649     -9.0627974271774292e-01
    z[9,8,1]  R2650     2.1944376826286316e-01
    z[9,8,1]  R2651     -6.3455426692962646e-01
    z[9,8,1]  R2652     -6.2975788116455078e-01
    z[9,8,1]  R2653     -0.53675377368927
    z[9,8,1]  R2654     -4.9162584543228149e-01
    z[9,8,1]  R2655     -4.4674062728881836e-01
    z[9,8,1]  R2656     -5.8175098896026611e-01
    z[9,8,1]  R2657     -4.9923619627952576e-01
    z[9,8,1]  R2658     -7.7833518385887146e-02
    z[9,8,1]  R2659     -5.4391577839851379e-02
    z[9,8,1]  R2660     -5.0886329263448715e-02
    z[9,8,1]  R2661     -3.9508793503046036e-02
    z[9,8,1]  R2662     -9.5183652639389038e-01
    z[9,8,1]  R2663     -9.5026838779449463e-01
    z[9,8,1]  R2664     -9.3119555711746216e-01
    z[9,8,1]  R2665     -8.8639110326766968e-01
    z[9,8,1]  R2666     -6.0358375310897827e-01
    z[9,8,1]  R2667     -2.6260793209075928e-01
    z[9,8,1]  R2668     -3.1257179379463196e-01
    z[9,8,1]  R2669     -1.1067306250333786e-01
    z[9,8,1]  R2670     -1.0375775396823883e-01
    z[9,8,1]  R2671     -1.3680014014244080e-01
    z[9,8,1]  R2672     -6.6274926066398621e-02
    z[9,8,1]  R2673     -8.4054440259933472e-02
    z[9,8,1]  R2674     -0.0701156035065651
    z[9,8,1]  R2675     -2.2179307416081429e-02
    z[9,8,1]  R2676     5.2454501390457153e-01
    z[9,8,1]  R2677     0.493733674287796
    z[9,8,1]  R2678     -5.9646263718605042e-02
    z[9,8,1]  R2679     -2.1950985491275787e-01
    z[9,8,1]  R2680     -4.4922783970832825e-01
    z[9,8,1]  R2681     8.3052909374237061e-01
    z[9,8,1]  R2682     6.8209058046340942e-01
    z[9,8,1]  R2683     -4.4528263807296753e-01
    z[9,8,1]  R2684     5.5602818727493286e-01
    z[9,8,1]  R2685     -9.5779865980148315e-02
    z[9,8,1]  R2686     -2.1436543762683868e-01
    z[9,8,1]  R2687     2.4146403372287750e-01
    z[9,8,1]  R2688     -2.3044308647513390e-02
    z[9,8,1]  R2689     -6.6871589422225952e-01
    z[9,8,1]  R2690     -3.9978951215744019e-01
    z[9,8,1]  R2691     -8.5582023859024048e-01
    z[9,8,1]  R2692     -7.2121411561965942e-01
    z[9,8,1]  R2693     -6.7721736431121826e-01
    z[9,8,1]  R2694     -5.3825116157531738e-01
    z[9,8,1]  R2695     6.8262583017349243e-01
    z[9,8,1]  R2696     6.5230381488800049e-01
    z[9,8,1]  R2697     5.9098637104034424e-01
    z[9,8,1]  R2698     3.7552586197853088e-01
    z[9,8,1]  R2699     7.5368750095367432e-01
    z[9,8,1]  R2700     -1.2656638026237488e-01
    z[9,8,1]  R2701     8.1298571825027466e-01
    z[9,8,1]  R2702     0.571906566619873
    z[9,8,1]  R2703     -0.194657102227211
    z[9,8,1]  R2704     5.4000097513198853e-01
    z[9,8,1]  R2705     6.7094784975051880e-01
    z[9,8,1]  R2706     1.6056393086910248e-01
    z[9,8,1]  R2707     3.6845106631517410e-02
    z[9,8,1]  R2708     6.9970452785491943e-01
    z[9,8,1]  R2709     -5.3066217899322510e-01
    z[9,8,1]  R2710     -4.5293325185775757e-01
    z[9,8,1]  R2711     8.5955935716629028e-01
    z[9,8,1]  R2712     8.4101319313049316e-01
    z[9,8,1]  R2713     -2.3749370872974396e-01
    z[9,8,1]  R2714     3.9434126019477844e-01
    z[9,8,1]  R2715     2.2372731566429138e-01
    z[9,8,1]  R2716     -5.1802724599838257e-01
    z[9,8,1]  R2717     -4.8616993427276611e-01
    z[9,8,1]  R2718     -5.2370971441268921e-01
    z[9,8,2]  R76       1
    z[9,8,2]  R85       -1
    z[9,8,2]  R2620     -1
    z[9,8,2]  R2621     1
    z[9,8,2]  R2630     -7.4411070346832275e-01
    z[9,8,2]  R2631     -3.6822758615016937e-02
    z[9,8,2]  R2632     -7.7068406343460083e-01
    z[9,8,2]  R2633     3.2374224066734314e-01
    z[9,8,2]  R2634     -8.4436124563217163e-01
    z[9,8,2]  R2635     -6.0189658403396606e-01
    z[9,8,2]  R2636     -3.3512271940708160e-02
    z[9,8,2]  R2637     0.0568292960524559
    z[9,8,2]  R2638     7.6525114476680756e-02
    z[9,8,2]  R2639     2.6634183526039124e-01
    z[9,8,2]  R2640     2.8374445438385010e-01
    z[9,8,2]  R2641     -2.0799554884433746e-01
    z[9,8,2]  R2642     2.7511257678270340e-02
    z[9,8,2]  R2643     1.4409109950065613e-01
    z[9,8,2]  R2644     2.4562698602676392e-01
    z[9,8,2]  R2645     7.0352025330066681e-02
    z[9,8,2]  R2646     1.3667736947536469e-01
    z[9,8,2]  R2647     2.1717865020036697e-02
    z[9,8,2]  R2648     1.2249117344617844e-01
    z[9,8,2]  R2649     2.9887804761528969e-02
    z[9,8,2]  R2650     6.9608017802238464e-02
    z[9,8,2]  R2651     6.9652813673019409e-01
    z[9,8,2]  R2652     6.6887855529785156e-01
    z[9,8,2]  R2653     7.8212898969650269e-01
    z[9,8,2]  R2654     7.3169898986816406e-01
    z[9,8,2]  R2655     8.6300361156463623e-01
    z[9,8,2]  R2656     6.7788320779800415e-01
    z[9,8,2]  R2657     6.0109579563140869e-01
    z[9,8,2]  R2658     5.0276088714599609e-01
    z[9,8,2]  R2659     5.2670013904571533e-01
    z[9,8,2]  R2660     -3.9953124523162842e-01
    z[9,8,2]  R2661     9.0667629241943359e-01
    z[9,8,2]  R2662     1.6216188669204712e-01
    z[9,8,2]  R2663     1.7469123005867004e-01
    z[9,8,2]  R2664     -0.0906200259923935
    z[9,8,2]  R2665     1.3017450273036957e-01
    z[9,8,2]  R2666     6.1005896329879761e-01
    z[9,8,2]  R2667     -5.0542913377285004e-02
    z[9,8,2]  R2668     1.2443476915359497e-01
    z[9,8,2]  R2669     3.7904572486877441e-01
    z[9,8,2]  R2670     3.7979254126548767e-01
    z[9,8,2]  R2671     3.2405778765678406e-01
    z[9,8,2]  R2672     2.1882160007953644e-01
    z[9,8,2]  R2673     3.9865878224372864e-01
    z[9,8,2]  R2674     2.0446313917636871e-01
    z[9,8,2]  R2675     5.1931917667388916e-01
    z[9,8,2]  R2676     2.7487581968307495e-01
    z[9,8,2]  R2677     -1.6449946165084839e-01
    z[9,8,2]  R2678     2.2594226896762848e-01
    z[9,8,2]  R2679     0.7100790143013
    z[9,8,2]  R2680     4.3023586273193359e-01
    z[9,8,2]  R2681     -4.8305816948413849e-02
    z[9,8,2]  R2682     -2.1928794682025909e-01
    z[9,8,2]  R2683     5.6980025768280029e-01
    z[9,8,2]  R2684     -0.0349474772810936
    z[9,8,2]  R2685     1.2344136089086533e-01
    z[9,8,2]  R2686     -2.3615586757659912e-01
    z[9,8,2]  R2687     8.0060847103595734e-02
    z[9,8,2]  R2688     -3.9585116505622864e-01
    z[9,8,2]  R2689     6.3608062267303467e-01
    z[9,8,2]  R2690     7.9112827777862549e-01
    z[9,8,2]  R2691     1.4244359731674194e-01
    z[9,8,2]  R2692     -2.0884594321250916e-01
    z[9,8,2]  R2693     -2.1701818332076073e-02
    z[9,8,2]  R2694     -9.9197268486022949e-02
    z[9,8,2]  R2695     5.0201827287673950e-01
    z[9,8,2]  R2696     -2.5773242115974426e-01
    z[9,8,2]  R2697     4.9454274773597717e-01
    z[9,8,2]  R2698     -2.9461485147476196e-01
    z[9,8,2]  R2699     1.1328115314245224e-01
    z[9,8,2]  R2700     0.539489209651947
    z[9,8,2]  R2701     -4.4375345110893250e-01
    z[9,8,2]  R2702     3.7113359570503235e-01
    z[9,8,2]  R2703     -0.0311265978962183
    z[9,8,2]  R2704     3.3781643956899643e-02
    z[9,8,2]  R2705     0.557063639163971
    z[9,8,2]  R2706     -1.0965149849653244e-01
    z[9,8,2]  R2707     3.7170931696891785e-01
    z[9,8,2]  R2708     -1.2720093131065369e-01
    z[9,8,2]  R2709     -1.4464257657527924e-01
    z[9,8,2]  R2710     0.362500935792923
    z[9,8,2]  R2711     2.4618411064147949e-01
    z[9,8,2]  R2712     1.8544629216194153e-01
    z[9,8,2]  R2713     1.9276790320873260e-01
    z[9,8,2]  R2714     -1.4643782377243042e-01
    z[9,8,2]  R2715     -7.2910618782043457e-01
    z[9,8,2]  R2716     -5.5241280794143677e-01
    z[9,8,2]  R2717     -6.4018994569778442e-01
    z[9,8,2]  R2718     -4.1414281725883484e-01
    z[9,8,3]  R77       1
    z[9,8,3]  R86       -1
    z[9,8,3]  R2622     -1
    z[9,8,3]  R2623     1
    z[9,8,3]  R2630     -4.3053078651428223e-01
    z[9,8,3]  R2631     -9.3980270624160767e-01
    z[9,8,3]  R2632     -5.1413238048553467e-01
    z[9,8,3]  R2633     -6.2300980091094971e-01
    z[9,8,3]  R2634     -4.6185851097106934e-01
    z[9,8,3]  R2635     -1.7539054155349731e-01
    z[9,8,3]  R2636     1.3005690276622772e-01
    z[9,8,3]  R2637     -2.9131261631846428e-02
    z[9,8,3]  R2638     1.1493502184748650e-02
    z[9,8,3]  R2639     -2.9282045364379883e-01
    z[9,8,3]  R2640     8.9619427919387817e-02
    z[9,8,3]  R2641     6.1843365430831909e-01
    z[9,8,3]  R2642     4.4111892580986023e-01
    z[9,8,3]  R2643     2.7013510465621948e-01
    z[9,8,3]  R2644     -7.9233951866626740e-02
    z[9,8,3]  R2645     2.0521600544452667e-01
    z[9,8,3]  R2646     -0.0388173945248127
    z[9,8,3]  R2647     2.7757605910301208e-01
    z[9,8,3]  R2648     1.4280018210411072e-01
    z[9,8,3]  R2649     1.9982960820198059e-01
    z[9,8,3]  R2650     2.0239561796188354e-01
    z[9,8,3]  R2651     -8.1577703356742859e-02
    z[9,8,3]  R2652     -4.0708336979150772e-02
    z[9,8,3]  R2653     6.0909765306860209e-04
    z[9,8,3]  R2654     -1.7282111942768097e-01
    z[9,8,3]  R2655     3.4197799861431122e-02
    z[9,8,3]  R2656     -5.0887301564216614e-02
    z[9,8,3]  R2657     -2.4098031222820282e-01
    z[9,8,3]  R2658     4.2497617006301880e-01
    z[9,8,3]  R2659     -9.6796251833438873e-02
    z[9,8,3]  R2660     1.9511635601520538e-01
    z[9,8,3]  R2661     1.8201845884323120e-01
    z[9,8,3]  R2662     1.9035039842128754e-01
    z[9,8,3]  R2663     1.9925527274608612e-02
    z[9,8,3]  R2664     2.2156937420368195e-01
    z[9,8,3]  R2665     -3.2070521265268326e-02
    z[9,8,3]  R2666     -3.7685963511466980e-01
    z[9,8,3]  R2667     3.5592874884605408e-01
    z[9,8,3]  R2668     3.8340842723846436e-01
    z[9,8,3]  R2669     -6.5457421541213989e-01
    z[9,8,3]  R2670     -6.6768777370452881e-01
    z[9,8,3]  R2671     -6.5568876266479492e-01
    z[9,8,3]  R2672     -9.6324187517166138e-01
    z[9,8,3]  R2673     -4.2995592951774597e-01
    z[9,8,3]  R2674     -0.778999388217926
    z[9,8,3]  R2675     -1.0544988512992859e-01
    z[9,8,3]  R2676     -8.3067983388900757e-02
    z[9,8,3]  R2677     -1.6315115988254547e-01
    z[9,8,3]  R2678     -0.58922278881073
    z[9,8,3]  R2679     3.8525944948196411e-01
    z[9,8,3]  R2680     4.7354760766029358e-01
    z[9,8,3]  R2681     1.7770472168922424e-01
    z[9,8,3]  R2682     1.1444151401519775e-01
    z[9,8,3]  R2683     5.2813404798507690e-01
    z[9,8,3]  R2684     7.9734158515930176e-01
    z[9,8,3]  R2685     5.4116570949554443e-01
    z[9,8,3]  R2686     8.3188760280609131e-01
    z[9,8,3]  R2687     0.582718014717102
    z[9,8,3]  R2688     6.8307328224182129e-01
    z[9,8,3]  R2689     -1.0596045106649399e-01
    z[9,8,3]  R2690     -2.8089922666549683e-01
    z[9,8,3]  R2691     2.3523949086666107e-01
    z[9,8,3]  R2692     -3.9567625522613525e-01
    z[9,8,3]  R2693     -7.2056323289871216e-02
    z[9,8,3]  R2694     -2.4559414386749268e-01
    z[9,8,3]  R2695     2.6950702071189880e-01
    z[9,8,3]  R2696     1.8879303336143494e-01
    z[9,8,3]  R2697     -2.4986344575881958e-01
    z[9,8,3]  R2698     3.7655803561210632e-01
    z[9,8,3]  R2699     -7.9082868993282318e-02
    z[9,8,3]  R2700     3.0169525742530823e-01
    z[9,8,3]  R2701     1.5044022351503372e-02
    z[9,8,3]  R2702     4.2207580804824829e-01
    z[9,8,3]  R2703     8.4545487165451050e-01
    z[9,8,3]  R2704     -6.9718080759048462e-01
    z[9,8,3]  R2705     3.2106384634971619e-01
    z[9,8,3]  R2706     6.7443537712097168e-01
    z[9,8,3]  R2707     -1.7858897149562836e-01
    z[9,8,3]  R2708     -5.9162354469299316e-01
    z[9,8,3]  R2709     -6.4128756523132324e-01
    z[9,8,3]  R2710     2.7004736661911011e-01
    z[9,8,3]  R2711     -1.6026093065738678e-01
    z[9,8,3]  R2712     2.8299784660339355e-01
    z[9,8,3]  R2713     -3.7891450524330139e-01
    z[9,8,3]  R2714     4.3775388039648533e-03
    z[9,8,3]  R2715     -5.9918439388275146e-01
    z[9,8,3]  R2716     3.7036202847957611e-02
    z[9,8,3]  R2717     1.2741230428218842e-01
    z[9,8,3]  R2718     1.5791422128677368e-01
    z[9,8,4]  R78       1
    z[9,8,4]  R87       -1
    z[9,8,4]  R2624     -1
    z[9,8,4]  R2625     1
    z[9,8,4]  R2630     -3.2824802398681641e-01
    z[9,8,4]  R2631     -2.3531022667884827e-01
    z[9,8,4]  R2632     -8.2215756177902222e-02
    z[9,8,4]  R2633     -6.8515396118164062e-01
    z[9,8,4]  R2634     -2.2942136228084564e-01
    z[9,8,4]  R2635     4.9723929166793823e-01
    z[9,8,4]  R2636     2.4729619920253754e-01
    z[9,8,4]  R2637     -1.1167253553867340e-01
    z[9,8,4]  R2638     -3.6528801918029785e-01
    z[9,8,4]  R2639     1.5953122079372406e-01
    z[9,8,4]  R2640     4.1583743691444397e-01
    z[9,8,4]  R2641     -5.4390925168991089e-01
    z[9,8,4]  R2642     -9.9856853485107422e-02
    z[9,8,4]  R2643     -3.2047357410192490e-02
    z[9,8,4]  R2644     -9.3093447387218475e-02
    z[9,8,4]  R2645     1.0573543608188629e-01
    z[9,8,4]  R2646     1.9736097753047943e-01
    z[9,8,4]  R2647     1.5574443340301514e-01
    z[9,8,4]  R2648     5.8930486440658569e-02
    z[9,8,4]  R2649     -2.2155632078647614e-01
    z[9,8,4]  R2650     -1.8620832264423370e-01
    z[9,8,4]  R2651     -8.2071825861930847e-02
    z[9,8,4]  R2652     -7.1168504655361176e-02
    z[9,8,4]  R2653     1.1733083426952362e-01
    z[9,8,4]  R2654     2.0120418071746826e-01
    z[9,8,4]  R2655     3.0511077493429184e-02
    z[9,8,4]  R2656     3.6816290020942688e-01
    z[9,8,4]  R2657     3.6784145236015320e-01
    z[9,8,4]  R2658     7.4541878700256348e-01
    z[9,8,4]  R2659     -3.1434498727321625e-02
    z[9,8,4]  R2660     2.7726659551262856e-02
    z[9,8,4]  R2661     -2.1740216016769409e-01
    z[9,8,4]  R2662     -3.1457386910915375e-02
    z[9,8,4]  R2663     -1.2729303538799286e-01
    z[9,8,4]  R2664     1.9173143804073334e-01
    z[9,8,4]  R2665     3.3662948012351990e-01
    z[9,8,4]  R2666     1.8153899908065796e-01
    z[9,8,4]  R2667     0.685374915599823
    z[9,8,4]  R2668     6.6990822553634644e-01
    z[9,8,4]  R2669     -5.5894082784652710e-01
    z[9,8,4]  R2670     -2.3572048544883728e-01
    z[9,8,4]  R2671     -3.8936766982078552e-01
    z[9,8,4]  R2672     9.9085070192813873e-02
    z[9,8,4]  R2673     0.656181275844574
    z[9,8,4]  R2674     4.0824091434478760e-01
    z[9,8,4]  R2675     -2.9309365153312683e-01
    z[9,8,4]  R2676     -2.0477418601512909e-01
    z[9,8,4]  R2677     -5.3559523075819016e-02
    z[9,8,4]  R2678     3.5402661561965942e-01
    z[9,8,4]  R2679     -5.0177015364170074e-02
    z[9,8,4]  R2680     4.5993265509605408e-01
    z[9,8,4]  R2681     1.7349453270435333e-01
    z[9,8,4]  R2682     -2.1278150379657745e-01
    z[9,8,4]  R2683     1.9889779388904572e-01
    z[9,8,4]  R2684     9.2982076108455658e-02
    z[9,8,4]  R2685     3.0479785799980164e-01
    z[9,8,4]  R2686     2.0064502954483032e-01
    z[9,8,4]  R2687     1.7051550745964050e-01
    z[9,8,4]  R2688     2.2355923056602478e-01
    z[9,8,4]  R2689     3.4694934729486704e-03
    z[9,8,4]  R2690     -1.5218140557408333e-02
    z[9,8,4]  R2691     -1.9779246300458908e-02
    z[9,8,4]  R2692     -0.30018350481987
    z[9,8,4]  R2693     -3.7041577696800232e-01
    z[9,8,4]  R2694     0.285529762506485
    z[9,8,4]  R2695     -2.4301761388778687e-01
    z[9,8,4]  R2696     2.9491928219795227e-01
    z[9,8,4]  R2697     4.4511565566062927e-01
    z[9,8,4]  R2698     0.0792914554476738
    z[9,8,4]  R2699     4.6958619356155396e-01
    z[9,8,4]  R2700     2.1743603050708771e-01
    z[9,8,4]  R2701     3.6259678006172180e-01
    z[9,8,4]  R2702     -3.0477797612547874e-02
    z[9,8,4]  R2703     2.1184088289737701e-01
    z[9,8,4]  R2704     1.3928785920143127e-01
    z[9,8,4]  R2705     -2.4499006569385529e-02
    z[9,8,4]  R2706     3.6405530571937561e-01
    z[9,8,4]  R2707     -2.1614167839288712e-02
    z[9,8,4]  R2708     3.6386170983314514e-01
    z[9,8,4]  R2709     4.8812088370323181e-01
    z[9,8,4]  R2710     3.5133868455886841e-01
    z[9,8,4]  R2711     1.9273412227630615e-01
    z[9,8,4]  R2712     1.5269558131694794e-01
    z[9,8,4]  R2713     0.191655695438385
    z[9,8,4]  R2714     -4.9689346551895142e-01
    z[9,8,4]  R2715     -0.0610814169049263
    z[9,8,4]  R2716     1.5813528001308441e-01
    z[9,8,4]  R2717     1.6630642116069794e-01
    z[9,8,4]  R2718     -3.2762092351913452e-01
    z[9,8,5]  R79       1
    z[9,8,5]  R88       -1
    z[9,8,5]  R2626     -1
    z[9,8,5]  R2627     1
    z[9,8,5]  R2630     -3.0798682570457458e-01
    z[9,8,5]  R2631     1.4860284328460693e-01
    z[9,8,5]  R2632     1.3143165409564972e-01
    z[9,8,5]  R2633     -4.7444548457860947e-02
    z[9,8,5]  R2634     3.9492752403020859e-02
    z[9,8,5]  R2635     1.9374240934848785e-01
    z[9,8,5]  R2636     1.3711906969547272e-01
    z[9,8,5]  R2637     -2.9747816920280457e-01
    z[9,8,5]  R2638     -4.3755255639553070e-02
    z[9,8,5]  R2639     -0.0848124623298645
    z[9,8,5]  R2640     2.2649076581001282e-01
    z[9,8,5]  R2641     3.8646966218948364e-01
    z[9,8,5]  R2642     -1.1627568304538727e-01
    z[9,8,5]  R2643     -6.1962295148987323e-05
    z[9,8,5]  R2644     1.3801721855998039e-02
    z[9,8,5]  R2645     -1.6287380456924438e-01
    z[9,8,5]  R2646     -2.6721358299255371e-01
    z[9,8,5]  R2647     1.9771657884120941e-01
    z[9,8,5]  R2648     -1.9833786785602570e-01
    z[9,8,5]  R2649     -2.3138357698917389e-01
    z[9,8,5]  R2650     7.0894765853881836e-01
    z[9,8,5]  R2651     -2.1792107820510864e-01
    z[9,8,5]  R2652     1.7922244966030121e-01
    z[9,8,5]  R2653     -1.1435023508965969e-02
    z[9,8,5]  R2654     -1.9206321239471436e-01
    z[9,8,5]  R2655     -1.3912537693977356e-01
    z[9,8,5]  R2656     1.3890877366065979e-01
    z[9,8,5]  R2657     3.0398979783058167e-01
    z[9,8,5]  R2658     2.2490348666906357e-02
    z[9,8,5]  R2659     5.2938252687454224e-01
    z[9,8,5]  R2660     1.2335211969912052e-02
    z[9,8,5]  R2661     -1.1504899710416794e-01
    z[9,8,5]  R2662     -1.7226109281182289e-02
    z[9,8,5]  R2663     1.8691466748714447e-01
    z[9,8,5]  R2664     4.3174274265766144e-02
    z[9,8,5]  R2665     6.5808288753032684e-02
    z[9,8,5]  R2666     1.3632968068122864e-01
    z[9,8,5]  R2667     -1.5600356459617615e-01
    z[9,8,5]  R2668     -2.0979729294776917e-01
    z[9,8,5]  R2669     -3.1899135559797287e-02
    z[9,8,5]  R2670     1.0000067949295044e-01
    z[9,8,5]  R2671     -1.7074528336524963e-01
    z[9,8,5]  R2672     -4.8373702913522720e-02
    z[9,8,5]  R2673     -1.9924034178256989e-01
    z[9,8,5]  R2674     6.7977467551827431e-03
    z[9,8,5]  R2675     -6.9073170423507690e-02
    z[9,8,5]  R2676     -5.7707138359546661e-02
    z[9,8,5]  R2677     -9.5456736162304878e-03
    z[9,8,5]  R2678     -6.4375180006027222e-01
    z[9,8,5]  R2679     5.1057100296020508e-01
    z[9,8,5]  R2680     9.1915823519229889e-02
    z[9,8,5]  R2681     -1.0320584289729595e-02
    z[9,8,5]  R2682     1.2849740684032440e-01
    z[9,8,5]  R2683     -3.7093784660100937e-02
    z[9,8,5]  R2684     -1.2073376774787903e-01
    z[9,8,5]  R2685     7.2403180599212646e-01
    z[9,8,5]  R2686     3.4957897663116455e-01
    z[9,8,5]  R2687     6.7242693901062012e-01
    z[9,8,5]  R2688     5.4841673374176025e-01
    z[9,8,5]  R2689     -4.7684319317340851e-02
    z[9,8,5]  R2690     -3.4641712903976440e-01
    z[9,8,5]  R2691     -2.5175441056489944e-02
    z[9,8,5]  R2692     4.0283703804016113e-01
    z[9,8,5]  R2693     5.8064728975296021e-01
    z[9,8,5]  R2694     6.5710562467575073e-01
    z[9,8,5]  R2695     -2.6476913690567017e-01
    z[9,8,5]  R2696     5.7118421792984009e-01
    z[9,8,5]  R2697     1.9922176003456116e-01
    z[9,8,5]  R2698     6.0836696624755859e-01
    z[9,8,5]  R2699     -2.1318690478801727e-01
    z[9,8,5]  R2700     4.8148801922798157e-01
    z[9,8,5]  R2701     0.000552017183508724
    z[9,8,5]  R2702     -5.3339886665344238e-01
    z[9,8,5]  R2703     4.3316060304641724e-01
    z[9,8,5]  R2704     3.7018787860870361e-01
    z[9,8,5]  R2705     3.0541330575942993e-01
    z[9,8,5]  R2706     5.6640452146530151e-01
    z[9,8,5]  R2707     8.3132719993591309e-01
    z[9,8,5]  R2708     3.5497869830578566e-03
    z[9,8,5]  R2709     3.1524743884801865e-02
    z[9,8,5]  R2710     5.4014086723327637e-01
    z[9,8,5]  R2711     1.7370861768722534e-01
    z[9,8,5]  R2712     8.1648379564285278e-02
    z[9,8,5]  R2713     4.9909746646881104e-01
    z[9,8,5]  R2714     4.5959451794624329e-01
    z[9,8,5]  R2715     -1.0670639574527740e-02
    z[9,8,5]  R2716     -5.2475303411483765e-01
    z[9,8,5]  R2717     -3.1629088521003723e-01
    z[9,8,5]  R2718     -5.7126820087432861e-01
    z[9,8,6]  R80       1
    z[9,8,6]  R89       -1
    z[9,8,6]  R2628     -1
    z[9,8,6]  R2629     1
    z[9,8,6]  R2630     -2.0467959344387054e-01
    z[9,8,6]  R2631     1.7171584069728851e-01
    z[9,8,6]  R2632     3.3292478322982788e-01
    z[9,8,6]  R2633     1.5424039214849472e-02
    z[9,8,6]  R2634     5.0195235759019852e-02
    z[9,8,6]  R2635     -4.9056738615036011e-01
    z[9,8,6]  R2636     0.0674024224281311
    z[9,8,6]  R2637     -8.2106389105319977e-02
    z[9,8,6]  R2638     1.6777482815086842e-03
    z[9,8,6]  R2639     6.7161314189434052e-02
    z[9,8,6]  R2640     3.8654974102973938e-01
    z[9,8,6]  R2641     -1.0419576615095139e-01
    z[9,8,6]  R2642     1.7666088044643402e-01
    z[9,8,6]  R2643     1.2872123718261719e-01
    z[9,8,6]  R2644     9.6881859004497528e-02
    z[9,8,6]  R2645     2.2454324364662170e-01
    z[9,8,6]  R2646     -1.6983805224299431e-02
    z[9,8,6]  R2647     -1.0190619528293610e-01
    z[9,8,6]  R2648     -2.6259443163871765e-01
    z[9,8,6]  R2649     -2.7493588626384735e-02
    z[9,8,6]  R2650     4.3242105841636658e-01
    z[9,8,6]  R2651     1.8403728306293488e-01
    z[9,8,6]  R2652     -3.4229072928428650e-01
    z[9,8,6]  R2653     -2.5955277681350708e-01
    z[9,8,6]  R2654     -2.9613664746284485e-01
    z[9,8,6]  R2655     -1.6206017136573792e-01
    z[9,8,6]  R2656     1.3659252226352692e-01
    z[9,8,6]  R2657     -2.8309881687164307e-01
    z[9,8,6]  R2658     1.6889926046133041e-02
    z[9,8,6]  R2659     -6.4644539356231689e-01
    z[9,8,6]  R2660     -5.8095294237136841e-01
    z[9,8,6]  R2661     -1.4411937445402145e-02
    z[9,8,6]  R2662     -1.5400281548500061e-01
    z[9,8,6]  R2663     -1.2219013273715973e-01
    z[9,8,6]  R2664     1.5229758620262146e-01
    z[9,8,6]  R2665     0.218552827835083
    z[9,8,6]  R2666     -1.9323615729808807e-01
    z[9,8,6]  R2667     5.4894298315048218e-01
    z[9,8,6]  R2668     4.7479081153869629e-01
    z[9,8,6]  R2669     3.1060501933097839e-01
    z[9,8,6]  R2670     5.6685513257980347e-01
    z[9,8,6]  R2671     -2.3149332404136658e-01
    z[9,8,6]  R2672     0.0737343579530716
    z[9,8,6]  R2673     1.9648127257823944e-01
    z[9,8,6]  R2674     -1.9989684224128723e-01
    z[9,8,6]  R2675     0.0941309928894043
    z[9,8,6]  R2676     -4.4072490930557251e-01
    z[9,8,6]  R2677     -5.0588476657867432e-01
    z[9,8,6]  R2678     -8.5069760680198669e-02
    z[9,8,6]  R2679     0.00797953736037016
    z[9,8,6]  R2680     -3.6925220489501953e-01
    z[9,8,6]  R2681     4.6424284577369690e-01
    z[9,8,6]  R2682     6.4075940847396851e-01
    z[9,8,6]  R2683     -3.4493547677993774e-01
    z[9,8,6]  R2684     8.6588621139526367e-02
    z[9,8,6]  R2685     -2.4086345732212067e-01
    z[9,8,6]  R2686     1.8434047698974609e-01
    z[9,8,6]  R2687     3.3821606636047363e-01
    z[9,8,6]  R2688     1.3408949971199036e-01
    z[9,8,6]  R2689     -2.2447763383388519e-01
    z[9,8,6]  R2690     6.6678076982498169e-02
    z[9,8,6]  R2691     4.2392125725746155e-01
    z[9,8,6]  R2692     1.4779888093471527e-01
    z[9,8,6]  R2693     -1.2012717127799988e-01
    z[9,8,6]  R2694     1.9500507414340973e-01
    z[9,8,6]  R2695     2.3942349851131439e-01
    z[9,8,6]  R2696     -1.2327600270509720e-01
    z[9,8,6]  R2697     -3.0668407678604126e-01
    z[9,8,6]  R2698     -2.5122725963592529e-01
    z[9,8,6]  R2699     -3.7140941619873047e-01
    z[9,8,6]  R2700     1.9923628866672516e-01
    z[9,8,6]  R2701     2.1036686375737190e-02
    z[9,8,6]  R2702     -1.1813435703516006e-01
    z[9,8,6]  R2703     -2.6810990646481514e-02
    z[9,8,6]  R2704     -1.9518600404262543e-01
    z[9,8,6]  R2705     2.0623704791069031e-01
    z[9,8,6]  R2706     1.0029902309179306e-01
    z[9,8,6]  R2707     -2.2265580296516418e-01
    z[9,8,6]  R2708     -1.0832364857196808e-01
    z[9,8,6]  R2709     7.1492679417133331e-02
    z[9,8,6]  R2710     2.7705797553062439e-01
    z[9,8,6]  R2711     -2.2224839031696320e-01
    z[9,8,6]  R2712     -2.0860308408737183e-01
    z[9,8,6]  R2713     6.1555508524179459e-02
    z[9,8,6]  R2714     9.8349370062351227e-02
    z[9,8,6]  R2715     1.7228952050209045e-01
    z[9,8,6]  R2716     -3.4487095475196838e-01
    z[9,8,6]  R2717     -4.1786277294158936e-01
    z[9,8,6]  R2718     -1.0108210891485214e-01
    z[9,10,0]  R83       -1
    z[9,10,0]  R92       1
    z[9,10,0]  R2719     -1
    z[9,10,0]  R2720     1
    z[9,10,0]  R2733     -1.1226820200681686e-01
    z[9,10,0]  R2734     -2.9766298830509186e-03
    z[9,10,0]  R2735     -5.9259835630655289e-02
    z[9,10,0]  R2736     -1.3733139634132385e-01
    z[9,10,0]  R2737     -1.6203567385673523e-02
    z[9,10,0]  R2738     -2.8471872210502625e-01
    z[9,10,0]  R2739     9.4680595397949219e-01
    z[9,10,0]  R2740     9.3098402023315430e-01
    z[9,10,0]  R2741     9.1860550642013550e-01
    z[9,10,0]  R2742     8.8751626014709473e-01
    z[9,10,0]  R2743     -6.1334443092346191e-01
    z[9,10,0]  R2744     -2.9817822575569153e-01
    z[9,10,0]  R2745     9.3357026576995850e-02
    z[9,10,0]  R2746     -1.1157221347093582e-01
    z[9,10,0]  R2747     -1.5873283147811890e-01
    z[9,10,0]  R2748     1.2745600193738937e-02
    z[9,10,0]  R2749     -2.2245932370424271e-02
    z[9,10,0]  R2750     -0.060992531478405
    z[9,10,0]  R2751     -1.1587447673082352e-01
    z[9,10,0]  R2752     -1.8560811877250671e-01
    z[9,10,0]  R2753     -4.2634120583534241e-01
    z[9,10,0]  R2754     -1.3205859065055847e-01
    z[9,10,0]  R2755     -0.000888276903424412
    z[9,10,0]  R2756     -1.3749279081821442e-01
    z[9,10,0]  R2757     -1.6728754341602325e-01
    z[9,10,0]  R2758     -8.9038275182247162e-02
    z[9,10,0]  R2759     -1.6110089421272278e-01
    z[9,10,0]  R2760     -1.5334102511405945e-01
    z[9,10,0]  R2761     -6.4253114163875580e-02
    z[9,10,0]  R2762     1.0551518946886063e-01
    z[9,10,0]  R2763     6.7918163537979126e-01
    z[9,10,0]  R2764     2.8729543089866638e-01
    z[9,10,0]  R2765     -8.0463126301765442e-02
    z[9,10,0]  R2766     -2.2232008632272482e-03
    z[9,10,0]  R2767     1.1726172268390656e-01
    z[9,10,0]  R2768     -1.7584471404552460e-01
    z[9,10,0]  R2769     -1.8058015406131744e-01
    z[9,10,0]  R2770     -7.9893134534358978e-02
    z[9,10,0]  R2771     -1.4695121347904205e-01
    z[9,10,0]  R2772     -0.0322338342666626
    z[9,10,0]  R2773     -3.8929153233766556e-02
    z[9,10,0]  R2774     -2.8456223011016846e-01
    z[9,10,0]  R2775     -9.5431968569755554e-02
    z[9,10,0]  R2776     4.8519930243492126e-01
    z[9,10,0]  R2777     2.9040375351905823e-01
    z[9,10,0]  R2778     6.2423527240753174e-01
    z[9,10,0]  R2779     0.68561190366745
    z[9,10,0]  R2780     3.9377138018608093e-01
    z[9,10,0]  R2781     4.7939980030059814e-01
    z[9,10,0]  R2782     -1.3835345208644867e-01
    z[9,10,0]  R2783     -2.6231449842453003e-01
    z[9,10,0]  R2784     -8.1875901669263840e-03
    z[9,10,0]  R2785     -7.8163832426071167e-01
    z[9,10,0]  R2786     -4.8524963855743408e-01
    z[9,10,0]  R2787     7.1659278869628906e-01
    z[9,10,0]  R2788     4.5273523777723312e-02
    z[9,10,0]  R2789     -4.5310713350772858e-02
    z[9,10,0]  R2790     6.3448154926300049e-01
    z[9,10,0]  R2791     3.3574381470680237e-01
    z[9,10,0]  R2792     -7.6139461994171143e-01
    z[9,10,0]  R2793     -7.8718638420104980e-01
    z[9,10,0]  R2794     -5.9369087219238281e-01
    z[9,10,0]  R2795     -5.3711426258087158e-01
    z[9,10,0]  R2796     1.0929322987794876e-01
    z[9,10,0]  R2797     2.8275832533836365e-01
    z[9,10,0]  R2798     7.5258262455463409e-02
    z[9,10,0]  R2799     5.1826828718185425e-01
    z[9,10,0]  R2800     8.6387908458709717e-01
    z[9,10,0]  R2801     2.2995744645595551e-01
    z[9,10,0]  R2802     -4.4182431697845459e-01
    z[9,10,0]  R2803     -4.4682115316390991e-01
    z[9,10,0]  R2804     -2.6626887917518616e-01
    z[9,10,0]  R2805     -2.6983499526977539e-01
    z[9,10,0]  R2806     -2.8977537155151367e-01
    z[9,10,0]  R2807     1.8678304553031921e-01
    z[9,10,0]  R2808     1.8696199357509613e-01
    z[9,10,0]  R2809     3.3619109541177750e-02
    z[9,10,0]  R2810     5.5952310562133789e-01
    z[9,10,0]  R2811     9.2262578010559082e-01
    z[9,10,1]  R84       -1
    z[9,10,1]  R93       1
    z[9,10,1]  R2721     -1
    z[9,10,1]  R2722     1
    z[9,10,1]  R2733     -0.0619843415915966
    z[9,10,1]  R2734     9.2010758817195892e-02
    z[9,10,1]  R2735     5.7703733444213867e-02
    z[9,10,1]  R2736     -1.2753465771675110e-01
    z[9,10,1]  R2737     -1.2947869300842285e-01
    z[9,10,1]  R2738     2.1319158375263214e-02
    z[9,10,1]  R2739     3.1947411596775055e-02
    z[9,10,1]  R2740     -1.4657779037952423e-01
    z[9,10,1]  R2741     -1.2175092846155167e-01
    z[9,10,1]  R2742     -1.3593797385692596e-01
    z[9,10,1]  R2743     4.0202805399894714e-01
    z[9,10,1]  R2744     1.7121504247188568e-01
    z[9,10,1]  R2745     8.6095374822616577e-01
    z[9,10,1]  R2746     -9.3606638908386230e-01
    z[9,10,1]  R2747     -9.4337177276611328e-01
    z[9,10,1]  R2748     -9.2986398935317993e-01
    z[9,10,1]  R2749     -9.3202722072601318e-01
    z[9,10,1]  R2750     -9.1925334930419922e-01
    z[9,10,1]  R2751     -9.1619348526000977e-01
    z[9,10,1]  R2752     -9.0627974271774292e-01
    z[9,10,1]  R2753     2.1944376826286316e-01
    z[9,10,1]  R2754     -6.3455426692962646e-01
    z[9,10,1]  R2755     -6.2975788116455078e-01
    z[9,10,1]  R2756     -0.53675377368927
    z[9,10,1]  R2757     -4.9162584543228149e-01
    z[9,10,1]  R2758     -4.4674062728881836e-01
    z[9,10,1]  R2759     -5.8175098896026611e-01
    z[9,10,1]  R2760     -4.9923619627952576e-01
    z[9,10,1]  R2761     -7.7833518385887146e-02
    z[9,10,1]  R2762     -5.4391577839851379e-02
    z[9,10,1]  R2763     -5.0886329263448715e-02
    z[9,10,1]  R2764     -3.9508793503046036e-02
    z[9,10,1]  R2765     -9.5183652639389038e-01
    z[9,10,1]  R2766     -9.5026838779449463e-01
    z[9,10,1]  R2767     -9.3119555711746216e-01
    z[9,10,1]  R2768     -8.8639110326766968e-01
    z[9,10,1]  R2769     -6.0358375310897827e-01
    z[9,10,1]  R2770     -2.6260793209075928e-01
    z[9,10,1]  R2771     -3.1257179379463196e-01
    z[9,10,1]  R2772     5.9495024383068085e-02
    z[9,10,1]  R2773     -1.7787255346775055e-01
    z[9,10,1]  R2774     -3.7116494774818420e-01
    z[9,10,1]  R2775     2.7456842362880707e-02
    z[9,10,1]  R2776     5.0318706035614014e-01
    z[9,10,1]  R2777     2.7592509984970093e-01
    z[9,10,1]  R2778     1.3301257789134979e-01
    z[9,10,1]  R2779     1.5204125642776489e-01
    z[9,10,1]  R2780     4.5381143689155579e-01
    z[9,10,1]  R2781     3.1715300679206848e-01
    z[9,10,1]  R2782     -5.4111443459987640e-02
    z[9,10,1]  R2783     -3.6944654583930969e-01
    z[9,10,1]  R2784     8.8989585638046265e-01
    z[9,10,1]  R2785     -1.0060093551874161e-01
    z[9,10,1]  R2786     4.9054840207099915e-01
    z[9,10,1]  R2787     -3.6201146245002747e-01
    z[9,10,1]  R2788     3.4500020742416382e-01
    z[9,10,1]  R2789     7.2072863578796387e-01
    z[9,10,1]  R2790     4.4959199428558350e-01
    z[9,10,1]  R2791     5.7441401481628418e-01
    z[9,10,1]  R2792     -1.9486187398433685e-01
    z[9,10,1]  R2793     2.4525374174118042e-01
    z[9,10,1]  R2794     5.0622463226318359e-01
    z[9,10,1]  R2795     -5.3992480039596558e-01
    z[9,10,1]  R2796     4.0347132086753845e-01
    z[9,10,1]  R2797     3.0033415555953979e-01
    z[9,10,1]  R2798     4.7502881288528442e-01
    z[9,10,1]  R2799     5.4198604822158813e-01
    z[9,10,1]  R2800     9.3117982149124146e-02
    z[9,10,1]  R2801     5.5350724607706070e-02
    z[9,10,1]  R2802     -6.3070565462112427e-01
    z[9,10,1]  R2803     0.666795015335083
    z[9,10,1]  R2804     2.4894419312477112e-01
    z[9,10,1]  R2805     5.1834475994110107e-01
    z[9,10,1]  R2806     0.744705855846405
    z[9,10,1]  R2807     0.777864396572113
    z[9,10,1]  R2808     4.4287830591201782e-01
    z[9,10,1]  R2809     3.9503553509712219e-01
    z[9,10,1]  R2810     4.4211441278457642e-01
    z[9,10,1]  R2811     -4.0771577507257462e-02
    z[9,10,2]  R85       -1
    z[9,10,2]  R94       1
    z[9,10,2]  R2723     -1
    z[9,10,2]  R2724     1
    z[9,10,2]  R2733     -7.4411070346832275e-01
    z[9,10,2]  R2734     -3.6822758615016937e-02
    z[9,10,2]  R2735     -7.7068406343460083e-01
    z[9,10,2]  R2736     3.2374224066734314e-01
    z[9,10,2]  R2737     -8.4436124563217163e-01
    z[9,10,2]  R2738     -6.0189658403396606e-01
    z[9,10,2]  R2739     -3.3512271940708160e-02
    z[9,10,2]  R2740     0.0568292960524559
    z[9,10,2]  R2741     7.6525114476680756e-02
    z[9,10,2]  R2742     2.6634183526039124e-01
    z[9,10,2]  R2743     2.8374445438385010e-01
    z[9,10,2]  R2744     -2.0799554884433746e-01
    z[9,10,2]  R2745     2.7511257678270340e-02
    z[9,10,2]  R2746     1.4409109950065613e-01
    z[9,10,2]  R2747     2.4562698602676392e-01
    z[9,10,2]  R2748     7.0352025330066681e-02
    z[9,10,2]  R2749     1.3667736947536469e-01
    z[9,10,2]  R2750     2.1717865020036697e-02
    z[9,10,2]  R2751     1.2249117344617844e-01
    z[9,10,2]  R2752     2.9887804761528969e-02
    z[9,10,2]  R2753     6.9608017802238464e-02
    z[9,10,2]  R2754     6.9652813673019409e-01
    z[9,10,2]  R2755     6.6887855529785156e-01
    z[9,10,2]  R2756     7.8212898969650269e-01
    z[9,10,2]  R2757     7.3169898986816406e-01
    z[9,10,2]  R2758     8.6300361156463623e-01
    z[9,10,2]  R2759     6.7788320779800415e-01
    z[9,10,2]  R2760     6.0109579563140869e-01
    z[9,10,2]  R2761     5.0276088714599609e-01
    z[9,10,2]  R2762     5.2670013904571533e-01
    z[9,10,2]  R2763     -3.9953124523162842e-01
    z[9,10,2]  R2764     9.0667629241943359e-01
    z[9,10,2]  R2765     1.6216188669204712e-01
    z[9,10,2]  R2766     1.7469123005867004e-01
    z[9,10,2]  R2767     -0.0906200259923935
    z[9,10,2]  R2768     1.3017450273036957e-01
    z[9,10,2]  R2769     6.1005896329879761e-01
    z[9,10,2]  R2770     -5.0542913377285004e-02
    z[9,10,2]  R2771     1.2443476915359497e-01
    z[9,10,2]  R2772     -0.724852442741394
    z[9,10,2]  R2773     -0.00740482984110713
    z[9,10,2]  R2774     -4.8283287882804871e-01
    z[9,10,2]  R2775     2.7693548798561096e-01
    z[9,10,2]  R2776     -3.0036973953247070e-01
    z[9,10,2]  R2777     -5.8482116460800171e-01
    z[9,10,2]  R2778     -4.4869095087051392e-01
    z[9,10,2]  R2779     -3.9584168791770935e-01
    z[9,10,2]  R2780     -3.1886133551597595e-01
    z[9,10,2]  R2781     -6.8888276815414429e-02
    z[9,10,2]  R2782     1.9236966967582703e-01
    z[9,10,2]  R2783     -2.3499862849712372e-01
    z[9,10,2]  R2784     -1.2824200093746185e-01
    z[9,10,2]  R2785     4.8321297764778137e-01
    z[9,10,2]  R2786     -4.0007346868515015e-01
    z[9,10,2]  R2787     -3.2211970537900925e-02
    z[9,10,2]  R2788     -2.3078870773315430e-01
    z[9,10,2]  R2789     4.5992609858512878e-01
    z[9,10,2]  R2790     3.2394322752952576e-01
    z[9,10,2]  R2791     1.2365873157978058e-01
    z[9,10,2]  R2792     5.4677021503448486e-01
    z[9,10,2]  R2793     -0.00409313291311264
    z[9,10,2]  R2794     4.9141440540552139e-02
    z[9,10,2]  R2795     -2.1499194204807281e-01
    z[9,10,2]  R2796     -4.8322245478630066e-01
    z[9,10,2]  R2797     -4.3023490905761719e-01
    z[9,10,2]  R2798     -3.2550308108329773e-01
    z[9,10,2]  R2799     -1.5176175534725189e-01
    z[9,10,2]  R2800     5.5523775517940521e-02
    z[9,10,2]  R2801     -5.1858407258987427e-01
    z[9,10,2]  R2802     4.1414242982864380e-01
    z[9,10,2]  R2803     -1.7898446321487427e-01
    z[9,10,2]  R2804     4.4153865426778793e-02
    z[9,10,2]  R2805     4.3548453599214554e-02
    z[9,10,2]  R2806     2.8381463885307312e-01
    z[9,10,2]  R2807     -3.0663815140724182e-01
    z[9,10,2]  R2808     -5.5600476264953613e-01
    z[9,10,2]  R2809     -6.0695797204971313e-01
    z[9,10,2]  R2810     -4.2058983445167542e-01
    z[9,10,2]  R2811     -1.8685944378376007e-02
    z[9,10,3]  R86       -1
    z[9,10,3]  R95       1
    z[9,10,3]  R2725     -1
    z[9,10,3]  R2726     1
    z[9,10,3]  R2733     -4.3053078651428223e-01
    z[9,10,3]  R2734     -9.3980270624160767e-01
    z[9,10,3]  R2735     -5.1413238048553467e-01
    z[9,10,3]  R2736     -6.2300980091094971e-01
    z[9,10,3]  R2737     -4.6185851097106934e-01
    z[9,10,3]  R2738     -1.7539054155349731e-01
    z[9,10,3]  R2739     1.3005690276622772e-01
    z[9,10,3]  R2740     -2.9131261631846428e-02
    z[9,10,3]  R2741     1.1493502184748650e-02
    z[9,10,3]  R2742     -2.9282045364379883e-01
    z[9,10,3]  R2743     8.9619427919387817e-02
    z[9,10,3]  R2744     6.1843365430831909e-01
    z[9,10,3]  R2745     4.4111892580986023e-01
    z[9,10,3]  R2746     2.7013510465621948e-01
    z[9,10,3]  R2747     -7.9233951866626740e-02
    z[9,10,3]  R2748     2.0521600544452667e-01
    z[9,10,3]  R2749     -0.0388173945248127
    z[9,10,3]  R2750     2.7757605910301208e-01
    z[9,10,3]  R2751     1.4280018210411072e-01
    z[9,10,3]  R2752     1.9982960820198059e-01
    z[9,10,3]  R2753     2.0239561796188354e-01
    z[9,10,3]  R2754     -8.1577703356742859e-02
    z[9,10,3]  R2755     -4.0708336979150772e-02
    z[9,10,3]  R2756     6.0909765306860209e-04
    z[9,10,3]  R2757     -1.7282111942768097e-01
    z[9,10,3]  R2758     3.4197799861431122e-02
    z[9,10,3]  R2759     -5.0887301564216614e-02
    z[9,10,3]  R2760     -2.4098031222820282e-01
    z[9,10,3]  R2761     4.2497617006301880e-01
    z[9,10,3]  R2762     -9.6796251833438873e-02
    z[9,10,3]  R2763     1.9511635601520538e-01
    z[9,10,3]  R2764     1.8201845884323120e-01
    z[9,10,3]  R2765     1.9035039842128754e-01
    z[9,10,3]  R2766     1.9925527274608612e-02
    z[9,10,3]  R2767     2.2156937420368195e-01
    z[9,10,3]  R2768     -3.2070521265268326e-02
    z[9,10,3]  R2769     -3.7685963511466980e-01
    z[9,10,3]  R2770     3.5592874884605408e-01
    z[9,10,3]  R2771     3.8340842723846436e-01
    z[9,10,3]  R2772     -0.585458517074585
    z[9,10,3]  R2773     -5.2857035398483276e-01
    z[9,10,3]  R2774     -4.2818996310234070e-01
    z[9,10,3]  R2775     -8.7082099914550781e-01
    z[9,10,3]  R2776     2.9156097769737244e-01
    z[9,10,3]  R2777     4.1652080416679382e-01
    z[9,10,3]  R2778     1.2389941513538361e-01
    z[9,10,3]  R2779     2.0483785867691040e-01
    z[9,10,3]  R2780     5.9187458828091621e-03
    z[9,10,3]  R2781     1.0321240127086639e-01
    z[9,10,3]  R2782     5.7243430055677891e-03
    z[9,10,3]  R2783     5.3754359483718872e-01
    z[9,10,3]  R2784     1.8291927874088287e-01
    z[9,10,3]  R2785     2.3596415296196938e-02
    z[9,10,3]  R2786     4.3839433789253235e-01
    z[9,10,3]  R2787     -2.7212709188461304e-01
    z[9,10,3]  R2788     5.7946640253067017e-01
    z[9,10,3]  R2789     -0.231314554810524
    z[9,10,3]  R2790     -4.0604448318481445e-01
    z[9,10,3]  R2791     -2.2802665829658508e-01
    z[9,10,3]  R2792     1.3147830963134766e-01
    z[9,10,3]  R2793     2.5725081562995911e-01
    z[9,10,3]  R2794     5.6381557136774063e-02
    z[9,10,3]  R2795     3.9758530259132385e-01
    z[9,10,3]  R2796     7.1642249822616577e-01
    z[9,10,3]  R2797     6.4207404851913452e-01
    z[9,10,3]  R2798     4.8567295074462891e-01
    z[9,10,3]  R2799     6.1398875713348389e-01
    z[9,10,3]  R2800     1.0109191387891769e-01
    z[9,10,3]  R2801     0.778455913066864
    z[9,10,3]  R2802     -3.1388387084007263e-01
    z[9,10,3]  R2803     9.2800423502922058e-02
    z[9,10,3]  R2804     1.0242816060781479e-01
    z[9,10,3]  R2805     -1.6660006344318390e-01
    z[9,10,3]  R2806     -3.7849491834640503e-01
    z[9,10,3]  R2807     2.5698107481002808e-01
    z[9,10,3]  R2808     4.8226529359817505e-01
    z[9,10,3]  R2809     0.67186039686203
    z[9,10,3]  R2810     5.2164858579635620e-01
    z[9,10,3]  R2811     -1.0438710451126099e-01
    z[9,10,4]  R87       -1
    z[9,10,4]  R96       1
    z[9,10,4]  R2727     -1
    z[9,10,4]  R2728     1
    z[9,10,4]  R2733     -3.2824802398681641e-01
    z[9,10,4]  R2734     -2.3531022667884827e-01
    z[9,10,4]  R2735     -8.2215756177902222e-02
    z[9,10,4]  R2736     -6.8515396118164062e-01
    z[9,10,4]  R2737     -2.2942136228084564e-01
    z[9,10,4]  R2738     4.9723929166793823e-01
    z[9,10,4]  R2739     2.4729619920253754e-01
    z[9,10,4]  R2740     -1.1167253553867340e-01
    z[9,10,4]  R2741     -3.6528801918029785e-01
    z[9,10,4]  R2742     1.5953122079372406e-01
    z[9,10,4]  R2743     4.1583743691444397e-01
    z[9,10,4]  R2744     -5.4390925168991089e-01
    z[9,10,4]  R2745     -9.9856853485107422e-02
    z[9,10,4]  R2746     -3.2047357410192490e-02
    z[9,10,4]  R2747     -9.3093447387218475e-02
    z[9,10,4]  R2748     1.0573543608188629e-01
    z[9,10,4]  R2749     1.9736097753047943e-01
    z[9,10,4]  R2750     1.5574443340301514e-01
    z[9,10,4]  R2751     5.8930486440658569e-02
    z[9,10,4]  R2752     -2.2155632078647614e-01
    z[9,10,4]  R2753     -1.8620832264423370e-01
    z[9,10,4]  R2754     -8.2071825861930847e-02
    z[9,10,4]  R2755     -7.1168504655361176e-02
    z[9,10,4]  R2756     1.1733083426952362e-01
    z[9,10,4]  R2757     2.0120418071746826e-01
    z[9,10,4]  R2758     3.0511077493429184e-02
    z[9,10,4]  R2759     3.6816290020942688e-01
    z[9,10,4]  R2760     3.6784145236015320e-01
    z[9,10,4]  R2761     7.4541878700256348e-01
    z[9,10,4]  R2762     -3.1434498727321625e-02
    z[9,10,4]  R2763     2.7726659551262856e-02
    z[9,10,4]  R2764     -2.1740216016769409e-01
    z[9,10,4]  R2765     -3.1457386910915375e-02
    z[9,10,4]  R2766     -1.2729303538799286e-01
    z[9,10,4]  R2767     1.9173143804073334e-01
    z[9,10,4]  R2768     3.3662948012351990e-01
    z[9,10,4]  R2769     1.8153899908065796e-01
    z[9,10,4]  R2770     0.685374915599823
    z[9,10,4]  R2771     6.6990822553634644e-01
    z[9,10,4]  R2772     -1.6976216435432434e-01
    z[9,10,4]  R2773     -4.0392079949378967e-01
    z[9,10,4]  R2774     0.598517656326294
    z[9,10,4]  R2775     1.3599993288516998e-01
    z[9,10,4]  R2776     4.9204263091087341e-01
    z[9,10,4]  R2777     1.4729213714599609e-01
    z[9,10,4]  R2778     6.0209494829177856e-01
    z[9,10,4]  R2779     4.2323696613311768e-01
    z[9,10,4]  R2780     4.7182390093803406e-01
    z[9,10,4]  R2781     -3.3233314752578735e-01
    z[9,10,4]  R2782     -5.8718425035476685e-01
    z[9,10,4]  R2783     -1.7536464333534241e-01
    z[9,10,4]  R2784     8.0129742622375488e-02
    z[9,10,4]  R2785     -2.6915794610977173e-01
    z[9,10,4]  R2786     1.4086230099201202e-01
    z[9,10,4]  R2787     3.5032492876052856e-01
    z[9,10,4]  R2788     -6.6820669174194336e-01
    z[9,10,4]  R2789     -4.1844749450683594e-01
    z[9,10,4]  R2790     -1.4110292494297028e-01
    z[9,10,4]  R2791     -4.7072374820709229e-01
    z[9,10,4]  R2792     1.8801175057888031e-01
    z[9,10,4]  R2793     1.6922098398208618e-01
    z[9,10,4]  R2794     -5.7497894763946533e-01
    z[9,10,4]  R2795     -4.0878134965896606e-01
    z[9,10,4]  R2796     -2.5134158134460449e-01
    z[9,10,4]  R2797     4.7637414932250977e-01
    z[9,10,4]  R2798     5.9170957654714584e-02
    z[9,10,4]  R2799     -1.1432316154241562e-01
    z[9,10,4]  R2800     3.2425925135612488e-01
    z[9,10,4]  R2801     -3.0830618925392628e-03
    z[9,10,4]  R2802     -3.5209706425666809e-01
    z[9,10,4]  R2803     -5.3375250101089478e-01
    z[9,10,4]  R2804     1.4306859672069550e-01
    z[9,10,4]  R2805     3.9614674448966980e-01
    z[9,10,4]  R2806     -8.5101991891860962e-02
    z[9,10,4]  R2807     4.0996676683425903e-01
    z[9,10,4]  R2808     3.1603109836578369e-01
    z[9,10,4]  R2809     7.8276596963405609e-02
    z[9,10,4]  R2810     -4.5020073652267456e-02
    z[9,10,4]  R2811     2.4737946689128876e-01
    z[9,10,5]  R88       -1
    z[9,10,5]  R97       1
    z[9,10,5]  R2729     -1
    z[9,10,5]  R2730     1
    z[9,10,5]  R2733     -3.0798682570457458e-01
    z[9,10,5]  R2734     1.4860284328460693e-01
    z[9,10,5]  R2735     1.3143165409564972e-01
    z[9,10,5]  R2736     -4.7444548457860947e-02
    z[9,10,5]  R2737     3.9492752403020859e-02
    z[9,10,5]  R2738     1.9374240934848785e-01
    z[9,10,5]  R2739     1.3711906969547272e-01
    z[9,10,5]  R2740     -2.9747816920280457e-01
    z[9,10,5]  R2741     -4.3755255639553070e-02
    z[9,10,5]  R2742     -0.0848124623298645
    z[9,10,5]  R2743     2.2649076581001282e-01
    z[9,10,5]  R2744     3.8646966218948364e-01
    z[9,10,5]  R2745     -1.1627568304538727e-01
    z[9,10,5]  R2746     -6.1962295148987323e-05
    z[9,10,5]  R2747     1.3801721855998039e-02
    z[9,10,5]  R2748     -1.6287380456924438e-01
    z[9,10,5]  R2749     -2.6721358299255371e-01
    z[9,10,5]  R2750     1.9771657884120941e-01
    z[9,10,5]  R2751     -1.9833786785602570e-01
    z[9,10,5]  R2752     -2.3138357698917389e-01
    z[9,10,5]  R2753     7.0894765853881836e-01
    z[9,10,5]  R2754     -2.1792107820510864e-01
    z[9,10,5]  R2755     1.7922244966030121e-01
    z[9,10,5]  R2756     -1.1435023508965969e-02
    z[9,10,5]  R2757     -1.9206321239471436e-01
    z[9,10,5]  R2758     -1.3912537693977356e-01
    z[9,10,5]  R2759     1.3890877366065979e-01
    z[9,10,5]  R2760     3.0398979783058167e-01
    z[9,10,5]  R2761     2.2490348666906357e-02
    z[9,10,5]  R2762     5.2938252687454224e-01
    z[9,10,5]  R2763     1.2335211969912052e-02
    z[9,10,5]  R2764     -1.1504899710416794e-01
    z[9,10,5]  R2765     -1.7226109281182289e-02
    z[9,10,5]  R2766     1.8691466748714447e-01
    z[9,10,5]  R2767     4.3174274265766144e-02
    z[9,10,5]  R2768     6.5808288753032684e-02
    z[9,10,5]  R2769     1.3632968068122864e-01
    z[9,10,5]  R2770     -1.5600356459617615e-01
    z[9,10,5]  R2771     -2.0979729294776917e-01
    z[9,10,5]  R2772     1.4835315942764282e-01
    z[9,10,5]  R2773     2.6637926697731018e-01
    z[9,10,5]  R2774     -2.7432022616267204e-02
    z[9,10,5]  R2775     3.6502219736576080e-02
    z[9,10,5]  R2776     -1.0321357101202011e-01
    z[9,10,5]  R2777     3.5617381334304810e-01
    z[9,10,5]  R2778     -7.1311786770820618e-02
    z[9,10,5]  R2779     2.9279375076293945e-01
    z[9,10,5]  R2780     -4.5880886912345886e-01
    z[9,10,5]  R2781     5.8623600006103516e-01
    z[9,10,5]  R2782     5.1523530483245850e-01
    z[9,10,5]  R2783     0.631995439529419
    z[9,10,5]  R2784     2.4163471162319183e-01
    z[9,10,5]  R2785     -0.213162362575531
    z[9,10,5]  R2786     -3.3033466339111328e-01
    z[9,10,5]  R2787     3.2594287395477295e-01
    z[9,10,5]  R2788     5.4186254739761353e-02
    z[9,10,5]  R2789     -1.5071900188922882e-01
    z[9,10,5]  R2790     -2.9552176594734192e-01
    z[9,10,5]  R2791     -4.7624596953392029e-01
    z[9,10,5]  R2792     -4.1224356740713120e-02
    z[9,10,5]  R2793     -1.0179454833269119e-01
    z[9,10,5]  R2794     -1.2646009027957916e-01
    z[9,10,5]  R2795     -2.1688570082187653e-01
    z[9,10,5]  R2796     1.2357288040220737e-02
    z[9,10,5]  R2797     -7.3192939162254333e-02
    z[9,10,5]  R2798     -3.3099305629730225e-01
    z[9,10,5]  R2799     1.2673702836036682e-01
    z[9,10,5]  R2800     -1.1368635110557079e-02
    z[9,10,5]  R2801     1.4075355231761932e-01
    z[9,10,5]  R2802     -8.0980204045772552e-02
    z[9,10,5]  R2803     -1.8685216084122658e-02
    z[9,10,5]  R2804     8.7871748208999634e-01
    z[9,10,5]  R2805     5.2634340524673462e-01
    z[9,10,5]  R2806     2.1733374893665314e-01
    z[9,10,5]  R2807     4.6922564506530762e-02
    z[9,10,5]  R2808     1.9103546440601349e-01
    z[9,10,5]  R2809     6.2783464789390564e-02
    z[9,10,5]  R2810     1.5240314602851868e-01
    z[9,10,5]  R2811     2.6976841688156128e-01
    z[9,10,6]  R89       -1
    z[9,10,6]  R98       1
    z[9,10,6]  R2731     -1
    z[9,10,6]  R2732     1
    z[9,10,6]  R2733     -2.0467959344387054e-01
    z[9,10,6]  R2734     1.7171584069728851e-01
    z[9,10,6]  R2735     3.3292478322982788e-01
    z[9,10,6]  R2736     1.5424039214849472e-02
    z[9,10,6]  R2737     5.0195235759019852e-02
    z[9,10,6]  R2738     -4.9056738615036011e-01
    z[9,10,6]  R2739     0.0674024224281311
    z[9,10,6]  R2740     -8.2106389105319977e-02
    z[9,10,6]  R2741     1.6777482815086842e-03
    z[9,10,6]  R2742     6.7161314189434052e-02
    z[9,10,6]  R2743     3.8654974102973938e-01
    z[9,10,6]  R2744     -1.0419576615095139e-01
    z[9,10,6]  R2745     1.7666088044643402e-01
    z[9,10,6]  R2746     1.2872123718261719e-01
    z[9,10,6]  R2747     9.6881859004497528e-02
    z[9,10,6]  R2748     2.2454324364662170e-01
    z[9,10,6]  R2749     -1.6983805224299431e-02
    z[9,10,6]  R2750     -1.0190619528293610e-01
    z[9,10,6]  R2751     -2.6259443163871765e-01
    z[9,10,6]  R2752     -2.7493588626384735e-02
    z[9,10,6]  R2753     4.3242105841636658e-01
    z[9,10,6]  R2754     1.8403728306293488e-01
    z[9,10,6]  R2755     -3.4229072928428650e-01
    z[9,10,6]  R2756     -2.5955277681350708e-01
    z[9,10,6]  R2757     -2.9613664746284485e-01
    z[9,10,6]  R2758     -1.6206017136573792e-01
    z[9,10,6]  R2759     1.3659252226352692e-01
    z[9,10,6]  R2760     -2.8309881687164307e-01
    z[9,10,6]  R2761     1.6889926046133041e-02
    z[9,10,6]  R2762     -6.4644539356231689e-01
    z[9,10,6]  R2763     -5.8095294237136841e-01
    z[9,10,6]  R2764     -1.4411937445402145e-02
    z[9,10,6]  R2765     -1.5400281548500061e-01
    z[9,10,6]  R2766     -1.2219013273715973e-01
    z[9,10,6]  R2767     1.5229758620262146e-01
    z[9,10,6]  R2768     0.218552827835083
    z[9,10,6]  R2769     -1.9323615729808807e-01
    z[9,10,6]  R2770     5.4894298315048218e-01
    z[9,10,6]  R2771     4.7479081153869629e-01
    z[9,10,6]  R2772     2.7644306421279907e-01
    z[9,10,6]  R2773     6.7327147722244263e-01
    z[9,10,6]  R2774     -7.6228022575378418e-02
    z[9,10,6]  R2775     3.6781498789787292e-01
    z[9,10,6]  R2776     2.8878265619277954e-01
    z[9,10,6]  R2777     -4.1889244318008423e-01
    z[9,10,6]  R2778     -9.1430976986885071e-02
    z[9,10,6]  R2779     -2.0811778306961060e-01
    z[9,10,6]  R2780     -3.2275122404098511e-01
    z[9,10,6]  R2781     -4.4729572534561157e-01
    z[9,10,6]  R2782     -5.7501184940338135e-01
    z[9,10,6]  R2783     -1.4265993237495422e-01
    z[9,10,6]  R2784     -3.0545833706855774e-01
    z[9,10,6]  R2785     -1.6427166759967804e-01
    z[9,10,6]  R2786     2.0659960806369781e-01
    z[9,10,6]  R2787     -2.2668333351612091e-01
    z[9,10,6]  R2788     2.0110729336738586e-01
    z[9,10,6]  R2789     1.2507688999176025e-01
    z[9,10,6]  R2790     -1.3507668673992157e-01
    z[9,10,6]  R2791     -2.0407313108444214e-01
    z[9,10,6]  R2792     1.7033822834491730e-01
    z[9,10,6]  R2793     -4.6367627382278442e-01
    z[9,10,6]  R2794     0.197689488530159
    z[9,10,6]  R2795     3.9398968219757080e-02
    z[9,10,6]  R2796     1.2318865209817886e-01
    z[9,10,6]  R2797     -1.4014187268912792e-02
    z[9,10,6]  R2798     5.6017464399337769e-01
    z[9,10,6]  R2799     9.2212647199630737e-02
    z[9,10,6]  R2800     3.5562083125114441e-01
    z[9,10,6]  R2801     -2.2206236422061920e-01
    z[9,10,6]  R2802     -8.0214828252792358e-02
    z[9,10,6]  R2803     1.7276298999786377e-01
    z[9,10,6]  R2804     2.4914576113224030e-01
    z[9,10,6]  R2805     -4.4145914912223816e-01
    z[9,10,6]  R2806     -2.8837126493453979e-01
    z[9,10,6]  R2807     1.7233215272426605e-01
    z[9,10,6]  R2808     -3.0135154724121094e-01
    z[9,10,6]  R2809     -1.1381273716688156e-01
    z[9,10,6]  R2810     1.3115748763084412e-01
    z[9,10,6]  R2811     4.3380558490753174e-02
    z[10,9,0]  R83       1
    z[10,9,0]  R92       -1
    z[10,9,0]  R2812     -1
    z[10,9,0]  R2813     1
    z[10,9,0]  R2826     -0.0322338342666626
    z[10,9,0]  R2827     -3.8929153233766556e-02
    z[10,9,0]  R2828     -2.8456223011016846e-01
    z[10,9,0]  R2829     -9.5431968569755554e-02
    z[10,9,0]  R2830     4.8519930243492126e-01
    z[10,9,0]  R2831     2.9040375351905823e-01
    z[10,9,0]  R2832     6.2423527240753174e-01
    z[10,9,0]  R2833     0.68561190366745
    z[10,9,0]  R2834     3.9377138018608093e-01
    z[10,9,0]  R2835     4.7939980030059814e-01
    z[10,9,0]  R2836     -1.3835345208644867e-01
    z[10,9,0]  R2837     -2.6231449842453003e-01
    z[10,9,0]  R2838     -8.1875901669263840e-03
    z[10,9,0]  R2839     -7.8163832426071167e-01
    z[10,9,0]  R2840     -4.8524963855743408e-01
    z[10,9,0]  R2841     7.1659278869628906e-01
    z[10,9,0]  R2842     4.5273523777723312e-02
    z[10,9,0]  R2843     -4.5310713350772858e-02
    z[10,9,0]  R2844     6.3448154926300049e-01
    z[10,9,0]  R2845     3.3574381470680237e-01
    z[10,9,0]  R2846     -7.6139461994171143e-01
    z[10,9,0]  R2847     -7.8718638420104980e-01
    z[10,9,0]  R2848     -5.9369087219238281e-01
    z[10,9,0]  R2849     -5.3711426258087158e-01
    z[10,9,0]  R2850     1.0929322987794876e-01
    z[10,9,0]  R2851     2.8275832533836365e-01
    z[10,9,0]  R2852     7.5258262455463409e-02
    z[10,9,0]  R2853     5.1826828718185425e-01
    z[10,9,0]  R2854     8.6387908458709717e-01
    z[10,9,0]  R2855     2.2995744645595551e-01
    z[10,9,0]  R2856     -4.4182431697845459e-01
    z[10,9,0]  R2857     -4.4682115316390991e-01
    z[10,9,0]  R2858     -2.6626887917518616e-01
    z[10,9,0]  R2859     -2.6983499526977539e-01
    z[10,9,0]  R2860     -2.8977537155151367e-01
    z[10,9,0]  R2861     1.8678304553031921e-01
    z[10,9,0]  R2862     1.8696199357509613e-01
    z[10,9,0]  R2863     3.3619109541177750e-02
    z[10,9,0]  R2864     5.5952310562133789e-01
    z[10,9,0]  R2865     9.2262578010559082e-01
    z[10,9,0]  R2866     -1.1226820200681686e-01
    z[10,9,0]  R2867     -2.9766298830509186e-03
    z[10,9,0]  R2868     -5.9259835630655289e-02
    z[10,9,0]  R2869     -1.3733139634132385e-01
    z[10,9,0]  R2870     -1.6203567385673523e-02
    z[10,9,0]  R2871     -2.8471872210502625e-01
    z[10,9,0]  R2872     9.4680595397949219e-01
    z[10,9,0]  R2873     9.3098402023315430e-01
    z[10,9,0]  R2874     9.1860550642013550e-01
    z[10,9,0]  R2875     8.8751626014709473e-01
    z[10,9,0]  R2876     -6.1334443092346191e-01
    z[10,9,0]  R2877     -2.9817822575569153e-01
    z[10,9,0]  R2878     9.3357026576995850e-02
    z[10,9,0]  R2879     -1.1157221347093582e-01
    z[10,9,0]  R2880     -1.5873283147811890e-01
    z[10,9,0]  R2881     1.2745600193738937e-02
    z[10,9,0]  R2882     -2.2245932370424271e-02
    z[10,9,0]  R2883     -0.060992531478405
    z[10,9,0]  R2884     -1.1587447673082352e-01
    z[10,9,0]  R2885     -1.8560811877250671e-01
    z[10,9,0]  R2886     -4.2634120583534241e-01
    z[10,9,0]  R2887     -1.3205859065055847e-01
    z[10,9,0]  R2888     -0.000888276903424412
    z[10,9,0]  R2889     -1.3749279081821442e-01
    z[10,9,0]  R2890     -1.6728754341602325e-01
    z[10,9,0]  R2891     -8.9038275182247162e-02
    z[10,9,0]  R2892     -1.6110089421272278e-01
    z[10,9,0]  R2893     -1.5334102511405945e-01
    z[10,9,0]  R2894     -6.4253114163875580e-02
    z[10,9,0]  R2895     1.0551518946886063e-01
    z[10,9,0]  R2896     6.7918163537979126e-01
    z[10,9,0]  R2897     2.8729543089866638e-01
    z[10,9,0]  R2898     -8.0463126301765442e-02
    z[10,9,0]  R2899     -2.2232008632272482e-03
    z[10,9,0]  R2900     1.1726172268390656e-01
    z[10,9,0]  R2901     -1.7584471404552460e-01
    z[10,9,0]  R2902     -1.8058015406131744e-01
    z[10,9,0]  R2903     -7.9893134534358978e-02
    z[10,9,0]  R2904     -1.4695121347904205e-01
    z[10,9,1]  R84       1
    z[10,9,1]  R93       -1
    z[10,9,1]  R2814     -1
    z[10,9,1]  R2815     1
    z[10,9,1]  R2826     5.9495024383068085e-02
    z[10,9,1]  R2827     -1.7787255346775055e-01
    z[10,9,1]  R2828     -3.7116494774818420e-01
    z[10,9,1]  R2829     2.7456842362880707e-02
    z[10,9,1]  R2830     5.0318706035614014e-01
    z[10,9,1]  R2831     2.7592509984970093e-01
    z[10,9,1]  R2832     1.3301257789134979e-01
    z[10,9,1]  R2833     1.5204125642776489e-01
    z[10,9,1]  R2834     4.5381143689155579e-01
    z[10,9,1]  R2835     3.1715300679206848e-01
    z[10,9,1]  R2836     -5.4111443459987640e-02
    z[10,9,1]  R2837     -3.6944654583930969e-01
    z[10,9,1]  R2838     8.8989585638046265e-01
    z[10,9,1]  R2839     -1.0060093551874161e-01
    z[10,9,1]  R2840     4.9054840207099915e-01
    z[10,9,1]  R2841     -3.6201146245002747e-01
    z[10,9,1]  R2842     3.4500020742416382e-01
    z[10,9,1]  R2843     7.2072863578796387e-01
    z[10,9,1]  R2844     4.4959199428558350e-01
    z[10,9,1]  R2845     5.7441401481628418e-01
    z[10,9,1]  R2846     -1.9486187398433685e-01
    z[10,9,1]  R2847     2.4525374174118042e-01
    z[10,9,1]  R2848     5.0622463226318359e-01
    z[10,9,1]  R2849     -5.3992480039596558e-01
    z[10,9,1]  R2850     4.0347132086753845e-01
    z[10,9,1]  R2851     3.0033415555953979e-01
    z[10,9,1]  R2852     4.7502881288528442e-01
    z[10,9,1]  R2853     5.4198604822158813e-01
    z[10,9,1]  R2854     9.3117982149124146e-02
    z[10,9,1]  R2855     5.5350724607706070e-02
    z[10,9,1]  R2856     -6.3070565462112427e-01
    z[10,9,1]  R2857     0.666795015335083
    z[10,9,1]  R2858     2.4894419312477112e-01
    z[10,9,1]  R2859     5.1834475994110107e-01
    z[10,9,1]  R2860     0.744705855846405
    z[10,9,1]  R2861     0.777864396572113
    z[10,9,1]  R2862     4.4287830591201782e-01
    z[10,9,1]  R2863     3.9503553509712219e-01
    z[10,9,1]  R2864     4.4211441278457642e-01
    z[10,9,1]  R2865     -4.0771577507257462e-02
    z[10,9,1]  R2866     -0.0619843415915966
    z[10,9,1]  R2867     9.2010758817195892e-02
    z[10,9,1]  R2868     5.7703733444213867e-02
    z[10,9,1]  R2869     -1.2753465771675110e-01
    z[10,9,1]  R2870     -1.2947869300842285e-01
    z[10,9,1]  R2871     2.1319158375263214e-02
    z[10,9,1]  R2872     3.1947411596775055e-02
    z[10,9,1]  R2873     -1.4657779037952423e-01
    z[10,9,1]  R2874     -1.2175092846155167e-01
    z[10,9,1]  R2875     -1.3593797385692596e-01
    z[10,9,1]  R2876     4.0202805399894714e-01
    z[10,9,1]  R2877     1.7121504247188568e-01
    z[10,9,1]  R2878     8.6095374822616577e-01
    z[10,9,1]  R2879     -9.3606638908386230e-01
    z[10,9,1]  R2880     -9.4337177276611328e-01
    z[10,9,1]  R2881     -9.2986398935317993e-01
    z[10,9,1]  R2882     -9.3202722072601318e-01
    z[10,9,1]  R2883     -9.1925334930419922e-01
    z[10,9,1]  R2884     -9.1619348526000977e-01
    z[10,9,1]  R2885     -9.0627974271774292e-01
    z[10,9,1]  R2886     2.1944376826286316e-01
    z[10,9,1]  R2887     -6.3455426692962646e-01
    z[10,9,1]  R2888     -6.2975788116455078e-01
    z[10,9,1]  R2889     -0.53675377368927
    z[10,9,1]  R2890     -4.9162584543228149e-01
    z[10,9,1]  R2891     -4.4674062728881836e-01
    z[10,9,1]  R2892     -5.8175098896026611e-01
    z[10,9,1]  R2893     -4.9923619627952576e-01
    z[10,9,1]  R2894     -7.7833518385887146e-02
    z[10,9,1]  R2895     -5.4391577839851379e-02
    z[10,9,1]  R2896     -5.0886329263448715e-02
    z[10,9,1]  R2897     -3.9508793503046036e-02
    z[10,9,1]  R2898     -9.5183652639389038e-01
    z[10,9,1]  R2899     -9.5026838779449463e-01
    z[10,9,1]  R2900     -9.3119555711746216e-01
    z[10,9,1]  R2901     -8.8639110326766968e-01
    z[10,9,1]  R2902     -6.0358375310897827e-01
    z[10,9,1]  R2903     -2.6260793209075928e-01
    z[10,9,1]  R2904     -3.1257179379463196e-01
    z[10,9,2]  R85       1
    z[10,9,2]  R94       -1
    z[10,9,2]  R2816     -1
    z[10,9,2]  R2817     1
    z[10,9,2]  R2826     -0.724852442741394
    z[10,9,2]  R2827     -0.00740482984110713
    z[10,9,2]  R2828     -4.8283287882804871e-01
    z[10,9,2]  R2829     2.7693548798561096e-01
    z[10,9,2]  R2830     -3.0036973953247070e-01
    z[10,9,2]  R2831     -5.8482116460800171e-01
    z[10,9,2]  R2832     -4.4869095087051392e-01
    z[10,9,2]  R2833     -3.9584168791770935e-01
    z[10,9,2]  R2834     -3.1886133551597595e-01
    z[10,9,2]  R2835     -6.8888276815414429e-02
    z[10,9,2]  R2836     1.9236966967582703e-01
    z[10,9,2]  R2837     -2.3499862849712372e-01
    z[10,9,2]  R2838     -1.2824200093746185e-01
    z[10,9,2]  R2839     4.8321297764778137e-01
    z[10,9,2]  R2840     -4.0007346868515015e-01
    z[10,9,2]  R2841     -3.2211970537900925e-02
    z[10,9,2]  R2842     -2.3078870773315430e-01
    z[10,9,2]  R2843     4.5992609858512878e-01
    z[10,9,2]  R2844     3.2394322752952576e-01
    z[10,9,2]  R2845     1.2365873157978058e-01
    z[10,9,2]  R2846     5.4677021503448486e-01
    z[10,9,2]  R2847     -0.00409313291311264
    z[10,9,2]  R2848     4.9141440540552139e-02
    z[10,9,2]  R2849     -2.1499194204807281e-01
    z[10,9,2]  R2850     -4.8322245478630066e-01
    z[10,9,2]  R2851     -4.3023490905761719e-01
    z[10,9,2]  R2852     -3.2550308108329773e-01
    z[10,9,2]  R2853     -1.5176175534725189e-01
    z[10,9,2]  R2854     5.5523775517940521e-02
    z[10,9,2]  R2855     -5.1858407258987427e-01
    z[10,9,2]  R2856     4.1414242982864380e-01
    z[10,9,2]  R2857     -1.7898446321487427e-01
    z[10,9,2]  R2858     4.4153865426778793e-02
    z[10,9,2]  R2859     4.3548453599214554e-02
    z[10,9,2]  R2860     2.8381463885307312e-01
    z[10,9,2]  R2861     -3.0663815140724182e-01
    z[10,9,2]  R2862     -5.5600476264953613e-01
    z[10,9,2]  R2863     -6.0695797204971313e-01
    z[10,9,2]  R2864     -4.2058983445167542e-01
    z[10,9,2]  R2865     -1.8685944378376007e-02
    z[10,9,2]  R2866     -7.4411070346832275e-01
    z[10,9,2]  R2867     -3.6822758615016937e-02
    z[10,9,2]  R2868     -7.7068406343460083e-01
    z[10,9,2]  R2869     3.2374224066734314e-01
    z[10,9,2]  R2870     -8.4436124563217163e-01
    z[10,9,2]  R2871     -6.0189658403396606e-01
    z[10,9,2]  R2872     -3.3512271940708160e-02
    z[10,9,2]  R2873     0.0568292960524559
    z[10,9,2]  R2874     7.6525114476680756e-02
    z[10,9,2]  R2875     2.6634183526039124e-01
    z[10,9,2]  R2876     2.8374445438385010e-01
    z[10,9,2]  R2877     -2.0799554884433746e-01
    z[10,9,2]  R2878     2.7511257678270340e-02
    z[10,9,2]  R2879     1.4409109950065613e-01
    z[10,9,2]  R2880     2.4562698602676392e-01
    z[10,9,2]  R2881     7.0352025330066681e-02
    z[10,9,2]  R2882     1.3667736947536469e-01
    z[10,9,2]  R2883     2.1717865020036697e-02
    z[10,9,2]  R2884     1.2249117344617844e-01
    z[10,9,2]  R2885     2.9887804761528969e-02
    z[10,9,2]  R2886     6.9608017802238464e-02
    z[10,9,2]  R2887     6.9652813673019409e-01
    z[10,9,2]  R2888     6.6887855529785156e-01
    z[10,9,2]  R2889     7.8212898969650269e-01
    z[10,9,2]  R2890     7.3169898986816406e-01
    z[10,9,2]  R2891     8.6300361156463623e-01
    z[10,9,2]  R2892     6.7788320779800415e-01
    z[10,9,2]  R2893     6.0109579563140869e-01
    z[10,9,2]  R2894     5.0276088714599609e-01
    z[10,9,2]  R2895     5.2670013904571533e-01
    z[10,9,2]  R2896     -3.9953124523162842e-01
    z[10,9,2]  R2897     9.0667629241943359e-01
    z[10,9,2]  R2898     1.6216188669204712e-01
    z[10,9,2]  R2899     1.7469123005867004e-01
    z[10,9,2]  R2900     -0.0906200259923935
    z[10,9,2]  R2901     1.3017450273036957e-01
    z[10,9,2]  R2902     6.1005896329879761e-01
    z[10,9,2]  R2903     -5.0542913377285004e-02
    z[10,9,2]  R2904     1.2443476915359497e-01
    z[10,9,3]  R86       1
    z[10,9,3]  R95       -1
    z[10,9,3]  R2818     -1
    z[10,9,3]  R2819     1
    z[10,9,3]  R2826     -0.585458517074585
    z[10,9,3]  R2827     -5.2857035398483276e-01
    z[10,9,3]  R2828     -4.2818996310234070e-01
    z[10,9,3]  R2829     -8.7082099914550781e-01
    z[10,9,3]  R2830     2.9156097769737244e-01
    z[10,9,3]  R2831     4.1652080416679382e-01
    z[10,9,3]  R2832     1.2389941513538361e-01
    z[10,9,3]  R2833     2.0483785867691040e-01
    z[10,9,3]  R2834     5.9187458828091621e-03
    z[10,9,3]  R2835     1.0321240127086639e-01
    z[10,9,3]  R2836     5.7243430055677891e-03
    z[10,9,3]  R2837     5.3754359483718872e-01
    z[10,9,3]  R2838     1.8291927874088287e-01
    z[10,9,3]  R2839     2.3596415296196938e-02
    z[10,9,3]  R2840     4.3839433789253235e-01
    z[10,9,3]  R2841     -2.7212709188461304e-01
    z[10,9,3]  R2842     5.7946640253067017e-01
    z[10,9,3]  R2843     -0.231314554810524
    z[10,9,3]  R2844     -4.0604448318481445e-01
    z[10,9,3]  R2845     -2.2802665829658508e-01
    z[10,9,3]  R2846     1.3147830963134766e-01
    z[10,9,3]  R2847     2.5725081562995911e-01
    z[10,9,3]  R2848     5.6381557136774063e-02
    z[10,9,3]  R2849     3.9758530259132385e-01
    z[10,9,3]  R2850     7.1642249822616577e-01
    z[10,9,3]  R2851     6.4207404851913452e-01
    z[10,9,3]  R2852     4.8567295074462891e-01
    z[10,9,3]  R2853     6.1398875713348389e-01
    z[10,9,3]  R2854     1.0109191387891769e-01
    z[10,9,3]  R2855     0.778455913066864
    z[10,9,3]  R2856     -3.1388387084007263e-01
    z[10,9,3]  R2857     9.2800423502922058e-02
    z[10,9,3]  R2858     1.0242816060781479e-01
    z[10,9,3]  R2859     -1.6660006344318390e-01
    z[10,9,3]  R2860     -3.7849491834640503e-01
    z[10,9,3]  R2861     2.5698107481002808e-01
    z[10,9,3]  R2862     4.8226529359817505e-01
    z[10,9,3]  R2863     0.67186039686203
    z[10,9,3]  R2864     5.2164858579635620e-01
    z[10,9,3]  R2865     -1.0438710451126099e-01
    z[10,9,3]  R2866     -4.3053078651428223e-01
    z[10,9,3]  R2867     -9.3980270624160767e-01
    z[10,9,3]  R2868     -5.1413238048553467e-01
    z[10,9,3]  R2869     -6.2300980091094971e-01
    z[10,9,3]  R2870     -4.6185851097106934e-01
    z[10,9,3]  R2871     -1.7539054155349731e-01
    z[10,9,3]  R2872     1.3005690276622772e-01
    z[10,9,3]  R2873     -2.9131261631846428e-02
    z[10,9,3]  R2874     1.1493502184748650e-02
    z[10,9,3]  R2875     -2.9282045364379883e-01
    z[10,9,3]  R2876     8.9619427919387817e-02
    z[10,9,3]  R2877     6.1843365430831909e-01
    z[10,9,3]  R2878     4.4111892580986023e-01
    z[10,9,3]  R2879     2.7013510465621948e-01
    z[10,9,3]  R2880     -7.9233951866626740e-02
    z[10,9,3]  R2881     2.0521600544452667e-01
    z[10,9,3]  R2882     -0.0388173945248127
    z[10,9,3]  R2883     2.7757605910301208e-01
    z[10,9,3]  R2884     1.4280018210411072e-01
    z[10,9,3]  R2885     1.9982960820198059e-01
    z[10,9,3]  R2886     2.0239561796188354e-01
    z[10,9,3]  R2887     -8.1577703356742859e-02
    z[10,9,3]  R2888     -4.0708336979150772e-02
    z[10,9,3]  R2889     6.0909765306860209e-04
    z[10,9,3]  R2890     -1.7282111942768097e-01
    z[10,9,3]  R2891     3.4197799861431122e-02
    z[10,9,3]  R2892     -5.0887301564216614e-02
    z[10,9,3]  R2893     -2.4098031222820282e-01
    z[10,9,3]  R2894     4.2497617006301880e-01
    z[10,9,3]  R2895     -9.6796251833438873e-02
    z[10,9,3]  R2896     1.9511635601520538e-01
    z[10,9,3]  R2897     1.8201845884323120e-01
    z[10,9,3]  R2898     1.9035039842128754e-01
    z[10,9,3]  R2899     1.9925527274608612e-02
    z[10,9,3]  R2900     2.2156937420368195e-01
    z[10,9,3]  R2901     -3.2070521265268326e-02
    z[10,9,3]  R2902     -3.7685963511466980e-01
    z[10,9,3]  R2903     3.5592874884605408e-01
    z[10,9,3]  R2904     3.8340842723846436e-01
    z[10,9,4]  R87       1
    z[10,9,4]  R96       -1
    z[10,9,4]  R2820     -1
    z[10,9,4]  R2821     1
    z[10,9,4]  R2826     -1.6976216435432434e-01
    z[10,9,4]  R2827     -4.0392079949378967e-01
    z[10,9,4]  R2828     0.598517656326294
    z[10,9,4]  R2829     1.3599993288516998e-01
    z[10,9,4]  R2830     4.9204263091087341e-01
    z[10,9,4]  R2831     1.4729213714599609e-01
    z[10,9,4]  R2832     6.0209494829177856e-01
    z[10,9,4]  R2833     4.2323696613311768e-01
    z[10,9,4]  R2834     4.7182390093803406e-01
    z[10,9,4]  R2835     -3.3233314752578735e-01
    z[10,9,4]  R2836     -5.8718425035476685e-01
    z[10,9,4]  R2837     -1.7536464333534241e-01
    z[10,9,4]  R2838     8.0129742622375488e-02
    z[10,9,4]  R2839     -2.6915794610977173e-01
    z[10,9,4]  R2840     1.4086230099201202e-01
    z[10,9,4]  R2841     3.5032492876052856e-01
    z[10,9,4]  R2842     -6.6820669174194336e-01
    z[10,9,4]  R2843     -4.1844749450683594e-01
    z[10,9,4]  R2844     -1.4110292494297028e-01
    z[10,9,4]  R2845     -4.7072374820709229e-01
    z[10,9,4]  R2846     1.8801175057888031e-01
    z[10,9,4]  R2847     1.6922098398208618e-01
    z[10,9,4]  R2848     -5.7497894763946533e-01
    z[10,9,4]  R2849     -4.0878134965896606e-01
    z[10,9,4]  R2850     -2.5134158134460449e-01
    z[10,9,4]  R2851     4.7637414932250977e-01
    z[10,9,4]  R2852     5.9170957654714584e-02
    z[10,9,4]  R2853     -1.1432316154241562e-01
    z[10,9,4]  R2854     3.2425925135612488e-01
    z[10,9,4]  R2855     -3.0830618925392628e-03
    z[10,9,4]  R2856     -3.5209706425666809e-01
    z[10,9,4]  R2857     -5.3375250101089478e-01
    z[10,9,4]  R2858     1.4306859672069550e-01
    z[10,9,4]  R2859     3.9614674448966980e-01
    z[10,9,4]  R2860     -8.5101991891860962e-02
    z[10,9,4]  R2861     4.0996676683425903e-01
    z[10,9,4]  R2862     3.1603109836578369e-01
    z[10,9,4]  R2863     7.8276596963405609e-02
    z[10,9,4]  R2864     -4.5020073652267456e-02
    z[10,9,4]  R2865     2.4737946689128876e-01
    z[10,9,4]  R2866     -3.2824802398681641e-01
    z[10,9,4]  R2867     -2.3531022667884827e-01
    z[10,9,4]  R2868     -8.2215756177902222e-02
    z[10,9,4]  R2869     -6.8515396118164062e-01
    z[10,9,4]  R2870     -2.2942136228084564e-01
    z[10,9,4]  R2871     4.9723929166793823e-01
    z[10,9,4]  R2872     2.4729619920253754e-01
    z[10,9,4]  R2873     -1.1167253553867340e-01
    z[10,9,4]  R2874     -3.6528801918029785e-01
    z[10,9,4]  R2875     1.5953122079372406e-01
    z[10,9,4]  R2876     4.1583743691444397e-01
    z[10,9,4]  R2877     -5.4390925168991089e-01
    z[10,9,4]  R2878     -9.9856853485107422e-02
    z[10,9,4]  R2879     -3.2047357410192490e-02
    z[10,9,4]  R2880     -9.3093447387218475e-02
    z[10,9,4]  R2881     1.0573543608188629e-01
    z[10,9,4]  R2882     1.9736097753047943e-01
    z[10,9,4]  R2883     1.5574443340301514e-01
    z[10,9,4]  R2884     5.8930486440658569e-02
    z[10,9,4]  R2885     -2.2155632078647614e-01
    z[10,9,4]  R2886     -1.8620832264423370e-01
    z[10,9,4]  R2887     -8.2071825861930847e-02
    z[10,9,4]  R2888     -7.1168504655361176e-02
    z[10,9,4]  R2889     1.1733083426952362e-01
    z[10,9,4]  R2890     2.0120418071746826e-01
    z[10,9,4]  R2891     3.0511077493429184e-02
    z[10,9,4]  R2892     3.6816290020942688e-01
    z[10,9,4]  R2893     3.6784145236015320e-01
    z[10,9,4]  R2894     7.4541878700256348e-01
    z[10,9,4]  R2895     -3.1434498727321625e-02
    z[10,9,4]  R2896     2.7726659551262856e-02
    z[10,9,4]  R2897     -2.1740216016769409e-01
    z[10,9,4]  R2898     -3.1457386910915375e-02
    z[10,9,4]  R2899     -1.2729303538799286e-01
    z[10,9,4]  R2900     1.9173143804073334e-01
    z[10,9,4]  R2901     3.3662948012351990e-01
    z[10,9,4]  R2902     1.8153899908065796e-01
    z[10,9,4]  R2903     0.685374915599823
    z[10,9,4]  R2904     6.6990822553634644e-01
    z[10,9,5]  R88       1
    z[10,9,5]  R97       -1
    z[10,9,5]  R2822     -1
    z[10,9,5]  R2823     1
    z[10,9,5]  R2826     1.4835315942764282e-01
    z[10,9,5]  R2827     2.6637926697731018e-01
    z[10,9,5]  R2828     -2.7432022616267204e-02
    z[10,9,5]  R2829     3.6502219736576080e-02
    z[10,9,5]  R2830     -1.0321357101202011e-01
    z[10,9,5]  R2831     3.5617381334304810e-01
    z[10,9,5]  R2832     -7.1311786770820618e-02
    z[10,9,5]  R2833     2.9279375076293945e-01
    z[10,9,5]  R2834     -4.5880886912345886e-01
    z[10,9,5]  R2835     5.8623600006103516e-01
    z[10,9,5]  R2836     5.1523530483245850e-01
    z[10,9,5]  R2837     0.631995439529419
    z[10,9,5]  R2838     2.4163471162319183e-01
    z[10,9,5]  R2839     -0.213162362575531
    z[10,9,5]  R2840     -3.3033466339111328e-01
    z[10,9,5]  R2841     3.2594287395477295e-01
    z[10,9,5]  R2842     5.4186254739761353e-02
    z[10,9,5]  R2843     -1.5071900188922882e-01
    z[10,9,5]  R2844     -2.9552176594734192e-01
    z[10,9,5]  R2845     -4.7624596953392029e-01
    z[10,9,5]  R2846     -4.1224356740713120e-02
    z[10,9,5]  R2847     -1.0179454833269119e-01
    z[10,9,5]  R2848     -1.2646009027957916e-01
    z[10,9,5]  R2849     -2.1688570082187653e-01
    z[10,9,5]  R2850     1.2357288040220737e-02
    z[10,9,5]  R2851     -7.3192939162254333e-02
    z[10,9,5]  R2852     -3.3099305629730225e-01
    z[10,9,5]  R2853     1.2673702836036682e-01
    z[10,9,5]  R2854     -1.1368635110557079e-02
    z[10,9,5]  R2855     1.4075355231761932e-01
    z[10,9,5]  R2856     -8.0980204045772552e-02
    z[10,9,5]  R2857     -1.8685216084122658e-02
    z[10,9,5]  R2858     8.7871748208999634e-01
    z[10,9,5]  R2859     5.2634340524673462e-01
    z[10,9,5]  R2860     2.1733374893665314e-01
    z[10,9,5]  R2861     4.6922564506530762e-02
    z[10,9,5]  R2862     1.9103546440601349e-01
    z[10,9,5]  R2863     6.2783464789390564e-02
    z[10,9,5]  R2864     1.5240314602851868e-01
    z[10,9,5]  R2865     2.6976841688156128e-01
    z[10,9,5]  R2866     -3.0798682570457458e-01
    z[10,9,5]  R2867     1.4860284328460693e-01
    z[10,9,5]  R2868     1.3143165409564972e-01
    z[10,9,5]  R2869     -4.7444548457860947e-02
    z[10,9,5]  R2870     3.9492752403020859e-02
    z[10,9,5]  R2871     1.9374240934848785e-01
    z[10,9,5]  R2872     1.3711906969547272e-01
    z[10,9,5]  R2873     -2.9747816920280457e-01
    z[10,9,5]  R2874     -4.3755255639553070e-02
    z[10,9,5]  R2875     -0.0848124623298645
    z[10,9,5]  R2876     2.2649076581001282e-01
    z[10,9,5]  R2877     3.8646966218948364e-01
    z[10,9,5]  R2878     -1.1627568304538727e-01
    z[10,9,5]  R2879     -6.1962295148987323e-05
    z[10,9,5]  R2880     1.3801721855998039e-02
    z[10,9,5]  R2881     -1.6287380456924438e-01
    z[10,9,5]  R2882     -2.6721358299255371e-01
    z[10,9,5]  R2883     1.9771657884120941e-01
    z[10,9,5]  R2884     -1.9833786785602570e-01
    z[10,9,5]  R2885     -2.3138357698917389e-01
    z[10,9,5]  R2886     7.0894765853881836e-01
    z[10,9,5]  R2887     -2.1792107820510864e-01
    z[10,9,5]  R2888     1.7922244966030121e-01
    z[10,9,5]  R2889     -1.1435023508965969e-02
    z[10,9,5]  R2890     -1.9206321239471436e-01
    z[10,9,5]  R2891     -1.3912537693977356e-01
    z[10,9,5]  R2892     1.3890877366065979e-01
    z[10,9,5]  R2893     3.0398979783058167e-01
    z[10,9,5]  R2894     2.2490348666906357e-02
    z[10,9,5]  R2895     5.2938252687454224e-01
    z[10,9,5]  R2896     1.2335211969912052e-02
    z[10,9,5]  R2897     -1.1504899710416794e-01
    z[10,9,5]  R2898     -1.7226109281182289e-02
    z[10,9,5]  R2899     1.8691466748714447e-01
    z[10,9,5]  R2900     4.3174274265766144e-02
    z[10,9,5]  R2901     6.5808288753032684e-02
    z[10,9,5]  R2902     1.3632968068122864e-01
    z[10,9,5]  R2903     -1.5600356459617615e-01
    z[10,9,5]  R2904     -2.0979729294776917e-01
    z[10,9,6]  R89       1
    z[10,9,6]  R98       -1
    z[10,9,6]  R2824     -1
    z[10,9,6]  R2825     1
    z[10,9,6]  R2826     2.7644306421279907e-01
    z[10,9,6]  R2827     6.7327147722244263e-01
    z[10,9,6]  R2828     -7.6228022575378418e-02
    z[10,9,6]  R2829     3.6781498789787292e-01
    z[10,9,6]  R2830     2.8878265619277954e-01
    z[10,9,6]  R2831     -4.1889244318008423e-01
    z[10,9,6]  R2832     -9.1430976986885071e-02
    z[10,9,6]  R2833     -2.0811778306961060e-01
    z[10,9,6]  R2834     -3.2275122404098511e-01
    z[10,9,6]  R2835     -4.4729572534561157e-01
    z[10,9,6]  R2836     -5.7501184940338135e-01
    z[10,9,6]  R2837     -1.4265993237495422e-01
    z[10,9,6]  R2838     -3.0545833706855774e-01
    z[10,9,6]  R2839     -1.6427166759967804e-01
    z[10,9,6]  R2840     2.0659960806369781e-01
    z[10,9,6]  R2841     -2.2668333351612091e-01
    z[10,9,6]  R2842     2.0110729336738586e-01
    z[10,9,6]  R2843     1.2507688999176025e-01
    z[10,9,6]  R2844     -1.3507668673992157e-01
    z[10,9,6]  R2845     -2.0407313108444214e-01
    z[10,9,6]  R2846     1.7033822834491730e-01
    z[10,9,6]  R2847     -4.6367627382278442e-01
    z[10,9,6]  R2848     0.197689488530159
    z[10,9,6]  R2849     3.9398968219757080e-02
    z[10,9,6]  R2850     1.2318865209817886e-01
    z[10,9,6]  R2851     -1.4014187268912792e-02
    z[10,9,6]  R2852     5.6017464399337769e-01
    z[10,9,6]  R2853     9.2212647199630737e-02
    z[10,9,6]  R2854     3.5562083125114441e-01
    z[10,9,6]  R2855     -2.2206236422061920e-01
    z[10,9,6]  R2856     -8.0214828252792358e-02
    z[10,9,6]  R2857     1.7276298999786377e-01
    z[10,9,6]  R2858     2.4914576113224030e-01
    z[10,9,6]  R2859     -4.4145914912223816e-01
    z[10,9,6]  R2860     -2.8837126493453979e-01
    z[10,9,6]  R2861     1.7233215272426605e-01
    z[10,9,6]  R2862     -3.0135154724121094e-01
    z[10,9,6]  R2863     -1.1381273716688156e-01
    z[10,9,6]  R2864     1.3115748763084412e-01
    z[10,9,6]  R2865     4.3380558490753174e-02
    z[10,9,6]  R2866     -2.0467959344387054e-01
    z[10,9,6]  R2867     1.7171584069728851e-01
    z[10,9,6]  R2868     3.3292478322982788e-01
    z[10,9,6]  R2869     1.5424039214849472e-02
    z[10,9,6]  R2870     5.0195235759019852e-02
    z[10,9,6]  R2871     -4.9056738615036011e-01
    z[10,9,6]  R2872     0.0674024224281311
    z[10,9,6]  R2873     -8.2106389105319977e-02
    z[10,9,6]  R2874     1.6777482815086842e-03
    z[10,9,6]  R2875     6.7161314189434052e-02
    z[10,9,6]  R2876     3.8654974102973938e-01
    z[10,9,6]  R2877     -1.0419576615095139e-01
    z[10,9,6]  R2878     1.7666088044643402e-01
    z[10,9,6]  R2879     1.2872123718261719e-01
    z[10,9,6]  R2880     9.6881859004497528e-02
    z[10,9,6]  R2881     2.2454324364662170e-01
    z[10,9,6]  R2882     -1.6983805224299431e-02
    z[10,9,6]  R2883     -1.0190619528293610e-01
    z[10,9,6]  R2884     -2.6259443163871765e-01
    z[10,9,6]  R2885     -2.7493588626384735e-02
    z[10,9,6]  R2886     4.3242105841636658e-01
    z[10,9,6]  R2887     1.8403728306293488e-01
    z[10,9,6]  R2888     -3.4229072928428650e-01
    z[10,9,6]  R2889     -2.5955277681350708e-01
    z[10,9,6]  R2890     -2.9613664746284485e-01
    z[10,9,6]  R2891     -1.6206017136573792e-01
    z[10,9,6]  R2892     1.3659252226352692e-01
    z[10,9,6]  R2893     -2.8309881687164307e-01
    z[10,9,6]  R2894     1.6889926046133041e-02
    z[10,9,6]  R2895     -6.4644539356231689e-01
    z[10,9,6]  R2896     -5.8095294237136841e-01
    z[10,9,6]  R2897     -1.4411937445402145e-02
    z[10,9,6]  R2898     -1.5400281548500061e-01
    z[10,9,6]  R2899     -1.2219013273715973e-01
    z[10,9,6]  R2900     1.5229758620262146e-01
    z[10,9,6]  R2901     0.218552827835083
    z[10,9,6]  R2902     -1.9323615729808807e-01
    z[10,9,6]  R2903     5.4894298315048218e-01
    z[10,9,6]  R2904     4.7479081153869629e-01
    length[0]  OBJ       1
    length[1]  OBJ       1
    length[2]  OBJ       1
    length[3]  OBJ       1
    length[4]  OBJ       1
    length[5]  OBJ       1
    length[6]  OBJ       1
    length[7]  OBJ       1
    length[8]  OBJ       1
    length[9]  OBJ       1
    length[10]  OBJ       1
    delta[0,0]  R2        1
    delta[0,1]  R3        1
    delta[0,2]  R4        1
    delta[0,3]  R5        1
    delta[0,4]  R6        1
    delta[0,5]  R7        1
    delta[0,6]  R8        1
    delta[1,0]  R11       1
    delta[1,1]  R12       1
    delta[1,2]  R13       1
    delta[1,3]  R14       1
    delta[1,4]  R15       1
    delta[1,5]  R16       1
    delta[1,6]  R17       1
    delta[2,0]  R20       1
    delta[2,1]  R21       1
    delta[2,2]  R22       1
    delta[2,3]  R23       1
    delta[2,4]  R24       1
    delta[2,5]  R25       1
    delta[2,6]  R26       1
    delta[3,0]  R29       1
    delta[3,1]  R30       1
    delta[3,2]  R31       1
    delta[3,3]  R32       1
    delta[3,4]  R33       1
    delta[3,5]  R34       1
    delta[3,6]  R35       1
    delta[4,0]  R38       1
    delta[4,1]  R39       1
    delta[4,2]  R40       1
    delta[4,3]  R41       1
    delta[4,4]  R42       1
    delta[4,5]  R43       1
    delta[4,6]  R44       1
    delta[5,0]  R47       1
    delta[5,1]  R48       1
    delta[5,2]  R49       1
    delta[5,3]  R50       1
    delta[5,4]  R51       1
    delta[5,5]  R52       1
    delta[5,6]  R53       1
    delta[6,0]  R56       1
    delta[6,1]  R57       1
    delta[6,2]  R58       1
    delta[6,3]  R59       1
    delta[6,4]  R60       1
    delta[6,5]  R61       1
    delta[6,6]  R62       1
    delta[7,0]  R65       1
    delta[7,1]  R66       1
    delta[7,2]  R67       1
    delta[7,3]  R68       1
    delta[7,4]  R69       1
    delta[7,5]  R70       1
    delta[7,6]  R71       1
    delta[8,0]  R74       1
    delta[8,1]  R75       1
    delta[8,2]  R76       1
    delta[8,3]  R77       1
    delta[8,4]  R78       1
    delta[8,5]  R79       1
    delta[8,6]  R80       1
    delta[9,0]  R83       1
    delta[9,1]  R84       1
    delta[9,2]  R85       1
    delta[9,3]  R86       1
    delta[9,4]  R87       1
    delta[9,5]  R88       1
    delta[9,6]  R89       1
    delta[10,0]  R92       1
    delta[10,1]  R93       1
    delta[10,2]  R94       1
    delta[10,3]  R95       1
    delta[10,4]  R96       1
    delta[10,5]  R97       1
    delta[10,6]  R98       1
RHS
    RHS1      R1        1
    RHS1      R10       1
    RHS1      R19       1
    RHS1      R28       1
    RHS1      R37       1
    RHS1      R46       1
    RHS1      R55       1
    RHS1      R64       1
    RHS1      R73       1
    RHS1      R82       1
    RHS1      R91       1
    RHS1      R99       1
    RHS1      R100      -1
BOUNDS
 BV BND1      phi[0,1]
 BV BND1      phi[1,0]
 BV BND1      phi[0,4]
 BV BND1      phi[4,0]
 BV BND1      phi[11,0]
 BV BND1      phi[1,2]
 BV BND1      phi[2,1]
 BV BND1      phi[2,3]
 BV BND1      phi[3,2]
 BV BND1      phi[2,10]
 BV BND1      phi[10,2]
 BV BND1      phi[3,10]
 BV BND1      phi[10,3]
 BV BND1      phi[3,12]
 BV BND1      phi[4,5]
 BV BND1      phi[5,4]
 BV BND1      phi[11,4]
 BV BND1      phi[5,6]
 BV BND1      phi[6,5]
 BV BND1      phi[6,7]
 BV BND1      phi[7,6]
 BV BND1      phi[7,8]
 BV BND1      phi[8,7]
 BV BND1      phi[8,9]
 BV BND1      phi[9,8]
 BV BND1      phi[9,10]
 BV BND1      phi[10,9]
 BV BND1      phi[10,12]
 FR BND1      z[0,1,0]
 FR BND1      z[0,1,1]
 FR BND1      z[0,1,2]
 FR BND1      z[0,1,3]
 FR BND1      z[0,1,4]
 FR BND1      z[0,1,5]
 FR BND1      z[0,1,6]
 FR BND1      z[1,0,0]
 FR BND1      z[1,0,1]
 FR BND1      z[1,0,2]
 FR BND1      z[1,0,3]
 FR BND1      z[1,0,4]
 FR BND1      z[1,0,5]
 FR BND1      z[1,0,6]
 FR BND1      z[0,4,0]
 FR BND1      z[0,4,1]
 FR BND1      z[0,4,2]
 FR BND1      z[0,4,3]
 FR BND1      z[0,4,4]
 FR BND1      z[0,4,5]
 FR BND1      z[0,4,6]
 FR BND1      z[4,0,0]
 FR BND1      z[4,0,1]
 FR BND1      z[4,0,2]
 FR BND1      z[4,0,3]
 FR BND1      z[4,0,4]
 FR BND1      z[4,0,5]
 FR BND1      z[4,0,6]
 FR BND1      z[1,2,0]
 FR BND1      z[1,2,1]
 FR BND1      z[1,2,2]
 FR BND1      z[1,2,3]
 FR BND1      z[1,2,4]
 FR BND1      z[1,2,5]
 FR BND1      z[1,2,6]
 FR BND1      z[2,1,0]
 FR BND1      z[2,1,1]
 FR BND1      z[2,1,2]
 FR BND1      z[2,1,3]
 FR BND1      z[2,1,4]
 FR BND1      z[2,1,5]
 FR BND1      z[2,1,6]
 FR BND1      z[2,3,0]
 FR BND1      z[2,3,1]
 FR BND1      z[2,3,2]
 FR BND1      z[2,3,3]
 FR BND1      z[2,3,4]
 FR BND1      z[2,3,5]
 FR BND1      z[2,3,6]
 FR BND1      z[3,2,0]
 FR BND1      z[3,2,1]
 FR BND1      z[3,2,2]
 FR BND1      z[3,2,3]
 FR BND1      z[3,2,4]
 FR BND1      z[3,2,5]
 FR BND1      z[3,2,6]
 FR BND1      z[2,10,0]
 FR BND1      z[2,10,1]
 FR BND1      z[2,10,2]
 FR BND1      z[2,10,3]
 FR BND1      z[2,10,4]
 FR BND1      z[2,10,5]
 FR BND1      z[2,10,6]
 FR BND1      z[10,2,0]
 FR BND1      z[10,2,1]
 FR BND1      z[10,2,2]
 FR BND1      z[10,2,3]
 FR BND1      z[10,2,4]
 FR BND1      z[10,2,5]
 FR BND1      z[10,2,6]
 FR BND1      z[3,10,0]
 FR BND1      z[3,10,1]
 FR BND1      z[3,10,2]
 FR BND1      z[3,10,3]
 FR BND1      z[3,10,4]
 FR BND1      z[3,10,5]
 FR BND1      z[3,10,6]
 FR BND1      z[10,3,0]
 FR BND1      z[10,3,1]
 FR BND1      z[10,3,2]
 FR BND1      z[10,3,3]
 FR BND1      z[10,3,4]
 FR BND1      z[10,3,5]
 FR BND1      z[10,3,6]
 FR BND1      z[4,5,0]
 FR BND1      z[4,5,1]
 FR BND1      z[4,5,2]
 FR BND1      z[4,5,3]
 FR BND1      z[4,5,4]
 FR BND1      z[4,5,5]
 FR BND1      z[4,5,6]
 FR BND1      z[5,4,0]
 FR BND1      z[5,4,1]
 FR BND1      z[5,4,2]
 FR BND1      z[5,4,3]
 FR BND1      z[5,4,4]
 FR BND1      z[5,4,5]
 FR BND1      z[5,4,6]
 FR BND1      z[5,6,0]
 FR BND1      z[5,6,1]
 FR BND1      z[5,6,2]
 FR BND1      z[5,6,3]
 FR BND1      z[5,6,4]
 FR BND1      z[5,6,5]
 FR BND1      z[5,6,6]
 FR BND1      z[6,5,0]
 FR BND1      z[6,5,1]
 FR BND1      z[6,5,2]
 FR BND1      z[6,5,3]
 FR BND1      z[6,5,4]
 FR BND1      z[6,5,5]
 FR BND1      z[6,5,6]
 FR BND1      z[6,7,0]
 FR BND1      z[6,7,1]
 FR BND1      z[6,7,2]
 FR BND1      z[6,7,3]
 FR BND1      z[6,7,4]
 FR BND1      z[6,7,5]
 FR BND1      z[6,7,6]
 FR BND1      z[7,6,0]
 FR BND1      z[7,6,1]
 FR BND1      z[7,6,2]
 FR BND1      z[7,6,3]
 FR BND1      z[7,6,4]
 FR BND1      z[7,6,5]
 FR BND1      z[7,6,6]
 FR BND1      z[7,8,0]
 FR BND1      z[7,8,1]
 FR BND1      z[7,8,2]
 FR BND1      z[7,8,3]
 FR BND1      z[7,8,4]
 FR BND1      z[7,8,5]
 FR BND1      z[7,8,6]
 FR BND1      z[8,7,0]
 FR BND1      z[8,7,1]
 FR BND1      z[8,7,2]
 FR BND1      z[8,7,3]
 FR BND1      z[8,7,4]
 FR BND1      z[8,7,5]
 FR BND1      z[8,7,6]
 FR BND1      z[8,9,0]
 FR BND1      z[8,9,1]
 FR BND1      z[8,9,2]
 FR BND1      z[8,9,3]
 FR BND1      z[8,9,4]
 FR BND1      z[8,9,5]
 FR BND1      z[8,9,6]
 FR BND1      z[9,8,0]
 FR BND1      z[9,8,1]
 FR BND1      z[9,8,2]
 FR BND1      z[9,8,3]
 FR BND1      z[9,8,4]
 FR BND1      z[9,8,5]
 FR BND1      z[9,8,6]
 FR BND1      z[9,10,0]
 FR BND1      z[9,10,1]
 FR BND1      z[9,10,2]
 FR BND1      z[9,10,3]
 FR BND1      z[9,10,4]
 FR BND1      z[9,10,5]
 FR BND1      z[9,10,6]
 FR BND1      z[10,9,0]
 FR BND1      z[10,9,1]
 FR BND1      z[10,9,2]
 FR BND1      z[10,9,3]
 FR BND1      z[10,9,4]
 FR BND1      z[10,9,5]
 FR BND1      z[10,9,6]
 FR BND1      delta[0,0]
 FR BND1      delta[0,1]
 FR BND1      delta[0,2]
 FR BND1      delta[0,3]
 FR BND1      delta[0,4]
 FR BND1      delta[0,5]
 FR BND1      delta[0,6]
 FR BND1      delta[1,0]
 FR BND1      delta[1,1]
 FR BND1      delta[1,2]
 FR BND1      delta[1,3]
 FR BND1      delta[1,4]
 FR BND1      delta[1,5]
 FR BND1      delta[1,6]
 FR BND1      delta[2,0]
 FR BND1      delta[2,1]
 FR BND1      delta[2,2]
 FR BND1      delta[2,3]
 FR BND1      delta[2,4]
 FR BND1      delta[2,5]
 FR BND1      delta[2,6]
 FR BND1      delta[3,0]
 FR BND1      delta[3,1]
 FR BND1      delta[3,2]
 FR BND1      delta[3,3]
 FR BND1      delta[3,4]
 FR BND1      delta[3,5]
 FR BND1      delta[3,6]
 FR BND1      delta[4,0]
 FR BND1      delta[4,1]
 FR BND1      delta[4,2]
 FR BND1      delta[4,3]
 FR BND1      delta[4,4]
 FR BND1      delta[4,5]
 FR BND1      delta[4,6]
 FR BND1      delta[5,0]
 FR BND1      delta[5,1]
 FR BND1      delta[5,2]
 FR BND1      delta[5,3]
 FR BND1      delta[5,4]
 FR BND1      delta[5,5]
 FR BND1      delta[5,6]
 FR BND1      delta[6,0]
 FR BND1      delta[6,1]
 FR BND1      delta[6,2]
 FR BND1      delta[6,3]
 FR BND1      delta[6,4]
 FR BND1      delta[6,5]
 FR BND1      delta[6,6]
 FR BND1      delta[7,0]
 FR BND1      delta[7,1]
 FR BND1      delta[7,2]
 FR BND1      delta[7,3]
 FR BND1      delta[7,4]
 FR BND1      delta[7,5]
 FR BND1      delta[7,6]
 FR BND1      delta[8,0]
 FR BND1      delta[8,1]
 FR BND1      delta[8,2]
 FR BND1      delta[8,3]
 FR BND1      delta[8,4]
 FR BND1      delta[8,5]
 FR BND1      delta[8,6]
 FR BND1      delta[9,0]
 FR BND1      delta[9,1]
 FR BND1      delta[9,2]
 FR BND1      delta[9,3]
 FR BND1      delta[9,4]
 FR BND1      delta[9,5]
 FR BND1      delta[9,6]
 FR BND1      delta[10,0]
 FR BND1      delta[10,1]
 FR BND1      delta[10,2]
 FR BND1      delta[10,3]
 FR BND1      delta[10,4]
 FR BND1      delta[10,5]
 FR BND1      delta[10,6]
QCMATRIX   qc0     
    length[0]  length[0]  -1
    delta[0,0]  delta[0,0]  1
    delta[0,1]  delta[0,1]  1
    delta[0,2]  delta[0,2]  1
    delta[0,3]  delta[0,3]  1
    delta[0,4]  delta[0,4]  1
    delta[0,5]  delta[0,5]  1
    delta[0,6]  delta[0,6]  1
QCMATRIX   qc1     
    length[1]  length[1]  -1
    delta[1,0]  delta[1,0]  1
    delta[1,1]  delta[1,1]  1
    delta[1,2]  delta[1,2]  1
    delta[1,3]  delta[1,3]  1
    delta[1,4]  delta[1,4]  1
    delta[1,5]  delta[1,5]  1
    delta[1,6]  delta[1,6]  1
QCMATRIX   qc2     
    length[2]  length[2]  -1
    delta[2,0]  delta[2,0]  1
    delta[2,1]  delta[2,1]  1
    delta[2,2]  delta[2,2]  1
    delta[2,3]  delta[2,3]  1
    delta[2,4]  delta[2,4]  1
    delta[2,5]  delta[2,5]  1
    delta[2,6]  delta[2,6]  1
QCMATRIX   qc3     
    length[3]  length[3]  -1
    delta[3,0]  delta[3,0]  1
    delta[3,1]  delta[3,1]  1
    delta[3,2]  delta[3,2]  1
    delta[3,3]  delta[3,3]  1
    delta[3,4]  delta[3,4]  1
    delta[3,5]  delta[3,5]  1
    delta[3,6]  delta[3,6]  1
QCMATRIX   qc4     
    length[4]  length[4]  -1
    delta[4,0]  delta[4,0]  1
    delta[4,1]  delta[4,1]  1
    delta[4,2]  delta[4,2]  1
    delta[4,3]  delta[4,3]  1
    delta[4,4]  delta[4,4]  1
    delta[4,5]  delta[4,5]  1
    delta[4,6]  delta[4,6]  1
QCMATRIX   qc5     
    length[5]  length[5]  -1
    delta[5,0]  delta[5,0]  1
    delta[5,1]  delta[5,1]  1
    delta[5,2]  delta[5,2]  1
    delta[5,3]  delta[5,3]  1
    delta[5,4]  delta[5,4]  1
    delta[5,5]  delta[5,5]  1
    delta[5,6]  delta[5,6]  1
QCMATRIX   qc6     
    length[6]  length[6]  -1
    delta[6,0]  delta[6,0]  1
    delta[6,1]  delta[6,1]  1
    delta[6,2]  delta[6,2]  1
    delta[6,3]  delta[6,3]  1
    delta[6,4]  delta[6,4]  1
    delta[6,5]  delta[6,5]  1
    delta[6,6]  delta[6,6]  1
QCMATRIX   qc7     
    length[7]  length[7]  -1
    delta[7,0]  delta[7,0]  1
    delta[7,1]  delta[7,1]  1
    delta[7,2]  delta[7,2]  1
    delta[7,3]  delta[7,3]  1
    delta[7,4]  delta[7,4]  1
    delta[7,5]  delta[7,5]  1
    delta[7,6]  delta[7,6]  1
QCMATRIX   qc8     
    length[8]  length[8]  -1
    delta[8,0]  delta[8,0]  1
    delta[8,1]  delta[8,1]  1
    delta[8,2]  delta[8,2]  1
    delta[8,3]  delta[8,3]  1
    delta[8,4]  delta[8,4]  1
    delta[8,5]  delta[8,5]  1
    delta[8,6]  delta[8,6]  1
QCMATRIX   qc9     
    length[9]  length[9]  -1
    delta[9,0]  delta[9,0]  1
    delta[9,1]  delta[9,1]  1
    delta[9,2]  delta[9,2]  1
    delta[9,3]  delta[9,3]  1
    delta[9,4]  delta[9,4]  1
    delta[9,5]  delta[9,5]  1
    delta[9,6]  delta[9,6]  1
QCMATRIX   qc10    
    length[10]  length[10]  -1
    delta[10,0]  delta[10,0]  1
    delta[10,1]  delta[10,1]  1
    delta[10,2]  delta[10,2]  1
    delta[10,3]  delta[10,3]  1
    delta[10,4]  delta[10,4]  1
    delta[10,5]  delta[10,5]  1
    delta[10,6]  delta[10,6]  1
ENDATA
