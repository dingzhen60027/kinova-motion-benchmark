NAME LGCS_GCS_Eq5_5_projected
ROWS
 N  OBJ
 E  R0      
 L  R1      
 E  R2      
 E  R3      
 E  R4      
 E  R5      
 E  R6      
 E  R7      
 E  R8      
 E  R9      
 L  R10     
 E  R11     
 E  R12     
 E  R13     
 E  R14     
 E  R15     
 E  R16     
 E  R17     
 E  R18     
 L  R19     
 E  R20     
 E  R21     
 E  R22     
 E  R23     
 E  R24     
 E  R25     
 E  R26     
 E  R27     
 L  R28     
 E  R29     
 E  R30     
 E  R31     
 E  R32     
 E  R33     
 E  R34     
 E  R35     
 E  R36     
 L  R37     
 E  R38     
 E  R39     
 E  R40     
 E  R41     
 E  R42     
 E  R43     
 E  R44     
 E  R45     
 L  R46     
 E  R47     
 E  R48     
 E  R49     
 E  R50     
 E  R51     
 E  R52     
 E  R53     
 E  R54     
 L  R55     
 E  R56     
 E  R57     
 E  R58     
 E  R59     
 E  R60     
 E  R61     
 E  R62     
 E  R63     
 L  R64     
 E  R65     
 E  R66     
 E  R67     
 E  R68     
 E  R69     
 E  R70     
 E  R71     
 E  R72     
 L  R73     
 E  R74     
 E  R75     
 E  R76     
 E  R77     
 E  R78     
 E  R79     
 E  R80     
 E  R81     
 L  R82     
 E  R83     
 E  R84     
 E  R85     
 E  R86     
 E  R87     
 E  R88     
 E  R89     
 E  R90     
 E  R91     
 L  R92     
 L  R93     
 L  R94     
 L  R95     
 L  R96     
 L  R97     
 L  R98     
 L  R99     
 L  R100    
 L  R101    
 L  R102    
 L  R103    
 L  R104    
 L  R105    
 L  R106    
 L  R107    
 L  R108    
 L  R109    
 L  R110    
 L  R111    
 L  R112    
 L  R113    
 L  R114    
 L  R115    
 L  R116    
 L  R117    
 L  R118    
 L  R119    
 L  R120    
 L  R121    
 L  R122    
 L  R123    
 L  R124    
 L  R125    
 L  R126    
 L  R127    
 L  R128    
 L  R129    
 L  R130    
 L  R131    
 L  R132    
 L  R133    
 L  R134    
 L  R135    
 L  R136    
 L  R137    
 L  R138    
 L  R139    
 L  R140    
 L  R141    
 L  R142    
 L  R143    
 L  R144    
 L  R145    
 L  R146    
 L  R147    
 L  R148    
 L  R149    
 L  R150    
 L  R151    
 L  R152    
 L  R153    
 L  R154    
 L  R155    
 L  R156    
 L  R157    
 L  R158    
 L  R159    
 L  R160    
 L  R161    
 L  R162    
 L  R163    
 L  R164    
 L  R165    
 L  R166    
 L  R167    
 L  R168    
 L  R169    
 L  R170    
 L  R171    
 L  R172    
 L  R173    
 L  R174    
 L  R175    
 L  R176    
 L  R177    
 L  R178    
 L  R179    
 L  R180    
 L  R181    
 L  R182    
 L  R183    
 L  R184    
 L  R185    
 L  R186    
 L  R187    
 L  R188    
 L  R189    
 L  R190    
 L  R191    
 L  R192    
 L  R193    
 L  R194    
 L  R195    
 L  R196    
 L  R197    
 L  R198    
 L  R199    
 L  R200    
 L  R201    
 L  R202    
 L  R203    
 L  R204    
 L  R205    
 L  R206    
 L  R207    
 L  R208    
 L  R209    
 L  R210    
 L  R211    
 L  R212    
 L  R213    
 L  R214    
 L  R215    
 L  R216    
 L  R217    
 L  R218    
 L  R219    
 L  R220    
 L  R221    
 L  R222    
 L  R223    
 L  R224    
 L  R225    
 L  R226    
 L  R227    
 L  R228    
 L  R229    
 L  R230    
 L  R231    
 L  R232    
 L  R233    
 L  R234    
 L  R235    
 L  R236    
 L  R237    
 L  R238    
 L  R239    
 L  R240    
 L  R241    
 L  R242    
 L  R243    
 L  R244    
 L  R245    
 L  R246    
 L  R247    
 L  R248    
 L  R249    
 L  R250    
 L  R251    
 L  R252    
 L  R253    
 L  R254    
 L  R255    
 L  R256    
 L  R257    
 L  R258    
 L  R259    
 L  R260    
 L  R261    
 L  R262    
 L  R263    
 L  R264    
 L  R265    
 L  R266    
 L  R267    
 L  R268    
 L  R269    
 L  R270    
 L  R271    
 L  R272    
 L  R273    
 L  R274    
 L  R275    
 L  R276    
 L  R277    
 L  R278    
 L  R279    
 L  R280    
 L  R281    
 L  R282    
 L  R283    
 L  R284    
 L  R285    
 L  R286    
 L  R287    
 L  R288    
 L  R289    
 L  R290    
 L  R291    
 L  R292    
 L  R293    
 L  R294    
 L  R295    
 L  R296    
 L  R297    
 L  R298    
 L  R299    
 L  R300    
 L  R301    
 L  R302    
 L  R303    
 L  R304    
 L  R305    
 L  R306    
 L  R307    
 L  R308    
 L  R309    
 L  R310    
 L  R311    
 L  R312    
 L  R313    
 L  R314    
 L  R315    
 L  R316    
 L  R317    
 L  R318    
 L  R319    
 L  R320    
 L  R321    
 L  R322    
 L  R323    
 L  R324    
 L  R325    
 L  R326    
 L  R327    
 L  R328    
 L  R329    
 L  R330    
 L  R331    
 L  R332    
 L  R333    
 L  R334    
 L  R335    
 L  R336    
 L  R337    
 L  R338    
 L  R339    
 L  R340    
 L  R341    
 L  R342    
 L  R343    
 L  R344    
 L  R345    
 L  R346    
 L  R347    
 L  R348    
 L  R349    
 L  R350    
 L  R351    
 L  R352    
 L  R353    
 L  R354    
 L  R355    
 L  R356    
 L  R357    
 L  R358    
 L  R359    
 L  R360    
 L  R361    
 L  R362    
 L  R363    
 L  R364    
 L  R365    
 L  R366    
 L  R367    
 L  R368    
 L  R369    
 L  R370    
 L  R371    
 L  R372    
 L  R373    
 L  R374    
 L  R375    
 L  R376    
 L  R377    
 L  R378    
 L  R379    
 L  R380    
 L  R381    
 L  R382    
 L  R383    
 L  R384    
 L  R385    
 L  R386    
 L  R387    
 L  R388    
 L  R389    
 L  R390    
 L  R391    
 L  R392    
 L  R393    
 L  R394    
 L  R395    
 L  R396    
 L  R397    
 L  R398    
 L  R399    
 L  R400    
 L  R401    
 L  R402    
 L  R403    
 L  R404    
 L  R405    
 L  R406    
 L  R407    
 L  R408    
 L  R409    
 L  R410    
 L  R411    
 L  R412    
 L  R413    
 L  R414    
 L  R415    
 L  R416    
 L  R417    
 L  R418    
 L  R419    
 L  R420    
 L  R421    
 L  R422    
 L  R423    
 L  R424    
 L  R425    
 L  R426    
 L  R427    
 L  R428    
 L  R429    
 L  R430    
 L  R431    
 L  R432    
 L  R433    
 L  R434    
 L  R435    
 L  R436    
 L  R437    
 L  R438    
 L  R439    
 L  R440    
 L  R441    
 L  R442    
 L  R443    
 L  R444    
 L  R445    
 L  R446    
 L  R447    
 L  R448    
 L  R449    
 L  R450    
 L  R451    
 L  R452    
 L  R453    
 L  R454    
 L  R455    
 L  R456    
 L  R457    
 L  R458    
 L  R459    
 L  R460    
 L  R461    
 L  R462    
 L  R463    
 L  R464    
 L  R465    
 L  R466    
 L  R467    
 L  R468    
 L  R469    
 L  R470    
 L  R471    
 L  R472    
 L  R473    
 L  R474    
 L  R475    
 L  R476    
 L  R477    
 L  R478    
 L  R479    
 L  R480    
 L  R481    
 L  R482    
 L  R483    
 L  R484    
 L  R485    
 L  R486    
 L  R487    
 L  R488    
 L  R489    
 L  R490    
 L  R491    
 L  R492    
 L  R493    
 L  R494    
 L  R495    
 L  R496    
 L  R497    
 L  R498    
 L  R499    
 L  R500    
 L  R501    
 L  R502    
 L  R503    
 L  R504    
 L  R505    
 L  R506    
 L  R507    
 L  R508    
 L  R509    
 L  R510    
 L  R511    
 L  R512    
 L  R513    
 L  R514    
 L  R515    
 L  R516    
 L  R517    
 L  R518    
 L  R519    
 L  R520    
 L  R521    
 L  R522    
 L  R523    
 L  R524    
 L  R525    
 L  R526    
 L  R527    
 L  R528    
 L  R529    
 L  R530    
 L  R531    
 L  R532    
 L  R533    
 L  R534    
 L  R535    
 L  R536    
 L  R537    
 L  R538    
 L  R539    
 L  R540    
 L  R541    
 L  R542    
 L  R543    
 L  R544    
 L  R545    
 L  R546    
 L  R547    
 L  R548    
 L  R549    
 L  R550    
 L  R551    
 L  R552    
 L  R553    
 L  R554    
 L  R555    
 L  R556    
 L  R557    
 L  R558    
 L  R559    
 L  R560    
 L  R561    
 L  R562    
 L  R563    
 L  R564    
 L  R565    
 L  R566    
 L  R567    
 L  R568    
 L  R569    
 L  R570    
 L  R571    
 L  R572    
 L  R573    
 L  R574    
 L  R575    
 L  R576    
 L  R577    
 L  R578    
 L  R579    
 L  R580    
 L  R581    
 L  R582    
 L  R583    
 L  R584    
 L  R585    
 L  R586    
 L  R587    
 L  R588    
 L  R589    
 L  R590    
 L  R591    
 L  R592    
 L  R593    
 L  R594    
 L  R595    
 L  R596    
 L  R597    
 L  R598    
 L  R599    
 L  R600    
 L  R601    
 L  R602    
 L  R603    
 L  R604    
 L  R605    
 L  R606    
 L  R607    
 L  R608    
 L  R609    
 L  R610    
 L  R611    
 L  R612    
 L  R613    
 L  R614    
 L  R615    
 L  R616    
 L  R617    
 L  R618    
 L  R619    
 L  R620    
 L  R621    
 L  R622    
 L  R623    
 L  R624    
 L  R625    
 L  R626    
 L  R627    
 L  R628    
 L  R629    
 L  R630    
 L  R631    
 L  R632    
 L  R633    
 L  R634    
 L  R635    
 L  R636    
 L  R637    
 L  R638    
 L  R639    
 L  R640    
 L  R641    
 L  R642    
 L  R643    
 L  R644    
 L  R645    
 L  R646    
 L  R647    
 L  R648    
 L  R649    
 L  R650    
 L  R651    
 L  R652    
 L  R653    
 L  R654    
 L  R655    
 L  R656    
 L  R657    
 L  R658    
 L  R659    
 L  R660    
 L  R661    
 L  R662    
 L  R663    
 L  R664    
 L  R665    
 L  R666    
 L  R667    
 L  R668    
 L  R669    
 L  R670    
 L  R671    
 L  R672    
 L  R673    
 L  R674    
 L  R675    
 L  R676    
 L  R677    
 L  R678    
 L  R679    
 L  R680    
 L  R681    
 L  R682    
 L  R683    
 L  R684    
 L  R685    
 L  R686    
 L  R687    
 L  R688    
 L  R689    
 L  R690    
 L  R691    
 L  R692    
 L  R693    
 L  R694    
 L  R695    
 L  R696    
 L  R697    
 L  R698    
 L  R699    
 L  R700    
 L  R701    
 L  R702    
 L  R703    
 L  R704    
 L  R705    
 L  R706    
 L  R707    
 L  R708    
 L  R709    
 L  R710    
 L  R711    
 L  R712    
 L  R713    
 L  R714    
 L  R715    
 L  R716    
 L  R717    
 L  R718    
 L  R719    
 L  R720    
 L  R721    
 L  R722    
 L  R723    
 L  R724    
 L  R725    
 L  R726    
 L  R727    
 L  R728    
 L  R729    
 L  R730    
 L  R731    
 L  R732    
 L  R733    
 L  R734    
 L  R735    
 L  R736    
 L  R737    
 L  R738    
 L  R739    
 L  R740    
 L  R741    
 L  R742    
 L  R743    
 L  R744    
 L  R745    
 L  R746    
 L  R747    
 L  R748    
 L  R749    
 L  R750    
 L  R751    
 L  R752    
 L  R753    
 L  R754    
 L  R755    
 L  R756    
 L  R757    
 L  R758    
 L  R759    
 L  R760    
 L  R761    
 L  R762    
 L  R763    
 L  R764    
 L  R765    
 L  R766    
 L  R767    
 L  R768    
 L  R769    
 L  R770    
 L  R771    
 L  R772    
 L  R773    
 L  R774    
 L  R775    
 L  R776    
 L  R777    
 L  R778    
 L  R779    
 L  R780    
 L  R781    
 L  R782    
 L  R783    
 L  R784    
 L  R785    
 L  R786    
 L  R787    
 L  R788    
 L  R789    
 L  R790    
 L  R791    
 L  R792    
 L  R793    
 L  R794    
 L  R795    
 L  R796    
 L  R797    
 L  R798    
 L  R799    
 L  R800    
 L  R801    
 L  R802    
 L  R803    
 L  R804    
 L  R805    
 L  R806    
 L  R807    
 L  R808    
 L  R809    
 L  R810    
 L  R811    
 L  R812    
 L  R813    
 L  R814    
 L  R815    
 L  R816    
 L  R817    
 L  R818    
 L  R819    
 L  R820    
 L  R821    
 L  R822    
 L  R823    
 L  R824    
 L  R825    
 L  R826    
 L  R827    
 L  R828    
 L  R829    
 L  R830    
 L  R831    
 L  R832    
 L  R833    
 L  R834    
 L  R835    
 L  R836    
 L  R837    
 L  R838    
 L  R839    
 L  R840    
 L  R841    
 L  R842    
 L  R843    
 L  R844    
 L  R845    
 L  R846    
 L  R847    
 L  R848    
 L  R849    
 L  R850    
 L  R851    
 L  R852    
 L  R853    
 L  R854    
 L  R855    
 L  R856    
 L  R857    
 L  R858    
 L  R859    
 L  R860    
 L  R861    
 L  R862    
 L  R863    
 L  R864    
 L  R865    
 L  R866    
 L  R867    
 L  R868    
 L  R869    
 L  R870    
 L  R871    
 L  R872    
 L  R873    
 L  R874    
 L  R875    
 L  R876    
 L  R877    
 L  R878    
 L  R879    
 L  R880    
 L  R881    
 L  R882    
 L  R883    
 L  R884    
 L  R885    
 L  R886    
 L  R887    
 L  R888    
 L  R889    
 L  R890    
 L  R891    
 L  R892    
 L  R893    
 L  R894    
 L  R895    
 L  R896    
 L  R897    
 L  R898    
 L  R899    
 L  R900    
 L  R901    
 L  R902    
 L  R903    
 L  R904    
 L  R905    
 L  R906    
 L  R907    
 L  R908    
 L  R909    
 L  R910    
 L  R911    
 L  R912    
 L  R913    
 L  R914    
 L  R915    
 L  R916    
 L  R917    
 L  R918    
 L  R919    
 L  R920    
 L  R921    
 L  R922    
 L  R923    
 L  R924    
 L  R925    
 L  R926    
 L  R927    
 L  R928    
 L  R929    
 L  R930    
 L  R931    
 L  R932    
 L  R933    
 L  R934    
 L  R935    
 L  R936    
 L  R937    
 L  R938    
 L  R939    
 L  R940    
 L  R941    
 L  R942    
 L  R943    
 L  R944    
 L  R945    
 L  R946    
 L  R947    
 L  R948    
 L  R949    
 L  R950    
 L  R951    
 L  R952    
 L  R953    
 L  R954    
 L  R955    
 L  R956    
 L  R957    
 L  R958    
 L  R959    
 L  R960    
 L  R961    
 L  R962    
 L  R963    
 L  R964    
 L  R965    
 L  R966    
 L  R967    
 L  R968    
 L  R969    
 L  R970    
 L  R971    
 L  R972    
 L  R973    
 L  R974    
 L  R975    
 L  R976    
 L  R977    
 L  R978    
 L  R979    
 L  R980    
 L  R981    
 L  R982    
 L  R983    
 L  R984    
 L  R985    
 L  R986    
 L  R987    
 L  R988    
 L  R989    
 L  R990    
 L  R991    
 L  R992    
 L  R993    
 L  R994    
 L  R995    
 L  R996    
 L  R997    
 L  R998    
 L  R999    
 L  R1000   
 L  R1001   
 L  R1002   
 L  R1003   
 L  R1004   
 L  R1005   
 L  R1006   
 L  R1007   
 L  R1008   
 L  R1009   
 L  R1010   
 L  R1011   
 L  R1012   
 L  R1013   
 L  R1014   
 L  R1015   
 L  R1016   
 L  R1017   
 L  R1018   
 L  R1019   
 L  R1020   
 L  R1021   
 L  R1022   
 L  R1023   
 L  R1024   
 L  R1025   
 L  R1026   
 L  R1027   
 L  R1028   
 L  R1029   
 L  R1030   
 L  R1031   
 L  R1032   
 L  R1033   
 L  R1034   
 L  R1035   
 L  R1036   
 L  R1037   
 L  R1038   
 L  R1039   
 L  R1040   
 L  R1041   
 L  R1042   
 L  R1043   
 L  R1044   
 L  R1045   
 L  R1046   
 L  R1047   
 L  R1048   
 L  R1049   
 L  R1050   
 L  R1051   
 L  R1052   
 L  R1053   
 L  R1054   
 L  R1055   
 L  R1056   
 L  R1057   
 L  R1058   
 L  R1059   
 L  R1060   
 L  R1061   
 L  R1062   
 L  R1063   
 L  R1064   
 L  R1065   
 L  R1066   
 L  R1067   
 L  R1068   
 L  R1069   
 L  R1070   
 L  R1071   
 L  R1072   
 L  R1073   
 L  R1074   
 L  R1075   
 L  R1076   
 L  R1077   
 L  R1078   
 L  R1079   
 L  R1080   
 L  R1081   
 L  R1082   
 L  R1083   
 L  R1084   
 L  R1085   
 L  R1086   
 L  R1087   
 L  R1088   
 L  R1089   
 L  R1090   
 L  R1091   
 L  R1092   
 L  R1093   
 L  R1094   
 L  R1095   
 L  R1096   
 L  R1097   
 L  R1098   
 L  R1099   
 L  R1100   
 L  R1101   
 L  R1102   
 L  R1103   
 L  R1104   
 L  R1105   
 L  R1106   
 L  R1107   
 L  R1108   
 L  R1109   
 L  R1110   
 L  R1111   
 L  R1112   
 L  R1113   
 L  R1114   
 L  R1115   
 L  R1116   
 L  R1117   
 L  R1118   
 L  R1119   
 L  R1120   
 L  R1121   
 L  R1122   
 L  R1123   
 L  R1124   
 L  R1125   
 L  R1126   
 L  R1127   
 L  R1128   
 L  R1129   
 L  R1130   
 L  R1131   
 L  R1132   
 L  R1133   
 L  R1134   
 L  R1135   
 L  R1136   
 L  R1137   
 L  R1138   
 L  R1139   
 L  R1140   
 L  R1141   
 L  R1142   
 L  R1143   
 L  R1144   
 L  R1145   
 L  R1146   
 L  R1147   
 L  R1148   
 L  R1149   
 L  R1150   
 L  R1151   
 L  R1152   
 L  R1153   
 L  R1154   
 L  R1155   
 L  R1156   
 L  R1157   
 L  R1158   
 L  R1159   
 L  R1160   
 L  R1161   
 L  R1162   
 L  R1163   
 L  R1164   
 L  R1165   
 L  R1166   
 L  R1167   
 L  R1168   
 L  R1169   
 L  R1170   
 L  R1171   
 L  R1172   
 L  R1173   
 L  R1174   
 L  R1175   
 L  R1176   
 L  R1177   
 L  R1178   
 L  R1179   
 L  R1180   
 L  R1181   
 L  R1182   
 L  R1183   
 L  R1184   
 L  R1185   
 L  R1186   
 L  R1187   
 L  R1188   
 L  R1189   
 L  R1190   
 L  R1191   
 L  R1192   
 L  R1193   
 L  R1194   
 L  R1195   
 L  R1196   
 L  R1197   
 L  R1198   
 L  R1199   
 L  R1200   
 L  R1201   
 L  R1202   
 L  R1203   
 L  R1204   
 L  R1205   
 L  R1206   
 L  R1207   
 L  R1208   
 L  R1209   
 L  R1210   
 L  R1211   
 L  R1212   
 L  R1213   
 L  R1214   
 L  R1215   
 L  R1216   
 L  R1217   
 L  R1218   
 L  R1219   
 L  R1220   
 L  R1221   
 L  R1222   
 L  R1223   
 L  R1224   
 L  R1225   
 L  R1226   
 L  R1227   
 L  R1228   
 L  R1229   
 L  R1230   
 L  R1231   
 L  R1232   
 L  R1233   
 L  R1234   
 L  R1235   
 L  R1236   
 L  R1237   
 L  R1238   
 L  R1239   
 L  R1240   
 L  R1241   
 L  R1242   
 L  R1243   
 L  R1244   
 L  R1245   
 L  R1246   
 L  R1247   
 L  R1248   
 L  R1249   
 L  R1250   
 L  R1251   
 L  R1252   
 L  R1253   
 L  R1254   
 L  R1255   
 L  R1256   
 L  R1257   
 L  R1258   
 L  R1259   
 L  R1260   
 L  R1261   
 L  R1262   
 L  R1263   
 L  R1264   
 L  R1265   
 L  R1266   
 L  R1267   
 L  R1268   
 L  R1269   
 L  R1270   
 L  R1271   
 L  R1272   
 L  R1273   
 L  R1274   
 L  R1275   
 L  R1276   
 L  R1277   
 L  R1278   
 L  R1279   
 L  R1280   
 L  R1281   
 L  R1282   
 L  R1283   
 L  R1284   
 L  R1285   
 L  R1286   
 L  R1287   
 L  R1288   
 L  R1289   
 L  R1290   
 L  R1291   
 L  R1292   
 L  R1293   
 L  R1294   
 L  R1295   
 L  R1296   
 L  R1297   
 L  R1298   
 L  R1299   
 L  R1300   
 L  R1301   
 L  R1302   
 L  R1303   
 L  R1304   
 L  R1305   
 L  R1306   
 L  R1307   
 L  R1308   
 L  R1309   
 L  R1310   
 L  R1311   
 L  R1312   
 L  R1313   
 L  R1314   
 L  R1315   
 L  R1316   
 L  R1317   
 L  R1318   
 L  R1319   
 L  R1320   
 L  R1321   
 L  R1322   
 L  R1323   
 L  R1324   
 L  R1325   
 L  R1326   
 L  R1327   
 L  R1328   
 L  R1329   
 L  R1330   
 L  R1331   
 L  R1332   
 L  R1333   
 L  R1334   
 L  R1335   
 L  R1336   
 L  R1337   
 L  R1338   
 L  R1339   
 L  R1340   
 L  R1341   
 L  R1342   
 L  R1343   
 L  R1344   
 L  R1345   
 L  R1346   
 L  R1347   
 L  R1348   
 L  R1349   
 L  R1350   
 L  R1351   
 L  R1352   
 L  R1353   
 L  R1354   
 L  R1355   
 L  R1356   
 L  R1357   
 L  R1358   
 L  R1359   
 L  R1360   
 L  R1361   
 L  R1362   
 L  R1363   
 L  R1364   
 L  R1365   
 L  R1366   
 L  R1367   
 L  R1368   
 L  R1369   
 L  R1370   
 L  R1371   
 L  R1372   
 L  R1373   
 L  R1374   
 L  R1375   
 L  R1376   
 L  R1377   
 L  R1378   
 L  R1379   
 L  R1380   
 L  R1381   
 L  R1382   
 L  R1383   
 L  R1384   
 L  R1385   
 L  R1386   
 L  R1387   
 L  R1388   
 L  R1389   
 L  R1390   
 L  R1391   
 L  R1392   
 L  R1393   
 L  R1394   
 L  R1395   
 L  R1396   
 L  R1397   
 L  R1398   
 L  R1399   
 L  R1400   
 L  R1401   
 L  R1402   
 L  R1403   
 L  R1404   
 L  R1405   
 L  R1406   
 L  R1407   
 L  R1408   
 L  R1409   
 L  R1410   
 L  R1411   
 L  R1412   
 L  R1413   
 L  R1414   
 L  R1415   
 L  R1416   
 L  R1417   
 L  R1418   
 L  R1419   
 L  R1420   
 L  R1421   
 L  R1422   
 L  R1423   
 L  R1424   
 L  R1425   
 L  R1426   
 L  R1427   
 L  R1428   
 L  R1429   
 L  R1430   
 L  R1431   
 L  R1432   
 L  R1433   
 L  R1434   
 L  R1435   
 L  R1436   
 L  R1437   
 L  R1438   
 L  R1439   
 L  R1440   
 L  R1441   
 L  R1442   
 L  R1443   
 L  R1444   
 L  R1445   
 L  R1446   
 L  R1447   
 L  R1448   
 L  R1449   
 L  R1450   
 L  R1451   
 L  R1452   
 L  R1453   
 L  R1454   
 L  R1455   
 L  R1456   
 L  R1457   
 L  R1458   
 L  R1459   
 L  R1460   
 L  R1461   
 L  R1462   
 L  R1463   
 L  R1464   
 L  R1465   
 L  R1466   
 L  R1467   
 L  R1468   
 L  R1469   
 L  R1470   
 L  R1471   
 L  R1472   
 L  R1473   
 L  R1474   
 L  R1475   
 L  R1476   
 L  R1477   
 L  R1478   
 L  R1479   
 L  R1480   
 L  R1481   
 L  R1482   
 L  R1483   
 L  R1484   
 L  R1485   
 L  R1486   
 L  R1487   
 L  R1488   
 L  R1489   
 L  R1490   
 L  R1491   
 L  R1492   
 L  R1493   
 L  R1494   
 L  R1495   
 L  R1496   
 L  R1497   
 L  R1498   
 L  R1499   
 L  R1500   
 L  R1501   
 L  R1502   
 L  R1503   
 L  R1504   
 L  R1505   
 L  R1506   
 L  R1507   
 L  R1508   
 L  R1509   
 L  R1510   
 L  R1511   
 L  R1512   
 L  R1513   
 L  R1514   
 L  R1515   
 L  R1516   
 L  R1517   
 L  R1518   
 L  R1519   
 L  R1520   
 L  R1521   
 L  R1522   
 L  R1523   
 L  R1524   
 L  R1525   
 L  R1526   
 L  R1527   
 L  R1528   
 L  R1529   
 L  R1530   
 L  R1531   
 L  R1532   
 L  R1533   
 L  R1534   
 L  R1535   
 L  R1536   
 L  R1537   
 L  R1538   
 L  R1539   
 L  R1540   
 L  R1541   
 L  R1542   
 L  R1543   
 L  R1544   
 L  R1545   
 L  R1546   
 L  R1547   
 L  R1548   
 L  R1549   
 L  R1550   
 L  R1551   
 L  R1552   
 L  R1553   
 L  R1554   
 L  R1555   
 L  R1556   
 L  R1557   
 L  R1558   
 L  R1559   
 L  R1560   
 L  R1561   
 L  R1562   
 L  R1563   
 L  R1564   
 L  R1565   
 L  R1566   
 L  R1567   
 L  R1568   
 L  R1569   
 L  R1570   
 L  R1571   
 L  R1572   
 L  R1573   
 L  R1574   
 L  R1575   
 L  R1576   
 L  R1577   
 L  R1578   
 L  R1579   
 L  R1580   
 L  R1581   
 L  R1582   
 L  R1583   
 L  R1584   
 L  R1585   
 L  R1586   
 L  R1587   
 L  R1588   
 L  R1589   
 L  R1590   
 L  R1591   
 L  R1592   
 L  R1593   
 L  R1594   
 L  R1595   
 L  R1596   
 L  R1597   
 L  R1598   
 L  R1599   
 L  R1600   
 L  R1601   
 L  R1602   
 L  R1603   
 L  R1604   
 L  R1605   
 L  R1606   
 L  R1607   
 L  R1608   
 L  R1609   
 L  R1610   
 L  R1611   
 L  R1612   
 L  R1613   
 L  R1614   
 L  R1615   
 L  R1616   
 L  R1617   
 L  R1618   
 L  R1619   
 L  R1620   
 L  R1621   
 L  R1622   
 L  R1623   
 L  R1624   
 L  R1625   
 L  R1626   
 L  R1627   
 L  R1628   
 L  R1629   
 L  R1630   
 L  R1631   
 L  R1632   
 L  R1633   
 L  R1634   
 L  R1635   
 L  R1636   
 L  R1637   
 L  R1638   
 L  R1639   
 L  R1640   
 L  R1641   
 L  R1642   
 L  R1643   
 L  R1644   
 L  R1645   
 L  R1646   
 L  R1647   
 L  R1648   
 L  R1649   
 L  R1650   
 L  R1651   
 L  R1652   
 L  R1653   
 L  R1654   
 L  R1655   
 L  R1656   
 L  R1657   
 L  R1658   
 L  R1659   
 L  R1660   
 L  R1661   
 L  R1662   
 L  R1663   
 L  R1664   
 L  R1665   
 L  R1666   
 L  R1667   
 L  R1668   
 L  R1669   
 L  R1670   
 L  R1671   
 L  R1672   
 L  R1673   
 L  R1674   
 L  R1675   
 L  R1676   
 L  R1677   
 L  R1678   
 L  R1679   
 L  R1680   
 L  R1681   
 L  R1682   
 L  R1683   
 L  R1684   
 L  R1685   
 L  R1686   
 L  R1687   
 L  R1688   
 L  R1689   
 L  R1690   
 L  R1691   
 L  R1692   
 L  R1693   
 L  R1694   
 L  R1695   
 L  R1696   
 L  R1697   
 L  R1698   
 L  R1699   
 L  R1700   
 L  R1701   
 L  R1702   
 L  R1703   
 L  R1704   
 L  R1705   
 L  R1706   
 L  R1707   
 L  R1708   
 L  R1709   
 L  R1710   
 L  R1711   
 L  R1712   
 L  R1713   
 L  R1714   
 L  R1715   
 L  R1716   
 L  R1717   
 L  R1718   
 L  R1719   
 L  R1720   
 L  R1721   
 L  R1722   
 L  R1723   
 L  R1724   
 L  R1725   
 L  R1726   
 L  R1727   
 L  R1728   
 L  R1729   
 L  R1730   
 L  R1731   
 L  R1732   
 L  R1733   
 L  R1734   
 L  R1735   
 L  R1736   
 L  R1737   
 L  R1738   
 L  R1739   
 L  R1740   
 L  R1741   
 L  R1742   
 L  R1743   
 L  R1744   
 L  R1745   
 L  R1746   
 L  R1747   
 L  R1748   
 L  R1749   
 L  R1750   
 L  R1751   
 L  R1752   
 L  R1753   
 L  R1754   
 L  R1755   
 L  R1756   
 L  R1757   
 L  R1758   
 L  R1759   
 L  R1760   
 L  R1761   
 L  R1762   
 L  R1763   
 L  R1764   
 L  R1765   
 L  R1766   
 L  R1767   
 L  R1768   
 L  R1769   
 L  R1770   
 L  R1771   
 L  R1772   
 L  R1773   
 L  R1774   
 L  R1775   
 L  R1776   
 L  R1777   
 L  R1778   
 L  R1779   
 L  R1780   
 L  R1781   
 L  R1782   
 L  R1783   
 L  R1784   
 L  R1785   
 L  R1786   
 L  R1787   
 L  R1788   
 L  R1789   
 L  R1790   
 L  R1791   
 L  R1792   
 L  R1793   
 L  R1794   
 L  R1795   
 L  R1796   
 L  R1797   
 L  R1798   
 L  R1799   
 L  R1800   
 L  R1801   
 L  R1802   
 L  R1803   
 L  R1804   
 L  R1805   
 L  R1806   
 L  R1807   
 L  R1808   
 L  R1809   
 L  R1810   
 L  R1811   
 L  R1812   
 L  R1813   
 L  R1814   
 L  R1815   
 L  R1816   
 L  R1817   
 L  R1818   
 L  R1819   
 L  R1820   
 L  R1821   
 L  R1822   
 L  R1823   
 L  R1824   
 L  R1825   
 L  R1826   
 L  R1827   
 L  R1828   
 L  R1829   
 L  R1830   
 L  R1831   
 L  R1832   
 L  R1833   
 L  R1834   
 L  R1835   
 L  R1836   
 L  R1837   
 L  R1838   
 L  R1839   
 L  R1840   
 L  R1841   
 L  R1842   
 L  R1843   
 L  R1844   
 L  R1845   
 L  R1846   
 L  R1847   
 L  R1848   
 L  R1849   
 L  R1850   
 L  R1851   
 L  R1852   
 L  R1853   
 L  R1854   
 L  R1855   
 L  R1856   
 L  R1857   
 L  R1858   
 L  R1859   
 L  R1860   
 L  R1861   
 L  R1862   
 L  R1863   
 L  R1864   
 L  R1865   
 L  R1866   
 L  R1867   
 L  R1868   
 L  R1869   
 L  R1870   
 L  R1871   
 L  R1872   
 L  R1873   
 L  R1874   
 L  R1875   
 L  R1876   
 L  R1877   
 L  R1878   
 L  R1879   
 L  R1880   
 L  R1881   
 L  R1882   
 L  R1883   
 L  R1884   
 L  R1885   
 L  R1886   
 L  R1887   
 L  R1888   
 L  R1889   
 L  R1890   
 L  R1891   
 L  R1892   
 L  R1893   
 L  R1894   
 L  R1895   
 L  R1896   
 L  R1897   
 L  R1898   
 L  R1899   
 L  R1900   
 L  R1901   
 L  R1902   
 L  R1903   
 L  R1904   
 L  R1905   
 L  R1906   
 L  R1907   
 L  R1908   
 L  R1909   
 L  R1910   
 L  R1911   
 L  R1912   
 L  R1913   
 L  R1914   
 L  R1915   
 L  R1916   
 L  R1917   
 L  R1918   
 L  R1919   
 L  R1920   
 L  R1921   
 L  R1922   
 L  R1923   
 L  R1924   
 L  R1925   
 L  R1926   
 L  R1927   
 L  R1928   
 L  R1929   
 L  R1930   
 L  R1931   
 L  R1932   
 L  R1933   
 L  R1934   
 L  R1935   
 L  R1936   
 L  R1937   
 L  R1938   
 L  R1939   
 L  R1940   
 L  R1941   
 L  R1942   
 L  R1943   
 L  R1944   
 L  R1945   
 L  R1946   
 L  R1947   
 L  R1948   
 L  R1949   
 L  R1950   
 L  R1951   
 L  R1952   
 L  R1953   
 L  R1954   
 L  R1955   
 L  R1956   
 L  R1957   
 L  R1958   
 L  R1959   
 L  R1960   
 L  R1961   
 L  R1962   
 L  R1963   
 L  R1964   
 L  R1965   
 L  R1966   
 L  R1967   
 L  R1968   
 L  R1969   
 L  R1970   
 L  R1971   
 L  R1972   
 L  R1973   
 L  R1974   
 L  R1975   
 L  R1976   
 L  R1977   
 L  R1978   
 L  R1979   
 L  R1980   
 L  R1981   
 L  R1982   
 L  R1983   
 L  R1984   
 L  R1985   
 L  R1986   
 L  R1987   
 L  R1988   
 L  R1989   
 L  R1990   
 L  R1991   
 L  R1992   
 L  R1993   
 L  R1994   
 L  R1995   
 L  R1996   
 L  R1997   
 L  R1998   
 L  R1999   
 L  R2000   
 L  R2001   
 L  R2002   
 L  R2003   
 L  R2004   
 L  R2005   
 L  R2006   
 L  R2007   
 L  R2008   
 L  R2009   
 L  R2010   
 L  R2011   
 L  R2012   
 L  R2013   
 L  R2014   
 L  R2015   
 L  R2016   
 L  R2017   
 L  R2018   
 L  R2019   
 L  R2020   
 L  R2021   
 L  R2022   
 L  R2023   
 L  R2024   
 L  R2025   
 L  R2026   
 L  R2027   
 L  R2028   
 L  R2029   
 L  R2030   
 L  R2031   
 L  R2032   
 L  R2033   
 L  R2034   
 L  R2035   
 L  R2036   
 L  R2037   
 L  R2038   
 L  R2039   
 L  R2040   
 L  R2041   
 L  R2042   
 L  R2043   
 L  R2044   
 L  R2045   
 L  R2046   
 L  R2047   
 L  R2048   
 L  R2049   
 L  R2050   
 L  R2051   
 L  R2052   
 L  R2053   
 L  R2054   
 L  R2055   
 L  R2056   
 L  R2057   
 L  R2058   
 L  R2059   
 L  R2060   
 L  R2061   
 L  R2062   
 L  R2063   
 L  R2064   
 L  R2065   
 L  R2066   
 L  R2067   
 L  R2068   
 L  R2069   
 L  R2070   
 L  R2071   
 L  R2072   
 L  R2073   
 L  R2074   
 L  R2075   
 L  R2076   
 L  R2077   
 L  R2078   
 L  R2079   
 L  R2080   
 L  R2081   
 L  R2082   
 L  R2083   
 L  R2084   
 L  R2085   
 L  R2086   
 L  R2087   
 L  R2088   
 L  R2089   
 L  R2090   
 L  R2091   
 L  R2092   
 L  R2093   
 L  R2094   
 L  R2095   
 L  R2096   
 L  R2097   
 L  R2098   
 L  R2099   
 L  R2100   
 L  R2101   
 L  R2102   
 L  R2103   
 L  R2104   
 L  R2105   
 L  R2106   
 L  R2107   
 L  R2108   
 L  R2109   
 L  R2110   
 L  R2111   
 L  R2112   
 L  R2113   
 L  R2114   
 L  R2115   
 L  R2116   
 L  R2117   
 L  R2118   
 L  R2119   
 L  R2120   
 L  R2121   
 L  R2122   
 L  R2123   
 L  R2124   
 L  R2125   
 L  R2126   
 L  R2127   
 L  R2128   
 L  R2129   
 L  R2130   
 L  R2131   
 L  R2132   
 L  R2133   
 L  R2134   
 L  R2135   
 L  R2136   
 L  R2137   
 L  R2138   
 L  R2139   
 L  R2140   
 L  R2141   
 L  R2142   
 L  R2143   
 L  R2144   
 L  R2145   
 L  R2146   
 L  R2147   
 L  R2148   
 L  R2149   
 L  R2150   
 L  R2151   
 L  R2152   
 L  R2153   
 L  R2154   
 L  R2155   
 L  R2156   
 L  R2157   
 L  R2158   
 L  R2159   
 L  R2160   
 L  R2161   
 L  R2162   
 L  R2163   
 L  R2164   
 L  R2165   
 L  R2166   
 L  R2167   
 L  R2168   
 L  R2169   
 L  R2170   
 L  R2171   
 L  R2172   
 L  R2173   
 L  R2174   
 L  R2175   
 L  R2176   
 L  R2177   
 L  R2178   
 L  R2179   
 L  R2180   
 L  R2181   
 L  R2182   
 L  R2183   
 L  R2184   
 L  R2185   
 L  R2186   
 L  R2187   
 L  R2188   
 L  R2189   
 L  R2190   
 L  R2191   
 L  R2192   
 L  R2193   
 L  R2194   
 L  R2195   
 L  R2196   
 L  R2197   
 L  R2198   
 L  R2199   
 L  R2200   
 L  R2201   
 L  R2202   
 L  R2203   
 L  R2204   
 L  R2205   
 L  R2206   
 L  R2207   
 L  R2208   
 L  R2209   
 L  R2210   
 L  R2211   
 L  R2212   
 L  R2213   
 L  R2214   
 L  R2215   
 L  R2216   
 L  R2217   
 L  R2218   
 L  R2219   
 L  R2220   
 L  R2221   
 L  R2222   
 L  R2223   
 L  R2224   
 L  R2225   
 L  R2226   
 L  R2227   
 L  R2228   
 L  R2229   
 L  R2230   
 L  R2231   
 L  R2232   
 L  R2233   
 L  R2234   
 L  R2235   
 L  R2236   
 L  R2237   
 L  R2238   
 L  R2239   
 L  R2240   
 L  R2241   
 L  R2242   
 L  R2243   
 L  R2244   
 L  R2245   
 L  R2246   
 L  R2247   
 L  R2248   
 L  R2249   
 L  R2250   
 L  R2251   
 L  R2252   
 L  R2253   
 L  R2254   
 L  R2255   
 L  R2256   
 L  R2257   
 L  R2258   
 L  R2259   
 L  R2260   
 L  R2261   
 L  R2262   
 L  R2263   
 L  R2264   
 L  R2265   
 L  R2266   
 L  R2267   
 L  R2268   
 L  R2269   
 L  R2270   
 L  R2271   
 L  R2272   
 L  R2273   
 L  R2274   
 L  R2275   
 L  R2276   
 L  R2277   
 L  R2278   
 L  R2279   
 L  R2280   
 L  R2281   
 L  R2282   
 L  R2283   
 L  R2284   
 L  R2285   
 L  R2286   
 L  R2287   
 L  R2288   
 L  R2289   
 L  R2290   
 L  R2291   
 L  R2292   
 L  R2293   
 L  R2294   
 L  R2295   
 L  R2296   
 L  R2297   
 L  R2298   
 L  R2299   
 L  R2300   
 L  R2301   
 L  R2302   
 L  R2303   
 L  R2304   
 L  R2305   
 L  R2306   
 L  R2307   
 L  R2308   
 L  R2309   
 L  R2310   
 L  R2311   
 L  R2312   
 L  R2313   
 L  R2314   
 L  R2315   
 L  R2316   
 L  R2317   
 L  R2318   
 L  R2319   
 L  R2320   
 L  R2321   
 L  R2322   
 L  R2323   
 L  R2324   
 L  R2325   
 L  R2326   
 L  R2327   
 L  R2328   
 L  R2329   
 L  R2330   
 L  R2331   
 L  R2332   
 L  R2333   
 L  R2334   
 L  R2335   
 L  R2336   
 L  R2337   
 L  R2338   
 L  R2339   
 L  R2340   
 L  R2341   
 L  R2342   
 L  R2343   
 L  R2344   
 L  R2345   
 L  R2346   
 L  R2347   
 L  R2348   
 L  R2349   
 L  R2350   
 L  R2351   
 L  R2352   
 L  R2353   
 L  R2354   
 L  R2355   
 L  R2356   
 L  R2357   
 L  R2358   
 L  R2359   
 L  R2360   
 L  R2361   
 L  R2362   
 L  R2363   
 L  R2364   
 L  R2365   
 L  R2366   
 L  R2367   
 L  R2368   
 L  R2369   
 L  R2370   
 L  R2371   
 L  R2372   
 L  R2373   
 L  R2374   
 L  R2375   
 L  R2376   
 L  R2377   
 L  R2378   
 L  R2379   
 L  R2380   
 L  R2381   
 L  R2382   
 L  R2383   
 L  R2384   
 L  R2385   
 L  R2386   
 L  R2387   
 L  R2388   
 L  R2389   
 L  R2390   
 L  R2391   
 L  R2392   
 L  R2393   
 L  R2394   
 L  R2395   
 L  R2396   
 L  R2397   
 L  R2398   
 L  R2399   
 L  R2400   
 L  R2401   
 L  R2402   
 L  R2403   
 L  R2404   
 L  R2405   
 L  R2406   
 L  R2407   
 L  R2408   
 L  R2409   
 L  R2410   
 L  R2411   
 L  R2412   
 L  R2413   
 L  R2414   
 L  R2415   
 L  R2416   
 L  R2417   
 L  R2418   
 L  R2419   
 L  R2420   
 L  R2421   
 L  R2422   
 L  R2423   
 L  R2424   
 L  R2425   
 L  R2426   
 L  R2427   
 L  R2428   
 L  R2429   
 L  R2430   
 L  R2431   
 L  R2432   
 L  R2433   
 L  R2434   
 L  R2435   
 L  R2436   
 L  R2437   
 L  R2438   
 L  R2439   
 L  R2440   
 L  R2441   
 L  R2442   
 L  R2443   
 L  R2444   
 L  R2445   
 L  R2446   
 L  R2447   
 L  R2448   
 L  R2449   
 L  R2450   
 L  R2451   
 L  R2452   
 L  R2453   
 L  R2454   
 L  R2455   
 L  R2456   
 L  R2457   
 L  R2458   
 L  R2459   
 L  R2460   
 L  R2461   
 L  R2462   
 L  R2463   
 L  R2464   
 L  R2465   
 L  R2466   
 L  R2467   
 L  R2468   
 L  R2469   
 L  R2470   
 L  R2471   
 L  R2472   
 L  R2473   
 L  R2474   
 L  R2475   
 L  R2476   
 L  R2477   
 L  R2478   
 L  R2479   
 L  R2480   
 L  R2481   
 L  R2482   
 L  R2483   
 L  R2484   
 L  R2485   
 L  R2486   
 L  R2487   
 L  R2488   
 L  R2489   
 L  R2490   
 L  R2491   
 L  R2492   
 L  R2493   
 L  R2494   
 L  R2495   
 L  R2496   
 L  R2497   
 L  R2498   
 L  R2499   
 L  R2500   
 L  R2501   
 L  R2502   
 L  R2503   
 L  R2504   
 L  R2505   
 L  R2506   
 L  R2507   
 L  R2508   
 L  R2509   
 L  R2510   
 L  R2511   
 L  R2512   
 L  R2513   
 L  R2514   
 L  R2515   
 L  R2516   
 L  R2517   
 L  R2518   
 L  R2519   
 L  R2520   
 L  R2521   
 L  R2522   
 L  R2523   
 L  R2524   
 L  R2525   
 L  R2526   
 L  R2527   
 L  R2528   
 L  R2529   
 L  R2530   
 L  R2531   
 L  R2532   
 L  R2533   
 L  R2534   
 L  R2535   
 L  R2536   
 L  R2537   
 L  R2538   
 L  R2539   
 L  R2540   
 L  R2541   
 L  R2542   
 L  R2543   
 L  R2544   
 L  R2545   
 L  R2546   
 L  R2547   
 L  R2548   
 L  R2549   
 L  R2550   
 L  R2551   
 L  R2552   
 L  R2553   
 L  R2554   
 L  R2555   
 L  R2556   
 L  R2557   
 L  R2558   
 L  R2559   
 L  R2560   
 L  R2561   
 L  R2562   
 L  R2563   
 L  R2564   
 L  R2565   
 L  R2566   
 L  R2567   
 L  R2568   
 L  R2569   
 L  R2570   
 L  R2571   
 L  R2572   
 L  R2573   
 L  R2574   
 L  R2575   
 L  R2576   
 L  R2577   
 L  R2578   
 L  R2579   
 L  R2580   
 L  R2581   
 L  R2582   
 L  R2583   
 L  R2584   
 L  R2585   
 L  R2586   
 L  R2587   
 L  R2588   
 L  R2589   
 L  R2590   
 L  R2591   
 L  R2592   
 L  R2593   
 L  R2594   
 L  R2595   
 L  R2596   
 L  R2597   
 L  R2598   
 L  R2599   
 L  R2600   
 L  R2601   
 L  R2602   
 L  R2603   
 L  R2604   
 L  R2605   
 L  R2606   
 L  R2607   
 L  R2608   
 L  R2609   
 L  R2610   
 L  R2611   
 L  R2612   
 L  R2613   
 L  R2614   
 L  R2615   
 L  R2616   
 L  R2617   
 L  R2618   
 L  R2619   
 L  R2620   
 L  R2621   
 L  R2622   
 L  R2623   
 L  R2624   
 L  R2625   
 L  R2626   
 L  R2627   
 L  R2628   
 L  R2629   
 L  R2630   
 L  R2631   
 L  R2632   
 L  R2633   
 L  R2634   
 L  R2635   
 L  R2636   
 L  R2637   
 L  R2638   
 L  R2639   
 L  R2640   
 L  R2641   
 L  R2642   
 L  R2643   
 L  R2644   
 L  R2645   
 L  R2646   
 L  R2647   
 L  R2648   
 L  R2649   
 L  R2650   
 L  R2651   
 L  R2652   
 L  R2653   
 L  R2654   
 L  R2655   
 L  R2656   
 L  R2657   
 L  R2658   
 L  R2659   
 L  R2660   
 L  R2661   
 L  R2662   
 L  R2663   
 L  R2664   
 L  R2665   
 L  R2666   
 L  R2667   
 L  R2668   
 L  R2669   
 L  R2670   
 L  R2671   
 L  R2672   
 L  R2673   
 L  R2674   
 L  R2675   
 L  R2676   
 L  R2677   
 L  R2678   
 L  R2679   
 L  R2680   
 L  R2681   
 L  R2682   
 L  R2683   
 L  R2684   
 L  R2685   
 L  R2686   
 L  R2687   
 L  R2688   
 L  R2689   
 L  R2690   
 L  R2691   
 L  R2692   
 L  R2693   
 L  R2694   
 L  R2695   
 L  R2696   
 L  R2697   
 L  R2698   
 L  R2699   
 L  R2700   
 L  R2701   
 L  R2702   
 L  R2703   
 L  R2704   
 L  R2705   
 L  R2706   
 L  R2707   
 L  R2708   
 L  R2709   
 L  R2710   
 L  R2711   
 L  R2712   
 L  R2713   
 L  R2714   
 L  R2715   
 L  R2716   
 L  R2717   
 L  R2718   
 L  R2719   
 L  R2720   
 L  R2721   
 L  R2722   
 L  R2723   
 L  R2724   
 L  R2725   
 L  R2726   
 L  R2727   
 L  R2728   
 L  R2729   
 L  R2730   
 L  R2731   
 L  R2732   
 L  R2733   
 L  R2734   
 L  R2735   
 L  R2736   
 L  R2737   
 L  R2738   
 L  R2739   
 L  R2740   
 L  R2741   
 L  R2742   
 L  R2743   
 L  R2744   
 L  R2745   
 L  R2746   
 L  R2747   
 L  R2748   
 L  R2749   
 L  R2750   
 L  R2751   
 L  R2752   
 L  R2753   
 L  qc0     
 L  qc1     
 L  qc2     
 L  qc3     
 L  qc4     
 L  qc5     
 L  qc6     
 L  qc7     
 L  qc8     
 L  qc9     
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    phi[0,1]  R0        1
    phi[0,1]  R1        1
    phi[0,1]  R9        -1
    phi[0,1]  R92       -3.0999999046325684e+00
    phi[0,1]  R93       -3.0999999046325684e+00
    phi[0,1]  R94       -2.2400000095367432e+00
    phi[0,1]  R95       -2.2400000095367432e+00
    phi[0,1]  R96       -3.0999999046325684e+00
    phi[0,1]  R97       -3.0999999046325684e+00
    phi[0,1]  R98       -2.5699999332427979e+00
    phi[0,1]  R99       -2.5699999332427979e+00
    phi[0,1]  R100      -3.0999999046325684e+00
    phi[0,1]  R101      -3.0999999046325684e+00
    phi[0,1]  R102      -2.0899999141693115e+00
    phi[0,1]  R103      -2.0899999141693115e+00
    phi[0,1]  R104      -3.0999999046325684e+00
    phi[0,1]  R105      -3.0999999046325684e+00
    phi[0,1]  R106      3.6841323971748352e-01
    phi[0,1]  R107      9.4976775348186493e-02
    phi[0,1]  R108      1.7492553591728210e-01
    phi[0,1]  R109      -6.4902013540267944e-01
    phi[0,1]  R110      -0.544015645980835
    phi[0,1]  R111      -6.5476067364215851e-02
    phi[0,1]  R112      -3.9310938119888306e-01
    phi[0,1]  R113      3.0206134915351868e-01
    phi[0,1]  R114      -1.9510000944137573e+00
    phi[0,1]  R115      2.0395611226558685e-01
    phi[0,1]  R116      -1.8147236108779907e+00
    phi[0,1]  R117      -2.6860964298248291e-01
    phi[0,1]  R118      -1.9700111150741577e+00
    phi[0,1]  R119      -1.7336626350879669e-01
    phi[0,1]  R120      -4.3426451086997986e-01
    phi[0,1]  R121      -0.288415789604187
    phi[0,1]  R122      -1.1381057500839233e+00
    phi[0,1]  R123      -4.0407335758209229e-01
    phi[0,1]  R124      -1.1821454763412476e+00
    phi[0,1]  R125      -7.8241086006164551e-01
    phi[0,1]  R126      -8.7979716062545776e-01
    phi[0,1]  R127      -8.8612926006317139e-01
    phi[0,1]  R128      -8.6342191696166992e-01
    phi[0,1]  R129      -1.5976548194885254e+00
    phi[0,1]  R130      -1.5959037542343140e+00
    phi[0,1]  R131      -1.9106793403625488e+00
    phi[0,1]  R132      -1.3955547809600830e+00
    phi[0,1]  R133      4.5200437307357788e-02
    phi[0,1]  R134      -1.1171829700469971e+00
    phi[0,1]  R135      2.1718165278434753e-01
    phi[0,1]  R136      -0.585711658000946
    phi[0,1]  R137      -1.8141325712203979e+00
    phi[0,1]  R138      -6.3398581743240356e-01
    phi[0,1]  R139      -2.5700739026069641e-01
    phi[0,1]  R140      -7.0124173164367676e-01
    phi[0,1]  R141      -2.9653182625770569e-01
    phi[0,1]  R142      -1.9889379739761353e+00
    phi[0,1]  R143      -1.4039809703826904e+00
    phi[0,1]  R144      -1.6545828580856323e+00
    phi[0,1]  R145      -3.5184672474861145e-01
    phi[0,1]  R146      4.5052725076675415e-01
    phi[0,1]  R147      -8.7487769126892090e-01
    phi[0,1]  R148      -1.2409967184066772e+00
    phi[0,1]  R149      -1.2237194776535034e+00
    phi[0,1]  R150      -3.2166007161140442e-01
    phi[0,1]  R151      -1.6635555028915405e-01
    phi[0,1]  R152      -4.7783127427101135e-01
    phi[0,1]  R153      -6.2624728679656982e-01
    phi[0,1]  R154      -2.4508963525295258e-01
    phi[0,1]  R155      -1.6968902349472046e+00
    phi[0,1]  R156      -1.4033994674682617e+00
    phi[0,1]  R157      -1.5287321805953979e-01
    phi[0,1]  R158      -1.5611131191253662e+00
    phi[0,1]  R159      -8.6895418167114258e-01
    phi[0,1]  R160      -1.9593201875686646e+00
    phi[0,1]  R161      3.3782371878623962e-01
    phi[0,1]  R162      -8.1023555994033813e-01
    phi[0,1]  R163      -1.4772222042083740e+00
    phi[0,1]  R164      -2.5230336189270020e+00
    phi[0,1]  R165      -1.68575119972229
    phi[0,1]  R166      7.0581710338592529e-01
    phi[0,1]  R167      1.2857401371002197e+00
    phi[0,1]  R168      1.2449791431427002e+00
    phi[0,1]  R169      7.8906130790710449e-01
    phi[0,1]  R170      1.1794650554656982e+00
    phi[0,1]  R171      7.7637231349945068e-01
    phi[0,1]  R172      7.7615588903427124e-01
    phi[0,1]  R173      1.0580040216445923e+00
    phi[0,1]  R174      -2.7246564626693726e-01
    phi[0,1]  R175      2.4565458297729492e-01
    phi[0,1]  R176      -2.6234167814254761e-01
    phi[0,1]  R177      1.0746860504150391e-01
    phi[0,1]  R178      2.6697331666946411e-01
    phi[0,1]  R179      -2.2192585468292236e-01
    phi[0,1]  R180      -5.3207254409790039e-01
    phi[0,1]  R181      -1.5096805989742279e-01
    phi[0,1]  R182      3.8666903972625732e-02
    phi[0,1]  R183      -3.6409664154052734e-01
    phi[0,1]  R184      1.8854357302188873e-01
    phi[0,1]  R185      -3.0958032608032227e-01
    phi[0,1]  R186      -1.4523614645004272e+00
    phi[0,1]  R187      -1.3720369338989258e+00
    phi[0,1]  R188      -1.6600272655487061e+00
    phi[0,1]  R189      -1.1131739616394043e+00
    phi[0,1]  R190      -1.2645827531814575e+00
    phi[0,1]  R191      -1.4135037660598755e+00
    phi[0,1]  R192      -1.0055119991302490e+00
    phi[0,1]  R193      -0.899972140789032
    phi[0,1]  R194      -1.0986747741699219e+00
    phi[0,1]  R195      -1.6302769184112549e+00
    phi[0,1]  R196      -4.7918668389320374e-01
    phi[0,1]  R197      -1.6353880167007446e+00
    phi[0,1]  R198      -1.6042659282684326e+00
    phi[0,1]  R199      -1.2693887948989868e+00
    phi[0,1]  R200      -1.9693913459777832e+00
    phi[0,1]  R201      -2.0945181846618652e+00
    phi[0,1]  R202      -1.6770938634872437e+00
    phi[0,1]  R203      -9.3601256608963013e-01
    phi[0,1]  R204      -9.1905772686004639e-01
    phi[0,1]  R205      -1.4506546258926392e+00
    phi[0,1]  R206      -1.3282465934753418e+00
    phi[0,1]  R207      -2.0819027423858643e+00
    phi[0,1]  R208      -1.6788767576217651e+00
    phi[0,1]  R209      -2.1277401447296143e+00
    phi[0,1]  R210      -2.1488819122314453e+00
    phi[0,1]  R211      -2.4454441070556641e+00
    phi[0,1]  R212      -1.2843089103698730e+00
    phi[0,1]  R213      -1.8869365453720093e+00
    phi[0,1]  R214      -1.8735146522521973e+00
    phi[0,1]  R215      -1.3547596931457520e+00
    phi[0,1]  R216      -1.4847203493118286e+00
    phi[0,1]  R217      -3.7128737568855286e-01
    phi[0,1]  R218      -5.9992873668670654e-01
    phi[0,1]  R219      -4.0980595350265503e-01
    phi[0,1]  R220      -8.9902347326278687e-01
    phi[0,1]  R221      -1.5234454870224
    phi[0,1]  R222      -2.1465973854064941e+00
    phi[0,1]  R223      -1.9807113409042358e+00
    phi[0,1]  R224      -1.1907218694686890e+00
    phi[0,1]  R225      -1.6505349874496460e+00
    phi[0,1]  R226      -2.2453193664550781e+00
    phi[0,1]  R227      -8.8201528787612915e-01
    phi[0,1]  R228      -3.8269901275634766e-01
    phi[0,1]  R229      -0.931524932384491
    phi[0,1]  R230      -9.7071743011474609e-01
    phi[0,1]  R231      -0.951265275478363
    phi[0,1]  R232      -1.0983262062072754e+00
    phi[0,1]  R233      -2.1882896423339844e+00
    phi[0,1]  R234      -1.1912208795547485e+00
    phi[0,1]  R235      -1.8264650106430054e+00
    phi[0,1]  R236      -8.3584690093994141e-01
    phi[0,1]  R237      -1.1410133838653564e+00
    phi[0,1]  R238      -1.2361494302749634e+00
    phi[0,1]  R239      -1.3587986230850220e+00
    phi[0,1]  R240      -1.5971895456314087e+00
    phi[0,1]  R241      -1.6416977643966675e+00
    phi[0,1]  R242      -1.9699259996414185e+00
    phi[0,1]  R243      -1.4119985103607178e+00
    phi[0,1]  R244      6.6172605752944946e-01
    phi[0,1]  R245      -1.5155097246170044e+00
    phi[1,0]  R0        -1
    phi[1,0]  R9        1
    phi[1,0]  R10       1
    phi[1,0]  R246      -3.0999999046325684e+00
    phi[1,0]  R247      -3.0999999046325684e+00
    phi[1,0]  R248      -2.2400000095367432e+00
    phi[1,0]  R249      -2.2400000095367432e+00
    phi[1,0]  R250      -3.0999999046325684e+00
    phi[1,0]  R251      -3.0999999046325684e+00
    phi[1,0]  R252      -2.5699999332427979e+00
    phi[1,0]  R253      -2.5699999332427979e+00
    phi[1,0]  R254      -3.0999999046325684e+00
    phi[1,0]  R255      -3.0999999046325684e+00
    phi[1,0]  R256      -2.0899999141693115e+00
    phi[1,0]  R257      -2.0899999141693115e+00
    phi[1,0]  R258      -3.0999999046325684e+00
    phi[1,0]  R259      -3.0999999046325684e+00
    phi[1,0]  R260      7.0581710338592529e-01
    phi[1,0]  R261      1.2857401371002197e+00
    phi[1,0]  R262      1.2449791431427002e+00
    phi[1,0]  R263      7.8906130790710449e-01
    phi[1,0]  R264      1.1794650554656982e+00
    phi[1,0]  R265      7.7637231349945068e-01
    phi[1,0]  R266      7.7615588903427124e-01
    phi[1,0]  R267      1.0580040216445923e+00
    phi[1,0]  R268      -2.7246564626693726e-01
    phi[1,0]  R269      2.4565458297729492e-01
    phi[1,0]  R270      -2.6234167814254761e-01
    phi[1,0]  R271      1.0746860504150391e-01
    phi[1,0]  R272      2.6697331666946411e-01
    phi[1,0]  R273      -2.2192585468292236e-01
    phi[1,0]  R274      -5.3207254409790039e-01
    phi[1,0]  R275      -1.5096805989742279e-01
    phi[1,0]  R276      3.8666903972625732e-02
    phi[1,0]  R277      -3.6409664154052734e-01
    phi[1,0]  R278      1.8854357302188873e-01
    phi[1,0]  R279      -3.0958032608032227e-01
    phi[1,0]  R280      -1.4523614645004272e+00
    phi[1,0]  R281      -1.3720369338989258e+00
    phi[1,0]  R282      -1.6600272655487061e+00
    phi[1,0]  R283      -1.1131739616394043e+00
    phi[1,0]  R284      -1.2645827531814575e+00
    phi[1,0]  R285      -1.4135037660598755e+00
    phi[1,0]  R286      -1.0055119991302490e+00
    phi[1,0]  R287      -0.899972140789032
    phi[1,0]  R288      -1.0986747741699219e+00
    phi[1,0]  R289      -1.6302769184112549e+00
    phi[1,0]  R290      -4.7918668389320374e-01
    phi[1,0]  R291      -1.6353880167007446e+00
    phi[1,0]  R292      -1.6042659282684326e+00
    phi[1,0]  R293      -1.2693887948989868e+00
    phi[1,0]  R294      -1.9693913459777832e+00
    phi[1,0]  R295      -2.0945181846618652e+00
    phi[1,0]  R296      -1.6770938634872437e+00
    phi[1,0]  R297      -9.3601256608963013e-01
    phi[1,0]  R298      -9.1905772686004639e-01
    phi[1,0]  R299      -1.4506546258926392e+00
    phi[1,0]  R300      -1.3282465934753418e+00
    phi[1,0]  R301      -2.0819027423858643e+00
    phi[1,0]  R302      -1.6788767576217651e+00
    phi[1,0]  R303      -2.1277401447296143e+00
    phi[1,0]  R304      -2.1488819122314453e+00
    phi[1,0]  R305      -2.4454441070556641e+00
    phi[1,0]  R306      -1.2843089103698730e+00
    phi[1,0]  R307      -1.8869365453720093e+00
    phi[1,0]  R308      -1.8735146522521973e+00
    phi[1,0]  R309      -1.3547596931457520e+00
    phi[1,0]  R310      -1.4847203493118286e+00
    phi[1,0]  R311      -3.7128737568855286e-01
    phi[1,0]  R312      -5.9992873668670654e-01
    phi[1,0]  R313      -4.0980595350265503e-01
    phi[1,0]  R314      -8.9902347326278687e-01
    phi[1,0]  R315      -1.5234454870224
    phi[1,0]  R316      -2.1465973854064941e+00
    phi[1,0]  R317      -1.9807113409042358e+00
    phi[1,0]  R318      -1.1907218694686890e+00
    phi[1,0]  R319      -1.6505349874496460e+00
    phi[1,0]  R320      -2.2453193664550781e+00
    phi[1,0]  R321      -8.8201528787612915e-01
    phi[1,0]  R322      -3.8269901275634766e-01
    phi[1,0]  R323      -0.931524932384491
    phi[1,0]  R324      -9.7071743011474609e-01
    phi[1,0]  R325      -0.951265275478363
    phi[1,0]  R326      -1.0983262062072754e+00
    phi[1,0]  R327      -2.1882896423339844e+00
    phi[1,0]  R328      -1.1912208795547485e+00
    phi[1,0]  R329      -1.8264650106430054e+00
    phi[1,0]  R330      -8.3584690093994141e-01
    phi[1,0]  R331      -1.1410133838653564e+00
    phi[1,0]  R332      -1.2361494302749634e+00
    phi[1,0]  R333      -1.3587986230850220e+00
    phi[1,0]  R334      -1.5971895456314087e+00
    phi[1,0]  R335      -1.6416977643966675e+00
    phi[1,0]  R336      -1.9699259996414185e+00
    phi[1,0]  R337      -1.4119985103607178e+00
    phi[1,0]  R338      6.6172605752944946e-01
    phi[1,0]  R339      -1.5155097246170044e+00
    phi[1,0]  R340      3.6841323971748352e-01
    phi[1,0]  R341      9.4976775348186493e-02
    phi[1,0]  R342      1.7492553591728210e-01
    phi[1,0]  R343      -6.4902013540267944e-01
    phi[1,0]  R344      -0.544015645980835
    phi[1,0]  R345      -6.5476067364215851e-02
    phi[1,0]  R346      -3.9310938119888306e-01
    phi[1,0]  R347      3.0206134915351868e-01
    phi[1,0]  R348      -1.9510000944137573e+00
    phi[1,0]  R349      2.0395611226558685e-01
    phi[1,0]  R350      -1.8147236108779907e+00
    phi[1,0]  R351      -2.6860964298248291e-01
    phi[1,0]  R352      -1.9700111150741577e+00
    phi[1,0]  R353      -1.7336626350879669e-01
    phi[1,0]  R354      -4.3426451086997986e-01
    phi[1,0]  R355      -0.288415789604187
    phi[1,0]  R356      -1.1381057500839233e+00
    phi[1,0]  R357      -4.0407335758209229e-01
    phi[1,0]  R358      -1.1821454763412476e+00
    phi[1,0]  R359      -7.8241086006164551e-01
    phi[1,0]  R360      -8.7979716062545776e-01
    phi[1,0]  R361      -8.8612926006317139e-01
    phi[1,0]  R362      -8.6342191696166992e-01
    phi[1,0]  R363      -1.5976548194885254e+00
    phi[1,0]  R364      -1.5959037542343140e+00
    phi[1,0]  R365      -1.9106793403625488e+00
    phi[1,0]  R366      -1.3955547809600830e+00
    phi[1,0]  R367      4.5200437307357788e-02
    phi[1,0]  R368      -1.1171829700469971e+00
    phi[1,0]  R369      2.1718165278434753e-01
    phi[1,0]  R370      -0.585711658000946
    phi[1,0]  R371      -1.8141325712203979e+00
    phi[1,0]  R372      -6.3398581743240356e-01
    phi[1,0]  R373      -2.5700739026069641e-01
    phi[1,0]  R374      -7.0124173164367676e-01
    phi[1,0]  R375      -2.9653182625770569e-01
    phi[1,0]  R376      -1.9889379739761353e+00
    phi[1,0]  R377      -1.4039809703826904e+00
    phi[1,0]  R378      -1.6545828580856323e+00
    phi[1,0]  R379      -3.5184672474861145e-01
    phi[1,0]  R380      4.5052725076675415e-01
    phi[1,0]  R381      -8.7487769126892090e-01
    phi[1,0]  R382      -1.2409967184066772e+00
    phi[1,0]  R383      -1.2237194776535034e+00
    phi[1,0]  R384      -3.2166007161140442e-01
    phi[1,0]  R385      -1.6635555028915405e-01
    phi[1,0]  R386      -4.7783127427101135e-01
    phi[1,0]  R387      -6.2624728679656982e-01
    phi[1,0]  R388      -2.4508963525295258e-01
    phi[1,0]  R389      -1.6968902349472046e+00
    phi[1,0]  R390      -1.4033994674682617e+00
    phi[1,0]  R391      -1.5287321805953979e-01
    phi[1,0]  R392      -1.5611131191253662e+00
    phi[1,0]  R393      -8.6895418167114258e-01
    phi[1,0]  R394      -1.9593201875686646e+00
    phi[1,0]  R395      3.3782371878623962e-01
    phi[1,0]  R396      -8.1023555994033813e-01
    phi[1,0]  R397      -1.4772222042083740e+00
    phi[1,0]  R398      -2.5230336189270020e+00
    phi[1,0]  R399      -1.68575119972229
    phi[0,5]  R0        1
    phi[0,5]  R1        1
    phi[0,5]  R45       -1
    phi[0,5]  R400      -3.0999999046325684e+00
    phi[0,5]  R401      -3.0999999046325684e+00
    phi[0,5]  R402      -2.2400000095367432e+00
    phi[0,5]  R403      -2.2400000095367432e+00
    phi[0,5]  R404      -3.0999999046325684e+00
    phi[0,5]  R405      -3.0999999046325684e+00
    phi[0,5]  R406      -2.5699999332427979e+00
    phi[0,5]  R407      -2.5699999332427979e+00
    phi[0,5]  R408      -3.0999999046325684e+00
    phi[0,5]  R409      -3.0999999046325684e+00
    phi[0,5]  R410      -2.0899999141693115e+00
    phi[0,5]  R411      -2.0899999141693115e+00
    phi[0,5]  R412      -3.0999999046325684e+00
    phi[0,5]  R413      -3.0999999046325684e+00
    phi[0,5]  R414      3.6841323971748352e-01
    phi[0,5]  R415      9.4976775348186493e-02
    phi[0,5]  R416      1.7492553591728210e-01
    phi[0,5]  R417      -6.4902013540267944e-01
    phi[0,5]  R418      -0.544015645980835
    phi[0,5]  R419      -6.5476067364215851e-02
    phi[0,5]  R420      -3.9310938119888306e-01
    phi[0,5]  R421      3.0206134915351868e-01
    phi[0,5]  R422      -1.9510000944137573e+00
    phi[0,5]  R423      2.0395611226558685e-01
    phi[0,5]  R424      -1.8147236108779907e+00
    phi[0,5]  R425      -2.6860964298248291e-01
    phi[0,5]  R426      -1.9700111150741577e+00
    phi[0,5]  R427      -1.7336626350879669e-01
    phi[0,5]  R428      -4.3426451086997986e-01
    phi[0,5]  R429      -0.288415789604187
    phi[0,5]  R430      -1.1381057500839233e+00
    phi[0,5]  R431      -4.0407335758209229e-01
    phi[0,5]  R432      -1.1821454763412476e+00
    phi[0,5]  R433      -7.8241086006164551e-01
    phi[0,5]  R434      -8.7979716062545776e-01
    phi[0,5]  R435      -8.8612926006317139e-01
    phi[0,5]  R436      -8.6342191696166992e-01
    phi[0,5]  R437      -1.5976548194885254e+00
    phi[0,5]  R438      -1.5959037542343140e+00
    phi[0,5]  R439      -1.9106793403625488e+00
    phi[0,5]  R440      -1.3955547809600830e+00
    phi[0,5]  R441      4.5200437307357788e-02
    phi[0,5]  R442      -1.1171829700469971e+00
    phi[0,5]  R443      2.1718165278434753e-01
    phi[0,5]  R444      -0.585711658000946
    phi[0,5]  R445      -1.8141325712203979e+00
    phi[0,5]  R446      -6.3398581743240356e-01
    phi[0,5]  R447      -2.5700739026069641e-01
    phi[0,5]  R448      -7.0124173164367676e-01
    phi[0,5]  R449      -2.9653182625770569e-01
    phi[0,5]  R450      -1.9889379739761353e+00
    phi[0,5]  R451      -1.4039809703826904e+00
    phi[0,5]  R452      -1.6545828580856323e+00
    phi[0,5]  R453      -3.5184672474861145e-01
    phi[0,5]  R454      4.5052725076675415e-01
    phi[0,5]  R455      -8.7487769126892090e-01
    phi[0,5]  R456      -1.2409967184066772e+00
    phi[0,5]  R457      -1.2237194776535034e+00
    phi[0,5]  R458      -3.2166007161140442e-01
    phi[0,5]  R459      -1.6635555028915405e-01
    phi[0,5]  R460      -4.7783127427101135e-01
    phi[0,5]  R461      -6.2624728679656982e-01
    phi[0,5]  R462      -2.4508963525295258e-01
    phi[0,5]  R463      -1.6968902349472046e+00
    phi[0,5]  R464      -1.4033994674682617e+00
    phi[0,5]  R465      -1.5287321805953979e-01
    phi[0,5]  R466      -1.5611131191253662e+00
    phi[0,5]  R467      -8.6895418167114258e-01
    phi[0,5]  R468      -1.9593201875686646e+00
    phi[0,5]  R469      3.3782371878623962e-01
    phi[0,5]  R470      -8.1023555994033813e-01
    phi[0,5]  R471      -1.4772222042083740e+00
    phi[0,5]  R472      -2.5230336189270020e+00
    phi[0,5]  R473      -1.68575119972229
    phi[0,5]  R474      1.0040199756622314e+00
    phi[0,5]  R475      1.5286905765533447e+00
    phi[0,5]  R476      1.1812471151351929e+00
    phi[0,5]  R477      1.1003676652908325e+00
    phi[0,5]  R478      -2.8553324937820435e-01
    phi[0,5]  R479      1.2852455675601959e-01
    phi[0,5]  R480      3.0759865045547485e-01
    phi[0,5]  R481      2.4433873593807220e-01
    phi[0,5]  R482      -7.8723394870758057e-01
    phi[0,5]  R483      -9.6787512302398682e-01
    phi[0,5]  R484      -2.3272061347961426e-01
    phi[0,5]  R485      1.2853199616074562e-02
    phi[0,5]  R486      5.0104144029319286e-03
    phi[0,5]  R487      -2.1753330230712891e+00
    phi[0,5]  R488      1.0951761007308960e+00
    phi[0,5]  R489      1.9493639469146729e-01
    phi[0,5]  R490      7.9607951641082764e-01
    phi[0,5]  R491      1.0852813720703125e+00
    phi[0,5]  R492      8.0336767435073853e-01
    phi[0,5]  R493      5.8638375997543335e-01
    phi[0,5]  R494      -2.4810762405395508e+00
    phi[0,5]  R495      -4.6268829703330994e-01
    phi[0,5]  R496      -1.6157008409500122e+00
    phi[0,5]  R497      -3.1129128932952881e+00
    phi[0,5]  R498      -1.6747971773147583e+00
    phi[0,5]  R499      -2.3356578350067139e+00
    phi[0,5]  R500      -2.7030389308929443e+00
    phi[0,5]  R501      6.9014990329742432e-01
    phi[0,5]  R502      -1.3521074056625366e+00
    phi[0,5]  R503      -1.3264334201812744e+00
    phi[0,5]  R504      -0.611155092716217
    phi[0,5]  R505      -1.6850816011428833e+00
    phi[0,5]  R506      -1.9842704534530640e+00
    phi[0,5]  R507      -2.1739697456359863e+00
    phi[0,5]  R508      -2.3052670955657959e+00
    phi[0,5]  R509      -2.1097412109375
    phi[0,5]  R510      -9.2568355798721313e-01
    phi[0,5]  R511      -3.3764150142669678e+00
    phi[0,5]  R512      -2.8746275901794434e+00
    phi[0,5]  R513      -3.0102052688598633e+00
    phi[5,0]  R0        -1
    phi[5,0]  R45       1
    phi[5,0]  R46       1
    phi[5,0]  R514      -3.0999999046325684e+00
    phi[5,0]  R515      -3.0999999046325684e+00
    phi[5,0]  R516      -2.2400000095367432e+00
    phi[5,0]  R517      -2.2400000095367432e+00
    phi[5,0]  R518      -3.0999999046325684e+00
    phi[5,0]  R519      -3.0999999046325684e+00
    phi[5,0]  R520      -2.5699999332427979e+00
    phi[5,0]  R521      -2.5699999332427979e+00
    phi[5,0]  R522      -3.0999999046325684e+00
    phi[5,0]  R523      -3.0999999046325684e+00
    phi[5,0]  R524      -2.0899999141693115e+00
    phi[5,0]  R525      -2.0899999141693115e+00
    phi[5,0]  R526      -3.0999999046325684e+00
    phi[5,0]  R527      -3.0999999046325684e+00
    phi[5,0]  R528      1.0040199756622314e+00
    phi[5,0]  R529      1.5286905765533447e+00
    phi[5,0]  R530      1.1812471151351929e+00
    phi[5,0]  R531      1.1003676652908325e+00
    phi[5,0]  R532      -2.8553324937820435e-01
    phi[5,0]  R533      1.2852455675601959e-01
    phi[5,0]  R534      3.0759865045547485e-01
    phi[5,0]  R535      2.4433873593807220e-01
    phi[5,0]  R536      -7.8723394870758057e-01
    phi[5,0]  R537      -9.6787512302398682e-01
    phi[5,0]  R538      -2.3272061347961426e-01
    phi[5,0]  R539      1.2853199616074562e-02
    phi[5,0]  R540      5.0104144029319286e-03
    phi[5,0]  R541      -2.1753330230712891e+00
    phi[5,0]  R542      1.0951761007308960e+00
    phi[5,0]  R543      1.9493639469146729e-01
    phi[5,0]  R544      7.9607951641082764e-01
    phi[5,0]  R545      1.0852813720703125e+00
    phi[5,0]  R546      8.0336767435073853e-01
    phi[5,0]  R547      5.8638375997543335e-01
    phi[5,0]  R548      -2.4810762405395508e+00
    phi[5,0]  R549      -4.6268829703330994e-01
    phi[5,0]  R550      -1.6157008409500122e+00
    phi[5,0]  R551      -3.1129128932952881e+00
    phi[5,0]  R552      -1.6747971773147583e+00
    phi[5,0]  R553      -2.3356578350067139e+00
    phi[5,0]  R554      -2.7030389308929443e+00
    phi[5,0]  R555      6.9014990329742432e-01
    phi[5,0]  R556      -1.3521074056625366e+00
    phi[5,0]  R557      -1.3264334201812744e+00
    phi[5,0]  R558      -0.611155092716217
    phi[5,0]  R559      -1.6850816011428833e+00
    phi[5,0]  R560      -1.9842704534530640e+00
    phi[5,0]  R561      -2.1739697456359863e+00
    phi[5,0]  R562      -2.3052670955657959e+00
    phi[5,0]  R563      -2.1097412109375
    phi[5,0]  R564      -9.2568355798721313e-01
    phi[5,0]  R565      -3.3764150142669678e+00
    phi[5,0]  R566      -2.8746275901794434e+00
    phi[5,0]  R567      -3.0102052688598633e+00
    phi[5,0]  R568      3.6841323971748352e-01
    phi[5,0]  R569      9.4976775348186493e-02
    phi[5,0]  R570      1.7492553591728210e-01
    phi[5,0]  R571      -6.4902013540267944e-01
    phi[5,0]  R572      -0.544015645980835
    phi[5,0]  R573      -6.5476067364215851e-02
    phi[5,0]  R574      -3.9310938119888306e-01
    phi[5,0]  R575      3.0206134915351868e-01
    phi[5,0]  R576      -1.9510000944137573e+00
    phi[5,0]  R577      2.0395611226558685e-01
    phi[5,0]  R578      -1.8147236108779907e+00
    phi[5,0]  R579      -2.6860964298248291e-01
    phi[5,0]  R580      -1.9700111150741577e+00
    phi[5,0]  R581      -1.7336626350879669e-01
    phi[5,0]  R582      -4.3426451086997986e-01
    phi[5,0]  R583      -0.288415789604187
    phi[5,0]  R584      -1.1381057500839233e+00
    phi[5,0]  R585      -4.0407335758209229e-01
    phi[5,0]  R586      -1.1821454763412476e+00
    phi[5,0]  R587      -7.8241086006164551e-01
    phi[5,0]  R588      -8.7979716062545776e-01
    phi[5,0]  R589      -8.8612926006317139e-01
    phi[5,0]  R590      -8.6342191696166992e-01
    phi[5,0]  R591      -1.5976548194885254e+00
    phi[5,0]  R592      -1.5959037542343140e+00
    phi[5,0]  R593      -1.9106793403625488e+00
    phi[5,0]  R594      -1.3955547809600830e+00
    phi[5,0]  R595      4.5200437307357788e-02
    phi[5,0]  R596      -1.1171829700469971e+00
    phi[5,0]  R597      2.1718165278434753e-01
    phi[5,0]  R598      -0.585711658000946
    phi[5,0]  R599      -1.8141325712203979e+00
    phi[5,0]  R600      -6.3398581743240356e-01
    phi[5,0]  R601      -2.5700739026069641e-01
    phi[5,0]  R602      -7.0124173164367676e-01
    phi[5,0]  R603      -2.9653182625770569e-01
    phi[5,0]  R604      -1.9889379739761353e+00
    phi[5,0]  R605      -1.4039809703826904e+00
    phi[5,0]  R606      -1.6545828580856323e+00
    phi[5,0]  R607      -3.5184672474861145e-01
    phi[5,0]  R608      4.5052725076675415e-01
    phi[5,0]  R609      -8.7487769126892090e-01
    phi[5,0]  R610      -1.2409967184066772e+00
    phi[5,0]  R611      -1.2237194776535034e+00
    phi[5,0]  R612      -3.2166007161140442e-01
    phi[5,0]  R613      -1.6635555028915405e-01
    phi[5,0]  R614      -4.7783127427101135e-01
    phi[5,0]  R615      -6.2624728679656982e-01
    phi[5,0]  R616      -2.4508963525295258e-01
    phi[5,0]  R617      -1.6968902349472046e+00
    phi[5,0]  R618      -1.4033994674682617e+00
    phi[5,0]  R619      -1.5287321805953979e-01
    phi[5,0]  R620      -1.5611131191253662e+00
    phi[5,0]  R621      -8.6895418167114258e-01
    phi[5,0]  R622      -1.9593201875686646e+00
    phi[5,0]  R623      3.3782371878623962e-01
    phi[5,0]  R624      -8.1023555994033813e-01
    phi[5,0]  R625      -1.4772222042083740e+00
    phi[5,0]  R626      -2.5230336189270020e+00
    phi[5,0]  R627      -1.68575119972229
    phi[10,0]  R0        -1
    phi[10,0]  R2        -1.0876942707822710e+00
    phi[10,0]  R3        -1.3864910604887788e+00
    phi[10,0]  R4        -8.0873759611484930e-01
    phi[10,0]  R5        1.7029626216183824e+00
    phi[10,0]  R6        1.5535340012573573e+00
    phi[10,0]  R7        1.2092606776728023e+00
    phi[10,0]  R8        -8.6802718594208583e-01
    phi[10,0]  R90       1
    phi[10,0]  R628      -2.0123056338502971e+00
    phi[10,0]  R629      -4.18769417541484
    phi[10,0]  R630      -8.5350894904796437e-01
    phi[10,0]  R631      -3.6264910700255220e+00
    phi[10,0]  R632      -2.2912623085177191e+00
    phi[10,0]  R633      -3.9087375007474177e+00
    phi[10,0]  R634      -4.2729625548611807e+00
    phi[10,0]  R635      -8.6703731162441544e-01
    phi[10,0]  R636      -4.6535339058899261e+00
    phi[10,0]  R637      -1.5464659033752111e+00
    phi[10,0]  R638      -3.2992605918421138e+00
    phi[10,0]  R639      -8.8073923649650920e-01
    phi[10,0]  R640      -2.2319727186904825e+00
    phi[10,0]  R641      -3.9680270905746542e+00
    phi[10,0]  R642      -1.8471695292999646e-01
    phi[10,0]  R643      -1.9273261307173384e-01
    phi[10,0]  R644      -2.3617925853314509e-01
    phi[10,0]  R645      -3.3435267230712018e-01
    phi[10,0]  R646      -3.4448597604659481e-01
    phi[10,0]  R647      -3.6478838932836233e-01
    phi[10,0]  R648      -1.4620485148583604e+00
    phi[10,0]  R649      -3.9501488868401036e-01
    phi[10,0]  R650      -4.0865379950503433e-01
    phi[10,0]  R651      -8.9020006851867084e-01
    phi[10,0]  R652      -3.4901822571049146e-01
    phi[10,0]  R653      -5.2323891049270566e-01
    phi[10,0]  R654      -6.2255081453916361e-01
    phi[10,0]  R655      -7.0689043925059181e-01
    phi[10,0]  R656      -7.1410592749421831e-01
    phi[10,0]  R657      -7.2134034338886033e-01
    phi[10,0]  R658      -0.734897079717932
    phi[10,0]  R659      -7.3642306361022492e-01
    phi[10,0]  R660      -7.3706720604679243e-01
    phi[10,0]  R661      -7.3946907890239355e-01
    phi[10,0]  R662      -3.3085508765428562e-01
    phi[10,0]  R663      -3.3195368185711494e-01
    phi[10,0]  R664      -3.4137072214843067e-01
    phi[10,0]  R665      -3.4989821445100922e-01
    phi[10,0]  R666      -3.6455694237560832e-01
    phi[10,0]  R667      -3.7749821709133924e-01
    phi[10,0]  R668      -4.4022893512565420e-01
    phi[10,0]  R669      -4.4266742109151080e-01
    phi[10,0]  R670      -4.6559268521137920e-01
    phi[10,0]  R671      -4.7280405216938037e-01
    phi[10,0]  R672      -3.4698008160853422e-01
    phi[10,0]  R673      -3.5783471327815519e-01
    phi[10,0]  R674      -3.6450710144395115e-01
    phi[10,0]  R675      -4.3193402137859449e-01
    phi[10,0]  R676      -4.4968763753966362e-01
    phi[10,0]  R677      -0.514571212830066
    phi[10,0]  R678      -5.3750928449239610e-01
    phi[10,0]  R679      -5.4311248808347468e-01
    phi[10,0]  R680      -6.1818588413527520e-01
    phi[10,0]  R681      -7.2706445458755953e-01
    phi[10,0]  R682      -3.1687430858323251e-01
    phi[10,0]  R683      -0.430505672197259
    phi[10,0]  R684      -4.4434603398691574e-01
    phi[10,0]  R685      -4.7453725882223952e-01
    phi[10,0]  R686      -4.8140848286012583e-01
    phi[10,0]  R687      -1.7861871835413954e+00
    phi[10,0]  R688      -0.637635755665347
    phi[10,0]  R689      -0.666918086961692
    phi[10,0]  R690      -0.671313602395598
    phi[10,0]  R691      -6.8424150571724840e-01
    phi[10,0]  R692      -3.1413791671544433e-01
    phi[10,0]  R693      -3.5026811318816953e-01
    phi[10,0]  R694      -3.6891082389033736e-01
    phi[10,0]  R695      -3.7885232400579882e-01
    phi[10,0]  R696      -3.7951697062704004e-01
    phi[10,0]  R697      -8.1499126921699916e-01
    phi[10,0]  R698      -7.9309826964675967e-01
    phi[10,0]  R699      -8.3832685395828754e-01
    phi[10,0]  R700      -8.5563817674449227e-01
    phi[10,0]  R701      -8.6696788474565112e-01
    phi[1,2]  R9        1
    phi[1,2]  R10       1
    phi[1,2]  R18       -1
    phi[1,2]  R702      -3.0999999046325684e+00
    phi[1,2]  R703      -3.0999999046325684e+00
    phi[1,2]  R704      -2.2400000095367432e+00
    phi[1,2]  R705      -2.2400000095367432e+00
    phi[1,2]  R706      -3.0999999046325684e+00
    phi[1,2]  R707      -3.0999999046325684e+00
    phi[1,2]  R708      -2.5699999332427979e+00
    phi[1,2]  R709      -2.5699999332427979e+00
    phi[1,2]  R710      -3.0999999046325684e+00
    phi[1,2]  R711      -3.0999999046325684e+00
    phi[1,2]  R712      -2.0899999141693115e+00
    phi[1,2]  R713      -2.0899999141693115e+00
    phi[1,2]  R714      -3.0999999046325684e+00
    phi[1,2]  R715      -3.0999999046325684e+00
    phi[1,2]  R716      7.0581710338592529e-01
    phi[1,2]  R717      1.2857401371002197e+00
    phi[1,2]  R718      1.2449791431427002e+00
    phi[1,2]  R719      7.8906130790710449e-01
    phi[1,2]  R720      1.1794650554656982e+00
    phi[1,2]  R721      7.7637231349945068e-01
    phi[1,2]  R722      7.7615588903427124e-01
    phi[1,2]  R723      1.0580040216445923e+00
    phi[1,2]  R724      -2.7246564626693726e-01
    phi[1,2]  R725      2.4565458297729492e-01
    phi[1,2]  R726      -2.6234167814254761e-01
    phi[1,2]  R727      1.0746860504150391e-01
    phi[1,2]  R728      2.6697331666946411e-01
    phi[1,2]  R729      -2.2192585468292236e-01
    phi[1,2]  R730      -5.3207254409790039e-01
    phi[1,2]  R731      -1.5096805989742279e-01
    phi[1,2]  R732      3.8666903972625732e-02
    phi[1,2]  R733      -3.6409664154052734e-01
    phi[1,2]  R734      1.8854357302188873e-01
    phi[1,2]  R735      -3.0958032608032227e-01
    phi[1,2]  R736      -1.4523614645004272e+00
    phi[1,2]  R737      -1.3720369338989258e+00
    phi[1,2]  R738      -1.6600272655487061e+00
    phi[1,2]  R739      -1.1131739616394043e+00
    phi[1,2]  R740      -1.2645827531814575e+00
    phi[1,2]  R741      -1.4135037660598755e+00
    phi[1,2]  R742      -1.0055119991302490e+00
    phi[1,2]  R743      -0.899972140789032
    phi[1,2]  R744      -1.0986747741699219e+00
    phi[1,2]  R745      -1.6302769184112549e+00
    phi[1,2]  R746      -4.7918668389320374e-01
    phi[1,2]  R747      -1.6353880167007446e+00
    phi[1,2]  R748      -1.6042659282684326e+00
    phi[1,2]  R749      -1.2693887948989868e+00
    phi[1,2]  R750      -1.9693913459777832e+00
    phi[1,2]  R751      -2.0945181846618652e+00
    phi[1,2]  R752      -1.6770938634872437e+00
    phi[1,2]  R753      -9.3601256608963013e-01
    phi[1,2]  R754      -9.1905772686004639e-01
    phi[1,2]  R755      -1.4506546258926392e+00
    phi[1,2]  R756      -1.3282465934753418e+00
    phi[1,2]  R757      -2.0819027423858643e+00
    phi[1,2]  R758      -1.6788767576217651e+00
    phi[1,2]  R759      -2.1277401447296143e+00
    phi[1,2]  R760      -2.1488819122314453e+00
    phi[1,2]  R761      -2.4454441070556641e+00
    phi[1,2]  R762      -1.2843089103698730e+00
    phi[1,2]  R763      -1.8869365453720093e+00
    phi[1,2]  R764      -1.8735146522521973e+00
    phi[1,2]  R765      -1.3547596931457520e+00
    phi[1,2]  R766      -1.4847203493118286e+00
    phi[1,2]  R767      -3.7128737568855286e-01
    phi[1,2]  R768      -5.9992873668670654e-01
    phi[1,2]  R769      -4.0980595350265503e-01
    phi[1,2]  R770      -8.9902347326278687e-01
    phi[1,2]  R771      -1.5234454870224
    phi[1,2]  R772      -2.1465973854064941e+00
    phi[1,2]  R773      -1.9807113409042358e+00
    phi[1,2]  R774      -1.1907218694686890e+00
    phi[1,2]  R775      -1.6505349874496460e+00
    phi[1,2]  R776      -2.2453193664550781e+00
    phi[1,2]  R777      -8.8201528787612915e-01
    phi[1,2]  R778      -3.8269901275634766e-01
    phi[1,2]  R779      -0.931524932384491
    phi[1,2]  R780      -9.7071743011474609e-01
    phi[1,2]  R781      -0.951265275478363
    phi[1,2]  R782      -1.0983262062072754e+00
    phi[1,2]  R783      -2.1882896423339844e+00
    phi[1,2]  R784      -1.1912208795547485e+00
    phi[1,2]  R785      -1.8264650106430054e+00
    phi[1,2]  R786      -8.3584690093994141e-01
    phi[1,2]  R787      -1.1410133838653564e+00
    phi[1,2]  R788      -1.2361494302749634e+00
    phi[1,2]  R789      -1.3587986230850220e+00
    phi[1,2]  R790      -1.5971895456314087e+00
    phi[1,2]  R791      -1.6416977643966675e+00
    phi[1,2]  R792      -1.9699259996414185e+00
    phi[1,2]  R793      -1.4119985103607178e+00
    phi[1,2]  R794      6.6172605752944946e-01
    phi[1,2]  R795      -1.5155097246170044e+00
    phi[1,2]  R796      1.4658120870590210e+00
    phi[1,2]  R797      -5.7754196226596832e-02
    phi[1,2]  R798      -7.9105056822299957e-02
    phi[1,2]  R799      8.6138397455215454e-01
    phi[1,2]  R800      1.1949729919433594e+00
    phi[1,2]  R801      1.0626022815704346e+00
    phi[1,2]  R802      1.3570271730422974e+00
    phi[1,2]  R803      1.3911136388778687e+00
    phi[1,2]  R804      6.0133183002471924e-01
    phi[1,2]  R805      2.1430739760398865e-01
    phi[1,2]  R806      -9.1402125358581543e-01
    phi[1,2]  R807      7.3895761743187904e-03
    phi[1,2]  R808      -1.1982066631317139e+00
    phi[1,2]  R809      -1.5418968200683594e+00
    phi[1,2]  R810      -2.1503503322601318e+00
    phi[1,2]  R811      -1.1939885616302490e+00
    phi[1,2]  R812      -0.574803352355957
    phi[1,2]  R813      -9.5286267995834351e-01
    phi[1,2]  R814      -3.2604852318763733e-01
    phi[1,2]  R815      -8.7450706958770752e-01
    phi[1,2]  R816      -7.6050686836242676e-01
    phi[1,2]  R817      -0.953938901424408
    phi[1,2]  R818      -3.3279955387115479e-01
    phi[1,2]  R819      -7.4625766277313232e-01
    phi[1,2]  R820      -9.4432276487350464e-01
    phi[1,2]  R821      -0.905570924282074
    phi[1,2]  R822      -1.2130230665206909e+00
    phi[1,2]  R823      -1.1740211248397827e+00
    phi[1,2]  R824      -1.4113448858261108e+00
    phi[1,2]  R825      -1.2674739360809326e+00
    phi[2,1]  R9        -1
    phi[2,1]  R18       1
    phi[2,1]  R19       1
    phi[2,1]  R826      -3.0999999046325684e+00
    phi[2,1]  R827      -3.0999999046325684e+00
    phi[2,1]  R828      -2.2400000095367432e+00
    phi[2,1]  R829      -2.2400000095367432e+00
    phi[2,1]  R830      -3.0999999046325684e+00
    phi[2,1]  R831      -3.0999999046325684e+00
    phi[2,1]  R832      -2.5699999332427979e+00
    phi[2,1]  R833      -2.5699999332427979e+00
    phi[2,1]  R834      -3.0999999046325684e+00
    phi[2,1]  R835      -3.0999999046325684e+00
    phi[2,1]  R836      -2.0899999141693115e+00
    phi[2,1]  R837      -2.0899999141693115e+00
    phi[2,1]  R838      -3.0999999046325684e+00
    phi[2,1]  R839      -3.0999999046325684e+00
    phi[2,1]  R840      1.4658120870590210e+00
    phi[2,1]  R841      -5.7754196226596832e-02
    phi[2,1]  R842      -7.9105056822299957e-02
    phi[2,1]  R843      8.6138397455215454e-01
    phi[2,1]  R844      1.1949729919433594e+00
    phi[2,1]  R845      1.0626022815704346e+00
    phi[2,1]  R846      1.3570271730422974e+00
    phi[2,1]  R847      1.3911136388778687e+00
    phi[2,1]  R848      6.0133183002471924e-01
    phi[2,1]  R849      2.1430739760398865e-01
    phi[2,1]  R850      -9.1402125358581543e-01
    phi[2,1]  R851      7.3895761743187904e-03
    phi[2,1]  R852      -1.1982066631317139e+00
    phi[2,1]  R853      -1.5418968200683594e+00
    phi[2,1]  R854      -2.1503503322601318e+00
    phi[2,1]  R855      -1.1939885616302490e+00
    phi[2,1]  R856      -0.574803352355957
    phi[2,1]  R857      -9.5286267995834351e-01
    phi[2,1]  R858      -3.2604852318763733e-01
    phi[2,1]  R859      -8.7450706958770752e-01
    phi[2,1]  R860      -7.6050686836242676e-01
    phi[2,1]  R861      -0.953938901424408
    phi[2,1]  R862      -3.3279955387115479e-01
    phi[2,1]  R863      -7.4625766277313232e-01
    phi[2,1]  R864      -9.4432276487350464e-01
    phi[2,1]  R865      -0.905570924282074
    phi[2,1]  R866      -1.2130230665206909e+00
    phi[2,1]  R867      -1.1740211248397827e+00
    phi[2,1]  R868      -1.4113448858261108e+00
    phi[2,1]  R869      -1.2674739360809326e+00
    phi[2,1]  R870      7.0581710338592529e-01
    phi[2,1]  R871      1.2857401371002197e+00
    phi[2,1]  R872      1.2449791431427002e+00
    phi[2,1]  R873      7.8906130790710449e-01
    phi[2,1]  R874      1.1794650554656982e+00
    phi[2,1]  R875      7.7637231349945068e-01
    phi[2,1]  R876      7.7615588903427124e-01
    phi[2,1]  R877      1.0580040216445923e+00
    phi[2,1]  R878      -2.7246564626693726e-01
    phi[2,1]  R879      2.4565458297729492e-01
    phi[2,1]  R880      -2.6234167814254761e-01
    phi[2,1]  R881      1.0746860504150391e-01
    phi[2,1]  R882      2.6697331666946411e-01
    phi[2,1]  R883      -2.2192585468292236e-01
    phi[2,1]  R884      -5.3207254409790039e-01
    phi[2,1]  R885      -1.5096805989742279e-01
    phi[2,1]  R886      3.8666903972625732e-02
    phi[2,1]  R887      -3.6409664154052734e-01
    phi[2,1]  R888      1.8854357302188873e-01
    phi[2,1]  R889      -3.0958032608032227e-01
    phi[2,1]  R890      -1.4523614645004272e+00
    phi[2,1]  R891      -1.3720369338989258e+00
    phi[2,1]  R892      -1.6600272655487061e+00
    phi[2,1]  R893      -1.1131739616394043e+00
    phi[2,1]  R894      -1.2645827531814575e+00
    phi[2,1]  R895      -1.4135037660598755e+00
    phi[2,1]  R896      -1.0055119991302490e+00
    phi[2,1]  R897      -0.899972140789032
    phi[2,1]  R898      -1.0986747741699219e+00
    phi[2,1]  R899      -1.6302769184112549e+00
    phi[2,1]  R900      -4.7918668389320374e-01
    phi[2,1]  R901      -1.6353880167007446e+00
    phi[2,1]  R902      -1.6042659282684326e+00
    phi[2,1]  R903      -1.2693887948989868e+00
    phi[2,1]  R904      -1.9693913459777832e+00
    phi[2,1]  R905      -2.0945181846618652e+00
    phi[2,1]  R906      -1.6770938634872437e+00
    phi[2,1]  R907      -9.3601256608963013e-01
    phi[2,1]  R908      -9.1905772686004639e-01
    phi[2,1]  R909      -1.4506546258926392e+00
    phi[2,1]  R910      -1.3282465934753418e+00
    phi[2,1]  R911      -2.0819027423858643e+00
    phi[2,1]  R912      -1.6788767576217651e+00
    phi[2,1]  R913      -2.1277401447296143e+00
    phi[2,1]  R914      -2.1488819122314453e+00
    phi[2,1]  R915      -2.4454441070556641e+00
    phi[2,1]  R916      -1.2843089103698730e+00
    phi[2,1]  R917      -1.8869365453720093e+00
    phi[2,1]  R918      -1.8735146522521973e+00
    phi[2,1]  R919      -1.3547596931457520e+00
    phi[2,1]  R920      -1.4847203493118286e+00
    phi[2,1]  R921      -3.7128737568855286e-01
    phi[2,1]  R922      -5.9992873668670654e-01
    phi[2,1]  R923      -4.0980595350265503e-01
    phi[2,1]  R924      -8.9902347326278687e-01
    phi[2,1]  R925      -1.5234454870224
    phi[2,1]  R926      -2.1465973854064941e+00
    phi[2,1]  R927      -1.9807113409042358e+00
    phi[2,1]  R928      -1.1907218694686890e+00
    phi[2,1]  R929      -1.6505349874496460e+00
    phi[2,1]  R930      -2.2453193664550781e+00
    phi[2,1]  R931      -8.8201528787612915e-01
    phi[2,1]  R932      -3.8269901275634766e-01
    phi[2,1]  R933      -0.931524932384491
    phi[2,1]  R934      -9.7071743011474609e-01
    phi[2,1]  R935      -0.951265275478363
    phi[2,1]  R936      -1.0983262062072754e+00
    phi[2,1]  R937      -2.1882896423339844e+00
    phi[2,1]  R938      -1.1912208795547485e+00
    phi[2,1]  R939      -1.8264650106430054e+00
    phi[2,1]  R940      -8.3584690093994141e-01
    phi[2,1]  R941      -1.1410133838653564e+00
    phi[2,1]  R942      -1.2361494302749634e+00
    phi[2,1]  R943      -1.3587986230850220e+00
    phi[2,1]  R944      -1.5971895456314087e+00
    phi[2,1]  R945      -1.6416977643966675e+00
    phi[2,1]  R946      -1.9699259996414185e+00
    phi[2,1]  R947      -1.4119985103607178e+00
    phi[2,1]  R948      6.6172605752944946e-01
    phi[2,1]  R949      -1.5155097246170044e+00
    phi[2,3]  R18       1
    phi[2,3]  R19       1
    phi[2,3]  R27       -1
    phi[2,3]  R950      -3.0999999046325684e+00
    phi[2,3]  R951      -3.0999999046325684e+00
    phi[2,3]  R952      -2.2400000095367432e+00
    phi[2,3]  R953      -2.2400000095367432e+00
    phi[2,3]  R954      -3.0999999046325684e+00
    phi[2,3]  R955      -3.0999999046325684e+00
    phi[2,3]  R956      -2.5699999332427979e+00
    phi[2,3]  R957      -2.5699999332427979e+00
    phi[2,3]  R958      -3.0999999046325684e+00
    phi[2,3]  R959      -3.0999999046325684e+00
    phi[2,3]  R960      -2.0899999141693115e+00
    phi[2,3]  R961      -2.0899999141693115e+00
    phi[2,3]  R962      -3.0999999046325684e+00
    phi[2,3]  R963      -3.0999999046325684e+00
    phi[2,3]  R964      1.4658120870590210e+00
    phi[2,3]  R965      -5.7754196226596832e-02
    phi[2,3]  R966      -7.9105056822299957e-02
    phi[2,3]  R967      8.6138397455215454e-01
    phi[2,3]  R968      1.1949729919433594e+00
    phi[2,3]  R969      1.0626022815704346e+00
    phi[2,3]  R970      1.3570271730422974e+00
    phi[2,3]  R971      1.3911136388778687e+00
    phi[2,3]  R972      6.0133183002471924e-01
    phi[2,3]  R973      2.1430739760398865e-01
    phi[2,3]  R974      -9.1402125358581543e-01
    phi[2,3]  R975      7.3895761743187904e-03
    phi[2,3]  R976      -1.1982066631317139e+00
    phi[2,3]  R977      -1.5418968200683594e+00
    phi[2,3]  R978      -2.1503503322601318e+00
    phi[2,3]  R979      -1.1939885616302490e+00
    phi[2,3]  R980      -0.574803352355957
    phi[2,3]  R981      -9.5286267995834351e-01
    phi[2,3]  R982      -3.2604852318763733e-01
    phi[2,3]  R983      -8.7450706958770752e-01
    phi[2,3]  R984      -7.6050686836242676e-01
    phi[2,3]  R985      -0.953938901424408
    phi[2,3]  R986      -3.3279955387115479e-01
    phi[2,3]  R987      -7.4625766277313232e-01
    phi[2,3]  R988      -9.4432276487350464e-01
    phi[2,3]  R989      -0.905570924282074
    phi[2,3]  R990      -1.2130230665206909e+00
    phi[2,3]  R991      -1.1740211248397827e+00
    phi[2,3]  R992      -1.4113448858261108e+00
    phi[2,3]  R993      -1.2674739360809326e+00
    phi[2,3]  R994      2.6116118431091309e+00
    phi[2,3]  R995      2.3428595066070557e+00
    phi[2,3]  R996      1.4125819206237793e+00
    phi[2,3]  R997      2.6769866943359375e+00
    phi[2,3]  R998      1.9768807888031006e+00
    phi[2,3]  R999      1.6142692565917969e+00
    phi[2,3]  R1000     1.1479370594024658e+00
    phi[2,3]  R1001     -1.8136522769927979e+00
    phi[2,3]  R1002     4.7017911076545715e-01
    phi[2,3]  R1003     -7.1002656221389771e-01
    phi[2,3]  R1004     2.4587005376815796e-01
    phi[2,3]  R1005     2.9710370302200317e-01
    phi[2,3]  R1006     -2.1677258014678955e+00
    phi[2,3]  R1007     -3.63869571685791
    phi[2,3]  R1008     -2.3671808242797852e+00
    phi[2,3]  R1009     -2.4654386043548584e+00
    phi[2,3]  R1010     -2.6650042533874512e+00
    phi[2,3]  R1011     -6.5572863817214966e-01
    phi[2,3]  R1012     -1.0876019001007080e+00
    phi[2,3]  R1013     -8.3281016349792480e-01
    phi[2,3]  R1014     -4.8660576343536377e-02
    phi[2,3]  R1015     -2.2645955085754395e+00
    phi[2,3]  R1016     -2.4355671405792236e+00
    phi[2,3]  R1017     -5.5593299865722656e-01
    phi[2,3]  R1018     3.5417163372039795e-01
    phi[2,3]  R1019     -1.7219852209091187e+00
    phi[2,3]  R1020     -0.518085777759552
    phi[2,3]  R1021     -6.5658479928970337e-01
    phi[2,3]  R1022     -1.0012665987014771e+00
    phi[2,3]  R1023     2.8327956795692444e-01
    phi[2,3]  R1024     -1.7369184494018555e+00
    phi[2,3]  R1025     -4.3511375784873962e-01
    phi[2,3]  R1026     -2.9490668773651123e+00
    phi[2,3]  R1027     -7.5623613595962524e-01
    phi[2,3]  R1028     -2.7014782428741455e+00
    phi[2,3]  R1029     2.1670703887939453e+00
    phi[2,3]  R1030     -1.6899530887603760e+00
    phi[2,3]  R1031     -0.929190993309021
    phi[2,3]  R1032     1.5262341499328613e-01
    phi[2,3]  R1033     1.1126598119735718e+00
    phi[2,3]  R1034     4.1260561347007751e-01
    phi[2,3]  R1035     8.8630992174148560e-01
    phi[2,3]  R1036     -2.1805756092071533e+00
    phi[2,3]  R1037     -1.6860339641571045e+00
    phi[2,3]  R1038     -2.9991058632731438e-02
    phi[2,3]  R1039     -2.9526617527008057e+00
    phi[2,3]  R1040     1.8182133436203003e+00
    phi[2,3]  R1041     1.7195028066635132e-01
    phi[2,3]  R1042     1.1798889636993408e+00
    phi[2,3]  R1043     -1.6767480373382568e+00
    phi[3,2]  R18       -1
    phi[3,2]  R27       1
    phi[3,2]  R28       1
    phi[3,2]  R1044     -3.0999999046325684e+00
    phi[3,2]  R1045     -3.0999999046325684e+00
    phi[3,2]  R1046     -2.2400000095367432e+00
    phi[3,2]  R1047     -2.2400000095367432e+00
    phi[3,2]  R1048     -3.0999999046325684e+00
    phi[3,2]  R1049     -3.0999999046325684e+00
    phi[3,2]  R1050     -2.5699999332427979e+00
    phi[3,2]  R1051     -2.5699999332427979e+00
    phi[3,2]  R1052     -3.0999999046325684e+00
    phi[3,2]  R1053     -3.0999999046325684e+00
    phi[3,2]  R1054     -2.0899999141693115e+00
    phi[3,2]  R1055     -2.0899999141693115e+00
    phi[3,2]  R1056     -3.0999999046325684e+00
    phi[3,2]  R1057     -3.0999999046325684e+00
    phi[3,2]  R1058     2.6116118431091309e+00
    phi[3,2]  R1059     2.3428595066070557e+00
    phi[3,2]  R1060     1.4125819206237793e+00
    phi[3,2]  R1061     2.6769866943359375e+00
    phi[3,2]  R1062     1.9768807888031006e+00
    phi[3,2]  R1063     1.6142692565917969e+00
    phi[3,2]  R1064     1.1479370594024658e+00
    phi[3,2]  R1065     -1.8136522769927979e+00
    phi[3,2]  R1066     4.7017911076545715e-01
    phi[3,2]  R1067     -7.1002656221389771e-01
    phi[3,2]  R1068     2.4587005376815796e-01
    phi[3,2]  R1069     2.9710370302200317e-01
    phi[3,2]  R1070     -2.1677258014678955e+00
    phi[3,2]  R1071     -3.63869571685791
    phi[3,2]  R1072     -2.3671808242797852e+00
    phi[3,2]  R1073     -2.4654386043548584e+00
    phi[3,2]  R1074     -2.6650042533874512e+00
    phi[3,2]  R1075     -6.5572863817214966e-01
    phi[3,2]  R1076     -1.0876019001007080e+00
    phi[3,2]  R1077     -8.3281016349792480e-01
    phi[3,2]  R1078     -4.8660576343536377e-02
    phi[3,2]  R1079     -2.2645955085754395e+00
    phi[3,2]  R1080     -2.4355671405792236e+00
    phi[3,2]  R1081     -5.5593299865722656e-01
    phi[3,2]  R1082     3.5417163372039795e-01
    phi[3,2]  R1083     -1.7219852209091187e+00
    phi[3,2]  R1084     -0.518085777759552
    phi[3,2]  R1085     -6.5658479928970337e-01
    phi[3,2]  R1086     -1.0012665987014771e+00
    phi[3,2]  R1087     2.8327956795692444e-01
    phi[3,2]  R1088     -1.7369184494018555e+00
    phi[3,2]  R1089     -4.3511375784873962e-01
    phi[3,2]  R1090     -2.9490668773651123e+00
    phi[3,2]  R1091     -7.5623613595962524e-01
    phi[3,2]  R1092     -2.7014782428741455e+00
    phi[3,2]  R1093     2.1670703887939453e+00
    phi[3,2]  R1094     -1.6899530887603760e+00
    phi[3,2]  R1095     -0.929190993309021
    phi[3,2]  R1096     1.5262341499328613e-01
    phi[3,2]  R1097     1.1126598119735718e+00
    phi[3,2]  R1098     4.1260561347007751e-01
    phi[3,2]  R1099     8.8630992174148560e-01
    phi[3,2]  R1100     -2.1805756092071533e+00
    phi[3,2]  R1101     -1.6860339641571045e+00
    phi[3,2]  R1102     -2.9991058632731438e-02
    phi[3,2]  R1103     -2.9526617527008057e+00
    phi[3,2]  R1104     1.8182133436203003e+00
    phi[3,2]  R1105     1.7195028066635132e-01
    phi[3,2]  R1106     1.1798889636993408e+00
    phi[3,2]  R1107     -1.6767480373382568e+00
    phi[3,2]  R1108     1.4658120870590210e+00
    phi[3,2]  R1109     -5.7754196226596832e-02
    phi[3,2]  R1110     -7.9105056822299957e-02
    phi[3,2]  R1111     8.6138397455215454e-01
    phi[3,2]  R1112     1.1949729919433594e+00
    phi[3,2]  R1113     1.0626022815704346e+00
    phi[3,2]  R1114     1.3570271730422974e+00
    phi[3,2]  R1115     1.3911136388778687e+00
    phi[3,2]  R1116     6.0133183002471924e-01
    phi[3,2]  R1117     2.1430739760398865e-01
    phi[3,2]  R1118     -9.1402125358581543e-01
    phi[3,2]  R1119     7.3895761743187904e-03
    phi[3,2]  R1120     -1.1982066631317139e+00
    phi[3,2]  R1121     -1.5418968200683594e+00
    phi[3,2]  R1122     -2.1503503322601318e+00
    phi[3,2]  R1123     -1.1939885616302490e+00
    phi[3,2]  R1124     -0.574803352355957
    phi[3,2]  R1125     -9.5286267995834351e-01
    phi[3,2]  R1126     -3.2604852318763733e-01
    phi[3,2]  R1127     -8.7450706958770752e-01
    phi[3,2]  R1128     -7.6050686836242676e-01
    phi[3,2]  R1129     -0.953938901424408
    phi[3,2]  R1130     -3.3279955387115479e-01
    phi[3,2]  R1131     -7.4625766277313232e-01
    phi[3,2]  R1132     -9.4432276487350464e-01
    phi[3,2]  R1133     -0.905570924282074
    phi[3,2]  R1134     -1.2130230665206909e+00
    phi[3,2]  R1135     -1.1740211248397827e+00
    phi[3,2]  R1136     -1.4113448858261108e+00
    phi[3,2]  R1137     -1.2674739360809326e+00
    phi[3,4]  R27       1
    phi[3,4]  R28       1
    phi[3,4]  R36       -1
    phi[3,4]  R1138     -3.0999999046325684e+00
    phi[3,4]  R1139     -3.0999999046325684e+00
    phi[3,4]  R1140     -2.2400000095367432e+00
    phi[3,4]  R1141     -2.2400000095367432e+00
    phi[3,4]  R1142     -3.0999999046325684e+00
    phi[3,4]  R1143     -3.0999999046325684e+00
    phi[3,4]  R1144     -2.5699999332427979e+00
    phi[3,4]  R1145     -2.5699999332427979e+00
    phi[3,4]  R1146     -3.0999999046325684e+00
    phi[3,4]  R1147     -3.0999999046325684e+00
    phi[3,4]  R1148     -2.0899999141693115e+00
    phi[3,4]  R1149     -2.0899999141693115e+00
    phi[3,4]  R1150     -3.0999999046325684e+00
    phi[3,4]  R1151     -3.0999999046325684e+00
    phi[3,4]  R1152     2.6116118431091309e+00
    phi[3,4]  R1153     2.3428595066070557e+00
    phi[3,4]  R1154     1.4125819206237793e+00
    phi[3,4]  R1155     2.6769866943359375e+00
    phi[3,4]  R1156     1.9768807888031006e+00
    phi[3,4]  R1157     1.6142692565917969e+00
    phi[3,4]  R1158     1.1479370594024658e+00
    phi[3,4]  R1159     -1.8136522769927979e+00
    phi[3,4]  R1160     4.7017911076545715e-01
    phi[3,4]  R1161     -7.1002656221389771e-01
    phi[3,4]  R1162     2.4587005376815796e-01
    phi[3,4]  R1163     2.9710370302200317e-01
    phi[3,4]  R1164     -2.1677258014678955e+00
    phi[3,4]  R1165     -3.63869571685791
    phi[3,4]  R1166     -2.3671808242797852e+00
    phi[3,4]  R1167     -2.4654386043548584e+00
    phi[3,4]  R1168     -2.6650042533874512e+00
    phi[3,4]  R1169     -6.5572863817214966e-01
    phi[3,4]  R1170     -1.0876019001007080e+00
    phi[3,4]  R1171     -8.3281016349792480e-01
    phi[3,4]  R1172     -4.8660576343536377e-02
    phi[3,4]  R1173     -2.2645955085754395e+00
    phi[3,4]  R1174     -2.4355671405792236e+00
    phi[3,4]  R1175     -5.5593299865722656e-01
    phi[3,4]  R1176     3.5417163372039795e-01
    phi[3,4]  R1177     -1.7219852209091187e+00
    phi[3,4]  R1178     -0.518085777759552
    phi[3,4]  R1179     -6.5658479928970337e-01
    phi[3,4]  R1180     -1.0012665987014771e+00
    phi[3,4]  R1181     2.8327956795692444e-01
    phi[3,4]  R1182     -1.7369184494018555e+00
    phi[3,4]  R1183     -4.3511375784873962e-01
    phi[3,4]  R1184     -2.9490668773651123e+00
    phi[3,4]  R1185     -7.5623613595962524e-01
    phi[3,4]  R1186     -2.7014782428741455e+00
    phi[3,4]  R1187     2.1670703887939453e+00
    phi[3,4]  R1188     -1.6899530887603760e+00
    phi[3,4]  R1189     -0.929190993309021
    phi[3,4]  R1190     1.5262341499328613e-01
    phi[3,4]  R1191     1.1126598119735718e+00
    phi[3,4]  R1192     4.1260561347007751e-01
    phi[3,4]  R1193     8.8630992174148560e-01
    phi[3,4]  R1194     -2.1805756092071533e+00
    phi[3,4]  R1195     -1.6860339641571045e+00
    phi[3,4]  R1196     -2.9991058632731438e-02
    phi[3,4]  R1197     -2.9526617527008057e+00
    phi[3,4]  R1198     1.8182133436203003e+00
    phi[3,4]  R1199     1.7195028066635132e-01
    phi[3,4]  R1200     1.1798889636993408e+00
    phi[3,4]  R1201     -1.6767480373382568e+00
    phi[3,4]  R1202     2.0504984855651855e+00
    phi[3,4]  R1203     1.4607239522954041e+00
    phi[3,4]  R1204     1.8133019208908081e+00
    phi[3,4]  R1205     2.7551195621490479e+00
    phi[3,4]  R1206     1.3843770027160645e+00
    phi[3,4]  R1207     2.7831139564514160e+00
    phi[3,4]  R1208     -1.5238615274429321e+00
    phi[3,4]  R1209     -1.4713011980056763e+00
    phi[3,4]  R1210     -1.1879136562347412e+00
    phi[3,4]  R1211     -1.2052880525588989e+00
    phi[3,4]  R1212     -1.1772027015686035e+00
    phi[3,4]  R1213     -2.5062782764434814e+00
    phi[3,4]  R1214     -1.4135143756866455e+00
    phi[3,4]  R1215     -2.4065425395965576e+00
    phi[3,4]  R1216     -1.8241934776306152e+00
    phi[3,4]  R1217     -1.9043525457382202e+00
    phi[3,4]  R1218     -1.7906099557876587e+00
    phi[3,4]  R1219     -2.6166238784790039e+00
    phi[3,4]  R1220     -1.7834196090698242e+00
    phi[3,4]  R1221     -2.5860879421234131e+00
    phi[3,4]  R1222     -1.6888539791107178e+00
    phi[3,4]  R1223     -3.3092260360717773e+00
    phi[3,4]  R1224     -3.7378447055816650e+00
    phi[3,4]  R1225     -1.6323626041412354e+00
    phi[3,4]  R1226     -3.0610327720642090e+00
    phi[3,4]  R1227     -1.9601497650146484e+00
    phi[3,4]  R1228     -1.3332855701446533e+00
    phi[3,4]  R1229     -2.46878719329834
    phi[3,4]  R1230     -8.2436317205429077e-01
    phi[3,4]  R1231     -2.5422053337097168e+00
    phi[3,4]  R1232     -2.9593608379364014e+00
    phi[3,4]  R1233     -2.4547948837280273e+00
    phi[3,4]  R1234     -3.0957715511322021e+00
    phi[3,4]  R1235     -6.2937736511230469e-01
    phi[3,4]  R1236     -2.1101157665252686e+00
    phi[3,4]  R1237     -3.2142570018768311e+00
    phi[3,4]  R1238     -2.5391712188720703e+00
    phi[3,4]  R1239     -3.8103899359703064e-01
    phi[3,4]  R1240     -5.9473669528961182e-01
    phi[3,4]  R1241     -1.9749791622161865e+00
    phi[3,4]  R1242     -2.6896078586578369e+00
    phi[3,4]  R1243     -2.4965779781341553e+00
    phi[3,4]  R1244     -2.1084840297698975e+00
    phi[3,4]  R1245     -1.3441803455352783e+00
    phi[3,4]  R1246     -1.2918095588684082e+00
    phi[3,4]  R1247     -1.0827403068542480e+00
    phi[3,4]  R1248     -1.2158010005950928e+00
    phi[3,4]  R1249     -1.4672069549560547e+00
    phi[3,4]  R1250     -3.0408098697662354e+00
    phi[3,4]  R1251     -9.9878787994384766e-01
    phi[3,4]  R1252     -1.4728426933288574e+00
    phi[3,4]  R1253     -1.1662852764129639e+00
    phi[3,4]  R1254     -1.5392550230026245e+00
    phi[3,4]  R1255     -2.3524663448333740e+00
    phi[3,4]  R1256     -2.7543728351593018e+00
    phi[3,4]  R1257     -2.4234511852264404e+00
    phi[3,4]  R1258     -1.4371293783187866e+00
    phi[3,4]  R1259     -2.6083736419677734e+00
    phi[3,4]  R1260     -1.8450063467025757e+00
    phi[3,4]  R1261     -1.5023406744003296e+00
    phi[3,4]  R1262     -1.8588010072708130e+00
    phi[3,4]  R1263     -2.5887765884399414e+00
    phi[3,4]  R1264     -2.8790297508239746e+00
    phi[3,4]  R1265     -3.5091674327850342e+00
    phi[3,4]  R1266     -3.1712961196899414e+00
    phi[3,4]  R1267     -1.4492106437683105e+00
    phi[3,4]  R1268     -2.8066310882568359e+00
    phi[3,4]  R1269     -2.8550586700439453e+00
    phi[3,4]  R1270     -9.0011346340179443e-01
    phi[3,4]  R1271     -1.8232712745666504e+00
    phi[3,4]  R1272     -4.0990343093872070e+00
    phi[3,4]  R1273     -3.2912700176239014e+00
    phi[3,4]  R1274     -3.5499916076660156e+00
    phi[3,4]  R1275     -2.0356371402740479e+00
    phi[3,4]  R1276     -1.5581924915313721e+00
    phi[3,4]  R1277     -1.7733958959579468e+00
    phi[4,3]  R27       -1
    phi[4,3]  R36       1
    phi[4,3]  R37       1
    phi[4,3]  R1278     -3.0999999046325684e+00
    phi[4,3]  R1279     -3.0999999046325684e+00
    phi[4,3]  R1280     -2.2400000095367432e+00
    phi[4,3]  R1281     -2.2400000095367432e+00
    phi[4,3]  R1282     -3.0999999046325684e+00
    phi[4,3]  R1283     -3.0999999046325684e+00
    phi[4,3]  R1284     -2.5699999332427979e+00
    phi[4,3]  R1285     -2.5699999332427979e+00
    phi[4,3]  R1286     -3.0999999046325684e+00
    phi[4,3]  R1287     -3.0999999046325684e+00
    phi[4,3]  R1288     -2.0899999141693115e+00
    phi[4,3]  R1289     -2.0899999141693115e+00
    phi[4,3]  R1290     -3.0999999046325684e+00
    phi[4,3]  R1291     -3.0999999046325684e+00
    phi[4,3]  R1292     2.0504984855651855e+00
    phi[4,3]  R1293     1.4607239522954041e+00
    phi[4,3]  R1294     1.8133019208908081e+00
    phi[4,3]  R1295     2.7551195621490479e+00
    phi[4,3]  R1296     1.3843770027160645e+00
    phi[4,3]  R1297     2.7831139564514160e+00
    phi[4,3]  R1298     -1.5238615274429321e+00
    phi[4,3]  R1299     -1.4713011980056763e+00
    phi[4,3]  R1300     -1.1879136562347412e+00
    phi[4,3]  R1301     -1.2052880525588989e+00
    phi[4,3]  R1302     -1.1772027015686035e+00
    phi[4,3]  R1303     -2.5062782764434814e+00
    phi[4,3]  R1304     -1.4135143756866455e+00
    phi[4,3]  R1305     -2.4065425395965576e+00
    phi[4,3]  R1306     -1.8241934776306152e+00
    phi[4,3]  R1307     -1.9043525457382202e+00
    phi[4,3]  R1308     -1.7906099557876587e+00
    phi[4,3]  R1309     -2.6166238784790039e+00
    phi[4,3]  R1310     -1.7834196090698242e+00
    phi[4,3]  R1311     -2.5860879421234131e+00
    phi[4,3]  R1312     -1.6888539791107178e+00
    phi[4,3]  R1313     -3.3092260360717773e+00
    phi[4,3]  R1314     -3.7378447055816650e+00
    phi[4,3]  R1315     -1.6323626041412354e+00
    phi[4,3]  R1316     -3.0610327720642090e+00
    phi[4,3]  R1317     -1.9601497650146484e+00
    phi[4,3]  R1318     -1.3332855701446533e+00
    phi[4,3]  R1319     -2.46878719329834
    phi[4,3]  R1320     -8.2436317205429077e-01
    phi[4,3]  R1321     -2.5422053337097168e+00
    phi[4,3]  R1322     -2.9593608379364014e+00
    phi[4,3]  R1323     -2.4547948837280273e+00
    phi[4,3]  R1324     -3.0957715511322021e+00
    phi[4,3]  R1325     -6.2937736511230469e-01
    phi[4,3]  R1326     -2.1101157665252686e+00
    phi[4,3]  R1327     -3.2142570018768311e+00
    phi[4,3]  R1328     -2.5391712188720703e+00
    phi[4,3]  R1329     -3.8103899359703064e-01
    phi[4,3]  R1330     -5.9473669528961182e-01
    phi[4,3]  R1331     -1.9749791622161865e+00
    phi[4,3]  R1332     -2.6896078586578369e+00
    phi[4,3]  R1333     -2.4965779781341553e+00
    phi[4,3]  R1334     -2.1084840297698975e+00
    phi[4,3]  R1335     -1.3441803455352783e+00
    phi[4,3]  R1336     -1.2918095588684082e+00
    phi[4,3]  R1337     -1.0827403068542480e+00
    phi[4,3]  R1338     -1.2158010005950928e+00
    phi[4,3]  R1339     -1.4672069549560547e+00
    phi[4,3]  R1340     -3.0408098697662354e+00
    phi[4,3]  R1341     -9.9878787994384766e-01
    phi[4,3]  R1342     -1.4728426933288574e+00
    phi[4,3]  R1343     -1.1662852764129639e+00
    phi[4,3]  R1344     -1.5392550230026245e+00
    phi[4,3]  R1345     -2.3524663448333740e+00
    phi[4,3]  R1346     -2.7543728351593018e+00
    phi[4,3]  R1347     -2.4234511852264404e+00
    phi[4,3]  R1348     -1.4371293783187866e+00
    phi[4,3]  R1349     -2.6083736419677734e+00
    phi[4,3]  R1350     -1.8450063467025757e+00
    phi[4,3]  R1351     -1.5023406744003296e+00
    phi[4,3]  R1352     -1.8588010072708130e+00
    phi[4,3]  R1353     -2.5887765884399414e+00
    phi[4,3]  R1354     -2.8790297508239746e+00
    phi[4,3]  R1355     -3.5091674327850342e+00
    phi[4,3]  R1356     -3.1712961196899414e+00
    phi[4,3]  R1357     -1.4492106437683105e+00
    phi[4,3]  R1358     -2.8066310882568359e+00
    phi[4,3]  R1359     -2.8550586700439453e+00
    phi[4,3]  R1360     -9.0011346340179443e-01
    phi[4,3]  R1361     -1.8232712745666504e+00
    phi[4,3]  R1362     -4.0990343093872070e+00
    phi[4,3]  R1363     -3.2912700176239014e+00
    phi[4,3]  R1364     -3.5499916076660156e+00
    phi[4,3]  R1365     -2.0356371402740479e+00
    phi[4,3]  R1366     -1.5581924915313721e+00
    phi[4,3]  R1367     -1.7733958959579468e+00
    phi[4,3]  R1368     2.6116118431091309e+00
    phi[4,3]  R1369     2.3428595066070557e+00
    phi[4,3]  R1370     1.4125819206237793e+00
    phi[4,3]  R1371     2.6769866943359375e+00
    phi[4,3]  R1372     1.9768807888031006e+00
    phi[4,3]  R1373     1.6142692565917969e+00
    phi[4,3]  R1374     1.1479370594024658e+00
    phi[4,3]  R1375     -1.8136522769927979e+00
    phi[4,3]  R1376     4.7017911076545715e-01
    phi[4,3]  R1377     -7.1002656221389771e-01
    phi[4,3]  R1378     2.4587005376815796e-01
    phi[4,3]  R1379     2.9710370302200317e-01
    phi[4,3]  R1380     -2.1677258014678955e+00
    phi[4,3]  R1381     -3.63869571685791
    phi[4,3]  R1382     -2.3671808242797852e+00
    phi[4,3]  R1383     -2.4654386043548584e+00
    phi[4,3]  R1384     -2.6650042533874512e+00
    phi[4,3]  R1385     -6.5572863817214966e-01
    phi[4,3]  R1386     -1.0876019001007080e+00
    phi[4,3]  R1387     -8.3281016349792480e-01
    phi[4,3]  R1388     -4.8660576343536377e-02
    phi[4,3]  R1389     -2.2645955085754395e+00
    phi[4,3]  R1390     -2.4355671405792236e+00
    phi[4,3]  R1391     -5.5593299865722656e-01
    phi[4,3]  R1392     3.5417163372039795e-01
    phi[4,3]  R1393     -1.7219852209091187e+00
    phi[4,3]  R1394     -0.518085777759552
    phi[4,3]  R1395     -6.5658479928970337e-01
    phi[4,3]  R1396     -1.0012665987014771e+00
    phi[4,3]  R1397     2.8327956795692444e-01
    phi[4,3]  R1398     -1.7369184494018555e+00
    phi[4,3]  R1399     -4.3511375784873962e-01
    phi[4,3]  R1400     -2.9490668773651123e+00
    phi[4,3]  R1401     -7.5623613595962524e-01
    phi[4,3]  R1402     -2.7014782428741455e+00
    phi[4,3]  R1403     2.1670703887939453e+00
    phi[4,3]  R1404     -1.6899530887603760e+00
    phi[4,3]  R1405     -0.929190993309021
    phi[4,3]  R1406     1.5262341499328613e-01
    phi[4,3]  R1407     1.1126598119735718e+00
    phi[4,3]  R1408     4.1260561347007751e-01
    phi[4,3]  R1409     8.8630992174148560e-01
    phi[4,3]  R1410     -2.1805756092071533e+00
    phi[4,3]  R1411     -1.6860339641571045e+00
    phi[4,3]  R1412     -2.9991058632731438e-02
    phi[4,3]  R1413     -2.9526617527008057e+00
    phi[4,3]  R1414     1.8182133436203003e+00
    phi[4,3]  R1415     1.7195028066635132e-01
    phi[4,3]  R1416     1.1798889636993408e+00
    phi[4,3]  R1417     -1.6767480373382568e+00
    phi[4,9]  R36       1
    phi[4,9]  R37       1
    phi[4,9]  R81       -1
    phi[4,9]  R1418     -3.0999999046325684e+00
    phi[4,9]  R1419     -3.0999999046325684e+00
    phi[4,9]  R1420     -2.2400000095367432e+00
    phi[4,9]  R1421     -2.2400000095367432e+00
    phi[4,9]  R1422     -3.0999999046325684e+00
    phi[4,9]  R1423     -3.0999999046325684e+00
    phi[4,9]  R1424     -2.5699999332427979e+00
    phi[4,9]  R1425     -2.5699999332427979e+00
    phi[4,9]  R1426     -3.0999999046325684e+00
    phi[4,9]  R1427     -3.0999999046325684e+00
    phi[4,9]  R1428     -2.0899999141693115e+00
    phi[4,9]  R1429     -2.0899999141693115e+00
    phi[4,9]  R1430     -3.0999999046325684e+00
    phi[4,9]  R1431     -3.0999999046325684e+00
    phi[4,9]  R1432     2.0504984855651855e+00
    phi[4,9]  R1433     1.4607239522954041e+00
    phi[4,9]  R1434     1.8133019208908081e+00
    phi[4,9]  R1435     2.7551195621490479e+00
    phi[4,9]  R1436     1.3843770027160645e+00
    phi[4,9]  R1437     2.7831139564514160e+00
    phi[4,9]  R1438     -1.5238615274429321e+00
    phi[4,9]  R1439     -1.4713011980056763e+00
    phi[4,9]  R1440     -1.1879136562347412e+00
    phi[4,9]  R1441     -1.2052880525588989e+00
    phi[4,9]  R1442     -1.1772027015686035e+00
    phi[4,9]  R1443     -2.5062782764434814e+00
    phi[4,9]  R1444     -1.4135143756866455e+00
    phi[4,9]  R1445     -2.4065425395965576e+00
    phi[4,9]  R1446     -1.8241934776306152e+00
    phi[4,9]  R1447     -1.9043525457382202e+00
    phi[4,9]  R1448     -1.7906099557876587e+00
    phi[4,9]  R1449     -2.6166238784790039e+00
    phi[4,9]  R1450     -1.7834196090698242e+00
    phi[4,9]  R1451     -2.5860879421234131e+00
    phi[4,9]  R1452     -1.6888539791107178e+00
    phi[4,9]  R1453     -3.3092260360717773e+00
    phi[4,9]  R1454     -3.7378447055816650e+00
    phi[4,9]  R1455     -1.6323626041412354e+00
    phi[4,9]  R1456     -3.0610327720642090e+00
    phi[4,9]  R1457     -1.9601497650146484e+00
    phi[4,9]  R1458     -1.3332855701446533e+00
    phi[4,9]  R1459     -2.46878719329834
    phi[4,9]  R1460     -8.2436317205429077e-01
    phi[4,9]  R1461     -2.5422053337097168e+00
    phi[4,9]  R1462     -2.9593608379364014e+00
    phi[4,9]  R1463     -2.4547948837280273e+00
    phi[4,9]  R1464     -3.0957715511322021e+00
    phi[4,9]  R1465     -6.2937736511230469e-01
    phi[4,9]  R1466     -2.1101157665252686e+00
    phi[4,9]  R1467     -3.2142570018768311e+00
    phi[4,9]  R1468     -2.5391712188720703e+00
    phi[4,9]  R1469     -3.8103899359703064e-01
    phi[4,9]  R1470     -5.9473669528961182e-01
    phi[4,9]  R1471     -1.9749791622161865e+00
    phi[4,9]  R1472     -2.6896078586578369e+00
    phi[4,9]  R1473     -2.4965779781341553e+00
    phi[4,9]  R1474     -2.1084840297698975e+00
    phi[4,9]  R1475     -1.3441803455352783e+00
    phi[4,9]  R1476     -1.2918095588684082e+00
    phi[4,9]  R1477     -1.0827403068542480e+00
    phi[4,9]  R1478     -1.2158010005950928e+00
    phi[4,9]  R1479     -1.4672069549560547e+00
    phi[4,9]  R1480     -3.0408098697662354e+00
    phi[4,9]  R1481     -9.9878787994384766e-01
    phi[4,9]  R1482     -1.4728426933288574e+00
    phi[4,9]  R1483     -1.1662852764129639e+00
    phi[4,9]  R1484     -1.5392550230026245e+00
    phi[4,9]  R1485     -2.3524663448333740e+00
    phi[4,9]  R1486     -2.7543728351593018e+00
    phi[4,9]  R1487     -2.4234511852264404e+00
    phi[4,9]  R1488     -1.4371293783187866e+00
    phi[4,9]  R1489     -2.6083736419677734e+00
    phi[4,9]  R1490     -1.8450063467025757e+00
    phi[4,9]  R1491     -1.5023406744003296e+00
    phi[4,9]  R1492     -1.8588010072708130e+00
    phi[4,9]  R1493     -2.5887765884399414e+00
    phi[4,9]  R1494     -2.8790297508239746e+00
    phi[4,9]  R1495     -3.5091674327850342e+00
    phi[4,9]  R1496     -3.1712961196899414e+00
    phi[4,9]  R1497     -1.4492106437683105e+00
    phi[4,9]  R1498     -2.8066310882568359e+00
    phi[4,9]  R1499     -2.8550586700439453e+00
    phi[4,9]  R1500     -9.0011346340179443e-01
    phi[4,9]  R1501     -1.8232712745666504e+00
    phi[4,9]  R1502     -4.0990343093872070e+00
    phi[4,9]  R1503     -3.2912700176239014e+00
    phi[4,9]  R1504     -3.5499916076660156e+00
    phi[4,9]  R1505     -2.0356371402740479e+00
    phi[4,9]  R1506     -1.5581924915313721e+00
    phi[4,9]  R1507     -1.7733958959579468e+00
    phi[4,9]  R1508     1.9444248676300049e+00
    phi[4,9]  R1509     1.4549728631973267e+00
    phi[4,9]  R1510     2.3942992687225342e+00
    phi[4,9]  R1511     2.0392901897430420e+00
    phi[4,9]  R1512     4.6727928519248962e-01
    phi[4,9]  R1513     -4.8645758628845215e-01
    phi[4,9]  R1514     3.0442276597023010e-01
    phi[4,9]  R1515     -1.0067421197891235e+00
    phi[4,9]  R1516     -2.2300343513488770e+00
    phi[4,9]  R1517     -2.38210129737854
    phi[4,9]  R1518     -2.5662178993225098e+00
    phi[4,9]  R1519     -1.4659725427627563e+00
    phi[4,9]  R1520     -9.7503942251205444e-01
    phi[4,9]  R1521     -1.4028270542621613e-01
    phi[4,9]  R1522     -1.2299046516418457e+00
    phi[4,9]  R1523     -9.9255681037902832e-01
    phi[4,9]  R1524     -1.12095046043396
    phi[4,9]  R1525     -2.03456711769104
    phi[4,9]  R1526     -2.6443424224853516e+00
    phi[4,9]  R1527     -1.5438759326934814e+00
    phi[4,9]  R1528     -1.1194546222686768e+00
    phi[4,9]  R1529     -2.4674823284149170e+00
    phi[4,9]  R1530     -7.4181622266769409e-01
    phi[4,9]  R1531     -1.8904321193695068e+00
    phi[4,9]  R1532     -2.2201573848724365e+00
    phi[4,9]  R1533     -1.1348236799240112e+00
    phi[4,9]  R1534     -1.0030443668365479e+00
    phi[4,9]  R1535     -4.9550110101699829e-01
    phi[4,9]  R1536     -1.1913045644760132e+00
    phi[4,9]  R1537     -1.4331978559494019e+00
    phi[4,9]  R1538     -1.0425816774368286e+00
    phi[4,9]  R1539     -1.2760782241821289e+00
    phi[4,9]  R1540     -2.9680292606353760e+00
    phi[4,9]  R1541     -2.5917289257049561e+00
    phi[9,4]  R36       -1
    phi[9,4]  R81       1
    phi[9,4]  R82       1
    phi[9,4]  R1542     -3.0999999046325684e+00
    phi[9,4]  R1543     -3.0999999046325684e+00
    phi[9,4]  R1544     -2.2400000095367432e+00
    phi[9,4]  R1545     -2.2400000095367432e+00
    phi[9,4]  R1546     -3.0999999046325684e+00
    phi[9,4]  R1547     -3.0999999046325684e+00
    phi[9,4]  R1548     -2.5699999332427979e+00
    phi[9,4]  R1549     -2.5699999332427979e+00
    phi[9,4]  R1550     -3.0999999046325684e+00
    phi[9,4]  R1551     -3.0999999046325684e+00
    phi[9,4]  R1552     -2.0899999141693115e+00
    phi[9,4]  R1553     -2.0899999141693115e+00
    phi[9,4]  R1554     -3.0999999046325684e+00
    phi[9,4]  R1555     -3.0999999046325684e+00
    phi[9,4]  R1556     1.9444248676300049e+00
    phi[9,4]  R1557     1.4549728631973267e+00
    phi[9,4]  R1558     2.3942992687225342e+00
    phi[9,4]  R1559     2.0392901897430420e+00
    phi[9,4]  R1560     4.6727928519248962e-01
    phi[9,4]  R1561     -4.8645758628845215e-01
    phi[9,4]  R1562     3.0442276597023010e-01
    phi[9,4]  R1563     -1.0067421197891235e+00
    phi[9,4]  R1564     -2.2300343513488770e+00
    phi[9,4]  R1565     -2.38210129737854
    phi[9,4]  R1566     -2.5662178993225098e+00
    phi[9,4]  R1567     -1.4659725427627563e+00
    phi[9,4]  R1568     -9.7503942251205444e-01
    phi[9,4]  R1569     -1.4028270542621613e-01
    phi[9,4]  R1570     -1.2299046516418457e+00
    phi[9,4]  R1571     -9.9255681037902832e-01
    phi[9,4]  R1572     -1.12095046043396
    phi[9,4]  R1573     -2.03456711769104
    phi[9,4]  R1574     -2.6443424224853516e+00
    phi[9,4]  R1575     -1.5438759326934814e+00
    phi[9,4]  R1576     -1.1194546222686768e+00
    phi[9,4]  R1577     -2.4674823284149170e+00
    phi[9,4]  R1578     -7.4181622266769409e-01
    phi[9,4]  R1579     -1.8904321193695068e+00
    phi[9,4]  R1580     -2.2201573848724365e+00
    phi[9,4]  R1581     -1.1348236799240112e+00
    phi[9,4]  R1582     -1.0030443668365479e+00
    phi[9,4]  R1583     -4.9550110101699829e-01
    phi[9,4]  R1584     -1.1913045644760132e+00
    phi[9,4]  R1585     -1.4331978559494019e+00
    phi[9,4]  R1586     -1.0425816774368286e+00
    phi[9,4]  R1587     -1.2760782241821289e+00
    phi[9,4]  R1588     -2.9680292606353760e+00
    phi[9,4]  R1589     -2.5917289257049561e+00
    phi[9,4]  R1590     2.0504984855651855e+00
    phi[9,4]  R1591     1.4607239522954041e+00
    phi[9,4]  R1592     1.8133019208908081e+00
    phi[9,4]  R1593     2.7551195621490479e+00
    phi[9,4]  R1594     1.3843770027160645e+00
    phi[9,4]  R1595     2.7831139564514160e+00
    phi[9,4]  R1596     -1.5238615274429321e+00
    phi[9,4]  R1597     -1.4713011980056763e+00
    phi[9,4]  R1598     -1.1879136562347412e+00
    phi[9,4]  R1599     -1.2052880525588989e+00
    phi[9,4]  R1600     -1.1772027015686035e+00
    phi[9,4]  R1601     -2.5062782764434814e+00
    phi[9,4]  R1602     -1.4135143756866455e+00
    phi[9,4]  R1603     -2.4065425395965576e+00
    phi[9,4]  R1604     -1.8241934776306152e+00
    phi[9,4]  R1605     -1.9043525457382202e+00
    phi[9,4]  R1606     -1.7906099557876587e+00
    phi[9,4]  R1607     -2.6166238784790039e+00
    phi[9,4]  R1608     -1.7834196090698242e+00
    phi[9,4]  R1609     -2.5860879421234131e+00
    phi[9,4]  R1610     -1.6888539791107178e+00
    phi[9,4]  R1611     -3.3092260360717773e+00
    phi[9,4]  R1612     -3.7378447055816650e+00
    phi[9,4]  R1613     -1.6323626041412354e+00
    phi[9,4]  R1614     -3.0610327720642090e+00
    phi[9,4]  R1615     -1.9601497650146484e+00
    phi[9,4]  R1616     -1.3332855701446533e+00
    phi[9,4]  R1617     -2.46878719329834
    phi[9,4]  R1618     -8.2436317205429077e-01
    phi[9,4]  R1619     -2.5422053337097168e+00
    phi[9,4]  R1620     -2.9593608379364014e+00
    phi[9,4]  R1621     -2.4547948837280273e+00
    phi[9,4]  R1622     -3.0957715511322021e+00
    phi[9,4]  R1623     -6.2937736511230469e-01
    phi[9,4]  R1624     -2.1101157665252686e+00
    phi[9,4]  R1625     -3.2142570018768311e+00
    phi[9,4]  R1626     -2.5391712188720703e+00
    phi[9,4]  R1627     -3.8103899359703064e-01
    phi[9,4]  R1628     -5.9473669528961182e-01
    phi[9,4]  R1629     -1.9749791622161865e+00
    phi[9,4]  R1630     -2.6896078586578369e+00
    phi[9,4]  R1631     -2.4965779781341553e+00
    phi[9,4]  R1632     -2.1084840297698975e+00
    phi[9,4]  R1633     -1.3441803455352783e+00
    phi[9,4]  R1634     -1.2918095588684082e+00
    phi[9,4]  R1635     -1.0827403068542480e+00
    phi[9,4]  R1636     -1.2158010005950928e+00
    phi[9,4]  R1637     -1.4672069549560547e+00
    phi[9,4]  R1638     -3.0408098697662354e+00
    phi[9,4]  R1639     -9.9878787994384766e-01
    phi[9,4]  R1640     -1.4728426933288574e+00
    phi[9,4]  R1641     -1.1662852764129639e+00
    phi[9,4]  R1642     -1.5392550230026245e+00
    phi[9,4]  R1643     -2.3524663448333740e+00
    phi[9,4]  R1644     -2.7543728351593018e+00
    phi[9,4]  R1645     -2.4234511852264404e+00
    phi[9,4]  R1646     -1.4371293783187866e+00
    phi[9,4]  R1647     -2.6083736419677734e+00
    phi[9,4]  R1648     -1.8450063467025757e+00
    phi[9,4]  R1649     -1.5023406744003296e+00
    phi[9,4]  R1650     -1.8588010072708130e+00
    phi[9,4]  R1651     -2.5887765884399414e+00
    phi[9,4]  R1652     -2.8790297508239746e+00
    phi[9,4]  R1653     -3.5091674327850342e+00
    phi[9,4]  R1654     -3.1712961196899414e+00
    phi[9,4]  R1655     -1.4492106437683105e+00
    phi[9,4]  R1656     -2.8066310882568359e+00
    phi[9,4]  R1657     -2.8550586700439453e+00
    phi[9,4]  R1658     -9.0011346340179443e-01
    phi[9,4]  R1659     -1.8232712745666504e+00
    phi[9,4]  R1660     -4.0990343093872070e+00
    phi[9,4]  R1661     -3.2912700176239014e+00
    phi[9,4]  R1662     -3.5499916076660156e+00
    phi[9,4]  R1663     -2.0356371402740479e+00
    phi[9,4]  R1664     -1.5581924915313721e+00
    phi[9,4]  R1665     -1.7733958959579468e+00
    phi[4,11]  R36       1
    phi[4,11]  R37       1
    phi[4,11]  R38       -2.3659294656801513e+00
    phi[4,11]  R39       1.61396413869553
    phi[4,11]  R40       7.2004346022925292e-01
    phi[4,11]  R41       -1.1164516108306279e+00
    phi[4,11]  R42       -1.6949008548941715e+00
    phi[4,11]  R43       4.8224095273947909e-01
    phi[4,11]  R44       -6.2122488005295651e-01
    phi[4,11]  R91       -1
    phi[4,11]  R1666     -5.46592937031272
    phi[4,11]  R1667     -7.3407043895241708e-01
    phi[4,11]  R1668     -6.2603587084121326e-01
    phi[4,11]  R1669     -3.8539641482322731e+00
    phi[4,11]  R1670     -2.3799564444033154e+00
    phi[4,11]  R1671     -3.8200433648618213e+00
    phi[4,11]  R1672     -3.6864515440734258e+00
    phi[4,11]  R1673     -1.45354832241217
    phi[4,11]  R1674     -4.79490075952674
    phi[4,11]  R1675     -1.4050990497383968e+00
    phi[4,11]  R1676     -1.6077589614298324e+00
    phi[4,11]  R1677     -2.5722408669087908e+00
    phi[4,11]  R1678     -3.7212247846855249e+00
    phi[4,11]  R1679     -2.4787750245796119e+00
    phi[4,11]  R1680     -1.3431095347016253e-07
    phi[4,11]  R1681     -5.5467881399096086e-08
    phi[4,11]  R1682     -3.8332029727964123e-02
    phi[4,11]  R1683     -3.9661797612338123e-02
    phi[4,11]  R1684     -4.3621473504663832e-02
    phi[4,11]  R1685     -6.9471815079125587e-02
    phi[4,11]  R1686     -6.6236381786016163e-01
    phi[4,11]  R1687     -8.3088436493191908e-01
    phi[4,11]  R1688     -5.2004870577436435e-01
    phi[4,11]  R1689     -5.3006303317286541e-01
    phi[4,11]  R1690     -0.503597650111974
    phi[4,11]  R1691     -7.8115338361524844e-01
    phi[4,11]  R1692     -2.2497650915967671e-01
    phi[4,11]  R1693     -3.3628408104741503e-01
    phi[4,11]  R1694     -8.0062185582463208e-01
    phi[4,11]  R1695     -8.9120439488667014e-01
    phi[4,11]  R1696     -3.5377877765044152e-01
    phi[4,11]  R1697     -6.3355322691226679e-01
    phi[4,11]  R1698     -4.7829687558965839e-01
    phi[4,11]  R1699     -6.3154194327352764e-01
    phi[4,11]  R1700     -3.6652936796193880e-01
    phi[4,11]  R1701     -8.4684897391751512e-01
    phi[4,11]  R1702     -9.6380336656899024e-01
    phi[4,11]  R1703     -3.8634940175701082e-01
    phi[4,11]  R1704     -6.5431408785283685e-01
    phi[4,11]  R1705     -3.9051182468595846e-01
    phi[4,11]  R1706     -3.9874769689498613e-01
    phi[4,11]  R1707     -0.515371085883072
    phi[4,11]  R1708     -4.8306720941682729e-01
    phi[4,11]  R1709     -3.7177356372616810e-01
    phi[4,11]  R1710     -7.0624315154899842e-01
    phi[4,11]  R1711     -3.7586320280001084e-01
    phi[4,11]  R1712     -3.8112122371242130e-01
    phi[4,11]  R1713     -3.8788533416573245e-01
    phi[4,11]  R1714     -3.9119039087691321e-01
    phi[4,11]  R1715     -3.9600525987093826e-01
    phi[4,11]  R1716     -9.7314298503224128e-01
    phi[4,11]  R1717     -2.3342823081836203e-01
    phi[4,11]  R1718     -3.0302633454988648e-01
    phi[4,11]  R1719     -4.1537851462457076e-01
    phi[4,11]  R1720     -6.3008682570172159e-01
    phi[4,11]  R1721     -9.0733104399209474e-01
    phi[4,11]  R1722     -3.5373214058716895e-01
    phi[4,11]  R1723     -4.8618915927410267e-01
    phi[4,11]  R1724     -5.0823061544979276e-01
    phi[4,11]  R1725     -0.339866928955026
    phi[4,11]  R1726     -3.5719314663892265e-01
    phi[4,11]  R1727     -3.4292669372693396e-01
    phi[4,11]  R1728     -8.2164834617385463e-01
    phi[4,11]  R1729     -3.1907925266951942e-01
    phi[4,11]  R1730     -0.751683682369816
    phi[4,11]  R1731     -3.4482930796925626e-01
    phi[4,11]  R1732     -8.1354690848333622e-01
    phi[4,11]  R1733     -3.7283331346692639e-01
    phi[4,11]  R1734     -9.3190146986098976e-01
    phi[4,11]  R1735     -5.9402628916504852e-01
    phi[4,11]  R1736     -3.7628134875699315e-01
    phi[4,11]  R1737     -5.6893531298783317e-01
    phi[4,11]  R1738     -3.3242710400620989e-01
    phi[4,11]  R1739     -3.4588582702144954e-01
    phi[4,11]  R1740     -6.0539088355815807e-01
    phi[4,11]  R1741     -3.6076062081111138e-01
    phi[4,11]  R1742     -3.6802724372672335e-01
    phi[4,11]  R1743     -3.9198539161626833e-01
    phi[4,11]  R1744     -3.9282308313613878e-01
    phi[4,11]  R1745     -5.1275664498164242e-01
    phi[4,11]  R1746     -6.3412109920729609e-01
    phi[4,11]  R1747     -1.0817304486432124e+00
    phi[4,11]  R1748     -3.2903977958095143e-01
    phi[4,11]  R1749     -3.3124213189542639e-01
    phi[4,11]  R1750     -8.2870835566630108e-01
    phi[4,11]  R1751     -3.9232484555103841e-01
    phi[4,11]  R1752     -7.7160681433633149e-01
    phi[4,11]  R1753     -5.1192766111713817e-01
    phi[4,11]  R1754     -5.3061872526906750e-01
    phi[4,11]  R1755     -5.4744376867987432e-01
    phi[5,6]  R45       1
    phi[5,6]  R46       1
    phi[5,6]  R54       -1
    phi[5,6]  R1756     -3.0999999046325684e+00
    phi[5,6]  R1757     -3.0999999046325684e+00
    phi[5,6]  R1758     -2.2400000095367432e+00
    phi[5,6]  R1759     -2.2400000095367432e+00
    phi[5,6]  R1760     -3.0999999046325684e+00
    phi[5,6]  R1761     -3.0999999046325684e+00
    phi[5,6]  R1762     -2.5699999332427979e+00
    phi[5,6]  R1763     -2.5699999332427979e+00
    phi[5,6]  R1764     -3.0999999046325684e+00
    phi[5,6]  R1765     -3.0999999046325684e+00
    phi[5,6]  R1766     -2.0899999141693115e+00
    phi[5,6]  R1767     -2.0899999141693115e+00
    phi[5,6]  R1768     -3.0999999046325684e+00
    phi[5,6]  R1769     -3.0999999046325684e+00
    phi[5,6]  R1770     1.0040199756622314e+00
    phi[5,6]  R1771     1.5286905765533447e+00
    phi[5,6]  R1772     1.1812471151351929e+00
    phi[5,6]  R1773     1.1003676652908325e+00
    phi[5,6]  R1774     -2.8553324937820435e-01
    phi[5,6]  R1775     1.2852455675601959e-01
    phi[5,6]  R1776     3.0759865045547485e-01
    phi[5,6]  R1777     2.4433873593807220e-01
    phi[5,6]  R1778     -7.8723394870758057e-01
    phi[5,6]  R1779     -9.6787512302398682e-01
    phi[5,6]  R1780     -2.3272061347961426e-01
    phi[5,6]  R1781     1.2853199616074562e-02
    phi[5,6]  R1782     5.0104144029319286e-03
    phi[5,6]  R1783     -2.1753330230712891e+00
    phi[5,6]  R1784     1.0951761007308960e+00
    phi[5,6]  R1785     1.9493639469146729e-01
    phi[5,6]  R1786     7.9607951641082764e-01
    phi[5,6]  R1787     1.0852813720703125e+00
    phi[5,6]  R1788     8.0336767435073853e-01
    phi[5,6]  R1789     5.8638375997543335e-01
    phi[5,6]  R1790     -2.4810762405395508e+00
    phi[5,6]  R1791     -4.6268829703330994e-01
    phi[5,6]  R1792     -1.6157008409500122e+00
    phi[5,6]  R1793     -3.1129128932952881e+00
    phi[5,6]  R1794     -1.6747971773147583e+00
    phi[5,6]  R1795     -2.3356578350067139e+00
    phi[5,6]  R1796     -2.7030389308929443e+00
    phi[5,6]  R1797     6.9014990329742432e-01
    phi[5,6]  R1798     -1.3521074056625366e+00
    phi[5,6]  R1799     -1.3264334201812744e+00
    phi[5,6]  R1800     -0.611155092716217
    phi[5,6]  R1801     -1.6850816011428833e+00
    phi[5,6]  R1802     -1.9842704534530640e+00
    phi[5,6]  R1803     -2.1739697456359863e+00
    phi[5,6]  R1804     -2.3052670955657959e+00
    phi[5,6]  R1805     -2.1097412109375
    phi[5,6]  R1806     -9.2568355798721313e-01
    phi[5,6]  R1807     -3.3764150142669678e+00
    phi[5,6]  R1808     -2.8746275901794434e+00
    phi[5,6]  R1809     -3.0102052688598633e+00
    phi[5,6]  R1810     1.6740301847457886e+00
    phi[5,6]  R1811     1.1086361408233643e+00
    phi[5,6]  R1812     2.2664263248443604e+00
    phi[5,6]  R1813     -1.1440351605415344e-01
    phi[5,6]  R1814     2.0200121402740479e+00
    phi[5,6]  R1815     1.5909364223480225e+00
    phi[5,6]  R1816     9.3083745241165161e-01
    phi[5,6]  R1817     1.3016786575317383e+00
    phi[5,6]  R1818     1.4546856880187988e+00
    phi[5,6]  R1819     6.6955578327178955e-01
    phi[5,6]  R1820     -2.9445283412933350e+00
    phi[5,6]  R1821     -2.0238637924194336e+00
    phi[5,6]  R1822     -2.1690022945404053e+00
    phi[5,6]  R1823     -1.7966130971908569e+00
    phi[5,6]  R1824     -1.1666007041931152e+00
    phi[5,6]  R1825     -3.3634738922119141e+00
    phi[5,6]  R1826     -3.6634593009948730e+00
    phi[5,6]  R1827     -3.7711474895477295e+00
    phi[5,6]  R1828     -3.6936738491058350e+00
    phi[5,6]  R1829     -3.7419147491455078e+00
    phi[5,6]  R1830     -1.4883618354797363e+00
    phi[5,6]  R1831     -5.5905096232891083e-02
    phi[5,6]  R1832     -1.6408129930496216e+00
    phi[5,6]  R1833     1.5323537588119507e-01
    phi[5,6]  R1834     -5.2937418222427368e-02
    phi[5,6]  R1835     4.2501151561737061e-01
    phi[5,6]  R1836     -3.2656056880950928e+00
    phi[5,6]  R1837     -3.8334834575653076e+00
    phi[5,6]  R1838     -3.0451033115386963e+00
    phi[5,6]  R1839     -3.5675423145294189e+00
    phi[5,6]  R1840     -9.3273617327213287e-02
    phi[5,6]  R1841     1.4323803782463074e-01
    phi[5,6]  R1842     -3.2247338294982910e+00
    phi[5,6]  R1843     4.4461101293563843e-01
    phi[5,6]  R1844     -3.5756146907806396e+00
    phi[5,6]  R1845     -5.1118910312652588e-01
    phi[5,6]  R1846     6.8134588003158569e-01
    phi[5,6]  R1847     -3.6176064014434814e+00
    phi[5,6]  R1848     -3.3772587776184082e+00
    phi[5,6]  R1849     -2.8323156833648682e+00
    phi[5,6]  R1850     -1.5939995646476746e-01
    phi[5,6]  R1851     6.9027376174926758e-01
    phi[5,6]  R1852     -1.1878594160079956e+00
    phi[5,6]  R1853     -6.4226430654525757e-01
    phi[5,6]  R1854     -3.6170175075531006e+00
    phi[5,6]  R1855     -3.6553664207458496e+00
    phi[5,6]  R1856     -3.2443084716796875e+00
    phi[5,6]  R1857     -0.8002969622612
    phi[5,6]  R1858     -1.8056727647781372e+00
    phi[5,6]  R1859     -1.8706942796707153e+00
    phi[6,5]  R45       -1
    phi[6,5]  R54       1
    phi[6,5]  R55       1
    phi[6,5]  R1860     -3.0999999046325684e+00
    phi[6,5]  R1861     -3.0999999046325684e+00
    phi[6,5]  R1862     -2.2400000095367432e+00
    phi[6,5]  R1863     -2.2400000095367432e+00
    phi[6,5]  R1864     -3.0999999046325684e+00
    phi[6,5]  R1865     -3.0999999046325684e+00
    phi[6,5]  R1866     -2.5699999332427979e+00
    phi[6,5]  R1867     -2.5699999332427979e+00
    phi[6,5]  R1868     -3.0999999046325684e+00
    phi[6,5]  R1869     -3.0999999046325684e+00
    phi[6,5]  R1870     -2.0899999141693115e+00
    phi[6,5]  R1871     -2.0899999141693115e+00
    phi[6,5]  R1872     -3.0999999046325684e+00
    phi[6,5]  R1873     -3.0999999046325684e+00
    phi[6,5]  R1874     1.6740301847457886e+00
    phi[6,5]  R1875     1.1086361408233643e+00
    phi[6,5]  R1876     2.2664263248443604e+00
    phi[6,5]  R1877     -1.1440351605415344e-01
    phi[6,5]  R1878     2.0200121402740479e+00
    phi[6,5]  R1879     1.5909364223480225e+00
    phi[6,5]  R1880     9.3083745241165161e-01
    phi[6,5]  R1881     1.3016786575317383e+00
    phi[6,5]  R1882     1.4546856880187988e+00
    phi[6,5]  R1883     6.6955578327178955e-01
    phi[6,5]  R1884     -2.9445283412933350e+00
    phi[6,5]  R1885     -2.0238637924194336e+00
    phi[6,5]  R1886     -2.1690022945404053e+00
    phi[6,5]  R1887     -1.7966130971908569e+00
    phi[6,5]  R1888     -1.1666007041931152e+00
    phi[6,5]  R1889     -3.3634738922119141e+00
    phi[6,5]  R1890     -3.6634593009948730e+00
    phi[6,5]  R1891     -3.7711474895477295e+00
    phi[6,5]  R1892     -3.6936738491058350e+00
    phi[6,5]  R1893     -3.7419147491455078e+00
    phi[6,5]  R1894     -1.4883618354797363e+00
    phi[6,5]  R1895     -5.5905096232891083e-02
    phi[6,5]  R1896     -1.6408129930496216e+00
    phi[6,5]  R1897     1.5323537588119507e-01
    phi[6,5]  R1898     -5.2937418222427368e-02
    phi[6,5]  R1899     4.2501151561737061e-01
    phi[6,5]  R1900     -3.2656056880950928e+00
    phi[6,5]  R1901     -3.8334834575653076e+00
    phi[6,5]  R1902     -3.0451033115386963e+00
    phi[6,5]  R1903     -3.5675423145294189e+00
    phi[6,5]  R1904     -9.3273617327213287e-02
    phi[6,5]  R1905     1.4323803782463074e-01
    phi[6,5]  R1906     -3.2247338294982910e+00
    phi[6,5]  R1907     4.4461101293563843e-01
    phi[6,5]  R1908     -3.5756146907806396e+00
    phi[6,5]  R1909     -5.1118910312652588e-01
    phi[6,5]  R1910     6.8134588003158569e-01
    phi[6,5]  R1911     -3.6176064014434814e+00
    phi[6,5]  R1912     -3.3772587776184082e+00
    phi[6,5]  R1913     -2.8323156833648682e+00
    phi[6,5]  R1914     -1.5939995646476746e-01
    phi[6,5]  R1915     6.9027376174926758e-01
    phi[6,5]  R1916     -1.1878594160079956e+00
    phi[6,5]  R1917     -6.4226430654525757e-01
    phi[6,5]  R1918     -3.6170175075531006e+00
    phi[6,5]  R1919     -3.6553664207458496e+00
    phi[6,5]  R1920     -3.2443084716796875e+00
    phi[6,5]  R1921     -0.8002969622612
    phi[6,5]  R1922     -1.8056727647781372e+00
    phi[6,5]  R1923     -1.8706942796707153e+00
    phi[6,5]  R1924     1.0040199756622314e+00
    phi[6,5]  R1925     1.5286905765533447e+00
    phi[6,5]  R1926     1.1812471151351929e+00
    phi[6,5]  R1927     1.1003676652908325e+00
    phi[6,5]  R1928     -2.8553324937820435e-01
    phi[6,5]  R1929     1.2852455675601959e-01
    phi[6,5]  R1930     3.0759865045547485e-01
    phi[6,5]  R1931     2.4433873593807220e-01
    phi[6,5]  R1932     -7.8723394870758057e-01
    phi[6,5]  R1933     -9.6787512302398682e-01
    phi[6,5]  R1934     -2.3272061347961426e-01
    phi[6,5]  R1935     1.2853199616074562e-02
    phi[6,5]  R1936     5.0104144029319286e-03
    phi[6,5]  R1937     -2.1753330230712891e+00
    phi[6,5]  R1938     1.0951761007308960e+00
    phi[6,5]  R1939     1.9493639469146729e-01
    phi[6,5]  R1940     7.9607951641082764e-01
    phi[6,5]  R1941     1.0852813720703125e+00
    phi[6,5]  R1942     8.0336767435073853e-01
    phi[6,5]  R1943     5.8638375997543335e-01
    phi[6,5]  R1944     -2.4810762405395508e+00
    phi[6,5]  R1945     -4.6268829703330994e-01
    phi[6,5]  R1946     -1.6157008409500122e+00
    phi[6,5]  R1947     -3.1129128932952881e+00
    phi[6,5]  R1948     -1.6747971773147583e+00
    phi[6,5]  R1949     -2.3356578350067139e+00
    phi[6,5]  R1950     -2.7030389308929443e+00
    phi[6,5]  R1951     6.9014990329742432e-01
    phi[6,5]  R1952     -1.3521074056625366e+00
    phi[6,5]  R1953     -1.3264334201812744e+00
    phi[6,5]  R1954     -0.611155092716217
    phi[6,5]  R1955     -1.6850816011428833e+00
    phi[6,5]  R1956     -1.9842704534530640e+00
    phi[6,5]  R1957     -2.1739697456359863e+00
    phi[6,5]  R1958     -2.3052670955657959e+00
    phi[6,5]  R1959     -2.1097412109375
    phi[6,5]  R1960     -9.2568355798721313e-01
    phi[6,5]  R1961     -3.3764150142669678e+00
    phi[6,5]  R1962     -2.8746275901794434e+00
    phi[6,5]  R1963     -3.0102052688598633e+00
    phi[5,7]  R45       1
    phi[5,7]  R46       1
    phi[5,7]  R63       -1
    phi[5,7]  R1964     -3.0999999046325684e+00
    phi[5,7]  R1965     -3.0999999046325684e+00
    phi[5,7]  R1966     -2.2400000095367432e+00
    phi[5,7]  R1967     -2.2400000095367432e+00
    phi[5,7]  R1968     -3.0999999046325684e+00
    phi[5,7]  R1969     -3.0999999046325684e+00
    phi[5,7]  R1970     -2.5699999332427979e+00
    phi[5,7]  R1971     -2.5699999332427979e+00
    phi[5,7]  R1972     -3.0999999046325684e+00
    phi[5,7]  R1973     -3.0999999046325684e+00
    phi[5,7]  R1974     -2.0899999141693115e+00
    phi[5,7]  R1975     -2.0899999141693115e+00
    phi[5,7]  R1976     -3.0999999046325684e+00
    phi[5,7]  R1977     -3.0999999046325684e+00
    phi[5,7]  R1978     1.0040199756622314e+00
    phi[5,7]  R1979     1.5286905765533447e+00
    phi[5,7]  R1980     1.1812471151351929e+00
    phi[5,7]  R1981     1.1003676652908325e+00
    phi[5,7]  R1982     -2.8553324937820435e-01
    phi[5,7]  R1983     1.2852455675601959e-01
    phi[5,7]  R1984     3.0759865045547485e-01
    phi[5,7]  R1985     2.4433873593807220e-01
    phi[5,7]  R1986     -7.8723394870758057e-01
    phi[5,7]  R1987     -9.6787512302398682e-01
    phi[5,7]  R1988     -2.3272061347961426e-01
    phi[5,7]  R1989     1.2853199616074562e-02
    phi[5,7]  R1990     5.0104144029319286e-03
    phi[5,7]  R1991     -2.1753330230712891e+00
    phi[5,7]  R1992     1.0951761007308960e+00
    phi[5,7]  R1993     1.9493639469146729e-01
    phi[5,7]  R1994     7.9607951641082764e-01
    phi[5,7]  R1995     1.0852813720703125e+00
    phi[5,7]  R1996     8.0336767435073853e-01
    phi[5,7]  R1997     5.8638375997543335e-01
    phi[5,7]  R1998     -2.4810762405395508e+00
    phi[5,7]  R1999     -4.6268829703330994e-01
    phi[5,7]  R2000     -1.6157008409500122e+00
    phi[5,7]  R2001     -3.1129128932952881e+00
    phi[5,7]  R2002     -1.6747971773147583e+00
    phi[5,7]  R2003     -2.3356578350067139e+00
    phi[5,7]  R2004     -2.7030389308929443e+00
    phi[5,7]  R2005     6.9014990329742432e-01
    phi[5,7]  R2006     -1.3521074056625366e+00
    phi[5,7]  R2007     -1.3264334201812744e+00
    phi[5,7]  R2008     -0.611155092716217
    phi[5,7]  R2009     -1.6850816011428833e+00
    phi[5,7]  R2010     -1.9842704534530640e+00
    phi[5,7]  R2011     -2.1739697456359863e+00
    phi[5,7]  R2012     -2.3052670955657959e+00
    phi[5,7]  R2013     -2.1097412109375
    phi[5,7]  R2014     -9.2568355798721313e-01
    phi[5,7]  R2015     -3.3764150142669678e+00
    phi[5,7]  R2016     -2.8746275901794434e+00
    phi[5,7]  R2017     -3.0102052688598633e+00
    phi[5,7]  R2018     1.9159718751907349e+00
    phi[5,7]  R2019     2.0577039718627930e+00
    phi[5,7]  R2020     -8.6943298578262329e-01
    phi[5,7]  R2021     2.6815852522850037e-01
    phi[5,7]  R2022     -5.4108953475952148e-01
    phi[5,7]  R2023     5.1463907957077026e-01
    phi[5,7]  R2024     1.1178762912750244e+00
    phi[5,7]  R2025     -3.8964742422103882e-01
    phi[5,7]  R2026     -2.7435517311096191e+00
    phi[5,7]  R2027     -2.0472514629364014e+00
    phi[5,7]  R2028     -5.5579113960266113e-01
    phi[5,7]  R2029     -1.5793602466583252e+00
    phi[5,7]  R2030     2.8342044353485107e-01
    phi[5,7]  R2031     1.2700122594833374e+00
    phi[5,7]  R2032     -1.5616843700408936e+00
    phi[5,7]  R2033     -1.8515017032623291e+00
    phi[5,7]  R2034     -1.7107207775115967e+00
    phi[5,7]  R2035     -7.3008143901824951e-01
    phi[5,7]  R2036     -1.3536863327026367e+00
    phi[5,7]  R2037     -1.1121237277984619e+00
    phi[5,7]  R2038     -6.1220288276672363e-01
    phi[5,7]  R2039     -1.5506057441234589e-01
    phi[5,7]  R2040     -1.5875830650329590e+00
    phi[5,7]  R2041     4.1646383702754974e-02
    phi[5,7]  R2042     -1.2067641019821167e+00
    phi[5,7]  R2043     -2.8571858406066895e+00
    phi[5,7]  R2044     -2.80363392829895
    phi[5,7]  R2045     -6.7171424627304077e-01
    phi[7,5]  R45       -1
    phi[7,5]  R63       1
    phi[7,5]  R64       1
    phi[7,5]  R2046     -3.0999999046325684e+00
    phi[7,5]  R2047     -3.0999999046325684e+00
    phi[7,5]  R2048     -2.2400000095367432e+00
    phi[7,5]  R2049     -2.2400000095367432e+00
    phi[7,5]  R2050     -3.0999999046325684e+00
    phi[7,5]  R2051     -3.0999999046325684e+00
    phi[7,5]  R2052     -2.5699999332427979e+00
    phi[7,5]  R2053     -2.5699999332427979e+00
    phi[7,5]  R2054     -3.0999999046325684e+00
    phi[7,5]  R2055     -3.0999999046325684e+00
    phi[7,5]  R2056     -2.0899999141693115e+00
    phi[7,5]  R2057     -2.0899999141693115e+00
    phi[7,5]  R2058     -3.0999999046325684e+00
    phi[7,5]  R2059     -3.0999999046325684e+00
    phi[7,5]  R2060     1.9159718751907349e+00
    phi[7,5]  R2061     2.0577039718627930e+00
    phi[7,5]  R2062     -8.6943298578262329e-01
    phi[7,5]  R2063     2.6815852522850037e-01
    phi[7,5]  R2064     -5.4108953475952148e-01
    phi[7,5]  R2065     5.1463907957077026e-01
    phi[7,5]  R2066     1.1178762912750244e+00
    phi[7,5]  R2067     -3.8964742422103882e-01
    phi[7,5]  R2068     -2.7435517311096191e+00
    phi[7,5]  R2069     -2.0472514629364014e+00
    phi[7,5]  R2070     -5.5579113960266113e-01
    phi[7,5]  R2071     -1.5793602466583252e+00
    phi[7,5]  R2072     2.8342044353485107e-01
    phi[7,5]  R2073     1.2700122594833374e+00
    phi[7,5]  R2074     -1.5616843700408936e+00
    phi[7,5]  R2075     -1.8515017032623291e+00
    phi[7,5]  R2076     -1.7107207775115967e+00
    phi[7,5]  R2077     -7.3008143901824951e-01
    phi[7,5]  R2078     -1.3536863327026367e+00
    phi[7,5]  R2079     -1.1121237277984619e+00
    phi[7,5]  R2080     -6.1220288276672363e-01
    phi[7,5]  R2081     -1.5506057441234589e-01
    phi[7,5]  R2082     -1.5875830650329590e+00
    phi[7,5]  R2083     4.1646383702754974e-02
    phi[7,5]  R2084     -1.2067641019821167e+00
    phi[7,5]  R2085     -2.8571858406066895e+00
    phi[7,5]  R2086     -2.80363392829895
    phi[7,5]  R2087     -6.7171424627304077e-01
    phi[7,5]  R2088     1.0040199756622314e+00
    phi[7,5]  R2089     1.5286905765533447e+00
    phi[7,5]  R2090     1.1812471151351929e+00
    phi[7,5]  R2091     1.1003676652908325e+00
    phi[7,5]  R2092     -2.8553324937820435e-01
    phi[7,5]  R2093     1.2852455675601959e-01
    phi[7,5]  R2094     3.0759865045547485e-01
    phi[7,5]  R2095     2.4433873593807220e-01
    phi[7,5]  R2096     -7.8723394870758057e-01
    phi[7,5]  R2097     -9.6787512302398682e-01
    phi[7,5]  R2098     -2.3272061347961426e-01
    phi[7,5]  R2099     1.2853199616074562e-02
    phi[7,5]  R2100     5.0104144029319286e-03
    phi[7,5]  R2101     -2.1753330230712891e+00
    phi[7,5]  R2102     1.0951761007308960e+00
    phi[7,5]  R2103     1.9493639469146729e-01
    phi[7,5]  R2104     7.9607951641082764e-01
    phi[7,5]  R2105     1.0852813720703125e+00
    phi[7,5]  R2106     8.0336767435073853e-01
    phi[7,5]  R2107     5.8638375997543335e-01
    phi[7,5]  R2108     -2.4810762405395508e+00
    phi[7,5]  R2109     -4.6268829703330994e-01
    phi[7,5]  R2110     -1.6157008409500122e+00
    phi[7,5]  R2111     -3.1129128932952881e+00
    phi[7,5]  R2112     -1.6747971773147583e+00
    phi[7,5]  R2113     -2.3356578350067139e+00
    phi[7,5]  R2114     -2.7030389308929443e+00
    phi[7,5]  R2115     6.9014990329742432e-01
    phi[7,5]  R2116     -1.3521074056625366e+00
    phi[7,5]  R2117     -1.3264334201812744e+00
    phi[7,5]  R2118     -0.611155092716217
    phi[7,5]  R2119     -1.6850816011428833e+00
    phi[7,5]  R2120     -1.9842704534530640e+00
    phi[7,5]  R2121     -2.1739697456359863e+00
    phi[7,5]  R2122     -2.3052670955657959e+00
    phi[7,5]  R2123     -2.1097412109375
    phi[7,5]  R2124     -9.2568355798721313e-01
    phi[7,5]  R2125     -3.3764150142669678e+00
    phi[7,5]  R2126     -2.8746275901794434e+00
    phi[7,5]  R2127     -3.0102052688598633e+00
    phi[10,5]  R45       -1
    phi[10,5]  R47       -1.0876942707822710e+00
    phi[10,5]  R48       -1.3864910604887788e+00
    phi[10,5]  R49       -8.0873759611484930e-01
    phi[10,5]  R50       1.7029626216183824e+00
    phi[10,5]  R51       1.5535340012573573e+00
    phi[10,5]  R52       1.2092606776728023e+00
    phi[10,5]  R53       -8.6802718594208583e-01
    phi[10,5]  R90       1
    phi[10,5]  R2128     -2.0123056338502971e+00
    phi[10,5]  R2129     -4.18769417541484
    phi[10,5]  R2130     -8.5350894904796437e-01
    phi[10,5]  R2131     -3.6264910700255220e+00
    phi[10,5]  R2132     -2.2912623085177191e+00
    phi[10,5]  R2133     -3.9087375007474177e+00
    phi[10,5]  R2134     -4.2729625548611807e+00
    phi[10,5]  R2135     -8.6703731162441544e-01
    phi[10,5]  R2136     -4.6535339058899261e+00
    phi[10,5]  R2137     -1.5464659033752111e+00
    phi[10,5]  R2138     -3.2992605918421138e+00
    phi[10,5]  R2139     -8.8073923649650920e-01
    phi[10,5]  R2140     -2.2319727186904825e+00
    phi[10,5]  R2141     -3.9680270905746542e+00
    phi[10,5]  R2142     -1.2684543085439204e-01
    phi[10,5]  R2143     -1.4624644088886662e-01
    phi[10,5]  R2144     -1.5391717027196572e-01
    phi[10,5]  R2145     -1.5796193667803582e-01
    phi[10,5]  R2146     -1.8314890664943279e-01
    phi[10,5]  R2147     -1.8373917072772827e-01
    phi[10,5]  R2148     -1.9037526709770625e-01
    phi[10,5]  R2149     -1.9305729909155050e-01
    phi[10,5]  R2150     -2.0393895378481153e-01
    phi[10,5]  R2151     -7.1708298914507451e-01
    phi[10,5]  R2152     -6.1924503362965977e-01
    phi[10,5]  R2153     -6.9062872466244263e-01
    phi[10,5]  R2154     -6.9484243271160750e-01
    phi[10,5]  R2155     -0.703740195887206
    phi[10,5]  R2156     -7.3326349289149562e-01
    phi[10,5]  R2157     -7.4012784827126754e-01
    phi[10,5]  R2158     -7.4505455602177628e-01
    phi[10,5]  R2159     -7.4593273852916342e-01
    phi[10,5]  R2160     -7.5588308297878726e-01
    phi[10,5]  R2161     -7.5668902524688519e-01
    phi[10,5]  R2162     -5.7294226983216534e-01
    phi[10,5]  R2163     -7.2387621913605560e-01
    phi[10,5]  R2164     -7.2736398693739912e-01
    phi[10,5]  R2165     -7.4994496246235931e-01
    phi[10,5]  R2166     -8.2453976298318765e-01
    phi[10,5]  R2167     -7.8571293594935754e-01
    phi[10,5]  R2168     -7.8647662303192645e-01
    phi[10,5]  R2169     -7.9598472462795167e-01
    phi[10,5]  R2170     -8.0645372360146017e-01
    phi[10,5]  R2171     -8.3145414232380410e-01
    phi[10,5]  R2172     -7.0717508804348161e-01
    phi[10,5]  R2173     -7.7159271962153941e-01
    phi[10,5]  R2174     -7.2665039818990085e-01
    phi[10,5]  R2175     -7.6339203455532911e-01
    phi[10,5]  R2176     -0.806974515116391
    phi[10,5]  R2177     -8.2432772402040966e-01
    phi[10,5]  R2178     -8.2984051769730072e-01
    phi[10,5]  R2179     -8.5357720347793853e-01
    phi[10,5]  R2180     -8.6202323715767637e-01
    phi[10,5]  R2181     -8.9297627682244318e-01
    phi[6,7]  R54       1
    phi[6,7]  R55       1
    phi[6,7]  R63       -1
    phi[6,7]  R2182     -3.0999999046325684e+00
    phi[6,7]  R2183     -3.0999999046325684e+00
    phi[6,7]  R2184     -2.2400000095367432e+00
    phi[6,7]  R2185     -2.2400000095367432e+00
    phi[6,7]  R2186     -3.0999999046325684e+00
    phi[6,7]  R2187     -3.0999999046325684e+00
    phi[6,7]  R2188     -2.5699999332427979e+00
    phi[6,7]  R2189     -2.5699999332427979e+00
    phi[6,7]  R2190     -3.0999999046325684e+00
    phi[6,7]  R2191     -3.0999999046325684e+00
    phi[6,7]  R2192     -2.0899999141693115e+00
    phi[6,7]  R2193     -2.0899999141693115e+00
    phi[6,7]  R2194     -3.0999999046325684e+00
    phi[6,7]  R2195     -3.0999999046325684e+00
    phi[6,7]  R2196     1.6740301847457886e+00
    phi[6,7]  R2197     1.1086361408233643e+00
    phi[6,7]  R2198     2.2664263248443604e+00
    phi[6,7]  R2199     -1.1440351605415344e-01
    phi[6,7]  R2200     2.0200121402740479e+00
    phi[6,7]  R2201     1.5909364223480225e+00
    phi[6,7]  R2202     9.3083745241165161e-01
    phi[6,7]  R2203     1.3016786575317383e+00
    phi[6,7]  R2204     1.4546856880187988e+00
    phi[6,7]  R2205     6.6955578327178955e-01
    phi[6,7]  R2206     -2.9445283412933350e+00
    phi[6,7]  R2207     -2.0238637924194336e+00
    phi[6,7]  R2208     -2.1690022945404053e+00
    phi[6,7]  R2209     -1.7966130971908569e+00
    phi[6,7]  R2210     -1.1666007041931152e+00
    phi[6,7]  R2211     -3.3634738922119141e+00
    phi[6,7]  R2212     -3.6634593009948730e+00
    phi[6,7]  R2213     -3.7711474895477295e+00
    phi[6,7]  R2214     -3.6936738491058350e+00
    phi[6,7]  R2215     -3.7419147491455078e+00
    phi[6,7]  R2216     -1.4883618354797363e+00
    phi[6,7]  R2217     -5.5905096232891083e-02
    phi[6,7]  R2218     -1.6408129930496216e+00
    phi[6,7]  R2219     1.5323537588119507e-01
    phi[6,7]  R2220     -5.2937418222427368e-02
    phi[6,7]  R2221     4.2501151561737061e-01
    phi[6,7]  R2222     -3.2656056880950928e+00
    phi[6,7]  R2223     -3.8334834575653076e+00
    phi[6,7]  R2224     -3.0451033115386963e+00
    phi[6,7]  R2225     -3.5675423145294189e+00
    phi[6,7]  R2226     -9.3273617327213287e-02
    phi[6,7]  R2227     1.4323803782463074e-01
    phi[6,7]  R2228     -3.2247338294982910e+00
    phi[6,7]  R2229     4.4461101293563843e-01
    phi[6,7]  R2230     -3.5756146907806396e+00
    phi[6,7]  R2231     -5.1118910312652588e-01
    phi[6,7]  R2232     6.8134588003158569e-01
    phi[6,7]  R2233     -3.6176064014434814e+00
    phi[6,7]  R2234     -3.3772587776184082e+00
    phi[6,7]  R2235     -2.8323156833648682e+00
    phi[6,7]  R2236     -1.5939995646476746e-01
    phi[6,7]  R2237     6.9027376174926758e-01
    phi[6,7]  R2238     -1.1878594160079956e+00
    phi[6,7]  R2239     -6.4226430654525757e-01
    phi[6,7]  R2240     -3.6170175075531006e+00
    phi[6,7]  R2241     -3.6553664207458496e+00
    phi[6,7]  R2242     -3.2443084716796875e+00
    phi[6,7]  R2243     -0.8002969622612
    phi[6,7]  R2244     -1.8056727647781372e+00
    phi[6,7]  R2245     -1.8706942796707153e+00
    phi[6,7]  R2246     1.9159718751907349e+00
    phi[6,7]  R2247     2.0577039718627930e+00
    phi[6,7]  R2248     -8.6943298578262329e-01
    phi[6,7]  R2249     2.6815852522850037e-01
    phi[6,7]  R2250     -5.4108953475952148e-01
    phi[6,7]  R2251     5.1463907957077026e-01
    phi[6,7]  R2252     1.1178762912750244e+00
    phi[6,7]  R2253     -3.8964742422103882e-01
    phi[6,7]  R2254     -2.7435517311096191e+00
    phi[6,7]  R2255     -2.0472514629364014e+00
    phi[6,7]  R2256     -5.5579113960266113e-01
    phi[6,7]  R2257     -1.5793602466583252e+00
    phi[6,7]  R2258     2.8342044353485107e-01
    phi[6,7]  R2259     1.2700122594833374e+00
    phi[6,7]  R2260     -1.5616843700408936e+00
    phi[6,7]  R2261     -1.8515017032623291e+00
    phi[6,7]  R2262     -1.7107207775115967e+00
    phi[6,7]  R2263     -7.3008143901824951e-01
    phi[6,7]  R2264     -1.3536863327026367e+00
    phi[6,7]  R2265     -1.1121237277984619e+00
    phi[6,7]  R2266     -6.1220288276672363e-01
    phi[6,7]  R2267     -1.5506057441234589e-01
    phi[6,7]  R2268     -1.5875830650329590e+00
    phi[6,7]  R2269     4.1646383702754974e-02
    phi[6,7]  R2270     -1.2067641019821167e+00
    phi[6,7]  R2271     -2.8571858406066895e+00
    phi[6,7]  R2272     -2.80363392829895
    phi[6,7]  R2273     -6.7171424627304077e-01
    phi[7,6]  R54       -1
    phi[7,6]  R63       1
    phi[7,6]  R64       1
    phi[7,6]  R2274     -3.0999999046325684e+00
    phi[7,6]  R2275     -3.0999999046325684e+00
    phi[7,6]  R2276     -2.2400000095367432e+00
    phi[7,6]  R2277     -2.2400000095367432e+00
    phi[7,6]  R2278     -3.0999999046325684e+00
    phi[7,6]  R2279     -3.0999999046325684e+00
    phi[7,6]  R2280     -2.5699999332427979e+00
    phi[7,6]  R2281     -2.5699999332427979e+00
    phi[7,6]  R2282     -3.0999999046325684e+00
    phi[7,6]  R2283     -3.0999999046325684e+00
    phi[7,6]  R2284     -2.0899999141693115e+00
    phi[7,6]  R2285     -2.0899999141693115e+00
    phi[7,6]  R2286     -3.0999999046325684e+00
    phi[7,6]  R2287     -3.0999999046325684e+00
    phi[7,6]  R2288     1.9159718751907349e+00
    phi[7,6]  R2289     2.0577039718627930e+00
    phi[7,6]  R2290     -8.6943298578262329e-01
    phi[7,6]  R2291     2.6815852522850037e-01
    phi[7,6]  R2292     -5.4108953475952148e-01
    phi[7,6]  R2293     5.1463907957077026e-01
    phi[7,6]  R2294     1.1178762912750244e+00
    phi[7,6]  R2295     -3.8964742422103882e-01
    phi[7,6]  R2296     -2.7435517311096191e+00
    phi[7,6]  R2297     -2.0472514629364014e+00
    phi[7,6]  R2298     -5.5579113960266113e-01
    phi[7,6]  R2299     -1.5793602466583252e+00
    phi[7,6]  R2300     2.8342044353485107e-01
    phi[7,6]  R2301     1.2700122594833374e+00
    phi[7,6]  R2302     -1.5616843700408936e+00
    phi[7,6]  R2303     -1.8515017032623291e+00
    phi[7,6]  R2304     -1.7107207775115967e+00
    phi[7,6]  R2305     -7.3008143901824951e-01
    phi[7,6]  R2306     -1.3536863327026367e+00
    phi[7,6]  R2307     -1.1121237277984619e+00
    phi[7,6]  R2308     -6.1220288276672363e-01
    phi[7,6]  R2309     -1.5506057441234589e-01
    phi[7,6]  R2310     -1.5875830650329590e+00
    phi[7,6]  R2311     4.1646383702754974e-02
    phi[7,6]  R2312     -1.2067641019821167e+00
    phi[7,6]  R2313     -2.8571858406066895e+00
    phi[7,6]  R2314     -2.80363392829895
    phi[7,6]  R2315     -6.7171424627304077e-01
    phi[7,6]  R2316     1.6740301847457886e+00
    phi[7,6]  R2317     1.1086361408233643e+00
    phi[7,6]  R2318     2.2664263248443604e+00
    phi[7,6]  R2319     -1.1440351605415344e-01
    phi[7,6]  R2320     2.0200121402740479e+00
    phi[7,6]  R2321     1.5909364223480225e+00
    phi[7,6]  R2322     9.3083745241165161e-01
    phi[7,6]  R2323     1.3016786575317383e+00
    phi[7,6]  R2324     1.4546856880187988e+00
    phi[7,6]  R2325     6.6955578327178955e-01
    phi[7,6]  R2326     -2.9445283412933350e+00
    phi[7,6]  R2327     -2.0238637924194336e+00
    phi[7,6]  R2328     -2.1690022945404053e+00
    phi[7,6]  R2329     -1.7966130971908569e+00
    phi[7,6]  R2330     -1.1666007041931152e+00
    phi[7,6]  R2331     -3.3634738922119141e+00
    phi[7,6]  R2332     -3.6634593009948730e+00
    phi[7,6]  R2333     -3.7711474895477295e+00
    phi[7,6]  R2334     -3.6936738491058350e+00
    phi[7,6]  R2335     -3.7419147491455078e+00
    phi[7,6]  R2336     -1.4883618354797363e+00
    phi[7,6]  R2337     -5.5905096232891083e-02
    phi[7,6]  R2338     -1.6408129930496216e+00
    phi[7,6]  R2339     1.5323537588119507e-01
    phi[7,6]  R2340     -5.2937418222427368e-02
    phi[7,6]  R2341     4.2501151561737061e-01
    phi[7,6]  R2342     -3.2656056880950928e+00
    phi[7,6]  R2343     -3.8334834575653076e+00
    phi[7,6]  R2344     -3.0451033115386963e+00
    phi[7,6]  R2345     -3.5675423145294189e+00
    phi[7,6]  R2346     -9.3273617327213287e-02
    phi[7,6]  R2347     1.4323803782463074e-01
    phi[7,6]  R2348     -3.2247338294982910e+00
    phi[7,6]  R2349     4.4461101293563843e-01
    phi[7,6]  R2350     -3.5756146907806396e+00
    phi[7,6]  R2351     -5.1118910312652588e-01
    phi[7,6]  R2352     6.8134588003158569e-01
    phi[7,6]  R2353     -3.6176064014434814e+00
    phi[7,6]  R2354     -3.3772587776184082e+00
    phi[7,6]  R2355     -2.8323156833648682e+00
    phi[7,6]  R2356     -1.5939995646476746e-01
    phi[7,6]  R2357     6.9027376174926758e-01
    phi[7,6]  R2358     -1.1878594160079956e+00
    phi[7,6]  R2359     -6.4226430654525757e-01
    phi[7,6]  R2360     -3.6170175075531006e+00
    phi[7,6]  R2361     -3.6553664207458496e+00
    phi[7,6]  R2362     -3.2443084716796875e+00
    phi[7,6]  R2363     -0.8002969622612
    phi[7,6]  R2364     -1.8056727647781372e+00
    phi[7,6]  R2365     -1.8706942796707153e+00
    phi[7,8]  R63       1
    phi[7,8]  R64       1
    phi[7,8]  R72       -1
    phi[7,8]  R2366     -3.0999999046325684e+00
    phi[7,8]  R2367     -3.0999999046325684e+00
    phi[7,8]  R2368     -2.2400000095367432e+00
    phi[7,8]  R2369     -2.2400000095367432e+00
    phi[7,8]  R2370     -3.0999999046325684e+00
    phi[7,8]  R2371     -3.0999999046325684e+00
    phi[7,8]  R2372     -2.5699999332427979e+00
    phi[7,8]  R2373     -2.5699999332427979e+00
    phi[7,8]  R2374     -3.0999999046325684e+00
    phi[7,8]  R2375     -3.0999999046325684e+00
    phi[7,8]  R2376     -2.0899999141693115e+00
    phi[7,8]  R2377     -2.0899999141693115e+00
    phi[7,8]  R2378     -3.0999999046325684e+00
    phi[7,8]  R2379     -3.0999999046325684e+00
    phi[7,8]  R2380     1.9159718751907349e+00
    phi[7,8]  R2381     2.0577039718627930e+00
    phi[7,8]  R2382     -8.6943298578262329e-01
    phi[7,8]  R2383     2.6815852522850037e-01
    phi[7,8]  R2384     -5.4108953475952148e-01
    phi[7,8]  R2385     5.1463907957077026e-01
    phi[7,8]  R2386     1.1178762912750244e+00
    phi[7,8]  R2387     -3.8964742422103882e-01
    phi[7,8]  R2388     -2.7435517311096191e+00
    phi[7,8]  R2389     -2.0472514629364014e+00
    phi[7,8]  R2390     -5.5579113960266113e-01
    phi[7,8]  R2391     -1.5793602466583252e+00
    phi[7,8]  R2392     2.8342044353485107e-01
    phi[7,8]  R2393     1.2700122594833374e+00
    phi[7,8]  R2394     -1.5616843700408936e+00
    phi[7,8]  R2395     -1.8515017032623291e+00
    phi[7,8]  R2396     -1.7107207775115967e+00
    phi[7,8]  R2397     -7.3008143901824951e-01
    phi[7,8]  R2398     -1.3536863327026367e+00
    phi[7,8]  R2399     -1.1121237277984619e+00
    phi[7,8]  R2400     -6.1220288276672363e-01
    phi[7,8]  R2401     -1.5506057441234589e-01
    phi[7,8]  R2402     -1.5875830650329590e+00
    phi[7,8]  R2403     4.1646383702754974e-02
    phi[7,8]  R2404     -1.2067641019821167e+00
    phi[7,8]  R2405     -2.8571858406066895e+00
    phi[7,8]  R2406     -2.80363392829895
    phi[7,8]  R2407     -6.7171424627304077e-01
    phi[7,8]  R2408     2.0053987503051758e+00
    phi[7,8]  R2409     2.6876144409179688e+00
    phi[7,8]  R2410     2.3993482589721680e+00
    phi[7,8]  R2411     4.8254346847534180e-01
    phi[7,8]  R2412     9.9705904722213745e-01
    phi[7,8]  R2413     -1.5135887861251831e+00
    phi[7,8]  R2414     1.1325138807296753e+00
    phi[7,8]  R2415     9.9420644342899323e-02
    phi[7,8]  R2416     -5.6836053729057312e-02
    phi[7,8]  R2417     3.1831018626689911e-02
    phi[7,8]  R2418     -3.1887047290802
    phi[7,8]  R2419     -2.9339799880981445e+00
    phi[7,8]  R2420     -3.3295156955718994e+00
    phi[7,8]  R2421     -1.3907986879348755e+00
    phi[7,8]  R2422     -2.5712645053863525e+00
    phi[7,8]  R2423     -2.3654139041900635e+00
    phi[7,8]  R2424     -1.0515775680541992e+00
    phi[7,8]  R2425     -6.6285365819931030e-01
    phi[7,8]  R2426     -1.3864952325820923e+00
    phi[7,8]  R2427     -2.3377557098865509e-01
    phi[7,8]  R2428     -1.8300564289093018e+00
    phi[7,8]  R2429     -1.5176249742507935e+00
    phi[7,8]  R2430     -2.0962707996368408e+00
    phi[7,8]  R2431     -8.1434261798858643e-01
    phi[7,8]  R2432     -7.2600233554840088e-01
    phi[7,8]  R2433     -2.3284370899200439e+00
    phi[7,8]  R2434     1.4063940048217773e+00
    phi[7,8]  R2435     -5.6480014324188232e-01
    phi[7,8]  R2436     -1.1217931658029556e-01
    phi[7,8]  R2437     1.1960414052009583e-01
    phi[7,8]  R2438     -1.3058751821517944e+00
    phi[7,8]  R2439     6.0782778263092041e-01
    phi[7,8]  R2440     5.9910565614700317e-01
    phi[7,8]  R2441     -4.5700025558471680e-01
    phi[7,8]  R2442     9.5509600639343262e-01
    phi[7,8]  R2443     8.5928380489349365e-01
    phi[7,8]  R2444     9.3259853124618530e-01
    phi[7,8]  R2445     -1.9309883117675781e+00
    phi[7,8]  R2446     -1.3852605819702148e+00
    phi[7,8]  R2447     -1.3446302413940430e+00
    phi[8,7]  R63       -1
    phi[8,7]  R72       1
    phi[8,7]  R73       1
    phi[8,7]  R2448     -3.0999999046325684e+00
    phi[8,7]  R2449     -3.0999999046325684e+00
    phi[8,7]  R2450     -2.2400000095367432e+00
    phi[8,7]  R2451     -2.2400000095367432e+00
    phi[8,7]  R2452     -3.0999999046325684e+00
    phi[8,7]  R2453     -3.0999999046325684e+00
    phi[8,7]  R2454     -2.5699999332427979e+00
    phi[8,7]  R2455     -2.5699999332427979e+00
    phi[8,7]  R2456     -3.0999999046325684e+00
    phi[8,7]  R2457     -3.0999999046325684e+00
    phi[8,7]  R2458     -2.0899999141693115e+00
    phi[8,7]  R2459     -2.0899999141693115e+00
    phi[8,7]  R2460     -3.0999999046325684e+00
    phi[8,7]  R2461     -3.0999999046325684e+00
    phi[8,7]  R2462     2.0053987503051758e+00
    phi[8,7]  R2463     2.6876144409179688e+00
    phi[8,7]  R2464     2.3993482589721680e+00
    phi[8,7]  R2465     4.8254346847534180e-01
    phi[8,7]  R2466     9.9705904722213745e-01
    phi[8,7]  R2467     -1.5135887861251831e+00
    phi[8,7]  R2468     1.1325138807296753e+00
    phi[8,7]  R2469     9.9420644342899323e-02
    phi[8,7]  R2470     -5.6836053729057312e-02
    phi[8,7]  R2471     3.1831018626689911e-02
    phi[8,7]  R2472     -3.1887047290802
    phi[8,7]  R2473     -2.9339799880981445e+00
    phi[8,7]  R2474     -3.3295156955718994e+00
    phi[8,7]  R2475     -1.3907986879348755e+00
    phi[8,7]  R2476     -2.5712645053863525e+00
    phi[8,7]  R2477     -2.3654139041900635e+00
    phi[8,7]  R2478     -1.0515775680541992e+00
    phi[8,7]  R2479     -6.6285365819931030e-01
    phi[8,7]  R2480     -1.3864952325820923e+00
    phi[8,7]  R2481     -2.3377557098865509e-01
    phi[8,7]  R2482     -1.8300564289093018e+00
    phi[8,7]  R2483     -1.5176249742507935e+00
    phi[8,7]  R2484     -2.0962707996368408e+00
    phi[8,7]  R2485     -8.1434261798858643e-01
    phi[8,7]  R2486     -7.2600233554840088e-01
    phi[8,7]  R2487     -2.3284370899200439e+00
    phi[8,7]  R2488     1.4063940048217773e+00
    phi[8,7]  R2489     -5.6480014324188232e-01
    phi[8,7]  R2490     -1.1217931658029556e-01
    phi[8,7]  R2491     1.1960414052009583e-01
    phi[8,7]  R2492     -1.3058751821517944e+00
    phi[8,7]  R2493     6.0782778263092041e-01
    phi[8,7]  R2494     5.9910565614700317e-01
    phi[8,7]  R2495     -4.5700025558471680e-01
    phi[8,7]  R2496     9.5509600639343262e-01
    phi[8,7]  R2497     8.5928380489349365e-01
    phi[8,7]  R2498     9.3259853124618530e-01
    phi[8,7]  R2499     -1.9309883117675781e+00
    phi[8,7]  R2500     -1.3852605819702148e+00
    phi[8,7]  R2501     -1.3446302413940430e+00
    phi[8,7]  R2502     1.9159718751907349e+00
    phi[8,7]  R2503     2.0577039718627930e+00
    phi[8,7]  R2504     -8.6943298578262329e-01
    phi[8,7]  R2505     2.6815852522850037e-01
    phi[8,7]  R2506     -5.4108953475952148e-01
    phi[8,7]  R2507     5.1463907957077026e-01
    phi[8,7]  R2508     1.1178762912750244e+00
    phi[8,7]  R2509     -3.8964742422103882e-01
    phi[8,7]  R2510     -2.7435517311096191e+00
    phi[8,7]  R2511     -2.0472514629364014e+00
    phi[8,7]  R2512     -5.5579113960266113e-01
    phi[8,7]  R2513     -1.5793602466583252e+00
    phi[8,7]  R2514     2.8342044353485107e-01
    phi[8,7]  R2515     1.2700122594833374e+00
    phi[8,7]  R2516     -1.5616843700408936e+00
    phi[8,7]  R2517     -1.8515017032623291e+00
    phi[8,7]  R2518     -1.7107207775115967e+00
    phi[8,7]  R2519     -7.3008143901824951e-01
    phi[8,7]  R2520     -1.3536863327026367e+00
    phi[8,7]  R2521     -1.1121237277984619e+00
    phi[8,7]  R2522     -6.1220288276672363e-01
    phi[8,7]  R2523     -1.5506057441234589e-01
    phi[8,7]  R2524     -1.5875830650329590e+00
    phi[8,7]  R2525     4.1646383702754974e-02
    phi[8,7]  R2526     -1.2067641019821167e+00
    phi[8,7]  R2527     -2.8571858406066895e+00
    phi[8,7]  R2528     -2.80363392829895
    phi[8,7]  R2529     -6.7171424627304077e-01
    phi[8,9]  R72       1
    phi[8,9]  R73       1
    phi[8,9]  R81       -1
    phi[8,9]  R2530     -3.0999999046325684e+00
    phi[8,9]  R2531     -3.0999999046325684e+00
    phi[8,9]  R2532     -2.2400000095367432e+00
    phi[8,9]  R2533     -2.2400000095367432e+00
    phi[8,9]  R2534     -3.0999999046325684e+00
    phi[8,9]  R2535     -3.0999999046325684e+00
    phi[8,9]  R2536     -2.5699999332427979e+00
    phi[8,9]  R2537     -2.5699999332427979e+00
    phi[8,9]  R2538     -3.0999999046325684e+00
    phi[8,9]  R2539     -3.0999999046325684e+00
    phi[8,9]  R2540     -2.0899999141693115e+00
    phi[8,9]  R2541     -2.0899999141693115e+00
    phi[8,9]  R2542     -3.0999999046325684e+00
    phi[8,9]  R2543     -3.0999999046325684e+00
    phi[8,9]  R2544     2.0053987503051758e+00
    phi[8,9]  R2545     2.6876144409179688e+00
    phi[8,9]  R2546     2.3993482589721680e+00
    phi[8,9]  R2547     4.8254346847534180e-01
    phi[8,9]  R2548     9.9705904722213745e-01
    phi[8,9]  R2549     -1.5135887861251831e+00
    phi[8,9]  R2550     1.1325138807296753e+00
    phi[8,9]  R2551     9.9420644342899323e-02
    phi[8,9]  R2552     -5.6836053729057312e-02
    phi[8,9]  R2553     3.1831018626689911e-02
    phi[8,9]  R2554     -3.1887047290802
    phi[8,9]  R2555     -2.9339799880981445e+00
    phi[8,9]  R2556     -3.3295156955718994e+00
    phi[8,9]  R2557     -1.3907986879348755e+00
    phi[8,9]  R2558     -2.5712645053863525e+00
    phi[8,9]  R2559     -2.3654139041900635e+00
    phi[8,9]  R2560     -1.0515775680541992e+00
    phi[8,9]  R2561     -6.6285365819931030e-01
    phi[8,9]  R2562     -1.3864952325820923e+00
    phi[8,9]  R2563     -2.3377557098865509e-01
    phi[8,9]  R2564     -1.8300564289093018e+00
    phi[8,9]  R2565     -1.5176249742507935e+00
    phi[8,9]  R2566     -2.0962707996368408e+00
    phi[8,9]  R2567     -8.1434261798858643e-01
    phi[8,9]  R2568     -7.2600233554840088e-01
    phi[8,9]  R2569     -2.3284370899200439e+00
    phi[8,9]  R2570     1.4063940048217773e+00
    phi[8,9]  R2571     -5.6480014324188232e-01
    phi[8,9]  R2572     -1.1217931658029556e-01
    phi[8,9]  R2573     1.1960414052009583e-01
    phi[8,9]  R2574     -1.3058751821517944e+00
    phi[8,9]  R2575     6.0782778263092041e-01
    phi[8,9]  R2576     5.9910565614700317e-01
    phi[8,9]  R2577     -4.5700025558471680e-01
    phi[8,9]  R2578     9.5509600639343262e-01
    phi[8,9]  R2579     8.5928380489349365e-01
    phi[8,9]  R2580     9.3259853124618530e-01
    phi[8,9]  R2581     -1.9309883117675781e+00
    phi[8,9]  R2582     -1.3852605819702148e+00
    phi[8,9]  R2583     -1.3446302413940430e+00
    phi[8,9]  R2584     1.9444248676300049e+00
    phi[8,9]  R2585     1.4549728631973267e+00
    phi[8,9]  R2586     2.3942992687225342e+00
    phi[8,9]  R2587     2.0392901897430420e+00
    phi[8,9]  R2588     4.6727928519248962e-01
    phi[8,9]  R2589     -4.8645758628845215e-01
    phi[8,9]  R2590     3.0442276597023010e-01
    phi[8,9]  R2591     -1.0067421197891235e+00
    phi[8,9]  R2592     -2.2300343513488770e+00
    phi[8,9]  R2593     -2.38210129737854
    phi[8,9]  R2594     -2.5662178993225098e+00
    phi[8,9]  R2595     -1.4659725427627563e+00
    phi[8,9]  R2596     -9.7503942251205444e-01
    phi[8,9]  R2597     -1.4028270542621613e-01
    phi[8,9]  R2598     -1.2299046516418457e+00
    phi[8,9]  R2599     -9.9255681037902832e-01
    phi[8,9]  R2600     -1.12095046043396
    phi[8,9]  R2601     -2.03456711769104
    phi[8,9]  R2602     -2.6443424224853516e+00
    phi[8,9]  R2603     -1.5438759326934814e+00
    phi[8,9]  R2604     -1.1194546222686768e+00
    phi[8,9]  R2605     -2.4674823284149170e+00
    phi[8,9]  R2606     -7.4181622266769409e-01
    phi[8,9]  R2607     -1.8904321193695068e+00
    phi[8,9]  R2608     -2.2201573848724365e+00
    phi[8,9]  R2609     -1.1348236799240112e+00
    phi[8,9]  R2610     -1.0030443668365479e+00
    phi[8,9]  R2611     -4.9550110101699829e-01
    phi[8,9]  R2612     -1.1913045644760132e+00
    phi[8,9]  R2613     -1.4331978559494019e+00
    phi[8,9]  R2614     -1.0425816774368286e+00
    phi[8,9]  R2615     -1.2760782241821289e+00
    phi[8,9]  R2616     -2.9680292606353760e+00
    phi[8,9]  R2617     -2.5917289257049561e+00
    phi[9,8]  R72       -1
    phi[9,8]  R81       1
    phi[9,8]  R82       1
    phi[9,8]  R2618     -3.0999999046325684e+00
    phi[9,8]  R2619     -3.0999999046325684e+00
    phi[9,8]  R2620     -2.2400000095367432e+00
    phi[9,8]  R2621     -2.2400000095367432e+00
    phi[9,8]  R2622     -3.0999999046325684e+00
    phi[9,8]  R2623     -3.0999999046325684e+00
    phi[9,8]  R2624     -2.5699999332427979e+00
    phi[9,8]  R2625     -2.5699999332427979e+00
    phi[9,8]  R2626     -3.0999999046325684e+00
    phi[9,8]  R2627     -3.0999999046325684e+00
    phi[9,8]  R2628     -2.0899999141693115e+00
    phi[9,8]  R2629     -2.0899999141693115e+00
    phi[9,8]  R2630     -3.0999999046325684e+00
    phi[9,8]  R2631     -3.0999999046325684e+00
    phi[9,8]  R2632     1.9444248676300049e+00
    phi[9,8]  R2633     1.4549728631973267e+00
    phi[9,8]  R2634     2.3942992687225342e+00
    phi[9,8]  R2635     2.0392901897430420e+00
    phi[9,8]  R2636     4.6727928519248962e-01
    phi[9,8]  R2637     -4.8645758628845215e-01
    phi[9,8]  R2638     3.0442276597023010e-01
    phi[9,8]  R2639     -1.0067421197891235e+00
    phi[9,8]  R2640     -2.2300343513488770e+00
    phi[9,8]  R2641     -2.38210129737854
    phi[9,8]  R2642     -2.5662178993225098e+00
    phi[9,8]  R2643     -1.4659725427627563e+00
    phi[9,8]  R2644     -9.7503942251205444e-01
    phi[9,8]  R2645     -1.4028270542621613e-01
    phi[9,8]  R2646     -1.2299046516418457e+00
    phi[9,8]  R2647     -9.9255681037902832e-01
    phi[9,8]  R2648     -1.12095046043396
    phi[9,8]  R2649     -2.03456711769104
    phi[9,8]  R2650     -2.6443424224853516e+00
    phi[9,8]  R2651     -1.5438759326934814e+00
    phi[9,8]  R2652     -1.1194546222686768e+00
    phi[9,8]  R2653     -2.4674823284149170e+00
    phi[9,8]  R2654     -7.4181622266769409e-01
    phi[9,8]  R2655     -1.8904321193695068e+00
    phi[9,8]  R2656     -2.2201573848724365e+00
    phi[9,8]  R2657     -1.1348236799240112e+00
    phi[9,8]  R2658     -1.0030443668365479e+00
    phi[9,8]  R2659     -4.9550110101699829e-01
    phi[9,8]  R2660     -1.1913045644760132e+00
    phi[9,8]  R2661     -1.4331978559494019e+00
    phi[9,8]  R2662     -1.0425816774368286e+00
    phi[9,8]  R2663     -1.2760782241821289e+00
    phi[9,8]  R2664     -2.9680292606353760e+00
    phi[9,8]  R2665     -2.5917289257049561e+00
    phi[9,8]  R2666     2.0053987503051758e+00
    phi[9,8]  R2667     2.6876144409179688e+00
    phi[9,8]  R2668     2.3993482589721680e+00
    phi[9,8]  R2669     4.8254346847534180e-01
    phi[9,8]  R2670     9.9705904722213745e-01
    phi[9,8]  R2671     -1.5135887861251831e+00
    phi[9,8]  R2672     1.1325138807296753e+00
    phi[9,8]  R2673     9.9420644342899323e-02
    phi[9,8]  R2674     -5.6836053729057312e-02
    phi[9,8]  R2675     3.1831018626689911e-02
    phi[9,8]  R2676     -3.1887047290802
    phi[9,8]  R2677     -2.9339799880981445e+00
    phi[9,8]  R2678     -3.3295156955718994e+00
    phi[9,8]  R2679     -1.3907986879348755e+00
    phi[9,8]  R2680     -2.5712645053863525e+00
    phi[9,8]  R2681     -2.3654139041900635e+00
    phi[9,8]  R2682     -1.0515775680541992e+00
    phi[9,8]  R2683     -6.6285365819931030e-01
    phi[9,8]  R2684     -1.3864952325820923e+00
    phi[9,8]  R2685     -2.3377557098865509e-01
    phi[9,8]  R2686     -1.8300564289093018e+00
    phi[9,8]  R2687     -1.5176249742507935e+00
    phi[9,8]  R2688     -2.0962707996368408e+00
    phi[9,8]  R2689     -8.1434261798858643e-01
    phi[9,8]  R2690     -7.2600233554840088e-01
    phi[9,8]  R2691     -2.3284370899200439e+00
    phi[9,8]  R2692     1.4063940048217773e+00
    phi[9,8]  R2693     -5.6480014324188232e-01
    phi[9,8]  R2694     -1.1217931658029556e-01
    phi[9,8]  R2695     1.1960414052009583e-01
    phi[9,8]  R2696     -1.3058751821517944e+00
    phi[9,8]  R2697     6.0782778263092041e-01
    phi[9,8]  R2698     5.9910565614700317e-01
    phi[9,8]  R2699     -4.5700025558471680e-01
    phi[9,8]  R2700     9.5509600639343262e-01
    phi[9,8]  R2701     8.5928380489349365e-01
    phi[9,8]  R2702     9.3259853124618530e-01
    phi[9,8]  R2703     -1.9309883117675781e+00
    phi[9,8]  R2704     -1.3852605819702148e+00
    phi[9,8]  R2705     -1.3446302413940430e+00
    phi[9,11]  R81       1
    phi[9,11]  R82       1
    phi[9,11]  R83       -2.3659294656801513e+00
    phi[9,11]  R84       1.61396413869553
    phi[9,11]  R85       7.2004346022925292e-01
    phi[9,11]  R86       -1.1164516108306279e+00
    phi[9,11]  R87       -1.6949008548941715e+00
    phi[9,11]  R88       4.8224095273947909e-01
    phi[9,11]  R89       -6.2122488005295651e-01
    phi[9,11]  R91       -1
    phi[9,11]  R2706     -5.46592937031272
    phi[9,11]  R2707     -7.3407043895241708e-01
    phi[9,11]  R2708     -6.2603587084121326e-01
    phi[9,11]  R2709     -3.8539641482322731e+00
    phi[9,11]  R2710     -2.3799564444033154e+00
    phi[9,11]  R2711     -3.8200433648618213e+00
    phi[9,11]  R2712     -3.6864515440734258e+00
    phi[9,11]  R2713     -1.45354832241217
    phi[9,11]  R2714     -4.79490075952674
    phi[9,11]  R2715     -1.4050990497383968e+00
    phi[9,11]  R2716     -1.6077589614298324e+00
    phi[9,11]  R2717     -2.5722408669087908e+00
    phi[9,11]  R2718     -3.7212247846855249e+00
    phi[9,11]  R2719     -2.4787750245796119e+00
    phi[9,11]  R2720     -1.0947267337080291e-07
    phi[9,11]  R2721     -1.2253830528052845e-07
    phi[9,11]  R2722     -1.2528701174296941e-06
    phi[9,11]  R2723     -0.0462391478773756
    phi[9,11]  R2724     -2.1366686465974072e-01
    phi[9,11]  R2725     -9.0062212022035459e-02
    phi[9,11]  R2726     -1.1049707144135379e-01
    phi[9,11]  R2727     -6.9668333735950216e-01
    phi[9,11]  R2728     -5.1679191720146989e-01
    phi[9,11]  R2729     -0.543001630572638
    phi[9,11]  R2730     -8.9856344287354206e-01
    phi[9,11]  R2731     -0.449830058735446
    phi[9,11]  R2732     -2.5020712363227582e-01
    phi[9,11]  R2733     -2.2519630710434629e-01
    phi[9,11]  R2734     -2.5064858022866821e-01
    phi[9,11]  R2735     -1.8730661938910542e-01
    phi[9,11]  R2736     -2.0986887064936455e-01
    phi[9,11]  R2737     -0.437093687309809
    phi[9,11]  R2738     -7.3718236017643735e-01
    phi[9,11]  R2739     -6.9820288902125616e-01
    phi[9,11]  R2740     -2.8981037980482749e-01
    phi[9,11]  R2741     -2.9675265338357359e-01
    phi[9,11]  R2742     -2.9679712757079646e-01
    phi[9,11]  R2743     -3.0068516345549545e-01
    phi[9,11]  R2744     -3.1219375222075563e-01
    phi[9,11]  R2745     -1.8364685609822506e-01
    phi[9,11]  R2746     -1.8955412262015015e-01
    phi[9,11]  R2747     -1.8999784914829271e-01
    phi[9,11]  R2748     -3.0194721169244809e-01
    phi[9,11]  R2749     -7.9236295129814660e-01
    phi[9,11]  R2750     -2.1292938145974905e-01
    phi[9,11]  R2751     -2.1453216423632426e-01
    phi[9,11]  R2752     -3.1563584367619990e-01
    phi[9,11]  R2753     -3.2924109039425842e-01
    MARKER    'MARKER'                 'INTEND'
    z[0,1,0]  R2        -1
    z[0,1,0]  R11       1
    z[0,1,0]  R92       -1
    z[0,1,0]  R93       1
    z[0,1,0]  R106      4.9490082263946533e-01
    z[0,1,0]  R107      4.1498789191246033e-01
    z[0,1,0]  R108      5.6200385093688965e-01
    z[0,1,0]  R109      -2.7195507287979126e-01
    z[0,1,0]  R110      -1.5923419594764709e-01
    z[0,1,0]  R111      1.1338619142770767e-01
    z[0,1,0]  R112      -5.6006636470556259e-02
    z[0,1,0]  R113      -2.2266621887683868e-01
    z[0,1,0]  R114      1.8465099856257439e-02
    z[0,1,0]  R115      6.4370214939117432e-02
    z[0,1,0]  R116      1.5307880938053131e-01
    z[0,1,0]  R117      7.3211260139942169e-02
    z[0,1,0]  R118      3.4881255030632019e-01
    z[0,1,0]  R119      -3.8617795705795288e-01
    z[0,1,0]  R120      -1.6033592820167542e-01
    z[0,1,0]  R121      -5.0186461210250854e-01
    z[0,1,0]  R122      -4.7637766599655151e-01
    z[0,1,0]  R123      -0.341469407081604
    z[0,1,0]  R124      -4.7362893819808960e-01
    z[0,1,0]  R125      -2.7223885059356689e-01
    z[0,1,0]  R126      2.4971213936805725e-01
    z[0,1,0]  R127      -6.0493912547826767e-02
    z[0,1,0]  R128      -0.0623035691678524
    z[0,1,0]  R129      1.6990311443805695e-02
    z[0,1,0]  R130      3.0292698740959167e-01
    z[0,1,0]  R131      -1.4488242566585541e-01
    z[0,1,0]  R132      2.6645186543464661e-01
    z[0,1,0]  R133      -1.6680526733398438e-01
    z[0,1,0]  R134      -6.0302621126174927e-01
    z[0,1,0]  R135      -4.7555884718894958e-01
    z[0,1,0]  R136      3.0833488702774048e-01
    z[0,1,0]  R137      3.6954346299171448e-01
    z[0,1,0]  R138      1.3853612542152405e-01
    z[0,1,0]  R139      1.1774213053286076e-02
    z[0,1,0]  R140      -3.4528955817222595e-01
    z[0,1,0]  R141      -0.51384037733078
    z[0,1,0]  R142      2.9657664895057678e-01
    z[0,1,0]  R143      3.4071081876754761e-01
    z[0,1,0]  R144      4.9104800820350647e-01
    z[0,1,0]  R145      -5.7003223896026611e-01
    z[0,1,0]  R146      -0.0688767358660698
    z[0,1,0]  R147      -4.3175253272056580e-01
    z[0,1,0]  R148      1.4744243025779724e-01
    z[0,1,0]  R149      -1.8172748386859894e-01
    z[0,1,0]  R150      6.0729360580444336e-01
    z[0,1,0]  R151      7.0505076646804810e-01
    z[0,1,0]  R152      -5.4727524518966675e-01
    z[0,1,0]  R153      6.3396120071411133e-01
    z[0,1,0]  R154      -4.9636000394821167e-01
    z[0,1,0]  R155      7.1425217390060425e-01
    z[0,1,0]  R156      2.8491258621215820e-01
    z[0,1,0]  R157      2.6955893635749817e-01
    z[0,1,0]  R158      1.4603634178638458e-01
    z[0,1,0]  R159      -6.4753681421279907e-02
    z[0,1,0]  R160      2.0705427229404449e-01
    z[0,1,0]  R161      4.6588051319122314e-01
    z[0,1,0]  R162      -6.0379576683044434e-01
    z[0,1,0]  R163      -7.6082962751388550e-01
    z[0,1,0]  R164      -7.6411402225494385e-01
    z[0,1,0]  R165      -8.1588953733444214e-01
    z[0,1,0]  R166      -6.5858542919158936e-01
    z[0,1,0]  R167      -6.5801924467086792e-01
    z[0,1,0]  R168      -7.1887493133544922e-01
    z[0,1,0]  R169      -4.1052407026290894e-01
    z[0,1,0]  R170      -7.1989625692367554e-01
    z[0,1,0]  R171      -0.59494549036026
    z[0,1,0]  R172      -5.6977653503417969e-01
    z[0,1,0]  R173      -6.3382625579833984e-01
    z[0,1,0]  R174      -0.820820689201355
    z[0,1,0]  R175      -0.791208803653717
    z[0,1,0]  R176      -1.5829540789127350e-01
    z[0,1,0]  R177      1.0571720451116562e-01
    z[0,1,0]  R178      9.0164765715599060e-02
    z[0,1,0]  R179      2.3170144855976105e-01
    z[0,1,0]  R180      1.9998101890087128e-01
    z[0,1,0]  R181      4.8847761750221252e-01
    z[0,1,0]  R182      2.9615685343742371e-01
    z[0,1,0]  R183      3.3222836256027222e-01
    z[0,1,0]  R184      3.5924544930458069e-01
    z[0,1,0]  R185      2.8316259384155273e-01
    z[0,1,0]  R186      4.6913135051727295e-01
    z[0,1,0]  R187      5.9548223018646240e-01
    z[0,1,0]  R188      5.5419504642486572e-01
    z[0,1,0]  R189      7.1332257986068726e-01
    z[0,1,0]  R190      0.413044273853302
    z[0,1,0]  R191      -4.1304641962051392e-01
    z[0,1,0]  R192      4.5895689725875854e-01
    z[0,1,0]  R193      5.3956449031829834e-01
    z[0,1,0]  R194      1.8347802758216858e-01
    z[0,1,0]  R195      8.0835449695587158e-01
    z[0,1,0]  R196      -2.6094338297843933e-01
    z[0,1,0]  R197      -1.0375731438398361e-01
    z[0,1,0]  R198      -1.1744309961795807e-01
    z[0,1,0]  R199      1.6161955893039703e-01
    z[0,1,0]  R200      4.5744961500167847e-01
    z[0,1,0]  R201      2.7871596813201904e-01
    z[0,1,0]  R202      2.7719014883041382e-01
    z[0,1,0]  R203      1.2179224193096161e-01
    z[0,1,0]  R204      -6.3695102930068970e-02
    z[0,1,0]  R205      0.629237711429596
    z[0,1,0]  R206      3.9095136523246765e-01
    z[0,1,0]  R207      3.6560770124197006e-02
    z[0,1,0]  R208      1.7770273983478546e-01
    z[0,1,0]  R209      1.4492644369602203e-01
    z[0,1,0]  R210      0.556480348110199
    z[0,1,0]  R211      5.0131708383560181e-01
    z[0,1,0]  R212      2.5523781776428223e-01
    z[0,1,0]  R213      -1.5742602944374084e-01
    z[0,1,0]  R214      4.6901664137840271e-01
    z[0,1,0]  R215      -0.0424308106303215
    z[0,1,0]  R216      2.9013910889625549e-01
    z[0,1,0]  R217      -2.6687833666801453e-01
    z[0,1,0]  R218      8.5017897188663483e-02
    z[0,1,0]  R219      -1.7064388096332550e-01
    z[0,1,0]  R220      7.6443380117416382e-01
    z[0,1,0]  R221      1.9689476490020752e-01
    z[0,1,0]  R222      8.2556062936782837e-01
    z[0,1,0]  R223      -1.2607698142528534e-01
    z[0,1,0]  R224      7.0532029867172241e-01
    z[0,1,0]  R225      0.554187536239624
    z[0,1,0]  R226      0.498337984085083
    z[0,1,0]  R227      1.3690540194511414e-01
    z[0,1,0]  R228      2.0153930783271790e-01
    z[0,1,0]  R229      3.8671070337295532e-01
    z[0,1,0]  R230      -7.6744019985198975e-02
    z[0,1,0]  R231      2.1289205551147461e-01
    z[0,1,0]  R232      -1.2130734324455261e-01
    z[0,1,0]  R233      4.4750612229108810e-02
    z[0,1,0]  R234      -1.3699607551097870e-01
    z[0,1,0]  R235      1.7185197770595551e-01
    z[0,1,0]  R236      3.0488875508308411e-01
    z[0,1,0]  R237      -2.1510450541973114e-01
    z[0,1,0]  R238      -4.6034038066864014e-01
    z[0,1,0]  R239      4.8502811789512634e-01
    z[0,1,0]  R240      3.1340980529785156e-01
    z[0,1,0]  R241      -3.1027961522340775e-02
    z[0,1,0]  R242      1.2311228550970554e-02
    z[0,1,0]  R243      6.5089219808578491e-01
    z[0,1,0]  R244      2.2151054814457893e-02
    z[0,1,0]  R245      6.4380139112472534e-01
    z[0,1,1]  R3        -1
    z[0,1,1]  R12       1
    z[0,1,1]  R94       -1
    z[0,1,1]  R95       1
    z[0,1,1]  R106      -2.3231776058673859e-01
    z[0,1,1]  R107      -4.2521899938583374e-01
    z[0,1,1]  R108      -2.8838777542114258e-01
    z[0,1,1]  R109      -2.9415807127952576e-01
    z[0,1,1]  R110      -1.8136461079120636e-01
    z[0,1,1]  R111      0.614677906036377
    z[0,1,1]  R112      8.8259148597717285e-01
    z[0,1,1]  R113      -1.2112042307853699e-01
    z[0,1,1]  R114      -2.1046364307403564e-01
    z[0,1,1]  R115      8.1843149662017822e-01
    z[0,1,1]  R116      1.2217903882265091e-01
    z[0,1,1]  R117      4.1422221064567566e-01
    z[0,1,1]  R118      -5.2835303544998169e-01
    z[0,1,1]  R119      -6.0785013437271118e-01
    z[0,1,1]  R120      2.9621484875679016e-01
    z[0,1,1]  R121      1.9389666616916656e-01
    z[0,1,1]  R122      -1.0692614316940308e-01
    z[0,1,1]  R123      3.5085476934909821e-02
    z[0,1,1]  R124      0.0629362165927887
    z[0,1,1]  R125      1.1717350780963898e-01
    z[0,1,1]  R126      4.6073517203330994e-01
    z[0,1,1]  R127      7.1917676925659180e-01
    z[0,1,1]  R128      5.5513072013854980e-01
    z[0,1,1]  R129      -5.3189247846603394e-01
    z[0,1,1]  R130      1.9663409888744354e-01
    z[0,1,1]  R131      0.213766410946846
    z[0,1,1]  R132      3.8322755694389343e-01
    z[0,1,1]  R133      6.5201544761657715e-01
    z[0,1,1]  R134      3.3321052789688110e-01
    z[0,1,1]  R135      6.9712668657302856e-01
    z[0,1,1]  R136      6.4458996057510376e-01
    z[0,1,1]  R137      -5.9066683053970337e-01
    z[0,1,1]  R138      -9.1286391019821167e-01
    z[0,1,1]  R139      -0.74636310338974
    z[0,1,1]  R140      -0.783897876739502
    z[0,1,1]  R141      -4.5693665742874146e-01
    z[0,1,1]  R142      -0.637538731098175
    z[0,1,1]  R143      -7.2442001104354858e-01
    z[0,1,1]  R144      -5.1696652173995972e-01
    z[0,1,1]  R145      1.1333186924457550e-01
    z[0,1,1]  R146      -6.8740415573120117e-01
    z[0,1,1]  R147      -5.5598491430282593e-01
    z[0,1,1]  R148      -7.0357513427734375e-01
    z[0,1,1]  R149      2.2914955019950867e-01
    z[0,1,1]  R150      3.8495090603828430e-01
    z[0,1,1]  R151      6.1672019958496094e-01
    z[0,1,1]  R152      1.0403732955455780e-01
    z[0,1,1]  R153      2.6857027783989906e-02
    z[0,1,1]  R154      3.9084741473197937e-01
    z[0,1,1]  R155      -1.0710010677576065e-01
    z[0,1,1]  R156      4.6051979064941406e-01
    z[0,1,1]  R157      -7.3174512386322021e-01
    z[0,1,1]  R158      -9.7263120114803314e-02
    z[0,1,1]  R159      -8.4369462728500366e-01
    z[0,1,1]  R160      1.1094018071889877e-01
    z[0,1,1]  R161      5.9087282419204712e-01
    z[0,1,1]  R162      -1.5158358030021191e-02
    z[0,1,1]  R163      -4.9962759017944336e-02
    z[0,1,1]  R164      -3.1675678491592407e-01
    z[0,1,1]  R165      -1.8333867192268372e-01
    z[0,1,1]  R166      -1.8033710122108459e-01
    z[0,1,1]  R167      -2.2804026305675507e-01
    z[0,1,1]  R168      -6.2383204698562622e-02
    z[0,1,1]  R169      -2.5859877467155457e-01
    z[0,1,1]  R170      -9.5601566135883331e-02
    z[0,1,1]  R171      -1.7058271169662476e-01
    z[0,1,1]  R172      -1.5964622795581818e-01
    z[0,1,1]  R173      -1.4073713123798370e-01
    z[0,1,1]  R174      -2.7701035141944885e-01
    z[0,1,1]  R175      -1.3329532742500305e-01
    z[0,1,1]  R176      0.804551362991333
    z[0,1,1]  R177      8.0172097682952881e-01
    z[0,1,1]  R178      8.9155030250549316e-01
    z[0,1,1]  R179      8.1907963752746582e-01
    z[0,1,1]  R180      8.7900412082672119e-01
    z[0,1,1]  R181      8.1295800209045410e-01
    z[0,1,1]  R182      7.5687986612319946e-01
    z[0,1,1]  R183      7.5830638408660889e-01
    z[0,1,1]  R184      7.4715173244476318e-01
    z[0,1,1]  R185      7.0336920022964478e-01
    z[0,1,1]  R186      -2.7622026205062866e-01
    z[0,1,1]  R187      -3.9142203330993652e-01
    z[0,1,1]  R188      -0.248797208070755
    z[0,1,1]  R189      -2.4576936662197113e-01
    z[0,1,1]  R190      -2.1434900164604187e-01
    z[0,1,1]  R191      1.0257773846387863e-01
    z[0,1,1]  R192      -1.3534389436244965e-01
    z[0,1,1]  R193      -1.5342769026756287e-01
    z[0,1,1]  R194      -2.4239315092563629e-01
    z[0,1,1]  R195      1.2143120914697647e-01
    z[0,1,1]  R196      5.4998785257339478e-01
    z[0,1,1]  R197      -7.4844092130661011e-01
    z[0,1,1]  R198      -5.1669752597808838e-01
    z[0,1,1]  R199      2.8788894414901733e-01
    z[0,1,1]  R200      -7.5884765386581421e-01
    z[0,1,1]  R201      -5.1433372497558594e-01
    z[0,1,1]  R202      -5.9484966099262238e-02
    z[0,1,1]  R203      5.6977644562721252e-02
    z[0,1,1]  R204      -9.7424782812595367e-02
    z[0,1,1]  R205      3.4643688797950745e-01
    z[0,1,1]  R206      -7.4864143133163452e-01
    z[0,1,1]  R207      -7.6750653982162476e-01
    z[0,1,1]  R208      -0.63265460729599
    z[0,1,1]  R209      -7.0288920402526855e-01
    z[0,1,1]  R210      -6.0325086116790771e-01
    z[0,1,1]  R211      -6.3913995027542114e-01
    z[0,1,1]  R212      3.4777700901031494e-01
    z[0,1,1]  R213      1.0955148190259933e-01
    z[0,1,1]  R214      3.3840516209602356e-01
    z[0,1,1]  R215      2.0106829702854156e-01
    z[0,1,1]  R216      2.3183113336563110e-01
    z[0,1,1]  R217      4.2090049386024475e-01
    z[0,1,1]  R218      4.7850003838539124e-01
    z[0,1,1]  R219      5.1707899570465088e-01
    z[0,1,1]  R220      4.5963954925537109e-01
    z[0,1,1]  R221      2.8990250825881958e-01
    z[0,1,1]  R222      6.1392839998006821e-02
    z[0,1,1]  R223      -6.5599137544631958e-01
    z[0,1,1]  R224      4.3035867810249329e-01
    z[0,1,1]  R225      4.1396754980087280e-01
    z[0,1,1]  R226      -5.6772458553314209e-01
    z[0,1,1]  R227      -4.0542924404144287e-01
    z[0,1,1]  R228      -2.9511788487434387e-01
    z[0,1,1]  R229      4.9987000226974487e-01
    z[0,1,1]  R230      4.4165849685668945e-01
    z[0,1,1]  R231      4.4861632585525513e-01
    z[0,1,1]  R232      0.58297199010849
    z[0,1,1]  R233      -0.700998842716217
    z[0,1,1]  R234      2.2690226137638092e-01
    z[0,1,1]  R235      -0.0210583433508873
    z[0,1,1]  R236      6.1287569999694824e-01
    z[0,1,1]  R237      -7.1970504522323608e-01
    z[0,1,1]  R238      -5.1845723390579224e-01
    z[0,1,1]  R239      5.7428580522537231e-01
    z[0,1,1]  R240      3.9865252375602722e-01
    z[0,1,1]  R241      -2.9648298025131226e-01
    z[0,1,1]  R242      3.0242647975683212e-02
    z[0,1,1]  R243      1.9152933359146118e-01
    z[0,1,1]  R244      7.7534466981887817e-01
    z[0,1,1]  R245      2.0321662724018097e-01
    z[0,1,2]  R4        -1
    z[0,1,2]  R13       1
    z[0,1,2]  R96       -1
    z[0,1,2]  R97       1
    z[0,1,2]  R106      -5.7488650083541870e-01
    z[0,1,2]  R107      -6.2625670433044434e-01
    z[0,1,2]  R108      -8.8665857911109924e-02
    z[0,1,2]  R109      -5.7745444774627686e-01
    z[0,1,2]  R110      -4.2030754685401917e-01
    z[0,1,2]  R111      -3.2679456472396851e-01
    z[0,1,2]  R112      2.3499237000942230e-01
    z[0,1,2]  R113      -2.5501725077629089e-01
    z[0,1,2]  R114      -6.5312135219573975e-01
    z[0,1,2]  R115      1.2549513578414917e-01
    z[0,1,2]  R116      -2.6208499073982239e-01
    z[0,1,2]  R117      3.5253354907035828e-01
    z[0,1,2]  R118      4.8182269930839539e-01
    z[0,1,2]  R119      3.8683211803436279e-01
    z[0,1,2]  R120      8.2693123817443848e-01
    z[0,1,2]  R121      8.0544006824493408e-01
    z[0,1,2]  R122      8.4311634302139282e-01
    z[0,1,2]  R123      8.9893138408660889e-01
    z[0,1,2]  R124      0.8321533203125
    z[0,1,2]  R125      9.1821324825286865e-01
    z[0,1,2]  R126      -7.1190494298934937e-01
    z[0,1,2]  R127      1.0455914773046970e-02
    z[0,1,2]  R128      2.5464800000190735e-01
    z[0,1,2]  R129      -5.5668348073959351e-01
    z[0,1,2]  R130      -0.676361620426178
    z[0,1,2]  R131      1.8518878519535065e-01
    z[0,1,2]  R132      -1.8845534324645996e-01
    z[0,1,2]  R133      -2.9361501336097717e-01
    z[0,1,2]  R134      1.4269612729549408e-02
    z[0,1,2]  R135      1.4455687999725342e-01
    z[0,1,2]  R136      -4.1292563080787659e-01
    z[0,1,2]  R137      -4.6847561001777649e-01
    z[0,1,2]  R138      2.1335519850254059e-01
    z[0,1,2]  R139      3.4986928105354309e-01
    z[0,1,2]  R140      -4.8542730510234833e-02
    z[0,1,2]  R141      -7.7823407948017120e-02
    z[0,1,2]  R142      -1.1915443092584610e-01
    z[0,1,2]  R143      3.6274176836013794e-01
    z[0,1,2]  R144      2.3225225508213043e-01
    z[0,1,2]  R145      -5.5932450294494629e-01
    z[0,1,2]  R146      1.0764485597610474e-01
    z[0,1,2]  R147      -8.8984228670597076e-02
    z[0,1,2]  R148      1.3610440492630005e-01
    z[0,1,2]  R149      -6.8699955940246582e-01
    z[0,1,2]  R150      1.8842889368534088e-01
    z[0,1,2]  R151      1.2623888254165649e-01
    z[0,1,2]  R152      -5.7087469100952148e-01
    z[0,1,2]  R153      2.1743780374526978e-01
    z[0,1,2]  R154      -6.2400847673416138e-01
    z[0,1,2]  R155      3.4387171268463135e-02
    z[0,1,2]  R156      -4.8959305882453918e-01
    z[0,1,2]  R157      2.3180879652500153e-01
    z[0,1,2]  R158      -4.3938422203063965e-01
    z[0,1,2]  R159      -2.0589542388916016e-01
    z[0,1,2]  R160      -1.7205569148063660e-01
    z[0,1,2]  R161      -2.3169048130512238e-02
    z[0,1,2]  R162      6.9852125644683838e-01
    z[0,1,2]  R163      0.470347136259079
    z[0,1,2]  R164      4.5164796710014343e-01
    z[0,1,2]  R165      3.8815578818321228e-01
    z[0,1,2]  R166      3.6491009593009949e-01
    z[0,1,2]  R167      8.3101242780685425e-02
    z[0,1,2]  R168      1.5813589096069336e-01
    z[0,1,2]  R169      4.2543417215347290e-01
    z[0,1,2]  R170      2.5178456306457520e-01
    z[0,1,2]  R171      6.8271708488464355e-01
    z[0,1,2]  R172      -3.4442096948623657e-01
    z[0,1,2]  R173      -1.5313203446567059e-02
    z[0,1,2]  R174      4.7069203108549118e-02
    z[0,1,2]  R175      -2.3530335724353790e-01
    z[0,1,2]  R176      2.4600613117218018e-01
    z[0,1,2]  R177      1.5599825978279114e-01
    z[0,1,2]  R178      1.8806867301464081e-01
    z[0,1,2]  R179      4.3373140692710876e-01
    z[0,1,2]  R180      -9.5579192042350769e-02
    z[0,1,2]  R181      0.0797993540763855
    z[0,1,2]  R182      6.5456248819828033e-02
    z[0,1,2]  R183      -2.2454971075057983e-01
    z[0,1,2]  R184      1.0154710710048676e-01
    z[0,1,2]  R185      3.5156715661287308e-02
    z[0,1,2]  R186      3.8920834660530090e-02
    z[0,1,2]  R187      -5.9202855825424194e-01
    z[0,1,2]  R188      -5.0289428234100342e-01
    z[0,1,2]  R189      -2.5969842076301575e-01
    z[0,1,2]  R190      -2.9287990927696228e-01
    z[0,1,2]  R191      -5.1057970523834229e-01
    z[0,1,2]  R192      -2.9195931553840637e-01
    z[0,1,2]  R193      -1.5345829725265503e-01
    z[0,1,2]  R194      -5.4529237747192383e-01
    z[0,1,2]  R195      -2.5295522809028625e-01
    z[0,1,2]  R196      9.3944780528545380e-02
    z[0,1,2]  R197      -4.6293100714683533e-01
    z[0,1,2]  R198      -6.5030390024185181e-01
    z[0,1,2]  R199      4.0662553906440735e-01
    z[0,1,2]  R200      4.1330105066299438e-01
    z[0,1,2]  R201      -3.1752744317054749e-01
    z[0,1,2]  R202      -8.1574696302413940e-01
    z[0,1,2]  R203      3.1801056861877441e-01
    z[0,1,2]  R204      -7.5886243581771851e-01
    z[0,1,2]  R205      -4.8464578390121460e-01
    z[0,1,2]  R206      -9.4092048704624176e-02
    z[0,1,2]  R207      -2.3630566895008087e-01
    z[0,1,2]  R208      3.9439156651496887e-02
    z[0,1,2]  R209      -5.8352392911911011e-01
    z[0,1,2]  R210      -4.4249197840690613e-01
    z[0,1,2]  R211      -3.7597176432609558e-01
    z[0,1,2]  R212      -1.0341511666774750e-01
    z[0,1,2]  R213      -0.631401777267456
    z[0,1,2]  R214      -1.3033016026020050e-01
    z[0,1,2]  R215      -0.673624575138092
    z[0,1,2]  R216      8.6111530661582947e-02
    z[0,1,2]  R217      -6.5445655584335327e-01
    z[0,1,2]  R218      -7.5995332002639771e-01
    z[0,1,2]  R219      -0.604049563407898
    z[0,1,2]  R220      -2.5753778219223022e-01
    z[0,1,2]  R221      -5.3976607322692871e-01
    z[0,1,2]  R222      4.2098306119441986e-02
    z[0,1,2]  R223      3.4863191843032837e-01
    z[0,1,2]  R224      4.5605354011058807e-02
    z[0,1,2]  R225      -3.8888771086931229e-02
    z[0,1,2]  R226      -2.9725676774978638e-01
    z[0,1,2]  R227      3.8173702359199524e-01
    z[0,1,2]  R228      -1.8941754102706909e-01
    z[0,1,2]  R229      1.1917474865913391e-01
    z[0,1,2]  R230      -7.8999191522598267e-01
    z[0,1,2]  R231      1.3872574269771576e-01
    z[0,1,2]  R232      4.2276558279991150e-01
    z[0,1,2]  R233      4.0643098950386047e-01
    z[0,1,2]  R234      5.0381618738174438e-01
    z[0,1,2]  R235      -3.2543742656707764e-01
    z[0,1,2]  R236      9.7078546881675720e-02
    z[0,1,2]  R237      -2.7968008071184158e-03
    z[0,1,2]  R238      3.8206619024276733e-01
    z[0,1,2]  R239      -2.5693991780281067e-01
    z[0,1,2]  R240      2.8152132034301758e-01
    z[0,1,2]  R241      -6.1093878746032715e-01
    z[0,1,2]  R242      -3.3857741951942444e-01
    z[0,1,2]  R243      -0.472592294216156
    z[0,1,2]  R244      9.7093977034091949e-02
    z[0,1,2]  R245      -2.3159457743167877e-01
    z[0,1,3]  R5        -1
    z[0,1,3]  R14       1
    z[0,1,3]  R98       -1
    z[0,1,3]  R99       1
    z[0,1,3]  R106      -5.7408112287521362e-01
    z[0,1,3]  R107      -3.6551985144615173e-01
    z[0,1,3]  R108      -5.9628689289093018e-01
    z[0,1,3]  R109      -2.9741668701171875e-01
    z[0,1,3]  R110      -4.1337344050407410e-01
    z[0,1,3]  R111      2.0641303062438965e-01
    z[0,1,3]  R112      2.1087038516998291e-01
    z[0,1,3]  R113      -7.0434558391571045e-01
    z[0,1,3]  R114      8.4888547658920288e-02
    z[0,1,3]  R115      8.0051563680171967e-02
    z[0,1,3]  R116      7.6750802993774414e-01
    z[0,1,3]  R117      4.0120804309844971e-01
    z[0,1,3]  R118      5.6791716814041138e-01
    z[0,1,3]  R119      -3.0295112729072571e-01
    z[0,1,3]  R120      1.9151894748210907e-01
    z[0,1,3]  R121      1.3078117370605469e-01
    z[0,1,3]  R122      1.4946061372756958e-01
    z[0,1,3]  R123      0.159884512424469
    z[0,1,3]  R124      9.7060039639472961e-02
    z[0,1,3]  R125      2.1969486773014069e-01
    z[0,1,3]  R126      3.3871078491210938e-01
    z[0,1,3]  R127      4.5961785316467285e-01
    z[0,1,3]  R128      7.3579859733581543e-01
    z[0,1,3]  R129      8.0825246870517731e-02
    z[0,1,3]  R130      4.8096778988838196e-01
    z[0,1,3]  R131      8.0494147539138794e-01
    z[0,1,3]  R132      3.7761631608009338e-01
    z[0,1,3]  R133      1.8257418274879456e-01
    z[0,1,3]  R134      6.4273148775100708e-01
    z[0,1,3]  R135      2.2279354929924011e-01
    z[0,1,3]  R136      2.6987805962562561e-01
    z[0,1,3]  R137      1.9493977725505829e-01
    z[0,1,3]  R138      -1.9338284432888031e-01
    z[0,1,3]  R139      -0.388785719871521
    z[0,1,3]  R140      -1.7030143737792969e-01
    z[0,1,3]  R141      -2.7515235543251038e-01
    z[0,1,3]  R142      6.0826158523559570e-01
    z[0,1,3]  R143      1.6258460283279419e-01
    z[0,1,3]  R144      5.2279084920883179e-01
    z[0,1,3]  R145      -5.2511040121316910e-02
    z[0,1,3]  R146      -0.637824296951294
    z[0,1,3]  R147      -1.9327494502067566e-01
    z[0,1,3]  R148      -1.5178553760051727e-01
    z[0,1,3]  R149      5.1419204473495483e-01
    z[0,1,3]  R150      1.2139932811260223e-01
    z[0,1,3]  R151      3.3413335680961609e-02
    z[0,1,3]  R152      -4.9365319311618805e-02
    z[0,1,3]  R153      2.4444395303726196e-01
    z[0,1,3]  R154      -1.7017644643783569e-01
    z[0,1,3]  R155      5.3708422183990479e-01
    z[0,1,3]  R156      6.0811394453048706e-01
    z[0,1,3]  R157      -3.2972010970115662e-01
    z[0,1,3]  R158      7.2953003644943237e-01
    z[0,1,3]  R159      -2.7185928821563721e-01
    z[0,1,3]  R160      8.5692560672760010e-01
    z[0,1,3]  R161      -6.7722752690315247e-02
    z[0,1,3]  R162      -1.6869744658470154e-01
    z[0,1,3]  R163      -1.0491450130939484e-01
    z[0,1,3]  R164      2.3639321327209473e-01
    z[0,1,3]  R165      -5.7837799191474915e-02
    z[0,1,3]  R166      -3.7720409035682678e-01
    z[0,1,3]  R167      -5.0152492523193359e-01
    z[0,1,3]  R168      -0.620127260684967
    z[0,1,3]  R169      -3.0619978904724121e-01
    z[0,1,3]  R170      -4.6318736672401428e-01
    z[0,1,3]  R171      -2.8145933151245117e-01
    z[0,1,3]  R172      -4.9411794543266296e-01
    z[0,1,3]  R173      -4.7303819656372070e-01
    z[0,1,3]  R174      -1.5031154453754425e-01
    z[0,1,3]  R175      -3.8023716211318970e-01
    z[0,1,3]  R176      4.0187767148017883e-01
    z[0,1,3]  R177      3.0618983507156372e-01
    z[0,1,3]  R178      1.4561046659946442e-01
    z[0,1,3]  R179      2.7717188000679016e-01
    z[0,1,3]  R180      3.1537401676177979e-01
    z[0,1,3]  R181      1.7669594287872314e-01
    z[0,1,3]  R182      2.2975522279739380e-01
    z[0,1,3]  R183      3.0813151597976685e-01
    z[0,1,3]  R184      1.8196175992488861e-01
    z[0,1,3]  R185      3.0411624908447266e-01
    z[0,1,3]  R186      -4.7513264417648315e-01
    z[0,1,3]  R187      -2.9910793900489807e-01
    z[0,1,3]  R188      -4.9415990710258484e-01
    z[0,1,3]  R189      -5.3595000505447388e-01
    z[0,1,3]  R190      -7.0295113325119019e-01
    z[0,1,3]  R191      6.3802433013916016e-01
    z[0,1,3]  R192      -5.2820432186126709e-01
    z[0,1,3]  R193      -7.0321941375732422e-01
    z[0,1,3]  R194      -1.1157199740409851e-01
    z[0,1,3]  R195      4.9584048986434937e-01
    z[0,1,3]  R196      6.3299578428268433e-01
    z[0,1,3]  R197      1.0616496205329895e-01
    z[0,1,3]  R198      2.5820401310920715e-01
    z[0,1,3]  R199      7.9184156656265259e-01
    z[0,1,3]  R200      -8.7833821773529053e-02
    z[0,1,3]  R201      -6.3290582038462162e-03
    z[0,1,3]  R202      3.8389280438423157e-01
    z[0,1,3]  R203      5.2608340978622437e-01
    z[0,1,3]  R204      3.3938249945640564e-01
    z[0,1,3]  R205      2.5562044978141785e-01
    z[0,1,3]  R206      -3.0140110850334167e-01
    z[0,1,3]  R207      -2.7371674776077271e-01
    z[0,1,3]  R208      -0.520424485206604
    z[0,1,3]  R209      5.7561047375202179e-02
    z[0,1,3]  R210      -1.3779722154140472e-01
    z[0,1,3]  R211      1.5111909806728363e-01
    z[0,1,3]  R212      7.1562141180038452e-01
    z[0,1,3]  R213      7.0563733577728271e-01
    z[0,1,3]  R214      6.9247573614120483e-01
    z[0,1,3]  R215      3.9864847064018250e-01
    z[0,1,3]  R216      8.6471486091613770e-01
    z[0,1,3]  R217      2.9924002289772034e-01
    z[0,1,3]  R218      9.8448902368545532e-02
    z[0,1,3]  R219      0.0271736029535532
    z[0,1,3]  R220      1.0608037561178207e-01
    z[0,1,3]  R221      1.6946910321712494e-01
    z[0,1,3]  R222      3.3247882127761841e-01
    z[0,1,3]  R223      0.596255898475647
    z[0,1,3]  R224      1.9995900988578796e-01
    z[0,1,3]  R225      2.9122719168663025e-01
    z[0,1,3]  R226      -1.0755251161754131e-02
    z[0,1,3]  R227      -7.1085256338119507e-01
    z[0,1,3]  R228      -7.3259377479553223e-01
    z[0,1,3]  R229      6.1649543046951294e-01
    z[0,1,3]  R230      3.1919321417808533e-01
    z[0,1,3]  R231      0.474653959274292
    z[0,1,3]  R232      5.7778173685073853e-01
    z[0,1,3]  R233      2.9399591684341431e-01
    z[0,1,3]  R234      5.8195346593856812e-01
    z[0,1,3]  R235      4.9630695581436157e-01
    z[0,1,3]  R236      6.5015846490859985e-01
    z[0,1,3]  R237      1.1039676517248154e-01
    z[0,1,3]  R238      4.3881908059120178e-01
    z[0,1,3]  R239      5.5209094285964966e-01
    z[0,1,3]  R240      5.9213083982467651e-01
    z[0,1,3]  R241      0.625938355922699
    z[0,1,3]  R242      6.1959064006805420e-01
    z[0,1,3]  R243      3.7651520967483521e-01
    z[0,1,3]  R244      -4.0214595198631287e-01
    z[0,1,3]  R245      3.4837007522583008e-01
    z[0,1,4]  R6        -1
    z[0,1,4]  R15       1
    z[0,1,4]  R100      -1
    z[0,1,4]  R101      1
    z[0,1,4]  R106      8.9604228734970093e-02
    z[0,1,4]  R107      -2.8744882345199585e-01
    z[0,1,4]  R108      2.0206996798515320e-01
    z[0,1,4]  R109      4.4445816427469254e-02
    z[0,1,4]  R110      5.0837200880050659e-01
    z[0,1,4]  R111      -4.3901059031486511e-01
    z[0,1,4]  R112      1.6942851245403290e-01
    z[0,1,4]  R113      -1.9649676978588104e-02
    z[0,1,4]  R114      4.6485564112663269e-01
    z[0,1,4]  R115      -3.1988048553466797e-01
    z[0,1,4]  R116      4.0406605601310730e-01
    z[0,1,4]  R117      -0.0986860916018486
    z[0,1,4]  R118      1.2505438923835754e-01
    z[0,1,4]  R119      -4.3657961487770081e-01
    z[0,1,4]  R120      2.2704254090785980e-01
    z[0,1,4]  R121      -1.2737950682640076e-01
    z[0,1,4]  R122      -1.2335945852100849e-02
    z[0,1,4]  R123      -1.8066802620887756e-01
    z[0,1,4]  R124      1.6324238479137421e-01
    z[0,1,4]  R125      6.8727836012840271e-02
    z[0,1,4]  R126      2.3454587161540985e-01
    z[0,1,4]  R127      5.1327306032180786e-01
    z[0,1,4]  R128      -1.1139550060033798e-01
    z[0,1,4]  R129      3.7365466356277466e-01
    z[0,1,4]  R130      1.5394628047943115e-01
    z[0,1,4]  R131      3.2040628790855408e-01
    z[0,1,4]  R132      3.3972853422164917e-01
    z[0,1,4]  R133      -6.4457327127456665e-02
    z[0,1,4]  R134      -2.8373605012893677e-01
    z[0,1,4]  R135      -3.2385626435279846e-01
    z[0,1,4]  R136      3.6158025264739990e-02
    z[0,1,4]  R137      2.8707557916641235e-01
    z[0,1,4]  R138      -2.1785897016525269e-01
    z[0,1,4]  R139      1.3910777866840363e-01
    z[0,1,4]  R140      -3.3459064364433289e-01
    z[0,1,4]  R141      -6.3165277242660522e-02
    z[0,1,4]  R142      -3.0165541172027588e-01
    z[0,1,4]  R143      3.2457414269447327e-01
    z[0,1,4]  R144      -6.5735457465052605e-03
    z[0,1,4]  R145      -4.6645230054855347e-01
    z[0,1,4]  R146      -2.1367374062538147e-01
    z[0,1,4]  R147      2.4187627434730530e-01
    z[0,1,4]  R148      0.53766930103302
    z[0,1,4]  R149      -3.9414870738983154e-01
    z[0,1,4]  R150      3.7524050474166870e-01
    z[0,1,4]  R151      -4.3254144489765167e-02
    z[0,1,4]  R152      -1.3490395247936249e-01
    z[0,1,4]  R153      -2.7130043506622314e-01
    z[0,1,4]  R154      -1.6369469463825226e-02
    z[0,1,4]  R155      8.4502868354320526e-02
    z[0,1,4]  R156      2.5334203243255615e-01
    z[0,1,4]  R157      -3.5510438680648804e-01
    z[0,1,4]  R158      -4.4641056656837463e-01
    z[0,1,4]  R159      1.5092290937900543e-02
    z[0,1,4]  R160      -2.3525262251496315e-02
    z[0,1,4]  R161      -0.0577346533536911
    z[0,1,4]  R162      6.4896240830421448e-02
    z[0,1,4]  R163      -1.4085040986537933e-01
    z[0,1,4]  R164      9.8788976669311523e-02
    z[0,1,4]  R165      -4.1376795619726181e-02
    z[0,1,4]  R166      -3.2421648502349854e-01
    z[0,1,4]  R167      -0.287641316652298
    z[0,1,4]  R168      -2.5535440444946289e-01
    z[0,1,4]  R169      -6.8725836277008057e-01
    z[0,1,4]  R170      1.0965451598167419e-01
    z[0,1,4]  R171      -8.6141265928745270e-02
    z[0,1,4]  R172      -3.9865094423294067e-01
    z[0,1,4]  R173      -1.8897384405136108e-01
    z[0,1,4]  R174      2.6522138714790344e-01
    z[0,1,4]  R175      1.8102388083934784e-01
    z[0,1,4]  R176      -7.8041076660156250e-02
    z[0,1,4]  R177      -2.4372771382331848e-01
    z[0,1,4]  R178      1.0159488767385483e-01
    z[0,1,4]  R179      3.1711183488368988e-02
    z[0,1,4]  R180      1.2975813448429108e-01
    z[0,1,4]  R181      3.6978356540203094e-02
    z[0,1,4]  R182      4.7158572822809219e-02
    z[0,1,4]  R183      -2.0836353302001953e-01
    z[0,1,4]  R184      -7.6501868665218353e-02
    z[0,1,4]  R185      -2.3105712607502937e-03
    z[0,1,4]  R186      -2.3320877552032471e-01
    z[0,1,4]  R187      -1.1149710416793823e-01
    z[0,1,4]  R188      1.9031253457069397e-01
    z[0,1,4]  R189      -2.6426789164543152e-01
    z[0,1,4]  R190      3.6705070734024048e-01
    z[0,1,4]  R191      3.2231593132019043e-01
    z[0,1,4]  R192      -1.2098166346549988e-01
    z[0,1,4]  R193      4.6424347907304764e-02
    z[0,1,4]  R194      -2.0061565935611725e-01
    z[0,1,4]  R195      -3.2303226180374622e-03
    z[0,1,4]  R196      -1.9778303802013397e-01
    z[0,1,4]  R197      2.3271875083446503e-01
    z[0,1,4]  R198      -2.0879207551479340e-01
    z[0,1,4]  R199      -1.4656364917755127e-01
    z[0,1,4]  R200      3.8150716572999954e-02
    z[0,1,4]  R201      1.2002401798963547e-01
    z[0,1,4]  R202      3.2161605358123779e-01
    z[0,1,4]  R203      4.0730339288711548e-01
    z[0,1,4]  R204      4.8944327980279922e-02
    z[0,1,4]  R205      3.6813560128211975e-01
    z[0,1,4]  R206      -1.9165527820587158e-01
    z[0,1,4]  R207      4.9533969163894653e-01
    z[0,1,4]  R208      3.0061343312263489e-01
    z[0,1,4]  R209      2.9962889850139618e-02
    z[0,1,4]  R210      4.4709322974085808e-03
    z[0,1,4]  R211      -1.3671702146530151e-01
    z[0,1,4]  R212      1.6357812285423279e-01
    z[0,1,4]  R213      1.9558621942996979e-01
    z[0,1,4]  R214      3.6986431479454041e-01
    z[0,1,4]  R215      2.1674321591854095e-01
    z[0,1,4]  R216      -4.2414046823978424e-02
    z[0,1,4]  R217      -1.7318703234195709e-02
    z[0,1,4]  R218      3.6371055245399475e-01
    z[0,1,4]  R219      4.8381996154785156e-01
    z[0,1,4]  R220      -3.2471738755702972e-02
    z[0,1,4]  R221      5.8499181270599365e-01
    z[0,1,4]  R222      4.3477073311805725e-01
    z[0,1,4]  R223      1.2443201988935471e-01
    z[0,1,4]  R224      1.5923465788364410e-01
    z[0,1,4]  R225      4.4488483667373657e-01
    z[0,1,4]  R226      -1.4953131973743439e-01
    z[0,1,4]  R227      6.2398705631494522e-02
    z[0,1,4]  R228      2.5058604776859283e-02
    z[0,1,4]  R229      -4.4366973638534546e-01
    z[0,1,4]  R230      2.5789496302604675e-01
    z[0,1,4]  R231      4.7080650925636292e-01
    z[0,1,4]  R232      -1.0918192565441132e-03
    z[0,1,4]  R233      -1.5598331391811371e-01
    z[0,1,4]  R234      4.9181395769119263e-01
    z[0,1,4]  R235      7.5598949193954468e-01
    z[0,1,4]  R236      -1.1459868401288986e-01
    z[0,1,4]  R237      -3.6937814950942993e-01
    z[0,1,4]  R238      3.9902281761169434e-01
    z[0,1,4]  R239      2.1089439094066620e-01
    z[0,1,4]  R240      3.0564457178115845e-01
    z[0,1,4]  R241      2.1205591037869453e-02
    z[0,1,4]  R242      6.6968256235122681e-01
    z[0,1,4]  R243      3.4454742074012756e-01
    z[0,1,4]  R244      4.2818868532776833e-03
    z[0,1,4]  R245      4.8093062639236450e-01
    z[0,1,5]  R7        -1
    z[0,1,5]  R16       1
    z[0,1,5]  R102      -1
    z[0,1,5]  R103      1
    z[0,1,5]  R106      1.2492982298135757e-01
    z[0,1,5]  R107      0.175779327750206
    z[0,1,5]  R108      3.8542658090591431e-02
    z[0,1,5]  R109      -5.6672483682632446e-01
    z[0,1,5]  R110      -5.7694405317306519e-01
    z[0,1,5]  R111      3.2612487673759460e-01
    z[0,1,5]  R112      -2.9808858036994934e-01
    z[0,1,5]  R113      -4.0076601505279541e-01
    z[0,1,5]  R114      -3.8645300269126892e-01
    z[0,1,5]  R115      1.7766506969928741e-01
    z[0,1,5]  R116      -1.6486328095197678e-02
    z[0,1,5]  R117      0.503727912902832
    z[0,1,5]  R118      0.0744536742568016
    z[0,1,5]  R119      -9.5156140625476837e-02
    z[0,1,5]  R120      1.6693204641342163e-01
    z[0,1,5]  R121      0.0472993366420269
    z[0,1,5]  R122      1.6686005890369415e-01
    z[0,1,5]  R123      1.1024153977632523e-01
    z[0,1,5]  R124      2.0623014867305756e-01
    z[0,1,5]  R125      6.2137570232152939e-02
    z[0,1,5]  R126      9.5437504351139069e-02
    z[0,1,5]  R127      -6.5168537199497223e-02
    z[0,1,5]  R128      2.6004728674888611e-01
    z[0,1,5]  R129      -5.0996005535125732e-01
    z[0,1,5]  R130      -8.8554620742797852e-02
    z[0,1,5]  R131      -2.4945183098316193e-01
    z[0,1,5]  R132      -1.1956793069839478e-01
    z[0,1,5]  R133      2.5355464220046997e-01
    z[0,1,5]  R134      -1.7481237649917603e-01
    z[0,1,5]  R135      1.9550228118896484e-01
    z[0,1,5]  R136      1.8047341704368591e-01
    z[0,1,5]  R137      -3.0346742272377014e-01
    z[0,1,5]  R138      -7.9076945781707764e-02
    z[0,1,5]  R139      -1.2368068844079971e-01
    z[0,1,5]  R140      -3.5012704133987427e-01
    z[0,1,5]  R141      -3.4012833237648010e-01
    z[0,1,5]  R142      7.3924213647842407e-02
    z[0,1,5]  R143      6.5081994980573654e-03
    z[0,1,5]  R144      3.1589362025260925e-01
    z[0,1,5]  R145      -1.6483667492866516e-01
    z[0,1,5]  R146      -7.4559226632118225e-02
    z[0,1,5]  R147      -5.8781629800796509e-01
    z[0,1,5]  R148      -3.9033353328704834e-01
    z[0,1,5]  R149      -5.8267004787921906e-02
    z[0,1,5]  R150      4.9076753854751587e-01
    z[0,1,5]  R151      0.244783416390419
    z[0,1,5]  R152      -2.7149847149848938e-01
    z[0,1,5]  R153      6.3544875383377075e-01
    z[0,1,5]  R154      -2.7017769217491150e-01
    z[0,1,5]  R155      3.8683155179023743e-01
    z[0,1,5]  R156      5.0349522382020950e-02
    z[0,1,5]  R157      9.5458760857582092e-02
    z[0,1,5]  R158      1.5454442799091339e-01
    z[0,1,5]  R159      -4.0873834490776062e-01
    z[0,1,5]  R160      2.3882275447249413e-02
    z[0,1,5]  R161      5.4946172237396240e-01
    z[0,1,5]  R162      2.4371053278446198e-01
    z[0,1,5]  R163      4.0685775876045227e-01
    z[0,1,5]  R164      2.0834033191204071e-01
    z[0,1,5]  R165      2.9766580462455750e-01
    z[0,1,5]  R166      -7.6462127268314362e-02
    z[0,1,5]  R167      3.5775130987167358e-01
    z[0,1,5]  R168      -5.0992354750633240e-02
    z[0,1,5]  R169      6.8135358393192291e-02
    z[0,1,5]  R170      4.2147073149681091e-01
    z[0,1,5]  R171      9.6685782074928284e-02
    z[0,1,5]  R172      2.4848919361829758e-02
    z[0,1,5]  R173      3.7973019480705261e-01
    z[0,1,5]  R174      -3.8027125597000122e-01
    z[0,1,5]  R175      -2.2399128973484039e-01
    z[0,1,5]  R176      1.3740417361259460e-01
    z[0,1,5]  R177      3.0534034967422485e-01
    z[0,1,5]  R178      3.5866221785545349e-01
    z[0,1,5]  R179      5.9211300686001778e-03
    z[0,1,5]  R180      -1.6443461179733276e-02
    z[0,1,5]  R181      2.0932057499885559e-01
    z[0,1,5]  R182      3.7273299694061279e-01
    z[0,1,5]  R183      2.1522977948188782e-01
    z[0,1,5]  R184      0.511130690574646
    z[0,1,5]  R185      3.6250913143157959e-01
    z[0,1,5]  R186      -0.648076057434082
    z[0,1,5]  R187      0.0657590702176094
    z[0,1,5]  R188      -2.9661828279495239e-01
    z[0,1,5]  R189      -7.6879158616065979e-02
    z[0,1,5]  R190      -2.1222910284996033e-01
    z[0,1,5]  R191      1.6392305493354797e-01
    z[0,1,5]  R192      -4.2393404245376587e-01
    z[0,1,5]  R193      -1.5759025514125824e-01
    z[0,1,5]  R194      -3.9872181415557861e-01
    z[0,1,5]  R195      7.0305779576301575e-02
    z[0,1,5]  R196      4.1900908946990967e-01
    z[0,1,5]  R197      1.4060950279235840e-01
    z[0,1,5]  R198      -4.0386593341827393e-01
    z[0,1,5]  R199      2.3328746855258942e-01
    z[0,1,5]  R200      1.4735272526741028e-01
    z[0,1,5]  R201      -1.0939425788819790e-02
    z[0,1,5]  R202      -2.9343429952859879e-02
    z[0,1,5]  R203      6.4921337366104126e-01
    z[0,1,5]  R204      5.4124879837036133e-01
    z[0,1,5]  R205      -2.0792341232299805e-01
    z[0,1,5]  R206      2.0585437119007111e-01
    z[0,1,5]  R207      -9.0375185012817383e-02
    z[0,1,5]  R208      -4.8706404864788055e-02
    z[0,1,5]  R209      -1.5952616930007935e-01
    z[0,1,5]  R210      -4.9883734434843063e-02
    z[0,1,5]  R211      -3.8910800218582153e-01
    z[0,1,5]  R212      4.2181101441383362e-01
    z[0,1,5]  R213      -1.6269692778587341e-01
    z[0,1,5]  R214      -1.3045889139175415e-01
    z[0,1,5]  R215      8.8567227125167847e-02
    z[0,1,5]  R216      3.1192660331726074e-01
    z[0,1,5]  R217      3.9336517453193665e-01
    z[0,1,5]  R218      2.0151710510253906e-01
    z[0,1,5]  R219      9.1979645192623138e-02
    z[0,1,5]  R220      -4.3433707207441330e-02
    z[0,1,5]  R221      -3.8120919466018677e-01
    z[0,1,5]  R222      -1.0739266127347946e-01
    z[0,1,5]  R223      1.6362212598323822e-01
    z[0,1,5]  R224      -3.6934378743171692e-01
    z[0,1,5]  R225      -4.7725012898445129e-01
    z[0,1,5]  R226      -0.523442268371582
    z[0,1,5]  R227      -2.9658830165863037e-01
    z[0,1,5]  R228      2.5670301169157028e-02
    z[0,1,5]  R229      8.1822425127029419e-02
    z[0,1,5]  R230      -6.0947993770241737e-03
    z[0,1,5]  R231      3.6438152194023132e-01
    z[0,1,5]  R232      -3.4555536508560181e-01
    z[0,1,5]  R233      -4.6714732050895691e-01
    z[0,1,5]  R234      1.2319060415029526e-01
    z[0,1,5]  R235      5.1724273711442947e-02
    z[0,1,5]  R236      2.0836119353771210e-01
    z[0,1,5]  R237      -2.1691080927848816e-01
    z[0,1,5]  R238      1.4422725141048431e-01
    z[0,1,5]  R239      -9.9152170121669769e-02
    z[0,1,5]  R240      -1.5527497231960297e-01
    z[0,1,5]  R241      3.7689003348350525e-01
    z[0,1,5]  R242      -8.8169820606708527e-02
    z[0,1,5]  R243      2.3336377739906311e-01
    z[0,1,5]  R244      -1.3693358004093170e-01
    z[0,1,5]  R245      4.8149690032005310e-02
    z[0,1,6]  R8        -1
    z[0,1,6]  R17       1
    z[0,1,6]  R104      -1
    z[0,1,6]  R105      1
    z[0,1,6]  R106      1.3191461563110352e-01
    z[0,1,6]  R107      0.0874442458152771
    z[0,1,6]  R108      -4.4186714291572571e-01
    z[0,1,6]  R109      -3.0732482671737671e-01
    z[0,1,6]  R110      -5.3932290524244308e-02
    z[0,1,6]  R111      -0.401030957698822
    z[0,1,6]  R112      -2.5396207347512245e-02
    z[0,1,6]  R113      -4.6218344569206238e-01
    z[0,1,6]  R114      -3.9516305923461914e-01
    z[0,1,6]  R115      -4.1228723526000977e-01
    z[0,1,6]  R116      3.7462085485458374e-01
    z[0,1,6]  R117      5.2376669645309448e-01
    z[0,1,6]  R118      -1.5266944468021393e-01
    z[0,1,6]  R119      2.0077311992645264e-01
    z[0,1,6]  R120      2.9434624314308167e-01
    z[0,1,6]  R121      0.16197469830513
    z[0,1,6]  R122      0.0212846789509058
    z[0,1,6]  R123      6.1095900833606720e-02
    z[0,1,6]  R124      -2.5218958035111427e-02
    z[0,1,6]  R125      -1.1041018366813660e-01
    z[0,1,6]  R126      1.9928197562694550e-01
    z[0,1,6]  R127      8.4426812827587128e-03
    z[0,1,6]  R128      -4.0857456624507904e-02
    z[0,1,6]  R129      0.0263714250177145
    z[0,1,6]  R130      -3.8630792498588562e-01
    z[0,1,6]  R131      -2.9359987378120422e-01
    z[0,1,6]  R132      -6.8870788812637329e-01
    z[0,1,6]  R133      5.9921962022781372e-01
    z[0,1,6]  R134      -3.0938610434532166e-02
    z[0,1,6]  R135      2.7243435382843018e-01
    z[0,1,6]  R136      -4.6066647768020630e-01
    z[0,1,6]  R137      -2.8735786676406860e-01
    z[0,1,6]  R138      -1.0418348759412766e-01
    z[0,1,6]  R139      3.6686885356903076e-01
    z[0,1,6]  R140      1.9505521282553673e-02
    z[0,1,6]  R141      5.7073158025741577e-01
    z[0,1,6]  R142      -1.5794268250465393e-01
    z[0,1,6]  R143      3.0939567089080811e-01
    z[0,1,6]  R144      2.5403586030006409e-01
    z[0,1,6]  R145      3.1916892528533936e-01
    z[0,1,6]  R146      2.3045334219932556e-01
    z[0,1,6]  R147      2.3487238585948944e-01
    z[0,1,6]  R148      1.5198100358247757e-02
    z[0,1,6]  R149      -1.3912385702133179e-01
    z[0,1,6]  R150      2.2606596350669861e-01
    z[0,1,6]  R151      2.0908632874488831e-01
    z[0,1,6]  R152      5.1905751228332520e-01
    z[0,1,6]  R153      -1.1375757306814194e-01
    z[0,1,6]  R154      3.3053648471832275e-01
    z[0,1,6]  R155      -1.7875127494335175e-01
    z[0,1,6]  R156      -1.7471471428871155e-01
    z[0,1,6]  R157      -3.0696097016334534e-01
    z[0,1,6]  R158      -1.4413294196128845e-01
    z[0,1,6]  R159      -1.9780771806836128e-02
    z[0,1,6]  R160      -4.2399564385414124e-01
    z[0,1,6]  R161      3.5136872529983521e-01
    z[0,1,6]  R162      2.3495469987392426e-01
    z[0,1,6]  R163      -0.0321926586329937
    z[0,1,6]  R164      5.2557539194822311e-02
    z[0,1,6]  R165      2.3745338618755341e-01
    z[0,1,6]  R166      -0.383847177028656
    z[0,1,6]  R167      2.1412980556488037e-01
    z[0,1,6]  R168      4.4229626655578613e-02
    z[0,1,6]  R169      -1.1348040401935577e-01
    z[0,1,6]  R170      -7.0780552923679352e-02
    z[0,1,6]  R171      2.3420266807079315e-01
    z[0,1,6]  R172      -3.5714048147201538e-01
    z[0,1,6]  R173      -4.1779378056526184e-01
    z[0,1,6]  R174      -9.8797872662544250e-02
    z[0,1,6]  R175      -2.7079728245735168e-01
    z[0,1,6]  R176      -2.8398019075393677e-01
    z[0,1,6]  R177      2.7448818087577820e-01
    z[0,1,6]  R178      -3.8419350981712341e-02
    z[0,1,6]  R179      9.7134284675121307e-02
    z[0,1,6]  R180      -2.4830566346645355e-01
    z[0,1,6]  R181      -1.3310468196868896e-01
    z[0,1,6]  R182      3.7576359510421753e-01
    z[0,1,6]  R183      -2.8193789720535278e-01
    z[0,1,6]  R184      4.6669259667396545e-02
    z[0,1,6]  R185      -4.4715738296508789e-01
    z[0,1,6]  R186      4.4310346245765686e-02
    z[0,1,6]  R187      1.8833646178245544e-01
    z[0,1,6]  R188      -0.0983353853225708
    z[0,1,6]  R189      1.8292682245373726e-02
    z[0,1,6]  R190      1.5415126085281372e-01
    z[0,1,6]  R191      1.4263746142387390e-01
    z[0,1,6]  R192      4.6091634035110474e-01
    z[0,1,6]  R193      3.7453049421310425e-01
    z[0,1,6]  R194      6.3131886720657349e-01
    z[0,1,6]  R195      -1.3046045601367950e-01
    z[0,1,6]  R196      7.2290033102035522e-02
    z[0,1,6]  R197      3.5995218157768250e-01
    z[0,1,6]  R198      1.5154068171977997e-01
    z[0,1,6]  R199      -1.5079037845134735e-01
    z[0,1,6]  R200      1.1484432965517044e-01
    z[0,1,6]  R201      -0.736470639705658
    z[0,1,6]  R202      5.0123695284128189e-02
    z[0,1,6]  R203      1.2904106080532074e-01
    z[0,1,6]  R204      7.2645372711122036e-03
    z[0,1,6]  R205      7.1147575974464417e-02
    z[0,1,6]  R206      3.2846489548683167e-01
    z[0,1,6]  R207      -1.5908074378967285e-01
    z[0,1,6]  R208      -4.5059084892272949e-01
    z[0,1,6]  R209      -3.3879649639129639e-01
    z[0,1,6]  R210      -3.3033692836761475e-01
    z[0,1,6]  R211      7.6765216886997223e-02
    z[0,1,6]  R212      -2.9396224021911621e-01
    z[0,1,6]  R213      4.3577242642641068e-02
    z[0,1,6]  R214      1.2319776415824890e-01
    z[0,1,6]  R215      -5.3875666856765747e-01
    z[0,1,6]  R216      8.8483437895774841e-02
    z[0,1,6]  R217      2.8057926893234253e-01
    z[0,1,6]  R218      -6.0776922851800919e-02
    z[0,1,6]  R219      3.0879381299018860e-01
    z[0,1,6]  R220      -3.5192728042602539e-01
    z[0,1,6]  R221      -2.6379138231277466e-01
    z[0,1,6]  R222      4.2512655258178711e-02
    z[0,1,6]  R223      -1.8563105165958405e-01
    z[0,1,6]  R224      3.3686894178390503e-01
    z[0,1,6]  R225      -9.7422868013381958e-02
    z[0,1,6]  R226      2.1099606156349182e-01
    z[0,1,6]  R227      2.7201318740844727e-01
    z[0,1,6]  R228      5.4628539085388184e-01
    z[0,1,6]  R229      5.2705843001604080e-02
    z[0,1,6]  R230      -8.0805547535419464e-02
    z[0,1,6]  R231      -3.9299684762954712e-01
    z[0,1,6]  R232      1.1600001901388168e-01
    z[0,1,6]  R233      1.1144879460334778e-01
    z[0,1,6]  R234      2.8317835927009583e-01
    z[0,1,6]  R235      2.0880098640918732e-01
    z[0,1,6]  R236      2.0675741136074066e-01
    z[0,1,6]  R237      4.8996829986572266e-01
    z[0,1,6]  R238      -2.7041694149374962e-02
    z[0,1,6]  R239      9.9062584340572357e-02
    z[0,1,6]  R240      -4.4209539890289307e-01
    z[0,1,6]  R241      -5.9952650219202042e-02
    z[0,1,6]  R242      2.1013806760311127e-01
    z[0,1,6]  R243      -3.7109214812517166e-02
    z[0,1,6]  R244      0.456543892621994
    z[0,1,6]  R245      3.6825588345527649e-01
    z[1,0,0]  R2        1
    z[1,0,0]  R11       -1
    z[1,0,0]  R246      -1
    z[1,0,0]  R247      1
    z[1,0,0]  R260      -6.5858542919158936e-01
    z[1,0,0]  R261      -6.5801924467086792e-01
    z[1,0,0]  R262      -7.1887493133544922e-01
    z[1,0,0]  R263      -4.1052407026290894e-01
    z[1,0,0]  R264      -7.1989625692367554e-01
    z[1,0,0]  R265      -0.59494549036026
    z[1,0,0]  R266      -5.6977653503417969e-01
    z[1,0,0]  R267      -6.3382625579833984e-01
    z[1,0,0]  R268      -0.820820689201355
    z[1,0,0]  R269      -0.791208803653717
    z[1,0,0]  R270      -1.5829540789127350e-01
    z[1,0,0]  R271      1.0571720451116562e-01
    z[1,0,0]  R272      9.0164765715599060e-02
    z[1,0,0]  R273      2.3170144855976105e-01
    z[1,0,0]  R274      1.9998101890087128e-01
    z[1,0,0]  R275      4.8847761750221252e-01
    z[1,0,0]  R276      2.9615685343742371e-01
    z[1,0,0]  R277      3.3222836256027222e-01
    z[1,0,0]  R278      3.5924544930458069e-01
    z[1,0,0]  R279      2.8316259384155273e-01
    z[1,0,0]  R280      4.6913135051727295e-01
    z[1,0,0]  R281      5.9548223018646240e-01
    z[1,0,0]  R282      5.5419504642486572e-01
    z[1,0,0]  R283      7.1332257986068726e-01
    z[1,0,0]  R284      0.413044273853302
    z[1,0,0]  R285      -4.1304641962051392e-01
    z[1,0,0]  R286      4.5895689725875854e-01
    z[1,0,0]  R287      5.3956449031829834e-01
    z[1,0,0]  R288      1.8347802758216858e-01
    z[1,0,0]  R289      8.0835449695587158e-01
    z[1,0,0]  R290      -2.6094338297843933e-01
    z[1,0,0]  R291      -1.0375731438398361e-01
    z[1,0,0]  R292      -1.1744309961795807e-01
    z[1,0,0]  R293      1.6161955893039703e-01
    z[1,0,0]  R294      4.5744961500167847e-01
    z[1,0,0]  R295      2.7871596813201904e-01
    z[1,0,0]  R296      2.7719014883041382e-01
    z[1,0,0]  R297      1.2179224193096161e-01
    z[1,0,0]  R298      -6.3695102930068970e-02
    z[1,0,0]  R299      0.629237711429596
    z[1,0,0]  R300      3.9095136523246765e-01
    z[1,0,0]  R301      3.6560770124197006e-02
    z[1,0,0]  R302      1.7770273983478546e-01
    z[1,0,0]  R303      1.4492644369602203e-01
    z[1,0,0]  R304      0.556480348110199
    z[1,0,0]  R305      5.0131708383560181e-01
    z[1,0,0]  R306      2.5523781776428223e-01
    z[1,0,0]  R307      -1.5742602944374084e-01
    z[1,0,0]  R308      4.6901664137840271e-01
    z[1,0,0]  R309      -0.0424308106303215
    z[1,0,0]  R310      2.9013910889625549e-01
    z[1,0,0]  R311      -2.6687833666801453e-01
    z[1,0,0]  R312      8.5017897188663483e-02
    z[1,0,0]  R313      -1.7064388096332550e-01
    z[1,0,0]  R314      7.6443380117416382e-01
    z[1,0,0]  R315      1.9689476490020752e-01
    z[1,0,0]  R316      8.2556062936782837e-01
    z[1,0,0]  R317      -1.2607698142528534e-01
    z[1,0,0]  R318      7.0532029867172241e-01
    z[1,0,0]  R319      0.554187536239624
    z[1,0,0]  R320      0.498337984085083
    z[1,0,0]  R321      1.3690540194511414e-01
    z[1,0,0]  R322      2.0153930783271790e-01
    z[1,0,0]  R323      3.8671070337295532e-01
    z[1,0,0]  R324      -7.6744019985198975e-02
    z[1,0,0]  R325      2.1289205551147461e-01
    z[1,0,0]  R326      -1.2130734324455261e-01
    z[1,0,0]  R327      4.4750612229108810e-02
    z[1,0,0]  R328      -1.3699607551097870e-01
    z[1,0,0]  R329      1.7185197770595551e-01
    z[1,0,0]  R330      3.0488875508308411e-01
    z[1,0,0]  R331      -2.1510450541973114e-01
    z[1,0,0]  R332      -4.6034038066864014e-01
    z[1,0,0]  R333      4.8502811789512634e-01
    z[1,0,0]  R334      3.1340980529785156e-01
    z[1,0,0]  R335      -3.1027961522340775e-02
    z[1,0,0]  R336      1.2311228550970554e-02
    z[1,0,0]  R337      6.5089219808578491e-01
    z[1,0,0]  R338      2.2151054814457893e-02
    z[1,0,0]  R339      6.4380139112472534e-01
    z[1,0,0]  R340      4.9490082263946533e-01
    z[1,0,0]  R341      4.1498789191246033e-01
    z[1,0,0]  R342      5.6200385093688965e-01
    z[1,0,0]  R343      -2.7195507287979126e-01
    z[1,0,0]  R344      -1.5923419594764709e-01
    z[1,0,0]  R345      1.1338619142770767e-01
    z[1,0,0]  R346      -5.6006636470556259e-02
    z[1,0,0]  R347      -2.2266621887683868e-01
    z[1,0,0]  R348      1.8465099856257439e-02
    z[1,0,0]  R349      6.4370214939117432e-02
    z[1,0,0]  R350      1.5307880938053131e-01
    z[1,0,0]  R351      7.3211260139942169e-02
    z[1,0,0]  R352      3.4881255030632019e-01
    z[1,0,0]  R353      -3.8617795705795288e-01
    z[1,0,0]  R354      -1.6033592820167542e-01
    z[1,0,0]  R355      -5.0186461210250854e-01
    z[1,0,0]  R356      -4.7637766599655151e-01
    z[1,0,0]  R357      -0.341469407081604
    z[1,0,0]  R358      -4.7362893819808960e-01
    z[1,0,0]  R359      -2.7223885059356689e-01
    z[1,0,0]  R360      2.4971213936805725e-01
    z[1,0,0]  R361      -6.0493912547826767e-02
    z[1,0,0]  R362      -0.0623035691678524
    z[1,0,0]  R363      1.6990311443805695e-02
    z[1,0,0]  R364      3.0292698740959167e-01
    z[1,0,0]  R365      -1.4488242566585541e-01
    z[1,0,0]  R366      2.6645186543464661e-01
    z[1,0,0]  R367      -1.6680526733398438e-01
    z[1,0,0]  R368      -6.0302621126174927e-01
    z[1,0,0]  R369      -4.7555884718894958e-01
    z[1,0,0]  R370      3.0833488702774048e-01
    z[1,0,0]  R371      3.6954346299171448e-01
    z[1,0,0]  R372      1.3853612542152405e-01
    z[1,0,0]  R373      1.1774213053286076e-02
    z[1,0,0]  R374      -3.4528955817222595e-01
    z[1,0,0]  R375      -0.51384037733078
    z[1,0,0]  R376      2.9657664895057678e-01
    z[1,0,0]  R377      3.4071081876754761e-01
    z[1,0,0]  R378      4.9104800820350647e-01
    z[1,0,0]  R379      -5.7003223896026611e-01
    z[1,0,0]  R380      -0.0688767358660698
    z[1,0,0]  R381      -4.3175253272056580e-01
    z[1,0,0]  R382      1.4744243025779724e-01
    z[1,0,0]  R383      -1.8172748386859894e-01
    z[1,0,0]  R384      6.0729360580444336e-01
    z[1,0,0]  R385      7.0505076646804810e-01
    z[1,0,0]  R386      -5.4727524518966675e-01
    z[1,0,0]  R387      6.3396120071411133e-01
    z[1,0,0]  R388      -4.9636000394821167e-01
    z[1,0,0]  R389      7.1425217390060425e-01
    z[1,0,0]  R390      2.8491258621215820e-01
    z[1,0,0]  R391      2.6955893635749817e-01
    z[1,0,0]  R392      1.4603634178638458e-01
    z[1,0,0]  R393      -6.4753681421279907e-02
    z[1,0,0]  R394      2.0705427229404449e-01
    z[1,0,0]  R395      4.6588051319122314e-01
    z[1,0,0]  R396      -6.0379576683044434e-01
    z[1,0,0]  R397      -7.6082962751388550e-01
    z[1,0,0]  R398      -7.6411402225494385e-01
    z[1,0,0]  R399      -8.1588953733444214e-01
    z[1,0,1]  R3        1
    z[1,0,1]  R12       -1
    z[1,0,1]  R248      -1
    z[1,0,1]  R249      1
    z[1,0,1]  R260      -1.8033710122108459e-01
    z[1,0,1]  R261      -2.2804026305675507e-01
    z[1,0,1]  R262      -6.2383204698562622e-02
    z[1,0,1]  R263      -2.5859877467155457e-01
    z[1,0,1]  R264      -9.5601566135883331e-02
    z[1,0,1]  R265      -1.7058271169662476e-01
    z[1,0,1]  R266      -1.5964622795581818e-01
    z[1,0,1]  R267      -1.4073713123798370e-01
    z[1,0,1]  R268      -2.7701035141944885e-01
    z[1,0,1]  R269      -1.3329532742500305e-01
    z[1,0,1]  R270      0.804551362991333
    z[1,0,1]  R271      8.0172097682952881e-01
    z[1,0,1]  R272      8.9155030250549316e-01
    z[1,0,1]  R273      8.1907963752746582e-01
    z[1,0,1]  R274      8.7900412082672119e-01
    z[1,0,1]  R275      8.1295800209045410e-01
    z[1,0,1]  R276      7.5687986612319946e-01
    z[1,0,1]  R277      7.5830638408660889e-01
    z[1,0,1]  R278      7.4715173244476318e-01
    z[1,0,1]  R279      7.0336920022964478e-01
    z[1,0,1]  R280      -2.7622026205062866e-01
    z[1,0,1]  R281      -3.9142203330993652e-01
    z[1,0,1]  R282      -0.248797208070755
    z[1,0,1]  R283      -2.4576936662197113e-01
    z[1,0,1]  R284      -2.1434900164604187e-01
    z[1,0,1]  R285      1.0257773846387863e-01
    z[1,0,1]  R286      -1.3534389436244965e-01
    z[1,0,1]  R287      -1.5342769026756287e-01
    z[1,0,1]  R288      -2.4239315092563629e-01
    z[1,0,1]  R289      1.2143120914697647e-01
    z[1,0,1]  R290      5.4998785257339478e-01
    z[1,0,1]  R291      -7.4844092130661011e-01
    z[1,0,1]  R292      -5.1669752597808838e-01
    z[1,0,1]  R293      2.8788894414901733e-01
    z[1,0,1]  R294      -7.5884765386581421e-01
    z[1,0,1]  R295      -5.1433372497558594e-01
    z[1,0,1]  R296      -5.9484966099262238e-02
    z[1,0,1]  R297      5.6977644562721252e-02
    z[1,0,1]  R298      -9.7424782812595367e-02
    z[1,0,1]  R299      3.4643688797950745e-01
    z[1,0,1]  R300      -7.4864143133163452e-01
    z[1,0,1]  R301      -7.6750653982162476e-01
    z[1,0,1]  R302      -0.63265460729599
    z[1,0,1]  R303      -7.0288920402526855e-01
    z[1,0,1]  R304      -6.0325086116790771e-01
    z[1,0,1]  R305      -6.3913995027542114e-01
    z[1,0,1]  R306      3.4777700901031494e-01
    z[1,0,1]  R307      1.0955148190259933e-01
    z[1,0,1]  R308      3.3840516209602356e-01
    z[1,0,1]  R309      2.0106829702854156e-01
    z[1,0,1]  R310      2.3183113336563110e-01
    z[1,0,1]  R311      4.2090049386024475e-01
    z[1,0,1]  R312      4.7850003838539124e-01
    z[1,0,1]  R313      5.1707899570465088e-01
    z[1,0,1]  R314      4.5963954925537109e-01
    z[1,0,1]  R315      2.8990250825881958e-01
    z[1,0,1]  R316      6.1392839998006821e-02
    z[1,0,1]  R317      -6.5599137544631958e-01
    z[1,0,1]  R318      4.3035867810249329e-01
    z[1,0,1]  R319      4.1396754980087280e-01
    z[1,0,1]  R320      -5.6772458553314209e-01
    z[1,0,1]  R321      -4.0542924404144287e-01
    z[1,0,1]  R322      -2.9511788487434387e-01
    z[1,0,1]  R323      4.9987000226974487e-01
    z[1,0,1]  R324      4.4165849685668945e-01
    z[1,0,1]  R325      4.4861632585525513e-01
    z[1,0,1]  R326      0.58297199010849
    z[1,0,1]  R327      -0.700998842716217
    z[1,0,1]  R328      2.2690226137638092e-01
    z[1,0,1]  R329      -0.0210583433508873
    z[1,0,1]  R330      6.1287569999694824e-01
    z[1,0,1]  R331      -7.1970504522323608e-01
    z[1,0,1]  R332      -5.1845723390579224e-01
    z[1,0,1]  R333      5.7428580522537231e-01
    z[1,0,1]  R334      3.9865252375602722e-01
    z[1,0,1]  R335      -2.9648298025131226e-01
    z[1,0,1]  R336      3.0242647975683212e-02
    z[1,0,1]  R337      1.9152933359146118e-01
    z[1,0,1]  R338      7.7534466981887817e-01
    z[1,0,1]  R339      2.0321662724018097e-01
    z[1,0,1]  R340      -2.3231776058673859e-01
    z[1,0,1]  R341      -4.2521899938583374e-01
    z[1,0,1]  R342      -2.8838777542114258e-01
    z[1,0,1]  R343      -2.9415807127952576e-01
    z[1,0,1]  R344      -1.8136461079120636e-01
    z[1,0,1]  R345      0.614677906036377
    z[1,0,1]  R346      8.8259148597717285e-01
    z[1,0,1]  R347      -1.2112042307853699e-01
    z[1,0,1]  R348      -2.1046364307403564e-01
    z[1,0,1]  R349      8.1843149662017822e-01
    z[1,0,1]  R350      1.2217903882265091e-01
    z[1,0,1]  R351      4.1422221064567566e-01
    z[1,0,1]  R352      -5.2835303544998169e-01
    z[1,0,1]  R353      -6.0785013437271118e-01
    z[1,0,1]  R354      2.9621484875679016e-01
    z[1,0,1]  R355      1.9389666616916656e-01
    z[1,0,1]  R356      -1.0692614316940308e-01
    z[1,0,1]  R357      3.5085476934909821e-02
    z[1,0,1]  R358      0.0629362165927887
    z[1,0,1]  R359      1.1717350780963898e-01
    z[1,0,1]  R360      4.6073517203330994e-01
    z[1,0,1]  R361      7.1917676925659180e-01
    z[1,0,1]  R362      5.5513072013854980e-01
    z[1,0,1]  R363      -5.3189247846603394e-01
    z[1,0,1]  R364      1.9663409888744354e-01
    z[1,0,1]  R365      0.213766410946846
    z[1,0,1]  R366      3.8322755694389343e-01
    z[1,0,1]  R367      6.5201544761657715e-01
    z[1,0,1]  R368      3.3321052789688110e-01
    z[1,0,1]  R369      6.9712668657302856e-01
    z[1,0,1]  R370      6.4458996057510376e-01
    z[1,0,1]  R371      -5.9066683053970337e-01
    z[1,0,1]  R372      -9.1286391019821167e-01
    z[1,0,1]  R373      -0.74636310338974
    z[1,0,1]  R374      -0.783897876739502
    z[1,0,1]  R375      -4.5693665742874146e-01
    z[1,0,1]  R376      -0.637538731098175
    z[1,0,1]  R377      -7.2442001104354858e-01
    z[1,0,1]  R378      -5.1696652173995972e-01
    z[1,0,1]  R379      1.1333186924457550e-01
    z[1,0,1]  R380      -6.8740415573120117e-01
    z[1,0,1]  R381      -5.5598491430282593e-01
    z[1,0,1]  R382      -7.0357513427734375e-01
    z[1,0,1]  R383      2.2914955019950867e-01
    z[1,0,1]  R384      3.8495090603828430e-01
    z[1,0,1]  R385      6.1672019958496094e-01
    z[1,0,1]  R386      1.0403732955455780e-01
    z[1,0,1]  R387      2.6857027783989906e-02
    z[1,0,1]  R388      3.9084741473197937e-01
    z[1,0,1]  R389      -1.0710010677576065e-01
    z[1,0,1]  R390      4.6051979064941406e-01
    z[1,0,1]  R391      -7.3174512386322021e-01
    z[1,0,1]  R392      -9.7263120114803314e-02
    z[1,0,1]  R393      -8.4369462728500366e-01
    z[1,0,1]  R394      1.1094018071889877e-01
    z[1,0,1]  R395      5.9087282419204712e-01
    z[1,0,1]  R396      -1.5158358030021191e-02
    z[1,0,1]  R397      -4.9962759017944336e-02
    z[1,0,1]  R398      -3.1675678491592407e-01
    z[1,0,1]  R399      -1.8333867192268372e-01
    z[1,0,2]  R4        1
    z[1,0,2]  R13       -1
    z[1,0,2]  R250      -1
    z[1,0,2]  R251      1
    z[1,0,2]  R260      3.6491009593009949e-01
    z[1,0,2]  R261      8.3101242780685425e-02
    z[1,0,2]  R262      1.5813589096069336e-01
    z[1,0,2]  R263      4.2543417215347290e-01
    z[1,0,2]  R264      2.5178456306457520e-01
    z[1,0,2]  R265      6.8271708488464355e-01
    z[1,0,2]  R266      -3.4442096948623657e-01
    z[1,0,2]  R267      -1.5313203446567059e-02
    z[1,0,2]  R268      4.7069203108549118e-02
    z[1,0,2]  R269      -2.3530335724353790e-01
    z[1,0,2]  R270      2.4600613117218018e-01
    z[1,0,2]  R271      1.5599825978279114e-01
    z[1,0,2]  R272      1.8806867301464081e-01
    z[1,0,2]  R273      4.3373140692710876e-01
    z[1,0,2]  R274      -9.5579192042350769e-02
    z[1,0,2]  R275      0.0797993540763855
    z[1,0,2]  R276      6.5456248819828033e-02
    z[1,0,2]  R277      -2.2454971075057983e-01
    z[1,0,2]  R278      1.0154710710048676e-01
    z[1,0,2]  R279      3.5156715661287308e-02
    z[1,0,2]  R280      3.8920834660530090e-02
    z[1,0,2]  R281      -5.9202855825424194e-01
    z[1,0,2]  R282      -5.0289428234100342e-01
    z[1,0,2]  R283      -2.5969842076301575e-01
    z[1,0,2]  R284      -2.9287990927696228e-01
    z[1,0,2]  R285      -5.1057970523834229e-01
    z[1,0,2]  R286      -2.9195931553840637e-01
    z[1,0,2]  R287      -1.5345829725265503e-01
    z[1,0,2]  R288      -5.4529237747192383e-01
    z[1,0,2]  R289      -2.5295522809028625e-01
    z[1,0,2]  R290      9.3944780528545380e-02
    z[1,0,2]  R291      -4.6293100714683533e-01
    z[1,0,2]  R292      -6.5030390024185181e-01
    z[1,0,2]  R293      4.0662553906440735e-01
    z[1,0,2]  R294      4.1330105066299438e-01
    z[1,0,2]  R295      -3.1752744317054749e-01
    z[1,0,2]  R296      -8.1574696302413940e-01
    z[1,0,2]  R297      3.1801056861877441e-01
    z[1,0,2]  R298      -7.5886243581771851e-01
    z[1,0,2]  R299      -4.8464578390121460e-01
    z[1,0,2]  R300      -9.4092048704624176e-02
    z[1,0,2]  R301      -2.3630566895008087e-01
    z[1,0,2]  R302      3.9439156651496887e-02
    z[1,0,2]  R303      -5.8352392911911011e-01
    z[1,0,2]  R304      -4.4249197840690613e-01
    z[1,0,2]  R305      -3.7597176432609558e-01
    z[1,0,2]  R306      -1.0341511666774750e-01
    z[1,0,2]  R307      -0.631401777267456
    z[1,0,2]  R308      -1.3033016026020050e-01
    z[1,0,2]  R309      -0.673624575138092
    z[1,0,2]  R310      8.6111530661582947e-02
    z[1,0,2]  R311      -6.5445655584335327e-01
    z[1,0,2]  R312      -7.5995332002639771e-01
    z[1,0,2]  R313      -0.604049563407898
    z[1,0,2]  R314      -2.5753778219223022e-01
    z[1,0,2]  R315      -5.3976607322692871e-01
    z[1,0,2]  R316      4.2098306119441986e-02
    z[1,0,2]  R317      3.4863191843032837e-01
    z[1,0,2]  R318      4.5605354011058807e-02
    z[1,0,2]  R319      -3.8888771086931229e-02
    z[1,0,2]  R320      -2.9725676774978638e-01
    z[1,0,2]  R321      3.8173702359199524e-01
    z[1,0,2]  R322      -1.8941754102706909e-01
    z[1,0,2]  R323      1.1917474865913391e-01
    z[1,0,2]  R324      -7.8999191522598267e-01
    z[1,0,2]  R325      1.3872574269771576e-01
    z[1,0,2]  R326      4.2276558279991150e-01
    z[1,0,2]  R327      4.0643098950386047e-01
    z[1,0,2]  R328      5.0381618738174438e-01
    z[1,0,2]  R329      -3.2543742656707764e-01
    z[1,0,2]  R330      9.7078546881675720e-02
    z[1,0,2]  R331      -2.7968008071184158e-03
    z[1,0,2]  R332      3.8206619024276733e-01
    z[1,0,2]  R333      -2.5693991780281067e-01
    z[1,0,2]  R334      2.8152132034301758e-01
    z[1,0,2]  R335      -6.1093878746032715e-01
    z[1,0,2]  R336      -3.3857741951942444e-01
    z[1,0,2]  R337      -0.472592294216156
    z[1,0,2]  R338      9.7093977034091949e-02
    z[1,0,2]  R339      -2.3159457743167877e-01
    z[1,0,2]  R340      -5.7488650083541870e-01
    z[1,0,2]  R341      -6.2625670433044434e-01
    z[1,0,2]  R342      -8.8665857911109924e-02
    z[1,0,2]  R343      -5.7745444774627686e-01
    z[1,0,2]  R344      -4.2030754685401917e-01
    z[1,0,2]  R345      -3.2679456472396851e-01
    z[1,0,2]  R346      2.3499237000942230e-01
    z[1,0,2]  R347      -2.5501725077629089e-01
    z[1,0,2]  R348      -6.5312135219573975e-01
    z[1,0,2]  R349      1.2549513578414917e-01
    z[1,0,2]  R350      -2.6208499073982239e-01
    z[1,0,2]  R351      3.5253354907035828e-01
    z[1,0,2]  R352      4.8182269930839539e-01
    z[1,0,2]  R353      3.8683211803436279e-01
    z[1,0,2]  R354      8.2693123817443848e-01
    z[1,0,2]  R355      8.0544006824493408e-01
    z[1,0,2]  R356      8.4311634302139282e-01
    z[1,0,2]  R357      8.9893138408660889e-01
    z[1,0,2]  R358      0.8321533203125
    z[1,0,2]  R359      9.1821324825286865e-01
    z[1,0,2]  R360      -7.1190494298934937e-01
    z[1,0,2]  R361      1.0455914773046970e-02
    z[1,0,2]  R362      2.5464800000190735e-01
    z[1,0,2]  R363      -5.5668348073959351e-01
    z[1,0,2]  R364      -0.676361620426178
    z[1,0,2]  R365      1.8518878519535065e-01
    z[1,0,2]  R366      -1.8845534324645996e-01
    z[1,0,2]  R367      -2.9361501336097717e-01
    z[1,0,2]  R368      1.4269612729549408e-02
    z[1,0,2]  R369      1.4455687999725342e-01
    z[1,0,2]  R370      -4.1292563080787659e-01
    z[1,0,2]  R371      -4.6847561001777649e-01
    z[1,0,2]  R372      2.1335519850254059e-01
    z[1,0,2]  R373      3.4986928105354309e-01
    z[1,0,2]  R374      -4.8542730510234833e-02
    z[1,0,2]  R375      -7.7823407948017120e-02
    z[1,0,2]  R376      -1.1915443092584610e-01
    z[1,0,2]  R377      3.6274176836013794e-01
    z[1,0,2]  R378      2.3225225508213043e-01
    z[1,0,2]  R379      -5.5932450294494629e-01
    z[1,0,2]  R380      1.0764485597610474e-01
    z[1,0,2]  R381      -8.8984228670597076e-02
    z[1,0,2]  R382      1.3610440492630005e-01
    z[1,0,2]  R383      -6.8699955940246582e-01
    z[1,0,2]  R384      1.8842889368534088e-01
    z[1,0,2]  R385      1.2623888254165649e-01
    z[1,0,2]  R386      -5.7087469100952148e-01
    z[1,0,2]  R387      2.1743780374526978e-01
    z[1,0,2]  R388      -6.2400847673416138e-01
    z[1,0,2]  R389      3.4387171268463135e-02
    z[1,0,2]  R390      -4.8959305882453918e-01
    z[1,0,2]  R391      2.3180879652500153e-01
    z[1,0,2]  R392      -4.3938422203063965e-01
    z[1,0,2]  R393      -2.0589542388916016e-01
    z[1,0,2]  R394      -1.7205569148063660e-01
    z[1,0,2]  R395      -2.3169048130512238e-02
    z[1,0,2]  R396      6.9852125644683838e-01
    z[1,0,2]  R397      0.470347136259079
    z[1,0,2]  R398      4.5164796710014343e-01
    z[1,0,2]  R399      3.8815578818321228e-01
    z[1,0,3]  R5        1
    z[1,0,3]  R14       -1
    z[1,0,3]  R252      -1
    z[1,0,3]  R253      1
    z[1,0,3]  R260      -3.7720409035682678e-01
    z[1,0,3]  R261      -5.0152492523193359e-01
    z[1,0,3]  R262      -0.620127260684967
    z[1,0,3]  R263      -3.0619978904724121e-01
    z[1,0,3]  R264      -4.6318736672401428e-01
    z[1,0,3]  R265      -2.8145933151245117e-01
    z[1,0,3]  R266      -4.9411794543266296e-01
    z[1,0,3]  R267      -4.7303819656372070e-01
    z[1,0,3]  R268      -1.5031154453754425e-01
    z[1,0,3]  R269      -3.8023716211318970e-01
    z[1,0,3]  R270      4.0187767148017883e-01
    z[1,0,3]  R271      3.0618983507156372e-01
    z[1,0,3]  R272      1.4561046659946442e-01
    z[1,0,3]  R273      2.7717188000679016e-01
    z[1,0,3]  R274      3.1537401676177979e-01
    z[1,0,3]  R275      1.7669594287872314e-01
    z[1,0,3]  R276      2.2975522279739380e-01
    z[1,0,3]  R277      3.0813151597976685e-01
    z[1,0,3]  R278      1.8196175992488861e-01
    z[1,0,3]  R279      3.0411624908447266e-01
    z[1,0,3]  R280      -4.7513264417648315e-01
    z[1,0,3]  R281      -2.9910793900489807e-01
    z[1,0,3]  R282      -4.9415990710258484e-01
    z[1,0,3]  R283      -5.3595000505447388e-01
    z[1,0,3]  R284      -7.0295113325119019e-01
    z[1,0,3]  R285      6.3802433013916016e-01
    z[1,0,3]  R286      -5.2820432186126709e-01
    z[1,0,3]  R287      -7.0321941375732422e-01
    z[1,0,3]  R288      -1.1157199740409851e-01
    z[1,0,3]  R289      4.9584048986434937e-01
    z[1,0,3]  R290      6.3299578428268433e-01
    z[1,0,3]  R291      1.0616496205329895e-01
    z[1,0,3]  R292      2.5820401310920715e-01
    z[1,0,3]  R293      7.9184156656265259e-01
    z[1,0,3]  R294      -8.7833821773529053e-02
    z[1,0,3]  R295      -6.3290582038462162e-03
    z[1,0,3]  R296      3.8389280438423157e-01
    z[1,0,3]  R297      5.2608340978622437e-01
    z[1,0,3]  R298      3.3938249945640564e-01
    z[1,0,3]  R299      2.5562044978141785e-01
    z[1,0,3]  R300      -3.0140110850334167e-01
    z[1,0,3]  R301      -2.7371674776077271e-01
    z[1,0,3]  R302      -0.520424485206604
    z[1,0,3]  R303      5.7561047375202179e-02
    z[1,0,3]  R304      -1.3779722154140472e-01
    z[1,0,3]  R305      1.5111909806728363e-01
    z[1,0,3]  R306      7.1562141180038452e-01
    z[1,0,3]  R307      7.0563733577728271e-01
    z[1,0,3]  R308      6.9247573614120483e-01
    z[1,0,3]  R309      3.9864847064018250e-01
    z[1,0,3]  R310      8.6471486091613770e-01
    z[1,0,3]  R311      2.9924002289772034e-01
    z[1,0,3]  R312      9.8448902368545532e-02
    z[1,0,3]  R313      0.0271736029535532
    z[1,0,3]  R314      1.0608037561178207e-01
    z[1,0,3]  R315      1.6946910321712494e-01
    z[1,0,3]  R316      3.3247882127761841e-01
    z[1,0,3]  R317      0.596255898475647
    z[1,0,3]  R318      1.9995900988578796e-01
    z[1,0,3]  R319      2.9122719168663025e-01
    z[1,0,3]  R320      -1.0755251161754131e-02
    z[1,0,3]  R321      -7.1085256338119507e-01
    z[1,0,3]  R322      -7.3259377479553223e-01
    z[1,0,3]  R323      6.1649543046951294e-01
    z[1,0,3]  R324      3.1919321417808533e-01
    z[1,0,3]  R325      0.474653959274292
    z[1,0,3]  R326      5.7778173685073853e-01
    z[1,0,3]  R327      2.9399591684341431e-01
    z[1,0,3]  R328      5.8195346593856812e-01
    z[1,0,3]  R329      4.9630695581436157e-01
    z[1,0,3]  R330      6.5015846490859985e-01
    z[1,0,3]  R331      1.1039676517248154e-01
    z[1,0,3]  R332      4.3881908059120178e-01
    z[1,0,3]  R333      5.5209094285964966e-01
    z[1,0,3]  R334      5.9213083982467651e-01
    z[1,0,3]  R335      0.625938355922699
    z[1,0,3]  R336      6.1959064006805420e-01
    z[1,0,3]  R337      3.7651520967483521e-01
    z[1,0,3]  R338      -4.0214595198631287e-01
    z[1,0,3]  R339      3.4837007522583008e-01
    z[1,0,3]  R340      -5.7408112287521362e-01
    z[1,0,3]  R341      -3.6551985144615173e-01
    z[1,0,3]  R342      -5.9628689289093018e-01
    z[1,0,3]  R343      -2.9741668701171875e-01
    z[1,0,3]  R344      -4.1337344050407410e-01
    z[1,0,3]  R345      2.0641303062438965e-01
    z[1,0,3]  R346      2.1087038516998291e-01
    z[1,0,3]  R347      -7.0434558391571045e-01
    z[1,0,3]  R348      8.4888547658920288e-02
    z[1,0,3]  R349      8.0051563680171967e-02
    z[1,0,3]  R350      7.6750802993774414e-01
    z[1,0,3]  R351      4.0120804309844971e-01
    z[1,0,3]  R352      5.6791716814041138e-01
    z[1,0,3]  R353      -3.0295112729072571e-01
    z[1,0,3]  R354      1.9151894748210907e-01
    z[1,0,3]  R355      1.3078117370605469e-01
    z[1,0,3]  R356      1.4946061372756958e-01
    z[1,0,3]  R357      0.159884512424469
    z[1,0,3]  R358      9.7060039639472961e-02
    z[1,0,3]  R359      2.1969486773014069e-01
    z[1,0,3]  R360      3.3871078491210938e-01
    z[1,0,3]  R361      4.5961785316467285e-01
    z[1,0,3]  R362      7.3579859733581543e-01
    z[1,0,3]  R363      8.0825246870517731e-02
    z[1,0,3]  R364      4.8096778988838196e-01
    z[1,0,3]  R365      8.0494147539138794e-01
    z[1,0,3]  R366      3.7761631608009338e-01
    z[1,0,3]  R367      1.8257418274879456e-01
    z[1,0,3]  R368      6.4273148775100708e-01
    z[1,0,3]  R369      2.2279354929924011e-01
    z[1,0,3]  R370      2.6987805962562561e-01
    z[1,0,3]  R371      1.9493977725505829e-01
    z[1,0,3]  R372      -1.9338284432888031e-01
    z[1,0,3]  R373      -0.388785719871521
    z[1,0,3]  R374      -1.7030143737792969e-01
    z[1,0,3]  R375      -2.7515235543251038e-01
    z[1,0,3]  R376      6.0826158523559570e-01
    z[1,0,3]  R377      1.6258460283279419e-01
    z[1,0,3]  R378      5.2279084920883179e-01
    z[1,0,3]  R379      -5.2511040121316910e-02
    z[1,0,3]  R380      -0.637824296951294
    z[1,0,3]  R381      -1.9327494502067566e-01
    z[1,0,3]  R382      -1.5178553760051727e-01
    z[1,0,3]  R383      5.1419204473495483e-01
    z[1,0,3]  R384      1.2139932811260223e-01
    z[1,0,3]  R385      3.3413335680961609e-02
    z[1,0,3]  R386      -4.9365319311618805e-02
    z[1,0,3]  R387      2.4444395303726196e-01
    z[1,0,3]  R388      -1.7017644643783569e-01
    z[1,0,3]  R389      5.3708422183990479e-01
    z[1,0,3]  R390      6.0811394453048706e-01
    z[1,0,3]  R391      -3.2972010970115662e-01
    z[1,0,3]  R392      7.2953003644943237e-01
    z[1,0,3]  R393      -2.7185928821563721e-01
    z[1,0,3]  R394      8.5692560672760010e-01
    z[1,0,3]  R395      -6.7722752690315247e-02
    z[1,0,3]  R396      -1.6869744658470154e-01
    z[1,0,3]  R397      -1.0491450130939484e-01
    z[1,0,3]  R398      2.3639321327209473e-01
    z[1,0,3]  R399      -5.7837799191474915e-02
    z[1,0,4]  R6        1
    z[1,0,4]  R15       -1
    z[1,0,4]  R254      -1
    z[1,0,4]  R255      1
    z[1,0,4]  R260      -3.2421648502349854e-01
    z[1,0,4]  R261      -0.287641316652298
    z[1,0,4]  R262      -2.5535440444946289e-01
    z[1,0,4]  R263      -6.8725836277008057e-01
    z[1,0,4]  R264      1.0965451598167419e-01
    z[1,0,4]  R265      -8.6141265928745270e-02
    z[1,0,4]  R266      -3.9865094423294067e-01
    z[1,0,4]  R267      -1.8897384405136108e-01
    z[1,0,4]  R268      2.6522138714790344e-01
    z[1,0,4]  R269      1.8102388083934784e-01
    z[1,0,4]  R270      -7.8041076660156250e-02
    z[1,0,4]  R271      -2.4372771382331848e-01
    z[1,0,4]  R272      1.0159488767385483e-01
    z[1,0,4]  R273      3.1711183488368988e-02
    z[1,0,4]  R274      1.2975813448429108e-01
    z[1,0,4]  R275      3.6978356540203094e-02
    z[1,0,4]  R276      4.7158572822809219e-02
    z[1,0,4]  R277      -2.0836353302001953e-01
    z[1,0,4]  R278      -7.6501868665218353e-02
    z[1,0,4]  R279      -2.3105712607502937e-03
    z[1,0,4]  R280      -2.3320877552032471e-01
    z[1,0,4]  R281      -1.1149710416793823e-01
    z[1,0,4]  R282      1.9031253457069397e-01
    z[1,0,4]  R283      -2.6426789164543152e-01
    z[1,0,4]  R284      3.6705070734024048e-01
    z[1,0,4]  R285      3.2231593132019043e-01
    z[1,0,4]  R286      -1.2098166346549988e-01
    z[1,0,4]  R287      4.6424347907304764e-02
    z[1,0,4]  R288      -2.0061565935611725e-01
    z[1,0,4]  R289      -3.2303226180374622e-03
    z[1,0,4]  R290      -1.9778303802013397e-01
    z[1,0,4]  R291      2.3271875083446503e-01
    z[1,0,4]  R292      -2.0879207551479340e-01
    z[1,0,4]  R293      -1.4656364917755127e-01
    z[1,0,4]  R294      3.8150716572999954e-02
    z[1,0,4]  R295      1.2002401798963547e-01
    z[1,0,4]  R296      3.2161605358123779e-01
    z[1,0,4]  R297      4.0730339288711548e-01
    z[1,0,4]  R298      4.8944327980279922e-02
    z[1,0,4]  R299      3.6813560128211975e-01
    z[1,0,4]  R300      -1.9165527820587158e-01
    z[1,0,4]  R301      4.9533969163894653e-01
    z[1,0,4]  R302      3.0061343312263489e-01
    z[1,0,4]  R303      2.9962889850139618e-02
    z[1,0,4]  R304      4.4709322974085808e-03
    z[1,0,4]  R305      -1.3671702146530151e-01
    z[1,0,4]  R306      1.6357812285423279e-01
    z[1,0,4]  R307      1.9558621942996979e-01
    z[1,0,4]  R308      3.6986431479454041e-01
    z[1,0,4]  R309      2.1674321591854095e-01
    z[1,0,4]  R310      -4.2414046823978424e-02
    z[1,0,4]  R311      -1.7318703234195709e-02
    z[1,0,4]  R312      3.6371055245399475e-01
    z[1,0,4]  R313      4.8381996154785156e-01
    z[1,0,4]  R314      -3.2471738755702972e-02
    z[1,0,4]  R315      5.8499181270599365e-01
    z[1,0,4]  R316      4.3477073311805725e-01
    z[1,0,4]  R317      1.2443201988935471e-01
    z[1,0,4]  R318      1.5923465788364410e-01
    z[1,0,4]  R319      4.4488483667373657e-01
    z[1,0,4]  R320      -1.4953131973743439e-01
    z[1,0,4]  R321      6.2398705631494522e-02
    z[1,0,4]  R322      2.5058604776859283e-02
    z[1,0,4]  R323      -4.4366973638534546e-01
    z[1,0,4]  R324      2.5789496302604675e-01
    z[1,0,4]  R325      4.7080650925636292e-01
    z[1,0,4]  R326      -1.0918192565441132e-03
    z[1,0,4]  R327      -1.5598331391811371e-01
    z[1,0,4]  R328      4.9181395769119263e-01
    z[1,0,4]  R329      7.5598949193954468e-01
    z[1,0,4]  R330      -1.1459868401288986e-01
    z[1,0,4]  R331      -3.6937814950942993e-01
    z[1,0,4]  R332      3.9902281761169434e-01
    z[1,0,4]  R333      2.1089439094066620e-01
    z[1,0,4]  R334      3.0564457178115845e-01
    z[1,0,4]  R335      2.1205591037869453e-02
    z[1,0,4]  R336      6.6968256235122681e-01
    z[1,0,4]  R337      3.4454742074012756e-01
    z[1,0,4]  R338      4.2818868532776833e-03
    z[1,0,4]  R339      4.8093062639236450e-01
    z[1,0,4]  R340      8.9604228734970093e-02
    z[1,0,4]  R341      -2.8744882345199585e-01
    z[1,0,4]  R342      2.0206996798515320e-01
    z[1,0,4]  R343      4.4445816427469254e-02
    z[1,0,4]  R344      5.0837200880050659e-01
    z[1,0,4]  R345      -4.3901059031486511e-01
    z[1,0,4]  R346      1.6942851245403290e-01
    z[1,0,4]  R347      -1.9649676978588104e-02
    z[1,0,4]  R348      4.6485564112663269e-01
    z[1,0,4]  R349      -3.1988048553466797e-01
    z[1,0,4]  R350      4.0406605601310730e-01
    z[1,0,4]  R351      -0.0986860916018486
    z[1,0,4]  R352      1.2505438923835754e-01
    z[1,0,4]  R353      -4.3657961487770081e-01
    z[1,0,4]  R354      2.2704254090785980e-01
    z[1,0,4]  R355      -1.2737950682640076e-01
    z[1,0,4]  R356      -1.2335945852100849e-02
    z[1,0,4]  R357      -1.8066802620887756e-01
    z[1,0,4]  R358      1.6324238479137421e-01
    z[1,0,4]  R359      6.8727836012840271e-02
    z[1,0,4]  R360      2.3454587161540985e-01
    z[1,0,4]  R361      5.1327306032180786e-01
    z[1,0,4]  R362      -1.1139550060033798e-01
    z[1,0,4]  R363      3.7365466356277466e-01
    z[1,0,4]  R364      1.5394628047943115e-01
    z[1,0,4]  R365      3.2040628790855408e-01
    z[1,0,4]  R366      3.3972853422164917e-01
    z[1,0,4]  R367      -6.4457327127456665e-02
    z[1,0,4]  R368      -2.8373605012893677e-01
    z[1,0,4]  R369      -3.2385626435279846e-01
    z[1,0,4]  R370      3.6158025264739990e-02
    z[1,0,4]  R371      2.8707557916641235e-01
    z[1,0,4]  R372      -2.1785897016525269e-01
    z[1,0,4]  R373      1.3910777866840363e-01
    z[1,0,4]  R374      -3.3459064364433289e-01
    z[1,0,4]  R375      -6.3165277242660522e-02
    z[1,0,4]  R376      -3.0165541172027588e-01
    z[1,0,4]  R377      3.2457414269447327e-01
    z[1,0,4]  R378      -6.5735457465052605e-03
    z[1,0,4]  R379      -4.6645230054855347e-01
    z[1,0,4]  R380      -2.1367374062538147e-01
    z[1,0,4]  R381      2.4187627434730530e-01
    z[1,0,4]  R382      0.53766930103302
    z[1,0,4]  R383      -3.9414870738983154e-01
    z[1,0,4]  R384      3.7524050474166870e-01
    z[1,0,4]  R385      -4.3254144489765167e-02
    z[1,0,4]  R386      -1.3490395247936249e-01
    z[1,0,4]  R387      -2.7130043506622314e-01
    z[1,0,4]  R388      -1.6369469463825226e-02
    z[1,0,4]  R389      8.4502868354320526e-02
    z[1,0,4]  R390      2.5334203243255615e-01
    z[1,0,4]  R391      -3.5510438680648804e-01
    z[1,0,4]  R392      -4.4641056656837463e-01
    z[1,0,4]  R393      1.5092290937900543e-02
    z[1,0,4]  R394      -2.3525262251496315e-02
    z[1,0,4]  R395      -0.0577346533536911
    z[1,0,4]  R396      6.4896240830421448e-02
    z[1,0,4]  R397      -1.4085040986537933e-01
    z[1,0,4]  R398      9.8788976669311523e-02
    z[1,0,4]  R399      -4.1376795619726181e-02
    z[1,0,5]  R7        1
    z[1,0,5]  R16       -1
    z[1,0,5]  R256      -1
    z[1,0,5]  R257      1
    z[1,0,5]  R260      -7.6462127268314362e-02
    z[1,0,5]  R261      3.5775130987167358e-01
    z[1,0,5]  R262      -5.0992354750633240e-02
    z[1,0,5]  R263      6.8135358393192291e-02
    z[1,0,5]  R264      4.2147073149681091e-01
    z[1,0,5]  R265      9.6685782074928284e-02
    z[1,0,5]  R266      2.4848919361829758e-02
    z[1,0,5]  R267      3.7973019480705261e-01
    z[1,0,5]  R268      -3.8027125597000122e-01
    z[1,0,5]  R269      -2.2399128973484039e-01
    z[1,0,5]  R270      1.3740417361259460e-01
    z[1,0,5]  R271      3.0534034967422485e-01
    z[1,0,5]  R272      3.5866221785545349e-01
    z[1,0,5]  R273      5.9211300686001778e-03
    z[1,0,5]  R274      -1.6443461179733276e-02
    z[1,0,5]  R275      2.0932057499885559e-01
    z[1,0,5]  R276      3.7273299694061279e-01
    z[1,0,5]  R277      2.1522977948188782e-01
    z[1,0,5]  R278      0.511130690574646
    z[1,0,5]  R279      3.6250913143157959e-01
    z[1,0,5]  R280      -0.648076057434082
    z[1,0,5]  R281      0.0657590702176094
    z[1,0,5]  R282      -2.9661828279495239e-01
    z[1,0,5]  R283      -7.6879158616065979e-02
    z[1,0,5]  R284      -2.1222910284996033e-01
    z[1,0,5]  R285      1.6392305493354797e-01
    z[1,0,5]  R286      -4.2393404245376587e-01
    z[1,0,5]  R287      -1.5759025514125824e-01
    z[1,0,5]  R288      -3.9872181415557861e-01
    z[1,0,5]  R289      7.0305779576301575e-02
    z[1,0,5]  R290      4.1900908946990967e-01
    z[1,0,5]  R291      1.4060950279235840e-01
    z[1,0,5]  R292      -4.0386593341827393e-01
    z[1,0,5]  R293      2.3328746855258942e-01
    z[1,0,5]  R294      1.4735272526741028e-01
    z[1,0,5]  R295      -1.0939425788819790e-02
    z[1,0,5]  R296      -2.9343429952859879e-02
    z[1,0,5]  R297      6.4921337366104126e-01
    z[1,0,5]  R298      5.4124879837036133e-01
    z[1,0,5]  R299      -2.0792341232299805e-01
    z[1,0,5]  R300      2.0585437119007111e-01
    z[1,0,5]  R301      -9.0375185012817383e-02
    z[1,0,5]  R302      -4.8706404864788055e-02
    z[1,0,5]  R303      -1.5952616930007935e-01
    z[1,0,5]  R304      -4.9883734434843063e-02
    z[1,0,5]  R305      -3.8910800218582153e-01
    z[1,0,5]  R306      4.2181101441383362e-01
    z[1,0,5]  R307      -1.6269692778587341e-01
    z[1,0,5]  R308      -1.3045889139175415e-01
    z[1,0,5]  R309      8.8567227125167847e-02
    z[1,0,5]  R310      3.1192660331726074e-01
    z[1,0,5]  R311      3.9336517453193665e-01
    z[1,0,5]  R312      2.0151710510253906e-01
    z[1,0,5]  R313      9.1979645192623138e-02
    z[1,0,5]  R314      -4.3433707207441330e-02
    z[1,0,5]  R315      -3.8120919466018677e-01
    z[1,0,5]  R316      -1.0739266127347946e-01
    z[1,0,5]  R317      1.6362212598323822e-01
    z[1,0,5]  R318      -3.6934378743171692e-01
    z[1,0,5]  R319      -4.7725012898445129e-01
    z[1,0,5]  R320      -0.523442268371582
    z[1,0,5]  R321      -2.9658830165863037e-01
    z[1,0,5]  R322      2.5670301169157028e-02
    z[1,0,5]  R323      8.1822425127029419e-02
    z[1,0,5]  R324      -6.0947993770241737e-03
    z[1,0,5]  R325      3.6438152194023132e-01
    z[1,0,5]  R326      -3.4555536508560181e-01
    z[1,0,5]  R327      -4.6714732050895691e-01
    z[1,0,5]  R328      1.2319060415029526e-01
    z[1,0,5]  R329      5.1724273711442947e-02
    z[1,0,5]  R330      2.0836119353771210e-01
    z[1,0,5]  R331      -2.1691080927848816e-01
    z[1,0,5]  R332      1.4422725141048431e-01
    z[1,0,5]  R333      -9.9152170121669769e-02
    z[1,0,5]  R334      -1.5527497231960297e-01
    z[1,0,5]  R335      3.7689003348350525e-01
    z[1,0,5]  R336      -8.8169820606708527e-02
    z[1,0,5]  R337      2.3336377739906311e-01
    z[1,0,5]  R338      -1.3693358004093170e-01
    z[1,0,5]  R339      4.8149690032005310e-02
    z[1,0,5]  R340      1.2492982298135757e-01
    z[1,0,5]  R341      0.175779327750206
    z[1,0,5]  R342      3.8542658090591431e-02
    z[1,0,5]  R343      -5.6672483682632446e-01
    z[1,0,5]  R344      -5.7694405317306519e-01
    z[1,0,5]  R345      3.2612487673759460e-01
    z[1,0,5]  R346      -2.9808858036994934e-01
    z[1,0,5]  R347      -4.0076601505279541e-01
    z[1,0,5]  R348      -3.8645300269126892e-01
    z[1,0,5]  R349      1.7766506969928741e-01
    z[1,0,5]  R350      -1.6486328095197678e-02
    z[1,0,5]  R351      0.503727912902832
    z[1,0,5]  R352      0.0744536742568016
    z[1,0,5]  R353      -9.5156140625476837e-02
    z[1,0,5]  R354      1.6693204641342163e-01
    z[1,0,5]  R355      0.0472993366420269
    z[1,0,5]  R356      1.6686005890369415e-01
    z[1,0,5]  R357      1.1024153977632523e-01
    z[1,0,5]  R358      2.0623014867305756e-01
    z[1,0,5]  R359      6.2137570232152939e-02
    z[1,0,5]  R360      9.5437504351139069e-02
    z[1,0,5]  R361      -6.5168537199497223e-02
    z[1,0,5]  R362      2.6004728674888611e-01
    z[1,0,5]  R363      -5.0996005535125732e-01
    z[1,0,5]  R364      -8.8554620742797852e-02
    z[1,0,5]  R365      -2.4945183098316193e-01
    z[1,0,5]  R366      -1.1956793069839478e-01
    z[1,0,5]  R367      2.5355464220046997e-01
    z[1,0,5]  R368      -1.7481237649917603e-01
    z[1,0,5]  R369      1.9550228118896484e-01
    z[1,0,5]  R370      1.8047341704368591e-01
    z[1,0,5]  R371      -3.0346742272377014e-01
    z[1,0,5]  R372      -7.9076945781707764e-02
    z[1,0,5]  R373      -1.2368068844079971e-01
    z[1,0,5]  R374      -3.5012704133987427e-01
    z[1,0,5]  R375      -3.4012833237648010e-01
    z[1,0,5]  R376      7.3924213647842407e-02
    z[1,0,5]  R377      6.5081994980573654e-03
    z[1,0,5]  R378      3.1589362025260925e-01
    z[1,0,5]  R379      -1.6483667492866516e-01
    z[1,0,5]  R380      -7.4559226632118225e-02
    z[1,0,5]  R381      -5.8781629800796509e-01
    z[1,0,5]  R382      -3.9033353328704834e-01
    z[1,0,5]  R383      -5.8267004787921906e-02
    z[1,0,5]  R384      4.9076753854751587e-01
    z[1,0,5]  R385      0.244783416390419
    z[1,0,5]  R386      -2.7149847149848938e-01
    z[1,0,5]  R387      6.3544875383377075e-01
    z[1,0,5]  R388      -2.7017769217491150e-01
    z[1,0,5]  R389      3.8683155179023743e-01
    z[1,0,5]  R390      5.0349522382020950e-02
    z[1,0,5]  R391      9.5458760857582092e-02
    z[1,0,5]  R392      1.5454442799091339e-01
    z[1,0,5]  R393      -4.0873834490776062e-01
    z[1,0,5]  R394      2.3882275447249413e-02
    z[1,0,5]  R395      5.4946172237396240e-01
    z[1,0,5]  R396      2.4371053278446198e-01
    z[1,0,5]  R397      4.0685775876045227e-01
    z[1,0,5]  R398      2.0834033191204071e-01
    z[1,0,5]  R399      2.9766580462455750e-01
    z[1,0,6]  R8        1
    z[1,0,6]  R17       -1
    z[1,0,6]  R258      -1
    z[1,0,6]  R259      1
    z[1,0,6]  R260      -0.383847177028656
    z[1,0,6]  R261      2.1412980556488037e-01
    z[1,0,6]  R262      4.4229626655578613e-02
    z[1,0,6]  R263      -1.1348040401935577e-01
    z[1,0,6]  R264      -7.0780552923679352e-02
    z[1,0,6]  R265      2.3420266807079315e-01
    z[1,0,6]  R266      -3.5714048147201538e-01
    z[1,0,6]  R267      -4.1779378056526184e-01
    z[1,0,6]  R268      -9.8797872662544250e-02
    z[1,0,6]  R269      -2.7079728245735168e-01
    z[1,0,6]  R270      -2.8398019075393677e-01
    z[1,0,6]  R271      2.7448818087577820e-01
    z[1,0,6]  R272      -3.8419350981712341e-02
    z[1,0,6]  R273      9.7134284675121307e-02
    z[1,0,6]  R274      -2.4830566346645355e-01
    z[1,0,6]  R275      -1.3310468196868896e-01
    z[1,0,6]  R276      3.7576359510421753e-01
    z[1,0,6]  R277      -2.8193789720535278e-01
    z[1,0,6]  R278      4.6669259667396545e-02
    z[1,0,6]  R279      -4.4715738296508789e-01
    z[1,0,6]  R280      4.4310346245765686e-02
    z[1,0,6]  R281      1.8833646178245544e-01
    z[1,0,6]  R282      -0.0983353853225708
    z[1,0,6]  R283      1.8292682245373726e-02
    z[1,0,6]  R284      1.5415126085281372e-01
    z[1,0,6]  R285      1.4263746142387390e-01
    z[1,0,6]  R286      4.6091634035110474e-01
    z[1,0,6]  R287      3.7453049421310425e-01
    z[1,0,6]  R288      6.3131886720657349e-01
    z[1,0,6]  R289      -1.3046045601367950e-01
    z[1,0,6]  R290      7.2290033102035522e-02
    z[1,0,6]  R291      3.5995218157768250e-01
    z[1,0,6]  R292      1.5154068171977997e-01
    z[1,0,6]  R293      -1.5079037845134735e-01
    z[1,0,6]  R294      1.1484432965517044e-01
    z[1,0,6]  R295      -0.736470639705658
    z[1,0,6]  R296      5.0123695284128189e-02
    z[1,0,6]  R297      1.2904106080532074e-01
    z[1,0,6]  R298      7.2645372711122036e-03
    z[1,0,6]  R299      7.1147575974464417e-02
    z[1,0,6]  R300      3.2846489548683167e-01
    z[1,0,6]  R301      -1.5908074378967285e-01
    z[1,0,6]  R302      -4.5059084892272949e-01
    z[1,0,6]  R303      -3.3879649639129639e-01
    z[1,0,6]  R304      -3.3033692836761475e-01
    z[1,0,6]  R305      7.6765216886997223e-02
    z[1,0,6]  R306      -2.9396224021911621e-01
    z[1,0,6]  R307      4.3577242642641068e-02
    z[1,0,6]  R308      1.2319776415824890e-01
    z[1,0,6]  R309      -5.3875666856765747e-01
    z[1,0,6]  R310      8.8483437895774841e-02
    z[1,0,6]  R311      2.8057926893234253e-01
    z[1,0,6]  R312      -6.0776922851800919e-02
    z[1,0,6]  R313      3.0879381299018860e-01
    z[1,0,6]  R314      -3.5192728042602539e-01
    z[1,0,6]  R315      -2.6379138231277466e-01
    z[1,0,6]  R316      4.2512655258178711e-02
    z[1,0,6]  R317      -1.8563105165958405e-01
    z[1,0,6]  R318      3.3686894178390503e-01
    z[1,0,6]  R319      -9.7422868013381958e-02
    z[1,0,6]  R320      2.1099606156349182e-01
    z[1,0,6]  R321      2.7201318740844727e-01
    z[1,0,6]  R322      5.4628539085388184e-01
    z[1,0,6]  R323      5.2705843001604080e-02
    z[1,0,6]  R324      -8.0805547535419464e-02
    z[1,0,6]  R325      -3.9299684762954712e-01
    z[1,0,6]  R326      1.1600001901388168e-01
    z[1,0,6]  R327      1.1144879460334778e-01
    z[1,0,6]  R328      2.8317835927009583e-01
    z[1,0,6]  R329      2.0880098640918732e-01
    z[1,0,6]  R330      2.0675741136074066e-01
    z[1,0,6]  R331      4.8996829986572266e-01
    z[1,0,6]  R332      -2.7041694149374962e-02
    z[1,0,6]  R333      9.9062584340572357e-02
    z[1,0,6]  R334      -4.4209539890289307e-01
    z[1,0,6]  R335      -5.9952650219202042e-02
    z[1,0,6]  R336      2.1013806760311127e-01
    z[1,0,6]  R337      -3.7109214812517166e-02
    z[1,0,6]  R338      0.456543892621994
    z[1,0,6]  R339      3.6825588345527649e-01
    z[1,0,6]  R340      1.3191461563110352e-01
    z[1,0,6]  R341      0.0874442458152771
    z[1,0,6]  R342      -4.4186714291572571e-01
    z[1,0,6]  R343      -3.0732482671737671e-01
    z[1,0,6]  R344      -5.3932290524244308e-02
    z[1,0,6]  R345      -0.401030957698822
    z[1,0,6]  R346      -2.5396207347512245e-02
    z[1,0,6]  R347      -4.6218344569206238e-01
    z[1,0,6]  R348      -3.9516305923461914e-01
    z[1,0,6]  R349      -4.1228723526000977e-01
    z[1,0,6]  R350      3.7462085485458374e-01
    z[1,0,6]  R351      5.2376669645309448e-01
    z[1,0,6]  R352      -1.5266944468021393e-01
    z[1,0,6]  R353      2.0077311992645264e-01
    z[1,0,6]  R354      2.9434624314308167e-01
    z[1,0,6]  R355      0.16197469830513
    z[1,0,6]  R356      0.0212846789509058
    z[1,0,6]  R357      6.1095900833606720e-02
    z[1,0,6]  R358      -2.5218958035111427e-02
    z[1,0,6]  R359      -1.1041018366813660e-01
    z[1,0,6]  R360      1.9928197562694550e-01
    z[1,0,6]  R361      8.4426812827587128e-03
    z[1,0,6]  R362      -4.0857456624507904e-02
    z[1,0,6]  R363      0.0263714250177145
    z[1,0,6]  R364      -3.8630792498588562e-01
    z[1,0,6]  R365      -2.9359987378120422e-01
    z[1,0,6]  R366      -6.8870788812637329e-01
    z[1,0,6]  R367      5.9921962022781372e-01
    z[1,0,6]  R368      -3.0938610434532166e-02
    z[1,0,6]  R369      2.7243435382843018e-01
    z[1,0,6]  R370      -4.6066647768020630e-01
    z[1,0,6]  R371      -2.8735786676406860e-01
    z[1,0,6]  R372      -1.0418348759412766e-01
    z[1,0,6]  R373      3.6686885356903076e-01
    z[1,0,6]  R374      1.9505521282553673e-02
    z[1,0,6]  R375      5.7073158025741577e-01
    z[1,0,6]  R376      -1.5794268250465393e-01
    z[1,0,6]  R377      3.0939567089080811e-01
    z[1,0,6]  R378      2.5403586030006409e-01
    z[1,0,6]  R379      3.1916892528533936e-01
    z[1,0,6]  R380      2.3045334219932556e-01
    z[1,0,6]  R381      2.3487238585948944e-01
    z[1,0,6]  R382      1.5198100358247757e-02
    z[1,0,6]  R383      -1.3912385702133179e-01
    z[1,0,6]  R384      2.2606596350669861e-01
    z[1,0,6]  R385      2.0908632874488831e-01
    z[1,0,6]  R386      5.1905751228332520e-01
    z[1,0,6]  R387      -1.1375757306814194e-01
    z[1,0,6]  R388      3.3053648471832275e-01
    z[1,0,6]  R389      -1.7875127494335175e-01
    z[1,0,6]  R390      -1.7471471428871155e-01
    z[1,0,6]  R391      -3.0696097016334534e-01
    z[1,0,6]  R392      -1.4413294196128845e-01
    z[1,0,6]  R393      -1.9780771806836128e-02
    z[1,0,6]  R394      -4.2399564385414124e-01
    z[1,0,6]  R395      3.5136872529983521e-01
    z[1,0,6]  R396      2.3495469987392426e-01
    z[1,0,6]  R397      -0.0321926586329937
    z[1,0,6]  R398      5.2557539194822311e-02
    z[1,0,6]  R399      2.3745338618755341e-01
    z[0,5,0]  R2        -1
    z[0,5,0]  R47       1
    z[0,5,0]  R400      -1
    z[0,5,0]  R401      1
    z[0,5,0]  R414      4.9490082263946533e-01
    z[0,5,0]  R415      4.1498789191246033e-01
    z[0,5,0]  R416      5.6200385093688965e-01
    z[0,5,0]  R417      -2.7195507287979126e-01
    z[0,5,0]  R418      -1.5923419594764709e-01
    z[0,5,0]  R419      1.1338619142770767e-01
    z[0,5,0]  R420      -5.6006636470556259e-02
    z[0,5,0]  R421      -2.2266621887683868e-01
    z[0,5,0]  R422      1.8465099856257439e-02
    z[0,5,0]  R423      6.4370214939117432e-02
    z[0,5,0]  R424      1.5307880938053131e-01
    z[0,5,0]  R425      7.3211260139942169e-02
    z[0,5,0]  R426      3.4881255030632019e-01
    z[0,5,0]  R427      -3.8617795705795288e-01
    z[0,5,0]  R428      -1.6033592820167542e-01
    z[0,5,0]  R429      -5.0186461210250854e-01
    z[0,5,0]  R430      -4.7637766599655151e-01
    z[0,5,0]  R431      -0.341469407081604
    z[0,5,0]  R432      -4.7362893819808960e-01
    z[0,5,0]  R433      -2.7223885059356689e-01
    z[0,5,0]  R434      2.4971213936805725e-01
    z[0,5,0]  R435      -6.0493912547826767e-02
    z[0,5,0]  R436      -0.0623035691678524
    z[0,5,0]  R437      1.6990311443805695e-02
    z[0,5,0]  R438      3.0292698740959167e-01
    z[0,5,0]  R439      -1.4488242566585541e-01
    z[0,5,0]  R440      2.6645186543464661e-01
    z[0,5,0]  R441      -1.6680526733398438e-01
    z[0,5,0]  R442      -6.0302621126174927e-01
    z[0,5,0]  R443      -4.7555884718894958e-01
    z[0,5,0]  R444      3.0833488702774048e-01
    z[0,5,0]  R445      3.6954346299171448e-01
    z[0,5,0]  R446      1.3853612542152405e-01
    z[0,5,0]  R447      1.1774213053286076e-02
    z[0,5,0]  R448      -3.4528955817222595e-01
    z[0,5,0]  R449      -0.51384037733078
    z[0,5,0]  R450      2.9657664895057678e-01
    z[0,5,0]  R451      3.4071081876754761e-01
    z[0,5,0]  R452      4.9104800820350647e-01
    z[0,5,0]  R453      -5.7003223896026611e-01
    z[0,5,0]  R454      -0.0688767358660698
    z[0,5,0]  R455      -4.3175253272056580e-01
    z[0,5,0]  R456      1.4744243025779724e-01
    z[0,5,0]  R457      -1.8172748386859894e-01
    z[0,5,0]  R458      6.0729360580444336e-01
    z[0,5,0]  R459      7.0505076646804810e-01
    z[0,5,0]  R460      -5.4727524518966675e-01
    z[0,5,0]  R461      6.3396120071411133e-01
    z[0,5,0]  R462      -4.9636000394821167e-01
    z[0,5,0]  R463      7.1425217390060425e-01
    z[0,5,0]  R464      2.8491258621215820e-01
    z[0,5,0]  R465      2.6955893635749817e-01
    z[0,5,0]  R466      1.4603634178638458e-01
    z[0,5,0]  R467      -6.4753681421279907e-02
    z[0,5,0]  R468      2.0705427229404449e-01
    z[0,5,0]  R469      4.6588051319122314e-01
    z[0,5,0]  R470      -6.0379576683044434e-01
    z[0,5,0]  R471      -7.6082962751388550e-01
    z[0,5,0]  R472      -7.6411402225494385e-01
    z[0,5,0]  R473      -8.1588953733444214e-01
    z[0,5,0]  R474      -1.3222447037696838e-01
    z[0,5,0]  R475      4.4330772757530212e-01
    z[0,5,0]  R476      5.1061475276947021e-01
    z[0,5,0]  R477      3.6846846342086792e-01
    z[0,5,0]  R478      -1.4600045979022980e-01
    z[0,5,0]  R479      5.6267328560352325e-02
    z[0,5,0]  R480      -2.3827967047691345e-01
    z[0,5,0]  R481      3.1948262453079224e-01
    z[0,5,0]  R482      5.4506051540374756e-01
    z[0,5,0]  R483      -4.5493689179420471e-01
    z[0,5,0]  R484      -5.8300759643316269e-02
    z[0,5,0]  R485      4.5845970511436462e-01
    z[0,5,0]  R486      1.2683887779712677e-01
    z[0,5,0]  R487      -1.1591664701700211e-01
    z[0,5,0]  R488      2.8984561562538147e-01
    z[0,5,0]  R489      4.3581213802099228e-02
    z[0,5,0]  R490      2.8131446242332458e-01
    z[0,5,0]  R491      3.0815801024436951e-01
    z[0,5,0]  R492      3.6679348349571228e-01
    z[0,5,0]  R493      2.0239928364753723e-01
    z[0,5,0]  R494      3.4378626942634583e-01
    z[0,5,0]  R495      3.5512766242027283e-01
    z[0,5,0]  R496      0.172831192612648
    z[0,5,0]  R497      -1.1071722209453583e-01
    z[0,5,0]  R498      -1.2994001805782318e-01
    z[0,5,0]  R499      -4.2620870471000671e-01
    z[0,5,0]  R500      1.7344912886619568e-01
    z[0,5,0]  R501      4.4796681404113770e-01
    z[0,5,0]  R502      -7.8268569707870483e-01
    z[0,5,0]  R503      -6.5067225694656372e-01
    z[0,5,0]  R504      -4.4846507906913757e-01
    z[0,5,0]  R505      -2.1969492081552744e-03
    z[0,5,0]  R506      -1.2974171340465546e-01
    z[0,5,0]  R507      -1.0507542639970779e-01
    z[0,5,0]  R508      -6.4282584190368652e-01
    z[0,5,0]  R509      -5.9012347459793091e-01
    z[0,5,0]  R510      3.8122949004173279e-01
    z[0,5,0]  R511      -4.8667392134666443e-01
    z[0,5,0]  R512      -3.3006361126899719e-01
    z[0,5,0]  R513      2.1405370533466339e-01
    z[0,5,1]  R3        -1
    z[0,5,1]  R48       1
    z[0,5,1]  R402      -1
    z[0,5,1]  R403      1
    z[0,5,1]  R414      -2.3231776058673859e-01
    z[0,5,1]  R415      -4.2521899938583374e-01
    z[0,5,1]  R416      -2.8838777542114258e-01
    z[0,5,1]  R417      -2.9415807127952576e-01
    z[0,5,1]  R418      -1.8136461079120636e-01
    z[0,5,1]  R419      0.614677906036377
    z[0,5,1]  R420      8.8259148597717285e-01
    z[0,5,1]  R421      -1.2112042307853699e-01
    z[0,5,1]  R422      -2.1046364307403564e-01
    z[0,5,1]  R423      8.1843149662017822e-01
    z[0,5,1]  R424      1.2217903882265091e-01
    z[0,5,1]  R425      4.1422221064567566e-01
    z[0,5,1]  R426      -5.2835303544998169e-01
    z[0,5,1]  R427      -6.0785013437271118e-01
    z[0,5,1]  R428      2.9621484875679016e-01
    z[0,5,1]  R429      1.9389666616916656e-01
    z[0,5,1]  R430      -1.0692614316940308e-01
    z[0,5,1]  R431      3.5085476934909821e-02
    z[0,5,1]  R432      0.0629362165927887
    z[0,5,1]  R433      1.1717350780963898e-01
    z[0,5,1]  R434      4.6073517203330994e-01
    z[0,5,1]  R435      7.1917676925659180e-01
    z[0,5,1]  R436      5.5513072013854980e-01
    z[0,5,1]  R437      -5.3189247846603394e-01
    z[0,5,1]  R438      1.9663409888744354e-01
    z[0,5,1]  R439      0.213766410946846
    z[0,5,1]  R440      3.8322755694389343e-01
    z[0,5,1]  R441      6.5201544761657715e-01
    z[0,5,1]  R442      3.3321052789688110e-01
    z[0,5,1]  R443      6.9712668657302856e-01
    z[0,5,1]  R444      6.4458996057510376e-01
    z[0,5,1]  R445      -5.9066683053970337e-01
    z[0,5,1]  R446      -9.1286391019821167e-01
    z[0,5,1]  R447      -0.74636310338974
    z[0,5,1]  R448      -0.783897876739502
    z[0,5,1]  R449      -4.5693665742874146e-01
    z[0,5,1]  R450      -0.637538731098175
    z[0,5,1]  R451      -7.2442001104354858e-01
    z[0,5,1]  R452      -5.1696652173995972e-01
    z[0,5,1]  R453      1.1333186924457550e-01
    z[0,5,1]  R454      -6.8740415573120117e-01
    z[0,5,1]  R455      -5.5598491430282593e-01
    z[0,5,1]  R456      -7.0357513427734375e-01
    z[0,5,1]  R457      2.2914955019950867e-01
    z[0,5,1]  R458      3.8495090603828430e-01
    z[0,5,1]  R459      6.1672019958496094e-01
    z[0,5,1]  R460      1.0403732955455780e-01
    z[0,5,1]  R461      2.6857027783989906e-02
    z[0,5,1]  R462      3.9084741473197937e-01
    z[0,5,1]  R463      -1.0710010677576065e-01
    z[0,5,1]  R464      4.6051979064941406e-01
    z[0,5,1]  R465      -7.3174512386322021e-01
    z[0,5,1]  R466      -9.7263120114803314e-02
    z[0,5,1]  R467      -8.4369462728500366e-01
    z[0,5,1]  R468      1.1094018071889877e-01
    z[0,5,1]  R469      5.9087282419204712e-01
    z[0,5,1]  R470      -1.5158358030021191e-02
    z[0,5,1]  R471      -4.9962759017944336e-02
    z[0,5,1]  R472      -3.1675678491592407e-01
    z[0,5,1]  R473      -1.8333867192268372e-01
    z[0,5,1]  R474      -1.6161552071571350e-01
    z[0,5,1]  R475      3.2868351787328720e-02
    z[0,5,1]  R476      -1.7294447124004364e-01
    z[0,5,1]  R477      -8.4048956632614136e-02
    z[0,5,1]  R478      -7.3759369552135468e-02
    z[0,5,1]  R479      1.5344594419002533e-01
    z[0,5,1]  R480      -1.3576546311378479e-01
    z[0,5,1]  R481      -6.5748848021030426e-02
    z[0,5,1]  R482      -3.4854590892791748e-01
    z[0,5,1]  R483      1.0795310884714127e-01
    z[0,5,1]  R484      3.8190406560897827e-01
    z[0,5,1]  R485      0.508387565612793
    z[0,5,1]  R486      3.8482189178466797e-01
    z[0,5,1]  R487      -9.4322019815444946e-01
    z[0,5,1]  R488      5.6086617708206177e-01
    z[0,5,1]  R489      8.6465978622436523e-01
    z[0,5,1]  R490      9.2690610885620117e-01
    z[0,5,1]  R491      8.7022984027862549e-01
    z[0,5,1]  R492      6.7859381437301636e-01
    z[0,5,1]  R493      9.3490058183670044e-01
    z[0,5,1]  R494      -7.2512662410736084e-01
    z[0,5,1]  R495      -6.8225187063217163e-01
    z[0,5,1]  R496      1.0376872122287750e-01
    z[0,5,1]  R497      -9.1379128396511078e-02
    z[0,5,1]  R498      -8.3054494857788086e-01
    z[0,5,1]  R499      -1.7058350145816803e-01
    z[0,5,1]  R500      -6.9917507469654083e-02
    z[0,5,1]  R501      -7.9005323350429535e-02
    z[0,5,1]  R502      -5.7636916637420654e-02
    z[0,5,1]  R503      -1.2369954586029053e-01
    z[0,5,1]  R504      2.7449575066566467e-01
    z[0,5,1]  R505      -8.9514678716659546e-01
    z[0,5,1]  R506      1.2293367832899094e-01
    z[0,5,1]  R507      -0.889827311038971
    z[0,5,1]  R508      -1.3678210973739624e-01
    z[0,5,1]  R509      -2.3393984884023666e-02
    z[0,5,1]  R510      3.3358085155487061e-01
    z[0,5,1]  R511      -7.5847542285919189e-01
    z[0,5,1]  R512      2.8464773297309875e-01
    z[0,5,1]  R513      -3.7620380520820618e-01
    z[0,5,2]  R4        -1
    z[0,5,2]  R49       1
    z[0,5,2]  R404      -1
    z[0,5,2]  R405      1
    z[0,5,2]  R414      -5.7488650083541870e-01
    z[0,5,2]  R415      -6.2625670433044434e-01
    z[0,5,2]  R416      -8.8665857911109924e-02
    z[0,5,2]  R417      -5.7745444774627686e-01
    z[0,5,2]  R418      -4.2030754685401917e-01
    z[0,5,2]  R419      -3.2679456472396851e-01
    z[0,5,2]  R420      2.3499237000942230e-01
    z[0,5,2]  R421      -2.5501725077629089e-01
    z[0,5,2]  R422      -6.5312135219573975e-01
    z[0,5,2]  R423      1.2549513578414917e-01
    z[0,5,2]  R424      -2.6208499073982239e-01
    z[0,5,2]  R425      3.5253354907035828e-01
    z[0,5,2]  R426      4.8182269930839539e-01
    z[0,5,2]  R427      3.8683211803436279e-01
    z[0,5,2]  R428      8.2693123817443848e-01
    z[0,5,2]  R429      8.0544006824493408e-01
    z[0,5,2]  R430      8.4311634302139282e-01
    z[0,5,2]  R431      8.9893138408660889e-01
    z[0,5,2]  R432      0.8321533203125
    z[0,5,2]  R433      9.1821324825286865e-01
    z[0,5,2]  R434      -7.1190494298934937e-01
    z[0,5,2]  R435      1.0455914773046970e-02
    z[0,5,2]  R436      2.5464800000190735e-01
    z[0,5,2]  R437      -5.5668348073959351e-01
    z[0,5,2]  R438      -0.676361620426178
    z[0,5,2]  R439      1.8518878519535065e-01
    z[0,5,2]  R440      -1.8845534324645996e-01
    z[0,5,2]  R441      -2.9361501336097717e-01
    z[0,5,2]  R442      1.4269612729549408e-02
    z[0,5,2]  R443      1.4455687999725342e-01
    z[0,5,2]  R444      -4.1292563080787659e-01
    z[0,5,2]  R445      -4.6847561001777649e-01
    z[0,5,2]  R446      2.1335519850254059e-01
    z[0,5,2]  R447      3.4986928105354309e-01
    z[0,5,2]  R448      -4.8542730510234833e-02
    z[0,5,2]  R449      -7.7823407948017120e-02
    z[0,5,2]  R450      -1.1915443092584610e-01
    z[0,5,2]  R451      3.6274176836013794e-01
    z[0,5,2]  R452      2.3225225508213043e-01
    z[0,5,2]  R453      -5.5932450294494629e-01
    z[0,5,2]  R454      1.0764485597610474e-01
    z[0,5,2]  R455      -8.8984228670597076e-02
    z[0,5,2]  R456      1.3610440492630005e-01
    z[0,5,2]  R457      -6.8699955940246582e-01
    z[0,5,2]  R458      1.8842889368534088e-01
    z[0,5,2]  R459      1.2623888254165649e-01
    z[0,5,2]  R460      -5.7087469100952148e-01
    z[0,5,2]  R461      2.1743780374526978e-01
    z[0,5,2]  R462      -6.2400847673416138e-01
    z[0,5,2]  R463      3.4387171268463135e-02
    z[0,5,2]  R464      -4.8959305882453918e-01
    z[0,5,2]  R465      2.3180879652500153e-01
    z[0,5,2]  R466      -4.3938422203063965e-01
    z[0,5,2]  R467      -2.0589542388916016e-01
    z[0,5,2]  R468      -1.7205569148063660e-01
    z[0,5,2]  R469      -2.3169048130512238e-02
    z[0,5,2]  R470      6.9852125644683838e-01
    z[0,5,2]  R471      0.470347136259079
    z[0,5,2]  R472      4.5164796710014343e-01
    z[0,5,2]  R473      3.8815578818321228e-01
    z[0,5,2]  R474      -6.1106526851654053e-01
    z[0,5,2]  R475      -6.1709243059158325e-01
    z[0,5,2]  R476      -4.1789144277572632e-01
    z[0,5,2]  R477      -4.7554206848144531e-01
    z[0,5,2]  R478      -6.7307806015014648e-01
    z[0,5,2]  R479      -5.5688637495040894e-01
    z[0,5,2]  R480      -2.8121533989906311e-01
    z[0,5,2]  R481      -0.698015570640564
    z[0,5,2]  R482      -5.9209811687469482e-01
    z[0,5,2]  R483      8.1579720973968506e-01
    z[0,5,2]  R484      7.7131724357604980e-01
    z[0,5,2]  R485      5.6596356630325317e-01
    z[0,5,2]  R486      0.581097424030304
    z[0,5,2]  R487      3.5194832831621170e-02
    z[0,5,2]  R488      5.5022466182708740e-01
    z[0,5,2]  R489      3.7467437982559204e-01
    z[0,5,2]  R490      0.185869038105011
    z[0,5,2]  R491      2.8341516852378845e-01
    z[0,5,2]  R492      4.6027562022209167e-01
    z[0,5,2]  R493      1.8549726903438568e-01
    z[0,5,2]  R494      -5.6430444121360779e-02
    z[0,5,2]  R495      5.4062587022781372e-01
    z[0,5,2]  R496      6.0086369514465332e-01
    z[0,5,2]  R497      -4.1874074935913086e-01
    z[0,5,2]  R498      5.0818151235580444e-01
    z[0,5,2]  R499      6.8316936492919922e-01
    z[0,5,2]  R500      -2.0684944093227386e-01
    z[0,5,2]  R501      4.9719268083572388e-01
    z[0,5,2]  R502      5.5894345045089722e-01
    z[0,5,2]  R503      5.4726940393447876e-01
    z[0,5,2]  R504      7.3217743635177612e-01
    z[0,5,2]  R505      4.2120260000228882e-01
    z[0,5,2]  R506      4.8127841949462891e-01
    z[0,5,2]  R507      3.1994324922561646e-01
    z[0,5,2]  R508      5.4639947414398193e-01
    z[0,5,2]  R509      4.6196100115776062e-01
    z[0,5,2]  R510      2.2199396789073944e-01
    z[0,5,2]  R511      -2.1182221174240112e-01
    z[0,5,2]  R512      -2.3711444437503815e-01
    z[0,5,2]  R513      -1.7014425992965698e-01
    z[0,5,3]  R5        -1
    z[0,5,3]  R50       1
    z[0,5,3]  R406      -1
    z[0,5,3]  R407      1
    z[0,5,3]  R414      -5.7408112287521362e-01
    z[0,5,3]  R415      -3.6551985144615173e-01
    z[0,5,3]  R416      -5.9628689289093018e-01
    z[0,5,3]  R417      -2.9741668701171875e-01
    z[0,5,3]  R418      -4.1337344050407410e-01
    z[0,5,3]  R419      2.0641303062438965e-01
    z[0,5,3]  R420      2.1087038516998291e-01
    z[0,5,3]  R421      -7.0434558391571045e-01
    z[0,5,3]  R422      8.4888547658920288e-02
    z[0,5,3]  R423      8.0051563680171967e-02
    z[0,5,3]  R424      7.6750802993774414e-01
    z[0,5,3]  R425      4.0120804309844971e-01
    z[0,5,3]  R426      5.6791716814041138e-01
    z[0,5,3]  R427      -3.0295112729072571e-01
    z[0,5,3]  R428      1.9151894748210907e-01
    z[0,5,3]  R429      1.3078117370605469e-01
    z[0,5,3]  R430      1.4946061372756958e-01
    z[0,5,3]  R431      0.159884512424469
    z[0,5,3]  R432      9.7060039639472961e-02
    z[0,5,3]  R433      2.1969486773014069e-01
    z[0,5,3]  R434      3.3871078491210938e-01
    z[0,5,3]  R435      4.5961785316467285e-01
    z[0,5,3]  R436      7.3579859733581543e-01
    z[0,5,3]  R437      8.0825246870517731e-02
    z[0,5,3]  R438      4.8096778988838196e-01
    z[0,5,3]  R439      8.0494147539138794e-01
    z[0,5,3]  R440      3.7761631608009338e-01
    z[0,5,3]  R441      1.8257418274879456e-01
    z[0,5,3]  R442      6.4273148775100708e-01
    z[0,5,3]  R443      2.2279354929924011e-01
    z[0,5,3]  R444      2.6987805962562561e-01
    z[0,5,3]  R445      1.9493977725505829e-01
    z[0,5,3]  R446      -1.9338284432888031e-01
    z[0,5,3]  R447      -0.388785719871521
    z[0,5,3]  R448      -1.7030143737792969e-01
    z[0,5,3]  R449      -2.7515235543251038e-01
    z[0,5,3]  R450      6.0826158523559570e-01
    z[0,5,3]  R451      1.6258460283279419e-01
    z[0,5,3]  R452      5.2279084920883179e-01
    z[0,5,3]  R453      -5.2511040121316910e-02
    z[0,5,3]  R454      -0.637824296951294
    z[0,5,3]  R455      -1.9327494502067566e-01
    z[0,5,3]  R456      -1.5178553760051727e-01
    z[0,5,3]  R457      5.1419204473495483e-01
    z[0,5,3]  R458      1.2139932811260223e-01
    z[0,5,3]  R459      3.3413335680961609e-02
    z[0,5,3]  R460      -4.9365319311618805e-02
    z[0,5,3]  R461      2.4444395303726196e-01
    z[0,5,3]  R462      -1.7017644643783569e-01
    z[0,5,3]  R463      5.3708422183990479e-01
    z[0,5,3]  R464      6.0811394453048706e-01
    z[0,5,3]  R465      -3.2972010970115662e-01
    z[0,5,3]  R466      7.2953003644943237e-01
    z[0,5,3]  R467      -2.7185928821563721e-01
    z[0,5,3]  R468      8.5692560672760010e-01
    z[0,5,3]  R469      -6.7722752690315247e-02
    z[0,5,3]  R470      -1.6869744658470154e-01
    z[0,5,3]  R471      -1.0491450130939484e-01
    z[0,5,3]  R472      2.3639321327209473e-01
    z[0,5,3]  R473      -5.7837799191474915e-02
    z[0,5,3]  R474      -5.2917140722274780e-01
    z[0,5,3]  R475      -3.5314863920211792e-01
    z[0,5,3]  R476      -6.0037565231323242e-01
    z[0,5,3]  R477      -5.5758535861968994e-01
    z[0,5,3]  R478      -1.6042657196521759e-01
    z[0,5,3]  R479      -3.3760768175125122e-01
    z[0,5,3]  R480      -7.8490930795669556e-01
    z[0,5,3]  R481      4.5755021274089813e-02
    z[0,5,3]  R482      -2.9018133878707886e-01
    z[0,5,3]  R483      1.0989991575479507e-01
    z[0,5,3]  R484      3.5300999879837036e-01
    z[0,5,3]  R485      3.8653177022933960e-01
    z[0,5,3]  R486      4.5291340351104736e-01
    z[0,5,3]  R487      1.9377514719963074e-01
    z[0,5,3]  R488      1.3471165299415588e-01
    z[0,5,3]  R489      2.3421159386634827e-01
    z[0,5,3]  R490      1.1017097532749176e-01
    z[0,5,3]  R491      7.6226450502872467e-02
    z[0,5,3]  R492      2.0796790719032288e-01
    z[0,5,3]  R493      1.4745345711708069e-01
    z[0,5,3]  R494      1.7238780856132507e-01
    z[0,5,3]  R495      -1.9658863544464111e-01
    z[0,5,3]  R496      6.6063910722732544e-01
    z[0,5,3]  R497      3.6536341905593872e-01
    z[0,5,3]  R498      -1.4940737187862396e-01
    z[0,5,3]  R499      4.5457309484481812e-01
    z[0,5,3]  R500      2.2941657900810242e-01
    z[0,5,3]  R501      -4.5434886217117310e-01
    z[0,5,3]  R502      6.7545793950557709e-02
    z[0,5,3]  R503      -3.8898780941963196e-02
    z[0,5,3]  R504      1.7104667425155640e-01
    z[0,5,3]  R505      -0.0592644065618515
    z[0,5,3]  R506      7.8499954938888550e-01
    z[0,5,3]  R507      -1.0627415776252747e-01
    z[0,5,3]  R508      4.4233056902885437e-01
    z[0,5,3]  R509      5.7241427898406982e-01
    z[0,5,3]  R510      7.3525249958038330e-01
    z[0,5,3]  R511      0.293355792760849
    z[0,5,3]  R512      7.2702729701995850e-01
    z[0,5,3]  R513      7.4696594476699829e-01
    z[0,5,4]  R6        -1
    z[0,5,4]  R51       1
    z[0,5,4]  R408      -1
    z[0,5,4]  R409      1
    z[0,5,4]  R414      8.9604228734970093e-02
    z[0,5,4]  R415      -2.8744882345199585e-01
    z[0,5,4]  R416      2.0206996798515320e-01
    z[0,5,4]  R417      4.4445816427469254e-02
    z[0,5,4]  R418      5.0837200880050659e-01
    z[0,5,4]  R419      -4.3901059031486511e-01
    z[0,5,4]  R420      1.6942851245403290e-01
    z[0,5,4]  R421      -1.9649676978588104e-02
    z[0,5,4]  R422      4.6485564112663269e-01
    z[0,5,4]  R423      -3.1988048553466797e-01
    z[0,5,4]  R424      4.0406605601310730e-01
    z[0,5,4]  R425      -0.0986860916018486
    z[0,5,4]  R426      1.2505438923835754e-01
    z[0,5,4]  R427      -4.3657961487770081e-01
    z[0,5,4]  R428      2.2704254090785980e-01
    z[0,5,4]  R429      -1.2737950682640076e-01
    z[0,5,4]  R430      -1.2335945852100849e-02
    z[0,5,4]  R431      -1.8066802620887756e-01
    z[0,5,4]  R432      1.6324238479137421e-01
    z[0,5,4]  R433      6.8727836012840271e-02
    z[0,5,4]  R434      2.3454587161540985e-01
    z[0,5,4]  R435      5.1327306032180786e-01
    z[0,5,4]  R436      -1.1139550060033798e-01
    z[0,5,4]  R437      3.7365466356277466e-01
    z[0,5,4]  R438      1.5394628047943115e-01
    z[0,5,4]  R439      3.2040628790855408e-01
    z[0,5,4]  R440      3.3972853422164917e-01
    z[0,5,4]  R441      -6.4457327127456665e-02
    z[0,5,4]  R442      -2.8373605012893677e-01
    z[0,5,4]  R443      -3.2385626435279846e-01
    z[0,5,4]  R444      3.6158025264739990e-02
    z[0,5,4]  R445      2.8707557916641235e-01
    z[0,5,4]  R446      -2.1785897016525269e-01
    z[0,5,4]  R447      1.3910777866840363e-01
    z[0,5,4]  R448      -3.3459064364433289e-01
    z[0,5,4]  R449      -6.3165277242660522e-02
    z[0,5,4]  R450      -3.0165541172027588e-01
    z[0,5,4]  R451      3.2457414269447327e-01
    z[0,5,4]  R452      -6.5735457465052605e-03
    z[0,5,4]  R453      -4.6645230054855347e-01
    z[0,5,4]  R454      -2.1367374062538147e-01
    z[0,5,4]  R455      2.4187627434730530e-01
    z[0,5,4]  R456      0.53766930103302
    z[0,5,4]  R457      -3.9414870738983154e-01
    z[0,5,4]  R458      3.7524050474166870e-01
    z[0,5,4]  R459      -4.3254144489765167e-02
    z[0,5,4]  R460      -1.3490395247936249e-01
    z[0,5,4]  R461      -2.7130043506622314e-01
    z[0,5,4]  R462      -1.6369469463825226e-02
    z[0,5,4]  R463      8.4502868354320526e-02
    z[0,5,4]  R464      2.5334203243255615e-01
    z[0,5,4]  R465      -3.5510438680648804e-01
    z[0,5,4]  R466      -4.4641056656837463e-01
    z[0,5,4]  R467      1.5092290937900543e-02
    z[0,5,4]  R468      -2.3525262251496315e-02
    z[0,5,4]  R469      -0.0577346533536911
    z[0,5,4]  R470      6.4896240830421448e-02
    z[0,5,4]  R471      -1.4085040986537933e-01
    z[0,5,4]  R472      9.8788976669311523e-02
    z[0,5,4]  R473      -4.1376795619726181e-02
    z[0,5,4]  R474      -3.2975059747695923e-01
    z[0,5,4]  R475      -3.2270956039428711e-01
    z[0,5,4]  R476      -1.6008014976978302e-01
    z[0,5,4]  R477      1.6464999318122864e-01
    z[0,5,4]  R478      -3.6174979805946350e-01
    z[0,5,4]  R479      -5.6766338646411896e-02
    z[0,5,4]  R480      3.8014256954193115e-01
    z[0,5,4]  R481      -5.4628050327301025e-01
    z[0,5,4]  R482      2.1887996792793274e-01
    z[0,5,4]  R483      -5.3625606000423431e-02
    z[0,5,4]  R484      -9.6041090786457062e-02
    z[0,5,4]  R485      -3.7073828279972076e-02
    z[0,5,4]  R486      -4.5687353610992432e-01
    z[0,5,4]  R487      -1.9509927928447723e-01
    z[0,5,4]  R488      -3.6990082263946533e-01
    z[0,5,4]  R489      -5.9515666216611862e-02
    z[0,5,4]  R490      -7.7582925558090210e-02
    z[0,5,4]  R491      -1.1067941784858704e-01
    z[0,5,4]  R492      -1.4172458648681641e-01
    z[0,5,4]  R493      5.7703603059053421e-02
    z[0,5,4]  R494      5.5482137203216553e-01
    z[0,5,4]  R495      -3.2768428325653076e-02
    z[0,5,4]  R496      -1.7064218409359455e-03
    z[0,5,4]  R497      8.1124818325042725e-01
    z[0,5,4]  R498      5.6696657091379166e-02
    z[0,5,4]  R499      1.9953319430351257e-01
    z[0,5,4]  R500      8.9923244714736938e-01
    z[0,5,4]  R501      -2.0589552819728851e-01
    z[0,5,4]  R502      -1.0547125339508057e-01
    z[0,5,4]  R503      -3.1715796794742346e-03
    z[0,5,4]  R504      -2.3647494614124298e-01
    z[0,5,4]  R505      2.3328827694058418e-02
    z[0,5,4]  R506      -9.8830483853816986e-02
    z[0,5,4]  R507      1.6807280480861664e-01
    z[0,5,4]  R508      -6.0537587851285934e-02
    z[0,5,4]  R509      -1.5713594853878021e-01
    z[0,5,4]  R510      -1.3777065277099609e-01
    z[0,5,4]  R511      2.1798150241374969e-01
    z[0,5,4]  R512      4.3557864427566528e-01
    z[0,5,4]  R513      3.2727840542793274e-01
    z[0,5,5]  R7        -1
    z[0,5,5]  R52       1
    z[0,5,5]  R410      -1
    z[0,5,5]  R411      1
    z[0,5,5]  R414      1.2492982298135757e-01
    z[0,5,5]  R415      0.175779327750206
    z[0,5,5]  R416      3.8542658090591431e-02
    z[0,5,5]  R417      -5.6672483682632446e-01
    z[0,5,5]  R418      -5.7694405317306519e-01
    z[0,5,5]  R419      3.2612487673759460e-01
    z[0,5,5]  R420      -2.9808858036994934e-01
    z[0,5,5]  R421      -4.0076601505279541e-01
    z[0,5,5]  R422      -3.8645300269126892e-01
    z[0,5,5]  R423      1.7766506969928741e-01
    z[0,5,5]  R424      -1.6486328095197678e-02
    z[0,5,5]  R425      0.503727912902832
    z[0,5,5]  R426      0.0744536742568016
    z[0,5,5]  R427      -9.5156140625476837e-02
    z[0,5,5]  R428      1.6693204641342163e-01
    z[0,5,5]  R429      0.0472993366420269
    z[0,5,5]  R430      1.6686005890369415e-01
    z[0,5,5]  R431      1.1024153977632523e-01
    z[0,5,5]  R432      2.0623014867305756e-01
    z[0,5,5]  R433      6.2137570232152939e-02
    z[0,5,5]  R434      9.5437504351139069e-02
    z[0,5,5]  R435      -6.5168537199497223e-02
    z[0,5,5]  R436      2.6004728674888611e-01
    z[0,5,5]  R437      -5.0996005535125732e-01
    z[0,5,5]  R438      -8.8554620742797852e-02
    z[0,5,5]  R439      -2.4945183098316193e-01
    z[0,5,5]  R440      -1.1956793069839478e-01
    z[0,5,5]  R441      2.5355464220046997e-01
    z[0,5,5]  R442      -1.7481237649917603e-01
    z[0,5,5]  R443      1.9550228118896484e-01
    z[0,5,5]  R444      1.8047341704368591e-01
    z[0,5,5]  R445      -3.0346742272377014e-01
    z[0,5,5]  R446      -7.9076945781707764e-02
    z[0,5,5]  R447      -1.2368068844079971e-01
    z[0,5,5]  R448      -3.5012704133987427e-01
    z[0,5,5]  R449      -3.4012833237648010e-01
    z[0,5,5]  R450      7.3924213647842407e-02
    z[0,5,5]  R451      6.5081994980573654e-03
    z[0,5,5]  R452      3.1589362025260925e-01
    z[0,5,5]  R453      -1.6483667492866516e-01
    z[0,5,5]  R454      -7.4559226632118225e-02
    z[0,5,5]  R455      -5.8781629800796509e-01
    z[0,5,5]  R456      -3.9033353328704834e-01
    z[0,5,5]  R457      -5.8267004787921906e-02
    z[0,5,5]  R458      4.9076753854751587e-01
    z[0,5,5]  R459      0.244783416390419
    z[0,5,5]  R460      -2.7149847149848938e-01
    z[0,5,5]  R461      6.3544875383377075e-01
    z[0,5,5]  R462      -2.7017769217491150e-01
    z[0,5,5]  R463      3.8683155179023743e-01
    z[0,5,5]  R464      5.0349522382020950e-02
    z[0,5,5]  R465      9.5458760857582092e-02
    z[0,5,5]  R466      1.5454442799091339e-01
    z[0,5,5]  R467      -4.0873834490776062e-01
    z[0,5,5]  R468      2.3882275447249413e-02
    z[0,5,5]  R469      5.4946172237396240e-01
    z[0,5,5]  R470      2.4371053278446198e-01
    z[0,5,5]  R471      4.0685775876045227e-01
    z[0,5,5]  R472      2.0834033191204071e-01
    z[0,5,5]  R473      2.9766580462455750e-01
    z[0,5,5]  R474      -1.9581261277198792e-01
    z[0,5,5]  R475      -1.5446981787681580e-01
    z[0,5,5]  R476      -2.6942875981330872e-01
    z[0,5,5]  R477      -1.8457669019699097e-01
    z[0,5,5]  R478      -2.7567198872566223e-01
    z[0,5,5]  R479      -3.3022406697273254e-01
    z[0,5,5]  R480      -2.6450985670089722e-01
    z[0,5,5]  R481      -1.7573808133602142e-01
    z[0,5,5]  R482      3.1393748521804810e-01
    z[0,5,5]  R483      2.1167731285095215e-01
    z[0,5,5]  R484      3.1547054648399353e-01
    z[0,5,5]  R485      2.2521814703941345e-01
    z[0,5,5]  R486      2.8799504041671753e-01
    z[0,5,5]  R487      1.0257090628147125e-01
    z[0,5,5]  R488      2.4985921382904053e-01
    z[0,5,5]  R489      1.1288130283355713e-01
    z[0,5,5]  R490      5.4335236549377441e-02
    z[0,5,5]  R491      1.1946207284927368e-01
    z[0,5,5]  R492      2.2022227942943573e-01
    z[0,5,5]  R493      8.3384037017822266e-02
    z[0,5,5]  R494      -2.4482456967234612e-02
    z[0,5,5]  R495      1.6232512891292572e-01
    z[0,5,5]  R496      2.6613163948059082e-01
    z[0,5,5]  R497      -1.0773230344057083e-01
    z[0,5,5]  R498      9.4823047518730164e-02
    z[0,5,5]  R499      2.7530258893966675e-01
    z[0,5,5]  R500      -1.1338969320058823e-01
    z[0,5,5]  R501      4.9063485860824585e-01
    z[0,5,5]  R502      1.9328027963638306e-01
    z[0,5,5]  R503      3.6383220553398132e-01
    z[0,5,5]  R504      2.1385115385055542e-01
    z[0,5,5]  R505      1.1175382137298584e-01
    z[0,5,5]  R506      2.8542625904083252e-01
    z[0,5,5]  R507      3.2299514859914780e-02
    z[0,5,5]  R508      2.3050366342067719e-01
    z[0,5,5]  R509      2.7703121304512024e-01
    z[0,5,5]  R510      2.7160212397575378e-01
    z[0,5,5]  R511      1.3086847029626369e-02
    z[0,5,5]  R512      7.5679324567317963e-02
    z[0,5,5]  R513      1.4883327484130859e-01
    z[0,5,6]  R8        -1
    z[0,5,6]  R53       1
    z[0,5,6]  R412      -1
    z[0,5,6]  R413      1
    z[0,5,6]  R414      1.3191461563110352e-01
    z[0,5,6]  R415      0.0874442458152771
    z[0,5,6]  R416      -4.4186714291572571e-01
    z[0,5,6]  R417      -3.0732482671737671e-01
    z[0,5,6]  R418      -5.3932290524244308e-02
    z[0,5,6]  R419      -0.401030957698822
    z[0,5,6]  R420      -2.5396207347512245e-02
    z[0,5,6]  R421      -4.6218344569206238e-01
    z[0,5,6]  R422      -3.9516305923461914e-01
    z[0,5,6]  R423      -4.1228723526000977e-01
    z[0,5,6]  R424      3.7462085485458374e-01
    z[0,5,6]  R425      5.2376669645309448e-01
    z[0,5,6]  R426      -1.5266944468021393e-01
    z[0,5,6]  R427      2.0077311992645264e-01
    z[0,5,6]  R428      2.9434624314308167e-01
    z[0,5,6]  R429      0.16197469830513
    z[0,5,6]  R430      0.0212846789509058
    z[0,5,6]  R431      6.1095900833606720e-02
    z[0,5,6]  R432      -2.5218958035111427e-02
    z[0,5,6]  R433      -1.1041018366813660e-01
    z[0,5,6]  R434      1.9928197562694550e-01
    z[0,5,6]  R435      8.4426812827587128e-03
    z[0,5,6]  R436      -4.0857456624507904e-02
    z[0,5,6]  R437      0.0263714250177145
    z[0,5,6]  R438      -3.8630792498588562e-01
    z[0,5,6]  R439      -2.9359987378120422e-01
    z[0,5,6]  R440      -6.8870788812637329e-01
    z[0,5,6]  R441      5.9921962022781372e-01
    z[0,5,6]  R442      -3.0938610434532166e-02
    z[0,5,6]  R443      2.7243435382843018e-01
    z[0,5,6]  R444      -4.6066647768020630e-01
    z[0,5,6]  R445      -2.8735786676406860e-01
    z[0,5,6]  R446      -1.0418348759412766e-01
    z[0,5,6]  R447      3.6686885356903076e-01
    z[0,5,6]  R448      1.9505521282553673e-02
    z[0,5,6]  R449      5.7073158025741577e-01
    z[0,5,6]  R450      -1.5794268250465393e-01
    z[0,5,6]  R451      3.0939567089080811e-01
    z[0,5,6]  R452      2.5403586030006409e-01
    z[0,5,6]  R453      3.1916892528533936e-01
    z[0,5,6]  R454      2.3045334219932556e-01
    z[0,5,6]  R455      2.3487238585948944e-01
    z[0,5,6]  R456      1.5198100358247757e-02
    z[0,5,6]  R457      -1.3912385702133179e-01
    z[0,5,6]  R458      2.2606596350669861e-01
    z[0,5,6]  R459      2.0908632874488831e-01
    z[0,5,6]  R460      5.1905751228332520e-01
    z[0,5,6]  R461      -1.1375757306814194e-01
    z[0,5,6]  R462      3.3053648471832275e-01
    z[0,5,6]  R463      -1.7875127494335175e-01
    z[0,5,6]  R464      -1.7471471428871155e-01
    z[0,5,6]  R465      -3.0696097016334534e-01
    z[0,5,6]  R466      -1.4413294196128845e-01
    z[0,5,6]  R467      -1.9780771806836128e-02
    z[0,5,6]  R468      -4.2399564385414124e-01
    z[0,5,6]  R469      3.5136872529983521e-01
    z[0,5,6]  R470      2.3495469987392426e-01
    z[0,5,6]  R471      -0.0321926586329937
    z[0,5,6]  R472      5.2557539194822311e-02
    z[0,5,6]  R473      2.3745338618755341e-01
    z[0,5,6]  R474      0.39483642578125
    z[0,5,6]  R475      4.1094845533370972e-01
    z[0,5,6]  R476      -2.7579185366630554e-01
    z[0,5,6]  R477      5.0886821746826172e-01
    z[0,5,6]  R478      -5.3629726171493530e-01
    z[0,5,6]  R479      -0.660996675491333
    z[0,5,6]  R480      1.2309314310550690e-01
    z[0,5,6]  R481      -2.7382916212081909e-01
    z[0,5,6]  R482      1.3197000138461590e-02
    z[0,5,6]  R483      -2.3683875799179077e-01
    z[0,5,6]  R484      1.4986149966716766e-01
    z[0,5,6]  R485      -9.7660243511199951e-02
    z[0,5,6]  R486      -3.6668688058853149e-02
    z[0,5,6]  R487      9.7606927156448364e-02
    z[0,5,6]  R488      2.8507539629936218e-01
    z[0,5,6]  R489      -1.9734199345111847e-01
    z[0,5,6]  R490      -0.077787384390831
    z[0,5,6]  R491      1.8730445206165314e-01
    z[0,5,6]  R492      2.8510499000549316e-01
    z[0,5,6]  R493      1.3623951375484467e-01
    z[0,5,6]  R494      -1.2113806605339050e-01
    z[0,5,6]  R495      2.2376336157321930e-01
    z[0,5,6]  R496      -3.0174696445465088e-01
    z[0,5,6]  R497      -2.8764383867383003e-02
    z[0,5,6]  R498      -2.3102907463908195e-02
    z[0,5,6]  R499      1.6892101615667343e-02
    z[0,5,6]  R500      -2.1939021348953247e-01
    z[0,5,6]  R501      2.3734977841377258e-01
    z[0,5,6]  R502      1.3645261526107788e-01
    z[0,5,6]  R503      3.5766372084617615e-01
    z[0,5,6]  R504      -2.3777644336223602e-01
    z[0,5,6]  R505      6.8924024701118469e-02
    z[0,5,6]  R506      -1.7019283771514893e-01
    z[0,5,6]  R507      -2.3284508287906647e-01
    z[0,5,6]  R508      -1.3061454892158508e-01
    z[0,5,6]  R509      9.3289464712142944e-02
    z[0,5,6]  R510      2.4649918079376221e-01
    z[0,5,6]  R511      9.6176296472549438e-02
    z[0,5,6]  R512      1.7258486151695251e-01
    z[0,5,6]  R513      3.1061553955078125e-01
    z[5,0,0]  R2        1
    z[5,0,0]  R47       -1
    z[5,0,0]  R514      -1
    z[5,0,0]  R515      1
    z[5,0,0]  R528      -1.3222447037696838e-01
    z[5,0,0]  R529      4.4330772757530212e-01
    z[5,0,0]  R530      5.1061475276947021e-01
    z[5,0,0]  R531      3.6846846342086792e-01
    z[5,0,0]  R532      -1.4600045979022980e-01
    z[5,0,0]  R533      5.6267328560352325e-02
    z[5,0,0]  R534      -2.3827967047691345e-01
    z[5,0,0]  R535      3.1948262453079224e-01
    z[5,0,0]  R536      5.4506051540374756e-01
    z[5,0,0]  R537      -4.5493689179420471e-01
    z[5,0,0]  R538      -5.8300759643316269e-02
    z[5,0,0]  R539      4.5845970511436462e-01
    z[5,0,0]  R540      1.2683887779712677e-01
    z[5,0,0]  R541      -1.1591664701700211e-01
    z[5,0,0]  R542      2.8984561562538147e-01
    z[5,0,0]  R543      4.3581213802099228e-02
    z[5,0,0]  R544      2.8131446242332458e-01
    z[5,0,0]  R545      3.0815801024436951e-01
    z[5,0,0]  R546      3.6679348349571228e-01
    z[5,0,0]  R547      2.0239928364753723e-01
    z[5,0,0]  R548      3.4378626942634583e-01
    z[5,0,0]  R549      3.5512766242027283e-01
    z[5,0,0]  R550      0.172831192612648
    z[5,0,0]  R551      -1.1071722209453583e-01
    z[5,0,0]  R552      -1.2994001805782318e-01
    z[5,0,0]  R553      -4.2620870471000671e-01
    z[5,0,0]  R554      1.7344912886619568e-01
    z[5,0,0]  R555      4.4796681404113770e-01
    z[5,0,0]  R556      -7.8268569707870483e-01
    z[5,0,0]  R557      -6.5067225694656372e-01
    z[5,0,0]  R558      -4.4846507906913757e-01
    z[5,0,0]  R559      -2.1969492081552744e-03
    z[5,0,0]  R560      -1.2974171340465546e-01
    z[5,0,0]  R561      -1.0507542639970779e-01
    z[5,0,0]  R562      -6.4282584190368652e-01
    z[5,0,0]  R563      -5.9012347459793091e-01
    z[5,0,0]  R564      3.8122949004173279e-01
    z[5,0,0]  R565      -4.8667392134666443e-01
    z[5,0,0]  R566      -3.3006361126899719e-01
    z[5,0,0]  R567      2.1405370533466339e-01
    z[5,0,0]  R568      4.9490082263946533e-01
    z[5,0,0]  R569      4.1498789191246033e-01
    z[5,0,0]  R570      5.6200385093688965e-01
    z[5,0,0]  R571      -2.7195507287979126e-01
    z[5,0,0]  R572      -1.5923419594764709e-01
    z[5,0,0]  R573      1.1338619142770767e-01
    z[5,0,0]  R574      -5.6006636470556259e-02
    z[5,0,0]  R575      -2.2266621887683868e-01
    z[5,0,0]  R576      1.8465099856257439e-02
    z[5,0,0]  R577      6.4370214939117432e-02
    z[5,0,0]  R578      1.5307880938053131e-01
    z[5,0,0]  R579      7.3211260139942169e-02
    z[5,0,0]  R580      3.4881255030632019e-01
    z[5,0,0]  R581      -3.8617795705795288e-01
    z[5,0,0]  R582      -1.6033592820167542e-01
    z[5,0,0]  R583      -5.0186461210250854e-01
    z[5,0,0]  R584      -4.7637766599655151e-01
    z[5,0,0]  R585      -0.341469407081604
    z[5,0,0]  R586      -4.7362893819808960e-01
    z[5,0,0]  R587      -2.7223885059356689e-01
    z[5,0,0]  R588      2.4971213936805725e-01
    z[5,0,0]  R589      -6.0493912547826767e-02
    z[5,0,0]  R590      -0.0623035691678524
    z[5,0,0]  R591      1.6990311443805695e-02
    z[5,0,0]  R592      3.0292698740959167e-01
    z[5,0,0]  R593      -1.4488242566585541e-01
    z[5,0,0]  R594      2.6645186543464661e-01
    z[5,0,0]  R595      -1.6680526733398438e-01
    z[5,0,0]  R596      -6.0302621126174927e-01
    z[5,0,0]  R597      -4.7555884718894958e-01
    z[5,0,0]  R598      3.0833488702774048e-01
    z[5,0,0]  R599      3.6954346299171448e-01
    z[5,0,0]  R600      1.3853612542152405e-01
    z[5,0,0]  R601      1.1774213053286076e-02
    z[5,0,0]  R602      -3.4528955817222595e-01
    z[5,0,0]  R603      -0.51384037733078
    z[5,0,0]  R604      2.9657664895057678e-01
    z[5,0,0]  R605      3.4071081876754761e-01
    z[5,0,0]  R606      4.9104800820350647e-01
    z[5,0,0]  R607      -5.7003223896026611e-01
    z[5,0,0]  R608      -0.0688767358660698
    z[5,0,0]  R609      -4.3175253272056580e-01
    z[5,0,0]  R610      1.4744243025779724e-01
    z[5,0,0]  R611      -1.8172748386859894e-01
    z[5,0,0]  R612      6.0729360580444336e-01
    z[5,0,0]  R613      7.0505076646804810e-01
    z[5,0,0]  R614      -5.4727524518966675e-01
    z[5,0,0]  R615      6.3396120071411133e-01
    z[5,0,0]  R616      -4.9636000394821167e-01
    z[5,0,0]  R617      7.1425217390060425e-01
    z[5,0,0]  R618      2.8491258621215820e-01
    z[5,0,0]  R619      2.6955893635749817e-01
    z[5,0,0]  R620      1.4603634178638458e-01
    z[5,0,0]  R621      -6.4753681421279907e-02
    z[5,0,0]  R622      2.0705427229404449e-01
    z[5,0,0]  R623      4.6588051319122314e-01
    z[5,0,0]  R624      -6.0379576683044434e-01
    z[5,0,0]  R625      -7.6082962751388550e-01
    z[5,0,0]  R626      -7.6411402225494385e-01
    z[5,0,0]  R627      -8.1588953733444214e-01
    z[5,0,1]  R3        1
    z[5,0,1]  R48       -1
    z[5,0,1]  R516      -1
    z[5,0,1]  R517      1
    z[5,0,1]  R528      -1.6161552071571350e-01
    z[5,0,1]  R529      3.2868351787328720e-02
    z[5,0,1]  R530      -1.7294447124004364e-01
    z[5,0,1]  R531      -8.4048956632614136e-02
    z[5,0,1]  R532      -7.3759369552135468e-02
    z[5,0,1]  R533      1.5344594419002533e-01
    z[5,0,1]  R534      -1.3576546311378479e-01
    z[5,0,1]  R535      -6.5748848021030426e-02
    z[5,0,1]  R536      -3.4854590892791748e-01
    z[5,0,1]  R537      1.0795310884714127e-01
    z[5,0,1]  R538      3.8190406560897827e-01
    z[5,0,1]  R539      0.508387565612793
    z[5,0,1]  R540      3.8482189178466797e-01
    z[5,0,1]  R541      -9.4322019815444946e-01
    z[5,0,1]  R542      5.6086617708206177e-01
    z[5,0,1]  R543      8.6465978622436523e-01
    z[5,0,1]  R544      9.2690610885620117e-01
    z[5,0,1]  R545      8.7022984027862549e-01
    z[5,0,1]  R546      6.7859381437301636e-01
    z[5,0,1]  R547      9.3490058183670044e-01
    z[5,0,1]  R548      -7.2512662410736084e-01
    z[5,0,1]  R549      -6.8225187063217163e-01
    z[5,0,1]  R550      1.0376872122287750e-01
    z[5,0,1]  R551      -9.1379128396511078e-02
    z[5,0,1]  R552      -8.3054494857788086e-01
    z[5,0,1]  R553      -1.7058350145816803e-01
    z[5,0,1]  R554      -6.9917507469654083e-02
    z[5,0,1]  R555      -7.9005323350429535e-02
    z[5,0,1]  R556      -5.7636916637420654e-02
    z[5,0,1]  R557      -1.2369954586029053e-01
    z[5,0,1]  R558      2.7449575066566467e-01
    z[5,0,1]  R559      -8.9514678716659546e-01
    z[5,0,1]  R560      1.2293367832899094e-01
    z[5,0,1]  R561      -0.889827311038971
    z[5,0,1]  R562      -1.3678210973739624e-01
    z[5,0,1]  R563      -2.3393984884023666e-02
    z[5,0,1]  R564      3.3358085155487061e-01
    z[5,0,1]  R565      -7.5847542285919189e-01
    z[5,0,1]  R566      2.8464773297309875e-01
    z[5,0,1]  R567      -3.7620380520820618e-01
    z[5,0,1]  R568      -2.3231776058673859e-01
    z[5,0,1]  R569      -4.2521899938583374e-01
    z[5,0,1]  R570      -2.8838777542114258e-01
    z[5,0,1]  R571      -2.9415807127952576e-01
    z[5,0,1]  R572      -1.8136461079120636e-01
    z[5,0,1]  R573      0.614677906036377
    z[5,0,1]  R574      8.8259148597717285e-01
    z[5,0,1]  R575      -1.2112042307853699e-01
    z[5,0,1]  R576      -2.1046364307403564e-01
    z[5,0,1]  R577      8.1843149662017822e-01
    z[5,0,1]  R578      1.2217903882265091e-01
    z[5,0,1]  R579      4.1422221064567566e-01
    z[5,0,1]  R580      -5.2835303544998169e-01
    z[5,0,1]  R581      -6.0785013437271118e-01
    z[5,0,1]  R582      2.9621484875679016e-01
    z[5,0,1]  R583      1.9389666616916656e-01
    z[5,0,1]  R584      -1.0692614316940308e-01
    z[5,0,1]  R585      3.5085476934909821e-02
    z[5,0,1]  R586      0.0629362165927887
    z[5,0,1]  R587      1.1717350780963898e-01
    z[5,0,1]  R588      4.6073517203330994e-01
    z[5,0,1]  R589      7.1917676925659180e-01
    z[5,0,1]  R590      5.5513072013854980e-01
    z[5,0,1]  R591      -5.3189247846603394e-01
    z[5,0,1]  R592      1.9663409888744354e-01
    z[5,0,1]  R593      0.213766410946846
    z[5,0,1]  R594      3.8322755694389343e-01
    z[5,0,1]  R595      6.5201544761657715e-01
    z[5,0,1]  R596      3.3321052789688110e-01
    z[5,0,1]  R597      6.9712668657302856e-01
    z[5,0,1]  R598      6.4458996057510376e-01
    z[5,0,1]  R599      -5.9066683053970337e-01
    z[5,0,1]  R600      -9.1286391019821167e-01
    z[5,0,1]  R601      -0.74636310338974
    z[5,0,1]  R602      -0.783897876739502
    z[5,0,1]  R603      -4.5693665742874146e-01
    z[5,0,1]  R604      -0.637538731098175
    z[5,0,1]  R605      -7.2442001104354858e-01
    z[5,0,1]  R606      -5.1696652173995972e-01
    z[5,0,1]  R607      1.1333186924457550e-01
    z[5,0,1]  R608      -6.8740415573120117e-01
    z[5,0,1]  R609      -5.5598491430282593e-01
    z[5,0,1]  R610      -7.0357513427734375e-01
    z[5,0,1]  R611      2.2914955019950867e-01
    z[5,0,1]  R612      3.8495090603828430e-01
    z[5,0,1]  R613      6.1672019958496094e-01
    z[5,0,1]  R614      1.0403732955455780e-01
    z[5,0,1]  R615      2.6857027783989906e-02
    z[5,0,1]  R616      3.9084741473197937e-01
    z[5,0,1]  R617      -1.0710010677576065e-01
    z[5,0,1]  R618      4.6051979064941406e-01
    z[5,0,1]  R619      -7.3174512386322021e-01
    z[5,0,1]  R620      -9.7263120114803314e-02
    z[5,0,1]  R621      -8.4369462728500366e-01
    z[5,0,1]  R622      1.1094018071889877e-01
    z[5,0,1]  R623      5.9087282419204712e-01
    z[5,0,1]  R624      -1.5158358030021191e-02
    z[5,0,1]  R625      -4.9962759017944336e-02
    z[5,0,1]  R626      -3.1675678491592407e-01
    z[5,0,1]  R627      -1.8333867192268372e-01
    z[5,0,2]  R4        1
    z[5,0,2]  R49       -1
    z[5,0,2]  R518      -1
    z[5,0,2]  R519      1
    z[5,0,2]  R528      -6.1106526851654053e-01
    z[5,0,2]  R529      -6.1709243059158325e-01
    z[5,0,2]  R530      -4.1789144277572632e-01
    z[5,0,2]  R531      -4.7554206848144531e-01
    z[5,0,2]  R532      -6.7307806015014648e-01
    z[5,0,2]  R533      -5.5688637495040894e-01
    z[5,0,2]  R534      -2.8121533989906311e-01
    z[5,0,2]  R535      -0.698015570640564
    z[5,0,2]  R536      -5.9209811687469482e-01
    z[5,0,2]  R537      8.1579720973968506e-01
    z[5,0,2]  R538      7.7131724357604980e-01
    z[5,0,2]  R539      5.6596356630325317e-01
    z[5,0,2]  R540      0.581097424030304
    z[5,0,2]  R541      3.5194832831621170e-02
    z[5,0,2]  R542      5.5022466182708740e-01
    z[5,0,2]  R543      3.7467437982559204e-01
    z[5,0,2]  R544      0.185869038105011
    z[5,0,2]  R545      2.8341516852378845e-01
    z[5,0,2]  R546      4.6027562022209167e-01
    z[5,0,2]  R547      1.8549726903438568e-01
    z[5,0,2]  R548      -5.6430444121360779e-02
    z[5,0,2]  R549      5.4062587022781372e-01
    z[5,0,2]  R550      6.0086369514465332e-01
    z[5,0,2]  R551      -4.1874074935913086e-01
    z[5,0,2]  R552      5.0818151235580444e-01
    z[5,0,2]  R553      6.8316936492919922e-01
    z[5,0,2]  R554      -2.0684944093227386e-01
    z[5,0,2]  R555      4.9719268083572388e-01
    z[5,0,2]  R556      5.5894345045089722e-01
    z[5,0,2]  R557      5.4726940393447876e-01
    z[5,0,2]  R558      7.3217743635177612e-01
    z[5,0,2]  R559      4.2120260000228882e-01
    z[5,0,2]  R560      4.8127841949462891e-01
    z[5,0,2]  R561      3.1994324922561646e-01
    z[5,0,2]  R562      5.4639947414398193e-01
    z[5,0,2]  R563      4.6196100115776062e-01
    z[5,0,2]  R564      2.2199396789073944e-01
    z[5,0,2]  R565      -2.1182221174240112e-01
    z[5,0,2]  R566      -2.3711444437503815e-01
    z[5,0,2]  R567      -1.7014425992965698e-01
    z[5,0,2]  R568      -5.7488650083541870e-01
    z[5,0,2]  R569      -6.2625670433044434e-01
    z[5,0,2]  R570      -8.8665857911109924e-02
    z[5,0,2]  R571      -5.7745444774627686e-01
    z[5,0,2]  R572      -4.2030754685401917e-01
    z[5,0,2]  R573      -3.2679456472396851e-01
    z[5,0,2]  R574      2.3499237000942230e-01
    z[5,0,2]  R575      -2.5501725077629089e-01
    z[5,0,2]  R576      -6.5312135219573975e-01
    z[5,0,2]  R577      1.2549513578414917e-01
    z[5,0,2]  R578      -2.6208499073982239e-01
    z[5,0,2]  R579      3.5253354907035828e-01
    z[5,0,2]  R580      4.8182269930839539e-01
    z[5,0,2]  R581      3.8683211803436279e-01
    z[5,0,2]  R582      8.2693123817443848e-01
    z[5,0,2]  R583      8.0544006824493408e-01
    z[5,0,2]  R584      8.4311634302139282e-01
    z[5,0,2]  R585      8.9893138408660889e-01
    z[5,0,2]  R586      0.8321533203125
    z[5,0,2]  R587      9.1821324825286865e-01
    z[5,0,2]  R588      -7.1190494298934937e-01
    z[5,0,2]  R589      1.0455914773046970e-02
    z[5,0,2]  R590      2.5464800000190735e-01
    z[5,0,2]  R591      -5.5668348073959351e-01
    z[5,0,2]  R592      -0.676361620426178
    z[5,0,2]  R593      1.8518878519535065e-01
    z[5,0,2]  R594      -1.8845534324645996e-01
    z[5,0,2]  R595      -2.9361501336097717e-01
    z[5,0,2]  R596      1.4269612729549408e-02
    z[5,0,2]  R597      1.4455687999725342e-01
    z[5,0,2]  R598      -4.1292563080787659e-01
    z[5,0,2]  R599      -4.6847561001777649e-01
    z[5,0,2]  R600      2.1335519850254059e-01
    z[5,0,2]  R601      3.4986928105354309e-01
    z[5,0,2]  R602      -4.8542730510234833e-02
    z[5,0,2]  R603      -7.7823407948017120e-02
    z[5,0,2]  R604      -1.1915443092584610e-01
    z[5,0,2]  R605      3.6274176836013794e-01
    z[5,0,2]  R606      2.3225225508213043e-01
    z[5,0,2]  R607      -5.5932450294494629e-01
    z[5,0,2]  R608      1.0764485597610474e-01
    z[5,0,2]  R609      -8.8984228670597076e-02
    z[5,0,2]  R610      1.3610440492630005e-01
    z[5,0,2]  R611      -6.8699955940246582e-01
    z[5,0,2]  R612      1.8842889368534088e-01
    z[5,0,2]  R613      1.2623888254165649e-01
    z[5,0,2]  R614      -5.7087469100952148e-01
    z[5,0,2]  R615      2.1743780374526978e-01
    z[5,0,2]  R616      -6.2400847673416138e-01
    z[5,0,2]  R617      3.4387171268463135e-02
    z[5,0,2]  R618      -4.8959305882453918e-01
    z[5,0,2]  R619      2.3180879652500153e-01
    z[5,0,2]  R620      -4.3938422203063965e-01
    z[5,0,2]  R621      -2.0589542388916016e-01
    z[5,0,2]  R622      -1.7205569148063660e-01
    z[5,0,2]  R623      -2.3169048130512238e-02
    z[5,0,2]  R624      6.9852125644683838e-01
    z[5,0,2]  R625      0.470347136259079
    z[5,0,2]  R626      4.5164796710014343e-01
    z[5,0,2]  R627      3.8815578818321228e-01
    z[5,0,3]  R5        1
    z[5,0,3]  R50       -1
    z[5,0,3]  R520      -1
    z[5,0,3]  R521      1
    z[5,0,3]  R528      -5.2917140722274780e-01
    z[5,0,3]  R529      -3.5314863920211792e-01
    z[5,0,3]  R530      -6.0037565231323242e-01
    z[5,0,3]  R531      -5.5758535861968994e-01
    z[5,0,3]  R532      -1.6042657196521759e-01
    z[5,0,3]  R533      -3.3760768175125122e-01
    z[5,0,3]  R534      -7.8490930795669556e-01
    z[5,0,3]  R535      4.5755021274089813e-02
    z[5,0,3]  R536      -2.9018133878707886e-01
    z[5,0,3]  R537      1.0989991575479507e-01
    z[5,0,3]  R538      3.5300999879837036e-01
    z[5,0,3]  R539      3.8653177022933960e-01
    z[5,0,3]  R540      4.5291340351104736e-01
    z[5,0,3]  R541      1.9377514719963074e-01
    z[5,0,3]  R542      1.3471165299415588e-01
    z[5,0,3]  R543      2.3421159386634827e-01
    z[5,0,3]  R544      1.1017097532749176e-01
    z[5,0,3]  R545      7.6226450502872467e-02
    z[5,0,3]  R546      2.0796790719032288e-01
    z[5,0,3]  R547      1.4745345711708069e-01
    z[5,0,3]  R548      1.7238780856132507e-01
    z[5,0,3]  R549      -1.9658863544464111e-01
    z[5,0,3]  R550      6.6063910722732544e-01
    z[5,0,3]  R551      3.6536341905593872e-01
    z[5,0,3]  R552      -1.4940737187862396e-01
    z[5,0,3]  R553      4.5457309484481812e-01
    z[5,0,3]  R554      2.2941657900810242e-01
    z[5,0,3]  R555      -4.5434886217117310e-01
    z[5,0,3]  R556      6.7545793950557709e-02
    z[5,0,3]  R557      -3.8898780941963196e-02
    z[5,0,3]  R558      1.7104667425155640e-01
    z[5,0,3]  R559      -0.0592644065618515
    z[5,0,3]  R560      7.8499954938888550e-01
    z[5,0,3]  R561      -1.0627415776252747e-01
    z[5,0,3]  R562      4.4233056902885437e-01
    z[5,0,3]  R563      5.7241427898406982e-01
    z[5,0,3]  R564      7.3525249958038330e-01
    z[5,0,3]  R565      0.293355792760849
    z[5,0,3]  R566      7.2702729701995850e-01
    z[5,0,3]  R567      7.4696594476699829e-01
    z[5,0,3]  R568      -5.7408112287521362e-01
    z[5,0,3]  R569      -3.6551985144615173e-01
    z[5,0,3]  R570      -5.9628689289093018e-01
    z[5,0,3]  R571      -2.9741668701171875e-01
    z[5,0,3]  R572      -4.1337344050407410e-01
    z[5,0,3]  R573      2.0641303062438965e-01
    z[5,0,3]  R574      2.1087038516998291e-01
    z[5,0,3]  R575      -7.0434558391571045e-01
    z[5,0,3]  R576      8.4888547658920288e-02
    z[5,0,3]  R577      8.0051563680171967e-02
    z[5,0,3]  R578      7.6750802993774414e-01
    z[5,0,3]  R579      4.0120804309844971e-01
    z[5,0,3]  R580      5.6791716814041138e-01
    z[5,0,3]  R581      -3.0295112729072571e-01
    z[5,0,3]  R582      1.9151894748210907e-01
    z[5,0,3]  R583      1.3078117370605469e-01
    z[5,0,3]  R584      1.4946061372756958e-01
    z[5,0,3]  R585      0.159884512424469
    z[5,0,3]  R586      9.7060039639472961e-02
    z[5,0,3]  R587      2.1969486773014069e-01
    z[5,0,3]  R588      3.3871078491210938e-01
    z[5,0,3]  R589      4.5961785316467285e-01
    z[5,0,3]  R590      7.3579859733581543e-01
    z[5,0,3]  R591      8.0825246870517731e-02
    z[5,0,3]  R592      4.8096778988838196e-01
    z[5,0,3]  R593      8.0494147539138794e-01
    z[5,0,3]  R594      3.7761631608009338e-01
    z[5,0,3]  R595      1.8257418274879456e-01
    z[5,0,3]  R596      6.4273148775100708e-01
    z[5,0,3]  R597      2.2279354929924011e-01
    z[5,0,3]  R598      2.6987805962562561e-01
    z[5,0,3]  R599      1.9493977725505829e-01
    z[5,0,3]  R600      -1.9338284432888031e-01
    z[5,0,3]  R601      -0.388785719871521
    z[5,0,3]  R602      -1.7030143737792969e-01
    z[5,0,3]  R603      -2.7515235543251038e-01
    z[5,0,3]  R604      6.0826158523559570e-01
    z[5,0,3]  R605      1.6258460283279419e-01
    z[5,0,3]  R606      5.2279084920883179e-01
    z[5,0,3]  R607      -5.2511040121316910e-02
    z[5,0,3]  R608      -0.637824296951294
    z[5,0,3]  R609      -1.9327494502067566e-01
    z[5,0,3]  R610      -1.5178553760051727e-01
    z[5,0,3]  R611      5.1419204473495483e-01
    z[5,0,3]  R612      1.2139932811260223e-01
    z[5,0,3]  R613      3.3413335680961609e-02
    z[5,0,3]  R614      -4.9365319311618805e-02
    z[5,0,3]  R615      2.4444395303726196e-01
    z[5,0,3]  R616      -1.7017644643783569e-01
    z[5,0,3]  R617      5.3708422183990479e-01
    z[5,0,3]  R618      6.0811394453048706e-01
    z[5,0,3]  R619      -3.2972010970115662e-01
    z[5,0,3]  R620      7.2953003644943237e-01
    z[5,0,3]  R621      -2.7185928821563721e-01
    z[5,0,3]  R622      8.5692560672760010e-01
    z[5,0,3]  R623      -6.7722752690315247e-02
    z[5,0,3]  R624      -1.6869744658470154e-01
    z[5,0,3]  R625      -1.0491450130939484e-01
    z[5,0,3]  R626      2.3639321327209473e-01
    z[5,0,3]  R627      -5.7837799191474915e-02
    z[5,0,4]  R6        1
    z[5,0,4]  R51       -1
    z[5,0,4]  R522      -1
    z[5,0,4]  R523      1
    z[5,0,4]  R528      -3.2975059747695923e-01
    z[5,0,4]  R529      -3.2270956039428711e-01
    z[5,0,4]  R530      -1.6008014976978302e-01
    z[5,0,4]  R531      1.6464999318122864e-01
    z[5,0,4]  R532      -3.6174979805946350e-01
    z[5,0,4]  R533      -5.6766338646411896e-02
    z[5,0,4]  R534      3.8014256954193115e-01
    z[5,0,4]  R535      -5.4628050327301025e-01
    z[5,0,4]  R536      2.1887996792793274e-01
    z[5,0,4]  R537      -5.3625606000423431e-02
    z[5,0,4]  R538      -9.6041090786457062e-02
    z[5,0,4]  R539      -3.7073828279972076e-02
    z[5,0,4]  R540      -4.5687353610992432e-01
    z[5,0,4]  R541      -1.9509927928447723e-01
    z[5,0,4]  R542      -3.6990082263946533e-01
    z[5,0,4]  R543      -5.9515666216611862e-02
    z[5,0,4]  R544      -7.7582925558090210e-02
    z[5,0,4]  R545      -1.1067941784858704e-01
    z[5,0,4]  R546      -1.4172458648681641e-01
    z[5,0,4]  R547      5.7703603059053421e-02
    z[5,0,4]  R548      5.5482137203216553e-01
    z[5,0,4]  R549      -3.2768428325653076e-02
    z[5,0,4]  R550      -1.7064218409359455e-03
    z[5,0,4]  R551      8.1124818325042725e-01
    z[5,0,4]  R552      5.6696657091379166e-02
    z[5,0,4]  R553      1.9953319430351257e-01
    z[5,0,4]  R554      8.9923244714736938e-01
    z[5,0,4]  R555      -2.0589552819728851e-01
    z[5,0,4]  R556      -1.0547125339508057e-01
    z[5,0,4]  R557      -3.1715796794742346e-03
    z[5,0,4]  R558      -2.3647494614124298e-01
    z[5,0,4]  R559      2.3328827694058418e-02
    z[5,0,4]  R560      -9.8830483853816986e-02
    z[5,0,4]  R561      1.6807280480861664e-01
    z[5,0,4]  R562      -6.0537587851285934e-02
    z[5,0,4]  R563      -1.5713594853878021e-01
    z[5,0,4]  R564      -1.3777065277099609e-01
    z[5,0,4]  R565      2.1798150241374969e-01
    z[5,0,4]  R566      4.3557864427566528e-01
    z[5,0,4]  R567      3.2727840542793274e-01
    z[5,0,4]  R568      8.9604228734970093e-02
    z[5,0,4]  R569      -2.8744882345199585e-01
    z[5,0,4]  R570      2.0206996798515320e-01
    z[5,0,4]  R571      4.4445816427469254e-02
    z[5,0,4]  R572      5.0837200880050659e-01
    z[5,0,4]  R573      -4.3901059031486511e-01
    z[5,0,4]  R574      1.6942851245403290e-01
    z[5,0,4]  R575      -1.9649676978588104e-02
    z[5,0,4]  R576      4.6485564112663269e-01
    z[5,0,4]  R577      -3.1988048553466797e-01
    z[5,0,4]  R578      4.0406605601310730e-01
    z[5,0,4]  R579      -0.0986860916018486
    z[5,0,4]  R580      1.2505438923835754e-01
    z[5,0,4]  R581      -4.3657961487770081e-01
    z[5,0,4]  R582      2.2704254090785980e-01
    z[5,0,4]  R583      -1.2737950682640076e-01
    z[5,0,4]  R584      -1.2335945852100849e-02
    z[5,0,4]  R585      -1.8066802620887756e-01
    z[5,0,4]  R586      1.6324238479137421e-01
    z[5,0,4]  R587      6.8727836012840271e-02
    z[5,0,4]  R588      2.3454587161540985e-01
    z[5,0,4]  R589      5.1327306032180786e-01
    z[5,0,4]  R590      -1.1139550060033798e-01
    z[5,0,4]  R591      3.7365466356277466e-01
    z[5,0,4]  R592      1.5394628047943115e-01
    z[5,0,4]  R593      3.2040628790855408e-01
    z[5,0,4]  R594      3.3972853422164917e-01
    z[5,0,4]  R595      -6.4457327127456665e-02
    z[5,0,4]  R596      -2.8373605012893677e-01
    z[5,0,4]  R597      -3.2385626435279846e-01
    z[5,0,4]  R598      3.6158025264739990e-02
    z[5,0,4]  R599      2.8707557916641235e-01
    z[5,0,4]  R600      -2.1785897016525269e-01
    z[5,0,4]  R601      1.3910777866840363e-01
    z[5,0,4]  R602      -3.3459064364433289e-01
    z[5,0,4]  R603      -6.3165277242660522e-02
    z[5,0,4]  R604      -3.0165541172027588e-01
    z[5,0,4]  R605      3.2457414269447327e-01
    z[5,0,4]  R606      -6.5735457465052605e-03
    z[5,0,4]  R607      -4.6645230054855347e-01
    z[5,0,4]  R608      -2.1367374062538147e-01
    z[5,0,4]  R609      2.4187627434730530e-01
    z[5,0,4]  R610      0.53766930103302
    z[5,0,4]  R611      -3.9414870738983154e-01
    z[5,0,4]  R612      3.7524050474166870e-01
    z[5,0,4]  R613      -4.3254144489765167e-02
    z[5,0,4]  R614      -1.3490395247936249e-01
    z[5,0,4]  R615      -2.7130043506622314e-01
    z[5,0,4]  R616      -1.6369469463825226e-02
    z[5,0,4]  R617      8.4502868354320526e-02
    z[5,0,4]  R618      2.5334203243255615e-01
    z[5,0,4]  R619      -3.5510438680648804e-01
    z[5,0,4]  R620      -4.4641056656837463e-01
    z[5,0,4]  R621      1.5092290937900543e-02
    z[5,0,4]  R622      -2.3525262251496315e-02
    z[5,0,4]  R623      -0.0577346533536911
    z[5,0,4]  R624      6.4896240830421448e-02
    z[5,0,4]  R625      -1.4085040986537933e-01
    z[5,0,4]  R626      9.8788976669311523e-02
    z[5,0,4]  R627      -4.1376795619726181e-02
    z[5,0,5]  R7        1
    z[5,0,5]  R52       -1
    z[5,0,5]  R524      -1
    z[5,0,5]  R525      1
    z[5,0,5]  R528      -1.9581261277198792e-01
    z[5,0,5]  R529      -1.5446981787681580e-01
    z[5,0,5]  R530      -2.6942875981330872e-01
    z[5,0,5]  R531      -1.8457669019699097e-01
    z[5,0,5]  R532      -2.7567198872566223e-01
    z[5,0,5]  R533      -3.3022406697273254e-01
    z[5,0,5]  R534      -2.6450985670089722e-01
    z[5,0,5]  R535      -1.7573808133602142e-01
    z[5,0,5]  R536      3.1393748521804810e-01
    z[5,0,5]  R537      2.1167731285095215e-01
    z[5,0,5]  R538      3.1547054648399353e-01
    z[5,0,5]  R539      2.2521814703941345e-01
    z[5,0,5]  R540      2.8799504041671753e-01
    z[5,0,5]  R541      1.0257090628147125e-01
    z[5,0,5]  R542      2.4985921382904053e-01
    z[5,0,5]  R543      1.1288130283355713e-01
    z[5,0,5]  R544      5.4335236549377441e-02
    z[5,0,5]  R545      1.1946207284927368e-01
    z[5,0,5]  R546      2.2022227942943573e-01
    z[5,0,5]  R547      8.3384037017822266e-02
    z[5,0,5]  R548      -2.4482456967234612e-02
    z[5,0,5]  R549      1.6232512891292572e-01
    z[5,0,5]  R550      2.6613163948059082e-01
    z[5,0,5]  R551      -1.0773230344057083e-01
    z[5,0,5]  R552      9.4823047518730164e-02
    z[5,0,5]  R553      2.7530258893966675e-01
    z[5,0,5]  R554      -1.1338969320058823e-01
    z[5,0,5]  R555      4.9063485860824585e-01
    z[5,0,5]  R556      1.9328027963638306e-01
    z[5,0,5]  R557      3.6383220553398132e-01
    z[5,0,5]  R558      2.1385115385055542e-01
    z[5,0,5]  R559      1.1175382137298584e-01
    z[5,0,5]  R560      2.8542625904083252e-01
    z[5,0,5]  R561      3.2299514859914780e-02
    z[5,0,5]  R562      2.3050366342067719e-01
    z[5,0,5]  R563      2.7703121304512024e-01
    z[5,0,5]  R564      2.7160212397575378e-01
    z[5,0,5]  R565      1.3086847029626369e-02
    z[5,0,5]  R566      7.5679324567317963e-02
    z[5,0,5]  R567      1.4883327484130859e-01
    z[5,0,5]  R568      1.2492982298135757e-01
    z[5,0,5]  R569      0.175779327750206
    z[5,0,5]  R570      3.8542658090591431e-02
    z[5,0,5]  R571      -5.6672483682632446e-01
    z[5,0,5]  R572      -5.7694405317306519e-01
    z[5,0,5]  R573      3.2612487673759460e-01
    z[5,0,5]  R574      -2.9808858036994934e-01
    z[5,0,5]  R575      -4.0076601505279541e-01
    z[5,0,5]  R576      -3.8645300269126892e-01
    z[5,0,5]  R577      1.7766506969928741e-01
    z[5,0,5]  R578      -1.6486328095197678e-02
    z[5,0,5]  R579      0.503727912902832
    z[5,0,5]  R580      0.0744536742568016
    z[5,0,5]  R581      -9.5156140625476837e-02
    z[5,0,5]  R582      1.6693204641342163e-01
    z[5,0,5]  R583      0.0472993366420269
    z[5,0,5]  R584      1.6686005890369415e-01
    z[5,0,5]  R585      1.1024153977632523e-01
    z[5,0,5]  R586      2.0623014867305756e-01
    z[5,0,5]  R587      6.2137570232152939e-02
    z[5,0,5]  R588      9.5437504351139069e-02
    z[5,0,5]  R589      -6.5168537199497223e-02
    z[5,0,5]  R590      2.6004728674888611e-01
    z[5,0,5]  R591      -5.0996005535125732e-01
    z[5,0,5]  R592      -8.8554620742797852e-02
    z[5,0,5]  R593      -2.4945183098316193e-01
    z[5,0,5]  R594      -1.1956793069839478e-01
    z[5,0,5]  R595      2.5355464220046997e-01
    z[5,0,5]  R596      -1.7481237649917603e-01
    z[5,0,5]  R597      1.9550228118896484e-01
    z[5,0,5]  R598      1.8047341704368591e-01
    z[5,0,5]  R599      -3.0346742272377014e-01
    z[5,0,5]  R600      -7.9076945781707764e-02
    z[5,0,5]  R601      -1.2368068844079971e-01
    z[5,0,5]  R602      -3.5012704133987427e-01
    z[5,0,5]  R603      -3.4012833237648010e-01
    z[5,0,5]  R604      7.3924213647842407e-02
    z[5,0,5]  R605      6.5081994980573654e-03
    z[5,0,5]  R606      3.1589362025260925e-01
    z[5,0,5]  R607      -1.6483667492866516e-01
    z[5,0,5]  R608      -7.4559226632118225e-02
    z[5,0,5]  R609      -5.8781629800796509e-01
    z[5,0,5]  R610      -3.9033353328704834e-01
    z[5,0,5]  R611      -5.8267004787921906e-02
    z[5,0,5]  R612      4.9076753854751587e-01
    z[5,0,5]  R613      0.244783416390419
    z[5,0,5]  R614      -2.7149847149848938e-01
    z[5,0,5]  R615      6.3544875383377075e-01
    z[5,0,5]  R616      -2.7017769217491150e-01
    z[5,0,5]  R617      3.8683155179023743e-01
    z[5,0,5]  R618      5.0349522382020950e-02
    z[5,0,5]  R619      9.5458760857582092e-02
    z[5,0,5]  R620      1.5454442799091339e-01
    z[5,0,5]  R621      -4.0873834490776062e-01
    z[5,0,5]  R622      2.3882275447249413e-02
    z[5,0,5]  R623      5.4946172237396240e-01
    z[5,0,5]  R624      2.4371053278446198e-01
    z[5,0,5]  R625      4.0685775876045227e-01
    z[5,0,5]  R626      2.0834033191204071e-01
    z[5,0,5]  R627      2.9766580462455750e-01
    z[5,0,6]  R8        1
    z[5,0,6]  R53       -1
    z[5,0,6]  R526      -1
    z[5,0,6]  R527      1
    z[5,0,6]  R528      0.39483642578125
    z[5,0,6]  R529      4.1094845533370972e-01
    z[5,0,6]  R530      -2.7579185366630554e-01
    z[5,0,6]  R531      5.0886821746826172e-01
    z[5,0,6]  R532      -5.3629726171493530e-01
    z[5,0,6]  R533      -0.660996675491333
    z[5,0,6]  R534      1.2309314310550690e-01
    z[5,0,6]  R535      -2.7382916212081909e-01
    z[5,0,6]  R536      1.3197000138461590e-02
    z[5,0,6]  R537      -2.3683875799179077e-01
    z[5,0,6]  R538      1.4986149966716766e-01
    z[5,0,6]  R539      -9.7660243511199951e-02
    z[5,0,6]  R540      -3.6668688058853149e-02
    z[5,0,6]  R541      9.7606927156448364e-02
    z[5,0,6]  R542      2.8507539629936218e-01
    z[5,0,6]  R543      -1.9734199345111847e-01
    z[5,0,6]  R544      -0.077787384390831
    z[5,0,6]  R545      1.8730445206165314e-01
    z[5,0,6]  R546      2.8510499000549316e-01
    z[5,0,6]  R547      1.3623951375484467e-01
    z[5,0,6]  R548      -1.2113806605339050e-01
    z[5,0,6]  R549      2.2376336157321930e-01
    z[5,0,6]  R550      -3.0174696445465088e-01
    z[5,0,6]  R551      -2.8764383867383003e-02
    z[5,0,6]  R552      -2.3102907463908195e-02
    z[5,0,6]  R553      1.6892101615667343e-02
    z[5,0,6]  R554      -2.1939021348953247e-01
    z[5,0,6]  R555      2.3734977841377258e-01
    z[5,0,6]  R556      1.3645261526107788e-01
    z[5,0,6]  R557      3.5766372084617615e-01
    z[5,0,6]  R558      -2.3777644336223602e-01
    z[5,0,6]  R559      6.8924024701118469e-02
    z[5,0,6]  R560      -1.7019283771514893e-01
    z[5,0,6]  R561      -2.3284508287906647e-01
    z[5,0,6]  R562      -1.3061454892158508e-01
    z[5,0,6]  R563      9.3289464712142944e-02
    z[5,0,6]  R564      2.4649918079376221e-01
    z[5,0,6]  R565      9.6176296472549438e-02
    z[5,0,6]  R566      1.7258486151695251e-01
    z[5,0,6]  R567      3.1061553955078125e-01
    z[5,0,6]  R568      1.3191461563110352e-01
    z[5,0,6]  R569      0.0874442458152771
    z[5,0,6]  R570      -4.4186714291572571e-01
    z[5,0,6]  R571      -3.0732482671737671e-01
    z[5,0,6]  R572      -5.3932290524244308e-02
    z[5,0,6]  R573      -0.401030957698822
    z[5,0,6]  R574      -2.5396207347512245e-02
    z[5,0,6]  R575      -4.6218344569206238e-01
    z[5,0,6]  R576      -3.9516305923461914e-01
    z[5,0,6]  R577      -4.1228723526000977e-01
    z[5,0,6]  R578      3.7462085485458374e-01
    z[5,0,6]  R579      5.2376669645309448e-01
    z[5,0,6]  R580      -1.5266944468021393e-01
    z[5,0,6]  R581      2.0077311992645264e-01
    z[5,0,6]  R582      2.9434624314308167e-01
    z[5,0,6]  R583      0.16197469830513
    z[5,0,6]  R584      0.0212846789509058
    z[5,0,6]  R585      6.1095900833606720e-02
    z[5,0,6]  R586      -2.5218958035111427e-02
    z[5,0,6]  R587      -1.1041018366813660e-01
    z[5,0,6]  R588      1.9928197562694550e-01
    z[5,0,6]  R589      8.4426812827587128e-03
    z[5,0,6]  R590      -4.0857456624507904e-02
    z[5,0,6]  R591      0.0263714250177145
    z[5,0,6]  R592      -3.8630792498588562e-01
    z[5,0,6]  R593      -2.9359987378120422e-01
    z[5,0,6]  R594      -6.8870788812637329e-01
    z[5,0,6]  R595      5.9921962022781372e-01
    z[5,0,6]  R596      -3.0938610434532166e-02
    z[5,0,6]  R597      2.7243435382843018e-01
    z[5,0,6]  R598      -4.6066647768020630e-01
    z[5,0,6]  R599      -2.8735786676406860e-01
    z[5,0,6]  R600      -1.0418348759412766e-01
    z[5,0,6]  R601      3.6686885356903076e-01
    z[5,0,6]  R602      1.9505521282553673e-02
    z[5,0,6]  R603      5.7073158025741577e-01
    z[5,0,6]  R604      -1.5794268250465393e-01
    z[5,0,6]  R605      3.0939567089080811e-01
    z[5,0,6]  R606      2.5403586030006409e-01
    z[5,0,6]  R607      3.1916892528533936e-01
    z[5,0,6]  R608      2.3045334219932556e-01
    z[5,0,6]  R609      2.3487238585948944e-01
    z[5,0,6]  R610      1.5198100358247757e-02
    z[5,0,6]  R611      -1.3912385702133179e-01
    z[5,0,6]  R612      2.2606596350669861e-01
    z[5,0,6]  R613      2.0908632874488831e-01
    z[5,0,6]  R614      5.1905751228332520e-01
    z[5,0,6]  R615      -1.1375757306814194e-01
    z[5,0,6]  R616      3.3053648471832275e-01
    z[5,0,6]  R617      -1.7875127494335175e-01
    z[5,0,6]  R618      -1.7471471428871155e-01
    z[5,0,6]  R619      -3.0696097016334534e-01
    z[5,0,6]  R620      -1.4413294196128845e-01
    z[5,0,6]  R621      -1.9780771806836128e-02
    z[5,0,6]  R622      -4.2399564385414124e-01
    z[5,0,6]  R623      3.5136872529983521e-01
    z[5,0,6]  R624      2.3495469987392426e-01
    z[5,0,6]  R625      -0.0321926586329937
    z[5,0,6]  R626      5.2557539194822311e-02
    z[5,0,6]  R627      2.3745338618755341e-01
    z[1,2,0]  R11       -1
    z[1,2,0]  R20       1
    z[1,2,0]  R702      -1
    z[1,2,0]  R703      1
    z[1,2,0]  R716      -6.5858542919158936e-01
    z[1,2,0]  R717      -6.5801924467086792e-01
    z[1,2,0]  R718      -7.1887493133544922e-01
    z[1,2,0]  R719      -4.1052407026290894e-01
    z[1,2,0]  R720      -7.1989625692367554e-01
    z[1,2,0]  R721      -0.59494549036026
    z[1,2,0]  R722      -5.6977653503417969e-01
    z[1,2,0]  R723      -6.3382625579833984e-01
    z[1,2,0]  R724      -0.820820689201355
    z[1,2,0]  R725      -0.791208803653717
    z[1,2,0]  R726      -1.5829540789127350e-01
    z[1,2,0]  R727      1.0571720451116562e-01
    z[1,2,0]  R728      9.0164765715599060e-02
    z[1,2,0]  R729      2.3170144855976105e-01
    z[1,2,0]  R730      1.9998101890087128e-01
    z[1,2,0]  R731      4.8847761750221252e-01
    z[1,2,0]  R732      2.9615685343742371e-01
    z[1,2,0]  R733      3.3222836256027222e-01
    z[1,2,0]  R734      3.5924544930458069e-01
    z[1,2,0]  R735      2.8316259384155273e-01
    z[1,2,0]  R736      4.6913135051727295e-01
    z[1,2,0]  R737      5.9548223018646240e-01
    z[1,2,0]  R738      5.5419504642486572e-01
    z[1,2,0]  R739      7.1332257986068726e-01
    z[1,2,0]  R740      0.413044273853302
    z[1,2,0]  R741      -4.1304641962051392e-01
    z[1,2,0]  R742      4.5895689725875854e-01
    z[1,2,0]  R743      5.3956449031829834e-01
    z[1,2,0]  R744      1.8347802758216858e-01
    z[1,2,0]  R745      8.0835449695587158e-01
    z[1,2,0]  R746      -2.6094338297843933e-01
    z[1,2,0]  R747      -1.0375731438398361e-01
    z[1,2,0]  R748      -1.1744309961795807e-01
    z[1,2,0]  R749      1.6161955893039703e-01
    z[1,2,0]  R750      4.5744961500167847e-01
    z[1,2,0]  R751      2.7871596813201904e-01
    z[1,2,0]  R752      2.7719014883041382e-01
    z[1,2,0]  R753      1.2179224193096161e-01
    z[1,2,0]  R754      -6.3695102930068970e-02
    z[1,2,0]  R755      0.629237711429596
    z[1,2,0]  R756      3.9095136523246765e-01
    z[1,2,0]  R757      3.6560770124197006e-02
    z[1,2,0]  R758      1.7770273983478546e-01
    z[1,2,0]  R759      1.4492644369602203e-01
    z[1,2,0]  R760      0.556480348110199
    z[1,2,0]  R761      5.0131708383560181e-01
    z[1,2,0]  R762      2.5523781776428223e-01
    z[1,2,0]  R763      -1.5742602944374084e-01
    z[1,2,0]  R764      4.6901664137840271e-01
    z[1,2,0]  R765      -0.0424308106303215
    z[1,2,0]  R766      2.9013910889625549e-01
    z[1,2,0]  R767      -2.6687833666801453e-01
    z[1,2,0]  R768      8.5017897188663483e-02
    z[1,2,0]  R769      -1.7064388096332550e-01
    z[1,2,0]  R770      7.6443380117416382e-01
    z[1,2,0]  R771      1.9689476490020752e-01
    z[1,2,0]  R772      8.2556062936782837e-01
    z[1,2,0]  R773      -1.2607698142528534e-01
    z[1,2,0]  R774      7.0532029867172241e-01
    z[1,2,0]  R775      0.554187536239624
    z[1,2,0]  R776      0.498337984085083
    z[1,2,0]  R777      1.3690540194511414e-01
    z[1,2,0]  R778      2.0153930783271790e-01
    z[1,2,0]  R779      3.8671070337295532e-01
    z[1,2,0]  R780      -7.6744019985198975e-02
    z[1,2,0]  R781      2.1289205551147461e-01
    z[1,2,0]  R782      -1.2130734324455261e-01
    z[1,2,0]  R783      4.4750612229108810e-02
    z[1,2,0]  R784      -1.3699607551097870e-01
    z[1,2,0]  R785      1.7185197770595551e-01
    z[1,2,0]  R786      3.0488875508308411e-01
    z[1,2,0]  R787      -2.1510450541973114e-01
    z[1,2,0]  R788      -4.6034038066864014e-01
    z[1,2,0]  R789      4.8502811789512634e-01
    z[1,2,0]  R790      3.1340980529785156e-01
    z[1,2,0]  R791      -3.1027961522340775e-02
    z[1,2,0]  R792      1.2311228550970554e-02
    z[1,2,0]  R793      6.5089219808578491e-01
    z[1,2,0]  R794      2.2151054814457893e-02
    z[1,2,0]  R795      6.4380139112472534e-01
    z[1,2,0]  R796      -1.6967041790485382e-01
    z[1,2,0]  R797      -1.3388785719871521e-01
    z[1,2,0]  R798      3.0542594194412231e-01
    z[1,2,0]  R799      -0.77823805809021
    z[1,2,0]  R800      -7.9751676321029663e-01
    z[1,2,0]  R801      -8.5658162832260132e-01
    z[1,2,0]  R802      -8.0390030145645142e-01
    z[1,2,0]  R803      -7.7379405498504639e-01
    z[1,2,0]  R804      -8.9063447713851929e-01
    z[1,2,0]  R805      -1.7608661949634552e-01
    z[1,2,0]  R806      1.0001166909933090e-01
    z[1,2,0]  R807      4.4433104991912842e-01
    z[1,2,0]  R808      3.6617133021354675e-01
    z[1,2,0]  R809      1.9942130148410797e-01
    z[1,2,0]  R810      -1.2687428295612335e-01
    z[1,2,0]  R811      -3.5667607188224792e-01
    z[1,2,0]  R812      -5.2196753025054932e-01
    z[1,2,0]  R813      -2.4494828283786774e-01
    z[1,2,0]  R814      -7.5037801265716553e-01
    z[1,2,0]  R815      1.8949049711227417e-01
    z[1,2,0]  R816      -6.1510574817657471e-01
    z[1,2,0]  R817      -3.4907853603363037e-01
    z[1,2,0]  R818      -1.6321410238742828e-01
    z[1,2,0]  R819      -3.3627992868423462e-01
    z[1,2,0]  R820      1.2292774766683578e-01
    z[1,2,0]  R821      1.1723812669515610e-01
    z[1,2,0]  R822      2.9016089439392090e-01
    z[1,2,0]  R823      2.1073332428932190e-01
    z[1,2,0]  R824      1.3649851083755493e-01
    z[1,2,0]  R825      3.8373467326164246e-01
    z[1,2,1]  R12       -1
    z[1,2,1]  R21       1
    z[1,2,1]  R704      -1
    z[1,2,1]  R705      1
    z[1,2,1]  R716      -1.8033710122108459e-01
    z[1,2,1]  R717      -2.2804026305675507e-01
    z[1,2,1]  R718      -6.2383204698562622e-02
    z[1,2,1]  R719      -2.5859877467155457e-01
    z[1,2,1]  R720      -9.5601566135883331e-02
    z[1,2,1]  R721      -1.7058271169662476e-01
    z[1,2,1]  R722      -1.5964622795581818e-01
    z[1,2,1]  R723      -1.4073713123798370e-01
    z[1,2,1]  R724      -2.7701035141944885e-01
    z[1,2,1]  R725      -1.3329532742500305e-01
    z[1,2,1]  R726      0.804551362991333
    z[1,2,1]  R727      8.0172097682952881e-01
    z[1,2,1]  R728      8.9155030250549316e-01
    z[1,2,1]  R729      8.1907963752746582e-01
    z[1,2,1]  R730      8.7900412082672119e-01
    z[1,2,1]  R731      8.1295800209045410e-01
    z[1,2,1]  R732      7.5687986612319946e-01
    z[1,2,1]  R733      7.5830638408660889e-01
    z[1,2,1]  R734      7.4715173244476318e-01
    z[1,2,1]  R735      7.0336920022964478e-01
    z[1,2,1]  R736      -2.7622026205062866e-01
    z[1,2,1]  R737      -3.9142203330993652e-01
    z[1,2,1]  R738      -0.248797208070755
    z[1,2,1]  R739      -2.4576936662197113e-01
    z[1,2,1]  R740      -2.1434900164604187e-01
    z[1,2,1]  R741      1.0257773846387863e-01
    z[1,2,1]  R742      -1.3534389436244965e-01
    z[1,2,1]  R743      -1.5342769026756287e-01
    z[1,2,1]  R744      -2.4239315092563629e-01
    z[1,2,1]  R745      1.2143120914697647e-01
    z[1,2,1]  R746      5.4998785257339478e-01
    z[1,2,1]  R747      -7.4844092130661011e-01
    z[1,2,1]  R748      -5.1669752597808838e-01
    z[1,2,1]  R749      2.8788894414901733e-01
    z[1,2,1]  R750      -7.5884765386581421e-01
    z[1,2,1]  R751      -5.1433372497558594e-01
    z[1,2,1]  R752      -5.9484966099262238e-02
    z[1,2,1]  R753      5.6977644562721252e-02
    z[1,2,1]  R754      -9.7424782812595367e-02
    z[1,2,1]  R755      3.4643688797950745e-01
    z[1,2,1]  R756      -7.4864143133163452e-01
    z[1,2,1]  R757      -7.6750653982162476e-01
    z[1,2,1]  R758      -0.63265460729599
    z[1,2,1]  R759      -7.0288920402526855e-01
    z[1,2,1]  R760      -6.0325086116790771e-01
    z[1,2,1]  R761      -6.3913995027542114e-01
    z[1,2,1]  R762      3.4777700901031494e-01
    z[1,2,1]  R763      1.0955148190259933e-01
    z[1,2,1]  R764      3.3840516209602356e-01
    z[1,2,1]  R765      2.0106829702854156e-01
    z[1,2,1]  R766      2.3183113336563110e-01
    z[1,2,1]  R767      4.2090049386024475e-01
    z[1,2,1]  R768      4.7850003838539124e-01
    z[1,2,1]  R769      5.1707899570465088e-01
    z[1,2,1]  R770      4.5963954925537109e-01
    z[1,2,1]  R771      2.8990250825881958e-01
    z[1,2,1]  R772      6.1392839998006821e-02
    z[1,2,1]  R773      -6.5599137544631958e-01
    z[1,2,1]  R774      4.3035867810249329e-01
    z[1,2,1]  R775      4.1396754980087280e-01
    z[1,2,1]  R776      -5.6772458553314209e-01
    z[1,2,1]  R777      -4.0542924404144287e-01
    z[1,2,1]  R778      -2.9511788487434387e-01
    z[1,2,1]  R779      4.9987000226974487e-01
    z[1,2,1]  R780      4.4165849685668945e-01
    z[1,2,1]  R781      4.4861632585525513e-01
    z[1,2,1]  R782      0.58297199010849
    z[1,2,1]  R783      -0.700998842716217
    z[1,2,1]  R784      2.2690226137638092e-01
    z[1,2,1]  R785      -0.0210583433508873
    z[1,2,1]  R786      6.1287569999694824e-01
    z[1,2,1]  R787      -7.1970504522323608e-01
    z[1,2,1]  R788      -5.1845723390579224e-01
    z[1,2,1]  R789      5.7428580522537231e-01
    z[1,2,1]  R790      3.9865252375602722e-01
    z[1,2,1]  R791      -2.9648298025131226e-01
    z[1,2,1]  R792      3.0242647975683212e-02
    z[1,2,1]  R793      1.9152933359146118e-01
    z[1,2,1]  R794      7.7534466981887817e-01
    z[1,2,1]  R795      2.0321662724018097e-01
    z[1,2,1]  R796      7.5533652305603027e-01
    z[1,2,1]  R797      1.5082035958766937e-01
    z[1,2,1]  R798      3.2670933008193970e-01
    z[1,2,1]  R799      -8.6420841515064240e-02
    z[1,2,1]  R800      -9.3506224453449249e-02
    z[1,2,1]  R801      -8.2904092967510223e-02
    z[1,2,1]  R802      7.6480291783809662e-02
    z[1,2,1]  R803      -4.5369766652584076e-02
    z[1,2,1]  R804      -4.7882851213216782e-02
    z[1,2,1]  R805      -1.4118745923042297e-01
    z[1,2,1]  R806      1.1222476139664650e-02
    z[1,2,1]  R807      4.5571732521057129e-01
    z[1,2,1]  R808      -4.6389934420585632e-01
    z[1,2,1]  R809      -4.7327658534049988e-01
    z[1,2,1]  R810      -4.2640617489814758e-01
    z[1,2,1]  R811      -4.0584355592727661e-01
    z[1,2,1]  R812      -0.498304545879364
    z[1,2,1]  R813      -0.765228807926178
    z[1,2,1]  R814      -4.2069500684738159e-01
    z[1,2,1]  R815      -3.6247938871383667e-01
    z[1,2,1]  R816      -5.1551681756973267e-01
    z[1,2,1]  R817      -7.5431865453720093e-01
    z[1,2,1]  R818      -4.4682428240776062e-01
    z[1,2,1]  R819      -7.0357149839401245e-01
    z[1,2,1]  R820      -6.1069816350936890e-01
    z[1,2,1]  R821      -6.9779038429260254e-01
    z[1,2,1]  R822      -0.66790372133255
    z[1,2,1]  R823      -7.9137659072875977e-01
    z[1,2,1]  R824      -6.8418294191360474e-01
    z[1,2,1]  R825      -7.2239428758621216e-01
    z[1,2,2]  R13       -1
    z[1,2,2]  R22       1
    z[1,2,2]  R706      -1
    z[1,2,2]  R707      1
    z[1,2,2]  R716      3.6491009593009949e-01
    z[1,2,2]  R717      8.3101242780685425e-02
    z[1,2,2]  R718      1.5813589096069336e-01
    z[1,2,2]  R719      4.2543417215347290e-01
    z[1,2,2]  R720      2.5178456306457520e-01
    z[1,2,2]  R721      6.8271708488464355e-01
    z[1,2,2]  R722      -3.4442096948623657e-01
    z[1,2,2]  R723      -1.5313203446567059e-02
    z[1,2,2]  R724      4.7069203108549118e-02
    z[1,2,2]  R725      -2.3530335724353790e-01
    z[1,2,2]  R726      2.4600613117218018e-01
    z[1,2,2]  R727      1.5599825978279114e-01
    z[1,2,2]  R728      1.8806867301464081e-01
    z[1,2,2]  R729      4.3373140692710876e-01
    z[1,2,2]  R730      -9.5579192042350769e-02
    z[1,2,2]  R731      0.0797993540763855
    z[1,2,2]  R732      6.5456248819828033e-02
    z[1,2,2]  R733      -2.2454971075057983e-01
    z[1,2,2]  R734      1.0154710710048676e-01
    z[1,2,2]  R735      3.5156715661287308e-02
    z[1,2,2]  R736      3.8920834660530090e-02
    z[1,2,2]  R737      -5.9202855825424194e-01
    z[1,2,2]  R738      -5.0289428234100342e-01
    z[1,2,2]  R739      -2.5969842076301575e-01
    z[1,2,2]  R740      -2.9287990927696228e-01
    z[1,2,2]  R741      -5.1057970523834229e-01
    z[1,2,2]  R742      -2.9195931553840637e-01
    z[1,2,2]  R743      -1.5345829725265503e-01
    z[1,2,2]  R744      -5.4529237747192383e-01
    z[1,2,2]  R745      -2.5295522809028625e-01
    z[1,2,2]  R746      9.3944780528545380e-02
    z[1,2,2]  R747      -4.6293100714683533e-01
    z[1,2,2]  R748      -6.5030390024185181e-01
    z[1,2,2]  R749      4.0662553906440735e-01
    z[1,2,2]  R750      4.1330105066299438e-01
    z[1,2,2]  R751      -3.1752744317054749e-01
    z[1,2,2]  R752      -8.1574696302413940e-01
    z[1,2,2]  R753      3.1801056861877441e-01
    z[1,2,2]  R754      -7.5886243581771851e-01
    z[1,2,2]  R755      -4.8464578390121460e-01
    z[1,2,2]  R756      -9.4092048704624176e-02
    z[1,2,2]  R757      -2.3630566895008087e-01
    z[1,2,2]  R758      3.9439156651496887e-02
    z[1,2,2]  R759      -5.8352392911911011e-01
    z[1,2,2]  R760      -4.4249197840690613e-01
    z[1,2,2]  R761      -3.7597176432609558e-01
    z[1,2,2]  R762      -1.0341511666774750e-01
    z[1,2,2]  R763      -0.631401777267456
    z[1,2,2]  R764      -1.3033016026020050e-01
    z[1,2,2]  R765      -0.673624575138092
    z[1,2,2]  R766      8.6111530661582947e-02
    z[1,2,2]  R767      -6.5445655584335327e-01
    z[1,2,2]  R768      -7.5995332002639771e-01
    z[1,2,2]  R769      -0.604049563407898
    z[1,2,2]  R770      -2.5753778219223022e-01
    z[1,2,2]  R771      -5.3976607322692871e-01
    z[1,2,2]  R772      4.2098306119441986e-02
    z[1,2,2]  R773      3.4863191843032837e-01
    z[1,2,2]  R774      4.5605354011058807e-02
    z[1,2,2]  R775      -3.8888771086931229e-02
    z[1,2,2]  R776      -2.9725676774978638e-01
    z[1,2,2]  R777      3.8173702359199524e-01
    z[1,2,2]  R778      -1.8941754102706909e-01
    z[1,2,2]  R779      1.1917474865913391e-01
    z[1,2,2]  R780      -7.8999191522598267e-01
    z[1,2,2]  R781      1.3872574269771576e-01
    z[1,2,2]  R782      4.2276558279991150e-01
    z[1,2,2]  R783      4.0643098950386047e-01
    z[1,2,2]  R784      5.0381618738174438e-01
    z[1,2,2]  R785      -3.2543742656707764e-01
    z[1,2,2]  R786      9.7078546881675720e-02
    z[1,2,2]  R787      -2.7968008071184158e-03
    z[1,2,2]  R788      3.8206619024276733e-01
    z[1,2,2]  R789      -2.5693991780281067e-01
    z[1,2,2]  R790      2.8152132034301758e-01
    z[1,2,2]  R791      -6.1093878746032715e-01
    z[1,2,2]  R792      -3.3857741951942444e-01
    z[1,2,2]  R793      -0.472592294216156
    z[1,2,2]  R794      9.7093977034091949e-02
    z[1,2,2]  R795      -2.3159457743167877e-01
    z[1,2,2]  R796      -3.1709957867860794e-02
    z[1,2,2]  R797      -1.1720193177461624e-01
    z[1,2,2]  R798      8.2046687602996826e-01
    z[1,2,2]  R799      4.8310512304306030e-01
    z[1,2,2]  R800      3.8264030218124390e-01
    z[1,2,2]  R801      3.7091696262359619e-01
    z[1,2,2]  R802      2.1323429048061371e-01
    z[1,2,2]  R803      -3.1985055655241013e-02
    z[1,2,2]  R804      -3.7263888120651245e-01
    z[1,2,2]  R805      -5.7381969690322876e-01
    z[1,2,2]  R806      -9.8400421440601349e-02
    z[1,2,2]  R807      -5.2164769172668457e-01
    z[1,2,2]  R808      -6.6140770912170410e-01
    z[1,2,2]  R809      -9.3525443226099014e-03
    z[1,2,2]  R810      -6.2786054611206055e-01
    z[1,2,2]  R811      -7.6410883665084839e-01
    z[1,2,2]  R812      -1.3354372978210449e-01
    z[1,2,2]  R813      -5.2212452888488770e-01
    z[1,2,2]  R814      2.8210720419883728e-01
    z[1,2,2]  R815      -5.5925279855728149e-01
    z[1,2,2]  R816      -0.313320517539978
    z[1,2,2]  R817      2.8686714172363281e-01
    z[1,2,2]  R818      4.6897572278976440e-01
    z[1,2,2]  R819      -4.2075714468955994e-01
    z[1,2,2]  R820      -4.1321775317192078e-01
    z[1,2,2]  R821      -1.0324368625879288e-01
    z[1,2,2]  R822      -5.2678704261779785e-02
    z[1,2,2]  R823      -2.9144442081451416e-01
    z[1,2,2]  R824      -2.6429215073585510e-01
    z[1,2,2]  R825      1.5398591756820679e-01
    z[1,2,3]  R14       -1
    z[1,2,3]  R23       1
    z[1,2,3]  R708      -1
    z[1,2,3]  R709      1
    z[1,2,3]  R716      -3.7720409035682678e-01
    z[1,2,3]  R717      -5.0152492523193359e-01
    z[1,2,3]  R718      -0.620127260684967
    z[1,2,3]  R719      -3.0619978904724121e-01
    z[1,2,3]  R720      -4.6318736672401428e-01
    z[1,2,3]  R721      -2.8145933151245117e-01
    z[1,2,3]  R722      -4.9411794543266296e-01
    z[1,2,3]  R723      -4.7303819656372070e-01
    z[1,2,3]  R724      -1.5031154453754425e-01
    z[1,2,3]  R725      -3.8023716211318970e-01
    z[1,2,3]  R726      4.0187767148017883e-01
    z[1,2,3]  R727      3.0618983507156372e-01
    z[1,2,3]  R728      1.4561046659946442e-01
    z[1,2,3]  R729      2.7717188000679016e-01
    z[1,2,3]  R730      3.1537401676177979e-01
    z[1,2,3]  R731      1.7669594287872314e-01
    z[1,2,3]  R732      2.2975522279739380e-01
    z[1,2,3]  R733      3.0813151597976685e-01
    z[1,2,3]  R734      1.8196175992488861e-01
    z[1,2,3]  R735      3.0411624908447266e-01
    z[1,2,3]  R736      -4.7513264417648315e-01
    z[1,2,3]  R737      -2.9910793900489807e-01
    z[1,2,3]  R738      -4.9415990710258484e-01
    z[1,2,3]  R739      -5.3595000505447388e-01
    z[1,2,3]  R740      -7.0295113325119019e-01
    z[1,2,3]  R741      6.3802433013916016e-01
    z[1,2,3]  R742      -5.2820432186126709e-01
    z[1,2,3]  R743      -7.0321941375732422e-01
    z[1,2,3]  R744      -1.1157199740409851e-01
    z[1,2,3]  R745      4.9584048986434937e-01
    z[1,2,3]  R746      6.3299578428268433e-01
    z[1,2,3]  R747      1.0616496205329895e-01
    z[1,2,3]  R748      2.5820401310920715e-01
    z[1,2,3]  R749      7.9184156656265259e-01
    z[1,2,3]  R750      -8.7833821773529053e-02
    z[1,2,3]  R751      -6.3290582038462162e-03
    z[1,2,3]  R752      3.8389280438423157e-01
    z[1,2,3]  R753      5.2608340978622437e-01
    z[1,2,3]  R754      3.3938249945640564e-01
    z[1,2,3]  R755      2.5562044978141785e-01
    z[1,2,3]  R756      -3.0140110850334167e-01
    z[1,2,3]  R757      -2.7371674776077271e-01
    z[1,2,3]  R758      -0.520424485206604
    z[1,2,3]  R759      5.7561047375202179e-02
    z[1,2,3]  R760      -1.3779722154140472e-01
    z[1,2,3]  R761      1.5111909806728363e-01
    z[1,2,3]  R762      7.1562141180038452e-01
    z[1,2,3]  R763      7.0563733577728271e-01
    z[1,2,3]  R764      6.9247573614120483e-01
    z[1,2,3]  R765      3.9864847064018250e-01
    z[1,2,3]  R766      8.6471486091613770e-01
    z[1,2,3]  R767      2.9924002289772034e-01
    z[1,2,3]  R768      9.8448902368545532e-02
    z[1,2,3]  R769      0.0271736029535532
    z[1,2,3]  R770      1.0608037561178207e-01
    z[1,2,3]  R771      1.6946910321712494e-01
    z[1,2,3]  R772      3.3247882127761841e-01
    z[1,2,3]  R773      0.596255898475647
    z[1,2,3]  R774      1.9995900988578796e-01
    z[1,2,3]  R775      2.9122719168663025e-01
    z[1,2,3]  R776      -1.0755251161754131e-02
    z[1,2,3]  R777      -7.1085256338119507e-01
    z[1,2,3]  R778      -7.3259377479553223e-01
    z[1,2,3]  R779      6.1649543046951294e-01
    z[1,2,3]  R780      3.1919321417808533e-01
    z[1,2,3]  R781      0.474653959274292
    z[1,2,3]  R782      5.7778173685073853e-01
    z[1,2,3]  R783      2.9399591684341431e-01
    z[1,2,3]  R784      5.8195346593856812e-01
    z[1,2,3]  R785      4.9630695581436157e-01
    z[1,2,3]  R786      6.5015846490859985e-01
    z[1,2,3]  R787      1.1039676517248154e-01
    z[1,2,3]  R788      4.3881908059120178e-01
    z[1,2,3]  R789      5.5209094285964966e-01
    z[1,2,3]  R790      5.9213083982467651e-01
    z[1,2,3]  R791      0.625938355922699
    z[1,2,3]  R792      6.1959064006805420e-01
    z[1,2,3]  R793      3.7651520967483521e-01
    z[1,2,3]  R794      -4.0214595198631287e-01
    z[1,2,3]  R795      3.4837007522583008e-01
    z[1,2,3]  R796      2.4858303368091583e-01
    z[1,2,3]  R797      4.2554402351379395e-01
    z[1,2,3]  R798      0.0343628004193306
    z[1,2,3]  R799      -3.8013058900833130e-01
    z[1,2,3]  R800      -2.9829597473144531e-01
    z[1,2,3]  R801      -3.3759616315364838e-02
    z[1,2,3]  R802      -4.6697562932968140e-01
    z[1,2,3]  R803      -3.4522190690040588e-01
    z[1,2,3]  R804      -1.0063122212886810e-01
    z[1,2,3]  R805      -0.532974362373352
    z[1,2,3]  R806      0.795096755027771
    z[1,2,3]  R807      -6.5679289400577545e-02
    z[1,2,3]  R808      2.1196436882019043e-01
    z[1,2,3]  R809      -5.1714515686035156e-01
    z[1,2,3]  R810      -3.2441899180412292e-01
    z[1,2,3]  R811      2.2344872355461121e-01
    z[1,2,3]  R812      -2.0596009492874146e-01
    z[1,2,3]  R813      -2.5589501857757568e-01
    z[1,2,3]  R814      -2.2315208613872528e-01
    z[1,2,3]  R815      -4.5817753672599792e-01
    z[1,2,3]  R816      -1.4972835779190063e-01
    z[1,2,3]  R817      2.0119418203830719e-01
    z[1,2,3]  R818      -7.1833759546279907e-01
    z[1,2,3]  R819      7.2061540558934212e-03
    z[1,2,3]  R820      -4.4673284888267517e-01
    z[1,2,3]  R821      -6.6427075862884521e-01
    z[1,2,3]  R822      -4.9844187498092651e-01
    z[1,2,3]  R823      -3.5893306136131287e-01
    z[1,2,3]  R824      -3.5574150085449219e-01
    z[1,2,3]  R825      -1.9878847897052765e-01
    z[1,2,4]  R15       -1
    z[1,2,4]  R24       1
    z[1,2,4]  R710      -1
    z[1,2,4]  R711      1
    z[1,2,4]  R716      -3.2421648502349854e-01
    z[1,2,4]  R717      -0.287641316652298
    z[1,2,4]  R718      -2.5535440444946289e-01
    z[1,2,4]  R719      -6.8725836277008057e-01
    z[1,2,4]  R720      1.0965451598167419e-01
    z[1,2,4]  R721      -8.6141265928745270e-02
    z[1,2,4]  R722      -3.9865094423294067e-01
    z[1,2,4]  R723      -1.8897384405136108e-01
    z[1,2,4]  R724      2.6522138714790344e-01
    z[1,2,4]  R725      1.8102388083934784e-01
    z[1,2,4]  R726      -7.8041076660156250e-02
    z[1,2,4]  R727      -2.4372771382331848e-01
    z[1,2,4]  R728      1.0159488767385483e-01
    z[1,2,4]  R729      3.1711183488368988e-02
    z[1,2,4]  R730      1.2975813448429108e-01
    z[1,2,4]  R731      3.6978356540203094e-02
    z[1,2,4]  R732      4.7158572822809219e-02
    z[1,2,4]  R733      -2.0836353302001953e-01
    z[1,2,4]  R734      -7.6501868665218353e-02
    z[1,2,4]  R735      -2.3105712607502937e-03
    z[1,2,4]  R736      -2.3320877552032471e-01
    z[1,2,4]  R737      -1.1149710416793823e-01
    z[1,2,4]  R738      1.9031253457069397e-01
    z[1,2,4]  R739      -2.6426789164543152e-01
    z[1,2,4]  R740      3.6705070734024048e-01
    z[1,2,4]  R741      3.2231593132019043e-01
    z[1,2,4]  R742      -1.2098166346549988e-01
    z[1,2,4]  R743      4.6424347907304764e-02
    z[1,2,4]  R744      -2.0061565935611725e-01
    z[1,2,4]  R745      -3.2303226180374622e-03
    z[1,2,4]  R746      -1.9778303802013397e-01
    z[1,2,4]  R747      2.3271875083446503e-01
    z[1,2,4]  R748      -2.0879207551479340e-01
    z[1,2,4]  R749      -1.4656364917755127e-01
    z[1,2,4]  R750      3.8150716572999954e-02
    z[1,2,4]  R751      1.2002401798963547e-01
    z[1,2,4]  R752      3.2161605358123779e-01
    z[1,2,4]  R753      4.0730339288711548e-01
    z[1,2,4]  R754      4.8944327980279922e-02
    z[1,2,4]  R755      3.6813560128211975e-01
    z[1,2,4]  R756      -1.9165527820587158e-01
    z[1,2,4]  R757      4.9533969163894653e-01
    z[1,2,4]  R758      3.0061343312263489e-01
    z[1,2,4]  R759      2.9962889850139618e-02
    z[1,2,4]  R760      4.4709322974085808e-03
    z[1,2,4]  R761      -1.3671702146530151e-01
    z[1,2,4]  R762      1.6357812285423279e-01
    z[1,2,4]  R763      1.9558621942996979e-01
    z[1,2,4]  R764      3.6986431479454041e-01
    z[1,2,4]  R765      2.1674321591854095e-01
    z[1,2,4]  R766      -4.2414046823978424e-02
    z[1,2,4]  R767      -1.7318703234195709e-02
    z[1,2,4]  R768      3.6371055245399475e-01
    z[1,2,4]  R769      4.8381996154785156e-01
    z[1,2,4]  R770      -3.2471738755702972e-02
    z[1,2,4]  R771      5.8499181270599365e-01
    z[1,2,4]  R772      4.3477073311805725e-01
    z[1,2,4]  R773      1.2443201988935471e-01
    z[1,2,4]  R774      1.5923465788364410e-01
    z[1,2,4]  R775      4.4488483667373657e-01
    z[1,2,4]  R776      -1.4953131973743439e-01
    z[1,2,4]  R777      6.2398705631494522e-02
    z[1,2,4]  R778      2.5058604776859283e-02
    z[1,2,4]  R779      -4.4366973638534546e-01
    z[1,2,4]  R780      2.5789496302604675e-01
    z[1,2,4]  R781      4.7080650925636292e-01
    z[1,2,4]  R782      -1.0918192565441132e-03
    z[1,2,4]  R783      -1.5598331391811371e-01
    z[1,2,4]  R784      4.9181395769119263e-01
    z[1,2,4]  R785      7.5598949193954468e-01
    z[1,2,4]  R786      -1.1459868401288986e-01
    z[1,2,4]  R787      -3.6937814950942993e-01
    z[1,2,4]  R788      3.9902281761169434e-01
    z[1,2,4]  R789      2.1089439094066620e-01
    z[1,2,4]  R790      3.0564457178115845e-01
    z[1,2,4]  R791      2.1205591037869453e-02
    z[1,2,4]  R792      6.6968256235122681e-01
    z[1,2,4]  R793      3.4454742074012756e-01
    z[1,2,4]  R794      4.2818868532776833e-03
    z[1,2,4]  R795      4.8093062639236450e-01
    z[1,2,4]  R796      2.2210077941417694e-01
    z[1,2,4]  R797      0.52739018201828
    z[1,2,4]  R798      6.0279220342636108e-02
    z[1,2,4]  R799      2.4187561124563217e-02
    z[1,2,4]  R800      -0.0906379222869873
    z[1,2,4]  R801      -3.1904366612434387e-01
    z[1,2,4]  R802      -1.3254015147686005e-01
    z[1,2,4]  R803      -5.0502443313598633e-01
    z[1,2,4]  R804      -1.4713397622108459e-01
    z[1,2,4]  R805      -2.8011593222618103e-01
    z[1,2,4]  R806      -3.7752330303192139e-01
    z[1,2,4]  R807      -2.7722901105880737e-01
    z[1,2,4]  R808      -3.1362017989158630e-01
    z[1,2,4]  R809      4.6093329787254333e-01
    z[1,2,4]  R810      4.8824116587638855e-01
    z[1,2,4]  R811      5.0413936376571655e-02
    z[1,2,4]  R812      -2.4194929003715515e-01
    z[1,2,4]  R813      -6.4516708254814148e-02
    z[1,2,4]  R814      2.3263719677925110e-01
    z[1,2,4]  R815      -2.1304479241371155e-01
    z[1,2,4]  R816      2.3986525833606720e-02
    z[1,2,4]  R817      9.1045916080474854e-02
    z[1,2,4]  R818      4.5402288436889648e-02
    z[1,2,4]  R819      -1.3329149782657623e-01
    z[1,2,4]  R820      -4.3217939138412476e-01
    z[1,2,4]  R821      -2.0710915327072144e-01
    z[1,2,4]  R822      -4.0176659822463989e-01
    z[1,2,4]  R823      -3.0604231357574463e-01
    z[1,2,4]  R824      -3.3184453845024109e-01
    z[1,2,4]  R825      1.4250871725380421e-02
    z[1,2,5]  R16       -1
    z[1,2,5]  R25       1
    z[1,2,5]  R712      -1
    z[1,2,5]  R713      1
    z[1,2,5]  R716      -7.6462127268314362e-02
    z[1,2,5]  R717      3.5775130987167358e-01
    z[1,2,5]  R718      -5.0992354750633240e-02
    z[1,2,5]  R719      6.8135358393192291e-02
    z[1,2,5]  R720      4.2147073149681091e-01
    z[1,2,5]  R721      9.6685782074928284e-02
    z[1,2,5]  R722      2.4848919361829758e-02
    z[1,2,5]  R723      3.7973019480705261e-01
    z[1,2,5]  R724      -3.8027125597000122e-01
    z[1,2,5]  R725      -2.2399128973484039e-01
    z[1,2,5]  R726      1.3740417361259460e-01
    z[1,2,5]  R727      3.0534034967422485e-01
    z[1,2,5]  R728      3.5866221785545349e-01
    z[1,2,5]  R729      5.9211300686001778e-03
    z[1,2,5]  R730      -1.6443461179733276e-02
    z[1,2,5]  R731      2.0932057499885559e-01
    z[1,2,5]  R732      3.7273299694061279e-01
    z[1,2,5]  R733      2.1522977948188782e-01
    z[1,2,5]  R734      0.511130690574646
    z[1,2,5]  R735      3.6250913143157959e-01
    z[1,2,5]  R736      -0.648076057434082
    z[1,2,5]  R737      0.0657590702176094
    z[1,2,5]  R738      -2.9661828279495239e-01
    z[1,2,5]  R739      -7.6879158616065979e-02
    z[1,2,5]  R740      -2.1222910284996033e-01
    z[1,2,5]  R741      1.6392305493354797e-01
    z[1,2,5]  R742      -4.2393404245376587e-01
    z[1,2,5]  R743      -1.5759025514125824e-01
    z[1,2,5]  R744      -3.9872181415557861e-01
    z[1,2,5]  R745      7.0305779576301575e-02
    z[1,2,5]  R746      4.1900908946990967e-01
    z[1,2,5]  R747      1.4060950279235840e-01
    z[1,2,5]  R748      -4.0386593341827393e-01
    z[1,2,5]  R749      2.3328746855258942e-01
    z[1,2,5]  R750      1.4735272526741028e-01
    z[1,2,5]  R751      -1.0939425788819790e-02
    z[1,2,5]  R752      -2.9343429952859879e-02
    z[1,2,5]  R753      6.4921337366104126e-01
    z[1,2,5]  R754      5.4124879837036133e-01
    z[1,2,5]  R755      -2.0792341232299805e-01
    z[1,2,5]  R756      2.0585437119007111e-01
    z[1,2,5]  R757      -9.0375185012817383e-02
    z[1,2,5]  R758      -4.8706404864788055e-02
    z[1,2,5]  R759      -1.5952616930007935e-01
    z[1,2,5]  R760      -4.9883734434843063e-02
    z[1,2,5]  R761      -3.8910800218582153e-01
    z[1,2,5]  R762      4.2181101441383362e-01
    z[1,2,5]  R763      -1.6269692778587341e-01
    z[1,2,5]  R764      -1.3045889139175415e-01
    z[1,2,5]  R765      8.8567227125167847e-02
    z[1,2,5]  R766      3.1192660331726074e-01
    z[1,2,5]  R767      3.9336517453193665e-01
    z[1,2,5]  R768      2.0151710510253906e-01
    z[1,2,5]  R769      9.1979645192623138e-02
    z[1,2,5]  R770      -4.3433707207441330e-02
    z[1,2,5]  R771      -3.8120919466018677e-01
    z[1,2,5]  R772      -1.0739266127347946e-01
    z[1,2,5]  R773      1.6362212598323822e-01
    z[1,2,5]  R774      -3.6934378743171692e-01
    z[1,2,5]  R775      -4.7725012898445129e-01
    z[1,2,5]  R776      -0.523442268371582
    z[1,2,5]  R777      -2.9658830165863037e-01
    z[1,2,5]  R778      2.5670301169157028e-02
    z[1,2,5]  R779      8.1822425127029419e-02
    z[1,2,5]  R780      -6.0947993770241737e-03
    z[1,2,5]  R781      3.6438152194023132e-01
    z[1,2,5]  R782      -3.4555536508560181e-01
    z[1,2,5]  R783      -4.6714732050895691e-01
    z[1,2,5]  R784      1.2319060415029526e-01
    z[1,2,5]  R785      5.1724273711442947e-02
    z[1,2,5]  R786      2.0836119353771210e-01
    z[1,2,5]  R787      -2.1691080927848816e-01
    z[1,2,5]  R788      1.4422725141048431e-01
    z[1,2,5]  R789      -9.9152170121669769e-02
    z[1,2,5]  R790      -1.5527497231960297e-01
    z[1,2,5]  R791      3.7689003348350525e-01
    z[1,2,5]  R792      -8.8169820606708527e-02
    z[1,2,5]  R793      2.3336377739906311e-01
    z[1,2,5]  R794      -1.3693358004093170e-01
    z[1,2,5]  R795      4.8149690032005310e-02
    z[1,2,5]  R796      1.9332119822502136e-01
    z[1,2,5]  R797      5.3401970863342285e-01
    z[1,2,5]  R798      -1.6601161658763885e-01
    z[1,2,5]  R799      -2.6130869984626770e-02
    z[1,2,5]  R800      3.3052659034729004e-01
    z[1,2,5]  R801      1.1951579898595810e-01
    z[1,2,5]  R802      1.1675358563661575e-01
    z[1,2,5]  R803      1.0763483494520187e-01
    z[1,2,5]  R804      -1.8017560243606567e-01
    z[1,2,5]  R805      -1.7369458079338074e-01
    z[1,2,5]  R806      -4.4999197125434875e-01
    z[1,2,5]  R807      -2.0654010772705078e-01
    z[1,2,5]  R808      2.0217722654342651e-01
    z[1,2,5]  R809      2.8861439228057861e-01
    z[1,2,5]  R810      -1.7662626504898071e-01
    z[1,2,5]  R811      -1.4387050271034241e-01
    z[1,2,5]  R812      -0.556344211101532
    z[1,2,5]  R813      1.0969237983226776e-01
    z[1,2,5]  R814      -2.7493458986282349e-01
    z[1,2,5]  R815      -9.7647741436958313e-02
    z[1,2,5]  R816      -3.8001391291618347e-01
    z[1,2,5]  R817      1.6607622802257538e-01
    z[1,2,5]  R818      -1.3904532790184021e-01
    z[1,2,5]  R819      0.0678798034787178
    z[1,2,5]  R820      -2.3103940486907959e-01
    z[1,2,5]  R821      -2.0109573379158974e-02
    z[1,2,5]  R822      -2.1075604856014252e-01
    z[1,2,5]  R823      1.0331179201602936e-01
    z[1,2,5]  R824      -2.6430118083953857e-01
    z[1,2,5]  R825      5.0883638858795166e-01
    z[1,2,6]  R17       -1
    z[1,2,6]  R26       1
    z[1,2,6]  R714      -1
    z[1,2,6]  R715      1
    z[1,2,6]  R716      -0.383847177028656
    z[1,2,6]  R717      2.1412980556488037e-01
    z[1,2,6]  R718      4.4229626655578613e-02
    z[1,2,6]  R719      -1.1348040401935577e-01
    z[1,2,6]  R720      -7.0780552923679352e-02
    z[1,2,6]  R721      2.3420266807079315e-01
    z[1,2,6]  R722      -3.5714048147201538e-01
    z[1,2,6]  R723      -4.1779378056526184e-01
    z[1,2,6]  R724      -9.8797872662544250e-02
    z[1,2,6]  R725      -2.7079728245735168e-01
    z[1,2,6]  R726      -2.8398019075393677e-01
    z[1,2,6]  R727      2.7448818087577820e-01
    z[1,2,6]  R728      -3.8419350981712341e-02
    z[1,2,6]  R729      9.7134284675121307e-02
    z[1,2,6]  R730      -2.4830566346645355e-01
    z[1,2,6]  R731      -1.3310468196868896e-01
    z[1,2,6]  R732      3.7576359510421753e-01
    z[1,2,6]  R733      -2.8193789720535278e-01
    z[1,2,6]  R734      4.6669259667396545e-02
    z[1,2,6]  R735      -4.4715738296508789e-01
    z[1,2,6]  R736      4.4310346245765686e-02
    z[1,2,6]  R737      1.8833646178245544e-01
    z[1,2,6]  R738      -0.0983353853225708
    z[1,2,6]  R739      1.8292682245373726e-02
    z[1,2,6]  R740      1.5415126085281372e-01
    z[1,2,6]  R741      1.4263746142387390e-01
    z[1,2,6]  R742      4.6091634035110474e-01
    z[1,2,6]  R743      3.7453049421310425e-01
    z[1,2,6]  R744      6.3131886720657349e-01
    z[1,2,6]  R745      -1.3046045601367950e-01
    z[1,2,6]  R746      7.2290033102035522e-02
    z[1,2,6]  R747      3.5995218157768250e-01
    z[1,2,6]  R748      1.5154068171977997e-01
    z[1,2,6]  R749      -1.5079037845134735e-01
    z[1,2,6]  R750      1.1484432965517044e-01
    z[1,2,6]  R751      -0.736470639705658
    z[1,2,6]  R752      5.0123695284128189e-02
    z[1,2,6]  R753      1.2904106080532074e-01
    z[1,2,6]  R754      7.2645372711122036e-03
    z[1,2,6]  R755      7.1147575974464417e-02
    z[1,2,6]  R756      3.2846489548683167e-01
    z[1,2,6]  R757      -1.5908074378967285e-01
    z[1,2,6]  R758      -4.5059084892272949e-01
    z[1,2,6]  R759      -3.3879649639129639e-01
    z[1,2,6]  R760      -3.3033692836761475e-01
    z[1,2,6]  R761      7.6765216886997223e-02
    z[1,2,6]  R762      -2.9396224021911621e-01
    z[1,2,6]  R763      4.3577242642641068e-02
    z[1,2,6]  R764      1.2319776415824890e-01
    z[1,2,6]  R765      -5.3875666856765747e-01
    z[1,2,6]  R766      8.8483437895774841e-02
    z[1,2,6]  R767      2.8057926893234253e-01
    z[1,2,6]  R768      -6.0776922851800919e-02
    z[1,2,6]  R769      3.0879381299018860e-01
    z[1,2,6]  R770      -3.5192728042602539e-01
    z[1,2,6]  R771      -2.6379138231277466e-01
    z[1,2,6]  R772      4.2512655258178711e-02
    z[1,2,6]  R773      -1.8563105165958405e-01
    z[1,2,6]  R774      3.3686894178390503e-01
    z[1,2,6]  R775      -9.7422868013381958e-02
    z[1,2,6]  R776      2.1099606156349182e-01
    z[1,2,6]  R777      2.7201318740844727e-01
    z[1,2,6]  R778      5.4628539085388184e-01
    z[1,2,6]  R779      5.2705843001604080e-02
    z[1,2,6]  R780      -8.0805547535419464e-02
    z[1,2,6]  R781      -3.9299684762954712e-01
    z[1,2,6]  R782      1.1600001901388168e-01
    z[1,2,6]  R783      1.1144879460334778e-01
    z[1,2,6]  R784      2.8317835927009583e-01
    z[1,2,6]  R785      2.0880098640918732e-01
    z[1,2,6]  R786      2.0675741136074066e-01
    z[1,2,6]  R787      4.8996829986572266e-01
    z[1,2,6]  R788      -2.7041694149374962e-02
    z[1,2,6]  R789      9.9062584340572357e-02
    z[1,2,6]  R790      -4.4209539890289307e-01
    z[1,2,6]  R791      -5.9952650219202042e-02
    z[1,2,6]  R792      2.1013806760311127e-01
    z[1,2,6]  R793      -3.7109214812517166e-02
    z[1,2,6]  R794      0.456543892621994
    z[1,2,6]  R795      3.6825588345527649e-01
    z[1,2,6]  R796      5.0117647647857666e-01
    z[1,2,6]  R797      -4.4853731989860535e-01
    z[1,2,6]  R798      -3.0730417370796204e-01
    z[1,2,6]  R799      8.7859280407428741e-02
    z[1,2,6]  R800      -4.8645719885826111e-02
    z[1,2,6]  R801      -6.7843578755855560e-02
    z[1,2,6]  R802      -2.3056827485561371e-01
    z[1,2,6]  R803      1.1112280935049057e-01
    z[1,2,6]  R804      -3.7142220884561539e-02
    z[1,2,6]  R805      0.476544052362442
    z[1,2,6]  R806      -5.4714262485504150e-02
    z[1,2,6]  R807      -4.4603458046913147e-01
    z[1,2,6]  R808      1.7056821286678314e-01
    z[1,2,6]  R809      4.1587987542152405e-01
    z[1,2,6]  R810      1.8179066479206085e-01
    z[1,2,6]  R811      2.2592335939407349e-01
    z[1,2,6]  R812      2.2567810118198395e-01
    z[1,2,6]  R813      1.1582200415432453e-02
    z[1,2,6]  R814      2.9293093830347061e-02
    z[1,2,6]  R815      -5.0506293773651123e-01
    z[1,2,6]  R816      -3.0052134394645691e-01
    z[1,2,6]  R817      3.8794970512390137e-01
    z[1,2,6]  R818      1.2793380022048950e-01
    z[1,2,6]  R819      4.3868002295494080e-01
    z[1,2,6]  R820      3.8199447095394135e-02
    z[1,2,6]  R821      -6.4267016947269440e-02
    z[1,2,6]  R822      -1.1250492185354233e-01
    z[1,2,6]  R823      1.0586041212081909e-01
    z[1,2,6]  R824      -3.6997777223587036e-01
    z[1,2,6]  R825      -9.2456437647342682e-02
    z[2,1,0]  R11       1
    z[2,1,0]  R20       -1
    z[2,1,0]  R826      -1
    z[2,1,0]  R827      1
    z[2,1,0]  R840      -1.6967041790485382e-01
    z[2,1,0]  R841      -1.3388785719871521e-01
    z[2,1,0]  R842      3.0542594194412231e-01
    z[2,1,0]  R843      -0.77823805809021
    z[2,1,0]  R844      -7.9751676321029663e-01
    z[2,1,0]  R845      -8.5658162832260132e-01
    z[2,1,0]  R846      -8.0390030145645142e-01
    z[2,1,0]  R847      -7.7379405498504639e-01
    z[2,1,0]  R848      -8.9063447713851929e-01
    z[2,1,0]  R849      -1.7608661949634552e-01
    z[2,1,0]  R850      1.0001166909933090e-01
    z[2,1,0]  R851      4.4433104991912842e-01
    z[2,1,0]  R852      3.6617133021354675e-01
    z[2,1,0]  R853      1.9942130148410797e-01
    z[2,1,0]  R854      -1.2687428295612335e-01
    z[2,1,0]  R855      -3.5667607188224792e-01
    z[2,1,0]  R856      -5.2196753025054932e-01
    z[2,1,0]  R857      -2.4494828283786774e-01
    z[2,1,0]  R858      -7.5037801265716553e-01
    z[2,1,0]  R859      1.8949049711227417e-01
    z[2,1,0]  R860      -6.1510574817657471e-01
    z[2,1,0]  R861      -3.4907853603363037e-01
    z[2,1,0]  R862      -1.6321410238742828e-01
    z[2,1,0]  R863      -3.3627992868423462e-01
    z[2,1,0]  R864      1.2292774766683578e-01
    z[2,1,0]  R865      1.1723812669515610e-01
    z[2,1,0]  R866      2.9016089439392090e-01
    z[2,1,0]  R867      2.1073332428932190e-01
    z[2,1,0]  R868      1.3649851083755493e-01
    z[2,1,0]  R869      3.8373467326164246e-01
    z[2,1,0]  R870      -6.5858542919158936e-01
    z[2,1,0]  R871      -6.5801924467086792e-01
    z[2,1,0]  R872      -7.1887493133544922e-01
    z[2,1,0]  R873      -4.1052407026290894e-01
    z[2,1,0]  R874      -7.1989625692367554e-01
    z[2,1,0]  R875      -0.59494549036026
    z[2,1,0]  R876      -5.6977653503417969e-01
    z[2,1,0]  R877      -6.3382625579833984e-01
    z[2,1,0]  R878      -0.820820689201355
    z[2,1,0]  R879      -0.791208803653717
    z[2,1,0]  R880      -1.5829540789127350e-01
    z[2,1,0]  R881      1.0571720451116562e-01
    z[2,1,0]  R882      9.0164765715599060e-02
    z[2,1,0]  R883      2.3170144855976105e-01
    z[2,1,0]  R884      1.9998101890087128e-01
    z[2,1,0]  R885      4.8847761750221252e-01
    z[2,1,0]  R886      2.9615685343742371e-01
    z[2,1,0]  R887      3.3222836256027222e-01
    z[2,1,0]  R888      3.5924544930458069e-01
    z[2,1,0]  R889      2.8316259384155273e-01
    z[2,1,0]  R890      4.6913135051727295e-01
    z[2,1,0]  R891      5.9548223018646240e-01
    z[2,1,0]  R892      5.5419504642486572e-01
    z[2,1,0]  R893      7.1332257986068726e-01
    z[2,1,0]  R894      0.413044273853302
    z[2,1,0]  R895      -4.1304641962051392e-01
    z[2,1,0]  R896      4.5895689725875854e-01
    z[2,1,0]  R897      5.3956449031829834e-01
    z[2,1,0]  R898      1.8347802758216858e-01
    z[2,1,0]  R899      8.0835449695587158e-01
    z[2,1,0]  R900      -2.6094338297843933e-01
    z[2,1,0]  R901      -1.0375731438398361e-01
    z[2,1,0]  R902      -1.1744309961795807e-01
    z[2,1,0]  R903      1.6161955893039703e-01
    z[2,1,0]  R904      4.5744961500167847e-01
    z[2,1,0]  R905      2.7871596813201904e-01
    z[2,1,0]  R906      2.7719014883041382e-01
    z[2,1,0]  R907      1.2179224193096161e-01
    z[2,1,0]  R908      -6.3695102930068970e-02
    z[2,1,0]  R909      0.629237711429596
    z[2,1,0]  R910      3.9095136523246765e-01
    z[2,1,0]  R911      3.6560770124197006e-02
    z[2,1,0]  R912      1.7770273983478546e-01
    z[2,1,0]  R913      1.4492644369602203e-01
    z[2,1,0]  R914      0.556480348110199
    z[2,1,0]  R915      5.0131708383560181e-01
    z[2,1,0]  R916      2.5523781776428223e-01
    z[2,1,0]  R917      -1.5742602944374084e-01
    z[2,1,0]  R918      4.6901664137840271e-01
    z[2,1,0]  R919      -0.0424308106303215
    z[2,1,0]  R920      2.9013910889625549e-01
    z[2,1,0]  R921      -2.6687833666801453e-01
    z[2,1,0]  R922      8.5017897188663483e-02
    z[2,1,0]  R923      -1.7064388096332550e-01
    z[2,1,0]  R924      7.6443380117416382e-01
    z[2,1,0]  R925      1.9689476490020752e-01
    z[2,1,0]  R926      8.2556062936782837e-01
    z[2,1,0]  R927      -1.2607698142528534e-01
    z[2,1,0]  R928      7.0532029867172241e-01
    z[2,1,0]  R929      0.554187536239624
    z[2,1,0]  R930      0.498337984085083
    z[2,1,0]  R931      1.3690540194511414e-01
    z[2,1,0]  R932      2.0153930783271790e-01
    z[2,1,0]  R933      3.8671070337295532e-01
    z[2,1,0]  R934      -7.6744019985198975e-02
    z[2,1,0]  R935      2.1289205551147461e-01
    z[2,1,0]  R936      -1.2130734324455261e-01
    z[2,1,0]  R937      4.4750612229108810e-02
    z[2,1,0]  R938      -1.3699607551097870e-01
    z[2,1,0]  R939      1.7185197770595551e-01
    z[2,1,0]  R940      3.0488875508308411e-01
    z[2,1,0]  R941      -2.1510450541973114e-01
    z[2,1,0]  R942      -4.6034038066864014e-01
    z[2,1,0]  R943      4.8502811789512634e-01
    z[2,1,0]  R944      3.1340980529785156e-01
    z[2,1,0]  R945      -3.1027961522340775e-02
    z[2,1,0]  R946      1.2311228550970554e-02
    z[2,1,0]  R947      6.5089219808578491e-01
    z[2,1,0]  R948      2.2151054814457893e-02
    z[2,1,0]  R949      6.4380139112472534e-01
    z[2,1,1]  R12       1
    z[2,1,1]  R21       -1
    z[2,1,1]  R828      -1
    z[2,1,1]  R829      1
    z[2,1,1]  R840      7.5533652305603027e-01
    z[2,1,1]  R841      1.5082035958766937e-01
    z[2,1,1]  R842      3.2670933008193970e-01
    z[2,1,1]  R843      -8.6420841515064240e-02
    z[2,1,1]  R844      -9.3506224453449249e-02
    z[2,1,1]  R845      -8.2904092967510223e-02
    z[2,1,1]  R846      7.6480291783809662e-02
    z[2,1,1]  R847      -4.5369766652584076e-02
    z[2,1,1]  R848      -4.7882851213216782e-02
    z[2,1,1]  R849      -1.4118745923042297e-01
    z[2,1,1]  R850      1.1222476139664650e-02
    z[2,1,1]  R851      4.5571732521057129e-01
    z[2,1,1]  R852      -4.6389934420585632e-01
    z[2,1,1]  R853      -4.7327658534049988e-01
    z[2,1,1]  R854      -4.2640617489814758e-01
    z[2,1,1]  R855      -4.0584355592727661e-01
    z[2,1,1]  R856      -0.498304545879364
    z[2,1,1]  R857      -0.765228807926178
    z[2,1,1]  R858      -4.2069500684738159e-01
    z[2,1,1]  R859      -3.6247938871383667e-01
    z[2,1,1]  R860      -5.1551681756973267e-01
    z[2,1,1]  R861      -7.5431865453720093e-01
    z[2,1,1]  R862      -4.4682428240776062e-01
    z[2,1,1]  R863      -7.0357149839401245e-01
    z[2,1,1]  R864      -6.1069816350936890e-01
    z[2,1,1]  R865      -6.9779038429260254e-01
    z[2,1,1]  R866      -0.66790372133255
    z[2,1,1]  R867      -7.9137659072875977e-01
    z[2,1,1]  R868      -6.8418294191360474e-01
    z[2,1,1]  R869      -7.2239428758621216e-01
    z[2,1,1]  R870      -1.8033710122108459e-01
    z[2,1,1]  R871      -2.2804026305675507e-01
    z[2,1,1]  R872      -6.2383204698562622e-02
    z[2,1,1]  R873      -2.5859877467155457e-01
    z[2,1,1]  R874      -9.5601566135883331e-02
    z[2,1,1]  R875      -1.7058271169662476e-01
    z[2,1,1]  R876      -1.5964622795581818e-01
    z[2,1,1]  R877      -1.4073713123798370e-01
    z[2,1,1]  R878      -2.7701035141944885e-01
    z[2,1,1]  R879      -1.3329532742500305e-01
    z[2,1,1]  R880      0.804551362991333
    z[2,1,1]  R881      8.0172097682952881e-01
    z[2,1,1]  R882      8.9155030250549316e-01
    z[2,1,1]  R883      8.1907963752746582e-01
    z[2,1,1]  R884      8.7900412082672119e-01
    z[2,1,1]  R885      8.1295800209045410e-01
    z[2,1,1]  R886      7.5687986612319946e-01
    z[2,1,1]  R887      7.5830638408660889e-01
    z[2,1,1]  R888      7.4715173244476318e-01
    z[2,1,1]  R889      7.0336920022964478e-01
    z[2,1,1]  R890      -2.7622026205062866e-01
    z[2,1,1]  R891      -3.9142203330993652e-01
    z[2,1,1]  R892      -0.248797208070755
    z[2,1,1]  R893      -2.4576936662197113e-01
    z[2,1,1]  R894      -2.1434900164604187e-01
    z[2,1,1]  R895      1.0257773846387863e-01
    z[2,1,1]  R896      -1.3534389436244965e-01
    z[2,1,1]  R897      -1.5342769026756287e-01
    z[2,1,1]  R898      -2.4239315092563629e-01
    z[2,1,1]  R899      1.2143120914697647e-01
    z[2,1,1]  R900      5.4998785257339478e-01
    z[2,1,1]  R901      -7.4844092130661011e-01
    z[2,1,1]  R902      -5.1669752597808838e-01
    z[2,1,1]  R903      2.8788894414901733e-01
    z[2,1,1]  R904      -7.5884765386581421e-01
    z[2,1,1]  R905      -5.1433372497558594e-01
    z[2,1,1]  R906      -5.9484966099262238e-02
    z[2,1,1]  R907      5.6977644562721252e-02
    z[2,1,1]  R908      -9.7424782812595367e-02
    z[2,1,1]  R909      3.4643688797950745e-01
    z[2,1,1]  R910      -7.4864143133163452e-01
    z[2,1,1]  R911      -7.6750653982162476e-01
    z[2,1,1]  R912      -0.63265460729599
    z[2,1,1]  R913      -7.0288920402526855e-01
    z[2,1,1]  R914      -6.0325086116790771e-01
    z[2,1,1]  R915      -6.3913995027542114e-01
    z[2,1,1]  R916      3.4777700901031494e-01
    z[2,1,1]  R917      1.0955148190259933e-01
    z[2,1,1]  R918      3.3840516209602356e-01
    z[2,1,1]  R919      2.0106829702854156e-01
    z[2,1,1]  R920      2.3183113336563110e-01
    z[2,1,1]  R921      4.2090049386024475e-01
    z[2,1,1]  R922      4.7850003838539124e-01
    z[2,1,1]  R923      5.1707899570465088e-01
    z[2,1,1]  R924      4.5963954925537109e-01
    z[2,1,1]  R925      2.8990250825881958e-01
    z[2,1,1]  R926      6.1392839998006821e-02
    z[2,1,1]  R927      -6.5599137544631958e-01
    z[2,1,1]  R928      4.3035867810249329e-01
    z[2,1,1]  R929      4.1396754980087280e-01
    z[2,1,1]  R930      -5.6772458553314209e-01
    z[2,1,1]  R931      -4.0542924404144287e-01
    z[2,1,1]  R932      -2.9511788487434387e-01
    z[2,1,1]  R933      4.9987000226974487e-01
    z[2,1,1]  R934      4.4165849685668945e-01
    z[2,1,1]  R935      4.4861632585525513e-01
    z[2,1,1]  R936      0.58297199010849
    z[2,1,1]  R937      -0.700998842716217
    z[2,1,1]  R938      2.2690226137638092e-01
    z[2,1,1]  R939      -0.0210583433508873
    z[2,1,1]  R940      6.1287569999694824e-01
    z[2,1,1]  R941      -7.1970504522323608e-01
    z[2,1,1]  R942      -5.1845723390579224e-01
    z[2,1,1]  R943      5.7428580522537231e-01
    z[2,1,1]  R944      3.9865252375602722e-01
    z[2,1,1]  R945      -2.9648298025131226e-01
    z[2,1,1]  R946      3.0242647975683212e-02
    z[2,1,1]  R947      1.9152933359146118e-01
    z[2,1,1]  R948      7.7534466981887817e-01
    z[2,1,1]  R949      2.0321662724018097e-01
    z[2,1,2]  R13       1
    z[2,1,2]  R22       -1
    z[2,1,2]  R830      -1
    z[2,1,2]  R831      1
    z[2,1,2]  R840      -3.1709957867860794e-02
    z[2,1,2]  R841      -1.1720193177461624e-01
    z[2,1,2]  R842      8.2046687602996826e-01
    z[2,1,2]  R843      4.8310512304306030e-01
    z[2,1,2]  R844      3.8264030218124390e-01
    z[2,1,2]  R845      3.7091696262359619e-01
    z[2,1,2]  R846      2.1323429048061371e-01
    z[2,1,2]  R847      -3.1985055655241013e-02
    z[2,1,2]  R848      -3.7263888120651245e-01
    z[2,1,2]  R849      -5.7381969690322876e-01
    z[2,1,2]  R850      -9.8400421440601349e-02
    z[2,1,2]  R851      -5.2164769172668457e-01
    z[2,1,2]  R852      -6.6140770912170410e-01
    z[2,1,2]  R853      -9.3525443226099014e-03
    z[2,1,2]  R854      -6.2786054611206055e-01
    z[2,1,2]  R855      -7.6410883665084839e-01
    z[2,1,2]  R856      -1.3354372978210449e-01
    z[2,1,2]  R857      -5.2212452888488770e-01
    z[2,1,2]  R858      2.8210720419883728e-01
    z[2,1,2]  R859      -5.5925279855728149e-01
    z[2,1,2]  R860      -0.313320517539978
    z[2,1,2]  R861      2.8686714172363281e-01
    z[2,1,2]  R862      4.6897572278976440e-01
    z[2,1,2]  R863      -4.2075714468955994e-01
    z[2,1,2]  R864      -4.1321775317192078e-01
    z[2,1,2]  R865      -1.0324368625879288e-01
    z[2,1,2]  R866      -5.2678704261779785e-02
    z[2,1,2]  R867      -2.9144442081451416e-01
    z[2,1,2]  R868      -2.6429215073585510e-01
    z[2,1,2]  R869      1.5398591756820679e-01
    z[2,1,2]  R870      3.6491009593009949e-01
    z[2,1,2]  R871      8.3101242780685425e-02
    z[2,1,2]  R872      1.5813589096069336e-01
    z[2,1,2]  R873      4.2543417215347290e-01
    z[2,1,2]  R874      2.5178456306457520e-01
    z[2,1,2]  R875      6.8271708488464355e-01
    z[2,1,2]  R876      -3.4442096948623657e-01
    z[2,1,2]  R877      -1.5313203446567059e-02
    z[2,1,2]  R878      4.7069203108549118e-02
    z[2,1,2]  R879      -2.3530335724353790e-01
    z[2,1,2]  R880      2.4600613117218018e-01
    z[2,1,2]  R881      1.5599825978279114e-01
    z[2,1,2]  R882      1.8806867301464081e-01
    z[2,1,2]  R883      4.3373140692710876e-01
    z[2,1,2]  R884      -9.5579192042350769e-02
    z[2,1,2]  R885      0.0797993540763855
    z[2,1,2]  R886      6.5456248819828033e-02
    z[2,1,2]  R887      -2.2454971075057983e-01
    z[2,1,2]  R888      1.0154710710048676e-01
    z[2,1,2]  R889      3.5156715661287308e-02
    z[2,1,2]  R890      3.8920834660530090e-02
    z[2,1,2]  R891      -5.9202855825424194e-01
    z[2,1,2]  R892      -5.0289428234100342e-01
    z[2,1,2]  R893      -2.5969842076301575e-01
    z[2,1,2]  R894      -2.9287990927696228e-01
    z[2,1,2]  R895      -5.1057970523834229e-01
    z[2,1,2]  R896      -2.9195931553840637e-01
    z[2,1,2]  R897      -1.5345829725265503e-01
    z[2,1,2]  R898      -5.4529237747192383e-01
    z[2,1,2]  R899      -2.5295522809028625e-01
    z[2,1,2]  R900      9.3944780528545380e-02
    z[2,1,2]  R901      -4.6293100714683533e-01
    z[2,1,2]  R902      -6.5030390024185181e-01
    z[2,1,2]  R903      4.0662553906440735e-01
    z[2,1,2]  R904      4.1330105066299438e-01
    z[2,1,2]  R905      -3.1752744317054749e-01
    z[2,1,2]  R906      -8.1574696302413940e-01
    z[2,1,2]  R907      3.1801056861877441e-01
    z[2,1,2]  R908      -7.5886243581771851e-01
    z[2,1,2]  R909      -4.8464578390121460e-01
    z[2,1,2]  R910      -9.4092048704624176e-02
    z[2,1,2]  R911      -2.3630566895008087e-01
    z[2,1,2]  R912      3.9439156651496887e-02
    z[2,1,2]  R913      -5.8352392911911011e-01
    z[2,1,2]  R914      -4.4249197840690613e-01
    z[2,1,2]  R915      -3.7597176432609558e-01
    z[2,1,2]  R916      -1.0341511666774750e-01
    z[2,1,2]  R917      -0.631401777267456
    z[2,1,2]  R918      -1.3033016026020050e-01
    z[2,1,2]  R919      -0.673624575138092
    z[2,1,2]  R920      8.6111530661582947e-02
    z[2,1,2]  R921      -6.5445655584335327e-01
    z[2,1,2]  R922      -7.5995332002639771e-01
    z[2,1,2]  R923      -0.604049563407898
    z[2,1,2]  R924      -2.5753778219223022e-01
    z[2,1,2]  R925      -5.3976607322692871e-01
    z[2,1,2]  R926      4.2098306119441986e-02
    z[2,1,2]  R927      3.4863191843032837e-01
    z[2,1,2]  R928      4.5605354011058807e-02
    z[2,1,2]  R929      -3.8888771086931229e-02
    z[2,1,2]  R930      -2.9725676774978638e-01
    z[2,1,2]  R931      3.8173702359199524e-01
    z[2,1,2]  R932      -1.8941754102706909e-01
    z[2,1,2]  R933      1.1917474865913391e-01
    z[2,1,2]  R934      -7.8999191522598267e-01
    z[2,1,2]  R935      1.3872574269771576e-01
    z[2,1,2]  R936      4.2276558279991150e-01
    z[2,1,2]  R937      4.0643098950386047e-01
    z[2,1,2]  R938      5.0381618738174438e-01
    z[2,1,2]  R939      -3.2543742656707764e-01
    z[2,1,2]  R940      9.7078546881675720e-02
    z[2,1,2]  R941      -2.7968008071184158e-03
    z[2,1,2]  R942      3.8206619024276733e-01
    z[2,1,2]  R943      -2.5693991780281067e-01
    z[2,1,2]  R944      2.8152132034301758e-01
    z[2,1,2]  R945      -6.1093878746032715e-01
    z[2,1,2]  R946      -3.3857741951942444e-01
    z[2,1,2]  R947      -0.472592294216156
    z[2,1,2]  R948      9.7093977034091949e-02
    z[2,1,2]  R949      -2.3159457743167877e-01
    z[2,1,3]  R14       1
    z[2,1,3]  R23       -1
    z[2,1,3]  R832      -1
    z[2,1,3]  R833      1
    z[2,1,3]  R840      2.4858303368091583e-01
    z[2,1,3]  R841      4.2554402351379395e-01
    z[2,1,3]  R842      0.0343628004193306
    z[2,1,3]  R843      -3.8013058900833130e-01
    z[2,1,3]  R844      -2.9829597473144531e-01
    z[2,1,3]  R845      -3.3759616315364838e-02
    z[2,1,3]  R846      -4.6697562932968140e-01
    z[2,1,3]  R847      -3.4522190690040588e-01
    z[2,1,3]  R848      -1.0063122212886810e-01
    z[2,1,3]  R849      -0.532974362373352
    z[2,1,3]  R850      0.795096755027771
    z[2,1,3]  R851      -6.5679289400577545e-02
    z[2,1,3]  R852      2.1196436882019043e-01
    z[2,1,3]  R853      -5.1714515686035156e-01
    z[2,1,3]  R854      -3.2441899180412292e-01
    z[2,1,3]  R855      2.2344872355461121e-01
    z[2,1,3]  R856      -2.0596009492874146e-01
    z[2,1,3]  R857      -2.5589501857757568e-01
    z[2,1,3]  R858      -2.2315208613872528e-01
    z[2,1,3]  R859      -4.5817753672599792e-01
    z[2,1,3]  R860      -1.4972835779190063e-01
    z[2,1,3]  R861      2.0119418203830719e-01
    z[2,1,3]  R862      -7.1833759546279907e-01
    z[2,1,3]  R863      7.2061540558934212e-03
    z[2,1,3]  R864      -4.4673284888267517e-01
    z[2,1,3]  R865      -6.6427075862884521e-01
    z[2,1,3]  R866      -4.9844187498092651e-01
    z[2,1,3]  R867      -3.5893306136131287e-01
    z[2,1,3]  R868      -3.5574150085449219e-01
    z[2,1,3]  R869      -1.9878847897052765e-01
    z[2,1,3]  R870      -3.7720409035682678e-01
    z[2,1,3]  R871      -5.0152492523193359e-01
    z[2,1,3]  R872      -0.620127260684967
    z[2,1,3]  R873      -3.0619978904724121e-01
    z[2,1,3]  R874      -4.6318736672401428e-01
    z[2,1,3]  R875      -2.8145933151245117e-01
    z[2,1,3]  R876      -4.9411794543266296e-01
    z[2,1,3]  R877      -4.7303819656372070e-01
    z[2,1,3]  R878      -1.5031154453754425e-01
    z[2,1,3]  R879      -3.8023716211318970e-01
    z[2,1,3]  R880      4.0187767148017883e-01
    z[2,1,3]  R881      3.0618983507156372e-01
    z[2,1,3]  R882      1.4561046659946442e-01
    z[2,1,3]  R883      2.7717188000679016e-01
    z[2,1,3]  R884      3.1537401676177979e-01
    z[2,1,3]  R885      1.7669594287872314e-01
    z[2,1,3]  R886      2.2975522279739380e-01
    z[2,1,3]  R887      3.0813151597976685e-01
    z[2,1,3]  R888      1.8196175992488861e-01
    z[2,1,3]  R889      3.0411624908447266e-01
    z[2,1,3]  R890      -4.7513264417648315e-01
    z[2,1,3]  R891      -2.9910793900489807e-01
    z[2,1,3]  R892      -4.9415990710258484e-01
    z[2,1,3]  R893      -5.3595000505447388e-01
    z[2,1,3]  R894      -7.0295113325119019e-01
    z[2,1,3]  R895      6.3802433013916016e-01
    z[2,1,3]  R896      -5.2820432186126709e-01
    z[2,1,3]  R897      -7.0321941375732422e-01
    z[2,1,3]  R898      -1.1157199740409851e-01
    z[2,1,3]  R899      4.9584048986434937e-01
    z[2,1,3]  R900      6.3299578428268433e-01
    z[2,1,3]  R901      1.0616496205329895e-01
    z[2,1,3]  R902      2.5820401310920715e-01
    z[2,1,3]  R903      7.9184156656265259e-01
    z[2,1,3]  R904      -8.7833821773529053e-02
    z[2,1,3]  R905      -6.3290582038462162e-03
    z[2,1,3]  R906      3.8389280438423157e-01
    z[2,1,3]  R907      5.2608340978622437e-01
    z[2,1,3]  R908      3.3938249945640564e-01
    z[2,1,3]  R909      2.5562044978141785e-01
    z[2,1,3]  R910      -3.0140110850334167e-01
    z[2,1,3]  R911      -2.7371674776077271e-01
    z[2,1,3]  R912      -0.520424485206604
    z[2,1,3]  R913      5.7561047375202179e-02
    z[2,1,3]  R914      -1.3779722154140472e-01
    z[2,1,3]  R915      1.5111909806728363e-01
    z[2,1,3]  R916      7.1562141180038452e-01
    z[2,1,3]  R917      7.0563733577728271e-01
    z[2,1,3]  R918      6.9247573614120483e-01
    z[2,1,3]  R919      3.9864847064018250e-01
    z[2,1,3]  R920      8.6471486091613770e-01
    z[2,1,3]  R921      2.9924002289772034e-01
    z[2,1,3]  R922      9.8448902368545532e-02
    z[2,1,3]  R923      0.0271736029535532
    z[2,1,3]  R924      1.0608037561178207e-01
    z[2,1,3]  R925      1.6946910321712494e-01
    z[2,1,3]  R926      3.3247882127761841e-01
    z[2,1,3]  R927      0.596255898475647
    z[2,1,3]  R928      1.9995900988578796e-01
    z[2,1,3]  R929      2.9122719168663025e-01
    z[2,1,3]  R930      -1.0755251161754131e-02
    z[2,1,3]  R931      -7.1085256338119507e-01
    z[2,1,3]  R932      -7.3259377479553223e-01
    z[2,1,3]  R933      6.1649543046951294e-01
    z[2,1,3]  R934      3.1919321417808533e-01
    z[2,1,3]  R935      0.474653959274292
    z[2,1,3]  R936      5.7778173685073853e-01
    z[2,1,3]  R937      2.9399591684341431e-01
    z[2,1,3]  R938      5.8195346593856812e-01
    z[2,1,3]  R939      4.9630695581436157e-01
    z[2,1,3]  R940      6.5015846490859985e-01
    z[2,1,3]  R941      1.1039676517248154e-01
    z[2,1,3]  R942      4.3881908059120178e-01
    z[2,1,3]  R943      5.5209094285964966e-01
    z[2,1,3]  R944      5.9213083982467651e-01
    z[2,1,3]  R945      0.625938355922699
    z[2,1,3]  R946      6.1959064006805420e-01
    z[2,1,3]  R947      3.7651520967483521e-01
    z[2,1,3]  R948      -4.0214595198631287e-01
    z[2,1,3]  R949      3.4837007522583008e-01
    z[2,1,4]  R15       1
    z[2,1,4]  R24       -1
    z[2,1,4]  R834      -1
    z[2,1,4]  R835      1
    z[2,1,4]  R840      2.2210077941417694e-01
    z[2,1,4]  R841      0.52739018201828
    z[2,1,4]  R842      6.0279220342636108e-02
    z[2,1,4]  R843      2.4187561124563217e-02
    z[2,1,4]  R844      -0.0906379222869873
    z[2,1,4]  R845      -3.1904366612434387e-01
    z[2,1,4]  R846      -1.3254015147686005e-01
    z[2,1,4]  R847      -5.0502443313598633e-01
    z[2,1,4]  R848      -1.4713397622108459e-01
    z[2,1,4]  R849      -2.8011593222618103e-01
    z[2,1,4]  R850      -3.7752330303192139e-01
    z[2,1,4]  R851      -2.7722901105880737e-01
    z[2,1,4]  R852      -3.1362017989158630e-01
    z[2,1,4]  R853      4.6093329787254333e-01
    z[2,1,4]  R854      4.8824116587638855e-01
    z[2,1,4]  R855      5.0413936376571655e-02
    z[2,1,4]  R856      -2.4194929003715515e-01
    z[2,1,4]  R857      -6.4516708254814148e-02
    z[2,1,4]  R858      2.3263719677925110e-01
    z[2,1,4]  R859      -2.1304479241371155e-01
    z[2,1,4]  R860      2.3986525833606720e-02
    z[2,1,4]  R861      9.1045916080474854e-02
    z[2,1,4]  R862      4.5402288436889648e-02
    z[2,1,4]  R863      -1.3329149782657623e-01
    z[2,1,4]  R864      -4.3217939138412476e-01
    z[2,1,4]  R865      -2.0710915327072144e-01
    z[2,1,4]  R866      -4.0176659822463989e-01
    z[2,1,4]  R867      -3.0604231357574463e-01
    z[2,1,4]  R868      -3.3184453845024109e-01
    z[2,1,4]  R869      1.4250871725380421e-02
    z[2,1,4]  R870      -3.2421648502349854e-01
    z[2,1,4]  R871      -0.287641316652298
    z[2,1,4]  R872      -2.5535440444946289e-01
    z[2,1,4]  R873      -6.8725836277008057e-01
    z[2,1,4]  R874      1.0965451598167419e-01
    z[2,1,4]  R875      -8.6141265928745270e-02
    z[2,1,4]  R876      -3.9865094423294067e-01
    z[2,1,4]  R877      -1.8897384405136108e-01
    z[2,1,4]  R878      2.6522138714790344e-01
    z[2,1,4]  R879      1.8102388083934784e-01
    z[2,1,4]  R880      -7.8041076660156250e-02
    z[2,1,4]  R881      -2.4372771382331848e-01
    z[2,1,4]  R882      1.0159488767385483e-01
    z[2,1,4]  R883      3.1711183488368988e-02
    z[2,1,4]  R884      1.2975813448429108e-01
    z[2,1,4]  R885      3.6978356540203094e-02
    z[2,1,4]  R886      4.7158572822809219e-02
    z[2,1,4]  R887      -2.0836353302001953e-01
    z[2,1,4]  R888      -7.6501868665218353e-02
    z[2,1,4]  R889      -2.3105712607502937e-03
    z[2,1,4]  R890      -2.3320877552032471e-01
    z[2,1,4]  R891      -1.1149710416793823e-01
    z[2,1,4]  R892      1.9031253457069397e-01
    z[2,1,4]  R893      -2.6426789164543152e-01
    z[2,1,4]  R894      3.6705070734024048e-01
    z[2,1,4]  R895      3.2231593132019043e-01
    z[2,1,4]  R896      -1.2098166346549988e-01
    z[2,1,4]  R897      4.6424347907304764e-02
    z[2,1,4]  R898      -2.0061565935611725e-01
    z[2,1,4]  R899      -3.2303226180374622e-03
    z[2,1,4]  R900      -1.9778303802013397e-01
    z[2,1,4]  R901      2.3271875083446503e-01
    z[2,1,4]  R902      -2.0879207551479340e-01
    z[2,1,4]  R903      -1.4656364917755127e-01
    z[2,1,4]  R904      3.8150716572999954e-02
    z[2,1,4]  R905      1.2002401798963547e-01
    z[2,1,4]  R906      3.2161605358123779e-01
    z[2,1,4]  R907      4.0730339288711548e-01
    z[2,1,4]  R908      4.8944327980279922e-02
    z[2,1,4]  R909      3.6813560128211975e-01
    z[2,1,4]  R910      -1.9165527820587158e-01
    z[2,1,4]  R911      4.9533969163894653e-01
    z[2,1,4]  R912      3.0061343312263489e-01
    z[2,1,4]  R913      2.9962889850139618e-02
    z[2,1,4]  R914      4.4709322974085808e-03
    z[2,1,4]  R915      -1.3671702146530151e-01
    z[2,1,4]  R916      1.6357812285423279e-01
    z[2,1,4]  R917      1.9558621942996979e-01
    z[2,1,4]  R918      3.6986431479454041e-01
    z[2,1,4]  R919      2.1674321591854095e-01
    z[2,1,4]  R920      -4.2414046823978424e-02
    z[2,1,4]  R921      -1.7318703234195709e-02
    z[2,1,4]  R922      3.6371055245399475e-01
    z[2,1,4]  R923      4.8381996154785156e-01
    z[2,1,4]  R924      -3.2471738755702972e-02
    z[2,1,4]  R925      5.8499181270599365e-01
    z[2,1,4]  R926      4.3477073311805725e-01
    z[2,1,4]  R927      1.2443201988935471e-01
    z[2,1,4]  R928      1.5923465788364410e-01
    z[2,1,4]  R929      4.4488483667373657e-01
    z[2,1,4]  R930      -1.4953131973743439e-01
    z[2,1,4]  R931      6.2398705631494522e-02
    z[2,1,4]  R932      2.5058604776859283e-02
    z[2,1,4]  R933      -4.4366973638534546e-01
    z[2,1,4]  R934      2.5789496302604675e-01
    z[2,1,4]  R935      4.7080650925636292e-01
    z[2,1,4]  R936      -1.0918192565441132e-03
    z[2,1,4]  R937      -1.5598331391811371e-01
    z[2,1,4]  R938      4.9181395769119263e-01
    z[2,1,4]  R939      7.5598949193954468e-01
    z[2,1,4]  R940      -1.1459868401288986e-01
    z[2,1,4]  R941      -3.6937814950942993e-01
    z[2,1,4]  R942      3.9902281761169434e-01
    z[2,1,4]  R943      2.1089439094066620e-01
    z[2,1,4]  R944      3.0564457178115845e-01
    z[2,1,4]  R945      2.1205591037869453e-02
    z[2,1,4]  R946      6.6968256235122681e-01
    z[2,1,4]  R947      3.4454742074012756e-01
    z[2,1,4]  R948      4.2818868532776833e-03
    z[2,1,4]  R949      4.8093062639236450e-01
    z[2,1,5]  R16       1
    z[2,1,5]  R25       -1
    z[2,1,5]  R836      -1
    z[2,1,5]  R837      1
    z[2,1,5]  R840      1.9332119822502136e-01
    z[2,1,5]  R841      5.3401970863342285e-01
    z[2,1,5]  R842      -1.6601161658763885e-01
    z[2,1,5]  R843      -2.6130869984626770e-02
    z[2,1,5]  R844      3.3052659034729004e-01
    z[2,1,5]  R845      1.1951579898595810e-01
    z[2,1,5]  R846      1.1675358563661575e-01
    z[2,1,5]  R847      1.0763483494520187e-01
    z[2,1,5]  R848      -1.8017560243606567e-01
    z[2,1,5]  R849      -1.7369458079338074e-01
    z[2,1,5]  R850      -4.4999197125434875e-01
    z[2,1,5]  R851      -2.0654010772705078e-01
    z[2,1,5]  R852      2.0217722654342651e-01
    z[2,1,5]  R853      2.8861439228057861e-01
    z[2,1,5]  R854      -1.7662626504898071e-01
    z[2,1,5]  R855      -1.4387050271034241e-01
    z[2,1,5]  R856      -0.556344211101532
    z[2,1,5]  R857      1.0969237983226776e-01
    z[2,1,5]  R858      -2.7493458986282349e-01
    z[2,1,5]  R859      -9.7647741436958313e-02
    z[2,1,5]  R860      -3.8001391291618347e-01
    z[2,1,5]  R861      1.6607622802257538e-01
    z[2,1,5]  R862      -1.3904532790184021e-01
    z[2,1,5]  R863      0.0678798034787178
    z[2,1,5]  R864      -2.3103940486907959e-01
    z[2,1,5]  R865      -2.0109573379158974e-02
    z[2,1,5]  R866      -2.1075604856014252e-01
    z[2,1,5]  R867      1.0331179201602936e-01
    z[2,1,5]  R868      -2.6430118083953857e-01
    z[2,1,5]  R869      5.0883638858795166e-01
    z[2,1,5]  R870      -7.6462127268314362e-02
    z[2,1,5]  R871      3.5775130987167358e-01
    z[2,1,5]  R872      -5.0992354750633240e-02
    z[2,1,5]  R873      6.8135358393192291e-02
    z[2,1,5]  R874      4.2147073149681091e-01
    z[2,1,5]  R875      9.6685782074928284e-02
    z[2,1,5]  R876      2.4848919361829758e-02
    z[2,1,5]  R877      3.7973019480705261e-01
    z[2,1,5]  R878      -3.8027125597000122e-01
    z[2,1,5]  R879      -2.2399128973484039e-01
    z[2,1,5]  R880      1.3740417361259460e-01
    z[2,1,5]  R881      3.0534034967422485e-01
    z[2,1,5]  R882      3.5866221785545349e-01
    z[2,1,5]  R883      5.9211300686001778e-03
    z[2,1,5]  R884      -1.6443461179733276e-02
    z[2,1,5]  R885      2.0932057499885559e-01
    z[2,1,5]  R886      3.7273299694061279e-01
    z[2,1,5]  R887      2.1522977948188782e-01
    z[2,1,5]  R888      0.511130690574646
    z[2,1,5]  R889      3.6250913143157959e-01
    z[2,1,5]  R890      -0.648076057434082
    z[2,1,5]  R891      0.0657590702176094
    z[2,1,5]  R892      -2.9661828279495239e-01
    z[2,1,5]  R893      -7.6879158616065979e-02
    z[2,1,5]  R894      -2.1222910284996033e-01
    z[2,1,5]  R895      1.6392305493354797e-01
    z[2,1,5]  R896      -4.2393404245376587e-01
    z[2,1,5]  R897      -1.5759025514125824e-01
    z[2,1,5]  R898      -3.9872181415557861e-01
    z[2,1,5]  R899      7.0305779576301575e-02
    z[2,1,5]  R900      4.1900908946990967e-01
    z[2,1,5]  R901      1.4060950279235840e-01
    z[2,1,5]  R902      -4.0386593341827393e-01
    z[2,1,5]  R903      2.3328746855258942e-01
    z[2,1,5]  R904      1.4735272526741028e-01
    z[2,1,5]  R905      -1.0939425788819790e-02
    z[2,1,5]  R906      -2.9343429952859879e-02
    z[2,1,5]  R907      6.4921337366104126e-01
    z[2,1,5]  R908      5.4124879837036133e-01
    z[2,1,5]  R909      -2.0792341232299805e-01
    z[2,1,5]  R910      2.0585437119007111e-01
    z[2,1,5]  R911      -9.0375185012817383e-02
    z[2,1,5]  R912      -4.8706404864788055e-02
    z[2,1,5]  R913      -1.5952616930007935e-01
    z[2,1,5]  R914      -4.9883734434843063e-02
    z[2,1,5]  R915      -3.8910800218582153e-01
    z[2,1,5]  R916      4.2181101441383362e-01
    z[2,1,5]  R917      -1.6269692778587341e-01
    z[2,1,5]  R918      -1.3045889139175415e-01
    z[2,1,5]  R919      8.8567227125167847e-02
    z[2,1,5]  R920      3.1192660331726074e-01
    z[2,1,5]  R921      3.9336517453193665e-01
    z[2,1,5]  R922      2.0151710510253906e-01
    z[2,1,5]  R923      9.1979645192623138e-02
    z[2,1,5]  R924      -4.3433707207441330e-02
    z[2,1,5]  R925      -3.8120919466018677e-01
    z[2,1,5]  R926      -1.0739266127347946e-01
    z[2,1,5]  R927      1.6362212598323822e-01
    z[2,1,5]  R928      -3.6934378743171692e-01
    z[2,1,5]  R929      -4.7725012898445129e-01
    z[2,1,5]  R930      -0.523442268371582
    z[2,1,5]  R931      -2.9658830165863037e-01
    z[2,1,5]  R932      2.5670301169157028e-02
    z[2,1,5]  R933      8.1822425127029419e-02
    z[2,1,5]  R934      -6.0947993770241737e-03
    z[2,1,5]  R935      3.6438152194023132e-01
    z[2,1,5]  R936      -3.4555536508560181e-01
    z[2,1,5]  R937      -4.6714732050895691e-01
    z[2,1,5]  R938      1.2319060415029526e-01
    z[2,1,5]  R939      5.1724273711442947e-02
    z[2,1,5]  R940      2.0836119353771210e-01
    z[2,1,5]  R941      -2.1691080927848816e-01
    z[2,1,5]  R942      1.4422725141048431e-01
    z[2,1,5]  R943      -9.9152170121669769e-02
    z[2,1,5]  R944      -1.5527497231960297e-01
    z[2,1,5]  R945      3.7689003348350525e-01
    z[2,1,5]  R946      -8.8169820606708527e-02
    z[2,1,5]  R947      2.3336377739906311e-01
    z[2,1,5]  R948      -1.3693358004093170e-01
    z[2,1,5]  R949      4.8149690032005310e-02
    z[2,1,6]  R17       1
    z[2,1,6]  R26       -1
    z[2,1,6]  R838      -1
    z[2,1,6]  R839      1
    z[2,1,6]  R840      5.0117647647857666e-01
    z[2,1,6]  R841      -4.4853731989860535e-01
    z[2,1,6]  R842      -3.0730417370796204e-01
    z[2,1,6]  R843      8.7859280407428741e-02
    z[2,1,6]  R844      -4.8645719885826111e-02
    z[2,1,6]  R845      -6.7843578755855560e-02
    z[2,1,6]  R846      -2.3056827485561371e-01
    z[2,1,6]  R847      1.1112280935049057e-01
    z[2,1,6]  R848      -3.7142220884561539e-02
    z[2,1,6]  R849      0.476544052362442
    z[2,1,6]  R850      -5.4714262485504150e-02
    z[2,1,6]  R851      -4.4603458046913147e-01
    z[2,1,6]  R852      1.7056821286678314e-01
    z[2,1,6]  R853      4.1587987542152405e-01
    z[2,1,6]  R854      1.8179066479206085e-01
    z[2,1,6]  R855      2.2592335939407349e-01
    z[2,1,6]  R856      2.2567810118198395e-01
    z[2,1,6]  R857      1.1582200415432453e-02
    z[2,1,6]  R858      2.9293093830347061e-02
    z[2,1,6]  R859      -5.0506293773651123e-01
    z[2,1,6]  R860      -3.0052134394645691e-01
    z[2,1,6]  R861      3.8794970512390137e-01
    z[2,1,6]  R862      1.2793380022048950e-01
    z[2,1,6]  R863      4.3868002295494080e-01
    z[2,1,6]  R864      3.8199447095394135e-02
    z[2,1,6]  R865      -6.4267016947269440e-02
    z[2,1,6]  R866      -1.1250492185354233e-01
    z[2,1,6]  R867      1.0586041212081909e-01
    z[2,1,6]  R868      -3.6997777223587036e-01
    z[2,1,6]  R869      -9.2456437647342682e-02
    z[2,1,6]  R870      -0.383847177028656
    z[2,1,6]  R871      2.1412980556488037e-01
    z[2,1,6]  R872      4.4229626655578613e-02
    z[2,1,6]  R873      -1.1348040401935577e-01
    z[2,1,6]  R874      -7.0780552923679352e-02
    z[2,1,6]  R875      2.3420266807079315e-01
    z[2,1,6]  R876      -3.5714048147201538e-01
    z[2,1,6]  R877      -4.1779378056526184e-01
    z[2,1,6]  R878      -9.8797872662544250e-02
    z[2,1,6]  R879      -2.7079728245735168e-01
    z[2,1,6]  R880      -2.8398019075393677e-01
    z[2,1,6]  R881      2.7448818087577820e-01
    z[2,1,6]  R882      -3.8419350981712341e-02
    z[2,1,6]  R883      9.7134284675121307e-02
    z[2,1,6]  R884      -2.4830566346645355e-01
    z[2,1,6]  R885      -1.3310468196868896e-01
    z[2,1,6]  R886      3.7576359510421753e-01
    z[2,1,6]  R887      -2.8193789720535278e-01
    z[2,1,6]  R888      4.6669259667396545e-02
    z[2,1,6]  R889      -4.4715738296508789e-01
    z[2,1,6]  R890      4.4310346245765686e-02
    z[2,1,6]  R891      1.8833646178245544e-01
    z[2,1,6]  R892      -0.0983353853225708
    z[2,1,6]  R893      1.8292682245373726e-02
    z[2,1,6]  R894      1.5415126085281372e-01
    z[2,1,6]  R895      1.4263746142387390e-01
    z[2,1,6]  R896      4.6091634035110474e-01
    z[2,1,6]  R897      3.7453049421310425e-01
    z[2,1,6]  R898      6.3131886720657349e-01
    z[2,1,6]  R899      -1.3046045601367950e-01
    z[2,1,6]  R900      7.2290033102035522e-02
    z[2,1,6]  R901      3.5995218157768250e-01
    z[2,1,6]  R902      1.5154068171977997e-01
    z[2,1,6]  R903      -1.5079037845134735e-01
    z[2,1,6]  R904      1.1484432965517044e-01
    z[2,1,6]  R905      -0.736470639705658
    z[2,1,6]  R906      5.0123695284128189e-02
    z[2,1,6]  R907      1.2904106080532074e-01
    z[2,1,6]  R908      7.2645372711122036e-03
    z[2,1,6]  R909      7.1147575974464417e-02
    z[2,1,6]  R910      3.2846489548683167e-01
    z[2,1,6]  R911      -1.5908074378967285e-01
    z[2,1,6]  R912      -4.5059084892272949e-01
    z[2,1,6]  R913      -3.3879649639129639e-01
    z[2,1,6]  R914      -3.3033692836761475e-01
    z[2,1,6]  R915      7.6765216886997223e-02
    z[2,1,6]  R916      -2.9396224021911621e-01
    z[2,1,6]  R917      4.3577242642641068e-02
    z[2,1,6]  R918      1.2319776415824890e-01
    z[2,1,6]  R919      -5.3875666856765747e-01
    z[2,1,6]  R920      8.8483437895774841e-02
    z[2,1,6]  R921      2.8057926893234253e-01
    z[2,1,6]  R922      -6.0776922851800919e-02
    z[2,1,6]  R923      3.0879381299018860e-01
    z[2,1,6]  R924      -3.5192728042602539e-01
    z[2,1,6]  R925      -2.6379138231277466e-01
    z[2,1,6]  R926      4.2512655258178711e-02
    z[2,1,6]  R927      -1.8563105165958405e-01
    z[2,1,6]  R928      3.3686894178390503e-01
    z[2,1,6]  R929      -9.7422868013381958e-02
    z[2,1,6]  R930      2.1099606156349182e-01
    z[2,1,6]  R931      2.7201318740844727e-01
    z[2,1,6]  R932      5.4628539085388184e-01
    z[2,1,6]  R933      5.2705843001604080e-02
    z[2,1,6]  R934      -8.0805547535419464e-02
    z[2,1,6]  R935      -3.9299684762954712e-01
    z[2,1,6]  R936      1.1600001901388168e-01
    z[2,1,6]  R937      1.1144879460334778e-01
    z[2,1,6]  R938      2.8317835927009583e-01
    z[2,1,6]  R939      2.0880098640918732e-01
    z[2,1,6]  R940      2.0675741136074066e-01
    z[2,1,6]  R941      4.8996829986572266e-01
    z[2,1,6]  R942      -2.7041694149374962e-02
    z[2,1,6]  R943      9.9062584340572357e-02
    z[2,1,6]  R944      -4.4209539890289307e-01
    z[2,1,6]  R945      -5.9952650219202042e-02
    z[2,1,6]  R946      2.1013806760311127e-01
    z[2,1,6]  R947      -3.7109214812517166e-02
    z[2,1,6]  R948      0.456543892621994
    z[2,1,6]  R949      3.6825588345527649e-01
    z[2,3,0]  R20       -1
    z[2,3,0]  R29       1
    z[2,3,0]  R950      -1
    z[2,3,0]  R951      1
    z[2,3,0]  R964      -1.6967041790485382e-01
    z[2,3,0]  R965      -1.3388785719871521e-01
    z[2,3,0]  R966      3.0542594194412231e-01
    z[2,3,0]  R967      -0.77823805809021
    z[2,3,0]  R968      -7.9751676321029663e-01
    z[2,3,0]  R969      -8.5658162832260132e-01
    z[2,3,0]  R970      -8.0390030145645142e-01
    z[2,3,0]  R971      -7.7379405498504639e-01
    z[2,3,0]  R972      -8.9063447713851929e-01
    z[2,3,0]  R973      -1.7608661949634552e-01
    z[2,3,0]  R974      1.0001166909933090e-01
    z[2,3,0]  R975      4.4433104991912842e-01
    z[2,3,0]  R976      3.6617133021354675e-01
    z[2,3,0]  R977      1.9942130148410797e-01
    z[2,3,0]  R978      -1.2687428295612335e-01
    z[2,3,0]  R979      -3.5667607188224792e-01
    z[2,3,0]  R980      -5.2196753025054932e-01
    z[2,3,0]  R981      -2.4494828283786774e-01
    z[2,3,0]  R982      -7.5037801265716553e-01
    z[2,3,0]  R983      1.8949049711227417e-01
    z[2,3,0]  R984      -6.1510574817657471e-01
    z[2,3,0]  R985      -3.4907853603363037e-01
    z[2,3,0]  R986      -1.6321410238742828e-01
    z[2,3,0]  R987      -3.3627992868423462e-01
    z[2,3,0]  R988      1.2292774766683578e-01
    z[2,3,0]  R989      1.1723812669515610e-01
    z[2,3,0]  R990      2.9016089439392090e-01
    z[2,3,0]  R991      2.1073332428932190e-01
    z[2,3,0]  R992      1.3649851083755493e-01
    z[2,3,0]  R993      3.8373467326164246e-01
    z[2,3,0]  R994      -5.4624056816101074e-01
    z[2,3,0]  R995      -0.424212247133255
    z[2,3,0]  R996      7.1994647383689880e-02
    z[2,3,0]  R997      -6.1272311210632324e-01
    z[2,3,0]  R998      -6.4805978536605835e-01
    z[2,3,0]  R999      -3.4386971592903137e-01
    z[2,3,0]  R1000     -8.9542247354984283e-02
    z[2,3,0]  R1001     1.1211939901113510e-01
    z[2,3,0]  R1002     -2.8060302138328552e-01
    z[2,3,0]  R1003     3.1735548377037048e-01
    z[2,3,0]  R1004     -6.1525338888168335e-01
    z[2,3,0]  R1005     -8.6321853101253510e-02
    z[2,3,0]  R1006     1.6740697622299194e-01
    z[2,3,0]  R1007     3.4569454193115234e-01
    z[2,3,0]  R1008     5.2569651603698730e-01
    z[2,3,0]  R1009     3.9396968483924866e-01
    z[2,3,0]  R1010     2.5449299812316895e-01
    z[2,3,0]  R1011     -6.4478024840354919e-02
    z[2,3,0]  R1012     -3.1391513347625732e-01
    z[2,3,0]  R1013     0.0785473957657814
    z[2,3,0]  R1014     -0.202298104763031
    z[2,3,0]  R1015     -3.6601746082305908e-01
    z[2,3,0]  R1016     1.3802783191204071e-01
    z[2,3,0]  R1017     -0.574720025062561
    z[2,3,0]  R1018     -1.1223085224628448e-01
    z[2,3,0]  R1019     -2.9490327835083008e-01
    z[2,3,0]  R1020     3.1449355185031891e-02
    z[2,3,0]  R1021     -2.7709737420082092e-02
    z[2,3,0]  R1022     -7.8968949615955353e-02
    z[2,3,0]  R1023     1.7646408081054688e-01
    z[2,3,0]  R1024     -1.8827441334724426e-01
    z[2,3,0]  R1025     -2.2635528445243835e-01
    z[2,3,0]  R1026     2.1855413913726807e-01
    z[2,3,0]  R1027     -4.7770336270332336e-02
    z[2,3,0]  R1028     1.0365481674671173e-01
    z[2,3,0]  R1029     -1.7878907918930054e-01
    z[2,3,0]  R1030     -4.6802438795566559e-02
    z[2,3,0]  R1031     -5.0883240997791290e-02
    z[2,3,0]  R1032     1.4553122222423553e-01
    z[2,3,0]  R1033     2.3893390595912933e-01
    z[2,3,0]  R1034     -8.7573036551475525e-02
    z[2,3,0]  R1035     3.5484347492456436e-02
    z[2,3,0]  R1036     -1.9336035475134850e-02
    z[2,3,0]  R1037     5.8665376156568527e-02
    z[2,3,0]  R1038     -3.2212796807289124e-01
    z[2,3,0]  R1039     2.3365199565887451e-01
    z[2,3,0]  R1040     -1.0389288514852524e-01
    z[2,3,0]  R1041     -4.9414080381393433e-01
    z[2,3,0]  R1042     -4.2689168453216553e-01
    z[2,3,0]  R1043     2.8846862912178040e-01
    z[2,3,1]  R21       -1
    z[2,3,1]  R30       1
    z[2,3,1]  R952      -1
    z[2,3,1]  R953      1
    z[2,3,1]  R964      7.5533652305603027e-01
    z[2,3,1]  R965      1.5082035958766937e-01
    z[2,3,1]  R966      3.2670933008193970e-01
    z[2,3,1]  R967      -8.6420841515064240e-02
    z[2,3,1]  R968      -9.3506224453449249e-02
    z[2,3,1]  R969      -8.2904092967510223e-02
    z[2,3,1]  R970      7.6480291783809662e-02
    z[2,3,1]  R971      -4.5369766652584076e-02
    z[2,3,1]  R972      -4.7882851213216782e-02
    z[2,3,1]  R973      -1.4118745923042297e-01
    z[2,3,1]  R974      1.1222476139664650e-02
    z[2,3,1]  R975      4.5571732521057129e-01
    z[2,3,1]  R976      -4.6389934420585632e-01
    z[2,3,1]  R977      -4.7327658534049988e-01
    z[2,3,1]  R978      -4.2640617489814758e-01
    z[2,3,1]  R979      -4.0584355592727661e-01
    z[2,3,1]  R980      -0.498304545879364
    z[2,3,1]  R981      -0.765228807926178
    z[2,3,1]  R982      -4.2069500684738159e-01
    z[2,3,1]  R983      -3.6247938871383667e-01
    z[2,3,1]  R984      -5.1551681756973267e-01
    z[2,3,1]  R985      -7.5431865453720093e-01
    z[2,3,1]  R986      -4.4682428240776062e-01
    z[2,3,1]  R987      -7.0357149839401245e-01
    z[2,3,1]  R988      -6.1069816350936890e-01
    z[2,3,1]  R989      -6.9779038429260254e-01
    z[2,3,1]  R990      -0.66790372133255
    z[2,3,1]  R991      -7.9137659072875977e-01
    z[2,3,1]  R992      -6.8418294191360474e-01
    z[2,3,1]  R993      -7.2239428758621216e-01
    z[2,3,1]  R994      7.9328608512878418e-01
    z[2,3,1]  R995      7.6735401153564453e-01
    z[2,3,1]  R996      6.3840603828430176e-01
    z[2,3,1]  R997      1.1874987185001373e-01
    z[2,3,1]  R998      1.6845221817493439e-01
    z[2,3,1]  R999      1.1892323940992355e-01
    z[2,3,1]  R1000     -4.9029093235731125e-02
    z[2,3,1]  R1001     -2.0932072773575783e-02
    z[2,3,1]  R1002     -5.1081206649541855e-02
    z[2,3,1]  R1003     -4.6568468213081360e-02
    z[2,3,1]  R1004     -6.5252298116683960e-01
    z[2,3,1]  R1005     -6.6241371631622314e-01
    z[2,3,1]  R1006     -6.3512933254241943e-01
    z[2,3,1]  R1007     -5.6671643257141113e-01
    z[2,3,1]  R1008     -5.8184927701950073e-01
    z[2,3,1]  R1009     -8.0940610170364380e-01
    z[2,3,1]  R1010     -5.6583595275878906e-01
    z[2,3,1]  R1011     -5.6445431709289551e-01
    z[2,3,1]  R1012     -6.2445646524429321e-01
    z[2,3,1]  R1013     -5.3245031833648682e-01
    z[2,3,1]  R1014     -7.7334809303283691e-01
    z[2,3,1]  R1015     -6.9144630432128906e-01
    z[2,3,1]  R1016     -0.743336021900177
    z[2,3,1]  R1017     -6.4037960767745972e-01
    z[2,3,1]  R1018     4.4405010342597961e-01
    z[2,3,1]  R1019     -6.9568479061126709e-01
    z[2,3,1]  R1020     0.522428035736084
    z[2,3,1]  R1021     -5.3287369012832642e-01
    z[2,3,1]  R1022     4.8844003677368164e-01
    z[2,3,1]  R1023     6.3939177989959717e-01
    z[2,3,1]  R1024     -8.4677040576934814e-01
    z[2,3,1]  R1025     -8.7058031558990479e-01
    z[2,3,1]  R1026     -8.9668089151382446e-01
    z[2,3,1]  R1027     -7.2005736827850342e-01
    z[2,3,1]  R1028     -6.7852222919464111e-01
    z[2,3,1]  R1029     0.713131844997406
    z[2,3,1]  R1030     -6.1013668775558472e-01
    z[2,3,1]  R1031     -6.1674284934997559e-01
    z[2,3,1]  R1032     6.5785801410675049e-01
    z[2,3,1]  R1033     8.5632407665252686e-01
    z[2,3,1]  R1034     6.4206200838088989e-01
    z[2,3,1]  R1035     8.7107646465301514e-01
    z[2,3,1]  R1036     -7.5011372566223145e-01
    z[2,3,1]  R1037     -8.7947982549667358e-01
    z[2,3,1]  R1038     4.7453027963638306e-01
    z[2,3,1]  R1039     -6.2827903032302856e-01
    z[2,3,1]  R1040     6.8753391504287720e-01
    z[2,3,1]  R1041     3.6887449026107788e-01
    z[2,3,1]  R1042     3.3512553572654724e-01
    z[2,3,1]  R1043     -0.559316098690033
    z[2,3,2]  R22       -1
    z[2,3,2]  R31       1
    z[2,3,2]  R954      -1
    z[2,3,2]  R955      1
    z[2,3,2]  R964      -3.1709957867860794e-02
    z[2,3,2]  R965      -1.1720193177461624e-01
    z[2,3,2]  R966      8.2046687602996826e-01
    z[2,3,2]  R967      4.8310512304306030e-01
    z[2,3,2]  R968      3.8264030218124390e-01
    z[2,3,2]  R969      3.7091696262359619e-01
    z[2,3,2]  R970      2.1323429048061371e-01
    z[2,3,2]  R971      -3.1985055655241013e-02
    z[2,3,2]  R972      -3.7263888120651245e-01
    z[2,3,2]  R973      -5.7381969690322876e-01
    z[2,3,2]  R974      -9.8400421440601349e-02
    z[2,3,2]  R975      -5.2164769172668457e-01
    z[2,3,2]  R976      -6.6140770912170410e-01
    z[2,3,2]  R977      -9.3525443226099014e-03
    z[2,3,2]  R978      -6.2786054611206055e-01
    z[2,3,2]  R979      -7.6410883665084839e-01
    z[2,3,2]  R980      -1.3354372978210449e-01
    z[2,3,2]  R981      -5.2212452888488770e-01
    z[2,3,2]  R982      2.8210720419883728e-01
    z[2,3,2]  R983      -5.5925279855728149e-01
    z[2,3,2]  R984      -0.313320517539978
    z[2,3,2]  R985      2.8686714172363281e-01
    z[2,3,2]  R986      4.6897572278976440e-01
    z[2,3,2]  R987      -4.2075714468955994e-01
    z[2,3,2]  R988      -4.1321775317192078e-01
    z[2,3,2]  R989      -1.0324368625879288e-01
    z[2,3,2]  R990      -5.2678704261779785e-02
    z[2,3,2]  R991      -2.9144442081451416e-01
    z[2,3,2]  R992      -2.6429215073585510e-01
    z[2,3,2]  R993      1.5398591756820679e-01
    z[2,3,2]  R994      2.4101685732603073e-02
    z[2,3,2]  R995      -1.2400750815868378e-01
    z[2,3,2]  R996      5.2930307388305664e-01
    z[2,3,2]  R997      5.2981162071228027e-01
    z[2,3,2]  R998      5.2514404058456421e-01
    z[2,3,2]  R999      3.1009066104888916e-01
    z[2,3,2]  R1000     -4.4367730617523193e-01
    z[2,3,2]  R1001     -8.0586922168731689e-01
    z[2,3,2]  R1002     -7.8454381227493286e-01
    z[2,3,2]  R1003     8.0022051930427551e-02
    z[2,3,2]  R1004     0.0970572754740715
    z[2,3,2]  R1005     0.152975931763649
    z[2,3,2]  R1006     3.4097391366958618e-01
    z[2,3,2]  R1007     -3.8507252931594849e-01
    z[2,3,2]  R1008     -6.8089894950389862e-02
    z[2,3,2]  R1009     -2.3545506596565247e-01
    z[2,3,2]  R1010     -5.0401028245687485e-02
    z[2,3,2]  R1011     8.3726853132247925e-02
    z[2,3,2]  R1012     1.0667237639427185e-01
    z[2,3,2]  R1013     -2.7492982149124146e-01
    z[2,3,2]  R1014     -4.1653178632259369e-02
    z[2,3,2]  R1015     2.7315405011177063e-01
    z[2,3,2]  R1016     1.5096355974674225e-01
    z[2,3,2]  R1017     4.1382029652595520e-01
    z[2,3,2]  R1018     5.0347495079040527e-01
    z[2,3,2]  R1019     -9.3935750424861908e-02
    z[2,3,2]  R1020     4.3033921718597412e-01
    z[2,3,2]  R1021     -4.3597763776779175e-01
    z[2,3,2]  R1022     1.1288274079561234e-01
    z[2,3,2]  R1023     6.4795380830764771e-01
    z[2,3,2]  R1024     -2.4157375097274780e-01
    z[2,3,2]  R1025     -3.2371073961257935e-02
    z[2,3,2]  R1026     0.0947737991809845
    z[2,3,2]  R1027     -2.7153888344764709e-01
    z[2,3,2]  R1028     -5.3877639770507812e-01
    z[2,3,2]  R1029     3.5098394751548767e-01
    z[2,3,2]  R1030     -2.7506032586097717e-01
    z[2,3,2]  R1031     3.3013519644737244e-01
    z[2,3,2]  R1032     3.1272286176681519e-01
    z[2,3,2]  R1033     3.6370927095413208e-01
    z[2,3,2]  R1034     4.2421030998229980e-01
    z[2,3,2]  R1035     1.8731613457202911e-01
    z[2,3,2]  R1036     2.3560628294944763e-02
    z[2,3,2]  R1037     2.8810295462608337e-01
    z[2,3,2]  R1038     1.2663708627223969e-01
    z[2,3,2]  R1039     -3.2625325024127960e-02
    z[2,3,2]  R1040     2.0188353955745697e-02
    z[2,3,2]  R1041     4.5583987236022949e-01
    z[2,3,2]  R1042     5.1397567987442017e-01
    z[2,3,2]  R1043     0.0961170494556427
    z[2,3,3]  R23       -1
    z[2,3,3]  R32       1
    z[2,3,3]  R956      -1
    z[2,3,3]  R957      1
    z[2,3,3]  R964      2.4858303368091583e-01
    z[2,3,3]  R965      4.2554402351379395e-01
    z[2,3,3]  R966      0.0343628004193306
    z[2,3,3]  R967      -3.8013058900833130e-01
    z[2,3,3]  R968      -2.9829597473144531e-01
    z[2,3,3]  R969      -3.3759616315364838e-02
    z[2,3,3]  R970      -4.6697562932968140e-01
    z[2,3,3]  R971      -3.4522190690040588e-01
    z[2,3,3]  R972      -1.0063122212886810e-01
    z[2,3,3]  R973      -0.532974362373352
    z[2,3,3]  R974      0.795096755027771
    z[2,3,3]  R975      -6.5679289400577545e-02
    z[2,3,3]  R976      2.1196436882019043e-01
    z[2,3,3]  R977      -5.1714515686035156e-01
    z[2,3,3]  R978      -3.2441899180412292e-01
    z[2,3,3]  R979      2.2344872355461121e-01
    z[2,3,3]  R980      -2.0596009492874146e-01
    z[2,3,3]  R981      -2.5589501857757568e-01
    z[2,3,3]  R982      -2.2315208613872528e-01
    z[2,3,3]  R983      -4.5817753672599792e-01
    z[2,3,3]  R984      -1.4972835779190063e-01
    z[2,3,3]  R985      2.0119418203830719e-01
    z[2,3,3]  R986      -7.1833759546279907e-01
    z[2,3,3]  R987      7.2061540558934212e-03
    z[2,3,3]  R988      -4.4673284888267517e-01
    z[2,3,3]  R989      -6.6427075862884521e-01
    z[2,3,3]  R990      -4.9844187498092651e-01
    z[2,3,3]  R991      -3.5893306136131287e-01
    z[2,3,3]  R992      -3.5574150085449219e-01
    z[2,3,3]  R993      -1.9878847897052765e-01
    z[2,3,3]  R994      1.5139020979404449e-01
    z[2,3,3]  R995      2.9603728652000427e-01
    z[2,3,3]  R996      1.5822613239288330e-01
    z[2,3,3]  R997      2.4612200260162354e-01
    z[2,3,3]  R998      1.1945197731256485e-01
    z[2,3,3]  R999      0.0224288459867239
    z[2,3,3]  R1000     -5.5111384391784668e-01
    z[2,3,3]  R1001     4.6425831317901611e-01
    z[2,3,3]  R1002     -4.1696190834045410e-01
    z[2,3,3]  R1003     -8.2614302635192871e-01
    z[2,3,3]  R1004     -4.0400597453117371e-01
    z[2,3,3]  R1005     -0.0763794332742691
    z[2,3,3]  R1006     -2.2706650197505951e-01
    z[2,3,3]  R1007     -7.7574424445629120e-02
    z[2,3,3]  R1008     -5.6893610954284668e-01
    z[2,3,3]  R1009     -3.5073789954185486e-01
    z[2,3,3]  R1010     -1.8418912589550018e-01
    z[2,3,3]  R1011     3.3512806892395020e-01
    z[2,3,3]  R1012     1.7176859080791473e-01
    z[2,3,3]  R1013     -1.3978110253810883e-01
    z[2,3,3]  R1014     -4.3832760304212570e-02
    z[2,3,3]  R1015     0.148304283618927
    z[2,3,3]  R1016     4.6387454867362976e-01
    z[2,3,3]  R1017     2.2624848783016205e-01
    z[2,3,3]  R1018     6.2244117259979248e-01
    z[2,3,3]  R1019     4.6368911862373352e-01
    z[2,3,3]  R1020     5.2992373704910278e-01
    z[2,3,3]  R1021     -3.0490031838417053e-01
    z[2,3,3]  R1022     6.3828772306442261e-01
    z[2,3,3]  R1023     5.4679099470376968e-02
    z[2,3,3]  R1024     2.2161155939102173e-01
    z[2,3,3]  R1025     1.2202896922826767e-01
    z[2,3,3]  R1026     3.0636712908744812e-01
    z[2,3,3]  R1027     -5.1346111297607422e-01
    z[2,3,3]  R1028     -0.125356987118721
    z[2,3,3]  R1029     -1.5767522156238556e-01
    z[2,3,3]  R1030     -0.00643932493403554
    z[2,3,3]  R1031     -5.5639952421188354e-01
    z[2,3,3]  R1032     2.8882962465286255e-01
    z[2,3,3]  R1033     -1.5325054526329041e-01
    z[2,3,3]  R1034     5.3501695394515991e-01
    z[2,3,3]  R1035     2.5933426618576050e-01
    z[2,3,3]  R1036     -1.9293682649731636e-02
    z[2,3,3]  R1037     -8.1855103373527527e-02
    z[2,3,3]  R1038     7.2345834970474243e-01
    z[2,3,3]  R1039     -2.1861200034618378e-01
    z[2,3,3]  R1040     1.4545749127864838e-01
    z[2,3,3]  R1041     2.9838341474533081e-01
    z[2,3,3]  R1042     2.6166230440139771e-01
    z[2,3,3]  R1043     -4.8168757557868958e-01
    z[2,3,4]  R24       -1
    z[2,3,4]  R33       1
    z[2,3,4]  R958      -1
    z[2,3,4]  R959      1
    z[2,3,4]  R964      2.2210077941417694e-01
    z[2,3,4]  R965      0.52739018201828
    z[2,3,4]  R966      6.0279220342636108e-02
    z[2,3,4]  R967      2.4187561124563217e-02
    z[2,3,4]  R968      -0.0906379222869873
    z[2,3,4]  R969      -3.1904366612434387e-01
    z[2,3,4]  R970      -1.3254015147686005e-01
    z[2,3,4]  R971      -5.0502443313598633e-01
    z[2,3,4]  R972      -1.4713397622108459e-01
    z[2,3,4]  R973      -2.8011593222618103e-01
    z[2,3,4]  R974      -3.7752330303192139e-01
    z[2,3,4]  R975      -2.7722901105880737e-01
    z[2,3,4]  R976      -3.1362017989158630e-01
    z[2,3,4]  R977      4.6093329787254333e-01
    z[2,3,4]  R978      4.8824116587638855e-01
    z[2,3,4]  R979      5.0413936376571655e-02
    z[2,3,4]  R980      -2.4194929003715515e-01
    z[2,3,4]  R981      -6.4516708254814148e-02
    z[2,3,4]  R982      2.3263719677925110e-01
    z[2,3,4]  R983      -2.1304479241371155e-01
    z[2,3,4]  R984      2.3986525833606720e-02
    z[2,3,4]  R985      9.1045916080474854e-02
    z[2,3,4]  R986      4.5402288436889648e-02
    z[2,3,4]  R987      -1.3329149782657623e-01
    z[2,3,4]  R988      -4.3217939138412476e-01
    z[2,3,4]  R989      -2.0710915327072144e-01
    z[2,3,4]  R990      -4.0176659822463989e-01
    z[2,3,4]  R991      -3.0604231357574463e-01
    z[2,3,4]  R992      -3.3184453845024109e-01
    z[2,3,4]  R993      1.4250871725380421e-02
    z[2,3,4]  R994      -9.9260888993740082e-02
    z[2,3,4]  R995      -1.8220679461956024e-01
    z[2,3,4]  R996      1.9566479325294495e-01
    z[2,3,4]  R997      -4.1278502345085144e-01
    z[2,3,4]  R998      1.5285915136337280e-01
    z[2,3,4]  R999      2.2578676044940948e-01
    z[2,3,4]  R1000     -6.1166834831237793e-01
    z[2,3,4]  R1001     6.0078907757997513e-02
    z[2,3,4]  R1002     -1.0044468194246292e-01
    z[2,3,4]  R1003     1.9026717543601990e-01
    z[2,3,4]  R1004     -0.0942695364356041
    z[2,3,4]  R1005     -0.530070424079895
    z[2,3,4]  R1006     0.572259247303009
    z[2,3,4]  R1007     0.281680703163147
    z[2,3,4]  R1008     4.8072297126054764e-02
    z[2,3,4]  R1009     1.2790170498192310e-02
    z[2,3,4]  R1010     5.2944332361221313e-01
    z[2,3,4]  R1011     5.0449732691049576e-02
    z[2,3,4]  R1012     1.2470442801713943e-01
    z[2,3,4]  R1013     -5.2881163358688354e-01
    z[2,3,4]  R1014     -6.7869938910007477e-02
    z[2,3,4]  R1015     0.330610454082489
    z[2,3,4]  R1016     -8.7898708879947662e-02
    z[2,3,4]  R1017     1.6543485224246979e-01
    z[2,3,4]  R1018     3.1123638153076172e-01
    z[2,3,4]  R1019     -1.7848348617553711e-01
    z[2,3,4]  R1020     1.1690960079431534e-01
    z[2,3,4]  R1021     1.5920451283454895e-01
    z[2,3,4]  R1022     3.0334630608558655e-01
    z[2,3,4]  R1023     0.0460958406329155
    z[2,3,4]  R1024     2.8051629662513733e-02
    z[2,3,4]  R1025     -2.2514438629150391e-01
    z[2,3,4]  R1026     4.8451088368892670e-02
    z[2,3,4]  R1027     -2.8541529178619385e-01
    z[2,3,4]  R1028     2.3641730844974518e-01
    z[2,3,4]  R1029     -4.1492116451263428e-01
    z[2,3,4]  R1030     3.7780386209487915e-01
    z[2,3,4]  R1031     3.3900007605552673e-02
    z[2,3,4]  R1032     -5.9458520263433456e-02
    z[2,3,4]  R1033     2.0541921257972717e-01
    z[2,3,4]  R1034     9.1188631951808929e-02
    z[2,3,4]  R1035     7.1426816284656525e-02
    z[2,3,4]  R1036     -1.2145414017140865e-02
    z[2,3,4]  R1037     -2.1761940419673920e-01
    z[2,3,4]  R1038     1.8333357572555542e-01
    z[2,3,4]  R1039     1.2594452500343323e-01
    z[2,3,4]  R1040     2.7962759137153625e-01
    z[2,3,4]  R1041     5.1990884542465210e-01
    z[2,3,4]  R1042     1.6360929608345032e-01
    z[2,3,4]  R1043     9.3086190521717072e-02
    z[2,3,5]  R25       -1
    z[2,3,5]  R34       1
    z[2,3,5]  R960      -1
    z[2,3,5]  R961      1
    z[2,3,5]  R964      1.9332119822502136e-01
    z[2,3,5]  R965      5.3401970863342285e-01
    z[2,3,5]  R966      -1.6601161658763885e-01
    z[2,3,5]  R967      -2.6130869984626770e-02
    z[2,3,5]  R968      3.3052659034729004e-01
    z[2,3,5]  R969      1.1951579898595810e-01
    z[2,3,5]  R970      1.1675358563661575e-01
    z[2,3,5]  R971      1.0763483494520187e-01
    z[2,3,5]  R972      -1.8017560243606567e-01
    z[2,3,5]  R973      -1.7369458079338074e-01
    z[2,3,5]  R974      -4.4999197125434875e-01
    z[2,3,5]  R975      -2.0654010772705078e-01
    z[2,3,5]  R976      2.0217722654342651e-01
    z[2,3,5]  R977      2.8861439228057861e-01
    z[2,3,5]  R978      -1.7662626504898071e-01
    z[2,3,5]  R979      -1.4387050271034241e-01
    z[2,3,5]  R980      -0.556344211101532
    z[2,3,5]  R981      1.0969237983226776e-01
    z[2,3,5]  R982      -2.7493458986282349e-01
    z[2,3,5]  R983      -9.7647741436958313e-02
    z[2,3,5]  R984      -3.8001391291618347e-01
    z[2,3,5]  R985      1.6607622802257538e-01
    z[2,3,5]  R986      -1.3904532790184021e-01
    z[2,3,5]  R987      0.0678798034787178
    z[2,3,5]  R988      -2.3103940486907959e-01
    z[2,3,5]  R989      -2.0109573379158974e-02
    z[2,3,5]  R990      -2.1075604856014252e-01
    z[2,3,5]  R991      1.0331179201602936e-01
    z[2,3,5]  R992      -2.6430118083953857e-01
    z[2,3,5]  R993      5.0883638858795166e-01
    z[2,3,5]  R994      -1.4690301613882184e-03
    z[2,3,5]  R995      7.7183679677546024e-03
    z[2,3,5]  R996      0.411602646112442
    z[2,3,5]  R997      3.0027794837951660e-01
    z[2,3,5]  R998      4.4443616271018982e-01
    z[2,3,5]  R999      7.7148318290710449e-01
    z[2,3,5]  R1000     -7.3083013296127319e-02
    z[2,3,5]  R1001     3.0366408824920654e-01
    z[2,3,5]  R1002     1.6252642869949341e-01
    z[2,3,5]  R1003     1.2806795537471771e-01
    z[2,3,5]  R1004     -3.5857267677783966e-02
    z[2,3,5]  R1005     0.175323948264122
    z[2,3,5]  R1006     2.4659889936447144e-01
    z[2,3,5]  R1007     -5.7021111249923706e-01
    z[2,3,5]  R1008     -2.3316358029842377e-01
    z[2,3,5]  R1009     -7.3266260325908661e-02
    z[2,3,5]  R1010     5.0397776067256927e-02
    z[2,3,5]  R1011     4.6938300132751465e-01
    z[2,3,5]  R1012     4.2848322540521622e-02
    z[2,3,5]  R1013     -3.4131422638893127e-01
    z[2,3,5]  R1014     5.9016084671020508e-01
    z[2,3,5]  R1015     -4.1576853394508362e-01
    z[2,3,5]  R1016     -2.4785226583480835e-01
    z[2,3,5]  R1017     7.4764534831047058e-02
    z[2,3,5]  R1018     1.9420921802520752e-01
    z[2,3,5]  R1019     -3.9852684736251831e-01
    z[2,3,5]  R1020     -4.8294299840927124e-01
    z[2,3,5]  R1021     4.3299004435539246e-01
    z[2,3,5]  R1022     -4.8052871227264404e-01
    z[2,3,5]  R1023     -3.6589032411575317e-01
    z[2,3,5]  R1024     1.8955765292048454e-02
    z[2,3,5]  R1025     3.3537667989730835e-01
    z[2,3,5]  R1026     -1.8424670398235321e-01
    z[2,3,5]  R1027     -1.2360414117574692e-01
    z[2,3,5]  R1028     -2.2777855396270752e-01
    z[2,3,5]  R1029     -3.6247935891151428e-01
    z[2,3,5]  R1030     2.7795165777206421e-01
    z[2,3,5]  R1031     -1.0404511541128159e-01
    z[2,3,5]  R1032     -4.3667447566986084e-01
    z[2,3,5]  R1033     8.2699991762638092e-02
    z[2,3,5]  R1034     -2.6953813433647156e-01
    z[2,3,5]  R1035     -2.2505274415016174e-01
    z[2,3,5]  R1036     -3.7162205576896667e-01
    z[2,3,5]  R1037     -2.0590139925479889e-01
    z[2,3,5]  R1038     -3.0605033040046692e-01
    z[2,3,5]  R1039     -0.577193021774292
    z[2,3,5]  R1040     6.0814291238784790e-01
    z[2,3,5]  R1041     -1.1223967373371124e-01
    z[2,3,5]  R1042     1.0405306518077850e-01
    z[2,3,5]  R1043     -6.3074208796024323e-02
    z[2,3,6]  R26       -1
    z[2,3,6]  R35       1
    z[2,3,6]  R962      -1
    z[2,3,6]  R963      1
    z[2,3,6]  R964      5.0117647647857666e-01
    z[2,3,6]  R965      -4.4853731989860535e-01
    z[2,3,6]  R966      -3.0730417370796204e-01
    z[2,3,6]  R967      8.7859280407428741e-02
    z[2,3,6]  R968      -4.8645719885826111e-02
    z[2,3,6]  R969      -6.7843578755855560e-02
    z[2,3,6]  R970      -2.3056827485561371e-01
    z[2,3,6]  R971      1.1112280935049057e-01
    z[2,3,6]  R972      -3.7142220884561539e-02
    z[2,3,6]  R973      0.476544052362442
    z[2,3,6]  R974      -5.4714262485504150e-02
    z[2,3,6]  R975      -4.4603458046913147e-01
    z[2,3,6]  R976      1.7056821286678314e-01
    z[2,3,6]  R977      4.1587987542152405e-01
    z[2,3,6]  R978      1.8179066479206085e-01
    z[2,3,6]  R979      2.2592335939407349e-01
    z[2,3,6]  R980      2.2567810118198395e-01
    z[2,3,6]  R981      1.1582200415432453e-02
    z[2,3,6]  R982      2.9293093830347061e-02
    z[2,3,6]  R983      -5.0506293773651123e-01
    z[2,3,6]  R984      -3.0052134394645691e-01
    z[2,3,6]  R985      3.8794970512390137e-01
    z[2,3,6]  R986      1.2793380022048950e-01
    z[2,3,6]  R987      4.3868002295494080e-01
    z[2,3,6]  R988      3.8199447095394135e-02
    z[2,3,6]  R989      -6.4267016947269440e-02
    z[2,3,6]  R990      -1.1250492185354233e-01
    z[2,3,6]  R991      1.0586041212081909e-01
    z[2,3,6]  R992      -3.6997777223587036e-01
    z[2,3,6]  R993      -9.2456437647342682e-02
    z[2,3,6]  R994      1.9739234447479248e-01
    z[2,3,6]  R995      -3.0811837315559387e-01
    z[2,3,6]  R996      -2.7268251776695251e-01
    z[2,3,6]  R997      -9.2920534312725067e-02
    z[2,3,6]  R998      -2.0176212489604950e-01
    z[2,3,6]  R999      3.5325026512145996e-01
    z[2,3,6]  R1000     -3.3094260096549988e-01
    z[2,3,6]  R1001     1.6189102828502655e-01
    z[2,3,6]  R1002     3.0460205674171448e-01
    z[2,3,6]  R1003     3.9445933699607849e-01
    z[2,3,6]  R1004     -1.1341780424118042e-01
    z[2,3,6]  R1005     -4.6131104230880737e-01
    z[2,3,6]  R1006     1.1167629063129425e-01
    z[2,3,6]  R1007     2.3331305012106895e-02
    z[2,3,6]  R1008     9.6927117556333542e-03
    z[2,3,6]  R1009     7.5245589017868042e-02
    z[2,3,6]  R1010     5.4382622241973877e-01
    z[2,3,6]  R1011     -5.7883268594741821e-01
    z[2,3,6]  R1012     6.7323154211044312e-01
    z[2,3,6]  R1013     -4.6804344654083252e-01
    z[2,3,6]  R1014     6.6752098500728607e-02
    z[2,3,6]  R1015     9.5703966915607452e-02
    z[2,3,6]  R1016     -3.4824347496032715e-01
    z[2,3,6]  R1017     6.4936473965644836e-02
    z[2,3,6]  R1018     -1.2131937593221664e-01
    z[2,3,6]  R1019     1.2059555947780609e-01
    z[2,3,6]  R1020     -1.1474822461605072e-01
    z[2,3,6]  R1021     -4.6841281652450562e-01
    z[2,3,6]  R1022     1.1004430055618286e-01
    z[2,3,6]  R1023     3.4700807183980942e-02
    z[2,3,6]  R1024     -0.372715562582016
    z[2,3,6]  R1025     -1.0838195681571960e-01
    z[2,3,6]  R1026     -9.5185093581676483e-02
    z[2,3,6]  R1027     2.1241450309753418e-01
    z[2,3,6]  R1028     3.3925303816795349e-01
    z[2,3,6]  R1029     -8.8744185864925385e-02
    z[2,3,6]  R1030     5.7432585954666138e-01
    z[2,3,6]  R1031     4.3185046315193176e-01
    z[2,3,6]  R1032     -4.1304412484169006e-01
    z[2,3,6]  R1033     -6.9377802312374115e-02
    z[2,3,6]  R1034     -1.8144853413105011e-01
    z[2,3,6]  R1035     -2.8613728284835815e-01
    z[2,3,6]  R1036     0.54569011926651
    z[2,3,6]  R1037     2.0884558558464050e-01
    z[2,3,6]  R1038     6.5937139093875885e-02
    z[2,3,6]  R1039     -3.9090004563331604e-01
    z[2,3,6]  R1040     -2.1658392250537872e-01
    z[2,3,6]  R1041     2.0007678866386414e-01
    z[2,3,6]  R1042     5.7898283004760742e-01
    z[2,3,6]  R1043     -5.9164726734161377e-01
    z[3,2,0]  R20       1
    z[3,2,0]  R29       -1
    z[3,2,0]  R1044     -1
    z[3,2,0]  R1045     1
    z[3,2,0]  R1058     -5.4624056816101074e-01
    z[3,2,0]  R1059     -0.424212247133255
    z[3,2,0]  R1060     7.1994647383689880e-02
    z[3,2,0]  R1061     -6.1272311210632324e-01
    z[3,2,0]  R1062     -6.4805978536605835e-01
    z[3,2,0]  R1063     -3.4386971592903137e-01
    z[3,2,0]  R1064     -8.9542247354984283e-02
    z[3,2,0]  R1065     1.1211939901113510e-01
    z[3,2,0]  R1066     -2.8060302138328552e-01
    z[3,2,0]  R1067     3.1735548377037048e-01
    z[3,2,0]  R1068     -6.1525338888168335e-01
    z[3,2,0]  R1069     -8.6321853101253510e-02
    z[3,2,0]  R1070     1.6740697622299194e-01
    z[3,2,0]  R1071     3.4569454193115234e-01
    z[3,2,0]  R1072     5.2569651603698730e-01
    z[3,2,0]  R1073     3.9396968483924866e-01
    z[3,2,0]  R1074     2.5449299812316895e-01
    z[3,2,0]  R1075     -6.4478024840354919e-02
    z[3,2,0]  R1076     -3.1391513347625732e-01
    z[3,2,0]  R1077     0.0785473957657814
    z[3,2,0]  R1078     -0.202298104763031
    z[3,2,0]  R1079     -3.6601746082305908e-01
    z[3,2,0]  R1080     1.3802783191204071e-01
    z[3,2,0]  R1081     -0.574720025062561
    z[3,2,0]  R1082     -1.1223085224628448e-01
    z[3,2,0]  R1083     -2.9490327835083008e-01
    z[3,2,0]  R1084     3.1449355185031891e-02
    z[3,2,0]  R1085     -2.7709737420082092e-02
    z[3,2,0]  R1086     -7.8968949615955353e-02
    z[3,2,0]  R1087     1.7646408081054688e-01
    z[3,2,0]  R1088     -1.8827441334724426e-01
    z[3,2,0]  R1089     -2.2635528445243835e-01
    z[3,2,0]  R1090     2.1855413913726807e-01
    z[3,2,0]  R1091     -4.7770336270332336e-02
    z[3,2,0]  R1092     1.0365481674671173e-01
    z[3,2,0]  R1093     -1.7878907918930054e-01
    z[3,2,0]  R1094     -4.6802438795566559e-02
    z[3,2,0]  R1095     -5.0883240997791290e-02
    z[3,2,0]  R1096     1.4553122222423553e-01
    z[3,2,0]  R1097     2.3893390595912933e-01
    z[3,2,0]  R1098     -8.7573036551475525e-02
    z[3,2,0]  R1099     3.5484347492456436e-02
    z[3,2,0]  R1100     -1.9336035475134850e-02
    z[3,2,0]  R1101     5.8665376156568527e-02
    z[3,2,0]  R1102     -3.2212796807289124e-01
    z[3,2,0]  R1103     2.3365199565887451e-01
    z[3,2,0]  R1104     -1.0389288514852524e-01
    z[3,2,0]  R1105     -4.9414080381393433e-01
    z[3,2,0]  R1106     -4.2689168453216553e-01
    z[3,2,0]  R1107     2.8846862912178040e-01
    z[3,2,0]  R1108     -1.6967041790485382e-01
    z[3,2,0]  R1109     -1.3388785719871521e-01
    z[3,2,0]  R1110     3.0542594194412231e-01
    z[3,2,0]  R1111     -0.77823805809021
    z[3,2,0]  R1112     -7.9751676321029663e-01
    z[3,2,0]  R1113     -8.5658162832260132e-01
    z[3,2,0]  R1114     -8.0390030145645142e-01
    z[3,2,0]  R1115     -7.7379405498504639e-01
    z[3,2,0]  R1116     -8.9063447713851929e-01
    z[3,2,0]  R1117     -1.7608661949634552e-01
    z[3,2,0]  R1118     1.0001166909933090e-01
    z[3,2,0]  R1119     4.4433104991912842e-01
    z[3,2,0]  R1120     3.6617133021354675e-01
    z[3,2,0]  R1121     1.9942130148410797e-01
    z[3,2,0]  R1122     -1.2687428295612335e-01
    z[3,2,0]  R1123     -3.5667607188224792e-01
    z[3,2,0]  R1124     -5.2196753025054932e-01
    z[3,2,0]  R1125     -2.4494828283786774e-01
    z[3,2,0]  R1126     -7.5037801265716553e-01
    z[3,2,0]  R1127     1.8949049711227417e-01
    z[3,2,0]  R1128     -6.1510574817657471e-01
    z[3,2,0]  R1129     -3.4907853603363037e-01
    z[3,2,0]  R1130     -1.6321410238742828e-01
    z[3,2,0]  R1131     -3.3627992868423462e-01
    z[3,2,0]  R1132     1.2292774766683578e-01
    z[3,2,0]  R1133     1.1723812669515610e-01
    z[3,2,0]  R1134     2.9016089439392090e-01
    z[3,2,0]  R1135     2.1073332428932190e-01
    z[3,2,0]  R1136     1.3649851083755493e-01
    z[3,2,0]  R1137     3.8373467326164246e-01
    z[3,2,1]  R21       1
    z[3,2,1]  R30       -1
    z[3,2,1]  R1046     -1
    z[3,2,1]  R1047     1
    z[3,2,1]  R1058     7.9328608512878418e-01
    z[3,2,1]  R1059     7.6735401153564453e-01
    z[3,2,1]  R1060     6.3840603828430176e-01
    z[3,2,1]  R1061     1.1874987185001373e-01
    z[3,2,1]  R1062     1.6845221817493439e-01
    z[3,2,1]  R1063     1.1892323940992355e-01
    z[3,2,1]  R1064     -4.9029093235731125e-02
    z[3,2,1]  R1065     -2.0932072773575783e-02
    z[3,2,1]  R1066     -5.1081206649541855e-02
    z[3,2,1]  R1067     -4.6568468213081360e-02
    z[3,2,1]  R1068     -6.5252298116683960e-01
    z[3,2,1]  R1069     -6.6241371631622314e-01
    z[3,2,1]  R1070     -6.3512933254241943e-01
    z[3,2,1]  R1071     -5.6671643257141113e-01
    z[3,2,1]  R1072     -5.8184927701950073e-01
    z[3,2,1]  R1073     -8.0940610170364380e-01
    z[3,2,1]  R1074     -5.6583595275878906e-01
    z[3,2,1]  R1075     -5.6445431709289551e-01
    z[3,2,1]  R1076     -6.2445646524429321e-01
    z[3,2,1]  R1077     -5.3245031833648682e-01
    z[3,2,1]  R1078     -7.7334809303283691e-01
    z[3,2,1]  R1079     -6.9144630432128906e-01
    z[3,2,1]  R1080     -0.743336021900177
    z[3,2,1]  R1081     -6.4037960767745972e-01
    z[3,2,1]  R1082     4.4405010342597961e-01
    z[3,2,1]  R1083     -6.9568479061126709e-01
    z[3,2,1]  R1084     0.522428035736084
    z[3,2,1]  R1085     -5.3287369012832642e-01
    z[3,2,1]  R1086     4.8844003677368164e-01
    z[3,2,1]  R1087     6.3939177989959717e-01
    z[3,2,1]  R1088     -8.4677040576934814e-01
    z[3,2,1]  R1089     -8.7058031558990479e-01
    z[3,2,1]  R1090     -8.9668089151382446e-01
    z[3,2,1]  R1091     -7.2005736827850342e-01
    z[3,2,1]  R1092     -6.7852222919464111e-01
    z[3,2,1]  R1093     0.713131844997406
    z[3,2,1]  R1094     -6.1013668775558472e-01
    z[3,2,1]  R1095     -6.1674284934997559e-01
    z[3,2,1]  R1096     6.5785801410675049e-01
    z[3,2,1]  R1097     8.5632407665252686e-01
    z[3,2,1]  R1098     6.4206200838088989e-01
    z[3,2,1]  R1099     8.7107646465301514e-01
    z[3,2,1]  R1100     -7.5011372566223145e-01
    z[3,2,1]  R1101     -8.7947982549667358e-01
    z[3,2,1]  R1102     4.7453027963638306e-01
    z[3,2,1]  R1103     -6.2827903032302856e-01
    z[3,2,1]  R1104     6.8753391504287720e-01
    z[3,2,1]  R1105     3.6887449026107788e-01
    z[3,2,1]  R1106     3.3512553572654724e-01
    z[3,2,1]  R1107     -0.559316098690033
    z[3,2,1]  R1108     7.5533652305603027e-01
    z[3,2,1]  R1109     1.5082035958766937e-01
    z[3,2,1]  R1110     3.2670933008193970e-01
    z[3,2,1]  R1111     -8.6420841515064240e-02
    z[3,2,1]  R1112     -9.3506224453449249e-02
    z[3,2,1]  R1113     -8.2904092967510223e-02
    z[3,2,1]  R1114     7.6480291783809662e-02
    z[3,2,1]  R1115     -4.5369766652584076e-02
    z[3,2,1]  R1116     -4.7882851213216782e-02
    z[3,2,1]  R1117     -1.4118745923042297e-01
    z[3,2,1]  R1118     1.1222476139664650e-02
    z[3,2,1]  R1119     4.5571732521057129e-01
    z[3,2,1]  R1120     -4.6389934420585632e-01
    z[3,2,1]  R1121     -4.7327658534049988e-01
    z[3,2,1]  R1122     -4.2640617489814758e-01
    z[3,2,1]  R1123     -4.0584355592727661e-01
    z[3,2,1]  R1124     -0.498304545879364
    z[3,2,1]  R1125     -0.765228807926178
    z[3,2,1]  R1126     -4.2069500684738159e-01
    z[3,2,1]  R1127     -3.6247938871383667e-01
    z[3,2,1]  R1128     -5.1551681756973267e-01
    z[3,2,1]  R1129     -7.5431865453720093e-01
    z[3,2,1]  R1130     -4.4682428240776062e-01
    z[3,2,1]  R1131     -7.0357149839401245e-01
    z[3,2,1]  R1132     -6.1069816350936890e-01
    z[3,2,1]  R1133     -6.9779038429260254e-01
    z[3,2,1]  R1134     -0.66790372133255
    z[3,2,1]  R1135     -7.9137659072875977e-01
    z[3,2,1]  R1136     -6.8418294191360474e-01
    z[3,2,1]  R1137     -7.2239428758621216e-01
    z[3,2,2]  R22       1
    z[3,2,2]  R31       -1
    z[3,2,2]  R1048     -1
    z[3,2,2]  R1049     1
    z[3,2,2]  R1058     2.4101685732603073e-02
    z[3,2,2]  R1059     -1.2400750815868378e-01
    z[3,2,2]  R1060     5.2930307388305664e-01
    z[3,2,2]  R1061     5.2981162071228027e-01
    z[3,2,2]  R1062     5.2514404058456421e-01
    z[3,2,2]  R1063     3.1009066104888916e-01
    z[3,2,2]  R1064     -4.4367730617523193e-01
    z[3,2,2]  R1065     -8.0586922168731689e-01
    z[3,2,2]  R1066     -7.8454381227493286e-01
    z[3,2,2]  R1067     8.0022051930427551e-02
    z[3,2,2]  R1068     0.0970572754740715
    z[3,2,2]  R1069     0.152975931763649
    z[3,2,2]  R1070     3.4097391366958618e-01
    z[3,2,2]  R1071     -3.8507252931594849e-01
    z[3,2,2]  R1072     -6.8089894950389862e-02
    z[3,2,2]  R1073     -2.3545506596565247e-01
    z[3,2,2]  R1074     -5.0401028245687485e-02
    z[3,2,2]  R1075     8.3726853132247925e-02
    z[3,2,2]  R1076     1.0667237639427185e-01
    z[3,2,2]  R1077     -2.7492982149124146e-01
    z[3,2,2]  R1078     -4.1653178632259369e-02
    z[3,2,2]  R1079     2.7315405011177063e-01
    z[3,2,2]  R1080     1.5096355974674225e-01
    z[3,2,2]  R1081     4.1382029652595520e-01
    z[3,2,2]  R1082     5.0347495079040527e-01
    z[3,2,2]  R1083     -9.3935750424861908e-02
    z[3,2,2]  R1084     4.3033921718597412e-01
    z[3,2,2]  R1085     -4.3597763776779175e-01
    z[3,2,2]  R1086     1.1288274079561234e-01
    z[3,2,2]  R1087     6.4795380830764771e-01
    z[3,2,2]  R1088     -2.4157375097274780e-01
    z[3,2,2]  R1089     -3.2371073961257935e-02
    z[3,2,2]  R1090     0.0947737991809845
    z[3,2,2]  R1091     -2.7153888344764709e-01
    z[3,2,2]  R1092     -5.3877639770507812e-01
    z[3,2,2]  R1093     3.5098394751548767e-01
    z[3,2,2]  R1094     -2.7506032586097717e-01
    z[3,2,2]  R1095     3.3013519644737244e-01
    z[3,2,2]  R1096     3.1272286176681519e-01
    z[3,2,2]  R1097     3.6370927095413208e-01
    z[3,2,2]  R1098     4.2421030998229980e-01
    z[3,2,2]  R1099     1.8731613457202911e-01
    z[3,2,2]  R1100     2.3560628294944763e-02
    z[3,2,2]  R1101     2.8810295462608337e-01
    z[3,2,2]  R1102     1.2663708627223969e-01
    z[3,2,2]  R1103     -3.2625325024127960e-02
    z[3,2,2]  R1104     2.0188353955745697e-02
    z[3,2,2]  R1105     4.5583987236022949e-01
    z[3,2,2]  R1106     5.1397567987442017e-01
    z[3,2,2]  R1107     0.0961170494556427
    z[3,2,2]  R1108     -3.1709957867860794e-02
    z[3,2,2]  R1109     -1.1720193177461624e-01
    z[3,2,2]  R1110     8.2046687602996826e-01
    z[3,2,2]  R1111     4.8310512304306030e-01
    z[3,2,2]  R1112     3.8264030218124390e-01
    z[3,2,2]  R1113     3.7091696262359619e-01
    z[3,2,2]  R1114     2.1323429048061371e-01
    z[3,2,2]  R1115     -3.1985055655241013e-02
    z[3,2,2]  R1116     -3.7263888120651245e-01
    z[3,2,2]  R1117     -5.7381969690322876e-01
    z[3,2,2]  R1118     -9.8400421440601349e-02
    z[3,2,2]  R1119     -5.2164769172668457e-01
    z[3,2,2]  R1120     -6.6140770912170410e-01
    z[3,2,2]  R1121     -9.3525443226099014e-03
    z[3,2,2]  R1122     -6.2786054611206055e-01
    z[3,2,2]  R1123     -7.6410883665084839e-01
    z[3,2,2]  R1124     -1.3354372978210449e-01
    z[3,2,2]  R1125     -5.2212452888488770e-01
    z[3,2,2]  R1126     2.8210720419883728e-01
    z[3,2,2]  R1127     -5.5925279855728149e-01
    z[3,2,2]  R1128     -0.313320517539978
    z[3,2,2]  R1129     2.8686714172363281e-01
    z[3,2,2]  R1130     4.6897572278976440e-01
    z[3,2,2]  R1131     -4.2075714468955994e-01
    z[3,2,2]  R1132     -4.1321775317192078e-01
    z[3,2,2]  R1133     -1.0324368625879288e-01
    z[3,2,2]  R1134     -5.2678704261779785e-02
    z[3,2,2]  R1135     -2.9144442081451416e-01
    z[3,2,2]  R1136     -2.6429215073585510e-01
    z[3,2,2]  R1137     1.5398591756820679e-01
    z[3,2,3]  R23       1
    z[3,2,3]  R32       -1
    z[3,2,3]  R1050     -1
    z[3,2,3]  R1051     1
    z[3,2,3]  R1058     1.5139020979404449e-01
    z[3,2,3]  R1059     2.9603728652000427e-01
    z[3,2,3]  R1060     1.5822613239288330e-01
    z[3,2,3]  R1061     2.4612200260162354e-01
    z[3,2,3]  R1062     1.1945197731256485e-01
    z[3,2,3]  R1063     0.0224288459867239
    z[3,2,3]  R1064     -5.5111384391784668e-01
    z[3,2,3]  R1065     4.6425831317901611e-01
    z[3,2,3]  R1066     -4.1696190834045410e-01
    z[3,2,3]  R1067     -8.2614302635192871e-01
    z[3,2,3]  R1068     -4.0400597453117371e-01
    z[3,2,3]  R1069     -0.0763794332742691
    z[3,2,3]  R1070     -2.2706650197505951e-01
    z[3,2,3]  R1071     -7.7574424445629120e-02
    z[3,2,3]  R1072     -5.6893610954284668e-01
    z[3,2,3]  R1073     -3.5073789954185486e-01
    z[3,2,3]  R1074     -1.8418912589550018e-01
    z[3,2,3]  R1075     3.3512806892395020e-01
    z[3,2,3]  R1076     1.7176859080791473e-01
    z[3,2,3]  R1077     -1.3978110253810883e-01
    z[3,2,3]  R1078     -4.3832760304212570e-02
    z[3,2,3]  R1079     0.148304283618927
    z[3,2,3]  R1080     4.6387454867362976e-01
    z[3,2,3]  R1081     2.2624848783016205e-01
    z[3,2,3]  R1082     6.2244117259979248e-01
    z[3,2,3]  R1083     4.6368911862373352e-01
    z[3,2,3]  R1084     5.2992373704910278e-01
    z[3,2,3]  R1085     -3.0490031838417053e-01
    z[3,2,3]  R1086     6.3828772306442261e-01
    z[3,2,3]  R1087     5.4679099470376968e-02
    z[3,2,3]  R1088     2.2161155939102173e-01
    z[3,2,3]  R1089     1.2202896922826767e-01
    z[3,2,3]  R1090     3.0636712908744812e-01
    z[3,2,3]  R1091     -5.1346111297607422e-01
    z[3,2,3]  R1092     -0.125356987118721
    z[3,2,3]  R1093     -1.5767522156238556e-01
    z[3,2,3]  R1094     -0.00643932493403554
    z[3,2,3]  R1095     -5.5639952421188354e-01
    z[3,2,3]  R1096     2.8882962465286255e-01
    z[3,2,3]  R1097     -1.5325054526329041e-01
    z[3,2,3]  R1098     5.3501695394515991e-01
    z[3,2,3]  R1099     2.5933426618576050e-01
    z[3,2,3]  R1100     -1.9293682649731636e-02
    z[3,2,3]  R1101     -8.1855103373527527e-02
    z[3,2,3]  R1102     7.2345834970474243e-01
    z[3,2,3]  R1103     -2.1861200034618378e-01
    z[3,2,3]  R1104     1.4545749127864838e-01
    z[3,2,3]  R1105     2.9838341474533081e-01
    z[3,2,3]  R1106     2.6166230440139771e-01
    z[3,2,3]  R1107     -4.8168757557868958e-01
    z[3,2,3]  R1108     2.4858303368091583e-01
    z[3,2,3]  R1109     4.2554402351379395e-01
    z[3,2,3]  R1110     0.0343628004193306
    z[3,2,3]  R1111     -3.8013058900833130e-01
    z[3,2,3]  R1112     -2.9829597473144531e-01
    z[3,2,3]  R1113     -3.3759616315364838e-02
    z[3,2,3]  R1114     -4.6697562932968140e-01
    z[3,2,3]  R1115     -3.4522190690040588e-01
    z[3,2,3]  R1116     -1.0063122212886810e-01
    z[3,2,3]  R1117     -0.532974362373352
    z[3,2,3]  R1118     0.795096755027771
    z[3,2,3]  R1119     -6.5679289400577545e-02
    z[3,2,3]  R1120     2.1196436882019043e-01
    z[3,2,3]  R1121     -5.1714515686035156e-01
    z[3,2,3]  R1122     -3.2441899180412292e-01
    z[3,2,3]  R1123     2.2344872355461121e-01
    z[3,2,3]  R1124     -2.0596009492874146e-01
    z[3,2,3]  R1125     -2.5589501857757568e-01
    z[3,2,3]  R1126     -2.2315208613872528e-01
    z[3,2,3]  R1127     -4.5817753672599792e-01
    z[3,2,3]  R1128     -1.4972835779190063e-01
    z[3,2,3]  R1129     2.0119418203830719e-01
    z[3,2,3]  R1130     -7.1833759546279907e-01
    z[3,2,3]  R1131     7.2061540558934212e-03
    z[3,2,3]  R1132     -4.4673284888267517e-01
    z[3,2,3]  R1133     -6.6427075862884521e-01
    z[3,2,3]  R1134     -4.9844187498092651e-01
    z[3,2,3]  R1135     -3.5893306136131287e-01
    z[3,2,3]  R1136     -3.5574150085449219e-01
    z[3,2,3]  R1137     -1.9878847897052765e-01
    z[3,2,4]  R24       1
    z[3,2,4]  R33       -1
    z[3,2,4]  R1052     -1
    z[3,2,4]  R1053     1
    z[3,2,4]  R1058     -9.9260888993740082e-02
    z[3,2,4]  R1059     -1.8220679461956024e-01
    z[3,2,4]  R1060     1.9566479325294495e-01
    z[3,2,4]  R1061     -4.1278502345085144e-01
    z[3,2,4]  R1062     1.5285915136337280e-01
    z[3,2,4]  R1063     2.2578676044940948e-01
    z[3,2,4]  R1064     -6.1166834831237793e-01
    z[3,2,4]  R1065     6.0078907757997513e-02
    z[3,2,4]  R1066     -1.0044468194246292e-01
    z[3,2,4]  R1067     1.9026717543601990e-01
    z[3,2,4]  R1068     -0.0942695364356041
    z[3,2,4]  R1069     -0.530070424079895
    z[3,2,4]  R1070     0.572259247303009
    z[3,2,4]  R1071     0.281680703163147
    z[3,2,4]  R1072     4.8072297126054764e-02
    z[3,2,4]  R1073     1.2790170498192310e-02
    z[3,2,4]  R1074     5.2944332361221313e-01
    z[3,2,4]  R1075     5.0449732691049576e-02
    z[3,2,4]  R1076     1.2470442801713943e-01
    z[3,2,4]  R1077     -5.2881163358688354e-01
    z[3,2,4]  R1078     -6.7869938910007477e-02
    z[3,2,4]  R1079     0.330610454082489
    z[3,2,4]  R1080     -8.7898708879947662e-02
    z[3,2,4]  R1081     1.6543485224246979e-01
    z[3,2,4]  R1082     3.1123638153076172e-01
    z[3,2,4]  R1083     -1.7848348617553711e-01
    z[3,2,4]  R1084     1.1690960079431534e-01
    z[3,2,4]  R1085     1.5920451283454895e-01
    z[3,2,4]  R1086     3.0334630608558655e-01
    z[3,2,4]  R1087     0.0460958406329155
    z[3,2,4]  R1088     2.8051629662513733e-02
    z[3,2,4]  R1089     -2.2514438629150391e-01
    z[3,2,4]  R1090     4.8451088368892670e-02
    z[3,2,4]  R1091     -2.8541529178619385e-01
    z[3,2,4]  R1092     2.3641730844974518e-01
    z[3,2,4]  R1093     -4.1492116451263428e-01
    z[3,2,4]  R1094     3.7780386209487915e-01
    z[3,2,4]  R1095     3.3900007605552673e-02
    z[3,2,4]  R1096     -5.9458520263433456e-02
    z[3,2,4]  R1097     2.0541921257972717e-01
    z[3,2,4]  R1098     9.1188631951808929e-02
    z[3,2,4]  R1099     7.1426816284656525e-02
    z[3,2,4]  R1100     -1.2145414017140865e-02
    z[3,2,4]  R1101     -2.1761940419673920e-01
    z[3,2,4]  R1102     1.8333357572555542e-01
    z[3,2,4]  R1103     1.2594452500343323e-01
    z[3,2,4]  R1104     2.7962759137153625e-01
    z[3,2,4]  R1105     5.1990884542465210e-01
    z[3,2,4]  R1106     1.6360929608345032e-01
    z[3,2,4]  R1107     9.3086190521717072e-02
    z[3,2,4]  R1108     2.2210077941417694e-01
    z[3,2,4]  R1109     0.52739018201828
    z[3,2,4]  R1110     6.0279220342636108e-02
    z[3,2,4]  R1111     2.4187561124563217e-02
    z[3,2,4]  R1112     -0.0906379222869873
    z[3,2,4]  R1113     -3.1904366612434387e-01
    z[3,2,4]  R1114     -1.3254015147686005e-01
    z[3,2,4]  R1115     -5.0502443313598633e-01
    z[3,2,4]  R1116     -1.4713397622108459e-01
    z[3,2,4]  R1117     -2.8011593222618103e-01
    z[3,2,4]  R1118     -3.7752330303192139e-01
    z[3,2,4]  R1119     -2.7722901105880737e-01
    z[3,2,4]  R1120     -3.1362017989158630e-01
    z[3,2,4]  R1121     4.6093329787254333e-01
    z[3,2,4]  R1122     4.8824116587638855e-01
    z[3,2,4]  R1123     5.0413936376571655e-02
    z[3,2,4]  R1124     -2.4194929003715515e-01
    z[3,2,4]  R1125     -6.4516708254814148e-02
    z[3,2,4]  R1126     2.3263719677925110e-01
    z[3,2,4]  R1127     -2.1304479241371155e-01
    z[3,2,4]  R1128     2.3986525833606720e-02
    z[3,2,4]  R1129     9.1045916080474854e-02
    z[3,2,4]  R1130     4.5402288436889648e-02
    z[3,2,4]  R1131     -1.3329149782657623e-01
    z[3,2,4]  R1132     -4.3217939138412476e-01
    z[3,2,4]  R1133     -2.0710915327072144e-01
    z[3,2,4]  R1134     -4.0176659822463989e-01
    z[3,2,4]  R1135     -3.0604231357574463e-01
    z[3,2,4]  R1136     -3.3184453845024109e-01
    z[3,2,4]  R1137     1.4250871725380421e-02
    z[3,2,5]  R25       1
    z[3,2,5]  R34       -1
    z[3,2,5]  R1054     -1
    z[3,2,5]  R1055     1
    z[3,2,5]  R1058     -1.4690301613882184e-03
    z[3,2,5]  R1059     7.7183679677546024e-03
    z[3,2,5]  R1060     0.411602646112442
    z[3,2,5]  R1061     3.0027794837951660e-01
    z[3,2,5]  R1062     4.4443616271018982e-01
    z[3,2,5]  R1063     7.7148318290710449e-01
    z[3,2,5]  R1064     -7.3083013296127319e-02
    z[3,2,5]  R1065     3.0366408824920654e-01
    z[3,2,5]  R1066     1.6252642869949341e-01
    z[3,2,5]  R1067     1.2806795537471771e-01
    z[3,2,5]  R1068     -3.5857267677783966e-02
    z[3,2,5]  R1069     0.175323948264122
    z[3,2,5]  R1070     2.4659889936447144e-01
    z[3,2,5]  R1071     -5.7021111249923706e-01
    z[3,2,5]  R1072     -2.3316358029842377e-01
    z[3,2,5]  R1073     -7.3266260325908661e-02
    z[3,2,5]  R1074     5.0397776067256927e-02
    z[3,2,5]  R1075     4.6938300132751465e-01
    z[3,2,5]  R1076     4.2848322540521622e-02
    z[3,2,5]  R1077     -3.4131422638893127e-01
    z[3,2,5]  R1078     5.9016084671020508e-01
    z[3,2,5]  R1079     -4.1576853394508362e-01
    z[3,2,5]  R1080     -2.4785226583480835e-01
    z[3,2,5]  R1081     7.4764534831047058e-02
    z[3,2,5]  R1082     1.9420921802520752e-01
    z[3,2,5]  R1083     -3.9852684736251831e-01
    z[3,2,5]  R1084     -4.8294299840927124e-01
    z[3,2,5]  R1085     4.3299004435539246e-01
    z[3,2,5]  R1086     -4.8052871227264404e-01
    z[3,2,5]  R1087     -3.6589032411575317e-01
    z[3,2,5]  R1088     1.8955765292048454e-02
    z[3,2,5]  R1089     3.3537667989730835e-01
    z[3,2,5]  R1090     -1.8424670398235321e-01
    z[3,2,5]  R1091     -1.2360414117574692e-01
    z[3,2,5]  R1092     -2.2777855396270752e-01
    z[3,2,5]  R1093     -3.6247935891151428e-01
    z[3,2,5]  R1094     2.7795165777206421e-01
    z[3,2,5]  R1095     -1.0404511541128159e-01
    z[3,2,5]  R1096     -4.3667447566986084e-01
    z[3,2,5]  R1097     8.2699991762638092e-02
    z[3,2,5]  R1098     -2.6953813433647156e-01
    z[3,2,5]  R1099     -2.2505274415016174e-01
    z[3,2,5]  R1100     -3.7162205576896667e-01
    z[3,2,5]  R1101     -2.0590139925479889e-01
    z[3,2,5]  R1102     -3.0605033040046692e-01
    z[3,2,5]  R1103     -0.577193021774292
    z[3,2,5]  R1104     6.0814291238784790e-01
    z[3,2,5]  R1105     -1.1223967373371124e-01
    z[3,2,5]  R1106     1.0405306518077850e-01
    z[3,2,5]  R1107     -6.3074208796024323e-02
    z[3,2,5]  R1108     1.9332119822502136e-01
    z[3,2,5]  R1109     5.3401970863342285e-01
    z[3,2,5]  R1110     -1.6601161658763885e-01
    z[3,2,5]  R1111     -2.6130869984626770e-02
    z[3,2,5]  R1112     3.3052659034729004e-01
    z[3,2,5]  R1113     1.1951579898595810e-01
    z[3,2,5]  R1114     1.1675358563661575e-01
    z[3,2,5]  R1115     1.0763483494520187e-01
    z[3,2,5]  R1116     -1.8017560243606567e-01
    z[3,2,5]  R1117     -1.7369458079338074e-01
    z[3,2,5]  R1118     -4.4999197125434875e-01
    z[3,2,5]  R1119     -2.0654010772705078e-01
    z[3,2,5]  R1120     2.0217722654342651e-01
    z[3,2,5]  R1121     2.8861439228057861e-01
    z[3,2,5]  R1122     -1.7662626504898071e-01
    z[3,2,5]  R1123     -1.4387050271034241e-01
    z[3,2,5]  R1124     -0.556344211101532
    z[3,2,5]  R1125     1.0969237983226776e-01
    z[3,2,5]  R1126     -2.7493458986282349e-01
    z[3,2,5]  R1127     -9.7647741436958313e-02
    z[3,2,5]  R1128     -3.8001391291618347e-01
    z[3,2,5]  R1129     1.6607622802257538e-01
    z[3,2,5]  R1130     -1.3904532790184021e-01
    z[3,2,5]  R1131     0.0678798034787178
    z[3,2,5]  R1132     -2.3103940486907959e-01
    z[3,2,5]  R1133     -2.0109573379158974e-02
    z[3,2,5]  R1134     -2.1075604856014252e-01
    z[3,2,5]  R1135     1.0331179201602936e-01
    z[3,2,5]  R1136     -2.6430118083953857e-01
    z[3,2,5]  R1137     5.0883638858795166e-01
    z[3,2,6]  R26       1
    z[3,2,6]  R35       -1
    z[3,2,6]  R1056     -1
    z[3,2,6]  R1057     1
    z[3,2,6]  R1058     1.9739234447479248e-01
    z[3,2,6]  R1059     -3.0811837315559387e-01
    z[3,2,6]  R1060     -2.7268251776695251e-01
    z[3,2,6]  R1061     -9.2920534312725067e-02
    z[3,2,6]  R1062     -2.0176212489604950e-01
    z[3,2,6]  R1063     3.5325026512145996e-01
    z[3,2,6]  R1064     -3.3094260096549988e-01
    z[3,2,6]  R1065     1.6189102828502655e-01
    z[3,2,6]  R1066     3.0460205674171448e-01
    z[3,2,6]  R1067     3.9445933699607849e-01
    z[3,2,6]  R1068     -1.1341780424118042e-01
    z[3,2,6]  R1069     -4.6131104230880737e-01
    z[3,2,6]  R1070     1.1167629063129425e-01
    z[3,2,6]  R1071     2.3331305012106895e-02
    z[3,2,6]  R1072     9.6927117556333542e-03
    z[3,2,6]  R1073     7.5245589017868042e-02
    z[3,2,6]  R1074     5.4382622241973877e-01
    z[3,2,6]  R1075     -5.7883268594741821e-01
    z[3,2,6]  R1076     6.7323154211044312e-01
    z[3,2,6]  R1077     -4.6804344654083252e-01
    z[3,2,6]  R1078     6.6752098500728607e-02
    z[3,2,6]  R1079     9.5703966915607452e-02
    z[3,2,6]  R1080     -3.4824347496032715e-01
    z[3,2,6]  R1081     6.4936473965644836e-02
    z[3,2,6]  R1082     -1.2131937593221664e-01
    z[3,2,6]  R1083     1.2059555947780609e-01
    z[3,2,6]  R1084     -1.1474822461605072e-01
    z[3,2,6]  R1085     -4.6841281652450562e-01
    z[3,2,6]  R1086     1.1004430055618286e-01
    z[3,2,6]  R1087     3.4700807183980942e-02
    z[3,2,6]  R1088     -0.372715562582016
    z[3,2,6]  R1089     -1.0838195681571960e-01
    z[3,2,6]  R1090     -9.5185093581676483e-02
    z[3,2,6]  R1091     2.1241450309753418e-01
    z[3,2,6]  R1092     3.3925303816795349e-01
    z[3,2,6]  R1093     -8.8744185864925385e-02
    z[3,2,6]  R1094     5.7432585954666138e-01
    z[3,2,6]  R1095     4.3185046315193176e-01
    z[3,2,6]  R1096     -4.1304412484169006e-01
    z[3,2,6]  R1097     -6.9377802312374115e-02
    z[3,2,6]  R1098     -1.8144853413105011e-01
    z[3,2,6]  R1099     -2.8613728284835815e-01
    z[3,2,6]  R1100     0.54569011926651
    z[3,2,6]  R1101     2.0884558558464050e-01
    z[3,2,6]  R1102     6.5937139093875885e-02
    z[3,2,6]  R1103     -3.9090004563331604e-01
    z[3,2,6]  R1104     -2.1658392250537872e-01
    z[3,2,6]  R1105     2.0007678866386414e-01
    z[3,2,6]  R1106     5.7898283004760742e-01
    z[3,2,6]  R1107     -5.9164726734161377e-01
    z[3,2,6]  R1108     5.0117647647857666e-01
    z[3,2,6]  R1109     -4.4853731989860535e-01
    z[3,2,6]  R1110     -3.0730417370796204e-01
    z[3,2,6]  R1111     8.7859280407428741e-02
    z[3,2,6]  R1112     -4.8645719885826111e-02
    z[3,2,6]  R1113     -6.7843578755855560e-02
    z[3,2,6]  R1114     -2.3056827485561371e-01
    z[3,2,6]  R1115     1.1112280935049057e-01
    z[3,2,6]  R1116     -3.7142220884561539e-02
    z[3,2,6]  R1117     0.476544052362442
    z[3,2,6]  R1118     -5.4714262485504150e-02
    z[3,2,6]  R1119     -4.4603458046913147e-01
    z[3,2,6]  R1120     1.7056821286678314e-01
    z[3,2,6]  R1121     4.1587987542152405e-01
    z[3,2,6]  R1122     1.8179066479206085e-01
    z[3,2,6]  R1123     2.2592335939407349e-01
    z[3,2,6]  R1124     2.2567810118198395e-01
    z[3,2,6]  R1125     1.1582200415432453e-02
    z[3,2,6]  R1126     2.9293093830347061e-02
    z[3,2,6]  R1127     -5.0506293773651123e-01
    z[3,2,6]  R1128     -3.0052134394645691e-01
    z[3,2,6]  R1129     3.8794970512390137e-01
    z[3,2,6]  R1130     1.2793380022048950e-01
    z[3,2,6]  R1131     4.3868002295494080e-01
    z[3,2,6]  R1132     3.8199447095394135e-02
    z[3,2,6]  R1133     -6.4267016947269440e-02
    z[3,2,6]  R1134     -1.1250492185354233e-01
    z[3,2,6]  R1135     1.0586041212081909e-01
    z[3,2,6]  R1136     -3.6997777223587036e-01
    z[3,2,6]  R1137     -9.2456437647342682e-02
    z[3,4,0]  R29       -1
    z[3,4,0]  R38       1
    z[3,4,0]  R1138     -1
    z[3,4,0]  R1139     1
    z[3,4,0]  R1152     -5.4624056816101074e-01
    z[3,4,0]  R1153     -0.424212247133255
    z[3,4,0]  R1154     7.1994647383689880e-02
    z[3,4,0]  R1155     -6.1272311210632324e-01
    z[3,4,0]  R1156     -6.4805978536605835e-01
    z[3,4,0]  R1157     -3.4386971592903137e-01
    z[3,4,0]  R1158     -8.9542247354984283e-02
    z[3,4,0]  R1159     1.1211939901113510e-01
    z[3,4,0]  R1160     -2.8060302138328552e-01
    z[3,4,0]  R1161     3.1735548377037048e-01
    z[3,4,0]  R1162     -6.1525338888168335e-01
    z[3,4,0]  R1163     -8.6321853101253510e-02
    z[3,4,0]  R1164     1.6740697622299194e-01
    z[3,4,0]  R1165     3.4569454193115234e-01
    z[3,4,0]  R1166     5.2569651603698730e-01
    z[3,4,0]  R1167     3.9396968483924866e-01
    z[3,4,0]  R1168     2.5449299812316895e-01
    z[3,4,0]  R1169     -6.4478024840354919e-02
    z[3,4,0]  R1170     -3.1391513347625732e-01
    z[3,4,0]  R1171     0.0785473957657814
    z[3,4,0]  R1172     -0.202298104763031
    z[3,4,0]  R1173     -3.6601746082305908e-01
    z[3,4,0]  R1174     1.3802783191204071e-01
    z[3,4,0]  R1175     -0.574720025062561
    z[3,4,0]  R1176     -1.1223085224628448e-01
    z[3,4,0]  R1177     -2.9490327835083008e-01
    z[3,4,0]  R1178     3.1449355185031891e-02
    z[3,4,0]  R1179     -2.7709737420082092e-02
    z[3,4,0]  R1180     -7.8968949615955353e-02
    z[3,4,0]  R1181     1.7646408081054688e-01
    z[3,4,0]  R1182     -1.8827441334724426e-01
    z[3,4,0]  R1183     -2.2635528445243835e-01
    z[3,4,0]  R1184     2.1855413913726807e-01
    z[3,4,0]  R1185     -4.7770336270332336e-02
    z[3,4,0]  R1186     1.0365481674671173e-01
    z[3,4,0]  R1187     -1.7878907918930054e-01
    z[3,4,0]  R1188     -4.6802438795566559e-02
    z[3,4,0]  R1189     -5.0883240997791290e-02
    z[3,4,0]  R1190     1.4553122222423553e-01
    z[3,4,0]  R1191     2.3893390595912933e-01
    z[3,4,0]  R1192     -8.7573036551475525e-02
    z[3,4,0]  R1193     3.5484347492456436e-02
    z[3,4,0]  R1194     -1.9336035475134850e-02
    z[3,4,0]  R1195     5.8665376156568527e-02
    z[3,4,0]  R1196     -3.2212796807289124e-01
    z[3,4,0]  R1197     2.3365199565887451e-01
    z[3,4,0]  R1198     -1.0389288514852524e-01
    z[3,4,0]  R1199     -4.9414080381393433e-01
    z[3,4,0]  R1200     -4.2689168453216553e-01
    z[3,4,0]  R1201     2.8846862912178040e-01
    z[3,4,0]  R1202     -7.8451806306838989e-01
    z[3,4,0]  R1203     -2.3863452672958374e-01
    z[3,4,0]  R1204     -4.2138642072677612e-01
    z[3,4,0]  R1205     -2.3271121084690094e-01
    z[3,4,0]  R1206     9.3946374952793121e-02
    z[3,4,0]  R1207     -6.3066649436950684e-01
    z[3,4,0]  R1208     -2.2421675920486450e-01
    z[3,4,0]  R1209     0.221639484167099
    z[3,4,0]  R1210     2.5867444276809692e-01
    z[3,4,0]  R1211     2.9126021265983582e-01
    z[3,4,0]  R1212     3.7454894185066223e-01
    z[3,4,0]  R1213     2.7899321913719177e-01
    z[3,4,0]  R1214     3.8191944360733032e-01
    z[3,4,0]  R1215     2.9376068711280823e-01
    z[3,4,0]  R1216     -0.0978270173072815
    z[3,4,0]  R1217     -2.9137728735804558e-02
    z[3,4,0]  R1218     7.4456967413425446e-02
    z[3,4,0]  R1219     1.8401703238487244e-01
    z[3,4,0]  R1220     0.302244633436203
    z[3,4,0]  R1221     1.1519994586706161e-01
    z[3,4,0]  R1222     -3.0517500638961792e-01
    z[3,4,0]  R1223     4.6974033117294312e-01
    z[3,4,0]  R1224     4.7435140609741211e-01
    z[3,4,0]  R1225     -2.6120521128177643e-02
    z[3,4,0]  R1226     0.317367821931839
    z[3,4,0]  R1227     -1.7612075433135033e-02
    z[3,4,0]  R1228     -1.6793097555637360e-01
    z[3,4,0]  R1229     -1.0067898780107498e-01
    z[3,4,0]  R1230     -1.6538232564926147e-02
    z[3,4,0]  R1231     -1.2822266668081284e-02
    z[3,4,0]  R1232     3.6187297105789185e-01
    z[3,4,0]  R1233     2.9852783679962158e-01
    z[3,4,0]  R1234     3.7791994214057922e-01
    z[3,4,0]  R1235     -3.7840750813484192e-01
    z[3,4,0]  R1236     -2.8823024034500122e-01
    z[3,4,0]  R1237     2.5137278437614441e-01
    z[3,4,0]  R1238     3.0971741676330566e-01
    z[3,4,0]  R1239     -0.0793575644493103
    z[3,4,0]  R1240     -1.8650509417057037e-01
    z[3,4,0]  R1241     1.6907888650894165e-01
    z[3,4,0]  R1242     3.1163122504949570e-02
    z[3,4,0]  R1243     1.5796346962451935e-01
    z[3,4,0]  R1244     2.8270235657691956e-01
    z[3,4,0]  R1245     -3.6034090444445610e-03
    z[3,4,0]  R1246     -1.9155786931514740e-01
    z[3,4,0]  R1247     -1.3722683489322662e-01
    z[3,4,0]  R1248     -2.5865417718887329e-01
    z[3,4,0]  R1249     -3.6463830620050430e-02
    z[3,4,0]  R1250     7.2248607873916626e-01
    z[3,4,0]  R1251     -9.6755206584930420e-02
    z[3,4,0]  R1252     -0.223170205950737
    z[3,4,0]  R1253     -4.9366939812898636e-02
    z[3,4,0]  R1254     2.2083133459091187e-01
    z[3,4,0]  R1255     1.7553773522377014e-01
    z[3,4,0]  R1256     4.5671370625495911e-01
    z[3,4,0]  R1257     -1.8355819582939148e-01
    z[3,4,0]  R1258     -2.1551392972469330e-01
    z[3,4,0]  R1259     0.100338414311409
    z[3,4,0]  R1260     -1.9112358568236232e-03
    z[3,4,0]  R1261     -1.3800835609436035e-01
    z[3,4,0]  R1262     2.6239061355590820e-01
    z[3,4,0]  R1263     3.1615287065505981e-01
    z[3,4,0]  R1264     3.3481448888778687e-01
    z[3,4,0]  R1265     6.4860087633132935e-01
    z[3,4,0]  R1266     2.3486499488353729e-01
    z[3,4,0]  R1267     3.1915476918220520e-01
    z[3,4,0]  R1268     4.6502545475959778e-01
    z[3,4,0]  R1269     6.9791865348815918e-01
    z[3,4,0]  R1270     -2.4639932811260223e-01
    z[3,4,0]  R1271     1.2444227188825607e-01
    z[3,4,0]  R1272     0.422778844833374
    z[3,4,0]  R1273     1.8694639205932617e-01
    z[3,4,0]  R1274     0.463606595993042
    z[3,4,0]  R1275     0.695311427116394
    z[3,4,0]  R1276     7.3519617319107056e-01
    z[3,4,0]  R1277     0.730003833770752
    z[3,4,1]  R30       -1
    z[3,4,1]  R39       1
    z[3,4,1]  R1140     -1
    z[3,4,1]  R1141     1
    z[3,4,1]  R1152     7.9328608512878418e-01
    z[3,4,1]  R1153     7.6735401153564453e-01
    z[3,4,1]  R1154     6.3840603828430176e-01
    z[3,4,1]  R1155     1.1874987185001373e-01
    z[3,4,1]  R1156     1.6845221817493439e-01
    z[3,4,1]  R1157     1.1892323940992355e-01
    z[3,4,1]  R1158     -4.9029093235731125e-02
    z[3,4,1]  R1159     -2.0932072773575783e-02
    z[3,4,1]  R1160     -5.1081206649541855e-02
    z[3,4,1]  R1161     -4.6568468213081360e-02
    z[3,4,1]  R1162     -6.5252298116683960e-01
    z[3,4,1]  R1163     -6.6241371631622314e-01
    z[3,4,1]  R1164     -6.3512933254241943e-01
    z[3,4,1]  R1165     -5.6671643257141113e-01
    z[3,4,1]  R1166     -5.8184927701950073e-01
    z[3,4,1]  R1167     -8.0940610170364380e-01
    z[3,4,1]  R1168     -5.6583595275878906e-01
    z[3,4,1]  R1169     -5.6445431709289551e-01
    z[3,4,1]  R1170     -6.2445646524429321e-01
    z[3,4,1]  R1171     -5.3245031833648682e-01
    z[3,4,1]  R1172     -7.7334809303283691e-01
    z[3,4,1]  R1173     -6.9144630432128906e-01
    z[3,4,1]  R1174     -0.743336021900177
    z[3,4,1]  R1175     -6.4037960767745972e-01
    z[3,4,1]  R1176     4.4405010342597961e-01
    z[3,4,1]  R1177     -6.9568479061126709e-01
    z[3,4,1]  R1178     0.522428035736084
    z[3,4,1]  R1179     -5.3287369012832642e-01
    z[3,4,1]  R1180     4.8844003677368164e-01
    z[3,4,1]  R1181     6.3939177989959717e-01
    z[3,4,1]  R1182     -8.4677040576934814e-01
    z[3,4,1]  R1183     -8.7058031558990479e-01
    z[3,4,1]  R1184     -8.9668089151382446e-01
    z[3,4,1]  R1185     -7.2005736827850342e-01
    z[3,4,1]  R1186     -6.7852222919464111e-01
    z[3,4,1]  R1187     0.713131844997406
    z[3,4,1]  R1188     -6.1013668775558472e-01
    z[3,4,1]  R1189     -6.1674284934997559e-01
    z[3,4,1]  R1190     6.5785801410675049e-01
    z[3,4,1]  R1191     8.5632407665252686e-01
    z[3,4,1]  R1192     6.4206200838088989e-01
    z[3,4,1]  R1193     8.7107646465301514e-01
    z[3,4,1]  R1194     -7.5011372566223145e-01
    z[3,4,1]  R1195     -8.7947982549667358e-01
    z[3,4,1]  R1196     4.7453027963638306e-01
    z[3,4,1]  R1197     -6.2827903032302856e-01
    z[3,4,1]  R1198     6.8753391504287720e-01
    z[3,4,1]  R1199     3.6887449026107788e-01
    z[3,4,1]  R1200     3.3512553572654724e-01
    z[3,4,1]  R1201     -0.559316098690033
    z[3,4,1]  R1202     2.8132668137550354e-01
    z[3,4,1]  R1203     4.2940124869346619e-01
    z[3,4,1]  R1204     7.5325970537960529e-03
    z[3,4,1]  R1205     5.7901513576507568e-01
    z[3,4,1]  R1206     2.0204983651638031e-01
    z[3,4,1]  R1207     8.6046881973743439e-02
    z[3,4,1]  R1208     2.8027138113975525e-01
    z[3,4,1]  R1209     4.9292293190956116e-01
    z[3,4,1]  R1210     3.1568199396133423e-01
    z[3,4,1]  R1211     6.7493891716003418e-01
    z[3,4,1]  R1212     5.9162467718124390e-01
    z[3,4,1]  R1213     1.0954042524099350e-01
    z[3,4,1]  R1214     4.5639863610267639e-01
    z[3,4,1]  R1215     1.4886243641376495e-01
    z[3,4,1]  R1216     -7.7556276321411133e-01
    z[3,4,1]  R1217     -6.4946508407592773e-01
    z[3,4,1]  R1218     -9.1136246919631958e-01
    z[3,4,1]  R1219     -8.9713948965072632e-01
    z[3,4,1]  R1220     -5.0371998548507690e-01
    z[3,4,1]  R1221     -8.0799359083175659e-01
    z[3,4,1]  R1222     -0.572062611579895
    z[3,4,1]  R1223     -7.7519947290420532e-01
    z[3,4,1]  R1224     -0.589427649974823
    z[3,4,1]  R1225     -6.5192335844039917e-01
    z[3,4,1]  R1226     -7.6822096109390259e-01
    z[3,4,1]  R1227     -4.5647367835044861e-01
    z[3,4,1]  R1228     -4.7322675585746765e-01
    z[3,4,1]  R1229     -6.4571005105972290e-01
    z[3,4,1]  R1230     -6.9772607088088989e-01
    z[3,4,1]  R1231     -8.3203715085983276e-01
    z[3,4,1]  R1232     -5.7106351852416992e-01
    z[3,4,1]  R1233     -4.4708859920501709e-01
    z[3,4,1]  R1234     -8.0021435022354126e-01
    z[3,4,1]  R1235     -7.7876365184783936e-01
    z[3,4,1]  R1236     -7.6200026273727417e-01
    z[3,4,1]  R1237     -7.6768219470977783e-01
    z[3,4,1]  R1238     -7.3314839601516724e-01
    z[3,4,1]  R1239     7.0500272512435913e-01
    z[3,4,1]  R1240     4.0483522415161133e-01
    z[3,4,1]  R1241     -5.5599248409271240e-01
    z[3,4,1]  R1242     -6.6381967067718506e-01
    z[3,4,1]  R1243     -9.0491241216659546e-01
    z[3,4,1]  R1244     -0.619698166847229
    z[3,4,1]  R1245     -5.0538444519042969e-01
    z[3,4,1]  R1246     -8.6528658866882324e-01
    z[3,4,1]  R1247     -7.7655076980590820e-01
    z[3,4,1]  R1248     -9.0143078565597534e-01
    z[3,4,1]  R1249     -7.0040273666381836e-01
    z[3,4,1]  R1250     2.1460117772221565e-02
    z[3,4,1]  R1251     -5.5794847011566162e-01
    z[3,4,1]  R1252     -8.7596380710601807e-01
    z[3,4,1]  R1253     -9.1440171003341675e-01
    z[3,4,1]  R1254     -6.7542958259582520e-01
    z[3,4,1]  R1255     -8.2888710498809814e-01
    z[3,4,1]  R1256     -6.4825212955474854e-01
    z[3,4,1]  R1257     -7.9127651453018188e-01
    z[3,4,1]  R1258     -8.2369971275329590e-01
    z[3,4,1]  R1259     -7.7229762077331543e-01
    z[3,4,1]  R1260     -8.8891887664794922e-01
    z[3,4,1]  R1261     -8.8942545652389526e-01
    z[3,4,1]  R1262     -0.79151850938797
    z[3,4,1]  R1263     -8.1461596488952637e-01
    z[3,4,1]  R1264     -8.2109457254409790e-01
    z[3,4,1]  R1265     -1.7773827910423279e-01
    z[3,4,1]  R1266     -7.5015085935592651e-01
    z[3,4,1]  R1267     -7.3993182182312012e-01
    z[3,4,1]  R1268     1.6175159811973572e-01
    z[3,4,1]  R1269     0.035215113312006
    z[3,4,1]  R1270     -0.937619686126709
    z[3,4,1]  R1271     -8.9324432611465454e-01
    z[3,4,1]  R1272     -7.7389258146286011e-01
    z[3,4,1]  R1273     -8.1678217649459839e-01
    z[3,4,1]  R1274     -4.9182184040546417e-02
    z[3,4,1]  R1275     4.4177651405334473e-01
    z[3,4,1]  R1276     4.1015404462814331e-01
    z[3,4,1]  R1277     3.9751288294792175e-01
    z[3,4,2]  R31       -1
    z[3,4,2]  R40       1
    z[3,4,2]  R1142     -1
    z[3,4,2]  R1143     1
    z[3,4,2]  R1152     2.4101685732603073e-02
    z[3,4,2]  R1153     -1.2400750815868378e-01
    z[3,4,2]  R1154     5.2930307388305664e-01
    z[3,4,2]  R1155     5.2981162071228027e-01
    z[3,4,2]  R1156     5.2514404058456421e-01
    z[3,4,2]  R1157     3.1009066104888916e-01
    z[3,4,2]  R1158     -4.4367730617523193e-01
    z[3,4,2]  R1159     -8.0586922168731689e-01
    z[3,4,2]  R1160     -7.8454381227493286e-01
    z[3,4,2]  R1161     8.0022051930427551e-02
    z[3,4,2]  R1162     0.0970572754740715
    z[3,4,2]  R1163     0.152975931763649
    z[3,4,2]  R1164     3.4097391366958618e-01
    z[3,4,2]  R1165     -3.8507252931594849e-01
    z[3,4,2]  R1166     -6.8089894950389862e-02
    z[3,4,2]  R1167     -2.3545506596565247e-01
    z[3,4,2]  R1168     -5.0401028245687485e-02
    z[3,4,2]  R1169     8.3726853132247925e-02
    z[3,4,2]  R1170     1.0667237639427185e-01
    z[3,4,2]  R1171     -2.7492982149124146e-01
    z[3,4,2]  R1172     -4.1653178632259369e-02
    z[3,4,2]  R1173     2.7315405011177063e-01
    z[3,4,2]  R1174     1.5096355974674225e-01
    z[3,4,2]  R1175     4.1382029652595520e-01
    z[3,4,2]  R1176     5.0347495079040527e-01
    z[3,4,2]  R1177     -9.3935750424861908e-02
    z[3,4,2]  R1178     4.3033921718597412e-01
    z[3,4,2]  R1179     -4.3597763776779175e-01
    z[3,4,2]  R1180     1.1288274079561234e-01
    z[3,4,2]  R1181     6.4795380830764771e-01
    z[3,4,2]  R1182     -2.4157375097274780e-01
    z[3,4,2]  R1183     -3.2371073961257935e-02
    z[3,4,2]  R1184     0.0947737991809845
    z[3,4,2]  R1185     -2.7153888344764709e-01
    z[3,4,2]  R1186     -5.3877639770507812e-01
    z[3,4,2]  R1187     3.5098394751548767e-01
    z[3,4,2]  R1188     -2.7506032586097717e-01
    z[3,4,2]  R1189     3.3013519644737244e-01
    z[3,4,2]  R1190     3.1272286176681519e-01
    z[3,4,2]  R1191     3.6370927095413208e-01
    z[3,4,2]  R1192     4.2421030998229980e-01
    z[3,4,2]  R1193     1.8731613457202911e-01
    z[3,4,2]  R1194     2.3560628294944763e-02
    z[3,4,2]  R1195     2.8810295462608337e-01
    z[3,4,2]  R1196     1.2663708627223969e-01
    z[3,4,2]  R1197     -3.2625325024127960e-02
    z[3,4,2]  R1198     2.0188353955745697e-02
    z[3,4,2]  R1199     4.5583987236022949e-01
    z[3,4,2]  R1200     5.1397567987442017e-01
    z[3,4,2]  R1201     0.0961170494556427
    z[3,4,2]  R1202     1.2565425038337708e-01
    z[3,4,2]  R1203     -7.2990462183952332e-02
    z[3,4,2]  R1204     -1.2438035011291504e-01
    z[3,4,2]  R1205     -1.6645358502864838e-01
    z[3,4,2]  R1206     -9.1014020144939423e-02
    z[3,4,2]  R1207     0.626151442527771
    z[3,4,2]  R1208     -2.4900703132152557e-01
    z[3,4,2]  R1209     1.0611472278833389e-01
    z[3,4,2]  R1210     9.1054454445838928e-02
    z[3,4,2]  R1211     -1.5911756455898285e-01
    z[3,4,2]  R1212     3.1160160899162292e-01
    z[3,4,2]  R1213     -1.1797026731073856e-02
    z[3,4,2]  R1214     -2.3035086691379547e-01
    z[3,4,2]  R1215     8.2876391708850861e-02
    z[3,4,2]  R1216     -3.3033519983291626e-01
    z[3,4,2]  R1217     -4.6171391010284424e-01
    z[3,4,2]  R1218     -3.1455031037330627e-01
    z[3,4,2]  R1219     1.0135427117347717e-01
    z[3,4,2]  R1220     -4.3890568614006042e-01
    z[3,4,2]  R1221     0.136931911110878
    z[3,4,2]  R1222     -6.8476319313049316e-01
    z[3,4,2]  R1223     -9.9444175139069557e-03
    z[3,4,2]  R1224     -4.6268993616104126e-01
    z[3,4,2]  R1225     -5.4729342460632324e-01
    z[3,4,2]  R1226     2.4883045256137848e-01
    z[3,4,2]  R1227     -6.9945007562637329e-01
    z[3,4,2]  R1228     -8.0823624134063721e-01
    z[3,4,2]  R1229     -6.4133191108703613e-01
    z[3,4,2]  R1230     -1.8304759636521339e-02
    z[3,4,2]  R1231     2.4319043755531311e-01
    z[3,4,2]  R1232     -6.8353205919265747e-01
    z[3,4,2]  R1233     -7.9876106977462769e-01
    z[3,4,2]  R1234     6.4935930073261261e-02
    z[3,4,2]  R1235     2.7095427736639977e-02
    z[3,4,2]  R1236     -1.4205268025398254e-01
    z[3,4,2]  R1237     -9.6215203404426575e-02
    z[3,4,2]  R1238     -1.0724537819623947e-01
    z[3,4,2]  R1239     -1.6476549208164215e-02
    z[3,4,2]  R1240     -2.6660233736038208e-01
    z[3,4,2]  R1241     -7.3061013221740723e-01
    z[3,4,2]  R1242     -6.6492223739624023e-01
    z[3,4,2]  R1243     1.3585336506366730e-01
    z[3,4,2]  R1244     -5.5617189407348633e-01
    z[3,4,2]  R1245     -5.2972149848937988e-01
    z[3,4,2]  R1246     -1.8511453270912170e-01
    z[3,4,2]  R1247     -2.8458639979362488e-01
    z[3,4,2]  R1248     3.7137895822525024e-02
    z[3,4,2]  R1249     -6.5151625871658325e-01
    z[3,4,2]  R1250     -4.9594688415527344e-01
    z[3,4,2]  R1251     -5.4087972640991211e-01
    z[3,4,2]  R1252     -1.7047224566340446e-02
    z[3,4,2]  R1253     2.7067303657531738e-01
    z[3,4,2]  R1254     -2.6017594337463379e-01
    z[3,4,2]  R1255     3.2183980941772461e-01
    z[3,4,2]  R1256     -1.6664777696132660e-01
    z[3,4,2]  R1257     -2.0325869321823120e-02
    z[3,4,2]  R1258     1.1372482031583786e-01
    z[3,4,2]  R1259     -5.3918910026550293e-01
    z[3,4,2]  R1260     -2.1300375461578369e-01
    z[3,4,2]  R1261     1.8503311276435852e-01
    z[3,4,2]  R1262     -3.3325843513011932e-02
    z[3,4,2]  R1263     -3.8550995290279388e-02
    z[3,4,2]  R1264     2.6382654905319214e-01
    z[3,4,2]  R1265     -9.6111074090003967e-02
    z[3,4,2]  R1266     -1.9729016721248627e-01
    z[3,4,2]  R1267     1.6195631027221680e-01
    z[3,4,2]  R1268     -1.3061526417732239e-01
    z[3,4,2]  R1269     -4.5849704742431641e-01
    z[3,4,2]  R1270     5.3239818662405014e-02
    z[3,4,2]  R1271     -4.7729674726724625e-02
    z[3,4,2]  R1272     -9.9238239228725433e-02
    z[3,4,2]  R1273     -1.8111547827720642e-01
    z[3,4,2]  R1274     -9.2884004116058350e-03
    z[3,4,2]  R1275     0.0757242813706398
    z[3,4,2]  R1276     0.326010137796402
    z[3,4,2]  R1277     1.1096108704805374e-01
    z[3,4,3]  R32       -1
    z[3,4,3]  R41       1
    z[3,4,3]  R1144     -1
    z[3,4,3]  R1145     1
    z[3,4,3]  R1152     1.5139020979404449e-01
    z[3,4,3]  R1153     2.9603728652000427e-01
    z[3,4,3]  R1154     1.5822613239288330e-01
    z[3,4,3]  R1155     2.4612200260162354e-01
    z[3,4,3]  R1156     1.1945197731256485e-01
    z[3,4,3]  R1157     0.0224288459867239
    z[3,4,3]  R1158     -5.5111384391784668e-01
    z[3,4,3]  R1159     4.6425831317901611e-01
    z[3,4,3]  R1160     -4.1696190834045410e-01
    z[3,4,3]  R1161     -8.2614302635192871e-01
    z[3,4,3]  R1162     -4.0400597453117371e-01
    z[3,4,3]  R1163     -0.0763794332742691
    z[3,4,3]  R1164     -2.2706650197505951e-01
    z[3,4,3]  R1165     -7.7574424445629120e-02
    z[3,4,3]  R1166     -5.6893610954284668e-01
    z[3,4,3]  R1167     -3.5073789954185486e-01
    z[3,4,3]  R1168     -1.8418912589550018e-01
    z[3,4,3]  R1169     3.3512806892395020e-01
    z[3,4,3]  R1170     1.7176859080791473e-01
    z[3,4,3]  R1171     -1.3978110253810883e-01
    z[3,4,3]  R1172     -4.3832760304212570e-02
    z[3,4,3]  R1173     0.148304283618927
    z[3,4,3]  R1174     4.6387454867362976e-01
    z[3,4,3]  R1175     2.2624848783016205e-01
    z[3,4,3]  R1176     6.2244117259979248e-01
    z[3,4,3]  R1177     4.6368911862373352e-01
    z[3,4,3]  R1178     5.2992373704910278e-01
    z[3,4,3]  R1179     -3.0490031838417053e-01
    z[3,4,3]  R1180     6.3828772306442261e-01
    z[3,4,3]  R1181     5.4679099470376968e-02
    z[3,4,3]  R1182     2.2161155939102173e-01
    z[3,4,3]  R1183     1.2202896922826767e-01
    z[3,4,3]  R1184     3.0636712908744812e-01
    z[3,4,3]  R1185     -5.1346111297607422e-01
    z[3,4,3]  R1186     -0.125356987118721
    z[3,4,3]  R1187     -1.5767522156238556e-01
    z[3,4,3]  R1188     -0.00643932493403554
    z[3,4,3]  R1189     -5.5639952421188354e-01
    z[3,4,3]  R1190     2.8882962465286255e-01
    z[3,4,3]  R1191     -1.5325054526329041e-01
    z[3,4,3]  R1192     5.3501695394515991e-01
    z[3,4,3]  R1193     2.5933426618576050e-01
    z[3,4,3]  R1194     -1.9293682649731636e-02
    z[3,4,3]  R1195     -8.1855103373527527e-02
    z[3,4,3]  R1196     7.2345834970474243e-01
    z[3,4,3]  R1197     -2.1861200034618378e-01
    z[3,4,3]  R1198     1.4545749127864838e-01
    z[3,4,3]  R1199     2.9838341474533081e-01
    z[3,4,3]  R1200     2.6166230440139771e-01
    z[3,4,3]  R1201     -4.8168757557868958e-01
    z[3,4,3]  R1202     -2.8652116656303406e-01
    z[3,4,3]  R1203     3.5964247584342957e-01
    z[3,4,3]  R1204     2.0728701353073120e-01
    z[3,4,3]  R1205     -5.2693802118301392e-01
    z[3,4,3]  R1206     -6.0815256834030151e-01
    z[3,4,3]  R1207     2.3736244067549706e-02
    z[3,4,3]  R1208     3.3163344860076904e-01
    z[3,4,3]  R1209     7.7075809240341187e-01
    z[3,4,3]  R1210     8.5122185945510864e-01
    z[3,4,3]  R1211     0.625590443611145
    z[3,4,3]  R1212     6.2528085708618164e-01
    z[3,4,3]  R1213     9.3912720680236816e-01
    z[3,4,3]  R1214     6.7131775617599487e-01
    z[3,4,3]  R1215     7.4573343992233276e-01
    z[3,4,3]  R1216     -1.6835495829582214e-01
    z[3,4,3]  R1217     -1.0739649832248688e-01
    z[3,4,3]  R1218     -2.1419250965118408e-01
    z[3,4,3]  R1219     -1.6170606017112732e-01
    z[3,4,3]  R1220     -6.2765496969223022e-01
    z[3,4,3]  R1221     3.4590315818786621e-01
    z[3,4,3]  R1222     7.9685494303703308e-02
    z[3,4,3]  R1223     1.6408908367156982e-01
    z[3,4,3]  R1224     -2.7080511674284935e-02
    z[3,4,3]  R1225     -3.9443865418434143e-01
    z[3,4,3]  R1226     2.4014189839363098e-01
    z[3,4,3]  R1227     -1.2927785515785217e-01
    z[3,4,3]  R1228     0.0540459118783474
    z[3,4,3]  R1229     7.0934325456619263e-02
    z[3,4,3]  R1230     -5.7334297895431519e-01
    z[3,4,3]  R1231     2.5984886288642883e-01
    z[3,4,3]  R1232     1.1943177878856659e-01
    z[3,4,3]  R1233     -1.2809245288372040e-01
    z[3,4,3]  R1234     9.6224442124366760e-02
    z[3,4,3]  R1235     -3.6655715107917786e-01
    z[3,4,3]  R1236     0.0673820897936821
    z[3,4,3]  R1237     4.0417218208312988e-01
    z[3,4,3]  R1238     2.4162137508392334e-01
    z[3,4,3]  R1239     3.8890153169631958e-01
    z[3,4,3]  R1240     5.7501119375228882e-01
    z[3,4,3]  R1241     -2.3392596840858459e-01
    z[3,4,3]  R1242     4.7164112329483032e-02
    z[3,4,3]  R1243     1.7356034368276596e-02
    z[3,4,3]  R1244     -4.5801591873168945e-01
    z[3,4,3]  R1245     -3.3098584413528442e-01
    z[3,4,3]  R1246     -1.4017856121063232e-01
    z[3,4,3]  R1247     -4.1113600134849548e-01
    z[3,4,3]  R1248     6.7720770835876465e-02
    z[3,4,3]  R1249     -2.7207341790199280e-01
    z[3,4,3]  R1250     2.9130643606185913e-01
    z[3,4,3]  R1251     -0.48995241522789
    z[3,4,3]  R1252     0.154449462890625
    z[3,4,3]  R1253     -2.7712401747703552e-01
    z[3,4,3]  R1254     -3.0682352185249329e-01
    z[3,4,3]  R1255     -8.2297712564468384e-02
    z[3,4,3]  R1256     -3.5729256272315979e-01
    z[3,4,3]  R1257     7.8484527766704559e-02
    z[3,4,3]  R1258     -1.7783628404140472e-01
    z[3,4,3]  R1259     -8.9961253106594086e-02
    z[3,4,3]  R1260     1.8062674999237061e-01
    z[3,4,3]  R1261     -1.3411337137222290e-01
    z[3,4,3]  R1262     -5.0566357374191284e-01
    z[3,4,3]  R1263     2.0418265461921692e-01
    z[3,4,3]  R1264     5.1924187690019608e-02
    z[3,4,3]  R1265     2.6497477293014526e-01
    z[3,4,3]  R1266     -1.2366843223571777e-01
    z[3,4,3]  R1267     -2.4484993517398834e-01
    z[3,4,3]  R1268     2.2541526705026627e-02
    z[3,4,3]  R1269     3.8468053936958313e-01
    z[3,4,3]  R1270     -2.2348362207412720e-01
    z[3,4,3]  R1271     -2.5302174687385559e-01
    z[3,4,3]  R1272     2.5384664535522461e-01
    z[3,4,3]  R1273     5.5681776255369186e-02
    z[3,4,3]  R1274     5.7787474244832993e-02
    z[3,4,3]  R1275     -2.5616058707237244e-01
    z[3,4,3]  R1276     -2.4824059009552002e-01
    z[3,4,3]  R1277     -2.2069209814071655e-01
    z[3,4,4]  R33       -1
    z[3,4,4]  R42       1
    z[3,4,4]  R1146     -1
    z[3,4,4]  R1147     1
    z[3,4,4]  R1152     -9.9260888993740082e-02
    z[3,4,4]  R1153     -1.8220679461956024e-01
    z[3,4,4]  R1154     1.9566479325294495e-01
    z[3,4,4]  R1155     -4.1278502345085144e-01
    z[3,4,4]  R1156     1.5285915136337280e-01
    z[3,4,4]  R1157     2.2578676044940948e-01
    z[3,4,4]  R1158     -6.1166834831237793e-01
    z[3,4,4]  R1159     6.0078907757997513e-02
    z[3,4,4]  R1160     -1.0044468194246292e-01
    z[3,4,4]  R1161     1.9026717543601990e-01
    z[3,4,4]  R1162     -0.0942695364356041
    z[3,4,4]  R1163     -0.530070424079895
    z[3,4,4]  R1164     0.572259247303009
    z[3,4,4]  R1165     0.281680703163147
    z[3,4,4]  R1166     4.8072297126054764e-02
    z[3,4,4]  R1167     1.2790170498192310e-02
    z[3,4,4]  R1168     5.2944332361221313e-01
    z[3,4,4]  R1169     5.0449732691049576e-02
    z[3,4,4]  R1170     1.2470442801713943e-01
    z[3,4,4]  R1171     -5.2881163358688354e-01
    z[3,4,4]  R1172     -6.7869938910007477e-02
    z[3,4,4]  R1173     0.330610454082489
    z[3,4,4]  R1174     -8.7898708879947662e-02
    z[3,4,4]  R1175     1.6543485224246979e-01
    z[3,4,4]  R1176     3.1123638153076172e-01
    z[3,4,4]  R1177     -1.7848348617553711e-01
    z[3,4,4]  R1178     1.1690960079431534e-01
    z[3,4,4]  R1179     1.5920451283454895e-01
    z[3,4,4]  R1180     3.0334630608558655e-01
    z[3,4,4]  R1181     0.0460958406329155
    z[3,4,4]  R1182     2.8051629662513733e-02
    z[3,4,4]  R1183     -2.2514438629150391e-01
    z[3,4,4]  R1184     4.8451088368892670e-02
    z[3,4,4]  R1185     -2.8541529178619385e-01
    z[3,4,4]  R1186     2.3641730844974518e-01
    z[3,4,4]  R1187     -4.1492116451263428e-01
    z[3,4,4]  R1188     3.7780386209487915e-01
    z[3,4,4]  R1189     3.3900007605552673e-02
    z[3,4,4]  R1190     -5.9458520263433456e-02
    z[3,4,4]  R1191     2.0541921257972717e-01
    z[3,4,4]  R1192     9.1188631951808929e-02
    z[3,4,4]  R1193     7.1426816284656525e-02
    z[3,4,4]  R1194     -1.2145414017140865e-02
    z[3,4,4]  R1195     -2.1761940419673920e-01
    z[3,4,4]  R1196     1.8333357572555542e-01
    z[3,4,4]  R1197     1.2594452500343323e-01
    z[3,4,4]  R1198     2.7962759137153625e-01
    z[3,4,4]  R1199     5.1990884542465210e-01
    z[3,4,4]  R1200     1.6360929608345032e-01
    z[3,4,4]  R1201     9.3086190521717072e-02
    z[3,4,4]  R1202     2.0960272848606110e-01
    z[3,4,4]  R1203     -3.7107229232788086e-02
    z[3,4,4]  R1204     -7.0225065946578979e-01
    z[3,4,4]  R1205     -4.7506490349769592e-01
    z[3,4,4]  R1206     -3.6551004648208618e-01
    z[3,4,4]  R1207     -4.3038591742515564e-01
    z[3,4,4]  R1208     4.4329786300659180e-01
    z[3,4,4]  R1209     -5.3792528808116913e-02
    z[3,4,4]  R1210     -4.5282721519470215e-02
    z[3,4,4]  R1211     6.5043777227401733e-02
    z[3,4,4]  R1212     1.4205466210842133e-01
    z[3,4,4]  R1213     8.2762479782104492e-02
    z[3,4,4]  R1214     1.7623870074748993e-01
    z[3,4,4]  R1215     3.9861190319061279e-01
    z[3,4,4]  R1216     -2.0020754635334015e-01
    z[3,4,4]  R1217     -1.9458557665348053e-01
    z[3,4,4]  R1218     -8.5982456803321838e-02
    z[3,4,4]  R1219     1.6359147429466248e-01
    z[3,4,4]  R1220     1.9855398684740067e-02
    z[3,4,4]  R1221     0.178420752286911
    z[3,4,4]  R1222     2.1477924287319183e-01
    z[3,4,4]  R1223     -1.5897114574909210e-01
    z[3,4,4]  R1224     2.6159333065152168e-02
    z[3,4,4]  R1225     1.6524660587310791e-01
    z[3,4,4]  R1226     0.0753258541226387
    z[3,4,4]  R1227     3.3169826865196228e-01
    z[3,4,4]  R1228     0.0411791168153286
    z[3,4,4]  R1229     2.2157919406890869e-01
    z[3,4,4]  R1230     -4.7878913581371307e-02
    z[3,4,4]  R1231     3.7933662533760071e-01
    z[3,4,4]  R1232     -1.9451610743999481e-02
    z[3,4,4]  R1233     1.8401028215885162e-01
    z[3,4,4]  R1234     2.4931050837039948e-01
    z[3,4,4]  R1235     9.7140751779079437e-02
    z[3,4,4]  R1236     4.1627818346023560e-01
    z[3,4,4]  R1237     3.2874977588653564e-01
    z[3,4,4]  R1238     -2.6751694083213806e-01
    z[3,4,4]  R1239     4.1147032380104065e-01
    z[3,4,4]  R1240     4.1332921385765076e-01
    z[3,4,4]  R1241     4.8051834106445312e-02
    z[3,4,4]  R1242     1.0222673416137695e-01
    z[3,4,4]  R1243     -2.2699016332626343e-01
    z[3,4,4]  R1244     6.3473515212535858e-02
    z[3,4,4]  R1245     8.2612454891204834e-02
    z[3,4,4]  R1246     -2.8288796544075012e-02
    z[3,4,4]  R1247     7.2491921484470367e-02
    z[3,4,4]  R1248     9.1149166226387024e-02
    z[3,4,4]  R1249     -7.5300313532352448e-02
    z[3,4,4]  R1250     1.7393555492162704e-02
    z[3,4,4]  R1251     8.6900874972343445e-02
    z[3,4,4]  R1252     -1.9447323679924011e-01
    z[3,4,4]  R1253     1.8232997506856918e-02
    z[3,4,4]  R1254     -3.6176049709320068e-01
    z[3,4,4]  R1255     2.2238619625568390e-01
    z[3,4,4]  R1256     -9.1401286423206329e-02
    z[3,4,4]  R1257     3.6532336473464966e-01
    z[3,4,4]  R1258     1.1237250268459320e-01
    z[3,4,4]  R1259     1.1224296689033508e-01
    z[3,4,4]  R1260     7.5787985697388649e-03
    z[3,4,4]  R1261     6.4320690929889679e-02
    z[3,4,4]  R1262     -1.3239432871341705e-01
    z[3,4,4]  R1263     2.5776756927371025e-02
    z[3,4,4]  R1264     3.5215219855308533e-01
    z[3,4,4]  R1265     6.4503157138824463e-01
    z[3,4,4]  R1266     4.3805581331253052e-01
    z[3,4,4]  R1267     -1.5390609204769135e-01
    z[3,4,4]  R1268     6.7675316333770752e-01
    z[3,4,4]  R1269     -3.6997926235198975e-01
    z[3,4,4]  R1270     -6.6607259213924408e-02
    z[3,4,4]  R1271     1.2064320594072342e-01
    z[3,4,4]  R1272     2.6603901386260986e-01
    z[3,4,4]  R1273     4.8441749811172485e-01
    z[3,4,4]  R1274     7.0256847143173218e-01
    z[3,4,4]  R1275     4.4332712888717651e-01
    z[3,4,4]  R1276     3.2140663266181946e-01
    z[3,4,4]  R1277     1.5471938252449036e-01
    z[3,4,5]  R34       -1
    z[3,4,5]  R43       1
    z[3,4,5]  R1148     -1
    z[3,4,5]  R1149     1
    z[3,4,5]  R1152     -1.4690301613882184e-03
    z[3,4,5]  R1153     7.7183679677546024e-03
    z[3,4,5]  R1154     0.411602646112442
    z[3,4,5]  R1155     3.0027794837951660e-01
    z[3,4,5]  R1156     4.4443616271018982e-01
    z[3,4,5]  R1157     7.7148318290710449e-01
    z[3,4,5]  R1158     -7.3083013296127319e-02
    z[3,4,5]  R1159     3.0366408824920654e-01
    z[3,4,5]  R1160     1.6252642869949341e-01
    z[3,4,5]  R1161     1.2806795537471771e-01
    z[3,4,5]  R1162     -3.5857267677783966e-02
    z[3,4,5]  R1163     0.175323948264122
    z[3,4,5]  R1164     2.4659889936447144e-01
    z[3,4,5]  R1165     -5.7021111249923706e-01
    z[3,4,5]  R1166     -2.3316358029842377e-01
    z[3,4,5]  R1167     -7.3266260325908661e-02
    z[3,4,5]  R1168     5.0397776067256927e-02
    z[3,4,5]  R1169     4.6938300132751465e-01
    z[3,4,5]  R1170     4.2848322540521622e-02
    z[3,4,5]  R1171     -3.4131422638893127e-01
    z[3,4,5]  R1172     5.9016084671020508e-01
    z[3,4,5]  R1173     -4.1576853394508362e-01
    z[3,4,5]  R1174     -2.4785226583480835e-01
    z[3,4,5]  R1175     7.4764534831047058e-02
    z[3,4,5]  R1176     1.9420921802520752e-01
    z[3,4,5]  R1177     -3.9852684736251831e-01
    z[3,4,5]  R1178     -4.8294299840927124e-01
    z[3,4,5]  R1179     4.3299004435539246e-01
    z[3,4,5]  R1180     -4.8052871227264404e-01
    z[3,4,5]  R1181     -3.6589032411575317e-01
    z[3,4,5]  R1182     1.8955765292048454e-02
    z[3,4,5]  R1183     3.3537667989730835e-01
    z[3,4,5]  R1184     -1.8424670398235321e-01
    z[3,4,5]  R1185     -1.2360414117574692e-01
    z[3,4,5]  R1186     -2.2777855396270752e-01
    z[3,4,5]  R1187     -3.6247935891151428e-01
    z[3,4,5]  R1188     2.7795165777206421e-01
    z[3,4,5]  R1189     -1.0404511541128159e-01
    z[3,4,5]  R1190     -4.3667447566986084e-01
    z[3,4,5]  R1191     8.2699991762638092e-02
    z[3,4,5]  R1192     -2.6953813433647156e-01
    z[3,4,5]  R1193     -2.2505274415016174e-01
    z[3,4,5]  R1194     -3.7162205576896667e-01
    z[3,4,5]  R1195     -2.0590139925479889e-01
    z[3,4,5]  R1196     -3.0605033040046692e-01
    z[3,4,5]  R1197     -0.577193021774292
    z[3,4,5]  R1198     6.0814291238784790e-01
    z[3,4,5]  R1199     -1.1223967373371124e-01
    z[3,4,5]  R1200     1.0405306518077850e-01
    z[3,4,5]  R1201     -6.3074208796024323e-02
    z[3,4,5]  R1202     -2.9125988483428955e-01
    z[3,4,5]  R1203     2.8395307064056396e-01
    z[3,4,5]  R1204     3.8931244611740112e-01
    z[3,4,5]  R1205     -1.9168801605701447e-01
    z[3,4,5]  R1206     5.8619940280914307e-01
    z[3,4,5]  R1207     -2.4412751197814941e-02
    z[3,4,5]  R1208     -2.9837164282798767e-01
    z[3,4,5]  R1209     -2.8865331411361694e-01
    z[3,4,5]  R1210     1.4389933645725250e-01
    z[3,4,5]  R1211     -9.0629987418651581e-02
    z[3,4,5]  R1212     -3.2613296061754227e-02
    z[3,4,5]  R1213     -1.4074572920799255e-01
    z[3,4,5]  R1214     3.2871791720390320e-01
    z[3,4,5]  R1215     1.4860203862190247e-01
    z[3,4,5]  R1216     -4.4143116474151611e-01
    z[3,4,5]  R1217     -5.3421151638031006e-01
    z[3,4,5]  R1218     1.0798743367195129e-01
    z[3,4,5]  R1219     -2.9459038376808167e-01
    z[3,4,5]  R1220     -2.6060670614242554e-01
    z[3,4,5]  R1221     -7.2829827666282654e-02
    z[3,4,5]  R1222     -2.1018789708614349e-01
    z[3,4,5]  R1223     7.5851596891880035e-02
    z[3,4,5]  R1224     -3.5586071014404297e-01
    z[3,4,5]  R1225     -2.5549063086509705e-01
    z[3,4,5]  R1226     1.1772985756397247e-01
    z[3,4,5]  R1227     -2.9082307219505310e-01
    z[3,4,5]  R1228     -7.5395785272121429e-02
    z[3,4,5]  R1229     -2.9266867041587830e-01
    z[3,4,5]  R1230     -3.0513831973075867e-01
    z[3,4,5]  R1231     3.6092754453420639e-02
    z[3,4,5]  R1232     -0.0642428919672966
    z[3,4,5]  R1233     -1.3352457899600267e-03
    z[3,4,5]  R1234     2.5755900144577026e-01
    z[3,4,5]  R1235     -3.2464000582695007e-01
    z[3,4,5]  R1236     -0.275749534368515
    z[3,4,5]  R1237     2.5408431887626648e-01
    z[3,4,5]  R1238     -0.0939953550696373
    z[3,4,5]  R1239     -2.5288176536560059e-01
    z[3,4,5]  R1240     -2.3178742825984955e-01
    z[3,4,5]  R1241     -0.127928227186203
    z[3,4,5]  R1242     -3.0584850907325745e-01
    z[3,4,5]  R1243     -2.4475468695163727e-01
    z[3,4,5]  R1244     -6.1415430158376694e-02
    z[3,4,5]  R1245     -3.7571245431900024e-01
    z[3,4,5]  R1246     -2.3396830260753632e-01
    z[3,4,5]  R1247     -2.2887107729911804e-01
    z[3,4,5]  R1248     -2.9069520533084869e-02
    z[3,4,5]  R1249     -0.0584476999938488
    z[3,4,5]  R1250     -1.2071265280246735e-01
    z[3,4,5]  R1251     -3.0844411253929138e-01
    z[3,4,5]  R1252     -2.5860235095024109e-01
    z[3,4,5]  R1253     -2.2496019955724478e-03
    z[3,4,5]  R1254     -2.4236641824245453e-01
    z[3,4,5]  R1255     7.9531274735927582e-02
    z[3,4,5]  R1256     -4.3636941909790039e-01
    z[3,4,5]  R1257     -4.3903324007987976e-01
    z[3,4,5]  R1258     -9.9482253193855286e-02
    z[3,4,5]  R1259     -2.7293553948402405e-01
    z[3,4,5]  R1260     2.2007305920124054e-01
    z[3,4,5]  R1261     1.1336227878928185e-02
    z[3,4,5]  R1262     -1.5972651541233063e-01
    z[3,4,5]  R1263     4.2401656508445740e-01
    z[3,4,5]  R1264     1.3125570118427277e-01
    z[3,4,5]  R1265     4.9722746014595032e-02
    z[3,4,5]  R1266     -9.0187273919582367e-02
    z[3,4,5]  R1267     0.148108571767807
    z[3,4,5]  R1268     -4.6637412905693054e-01
    z[3,4,5]  R1269     -1.2660789489746094e-01
    z[3,4,5]  R1270     -2.2432606667280197e-02
    z[3,4,5]  R1271     -3.3498124685138464e-03
    z[3,4,5]  R1272     -2.0628614723682404e-01
    z[3,4,5]  R1273     -6.0372814536094666e-02
    z[3,4,5]  R1274     -5.1319307088851929e-01
    z[3,4,5]  R1275     -1.2096808850765228e-01
    z[3,4,5]  R1276     -1.0360217653214931e-02
    z[3,4,5]  R1277     1.5313176810741425e-01
    z[3,4,6]  R35       -1
    z[3,4,6]  R44       1
    z[3,4,6]  R1150     -1
    z[3,4,6]  R1151     1
    z[3,4,6]  R1152     1.9739234447479248e-01
    z[3,4,6]  R1153     -3.0811837315559387e-01
    z[3,4,6]  R1154     -2.7268251776695251e-01
    z[3,4,6]  R1155     -9.2920534312725067e-02
    z[3,4,6]  R1156     -2.0176212489604950e-01
    z[3,4,6]  R1157     3.5325026512145996e-01
    z[3,4,6]  R1158     -3.3094260096549988e-01
    z[3,4,6]  R1159     1.6189102828502655e-01
    z[3,4,6]  R1160     3.0460205674171448e-01
    z[3,4,6]  R1161     3.9445933699607849e-01
    z[3,4,6]  R1162     -1.1341780424118042e-01
    z[3,4,6]  R1163     -4.6131104230880737e-01
    z[3,4,6]  R1164     1.1167629063129425e-01
    z[3,4,6]  R1165     2.3331305012106895e-02
    z[3,4,6]  R1166     9.6927117556333542e-03
    z[3,4,6]  R1167     7.5245589017868042e-02
    z[3,4,6]  R1168     5.4382622241973877e-01
    z[3,4,6]  R1169     -5.7883268594741821e-01
    z[3,4,6]  R1170     6.7323154211044312e-01
    z[3,4,6]  R1171     -4.6804344654083252e-01
    z[3,4,6]  R1172     6.6752098500728607e-02
    z[3,4,6]  R1173     9.5703966915607452e-02
    z[3,4,6]  R1174     -3.4824347496032715e-01
    z[3,4,6]  R1175     6.4936473965644836e-02
    z[3,4,6]  R1176     -1.2131937593221664e-01
    z[3,4,6]  R1177     1.2059555947780609e-01
    z[3,4,6]  R1178     -1.1474822461605072e-01
    z[3,4,6]  R1179     -4.6841281652450562e-01
    z[3,4,6]  R1180     1.1004430055618286e-01
    z[3,4,6]  R1181     3.4700807183980942e-02
    z[3,4,6]  R1182     -0.372715562582016
    z[3,4,6]  R1183     -1.0838195681571960e-01
    z[3,4,6]  R1184     -9.5185093581676483e-02
    z[3,4,6]  R1185     2.1241450309753418e-01
    z[3,4,6]  R1186     3.3925303816795349e-01
    z[3,4,6]  R1187     -8.8744185864925385e-02
    z[3,4,6]  R1188     5.7432585954666138e-01
    z[3,4,6]  R1189     4.3185046315193176e-01
    z[3,4,6]  R1190     -4.1304412484169006e-01
    z[3,4,6]  R1191     -6.9377802312374115e-02
    z[3,4,6]  R1192     -1.8144853413105011e-01
    z[3,4,6]  R1193     -2.8613728284835815e-01
    z[3,4,6]  R1194     0.54569011926651
    z[3,4,6]  R1195     2.0884558558464050e-01
    z[3,4,6]  R1196     6.5937139093875885e-02
    z[3,4,6]  R1197     -3.9090004563331604e-01
    z[3,4,6]  R1198     -2.1658392250537872e-01
    z[3,4,6]  R1199     2.0007678866386414e-01
    z[3,4,6]  R1200     5.7898283004760742e-01
    z[3,4,6]  R1201     -5.9164726734161377e-01
    z[3,4,6]  R1202     2.8060242533683777e-01
    z[3,4,6]  R1203     -7.3620069026947021e-01
    z[3,4,6]  R1204     3.4527981281280518e-01
    z[3,4,6]  R1205     -2.0684666931629181e-01
    z[3,4,6]  R1206     3.0820357799530029e-01
    z[3,4,6]  R1207     -0.128057062625885
    z[3,4,6]  R1208     6.4315706491470337e-01
    z[3,4,6]  R1209     1.2790703773498535e-01
    z[3,4,6]  R1210     -2.7893617749214172e-01
    z[3,4,6]  R1211     1.7463859915733337e-01
    z[3,4,6]  R1212     1.9452748820185661e-02
    z[3,4,6]  R1213     -3.7492178380489349e-02
    z[3,4,6]  R1214     -5.4711066186428070e-02
    z[3,4,6]  R1215     3.8416630029678345e-01
    z[3,4,6]  R1216     0.128541499376297
    z[3,4,6]  R1217     -1.7142567038536072e-01
    z[3,4,6]  R1218     3.5137572558596730e-04
    z[3,4,6]  R1219     -1.0635446012020111e-01
    z[3,4,6]  R1220     3.9185993373394012e-03
    z[3,4,6]  R1221     -3.9791685342788696e-01
    z[3,4,6]  R1222     1.1854583024978638e-01
    z[3,4,6]  R1223     3.4693002700805664e-01
    z[3,4,6]  R1224     2.9228290915489197e-01
    z[3,4,6]  R1225     -1.6315580904483795e-01
    z[3,4,6]  R1226     4.1230472922325134e-01
    z[3,4,6]  R1227     -3.0129143595695496e-01
    z[3,4,6]  R1228     -2.9035961627960205e-01
    z[3,4,6]  R1229     1.4775559306144714e-01
    z[3,4,6]  R1230     -2.9739844799041748e-01
    z[3,4,6]  R1231     1.8891172111034393e-01
    z[3,4,6]  R1232     -2.3863962292671204e-01
    z[3,4,6]  R1233     -1.5067948400974274e-01
    z[3,4,6]  R1234     2.7361556887626648e-01
    z[3,4,6]  R1235     -2.0225435495376587e-02
    z[3,4,6]  R1236     2.4946808815002441e-01
    z[3,4,6]  R1237     4.7203049063682556e-02
    z[3,4,6]  R1238     -4.6506536006927490e-01
    z[3,4,6]  R1239     3.3451551198959351e-01
    z[3,4,6]  R1240     -4.1838163137435913e-01
    z[3,4,6]  R1241     -2.3472876846790314e-01
    z[3,4,6]  R1242     1.0016328841447830e-01
    z[3,4,6]  R1243     1.6122755408287048e-01
    z[3,4,6]  R1244     9.5639698207378387e-02
    z[3,4,6]  R1245     -4.5434826612472534e-01
    z[3,4,6]  R1246     -3.2423120737075806e-01
    z[3,4,6]  R1247     -2.6547786593437195e-01
    z[3,4,6]  R1248     -3.2465690374374390e-01
    z[3,4,6]  R1249     2.2864004597067833e-02
    z[3,4,6]  R1250     -3.6312052607536316e-01
    z[3,4,6]  R1251     -2.0985266566276550e-01
    z[3,4,6]  R1252     -2.3246988654136658e-01
    z[3,4,6]  R1253     -1.0503920912742615e-01
    z[3,4,6]  R1254     -3.7892490625381470e-01
    z[3,4,6]  R1255     3.4058490395545959e-01
    z[3,4,6]  R1256     -1.3030645251274109e-01
    z[3,4,6]  R1257     8.6043469607830048e-02
    z[3,4,6]  R1258     4.5605826377868652e-01
    z[3,4,6]  R1259     -0.087053082883358
    z[3,4,6]  R1260     -2.8867509961128235e-01
    z[3,4,6]  R1261     3.6522147059440613e-01
    z[3,4,6]  R1262     0.0693008303642273
    z[3,4,6]  R1263     1.1321227252483368e-01
    z[3,4,6]  R1264     -1.2769292108714581e-02
    z[3,4,6]  R1265     -2.2302225232124329e-01
    z[3,4,6]  R1266     3.5758644342422485e-01
    z[3,4,6]  R1267     -4.6779972314834595e-01
    z[3,4,6]  R1268     -2.5400716066360474e-01
    z[3,4,6]  R1269     -2.3589698597788811e-02
    z[3,4,6]  R1270     4.9371778964996338e-02
    z[3,4,6]  R1271     -3.2521459460258484e-01
    z[3,4,6]  R1272     1.8636316061019897e-01
    z[3,4,6]  R1273     1.5397830307483673e-01
    z[3,4,6]  R1274     1.4918014407157898e-01
    z[3,4,6]  R1275     1.9710658490657806e-01
    z[3,4,6]  R1276     -1.4122587442398071e-01
    z[3,4,6]  R1277     0.447965532541275
    z[4,3,0]  R29       1
    z[4,3,0]  R38       -1
    z[4,3,0]  R1278     -1
    z[4,3,0]  R1279     1
    z[4,3,0]  R1292     -7.8451806306838989e-01
    z[4,3,0]  R1293     -2.3863452672958374e-01
    z[4,3,0]  R1294     -4.2138642072677612e-01
    z[4,3,0]  R1295     -2.3271121084690094e-01
    z[4,3,0]  R1296     9.3946374952793121e-02
    z[4,3,0]  R1297     -6.3066649436950684e-01
    z[4,3,0]  R1298     -2.2421675920486450e-01
    z[4,3,0]  R1299     0.221639484167099
    z[4,3,0]  R1300     2.5867444276809692e-01
    z[4,3,0]  R1301     2.9126021265983582e-01
    z[4,3,0]  R1302     3.7454894185066223e-01
    z[4,3,0]  R1303     2.7899321913719177e-01
    z[4,3,0]  R1304     3.8191944360733032e-01
    z[4,3,0]  R1305     2.9376068711280823e-01
    z[4,3,0]  R1306     -0.0978270173072815
    z[4,3,0]  R1307     -2.9137728735804558e-02
    z[4,3,0]  R1308     7.4456967413425446e-02
    z[4,3,0]  R1309     1.8401703238487244e-01
    z[4,3,0]  R1310     0.302244633436203
    z[4,3,0]  R1311     1.1519994586706161e-01
    z[4,3,0]  R1312     -3.0517500638961792e-01
    z[4,3,0]  R1313     4.6974033117294312e-01
    z[4,3,0]  R1314     4.7435140609741211e-01
    z[4,3,0]  R1315     -2.6120521128177643e-02
    z[4,3,0]  R1316     0.317367821931839
    z[4,3,0]  R1317     -1.7612075433135033e-02
    z[4,3,0]  R1318     -1.6793097555637360e-01
    z[4,3,0]  R1319     -1.0067898780107498e-01
    z[4,3,0]  R1320     -1.6538232564926147e-02
    z[4,3,0]  R1321     -1.2822266668081284e-02
    z[4,3,0]  R1322     3.6187297105789185e-01
    z[4,3,0]  R1323     2.9852783679962158e-01
    z[4,3,0]  R1324     3.7791994214057922e-01
    z[4,3,0]  R1325     -3.7840750813484192e-01
    z[4,3,0]  R1326     -2.8823024034500122e-01
    z[4,3,0]  R1327     2.5137278437614441e-01
    z[4,3,0]  R1328     3.0971741676330566e-01
    z[4,3,0]  R1329     -0.0793575644493103
    z[4,3,0]  R1330     -1.8650509417057037e-01
    z[4,3,0]  R1331     1.6907888650894165e-01
    z[4,3,0]  R1332     3.1163122504949570e-02
    z[4,3,0]  R1333     1.5796346962451935e-01
    z[4,3,0]  R1334     2.8270235657691956e-01
    z[4,3,0]  R1335     -3.6034090444445610e-03
    z[4,3,0]  R1336     -1.9155786931514740e-01
    z[4,3,0]  R1337     -1.3722683489322662e-01
    z[4,3,0]  R1338     -2.5865417718887329e-01
    z[4,3,0]  R1339     -3.6463830620050430e-02
    z[4,3,0]  R1340     7.2248607873916626e-01
    z[4,3,0]  R1341     -9.6755206584930420e-02
    z[4,3,0]  R1342     -0.223170205950737
    z[4,3,0]  R1343     -4.9366939812898636e-02
    z[4,3,0]  R1344     2.2083133459091187e-01
    z[4,3,0]  R1345     1.7553773522377014e-01
    z[4,3,0]  R1346     4.5671370625495911e-01
    z[4,3,0]  R1347     -1.8355819582939148e-01
    z[4,3,0]  R1348     -2.1551392972469330e-01
    z[4,3,0]  R1349     0.100338414311409
    z[4,3,0]  R1350     -1.9112358568236232e-03
    z[4,3,0]  R1351     -1.3800835609436035e-01
    z[4,3,0]  R1352     2.6239061355590820e-01
    z[4,3,0]  R1353     3.1615287065505981e-01
    z[4,3,0]  R1354     3.3481448888778687e-01
    z[4,3,0]  R1355     6.4860087633132935e-01
    z[4,3,0]  R1356     2.3486499488353729e-01
    z[4,3,0]  R1357     3.1915476918220520e-01
    z[4,3,0]  R1358     4.6502545475959778e-01
    z[4,3,0]  R1359     6.9791865348815918e-01
    z[4,3,0]  R1360     -2.4639932811260223e-01
    z[4,3,0]  R1361     1.2444227188825607e-01
    z[4,3,0]  R1362     0.422778844833374
    z[4,3,0]  R1363     1.8694639205932617e-01
    z[4,3,0]  R1364     0.463606595993042
    z[4,3,0]  R1365     0.695311427116394
    z[4,3,0]  R1366     7.3519617319107056e-01
    z[4,3,0]  R1367     0.730003833770752
    z[4,3,0]  R1368     -5.4624056816101074e-01
    z[4,3,0]  R1369     -0.424212247133255
    z[4,3,0]  R1370     7.1994647383689880e-02
    z[4,3,0]  R1371     -6.1272311210632324e-01
    z[4,3,0]  R1372     -6.4805978536605835e-01
    z[4,3,0]  R1373     -3.4386971592903137e-01
    z[4,3,0]  R1374     -8.9542247354984283e-02
    z[4,3,0]  R1375     1.1211939901113510e-01
    z[4,3,0]  R1376     -2.8060302138328552e-01
    z[4,3,0]  R1377     3.1735548377037048e-01
    z[4,3,0]  R1378     -6.1525338888168335e-01
    z[4,3,0]  R1379     -8.6321853101253510e-02
    z[4,3,0]  R1380     1.6740697622299194e-01
    z[4,3,0]  R1381     3.4569454193115234e-01
    z[4,3,0]  R1382     5.2569651603698730e-01
    z[4,3,0]  R1383     3.9396968483924866e-01
    z[4,3,0]  R1384     2.5449299812316895e-01
    z[4,3,0]  R1385     -6.4478024840354919e-02
    z[4,3,0]  R1386     -3.1391513347625732e-01
    z[4,3,0]  R1387     0.0785473957657814
    z[4,3,0]  R1388     -0.202298104763031
    z[4,3,0]  R1389     -3.6601746082305908e-01
    z[4,3,0]  R1390     1.3802783191204071e-01
    z[4,3,0]  R1391     -0.574720025062561
    z[4,3,0]  R1392     -1.1223085224628448e-01
    z[4,3,0]  R1393     -2.9490327835083008e-01
    z[4,3,0]  R1394     3.1449355185031891e-02
    z[4,3,0]  R1395     -2.7709737420082092e-02
    z[4,3,0]  R1396     -7.8968949615955353e-02
    z[4,3,0]  R1397     1.7646408081054688e-01
    z[4,3,0]  R1398     -1.8827441334724426e-01
    z[4,3,0]  R1399     -2.2635528445243835e-01
    z[4,3,0]  R1400     2.1855413913726807e-01
    z[4,3,0]  R1401     -4.7770336270332336e-02
    z[4,3,0]  R1402     1.0365481674671173e-01
    z[4,3,0]  R1403     -1.7878907918930054e-01
    z[4,3,0]  R1404     -4.6802438795566559e-02
    z[4,3,0]  R1405     -5.0883240997791290e-02
    z[4,3,0]  R1406     1.4553122222423553e-01
    z[4,3,0]  R1407     2.3893390595912933e-01
    z[4,3,0]  R1408     -8.7573036551475525e-02
    z[4,3,0]  R1409     3.5484347492456436e-02
    z[4,3,0]  R1410     -1.9336035475134850e-02
    z[4,3,0]  R1411     5.8665376156568527e-02
    z[4,3,0]  R1412     -3.2212796807289124e-01
    z[4,3,0]  R1413     2.3365199565887451e-01
    z[4,3,0]  R1414     -1.0389288514852524e-01
    z[4,3,0]  R1415     -4.9414080381393433e-01
    z[4,3,0]  R1416     -4.2689168453216553e-01
    z[4,3,0]  R1417     2.8846862912178040e-01
    z[4,3,1]  R30       1
    z[4,3,1]  R39       -1
    z[4,3,1]  R1280     -1
    z[4,3,1]  R1281     1
    z[4,3,1]  R1292     2.8132668137550354e-01
    z[4,3,1]  R1293     4.2940124869346619e-01
    z[4,3,1]  R1294     7.5325970537960529e-03
    z[4,3,1]  R1295     5.7901513576507568e-01
    z[4,3,1]  R1296     2.0204983651638031e-01
    z[4,3,1]  R1297     8.6046881973743439e-02
    z[4,3,1]  R1298     2.8027138113975525e-01
    z[4,3,1]  R1299     4.9292293190956116e-01
    z[4,3,1]  R1300     3.1568199396133423e-01
    z[4,3,1]  R1301     6.7493891716003418e-01
    z[4,3,1]  R1302     5.9162467718124390e-01
    z[4,3,1]  R1303     1.0954042524099350e-01
    z[4,3,1]  R1304     4.5639863610267639e-01
    z[4,3,1]  R1305     1.4886243641376495e-01
    z[4,3,1]  R1306     -7.7556276321411133e-01
    z[4,3,1]  R1307     -6.4946508407592773e-01
    z[4,3,1]  R1308     -9.1136246919631958e-01
    z[4,3,1]  R1309     -8.9713948965072632e-01
    z[4,3,1]  R1310     -5.0371998548507690e-01
    z[4,3,1]  R1311     -8.0799359083175659e-01
    z[4,3,1]  R1312     -0.572062611579895
    z[4,3,1]  R1313     -7.7519947290420532e-01
    z[4,3,1]  R1314     -0.589427649974823
    z[4,3,1]  R1315     -6.5192335844039917e-01
    z[4,3,1]  R1316     -7.6822096109390259e-01
    z[4,3,1]  R1317     -4.5647367835044861e-01
    z[4,3,1]  R1318     -4.7322675585746765e-01
    z[4,3,1]  R1319     -6.4571005105972290e-01
    z[4,3,1]  R1320     -6.9772607088088989e-01
    z[4,3,1]  R1321     -8.3203715085983276e-01
    z[4,3,1]  R1322     -5.7106351852416992e-01
    z[4,3,1]  R1323     -4.4708859920501709e-01
    z[4,3,1]  R1324     -8.0021435022354126e-01
    z[4,3,1]  R1325     -7.7876365184783936e-01
    z[4,3,1]  R1326     -7.6200026273727417e-01
    z[4,3,1]  R1327     -7.6768219470977783e-01
    z[4,3,1]  R1328     -7.3314839601516724e-01
    z[4,3,1]  R1329     7.0500272512435913e-01
    z[4,3,1]  R1330     4.0483522415161133e-01
    z[4,3,1]  R1331     -5.5599248409271240e-01
    z[4,3,1]  R1332     -6.6381967067718506e-01
    z[4,3,1]  R1333     -9.0491241216659546e-01
    z[4,3,1]  R1334     -0.619698166847229
    z[4,3,1]  R1335     -5.0538444519042969e-01
    z[4,3,1]  R1336     -8.6528658866882324e-01
    z[4,3,1]  R1337     -7.7655076980590820e-01
    z[4,3,1]  R1338     -9.0143078565597534e-01
    z[4,3,1]  R1339     -7.0040273666381836e-01
    z[4,3,1]  R1340     2.1460117772221565e-02
    z[4,3,1]  R1341     -5.5794847011566162e-01
    z[4,3,1]  R1342     -8.7596380710601807e-01
    z[4,3,1]  R1343     -9.1440171003341675e-01
    z[4,3,1]  R1344     -6.7542958259582520e-01
    z[4,3,1]  R1345     -8.2888710498809814e-01
    z[4,3,1]  R1346     -6.4825212955474854e-01
    z[4,3,1]  R1347     -7.9127651453018188e-01
    z[4,3,1]  R1348     -8.2369971275329590e-01
    z[4,3,1]  R1349     -7.7229762077331543e-01
    z[4,3,1]  R1350     -8.8891887664794922e-01
    z[4,3,1]  R1351     -8.8942545652389526e-01
    z[4,3,1]  R1352     -0.79151850938797
    z[4,3,1]  R1353     -8.1461596488952637e-01
    z[4,3,1]  R1354     -8.2109457254409790e-01
    z[4,3,1]  R1355     -1.7773827910423279e-01
    z[4,3,1]  R1356     -7.5015085935592651e-01
    z[4,3,1]  R1357     -7.3993182182312012e-01
    z[4,3,1]  R1358     1.6175159811973572e-01
    z[4,3,1]  R1359     0.035215113312006
    z[4,3,1]  R1360     -0.937619686126709
    z[4,3,1]  R1361     -8.9324432611465454e-01
    z[4,3,1]  R1362     -7.7389258146286011e-01
    z[4,3,1]  R1363     -8.1678217649459839e-01
    z[4,3,1]  R1364     -4.9182184040546417e-02
    z[4,3,1]  R1365     4.4177651405334473e-01
    z[4,3,1]  R1366     4.1015404462814331e-01
    z[4,3,1]  R1367     3.9751288294792175e-01
    z[4,3,1]  R1368     7.9328608512878418e-01
    z[4,3,1]  R1369     7.6735401153564453e-01
    z[4,3,1]  R1370     6.3840603828430176e-01
    z[4,3,1]  R1371     1.1874987185001373e-01
    z[4,3,1]  R1372     1.6845221817493439e-01
    z[4,3,1]  R1373     1.1892323940992355e-01
    z[4,3,1]  R1374     -4.9029093235731125e-02
    z[4,3,1]  R1375     -2.0932072773575783e-02
    z[4,3,1]  R1376     -5.1081206649541855e-02
    z[4,3,1]  R1377     -4.6568468213081360e-02
    z[4,3,1]  R1378     -6.5252298116683960e-01
    z[4,3,1]  R1379     -6.6241371631622314e-01
    z[4,3,1]  R1380     -6.3512933254241943e-01
    z[4,3,1]  R1381     -5.6671643257141113e-01
    z[4,3,1]  R1382     -5.8184927701950073e-01
    z[4,3,1]  R1383     -8.0940610170364380e-01
    z[4,3,1]  R1384     -5.6583595275878906e-01
    z[4,3,1]  R1385     -5.6445431709289551e-01
    z[4,3,1]  R1386     -6.2445646524429321e-01
    z[4,3,1]  R1387     -5.3245031833648682e-01
    z[4,3,1]  R1388     -7.7334809303283691e-01
    z[4,3,1]  R1389     -6.9144630432128906e-01
    z[4,3,1]  R1390     -0.743336021900177
    z[4,3,1]  R1391     -6.4037960767745972e-01
    z[4,3,1]  R1392     4.4405010342597961e-01
    z[4,3,1]  R1393     -6.9568479061126709e-01
    z[4,3,1]  R1394     0.522428035736084
    z[4,3,1]  R1395     -5.3287369012832642e-01
    z[4,3,1]  R1396     4.8844003677368164e-01
    z[4,3,1]  R1397     6.3939177989959717e-01
    z[4,3,1]  R1398     -8.4677040576934814e-01
    z[4,3,1]  R1399     -8.7058031558990479e-01
    z[4,3,1]  R1400     -8.9668089151382446e-01
    z[4,3,1]  R1401     -7.2005736827850342e-01
    z[4,3,1]  R1402     -6.7852222919464111e-01
    z[4,3,1]  R1403     0.713131844997406
    z[4,3,1]  R1404     -6.1013668775558472e-01
    z[4,3,1]  R1405     -6.1674284934997559e-01
    z[4,3,1]  R1406     6.5785801410675049e-01
    z[4,3,1]  R1407     8.5632407665252686e-01
    z[4,3,1]  R1408     6.4206200838088989e-01
    z[4,3,1]  R1409     8.7107646465301514e-01
    z[4,3,1]  R1410     -7.5011372566223145e-01
    z[4,3,1]  R1411     -8.7947982549667358e-01
    z[4,3,1]  R1412     4.7453027963638306e-01
    z[4,3,1]  R1413     -6.2827903032302856e-01
    z[4,3,1]  R1414     6.8753391504287720e-01
    z[4,3,1]  R1415     3.6887449026107788e-01
    z[4,3,1]  R1416     3.3512553572654724e-01
    z[4,3,1]  R1417     -0.559316098690033
    z[4,3,2]  R31       1
    z[4,3,2]  R40       -1
    z[4,3,2]  R1282     -1
    z[4,3,2]  R1283     1
    z[4,3,2]  R1292     1.2565425038337708e-01
    z[4,3,2]  R1293     -7.2990462183952332e-02
    z[4,3,2]  R1294     -1.2438035011291504e-01
    z[4,3,2]  R1295     -1.6645358502864838e-01
    z[4,3,2]  R1296     -9.1014020144939423e-02
    z[4,3,2]  R1297     0.626151442527771
    z[4,3,2]  R1298     -2.4900703132152557e-01
    z[4,3,2]  R1299     1.0611472278833389e-01
    z[4,3,2]  R1300     9.1054454445838928e-02
    z[4,3,2]  R1301     -1.5911756455898285e-01
    z[4,3,2]  R1302     3.1160160899162292e-01
    z[4,3,2]  R1303     -1.1797026731073856e-02
    z[4,3,2]  R1304     -2.3035086691379547e-01
    z[4,3,2]  R1305     8.2876391708850861e-02
    z[4,3,2]  R1306     -3.3033519983291626e-01
    z[4,3,2]  R1307     -4.6171391010284424e-01
    z[4,3,2]  R1308     -3.1455031037330627e-01
    z[4,3,2]  R1309     1.0135427117347717e-01
    z[4,3,2]  R1310     -4.3890568614006042e-01
    z[4,3,2]  R1311     0.136931911110878
    z[4,3,2]  R1312     -6.8476319313049316e-01
    z[4,3,2]  R1313     -9.9444175139069557e-03
    z[4,3,2]  R1314     -4.6268993616104126e-01
    z[4,3,2]  R1315     -5.4729342460632324e-01
    z[4,3,2]  R1316     2.4883045256137848e-01
    z[4,3,2]  R1317     -6.9945007562637329e-01
    z[4,3,2]  R1318     -8.0823624134063721e-01
    z[4,3,2]  R1319     -6.4133191108703613e-01
    z[4,3,2]  R1320     -1.8304759636521339e-02
    z[4,3,2]  R1321     2.4319043755531311e-01
    z[4,3,2]  R1322     -6.8353205919265747e-01
    z[4,3,2]  R1323     -7.9876106977462769e-01
    z[4,3,2]  R1324     6.4935930073261261e-02
    z[4,3,2]  R1325     2.7095427736639977e-02
    z[4,3,2]  R1326     -1.4205268025398254e-01
    z[4,3,2]  R1327     -9.6215203404426575e-02
    z[4,3,2]  R1328     -1.0724537819623947e-01
    z[4,3,2]  R1329     -1.6476549208164215e-02
    z[4,3,2]  R1330     -2.6660233736038208e-01
    z[4,3,2]  R1331     -7.3061013221740723e-01
    z[4,3,2]  R1332     -6.6492223739624023e-01
    z[4,3,2]  R1333     1.3585336506366730e-01
    z[4,3,2]  R1334     -5.5617189407348633e-01
    z[4,3,2]  R1335     -5.2972149848937988e-01
    z[4,3,2]  R1336     -1.8511453270912170e-01
    z[4,3,2]  R1337     -2.8458639979362488e-01
    z[4,3,2]  R1338     3.7137895822525024e-02
    z[4,3,2]  R1339     -6.5151625871658325e-01
    z[4,3,2]  R1340     -4.9594688415527344e-01
    z[4,3,2]  R1341     -5.4087972640991211e-01
    z[4,3,2]  R1342     -1.7047224566340446e-02
    z[4,3,2]  R1343     2.7067303657531738e-01
    z[4,3,2]  R1344     -2.6017594337463379e-01
    z[4,3,2]  R1345     3.2183980941772461e-01
    z[4,3,2]  R1346     -1.6664777696132660e-01
    z[4,3,2]  R1347     -2.0325869321823120e-02
    z[4,3,2]  R1348     1.1372482031583786e-01
    z[4,3,2]  R1349     -5.3918910026550293e-01
    z[4,3,2]  R1350     -2.1300375461578369e-01
    z[4,3,2]  R1351     1.8503311276435852e-01
    z[4,3,2]  R1352     -3.3325843513011932e-02
    z[4,3,2]  R1353     -3.8550995290279388e-02
    z[4,3,2]  R1354     2.6382654905319214e-01
    z[4,3,2]  R1355     -9.6111074090003967e-02
    z[4,3,2]  R1356     -1.9729016721248627e-01
    z[4,3,2]  R1357     1.6195631027221680e-01
    z[4,3,2]  R1358     -1.3061526417732239e-01
    z[4,3,2]  R1359     -4.5849704742431641e-01
    z[4,3,2]  R1360     5.3239818662405014e-02
    z[4,3,2]  R1361     -4.7729674726724625e-02
    z[4,3,2]  R1362     -9.9238239228725433e-02
    z[4,3,2]  R1363     -1.8111547827720642e-01
    z[4,3,2]  R1364     -9.2884004116058350e-03
    z[4,3,2]  R1365     0.0757242813706398
    z[4,3,2]  R1366     0.326010137796402
    z[4,3,2]  R1367     1.1096108704805374e-01
    z[4,3,2]  R1368     2.4101685732603073e-02
    z[4,3,2]  R1369     -1.2400750815868378e-01
    z[4,3,2]  R1370     5.2930307388305664e-01
    z[4,3,2]  R1371     5.2981162071228027e-01
    z[4,3,2]  R1372     5.2514404058456421e-01
    z[4,3,2]  R1373     3.1009066104888916e-01
    z[4,3,2]  R1374     -4.4367730617523193e-01
    z[4,3,2]  R1375     -8.0586922168731689e-01
    z[4,3,2]  R1376     -7.8454381227493286e-01
    z[4,3,2]  R1377     8.0022051930427551e-02
    z[4,3,2]  R1378     0.0970572754740715
    z[4,3,2]  R1379     0.152975931763649
    z[4,3,2]  R1380     3.4097391366958618e-01
    z[4,3,2]  R1381     -3.8507252931594849e-01
    z[4,3,2]  R1382     -6.8089894950389862e-02
    z[4,3,2]  R1383     -2.3545506596565247e-01
    z[4,3,2]  R1384     -5.0401028245687485e-02
    z[4,3,2]  R1385     8.3726853132247925e-02
    z[4,3,2]  R1386     1.0667237639427185e-01
    z[4,3,2]  R1387     -2.7492982149124146e-01
    z[4,3,2]  R1388     -4.1653178632259369e-02
    z[4,3,2]  R1389     2.7315405011177063e-01
    z[4,3,2]  R1390     1.5096355974674225e-01
    z[4,3,2]  R1391     4.1382029652595520e-01
    z[4,3,2]  R1392     5.0347495079040527e-01
    z[4,3,2]  R1393     -9.3935750424861908e-02
    z[4,3,2]  R1394     4.3033921718597412e-01
    z[4,3,2]  R1395     -4.3597763776779175e-01
    z[4,3,2]  R1396     1.1288274079561234e-01
    z[4,3,2]  R1397     6.4795380830764771e-01
    z[4,3,2]  R1398     -2.4157375097274780e-01
    z[4,3,2]  R1399     -3.2371073961257935e-02
    z[4,3,2]  R1400     0.0947737991809845
    z[4,3,2]  R1401     -2.7153888344764709e-01
    z[4,3,2]  R1402     -5.3877639770507812e-01
    z[4,3,2]  R1403     3.5098394751548767e-01
    z[4,3,2]  R1404     -2.7506032586097717e-01
    z[4,3,2]  R1405     3.3013519644737244e-01
    z[4,3,2]  R1406     3.1272286176681519e-01
    z[4,3,2]  R1407     3.6370927095413208e-01
    z[4,3,2]  R1408     4.2421030998229980e-01
    z[4,3,2]  R1409     1.8731613457202911e-01
    z[4,3,2]  R1410     2.3560628294944763e-02
    z[4,3,2]  R1411     2.8810295462608337e-01
    z[4,3,2]  R1412     1.2663708627223969e-01
    z[4,3,2]  R1413     -3.2625325024127960e-02
    z[4,3,2]  R1414     2.0188353955745697e-02
    z[4,3,2]  R1415     4.5583987236022949e-01
    z[4,3,2]  R1416     5.1397567987442017e-01
    z[4,3,2]  R1417     0.0961170494556427
    z[4,3,3]  R32       1
    z[4,3,3]  R41       -1
    z[4,3,3]  R1284     -1
    z[4,3,3]  R1285     1
    z[4,3,3]  R1292     -2.8652116656303406e-01
    z[4,3,3]  R1293     3.5964247584342957e-01
    z[4,3,3]  R1294     2.0728701353073120e-01
    z[4,3,3]  R1295     -5.2693802118301392e-01
    z[4,3,3]  R1296     -6.0815256834030151e-01
    z[4,3,3]  R1297     2.3736244067549706e-02
    z[4,3,3]  R1298     3.3163344860076904e-01
    z[4,3,3]  R1299     7.7075809240341187e-01
    z[4,3,3]  R1300     8.5122185945510864e-01
    z[4,3,3]  R1301     0.625590443611145
    z[4,3,3]  R1302     6.2528085708618164e-01
    z[4,3,3]  R1303     9.3912720680236816e-01
    z[4,3,3]  R1304     6.7131775617599487e-01
    z[4,3,3]  R1305     7.4573343992233276e-01
    z[4,3,3]  R1306     -1.6835495829582214e-01
    z[4,3,3]  R1307     -1.0739649832248688e-01
    z[4,3,3]  R1308     -2.1419250965118408e-01
    z[4,3,3]  R1309     -1.6170606017112732e-01
    z[4,3,3]  R1310     -6.2765496969223022e-01
    z[4,3,3]  R1311     3.4590315818786621e-01
    z[4,3,3]  R1312     7.9685494303703308e-02
    z[4,3,3]  R1313     1.6408908367156982e-01
    z[4,3,3]  R1314     -2.7080511674284935e-02
    z[4,3,3]  R1315     -3.9443865418434143e-01
    z[4,3,3]  R1316     2.4014189839363098e-01
    z[4,3,3]  R1317     -1.2927785515785217e-01
    z[4,3,3]  R1318     0.0540459118783474
    z[4,3,3]  R1319     7.0934325456619263e-02
    z[4,3,3]  R1320     -5.7334297895431519e-01
    z[4,3,3]  R1321     2.5984886288642883e-01
    z[4,3,3]  R1322     1.1943177878856659e-01
    z[4,3,3]  R1323     -1.2809245288372040e-01
    z[4,3,3]  R1324     9.6224442124366760e-02
    z[4,3,3]  R1325     -3.6655715107917786e-01
    z[4,3,3]  R1326     0.0673820897936821
    z[4,3,3]  R1327     4.0417218208312988e-01
    z[4,3,3]  R1328     2.4162137508392334e-01
    z[4,3,3]  R1329     3.8890153169631958e-01
    z[4,3,3]  R1330     5.7501119375228882e-01
    z[4,3,3]  R1331     -2.3392596840858459e-01
    z[4,3,3]  R1332     4.7164112329483032e-02
    z[4,3,3]  R1333     1.7356034368276596e-02
    z[4,3,3]  R1334     -4.5801591873168945e-01
    z[4,3,3]  R1335     -3.3098584413528442e-01
    z[4,3,3]  R1336     -1.4017856121063232e-01
    z[4,3,3]  R1337     -4.1113600134849548e-01
    z[4,3,3]  R1338     6.7720770835876465e-02
    z[4,3,3]  R1339     -2.7207341790199280e-01
    z[4,3,3]  R1340     2.9130643606185913e-01
    z[4,3,3]  R1341     -0.48995241522789
    z[4,3,3]  R1342     0.154449462890625
    z[4,3,3]  R1343     -2.7712401747703552e-01
    z[4,3,3]  R1344     -3.0682352185249329e-01
    z[4,3,3]  R1345     -8.2297712564468384e-02
    z[4,3,3]  R1346     -3.5729256272315979e-01
    z[4,3,3]  R1347     7.8484527766704559e-02
    z[4,3,3]  R1348     -1.7783628404140472e-01
    z[4,3,3]  R1349     -8.9961253106594086e-02
    z[4,3,3]  R1350     1.8062674999237061e-01
    z[4,3,3]  R1351     -1.3411337137222290e-01
    z[4,3,3]  R1352     -5.0566357374191284e-01
    z[4,3,3]  R1353     2.0418265461921692e-01
    z[4,3,3]  R1354     5.1924187690019608e-02
    z[4,3,3]  R1355     2.6497477293014526e-01
    z[4,3,3]  R1356     -1.2366843223571777e-01
    z[4,3,3]  R1357     -2.4484993517398834e-01
    z[4,3,3]  R1358     2.2541526705026627e-02
    z[4,3,3]  R1359     3.8468053936958313e-01
    z[4,3,3]  R1360     -2.2348362207412720e-01
    z[4,3,3]  R1361     -2.5302174687385559e-01
    z[4,3,3]  R1362     2.5384664535522461e-01
    z[4,3,3]  R1363     5.5681776255369186e-02
    z[4,3,3]  R1364     5.7787474244832993e-02
    z[4,3,3]  R1365     -2.5616058707237244e-01
    z[4,3,3]  R1366     -2.4824059009552002e-01
    z[4,3,3]  R1367     -2.2069209814071655e-01
    z[4,3,3]  R1368     1.5139020979404449e-01
    z[4,3,3]  R1369     2.9603728652000427e-01
    z[4,3,3]  R1370     1.5822613239288330e-01
    z[4,3,3]  R1371     2.4612200260162354e-01
    z[4,3,3]  R1372     1.1945197731256485e-01
    z[4,3,3]  R1373     0.0224288459867239
    z[4,3,3]  R1374     -5.5111384391784668e-01
    z[4,3,3]  R1375     4.6425831317901611e-01
    z[4,3,3]  R1376     -4.1696190834045410e-01
    z[4,3,3]  R1377     -8.2614302635192871e-01
    z[4,3,3]  R1378     -4.0400597453117371e-01
    z[4,3,3]  R1379     -0.0763794332742691
    z[4,3,3]  R1380     -2.2706650197505951e-01
    z[4,3,3]  R1381     -7.7574424445629120e-02
    z[4,3,3]  R1382     -5.6893610954284668e-01
    z[4,3,3]  R1383     -3.5073789954185486e-01
    z[4,3,3]  R1384     -1.8418912589550018e-01
    z[4,3,3]  R1385     3.3512806892395020e-01
    z[4,3,3]  R1386     1.7176859080791473e-01
    z[4,3,3]  R1387     -1.3978110253810883e-01
    z[4,3,3]  R1388     -4.3832760304212570e-02
    z[4,3,3]  R1389     0.148304283618927
    z[4,3,3]  R1390     4.6387454867362976e-01
    z[4,3,3]  R1391     2.2624848783016205e-01
    z[4,3,3]  R1392     6.2244117259979248e-01
    z[4,3,3]  R1393     4.6368911862373352e-01
    z[4,3,3]  R1394     5.2992373704910278e-01
    z[4,3,3]  R1395     -3.0490031838417053e-01
    z[4,3,3]  R1396     6.3828772306442261e-01
    z[4,3,3]  R1397     5.4679099470376968e-02
    z[4,3,3]  R1398     2.2161155939102173e-01
    z[4,3,3]  R1399     1.2202896922826767e-01
    z[4,3,3]  R1400     3.0636712908744812e-01
    z[4,3,3]  R1401     -5.1346111297607422e-01
    z[4,3,3]  R1402     -0.125356987118721
    z[4,3,3]  R1403     -1.5767522156238556e-01
    z[4,3,3]  R1404     -0.00643932493403554
    z[4,3,3]  R1405     -5.5639952421188354e-01
    z[4,3,3]  R1406     2.8882962465286255e-01
    z[4,3,3]  R1407     -1.5325054526329041e-01
    z[4,3,3]  R1408     5.3501695394515991e-01
    z[4,3,3]  R1409     2.5933426618576050e-01
    z[4,3,3]  R1410     -1.9293682649731636e-02
    z[4,3,3]  R1411     -8.1855103373527527e-02
    z[4,3,3]  R1412     7.2345834970474243e-01
    z[4,3,3]  R1413     -2.1861200034618378e-01
    z[4,3,3]  R1414     1.4545749127864838e-01
    z[4,3,3]  R1415     2.9838341474533081e-01
    z[4,3,3]  R1416     2.6166230440139771e-01
    z[4,3,3]  R1417     -4.8168757557868958e-01
    z[4,3,4]  R33       1
    z[4,3,4]  R42       -1
    z[4,3,4]  R1286     -1
    z[4,3,4]  R1287     1
    z[4,3,4]  R1292     2.0960272848606110e-01
    z[4,3,4]  R1293     -3.7107229232788086e-02
    z[4,3,4]  R1294     -7.0225065946578979e-01
    z[4,3,4]  R1295     -4.7506490349769592e-01
    z[4,3,4]  R1296     -3.6551004648208618e-01
    z[4,3,4]  R1297     -4.3038591742515564e-01
    z[4,3,4]  R1298     4.4329786300659180e-01
    z[4,3,4]  R1299     -5.3792528808116913e-02
    z[4,3,4]  R1300     -4.5282721519470215e-02
    z[4,3,4]  R1301     6.5043777227401733e-02
    z[4,3,4]  R1302     1.4205466210842133e-01
    z[4,3,4]  R1303     8.2762479782104492e-02
    z[4,3,4]  R1304     1.7623870074748993e-01
    z[4,3,4]  R1305     3.9861190319061279e-01
    z[4,3,4]  R1306     -2.0020754635334015e-01
    z[4,3,4]  R1307     -1.9458557665348053e-01
    z[4,3,4]  R1308     -8.5982456803321838e-02
    z[4,3,4]  R1309     1.6359147429466248e-01
    z[4,3,4]  R1310     1.9855398684740067e-02
    z[4,3,4]  R1311     0.178420752286911
    z[4,3,4]  R1312     2.1477924287319183e-01
    z[4,3,4]  R1313     -1.5897114574909210e-01
    z[4,3,4]  R1314     2.6159333065152168e-02
    z[4,3,4]  R1315     1.6524660587310791e-01
    z[4,3,4]  R1316     0.0753258541226387
    z[4,3,4]  R1317     3.3169826865196228e-01
    z[4,3,4]  R1318     0.0411791168153286
    z[4,3,4]  R1319     2.2157919406890869e-01
    z[4,3,4]  R1320     -4.7878913581371307e-02
    z[4,3,4]  R1321     3.7933662533760071e-01
    z[4,3,4]  R1322     -1.9451610743999481e-02
    z[4,3,4]  R1323     1.8401028215885162e-01
    z[4,3,4]  R1324     2.4931050837039948e-01
    z[4,3,4]  R1325     9.7140751779079437e-02
    z[4,3,4]  R1326     4.1627818346023560e-01
    z[4,3,4]  R1327     3.2874977588653564e-01
    z[4,3,4]  R1328     -2.6751694083213806e-01
    z[4,3,4]  R1329     4.1147032380104065e-01
    z[4,3,4]  R1330     4.1332921385765076e-01
    z[4,3,4]  R1331     4.8051834106445312e-02
    z[4,3,4]  R1332     1.0222673416137695e-01
    z[4,3,4]  R1333     -2.2699016332626343e-01
    z[4,3,4]  R1334     6.3473515212535858e-02
    z[4,3,4]  R1335     8.2612454891204834e-02
    z[4,3,4]  R1336     -2.8288796544075012e-02
    z[4,3,4]  R1337     7.2491921484470367e-02
    z[4,3,4]  R1338     9.1149166226387024e-02
    z[4,3,4]  R1339     -7.5300313532352448e-02
    z[4,3,4]  R1340     1.7393555492162704e-02
    z[4,3,4]  R1341     8.6900874972343445e-02
    z[4,3,4]  R1342     -1.9447323679924011e-01
    z[4,3,4]  R1343     1.8232997506856918e-02
    z[4,3,4]  R1344     -3.6176049709320068e-01
    z[4,3,4]  R1345     2.2238619625568390e-01
    z[4,3,4]  R1346     -9.1401286423206329e-02
    z[4,3,4]  R1347     3.6532336473464966e-01
    z[4,3,4]  R1348     1.1237250268459320e-01
    z[4,3,4]  R1349     1.1224296689033508e-01
    z[4,3,4]  R1350     7.5787985697388649e-03
    z[4,3,4]  R1351     6.4320690929889679e-02
    z[4,3,4]  R1352     -1.3239432871341705e-01
    z[4,3,4]  R1353     2.5776756927371025e-02
    z[4,3,4]  R1354     3.5215219855308533e-01
    z[4,3,4]  R1355     6.4503157138824463e-01
    z[4,3,4]  R1356     4.3805581331253052e-01
    z[4,3,4]  R1357     -1.5390609204769135e-01
    z[4,3,4]  R1358     6.7675316333770752e-01
    z[4,3,4]  R1359     -3.6997926235198975e-01
    z[4,3,4]  R1360     -6.6607259213924408e-02
    z[4,3,4]  R1361     1.2064320594072342e-01
    z[4,3,4]  R1362     2.6603901386260986e-01
    z[4,3,4]  R1363     4.8441749811172485e-01
    z[4,3,4]  R1364     7.0256847143173218e-01
    z[4,3,4]  R1365     4.4332712888717651e-01
    z[4,3,4]  R1366     3.2140663266181946e-01
    z[4,3,4]  R1367     1.5471938252449036e-01
    z[4,3,4]  R1368     -9.9260888993740082e-02
    z[4,3,4]  R1369     -1.8220679461956024e-01
    z[4,3,4]  R1370     1.9566479325294495e-01
    z[4,3,4]  R1371     -4.1278502345085144e-01
    z[4,3,4]  R1372     1.5285915136337280e-01
    z[4,3,4]  R1373     2.2578676044940948e-01
    z[4,3,4]  R1374     -6.1166834831237793e-01
    z[4,3,4]  R1375     6.0078907757997513e-02
    z[4,3,4]  R1376     -1.0044468194246292e-01
    z[4,3,4]  R1377     1.9026717543601990e-01
    z[4,3,4]  R1378     -0.0942695364356041
    z[4,3,4]  R1379     -0.530070424079895
    z[4,3,4]  R1380     0.572259247303009
    z[4,3,4]  R1381     0.281680703163147
    z[4,3,4]  R1382     4.8072297126054764e-02
    z[4,3,4]  R1383     1.2790170498192310e-02
    z[4,3,4]  R1384     5.2944332361221313e-01
    z[4,3,4]  R1385     5.0449732691049576e-02
    z[4,3,4]  R1386     1.2470442801713943e-01
    z[4,3,4]  R1387     -5.2881163358688354e-01
    z[4,3,4]  R1388     -6.7869938910007477e-02
    z[4,3,4]  R1389     0.330610454082489
    z[4,3,4]  R1390     -8.7898708879947662e-02
    z[4,3,4]  R1391     1.6543485224246979e-01
    z[4,3,4]  R1392     3.1123638153076172e-01
    z[4,3,4]  R1393     -1.7848348617553711e-01
    z[4,3,4]  R1394     1.1690960079431534e-01
    z[4,3,4]  R1395     1.5920451283454895e-01
    z[4,3,4]  R1396     3.0334630608558655e-01
    z[4,3,4]  R1397     0.0460958406329155
    z[4,3,4]  R1398     2.8051629662513733e-02
    z[4,3,4]  R1399     -2.2514438629150391e-01
    z[4,3,4]  R1400     4.8451088368892670e-02
    z[4,3,4]  R1401     -2.8541529178619385e-01
    z[4,3,4]  R1402     2.3641730844974518e-01
    z[4,3,4]  R1403     -4.1492116451263428e-01
    z[4,3,4]  R1404     3.7780386209487915e-01
    z[4,3,4]  R1405     3.3900007605552673e-02
    z[4,3,4]  R1406     -5.9458520263433456e-02
    z[4,3,4]  R1407     2.0541921257972717e-01
    z[4,3,4]  R1408     9.1188631951808929e-02
    z[4,3,4]  R1409     7.1426816284656525e-02
    z[4,3,4]  R1410     -1.2145414017140865e-02
    z[4,3,4]  R1411     -2.1761940419673920e-01
    z[4,3,4]  R1412     1.8333357572555542e-01
    z[4,3,4]  R1413     1.2594452500343323e-01
    z[4,3,4]  R1414     2.7962759137153625e-01
    z[4,3,4]  R1415     5.1990884542465210e-01
    z[4,3,4]  R1416     1.6360929608345032e-01
    z[4,3,4]  R1417     9.3086190521717072e-02
    z[4,3,5]  R34       1
    z[4,3,5]  R43       -1
    z[4,3,5]  R1288     -1
    z[4,3,5]  R1289     1
    z[4,3,5]  R1292     -2.9125988483428955e-01
    z[4,3,5]  R1293     2.8395307064056396e-01
    z[4,3,5]  R1294     3.8931244611740112e-01
    z[4,3,5]  R1295     -1.9168801605701447e-01
    z[4,3,5]  R1296     5.8619940280914307e-01
    z[4,3,5]  R1297     -2.4412751197814941e-02
    z[4,3,5]  R1298     -2.9837164282798767e-01
    z[4,3,5]  R1299     -2.8865331411361694e-01
    z[4,3,5]  R1300     1.4389933645725250e-01
    z[4,3,5]  R1301     -9.0629987418651581e-02
    z[4,3,5]  R1302     -3.2613296061754227e-02
    z[4,3,5]  R1303     -1.4074572920799255e-01
    z[4,3,5]  R1304     3.2871791720390320e-01
    z[4,3,5]  R1305     1.4860203862190247e-01
    z[4,3,5]  R1306     -4.4143116474151611e-01
    z[4,3,5]  R1307     -5.3421151638031006e-01
    z[4,3,5]  R1308     1.0798743367195129e-01
    z[4,3,5]  R1309     -2.9459038376808167e-01
    z[4,3,5]  R1310     -2.6060670614242554e-01
    z[4,3,5]  R1311     -7.2829827666282654e-02
    z[4,3,5]  R1312     -2.1018789708614349e-01
    z[4,3,5]  R1313     7.5851596891880035e-02
    z[4,3,5]  R1314     -3.5586071014404297e-01
    z[4,3,5]  R1315     -2.5549063086509705e-01
    z[4,3,5]  R1316     1.1772985756397247e-01
    z[4,3,5]  R1317     -2.9082307219505310e-01
    z[4,3,5]  R1318     -7.5395785272121429e-02
    z[4,3,5]  R1319     -2.9266867041587830e-01
    z[4,3,5]  R1320     -3.0513831973075867e-01
    z[4,3,5]  R1321     3.6092754453420639e-02
    z[4,3,5]  R1322     -0.0642428919672966
    z[4,3,5]  R1323     -1.3352457899600267e-03
    z[4,3,5]  R1324     2.5755900144577026e-01
    z[4,3,5]  R1325     -3.2464000582695007e-01
    z[4,3,5]  R1326     -0.275749534368515
    z[4,3,5]  R1327     2.5408431887626648e-01
    z[4,3,5]  R1328     -0.0939953550696373
    z[4,3,5]  R1329     -2.5288176536560059e-01
    z[4,3,5]  R1330     -2.3178742825984955e-01
    z[4,3,5]  R1331     -0.127928227186203
    z[4,3,5]  R1332     -3.0584850907325745e-01
    z[4,3,5]  R1333     -2.4475468695163727e-01
    z[4,3,5]  R1334     -6.1415430158376694e-02
    z[4,3,5]  R1335     -3.7571245431900024e-01
    z[4,3,5]  R1336     -2.3396830260753632e-01
    z[4,3,5]  R1337     -2.2887107729911804e-01
    z[4,3,5]  R1338     -2.9069520533084869e-02
    z[4,3,5]  R1339     -0.0584476999938488
    z[4,3,5]  R1340     -1.2071265280246735e-01
    z[4,3,5]  R1341     -3.0844411253929138e-01
    z[4,3,5]  R1342     -2.5860235095024109e-01
    z[4,3,5]  R1343     -2.2496019955724478e-03
    z[4,3,5]  R1344     -2.4236641824245453e-01
    z[4,3,5]  R1345     7.9531274735927582e-02
    z[4,3,5]  R1346     -4.3636941909790039e-01
    z[4,3,5]  R1347     -4.3903324007987976e-01
    z[4,3,5]  R1348     -9.9482253193855286e-02
    z[4,3,5]  R1349     -2.7293553948402405e-01
    z[4,3,5]  R1350     2.2007305920124054e-01
    z[4,3,5]  R1351     1.1336227878928185e-02
    z[4,3,5]  R1352     -1.5972651541233063e-01
    z[4,3,5]  R1353     4.2401656508445740e-01
    z[4,3,5]  R1354     1.3125570118427277e-01
    z[4,3,5]  R1355     4.9722746014595032e-02
    z[4,3,5]  R1356     -9.0187273919582367e-02
    z[4,3,5]  R1357     0.148108571767807
    z[4,3,5]  R1358     -4.6637412905693054e-01
    z[4,3,5]  R1359     -1.2660789489746094e-01
    z[4,3,5]  R1360     -2.2432606667280197e-02
    z[4,3,5]  R1361     -3.3498124685138464e-03
    z[4,3,5]  R1362     -2.0628614723682404e-01
    z[4,3,5]  R1363     -6.0372814536094666e-02
    z[4,3,5]  R1364     -5.1319307088851929e-01
    z[4,3,5]  R1365     -1.2096808850765228e-01
    z[4,3,5]  R1366     -1.0360217653214931e-02
    z[4,3,5]  R1367     1.5313176810741425e-01
    z[4,3,5]  R1368     -1.4690301613882184e-03
    z[4,3,5]  R1369     7.7183679677546024e-03
    z[4,3,5]  R1370     0.411602646112442
    z[4,3,5]  R1371     3.0027794837951660e-01
    z[4,3,5]  R1372     4.4443616271018982e-01
    z[4,3,5]  R1373     7.7148318290710449e-01
    z[4,3,5]  R1374     -7.3083013296127319e-02
    z[4,3,5]  R1375     3.0366408824920654e-01
    z[4,3,5]  R1376     1.6252642869949341e-01
    z[4,3,5]  R1377     1.2806795537471771e-01
    z[4,3,5]  R1378     -3.5857267677783966e-02
    z[4,3,5]  R1379     0.175323948264122
    z[4,3,5]  R1380     2.4659889936447144e-01
    z[4,3,5]  R1381     -5.7021111249923706e-01
    z[4,3,5]  R1382     -2.3316358029842377e-01
    z[4,3,5]  R1383     -7.3266260325908661e-02
    z[4,3,5]  R1384     5.0397776067256927e-02
    z[4,3,5]  R1385     4.6938300132751465e-01
    z[4,3,5]  R1386     4.2848322540521622e-02
    z[4,3,5]  R1387     -3.4131422638893127e-01
    z[4,3,5]  R1388     5.9016084671020508e-01
    z[4,3,5]  R1389     -4.1576853394508362e-01
    z[4,3,5]  R1390     -2.4785226583480835e-01
    z[4,3,5]  R1391     7.4764534831047058e-02
    z[4,3,5]  R1392     1.9420921802520752e-01
    z[4,3,5]  R1393     -3.9852684736251831e-01
    z[4,3,5]  R1394     -4.8294299840927124e-01
    z[4,3,5]  R1395     4.3299004435539246e-01
    z[4,3,5]  R1396     -4.8052871227264404e-01
    z[4,3,5]  R1397     -3.6589032411575317e-01
    z[4,3,5]  R1398     1.8955765292048454e-02
    z[4,3,5]  R1399     3.3537667989730835e-01
    z[4,3,5]  R1400     -1.8424670398235321e-01
    z[4,3,5]  R1401     -1.2360414117574692e-01
    z[4,3,5]  R1402     -2.2777855396270752e-01
    z[4,3,5]  R1403     -3.6247935891151428e-01
    z[4,3,5]  R1404     2.7795165777206421e-01
    z[4,3,5]  R1405     -1.0404511541128159e-01
    z[4,3,5]  R1406     -4.3667447566986084e-01
    z[4,3,5]  R1407     8.2699991762638092e-02
    z[4,3,5]  R1408     -2.6953813433647156e-01
    z[4,3,5]  R1409     -2.2505274415016174e-01
    z[4,3,5]  R1410     -3.7162205576896667e-01
    z[4,3,5]  R1411     -2.0590139925479889e-01
    z[4,3,5]  R1412     -3.0605033040046692e-01
    z[4,3,5]  R1413     -0.577193021774292
    z[4,3,5]  R1414     6.0814291238784790e-01
    z[4,3,5]  R1415     -1.1223967373371124e-01
    z[4,3,5]  R1416     1.0405306518077850e-01
    z[4,3,5]  R1417     -6.3074208796024323e-02
    z[4,3,6]  R35       1
    z[4,3,6]  R44       -1
    z[4,3,6]  R1290     -1
    z[4,3,6]  R1291     1
    z[4,3,6]  R1292     2.8060242533683777e-01
    z[4,3,6]  R1293     -7.3620069026947021e-01
    z[4,3,6]  R1294     3.4527981281280518e-01
    z[4,3,6]  R1295     -2.0684666931629181e-01
    z[4,3,6]  R1296     3.0820357799530029e-01
    z[4,3,6]  R1297     -0.128057062625885
    z[4,3,6]  R1298     6.4315706491470337e-01
    z[4,3,6]  R1299     1.2790703773498535e-01
    z[4,3,6]  R1300     -2.7893617749214172e-01
    z[4,3,6]  R1301     1.7463859915733337e-01
    z[4,3,6]  R1302     1.9452748820185661e-02
    z[4,3,6]  R1303     -3.7492178380489349e-02
    z[4,3,6]  R1304     -5.4711066186428070e-02
    z[4,3,6]  R1305     3.8416630029678345e-01
    z[4,3,6]  R1306     0.128541499376297
    z[4,3,6]  R1307     -1.7142567038536072e-01
    z[4,3,6]  R1308     3.5137572558596730e-04
    z[4,3,6]  R1309     -1.0635446012020111e-01
    z[4,3,6]  R1310     3.9185993373394012e-03
    z[4,3,6]  R1311     -3.9791685342788696e-01
    z[4,3,6]  R1312     1.1854583024978638e-01
    z[4,3,6]  R1313     3.4693002700805664e-01
    z[4,3,6]  R1314     2.9228290915489197e-01
    z[4,3,6]  R1315     -1.6315580904483795e-01
    z[4,3,6]  R1316     4.1230472922325134e-01
    z[4,3,6]  R1317     -3.0129143595695496e-01
    z[4,3,6]  R1318     -2.9035961627960205e-01
    z[4,3,6]  R1319     1.4775559306144714e-01
    z[4,3,6]  R1320     -2.9739844799041748e-01
    z[4,3,6]  R1321     1.8891172111034393e-01
    z[4,3,6]  R1322     -2.3863962292671204e-01
    z[4,3,6]  R1323     -1.5067948400974274e-01
    z[4,3,6]  R1324     2.7361556887626648e-01
    z[4,3,6]  R1325     -2.0225435495376587e-02
    z[4,3,6]  R1326     2.4946808815002441e-01
    z[4,3,6]  R1327     4.7203049063682556e-02
    z[4,3,6]  R1328     -4.6506536006927490e-01
    z[4,3,6]  R1329     3.3451551198959351e-01
    z[4,3,6]  R1330     -4.1838163137435913e-01
    z[4,3,6]  R1331     -2.3472876846790314e-01
    z[4,3,6]  R1332     1.0016328841447830e-01
    z[4,3,6]  R1333     1.6122755408287048e-01
    z[4,3,6]  R1334     9.5639698207378387e-02
    z[4,3,6]  R1335     -4.5434826612472534e-01
    z[4,3,6]  R1336     -3.2423120737075806e-01
    z[4,3,6]  R1337     -2.6547786593437195e-01
    z[4,3,6]  R1338     -3.2465690374374390e-01
    z[4,3,6]  R1339     2.2864004597067833e-02
    z[4,3,6]  R1340     -3.6312052607536316e-01
    z[4,3,6]  R1341     -2.0985266566276550e-01
    z[4,3,6]  R1342     -2.3246988654136658e-01
    z[4,3,6]  R1343     -1.0503920912742615e-01
    z[4,3,6]  R1344     -3.7892490625381470e-01
    z[4,3,6]  R1345     3.4058490395545959e-01
    z[4,3,6]  R1346     -1.3030645251274109e-01
    z[4,3,6]  R1347     8.6043469607830048e-02
    z[4,3,6]  R1348     4.5605826377868652e-01
    z[4,3,6]  R1349     -0.087053082883358
    z[4,3,6]  R1350     -2.8867509961128235e-01
    z[4,3,6]  R1351     3.6522147059440613e-01
    z[4,3,6]  R1352     0.0693008303642273
    z[4,3,6]  R1353     1.1321227252483368e-01
    z[4,3,6]  R1354     -1.2769292108714581e-02
    z[4,3,6]  R1355     -2.2302225232124329e-01
    z[4,3,6]  R1356     3.5758644342422485e-01
    z[4,3,6]  R1357     -4.6779972314834595e-01
    z[4,3,6]  R1358     -2.5400716066360474e-01
    z[4,3,6]  R1359     -2.3589698597788811e-02
    z[4,3,6]  R1360     4.9371778964996338e-02
    z[4,3,6]  R1361     -3.2521459460258484e-01
    z[4,3,6]  R1362     1.8636316061019897e-01
    z[4,3,6]  R1363     1.5397830307483673e-01
    z[4,3,6]  R1364     1.4918014407157898e-01
    z[4,3,6]  R1365     1.9710658490657806e-01
    z[4,3,6]  R1366     -1.4122587442398071e-01
    z[4,3,6]  R1367     0.447965532541275
    z[4,3,6]  R1368     1.9739234447479248e-01
    z[4,3,6]  R1369     -3.0811837315559387e-01
    z[4,3,6]  R1370     -2.7268251776695251e-01
    z[4,3,6]  R1371     -9.2920534312725067e-02
    z[4,3,6]  R1372     -2.0176212489604950e-01
    z[4,3,6]  R1373     3.5325026512145996e-01
    z[4,3,6]  R1374     -3.3094260096549988e-01
    z[4,3,6]  R1375     1.6189102828502655e-01
    z[4,3,6]  R1376     3.0460205674171448e-01
    z[4,3,6]  R1377     3.9445933699607849e-01
    z[4,3,6]  R1378     -1.1341780424118042e-01
    z[4,3,6]  R1379     -4.6131104230880737e-01
    z[4,3,6]  R1380     1.1167629063129425e-01
    z[4,3,6]  R1381     2.3331305012106895e-02
    z[4,3,6]  R1382     9.6927117556333542e-03
    z[4,3,6]  R1383     7.5245589017868042e-02
    z[4,3,6]  R1384     5.4382622241973877e-01
    z[4,3,6]  R1385     -5.7883268594741821e-01
    z[4,3,6]  R1386     6.7323154211044312e-01
    z[4,3,6]  R1387     -4.6804344654083252e-01
    z[4,3,6]  R1388     6.6752098500728607e-02
    z[4,3,6]  R1389     9.5703966915607452e-02
    z[4,3,6]  R1390     -3.4824347496032715e-01
    z[4,3,6]  R1391     6.4936473965644836e-02
    z[4,3,6]  R1392     -1.2131937593221664e-01
    z[4,3,6]  R1393     1.2059555947780609e-01
    z[4,3,6]  R1394     -1.1474822461605072e-01
    z[4,3,6]  R1395     -4.6841281652450562e-01
    z[4,3,6]  R1396     1.1004430055618286e-01
    z[4,3,6]  R1397     3.4700807183980942e-02
    z[4,3,6]  R1398     -0.372715562582016
    z[4,3,6]  R1399     -1.0838195681571960e-01
    z[4,3,6]  R1400     -9.5185093581676483e-02
    z[4,3,6]  R1401     2.1241450309753418e-01
    z[4,3,6]  R1402     3.3925303816795349e-01
    z[4,3,6]  R1403     -8.8744185864925385e-02
    z[4,3,6]  R1404     5.7432585954666138e-01
    z[4,3,6]  R1405     4.3185046315193176e-01
    z[4,3,6]  R1406     -4.1304412484169006e-01
    z[4,3,6]  R1407     -6.9377802312374115e-02
    z[4,3,6]  R1408     -1.8144853413105011e-01
    z[4,3,6]  R1409     -2.8613728284835815e-01
    z[4,3,6]  R1410     0.54569011926651
    z[4,3,6]  R1411     2.0884558558464050e-01
    z[4,3,6]  R1412     6.5937139093875885e-02
    z[4,3,6]  R1413     -3.9090004563331604e-01
    z[4,3,6]  R1414     -2.1658392250537872e-01
    z[4,3,6]  R1415     2.0007678866386414e-01
    z[4,3,6]  R1416     5.7898283004760742e-01
    z[4,3,6]  R1417     -5.9164726734161377e-01
    z[4,9,0]  R38       -1
    z[4,9,0]  R83       1
    z[4,9,0]  R1418     -1
    z[4,9,0]  R1419     1
    z[4,9,0]  R1432     -7.8451806306838989e-01
    z[4,9,0]  R1433     -2.3863452672958374e-01
    z[4,9,0]  R1434     -4.2138642072677612e-01
    z[4,9,0]  R1435     -2.3271121084690094e-01
    z[4,9,0]  R1436     9.3946374952793121e-02
    z[4,9,0]  R1437     -6.3066649436950684e-01
    z[4,9,0]  R1438     -2.2421675920486450e-01
    z[4,9,0]  R1439     0.221639484167099
    z[4,9,0]  R1440     2.5867444276809692e-01
    z[4,9,0]  R1441     2.9126021265983582e-01
    z[4,9,0]  R1442     3.7454894185066223e-01
    z[4,9,0]  R1443     2.7899321913719177e-01
    z[4,9,0]  R1444     3.8191944360733032e-01
    z[4,9,0]  R1445     2.9376068711280823e-01
    z[4,9,0]  R1446     -0.0978270173072815
    z[4,9,0]  R1447     -2.9137728735804558e-02
    z[4,9,0]  R1448     7.4456967413425446e-02
    z[4,9,0]  R1449     1.8401703238487244e-01
    z[4,9,0]  R1450     0.302244633436203
    z[4,9,0]  R1451     1.1519994586706161e-01
    z[4,9,0]  R1452     -3.0517500638961792e-01
    z[4,9,0]  R1453     4.6974033117294312e-01
    z[4,9,0]  R1454     4.7435140609741211e-01
    z[4,9,0]  R1455     -2.6120521128177643e-02
    z[4,9,0]  R1456     0.317367821931839
    z[4,9,0]  R1457     -1.7612075433135033e-02
    z[4,9,0]  R1458     -1.6793097555637360e-01
    z[4,9,0]  R1459     -1.0067898780107498e-01
    z[4,9,0]  R1460     -1.6538232564926147e-02
    z[4,9,0]  R1461     -1.2822266668081284e-02
    z[4,9,0]  R1462     3.6187297105789185e-01
    z[4,9,0]  R1463     2.9852783679962158e-01
    z[4,9,0]  R1464     3.7791994214057922e-01
    z[4,9,0]  R1465     -3.7840750813484192e-01
    z[4,9,0]  R1466     -2.8823024034500122e-01
    z[4,9,0]  R1467     2.5137278437614441e-01
    z[4,9,0]  R1468     3.0971741676330566e-01
    z[4,9,0]  R1469     -0.0793575644493103
    z[4,9,0]  R1470     -1.8650509417057037e-01
    z[4,9,0]  R1471     1.6907888650894165e-01
    z[4,9,0]  R1472     3.1163122504949570e-02
    z[4,9,0]  R1473     1.5796346962451935e-01
    z[4,9,0]  R1474     2.8270235657691956e-01
    z[4,9,0]  R1475     -3.6034090444445610e-03
    z[4,9,0]  R1476     -1.9155786931514740e-01
    z[4,9,0]  R1477     -1.3722683489322662e-01
    z[4,9,0]  R1478     -2.5865417718887329e-01
    z[4,9,0]  R1479     -3.6463830620050430e-02
    z[4,9,0]  R1480     7.2248607873916626e-01
    z[4,9,0]  R1481     -9.6755206584930420e-02
    z[4,9,0]  R1482     -0.223170205950737
    z[4,9,0]  R1483     -4.9366939812898636e-02
    z[4,9,0]  R1484     2.2083133459091187e-01
    z[4,9,0]  R1485     1.7553773522377014e-01
    z[4,9,0]  R1486     4.5671370625495911e-01
    z[4,9,0]  R1487     -1.8355819582939148e-01
    z[4,9,0]  R1488     -2.1551392972469330e-01
    z[4,9,0]  R1489     0.100338414311409
    z[4,9,0]  R1490     -1.9112358568236232e-03
    z[4,9,0]  R1491     -1.3800835609436035e-01
    z[4,9,0]  R1492     2.6239061355590820e-01
    z[4,9,0]  R1493     3.1615287065505981e-01
    z[4,9,0]  R1494     3.3481448888778687e-01
    z[4,9,0]  R1495     6.4860087633132935e-01
    z[4,9,0]  R1496     2.3486499488353729e-01
    z[4,9,0]  R1497     3.1915476918220520e-01
    z[4,9,0]  R1498     4.6502545475959778e-01
    z[4,9,0]  R1499     6.9791865348815918e-01
    z[4,9,0]  R1500     -2.4639932811260223e-01
    z[4,9,0]  R1501     1.2444227188825607e-01
    z[4,9,0]  R1502     0.422778844833374
    z[4,9,0]  R1503     1.8694639205932617e-01
    z[4,9,0]  R1504     0.463606595993042
    z[4,9,0]  R1505     0.695311427116394
    z[4,9,0]  R1506     7.3519617319107056e-01
    z[4,9,0]  R1507     0.730003833770752
    z[4,9,0]  R1508     -1.1683891713619232e-01
    z[4,9,0]  R1509     -7.2481578588485718e-01
    z[4,9,0]  R1510     -7.7795642614364624e-01
    z[4,9,0]  R1511     -4.9626111984252930e-02
    z[4,9,0]  R1512     5.6205615401268005e-02
    z[4,9,0]  R1513     2.8992640972137451e-01
    z[4,9,0]  R1514     2.4261078238487244e-01
    z[4,9,0]  R1515     9.8038287833333015e-03
    z[4,9,0]  R1516     0.440586119890213
    z[4,9,0]  R1517     5.4980188608169556e-01
    z[4,9,0]  R1518     9.0830363333225250e-02
    z[4,9,0]  R1519     4.7096928954124451e-01
    z[4,9,0]  R1520     2.6634064316749573e-01
    z[4,9,0]  R1521     8.6104303598403931e-02
    z[4,9,0]  R1522     3.6794704198837280e-01
    z[4,9,0]  R1523     -1.6276559233665466e-01
    z[4,9,0]  R1524     -1.7888191342353821e-01
    z[4,9,0]  R1525     4.6682957559823990e-02
    z[4,9,0]  R1526     1.5970674157142639e-01
    z[4,9,0]  R1527     -6.7939713597297668e-02
    z[4,9,0]  R1528     -0.0341838039457798
    z[4,9,0]  R1529     2.9439744353294373e-01
    z[4,9,0]  R1530     -1.9379843771457672e-01
    z[4,9,0]  R1531     2.5401732325553894e-01
    z[4,9,0]  R1532     -6.9402478635311127e-02
    z[4,9,0]  R1533     7.1375928819179535e-02
    z[4,9,0]  R1534     1.3114073872566223e-01
    z[4,9,0]  R1535     1.0505028814077377e-01
    z[4,9,0]  R1536     -1.5803864598274231e-01
    z[4,9,0]  R1537     -1.6549913585186005e-01
    z[4,9,0]  R1538     3.6452811956405640e-01
    z[4,9,0]  R1539     -5.6082367897033691e-02
    z[4,9,0]  R1540     3.6245340108871460e-01
    z[4,9,0]  R1541     1.3113540597259998e-02
    z[4,9,1]  R39       -1
    z[4,9,1]  R84       1
    z[4,9,1]  R1420     -1
    z[4,9,1]  R1421     1
    z[4,9,1]  R1432     2.8132668137550354e-01
    z[4,9,1]  R1433     4.2940124869346619e-01
    z[4,9,1]  R1434     7.5325970537960529e-03
    z[4,9,1]  R1435     5.7901513576507568e-01
    z[4,9,1]  R1436     2.0204983651638031e-01
    z[4,9,1]  R1437     8.6046881973743439e-02
    z[4,9,1]  R1438     2.8027138113975525e-01
    z[4,9,1]  R1439     4.9292293190956116e-01
    z[4,9,1]  R1440     3.1568199396133423e-01
    z[4,9,1]  R1441     6.7493891716003418e-01
    z[4,9,1]  R1442     5.9162467718124390e-01
    z[4,9,1]  R1443     1.0954042524099350e-01
    z[4,9,1]  R1444     4.5639863610267639e-01
    z[4,9,1]  R1445     1.4886243641376495e-01
    z[4,9,1]  R1446     -7.7556276321411133e-01
    z[4,9,1]  R1447     -6.4946508407592773e-01
    z[4,9,1]  R1448     -9.1136246919631958e-01
    z[4,9,1]  R1449     -8.9713948965072632e-01
    z[4,9,1]  R1450     -5.0371998548507690e-01
    z[4,9,1]  R1451     -8.0799359083175659e-01
    z[4,9,1]  R1452     -0.572062611579895
    z[4,9,1]  R1453     -7.7519947290420532e-01
    z[4,9,1]  R1454     -0.589427649974823
    z[4,9,1]  R1455     -6.5192335844039917e-01
    z[4,9,1]  R1456     -7.6822096109390259e-01
    z[4,9,1]  R1457     -4.5647367835044861e-01
    z[4,9,1]  R1458     -4.7322675585746765e-01
    z[4,9,1]  R1459     -6.4571005105972290e-01
    z[4,9,1]  R1460     -6.9772607088088989e-01
    z[4,9,1]  R1461     -8.3203715085983276e-01
    z[4,9,1]  R1462     -5.7106351852416992e-01
    z[4,9,1]  R1463     -4.4708859920501709e-01
    z[4,9,1]  R1464     -8.0021435022354126e-01
    z[4,9,1]  R1465     -7.7876365184783936e-01
    z[4,9,1]  R1466     -7.6200026273727417e-01
    z[4,9,1]  R1467     -7.6768219470977783e-01
    z[4,9,1]  R1468     -7.3314839601516724e-01
    z[4,9,1]  R1469     7.0500272512435913e-01
    z[4,9,1]  R1470     4.0483522415161133e-01
    z[4,9,1]  R1471     -5.5599248409271240e-01
    z[4,9,1]  R1472     -6.6381967067718506e-01
    z[4,9,1]  R1473     -9.0491241216659546e-01
    z[4,9,1]  R1474     -0.619698166847229
    z[4,9,1]  R1475     -5.0538444519042969e-01
    z[4,9,1]  R1476     -8.6528658866882324e-01
    z[4,9,1]  R1477     -7.7655076980590820e-01
    z[4,9,1]  R1478     -9.0143078565597534e-01
    z[4,9,1]  R1479     -7.0040273666381836e-01
    z[4,9,1]  R1480     2.1460117772221565e-02
    z[4,9,1]  R1481     -5.5794847011566162e-01
    z[4,9,1]  R1482     -8.7596380710601807e-01
    z[4,9,1]  R1483     -9.1440171003341675e-01
    z[4,9,1]  R1484     -6.7542958259582520e-01
    z[4,9,1]  R1485     -8.2888710498809814e-01
    z[4,9,1]  R1486     -6.4825212955474854e-01
    z[4,9,1]  R1487     -7.9127651453018188e-01
    z[4,9,1]  R1488     -8.2369971275329590e-01
    z[4,9,1]  R1489     -7.7229762077331543e-01
    z[4,9,1]  R1490     -8.8891887664794922e-01
    z[4,9,1]  R1491     -8.8942545652389526e-01
    z[4,9,1]  R1492     -0.79151850938797
    z[4,9,1]  R1493     -8.1461596488952637e-01
    z[4,9,1]  R1494     -8.2109457254409790e-01
    z[4,9,1]  R1495     -1.7773827910423279e-01
    z[4,9,1]  R1496     -7.5015085935592651e-01
    z[4,9,1]  R1497     -7.3993182182312012e-01
    z[4,9,1]  R1498     1.6175159811973572e-01
    z[4,9,1]  R1499     0.035215113312006
    z[4,9,1]  R1500     -0.937619686126709
    z[4,9,1]  R1501     -8.9324432611465454e-01
    z[4,9,1]  R1502     -7.7389258146286011e-01
    z[4,9,1]  R1503     -8.1678217649459839e-01
    z[4,9,1]  R1504     -4.9182184040546417e-02
    z[4,9,1]  R1505     4.4177651405334473e-01
    z[4,9,1]  R1506     4.1015404462814331e-01
    z[4,9,1]  R1507     3.9751288294792175e-01
    z[4,9,1]  R1508     5.5101519823074341e-01
    z[4,9,1]  R1509     1.3473220169544220e-01
    z[4,9,1]  R1510     1.6858656704425812e-01
    z[4,9,1]  R1511     4.2314249277114868e-01
    z[4,9,1]  R1512     -2.8061237186193466e-02
    z[4,9,1]  R1513     0.714479923248291
    z[4,9,1]  R1514     7.6638185977935791e-01
    z[4,9,1]  R1515     -5.1809144020080566e-01
    z[4,9,1]  R1516     -2.1793937683105469e-01
    z[4,9,1]  R1517     -3.7115550041198730e-01
    z[4,9,1]  R1518     -4.5765072107315063e-01
    z[4,9,1]  R1519     -4.2141985893249512e-01
    z[4,9,1]  R1520     -1.5965756773948669e-01
    z[4,9,1]  R1521     -4.7693407535552979e-01
    z[4,9,1]  R1522     -2.7830743789672852e-01
    z[4,9,1]  R1523     -6.4149700105190277e-02
    z[4,9,1]  R1524     -7.0111477375030518e-01
    z[4,9,1]  R1525     -9.2115324735641479e-01
    z[4,9,1]  R1526     -8.8041067123413086e-01
    z[4,9,1]  R1527     -8.6946618556976318e-01
    z[4,9,1]  R1528     -7.5549733638763428e-01
    z[4,9,1]  R1529     -8.7078070640563965e-01
    z[4,9,1]  R1530     -8.5063123703002930e-01
    z[4,9,1]  R1531     -8.1650906801223755e-01
    z[4,9,1]  R1532     -8.8971352577209473e-01
    z[4,9,1]  R1533     -0.678108274936676
    z[4,9,1]  R1534     -6.2778592109680176e-01
    z[4,9,1]  R1535     -4.3269151449203491e-01
    z[4,9,1]  R1536     -0.902143120765686
    z[4,9,1]  R1537     -8.7095803022384644e-01
    z[4,9,1]  R1538     -6.8296605348587036e-01
    z[4,9,1]  R1539     -3.3892369270324707e-01
    z[4,9,1]  R1540     -7.9935854673385620e-01
    z[4,9,1]  R1541     -7.5542962551116943e-01
    z[4,9,2]  R40       -1
    z[4,9,2]  R85       1
    z[4,9,2]  R1422     -1
    z[4,9,2]  R1423     1
    z[4,9,2]  R1432     1.2565425038337708e-01
    z[4,9,2]  R1433     -7.2990462183952332e-02
    z[4,9,2]  R1434     -1.2438035011291504e-01
    z[4,9,2]  R1435     -1.6645358502864838e-01
    z[4,9,2]  R1436     -9.1014020144939423e-02
    z[4,9,2]  R1437     0.626151442527771
    z[4,9,2]  R1438     -2.4900703132152557e-01
    z[4,9,2]  R1439     1.0611472278833389e-01
    z[4,9,2]  R1440     9.1054454445838928e-02
    z[4,9,2]  R1441     -1.5911756455898285e-01
    z[4,9,2]  R1442     3.1160160899162292e-01
    z[4,9,2]  R1443     -1.1797026731073856e-02
    z[4,9,2]  R1444     -2.3035086691379547e-01
    z[4,9,2]  R1445     8.2876391708850861e-02
    z[4,9,2]  R1446     -3.3033519983291626e-01
    z[4,9,2]  R1447     -4.6171391010284424e-01
    z[4,9,2]  R1448     -3.1455031037330627e-01
    z[4,9,2]  R1449     1.0135427117347717e-01
    z[4,9,2]  R1450     -4.3890568614006042e-01
    z[4,9,2]  R1451     0.136931911110878
    z[4,9,2]  R1452     -6.8476319313049316e-01
    z[4,9,2]  R1453     -9.9444175139069557e-03
    z[4,9,2]  R1454     -4.6268993616104126e-01
    z[4,9,2]  R1455     -5.4729342460632324e-01
    z[4,9,2]  R1456     2.4883045256137848e-01
    z[4,9,2]  R1457     -6.9945007562637329e-01
    z[4,9,2]  R1458     -8.0823624134063721e-01
    z[4,9,2]  R1459     -6.4133191108703613e-01
    z[4,9,2]  R1460     -1.8304759636521339e-02
    z[4,9,2]  R1461     2.4319043755531311e-01
    z[4,9,2]  R1462     -6.8353205919265747e-01
    z[4,9,2]  R1463     -7.9876106977462769e-01
    z[4,9,2]  R1464     6.4935930073261261e-02
    z[4,9,2]  R1465     2.7095427736639977e-02
    z[4,9,2]  R1466     -1.4205268025398254e-01
    z[4,9,2]  R1467     -9.6215203404426575e-02
    z[4,9,2]  R1468     -1.0724537819623947e-01
    z[4,9,2]  R1469     -1.6476549208164215e-02
    z[4,9,2]  R1470     -2.6660233736038208e-01
    z[4,9,2]  R1471     -7.3061013221740723e-01
    z[4,9,2]  R1472     -6.6492223739624023e-01
    z[4,9,2]  R1473     1.3585336506366730e-01
    z[4,9,2]  R1474     -5.5617189407348633e-01
    z[4,9,2]  R1475     -5.2972149848937988e-01
    z[4,9,2]  R1476     -1.8511453270912170e-01
    z[4,9,2]  R1477     -2.8458639979362488e-01
    z[4,9,2]  R1478     3.7137895822525024e-02
    z[4,9,2]  R1479     -6.5151625871658325e-01
    z[4,9,2]  R1480     -4.9594688415527344e-01
    z[4,9,2]  R1481     -5.4087972640991211e-01
    z[4,9,2]  R1482     -1.7047224566340446e-02
    z[4,9,2]  R1483     2.7067303657531738e-01
    z[4,9,2]  R1484     -2.6017594337463379e-01
    z[4,9,2]  R1485     3.2183980941772461e-01
    z[4,9,2]  R1486     -1.6664777696132660e-01
    z[4,9,2]  R1487     -2.0325869321823120e-02
    z[4,9,2]  R1488     1.1372482031583786e-01
    z[4,9,2]  R1489     -5.3918910026550293e-01
    z[4,9,2]  R1490     -2.1300375461578369e-01
    z[4,9,2]  R1491     1.8503311276435852e-01
    z[4,9,2]  R1492     -3.3325843513011932e-02
    z[4,9,2]  R1493     -3.8550995290279388e-02
    z[4,9,2]  R1494     2.6382654905319214e-01
    z[4,9,2]  R1495     -9.6111074090003967e-02
    z[4,9,2]  R1496     -1.9729016721248627e-01
    z[4,9,2]  R1497     1.6195631027221680e-01
    z[4,9,2]  R1498     -1.3061526417732239e-01
    z[4,9,2]  R1499     -4.5849704742431641e-01
    z[4,9,2]  R1500     5.3239818662405014e-02
    z[4,9,2]  R1501     -4.7729674726724625e-02
    z[4,9,2]  R1502     -9.9238239228725433e-02
    z[4,9,2]  R1503     -1.8111547827720642e-01
    z[4,9,2]  R1504     -9.2884004116058350e-03
    z[4,9,2]  R1505     0.0757242813706398
    z[4,9,2]  R1506     0.326010137796402
    z[4,9,2]  R1507     1.1096108704805374e-01
    z[4,9,2]  R1508     6.5449941158294678e-01
    z[4,9,2]  R1509     -4.3286693096160889e-01
    z[4,9,2]  R1510     1.2441541254520416e-01
    z[4,9,2]  R1511     -1.7065811157226562e-01
    z[4,9,2]  R1512     6.5025717020034790e-01
    z[4,9,2]  R1513     -1.3663330674171448e-01
    z[4,9,2]  R1514     4.7430303692817688e-01
    z[4,9,2]  R1515     -5.1721256971359253e-01
    z[4,9,2]  R1516     -8.2653927803039551e-01
    z[4,9,2]  R1517     -0.553094744682312
    z[4,9,2]  R1518     -8.1289076805114746e-01
    z[4,9,2]  R1519     -4.1897448897361755e-01
    z[4,9,2]  R1520     -7.3320406675338745e-01
    z[4,9,2]  R1521     -3.8440600037574768e-01
    z[4,9,2]  R1522     -5.3828316926956177e-01
    z[4,9,2]  R1523     4.1125959157943726e-01
    z[4,9,2]  R1524     -5.0224578380584717e-01
    z[4,9,2]  R1525     -0.235634446144104
    z[4,9,2]  R1526     3.0603477358818054e-01
    z[4,9,2]  R1527     3.4926262497901917e-01
    z[4,9,2]  R1528     -2.6990300416946411e-01
    z[4,9,2]  R1529     2.1224774420261383e-01
    z[4,9,2]  R1530     4.4793450832366943e-01
    z[4,9,2]  R1531     4.8370894789695740e-01
    z[4,9,2]  R1532     -1.0303554683923721e-01
    z[4,9,2]  R1533     -5.9813553094863892e-01
    z[4,9,2]  R1534     -4.4539690017700195e-01
    z[4,9,2]  R1535     -6.5150165557861328e-01
    z[4,9,2]  R1536     -2.7931925654411316e-01
    z[4,9,2]  R1537     -2.8034433722496033e-01
    z[4,9,2]  R1538     -1.2294710427522659e-01
    z[4,9,2]  R1539     -8.6787927150726318e-01
    z[4,9,2]  R1540     2.5643259286880493e-01
    z[4,9,2]  R1541     2.2316598892211914e-01
    z[4,9,3]  R41       -1
    z[4,9,3]  R86       1
    z[4,9,3]  R1424     -1
    z[4,9,3]  R1425     1
    z[4,9,3]  R1432     -2.8652116656303406e-01
    z[4,9,3]  R1433     3.5964247584342957e-01
    z[4,9,3]  R1434     2.0728701353073120e-01
    z[4,9,3]  R1435     -5.2693802118301392e-01
    z[4,9,3]  R1436     -6.0815256834030151e-01
    z[4,9,3]  R1437     2.3736244067549706e-02
    z[4,9,3]  R1438     3.3163344860076904e-01
    z[4,9,3]  R1439     7.7075809240341187e-01
    z[4,9,3]  R1440     8.5122185945510864e-01
    z[4,9,3]  R1441     0.625590443611145
    z[4,9,3]  R1442     6.2528085708618164e-01
    z[4,9,3]  R1443     9.3912720680236816e-01
    z[4,9,3]  R1444     6.7131775617599487e-01
    z[4,9,3]  R1445     7.4573343992233276e-01
    z[4,9,3]  R1446     -1.6835495829582214e-01
    z[4,9,3]  R1447     -1.0739649832248688e-01
    z[4,9,3]  R1448     -2.1419250965118408e-01
    z[4,9,3]  R1449     -1.6170606017112732e-01
    z[4,9,3]  R1450     -6.2765496969223022e-01
    z[4,9,3]  R1451     3.4590315818786621e-01
    z[4,9,3]  R1452     7.9685494303703308e-02
    z[4,9,3]  R1453     1.6408908367156982e-01
    z[4,9,3]  R1454     -2.7080511674284935e-02
    z[4,9,3]  R1455     -3.9443865418434143e-01
    z[4,9,3]  R1456     2.4014189839363098e-01
    z[4,9,3]  R1457     -1.2927785515785217e-01
    z[4,9,3]  R1458     0.0540459118783474
    z[4,9,3]  R1459     7.0934325456619263e-02
    z[4,9,3]  R1460     -5.7334297895431519e-01
    z[4,9,3]  R1461     2.5984886288642883e-01
    z[4,9,3]  R1462     1.1943177878856659e-01
    z[4,9,3]  R1463     -1.2809245288372040e-01
    z[4,9,3]  R1464     9.6224442124366760e-02
    z[4,9,3]  R1465     -3.6655715107917786e-01
    z[4,9,3]  R1466     0.0673820897936821
    z[4,9,3]  R1467     4.0417218208312988e-01
    z[4,9,3]  R1468     2.4162137508392334e-01
    z[4,9,3]  R1469     3.8890153169631958e-01
    z[4,9,3]  R1470     5.7501119375228882e-01
    z[4,9,3]  R1471     -2.3392596840858459e-01
    z[4,9,3]  R1472     4.7164112329483032e-02
    z[4,9,3]  R1473     1.7356034368276596e-02
    z[4,9,3]  R1474     -4.5801591873168945e-01
    z[4,9,3]  R1475     -3.3098584413528442e-01
    z[4,9,3]  R1476     -1.4017856121063232e-01
    z[4,9,3]  R1477     -4.1113600134849548e-01
    z[4,9,3]  R1478     6.7720770835876465e-02
    z[4,9,3]  R1479     -2.7207341790199280e-01
    z[4,9,3]  R1480     2.9130643606185913e-01
    z[4,9,3]  R1481     -0.48995241522789
    z[4,9,3]  R1482     0.154449462890625
    z[4,9,3]  R1483     -2.7712401747703552e-01
    z[4,9,3]  R1484     -3.0682352185249329e-01
    z[4,9,3]  R1485     -8.2297712564468384e-02
    z[4,9,3]  R1486     -3.5729256272315979e-01
    z[4,9,3]  R1487     7.8484527766704559e-02
    z[4,9,3]  R1488     -1.7783628404140472e-01
    z[4,9,3]  R1489     -8.9961253106594086e-02
    z[4,9,3]  R1490     1.8062674999237061e-01
    z[4,9,3]  R1491     -1.3411337137222290e-01
    z[4,9,3]  R1492     -5.0566357374191284e-01
    z[4,9,3]  R1493     2.0418265461921692e-01
    z[4,9,3]  R1494     5.1924187690019608e-02
    z[4,9,3]  R1495     2.6497477293014526e-01
    z[4,9,3]  R1496     -1.2366843223571777e-01
    z[4,9,3]  R1497     -2.4484993517398834e-01
    z[4,9,3]  R1498     2.2541526705026627e-02
    z[4,9,3]  R1499     3.8468053936958313e-01
    z[4,9,3]  R1500     -2.2348362207412720e-01
    z[4,9,3]  R1501     -2.5302174687385559e-01
    z[4,9,3]  R1502     2.5384664535522461e-01
    z[4,9,3]  R1503     5.5681776255369186e-02
    z[4,9,3]  R1504     5.7787474244832993e-02
    z[4,9,3]  R1505     -2.5616058707237244e-01
    z[4,9,3]  R1506     -2.4824059009552002e-01
    z[4,9,3]  R1507     -2.2069209814071655e-01
    z[4,9,3]  R1508     -3.3724498003721237e-02
    z[4,9,3]  R1509     3.1078770756721497e-01
    z[4,9,3]  R1510     -4.5165005326271057e-01
    z[4,9,3]  R1511     1.4078325033187866e-01
    z[4,9,3]  R1512     -3.4588072448968887e-02
    z[4,9,3]  R1513     -1.2074072659015656e-01
    z[4,9,3]  R1514     2.5519285351037979e-02
    z[4,9,3]  R1515     -5.5568039417266846e-01
    z[4,9,3]  R1516     -1.9025236368179321e-01
    z[4,9,3]  R1517     -2.2748155891895294e-01
    z[4,9,3]  R1518     2.0364774763584137e-01
    z[4,9,3]  R1519     -5.9576690196990967e-01
    z[4,9,3]  R1520     -5.6127548217773438e-01
    z[4,9,3]  R1521     -6.4333927631378174e-01
    z[4,9,3]  R1522     -4.2715385556221008e-01
    z[4,9,3]  R1523     7.4921971559524536e-01
    z[4,9,3]  R1524     -1.9616352021694183e-01
    z[4,9,3]  R1525     1.6831265389919281e-01
    z[4,9,3]  R1526     -6.8378285504877567e-03
    z[4,9,3]  R1527     9.6730358898639679e-02
    z[4,9,3]  R1528     1.3995271921157837e-01
    z[4,9,3]  R1529     -1.4716957509517670e-01
    z[4,9,3]  R1530     1.1623748391866684e-01
    z[4,9,3]  R1531     -1.3191212713718414e-01
    z[4,9,3]  R1532     1.2486474215984344e-01
    z[4,9,3]  R1533     -5.4926581680774689e-02
    z[4,9,3]  R1534     -3.8294005393981934e-01
    z[4,9,3]  R1535     -3.8724753260612488e-01
    z[4,9,3]  R1536     -1.4854340255260468e-01
    z[4,9,3]  R1537     -7.3607891798019409e-02
    z[4,9,3]  R1538     -0.280905157327652
    z[4,9,3]  R1539     -1.0316666215658188e-01
    z[4,9,3]  R1540     3.2250329852104187e-01
    z[4,9,3]  R1541     1.2399671971797943e-01
    z[4,9,4]  R42       -1
    z[4,9,4]  R87       1
    z[4,9,4]  R1426     -1
    z[4,9,4]  R1427     1
    z[4,9,4]  R1432     2.0960272848606110e-01
    z[4,9,4]  R1433     -3.7107229232788086e-02
    z[4,9,4]  R1434     -7.0225065946578979e-01
    z[4,9,4]  R1435     -4.7506490349769592e-01
    z[4,9,4]  R1436     -3.6551004648208618e-01
    z[4,9,4]  R1437     -4.3038591742515564e-01
    z[4,9,4]  R1438     4.4329786300659180e-01
    z[4,9,4]  R1439     -5.3792528808116913e-02
    z[4,9,4]  R1440     -4.5282721519470215e-02
    z[4,9,4]  R1441     6.5043777227401733e-02
    z[4,9,4]  R1442     1.4205466210842133e-01
    z[4,9,4]  R1443     8.2762479782104492e-02
    z[4,9,4]  R1444     1.7623870074748993e-01
    z[4,9,4]  R1445     3.9861190319061279e-01
    z[4,9,4]  R1446     -2.0020754635334015e-01
    z[4,9,4]  R1447     -1.9458557665348053e-01
    z[4,9,4]  R1448     -8.5982456803321838e-02
    z[4,9,4]  R1449     1.6359147429466248e-01
    z[4,9,4]  R1450     1.9855398684740067e-02
    z[4,9,4]  R1451     0.178420752286911
    z[4,9,4]  R1452     2.1477924287319183e-01
    z[4,9,4]  R1453     -1.5897114574909210e-01
    z[4,9,4]  R1454     2.6159333065152168e-02
    z[4,9,4]  R1455     1.6524660587310791e-01
    z[4,9,4]  R1456     0.0753258541226387
    z[4,9,4]  R1457     3.3169826865196228e-01
    z[4,9,4]  R1458     0.0411791168153286
    z[4,9,4]  R1459     2.2157919406890869e-01
    z[4,9,4]  R1460     -4.7878913581371307e-02
    z[4,9,4]  R1461     3.7933662533760071e-01
    z[4,9,4]  R1462     -1.9451610743999481e-02
    z[4,9,4]  R1463     1.8401028215885162e-01
    z[4,9,4]  R1464     2.4931050837039948e-01
    z[4,9,4]  R1465     9.7140751779079437e-02
    z[4,9,4]  R1466     4.1627818346023560e-01
    z[4,9,4]  R1467     3.2874977588653564e-01
    z[4,9,4]  R1468     -2.6751694083213806e-01
    z[4,9,4]  R1469     4.1147032380104065e-01
    z[4,9,4]  R1470     4.1332921385765076e-01
    z[4,9,4]  R1471     4.8051834106445312e-02
    z[4,9,4]  R1472     1.0222673416137695e-01
    z[4,9,4]  R1473     -2.2699016332626343e-01
    z[4,9,4]  R1474     6.3473515212535858e-02
    z[4,9,4]  R1475     8.2612454891204834e-02
    z[4,9,4]  R1476     -2.8288796544075012e-02
    z[4,9,4]  R1477     7.2491921484470367e-02
    z[4,9,4]  R1478     9.1149166226387024e-02
    z[4,9,4]  R1479     -7.5300313532352448e-02
    z[4,9,4]  R1480     1.7393555492162704e-02
    z[4,9,4]  R1481     8.6900874972343445e-02
    z[4,9,4]  R1482     -1.9447323679924011e-01
    z[4,9,4]  R1483     1.8232997506856918e-02
    z[4,9,4]  R1484     -3.6176049709320068e-01
    z[4,9,4]  R1485     2.2238619625568390e-01
    z[4,9,4]  R1486     -9.1401286423206329e-02
    z[4,9,4]  R1487     3.6532336473464966e-01
    z[4,9,4]  R1488     1.1237250268459320e-01
    z[4,9,4]  R1489     1.1224296689033508e-01
    z[4,9,4]  R1490     7.5787985697388649e-03
    z[4,9,4]  R1491     6.4320690929889679e-02
    z[4,9,4]  R1492     -1.3239432871341705e-01
    z[4,9,4]  R1493     2.5776756927371025e-02
    z[4,9,4]  R1494     3.5215219855308533e-01
    z[4,9,4]  R1495     6.4503157138824463e-01
    z[4,9,4]  R1496     4.3805581331253052e-01
    z[4,9,4]  R1497     -1.5390609204769135e-01
    z[4,9,4]  R1498     6.7675316333770752e-01
    z[4,9,4]  R1499     -3.6997926235198975e-01
    z[4,9,4]  R1500     -6.6607259213924408e-02
    z[4,9,4]  R1501     1.2064320594072342e-01
    z[4,9,4]  R1502     2.6603901386260986e-01
    z[4,9,4]  R1503     4.8441749811172485e-01
    z[4,9,4]  R1504     7.0256847143173218e-01
    z[4,9,4]  R1505     4.4332712888717651e-01
    z[4,9,4]  R1506     3.2140663266181946e-01
    z[4,9,4]  R1507     1.5471938252449036e-01
    z[4,9,4]  R1508     1.9196658395230770e-03
    z[4,9,4]  R1509     -2.5800400972366333e-01
    z[4,9,4]  R1510     2.5214368104934692e-01
    z[4,9,4]  R1511     -7.0631998777389526e-01
    z[4,9,4]  R1512     -3.7295809388160706e-01
    z[4,9,4]  R1513     2.8939986228942871e-01
    z[4,9,4]  R1514     2.8842580318450928e-01
    z[4,9,4]  R1515     -2.4159426987171173e-01
    z[4,9,4]  R1516     -1.0661655664443970e-01
    z[4,9,4]  R1517     -2.4044224619865417e-01
    z[4,9,4]  R1518     6.5771579742431641e-02
    z[4,9,4]  R1519     -1.4227968454360962e-01
    z[4,9,4]  R1520     -7.1949161589145660e-02
    z[4,9,4]  R1521     -4.2798832058906555e-01
    z[4,9,4]  R1522     -3.4484058618545532e-01
    z[4,9,4]  R1523     4.1967192292213440e-01
    z[4,9,4]  R1524     -0.147585928440094
    z[4,9,4]  R1525     -2.3215298354625702e-01
    z[4,9,4]  R1526     2.6100844144821167e-01
    z[4,9,4]  R1527     -5.4785937070846558e-02
    z[4,9,4]  R1528     -1.7025260627269745e-01
    z[4,9,4]  R1529     2.3434217274188995e-01
    z[4,9,4]  R1530     -1.3723957538604736e-01
    z[4,9,4]  R1531     4.8777997493743896e-02
    z[4,9,4]  R1532     2.6117336750030518e-01
    z[4,9,4]  R1533     -3.1882843375205994e-01
    z[4,9,4]  R1534     -3.8114255666732788e-01
    z[4,9,4]  R1535     -2.6665088534355164e-01
    z[4,9,4]  R1536     -2.0027939975261688e-01
    z[4,9,4]  R1537     -1.7304883897304535e-01
    z[4,9,4]  R1538     -5.3228950500488281e-01
    z[4,9,4]  R1539     -0.00839918851852417
    z[4,9,4]  R1540     2.1437498927116394e-01
    z[4,9,4]  R1541     5.1331651210784912e-01
    z[4,9,5]  R43       -1
    z[4,9,5]  R88       1
    z[4,9,5]  R1428     -1
    z[4,9,5]  R1429     1
    z[4,9,5]  R1432     -2.9125988483428955e-01
    z[4,9,5]  R1433     2.8395307064056396e-01
    z[4,9,5]  R1434     3.8931244611740112e-01
    z[4,9,5]  R1435     -1.9168801605701447e-01
    z[4,9,5]  R1436     5.8619940280914307e-01
    z[4,9,5]  R1437     -2.4412751197814941e-02
    z[4,9,5]  R1438     -2.9837164282798767e-01
    z[4,9,5]  R1439     -2.8865331411361694e-01
    z[4,9,5]  R1440     1.4389933645725250e-01
    z[4,9,5]  R1441     -9.0629987418651581e-02
    z[4,9,5]  R1442     -3.2613296061754227e-02
    z[4,9,5]  R1443     -1.4074572920799255e-01
    z[4,9,5]  R1444     3.2871791720390320e-01
    z[4,9,5]  R1445     1.4860203862190247e-01
    z[4,9,5]  R1446     -4.4143116474151611e-01
    z[4,9,5]  R1447     -5.3421151638031006e-01
    z[4,9,5]  R1448     1.0798743367195129e-01
    z[4,9,5]  R1449     -2.9459038376808167e-01
    z[4,9,5]  R1450     -2.6060670614242554e-01
    z[4,9,5]  R1451     -7.2829827666282654e-02
    z[4,9,5]  R1452     -2.1018789708614349e-01
    z[4,9,5]  R1453     7.5851596891880035e-02
    z[4,9,5]  R1454     -3.5586071014404297e-01
    z[4,9,5]  R1455     -2.5549063086509705e-01
    z[4,9,5]  R1456     1.1772985756397247e-01
    z[4,9,5]  R1457     -2.9082307219505310e-01
    z[4,9,5]  R1458     -7.5395785272121429e-02
    z[4,9,5]  R1459     -2.9266867041587830e-01
    z[4,9,5]  R1460     -3.0513831973075867e-01
    z[4,9,5]  R1461     3.6092754453420639e-02
    z[4,9,5]  R1462     -0.0642428919672966
    z[4,9,5]  R1463     -1.3352457899600267e-03
    z[4,9,5]  R1464     2.5755900144577026e-01
    z[4,9,5]  R1465     -3.2464000582695007e-01
    z[4,9,5]  R1466     -0.275749534368515
    z[4,9,5]  R1467     2.5408431887626648e-01
    z[4,9,5]  R1468     -0.0939953550696373
    z[4,9,5]  R1469     -2.5288176536560059e-01
    z[4,9,5]  R1470     -2.3178742825984955e-01
    z[4,9,5]  R1471     -0.127928227186203
    z[4,9,5]  R1472     -3.0584850907325745e-01
    z[4,9,5]  R1473     -2.4475468695163727e-01
    z[4,9,5]  R1474     -6.1415430158376694e-02
    z[4,9,5]  R1475     -3.7571245431900024e-01
    z[4,9,5]  R1476     -2.3396830260753632e-01
    z[4,9,5]  R1477     -2.2887107729911804e-01
    z[4,9,5]  R1478     -2.9069520533084869e-02
    z[4,9,5]  R1479     -0.0584476999938488
    z[4,9,5]  R1480     -1.2071265280246735e-01
    z[4,9,5]  R1481     -3.0844411253929138e-01
    z[4,9,5]  R1482     -2.5860235095024109e-01
    z[4,9,5]  R1483     -2.2496019955724478e-03
    z[4,9,5]  R1484     -2.4236641824245453e-01
    z[4,9,5]  R1485     7.9531274735927582e-02
    z[4,9,5]  R1486     -4.3636941909790039e-01
    z[4,9,5]  R1487     -4.3903324007987976e-01
    z[4,9,5]  R1488     -9.9482253193855286e-02
    z[4,9,5]  R1489     -2.7293553948402405e-01
    z[4,9,5]  R1490     2.2007305920124054e-01
    z[4,9,5]  R1491     1.1336227878928185e-02
    z[4,9,5]  R1492     -1.5972651541233063e-01
    z[4,9,5]  R1493     4.2401656508445740e-01
    z[4,9,5]  R1494     1.3125570118427277e-01
    z[4,9,5]  R1495     4.9722746014595032e-02
    z[4,9,5]  R1496     -9.0187273919582367e-02
    z[4,9,5]  R1497     0.148108571767807
    z[4,9,5]  R1498     -4.6637412905693054e-01
    z[4,9,5]  R1499     -1.2660789489746094e-01
    z[4,9,5]  R1500     -2.2432606667280197e-02
    z[4,9,5]  R1501     -3.3498124685138464e-03
    z[4,9,5]  R1502     -2.0628614723682404e-01
    z[4,9,5]  R1503     -6.0372814536094666e-02
    z[4,9,5]  R1504     -5.1319307088851929e-01
    z[4,9,5]  R1505     -1.2096808850765228e-01
    z[4,9,5]  R1506     -1.0360217653214931e-02
    z[4,9,5]  R1507     1.5313176810741425e-01
    z[4,9,5]  R1508     5.0063580274581909e-01
    z[4,9,5]  R1509     -1.9602391123771667e-01
    z[4,9,5]  R1510     2.8628429770469666e-01
    z[4,9,5]  R1511     1.0761862248182297e-01
    z[4,9,5]  R1512     -6.5537005662918091e-01
    z[4,9,5]  R1513     -4.2324599623680115e-01
    z[4,9,5]  R1514     -2.0733886957168579e-01
    z[4,9,5]  R1515     -3.0481913685798645e-01
    z[4,9,5]  R1516     -1.4984667301177979e-01
    z[4,9,5]  R1517     -3.7876769900321960e-01
    z[4,9,5]  R1518     1.1142546683549881e-01
    z[4,9,5]  R1519     1.6161814332008362e-01
    z[4,9,5]  R1520     1.1382610350847244e-01
    z[4,9,5]  R1521     -1.1267782747745514e-01
    z[4,9,5]  R1522     -3.6104604601860046e-01
    z[4,9,5]  R1523     2.3703837394714355e-01
    z[4,9,5]  R1524     -1.6992285847663879e-01
    z[4,9,5]  R1525     -1.0494102537631989e-01
    z[4,9,5]  R1526     -2.7235141023993492e-02
    z[4,9,5]  R1527     -7.3739282786846161e-02
    z[4,9,5]  R1528     5.1846086978912354e-01
    z[4,9,5]  R1529     1.5279792249202728e-01
    z[4,9,5]  R1530     -0.00711454264819622
    z[4,9,5]  R1531     -1.1322123557329178e-01
    z[4,9,5]  R1532     0.275865763425827
    z[4,9,5]  R1533     2.6888754963874817e-01
    z[4,9,5]  R1534     -2.3302617669105530e-01
    z[4,9,5]  R1535     3.9052048325538635e-01
    z[4,9,5]  R1536     -6.3229940831661224e-02
    z[4,9,5]  R1537     6.6179037094116211e-03
    z[4,9,5]  R1538     -0.114285409450531
    z[4,9,5]  R1539     1.0628158599138260e-01
    z[4,9,5]  R1540     1.1328091472387314e-01
    z[4,9,5]  R1541     5.9948820620775223e-02
    z[4,9,6]  R44       -1
    z[4,9,6]  R89       1
    z[4,9,6]  R1430     -1
    z[4,9,6]  R1431     1
    z[4,9,6]  R1432     2.8060242533683777e-01
    z[4,9,6]  R1433     -7.3620069026947021e-01
    z[4,9,6]  R1434     3.4527981281280518e-01
    z[4,9,6]  R1435     -2.0684666931629181e-01
    z[4,9,6]  R1436     3.0820357799530029e-01
    z[4,9,6]  R1437     -0.128057062625885
    z[4,9,6]  R1438     6.4315706491470337e-01
    z[4,9,6]  R1439     1.2790703773498535e-01
    z[4,9,6]  R1440     -2.7893617749214172e-01
    z[4,9,6]  R1441     1.7463859915733337e-01
    z[4,9,6]  R1442     1.9452748820185661e-02
    z[4,9,6]  R1443     -3.7492178380489349e-02
    z[4,9,6]  R1444     -5.4711066186428070e-02
    z[4,9,6]  R1445     3.8416630029678345e-01
    z[4,9,6]  R1446     0.128541499376297
    z[4,9,6]  R1447     -1.7142567038536072e-01
    z[4,9,6]  R1448     3.5137572558596730e-04
    z[4,9,6]  R1449     -1.0635446012020111e-01
    z[4,9,6]  R1450     3.9185993373394012e-03
    z[4,9,6]  R1451     -3.9791685342788696e-01
    z[4,9,6]  R1452     1.1854583024978638e-01
    z[4,9,6]  R1453     3.4693002700805664e-01
    z[4,9,6]  R1454     2.9228290915489197e-01
    z[4,9,6]  R1455     -1.6315580904483795e-01
    z[4,9,6]  R1456     4.1230472922325134e-01
    z[4,9,6]  R1457     -3.0129143595695496e-01
    z[4,9,6]  R1458     -2.9035961627960205e-01
    z[4,9,6]  R1459     1.4775559306144714e-01
    z[4,9,6]  R1460     -2.9739844799041748e-01
    z[4,9,6]  R1461     1.8891172111034393e-01
    z[4,9,6]  R1462     -2.3863962292671204e-01
    z[4,9,6]  R1463     -1.5067948400974274e-01
    z[4,9,6]  R1464     2.7361556887626648e-01
    z[4,9,6]  R1465     -2.0225435495376587e-02
    z[4,9,6]  R1466     2.4946808815002441e-01
    z[4,9,6]  R1467     4.7203049063682556e-02
    z[4,9,6]  R1468     -4.6506536006927490e-01
    z[4,9,6]  R1469     3.3451551198959351e-01
    z[4,9,6]  R1470     -4.1838163137435913e-01
    z[4,9,6]  R1471     -2.3472876846790314e-01
    z[4,9,6]  R1472     1.0016328841447830e-01
    z[4,9,6]  R1473     1.6122755408287048e-01
    z[4,9,6]  R1474     9.5639698207378387e-02
    z[4,9,6]  R1475     -4.5434826612472534e-01
    z[4,9,6]  R1476     -3.2423120737075806e-01
    z[4,9,6]  R1477     -2.6547786593437195e-01
    z[4,9,6]  R1478     -3.2465690374374390e-01
    z[4,9,6]  R1479     2.2864004597067833e-02
    z[4,9,6]  R1480     -3.6312052607536316e-01
    z[4,9,6]  R1481     -2.0985266566276550e-01
    z[4,9,6]  R1482     -2.3246988654136658e-01
    z[4,9,6]  R1483     -1.0503920912742615e-01
    z[4,9,6]  R1484     -3.7892490625381470e-01
    z[4,9,6]  R1485     3.4058490395545959e-01
    z[4,9,6]  R1486     -1.3030645251274109e-01
    z[4,9,6]  R1487     8.6043469607830048e-02
    z[4,9,6]  R1488     4.5605826377868652e-01
    z[4,9,6]  R1489     -0.087053082883358
    z[4,9,6]  R1490     -2.8867509961128235e-01
    z[4,9,6]  R1491     3.6522147059440613e-01
    z[4,9,6]  R1492     0.0693008303642273
    z[4,9,6]  R1493     1.1321227252483368e-01
    z[4,9,6]  R1494     -1.2769292108714581e-02
    z[4,9,6]  R1495     -2.2302225232124329e-01
    z[4,9,6]  R1496     3.5758644342422485e-01
    z[4,9,6]  R1497     -4.6779972314834595e-01
    z[4,9,6]  R1498     -2.5400716066360474e-01
    z[4,9,6]  R1499     -2.3589698597788811e-02
    z[4,9,6]  R1500     4.9371778964996338e-02
    z[4,9,6]  R1501     -3.2521459460258484e-01
    z[4,9,6]  R1502     1.8636316061019897e-01
    z[4,9,6]  R1503     1.5397830307483673e-01
    z[4,9,6]  R1504     1.4918014407157898e-01
    z[4,9,6]  R1505     1.9710658490657806e-01
    z[4,9,6]  R1506     -1.4122587442398071e-01
    z[4,9,6]  R1507     0.447965532541275
    z[4,9,6]  R1508     -5.0835594534873962e-02
    z[4,9,6]  R1509     2.5987529754638672e-01
    z[4,9,6]  R1510     3.6881312727928162e-02
    z[4,9,6]  R1511     -5.0899302959442139e-01
    z[4,9,6]  R1512     -5.8440122753381729e-02
    z[4,9,6]  R1513     3.3064281940460205e-01
    z[4,9,6]  R1514     -4.4781979173421860e-02
    z[4,9,6]  R1515     -6.2554776668548584e-02
    z[4,9,6]  R1516     7.2125345468521118e-02
    z[4,9,6]  R1517     3.1975358724594116e-02
    z[4,9,6]  R1518     -2.5159576535224915e-01
    z[4,9,6]  R1519     -1.5411528944969177e-01
    z[4,9,6]  R1520     1.8116460740566254e-01
    z[4,9,6]  R1521     8.7155632674694061e-02
    z[4,9,6]  R1522     2.5628376007080078e-01
    z[4,9,6]  R1523     -8.1337183713912964e-02
    z[4,9,6]  R1524     3.6749577522277832e-01
    z[4,9,6]  R1525     -2.3170365020632744e-02
    z[4,9,6]  R1526     -1.9183224439620972e-01
    z[4,9,6]  R1527     -3.1564655900001526e-01
    z[4,9,6]  R1528     -1.9450746476650238e-01
    z[4,9,6]  R1529     1.0049699246883392e-01
    z[4,9,6]  R1530     -7.6333783566951752e-02
    z[4,9,6]  R1531     0.0470597967505455
    z[4,9,6]  R1532     1.8185776472091675e-01
    z[4,9,6]  R1533     -1.8424183130264282e-02
    z[4,9,6]  R1534     2.0998762547969818e-01
    z[4,9,6]  R1535     -0.0609787218272686
    z[4,9,6]  R1536     1.3025906682014465e-01
    z[4,9,6]  R1537     -3.1629326939582825e-01
    z[4,9,6]  R1538     -1.0128965228796005e-01
    z[4,9,6]  R1539     3.2674354314804077e-01
    z[4,9,6]  R1540     0.0331374928355217
    z[4,9,6]  R1541     0.31126868724823
    z[9,4,0]  R38       1
    z[9,4,0]  R83       -1
    z[9,4,0]  R1542     -1
    z[9,4,0]  R1543     1
    z[9,4,0]  R1556     -1.1683891713619232e-01
    z[9,4,0]  R1557     -7.2481578588485718e-01
    z[9,4,0]  R1558     -7.7795642614364624e-01
    z[9,4,0]  R1559     -4.9626111984252930e-02
    z[9,4,0]  R1560     5.6205615401268005e-02
    z[9,4,0]  R1561     2.8992640972137451e-01
    z[9,4,0]  R1562     2.4261078238487244e-01
    z[9,4,0]  R1563     9.8038287833333015e-03
    z[9,4,0]  R1564     0.440586119890213
    z[9,4,0]  R1565     5.4980188608169556e-01
    z[9,4,0]  R1566     9.0830363333225250e-02
    z[9,4,0]  R1567     4.7096928954124451e-01
    z[9,4,0]  R1568     2.6634064316749573e-01
    z[9,4,0]  R1569     8.6104303598403931e-02
    z[9,4,0]  R1570     3.6794704198837280e-01
    z[9,4,0]  R1571     -1.6276559233665466e-01
    z[9,4,0]  R1572     -1.7888191342353821e-01
    z[9,4,0]  R1573     4.6682957559823990e-02
    z[9,4,0]  R1574     1.5970674157142639e-01
    z[9,4,0]  R1575     -6.7939713597297668e-02
    z[9,4,0]  R1576     -0.0341838039457798
    z[9,4,0]  R1577     2.9439744353294373e-01
    z[9,4,0]  R1578     -1.9379843771457672e-01
    z[9,4,0]  R1579     2.5401732325553894e-01
    z[9,4,0]  R1580     -6.9402478635311127e-02
    z[9,4,0]  R1581     7.1375928819179535e-02
    z[9,4,0]  R1582     1.3114073872566223e-01
    z[9,4,0]  R1583     1.0505028814077377e-01
    z[9,4,0]  R1584     -1.5803864598274231e-01
    z[9,4,0]  R1585     -1.6549913585186005e-01
    z[9,4,0]  R1586     3.6452811956405640e-01
    z[9,4,0]  R1587     -5.6082367897033691e-02
    z[9,4,0]  R1588     3.6245340108871460e-01
    z[9,4,0]  R1589     1.3113540597259998e-02
    z[9,4,0]  R1590     -7.8451806306838989e-01
    z[9,4,0]  R1591     -2.3863452672958374e-01
    z[9,4,0]  R1592     -4.2138642072677612e-01
    z[9,4,0]  R1593     -2.3271121084690094e-01
    z[9,4,0]  R1594     9.3946374952793121e-02
    z[9,4,0]  R1595     -6.3066649436950684e-01
    z[9,4,0]  R1596     -2.2421675920486450e-01
    z[9,4,0]  R1597     0.221639484167099
    z[9,4,0]  R1598     2.5867444276809692e-01
    z[9,4,0]  R1599     2.9126021265983582e-01
    z[9,4,0]  R1600     3.7454894185066223e-01
    z[9,4,0]  R1601     2.7899321913719177e-01
    z[9,4,0]  R1602     3.8191944360733032e-01
    z[9,4,0]  R1603     2.9376068711280823e-01
    z[9,4,0]  R1604     -0.0978270173072815
    z[9,4,0]  R1605     -2.9137728735804558e-02
    z[9,4,0]  R1606     7.4456967413425446e-02
    z[9,4,0]  R1607     1.8401703238487244e-01
    z[9,4,0]  R1608     0.302244633436203
    z[9,4,0]  R1609     1.1519994586706161e-01
    z[9,4,0]  R1610     -3.0517500638961792e-01
    z[9,4,0]  R1611     4.6974033117294312e-01
    z[9,4,0]  R1612     4.7435140609741211e-01
    z[9,4,0]  R1613     -2.6120521128177643e-02
    z[9,4,0]  R1614     0.317367821931839
    z[9,4,0]  R1615     -1.7612075433135033e-02
    z[9,4,0]  R1616     -1.6793097555637360e-01
    z[9,4,0]  R1617     -1.0067898780107498e-01
    z[9,4,0]  R1618     -1.6538232564926147e-02
    z[9,4,0]  R1619     -1.2822266668081284e-02
    z[9,4,0]  R1620     3.6187297105789185e-01
    z[9,4,0]  R1621     2.9852783679962158e-01
    z[9,4,0]  R1622     3.7791994214057922e-01
    z[9,4,0]  R1623     -3.7840750813484192e-01
    z[9,4,0]  R1624     -2.8823024034500122e-01
    z[9,4,0]  R1625     2.5137278437614441e-01
    z[9,4,0]  R1626     3.0971741676330566e-01
    z[9,4,0]  R1627     -0.0793575644493103
    z[9,4,0]  R1628     -1.8650509417057037e-01
    z[9,4,0]  R1629     1.6907888650894165e-01
    z[9,4,0]  R1630     3.1163122504949570e-02
    z[9,4,0]  R1631     1.5796346962451935e-01
    z[9,4,0]  R1632     2.8270235657691956e-01
    z[9,4,0]  R1633     -3.6034090444445610e-03
    z[9,4,0]  R1634     -1.9155786931514740e-01
    z[9,4,0]  R1635     -1.3722683489322662e-01
    z[9,4,0]  R1636     -2.5865417718887329e-01
    z[9,4,0]  R1637     -3.6463830620050430e-02
    z[9,4,0]  R1638     7.2248607873916626e-01
    z[9,4,0]  R1639     -9.6755206584930420e-02
    z[9,4,0]  R1640     -0.223170205950737
    z[9,4,0]  R1641     -4.9366939812898636e-02
    z[9,4,0]  R1642     2.2083133459091187e-01
    z[9,4,0]  R1643     1.7553773522377014e-01
    z[9,4,0]  R1644     4.5671370625495911e-01
    z[9,4,0]  R1645     -1.8355819582939148e-01
    z[9,4,0]  R1646     -2.1551392972469330e-01
    z[9,4,0]  R1647     0.100338414311409
    z[9,4,0]  R1648     -1.9112358568236232e-03
    z[9,4,0]  R1649     -1.3800835609436035e-01
    z[9,4,0]  R1650     2.6239061355590820e-01
    z[9,4,0]  R1651     3.1615287065505981e-01
    z[9,4,0]  R1652     3.3481448888778687e-01
    z[9,4,0]  R1653     6.4860087633132935e-01
    z[9,4,0]  R1654     2.3486499488353729e-01
    z[9,4,0]  R1655     3.1915476918220520e-01
    z[9,4,0]  R1656     4.6502545475959778e-01
    z[9,4,0]  R1657     6.9791865348815918e-01
    z[9,4,0]  R1658     -2.4639932811260223e-01
    z[9,4,0]  R1659     1.2444227188825607e-01
    z[9,4,0]  R1660     0.422778844833374
    z[9,4,0]  R1661     1.8694639205932617e-01
    z[9,4,0]  R1662     0.463606595993042
    z[9,4,0]  R1663     0.695311427116394
    z[9,4,0]  R1664     7.3519617319107056e-01
    z[9,4,0]  R1665     0.730003833770752
    z[9,4,1]  R39       1
    z[9,4,1]  R84       -1
    z[9,4,1]  R1544     -1
    z[9,4,1]  R1545     1
    z[9,4,1]  R1556     5.5101519823074341e-01
    z[9,4,1]  R1557     1.3473220169544220e-01
    z[9,4,1]  R1558     1.6858656704425812e-01
    z[9,4,1]  R1559     4.2314249277114868e-01
    z[9,4,1]  R1560     -2.8061237186193466e-02
    z[9,4,1]  R1561     0.714479923248291
    z[9,4,1]  R1562     7.6638185977935791e-01
    z[9,4,1]  R1563     -5.1809144020080566e-01
    z[9,4,1]  R1564     -2.1793937683105469e-01
    z[9,4,1]  R1565     -3.7115550041198730e-01
    z[9,4,1]  R1566     -4.5765072107315063e-01
    z[9,4,1]  R1567     -4.2141985893249512e-01
    z[9,4,1]  R1568     -1.5965756773948669e-01
    z[9,4,1]  R1569     -4.7693407535552979e-01
    z[9,4,1]  R1570     -2.7830743789672852e-01
    z[9,4,1]  R1571     -6.4149700105190277e-02
    z[9,4,1]  R1572     -7.0111477375030518e-01
    z[9,4,1]  R1573     -9.2115324735641479e-01
    z[9,4,1]  R1574     -8.8041067123413086e-01
    z[9,4,1]  R1575     -8.6946618556976318e-01
    z[9,4,1]  R1576     -7.5549733638763428e-01
    z[9,4,1]  R1577     -8.7078070640563965e-01
    z[9,4,1]  R1578     -8.5063123703002930e-01
    z[9,4,1]  R1579     -8.1650906801223755e-01
    z[9,4,1]  R1580     -8.8971352577209473e-01
    z[9,4,1]  R1581     -0.678108274936676
    z[9,4,1]  R1582     -6.2778592109680176e-01
    z[9,4,1]  R1583     -4.3269151449203491e-01
    z[9,4,1]  R1584     -0.902143120765686
    z[9,4,1]  R1585     -8.7095803022384644e-01
    z[9,4,1]  R1586     -6.8296605348587036e-01
    z[9,4,1]  R1587     -3.3892369270324707e-01
    z[9,4,1]  R1588     -7.9935854673385620e-01
    z[9,4,1]  R1589     -7.5542962551116943e-01
    z[9,4,1]  R1590     2.8132668137550354e-01
    z[9,4,1]  R1591     4.2940124869346619e-01
    z[9,4,1]  R1592     7.5325970537960529e-03
    z[9,4,1]  R1593     5.7901513576507568e-01
    z[9,4,1]  R1594     2.0204983651638031e-01
    z[9,4,1]  R1595     8.6046881973743439e-02
    z[9,4,1]  R1596     2.8027138113975525e-01
    z[9,4,1]  R1597     4.9292293190956116e-01
    z[9,4,1]  R1598     3.1568199396133423e-01
    z[9,4,1]  R1599     6.7493891716003418e-01
    z[9,4,1]  R1600     5.9162467718124390e-01
    z[9,4,1]  R1601     1.0954042524099350e-01
    z[9,4,1]  R1602     4.5639863610267639e-01
    z[9,4,1]  R1603     1.4886243641376495e-01
    z[9,4,1]  R1604     -7.7556276321411133e-01
    z[9,4,1]  R1605     -6.4946508407592773e-01
    z[9,4,1]  R1606     -9.1136246919631958e-01
    z[9,4,1]  R1607     -8.9713948965072632e-01
    z[9,4,1]  R1608     -5.0371998548507690e-01
    z[9,4,1]  R1609     -8.0799359083175659e-01
    z[9,4,1]  R1610     -0.572062611579895
    z[9,4,1]  R1611     -7.7519947290420532e-01
    z[9,4,1]  R1612     -0.589427649974823
    z[9,4,1]  R1613     -6.5192335844039917e-01
    z[9,4,1]  R1614     -7.6822096109390259e-01
    z[9,4,1]  R1615     -4.5647367835044861e-01
    z[9,4,1]  R1616     -4.7322675585746765e-01
    z[9,4,1]  R1617     -6.4571005105972290e-01
    z[9,4,1]  R1618     -6.9772607088088989e-01
    z[9,4,1]  R1619     -8.3203715085983276e-01
    z[9,4,1]  R1620     -5.7106351852416992e-01
    z[9,4,1]  R1621     -4.4708859920501709e-01
    z[9,4,1]  R1622     -8.0021435022354126e-01
    z[9,4,1]  R1623     -7.7876365184783936e-01
    z[9,4,1]  R1624     -7.6200026273727417e-01
    z[9,4,1]  R1625     -7.6768219470977783e-01
    z[9,4,1]  R1626     -7.3314839601516724e-01
    z[9,4,1]  R1627     7.0500272512435913e-01
    z[9,4,1]  R1628     4.0483522415161133e-01
    z[9,4,1]  R1629     -5.5599248409271240e-01
    z[9,4,1]  R1630     -6.6381967067718506e-01
    z[9,4,1]  R1631     -9.0491241216659546e-01
    z[9,4,1]  R1632     -0.619698166847229
    z[9,4,1]  R1633     -5.0538444519042969e-01
    z[9,4,1]  R1634     -8.6528658866882324e-01
    z[9,4,1]  R1635     -7.7655076980590820e-01
    z[9,4,1]  R1636     -9.0143078565597534e-01
    z[9,4,1]  R1637     -7.0040273666381836e-01
    z[9,4,1]  R1638     2.1460117772221565e-02
    z[9,4,1]  R1639     -5.5794847011566162e-01
    z[9,4,1]  R1640     -8.7596380710601807e-01
    z[9,4,1]  R1641     -9.1440171003341675e-01
    z[9,4,1]  R1642     -6.7542958259582520e-01
    z[9,4,1]  R1643     -8.2888710498809814e-01
    z[9,4,1]  R1644     -6.4825212955474854e-01
    z[9,4,1]  R1645     -7.9127651453018188e-01
    z[9,4,1]  R1646     -8.2369971275329590e-01
    z[9,4,1]  R1647     -7.7229762077331543e-01
    z[9,4,1]  R1648     -8.8891887664794922e-01
    z[9,4,1]  R1649     -8.8942545652389526e-01
    z[9,4,1]  R1650     -0.79151850938797
    z[9,4,1]  R1651     -8.1461596488952637e-01
    z[9,4,1]  R1652     -8.2109457254409790e-01
    z[9,4,1]  R1653     -1.7773827910423279e-01
    z[9,4,1]  R1654     -7.5015085935592651e-01
    z[9,4,1]  R1655     -7.3993182182312012e-01
    z[9,4,1]  R1656     1.6175159811973572e-01
    z[9,4,1]  R1657     0.035215113312006
    z[9,4,1]  R1658     -0.937619686126709
    z[9,4,1]  R1659     -8.9324432611465454e-01
    z[9,4,1]  R1660     -7.7389258146286011e-01
    z[9,4,1]  R1661     -8.1678217649459839e-01
    z[9,4,1]  R1662     -4.9182184040546417e-02
    z[9,4,1]  R1663     4.4177651405334473e-01
    z[9,4,1]  R1664     4.1015404462814331e-01
    z[9,4,1]  R1665     3.9751288294792175e-01
    z[9,4,2]  R40       1
    z[9,4,2]  R85       -1
    z[9,4,2]  R1546     -1
    z[9,4,2]  R1547     1
    z[9,4,2]  R1556     6.5449941158294678e-01
    z[9,4,2]  R1557     -4.3286693096160889e-01
    z[9,4,2]  R1558     1.2441541254520416e-01
    z[9,4,2]  R1559     -1.7065811157226562e-01
    z[9,4,2]  R1560     6.5025717020034790e-01
    z[9,4,2]  R1561     -1.3663330674171448e-01
    z[9,4,2]  R1562     4.7430303692817688e-01
    z[9,4,2]  R1563     -5.1721256971359253e-01
    z[9,4,2]  R1564     -8.2653927803039551e-01
    z[9,4,2]  R1565     -0.553094744682312
    z[9,4,2]  R1566     -8.1289076805114746e-01
    z[9,4,2]  R1567     -4.1897448897361755e-01
    z[9,4,2]  R1568     -7.3320406675338745e-01
    z[9,4,2]  R1569     -3.8440600037574768e-01
    z[9,4,2]  R1570     -5.3828316926956177e-01
    z[9,4,2]  R1571     4.1125959157943726e-01
    z[9,4,2]  R1572     -5.0224578380584717e-01
    z[9,4,2]  R1573     -0.235634446144104
    z[9,4,2]  R1574     3.0603477358818054e-01
    z[9,4,2]  R1575     3.4926262497901917e-01
    z[9,4,2]  R1576     -2.6990300416946411e-01
    z[9,4,2]  R1577     2.1224774420261383e-01
    z[9,4,2]  R1578     4.4793450832366943e-01
    z[9,4,2]  R1579     4.8370894789695740e-01
    z[9,4,2]  R1580     -1.0303554683923721e-01
    z[9,4,2]  R1581     -5.9813553094863892e-01
    z[9,4,2]  R1582     -4.4539690017700195e-01
    z[9,4,2]  R1583     -6.5150165557861328e-01
    z[9,4,2]  R1584     -2.7931925654411316e-01
    z[9,4,2]  R1585     -2.8034433722496033e-01
    z[9,4,2]  R1586     -1.2294710427522659e-01
    z[9,4,2]  R1587     -8.6787927150726318e-01
    z[9,4,2]  R1588     2.5643259286880493e-01
    z[9,4,2]  R1589     2.2316598892211914e-01
    z[9,4,2]  R1590     1.2565425038337708e-01
    z[9,4,2]  R1591     -7.2990462183952332e-02
    z[9,4,2]  R1592     -1.2438035011291504e-01
    z[9,4,2]  R1593     -1.6645358502864838e-01
    z[9,4,2]  R1594     -9.1014020144939423e-02
    z[9,4,2]  R1595     0.626151442527771
    z[9,4,2]  R1596     -2.4900703132152557e-01
    z[9,4,2]  R1597     1.0611472278833389e-01
    z[9,4,2]  R1598     9.1054454445838928e-02
    z[9,4,2]  R1599     -1.5911756455898285e-01
    z[9,4,2]  R1600     3.1160160899162292e-01
    z[9,4,2]  R1601     -1.1797026731073856e-02
    z[9,4,2]  R1602     -2.3035086691379547e-01
    z[9,4,2]  R1603     8.2876391708850861e-02
    z[9,4,2]  R1604     -3.3033519983291626e-01
    z[9,4,2]  R1605     -4.6171391010284424e-01
    z[9,4,2]  R1606     -3.1455031037330627e-01
    z[9,4,2]  R1607     1.0135427117347717e-01
    z[9,4,2]  R1608     -4.3890568614006042e-01
    z[9,4,2]  R1609     0.136931911110878
    z[9,4,2]  R1610     -6.8476319313049316e-01
    z[9,4,2]  R1611     -9.9444175139069557e-03
    z[9,4,2]  R1612     -4.6268993616104126e-01
    z[9,4,2]  R1613     -5.4729342460632324e-01
    z[9,4,2]  R1614     2.4883045256137848e-01
    z[9,4,2]  R1615     -6.9945007562637329e-01
    z[9,4,2]  R1616     -8.0823624134063721e-01
    z[9,4,2]  R1617     -6.4133191108703613e-01
    z[9,4,2]  R1618     -1.8304759636521339e-02
    z[9,4,2]  R1619     2.4319043755531311e-01
    z[9,4,2]  R1620     -6.8353205919265747e-01
    z[9,4,2]  R1621     -7.9876106977462769e-01
    z[9,4,2]  R1622     6.4935930073261261e-02
    z[9,4,2]  R1623     2.7095427736639977e-02
    z[9,4,2]  R1624     -1.4205268025398254e-01
    z[9,4,2]  R1625     -9.6215203404426575e-02
    z[9,4,2]  R1626     -1.0724537819623947e-01
    z[9,4,2]  R1627     -1.6476549208164215e-02
    z[9,4,2]  R1628     -2.6660233736038208e-01
    z[9,4,2]  R1629     -7.3061013221740723e-01
    z[9,4,2]  R1630     -6.6492223739624023e-01
    z[9,4,2]  R1631     1.3585336506366730e-01
    z[9,4,2]  R1632     -5.5617189407348633e-01
    z[9,4,2]  R1633     -5.2972149848937988e-01
    z[9,4,2]  R1634     -1.8511453270912170e-01
    z[9,4,2]  R1635     -2.8458639979362488e-01
    z[9,4,2]  R1636     3.7137895822525024e-02
    z[9,4,2]  R1637     -6.5151625871658325e-01
    z[9,4,2]  R1638     -4.9594688415527344e-01
    z[9,4,2]  R1639     -5.4087972640991211e-01
    z[9,4,2]  R1640     -1.7047224566340446e-02
    z[9,4,2]  R1641     2.7067303657531738e-01
    z[9,4,2]  R1642     -2.6017594337463379e-01
    z[9,4,2]  R1643     3.2183980941772461e-01
    z[9,4,2]  R1644     -1.6664777696132660e-01
    z[9,4,2]  R1645     -2.0325869321823120e-02
    z[9,4,2]  R1646     1.1372482031583786e-01
    z[9,4,2]  R1647     -5.3918910026550293e-01
    z[9,4,2]  R1648     -2.1300375461578369e-01
    z[9,4,2]  R1649     1.8503311276435852e-01
    z[9,4,2]  R1650     -3.3325843513011932e-02
    z[9,4,2]  R1651     -3.8550995290279388e-02
    z[9,4,2]  R1652     2.6382654905319214e-01
    z[9,4,2]  R1653     -9.6111074090003967e-02
    z[9,4,2]  R1654     -1.9729016721248627e-01
    z[9,4,2]  R1655     1.6195631027221680e-01
    z[9,4,2]  R1656     -1.3061526417732239e-01
    z[9,4,2]  R1657     -4.5849704742431641e-01
    z[9,4,2]  R1658     5.3239818662405014e-02
    z[9,4,2]  R1659     -4.7729674726724625e-02
    z[9,4,2]  R1660     -9.9238239228725433e-02
    z[9,4,2]  R1661     -1.8111547827720642e-01
    z[9,4,2]  R1662     -9.2884004116058350e-03
    z[9,4,2]  R1663     0.0757242813706398
    z[9,4,2]  R1664     0.326010137796402
    z[9,4,2]  R1665     1.1096108704805374e-01
    z[9,4,3]  R41       1
    z[9,4,3]  R86       -1
    z[9,4,3]  R1548     -1
    z[9,4,3]  R1549     1
    z[9,4,3]  R1556     -3.3724498003721237e-02
    z[9,4,3]  R1557     3.1078770756721497e-01
    z[9,4,3]  R1558     -4.5165005326271057e-01
    z[9,4,3]  R1559     1.4078325033187866e-01
    z[9,4,3]  R1560     -3.4588072448968887e-02
    z[9,4,3]  R1561     -1.2074072659015656e-01
    z[9,4,3]  R1562     2.5519285351037979e-02
    z[9,4,3]  R1563     -5.5568039417266846e-01
    z[9,4,3]  R1564     -1.9025236368179321e-01
    z[9,4,3]  R1565     -2.2748155891895294e-01
    z[9,4,3]  R1566     2.0364774763584137e-01
    z[9,4,3]  R1567     -5.9576690196990967e-01
    z[9,4,3]  R1568     -5.6127548217773438e-01
    z[9,4,3]  R1569     -6.4333927631378174e-01
    z[9,4,3]  R1570     -4.2715385556221008e-01
    z[9,4,3]  R1571     7.4921971559524536e-01
    z[9,4,3]  R1572     -1.9616352021694183e-01
    z[9,4,3]  R1573     1.6831265389919281e-01
    z[9,4,3]  R1574     -6.8378285504877567e-03
    z[9,4,3]  R1575     9.6730358898639679e-02
    z[9,4,3]  R1576     1.3995271921157837e-01
    z[9,4,3]  R1577     -1.4716957509517670e-01
    z[9,4,3]  R1578     1.1623748391866684e-01
    z[9,4,3]  R1579     -1.3191212713718414e-01
    z[9,4,3]  R1580     1.2486474215984344e-01
    z[9,4,3]  R1581     -5.4926581680774689e-02
    z[9,4,3]  R1582     -3.8294005393981934e-01
    z[9,4,3]  R1583     -3.8724753260612488e-01
    z[9,4,3]  R1584     -1.4854340255260468e-01
    z[9,4,3]  R1585     -7.3607891798019409e-02
    z[9,4,3]  R1586     -0.280905157327652
    z[9,4,3]  R1587     -1.0316666215658188e-01
    z[9,4,3]  R1588     3.2250329852104187e-01
    z[9,4,3]  R1589     1.2399671971797943e-01
    z[9,4,3]  R1590     -2.8652116656303406e-01
    z[9,4,3]  R1591     3.5964247584342957e-01
    z[9,4,3]  R1592     2.0728701353073120e-01
    z[9,4,3]  R1593     -5.2693802118301392e-01
    z[9,4,3]  R1594     -6.0815256834030151e-01
    z[9,4,3]  R1595     2.3736244067549706e-02
    z[9,4,3]  R1596     3.3163344860076904e-01
    z[9,4,3]  R1597     7.7075809240341187e-01
    z[9,4,3]  R1598     8.5122185945510864e-01
    z[9,4,3]  R1599     0.625590443611145
    z[9,4,3]  R1600     6.2528085708618164e-01
    z[9,4,3]  R1601     9.3912720680236816e-01
    z[9,4,3]  R1602     6.7131775617599487e-01
    z[9,4,3]  R1603     7.4573343992233276e-01
    z[9,4,3]  R1604     -1.6835495829582214e-01
    z[9,4,3]  R1605     -1.0739649832248688e-01
    z[9,4,3]  R1606     -2.1419250965118408e-01
    z[9,4,3]  R1607     -1.6170606017112732e-01
    z[9,4,3]  R1608     -6.2765496969223022e-01
    z[9,4,3]  R1609     3.4590315818786621e-01
    z[9,4,3]  R1610     7.9685494303703308e-02
    z[9,4,3]  R1611     1.6408908367156982e-01
    z[9,4,3]  R1612     -2.7080511674284935e-02
    z[9,4,3]  R1613     -3.9443865418434143e-01
    z[9,4,3]  R1614     2.4014189839363098e-01
    z[9,4,3]  R1615     -1.2927785515785217e-01
    z[9,4,3]  R1616     0.0540459118783474
    z[9,4,3]  R1617     7.0934325456619263e-02
    z[9,4,3]  R1618     -5.7334297895431519e-01
    z[9,4,3]  R1619     2.5984886288642883e-01
    z[9,4,3]  R1620     1.1943177878856659e-01
    z[9,4,3]  R1621     -1.2809245288372040e-01
    z[9,4,3]  R1622     9.6224442124366760e-02
    z[9,4,3]  R1623     -3.6655715107917786e-01
    z[9,4,3]  R1624     0.0673820897936821
    z[9,4,3]  R1625     4.0417218208312988e-01
    z[9,4,3]  R1626     2.4162137508392334e-01
    z[9,4,3]  R1627     3.8890153169631958e-01
    z[9,4,3]  R1628     5.7501119375228882e-01
    z[9,4,3]  R1629     -2.3392596840858459e-01
    z[9,4,3]  R1630     4.7164112329483032e-02
    z[9,4,3]  R1631     1.7356034368276596e-02
    z[9,4,3]  R1632     -4.5801591873168945e-01
    z[9,4,3]  R1633     -3.3098584413528442e-01
    z[9,4,3]  R1634     -1.4017856121063232e-01
    z[9,4,3]  R1635     -4.1113600134849548e-01
    z[9,4,3]  R1636     6.7720770835876465e-02
    z[9,4,3]  R1637     -2.7207341790199280e-01
    z[9,4,3]  R1638     2.9130643606185913e-01
    z[9,4,3]  R1639     -0.48995241522789
    z[9,4,3]  R1640     0.154449462890625
    z[9,4,3]  R1641     -2.7712401747703552e-01
    z[9,4,3]  R1642     -3.0682352185249329e-01
    z[9,4,3]  R1643     -8.2297712564468384e-02
    z[9,4,3]  R1644     -3.5729256272315979e-01
    z[9,4,3]  R1645     7.8484527766704559e-02
    z[9,4,3]  R1646     -1.7783628404140472e-01
    z[9,4,3]  R1647     -8.9961253106594086e-02
    z[9,4,3]  R1648     1.8062674999237061e-01
    z[9,4,3]  R1649     -1.3411337137222290e-01
    z[9,4,3]  R1650     -5.0566357374191284e-01
    z[9,4,3]  R1651     2.0418265461921692e-01
    z[9,4,3]  R1652     5.1924187690019608e-02
    z[9,4,3]  R1653     2.6497477293014526e-01
    z[9,4,3]  R1654     -1.2366843223571777e-01
    z[9,4,3]  R1655     -2.4484993517398834e-01
    z[9,4,3]  R1656     2.2541526705026627e-02
    z[9,4,3]  R1657     3.8468053936958313e-01
    z[9,4,3]  R1658     -2.2348362207412720e-01
    z[9,4,3]  R1659     -2.5302174687385559e-01
    z[9,4,3]  R1660     2.5384664535522461e-01
    z[9,4,3]  R1661     5.5681776255369186e-02
    z[9,4,3]  R1662     5.7787474244832993e-02
    z[9,4,3]  R1663     -2.5616058707237244e-01
    z[9,4,3]  R1664     -2.4824059009552002e-01
    z[9,4,3]  R1665     -2.2069209814071655e-01
    z[9,4,4]  R42       1
    z[9,4,4]  R87       -1
    z[9,4,4]  R1550     -1
    z[9,4,4]  R1551     1
    z[9,4,4]  R1556     1.9196658395230770e-03
    z[9,4,4]  R1557     -2.5800400972366333e-01
    z[9,4,4]  R1558     2.5214368104934692e-01
    z[9,4,4]  R1559     -7.0631998777389526e-01
    z[9,4,4]  R1560     -3.7295809388160706e-01
    z[9,4,4]  R1561     2.8939986228942871e-01
    z[9,4,4]  R1562     2.8842580318450928e-01
    z[9,4,4]  R1563     -2.4159426987171173e-01
    z[9,4,4]  R1564     -1.0661655664443970e-01
    z[9,4,4]  R1565     -2.4044224619865417e-01
    z[9,4,4]  R1566     6.5771579742431641e-02
    z[9,4,4]  R1567     -1.4227968454360962e-01
    z[9,4,4]  R1568     -7.1949161589145660e-02
    z[9,4,4]  R1569     -4.2798832058906555e-01
    z[9,4,4]  R1570     -3.4484058618545532e-01
    z[9,4,4]  R1571     4.1967192292213440e-01
    z[9,4,4]  R1572     -0.147585928440094
    z[9,4,4]  R1573     -2.3215298354625702e-01
    z[9,4,4]  R1574     2.6100844144821167e-01
    z[9,4,4]  R1575     -5.4785937070846558e-02
    z[9,4,4]  R1576     -1.7025260627269745e-01
    z[9,4,4]  R1577     2.3434217274188995e-01
    z[9,4,4]  R1578     -1.3723957538604736e-01
    z[9,4,4]  R1579     4.8777997493743896e-02
    z[9,4,4]  R1580     2.6117336750030518e-01
    z[9,4,4]  R1581     -3.1882843375205994e-01
    z[9,4,4]  R1582     -3.8114255666732788e-01
    z[9,4,4]  R1583     -2.6665088534355164e-01
    z[9,4,4]  R1584     -2.0027939975261688e-01
    z[9,4,4]  R1585     -1.7304883897304535e-01
    z[9,4,4]  R1586     -5.3228950500488281e-01
    z[9,4,4]  R1587     -0.00839918851852417
    z[9,4,4]  R1588     2.1437498927116394e-01
    z[9,4,4]  R1589     5.1331651210784912e-01
    z[9,4,4]  R1590     2.0960272848606110e-01
    z[9,4,4]  R1591     -3.7107229232788086e-02
    z[9,4,4]  R1592     -7.0225065946578979e-01
    z[9,4,4]  R1593     -4.7506490349769592e-01
    z[9,4,4]  R1594     -3.6551004648208618e-01
    z[9,4,4]  R1595     -4.3038591742515564e-01
    z[9,4,4]  R1596     4.4329786300659180e-01
    z[9,4,4]  R1597     -5.3792528808116913e-02
    z[9,4,4]  R1598     -4.5282721519470215e-02
    z[9,4,4]  R1599     6.5043777227401733e-02
    z[9,4,4]  R1600     1.4205466210842133e-01
    z[9,4,4]  R1601     8.2762479782104492e-02
    z[9,4,4]  R1602     1.7623870074748993e-01
    z[9,4,4]  R1603     3.9861190319061279e-01
    z[9,4,4]  R1604     -2.0020754635334015e-01
    z[9,4,4]  R1605     -1.9458557665348053e-01
    z[9,4,4]  R1606     -8.5982456803321838e-02
    z[9,4,4]  R1607     1.6359147429466248e-01
    z[9,4,4]  R1608     1.9855398684740067e-02
    z[9,4,4]  R1609     0.178420752286911
    z[9,4,4]  R1610     2.1477924287319183e-01
    z[9,4,4]  R1611     -1.5897114574909210e-01
    z[9,4,4]  R1612     2.6159333065152168e-02
    z[9,4,4]  R1613     1.6524660587310791e-01
    z[9,4,4]  R1614     0.0753258541226387
    z[9,4,4]  R1615     3.3169826865196228e-01
    z[9,4,4]  R1616     0.0411791168153286
    z[9,4,4]  R1617     2.2157919406890869e-01
    z[9,4,4]  R1618     -4.7878913581371307e-02
    z[9,4,4]  R1619     3.7933662533760071e-01
    z[9,4,4]  R1620     -1.9451610743999481e-02
    z[9,4,4]  R1621     1.8401028215885162e-01
    z[9,4,4]  R1622     2.4931050837039948e-01
    z[9,4,4]  R1623     9.7140751779079437e-02
    z[9,4,4]  R1624     4.1627818346023560e-01
    z[9,4,4]  R1625     3.2874977588653564e-01
    z[9,4,4]  R1626     -2.6751694083213806e-01
    z[9,4,4]  R1627     4.1147032380104065e-01
    z[9,4,4]  R1628     4.1332921385765076e-01
    z[9,4,4]  R1629     4.8051834106445312e-02
    z[9,4,4]  R1630     1.0222673416137695e-01
    z[9,4,4]  R1631     -2.2699016332626343e-01
    z[9,4,4]  R1632     6.3473515212535858e-02
    z[9,4,4]  R1633     8.2612454891204834e-02
    z[9,4,4]  R1634     -2.8288796544075012e-02
    z[9,4,4]  R1635     7.2491921484470367e-02
    z[9,4,4]  R1636     9.1149166226387024e-02
    z[9,4,4]  R1637     -7.5300313532352448e-02
    z[9,4,4]  R1638     1.7393555492162704e-02
    z[9,4,4]  R1639     8.6900874972343445e-02
    z[9,4,4]  R1640     -1.9447323679924011e-01
    z[9,4,4]  R1641     1.8232997506856918e-02
    z[9,4,4]  R1642     -3.6176049709320068e-01
    z[9,4,4]  R1643     2.2238619625568390e-01
    z[9,4,4]  R1644     -9.1401286423206329e-02
    z[9,4,4]  R1645     3.6532336473464966e-01
    z[9,4,4]  R1646     1.1237250268459320e-01
    z[9,4,4]  R1647     1.1224296689033508e-01
    z[9,4,4]  R1648     7.5787985697388649e-03
    z[9,4,4]  R1649     6.4320690929889679e-02
    z[9,4,4]  R1650     -1.3239432871341705e-01
    z[9,4,4]  R1651     2.5776756927371025e-02
    z[9,4,4]  R1652     3.5215219855308533e-01
    z[9,4,4]  R1653     6.4503157138824463e-01
    z[9,4,4]  R1654     4.3805581331253052e-01
    z[9,4,4]  R1655     -1.5390609204769135e-01
    z[9,4,4]  R1656     6.7675316333770752e-01
    z[9,4,4]  R1657     -3.6997926235198975e-01
    z[9,4,4]  R1658     -6.6607259213924408e-02
    z[9,4,4]  R1659     1.2064320594072342e-01
    z[9,4,4]  R1660     2.6603901386260986e-01
    z[9,4,4]  R1661     4.8441749811172485e-01
    z[9,4,4]  R1662     7.0256847143173218e-01
    z[9,4,4]  R1663     4.4332712888717651e-01
    z[9,4,4]  R1664     3.2140663266181946e-01
    z[9,4,4]  R1665     1.5471938252449036e-01
    z[9,4,5]  R43       1
    z[9,4,5]  R88       -1
    z[9,4,5]  R1552     -1
    z[9,4,5]  R1553     1
    z[9,4,5]  R1556     5.0063580274581909e-01
    z[9,4,5]  R1557     -1.9602391123771667e-01
    z[9,4,5]  R1558     2.8628429770469666e-01
    z[9,4,5]  R1559     1.0761862248182297e-01
    z[9,4,5]  R1560     -6.5537005662918091e-01
    z[9,4,5]  R1561     -4.2324599623680115e-01
    z[9,4,5]  R1562     -2.0733886957168579e-01
    z[9,4,5]  R1563     -3.0481913685798645e-01
    z[9,4,5]  R1564     -1.4984667301177979e-01
    z[9,4,5]  R1565     -3.7876769900321960e-01
    z[9,4,5]  R1566     1.1142546683549881e-01
    z[9,4,5]  R1567     1.6161814332008362e-01
    z[9,4,5]  R1568     1.1382610350847244e-01
    z[9,4,5]  R1569     -1.1267782747745514e-01
    z[9,4,5]  R1570     -3.6104604601860046e-01
    z[9,4,5]  R1571     2.3703837394714355e-01
    z[9,4,5]  R1572     -1.6992285847663879e-01
    z[9,4,5]  R1573     -1.0494102537631989e-01
    z[9,4,5]  R1574     -2.7235141023993492e-02
    z[9,4,5]  R1575     -7.3739282786846161e-02
    z[9,4,5]  R1576     5.1846086978912354e-01
    z[9,4,5]  R1577     1.5279792249202728e-01
    z[9,4,5]  R1578     -0.00711454264819622
    z[9,4,5]  R1579     -1.1322123557329178e-01
    z[9,4,5]  R1580     0.275865763425827
    z[9,4,5]  R1581     2.6888754963874817e-01
    z[9,4,5]  R1582     -2.3302617669105530e-01
    z[9,4,5]  R1583     3.9052048325538635e-01
    z[9,4,5]  R1584     -6.3229940831661224e-02
    z[9,4,5]  R1585     6.6179037094116211e-03
    z[9,4,5]  R1586     -0.114285409450531
    z[9,4,5]  R1587     1.0628158599138260e-01
    z[9,4,5]  R1588     1.1328091472387314e-01
    z[9,4,5]  R1589     5.9948820620775223e-02
    z[9,4,5]  R1590     -2.9125988483428955e-01
    z[9,4,5]  R1591     2.8395307064056396e-01
    z[9,4,5]  R1592     3.8931244611740112e-01
    z[9,4,5]  R1593     -1.9168801605701447e-01
    z[9,4,5]  R1594     5.8619940280914307e-01
    z[9,4,5]  R1595     -2.4412751197814941e-02
    z[9,4,5]  R1596     -2.9837164282798767e-01
    z[9,4,5]  R1597     -2.8865331411361694e-01
    z[9,4,5]  R1598     1.4389933645725250e-01
    z[9,4,5]  R1599     -9.0629987418651581e-02
    z[9,4,5]  R1600     -3.2613296061754227e-02
    z[9,4,5]  R1601     -1.4074572920799255e-01
    z[9,4,5]  R1602     3.2871791720390320e-01
    z[9,4,5]  R1603     1.4860203862190247e-01
    z[9,4,5]  R1604     -4.4143116474151611e-01
    z[9,4,5]  R1605     -5.3421151638031006e-01
    z[9,4,5]  R1606     1.0798743367195129e-01
    z[9,4,5]  R1607     -2.9459038376808167e-01
    z[9,4,5]  R1608     -2.6060670614242554e-01
    z[9,4,5]  R1609     -7.2829827666282654e-02
    z[9,4,5]  R1610     -2.1018789708614349e-01
    z[9,4,5]  R1611     7.5851596891880035e-02
    z[9,4,5]  R1612     -3.5586071014404297e-01
    z[9,4,5]  R1613     -2.5549063086509705e-01
    z[9,4,5]  R1614     1.1772985756397247e-01
    z[9,4,5]  R1615     -2.9082307219505310e-01
    z[9,4,5]  R1616     -7.5395785272121429e-02
    z[9,4,5]  R1617     -2.9266867041587830e-01
    z[9,4,5]  R1618     -3.0513831973075867e-01
    z[9,4,5]  R1619     3.6092754453420639e-02
    z[9,4,5]  R1620     -0.0642428919672966
    z[9,4,5]  R1621     -1.3352457899600267e-03
    z[9,4,5]  R1622     2.5755900144577026e-01
    z[9,4,5]  R1623     -3.2464000582695007e-01
    z[9,4,5]  R1624     -0.275749534368515
    z[9,4,5]  R1625     2.5408431887626648e-01
    z[9,4,5]  R1626     -0.0939953550696373
    z[9,4,5]  R1627     -2.5288176536560059e-01
    z[9,4,5]  R1628     -2.3178742825984955e-01
    z[9,4,5]  R1629     -0.127928227186203
    z[9,4,5]  R1630     -3.0584850907325745e-01
    z[9,4,5]  R1631     -2.4475468695163727e-01
    z[9,4,5]  R1632     -6.1415430158376694e-02
    z[9,4,5]  R1633     -3.7571245431900024e-01
    z[9,4,5]  R1634     -2.3396830260753632e-01
    z[9,4,5]  R1635     -2.2887107729911804e-01
    z[9,4,5]  R1636     -2.9069520533084869e-02
    z[9,4,5]  R1637     -0.0584476999938488
    z[9,4,5]  R1638     -1.2071265280246735e-01
    z[9,4,5]  R1639     -3.0844411253929138e-01
    z[9,4,5]  R1640     -2.5860235095024109e-01
    z[9,4,5]  R1641     -2.2496019955724478e-03
    z[9,4,5]  R1642     -2.4236641824245453e-01
    z[9,4,5]  R1643     7.9531274735927582e-02
    z[9,4,5]  R1644     -4.3636941909790039e-01
    z[9,4,5]  R1645     -4.3903324007987976e-01
    z[9,4,5]  R1646     -9.9482253193855286e-02
    z[9,4,5]  R1647     -2.7293553948402405e-01
    z[9,4,5]  R1648     2.2007305920124054e-01
    z[9,4,5]  R1649     1.1336227878928185e-02
    z[9,4,5]  R1650     -1.5972651541233063e-01
    z[9,4,5]  R1651     4.2401656508445740e-01
    z[9,4,5]  R1652     1.3125570118427277e-01
    z[9,4,5]  R1653     4.9722746014595032e-02
    z[9,4,5]  R1654     -9.0187273919582367e-02
    z[9,4,5]  R1655     0.148108571767807
    z[9,4,5]  R1656     -4.6637412905693054e-01
    z[9,4,5]  R1657     -1.2660789489746094e-01
    z[9,4,5]  R1658     -2.2432606667280197e-02
    z[9,4,5]  R1659     -3.3498124685138464e-03
    z[9,4,5]  R1660     -2.0628614723682404e-01
    z[9,4,5]  R1661     -6.0372814536094666e-02
    z[9,4,5]  R1662     -5.1319307088851929e-01
    z[9,4,5]  R1663     -1.2096808850765228e-01
    z[9,4,5]  R1664     -1.0360217653214931e-02
    z[9,4,5]  R1665     1.5313176810741425e-01
    z[9,4,6]  R44       1
    z[9,4,6]  R89       -1
    z[9,4,6]  R1554     -1
    z[9,4,6]  R1555     1
    z[9,4,6]  R1556     -5.0835594534873962e-02
    z[9,4,6]  R1557     2.5987529754638672e-01
    z[9,4,6]  R1558     3.6881312727928162e-02
    z[9,4,6]  R1559     -5.0899302959442139e-01
    z[9,4,6]  R1560     -5.8440122753381729e-02
    z[9,4,6]  R1561     3.3064281940460205e-01
    z[9,4,6]  R1562     -4.4781979173421860e-02
    z[9,4,6]  R1563     -6.2554776668548584e-02
    z[9,4,6]  R1564     7.2125345468521118e-02
    z[9,4,6]  R1565     3.1975358724594116e-02
    z[9,4,6]  R1566     -2.5159576535224915e-01
    z[9,4,6]  R1567     -1.5411528944969177e-01
    z[9,4,6]  R1568     1.8116460740566254e-01
    z[9,4,6]  R1569     8.7155632674694061e-02
    z[9,4,6]  R1570     2.5628376007080078e-01
    z[9,4,6]  R1571     -8.1337183713912964e-02
    z[9,4,6]  R1572     3.6749577522277832e-01
    z[9,4,6]  R1573     -2.3170365020632744e-02
    z[9,4,6]  R1574     -1.9183224439620972e-01
    z[9,4,6]  R1575     -3.1564655900001526e-01
    z[9,4,6]  R1576     -1.9450746476650238e-01
    z[9,4,6]  R1577     1.0049699246883392e-01
    z[9,4,6]  R1578     -7.6333783566951752e-02
    z[9,4,6]  R1579     0.0470597967505455
    z[9,4,6]  R1580     1.8185776472091675e-01
    z[9,4,6]  R1581     -1.8424183130264282e-02
    z[9,4,6]  R1582     2.0998762547969818e-01
    z[9,4,6]  R1583     -0.0609787218272686
    z[9,4,6]  R1584     1.3025906682014465e-01
    z[9,4,6]  R1585     -3.1629326939582825e-01
    z[9,4,6]  R1586     -1.0128965228796005e-01
    z[9,4,6]  R1587     3.2674354314804077e-01
    z[9,4,6]  R1588     0.0331374928355217
    z[9,4,6]  R1589     0.31126868724823
    z[9,4,6]  R1590     2.8060242533683777e-01
    z[9,4,6]  R1591     -7.3620069026947021e-01
    z[9,4,6]  R1592     3.4527981281280518e-01
    z[9,4,6]  R1593     -2.0684666931629181e-01
    z[9,4,6]  R1594     3.0820357799530029e-01
    z[9,4,6]  R1595     -0.128057062625885
    z[9,4,6]  R1596     6.4315706491470337e-01
    z[9,4,6]  R1597     1.2790703773498535e-01
    z[9,4,6]  R1598     -2.7893617749214172e-01
    z[9,4,6]  R1599     1.7463859915733337e-01
    z[9,4,6]  R1600     1.9452748820185661e-02
    z[9,4,6]  R1601     -3.7492178380489349e-02
    z[9,4,6]  R1602     -5.4711066186428070e-02
    z[9,4,6]  R1603     3.8416630029678345e-01
    z[9,4,6]  R1604     0.128541499376297
    z[9,4,6]  R1605     -1.7142567038536072e-01
    z[9,4,6]  R1606     3.5137572558596730e-04
    z[9,4,6]  R1607     -1.0635446012020111e-01
    z[9,4,6]  R1608     3.9185993373394012e-03
    z[9,4,6]  R1609     -3.9791685342788696e-01
    z[9,4,6]  R1610     1.1854583024978638e-01
    z[9,4,6]  R1611     3.4693002700805664e-01
    z[9,4,6]  R1612     2.9228290915489197e-01
    z[9,4,6]  R1613     -1.6315580904483795e-01
    z[9,4,6]  R1614     4.1230472922325134e-01
    z[9,4,6]  R1615     -3.0129143595695496e-01
    z[9,4,6]  R1616     -2.9035961627960205e-01
    z[9,4,6]  R1617     1.4775559306144714e-01
    z[9,4,6]  R1618     -2.9739844799041748e-01
    z[9,4,6]  R1619     1.8891172111034393e-01
    z[9,4,6]  R1620     -2.3863962292671204e-01
    z[9,4,6]  R1621     -1.5067948400974274e-01
    z[9,4,6]  R1622     2.7361556887626648e-01
    z[9,4,6]  R1623     -2.0225435495376587e-02
    z[9,4,6]  R1624     2.4946808815002441e-01
    z[9,4,6]  R1625     4.7203049063682556e-02
    z[9,4,6]  R1626     -4.6506536006927490e-01
    z[9,4,6]  R1627     3.3451551198959351e-01
    z[9,4,6]  R1628     -4.1838163137435913e-01
    z[9,4,6]  R1629     -2.3472876846790314e-01
    z[9,4,6]  R1630     1.0016328841447830e-01
    z[9,4,6]  R1631     1.6122755408287048e-01
    z[9,4,6]  R1632     9.5639698207378387e-02
    z[9,4,6]  R1633     -4.5434826612472534e-01
    z[9,4,6]  R1634     -3.2423120737075806e-01
    z[9,4,6]  R1635     -2.6547786593437195e-01
    z[9,4,6]  R1636     -3.2465690374374390e-01
    z[9,4,6]  R1637     2.2864004597067833e-02
    z[9,4,6]  R1638     -3.6312052607536316e-01
    z[9,4,6]  R1639     -2.0985266566276550e-01
    z[9,4,6]  R1640     -2.3246988654136658e-01
    z[9,4,6]  R1641     -1.0503920912742615e-01
    z[9,4,6]  R1642     -3.7892490625381470e-01
    z[9,4,6]  R1643     3.4058490395545959e-01
    z[9,4,6]  R1644     -1.3030645251274109e-01
    z[9,4,6]  R1645     8.6043469607830048e-02
    z[9,4,6]  R1646     4.5605826377868652e-01
    z[9,4,6]  R1647     -0.087053082883358
    z[9,4,6]  R1648     -2.8867509961128235e-01
    z[9,4,6]  R1649     3.6522147059440613e-01
    z[9,4,6]  R1650     0.0693008303642273
    z[9,4,6]  R1651     1.1321227252483368e-01
    z[9,4,6]  R1652     -1.2769292108714581e-02
    z[9,4,6]  R1653     -2.2302225232124329e-01
    z[9,4,6]  R1654     3.5758644342422485e-01
    z[9,4,6]  R1655     -4.6779972314834595e-01
    z[9,4,6]  R1656     -2.5400716066360474e-01
    z[9,4,6]  R1657     -2.3589698597788811e-02
    z[9,4,6]  R1658     4.9371778964996338e-02
    z[9,4,6]  R1659     -3.2521459460258484e-01
    z[9,4,6]  R1660     1.8636316061019897e-01
    z[9,4,6]  R1661     1.5397830307483673e-01
    z[9,4,6]  R1662     1.4918014407157898e-01
    z[9,4,6]  R1663     1.9710658490657806e-01
    z[9,4,6]  R1664     -1.4122587442398071e-01
    z[9,4,6]  R1665     0.447965532541275
    z[5,6,0]  R47       -1
    z[5,6,0]  R56       1
    z[5,6,0]  R1756     -1
    z[5,6,0]  R1757     1
    z[5,6,0]  R1770     -1.3222447037696838e-01
    z[5,6,0]  R1771     4.4330772757530212e-01
    z[5,6,0]  R1772     5.1061475276947021e-01
    z[5,6,0]  R1773     3.6846846342086792e-01
    z[5,6,0]  R1774     -1.4600045979022980e-01
    z[5,6,0]  R1775     5.6267328560352325e-02
    z[5,6,0]  R1776     -2.3827967047691345e-01
    z[5,6,0]  R1777     3.1948262453079224e-01
    z[5,6,0]  R1778     5.4506051540374756e-01
    z[5,6,0]  R1779     -4.5493689179420471e-01
    z[5,6,0]  R1780     -5.8300759643316269e-02
    z[5,6,0]  R1781     4.5845970511436462e-01
    z[5,6,0]  R1782     1.2683887779712677e-01
    z[5,6,0]  R1783     -1.1591664701700211e-01
    z[5,6,0]  R1784     2.8984561562538147e-01
    z[5,6,0]  R1785     4.3581213802099228e-02
    z[5,6,0]  R1786     2.8131446242332458e-01
    z[5,6,0]  R1787     3.0815801024436951e-01
    z[5,6,0]  R1788     3.6679348349571228e-01
    z[5,6,0]  R1789     2.0239928364753723e-01
    z[5,6,0]  R1790     3.4378626942634583e-01
    z[5,6,0]  R1791     3.5512766242027283e-01
    z[5,6,0]  R1792     0.172831192612648
    z[5,6,0]  R1793     -1.1071722209453583e-01
    z[5,6,0]  R1794     -1.2994001805782318e-01
    z[5,6,0]  R1795     -4.2620870471000671e-01
    z[5,6,0]  R1796     1.7344912886619568e-01
    z[5,6,0]  R1797     4.4796681404113770e-01
    z[5,6,0]  R1798     -7.8268569707870483e-01
    z[5,6,0]  R1799     -6.5067225694656372e-01
    z[5,6,0]  R1800     -4.4846507906913757e-01
    z[5,6,0]  R1801     -2.1969492081552744e-03
    z[5,6,0]  R1802     -1.2974171340465546e-01
    z[5,6,0]  R1803     -1.0507542639970779e-01
    z[5,6,0]  R1804     -6.4282584190368652e-01
    z[5,6,0]  R1805     -5.9012347459793091e-01
    z[5,6,0]  R1806     3.8122949004173279e-01
    z[5,6,0]  R1807     -4.8667392134666443e-01
    z[5,6,0]  R1808     -3.3006361126899719e-01
    z[5,6,0]  R1809     2.1405370533466339e-01
    z[5,6,0]  R1810     3.5783922672271729e-01
    z[5,6,0]  R1811     0.214617520570755
    z[5,6,0]  R1812     2.5890854001045227e-01
    z[5,6,0]  R1813     -4.6143096685409546e-01
    z[5,6,0]  R1814     -0.210273876786232
    z[5,6,0]  R1815     -1.8114566802978516e-01
    z[5,6,0]  R1816     3.3847063779830933e-01
    z[5,6,0]  R1817     2.8565225005149841e-01
    z[5,6,0]  R1818     4.1506037116050720e-01
    z[5,6,0]  R1819     3.2135307788848877e-01
    z[5,6,0]  R1820     1.8740488216280937e-02
    z[5,6,0]  R1821     4.8412081599235535e-01
    z[5,6,0]  R1822     -2.1803854405879974e-01
    z[5,6,0]  R1823     0.50909823179245
    z[5,6,0]  R1824     7.1029466390609741e-01
    z[5,6,0]  R1825     -5.5524501949548721e-02
    z[5,6,0]  R1826     -6.1685512773692608e-03
    z[5,6,0]  R1827     3.7835661321878433e-02
    z[5,6,0]  R1828     5.6850533932447433e-02
    z[5,6,0]  R1829     2.5100933387875557e-02
    z[5,6,0]  R1830     4.4018816202878952e-02
    z[5,6,0]  R1831     -1.1822836101055145e-01
    z[5,6,0]  R1832     -3.6960181593894958e-01
    z[5,6,0]  R1833     3.4233191609382629e-01
    z[5,6,0]  R1834     3.9878332614898682e-01
    z[5,6,0]  R1835     3.1251686811447144e-01
    z[5,6,0]  R1836     -1.7355673015117645e-01
    z[5,6,0]  R1837     2.4099587462842464e-03
    z[5,6,0]  R1838     2.7057060971856117e-02
    z[5,6,0]  R1839     -4.4093459844589233e-01
    z[5,6,0]  R1840     4.1839978098869324e-01
    z[5,6,0]  R1841     3.5848870873451233e-01
    z[5,6,0]  R1842     2.2785486280918121e-01
    z[5,6,0]  R1843     3.6973163485527039e-01
    z[5,6,0]  R1844     -4.7974463552236557e-02
    z[5,6,0]  R1845     6.8158395588397980e-02
    z[5,6,0]  R1846     2.1467141807079315e-01
    z[5,6,0]  R1847     8.5718967020511627e-02
    z[5,6,0]  R1848     -1.9045859575271606e-01
    z[5,6,0]  R1849     2.1406984329223633e-01
    z[5,6,0]  R1850     4.9754351377487183e-01
    z[5,6,0]  R1851     2.3441560566425323e-01
    z[5,6,0]  R1852     5.6777395308017731e-02
    z[5,6,0]  R1853     6.9153445959091187e-01
    z[5,6,0]  R1854     8.4705986082553864e-02
    z[5,6,0]  R1855     -3.3468225598335266e-01
    z[5,6,0]  R1856     -1.9302885234355927e-01
    z[5,6,0]  R1857     -4.2197167873382568e-01
    z[5,6,0]  R1858     -6.2555056810379028e-01
    z[5,6,0]  R1859     -1.4626176655292511e-01
    z[5,6,1]  R48       -1
    z[5,6,1]  R57       1
    z[5,6,1]  R1758     -1
    z[5,6,1]  R1759     1
    z[5,6,1]  R1770     -1.6161552071571350e-01
    z[5,6,1]  R1771     3.2868351787328720e-02
    z[5,6,1]  R1772     -1.7294447124004364e-01
    z[5,6,1]  R1773     -8.4048956632614136e-02
    z[5,6,1]  R1774     -7.3759369552135468e-02
    z[5,6,1]  R1775     1.5344594419002533e-01
    z[5,6,1]  R1776     -1.3576546311378479e-01
    z[5,6,1]  R1777     -6.5748848021030426e-02
    z[5,6,1]  R1778     -3.4854590892791748e-01
    z[5,6,1]  R1779     1.0795310884714127e-01
    z[5,6,1]  R1780     3.8190406560897827e-01
    z[5,6,1]  R1781     0.508387565612793
    z[5,6,1]  R1782     3.8482189178466797e-01
    z[5,6,1]  R1783     -9.4322019815444946e-01
    z[5,6,1]  R1784     5.6086617708206177e-01
    z[5,6,1]  R1785     8.6465978622436523e-01
    z[5,6,1]  R1786     9.2690610885620117e-01
    z[5,6,1]  R1787     8.7022984027862549e-01
    z[5,6,1]  R1788     6.7859381437301636e-01
    z[5,6,1]  R1789     9.3490058183670044e-01
    z[5,6,1]  R1790     -7.2512662410736084e-01
    z[5,6,1]  R1791     -6.8225187063217163e-01
    z[5,6,1]  R1792     1.0376872122287750e-01
    z[5,6,1]  R1793     -9.1379128396511078e-02
    z[5,6,1]  R1794     -8.3054494857788086e-01
    z[5,6,1]  R1795     -1.7058350145816803e-01
    z[5,6,1]  R1796     -6.9917507469654083e-02
    z[5,6,1]  R1797     -7.9005323350429535e-02
    z[5,6,1]  R1798     -5.7636916637420654e-02
    z[5,6,1]  R1799     -1.2369954586029053e-01
    z[5,6,1]  R1800     2.7449575066566467e-01
    z[5,6,1]  R1801     -8.9514678716659546e-01
    z[5,6,1]  R1802     1.2293367832899094e-01
    z[5,6,1]  R1803     -0.889827311038971
    z[5,6,1]  R1804     -1.3678210973739624e-01
    z[5,6,1]  R1805     -2.3393984884023666e-02
    z[5,6,1]  R1806     3.3358085155487061e-01
    z[5,6,1]  R1807     -7.5847542285919189e-01
    z[5,6,1]  R1808     2.8464773297309875e-01
    z[5,6,1]  R1809     -3.7620380520820618e-01
    z[5,6,1]  R1810     -1.0184162110090256e-01
    z[5,6,1]  R1811     -6.3242278993129730e-02
    z[5,6,1]  R1812     -1.6725437343120575e-01
    z[5,6,1]  R1813     -0.303504079580307
    z[5,6,1]  R1814     -1.7079021036624908e-01
    z[5,6,1]  R1815     -2.0953050255775452e-01
    z[5,6,1]  R1816     0.810470461845398
    z[5,6,1]  R1817     7.7487325668334961e-01
    z[5,6,1]  R1818     6.2169611454010010e-01
    z[5,6,1]  R1819     6.2602823972702026e-01
    z[5,6,1]  R1820     -4.7532996535301208e-01
    z[5,6,1]  R1821     -7.1956586837768555e-01
    z[5,6,1]  R1822     -6.3786417245864868e-01
    z[5,6,1]  R1823     -5.8766132593154907e-01
    z[5,6,1]  R1824     -3.0826598405838013e-01
    z[5,6,1]  R1825     9.4622872769832611e-02
    z[5,6,1]  R1826     -6.0548450797796249e-02
    z[5,6,1]  R1827     -1.1446894705295563e-01
    z[5,6,1]  R1828     -2.2744706273078918e-01
    z[5,6,1]  R1829     -1.1153586953878403e-01
    z[5,6,1]  R1830     5.3579532541334629e-03
    z[5,6,1]  R1831     2.6253911852836609e-01
    z[5,6,1]  R1832     2.2489833831787109e-01
    z[5,6,1]  R1833     4.6520507335662842e-01
    z[5,6,1]  R1834     7.1018069982528687e-02
    z[5,6,1]  R1835     8.5603815317153931e-01
    z[5,6,1]  R1836     2.8711551427841187e-01
    z[5,6,1]  R1837     -9.3920789659023285e-02
    z[5,6,1]  R1838     0.345195472240448
    z[5,6,1]  R1839     1.6721232235431671e-01
    z[5,6,1]  R1840     3.3686190843582153e-01
    z[5,6,1]  R1841     1.3379177451133728e-01
    z[5,6,1]  R1842     1.3943144679069519e-01
    z[5,6,1]  R1843     8.0643719434738159e-01
    z[5,6,1]  R1844     -8.9668609201908112e-02
    z[5,6,1]  R1845     7.9418027400970459e-01
    z[5,6,1]  R1846     0.832773745059967
    z[5,6,1]  R1847     8.4061279892921448e-02
    z[5,6,1]  R1848     3.0079850554466248e-01
    z[5,6,1]  R1849     2.7481248974800110e-01
    z[5,6,1]  R1850     2.9237136244773865e-01
    z[5,6,1]  R1851     7.5944197177886963e-01
    z[5,6,1]  R1852     -4.8153233528137207e-01
    z[5,6,1]  R1853     5.3768402338027954e-01
    z[5,6,1]  R1854     -1.4101034402847290e-01
    z[5,6,1]  R1855     1.4121639728546143e-01
    z[5,6,1]  R1856     3.0635641887784004e-02
    z[5,6,1]  R1857     3.5354387760162354e-01
    z[5,6,1]  R1858     8.2029908895492554e-02
    z[5,6,1]  R1859     -3.7217464298009872e-02
    z[5,6,2]  R49       -1
    z[5,6,2]  R58       1
    z[5,6,2]  R1760     -1
    z[5,6,2]  R1761     1
    z[5,6,2]  R1770     -6.1106526851654053e-01
    z[5,6,2]  R1771     -6.1709243059158325e-01
    z[5,6,2]  R1772     -4.1789144277572632e-01
    z[5,6,2]  R1773     -4.7554206848144531e-01
    z[5,6,2]  R1774     -6.7307806015014648e-01
    z[5,6,2]  R1775     -5.5688637495040894e-01
    z[5,6,2]  R1776     -2.8121533989906311e-01
    z[5,6,2]  R1777     -0.698015570640564
    z[5,6,2]  R1778     -5.9209811687469482e-01
    z[5,6,2]  R1779     8.1579720973968506e-01
    z[5,6,2]  R1780     7.7131724357604980e-01
    z[5,6,2]  R1781     5.6596356630325317e-01
    z[5,6,2]  R1782     0.581097424030304
    z[5,6,2]  R1783     3.5194832831621170e-02
    z[5,6,2]  R1784     5.5022466182708740e-01
    z[5,6,2]  R1785     3.7467437982559204e-01
    z[5,6,2]  R1786     0.185869038105011
    z[5,6,2]  R1787     2.8341516852378845e-01
    z[5,6,2]  R1788     4.6027562022209167e-01
    z[5,6,2]  R1789     1.8549726903438568e-01
    z[5,6,2]  R1790     -5.6430444121360779e-02
    z[5,6,2]  R1791     5.4062587022781372e-01
    z[5,6,2]  R1792     6.0086369514465332e-01
    z[5,6,2]  R1793     -4.1874074935913086e-01
    z[5,6,2]  R1794     5.0818151235580444e-01
    z[5,6,2]  R1795     6.8316936492919922e-01
    z[5,6,2]  R1796     -2.0684944093227386e-01
    z[5,6,2]  R1797     4.9719268083572388e-01
    z[5,6,2]  R1798     5.5894345045089722e-01
    z[5,6,2]  R1799     5.4726940393447876e-01
    z[5,6,2]  R1800     7.3217743635177612e-01
    z[5,6,2]  R1801     4.2120260000228882e-01
    z[5,6,2]  R1802     4.8127841949462891e-01
    z[5,6,2]  R1803     3.1994324922561646e-01
    z[5,6,2]  R1804     5.4639947414398193e-01
    z[5,6,2]  R1805     4.6196100115776062e-01
    z[5,6,2]  R1806     2.2199396789073944e-01
    z[5,6,2]  R1807     -2.1182221174240112e-01
    z[5,6,2]  R1808     -2.3711444437503815e-01
    z[5,6,2]  R1809     -1.7014425992965698e-01
    z[5,6,2]  R1810     -5.0906091928482056e-01
    z[5,6,2]  R1811     -7.5055104494094849e-01
    z[5,6,2]  R1812     -1.8389877676963806e-01
    z[5,6,2]  R1813     -7.7626121044158936e-01
    z[5,6,2]  R1814     -4.3419343233108521e-01
    z[5,6,2]  R1815     2.3305429518222809e-01
    z[5,6,2]  R1816     1.4699342846870422e-01
    z[5,6,2]  R1817     3.3032163977622986e-01
    z[5,6,2]  R1818     0.312933087348938
    z[5,6,2]  R1819     9.1706722974777222e-02
    z[5,6,2]  R1820     -1.0843417793512344e-01
    z[5,6,2]  R1821     1.1218120902776718e-01
    z[5,6,2]  R1822     2.6355206966400146e-01
    z[5,6,2]  R1823     3.7070938944816589e-01
    z[5,6,2]  R1824     2.7988687157630920e-01
    z[5,6,2]  R1825     2.3535709083080292e-01
    z[5,6,2]  R1826     3.2425424456596375e-01
    z[5,6,2]  R1827     -1.5053071081638336e-01
    z[5,6,2]  R1828     -5.3392220288515091e-02
    z[5,6,2]  R1829     -3.6827970296144485e-02
    z[5,6,2]  R1830     8.6703681945800781e-01
    z[5,6,2]  R1831     7.7955722808837891e-01
    z[5,6,2]  R1832     6.8148344755172729e-01
    z[5,6,2]  R1833     6.7619484663009644e-01
    z[5,6,2]  R1834     7.7082967758178711e-01
    z[5,6,2]  R1835     2.3359667509794235e-02
    z[5,6,2]  R1836     7.9174205660820007e-02
    z[5,6,2]  R1837     -1.3105416297912598e-01
    z[5,6,2]  R1838     -6.5037272870540619e-02
    z[5,6,2]  R1839     -5.9566110372543335e-02
    z[5,6,2]  R1840     6.9493138790130615e-01
    z[5,6,2]  R1841     7.6160228252410889e-01
    z[5,6,2]  R1842     -1.2034597247838974e-01
    z[5,6,2]  R1843     1.5307830274105072e-01
    z[5,6,2]  R1844     2.7876922860741615e-02
    z[5,6,2]  R1845     1.5207213163375854e-01
    z[5,6,2]  R1846     4.2497169971466064e-01
    z[5,6,2]  R1847     2.0644725300371647e-03
    z[5,6,2]  R1848     3.1650561839342117e-02
    z[5,6,2]  R1849     2.7639198303222656e-01
    z[5,6,2]  R1850     6.5993010997772217e-01
    z[5,6,2]  R1851     4.0878447890281677e-01
    z[5,6,2]  R1852     7.0100909471511841e-01
    z[5,6,2]  R1853     -1.0121328383684158e-01
    z[5,6,2]  R1854     1.4600278437137604e-01
    z[5,6,2]  R1855     -4.0214333683252335e-02
    z[5,6,2]  R1856     -9.1538235545158386e-02
    z[5,6,2]  R1857     0.645959198474884
    z[5,6,2]  R1858     7.2471112012863159e-01
    z[5,6,2]  R1859     6.1217653751373291e-01
    z[5,6,3]  R50       -1
    z[5,6,3]  R59       1
    z[5,6,3]  R1762     -1
    z[5,6,3]  R1763     1
    z[5,6,3]  R1770     -5.2917140722274780e-01
    z[5,6,3]  R1771     -3.5314863920211792e-01
    z[5,6,3]  R1772     -6.0037565231323242e-01
    z[5,6,3]  R1773     -5.5758535861968994e-01
    z[5,6,3]  R1774     -1.6042657196521759e-01
    z[5,6,3]  R1775     -3.3760768175125122e-01
    z[5,6,3]  R1776     -7.8490930795669556e-01
    z[5,6,3]  R1777     4.5755021274089813e-02
    z[5,6,3]  R1778     -2.9018133878707886e-01
    z[5,6,3]  R1779     1.0989991575479507e-01
    z[5,6,3]  R1780     3.5300999879837036e-01
    z[5,6,3]  R1781     3.8653177022933960e-01
    z[5,6,3]  R1782     4.5291340351104736e-01
    z[5,6,3]  R1783     1.9377514719963074e-01
    z[5,6,3]  R1784     1.3471165299415588e-01
    z[5,6,3]  R1785     2.3421159386634827e-01
    z[5,6,3]  R1786     1.1017097532749176e-01
    z[5,6,3]  R1787     7.6226450502872467e-02
    z[5,6,3]  R1788     2.0796790719032288e-01
    z[5,6,3]  R1789     1.4745345711708069e-01
    z[5,6,3]  R1790     1.7238780856132507e-01
    z[5,6,3]  R1791     -1.9658863544464111e-01
    z[5,6,3]  R1792     6.6063910722732544e-01
    z[5,6,3]  R1793     3.6536341905593872e-01
    z[5,6,3]  R1794     -1.4940737187862396e-01
    z[5,6,3]  R1795     4.5457309484481812e-01
    z[5,6,3]  R1796     2.2941657900810242e-01
    z[5,6,3]  R1797     -4.5434886217117310e-01
    z[5,6,3]  R1798     6.7545793950557709e-02
    z[5,6,3]  R1799     -3.8898780941963196e-02
    z[5,6,3]  R1800     1.7104667425155640e-01
    z[5,6,3]  R1801     -0.0592644065618515
    z[5,6,3]  R1802     7.8499954938888550e-01
    z[5,6,3]  R1803     -1.0627415776252747e-01
    z[5,6,3]  R1804     4.4233056902885437e-01
    z[5,6,3]  R1805     5.7241427898406982e-01
    z[5,6,3]  R1806     7.3525249958038330e-01
    z[5,6,3]  R1807     0.293355792760849
    z[5,6,3]  R1808     7.2702729701995850e-01
    z[5,6,3]  R1809     7.4696594476699829e-01
    z[5,6,3]  R1810     -3.0589836835861206e-01
    z[5,6,3]  R1811     -1.5433473885059357e-01
    z[5,6,3]  R1812     -5.9438586235046387e-01
    z[5,6,3]  R1813     -1.5773284435272217e-01
    z[5,6,3]  R1814     -4.6872556209564209e-01
    z[5,6,3]  R1815     -7.4423581361770630e-01
    z[5,6,3]  R1816     3.7225559353828430e-02
    z[5,6,3]  R1817     9.7412243485450745e-02
    z[5,6,3]  R1818     1.0573107749223709e-01
    z[5,6,3]  R1819     1.9528393447399139e-01
    z[5,6,3]  R1820     -0.192473366856575
    z[5,6,3]  R1821     -8.2285888493061066e-03
    z[5,6,3]  R1822     -1.1563333868980408e-01
    z[5,6,3]  R1823     0.0585331991314888
    z[5,6,3]  R1824     4.7160801291465759e-01
    z[5,6,3]  R1825     0.640306830406189
    z[5,6,3]  R1826     5.5618607997894287e-01
    z[5,6,3]  R1827     6.9402772188186646e-01
    z[5,6,3]  R1828     7.3062801361083984e-01
    z[5,6,3]  R1829     7.7099221944808960e-01
    z[5,6,3]  R1830     2.9088884592056274e-01
    z[5,6,3]  R1831     2.6989719271659851e-01
    z[5,6,3]  R1832     2.9004257917404175e-01
    z[5,6,3]  R1833     2.6627743244171143e-01
    z[5,6,3]  R1834     2.6294848322868347e-01
    z[5,6,3]  R1835     -2.3445339500904083e-01
    z[5,6,3]  R1836     6.6040658950805664e-01
    z[5,6,3]  R1837     5.9646093845367432e-01
    z[5,6,3]  R1838     0.782145619392395
    z[5,6,3]  R1839     4.0949431061744690e-01
    z[5,6,3]  R1840     3.1158992648124695e-01
    z[5,6,3]  R1841     2.7255716919898987e-01
    z[5,6,3]  R1842     6.5426176786422729e-01
    z[5,6,3]  R1843     1.2856918573379517e-01
    z[5,6,3]  R1844     5.1470750570297241e-01
    z[5,6,3]  R1845     1.1904380470514297e-01
    z[5,6,3]  R1846     -7.3084801435470581e-02
    z[5,6,3]  R1847     7.1243906021118164e-01
    z[5,6,3]  R1848     5.4430794715881348e-01
    z[5,6,3]  R1849     6.8508094549179077e-01
    z[5,6,3]  R1850     3.4227120876312256e-01
    z[5,6,3]  R1851     2.4159125983715057e-01
    z[5,6,3]  R1852     2.8500276803970337e-01
    z[5,6,3]  R1853     1.2094379216432571e-01
    z[5,6,3]  R1854     7.3022079467773438e-01
    z[5,6,3]  R1855     5.3078317642211914e-01
    z[5,6,3]  R1856     7.2227662801742554e-01
    z[5,6,3]  R1857     2.6772037148475647e-01
    z[5,6,3]  R1858     2.5740250945091248e-01
    z[5,6,3]  R1859     2.8304448723793030e-01
    z[5,6,4]  R51       -1
    z[5,6,4]  R60       1
    z[5,6,4]  R1764     -1
    z[5,6,4]  R1765     1
    z[5,6,4]  R1770     -3.2975059747695923e-01
    z[5,6,4]  R1771     -3.2270956039428711e-01
    z[5,6,4]  R1772     -1.6008014976978302e-01
    z[5,6,4]  R1773     1.6464999318122864e-01
    z[5,6,4]  R1774     -3.6174979805946350e-01
    z[5,6,4]  R1775     -5.6766338646411896e-02
    z[5,6,4]  R1776     3.8014256954193115e-01
    z[5,6,4]  R1777     -5.4628050327301025e-01
    z[5,6,4]  R1778     2.1887996792793274e-01
    z[5,6,4]  R1779     -5.3625606000423431e-02
    z[5,6,4]  R1780     -9.6041090786457062e-02
    z[5,6,4]  R1781     -3.7073828279972076e-02
    z[5,6,4]  R1782     -4.5687353610992432e-01
    z[5,6,4]  R1783     -1.9509927928447723e-01
    z[5,6,4]  R1784     -3.6990082263946533e-01
    z[5,6,4]  R1785     -5.9515666216611862e-02
    z[5,6,4]  R1786     -7.7582925558090210e-02
    z[5,6,4]  R1787     -1.1067941784858704e-01
    z[5,6,4]  R1788     -1.4172458648681641e-01
    z[5,6,4]  R1789     5.7703603059053421e-02
    z[5,6,4]  R1790     5.5482137203216553e-01
    z[5,6,4]  R1791     -3.2768428325653076e-02
    z[5,6,4]  R1792     -1.7064218409359455e-03
    z[5,6,4]  R1793     8.1124818325042725e-01
    z[5,6,4]  R1794     5.6696657091379166e-02
    z[5,6,4]  R1795     1.9953319430351257e-01
    z[5,6,4]  R1796     8.9923244714736938e-01
    z[5,6,4]  R1797     -2.0589552819728851e-01
    z[5,6,4]  R1798     -1.0547125339508057e-01
    z[5,6,4]  R1799     -3.1715796794742346e-03
    z[5,6,4]  R1800     -2.3647494614124298e-01
    z[5,6,4]  R1801     2.3328827694058418e-02
    z[5,6,4]  R1802     -9.8830483853816986e-02
    z[5,6,4]  R1803     1.6807280480861664e-01
    z[5,6,4]  R1804     -6.0537587851285934e-02
    z[5,6,4]  R1805     -1.5713594853878021e-01
    z[5,6,4]  R1806     -1.3777065277099609e-01
    z[5,6,4]  R1807     2.1798150241374969e-01
    z[5,6,4]  R1808     4.3557864427566528e-01
    z[5,6,4]  R1809     3.2727840542793274e-01
    z[5,6,4]  R1810     -6.5553623437881470e-01
    z[5,6,4]  R1811     -5.6372737884521484e-01
    z[5,6,4]  R1812     -6.5037024021148682e-01
    z[5,6,4]  R1813     -1.4352397620677948e-01
    z[5,6,4]  R1814     -4.4759041070938110e-01
    z[5,6,4]  R1815     -3.2101035118103027e-01
    z[5,6,4]  R1816     4.6939209103584290e-02
    z[5,6,4]  R1817     -1.3300265371799469e-01
    z[5,6,4]  R1818     -2.0688125491142273e-01
    z[5,6,4]  R1819     -2.2732120007276535e-02
    z[5,6,4]  R1820     7.3849511146545410e-01
    z[5,6,4]  R1821     4.6790724992752075e-01
    z[5,6,4]  R1822     5.1474612951278687e-01
    z[5,6,4]  R1823     0.117306649684906
    z[5,6,4]  R1824     1.4192031323909760e-01
    z[5,6,4]  R1825     0.639231264591217
    z[5,6,4]  R1826     6.4150214195251465e-01
    z[5,6,4]  R1827     5.1964229345321655e-01
    z[5,6,4]  R1828     5.8704030513763428e-01
    z[5,6,4]  R1829     6.1071318387985229e-01
    z[5,6,4]  R1830     -2.6565727591514587e-01
    z[5,6,4]  R1831     -3.3379873633384705e-01
    z[5,6,4]  R1832     -3.5412481427192688e-01
    z[5,6,4]  R1833     -3.3927980065345764e-01
    z[5,6,4]  R1834     -2.6110973954200745e-01
    z[5,6,4]  R1835     1.8755020201206207e-01
    z[5,6,4]  R1836     5.9185034036636353e-01
    z[5,6,4]  R1837     4.7020500898361206e-01
    z[5,6,4]  R1838     4.8603174090385437e-01
    z[5,6,4]  R1839     5.5803602933883667e-01
    z[5,6,4]  R1840     -3.1170541048049927e-01
    z[5,6,4]  R1841     -0.335040807723999
    z[5,6,4]  R1842     3.4145078063011169e-01
    z[5,6,4]  R1843     -4.1805077344179153e-03
    z[5,6,4]  R1844     5.2007704973220825e-01
    z[5,6,4]  R1845     3.9965155720710754e-01
    z[5,6,4]  R1846     1.5197758562862873e-02
    z[5,6,4]  R1847     5.2641767263412476e-01
    z[5,6,4]  R1848     5.2312481403350830e-01
    z[5,6,4]  R1849     4.8766264319419861e-01
    z[5,6,4]  R1850     -2.9579576849937439e-01
    z[5,6,4]  R1851     1.8831400200724602e-02
    z[5,6,4]  R1852     -2.7756664156913757e-01
    z[5,6,4]  R1853     3.8045457005500793e-01
    z[5,6,4]  R1854     0.634904146194458
    z[5,6,4]  R1855     5.9926205873489380e-01
    z[5,6,4]  R1856     6.1631715297698975e-01
    z[5,6,4]  R1857     -1.9644858315587044e-02
    z[5,6,4]  R1858     -7.1411304175853729e-02
    z[5,6,4]  R1859     5.4956275224685669e-01
    z[5,6,5]  R52       -1
    z[5,6,5]  R61       1
    z[5,6,5]  R1766     -1
    z[5,6,5]  R1767     1
    z[5,6,5]  R1770     -1.9581261277198792e-01
    z[5,6,5]  R1771     -1.5446981787681580e-01
    z[5,6,5]  R1772     -2.6942875981330872e-01
    z[5,6,5]  R1773     -1.8457669019699097e-01
    z[5,6,5]  R1774     -2.7567198872566223e-01
    z[5,6,5]  R1775     -3.3022406697273254e-01
    z[5,6,5]  R1776     -2.6450985670089722e-01
    z[5,6,5]  R1777     -1.7573808133602142e-01
    z[5,6,5]  R1778     3.1393748521804810e-01
    z[5,6,5]  R1779     2.1167731285095215e-01
    z[5,6,5]  R1780     3.1547054648399353e-01
    z[5,6,5]  R1781     2.2521814703941345e-01
    z[5,6,5]  R1782     2.8799504041671753e-01
    z[5,6,5]  R1783     1.0257090628147125e-01
    z[5,6,5]  R1784     2.4985921382904053e-01
    z[5,6,5]  R1785     1.1288130283355713e-01
    z[5,6,5]  R1786     5.4335236549377441e-02
    z[5,6,5]  R1787     1.1946207284927368e-01
    z[5,6,5]  R1788     2.2022227942943573e-01
    z[5,6,5]  R1789     8.3384037017822266e-02
    z[5,6,5]  R1790     -2.4482456967234612e-02
    z[5,6,5]  R1791     1.6232512891292572e-01
    z[5,6,5]  R1792     2.6613163948059082e-01
    z[5,6,5]  R1793     -1.0773230344057083e-01
    z[5,6,5]  R1794     9.4823047518730164e-02
    z[5,6,5]  R1795     2.7530258893966675e-01
    z[5,6,5]  R1796     -1.1338969320058823e-01
    z[5,6,5]  R1797     4.9063485860824585e-01
    z[5,6,5]  R1798     1.9328027963638306e-01
    z[5,6,5]  R1799     3.6383220553398132e-01
    z[5,6,5]  R1800     2.1385115385055542e-01
    z[5,6,5]  R1801     1.1175382137298584e-01
    z[5,6,5]  R1802     2.8542625904083252e-01
    z[5,6,5]  R1803     3.2299514859914780e-02
    z[5,6,5]  R1804     2.3050366342067719e-01
    z[5,6,5]  R1805     2.7703121304512024e-01
    z[5,6,5]  R1806     2.7160212397575378e-01
    z[5,6,5]  R1807     1.3086847029626369e-02
    z[5,6,5]  R1808     7.5679324567317963e-02
    z[5,6,5]  R1809     1.4883327484130859e-01
    z[5,6,5]  R1810     3.1890936195850372e-02
    z[5,6,5]  R1811     -8.3937905728816986e-02
    z[5,6,5]  R1812     -4.3179783970117569e-02
    z[5,6,5]  R1813     2.1393939852714539e-01
    z[5,6,5]  R1814     5.5773550271987915e-01
    z[5,6,5]  R1815     1.3033340871334076e-01
    z[5,6,5]  R1816     3.8876384496688843e-01
    z[5,6,5]  R1817     3.9590248465538025e-01
    z[5,6,5]  R1818     5.3513944149017334e-01
    z[5,6,5]  R1819     5.9808903932571411e-01
    z[5,6,5]  R1820     -3.8606292009353638e-01
    z[5,6,5]  R1821     -4.6896100044250488e-02
    z[5,6,5]  R1822     -1.7600633203983307e-01
    z[5,6,5]  R1823     -4.3365910649299622e-01
    z[5,6,5]  R1824     1.6803377866744995e-01
    z[5,6,5]  R1825     -2.7435111999511719e-01
    z[5,6,5]  R1826     -0.41243776679039
    z[5,6,5]  R1827     -4.0450578927993774e-01
    z[5,6,5]  R1828     -1.5519276261329651e-01
    z[5,6,5]  R1829     -1.2001276016235352e-01
    z[5,6,5]  R1830     -2.7328658103942871e-01
    z[5,6,5]  R1831     3.4517291188240051e-01
    z[5,6,5]  R1832     -3.5216996073722839e-01
    z[5,6,5]  R1833     1.9515956519171596e-03
    z[5,6,5]  R1834     3.0713069438934326e-01
    z[5,6,5]  R1835     2.0844615995883942e-01
    z[5,6,5]  R1836     -1.6517917811870575e-01
    z[5,6,5]  R1837     -4.0421482920646667e-01
    z[5,6,5]  R1838     -1.6351450979709625e-01
    z[5,6,5]  R1839     -5.2698552608489990e-01
    z[5,6,5]  R1840     -6.1436548829078674e-02
    z[5,6,5]  R1841     2.5246468186378479e-01
    z[5,6,5]  R1842     -5.9880632162094116e-01
    z[5,6,5]  R1843     2.3992657661437988e-01
    z[5,6,5]  R1844     -0.559112548828125
    z[5,6,5]  R1845     3.2083955407142639e-01
    z[5,6,5]  R1846     1.3470095396041870e-01
    z[5,6,5]  R1847     -4.4716912508010864e-01
    z[5,6,5]  R1848     -5.4794645309448242e-01
    z[5,6,5]  R1849     -2.9601526260375977e-01
    z[5,6,5]  R1850     -7.1639634668827057e-02
    z[5,6,5]  R1851     3.7576580047607422e-01
    z[5,6,5]  R1852     2.0769409835338593e-01
    z[5,6,5]  R1853     2.4020275473594666e-01
    z[5,6,5]  R1854     -1.1854986846446991e-01
    z[5,6,5]  R1855     -4.6189829707145691e-01
    z[5,6,5]  R1856     8.8646404445171356e-02
    z[5,6,5]  R1857     3.9814686775207520e-01
    z[5,6,5]  R1858     0.0660867840051651
    z[5,6,5]  R1859     4.6411749720573425e-01
    z[5,6,6]  R53       -1
    z[5,6,6]  R62       1
    z[5,6,6]  R1768     -1
    z[5,6,6]  R1769     1
    z[5,6,6]  R1770     0.39483642578125
    z[5,6,6]  R1771     4.1094845533370972e-01
    z[5,6,6]  R1772     -2.7579185366630554e-01
    z[5,6,6]  R1773     5.0886821746826172e-01
    z[5,6,6]  R1774     -5.3629726171493530e-01
    z[5,6,6]  R1775     -0.660996675491333
    z[5,6,6]  R1776     1.2309314310550690e-01
    z[5,6,6]  R1777     -2.7382916212081909e-01
    z[5,6,6]  R1778     1.3197000138461590e-02
    z[5,6,6]  R1779     -2.3683875799179077e-01
    z[5,6,6]  R1780     1.4986149966716766e-01
    z[5,6,6]  R1781     -9.7660243511199951e-02
    z[5,6,6]  R1782     -3.6668688058853149e-02
    z[5,6,6]  R1783     9.7606927156448364e-02
    z[5,6,6]  R1784     2.8507539629936218e-01
    z[5,6,6]  R1785     -1.9734199345111847e-01
    z[5,6,6]  R1786     -0.077787384390831
    z[5,6,6]  R1787     1.8730445206165314e-01
    z[5,6,6]  R1788     2.8510499000549316e-01
    z[5,6,6]  R1789     1.3623951375484467e-01
    z[5,6,6]  R1790     -1.2113806605339050e-01
    z[5,6,6]  R1791     2.2376336157321930e-01
    z[5,6,6]  R1792     -3.0174696445465088e-01
    z[5,6,6]  R1793     -2.8764383867383003e-02
    z[5,6,6]  R1794     -2.3102907463908195e-02
    z[5,6,6]  R1795     1.6892101615667343e-02
    z[5,6,6]  R1796     -2.1939021348953247e-01
    z[5,6,6]  R1797     2.3734977841377258e-01
    z[5,6,6]  R1798     1.3645261526107788e-01
    z[5,6,6]  R1799     3.5766372084617615e-01
    z[5,6,6]  R1800     -2.3777644336223602e-01
    z[5,6,6]  R1801     6.8924024701118469e-02
    z[5,6,6]  R1802     -1.7019283771514893e-01
    z[5,6,6]  R1803     -2.3284508287906647e-01
    z[5,6,6]  R1804     -1.3061454892158508e-01
    z[5,6,6]  R1805     9.3289464712142944e-02
    z[5,6,6]  R1806     2.4649918079376221e-01
    z[5,6,6]  R1807     9.6176296472549438e-02
    z[5,6,6]  R1808     1.7258486151695251e-01
    z[5,6,6]  R1809     3.1061553955078125e-01
    z[5,6,6]  R1810     -2.7949538826942444e-01
    z[5,6,6]  R1811     1.9483187794685364e-01
    z[5,6,6]  R1812     3.0501335859298706e-01
    z[5,6,6]  R1813     -3.3709757030010223e-02
    z[5,6,6]  R1814     -8.3558365702629089e-02
    z[5,6,6]  R1815     -4.4164186716079712e-01
    z[5,6,6]  R1816     2.2856485843658447e-01
    z[5,6,6]  R1817     1.5793742239475250e-01
    z[5,6,6]  R1818     -5.4209318011999130e-02
    z[5,6,6]  R1819     -3.1630310416221619e-01
    z[5,6,6]  R1820     1.7460419237613678e-01
    z[5,6,6]  R1821     1.1858832091093063e-01
    z[5,6,6]  R1822     4.0843120217323303e-01
    z[5,6,6]  R1823     -2.2978352010250092e-01
    z[5,6,6]  R1824     2.2655259072780609e-01
    z[5,6,6]  R1825     1.9670473039150238e-01
    z[5,6,6]  R1826     1.3496269471943378e-02
    z[5,6,6]  R1827     2.1789531409740448e-01
    z[5,6,6]  R1828     1.9916498661041260e-01
    z[5,6,6]  R1829     -6.1406232416629791e-02
    z[5,6,6]  R1830     -1.2808224558830261e-01
    z[5,6,6]  R1831     7.7300563454627991e-02
    z[5,6,6]  R1832     -1.2183124572038651e-01
    z[5,6,6]  R1833     1.5210315585136414e-01
    z[5,6,6]  R1834     -1.0050041973590851e-01
    z[5,6,6]  R1835     -1.8813011050224304e-01
    z[5,6,6]  R1836     -2.5974291563034058e-01
    z[5,6,6]  R1837     -4.8347678780555725e-01
    z[5,6,6]  R1838     -3.4096620976924896e-02
    z[5,6,6]  R1839     1.3139671087265015e-01
    z[5,6,6]  R1840     1.7467968165874481e-01
    z[5,6,6]  R1841     1.5254262089729309e-01
    z[5,6,6]  R1842     1.0460289567708969e-01
    z[5,6,6]  R1843     -3.3972385525703430e-01
    z[5,6,6]  R1844     3.7532657384872437e-01
    z[5,6,6]  R1845     -2.5431340932846069e-01
    z[5,6,6]  R1846     -2.3682577908039093e-01
    z[5,6,6]  R1847     3.0602652579545975e-02
    z[5,6,6]  R1848     4.5474354177713394e-02
    z[5,6,6]  R1849     8.6508587002754211e-02
    z[5,6,6]  R1850     1.4725729823112488e-01
    z[5,6,6]  R1851     3.5658221691846848e-02
    z[5,6,6]  R1852     2.6848191022872925e-01
    z[5,6,6]  R1853     7.3222480714321136e-02
    z[5,6,6]  R1854     -3.5274066030979156e-02
    z[5,6,6]  R1855     1.1060192435979843e-01
    z[5,6,6]  R1856     2.0984171330928802e-01
    z[5,6,6]  R1857     -2.2159019112586975e-01
    z[5,6,6]  R1858     -3.2067753374576569e-02
    z[5,6,6]  R1859     -7.0169776678085327e-02
    z[6,5,0]  R47       1
    z[6,5,0]  R56       -1
    z[6,5,0]  R1860     -1
    z[6,5,0]  R1861     1
    z[6,5,0]  R1874     3.5783922672271729e-01
    z[6,5,0]  R1875     0.214617520570755
    z[6,5,0]  R1876     2.5890854001045227e-01
    z[6,5,0]  R1877     -4.6143096685409546e-01
    z[6,5,0]  R1878     -0.210273876786232
    z[6,5,0]  R1879     -1.8114566802978516e-01
    z[6,5,0]  R1880     3.3847063779830933e-01
    z[6,5,0]  R1881     2.8565225005149841e-01
    z[6,5,0]  R1882     4.1506037116050720e-01
    z[6,5,0]  R1883     3.2135307788848877e-01
    z[6,5,0]  R1884     1.8740488216280937e-02
    z[6,5,0]  R1885     4.8412081599235535e-01
    z[6,5,0]  R1886     -2.1803854405879974e-01
    z[6,5,0]  R1887     0.50909823179245
    z[6,5,0]  R1888     7.1029466390609741e-01
    z[6,5,0]  R1889     -5.5524501949548721e-02
    z[6,5,0]  R1890     -6.1685512773692608e-03
    z[6,5,0]  R1891     3.7835661321878433e-02
    z[6,5,0]  R1892     5.6850533932447433e-02
    z[6,5,0]  R1893     2.5100933387875557e-02
    z[6,5,0]  R1894     4.4018816202878952e-02
    z[6,5,0]  R1895     -1.1822836101055145e-01
    z[6,5,0]  R1896     -3.6960181593894958e-01
    z[6,5,0]  R1897     3.4233191609382629e-01
    z[6,5,0]  R1898     3.9878332614898682e-01
    z[6,5,0]  R1899     3.1251686811447144e-01
    z[6,5,0]  R1900     -1.7355673015117645e-01
    z[6,5,0]  R1901     2.4099587462842464e-03
    z[6,5,0]  R1902     2.7057060971856117e-02
    z[6,5,0]  R1903     -4.4093459844589233e-01
    z[6,5,0]  R1904     4.1839978098869324e-01
    z[6,5,0]  R1905     3.5848870873451233e-01
    z[6,5,0]  R1906     2.2785486280918121e-01
    z[6,5,0]  R1907     3.6973163485527039e-01
    z[6,5,0]  R1908     -4.7974463552236557e-02
    z[6,5,0]  R1909     6.8158395588397980e-02
    z[6,5,0]  R1910     2.1467141807079315e-01
    z[6,5,0]  R1911     8.5718967020511627e-02
    z[6,5,0]  R1912     -1.9045859575271606e-01
    z[6,5,0]  R1913     2.1406984329223633e-01
    z[6,5,0]  R1914     4.9754351377487183e-01
    z[6,5,0]  R1915     2.3441560566425323e-01
    z[6,5,0]  R1916     5.6777395308017731e-02
    z[6,5,0]  R1917     6.9153445959091187e-01
    z[6,5,0]  R1918     8.4705986082553864e-02
    z[6,5,0]  R1919     -3.3468225598335266e-01
    z[6,5,0]  R1920     -1.9302885234355927e-01
    z[6,5,0]  R1921     -4.2197167873382568e-01
    z[6,5,0]  R1922     -6.2555056810379028e-01
    z[6,5,0]  R1923     -1.4626176655292511e-01
    z[6,5,0]  R1924     -1.3222447037696838e-01
    z[6,5,0]  R1925     4.4330772757530212e-01
    z[6,5,0]  R1926     5.1061475276947021e-01
    z[6,5,0]  R1927     3.6846846342086792e-01
    z[6,5,0]  R1928     -1.4600045979022980e-01
    z[6,5,0]  R1929     5.6267328560352325e-02
    z[6,5,0]  R1930     -2.3827967047691345e-01
    z[6,5,0]  R1931     3.1948262453079224e-01
    z[6,5,0]  R1932     5.4506051540374756e-01
    z[6,5,0]  R1933     -4.5493689179420471e-01
    z[6,5,0]  R1934     -5.8300759643316269e-02
    z[6,5,0]  R1935     4.5845970511436462e-01
    z[6,5,0]  R1936     1.2683887779712677e-01
    z[6,5,0]  R1937     -1.1591664701700211e-01
    z[6,5,0]  R1938     2.8984561562538147e-01
    z[6,5,0]  R1939     4.3581213802099228e-02
    z[6,5,0]  R1940     2.8131446242332458e-01
    z[6,5,0]  R1941     3.0815801024436951e-01
    z[6,5,0]  R1942     3.6679348349571228e-01
    z[6,5,0]  R1943     2.0239928364753723e-01
    z[6,5,0]  R1944     3.4378626942634583e-01
    z[6,5,0]  R1945     3.5512766242027283e-01
    z[6,5,0]  R1946     0.172831192612648
    z[6,5,0]  R1947     -1.1071722209453583e-01
    z[6,5,0]  R1948     -1.2994001805782318e-01
    z[6,5,0]  R1949     -4.2620870471000671e-01
    z[6,5,0]  R1950     1.7344912886619568e-01
    z[6,5,0]  R1951     4.4796681404113770e-01
    z[6,5,0]  R1952     -7.8268569707870483e-01
    z[6,5,0]  R1953     -6.5067225694656372e-01
    z[6,5,0]  R1954     -4.4846507906913757e-01
    z[6,5,0]  R1955     -2.1969492081552744e-03
    z[6,5,0]  R1956     -1.2974171340465546e-01
    z[6,5,0]  R1957     -1.0507542639970779e-01
    z[6,5,0]  R1958     -6.4282584190368652e-01
    z[6,5,0]  R1959     -5.9012347459793091e-01
    z[6,5,0]  R1960     3.8122949004173279e-01
    z[6,5,0]  R1961     -4.8667392134666443e-01
    z[6,5,0]  R1962     -3.3006361126899719e-01
    z[6,5,0]  R1963     2.1405370533466339e-01
    z[6,5,1]  R48       1
    z[6,5,1]  R57       -1
    z[6,5,1]  R1862     -1
    z[6,5,1]  R1863     1
    z[6,5,1]  R1874     -1.0184162110090256e-01
    z[6,5,1]  R1875     -6.3242278993129730e-02
    z[6,5,1]  R1876     -1.6725437343120575e-01
    z[6,5,1]  R1877     -0.303504079580307
    z[6,5,1]  R1878     -1.7079021036624908e-01
    z[6,5,1]  R1879     -2.0953050255775452e-01
    z[6,5,1]  R1880     0.810470461845398
    z[6,5,1]  R1881     7.7487325668334961e-01
    z[6,5,1]  R1882     6.2169611454010010e-01
    z[6,5,1]  R1883     6.2602823972702026e-01
    z[6,5,1]  R1884     -4.7532996535301208e-01
    z[6,5,1]  R1885     -7.1956586837768555e-01
    z[6,5,1]  R1886     -6.3786417245864868e-01
    z[6,5,1]  R1887     -5.8766132593154907e-01
    z[6,5,1]  R1888     -3.0826598405838013e-01
    z[6,5,1]  R1889     9.4622872769832611e-02
    z[6,5,1]  R1890     -6.0548450797796249e-02
    z[6,5,1]  R1891     -1.1446894705295563e-01
    z[6,5,1]  R1892     -2.2744706273078918e-01
    z[6,5,1]  R1893     -1.1153586953878403e-01
    z[6,5,1]  R1894     5.3579532541334629e-03
    z[6,5,1]  R1895     2.6253911852836609e-01
    z[6,5,1]  R1896     2.2489833831787109e-01
    z[6,5,1]  R1897     4.6520507335662842e-01
    z[6,5,1]  R1898     7.1018069982528687e-02
    z[6,5,1]  R1899     8.5603815317153931e-01
    z[6,5,1]  R1900     2.8711551427841187e-01
    z[6,5,1]  R1901     -9.3920789659023285e-02
    z[6,5,1]  R1902     0.345195472240448
    z[6,5,1]  R1903     1.6721232235431671e-01
    z[6,5,1]  R1904     3.3686190843582153e-01
    z[6,5,1]  R1905     1.3379177451133728e-01
    z[6,5,1]  R1906     1.3943144679069519e-01
    z[6,5,1]  R1907     8.0643719434738159e-01
    z[6,5,1]  R1908     -8.9668609201908112e-02
    z[6,5,1]  R1909     7.9418027400970459e-01
    z[6,5,1]  R1910     0.832773745059967
    z[6,5,1]  R1911     8.4061279892921448e-02
    z[6,5,1]  R1912     3.0079850554466248e-01
    z[6,5,1]  R1913     2.7481248974800110e-01
    z[6,5,1]  R1914     2.9237136244773865e-01
    z[6,5,1]  R1915     7.5944197177886963e-01
    z[6,5,1]  R1916     -4.8153233528137207e-01
    z[6,5,1]  R1917     5.3768402338027954e-01
    z[6,5,1]  R1918     -1.4101034402847290e-01
    z[6,5,1]  R1919     1.4121639728546143e-01
    z[6,5,1]  R1920     3.0635641887784004e-02
    z[6,5,1]  R1921     3.5354387760162354e-01
    z[6,5,1]  R1922     8.2029908895492554e-02
    z[6,5,1]  R1923     -3.7217464298009872e-02
    z[6,5,1]  R1924     -1.6161552071571350e-01
    z[6,5,1]  R1925     3.2868351787328720e-02
    z[6,5,1]  R1926     -1.7294447124004364e-01
    z[6,5,1]  R1927     -8.4048956632614136e-02
    z[6,5,1]  R1928     -7.3759369552135468e-02
    z[6,5,1]  R1929     1.5344594419002533e-01
    z[6,5,1]  R1930     -1.3576546311378479e-01
    z[6,5,1]  R1931     -6.5748848021030426e-02
    z[6,5,1]  R1932     -3.4854590892791748e-01
    z[6,5,1]  R1933     1.0795310884714127e-01
    z[6,5,1]  R1934     3.8190406560897827e-01
    z[6,5,1]  R1935     0.508387565612793
    z[6,5,1]  R1936     3.8482189178466797e-01
    z[6,5,1]  R1937     -9.4322019815444946e-01
    z[6,5,1]  R1938     5.6086617708206177e-01
    z[6,5,1]  R1939     8.6465978622436523e-01
    z[6,5,1]  R1940     9.2690610885620117e-01
    z[6,5,1]  R1941     8.7022984027862549e-01
    z[6,5,1]  R1942     6.7859381437301636e-01
    z[6,5,1]  R1943     9.3490058183670044e-01
    z[6,5,1]  R1944     -7.2512662410736084e-01
    z[6,5,1]  R1945     -6.8225187063217163e-01
    z[6,5,1]  R1946     1.0376872122287750e-01
    z[6,5,1]  R1947     -9.1379128396511078e-02
    z[6,5,1]  R1948     -8.3054494857788086e-01
    z[6,5,1]  R1949     -1.7058350145816803e-01
    z[6,5,1]  R1950     -6.9917507469654083e-02
    z[6,5,1]  R1951     -7.9005323350429535e-02
    z[6,5,1]  R1952     -5.7636916637420654e-02
    z[6,5,1]  R1953     -1.2369954586029053e-01
    z[6,5,1]  R1954     2.7449575066566467e-01
    z[6,5,1]  R1955     -8.9514678716659546e-01
    z[6,5,1]  R1956     1.2293367832899094e-01
    z[6,5,1]  R1957     -0.889827311038971
    z[6,5,1]  R1958     -1.3678210973739624e-01
    z[6,5,1]  R1959     -2.3393984884023666e-02
    z[6,5,1]  R1960     3.3358085155487061e-01
    z[6,5,1]  R1961     -7.5847542285919189e-01
    z[6,5,1]  R1962     2.8464773297309875e-01
    z[6,5,1]  R1963     -3.7620380520820618e-01
    z[6,5,2]  R49       1
    z[6,5,2]  R58       -1
    z[6,5,2]  R1864     -1
    z[6,5,2]  R1865     1
    z[6,5,2]  R1874     -5.0906091928482056e-01
    z[6,5,2]  R1875     -7.5055104494094849e-01
    z[6,5,2]  R1876     -1.8389877676963806e-01
    z[6,5,2]  R1877     -7.7626121044158936e-01
    z[6,5,2]  R1878     -4.3419343233108521e-01
    z[6,5,2]  R1879     2.3305429518222809e-01
    z[6,5,2]  R1880     1.4699342846870422e-01
    z[6,5,2]  R1881     3.3032163977622986e-01
    z[6,5,2]  R1882     0.312933087348938
    z[6,5,2]  R1883     9.1706722974777222e-02
    z[6,5,2]  R1884     -1.0843417793512344e-01
    z[6,5,2]  R1885     1.1218120902776718e-01
    z[6,5,2]  R1886     2.6355206966400146e-01
    z[6,5,2]  R1887     3.7070938944816589e-01
    z[6,5,2]  R1888     2.7988687157630920e-01
    z[6,5,2]  R1889     2.3535709083080292e-01
    z[6,5,2]  R1890     3.2425424456596375e-01
    z[6,5,2]  R1891     -1.5053071081638336e-01
    z[6,5,2]  R1892     -5.3392220288515091e-02
    z[6,5,2]  R1893     -3.6827970296144485e-02
    z[6,5,2]  R1894     8.6703681945800781e-01
    z[6,5,2]  R1895     7.7955722808837891e-01
    z[6,5,2]  R1896     6.8148344755172729e-01
    z[6,5,2]  R1897     6.7619484663009644e-01
    z[6,5,2]  R1898     7.7082967758178711e-01
    z[6,5,2]  R1899     2.3359667509794235e-02
    z[6,5,2]  R1900     7.9174205660820007e-02
    z[6,5,2]  R1901     -1.3105416297912598e-01
    z[6,5,2]  R1902     -6.5037272870540619e-02
    z[6,5,2]  R1903     -5.9566110372543335e-02
    z[6,5,2]  R1904     6.9493138790130615e-01
    z[6,5,2]  R1905     7.6160228252410889e-01
    z[6,5,2]  R1906     -1.2034597247838974e-01
    z[6,5,2]  R1907     1.5307830274105072e-01
    z[6,5,2]  R1908     2.7876922860741615e-02
    z[6,5,2]  R1909     1.5207213163375854e-01
    z[6,5,2]  R1910     4.2497169971466064e-01
    z[6,5,2]  R1911     2.0644725300371647e-03
    z[6,5,2]  R1912     3.1650561839342117e-02
    z[6,5,2]  R1913     2.7639198303222656e-01
    z[6,5,2]  R1914     6.5993010997772217e-01
    z[6,5,2]  R1915     4.0878447890281677e-01
    z[6,5,2]  R1916     7.0100909471511841e-01
    z[6,5,2]  R1917     -1.0121328383684158e-01
    z[6,5,2]  R1918     1.4600278437137604e-01
    z[6,5,2]  R1919     -4.0214333683252335e-02
    z[6,5,2]  R1920     -9.1538235545158386e-02
    z[6,5,2]  R1921     0.645959198474884
    z[6,5,2]  R1922     7.2471112012863159e-01
    z[6,5,2]  R1923     6.1217653751373291e-01
    z[6,5,2]  R1924     -6.1106526851654053e-01
    z[6,5,2]  R1925     -6.1709243059158325e-01
    z[6,5,2]  R1926     -4.1789144277572632e-01
    z[6,5,2]  R1927     -4.7554206848144531e-01
    z[6,5,2]  R1928     -6.7307806015014648e-01
    z[6,5,2]  R1929     -5.5688637495040894e-01
    z[6,5,2]  R1930     -2.8121533989906311e-01
    z[6,5,2]  R1931     -0.698015570640564
    z[6,5,2]  R1932     -5.9209811687469482e-01
    z[6,5,2]  R1933     8.1579720973968506e-01
    z[6,5,2]  R1934     7.7131724357604980e-01
    z[6,5,2]  R1935     5.6596356630325317e-01
    z[6,5,2]  R1936     0.581097424030304
    z[6,5,2]  R1937     3.5194832831621170e-02
    z[6,5,2]  R1938     5.5022466182708740e-01
    z[6,5,2]  R1939     3.7467437982559204e-01
    z[6,5,2]  R1940     0.185869038105011
    z[6,5,2]  R1941     2.8341516852378845e-01
    z[6,5,2]  R1942     4.6027562022209167e-01
    z[6,5,2]  R1943     1.8549726903438568e-01
    z[6,5,2]  R1944     -5.6430444121360779e-02
    z[6,5,2]  R1945     5.4062587022781372e-01
    z[6,5,2]  R1946     6.0086369514465332e-01
    z[6,5,2]  R1947     -4.1874074935913086e-01
    z[6,5,2]  R1948     5.0818151235580444e-01
    z[6,5,2]  R1949     6.8316936492919922e-01
    z[6,5,2]  R1950     -2.0684944093227386e-01
    z[6,5,2]  R1951     4.9719268083572388e-01
    z[6,5,2]  R1952     5.5894345045089722e-01
    z[6,5,2]  R1953     5.4726940393447876e-01
    z[6,5,2]  R1954     7.3217743635177612e-01
    z[6,5,2]  R1955     4.2120260000228882e-01
    z[6,5,2]  R1956     4.8127841949462891e-01
    z[6,5,2]  R1957     3.1994324922561646e-01
    z[6,5,2]  R1958     5.4639947414398193e-01
    z[6,5,2]  R1959     4.6196100115776062e-01
    z[6,5,2]  R1960     2.2199396789073944e-01
    z[6,5,2]  R1961     -2.1182221174240112e-01
    z[6,5,2]  R1962     -2.3711444437503815e-01
    z[6,5,2]  R1963     -1.7014425992965698e-01
    z[6,5,3]  R50       1
    z[6,5,3]  R59       -1
    z[6,5,3]  R1866     -1
    z[6,5,3]  R1867     1
    z[6,5,3]  R1874     -3.0589836835861206e-01
    z[6,5,3]  R1875     -1.5433473885059357e-01
    z[6,5,3]  R1876     -5.9438586235046387e-01
    z[6,5,3]  R1877     -1.5773284435272217e-01
    z[6,5,3]  R1878     -4.6872556209564209e-01
    z[6,5,3]  R1879     -7.4423581361770630e-01
    z[6,5,3]  R1880     3.7225559353828430e-02
    z[6,5,3]  R1881     9.7412243485450745e-02
    z[6,5,3]  R1882     1.0573107749223709e-01
    z[6,5,3]  R1883     1.9528393447399139e-01
    z[6,5,3]  R1884     -0.192473366856575
    z[6,5,3]  R1885     -8.2285888493061066e-03
    z[6,5,3]  R1886     -1.1563333868980408e-01
    z[6,5,3]  R1887     0.0585331991314888
    z[6,5,3]  R1888     4.7160801291465759e-01
    z[6,5,3]  R1889     0.640306830406189
    z[6,5,3]  R1890     5.5618607997894287e-01
    z[6,5,3]  R1891     6.9402772188186646e-01
    z[6,5,3]  R1892     7.3062801361083984e-01
    z[6,5,3]  R1893     7.7099221944808960e-01
    z[6,5,3]  R1894     2.9088884592056274e-01
    z[6,5,3]  R1895     2.6989719271659851e-01
    z[6,5,3]  R1896     2.9004257917404175e-01
    z[6,5,3]  R1897     2.6627743244171143e-01
    z[6,5,3]  R1898     2.6294848322868347e-01
    z[6,5,3]  R1899     -2.3445339500904083e-01
    z[6,5,3]  R1900     6.6040658950805664e-01
    z[6,5,3]  R1901     5.9646093845367432e-01
    z[6,5,3]  R1902     0.782145619392395
    z[6,5,3]  R1903     4.0949431061744690e-01
    z[6,5,3]  R1904     3.1158992648124695e-01
    z[6,5,3]  R1905     2.7255716919898987e-01
    z[6,5,3]  R1906     6.5426176786422729e-01
    z[6,5,3]  R1907     1.2856918573379517e-01
    z[6,5,3]  R1908     5.1470750570297241e-01
    z[6,5,3]  R1909     1.1904380470514297e-01
    z[6,5,3]  R1910     -7.3084801435470581e-02
    z[6,5,3]  R1911     7.1243906021118164e-01
    z[6,5,3]  R1912     5.4430794715881348e-01
    z[6,5,3]  R1913     6.8508094549179077e-01
    z[6,5,3]  R1914     3.4227120876312256e-01
    z[6,5,3]  R1915     2.4159125983715057e-01
    z[6,5,3]  R1916     2.8500276803970337e-01
    z[6,5,3]  R1917     1.2094379216432571e-01
    z[6,5,3]  R1918     7.3022079467773438e-01
    z[6,5,3]  R1919     5.3078317642211914e-01
    z[6,5,3]  R1920     7.2227662801742554e-01
    z[6,5,3]  R1921     2.6772037148475647e-01
    z[6,5,3]  R1922     2.5740250945091248e-01
    z[6,5,3]  R1923     2.8304448723793030e-01
    z[6,5,3]  R1924     -5.2917140722274780e-01
    z[6,5,3]  R1925     -3.5314863920211792e-01
    z[6,5,3]  R1926     -6.0037565231323242e-01
    z[6,5,3]  R1927     -5.5758535861968994e-01
    z[6,5,3]  R1928     -1.6042657196521759e-01
    z[6,5,3]  R1929     -3.3760768175125122e-01
    z[6,5,3]  R1930     -7.8490930795669556e-01
    z[6,5,3]  R1931     4.5755021274089813e-02
    z[6,5,3]  R1932     -2.9018133878707886e-01
    z[6,5,3]  R1933     1.0989991575479507e-01
    z[6,5,3]  R1934     3.5300999879837036e-01
    z[6,5,3]  R1935     3.8653177022933960e-01
    z[6,5,3]  R1936     4.5291340351104736e-01
    z[6,5,3]  R1937     1.9377514719963074e-01
    z[6,5,3]  R1938     1.3471165299415588e-01
    z[6,5,3]  R1939     2.3421159386634827e-01
    z[6,5,3]  R1940     1.1017097532749176e-01
    z[6,5,3]  R1941     7.6226450502872467e-02
    z[6,5,3]  R1942     2.0796790719032288e-01
    z[6,5,3]  R1943     1.4745345711708069e-01
    z[6,5,3]  R1944     1.7238780856132507e-01
    z[6,5,3]  R1945     -1.9658863544464111e-01
    z[6,5,3]  R1946     6.6063910722732544e-01
    z[6,5,3]  R1947     3.6536341905593872e-01
    z[6,5,3]  R1948     -1.4940737187862396e-01
    z[6,5,3]  R1949     4.5457309484481812e-01
    z[6,5,3]  R1950     2.2941657900810242e-01
    z[6,5,3]  R1951     -4.5434886217117310e-01
    z[6,5,3]  R1952     6.7545793950557709e-02
    z[6,5,3]  R1953     -3.8898780941963196e-02
    z[6,5,3]  R1954     1.7104667425155640e-01
    z[6,5,3]  R1955     -0.0592644065618515
    z[6,5,3]  R1956     7.8499954938888550e-01
    z[6,5,3]  R1957     -1.0627415776252747e-01
    z[6,5,3]  R1958     4.4233056902885437e-01
    z[6,5,3]  R1959     5.7241427898406982e-01
    z[6,5,3]  R1960     7.3525249958038330e-01
    z[6,5,3]  R1961     0.293355792760849
    z[6,5,3]  R1962     7.2702729701995850e-01
    z[6,5,3]  R1963     7.4696594476699829e-01
    z[6,5,4]  R51       1
    z[6,5,4]  R60       -1
    z[6,5,4]  R1868     -1
    z[6,5,4]  R1869     1
    z[6,5,4]  R1874     -6.5553623437881470e-01
    z[6,5,4]  R1875     -5.6372737884521484e-01
    z[6,5,4]  R1876     -6.5037024021148682e-01
    z[6,5,4]  R1877     -1.4352397620677948e-01
    z[6,5,4]  R1878     -4.4759041070938110e-01
    z[6,5,4]  R1879     -3.2101035118103027e-01
    z[6,5,4]  R1880     4.6939209103584290e-02
    z[6,5,4]  R1881     -1.3300265371799469e-01
    z[6,5,4]  R1882     -2.0688125491142273e-01
    z[6,5,4]  R1883     -2.2732120007276535e-02
    z[6,5,4]  R1884     7.3849511146545410e-01
    z[6,5,4]  R1885     4.6790724992752075e-01
    z[6,5,4]  R1886     5.1474612951278687e-01
    z[6,5,4]  R1887     0.117306649684906
    z[6,5,4]  R1888     1.4192031323909760e-01
    z[6,5,4]  R1889     0.639231264591217
    z[6,5,4]  R1890     6.4150214195251465e-01
    z[6,5,4]  R1891     5.1964229345321655e-01
    z[6,5,4]  R1892     5.8704030513763428e-01
    z[6,5,4]  R1893     6.1071318387985229e-01
    z[6,5,4]  R1894     -2.6565727591514587e-01
    z[6,5,4]  R1895     -3.3379873633384705e-01
    z[6,5,4]  R1896     -3.5412481427192688e-01
    z[6,5,4]  R1897     -3.3927980065345764e-01
    z[6,5,4]  R1898     -2.6110973954200745e-01
    z[6,5,4]  R1899     1.8755020201206207e-01
    z[6,5,4]  R1900     5.9185034036636353e-01
    z[6,5,4]  R1901     4.7020500898361206e-01
    z[6,5,4]  R1902     4.8603174090385437e-01
    z[6,5,4]  R1903     5.5803602933883667e-01
    z[6,5,4]  R1904     -3.1170541048049927e-01
    z[6,5,4]  R1905     -0.335040807723999
    z[6,5,4]  R1906     3.4145078063011169e-01
    z[6,5,4]  R1907     -4.1805077344179153e-03
    z[6,5,4]  R1908     5.2007704973220825e-01
    z[6,5,4]  R1909     3.9965155720710754e-01
    z[6,5,4]  R1910     1.5197758562862873e-02
    z[6,5,4]  R1911     5.2641767263412476e-01
    z[6,5,4]  R1912     5.2312481403350830e-01
    z[6,5,4]  R1913     4.8766264319419861e-01
    z[6,5,4]  R1914     -2.9579576849937439e-01
    z[6,5,4]  R1915     1.8831400200724602e-02
    z[6,5,4]  R1916     -2.7756664156913757e-01
    z[6,5,4]  R1917     3.8045457005500793e-01
    z[6,5,4]  R1918     0.634904146194458
    z[6,5,4]  R1919     5.9926205873489380e-01
    z[6,5,4]  R1920     6.1631715297698975e-01
    z[6,5,4]  R1921     -1.9644858315587044e-02
    z[6,5,4]  R1922     -7.1411304175853729e-02
    z[6,5,4]  R1923     5.4956275224685669e-01
    z[6,5,4]  R1924     -3.2975059747695923e-01
    z[6,5,4]  R1925     -3.2270956039428711e-01
    z[6,5,4]  R1926     -1.6008014976978302e-01
    z[6,5,4]  R1927     1.6464999318122864e-01
    z[6,5,4]  R1928     -3.6174979805946350e-01
    z[6,5,4]  R1929     -5.6766338646411896e-02
    z[6,5,4]  R1930     3.8014256954193115e-01
    z[6,5,4]  R1931     -5.4628050327301025e-01
    z[6,5,4]  R1932     2.1887996792793274e-01
    z[6,5,4]  R1933     -5.3625606000423431e-02
    z[6,5,4]  R1934     -9.6041090786457062e-02
    z[6,5,4]  R1935     -3.7073828279972076e-02
    z[6,5,4]  R1936     -4.5687353610992432e-01
    z[6,5,4]  R1937     -1.9509927928447723e-01
    z[6,5,4]  R1938     -3.6990082263946533e-01
    z[6,5,4]  R1939     -5.9515666216611862e-02
    z[6,5,4]  R1940     -7.7582925558090210e-02
    z[6,5,4]  R1941     -1.1067941784858704e-01
    z[6,5,4]  R1942     -1.4172458648681641e-01
    z[6,5,4]  R1943     5.7703603059053421e-02
    z[6,5,4]  R1944     5.5482137203216553e-01
    z[6,5,4]  R1945     -3.2768428325653076e-02
    z[6,5,4]  R1946     -1.7064218409359455e-03
    z[6,5,4]  R1947     8.1124818325042725e-01
    z[6,5,4]  R1948     5.6696657091379166e-02
    z[6,5,4]  R1949     1.9953319430351257e-01
    z[6,5,4]  R1950     8.9923244714736938e-01
    z[6,5,4]  R1951     -2.0589552819728851e-01
    z[6,5,4]  R1952     -1.0547125339508057e-01
    z[6,5,4]  R1953     -3.1715796794742346e-03
    z[6,5,4]  R1954     -2.3647494614124298e-01
    z[6,5,4]  R1955     2.3328827694058418e-02
    z[6,5,4]  R1956     -9.8830483853816986e-02
    z[6,5,4]  R1957     1.6807280480861664e-01
    z[6,5,4]  R1958     -6.0537587851285934e-02
    z[6,5,4]  R1959     -1.5713594853878021e-01
    z[6,5,4]  R1960     -1.3777065277099609e-01
    z[6,5,4]  R1961     2.1798150241374969e-01
    z[6,5,4]  R1962     4.3557864427566528e-01
    z[6,5,4]  R1963     3.2727840542793274e-01
    z[6,5,5]  R52       1
    z[6,5,5]  R61       -1
    z[6,5,5]  R1870     -1
    z[6,5,5]  R1871     1
    z[6,5,5]  R1874     3.1890936195850372e-02
    z[6,5,5]  R1875     -8.3937905728816986e-02
    z[6,5,5]  R1876     -4.3179783970117569e-02
    z[6,5,5]  R1877     2.1393939852714539e-01
    z[6,5,5]  R1878     5.5773550271987915e-01
    z[6,5,5]  R1879     1.3033340871334076e-01
    z[6,5,5]  R1880     3.8876384496688843e-01
    z[6,5,5]  R1881     3.9590248465538025e-01
    z[6,5,5]  R1882     5.3513944149017334e-01
    z[6,5,5]  R1883     5.9808903932571411e-01
    z[6,5,5]  R1884     -3.8606292009353638e-01
    z[6,5,5]  R1885     -4.6896100044250488e-02
    z[6,5,5]  R1886     -1.7600633203983307e-01
    z[6,5,5]  R1887     -4.3365910649299622e-01
    z[6,5,5]  R1888     1.6803377866744995e-01
    z[6,5,5]  R1889     -2.7435111999511719e-01
    z[6,5,5]  R1890     -0.41243776679039
    z[6,5,5]  R1891     -4.0450578927993774e-01
    z[6,5,5]  R1892     -1.5519276261329651e-01
    z[6,5,5]  R1893     -1.2001276016235352e-01
    z[6,5,5]  R1894     -2.7328658103942871e-01
    z[6,5,5]  R1895     3.4517291188240051e-01
    z[6,5,5]  R1896     -3.5216996073722839e-01
    z[6,5,5]  R1897     1.9515956519171596e-03
    z[6,5,5]  R1898     3.0713069438934326e-01
    z[6,5,5]  R1899     2.0844615995883942e-01
    z[6,5,5]  R1900     -1.6517917811870575e-01
    z[6,5,5]  R1901     -4.0421482920646667e-01
    z[6,5,5]  R1902     -1.6351450979709625e-01
    z[6,5,5]  R1903     -5.2698552608489990e-01
    z[6,5,5]  R1904     -6.1436548829078674e-02
    z[6,5,5]  R1905     2.5246468186378479e-01
    z[6,5,5]  R1906     -5.9880632162094116e-01
    z[6,5,5]  R1907     2.3992657661437988e-01
    z[6,5,5]  R1908     -0.559112548828125
    z[6,5,5]  R1909     3.2083955407142639e-01
    z[6,5,5]  R1910     1.3470095396041870e-01
    z[6,5,5]  R1911     -4.4716912508010864e-01
    z[6,5,5]  R1912     -5.4794645309448242e-01
    z[6,5,5]  R1913     -2.9601526260375977e-01
    z[6,5,5]  R1914     -7.1639634668827057e-02
    z[6,5,5]  R1915     3.7576580047607422e-01
    z[6,5,5]  R1916     2.0769409835338593e-01
    z[6,5,5]  R1917     2.4020275473594666e-01
    z[6,5,5]  R1918     -1.1854986846446991e-01
    z[6,5,5]  R1919     -4.6189829707145691e-01
    z[6,5,5]  R1920     8.8646404445171356e-02
    z[6,5,5]  R1921     3.9814686775207520e-01
    z[6,5,5]  R1922     0.0660867840051651
    z[6,5,5]  R1923     4.6411749720573425e-01
    z[6,5,5]  R1924     -1.9581261277198792e-01
    z[6,5,5]  R1925     -1.5446981787681580e-01
    z[6,5,5]  R1926     -2.6942875981330872e-01
    z[6,5,5]  R1927     -1.8457669019699097e-01
    z[6,5,5]  R1928     -2.7567198872566223e-01
    z[6,5,5]  R1929     -3.3022406697273254e-01
    z[6,5,5]  R1930     -2.6450985670089722e-01
    z[6,5,5]  R1931     -1.7573808133602142e-01
    z[6,5,5]  R1932     3.1393748521804810e-01
    z[6,5,5]  R1933     2.1167731285095215e-01
    z[6,5,5]  R1934     3.1547054648399353e-01
    z[6,5,5]  R1935     2.2521814703941345e-01
    z[6,5,5]  R1936     2.8799504041671753e-01
    z[6,5,5]  R1937     1.0257090628147125e-01
    z[6,5,5]  R1938     2.4985921382904053e-01
    z[6,5,5]  R1939     1.1288130283355713e-01
    z[6,5,5]  R1940     5.4335236549377441e-02
    z[6,5,5]  R1941     1.1946207284927368e-01
    z[6,5,5]  R1942     2.2022227942943573e-01
    z[6,5,5]  R1943     8.3384037017822266e-02
    z[6,5,5]  R1944     -2.4482456967234612e-02
    z[6,5,5]  R1945     1.6232512891292572e-01
    z[6,5,5]  R1946     2.6613163948059082e-01
    z[6,5,5]  R1947     -1.0773230344057083e-01
    z[6,5,5]  R1948     9.4823047518730164e-02
    z[6,5,5]  R1949     2.7530258893966675e-01
    z[6,5,5]  R1950     -1.1338969320058823e-01
    z[6,5,5]  R1951     4.9063485860824585e-01
    z[6,5,5]  R1952     1.9328027963638306e-01
    z[6,5,5]  R1953     3.6383220553398132e-01
    z[6,5,5]  R1954     2.1385115385055542e-01
    z[6,5,5]  R1955     1.1175382137298584e-01
    z[6,5,5]  R1956     2.8542625904083252e-01
    z[6,5,5]  R1957     3.2299514859914780e-02
    z[6,5,5]  R1958     2.3050366342067719e-01
    z[6,5,5]  R1959     2.7703121304512024e-01
    z[6,5,5]  R1960     2.7160212397575378e-01
    z[6,5,5]  R1961     1.3086847029626369e-02
    z[6,5,5]  R1962     7.5679324567317963e-02
    z[6,5,5]  R1963     1.4883327484130859e-01
    z[6,5,6]  R53       1
    z[6,5,6]  R62       -1
    z[6,5,6]  R1872     -1
    z[6,5,6]  R1873     1
    z[6,5,6]  R1874     -2.7949538826942444e-01
    z[6,5,6]  R1875     1.9483187794685364e-01
    z[6,5,6]  R1876     3.0501335859298706e-01
    z[6,5,6]  R1877     -3.3709757030010223e-02
    z[6,5,6]  R1878     -8.3558365702629089e-02
    z[6,5,6]  R1879     -4.4164186716079712e-01
    z[6,5,6]  R1880     2.2856485843658447e-01
    z[6,5,6]  R1881     1.5793742239475250e-01
    z[6,5,6]  R1882     -5.4209318011999130e-02
    z[6,5,6]  R1883     -3.1630310416221619e-01
    z[6,5,6]  R1884     1.7460419237613678e-01
    z[6,5,6]  R1885     1.1858832091093063e-01
    z[6,5,6]  R1886     4.0843120217323303e-01
    z[6,5,6]  R1887     -2.2978352010250092e-01
    z[6,5,6]  R1888     2.2655259072780609e-01
    z[6,5,6]  R1889     1.9670473039150238e-01
    z[6,5,6]  R1890     1.3496269471943378e-02
    z[6,5,6]  R1891     2.1789531409740448e-01
    z[6,5,6]  R1892     1.9916498661041260e-01
    z[6,5,6]  R1893     -6.1406232416629791e-02
    z[6,5,6]  R1894     -1.2808224558830261e-01
    z[6,5,6]  R1895     7.7300563454627991e-02
    z[6,5,6]  R1896     -1.2183124572038651e-01
    z[6,5,6]  R1897     1.5210315585136414e-01
    z[6,5,6]  R1898     -1.0050041973590851e-01
    z[6,5,6]  R1899     -1.8813011050224304e-01
    z[6,5,6]  R1900     -2.5974291563034058e-01
    z[6,5,6]  R1901     -4.8347678780555725e-01
    z[6,5,6]  R1902     -3.4096620976924896e-02
    z[6,5,6]  R1903     1.3139671087265015e-01
    z[6,5,6]  R1904     1.7467968165874481e-01
    z[6,5,6]  R1905     1.5254262089729309e-01
    z[6,5,6]  R1906     1.0460289567708969e-01
    z[6,5,6]  R1907     -3.3972385525703430e-01
    z[6,5,6]  R1908     3.7532657384872437e-01
    z[6,5,6]  R1909     -2.5431340932846069e-01
    z[6,5,6]  R1910     -2.3682577908039093e-01
    z[6,5,6]  R1911     3.0602652579545975e-02
    z[6,5,6]  R1912     4.5474354177713394e-02
    z[6,5,6]  R1913     8.6508587002754211e-02
    z[6,5,6]  R1914     1.4725729823112488e-01
    z[6,5,6]  R1915     3.5658221691846848e-02
    z[6,5,6]  R1916     2.6848191022872925e-01
    z[6,5,6]  R1917     7.3222480714321136e-02
    z[6,5,6]  R1918     -3.5274066030979156e-02
    z[6,5,6]  R1919     1.1060192435979843e-01
    z[6,5,6]  R1920     2.0984171330928802e-01
    z[6,5,6]  R1921     -2.2159019112586975e-01
    z[6,5,6]  R1922     -3.2067753374576569e-02
    z[6,5,6]  R1923     -7.0169776678085327e-02
    z[6,5,6]  R1924     0.39483642578125
    z[6,5,6]  R1925     4.1094845533370972e-01
    z[6,5,6]  R1926     -2.7579185366630554e-01
    z[6,5,6]  R1927     5.0886821746826172e-01
    z[6,5,6]  R1928     -5.3629726171493530e-01
    z[6,5,6]  R1929     -0.660996675491333
    z[6,5,6]  R1930     1.2309314310550690e-01
    z[6,5,6]  R1931     -2.7382916212081909e-01
    z[6,5,6]  R1932     1.3197000138461590e-02
    z[6,5,6]  R1933     -2.3683875799179077e-01
    z[6,5,6]  R1934     1.4986149966716766e-01
    z[6,5,6]  R1935     -9.7660243511199951e-02
    z[6,5,6]  R1936     -3.6668688058853149e-02
    z[6,5,6]  R1937     9.7606927156448364e-02
    z[6,5,6]  R1938     2.8507539629936218e-01
    z[6,5,6]  R1939     -1.9734199345111847e-01
    z[6,5,6]  R1940     -0.077787384390831
    z[6,5,6]  R1941     1.8730445206165314e-01
    z[6,5,6]  R1942     2.8510499000549316e-01
    z[6,5,6]  R1943     1.3623951375484467e-01
    z[6,5,6]  R1944     -1.2113806605339050e-01
    z[6,5,6]  R1945     2.2376336157321930e-01
    z[6,5,6]  R1946     -3.0174696445465088e-01
    z[6,5,6]  R1947     -2.8764383867383003e-02
    z[6,5,6]  R1948     -2.3102907463908195e-02
    z[6,5,6]  R1949     1.6892101615667343e-02
    z[6,5,6]  R1950     -2.1939021348953247e-01
    z[6,5,6]  R1951     2.3734977841377258e-01
    z[6,5,6]  R1952     1.3645261526107788e-01
    z[6,5,6]  R1953     3.5766372084617615e-01
    z[6,5,6]  R1954     -2.3777644336223602e-01
    z[6,5,6]  R1955     6.8924024701118469e-02
    z[6,5,6]  R1956     -1.7019283771514893e-01
    z[6,5,6]  R1957     -2.3284508287906647e-01
    z[6,5,6]  R1958     -1.3061454892158508e-01
    z[6,5,6]  R1959     9.3289464712142944e-02
    z[6,5,6]  R1960     2.4649918079376221e-01
    z[6,5,6]  R1961     9.6176296472549438e-02
    z[6,5,6]  R1962     1.7258486151695251e-01
    z[6,5,6]  R1963     3.1061553955078125e-01
    z[5,7,0]  R47       -1
    z[5,7,0]  R65       1
    z[5,7,0]  R1964     -1
    z[5,7,0]  R1965     1
    z[5,7,0]  R1978     -1.3222447037696838e-01
    z[5,7,0]  R1979     4.4330772757530212e-01
    z[5,7,0]  R1980     5.1061475276947021e-01
    z[5,7,0]  R1981     3.6846846342086792e-01
    z[5,7,0]  R1982     -1.4600045979022980e-01
    z[5,7,0]  R1983     5.6267328560352325e-02
    z[5,7,0]  R1984     -2.3827967047691345e-01
    z[5,7,0]  R1985     3.1948262453079224e-01
    z[5,7,0]  R1986     5.4506051540374756e-01
    z[5,7,0]  R1987     -4.5493689179420471e-01
    z[5,7,0]  R1988     -5.8300759643316269e-02
    z[5,7,0]  R1989     4.5845970511436462e-01
    z[5,7,0]  R1990     1.2683887779712677e-01
    z[5,7,0]  R1991     -1.1591664701700211e-01
    z[5,7,0]  R1992     2.8984561562538147e-01
    z[5,7,0]  R1993     4.3581213802099228e-02
    z[5,7,0]  R1994     2.8131446242332458e-01
    z[5,7,0]  R1995     3.0815801024436951e-01
    z[5,7,0]  R1996     3.6679348349571228e-01
    z[5,7,0]  R1997     2.0239928364753723e-01
    z[5,7,0]  R1998     3.4378626942634583e-01
    z[5,7,0]  R1999     3.5512766242027283e-01
    z[5,7,0]  R2000     0.172831192612648
    z[5,7,0]  R2001     -1.1071722209453583e-01
    z[5,7,0]  R2002     -1.2994001805782318e-01
    z[5,7,0]  R2003     -4.2620870471000671e-01
    z[5,7,0]  R2004     1.7344912886619568e-01
    z[5,7,0]  R2005     4.4796681404113770e-01
    z[5,7,0]  R2006     -7.8268569707870483e-01
    z[5,7,0]  R2007     -6.5067225694656372e-01
    z[5,7,0]  R2008     -4.4846507906913757e-01
    z[5,7,0]  R2009     -2.1969492081552744e-03
    z[5,7,0]  R2010     -1.2974171340465546e-01
    z[5,7,0]  R2011     -1.0507542639970779e-01
    z[5,7,0]  R2012     -6.4282584190368652e-01
    z[5,7,0]  R2013     -5.9012347459793091e-01
    z[5,7,0]  R2014     3.8122949004173279e-01
    z[5,7,0]  R2015     -4.8667392134666443e-01
    z[5,7,0]  R2016     -3.3006361126899719e-01
    z[5,7,0]  R2017     2.1405370533466339e-01
    z[5,7,0]  R2018     4.0067169815301895e-02
    z[5,7,0]  R2019     -2.3708039522171021e-01
    z[5,7,0]  R2020     -6.1161381006240845e-01
    z[5,7,0]  R2021     5.3265875577926636e-01
    z[5,7,0]  R2022     6.7545038461685181e-01
    z[5,7,0]  R2023     4.4440844655036926e-01
    z[5,7,0]  R2024     4.5341044664382935e-01
    z[5,7,0]  R2025     -3.9376479387283325e-01
    z[5,7,0]  R2026     -3.7958592176437378e-01
    z[5,7,0]  R2027     -1.3526062667369843e-01
    z[5,7,0]  R2028     0.0799262747168541
    z[5,7,0]  R2029     -1.7884841561317444e-01
    z[5,7,0]  R2030     6.3129913806915283e-01
    z[5,7,0]  R2031     5.8014911413192749e-01
    z[5,7,0]  R2032     5.0079208612442017e-01
    z[5,7,0]  R2033     0.176330104470253
    z[5,7,0]  R2034     -3.1682834029197693e-01
    z[5,7,0]  R2035     -5.1431256532669067e-01
    z[5,7,0]  R2036     -2.9855456948280334e-01
    z[5,7,0]  R2037     4.2249751091003418e-01
    z[5,7,0]  R2038     5.5136221647262573e-01
    z[5,7,0]  R2039     5.8825761079788208e-01
    z[5,7,0]  R2040     4.1543582081794739e-01
    z[5,7,0]  R2041     3.1901162862777710e-01
    z[5,7,0]  R2042     -1.2675908207893372e-01
    z[5,7,0]  R2043     5.0275996327400208e-02
    z[5,7,0]  R2044     -2.2355319932103157e-02
    z[5,7,0]  R2045     -3.8570597767829895e-01
    z[5,7,1]  R48       -1
    z[5,7,1]  R66       1
    z[5,7,1]  R1966     -1
    z[5,7,1]  R1967     1
    z[5,7,1]  R1978     -1.6161552071571350e-01
    z[5,7,1]  R1979     3.2868351787328720e-02
    z[5,7,1]  R1980     -1.7294447124004364e-01
    z[5,7,1]  R1981     -8.4048956632614136e-02
    z[5,7,1]  R1982     -7.3759369552135468e-02
    z[5,7,1]  R1983     1.5344594419002533e-01
    z[5,7,1]  R1984     -1.3576546311378479e-01
    z[5,7,1]  R1985     -6.5748848021030426e-02
    z[5,7,1]  R1986     -3.4854590892791748e-01
    z[5,7,1]  R1987     1.0795310884714127e-01
    z[5,7,1]  R1988     3.8190406560897827e-01
    z[5,7,1]  R1989     0.508387565612793
    z[5,7,1]  R1990     3.8482189178466797e-01
    z[5,7,1]  R1991     -9.4322019815444946e-01
    z[5,7,1]  R1992     5.6086617708206177e-01
    z[5,7,1]  R1993     8.6465978622436523e-01
    z[5,7,1]  R1994     9.2690610885620117e-01
    z[5,7,1]  R1995     8.7022984027862549e-01
    z[5,7,1]  R1996     6.7859381437301636e-01
    z[5,7,1]  R1997     9.3490058183670044e-01
    z[5,7,1]  R1998     -7.2512662410736084e-01
    z[5,7,1]  R1999     -6.8225187063217163e-01
    z[5,7,1]  R2000     1.0376872122287750e-01
    z[5,7,1]  R2001     -9.1379128396511078e-02
    z[5,7,1]  R2002     -8.3054494857788086e-01
    z[5,7,1]  R2003     -1.7058350145816803e-01
    z[5,7,1]  R2004     -6.9917507469654083e-02
    z[5,7,1]  R2005     -7.9005323350429535e-02
    z[5,7,1]  R2006     -5.7636916637420654e-02
    z[5,7,1]  R2007     -1.2369954586029053e-01
    z[5,7,1]  R2008     2.7449575066566467e-01
    z[5,7,1]  R2009     -8.9514678716659546e-01
    z[5,7,1]  R2010     1.2293367832899094e-01
    z[5,7,1]  R2011     -0.889827311038971
    z[5,7,1]  R2012     -1.3678210973739624e-01
    z[5,7,1]  R2013     -2.3393984884023666e-02
    z[5,7,1]  R2014     3.3358085155487061e-01
    z[5,7,1]  R2015     -7.5847542285919189e-01
    z[5,7,1]  R2016     2.8464773297309875e-01
    z[5,7,1]  R2017     -3.7620380520820618e-01
    z[5,7,1]  R2018     -2.2337000072002411e-01
    z[5,7,1]  R2019     -1.9959750771522522e-01
    z[5,7,1]  R2020     -1.6205689311027527e-01
    z[5,7,1]  R2021     5.1615241914987564e-02
    z[5,7,1]  R2022     -8.8565431535243988e-02
    z[5,7,1]  R2023     6.8200731277465820e-01
    z[5,7,1]  R2024     4.6463176608085632e-01
    z[5,7,1]  R2025     0.702788770198822
    z[5,7,1]  R2026     1.8833984434604645e-01
    z[5,7,1]  R2027     -8.2548034191131592e-01
    z[5,7,1]  R2028     -2.7658230066299438e-01
    z[5,7,1]  R2029     -6.6683292388916016e-02
    z[5,7,1]  R2030     4.9134841561317444e-01
    z[5,7,1]  R2031     3.4632202982902527e-01
    z[5,7,1]  R2032     3.1011883169412613e-02
    z[5,7,1]  R2033     5.2983641624450684e-01
    z[5,7,1]  R2034     4.1821259260177612e-01
    z[5,7,1]  R2035     5.1034212112426758e-01
    z[5,7,1]  R2036     1.2049067020416260e-01
    z[5,7,1]  R2037     2.3231862485408783e-01
    z[5,7,1]  R2038     2.8565225005149841e-01
    z[5,7,1]  R2039     5.2151030302047729e-01
    z[5,7,1]  R2040     1.9055104255676270e-01
    z[5,7,1]  R2041     7.2859472036361694e-01
    z[5,7,1]  R2042     0.476112961769104
    z[5,7,1]  R2043     5.1500028371810913e-01
    z[5,7,1]  R2044     4.5134374499320984e-01
    z[5,7,1]  R2045     0.517600953578949
    z[5,7,2]  R49       -1
    z[5,7,2]  R67       1
    z[5,7,2]  R1968     -1
    z[5,7,2]  R1969     1
    z[5,7,2]  R1978     -6.1106526851654053e-01
    z[5,7,2]  R1979     -6.1709243059158325e-01
    z[5,7,2]  R1980     -4.1789144277572632e-01
    z[5,7,2]  R1981     -4.7554206848144531e-01
    z[5,7,2]  R1982     -6.7307806015014648e-01
    z[5,7,2]  R1983     -5.5688637495040894e-01
    z[5,7,2]  R1984     -2.8121533989906311e-01
    z[5,7,2]  R1985     -0.698015570640564
    z[5,7,2]  R1986     -5.9209811687469482e-01
    z[5,7,2]  R1987     8.1579720973968506e-01
    z[5,7,2]  R1988     7.7131724357604980e-01
    z[5,7,2]  R1989     5.6596356630325317e-01
    z[5,7,2]  R1990     0.581097424030304
    z[5,7,2]  R1991     3.5194832831621170e-02
    z[5,7,2]  R1992     5.5022466182708740e-01
    z[5,7,2]  R1993     3.7467437982559204e-01
    z[5,7,2]  R1994     0.185869038105011
    z[5,7,2]  R1995     2.8341516852378845e-01
    z[5,7,2]  R1996     4.6027562022209167e-01
    z[5,7,2]  R1997     1.8549726903438568e-01
    z[5,7,2]  R1998     -5.6430444121360779e-02
    z[5,7,2]  R1999     5.4062587022781372e-01
    z[5,7,2]  R2000     6.0086369514465332e-01
    z[5,7,2]  R2001     -4.1874074935913086e-01
    z[5,7,2]  R2002     5.0818151235580444e-01
    z[5,7,2]  R2003     6.8316936492919922e-01
    z[5,7,2]  R2004     -2.0684944093227386e-01
    z[5,7,2]  R2005     4.9719268083572388e-01
    z[5,7,2]  R2006     5.5894345045089722e-01
    z[5,7,2]  R2007     5.4726940393447876e-01
    z[5,7,2]  R2008     7.3217743635177612e-01
    z[5,7,2]  R2009     4.2120260000228882e-01
    z[5,7,2]  R2010     4.8127841949462891e-01
    z[5,7,2]  R2011     3.1994324922561646e-01
    z[5,7,2]  R2012     5.4639947414398193e-01
    z[5,7,2]  R2013     4.6196100115776062e-01
    z[5,7,2]  R2014     2.2199396789073944e-01
    z[5,7,2]  R2015     -2.1182221174240112e-01
    z[5,7,2]  R2016     -2.3711444437503815e-01
    z[5,7,2]  R2017     -1.7014425992965698e-01
    z[5,7,2]  R2018     1.7554818093776703e-01
    z[5,7,2]  R2019     -2.6097807288169861e-01
    z[5,7,2]  R2020     -4.7502890229225159e-01
    z[5,7,2]  R2021     -2.2710184752941132e-01
    z[5,7,2]  R2022     -2.8238528966903687e-01
    z[5,7,2]  R2023     1.4959146082401276e-01
    z[5,7,2]  R2024     2.1901136636734009e-01
    z[5,7,2]  R2025     5.6506818532943726e-01
    z[5,7,2]  R2026     7.5908845663070679e-01
    z[5,7,2]  R2027     2.3316064476966858e-01
    z[5,7,2]  R2028     1.1616774648427963e-01
    z[5,7,2]  R2029     -1.7606303095817566e-01
    z[5,7,2]  R2030     4.2033895850181580e-01
    z[5,7,2]  R2031     3.2234114408493042e-01
    z[5,7,2]  R2032     4.9098369479179382e-01
    z[5,7,2]  R2033     6.4764000475406647e-02
    z[5,7,2]  R2034     -3.6040741205215454e-01
    z[5,7,2]  R2035     6.1960095167160034e-01
    z[5,7,2]  R2036     -1.6804602742195129e-01
    z[5,7,2]  R2037     4.1956314444541931e-01
    z[5,7,2]  R2038     4.4844293594360352e-01
    z[5,7,2]  R2039     3.8353288173675537e-01
    z[5,7,2]  R2040     0.421851247549057
    z[5,7,2]  R2041     8.3521112799644470e-02
    z[5,7,2]  R2042     -2.0321704447269440e-01
    z[5,7,2]  R2043     -1.2585286796092987e-01
    z[5,7,2]  R2044     -2.1186162531375885e-01
    z[5,7,2]  R2045     6.4983642101287842e-01
    z[5,7,3]  R50       -1
    z[5,7,3]  R68       1
    z[5,7,3]  R1970     -1
    z[5,7,3]  R1971     1
    z[5,7,3]  R1978     -5.2917140722274780e-01
    z[5,7,3]  R1979     -3.5314863920211792e-01
    z[5,7,3]  R1980     -6.0037565231323242e-01
    z[5,7,3]  R1981     -5.5758535861968994e-01
    z[5,7,3]  R1982     -1.6042657196521759e-01
    z[5,7,3]  R1983     -3.3760768175125122e-01
    z[5,7,3]  R1984     -7.8490930795669556e-01
    z[5,7,3]  R1985     4.5755021274089813e-02
    z[5,7,3]  R1986     -2.9018133878707886e-01
    z[5,7,3]  R1987     1.0989991575479507e-01
    z[5,7,3]  R1988     3.5300999879837036e-01
    z[5,7,3]  R1989     3.8653177022933960e-01
    z[5,7,3]  R1990     4.5291340351104736e-01
    z[5,7,3]  R1991     1.9377514719963074e-01
    z[5,7,3]  R1992     1.3471165299415588e-01
    z[5,7,3]  R1993     2.3421159386634827e-01
    z[5,7,3]  R1994     1.1017097532749176e-01
    z[5,7,3]  R1995     7.6226450502872467e-02
    z[5,7,3]  R1996     2.0796790719032288e-01
    z[5,7,3]  R1997     1.4745345711708069e-01
    z[5,7,3]  R1998     1.7238780856132507e-01
    z[5,7,3]  R1999     -1.9658863544464111e-01
    z[5,7,3]  R2000     6.6063910722732544e-01
    z[5,7,3]  R2001     3.6536341905593872e-01
    z[5,7,3]  R2002     -1.4940737187862396e-01
    z[5,7,3]  R2003     4.5457309484481812e-01
    z[5,7,3]  R2004     2.2941657900810242e-01
    z[5,7,3]  R2005     -4.5434886217117310e-01
    z[5,7,3]  R2006     6.7545793950557709e-02
    z[5,7,3]  R2007     -3.8898780941963196e-02
    z[5,7,3]  R2008     1.7104667425155640e-01
    z[5,7,3]  R2009     -0.0592644065618515
    z[5,7,3]  R2010     7.8499954938888550e-01
    z[5,7,3]  R2011     -1.0627415776252747e-01
    z[5,7,3]  R2012     4.4233056902885437e-01
    z[5,7,3]  R2013     5.7241427898406982e-01
    z[5,7,3]  R2014     7.3525249958038330e-01
    z[5,7,3]  R2015     0.293355792760849
    z[5,7,3]  R2016     7.2702729701995850e-01
    z[5,7,3]  R2017     7.4696594476699829e-01
    z[5,7,3]  R2018     -7.9482358694076538e-01
    z[5,7,3]  R2019     -3.7739893794059753e-01
    z[5,7,3]  R2020     -8.0764904618263245e-02
    z[5,7,3]  R2021     1.9979354739189148e-01
    z[5,7,3]  R2022     3.8262015581130981e-01
    z[5,7,3]  R2023     2.7596119046211243e-01
    z[5,7,3]  R2024     1.8535287678241730e-01
    z[5,7,3]  R2025     -3.4371569752693176e-02
    z[5,7,3]  R2026     3.5858038067817688e-01
    z[5,7,3]  R2027     7.0522271096706390e-02
    z[5,7,3]  R2028     7.6576471328735352e-01
    z[5,7,3]  R2029     8.7756061553955078e-01
    z[5,7,3]  R2030     -1.1006095260381699e-01
    z[5,7,3]  R2031     3.4041205048561096e-01
    z[5,7,3]  R2032     5.4449033737182617e-01
    z[5,7,3]  R2033     4.1975349187850952e-01
    z[5,7,3]  R2034     -7.2573184967041016e-02
    z[5,7,3]  R2035     2.0260216668248177e-02
    z[5,7,3]  R2036     -1.3500805199146271e-01
    z[5,7,3]  R2037     2.1684104204177856e-01
    z[5,7,3]  R2038     4.3430694937705994e-01
    z[5,7,3]  R2039     2.4595226347446442e-01
    z[5,7,3]  R2040     2.8161951899528503e-01
    z[5,7,3]  R2041     0.00901623535901308
    z[5,7,3]  R2042     -4.5758393406867981e-01
    z[5,7,3]  R2043     4.2273014783859253e-01
    z[5,7,3]  R2044     6.0827469825744629e-01
    z[5,7,3]  R2045     1.8400286138057709e-01
    z[5,7,4]  R51       -1
    z[5,7,4]  R69       1
    z[5,7,4]  R1972     -1
    z[5,7,4]  R1973     1
    z[5,7,4]  R1978     -3.2975059747695923e-01
    z[5,7,4]  R1979     -3.2270956039428711e-01
    z[5,7,4]  R1980     -1.6008014976978302e-01
    z[5,7,4]  R1981     1.6464999318122864e-01
    z[5,7,4]  R1982     -3.6174979805946350e-01
    z[5,7,4]  R1983     -5.6766338646411896e-02
    z[5,7,4]  R1984     3.8014256954193115e-01
    z[5,7,4]  R1985     -5.4628050327301025e-01
    z[5,7,4]  R1986     2.1887996792793274e-01
    z[5,7,4]  R1987     -5.3625606000423431e-02
    z[5,7,4]  R1988     -9.6041090786457062e-02
    z[5,7,4]  R1989     -3.7073828279972076e-02
    z[5,7,4]  R1990     -4.5687353610992432e-01
    z[5,7,4]  R1991     -1.9509927928447723e-01
    z[5,7,4]  R1992     -3.6990082263946533e-01
    z[5,7,4]  R1993     -5.9515666216611862e-02
    z[5,7,4]  R1994     -7.7582925558090210e-02
    z[5,7,4]  R1995     -1.1067941784858704e-01
    z[5,7,4]  R1996     -1.4172458648681641e-01
    z[5,7,4]  R1997     5.7703603059053421e-02
    z[5,7,4]  R1998     5.5482137203216553e-01
    z[5,7,4]  R1999     -3.2768428325653076e-02
    z[5,7,4]  R2000     -1.7064218409359455e-03
    z[5,7,4]  R2001     8.1124818325042725e-01
    z[5,7,4]  R2002     5.6696657091379166e-02
    z[5,7,4]  R2003     1.9953319430351257e-01
    z[5,7,4]  R2004     8.9923244714736938e-01
    z[5,7,4]  R2005     -2.0589552819728851e-01
    z[5,7,4]  R2006     -1.0547125339508057e-01
    z[5,7,4]  R2007     -3.1715796794742346e-03
    z[5,7,4]  R2008     -2.3647494614124298e-01
    z[5,7,4]  R2009     2.3328827694058418e-02
    z[5,7,4]  R2010     -9.8830483853816986e-02
    z[5,7,4]  R2011     1.6807280480861664e-01
    z[5,7,4]  R2012     -6.0537587851285934e-02
    z[5,7,4]  R2013     -1.5713594853878021e-01
    z[5,7,4]  R2014     -1.3777065277099609e-01
    z[5,7,4]  R2015     2.1798150241374969e-01
    z[5,7,4]  R2016     4.3557864427566528e-01
    z[5,7,4]  R2017     3.2727840542793274e-01
    z[5,7,4]  R2018     -1.0521605610847473e-01
    z[5,7,4]  R2019     -6.6669136285781860e-01
    z[5,7,4]  R2020     4.0884606540203094e-02
    z[5,7,4]  R2021     -5.4078716039657593e-01
    z[5,7,4]  R2022     -1.9201116263866425e-01
    z[5,7,4]  R2023     9.9918648600578308e-02
    z[5,7,4]  R2024     -1.4944776892662048e-02
    z[5,7,4]  R2025     -1.1669119819998741e-02
    z[5,7,4]  R2026     3.0302062630653381e-01
    z[5,7,4]  R2027     1.8192978203296661e-01
    z[5,7,4]  R2028     -1.5622977912425995e-01
    z[5,7,4]  R2029     1.0299666225910187e-01
    z[5,7,4]  R2030     1.7547617852687836e-01
    z[5,7,4]  R2031     -2.6857721805572510e-01
    z[5,7,4]  R2032     3.1995329260826111e-01
    z[5,7,4]  R2033     6.8665152788162231e-01
    z[5,7,4]  R2034     5.3739798069000244e-01
    z[5,7,4]  R2035     1.2559781968593597e-01
    z[5,7,4]  R2036     7.2910869121551514e-01
    z[5,7,4]  R2037     5.8731347322463989e-01
    z[5,7,4]  R2038     3.6370679736137390e-01
    z[5,7,4]  R2039     2.7539917826652527e-01
    z[5,7,4]  R2040     6.5521574020385742e-01
    z[5,7,4]  R2041     4.1041484475135803e-01
    z[5,7,4]  R2042     4.4433760643005371e-01
    z[5,7,4]  R2043     3.7291434407234192e-01
    z[5,7,4]  R2044     2.2865977883338928e-01
    z[5,7,4]  R2045     -2.5542598962783813e-01
    z[5,7,5]  R52       -1
    z[5,7,5]  R70       1
    z[5,7,5]  R1974     -1
    z[5,7,5]  R1975     1
    z[5,7,5]  R1978     -1.9581261277198792e-01
    z[5,7,5]  R1979     -1.5446981787681580e-01
    z[5,7,5]  R1980     -2.6942875981330872e-01
    z[5,7,5]  R1981     -1.8457669019699097e-01
    z[5,7,5]  R1982     -2.7567198872566223e-01
    z[5,7,5]  R1983     -3.3022406697273254e-01
    z[5,7,5]  R1984     -2.6450985670089722e-01
    z[5,7,5]  R1985     -1.7573808133602142e-01
    z[5,7,5]  R1986     3.1393748521804810e-01
    z[5,7,5]  R1987     2.1167731285095215e-01
    z[5,7,5]  R1988     3.1547054648399353e-01
    z[5,7,5]  R1989     2.2521814703941345e-01
    z[5,7,5]  R1990     2.8799504041671753e-01
    z[5,7,5]  R1991     1.0257090628147125e-01
    z[5,7,5]  R1992     2.4985921382904053e-01
    z[5,7,5]  R1993     1.1288130283355713e-01
    z[5,7,5]  R1994     5.4335236549377441e-02
    z[5,7,5]  R1995     1.1946207284927368e-01
    z[5,7,5]  R1996     2.2022227942943573e-01
    z[5,7,5]  R1997     8.3384037017822266e-02
    z[5,7,5]  R1998     -2.4482456967234612e-02
    z[5,7,5]  R1999     1.6232512891292572e-01
    z[5,7,5]  R2000     2.6613163948059082e-01
    z[5,7,5]  R2001     -1.0773230344057083e-01
    z[5,7,5]  R2002     9.4823047518730164e-02
    z[5,7,5]  R2003     2.7530258893966675e-01
    z[5,7,5]  R2004     -1.1338969320058823e-01
    z[5,7,5]  R2005     4.9063485860824585e-01
    z[5,7,5]  R2006     1.9328027963638306e-01
    z[5,7,5]  R2007     3.6383220553398132e-01
    z[5,7,5]  R2008     2.1385115385055542e-01
    z[5,7,5]  R2009     1.1175382137298584e-01
    z[5,7,5]  R2010     2.8542625904083252e-01
    z[5,7,5]  R2011     3.2299514859914780e-02
    z[5,7,5]  R2012     2.3050366342067719e-01
    z[5,7,5]  R2013     2.7703121304512024e-01
    z[5,7,5]  R2014     2.7160212397575378e-01
    z[5,7,5]  R2015     1.3086847029626369e-02
    z[5,7,5]  R2016     7.5679324567317963e-02
    z[5,7,5]  R2017     1.4883327484130859e-01
    z[5,7,5]  R2018     4.8914080858230591e-01
    z[5,7,5]  R2019     8.4587134420871735e-02
    z[5,7,5]  R2020     3.8188643753528595e-02
    z[5,7,5]  R2021     1.0736273974180222e-01
    z[5,7,5]  R2022     4.8926255106925964e-01
    z[5,7,5]  R2023     0.434596449136734
    z[5,7,5]  R2024     5.5236268043518066e-01
    z[5,7,5]  R2025     -0.0758703202009201
    z[5,7,5]  R2026     -1.2080959230661392e-01
    z[5,7,5]  R2027     -4.3662688136100769e-01
    z[5,7,5]  R2028     5.2186584472656250e-01
    z[5,7,5]  R2029     2.9076170921325684e-01
    z[5,7,5]  R2030     -1.2655048072338104e-01
    z[5,7,5]  R2031     0.440373033285141
    z[5,7,5]  R2032     1.0545748472213745e-01
    z[5,7,5]  R2033     1.6299945116043091e-01
    z[5,7,5]  R2034     -1.3524267077445984e-01
    z[5,7,5]  R2035     9.4388015568256378e-02
    z[5,7,5]  R2036     2.4583670496940613e-01
    z[5,7,5]  R2037     3.0880689620971680e-01
    z[5,7,5]  R2038     3.0298420786857605e-01
    z[5,7,5]  R2039     2.0331549644470215e-01
    z[5,7,5]  R2040     5.8228474110364914e-02
    z[5,7,5]  R2041     2.6883718371391296e-01
    z[5,7,5]  R2042     -4.9682331085205078e-01
    z[5,7,5]  R2043     -6.2081003189086914e-01
    z[5,7,5]  R2044     -5.7314914464950562e-01
    z[5,7,5]  R2045     -2.4634602665901184e-01
    z[5,7,6]  R53       -1
    z[5,7,6]  R71       1
    z[5,7,6]  R1976     -1
    z[5,7,6]  R1977     1
    z[5,7,6]  R1978     0.39483642578125
    z[5,7,6]  R1979     4.1094845533370972e-01
    z[5,7,6]  R1980     -2.7579185366630554e-01
    z[5,7,6]  R1981     5.0886821746826172e-01
    z[5,7,6]  R1982     -5.3629726171493530e-01
    z[5,7,6]  R1983     -0.660996675491333
    z[5,7,6]  R1984     1.2309314310550690e-01
    z[5,7,6]  R1985     -2.7382916212081909e-01
    z[5,7,6]  R1986     1.3197000138461590e-02
    z[5,7,6]  R1987     -2.3683875799179077e-01
    z[5,7,6]  R1988     1.4986149966716766e-01
    z[5,7,6]  R1989     -9.7660243511199951e-02
    z[5,7,6]  R1990     -3.6668688058853149e-02
    z[5,7,6]  R1991     9.7606927156448364e-02
    z[5,7,6]  R1992     2.8507539629936218e-01
    z[5,7,6]  R1993     -1.9734199345111847e-01
    z[5,7,6]  R1994     -0.077787384390831
    z[5,7,6]  R1995     1.8730445206165314e-01
    z[5,7,6]  R1996     2.8510499000549316e-01
    z[5,7,6]  R1997     1.3623951375484467e-01
    z[5,7,6]  R1998     -1.2113806605339050e-01
    z[5,7,6]  R1999     2.2376336157321930e-01
    z[5,7,6]  R2000     -3.0174696445465088e-01
    z[5,7,6]  R2001     -2.8764383867383003e-02
    z[5,7,6]  R2002     -2.3102907463908195e-02
    z[5,7,6]  R2003     1.6892101615667343e-02
    z[5,7,6]  R2004     -2.1939021348953247e-01
    z[5,7,6]  R2005     2.3734977841377258e-01
    z[5,7,6]  R2006     1.3645261526107788e-01
    z[5,7,6]  R2007     3.5766372084617615e-01
    z[5,7,6]  R2008     -2.3777644336223602e-01
    z[5,7,6]  R2009     6.8924024701118469e-02
    z[5,7,6]  R2010     -1.7019283771514893e-01
    z[5,7,6]  R2011     -2.3284508287906647e-01
    z[5,7,6]  R2012     -1.3061454892158508e-01
    z[5,7,6]  R2013     9.3289464712142944e-02
    z[5,7,6]  R2014     2.4649918079376221e-01
    z[5,7,6]  R2015     9.6176296472549438e-02
    z[5,7,6]  R2016     1.7258486151695251e-01
    z[5,7,6]  R2017     3.1061553955078125e-01
    z[5,7,6]  R2018     -1.8870523571968079e-01
    z[5,7,6]  R2019     4.9171319603919983e-01
    z[5,7,6]  R2020     -0.60362309217453
    z[5,7,6]  R2021     -5.6403923034667969e-01
    z[5,7,6]  R2022     1.8313153088092804e-01
    z[5,7,6]  R2023     -0.199942946434021
    z[5,7,6]  R2024     4.3690595030784607e-01
    z[5,7,6]  R2025     1.5703898668289185e-01
    z[5,7,6]  R2026     -9.6078030765056610e-02
    z[5,7,6]  R2027     1.3117891550064087e-01
    z[5,7,6]  R2028     -0.143079936504364
    z[5,7,6]  R2029     2.5943225622177124e-01
    z[5,7,6]  R2030     3.5275071859359741e-01
    z[5,7,6]  R2031     2.4008680880069733e-01
    z[5,7,6]  R2032     -3.1180027127265930e-01
    z[5,7,6]  R2033     9.8663859069347382e-02
    z[5,7,6]  R2034     0.53147953748703
    z[5,7,6]  R2035     2.5697031617164612e-01
    z[5,7,6]  R2036     5.0778478384017944e-01
    z[5,7,6]  R2037     -3.2275646924972534e-01
    z[5,7,6]  R2038     2.4430163204669952e-02
    z[5,7,6]  R2039     -2.3918202519416809e-01
    z[5,7,6]  R2040     3.1802043318748474e-01
    z[5,7,6]  R2041     3.4584742784500122e-01
    z[5,7,6]  R2042     2.4959772825241089e-01
    z[5,7,6]  R2043     -1.1505239456892014e-01
    z[5,7,6]  R2044     1.0968401096761227e-02
    z[5,7,6]  R2045     -3.5311821848154068e-02
    z[7,5,0]  R47       1
    z[7,5,0]  R65       -1
    z[7,5,0]  R2046     -1
    z[7,5,0]  R2047     1
    z[7,5,0]  R2060     4.0067169815301895e-02
    z[7,5,0]  R2061     -2.3708039522171021e-01
    z[7,5,0]  R2062     -6.1161381006240845e-01
    z[7,5,0]  R2063     5.3265875577926636e-01
    z[7,5,0]  R2064     6.7545038461685181e-01
    z[7,5,0]  R2065     4.4440844655036926e-01
    z[7,5,0]  R2066     4.5341044664382935e-01
    z[7,5,0]  R2067     -3.9376479387283325e-01
    z[7,5,0]  R2068     -3.7958592176437378e-01
    z[7,5,0]  R2069     -1.3526062667369843e-01
    z[7,5,0]  R2070     0.0799262747168541
    z[7,5,0]  R2071     -1.7884841561317444e-01
    z[7,5,0]  R2072     6.3129913806915283e-01
    z[7,5,0]  R2073     5.8014911413192749e-01
    z[7,5,0]  R2074     5.0079208612442017e-01
    z[7,5,0]  R2075     0.176330104470253
    z[7,5,0]  R2076     -3.1682834029197693e-01
    z[7,5,0]  R2077     -5.1431256532669067e-01
    z[7,5,0]  R2078     -2.9855456948280334e-01
    z[7,5,0]  R2079     4.2249751091003418e-01
    z[7,5,0]  R2080     5.5136221647262573e-01
    z[7,5,0]  R2081     5.8825761079788208e-01
    z[7,5,0]  R2082     4.1543582081794739e-01
    z[7,5,0]  R2083     3.1901162862777710e-01
    z[7,5,0]  R2084     -1.2675908207893372e-01
    z[7,5,0]  R2085     5.0275996327400208e-02
    z[7,5,0]  R2086     -2.2355319932103157e-02
    z[7,5,0]  R2087     -3.8570597767829895e-01
    z[7,5,0]  R2088     -1.3222447037696838e-01
    z[7,5,0]  R2089     4.4330772757530212e-01
    z[7,5,0]  R2090     5.1061475276947021e-01
    z[7,5,0]  R2091     3.6846846342086792e-01
    z[7,5,0]  R2092     -1.4600045979022980e-01
    z[7,5,0]  R2093     5.6267328560352325e-02
    z[7,5,0]  R2094     -2.3827967047691345e-01
    z[7,5,0]  R2095     3.1948262453079224e-01
    z[7,5,0]  R2096     5.4506051540374756e-01
    z[7,5,0]  R2097     -4.5493689179420471e-01
    z[7,5,0]  R2098     -5.8300759643316269e-02
    z[7,5,0]  R2099     4.5845970511436462e-01
    z[7,5,0]  R2100     1.2683887779712677e-01
    z[7,5,0]  R2101     -1.1591664701700211e-01
    z[7,5,0]  R2102     2.8984561562538147e-01
    z[7,5,0]  R2103     4.3581213802099228e-02
    z[7,5,0]  R2104     2.8131446242332458e-01
    z[7,5,0]  R2105     3.0815801024436951e-01
    z[7,5,0]  R2106     3.6679348349571228e-01
    z[7,5,0]  R2107     2.0239928364753723e-01
    z[7,5,0]  R2108     3.4378626942634583e-01
    z[7,5,0]  R2109     3.5512766242027283e-01
    z[7,5,0]  R2110     0.172831192612648
    z[7,5,0]  R2111     -1.1071722209453583e-01
    z[7,5,0]  R2112     -1.2994001805782318e-01
    z[7,5,0]  R2113     -4.2620870471000671e-01
    z[7,5,0]  R2114     1.7344912886619568e-01
    z[7,5,0]  R2115     4.4796681404113770e-01
    z[7,5,0]  R2116     -7.8268569707870483e-01
    z[7,5,0]  R2117     -6.5067225694656372e-01
    z[7,5,0]  R2118     -4.4846507906913757e-01
    z[7,5,0]  R2119     -2.1969492081552744e-03
    z[7,5,0]  R2120     -1.2974171340465546e-01
    z[7,5,0]  R2121     -1.0507542639970779e-01
    z[7,5,0]  R2122     -6.4282584190368652e-01
    z[7,5,0]  R2123     -5.9012347459793091e-01
    z[7,5,0]  R2124     3.8122949004173279e-01
    z[7,5,0]  R2125     -4.8667392134666443e-01
    z[7,5,0]  R2126     -3.3006361126899719e-01
    z[7,5,0]  R2127     2.1405370533466339e-01
    z[7,5,1]  R48       1
    z[7,5,1]  R66       -1
    z[7,5,1]  R2048     -1
    z[7,5,1]  R2049     1
    z[7,5,1]  R2060     -2.2337000072002411e-01
    z[7,5,1]  R2061     -1.9959750771522522e-01
    z[7,5,1]  R2062     -1.6205689311027527e-01
    z[7,5,1]  R2063     5.1615241914987564e-02
    z[7,5,1]  R2064     -8.8565431535243988e-02
    z[7,5,1]  R2065     6.8200731277465820e-01
    z[7,5,1]  R2066     4.6463176608085632e-01
    z[7,5,1]  R2067     0.702788770198822
    z[7,5,1]  R2068     1.8833984434604645e-01
    z[7,5,1]  R2069     -8.2548034191131592e-01
    z[7,5,1]  R2070     -2.7658230066299438e-01
    z[7,5,1]  R2071     -6.6683292388916016e-02
    z[7,5,1]  R2072     4.9134841561317444e-01
    z[7,5,1]  R2073     3.4632202982902527e-01
    z[7,5,1]  R2074     3.1011883169412613e-02
    z[7,5,1]  R2075     5.2983641624450684e-01
    z[7,5,1]  R2076     4.1821259260177612e-01
    z[7,5,1]  R2077     5.1034212112426758e-01
    z[7,5,1]  R2078     1.2049067020416260e-01
    z[7,5,1]  R2079     2.3231862485408783e-01
    z[7,5,1]  R2080     2.8565225005149841e-01
    z[7,5,1]  R2081     5.2151030302047729e-01
    z[7,5,1]  R2082     1.9055104255676270e-01
    z[7,5,1]  R2083     7.2859472036361694e-01
    z[7,5,1]  R2084     0.476112961769104
    z[7,5,1]  R2085     5.1500028371810913e-01
    z[7,5,1]  R2086     4.5134374499320984e-01
    z[7,5,1]  R2087     0.517600953578949
    z[7,5,1]  R2088     -1.6161552071571350e-01
    z[7,5,1]  R2089     3.2868351787328720e-02
    z[7,5,1]  R2090     -1.7294447124004364e-01
    z[7,5,1]  R2091     -8.4048956632614136e-02
    z[7,5,1]  R2092     -7.3759369552135468e-02
    z[7,5,1]  R2093     1.5344594419002533e-01
    z[7,5,1]  R2094     -1.3576546311378479e-01
    z[7,5,1]  R2095     -6.5748848021030426e-02
    z[7,5,1]  R2096     -3.4854590892791748e-01
    z[7,5,1]  R2097     1.0795310884714127e-01
    z[7,5,1]  R2098     3.8190406560897827e-01
    z[7,5,1]  R2099     0.508387565612793
    z[7,5,1]  R2100     3.8482189178466797e-01
    z[7,5,1]  R2101     -9.4322019815444946e-01
    z[7,5,1]  R2102     5.6086617708206177e-01
    z[7,5,1]  R2103     8.6465978622436523e-01
    z[7,5,1]  R2104     9.2690610885620117e-01
    z[7,5,1]  R2105     8.7022984027862549e-01
    z[7,5,1]  R2106     6.7859381437301636e-01
    z[7,5,1]  R2107     9.3490058183670044e-01
    z[7,5,1]  R2108     -7.2512662410736084e-01
    z[7,5,1]  R2109     -6.8225187063217163e-01
    z[7,5,1]  R2110     1.0376872122287750e-01
    z[7,5,1]  R2111     -9.1379128396511078e-02
    z[7,5,1]  R2112     -8.3054494857788086e-01
    z[7,5,1]  R2113     -1.7058350145816803e-01
    z[7,5,1]  R2114     -6.9917507469654083e-02
    z[7,5,1]  R2115     -7.9005323350429535e-02
    z[7,5,1]  R2116     -5.7636916637420654e-02
    z[7,5,1]  R2117     -1.2369954586029053e-01
    z[7,5,1]  R2118     2.7449575066566467e-01
    z[7,5,1]  R2119     -8.9514678716659546e-01
    z[7,5,1]  R2120     1.2293367832899094e-01
    z[7,5,1]  R2121     -0.889827311038971
    z[7,5,1]  R2122     -1.3678210973739624e-01
    z[7,5,1]  R2123     -2.3393984884023666e-02
    z[7,5,1]  R2124     3.3358085155487061e-01
    z[7,5,1]  R2125     -7.5847542285919189e-01
    z[7,5,1]  R2126     2.8464773297309875e-01
    z[7,5,1]  R2127     -3.7620380520820618e-01
    z[7,5,2]  R49       1
    z[7,5,2]  R67       -1
    z[7,5,2]  R2050     -1
    z[7,5,2]  R2051     1
    z[7,5,2]  R2060     1.7554818093776703e-01
    z[7,5,2]  R2061     -2.6097807288169861e-01
    z[7,5,2]  R2062     -4.7502890229225159e-01
    z[7,5,2]  R2063     -2.2710184752941132e-01
    z[7,5,2]  R2064     -2.8238528966903687e-01
    z[7,5,2]  R2065     1.4959146082401276e-01
    z[7,5,2]  R2066     2.1901136636734009e-01
    z[7,5,2]  R2067     5.6506818532943726e-01
    z[7,5,2]  R2068     7.5908845663070679e-01
    z[7,5,2]  R2069     2.3316064476966858e-01
    z[7,5,2]  R2070     1.1616774648427963e-01
    z[7,5,2]  R2071     -1.7606303095817566e-01
    z[7,5,2]  R2072     4.2033895850181580e-01
    z[7,5,2]  R2073     3.2234114408493042e-01
    z[7,5,2]  R2074     4.9098369479179382e-01
    z[7,5,2]  R2075     6.4764000475406647e-02
    z[7,5,2]  R2076     -3.6040741205215454e-01
    z[7,5,2]  R2077     6.1960095167160034e-01
    z[7,5,2]  R2078     -1.6804602742195129e-01
    z[7,5,2]  R2079     4.1956314444541931e-01
    z[7,5,2]  R2080     4.4844293594360352e-01
    z[7,5,2]  R2081     3.8353288173675537e-01
    z[7,5,2]  R2082     0.421851247549057
    z[7,5,2]  R2083     8.3521112799644470e-02
    z[7,5,2]  R2084     -2.0321704447269440e-01
    z[7,5,2]  R2085     -1.2585286796092987e-01
    z[7,5,2]  R2086     -2.1186162531375885e-01
    z[7,5,2]  R2087     6.4983642101287842e-01
    z[7,5,2]  R2088     -6.1106526851654053e-01
    z[7,5,2]  R2089     -6.1709243059158325e-01
    z[7,5,2]  R2090     -4.1789144277572632e-01
    z[7,5,2]  R2091     -4.7554206848144531e-01
    z[7,5,2]  R2092     -6.7307806015014648e-01
    z[7,5,2]  R2093     -5.5688637495040894e-01
    z[7,5,2]  R2094     -2.8121533989906311e-01
    z[7,5,2]  R2095     -0.698015570640564
    z[7,5,2]  R2096     -5.9209811687469482e-01
    z[7,5,2]  R2097     8.1579720973968506e-01
    z[7,5,2]  R2098     7.7131724357604980e-01
    z[7,5,2]  R2099     5.6596356630325317e-01
    z[7,5,2]  R2100     0.581097424030304
    z[7,5,2]  R2101     3.5194832831621170e-02
    z[7,5,2]  R2102     5.5022466182708740e-01
    z[7,5,2]  R2103     3.7467437982559204e-01
    z[7,5,2]  R2104     0.185869038105011
    z[7,5,2]  R2105     2.8341516852378845e-01
    z[7,5,2]  R2106     4.6027562022209167e-01
    z[7,5,2]  R2107     1.8549726903438568e-01
    z[7,5,2]  R2108     -5.6430444121360779e-02
    z[7,5,2]  R2109     5.4062587022781372e-01
    z[7,5,2]  R2110     6.0086369514465332e-01
    z[7,5,2]  R2111     -4.1874074935913086e-01
    z[7,5,2]  R2112     5.0818151235580444e-01
    z[7,5,2]  R2113     6.8316936492919922e-01
    z[7,5,2]  R2114     -2.0684944093227386e-01
    z[7,5,2]  R2115     4.9719268083572388e-01
    z[7,5,2]  R2116     5.5894345045089722e-01
    z[7,5,2]  R2117     5.4726940393447876e-01
    z[7,5,2]  R2118     7.3217743635177612e-01
    z[7,5,2]  R2119     4.2120260000228882e-01
    z[7,5,2]  R2120     4.8127841949462891e-01
    z[7,5,2]  R2121     3.1994324922561646e-01
    z[7,5,2]  R2122     5.4639947414398193e-01
    z[7,5,2]  R2123     4.6196100115776062e-01
    z[7,5,2]  R2124     2.2199396789073944e-01
    z[7,5,2]  R2125     -2.1182221174240112e-01
    z[7,5,2]  R2126     -2.3711444437503815e-01
    z[7,5,2]  R2127     -1.7014425992965698e-01
    z[7,5,3]  R50       1
    z[7,5,3]  R68       -1
    z[7,5,3]  R2052     -1
    z[7,5,3]  R2053     1
    z[7,5,3]  R2060     -7.9482358694076538e-01
    z[7,5,3]  R2061     -3.7739893794059753e-01
    z[7,5,3]  R2062     -8.0764904618263245e-02
    z[7,5,3]  R2063     1.9979354739189148e-01
    z[7,5,3]  R2064     3.8262015581130981e-01
    z[7,5,3]  R2065     2.7596119046211243e-01
    z[7,5,3]  R2066     1.8535287678241730e-01
    z[7,5,3]  R2067     -3.4371569752693176e-02
    z[7,5,3]  R2068     3.5858038067817688e-01
    z[7,5,3]  R2069     7.0522271096706390e-02
    z[7,5,3]  R2070     7.6576471328735352e-01
    z[7,5,3]  R2071     8.7756061553955078e-01
    z[7,5,3]  R2072     -1.1006095260381699e-01
    z[7,5,3]  R2073     3.4041205048561096e-01
    z[7,5,3]  R2074     5.4449033737182617e-01
    z[7,5,3]  R2075     4.1975349187850952e-01
    z[7,5,3]  R2076     -7.2573184967041016e-02
    z[7,5,3]  R2077     2.0260216668248177e-02
    z[7,5,3]  R2078     -1.3500805199146271e-01
    z[7,5,3]  R2079     2.1684104204177856e-01
    z[7,5,3]  R2080     4.3430694937705994e-01
    z[7,5,3]  R2081     2.4595226347446442e-01
    z[7,5,3]  R2082     2.8161951899528503e-01
    z[7,5,3]  R2083     0.00901623535901308
    z[7,5,3]  R2084     -4.5758393406867981e-01
    z[7,5,3]  R2085     4.2273014783859253e-01
    z[7,5,3]  R2086     6.0827469825744629e-01
    z[7,5,3]  R2087     1.8400286138057709e-01
    z[7,5,3]  R2088     -5.2917140722274780e-01
    z[7,5,3]  R2089     -3.5314863920211792e-01
    z[7,5,3]  R2090     -6.0037565231323242e-01
    z[7,5,3]  R2091     -5.5758535861968994e-01
    z[7,5,3]  R2092     -1.6042657196521759e-01
    z[7,5,3]  R2093     -3.3760768175125122e-01
    z[7,5,3]  R2094     -7.8490930795669556e-01
    z[7,5,3]  R2095     4.5755021274089813e-02
    z[7,5,3]  R2096     -2.9018133878707886e-01
    z[7,5,3]  R2097     1.0989991575479507e-01
    z[7,5,3]  R2098     3.5300999879837036e-01
    z[7,5,3]  R2099     3.8653177022933960e-01
    z[7,5,3]  R2100     4.5291340351104736e-01
    z[7,5,3]  R2101     1.9377514719963074e-01
    z[7,5,3]  R2102     1.3471165299415588e-01
    z[7,5,3]  R2103     2.3421159386634827e-01
    z[7,5,3]  R2104     1.1017097532749176e-01
    z[7,5,3]  R2105     7.6226450502872467e-02
    z[7,5,3]  R2106     2.0796790719032288e-01
    z[7,5,3]  R2107     1.4745345711708069e-01
    z[7,5,3]  R2108     1.7238780856132507e-01
    z[7,5,3]  R2109     -1.9658863544464111e-01
    z[7,5,3]  R2110     6.6063910722732544e-01
    z[7,5,3]  R2111     3.6536341905593872e-01
    z[7,5,3]  R2112     -1.4940737187862396e-01
    z[7,5,3]  R2113     4.5457309484481812e-01
    z[7,5,3]  R2114     2.2941657900810242e-01
    z[7,5,3]  R2115     -4.5434886217117310e-01
    z[7,5,3]  R2116     6.7545793950557709e-02
    z[7,5,3]  R2117     -3.8898780941963196e-02
    z[7,5,3]  R2118     1.7104667425155640e-01
    z[7,5,3]  R2119     -0.0592644065618515
    z[7,5,3]  R2120     7.8499954938888550e-01
    z[7,5,3]  R2121     -1.0627415776252747e-01
    z[7,5,3]  R2122     4.4233056902885437e-01
    z[7,5,3]  R2123     5.7241427898406982e-01
    z[7,5,3]  R2124     7.3525249958038330e-01
    z[7,5,3]  R2125     0.293355792760849
    z[7,5,3]  R2126     7.2702729701995850e-01
    z[7,5,3]  R2127     7.4696594476699829e-01
    z[7,5,4]  R51       1
    z[7,5,4]  R69       -1
    z[7,5,4]  R2054     -1
    z[7,5,4]  R2055     1
    z[7,5,4]  R2060     -1.0521605610847473e-01
    z[7,5,4]  R2061     -6.6669136285781860e-01
    z[7,5,4]  R2062     4.0884606540203094e-02
    z[7,5,4]  R2063     -5.4078716039657593e-01
    z[7,5,4]  R2064     -1.9201116263866425e-01
    z[7,5,4]  R2065     9.9918648600578308e-02
    z[7,5,4]  R2066     -1.4944776892662048e-02
    z[7,5,4]  R2067     -1.1669119819998741e-02
    z[7,5,4]  R2068     3.0302062630653381e-01
    z[7,5,4]  R2069     1.8192978203296661e-01
    z[7,5,4]  R2070     -1.5622977912425995e-01
    z[7,5,4]  R2071     1.0299666225910187e-01
    z[7,5,4]  R2072     1.7547617852687836e-01
    z[7,5,4]  R2073     -2.6857721805572510e-01
    z[7,5,4]  R2074     3.1995329260826111e-01
    z[7,5,4]  R2075     6.8665152788162231e-01
    z[7,5,4]  R2076     5.3739798069000244e-01
    z[7,5,4]  R2077     1.2559781968593597e-01
    z[7,5,4]  R2078     7.2910869121551514e-01
    z[7,5,4]  R2079     5.8731347322463989e-01
    z[7,5,4]  R2080     3.6370679736137390e-01
    z[7,5,4]  R2081     2.7539917826652527e-01
    z[7,5,4]  R2082     6.5521574020385742e-01
    z[7,5,4]  R2083     4.1041484475135803e-01
    z[7,5,4]  R2084     4.4433760643005371e-01
    z[7,5,4]  R2085     3.7291434407234192e-01
    z[7,5,4]  R2086     2.2865977883338928e-01
    z[7,5,4]  R2087     -2.5542598962783813e-01
    z[7,5,4]  R2088     -3.2975059747695923e-01
    z[7,5,4]  R2089     -3.2270956039428711e-01
    z[7,5,4]  R2090     -1.6008014976978302e-01
    z[7,5,4]  R2091     1.6464999318122864e-01
    z[7,5,4]  R2092     -3.6174979805946350e-01
    z[7,5,4]  R2093     -5.6766338646411896e-02
    z[7,5,4]  R2094     3.8014256954193115e-01
    z[7,5,4]  R2095     -5.4628050327301025e-01
    z[7,5,4]  R2096     2.1887996792793274e-01
    z[7,5,4]  R2097     -5.3625606000423431e-02
    z[7,5,4]  R2098     -9.6041090786457062e-02
    z[7,5,4]  R2099     -3.7073828279972076e-02
    z[7,5,4]  R2100     -4.5687353610992432e-01
    z[7,5,4]  R2101     -1.9509927928447723e-01
    z[7,5,4]  R2102     -3.6990082263946533e-01
    z[7,5,4]  R2103     -5.9515666216611862e-02
    z[7,5,4]  R2104     -7.7582925558090210e-02
    z[7,5,4]  R2105     -1.1067941784858704e-01
    z[7,5,4]  R2106     -1.4172458648681641e-01
    z[7,5,4]  R2107     5.7703603059053421e-02
    z[7,5,4]  R2108     5.5482137203216553e-01
    z[7,5,4]  R2109     -3.2768428325653076e-02
    z[7,5,4]  R2110     -1.7064218409359455e-03
    z[7,5,4]  R2111     8.1124818325042725e-01
    z[7,5,4]  R2112     5.6696657091379166e-02
    z[7,5,4]  R2113     1.9953319430351257e-01
    z[7,5,4]  R2114     8.9923244714736938e-01
    z[7,5,4]  R2115     -2.0589552819728851e-01
    z[7,5,4]  R2116     -1.0547125339508057e-01
    z[7,5,4]  R2117     -3.1715796794742346e-03
    z[7,5,4]  R2118     -2.3647494614124298e-01
    z[7,5,4]  R2119     2.3328827694058418e-02
    z[7,5,4]  R2120     -9.8830483853816986e-02
    z[7,5,4]  R2121     1.6807280480861664e-01
    z[7,5,4]  R2122     -6.0537587851285934e-02
    z[7,5,4]  R2123     -1.5713594853878021e-01
    z[7,5,4]  R2124     -1.3777065277099609e-01
    z[7,5,4]  R2125     2.1798150241374969e-01
    z[7,5,4]  R2126     4.3557864427566528e-01
    z[7,5,4]  R2127     3.2727840542793274e-01
    z[7,5,5]  R52       1
    z[7,5,5]  R70       -1
    z[7,5,5]  R2056     -1
    z[7,5,5]  R2057     1
    z[7,5,5]  R2060     4.8914080858230591e-01
    z[7,5,5]  R2061     8.4587134420871735e-02
    z[7,5,5]  R2062     3.8188643753528595e-02
    z[7,5,5]  R2063     1.0736273974180222e-01
    z[7,5,5]  R2064     4.8926255106925964e-01
    z[7,5,5]  R2065     0.434596449136734
    z[7,5,5]  R2066     5.5236268043518066e-01
    z[7,5,5]  R2067     -0.0758703202009201
    z[7,5,5]  R2068     -1.2080959230661392e-01
    z[7,5,5]  R2069     -4.3662688136100769e-01
    z[7,5,5]  R2070     5.2186584472656250e-01
    z[7,5,5]  R2071     2.9076170921325684e-01
    z[7,5,5]  R2072     -1.2655048072338104e-01
    z[7,5,5]  R2073     0.440373033285141
    z[7,5,5]  R2074     1.0545748472213745e-01
    z[7,5,5]  R2075     1.6299945116043091e-01
    z[7,5,5]  R2076     -1.3524267077445984e-01
    z[7,5,5]  R2077     9.4388015568256378e-02
    z[7,5,5]  R2078     2.4583670496940613e-01
    z[7,5,5]  R2079     3.0880689620971680e-01
    z[7,5,5]  R2080     3.0298420786857605e-01
    z[7,5,5]  R2081     2.0331549644470215e-01
    z[7,5,5]  R2082     5.8228474110364914e-02
    z[7,5,5]  R2083     2.6883718371391296e-01
    z[7,5,5]  R2084     -4.9682331085205078e-01
    z[7,5,5]  R2085     -6.2081003189086914e-01
    z[7,5,5]  R2086     -5.7314914464950562e-01
    z[7,5,5]  R2087     -2.4634602665901184e-01
    z[7,5,5]  R2088     -1.9581261277198792e-01
    z[7,5,5]  R2089     -1.5446981787681580e-01
    z[7,5,5]  R2090     -2.6942875981330872e-01
    z[7,5,5]  R2091     -1.8457669019699097e-01
    z[7,5,5]  R2092     -2.7567198872566223e-01
    z[7,5,5]  R2093     -3.3022406697273254e-01
    z[7,5,5]  R2094     -2.6450985670089722e-01
    z[7,5,5]  R2095     -1.7573808133602142e-01
    z[7,5,5]  R2096     3.1393748521804810e-01
    z[7,5,5]  R2097     2.1167731285095215e-01
    z[7,5,5]  R2098     3.1547054648399353e-01
    z[7,5,5]  R2099     2.2521814703941345e-01
    z[7,5,5]  R2100     2.8799504041671753e-01
    z[7,5,5]  R2101     1.0257090628147125e-01
    z[7,5,5]  R2102     2.4985921382904053e-01
    z[7,5,5]  R2103     1.1288130283355713e-01
    z[7,5,5]  R2104     5.4335236549377441e-02
    z[7,5,5]  R2105     1.1946207284927368e-01
    z[7,5,5]  R2106     2.2022227942943573e-01
    z[7,5,5]  R2107     8.3384037017822266e-02
    z[7,5,5]  R2108     -2.4482456967234612e-02
    z[7,5,5]  R2109     1.6232512891292572e-01
    z[7,5,5]  R2110     2.6613163948059082e-01
    z[7,5,5]  R2111     -1.0773230344057083e-01
    z[7,5,5]  R2112     9.4823047518730164e-02
    z[7,5,5]  R2113     2.7530258893966675e-01
    z[7,5,5]  R2114     -1.1338969320058823e-01
    z[7,5,5]  R2115     4.9063485860824585e-01
    z[7,5,5]  R2116     1.9328027963638306e-01
    z[7,5,5]  R2117     3.6383220553398132e-01
    z[7,5,5]  R2118     2.1385115385055542e-01
    z[7,5,5]  R2119     1.1175382137298584e-01
    z[7,5,5]  R2120     2.8542625904083252e-01
    z[7,5,5]  R2121     3.2299514859914780e-02
    z[7,5,5]  R2122     2.3050366342067719e-01
    z[7,5,5]  R2123     2.7703121304512024e-01
    z[7,5,5]  R2124     2.7160212397575378e-01
    z[7,5,5]  R2125     1.3086847029626369e-02
    z[7,5,5]  R2126     7.5679324567317963e-02
    z[7,5,5]  R2127     1.4883327484130859e-01
    z[7,5,6]  R53       1
    z[7,5,6]  R71       -1
    z[7,5,6]  R2058     -1
    z[7,5,6]  R2059     1
    z[7,5,6]  R2060     -1.8870523571968079e-01
    z[7,5,6]  R2061     4.9171319603919983e-01
    z[7,5,6]  R2062     -0.60362309217453
    z[7,5,6]  R2063     -5.6403923034667969e-01
    z[7,5,6]  R2064     1.8313153088092804e-01
    z[7,5,6]  R2065     -0.199942946434021
    z[7,5,6]  R2066     4.3690595030784607e-01
    z[7,5,6]  R2067     1.5703898668289185e-01
    z[7,5,6]  R2068     -9.6078030765056610e-02
    z[7,5,6]  R2069     1.3117891550064087e-01
    z[7,5,6]  R2070     -0.143079936504364
    z[7,5,6]  R2071     2.5943225622177124e-01
    z[7,5,6]  R2072     3.5275071859359741e-01
    z[7,5,6]  R2073     2.4008680880069733e-01
    z[7,5,6]  R2074     -3.1180027127265930e-01
    z[7,5,6]  R2075     9.8663859069347382e-02
    z[7,5,6]  R2076     0.53147953748703
    z[7,5,6]  R2077     2.5697031617164612e-01
    z[7,5,6]  R2078     5.0778478384017944e-01
    z[7,5,6]  R2079     -3.2275646924972534e-01
    z[7,5,6]  R2080     2.4430163204669952e-02
    z[7,5,6]  R2081     -2.3918202519416809e-01
    z[7,5,6]  R2082     3.1802043318748474e-01
    z[7,5,6]  R2083     3.4584742784500122e-01
    z[7,5,6]  R2084     2.4959772825241089e-01
    z[7,5,6]  R2085     -1.1505239456892014e-01
    z[7,5,6]  R2086     1.0968401096761227e-02
    z[7,5,6]  R2087     -3.5311821848154068e-02
    z[7,5,6]  R2088     0.39483642578125
    z[7,5,6]  R2089     4.1094845533370972e-01
    z[7,5,6]  R2090     -2.7579185366630554e-01
    z[7,5,6]  R2091     5.0886821746826172e-01
    z[7,5,6]  R2092     -5.3629726171493530e-01
    z[7,5,6]  R2093     -0.660996675491333
    z[7,5,6]  R2094     1.2309314310550690e-01
    z[7,5,6]  R2095     -2.7382916212081909e-01
    z[7,5,6]  R2096     1.3197000138461590e-02
    z[7,5,6]  R2097     -2.3683875799179077e-01
    z[7,5,6]  R2098     1.4986149966716766e-01
    z[7,5,6]  R2099     -9.7660243511199951e-02
    z[7,5,6]  R2100     -3.6668688058853149e-02
    z[7,5,6]  R2101     9.7606927156448364e-02
    z[7,5,6]  R2102     2.8507539629936218e-01
    z[7,5,6]  R2103     -1.9734199345111847e-01
    z[7,5,6]  R2104     -0.077787384390831
    z[7,5,6]  R2105     1.8730445206165314e-01
    z[7,5,6]  R2106     2.8510499000549316e-01
    z[7,5,6]  R2107     1.3623951375484467e-01
    z[7,5,6]  R2108     -1.2113806605339050e-01
    z[7,5,6]  R2109     2.2376336157321930e-01
    z[7,5,6]  R2110     -3.0174696445465088e-01
    z[7,5,6]  R2111     -2.8764383867383003e-02
    z[7,5,6]  R2112     -2.3102907463908195e-02
    z[7,5,6]  R2113     1.6892101615667343e-02
    z[7,5,6]  R2114     -2.1939021348953247e-01
    z[7,5,6]  R2115     2.3734977841377258e-01
    z[7,5,6]  R2116     1.3645261526107788e-01
    z[7,5,6]  R2117     3.5766372084617615e-01
    z[7,5,6]  R2118     -2.3777644336223602e-01
    z[7,5,6]  R2119     6.8924024701118469e-02
    z[7,5,6]  R2120     -1.7019283771514893e-01
    z[7,5,6]  R2121     -2.3284508287906647e-01
    z[7,5,6]  R2122     -1.3061454892158508e-01
    z[7,5,6]  R2123     9.3289464712142944e-02
    z[7,5,6]  R2124     2.4649918079376221e-01
    z[7,5,6]  R2125     9.6176296472549438e-02
    z[7,5,6]  R2126     1.7258486151695251e-01
    z[7,5,6]  R2127     3.1061553955078125e-01
    z[6,7,0]  R56       -1
    z[6,7,0]  R65       1
    z[6,7,0]  R2182     -1
    z[6,7,0]  R2183     1
    z[6,7,0]  R2196     3.5783922672271729e-01
    z[6,7,0]  R2197     0.214617520570755
    z[6,7,0]  R2198     2.5890854001045227e-01
    z[6,7,0]  R2199     -4.6143096685409546e-01
    z[6,7,0]  R2200     -0.210273876786232
    z[6,7,0]  R2201     -1.8114566802978516e-01
    z[6,7,0]  R2202     3.3847063779830933e-01
    z[6,7,0]  R2203     2.8565225005149841e-01
    z[6,7,0]  R2204     4.1506037116050720e-01
    z[6,7,0]  R2205     3.2135307788848877e-01
    z[6,7,0]  R2206     1.8740488216280937e-02
    z[6,7,0]  R2207     4.8412081599235535e-01
    z[6,7,0]  R2208     -2.1803854405879974e-01
    z[6,7,0]  R2209     0.50909823179245
    z[6,7,0]  R2210     7.1029466390609741e-01
    z[6,7,0]  R2211     -5.5524501949548721e-02
    z[6,7,0]  R2212     -6.1685512773692608e-03
    z[6,7,0]  R2213     3.7835661321878433e-02
    z[6,7,0]  R2214     5.6850533932447433e-02
    z[6,7,0]  R2215     2.5100933387875557e-02
    z[6,7,0]  R2216     4.4018816202878952e-02
    z[6,7,0]  R2217     -1.1822836101055145e-01
    z[6,7,0]  R2218     -3.6960181593894958e-01
    z[6,7,0]  R2219     3.4233191609382629e-01
    z[6,7,0]  R2220     3.9878332614898682e-01
    z[6,7,0]  R2221     3.1251686811447144e-01
    z[6,7,0]  R2222     -1.7355673015117645e-01
    z[6,7,0]  R2223     2.4099587462842464e-03
    z[6,7,0]  R2224     2.7057060971856117e-02
    z[6,7,0]  R2225     -4.4093459844589233e-01
    z[6,7,0]  R2226     4.1839978098869324e-01
    z[6,7,0]  R2227     3.5848870873451233e-01
    z[6,7,0]  R2228     2.2785486280918121e-01
    z[6,7,0]  R2229     3.6973163485527039e-01
    z[6,7,0]  R2230     -4.7974463552236557e-02
    z[6,7,0]  R2231     6.8158395588397980e-02
    z[6,7,0]  R2232     2.1467141807079315e-01
    z[6,7,0]  R2233     8.5718967020511627e-02
    z[6,7,0]  R2234     -1.9045859575271606e-01
    z[6,7,0]  R2235     2.1406984329223633e-01
    z[6,7,0]  R2236     4.9754351377487183e-01
    z[6,7,0]  R2237     2.3441560566425323e-01
    z[6,7,0]  R2238     5.6777395308017731e-02
    z[6,7,0]  R2239     6.9153445959091187e-01
    z[6,7,0]  R2240     8.4705986082553864e-02
    z[6,7,0]  R2241     -3.3468225598335266e-01
    z[6,7,0]  R2242     -1.9302885234355927e-01
    z[6,7,0]  R2243     -4.2197167873382568e-01
    z[6,7,0]  R2244     -6.2555056810379028e-01
    z[6,7,0]  R2245     -1.4626176655292511e-01
    z[6,7,0]  R2246     4.0067169815301895e-02
    z[6,7,0]  R2247     -2.3708039522171021e-01
    z[6,7,0]  R2248     -6.1161381006240845e-01
    z[6,7,0]  R2249     5.3265875577926636e-01
    z[6,7,0]  R2250     6.7545038461685181e-01
    z[6,7,0]  R2251     4.4440844655036926e-01
    z[6,7,0]  R2252     4.5341044664382935e-01
    z[6,7,0]  R2253     -3.9376479387283325e-01
    z[6,7,0]  R2254     -3.7958592176437378e-01
    z[6,7,0]  R2255     -1.3526062667369843e-01
    z[6,7,0]  R2256     0.0799262747168541
    z[6,7,0]  R2257     -1.7884841561317444e-01
    z[6,7,0]  R2258     6.3129913806915283e-01
    z[6,7,0]  R2259     5.8014911413192749e-01
    z[6,7,0]  R2260     5.0079208612442017e-01
    z[6,7,0]  R2261     0.176330104470253
    z[6,7,0]  R2262     -3.1682834029197693e-01
    z[6,7,0]  R2263     -5.1431256532669067e-01
    z[6,7,0]  R2264     -2.9855456948280334e-01
    z[6,7,0]  R2265     4.2249751091003418e-01
    z[6,7,0]  R2266     5.5136221647262573e-01
    z[6,7,0]  R2267     5.8825761079788208e-01
    z[6,7,0]  R2268     4.1543582081794739e-01
    z[6,7,0]  R2269     3.1901162862777710e-01
    z[6,7,0]  R2270     -1.2675908207893372e-01
    z[6,7,0]  R2271     5.0275996327400208e-02
    z[6,7,0]  R2272     -2.2355319932103157e-02
    z[6,7,0]  R2273     -3.8570597767829895e-01
    z[6,7,1]  R57       -1
    z[6,7,1]  R66       1
    z[6,7,1]  R2184     -1
    z[6,7,1]  R2185     1
    z[6,7,1]  R2196     -1.0184162110090256e-01
    z[6,7,1]  R2197     -6.3242278993129730e-02
    z[6,7,1]  R2198     -1.6725437343120575e-01
    z[6,7,1]  R2199     -0.303504079580307
    z[6,7,1]  R2200     -1.7079021036624908e-01
    z[6,7,1]  R2201     -2.0953050255775452e-01
    z[6,7,1]  R2202     0.810470461845398
    z[6,7,1]  R2203     7.7487325668334961e-01
    z[6,7,1]  R2204     6.2169611454010010e-01
    z[6,7,1]  R2205     6.2602823972702026e-01
    z[6,7,1]  R2206     -4.7532996535301208e-01
    z[6,7,1]  R2207     -7.1956586837768555e-01
    z[6,7,1]  R2208     -6.3786417245864868e-01
    z[6,7,1]  R2209     -5.8766132593154907e-01
    z[6,7,1]  R2210     -3.0826598405838013e-01
    z[6,7,1]  R2211     9.4622872769832611e-02
    z[6,7,1]  R2212     -6.0548450797796249e-02
    z[6,7,1]  R2213     -1.1446894705295563e-01
    z[6,7,1]  R2214     -2.2744706273078918e-01
    z[6,7,1]  R2215     -1.1153586953878403e-01
    z[6,7,1]  R2216     5.3579532541334629e-03
    z[6,7,1]  R2217     2.6253911852836609e-01
    z[6,7,1]  R2218     2.2489833831787109e-01
    z[6,7,1]  R2219     4.6520507335662842e-01
    z[6,7,1]  R2220     7.1018069982528687e-02
    z[6,7,1]  R2221     8.5603815317153931e-01
    z[6,7,1]  R2222     2.8711551427841187e-01
    z[6,7,1]  R2223     -9.3920789659023285e-02
    z[6,7,1]  R2224     0.345195472240448
    z[6,7,1]  R2225     1.6721232235431671e-01
    z[6,7,1]  R2226     3.3686190843582153e-01
    z[6,7,1]  R2227     1.3379177451133728e-01
    z[6,7,1]  R2228     1.3943144679069519e-01
    z[6,7,1]  R2229     8.0643719434738159e-01
    z[6,7,1]  R2230     -8.9668609201908112e-02
    z[6,7,1]  R2231     7.9418027400970459e-01
    z[6,7,1]  R2232     0.832773745059967
    z[6,7,1]  R2233     8.4061279892921448e-02
    z[6,7,1]  R2234     3.0079850554466248e-01
    z[6,7,1]  R2235     2.7481248974800110e-01
    z[6,7,1]  R2236     2.9237136244773865e-01
    z[6,7,1]  R2237     7.5944197177886963e-01
    z[6,7,1]  R2238     -4.8153233528137207e-01
    z[6,7,1]  R2239     5.3768402338027954e-01
    z[6,7,1]  R2240     -1.4101034402847290e-01
    z[6,7,1]  R2241     1.4121639728546143e-01
    z[6,7,1]  R2242     3.0635641887784004e-02
    z[6,7,1]  R2243     3.5354387760162354e-01
    z[6,7,1]  R2244     8.2029908895492554e-02
    z[6,7,1]  R2245     -3.7217464298009872e-02
    z[6,7,1]  R2246     -2.2337000072002411e-01
    z[6,7,1]  R2247     -1.9959750771522522e-01
    z[6,7,1]  R2248     -1.6205689311027527e-01
    z[6,7,1]  R2249     5.1615241914987564e-02
    z[6,7,1]  R2250     -8.8565431535243988e-02
    z[6,7,1]  R2251     6.8200731277465820e-01
    z[6,7,1]  R2252     4.6463176608085632e-01
    z[6,7,1]  R2253     0.702788770198822
    z[6,7,1]  R2254     1.8833984434604645e-01
    z[6,7,1]  R2255     -8.2548034191131592e-01
    z[6,7,1]  R2256     -2.7658230066299438e-01
    z[6,7,1]  R2257     -6.6683292388916016e-02
    z[6,7,1]  R2258     4.9134841561317444e-01
    z[6,7,1]  R2259     3.4632202982902527e-01
    z[6,7,1]  R2260     3.1011883169412613e-02
    z[6,7,1]  R2261     5.2983641624450684e-01
    z[6,7,1]  R2262     4.1821259260177612e-01
    z[6,7,1]  R2263     5.1034212112426758e-01
    z[6,7,1]  R2264     1.2049067020416260e-01
    z[6,7,1]  R2265     2.3231862485408783e-01
    z[6,7,1]  R2266     2.8565225005149841e-01
    z[6,7,1]  R2267     5.2151030302047729e-01
    z[6,7,1]  R2268     1.9055104255676270e-01
    z[6,7,1]  R2269     7.2859472036361694e-01
    z[6,7,1]  R2270     0.476112961769104
    z[6,7,1]  R2271     5.1500028371810913e-01
    z[6,7,1]  R2272     4.5134374499320984e-01
    z[6,7,1]  R2273     0.517600953578949
    z[6,7,2]  R58       -1
    z[6,7,2]  R67       1
    z[6,7,2]  R2186     -1
    z[6,7,2]  R2187     1
    z[6,7,2]  R2196     -5.0906091928482056e-01
    z[6,7,2]  R2197     -7.5055104494094849e-01
    z[6,7,2]  R2198     -1.8389877676963806e-01
    z[6,7,2]  R2199     -7.7626121044158936e-01
    z[6,7,2]  R2200     -4.3419343233108521e-01
    z[6,7,2]  R2201     2.3305429518222809e-01
    z[6,7,2]  R2202     1.4699342846870422e-01
    z[6,7,2]  R2203     3.3032163977622986e-01
    z[6,7,2]  R2204     0.312933087348938
    z[6,7,2]  R2205     9.1706722974777222e-02
    z[6,7,2]  R2206     -1.0843417793512344e-01
    z[6,7,2]  R2207     1.1218120902776718e-01
    z[6,7,2]  R2208     2.6355206966400146e-01
    z[6,7,2]  R2209     3.7070938944816589e-01
    z[6,7,2]  R2210     2.7988687157630920e-01
    z[6,7,2]  R2211     2.3535709083080292e-01
    z[6,7,2]  R2212     3.2425424456596375e-01
    z[6,7,2]  R2213     -1.5053071081638336e-01
    z[6,7,2]  R2214     -5.3392220288515091e-02
    z[6,7,2]  R2215     -3.6827970296144485e-02
    z[6,7,2]  R2216     8.6703681945800781e-01
    z[6,7,2]  R2217     7.7955722808837891e-01
    z[6,7,2]  R2218     6.8148344755172729e-01
    z[6,7,2]  R2219     6.7619484663009644e-01
    z[6,7,2]  R2220     7.7082967758178711e-01
    z[6,7,2]  R2221     2.3359667509794235e-02
    z[6,7,2]  R2222     7.9174205660820007e-02
    z[6,7,2]  R2223     -1.3105416297912598e-01
    z[6,7,2]  R2224     -6.5037272870540619e-02
    z[6,7,2]  R2225     -5.9566110372543335e-02
    z[6,7,2]  R2226     6.9493138790130615e-01
    z[6,7,2]  R2227     7.6160228252410889e-01
    z[6,7,2]  R2228     -1.2034597247838974e-01
    z[6,7,2]  R2229     1.5307830274105072e-01
    z[6,7,2]  R2230     2.7876922860741615e-02
    z[6,7,2]  R2231     1.5207213163375854e-01
    z[6,7,2]  R2232     4.2497169971466064e-01
    z[6,7,2]  R2233     2.0644725300371647e-03
    z[6,7,2]  R2234     3.1650561839342117e-02
    z[6,7,2]  R2235     2.7639198303222656e-01
    z[6,7,2]  R2236     6.5993010997772217e-01
    z[6,7,2]  R2237     4.0878447890281677e-01
    z[6,7,2]  R2238     7.0100909471511841e-01
    z[6,7,2]  R2239     -1.0121328383684158e-01
    z[6,7,2]  R2240     1.4600278437137604e-01
    z[6,7,2]  R2241     -4.0214333683252335e-02
    z[6,7,2]  R2242     -9.1538235545158386e-02
    z[6,7,2]  R2243     0.645959198474884
    z[6,7,2]  R2244     7.2471112012863159e-01
    z[6,7,2]  R2245     6.1217653751373291e-01
    z[6,7,2]  R2246     1.7554818093776703e-01
    z[6,7,2]  R2247     -2.6097807288169861e-01
    z[6,7,2]  R2248     -4.7502890229225159e-01
    z[6,7,2]  R2249     -2.2710184752941132e-01
    z[6,7,2]  R2250     -2.8238528966903687e-01
    z[6,7,2]  R2251     1.4959146082401276e-01
    z[6,7,2]  R2252     2.1901136636734009e-01
    z[6,7,2]  R2253     5.6506818532943726e-01
    z[6,7,2]  R2254     7.5908845663070679e-01
    z[6,7,2]  R2255     2.3316064476966858e-01
    z[6,7,2]  R2256     1.1616774648427963e-01
    z[6,7,2]  R2257     -1.7606303095817566e-01
    z[6,7,2]  R2258     4.2033895850181580e-01
    z[6,7,2]  R2259     3.2234114408493042e-01
    z[6,7,2]  R2260     4.9098369479179382e-01
    z[6,7,2]  R2261     6.4764000475406647e-02
    z[6,7,2]  R2262     -3.6040741205215454e-01
    z[6,7,2]  R2263     6.1960095167160034e-01
    z[6,7,2]  R2264     -1.6804602742195129e-01
    z[6,7,2]  R2265     4.1956314444541931e-01
    z[6,7,2]  R2266     4.4844293594360352e-01
    z[6,7,2]  R2267     3.8353288173675537e-01
    z[6,7,2]  R2268     0.421851247549057
    z[6,7,2]  R2269     8.3521112799644470e-02
    z[6,7,2]  R2270     -2.0321704447269440e-01
    z[6,7,2]  R2271     -1.2585286796092987e-01
    z[6,7,2]  R2272     -2.1186162531375885e-01
    z[6,7,2]  R2273     6.4983642101287842e-01
    z[6,7,3]  R59       -1
    z[6,7,3]  R68       1
    z[6,7,3]  R2188     -1
    z[6,7,3]  R2189     1
    z[6,7,3]  R2196     -3.0589836835861206e-01
    z[6,7,3]  R2197     -1.5433473885059357e-01
    z[6,7,3]  R2198     -5.9438586235046387e-01
    z[6,7,3]  R2199     -1.5773284435272217e-01
    z[6,7,3]  R2200     -4.6872556209564209e-01
    z[6,7,3]  R2201     -7.4423581361770630e-01
    z[6,7,3]  R2202     3.7225559353828430e-02
    z[6,7,3]  R2203     9.7412243485450745e-02
    z[6,7,3]  R2204     1.0573107749223709e-01
    z[6,7,3]  R2205     1.9528393447399139e-01
    z[6,7,3]  R2206     -0.192473366856575
    z[6,7,3]  R2207     -8.2285888493061066e-03
    z[6,7,3]  R2208     -1.1563333868980408e-01
    z[6,7,3]  R2209     0.0585331991314888
    z[6,7,3]  R2210     4.7160801291465759e-01
    z[6,7,3]  R2211     0.640306830406189
    z[6,7,3]  R2212     5.5618607997894287e-01
    z[6,7,3]  R2213     6.9402772188186646e-01
    z[6,7,3]  R2214     7.3062801361083984e-01
    z[6,7,3]  R2215     7.7099221944808960e-01
    z[6,7,3]  R2216     2.9088884592056274e-01
    z[6,7,3]  R2217     2.6989719271659851e-01
    z[6,7,3]  R2218     2.9004257917404175e-01
    z[6,7,3]  R2219     2.6627743244171143e-01
    z[6,7,3]  R2220     2.6294848322868347e-01
    z[6,7,3]  R2221     -2.3445339500904083e-01
    z[6,7,3]  R2222     6.6040658950805664e-01
    z[6,7,3]  R2223     5.9646093845367432e-01
    z[6,7,3]  R2224     0.782145619392395
    z[6,7,3]  R2225     4.0949431061744690e-01
    z[6,7,3]  R2226     3.1158992648124695e-01
    z[6,7,3]  R2227     2.7255716919898987e-01
    z[6,7,3]  R2228     6.5426176786422729e-01
    z[6,7,3]  R2229     1.2856918573379517e-01
    z[6,7,3]  R2230     5.1470750570297241e-01
    z[6,7,3]  R2231     1.1904380470514297e-01
    z[6,7,3]  R2232     -7.3084801435470581e-02
    z[6,7,3]  R2233     7.1243906021118164e-01
    z[6,7,3]  R2234     5.4430794715881348e-01
    z[6,7,3]  R2235     6.8508094549179077e-01
    z[6,7,3]  R2236     3.4227120876312256e-01
    z[6,7,3]  R2237     2.4159125983715057e-01
    z[6,7,3]  R2238     2.8500276803970337e-01
    z[6,7,3]  R2239     1.2094379216432571e-01
    z[6,7,3]  R2240     7.3022079467773438e-01
    z[6,7,3]  R2241     5.3078317642211914e-01
    z[6,7,3]  R2242     7.2227662801742554e-01
    z[6,7,3]  R2243     2.6772037148475647e-01
    z[6,7,3]  R2244     2.5740250945091248e-01
    z[6,7,3]  R2245     2.8304448723793030e-01
    z[6,7,3]  R2246     -7.9482358694076538e-01
    z[6,7,3]  R2247     -3.7739893794059753e-01
    z[6,7,3]  R2248     -8.0764904618263245e-02
    z[6,7,3]  R2249     1.9979354739189148e-01
    z[6,7,3]  R2250     3.8262015581130981e-01
    z[6,7,3]  R2251     2.7596119046211243e-01
    z[6,7,3]  R2252     1.8535287678241730e-01
    z[6,7,3]  R2253     -3.4371569752693176e-02
    z[6,7,3]  R2254     3.5858038067817688e-01
    z[6,7,3]  R2255     7.0522271096706390e-02
    z[6,7,3]  R2256     7.6576471328735352e-01
    z[6,7,3]  R2257     8.7756061553955078e-01
    z[6,7,3]  R2258     -1.1006095260381699e-01
    z[6,7,3]  R2259     3.4041205048561096e-01
    z[6,7,3]  R2260     5.4449033737182617e-01
    z[6,7,3]  R2261     4.1975349187850952e-01
    z[6,7,3]  R2262     -7.2573184967041016e-02
    z[6,7,3]  R2263     2.0260216668248177e-02
    z[6,7,3]  R2264     -1.3500805199146271e-01
    z[6,7,3]  R2265     2.1684104204177856e-01
    z[6,7,3]  R2266     4.3430694937705994e-01
    z[6,7,3]  R2267     2.4595226347446442e-01
    z[6,7,3]  R2268     2.8161951899528503e-01
    z[6,7,3]  R2269     0.00901623535901308
    z[6,7,3]  R2270     -4.5758393406867981e-01
    z[6,7,3]  R2271     4.2273014783859253e-01
    z[6,7,3]  R2272     6.0827469825744629e-01
    z[6,7,3]  R2273     1.8400286138057709e-01
    z[6,7,4]  R60       -1
    z[6,7,4]  R69       1
    z[6,7,4]  R2190     -1
    z[6,7,4]  R2191     1
    z[6,7,4]  R2196     -6.5553623437881470e-01
    z[6,7,4]  R2197     -5.6372737884521484e-01
    z[6,7,4]  R2198     -6.5037024021148682e-01
    z[6,7,4]  R2199     -1.4352397620677948e-01
    z[6,7,4]  R2200     -4.4759041070938110e-01
    z[6,7,4]  R2201     -3.2101035118103027e-01
    z[6,7,4]  R2202     4.6939209103584290e-02
    z[6,7,4]  R2203     -1.3300265371799469e-01
    z[6,7,4]  R2204     -2.0688125491142273e-01
    z[6,7,4]  R2205     -2.2732120007276535e-02
    z[6,7,4]  R2206     7.3849511146545410e-01
    z[6,7,4]  R2207     4.6790724992752075e-01
    z[6,7,4]  R2208     5.1474612951278687e-01
    z[6,7,4]  R2209     0.117306649684906
    z[6,7,4]  R2210     1.4192031323909760e-01
    z[6,7,4]  R2211     0.639231264591217
    z[6,7,4]  R2212     6.4150214195251465e-01
    z[6,7,4]  R2213     5.1964229345321655e-01
    z[6,7,4]  R2214     5.8704030513763428e-01
    z[6,7,4]  R2215     6.1071318387985229e-01
    z[6,7,4]  R2216     -2.6565727591514587e-01
    z[6,7,4]  R2217     -3.3379873633384705e-01
    z[6,7,4]  R2218     -3.5412481427192688e-01
    z[6,7,4]  R2219     -3.3927980065345764e-01
    z[6,7,4]  R2220     -2.6110973954200745e-01
    z[6,7,4]  R2221     1.8755020201206207e-01
    z[6,7,4]  R2222     5.9185034036636353e-01
    z[6,7,4]  R2223     4.7020500898361206e-01
    z[6,7,4]  R2224     4.8603174090385437e-01
    z[6,7,4]  R2225     5.5803602933883667e-01
    z[6,7,4]  R2226     -3.1170541048049927e-01
    z[6,7,4]  R2227     -0.335040807723999
    z[6,7,4]  R2228     3.4145078063011169e-01
    z[6,7,4]  R2229     -4.1805077344179153e-03
    z[6,7,4]  R2230     5.2007704973220825e-01
    z[6,7,4]  R2231     3.9965155720710754e-01
    z[6,7,4]  R2232     1.5197758562862873e-02
    z[6,7,4]  R2233     5.2641767263412476e-01
    z[6,7,4]  R2234     5.2312481403350830e-01
    z[6,7,4]  R2235     4.8766264319419861e-01
    z[6,7,4]  R2236     -2.9579576849937439e-01
    z[6,7,4]  R2237     1.8831400200724602e-02
    z[6,7,4]  R2238     -2.7756664156913757e-01
    z[6,7,4]  R2239     3.8045457005500793e-01
    z[6,7,4]  R2240     0.634904146194458
    z[6,7,4]  R2241     5.9926205873489380e-01
    z[6,7,4]  R2242     6.1631715297698975e-01
    z[6,7,4]  R2243     -1.9644858315587044e-02
    z[6,7,4]  R2244     -7.1411304175853729e-02
    z[6,7,4]  R2245     5.4956275224685669e-01
    z[6,7,4]  R2246     -1.0521605610847473e-01
    z[6,7,4]  R2247     -6.6669136285781860e-01
    z[6,7,4]  R2248     4.0884606540203094e-02
    z[6,7,4]  R2249     -5.4078716039657593e-01
    z[6,7,4]  R2250     -1.9201116263866425e-01
    z[6,7,4]  R2251     9.9918648600578308e-02
    z[6,7,4]  R2252     -1.4944776892662048e-02
    z[6,7,4]  R2253     -1.1669119819998741e-02
    z[6,7,4]  R2254     3.0302062630653381e-01
    z[6,7,4]  R2255     1.8192978203296661e-01
    z[6,7,4]  R2256     -1.5622977912425995e-01
    z[6,7,4]  R2257     1.0299666225910187e-01
    z[6,7,4]  R2258     1.7547617852687836e-01
    z[6,7,4]  R2259     -2.6857721805572510e-01
    z[6,7,4]  R2260     3.1995329260826111e-01
    z[6,7,4]  R2261     6.8665152788162231e-01
    z[6,7,4]  R2262     5.3739798069000244e-01
    z[6,7,4]  R2263     1.2559781968593597e-01
    z[6,7,4]  R2264     7.2910869121551514e-01
    z[6,7,4]  R2265     5.8731347322463989e-01
    z[6,7,4]  R2266     3.6370679736137390e-01
    z[6,7,4]  R2267     2.7539917826652527e-01
    z[6,7,4]  R2268     6.5521574020385742e-01
    z[6,7,4]  R2269     4.1041484475135803e-01
    z[6,7,4]  R2270     4.4433760643005371e-01
    z[6,7,4]  R2271     3.7291434407234192e-01
    z[6,7,4]  R2272     2.2865977883338928e-01
    z[6,7,4]  R2273     -2.5542598962783813e-01
    z[6,7,5]  R61       -1
    z[6,7,5]  R70       1
    z[6,7,5]  R2192     -1
    z[6,7,5]  R2193     1
    z[6,7,5]  R2196     3.1890936195850372e-02
    z[6,7,5]  R2197     -8.3937905728816986e-02
    z[6,7,5]  R2198     -4.3179783970117569e-02
    z[6,7,5]  R2199     2.1393939852714539e-01
    z[6,7,5]  R2200     5.5773550271987915e-01
    z[6,7,5]  R2201     1.3033340871334076e-01
    z[6,7,5]  R2202     3.8876384496688843e-01
    z[6,7,5]  R2203     3.9590248465538025e-01
    z[6,7,5]  R2204     5.3513944149017334e-01
    z[6,7,5]  R2205     5.9808903932571411e-01
    z[6,7,5]  R2206     -3.8606292009353638e-01
    z[6,7,5]  R2207     -4.6896100044250488e-02
    z[6,7,5]  R2208     -1.7600633203983307e-01
    z[6,7,5]  R2209     -4.3365910649299622e-01
    z[6,7,5]  R2210     1.6803377866744995e-01
    z[6,7,5]  R2211     -2.7435111999511719e-01
    z[6,7,5]  R2212     -0.41243776679039
    z[6,7,5]  R2213     -4.0450578927993774e-01
    z[6,7,5]  R2214     -1.5519276261329651e-01
    z[6,7,5]  R2215     -1.2001276016235352e-01
    z[6,7,5]  R2216     -2.7328658103942871e-01
    z[6,7,5]  R2217     3.4517291188240051e-01
    z[6,7,5]  R2218     -3.5216996073722839e-01
    z[6,7,5]  R2219     1.9515956519171596e-03
    z[6,7,5]  R2220     3.0713069438934326e-01
    z[6,7,5]  R2221     2.0844615995883942e-01
    z[6,7,5]  R2222     -1.6517917811870575e-01
    z[6,7,5]  R2223     -4.0421482920646667e-01
    z[6,7,5]  R2224     -1.6351450979709625e-01
    z[6,7,5]  R2225     -5.2698552608489990e-01
    z[6,7,5]  R2226     -6.1436548829078674e-02
    z[6,7,5]  R2227     2.5246468186378479e-01
    z[6,7,5]  R2228     -5.9880632162094116e-01
    z[6,7,5]  R2229     2.3992657661437988e-01
    z[6,7,5]  R2230     -0.559112548828125
    z[6,7,5]  R2231     3.2083955407142639e-01
    z[6,7,5]  R2232     1.3470095396041870e-01
    z[6,7,5]  R2233     -4.4716912508010864e-01
    z[6,7,5]  R2234     -5.4794645309448242e-01
    z[6,7,5]  R2235     -2.9601526260375977e-01
    z[6,7,5]  R2236     -7.1639634668827057e-02
    z[6,7,5]  R2237     3.7576580047607422e-01
    z[6,7,5]  R2238     2.0769409835338593e-01
    z[6,7,5]  R2239     2.4020275473594666e-01
    z[6,7,5]  R2240     -1.1854986846446991e-01
    z[6,7,5]  R2241     -4.6189829707145691e-01
    z[6,7,5]  R2242     8.8646404445171356e-02
    z[6,7,5]  R2243     3.9814686775207520e-01
    z[6,7,5]  R2244     0.0660867840051651
    z[6,7,5]  R2245     4.6411749720573425e-01
    z[6,7,5]  R2246     4.8914080858230591e-01
    z[6,7,5]  R2247     8.4587134420871735e-02
    z[6,7,5]  R2248     3.8188643753528595e-02
    z[6,7,5]  R2249     1.0736273974180222e-01
    z[6,7,5]  R2250     4.8926255106925964e-01
    z[6,7,5]  R2251     0.434596449136734
    z[6,7,5]  R2252     5.5236268043518066e-01
    z[6,7,5]  R2253     -0.0758703202009201
    z[6,7,5]  R2254     -1.2080959230661392e-01
    z[6,7,5]  R2255     -4.3662688136100769e-01
    z[6,7,5]  R2256     5.2186584472656250e-01
    z[6,7,5]  R2257     2.9076170921325684e-01
    z[6,7,5]  R2258     -1.2655048072338104e-01
    z[6,7,5]  R2259     0.440373033285141
    z[6,7,5]  R2260     1.0545748472213745e-01
    z[6,7,5]  R2261     1.6299945116043091e-01
    z[6,7,5]  R2262     -1.3524267077445984e-01
    z[6,7,5]  R2263     9.4388015568256378e-02
    z[6,7,5]  R2264     2.4583670496940613e-01
    z[6,7,5]  R2265     3.0880689620971680e-01
    z[6,7,5]  R2266     3.0298420786857605e-01
    z[6,7,5]  R2267     2.0331549644470215e-01
    z[6,7,5]  R2268     5.8228474110364914e-02
    z[6,7,5]  R2269     2.6883718371391296e-01
    z[6,7,5]  R2270     -4.9682331085205078e-01
    z[6,7,5]  R2271     -6.2081003189086914e-01
    z[6,7,5]  R2272     -5.7314914464950562e-01
    z[6,7,5]  R2273     -2.4634602665901184e-01
    z[6,7,6]  R62       -1
    z[6,7,6]  R71       1
    z[6,7,6]  R2194     -1
    z[6,7,6]  R2195     1
    z[6,7,6]  R2196     -2.7949538826942444e-01
    z[6,7,6]  R2197     1.9483187794685364e-01
    z[6,7,6]  R2198     3.0501335859298706e-01
    z[6,7,6]  R2199     -3.3709757030010223e-02
    z[6,7,6]  R2200     -8.3558365702629089e-02
    z[6,7,6]  R2201     -4.4164186716079712e-01
    z[6,7,6]  R2202     2.2856485843658447e-01
    z[6,7,6]  R2203     1.5793742239475250e-01
    z[6,7,6]  R2204     -5.4209318011999130e-02
    z[6,7,6]  R2205     -3.1630310416221619e-01
    z[6,7,6]  R2206     1.7460419237613678e-01
    z[6,7,6]  R2207     1.1858832091093063e-01
    z[6,7,6]  R2208     4.0843120217323303e-01
    z[6,7,6]  R2209     -2.2978352010250092e-01
    z[6,7,6]  R2210     2.2655259072780609e-01
    z[6,7,6]  R2211     1.9670473039150238e-01
    z[6,7,6]  R2212     1.3496269471943378e-02
    z[6,7,6]  R2213     2.1789531409740448e-01
    z[6,7,6]  R2214     1.9916498661041260e-01
    z[6,7,6]  R2215     -6.1406232416629791e-02
    z[6,7,6]  R2216     -1.2808224558830261e-01
    z[6,7,6]  R2217     7.7300563454627991e-02
    z[6,7,6]  R2218     -1.2183124572038651e-01
    z[6,7,6]  R2219     1.5210315585136414e-01
    z[6,7,6]  R2220     -1.0050041973590851e-01
    z[6,7,6]  R2221     -1.8813011050224304e-01
    z[6,7,6]  R2222     -2.5974291563034058e-01
    z[6,7,6]  R2223     -4.8347678780555725e-01
    z[6,7,6]  R2224     -3.4096620976924896e-02
    z[6,7,6]  R2225     1.3139671087265015e-01
    z[6,7,6]  R2226     1.7467968165874481e-01
    z[6,7,6]  R2227     1.5254262089729309e-01
    z[6,7,6]  R2228     1.0460289567708969e-01
    z[6,7,6]  R2229     -3.3972385525703430e-01
    z[6,7,6]  R2230     3.7532657384872437e-01
    z[6,7,6]  R2231     -2.5431340932846069e-01
    z[6,7,6]  R2232     -2.3682577908039093e-01
    z[6,7,6]  R2233     3.0602652579545975e-02
    z[6,7,6]  R2234     4.5474354177713394e-02
    z[6,7,6]  R2235     8.6508587002754211e-02
    z[6,7,6]  R2236     1.4725729823112488e-01
    z[6,7,6]  R2237     3.5658221691846848e-02
    z[6,7,6]  R2238     2.6848191022872925e-01
    z[6,7,6]  R2239     7.3222480714321136e-02
    z[6,7,6]  R2240     -3.5274066030979156e-02
    z[6,7,6]  R2241     1.1060192435979843e-01
    z[6,7,6]  R2242     2.0984171330928802e-01
    z[6,7,6]  R2243     -2.2159019112586975e-01
    z[6,7,6]  R2244     -3.2067753374576569e-02
    z[6,7,6]  R2245     -7.0169776678085327e-02
    z[6,7,6]  R2246     -1.8870523571968079e-01
    z[6,7,6]  R2247     4.9171319603919983e-01
    z[6,7,6]  R2248     -0.60362309217453
    z[6,7,6]  R2249     -5.6403923034667969e-01
    z[6,7,6]  R2250     1.8313153088092804e-01
    z[6,7,6]  R2251     -0.199942946434021
    z[6,7,6]  R2252     4.3690595030784607e-01
    z[6,7,6]  R2253     1.5703898668289185e-01
    z[6,7,6]  R2254     -9.6078030765056610e-02
    z[6,7,6]  R2255     1.3117891550064087e-01
    z[6,7,6]  R2256     -0.143079936504364
    z[6,7,6]  R2257     2.5943225622177124e-01
    z[6,7,6]  R2258     3.5275071859359741e-01
    z[6,7,6]  R2259     2.4008680880069733e-01
    z[6,7,6]  R2260     -3.1180027127265930e-01
    z[6,7,6]  R2261     9.8663859069347382e-02
    z[6,7,6]  R2262     0.53147953748703
    z[6,7,6]  R2263     2.5697031617164612e-01
    z[6,7,6]  R2264     5.0778478384017944e-01
    z[6,7,6]  R2265     -3.2275646924972534e-01
    z[6,7,6]  R2266     2.4430163204669952e-02
    z[6,7,6]  R2267     -2.3918202519416809e-01
    z[6,7,6]  R2268     3.1802043318748474e-01
    z[6,7,6]  R2269     3.4584742784500122e-01
    z[6,7,6]  R2270     2.4959772825241089e-01
    z[6,7,6]  R2271     -1.1505239456892014e-01
    z[6,7,6]  R2272     1.0968401096761227e-02
    z[6,7,6]  R2273     -3.5311821848154068e-02
    z[7,6,0]  R56       1
    z[7,6,0]  R65       -1
    z[7,6,0]  R2274     -1
    z[7,6,0]  R2275     1
    z[7,6,0]  R2288     4.0067169815301895e-02
    z[7,6,0]  R2289     -2.3708039522171021e-01
    z[7,6,0]  R2290     -6.1161381006240845e-01
    z[7,6,0]  R2291     5.3265875577926636e-01
    z[7,6,0]  R2292     6.7545038461685181e-01
    z[7,6,0]  R2293     4.4440844655036926e-01
    z[7,6,0]  R2294     4.5341044664382935e-01
    z[7,6,0]  R2295     -3.9376479387283325e-01
    z[7,6,0]  R2296     -3.7958592176437378e-01
    z[7,6,0]  R2297     -1.3526062667369843e-01
    z[7,6,0]  R2298     0.0799262747168541
    z[7,6,0]  R2299     -1.7884841561317444e-01
    z[7,6,0]  R2300     6.3129913806915283e-01
    z[7,6,0]  R2301     5.8014911413192749e-01
    z[7,6,0]  R2302     5.0079208612442017e-01
    z[7,6,0]  R2303     0.176330104470253
    z[7,6,0]  R2304     -3.1682834029197693e-01
    z[7,6,0]  R2305     -5.1431256532669067e-01
    z[7,6,0]  R2306     -2.9855456948280334e-01
    z[7,6,0]  R2307     4.2249751091003418e-01
    z[7,6,0]  R2308     5.5136221647262573e-01
    z[7,6,0]  R2309     5.8825761079788208e-01
    z[7,6,0]  R2310     4.1543582081794739e-01
    z[7,6,0]  R2311     3.1901162862777710e-01
    z[7,6,0]  R2312     -1.2675908207893372e-01
    z[7,6,0]  R2313     5.0275996327400208e-02
    z[7,6,0]  R2314     -2.2355319932103157e-02
    z[7,6,0]  R2315     -3.8570597767829895e-01
    z[7,6,0]  R2316     3.5783922672271729e-01
    z[7,6,0]  R2317     0.214617520570755
    z[7,6,0]  R2318     2.5890854001045227e-01
    z[7,6,0]  R2319     -4.6143096685409546e-01
    z[7,6,0]  R2320     -0.210273876786232
    z[7,6,0]  R2321     -1.8114566802978516e-01
    z[7,6,0]  R2322     3.3847063779830933e-01
    z[7,6,0]  R2323     2.8565225005149841e-01
    z[7,6,0]  R2324     4.1506037116050720e-01
    z[7,6,0]  R2325     3.2135307788848877e-01
    z[7,6,0]  R2326     1.8740488216280937e-02
    z[7,6,0]  R2327     4.8412081599235535e-01
    z[7,6,0]  R2328     -2.1803854405879974e-01
    z[7,6,0]  R2329     0.50909823179245
    z[7,6,0]  R2330     7.1029466390609741e-01
    z[7,6,0]  R2331     -5.5524501949548721e-02
    z[7,6,0]  R2332     -6.1685512773692608e-03
    z[7,6,0]  R2333     3.7835661321878433e-02
    z[7,6,0]  R2334     5.6850533932447433e-02
    z[7,6,0]  R2335     2.5100933387875557e-02
    z[7,6,0]  R2336     4.4018816202878952e-02
    z[7,6,0]  R2337     -1.1822836101055145e-01
    z[7,6,0]  R2338     -3.6960181593894958e-01
    z[7,6,0]  R2339     3.4233191609382629e-01
    z[7,6,0]  R2340     3.9878332614898682e-01
    z[7,6,0]  R2341     3.1251686811447144e-01
    z[7,6,0]  R2342     -1.7355673015117645e-01
    z[7,6,0]  R2343     2.4099587462842464e-03
    z[7,6,0]  R2344     2.7057060971856117e-02
    z[7,6,0]  R2345     -4.4093459844589233e-01
    z[7,6,0]  R2346     4.1839978098869324e-01
    z[7,6,0]  R2347     3.5848870873451233e-01
    z[7,6,0]  R2348     2.2785486280918121e-01
    z[7,6,0]  R2349     3.6973163485527039e-01
    z[7,6,0]  R2350     -4.7974463552236557e-02
    z[7,6,0]  R2351     6.8158395588397980e-02
    z[7,6,0]  R2352     2.1467141807079315e-01
    z[7,6,0]  R2353     8.5718967020511627e-02
    z[7,6,0]  R2354     -1.9045859575271606e-01
    z[7,6,0]  R2355     2.1406984329223633e-01
    z[7,6,0]  R2356     4.9754351377487183e-01
    z[7,6,0]  R2357     2.3441560566425323e-01
    z[7,6,0]  R2358     5.6777395308017731e-02
    z[7,6,0]  R2359     6.9153445959091187e-01
    z[7,6,0]  R2360     8.4705986082553864e-02
    z[7,6,0]  R2361     -3.3468225598335266e-01
    z[7,6,0]  R2362     -1.9302885234355927e-01
    z[7,6,0]  R2363     -4.2197167873382568e-01
    z[7,6,0]  R2364     -6.2555056810379028e-01
    z[7,6,0]  R2365     -1.4626176655292511e-01
    z[7,6,1]  R57       1
    z[7,6,1]  R66       -1
    z[7,6,1]  R2276     -1
    z[7,6,1]  R2277     1
    z[7,6,1]  R2288     -2.2337000072002411e-01
    z[7,6,1]  R2289     -1.9959750771522522e-01
    z[7,6,1]  R2290     -1.6205689311027527e-01
    z[7,6,1]  R2291     5.1615241914987564e-02
    z[7,6,1]  R2292     -8.8565431535243988e-02
    z[7,6,1]  R2293     6.8200731277465820e-01
    z[7,6,1]  R2294     4.6463176608085632e-01
    z[7,6,1]  R2295     0.702788770198822
    z[7,6,1]  R2296     1.8833984434604645e-01
    z[7,6,1]  R2297     -8.2548034191131592e-01
    z[7,6,1]  R2298     -2.7658230066299438e-01
    z[7,6,1]  R2299     -6.6683292388916016e-02
    z[7,6,1]  R2300     4.9134841561317444e-01
    z[7,6,1]  R2301     3.4632202982902527e-01
    z[7,6,1]  R2302     3.1011883169412613e-02
    z[7,6,1]  R2303     5.2983641624450684e-01
    z[7,6,1]  R2304     4.1821259260177612e-01
    z[7,6,1]  R2305     5.1034212112426758e-01
    z[7,6,1]  R2306     1.2049067020416260e-01
    z[7,6,1]  R2307     2.3231862485408783e-01
    z[7,6,1]  R2308     2.8565225005149841e-01
    z[7,6,1]  R2309     5.2151030302047729e-01
    z[7,6,1]  R2310     1.9055104255676270e-01
    z[7,6,1]  R2311     7.2859472036361694e-01
    z[7,6,1]  R2312     0.476112961769104
    z[7,6,1]  R2313     5.1500028371810913e-01
    z[7,6,1]  R2314     4.5134374499320984e-01
    z[7,6,1]  R2315     0.517600953578949
    z[7,6,1]  R2316     -1.0184162110090256e-01
    z[7,6,1]  R2317     -6.3242278993129730e-02
    z[7,6,1]  R2318     -1.6725437343120575e-01
    z[7,6,1]  R2319     -0.303504079580307
    z[7,6,1]  R2320     -1.7079021036624908e-01
    z[7,6,1]  R2321     -2.0953050255775452e-01
    z[7,6,1]  R2322     0.810470461845398
    z[7,6,1]  R2323     7.7487325668334961e-01
    z[7,6,1]  R2324     6.2169611454010010e-01
    z[7,6,1]  R2325     6.2602823972702026e-01
    z[7,6,1]  R2326     -4.7532996535301208e-01
    z[7,6,1]  R2327     -7.1956586837768555e-01
    z[7,6,1]  R2328     -6.3786417245864868e-01
    z[7,6,1]  R2329     -5.8766132593154907e-01
    z[7,6,1]  R2330     -3.0826598405838013e-01
    z[7,6,1]  R2331     9.4622872769832611e-02
    z[7,6,1]  R2332     -6.0548450797796249e-02
    z[7,6,1]  R2333     -1.1446894705295563e-01
    z[7,6,1]  R2334     -2.2744706273078918e-01
    z[7,6,1]  R2335     -1.1153586953878403e-01
    z[7,6,1]  R2336     5.3579532541334629e-03
    z[7,6,1]  R2337     2.6253911852836609e-01
    z[7,6,1]  R2338     2.2489833831787109e-01
    z[7,6,1]  R2339     4.6520507335662842e-01
    z[7,6,1]  R2340     7.1018069982528687e-02
    z[7,6,1]  R2341     8.5603815317153931e-01
    z[7,6,1]  R2342     2.8711551427841187e-01
    z[7,6,1]  R2343     -9.3920789659023285e-02
    z[7,6,1]  R2344     0.345195472240448
    z[7,6,1]  R2345     1.6721232235431671e-01
    z[7,6,1]  R2346     3.3686190843582153e-01
    z[7,6,1]  R2347     1.3379177451133728e-01
    z[7,6,1]  R2348     1.3943144679069519e-01
    z[7,6,1]  R2349     8.0643719434738159e-01
    z[7,6,1]  R2350     -8.9668609201908112e-02
    z[7,6,1]  R2351     7.9418027400970459e-01
    z[7,6,1]  R2352     0.832773745059967
    z[7,6,1]  R2353     8.4061279892921448e-02
    z[7,6,1]  R2354     3.0079850554466248e-01
    z[7,6,1]  R2355     2.7481248974800110e-01
    z[7,6,1]  R2356     2.9237136244773865e-01
    z[7,6,1]  R2357     7.5944197177886963e-01
    z[7,6,1]  R2358     -4.8153233528137207e-01
    z[7,6,1]  R2359     5.3768402338027954e-01
    z[7,6,1]  R2360     -1.4101034402847290e-01
    z[7,6,1]  R2361     1.4121639728546143e-01
    z[7,6,1]  R2362     3.0635641887784004e-02
    z[7,6,1]  R2363     3.5354387760162354e-01
    z[7,6,1]  R2364     8.2029908895492554e-02
    z[7,6,1]  R2365     -3.7217464298009872e-02
    z[7,6,2]  R58       1
    z[7,6,2]  R67       -1
    z[7,6,2]  R2278     -1
    z[7,6,2]  R2279     1
    z[7,6,2]  R2288     1.7554818093776703e-01
    z[7,6,2]  R2289     -2.6097807288169861e-01
    z[7,6,2]  R2290     -4.7502890229225159e-01
    z[7,6,2]  R2291     -2.2710184752941132e-01
    z[7,6,2]  R2292     -2.8238528966903687e-01
    z[7,6,2]  R2293     1.4959146082401276e-01
    z[7,6,2]  R2294     2.1901136636734009e-01
    z[7,6,2]  R2295     5.6506818532943726e-01
    z[7,6,2]  R2296     7.5908845663070679e-01
    z[7,6,2]  R2297     2.3316064476966858e-01
    z[7,6,2]  R2298     1.1616774648427963e-01
    z[7,6,2]  R2299     -1.7606303095817566e-01
    z[7,6,2]  R2300     4.2033895850181580e-01
    z[7,6,2]  R2301     3.2234114408493042e-01
    z[7,6,2]  R2302     4.9098369479179382e-01
    z[7,6,2]  R2303     6.4764000475406647e-02
    z[7,6,2]  R2304     -3.6040741205215454e-01
    z[7,6,2]  R2305     6.1960095167160034e-01
    z[7,6,2]  R2306     -1.6804602742195129e-01
    z[7,6,2]  R2307     4.1956314444541931e-01
    z[7,6,2]  R2308     4.4844293594360352e-01
    z[7,6,2]  R2309     3.8353288173675537e-01
    z[7,6,2]  R2310     0.421851247549057
    z[7,6,2]  R2311     8.3521112799644470e-02
    z[7,6,2]  R2312     -2.0321704447269440e-01
    z[7,6,2]  R2313     -1.2585286796092987e-01
    z[7,6,2]  R2314     -2.1186162531375885e-01
    z[7,6,2]  R2315     6.4983642101287842e-01
    z[7,6,2]  R2316     -5.0906091928482056e-01
    z[7,6,2]  R2317     -7.5055104494094849e-01
    z[7,6,2]  R2318     -1.8389877676963806e-01
    z[7,6,2]  R2319     -7.7626121044158936e-01
    z[7,6,2]  R2320     -4.3419343233108521e-01
    z[7,6,2]  R2321     2.3305429518222809e-01
    z[7,6,2]  R2322     1.4699342846870422e-01
    z[7,6,2]  R2323     3.3032163977622986e-01
    z[7,6,2]  R2324     0.312933087348938
    z[7,6,2]  R2325     9.1706722974777222e-02
    z[7,6,2]  R2326     -1.0843417793512344e-01
    z[7,6,2]  R2327     1.1218120902776718e-01
    z[7,6,2]  R2328     2.6355206966400146e-01
    z[7,6,2]  R2329     3.7070938944816589e-01
    z[7,6,2]  R2330     2.7988687157630920e-01
    z[7,6,2]  R2331     2.3535709083080292e-01
    z[7,6,2]  R2332     3.2425424456596375e-01
    z[7,6,2]  R2333     -1.5053071081638336e-01
    z[7,6,2]  R2334     -5.3392220288515091e-02
    z[7,6,2]  R2335     -3.6827970296144485e-02
    z[7,6,2]  R2336     8.6703681945800781e-01
    z[7,6,2]  R2337     7.7955722808837891e-01
    z[7,6,2]  R2338     6.8148344755172729e-01
    z[7,6,2]  R2339     6.7619484663009644e-01
    z[7,6,2]  R2340     7.7082967758178711e-01
    z[7,6,2]  R2341     2.3359667509794235e-02
    z[7,6,2]  R2342     7.9174205660820007e-02
    z[7,6,2]  R2343     -1.3105416297912598e-01
    z[7,6,2]  R2344     -6.5037272870540619e-02
    z[7,6,2]  R2345     -5.9566110372543335e-02
    z[7,6,2]  R2346     6.9493138790130615e-01
    z[7,6,2]  R2347     7.6160228252410889e-01
    z[7,6,2]  R2348     -1.2034597247838974e-01
    z[7,6,2]  R2349     1.5307830274105072e-01
    z[7,6,2]  R2350     2.7876922860741615e-02
    z[7,6,2]  R2351     1.5207213163375854e-01
    z[7,6,2]  R2352     4.2497169971466064e-01
    z[7,6,2]  R2353     2.0644725300371647e-03
    z[7,6,2]  R2354     3.1650561839342117e-02
    z[7,6,2]  R2355     2.7639198303222656e-01
    z[7,6,2]  R2356     6.5993010997772217e-01
    z[7,6,2]  R2357     4.0878447890281677e-01
    z[7,6,2]  R2358     7.0100909471511841e-01
    z[7,6,2]  R2359     -1.0121328383684158e-01
    z[7,6,2]  R2360     1.4600278437137604e-01
    z[7,6,2]  R2361     -4.0214333683252335e-02
    z[7,6,2]  R2362     -9.1538235545158386e-02
    z[7,6,2]  R2363     0.645959198474884
    z[7,6,2]  R2364     7.2471112012863159e-01
    z[7,6,2]  R2365     6.1217653751373291e-01
    z[7,6,3]  R59       1
    z[7,6,3]  R68       -1
    z[7,6,3]  R2280     -1
    z[7,6,3]  R2281     1
    z[7,6,3]  R2288     -7.9482358694076538e-01
    z[7,6,3]  R2289     -3.7739893794059753e-01
    z[7,6,3]  R2290     -8.0764904618263245e-02
    z[7,6,3]  R2291     1.9979354739189148e-01
    z[7,6,3]  R2292     3.8262015581130981e-01
    z[7,6,3]  R2293     2.7596119046211243e-01
    z[7,6,3]  R2294     1.8535287678241730e-01
    z[7,6,3]  R2295     -3.4371569752693176e-02
    z[7,6,3]  R2296     3.5858038067817688e-01
    z[7,6,3]  R2297     7.0522271096706390e-02
    z[7,6,3]  R2298     7.6576471328735352e-01
    z[7,6,3]  R2299     8.7756061553955078e-01
    z[7,6,3]  R2300     -1.1006095260381699e-01
    z[7,6,3]  R2301     3.4041205048561096e-01
    z[7,6,3]  R2302     5.4449033737182617e-01
    z[7,6,3]  R2303     4.1975349187850952e-01
    z[7,6,3]  R2304     -7.2573184967041016e-02
    z[7,6,3]  R2305     2.0260216668248177e-02
    z[7,6,3]  R2306     -1.3500805199146271e-01
    z[7,6,3]  R2307     2.1684104204177856e-01
    z[7,6,3]  R2308     4.3430694937705994e-01
    z[7,6,3]  R2309     2.4595226347446442e-01
    z[7,6,3]  R2310     2.8161951899528503e-01
    z[7,6,3]  R2311     0.00901623535901308
    z[7,6,3]  R2312     -4.5758393406867981e-01
    z[7,6,3]  R2313     4.2273014783859253e-01
    z[7,6,3]  R2314     6.0827469825744629e-01
    z[7,6,3]  R2315     1.8400286138057709e-01
    z[7,6,3]  R2316     -3.0589836835861206e-01
    z[7,6,3]  R2317     -1.5433473885059357e-01
    z[7,6,3]  R2318     -5.9438586235046387e-01
    z[7,6,3]  R2319     -1.5773284435272217e-01
    z[7,6,3]  R2320     -4.6872556209564209e-01
    z[7,6,3]  R2321     -7.4423581361770630e-01
    z[7,6,3]  R2322     3.7225559353828430e-02
    z[7,6,3]  R2323     9.7412243485450745e-02
    z[7,6,3]  R2324     1.0573107749223709e-01
    z[7,6,3]  R2325     1.9528393447399139e-01
    z[7,6,3]  R2326     -0.192473366856575
    z[7,6,3]  R2327     -8.2285888493061066e-03
    z[7,6,3]  R2328     -1.1563333868980408e-01
    z[7,6,3]  R2329     0.0585331991314888
    z[7,6,3]  R2330     4.7160801291465759e-01
    z[7,6,3]  R2331     0.640306830406189
    z[7,6,3]  R2332     5.5618607997894287e-01
    z[7,6,3]  R2333     6.9402772188186646e-01
    z[7,6,3]  R2334     7.3062801361083984e-01
    z[7,6,3]  R2335     7.7099221944808960e-01
    z[7,6,3]  R2336     2.9088884592056274e-01
    z[7,6,3]  R2337     2.6989719271659851e-01
    z[7,6,3]  R2338     2.9004257917404175e-01
    z[7,6,3]  R2339     2.6627743244171143e-01
    z[7,6,3]  R2340     2.6294848322868347e-01
    z[7,6,3]  R2341     -2.3445339500904083e-01
    z[7,6,3]  R2342     6.6040658950805664e-01
    z[7,6,3]  R2343     5.9646093845367432e-01
    z[7,6,3]  R2344     0.782145619392395
    z[7,6,3]  R2345     4.0949431061744690e-01
    z[7,6,3]  R2346     3.1158992648124695e-01
    z[7,6,3]  R2347     2.7255716919898987e-01
    z[7,6,3]  R2348     6.5426176786422729e-01
    z[7,6,3]  R2349     1.2856918573379517e-01
    z[7,6,3]  R2350     5.1470750570297241e-01
    z[7,6,3]  R2351     1.1904380470514297e-01
    z[7,6,3]  R2352     -7.3084801435470581e-02
    z[7,6,3]  R2353     7.1243906021118164e-01
    z[7,6,3]  R2354     5.4430794715881348e-01
    z[7,6,3]  R2355     6.8508094549179077e-01
    z[7,6,3]  R2356     3.4227120876312256e-01
    z[7,6,3]  R2357     2.4159125983715057e-01
    z[7,6,3]  R2358     2.8500276803970337e-01
    z[7,6,3]  R2359     1.2094379216432571e-01
    z[7,6,3]  R2360     7.3022079467773438e-01
    z[7,6,3]  R2361     5.3078317642211914e-01
    z[7,6,3]  R2362     7.2227662801742554e-01
    z[7,6,3]  R2363     2.6772037148475647e-01
    z[7,6,3]  R2364     2.5740250945091248e-01
    z[7,6,3]  R2365     2.8304448723793030e-01
    z[7,6,4]  R60       1
    z[7,6,4]  R69       -1
    z[7,6,4]  R2282     -1
    z[7,6,4]  R2283     1
    z[7,6,4]  R2288     -1.0521605610847473e-01
    z[7,6,4]  R2289     -6.6669136285781860e-01
    z[7,6,4]  R2290     4.0884606540203094e-02
    z[7,6,4]  R2291     -5.4078716039657593e-01
    z[7,6,4]  R2292     -1.9201116263866425e-01
    z[7,6,4]  R2293     9.9918648600578308e-02
    z[7,6,4]  R2294     -1.4944776892662048e-02
    z[7,6,4]  R2295     -1.1669119819998741e-02
    z[7,6,4]  R2296     3.0302062630653381e-01
    z[7,6,4]  R2297     1.8192978203296661e-01
    z[7,6,4]  R2298     -1.5622977912425995e-01
    z[7,6,4]  R2299     1.0299666225910187e-01
    z[7,6,4]  R2300     1.7547617852687836e-01
    z[7,6,4]  R2301     -2.6857721805572510e-01
    z[7,6,4]  R2302     3.1995329260826111e-01
    z[7,6,4]  R2303     6.8665152788162231e-01
    z[7,6,4]  R2304     5.3739798069000244e-01
    z[7,6,4]  R2305     1.2559781968593597e-01
    z[7,6,4]  R2306     7.2910869121551514e-01
    z[7,6,4]  R2307     5.8731347322463989e-01
    z[7,6,4]  R2308     3.6370679736137390e-01
    z[7,6,4]  R2309     2.7539917826652527e-01
    z[7,6,4]  R2310     6.5521574020385742e-01
    z[7,6,4]  R2311     4.1041484475135803e-01
    z[7,6,4]  R2312     4.4433760643005371e-01
    z[7,6,4]  R2313     3.7291434407234192e-01
    z[7,6,4]  R2314     2.2865977883338928e-01
    z[7,6,4]  R2315     -2.5542598962783813e-01
    z[7,6,4]  R2316     -6.5553623437881470e-01
    z[7,6,4]  R2317     -5.6372737884521484e-01
    z[7,6,4]  R2318     -6.5037024021148682e-01
    z[7,6,4]  R2319     -1.4352397620677948e-01
    z[7,6,4]  R2320     -4.4759041070938110e-01
    z[7,6,4]  R2321     -3.2101035118103027e-01
    z[7,6,4]  R2322     4.6939209103584290e-02
    z[7,6,4]  R2323     -1.3300265371799469e-01
    z[7,6,4]  R2324     -2.0688125491142273e-01
    z[7,6,4]  R2325     -2.2732120007276535e-02
    z[7,6,4]  R2326     7.3849511146545410e-01
    z[7,6,4]  R2327     4.6790724992752075e-01
    z[7,6,4]  R2328     5.1474612951278687e-01
    z[7,6,4]  R2329     0.117306649684906
    z[7,6,4]  R2330     1.4192031323909760e-01
    z[7,6,4]  R2331     0.639231264591217
    z[7,6,4]  R2332     6.4150214195251465e-01
    z[7,6,4]  R2333     5.1964229345321655e-01
    z[7,6,4]  R2334     5.8704030513763428e-01
    z[7,6,4]  R2335     6.1071318387985229e-01
    z[7,6,4]  R2336     -2.6565727591514587e-01
    z[7,6,4]  R2337     -3.3379873633384705e-01
    z[7,6,4]  R2338     -3.5412481427192688e-01
    z[7,6,4]  R2339     -3.3927980065345764e-01
    z[7,6,4]  R2340     -2.6110973954200745e-01
    z[7,6,4]  R2341     1.8755020201206207e-01
    z[7,6,4]  R2342     5.9185034036636353e-01
    z[7,6,4]  R2343     4.7020500898361206e-01
    z[7,6,4]  R2344     4.8603174090385437e-01
    z[7,6,4]  R2345     5.5803602933883667e-01
    z[7,6,4]  R2346     -3.1170541048049927e-01
    z[7,6,4]  R2347     -0.335040807723999
    z[7,6,4]  R2348     3.4145078063011169e-01
    z[7,6,4]  R2349     -4.1805077344179153e-03
    z[7,6,4]  R2350     5.2007704973220825e-01
    z[7,6,4]  R2351     3.9965155720710754e-01
    z[7,6,4]  R2352     1.5197758562862873e-02
    z[7,6,4]  R2353     5.2641767263412476e-01
    z[7,6,4]  R2354     5.2312481403350830e-01
    z[7,6,4]  R2355     4.8766264319419861e-01
    z[7,6,4]  R2356     -2.9579576849937439e-01
    z[7,6,4]  R2357     1.8831400200724602e-02
    z[7,6,4]  R2358     -2.7756664156913757e-01
    z[7,6,4]  R2359     3.8045457005500793e-01
    z[7,6,4]  R2360     0.634904146194458
    z[7,6,4]  R2361     5.9926205873489380e-01
    z[7,6,4]  R2362     6.1631715297698975e-01
    z[7,6,4]  R2363     -1.9644858315587044e-02
    z[7,6,4]  R2364     -7.1411304175853729e-02
    z[7,6,4]  R2365     5.4956275224685669e-01
    z[7,6,5]  R61       1
    z[7,6,5]  R70       -1
    z[7,6,5]  R2284     -1
    z[7,6,5]  R2285     1
    z[7,6,5]  R2288     4.8914080858230591e-01
    z[7,6,5]  R2289     8.4587134420871735e-02
    z[7,6,5]  R2290     3.8188643753528595e-02
    z[7,6,5]  R2291     1.0736273974180222e-01
    z[7,6,5]  R2292     4.8926255106925964e-01
    z[7,6,5]  R2293     0.434596449136734
    z[7,6,5]  R2294     5.5236268043518066e-01
    z[7,6,5]  R2295     -0.0758703202009201
    z[7,6,5]  R2296     -1.2080959230661392e-01
    z[7,6,5]  R2297     -4.3662688136100769e-01
    z[7,6,5]  R2298     5.2186584472656250e-01
    z[7,6,5]  R2299     2.9076170921325684e-01
    z[7,6,5]  R2300     -1.2655048072338104e-01
    z[7,6,5]  R2301     0.440373033285141
    z[7,6,5]  R2302     1.0545748472213745e-01
    z[7,6,5]  R2303     1.6299945116043091e-01
    z[7,6,5]  R2304     -1.3524267077445984e-01
    z[7,6,5]  R2305     9.4388015568256378e-02
    z[7,6,5]  R2306     2.4583670496940613e-01
    z[7,6,5]  R2307     3.0880689620971680e-01
    z[7,6,5]  R2308     3.0298420786857605e-01
    z[7,6,5]  R2309     2.0331549644470215e-01
    z[7,6,5]  R2310     5.8228474110364914e-02
    z[7,6,5]  R2311     2.6883718371391296e-01
    z[7,6,5]  R2312     -4.9682331085205078e-01
    z[7,6,5]  R2313     -6.2081003189086914e-01
    z[7,6,5]  R2314     -5.7314914464950562e-01
    z[7,6,5]  R2315     -2.4634602665901184e-01
    z[7,6,5]  R2316     3.1890936195850372e-02
    z[7,6,5]  R2317     -8.3937905728816986e-02
    z[7,6,5]  R2318     -4.3179783970117569e-02
    z[7,6,5]  R2319     2.1393939852714539e-01
    z[7,6,5]  R2320     5.5773550271987915e-01
    z[7,6,5]  R2321     1.3033340871334076e-01
    z[7,6,5]  R2322     3.8876384496688843e-01
    z[7,6,5]  R2323     3.9590248465538025e-01
    z[7,6,5]  R2324     5.3513944149017334e-01
    z[7,6,5]  R2325     5.9808903932571411e-01
    z[7,6,5]  R2326     -3.8606292009353638e-01
    z[7,6,5]  R2327     -4.6896100044250488e-02
    z[7,6,5]  R2328     -1.7600633203983307e-01
    z[7,6,5]  R2329     -4.3365910649299622e-01
    z[7,6,5]  R2330     1.6803377866744995e-01
    z[7,6,5]  R2331     -2.7435111999511719e-01
    z[7,6,5]  R2332     -0.41243776679039
    z[7,6,5]  R2333     -4.0450578927993774e-01
    z[7,6,5]  R2334     -1.5519276261329651e-01
    z[7,6,5]  R2335     -1.2001276016235352e-01
    z[7,6,5]  R2336     -2.7328658103942871e-01
    z[7,6,5]  R2337     3.4517291188240051e-01
    z[7,6,5]  R2338     -3.5216996073722839e-01
    z[7,6,5]  R2339     1.9515956519171596e-03
    z[7,6,5]  R2340     3.0713069438934326e-01
    z[7,6,5]  R2341     2.0844615995883942e-01
    z[7,6,5]  R2342     -1.6517917811870575e-01
    z[7,6,5]  R2343     -4.0421482920646667e-01
    z[7,6,5]  R2344     -1.6351450979709625e-01
    z[7,6,5]  R2345     -5.2698552608489990e-01
    z[7,6,5]  R2346     -6.1436548829078674e-02
    z[7,6,5]  R2347     2.5246468186378479e-01
    z[7,6,5]  R2348     -5.9880632162094116e-01
    z[7,6,5]  R2349     2.3992657661437988e-01
    z[7,6,5]  R2350     -0.559112548828125
    z[7,6,5]  R2351     3.2083955407142639e-01
    z[7,6,5]  R2352     1.3470095396041870e-01
    z[7,6,5]  R2353     -4.4716912508010864e-01
    z[7,6,5]  R2354     -5.4794645309448242e-01
    z[7,6,5]  R2355     -2.9601526260375977e-01
    z[7,6,5]  R2356     -7.1639634668827057e-02
    z[7,6,5]  R2357     3.7576580047607422e-01
    z[7,6,5]  R2358     2.0769409835338593e-01
    z[7,6,5]  R2359     2.4020275473594666e-01
    z[7,6,5]  R2360     -1.1854986846446991e-01
    z[7,6,5]  R2361     -4.6189829707145691e-01
    z[7,6,5]  R2362     8.8646404445171356e-02
    z[7,6,5]  R2363     3.9814686775207520e-01
    z[7,6,5]  R2364     0.0660867840051651
    z[7,6,5]  R2365     4.6411749720573425e-01
    z[7,6,6]  R62       1
    z[7,6,6]  R71       -1
    z[7,6,6]  R2286     -1
    z[7,6,6]  R2287     1
    z[7,6,6]  R2288     -1.8870523571968079e-01
    z[7,6,6]  R2289     4.9171319603919983e-01
    z[7,6,6]  R2290     -0.60362309217453
    z[7,6,6]  R2291     -5.6403923034667969e-01
    z[7,6,6]  R2292     1.8313153088092804e-01
    z[7,6,6]  R2293     -0.199942946434021
    z[7,6,6]  R2294     4.3690595030784607e-01
    z[7,6,6]  R2295     1.5703898668289185e-01
    z[7,6,6]  R2296     -9.6078030765056610e-02
    z[7,6,6]  R2297     1.3117891550064087e-01
    z[7,6,6]  R2298     -0.143079936504364
    z[7,6,6]  R2299     2.5943225622177124e-01
    z[7,6,6]  R2300     3.5275071859359741e-01
    z[7,6,6]  R2301     2.4008680880069733e-01
    z[7,6,6]  R2302     -3.1180027127265930e-01
    z[7,6,6]  R2303     9.8663859069347382e-02
    z[7,6,6]  R2304     0.53147953748703
    z[7,6,6]  R2305     2.5697031617164612e-01
    z[7,6,6]  R2306     5.0778478384017944e-01
    z[7,6,6]  R2307     -3.2275646924972534e-01
    z[7,6,6]  R2308     2.4430163204669952e-02
    z[7,6,6]  R2309     -2.3918202519416809e-01
    z[7,6,6]  R2310     3.1802043318748474e-01
    z[7,6,6]  R2311     3.4584742784500122e-01
    z[7,6,6]  R2312     2.4959772825241089e-01
    z[7,6,6]  R2313     -1.1505239456892014e-01
    z[7,6,6]  R2314     1.0968401096761227e-02
    z[7,6,6]  R2315     -3.5311821848154068e-02
    z[7,6,6]  R2316     -2.7949538826942444e-01
    z[7,6,6]  R2317     1.9483187794685364e-01
    z[7,6,6]  R2318     3.0501335859298706e-01
    z[7,6,6]  R2319     -3.3709757030010223e-02
    z[7,6,6]  R2320     -8.3558365702629089e-02
    z[7,6,6]  R2321     -4.4164186716079712e-01
    z[7,6,6]  R2322     2.2856485843658447e-01
    z[7,6,6]  R2323     1.5793742239475250e-01
    z[7,6,6]  R2324     -5.4209318011999130e-02
    z[7,6,6]  R2325     -3.1630310416221619e-01
    z[7,6,6]  R2326     1.7460419237613678e-01
    z[7,6,6]  R2327     1.1858832091093063e-01
    z[7,6,6]  R2328     4.0843120217323303e-01
    z[7,6,6]  R2329     -2.2978352010250092e-01
    z[7,6,6]  R2330     2.2655259072780609e-01
    z[7,6,6]  R2331     1.9670473039150238e-01
    z[7,6,6]  R2332     1.3496269471943378e-02
    z[7,6,6]  R2333     2.1789531409740448e-01
    z[7,6,6]  R2334     1.9916498661041260e-01
    z[7,6,6]  R2335     -6.1406232416629791e-02
    z[7,6,6]  R2336     -1.2808224558830261e-01
    z[7,6,6]  R2337     7.7300563454627991e-02
    z[7,6,6]  R2338     -1.2183124572038651e-01
    z[7,6,6]  R2339     1.5210315585136414e-01
    z[7,6,6]  R2340     -1.0050041973590851e-01
    z[7,6,6]  R2341     -1.8813011050224304e-01
    z[7,6,6]  R2342     -2.5974291563034058e-01
    z[7,6,6]  R2343     -4.8347678780555725e-01
    z[7,6,6]  R2344     -3.4096620976924896e-02
    z[7,6,6]  R2345     1.3139671087265015e-01
    z[7,6,6]  R2346     1.7467968165874481e-01
    z[7,6,6]  R2347     1.5254262089729309e-01
    z[7,6,6]  R2348     1.0460289567708969e-01
    z[7,6,6]  R2349     -3.3972385525703430e-01
    z[7,6,6]  R2350     3.7532657384872437e-01
    z[7,6,6]  R2351     -2.5431340932846069e-01
    z[7,6,6]  R2352     -2.3682577908039093e-01
    z[7,6,6]  R2353     3.0602652579545975e-02
    z[7,6,6]  R2354     4.5474354177713394e-02
    z[7,6,6]  R2355     8.6508587002754211e-02
    z[7,6,6]  R2356     1.4725729823112488e-01
    z[7,6,6]  R2357     3.5658221691846848e-02
    z[7,6,6]  R2358     2.6848191022872925e-01
    z[7,6,6]  R2359     7.3222480714321136e-02
    z[7,6,6]  R2360     -3.5274066030979156e-02
    z[7,6,6]  R2361     1.1060192435979843e-01
    z[7,6,6]  R2362     2.0984171330928802e-01
    z[7,6,6]  R2363     -2.2159019112586975e-01
    z[7,6,6]  R2364     -3.2067753374576569e-02
    z[7,6,6]  R2365     -7.0169776678085327e-02
    z[7,8,0]  R65       -1
    z[7,8,0]  R74       1
    z[7,8,0]  R2366     -1
    z[7,8,0]  R2367     1
    z[7,8,0]  R2380     4.0067169815301895e-02
    z[7,8,0]  R2381     -2.3708039522171021e-01
    z[7,8,0]  R2382     -6.1161381006240845e-01
    z[7,8,0]  R2383     5.3265875577926636e-01
    z[7,8,0]  R2384     6.7545038461685181e-01
    z[7,8,0]  R2385     4.4440844655036926e-01
    z[7,8,0]  R2386     4.5341044664382935e-01
    z[7,8,0]  R2387     -3.9376479387283325e-01
    z[7,8,0]  R2388     -3.7958592176437378e-01
    z[7,8,0]  R2389     -1.3526062667369843e-01
    z[7,8,0]  R2390     0.0799262747168541
    z[7,8,0]  R2391     -1.7884841561317444e-01
    z[7,8,0]  R2392     6.3129913806915283e-01
    z[7,8,0]  R2393     5.8014911413192749e-01
    z[7,8,0]  R2394     5.0079208612442017e-01
    z[7,8,0]  R2395     0.176330104470253
    z[7,8,0]  R2396     -3.1682834029197693e-01
    z[7,8,0]  R2397     -5.1431256532669067e-01
    z[7,8,0]  R2398     -2.9855456948280334e-01
    z[7,8,0]  R2399     4.2249751091003418e-01
    z[7,8,0]  R2400     5.5136221647262573e-01
    z[7,8,0]  R2401     5.8825761079788208e-01
    z[7,8,0]  R2402     4.1543582081794739e-01
    z[7,8,0]  R2403     3.1901162862777710e-01
    z[7,8,0]  R2404     -1.2675908207893372e-01
    z[7,8,0]  R2405     5.0275996327400208e-02
    z[7,8,0]  R2406     -2.2355319932103157e-02
    z[7,8,0]  R2407     -3.8570597767829895e-01
    z[7,8,0]  R2408     -2.0111629366874695e-01
    z[7,8,0]  R2409     -2.4270208179950714e-01
    z[7,8,0]  R2410     -1.5699948370456696e-01
    z[7,8,0]  R2411     6.6477544605731964e-02
    z[7,8,0]  R2412     -3.5107459407299757e-03
    z[7,8,0]  R2413     2.0591892302036285e-01
    z[7,8,0]  R2414     2.3244784772396088e-01
    z[7,8,0]  R2415     1.2624438107013702e-01
    z[7,8,0]  R2416     2.1336102485656738e-01
    z[7,8,0]  R2417     -9.0435284376144409e-01
    z[7,8,0]  R2418     -7.6551824808120728e-02
    z[7,8,0]  R2419     2.0580536127090454e-01
    z[7,8,0]  R2420     2.4859334528446198e-01
    z[7,8,0]  R2421     3.4582239389419556e-01
    z[7,8,0]  R2422     1.4862895011901855e-01
    z[7,8,0]  R2423     1.0935758799314499e-01
    z[7,8,0]  R2424     -1.6155529022216797e-01
    z[7,8,0]  R2425     1.7433200776576996e-01
    z[7,8,0]  R2426     8.7078690528869629e-02
    z[7,8,0]  R2427     -1.2701866030693054e-01
    z[7,8,0]  R2428     3.0171531438827515e-01
    z[7,8,0]  R2429     7.2028465569019318e-02
    z[7,8,0]  R2430     2.7042636275291443e-01
    z[7,8,0]  R2431     1.6744980216026306e-01
    z[7,8,0]  R2432     -2.9490685090422630e-02
    z[7,8,0]  R2433     9.2251554131507874e-02
    z[7,8,0]  R2434     -1.2892271578311920e-01
    z[7,8,0]  R2435     -2.0086021721363068e-01
    z[7,8,0]  R2436     7.2531960904598236e-02
    z[7,8,0]  R2437     -0.511598527431488
    z[7,8,0]  R2438     -1.0005234181880951e-01
    z[7,8,0]  R2439     1.1733307689428329e-01
    z[7,8,0]  R2440     -4.1857632994651794e-01
    z[7,8,0]  R2441     -6.1898726224899292e-01
    z[7,8,0]  R2442     -1.4537665247917175e-01
    z[7,8,0]  R2443     2.0276996493339539e-01
    z[7,8,0]  R2444     -1.5041647851467133e-01
    z[7,8,0]  R2445     0.306181937456131
    z[7,8,0]  R2446     3.9462804794311523e-01
    z[7,8,0]  R2447     -9.6003890037536621e-02
    z[7,8,1]  R66       -1
    z[7,8,1]  R75       1
    z[7,8,1]  R2368     -1
    z[7,8,1]  R2369     1
    z[7,8,1]  R2380     -2.2337000072002411e-01
    z[7,8,1]  R2381     -1.9959750771522522e-01
    z[7,8,1]  R2382     -1.6205689311027527e-01
    z[7,8,1]  R2383     5.1615241914987564e-02
    z[7,8,1]  R2384     -8.8565431535243988e-02
    z[7,8,1]  R2385     6.8200731277465820e-01
    z[7,8,1]  R2386     4.6463176608085632e-01
    z[7,8,1]  R2387     0.702788770198822
    z[7,8,1]  R2388     1.8833984434604645e-01
    z[7,8,1]  R2389     -8.2548034191131592e-01
    z[7,8,1]  R2390     -2.7658230066299438e-01
    z[7,8,1]  R2391     -6.6683292388916016e-02
    z[7,8,1]  R2392     4.9134841561317444e-01
    z[7,8,1]  R2393     3.4632202982902527e-01
    z[7,8,1]  R2394     3.1011883169412613e-02
    z[7,8,1]  R2395     5.2983641624450684e-01
    z[7,8,1]  R2396     4.1821259260177612e-01
    z[7,8,1]  R2397     5.1034212112426758e-01
    z[7,8,1]  R2398     1.2049067020416260e-01
    z[7,8,1]  R2399     2.3231862485408783e-01
    z[7,8,1]  R2400     2.8565225005149841e-01
    z[7,8,1]  R2401     5.2151030302047729e-01
    z[7,8,1]  R2402     1.9055104255676270e-01
    z[7,8,1]  R2403     7.2859472036361694e-01
    z[7,8,1]  R2404     0.476112961769104
    z[7,8,1]  R2405     5.1500028371810913e-01
    z[7,8,1]  R2406     4.5134374499320984e-01
    z[7,8,1]  R2407     0.517600953578949
    z[7,8,1]  R2408     -1.3025115430355072e-01
    z[7,8,1]  R2409     -1.3317577540874481e-02
    z[7,8,1]  R2410     8.0886083841323853e-01
    z[7,8,1]  R2411     -1.3516566157341003e-01
    z[7,8,1]  R2412     6.5173107385635376e-01
    z[7,8,1]  R2413     3.7668704986572266e-02
    z[7,8,1]  R2414     6.7653638124465942e-01
    z[7,8,1]  R2415     -5.1842797547578812e-02
    z[7,8,1]  R2416     3.4885206818580627e-01
    z[7,8,1]  R2417     -1.1103361099958420e-01
    z[7,8,1]  R2418     -8.3584529161453247e-01
    z[7,8,1]  R2419     -6.5859478712081909e-01
    z[7,8,1]  R2420     -7.1510475873947144e-01
    z[7,8,1]  R2421     1.4314013719558716e-01
    z[7,8,1]  R2422     -8.4134501218795776e-01
    z[7,8,1]  R2423     -6.6101610660552979e-01
    z[7,8,1]  R2424     -8.3556854724884033e-01
    z[7,8,1]  R2425     0.401563823223114
    z[7,8,1]  R2426     1.2806928157806396e-01
    z[7,8,1]  R2427     -6.0899519920349121e-01
    z[7,8,1]  R2428     -3.6122608184814453e-01
    z[7,8,1]  R2429     -2.3939548432826996e-01
    z[7,8,1]  R2430     -3.7896192073822021e-01
    z[7,8,1]  R2431     -4.1848089545965195e-02
    z[7,8,1]  R2432     -3.4122887253761292e-01
    z[7,8,1]  R2433     -8.3733355998992920e-01
    z[7,8,1]  R2434     5.0221151113510132e-01
    z[7,8,1]  R2435     -7.7609074115753174e-01
    z[7,8,1]  R2436     6.2885576486587524e-01
    z[7,8,1]  R2437     0.226348876953125
    z[7,8,1]  R2438     -8.7646156549453735e-01
    z[7,8,1]  R2439     3.5217535495758057e-01
    z[7,8,1]  R2440     -3.4532102942466736e-01
    z[7,8,1]  R2441     -4.8880180716514587e-01
    z[7,8,1]  R2442     -0.170157328248024
    z[7,8,1]  R2443     6.2894034385681152e-01
    z[7,8,1]  R2444     -4.3408384919166565e-01
    z[7,8,1]  R2445     4.6868675947189331e-01
    z[7,8,1]  R2446     5.8811980485916138e-01
    z[7,8,1]  R2447     -1.9644196331501007e-01
    z[7,8,2]  R67       -1
    z[7,8,2]  R76       1
    z[7,8,2]  R2370     -1
    z[7,8,2]  R2371     1
    z[7,8,2]  R2380     1.7554818093776703e-01
    z[7,8,2]  R2381     -2.6097807288169861e-01
    z[7,8,2]  R2382     -4.7502890229225159e-01
    z[7,8,2]  R2383     -2.2710184752941132e-01
    z[7,8,2]  R2384     -2.8238528966903687e-01
    z[7,8,2]  R2385     1.4959146082401276e-01
    z[7,8,2]  R2386     2.1901136636734009e-01
    z[7,8,2]  R2387     5.6506818532943726e-01
    z[7,8,2]  R2388     7.5908845663070679e-01
    z[7,8,2]  R2389     2.3316064476966858e-01
    z[7,8,2]  R2390     1.1616774648427963e-01
    z[7,8,2]  R2391     -1.7606303095817566e-01
    z[7,8,2]  R2392     4.2033895850181580e-01
    z[7,8,2]  R2393     3.2234114408493042e-01
    z[7,8,2]  R2394     4.9098369479179382e-01
    z[7,8,2]  R2395     6.4764000475406647e-02
    z[7,8,2]  R2396     -3.6040741205215454e-01
    z[7,8,2]  R2397     6.1960095167160034e-01
    z[7,8,2]  R2398     -1.6804602742195129e-01
    z[7,8,2]  R2399     4.1956314444541931e-01
    z[7,8,2]  R2400     4.4844293594360352e-01
    z[7,8,2]  R2401     3.8353288173675537e-01
    z[7,8,2]  R2402     0.421851247549057
    z[7,8,2]  R2403     8.3521112799644470e-02
    z[7,8,2]  R2404     -2.0321704447269440e-01
    z[7,8,2]  R2405     -1.2585286796092987e-01
    z[7,8,2]  R2406     -2.1186162531375885e-01
    z[7,8,2]  R2407     6.4983642101287842e-01
    z[7,8,2]  R2408     -2.7533471584320068e-01
    z[7,8,2]  R2409     -2.6543724536895752e-01
    z[7,8,2]  R2410     5.1782506704330444e-01
    z[7,8,2]  R2411     -3.1296011805534363e-01
    z[7,8,2]  R2412     -9.8057903349399567e-02
    z[7,8,2]  R2413     -6.3203227519989014e-01
    z[7,8,2]  R2414     -3.2391190528869629e-01
    z[7,8,2]  R2415     -3.6273059248924255e-01
    z[7,8,2]  R2416     5.2638594061136246e-02
    z[7,8,2]  R2417     1.6446973383426666e-01
    z[7,8,2]  R2418     -4.7788426280021667e-01
    z[7,8,2]  R2419     -4.3715590238571167e-01
    z[7,8,2]  R2420     -4.0727302432060242e-01
    z[7,8,2]  R2421     -5.4799216985702515e-01
    z[7,8,2]  R2422     -3.0662044882774353e-01
    z[7,8,2]  R2423     -3.7563818693161011e-01
    z[7,8,2]  R2424     6.4522060565650463e-03
    z[7,8,2]  R2425     1.0601682215929031e-01
    z[7,8,2]  R2426     2.8027918934822083e-01
    z[7,8,2]  R2427     7.2129350900650024e-01
    z[7,8,2]  R2428     -7.6573336124420166e-01
    z[7,8,2]  R2429     -8.0364304780960083e-01
    z[7,8,2]  R2430     -7.5284171104431152e-01
    z[7,8,2]  R2431     -7.0482075214385986e-01
    z[7,8,2]  R2432     -3.6790904402732849e-01
    z[7,8,2]  R2433     -3.1498628854751587e-01
    z[7,8,2]  R2434     3.7793284654617310e-01
    z[7,8,2]  R2435     8.5784226655960083e-02
    z[7,8,2]  R2436     7.4811629019677639e-03
    z[7,8,2]  R2437     -5.0689816474914551e-01
    z[7,8,2]  R2438     -2.7843010425567627e-01
    z[7,8,2]  R2439     -6.5639001131057739e-01
    z[7,8,2]  R2440     -1.6937333345413208e-01
    z[7,8,2]  R2441     -3.5882163047790527e-01
    z[7,8,2]  R2442     -1.8943351507186890e-01
    z[7,8,2]  R2443     -0.0875493511557579
    z[7,8,2]  R2444     1.4354649186134338e-01
    z[7,8,2]  R2445     1.4232377707958221e-01
    z[7,8,2]  R2446     -3.8037461042404175e-01
    z[7,8,2]  R2447     0.682428777217865
    z[7,8,3]  R68       -1
    z[7,8,3]  R77       1
    z[7,8,3]  R2372     -1
    z[7,8,3]  R2373     1
    z[7,8,3]  R2380     -7.9482358694076538e-01
    z[7,8,3]  R2381     -3.7739893794059753e-01
    z[7,8,3]  R2382     -8.0764904618263245e-02
    z[7,8,3]  R2383     1.9979354739189148e-01
    z[7,8,3]  R2384     3.8262015581130981e-01
    z[7,8,3]  R2385     2.7596119046211243e-01
    z[7,8,3]  R2386     1.8535287678241730e-01
    z[7,8,3]  R2387     -3.4371569752693176e-02
    z[7,8,3]  R2388     3.5858038067817688e-01
    z[7,8,3]  R2389     7.0522271096706390e-02
    z[7,8,3]  R2390     7.6576471328735352e-01
    z[7,8,3]  R2391     8.7756061553955078e-01
    z[7,8,3]  R2392     -1.1006095260381699e-01
    z[7,8,3]  R2393     3.4041205048561096e-01
    z[7,8,3]  R2394     5.4449033737182617e-01
    z[7,8,3]  R2395     4.1975349187850952e-01
    z[7,8,3]  R2396     -7.2573184967041016e-02
    z[7,8,3]  R2397     2.0260216668248177e-02
    z[7,8,3]  R2398     -1.3500805199146271e-01
    z[7,8,3]  R2399     2.1684104204177856e-01
    z[7,8,3]  R2400     4.3430694937705994e-01
    z[7,8,3]  R2401     2.4595226347446442e-01
    z[7,8,3]  R2402     2.8161951899528503e-01
    z[7,8,3]  R2403     0.00901623535901308
    z[7,8,3]  R2404     -4.5758393406867981e-01
    z[7,8,3]  R2405     4.2273014783859253e-01
    z[7,8,3]  R2406     6.0827469825744629e-01
    z[7,8,3]  R2407     1.8400286138057709e-01
    z[7,8,3]  R2408     -4.1108828783035278e-01
    z[7,8,3]  R2409     -3.3574259281158447e-01
    z[7,8,3]  R2410     0.098890021443367
    z[7,8,3]  R2411     3.4599813818931580e-01
    z[7,8,3]  R2412     1.0233910754323006e-02
    z[7,8,3]  R2413     -5.9911131858825684e-01
    z[7,8,3]  R2414     1.8235588073730469e-01
    z[7,8,3]  R2415     -4.5054781436920166e-01
    z[7,8,3]  R2416     6.2465268373489380e-01
    z[7,8,3]  R2417     -1.8111613392829895e-01
    z[7,8,3]  R2418     9.4365149736404419e-02
    z[7,8,3]  R2419     4.7966772317886353e-01
    z[7,8,3]  R2420     2.5894096493721008e-01
    z[7,8,3]  R2421     6.8568712472915649e-01
    z[7,8,3]  R2422     1.5062336623668671e-01
    z[7,8,3]  R2423     1.1097923666238785e-01
    z[7,8,3]  R2424     -0.344770610332489
    z[7,8,3]  R2425     -2.7805429697036743e-01
    z[7,8,3]  R2426     4.6462345123291016e-01
    z[7,8,3]  R2427     0.0957830622792244
    z[7,8,3]  R2428     3.1819251179695129e-01
    z[7,8,3]  R2429     -2.6399964094161987e-01
    z[7,8,3]  R2430     -3.9392209053039551e-01
    z[7,8,3]  R2431     -6.4627963304519653e-01
    z[7,8,3]  R2432     8.1930831074714661e-02
    z[7,8,3]  R2433     -9.7869694232940674e-02
    z[7,8,3]  R2434     5.9446100145578384e-02
    z[7,8,3]  R2435     3.5228466987609863e-01
    z[7,8,3]  R2436     -4.2278897762298584e-01
    z[7,8,3]  R2437     1.8325652927160263e-02
    z[7,8,3]  R2438     -2.3752617835998535e-01
    z[7,8,3]  R2439     -4.9152252078056335e-01
    z[7,8,3]  R2440     5.2153009176254272e-01
    z[7,8,3]  R2441     -2.8063976764678955e-01
    z[7,8,3]  R2442     -4.1833803988993168e-03
    z[7,8,3]  R2443     5.4240250587463379e-01
    z[7,8,3]  R2444     4.0116497874259949e-01
    z[7,8,3]  R2445     3.5707205533981323e-01
    z[7,8,3]  R2446     9.5357939600944519e-02
    z[7,8,3]  R2447     1.0043677687644958e-01
    z[7,8,4]  R69       -1
    z[7,8,4]  R78       1
    z[7,8,4]  R2374     -1
    z[7,8,4]  R2375     1
    z[7,8,4]  R2380     -1.0521605610847473e-01
    z[7,8,4]  R2381     -6.6669136285781860e-01
    z[7,8,4]  R2382     4.0884606540203094e-02
    z[7,8,4]  R2383     -5.4078716039657593e-01
    z[7,8,4]  R2384     -1.9201116263866425e-01
    z[7,8,4]  R2385     9.9918648600578308e-02
    z[7,8,4]  R2386     -1.4944776892662048e-02
    z[7,8,4]  R2387     -1.1669119819998741e-02
    z[7,8,4]  R2388     3.0302062630653381e-01
    z[7,8,4]  R2389     1.8192978203296661e-01
    z[7,8,4]  R2390     -1.5622977912425995e-01
    z[7,8,4]  R2391     1.0299666225910187e-01
    z[7,8,4]  R2392     1.7547617852687836e-01
    z[7,8,4]  R2393     -2.6857721805572510e-01
    z[7,8,4]  R2394     3.1995329260826111e-01
    z[7,8,4]  R2395     6.8665152788162231e-01
    z[7,8,4]  R2396     5.3739798069000244e-01
    z[7,8,4]  R2397     1.2559781968593597e-01
    z[7,8,4]  R2398     7.2910869121551514e-01
    z[7,8,4]  R2399     5.8731347322463989e-01
    z[7,8,4]  R2400     3.6370679736137390e-01
    z[7,8,4]  R2401     2.7539917826652527e-01
    z[7,8,4]  R2402     6.5521574020385742e-01
    z[7,8,4]  R2403     4.1041484475135803e-01
    z[7,8,4]  R2404     4.4433760643005371e-01
    z[7,8,4]  R2405     3.7291434407234192e-01
    z[7,8,4]  R2406     2.2865977883338928e-01
    z[7,8,4]  R2407     -2.5542598962783813e-01
    z[7,8,4]  R2408     -7.9225790500640869e-01
    z[7,8,4]  R2409     -6.1505675315856934e-01
    z[7,8,4]  R2410     4.5633900910615921e-02
    z[7,8,4]  R2411     -4.8944196105003357e-01
    z[7,8,4]  R2412     -1.1414247564971447e-03
    z[7,8,4]  R2413     2.5589668750762939e-01
    z[7,8,4]  R2414     -4.3162095546722412e-01
    z[7,8,4]  R2415     -1.5001788735389709e-01
    z[7,8,4]  R2416     -1.7305327951908112e-01
    z[7,8,4]  R2417     1.5978132188320160e-01
    z[7,8,4]  R2418     2.1414557099342346e-01
    z[7,8,4]  R2419     6.1492212116718292e-02
    z[7,8,4]  R2420     7.0217796601355076e-03
    z[7,8,4]  R2421     -1.6406312584877014e-01
    z[7,8,4]  R2422     4.4874947518110275e-02
    z[7,8,4]  R2423     3.5974502563476562e-01
    z[7,8,4]  R2424     1.9913001358509064e-01
    z[7,8,4]  R2425     1.9794845581054688e-01
    z[7,8,4]  R2426     -3.6149136722087860e-02
    z[7,8,4]  R2427     -1.9500473141670227e-01
    z[7,8,4]  R2428     -0.267798513174057
    z[7,8,4]  R2429     1.9431692361831665e-01
    z[7,8,4]  R2430     1.6765825450420380e-01
    z[7,8,4]  R2431     1.2689247727394104e-01
    z[7,8,4]  R2432     2.9101692140102386e-02
    z[7,8,4]  R2433     -1.0317552089691162e-01
    z[7,8,4]  R2434     -3.3634561300277710e-01
    z[7,8,4]  R2435     -2.8721749782562256e-01
    z[7,8,4]  R2436     5.8807837963104248e-01
    z[7,8,4]  R2437     -2.2768768668174744e-01
    z[7,8,4]  R2438     -8.9141465723514557e-03
    z[7,8,4]  R2439     -1.5934322774410248e-01
    z[7,8,4]  R2440     -0.618080198764801
    z[7,8,4]  R2441     2.3450503125786781e-02
    z[7,8,4]  R2442     -5.8210569620132446e-01
    z[7,8,4]  R2443     -4.0888571739196777e-01
    z[7,8,4]  R2444     -6.7335605621337891e-01
    z[7,8,4]  R2445     4.0802329778671265e-01
    z[7,8,4]  R2446     2.3148220032453537e-02
    z[7,8,4]  R2447     4.7486644983291626e-01
    z[7,8,5]  R70       -1
    z[7,8,5]  R79       1
    z[7,8,5]  R2376     -1
    z[7,8,5]  R2377     1
    z[7,8,5]  R2380     4.8914080858230591e-01
    z[7,8,5]  R2381     8.4587134420871735e-02
    z[7,8,5]  R2382     3.8188643753528595e-02
    z[7,8,5]  R2383     1.0736273974180222e-01
    z[7,8,5]  R2384     4.8926255106925964e-01
    z[7,8,5]  R2385     0.434596449136734
    z[7,8,5]  R2386     5.5236268043518066e-01
    z[7,8,5]  R2387     -0.0758703202009201
    z[7,8,5]  R2388     -1.2080959230661392e-01
    z[7,8,5]  R2389     -4.3662688136100769e-01
    z[7,8,5]  R2390     5.2186584472656250e-01
    z[7,8,5]  R2391     2.9076170921325684e-01
    z[7,8,5]  R2392     -1.2655048072338104e-01
    z[7,8,5]  R2393     0.440373033285141
    z[7,8,5]  R2394     1.0545748472213745e-01
    z[7,8,5]  R2395     1.6299945116043091e-01
    z[7,8,5]  R2396     -1.3524267077445984e-01
    z[7,8,5]  R2397     9.4388015568256378e-02
    z[7,8,5]  R2398     2.4583670496940613e-01
    z[7,8,5]  R2399     3.0880689620971680e-01
    z[7,8,5]  R2400     3.0298420786857605e-01
    z[7,8,5]  R2401     2.0331549644470215e-01
    z[7,8,5]  R2402     5.8228474110364914e-02
    z[7,8,5]  R2403     2.6883718371391296e-01
    z[7,8,5]  R2404     -4.9682331085205078e-01
    z[7,8,5]  R2405     -6.2081003189086914e-01
    z[7,8,5]  R2406     -5.7314914464950562e-01
    z[7,8,5]  R2407     -2.4634602665901184e-01
    z[7,8,5]  R2408     1.8564743222668767e-03
    z[7,8,5]  R2409     6.1481392383575439e-01
    z[7,8,5]  R2410     2.0107144117355347e-01
    z[7,8,5]  R2411     1.7602321505546570e-01
    z[7,8,5]  R2412     3.4894740581512451e-01
    z[7,8,5]  R2413     -2.5422504171729088e-02
    z[7,8,5]  R2414     -1.0618577152490616e-01
    z[7,8,5]  R2415     -1.5849521756172180e-01
    z[7,8,5]  R2416     -1.7310941219329834e-01
    z[7,8,5]  R2417     -8.9023463428020477e-02
    z[7,8,5]  R2418     -9.8305873572826385e-02
    z[7,8,5]  R2419     1.3046124577522278e-01
    z[7,8,5]  R2420     -4.1442602872848511e-01
    z[7,8,5]  R2421     2.2163568437099457e-01
    z[7,8,5]  R2422     -1.1630660295486450e-01
    z[7,8,5]  R2423     5.1465582847595215e-01
    z[7,8,5]  R2424     2.1447446942329407e-01
    z[7,8,5]  R2425     -7.6004254817962646e-01
    z[7,8,5]  R2426     -6.7631185054779053e-01
    z[7,8,5]  R2427     -0.087654247879982
    z[7,8,5]  R2428     1.2756885588169098e-01
    z[7,8,5]  R2429     3.9423468708992004e-01
    z[7,8,5]  R2430     4.7471120953559875e-02
    z[7,8,5]  R2431     1.8713992834091187e-01
    z[7,8,5]  R2432     6.6836869716644287e-01
    z[7,8,5]  R2433     -4.1208758950233459e-01
    z[7,8,5]  R2434     -4.7995451092720032e-01
    z[7,8,5]  R2435     2.2771118581295013e-01
    z[7,8,5]  R2436     1.2283533066511154e-01
    z[7,8,5]  R2437     -2.7059906721115112e-01
    z[7,8,5]  R2438     2.5053784251213074e-01
    z[7,8,5]  R2439     2.8760612010955811e-01
    z[7,8,5]  R2440     1.5099765360355377e-01
    z[7,8,5]  R2441     7.9561106860637665e-02
    z[7,8,5]  R2442     -2.1995210647583008e-01
    z[7,8,5]  R2443     -1.5352936089038849e-01
    z[7,8,5]  R2444     -5.3045023232698441e-02
    z[7,8,5]  R2445     -6.1002004146575928e-01
    z[7,8,5]  R2446     -0.56720370054245
    z[7,8,5]  R2447     -4.3515142798423767e-01
    z[7,8,6]  R71       -1
    z[7,8,6]  R80       1
    z[7,8,6]  R2378     -1
    z[7,8,6]  R2379     1
    z[7,8,6]  R2380     -1.8870523571968079e-01
    z[7,8,6]  R2381     4.9171319603919983e-01
    z[7,8,6]  R2382     -0.60362309217453
    z[7,8,6]  R2383     -5.6403923034667969e-01
    z[7,8,6]  R2384     1.8313153088092804e-01
    z[7,8,6]  R2385     -0.199942946434021
    z[7,8,6]  R2386     4.3690595030784607e-01
    z[7,8,6]  R2387     1.5703898668289185e-01
    z[7,8,6]  R2388     -9.6078030765056610e-02
    z[7,8,6]  R2389     1.3117891550064087e-01
    z[7,8,6]  R2390     -0.143079936504364
    z[7,8,6]  R2391     2.5943225622177124e-01
    z[7,8,6]  R2392     3.5275071859359741e-01
    z[7,8,6]  R2393     2.4008680880069733e-01
    z[7,8,6]  R2394     -3.1180027127265930e-01
    z[7,8,6]  R2395     9.8663859069347382e-02
    z[7,8,6]  R2396     0.53147953748703
    z[7,8,6]  R2397     2.5697031617164612e-01
    z[7,8,6]  R2398     5.0778478384017944e-01
    z[7,8,6]  R2399     -3.2275646924972534e-01
    z[7,8,6]  R2400     2.4430163204669952e-02
    z[7,8,6]  R2401     -2.3918202519416809e-01
    z[7,8,6]  R2402     3.1802043318748474e-01
    z[7,8,6]  R2403     3.4584742784500122e-01
    z[7,8,6]  R2404     2.4959772825241089e-01
    z[7,8,6]  R2405     -1.1505239456892014e-01
    z[7,8,6]  R2406     1.0968401096761227e-02
    z[7,8,6]  R2407     -3.5311821848154068e-02
    z[7,8,6]  R2408     -2.6477941870689392e-01
    z[7,8,6]  R2409     -3.8045436143875122e-02
    z[7,8,6]  R2410     2.5714330375194550e-02
    z[7,8,6]  R2411     6.9936728477478027e-01
    z[7,8,6]  R2412     -0.666144609451294
    z[7,8,6]  R2413     -3.6283582448959351e-01
    z[7,8,6]  R2414     3.9054048061370850e-01
    z[7,8,6]  R2415     0.774068295955658
    z[7,8,6]  R2416     6.1636292934417725e-01
    z[7,8,6]  R2417     2.7660238742828369e-01
    z[7,8,6]  R2418     -5.1981728523969650e-02
    z[7,8,6]  R2419     -2.8619766235351562e-01
    z[7,8,6]  R2420     -1.4868296682834625e-01
    z[7,8,6]  R2421     -1.1582987010478973e-01
    z[7,8,6]  R2422     3.7121871113777161e-01
    z[7,8,6]  R2423     5.8232326060533524e-02
    z[7,8,6]  R2424     2.6676696538925171e-01
    z[7,8,6]  R2425     3.2086277008056641e-01
    z[7,8,6]  R2426     -4.7210144996643066e-01
    z[7,8,6]  R2427     -1.9453082978725433e-01
    z[7,8,6]  R2428     -5.3848903626203537e-02
    z[7,8,6]  R2429     1.6965794563293457e-01
    z[7,8,6]  R2430     1.7592374980449677e-01
    z[7,8,6]  R2431     -6.8092525005340576e-02
    z[7,8,6]  R2432     -5.4134994745254517e-01
    z[7,8,6]  R2433     3.3255517482757568e-02
    z[7,8,6]  R2434     -4.9123394489288330e-01
    z[7,8,6]  R2435     -3.0253675580024719e-01
    z[7,8,6]  R2436     -2.4402524530887604e-01
    z[7,8,6]  R2437     5.5198359489440918e-01
    z[7,8,6]  R2438     -0.158157616853714
    z[7,8,6]  R2439     -2.8575471043586731e-01
    z[7,8,6]  R2440     -6.5517071634531021e-03
    z[7,8,6]  R2441     4.0439587831497192e-01
    z[7,8,6]  R2442     7.2579854726791382e-01
    z[7,8,6]  R2443     2.6588392257690430e-01
    z[7,8,6]  R2444     3.8882508873939514e-01
    z[7,8,6]  R2445     -1.4881062321364880e-02
    z[7,8,6]  R2446     -1.4949870109558105e-01
    z[7,8,6]  R2447     2.4807748198509216e-01
    z[8,7,0]  R65       1
    z[8,7,0]  R74       -1
    z[8,7,0]  R2448     -1
    z[8,7,0]  R2449     1
    z[8,7,0]  R2462     -2.0111629366874695e-01
    z[8,7,0]  R2463     -2.4270208179950714e-01
    z[8,7,0]  R2464     -1.5699948370456696e-01
    z[8,7,0]  R2465     6.6477544605731964e-02
    z[8,7,0]  R2466     -3.5107459407299757e-03
    z[8,7,0]  R2467     2.0591892302036285e-01
    z[8,7,0]  R2468     2.3244784772396088e-01
    z[8,7,0]  R2469     1.2624438107013702e-01
    z[8,7,0]  R2470     2.1336102485656738e-01
    z[8,7,0]  R2471     -9.0435284376144409e-01
    z[8,7,0]  R2472     -7.6551824808120728e-02
    z[8,7,0]  R2473     2.0580536127090454e-01
    z[8,7,0]  R2474     2.4859334528446198e-01
    z[8,7,0]  R2475     3.4582239389419556e-01
    z[8,7,0]  R2476     1.4862895011901855e-01
    z[8,7,0]  R2477     1.0935758799314499e-01
    z[8,7,0]  R2478     -1.6155529022216797e-01
    z[8,7,0]  R2479     1.7433200776576996e-01
    z[8,7,0]  R2480     8.7078690528869629e-02
    z[8,7,0]  R2481     -1.2701866030693054e-01
    z[8,7,0]  R2482     3.0171531438827515e-01
    z[8,7,0]  R2483     7.2028465569019318e-02
    z[8,7,0]  R2484     2.7042636275291443e-01
    z[8,7,0]  R2485     1.6744980216026306e-01
    z[8,7,0]  R2486     -2.9490685090422630e-02
    z[8,7,0]  R2487     9.2251554131507874e-02
    z[8,7,0]  R2488     -1.2892271578311920e-01
    z[8,7,0]  R2489     -2.0086021721363068e-01
    z[8,7,0]  R2490     7.2531960904598236e-02
    z[8,7,0]  R2491     -0.511598527431488
    z[8,7,0]  R2492     -1.0005234181880951e-01
    z[8,7,0]  R2493     1.1733307689428329e-01
    z[8,7,0]  R2494     -4.1857632994651794e-01
    z[8,7,0]  R2495     -6.1898726224899292e-01
    z[8,7,0]  R2496     -1.4537665247917175e-01
    z[8,7,0]  R2497     2.0276996493339539e-01
    z[8,7,0]  R2498     -1.5041647851467133e-01
    z[8,7,0]  R2499     0.306181937456131
    z[8,7,0]  R2500     3.9462804794311523e-01
    z[8,7,0]  R2501     -9.6003890037536621e-02
    z[8,7,0]  R2502     4.0067169815301895e-02
    z[8,7,0]  R2503     -2.3708039522171021e-01
    z[8,7,0]  R2504     -6.1161381006240845e-01
    z[8,7,0]  R2505     5.3265875577926636e-01
    z[8,7,0]  R2506     6.7545038461685181e-01
    z[8,7,0]  R2507     4.4440844655036926e-01
    z[8,7,0]  R2508     4.5341044664382935e-01
    z[8,7,0]  R2509     -3.9376479387283325e-01
    z[8,7,0]  R2510     -3.7958592176437378e-01
    z[8,7,0]  R2511     -1.3526062667369843e-01
    z[8,7,0]  R2512     0.0799262747168541
    z[8,7,0]  R2513     -1.7884841561317444e-01
    z[8,7,0]  R2514     6.3129913806915283e-01
    z[8,7,0]  R2515     5.8014911413192749e-01
    z[8,7,0]  R2516     5.0079208612442017e-01
    z[8,7,0]  R2517     0.176330104470253
    z[8,7,0]  R2518     -3.1682834029197693e-01
    z[8,7,0]  R2519     -5.1431256532669067e-01
    z[8,7,0]  R2520     -2.9855456948280334e-01
    z[8,7,0]  R2521     4.2249751091003418e-01
    z[8,7,0]  R2522     5.5136221647262573e-01
    z[8,7,0]  R2523     5.8825761079788208e-01
    z[8,7,0]  R2524     4.1543582081794739e-01
    z[8,7,0]  R2525     3.1901162862777710e-01
    z[8,7,0]  R2526     -1.2675908207893372e-01
    z[8,7,0]  R2527     5.0275996327400208e-02
    z[8,7,0]  R2528     -2.2355319932103157e-02
    z[8,7,0]  R2529     -3.8570597767829895e-01
    z[8,7,1]  R66       1
    z[8,7,1]  R75       -1
    z[8,7,1]  R2450     -1
    z[8,7,1]  R2451     1
    z[8,7,1]  R2462     -1.3025115430355072e-01
    z[8,7,1]  R2463     -1.3317577540874481e-02
    z[8,7,1]  R2464     8.0886083841323853e-01
    z[8,7,1]  R2465     -1.3516566157341003e-01
    z[8,7,1]  R2466     6.5173107385635376e-01
    z[8,7,1]  R2467     3.7668704986572266e-02
    z[8,7,1]  R2468     6.7653638124465942e-01
    z[8,7,1]  R2469     -5.1842797547578812e-02
    z[8,7,1]  R2470     3.4885206818580627e-01
    z[8,7,1]  R2471     -1.1103361099958420e-01
    z[8,7,1]  R2472     -8.3584529161453247e-01
    z[8,7,1]  R2473     -6.5859478712081909e-01
    z[8,7,1]  R2474     -7.1510475873947144e-01
    z[8,7,1]  R2475     1.4314013719558716e-01
    z[8,7,1]  R2476     -8.4134501218795776e-01
    z[8,7,1]  R2477     -6.6101610660552979e-01
    z[8,7,1]  R2478     -8.3556854724884033e-01
    z[8,7,1]  R2479     0.401563823223114
    z[8,7,1]  R2480     1.2806928157806396e-01
    z[8,7,1]  R2481     -6.0899519920349121e-01
    z[8,7,1]  R2482     -3.6122608184814453e-01
    z[8,7,1]  R2483     -2.3939548432826996e-01
    z[8,7,1]  R2484     -3.7896192073822021e-01
    z[8,7,1]  R2485     -4.1848089545965195e-02
    z[8,7,1]  R2486     -3.4122887253761292e-01
    z[8,7,1]  R2487     -8.3733355998992920e-01
    z[8,7,1]  R2488     5.0221151113510132e-01
    z[8,7,1]  R2489     -7.7609074115753174e-01
    z[8,7,1]  R2490     6.2885576486587524e-01
    z[8,7,1]  R2491     0.226348876953125
    z[8,7,1]  R2492     -8.7646156549453735e-01
    z[8,7,1]  R2493     3.5217535495758057e-01
    z[8,7,1]  R2494     -3.4532102942466736e-01
    z[8,7,1]  R2495     -4.8880180716514587e-01
    z[8,7,1]  R2496     -0.170157328248024
    z[8,7,1]  R2497     6.2894034385681152e-01
    z[8,7,1]  R2498     -4.3408384919166565e-01
    z[8,7,1]  R2499     4.6868675947189331e-01
    z[8,7,1]  R2500     5.8811980485916138e-01
    z[8,7,1]  R2501     -1.9644196331501007e-01
    z[8,7,1]  R2502     -2.2337000072002411e-01
    z[8,7,1]  R2503     -1.9959750771522522e-01
    z[8,7,1]  R2504     -1.6205689311027527e-01
    z[8,7,1]  R2505     5.1615241914987564e-02
    z[8,7,1]  R2506     -8.8565431535243988e-02
    z[8,7,1]  R2507     6.8200731277465820e-01
    z[8,7,1]  R2508     4.6463176608085632e-01
    z[8,7,1]  R2509     0.702788770198822
    z[8,7,1]  R2510     1.8833984434604645e-01
    z[8,7,1]  R2511     -8.2548034191131592e-01
    z[8,7,1]  R2512     -2.7658230066299438e-01
    z[8,7,1]  R2513     -6.6683292388916016e-02
    z[8,7,1]  R2514     4.9134841561317444e-01
    z[8,7,1]  R2515     3.4632202982902527e-01
    z[8,7,1]  R2516     3.1011883169412613e-02
    z[8,7,1]  R2517     5.2983641624450684e-01
    z[8,7,1]  R2518     4.1821259260177612e-01
    z[8,7,1]  R2519     5.1034212112426758e-01
    z[8,7,1]  R2520     1.2049067020416260e-01
    z[8,7,1]  R2521     2.3231862485408783e-01
    z[8,7,1]  R2522     2.8565225005149841e-01
    z[8,7,1]  R2523     5.2151030302047729e-01
    z[8,7,1]  R2524     1.9055104255676270e-01
    z[8,7,1]  R2525     7.2859472036361694e-01
    z[8,7,1]  R2526     0.476112961769104
    z[8,7,1]  R2527     5.1500028371810913e-01
    z[8,7,1]  R2528     4.5134374499320984e-01
    z[8,7,1]  R2529     0.517600953578949
    z[8,7,2]  R67       1
    z[8,7,2]  R76       -1
    z[8,7,2]  R2452     -1
    z[8,7,2]  R2453     1
    z[8,7,2]  R2462     -2.7533471584320068e-01
    z[8,7,2]  R2463     -2.6543724536895752e-01
    z[8,7,2]  R2464     5.1782506704330444e-01
    z[8,7,2]  R2465     -3.1296011805534363e-01
    z[8,7,2]  R2466     -9.8057903349399567e-02
    z[8,7,2]  R2467     -6.3203227519989014e-01
    z[8,7,2]  R2468     -3.2391190528869629e-01
    z[8,7,2]  R2469     -3.6273059248924255e-01
    z[8,7,2]  R2470     5.2638594061136246e-02
    z[8,7,2]  R2471     1.6446973383426666e-01
    z[8,7,2]  R2472     -4.7788426280021667e-01
    z[8,7,2]  R2473     -4.3715590238571167e-01
    z[8,7,2]  R2474     -4.0727302432060242e-01
    z[8,7,2]  R2475     -5.4799216985702515e-01
    z[8,7,2]  R2476     -3.0662044882774353e-01
    z[8,7,2]  R2477     -3.7563818693161011e-01
    z[8,7,2]  R2478     6.4522060565650463e-03
    z[8,7,2]  R2479     1.0601682215929031e-01
    z[8,7,2]  R2480     2.8027918934822083e-01
    z[8,7,2]  R2481     7.2129350900650024e-01
    z[8,7,2]  R2482     -7.6573336124420166e-01
    z[8,7,2]  R2483     -8.0364304780960083e-01
    z[8,7,2]  R2484     -7.5284171104431152e-01
    z[8,7,2]  R2485     -7.0482075214385986e-01
    z[8,7,2]  R2486     -3.6790904402732849e-01
    z[8,7,2]  R2487     -3.1498628854751587e-01
    z[8,7,2]  R2488     3.7793284654617310e-01
    z[8,7,2]  R2489     8.5784226655960083e-02
    z[8,7,2]  R2490     7.4811629019677639e-03
    z[8,7,2]  R2491     -5.0689816474914551e-01
    z[8,7,2]  R2492     -2.7843010425567627e-01
    z[8,7,2]  R2493     -6.5639001131057739e-01
    z[8,7,2]  R2494     -1.6937333345413208e-01
    z[8,7,2]  R2495     -3.5882163047790527e-01
    z[8,7,2]  R2496     -1.8943351507186890e-01
    z[8,7,2]  R2497     -0.0875493511557579
    z[8,7,2]  R2498     1.4354649186134338e-01
    z[8,7,2]  R2499     1.4232377707958221e-01
    z[8,7,2]  R2500     -3.8037461042404175e-01
    z[8,7,2]  R2501     0.682428777217865
    z[8,7,2]  R2502     1.7554818093776703e-01
    z[8,7,2]  R2503     -2.6097807288169861e-01
    z[8,7,2]  R2504     -4.7502890229225159e-01
    z[8,7,2]  R2505     -2.2710184752941132e-01
    z[8,7,2]  R2506     -2.8238528966903687e-01
    z[8,7,2]  R2507     1.4959146082401276e-01
    z[8,7,2]  R2508     2.1901136636734009e-01
    z[8,7,2]  R2509     5.6506818532943726e-01
    z[8,7,2]  R2510     7.5908845663070679e-01
    z[8,7,2]  R2511     2.3316064476966858e-01
    z[8,7,2]  R2512     1.1616774648427963e-01
    z[8,7,2]  R2513     -1.7606303095817566e-01
    z[8,7,2]  R2514     4.2033895850181580e-01
    z[8,7,2]  R2515     3.2234114408493042e-01
    z[8,7,2]  R2516     4.9098369479179382e-01
    z[8,7,2]  R2517     6.4764000475406647e-02
    z[8,7,2]  R2518     -3.6040741205215454e-01
    z[8,7,2]  R2519     6.1960095167160034e-01
    z[8,7,2]  R2520     -1.6804602742195129e-01
    z[8,7,2]  R2521     4.1956314444541931e-01
    z[8,7,2]  R2522     4.4844293594360352e-01
    z[8,7,2]  R2523     3.8353288173675537e-01
    z[8,7,2]  R2524     0.421851247549057
    z[8,7,2]  R2525     8.3521112799644470e-02
    z[8,7,2]  R2526     -2.0321704447269440e-01
    z[8,7,2]  R2527     -1.2585286796092987e-01
    z[8,7,2]  R2528     -2.1186162531375885e-01
    z[8,7,2]  R2529     6.4983642101287842e-01
    z[8,7,3]  R68       1
    z[8,7,3]  R77       -1
    z[8,7,3]  R2454     -1
    z[8,7,3]  R2455     1
    z[8,7,3]  R2462     -4.1108828783035278e-01
    z[8,7,3]  R2463     -3.3574259281158447e-01
    z[8,7,3]  R2464     0.098890021443367
    z[8,7,3]  R2465     3.4599813818931580e-01
    z[8,7,3]  R2466     1.0233910754323006e-02
    z[8,7,3]  R2467     -5.9911131858825684e-01
    z[8,7,3]  R2468     1.8235588073730469e-01
    z[8,7,3]  R2469     -4.5054781436920166e-01
    z[8,7,3]  R2470     6.2465268373489380e-01
    z[8,7,3]  R2471     -1.8111613392829895e-01
    z[8,7,3]  R2472     9.4365149736404419e-02
    z[8,7,3]  R2473     4.7966772317886353e-01
    z[8,7,3]  R2474     2.5894096493721008e-01
    z[8,7,3]  R2475     6.8568712472915649e-01
    z[8,7,3]  R2476     1.5062336623668671e-01
    z[8,7,3]  R2477     1.1097923666238785e-01
    z[8,7,3]  R2478     -0.344770610332489
    z[8,7,3]  R2479     -2.7805429697036743e-01
    z[8,7,3]  R2480     4.6462345123291016e-01
    z[8,7,3]  R2481     0.0957830622792244
    z[8,7,3]  R2482     3.1819251179695129e-01
    z[8,7,3]  R2483     -2.6399964094161987e-01
    z[8,7,3]  R2484     -3.9392209053039551e-01
    z[8,7,3]  R2485     -6.4627963304519653e-01
    z[8,7,3]  R2486     8.1930831074714661e-02
    z[8,7,3]  R2487     -9.7869694232940674e-02
    z[8,7,3]  R2488     5.9446100145578384e-02
    z[8,7,3]  R2489     3.5228466987609863e-01
    z[8,7,3]  R2490     -4.2278897762298584e-01
    z[8,7,3]  R2491     1.8325652927160263e-02
    z[8,7,3]  R2492     -2.3752617835998535e-01
    z[8,7,3]  R2493     -4.9152252078056335e-01
    z[8,7,3]  R2494     5.2153009176254272e-01
    z[8,7,3]  R2495     -2.8063976764678955e-01
    z[8,7,3]  R2496     -4.1833803988993168e-03
    z[8,7,3]  R2497     5.4240250587463379e-01
    z[8,7,3]  R2498     4.0116497874259949e-01
    z[8,7,3]  R2499     3.5707205533981323e-01
    z[8,7,3]  R2500     9.5357939600944519e-02
    z[8,7,3]  R2501     1.0043677687644958e-01
    z[8,7,3]  R2502     -7.9482358694076538e-01
    z[8,7,3]  R2503     -3.7739893794059753e-01
    z[8,7,3]  R2504     -8.0764904618263245e-02
    z[8,7,3]  R2505     1.9979354739189148e-01
    z[8,7,3]  R2506     3.8262015581130981e-01
    z[8,7,3]  R2507     2.7596119046211243e-01
    z[8,7,3]  R2508     1.8535287678241730e-01
    z[8,7,3]  R2509     -3.4371569752693176e-02
    z[8,7,3]  R2510     3.5858038067817688e-01
    z[8,7,3]  R2511     7.0522271096706390e-02
    z[8,7,3]  R2512     7.6576471328735352e-01
    z[8,7,3]  R2513     8.7756061553955078e-01
    z[8,7,3]  R2514     -1.1006095260381699e-01
    z[8,7,3]  R2515     3.4041205048561096e-01
    z[8,7,3]  R2516     5.4449033737182617e-01
    z[8,7,3]  R2517     4.1975349187850952e-01
    z[8,7,3]  R2518     -7.2573184967041016e-02
    z[8,7,3]  R2519     2.0260216668248177e-02
    z[8,7,3]  R2520     -1.3500805199146271e-01
    z[8,7,3]  R2521     2.1684104204177856e-01
    z[8,7,3]  R2522     4.3430694937705994e-01
    z[8,7,3]  R2523     2.4595226347446442e-01
    z[8,7,3]  R2524     2.8161951899528503e-01
    z[8,7,3]  R2525     0.00901623535901308
    z[8,7,3]  R2526     -4.5758393406867981e-01
    z[8,7,3]  R2527     4.2273014783859253e-01
    z[8,7,3]  R2528     6.0827469825744629e-01
    z[8,7,3]  R2529     1.8400286138057709e-01
    z[8,7,4]  R69       1
    z[8,7,4]  R78       -1
    z[8,7,4]  R2456     -1
    z[8,7,4]  R2457     1
    z[8,7,4]  R2462     -7.9225790500640869e-01
    z[8,7,4]  R2463     -6.1505675315856934e-01
    z[8,7,4]  R2464     4.5633900910615921e-02
    z[8,7,4]  R2465     -4.8944196105003357e-01
    z[8,7,4]  R2466     -1.1414247564971447e-03
    z[8,7,4]  R2467     2.5589668750762939e-01
    z[8,7,4]  R2468     -4.3162095546722412e-01
    z[8,7,4]  R2469     -1.5001788735389709e-01
    z[8,7,4]  R2470     -1.7305327951908112e-01
    z[8,7,4]  R2471     1.5978132188320160e-01
    z[8,7,4]  R2472     2.1414557099342346e-01
    z[8,7,4]  R2473     6.1492212116718292e-02
    z[8,7,4]  R2474     7.0217796601355076e-03
    z[8,7,4]  R2475     -1.6406312584877014e-01
    z[8,7,4]  R2476     4.4874947518110275e-02
    z[8,7,4]  R2477     3.5974502563476562e-01
    z[8,7,4]  R2478     1.9913001358509064e-01
    z[8,7,4]  R2479     1.9794845581054688e-01
    z[8,7,4]  R2480     -3.6149136722087860e-02
    z[8,7,4]  R2481     -1.9500473141670227e-01
    z[8,7,4]  R2482     -0.267798513174057
    z[8,7,4]  R2483     1.9431692361831665e-01
    z[8,7,4]  R2484     1.6765825450420380e-01
    z[8,7,4]  R2485     1.2689247727394104e-01
    z[8,7,4]  R2486     2.9101692140102386e-02
    z[8,7,4]  R2487     -1.0317552089691162e-01
    z[8,7,4]  R2488     -3.3634561300277710e-01
    z[8,7,4]  R2489     -2.8721749782562256e-01
    z[8,7,4]  R2490     5.8807837963104248e-01
    z[8,7,4]  R2491     -2.2768768668174744e-01
    z[8,7,4]  R2492     -8.9141465723514557e-03
    z[8,7,4]  R2493     -1.5934322774410248e-01
    z[8,7,4]  R2494     -0.618080198764801
    z[8,7,4]  R2495     2.3450503125786781e-02
    z[8,7,4]  R2496     -5.8210569620132446e-01
    z[8,7,4]  R2497     -4.0888571739196777e-01
    z[8,7,4]  R2498     -6.7335605621337891e-01
    z[8,7,4]  R2499     4.0802329778671265e-01
    z[8,7,4]  R2500     2.3148220032453537e-02
    z[8,7,4]  R2501     4.7486644983291626e-01
    z[8,7,4]  R2502     -1.0521605610847473e-01
    z[8,7,4]  R2503     -6.6669136285781860e-01
    z[8,7,4]  R2504     4.0884606540203094e-02
    z[8,7,4]  R2505     -5.4078716039657593e-01
    z[8,7,4]  R2506     -1.9201116263866425e-01
    z[8,7,4]  R2507     9.9918648600578308e-02
    z[8,7,4]  R2508     -1.4944776892662048e-02
    z[8,7,4]  R2509     -1.1669119819998741e-02
    z[8,7,4]  R2510     3.0302062630653381e-01
    z[8,7,4]  R2511     1.8192978203296661e-01
    z[8,7,4]  R2512     -1.5622977912425995e-01
    z[8,7,4]  R2513     1.0299666225910187e-01
    z[8,7,4]  R2514     1.7547617852687836e-01
    z[8,7,4]  R2515     -2.6857721805572510e-01
    z[8,7,4]  R2516     3.1995329260826111e-01
    z[8,7,4]  R2517     6.8665152788162231e-01
    z[8,7,4]  R2518     5.3739798069000244e-01
    z[8,7,4]  R2519     1.2559781968593597e-01
    z[8,7,4]  R2520     7.2910869121551514e-01
    z[8,7,4]  R2521     5.8731347322463989e-01
    z[8,7,4]  R2522     3.6370679736137390e-01
    z[8,7,4]  R2523     2.7539917826652527e-01
    z[8,7,4]  R2524     6.5521574020385742e-01
    z[8,7,4]  R2525     4.1041484475135803e-01
    z[8,7,4]  R2526     4.4433760643005371e-01
    z[8,7,4]  R2527     3.7291434407234192e-01
    z[8,7,4]  R2528     2.2865977883338928e-01
    z[8,7,4]  R2529     -2.5542598962783813e-01
    z[8,7,5]  R70       1
    z[8,7,5]  R79       -1
    z[8,7,5]  R2458     -1
    z[8,7,5]  R2459     1
    z[8,7,5]  R2462     1.8564743222668767e-03
    z[8,7,5]  R2463     6.1481392383575439e-01
    z[8,7,5]  R2464     2.0107144117355347e-01
    z[8,7,5]  R2465     1.7602321505546570e-01
    z[8,7,5]  R2466     3.4894740581512451e-01
    z[8,7,5]  R2467     -2.5422504171729088e-02
    z[8,7,5]  R2468     -1.0618577152490616e-01
    z[8,7,5]  R2469     -1.5849521756172180e-01
    z[8,7,5]  R2470     -1.7310941219329834e-01
    z[8,7,5]  R2471     -8.9023463428020477e-02
    z[8,7,5]  R2472     -9.8305873572826385e-02
    z[8,7,5]  R2473     1.3046124577522278e-01
    z[8,7,5]  R2474     -4.1442602872848511e-01
    z[8,7,5]  R2475     2.2163568437099457e-01
    z[8,7,5]  R2476     -1.1630660295486450e-01
    z[8,7,5]  R2477     5.1465582847595215e-01
    z[8,7,5]  R2478     2.1447446942329407e-01
    z[8,7,5]  R2479     -7.6004254817962646e-01
    z[8,7,5]  R2480     -6.7631185054779053e-01
    z[8,7,5]  R2481     -0.087654247879982
    z[8,7,5]  R2482     1.2756885588169098e-01
    z[8,7,5]  R2483     3.9423468708992004e-01
    z[8,7,5]  R2484     4.7471120953559875e-02
    z[8,7,5]  R2485     1.8713992834091187e-01
    z[8,7,5]  R2486     6.6836869716644287e-01
    z[8,7,5]  R2487     -4.1208758950233459e-01
    z[8,7,5]  R2488     -4.7995451092720032e-01
    z[8,7,5]  R2489     2.2771118581295013e-01
    z[8,7,5]  R2490     1.2283533066511154e-01
    z[8,7,5]  R2491     -2.7059906721115112e-01
    z[8,7,5]  R2492     2.5053784251213074e-01
    z[8,7,5]  R2493     2.8760612010955811e-01
    z[8,7,5]  R2494     1.5099765360355377e-01
    z[8,7,5]  R2495     7.9561106860637665e-02
    z[8,7,5]  R2496     -2.1995210647583008e-01
    z[8,7,5]  R2497     -1.5352936089038849e-01
    z[8,7,5]  R2498     -5.3045023232698441e-02
    z[8,7,5]  R2499     -6.1002004146575928e-01
    z[8,7,5]  R2500     -0.56720370054245
    z[8,7,5]  R2501     -4.3515142798423767e-01
    z[8,7,5]  R2502     4.8914080858230591e-01
    z[8,7,5]  R2503     8.4587134420871735e-02
    z[8,7,5]  R2504     3.8188643753528595e-02
    z[8,7,5]  R2505     1.0736273974180222e-01
    z[8,7,5]  R2506     4.8926255106925964e-01
    z[8,7,5]  R2507     0.434596449136734
    z[8,7,5]  R2508     5.5236268043518066e-01
    z[8,7,5]  R2509     -0.0758703202009201
    z[8,7,5]  R2510     -1.2080959230661392e-01
    z[8,7,5]  R2511     -4.3662688136100769e-01
    z[8,7,5]  R2512     5.2186584472656250e-01
    z[8,7,5]  R2513     2.9076170921325684e-01
    z[8,7,5]  R2514     -1.2655048072338104e-01
    z[8,7,5]  R2515     0.440373033285141
    z[8,7,5]  R2516     1.0545748472213745e-01
    z[8,7,5]  R2517     1.6299945116043091e-01
    z[8,7,5]  R2518     -1.3524267077445984e-01
    z[8,7,5]  R2519     9.4388015568256378e-02
    z[8,7,5]  R2520     2.4583670496940613e-01
    z[8,7,5]  R2521     3.0880689620971680e-01
    z[8,7,5]  R2522     3.0298420786857605e-01
    z[8,7,5]  R2523     2.0331549644470215e-01
    z[8,7,5]  R2524     5.8228474110364914e-02
    z[8,7,5]  R2525     2.6883718371391296e-01
    z[8,7,5]  R2526     -4.9682331085205078e-01
    z[8,7,5]  R2527     -6.2081003189086914e-01
    z[8,7,5]  R2528     -5.7314914464950562e-01
    z[8,7,5]  R2529     -2.4634602665901184e-01
    z[8,7,6]  R71       1
    z[8,7,6]  R80       -1
    z[8,7,6]  R2460     -1
    z[8,7,6]  R2461     1
    z[8,7,6]  R2462     -2.6477941870689392e-01
    z[8,7,6]  R2463     -3.8045436143875122e-02
    z[8,7,6]  R2464     2.5714330375194550e-02
    z[8,7,6]  R2465     6.9936728477478027e-01
    z[8,7,6]  R2466     -0.666144609451294
    z[8,7,6]  R2467     -3.6283582448959351e-01
    z[8,7,6]  R2468     3.9054048061370850e-01
    z[8,7,6]  R2469     0.774068295955658
    z[8,7,6]  R2470     6.1636292934417725e-01
    z[8,7,6]  R2471     2.7660238742828369e-01
    z[8,7,6]  R2472     -5.1981728523969650e-02
    z[8,7,6]  R2473     -2.8619766235351562e-01
    z[8,7,6]  R2474     -1.4868296682834625e-01
    z[8,7,6]  R2475     -1.1582987010478973e-01
    z[8,7,6]  R2476     3.7121871113777161e-01
    z[8,7,6]  R2477     5.8232326060533524e-02
    z[8,7,6]  R2478     2.6676696538925171e-01
    z[8,7,6]  R2479     3.2086277008056641e-01
    z[8,7,6]  R2480     -4.7210144996643066e-01
    z[8,7,6]  R2481     -1.9453082978725433e-01
    z[8,7,6]  R2482     -5.3848903626203537e-02
    z[8,7,6]  R2483     1.6965794563293457e-01
    z[8,7,6]  R2484     1.7592374980449677e-01
    z[8,7,6]  R2485     -6.8092525005340576e-02
    z[8,7,6]  R2486     -5.4134994745254517e-01
    z[8,7,6]  R2487     3.3255517482757568e-02
    z[8,7,6]  R2488     -4.9123394489288330e-01
    z[8,7,6]  R2489     -3.0253675580024719e-01
    z[8,7,6]  R2490     -2.4402524530887604e-01
    z[8,7,6]  R2491     5.5198359489440918e-01
    z[8,7,6]  R2492     -0.158157616853714
    z[8,7,6]  R2493     -2.8575471043586731e-01
    z[8,7,6]  R2494     -6.5517071634531021e-03
    z[8,7,6]  R2495     4.0439587831497192e-01
    z[8,7,6]  R2496     7.2579854726791382e-01
    z[8,7,6]  R2497     2.6588392257690430e-01
    z[8,7,6]  R2498     3.8882508873939514e-01
    z[8,7,6]  R2499     -1.4881062321364880e-02
    z[8,7,6]  R2500     -1.4949870109558105e-01
    z[8,7,6]  R2501     2.4807748198509216e-01
    z[8,7,6]  R2502     -1.8870523571968079e-01
    z[8,7,6]  R2503     4.9171319603919983e-01
    z[8,7,6]  R2504     -0.60362309217453
    z[8,7,6]  R2505     -5.6403923034667969e-01
    z[8,7,6]  R2506     1.8313153088092804e-01
    z[8,7,6]  R2507     -0.199942946434021
    z[8,7,6]  R2508     4.3690595030784607e-01
    z[8,7,6]  R2509     1.5703898668289185e-01
    z[8,7,6]  R2510     -9.6078030765056610e-02
    z[8,7,6]  R2511     1.3117891550064087e-01
    z[8,7,6]  R2512     -0.143079936504364
    z[8,7,6]  R2513     2.5943225622177124e-01
    z[8,7,6]  R2514     3.5275071859359741e-01
    z[8,7,6]  R2515     2.4008680880069733e-01
    z[8,7,6]  R2516     -3.1180027127265930e-01
    z[8,7,6]  R2517     9.8663859069347382e-02
    z[8,7,6]  R2518     0.53147953748703
    z[8,7,6]  R2519     2.5697031617164612e-01
    z[8,7,6]  R2520     5.0778478384017944e-01
    z[8,7,6]  R2521     -3.2275646924972534e-01
    z[8,7,6]  R2522     2.4430163204669952e-02
    z[8,7,6]  R2523     -2.3918202519416809e-01
    z[8,7,6]  R2524     3.1802043318748474e-01
    z[8,7,6]  R2525     3.4584742784500122e-01
    z[8,7,6]  R2526     2.4959772825241089e-01
    z[8,7,6]  R2527     -1.1505239456892014e-01
    z[8,7,6]  R2528     1.0968401096761227e-02
    z[8,7,6]  R2529     -3.5311821848154068e-02
    z[8,9,0]  R74       -1
    z[8,9,0]  R83       1
    z[8,9,0]  R2530     -1
    z[8,9,0]  R2531     1
    z[8,9,0]  R2544     -2.0111629366874695e-01
    z[8,9,0]  R2545     -2.4270208179950714e-01
    z[8,9,0]  R2546     -1.5699948370456696e-01
    z[8,9,0]  R2547     6.6477544605731964e-02
    z[8,9,0]  R2548     -3.5107459407299757e-03
    z[8,9,0]  R2549     2.0591892302036285e-01
    z[8,9,0]  R2550     2.3244784772396088e-01
    z[8,9,0]  R2551     1.2624438107013702e-01
    z[8,9,0]  R2552     2.1336102485656738e-01
    z[8,9,0]  R2553     -9.0435284376144409e-01
    z[8,9,0]  R2554     -7.6551824808120728e-02
    z[8,9,0]  R2555     2.0580536127090454e-01
    z[8,9,0]  R2556     2.4859334528446198e-01
    z[8,9,0]  R2557     3.4582239389419556e-01
    z[8,9,0]  R2558     1.4862895011901855e-01
    z[8,9,0]  R2559     1.0935758799314499e-01
    z[8,9,0]  R2560     -1.6155529022216797e-01
    z[8,9,0]  R2561     1.7433200776576996e-01
    z[8,9,0]  R2562     8.7078690528869629e-02
    z[8,9,0]  R2563     -1.2701866030693054e-01
    z[8,9,0]  R2564     3.0171531438827515e-01
    z[8,9,0]  R2565     7.2028465569019318e-02
    z[8,9,0]  R2566     2.7042636275291443e-01
    z[8,9,0]  R2567     1.6744980216026306e-01
    z[8,9,0]  R2568     -2.9490685090422630e-02
    z[8,9,0]  R2569     9.2251554131507874e-02
    z[8,9,0]  R2570     -1.2892271578311920e-01
    z[8,9,0]  R2571     -2.0086021721363068e-01
    z[8,9,0]  R2572     7.2531960904598236e-02
    z[8,9,0]  R2573     -0.511598527431488
    z[8,9,0]  R2574     -1.0005234181880951e-01
    z[8,9,0]  R2575     1.1733307689428329e-01
    z[8,9,0]  R2576     -4.1857632994651794e-01
    z[8,9,0]  R2577     -6.1898726224899292e-01
    z[8,9,0]  R2578     -1.4537665247917175e-01
    z[8,9,0]  R2579     2.0276996493339539e-01
    z[8,9,0]  R2580     -1.5041647851467133e-01
    z[8,9,0]  R2581     0.306181937456131
    z[8,9,0]  R2582     3.9462804794311523e-01
    z[8,9,0]  R2583     -9.6003890037536621e-02
    z[8,9,0]  R2584     -1.1683891713619232e-01
    z[8,9,0]  R2585     -7.2481578588485718e-01
    z[8,9,0]  R2586     -7.7795642614364624e-01
    z[8,9,0]  R2587     -4.9626111984252930e-02
    z[8,9,0]  R2588     5.6205615401268005e-02
    z[8,9,0]  R2589     2.8992640972137451e-01
    z[8,9,0]  R2590     2.4261078238487244e-01
    z[8,9,0]  R2591     9.8038287833333015e-03
    z[8,9,0]  R2592     0.440586119890213
    z[8,9,0]  R2593     5.4980188608169556e-01
    z[8,9,0]  R2594     9.0830363333225250e-02
    z[8,9,0]  R2595     4.7096928954124451e-01
    z[8,9,0]  R2596     2.6634064316749573e-01
    z[8,9,0]  R2597     8.6104303598403931e-02
    z[8,9,0]  R2598     3.6794704198837280e-01
    z[8,9,0]  R2599     -1.6276559233665466e-01
    z[8,9,0]  R2600     -1.7888191342353821e-01
    z[8,9,0]  R2601     4.6682957559823990e-02
    z[8,9,0]  R2602     1.5970674157142639e-01
    z[8,9,0]  R2603     -6.7939713597297668e-02
    z[8,9,0]  R2604     -0.0341838039457798
    z[8,9,0]  R2605     2.9439744353294373e-01
    z[8,9,0]  R2606     -1.9379843771457672e-01
    z[8,9,0]  R2607     2.5401732325553894e-01
    z[8,9,0]  R2608     -6.9402478635311127e-02
    z[8,9,0]  R2609     7.1375928819179535e-02
    z[8,9,0]  R2610     1.3114073872566223e-01
    z[8,9,0]  R2611     1.0505028814077377e-01
    z[8,9,0]  R2612     -1.5803864598274231e-01
    z[8,9,0]  R2613     -1.6549913585186005e-01
    z[8,9,0]  R2614     3.6452811956405640e-01
    z[8,9,0]  R2615     -5.6082367897033691e-02
    z[8,9,0]  R2616     3.6245340108871460e-01
    z[8,9,0]  R2617     1.3113540597259998e-02
    z[8,9,1]  R75       -1
    z[8,9,1]  R84       1
    z[8,9,1]  R2532     -1
    z[8,9,1]  R2533     1
    z[8,9,1]  R2544     -1.3025115430355072e-01
    z[8,9,1]  R2545     -1.3317577540874481e-02
    z[8,9,1]  R2546     8.0886083841323853e-01
    z[8,9,1]  R2547     -1.3516566157341003e-01
    z[8,9,1]  R2548     6.5173107385635376e-01
    z[8,9,1]  R2549     3.7668704986572266e-02
    z[8,9,1]  R2550     6.7653638124465942e-01
    z[8,9,1]  R2551     -5.1842797547578812e-02
    z[8,9,1]  R2552     3.4885206818580627e-01
    z[8,9,1]  R2553     -1.1103361099958420e-01
    z[8,9,1]  R2554     -8.3584529161453247e-01
    z[8,9,1]  R2555     -6.5859478712081909e-01
    z[8,9,1]  R2556     -7.1510475873947144e-01
    z[8,9,1]  R2557     1.4314013719558716e-01
    z[8,9,1]  R2558     -8.4134501218795776e-01
    z[8,9,1]  R2559     -6.6101610660552979e-01
    z[8,9,1]  R2560     -8.3556854724884033e-01
    z[8,9,1]  R2561     0.401563823223114
    z[8,9,1]  R2562     1.2806928157806396e-01
    z[8,9,1]  R2563     -6.0899519920349121e-01
    z[8,9,1]  R2564     -3.6122608184814453e-01
    z[8,9,1]  R2565     -2.3939548432826996e-01
    z[8,9,1]  R2566     -3.7896192073822021e-01
    z[8,9,1]  R2567     -4.1848089545965195e-02
    z[8,9,1]  R2568     -3.4122887253761292e-01
    z[8,9,1]  R2569     -8.3733355998992920e-01
    z[8,9,1]  R2570     5.0221151113510132e-01
    z[8,9,1]  R2571     -7.7609074115753174e-01
    z[8,9,1]  R2572     6.2885576486587524e-01
    z[8,9,1]  R2573     0.226348876953125
    z[8,9,1]  R2574     -8.7646156549453735e-01
    z[8,9,1]  R2575     3.5217535495758057e-01
    z[8,9,1]  R2576     -3.4532102942466736e-01
    z[8,9,1]  R2577     -4.8880180716514587e-01
    z[8,9,1]  R2578     -0.170157328248024
    z[8,9,1]  R2579     6.2894034385681152e-01
    z[8,9,1]  R2580     -4.3408384919166565e-01
    z[8,9,1]  R2581     4.6868675947189331e-01
    z[8,9,1]  R2582     5.8811980485916138e-01
    z[8,9,1]  R2583     -1.9644196331501007e-01
    z[8,9,1]  R2584     5.5101519823074341e-01
    z[8,9,1]  R2585     1.3473220169544220e-01
    z[8,9,1]  R2586     1.6858656704425812e-01
    z[8,9,1]  R2587     4.2314249277114868e-01
    z[8,9,1]  R2588     -2.8061237186193466e-02
    z[8,9,1]  R2589     0.714479923248291
    z[8,9,1]  R2590     7.6638185977935791e-01
    z[8,9,1]  R2591     -5.1809144020080566e-01
    z[8,9,1]  R2592     -2.1793937683105469e-01
    z[8,9,1]  R2593     -3.7115550041198730e-01
    z[8,9,1]  R2594     -4.5765072107315063e-01
    z[8,9,1]  R2595     -4.2141985893249512e-01
    z[8,9,1]  R2596     -1.5965756773948669e-01
    z[8,9,1]  R2597     -4.7693407535552979e-01
    z[8,9,1]  R2598     -2.7830743789672852e-01
    z[8,9,1]  R2599     -6.4149700105190277e-02
    z[8,9,1]  R2600     -7.0111477375030518e-01
    z[8,9,1]  R2601     -9.2115324735641479e-01
    z[8,9,1]  R2602     -8.8041067123413086e-01
    z[8,9,1]  R2603     -8.6946618556976318e-01
    z[8,9,1]  R2604     -7.5549733638763428e-01
    z[8,9,1]  R2605     -8.7078070640563965e-01
    z[8,9,1]  R2606     -8.5063123703002930e-01
    z[8,9,1]  R2607     -8.1650906801223755e-01
    z[8,9,1]  R2608     -8.8971352577209473e-01
    z[8,9,1]  R2609     -0.678108274936676
    z[8,9,1]  R2610     -6.2778592109680176e-01
    z[8,9,1]  R2611     -4.3269151449203491e-01
    z[8,9,1]  R2612     -0.902143120765686
    z[8,9,1]  R2613     -8.7095803022384644e-01
    z[8,9,1]  R2614     -6.8296605348587036e-01
    z[8,9,1]  R2615     -3.3892369270324707e-01
    z[8,9,1]  R2616     -7.9935854673385620e-01
    z[8,9,1]  R2617     -7.5542962551116943e-01
    z[8,9,2]  R76       -1
    z[8,9,2]  R85       1
    z[8,9,2]  R2534     -1
    z[8,9,2]  R2535     1
    z[8,9,2]  R2544     -2.7533471584320068e-01
    z[8,9,2]  R2545     -2.6543724536895752e-01
    z[8,9,2]  R2546     5.1782506704330444e-01
    z[8,9,2]  R2547     -3.1296011805534363e-01
    z[8,9,2]  R2548     -9.8057903349399567e-02
    z[8,9,2]  R2549     -6.3203227519989014e-01
    z[8,9,2]  R2550     -3.2391190528869629e-01
    z[8,9,2]  R2551     -3.6273059248924255e-01
    z[8,9,2]  R2552     5.2638594061136246e-02
    z[8,9,2]  R2553     1.6446973383426666e-01
    z[8,9,2]  R2554     -4.7788426280021667e-01
    z[8,9,2]  R2555     -4.3715590238571167e-01
    z[8,9,2]  R2556     -4.0727302432060242e-01
    z[8,9,2]  R2557     -5.4799216985702515e-01
    z[8,9,2]  R2558     -3.0662044882774353e-01
    z[8,9,2]  R2559     -3.7563818693161011e-01
    z[8,9,2]  R2560     6.4522060565650463e-03
    z[8,9,2]  R2561     1.0601682215929031e-01
    z[8,9,2]  R2562     2.8027918934822083e-01
    z[8,9,2]  R2563     7.2129350900650024e-01
    z[8,9,2]  R2564     -7.6573336124420166e-01
    z[8,9,2]  R2565     -8.0364304780960083e-01
    z[8,9,2]  R2566     -7.5284171104431152e-01
    z[8,9,2]  R2567     -7.0482075214385986e-01
    z[8,9,2]  R2568     -3.6790904402732849e-01
    z[8,9,2]  R2569     -3.1498628854751587e-01
    z[8,9,2]  R2570     3.7793284654617310e-01
    z[8,9,2]  R2571     8.5784226655960083e-02
    z[8,9,2]  R2572     7.4811629019677639e-03
    z[8,9,2]  R2573     -5.0689816474914551e-01
    z[8,9,2]  R2574     -2.7843010425567627e-01
    z[8,9,2]  R2575     -6.5639001131057739e-01
    z[8,9,2]  R2576     -1.6937333345413208e-01
    z[8,9,2]  R2577     -3.5882163047790527e-01
    z[8,9,2]  R2578     -1.8943351507186890e-01
    z[8,9,2]  R2579     -0.0875493511557579
    z[8,9,2]  R2580     1.4354649186134338e-01
    z[8,9,2]  R2581     1.4232377707958221e-01
    z[8,9,2]  R2582     -3.8037461042404175e-01
    z[8,9,2]  R2583     0.682428777217865
    z[8,9,2]  R2584     6.5449941158294678e-01
    z[8,9,2]  R2585     -4.3286693096160889e-01
    z[8,9,2]  R2586     1.2441541254520416e-01
    z[8,9,2]  R2587     -1.7065811157226562e-01
    z[8,9,2]  R2588     6.5025717020034790e-01
    z[8,9,2]  R2589     -1.3663330674171448e-01
    z[8,9,2]  R2590     4.7430303692817688e-01
    z[8,9,2]  R2591     -5.1721256971359253e-01
    z[8,9,2]  R2592     -8.2653927803039551e-01
    z[8,9,2]  R2593     -0.553094744682312
    z[8,9,2]  R2594     -8.1289076805114746e-01
    z[8,9,2]  R2595     -4.1897448897361755e-01
    z[8,9,2]  R2596     -7.3320406675338745e-01
    z[8,9,2]  R2597     -3.8440600037574768e-01
    z[8,9,2]  R2598     -5.3828316926956177e-01
    z[8,9,2]  R2599     4.1125959157943726e-01
    z[8,9,2]  R2600     -5.0224578380584717e-01
    z[8,9,2]  R2601     -0.235634446144104
    z[8,9,2]  R2602     3.0603477358818054e-01
    z[8,9,2]  R2603     3.4926262497901917e-01
    z[8,9,2]  R2604     -2.6990300416946411e-01
    z[8,9,2]  R2605     2.1224774420261383e-01
    z[8,9,2]  R2606     4.4793450832366943e-01
    z[8,9,2]  R2607     4.8370894789695740e-01
    z[8,9,2]  R2608     -1.0303554683923721e-01
    z[8,9,2]  R2609     -5.9813553094863892e-01
    z[8,9,2]  R2610     -4.4539690017700195e-01
    z[8,9,2]  R2611     -6.5150165557861328e-01
    z[8,9,2]  R2612     -2.7931925654411316e-01
    z[8,9,2]  R2613     -2.8034433722496033e-01
    z[8,9,2]  R2614     -1.2294710427522659e-01
    z[8,9,2]  R2615     -8.6787927150726318e-01
    z[8,9,2]  R2616     2.5643259286880493e-01
    z[8,9,2]  R2617     2.2316598892211914e-01
    z[8,9,3]  R77       -1
    z[8,9,3]  R86       1
    z[8,9,3]  R2536     -1
    z[8,9,3]  R2537     1
    z[8,9,3]  R2544     -4.1108828783035278e-01
    z[8,9,3]  R2545     -3.3574259281158447e-01
    z[8,9,3]  R2546     0.098890021443367
    z[8,9,3]  R2547     3.4599813818931580e-01
    z[8,9,3]  R2548     1.0233910754323006e-02
    z[8,9,3]  R2549     -5.9911131858825684e-01
    z[8,9,3]  R2550     1.8235588073730469e-01
    z[8,9,3]  R2551     -4.5054781436920166e-01
    z[8,9,3]  R2552     6.2465268373489380e-01
    z[8,9,3]  R2553     -1.8111613392829895e-01
    z[8,9,3]  R2554     9.4365149736404419e-02
    z[8,9,3]  R2555     4.7966772317886353e-01
    z[8,9,3]  R2556     2.5894096493721008e-01
    z[8,9,3]  R2557     6.8568712472915649e-01
    z[8,9,3]  R2558     1.5062336623668671e-01
    z[8,9,3]  R2559     1.1097923666238785e-01
    z[8,9,3]  R2560     -0.344770610332489
    z[8,9,3]  R2561     -2.7805429697036743e-01
    z[8,9,3]  R2562     4.6462345123291016e-01
    z[8,9,3]  R2563     0.0957830622792244
    z[8,9,3]  R2564     3.1819251179695129e-01
    z[8,9,3]  R2565     -2.6399964094161987e-01
    z[8,9,3]  R2566     -3.9392209053039551e-01
    z[8,9,3]  R2567     -6.4627963304519653e-01
    z[8,9,3]  R2568     8.1930831074714661e-02
    z[8,9,3]  R2569     -9.7869694232940674e-02
    z[8,9,3]  R2570     5.9446100145578384e-02
    z[8,9,3]  R2571     3.5228466987609863e-01
    z[8,9,3]  R2572     -4.2278897762298584e-01
    z[8,9,3]  R2573     1.8325652927160263e-02
    z[8,9,3]  R2574     -2.3752617835998535e-01
    z[8,9,3]  R2575     -4.9152252078056335e-01
    z[8,9,3]  R2576     5.2153009176254272e-01
    z[8,9,3]  R2577     -2.8063976764678955e-01
    z[8,9,3]  R2578     -4.1833803988993168e-03
    z[8,9,3]  R2579     5.4240250587463379e-01
    z[8,9,3]  R2580     4.0116497874259949e-01
    z[8,9,3]  R2581     3.5707205533981323e-01
    z[8,9,3]  R2582     9.5357939600944519e-02
    z[8,9,3]  R2583     1.0043677687644958e-01
    z[8,9,3]  R2584     -3.3724498003721237e-02
    z[8,9,3]  R2585     3.1078770756721497e-01
    z[8,9,3]  R2586     -4.5165005326271057e-01
    z[8,9,3]  R2587     1.4078325033187866e-01
    z[8,9,3]  R2588     -3.4588072448968887e-02
    z[8,9,3]  R2589     -1.2074072659015656e-01
    z[8,9,3]  R2590     2.5519285351037979e-02
    z[8,9,3]  R2591     -5.5568039417266846e-01
    z[8,9,3]  R2592     -1.9025236368179321e-01
    z[8,9,3]  R2593     -2.2748155891895294e-01
    z[8,9,3]  R2594     2.0364774763584137e-01
    z[8,9,3]  R2595     -5.9576690196990967e-01
    z[8,9,3]  R2596     -5.6127548217773438e-01
    z[8,9,3]  R2597     -6.4333927631378174e-01
    z[8,9,3]  R2598     -4.2715385556221008e-01
    z[8,9,3]  R2599     7.4921971559524536e-01
    z[8,9,3]  R2600     -1.9616352021694183e-01
    z[8,9,3]  R2601     1.6831265389919281e-01
    z[8,9,3]  R2602     -6.8378285504877567e-03
    z[8,9,3]  R2603     9.6730358898639679e-02
    z[8,9,3]  R2604     1.3995271921157837e-01
    z[8,9,3]  R2605     -1.4716957509517670e-01
    z[8,9,3]  R2606     1.1623748391866684e-01
    z[8,9,3]  R2607     -1.3191212713718414e-01
    z[8,9,3]  R2608     1.2486474215984344e-01
    z[8,9,3]  R2609     -5.4926581680774689e-02
    z[8,9,3]  R2610     -3.8294005393981934e-01
    z[8,9,3]  R2611     -3.8724753260612488e-01
    z[8,9,3]  R2612     -1.4854340255260468e-01
    z[8,9,3]  R2613     -7.3607891798019409e-02
    z[8,9,3]  R2614     -0.280905157327652
    z[8,9,3]  R2615     -1.0316666215658188e-01
    z[8,9,3]  R2616     3.2250329852104187e-01
    z[8,9,3]  R2617     1.2399671971797943e-01
    z[8,9,4]  R78       -1
    z[8,9,4]  R87       1
    z[8,9,4]  R2538     -1
    z[8,9,4]  R2539     1
    z[8,9,4]  R2544     -7.9225790500640869e-01
    z[8,9,4]  R2545     -6.1505675315856934e-01
    z[8,9,4]  R2546     4.5633900910615921e-02
    z[8,9,4]  R2547     -4.8944196105003357e-01
    z[8,9,4]  R2548     -1.1414247564971447e-03
    z[8,9,4]  R2549     2.5589668750762939e-01
    z[8,9,4]  R2550     -4.3162095546722412e-01
    z[8,9,4]  R2551     -1.5001788735389709e-01
    z[8,9,4]  R2552     -1.7305327951908112e-01
    z[8,9,4]  R2553     1.5978132188320160e-01
    z[8,9,4]  R2554     2.1414557099342346e-01
    z[8,9,4]  R2555     6.1492212116718292e-02
    z[8,9,4]  R2556     7.0217796601355076e-03
    z[8,9,4]  R2557     -1.6406312584877014e-01
    z[8,9,4]  R2558     4.4874947518110275e-02
    z[8,9,4]  R2559     3.5974502563476562e-01
    z[8,9,4]  R2560     1.9913001358509064e-01
    z[8,9,4]  R2561     1.9794845581054688e-01
    z[8,9,4]  R2562     -3.6149136722087860e-02
    z[8,9,4]  R2563     -1.9500473141670227e-01
    z[8,9,4]  R2564     -0.267798513174057
    z[8,9,4]  R2565     1.9431692361831665e-01
    z[8,9,4]  R2566     1.6765825450420380e-01
    z[8,9,4]  R2567     1.2689247727394104e-01
    z[8,9,4]  R2568     2.9101692140102386e-02
    z[8,9,4]  R2569     -1.0317552089691162e-01
    z[8,9,4]  R2570     -3.3634561300277710e-01
    z[8,9,4]  R2571     -2.8721749782562256e-01
    z[8,9,4]  R2572     5.8807837963104248e-01
    z[8,9,4]  R2573     -2.2768768668174744e-01
    z[8,9,4]  R2574     -8.9141465723514557e-03
    z[8,9,4]  R2575     -1.5934322774410248e-01
    z[8,9,4]  R2576     -0.618080198764801
    z[8,9,4]  R2577     2.3450503125786781e-02
    z[8,9,4]  R2578     -5.8210569620132446e-01
    z[8,9,4]  R2579     -4.0888571739196777e-01
    z[8,9,4]  R2580     -6.7335605621337891e-01
    z[8,9,4]  R2581     4.0802329778671265e-01
    z[8,9,4]  R2582     2.3148220032453537e-02
    z[8,9,4]  R2583     4.7486644983291626e-01
    z[8,9,4]  R2584     1.9196658395230770e-03
    z[8,9,4]  R2585     -2.5800400972366333e-01
    z[8,9,4]  R2586     2.5214368104934692e-01
    z[8,9,4]  R2587     -7.0631998777389526e-01
    z[8,9,4]  R2588     -3.7295809388160706e-01
    z[8,9,4]  R2589     2.8939986228942871e-01
    z[8,9,4]  R2590     2.8842580318450928e-01
    z[8,9,4]  R2591     -2.4159426987171173e-01
    z[8,9,4]  R2592     -1.0661655664443970e-01
    z[8,9,4]  R2593     -2.4044224619865417e-01
    z[8,9,4]  R2594     6.5771579742431641e-02
    z[8,9,4]  R2595     -1.4227968454360962e-01
    z[8,9,4]  R2596     -7.1949161589145660e-02
    z[8,9,4]  R2597     -4.2798832058906555e-01
    z[8,9,4]  R2598     -3.4484058618545532e-01
    z[8,9,4]  R2599     4.1967192292213440e-01
    z[8,9,4]  R2600     -0.147585928440094
    z[8,9,4]  R2601     -2.3215298354625702e-01
    z[8,9,4]  R2602     2.6100844144821167e-01
    z[8,9,4]  R2603     -5.4785937070846558e-02
    z[8,9,4]  R2604     -1.7025260627269745e-01
    z[8,9,4]  R2605     2.3434217274188995e-01
    z[8,9,4]  R2606     -1.3723957538604736e-01
    z[8,9,4]  R2607     4.8777997493743896e-02
    z[8,9,4]  R2608     2.6117336750030518e-01
    z[8,9,4]  R2609     -3.1882843375205994e-01
    z[8,9,4]  R2610     -3.8114255666732788e-01
    z[8,9,4]  R2611     -2.6665088534355164e-01
    z[8,9,4]  R2612     -2.0027939975261688e-01
    z[8,9,4]  R2613     -1.7304883897304535e-01
    z[8,9,4]  R2614     -5.3228950500488281e-01
    z[8,9,4]  R2615     -0.00839918851852417
    z[8,9,4]  R2616     2.1437498927116394e-01
    z[8,9,4]  R2617     5.1331651210784912e-01
    z[8,9,5]  R79       -1
    z[8,9,5]  R88       1
    z[8,9,5]  R2540     -1
    z[8,9,5]  R2541     1
    z[8,9,5]  R2544     1.8564743222668767e-03
    z[8,9,5]  R2545     6.1481392383575439e-01
    z[8,9,5]  R2546     2.0107144117355347e-01
    z[8,9,5]  R2547     1.7602321505546570e-01
    z[8,9,5]  R2548     3.4894740581512451e-01
    z[8,9,5]  R2549     -2.5422504171729088e-02
    z[8,9,5]  R2550     -1.0618577152490616e-01
    z[8,9,5]  R2551     -1.5849521756172180e-01
    z[8,9,5]  R2552     -1.7310941219329834e-01
    z[8,9,5]  R2553     -8.9023463428020477e-02
    z[8,9,5]  R2554     -9.8305873572826385e-02
    z[8,9,5]  R2555     1.3046124577522278e-01
    z[8,9,5]  R2556     -4.1442602872848511e-01
    z[8,9,5]  R2557     2.2163568437099457e-01
    z[8,9,5]  R2558     -1.1630660295486450e-01
    z[8,9,5]  R2559     5.1465582847595215e-01
    z[8,9,5]  R2560     2.1447446942329407e-01
    z[8,9,5]  R2561     -7.6004254817962646e-01
    z[8,9,5]  R2562     -6.7631185054779053e-01
    z[8,9,5]  R2563     -0.087654247879982
    z[8,9,5]  R2564     1.2756885588169098e-01
    z[8,9,5]  R2565     3.9423468708992004e-01
    z[8,9,5]  R2566     4.7471120953559875e-02
    z[8,9,5]  R2567     1.8713992834091187e-01
    z[8,9,5]  R2568     6.6836869716644287e-01
    z[8,9,5]  R2569     -4.1208758950233459e-01
    z[8,9,5]  R2570     -4.7995451092720032e-01
    z[8,9,5]  R2571     2.2771118581295013e-01
    z[8,9,5]  R2572     1.2283533066511154e-01
    z[8,9,5]  R2573     -2.7059906721115112e-01
    z[8,9,5]  R2574     2.5053784251213074e-01
    z[8,9,5]  R2575     2.8760612010955811e-01
    z[8,9,5]  R2576     1.5099765360355377e-01
    z[8,9,5]  R2577     7.9561106860637665e-02
    z[8,9,5]  R2578     -2.1995210647583008e-01
    z[8,9,5]  R2579     -1.5352936089038849e-01
    z[8,9,5]  R2580     -5.3045023232698441e-02
    z[8,9,5]  R2581     -6.1002004146575928e-01
    z[8,9,5]  R2582     -0.56720370054245
    z[8,9,5]  R2583     -4.3515142798423767e-01
    z[8,9,5]  R2584     5.0063580274581909e-01
    z[8,9,5]  R2585     -1.9602391123771667e-01
    z[8,9,5]  R2586     2.8628429770469666e-01
    z[8,9,5]  R2587     1.0761862248182297e-01
    z[8,9,5]  R2588     -6.5537005662918091e-01
    z[8,9,5]  R2589     -4.2324599623680115e-01
    z[8,9,5]  R2590     -2.0733886957168579e-01
    z[8,9,5]  R2591     -3.0481913685798645e-01
    z[8,9,5]  R2592     -1.4984667301177979e-01
    z[8,9,5]  R2593     -3.7876769900321960e-01
    z[8,9,5]  R2594     1.1142546683549881e-01
    z[8,9,5]  R2595     1.6161814332008362e-01
    z[8,9,5]  R2596     1.1382610350847244e-01
    z[8,9,5]  R2597     -1.1267782747745514e-01
    z[8,9,5]  R2598     -3.6104604601860046e-01
    z[8,9,5]  R2599     2.3703837394714355e-01
    z[8,9,5]  R2600     -1.6992285847663879e-01
    z[8,9,5]  R2601     -1.0494102537631989e-01
    z[8,9,5]  R2602     -2.7235141023993492e-02
    z[8,9,5]  R2603     -7.3739282786846161e-02
    z[8,9,5]  R2604     5.1846086978912354e-01
    z[8,9,5]  R2605     1.5279792249202728e-01
    z[8,9,5]  R2606     -0.00711454264819622
    z[8,9,5]  R2607     -1.1322123557329178e-01
    z[8,9,5]  R2608     0.275865763425827
    z[8,9,5]  R2609     2.6888754963874817e-01
    z[8,9,5]  R2610     -2.3302617669105530e-01
    z[8,9,5]  R2611     3.9052048325538635e-01
    z[8,9,5]  R2612     -6.3229940831661224e-02
    z[8,9,5]  R2613     6.6179037094116211e-03
    z[8,9,5]  R2614     -0.114285409450531
    z[8,9,5]  R2615     1.0628158599138260e-01
    z[8,9,5]  R2616     1.1328091472387314e-01
    z[8,9,5]  R2617     5.9948820620775223e-02
    z[8,9,6]  R80       -1
    z[8,9,6]  R89       1
    z[8,9,6]  R2542     -1
    z[8,9,6]  R2543     1
    z[8,9,6]  R2544     -2.6477941870689392e-01
    z[8,9,6]  R2545     -3.8045436143875122e-02
    z[8,9,6]  R2546     2.5714330375194550e-02
    z[8,9,6]  R2547     6.9936728477478027e-01
    z[8,9,6]  R2548     -0.666144609451294
    z[8,9,6]  R2549     -3.6283582448959351e-01
    z[8,9,6]  R2550     3.9054048061370850e-01
    z[8,9,6]  R2551     0.774068295955658
    z[8,9,6]  R2552     6.1636292934417725e-01
    z[8,9,6]  R2553     2.7660238742828369e-01
    z[8,9,6]  R2554     -5.1981728523969650e-02
    z[8,9,6]  R2555     -2.8619766235351562e-01
    z[8,9,6]  R2556     -1.4868296682834625e-01
    z[8,9,6]  R2557     -1.1582987010478973e-01
    z[8,9,6]  R2558     3.7121871113777161e-01
    z[8,9,6]  R2559     5.8232326060533524e-02
    z[8,9,6]  R2560     2.6676696538925171e-01
    z[8,9,6]  R2561     3.2086277008056641e-01
    z[8,9,6]  R2562     -4.7210144996643066e-01
    z[8,9,6]  R2563     -1.9453082978725433e-01
    z[8,9,6]  R2564     -5.3848903626203537e-02
    z[8,9,6]  R2565     1.6965794563293457e-01
    z[8,9,6]  R2566     1.7592374980449677e-01
    z[8,9,6]  R2567     -6.8092525005340576e-02
    z[8,9,6]  R2568     -5.4134994745254517e-01
    z[8,9,6]  R2569     3.3255517482757568e-02
    z[8,9,6]  R2570     -4.9123394489288330e-01
    z[8,9,6]  R2571     -3.0253675580024719e-01
    z[8,9,6]  R2572     -2.4402524530887604e-01
    z[8,9,6]  R2573     5.5198359489440918e-01
    z[8,9,6]  R2574     -0.158157616853714
    z[8,9,6]  R2575     -2.8575471043586731e-01
    z[8,9,6]  R2576     -6.5517071634531021e-03
    z[8,9,6]  R2577     4.0439587831497192e-01
    z[8,9,6]  R2578     7.2579854726791382e-01
    z[8,9,6]  R2579     2.6588392257690430e-01
    z[8,9,6]  R2580     3.8882508873939514e-01
    z[8,9,6]  R2581     -1.4881062321364880e-02
    z[8,9,6]  R2582     -1.4949870109558105e-01
    z[8,9,6]  R2583     2.4807748198509216e-01
    z[8,9,6]  R2584     -5.0835594534873962e-02
    z[8,9,6]  R2585     2.5987529754638672e-01
    z[8,9,6]  R2586     3.6881312727928162e-02
    z[8,9,6]  R2587     -5.0899302959442139e-01
    z[8,9,6]  R2588     -5.8440122753381729e-02
    z[8,9,6]  R2589     3.3064281940460205e-01
    z[8,9,6]  R2590     -4.4781979173421860e-02
    z[8,9,6]  R2591     -6.2554776668548584e-02
    z[8,9,6]  R2592     7.2125345468521118e-02
    z[8,9,6]  R2593     3.1975358724594116e-02
    z[8,9,6]  R2594     -2.5159576535224915e-01
    z[8,9,6]  R2595     -1.5411528944969177e-01
    z[8,9,6]  R2596     1.8116460740566254e-01
    z[8,9,6]  R2597     8.7155632674694061e-02
    z[8,9,6]  R2598     2.5628376007080078e-01
    z[8,9,6]  R2599     -8.1337183713912964e-02
    z[8,9,6]  R2600     3.6749577522277832e-01
    z[8,9,6]  R2601     -2.3170365020632744e-02
    z[8,9,6]  R2602     -1.9183224439620972e-01
    z[8,9,6]  R2603     -3.1564655900001526e-01
    z[8,9,6]  R2604     -1.9450746476650238e-01
    z[8,9,6]  R2605     1.0049699246883392e-01
    z[8,9,6]  R2606     -7.6333783566951752e-02
    z[8,9,6]  R2607     0.0470597967505455
    z[8,9,6]  R2608     1.8185776472091675e-01
    z[8,9,6]  R2609     -1.8424183130264282e-02
    z[8,9,6]  R2610     2.0998762547969818e-01
    z[8,9,6]  R2611     -0.0609787218272686
    z[8,9,6]  R2612     1.3025906682014465e-01
    z[8,9,6]  R2613     -3.1629326939582825e-01
    z[8,9,6]  R2614     -1.0128965228796005e-01
    z[8,9,6]  R2615     3.2674354314804077e-01
    z[8,9,6]  R2616     0.0331374928355217
    z[8,9,6]  R2617     0.31126868724823
    z[9,8,0]  R74       1
    z[9,8,0]  R83       -1
    z[9,8,0]  R2618     -1
    z[9,8,0]  R2619     1
    z[9,8,0]  R2632     -1.1683891713619232e-01
    z[9,8,0]  R2633     -7.2481578588485718e-01
    z[9,8,0]  R2634     -7.7795642614364624e-01
    z[9,8,0]  R2635     -4.9626111984252930e-02
    z[9,8,0]  R2636     5.6205615401268005e-02
    z[9,8,0]  R2637     2.8992640972137451e-01
    z[9,8,0]  R2638     2.4261078238487244e-01
    z[9,8,0]  R2639     9.8038287833333015e-03
    z[9,8,0]  R2640     0.440586119890213
    z[9,8,0]  R2641     5.4980188608169556e-01
    z[9,8,0]  R2642     9.0830363333225250e-02
    z[9,8,0]  R2643     4.7096928954124451e-01
    z[9,8,0]  R2644     2.6634064316749573e-01
    z[9,8,0]  R2645     8.6104303598403931e-02
    z[9,8,0]  R2646     3.6794704198837280e-01
    z[9,8,0]  R2647     -1.6276559233665466e-01
    z[9,8,0]  R2648     -1.7888191342353821e-01
    z[9,8,0]  R2649     4.6682957559823990e-02
    z[9,8,0]  R2650     1.5970674157142639e-01
    z[9,8,0]  R2651     -6.7939713597297668e-02
    z[9,8,0]  R2652     -0.0341838039457798
    z[9,8,0]  R2653     2.9439744353294373e-01
    z[9,8,0]  R2654     -1.9379843771457672e-01
    z[9,8,0]  R2655     2.5401732325553894e-01
    z[9,8,0]  R2656     -6.9402478635311127e-02
    z[9,8,0]  R2657     7.1375928819179535e-02
    z[9,8,0]  R2658     1.3114073872566223e-01
    z[9,8,0]  R2659     1.0505028814077377e-01
    z[9,8,0]  R2660     -1.5803864598274231e-01
    z[9,8,0]  R2661     -1.6549913585186005e-01
    z[9,8,0]  R2662     3.6452811956405640e-01
    z[9,8,0]  R2663     -5.6082367897033691e-02
    z[9,8,0]  R2664     3.6245340108871460e-01
    z[9,8,0]  R2665     1.3113540597259998e-02
    z[9,8,0]  R2666     -2.0111629366874695e-01
    z[9,8,0]  R2667     -2.4270208179950714e-01
    z[9,8,0]  R2668     -1.5699948370456696e-01
    z[9,8,0]  R2669     6.6477544605731964e-02
    z[9,8,0]  R2670     -3.5107459407299757e-03
    z[9,8,0]  R2671     2.0591892302036285e-01
    z[9,8,0]  R2672     2.3244784772396088e-01
    z[9,8,0]  R2673     1.2624438107013702e-01
    z[9,8,0]  R2674     2.1336102485656738e-01
    z[9,8,0]  R2675     -9.0435284376144409e-01
    z[9,8,0]  R2676     -7.6551824808120728e-02
    z[9,8,0]  R2677     2.0580536127090454e-01
    z[9,8,0]  R2678     2.4859334528446198e-01
    z[9,8,0]  R2679     3.4582239389419556e-01
    z[9,8,0]  R2680     1.4862895011901855e-01
    z[9,8,0]  R2681     1.0935758799314499e-01
    z[9,8,0]  R2682     -1.6155529022216797e-01
    z[9,8,0]  R2683     1.7433200776576996e-01
    z[9,8,0]  R2684     8.7078690528869629e-02
    z[9,8,0]  R2685     -1.2701866030693054e-01
    z[9,8,0]  R2686     3.0171531438827515e-01
    z[9,8,0]  R2687     7.2028465569019318e-02
    z[9,8,0]  R2688     2.7042636275291443e-01
    z[9,8,0]  R2689     1.6744980216026306e-01
    z[9,8,0]  R2690     -2.9490685090422630e-02
    z[9,8,0]  R2691     9.2251554131507874e-02
    z[9,8,0]  R2692     -1.2892271578311920e-01
    z[9,8,0]  R2693     -2.0086021721363068e-01
    z[9,8,0]  R2694     7.2531960904598236e-02
    z[9,8,0]  R2695     -0.511598527431488
    z[9,8,0]  R2696     -1.0005234181880951e-01
    z[9,8,0]  R2697     1.1733307689428329e-01
    z[9,8,0]  R2698     -4.1857632994651794e-01
    z[9,8,0]  R2699     -6.1898726224899292e-01
    z[9,8,0]  R2700     -1.4537665247917175e-01
    z[9,8,0]  R2701     2.0276996493339539e-01
    z[9,8,0]  R2702     -1.5041647851467133e-01
    z[9,8,0]  R2703     0.306181937456131
    z[9,8,0]  R2704     3.9462804794311523e-01
    z[9,8,0]  R2705     -9.6003890037536621e-02
    z[9,8,1]  R75       1
    z[9,8,1]  R84       -1
    z[9,8,1]  R2620     -1
    z[9,8,1]  R2621     1
    z[9,8,1]  R2632     5.5101519823074341e-01
    z[9,8,1]  R2633     1.3473220169544220e-01
    z[9,8,1]  R2634     1.6858656704425812e-01
    z[9,8,1]  R2635     4.2314249277114868e-01
    z[9,8,1]  R2636     -2.8061237186193466e-02
    z[9,8,1]  R2637     0.714479923248291
    z[9,8,1]  R2638     7.6638185977935791e-01
    z[9,8,1]  R2639     -5.1809144020080566e-01
    z[9,8,1]  R2640     -2.1793937683105469e-01
    z[9,8,1]  R2641     -3.7115550041198730e-01
    z[9,8,1]  R2642     -4.5765072107315063e-01
    z[9,8,1]  R2643     -4.2141985893249512e-01
    z[9,8,1]  R2644     -1.5965756773948669e-01
    z[9,8,1]  R2645     -4.7693407535552979e-01
    z[9,8,1]  R2646     -2.7830743789672852e-01
    z[9,8,1]  R2647     -6.4149700105190277e-02
    z[9,8,1]  R2648     -7.0111477375030518e-01
    z[9,8,1]  R2649     -9.2115324735641479e-01
    z[9,8,1]  R2650     -8.8041067123413086e-01
    z[9,8,1]  R2651     -8.6946618556976318e-01
    z[9,8,1]  R2652     -7.5549733638763428e-01
    z[9,8,1]  R2653     -8.7078070640563965e-01
    z[9,8,1]  R2654     -8.5063123703002930e-01
    z[9,8,1]  R2655     -8.1650906801223755e-01
    z[9,8,1]  R2656     -8.8971352577209473e-01
    z[9,8,1]  R2657     -0.678108274936676
    z[9,8,1]  R2658     -6.2778592109680176e-01
    z[9,8,1]  R2659     -4.3269151449203491e-01
    z[9,8,1]  R2660     -0.902143120765686
    z[9,8,1]  R2661     -8.7095803022384644e-01
    z[9,8,1]  R2662     -6.8296605348587036e-01
    z[9,8,1]  R2663     -3.3892369270324707e-01
    z[9,8,1]  R2664     -7.9935854673385620e-01
    z[9,8,1]  R2665     -7.5542962551116943e-01
    z[9,8,1]  R2666     -1.3025115430355072e-01
    z[9,8,1]  R2667     -1.3317577540874481e-02
    z[9,8,1]  R2668     8.0886083841323853e-01
    z[9,8,1]  R2669     -1.3516566157341003e-01
    z[9,8,1]  R2670     6.5173107385635376e-01
    z[9,8,1]  R2671     3.7668704986572266e-02
    z[9,8,1]  R2672     6.7653638124465942e-01
    z[9,8,1]  R2673     -5.1842797547578812e-02
    z[9,8,1]  R2674     3.4885206818580627e-01
    z[9,8,1]  R2675     -1.1103361099958420e-01
    z[9,8,1]  R2676     -8.3584529161453247e-01
    z[9,8,1]  R2677     -6.5859478712081909e-01
    z[9,8,1]  R2678     -7.1510475873947144e-01
    z[9,8,1]  R2679     1.4314013719558716e-01
    z[9,8,1]  R2680     -8.4134501218795776e-01
    z[9,8,1]  R2681     -6.6101610660552979e-01
    z[9,8,1]  R2682     -8.3556854724884033e-01
    z[9,8,1]  R2683     0.401563823223114
    z[9,8,1]  R2684     1.2806928157806396e-01
    z[9,8,1]  R2685     -6.0899519920349121e-01
    z[9,8,1]  R2686     -3.6122608184814453e-01
    z[9,8,1]  R2687     -2.3939548432826996e-01
    z[9,8,1]  R2688     -3.7896192073822021e-01
    z[9,8,1]  R2689     -4.1848089545965195e-02
    z[9,8,1]  R2690     -3.4122887253761292e-01
    z[9,8,1]  R2691     -8.3733355998992920e-01
    z[9,8,1]  R2692     5.0221151113510132e-01
    z[9,8,1]  R2693     -7.7609074115753174e-01
    z[9,8,1]  R2694     6.2885576486587524e-01
    z[9,8,1]  R2695     0.226348876953125
    z[9,8,1]  R2696     -8.7646156549453735e-01
    z[9,8,1]  R2697     3.5217535495758057e-01
    z[9,8,1]  R2698     -3.4532102942466736e-01
    z[9,8,1]  R2699     -4.8880180716514587e-01
    z[9,8,1]  R2700     -0.170157328248024
    z[9,8,1]  R2701     6.2894034385681152e-01
    z[9,8,1]  R2702     -4.3408384919166565e-01
    z[9,8,1]  R2703     4.6868675947189331e-01
    z[9,8,1]  R2704     5.8811980485916138e-01
    z[9,8,1]  R2705     -1.9644196331501007e-01
    z[9,8,2]  R76       1
    z[9,8,2]  R85       -1
    z[9,8,2]  R2622     -1
    z[9,8,2]  R2623     1
    z[9,8,2]  R2632     6.5449941158294678e-01
    z[9,8,2]  R2633     -4.3286693096160889e-01
    z[9,8,2]  R2634     1.2441541254520416e-01
    z[9,8,2]  R2635     -1.7065811157226562e-01
    z[9,8,2]  R2636     6.5025717020034790e-01
    z[9,8,2]  R2637     -1.3663330674171448e-01
    z[9,8,2]  R2638     4.7430303692817688e-01
    z[9,8,2]  R2639     -5.1721256971359253e-01
    z[9,8,2]  R2640     -8.2653927803039551e-01
    z[9,8,2]  R2641     -0.553094744682312
    z[9,8,2]  R2642     -8.1289076805114746e-01
    z[9,8,2]  R2643     -4.1897448897361755e-01
    z[9,8,2]  R2644     -7.3320406675338745e-01
    z[9,8,2]  R2645     -3.8440600037574768e-01
    z[9,8,2]  R2646     -5.3828316926956177e-01
    z[9,8,2]  R2647     4.1125959157943726e-01
    z[9,8,2]  R2648     -5.0224578380584717e-01
    z[9,8,2]  R2649     -0.235634446144104
    z[9,8,2]  R2650     3.0603477358818054e-01
    z[9,8,2]  R2651     3.4926262497901917e-01
    z[9,8,2]  R2652     -2.6990300416946411e-01
    z[9,8,2]  R2653     2.1224774420261383e-01
    z[9,8,2]  R2654     4.4793450832366943e-01
    z[9,8,2]  R2655     4.8370894789695740e-01
    z[9,8,2]  R2656     -1.0303554683923721e-01
    z[9,8,2]  R2657     -5.9813553094863892e-01
    z[9,8,2]  R2658     -4.4539690017700195e-01
    z[9,8,2]  R2659     -6.5150165557861328e-01
    z[9,8,2]  R2660     -2.7931925654411316e-01
    z[9,8,2]  R2661     -2.8034433722496033e-01
    z[9,8,2]  R2662     -1.2294710427522659e-01
    z[9,8,2]  R2663     -8.6787927150726318e-01
    z[9,8,2]  R2664     2.5643259286880493e-01
    z[9,8,2]  R2665     2.2316598892211914e-01
    z[9,8,2]  R2666     -2.7533471584320068e-01
    z[9,8,2]  R2667     -2.6543724536895752e-01
    z[9,8,2]  R2668     5.1782506704330444e-01
    z[9,8,2]  R2669     -3.1296011805534363e-01
    z[9,8,2]  R2670     -9.8057903349399567e-02
    z[9,8,2]  R2671     -6.3203227519989014e-01
    z[9,8,2]  R2672     -3.2391190528869629e-01
    z[9,8,2]  R2673     -3.6273059248924255e-01
    z[9,8,2]  R2674     5.2638594061136246e-02
    z[9,8,2]  R2675     1.6446973383426666e-01
    z[9,8,2]  R2676     -4.7788426280021667e-01
    z[9,8,2]  R2677     -4.3715590238571167e-01
    z[9,8,2]  R2678     -4.0727302432060242e-01
    z[9,8,2]  R2679     -5.4799216985702515e-01
    z[9,8,2]  R2680     -3.0662044882774353e-01
    z[9,8,2]  R2681     -3.7563818693161011e-01
    z[9,8,2]  R2682     6.4522060565650463e-03
    z[9,8,2]  R2683     1.0601682215929031e-01
    z[9,8,2]  R2684     2.8027918934822083e-01
    z[9,8,2]  R2685     7.2129350900650024e-01
    z[9,8,2]  R2686     -7.6573336124420166e-01
    z[9,8,2]  R2687     -8.0364304780960083e-01
    z[9,8,2]  R2688     -7.5284171104431152e-01
    z[9,8,2]  R2689     -7.0482075214385986e-01
    z[9,8,2]  R2690     -3.6790904402732849e-01
    z[9,8,2]  R2691     -3.1498628854751587e-01
    z[9,8,2]  R2692     3.7793284654617310e-01
    z[9,8,2]  R2693     8.5784226655960083e-02
    z[9,8,2]  R2694     7.4811629019677639e-03
    z[9,8,2]  R2695     -5.0689816474914551e-01
    z[9,8,2]  R2696     -2.7843010425567627e-01
    z[9,8,2]  R2697     -6.5639001131057739e-01
    z[9,8,2]  R2698     -1.6937333345413208e-01
    z[9,8,2]  R2699     -3.5882163047790527e-01
    z[9,8,2]  R2700     -1.8943351507186890e-01
    z[9,8,2]  R2701     -0.0875493511557579
    z[9,8,2]  R2702     1.4354649186134338e-01
    z[9,8,2]  R2703     1.4232377707958221e-01
    z[9,8,2]  R2704     -3.8037461042404175e-01
    z[9,8,2]  R2705     0.682428777217865
    z[9,8,3]  R77       1
    z[9,8,3]  R86       -1
    z[9,8,3]  R2624     -1
    z[9,8,3]  R2625     1
    z[9,8,3]  R2632     -3.3724498003721237e-02
    z[9,8,3]  R2633     3.1078770756721497e-01
    z[9,8,3]  R2634     -4.5165005326271057e-01
    z[9,8,3]  R2635     1.4078325033187866e-01
    z[9,8,3]  R2636     -3.4588072448968887e-02
    z[9,8,3]  R2637     -1.2074072659015656e-01
    z[9,8,3]  R2638     2.5519285351037979e-02
    z[9,8,3]  R2639     -5.5568039417266846e-01
    z[9,8,3]  R2640     -1.9025236368179321e-01
    z[9,8,3]  R2641     -2.2748155891895294e-01
    z[9,8,3]  R2642     2.0364774763584137e-01
    z[9,8,3]  R2643     -5.9576690196990967e-01
    z[9,8,3]  R2644     -5.6127548217773438e-01
    z[9,8,3]  R2645     -6.4333927631378174e-01
    z[9,8,3]  R2646     -4.2715385556221008e-01
    z[9,8,3]  R2647     7.4921971559524536e-01
    z[9,8,3]  R2648     -1.9616352021694183e-01
    z[9,8,3]  R2649     1.6831265389919281e-01
    z[9,8,3]  R2650     -6.8378285504877567e-03
    z[9,8,3]  R2651     9.6730358898639679e-02
    z[9,8,3]  R2652     1.3995271921157837e-01
    z[9,8,3]  R2653     -1.4716957509517670e-01
    z[9,8,3]  R2654     1.1623748391866684e-01
    z[9,8,3]  R2655     -1.3191212713718414e-01
    z[9,8,3]  R2656     1.2486474215984344e-01
    z[9,8,3]  R2657     -5.4926581680774689e-02
    z[9,8,3]  R2658     -3.8294005393981934e-01
    z[9,8,3]  R2659     -3.8724753260612488e-01
    z[9,8,3]  R2660     -1.4854340255260468e-01
    z[9,8,3]  R2661     -7.3607891798019409e-02
    z[9,8,3]  R2662     -0.280905157327652
    z[9,8,3]  R2663     -1.0316666215658188e-01
    z[9,8,3]  R2664     3.2250329852104187e-01
    z[9,8,3]  R2665     1.2399671971797943e-01
    z[9,8,3]  R2666     -4.1108828783035278e-01
    z[9,8,3]  R2667     -3.3574259281158447e-01
    z[9,8,3]  R2668     0.098890021443367
    z[9,8,3]  R2669     3.4599813818931580e-01
    z[9,8,3]  R2670     1.0233910754323006e-02
    z[9,8,3]  R2671     -5.9911131858825684e-01
    z[9,8,3]  R2672     1.8235588073730469e-01
    z[9,8,3]  R2673     -4.5054781436920166e-01
    z[9,8,3]  R2674     6.2465268373489380e-01
    z[9,8,3]  R2675     -1.8111613392829895e-01
    z[9,8,3]  R2676     9.4365149736404419e-02
    z[9,8,3]  R2677     4.7966772317886353e-01
    z[9,8,3]  R2678     2.5894096493721008e-01
    z[9,8,3]  R2679     6.8568712472915649e-01
    z[9,8,3]  R2680     1.5062336623668671e-01
    z[9,8,3]  R2681     1.1097923666238785e-01
    z[9,8,3]  R2682     -0.344770610332489
    z[9,8,3]  R2683     -2.7805429697036743e-01
    z[9,8,3]  R2684     4.6462345123291016e-01
    z[9,8,3]  R2685     0.0957830622792244
    z[9,8,3]  R2686     3.1819251179695129e-01
    z[9,8,3]  R2687     -2.6399964094161987e-01
    z[9,8,3]  R2688     -3.9392209053039551e-01
    z[9,8,3]  R2689     -6.4627963304519653e-01
    z[9,8,3]  R2690     8.1930831074714661e-02
    z[9,8,3]  R2691     -9.7869694232940674e-02
    z[9,8,3]  R2692     5.9446100145578384e-02
    z[9,8,3]  R2693     3.5228466987609863e-01
    z[9,8,3]  R2694     -4.2278897762298584e-01
    z[9,8,3]  R2695     1.8325652927160263e-02
    z[9,8,3]  R2696     -2.3752617835998535e-01
    z[9,8,3]  R2697     -4.9152252078056335e-01
    z[9,8,3]  R2698     5.2153009176254272e-01
    z[9,8,3]  R2699     -2.8063976764678955e-01
    z[9,8,3]  R2700     -4.1833803988993168e-03
    z[9,8,3]  R2701     5.4240250587463379e-01
    z[9,8,3]  R2702     4.0116497874259949e-01
    z[9,8,3]  R2703     3.5707205533981323e-01
    z[9,8,3]  R2704     9.5357939600944519e-02
    z[9,8,3]  R2705     1.0043677687644958e-01
    z[9,8,4]  R78       1
    z[9,8,4]  R87       -1
    z[9,8,4]  R2626     -1
    z[9,8,4]  R2627     1
    z[9,8,4]  R2632     1.9196658395230770e-03
    z[9,8,4]  R2633     -2.5800400972366333e-01
    z[9,8,4]  R2634     2.5214368104934692e-01
    z[9,8,4]  R2635     -7.0631998777389526e-01
    z[9,8,4]  R2636     -3.7295809388160706e-01
    z[9,8,4]  R2637     2.8939986228942871e-01
    z[9,8,4]  R2638     2.8842580318450928e-01
    z[9,8,4]  R2639     -2.4159426987171173e-01
    z[9,8,4]  R2640     -1.0661655664443970e-01
    z[9,8,4]  R2641     -2.4044224619865417e-01
    z[9,8,4]  R2642     6.5771579742431641e-02
    z[9,8,4]  R2643     -1.4227968454360962e-01
    z[9,8,4]  R2644     -7.1949161589145660e-02
    z[9,8,4]  R2645     -4.2798832058906555e-01
    z[9,8,4]  R2646     -3.4484058618545532e-01
    z[9,8,4]  R2647     4.1967192292213440e-01
    z[9,8,4]  R2648     -0.147585928440094
    z[9,8,4]  R2649     -2.3215298354625702e-01
    z[9,8,4]  R2650     2.6100844144821167e-01
    z[9,8,4]  R2651     -5.4785937070846558e-02
    z[9,8,4]  R2652     -1.7025260627269745e-01
    z[9,8,4]  R2653     2.3434217274188995e-01
    z[9,8,4]  R2654     -1.3723957538604736e-01
    z[9,8,4]  R2655     4.8777997493743896e-02
    z[9,8,4]  R2656     2.6117336750030518e-01
    z[9,8,4]  R2657     -3.1882843375205994e-01
    z[9,8,4]  R2658     -3.8114255666732788e-01
    z[9,8,4]  R2659     -2.6665088534355164e-01
    z[9,8,4]  R2660     -2.0027939975261688e-01
    z[9,8,4]  R2661     -1.7304883897304535e-01
    z[9,8,4]  R2662     -5.3228950500488281e-01
    z[9,8,4]  R2663     -0.00839918851852417
    z[9,8,4]  R2664     2.1437498927116394e-01
    z[9,8,4]  R2665     5.1331651210784912e-01
    z[9,8,4]  R2666     -7.9225790500640869e-01
    z[9,8,4]  R2667     -6.1505675315856934e-01
    z[9,8,4]  R2668     4.5633900910615921e-02
    z[9,8,4]  R2669     -4.8944196105003357e-01
    z[9,8,4]  R2670     -1.1414247564971447e-03
    z[9,8,4]  R2671     2.5589668750762939e-01
    z[9,8,4]  R2672     -4.3162095546722412e-01
    z[9,8,4]  R2673     -1.5001788735389709e-01
    z[9,8,4]  R2674     -1.7305327951908112e-01
    z[9,8,4]  R2675     1.5978132188320160e-01
    z[9,8,4]  R2676     2.1414557099342346e-01
    z[9,8,4]  R2677     6.1492212116718292e-02
    z[9,8,4]  R2678     7.0217796601355076e-03
    z[9,8,4]  R2679     -1.6406312584877014e-01
    z[9,8,4]  R2680     4.4874947518110275e-02
    z[9,8,4]  R2681     3.5974502563476562e-01
    z[9,8,4]  R2682     1.9913001358509064e-01
    z[9,8,4]  R2683     1.9794845581054688e-01
    z[9,8,4]  R2684     -3.6149136722087860e-02
    z[9,8,4]  R2685     -1.9500473141670227e-01
    z[9,8,4]  R2686     -0.267798513174057
    z[9,8,4]  R2687     1.9431692361831665e-01
    z[9,8,4]  R2688     1.6765825450420380e-01
    z[9,8,4]  R2689     1.2689247727394104e-01
    z[9,8,4]  R2690     2.9101692140102386e-02
    z[9,8,4]  R2691     -1.0317552089691162e-01
    z[9,8,4]  R2692     -3.3634561300277710e-01
    z[9,8,4]  R2693     -2.8721749782562256e-01
    z[9,8,4]  R2694     5.8807837963104248e-01
    z[9,8,4]  R2695     -2.2768768668174744e-01
    z[9,8,4]  R2696     -8.9141465723514557e-03
    z[9,8,4]  R2697     -1.5934322774410248e-01
    z[9,8,4]  R2698     -0.618080198764801
    z[9,8,4]  R2699     2.3450503125786781e-02
    z[9,8,4]  R2700     -5.8210569620132446e-01
    z[9,8,4]  R2701     -4.0888571739196777e-01
    z[9,8,4]  R2702     -6.7335605621337891e-01
    z[9,8,4]  R2703     4.0802329778671265e-01
    z[9,8,4]  R2704     2.3148220032453537e-02
    z[9,8,4]  R2705     4.7486644983291626e-01
    z[9,8,5]  R79       1
    z[9,8,5]  R88       -1
    z[9,8,5]  R2628     -1
    z[9,8,5]  R2629     1
    z[9,8,5]  R2632     5.0063580274581909e-01
    z[9,8,5]  R2633     -1.9602391123771667e-01
    z[9,8,5]  R2634     2.8628429770469666e-01
    z[9,8,5]  R2635     1.0761862248182297e-01
    z[9,8,5]  R2636     -6.5537005662918091e-01
    z[9,8,5]  R2637     -4.2324599623680115e-01
    z[9,8,5]  R2638     -2.0733886957168579e-01
    z[9,8,5]  R2639     -3.0481913685798645e-01
    z[9,8,5]  R2640     -1.4984667301177979e-01
    z[9,8,5]  R2641     -3.7876769900321960e-01
    z[9,8,5]  R2642     1.1142546683549881e-01
    z[9,8,5]  R2643     1.6161814332008362e-01
    z[9,8,5]  R2644     1.1382610350847244e-01
    z[9,8,5]  R2645     -1.1267782747745514e-01
    z[9,8,5]  R2646     -3.6104604601860046e-01
    z[9,8,5]  R2647     2.3703837394714355e-01
    z[9,8,5]  R2648     -1.6992285847663879e-01
    z[9,8,5]  R2649     -1.0494102537631989e-01
    z[9,8,5]  R2650     -2.7235141023993492e-02
    z[9,8,5]  R2651     -7.3739282786846161e-02
    z[9,8,5]  R2652     5.1846086978912354e-01
    z[9,8,5]  R2653     1.5279792249202728e-01
    z[9,8,5]  R2654     -0.00711454264819622
    z[9,8,5]  R2655     -1.1322123557329178e-01
    z[9,8,5]  R2656     0.275865763425827
    z[9,8,5]  R2657     2.6888754963874817e-01
    z[9,8,5]  R2658     -2.3302617669105530e-01
    z[9,8,5]  R2659     3.9052048325538635e-01
    z[9,8,5]  R2660     -6.3229940831661224e-02
    z[9,8,5]  R2661     6.6179037094116211e-03
    z[9,8,5]  R2662     -0.114285409450531
    z[9,8,5]  R2663     1.0628158599138260e-01
    z[9,8,5]  R2664     1.1328091472387314e-01
    z[9,8,5]  R2665     5.9948820620775223e-02
    z[9,8,5]  R2666     1.8564743222668767e-03
    z[9,8,5]  R2667     6.1481392383575439e-01
    z[9,8,5]  R2668     2.0107144117355347e-01
    z[9,8,5]  R2669     1.7602321505546570e-01
    z[9,8,5]  R2670     3.4894740581512451e-01
    z[9,8,5]  R2671     -2.5422504171729088e-02
    z[9,8,5]  R2672     -1.0618577152490616e-01
    z[9,8,5]  R2673     -1.5849521756172180e-01
    z[9,8,5]  R2674     -1.7310941219329834e-01
    z[9,8,5]  R2675     -8.9023463428020477e-02
    z[9,8,5]  R2676     -9.8305873572826385e-02
    z[9,8,5]  R2677     1.3046124577522278e-01
    z[9,8,5]  R2678     -4.1442602872848511e-01
    z[9,8,5]  R2679     2.2163568437099457e-01
    z[9,8,5]  R2680     -1.1630660295486450e-01
    z[9,8,5]  R2681     5.1465582847595215e-01
    z[9,8,5]  R2682     2.1447446942329407e-01
    z[9,8,5]  R2683     -7.6004254817962646e-01
    z[9,8,5]  R2684     -6.7631185054779053e-01
    z[9,8,5]  R2685     -0.087654247879982
    z[9,8,5]  R2686     1.2756885588169098e-01
    z[9,8,5]  R2687     3.9423468708992004e-01
    z[9,8,5]  R2688     4.7471120953559875e-02
    z[9,8,5]  R2689     1.8713992834091187e-01
    z[9,8,5]  R2690     6.6836869716644287e-01
    z[9,8,5]  R2691     -4.1208758950233459e-01
    z[9,8,5]  R2692     -4.7995451092720032e-01
    z[9,8,5]  R2693     2.2771118581295013e-01
    z[9,8,5]  R2694     1.2283533066511154e-01
    z[9,8,5]  R2695     -2.7059906721115112e-01
    z[9,8,5]  R2696     2.5053784251213074e-01
    z[9,8,5]  R2697     2.8760612010955811e-01
    z[9,8,5]  R2698     1.5099765360355377e-01
    z[9,8,5]  R2699     7.9561106860637665e-02
    z[9,8,5]  R2700     -2.1995210647583008e-01
    z[9,8,5]  R2701     -1.5352936089038849e-01
    z[9,8,5]  R2702     -5.3045023232698441e-02
    z[9,8,5]  R2703     -6.1002004146575928e-01
    z[9,8,5]  R2704     -0.56720370054245
    z[9,8,5]  R2705     -4.3515142798423767e-01
    z[9,8,6]  R80       1
    z[9,8,6]  R89       -1
    z[9,8,6]  R2630     -1
    z[9,8,6]  R2631     1
    z[9,8,6]  R2632     -5.0835594534873962e-02
    z[9,8,6]  R2633     2.5987529754638672e-01
    z[9,8,6]  R2634     3.6881312727928162e-02
    z[9,8,6]  R2635     -5.0899302959442139e-01
    z[9,8,6]  R2636     -5.8440122753381729e-02
    z[9,8,6]  R2637     3.3064281940460205e-01
    z[9,8,6]  R2638     -4.4781979173421860e-02
    z[9,8,6]  R2639     -6.2554776668548584e-02
    z[9,8,6]  R2640     7.2125345468521118e-02
    z[9,8,6]  R2641     3.1975358724594116e-02
    z[9,8,6]  R2642     -2.5159576535224915e-01
    z[9,8,6]  R2643     -1.5411528944969177e-01
    z[9,8,6]  R2644     1.8116460740566254e-01
    z[9,8,6]  R2645     8.7155632674694061e-02
    z[9,8,6]  R2646     2.5628376007080078e-01
    z[9,8,6]  R2647     -8.1337183713912964e-02
    z[9,8,6]  R2648     3.6749577522277832e-01
    z[9,8,6]  R2649     -2.3170365020632744e-02
    z[9,8,6]  R2650     -1.9183224439620972e-01
    z[9,8,6]  R2651     -3.1564655900001526e-01
    z[9,8,6]  R2652     -1.9450746476650238e-01
    z[9,8,6]  R2653     1.0049699246883392e-01
    z[9,8,6]  R2654     -7.6333783566951752e-02
    z[9,8,6]  R2655     0.0470597967505455
    z[9,8,6]  R2656     1.8185776472091675e-01
    z[9,8,6]  R2657     -1.8424183130264282e-02
    z[9,8,6]  R2658     2.0998762547969818e-01
    z[9,8,6]  R2659     -0.0609787218272686
    z[9,8,6]  R2660     1.3025906682014465e-01
    z[9,8,6]  R2661     -3.1629326939582825e-01
    z[9,8,6]  R2662     -1.0128965228796005e-01
    z[9,8,6]  R2663     3.2674354314804077e-01
    z[9,8,6]  R2664     0.0331374928355217
    z[9,8,6]  R2665     0.31126868724823
    z[9,8,6]  R2666     -2.6477941870689392e-01
    z[9,8,6]  R2667     -3.8045436143875122e-02
    z[9,8,6]  R2668     2.5714330375194550e-02
    z[9,8,6]  R2669     6.9936728477478027e-01
    z[9,8,6]  R2670     -0.666144609451294
    z[9,8,6]  R2671     -3.6283582448959351e-01
    z[9,8,6]  R2672     3.9054048061370850e-01
    z[9,8,6]  R2673     0.774068295955658
    z[9,8,6]  R2674     6.1636292934417725e-01
    z[9,8,6]  R2675     2.7660238742828369e-01
    z[9,8,6]  R2676     -5.1981728523969650e-02
    z[9,8,6]  R2677     -2.8619766235351562e-01
    z[9,8,6]  R2678     -1.4868296682834625e-01
    z[9,8,6]  R2679     -1.1582987010478973e-01
    z[9,8,6]  R2680     3.7121871113777161e-01
    z[9,8,6]  R2681     5.8232326060533524e-02
    z[9,8,6]  R2682     2.6676696538925171e-01
    z[9,8,6]  R2683     3.2086277008056641e-01
    z[9,8,6]  R2684     -4.7210144996643066e-01
    z[9,8,6]  R2685     -1.9453082978725433e-01
    z[9,8,6]  R2686     -5.3848903626203537e-02
    z[9,8,6]  R2687     1.6965794563293457e-01
    z[9,8,6]  R2688     1.7592374980449677e-01
    z[9,8,6]  R2689     -6.8092525005340576e-02
    z[9,8,6]  R2690     -5.4134994745254517e-01
    z[9,8,6]  R2691     3.3255517482757568e-02
    z[9,8,6]  R2692     -4.9123394489288330e-01
    z[9,8,6]  R2693     -3.0253675580024719e-01
    z[9,8,6]  R2694     -2.4402524530887604e-01
    z[9,8,6]  R2695     5.5198359489440918e-01
    z[9,8,6]  R2696     -0.158157616853714
    z[9,8,6]  R2697     -2.8575471043586731e-01
    z[9,8,6]  R2698     -6.5517071634531021e-03
    z[9,8,6]  R2699     4.0439587831497192e-01
    z[9,8,6]  R2700     7.2579854726791382e-01
    z[9,8,6]  R2701     2.6588392257690430e-01
    z[9,8,6]  R2702     3.8882508873939514e-01
    z[9,8,6]  R2703     -1.4881062321364880e-02
    z[9,8,6]  R2704     -1.4949870109558105e-01
    z[9,8,6]  R2705     2.4807748198509216e-01
    length[0]  OBJ       1
    length[1]  OBJ       1
    length[2]  OBJ       1
    length[3]  OBJ       1
    length[4]  OBJ       1
    length[5]  OBJ       1
    length[6]  OBJ       1
    length[7]  OBJ       1
    length[8]  OBJ       1
    length[9]  OBJ       1
    delta[0,0]  R2        1
    delta[0,1]  R3        1
    delta[0,2]  R4        1
    delta[0,3]  R5        1
    delta[0,4]  R6        1
    delta[0,5]  R7        1
    delta[0,6]  R8        1
    delta[1,0]  R11       1
    delta[1,1]  R12       1
    delta[1,2]  R13       1
    delta[1,3]  R14       1
    delta[1,4]  R15       1
    delta[1,5]  R16       1
    delta[1,6]  R17       1
    delta[2,0]  R20       1
    delta[2,1]  R21       1
    delta[2,2]  R22       1
    delta[2,3]  R23       1
    delta[2,4]  R24       1
    delta[2,5]  R25       1
    delta[2,6]  R26       1
    delta[3,0]  R29       1
    delta[3,1]  R30       1
    delta[3,2]  R31       1
    delta[3,3]  R32       1
    delta[3,4]  R33       1
    delta[3,5]  R34       1
    delta[3,6]  R35       1
    delta[4,0]  R38       1
    delta[4,1]  R39       1
    delta[4,2]  R40       1
    delta[4,3]  R41       1
    delta[4,4]  R42       1
    delta[4,5]  R43       1
    delta[4,6]  R44       1
    delta[5,0]  R47       1
    delta[5,1]  R48       1
    delta[5,2]  R49       1
    delta[5,3]  R50       1
    delta[5,4]  R51       1
    delta[5,5]  R52       1
    delta[5,6]  R53       1
    delta[6,0]  R56       1
    delta[6,1]  R57       1
    delta[6,2]  R58       1
    delta[6,3]  R59       1
    delta[6,4]  R60       1
    delta[6,5]  R61       1
    delta[6,6]  R62       1
    delta[7,0]  R65       1
    delta[7,1]  R66       1
    delta[7,2]  R67       1
    delta[7,3]  R68       1
    delta[7,4]  R69       1
    delta[7,5]  R70       1
    delta[7,6]  R71       1
    delta[8,0]  R74       1
    delta[8,1]  R75       1
    delta[8,2]  R76       1
    delta[8,3]  R77       1
    delta[8,4]  R78       1
    delta[8,5]  R79       1
    delta[8,6]  R80       1
    delta[9,0]  R83       1
    delta[9,1]  R84       1
    delta[9,2]  R85       1
    delta[9,3]  R86       1
    delta[9,4]  R87       1
    delta[9,5]  R88       1
    delta[9,6]  R89       1
RHS
    RHS1      R1        1
    RHS1      R10       1
    RHS1      R19       1
    RHS1      R28       1
    RHS1      R37       1
    RHS1      R46       1
    RHS1      R55       1
    RHS1      R64       1
    RHS1      R73       1
    RHS1      R82       1
    RHS1      R90       1
    RHS1      R91       -1
BOUNDS
 BV BND1      phi[0,1]
 BV BND1      phi[1,0]
 BV BND1      phi[0,5]
 BV BND1      phi[5,0]
 BV BND1      phi[10,0]
 BV BND1      phi[1,2]
 BV BND1      phi[2,1]
 BV BND1      phi[2,3]
 BV BND1      phi[3,2]
 BV BND1      phi[3,4]
 BV BND1      phi[4,3]
 BV BND1      phi[4,9]
 BV BND1      phi[9,4]
 BV BND1      phi[4,11]
 BV BND1      phi[5,6]
 BV BND1      phi[6,5]
 BV BND1      phi[5,7]
 BV BND1      phi[7,5]
 BV BND1      phi[10,5]
 BV BND1      phi[6,7]
 BV BND1      phi[7,6]
 BV BND1      phi[7,8]
 BV BND1      phi[8,7]
 BV BND1      phi[8,9]
 BV BND1      phi[9,8]
 BV BND1      phi[9,11]
 FR BND1      z[0,1,0]
 FR BND1      z[0,1,1]
 FR BND1      z[0,1,2]
 FR BND1      z[0,1,3]
 FR BND1      z[0,1,4]
 FR BND1      z[0,1,5]
 FR BND1      z[0,1,6]
 FR BND1      z[1,0,0]
 FR BND1      z[1,0,1]
 FR BND1      z[1,0,2]
 FR BND1      z[1,0,3]
 FR BND1      z[1,0,4]
 FR BND1      z[1,0,5]
 FR BND1      z[1,0,6]
 FR BND1      z[0,5,0]
 FR BND1      z[0,5,1]
 FR BND1      z[0,5,2]
 FR BND1      z[0,5,3]
 FR BND1      z[0,5,4]
 FR BND1      z[0,5,5]
 FR BND1      z[0,5,6]
 FR BND1      z[5,0,0]
 FR BND1      z[5,0,1]
 FR BND1      z[5,0,2]
 FR BND1      z[5,0,3]
 FR BND1      z[5,0,4]
 FR BND1      z[5,0,5]
 FR BND1      z[5,0,6]
 FR BND1      z[1,2,0]
 FR BND1      z[1,2,1]
 FR BND1      z[1,2,2]
 FR BND1      z[1,2,3]
 FR BND1      z[1,2,4]
 FR BND1      z[1,2,5]
 FR BND1      z[1,2,6]
 FR BND1      z[2,1,0]
 FR BND1      z[2,1,1]
 FR BND1      z[2,1,2]
 FR BND1      z[2,1,3]
 FR BND1      z[2,1,4]
 FR BND1      z[2,1,5]
 FR BND1      z[2,1,6]
 FR BND1      z[2,3,0]
 FR BND1      z[2,3,1]
 FR BND1      z[2,3,2]
 FR BND1      z[2,3,3]
 FR BND1      z[2,3,4]
 FR BND1      z[2,3,5]
 FR BND1      z[2,3,6]
 FR BND1      z[3,2,0]
 FR BND1      z[3,2,1]
 FR BND1      z[3,2,2]
 FR BND1      z[3,2,3]
 FR BND1      z[3,2,4]
 FR BND1      z[3,2,5]
 FR BND1      z[3,2,6]
 FR BND1      z[3,4,0]
 FR BND1      z[3,4,1]
 FR BND1      z[3,4,2]
 FR BND1      z[3,4,3]
 FR BND1      z[3,4,4]
 FR BND1      z[3,4,5]
 FR BND1      z[3,4,6]
 FR BND1      z[4,3,0]
 FR BND1      z[4,3,1]
 FR BND1      z[4,3,2]
 FR BND1      z[4,3,3]
 FR BND1      z[4,3,4]
 FR BND1      z[4,3,5]
 FR BND1      z[4,3,6]
 FR BND1      z[4,9,0]
 FR BND1      z[4,9,1]
 FR BND1      z[4,9,2]
 FR BND1      z[4,9,3]
 FR BND1      z[4,9,4]
 FR BND1      z[4,9,5]
 FR BND1      z[4,9,6]
 FR BND1      z[9,4,0]
 FR BND1      z[9,4,1]
 FR BND1      z[9,4,2]
 FR BND1      z[9,4,3]
 FR BND1      z[9,4,4]
 FR BND1      z[9,4,5]
 FR BND1      z[9,4,6]
 FR BND1      z[5,6,0]
 FR BND1      z[5,6,1]
 FR BND1      z[5,6,2]
 FR BND1      z[5,6,3]
 FR BND1      z[5,6,4]
 FR BND1      z[5,6,5]
 FR BND1      z[5,6,6]
 FR BND1      z[6,5,0]
 FR BND1      z[6,5,1]
 FR BND1      z[6,5,2]
 FR BND1      z[6,5,3]
 FR BND1      z[6,5,4]
 FR BND1      z[6,5,5]
 FR BND1      z[6,5,6]
 FR BND1      z[5,7,0]
 FR BND1      z[5,7,1]
 FR BND1      z[5,7,2]
 FR BND1      z[5,7,3]
 FR BND1      z[5,7,4]
 FR BND1      z[5,7,5]
 FR BND1      z[5,7,6]
 FR BND1      z[7,5,0]
 FR BND1      z[7,5,1]
 FR BND1      z[7,5,2]
 FR BND1      z[7,5,3]
 FR BND1      z[7,5,4]
 FR BND1      z[7,5,5]
 FR BND1      z[7,5,6]
 FR BND1      z[6,7,0]
 FR BND1      z[6,7,1]
 FR BND1      z[6,7,2]
 FR BND1      z[6,7,3]
 FR BND1      z[6,7,4]
 FR BND1      z[6,7,5]
 FR BND1      z[6,7,6]
 FR BND1      z[7,6,0]
 FR BND1      z[7,6,1]
 FR BND1      z[7,6,2]
 FR BND1      z[7,6,3]
 FR BND1      z[7,6,4]
 FR BND1      z[7,6,5]
 FR BND1      z[7,6,6]
 FR BND1      z[7,8,0]
 FR BND1      z[7,8,1]
 FR BND1      z[7,8,2]
 FR BND1      z[7,8,3]
 FR BND1      z[7,8,4]
 FR BND1      z[7,8,5]
 FR BND1      z[7,8,6]
 FR BND1      z[8,7,0]
 FR BND1      z[8,7,1]
 FR BND1      z[8,7,2]
 FR BND1      z[8,7,3]
 FR BND1      z[8,7,4]
 FR BND1      z[8,7,5]
 FR BND1      z[8,7,6]
 FR BND1      z[8,9,0]
 FR BND1      z[8,9,1]
 FR BND1      z[8,9,2]
 FR BND1      z[8,9,3]
 FR BND1      z[8,9,4]
 FR BND1      z[8,9,5]
 FR BND1      z[8,9,6]
 FR BND1      z[9,8,0]
 FR BND1      z[9,8,1]
 FR BND1      z[9,8,2]
 FR BND1      z[9,8,3]
 FR BND1      z[9,8,4]
 FR BND1      z[9,8,5]
 FR BND1      z[9,8,6]
 FR BND1      delta[0,0]
 FR BND1      delta[0,1]
 FR BND1      delta[0,2]
 FR BND1      delta[0,3]
 FR BND1      delta[0,4]
 FR BND1      delta[0,5]
 FR BND1      delta[0,6]
 FR BND1      delta[1,0]
 FR BND1      delta[1,1]
 FR BND1      delta[1,2]
 FR BND1      delta[1,3]
 FR BND1      delta[1,4]
 FR BND1      delta[1,5]
 FR BND1      delta[1,6]
 FR BND1      delta[2,0]
 FR BND1      delta[2,1]
 FR BND1      delta[2,2]
 FR BND1      delta[2,3]
 FR BND1      delta[2,4]
 FR BND1      delta[2,5]
 FR BND1      delta[2,6]
 FR BND1      delta[3,0]
 FR BND1      delta[3,1]
 FR BND1      delta[3,2]
 FR BND1      delta[3,3]
 FR BND1      delta[3,4]
 FR BND1      delta[3,5]
 FR BND1      delta[3,6]
 FR BND1      delta[4,0]
 FR BND1      delta[4,1]
 FR BND1      delta[4,2]
 FR BND1      delta[4,3]
 FR BND1      delta[4,4]
 FR BND1      delta[4,5]
 FR BND1      delta[4,6]
 FR BND1      delta[5,0]
 FR BND1      delta[5,1]
 FR BND1      delta[5,2]
 FR BND1      delta[5,3]
 FR BND1      delta[5,4]
 FR BND1      delta[5,5]
 FR BND1      delta[5,6]
 FR BND1      delta[6,0]
 FR BND1      delta[6,1]
 FR BND1      delta[6,2]
 FR BND1      delta[6,3]
 FR BND1      delta[6,4]
 FR BND1      delta[6,5]
 FR BND1      delta[6,6]
 FR BND1      delta[7,0]
 FR BND1      delta[7,1]
 FR BND1      delta[7,2]
 FR BND1      delta[7,3]
 FR BND1      delta[7,4]
 FR BND1      delta[7,5]
 FR BND1      delta[7,6]
 FR BND1      delta[8,0]
 FR BND1      delta[8,1]
 FR BND1      delta[8,2]
 FR BND1      delta[8,3]
 FR BND1      delta[8,4]
 FR BND1      delta[8,5]
 FR BND1      delta[8,6]
 FR BND1      delta[9,0]
 FR BND1      delta[9,1]
 FR BND1      delta[9,2]
 FR BND1      delta[9,3]
 FR BND1      delta[9,4]
 FR BND1      delta[9,5]
 FR BND1      delta[9,6]
QCMATRIX   qc0     
    length[0]  length[0]  -1
    delta[0,0]  delta[0,0]  1
    delta[0,1]  delta[0,1]  1
    delta[0,2]  delta[0,2]  1
    delta[0,3]  delta[0,3]  1
    delta[0,4]  delta[0,4]  1
    delta[0,5]  delta[0,5]  1
    delta[0,6]  delta[0,6]  1
QCMATRIX   qc1     
    length[1]  length[1]  -1
    delta[1,0]  delta[1,0]  1
    delta[1,1]  delta[1,1]  1
    delta[1,2]  delta[1,2]  1
    delta[1,3]  delta[1,3]  1
    delta[1,4]  delta[1,4]  1
    delta[1,5]  delta[1,5]  1
    delta[1,6]  delta[1,6]  1
QCMATRIX   qc2     
    length[2]  length[2]  -1
    delta[2,0]  delta[2,0]  1
    delta[2,1]  delta[2,1]  1
    delta[2,2]  delta[2,2]  1
    delta[2,3]  delta[2,3]  1
    delta[2,4]  delta[2,4]  1
    delta[2,5]  delta[2,5]  1
    delta[2,6]  delta[2,6]  1
QCMATRIX   qc3     
    length[3]  length[3]  -1
    delta[3,0]  delta[3,0]  1
    delta[3,1]  delta[3,1]  1
    delta[3,2]  delta[3,2]  1
    delta[3,3]  delta[3,3]  1
    delta[3,4]  delta[3,4]  1
    delta[3,5]  delta[3,5]  1
    delta[3,6]  delta[3,6]  1
QCMATRIX   qc4     
    length[4]  length[4]  -1
    delta[4,0]  delta[4,0]  1
    delta[4,1]  delta[4,1]  1
    delta[4,2]  delta[4,2]  1
    delta[4,3]  delta[4,3]  1
    delta[4,4]  delta[4,4]  1
    delta[4,5]  delta[4,5]  1
    delta[4,6]  delta[4,6]  1
QCMATRIX   qc5     
    length[5]  length[5]  -1
    delta[5,0]  delta[5,0]  1
    delta[5,1]  delta[5,1]  1
    delta[5,2]  delta[5,2]  1
    delta[5,3]  delta[5,3]  1
    delta[5,4]  delta[5,4]  1
    delta[5,5]  delta[5,5]  1
    delta[5,6]  delta[5,6]  1
QCMATRIX   qc6     
    length[6]  length[6]  -1
    delta[6,0]  delta[6,0]  1
    delta[6,1]  delta[6,1]  1
    delta[6,2]  delta[6,2]  1
    delta[6,3]  delta[6,3]  1
    delta[6,4]  delta[6,4]  1
    delta[6,5]  delta[6,5]  1
    delta[6,6]  delta[6,6]  1
QCMATRIX   qc7     
    length[7]  length[7]  -1
    delta[7,0]  delta[7,0]  1
    delta[7,1]  delta[7,1]  1
    delta[7,2]  delta[7,2]  1
    delta[7,3]  delta[7,3]  1
    delta[7,4]  delta[7,4]  1
    delta[7,5]  delta[7,5]  1
    delta[7,6]  delta[7,6]  1
QCMATRIX   qc8     
    length[8]  length[8]  -1
    delta[8,0]  delta[8,0]  1
    delta[8,1]  delta[8,1]  1
    delta[8,2]  delta[8,2]  1
    delta[8,3]  delta[8,3]  1
    delta[8,4]  delta[8,4]  1
    delta[8,5]  delta[8,5]  1
    delta[8,6]  delta[8,6]  1
QCMATRIX   qc9     
    length[9]  length[9]  -1
    delta[9,0]  delta[9,0]  1
    delta[9,1]  delta[9,1]  1
    delta[9,2]  delta[9,2]  1
    delta[9,3]  delta[9,3]  1
    delta[9,4]  delta[9,4]  1
    delta[9,5]  delta[9,5]  1
    delta[9,6]  delta[9,6]  1
ENDATA
