NAME LGCS_GCS_Eq5_5_projected
ROWS
 N  OBJ
 E  R0      
 L  R1      
 E  R2      
 E  R3      
 E  R4      
 E  R5      
 E  R6      
 E  R7      
 E  R8      
 E  R9      
 L  R10     
 E  R11     
 E  R12     
 E  R13     
 E  R14     
 E  R15     
 E  R16     
 E  R17     
 E  R18     
 L  R19     
 E  R20     
 E  R21     
 E  R22     
 E  R23     
 E  R24     
 E  R25     
 E  R26     
 E  R27     
 L  R28     
 E  R29     
 E  R30     
 E  R31     
 E  R32     
 E  R33     
 E  R34     
 E  R35     
 E  R36     
 L  R37     
 E  R38     
 E  R39     
 E  R40     
 E  R41     
 E  R42     
 E  R43     
 E  R44     
 E  R45     
 L  R46     
 E  R47     
 E  R48     
 E  R49     
 E  R50     
 E  R51     
 E  R52     
 E  R53     
 E  R54     
 L  R55     
 E  R56     
 E  R57     
 E  R58     
 E  R59     
 E  R60     
 E  R61     
 E  R62     
 E  R63     
 L  R64     
 E  R65     
 E  R66     
 E  R67     
 E  R68     
 E  R69     
 E  R70     
 E  R71     
 E  R72     
 E  R73     
 L  R74     
 L  R75     
 L  R76     
 L  R77     
 L  R78     
 L  R79     
 L  R80     
 L  R81     
 L  R82     
 L  R83     
 L  R84     
 L  R85     
 L  R86     
 L  R87     
 L  R88     
 L  R89     
 L  R90     
 L  R91     
 L  R92     
 L  R93     
 L  R94     
 L  R95     
 L  R96     
 L  R97     
 L  R98     
 L  R99     
 L  R100    
 L  R101    
 L  R102    
 L  R103    
 L  R104    
 L  R105    
 L  R106    
 L  R107    
 L  R108    
 L  R109    
 L  R110    
 L  R111    
 L  R112    
 L  R113    
 L  R114    
 L  R115    
 L  R116    
 L  R117    
 L  R118    
 L  R119    
 L  R120    
 L  R121    
 L  R122    
 L  R123    
 L  R124    
 L  R125    
 L  R126    
 L  R127    
 L  R128    
 L  R129    
 L  R130    
 L  R131    
 L  R132    
 L  R133    
 L  R134    
 L  R135    
 L  R136    
 L  R137    
 L  R138    
 L  R139    
 L  R140    
 L  R141    
 L  R142    
 L  R143    
 L  R144    
 L  R145    
 L  R146    
 L  R147    
 L  R148    
 L  R149    
 L  R150    
 L  R151    
 L  R152    
 L  R153    
 L  R154    
 L  R155    
 L  R156    
 L  R157    
 L  R158    
 L  R159    
 L  R160    
 L  R161    
 L  R162    
 L  R163    
 L  R164    
 L  R165    
 L  R166    
 L  R167    
 L  R168    
 L  R169    
 L  R170    
 L  R171    
 L  R172    
 L  R173    
 L  R174    
 L  R175    
 L  R176    
 L  R177    
 L  R178    
 L  R179    
 L  R180    
 L  R181    
 L  R182    
 L  R183    
 L  R184    
 L  R185    
 L  R186    
 L  R187    
 L  R188    
 L  R189    
 L  R190    
 L  R191    
 L  R192    
 L  R193    
 L  R194    
 L  R195    
 L  R196    
 L  R197    
 L  R198    
 L  R199    
 L  R200    
 L  R201    
 L  R202    
 L  R203    
 L  R204    
 L  R205    
 L  R206    
 L  R207    
 L  R208    
 L  R209    
 L  R210    
 L  R211    
 L  R212    
 L  R213    
 L  R214    
 L  R215    
 L  R216    
 L  R217    
 L  R218    
 L  R219    
 L  R220    
 L  R221    
 L  R222    
 L  R223    
 L  R224    
 L  R225    
 L  R226    
 L  R227    
 L  R228    
 L  R229    
 L  R230    
 L  R231    
 L  R232    
 L  R233    
 L  R234    
 L  R235    
 L  R236    
 L  R237    
 L  R238    
 L  R239    
 L  R240    
 L  R241    
 L  R242    
 L  R243    
 L  R244    
 L  R245    
 L  R246    
 L  R247    
 L  R248    
 L  R249    
 L  R250    
 L  R251    
 L  R252    
 L  R253    
 L  R254    
 L  R255    
 L  R256    
 L  R257    
 L  R258    
 L  R259    
 L  R260    
 L  R261    
 L  R262    
 L  R263    
 L  R264    
 L  R265    
 L  R266    
 L  R267    
 L  R268    
 L  R269    
 L  R270    
 L  R271    
 L  R272    
 L  R273    
 L  R274    
 L  R275    
 L  R276    
 L  R277    
 L  R278    
 L  R279    
 L  R280    
 L  R281    
 L  R282    
 L  R283    
 L  R284    
 L  R285    
 L  R286    
 L  R287    
 L  R288    
 L  R289    
 L  R290    
 L  R291    
 L  R292    
 L  R293    
 L  R294    
 L  R295    
 L  R296    
 L  R297    
 L  R298    
 L  R299    
 L  R300    
 L  R301    
 L  R302    
 L  R303    
 L  R304    
 L  R305    
 L  R306    
 L  R307    
 L  R308    
 L  R309    
 L  R310    
 L  R311    
 L  R312    
 L  R313    
 L  R314    
 L  R315    
 L  R316    
 L  R317    
 L  R318    
 L  R319    
 L  R320    
 L  R321    
 L  R322    
 L  R323    
 L  R324    
 L  R325    
 L  R326    
 L  R327    
 L  R328    
 L  R329    
 L  R330    
 L  R331    
 L  R332    
 L  R333    
 L  R334    
 L  R335    
 L  R336    
 L  R337    
 L  R338    
 L  R339    
 L  R340    
 L  R341    
 L  R342    
 L  R343    
 L  R344    
 L  R345    
 L  R346    
 L  R347    
 L  R348    
 L  R349    
 L  R350    
 L  R351    
 L  R352    
 L  R353    
 L  R354    
 L  R355    
 L  R356    
 L  R357    
 L  R358    
 L  R359    
 L  R360    
 L  R361    
 L  R362    
 L  R363    
 L  R364    
 L  R365    
 L  R366    
 L  R367    
 L  R368    
 L  R369    
 L  R370    
 L  R371    
 L  R372    
 L  R373    
 L  R374    
 L  R375    
 L  R376    
 L  R377    
 L  R378    
 L  R379    
 L  R380    
 L  R381    
 L  R382    
 L  R383    
 L  R384    
 L  R385    
 L  R386    
 L  R387    
 L  R388    
 L  R389    
 L  R390    
 L  R391    
 L  R392    
 L  R393    
 L  R394    
 L  R395    
 L  R396    
 L  R397    
 L  R398    
 L  R399    
 L  R400    
 L  R401    
 L  R402    
 L  R403    
 L  R404    
 L  R405    
 L  R406    
 L  R407    
 L  R408    
 L  R409    
 L  R410    
 L  R411    
 L  R412    
 L  R413    
 L  R414    
 L  R415    
 L  R416    
 L  R417    
 L  R418    
 L  R419    
 L  R420    
 L  R421    
 L  R422    
 L  R423    
 L  R424    
 L  R425    
 L  R426    
 L  R427    
 L  R428    
 L  R429    
 L  R430    
 L  R431    
 L  R432    
 L  R433    
 L  R434    
 L  R435    
 L  R436    
 L  R437    
 L  R438    
 L  R439    
 L  R440    
 L  R441    
 L  R442    
 L  R443    
 L  R444    
 L  R445    
 L  R446    
 L  R447    
 L  R448    
 L  R449    
 L  R450    
 L  R451    
 L  R452    
 L  R453    
 L  R454    
 L  R455    
 L  R456    
 L  R457    
 L  R458    
 L  R459    
 L  R460    
 L  R461    
 L  R462    
 L  R463    
 L  R464    
 L  R465    
 L  R466    
 L  R467    
 L  R468    
 L  R469    
 L  R470    
 L  R471    
 L  R472    
 L  R473    
 L  R474    
 L  R475    
 L  R476    
 L  R477    
 L  R478    
 L  R479    
 L  R480    
 L  R481    
 L  R482    
 L  R483    
 L  R484    
 L  R485    
 L  R486    
 L  R487    
 L  R488    
 L  R489    
 L  R490    
 L  R491    
 L  R492    
 L  R493    
 L  R494    
 L  R495    
 L  R496    
 L  R497    
 L  R498    
 L  R499    
 L  R500    
 L  R501    
 L  R502    
 L  R503    
 L  R504    
 L  R505    
 L  R506    
 L  R507    
 L  R508    
 L  R509    
 L  R510    
 L  R511    
 L  R512    
 L  R513    
 L  R514    
 L  R515    
 L  R516    
 L  R517    
 L  R518    
 L  R519    
 L  R520    
 L  R521    
 L  R522    
 L  R523    
 L  R524    
 L  R525    
 L  R526    
 L  R527    
 L  R528    
 L  R529    
 L  R530    
 L  R531    
 L  R532    
 L  R533    
 L  R534    
 L  R535    
 L  R536    
 L  R537    
 L  R538    
 L  R539    
 L  R540    
 L  R541    
 L  R542    
 L  R543    
 L  R544    
 L  R545    
 L  R546    
 L  R547    
 L  R548    
 L  R549    
 L  R550    
 L  R551    
 L  R552    
 L  R553    
 L  R554    
 L  R555    
 L  R556    
 L  R557    
 L  R558    
 L  R559    
 L  R560    
 L  R561    
 L  R562    
 L  R563    
 L  R564    
 L  R565    
 L  R566    
 L  R567    
 L  R568    
 L  R569    
 L  R570    
 L  R571    
 L  R572    
 L  R573    
 L  R574    
 L  R575    
 L  R576    
 L  R577    
 L  R578    
 L  R579    
 L  R580    
 L  R581    
 L  R582    
 L  R583    
 L  R584    
 L  R585    
 L  R586    
 L  R587    
 L  R588    
 L  R589    
 L  R590    
 L  R591    
 L  R592    
 L  R593    
 L  R594    
 L  R595    
 L  R596    
 L  R597    
 L  R598    
 L  R599    
 L  R600    
 L  R601    
 L  R602    
 L  R603    
 L  R604    
 L  R605    
 L  R606    
 L  R607    
 L  R608    
 L  R609    
 L  R610    
 L  R611    
 L  R612    
 L  R613    
 L  R614    
 L  R615    
 L  R616    
 L  R617    
 L  R618    
 L  R619    
 L  R620    
 L  R621    
 L  R622    
 L  R623    
 L  R624    
 L  R625    
 L  R626    
 L  R627    
 L  R628    
 L  R629    
 L  R630    
 L  R631    
 L  R632    
 L  R633    
 L  R634    
 L  R635    
 L  R636    
 L  R637    
 L  R638    
 L  R639    
 L  R640    
 L  R641    
 L  R642    
 L  R643    
 L  R644    
 L  R645    
 L  R646    
 L  R647    
 L  R648    
 L  R649    
 L  R650    
 L  R651    
 L  R652    
 L  R653    
 L  R654    
 L  R655    
 L  R656    
 L  R657    
 L  R658    
 L  R659    
 L  R660    
 L  R661    
 L  R662    
 L  R663    
 L  R664    
 L  R665    
 L  R666    
 L  R667    
 L  R668    
 L  R669    
 L  R670    
 L  R671    
 L  R672    
 L  R673    
 L  R674    
 L  R675    
 L  R676    
 L  R677    
 L  R678    
 L  R679    
 L  R680    
 L  R681    
 L  R682    
 L  R683    
 L  R684    
 L  R685    
 L  R686    
 L  R687    
 L  R688    
 L  R689    
 L  R690    
 L  R691    
 L  R692    
 L  R693    
 L  R694    
 L  R695    
 L  R696    
 L  R697    
 L  R698    
 L  R699    
 L  R700    
 L  R701    
 L  R702    
 L  R703    
 L  R704    
 L  R705    
 L  R706    
 L  R707    
 L  R708    
 L  R709    
 L  R710    
 L  R711    
 L  R712    
 L  R713    
 L  R714    
 L  R715    
 L  R716    
 L  R717    
 L  R718    
 L  R719    
 L  R720    
 L  R721    
 L  R722    
 L  R723    
 L  R724    
 L  R725    
 L  R726    
 L  R727    
 L  R728    
 L  R729    
 L  R730    
 L  R731    
 L  R732    
 L  R733    
 L  R734    
 L  R735    
 L  R736    
 L  R737    
 L  R738    
 L  R739    
 L  R740    
 L  R741    
 L  R742    
 L  R743    
 L  R744    
 L  R745    
 L  R746    
 L  R747    
 L  R748    
 L  R749    
 L  R750    
 L  R751    
 L  R752    
 L  R753    
 L  R754    
 L  R755    
 L  R756    
 L  R757    
 L  R758    
 L  R759    
 L  R760    
 L  R761    
 L  R762    
 L  R763    
 L  R764    
 L  R765    
 L  R766    
 L  R767    
 L  R768    
 L  R769    
 L  R770    
 L  R771    
 L  R772    
 L  R773    
 L  R774    
 L  R775    
 L  R776    
 L  R777    
 L  R778    
 L  R779    
 L  R780    
 L  R781    
 L  R782    
 L  R783    
 L  R784    
 L  R785    
 L  R786    
 L  R787    
 L  R788    
 L  R789    
 L  R790    
 L  R791    
 L  R792    
 L  R793    
 L  R794    
 L  R795    
 L  R796    
 L  R797    
 L  R798    
 L  R799    
 L  R800    
 L  R801    
 L  R802    
 L  R803    
 L  R804    
 L  R805    
 L  R806    
 L  R807    
 L  R808    
 L  R809    
 L  R810    
 L  R811    
 L  R812    
 L  R813    
 L  R814    
 L  R815    
 L  R816    
 L  R817    
 L  R818    
 L  R819    
 L  R820    
 L  R821    
 L  R822    
 L  R823    
 L  R824    
 L  R825    
 L  R826    
 L  R827    
 L  R828    
 L  R829    
 L  R830    
 L  R831    
 L  R832    
 L  R833    
 L  R834    
 L  R835    
 L  R836    
 L  R837    
 L  R838    
 L  R839    
 L  R840    
 L  R841    
 L  R842    
 L  R843    
 L  R844    
 L  R845    
 L  R846    
 L  R847    
 L  R848    
 L  R849    
 L  R850    
 L  R851    
 L  R852    
 L  R853    
 L  R854    
 L  R855    
 L  R856    
 L  R857    
 L  R858    
 L  R859    
 L  R860    
 L  R861    
 L  R862    
 L  R863    
 L  R864    
 L  R865    
 L  R866    
 L  R867    
 L  R868    
 L  R869    
 L  R870    
 L  R871    
 L  R872    
 L  R873    
 L  R874    
 L  R875    
 L  R876    
 L  R877    
 L  R878    
 L  R879    
 L  R880    
 L  R881    
 L  R882    
 L  R883    
 L  R884    
 L  R885    
 L  R886    
 L  R887    
 L  R888    
 L  R889    
 L  R890    
 L  R891    
 L  R892    
 L  R893    
 L  R894    
 L  R895    
 L  R896    
 L  R897    
 L  R898    
 L  R899    
 L  R900    
 L  R901    
 L  R902    
 L  R903    
 L  R904    
 L  R905    
 L  R906    
 L  R907    
 L  R908    
 L  R909    
 L  R910    
 L  R911    
 L  R912    
 L  R913    
 L  R914    
 L  R915    
 L  R916    
 L  R917    
 L  R918    
 L  R919    
 L  R920    
 L  R921    
 L  R922    
 L  R923    
 L  R924    
 L  R925    
 L  R926    
 L  R927    
 L  R928    
 L  R929    
 L  R930    
 L  R931    
 L  R932    
 L  R933    
 L  R934    
 L  R935    
 L  R936    
 L  R937    
 L  R938    
 L  R939    
 L  R940    
 L  R941    
 L  R942    
 L  R943    
 L  R944    
 L  R945    
 L  R946    
 L  R947    
 L  R948    
 L  R949    
 L  R950    
 L  R951    
 L  R952    
 L  R953    
 L  R954    
 L  R955    
 L  R956    
 L  R957    
 L  R958    
 L  R959    
 L  R960    
 L  R961    
 L  R962    
 L  R963    
 L  R964    
 L  R965    
 L  R966    
 L  R967    
 L  R968    
 L  R969    
 L  R970    
 L  R971    
 L  R972    
 L  R973    
 L  R974    
 L  R975    
 L  R976    
 L  R977    
 L  R978    
 L  R979    
 L  R980    
 L  R981    
 L  R982    
 L  R983    
 L  R984    
 L  R985    
 L  R986    
 L  R987    
 L  R988    
 L  R989    
 L  R990    
 L  R991    
 L  R992    
 L  R993    
 L  R994    
 L  R995    
 L  R996    
 L  R997    
 L  R998    
 L  R999    
 L  R1000   
 L  R1001   
 L  R1002   
 L  R1003   
 L  R1004   
 L  R1005   
 L  R1006   
 L  R1007   
 L  R1008   
 L  R1009   
 L  R1010   
 L  R1011   
 L  R1012   
 L  R1013   
 L  R1014   
 L  R1015   
 L  R1016   
 L  R1017   
 L  R1018   
 L  R1019   
 L  R1020   
 L  R1021   
 L  R1022   
 L  R1023   
 L  R1024   
 L  R1025   
 L  R1026   
 L  R1027   
 L  R1028   
 L  R1029   
 L  R1030   
 L  R1031   
 L  R1032   
 L  R1033   
 L  R1034   
 L  R1035   
 L  R1036   
 L  R1037   
 L  R1038   
 L  R1039   
 L  R1040   
 L  R1041   
 L  R1042   
 L  R1043   
 L  R1044   
 L  R1045   
 L  R1046   
 L  R1047   
 L  R1048   
 L  R1049   
 L  R1050   
 L  R1051   
 L  R1052   
 L  R1053   
 L  R1054   
 L  R1055   
 L  R1056   
 L  R1057   
 L  R1058   
 L  R1059   
 L  R1060   
 L  R1061   
 L  R1062   
 L  R1063   
 L  R1064   
 L  R1065   
 L  R1066   
 L  R1067   
 L  R1068   
 L  R1069   
 L  R1070   
 L  R1071   
 L  R1072   
 L  R1073   
 L  R1074   
 L  R1075   
 L  R1076   
 L  R1077   
 L  R1078   
 L  R1079   
 L  R1080   
 L  R1081   
 L  R1082   
 L  R1083   
 L  R1084   
 L  R1085   
 L  R1086   
 L  R1087   
 L  R1088   
 L  R1089   
 L  R1090   
 L  R1091   
 L  R1092   
 L  R1093   
 L  R1094   
 L  R1095   
 L  R1096   
 L  R1097   
 L  R1098   
 L  R1099   
 L  R1100   
 L  R1101   
 L  R1102   
 L  R1103   
 L  R1104   
 L  R1105   
 L  R1106   
 L  R1107   
 L  R1108   
 L  R1109   
 L  R1110   
 L  R1111   
 L  R1112   
 L  R1113   
 L  R1114   
 L  R1115   
 L  R1116   
 L  R1117   
 L  R1118   
 L  R1119   
 L  R1120   
 L  R1121   
 L  R1122   
 L  R1123   
 L  R1124   
 L  R1125   
 L  R1126   
 L  R1127   
 L  R1128   
 L  R1129   
 L  R1130   
 L  R1131   
 L  R1132   
 L  R1133   
 L  R1134   
 L  R1135   
 L  R1136   
 L  R1137   
 L  R1138   
 L  R1139   
 L  R1140   
 L  R1141   
 L  R1142   
 L  R1143   
 L  R1144   
 L  R1145   
 L  R1146   
 L  R1147   
 L  R1148   
 L  R1149   
 L  R1150   
 L  R1151   
 L  R1152   
 L  R1153   
 L  R1154   
 L  R1155   
 L  R1156   
 L  R1157   
 L  R1158   
 L  R1159   
 L  R1160   
 L  R1161   
 L  R1162   
 L  R1163   
 L  R1164   
 L  R1165   
 L  R1166   
 L  R1167   
 L  R1168   
 L  R1169   
 L  R1170   
 L  R1171   
 L  R1172   
 L  R1173   
 L  R1174   
 L  R1175   
 L  R1176   
 L  R1177   
 L  R1178   
 L  R1179   
 L  R1180   
 L  R1181   
 L  R1182   
 L  R1183   
 L  R1184   
 L  R1185   
 L  R1186   
 L  R1187   
 L  R1188   
 L  R1189   
 L  R1190   
 L  R1191   
 L  R1192   
 L  R1193   
 L  R1194   
 L  R1195   
 L  R1196   
 L  R1197   
 L  R1198   
 L  R1199   
 L  R1200   
 L  R1201   
 L  R1202   
 L  R1203   
 L  R1204   
 L  R1205   
 L  R1206   
 L  R1207   
 L  R1208   
 L  R1209   
 L  R1210   
 L  R1211   
 L  R1212   
 L  R1213   
 L  R1214   
 L  R1215   
 L  R1216   
 L  R1217   
 L  R1218   
 L  R1219   
 L  R1220   
 L  R1221   
 L  R1222   
 L  R1223   
 L  R1224   
 L  R1225   
 L  R1226   
 L  R1227   
 L  R1228   
 L  R1229   
 L  R1230   
 L  R1231   
 L  R1232   
 L  R1233   
 L  R1234   
 L  R1235   
 L  R1236   
 L  R1237   
 L  R1238   
 L  R1239   
 L  R1240   
 L  R1241   
 L  R1242   
 L  R1243   
 L  R1244   
 L  R1245   
 L  R1246   
 L  R1247   
 L  R1248   
 L  R1249   
 L  R1250   
 L  R1251   
 L  R1252   
 L  R1253   
 L  R1254   
 L  R1255   
 L  R1256   
 L  R1257   
 L  R1258   
 L  R1259   
 L  R1260   
 L  R1261   
 L  R1262   
 L  R1263   
 L  R1264   
 L  R1265   
 L  R1266   
 L  R1267   
 L  R1268   
 L  R1269   
 L  R1270   
 L  R1271   
 L  R1272   
 L  R1273   
 L  R1274   
 L  R1275   
 L  R1276   
 L  R1277   
 L  R1278   
 L  R1279   
 L  R1280   
 L  R1281   
 L  R1282   
 L  R1283   
 L  R1284   
 L  R1285   
 L  R1286   
 L  R1287   
 L  R1288   
 L  R1289   
 L  R1290   
 L  R1291   
 L  R1292   
 L  R1293   
 L  R1294   
 L  R1295   
 L  R1296   
 L  R1297   
 L  R1298   
 L  R1299   
 L  R1300   
 L  R1301   
 L  R1302   
 L  R1303   
 L  R1304   
 L  R1305   
 L  R1306   
 L  R1307   
 L  R1308   
 L  R1309   
 L  R1310   
 L  R1311   
 L  R1312   
 L  R1313   
 L  R1314   
 L  R1315   
 L  R1316   
 L  R1317   
 L  R1318   
 L  R1319   
 L  R1320   
 L  R1321   
 L  R1322   
 L  R1323   
 L  R1324   
 L  R1325   
 L  R1326   
 L  R1327   
 L  R1328   
 L  R1329   
 L  R1330   
 L  R1331   
 L  R1332   
 L  R1333   
 L  R1334   
 L  R1335   
 L  R1336   
 L  R1337   
 L  R1338   
 L  R1339   
 L  R1340   
 L  R1341   
 L  R1342   
 L  R1343   
 L  R1344   
 L  R1345   
 L  R1346   
 L  R1347   
 L  R1348   
 L  R1349   
 L  R1350   
 L  R1351   
 L  R1352   
 L  R1353   
 L  R1354   
 L  R1355   
 L  R1356   
 L  R1357   
 L  R1358   
 L  R1359   
 L  R1360   
 L  R1361   
 L  R1362   
 L  R1363   
 L  R1364   
 L  R1365   
 L  R1366   
 L  R1367   
 L  R1368   
 L  R1369   
 L  R1370   
 L  R1371   
 L  R1372   
 L  R1373   
 L  R1374   
 L  R1375   
 L  R1376   
 L  R1377   
 L  R1378   
 L  R1379   
 L  R1380   
 L  R1381   
 L  R1382   
 L  R1383   
 L  R1384   
 L  R1385   
 L  R1386   
 L  R1387   
 L  R1388   
 L  R1389   
 L  R1390   
 L  R1391   
 L  R1392   
 L  R1393   
 L  R1394   
 L  R1395   
 L  R1396   
 L  R1397   
 L  R1398   
 L  R1399   
 L  R1400   
 L  R1401   
 L  R1402   
 L  R1403   
 L  R1404   
 L  R1405   
 L  R1406   
 L  R1407   
 L  R1408   
 L  R1409   
 L  R1410   
 L  R1411   
 L  R1412   
 L  R1413   
 L  R1414   
 L  R1415   
 L  R1416   
 L  R1417   
 L  R1418   
 L  R1419   
 L  R1420   
 L  R1421   
 L  R1422   
 L  R1423   
 L  R1424   
 L  R1425   
 L  R1426   
 L  R1427   
 L  R1428   
 L  R1429   
 L  R1430   
 L  R1431   
 L  R1432   
 L  R1433   
 L  R1434   
 L  R1435   
 L  R1436   
 L  R1437   
 L  R1438   
 L  R1439   
 L  R1440   
 L  R1441   
 L  R1442   
 L  R1443   
 L  R1444   
 L  R1445   
 L  R1446   
 L  R1447   
 L  R1448   
 L  R1449   
 L  R1450   
 L  R1451   
 L  R1452   
 L  R1453   
 L  R1454   
 L  R1455   
 L  R1456   
 L  R1457   
 L  R1458   
 L  R1459   
 L  R1460   
 L  R1461   
 L  R1462   
 L  R1463   
 L  R1464   
 L  R1465   
 L  R1466   
 L  R1467   
 L  R1468   
 L  R1469   
 L  R1470   
 L  R1471   
 L  R1472   
 L  R1473   
 L  R1474   
 L  R1475   
 L  R1476   
 L  R1477   
 L  R1478   
 L  R1479   
 L  R1480   
 L  R1481   
 L  R1482   
 L  R1483   
 L  R1484   
 L  R1485   
 L  R1486   
 L  R1487   
 L  R1488   
 L  R1489   
 L  R1490   
 L  R1491   
 L  R1492   
 L  R1493   
 L  R1494   
 L  R1495   
 L  R1496   
 L  R1497   
 L  R1498   
 L  R1499   
 L  R1500   
 L  R1501   
 L  R1502   
 L  R1503   
 L  R1504   
 L  R1505   
 L  R1506   
 L  R1507   
 L  R1508   
 L  R1509   
 L  R1510   
 L  R1511   
 L  R1512   
 L  R1513   
 L  R1514   
 L  R1515   
 L  R1516   
 L  R1517   
 L  R1518   
 L  R1519   
 L  R1520   
 L  R1521   
 L  R1522   
 L  R1523   
 L  R1524   
 L  R1525   
 L  R1526   
 L  R1527   
 L  R1528   
 L  R1529   
 L  R1530   
 L  R1531   
 L  R1532   
 L  R1533   
 L  R1534   
 L  R1535   
 L  R1536   
 L  R1537   
 L  R1538   
 L  R1539   
 L  R1540   
 L  R1541   
 L  R1542   
 L  R1543   
 L  R1544   
 L  R1545   
 L  R1546   
 L  R1547   
 L  R1548   
 L  R1549   
 L  R1550   
 L  R1551   
 L  R1552   
 L  R1553   
 L  R1554   
 L  R1555   
 L  R1556   
 L  R1557   
 L  R1558   
 L  R1559   
 L  R1560   
 L  R1561   
 L  R1562   
 L  R1563   
 L  R1564   
 L  R1565   
 L  R1566   
 L  R1567   
 L  R1568   
 L  R1569   
 L  R1570   
 L  R1571   
 L  R1572   
 L  R1573   
 L  R1574   
 L  R1575   
 L  R1576   
 L  R1577   
 L  R1578   
 L  R1579   
 L  R1580   
 L  R1581   
 L  R1582   
 L  R1583   
 L  R1584   
 L  R1585   
 L  R1586   
 L  R1587   
 L  R1588   
 L  R1589   
 L  R1590   
 L  R1591   
 L  R1592   
 L  R1593   
 L  R1594   
 L  R1595   
 L  R1596   
 L  R1597   
 L  R1598   
 L  R1599   
 L  R1600   
 L  R1601   
 L  R1602   
 L  R1603   
 L  R1604   
 L  R1605   
 L  R1606   
 L  R1607   
 L  R1608   
 L  R1609   
 L  R1610   
 L  R1611   
 L  R1612   
 L  R1613   
 L  R1614   
 L  R1615   
 L  R1616   
 L  R1617   
 L  R1618   
 L  R1619   
 L  R1620   
 L  R1621   
 L  R1622   
 L  R1623   
 L  R1624   
 L  R1625   
 L  R1626   
 L  R1627   
 L  R1628   
 L  R1629   
 L  R1630   
 L  R1631   
 L  R1632   
 L  R1633   
 L  R1634   
 L  R1635   
 L  R1636   
 L  R1637   
 L  R1638   
 L  R1639   
 L  R1640   
 L  R1641   
 L  R1642   
 L  R1643   
 L  R1644   
 L  R1645   
 L  R1646   
 L  R1647   
 L  R1648   
 L  R1649   
 L  R1650   
 L  R1651   
 L  R1652   
 L  R1653   
 L  R1654   
 L  R1655   
 L  R1656   
 L  R1657   
 L  R1658   
 L  R1659   
 L  R1660   
 L  R1661   
 L  R1662   
 L  R1663   
 L  R1664   
 L  R1665   
 L  R1666   
 L  R1667   
 L  R1668   
 L  R1669   
 L  R1670   
 L  R1671   
 L  R1672   
 L  R1673   
 L  R1674   
 L  R1675   
 L  R1676   
 L  R1677   
 L  R1678   
 L  R1679   
 L  R1680   
 L  R1681   
 L  R1682   
 L  R1683   
 L  R1684   
 L  R1685   
 L  R1686   
 L  R1687   
 L  R1688   
 L  R1689   
 L  R1690   
 L  R1691   
 L  R1692   
 L  R1693   
 L  R1694   
 L  R1695   
 L  R1696   
 L  R1697   
 L  R1698   
 L  R1699   
 L  R1700   
 L  R1701   
 L  R1702   
 L  R1703   
 L  R1704   
 L  R1705   
 L  R1706   
 L  R1707   
 L  R1708   
 L  R1709   
 L  R1710   
 L  R1711   
 L  R1712   
 L  R1713   
 L  R1714   
 L  R1715   
 L  R1716   
 L  R1717   
 L  R1718   
 L  R1719   
 L  R1720   
 L  R1721   
 L  R1722   
 L  R1723   
 L  R1724   
 L  R1725   
 L  R1726   
 L  R1727   
 L  R1728   
 L  R1729   
 L  R1730   
 L  R1731   
 L  R1732   
 L  R1733   
 L  R1734   
 L  R1735   
 L  R1736   
 L  R1737   
 L  R1738   
 L  R1739   
 L  R1740   
 L  R1741   
 L  R1742   
 L  R1743   
 L  R1744   
 L  R1745   
 L  R1746   
 L  R1747   
 L  R1748   
 L  R1749   
 L  R1750   
 L  R1751   
 L  R1752   
 L  R1753   
 L  R1754   
 L  R1755   
 L  R1756   
 L  R1757   
 L  R1758   
 L  R1759   
 L  R1760   
 L  R1761   
 L  R1762   
 L  R1763   
 L  R1764   
 L  R1765   
 L  R1766   
 L  R1767   
 L  R1768   
 L  R1769   
 L  R1770   
 L  R1771   
 L  R1772   
 L  R1773   
 L  R1774   
 L  R1775   
 L  R1776   
 L  R1777   
 L  R1778   
 L  R1779   
 L  R1780   
 L  R1781   
 L  R1782   
 L  R1783   
 L  R1784   
 L  R1785   
 L  R1786   
 L  R1787   
 L  R1788   
 L  R1789   
 L  R1790   
 L  R1791   
 L  R1792   
 L  R1793   
 L  R1794   
 L  R1795   
 L  R1796   
 L  R1797   
 L  R1798   
 L  R1799   
 L  R1800   
 L  R1801   
 L  R1802   
 L  R1803   
 L  R1804   
 L  R1805   
 L  R1806   
 L  R1807   
 L  R1808   
 L  R1809   
 L  R1810   
 L  R1811   
 L  R1812   
 L  R1813   
 L  R1814   
 L  R1815   
 L  R1816   
 L  R1817   
 L  R1818   
 L  R1819   
 L  R1820   
 L  R1821   
 L  R1822   
 L  R1823   
 L  R1824   
 L  R1825   
 L  R1826   
 L  R1827   
 L  R1828   
 L  R1829   
 L  R1830   
 L  R1831   
 L  R1832   
 L  R1833   
 L  R1834   
 L  R1835   
 L  R1836   
 L  R1837   
 L  R1838   
 L  R1839   
 L  R1840   
 L  R1841   
 L  R1842   
 L  R1843   
 L  R1844   
 L  R1845   
 L  R1846   
 L  R1847   
 L  R1848   
 L  R1849   
 L  R1850   
 L  R1851   
 L  R1852   
 L  R1853   
 L  R1854   
 L  R1855   
 L  R1856   
 L  R1857   
 L  R1858   
 L  R1859   
 L  R1860   
 L  R1861   
 L  R1862   
 L  R1863   
 L  R1864   
 L  R1865   
 L  R1866   
 L  R1867   
 L  R1868   
 L  R1869   
 L  R1870   
 L  R1871   
 L  R1872   
 L  R1873   
 L  R1874   
 L  R1875   
 L  R1876   
 L  R1877   
 L  R1878   
 L  R1879   
 L  R1880   
 L  R1881   
 L  R1882   
 L  R1883   
 L  R1884   
 L  R1885   
 L  R1886   
 L  R1887   
 L  R1888   
 L  R1889   
 L  R1890   
 L  R1891   
 L  R1892   
 L  R1893   
 L  R1894   
 L  R1895   
 L  R1896   
 L  R1897   
 L  R1898   
 L  R1899   
 L  R1900   
 L  R1901   
 L  R1902   
 L  R1903   
 L  R1904   
 L  R1905   
 L  R1906   
 L  R1907   
 L  R1908   
 L  R1909   
 L  R1910   
 L  R1911   
 L  R1912   
 L  R1913   
 L  R1914   
 L  R1915   
 L  R1916   
 L  R1917   
 L  R1918   
 L  R1919   
 L  R1920   
 L  R1921   
 L  R1922   
 L  R1923   
 L  R1924   
 L  R1925   
 L  R1926   
 L  R1927   
 L  R1928   
 L  R1929   
 L  R1930   
 L  R1931   
 L  R1932   
 L  R1933   
 L  R1934   
 L  R1935   
 L  R1936   
 L  R1937   
 L  R1938   
 L  R1939   
 L  R1940   
 L  R1941   
 L  R1942   
 L  R1943   
 L  R1944   
 L  R1945   
 L  R1946   
 L  R1947   
 L  R1948   
 L  R1949   
 L  R1950   
 L  R1951   
 L  R1952   
 L  R1953   
 L  R1954   
 L  R1955   
 L  R1956   
 L  R1957   
 L  R1958   
 L  R1959   
 L  R1960   
 L  R1961   
 L  R1962   
 L  R1963   
 L  R1964   
 L  R1965   
 L  R1966   
 L  R1967   
 L  R1968   
 L  R1969   
 L  R1970   
 L  R1971   
 L  R1972   
 L  R1973   
 L  R1974   
 L  R1975   
 L  R1976   
 L  R1977   
 L  R1978   
 L  R1979   
 L  R1980   
 L  R1981   
 L  R1982   
 L  R1983   
 L  R1984   
 L  R1985   
 L  R1986   
 L  R1987   
 L  R1988   
 L  R1989   
 L  R1990   
 L  R1991   
 L  R1992   
 L  R1993   
 L  R1994   
 L  R1995   
 L  R1996   
 L  R1997   
 L  R1998   
 L  R1999   
 L  R2000   
 L  R2001   
 L  R2002   
 L  R2003   
 L  R2004   
 L  R2005   
 L  R2006   
 L  R2007   
 L  R2008   
 L  R2009   
 L  R2010   
 L  R2011   
 L  R2012   
 L  R2013   
 L  R2014   
 L  R2015   
 L  R2016   
 L  R2017   
 L  R2018   
 L  R2019   
 L  R2020   
 L  R2021   
 L  R2022   
 L  R2023   
 L  R2024   
 L  R2025   
 L  R2026   
 L  R2027   
 L  R2028   
 L  R2029   
 L  R2030   
 L  R2031   
 L  R2032   
 L  R2033   
 L  R2034   
 L  R2035   
 L  R2036   
 L  R2037   
 L  R2038   
 L  R2039   
 L  R2040   
 L  R2041   
 L  R2042   
 L  R2043   
 L  R2044   
 L  R2045   
 L  R2046   
 L  R2047   
 L  R2048   
 L  R2049   
 L  R2050   
 L  R2051   
 L  R2052   
 L  R2053   
 L  R2054   
 L  R2055   
 L  R2056   
 L  R2057   
 L  R2058   
 L  R2059   
 L  R2060   
 L  R2061   
 L  R2062   
 L  R2063   
 L  R2064   
 L  R2065   
 L  R2066   
 L  R2067   
 L  R2068   
 L  R2069   
 L  R2070   
 L  R2071   
 L  R2072   
 L  R2073   
 L  R2074   
 L  R2075   
 L  R2076   
 L  R2077   
 L  R2078   
 L  R2079   
 L  R2080   
 L  R2081   
 L  R2082   
 L  R2083   
 L  R2084   
 L  R2085   
 L  R2086   
 L  R2087   
 L  R2088   
 L  R2089   
 L  R2090   
 L  R2091   
 L  R2092   
 L  R2093   
 L  R2094   
 L  R2095   
 L  R2096   
 L  R2097   
 L  R2098   
 L  R2099   
 L  R2100   
 L  R2101   
 L  R2102   
 L  R2103   
 L  R2104   
 L  R2105   
 L  R2106   
 L  R2107   
 L  R2108   
 L  R2109   
 L  R2110   
 L  R2111   
 L  R2112   
 L  R2113   
 L  R2114   
 L  R2115   
 L  R2116   
 L  R2117   
 L  R2118   
 L  R2119   
 L  R2120   
 L  R2121   
 L  R2122   
 L  R2123   
 L  R2124   
 L  R2125   
 L  R2126   
 L  R2127   
 L  R2128   
 L  R2129   
 L  R2130   
 L  R2131   
 L  R2132   
 L  R2133   
 L  R2134   
 L  R2135   
 L  R2136   
 L  R2137   
 L  R2138   
 L  R2139   
 L  R2140   
 L  R2141   
 L  R2142   
 L  R2143   
 L  R2144   
 L  R2145   
 L  R2146   
 L  R2147   
 L  R2148   
 L  R2149   
 L  R2150   
 L  R2151   
 L  R2152   
 L  R2153   
 L  R2154   
 L  R2155   
 L  R2156   
 L  R2157   
 L  R2158   
 L  R2159   
 L  R2160   
 L  R2161   
 L  R2162   
 L  R2163   
 L  R2164   
 L  R2165   
 L  R2166   
 L  R2167   
 L  R2168   
 L  R2169   
 L  R2170   
 L  R2171   
 L  R2172   
 L  R2173   
 L  R2174   
 L  R2175   
 L  R2176   
 L  R2177   
 L  R2178   
 L  R2179   
 L  R2180   
 L  R2181   
 L  R2182   
 L  R2183   
 L  R2184   
 L  R2185   
 L  R2186   
 L  R2187   
 L  R2188   
 L  R2189   
 L  R2190   
 L  R2191   
 L  R2192   
 L  R2193   
 L  R2194   
 L  R2195   
 L  R2196   
 L  R2197   
 L  R2198   
 L  R2199   
 L  R2200   
 L  R2201   
 L  R2202   
 L  R2203   
 L  R2204   
 L  R2205   
 L  R2206   
 L  R2207   
 L  R2208   
 L  R2209   
 L  R2210   
 L  R2211   
 L  R2212   
 L  R2213   
 L  R2214   
 L  R2215   
 L  R2216   
 L  R2217   
 L  R2218   
 L  R2219   
 L  R2220   
 L  R2221   
 L  R2222   
 L  R2223   
 L  R2224   
 L  R2225   
 L  R2226   
 L  R2227   
 L  R2228   
 L  R2229   
 L  R2230   
 L  R2231   
 L  R2232   
 L  R2233   
 L  R2234   
 L  R2235   
 L  R2236   
 L  R2237   
 L  R2238   
 L  R2239   
 L  R2240   
 L  R2241   
 L  R2242   
 L  R2243   
 L  R2244   
 L  R2245   
 L  R2246   
 L  R2247   
 L  R2248   
 L  R2249   
 L  R2250   
 L  R2251   
 L  R2252   
 L  R2253   
 L  R2254   
 L  R2255   
 L  R2256   
 L  R2257   
 L  R2258   
 L  R2259   
 L  R2260   
 L  R2261   
 L  R2262   
 L  R2263   
 L  R2264   
 L  R2265   
 L  R2266   
 L  R2267   
 L  R2268   
 L  R2269   
 L  R2270   
 L  R2271   
 L  R2272   
 L  R2273   
 L  R2274   
 L  R2275   
 L  R2276   
 L  R2277   
 L  R2278   
 L  R2279   
 L  R2280   
 L  R2281   
 L  R2282   
 L  R2283   
 L  R2284   
 L  R2285   
 L  R2286   
 L  R2287   
 L  R2288   
 L  R2289   
 L  R2290   
 L  R2291   
 L  R2292   
 L  R2293   
 L  R2294   
 L  R2295   
 L  R2296   
 L  R2297   
 L  R2298   
 L  R2299   
 L  R2300   
 L  R2301   
 L  R2302   
 L  R2303   
 L  R2304   
 L  R2305   
 L  R2306   
 L  R2307   
 L  R2308   
 L  R2309   
 L  R2310   
 L  R2311   
 L  R2312   
 L  R2313   
 L  R2314   
 L  R2315   
 L  R2316   
 L  R2317   
 L  R2318   
 L  R2319   
 L  R2320   
 L  R2321   
 L  R2322   
 L  R2323   
 L  R2324   
 L  R2325   
 L  R2326   
 L  R2327   
 L  R2328   
 L  R2329   
 L  R2330   
 L  R2331   
 L  R2332   
 L  R2333   
 L  R2334   
 L  R2335   
 L  R2336   
 L  R2337   
 L  R2338   
 L  R2339   
 L  R2340   
 L  R2341   
 L  R2342   
 L  R2343   
 L  R2344   
 L  R2345   
 L  R2346   
 L  R2347   
 L  R2348   
 L  R2349   
 L  R2350   
 L  R2351   
 L  R2352   
 L  R2353   
 L  R2354   
 L  R2355   
 L  R2356   
 L  R2357   
 L  R2358   
 L  R2359   
 L  R2360   
 L  R2361   
 L  R2362   
 L  R2363   
 L  R2364   
 L  R2365   
 L  R2366   
 L  R2367   
 L  R2368   
 L  R2369   
 L  R2370   
 L  R2371   
 L  R2372   
 L  R2373   
 L  R2374   
 L  R2375   
 L  R2376   
 L  R2377   
 L  R2378   
 L  R2379   
 L  R2380   
 L  R2381   
 L  R2382   
 L  R2383   
 L  R2384   
 L  R2385   
 L  R2386   
 L  R2387   
 L  R2388   
 L  R2389   
 L  R2390   
 L  R2391   
 L  R2392   
 L  R2393   
 L  R2394   
 L  R2395   
 L  R2396   
 L  R2397   
 L  R2398   
 L  R2399   
 L  R2400   
 L  R2401   
 L  R2402   
 L  R2403   
 L  R2404   
 L  R2405   
 L  R2406   
 L  R2407   
 L  R2408   
 L  R2409   
 L  R2410   
 L  R2411   
 L  R2412   
 L  R2413   
 L  R2414   
 L  R2415   
 L  R2416   
 L  R2417   
 L  R2418   
 L  R2419   
 L  R2420   
 L  R2421   
 L  R2422   
 L  R2423   
 L  R2424   
 L  R2425   
 L  R2426   
 L  R2427   
 L  R2428   
 L  R2429   
 L  R2430   
 L  R2431   
 L  R2432   
 L  R2433   
 L  R2434   
 L  R2435   
 L  R2436   
 L  R2437   
 L  R2438   
 L  R2439   
 L  R2440   
 L  R2441   
 L  R2442   
 L  R2443   
 L  R2444   
 L  R2445   
 L  R2446   
 L  R2447   
 L  R2448   
 L  R2449   
 L  R2450   
 L  R2451   
 L  R2452   
 L  R2453   
 L  R2454   
 L  R2455   
 L  R2456   
 L  R2457   
 L  R2458   
 L  R2459   
 L  R2460   
 L  R2461   
 L  R2462   
 L  R2463   
 L  R2464   
 L  R2465   
 L  R2466   
 L  R2467   
 L  R2468   
 L  R2469   
 L  R2470   
 L  R2471   
 L  R2472   
 L  R2473   
 L  R2474   
 L  R2475   
 L  R2476   
 L  R2477   
 L  R2478   
 L  R2479   
 L  R2480   
 L  R2481   
 L  R2482   
 L  R2483   
 L  R2484   
 L  R2485   
 L  R2486   
 L  R2487   
 L  R2488   
 L  R2489   
 L  R2490   
 L  R2491   
 L  R2492   
 L  R2493   
 L  R2494   
 L  R2495   
 L  R2496   
 L  R2497   
 L  R2498   
 L  R2499   
 L  R2500   
 L  R2501   
 L  R2502   
 L  R2503   
 L  R2504   
 L  R2505   
 L  R2506   
 L  R2507   
 L  R2508   
 L  R2509   
 L  R2510   
 L  R2511   
 L  R2512   
 L  R2513   
 L  R2514   
 L  R2515   
 L  R2516   
 L  R2517   
 L  R2518   
 L  R2519   
 L  R2520   
 L  R2521   
 L  R2522   
 L  R2523   
 L  R2524   
 L  R2525   
 L  R2526   
 L  R2527   
 L  R2528   
 L  R2529   
 L  R2530   
 L  R2531   
 L  R2532   
 L  R2533   
 L  R2534   
 L  R2535   
 L  R2536   
 L  R2537   
 L  R2538   
 L  R2539   
 L  R2540   
 L  R2541   
 L  R2542   
 L  R2543   
 L  R2544   
 L  R2545   
 L  R2546   
 L  R2547   
 L  R2548   
 L  R2549   
 L  R2550   
 L  R2551   
 L  R2552   
 L  R2553   
 L  R2554   
 L  R2555   
 L  R2556   
 L  R2557   
 L  R2558   
 L  R2559   
 L  R2560   
 L  R2561   
 L  R2562   
 L  R2563   
 L  R2564   
 L  R2565   
 L  R2566   
 L  R2567   
 L  R2568   
 L  R2569   
 L  R2570   
 L  R2571   
 L  R2572   
 L  R2573   
 L  R2574   
 L  R2575   
 L  R2576   
 L  R2577   
 L  R2578   
 L  R2579   
 L  R2580   
 L  R2581   
 L  R2582   
 L  R2583   
 L  R2584   
 L  R2585   
 L  R2586   
 L  R2587   
 L  R2588   
 L  R2589   
 L  R2590   
 L  R2591   
 L  R2592   
 L  R2593   
 L  R2594   
 L  R2595   
 L  R2596   
 L  R2597   
 L  R2598   
 L  R2599   
 L  R2600   
 L  R2601   
 L  R2602   
 L  R2603   
 L  R2604   
 L  R2605   
 L  R2606   
 L  R2607   
 L  R2608   
 L  R2609   
 L  R2610   
 L  R2611   
 L  R2612   
 L  R2613   
 L  R2614   
 L  R2615   
 L  R2616   
 L  R2617   
 L  R2618   
 L  R2619   
 L  R2620   
 L  R2621   
 L  R2622   
 L  R2623   
 L  R2624   
 L  R2625   
 L  R2626   
 L  R2627   
 L  R2628   
 L  R2629   
 L  R2630   
 L  R2631   
 L  R2632   
 L  R2633   
 L  R2634   
 L  R2635   
 L  R2636   
 L  R2637   
 L  R2638   
 L  R2639   
 L  R2640   
 L  R2641   
 L  R2642   
 L  R2643   
 L  R2644   
 L  R2645   
 L  R2646   
 L  R2647   
 L  R2648   
 L  R2649   
 L  R2650   
 L  R2651   
 L  R2652   
 L  R2653   
 L  R2654   
 L  R2655   
 L  R2656   
 L  R2657   
 L  R2658   
 L  R2659   
 L  R2660   
 L  R2661   
 L  R2662   
 L  R2663   
 L  R2664   
 L  R2665   
 L  R2666   
 L  R2667   
 L  R2668   
 L  R2669   
 L  qc0     
 L  qc1     
 L  qc2     
 L  qc3     
 L  qc4     
 L  qc5     
 L  qc6     
 L  qc7     
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    phi[0,1]  R0        1
    phi[0,1]  R1        1
    phi[0,1]  R9        -1
    phi[0,1]  R74       -3.0999999046325684e+00
    phi[0,1]  R75       -3.0999999046325684e+00
    phi[0,1]  R76       -2.2400000095367432e+00
    phi[0,1]  R77       -2.2400000095367432e+00
    phi[0,1]  R78       -3.0999999046325684e+00
    phi[0,1]  R79       -3.0999999046325684e+00
    phi[0,1]  R80       -2.5699999332427979e+00
    phi[0,1]  R81       -2.5699999332427979e+00
    phi[0,1]  R82       -3.0999999046325684e+00
    phi[0,1]  R83       -3.0999999046325684e+00
    phi[0,1]  R84       -2.0899999141693115e+00
    phi[0,1]  R85       -2.0899999141693115e+00
    phi[0,1]  R86       -3.0999999046325684e+00
    phi[0,1]  R87       -3.0999999046325684e+00
    phi[0,1]  R88       1.6564947366714478e+00
    phi[0,1]  R89       1.3346179723739624e+00
    phi[0,1]  R90       8.6935126781463623e-01
    phi[0,1]  R91       2.3759746551513672e+00
    phi[0,1]  R92       1.18687105178833
    phi[0,1]  R93       4.4723996520042419e-01
    phi[0,1]  R94       2.5852041244506836e+00
    phi[0,1]  R95       2.9762408733367920e+00
    phi[0,1]  R96       2.4950993061065674e+00
    phi[0,1]  R97       1.3653959333896637e-01
    phi[0,1]  R98       -1.8423606157302856e+00
    phi[0,1]  R99       -2.9243652820587158e+00
    phi[0,1]  R100      -1.0284932851791382e+00
    phi[0,1]  R101      -2.4771654605865479e+00
    phi[0,1]  R102      -2.5056068897247314e+00
    phi[0,1]  R103      -1.4946783781051636e+00
    phi[0,1]  R104      -1.8367550373077393e+00
    phi[0,1]  R105      -0.752835750579834
    phi[0,1]  R106      -1.6402444839477539e+00
    phi[0,1]  R107      1.84006667137146
    phi[0,1]  R108      -1.1930602043867111e-01
    phi[0,1]  R109      -4.2254328727722168e-01
    phi[0,1]  R110      1.2391186952590942e+00
    phi[0,1]  R111      -1.4637634158134460e-01
    phi[0,1]  R112      -1.3424482345581055e+00
    phi[0,1]  R113      -1.3917092084884644e+00
    phi[0,1]  R114      1.5509039163589478e-01
    phi[0,1]  R115      -1.1546980142593384e+00
    phi[0,1]  R116      2.0705714821815491e-01
    phi[0,1]  R117      -1.8370142206549644e-02
    phi[0,1]  R118      -7.0574051141738892e-01
    phi[0,1]  R119      -1.7091115713119507e+00
    phi[0,1]  R120      -7.2450834512710571e-01
    phi[0,1]  R121      -1.7249271869659424e+00
    phi[0,1]  R122      -2.4162245914340019e-02
    phi[0,1]  R123      -2.5587670803070068e+00
    phi[0,1]  R124      -4.0877994894981384e-01
    phi[0,1]  R125      -1.2376141548156738e+00
    phi[0,1]  R126      -1.2744680047035217e-01
    phi[0,1]  R127      -1.7862209081649780e+00
    phi[0,1]  R128      2.4963538646698
    phi[0,1]  R129      1.7336258888244629e+00
    phi[0,1]  R130      1.4955888986587524e+00
    phi[0,1]  R131      1.7211706638336182e+00
    phi[0,1]  R132      2.1004745960235596e+00
    phi[0,1]  R133      -2.2902162075042725e+00
    phi[0,1]  R134      2.5116711854934692e-01
    phi[0,1]  R135      1.2279601097106934e+00
    phi[0,1]  R136      3.4853017330169678e-01
    phi[0,1]  R137      5.7756072282791138e-01
    phi[0,1]  R138      -1.2942359447479248e+00
    phi[0,1]  R139      -1.4284121990203857e+00
    phi[0,1]  R140      -2.7967376708984375e+00
    phi[0,1]  R141      -2.5418975353240967e+00
    phi[0,1]  R142      -2.2268667221069336e+00
    phi[0,1]  R143      -1.3170238733291626e+00
    phi[0,1]  R144      -2.1494996547698975e+00
    phi[0,1]  R145      -2.9085350036621094e+00
    phi[0,1]  R146      -1.8219076395034790e+00
    phi[0,1]  R147      -2.2166464328765869e+00
    phi[0,1]  R148      -8.3626079559326172e-01
    phi[0,1]  R149      -3.2189896106719971e+00
    phi[0,1]  R150      -6.7499846220016479e-01
    phi[0,1]  R151      -2.5502939224243164e+00
    phi[0,1]  R152      -2.1119406223297119e+00
    phi[0,1]  R153      -1.5659917593002319e+00
    phi[0,1]  R154      -2.9926688671112061e+00
    phi[0,1]  R155      -1.9912683963775635e+00
    phi[0,1]  R156      1.7624202966690063e+00
    phi[0,1]  R157      1.7676345109939575e+00
    phi[0,1]  R158      -2.3440320491790771e+00
    phi[0,1]  R159      -8.9249891042709351e-01
    phi[0,1]  R160      -3.0345923900604248e+00
    phi[0,1]  R161      -2.8800981044769287e+00
    phi[0,1]  R162      -1.0606863498687744e+00
    phi[0,1]  R163      6.4512640237808228e-01
    phi[0,1]  R164      -3.4161096811294556e-01
    phi[0,1]  R165      -2.4345057085156441e-02
    phi[0,1]  R166      -1.0151368379592896e+00
    phi[0,1]  R167      2.3282326757907867e-01
    phi[1,0]  R0        -1
    phi[1,0]  R9        1
    phi[1,0]  R10       1
    phi[1,0]  R168      -3.0999999046325684e+00
    phi[1,0]  R169      -3.0999999046325684e+00
    phi[1,0]  R170      -2.2400000095367432e+00
    phi[1,0]  R171      -2.2400000095367432e+00
    phi[1,0]  R172      -3.0999999046325684e+00
    phi[1,0]  R173      -3.0999999046325684e+00
    phi[1,0]  R174      -2.5699999332427979e+00
    phi[1,0]  R175      -2.5699999332427979e+00
    phi[1,0]  R176      -3.0999999046325684e+00
    phi[1,0]  R177      -3.0999999046325684e+00
    phi[1,0]  R178      -2.0899999141693115e+00
    phi[1,0]  R179      -2.0899999141693115e+00
    phi[1,0]  R180      -3.0999999046325684e+00
    phi[1,0]  R181      -3.0999999046325684e+00
    phi[1,0]  R182      2.4963538646698
    phi[1,0]  R183      1.7336258888244629e+00
    phi[1,0]  R184      1.4955888986587524e+00
    phi[1,0]  R185      1.7211706638336182e+00
    phi[1,0]  R186      2.1004745960235596e+00
    phi[1,0]  R187      -2.2902162075042725e+00
    phi[1,0]  R188      2.5116711854934692e-01
    phi[1,0]  R189      1.2279601097106934e+00
    phi[1,0]  R190      3.4853017330169678e-01
    phi[1,0]  R191      5.7756072282791138e-01
    phi[1,0]  R192      -1.2942359447479248e+00
    phi[1,0]  R193      -1.4284121990203857e+00
    phi[1,0]  R194      -2.7967376708984375e+00
    phi[1,0]  R195      -2.5418975353240967e+00
    phi[1,0]  R196      -2.2268667221069336e+00
    phi[1,0]  R197      -1.3170238733291626e+00
    phi[1,0]  R198      -2.1494996547698975e+00
    phi[1,0]  R199      -2.9085350036621094e+00
    phi[1,0]  R200      -1.8219076395034790e+00
    phi[1,0]  R201      -2.2166464328765869e+00
    phi[1,0]  R202      -8.3626079559326172e-01
    phi[1,0]  R203      -3.2189896106719971e+00
    phi[1,0]  R204      -6.7499846220016479e-01
    phi[1,0]  R205      -2.5502939224243164e+00
    phi[1,0]  R206      -2.1119406223297119e+00
    phi[1,0]  R207      -1.5659917593002319e+00
    phi[1,0]  R208      -2.9926688671112061e+00
    phi[1,0]  R209      -1.9912683963775635e+00
    phi[1,0]  R210      1.7624202966690063e+00
    phi[1,0]  R211      1.7676345109939575e+00
    phi[1,0]  R212      -2.3440320491790771e+00
    phi[1,0]  R213      -8.9249891042709351e-01
    phi[1,0]  R214      -3.0345923900604248e+00
    phi[1,0]  R215      -2.8800981044769287e+00
    phi[1,0]  R216      -1.0606863498687744e+00
    phi[1,0]  R217      6.4512640237808228e-01
    phi[1,0]  R218      -3.4161096811294556e-01
    phi[1,0]  R219      -2.4345057085156441e-02
    phi[1,0]  R220      -1.0151368379592896e+00
    phi[1,0]  R221      2.3282326757907867e-01
    phi[1,0]  R222      1.6564947366714478e+00
    phi[1,0]  R223      1.3346179723739624e+00
    phi[1,0]  R224      8.6935126781463623e-01
    phi[1,0]  R225      2.3759746551513672e+00
    phi[1,0]  R226      1.18687105178833
    phi[1,0]  R227      4.4723996520042419e-01
    phi[1,0]  R228      2.5852041244506836e+00
    phi[1,0]  R229      2.9762408733367920e+00
    phi[1,0]  R230      2.4950993061065674e+00
    phi[1,0]  R231      1.3653959333896637e-01
    phi[1,0]  R232      -1.8423606157302856e+00
    phi[1,0]  R233      -2.9243652820587158e+00
    phi[1,0]  R234      -1.0284932851791382e+00
    phi[1,0]  R235      -2.4771654605865479e+00
    phi[1,0]  R236      -2.5056068897247314e+00
    phi[1,0]  R237      -1.4946783781051636e+00
    phi[1,0]  R238      -1.8367550373077393e+00
    phi[1,0]  R239      -0.752835750579834
    phi[1,0]  R240      -1.6402444839477539e+00
    phi[1,0]  R241      1.84006667137146
    phi[1,0]  R242      -1.1930602043867111e-01
    phi[1,0]  R243      -4.2254328727722168e-01
    phi[1,0]  R244      1.2391186952590942e+00
    phi[1,0]  R245      -1.4637634158134460e-01
    phi[1,0]  R246      -1.3424482345581055e+00
    phi[1,0]  R247      -1.3917092084884644e+00
    phi[1,0]  R248      1.5509039163589478e-01
    phi[1,0]  R249      -1.1546980142593384e+00
    phi[1,0]  R250      2.0705714821815491e-01
    phi[1,0]  R251      -1.8370142206549644e-02
    phi[1,0]  R252      -7.0574051141738892e-01
    phi[1,0]  R253      -1.7091115713119507e+00
    phi[1,0]  R254      -7.2450834512710571e-01
    phi[1,0]  R255      -1.7249271869659424e+00
    phi[1,0]  R256      -2.4162245914340019e-02
    phi[1,0]  R257      -2.5587670803070068e+00
    phi[1,0]  R258      -4.0877994894981384e-01
    phi[1,0]  R259      -1.2376141548156738e+00
    phi[1,0]  R260      -1.2744680047035217e-01
    phi[1,0]  R261      -1.7862209081649780e+00
    phi[0,5]  R0        1
    phi[0,5]  R1        1
    phi[0,5]  R45       -1
    phi[0,5]  R262      -3.0999999046325684e+00
    phi[0,5]  R263      -3.0999999046325684e+00
    phi[0,5]  R264      -2.2400000095367432e+00
    phi[0,5]  R265      -2.2400000095367432e+00
    phi[0,5]  R266      -3.0999999046325684e+00
    phi[0,5]  R267      -3.0999999046325684e+00
    phi[0,5]  R268      -2.5699999332427979e+00
    phi[0,5]  R269      -2.5699999332427979e+00
    phi[0,5]  R270      -3.0999999046325684e+00
    phi[0,5]  R271      -3.0999999046325684e+00
    phi[0,5]  R272      -2.0899999141693115e+00
    phi[0,5]  R273      -2.0899999141693115e+00
    phi[0,5]  R274      -3.0999999046325684e+00
    phi[0,5]  R275      -3.0999999046325684e+00
    phi[0,5]  R276      1.6564947366714478e+00
    phi[0,5]  R277      1.3346179723739624e+00
    phi[0,5]  R278      8.6935126781463623e-01
    phi[0,5]  R279      2.3759746551513672e+00
    phi[0,5]  R280      1.18687105178833
    phi[0,5]  R281      4.4723996520042419e-01
    phi[0,5]  R282      2.5852041244506836e+00
    phi[0,5]  R283      2.9762408733367920e+00
    phi[0,5]  R284      2.4950993061065674e+00
    phi[0,5]  R285      1.3653959333896637e-01
    phi[0,5]  R286      -1.8423606157302856e+00
    phi[0,5]  R287      -2.9243652820587158e+00
    phi[0,5]  R288      -1.0284932851791382e+00
    phi[0,5]  R289      -2.4771654605865479e+00
    phi[0,5]  R290      -2.5056068897247314e+00
    phi[0,5]  R291      -1.4946783781051636e+00
    phi[0,5]  R292      -1.8367550373077393e+00
    phi[0,5]  R293      -0.752835750579834
    phi[0,5]  R294      -1.6402444839477539e+00
    phi[0,5]  R295      1.84006667137146
    phi[0,5]  R296      -1.1930602043867111e-01
    phi[0,5]  R297      -4.2254328727722168e-01
    phi[0,5]  R298      1.2391186952590942e+00
    phi[0,5]  R299      -1.4637634158134460e-01
    phi[0,5]  R300      -1.3424482345581055e+00
    phi[0,5]  R301      -1.3917092084884644e+00
    phi[0,5]  R302      1.5509039163589478e-01
    phi[0,5]  R303      -1.1546980142593384e+00
    phi[0,5]  R304      2.0705714821815491e-01
    phi[0,5]  R305      -1.8370142206549644e-02
    phi[0,5]  R306      -7.0574051141738892e-01
    phi[0,5]  R307      -1.7091115713119507e+00
    phi[0,5]  R308      -7.2450834512710571e-01
    phi[0,5]  R309      -1.7249271869659424e+00
    phi[0,5]  R310      -2.4162245914340019e-02
    phi[0,5]  R311      -2.5587670803070068e+00
    phi[0,5]  R312      -4.0877994894981384e-01
    phi[0,5]  R313      -1.2376141548156738e+00
    phi[0,5]  R314      -1.2744680047035217e-01
    phi[0,5]  R315      -1.7862209081649780e+00
    phi[0,5]  R316      -7.9203283786773682e-01
    phi[0,5]  R317      2.8076500892639160e+00
    phi[0,5]  R318      3.0165817737579346e+00
    phi[0,5]  R319      2.8180882930755615e+00
    phi[0,5]  R320      3.3655552864074707e+00
    phi[0,5]  R321      3.0474305152893066e+00
    phi[0,5]  R322      3.2612526416778564e+00
    phi[0,5]  R323      2.6908736228942871e+00
    phi[0,5]  R324      3.0105242729187012e+00
    phi[0,5]  R325      2.8849561214447021e+00
    phi[0,5]  R326      -2.1099472045898438e+00
    phi[0,5]  R327      -1.0483162403106689e+00
    phi[0,5]  R328      -1.6577509641647339e+00
    phi[0,5]  R329      -2.6158449649810791e+00
    phi[0,5]  R330      -2.3549637198448181e-01
    phi[0,5]  R331      -5.0872528553009033e-01
    phi[0,5]  R332      -2.3982350826263428e+00
    phi[0,5]  R333      -2.0925955772399902e+00
    phi[0,5]  R334      -7.0746958255767822e-01
    phi[0,5]  R335      -3.0812611579895020e+00
    phi[0,5]  R336      -4.5784950256347656e-01
    phi[0,5]  R337      -4.6550095081329346e-02
    phi[0,5]  R338      -4.2479839920997620e-01
    phi[0,5]  R339      -1.4490628242492676e+00
    phi[0,5]  R340      -0.874847948551178
    phi[0,5]  R341      -3.5285255908966064e+00
    phi[0,5]  R342      1.1299564503133297e-02
    phi[0,5]  R343      1.02763831615448
    phi[0,5]  R344      -1.3856884837150574e-01
    phi[0,5]  R345      -7.0064926147460938e-01
    phi[0,5]  R346      5.2048754692077637e-01
    phi[0,5]  R347      -2.8572754859924316e+00
    phi[0,5]  R348      -2.2127977013587952e-01
    phi[0,5]  R349      -3.0582771301269531e+00
    phi[0,5]  R350      -6.2147490680217743e-03
    phi[0,5]  R351      3.6245263181626797e-03
    phi[0,5]  R352      -9.4238060712814331e-01
    phi[0,5]  R353      -1.6427754163742065e+00
    phi[0,5]  R354      -1.7337930202484131e+00
    phi[0,5]  R355      -1.7901489734649658e+00
    phi[0,5]  R356      -1.1796261072158813e+00
    phi[0,5]  R357      -2.1728000640869141e+00
    phi[0,5]  R358      -2.7709286212921143e+00
    phi[0,5]  R359      -2.9241403564810753e-02
    phi[0,5]  R360      -1.0765225887298584e+00
    phi[0,5]  R361      -5.0105011463165283e-01
    phi[0,5]  R362      -1.1340914666652679e-01
    phi[0,5]  R363      -1.4461387395858765e+00
    phi[0,5]  R364      -1.57016122341156
    phi[0,5]  R365      -2.1026985645294189e+00
    phi[5,0]  R0        -1
    phi[5,0]  R45       1
    phi[5,0]  R46       1
    phi[5,0]  R366      -3.0999999046325684e+00
    phi[5,0]  R367      -3.0999999046325684e+00
    phi[5,0]  R368      -2.2400000095367432e+00
    phi[5,0]  R369      -2.2400000095367432e+00
    phi[5,0]  R370      -3.0999999046325684e+00
    phi[5,0]  R371      -3.0999999046325684e+00
    phi[5,0]  R372      -2.5699999332427979e+00
    phi[5,0]  R373      -2.5699999332427979e+00
    phi[5,0]  R374      -3.0999999046325684e+00
    phi[5,0]  R375      -3.0999999046325684e+00
    phi[5,0]  R376      -2.0899999141693115e+00
    phi[5,0]  R377      -2.0899999141693115e+00
    phi[5,0]  R378      -3.0999999046325684e+00
    phi[5,0]  R379      -3.0999999046325684e+00
    phi[5,0]  R380      -7.9203283786773682e-01
    phi[5,0]  R381      2.8076500892639160e+00
    phi[5,0]  R382      3.0165817737579346e+00
    phi[5,0]  R383      2.8180882930755615e+00
    phi[5,0]  R384      3.3655552864074707e+00
    phi[5,0]  R385      3.0474305152893066e+00
    phi[5,0]  R386      3.2612526416778564e+00
    phi[5,0]  R387      2.6908736228942871e+00
    phi[5,0]  R388      3.0105242729187012e+00
    phi[5,0]  R389      2.8849561214447021e+00
    phi[5,0]  R390      -2.1099472045898438e+00
    phi[5,0]  R391      -1.0483162403106689e+00
    phi[5,0]  R392      -1.6577509641647339e+00
    phi[5,0]  R393      -2.6158449649810791e+00
    phi[5,0]  R394      -2.3549637198448181e-01
    phi[5,0]  R395      -5.0872528553009033e-01
    phi[5,0]  R396      -2.3982350826263428e+00
    phi[5,0]  R397      -2.0925955772399902e+00
    phi[5,0]  R398      -7.0746958255767822e-01
    phi[5,0]  R399      -3.0812611579895020e+00
    phi[5,0]  R400      -4.5784950256347656e-01
    phi[5,0]  R401      -4.6550095081329346e-02
    phi[5,0]  R402      -4.2479839920997620e-01
    phi[5,0]  R403      -1.4490628242492676e+00
    phi[5,0]  R404      -0.874847948551178
    phi[5,0]  R405      -3.5285255908966064e+00
    phi[5,0]  R406      1.1299564503133297e-02
    phi[5,0]  R407      1.02763831615448
    phi[5,0]  R408      -1.3856884837150574e-01
    phi[5,0]  R409      -7.0064926147460938e-01
    phi[5,0]  R410      5.2048754692077637e-01
    phi[5,0]  R411      -2.8572754859924316e+00
    phi[5,0]  R412      -2.2127977013587952e-01
    phi[5,0]  R413      -3.0582771301269531e+00
    phi[5,0]  R414      -6.2147490680217743e-03
    phi[5,0]  R415      3.6245263181626797e-03
    phi[5,0]  R416      -9.4238060712814331e-01
    phi[5,0]  R417      -1.6427754163742065e+00
    phi[5,0]  R418      -1.7337930202484131e+00
    phi[5,0]  R419      -1.7901489734649658e+00
    phi[5,0]  R420      -1.1796261072158813e+00
    phi[5,0]  R421      -2.1728000640869141e+00
    phi[5,0]  R422      -2.7709286212921143e+00
    phi[5,0]  R423      -2.9241403564810753e-02
    phi[5,0]  R424      -1.0765225887298584e+00
    phi[5,0]  R425      -5.0105011463165283e-01
    phi[5,0]  R426      -1.1340914666652679e-01
    phi[5,0]  R427      -1.4461387395858765e+00
    phi[5,0]  R428      -1.57016122341156
    phi[5,0]  R429      -2.1026985645294189e+00
    phi[5,0]  R430      1.6564947366714478e+00
    phi[5,0]  R431      1.3346179723739624e+00
    phi[5,0]  R432      8.6935126781463623e-01
    phi[5,0]  R433      2.3759746551513672e+00
    phi[5,0]  R434      1.18687105178833
    phi[5,0]  R435      4.4723996520042419e-01
    phi[5,0]  R436      2.5852041244506836e+00
    phi[5,0]  R437      2.9762408733367920e+00
    phi[5,0]  R438      2.4950993061065674e+00
    phi[5,0]  R439      1.3653959333896637e-01
    phi[5,0]  R440      -1.8423606157302856e+00
    phi[5,0]  R441      -2.9243652820587158e+00
    phi[5,0]  R442      -1.0284932851791382e+00
    phi[5,0]  R443      -2.4771654605865479e+00
    phi[5,0]  R444      -2.5056068897247314e+00
    phi[5,0]  R445      -1.4946783781051636e+00
    phi[5,0]  R446      -1.8367550373077393e+00
    phi[5,0]  R447      -0.752835750579834
    phi[5,0]  R448      -1.6402444839477539e+00
    phi[5,0]  R449      1.84006667137146
    phi[5,0]  R450      -1.1930602043867111e-01
    phi[5,0]  R451      -4.2254328727722168e-01
    phi[5,0]  R452      1.2391186952590942e+00
    phi[5,0]  R453      -1.4637634158134460e-01
    phi[5,0]  R454      -1.3424482345581055e+00
    phi[5,0]  R455      -1.3917092084884644e+00
    phi[5,0]  R456      1.5509039163589478e-01
    phi[5,0]  R457      -1.1546980142593384e+00
    phi[5,0]  R458      2.0705714821815491e-01
    phi[5,0]  R459      -1.8370142206549644e-02
    phi[5,0]  R460      -7.0574051141738892e-01
    phi[5,0]  R461      -1.7091115713119507e+00
    phi[5,0]  R462      -7.2450834512710571e-01
    phi[5,0]  R463      -1.7249271869659424e+00
    phi[5,0]  R464      -2.4162245914340019e-02
    phi[5,0]  R465      -2.5587670803070068e+00
    phi[5,0]  R466      -4.0877994894981384e-01
    phi[5,0]  R467      -1.2376141548156738e+00
    phi[5,0]  R468      -1.2744680047035217e-01
    phi[5,0]  R469      -1.7862209081649780e+00
    phi[8,0]  R0        -1
    phi[8,0]  R2        2.6730700195312918e+00
    phi[8,0]  R3        -1.3638672989601659e+00
    phi[8,0]  R4        2.6523768258535685e+00
    phi[8,0]  R5        2.3550335083054450e+00
    phi[8,0]  R6        1.4915130460446560e+00
    phi[8,0]  R7        -1.3152405525902688e+00
    phi[8,0]  R8        3.0287032482341085e+00
    phi[8,0]  R72       1
    phi[8,0]  R470      -5.77306992416386
    phi[8,0]  R471      -4.2692988510127661e-01
    phi[8,0]  R472      -8.7613271057657727e-01
    phi[8,0]  R473      -3.6038673084969091e+00
    phi[8,0]  R474      -5.7523767304861373e+00
    phi[8,0]  R475      -4.4762307877899987e-01
    phi[8,0]  R476      -4.9250334415482424e+00
    phi[8,0]  R477      -2.1496642493735285e-01
    phi[8,0]  R478      -4.5915129506772239e+00
    phi[8,0]  R479      -1.6084868585879124e+00
    phi[8,0]  R480      -7.7475936157904268e-01
    phi[8,0]  R481      -3.4052404667595804e+00
    phi[8,0]  R482      -6.1287031528666773e+00
    phi[8,0]  R483      -7.1296656398459834e-02
    phi[8,0]  R484      -4.6847033167006424e-01
    phi[8,0]  R485      -1.4340947279591028e+00
    phi[8,0]  R486      -1.9503474182405078e-01
    phi[8,0]  R487      -5.4403458618226219e-01
    phi[8,0]  R488      -3.6870082180692543e-01
    phi[8,0]  R489      -3.9851618192948113e-01
    phi[8,0]  R490      -4.1123107918362178e-01
    phi[8,0]  R491      -1.7108159146044537e+00
    phi[8,0]  R492      -0.606387864577949
    phi[8,0]  R493      -4.3797058681793288e-01
    phi[8,0]  R494      -1.0406558303614921e-01
    phi[8,0]  R495      -1.0418393340012866e-01
    phi[8,0]  R496      -1.1400867841307571e-01
    phi[8,0]  R497      -1.1758824194672712e-01
    phi[8,0]  R498      -1.2173138097385250e-01
    phi[8,0]  R499      -1.3414506521135272e-01
    phi[8,0]  R500      -1.3835365305209990e-01
    phi[8,0]  R501      -2.3521154565466040e-01
    phi[8,0]  R502      -2.4604142834010689e-01
    phi[8,0]  R503      -2.4809736629344536e-01
    phi[8,0]  R504      -4.0254379081971475e-01
    phi[8,0]  R505      -0.40572552215838
    phi[8,0]  R506      -4.4354869391875829e-01
    phi[8,0]  R507      -4.5874688146121989e-01
    phi[8,0]  R508      -4.8908128954618535e-01
    phi[8,0]  R509      -4.9151910402857135e-01
    phi[8,0]  R510      -5.0139127538506090e-01
    phi[8,0]  R511      -5.0823188294264932e-01
    phi[8,0]  R512      -5.1849272442907735e-01
    phi[8,0]  R513      -5.3685263973755892e-01
    phi[8,0]  R514      -4.1457581126963794e-01
    phi[8,0]  R515      -4.3024084776205762e-01
    phi[8,0]  R516      -4.3225851994289077e-01
    phi[8,0]  R517      -0.434258809679557
    phi[8,0]  R518      -4.4860275958929818e-01
    phi[8,0]  R519      -4.5097892388633065e-01
    phi[8,0]  R520      -4.5546133221655460e-01
    phi[8,0]  R521      -4.6594651947472865e-01
    phi[8,0]  R522      -4.7103331633870882e-01
    phi[8,0]  R523      -4.8458541970384528e-01
    phi[1,2]  R9        1
    phi[1,2]  R10       1
    phi[1,2]  R18       -1
    phi[1,2]  R524      -3.0999999046325684e+00
    phi[1,2]  R525      -3.0999999046325684e+00
    phi[1,2]  R526      -2.2400000095367432e+00
    phi[1,2]  R527      -2.2400000095367432e+00
    phi[1,2]  R528      -3.0999999046325684e+00
    phi[1,2]  R529      -3.0999999046325684e+00
    phi[1,2]  R530      -2.5699999332427979e+00
    phi[1,2]  R531      -2.5699999332427979e+00
    phi[1,2]  R532      -3.0999999046325684e+00
    phi[1,2]  R533      -3.0999999046325684e+00
    phi[1,2]  R534      -2.0899999141693115e+00
    phi[1,2]  R535      -2.0899999141693115e+00
    phi[1,2]  R536      -3.0999999046325684e+00
    phi[1,2]  R537      -3.0999999046325684e+00
    phi[1,2]  R538      2.4963538646698
    phi[1,2]  R539      1.7336258888244629e+00
    phi[1,2]  R540      1.4955888986587524e+00
    phi[1,2]  R541      1.7211706638336182e+00
    phi[1,2]  R542      2.1004745960235596e+00
    phi[1,2]  R543      -2.2902162075042725e+00
    phi[1,2]  R544      2.5116711854934692e-01
    phi[1,2]  R545      1.2279601097106934e+00
    phi[1,2]  R546      3.4853017330169678e-01
    phi[1,2]  R547      5.7756072282791138e-01
    phi[1,2]  R548      -1.2942359447479248e+00
    phi[1,2]  R549      -1.4284121990203857e+00
    phi[1,2]  R550      -2.7967376708984375e+00
    phi[1,2]  R551      -2.5418975353240967e+00
    phi[1,2]  R552      -2.2268667221069336e+00
    phi[1,2]  R553      -1.3170238733291626e+00
    phi[1,2]  R554      -2.1494996547698975e+00
    phi[1,2]  R555      -2.9085350036621094e+00
    phi[1,2]  R556      -1.8219076395034790e+00
    phi[1,2]  R557      -2.2166464328765869e+00
    phi[1,2]  R558      -8.3626079559326172e-01
    phi[1,2]  R559      -3.2189896106719971e+00
    phi[1,2]  R560      -6.7499846220016479e-01
    phi[1,2]  R561      -2.5502939224243164e+00
    phi[1,2]  R562      -2.1119406223297119e+00
    phi[1,2]  R563      -1.5659917593002319e+00
    phi[1,2]  R564      -2.9926688671112061e+00
    phi[1,2]  R565      -1.9912683963775635e+00
    phi[1,2]  R566      1.7624202966690063e+00
    phi[1,2]  R567      1.7676345109939575e+00
    phi[1,2]  R568      -2.3440320491790771e+00
    phi[1,2]  R569      -8.9249891042709351e-01
    phi[1,2]  R570      -3.0345923900604248e+00
    phi[1,2]  R571      -2.8800981044769287e+00
    phi[1,2]  R572      -1.0606863498687744e+00
    phi[1,2]  R573      6.4512640237808228e-01
    phi[1,2]  R574      -3.4161096811294556e-01
    phi[1,2]  R575      -2.4345057085156441e-02
    phi[1,2]  R576      -1.0151368379592896e+00
    phi[1,2]  R577      2.3282326757907867e-01
    phi[1,2]  R578      2.1197950839996338e+00
    phi[1,2]  R579      -4.6676233410835266e-01
    phi[1,2]  R580      1.6533249616622925e+00
    phi[1,2]  R581      2.0244536399841309e+00
    phi[1,2]  R582      7.7039963006973267e-01
    phi[1,2]  R583      1.0261783599853516e+00
    phi[1,2]  R584      1.2414619922637939e+00
    phi[1,2]  R585      7.8290677070617676e-01
    phi[1,2]  R586      1.9078036546707153e+00
    phi[1,2]  R587      9.5701926946640015e-01
    phi[1,2]  R588      -5.0059032440185547e-01
    phi[1,2]  R589      -4.3575830757617950e-02
    phi[1,2]  R590      -1.4893896877765656e-02
    phi[1,2]  R591      -0.803838849067688
    phi[1,2]  R592      -5.8150053024291992e-01
    phi[1,2]  R593      -2.2847583293914795e+00
    phi[1,2]  R594      -0.665794849395752
    phi[1,2]  R595      -0.515534520149231
    phi[1,2]  R596      -8.2614880800247192e-01
    phi[1,2]  R597      -4.5291891694068909e-01
    phi[1,2]  R598      1.2773519754409790e+00
    phi[1,2]  R599      1.1285821348428726e-01
    phi[1,2]  R600      2.1221715211868286e-01
    phi[1,2]  R601      -5.4068940877914429e-01
    phi[1,2]  R602      0.590824544429779
    phi[1,2]  R603      2.8898048400878906e-01
    phi[1,2]  R604      1.2221070528030396e+00
    phi[1,2]  R605      1.1933321952819824e+00
    phi[1,2]  R606      4.6545732021331787e-01
    phi[1,2]  R607      -1.0754680633544922e+00
    phi[1,2]  R608      9.3244779109954834e-01
    phi[1,2]  R609      1.1488258838653564e+00
    phi[1,2]  R610      -5.8189302682876587e-02
    phi[1,2]  R611      -0.63921719789505
    phi[1,2]  R612      -7.9432809352874756e-01
    phi[1,2]  R613      -4.6961358189582825e-01
    phi[1,2]  R614      6.3534080982208252e-02
    phi[1,2]  R615      1.4696875810623169e+00
    phi[1,2]  R616      -5.3359043598175049e-01
    phi[1,2]  R617      6.5221649408340454e-01
    phi[1,2]  R618      6.3565564155578613e-01
    phi[1,2]  R619      1.3922302424907684e-01
    phi[1,2]  R620      4.3781468272209167e-01
    phi[1,2]  R621      2.5270313024520874e-01
    phi[1,2]  R622      -8.3853268623352051e-01
    phi[1,2]  R623      -1.6926175355911255e+00
    phi[1,2]  R624      -2.6292076110839844e+00
    phi[1,2]  R625      -3.0480229854583740e+00
    phi[1,2]  R626      -3.0172970294952393e+00
    phi[1,2]  R627      -2.9488623142242432e+00
    phi[1,2]  R628      2.7361735701560974e-01
    phi[1,2]  R629      9.2382073402404785e-01
    phi[1,2]  R630      -5.6101256608963013e-01
    phi[1,2]  R631      1.6019386053085327e+00
    phi[1,2]  R632      -2.0925931930541992e+00
    phi[1,2]  R633      -2.7360360622406006e+00
    phi[1,2]  R634      -2.2106952667236328e+00
    phi[1,2]  R635      -2.3042569160461426e+00
    phi[1,2]  R636      -2.6972279548645020e+00
    phi[1,2]  R637      -2.4539868831634521e+00
    phi[2,1]  R9        -1
    phi[2,1]  R18       1
    phi[2,1]  R19       1
    phi[2,1]  R638      -3.0999999046325684e+00
    phi[2,1]  R639      -3.0999999046325684e+00
    phi[2,1]  R640      -2.2400000095367432e+00
    phi[2,1]  R641      -2.2400000095367432e+00
    phi[2,1]  R642      -3.0999999046325684e+00
    phi[2,1]  R643      -3.0999999046325684e+00
    phi[2,1]  R644      -2.5699999332427979e+00
    phi[2,1]  R645      -2.5699999332427979e+00
    phi[2,1]  R646      -3.0999999046325684e+00
    phi[2,1]  R647      -3.0999999046325684e+00
    phi[2,1]  R648      -2.0899999141693115e+00
    phi[2,1]  R649      -2.0899999141693115e+00
    phi[2,1]  R650      -3.0999999046325684e+00
    phi[2,1]  R651      -3.0999999046325684e+00
    phi[2,1]  R652      2.1197950839996338e+00
    phi[2,1]  R653      -4.6676233410835266e-01
    phi[2,1]  R654      1.6533249616622925e+00
    phi[2,1]  R655      2.0244536399841309e+00
    phi[2,1]  R656      7.7039963006973267e-01
    phi[2,1]  R657      1.0261783599853516e+00
    phi[2,1]  R658      1.2414619922637939e+00
    phi[2,1]  R659      7.8290677070617676e-01
    phi[2,1]  R660      1.9078036546707153e+00
    phi[2,1]  R661      9.5701926946640015e-01
    phi[2,1]  R662      -5.0059032440185547e-01
    phi[2,1]  R663      -4.3575830757617950e-02
    phi[2,1]  R664      -1.4893896877765656e-02
    phi[2,1]  R665      -0.803838849067688
    phi[2,1]  R666      -5.8150053024291992e-01
    phi[2,1]  R667      -2.2847583293914795e+00
    phi[2,1]  R668      -0.665794849395752
    phi[2,1]  R669      -0.515534520149231
    phi[2,1]  R670      -8.2614880800247192e-01
    phi[2,1]  R671      -4.5291891694068909e-01
    phi[2,1]  R672      1.2773519754409790e+00
    phi[2,1]  R673      1.1285821348428726e-01
    phi[2,1]  R674      2.1221715211868286e-01
    phi[2,1]  R675      -5.4068940877914429e-01
    phi[2,1]  R676      0.590824544429779
    phi[2,1]  R677      2.8898048400878906e-01
    phi[2,1]  R678      1.2221070528030396e+00
    phi[2,1]  R679      1.1933321952819824e+00
    phi[2,1]  R680      4.6545732021331787e-01
    phi[2,1]  R681      -1.0754680633544922e+00
    phi[2,1]  R682      9.3244779109954834e-01
    phi[2,1]  R683      1.1488258838653564e+00
    phi[2,1]  R684      -5.8189302682876587e-02
    phi[2,1]  R685      -0.63921719789505
    phi[2,1]  R686      -7.9432809352874756e-01
    phi[2,1]  R687      -4.6961358189582825e-01
    phi[2,1]  R688      6.3534080982208252e-02
    phi[2,1]  R689      1.4696875810623169e+00
    phi[2,1]  R690      -5.3359043598175049e-01
    phi[2,1]  R691      6.5221649408340454e-01
    phi[2,1]  R692      6.3565564155578613e-01
    phi[2,1]  R693      1.3922302424907684e-01
    phi[2,1]  R694      4.3781468272209167e-01
    phi[2,1]  R695      2.5270313024520874e-01
    phi[2,1]  R696      -8.3853268623352051e-01
    phi[2,1]  R697      -1.6926175355911255e+00
    phi[2,1]  R698      -2.6292076110839844e+00
    phi[2,1]  R699      -3.0480229854583740e+00
    phi[2,1]  R700      -3.0172970294952393e+00
    phi[2,1]  R701      -2.9488623142242432e+00
    phi[2,1]  R702      2.7361735701560974e-01
    phi[2,1]  R703      9.2382073402404785e-01
    phi[2,1]  R704      -5.6101256608963013e-01
    phi[2,1]  R705      1.6019386053085327e+00
    phi[2,1]  R706      -2.0925931930541992e+00
    phi[2,1]  R707      -2.7360360622406006e+00
    phi[2,1]  R708      -2.2106952667236328e+00
    phi[2,1]  R709      -2.3042569160461426e+00
    phi[2,1]  R710      -2.6972279548645020e+00
    phi[2,1]  R711      -2.4539868831634521e+00
    phi[2,1]  R712      2.4963538646698
    phi[2,1]  R713      1.7336258888244629e+00
    phi[2,1]  R714      1.4955888986587524e+00
    phi[2,1]  R715      1.7211706638336182e+00
    phi[2,1]  R716      2.1004745960235596e+00
    phi[2,1]  R717      -2.2902162075042725e+00
    phi[2,1]  R718      2.5116711854934692e-01
    phi[2,1]  R719      1.2279601097106934e+00
    phi[2,1]  R720      3.4853017330169678e-01
    phi[2,1]  R721      5.7756072282791138e-01
    phi[2,1]  R722      -1.2942359447479248e+00
    phi[2,1]  R723      -1.4284121990203857e+00
    phi[2,1]  R724      -2.7967376708984375e+00
    phi[2,1]  R725      -2.5418975353240967e+00
    phi[2,1]  R726      -2.2268667221069336e+00
    phi[2,1]  R727      -1.3170238733291626e+00
    phi[2,1]  R728      -2.1494996547698975e+00
    phi[2,1]  R729      -2.9085350036621094e+00
    phi[2,1]  R730      -1.8219076395034790e+00
    phi[2,1]  R731      -2.2166464328765869e+00
    phi[2,1]  R732      -8.3626079559326172e-01
    phi[2,1]  R733      -3.2189896106719971e+00
    phi[2,1]  R734      -6.7499846220016479e-01
    phi[2,1]  R735      -2.5502939224243164e+00
    phi[2,1]  R736      -2.1119406223297119e+00
    phi[2,1]  R737      -1.5659917593002319e+00
    phi[2,1]  R738      -2.9926688671112061e+00
    phi[2,1]  R739      -1.9912683963775635e+00
    phi[2,1]  R740      1.7624202966690063e+00
    phi[2,1]  R741      1.7676345109939575e+00
    phi[2,1]  R742      -2.3440320491790771e+00
    phi[2,1]  R743      -8.9249891042709351e-01
    phi[2,1]  R744      -3.0345923900604248e+00
    phi[2,1]  R745      -2.8800981044769287e+00
    phi[2,1]  R746      -1.0606863498687744e+00
    phi[2,1]  R747      6.4512640237808228e-01
    phi[2,1]  R748      -3.4161096811294556e-01
    phi[2,1]  R749      -2.4345057085156441e-02
    phi[2,1]  R750      -1.0151368379592896e+00
    phi[2,1]  R751      2.3282326757907867e-01
    phi[2,3]  R18       1
    phi[2,3]  R19       1
    phi[2,3]  R27       -1
    phi[2,3]  R752      -3.0999999046325684e+00
    phi[2,3]  R753      -3.0999999046325684e+00
    phi[2,3]  R754      -2.2400000095367432e+00
    phi[2,3]  R755      -2.2400000095367432e+00
    phi[2,3]  R756      -3.0999999046325684e+00
    phi[2,3]  R757      -3.0999999046325684e+00
    phi[2,3]  R758      -2.5699999332427979e+00
    phi[2,3]  R759      -2.5699999332427979e+00
    phi[2,3]  R760      -3.0999999046325684e+00
    phi[2,3]  R761      -3.0999999046325684e+00
    phi[2,3]  R762      -2.0899999141693115e+00
    phi[2,3]  R763      -2.0899999141693115e+00
    phi[2,3]  R764      -3.0999999046325684e+00
    phi[2,3]  R765      -3.0999999046325684e+00
    phi[2,3]  R766      2.1197950839996338e+00
    phi[2,3]  R767      -4.6676233410835266e-01
    phi[2,3]  R768      1.6533249616622925e+00
    phi[2,3]  R769      2.0244536399841309e+00
    phi[2,3]  R770      7.7039963006973267e-01
    phi[2,3]  R771      1.0261783599853516e+00
    phi[2,3]  R772      1.2414619922637939e+00
    phi[2,3]  R773      7.8290677070617676e-01
    phi[2,3]  R774      1.9078036546707153e+00
    phi[2,3]  R775      9.5701926946640015e-01
    phi[2,3]  R776      -5.0059032440185547e-01
    phi[2,3]  R777      -4.3575830757617950e-02
    phi[2,3]  R778      -1.4893896877765656e-02
    phi[2,3]  R779      -0.803838849067688
    phi[2,3]  R780      -5.8150053024291992e-01
    phi[2,3]  R781      -2.2847583293914795e+00
    phi[2,3]  R782      -0.665794849395752
    phi[2,3]  R783      -0.515534520149231
    phi[2,3]  R784      -8.2614880800247192e-01
    phi[2,3]  R785      -4.5291891694068909e-01
    phi[2,3]  R786      1.2773519754409790e+00
    phi[2,3]  R787      1.1285821348428726e-01
    phi[2,3]  R788      2.1221715211868286e-01
    phi[2,3]  R789      -5.4068940877914429e-01
    phi[2,3]  R790      0.590824544429779
    phi[2,3]  R791      2.8898048400878906e-01
    phi[2,3]  R792      1.2221070528030396e+00
    phi[2,3]  R793      1.1933321952819824e+00
    phi[2,3]  R794      4.6545732021331787e-01
    phi[2,3]  R795      -1.0754680633544922e+00
    phi[2,3]  R796      9.3244779109954834e-01
    phi[2,3]  R797      1.1488258838653564e+00
    phi[2,3]  R798      -5.8189302682876587e-02
    phi[2,3]  R799      -0.63921719789505
    phi[2,3]  R800      -7.9432809352874756e-01
    phi[2,3]  R801      -4.6961358189582825e-01
    phi[2,3]  R802      6.3534080982208252e-02
    phi[2,3]  R803      1.4696875810623169e+00
    phi[2,3]  R804      -5.3359043598175049e-01
    phi[2,3]  R805      6.5221649408340454e-01
    phi[2,3]  R806      6.3565564155578613e-01
    phi[2,3]  R807      1.3922302424907684e-01
    phi[2,3]  R808      4.3781468272209167e-01
    phi[2,3]  R809      2.5270313024520874e-01
    phi[2,3]  R810      -8.3853268623352051e-01
    phi[2,3]  R811      -1.6926175355911255e+00
    phi[2,3]  R812      -2.6292076110839844e+00
    phi[2,3]  R813      -3.0480229854583740e+00
    phi[2,3]  R814      -3.0172970294952393e+00
    phi[2,3]  R815      -2.9488623142242432e+00
    phi[2,3]  R816      2.7361735701560974e-01
    phi[2,3]  R817      9.2382073402404785e-01
    phi[2,3]  R818      -5.6101256608963013e-01
    phi[2,3]  R819      1.6019386053085327e+00
    phi[2,3]  R820      -2.0925931930541992e+00
    phi[2,3]  R821      -2.7360360622406006e+00
    phi[2,3]  R822      -2.2106952667236328e+00
    phi[2,3]  R823      -2.3042569160461426e+00
    phi[2,3]  R824      -2.6972279548645020e+00
    phi[2,3]  R825      -2.4539868831634521e+00
    phi[2,3]  R826      -6.0127913951873779e-01
    phi[2,3]  R827      8.3502340316772461e-01
    phi[2,3]  R828      -2.0470929145812988e+00
    phi[2,3]  R829      1.8222750425338745e+00
    phi[2,3]  R830      1.5682909488677979e+00
    phi[2,3]  R831      -1.2726160287857056e+00
    phi[2,3]  R832      9.3972188234329224e-01
    phi[2,3]  R833      -4.2007541656494141e-01
    phi[2,3]  R834      2.2586163878440857e-01
    phi[2,3]  R835      1.6131587028503418e+00
    phi[2,3]  R836      2.2400949895381927e-01
    phi[2,3]  R837      1.4532764256000519e-01
    phi[2,3]  R838      -0.922102689743042
    phi[2,3]  R839      1.7070409655570984e-01
    phi[2,3]  R840      -2.0932962000370026e-01
    phi[2,3]  R841      5.5579423904418945e-01
    phi[2,3]  R842      -6.0878914594650269e-01
    phi[2,3]  R843      8.9603118598461151e-02
    phi[2,3]  R844      -0.59317547082901
    phi[2,3]  R845      -0.616935133934021
    phi[2,3]  R846      1.3413868844509125e-01
    phi[2,3]  R847      1.2124543190002441e+00
    phi[2,3]  R848      -1.2365154027938843e+00
    phi[2,3]  R849      -2.5582343339920044e-01
    phi[2,3]  R850      -5.2891987562179565e-01
    phi[2,3]  R851      -1.5389494895935059e+00
    phi[2,3]  R852      -8.1017494201660156e-01
    phi[2,3]  R853      -8.5589474439620972e-01
    phi[2,3]  R854      -5.8916163444519043e-01
    phi[2,3]  R855      -2.4055716991424561e+00
    phi[2,3]  R856      1.1067247390747070e+00
    phi[2,3]  R857      4.4351585209369659e-02
    phi[2,3]  R858      -2.0250127315521240e+00
    phi[2,3]  R859      -3.1699259281158447e+00
    phi[2,3]  R860      -2.6480793952941895e+00
    phi[2,3]  R861      6.2676256895065308e-01
    phi[2,3]  R862      -9.5934592187404633e-02
    phi[2,3]  R863      7.2592014074325562e-01
    phi[2,3]  R864      -2.1384713649749756e+00
    phi[2,3]  R865      2.3172160983085632e-01
    phi[2,3]  R866      9.8537737131118774e-01
    phi[2,3]  R867      -2.2080218791961670e+00
    phi[2,3]  R868      -9.2432558536529541e-01
    phi[2,3]  R869      -3.08270001411438
    phi[2,3]  R870      1.9859695434570312e-01
    phi[2,3]  R871      1.1946005821228027e+00
    phi[2,3]  R872      -1.6553881168365479e+00
    phi[2,3]  R873      -6.1663128435611725e-02
    phi[2,3]  R874      -1.6640714406967163e+00
    phi[2,3]  R875      2.9824355244636536e-01
    phi[3,2]  R18       -1
    phi[3,2]  R27       1
    phi[3,2]  R28       1
    phi[3,2]  R876      -3.0999999046325684e+00
    phi[3,2]  R877      -3.0999999046325684e+00
    phi[3,2]  R878      -2.2400000095367432e+00
    phi[3,2]  R879      -2.2400000095367432e+00
    phi[3,2]  R880      -3.0999999046325684e+00
    phi[3,2]  R881      -3.0999999046325684e+00
    phi[3,2]  R882      -2.5699999332427979e+00
    phi[3,2]  R883      -2.5699999332427979e+00
    phi[3,2]  R884      -3.0999999046325684e+00
    phi[3,2]  R885      -3.0999999046325684e+00
    phi[3,2]  R886      -2.0899999141693115e+00
    phi[3,2]  R887      -2.0899999141693115e+00
    phi[3,2]  R888      -3.0999999046325684e+00
    phi[3,2]  R889      -3.0999999046325684e+00
    phi[3,2]  R890      -6.0127913951873779e-01
    phi[3,2]  R891      8.3502340316772461e-01
    phi[3,2]  R892      -2.0470929145812988e+00
    phi[3,2]  R893      1.8222750425338745e+00
    phi[3,2]  R894      1.5682909488677979e+00
    phi[3,2]  R895      -1.2726160287857056e+00
    phi[3,2]  R896      9.3972188234329224e-01
    phi[3,2]  R897      -4.2007541656494141e-01
    phi[3,2]  R898      2.2586163878440857e-01
    phi[3,2]  R899      1.6131587028503418e+00
    phi[3,2]  R900      2.2400949895381927e-01
    phi[3,2]  R901      1.4532764256000519e-01
    phi[3,2]  R902      -0.922102689743042
    phi[3,2]  R903      1.7070409655570984e-01
    phi[3,2]  R904      -2.0932962000370026e-01
    phi[3,2]  R905      5.5579423904418945e-01
    phi[3,2]  R906      -6.0878914594650269e-01
    phi[3,2]  R907      8.9603118598461151e-02
    phi[3,2]  R908      -0.59317547082901
    phi[3,2]  R909      -0.616935133934021
    phi[3,2]  R910      1.3413868844509125e-01
    phi[3,2]  R911      1.2124543190002441e+00
    phi[3,2]  R912      -1.2365154027938843e+00
    phi[3,2]  R913      -2.5582343339920044e-01
    phi[3,2]  R914      -5.2891987562179565e-01
    phi[3,2]  R915      -1.5389494895935059e+00
    phi[3,2]  R916      -8.1017494201660156e-01
    phi[3,2]  R917      -8.5589474439620972e-01
    phi[3,2]  R918      -5.8916163444519043e-01
    phi[3,2]  R919      -2.4055716991424561e+00
    phi[3,2]  R920      1.1067247390747070e+00
    phi[3,2]  R921      4.4351585209369659e-02
    phi[3,2]  R922      -2.0250127315521240e+00
    phi[3,2]  R923      -3.1699259281158447e+00
    phi[3,2]  R924      -2.6480793952941895e+00
    phi[3,2]  R925      6.2676256895065308e-01
    phi[3,2]  R926      -9.5934592187404633e-02
    phi[3,2]  R927      7.2592014074325562e-01
    phi[3,2]  R928      -2.1384713649749756e+00
    phi[3,2]  R929      2.3172160983085632e-01
    phi[3,2]  R930      9.8537737131118774e-01
    phi[3,2]  R931      -2.2080218791961670e+00
    phi[3,2]  R932      -9.2432558536529541e-01
    phi[3,2]  R933      -3.08270001411438
    phi[3,2]  R934      1.9859695434570312e-01
    phi[3,2]  R935      1.1946005821228027e+00
    phi[3,2]  R936      -1.6553881168365479e+00
    phi[3,2]  R937      -6.1663128435611725e-02
    phi[3,2]  R938      -1.6640714406967163e+00
    phi[3,2]  R939      2.9824355244636536e-01
    phi[3,2]  R940      2.1197950839996338e+00
    phi[3,2]  R941      -4.6676233410835266e-01
    phi[3,2]  R942      1.6533249616622925e+00
    phi[3,2]  R943      2.0244536399841309e+00
    phi[3,2]  R944      7.7039963006973267e-01
    phi[3,2]  R945      1.0261783599853516e+00
    phi[3,2]  R946      1.2414619922637939e+00
    phi[3,2]  R947      7.8290677070617676e-01
    phi[3,2]  R948      1.9078036546707153e+00
    phi[3,2]  R949      9.5701926946640015e-01
    phi[3,2]  R950      -5.0059032440185547e-01
    phi[3,2]  R951      -4.3575830757617950e-02
    phi[3,2]  R952      -1.4893896877765656e-02
    phi[3,2]  R953      -0.803838849067688
    phi[3,2]  R954      -5.8150053024291992e-01
    phi[3,2]  R955      -2.2847583293914795e+00
    phi[3,2]  R956      -0.665794849395752
    phi[3,2]  R957      -0.515534520149231
    phi[3,2]  R958      -8.2614880800247192e-01
    phi[3,2]  R959      -4.5291891694068909e-01
    phi[3,2]  R960      1.2773519754409790e+00
    phi[3,2]  R961      1.1285821348428726e-01
    phi[3,2]  R962      2.1221715211868286e-01
    phi[3,2]  R963      -5.4068940877914429e-01
    phi[3,2]  R964      0.590824544429779
    phi[3,2]  R965      2.8898048400878906e-01
    phi[3,2]  R966      1.2221070528030396e+00
    phi[3,2]  R967      1.1933321952819824e+00
    phi[3,2]  R968      4.6545732021331787e-01
    phi[3,2]  R969      -1.0754680633544922e+00
    phi[3,2]  R970      9.3244779109954834e-01
    phi[3,2]  R971      1.1488258838653564e+00
    phi[3,2]  R972      -5.8189302682876587e-02
    phi[3,2]  R973      -0.63921719789505
    phi[3,2]  R974      -7.9432809352874756e-01
    phi[3,2]  R975      -4.6961358189582825e-01
    phi[3,2]  R976      6.3534080982208252e-02
    phi[3,2]  R977      1.4696875810623169e+00
    phi[3,2]  R978      -5.3359043598175049e-01
    phi[3,2]  R979      6.5221649408340454e-01
    phi[3,2]  R980      6.3565564155578613e-01
    phi[3,2]  R981      1.3922302424907684e-01
    phi[3,2]  R982      4.3781468272209167e-01
    phi[3,2]  R983      2.5270313024520874e-01
    phi[3,2]  R984      -8.3853268623352051e-01
    phi[3,2]  R985      -1.6926175355911255e+00
    phi[3,2]  R986      -2.6292076110839844e+00
    phi[3,2]  R987      -3.0480229854583740e+00
    phi[3,2]  R988      -3.0172970294952393e+00
    phi[3,2]  R989      -2.9488623142242432e+00
    phi[3,2]  R990      2.7361735701560974e-01
    phi[3,2]  R991      9.2382073402404785e-01
    phi[3,2]  R992      -5.6101256608963013e-01
    phi[3,2]  R993      1.6019386053085327e+00
    phi[3,2]  R994      -2.0925931930541992e+00
    phi[3,2]  R995      -2.7360360622406006e+00
    phi[3,2]  R996      -2.2106952667236328e+00
    phi[3,2]  R997      -2.3042569160461426e+00
    phi[3,2]  R998      -2.6972279548645020e+00
    phi[3,2]  R999      -2.4539868831634521e+00
    phi[3,4]  R27       1
    phi[3,4]  R28       1
    phi[3,4]  R36       -1
    phi[3,4]  R1000     -3.0999999046325684e+00
    phi[3,4]  R1001     -3.0999999046325684e+00
    phi[3,4]  R1002     -2.2400000095367432e+00
    phi[3,4]  R1003     -2.2400000095367432e+00
    phi[3,4]  R1004     -3.0999999046325684e+00
    phi[3,4]  R1005     -3.0999999046325684e+00
    phi[3,4]  R1006     -2.5699999332427979e+00
    phi[3,4]  R1007     -2.5699999332427979e+00
    phi[3,4]  R1008     -3.0999999046325684e+00
    phi[3,4]  R1009     -3.0999999046325684e+00
    phi[3,4]  R1010     -2.0899999141693115e+00
    phi[3,4]  R1011     -2.0899999141693115e+00
    phi[3,4]  R1012     -3.0999999046325684e+00
    phi[3,4]  R1013     -3.0999999046325684e+00
    phi[3,4]  R1014     -6.0127913951873779e-01
    phi[3,4]  R1015     8.3502340316772461e-01
    phi[3,4]  R1016     -2.0470929145812988e+00
    phi[3,4]  R1017     1.8222750425338745e+00
    phi[3,4]  R1018     1.5682909488677979e+00
    phi[3,4]  R1019     -1.2726160287857056e+00
    phi[3,4]  R1020     9.3972188234329224e-01
    phi[3,4]  R1021     -4.2007541656494141e-01
    phi[3,4]  R1022     2.2586163878440857e-01
    phi[3,4]  R1023     1.6131587028503418e+00
    phi[3,4]  R1024     2.2400949895381927e-01
    phi[3,4]  R1025     1.4532764256000519e-01
    phi[3,4]  R1026     -0.922102689743042
    phi[3,4]  R1027     1.7070409655570984e-01
    phi[3,4]  R1028     -2.0932962000370026e-01
    phi[3,4]  R1029     5.5579423904418945e-01
    phi[3,4]  R1030     -6.0878914594650269e-01
    phi[3,4]  R1031     8.9603118598461151e-02
    phi[3,4]  R1032     -0.59317547082901
    phi[3,4]  R1033     -0.616935133934021
    phi[3,4]  R1034     1.3413868844509125e-01
    phi[3,4]  R1035     1.2124543190002441e+00
    phi[3,4]  R1036     -1.2365154027938843e+00
    phi[3,4]  R1037     -2.5582343339920044e-01
    phi[3,4]  R1038     -5.2891987562179565e-01
    phi[3,4]  R1039     -1.5389494895935059e+00
    phi[3,4]  R1040     -8.1017494201660156e-01
    phi[3,4]  R1041     -8.5589474439620972e-01
    phi[3,4]  R1042     -5.8916163444519043e-01
    phi[3,4]  R1043     -2.4055716991424561e+00
    phi[3,4]  R1044     1.1067247390747070e+00
    phi[3,4]  R1045     4.4351585209369659e-02
    phi[3,4]  R1046     -2.0250127315521240e+00
    phi[3,4]  R1047     -3.1699259281158447e+00
    phi[3,4]  R1048     -2.6480793952941895e+00
    phi[3,4]  R1049     6.2676256895065308e-01
    phi[3,4]  R1050     -9.5934592187404633e-02
    phi[3,4]  R1051     7.2592014074325562e-01
    phi[3,4]  R1052     -2.1384713649749756e+00
    phi[3,4]  R1053     2.3172160983085632e-01
    phi[3,4]  R1054     9.8537737131118774e-01
    phi[3,4]  R1055     -2.2080218791961670e+00
    phi[3,4]  R1056     -9.2432558536529541e-01
    phi[3,4]  R1057     -3.08270001411438
    phi[3,4]  R1058     1.9859695434570312e-01
    phi[3,4]  R1059     1.1946005821228027e+00
    phi[3,4]  R1060     -1.6553881168365479e+00
    phi[3,4]  R1061     -6.1663128435611725e-02
    phi[3,4]  R1062     -1.6640714406967163e+00
    phi[3,4]  R1063     2.9824355244636536e-01
    phi[3,4]  R1064     1.5045989751815796e+00
    phi[3,4]  R1065     1.5220741033554077e+00
    phi[3,4]  R1066     5.8739924430847168e-01
    phi[3,4]  R1067     7.1256154775619507e-01
    phi[3,4]  R1068     2.6825663447380066e-01
    phi[3,4]  R1069     3.5873398184776306e-01
    phi[3,4]  R1070     -2.4466846883296967e-01
    phi[3,4]  R1071     -5.9392881393432617e-01
    phi[3,4]  R1072     -1.1557391881942749e+00
    phi[3,4]  R1073     2.5101512670516968e-01
    phi[3,4]  R1074     -2.4855144023895264e+00
    phi[3,4]  R1075     -1.9049099683761597e+00
    phi[3,4]  R1076     -2.4922461509704590e+00
    phi[3,4]  R1077     -2.8483734130859375e+00
    phi[3,4]  R1078     1.4229370653629303e-01
    phi[3,4]  R1079     5.6601548194885254e-01
    phi[3,4]  R1080     1.8343603610992432e-01
    phi[3,4]  R1081     5.9229516983032227e-01
    phi[3,4]  R1082     9.5646090805530548e-02
    phi[3,4]  R1083     3.2936373353004456e-01
    phi[3,4]  R1084     -3.7549573183059692e-01
    phi[3,4]  R1085     -1.1558514833450317e+00
    phi[3,4]  R1086     -2.4432773590087891e+00
    phi[3,4]  R1087     -2.0732848644256592e+00
    phi[3,4]  R1088     -4.4600442051887512e-01
    phi[3,4]  R1089     -6.6851258277893066e-02
    phi[3,4]  R1090     6.4099490642547607e-01
    phi[3,4]  R1091     -8.7897628545761108e-01
    phi[3,4]  R1092     -4.4537064433097839e-01
    phi[3,4]  R1093     -8.5385537147521973e-01
    phi[3,4]  R1094     -2.3176872730255127e+00
    phi[3,4]  R1095     -1.2443329095840454e+00
    phi[3,4]  R1096     -1.1867657899856567e+00
    phi[3,4]  R1097     6.4987844228744507e-01
    phi[3,4]  R1098     -6.3331216573715210e-01
    phi[3,4]  R1099     -1.0701813697814941e+00
    phi[3,4]  R1100     -9.7028493881225586e-01
    phi[3,4]  R1101     -2.4551652371883392e-01
    phi[3,4]  R1102     2.8793570399284363e-01
    phi[3,4]  R1103     -8.9878535270690918e-01
    phi[3,4]  R1104     0.468716561794281
    phi[3,4]  R1105     7.8344339132308960e-01
    phi[3,4]  R1106     -8.9435532689094543e-02
    phi[3,4]  R1107     -1.1695630550384521e+00
    phi[3,4]  R1108     6.2263929843902588e-01
    phi[3,4]  R1109     9.3650954961776733e-01
    phi[3,4]  R1110     -1.1683062314987183e+00
    phi[3,4]  R1111     6.3178151845932007e-01
    phi[3,4]  R1112     0.830464780330658
    phi[3,4]  R1113     1.21615469455719
    phi[3,4]  R1114     -1.1541399955749512e+00
    phi[3,4]  R1115     -1.0033031702041626e+00
    phi[3,4]  R1116     -7.4603313207626343e-01
    phi[3,4]  R1117     -6.0793179273605347e-01
    phi[3,4]  R1118     -1.3629381656646729e+00
    phi[3,4]  R1119     -1.4116891622543335e+00
    phi[3,4]  R1120     -1.2548942565917969e+00
    phi[3,4]  R1121     -1.4926064014434814e+00
    phi[3,4]  R1122     -1.6693766117095947e+00
    phi[3,4]  R1123     7.9330521821975708e-01
    phi[3,4]  R1124     -2.0348151028156281e-01
    phi[3,4]  R1125     -6.3870096206665039e-01
    phi[3,4]  R1126     -1.14873206615448
    phi[3,4]  R1127     -9.2933970689773560e-01
    phi[3,4]  R1128     -1.1345375776290894e+00
    phi[3,4]  R1129     -7.1445268392562866e-01
    phi[3,4]  R1130     0.0982760339975357
    phi[3,4]  R1131     1.7573084831237793e+00
    phi[3,4]  R1132     -2.2952699661254883e-01
    phi[3,4]  R1133     -1.4391747713088989e+00
    phi[4,3]  R27       -1
    phi[4,3]  R36       1
    phi[4,3]  R37       1
    phi[4,3]  R1134     -3.0999999046325684e+00
    phi[4,3]  R1135     -3.0999999046325684e+00
    phi[4,3]  R1136     -2.2400000095367432e+00
    phi[4,3]  R1137     -2.2400000095367432e+00
    phi[4,3]  R1138     -3.0999999046325684e+00
    phi[4,3]  R1139     -3.0999999046325684e+00
    phi[4,3]  R1140     -2.5699999332427979e+00
    phi[4,3]  R1141     -2.5699999332427979e+00
    phi[4,3]  R1142     -3.0999999046325684e+00
    phi[4,3]  R1143     -3.0999999046325684e+00
    phi[4,3]  R1144     -2.0899999141693115e+00
    phi[4,3]  R1145     -2.0899999141693115e+00
    phi[4,3]  R1146     -3.0999999046325684e+00
    phi[4,3]  R1147     -3.0999999046325684e+00
    phi[4,3]  R1148     1.5045989751815796e+00
    phi[4,3]  R1149     1.5220741033554077e+00
    phi[4,3]  R1150     5.8739924430847168e-01
    phi[4,3]  R1151     7.1256154775619507e-01
    phi[4,3]  R1152     2.6825663447380066e-01
    phi[4,3]  R1153     3.5873398184776306e-01
    phi[4,3]  R1154     -2.4466846883296967e-01
    phi[4,3]  R1155     -5.9392881393432617e-01
    phi[4,3]  R1156     -1.1557391881942749e+00
    phi[4,3]  R1157     2.5101512670516968e-01
    phi[4,3]  R1158     -2.4855144023895264e+00
    phi[4,3]  R1159     -1.9049099683761597e+00
    phi[4,3]  R1160     -2.4922461509704590e+00
    phi[4,3]  R1161     -2.8483734130859375e+00
    phi[4,3]  R1162     1.4229370653629303e-01
    phi[4,3]  R1163     5.6601548194885254e-01
    phi[4,3]  R1164     1.8343603610992432e-01
    phi[4,3]  R1165     5.9229516983032227e-01
    phi[4,3]  R1166     9.5646090805530548e-02
    phi[4,3]  R1167     3.2936373353004456e-01
    phi[4,3]  R1168     -3.7549573183059692e-01
    phi[4,3]  R1169     -1.1558514833450317e+00
    phi[4,3]  R1170     -2.4432773590087891e+00
    phi[4,3]  R1171     -2.0732848644256592e+00
    phi[4,3]  R1172     -4.4600442051887512e-01
    phi[4,3]  R1173     -6.6851258277893066e-02
    phi[4,3]  R1174     6.4099490642547607e-01
    phi[4,3]  R1175     -8.7897628545761108e-01
    phi[4,3]  R1176     -4.4537064433097839e-01
    phi[4,3]  R1177     -8.5385537147521973e-01
    phi[4,3]  R1178     -2.3176872730255127e+00
    phi[4,3]  R1179     -1.2443329095840454e+00
    phi[4,3]  R1180     -1.1867657899856567e+00
    phi[4,3]  R1181     6.4987844228744507e-01
    phi[4,3]  R1182     -6.3331216573715210e-01
    phi[4,3]  R1183     -1.0701813697814941e+00
    phi[4,3]  R1184     -9.7028493881225586e-01
    phi[4,3]  R1185     -2.4551652371883392e-01
    phi[4,3]  R1186     2.8793570399284363e-01
    phi[4,3]  R1187     -8.9878535270690918e-01
    phi[4,3]  R1188     0.468716561794281
    phi[4,3]  R1189     7.8344339132308960e-01
    phi[4,3]  R1190     -8.9435532689094543e-02
    phi[4,3]  R1191     -1.1695630550384521e+00
    phi[4,3]  R1192     6.2263929843902588e-01
    phi[4,3]  R1193     9.3650954961776733e-01
    phi[4,3]  R1194     -1.1683062314987183e+00
    phi[4,3]  R1195     6.3178151845932007e-01
    phi[4,3]  R1196     0.830464780330658
    phi[4,3]  R1197     1.21615469455719
    phi[4,3]  R1198     -1.1541399955749512e+00
    phi[4,3]  R1199     -1.0033031702041626e+00
    phi[4,3]  R1200     -7.4603313207626343e-01
    phi[4,3]  R1201     -6.0793179273605347e-01
    phi[4,3]  R1202     -1.3629381656646729e+00
    phi[4,3]  R1203     -1.4116891622543335e+00
    phi[4,3]  R1204     -1.2548942565917969e+00
    phi[4,3]  R1205     -1.4926064014434814e+00
    phi[4,3]  R1206     -1.6693766117095947e+00
    phi[4,3]  R1207     7.9330521821975708e-01
    phi[4,3]  R1208     -2.0348151028156281e-01
    phi[4,3]  R1209     -6.3870096206665039e-01
    phi[4,3]  R1210     -1.14873206615448
    phi[4,3]  R1211     -9.2933970689773560e-01
    phi[4,3]  R1212     -1.1345375776290894e+00
    phi[4,3]  R1213     -7.1445268392562866e-01
    phi[4,3]  R1214     0.0982760339975357
    phi[4,3]  R1215     1.7573084831237793e+00
    phi[4,3]  R1216     -2.2952699661254883e-01
    phi[4,3]  R1217     -1.4391747713088989e+00
    phi[4,3]  R1218     -6.0127913951873779e-01
    phi[4,3]  R1219     8.3502340316772461e-01
    phi[4,3]  R1220     -2.0470929145812988e+00
    phi[4,3]  R1221     1.8222750425338745e+00
    phi[4,3]  R1222     1.5682909488677979e+00
    phi[4,3]  R1223     -1.2726160287857056e+00
    phi[4,3]  R1224     9.3972188234329224e-01
    phi[4,3]  R1225     -4.2007541656494141e-01
    phi[4,3]  R1226     2.2586163878440857e-01
    phi[4,3]  R1227     1.6131587028503418e+00
    phi[4,3]  R1228     2.2400949895381927e-01
    phi[4,3]  R1229     1.4532764256000519e-01
    phi[4,3]  R1230     -0.922102689743042
    phi[4,3]  R1231     1.7070409655570984e-01
    phi[4,3]  R1232     -2.0932962000370026e-01
    phi[4,3]  R1233     5.5579423904418945e-01
    phi[4,3]  R1234     -6.0878914594650269e-01
    phi[4,3]  R1235     8.9603118598461151e-02
    phi[4,3]  R1236     -0.59317547082901
    phi[4,3]  R1237     -0.616935133934021
    phi[4,3]  R1238     1.3413868844509125e-01
    phi[4,3]  R1239     1.2124543190002441e+00
    phi[4,3]  R1240     -1.2365154027938843e+00
    phi[4,3]  R1241     -2.5582343339920044e-01
    phi[4,3]  R1242     -5.2891987562179565e-01
    phi[4,3]  R1243     -1.5389494895935059e+00
    phi[4,3]  R1244     -8.1017494201660156e-01
    phi[4,3]  R1245     -8.5589474439620972e-01
    phi[4,3]  R1246     -5.8916163444519043e-01
    phi[4,3]  R1247     -2.4055716991424561e+00
    phi[4,3]  R1248     1.1067247390747070e+00
    phi[4,3]  R1249     4.4351585209369659e-02
    phi[4,3]  R1250     -2.0250127315521240e+00
    phi[4,3]  R1251     -3.1699259281158447e+00
    phi[4,3]  R1252     -2.6480793952941895e+00
    phi[4,3]  R1253     6.2676256895065308e-01
    phi[4,3]  R1254     -9.5934592187404633e-02
    phi[4,3]  R1255     7.2592014074325562e-01
    phi[4,3]  R1256     -2.1384713649749756e+00
    phi[4,3]  R1257     2.3172160983085632e-01
    phi[4,3]  R1258     9.8537737131118774e-01
    phi[4,3]  R1259     -2.2080218791961670e+00
    phi[4,3]  R1260     -9.2432558536529541e-01
    phi[4,3]  R1261     -3.08270001411438
    phi[4,3]  R1262     1.9859695434570312e-01
    phi[4,3]  R1263     1.1946005821228027e+00
    phi[4,3]  R1264     -1.6553881168365479e+00
    phi[4,3]  R1265     -6.1663128435611725e-02
    phi[4,3]  R1266     -1.6640714406967163e+00
    phi[4,3]  R1267     2.9824355244636536e-01
    phi[3,6]  R27       1
    phi[3,6]  R28       1
    phi[3,6]  R54       -1
    phi[3,6]  R1268     -3.0999999046325684e+00
    phi[3,6]  R1269     -3.0999999046325684e+00
    phi[3,6]  R1270     -2.2400000095367432e+00
    phi[3,6]  R1271     -2.2400000095367432e+00
    phi[3,6]  R1272     -3.0999999046325684e+00
    phi[3,6]  R1273     -3.0999999046325684e+00
    phi[3,6]  R1274     -2.5699999332427979e+00
    phi[3,6]  R1275     -2.5699999332427979e+00
    phi[3,6]  R1276     -3.0999999046325684e+00
    phi[3,6]  R1277     -3.0999999046325684e+00
    phi[3,6]  R1278     -2.0899999141693115e+00
    phi[3,6]  R1279     -2.0899999141693115e+00
    phi[3,6]  R1280     -3.0999999046325684e+00
    phi[3,6]  R1281     -3.0999999046325684e+00
    phi[3,6]  R1282     -6.0127913951873779e-01
    phi[3,6]  R1283     8.3502340316772461e-01
    phi[3,6]  R1284     -2.0470929145812988e+00
    phi[3,6]  R1285     1.8222750425338745e+00
    phi[3,6]  R1286     1.5682909488677979e+00
    phi[3,6]  R1287     -1.2726160287857056e+00
    phi[3,6]  R1288     9.3972188234329224e-01
    phi[3,6]  R1289     -4.2007541656494141e-01
    phi[3,6]  R1290     2.2586163878440857e-01
    phi[3,6]  R1291     1.6131587028503418e+00
    phi[3,6]  R1292     2.2400949895381927e-01
    phi[3,6]  R1293     1.4532764256000519e-01
    phi[3,6]  R1294     -0.922102689743042
    phi[3,6]  R1295     1.7070409655570984e-01
    phi[3,6]  R1296     -2.0932962000370026e-01
    phi[3,6]  R1297     5.5579423904418945e-01
    phi[3,6]  R1298     -6.0878914594650269e-01
    phi[3,6]  R1299     8.9603118598461151e-02
    phi[3,6]  R1300     -0.59317547082901
    phi[3,6]  R1301     -0.616935133934021
    phi[3,6]  R1302     1.3413868844509125e-01
    phi[3,6]  R1303     1.2124543190002441e+00
    phi[3,6]  R1304     -1.2365154027938843e+00
    phi[3,6]  R1305     -2.5582343339920044e-01
    phi[3,6]  R1306     -5.2891987562179565e-01
    phi[3,6]  R1307     -1.5389494895935059e+00
    phi[3,6]  R1308     -8.1017494201660156e-01
    phi[3,6]  R1309     -8.5589474439620972e-01
    phi[3,6]  R1310     -5.8916163444519043e-01
    phi[3,6]  R1311     -2.4055716991424561e+00
    phi[3,6]  R1312     1.1067247390747070e+00
    phi[3,6]  R1313     4.4351585209369659e-02
    phi[3,6]  R1314     -2.0250127315521240e+00
    phi[3,6]  R1315     -3.1699259281158447e+00
    phi[3,6]  R1316     -2.6480793952941895e+00
    phi[3,6]  R1317     6.2676256895065308e-01
    phi[3,6]  R1318     -9.5934592187404633e-02
    phi[3,6]  R1319     7.2592014074325562e-01
    phi[3,6]  R1320     -2.1384713649749756e+00
    phi[3,6]  R1321     2.3172160983085632e-01
    phi[3,6]  R1322     9.8537737131118774e-01
    phi[3,6]  R1323     -2.2080218791961670e+00
    phi[3,6]  R1324     -9.2432558536529541e-01
    phi[3,6]  R1325     -3.08270001411438
    phi[3,6]  R1326     1.9859695434570312e-01
    phi[3,6]  R1327     1.1946005821228027e+00
    phi[3,6]  R1328     -1.6553881168365479e+00
    phi[3,6]  R1329     -6.1663128435611725e-02
    phi[3,6]  R1330     -1.6640714406967163e+00
    phi[3,6]  R1331     2.9824355244636536e-01
    phi[3,6]  R1332     2.3352081775665283e+00
    phi[3,6]  R1333     2.6971046924591064e+00
    phi[3,6]  R1334     2.1561522483825684e+00
    phi[3,6]  R1335     1.4242571592330933e+00
    phi[3,6]  R1336     9.4781392812728882e-01
    phi[3,6]  R1337     2.3292881250381470e-01
    phi[3,6]  R1338     -2.5713326930999756e+00
    phi[3,6]  R1339     9.6326857805252075e-02
    phi[3,6]  R1340     -9.4061785936355591e-01
    phi[3,6]  R1341     -2.30448317527771
    phi[3,6]  R1342     -1.0913022756576538e+00
    phi[3,6]  R1343     -1.7075026035308838e+00
    phi[3,6]  R1344     -1.0674458742141724e+00
    phi[3,6]  R1345     -1.4569752216339111e+00
    phi[3,6]  R1346     -1.4675543308258057e+00
    phi[3,6]  R1347     -1.1686152219772339e+00
    phi[3,6]  R1348     -2.8199908733367920e+00
    phi[3,6]  R1349     -3.2676513195037842e+00
    phi[3,6]  R1350     -2.3684391975402832e+00
    phi[3,6]  R1351     -1.0388647317886353e+00
    phi[3,6]  R1352     -2.9406974315643311e+00
    phi[3,6]  R1353     -2.7838253974914551e+00
    phi[3,6]  R1354     -1.8816654682159424e+00
    phi[3,6]  R1355     -1.7148915529251099e+00
    phi[3,6]  R1356     -2.95913028717041
    phi[3,6]  R1357     -2.7803051471710205e+00
    phi[3,6]  R1358     -1.3929710388183594e+00
    phi[3,6]  R1359     -3.2591361999511719e+00
    phi[3,6]  R1360     -2.27364182472229
    phi[3,6]  R1361     -2.9202415943145752e+00
    phi[3,6]  R1362     -2.2405905723571777e+00
    phi[3,6]  R1363     -2.3908915519714355e+00
    phi[3,6]  R1364     -2.0234229564666748e+00
    phi[3,6]  R1365     -1.4838041067123413e+00
    phi[3,6]  R1366     -1.0747042894363403e+00
    phi[3,6]  R1367     -1.7372274398803711e+00
    phi[3,6]  R1368     -1.3823571205139160e+00
    phi[3,6]  R1369     -1.3536016941070557e+00
    phi[3,6]  R1370     -3.0228674411773682e+00
    phi[3,6]  R1371     -8.1145149469375610e-01
    phi[6,3]  R27       -1
    phi[6,3]  R54       1
    phi[6,3]  R55       1
    phi[6,3]  R1372     -3.0999999046325684e+00
    phi[6,3]  R1373     -3.0999999046325684e+00
    phi[6,3]  R1374     -2.2400000095367432e+00
    phi[6,3]  R1375     -2.2400000095367432e+00
    phi[6,3]  R1376     -3.0999999046325684e+00
    phi[6,3]  R1377     -3.0999999046325684e+00
    phi[6,3]  R1378     -2.5699999332427979e+00
    phi[6,3]  R1379     -2.5699999332427979e+00
    phi[6,3]  R1380     -3.0999999046325684e+00
    phi[6,3]  R1381     -3.0999999046325684e+00
    phi[6,3]  R1382     -2.0899999141693115e+00
    phi[6,3]  R1383     -2.0899999141693115e+00
    phi[6,3]  R1384     -3.0999999046325684e+00
    phi[6,3]  R1385     -3.0999999046325684e+00
    phi[6,3]  R1386     2.3352081775665283e+00
    phi[6,3]  R1387     2.6971046924591064e+00
    phi[6,3]  R1388     2.1561522483825684e+00
    phi[6,3]  R1389     1.4242571592330933e+00
    phi[6,3]  R1390     9.4781392812728882e-01
    phi[6,3]  R1391     2.3292881250381470e-01
    phi[6,3]  R1392     -2.5713326930999756e+00
    phi[6,3]  R1393     9.6326857805252075e-02
    phi[6,3]  R1394     -9.4061785936355591e-01
    phi[6,3]  R1395     -2.30448317527771
    phi[6,3]  R1396     -1.0913022756576538e+00
    phi[6,3]  R1397     -1.7075026035308838e+00
    phi[6,3]  R1398     -1.0674458742141724e+00
    phi[6,3]  R1399     -1.4569752216339111e+00
    phi[6,3]  R1400     -1.4675543308258057e+00
    phi[6,3]  R1401     -1.1686152219772339e+00
    phi[6,3]  R1402     -2.8199908733367920e+00
    phi[6,3]  R1403     -3.2676513195037842e+00
    phi[6,3]  R1404     -2.3684391975402832e+00
    phi[6,3]  R1405     -1.0388647317886353e+00
    phi[6,3]  R1406     -2.9406974315643311e+00
    phi[6,3]  R1407     -2.7838253974914551e+00
    phi[6,3]  R1408     -1.8816654682159424e+00
    phi[6,3]  R1409     -1.7148915529251099e+00
    phi[6,3]  R1410     -2.95913028717041
    phi[6,3]  R1411     -2.7803051471710205e+00
    phi[6,3]  R1412     -1.3929710388183594e+00
    phi[6,3]  R1413     -3.2591361999511719e+00
    phi[6,3]  R1414     -2.27364182472229
    phi[6,3]  R1415     -2.9202415943145752e+00
    phi[6,3]  R1416     -2.2405905723571777e+00
    phi[6,3]  R1417     -2.3908915519714355e+00
    phi[6,3]  R1418     -2.0234229564666748e+00
    phi[6,3]  R1419     -1.4838041067123413e+00
    phi[6,3]  R1420     -1.0747042894363403e+00
    phi[6,3]  R1421     -1.7372274398803711e+00
    phi[6,3]  R1422     -1.3823571205139160e+00
    phi[6,3]  R1423     -1.3536016941070557e+00
    phi[6,3]  R1424     -3.0228674411773682e+00
    phi[6,3]  R1425     -8.1145149469375610e-01
    phi[6,3]  R1426     -6.0127913951873779e-01
    phi[6,3]  R1427     8.3502340316772461e-01
    phi[6,3]  R1428     -2.0470929145812988e+00
    phi[6,3]  R1429     1.8222750425338745e+00
    phi[6,3]  R1430     1.5682909488677979e+00
    phi[6,3]  R1431     -1.2726160287857056e+00
    phi[6,3]  R1432     9.3972188234329224e-01
    phi[6,3]  R1433     -4.2007541656494141e-01
    phi[6,3]  R1434     2.2586163878440857e-01
    phi[6,3]  R1435     1.6131587028503418e+00
    phi[6,3]  R1436     2.2400949895381927e-01
    phi[6,3]  R1437     1.4532764256000519e-01
    phi[6,3]  R1438     -0.922102689743042
    phi[6,3]  R1439     1.7070409655570984e-01
    phi[6,3]  R1440     -2.0932962000370026e-01
    phi[6,3]  R1441     5.5579423904418945e-01
    phi[6,3]  R1442     -6.0878914594650269e-01
    phi[6,3]  R1443     8.9603118598461151e-02
    phi[6,3]  R1444     -0.59317547082901
    phi[6,3]  R1445     -0.616935133934021
    phi[6,3]  R1446     1.3413868844509125e-01
    phi[6,3]  R1447     1.2124543190002441e+00
    phi[6,3]  R1448     -1.2365154027938843e+00
    phi[6,3]  R1449     -2.5582343339920044e-01
    phi[6,3]  R1450     -5.2891987562179565e-01
    phi[6,3]  R1451     -1.5389494895935059e+00
    phi[6,3]  R1452     -8.1017494201660156e-01
    phi[6,3]  R1453     -8.5589474439620972e-01
    phi[6,3]  R1454     -5.8916163444519043e-01
    phi[6,3]  R1455     -2.4055716991424561e+00
    phi[6,3]  R1456     1.1067247390747070e+00
    phi[6,3]  R1457     4.4351585209369659e-02
    phi[6,3]  R1458     -2.0250127315521240e+00
    phi[6,3]  R1459     -3.1699259281158447e+00
    phi[6,3]  R1460     -2.6480793952941895e+00
    phi[6,3]  R1461     6.2676256895065308e-01
    phi[6,3]  R1462     -9.5934592187404633e-02
    phi[6,3]  R1463     7.2592014074325562e-01
    phi[6,3]  R1464     -2.1384713649749756e+00
    phi[6,3]  R1465     2.3172160983085632e-01
    phi[6,3]  R1466     9.8537737131118774e-01
    phi[6,3]  R1467     -2.2080218791961670e+00
    phi[6,3]  R1468     -9.2432558536529541e-01
    phi[6,3]  R1469     -3.08270001411438
    phi[6,3]  R1470     1.9859695434570312e-01
    phi[6,3]  R1471     1.1946005821228027e+00
    phi[6,3]  R1472     -1.6553881168365479e+00
    phi[6,3]  R1473     -6.1663128435611725e-02
    phi[6,3]  R1474     -1.6640714406967163e+00
    phi[6,3]  R1475     2.9824355244636536e-01
    phi[3,7]  R27       1
    phi[3,7]  R28       1
    phi[3,7]  R63       -1
    phi[3,7]  R1476     -3.0999999046325684e+00
    phi[3,7]  R1477     -3.0999999046325684e+00
    phi[3,7]  R1478     -2.2400000095367432e+00
    phi[3,7]  R1479     -2.2400000095367432e+00
    phi[3,7]  R1480     -3.0999999046325684e+00
    phi[3,7]  R1481     -3.0999999046325684e+00
    phi[3,7]  R1482     -2.5699999332427979e+00
    phi[3,7]  R1483     -2.5699999332427979e+00
    phi[3,7]  R1484     -3.0999999046325684e+00
    phi[3,7]  R1485     -3.0999999046325684e+00
    phi[3,7]  R1486     -2.0899999141693115e+00
    phi[3,7]  R1487     -2.0899999141693115e+00
    phi[3,7]  R1488     -3.0999999046325684e+00
    phi[3,7]  R1489     -3.0999999046325684e+00
    phi[3,7]  R1490     -6.0127913951873779e-01
    phi[3,7]  R1491     8.3502340316772461e-01
    phi[3,7]  R1492     -2.0470929145812988e+00
    phi[3,7]  R1493     1.8222750425338745e+00
    phi[3,7]  R1494     1.5682909488677979e+00
    phi[3,7]  R1495     -1.2726160287857056e+00
    phi[3,7]  R1496     9.3972188234329224e-01
    phi[3,7]  R1497     -4.2007541656494141e-01
    phi[3,7]  R1498     2.2586163878440857e-01
    phi[3,7]  R1499     1.6131587028503418e+00
    phi[3,7]  R1500     2.2400949895381927e-01
    phi[3,7]  R1501     1.4532764256000519e-01
    phi[3,7]  R1502     -0.922102689743042
    phi[3,7]  R1503     1.7070409655570984e-01
    phi[3,7]  R1504     -2.0932962000370026e-01
    phi[3,7]  R1505     5.5579423904418945e-01
    phi[3,7]  R1506     -6.0878914594650269e-01
    phi[3,7]  R1507     8.9603118598461151e-02
    phi[3,7]  R1508     -0.59317547082901
    phi[3,7]  R1509     -0.616935133934021
    phi[3,7]  R1510     1.3413868844509125e-01
    phi[3,7]  R1511     1.2124543190002441e+00
    phi[3,7]  R1512     -1.2365154027938843e+00
    phi[3,7]  R1513     -2.5582343339920044e-01
    phi[3,7]  R1514     -5.2891987562179565e-01
    phi[3,7]  R1515     -1.5389494895935059e+00
    phi[3,7]  R1516     -8.1017494201660156e-01
    phi[3,7]  R1517     -8.5589474439620972e-01
    phi[3,7]  R1518     -5.8916163444519043e-01
    phi[3,7]  R1519     -2.4055716991424561e+00
    phi[3,7]  R1520     1.1067247390747070e+00
    phi[3,7]  R1521     4.4351585209369659e-02
    phi[3,7]  R1522     -2.0250127315521240e+00
    phi[3,7]  R1523     -3.1699259281158447e+00
    phi[3,7]  R1524     -2.6480793952941895e+00
    phi[3,7]  R1525     6.2676256895065308e-01
    phi[3,7]  R1526     -9.5934592187404633e-02
    phi[3,7]  R1527     7.2592014074325562e-01
    phi[3,7]  R1528     -2.1384713649749756e+00
    phi[3,7]  R1529     2.3172160983085632e-01
    phi[3,7]  R1530     9.8537737131118774e-01
    phi[3,7]  R1531     -2.2080218791961670e+00
    phi[3,7]  R1532     -9.2432558536529541e-01
    phi[3,7]  R1533     -3.08270001411438
    phi[3,7]  R1534     1.9859695434570312e-01
    phi[3,7]  R1535     1.1946005821228027e+00
    phi[3,7]  R1536     -1.6553881168365479e+00
    phi[3,7]  R1537     -6.1663128435611725e-02
    phi[3,7]  R1538     -1.6640714406967163e+00
    phi[3,7]  R1539     2.9824355244636536e-01
    phi[3,7]  R1540     6.5799486637115479e-01
    phi[3,7]  R1541     9.7527700662612915e-01
    phi[3,7]  R1542     1.2964508533477783e+00
    phi[3,7]  R1543     1.8751047551631927e-01
    phi[3,7]  R1544     -0.299600750207901
    phi[3,7]  R1545     -7.7103048563003540e-01
    phi[3,7]  R1546     3.8338100910186768e-01
    phi[3,7]  R1547     -8.2681930065155029e-01
    phi[3,7]  R1548     -2.4086291790008545e+00
    phi[3,7]  R1549     -2.0673902034759521e+00
    phi[3,7]  R1550     2.10866641998291
    phi[3,7]  R1551     2.8177145123481750e-01
    phi[3,7]  R1552     -0.179292693734169
    phi[3,7]  R1553     -3.8770991563796997e-01
    phi[3,7]  R1554     1.1141237020492554e+00
    phi[3,7]  R1555     -1.4681957662105560e-01
    phi[3,7]  R1556     7.0310711860656738e-01
    phi[3,7]  R1557     1.7549513280391693e-01
    phi[3,7]  R1558     9.1958826780319214e-01
    phi[3,7]  R1559     8.6524891853332520e-01
    phi[3,7]  R1560     -3.8530457019805908e-01
    phi[3,7]  R1561     -6.9636249542236328e-01
    phi[3,7]  R1562     -9.7384667396545410e-01
    phi[3,7]  R1563     -6.5875357389450073e-01
    phi[3,7]  R1564     -8.2526482641696930e-02
    phi[3,7]  R1565     -1.7360872030258179e+00
    phi[3,7]  R1566     -0.0976310670375824
    phi[3,7]  R1567     -5.8913275599479675e-02
    phi[3,7]  R1568     -2.5754473209381104e+00
    phi[3,7]  R1569     1.5373377501964569e-01
    phi[3,7]  R1570     -2.7322680950164795e+00
    phi[3,7]  R1571     6.3295882940292358e-01
    phi[3,7]  R1572     4.8233321309089661e-01
    phi[3,7]  R1573     -5.2868628501892090e-01
    phi[3,7]  R1574     8.5413259267807007e-01
    phi[3,7]  R1575     -6.1180430650711060e-01
    phi[3,7]  R1576     6.4918190240859985e-01
    phi[3,7]  R1577     -1.0275367498397827e+00
    phi[3,7]  R1578     -2.0429396629333496e+00
    phi[3,7]  R1579     -7.9672467708587646e-01
    phi[3,7]  R1580     -2.3250651359558105e+00
    phi[3,7]  R1581     2.1792068481445312e+00
    phi[3,7]  R1582     -1.4932667016983032e+00
    phi[3,7]  R1583     1.0587695837020874e+00
    phi[3,7]  R1584     6.0042792558670044e-01
    phi[3,7]  R1585     -7.1883052587509155e-01
    phi[3,7]  R1586     5.6212669610977173e-01
    phi[3,7]  R1587     6.4911139011383057e-01
    phi[3,7]  R1588     8.0117094516754150e-01
    phi[3,7]  R1589     1.6454113721847534e+00
    phi[3,7]  R1590     -2.5483703613281250e+00
    phi[3,7]  R1591     -1.2203072309494019e+00
    phi[3,7]  R1592     -1.9714339971542358e+00
    phi[3,7]  R1593     -2.2899593412876129e-01
    phi[3,7]  R1594     1.7513586282730103e+00
    phi[3,7]  R1595     -1.3622267246246338e+00
    phi[3,7]  R1596     1.9204229116439819e+00
    phi[3,7]  R1597     4.4358074665069580e-01
    phi[3,7]  R1598     -8.5386657714843750e-01
    phi[3,7]  R1599     -1.4615262746810913e+00
    phi[7,3]  R27       -1
    phi[7,3]  R63       1
    phi[7,3]  R64       1
    phi[7,3]  R1600     -3.0999999046325684e+00
    phi[7,3]  R1601     -3.0999999046325684e+00
    phi[7,3]  R1602     -2.2400000095367432e+00
    phi[7,3]  R1603     -2.2400000095367432e+00
    phi[7,3]  R1604     -3.0999999046325684e+00
    phi[7,3]  R1605     -3.0999999046325684e+00
    phi[7,3]  R1606     -2.5699999332427979e+00
    phi[7,3]  R1607     -2.5699999332427979e+00
    phi[7,3]  R1608     -3.0999999046325684e+00
    phi[7,3]  R1609     -3.0999999046325684e+00
    phi[7,3]  R1610     -2.0899999141693115e+00
    phi[7,3]  R1611     -2.0899999141693115e+00
    phi[7,3]  R1612     -3.0999999046325684e+00
    phi[7,3]  R1613     -3.0999999046325684e+00
    phi[7,3]  R1614     6.5799486637115479e-01
    phi[7,3]  R1615     9.7527700662612915e-01
    phi[7,3]  R1616     1.2964508533477783e+00
    phi[7,3]  R1617     1.8751047551631927e-01
    phi[7,3]  R1618     -0.299600750207901
    phi[7,3]  R1619     -7.7103048563003540e-01
    phi[7,3]  R1620     3.8338100910186768e-01
    phi[7,3]  R1621     -8.2681930065155029e-01
    phi[7,3]  R1622     -2.4086291790008545e+00
    phi[7,3]  R1623     -2.0673902034759521e+00
    phi[7,3]  R1624     2.10866641998291
    phi[7,3]  R1625     2.8177145123481750e-01
    phi[7,3]  R1626     -0.179292693734169
    phi[7,3]  R1627     -3.8770991563796997e-01
    phi[7,3]  R1628     1.1141237020492554e+00
    phi[7,3]  R1629     -1.4681957662105560e-01
    phi[7,3]  R1630     7.0310711860656738e-01
    phi[7,3]  R1631     1.7549513280391693e-01
    phi[7,3]  R1632     9.1958826780319214e-01
    phi[7,3]  R1633     8.6524891853332520e-01
    phi[7,3]  R1634     -3.8530457019805908e-01
    phi[7,3]  R1635     -6.9636249542236328e-01
    phi[7,3]  R1636     -9.7384667396545410e-01
    phi[7,3]  R1637     -6.5875357389450073e-01
    phi[7,3]  R1638     -8.2526482641696930e-02
    phi[7,3]  R1639     -1.7360872030258179e+00
    phi[7,3]  R1640     -0.0976310670375824
    phi[7,3]  R1641     -5.8913275599479675e-02
    phi[7,3]  R1642     -2.5754473209381104e+00
    phi[7,3]  R1643     1.5373377501964569e-01
    phi[7,3]  R1644     -2.7322680950164795e+00
    phi[7,3]  R1645     6.3295882940292358e-01
    phi[7,3]  R1646     4.8233321309089661e-01
    phi[7,3]  R1647     -5.2868628501892090e-01
    phi[7,3]  R1648     8.5413259267807007e-01
    phi[7,3]  R1649     -6.1180430650711060e-01
    phi[7,3]  R1650     6.4918190240859985e-01
    phi[7,3]  R1651     -1.0275367498397827e+00
    phi[7,3]  R1652     -2.0429396629333496e+00
    phi[7,3]  R1653     -7.9672467708587646e-01
    phi[7,3]  R1654     -2.3250651359558105e+00
    phi[7,3]  R1655     2.1792068481445312e+00
    phi[7,3]  R1656     -1.4932667016983032e+00
    phi[7,3]  R1657     1.0587695837020874e+00
    phi[7,3]  R1658     6.0042792558670044e-01
    phi[7,3]  R1659     -7.1883052587509155e-01
    phi[7,3]  R1660     5.6212669610977173e-01
    phi[7,3]  R1661     6.4911139011383057e-01
    phi[7,3]  R1662     8.0117094516754150e-01
    phi[7,3]  R1663     1.6454113721847534e+00
    phi[7,3]  R1664     -2.5483703613281250e+00
    phi[7,3]  R1665     -1.2203072309494019e+00
    phi[7,3]  R1666     -1.9714339971542358e+00
    phi[7,3]  R1667     -2.2899593412876129e-01
    phi[7,3]  R1668     1.7513586282730103e+00
    phi[7,3]  R1669     -1.3622267246246338e+00
    phi[7,3]  R1670     1.9204229116439819e+00
    phi[7,3]  R1671     4.4358074665069580e-01
    phi[7,3]  R1672     -8.5386657714843750e-01
    phi[7,3]  R1673     -1.4615262746810913e+00
    phi[7,3]  R1674     -6.0127913951873779e-01
    phi[7,3]  R1675     8.3502340316772461e-01
    phi[7,3]  R1676     -2.0470929145812988e+00
    phi[7,3]  R1677     1.8222750425338745e+00
    phi[7,3]  R1678     1.5682909488677979e+00
    phi[7,3]  R1679     -1.2726160287857056e+00
    phi[7,3]  R1680     9.3972188234329224e-01
    phi[7,3]  R1681     -4.2007541656494141e-01
    phi[7,3]  R1682     2.2586163878440857e-01
    phi[7,3]  R1683     1.6131587028503418e+00
    phi[7,3]  R1684     2.2400949895381927e-01
    phi[7,3]  R1685     1.4532764256000519e-01
    phi[7,3]  R1686     -0.922102689743042
    phi[7,3]  R1687     1.7070409655570984e-01
    phi[7,3]  R1688     -2.0932962000370026e-01
    phi[7,3]  R1689     5.5579423904418945e-01
    phi[7,3]  R1690     -6.0878914594650269e-01
    phi[7,3]  R1691     8.9603118598461151e-02
    phi[7,3]  R1692     -0.59317547082901
    phi[7,3]  R1693     -0.616935133934021
    phi[7,3]  R1694     1.3413868844509125e-01
    phi[7,3]  R1695     1.2124543190002441e+00
    phi[7,3]  R1696     -1.2365154027938843e+00
    phi[7,3]  R1697     -2.5582343339920044e-01
    phi[7,3]  R1698     -5.2891987562179565e-01
    phi[7,3]  R1699     -1.5389494895935059e+00
    phi[7,3]  R1700     -8.1017494201660156e-01
    phi[7,3]  R1701     -8.5589474439620972e-01
    phi[7,3]  R1702     -5.8916163444519043e-01
    phi[7,3]  R1703     -2.4055716991424561e+00
    phi[7,3]  R1704     1.1067247390747070e+00
    phi[7,3]  R1705     4.4351585209369659e-02
    phi[7,3]  R1706     -2.0250127315521240e+00
    phi[7,3]  R1707     -3.1699259281158447e+00
    phi[7,3]  R1708     -2.6480793952941895e+00
    phi[7,3]  R1709     6.2676256895065308e-01
    phi[7,3]  R1710     -9.5934592187404633e-02
    phi[7,3]  R1711     7.2592014074325562e-01
    phi[7,3]  R1712     -2.1384713649749756e+00
    phi[7,3]  R1713     2.3172160983085632e-01
    phi[7,3]  R1714     9.8537737131118774e-01
    phi[7,3]  R1715     -2.2080218791961670e+00
    phi[7,3]  R1716     -9.2432558536529541e-01
    phi[7,3]  R1717     -3.08270001411438
    phi[7,3]  R1718     1.9859695434570312e-01
    phi[7,3]  R1719     1.1946005821228027e+00
    phi[7,3]  R1720     -1.6553881168365479e+00
    phi[7,3]  R1721     -6.1663128435611725e-02
    phi[7,3]  R1722     -1.6640714406967163e+00
    phi[7,3]  R1723     2.9824355244636536e-01
    phi[4,7]  R36       1
    phi[4,7]  R37       1
    phi[4,7]  R63       -1
    phi[4,7]  R1724     -3.0999999046325684e+00
    phi[4,7]  R1725     -3.0999999046325684e+00
    phi[4,7]  R1726     -2.2400000095367432e+00
    phi[4,7]  R1727     -2.2400000095367432e+00
    phi[4,7]  R1728     -3.0999999046325684e+00
    phi[4,7]  R1729     -3.0999999046325684e+00
    phi[4,7]  R1730     -2.5699999332427979e+00
    phi[4,7]  R1731     -2.5699999332427979e+00
    phi[4,7]  R1732     -3.0999999046325684e+00
    phi[4,7]  R1733     -3.0999999046325684e+00
    phi[4,7]  R1734     -2.0899999141693115e+00
    phi[4,7]  R1735     -2.0899999141693115e+00
    phi[4,7]  R1736     -3.0999999046325684e+00
    phi[4,7]  R1737     -3.0999999046325684e+00
    phi[4,7]  R1738     1.5045989751815796e+00
    phi[4,7]  R1739     1.5220741033554077e+00
    phi[4,7]  R1740     5.8739924430847168e-01
    phi[4,7]  R1741     7.1256154775619507e-01
    phi[4,7]  R1742     2.6825663447380066e-01
    phi[4,7]  R1743     3.5873398184776306e-01
    phi[4,7]  R1744     -2.4466846883296967e-01
    phi[4,7]  R1745     -5.9392881393432617e-01
    phi[4,7]  R1746     -1.1557391881942749e+00
    phi[4,7]  R1747     2.5101512670516968e-01
    phi[4,7]  R1748     -2.4855144023895264e+00
    phi[4,7]  R1749     -1.9049099683761597e+00
    phi[4,7]  R1750     -2.4922461509704590e+00
    phi[4,7]  R1751     -2.8483734130859375e+00
    phi[4,7]  R1752     1.4229370653629303e-01
    phi[4,7]  R1753     5.6601548194885254e-01
    phi[4,7]  R1754     1.8343603610992432e-01
    phi[4,7]  R1755     5.9229516983032227e-01
    phi[4,7]  R1756     9.5646090805530548e-02
    phi[4,7]  R1757     3.2936373353004456e-01
    phi[4,7]  R1758     -3.7549573183059692e-01
    phi[4,7]  R1759     -1.1558514833450317e+00
    phi[4,7]  R1760     -2.4432773590087891e+00
    phi[4,7]  R1761     -2.0732848644256592e+00
    phi[4,7]  R1762     -4.4600442051887512e-01
    phi[4,7]  R1763     -6.6851258277893066e-02
    phi[4,7]  R1764     6.4099490642547607e-01
    phi[4,7]  R1765     -8.7897628545761108e-01
    phi[4,7]  R1766     -4.4537064433097839e-01
    phi[4,7]  R1767     -8.5385537147521973e-01
    phi[4,7]  R1768     -2.3176872730255127e+00
    phi[4,7]  R1769     -1.2443329095840454e+00
    phi[4,7]  R1770     -1.1867657899856567e+00
    phi[4,7]  R1771     6.4987844228744507e-01
    phi[4,7]  R1772     -6.3331216573715210e-01
    phi[4,7]  R1773     -1.0701813697814941e+00
    phi[4,7]  R1774     -9.7028493881225586e-01
    phi[4,7]  R1775     -2.4551652371883392e-01
    phi[4,7]  R1776     2.8793570399284363e-01
    phi[4,7]  R1777     -8.9878535270690918e-01
    phi[4,7]  R1778     0.468716561794281
    phi[4,7]  R1779     7.8344339132308960e-01
    phi[4,7]  R1780     -8.9435532689094543e-02
    phi[4,7]  R1781     -1.1695630550384521e+00
    phi[4,7]  R1782     6.2263929843902588e-01
    phi[4,7]  R1783     9.3650954961776733e-01
    phi[4,7]  R1784     -1.1683062314987183e+00
    phi[4,7]  R1785     6.3178151845932007e-01
    phi[4,7]  R1786     0.830464780330658
    phi[4,7]  R1787     1.21615469455719
    phi[4,7]  R1788     -1.1541399955749512e+00
    phi[4,7]  R1789     -1.0033031702041626e+00
    phi[4,7]  R1790     -7.4603313207626343e-01
    phi[4,7]  R1791     -6.0793179273605347e-01
    phi[4,7]  R1792     -1.3629381656646729e+00
    phi[4,7]  R1793     -1.4116891622543335e+00
    phi[4,7]  R1794     -1.2548942565917969e+00
    phi[4,7]  R1795     -1.4926064014434814e+00
    phi[4,7]  R1796     -1.6693766117095947e+00
    phi[4,7]  R1797     7.9330521821975708e-01
    phi[4,7]  R1798     -2.0348151028156281e-01
    phi[4,7]  R1799     -6.3870096206665039e-01
    phi[4,7]  R1800     -1.14873206615448
    phi[4,7]  R1801     -9.2933970689773560e-01
    phi[4,7]  R1802     -1.1345375776290894e+00
    phi[4,7]  R1803     -7.1445268392562866e-01
    phi[4,7]  R1804     0.0982760339975357
    phi[4,7]  R1805     1.7573084831237793e+00
    phi[4,7]  R1806     -2.2952699661254883e-01
    phi[4,7]  R1807     -1.4391747713088989e+00
    phi[4,7]  R1808     6.5799486637115479e-01
    phi[4,7]  R1809     9.7527700662612915e-01
    phi[4,7]  R1810     1.2964508533477783e+00
    phi[4,7]  R1811     1.8751047551631927e-01
    phi[4,7]  R1812     -0.299600750207901
    phi[4,7]  R1813     -7.7103048563003540e-01
    phi[4,7]  R1814     3.8338100910186768e-01
    phi[4,7]  R1815     -8.2681930065155029e-01
    phi[4,7]  R1816     -2.4086291790008545e+00
    phi[4,7]  R1817     -2.0673902034759521e+00
    phi[4,7]  R1818     2.10866641998291
    phi[4,7]  R1819     2.8177145123481750e-01
    phi[4,7]  R1820     -0.179292693734169
    phi[4,7]  R1821     -3.8770991563796997e-01
    phi[4,7]  R1822     1.1141237020492554e+00
    phi[4,7]  R1823     -1.4681957662105560e-01
    phi[4,7]  R1824     7.0310711860656738e-01
    phi[4,7]  R1825     1.7549513280391693e-01
    phi[4,7]  R1826     9.1958826780319214e-01
    phi[4,7]  R1827     8.6524891853332520e-01
    phi[4,7]  R1828     -3.8530457019805908e-01
    phi[4,7]  R1829     -6.9636249542236328e-01
    phi[4,7]  R1830     -9.7384667396545410e-01
    phi[4,7]  R1831     -6.5875357389450073e-01
    phi[4,7]  R1832     -8.2526482641696930e-02
    phi[4,7]  R1833     -1.7360872030258179e+00
    phi[4,7]  R1834     -0.0976310670375824
    phi[4,7]  R1835     -5.8913275599479675e-02
    phi[4,7]  R1836     -2.5754473209381104e+00
    phi[4,7]  R1837     1.5373377501964569e-01
    phi[4,7]  R1838     -2.7322680950164795e+00
    phi[4,7]  R1839     6.3295882940292358e-01
    phi[4,7]  R1840     4.8233321309089661e-01
    phi[4,7]  R1841     -5.2868628501892090e-01
    phi[4,7]  R1842     8.5413259267807007e-01
    phi[4,7]  R1843     -6.1180430650711060e-01
    phi[4,7]  R1844     6.4918190240859985e-01
    phi[4,7]  R1845     -1.0275367498397827e+00
    phi[4,7]  R1846     -2.0429396629333496e+00
    phi[4,7]  R1847     -7.9672467708587646e-01
    phi[4,7]  R1848     -2.3250651359558105e+00
    phi[4,7]  R1849     2.1792068481445312e+00
    phi[4,7]  R1850     -1.4932667016983032e+00
    phi[4,7]  R1851     1.0587695837020874e+00
    phi[4,7]  R1852     6.0042792558670044e-01
    phi[4,7]  R1853     -7.1883052587509155e-01
    phi[4,7]  R1854     5.6212669610977173e-01
    phi[4,7]  R1855     6.4911139011383057e-01
    phi[4,7]  R1856     8.0117094516754150e-01
    phi[4,7]  R1857     1.6454113721847534e+00
    phi[4,7]  R1858     -2.5483703613281250e+00
    phi[4,7]  R1859     -1.2203072309494019e+00
    phi[4,7]  R1860     -1.9714339971542358e+00
    phi[4,7]  R1861     -2.2899593412876129e-01
    phi[4,7]  R1862     1.7513586282730103e+00
    phi[4,7]  R1863     -1.3622267246246338e+00
    phi[4,7]  R1864     1.9204229116439819e+00
    phi[4,7]  R1865     4.4358074665069580e-01
    phi[4,7]  R1866     -8.5386657714843750e-01
    phi[4,7]  R1867     -1.4615262746810913e+00
    phi[7,4]  R36       -1
    phi[7,4]  R63       1
    phi[7,4]  R64       1
    phi[7,4]  R1868     -3.0999999046325684e+00
    phi[7,4]  R1869     -3.0999999046325684e+00
    phi[7,4]  R1870     -2.2400000095367432e+00
    phi[7,4]  R1871     -2.2400000095367432e+00
    phi[7,4]  R1872     -3.0999999046325684e+00
    phi[7,4]  R1873     -3.0999999046325684e+00
    phi[7,4]  R1874     -2.5699999332427979e+00
    phi[7,4]  R1875     -2.5699999332427979e+00
    phi[7,4]  R1876     -3.0999999046325684e+00
    phi[7,4]  R1877     -3.0999999046325684e+00
    phi[7,4]  R1878     -2.0899999141693115e+00
    phi[7,4]  R1879     -2.0899999141693115e+00
    phi[7,4]  R1880     -3.0999999046325684e+00
    phi[7,4]  R1881     -3.0999999046325684e+00
    phi[7,4]  R1882     6.5799486637115479e-01
    phi[7,4]  R1883     9.7527700662612915e-01
    phi[7,4]  R1884     1.2964508533477783e+00
    phi[7,4]  R1885     1.8751047551631927e-01
    phi[7,4]  R1886     -0.299600750207901
    phi[7,4]  R1887     -7.7103048563003540e-01
    phi[7,4]  R1888     3.8338100910186768e-01
    phi[7,4]  R1889     -8.2681930065155029e-01
    phi[7,4]  R1890     -2.4086291790008545e+00
    phi[7,4]  R1891     -2.0673902034759521e+00
    phi[7,4]  R1892     2.10866641998291
    phi[7,4]  R1893     2.8177145123481750e-01
    phi[7,4]  R1894     -0.179292693734169
    phi[7,4]  R1895     -3.8770991563796997e-01
    phi[7,4]  R1896     1.1141237020492554e+00
    phi[7,4]  R1897     -1.4681957662105560e-01
    phi[7,4]  R1898     7.0310711860656738e-01
    phi[7,4]  R1899     1.7549513280391693e-01
    phi[7,4]  R1900     9.1958826780319214e-01
    phi[7,4]  R1901     8.6524891853332520e-01
    phi[7,4]  R1902     -3.8530457019805908e-01
    phi[7,4]  R1903     -6.9636249542236328e-01
    phi[7,4]  R1904     -9.7384667396545410e-01
    phi[7,4]  R1905     -6.5875357389450073e-01
    phi[7,4]  R1906     -8.2526482641696930e-02
    phi[7,4]  R1907     -1.7360872030258179e+00
    phi[7,4]  R1908     -0.0976310670375824
    phi[7,4]  R1909     -5.8913275599479675e-02
    phi[7,4]  R1910     -2.5754473209381104e+00
    phi[7,4]  R1911     1.5373377501964569e-01
    phi[7,4]  R1912     -2.7322680950164795e+00
    phi[7,4]  R1913     6.3295882940292358e-01
    phi[7,4]  R1914     4.8233321309089661e-01
    phi[7,4]  R1915     -5.2868628501892090e-01
    phi[7,4]  R1916     8.5413259267807007e-01
    phi[7,4]  R1917     -6.1180430650711060e-01
    phi[7,4]  R1918     6.4918190240859985e-01
    phi[7,4]  R1919     -1.0275367498397827e+00
    phi[7,4]  R1920     -2.0429396629333496e+00
    phi[7,4]  R1921     -7.9672467708587646e-01
    phi[7,4]  R1922     -2.3250651359558105e+00
    phi[7,4]  R1923     2.1792068481445312e+00
    phi[7,4]  R1924     -1.4932667016983032e+00
    phi[7,4]  R1925     1.0587695837020874e+00
    phi[7,4]  R1926     6.0042792558670044e-01
    phi[7,4]  R1927     -7.1883052587509155e-01
    phi[7,4]  R1928     5.6212669610977173e-01
    phi[7,4]  R1929     6.4911139011383057e-01
    phi[7,4]  R1930     8.0117094516754150e-01
    phi[7,4]  R1931     1.6454113721847534e+00
    phi[7,4]  R1932     -2.5483703613281250e+00
    phi[7,4]  R1933     -1.2203072309494019e+00
    phi[7,4]  R1934     -1.9714339971542358e+00
    phi[7,4]  R1935     -2.2899593412876129e-01
    phi[7,4]  R1936     1.7513586282730103e+00
    phi[7,4]  R1937     -1.3622267246246338e+00
    phi[7,4]  R1938     1.9204229116439819e+00
    phi[7,4]  R1939     4.4358074665069580e-01
    phi[7,4]  R1940     -8.5386657714843750e-01
    phi[7,4]  R1941     -1.4615262746810913e+00
    phi[7,4]  R1942     1.5045989751815796e+00
    phi[7,4]  R1943     1.5220741033554077e+00
    phi[7,4]  R1944     5.8739924430847168e-01
    phi[7,4]  R1945     7.1256154775619507e-01
    phi[7,4]  R1946     2.6825663447380066e-01
    phi[7,4]  R1947     3.5873398184776306e-01
    phi[7,4]  R1948     -2.4466846883296967e-01
    phi[7,4]  R1949     -5.9392881393432617e-01
    phi[7,4]  R1950     -1.1557391881942749e+00
    phi[7,4]  R1951     2.5101512670516968e-01
    phi[7,4]  R1952     -2.4855144023895264e+00
    phi[7,4]  R1953     -1.9049099683761597e+00
    phi[7,4]  R1954     -2.4922461509704590e+00
    phi[7,4]  R1955     -2.8483734130859375e+00
    phi[7,4]  R1956     1.4229370653629303e-01
    phi[7,4]  R1957     5.6601548194885254e-01
    phi[7,4]  R1958     1.8343603610992432e-01
    phi[7,4]  R1959     5.9229516983032227e-01
    phi[7,4]  R1960     9.5646090805530548e-02
    phi[7,4]  R1961     3.2936373353004456e-01
    phi[7,4]  R1962     -3.7549573183059692e-01
    phi[7,4]  R1963     -1.1558514833450317e+00
    phi[7,4]  R1964     -2.4432773590087891e+00
    phi[7,4]  R1965     -2.0732848644256592e+00
    phi[7,4]  R1966     -4.4600442051887512e-01
    phi[7,4]  R1967     -6.6851258277893066e-02
    phi[7,4]  R1968     6.4099490642547607e-01
    phi[7,4]  R1969     -8.7897628545761108e-01
    phi[7,4]  R1970     -4.4537064433097839e-01
    phi[7,4]  R1971     -8.5385537147521973e-01
    phi[7,4]  R1972     -2.3176872730255127e+00
    phi[7,4]  R1973     -1.2443329095840454e+00
    phi[7,4]  R1974     -1.1867657899856567e+00
    phi[7,4]  R1975     6.4987844228744507e-01
    phi[7,4]  R1976     -6.3331216573715210e-01
    phi[7,4]  R1977     -1.0701813697814941e+00
    phi[7,4]  R1978     -9.7028493881225586e-01
    phi[7,4]  R1979     -2.4551652371883392e-01
    phi[7,4]  R1980     2.8793570399284363e-01
    phi[7,4]  R1981     -8.9878535270690918e-01
    phi[7,4]  R1982     0.468716561794281
    phi[7,4]  R1983     7.8344339132308960e-01
    phi[7,4]  R1984     -8.9435532689094543e-02
    phi[7,4]  R1985     -1.1695630550384521e+00
    phi[7,4]  R1986     6.2263929843902588e-01
    phi[7,4]  R1987     9.3650954961776733e-01
    phi[7,4]  R1988     -1.1683062314987183e+00
    phi[7,4]  R1989     6.3178151845932007e-01
    phi[7,4]  R1990     0.830464780330658
    phi[7,4]  R1991     1.21615469455719
    phi[7,4]  R1992     -1.1541399955749512e+00
    phi[7,4]  R1993     -1.0033031702041626e+00
    phi[7,4]  R1994     -7.4603313207626343e-01
    phi[7,4]  R1995     -6.0793179273605347e-01
    phi[7,4]  R1996     -1.3629381656646729e+00
    phi[7,4]  R1997     -1.4116891622543335e+00
    phi[7,4]  R1998     -1.2548942565917969e+00
    phi[7,4]  R1999     -1.4926064014434814e+00
    phi[7,4]  R2000     -1.6693766117095947e+00
    phi[7,4]  R2001     7.9330521821975708e-01
    phi[7,4]  R2002     -2.0348151028156281e-01
    phi[7,4]  R2003     -6.3870096206665039e-01
    phi[7,4]  R2004     -1.14873206615448
    phi[7,4]  R2005     -9.2933970689773560e-01
    phi[7,4]  R2006     -1.1345375776290894e+00
    phi[7,4]  R2007     -7.1445268392562866e-01
    phi[7,4]  R2008     0.0982760339975357
    phi[7,4]  R2009     1.7573084831237793e+00
    phi[7,4]  R2010     -2.2952699661254883e-01
    phi[7,4]  R2011     -1.4391747713088989e+00
    phi[4,9]  R36       1
    phi[4,9]  R37       1
    phi[4,9]  R38       1.0304953161175030e+00
    phi[4,9]  R39       1.3415754206792543e+00
    phi[4,9]  R40       -2.0477249685353107e+00
    phi[4,9]  R41       -1.8766128995991016e-01
    phi[4,9]  R42       -6.2880344547162048e-01
    phi[4,9]  R43       -1.6981592742109530e+00
    phi[4,9]  R44       -5.0896577480679994e-02
    phi[4,9]  R73       -1
    phi[4,9]  R2012     -2.0695045885150654e+00
    phi[4,9]  R2013     -4.1304952207500714e+00
    phi[4,9]  R2014     -8.9842458885748888e-01
    phi[4,9]  R2015     -3.5815754302159974e+00
    phi[4,9]  R2016     -5.1477248731678795e+00
    phi[4,9]  R2017     -1.0522749360972576e+00
    phi[4,9]  R2018     -2.7576612232027080e+00
    phi[4,9]  R2019     -2.3823386432828877e+00
    phi[4,9]  R2020     -3.7288033501041888e+00
    phi[4,9]  R2021     -2.4711964591609479e+00
    phi[4,9]  R2022     -3.7881591883802646e+00
    phi[4,9]  R2023     -3.9184063995835849e-01
    phi[4,9]  R2024     -3.1508964821132484e+00
    phi[4,9]  R2025     -3.0491033271518884e+00
    phi[4,9]  R2026     -1.2233675754159434e-01
    phi[4,9]  R2027     -1.2246057414106382e-01
    phi[4,9]  R2028     -1.2727632900092090e-01
    phi[4,9]  R2029     -1.2934317542097096e-01
    phi[4,9]  R2030     -1.3455524044394124e-01
    phi[4,9]  R2031     -1.3691152855257216e-01
    phi[4,9]  R2032     -1.9070794062598348e-01
    phi[4,9]  R2033     -3.5705194538693585e-01
    phi[4,9]  R2034     -6.9227539283356787e-01
    phi[4,9]  R2035     -2.1943472694681676e-01
    phi[4,9]  R2036     -1.7334140297175660e-01
    phi[4,9]  R2037     -1.7634672760736070e-01
    phi[4,9]  R2038     -1.9949506985543364e-01
    phi[4,9]  R2039     -2.2804933509845959e-01
    phi[4,9]  R2040     -1.3595929990930256e+00
    phi[4,9]  R2041     -1.0895046229076493e+00
    phi[4,9]  R2042     -1.0760685304435562e+00
    phi[4,9]  R2043     -1.2588179816300882e+00
    phi[4,9]  R2044     -1.2504653103947083e+00
    phi[4,9]  R2045     -1.1613726255795911e+00
    phi[4,9]  R2046     -1.6696819594273804e-01
    phi[4,9]  R2047     -1.9342496483313265e-01
    phi[4,9]  R2048     -2.0195606851159331e-01
    phi[4,9]  R2049     -2.2796404194040165e-01
    phi[4,9]  R2050     -0.251605342511554
    phi[4,9]  R2051     -3.2911976222215483e-01
    phi[4,9]  R2052     -4.7100048701651964e-01
    phi[4,9]  R2053     -6.4976080277495285e-01
    phi[4,9]  R2054     -1.4628116907777540e+00
    phi[4,9]  R2055     -1.2736039088203963e+00
    phi[4,9]  R2056     -1.2281347964190514e-01
    phi[4,9]  R2057     -1.4207175309935738e-01
    phi[4,9]  R2058     -1.8366217570370535e-01
    phi[4,9]  R2059     -4.1191156348321334e-01
    phi[4,9]  R2060     -0.534122856873794
    phi[4,9]  R2061     -5.8382909231630786e-01
    phi[4,9]  R2062     -5.8501693301337254e-01
    phi[4,9]  R2063     -6.6816747950516042e-01
    phi[4,9]  R2064     -6.9225287872205465e-01
    phi[4,9]  R2065     -1.5770317243679355e+00
    phi[4,9]  R2066     -4.1222854890003557e-01
    phi[4,9]  R2067     -9.3451445131535626e-01
    phi[4,9]  R2068     -1.7426898804596815e+00
    phi[4,9]  R2069     -1.7549710375306673e+00
    phi[4,9]  R2070     -7.6832253247764748e-01
    phi[4,9]  R2071     -7.7074076941035985e-01
    phi[4,9]  R2072     -1.4328108544804490e+00
    phi[4,9]  R2073     -7.7776775568107936e-01
    phi[4,9]  R2074     -7.8154657166502850e-01
    phi[4,9]  R2075     -7.8404764168180119e-01
    phi[4,9]  R2076     -5.6668341395025168e-01
    phi[4,9]  R2077     -5.8401404125429546e-01
    phi[4,9]  R2078     -1.6930761456305121e+00
    phi[4,9]  R2079     -1.3903391928572593e+00
    phi[4,9]  R2080     -1.7261436902790617e+00
    phi[4,9]  R2081     -1.4956427844681508e+00
    phi[4,9]  R2082     -1.1651749801075717e+00
    phi[4,9]  R2083     -1.7795643869632403e+00
    phi[4,9]  R2084     -1.5694516590409184e+00
    phi[4,9]  R2085     -7.8844468758612574e-01
    phi[4,9]  R2086     -2.0926052683519186e-01
    phi[4,9]  R2087     -2.4980443540527586e-01
    phi[4,9]  R2088     -4.7019466512693886e-01
    phi[4,9]  R2089     -1.4294148889041285e+00
    phi[4,9]  R2090     -1.4711986631445997e+00
    phi[4,9]  R2091     -1.0321613261791160e+00
    phi[4,9]  R2092     -8.3223208283123606e-01
    phi[4,9]  R2093     -9.2007326455819971e-01
    phi[4,9]  R2094     -9.2563957144369735e-01
    phi[4,9]  R2095     -1.9730465720205665e+00
    phi[5,6]  R45       1
    phi[5,6]  R46       1
    phi[5,6]  R54       -1
    phi[5,6]  R2096     -3.0999999046325684e+00
    phi[5,6]  R2097     -3.0999999046325684e+00
    phi[5,6]  R2098     -2.2400000095367432e+00
    phi[5,6]  R2099     -2.2400000095367432e+00
    phi[5,6]  R2100     -3.0999999046325684e+00
    phi[5,6]  R2101     -3.0999999046325684e+00
    phi[5,6]  R2102     -2.5699999332427979e+00
    phi[5,6]  R2103     -2.5699999332427979e+00
    phi[5,6]  R2104     -3.0999999046325684e+00
    phi[5,6]  R2105     -3.0999999046325684e+00
    phi[5,6]  R2106     -2.0899999141693115e+00
    phi[5,6]  R2107     -2.0899999141693115e+00
    phi[5,6]  R2108     -3.0999999046325684e+00
    phi[5,6]  R2109     -3.0999999046325684e+00
    phi[5,6]  R2110     -7.9203283786773682e-01
    phi[5,6]  R2111     2.8076500892639160e+00
    phi[5,6]  R2112     3.0165817737579346e+00
    phi[5,6]  R2113     2.8180882930755615e+00
    phi[5,6]  R2114     3.3655552864074707e+00
    phi[5,6]  R2115     3.0474305152893066e+00
    phi[5,6]  R2116     3.2612526416778564e+00
    phi[5,6]  R2117     2.6908736228942871e+00
    phi[5,6]  R2118     3.0105242729187012e+00
    phi[5,6]  R2119     2.8849561214447021e+00
    phi[5,6]  R2120     -2.1099472045898438e+00
    phi[5,6]  R2121     -1.0483162403106689e+00
    phi[5,6]  R2122     -1.6577509641647339e+00
    phi[5,6]  R2123     -2.6158449649810791e+00
    phi[5,6]  R2124     -2.3549637198448181e-01
    phi[5,6]  R2125     -5.0872528553009033e-01
    phi[5,6]  R2126     -2.3982350826263428e+00
    phi[5,6]  R2127     -2.0925955772399902e+00
    phi[5,6]  R2128     -7.0746958255767822e-01
    phi[5,6]  R2129     -3.0812611579895020e+00
    phi[5,6]  R2130     -4.5784950256347656e-01
    phi[5,6]  R2131     -4.6550095081329346e-02
    phi[5,6]  R2132     -4.2479839920997620e-01
    phi[5,6]  R2133     -1.4490628242492676e+00
    phi[5,6]  R2134     -0.874847948551178
    phi[5,6]  R2135     -3.5285255908966064e+00
    phi[5,6]  R2136     1.1299564503133297e-02
    phi[5,6]  R2137     1.02763831615448
    phi[5,6]  R2138     -1.3856884837150574e-01
    phi[5,6]  R2139     -7.0064926147460938e-01
    phi[5,6]  R2140     5.2048754692077637e-01
    phi[5,6]  R2141     -2.8572754859924316e+00
    phi[5,6]  R2142     -2.2127977013587952e-01
    phi[5,6]  R2143     -3.0582771301269531e+00
    phi[5,6]  R2144     -6.2147490680217743e-03
    phi[5,6]  R2145     3.6245263181626797e-03
    phi[5,6]  R2146     -9.4238060712814331e-01
    phi[5,6]  R2147     -1.6427754163742065e+00
    phi[5,6]  R2148     -1.7337930202484131e+00
    phi[5,6]  R2149     -1.7901489734649658e+00
    phi[5,6]  R2150     -1.1796261072158813e+00
    phi[5,6]  R2151     -2.1728000640869141e+00
    phi[5,6]  R2152     -2.7709286212921143e+00
    phi[5,6]  R2153     -2.9241403564810753e-02
    phi[5,6]  R2154     -1.0765225887298584e+00
    phi[5,6]  R2155     -5.0105011463165283e-01
    phi[5,6]  R2156     -1.1340914666652679e-01
    phi[5,6]  R2157     -1.4461387395858765e+00
    phi[5,6]  R2158     -1.57016122341156
    phi[5,6]  R2159     -2.1026985645294189e+00
    phi[5,6]  R2160     2.3352081775665283e+00
    phi[5,6]  R2161     2.6971046924591064e+00
    phi[5,6]  R2162     2.1561522483825684e+00
    phi[5,6]  R2163     1.4242571592330933e+00
    phi[5,6]  R2164     9.4781392812728882e-01
    phi[5,6]  R2165     2.3292881250381470e-01
    phi[5,6]  R2166     -2.5713326930999756e+00
    phi[5,6]  R2167     9.6326857805252075e-02
    phi[5,6]  R2168     -9.4061785936355591e-01
    phi[5,6]  R2169     -2.30448317527771
    phi[5,6]  R2170     -1.0913022756576538e+00
    phi[5,6]  R2171     -1.7075026035308838e+00
    phi[5,6]  R2172     -1.0674458742141724e+00
    phi[5,6]  R2173     -1.4569752216339111e+00
    phi[5,6]  R2174     -1.4675543308258057e+00
    phi[5,6]  R2175     -1.1686152219772339e+00
    phi[5,6]  R2176     -2.8199908733367920e+00
    phi[5,6]  R2177     -3.2676513195037842e+00
    phi[5,6]  R2178     -2.3684391975402832e+00
    phi[5,6]  R2179     -1.0388647317886353e+00
    phi[5,6]  R2180     -2.9406974315643311e+00
    phi[5,6]  R2181     -2.7838253974914551e+00
    phi[5,6]  R2182     -1.8816654682159424e+00
    phi[5,6]  R2183     -1.7148915529251099e+00
    phi[5,6]  R2184     -2.95913028717041
    phi[5,6]  R2185     -2.7803051471710205e+00
    phi[5,6]  R2186     -1.3929710388183594e+00
    phi[5,6]  R2187     -3.2591361999511719e+00
    phi[5,6]  R2188     -2.27364182472229
    phi[5,6]  R2189     -2.9202415943145752e+00
    phi[5,6]  R2190     -2.2405905723571777e+00
    phi[5,6]  R2191     -2.3908915519714355e+00
    phi[5,6]  R2192     -2.0234229564666748e+00
    phi[5,6]  R2193     -1.4838041067123413e+00
    phi[5,6]  R2194     -1.0747042894363403e+00
    phi[5,6]  R2195     -1.7372274398803711e+00
    phi[5,6]  R2196     -1.3823571205139160e+00
    phi[5,6]  R2197     -1.3536016941070557e+00
    phi[5,6]  R2198     -3.0228674411773682e+00
    phi[5,6]  R2199     -8.1145149469375610e-01
    phi[6,5]  R45       -1
    phi[6,5]  R54       1
    phi[6,5]  R55       1
    phi[6,5]  R2200     -3.0999999046325684e+00
    phi[6,5]  R2201     -3.0999999046325684e+00
    phi[6,5]  R2202     -2.2400000095367432e+00
    phi[6,5]  R2203     -2.2400000095367432e+00
    phi[6,5]  R2204     -3.0999999046325684e+00
    phi[6,5]  R2205     -3.0999999046325684e+00
    phi[6,5]  R2206     -2.5699999332427979e+00
    phi[6,5]  R2207     -2.5699999332427979e+00
    phi[6,5]  R2208     -3.0999999046325684e+00
    phi[6,5]  R2209     -3.0999999046325684e+00
    phi[6,5]  R2210     -2.0899999141693115e+00
    phi[6,5]  R2211     -2.0899999141693115e+00
    phi[6,5]  R2212     -3.0999999046325684e+00
    phi[6,5]  R2213     -3.0999999046325684e+00
    phi[6,5]  R2214     2.3352081775665283e+00
    phi[6,5]  R2215     2.6971046924591064e+00
    phi[6,5]  R2216     2.1561522483825684e+00
    phi[6,5]  R2217     1.4242571592330933e+00
    phi[6,5]  R2218     9.4781392812728882e-01
    phi[6,5]  R2219     2.3292881250381470e-01
    phi[6,5]  R2220     -2.5713326930999756e+00
    phi[6,5]  R2221     9.6326857805252075e-02
    phi[6,5]  R2222     -9.4061785936355591e-01
    phi[6,5]  R2223     -2.30448317527771
    phi[6,5]  R2224     -1.0913022756576538e+00
    phi[6,5]  R2225     -1.7075026035308838e+00
    phi[6,5]  R2226     -1.0674458742141724e+00
    phi[6,5]  R2227     -1.4569752216339111e+00
    phi[6,5]  R2228     -1.4675543308258057e+00
    phi[6,5]  R2229     -1.1686152219772339e+00
    phi[6,5]  R2230     -2.8199908733367920e+00
    phi[6,5]  R2231     -3.2676513195037842e+00
    phi[6,5]  R2232     -2.3684391975402832e+00
    phi[6,5]  R2233     -1.0388647317886353e+00
    phi[6,5]  R2234     -2.9406974315643311e+00
    phi[6,5]  R2235     -2.7838253974914551e+00
    phi[6,5]  R2236     -1.8816654682159424e+00
    phi[6,5]  R2237     -1.7148915529251099e+00
    phi[6,5]  R2238     -2.95913028717041
    phi[6,5]  R2239     -2.7803051471710205e+00
    phi[6,5]  R2240     -1.3929710388183594e+00
    phi[6,5]  R2241     -3.2591361999511719e+00
    phi[6,5]  R2242     -2.27364182472229
    phi[6,5]  R2243     -2.9202415943145752e+00
    phi[6,5]  R2244     -2.2405905723571777e+00
    phi[6,5]  R2245     -2.3908915519714355e+00
    phi[6,5]  R2246     -2.0234229564666748e+00
    phi[6,5]  R2247     -1.4838041067123413e+00
    phi[6,5]  R2248     -1.0747042894363403e+00
    phi[6,5]  R2249     -1.7372274398803711e+00
    phi[6,5]  R2250     -1.3823571205139160e+00
    phi[6,5]  R2251     -1.3536016941070557e+00
    phi[6,5]  R2252     -3.0228674411773682e+00
    phi[6,5]  R2253     -8.1145149469375610e-01
    phi[6,5]  R2254     -7.9203283786773682e-01
    phi[6,5]  R2255     2.8076500892639160e+00
    phi[6,5]  R2256     3.0165817737579346e+00
    phi[6,5]  R2257     2.8180882930755615e+00
    phi[6,5]  R2258     3.3655552864074707e+00
    phi[6,5]  R2259     3.0474305152893066e+00
    phi[6,5]  R2260     3.2612526416778564e+00
    phi[6,5]  R2261     2.6908736228942871e+00
    phi[6,5]  R2262     3.0105242729187012e+00
    phi[6,5]  R2263     2.8849561214447021e+00
    phi[6,5]  R2264     -2.1099472045898438e+00
    phi[6,5]  R2265     -1.0483162403106689e+00
    phi[6,5]  R2266     -1.6577509641647339e+00
    phi[6,5]  R2267     -2.6158449649810791e+00
    phi[6,5]  R2268     -2.3549637198448181e-01
    phi[6,5]  R2269     -5.0872528553009033e-01
    phi[6,5]  R2270     -2.3982350826263428e+00
    phi[6,5]  R2271     -2.0925955772399902e+00
    phi[6,5]  R2272     -7.0746958255767822e-01
    phi[6,5]  R2273     -3.0812611579895020e+00
    phi[6,5]  R2274     -4.5784950256347656e-01
    phi[6,5]  R2275     -4.6550095081329346e-02
    phi[6,5]  R2276     -4.2479839920997620e-01
    phi[6,5]  R2277     -1.4490628242492676e+00
    phi[6,5]  R2278     -0.874847948551178
    phi[6,5]  R2279     -3.5285255908966064e+00
    phi[6,5]  R2280     1.1299564503133297e-02
    phi[6,5]  R2281     1.02763831615448
    phi[6,5]  R2282     -1.3856884837150574e-01
    phi[6,5]  R2283     -7.0064926147460938e-01
    phi[6,5]  R2284     5.2048754692077637e-01
    phi[6,5]  R2285     -2.8572754859924316e+00
    phi[6,5]  R2286     -2.2127977013587952e-01
    phi[6,5]  R2287     -3.0582771301269531e+00
    phi[6,5]  R2288     -6.2147490680217743e-03
    phi[6,5]  R2289     3.6245263181626797e-03
    phi[6,5]  R2290     -9.4238060712814331e-01
    phi[6,5]  R2291     -1.6427754163742065e+00
    phi[6,5]  R2292     -1.7337930202484131e+00
    phi[6,5]  R2293     -1.7901489734649658e+00
    phi[6,5]  R2294     -1.1796261072158813e+00
    phi[6,5]  R2295     -2.1728000640869141e+00
    phi[6,5]  R2296     -2.7709286212921143e+00
    phi[6,5]  R2297     -2.9241403564810753e-02
    phi[6,5]  R2298     -1.0765225887298584e+00
    phi[6,5]  R2299     -5.0105011463165283e-01
    phi[6,5]  R2300     -1.1340914666652679e-01
    phi[6,5]  R2301     -1.4461387395858765e+00
    phi[6,5]  R2302     -1.57016122341156
    phi[6,5]  R2303     -2.1026985645294189e+00
    phi[8,5]  R45       -1
    phi[8,5]  R47       2.6730700195312918e+00
    phi[8,5]  R48       -1.3638672989601659e+00
    phi[8,5]  R49       2.6523768258535685e+00
    phi[8,5]  R50       2.3550335083054450e+00
    phi[8,5]  R51       1.4915130460446560e+00
    phi[8,5]  R52       -1.3152405525902688e+00
    phi[8,5]  R53       3.0287032482341085e+00
    phi[8,5]  R72       1
    phi[8,5]  R2304     -5.77306992416386
    phi[8,5]  R2305     -4.2692988510127661e-01
    phi[8,5]  R2306     -8.7613271057657727e-01
    phi[8,5]  R2307     -3.6038673084969091e+00
    phi[8,5]  R2308     -5.7523767304861373e+00
    phi[8,5]  R2309     -4.4762307877899987e-01
    phi[8,5]  R2310     -4.9250334415482424e+00
    phi[8,5]  R2311     -2.1496642493735285e-01
    phi[8,5]  R2312     -4.5915129506772239e+00
    phi[8,5]  R2313     -1.6084868585879124e+00
    phi[8,5]  R2314     -7.7475936157904268e-01
    phi[8,5]  R2315     -3.4052404667595804e+00
    phi[8,5]  R2316     -6.1287031528666773e+00
    phi[8,5]  R2317     -7.1296656398459834e-02
    phi[8,5]  R2318     -1.9070082192027571e-01
    phi[8,5]  R2319     -3.4626910195743621e-01
    phi[8,5]  R2320     -2.2452968611487423e-01
    phi[8,5]  R2321     -1.2774016625666071e+00
    phi[8,5]  R2322     -8.7264424743708968e-01
    phi[8,5]  R2323     -1.3822461636683041e+00
    phi[8,5]  R2324     -5.6480103886116328e-01
    phi[8,5]  R2325     -2.3042090145338356e-01
    phi[8,5]  R2326     -1.0521437596166106e+00
    phi[8,5]  R2327     -1.6995952625749862e+00
    phi[8,5]  R2328     -1.7164963854726678e-01
    phi[8,5]  R2329     -1.8027313890593721e-01
    phi[8,5]  R2330     -1.8052715647782591e-01
    phi[8,5]  R2331     -2.0545026549542733e-01
    phi[8,5]  R2332     -2.0612682660976556e-01
    phi[8,5]  R2333     -2.4490335320830592e-01
    phi[8,5]  R2334     -2.4913993081816033e-01
    phi[8,5]  R2335     -2.5446743039232156e-01
    phi[8,5]  R2336     -2.5854066345332405e-01
    phi[8,5]  R2337     -2.7081550766507956e-01
    phi[8,5]  R2338     -1.9686545145897266e-01
    phi[8,5]  R2339     -3.9641068760832709e-01
    phi[8,5]  R2340     -4.3909949471985832e-01
    phi[8,5]  R2341     -4.7632637791428134e-01
    phi[8,5]  R2342     -5.2301048709901554e-01
    phi[8,5]  R2343     -5.2961381523398510e-01
    phi[8,5]  R2344     -5.3191452985874565e-01
    phi[8,5]  R2345     -0.534753256047555
    phi[8,5]  R2346     -5.7581351408126880e-01
    phi[8,5]  R2347     -5.8235554691173408e-01
    phi[8,5]  R2348     -1.9011981760491803e-01
    phi[8,5]  R2349     -2.6492937467793753e-01
    phi[8,5]  R2350     -2.6736234844133638e-01
    phi[8,5]  R2351     -2.6967834418966996e-01
    phi[8,5]  R2352     -2.7743475601519418e-01
    phi[8,5]  R2353     -2.7777185743296029e-01
    phi[8,5]  R2354     -2.7793215389739157e-01
    phi[8,5]  R2355     -3.1263776486892114e-01
    phi[8,5]  R2356     -3.1623104916211675e-01
    phi[8,5]  R2357     -3.3806605421675329e-01
    phi[8,5]  R2358     -1.8463174394961335e-01
    phi[8,5]  R2359     -2.1041327656973374e-01
    phi[8,5]  R2360     -2.2358012172320718e-01
    phi[8,5]  R2361     -2.5167850188745522e-01
    phi[8,5]  R2362     -3.0580696759924608e-01
    phi[8,5]  R2363     -3.6763283932782609e-01
    phi[8,5]  R2364     -4.7260213433672682e-01
    phi[8,5]  R2365     -0.53947472176096
    phi[8,5]  R2366     -0.542626863238229
    phi[8,5]  R2367     -5.5115518228841620e-01
    phi[6,7]  R54       1
    phi[6,7]  R55       1
    phi[6,7]  R63       -1
    phi[6,7]  R2368     -3.0999999046325684e+00
    phi[6,7]  R2369     -3.0999999046325684e+00
    phi[6,7]  R2370     -2.2400000095367432e+00
    phi[6,7]  R2371     -2.2400000095367432e+00
    phi[6,7]  R2372     -3.0999999046325684e+00
    phi[6,7]  R2373     -3.0999999046325684e+00
    phi[6,7]  R2374     -2.5699999332427979e+00
    phi[6,7]  R2375     -2.5699999332427979e+00
    phi[6,7]  R2376     -3.0999999046325684e+00
    phi[6,7]  R2377     -3.0999999046325684e+00
    phi[6,7]  R2378     -2.0899999141693115e+00
    phi[6,7]  R2379     -2.0899999141693115e+00
    phi[6,7]  R2380     -3.0999999046325684e+00
    phi[6,7]  R2381     -3.0999999046325684e+00
    phi[6,7]  R2382     2.3352081775665283e+00
    phi[6,7]  R2383     2.6971046924591064e+00
    phi[6,7]  R2384     2.1561522483825684e+00
    phi[6,7]  R2385     1.4242571592330933e+00
    phi[6,7]  R2386     9.4781392812728882e-01
    phi[6,7]  R2387     2.3292881250381470e-01
    phi[6,7]  R2388     -2.5713326930999756e+00
    phi[6,7]  R2389     9.6326857805252075e-02
    phi[6,7]  R2390     -9.4061785936355591e-01
    phi[6,7]  R2391     -2.30448317527771
    phi[6,7]  R2392     -1.0913022756576538e+00
    phi[6,7]  R2393     -1.7075026035308838e+00
    phi[6,7]  R2394     -1.0674458742141724e+00
    phi[6,7]  R2395     -1.4569752216339111e+00
    phi[6,7]  R2396     -1.4675543308258057e+00
    phi[6,7]  R2397     -1.1686152219772339e+00
    phi[6,7]  R2398     -2.8199908733367920e+00
    phi[6,7]  R2399     -3.2676513195037842e+00
    phi[6,7]  R2400     -2.3684391975402832e+00
    phi[6,7]  R2401     -1.0388647317886353e+00
    phi[6,7]  R2402     -2.9406974315643311e+00
    phi[6,7]  R2403     -2.7838253974914551e+00
    phi[6,7]  R2404     -1.8816654682159424e+00
    phi[6,7]  R2405     -1.7148915529251099e+00
    phi[6,7]  R2406     -2.95913028717041
    phi[6,7]  R2407     -2.7803051471710205e+00
    phi[6,7]  R2408     -1.3929710388183594e+00
    phi[6,7]  R2409     -3.2591361999511719e+00
    phi[6,7]  R2410     -2.27364182472229
    phi[6,7]  R2411     -2.9202415943145752e+00
    phi[6,7]  R2412     -2.2405905723571777e+00
    phi[6,7]  R2413     -2.3908915519714355e+00
    phi[6,7]  R2414     -2.0234229564666748e+00
    phi[6,7]  R2415     -1.4838041067123413e+00
    phi[6,7]  R2416     -1.0747042894363403e+00
    phi[6,7]  R2417     -1.7372274398803711e+00
    phi[6,7]  R2418     -1.3823571205139160e+00
    phi[6,7]  R2419     -1.3536016941070557e+00
    phi[6,7]  R2420     -3.0228674411773682e+00
    phi[6,7]  R2421     -8.1145149469375610e-01
    phi[6,7]  R2422     6.5799486637115479e-01
    phi[6,7]  R2423     9.7527700662612915e-01
    phi[6,7]  R2424     1.2964508533477783e+00
    phi[6,7]  R2425     1.8751047551631927e-01
    phi[6,7]  R2426     -0.299600750207901
    phi[6,7]  R2427     -7.7103048563003540e-01
    phi[6,7]  R2428     3.8338100910186768e-01
    phi[6,7]  R2429     -8.2681930065155029e-01
    phi[6,7]  R2430     -2.4086291790008545e+00
    phi[6,7]  R2431     -2.0673902034759521e+00
    phi[6,7]  R2432     2.10866641998291
    phi[6,7]  R2433     2.8177145123481750e-01
    phi[6,7]  R2434     -0.179292693734169
    phi[6,7]  R2435     -3.8770991563796997e-01
    phi[6,7]  R2436     1.1141237020492554e+00
    phi[6,7]  R2437     -1.4681957662105560e-01
    phi[6,7]  R2438     7.0310711860656738e-01
    phi[6,7]  R2439     1.7549513280391693e-01
    phi[6,7]  R2440     9.1958826780319214e-01
    phi[6,7]  R2441     8.6524891853332520e-01
    phi[6,7]  R2442     -3.8530457019805908e-01
    phi[6,7]  R2443     -6.9636249542236328e-01
    phi[6,7]  R2444     -9.7384667396545410e-01
    phi[6,7]  R2445     -6.5875357389450073e-01
    phi[6,7]  R2446     -8.2526482641696930e-02
    phi[6,7]  R2447     -1.7360872030258179e+00
    phi[6,7]  R2448     -0.0976310670375824
    phi[6,7]  R2449     -5.8913275599479675e-02
    phi[6,7]  R2450     -2.5754473209381104e+00
    phi[6,7]  R2451     1.5373377501964569e-01
    phi[6,7]  R2452     -2.7322680950164795e+00
    phi[6,7]  R2453     6.3295882940292358e-01
    phi[6,7]  R2454     4.8233321309089661e-01
    phi[6,7]  R2455     -5.2868628501892090e-01
    phi[6,7]  R2456     8.5413259267807007e-01
    phi[6,7]  R2457     -6.1180430650711060e-01
    phi[6,7]  R2458     6.4918190240859985e-01
    phi[6,7]  R2459     -1.0275367498397827e+00
    phi[6,7]  R2460     -2.0429396629333496e+00
    phi[6,7]  R2461     -7.9672467708587646e-01
    phi[6,7]  R2462     -2.3250651359558105e+00
    phi[6,7]  R2463     2.1792068481445312e+00
    phi[6,7]  R2464     -1.4932667016983032e+00
    phi[6,7]  R2465     1.0587695837020874e+00
    phi[6,7]  R2466     6.0042792558670044e-01
    phi[6,7]  R2467     -7.1883052587509155e-01
    phi[6,7]  R2468     5.6212669610977173e-01
    phi[6,7]  R2469     6.4911139011383057e-01
    phi[6,7]  R2470     8.0117094516754150e-01
    phi[6,7]  R2471     1.6454113721847534e+00
    phi[6,7]  R2472     -2.5483703613281250e+00
    phi[6,7]  R2473     -1.2203072309494019e+00
    phi[6,7]  R2474     -1.9714339971542358e+00
    phi[6,7]  R2475     -2.2899593412876129e-01
    phi[6,7]  R2476     1.7513586282730103e+00
    phi[6,7]  R2477     -1.3622267246246338e+00
    phi[6,7]  R2478     1.9204229116439819e+00
    phi[6,7]  R2479     4.4358074665069580e-01
    phi[6,7]  R2480     -8.5386657714843750e-01
    phi[6,7]  R2481     -1.4615262746810913e+00
    phi[7,6]  R54       -1
    phi[7,6]  R63       1
    phi[7,6]  R64       1
    phi[7,6]  R2482     -3.0999999046325684e+00
    phi[7,6]  R2483     -3.0999999046325684e+00
    phi[7,6]  R2484     -2.2400000095367432e+00
    phi[7,6]  R2485     -2.2400000095367432e+00
    phi[7,6]  R2486     -3.0999999046325684e+00
    phi[7,6]  R2487     -3.0999999046325684e+00
    phi[7,6]  R2488     -2.5699999332427979e+00
    phi[7,6]  R2489     -2.5699999332427979e+00
    phi[7,6]  R2490     -3.0999999046325684e+00
    phi[7,6]  R2491     -3.0999999046325684e+00
    phi[7,6]  R2492     -2.0899999141693115e+00
    phi[7,6]  R2493     -2.0899999141693115e+00
    phi[7,6]  R2494     -3.0999999046325684e+00
    phi[7,6]  R2495     -3.0999999046325684e+00
    phi[7,6]  R2496     6.5799486637115479e-01
    phi[7,6]  R2497     9.7527700662612915e-01
    phi[7,6]  R2498     1.2964508533477783e+00
    phi[7,6]  R2499     1.8751047551631927e-01
    phi[7,6]  R2500     -0.299600750207901
    phi[7,6]  R2501     -7.7103048563003540e-01
    phi[7,6]  R2502     3.8338100910186768e-01
    phi[7,6]  R2503     -8.2681930065155029e-01
    phi[7,6]  R2504     -2.4086291790008545e+00
    phi[7,6]  R2505     -2.0673902034759521e+00
    phi[7,6]  R2506     2.10866641998291
    phi[7,6]  R2507     2.8177145123481750e-01
    phi[7,6]  R2508     -0.179292693734169
    phi[7,6]  R2509     -3.8770991563796997e-01
    phi[7,6]  R2510     1.1141237020492554e+00
    phi[7,6]  R2511     -1.4681957662105560e-01
    phi[7,6]  R2512     7.0310711860656738e-01
    phi[7,6]  R2513     1.7549513280391693e-01
    phi[7,6]  R2514     9.1958826780319214e-01
    phi[7,6]  R2515     8.6524891853332520e-01
    phi[7,6]  R2516     -3.8530457019805908e-01
    phi[7,6]  R2517     -6.9636249542236328e-01
    phi[7,6]  R2518     -9.7384667396545410e-01
    phi[7,6]  R2519     -6.5875357389450073e-01
    phi[7,6]  R2520     -8.2526482641696930e-02
    phi[7,6]  R2521     -1.7360872030258179e+00
    phi[7,6]  R2522     -0.0976310670375824
    phi[7,6]  R2523     -5.8913275599479675e-02
    phi[7,6]  R2524     -2.5754473209381104e+00
    phi[7,6]  R2525     1.5373377501964569e-01
    phi[7,6]  R2526     -2.7322680950164795e+00
    phi[7,6]  R2527     6.3295882940292358e-01
    phi[7,6]  R2528     4.8233321309089661e-01
    phi[7,6]  R2529     -5.2868628501892090e-01
    phi[7,6]  R2530     8.5413259267807007e-01
    phi[7,6]  R2531     -6.1180430650711060e-01
    phi[7,6]  R2532     6.4918190240859985e-01
    phi[7,6]  R2533     -1.0275367498397827e+00
    phi[7,6]  R2534     -2.0429396629333496e+00
    phi[7,6]  R2535     -7.9672467708587646e-01
    phi[7,6]  R2536     -2.3250651359558105e+00
    phi[7,6]  R2537     2.1792068481445312e+00
    phi[7,6]  R2538     -1.4932667016983032e+00
    phi[7,6]  R2539     1.0587695837020874e+00
    phi[7,6]  R2540     6.0042792558670044e-01
    phi[7,6]  R2541     -7.1883052587509155e-01
    phi[7,6]  R2542     5.6212669610977173e-01
    phi[7,6]  R2543     6.4911139011383057e-01
    phi[7,6]  R2544     8.0117094516754150e-01
    phi[7,6]  R2545     1.6454113721847534e+00
    phi[7,6]  R2546     -2.5483703613281250e+00
    phi[7,6]  R2547     -1.2203072309494019e+00
    phi[7,6]  R2548     -1.9714339971542358e+00
    phi[7,6]  R2549     -2.2899593412876129e-01
    phi[7,6]  R2550     1.7513586282730103e+00
    phi[7,6]  R2551     -1.3622267246246338e+00
    phi[7,6]  R2552     1.9204229116439819e+00
    phi[7,6]  R2553     4.4358074665069580e-01
    phi[7,6]  R2554     -8.5386657714843750e-01
    phi[7,6]  R2555     -1.4615262746810913e+00
    phi[7,6]  R2556     2.3352081775665283e+00
    phi[7,6]  R2557     2.6971046924591064e+00
    phi[7,6]  R2558     2.1561522483825684e+00
    phi[7,6]  R2559     1.4242571592330933e+00
    phi[7,6]  R2560     9.4781392812728882e-01
    phi[7,6]  R2561     2.3292881250381470e-01
    phi[7,6]  R2562     -2.5713326930999756e+00
    phi[7,6]  R2563     9.6326857805252075e-02
    phi[7,6]  R2564     -9.4061785936355591e-01
    phi[7,6]  R2565     -2.30448317527771
    phi[7,6]  R2566     -1.0913022756576538e+00
    phi[7,6]  R2567     -1.7075026035308838e+00
    phi[7,6]  R2568     -1.0674458742141724e+00
    phi[7,6]  R2569     -1.4569752216339111e+00
    phi[7,6]  R2570     -1.4675543308258057e+00
    phi[7,6]  R2571     -1.1686152219772339e+00
    phi[7,6]  R2572     -2.8199908733367920e+00
    phi[7,6]  R2573     -3.2676513195037842e+00
    phi[7,6]  R2574     -2.3684391975402832e+00
    phi[7,6]  R2575     -1.0388647317886353e+00
    phi[7,6]  R2576     -2.9406974315643311e+00
    phi[7,6]  R2577     -2.7838253974914551e+00
    phi[7,6]  R2578     -1.8816654682159424e+00
    phi[7,6]  R2579     -1.7148915529251099e+00
    phi[7,6]  R2580     -2.95913028717041
    phi[7,6]  R2581     -2.7803051471710205e+00
    phi[7,6]  R2582     -1.3929710388183594e+00
    phi[7,6]  R2583     -3.2591361999511719e+00
    phi[7,6]  R2584     -2.27364182472229
    phi[7,6]  R2585     -2.9202415943145752e+00
    phi[7,6]  R2586     -2.2405905723571777e+00
    phi[7,6]  R2587     -2.3908915519714355e+00
    phi[7,6]  R2588     -2.0234229564666748e+00
    phi[7,6]  R2589     -1.4838041067123413e+00
    phi[7,6]  R2590     -1.0747042894363403e+00
    phi[7,6]  R2591     -1.7372274398803711e+00
    phi[7,6]  R2592     -1.3823571205139160e+00
    phi[7,6]  R2593     -1.3536016941070557e+00
    phi[7,6]  R2594     -3.0228674411773682e+00
    phi[7,6]  R2595     -8.1145149469375610e-01
    phi[7,9]  R63       1
    phi[7,9]  R64       1
    phi[7,9]  R65       1.0304953161175030e+00
    phi[7,9]  R66       1.3415754206792543e+00
    phi[7,9]  R67       -2.0477249685353107e+00
    phi[7,9]  R68       -1.8766128995991016e-01
    phi[7,9]  R69       -6.2880344547162048e-01
    phi[7,9]  R70       -1.6981592742109530e+00
    phi[7,9]  R71       -5.0896577480679994e-02
    phi[7,9]  R73       -1
    phi[7,9]  R2596     -2.0695045885150654e+00
    phi[7,9]  R2597     -4.1304952207500714e+00
    phi[7,9]  R2598     -8.9842458885748888e-01
    phi[7,9]  R2599     -3.5815754302159974e+00
    phi[7,9]  R2600     -5.1477248731678795e+00
    phi[7,9]  R2601     -1.0522749360972576e+00
    phi[7,9]  R2602     -2.7576612232027080e+00
    phi[7,9]  R2603     -2.3823386432828877e+00
    phi[7,9]  R2604     -3.7288033501041888e+00
    phi[7,9]  R2605     -2.4711964591609479e+00
    phi[7,9]  R2606     -3.7881591883802646e+00
    phi[7,9]  R2607     -3.9184063995835849e-01
    phi[7,9]  R2608     -3.1508964821132484e+00
    phi[7,9]  R2609     -3.0491033271518884e+00
    phi[7,9]  R2610     -1.1947654202848246e-01
    phi[7,9]  R2611     -1.2163116384609074e-01
    phi[7,9]  R2612     -1.2241591634554094e-01
    phi[7,9]  R2613     -1.3365436788213308e-01
    phi[7,9]  R2614     -1.3554054021930809e-01
    phi[7,9]  R2615     -1.4712111306345688e-01
    phi[7,9]  R2616     -1.6576082889045451e-01
    phi[7,9]  R2617     -2.1665490088370221e-01
    phi[7,9]  R2618     -2.4934260854324863e-01
    phi[7,9]  R2619     -2.5435601510532035e-01
    phi[7,9]  R2620     -4.4974581996179452e-01
    phi[7,9]  R2621     -0.602509203520117
    phi[7,9]  R2622     -1.1152720356599364e+00
    phi[7,9]  R2623     -5.0185220172125466e-01
    phi[7,9]  R2624     -5.2399877472080880e-01
    phi[7,9]  R2625     -5.2660871772357765e-01
    phi[7,9]  R2626     -7.3732551330931062e-01
    phi[7,9]  R2627     -8.8760062220111324e-01
    phi[7,9]  R2628     -6.7955145748692858e-01
    phi[7,9]  R2629     -6.8589284241564474e-01
    phi[7,9]  R2630     -1.7872949194453741e-01
    phi[7,9]  R2631     -1.8584427615091148e-01
    phi[7,9]  R2632     -2.0607374648975185e-01
    phi[7,9]  R2633     -2.0888959713027411e-01
    phi[7,9]  R2634     -2.1385613810463155e-01
    phi[7,9]  R2635     -2.1977294893074517e-01
    phi[7,9]  R2636     -2.4921845089317515e-01
    phi[7,9]  R2637     -2.6370902873502555e-01
    phi[7,9]  R2638     -2.6900430262661335e-01
    phi[7,9]  R2639     -3.8945653503231115e-01
    phi[7,9]  R2640     -3.1590710091871577e-01
    phi[7,9]  R2641     -3.6125829629489392e-01
    phi[7,9]  R2642     -3.8602163359252484e-01
    phi[7,9]  R2643     -3.8710237420062538e-01
    phi[7,9]  R2644     -3.8998814759829492e-01
    phi[7,9]  R2645     -3.9743048370618961e-01
    phi[7,9]  R2646     -4.1420011429502490e-01
    phi[7,9]  R2647     -4.3365909544757641e-01
    phi[7,9]  R2648     -5.4326934929858650e-01
    phi[7,9]  R2649     -0.552477593540593
    phi[7,9]  R2650     -2.8111577569511725e-01
    phi[7,9]  R2651     -5.1843490663146019e-01
    phi[7,9]  R2652     -1.5234131870810694e+00
    phi[7,9]  R2653     -1.0334342383595438e+00
    phi[7,9]  R2654     -5.5200071488297286e-01
    phi[7,9]  R2655     -5.6962018404350934e-01
    phi[7,9]  R2656     -6.5118731396593477e-01
    phi[7,9]  R2657     -6.5889242519763758e-01
    phi[7,9]  R2658     -6.5995026714964911e-01
    phi[7,9]  R2659     -6.6003637084152667e-01
    phi[7,9]  R2660     -2.1295740388217022e-01
    phi[7,9]  R2661     -2.1537294496378578e-01
    phi[7,9]  R2662     -2.2033067029553433e-01
    phi[7,9]  R2663     -8.1122819357471221e-01
    phi[7,9]  R2664     -4.0572566839584390e-01
    phi[7,9]  R2665     -1.4259935788668097e+00
    phi[7,9]  R2666     -5.4528453285984746e-01
    phi[7,9]  R2667     -5.5279037686580246e-01
    phi[7,9]  R2668     -0.596989519131238
    phi[7,9]  R2669     -6.0798831274825438e-01
    MARKER    'MARKER'                 'INTEND'
    z[0,1,0]  R2        -1
    z[0,1,0]  R11       1
    z[0,1,0]  R74       -1
    z[0,1,0]  R75       1
    z[0,1,0]  R88       -2.9110053181648254e-01
    z[0,1,0]  R89       -7.7135547995567322e-02
    z[0,1,0]  R90       -1.0992193967103958e-01
    z[0,1,0]  R91       -2.4763907492160797e-01
    z[0,1,0]  R92       -4.5247364044189453e-01
    z[0,1,0]  R93       3.4517128020524979e-02
    z[0,1,0]  R94       -3.4133675694465637e-01
    z[0,1,0]  R95       -3.1733080744743347e-01
    z[0,1,0]  R96       -1.9801306724548340e-01
    z[0,1,0]  R97       -4.4325807690620422e-01
    z[0,1,0]  R98       3.7688564509153366e-02
    z[0,1,0]  R99       1.8515534698963165e-01
    z[0,1,0]  R100      -3.2667997479438782e-01
    z[0,1,0]  R101      4.4320335984230042e-01
    z[0,1,0]  R102      3.5500061511993408e-01
    z[0,1,0]  R103      -2.6508134603500366e-01
    z[0,1,0]  R104      3.9741504192352295e-01
    z[0,1,0]  R105      3.8087822496891022e-02
    z[0,1,0]  R106      4.8788771033287048e-02
    z[0,1,0]  R107      -6.4040142297744751e-01
    z[0,1,0]  R108      6.1919075250625610e-01
    z[0,1,0]  R109      -2.0823439955711365e-01
    z[0,1,0]  R110      -3.6439269781112671e-01
    z[0,1,0]  R111      -2.5745810940861702e-02
    z[0,1,0]  R112      0.552279531955719
    z[0,1,0]  R113      -1.2913800776004791e-01
    z[0,1,0]  R114      -2.2922135889530182e-01
    z[0,1,0]  R115      7.8371495008468628e-02
    z[0,1,0]  R116      -4.2302292585372925e-01
    z[0,1,0]  R117      -4.5666176825761795e-02
    z[0,1,0]  R118      3.9789915084838867e-01
    z[0,1,0]  R119      -1.8887579441070557e-02
    z[0,1,0]  R120      1.0406654328107834e-02
    z[0,1,0]  R121      2.2542765736579895e-01
    z[0,1,0]  R122      1.2186097353696823e-01
    z[0,1,0]  R123      1.8019260466098785e-01
    z[0,1,0]  R124      8.4562357515096664e-03
    z[0,1,0]  R125      4.1901251673698425e-01
    z[0,1,0]  R126      -4.1141349077224731e-01
    z[0,1,0]  R127      1.2014894187450409e-01
    z[0,1,0]  R128      -6.8537926673889160e-01
    z[0,1,0]  R129      -6.1989778280258179e-01
    z[0,1,0]  R130      -3.9015492796897888e-01
    z[0,1,0]  R131      -7.6221138238906860e-01
    z[0,1,0]  R132      -7.7940732240676880e-01
    z[0,1,0]  R133      6.3415724039077759e-01
    z[0,1,0]  R134      -2.0341657102108002e-01
    z[0,1,0]  R135      8.5822738707065582e-02
    z[0,1,0]  R136      7.1230880916118622e-02
    z[0,1,0]  R137      -6.0418337583541870e-02
    z[0,1,0]  R138      3.2008466124534607e-01
    z[0,1,0]  R139      4.0764841437339783e-01
    z[0,1,0]  R140      4.9026329070329666e-03
    z[0,1,0]  R141      8.2191802561283112e-02
    z[0,1,0]  R142      0.0870785117149353
    z[0,1,0]  R143      2.6003026962280273e-01
    z[0,1,0]  R144      5.3831964731216431e-01
    z[0,1,0]  R145      1.6848705708980560e-01
    z[0,1,0]  R146      1.2245961278676987e-01
    z[0,1,0]  R147      4.3266189098358154e-01
    z[0,1,0]  R148      -1.7281191051006317e-01
    z[0,1,0]  R149      3.7440863251686096e-01
    z[0,1,0]  R150      -8.8296726346015930e-02
    z[0,1,0]  R151      -8.5912920534610748e-02
    z[0,1,0]  R152      -8.5435574874281883e-03
    z[0,1,0]  R153      5.6546766310930252e-02
    z[0,1,0]  R154      4.1534101963043213e-01
    z[0,1,0]  R155      -9.5797730609774590e-03
    z[0,1,0]  R156      1.6904467344284058e-01
    z[0,1,0]  R157      9.3381822109222412e-02
    z[0,1,0]  R158      3.4843999147415161e-01
    z[0,1,0]  R159      1.5935826301574707e-01
    z[0,1,0]  R160      2.6861077547073364e-01
    z[0,1,0]  R161      1.4243774116039276e-01
    z[0,1,0]  R162      3.2409456372261047e-01
    z[0,1,0]  R163      4.6643380075693130e-02
    z[0,1,0]  R164      2.9713290929794312e-01
    z[0,1,0]  R165      1.7995053529739380e-01
    z[0,1,0]  R166      4.1195189952850342e-01
    z[0,1,0]  R167      -7.0935539901256561e-02
    z[0,1,1]  R3        -1
    z[0,1,1]  R12       1
    z[0,1,1]  R76       -1
    z[0,1,1]  R77       1
    z[0,1,1]  R88       -7.3140613734722137e-02
    z[0,1,1]  R89       -6.4375951886177063e-02
    z[0,1,1]  R90       -3.2401908189058304e-02
    z[0,1,1]  R91       -6.9302178919315338e-02
    z[0,1,1]  R92       -1.6971176862716675e-01
    z[0,1,1]  R93       -1.5012322366237640e-01
    z[0,1,1]  R94       7.0354324579238892e-01
    z[0,1,1]  R95       7.1915447711944580e-01
    z[0,1,1]  R96       8.3061850070953369e-01
    z[0,1,1]  R97       1.5530514717102051e-01
    z[0,1,1]  R98       -3.0270934104919434e-01
    z[0,1,1]  R99       -5.4343408346176147e-01
    z[0,1,1]  R100      -6.0718166828155518e-01
    z[0,1,1]  R101      -5.8420103788375854e-01
    z[0,1,1]  R102      -5.5674254894256592e-01
    z[0,1,1]  R103      -7.3574233055114746e-01
    z[0,1,1]  R104      -1.1066448874771595e-02
    z[0,1,1]  R105      -7.6014584302902222e-01
    z[0,1,1]  R106      -7.7486616373062134e-01
    z[0,1,1]  R107      0.0572950579226017
    z[0,1,1]  R108      4.7785595059394836e-01
    z[0,1,1]  R109      -1.8672700226306915e-01
    z[0,1,1]  R110      2.8185930848121643e-01
    z[0,1,1]  R111      -1.8345098197460175e-01
    z[0,1,1]  R112      4.2447263002395630e-01
    z[0,1,1]  R113      -2.7415317296981812e-01
    z[0,1,1]  R114      1.4668746292591095e-01
    z[0,1,1]  R115      2.9270383715629578e-01
    z[0,1,1]  R116      -3.7561511993408203e-01
    z[0,1,1]  R117      4.5177853107452393e-01
    z[0,1,1]  R118      4.3619260191917419e-01
    z[0,1,1]  R119      0.275611013174057
    z[0,1,1]  R120      0.527420163154602
    z[0,1,1]  R121      -1.5529237687587738e-01
    z[0,1,1]  R122      4.1819038987159729e-01
    z[0,1,1]  R123      -1.5105533599853516e-01
    z[0,1,1]  R124      1.2223100289702415e-02
    z[0,1,1]  R125      2.4060933291912079e-01
    z[0,1,1]  R126      -6.6439077258110046e-02
    z[0,1,1]  R127      -7.0705041289329529e-02
    z[0,1,1]  R128      0.0571502223610878
    z[0,1,1]  R129      -1.4520107768476009e-02
    z[0,1,1]  R130      5.2287089824676514e-01
    z[0,1,1]  R131      1.9970615208148956e-01
    z[0,1,1]  R132      -1.5222278423607349e-02
    z[0,1,1]  R133      -3.3910888433456421e-01
    z[0,1,1]  R134      1.7417545616626740e-01
    z[0,1,1]  R135      4.5699110627174377e-01
    z[0,1,1]  R136      2.8019109368324280e-01
    z[0,1,1]  R137      6.7615598440170288e-01
    z[0,1,1]  R138      -4.2932316660881042e-01
    z[0,1,1]  R139      -5.7425397634506226e-01
    z[0,1,1]  R140      -6.2131518125534058e-01
    z[0,1,1]  R141      -7.5799202919006348e-01
    z[0,1,1]  R142      -5.5511152744293213e-01
    z[0,1,1]  R143      -5.6249588727951050e-01
    z[0,1,1]  R144      -6.5417569875717163e-01
    z[0,1,1]  R145      -5.1269501447677612e-01
    z[0,1,1]  R146      -4.8968937993049622e-01
    z[0,1,1]  R147      -4.9344503879547119e-01
    z[0,1,1]  R148      -8.4892296791076660e-01
    z[0,1,1]  R149      -7.8575527667999268e-01
    z[0,1,1]  R150      -7.1145397424697876e-01
    z[0,1,1]  R151      -7.1247613430023193e-01
    z[0,1,1]  R152      -6.9293183088302612e-01
    z[0,1,1]  R153      -6.3465994596481323e-01
    z[0,1,1]  R154      -0.61861252784729
    z[0,1,1]  R155      -5.3537541627883911e-01
    z[0,1,1]  R156      0.595018208026886
    z[0,1,1]  R157      4.8361852765083313e-01
    z[0,1,1]  R158      -7.9290562868118286e-01
    z[0,1,1]  R159      -6.0925519466400146e-01
    z[0,1,1]  R160      -0.825687050819397
    z[0,1,1]  R161      -0.647787868976593
    z[0,1,1]  R162      6.7067429423332214e-02
    z[0,1,1]  R163      -3.6139285564422607e-01
    z[0,1,1]  R164      -3.7306267768144608e-02
    z[0,1,1]  R165      4.8320105671882629e-01
    z[0,1,1]  R166      3.7311285734176636e-01
    z[0,1,1]  R167      5.6233358383178711e-01
    z[0,1,2]  R4        -1
    z[0,1,2]  R13       1
    z[0,1,2]  R78       -1
    z[0,1,2]  R79       1
    z[0,1,2]  R88       6.2608234584331512e-02
    z[0,1,2]  R89       1.2828177213668823e-01
    z[0,1,2]  R90       1.1891358345746994e-01
    z[0,1,2]  R91       -1.2434328347444534e-01
    z[0,1,2]  R92       5.8074957132339478e-01
    z[0,1,2]  R93       3.8947516679763794e-01
    z[0,1,2]  R94       -4.9320429563522339e-01
    z[0,1,2]  R95       -4.7367650270462036e-01
    z[0,1,2]  R96       -0.334102064371109
    z[0,1,2]  R97       4.6975514292716980e-01
    z[0,1,2]  R98       8.1207972764968872e-01
    z[0,1,2]  R99       6.0442489385604858e-01
    z[0,1,2]  R100      6.0188883543014526e-01
    z[0,1,2]  R101      6.0502427816390991e-01
    z[0,1,2]  R102      5.0293004512786865e-01
    z[0,1,2]  R103      3.8175088167190552e-01
    z[0,1,2]  R104      6.6689413785934448e-01
    z[0,1,2]  R105      -9.7829692065715790e-02
    z[0,1,2]  R106      -1.3991887867450714e-01
    z[0,1,2]  R107      4.3921470642089844e-01
    z[0,1,2]  R108      -1.2083734571933746e-01
    z[0,1,2]  R109      -0.544776201248169
    z[0,1,2]  R110      -5.3840112686157227e-01
    z[0,1,2]  R111      -1.5728504955768585e-01
    z[0,1,2]  R112      -0.00527540547773242
    z[0,1,2]  R113      -3.1793826818466187e-01
    z[0,1,2]  R114      -1.8751792609691620e-01
    z[0,1,2]  R115      -5.8714441955089569e-02
    z[0,1,2]  R116      -4.3605649471282959e-01
    z[0,1,2]  R117      -6.2979239225387573e-01
    z[0,1,2]  R118      -5.3202873468399048e-01
    z[0,1,2]  R119      -3.3552855253219604e-01
    z[0,1,2]  R120      -3.3924323320388794e-01
    z[0,1,2]  R121      -4.3600523471832275e-01
    z[0,1,2]  R122      -2.6900994777679443e-01
    z[0,1,2]  R123      -1.7215685546398163e-01
    z[0,1,2]  R124      -3.1496292352676392e-01
    z[0,1,2]  R125      -4.3559196591377258e-01
    z[0,1,2]  R126      -3.7466189265251160e-01
    z[0,1,2]  R127      -5.8040237426757812e-01
    z[0,1,2]  R128      3.3827850222587585e-01
    z[0,1,2]  R129      2.6897537708282471e-01
    z[0,1,2]  R130      4.7927427291870117e-01
    z[0,1,2]  R131      5.6895589828491211e-01
    z[0,1,2]  R132      3.1550264358520508e-01
    z[0,1,2]  R133      2.3017936944961548e-01
    z[0,1,2]  R134      -8.0488801002502441e-01
    z[0,1,2]  R135      -6.7732048034667969e-01
    z[0,1,2]  R136      -5.6877499818801880e-01
    z[0,1,2]  R137      -4.7535607218742371e-01
    z[0,1,2]  R138      4.1857668757438660e-01
    z[0,1,2]  R139      7.0329317823052406e-03
    z[0,1,2]  R140      2.1478319168090820e-01
    z[0,1,2]  R141      -3.4359315037727356e-01
    z[0,1,2]  R142      -2.9130160808563232e-01
    z[0,1,2]  R143      -0.227743998169899
    z[0,1,2]  R144      -1.8006688356399536e-01
    z[0,1,2]  R145      2.9676848649978638e-01
    z[0,1,2]  R146      -5.0348842144012451e-01
    z[0,1,2]  R147      -4.6433243155479431e-01
    z[0,1,2]  R148      -4.0656253695487976e-01
    z[0,1,2]  R149      1.4423318207263947e-01
    z[0,1,2]  R150      1.1157031171023846e-02
    z[0,1,2]  R151      4.5995819568634033e-01
    z[0,1,2]  R152      7.3543138802051544e-02
    z[0,1,2]  R153      -1.3757381588220596e-02
    z[0,1,2]  R154      1.4972053468227386e-01
    z[0,1,2]  R155      -4.3314412236213684e-01
    z[0,1,2]  R156      -3.6220791935920715e-01
    z[0,1,2]  R157      -5.7210975885391235e-01
    z[0,1,2]  R158      8.0398945137858391e-03
    z[0,1,2]  R159      3.2255479693412781e-01
    z[0,1,2]  R160      3.1184738874435425e-01
    z[0,1,2]  R161      2.2299650311470032e-01
    z[0,1,2]  R162      1.6216664016246796e-01
    z[0,1,2]  R163      -4.9299055337905884e-01
    z[0,1,2]  R164      8.9813880622386932e-02
    z[0,1,2]  R165      -6.4932525157928467e-01
    z[0,1,2]  R166      -0.747498095035553
    z[0,1,2]  R167      -6.4216977357864380e-01
    z[0,1,3]  R5        -1
    z[0,1,3]  R14       1
    z[0,1,3]  R80       -1
    z[0,1,3]  R81       1
    z[0,1,3]  R88       -8.0044138431549072e-01
    z[0,1,3]  R89       -7.3260128498077393e-01
    z[0,1,3]  R90       -9.2536401748657227e-01
    z[0,1,3]  R91       -5.7159650325775146e-01
    z[0,1,3]  R92       -1.0784323513507843e-01
    z[0,1,3]  R93       -1.2085956335067749e-01
    z[0,1,3]  R94       -1.8910260498523712e-01
    z[0,1,3]  R95       -1.9142301380634308e-01
    z[0,1,3]  R96       -2.0735612511634827e-01
    z[0,1,3]  R97       3.5851910710334778e-02
    z[0,1,3]  R98       9.4207823276519775e-02
    z[0,1,3]  R99       -3.9301950484514236e-02
    z[0,1,3]  R100      0.0373460054397583
    z[0,1,3]  R101      -2.0858001708984375e-01
    z[0,1,3]  R102      -1.6748347878456116e-01
    z[0,1,3]  R103      1.0246150940656662e-01
    z[0,1,3]  R104      -1.7951881885528564e-01
    z[0,1,3]  R105      -3.3786278963088989e-01
    z[0,1,3]  R106      -2.1383160352706909e-01
    z[0,1,3]  R107      -7.5724922120571136e-02
    z[0,1,3]  R108      -5.0463861227035522e-01
    z[0,1,3]  R109      4.8110455274581909e-01
    z[0,1,3]  R110      4.5489895343780518e-01
    z[0,1,3]  R111      4.5532214641571045e-01
    z[0,1,3]  R112      -3.1989842653274536e-01
    z[0,1,3]  R113      7.7010315656661987e-01
    z[0,1,3]  R114      8.1475955247879028e-01
    z[0,1,3]  R115      6.9427573680877686e-01
    z[0,1,3]  R116      3.7086969614028931e-01
    z[0,1,3]  R117      5.2603012323379517e-01
    z[0,1,3]  R118      0.552764356136322
    z[0,1,3]  R119      4.5846515893936157e-01
    z[0,1,3]  R120      0.440618634223938
    z[0,1,3]  R121      4.2818653583526611e-01
    z[0,1,3]  R122      4.3854394555091858e-01
    z[0,1,3]  R123      8.4263467788696289e-01
    z[0,1,3]  R124      8.0142879486083984e-01
    z[0,1,3]  R125      4.2945098876953125e-01
    z[0,1,3]  R126      7.6675540208816528e-01
    z[0,1,3]  R127      7.1963596343994141e-01
    z[0,1,3]  R128      -6.3158601522445679e-01
    z[0,1,3]  R129      -5.0303298234939575e-01
    z[0,1,3]  R130      -7.2316408157348633e-02
    z[0,1,3]  R131      -5.6475561112165451e-02
    z[0,1,3]  R132      -1.6880510747432709e-01
    z[0,1,3]  R133      -7.7094823122024536e-02
    z[0,1,3]  R134      2.0961783826351166e-01
    z[0,1,3]  R135      -5.4559266567230225e-01
    z[0,1,3]  R136      -8.2782298326492310e-02
    z[0,1,3]  R137      -1.4568190276622772e-01
    z[0,1,3]  R138      -2.1791622042655945e-01
    z[0,1,3]  R139      -4.3024352192878723e-01
    z[0,1,3]  R140      6.3930678367614746e-01
    z[0,1,3]  R141      4.6592387557029724e-01
    z[0,1,3]  R142      -2.5682101026177406e-02
    z[0,1,3]  R143      -3.0834561586380005e-01
    z[0,1,3]  R144      -2.6775610446929932e-01
    z[0,1,3]  R145      4.7634443640708923e-01
    z[0,1,3]  R146      3.9109072089195251e-01
    z[0,1,3]  R147      -1.5720802545547485e-01
    z[0,1,3]  R148      -3.4958653151988983e-02
    z[0,1,3]  R149      -2.1188369393348694e-01
    z[0,1,3]  R150      -1.2492434680461884e-01
    z[0,1,3]  R151      5.2482996135950089e-02
    z[0,1,3]  R152      5.5309587717056274e-01
    z[0,1,3]  R153      -2.6708588004112244e-01
    z[0,1,3]  R154      1.7133103311061859e-01
    z[0,1,3]  R155      2.1449856460094452e-02
    z[0,1,3]  R156      -4.7806450724601746e-01
    z[0,1,3]  R157      -4.8097869753837585e-01
    z[0,1,3]  R158      -1.2466013431549072e-01
    z[0,1,3]  R159      -2.6293888688087463e-01
    z[0,1,3]  R160      3.3467465639114380e-01
    z[0,1,3]  R161      1.5844729542732239e-01
    z[0,1,3]  R162      -6.4167755842208862e-01
    z[0,1,3]  R163      -6.8747711181640625e-01
    z[0,1,3]  R164      -3.5609990358352661e-01
    z[0,1,3]  R165      2.1293807029724121e-01
    z[0,1,3]  R166      2.8251573443412781e-01
    z[0,1,3]  R167      3.0904152989387512e-01
    z[0,1,4]  R6        -1
    z[0,1,4]  R15       1
    z[0,1,4]  R82       -1
    z[0,1,4]  R83       1
    z[0,1,4]  R88       -2.1164520084857941e-01
    z[0,1,4]  R89       -3.9901182055473328e-01
    z[0,1,4]  R90       2.5594955682754517e-01
    z[0,1,4]  R91       3.0116474628448486e-01
    z[0,1,4]  R92       -1.1749612540006638e-01
    z[0,1,4]  R93       -2.0477820653468370e-03
    z[0,1,4]  R94       3.2114297151565552e-01
    z[0,1,4]  R95       -1.7730036750435829e-02
    z[0,1,4]  R96       -1.3784086704254150e-01
    z[0,1,4]  R97       -7.2555428743362427e-01
    z[0,1,4]  R98       -3.5865274071693420e-01
    z[0,1,4]  R99       -2.5757363438606262e-01
    z[0,1,4]  R100      -3.9924946427345276e-01
    z[0,1,4]  R101      1.2988951057195663e-02
    z[0,1,4]  R102      2.8092095255851746e-01
    z[0,1,4]  R103      1.6135616600513458e-01
    z[0,1,4]  R104      1.2858679890632629e-01
    z[0,1,4]  R105      1.3438127934932709e-01
    z[0,1,4]  R106      -1.8022048473358154e-01
    z[0,1,4]  R107      2.6228258013725281e-01
    z[0,1,4]  R108      2.6210841536521912e-01
    z[0,1,4]  R109      5.4431253671646118e-01
    z[0,1,4]  R110      3.6802875995635986e-01
    z[0,1,4]  R111      5.4675036668777466e-01
    z[0,1,4]  R112      -4.5000213384628296e-01
    z[0,1,4]  R113      -3.7259936332702637e-01
    z[0,1,4]  R114      -2.2440558671951294e-01
    z[0,1,4]  R115      -6.1998224258422852e-01
    z[0,1,4]  R116      4.9447005987167358e-01
    z[0,1,4]  R117      -1.9379186630249023e-01
    z[0,1,4]  R118      2.1994405984878540e-01
    z[0,1,4]  R119      7.5776636600494385e-01
    z[0,1,4]  R120      6.0271179676055908e-01
    z[0,1,4]  R121      6.7618530988693237e-01
    z[0,1,4]  R122      5.8848571777343750e-01
    z[0,1,4]  R123      -0.422538697719574
    z[0,1,4]  R124      -5.2651070058345795e-02
    z[0,1,4]  R125      3.9391061663627625e-01
    z[0,1,4]  R126      -2.7618253231048584e-01
    z[0,1,4]  R127      -1.8348044157028198e-01
    z[0,1,4]  R128      5.4618109017610550e-02
    z[0,1,4]  R129      4.3251585960388184e-01
    z[0,1,4]  R130      2.2884850203990936e-01
    z[0,1,4]  R131      1.3395678251981735e-02
    z[0,1,4]  R132      -3.2032021880149841e-01
    z[0,1,4]  R133      -1.6126623749732971e-01
    z[0,1,4]  R134      -1.6589350998401642e-01
    z[0,1,4]  R135      1.5212227404117584e-01
    z[0,1,4]  R136      1.6600900888442993e-01
    z[0,1,4]  R137      -4.0259528160095215e-01
    z[0,1,4]  R138      2.1024408936500549e-01
    z[0,1,4]  R139      3.2547575235366821e-01
    z[0,1,4]  R140      1.2544916570186615e-01
    z[0,1,4]  R141      1.4493545889854431e-01
    z[0,1,4]  R142      -0.635603129863739
    z[0,1,4]  R143      -3.5129398107528687e-01
    z[0,1,4]  R144      3.6472561955451965e-01
    z[0,1,4]  R145      -1.0093870013952255e-01
    z[0,1,4]  R146      -2.8051188588142395e-01
    z[0,1,4]  R147      4.1372036933898926e-01
    z[0,1,4]  R148      -1.8713331222534180e-01
    z[0,1,4]  R149      -9.2841759324073792e-02
    z[0,1,4]  R150      -0.458484411239624
    z[0,1,4]  R151      -2.1331407129764557e-01
    z[0,1,4]  R152      -2.4745023250579834e-01
    z[0,1,4]  R153      -3.6730185151100159e-02
    z[0,1,4]  R154      5.9393906593322754e-01
    z[0,1,4]  R155      1.0587974451482296e-02
    z[0,1,4]  R156      -2.6298624277114868e-01
    z[0,1,4]  R157      -1.3785381615161896e-01
    z[0,1,4]  R158      4.1813701391220093e-01
    z[0,1,4]  R159      -1.7909309267997742e-01
    z[0,1,4]  R160      1.4182345569133759e-01
    z[0,1,4]  R161      -4.0630164742469788e-01
    z[0,1,4]  R162      -4.0135571360588074e-01
    z[0,1,4]  R163      1.4454364776611328e-01
    z[0,1,4]  R164      -4.4148343801498413e-01
    z[0,1,4]  R165      -3.9723706245422363e-01
    z[0,1,4]  R166      1.9270395860075951e-02
    z[0,1,4]  R167      -1.1284729093313217e-01
    z[0,1,5]  R7        -1
    z[0,1,5]  R16       1
    z[0,1,5]  R84       -1
    z[0,1,5]  R85       1
    z[0,1,5]  R88       -4.6946471929550171e-01
    z[0,1,5]  R89       -3.6508047580718994e-01
    z[0,1,5]  R90       1.1537971906363964e-02
    z[0,1,5]  R91       -4.3312925100326538e-01
    z[0,1,5]  R92       -1.4218859374523163e-01
    z[0,1,5]  R93       -4.0969517827033997e-01
    z[0,1,5]  R94       4.2105689644813538e-02
    z[0,1,5]  R95       0.0718042328953743
    z[0,1,5]  R96       -3.0032646656036377e-01
    z[0,1,5]  R97       -4.3200269341468811e-02
    z[0,1,5]  R98       3.2576853036880493e-01
    z[0,1,5]  R99       3.7302923202514648e-01
    z[0,1,5]  R100      1.2362153269350529e-02
    z[0,1,5]  R101      7.5328819453716278e-02
    z[0,1,5]  R102      4.5080298185348511e-01
    z[0,1,5]  R103      4.5079210400581360e-01
    z[0,1,5]  R104      5.8838760852813721e-01
    z[0,1,5]  R105      -5.0827842950820923e-01
    z[0,1,5]  R106      -4.9634787440299988e-01
    z[0,1,5]  R107      4.2970347404479980e-01
    z[0,1,5]  R108      -1.7995594441890717e-01
    z[0,1,5]  R109      3.0343741178512573e-01
    z[0,1,5]  R110      -2.6977434754371643e-01
    z[0,1,5]  R111      -2.3725025355815887e-02
    z[0,1,5]  R112      -3.3120924234390259e-01
    z[0,1,5]  R113      -2.7226004004478455e-01
    z[0,1,5]  R114      -1.7371596395969391e-01
    z[0,1,5]  R115      -0.195637509226799
    z[0,1,5]  R116      -1.8987011909484863e-01
    z[0,1,5]  R117      -1.5229150652885437e-01
    z[0,1,5]  R118      4.2402278631925583e-02
    z[0,1,5]  R119      5.8454502373933792e-02
    z[0,1,5]  R120      2.0937785506248474e-01
    z[0,1,5]  R121      -2.1447671949863434e-01
    z[0,1,5]  R122      0.0199163518846035
    z[0,1,5]  R123      -2.7964893728494644e-02
    z[0,1,5]  R124      -2.4191781878471375e-01
    z[0,1,5]  R125      -3.7180560827255249e-01
    z[0,1,5]  R126      -1.4547628164291382e-01
    z[0,1,5]  R127      -1.2203764170408249e-01
    z[0,1,5]  R128      1.0035312175750732e-01
    z[0,1,5]  R129      1.2102705240249634e-01
    z[0,1,5]  R130      -4.0607705712318420e-01
    z[0,1,5]  R131      -2.6194760575890541e-03
    z[0,1,5]  R132      -4.0177392959594727e-01
    z[0,1,5]  R133      1.4393597841262817e-01
    z[0,1,5]  R134      -2.7187490463256836e-01
    z[0,1,5]  R135      1.6387138515710831e-02
    z[0,1,5]  R136      -3.2049903273582458e-01
    z[0,1,5]  R137      2.6123279333114624e-01
    z[0,1,5]  R138      -6.3597774505615234e-01
    z[0,1,5]  R139      -4.5043057203292847e-01
    z[0,1,5]  R140      3.3822205662727356e-01
    z[0,1,5]  R141      0.0916120857000351
    z[0,1,5]  R142      1.9699060916900635e-01
    z[0,1,5]  R143      -5.8789849281311035e-01
    z[0,1,5]  R144      9.2904157936573029e-02
    z[0,1,5]  R145      -4.9578076601028442e-01
    z[0,1,5]  R146      4.9798467755317688e-01
    z[0,1,5]  R147      -8.7487436830997467e-02
    z[0,1,5]  R148      1.6432522237300873e-01
    z[0,1,5]  R149      -6.0462478548288345e-02
    z[0,1,5]  R150      1.4008009433746338e-01
    z[0,1,5]  R151      3.2220765948295593e-01
    z[0,1,5]  R152      -0.383074551820755
    z[0,1,5]  R153      7.2040760517120361e-01
    z[0,1,5]  R154      1.2024323642253876e-01
    z[0,1,5]  R155      2.5460805743932724e-02
    z[0,1,5]  R156      -3.5921093821525574e-01
    z[0,1,5]  R157      -4.1875803470611572e-01
    z[0,1,5]  R158      2.2691969573497772e-01
    z[0,1,5]  R159      -4.0171968936920166e-01
    z[0,1,5]  R160      6.0343381017446518e-02
    z[0,1,5]  R161      5.5310624837875366e-01
    z[0,1,5]  R162      -0.295651376247406
    z[0,1,5]  R163      -3.4224978089332581e-01
    z[0,1,5]  R164      -7.4231362342834473e-01
    z[0,1,5]  R165      3.2469585537910461e-01
    z[0,1,5]  R166      4.3311398476362228e-02
    z[0,1,5]  R167      1.8013213574886322e-01
    z[0,1,6]  R8        -1
    z[0,1,6]  R17       1
    z[0,1,6]  R86       -1
    z[0,1,6]  R87       1
    z[0,1,6]  R88       -9.6968440338969231e-03
    z[0,1,6]  R89       -3.7980365753173828e-01
    z[0,1,6]  R90       2.2535514831542969e-01
    z[0,1,6]  R91       -5.5980980396270752e-01
    z[0,1,6]  R92       -6.1930793523788452e-01
    z[0,1,6]  R93       -8.0132347345352173e-01
    z[0,1,6]  R94       6.7823834717273712e-02
    z[0,1,6]  R95       -3.4005227684974670e-01
    z[0,1,6]  R96       -8.3945453166961670e-02
    z[0,1,6]  R97       1.7073978483676910e-01
    z[0,1,6]  R98       -6.1976794153451920e-02
    z[0,1,6]  R99       3.1309393048286438e-01
    z[0,1,6]  R100      -3.7321012467145920e-02
    z[0,1,6]  R101      -2.1651054918766022e-01
    z[0,1,6]  R102      -2.9716560617089272e-02
    z[0,1,6]  R103      5.4164156317710876e-02
    z[0,1,6]  R104      -4.7218024730682373e-02
    z[0,1,6]  R105      -1.4352865517139435e-01
    z[0,1,6]  R106      2.3034781217575073e-01
    z[0,1,6]  R107      -3.6677280068397522e-01
    z[0,1,6]  R108      -1.3382703065872192e-01
    z[0,1,6]  R109      7.1961626410484314e-02
    z[0,1,6]  R110      -2.8764751553535461e-01
    z[0,1,6]  R111      -6.5888333320617676e-01
    z[0,1,6]  R112      3.1661653518676758e-01
    z[0,1,6]  R113      3.2620962709188461e-02
    z[0,1,6]  R114      -0.382634699344635
    z[0,1,6]  R115      8.0147329717874527e-03
    z[0,1,6]  R116      -2.6781329512596130e-01
    z[0,1,6]  R117      2.4436981976032257e-01
    z[0,1,6]  R118      -1.1241012066602707e-01
    z[0,1,6]  R119      1.5259535610675812e-01
    z[0,1,6]  R120      7.3405079543590546e-02
    z[0,1,6]  R121      -2.1999014914035797e-01
    z[0,1,6]  R122      -4.4594547152519226e-01
    z[0,1,6]  R123      1.6037710011005402e-01
    z[0,1,6]  R124      -4.4383895397186279e-01
    z[0,1,6]  R125      -0.314582496881485
    z[0,1,6]  R126      2.4479079991579056e-02
    z[0,1,6]  R127      2.7796393632888794e-01
    z[0,1,6]  R128      -2.4538420140743256e-02
    z[0,1,6]  R129      0.297335684299469
    z[0,1,6]  R130      3.4954464435577393e-01
    z[0,1,6]  R131      2.2817702591419220e-01
    z[0,1,6]  R132      1.5097934752702713e-02
    z[0,1,6]  R133      -6.1416542530059814e-01
    z[0,1,6]  R134      3.6751002073287964e-01
    z[0,1,6]  R135      -6.2844090163707733e-02
    z[0,1,6]  R136      -6.7511671781539917e-01
    z[0,1,6]  R137      2.4829532206058502e-01
    z[0,1,6]  R138      -2.0460508763790131e-01
    z[0,1,6]  R139      -1.0036907345056534e-01
    z[0,1,6]  R140      1.7019617557525635e-01
    z[0,1,6]  R141      2.3270641267299652e-01
    z[0,1,6]  R142      3.9491218328475952e-01
    z[0,1,6]  R143      2.4653873406350613e-03
    z[0,1,6]  R144      -1.9103090465068817e-01
    z[0,1,6]  R145      3.7120506167411804e-01
    z[0,1,6]  R146      -1.0990805923938751e-01
    z[0,1,6]  R147      3.8752806186676025e-01
    z[0,1,6]  R148      -1.4466822147369385e-01
    z[0,1,6]  R149      4.0550419688224792e-01
    z[0,1,6]  R150      -4.9038353562355042e-01
    z[0,1,6]  R151      3.4836760163307190e-01
    z[0,1,6]  R152      -2.1705206483602524e-02
    z[0,1,6]  R153      -4.6356637030839920e-02
    z[0,1,6]  R154      1.6067904233932495e-01
    z[0,1,6]  R155      7.2418713569641113e-01
    z[0,1,6]  R156      -2.4380896985530853e-01
    z[0,1,6]  R157      -6.6189341247081757e-02
    z[0,1,6]  R158      -8.9187301695346832e-02
    z[0,1,6]  R159      -4.8660197854042053e-01
    z[0,1,6]  R160      -1.1435898393392563e-01
    z[0,1,6]  R161      1.1933930218219757e-01
    z[0,1,6]  R162      4.5157539844512939e-01
    z[0,1,6]  R163      -1.1630688607692719e-01
    z[0,1,6]  R164      -1.7178329825401306e-01
    z[0,1,6]  R165      -6.2800779938697815e-02
    z[0,1,6]  R166      2.2420226037502289e-01
    z[0,1,6]  R167      3.5451132059097290e-01
    z[1,0,0]  R2        1
    z[1,0,0]  R11       -1
    z[1,0,0]  R168      -1
    z[1,0,0]  R169      1
    z[1,0,0]  R182      -6.8537926673889160e-01
    z[1,0,0]  R183      -6.1989778280258179e-01
    z[1,0,0]  R184      -3.9015492796897888e-01
    z[1,0,0]  R185      -7.6221138238906860e-01
    z[1,0,0]  R186      -7.7940732240676880e-01
    z[1,0,0]  R187      6.3415724039077759e-01
    z[1,0,0]  R188      -2.0341657102108002e-01
    z[1,0,0]  R189      8.5822738707065582e-02
    z[1,0,0]  R190      7.1230880916118622e-02
    z[1,0,0]  R191      -6.0418337583541870e-02
    z[1,0,0]  R192      3.2008466124534607e-01
    z[1,0,0]  R193      4.0764841437339783e-01
    z[1,0,0]  R194      4.9026329070329666e-03
    z[1,0,0]  R195      8.2191802561283112e-02
    z[1,0,0]  R196      0.0870785117149353
    z[1,0,0]  R197      2.6003026962280273e-01
    z[1,0,0]  R198      5.3831964731216431e-01
    z[1,0,0]  R199      1.6848705708980560e-01
    z[1,0,0]  R200      1.2245961278676987e-01
    z[1,0,0]  R201      4.3266189098358154e-01
    z[1,0,0]  R202      -1.7281191051006317e-01
    z[1,0,0]  R203      3.7440863251686096e-01
    z[1,0,0]  R204      -8.8296726346015930e-02
    z[1,0,0]  R205      -8.5912920534610748e-02
    z[1,0,0]  R206      -8.5435574874281883e-03
    z[1,0,0]  R207      5.6546766310930252e-02
    z[1,0,0]  R208      4.1534101963043213e-01
    z[1,0,0]  R209      -9.5797730609774590e-03
    z[1,0,0]  R210      1.6904467344284058e-01
    z[1,0,0]  R211      9.3381822109222412e-02
    z[1,0,0]  R212      3.4843999147415161e-01
    z[1,0,0]  R213      1.5935826301574707e-01
    z[1,0,0]  R214      2.6861077547073364e-01
    z[1,0,0]  R215      1.4243774116039276e-01
    z[1,0,0]  R216      3.2409456372261047e-01
    z[1,0,0]  R217      4.6643380075693130e-02
    z[1,0,0]  R218      2.9713290929794312e-01
    z[1,0,0]  R219      1.7995053529739380e-01
    z[1,0,0]  R220      4.1195189952850342e-01
    z[1,0,0]  R221      -7.0935539901256561e-02
    z[1,0,0]  R222      -2.9110053181648254e-01
    z[1,0,0]  R223      -7.7135547995567322e-02
    z[1,0,0]  R224      -1.0992193967103958e-01
    z[1,0,0]  R225      -2.4763907492160797e-01
    z[1,0,0]  R226      -4.5247364044189453e-01
    z[1,0,0]  R227      3.4517128020524979e-02
    z[1,0,0]  R228      -3.4133675694465637e-01
    z[1,0,0]  R229      -3.1733080744743347e-01
    z[1,0,0]  R230      -1.9801306724548340e-01
    z[1,0,0]  R231      -4.4325807690620422e-01
    z[1,0,0]  R232      3.7688564509153366e-02
    z[1,0,0]  R233      1.8515534698963165e-01
    z[1,0,0]  R234      -3.2667997479438782e-01
    z[1,0,0]  R235      4.4320335984230042e-01
    z[1,0,0]  R236      3.5500061511993408e-01
    z[1,0,0]  R237      -2.6508134603500366e-01
    z[1,0,0]  R238      3.9741504192352295e-01
    z[1,0,0]  R239      3.8087822496891022e-02
    z[1,0,0]  R240      4.8788771033287048e-02
    z[1,0,0]  R241      -6.4040142297744751e-01
    z[1,0,0]  R242      6.1919075250625610e-01
    z[1,0,0]  R243      -2.0823439955711365e-01
    z[1,0,0]  R244      -3.6439269781112671e-01
    z[1,0,0]  R245      -2.5745810940861702e-02
    z[1,0,0]  R246      0.552279531955719
    z[1,0,0]  R247      -1.2913800776004791e-01
    z[1,0,0]  R248      -2.2922135889530182e-01
    z[1,0,0]  R249      7.8371495008468628e-02
    z[1,0,0]  R250      -4.2302292585372925e-01
    z[1,0,0]  R251      -4.5666176825761795e-02
    z[1,0,0]  R252      3.9789915084838867e-01
    z[1,0,0]  R253      -1.8887579441070557e-02
    z[1,0,0]  R254      1.0406654328107834e-02
    z[1,0,0]  R255      2.2542765736579895e-01
    z[1,0,0]  R256      1.2186097353696823e-01
    z[1,0,0]  R257      1.8019260466098785e-01
    z[1,0,0]  R258      8.4562357515096664e-03
    z[1,0,0]  R259      4.1901251673698425e-01
    z[1,0,0]  R260      -4.1141349077224731e-01
    z[1,0,0]  R261      1.2014894187450409e-01
    z[1,0,1]  R3        1
    z[1,0,1]  R12       -1
    z[1,0,1]  R170      -1
    z[1,0,1]  R171      1
    z[1,0,1]  R182      0.0571502223610878
    z[1,0,1]  R183      -1.4520107768476009e-02
    z[1,0,1]  R184      5.2287089824676514e-01
    z[1,0,1]  R185      1.9970615208148956e-01
    z[1,0,1]  R186      -1.5222278423607349e-02
    z[1,0,1]  R187      -3.3910888433456421e-01
    z[1,0,1]  R188      1.7417545616626740e-01
    z[1,0,1]  R189      4.5699110627174377e-01
    z[1,0,1]  R190      2.8019109368324280e-01
    z[1,0,1]  R191      6.7615598440170288e-01
    z[1,0,1]  R192      -4.2932316660881042e-01
    z[1,0,1]  R193      -5.7425397634506226e-01
    z[1,0,1]  R194      -6.2131518125534058e-01
    z[1,0,1]  R195      -7.5799202919006348e-01
    z[1,0,1]  R196      -5.5511152744293213e-01
    z[1,0,1]  R197      -5.6249588727951050e-01
    z[1,0,1]  R198      -6.5417569875717163e-01
    z[1,0,1]  R199      -5.1269501447677612e-01
    z[1,0,1]  R200      -4.8968937993049622e-01
    z[1,0,1]  R201      -4.9344503879547119e-01
    z[1,0,1]  R202      -8.4892296791076660e-01
    z[1,0,1]  R203      -7.8575527667999268e-01
    z[1,0,1]  R204      -7.1145397424697876e-01
    z[1,0,1]  R205      -7.1247613430023193e-01
    z[1,0,1]  R206      -6.9293183088302612e-01
    z[1,0,1]  R207      -6.3465994596481323e-01
    z[1,0,1]  R208      -0.61861252784729
    z[1,0,1]  R209      -5.3537541627883911e-01
    z[1,0,1]  R210      0.595018208026886
    z[1,0,1]  R211      4.8361852765083313e-01
    z[1,0,1]  R212      -7.9290562868118286e-01
    z[1,0,1]  R213      -6.0925519466400146e-01
    z[1,0,1]  R214      -0.825687050819397
    z[1,0,1]  R215      -0.647787868976593
    z[1,0,1]  R216      6.7067429423332214e-02
    z[1,0,1]  R217      -3.6139285564422607e-01
    z[1,0,1]  R218      -3.7306267768144608e-02
    z[1,0,1]  R219      4.8320105671882629e-01
    z[1,0,1]  R220      3.7311285734176636e-01
    z[1,0,1]  R221      5.6233358383178711e-01
    z[1,0,1]  R222      -7.3140613734722137e-02
    z[1,0,1]  R223      -6.4375951886177063e-02
    z[1,0,1]  R224      -3.2401908189058304e-02
    z[1,0,1]  R225      -6.9302178919315338e-02
    z[1,0,1]  R226      -1.6971176862716675e-01
    z[1,0,1]  R227      -1.5012322366237640e-01
    z[1,0,1]  R228      7.0354324579238892e-01
    z[1,0,1]  R229      7.1915447711944580e-01
    z[1,0,1]  R230      8.3061850070953369e-01
    z[1,0,1]  R231      1.5530514717102051e-01
    z[1,0,1]  R232      -3.0270934104919434e-01
    z[1,0,1]  R233      -5.4343408346176147e-01
    z[1,0,1]  R234      -6.0718166828155518e-01
    z[1,0,1]  R235      -5.8420103788375854e-01
    z[1,0,1]  R236      -5.5674254894256592e-01
    z[1,0,1]  R237      -7.3574233055114746e-01
    z[1,0,1]  R238      -1.1066448874771595e-02
    z[1,0,1]  R239      -7.6014584302902222e-01
    z[1,0,1]  R240      -7.7486616373062134e-01
    z[1,0,1]  R241      0.0572950579226017
    z[1,0,1]  R242      4.7785595059394836e-01
    z[1,0,1]  R243      -1.8672700226306915e-01
    z[1,0,1]  R244      2.8185930848121643e-01
    z[1,0,1]  R245      -1.8345098197460175e-01
    z[1,0,1]  R246      4.2447263002395630e-01
    z[1,0,1]  R247      -2.7415317296981812e-01
    z[1,0,1]  R248      1.4668746292591095e-01
    z[1,0,1]  R249      2.9270383715629578e-01
    z[1,0,1]  R250      -3.7561511993408203e-01
    z[1,0,1]  R251      4.5177853107452393e-01
    z[1,0,1]  R252      4.3619260191917419e-01
    z[1,0,1]  R253      0.275611013174057
    z[1,0,1]  R254      0.527420163154602
    z[1,0,1]  R255      -1.5529237687587738e-01
    z[1,0,1]  R256      4.1819038987159729e-01
    z[1,0,1]  R257      -1.5105533599853516e-01
    z[1,0,1]  R258      1.2223100289702415e-02
    z[1,0,1]  R259      2.4060933291912079e-01
    z[1,0,1]  R260      -6.6439077258110046e-02
    z[1,0,1]  R261      -7.0705041289329529e-02
    z[1,0,2]  R4        1
    z[1,0,2]  R13       -1
    z[1,0,2]  R172      -1
    z[1,0,2]  R173      1
    z[1,0,2]  R182      3.3827850222587585e-01
    z[1,0,2]  R183      2.6897537708282471e-01
    z[1,0,2]  R184      4.7927427291870117e-01
    z[1,0,2]  R185      5.6895589828491211e-01
    z[1,0,2]  R186      3.1550264358520508e-01
    z[1,0,2]  R187      2.3017936944961548e-01
    z[1,0,2]  R188      -8.0488801002502441e-01
    z[1,0,2]  R189      -6.7732048034667969e-01
    z[1,0,2]  R190      -5.6877499818801880e-01
    z[1,0,2]  R191      -4.7535607218742371e-01
    z[1,0,2]  R192      4.1857668757438660e-01
    z[1,0,2]  R193      7.0329317823052406e-03
    z[1,0,2]  R194      2.1478319168090820e-01
    z[1,0,2]  R195      -3.4359315037727356e-01
    z[1,0,2]  R196      -2.9130160808563232e-01
    z[1,0,2]  R197      -0.227743998169899
    z[1,0,2]  R198      -1.8006688356399536e-01
    z[1,0,2]  R199      2.9676848649978638e-01
    z[1,0,2]  R200      -5.0348842144012451e-01
    z[1,0,2]  R201      -4.6433243155479431e-01
    z[1,0,2]  R202      -4.0656253695487976e-01
    z[1,0,2]  R203      1.4423318207263947e-01
    z[1,0,2]  R204      1.1157031171023846e-02
    z[1,0,2]  R205      4.5995819568634033e-01
    z[1,0,2]  R206      7.3543138802051544e-02
    z[1,0,2]  R207      -1.3757381588220596e-02
    z[1,0,2]  R208      1.4972053468227386e-01
    z[1,0,2]  R209      -4.3314412236213684e-01
    z[1,0,2]  R210      -3.6220791935920715e-01
    z[1,0,2]  R211      -5.7210975885391235e-01
    z[1,0,2]  R212      8.0398945137858391e-03
    z[1,0,2]  R213      3.2255479693412781e-01
    z[1,0,2]  R214      3.1184738874435425e-01
    z[1,0,2]  R215      2.2299650311470032e-01
    z[1,0,2]  R216      1.6216664016246796e-01
    z[1,0,2]  R217      -4.9299055337905884e-01
    z[1,0,2]  R218      8.9813880622386932e-02
    z[1,0,2]  R219      -6.4932525157928467e-01
    z[1,0,2]  R220      -0.747498095035553
    z[1,0,2]  R221      -6.4216977357864380e-01
    z[1,0,2]  R222      6.2608234584331512e-02
    z[1,0,2]  R223      1.2828177213668823e-01
    z[1,0,2]  R224      1.1891358345746994e-01
    z[1,0,2]  R225      -1.2434328347444534e-01
    z[1,0,2]  R226      5.8074957132339478e-01
    z[1,0,2]  R227      3.8947516679763794e-01
    z[1,0,2]  R228      -4.9320429563522339e-01
    z[1,0,2]  R229      -4.7367650270462036e-01
    z[1,0,2]  R230      -0.334102064371109
    z[1,0,2]  R231      4.6975514292716980e-01
    z[1,0,2]  R232      8.1207972764968872e-01
    z[1,0,2]  R233      6.0442489385604858e-01
    z[1,0,2]  R234      6.0188883543014526e-01
    z[1,0,2]  R235      6.0502427816390991e-01
    z[1,0,2]  R236      5.0293004512786865e-01
    z[1,0,2]  R237      3.8175088167190552e-01
    z[1,0,2]  R238      6.6689413785934448e-01
    z[1,0,2]  R239      -9.7829692065715790e-02
    z[1,0,2]  R240      -1.3991887867450714e-01
    z[1,0,2]  R241      4.3921470642089844e-01
    z[1,0,2]  R242      -1.2083734571933746e-01
    z[1,0,2]  R243      -0.544776201248169
    z[1,0,2]  R244      -5.3840112686157227e-01
    z[1,0,2]  R245      -1.5728504955768585e-01
    z[1,0,2]  R246      -0.00527540547773242
    z[1,0,2]  R247      -3.1793826818466187e-01
    z[1,0,2]  R248      -1.8751792609691620e-01
    z[1,0,2]  R249      -5.8714441955089569e-02
    z[1,0,2]  R250      -4.3605649471282959e-01
    z[1,0,2]  R251      -6.2979239225387573e-01
    z[1,0,2]  R252      -5.3202873468399048e-01
    z[1,0,2]  R253      -3.3552855253219604e-01
    z[1,0,2]  R254      -3.3924323320388794e-01
    z[1,0,2]  R255      -4.3600523471832275e-01
    z[1,0,2]  R256      -2.6900994777679443e-01
    z[1,0,2]  R257      -1.7215685546398163e-01
    z[1,0,2]  R258      -3.1496292352676392e-01
    z[1,0,2]  R259      -4.3559196591377258e-01
    z[1,0,2]  R260      -3.7466189265251160e-01
    z[1,0,2]  R261      -5.8040237426757812e-01
    z[1,0,3]  R5        1
    z[1,0,3]  R14       -1
    z[1,0,3]  R174      -1
    z[1,0,3]  R175      1
    z[1,0,3]  R182      -6.3158601522445679e-01
    z[1,0,3]  R183      -5.0303298234939575e-01
    z[1,0,3]  R184      -7.2316408157348633e-02
    z[1,0,3]  R185      -5.6475561112165451e-02
    z[1,0,3]  R186      -1.6880510747432709e-01
    z[1,0,3]  R187      -7.7094823122024536e-02
    z[1,0,3]  R188      2.0961783826351166e-01
    z[1,0,3]  R189      -5.4559266567230225e-01
    z[1,0,3]  R190      -8.2782298326492310e-02
    z[1,0,3]  R191      -1.4568190276622772e-01
    z[1,0,3]  R192      -2.1791622042655945e-01
    z[1,0,3]  R193      -4.3024352192878723e-01
    z[1,0,3]  R194      6.3930678367614746e-01
    z[1,0,3]  R195      4.6592387557029724e-01
    z[1,0,3]  R196      -2.5682101026177406e-02
    z[1,0,3]  R197      -3.0834561586380005e-01
    z[1,0,3]  R198      -2.6775610446929932e-01
    z[1,0,3]  R199      4.7634443640708923e-01
    z[1,0,3]  R200      3.9109072089195251e-01
    z[1,0,3]  R201      -1.5720802545547485e-01
    z[1,0,3]  R202      -3.4958653151988983e-02
    z[1,0,3]  R203      -2.1188369393348694e-01
    z[1,0,3]  R204      -1.2492434680461884e-01
    z[1,0,3]  R205      5.2482996135950089e-02
    z[1,0,3]  R206      5.5309587717056274e-01
    z[1,0,3]  R207      -2.6708588004112244e-01
    z[1,0,3]  R208      1.7133103311061859e-01
    z[1,0,3]  R209      2.1449856460094452e-02
    z[1,0,3]  R210      -4.7806450724601746e-01
    z[1,0,3]  R211      -4.8097869753837585e-01
    z[1,0,3]  R212      -1.2466013431549072e-01
    z[1,0,3]  R213      -2.6293888688087463e-01
    z[1,0,3]  R214      3.3467465639114380e-01
    z[1,0,3]  R215      1.5844729542732239e-01
    z[1,0,3]  R216      -6.4167755842208862e-01
    z[1,0,3]  R217      -6.8747711181640625e-01
    z[1,0,3]  R218      -3.5609990358352661e-01
    z[1,0,3]  R219      2.1293807029724121e-01
    z[1,0,3]  R220      2.8251573443412781e-01
    z[1,0,3]  R221      3.0904152989387512e-01
    z[1,0,3]  R222      -8.0044138431549072e-01
    z[1,0,3]  R223      -7.3260128498077393e-01
    z[1,0,3]  R224      -9.2536401748657227e-01
    z[1,0,3]  R225      -5.7159650325775146e-01
    z[1,0,3]  R226      -1.0784323513507843e-01
    z[1,0,3]  R227      -1.2085956335067749e-01
    z[1,0,3]  R228      -1.8910260498523712e-01
    z[1,0,3]  R229      -1.9142301380634308e-01
    z[1,0,3]  R230      -2.0735612511634827e-01
    z[1,0,3]  R231      3.5851910710334778e-02
    z[1,0,3]  R232      9.4207823276519775e-02
    z[1,0,3]  R233      -3.9301950484514236e-02
    z[1,0,3]  R234      0.0373460054397583
    z[1,0,3]  R235      -2.0858001708984375e-01
    z[1,0,3]  R236      -1.6748347878456116e-01
    z[1,0,3]  R237      1.0246150940656662e-01
    z[1,0,3]  R238      -1.7951881885528564e-01
    z[1,0,3]  R239      -3.3786278963088989e-01
    z[1,0,3]  R240      -2.1383160352706909e-01
    z[1,0,3]  R241      -7.5724922120571136e-02
    z[1,0,3]  R242      -5.0463861227035522e-01
    z[1,0,3]  R243      4.8110455274581909e-01
    z[1,0,3]  R244      4.5489895343780518e-01
    z[1,0,3]  R245      4.5532214641571045e-01
    z[1,0,3]  R246      -3.1989842653274536e-01
    z[1,0,3]  R247      7.7010315656661987e-01
    z[1,0,3]  R248      8.1475955247879028e-01
    z[1,0,3]  R249      6.9427573680877686e-01
    z[1,0,3]  R250      3.7086969614028931e-01
    z[1,0,3]  R251      5.2603012323379517e-01
    z[1,0,3]  R252      0.552764356136322
    z[1,0,3]  R253      4.5846515893936157e-01
    z[1,0,3]  R254      0.440618634223938
    z[1,0,3]  R255      4.2818653583526611e-01
    z[1,0,3]  R256      4.3854394555091858e-01
    z[1,0,3]  R257      8.4263467788696289e-01
    z[1,0,3]  R258      8.0142879486083984e-01
    z[1,0,3]  R259      4.2945098876953125e-01
    z[1,0,3]  R260      7.6675540208816528e-01
    z[1,0,3]  R261      7.1963596343994141e-01
    z[1,0,4]  R6        1
    z[1,0,4]  R15       -1
    z[1,0,4]  R176      -1
    z[1,0,4]  R177      1
    z[1,0,4]  R182      5.4618109017610550e-02
    z[1,0,4]  R183      4.3251585960388184e-01
    z[1,0,4]  R184      2.2884850203990936e-01
    z[1,0,4]  R185      1.3395678251981735e-02
    z[1,0,4]  R186      -3.2032021880149841e-01
    z[1,0,4]  R187      -1.6126623749732971e-01
    z[1,0,4]  R188      -1.6589350998401642e-01
    z[1,0,4]  R189      1.5212227404117584e-01
    z[1,0,4]  R190      1.6600900888442993e-01
    z[1,0,4]  R191      -4.0259528160095215e-01
    z[1,0,4]  R192      2.1024408936500549e-01
    z[1,0,4]  R193      3.2547575235366821e-01
    z[1,0,4]  R194      1.2544916570186615e-01
    z[1,0,4]  R195      1.4493545889854431e-01
    z[1,0,4]  R196      -0.635603129863739
    z[1,0,4]  R197      -3.5129398107528687e-01
    z[1,0,4]  R198      3.6472561955451965e-01
    z[1,0,4]  R199      -1.0093870013952255e-01
    z[1,0,4]  R200      -2.8051188588142395e-01
    z[1,0,4]  R201      4.1372036933898926e-01
    z[1,0,4]  R202      -1.8713331222534180e-01
    z[1,0,4]  R203      -9.2841759324073792e-02
    z[1,0,4]  R204      -0.458484411239624
    z[1,0,4]  R205      -2.1331407129764557e-01
    z[1,0,4]  R206      -2.4745023250579834e-01
    z[1,0,4]  R207      -3.6730185151100159e-02
    z[1,0,4]  R208      5.9393906593322754e-01
    z[1,0,4]  R209      1.0587974451482296e-02
    z[1,0,4]  R210      -2.6298624277114868e-01
    z[1,0,4]  R211      -1.3785381615161896e-01
    z[1,0,4]  R212      4.1813701391220093e-01
    z[1,0,4]  R213      -1.7909309267997742e-01
    z[1,0,4]  R214      1.4182345569133759e-01
    z[1,0,4]  R215      -4.0630164742469788e-01
    z[1,0,4]  R216      -4.0135571360588074e-01
    z[1,0,4]  R217      1.4454364776611328e-01
    z[1,0,4]  R218      -4.4148343801498413e-01
    z[1,0,4]  R219      -3.9723706245422363e-01
    z[1,0,4]  R220      1.9270395860075951e-02
    z[1,0,4]  R221      -1.1284729093313217e-01
    z[1,0,4]  R222      -2.1164520084857941e-01
    z[1,0,4]  R223      -3.9901182055473328e-01
    z[1,0,4]  R224      2.5594955682754517e-01
    z[1,0,4]  R225      3.0116474628448486e-01
    z[1,0,4]  R226      -1.1749612540006638e-01
    z[1,0,4]  R227      -2.0477820653468370e-03
    z[1,0,4]  R228      3.2114297151565552e-01
    z[1,0,4]  R229      -1.7730036750435829e-02
    z[1,0,4]  R230      -1.3784086704254150e-01
    z[1,0,4]  R231      -7.2555428743362427e-01
    z[1,0,4]  R232      -3.5865274071693420e-01
    z[1,0,4]  R233      -2.5757363438606262e-01
    z[1,0,4]  R234      -3.9924946427345276e-01
    z[1,0,4]  R235      1.2988951057195663e-02
    z[1,0,4]  R236      2.8092095255851746e-01
    z[1,0,4]  R237      1.6135616600513458e-01
    z[1,0,4]  R238      1.2858679890632629e-01
    z[1,0,4]  R239      1.3438127934932709e-01
    z[1,0,4]  R240      -1.8022048473358154e-01
    z[1,0,4]  R241      2.6228258013725281e-01
    z[1,0,4]  R242      2.6210841536521912e-01
    z[1,0,4]  R243      5.4431253671646118e-01
    z[1,0,4]  R244      3.6802875995635986e-01
    z[1,0,4]  R245      5.4675036668777466e-01
    z[1,0,4]  R246      -4.5000213384628296e-01
    z[1,0,4]  R247      -3.7259936332702637e-01
    z[1,0,4]  R248      -2.2440558671951294e-01
    z[1,0,4]  R249      -6.1998224258422852e-01
    z[1,0,4]  R250      4.9447005987167358e-01
    z[1,0,4]  R251      -1.9379186630249023e-01
    z[1,0,4]  R252      2.1994405984878540e-01
    z[1,0,4]  R253      7.5776636600494385e-01
    z[1,0,4]  R254      6.0271179676055908e-01
    z[1,0,4]  R255      6.7618530988693237e-01
    z[1,0,4]  R256      5.8848571777343750e-01
    z[1,0,4]  R257      -0.422538697719574
    z[1,0,4]  R258      -5.2651070058345795e-02
    z[1,0,4]  R259      3.9391061663627625e-01
    z[1,0,4]  R260      -2.7618253231048584e-01
    z[1,0,4]  R261      -1.8348044157028198e-01
    z[1,0,5]  R7        1
    z[1,0,5]  R16       -1
    z[1,0,5]  R178      -1
    z[1,0,5]  R179      1
    z[1,0,5]  R182      1.0035312175750732e-01
    z[1,0,5]  R183      1.2102705240249634e-01
    z[1,0,5]  R184      -4.0607705712318420e-01
    z[1,0,5]  R185      -2.6194760575890541e-03
    z[1,0,5]  R186      -4.0177392959594727e-01
    z[1,0,5]  R187      1.4393597841262817e-01
    z[1,0,5]  R188      -2.7187490463256836e-01
    z[1,0,5]  R189      1.6387138515710831e-02
    z[1,0,5]  R190      -3.2049903273582458e-01
    z[1,0,5]  R191      2.6123279333114624e-01
    z[1,0,5]  R192      -6.3597774505615234e-01
    z[1,0,5]  R193      -4.5043057203292847e-01
    z[1,0,5]  R194      3.3822205662727356e-01
    z[1,0,5]  R195      0.0916120857000351
    z[1,0,5]  R196      1.9699060916900635e-01
    z[1,0,5]  R197      -5.8789849281311035e-01
    z[1,0,5]  R198      9.2904157936573029e-02
    z[1,0,5]  R199      -4.9578076601028442e-01
    z[1,0,5]  R200      4.9798467755317688e-01
    z[1,0,5]  R201      -8.7487436830997467e-02
    z[1,0,5]  R202      1.6432522237300873e-01
    z[1,0,5]  R203      -6.0462478548288345e-02
    z[1,0,5]  R204      1.4008009433746338e-01
    z[1,0,5]  R205      3.2220765948295593e-01
    z[1,0,5]  R206      -0.383074551820755
    z[1,0,5]  R207      7.2040760517120361e-01
    z[1,0,5]  R208      1.2024323642253876e-01
    z[1,0,5]  R209      2.5460805743932724e-02
    z[1,0,5]  R210      -3.5921093821525574e-01
    z[1,0,5]  R211      -4.1875803470611572e-01
    z[1,0,5]  R212      2.2691969573497772e-01
    z[1,0,5]  R213      -4.0171968936920166e-01
    z[1,0,5]  R214      6.0343381017446518e-02
    z[1,0,5]  R215      5.5310624837875366e-01
    z[1,0,5]  R216      -0.295651376247406
    z[1,0,5]  R217      -3.4224978089332581e-01
    z[1,0,5]  R218      -7.4231362342834473e-01
    z[1,0,5]  R219      3.2469585537910461e-01
    z[1,0,5]  R220      4.3311398476362228e-02
    z[1,0,5]  R221      1.8013213574886322e-01
    z[1,0,5]  R222      -4.6946471929550171e-01
    z[1,0,5]  R223      -3.6508047580718994e-01
    z[1,0,5]  R224      1.1537971906363964e-02
    z[1,0,5]  R225      -4.3312925100326538e-01
    z[1,0,5]  R226      -1.4218859374523163e-01
    z[1,0,5]  R227      -4.0969517827033997e-01
    z[1,0,5]  R228      4.2105689644813538e-02
    z[1,0,5]  R229      0.0718042328953743
    z[1,0,5]  R230      -3.0032646656036377e-01
    z[1,0,5]  R231      -4.3200269341468811e-02
    z[1,0,5]  R232      3.2576853036880493e-01
    z[1,0,5]  R233      3.7302923202514648e-01
    z[1,0,5]  R234      1.2362153269350529e-02
    z[1,0,5]  R235      7.5328819453716278e-02
    z[1,0,5]  R236      4.5080298185348511e-01
    z[1,0,5]  R237      4.5079210400581360e-01
    z[1,0,5]  R238      5.8838760852813721e-01
    z[1,0,5]  R239      -5.0827842950820923e-01
    z[1,0,5]  R240      -4.9634787440299988e-01
    z[1,0,5]  R241      4.2970347404479980e-01
    z[1,0,5]  R242      -1.7995594441890717e-01
    z[1,0,5]  R243      3.0343741178512573e-01
    z[1,0,5]  R244      -2.6977434754371643e-01
    z[1,0,5]  R245      -2.3725025355815887e-02
    z[1,0,5]  R246      -3.3120924234390259e-01
    z[1,0,5]  R247      -2.7226004004478455e-01
    z[1,0,5]  R248      -1.7371596395969391e-01
    z[1,0,5]  R249      -0.195637509226799
    z[1,0,5]  R250      -1.8987011909484863e-01
    z[1,0,5]  R251      -1.5229150652885437e-01
    z[1,0,5]  R252      4.2402278631925583e-02
    z[1,0,5]  R253      5.8454502373933792e-02
    z[1,0,5]  R254      2.0937785506248474e-01
    z[1,0,5]  R255      -2.1447671949863434e-01
    z[1,0,5]  R256      0.0199163518846035
    z[1,0,5]  R257      -2.7964893728494644e-02
    z[1,0,5]  R258      -2.4191781878471375e-01
    z[1,0,5]  R259      -3.7180560827255249e-01
    z[1,0,5]  R260      -1.4547628164291382e-01
    z[1,0,5]  R261      -1.2203764170408249e-01
    z[1,0,6]  R8        1
    z[1,0,6]  R17       -1
    z[1,0,6]  R180      -1
    z[1,0,6]  R181      1
    z[1,0,6]  R182      -2.4538420140743256e-02
    z[1,0,6]  R183      0.297335684299469
    z[1,0,6]  R184      3.4954464435577393e-01
    z[1,0,6]  R185      2.2817702591419220e-01
    z[1,0,6]  R186      1.5097934752702713e-02
    z[1,0,6]  R187      -6.1416542530059814e-01
    z[1,0,6]  R188      3.6751002073287964e-01
    z[1,0,6]  R189      -6.2844090163707733e-02
    z[1,0,6]  R190      -6.7511671781539917e-01
    z[1,0,6]  R191      2.4829532206058502e-01
    z[1,0,6]  R192      -2.0460508763790131e-01
    z[1,0,6]  R193      -1.0036907345056534e-01
    z[1,0,6]  R194      1.7019617557525635e-01
    z[1,0,6]  R195      2.3270641267299652e-01
    z[1,0,6]  R196      3.9491218328475952e-01
    z[1,0,6]  R197      2.4653873406350613e-03
    z[1,0,6]  R198      -1.9103090465068817e-01
    z[1,0,6]  R199      3.7120506167411804e-01
    z[1,0,6]  R200      -1.0990805923938751e-01
    z[1,0,6]  R201      3.8752806186676025e-01
    z[1,0,6]  R202      -1.4466822147369385e-01
    z[1,0,6]  R203      4.0550419688224792e-01
    z[1,0,6]  R204      -4.9038353562355042e-01
    z[1,0,6]  R205      3.4836760163307190e-01
    z[1,0,6]  R206      -2.1705206483602524e-02
    z[1,0,6]  R207      -4.6356637030839920e-02
    z[1,0,6]  R208      1.6067904233932495e-01
    z[1,0,6]  R209      7.2418713569641113e-01
    z[1,0,6]  R210      -2.4380896985530853e-01
    z[1,0,6]  R211      -6.6189341247081757e-02
    z[1,0,6]  R212      -8.9187301695346832e-02
    z[1,0,6]  R213      -4.8660197854042053e-01
    z[1,0,6]  R214      -1.1435898393392563e-01
    z[1,0,6]  R215      1.1933930218219757e-01
    z[1,0,6]  R216      4.5157539844512939e-01
    z[1,0,6]  R217      -1.1630688607692719e-01
    z[1,0,6]  R218      -1.7178329825401306e-01
    z[1,0,6]  R219      -6.2800779938697815e-02
    z[1,0,6]  R220      2.2420226037502289e-01
    z[1,0,6]  R221      3.5451132059097290e-01
    z[1,0,6]  R222      -9.6968440338969231e-03
    z[1,0,6]  R223      -3.7980365753173828e-01
    z[1,0,6]  R224      2.2535514831542969e-01
    z[1,0,6]  R225      -5.5980980396270752e-01
    z[1,0,6]  R226      -6.1930793523788452e-01
    z[1,0,6]  R227      -8.0132347345352173e-01
    z[1,0,6]  R228      6.7823834717273712e-02
    z[1,0,6]  R229      -3.4005227684974670e-01
    z[1,0,6]  R230      -8.3945453166961670e-02
    z[1,0,6]  R231      1.7073978483676910e-01
    z[1,0,6]  R232      -6.1976794153451920e-02
    z[1,0,6]  R233      3.1309393048286438e-01
    z[1,0,6]  R234      -3.7321012467145920e-02
    z[1,0,6]  R235      -2.1651054918766022e-01
    z[1,0,6]  R236      -2.9716560617089272e-02
    z[1,0,6]  R237      5.4164156317710876e-02
    z[1,0,6]  R238      -4.7218024730682373e-02
    z[1,0,6]  R239      -1.4352865517139435e-01
    z[1,0,6]  R240      2.3034781217575073e-01
    z[1,0,6]  R241      -3.6677280068397522e-01
    z[1,0,6]  R242      -1.3382703065872192e-01
    z[1,0,6]  R243      7.1961626410484314e-02
    z[1,0,6]  R244      -2.8764751553535461e-01
    z[1,0,6]  R245      -6.5888333320617676e-01
    z[1,0,6]  R246      3.1661653518676758e-01
    z[1,0,6]  R247      3.2620962709188461e-02
    z[1,0,6]  R248      -0.382634699344635
    z[1,0,6]  R249      8.0147329717874527e-03
    z[1,0,6]  R250      -2.6781329512596130e-01
    z[1,0,6]  R251      2.4436981976032257e-01
    z[1,0,6]  R252      -1.1241012066602707e-01
    z[1,0,6]  R253      1.5259535610675812e-01
    z[1,0,6]  R254      7.3405079543590546e-02
    z[1,0,6]  R255      -2.1999014914035797e-01
    z[1,0,6]  R256      -4.4594547152519226e-01
    z[1,0,6]  R257      1.6037710011005402e-01
    z[1,0,6]  R258      -4.4383895397186279e-01
    z[1,0,6]  R259      -0.314582496881485
    z[1,0,6]  R260      2.4479079991579056e-02
    z[1,0,6]  R261      2.7796393632888794e-01
    z[0,5,0]  R2        -1
    z[0,5,0]  R47       1
    z[0,5,0]  R262      -1
    z[0,5,0]  R263      1
    z[0,5,0]  R276      -2.9110053181648254e-01
    z[0,5,0]  R277      -7.7135547995567322e-02
    z[0,5,0]  R278      -1.0992193967103958e-01
    z[0,5,0]  R279      -2.4763907492160797e-01
    z[0,5,0]  R280      -4.5247364044189453e-01
    z[0,5,0]  R281      3.4517128020524979e-02
    z[0,5,0]  R282      -3.4133675694465637e-01
    z[0,5,0]  R283      -3.1733080744743347e-01
    z[0,5,0]  R284      -1.9801306724548340e-01
    z[0,5,0]  R285      -4.4325807690620422e-01
    z[0,5,0]  R286      3.7688564509153366e-02
    z[0,5,0]  R287      1.8515534698963165e-01
    z[0,5,0]  R288      -3.2667997479438782e-01
    z[0,5,0]  R289      4.4320335984230042e-01
    z[0,5,0]  R290      3.5500061511993408e-01
    z[0,5,0]  R291      -2.6508134603500366e-01
    z[0,5,0]  R292      3.9741504192352295e-01
    z[0,5,0]  R293      3.8087822496891022e-02
    z[0,5,0]  R294      4.8788771033287048e-02
    z[0,5,0]  R295      -6.4040142297744751e-01
    z[0,5,0]  R296      6.1919075250625610e-01
    z[0,5,0]  R297      -2.0823439955711365e-01
    z[0,5,0]  R298      -3.6439269781112671e-01
    z[0,5,0]  R299      -2.5745810940861702e-02
    z[0,5,0]  R300      0.552279531955719
    z[0,5,0]  R301      -1.2913800776004791e-01
    z[0,5,0]  R302      -2.2922135889530182e-01
    z[0,5,0]  R303      7.8371495008468628e-02
    z[0,5,0]  R304      -4.2302292585372925e-01
    z[0,5,0]  R305      -4.5666176825761795e-02
    z[0,5,0]  R306      3.9789915084838867e-01
    z[0,5,0]  R307      -1.8887579441070557e-02
    z[0,5,0]  R308      1.0406654328107834e-02
    z[0,5,0]  R309      2.2542765736579895e-01
    z[0,5,0]  R310      1.2186097353696823e-01
    z[0,5,0]  R311      1.8019260466098785e-01
    z[0,5,0]  R312      8.4562357515096664e-03
    z[0,5,0]  R313      4.1901251673698425e-01
    z[0,5,0]  R314      -4.1141349077224731e-01
    z[0,5,0]  R315      1.2014894187450409e-01
    z[0,5,0]  R316      2.9091495275497437e-01
    z[0,5,0]  R317      -3.6083468794822693e-01
    z[0,5,0]  R318      -4.6569105982780457e-01
    z[0,5,0]  R319      -2.0228002965450287e-01
    z[0,5,0]  R320      -3.6377462744712830e-01
    z[0,5,0]  R321      -3.3797499537467957e-01
    z[0,5,0]  R322      -5.4884368181228638e-01
    z[0,5,0]  R323      -3.7617659568786621e-01
    z[0,5,0]  R324      -3.1347030401229858e-01
    z[0,5,0]  R325      -6.2527453899383545e-01
    z[0,5,0]  R326      2.3207743465900421e-01
    z[0,5,0]  R327      -5.0279909372329712e-01
    z[0,5,0]  R328      -2.2818683087825775e-01
    z[0,5,0]  R329      -2.1225777268409729e-01
    z[0,5,0]  R330      -5.1677042245864868e-01
    z[0,5,0]  R331      -4.4484436511993408e-01
    z[0,5,0]  R332      2.0168316364288330e-01
    z[0,5,0]  R333      -1.7646947875618935e-02
    z[0,5,0]  R334      4.1896656155586243e-02
    z[0,5,0]  R335      8.8463641703128815e-02
    z[0,5,0]  R336      4.0395464748144150e-02
    z[0,5,0]  R337      -4.8250782489776611e-01
    z[0,5,0]  R338      4.6158574521541595e-02
    z[0,5,0]  R339      5.9904003143310547e-01
    z[0,5,0]  R340      5.6295675039291382e-01
    z[0,5,0]  R341      4.4647005200386047e-01
    z[0,5,0]  R342      -1.9672855734825134e-01
    z[0,5,0]  R343      -9.8254628479480743e-02
    z[0,5,0]  R344      3.3166274428367615e-01
    z[0,5,0]  R345      5.9548731893301010e-02
    z[0,5,0]  R346      -3.9123165607452393e-01
    z[0,5,0]  R347      -1.0539588332176208e-01
    z[0,5,0]  R348      2.6394993066787720e-01
    z[0,5,0]  R349      5.4921209812164307e-01
    z[0,5,0]  R350      -3.0321314930915833e-01
    z[0,5,0]  R351      3.6329996585845947e-01
    z[0,5,0]  R352      0.088935486972332
    z[0,5,0]  R353      5.6920063495635986e-01
    z[0,5,0]  R354      1.9802051782608032e-01
    z[0,5,0]  R355      1.6972261667251587e-01
    z[0,5,0]  R356      2.4450385570526123e-01
    z[0,5,0]  R357      9.1531641781330109e-02
    z[0,5,0]  R358      4.0710300207138062e-01
    z[0,5,0]  R359      -9.8229393362998962e-02
    z[0,5,0]  R360      4.2558785527944565e-02
    z[0,5,0]  R361      -4.2971599847078323e-02
    z[0,5,0]  R362      -2.2841045260429382e-01
    z[0,5,0]  R363      6.3354569673538208e-01
    z[0,5,0]  R364      8.4422230720520020e-01
    z[0,5,0]  R365      7.1804314851760864e-01
    z[0,5,1]  R3        -1
    z[0,5,1]  R48       1
    z[0,5,1]  R264      -1
    z[0,5,1]  R265      1
    z[0,5,1]  R276      -7.3140613734722137e-02
    z[0,5,1]  R277      -6.4375951886177063e-02
    z[0,5,1]  R278      -3.2401908189058304e-02
    z[0,5,1]  R279      -6.9302178919315338e-02
    z[0,5,1]  R280      -1.6971176862716675e-01
    z[0,5,1]  R281      -1.5012322366237640e-01
    z[0,5,1]  R282      7.0354324579238892e-01
    z[0,5,1]  R283      7.1915447711944580e-01
    z[0,5,1]  R284      8.3061850070953369e-01
    z[0,5,1]  R285      1.5530514717102051e-01
    z[0,5,1]  R286      -3.0270934104919434e-01
    z[0,5,1]  R287      -5.4343408346176147e-01
    z[0,5,1]  R288      -6.0718166828155518e-01
    z[0,5,1]  R289      -5.8420103788375854e-01
    z[0,5,1]  R290      -5.5674254894256592e-01
    z[0,5,1]  R291      -7.3574233055114746e-01
    z[0,5,1]  R292      -1.1066448874771595e-02
    z[0,5,1]  R293      -7.6014584302902222e-01
    z[0,5,1]  R294      -7.7486616373062134e-01
    z[0,5,1]  R295      0.0572950579226017
    z[0,5,1]  R296      4.7785595059394836e-01
    z[0,5,1]  R297      -1.8672700226306915e-01
    z[0,5,1]  R298      2.8185930848121643e-01
    z[0,5,1]  R299      -1.8345098197460175e-01
    z[0,5,1]  R300      4.2447263002395630e-01
    z[0,5,1]  R301      -2.7415317296981812e-01
    z[0,5,1]  R302      1.4668746292591095e-01
    z[0,5,1]  R303      2.9270383715629578e-01
    z[0,5,1]  R304      -3.7561511993408203e-01
    z[0,5,1]  R305      4.5177853107452393e-01
    z[0,5,1]  R306      4.3619260191917419e-01
    z[0,5,1]  R307      0.275611013174057
    z[0,5,1]  R308      0.527420163154602
    z[0,5,1]  R309      -1.5529237687587738e-01
    z[0,5,1]  R310      4.1819038987159729e-01
    z[0,5,1]  R311      -1.5105533599853516e-01
    z[0,5,1]  R312      1.2223100289702415e-02
    z[0,5,1]  R313      2.4060933291912079e-01
    z[0,5,1]  R314      -6.6439077258110046e-02
    z[0,5,1]  R315      -7.0705041289329529e-02
    z[0,5,1]  R316      -7.3565638065338135e-01
    z[0,5,1]  R317      -6.4328014850616455e-02
    z[0,5,1]  R318      -2.9201605916023254e-01
    z[0,5,1]  R319      5.2661824971437454e-02
    z[0,5,1]  R320      1.3025499880313873e-01
    z[0,5,1]  R321      1.5686845779418945e-01
    z[0,5,1]  R322      -2.4323178455233574e-02
    z[0,5,1]  R323      -2.2287362813949585e-01
    z[0,5,1]  R324      -2.6984763145446777e-01
    z[0,5,1]  R325      1.4140671119093895e-02
    z[0,5,1]  R326      -1.0301580280065536e-01
    z[0,5,1]  R327      -2.9531466960906982e-01
    z[0,5,1]  R328      -5.1376044750213623e-01
    z[0,5,1]  R329      -1.5158012509346008e-01
    z[0,5,1]  R330      -1.9731591641902924e-01
    z[0,5,1]  R331      -5.2393499761819839e-02
    z[0,5,1]  R332      -0.373665452003479
    z[0,5,1]  R333      3.0326899886131287e-01
    z[0,5,1]  R334      1.3561367988586426e-01
    z[0,5,1]  R335      6.2951862812042236e-02
    z[0,5,1]  R336      -2.7003467082977295e-01
    z[0,5,1]  R337      -6.7096549272537231e-01
    z[0,5,1]  R338      5.3244483470916748e-01
    z[0,5,1]  R339      2.7409994602203369e-01
    z[0,5,1]  R340      -0.0711694285273552
    z[0,5,1]  R341      -1.6892926394939423e-01
    z[0,5,1]  R342      -2.3674850165843964e-01
    z[0,5,1]  R343      -2.7946993708610535e-01
    z[0,5,1]  R344      4.6551775932312012e-01
    z[0,5,1]  R345      -2.3112232983112335e-01
    z[0,5,1]  R346      -6.2447714805603027e-01
    z[0,5,1]  R347      -6.7923784255981445e-01
    z[0,5,1]  R348      -7.1744000911712646e-01
    z[0,5,1]  R349      -5.3574812412261963e-01
    z[0,5,1]  R350      -7.0917648077011108e-01
    z[0,5,1]  R351      -4.5288136601448059e-01
    z[0,5,1]  R352      -5.1484644412994385e-01
    z[0,5,1]  R353      -7.8515373170375824e-02
    z[0,5,1]  R354      -0.761551022529602
    z[0,5,1]  R355      -3.1575447320938110e-01
    z[0,5,1]  R356      -5.6011569499969482e-01
    z[0,5,1]  R357      -4.9273529648780823e-01
    z[0,5,1]  R358      -4.4910877943038940e-01
    z[0,5,1]  R359      -1.6063762828707695e-02
    z[0,5,1]  R360      5.6766015291213989e-01
    z[0,5,1]  R361      4.3509021401405334e-01
    z[0,5,1]  R362      3.0859598517417908e-01
    z[0,5,1]  R363      7.0993030071258545e-01
    z[0,5,1]  R364      4.9765196442604065e-01
    z[0,5,1]  R365      6.6561222076416016e-01
    z[0,5,2]  R4        -1
    z[0,5,2]  R49       1
    z[0,5,2]  R266      -1
    z[0,5,2]  R267      1
    z[0,5,2]  R276      6.2608234584331512e-02
    z[0,5,2]  R277      1.2828177213668823e-01
    z[0,5,2]  R278      1.1891358345746994e-01
    z[0,5,2]  R279      -1.2434328347444534e-01
    z[0,5,2]  R280      5.8074957132339478e-01
    z[0,5,2]  R281      3.8947516679763794e-01
    z[0,5,2]  R282      -4.9320429563522339e-01
    z[0,5,2]  R283      -4.7367650270462036e-01
    z[0,5,2]  R284      -0.334102064371109
    z[0,5,2]  R285      4.6975514292716980e-01
    z[0,5,2]  R286      8.1207972764968872e-01
    z[0,5,2]  R287      6.0442489385604858e-01
    z[0,5,2]  R288      6.0188883543014526e-01
    z[0,5,2]  R289      6.0502427816390991e-01
    z[0,5,2]  R290      5.0293004512786865e-01
    z[0,5,2]  R291      3.8175088167190552e-01
    z[0,5,2]  R292      6.6689413785934448e-01
    z[0,5,2]  R293      -9.7829692065715790e-02
    z[0,5,2]  R294      -1.3991887867450714e-01
    z[0,5,2]  R295      4.3921470642089844e-01
    z[0,5,2]  R296      -1.2083734571933746e-01
    z[0,5,2]  R297      -0.544776201248169
    z[0,5,2]  R298      -5.3840112686157227e-01
    z[0,5,2]  R299      -1.5728504955768585e-01
    z[0,5,2]  R300      -0.00527540547773242
    z[0,5,2]  R301      -3.1793826818466187e-01
    z[0,5,2]  R302      -1.8751792609691620e-01
    z[0,5,2]  R303      -5.8714441955089569e-02
    z[0,5,2]  R304      -4.3605649471282959e-01
    z[0,5,2]  R305      -6.2979239225387573e-01
    z[0,5,2]  R306      -5.3202873468399048e-01
    z[0,5,2]  R307      -3.3552855253219604e-01
    z[0,5,2]  R308      -3.3924323320388794e-01
    z[0,5,2]  R309      -4.3600523471832275e-01
    z[0,5,2]  R310      -2.6900994777679443e-01
    z[0,5,2]  R311      -1.7215685546398163e-01
    z[0,5,2]  R312      -3.1496292352676392e-01
    z[0,5,2]  R313      -4.3559196591377258e-01
    z[0,5,2]  R314      -3.7466189265251160e-01
    z[0,5,2]  R315      -5.8040237426757812e-01
    z[0,5,2]  R316      1.3208520412445068e-01
    z[0,5,2]  R317      -3.8682025671005249e-01
    z[0,5,2]  R318      -3.9834859967231750e-01
    z[0,5,2]  R319      -3.8881012797355652e-01
    z[0,5,2]  R320      -5.8433258533477783e-01
    z[0,5,2]  R321      -3.4658560156822205e-01
    z[0,5,2]  R322      -3.4464821219444275e-01
    z[0,5,2]  R323      -1.6381615400314331e-01
    z[0,5,2]  R324      -3.1097128987312317e-01
    z[0,5,2]  R325      -1.8465775251388550e-01
    z[0,5,2]  R326      6.1017107963562012e-01
    z[0,5,2]  R327      3.4490790963172913e-01
    z[0,5,2]  R328      2.8559392690658569e-01
    z[0,5,2]  R329      7.7999740839004517e-01
    z[0,5,2]  R330      3.7083712220191956e-01
    z[0,5,2]  R331      7.3896294832229614e-01
    z[0,5,2]  R332      0.58495032787323
    z[0,5,2]  R333      4.0773600339889526e-01
    z[0,5,2]  R334      1.9199748337268829e-01
    z[0,5,2]  R335      6.0725563764572144e-01
    z[0,5,2]  R336      1.7580537497997284e-01
    z[0,5,2]  R337      2.8710660338401794e-01
    z[0,5,2]  R338      -5.9267640113830566e-01
    z[0,5,2]  R339      -4.9337202310562134e-01
    z[0,5,2]  R340      -6.0816633701324463e-01
    z[0,5,2]  R341      3.6779043078422546e-01
    z[0,5,2]  R342      -3.5593810677528381e-01
    z[0,5,2]  R343      -8.0446094274520874e-01
    z[0,5,2]  R344      -6.1851215362548828e-01
    z[0,5,2]  R345      -6.6251236200332642e-01
    z[0,5,2]  R346      1.0689135640859604e-01
    z[0,5,2]  R347      2.2233678400516510e-01
    z[0,5,2]  R348      -1.5225446224212646e-01
    z[0,5,2]  R349      2.5967153906822205e-01
    z[0,5,2]  R350      3.7751322984695435e-01
    z[0,5,2]  R351      1.2850096821784973e-01
    z[0,5,2]  R352      -4.1867870092391968e-01
    z[0,5,2]  R353      -3.2843223214149475e-01
    z[0,5,2]  R354      -2.2259384393692017e-01
    z[0,5,2]  R355      5.9010386466979980e-01
    z[0,5,2]  R356      6.1665505170822144e-01
    z[0,5,2]  R357      7.0563161373138428e-01
    z[0,5,2]  R358      3.8184961676597595e-01
    z[0,5,2]  R359      -6.5093362331390381e-01
    z[0,5,2]  R360      -3.8382175564765930e-01
    z[0,5,2]  R361      -1.7292433977127075e-01
    z[0,5,2]  R362      -4.8232406377792358e-01
    z[0,5,2]  R363      1.7470008134841919e-01
    z[0,5,2]  R364      7.2153680026531219e-02
    z[0,5,2]  R365      1.4411626756191254e-01
    z[0,5,3]  R5        -1
    z[0,5,3]  R50       1
    z[0,5,3]  R268      -1
    z[0,5,3]  R269      1
    z[0,5,3]  R276      -8.0044138431549072e-01
    z[0,5,3]  R277      -7.3260128498077393e-01
    z[0,5,3]  R278      -9.2536401748657227e-01
    z[0,5,3]  R279      -5.7159650325775146e-01
    z[0,5,3]  R280      -1.0784323513507843e-01
    z[0,5,3]  R281      -1.2085956335067749e-01
    z[0,5,3]  R282      -1.8910260498523712e-01
    z[0,5,3]  R283      -1.9142301380634308e-01
    z[0,5,3]  R284      -2.0735612511634827e-01
    z[0,5,3]  R285      3.5851910710334778e-02
    z[0,5,3]  R286      9.4207823276519775e-02
    z[0,5,3]  R287      -3.9301950484514236e-02
    z[0,5,3]  R288      0.0373460054397583
    z[0,5,3]  R289      -2.0858001708984375e-01
    z[0,5,3]  R290      -1.6748347878456116e-01
    z[0,5,3]  R291      1.0246150940656662e-01
    z[0,5,3]  R292      -1.7951881885528564e-01
    z[0,5,3]  R293      -3.3786278963088989e-01
    z[0,5,3]  R294      -2.1383160352706909e-01
    z[0,5,3]  R295      -7.5724922120571136e-02
    z[0,5,3]  R296      -5.0463861227035522e-01
    z[0,5,3]  R297      4.8110455274581909e-01
    z[0,5,3]  R298      4.5489895343780518e-01
    z[0,5,3]  R299      4.5532214641571045e-01
    z[0,5,3]  R300      -3.1989842653274536e-01
    z[0,5,3]  R301      7.7010315656661987e-01
    z[0,5,3]  R302      8.1475955247879028e-01
    z[0,5,3]  R303      6.9427573680877686e-01
    z[0,5,3]  R304      3.7086969614028931e-01
    z[0,5,3]  R305      5.2603012323379517e-01
    z[0,5,3]  R306      0.552764356136322
    z[0,5,3]  R307      4.5846515893936157e-01
    z[0,5,3]  R308      0.440618634223938
    z[0,5,3]  R309      4.2818653583526611e-01
    z[0,5,3]  R310      4.3854394555091858e-01
    z[0,5,3]  R311      8.4263467788696289e-01
    z[0,5,3]  R312      8.0142879486083984e-01
    z[0,5,3]  R313      4.2945098876953125e-01
    z[0,5,3]  R314      7.6675540208816528e-01
    z[0,5,3]  R315      7.1963596343994141e-01
    z[0,5,3]  R316      0.0196211077272892
    z[0,5,3]  R317      -0.701768696308136
    z[0,5,3]  R318      -6.5325957536697388e-01
    z[0,5,3]  R319      -7.0325976610183716e-01
    z[0,5,3]  R320      -6.5420705080032349e-01
    z[0,5,3]  R321      -6.7545342445373535e-01
    z[0,5,3]  R322      -6.6219961643218994e-01
    z[0,5,3]  R323      -7.0152705907821655e-01
    z[0,5,3]  R324      -7.6354062557220459e-01
    z[0,5,3]  R325      -7.1497130393981934e-01
    z[0,5,3]  R326      -1.7959071695804596e-01
    z[0,5,3]  R327      7.4589416384696960e-02
    z[0,5,3]  R328      2.4222701787948608e-01
    z[0,5,3]  R329      2.7327957749366760e-01
    z[0,5,3]  R330      -1.5850800275802612e-01
    z[0,5,3]  R331      -4.3000063300132751e-01
    z[0,5,3]  R332      2.2664192318916321e-01
    z[0,5,3]  R333      1.2618897855281830e-01
    z[0,5,3]  R334      -2.5506886839866638e-01
    z[0,5,3]  R335      3.7588068842887878e-01
    z[0,5,3]  R336      -2.2563324868679047e-01
    z[0,5,3]  R337      2.3195911198854446e-02
    z[0,5,3]  R338      0.390370637178421
    z[0,5,3]  R339      3.8116759061813354e-01
    z[0,5,3]  R340      3.2221826910972595e-01
    z[0,5,3]  R341      -2.9729706048965454e-01
    z[0,5,3]  R342      3.3737942576408386e-01
    z[0,5,3]  R343      3.2657852768898010e-01
    z[0,5,3]  R344      3.4689873456954956e-01
    z[0,5,3]  R345      3.2710546255111694e-01
    z[0,5,3]  R346      -3.4157100319862366e-01
    z[0,5,3]  R347      -1.9333158433437347e-01
    z[0,5,3]  R348      -3.9478850364685059e-01
    z[0,5,3]  R349      -4.0185242891311646e-01
    z[0,5,3]  R350      -1.7905758321285248e-01
    z[0,5,3]  R351      -0.620050847530365
    z[0,5,3]  R352      6.9500762224197388e-01
    z[0,5,3]  R353      0.589187502861023
    z[0,5,3]  R354      -1.3092766702175140e-01
    z[0,5,3]  R355      -4.1605284810066223e-01
    z[0,5,3]  R356      -3.2427427172660828e-01
    z[0,5,3]  R357      2.1129217743873596e-01
    z[0,5,3]  R358      3.5562857985496521e-01
    z[0,5,3]  R359      6.7207229137420654e-01
    z[0,5,3]  R360      5.5396783351898193e-01
    z[0,5,3]  R361      4.8108518123626709e-01
    z[0,5,3]  R362      4.1041249036788940e-01
    z[0,5,3]  R363      -1.6488130390644073e-01
    z[0,5,3]  R364      -1.4268906414508820e-01
    z[0,5,3]  R365      8.8368929922580719e-02
    z[0,5,4]  R6        -1
    z[0,5,4]  R51       1
    z[0,5,4]  R270      -1
    z[0,5,4]  R271      1
    z[0,5,4]  R276      -2.1164520084857941e-01
    z[0,5,4]  R277      -3.9901182055473328e-01
    z[0,5,4]  R278      2.5594955682754517e-01
    z[0,5,4]  R279      3.0116474628448486e-01
    z[0,5,4]  R280      -1.1749612540006638e-01
    z[0,5,4]  R281      -2.0477820653468370e-03
    z[0,5,4]  R282      3.2114297151565552e-01
    z[0,5,4]  R283      -1.7730036750435829e-02
    z[0,5,4]  R284      -1.3784086704254150e-01
    z[0,5,4]  R285      -7.2555428743362427e-01
    z[0,5,4]  R286      -3.5865274071693420e-01
    z[0,5,4]  R287      -2.5757363438606262e-01
    z[0,5,4]  R288      -3.9924946427345276e-01
    z[0,5,4]  R289      1.2988951057195663e-02
    z[0,5,4]  R290      2.8092095255851746e-01
    z[0,5,4]  R291      1.6135616600513458e-01
    z[0,5,4]  R292      1.2858679890632629e-01
    z[0,5,4]  R293      1.3438127934932709e-01
    z[0,5,4]  R294      -1.8022048473358154e-01
    z[0,5,4]  R295      2.6228258013725281e-01
    z[0,5,4]  R296      2.6210841536521912e-01
    z[0,5,4]  R297      5.4431253671646118e-01
    z[0,5,4]  R298      3.6802875995635986e-01
    z[0,5,4]  R299      5.4675036668777466e-01
    z[0,5,4]  R300      -4.5000213384628296e-01
    z[0,5,4]  R301      -3.7259936332702637e-01
    z[0,5,4]  R302      -2.2440558671951294e-01
    z[0,5,4]  R303      -6.1998224258422852e-01
    z[0,5,4]  R304      4.9447005987167358e-01
    z[0,5,4]  R305      -1.9379186630249023e-01
    z[0,5,4]  R306      2.1994405984878540e-01
    z[0,5,4]  R307      7.5776636600494385e-01
    z[0,5,4]  R308      6.0271179676055908e-01
    z[0,5,4]  R309      6.7618530988693237e-01
    z[0,5,4]  R310      5.8848571777343750e-01
    z[0,5,4]  R311      -0.422538697719574
    z[0,5,4]  R312      -5.2651070058345795e-02
    z[0,5,4]  R313      3.9391061663627625e-01
    z[0,5,4]  R314      -2.7618253231048584e-01
    z[0,5,4]  R315      -1.8348044157028198e-01
    z[0,5,4]  R316      1.5048332512378693e-01
    z[0,5,4]  R317      -3.2633045315742493e-01
    z[0,5,4]  R318      -1.6680608689785004e-01
    z[0,5,4]  R319      -4.1913607716560364e-01
    z[0,5,4]  R320      -9.9355258047580719e-02
    z[0,5,4]  R321      -1.8634644150733948e-01
    z[0,5,4]  R322      1.2752544879913330e-01
    z[0,5,4]  R323      -1.3623578846454620e-01
    z[0,5,4]  R324      -1.9300854206085205e-01
    z[0,5,4]  R325      -2.0560650527477264e-01
    z[0,5,4]  R326      -4.2824211716651917e-01
    z[0,5,4]  R327      -1.6616936028003693e-01
    z[0,5,4]  R328      -5.2697628736495972e-01
    z[0,5,4]  R329      -4.4625130295753479e-01
    z[0,5,4]  R330      3.8606348633766174e-01
    z[0,5,4]  R331      -1.2558455578982830e-02
    z[0,5,4]  R332      -5.8654683828353882e-01
    z[0,5,4]  R333      1.7067460715770721e-01
    z[0,5,4]  R334      3.1366115808486938e-01
    z[0,5,4]  R335      2.1508924663066864e-01
    z[0,5,4]  R336      3.9654234051704407e-01
    z[0,5,4]  R337      -1.3074333965778351e-01
    z[0,5,4]  R338      -2.6131460443139076e-02
    z[0,5,4]  R339      -2.5739734992384911e-02
    z[0,5,4]  R340      -4.4466635584831238e-01
    z[0,5,4]  R341      5.0851291418075562e-01
    z[0,5,4]  R342      -4.8996168375015259e-01
    z[0,5,4]  R343      -3.6061301361769438e-03
    z[0,5,4]  R344      2.9170578718185425e-01
    z[0,5,4]  R345      6.2315058708190918e-01
    z[0,5,4]  R346      -1.0473524034023285e-01
    z[0,5,4]  R347      2.4731905758380890e-01
    z[0,5,4]  R348      -4.7590738534927368e-01
    z[0,5,4]  R349      1.2608104385435581e-02
    z[0,5,4]  R350      -2.5923281908035278e-01
    z[0,5,4]  R351      -2.3029941320419312e-01
    z[0,5,4]  R352      -1.4339910447597504e-01
    z[0,5,4]  R353      2.5317385792732239e-01
    z[0,5,4]  R354      -1.3775067031383514e-01
    z[0,5,4]  R355      4.3282940983772278e-01
    z[0,5,4]  R356      -0.165388822555542
    z[0,5,4]  R357      -1.3358780741691589e-01
    z[0,5,4]  R358      -4.8172404058277607e-03
    z[0,5,4]  R359      -0.0821036770939827
    z[0,5,4]  R360      -1.8744440376758575e-01
    z[0,5,4]  R361      5.8051735162734985e-01
    z[0,5,4]  R362      5.5524122714996338e-01
    z[0,5,4]  R363      -7.4247263371944427e-02
    z[0,5,4]  R364      -4.5442916452884674e-02
    z[0,5,4]  R365      -2.5031277909874916e-02
    z[0,5,5]  R7        -1
    z[0,5,5]  R52       1
    z[0,5,5]  R272      -1
    z[0,5,5]  R273      1
    z[0,5,5]  R276      -4.6946471929550171e-01
    z[0,5,5]  R277      -3.6508047580718994e-01
    z[0,5,5]  R278      1.1537971906363964e-02
    z[0,5,5]  R279      -4.3312925100326538e-01
    z[0,5,5]  R280      -1.4218859374523163e-01
    z[0,5,5]  R281      -4.0969517827033997e-01
    z[0,5,5]  R282      4.2105689644813538e-02
    z[0,5,5]  R283      0.0718042328953743
    z[0,5,5]  R284      -3.0032646656036377e-01
    z[0,5,5]  R285      -4.3200269341468811e-02
    z[0,5,5]  R286      3.2576853036880493e-01
    z[0,5,5]  R287      3.7302923202514648e-01
    z[0,5,5]  R288      1.2362153269350529e-02
    z[0,5,5]  R289      7.5328819453716278e-02
    z[0,5,5]  R290      4.5080298185348511e-01
    z[0,5,5]  R291      4.5079210400581360e-01
    z[0,5,5]  R292      5.8838760852813721e-01
    z[0,5,5]  R293      -5.0827842950820923e-01
    z[0,5,5]  R294      -4.9634787440299988e-01
    z[0,5,5]  R295      4.2970347404479980e-01
    z[0,5,5]  R296      -1.7995594441890717e-01
    z[0,5,5]  R297      3.0343741178512573e-01
    z[0,5,5]  R298      -2.6977434754371643e-01
    z[0,5,5]  R299      -2.3725025355815887e-02
    z[0,5,5]  R300      -3.3120924234390259e-01
    z[0,5,5]  R301      -2.7226004004478455e-01
    z[0,5,5]  R302      -1.7371596395969391e-01
    z[0,5,5]  R303      -0.195637509226799
    z[0,5,5]  R304      -1.8987011909484863e-01
    z[0,5,5]  R305      -1.5229150652885437e-01
    z[0,5,5]  R306      4.2402278631925583e-02
    z[0,5,5]  R307      5.8454502373933792e-02
    z[0,5,5]  R308      2.0937785506248474e-01
    z[0,5,5]  R309      -2.1447671949863434e-01
    z[0,5,5]  R310      0.0199163518846035
    z[0,5,5]  R311      -2.7964893728494644e-02
    z[0,5,5]  R312      -2.4191781878471375e-01
    z[0,5,5]  R313      -3.7180560827255249e-01
    z[0,5,5]  R314      -1.4547628164291382e-01
    z[0,5,5]  R315      -1.2203764170408249e-01
    z[0,5,5]  R316      3.9202713966369629e-01
    z[0,5,5]  R317      -3.0105775594711304e-01
    z[0,5,5]  R318      -2.9000511765480042e-01
    z[0,5,5]  R319      -3.1298825144767761e-01
    z[0,5,5]  R320      -2.5966253876686096e-01
    z[0,5,5]  R321      -3.7169870734214783e-01
    z[0,5,5]  R322      -3.0928614735603333e-01
    z[0,5,5]  R323      -4.8580473661422729e-01
    z[0,5,5]  R324      -1.5923266112804413e-01
    z[0,5,5]  R325      -1.8636988475918770e-02
    z[0,5,5]  R326      4.3766376376152039e-01
    z[0,5,5]  R327      4.7934854030609131e-01
    z[0,5,5]  R328      3.0896827578544617e-01
    z[0,5,5]  R329      -5.0114773213863373e-02
    z[0,5,5]  R330      5.7238936424255371e-01
    z[0,5,5]  R331      1.4931109547615051e-01
    z[0,5,5]  R332      -2.4780185520648956e-01
    z[0,5,5]  R333      6.6247540712356567e-01
    z[0,5,5]  R334      7.9129147529602051e-01
    z[0,5,5]  R335      6.2015217542648315e-01
    z[0,5,5]  R336      8.2093071937561035e-01
    z[0,5,5]  R337      -3.2185354828834534e-01
    z[0,5,5]  R338      6.9746315479278564e-02
    z[0,5,5]  R339      3.5823008418083191e-01
    z[0,5,5]  R340      -2.6745175942778587e-02
    z[0,5,5]  R341      -5.3570348024368286e-01
    z[0,5,5]  R342      -6.4375501871109009e-01
    z[0,5,5]  R343      -3.1721353530883789e-01
    z[0,5,5]  R344      -2.1833148598670959e-01
    z[0,5,5]  R345      1.3217644765973091e-02
    z[0,5,5]  R346      4.9586769938468933e-01
    z[0,5,5]  R347      -5.7216089963912964e-01
    z[0,5,5]  R348      -7.6155602000653744e-03
    z[0,5,5]  R349      -4.1675922274589539e-01
    z[0,5,5]  R350      -2.5325170159339905e-01
    z[0,5,5]  R351      -3.5454273223876953e-01
    z[0,5,5]  R352      -4.6683784574270248e-02
    z[0,5,5]  R353      2.7457234263420105e-01
    z[0,5,5]  R354      -5.3711551427841187e-01
    z[0,5,5]  R355      -2.4102471768856049e-01
    z[0,5,5]  R356      2.3109711706638336e-01
    z[0,5,5]  R357      -1.1135119944810867e-01
    z[0,5,5]  R358      5.9610503911972046e-01
    z[0,5,5]  R359      -3.2514768838882446e-01
    z[0,5,5]  R360      -1.4958518743515015e-01
    z[0,5,5]  R361      -2.8918331861495972e-01
    z[0,5,5]  R362      3.2546848058700562e-01
    z[0,5,5]  R363      -1.7712321877479553e-01
    z[0,5,5]  R364      0.00496411370113492
    z[0,5,5]  R365      -9.9545374512672424e-02
    z[0,5,6]  R8        -1
    z[0,5,6]  R53       1
    z[0,5,6]  R274      -1
    z[0,5,6]  R275      1
    z[0,5,6]  R276      -9.6968440338969231e-03
    z[0,5,6]  R277      -3.7980365753173828e-01
    z[0,5,6]  R278      2.2535514831542969e-01
    z[0,5,6]  R279      -5.5980980396270752e-01
    z[0,5,6]  R280      -6.1930793523788452e-01
    z[0,5,6]  R281      -8.0132347345352173e-01
    z[0,5,6]  R282      6.7823834717273712e-02
    z[0,5,6]  R283      -3.4005227684974670e-01
    z[0,5,6]  R284      -8.3945453166961670e-02
    z[0,5,6]  R285      1.7073978483676910e-01
    z[0,5,6]  R286      -6.1976794153451920e-02
    z[0,5,6]  R287      3.1309393048286438e-01
    z[0,5,6]  R288      -3.7321012467145920e-02
    z[0,5,6]  R289      -2.1651054918766022e-01
    z[0,5,6]  R290      -2.9716560617089272e-02
    z[0,5,6]  R291      5.4164156317710876e-02
    z[0,5,6]  R292      -4.7218024730682373e-02
    z[0,5,6]  R293      -1.4352865517139435e-01
    z[0,5,6]  R294      2.3034781217575073e-01
    z[0,5,6]  R295      -3.6677280068397522e-01
    z[0,5,6]  R296      -1.3382703065872192e-01
    z[0,5,6]  R297      7.1961626410484314e-02
    z[0,5,6]  R298      -2.8764751553535461e-01
    z[0,5,6]  R299      -6.5888333320617676e-01
    z[0,5,6]  R300      3.1661653518676758e-01
    z[0,5,6]  R301      3.2620962709188461e-02
    z[0,5,6]  R302      -0.382634699344635
    z[0,5,6]  R303      8.0147329717874527e-03
    z[0,5,6]  R304      -2.6781329512596130e-01
    z[0,5,6]  R305      2.4436981976032257e-01
    z[0,5,6]  R306      -1.1241012066602707e-01
    z[0,5,6]  R307      1.5259535610675812e-01
    z[0,5,6]  R308      7.3405079543590546e-02
    z[0,5,6]  R309      -2.1999014914035797e-01
    z[0,5,6]  R310      -4.4594547152519226e-01
    z[0,5,6]  R311      1.6037710011005402e-01
    z[0,5,6]  R312      -4.4383895397186279e-01
    z[0,5,6]  R313      -0.314582496881485
    z[0,5,6]  R314      2.4479079991579056e-02
    z[0,5,6]  R315      2.7796393632888794e-01
    z[0,5,6]  R316      -4.2428311705589294e-01
    z[0,5,6]  R317      1.6255371272563934e-01
    z[0,5,6]  R318      2.2395044565200806e-02
    z[0,5,6]  R319      -1.9215951859951019e-01
    z[0,5,6]  R320      -6.3041254878044128e-02
    z[0,5,6]  R321      -3.3454650640487671e-01
    z[0,5,6]  R322      -1.7019891738891602e-01
    z[0,5,6]  R323      -1.8781930208206177e-01
    z[0,5,6]  R324      -2.9430219531059265e-01
    z[0,5,6]  R325      -1.4466480910778046e-01
    z[0,5,6]  R326      3.9500033855438232e-01
    z[0,5,6]  R327      5.2732348442077637e-01
    z[0,5,6]  R328      4.1301050782203674e-01
    z[0,5,6]  R329      2.1734927594661713e-01
    z[0,5,6]  R330      2.3387011885643005e-01
    z[0,5,6]  R331      2.1436008810997009e-01
    z[0,5,6]  R332      -1.4395037293434143e-01
    z[0,5,6]  R333      5.0748473405838013e-01
    z[0,5,6]  R334      0.391669362783432
    z[0,5,6]  R335      2.1751639246940613e-01
    z[0,5,6]  R336      1.1161798238754272e-01
    z[0,5,6]  R337      -3.3665984869003296e-01
    z[0,5,6]  R338      4.5295679569244385e-01
    z[0,5,6]  R339      2.1982754766941071e-01
    z[0,5,6]  R340      0.0766829177737236
    z[0,5,6]  R341      -5.3929977118968964e-02
    z[0,5,6]  R342      -1.0123301297426224e-01
    z[0,5,6]  R343      -2.4040430784225464e-01
    z[0,5,6]  R344      -1.9400058686733246e-01
    z[0,5,6]  R345      -9.2867843806743622e-02
    z[0,5,6]  R346      2.6835662126541138e-01
    z[0,5,6]  R347      2.2843407094478607e-01
    z[0,5,6]  R348      1.0012534260749817e-01
    z[0,5,6]  R349      9.2617996037006378e-02
    z[0,5,6]  R350      -3.1498336791992188e-01
    z[0,5,6]  R351      -2.8844013810157776e-01
    z[0,5,6]  R352      -2.1436761319637299e-01
    z[0,5,6]  R353      -2.7449825406074524e-01
    z[0,5,6]  R354      8.1667736172676086e-02
    z[0,5,6]  R355      -3.2363036274909973e-01
    z[0,5,6]  R356      -2.4558429419994354e-01
    z[0,5,6]  R357      -4.1955778002738953e-01
    z[0,5,6]  R358      -7.0165641605854034e-02
    z[0,5,6]  R359      -4.7278359532356262e-02
    z[0,5,6]  R360      4.0526536107063293e-01
    z[0,5,6]  R361      -3.5619777441024780e-01
    z[0,5,6]  R362      1.9313147664070129e-01
    z[0,5,6]  R363      -5.2450164221227169e-03
    z[0,5,6]  R364      -1.0943074524402618e-01
    z[0,5,6]  R365      -4.7539673745632172e-02
    z[5,0,0]  R2        1
    z[5,0,0]  R47       -1
    z[5,0,0]  R366      -1
    z[5,0,0]  R367      1
    z[5,0,0]  R380      2.9091495275497437e-01
    z[5,0,0]  R381      -3.6083468794822693e-01
    z[5,0,0]  R382      -4.6569105982780457e-01
    z[5,0,0]  R383      -2.0228002965450287e-01
    z[5,0,0]  R384      -3.6377462744712830e-01
    z[5,0,0]  R385      -3.3797499537467957e-01
    z[5,0,0]  R386      -5.4884368181228638e-01
    z[5,0,0]  R387      -3.7617659568786621e-01
    z[5,0,0]  R388      -3.1347030401229858e-01
    z[5,0,0]  R389      -6.2527453899383545e-01
    z[5,0,0]  R390      2.3207743465900421e-01
    z[5,0,0]  R391      -5.0279909372329712e-01
    z[5,0,0]  R392      -2.2818683087825775e-01
    z[5,0,0]  R393      -2.1225777268409729e-01
    z[5,0,0]  R394      -5.1677042245864868e-01
    z[5,0,0]  R395      -4.4484436511993408e-01
    z[5,0,0]  R396      2.0168316364288330e-01
    z[5,0,0]  R397      -1.7646947875618935e-02
    z[5,0,0]  R398      4.1896656155586243e-02
    z[5,0,0]  R399      8.8463641703128815e-02
    z[5,0,0]  R400      4.0395464748144150e-02
    z[5,0,0]  R401      -4.8250782489776611e-01
    z[5,0,0]  R402      4.6158574521541595e-02
    z[5,0,0]  R403      5.9904003143310547e-01
    z[5,0,0]  R404      5.6295675039291382e-01
    z[5,0,0]  R405      4.4647005200386047e-01
    z[5,0,0]  R406      -1.9672855734825134e-01
    z[5,0,0]  R407      -9.8254628479480743e-02
    z[5,0,0]  R408      3.3166274428367615e-01
    z[5,0,0]  R409      5.9548731893301010e-02
    z[5,0,0]  R410      -3.9123165607452393e-01
    z[5,0,0]  R411      -1.0539588332176208e-01
    z[5,0,0]  R412      2.6394993066787720e-01
    z[5,0,0]  R413      5.4921209812164307e-01
    z[5,0,0]  R414      -3.0321314930915833e-01
    z[5,0,0]  R415      3.6329996585845947e-01
    z[5,0,0]  R416      0.088935486972332
    z[5,0,0]  R417      5.6920063495635986e-01
    z[5,0,0]  R418      1.9802051782608032e-01
    z[5,0,0]  R419      1.6972261667251587e-01
    z[5,0,0]  R420      2.4450385570526123e-01
    z[5,0,0]  R421      9.1531641781330109e-02
    z[5,0,0]  R422      4.0710300207138062e-01
    z[5,0,0]  R423      -9.8229393362998962e-02
    z[5,0,0]  R424      4.2558785527944565e-02
    z[5,0,0]  R425      -4.2971599847078323e-02
    z[5,0,0]  R426      -2.2841045260429382e-01
    z[5,0,0]  R427      6.3354569673538208e-01
    z[5,0,0]  R428      8.4422230720520020e-01
    z[5,0,0]  R429      7.1804314851760864e-01
    z[5,0,0]  R430      -2.9110053181648254e-01
    z[5,0,0]  R431      -7.7135547995567322e-02
    z[5,0,0]  R432      -1.0992193967103958e-01
    z[5,0,0]  R433      -2.4763907492160797e-01
    z[5,0,0]  R434      -4.5247364044189453e-01
    z[5,0,0]  R435      3.4517128020524979e-02
    z[5,0,0]  R436      -3.4133675694465637e-01
    z[5,0,0]  R437      -3.1733080744743347e-01
    z[5,0,0]  R438      -1.9801306724548340e-01
    z[5,0,0]  R439      -4.4325807690620422e-01
    z[5,0,0]  R440      3.7688564509153366e-02
    z[5,0,0]  R441      1.8515534698963165e-01
    z[5,0,0]  R442      -3.2667997479438782e-01
    z[5,0,0]  R443      4.4320335984230042e-01
    z[5,0,0]  R444      3.5500061511993408e-01
    z[5,0,0]  R445      -2.6508134603500366e-01
    z[5,0,0]  R446      3.9741504192352295e-01
    z[5,0,0]  R447      3.8087822496891022e-02
    z[5,0,0]  R448      4.8788771033287048e-02
    z[5,0,0]  R449      -6.4040142297744751e-01
    z[5,0,0]  R450      6.1919075250625610e-01
    z[5,0,0]  R451      -2.0823439955711365e-01
    z[5,0,0]  R452      -3.6439269781112671e-01
    z[5,0,0]  R453      -2.5745810940861702e-02
    z[5,0,0]  R454      0.552279531955719
    z[5,0,0]  R455      -1.2913800776004791e-01
    z[5,0,0]  R456      -2.2922135889530182e-01
    z[5,0,0]  R457      7.8371495008468628e-02
    z[5,0,0]  R458      -4.2302292585372925e-01
    z[5,0,0]  R459      -4.5666176825761795e-02
    z[5,0,0]  R460      3.9789915084838867e-01
    z[5,0,0]  R461      -1.8887579441070557e-02
    z[5,0,0]  R462      1.0406654328107834e-02
    z[5,0,0]  R463      2.2542765736579895e-01
    z[5,0,0]  R464      1.2186097353696823e-01
    z[5,0,0]  R465      1.8019260466098785e-01
    z[5,0,0]  R466      8.4562357515096664e-03
    z[5,0,0]  R467      4.1901251673698425e-01
    z[5,0,0]  R468      -4.1141349077224731e-01
    z[5,0,0]  R469      1.2014894187450409e-01
    z[5,0,1]  R3        1
    z[5,0,1]  R48       -1
    z[5,0,1]  R368      -1
    z[5,0,1]  R369      1
    z[5,0,1]  R380      -7.3565638065338135e-01
    z[5,0,1]  R381      -6.4328014850616455e-02
    z[5,0,1]  R382      -2.9201605916023254e-01
    z[5,0,1]  R383      5.2661824971437454e-02
    z[5,0,1]  R384      1.3025499880313873e-01
    z[5,0,1]  R385      1.5686845779418945e-01
    z[5,0,1]  R386      -2.4323178455233574e-02
    z[5,0,1]  R387      -2.2287362813949585e-01
    z[5,0,1]  R388      -2.6984763145446777e-01
    z[5,0,1]  R389      1.4140671119093895e-02
    z[5,0,1]  R390      -1.0301580280065536e-01
    z[5,0,1]  R391      -2.9531466960906982e-01
    z[5,0,1]  R392      -5.1376044750213623e-01
    z[5,0,1]  R393      -1.5158012509346008e-01
    z[5,0,1]  R394      -1.9731591641902924e-01
    z[5,0,1]  R395      -5.2393499761819839e-02
    z[5,0,1]  R396      -0.373665452003479
    z[5,0,1]  R397      3.0326899886131287e-01
    z[5,0,1]  R398      1.3561367988586426e-01
    z[5,0,1]  R399      6.2951862812042236e-02
    z[5,0,1]  R400      -2.7003467082977295e-01
    z[5,0,1]  R401      -6.7096549272537231e-01
    z[5,0,1]  R402      5.3244483470916748e-01
    z[5,0,1]  R403      2.7409994602203369e-01
    z[5,0,1]  R404      -0.0711694285273552
    z[5,0,1]  R405      -1.6892926394939423e-01
    z[5,0,1]  R406      -2.3674850165843964e-01
    z[5,0,1]  R407      -2.7946993708610535e-01
    z[5,0,1]  R408      4.6551775932312012e-01
    z[5,0,1]  R409      -2.3112232983112335e-01
    z[5,0,1]  R410      -6.2447714805603027e-01
    z[5,0,1]  R411      -6.7923784255981445e-01
    z[5,0,1]  R412      -7.1744000911712646e-01
    z[5,0,1]  R413      -5.3574812412261963e-01
    z[5,0,1]  R414      -7.0917648077011108e-01
    z[5,0,1]  R415      -4.5288136601448059e-01
    z[5,0,1]  R416      -5.1484644412994385e-01
    z[5,0,1]  R417      -7.8515373170375824e-02
    z[5,0,1]  R418      -0.761551022529602
    z[5,0,1]  R419      -3.1575447320938110e-01
    z[5,0,1]  R420      -5.6011569499969482e-01
    z[5,0,1]  R421      -4.9273529648780823e-01
    z[5,0,1]  R422      -4.4910877943038940e-01
    z[5,0,1]  R423      -1.6063762828707695e-02
    z[5,0,1]  R424      5.6766015291213989e-01
    z[5,0,1]  R425      4.3509021401405334e-01
    z[5,0,1]  R426      3.0859598517417908e-01
    z[5,0,1]  R427      7.0993030071258545e-01
    z[5,0,1]  R428      4.9765196442604065e-01
    z[5,0,1]  R429      6.6561222076416016e-01
    z[5,0,1]  R430      -7.3140613734722137e-02
    z[5,0,1]  R431      -6.4375951886177063e-02
    z[5,0,1]  R432      -3.2401908189058304e-02
    z[5,0,1]  R433      -6.9302178919315338e-02
    z[5,0,1]  R434      -1.6971176862716675e-01
    z[5,0,1]  R435      -1.5012322366237640e-01
    z[5,0,1]  R436      7.0354324579238892e-01
    z[5,0,1]  R437      7.1915447711944580e-01
    z[5,0,1]  R438      8.3061850070953369e-01
    z[5,0,1]  R439      1.5530514717102051e-01
    z[5,0,1]  R440      -3.0270934104919434e-01
    z[5,0,1]  R441      -5.4343408346176147e-01
    z[5,0,1]  R442      -6.0718166828155518e-01
    z[5,0,1]  R443      -5.8420103788375854e-01
    z[5,0,1]  R444      -5.5674254894256592e-01
    z[5,0,1]  R445      -7.3574233055114746e-01
    z[5,0,1]  R446      -1.1066448874771595e-02
    z[5,0,1]  R447      -7.6014584302902222e-01
    z[5,0,1]  R448      -7.7486616373062134e-01
    z[5,0,1]  R449      0.0572950579226017
    z[5,0,1]  R450      4.7785595059394836e-01
    z[5,0,1]  R451      -1.8672700226306915e-01
    z[5,0,1]  R452      2.8185930848121643e-01
    z[5,0,1]  R453      -1.8345098197460175e-01
    z[5,0,1]  R454      4.2447263002395630e-01
    z[5,0,1]  R455      -2.7415317296981812e-01
    z[5,0,1]  R456      1.4668746292591095e-01
    z[5,0,1]  R457      2.9270383715629578e-01
    z[5,0,1]  R458      -3.7561511993408203e-01
    z[5,0,1]  R459      4.5177853107452393e-01
    z[5,0,1]  R460      4.3619260191917419e-01
    z[5,0,1]  R461      0.275611013174057
    z[5,0,1]  R462      0.527420163154602
    z[5,0,1]  R463      -1.5529237687587738e-01
    z[5,0,1]  R464      4.1819038987159729e-01
    z[5,0,1]  R465      -1.5105533599853516e-01
    z[5,0,1]  R466      1.2223100289702415e-02
    z[5,0,1]  R467      2.4060933291912079e-01
    z[5,0,1]  R468      -6.6439077258110046e-02
    z[5,0,1]  R469      -7.0705041289329529e-02
    z[5,0,2]  R4        1
    z[5,0,2]  R49       -1
    z[5,0,2]  R370      -1
    z[5,0,2]  R371      1
    z[5,0,2]  R380      1.3208520412445068e-01
    z[5,0,2]  R381      -3.8682025671005249e-01
    z[5,0,2]  R382      -3.9834859967231750e-01
    z[5,0,2]  R383      -3.8881012797355652e-01
    z[5,0,2]  R384      -5.8433258533477783e-01
    z[5,0,2]  R385      -3.4658560156822205e-01
    z[5,0,2]  R386      -3.4464821219444275e-01
    z[5,0,2]  R387      -1.6381615400314331e-01
    z[5,0,2]  R388      -3.1097128987312317e-01
    z[5,0,2]  R389      -1.8465775251388550e-01
    z[5,0,2]  R390      6.1017107963562012e-01
    z[5,0,2]  R391      3.4490790963172913e-01
    z[5,0,2]  R392      2.8559392690658569e-01
    z[5,0,2]  R393      7.7999740839004517e-01
    z[5,0,2]  R394      3.7083712220191956e-01
    z[5,0,2]  R395      7.3896294832229614e-01
    z[5,0,2]  R396      0.58495032787323
    z[5,0,2]  R397      4.0773600339889526e-01
    z[5,0,2]  R398      1.9199748337268829e-01
    z[5,0,2]  R399      6.0725563764572144e-01
    z[5,0,2]  R400      1.7580537497997284e-01
    z[5,0,2]  R401      2.8710660338401794e-01
    z[5,0,2]  R402      -5.9267640113830566e-01
    z[5,0,2]  R403      -4.9337202310562134e-01
    z[5,0,2]  R404      -6.0816633701324463e-01
    z[5,0,2]  R405      3.6779043078422546e-01
    z[5,0,2]  R406      -3.5593810677528381e-01
    z[5,0,2]  R407      -8.0446094274520874e-01
    z[5,0,2]  R408      -6.1851215362548828e-01
    z[5,0,2]  R409      -6.6251236200332642e-01
    z[5,0,2]  R410      1.0689135640859604e-01
    z[5,0,2]  R411      2.2233678400516510e-01
    z[5,0,2]  R412      -1.5225446224212646e-01
    z[5,0,2]  R413      2.5967153906822205e-01
    z[5,0,2]  R414      3.7751322984695435e-01
    z[5,0,2]  R415      1.2850096821784973e-01
    z[5,0,2]  R416      -4.1867870092391968e-01
    z[5,0,2]  R417      -3.2843223214149475e-01
    z[5,0,2]  R418      -2.2259384393692017e-01
    z[5,0,2]  R419      5.9010386466979980e-01
    z[5,0,2]  R420      6.1665505170822144e-01
    z[5,0,2]  R421      7.0563161373138428e-01
    z[5,0,2]  R422      3.8184961676597595e-01
    z[5,0,2]  R423      -6.5093362331390381e-01
    z[5,0,2]  R424      -3.8382175564765930e-01
    z[5,0,2]  R425      -1.7292433977127075e-01
    z[5,0,2]  R426      -4.8232406377792358e-01
    z[5,0,2]  R427      1.7470008134841919e-01
    z[5,0,2]  R428      7.2153680026531219e-02
    z[5,0,2]  R429      1.4411626756191254e-01
    z[5,0,2]  R430      6.2608234584331512e-02
    z[5,0,2]  R431      1.2828177213668823e-01
    z[5,0,2]  R432      1.1891358345746994e-01
    z[5,0,2]  R433      -1.2434328347444534e-01
    z[5,0,2]  R434      5.8074957132339478e-01
    z[5,0,2]  R435      3.8947516679763794e-01
    z[5,0,2]  R436      -4.9320429563522339e-01
    z[5,0,2]  R437      -4.7367650270462036e-01
    z[5,0,2]  R438      -0.334102064371109
    z[5,0,2]  R439      4.6975514292716980e-01
    z[5,0,2]  R440      8.1207972764968872e-01
    z[5,0,2]  R441      6.0442489385604858e-01
    z[5,0,2]  R442      6.0188883543014526e-01
    z[5,0,2]  R443      6.0502427816390991e-01
    z[5,0,2]  R444      5.0293004512786865e-01
    z[5,0,2]  R445      3.8175088167190552e-01
    z[5,0,2]  R446      6.6689413785934448e-01
    z[5,0,2]  R447      -9.7829692065715790e-02
    z[5,0,2]  R448      -1.3991887867450714e-01
    z[5,0,2]  R449      4.3921470642089844e-01
    z[5,0,2]  R450      -1.2083734571933746e-01
    z[5,0,2]  R451      -0.544776201248169
    z[5,0,2]  R452      -5.3840112686157227e-01
    z[5,0,2]  R453      -1.5728504955768585e-01
    z[5,0,2]  R454      -0.00527540547773242
    z[5,0,2]  R455      -3.1793826818466187e-01
    z[5,0,2]  R456      -1.8751792609691620e-01
    z[5,0,2]  R457      -5.8714441955089569e-02
    z[5,0,2]  R458      -4.3605649471282959e-01
    z[5,0,2]  R459      -6.2979239225387573e-01
    z[5,0,2]  R460      -5.3202873468399048e-01
    z[5,0,2]  R461      -3.3552855253219604e-01
    z[5,0,2]  R462      -3.3924323320388794e-01
    z[5,0,2]  R463      -4.3600523471832275e-01
    z[5,0,2]  R464      -2.6900994777679443e-01
    z[5,0,2]  R465      -1.7215685546398163e-01
    z[5,0,2]  R466      -3.1496292352676392e-01
    z[5,0,2]  R467      -4.3559196591377258e-01
    z[5,0,2]  R468      -3.7466189265251160e-01
    z[5,0,2]  R469      -5.8040237426757812e-01
    z[5,0,3]  R5        1
    z[5,0,3]  R50       -1
    z[5,0,3]  R372      -1
    z[5,0,3]  R373      1
    z[5,0,3]  R380      0.0196211077272892
    z[5,0,3]  R381      -0.701768696308136
    z[5,0,3]  R382      -6.5325957536697388e-01
    z[5,0,3]  R383      -7.0325976610183716e-01
    z[5,0,3]  R384      -6.5420705080032349e-01
    z[5,0,3]  R385      -6.7545342445373535e-01
    z[5,0,3]  R386      -6.6219961643218994e-01
    z[5,0,3]  R387      -7.0152705907821655e-01
    z[5,0,3]  R388      -7.6354062557220459e-01
    z[5,0,3]  R389      -7.1497130393981934e-01
    z[5,0,3]  R390      -1.7959071695804596e-01
    z[5,0,3]  R391      7.4589416384696960e-02
    z[5,0,3]  R392      2.4222701787948608e-01
    z[5,0,3]  R393      2.7327957749366760e-01
    z[5,0,3]  R394      -1.5850800275802612e-01
    z[5,0,3]  R395      -4.3000063300132751e-01
    z[5,0,3]  R396      2.2664192318916321e-01
    z[5,0,3]  R397      1.2618897855281830e-01
    z[5,0,3]  R398      -2.5506886839866638e-01
    z[5,0,3]  R399      3.7588068842887878e-01
    z[5,0,3]  R400      -2.2563324868679047e-01
    z[5,0,3]  R401      2.3195911198854446e-02
    z[5,0,3]  R402      0.390370637178421
    z[5,0,3]  R403      3.8116759061813354e-01
    z[5,0,3]  R404      3.2221826910972595e-01
    z[5,0,3]  R405      -2.9729706048965454e-01
    z[5,0,3]  R406      3.3737942576408386e-01
    z[5,0,3]  R407      3.2657852768898010e-01
    z[5,0,3]  R408      3.4689873456954956e-01
    z[5,0,3]  R409      3.2710546255111694e-01
    z[5,0,3]  R410      -3.4157100319862366e-01
    z[5,0,3]  R411      -1.9333158433437347e-01
    z[5,0,3]  R412      -3.9478850364685059e-01
    z[5,0,3]  R413      -4.0185242891311646e-01
    z[5,0,3]  R414      -1.7905758321285248e-01
    z[5,0,3]  R415      -0.620050847530365
    z[5,0,3]  R416      6.9500762224197388e-01
    z[5,0,3]  R417      0.589187502861023
    z[5,0,3]  R418      -1.3092766702175140e-01
    z[5,0,3]  R419      -4.1605284810066223e-01
    z[5,0,3]  R420      -3.2427427172660828e-01
    z[5,0,3]  R421      2.1129217743873596e-01
    z[5,0,3]  R422      3.5562857985496521e-01
    z[5,0,3]  R423      6.7207229137420654e-01
    z[5,0,3]  R424      5.5396783351898193e-01
    z[5,0,3]  R425      4.8108518123626709e-01
    z[5,0,3]  R426      4.1041249036788940e-01
    z[5,0,3]  R427      -1.6488130390644073e-01
    z[5,0,3]  R428      -1.4268906414508820e-01
    z[5,0,3]  R429      8.8368929922580719e-02
    z[5,0,3]  R430      -8.0044138431549072e-01
    z[5,0,3]  R431      -7.3260128498077393e-01
    z[5,0,3]  R432      -9.2536401748657227e-01
    z[5,0,3]  R433      -5.7159650325775146e-01
    z[5,0,3]  R434      -1.0784323513507843e-01
    z[5,0,3]  R435      -1.2085956335067749e-01
    z[5,0,3]  R436      -1.8910260498523712e-01
    z[5,0,3]  R437      -1.9142301380634308e-01
    z[5,0,3]  R438      -2.0735612511634827e-01
    z[5,0,3]  R439      3.5851910710334778e-02
    z[5,0,3]  R440      9.4207823276519775e-02
    z[5,0,3]  R441      -3.9301950484514236e-02
    z[5,0,3]  R442      0.0373460054397583
    z[5,0,3]  R443      -2.0858001708984375e-01
    z[5,0,3]  R444      -1.6748347878456116e-01
    z[5,0,3]  R445      1.0246150940656662e-01
    z[5,0,3]  R446      -1.7951881885528564e-01
    z[5,0,3]  R447      -3.3786278963088989e-01
    z[5,0,3]  R448      -2.1383160352706909e-01
    z[5,0,3]  R449      -7.5724922120571136e-02
    z[5,0,3]  R450      -5.0463861227035522e-01
    z[5,0,3]  R451      4.8110455274581909e-01
    z[5,0,3]  R452      4.5489895343780518e-01
    z[5,0,3]  R453      4.5532214641571045e-01
    z[5,0,3]  R454      -3.1989842653274536e-01
    z[5,0,3]  R455      7.7010315656661987e-01
    z[5,0,3]  R456      8.1475955247879028e-01
    z[5,0,3]  R457      6.9427573680877686e-01
    z[5,0,3]  R458      3.7086969614028931e-01
    z[5,0,3]  R459      5.2603012323379517e-01
    z[5,0,3]  R460      0.552764356136322
    z[5,0,3]  R461      4.5846515893936157e-01
    z[5,0,3]  R462      0.440618634223938
    z[5,0,3]  R463      4.2818653583526611e-01
    z[5,0,3]  R464      4.3854394555091858e-01
    z[5,0,3]  R465      8.4263467788696289e-01
    z[5,0,3]  R466      8.0142879486083984e-01
    z[5,0,3]  R467      4.2945098876953125e-01
    z[5,0,3]  R468      7.6675540208816528e-01
    z[5,0,3]  R469      7.1963596343994141e-01
    z[5,0,4]  R6        1
    z[5,0,4]  R51       -1
    z[5,0,4]  R374      -1
    z[5,0,4]  R375      1
    z[5,0,4]  R380      1.5048332512378693e-01
    z[5,0,4]  R381      -3.2633045315742493e-01
    z[5,0,4]  R382      -1.6680608689785004e-01
    z[5,0,4]  R383      -4.1913607716560364e-01
    z[5,0,4]  R384      -9.9355258047580719e-02
    z[5,0,4]  R385      -1.8634644150733948e-01
    z[5,0,4]  R386      1.2752544879913330e-01
    z[5,0,4]  R387      -1.3623578846454620e-01
    z[5,0,4]  R388      -1.9300854206085205e-01
    z[5,0,4]  R389      -2.0560650527477264e-01
    z[5,0,4]  R390      -4.2824211716651917e-01
    z[5,0,4]  R391      -1.6616936028003693e-01
    z[5,0,4]  R392      -5.2697628736495972e-01
    z[5,0,4]  R393      -4.4625130295753479e-01
    z[5,0,4]  R394      3.8606348633766174e-01
    z[5,0,4]  R395      -1.2558455578982830e-02
    z[5,0,4]  R396      -5.8654683828353882e-01
    z[5,0,4]  R397      1.7067460715770721e-01
    z[5,0,4]  R398      3.1366115808486938e-01
    z[5,0,4]  R399      2.1508924663066864e-01
    z[5,0,4]  R400      3.9654234051704407e-01
    z[5,0,4]  R401      -1.3074333965778351e-01
    z[5,0,4]  R402      -2.6131460443139076e-02
    z[5,0,4]  R403      -2.5739734992384911e-02
    z[5,0,4]  R404      -4.4466635584831238e-01
    z[5,0,4]  R405      5.0851291418075562e-01
    z[5,0,4]  R406      -4.8996168375015259e-01
    z[5,0,4]  R407      -3.6061301361769438e-03
    z[5,0,4]  R408      2.9170578718185425e-01
    z[5,0,4]  R409      6.2315058708190918e-01
    z[5,0,4]  R410      -1.0473524034023285e-01
    z[5,0,4]  R411      2.4731905758380890e-01
    z[5,0,4]  R412      -4.7590738534927368e-01
    z[5,0,4]  R413      1.2608104385435581e-02
    z[5,0,4]  R414      -2.5923281908035278e-01
    z[5,0,4]  R415      -2.3029941320419312e-01
    z[5,0,4]  R416      -1.4339910447597504e-01
    z[5,0,4]  R417      2.5317385792732239e-01
    z[5,0,4]  R418      -1.3775067031383514e-01
    z[5,0,4]  R419      4.3282940983772278e-01
    z[5,0,4]  R420      -0.165388822555542
    z[5,0,4]  R421      -1.3358780741691589e-01
    z[5,0,4]  R422      -4.8172404058277607e-03
    z[5,0,4]  R423      -0.0821036770939827
    z[5,0,4]  R424      -1.8744440376758575e-01
    z[5,0,4]  R425      5.8051735162734985e-01
    z[5,0,4]  R426      5.5524122714996338e-01
    z[5,0,4]  R427      -7.4247263371944427e-02
    z[5,0,4]  R428      -4.5442916452884674e-02
    z[5,0,4]  R429      -2.5031277909874916e-02
    z[5,0,4]  R430      -2.1164520084857941e-01
    z[5,0,4]  R431      -3.9901182055473328e-01
    z[5,0,4]  R432      2.5594955682754517e-01
    z[5,0,4]  R433      3.0116474628448486e-01
    z[5,0,4]  R434      -1.1749612540006638e-01
    z[5,0,4]  R435      -2.0477820653468370e-03
    z[5,0,4]  R436      3.2114297151565552e-01
    z[5,0,4]  R437      -1.7730036750435829e-02
    z[5,0,4]  R438      -1.3784086704254150e-01
    z[5,0,4]  R439      -7.2555428743362427e-01
    z[5,0,4]  R440      -3.5865274071693420e-01
    z[5,0,4]  R441      -2.5757363438606262e-01
    z[5,0,4]  R442      -3.9924946427345276e-01
    z[5,0,4]  R443      1.2988951057195663e-02
    z[5,0,4]  R444      2.8092095255851746e-01
    z[5,0,4]  R445      1.6135616600513458e-01
    z[5,0,4]  R446      1.2858679890632629e-01
    z[5,0,4]  R447      1.3438127934932709e-01
    z[5,0,4]  R448      -1.8022048473358154e-01
    z[5,0,4]  R449      2.6228258013725281e-01
    z[5,0,4]  R450      2.6210841536521912e-01
    z[5,0,4]  R451      5.4431253671646118e-01
    z[5,0,4]  R452      3.6802875995635986e-01
    z[5,0,4]  R453      5.4675036668777466e-01
    z[5,0,4]  R454      -4.5000213384628296e-01
    z[5,0,4]  R455      -3.7259936332702637e-01
    z[5,0,4]  R456      -2.2440558671951294e-01
    z[5,0,4]  R457      -6.1998224258422852e-01
    z[5,0,4]  R458      4.9447005987167358e-01
    z[5,0,4]  R459      -1.9379186630249023e-01
    z[5,0,4]  R460      2.1994405984878540e-01
    z[5,0,4]  R461      7.5776636600494385e-01
    z[5,0,4]  R462      6.0271179676055908e-01
    z[5,0,4]  R463      6.7618530988693237e-01
    z[5,0,4]  R464      5.8848571777343750e-01
    z[5,0,4]  R465      -0.422538697719574
    z[5,0,4]  R466      -5.2651070058345795e-02
    z[5,0,4]  R467      3.9391061663627625e-01
    z[5,0,4]  R468      -2.7618253231048584e-01
    z[5,0,4]  R469      -1.8348044157028198e-01
    z[5,0,5]  R7        1
    z[5,0,5]  R52       -1
    z[5,0,5]  R376      -1
    z[5,0,5]  R377      1
    z[5,0,5]  R380      3.9202713966369629e-01
    z[5,0,5]  R381      -3.0105775594711304e-01
    z[5,0,5]  R382      -2.9000511765480042e-01
    z[5,0,5]  R383      -3.1298825144767761e-01
    z[5,0,5]  R384      -2.5966253876686096e-01
    z[5,0,5]  R385      -3.7169870734214783e-01
    z[5,0,5]  R386      -3.0928614735603333e-01
    z[5,0,5]  R387      -4.8580473661422729e-01
    z[5,0,5]  R388      -1.5923266112804413e-01
    z[5,0,5]  R389      -1.8636988475918770e-02
    z[5,0,5]  R390      4.3766376376152039e-01
    z[5,0,5]  R391      4.7934854030609131e-01
    z[5,0,5]  R392      3.0896827578544617e-01
    z[5,0,5]  R393      -5.0114773213863373e-02
    z[5,0,5]  R394      5.7238936424255371e-01
    z[5,0,5]  R395      1.4931109547615051e-01
    z[5,0,5]  R396      -2.4780185520648956e-01
    z[5,0,5]  R397      6.6247540712356567e-01
    z[5,0,5]  R398      7.9129147529602051e-01
    z[5,0,5]  R399      6.2015217542648315e-01
    z[5,0,5]  R400      8.2093071937561035e-01
    z[5,0,5]  R401      -3.2185354828834534e-01
    z[5,0,5]  R402      6.9746315479278564e-02
    z[5,0,5]  R403      3.5823008418083191e-01
    z[5,0,5]  R404      -2.6745175942778587e-02
    z[5,0,5]  R405      -5.3570348024368286e-01
    z[5,0,5]  R406      -6.4375501871109009e-01
    z[5,0,5]  R407      -3.1721353530883789e-01
    z[5,0,5]  R408      -2.1833148598670959e-01
    z[5,0,5]  R409      1.3217644765973091e-02
    z[5,0,5]  R410      4.9586769938468933e-01
    z[5,0,5]  R411      -5.7216089963912964e-01
    z[5,0,5]  R412      -7.6155602000653744e-03
    z[5,0,5]  R413      -4.1675922274589539e-01
    z[5,0,5]  R414      -2.5325170159339905e-01
    z[5,0,5]  R415      -3.5454273223876953e-01
    z[5,0,5]  R416      -4.6683784574270248e-02
    z[5,0,5]  R417      2.7457234263420105e-01
    z[5,0,5]  R418      -5.3711551427841187e-01
    z[5,0,5]  R419      -2.4102471768856049e-01
    z[5,0,5]  R420      2.3109711706638336e-01
    z[5,0,5]  R421      -1.1135119944810867e-01
    z[5,0,5]  R422      5.9610503911972046e-01
    z[5,0,5]  R423      -3.2514768838882446e-01
    z[5,0,5]  R424      -1.4958518743515015e-01
    z[5,0,5]  R425      -2.8918331861495972e-01
    z[5,0,5]  R426      3.2546848058700562e-01
    z[5,0,5]  R427      -1.7712321877479553e-01
    z[5,0,5]  R428      0.00496411370113492
    z[5,0,5]  R429      -9.9545374512672424e-02
    z[5,0,5]  R430      -4.6946471929550171e-01
    z[5,0,5]  R431      -3.6508047580718994e-01
    z[5,0,5]  R432      1.1537971906363964e-02
    z[5,0,5]  R433      -4.3312925100326538e-01
    z[5,0,5]  R434      -1.4218859374523163e-01
    z[5,0,5]  R435      -4.0969517827033997e-01
    z[5,0,5]  R436      4.2105689644813538e-02
    z[5,0,5]  R437      0.0718042328953743
    z[5,0,5]  R438      -3.0032646656036377e-01
    z[5,0,5]  R439      -4.3200269341468811e-02
    z[5,0,5]  R440      3.2576853036880493e-01
    z[5,0,5]  R441      3.7302923202514648e-01
    z[5,0,5]  R442      1.2362153269350529e-02
    z[5,0,5]  R443      7.5328819453716278e-02
    z[5,0,5]  R444      4.5080298185348511e-01
    z[5,0,5]  R445      4.5079210400581360e-01
    z[5,0,5]  R446      5.8838760852813721e-01
    z[5,0,5]  R447      -5.0827842950820923e-01
    z[5,0,5]  R448      -4.9634787440299988e-01
    z[5,0,5]  R449      4.2970347404479980e-01
    z[5,0,5]  R450      -1.7995594441890717e-01
    z[5,0,5]  R451      3.0343741178512573e-01
    z[5,0,5]  R452      -2.6977434754371643e-01
    z[5,0,5]  R453      -2.3725025355815887e-02
    z[5,0,5]  R454      -3.3120924234390259e-01
    z[5,0,5]  R455      -2.7226004004478455e-01
    z[5,0,5]  R456      -1.7371596395969391e-01
    z[5,0,5]  R457      -0.195637509226799
    z[5,0,5]  R458      -1.8987011909484863e-01
    z[5,0,5]  R459      -1.5229150652885437e-01
    z[5,0,5]  R460      4.2402278631925583e-02
    z[5,0,5]  R461      5.8454502373933792e-02
    z[5,0,5]  R462      2.0937785506248474e-01
    z[5,0,5]  R463      -2.1447671949863434e-01
    z[5,0,5]  R464      0.0199163518846035
    z[5,0,5]  R465      -2.7964893728494644e-02
    z[5,0,5]  R466      -2.4191781878471375e-01
    z[5,0,5]  R467      -3.7180560827255249e-01
    z[5,0,5]  R468      -1.4547628164291382e-01
    z[5,0,5]  R469      -1.2203764170408249e-01
    z[5,0,6]  R8        1
    z[5,0,6]  R53       -1
    z[5,0,6]  R378      -1
    z[5,0,6]  R379      1
    z[5,0,6]  R380      -4.2428311705589294e-01
    z[5,0,6]  R381      1.6255371272563934e-01
    z[5,0,6]  R382      2.2395044565200806e-02
    z[5,0,6]  R383      -1.9215951859951019e-01
    z[5,0,6]  R384      -6.3041254878044128e-02
    z[5,0,6]  R385      -3.3454650640487671e-01
    z[5,0,6]  R386      -1.7019891738891602e-01
    z[5,0,6]  R387      -1.8781930208206177e-01
    z[5,0,6]  R388      -2.9430219531059265e-01
    z[5,0,6]  R389      -1.4466480910778046e-01
    z[5,0,6]  R390      3.9500033855438232e-01
    z[5,0,6]  R391      5.2732348442077637e-01
    z[5,0,6]  R392      4.1301050782203674e-01
    z[5,0,6]  R393      2.1734927594661713e-01
    z[5,0,6]  R394      2.3387011885643005e-01
    z[5,0,6]  R395      2.1436008810997009e-01
    z[5,0,6]  R396      -1.4395037293434143e-01
    z[5,0,6]  R397      5.0748473405838013e-01
    z[5,0,6]  R398      0.391669362783432
    z[5,0,6]  R399      2.1751639246940613e-01
    z[5,0,6]  R400      1.1161798238754272e-01
    z[5,0,6]  R401      -3.3665984869003296e-01
    z[5,0,6]  R402      4.5295679569244385e-01
    z[5,0,6]  R403      2.1982754766941071e-01
    z[5,0,6]  R404      0.0766829177737236
    z[5,0,6]  R405      -5.3929977118968964e-02
    z[5,0,6]  R406      -1.0123301297426224e-01
    z[5,0,6]  R407      -2.4040430784225464e-01
    z[5,0,6]  R408      -1.9400058686733246e-01
    z[5,0,6]  R409      -9.2867843806743622e-02
    z[5,0,6]  R410      2.6835662126541138e-01
    z[5,0,6]  R411      2.2843407094478607e-01
    z[5,0,6]  R412      1.0012534260749817e-01
    z[5,0,6]  R413      9.2617996037006378e-02
    z[5,0,6]  R414      -3.1498336791992188e-01
    z[5,0,6]  R415      -2.8844013810157776e-01
    z[5,0,6]  R416      -2.1436761319637299e-01
    z[5,0,6]  R417      -2.7449825406074524e-01
    z[5,0,6]  R418      8.1667736172676086e-02
    z[5,0,6]  R419      -3.2363036274909973e-01
    z[5,0,6]  R420      -2.4558429419994354e-01
    z[5,0,6]  R421      -4.1955778002738953e-01
    z[5,0,6]  R422      -7.0165641605854034e-02
    z[5,0,6]  R423      -4.7278359532356262e-02
    z[5,0,6]  R424      4.0526536107063293e-01
    z[5,0,6]  R425      -3.5619777441024780e-01
    z[5,0,6]  R426      1.9313147664070129e-01
    z[5,0,6]  R427      -5.2450164221227169e-03
    z[5,0,6]  R428      -1.0943074524402618e-01
    z[5,0,6]  R429      -4.7539673745632172e-02
    z[5,0,6]  R430      -9.6968440338969231e-03
    z[5,0,6]  R431      -3.7980365753173828e-01
    z[5,0,6]  R432      2.2535514831542969e-01
    z[5,0,6]  R433      -5.5980980396270752e-01
    z[5,0,6]  R434      -6.1930793523788452e-01
    z[5,0,6]  R435      -8.0132347345352173e-01
    z[5,0,6]  R436      6.7823834717273712e-02
    z[5,0,6]  R437      -3.4005227684974670e-01
    z[5,0,6]  R438      -8.3945453166961670e-02
    z[5,0,6]  R439      1.7073978483676910e-01
    z[5,0,6]  R440      -6.1976794153451920e-02
    z[5,0,6]  R441      3.1309393048286438e-01
    z[5,0,6]  R442      -3.7321012467145920e-02
    z[5,0,6]  R443      -2.1651054918766022e-01
    z[5,0,6]  R444      -2.9716560617089272e-02
    z[5,0,6]  R445      5.4164156317710876e-02
    z[5,0,6]  R446      -4.7218024730682373e-02
    z[5,0,6]  R447      -1.4352865517139435e-01
    z[5,0,6]  R448      2.3034781217575073e-01
    z[5,0,6]  R449      -3.6677280068397522e-01
    z[5,0,6]  R450      -1.3382703065872192e-01
    z[5,0,6]  R451      7.1961626410484314e-02
    z[5,0,6]  R452      -2.8764751553535461e-01
    z[5,0,6]  R453      -6.5888333320617676e-01
    z[5,0,6]  R454      3.1661653518676758e-01
    z[5,0,6]  R455      3.2620962709188461e-02
    z[5,0,6]  R456      -0.382634699344635
    z[5,0,6]  R457      8.0147329717874527e-03
    z[5,0,6]  R458      -2.6781329512596130e-01
    z[5,0,6]  R459      2.4436981976032257e-01
    z[5,0,6]  R460      -1.1241012066602707e-01
    z[5,0,6]  R461      1.5259535610675812e-01
    z[5,0,6]  R462      7.3405079543590546e-02
    z[5,0,6]  R463      -2.1999014914035797e-01
    z[5,0,6]  R464      -4.4594547152519226e-01
    z[5,0,6]  R465      1.6037710011005402e-01
    z[5,0,6]  R466      -4.4383895397186279e-01
    z[5,0,6]  R467      -0.314582496881485
    z[5,0,6]  R468      2.4479079991579056e-02
    z[5,0,6]  R469      2.7796393632888794e-01
    z[1,2,0]  R11       -1
    z[1,2,0]  R20       1
    z[1,2,0]  R524      -1
    z[1,2,0]  R525      1
    z[1,2,0]  R538      -6.8537926673889160e-01
    z[1,2,0]  R539      -6.1989778280258179e-01
    z[1,2,0]  R540      -3.9015492796897888e-01
    z[1,2,0]  R541      -7.6221138238906860e-01
    z[1,2,0]  R542      -7.7940732240676880e-01
    z[1,2,0]  R543      6.3415724039077759e-01
    z[1,2,0]  R544      -2.0341657102108002e-01
    z[1,2,0]  R545      8.5822738707065582e-02
    z[1,2,0]  R546      7.1230880916118622e-02
    z[1,2,0]  R547      -6.0418337583541870e-02
    z[1,2,0]  R548      3.2008466124534607e-01
    z[1,2,0]  R549      4.0764841437339783e-01
    z[1,2,0]  R550      4.9026329070329666e-03
    z[1,2,0]  R551      8.2191802561283112e-02
    z[1,2,0]  R552      0.0870785117149353
    z[1,2,0]  R553      2.6003026962280273e-01
    z[1,2,0]  R554      5.3831964731216431e-01
    z[1,2,0]  R555      1.6848705708980560e-01
    z[1,2,0]  R556      1.2245961278676987e-01
    z[1,2,0]  R557      4.3266189098358154e-01
    z[1,2,0]  R558      -1.7281191051006317e-01
    z[1,2,0]  R559      3.7440863251686096e-01
    z[1,2,0]  R560      -8.8296726346015930e-02
    z[1,2,0]  R561      -8.5912920534610748e-02
    z[1,2,0]  R562      -8.5435574874281883e-03
    z[1,2,0]  R563      5.6546766310930252e-02
    z[1,2,0]  R564      4.1534101963043213e-01
    z[1,2,0]  R565      -9.5797730609774590e-03
    z[1,2,0]  R566      1.6904467344284058e-01
    z[1,2,0]  R567      9.3381822109222412e-02
    z[1,2,0]  R568      3.4843999147415161e-01
    z[1,2,0]  R569      1.5935826301574707e-01
    z[1,2,0]  R570      2.6861077547073364e-01
    z[1,2,0]  R571      1.4243774116039276e-01
    z[1,2,0]  R572      3.2409456372261047e-01
    z[1,2,0]  R573      4.6643380075693130e-02
    z[1,2,0]  R574      2.9713290929794312e-01
    z[1,2,0]  R575      1.7995053529739380e-01
    z[1,2,0]  R576      4.1195189952850342e-01
    z[1,2,0]  R577      -7.0935539901256561e-02
    z[1,2,0]  R578      -4.6003714203834534e-01
    z[1,2,0]  R579      -8.5073653608560562e-03
    z[1,2,0]  R580      -5.5655580759048462e-01
    z[1,2,0]  R581      -4.1328959167003632e-02
    z[1,2,0]  R582      1.8384875357151031e-01
    z[1,2,0]  R583      -6.8432295322418213e-01
    z[1,2,0]  R584      -4.3920648097991943e-01
    z[1,2,0]  R585      -2.7425637841224670e-01
    z[1,2,0]  R586      -3.9826804399490356e-01
    z[1,2,0]  R587      3.2798236608505249e-01
    z[1,2,0]  R588      1.9804461300373077e-01
    z[1,2,0]  R589      -7.2348743677139282e-02
    z[1,2,0]  R590      -1.7537489533424377e-02
    z[1,2,0]  R591      0.292106568813324
    z[1,2,0]  R592      0.402878999710083
    z[1,2,0]  R593      -1.2381814420223236e-01
    z[1,2,0]  R594      -2.3071540892124176e-01
    z[1,2,0]  R595      7.0579960942268372e-02
    z[1,2,0]  R596      3.9821188896894455e-02
    z[1,2,0]  R597      -6.1034295707941055e-02
    z[1,2,0]  R598      -1.8003901839256287e-01
    z[1,2,0]  R599      -1.5587781369686127e-01
    z[1,2,0]  R600      1.8529336154460907e-01
    z[1,2,0]  R601      -8.3421230316162109e-02
    z[1,2,0]  R602      -3.2203629612922668e-01
    z[1,2,0]  R603      -4.6948346495628357e-01
    z[1,2,0]  R604      -4.3462562561035156e-01
    z[1,2,0]  R605      -1.4304748177528381e-01
    z[1,2,0]  R606      1.8365567922592163e-01
    z[1,2,0]  R607      -2.8893113136291504e-02
    z[1,2,0]  R608      -3.8958737254142761e-01
    z[1,2,0]  R609      -6.8815350532531738e-02
    z[1,2,0]  R610      2.4270290136337280e-01
    z[1,2,0]  R611      -0.233124777674675
    z[1,2,0]  R612      -2.7780758216977119e-02
    z[1,2,0]  R613      -9.1728426516056061e-02
    z[1,2,0]  R614      1.5637844800949097e-01
    z[1,2,0]  R615      1.3719514012336731e-01
    z[1,2,0]  R616      2.9046159982681274e-01
    z[1,2,0]  R617      -4.0357176214456558e-02
    z[1,2,0]  R618      -0.00798717699944973
    z[1,2,0]  R619      -3.9652702212333679e-01
    z[1,2,0]  R620      2.3141847550868988e-01
    z[1,2,0]  R621      -1.4708544313907623e-01
    z[1,2,0]  R622      2.6743856072425842e-01
    z[1,2,0]  R623      1.0477688163518906e-01
    z[1,2,0]  R624      3.3715635538101196e-01
    z[1,2,0]  R625      4.3467298150062561e-01
    z[1,2,0]  R626      2.1802544593811035e-01
    z[1,2,0]  R627      3.1608527898788452e-01
    z[1,2,0]  R628      -7.1441113948822021e-02
    z[1,2,0]  R629      -1.0171761363744736e-01
    z[1,2,0]  R630      2.2076368331909180e-01
    z[1,2,0]  R631      -4.1067633777856827e-02
    z[1,2,0]  R632      -1.7654503881931305e-01
    z[1,2,0]  R633      1.7004080116748810e-01
    z[1,2,0]  R634      -7.1844369173049927e-02
    z[1,2,0]  R635      1.2535277009010315e-01
    z[1,2,0]  R636      6.0810748487710953e-02
    z[1,2,0]  R637      -1.0493205487728119e-01
    z[1,2,1]  R12       -1
    z[1,2,1]  R21       1
    z[1,2,1]  R526      -1
    z[1,2,1]  R527      1
    z[1,2,1]  R538      0.0571502223610878
    z[1,2,1]  R539      -1.4520107768476009e-02
    z[1,2,1]  R540      5.2287089824676514e-01
    z[1,2,1]  R541      1.9970615208148956e-01
    z[1,2,1]  R542      -1.5222278423607349e-02
    z[1,2,1]  R543      -3.3910888433456421e-01
    z[1,2,1]  R544      1.7417545616626740e-01
    z[1,2,1]  R545      4.5699110627174377e-01
    z[1,2,1]  R546      2.8019109368324280e-01
    z[1,2,1]  R547      6.7615598440170288e-01
    z[1,2,1]  R548      -4.2932316660881042e-01
    z[1,2,1]  R549      -5.7425397634506226e-01
    z[1,2,1]  R550      -6.2131518125534058e-01
    z[1,2,1]  R551      -7.5799202919006348e-01
    z[1,2,1]  R552      -5.5511152744293213e-01
    z[1,2,1]  R553      -5.6249588727951050e-01
    z[1,2,1]  R554      -6.5417569875717163e-01
    z[1,2,1]  R555      -5.1269501447677612e-01
    z[1,2,1]  R556      -4.8968937993049622e-01
    z[1,2,1]  R557      -4.9344503879547119e-01
    z[1,2,1]  R558      -8.4892296791076660e-01
    z[1,2,1]  R559      -7.8575527667999268e-01
    z[1,2,1]  R560      -7.1145397424697876e-01
    z[1,2,1]  R561      -7.1247613430023193e-01
    z[1,2,1]  R562      -6.9293183088302612e-01
    z[1,2,1]  R563      -6.3465994596481323e-01
    z[1,2,1]  R564      -0.61861252784729
    z[1,2,1]  R565      -5.3537541627883911e-01
    z[1,2,1]  R566      0.595018208026886
    z[1,2,1]  R567      4.8361852765083313e-01
    z[1,2,1]  R568      -7.9290562868118286e-01
    z[1,2,1]  R569      -6.0925519466400146e-01
    z[1,2,1]  R570      -0.825687050819397
    z[1,2,1]  R571      -0.647787868976593
    z[1,2,1]  R572      6.7067429423332214e-02
    z[1,2,1]  R573      -3.6139285564422607e-01
    z[1,2,1]  R574      -3.7306267768144608e-02
    z[1,2,1]  R575      4.8320105671882629e-01
    z[1,2,1]  R576      3.7311285734176636e-01
    z[1,2,1]  R577      5.6233358383178711e-01
    z[1,2,1]  R578      -1.2009544670581818e-01
    z[1,2,1]  R579      -8.1751078367233276e-02
    z[1,2,1]  R580      -1.1944067478179932e-01
    z[1,2,1]  R581      4.1970473527908325e-01
    z[1,2,1]  R582      2.8386149555444717e-02
    z[1,2,1]  R583      -3.3588859438896179e-01
    z[1,2,1]  R584      -3.5688936710357666e-01
    z[1,2,1]  R585      -1.0904785245656967e-01
    z[1,2,1]  R586      2.6019543409347534e-01
    z[1,2,1]  R587      3.2960599660873413e-01
    z[1,2,1]  R588      0.310889333486557
    z[1,2,1]  R589      3.6694172024726868e-01
    z[1,2,1]  R590      2.3732134699821472e-01
    z[1,2,1]  R591      6.3886421918869019e-01
    z[1,2,1]  R592      7.7943336963653564e-01
    z[1,2,1]  R593      -6.4054572582244873e-01
    z[1,2,1]  R594      -3.4550639986991882e-01
    z[1,2,1]  R595      1.6194467246532440e-01
    z[1,2,1]  R596      1.1359908431768417e-01
    z[1,2,1]  R597      2.0492841303348541e-01
    z[1,2,1]  R598      -7.6640337705612183e-02
    z[1,2,1]  R599      -3.9700353145599365e-01
    z[1,2,1]  R600      1.8615961074829102e-01
    z[1,2,1]  R601      -2.4497555196285248e-01
    z[1,2,1]  R602      -4.1259798407554626e-01
    z[1,2,1]  R603      -6.4995211362838745e-01
    z[1,2,1]  R604      -2.0629326999187469e-01
    z[1,2,1]  R605      3.5990167409181595e-02
    z[1,2,1]  R606      5.4702192544937134e-01
    z[1,2,1]  R607      -2.8597798943519592e-01
    z[1,2,1]  R608      -4.1062659025192261e-01
    z[1,2,1]  R609      1.3161525130271912e-01
    z[1,2,1]  R610      1.3473476469516754e-01
    z[1,2,1]  R611      -7.6633952558040619e-02
    z[1,2,1]  R612      -2.4065822362899780e-01
    z[1,2,1]  R613      -3.3735689520835876e-01
    z[1,2,1]  R614      4.1433599591255188e-01
    z[1,2,1]  R615      3.6250334978103638e-01
    z[1,2,1]  R616      4.3162074685096741e-01
    z[1,2,1]  R617      2.9725155234336853e-01
    z[1,2,1]  R618      2.8470417857170105e-01
    z[1,2,1]  R619      -4.2697837948799133e-01
    z[1,2,1]  R620      3.6318513751029968e-01
    z[1,2,1]  R621      1.9550137221813202e-01
    z[1,2,1]  R622      3.1546348333358765e-01
    z[1,2,1]  R623      -1.8552072346210480e-01
    z[1,2,1]  R624      -9.1899514198303223e-01
    z[1,2,1]  R625      -8.7285065650939941e-01
    z[1,2,1]  R626      -8.4027677774429321e-01
    z[1,2,1]  R627      -8.3648532629013062e-01
    z[1,2,1]  R628      -2.1401226520538330e-01
    z[1,2,1]  R629      5.2057977765798569e-02
    z[1,2,1]  R630      4.2800846695899963e-01
    z[1,2,1]  R631      2.6091209053993225e-01
    z[1,2,1]  R632      -8.2916563749313354e-01
    z[1,2,1]  R633      -7.2809213399887085e-01
    z[1,2,1]  R634      -6.6152030229568481e-01
    z[1,2,1]  R635      1.5068809688091278e-01
    z[1,2,1]  R636      -1.2697984278202057e-01
    z[1,2,1]  R637      -1.8668781220912933e-01
    z[1,2,2]  R13       -1
    z[1,2,2]  R22       1
    z[1,2,2]  R528      -1
    z[1,2,2]  R529      1
    z[1,2,2]  R538      3.3827850222587585e-01
    z[1,2,2]  R539      2.6897537708282471e-01
    z[1,2,2]  R540      4.7927427291870117e-01
    z[1,2,2]  R541      5.6895589828491211e-01
    z[1,2,2]  R542      3.1550264358520508e-01
    z[1,2,2]  R543      2.3017936944961548e-01
    z[1,2,2]  R544      -8.0488801002502441e-01
    z[1,2,2]  R545      -6.7732048034667969e-01
    z[1,2,2]  R546      -5.6877499818801880e-01
    z[1,2,2]  R547      -4.7535607218742371e-01
    z[1,2,2]  R548      4.1857668757438660e-01
    z[1,2,2]  R549      7.0329317823052406e-03
    z[1,2,2]  R550      2.1478319168090820e-01
    z[1,2,2]  R551      -3.4359315037727356e-01
    z[1,2,2]  R552      -2.9130160808563232e-01
    z[1,2,2]  R553      -0.227743998169899
    z[1,2,2]  R554      -1.8006688356399536e-01
    z[1,2,2]  R555      2.9676848649978638e-01
    z[1,2,2]  R556      -5.0348842144012451e-01
    z[1,2,2]  R557      -4.6433243155479431e-01
    z[1,2,2]  R558      -4.0656253695487976e-01
    z[1,2,2]  R559      1.4423318207263947e-01
    z[1,2,2]  R560      1.1157031171023846e-02
    z[1,2,2]  R561      4.5995819568634033e-01
    z[1,2,2]  R562      7.3543138802051544e-02
    z[1,2,2]  R563      -1.3757381588220596e-02
    z[1,2,2]  R564      1.4972053468227386e-01
    z[1,2,2]  R565      -4.3314412236213684e-01
    z[1,2,2]  R566      -3.6220791935920715e-01
    z[1,2,2]  R567      -5.7210975885391235e-01
    z[1,2,2]  R568      8.0398945137858391e-03
    z[1,2,2]  R569      3.2255479693412781e-01
    z[1,2,2]  R570      3.1184738874435425e-01
    z[1,2,2]  R571      2.2299650311470032e-01
    z[1,2,2]  R572      1.6216664016246796e-01
    z[1,2,2]  R573      -4.9299055337905884e-01
    z[1,2,2]  R574      8.9813880622386932e-02
    z[1,2,2]  R575      -6.4932525157928467e-01
    z[1,2,2]  R576      -0.747498095035553
    z[1,2,2]  R577      -6.4216977357864380e-01
    z[1,2,2]  R578      -1.4356851577758789e-01
    z[1,2,2]  R579      0.729804277420044
    z[1,2,2]  R580      -2.6146861910820007e-01
    z[1,2,2]  R581      -3.0947241187095642e-01
    z[1,2,2]  R582      -5.2568817138671875e-01
    z[1,2,2]  R583      -4.1015830636024475e-01
    z[1,2,2]  R584      -2.6602697372436523e-01
    z[1,2,2]  R585      5.3871631622314453e-01
    z[1,2,2]  R586      -1.6271330416202545e-01
    z[1,2,2]  R587      -3.7800505757331848e-01
    z[1,2,2]  R588      0.69382244348526
    z[1,2,2]  R589      3.9817529916763306e-01
    z[1,2,2]  R590      -7.6352918148040771e-01
    z[1,2,2]  R591      2.0025306940078735e-01
    z[1,2,2]  R592      3.0574655532836914e-01
    z[1,2,2]  R593      2.9796570539474487e-01
    z[1,2,2]  R594      2.2964215278625488e-01
    z[1,2,2]  R595      3.6519104242324829e-01
    z[1,2,2]  R596      -6.5180528163909912e-01
    z[1,2,2]  R597      -4.6473458409309387e-01
    z[1,2,2]  R598      5.0008010864257812e-01
    z[1,2,2]  R599      5.1603639125823975e-01
    z[1,2,2]  R600      7.4964660406112671e-01
    z[1,2,2]  R601      6.6788399219512939e-01
    z[1,2,2]  R602      -7.1688455343246460e-01
    z[1,2,2]  R603      1.4531970024108887e-01
    z[1,2,2]  R604      -7.0390887558460236e-02
    z[1,2,2]  R605      -9.6790179610252380e-02
    z[1,2,2]  R606      3.4134072065353394e-01
    z[1,2,2]  R607      -7.9266905784606934e-01
    z[1,2,2]  R608      2.1038149297237396e-01
    z[1,2,2]  R609      -7.8002011775970459e-01
    z[1,2,2]  R610      -7.2178280353546143e-01
    z[1,2,2]  R611      6.2027710676193237e-01
    z[1,2,2]  R612      -5.2359807491302490e-01
    z[1,2,2]  R613      2.7404937148094177e-01
    z[1,2,2]  R614      7.2649180889129639e-01
    z[1,2,2]  R615      -2.9205662012100220e-01
    z[1,2,2]  R616      6.9390803575515747e-01
    z[1,2,2]  R617      -0.504687488079071
    z[1,2,2]  R618      6.4094376564025879e-01
    z[1,2,2]  R619      5.0092363357543945e-01
    z[1,2,2]  R620      5.5363011360168457e-01
    z[1,2,2]  R621      6.6597777605056763e-01
    z[1,2,2]  R622      7.9786878824234009e-01
    z[1,2,2]  R623      7.3170125484466553e-01
    z[1,2,2]  R624      -1.2281985580921173e-01
    z[1,2,2]  R625      1.1112658679485321e-01
    z[1,2,2]  R626      1.9943784177303314e-01
    z[1,2,2]  R627      -1.5234960615634918e-01
    z[1,2,2]  R628      3.9555743336677551e-01
    z[1,2,2]  R629      4.0862086415290833e-01
    z[1,2,2]  R630      7.8288817405700684e-01
    z[1,2,2]  R631      -1.1294302530586720e-02
    z[1,2,2]  R632      -6.9810695946216583e-02
    z[1,2,2]  R633      -2.8861811757087708e-01
    z[1,2,2]  R634      4.2097836732864380e-02
    z[1,2,2]  R635      1.5735620632767677e-02
    z[1,2,2]  R636      -0.131294846534729
    z[1,2,2]  R637      2.8363198041915894e-02
    z[1,2,3]  R14       -1
    z[1,2,3]  R23       1
    z[1,2,3]  R530      -1
    z[1,2,3]  R531      1
    z[1,2,3]  R538      -6.3158601522445679e-01
    z[1,2,3]  R539      -5.0303298234939575e-01
    z[1,2,3]  R540      -7.2316408157348633e-02
    z[1,2,3]  R541      -5.6475561112165451e-02
    z[1,2,3]  R542      -1.6880510747432709e-01
    z[1,2,3]  R543      -7.7094823122024536e-02
    z[1,2,3]  R544      2.0961783826351166e-01
    z[1,2,3]  R545      -5.4559266567230225e-01
    z[1,2,3]  R546      -8.2782298326492310e-02
    z[1,2,3]  R547      -1.4568190276622772e-01
    z[1,2,3]  R548      -2.1791622042655945e-01
    z[1,2,3]  R549      -4.3024352192878723e-01
    z[1,2,3]  R550      6.3930678367614746e-01
    z[1,2,3]  R551      4.6592387557029724e-01
    z[1,2,3]  R552      -2.5682101026177406e-02
    z[1,2,3]  R553      -3.0834561586380005e-01
    z[1,2,3]  R554      -2.6775610446929932e-01
    z[1,2,3]  R555      4.7634443640708923e-01
    z[1,2,3]  R556      3.9109072089195251e-01
    z[1,2,3]  R557      -1.5720802545547485e-01
    z[1,2,3]  R558      -3.4958653151988983e-02
    z[1,2,3]  R559      -2.1188369393348694e-01
    z[1,2,3]  R560      -1.2492434680461884e-01
    z[1,2,3]  R561      5.2482996135950089e-02
    z[1,2,3]  R562      5.5309587717056274e-01
    z[1,2,3]  R563      -2.6708588004112244e-01
    z[1,2,3]  R564      1.7133103311061859e-01
    z[1,2,3]  R565      2.1449856460094452e-02
    z[1,2,3]  R566      -4.7806450724601746e-01
    z[1,2,3]  R567      -4.8097869753837585e-01
    z[1,2,3]  R568      -1.2466013431549072e-01
    z[1,2,3]  R569      -2.6293888688087463e-01
    z[1,2,3]  R570      3.3467465639114380e-01
    z[1,2,3]  R571      1.5844729542732239e-01
    z[1,2,3]  R572      -6.4167755842208862e-01
    z[1,2,3]  R573      -6.8747711181640625e-01
    z[1,2,3]  R574      -3.5609990358352661e-01
    z[1,2,3]  R575      2.1293807029724121e-01
    z[1,2,3]  R576      2.8251573443412781e-01
    z[1,2,3]  R577      3.0904152989387512e-01
    z[1,2,3]  R578      -7.7471143007278442e-01
    z[1,2,3]  R579      -1.9912803173065186e-01
    z[1,2,3]  R580      -5.9046244621276855e-01
    z[1,2,3]  R581      -7.7111244201660156e-01
    z[1,2,3]  R582      -4.2575830221176147e-01
    z[1,2,3]  R583      -2.1329177916049957e-01
    z[1,2,3]  R584      -4.8338085412979126e-01
    z[1,2,3]  R585      -0.650117039680481
    z[1,2,3]  R586      -6.1055636405944824e-01
    z[1,2,3]  R587      -4.4781497120857239e-01
    z[1,2,3]  R588      5.2484970539808273e-02
    z[1,2,3]  R589      -7.0237023464869708e-05
    z[1,2,3]  R590      2.7089977636933327e-02
    z[1,2,3]  R591      1.3784949481487274e-01
    z[1,2,3]  R592      0.0763256624341011
    z[1,2,3]  R593      2.3601779341697693e-01
    z[1,2,3]  R594      2.1000732481479645e-01
    z[1,2,3]  R595      1.4069318771362305e-01
    z[1,2,3]  R596      1.5281075239181519e-01
    z[1,2,3]  R597      3.3632174134254456e-02
    z[1,2,3]  R598      -0.602166473865509
    z[1,2,3]  R599      -2.8964528441429138e-01
    z[1,2,3]  R600      -3.9659479260444641e-01
    z[1,2,3]  R601      -1.0696002095937729e-01
    z[1,2,3]  R602      -1.8552352488040924e-01
    z[1,2,3]  R603      -2.3194706439971924e-01
    z[1,2,3]  R604      -6.7049944400787354e-01
    z[1,2,3]  R605      -6.8894618749618530e-01
    z[1,2,3]  R606      -4.6335729956626892e-01
    z[1,2,3]  R607      4.5260539650917053e-01
    z[1,2,3]  R608      -0.627235472202301
    z[1,2,3]  R609      -3.8507196307182312e-01
    z[1,2,3]  R610      0.0701432153582573
    z[1,2,3]  R611      1.5927150845527649e-02
    z[1,2,3]  R612      2.8033575415611267e-01
    z[1,2,3]  R613      -2.9147097468376160e-01
    z[1,2,3]  R614      -2.4210660159587860e-01
    z[1,2,3]  R615      -6.0953539609909058e-01
    z[1,2,3]  R616      -1.1136322468519211e-01
    z[1,2,3]  R617      -1.5046467073261738e-02
    z[1,2,3]  R618      -5.2768802642822266e-01
    z[1,2,3]  R619      -3.6627539992332458e-01
    z[1,2,3]  R620      -5.4008686542510986e-01
    z[1,2,3]  R621      -0.152797669172287
    z[1,2,3]  R622      1.4392603933811188e-01
    z[1,2,3]  R623      2.5546967983245850e-01
    z[1,2,3]  R624      -6.3771359622478485e-02
    z[1,2,3]  R625      6.0601551085710526e-02
    z[1,2,3]  R626      0.191497340798378
    z[1,2,3]  R627      3.2247364521026611e-01
    z[1,2,3]  R628      -3.7331116199493408e-01
    z[1,2,3]  R629      -4.4019228219985962e-01
    z[1,2,3]  R630      -7.8483417630195618e-02
    z[1,2,3]  R631      -8.9167469739913940e-01
    z[1,2,3]  R632      2.2209782898426056e-01
    z[1,2,3]  R633      4.2631953954696655e-01
    z[1,2,3]  R634      0.506289541721344
    z[1,2,3]  R635      7.1076595783233643e-01
    z[1,2,3]  R636      8.1934696435928345e-01
    z[1,2,3]  R637      7.1757531166076660e-01
    z[1,2,4]  R15       -1
    z[1,2,4]  R24       1
    z[1,2,4]  R532      -1
    z[1,2,4]  R533      1
    z[1,2,4]  R538      5.4618109017610550e-02
    z[1,2,4]  R539      4.3251585960388184e-01
    z[1,2,4]  R540      2.2884850203990936e-01
    z[1,2,4]  R541      1.3395678251981735e-02
    z[1,2,4]  R542      -3.2032021880149841e-01
    z[1,2,4]  R543      -1.6126623749732971e-01
    z[1,2,4]  R544      -1.6589350998401642e-01
    z[1,2,4]  R545      1.5212227404117584e-01
    z[1,2,4]  R546      1.6600900888442993e-01
    z[1,2,4]  R547      -4.0259528160095215e-01
    z[1,2,4]  R548      2.1024408936500549e-01
    z[1,2,4]  R549      3.2547575235366821e-01
    z[1,2,4]  R550      1.2544916570186615e-01
    z[1,2,4]  R551      1.4493545889854431e-01
    z[1,2,4]  R552      -0.635603129863739
    z[1,2,4]  R553      -3.5129398107528687e-01
    z[1,2,4]  R554      3.6472561955451965e-01
    z[1,2,4]  R555      -1.0093870013952255e-01
    z[1,2,4]  R556      -2.8051188588142395e-01
    z[1,2,4]  R557      4.1372036933898926e-01
    z[1,2,4]  R558      -1.8713331222534180e-01
    z[1,2,4]  R559      -9.2841759324073792e-02
    z[1,2,4]  R560      -0.458484411239624
    z[1,2,4]  R561      -2.1331407129764557e-01
    z[1,2,4]  R562      -2.4745023250579834e-01
    z[1,2,4]  R563      -3.6730185151100159e-02
    z[1,2,4]  R564      5.9393906593322754e-01
    z[1,2,4]  R565      1.0587974451482296e-02
    z[1,2,4]  R566      -2.6298624277114868e-01
    z[1,2,4]  R567      -1.3785381615161896e-01
    z[1,2,4]  R568      4.1813701391220093e-01
    z[1,2,4]  R569      -1.7909309267997742e-01
    z[1,2,4]  R570      1.4182345569133759e-01
    z[1,2,4]  R571      -4.0630164742469788e-01
    z[1,2,4]  R572      -4.0135571360588074e-01
    z[1,2,4]  R573      1.4454364776611328e-01
    z[1,2,4]  R574      -4.4148343801498413e-01
    z[1,2,4]  R575      -3.9723706245422363e-01
    z[1,2,4]  R576      1.9270395860075951e-02
    z[1,2,4]  R577      -1.1284729093313217e-01
    z[1,2,4]  R578      -3.5694119334220886e-01
    z[1,2,4]  R579      5.4370075464248657e-01
    z[1,2,4]  R580      1.2318822741508484e-01
    z[1,2,4]  R581      5.1668293774127960e-02
    z[1,2,4]  R582      -3.6304976791143417e-02
    z[1,2,4]  R583      -3.0530476942658424e-03
    z[1,2,4]  R584      -2.2639280557632446e-01
    z[1,2,4]  R585      2.7488246560096741e-01
    z[1,2,4]  R586      9.1593027114868164e-02
    z[1,2,4]  R587      -1.2613105773925781e-01
    z[1,2,4]  R588      -5.8197224140167236e-01
    z[1,2,4]  R589      -3.9051589369773865e-01
    z[1,2,4]  R590      -9.0018799528479576e-03
    z[1,2,4]  R591      2.9724881052970886e-01
    z[1,2,4]  R592      -5.5463850498199463e-02
    z[1,2,4]  R593      9.1593697667121887e-02
    z[1,2,4]  R594      -6.2548726797103882e-01
    z[1,2,4]  R595      -4.9875780940055847e-01
    z[1,2,4]  R596      5.8119124174118042e-01
    z[1,2,4]  R597      4.4617357850074768e-01
    z[1,2,4]  R598      -4.9004080891609192e-01
    z[1,2,4]  R599      -5.6687819957733154e-01
    z[1,2,4]  R600      -4.4454705715179443e-01
    z[1,2,4]  R601      -5.0671774148941040e-01
    z[1,2,4]  R602      -2.9070526361465454e-01
    z[1,2,4]  R603      -8.0801740288734436e-02
    z[1,2,4]  R604      3.3899176120758057e-01
    z[1,2,4]  R605      5.4657596349716187e-01
    z[1,2,4]  R606      4.7412925958633423e-01
    z[1,2,4]  R607      1.3509477674961090e-01
    z[1,2,4]  R608      4.2176067829132080e-01
    z[1,2,4]  R609      2.5802356004714966e-01
    z[1,2,4]  R610      1.1396868526935577e-01
    z[1,2,4]  R611      4.3104812502861023e-01
    z[1,2,4]  R612      3.6857652664184570e-01
    z[1,2,4]  R613      5.6691169738769531e-01
    z[1,2,4]  R614      -2.7196460962295532e-01
    z[1,2,4]  R615      -4.7114729881286621e-01
    z[1,2,4]  R616      3.9963617920875549e-02
    z[1,2,4]  R617      -6.2227261066436768e-01
    z[1,2,4]  R618      3.7327775359153748e-01
    z[1,2,4]  R619      9.4569891691207886e-02
    z[1,2,4]  R620      2.4253083765506744e-01
    z[1,2,4]  R621      -2.1205490827560425e-01
    z[1,2,4]  R622      -2.3234188556671143e-01
    z[1,2,4]  R623      0.0516420416533947
    z[1,2,4]  R624      9.3780837953090668e-02
    z[1,2,4]  R625      1.0123088210821152e-01
    z[1,2,4]  R626      8.4556154906749725e-02
    z[1,2,4]  R627      -2.5497657060623169e-01
    z[1,2,4]  R628      3.2510408759117126e-01
    z[1,2,4]  R629      -7.9041332006454468e-02
    z[1,2,4]  R630      2.0585921406745911e-01
    z[1,2,4]  R631      1.8836686387658119e-02
    z[1,2,4]  R632      1.0669153183698654e-01
    z[1,2,4]  R633      9.9437877535820007e-02
    z[1,2,4]  R634      9.7253829240798950e-02
    z[1,2,4]  R635      -2.5226840376853943e-01
    z[1,2,4]  R636      -1.3433134555816650e-01
    z[1,2,4]  R637      -1.8296252191066742e-01
    z[1,2,5]  R16       -1
    z[1,2,5]  R25       1
    z[1,2,5]  R534      -1
    z[1,2,5]  R535      1
    z[1,2,5]  R538      1.0035312175750732e-01
    z[1,2,5]  R539      1.2102705240249634e-01
    z[1,2,5]  R540      -4.0607705712318420e-01
    z[1,2,5]  R541      -2.6194760575890541e-03
    z[1,2,5]  R542      -4.0177392959594727e-01
    z[1,2,5]  R543      1.4393597841262817e-01
    z[1,2,5]  R544      -2.7187490463256836e-01
    z[1,2,5]  R545      1.6387138515710831e-02
    z[1,2,5]  R546      -3.2049903273582458e-01
    z[1,2,5]  R547      2.6123279333114624e-01
    z[1,2,5]  R548      -6.3597774505615234e-01
    z[1,2,5]  R549      -4.5043057203292847e-01
    z[1,2,5]  R550      3.3822205662727356e-01
    z[1,2,5]  R551      0.0916120857000351
    z[1,2,5]  R552      1.9699060916900635e-01
    z[1,2,5]  R553      -5.8789849281311035e-01
    z[1,2,5]  R554      9.2904157936573029e-02
    z[1,2,5]  R555      -4.9578076601028442e-01
    z[1,2,5]  R556      4.9798467755317688e-01
    z[1,2,5]  R557      -8.7487436830997467e-02
    z[1,2,5]  R558      1.6432522237300873e-01
    z[1,2,5]  R559      -6.0462478548288345e-02
    z[1,2,5]  R560      1.4008009433746338e-01
    z[1,2,5]  R561      3.2220765948295593e-01
    z[1,2,5]  R562      -0.383074551820755
    z[1,2,5]  R563      7.2040760517120361e-01
    z[1,2,5]  R564      1.2024323642253876e-01
    z[1,2,5]  R565      2.5460805743932724e-02
    z[1,2,5]  R566      -3.5921093821525574e-01
    z[1,2,5]  R567      -4.1875803470611572e-01
    z[1,2,5]  R568      2.2691969573497772e-01
    z[1,2,5]  R569      -4.0171968936920166e-01
    z[1,2,5]  R570      6.0343381017446518e-02
    z[1,2,5]  R571      5.5310624837875366e-01
    z[1,2,5]  R572      -0.295651376247406
    z[1,2,5]  R573      -3.4224978089332581e-01
    z[1,2,5]  R574      -7.4231362342834473e-01
    z[1,2,5]  R575      3.2469585537910461e-01
    z[1,2,5]  R576      4.3311398476362228e-02
    z[1,2,5]  R577      1.8013213574886322e-01
    z[1,2,5]  R578      -1.1111732572317123e-01
    z[1,2,5]  R579      -3.4645661711692810e-01
    z[1,2,5]  R580      -2.6786080002784729e-01
    z[1,2,5]  R581      -3.5867077112197876e-01
    z[1,2,5]  R582      -1.2361617386341095e-01
    z[1,2,5]  R583      -4.2112907767295837e-01
    z[1,2,5]  R584      -1.7349600791931152e-01
    z[1,2,5]  R585      3.4701073169708252e-01
    z[1,2,5]  R586      -5.9970027208328247e-01
    z[1,2,5]  R587      -0.366510272026062
    z[1,2,5]  R588      9.0328685939311981e-02
    z[1,2,5]  R589      -5.6349381804466248e-02
    z[1,2,5]  R590      3.5383901000022888e-01
    z[1,2,5]  R591      -1.0622695088386536e-01
    z[1,2,5]  R592      1.7993077635765076e-02
    z[1,2,5]  R593      1.3508167862892151e-01
    z[1,2,5]  R594      -5.8078831434249878e-01
    z[1,2,5]  R595      -7.3170220851898193e-01
    z[1,2,5]  R596      -1.5470009297132492e-02
    z[1,2,5]  R597      1.0067449510097504e-01
    z[1,2,5]  R598      -2.4939297139644623e-01
    z[1,2,5]  R599      -3.7920403480529785e-01
    z[1,2,5]  R600      -4.9990072846412659e-02
    z[1,2,5]  R601      -1.6136933863162994e-01
    z[1,2,5]  R602      2.8091698884963989e-01
    z[1,2,5]  R603      -5.2493721246719360e-01
    z[1,2,5]  R604      1.8734987080097198e-01
    z[1,2,5]  R605      -3.7610962986946106e-01
    z[1,2,5]  R606      1.9069159030914307e-01
    z[1,2,5]  R607      -2.5586915016174316e-01
    z[1,2,5]  R608      -2.5097039341926575e-01
    z[1,2,5]  R609      -1.9765205681324005e-01
    z[1,2,5]  R610      -6.0160171985626221e-01
    z[1,2,5]  R611      -2.4117382243275642e-02
    z[1,2,5]  R612      -6.6142719984054565e-01
    z[1,2,5]  R613      3.8101503252983093e-01
    z[1,2,5]  R614      3.7576174736022949e-01
    z[1,2,5]  R615      2.6153370738029480e-01
    z[1,2,5]  R616      4.3961510062217712e-01
    z[1,2,5]  R617      -9.5619618892669678e-02
    z[1,2,5]  R618      -1.1721321940422058e-01
    z[1,2,5]  R619      5.0972348451614380e-01
    z[1,2,5]  R620      1.9712999463081360e-01
    z[1,2,5]  R621      -2.6369765400886536e-01
    z[1,2,5]  R622      -3.2655301690101624e-01
    z[1,2,5]  R623      2.4778404831886292e-01
    z[1,2,5]  R624      -4.1140198707580566e-02
    z[1,2,5]  R625      -3.0406689271330833e-02
    z[1,2,5]  R626      4.0036982297897339e-01
    z[1,2,5]  R627      -9.0188682079315186e-02
    z[1,2,5]  R628      -6.9940364360809326e-01
    z[1,2,5]  R629      -7.6825064420700073e-01
    z[1,2,5]  R630      3.1678438186645508e-01
    z[1,2,5]  R631      2.7540540695190430e-01
    z[1,2,5]  R632      3.7043631076812744e-01
    z[1,2,5]  R633      2.2858747839927673e-01
    z[1,2,5]  R634      -1.5789978206157684e-01
    z[1,2,5]  R635      5.8064174652099609e-01
    z[1,2,5]  R636      5.2196395397186279e-01
    z[1,2,5]  R637      0.578454852104187
    z[1,2,6]  R17       -1
    z[1,2,6]  R26       1
    z[1,2,6]  R536      -1
    z[1,2,6]  R537      1
    z[1,2,6]  R538      -2.4538420140743256e-02
    z[1,2,6]  R539      0.297335684299469
    z[1,2,6]  R540      3.4954464435577393e-01
    z[1,2,6]  R541      2.2817702591419220e-01
    z[1,2,6]  R542      1.5097934752702713e-02
    z[1,2,6]  R543      -6.1416542530059814e-01
    z[1,2,6]  R544      3.6751002073287964e-01
    z[1,2,6]  R545      -6.2844090163707733e-02
    z[1,2,6]  R546      -6.7511671781539917e-01
    z[1,2,6]  R547      2.4829532206058502e-01
    z[1,2,6]  R548      -2.0460508763790131e-01
    z[1,2,6]  R549      -1.0036907345056534e-01
    z[1,2,6]  R550      1.7019617557525635e-01
    z[1,2,6]  R551      2.3270641267299652e-01
    z[1,2,6]  R552      3.9491218328475952e-01
    z[1,2,6]  R553      2.4653873406350613e-03
    z[1,2,6]  R554      -1.9103090465068817e-01
    z[1,2,6]  R555      3.7120506167411804e-01
    z[1,2,6]  R556      -1.0990805923938751e-01
    z[1,2,6]  R557      3.8752806186676025e-01
    z[1,2,6]  R558      -1.4466822147369385e-01
    z[1,2,6]  R559      4.0550419688224792e-01
    z[1,2,6]  R560      -4.9038353562355042e-01
    z[1,2,6]  R561      3.4836760163307190e-01
    z[1,2,6]  R562      -2.1705206483602524e-02
    z[1,2,6]  R563      -4.6356637030839920e-02
    z[1,2,6]  R564      1.6067904233932495e-01
    z[1,2,6]  R565      7.2418713569641113e-01
    z[1,2,6]  R566      -2.4380896985530853e-01
    z[1,2,6]  R567      -6.6189341247081757e-02
    z[1,2,6]  R568      -8.9187301695346832e-02
    z[1,2,6]  R569      -4.8660197854042053e-01
    z[1,2,6]  R570      -1.1435898393392563e-01
    z[1,2,6]  R571      1.1933930218219757e-01
    z[1,2,6]  R572      4.5157539844512939e-01
    z[1,2,6]  R573      -1.1630688607692719e-01
    z[1,2,6]  R574      -1.7178329825401306e-01
    z[1,2,6]  R575      -6.2800779938697815e-02
    z[1,2,6]  R576      2.2420226037502289e-01
    z[1,2,6]  R577      3.5451132059097290e-01
    z[1,2,6]  R578      -1.1575453728437424e-01
    z[1,2,6]  R579      -7.3043704032897949e-02
    z[1,2,6]  R580      -4.1478082537651062e-01
    z[1,2,6]  R581      -2.0926142111420631e-02
    z[1,2,6]  R582      -7.0083987712860107e-01
    z[1,2,6]  R583      1.6672931611537933e-01
    z[1,2,6]  R584      -0.542167603969574
    z[1,2,6]  R585      6.3620530068874359e-02
    z[1,2,6]  R586      -7.9978398978710175e-02
    z[1,2,6]  R587      -5.3863030672073364e-01
    z[1,2,6]  R588      -1.8201902508735657e-01
    z[1,2,6]  R589      7.3884904384613037e-01
    z[1,2,6]  R590      4.8412540555000305e-01
    z[1,2,6]  R591      5.8973014354705811e-01
    z[1,2,6]  R592      3.5702344775199890e-01
    z[1,2,6]  R593      6.3501638174057007e-01
    z[1,2,6]  R594      4.4806458055973053e-02
    z[1,2,6]  R595      1.7744249105453491e-01
    z[1,2,6]  R596      4.4641438126564026e-01
    z[1,2,6]  R597      7.2661107778549194e-01
    z[1,2,6]  R598      -2.1608068048954010e-01
    z[1,2,6]  R599      -0.0524955689907074
    z[1,2,6]  R600      -1.0785356909036636e-01
    z[1,2,6]  R601      4.3899369239807129e-01
    z[1,2,6]  R602      -1.1953758448362350e-01
    z[1,2,6]  R603      -1.1923612095415592e-02
    z[1,2,6]  R604      4.0497392416000366e-01
    z[1,2,6]  R605      2.3242910206317902e-01
    z[1,2,6]  R606      2.7324414253234863e-01
    z[1,2,6]  R607      2.2052489221096039e-02
    z[1,2,6]  R608      3.2474055886268616e-02
    z[1,2,6]  R609      3.3998188376426697e-01
    z[1,2,6]  R610      -1.4878799021244049e-01
    z[1,2,6]  R611      6.0695850849151611e-01
    z[1,2,6]  R612      1.2342663109302521e-01
    z[1,2,6]  R613      -5.0115519762039185e-01
    z[1,2,6]  R614      -4.7997005283832550e-02
    z[1,2,6]  R615      -3.2024788856506348e-01
    z[1,2,6]  R616      -2.0141196250915527e-01
    z[1,2,6]  R617      5.0863599777221680e-01
    z[1,2,6]  R618      2.7666044235229492e-01
    z[1,2,6]  R619      -8.1315249204635620e-02
    z[1,2,6]  R620      -0.344471275806427
    z[1,2,6]  R621      5.9897238016128540e-01
    z[1,2,6]  R622      -1.0502582043409348e-01
    z[1,2,6]  R623      -5.3841298818588257e-01
    z[1,2,6]  R624      1.1015736311674118e-01
    z[1,2,6]  R625      -1.4831455051898956e-01
    z[1,2,6]  R626      5.0073593854904175e-02
    z[1,2,6]  R627      5.9780506417155266e-03
    z[1,2,6]  R628      -2.4168142676353455e-01
    z[1,2,6]  R629      1.7247229814529419e-01
    z[1,2,6]  R630      7.9172827303409576e-02
    z[1,2,6]  R631      2.4253658950328827e-01
    z[1,2,6]  R632      2.8019472956657410e-01
    z[1,2,6]  R633      -3.3731141686439514e-01
    z[1,2,6]  R634      -5.1452624797821045e-01
    z[1,2,6]  R635      2.3528663814067841e-01
    z[1,2,6]  R636      3.3454321324825287e-02
    z[1,2,6]  R637      2.6520317792892456e-01
    z[2,1,0]  R11       1
    z[2,1,0]  R20       -1
    z[2,1,0]  R638      -1
    z[2,1,0]  R639      1
    z[2,1,0]  R652      -4.6003714203834534e-01
    z[2,1,0]  R653      -8.5073653608560562e-03
    z[2,1,0]  R654      -5.5655580759048462e-01
    z[2,1,0]  R655      -4.1328959167003632e-02
    z[2,1,0]  R656      1.8384875357151031e-01
    z[2,1,0]  R657      -6.8432295322418213e-01
    z[2,1,0]  R658      -4.3920648097991943e-01
    z[2,1,0]  R659      -2.7425637841224670e-01
    z[2,1,0]  R660      -3.9826804399490356e-01
    z[2,1,0]  R661      3.2798236608505249e-01
    z[2,1,0]  R662      1.9804461300373077e-01
    z[2,1,0]  R663      -7.2348743677139282e-02
    z[2,1,0]  R664      -1.7537489533424377e-02
    z[2,1,0]  R665      0.292106568813324
    z[2,1,0]  R666      0.402878999710083
    z[2,1,0]  R667      -1.2381814420223236e-01
    z[2,1,0]  R668      -2.3071540892124176e-01
    z[2,1,0]  R669      7.0579960942268372e-02
    z[2,1,0]  R670      3.9821188896894455e-02
    z[2,1,0]  R671      -6.1034295707941055e-02
    z[2,1,0]  R672      -1.8003901839256287e-01
    z[2,1,0]  R673      -1.5587781369686127e-01
    z[2,1,0]  R674      1.8529336154460907e-01
    z[2,1,0]  R675      -8.3421230316162109e-02
    z[2,1,0]  R676      -3.2203629612922668e-01
    z[2,1,0]  R677      -4.6948346495628357e-01
    z[2,1,0]  R678      -4.3462562561035156e-01
    z[2,1,0]  R679      -1.4304748177528381e-01
    z[2,1,0]  R680      1.8365567922592163e-01
    z[2,1,0]  R681      -2.8893113136291504e-02
    z[2,1,0]  R682      -3.8958737254142761e-01
    z[2,1,0]  R683      -6.8815350532531738e-02
    z[2,1,0]  R684      2.4270290136337280e-01
    z[2,1,0]  R685      -0.233124777674675
    z[2,1,0]  R686      -2.7780758216977119e-02
    z[2,1,0]  R687      -9.1728426516056061e-02
    z[2,1,0]  R688      1.5637844800949097e-01
    z[2,1,0]  R689      1.3719514012336731e-01
    z[2,1,0]  R690      2.9046159982681274e-01
    z[2,1,0]  R691      -4.0357176214456558e-02
    z[2,1,0]  R692      -0.00798717699944973
    z[2,1,0]  R693      -3.9652702212333679e-01
    z[2,1,0]  R694      2.3141847550868988e-01
    z[2,1,0]  R695      -1.4708544313907623e-01
    z[2,1,0]  R696      2.6743856072425842e-01
    z[2,1,0]  R697      1.0477688163518906e-01
    z[2,1,0]  R698      3.3715635538101196e-01
    z[2,1,0]  R699      4.3467298150062561e-01
    z[2,1,0]  R700      2.1802544593811035e-01
    z[2,1,0]  R701      3.1608527898788452e-01
    z[2,1,0]  R702      -7.1441113948822021e-02
    z[2,1,0]  R703      -1.0171761363744736e-01
    z[2,1,0]  R704      2.2076368331909180e-01
    z[2,1,0]  R705      -4.1067633777856827e-02
    z[2,1,0]  R706      -1.7654503881931305e-01
    z[2,1,0]  R707      1.7004080116748810e-01
    z[2,1,0]  R708      -7.1844369173049927e-02
    z[2,1,0]  R709      1.2535277009010315e-01
    z[2,1,0]  R710      6.0810748487710953e-02
    z[2,1,0]  R711      -1.0493205487728119e-01
    z[2,1,0]  R712      -6.8537926673889160e-01
    z[2,1,0]  R713      -6.1989778280258179e-01
    z[2,1,0]  R714      -3.9015492796897888e-01
    z[2,1,0]  R715      -7.6221138238906860e-01
    z[2,1,0]  R716      -7.7940732240676880e-01
    z[2,1,0]  R717      6.3415724039077759e-01
    z[2,1,0]  R718      -2.0341657102108002e-01
    z[2,1,0]  R719      8.5822738707065582e-02
    z[2,1,0]  R720      7.1230880916118622e-02
    z[2,1,0]  R721      -6.0418337583541870e-02
    z[2,1,0]  R722      3.2008466124534607e-01
    z[2,1,0]  R723      4.0764841437339783e-01
    z[2,1,0]  R724      4.9026329070329666e-03
    z[2,1,0]  R725      8.2191802561283112e-02
    z[2,1,0]  R726      0.0870785117149353
    z[2,1,0]  R727      2.6003026962280273e-01
    z[2,1,0]  R728      5.3831964731216431e-01
    z[2,1,0]  R729      1.6848705708980560e-01
    z[2,1,0]  R730      1.2245961278676987e-01
    z[2,1,0]  R731      4.3266189098358154e-01
    z[2,1,0]  R732      -1.7281191051006317e-01
    z[2,1,0]  R733      3.7440863251686096e-01
    z[2,1,0]  R734      -8.8296726346015930e-02
    z[2,1,0]  R735      -8.5912920534610748e-02
    z[2,1,0]  R736      -8.5435574874281883e-03
    z[2,1,0]  R737      5.6546766310930252e-02
    z[2,1,0]  R738      4.1534101963043213e-01
    z[2,1,0]  R739      -9.5797730609774590e-03
    z[2,1,0]  R740      1.6904467344284058e-01
    z[2,1,0]  R741      9.3381822109222412e-02
    z[2,1,0]  R742      3.4843999147415161e-01
    z[2,1,0]  R743      1.5935826301574707e-01
    z[2,1,0]  R744      2.6861077547073364e-01
    z[2,1,0]  R745      1.4243774116039276e-01
    z[2,1,0]  R746      3.2409456372261047e-01
    z[2,1,0]  R747      4.6643380075693130e-02
    z[2,1,0]  R748      2.9713290929794312e-01
    z[2,1,0]  R749      1.7995053529739380e-01
    z[2,1,0]  R750      4.1195189952850342e-01
    z[2,1,0]  R751      -7.0935539901256561e-02
    z[2,1,1]  R12       1
    z[2,1,1]  R21       -1
    z[2,1,1]  R640      -1
    z[2,1,1]  R641      1
    z[2,1,1]  R652      -1.2009544670581818e-01
    z[2,1,1]  R653      -8.1751078367233276e-02
    z[2,1,1]  R654      -1.1944067478179932e-01
    z[2,1,1]  R655      4.1970473527908325e-01
    z[2,1,1]  R656      2.8386149555444717e-02
    z[2,1,1]  R657      -3.3588859438896179e-01
    z[2,1,1]  R658      -3.5688936710357666e-01
    z[2,1,1]  R659      -1.0904785245656967e-01
    z[2,1,1]  R660      2.6019543409347534e-01
    z[2,1,1]  R661      3.2960599660873413e-01
    z[2,1,1]  R662      0.310889333486557
    z[2,1,1]  R663      3.6694172024726868e-01
    z[2,1,1]  R664      2.3732134699821472e-01
    z[2,1,1]  R665      6.3886421918869019e-01
    z[2,1,1]  R666      7.7943336963653564e-01
    z[2,1,1]  R667      -6.4054572582244873e-01
    z[2,1,1]  R668      -3.4550639986991882e-01
    z[2,1,1]  R669      1.6194467246532440e-01
    z[2,1,1]  R670      1.1359908431768417e-01
    z[2,1,1]  R671      2.0492841303348541e-01
    z[2,1,1]  R672      -7.6640337705612183e-02
    z[2,1,1]  R673      -3.9700353145599365e-01
    z[2,1,1]  R674      1.8615961074829102e-01
    z[2,1,1]  R675      -2.4497555196285248e-01
    z[2,1,1]  R676      -4.1259798407554626e-01
    z[2,1,1]  R677      -6.4995211362838745e-01
    z[2,1,1]  R678      -2.0629326999187469e-01
    z[2,1,1]  R679      3.5990167409181595e-02
    z[2,1,1]  R680      5.4702192544937134e-01
    z[2,1,1]  R681      -2.8597798943519592e-01
    z[2,1,1]  R682      -4.1062659025192261e-01
    z[2,1,1]  R683      1.3161525130271912e-01
    z[2,1,1]  R684      1.3473476469516754e-01
    z[2,1,1]  R685      -7.6633952558040619e-02
    z[2,1,1]  R686      -2.4065822362899780e-01
    z[2,1,1]  R687      -3.3735689520835876e-01
    z[2,1,1]  R688      4.1433599591255188e-01
    z[2,1,1]  R689      3.6250334978103638e-01
    z[2,1,1]  R690      4.3162074685096741e-01
    z[2,1,1]  R691      2.9725155234336853e-01
    z[2,1,1]  R692      2.8470417857170105e-01
    z[2,1,1]  R693      -4.2697837948799133e-01
    z[2,1,1]  R694      3.6318513751029968e-01
    z[2,1,1]  R695      1.9550137221813202e-01
    z[2,1,1]  R696      3.1546348333358765e-01
    z[2,1,1]  R697      -1.8552072346210480e-01
    z[2,1,1]  R698      -9.1899514198303223e-01
    z[2,1,1]  R699      -8.7285065650939941e-01
    z[2,1,1]  R700      -8.4027677774429321e-01
    z[2,1,1]  R701      -8.3648532629013062e-01
    z[2,1,1]  R702      -2.1401226520538330e-01
    z[2,1,1]  R703      5.2057977765798569e-02
    z[2,1,1]  R704      4.2800846695899963e-01
    z[2,1,1]  R705      2.6091209053993225e-01
    z[2,1,1]  R706      -8.2916563749313354e-01
    z[2,1,1]  R707      -7.2809213399887085e-01
    z[2,1,1]  R708      -6.6152030229568481e-01
    z[2,1,1]  R709      1.5068809688091278e-01
    z[2,1,1]  R710      -1.2697984278202057e-01
    z[2,1,1]  R711      -1.8668781220912933e-01
    z[2,1,1]  R712      0.0571502223610878
    z[2,1,1]  R713      -1.4520107768476009e-02
    z[2,1,1]  R714      5.2287089824676514e-01
    z[2,1,1]  R715      1.9970615208148956e-01
    z[2,1,1]  R716      -1.5222278423607349e-02
    z[2,1,1]  R717      -3.3910888433456421e-01
    z[2,1,1]  R718      1.7417545616626740e-01
    z[2,1,1]  R719      4.5699110627174377e-01
    z[2,1,1]  R720      2.8019109368324280e-01
    z[2,1,1]  R721      6.7615598440170288e-01
    z[2,1,1]  R722      -4.2932316660881042e-01
    z[2,1,1]  R723      -5.7425397634506226e-01
    z[2,1,1]  R724      -6.2131518125534058e-01
    z[2,1,1]  R725      -7.5799202919006348e-01
    z[2,1,1]  R726      -5.5511152744293213e-01
    z[2,1,1]  R727      -5.6249588727951050e-01
    z[2,1,1]  R728      -6.5417569875717163e-01
    z[2,1,1]  R729      -5.1269501447677612e-01
    z[2,1,1]  R730      -4.8968937993049622e-01
    z[2,1,1]  R731      -4.9344503879547119e-01
    z[2,1,1]  R732      -8.4892296791076660e-01
    z[2,1,1]  R733      -7.8575527667999268e-01
    z[2,1,1]  R734      -7.1145397424697876e-01
    z[2,1,1]  R735      -7.1247613430023193e-01
    z[2,1,1]  R736      -6.9293183088302612e-01
    z[2,1,1]  R737      -6.3465994596481323e-01
    z[2,1,1]  R738      -0.61861252784729
    z[2,1,1]  R739      -5.3537541627883911e-01
    z[2,1,1]  R740      0.595018208026886
    z[2,1,1]  R741      4.8361852765083313e-01
    z[2,1,1]  R742      -7.9290562868118286e-01
    z[2,1,1]  R743      -6.0925519466400146e-01
    z[2,1,1]  R744      -0.825687050819397
    z[2,1,1]  R745      -0.647787868976593
    z[2,1,1]  R746      6.7067429423332214e-02
    z[2,1,1]  R747      -3.6139285564422607e-01
    z[2,1,1]  R748      -3.7306267768144608e-02
    z[2,1,1]  R749      4.8320105671882629e-01
    z[2,1,1]  R750      3.7311285734176636e-01
    z[2,1,1]  R751      5.6233358383178711e-01
    z[2,1,2]  R13       1
    z[2,1,2]  R22       -1
    z[2,1,2]  R642      -1
    z[2,1,2]  R643      1
    z[2,1,2]  R652      -1.4356851577758789e-01
    z[2,1,2]  R653      0.729804277420044
    z[2,1,2]  R654      -2.6146861910820007e-01
    z[2,1,2]  R655      -3.0947241187095642e-01
    z[2,1,2]  R656      -5.2568817138671875e-01
    z[2,1,2]  R657      -4.1015830636024475e-01
    z[2,1,2]  R658      -2.6602697372436523e-01
    z[2,1,2]  R659      5.3871631622314453e-01
    z[2,1,2]  R660      -1.6271330416202545e-01
    z[2,1,2]  R661      -3.7800505757331848e-01
    z[2,1,2]  R662      0.69382244348526
    z[2,1,2]  R663      3.9817529916763306e-01
    z[2,1,2]  R664      -7.6352918148040771e-01
    z[2,1,2]  R665      2.0025306940078735e-01
    z[2,1,2]  R666      3.0574655532836914e-01
    z[2,1,2]  R667      2.9796570539474487e-01
    z[2,1,2]  R668      2.2964215278625488e-01
    z[2,1,2]  R669      3.6519104242324829e-01
    z[2,1,2]  R670      -6.5180528163909912e-01
    z[2,1,2]  R671      -4.6473458409309387e-01
    z[2,1,2]  R672      5.0008010864257812e-01
    z[2,1,2]  R673      5.1603639125823975e-01
    z[2,1,2]  R674      7.4964660406112671e-01
    z[2,1,2]  R675      6.6788399219512939e-01
    z[2,1,2]  R676      -7.1688455343246460e-01
    z[2,1,2]  R677      1.4531970024108887e-01
    z[2,1,2]  R678      -7.0390887558460236e-02
    z[2,1,2]  R679      -9.6790179610252380e-02
    z[2,1,2]  R680      3.4134072065353394e-01
    z[2,1,2]  R681      -7.9266905784606934e-01
    z[2,1,2]  R682      2.1038149297237396e-01
    z[2,1,2]  R683      -7.8002011775970459e-01
    z[2,1,2]  R684      -7.2178280353546143e-01
    z[2,1,2]  R685      6.2027710676193237e-01
    z[2,1,2]  R686      -5.2359807491302490e-01
    z[2,1,2]  R687      2.7404937148094177e-01
    z[2,1,2]  R688      7.2649180889129639e-01
    z[2,1,2]  R689      -2.9205662012100220e-01
    z[2,1,2]  R690      6.9390803575515747e-01
    z[2,1,2]  R691      -0.504687488079071
    z[2,1,2]  R692      6.4094376564025879e-01
    z[2,1,2]  R693      5.0092363357543945e-01
    z[2,1,2]  R694      5.5363011360168457e-01
    z[2,1,2]  R695      6.6597777605056763e-01
    z[2,1,2]  R696      7.9786878824234009e-01
    z[2,1,2]  R697      7.3170125484466553e-01
    z[2,1,2]  R698      -1.2281985580921173e-01
    z[2,1,2]  R699      1.1112658679485321e-01
    z[2,1,2]  R700      1.9943784177303314e-01
    z[2,1,2]  R701      -1.5234960615634918e-01
    z[2,1,2]  R702      3.9555743336677551e-01
    z[2,1,2]  R703      4.0862086415290833e-01
    z[2,1,2]  R704      7.8288817405700684e-01
    z[2,1,2]  R705      -1.1294302530586720e-02
    z[2,1,2]  R706      -6.9810695946216583e-02
    z[2,1,2]  R707      -2.8861811757087708e-01
    z[2,1,2]  R708      4.2097836732864380e-02
    z[2,1,2]  R709      1.5735620632767677e-02
    z[2,1,2]  R710      -0.131294846534729
    z[2,1,2]  R711      2.8363198041915894e-02
    z[2,1,2]  R712      3.3827850222587585e-01
    z[2,1,2]  R713      2.6897537708282471e-01
    z[2,1,2]  R714      4.7927427291870117e-01
    z[2,1,2]  R715      5.6895589828491211e-01
    z[2,1,2]  R716      3.1550264358520508e-01
    z[2,1,2]  R717      2.3017936944961548e-01
    z[2,1,2]  R718      -8.0488801002502441e-01
    z[2,1,2]  R719      -6.7732048034667969e-01
    z[2,1,2]  R720      -5.6877499818801880e-01
    z[2,1,2]  R721      -4.7535607218742371e-01
    z[2,1,2]  R722      4.1857668757438660e-01
    z[2,1,2]  R723      7.0329317823052406e-03
    z[2,1,2]  R724      2.1478319168090820e-01
    z[2,1,2]  R725      -3.4359315037727356e-01
    z[2,1,2]  R726      -2.9130160808563232e-01
    z[2,1,2]  R727      -0.227743998169899
    z[2,1,2]  R728      -1.8006688356399536e-01
    z[2,1,2]  R729      2.9676848649978638e-01
    z[2,1,2]  R730      -5.0348842144012451e-01
    z[2,1,2]  R731      -4.6433243155479431e-01
    z[2,1,2]  R732      -4.0656253695487976e-01
    z[2,1,2]  R733      1.4423318207263947e-01
    z[2,1,2]  R734      1.1157031171023846e-02
    z[2,1,2]  R735      4.5995819568634033e-01
    z[2,1,2]  R736      7.3543138802051544e-02
    z[2,1,2]  R737      -1.3757381588220596e-02
    z[2,1,2]  R738      1.4972053468227386e-01
    z[2,1,2]  R739      -4.3314412236213684e-01
    z[2,1,2]  R740      -3.6220791935920715e-01
    z[2,1,2]  R741      -5.7210975885391235e-01
    z[2,1,2]  R742      8.0398945137858391e-03
    z[2,1,2]  R743      3.2255479693412781e-01
    z[2,1,2]  R744      3.1184738874435425e-01
    z[2,1,2]  R745      2.2299650311470032e-01
    z[2,1,2]  R746      1.6216664016246796e-01
    z[2,1,2]  R747      -4.9299055337905884e-01
    z[2,1,2]  R748      8.9813880622386932e-02
    z[2,1,2]  R749      -6.4932525157928467e-01
    z[2,1,2]  R750      -0.747498095035553
    z[2,1,2]  R751      -6.4216977357864380e-01
    z[2,1,3]  R14       1
    z[2,1,3]  R23       -1
    z[2,1,3]  R644      -1
    z[2,1,3]  R645      1
    z[2,1,3]  R652      -7.7471143007278442e-01
    z[2,1,3]  R653      -1.9912803173065186e-01
    z[2,1,3]  R654      -5.9046244621276855e-01
    z[2,1,3]  R655      -7.7111244201660156e-01
    z[2,1,3]  R656      -4.2575830221176147e-01
    z[2,1,3]  R657      -2.1329177916049957e-01
    z[2,1,3]  R658      -4.8338085412979126e-01
    z[2,1,3]  R659      -0.650117039680481
    z[2,1,3]  R660      -6.1055636405944824e-01
    z[2,1,3]  R661      -4.4781497120857239e-01
    z[2,1,3]  R662      5.2484970539808273e-02
    z[2,1,3]  R663      -7.0237023464869708e-05
    z[2,1,3]  R664      2.7089977636933327e-02
    z[2,1,3]  R665      1.3784949481487274e-01
    z[2,1,3]  R666      0.0763256624341011
    z[2,1,3]  R667      2.3601779341697693e-01
    z[2,1,3]  R668      2.1000732481479645e-01
    z[2,1,3]  R669      1.4069318771362305e-01
    z[2,1,3]  R670      1.5281075239181519e-01
    z[2,1,3]  R671      3.3632174134254456e-02
    z[2,1,3]  R672      -0.602166473865509
    z[2,1,3]  R673      -2.8964528441429138e-01
    z[2,1,3]  R674      -3.9659479260444641e-01
    z[2,1,3]  R675      -1.0696002095937729e-01
    z[2,1,3]  R676      -1.8552352488040924e-01
    z[2,1,3]  R677      -2.3194706439971924e-01
    z[2,1,3]  R678      -6.7049944400787354e-01
    z[2,1,3]  R679      -6.8894618749618530e-01
    z[2,1,3]  R680      -4.6335729956626892e-01
    z[2,1,3]  R681      4.5260539650917053e-01
    z[2,1,3]  R682      -0.627235472202301
    z[2,1,3]  R683      -3.8507196307182312e-01
    z[2,1,3]  R684      0.0701432153582573
    z[2,1,3]  R685      1.5927150845527649e-02
    z[2,1,3]  R686      2.8033575415611267e-01
    z[2,1,3]  R687      -2.9147097468376160e-01
    z[2,1,3]  R688      -2.4210660159587860e-01
    z[2,1,3]  R689      -6.0953539609909058e-01
    z[2,1,3]  R690      -1.1136322468519211e-01
    z[2,1,3]  R691      -1.5046467073261738e-02
    z[2,1,3]  R692      -5.2768802642822266e-01
    z[2,1,3]  R693      -3.6627539992332458e-01
    z[2,1,3]  R694      -5.4008686542510986e-01
    z[2,1,3]  R695      -0.152797669172287
    z[2,1,3]  R696      1.4392603933811188e-01
    z[2,1,3]  R697      2.5546967983245850e-01
    z[2,1,3]  R698      -6.3771359622478485e-02
    z[2,1,3]  R699      6.0601551085710526e-02
    z[2,1,3]  R700      0.191497340798378
    z[2,1,3]  R701      3.2247364521026611e-01
    z[2,1,3]  R702      -3.7331116199493408e-01
    z[2,1,3]  R703      -4.4019228219985962e-01
    z[2,1,3]  R704      -7.8483417630195618e-02
    z[2,1,3]  R705      -8.9167469739913940e-01
    z[2,1,3]  R706      2.2209782898426056e-01
    z[2,1,3]  R707      4.2631953954696655e-01
    z[2,1,3]  R708      0.506289541721344
    z[2,1,3]  R709      7.1076595783233643e-01
    z[2,1,3]  R710      8.1934696435928345e-01
    z[2,1,3]  R711      7.1757531166076660e-01
    z[2,1,3]  R712      -6.3158601522445679e-01
    z[2,1,3]  R713      -5.0303298234939575e-01
    z[2,1,3]  R714      -7.2316408157348633e-02
    z[2,1,3]  R715      -5.6475561112165451e-02
    z[2,1,3]  R716      -1.6880510747432709e-01
    z[2,1,3]  R717      -7.7094823122024536e-02
    z[2,1,3]  R718      2.0961783826351166e-01
    z[2,1,3]  R719      -5.4559266567230225e-01
    z[2,1,3]  R720      -8.2782298326492310e-02
    z[2,1,3]  R721      -1.4568190276622772e-01
    z[2,1,3]  R722      -2.1791622042655945e-01
    z[2,1,3]  R723      -4.3024352192878723e-01
    z[2,1,3]  R724      6.3930678367614746e-01
    z[2,1,3]  R725      4.6592387557029724e-01
    z[2,1,3]  R726      -2.5682101026177406e-02
    z[2,1,3]  R727      -3.0834561586380005e-01
    z[2,1,3]  R728      -2.6775610446929932e-01
    z[2,1,3]  R729      4.7634443640708923e-01
    z[2,1,3]  R730      3.9109072089195251e-01
    z[2,1,3]  R731      -1.5720802545547485e-01
    z[2,1,3]  R732      -3.4958653151988983e-02
    z[2,1,3]  R733      -2.1188369393348694e-01
    z[2,1,3]  R734      -1.2492434680461884e-01
    z[2,1,3]  R735      5.2482996135950089e-02
    z[2,1,3]  R736      5.5309587717056274e-01
    z[2,1,3]  R737      -2.6708588004112244e-01
    z[2,1,3]  R738      1.7133103311061859e-01
    z[2,1,3]  R739      2.1449856460094452e-02
    z[2,1,3]  R740      -4.7806450724601746e-01
    z[2,1,3]  R741      -4.8097869753837585e-01
    z[2,1,3]  R742      -1.2466013431549072e-01
    z[2,1,3]  R743      -2.6293888688087463e-01
    z[2,1,3]  R744      3.3467465639114380e-01
    z[2,1,3]  R745      1.5844729542732239e-01
    z[2,1,3]  R746      -6.4167755842208862e-01
    z[2,1,3]  R747      -6.8747711181640625e-01
    z[2,1,3]  R748      -3.5609990358352661e-01
    z[2,1,3]  R749      2.1293807029724121e-01
    z[2,1,3]  R750      2.8251573443412781e-01
    z[2,1,3]  R751      3.0904152989387512e-01
    z[2,1,4]  R15       1
    z[2,1,4]  R24       -1
    z[2,1,4]  R646      -1
    z[2,1,4]  R647      1
    z[2,1,4]  R652      -3.5694119334220886e-01
    z[2,1,4]  R653      5.4370075464248657e-01
    z[2,1,4]  R654      1.2318822741508484e-01
    z[2,1,4]  R655      5.1668293774127960e-02
    z[2,1,4]  R656      -3.6304976791143417e-02
    z[2,1,4]  R657      -3.0530476942658424e-03
    z[2,1,4]  R658      -2.2639280557632446e-01
    z[2,1,4]  R659      2.7488246560096741e-01
    z[2,1,4]  R660      9.1593027114868164e-02
    z[2,1,4]  R661      -1.2613105773925781e-01
    z[2,1,4]  R662      -5.8197224140167236e-01
    z[2,1,4]  R663      -3.9051589369773865e-01
    z[2,1,4]  R664      -9.0018799528479576e-03
    z[2,1,4]  R665      2.9724881052970886e-01
    z[2,1,4]  R666      -5.5463850498199463e-02
    z[2,1,4]  R667      9.1593697667121887e-02
    z[2,1,4]  R668      -6.2548726797103882e-01
    z[2,1,4]  R669      -4.9875780940055847e-01
    z[2,1,4]  R670      5.8119124174118042e-01
    z[2,1,4]  R671      4.4617357850074768e-01
    z[2,1,4]  R672      -4.9004080891609192e-01
    z[2,1,4]  R673      -5.6687819957733154e-01
    z[2,1,4]  R674      -4.4454705715179443e-01
    z[2,1,4]  R675      -5.0671774148941040e-01
    z[2,1,4]  R676      -2.9070526361465454e-01
    z[2,1,4]  R677      -8.0801740288734436e-02
    z[2,1,4]  R678      3.3899176120758057e-01
    z[2,1,4]  R679      5.4657596349716187e-01
    z[2,1,4]  R680      4.7412925958633423e-01
    z[2,1,4]  R681      1.3509477674961090e-01
    z[2,1,4]  R682      4.2176067829132080e-01
    z[2,1,4]  R683      2.5802356004714966e-01
    z[2,1,4]  R684      1.1396868526935577e-01
    z[2,1,4]  R685      4.3104812502861023e-01
    z[2,1,4]  R686      3.6857652664184570e-01
    z[2,1,4]  R687      5.6691169738769531e-01
    z[2,1,4]  R688      -2.7196460962295532e-01
    z[2,1,4]  R689      -4.7114729881286621e-01
    z[2,1,4]  R690      3.9963617920875549e-02
    z[2,1,4]  R691      -6.2227261066436768e-01
    z[2,1,4]  R692      3.7327775359153748e-01
    z[2,1,4]  R693      9.4569891691207886e-02
    z[2,1,4]  R694      2.4253083765506744e-01
    z[2,1,4]  R695      -2.1205490827560425e-01
    z[2,1,4]  R696      -2.3234188556671143e-01
    z[2,1,4]  R697      0.0516420416533947
    z[2,1,4]  R698      9.3780837953090668e-02
    z[2,1,4]  R699      1.0123088210821152e-01
    z[2,1,4]  R700      8.4556154906749725e-02
    z[2,1,4]  R701      -2.5497657060623169e-01
    z[2,1,4]  R702      3.2510408759117126e-01
    z[2,1,4]  R703      -7.9041332006454468e-02
    z[2,1,4]  R704      2.0585921406745911e-01
    z[2,1,4]  R705      1.8836686387658119e-02
    z[2,1,4]  R706      1.0669153183698654e-01
    z[2,1,4]  R707      9.9437877535820007e-02
    z[2,1,4]  R708      9.7253829240798950e-02
    z[2,1,4]  R709      -2.5226840376853943e-01
    z[2,1,4]  R710      -1.3433134555816650e-01
    z[2,1,4]  R711      -1.8296252191066742e-01
    z[2,1,4]  R712      5.4618109017610550e-02
    z[2,1,4]  R713      4.3251585960388184e-01
    z[2,1,4]  R714      2.2884850203990936e-01
    z[2,1,4]  R715      1.3395678251981735e-02
    z[2,1,4]  R716      -3.2032021880149841e-01
    z[2,1,4]  R717      -1.6126623749732971e-01
    z[2,1,4]  R718      -1.6589350998401642e-01
    z[2,1,4]  R719      1.5212227404117584e-01
    z[2,1,4]  R720      1.6600900888442993e-01
    z[2,1,4]  R721      -4.0259528160095215e-01
    z[2,1,4]  R722      2.1024408936500549e-01
    z[2,1,4]  R723      3.2547575235366821e-01
    z[2,1,4]  R724      1.2544916570186615e-01
    z[2,1,4]  R725      1.4493545889854431e-01
    z[2,1,4]  R726      -0.635603129863739
    z[2,1,4]  R727      -3.5129398107528687e-01
    z[2,1,4]  R728      3.6472561955451965e-01
    z[2,1,4]  R729      -1.0093870013952255e-01
    z[2,1,4]  R730      -2.8051188588142395e-01
    z[2,1,4]  R731      4.1372036933898926e-01
    z[2,1,4]  R732      -1.8713331222534180e-01
    z[2,1,4]  R733      -9.2841759324073792e-02
    z[2,1,4]  R734      -0.458484411239624
    z[2,1,4]  R735      -2.1331407129764557e-01
    z[2,1,4]  R736      -2.4745023250579834e-01
    z[2,1,4]  R737      -3.6730185151100159e-02
    z[2,1,4]  R738      5.9393906593322754e-01
    z[2,1,4]  R739      1.0587974451482296e-02
    z[2,1,4]  R740      -2.6298624277114868e-01
    z[2,1,4]  R741      -1.3785381615161896e-01
    z[2,1,4]  R742      4.1813701391220093e-01
    z[2,1,4]  R743      -1.7909309267997742e-01
    z[2,1,4]  R744      1.4182345569133759e-01
    z[2,1,4]  R745      -4.0630164742469788e-01
    z[2,1,4]  R746      -4.0135571360588074e-01
    z[2,1,4]  R747      1.4454364776611328e-01
    z[2,1,4]  R748      -4.4148343801498413e-01
    z[2,1,4]  R749      -3.9723706245422363e-01
    z[2,1,4]  R750      1.9270395860075951e-02
    z[2,1,4]  R751      -1.1284729093313217e-01
    z[2,1,5]  R16       1
    z[2,1,5]  R25       -1
    z[2,1,5]  R648      -1
    z[2,1,5]  R649      1
    z[2,1,5]  R652      -1.1111732572317123e-01
    z[2,1,5]  R653      -3.4645661711692810e-01
    z[2,1,5]  R654      -2.6786080002784729e-01
    z[2,1,5]  R655      -3.5867077112197876e-01
    z[2,1,5]  R656      -1.2361617386341095e-01
    z[2,1,5]  R657      -4.2112907767295837e-01
    z[2,1,5]  R658      -1.7349600791931152e-01
    z[2,1,5]  R659      3.4701073169708252e-01
    z[2,1,5]  R660      -5.9970027208328247e-01
    z[2,1,5]  R661      -0.366510272026062
    z[2,1,5]  R662      9.0328685939311981e-02
    z[2,1,5]  R663      -5.6349381804466248e-02
    z[2,1,5]  R664      3.5383901000022888e-01
    z[2,1,5]  R665      -1.0622695088386536e-01
    z[2,1,5]  R666      1.7993077635765076e-02
    z[2,1,5]  R667      1.3508167862892151e-01
    z[2,1,5]  R668      -5.8078831434249878e-01
    z[2,1,5]  R669      -7.3170220851898193e-01
    z[2,1,5]  R670      -1.5470009297132492e-02
    z[2,1,5]  R671      1.0067449510097504e-01
    z[2,1,5]  R672      -2.4939297139644623e-01
    z[2,1,5]  R673      -3.7920403480529785e-01
    z[2,1,5]  R674      -4.9990072846412659e-02
    z[2,1,5]  R675      -1.6136933863162994e-01
    z[2,1,5]  R676      2.8091698884963989e-01
    z[2,1,5]  R677      -5.2493721246719360e-01
    z[2,1,5]  R678      1.8734987080097198e-01
    z[2,1,5]  R679      -3.7610962986946106e-01
    z[2,1,5]  R680      1.9069159030914307e-01
    z[2,1,5]  R681      -2.5586915016174316e-01
    z[2,1,5]  R682      -2.5097039341926575e-01
    z[2,1,5]  R683      -1.9765205681324005e-01
    z[2,1,5]  R684      -6.0160171985626221e-01
    z[2,1,5]  R685      -2.4117382243275642e-02
    z[2,1,5]  R686      -6.6142719984054565e-01
    z[2,1,5]  R687      3.8101503252983093e-01
    z[2,1,5]  R688      3.7576174736022949e-01
    z[2,1,5]  R689      2.6153370738029480e-01
    z[2,1,5]  R690      4.3961510062217712e-01
    z[2,1,5]  R691      -9.5619618892669678e-02
    z[2,1,5]  R692      -1.1721321940422058e-01
    z[2,1,5]  R693      5.0972348451614380e-01
    z[2,1,5]  R694      1.9712999463081360e-01
    z[2,1,5]  R695      -2.6369765400886536e-01
    z[2,1,5]  R696      -3.2655301690101624e-01
    z[2,1,5]  R697      2.4778404831886292e-01
    z[2,1,5]  R698      -4.1140198707580566e-02
    z[2,1,5]  R699      -3.0406689271330833e-02
    z[2,1,5]  R700      4.0036982297897339e-01
    z[2,1,5]  R701      -9.0188682079315186e-02
    z[2,1,5]  R702      -6.9940364360809326e-01
    z[2,1,5]  R703      -7.6825064420700073e-01
    z[2,1,5]  R704      3.1678438186645508e-01
    z[2,1,5]  R705      2.7540540695190430e-01
    z[2,1,5]  R706      3.7043631076812744e-01
    z[2,1,5]  R707      2.2858747839927673e-01
    z[2,1,5]  R708      -1.5789978206157684e-01
    z[2,1,5]  R709      5.8064174652099609e-01
    z[2,1,5]  R710      5.2196395397186279e-01
    z[2,1,5]  R711      0.578454852104187
    z[2,1,5]  R712      1.0035312175750732e-01
    z[2,1,5]  R713      1.2102705240249634e-01
    z[2,1,5]  R714      -4.0607705712318420e-01
    z[2,1,5]  R715      -2.6194760575890541e-03
    z[2,1,5]  R716      -4.0177392959594727e-01
    z[2,1,5]  R717      1.4393597841262817e-01
    z[2,1,5]  R718      -2.7187490463256836e-01
    z[2,1,5]  R719      1.6387138515710831e-02
    z[2,1,5]  R720      -3.2049903273582458e-01
    z[2,1,5]  R721      2.6123279333114624e-01
    z[2,1,5]  R722      -6.3597774505615234e-01
    z[2,1,5]  R723      -4.5043057203292847e-01
    z[2,1,5]  R724      3.3822205662727356e-01
    z[2,1,5]  R725      0.0916120857000351
    z[2,1,5]  R726      1.9699060916900635e-01
    z[2,1,5]  R727      -5.8789849281311035e-01
    z[2,1,5]  R728      9.2904157936573029e-02
    z[2,1,5]  R729      -4.9578076601028442e-01
    z[2,1,5]  R730      4.9798467755317688e-01
    z[2,1,5]  R731      -8.7487436830997467e-02
    z[2,1,5]  R732      1.6432522237300873e-01
    z[2,1,5]  R733      -6.0462478548288345e-02
    z[2,1,5]  R734      1.4008009433746338e-01
    z[2,1,5]  R735      3.2220765948295593e-01
    z[2,1,5]  R736      -0.383074551820755
    z[2,1,5]  R737      7.2040760517120361e-01
    z[2,1,5]  R738      1.2024323642253876e-01
    z[2,1,5]  R739      2.5460805743932724e-02
    z[2,1,5]  R740      -3.5921093821525574e-01
    z[2,1,5]  R741      -4.1875803470611572e-01
    z[2,1,5]  R742      2.2691969573497772e-01
    z[2,1,5]  R743      -4.0171968936920166e-01
    z[2,1,5]  R744      6.0343381017446518e-02
    z[2,1,5]  R745      5.5310624837875366e-01
    z[2,1,5]  R746      -0.295651376247406
    z[2,1,5]  R747      -3.4224978089332581e-01
    z[2,1,5]  R748      -7.4231362342834473e-01
    z[2,1,5]  R749      3.2469585537910461e-01
    z[2,1,5]  R750      4.3311398476362228e-02
    z[2,1,5]  R751      1.8013213574886322e-01
    z[2,1,6]  R17       1
    z[2,1,6]  R26       -1
    z[2,1,6]  R650      -1
    z[2,1,6]  R651      1
    z[2,1,6]  R652      -1.1575453728437424e-01
    z[2,1,6]  R653      -7.3043704032897949e-02
    z[2,1,6]  R654      -4.1478082537651062e-01
    z[2,1,6]  R655      -2.0926142111420631e-02
    z[2,1,6]  R656      -7.0083987712860107e-01
    z[2,1,6]  R657      1.6672931611537933e-01
    z[2,1,6]  R658      -0.542167603969574
    z[2,1,6]  R659      6.3620530068874359e-02
    z[2,1,6]  R660      -7.9978398978710175e-02
    z[2,1,6]  R661      -5.3863030672073364e-01
    z[2,1,6]  R662      -1.8201902508735657e-01
    z[2,1,6]  R663      7.3884904384613037e-01
    z[2,1,6]  R664      4.8412540555000305e-01
    z[2,1,6]  R665      5.8973014354705811e-01
    z[2,1,6]  R666      3.5702344775199890e-01
    z[2,1,6]  R667      6.3501638174057007e-01
    z[2,1,6]  R668      4.4806458055973053e-02
    z[2,1,6]  R669      1.7744249105453491e-01
    z[2,1,6]  R670      4.4641438126564026e-01
    z[2,1,6]  R671      7.2661107778549194e-01
    z[2,1,6]  R672      -2.1608068048954010e-01
    z[2,1,6]  R673      -0.0524955689907074
    z[2,1,6]  R674      -1.0785356909036636e-01
    z[2,1,6]  R675      4.3899369239807129e-01
    z[2,1,6]  R676      -1.1953758448362350e-01
    z[2,1,6]  R677      -1.1923612095415592e-02
    z[2,1,6]  R678      4.0497392416000366e-01
    z[2,1,6]  R679      2.3242910206317902e-01
    z[2,1,6]  R680      2.7324414253234863e-01
    z[2,1,6]  R681      2.2052489221096039e-02
    z[2,1,6]  R682      3.2474055886268616e-02
    z[2,1,6]  R683      3.3998188376426697e-01
    z[2,1,6]  R684      -1.4878799021244049e-01
    z[2,1,6]  R685      6.0695850849151611e-01
    z[2,1,6]  R686      1.2342663109302521e-01
    z[2,1,6]  R687      -5.0115519762039185e-01
    z[2,1,6]  R688      -4.7997005283832550e-02
    z[2,1,6]  R689      -3.2024788856506348e-01
    z[2,1,6]  R690      -2.0141196250915527e-01
    z[2,1,6]  R691      5.0863599777221680e-01
    z[2,1,6]  R692      2.7666044235229492e-01
    z[2,1,6]  R693      -8.1315249204635620e-02
    z[2,1,6]  R694      -0.344471275806427
    z[2,1,6]  R695      5.9897238016128540e-01
    z[2,1,6]  R696      -1.0502582043409348e-01
    z[2,1,6]  R697      -5.3841298818588257e-01
    z[2,1,6]  R698      1.1015736311674118e-01
    z[2,1,6]  R699      -1.4831455051898956e-01
    z[2,1,6]  R700      5.0073593854904175e-02
    z[2,1,6]  R701      5.9780506417155266e-03
    z[2,1,6]  R702      -2.4168142676353455e-01
    z[2,1,6]  R703      1.7247229814529419e-01
    z[2,1,6]  R704      7.9172827303409576e-02
    z[2,1,6]  R705      2.4253658950328827e-01
    z[2,1,6]  R706      2.8019472956657410e-01
    z[2,1,6]  R707      -3.3731141686439514e-01
    z[2,1,6]  R708      -5.1452624797821045e-01
    z[2,1,6]  R709      2.3528663814067841e-01
    z[2,1,6]  R710      3.3454321324825287e-02
    z[2,1,6]  R711      2.6520317792892456e-01
    z[2,1,6]  R712      -2.4538420140743256e-02
    z[2,1,6]  R713      0.297335684299469
    z[2,1,6]  R714      3.4954464435577393e-01
    z[2,1,6]  R715      2.2817702591419220e-01
    z[2,1,6]  R716      1.5097934752702713e-02
    z[2,1,6]  R717      -6.1416542530059814e-01
    z[2,1,6]  R718      3.6751002073287964e-01
    z[2,1,6]  R719      -6.2844090163707733e-02
    z[2,1,6]  R720      -6.7511671781539917e-01
    z[2,1,6]  R721      2.4829532206058502e-01
    z[2,1,6]  R722      -2.0460508763790131e-01
    z[2,1,6]  R723      -1.0036907345056534e-01
    z[2,1,6]  R724      1.7019617557525635e-01
    z[2,1,6]  R725      2.3270641267299652e-01
    z[2,1,6]  R726      3.9491218328475952e-01
    z[2,1,6]  R727      2.4653873406350613e-03
    z[2,1,6]  R728      -1.9103090465068817e-01
    z[2,1,6]  R729      3.7120506167411804e-01
    z[2,1,6]  R730      -1.0990805923938751e-01
    z[2,1,6]  R731      3.8752806186676025e-01
    z[2,1,6]  R732      -1.4466822147369385e-01
    z[2,1,6]  R733      4.0550419688224792e-01
    z[2,1,6]  R734      -4.9038353562355042e-01
    z[2,1,6]  R735      3.4836760163307190e-01
    z[2,1,6]  R736      -2.1705206483602524e-02
    z[2,1,6]  R737      -4.6356637030839920e-02
    z[2,1,6]  R738      1.6067904233932495e-01
    z[2,1,6]  R739      7.2418713569641113e-01
    z[2,1,6]  R740      -2.4380896985530853e-01
    z[2,1,6]  R741      -6.6189341247081757e-02
    z[2,1,6]  R742      -8.9187301695346832e-02
    z[2,1,6]  R743      -4.8660197854042053e-01
    z[2,1,6]  R744      -1.1435898393392563e-01
    z[2,1,6]  R745      1.1933930218219757e-01
    z[2,1,6]  R746      4.5157539844512939e-01
    z[2,1,6]  R747      -1.1630688607692719e-01
    z[2,1,6]  R748      -1.7178329825401306e-01
    z[2,1,6]  R749      -6.2800779938697815e-02
    z[2,1,6]  R750      2.2420226037502289e-01
    z[2,1,6]  R751      3.5451132059097290e-01
    z[2,3,0]  R20       -1
    z[2,3,0]  R29       1
    z[2,3,0]  R752      -1
    z[2,3,0]  R753      1
    z[2,3,0]  R766      -4.6003714203834534e-01
    z[2,3,0]  R767      -8.5073653608560562e-03
    z[2,3,0]  R768      -5.5655580759048462e-01
    z[2,3,0]  R769      -4.1328959167003632e-02
    z[2,3,0]  R770      1.8384875357151031e-01
    z[2,3,0]  R771      -6.8432295322418213e-01
    z[2,3,0]  R772      -4.3920648097991943e-01
    z[2,3,0]  R773      -2.7425637841224670e-01
    z[2,3,0]  R774      -3.9826804399490356e-01
    z[2,3,0]  R775      3.2798236608505249e-01
    z[2,3,0]  R776      1.9804461300373077e-01
    z[2,3,0]  R777      -7.2348743677139282e-02
    z[2,3,0]  R778      -1.7537489533424377e-02
    z[2,3,0]  R779      0.292106568813324
    z[2,3,0]  R780      0.402878999710083
    z[2,3,0]  R781      -1.2381814420223236e-01
    z[2,3,0]  R782      -2.3071540892124176e-01
    z[2,3,0]  R783      7.0579960942268372e-02
    z[2,3,0]  R784      3.9821188896894455e-02
    z[2,3,0]  R785      -6.1034295707941055e-02
    z[2,3,0]  R786      -1.8003901839256287e-01
    z[2,3,0]  R787      -1.5587781369686127e-01
    z[2,3,0]  R788      1.8529336154460907e-01
    z[2,3,0]  R789      -8.3421230316162109e-02
    z[2,3,0]  R790      -3.2203629612922668e-01
    z[2,3,0]  R791      -4.6948346495628357e-01
    z[2,3,0]  R792      -4.3462562561035156e-01
    z[2,3,0]  R793      -1.4304748177528381e-01
    z[2,3,0]  R794      1.8365567922592163e-01
    z[2,3,0]  R795      -2.8893113136291504e-02
    z[2,3,0]  R796      -3.8958737254142761e-01
    z[2,3,0]  R797      -6.8815350532531738e-02
    z[2,3,0]  R798      2.4270290136337280e-01
    z[2,3,0]  R799      -0.233124777674675
    z[2,3,0]  R800      -2.7780758216977119e-02
    z[2,3,0]  R801      -9.1728426516056061e-02
    z[2,3,0]  R802      1.5637844800949097e-01
    z[2,3,0]  R803      1.3719514012336731e-01
    z[2,3,0]  R804      2.9046159982681274e-01
    z[2,3,0]  R805      -4.0357176214456558e-02
    z[2,3,0]  R806      -0.00798717699944973
    z[2,3,0]  R807      -3.9652702212333679e-01
    z[2,3,0]  R808      2.3141847550868988e-01
    z[2,3,0]  R809      -1.4708544313907623e-01
    z[2,3,0]  R810      2.6743856072425842e-01
    z[2,3,0]  R811      1.0477688163518906e-01
    z[2,3,0]  R812      3.3715635538101196e-01
    z[2,3,0]  R813      4.3467298150062561e-01
    z[2,3,0]  R814      2.1802544593811035e-01
    z[2,3,0]  R815      3.1608527898788452e-01
    z[2,3,0]  R816      -7.1441113948822021e-02
    z[2,3,0]  R817      -1.0171761363744736e-01
    z[2,3,0]  R818      2.2076368331909180e-01
    z[2,3,0]  R819      -4.1067633777856827e-02
    z[2,3,0]  R820      -1.7654503881931305e-01
    z[2,3,0]  R821      1.7004080116748810e-01
    z[2,3,0]  R822      -7.1844369173049927e-02
    z[2,3,0]  R823      1.2535277009010315e-01
    z[2,3,0]  R824      6.0810748487710953e-02
    z[2,3,0]  R825      -1.0493205487728119e-01
    z[2,3,0]  R826      -3.4679239988327026e-01
    z[2,3,0]  R827      3.1635525822639465e-01
    z[2,3,0]  R828      2.4061417579650879e-01
    z[2,3,0]  R829      1.3621720671653748e-01
    z[2,3,0]  R830      1.2337982654571533e-01
    z[2,3,0]  R831      -1.5169952809810638e-01
    z[2,3,0]  R832      2.2870300710201263e-01
    z[2,3,0]  R833      -1.9770224392414093e-01
    z[2,3,0]  R834      2.8880143165588379e-01
    z[2,3,0]  R835      -1.5453328192234039e-01
    z[2,3,0]  R836      3.8862389326095581e-01
    z[2,3,0]  R837      3.7091308832168579e-01
    z[2,3,0]  R838      0.478127658367157
    z[2,3,0]  R839      4.6311464905738831e-01
    z[2,3,0]  R840      4.7244840860366821e-01
    z[2,3,0]  R841      -3.2537445425987244e-01
    z[2,3,0]  R842      4.7602352499961853e-01
    z[2,3,0]  R843      2.5705429911613464e-01
    z[2,3,0]  R844      5.9679847955703735e-01
    z[2,3,0]  R845      4.8446375131607056e-01
    z[2,3,0]  R846      -1.4129619300365448e-01
    z[2,3,0]  R847      -2.4598467350006104e-01
    z[2,3,0]  R848      -2.2360714152455330e-02
    z[2,3,0]  R849      4.9472215771675110e-01
    z[2,3,0]  R850      -2.9698467254638672e-01
    z[2,3,0]  R851      9.5166578888893127e-02
    z[2,3,0]  R852      -8.4637673571705818e-03
    z[2,3,0]  R853      3.5379037261009216e-01
    z[2,3,0]  R854      -4.9908825755119324e-01
    z[2,3,0]  R855      2.0909052342176437e-02
    z[2,3,0]  R856      -1.6441054642200470e-01
    z[2,3,0]  R857      -4.1640344262123108e-01
    z[2,3,0]  R858      2.3950491845607758e-01
    z[2,3,0]  R859      -3.0985912680625916e-01
    z[2,3,0]  R860      1.3322702050209045e-01
    z[2,3,0]  R861      2.8159549832344055e-01
    z[2,3,0]  R862      -5.0860035419464111e-01
    z[2,3,0]  R863      -2.9777538776397705e-01
    z[2,3,0]  R864      1.0051559656858444e-01
    z[2,3,0]  R865      -4.4247376918792725e-01
    z[2,3,0]  R866      -1.9971807301044464e-01
    z[2,3,0]  R867      -1.4479297399520874e-01
    z[2,3,0]  R868      3.1530305743217468e-01
    z[2,3,0]  R869      -4.0553700923919678e-01
    z[2,3,0]  R870      2.8023305535316467e-01
    z[2,3,0]  R871      1.1138470470905304e-01
    z[2,3,0]  R872      -1.4050295948982239e-01
    z[2,3,0]  R873      -1.6415895521640778e-01
    z[2,3,0]  R874      -3.0126294121146202e-02
    z[2,3,0]  R875      -2.0682542026042938e-01
    z[2,3,1]  R21       -1
    z[2,3,1]  R30       1
    z[2,3,1]  R754      -1
    z[2,3,1]  R755      1
    z[2,3,1]  R766      -1.2009544670581818e-01
    z[2,3,1]  R767      -8.1751078367233276e-02
    z[2,3,1]  R768      -1.1944067478179932e-01
    z[2,3,1]  R769      4.1970473527908325e-01
    z[2,3,1]  R770      2.8386149555444717e-02
    z[2,3,1]  R771      -3.3588859438896179e-01
    z[2,3,1]  R772      -3.5688936710357666e-01
    z[2,3,1]  R773      -1.0904785245656967e-01
    z[2,3,1]  R774      2.6019543409347534e-01
    z[2,3,1]  R775      3.2960599660873413e-01
    z[2,3,1]  R776      0.310889333486557
    z[2,3,1]  R777      3.6694172024726868e-01
    z[2,3,1]  R778      2.3732134699821472e-01
    z[2,3,1]  R779      6.3886421918869019e-01
    z[2,3,1]  R780      7.7943336963653564e-01
    z[2,3,1]  R781      -6.4054572582244873e-01
    z[2,3,1]  R782      -3.4550639986991882e-01
    z[2,3,1]  R783      1.6194467246532440e-01
    z[2,3,1]  R784      1.1359908431768417e-01
    z[2,3,1]  R785      2.0492841303348541e-01
    z[2,3,1]  R786      -7.6640337705612183e-02
    z[2,3,1]  R787      -3.9700353145599365e-01
    z[2,3,1]  R788      1.8615961074829102e-01
    z[2,3,1]  R789      -2.4497555196285248e-01
    z[2,3,1]  R790      -4.1259798407554626e-01
    z[2,3,1]  R791      -6.4995211362838745e-01
    z[2,3,1]  R792      -2.0629326999187469e-01
    z[2,3,1]  R793      3.5990167409181595e-02
    z[2,3,1]  R794      5.4702192544937134e-01
    z[2,3,1]  R795      -2.8597798943519592e-01
    z[2,3,1]  R796      -4.1062659025192261e-01
    z[2,3,1]  R797      1.3161525130271912e-01
    z[2,3,1]  R798      1.3473476469516754e-01
    z[2,3,1]  R799      -7.6633952558040619e-02
    z[2,3,1]  R800      -2.4065822362899780e-01
    z[2,3,1]  R801      -3.3735689520835876e-01
    z[2,3,1]  R802      4.1433599591255188e-01
    z[2,3,1]  R803      3.6250334978103638e-01
    z[2,3,1]  R804      4.3162074685096741e-01
    z[2,3,1]  R805      2.9725155234336853e-01
    z[2,3,1]  R806      2.8470417857170105e-01
    z[2,3,1]  R807      -4.2697837948799133e-01
    z[2,3,1]  R808      3.6318513751029968e-01
    z[2,3,1]  R809      1.9550137221813202e-01
    z[2,3,1]  R810      3.1546348333358765e-01
    z[2,3,1]  R811      -1.8552072346210480e-01
    z[2,3,1]  R812      -9.1899514198303223e-01
    z[2,3,1]  R813      -8.7285065650939941e-01
    z[2,3,1]  R814      -8.4027677774429321e-01
    z[2,3,1]  R815      -8.3648532629013062e-01
    z[2,3,1]  R816      -2.1401226520538330e-01
    z[2,3,1]  R817      5.2057977765798569e-02
    z[2,3,1]  R818      4.2800846695899963e-01
    z[2,3,1]  R819      2.6091209053993225e-01
    z[2,3,1]  R820      -8.2916563749313354e-01
    z[2,3,1]  R821      -7.2809213399887085e-01
    z[2,3,1]  R822      -6.6152030229568481e-01
    z[2,3,1]  R823      1.5068809688091278e-01
    z[2,3,1]  R824      -1.2697984278202057e-01
    z[2,3,1]  R825      -1.8668781220912933e-01
    z[2,3,1]  R826      -5.2148234844207764e-01
    z[2,3,1]  R827      8.3416923880577087e-02
    z[2,3,1]  R828      -5.1724594831466675e-01
    z[2,3,1]  R829      0.436928391456604
    z[2,3,1]  R830      0.481802374124527
    z[2,3,1]  R831      -4.2934402823448181e-01
    z[2,3,1]  R832      4.3029200285673141e-02
    z[2,3,1]  R833      -3.1166023015975952e-01
    z[2,3,1]  R834      -9.3946449458599091e-02
    z[2,3,1]  R835      2.3569411039352417e-01
    z[2,3,1]  R836      -3.9549741148948669e-01
    z[2,3,1]  R837      -3.2833805680274963e-01
    z[2,3,1]  R838      -4.0744832158088684e-01
    z[2,3,1]  R839      -7.6940737664699554e-02
    z[2,3,1]  R840      -1.4032201468944550e-01
    z[2,3,1]  R841      -2.6081937551498413e-01
    z[2,3,1]  R842      -4.7939816117286682e-01
    z[2,3,1]  R843      -5.7229530811309814e-01
    z[2,3,1]  R844      -1.1862655729055405e-01
    z[2,3,1]  R845      -2.3100028932094574e-01
    z[2,3,1]  R846      -3.8691377639770508e-01
    z[2,3,1]  R847      -1.3536162674427032e-01
    z[2,3,1]  R848      -8.1442302465438843e-01
    z[2,3,1]  R849      2.1609127521514893e-01
    z[2,3,1]  R850      -8.0153423547744751e-01
    z[2,3,1]  R851      -7.2501242160797119e-01
    z[2,3,1]  R852      -9.2812252044677734e-01
    z[2,3,1]  R853      5.6346774101257324e-01
    z[2,3,1]  R854      0.726138710975647
    z[2,3,1]  R855      -0.0324397049844265
    z[2,3,1]  R856      -3.2403391599655151e-01
    z[2,3,1]  R857      -4.0914842486381531e-01
    z[2,3,1]  R858      -5.8479070663452148e-01
    z[2,3,1]  R859      -6.0351520776748657e-01
    z[2,3,1]  R860      1.4922253787517548e-01
    z[2,3,1]  R861      5.9933638572692871e-01
    z[2,3,1]  R862      4.6213066577911377e-01
    z[2,3,1]  R863      0.813393771648407
    z[2,3,1]  R864      4.7956377267837524e-01
    z[2,3,1]  R865      6.3635557889938354e-01
    z[2,3,1]  R866      -3.5282588005065918e-01
    z[2,3,1]  R867      -5.1891523599624634e-01
    z[2,3,1]  R868      -7.3771619796752930e-01
    z[2,3,1]  R869      -6.7508661746978760e-01
    z[2,3,1]  R870      3.8875925540924072e-01
    z[2,3,1]  R871      5.7495909929275513e-01
    z[2,3,1]  R872      5.7786947488784790e-01
    z[2,3,1]  R873      8.9735507965087891e-01
    z[2,3,1]  R874      4.3170607089996338e-01
    z[2,3,1]  R875      7.3682177066802979e-01
    z[2,3,2]  R22       -1
    z[2,3,2]  R31       1
    z[2,3,2]  R756      -1
    z[2,3,2]  R757      1
    z[2,3,2]  R766      -1.4356851577758789e-01
    z[2,3,2]  R767      0.729804277420044
    z[2,3,2]  R768      -2.6146861910820007e-01
    z[2,3,2]  R769      -3.0947241187095642e-01
    z[2,3,2]  R770      -5.2568817138671875e-01
    z[2,3,2]  R771      -4.1015830636024475e-01
    z[2,3,2]  R772      -2.6602697372436523e-01
    z[2,3,2]  R773      5.3871631622314453e-01
    z[2,3,2]  R774      -1.6271330416202545e-01
    z[2,3,2]  R775      -3.7800505757331848e-01
    z[2,3,2]  R776      0.69382244348526
    z[2,3,2]  R777      3.9817529916763306e-01
    z[2,3,2]  R778      -7.6352918148040771e-01
    z[2,3,2]  R779      2.0025306940078735e-01
    z[2,3,2]  R780      3.0574655532836914e-01
    z[2,3,2]  R781      2.9796570539474487e-01
    z[2,3,2]  R782      2.2964215278625488e-01
    z[2,3,2]  R783      3.6519104242324829e-01
    z[2,3,2]  R784      -6.5180528163909912e-01
    z[2,3,2]  R785      -4.6473458409309387e-01
    z[2,3,2]  R786      5.0008010864257812e-01
    z[2,3,2]  R787      5.1603639125823975e-01
    z[2,3,2]  R788      7.4964660406112671e-01
    z[2,3,2]  R789      6.6788399219512939e-01
    z[2,3,2]  R790      -7.1688455343246460e-01
    z[2,3,2]  R791      1.4531970024108887e-01
    z[2,3,2]  R792      -7.0390887558460236e-02
    z[2,3,2]  R793      -9.6790179610252380e-02
    z[2,3,2]  R794      3.4134072065353394e-01
    z[2,3,2]  R795      -7.9266905784606934e-01
    z[2,3,2]  R796      2.1038149297237396e-01
    z[2,3,2]  R797      -7.8002011775970459e-01
    z[2,3,2]  R798      -7.2178280353546143e-01
    z[2,3,2]  R799      6.2027710676193237e-01
    z[2,3,2]  R800      -5.2359807491302490e-01
    z[2,3,2]  R801      2.7404937148094177e-01
    z[2,3,2]  R802      7.2649180889129639e-01
    z[2,3,2]  R803      -2.9205662012100220e-01
    z[2,3,2]  R804      6.9390803575515747e-01
    z[2,3,2]  R805      -0.504687488079071
    z[2,3,2]  R806      6.4094376564025879e-01
    z[2,3,2]  R807      5.0092363357543945e-01
    z[2,3,2]  R808      5.5363011360168457e-01
    z[2,3,2]  R809      6.6597777605056763e-01
    z[2,3,2]  R810      7.9786878824234009e-01
    z[2,3,2]  R811      7.3170125484466553e-01
    z[2,3,2]  R812      -1.2281985580921173e-01
    z[2,3,2]  R813      1.1112658679485321e-01
    z[2,3,2]  R814      1.9943784177303314e-01
    z[2,3,2]  R815      -1.5234960615634918e-01
    z[2,3,2]  R816      3.9555743336677551e-01
    z[2,3,2]  R817      4.0862086415290833e-01
    z[2,3,2]  R818      7.8288817405700684e-01
    z[2,3,2]  R819      -1.1294302530586720e-02
    z[2,3,2]  R820      -6.9810695946216583e-02
    z[2,3,2]  R821      -2.8861811757087708e-01
    z[2,3,2]  R822      4.2097836732864380e-02
    z[2,3,2]  R823      1.5735620632767677e-02
    z[2,3,2]  R824      -0.131294846534729
    z[2,3,2]  R825      2.8363198041915894e-02
    z[2,3,2]  R826      1.5335462987422943e-01
    z[2,3,2]  R827      -6.0049909353256226e-01
    z[2,3,2]  R828      5.4962551593780518e-01
    z[2,3,2]  R829      -3.2779499888420105e-01
    z[2,3,2]  R830      -3.8564798235893250e-01
    z[2,3,2]  R831      -4.9620741046965122e-03
    z[2,3,2]  R832      -4.8943346738815308e-01
    z[2,3,2]  R833      1.8296520411968231e-01
    z[2,3,2]  R834      -4.2893221974372864e-01
    z[2,3,2]  R835      -2.5571811944246292e-02
    z[2,3,2]  R836      3.3236268162727356e-01
    z[2,3,2]  R837      4.7776794433593750e-01
    z[2,3,2]  R838      5.4234284162521362e-01
    z[2,3,2]  R839      3.3731272816658020e-01
    z[2,3,2]  R840      6.2042981386184692e-01
    z[2,3,2]  R841      -4.3763765692710876e-01
    z[2,3,2]  R842      2.6428681612014771e-01
    z[2,3,2]  R843      1.4328658580780029e-03
    z[2,3,2]  R844      3.2177260518074036e-01
    z[2,3,2]  R845      1.7702539265155792e-01
    z[2,3,2]  R846      -7.1257036924362183e-01
    z[2,3,2]  R847      -5.8643120527267456e-01
    z[2,3,2]  R848      -1.3432666659355164e-01
    z[2,3,2]  R849      4.8286509513854980e-01
    z[2,3,2]  R850      -4.7755271196365356e-01
    z[2,3,2]  R851      -2.8411459922790527e-01
    z[2,3,2]  R852      -1.3416558504104614e-01
    z[2,3,2]  R853      7.0129656791687012e-01
    z[2,3,2]  R854      -3.3579519391059875e-01
    z[2,3,2]  R855      1.0880029201507568e-01
    z[2,3,2]  R856      -0.604345440864563
    z[2,3,2]  R857      -2.9558802023530006e-02
    z[2,3,2]  R858      1.1722157150506973e-01
    z[2,3,2]  R859      3.9034938812255859e-01
    z[2,3,2]  R860      4.1221952438354492e-01
    z[2,3,2]  R861      -1.5346366167068481e-01
    z[2,3,2]  R862      -6.5238827466964722e-01
    z[2,3,2]  R863      -4.8277732729911804e-01
    z[2,3,2]  R864      6.8101976066827774e-03
    z[2,3,2]  R865      -5.9404021501541138e-01
    z[2,3,2]  R866      -3.6452940106391907e-01
    z[2,3,2]  R867      -2.5705328583717346e-01
    z[2,3,2]  R868      -5.0469189882278442e-03
    z[2,3,2]  R869      1.0578592121601105e-01
    z[2,3,2]  R870      6.2631016969680786e-01
    z[2,3,2]  R871      -2.6241201162338257e-01
    z[2,3,2]  R872      -9.8471298813819885e-02
    z[2,3,2]  R873      -3.2202121615409851e-01
    z[2,3,2]  R874      -2.2024551033973694e-01
    z[2,3,2]  R875      -3.5296049714088440e-01
    z[2,3,3]  R23       -1
    z[2,3,3]  R32       1
    z[2,3,3]  R758      -1
    z[2,3,3]  R759      1
    z[2,3,3]  R766      -7.7471143007278442e-01
    z[2,3,3]  R767      -1.9912803173065186e-01
    z[2,3,3]  R768      -5.9046244621276855e-01
    z[2,3,3]  R769      -7.7111244201660156e-01
    z[2,3,3]  R770      -4.2575830221176147e-01
    z[2,3,3]  R771      -2.1329177916049957e-01
    z[2,3,3]  R772      -4.8338085412979126e-01
    z[2,3,3]  R773      -0.650117039680481
    z[2,3,3]  R774      -6.1055636405944824e-01
    z[2,3,3]  R775      -4.4781497120857239e-01
    z[2,3,3]  R776      5.2484970539808273e-02
    z[2,3,3]  R777      -7.0237023464869708e-05
    z[2,3,3]  R778      2.7089977636933327e-02
    z[2,3,3]  R779      1.3784949481487274e-01
    z[2,3,3]  R780      0.0763256624341011
    z[2,3,3]  R781      2.3601779341697693e-01
    z[2,3,3]  R782      2.1000732481479645e-01
    z[2,3,3]  R783      1.4069318771362305e-01
    z[2,3,3]  R784      1.5281075239181519e-01
    z[2,3,3]  R785      3.3632174134254456e-02
    z[2,3,3]  R786      -0.602166473865509
    z[2,3,3]  R787      -2.8964528441429138e-01
    z[2,3,3]  R788      -3.9659479260444641e-01
    z[2,3,3]  R789      -1.0696002095937729e-01
    z[2,3,3]  R790      -1.8552352488040924e-01
    z[2,3,3]  R791      -2.3194706439971924e-01
    z[2,3,3]  R792      -6.7049944400787354e-01
    z[2,3,3]  R793      -6.8894618749618530e-01
    z[2,3,3]  R794      -4.6335729956626892e-01
    z[2,3,3]  R795      4.5260539650917053e-01
    z[2,3,3]  R796      -0.627235472202301
    z[2,3,3]  R797      -3.8507196307182312e-01
    z[2,3,3]  R798      0.0701432153582573
    z[2,3,3]  R799      1.5927150845527649e-02
    z[2,3,3]  R800      2.8033575415611267e-01
    z[2,3,3]  R801      -2.9147097468376160e-01
    z[2,3,3]  R802      -2.4210660159587860e-01
    z[2,3,3]  R803      -6.0953539609909058e-01
    z[2,3,3]  R804      -1.1136322468519211e-01
    z[2,3,3]  R805      -1.5046467073261738e-02
    z[2,3,3]  R806      -5.2768802642822266e-01
    z[2,3,3]  R807      -3.6627539992332458e-01
    z[2,3,3]  R808      -5.4008686542510986e-01
    z[2,3,3]  R809      -0.152797669172287
    z[2,3,3]  R810      1.4392603933811188e-01
    z[2,3,3]  R811      2.5546967983245850e-01
    z[2,3,3]  R812      -6.3771359622478485e-02
    z[2,3,3]  R813      6.0601551085710526e-02
    z[2,3,3]  R814      0.191497340798378
    z[2,3,3]  R815      3.2247364521026611e-01
    z[2,3,3]  R816      -3.7331116199493408e-01
    z[2,3,3]  R817      -4.4019228219985962e-01
    z[2,3,3]  R818      -7.8483417630195618e-02
    z[2,3,3]  R819      -8.9167469739913940e-01
    z[2,3,3]  R820      2.2209782898426056e-01
    z[2,3,3]  R821      4.2631953954696655e-01
    z[2,3,3]  R822      0.506289541721344
    z[2,3,3]  R823      7.1076595783233643e-01
    z[2,3,3]  R824      8.1934696435928345e-01
    z[2,3,3]  R825      7.1757531166076660e-01
    z[2,3,3]  R826      1.3980150222778320e-01
    z[2,3,3]  R827      -4.8543652892112732e-01
    z[2,3,3]  R828      0.349149614572525
    z[2,3,3]  R829      -7.0498067140579224e-01
    z[2,3,3]  R830      -6.4381921291351318e-01
    z[2,3,3]  R831      2.5701728463172913e-01
    z[2,3,3]  R832      -5.4006010293960571e-01
    z[2,3,3]  R833      -0.0647614598274231
    z[2,3,3]  R834      -1.8884766101837158e-01
    z[2,3,3]  R835      -4.9562579393386841e-01
    z[2,3,3]  R836      -7.6045602560043335e-01
    z[2,3,3]  R837      -6.8463677167892456e-01
    z[2,3,3]  R838      -3.7467747926712036e-01
    z[2,3,3]  R839      -7.0945578813552856e-01
    z[2,3,3]  R840      -4.7919160127639771e-01
    z[2,3,3]  R841      -6.2790863215923309e-02
    z[2,3,3]  R842      -5.4137378931045532e-01
    z[2,3,3]  R843      -6.1908680200576782e-01
    z[2,3,3]  R844      -5.0925046205520630e-01
    z[2,3,3]  R845      -5.1862555742263794e-01
    z[2,3,3]  R846      0.0450817309319973
    z[2,3,3]  R847      -6.1120027303695679e-01
    z[2,3,3]  R848      1.4381159842014313e-01
    z[2,3,3]  R849      -4.9036917090415955e-01
    z[2,3,3]  R850      -3.7112716585397720e-02
    z[2,3,3]  R851      1.6053833067417145e-01
    z[2,3,3]  R852      -2.5952902436256409e-01
    z[2,3,3]  R853      -1.0738559067249298e-03
    z[2,3,3]  R854      3.0714073777198792e-01
    z[2,3,3]  R855      8.6557984352111816e-01
    z[2,3,3]  R856      -4.5465391874313354e-01
    z[2,3,3]  R857      -4.8944808542728424e-02
    z[2,3,3]  R858      3.8044983148574829e-01
    z[2,3,3]  R859      -2.1053658425807953e-01
    z[2,3,3]  R860      8.1655263900756836e-01
    z[2,3,3]  R861      -5.5685347318649292e-01
    z[2,3,3]  R862      3.0859303474426270e-01
    z[2,3,3]  R863      -6.4833253622055054e-02
    z[2,3,3]  R864      6.2604665756225586e-01
    z[2,3,3]  R865      1.9388185441493988e-01
    z[2,3,3]  R866      -3.7968146800994873e-01
    z[2,3,3]  R867      7.0764243602752686e-01
    z[2,3,3]  R868      -2.8273233771324158e-01
    z[2,3,3]  R869      7.9361535608768463e-02
    z[2,3,3]  R870      -4.0932792425155640e-01
    z[2,3,3]  R871      -6.0328519344329834e-01
    z[2,3,3]  R872      7.1337640285491943e-01
    z[2,3,3]  R873      1.6910864412784576e-01
    z[2,3,3]  R874      6.6688686609268188e-01
    z[2,3,3]  R875      8.0330856144428253e-02
    z[2,3,4]  R24       -1
    z[2,3,4]  R33       1
    z[2,3,4]  R760      -1
    z[2,3,4]  R761      1
    z[2,3,4]  R766      -3.5694119334220886e-01
    z[2,3,4]  R767      5.4370075464248657e-01
    z[2,3,4]  R768      1.2318822741508484e-01
    z[2,3,4]  R769      5.1668293774127960e-02
    z[2,3,4]  R770      -3.6304976791143417e-02
    z[2,3,4]  R771      -3.0530476942658424e-03
    z[2,3,4]  R772      -2.2639280557632446e-01
    z[2,3,4]  R773      2.7488246560096741e-01
    z[2,3,4]  R774      9.1593027114868164e-02
    z[2,3,4]  R775      -1.2613105773925781e-01
    z[2,3,4]  R776      -5.8197224140167236e-01
    z[2,3,4]  R777      -3.9051589369773865e-01
    z[2,3,4]  R778      -9.0018799528479576e-03
    z[2,3,4]  R779      2.9724881052970886e-01
    z[2,3,4]  R780      -5.5463850498199463e-02
    z[2,3,4]  R781      9.1593697667121887e-02
    z[2,3,4]  R782      -6.2548726797103882e-01
    z[2,3,4]  R783      -4.9875780940055847e-01
    z[2,3,4]  R784      5.8119124174118042e-01
    z[2,3,4]  R785      4.4617357850074768e-01
    z[2,3,4]  R786      -4.9004080891609192e-01
    z[2,3,4]  R787      -5.6687819957733154e-01
    z[2,3,4]  R788      -4.4454705715179443e-01
    z[2,3,4]  R789      -5.0671774148941040e-01
    z[2,3,4]  R790      -2.9070526361465454e-01
    z[2,3,4]  R791      -8.0801740288734436e-02
    z[2,3,4]  R792      3.3899176120758057e-01
    z[2,3,4]  R793      5.4657596349716187e-01
    z[2,3,4]  R794      4.7412925958633423e-01
    z[2,3,4]  R795      1.3509477674961090e-01
    z[2,3,4]  R796      4.2176067829132080e-01
    z[2,3,4]  R797      2.5802356004714966e-01
    z[2,3,4]  R798      1.1396868526935577e-01
    z[2,3,4]  R799      4.3104812502861023e-01
    z[2,3,4]  R800      3.6857652664184570e-01
    z[2,3,4]  R801      5.6691169738769531e-01
    z[2,3,4]  R802      -2.7196460962295532e-01
    z[2,3,4]  R803      -4.7114729881286621e-01
    z[2,3,4]  R804      3.9963617920875549e-02
    z[2,3,4]  R805      -6.2227261066436768e-01
    z[2,3,4]  R806      3.7327775359153748e-01
    z[2,3,4]  R807      9.4569891691207886e-02
    z[2,3,4]  R808      2.4253083765506744e-01
    z[2,3,4]  R809      -2.1205490827560425e-01
    z[2,3,4]  R810      -2.3234188556671143e-01
    z[2,3,4]  R811      0.0516420416533947
    z[2,3,4]  R812      9.3780837953090668e-02
    z[2,3,4]  R813      1.0123088210821152e-01
    z[2,3,4]  R814      8.4556154906749725e-02
    z[2,3,4]  R815      -2.5497657060623169e-01
    z[2,3,4]  R816      3.2510408759117126e-01
    z[2,3,4]  R817      -7.9041332006454468e-02
    z[2,3,4]  R818      2.0585921406745911e-01
    z[2,3,4]  R819      1.8836686387658119e-02
    z[2,3,4]  R820      1.0669153183698654e-01
    z[2,3,4]  R821      9.9437877535820007e-02
    z[2,3,4]  R822      9.7253829240798950e-02
    z[2,3,4]  R823      -2.5226840376853943e-01
    z[2,3,4]  R824      -1.3433134555816650e-01
    z[2,3,4]  R825      -1.8296252191066742e-01
    z[2,3,4]  R826      -4.8401427268981934e-01
    z[2,3,4]  R827      4.6343751251697540e-02
    z[2,3,4]  R828      5.4460112005472183e-02
    z[2,3,4]  R829      -3.2666212320327759e-01
    z[2,3,4]  R830      1.3809368014335632e-01
    z[2,3,4]  R831      6.6078805923461914e-01
    z[2,3,4]  R832      -3.1959589570760727e-02
    z[2,3,4]  R833      4.6754062175750732e-01
    z[2,3,4]  R834      -3.1381070613861084e-01
    z[2,3,4]  R835      -6.2581133842468262e-01
    z[2,3,4]  R836      -1.9610758870840073e-02
    z[2,3,4]  R837      -4.9195587635040283e-02
    z[2,3,4]  R838      2.2888121008872986e-01
    z[2,3,4]  R839      1.2012667208909988e-01
    z[2,3,4]  R840      -3.0425125360488892e-01
    z[2,3,4]  R841      -7.9097676277160645e-01
    z[2,3,4]  R842      2.3311580717563629e-01
    z[2,3,4]  R843      -1.8523296713829041e-01
    z[2,3,4]  R844      2.3390786349773407e-01
    z[2,3,4]  R845      5.2037900686264038e-01
    z[2,3,4]  R846      -2.6308125257492065e-01
    z[2,3,4]  R847      4.4833451509475708e-01
    z[2,3,4]  R848      -2.2582834959030151e-01
    z[2,3,4]  R849      4.2494514584541321e-01
    z[2,3,4]  R850      2.3748284205794334e-02
    z[2,3,4]  R851      -5.7107824832201004e-02
    z[2,3,4]  R852      1.9484585523605347e-01
    z[2,3,4]  R853      4.0376982651650906e-03
    z[2,3,4]  R854      1.2568618357181549e-01
    z[2,3,4]  R855      -3.9516729116439819e-01
    z[2,3,4]  R856      -4.3289104104042053e-01
    z[2,3,4]  R857      1.7633788287639618e-01
    z[2,3,4]  R858      -3.3293321728706360e-02
    z[2,3,4]  R859      3.1441393494606018e-01
    z[2,3,4]  R860      2.5045558810234070e-01
    z[2,3,4]  R861      1.5220838785171509e-01
    z[2,3,4]  R862      3.3705178648233414e-02
    z[2,3,4]  R863      -8.6671836674213409e-02
    z[2,3,4]  R864      5.3131759166717529e-01
    z[2,3,4]  R865      -2.8040159493684769e-02
    z[2,3,4]  R866      -1.8048363924026489e-01
    z[2,3,4]  R867      2.8188863396644592e-01
    z[2,3,4]  R868      -0.0724576786160469
    z[2,3,4]  R869      2.1844211220741272e-01
    z[2,3,4]  R870      -1.2153670191764832e-01
    z[2,3,4]  R871      -1.3801916502416134e-02
    z[2,3,4]  R872      2.5893816351890564e-01
    z[2,3,4]  R873      4.8382304608821869e-02
    z[2,3,4]  R874      -2.3363950848579407e-01
    z[2,3,4]  R875      -4.4344505667686462e-01
    z[2,3,5]  R25       -1
    z[2,3,5]  R34       1
    z[2,3,5]  R762      -1
    z[2,3,5]  R763      1
    z[2,3,5]  R766      -1.1111732572317123e-01
    z[2,3,5]  R767      -3.4645661711692810e-01
    z[2,3,5]  R768      -2.6786080002784729e-01
    z[2,3,5]  R769      -3.5867077112197876e-01
    z[2,3,5]  R770      -1.2361617386341095e-01
    z[2,3,5]  R771      -4.2112907767295837e-01
    z[2,3,5]  R772      -1.7349600791931152e-01
    z[2,3,5]  R773      3.4701073169708252e-01
    z[2,3,5]  R774      -5.9970027208328247e-01
    z[2,3,5]  R775      -0.366510272026062
    z[2,3,5]  R776      9.0328685939311981e-02
    z[2,3,5]  R777      -5.6349381804466248e-02
    z[2,3,5]  R778      3.5383901000022888e-01
    z[2,3,5]  R779      -1.0622695088386536e-01
    z[2,3,5]  R780      1.7993077635765076e-02
    z[2,3,5]  R781      1.3508167862892151e-01
    z[2,3,5]  R782      -5.8078831434249878e-01
    z[2,3,5]  R783      -7.3170220851898193e-01
    z[2,3,5]  R784      -1.5470009297132492e-02
    z[2,3,5]  R785      1.0067449510097504e-01
    z[2,3,5]  R786      -2.4939297139644623e-01
    z[2,3,5]  R787      -3.7920403480529785e-01
    z[2,3,5]  R788      -4.9990072846412659e-02
    z[2,3,5]  R789      -1.6136933863162994e-01
    z[2,3,5]  R790      2.8091698884963989e-01
    z[2,3,5]  R791      -5.2493721246719360e-01
    z[2,3,5]  R792      1.8734987080097198e-01
    z[2,3,5]  R793      -3.7610962986946106e-01
    z[2,3,5]  R794      1.9069159030914307e-01
    z[2,3,5]  R795      -2.5586915016174316e-01
    z[2,3,5]  R796      -2.5097039341926575e-01
    z[2,3,5]  R797      -1.9765205681324005e-01
    z[2,3,5]  R798      -6.0160171985626221e-01
    z[2,3,5]  R799      -2.4117382243275642e-02
    z[2,3,5]  R800      -6.6142719984054565e-01
    z[2,3,5]  R801      3.8101503252983093e-01
    z[2,3,5]  R802      3.7576174736022949e-01
    z[2,3,5]  R803      2.6153370738029480e-01
    z[2,3,5]  R804      4.3961510062217712e-01
    z[2,3,5]  R805      -9.5619618892669678e-02
    z[2,3,5]  R806      -1.1721321940422058e-01
    z[2,3,5]  R807      5.0972348451614380e-01
    z[2,3,5]  R808      1.9712999463081360e-01
    z[2,3,5]  R809      -2.6369765400886536e-01
    z[2,3,5]  R810      -3.2655301690101624e-01
    z[2,3,5]  R811      2.4778404831886292e-01
    z[2,3,5]  R812      -4.1140198707580566e-02
    z[2,3,5]  R813      -3.0406689271330833e-02
    z[2,3,5]  R814      4.0036982297897339e-01
    z[2,3,5]  R815      -9.0188682079315186e-02
    z[2,3,5]  R816      -6.9940364360809326e-01
    z[2,3,5]  R817      -7.6825064420700073e-01
    z[2,3,5]  R818      3.1678438186645508e-01
    z[2,3,5]  R819      2.7540540695190430e-01
    z[2,3,5]  R820      3.7043631076812744e-01
    z[2,3,5]  R821      2.2858747839927673e-01
    z[2,3,5]  R822      -1.5789978206157684e-01
    z[2,3,5]  R823      5.8064174652099609e-01
    z[2,3,5]  R824      5.2196395397186279e-01
    z[2,3,5]  R825      0.578454852104187
    z[2,3,5]  R826      -3.7373277544975281e-01
    z[2,3,5]  R827      -2.8061193227767944e-01
    z[2,3,5]  R828      -2.6671119034290314e-02
    z[2,3,5]  R829      -1.1959427595138550e-01
    z[2,3,5]  R830      -3.1937101483345032e-01
    z[2,3,5]  R831      -3.6324670910835266e-01
    z[2,3,5]  R832      -8.2112692296504974e-02
    z[2,3,5]  R833      -6.9876688718795776e-01
    z[2,3,5]  R834      -0.394333153963089
    z[2,3,5]  R835      -4.3859738111495972e-01
    z[2,3,5]  R836      3.3692322671413422e-02
    z[2,3,5]  R837      -1.6348755359649658e-01
    z[2,3,5]  R838      -2.0855288952589035e-02
    z[2,3,5]  R839      2.0821157097816467e-01
    z[2,3,5]  R840      -0.0433766171336174
    z[2,3,5]  R841      -5.6146692484617233e-02
    z[2,3,5]  R842      2.7365830540657043e-01
    z[2,3,5]  R843      2.2968876361846924e-01
    z[2,3,5]  R844      4.4170853495597839e-01
    z[2,3,5]  R845      3.6483103036880493e-01
    z[2,3,5]  R846      -4.5089519023895264e-01
    z[2,3,5]  R847      -2.5357827544212341e-02
    z[2,3,5]  R848      1.5495795011520386e-01
    z[2,3,5]  R849      8.0810030922293663e-03
    z[2,3,5]  R850      0.0723768025636673
    z[2,3,5]  R851      5.9614843130111694e-01
    z[2,3,5]  R852      5.4889399558305740e-02
    z[2,3,5]  R853      -0.197321817278862
    z[2,3,5]  R854      2.7102181687951088e-02
    z[2,3,5]  R855      2.8337183594703674e-01
    z[2,3,5]  R856      0.256511926651001
    z[2,3,5]  R857      -6.9606119394302368e-01
    z[2,3,5]  R858      3.4793254733085632e-01
    z[2,3,5]  R859      4.8544409871101379e-01
    z[2,3,5]  R860      -6.2928862869739532e-02
    z[2,3,5]  R861      4.3521293997764587e-01
    z[2,3,5]  R862      -2.1326787769794464e-02
    z[2,3,5]  R863      1.4439002610743046e-02
    z[2,3,5]  R864      2.5736328959465027e-01
    z[2,3,5]  R865      -3.0850782990455627e-02
    z[2,3,5]  R866      -7.2390139102935791e-01
    z[2,3,5]  R867      2.4870058894157410e-01
    z[2,3,5]  R868      5.1580244302749634e-01
    z[2,3,5]  R869      0.545786440372467
    z[2,3,5]  R870      -3.3381292223930359e-01
    z[2,3,5]  R871      2.2834406793117523e-01
    z[2,3,5]  R872      1.4479791745543480e-02
    z[2,3,5]  R873      1.4484675228595734e-01
    z[2,3,5]  R874      5.0283408164978027e-01
    z[2,3,5]  R875      1.9192793965339661e-01
    z[2,3,6]  R26       -1
    z[2,3,6]  R35       1
    z[2,3,6]  R764      -1
    z[2,3,6]  R765      1
    z[2,3,6]  R766      -1.1575453728437424e-01
    z[2,3,6]  R767      -7.3043704032897949e-02
    z[2,3,6]  R768      -4.1478082537651062e-01
    z[2,3,6]  R769      -2.0926142111420631e-02
    z[2,3,6]  R770      -7.0083987712860107e-01
    z[2,3,6]  R771      1.6672931611537933e-01
    z[2,3,6]  R772      -0.542167603969574
    z[2,3,6]  R773      6.3620530068874359e-02
    z[2,3,6]  R774      -7.9978398978710175e-02
    z[2,3,6]  R775      -5.3863030672073364e-01
    z[2,3,6]  R776      -1.8201902508735657e-01
    z[2,3,6]  R777      7.3884904384613037e-01
    z[2,3,6]  R778      4.8412540555000305e-01
    z[2,3,6]  R779      5.8973014354705811e-01
    z[2,3,6]  R780      3.5702344775199890e-01
    z[2,3,6]  R781      6.3501638174057007e-01
    z[2,3,6]  R782      4.4806458055973053e-02
    z[2,3,6]  R783      1.7744249105453491e-01
    z[2,3,6]  R784      4.4641438126564026e-01
    z[2,3,6]  R785      7.2661107778549194e-01
    z[2,3,6]  R786      -2.1608068048954010e-01
    z[2,3,6]  R787      -0.0524955689907074
    z[2,3,6]  R788      -1.0785356909036636e-01
    z[2,3,6]  R789      4.3899369239807129e-01
    z[2,3,6]  R790      -1.1953758448362350e-01
    z[2,3,6]  R791      -1.1923612095415592e-02
    z[2,3,6]  R792      4.0497392416000366e-01
    z[2,3,6]  R793      2.3242910206317902e-01
    z[2,3,6]  R794      2.7324414253234863e-01
    z[2,3,6]  R795      2.2052489221096039e-02
    z[2,3,6]  R796      3.2474055886268616e-02
    z[2,3,6]  R797      3.3998188376426697e-01
    z[2,3,6]  R798      -1.4878799021244049e-01
    z[2,3,6]  R799      6.0695850849151611e-01
    z[2,3,6]  R800      1.2342663109302521e-01
    z[2,3,6]  R801      -5.0115519762039185e-01
    z[2,3,6]  R802      -4.7997005283832550e-02
    z[2,3,6]  R803      -3.2024788856506348e-01
    z[2,3,6]  R804      -2.0141196250915527e-01
    z[2,3,6]  R805      5.0863599777221680e-01
    z[2,3,6]  R806      2.7666044235229492e-01
    z[2,3,6]  R807      -8.1315249204635620e-02
    z[2,3,6]  R808      -0.344471275806427
    z[2,3,6]  R809      5.9897238016128540e-01
    z[2,3,6]  R810      -1.0502582043409348e-01
    z[2,3,6]  R811      -5.3841298818588257e-01
    z[2,3,6]  R812      1.1015736311674118e-01
    z[2,3,6]  R813      -1.4831455051898956e-01
    z[2,3,6]  R814      5.0073593854904175e-02
    z[2,3,6]  R815      5.9780506417155266e-03
    z[2,3,6]  R816      -2.4168142676353455e-01
    z[2,3,6]  R817      1.7247229814529419e-01
    z[2,3,6]  R818      7.9172827303409576e-02
    z[2,3,6]  R819      2.4253658950328827e-01
    z[2,3,6]  R820      2.8019472956657410e-01
    z[2,3,6]  R821      -3.3731141686439514e-01
    z[2,3,6]  R822      -5.1452624797821045e-01
    z[2,3,6]  R823      2.3528663814067841e-01
    z[2,3,6]  R824      3.3454321324825287e-02
    z[2,3,6]  R825      2.6520317792892456e-01
    z[2,3,6]  R826      -4.3678706884384155e-01
    z[2,3,6]  R827      -4.6456691622734070e-01
    z[2,3,6]  R828      -4.9688091874122620e-01
    z[2,3,6]  R829      -2.5510832667350769e-01
    z[2,3,6]  R830      -2.6143577694892883e-01
    z[2,3,6]  R831      3.9746630191802979e-01
    z[2,3,6]  R832      6.3786321878433228e-01
    z[2,3,6]  R833      3.4531423449516296e-01
    z[2,3,6]  R834      0.658897340297699
    z[2,3,6]  R835      -3.0043545365333557e-01
    z[2,3,6]  R836      4.7700032591819763e-02
    z[2,3,6]  R837      1.6875910758972168e-01
    z[2,3,6]  R838      3.4356853365898132e-01
    z[2,3,6]  R839      -3.2359704375267029e-01
    z[2,3,6]  R840      2.1930399537086487e-01
    z[2,3,6]  R841      -4.2879793792963028e-02
    z[2,3,6]  R842      2.2674646973609924e-01
    z[2,3,6]  R843      3.6886653304100037e-01
    z[2,3,6]  R844      1.3063828647136688e-01
    z[2,3,6]  R845      8.7904646992683411e-02
    z[2,3,6]  R846      -2.1914835274219513e-01
    z[2,3,6]  R847      -4.5325968414545059e-02
    z[2,3,6]  R848      4.7167718410491943e-01
    z[2,3,6]  R849      2.3300263285636902e-01
    z[2,3,6]  R850      -1.8468016386032104e-01
    z[2,3,6]  R851      1.2350400909781456e-02
    z[2,3,6]  R852      -1.1037850379943848e-01
    z[2,3,6]  R853      -1.6299147903919220e-01
    z[2,3,6]  R854      -2.8236522339284420e-03
    z[2,3,6]  R855      3.1427938491106033e-02
    z[2,3,6]  R856      2.0696519315242767e-01
    z[2,3,6]  R857      -3.7461996078491211e-01
    z[2,3,6]  R858      0.565693199634552
    z[2,3,6]  R859      9.2446379363536835e-02
    z[2,3,6]  R860      2.3793274164199829e-01
    z[2,3,6]  R861      1.2363357841968536e-01
    z[2,3,6]  R862      -7.3006264865398407e-02
    z[2,3,6]  R863      6.8720698356628418e-02
    z[2,3,6]  R864      1.3928471505641937e-01
    z[2,3,6]  R865      0.0840034931898117
    z[2,3,6]  R866      4.4490348547697067e-02
    z[2,3,6]  R867      4.0182426571846008e-02
    z[2,3,6]  R868      -7.1369171142578125e-02
    z[2,3,6]  R869      -1.2926366925239563e-01
    z[2,3,6]  R870      -2.9037842154502869e-01
    z[2,3,6]  R871      4.1457340121269226e-01
    z[2,3,6]  R872      2.4589551985263824e-01
    z[2,3,6]  R873      -1.1040373146533966e-01
    z[2,3,6]  R874      -1.0975638777017593e-01
    z[2,3,6]  R875      -2.2316549718379974e-01
    z[3,2,0]  R20       1
    z[3,2,0]  R29       -1
    z[3,2,0]  R876      -1
    z[3,2,0]  R877      1
    z[3,2,0]  R890      -3.4679239988327026e-01
    z[3,2,0]  R891      3.1635525822639465e-01
    z[3,2,0]  R892      2.4061417579650879e-01
    z[3,2,0]  R893      1.3621720671653748e-01
    z[3,2,0]  R894      1.2337982654571533e-01
    z[3,2,0]  R895      -1.5169952809810638e-01
    z[3,2,0]  R896      2.2870300710201263e-01
    z[3,2,0]  R897      -1.9770224392414093e-01
    z[3,2,0]  R898      2.8880143165588379e-01
    z[3,2,0]  R899      -1.5453328192234039e-01
    z[3,2,0]  R900      3.8862389326095581e-01
    z[3,2,0]  R901      3.7091308832168579e-01
    z[3,2,0]  R902      0.478127658367157
    z[3,2,0]  R903      4.6311464905738831e-01
    z[3,2,0]  R904      4.7244840860366821e-01
    z[3,2,0]  R905      -3.2537445425987244e-01
    z[3,2,0]  R906      4.7602352499961853e-01
    z[3,2,0]  R907      2.5705429911613464e-01
    z[3,2,0]  R908      5.9679847955703735e-01
    z[3,2,0]  R909      4.8446375131607056e-01
    z[3,2,0]  R910      -1.4129619300365448e-01
    z[3,2,0]  R911      -2.4598467350006104e-01
    z[3,2,0]  R912      -2.2360714152455330e-02
    z[3,2,0]  R913      4.9472215771675110e-01
    z[3,2,0]  R914      -2.9698467254638672e-01
    z[3,2,0]  R915      9.5166578888893127e-02
    z[3,2,0]  R916      -8.4637673571705818e-03
    z[3,2,0]  R917      3.5379037261009216e-01
    z[3,2,0]  R918      -4.9908825755119324e-01
    z[3,2,0]  R919      2.0909052342176437e-02
    z[3,2,0]  R920      -1.6441054642200470e-01
    z[3,2,0]  R921      -4.1640344262123108e-01
    z[3,2,0]  R922      2.3950491845607758e-01
    z[3,2,0]  R923      -3.0985912680625916e-01
    z[3,2,0]  R924      1.3322702050209045e-01
    z[3,2,0]  R925      2.8159549832344055e-01
    z[3,2,0]  R926      -5.0860035419464111e-01
    z[3,2,0]  R927      -2.9777538776397705e-01
    z[3,2,0]  R928      1.0051559656858444e-01
    z[3,2,0]  R929      -4.4247376918792725e-01
    z[3,2,0]  R930      -1.9971807301044464e-01
    z[3,2,0]  R931      -1.4479297399520874e-01
    z[3,2,0]  R932      3.1530305743217468e-01
    z[3,2,0]  R933      -4.0553700923919678e-01
    z[3,2,0]  R934      2.8023305535316467e-01
    z[3,2,0]  R935      1.1138470470905304e-01
    z[3,2,0]  R936      -1.4050295948982239e-01
    z[3,2,0]  R937      -1.6415895521640778e-01
    z[3,2,0]  R938      -3.0126294121146202e-02
    z[3,2,0]  R939      -2.0682542026042938e-01
    z[3,2,0]  R940      -4.6003714203834534e-01
    z[3,2,0]  R941      -8.5073653608560562e-03
    z[3,2,0]  R942      -5.5655580759048462e-01
    z[3,2,0]  R943      -4.1328959167003632e-02
    z[3,2,0]  R944      1.8384875357151031e-01
    z[3,2,0]  R945      -6.8432295322418213e-01
    z[3,2,0]  R946      -4.3920648097991943e-01
    z[3,2,0]  R947      -2.7425637841224670e-01
    z[3,2,0]  R948      -3.9826804399490356e-01
    z[3,2,0]  R949      3.2798236608505249e-01
    z[3,2,0]  R950      1.9804461300373077e-01
    z[3,2,0]  R951      -7.2348743677139282e-02
    z[3,2,0]  R952      -1.7537489533424377e-02
    z[3,2,0]  R953      0.292106568813324
    z[3,2,0]  R954      0.402878999710083
    z[3,2,0]  R955      -1.2381814420223236e-01
    z[3,2,0]  R956      -2.3071540892124176e-01
    z[3,2,0]  R957      7.0579960942268372e-02
    z[3,2,0]  R958      3.9821188896894455e-02
    z[3,2,0]  R959      -6.1034295707941055e-02
    z[3,2,0]  R960      -1.8003901839256287e-01
    z[3,2,0]  R961      -1.5587781369686127e-01
    z[3,2,0]  R962      1.8529336154460907e-01
    z[3,2,0]  R963      -8.3421230316162109e-02
    z[3,2,0]  R964      -3.2203629612922668e-01
    z[3,2,0]  R965      -4.6948346495628357e-01
    z[3,2,0]  R966      -4.3462562561035156e-01
    z[3,2,0]  R967      -1.4304748177528381e-01
    z[3,2,0]  R968      1.8365567922592163e-01
    z[3,2,0]  R969      -2.8893113136291504e-02
    z[3,2,0]  R970      -3.8958737254142761e-01
    z[3,2,0]  R971      -6.8815350532531738e-02
    z[3,2,0]  R972      2.4270290136337280e-01
    z[3,2,0]  R973      -0.233124777674675
    z[3,2,0]  R974      -2.7780758216977119e-02
    z[3,2,0]  R975      -9.1728426516056061e-02
    z[3,2,0]  R976      1.5637844800949097e-01
    z[3,2,0]  R977      1.3719514012336731e-01
    z[3,2,0]  R978      2.9046159982681274e-01
    z[3,2,0]  R979      -4.0357176214456558e-02
    z[3,2,0]  R980      -0.00798717699944973
    z[3,2,0]  R981      -3.9652702212333679e-01
    z[3,2,0]  R982      2.3141847550868988e-01
    z[3,2,0]  R983      -1.4708544313907623e-01
    z[3,2,0]  R984      2.6743856072425842e-01
    z[3,2,0]  R985      1.0477688163518906e-01
    z[3,2,0]  R986      3.3715635538101196e-01
    z[3,2,0]  R987      4.3467298150062561e-01
    z[3,2,0]  R988      2.1802544593811035e-01
    z[3,2,0]  R989      3.1608527898788452e-01
    z[3,2,0]  R990      -7.1441113948822021e-02
    z[3,2,0]  R991      -1.0171761363744736e-01
    z[3,2,0]  R992      2.2076368331909180e-01
    z[3,2,0]  R993      -4.1067633777856827e-02
    z[3,2,0]  R994      -1.7654503881931305e-01
    z[3,2,0]  R995      1.7004080116748810e-01
    z[3,2,0]  R996      -7.1844369173049927e-02
    z[3,2,0]  R997      1.2535277009010315e-01
    z[3,2,0]  R998      6.0810748487710953e-02
    z[3,2,0]  R999      -1.0493205487728119e-01
    z[3,2,1]  R21       1
    z[3,2,1]  R30       -1
    z[3,2,1]  R878      -1
    z[3,2,1]  R879      1
    z[3,2,1]  R890      -5.2148234844207764e-01
    z[3,2,1]  R891      8.3416923880577087e-02
    z[3,2,1]  R892      -5.1724594831466675e-01
    z[3,2,1]  R893      0.436928391456604
    z[3,2,1]  R894      0.481802374124527
    z[3,2,1]  R895      -4.2934402823448181e-01
    z[3,2,1]  R896      4.3029200285673141e-02
    z[3,2,1]  R897      -3.1166023015975952e-01
    z[3,2,1]  R898      -9.3946449458599091e-02
    z[3,2,1]  R899      2.3569411039352417e-01
    z[3,2,1]  R900      -3.9549741148948669e-01
    z[3,2,1]  R901      -3.2833805680274963e-01
    z[3,2,1]  R902      -4.0744832158088684e-01
    z[3,2,1]  R903      -7.6940737664699554e-02
    z[3,2,1]  R904      -1.4032201468944550e-01
    z[3,2,1]  R905      -2.6081937551498413e-01
    z[3,2,1]  R906      -4.7939816117286682e-01
    z[3,2,1]  R907      -5.7229530811309814e-01
    z[3,2,1]  R908      -1.1862655729055405e-01
    z[3,2,1]  R909      -2.3100028932094574e-01
    z[3,2,1]  R910      -3.8691377639770508e-01
    z[3,2,1]  R911      -1.3536162674427032e-01
    z[3,2,1]  R912      -8.1442302465438843e-01
    z[3,2,1]  R913      2.1609127521514893e-01
    z[3,2,1]  R914      -8.0153423547744751e-01
    z[3,2,1]  R915      -7.2501242160797119e-01
    z[3,2,1]  R916      -9.2812252044677734e-01
    z[3,2,1]  R917      5.6346774101257324e-01
    z[3,2,1]  R918      0.726138710975647
    z[3,2,1]  R919      -0.0324397049844265
    z[3,2,1]  R920      -3.2403391599655151e-01
    z[3,2,1]  R921      -4.0914842486381531e-01
    z[3,2,1]  R922      -5.8479070663452148e-01
    z[3,2,1]  R923      -6.0351520776748657e-01
    z[3,2,1]  R924      1.4922253787517548e-01
    z[3,2,1]  R925      5.9933638572692871e-01
    z[3,2,1]  R926      4.6213066577911377e-01
    z[3,2,1]  R927      0.813393771648407
    z[3,2,1]  R928      4.7956377267837524e-01
    z[3,2,1]  R929      6.3635557889938354e-01
    z[3,2,1]  R930      -3.5282588005065918e-01
    z[3,2,1]  R931      -5.1891523599624634e-01
    z[3,2,1]  R932      -7.3771619796752930e-01
    z[3,2,1]  R933      -6.7508661746978760e-01
    z[3,2,1]  R934      3.8875925540924072e-01
    z[3,2,1]  R935      5.7495909929275513e-01
    z[3,2,1]  R936      5.7786947488784790e-01
    z[3,2,1]  R937      8.9735507965087891e-01
    z[3,2,1]  R938      4.3170607089996338e-01
    z[3,2,1]  R939      7.3682177066802979e-01
    z[3,2,1]  R940      -1.2009544670581818e-01
    z[3,2,1]  R941      -8.1751078367233276e-02
    z[3,2,1]  R942      -1.1944067478179932e-01
    z[3,2,1]  R943      4.1970473527908325e-01
    z[3,2,1]  R944      2.8386149555444717e-02
    z[3,2,1]  R945      -3.3588859438896179e-01
    z[3,2,1]  R946      -3.5688936710357666e-01
    z[3,2,1]  R947      -1.0904785245656967e-01
    z[3,2,1]  R948      2.6019543409347534e-01
    z[3,2,1]  R949      3.2960599660873413e-01
    z[3,2,1]  R950      0.310889333486557
    z[3,2,1]  R951      3.6694172024726868e-01
    z[3,2,1]  R952      2.3732134699821472e-01
    z[3,2,1]  R953      6.3886421918869019e-01
    z[3,2,1]  R954      7.7943336963653564e-01
    z[3,2,1]  R955      -6.4054572582244873e-01
    z[3,2,1]  R956      -3.4550639986991882e-01
    z[3,2,1]  R957      1.6194467246532440e-01
    z[3,2,1]  R958      1.1359908431768417e-01
    z[3,2,1]  R959      2.0492841303348541e-01
    z[3,2,1]  R960      -7.6640337705612183e-02
    z[3,2,1]  R961      -3.9700353145599365e-01
    z[3,2,1]  R962      1.8615961074829102e-01
    z[3,2,1]  R963      -2.4497555196285248e-01
    z[3,2,1]  R964      -4.1259798407554626e-01
    z[3,2,1]  R965      -6.4995211362838745e-01
    z[3,2,1]  R966      -2.0629326999187469e-01
    z[3,2,1]  R967      3.5990167409181595e-02
    z[3,2,1]  R968      5.4702192544937134e-01
    z[3,2,1]  R969      -2.8597798943519592e-01
    z[3,2,1]  R970      -4.1062659025192261e-01
    z[3,2,1]  R971      1.3161525130271912e-01
    z[3,2,1]  R972      1.3473476469516754e-01
    z[3,2,1]  R973      -7.6633952558040619e-02
    z[3,2,1]  R974      -2.4065822362899780e-01
    z[3,2,1]  R975      -3.3735689520835876e-01
    z[3,2,1]  R976      4.1433599591255188e-01
    z[3,2,1]  R977      3.6250334978103638e-01
    z[3,2,1]  R978      4.3162074685096741e-01
    z[3,2,1]  R979      2.9725155234336853e-01
    z[3,2,1]  R980      2.8470417857170105e-01
    z[3,2,1]  R981      -4.2697837948799133e-01
    z[3,2,1]  R982      3.6318513751029968e-01
    z[3,2,1]  R983      1.9550137221813202e-01
    z[3,2,1]  R984      3.1546348333358765e-01
    z[3,2,1]  R985      -1.8552072346210480e-01
    z[3,2,1]  R986      -9.1899514198303223e-01
    z[3,2,1]  R987      -8.7285065650939941e-01
    z[3,2,1]  R988      -8.4027677774429321e-01
    z[3,2,1]  R989      -8.3648532629013062e-01
    z[3,2,1]  R990      -2.1401226520538330e-01
    z[3,2,1]  R991      5.2057977765798569e-02
    z[3,2,1]  R992      4.2800846695899963e-01
    z[3,2,1]  R993      2.6091209053993225e-01
    z[3,2,1]  R994      -8.2916563749313354e-01
    z[3,2,1]  R995      -7.2809213399887085e-01
    z[3,2,1]  R996      -6.6152030229568481e-01
    z[3,2,1]  R997      1.5068809688091278e-01
    z[3,2,1]  R998      -1.2697984278202057e-01
    z[3,2,1]  R999      -1.8668781220912933e-01
    z[3,2,2]  R22       1
    z[3,2,2]  R31       -1
    z[3,2,2]  R880      -1
    z[3,2,2]  R881      1
    z[3,2,2]  R890      1.5335462987422943e-01
    z[3,2,2]  R891      -6.0049909353256226e-01
    z[3,2,2]  R892      5.4962551593780518e-01
    z[3,2,2]  R893      -3.2779499888420105e-01
    z[3,2,2]  R894      -3.8564798235893250e-01
    z[3,2,2]  R895      -4.9620741046965122e-03
    z[3,2,2]  R896      -4.8943346738815308e-01
    z[3,2,2]  R897      1.8296520411968231e-01
    z[3,2,2]  R898      -4.2893221974372864e-01
    z[3,2,2]  R899      -2.5571811944246292e-02
    z[3,2,2]  R900      3.3236268162727356e-01
    z[3,2,2]  R901      4.7776794433593750e-01
    z[3,2,2]  R902      5.4234284162521362e-01
    z[3,2,2]  R903      3.3731272816658020e-01
    z[3,2,2]  R904      6.2042981386184692e-01
    z[3,2,2]  R905      -4.3763765692710876e-01
    z[3,2,2]  R906      2.6428681612014771e-01
    z[3,2,2]  R907      1.4328658580780029e-03
    z[3,2,2]  R908      3.2177260518074036e-01
    z[3,2,2]  R909      1.7702539265155792e-01
    z[3,2,2]  R910      -7.1257036924362183e-01
    z[3,2,2]  R911      -5.8643120527267456e-01
    z[3,2,2]  R912      -1.3432666659355164e-01
    z[3,2,2]  R913      4.8286509513854980e-01
    z[3,2,2]  R914      -4.7755271196365356e-01
    z[3,2,2]  R915      -2.8411459922790527e-01
    z[3,2,2]  R916      -1.3416558504104614e-01
    z[3,2,2]  R917      7.0129656791687012e-01
    z[3,2,2]  R918      -3.3579519391059875e-01
    z[3,2,2]  R919      1.0880029201507568e-01
    z[3,2,2]  R920      -0.604345440864563
    z[3,2,2]  R921      -2.9558802023530006e-02
    z[3,2,2]  R922      1.1722157150506973e-01
    z[3,2,2]  R923      3.9034938812255859e-01
    z[3,2,2]  R924      4.1221952438354492e-01
    z[3,2,2]  R925      -1.5346366167068481e-01
    z[3,2,2]  R926      -6.5238827466964722e-01
    z[3,2,2]  R927      -4.8277732729911804e-01
    z[3,2,2]  R928      6.8101976066827774e-03
    z[3,2,2]  R929      -5.9404021501541138e-01
    z[3,2,2]  R930      -3.6452940106391907e-01
    z[3,2,2]  R931      -2.5705328583717346e-01
    z[3,2,2]  R932      -5.0469189882278442e-03
    z[3,2,2]  R933      1.0578592121601105e-01
    z[3,2,2]  R934      6.2631016969680786e-01
    z[3,2,2]  R935      -2.6241201162338257e-01
    z[3,2,2]  R936      -9.8471298813819885e-02
    z[3,2,2]  R937      -3.2202121615409851e-01
    z[3,2,2]  R938      -2.2024551033973694e-01
    z[3,2,2]  R939      -3.5296049714088440e-01
    z[3,2,2]  R940      -1.4356851577758789e-01
    z[3,2,2]  R941      0.729804277420044
    z[3,2,2]  R942      -2.6146861910820007e-01
    z[3,2,2]  R943      -3.0947241187095642e-01
    z[3,2,2]  R944      -5.2568817138671875e-01
    z[3,2,2]  R945      -4.1015830636024475e-01
    z[3,2,2]  R946      -2.6602697372436523e-01
    z[3,2,2]  R947      5.3871631622314453e-01
    z[3,2,2]  R948      -1.6271330416202545e-01
    z[3,2,2]  R949      -3.7800505757331848e-01
    z[3,2,2]  R950      0.69382244348526
    z[3,2,2]  R951      3.9817529916763306e-01
    z[3,2,2]  R952      -7.6352918148040771e-01
    z[3,2,2]  R953      2.0025306940078735e-01
    z[3,2,2]  R954      3.0574655532836914e-01
    z[3,2,2]  R955      2.9796570539474487e-01
    z[3,2,2]  R956      2.2964215278625488e-01
    z[3,2,2]  R957      3.6519104242324829e-01
    z[3,2,2]  R958      -6.5180528163909912e-01
    z[3,2,2]  R959      -4.6473458409309387e-01
    z[3,2,2]  R960      5.0008010864257812e-01
    z[3,2,2]  R961      5.1603639125823975e-01
    z[3,2,2]  R962      7.4964660406112671e-01
    z[3,2,2]  R963      6.6788399219512939e-01
    z[3,2,2]  R964      -7.1688455343246460e-01
    z[3,2,2]  R965      1.4531970024108887e-01
    z[3,2,2]  R966      -7.0390887558460236e-02
    z[3,2,2]  R967      -9.6790179610252380e-02
    z[3,2,2]  R968      3.4134072065353394e-01
    z[3,2,2]  R969      -7.9266905784606934e-01
    z[3,2,2]  R970      2.1038149297237396e-01
    z[3,2,2]  R971      -7.8002011775970459e-01
    z[3,2,2]  R972      -7.2178280353546143e-01
    z[3,2,2]  R973      6.2027710676193237e-01
    z[3,2,2]  R974      -5.2359807491302490e-01
    z[3,2,2]  R975      2.7404937148094177e-01
    z[3,2,2]  R976      7.2649180889129639e-01
    z[3,2,2]  R977      -2.9205662012100220e-01
    z[3,2,2]  R978      6.9390803575515747e-01
    z[3,2,2]  R979      -0.504687488079071
    z[3,2,2]  R980      6.4094376564025879e-01
    z[3,2,2]  R981      5.0092363357543945e-01
    z[3,2,2]  R982      5.5363011360168457e-01
    z[3,2,2]  R983      6.6597777605056763e-01
    z[3,2,2]  R984      7.9786878824234009e-01
    z[3,2,2]  R985      7.3170125484466553e-01
    z[3,2,2]  R986      -1.2281985580921173e-01
    z[3,2,2]  R987      1.1112658679485321e-01
    z[3,2,2]  R988      1.9943784177303314e-01
    z[3,2,2]  R989      -1.5234960615634918e-01
    z[3,2,2]  R990      3.9555743336677551e-01
    z[3,2,2]  R991      4.0862086415290833e-01
    z[3,2,2]  R992      7.8288817405700684e-01
    z[3,2,2]  R993      -1.1294302530586720e-02
    z[3,2,2]  R994      -6.9810695946216583e-02
    z[3,2,2]  R995      -2.8861811757087708e-01
    z[3,2,2]  R996      4.2097836732864380e-02
    z[3,2,2]  R997      1.5735620632767677e-02
    z[3,2,2]  R998      -0.131294846534729
    z[3,2,2]  R999      2.8363198041915894e-02
    z[3,2,3]  R23       1
    z[3,2,3]  R32       -1
    z[3,2,3]  R882      -1
    z[3,2,3]  R883      1
    z[3,2,3]  R890      1.3980150222778320e-01
    z[3,2,3]  R891      -4.8543652892112732e-01
    z[3,2,3]  R892      0.349149614572525
    z[3,2,3]  R893      -7.0498067140579224e-01
    z[3,2,3]  R894      -6.4381921291351318e-01
    z[3,2,3]  R895      2.5701728463172913e-01
    z[3,2,3]  R896      -5.4006010293960571e-01
    z[3,2,3]  R897      -0.0647614598274231
    z[3,2,3]  R898      -1.8884766101837158e-01
    z[3,2,3]  R899      -4.9562579393386841e-01
    z[3,2,3]  R900      -7.6045602560043335e-01
    z[3,2,3]  R901      -6.8463677167892456e-01
    z[3,2,3]  R902      -3.7467747926712036e-01
    z[3,2,3]  R903      -7.0945578813552856e-01
    z[3,2,3]  R904      -4.7919160127639771e-01
    z[3,2,3]  R905      -6.2790863215923309e-02
    z[3,2,3]  R906      -5.4137378931045532e-01
    z[3,2,3]  R907      -6.1908680200576782e-01
    z[3,2,3]  R908      -5.0925046205520630e-01
    z[3,2,3]  R909      -5.1862555742263794e-01
    z[3,2,3]  R910      0.0450817309319973
    z[3,2,3]  R911      -6.1120027303695679e-01
    z[3,2,3]  R912      1.4381159842014313e-01
    z[3,2,3]  R913      -4.9036917090415955e-01
    z[3,2,3]  R914      -3.7112716585397720e-02
    z[3,2,3]  R915      1.6053833067417145e-01
    z[3,2,3]  R916      -2.5952902436256409e-01
    z[3,2,3]  R917      -1.0738559067249298e-03
    z[3,2,3]  R918      3.0714073777198792e-01
    z[3,2,3]  R919      8.6557984352111816e-01
    z[3,2,3]  R920      -4.5465391874313354e-01
    z[3,2,3]  R921      -4.8944808542728424e-02
    z[3,2,3]  R922      3.8044983148574829e-01
    z[3,2,3]  R923      -2.1053658425807953e-01
    z[3,2,3]  R924      8.1655263900756836e-01
    z[3,2,3]  R925      -5.5685347318649292e-01
    z[3,2,3]  R926      3.0859303474426270e-01
    z[3,2,3]  R927      -6.4833253622055054e-02
    z[3,2,3]  R928      6.2604665756225586e-01
    z[3,2,3]  R929      1.9388185441493988e-01
    z[3,2,3]  R930      -3.7968146800994873e-01
    z[3,2,3]  R931      7.0764243602752686e-01
    z[3,2,3]  R932      -2.8273233771324158e-01
    z[3,2,3]  R933      7.9361535608768463e-02
    z[3,2,3]  R934      -4.0932792425155640e-01
    z[3,2,3]  R935      -6.0328519344329834e-01
    z[3,2,3]  R936      7.1337640285491943e-01
    z[3,2,3]  R937      1.6910864412784576e-01
    z[3,2,3]  R938      6.6688686609268188e-01
    z[3,2,3]  R939      8.0330856144428253e-02
    z[3,2,3]  R940      -7.7471143007278442e-01
    z[3,2,3]  R941      -1.9912803173065186e-01
    z[3,2,3]  R942      -5.9046244621276855e-01
    z[3,2,3]  R943      -7.7111244201660156e-01
    z[3,2,3]  R944      -4.2575830221176147e-01
    z[3,2,3]  R945      -2.1329177916049957e-01
    z[3,2,3]  R946      -4.8338085412979126e-01
    z[3,2,3]  R947      -0.650117039680481
    z[3,2,3]  R948      -6.1055636405944824e-01
    z[3,2,3]  R949      -4.4781497120857239e-01
    z[3,2,3]  R950      5.2484970539808273e-02
    z[3,2,3]  R951      -7.0237023464869708e-05
    z[3,2,3]  R952      2.7089977636933327e-02
    z[3,2,3]  R953      1.3784949481487274e-01
    z[3,2,3]  R954      0.0763256624341011
    z[3,2,3]  R955      2.3601779341697693e-01
    z[3,2,3]  R956      2.1000732481479645e-01
    z[3,2,3]  R957      1.4069318771362305e-01
    z[3,2,3]  R958      1.5281075239181519e-01
    z[3,2,3]  R959      3.3632174134254456e-02
    z[3,2,3]  R960      -0.602166473865509
    z[3,2,3]  R961      -2.8964528441429138e-01
    z[3,2,3]  R962      -3.9659479260444641e-01
    z[3,2,3]  R963      -1.0696002095937729e-01
    z[3,2,3]  R964      -1.8552352488040924e-01
    z[3,2,3]  R965      -2.3194706439971924e-01
    z[3,2,3]  R966      -6.7049944400787354e-01
    z[3,2,3]  R967      -6.8894618749618530e-01
    z[3,2,3]  R968      -4.6335729956626892e-01
    z[3,2,3]  R969      4.5260539650917053e-01
    z[3,2,3]  R970      -0.627235472202301
    z[3,2,3]  R971      -3.8507196307182312e-01
    z[3,2,3]  R972      0.0701432153582573
    z[3,2,3]  R973      1.5927150845527649e-02
    z[3,2,3]  R974      2.8033575415611267e-01
    z[3,2,3]  R975      -2.9147097468376160e-01
    z[3,2,3]  R976      -2.4210660159587860e-01
    z[3,2,3]  R977      -6.0953539609909058e-01
    z[3,2,3]  R978      -1.1136322468519211e-01
    z[3,2,3]  R979      -1.5046467073261738e-02
    z[3,2,3]  R980      -5.2768802642822266e-01
    z[3,2,3]  R981      -3.6627539992332458e-01
    z[3,2,3]  R982      -5.4008686542510986e-01
    z[3,2,3]  R983      -0.152797669172287
    z[3,2,3]  R984      1.4392603933811188e-01
    z[3,2,3]  R985      2.5546967983245850e-01
    z[3,2,3]  R986      -6.3771359622478485e-02
    z[3,2,3]  R987      6.0601551085710526e-02
    z[3,2,3]  R988      0.191497340798378
    z[3,2,3]  R989      3.2247364521026611e-01
    z[3,2,3]  R990      -3.7331116199493408e-01
    z[3,2,3]  R991      -4.4019228219985962e-01
    z[3,2,3]  R992      -7.8483417630195618e-02
    z[3,2,3]  R993      -8.9167469739913940e-01
    z[3,2,3]  R994      2.2209782898426056e-01
    z[3,2,3]  R995      4.2631953954696655e-01
    z[3,2,3]  R996      0.506289541721344
    z[3,2,3]  R997      7.1076595783233643e-01
    z[3,2,3]  R998      8.1934696435928345e-01
    z[3,2,3]  R999      7.1757531166076660e-01
    z[3,2,4]  R24       1
    z[3,2,4]  R33       -1
    z[3,2,4]  R884      -1
    z[3,2,4]  R885      1
    z[3,2,4]  R890      -4.8401427268981934e-01
    z[3,2,4]  R891      4.6343751251697540e-02
    z[3,2,4]  R892      5.4460112005472183e-02
    z[3,2,4]  R893      -3.2666212320327759e-01
    z[3,2,4]  R894      1.3809368014335632e-01
    z[3,2,4]  R895      6.6078805923461914e-01
    z[3,2,4]  R896      -3.1959589570760727e-02
    z[3,2,4]  R897      4.6754062175750732e-01
    z[3,2,4]  R898      -3.1381070613861084e-01
    z[3,2,4]  R899      -6.2581133842468262e-01
    z[3,2,4]  R900      -1.9610758870840073e-02
    z[3,2,4]  R901      -4.9195587635040283e-02
    z[3,2,4]  R902      2.2888121008872986e-01
    z[3,2,4]  R903      1.2012667208909988e-01
    z[3,2,4]  R904      -3.0425125360488892e-01
    z[3,2,4]  R905      -7.9097676277160645e-01
    z[3,2,4]  R906      2.3311580717563629e-01
    z[3,2,4]  R907      -1.8523296713829041e-01
    z[3,2,4]  R908      2.3390786349773407e-01
    z[3,2,4]  R909      5.2037900686264038e-01
    z[3,2,4]  R910      -2.6308125257492065e-01
    z[3,2,4]  R911      4.4833451509475708e-01
    z[3,2,4]  R912      -2.2582834959030151e-01
    z[3,2,4]  R913      4.2494514584541321e-01
    z[3,2,4]  R914      2.3748284205794334e-02
    z[3,2,4]  R915      -5.7107824832201004e-02
    z[3,2,4]  R916      1.9484585523605347e-01
    z[3,2,4]  R917      4.0376982651650906e-03
    z[3,2,4]  R918      1.2568618357181549e-01
    z[3,2,4]  R919      -3.9516729116439819e-01
    z[3,2,4]  R920      -4.3289104104042053e-01
    z[3,2,4]  R921      1.7633788287639618e-01
    z[3,2,4]  R922      -3.3293321728706360e-02
    z[3,2,4]  R923      3.1441393494606018e-01
    z[3,2,4]  R924      2.5045558810234070e-01
    z[3,2,4]  R925      1.5220838785171509e-01
    z[3,2,4]  R926      3.3705178648233414e-02
    z[3,2,4]  R927      -8.6671836674213409e-02
    z[3,2,4]  R928      5.3131759166717529e-01
    z[3,2,4]  R929      -2.8040159493684769e-02
    z[3,2,4]  R930      -1.8048363924026489e-01
    z[3,2,4]  R931      2.8188863396644592e-01
    z[3,2,4]  R932      -0.0724576786160469
    z[3,2,4]  R933      2.1844211220741272e-01
    z[3,2,4]  R934      -1.2153670191764832e-01
    z[3,2,4]  R935      -1.3801916502416134e-02
    z[3,2,4]  R936      2.5893816351890564e-01
    z[3,2,4]  R937      4.8382304608821869e-02
    z[3,2,4]  R938      -2.3363950848579407e-01
    z[3,2,4]  R939      -4.4344505667686462e-01
    z[3,2,4]  R940      -3.5694119334220886e-01
    z[3,2,4]  R941      5.4370075464248657e-01
    z[3,2,4]  R942      1.2318822741508484e-01
    z[3,2,4]  R943      5.1668293774127960e-02
    z[3,2,4]  R944      -3.6304976791143417e-02
    z[3,2,4]  R945      -3.0530476942658424e-03
    z[3,2,4]  R946      -2.2639280557632446e-01
    z[3,2,4]  R947      2.7488246560096741e-01
    z[3,2,4]  R948      9.1593027114868164e-02
    z[3,2,4]  R949      -1.2613105773925781e-01
    z[3,2,4]  R950      -5.8197224140167236e-01
    z[3,2,4]  R951      -3.9051589369773865e-01
    z[3,2,4]  R952      -9.0018799528479576e-03
    z[3,2,4]  R953      2.9724881052970886e-01
    z[3,2,4]  R954      -5.5463850498199463e-02
    z[3,2,4]  R955      9.1593697667121887e-02
    z[3,2,4]  R956      -6.2548726797103882e-01
    z[3,2,4]  R957      -4.9875780940055847e-01
    z[3,2,4]  R958      5.8119124174118042e-01
    z[3,2,4]  R959      4.4617357850074768e-01
    z[3,2,4]  R960      -4.9004080891609192e-01
    z[3,2,4]  R961      -5.6687819957733154e-01
    z[3,2,4]  R962      -4.4454705715179443e-01
    z[3,2,4]  R963      -5.0671774148941040e-01
    z[3,2,4]  R964      -2.9070526361465454e-01
    z[3,2,4]  R965      -8.0801740288734436e-02
    z[3,2,4]  R966      3.3899176120758057e-01
    z[3,2,4]  R967      5.4657596349716187e-01
    z[3,2,4]  R968      4.7412925958633423e-01
    z[3,2,4]  R969      1.3509477674961090e-01
    z[3,2,4]  R970      4.2176067829132080e-01
    z[3,2,4]  R971      2.5802356004714966e-01
    z[3,2,4]  R972      1.1396868526935577e-01
    z[3,2,4]  R973      4.3104812502861023e-01
    z[3,2,4]  R974      3.6857652664184570e-01
    z[3,2,4]  R975      5.6691169738769531e-01
    z[3,2,4]  R976      -2.7196460962295532e-01
    z[3,2,4]  R977      -4.7114729881286621e-01
    z[3,2,4]  R978      3.9963617920875549e-02
    z[3,2,4]  R979      -6.2227261066436768e-01
    z[3,2,4]  R980      3.7327775359153748e-01
    z[3,2,4]  R981      9.4569891691207886e-02
    z[3,2,4]  R982      2.4253083765506744e-01
    z[3,2,4]  R983      -2.1205490827560425e-01
    z[3,2,4]  R984      -2.3234188556671143e-01
    z[3,2,4]  R985      0.0516420416533947
    z[3,2,4]  R986      9.3780837953090668e-02
    z[3,2,4]  R987      1.0123088210821152e-01
    z[3,2,4]  R988      8.4556154906749725e-02
    z[3,2,4]  R989      -2.5497657060623169e-01
    z[3,2,4]  R990      3.2510408759117126e-01
    z[3,2,4]  R991      -7.9041332006454468e-02
    z[3,2,4]  R992      2.0585921406745911e-01
    z[3,2,4]  R993      1.8836686387658119e-02
    z[3,2,4]  R994      1.0669153183698654e-01
    z[3,2,4]  R995      9.9437877535820007e-02
    z[3,2,4]  R996      9.7253829240798950e-02
    z[3,2,4]  R997      -2.5226840376853943e-01
    z[3,2,4]  R998      -1.3433134555816650e-01
    z[3,2,4]  R999      -1.8296252191066742e-01
    z[3,2,5]  R25       1
    z[3,2,5]  R34       -1
    z[3,2,5]  R886      -1
    z[3,2,5]  R887      1
    z[3,2,5]  R890      -3.7373277544975281e-01
    z[3,2,5]  R891      -2.8061193227767944e-01
    z[3,2,5]  R892      -2.6671119034290314e-02
    z[3,2,5]  R893      -1.1959427595138550e-01
    z[3,2,5]  R894      -3.1937101483345032e-01
    z[3,2,5]  R895      -3.6324670910835266e-01
    z[3,2,5]  R896      -8.2112692296504974e-02
    z[3,2,5]  R897      -6.9876688718795776e-01
    z[3,2,5]  R898      -0.394333153963089
    z[3,2,5]  R899      -4.3859738111495972e-01
    z[3,2,5]  R900      3.3692322671413422e-02
    z[3,2,5]  R901      -1.6348755359649658e-01
    z[3,2,5]  R902      -2.0855288952589035e-02
    z[3,2,5]  R903      2.0821157097816467e-01
    z[3,2,5]  R904      -0.0433766171336174
    z[3,2,5]  R905      -5.6146692484617233e-02
    z[3,2,5]  R906      2.7365830540657043e-01
    z[3,2,5]  R907      2.2968876361846924e-01
    z[3,2,5]  R908      4.4170853495597839e-01
    z[3,2,5]  R909      3.6483103036880493e-01
    z[3,2,5]  R910      -4.5089519023895264e-01
    z[3,2,5]  R911      -2.5357827544212341e-02
    z[3,2,5]  R912      1.5495795011520386e-01
    z[3,2,5]  R913      8.0810030922293663e-03
    z[3,2,5]  R914      0.0723768025636673
    z[3,2,5]  R915      5.9614843130111694e-01
    z[3,2,5]  R916      5.4889399558305740e-02
    z[3,2,5]  R917      -0.197321817278862
    z[3,2,5]  R918      2.7102181687951088e-02
    z[3,2,5]  R919      2.8337183594703674e-01
    z[3,2,5]  R920      0.256511926651001
    z[3,2,5]  R921      -6.9606119394302368e-01
    z[3,2,5]  R922      3.4793254733085632e-01
    z[3,2,5]  R923      4.8544409871101379e-01
    z[3,2,5]  R924      -6.2928862869739532e-02
    z[3,2,5]  R925      4.3521293997764587e-01
    z[3,2,5]  R926      -2.1326787769794464e-02
    z[3,2,5]  R927      1.4439002610743046e-02
    z[3,2,5]  R928      2.5736328959465027e-01
    z[3,2,5]  R929      -3.0850782990455627e-02
    z[3,2,5]  R930      -7.2390139102935791e-01
    z[3,2,5]  R931      2.4870058894157410e-01
    z[3,2,5]  R932      5.1580244302749634e-01
    z[3,2,5]  R933      0.545786440372467
    z[3,2,5]  R934      -3.3381292223930359e-01
    z[3,2,5]  R935      2.2834406793117523e-01
    z[3,2,5]  R936      1.4479791745543480e-02
    z[3,2,5]  R937      1.4484675228595734e-01
    z[3,2,5]  R938      5.0283408164978027e-01
    z[3,2,5]  R939      1.9192793965339661e-01
    z[3,2,5]  R940      -1.1111732572317123e-01
    z[3,2,5]  R941      -3.4645661711692810e-01
    z[3,2,5]  R942      -2.6786080002784729e-01
    z[3,2,5]  R943      -3.5867077112197876e-01
    z[3,2,5]  R944      -1.2361617386341095e-01
    z[3,2,5]  R945      -4.2112907767295837e-01
    z[3,2,5]  R946      -1.7349600791931152e-01
    z[3,2,5]  R947      3.4701073169708252e-01
    z[3,2,5]  R948      -5.9970027208328247e-01
    z[3,2,5]  R949      -0.366510272026062
    z[3,2,5]  R950      9.0328685939311981e-02
    z[3,2,5]  R951      -5.6349381804466248e-02
    z[3,2,5]  R952      3.5383901000022888e-01
    z[3,2,5]  R953      -1.0622695088386536e-01
    z[3,2,5]  R954      1.7993077635765076e-02
    z[3,2,5]  R955      1.3508167862892151e-01
    z[3,2,5]  R956      -5.8078831434249878e-01
    z[3,2,5]  R957      -7.3170220851898193e-01
    z[3,2,5]  R958      -1.5470009297132492e-02
    z[3,2,5]  R959      1.0067449510097504e-01
    z[3,2,5]  R960      -2.4939297139644623e-01
    z[3,2,5]  R961      -3.7920403480529785e-01
    z[3,2,5]  R962      -4.9990072846412659e-02
    z[3,2,5]  R963      -1.6136933863162994e-01
    z[3,2,5]  R964      2.8091698884963989e-01
    z[3,2,5]  R965      -5.2493721246719360e-01
    z[3,2,5]  R966      1.8734987080097198e-01
    z[3,2,5]  R967      -3.7610962986946106e-01
    z[3,2,5]  R968      1.9069159030914307e-01
    z[3,2,5]  R969      -2.5586915016174316e-01
    z[3,2,5]  R970      -2.5097039341926575e-01
    z[3,2,5]  R971      -1.9765205681324005e-01
    z[3,2,5]  R972      -6.0160171985626221e-01
    z[3,2,5]  R973      -2.4117382243275642e-02
    z[3,2,5]  R974      -6.6142719984054565e-01
    z[3,2,5]  R975      3.8101503252983093e-01
    z[3,2,5]  R976      3.7576174736022949e-01
    z[3,2,5]  R977      2.6153370738029480e-01
    z[3,2,5]  R978      4.3961510062217712e-01
    z[3,2,5]  R979      -9.5619618892669678e-02
    z[3,2,5]  R980      -1.1721321940422058e-01
    z[3,2,5]  R981      5.0972348451614380e-01
    z[3,2,5]  R982      1.9712999463081360e-01
    z[3,2,5]  R983      -2.6369765400886536e-01
    z[3,2,5]  R984      -3.2655301690101624e-01
    z[3,2,5]  R985      2.4778404831886292e-01
    z[3,2,5]  R986      -4.1140198707580566e-02
    z[3,2,5]  R987      -3.0406689271330833e-02
    z[3,2,5]  R988      4.0036982297897339e-01
    z[3,2,5]  R989      -9.0188682079315186e-02
    z[3,2,5]  R990      -6.9940364360809326e-01
    z[3,2,5]  R991      -7.6825064420700073e-01
    z[3,2,5]  R992      3.1678438186645508e-01
    z[3,2,5]  R993      2.7540540695190430e-01
    z[3,2,5]  R994      3.7043631076812744e-01
    z[3,2,5]  R995      2.2858747839927673e-01
    z[3,2,5]  R996      -1.5789978206157684e-01
    z[3,2,5]  R997      5.8064174652099609e-01
    z[3,2,5]  R998      5.2196395397186279e-01
    z[3,2,5]  R999      0.578454852104187
    z[3,2,6]  R26       1
    z[3,2,6]  R35       -1
    z[3,2,6]  R888      -1
    z[3,2,6]  R889      1
    z[3,2,6]  R890      -4.3678706884384155e-01
    z[3,2,6]  R891      -4.6456691622734070e-01
    z[3,2,6]  R892      -4.9688091874122620e-01
    z[3,2,6]  R893      -2.5510832667350769e-01
    z[3,2,6]  R894      -2.6143577694892883e-01
    z[3,2,6]  R895      3.9746630191802979e-01
    z[3,2,6]  R896      6.3786321878433228e-01
    z[3,2,6]  R897      3.4531423449516296e-01
    z[3,2,6]  R898      0.658897340297699
    z[3,2,6]  R899      -3.0043545365333557e-01
    z[3,2,6]  R900      4.7700032591819763e-02
    z[3,2,6]  R901      1.6875910758972168e-01
    z[3,2,6]  R902      3.4356853365898132e-01
    z[3,2,6]  R903      -3.2359704375267029e-01
    z[3,2,6]  R904      2.1930399537086487e-01
    z[3,2,6]  R905      -4.2879793792963028e-02
    z[3,2,6]  R906      2.2674646973609924e-01
    z[3,2,6]  R907      3.6886653304100037e-01
    z[3,2,6]  R908      1.3063828647136688e-01
    z[3,2,6]  R909      8.7904646992683411e-02
    z[3,2,6]  R910      -2.1914835274219513e-01
    z[3,2,6]  R911      -4.5325968414545059e-02
    z[3,2,6]  R912      4.7167718410491943e-01
    z[3,2,6]  R913      2.3300263285636902e-01
    z[3,2,6]  R914      -1.8468016386032104e-01
    z[3,2,6]  R915      1.2350400909781456e-02
    z[3,2,6]  R916      -1.1037850379943848e-01
    z[3,2,6]  R917      -1.6299147903919220e-01
    z[3,2,6]  R918      -2.8236522339284420e-03
    z[3,2,6]  R919      3.1427938491106033e-02
    z[3,2,6]  R920      2.0696519315242767e-01
    z[3,2,6]  R921      -3.7461996078491211e-01
    z[3,2,6]  R922      0.565693199634552
    z[3,2,6]  R923      9.2446379363536835e-02
    z[3,2,6]  R924      2.3793274164199829e-01
    z[3,2,6]  R925      1.2363357841968536e-01
    z[3,2,6]  R926      -7.3006264865398407e-02
    z[3,2,6]  R927      6.8720698356628418e-02
    z[3,2,6]  R928      1.3928471505641937e-01
    z[3,2,6]  R929      0.0840034931898117
    z[3,2,6]  R930      4.4490348547697067e-02
    z[3,2,6]  R931      4.0182426571846008e-02
    z[3,2,6]  R932      -7.1369171142578125e-02
    z[3,2,6]  R933      -1.2926366925239563e-01
    z[3,2,6]  R934      -2.9037842154502869e-01
    z[3,2,6]  R935      4.1457340121269226e-01
    z[3,2,6]  R936      2.4589551985263824e-01
    z[3,2,6]  R937      -1.1040373146533966e-01
    z[3,2,6]  R938      -1.0975638777017593e-01
    z[3,2,6]  R939      -2.2316549718379974e-01
    z[3,2,6]  R940      -1.1575453728437424e-01
    z[3,2,6]  R941      -7.3043704032897949e-02
    z[3,2,6]  R942      -4.1478082537651062e-01
    z[3,2,6]  R943      -2.0926142111420631e-02
    z[3,2,6]  R944      -7.0083987712860107e-01
    z[3,2,6]  R945      1.6672931611537933e-01
    z[3,2,6]  R946      -0.542167603969574
    z[3,2,6]  R947      6.3620530068874359e-02
    z[3,2,6]  R948      -7.9978398978710175e-02
    z[3,2,6]  R949      -5.3863030672073364e-01
    z[3,2,6]  R950      -1.8201902508735657e-01
    z[3,2,6]  R951      7.3884904384613037e-01
    z[3,2,6]  R952      4.8412540555000305e-01
    z[3,2,6]  R953      5.8973014354705811e-01
    z[3,2,6]  R954      3.5702344775199890e-01
    z[3,2,6]  R955      6.3501638174057007e-01
    z[3,2,6]  R956      4.4806458055973053e-02
    z[3,2,6]  R957      1.7744249105453491e-01
    z[3,2,6]  R958      4.4641438126564026e-01
    z[3,2,6]  R959      7.2661107778549194e-01
    z[3,2,6]  R960      -2.1608068048954010e-01
    z[3,2,6]  R961      -0.0524955689907074
    z[3,2,6]  R962      -1.0785356909036636e-01
    z[3,2,6]  R963      4.3899369239807129e-01
    z[3,2,6]  R964      -1.1953758448362350e-01
    z[3,2,6]  R965      -1.1923612095415592e-02
    z[3,2,6]  R966      4.0497392416000366e-01
    z[3,2,6]  R967      2.3242910206317902e-01
    z[3,2,6]  R968      2.7324414253234863e-01
    z[3,2,6]  R969      2.2052489221096039e-02
    z[3,2,6]  R970      3.2474055886268616e-02
    z[3,2,6]  R971      3.3998188376426697e-01
    z[3,2,6]  R972      -1.4878799021244049e-01
    z[3,2,6]  R973      6.0695850849151611e-01
    z[3,2,6]  R974      1.2342663109302521e-01
    z[3,2,6]  R975      -5.0115519762039185e-01
    z[3,2,6]  R976      -4.7997005283832550e-02
    z[3,2,6]  R977      -3.2024788856506348e-01
    z[3,2,6]  R978      -2.0141196250915527e-01
    z[3,2,6]  R979      5.0863599777221680e-01
    z[3,2,6]  R980      2.7666044235229492e-01
    z[3,2,6]  R981      -8.1315249204635620e-02
    z[3,2,6]  R982      -0.344471275806427
    z[3,2,6]  R983      5.9897238016128540e-01
    z[3,2,6]  R984      -1.0502582043409348e-01
    z[3,2,6]  R985      -5.3841298818588257e-01
    z[3,2,6]  R986      1.1015736311674118e-01
    z[3,2,6]  R987      -1.4831455051898956e-01
    z[3,2,6]  R988      5.0073593854904175e-02
    z[3,2,6]  R989      5.9780506417155266e-03
    z[3,2,6]  R990      -2.4168142676353455e-01
    z[3,2,6]  R991      1.7247229814529419e-01
    z[3,2,6]  R992      7.9172827303409576e-02
    z[3,2,6]  R993      2.4253658950328827e-01
    z[3,2,6]  R994      2.8019472956657410e-01
    z[3,2,6]  R995      -3.3731141686439514e-01
    z[3,2,6]  R996      -5.1452624797821045e-01
    z[3,2,6]  R997      2.3528663814067841e-01
    z[3,2,6]  R998      3.3454321324825287e-02
    z[3,2,6]  R999      2.6520317792892456e-01
    z[3,4,0]  R29       -1
    z[3,4,0]  R38       1
    z[3,4,0]  R1000     -1
    z[3,4,0]  R1001     1
    z[3,4,0]  R1014     -3.4679239988327026e-01
    z[3,4,0]  R1015     3.1635525822639465e-01
    z[3,4,0]  R1016     2.4061417579650879e-01
    z[3,4,0]  R1017     1.3621720671653748e-01
    z[3,4,0]  R1018     1.2337982654571533e-01
    z[3,4,0]  R1019     -1.5169952809810638e-01
    z[3,4,0]  R1020     2.2870300710201263e-01
    z[3,4,0]  R1021     -1.9770224392414093e-01
    z[3,4,0]  R1022     2.8880143165588379e-01
    z[3,4,0]  R1023     -1.5453328192234039e-01
    z[3,4,0]  R1024     3.8862389326095581e-01
    z[3,4,0]  R1025     3.7091308832168579e-01
    z[3,4,0]  R1026     0.478127658367157
    z[3,4,0]  R1027     4.6311464905738831e-01
    z[3,4,0]  R1028     4.7244840860366821e-01
    z[3,4,0]  R1029     -3.2537445425987244e-01
    z[3,4,0]  R1030     4.7602352499961853e-01
    z[3,4,0]  R1031     2.5705429911613464e-01
    z[3,4,0]  R1032     5.9679847955703735e-01
    z[3,4,0]  R1033     4.8446375131607056e-01
    z[3,4,0]  R1034     -1.4129619300365448e-01
    z[3,4,0]  R1035     -2.4598467350006104e-01
    z[3,4,0]  R1036     -2.2360714152455330e-02
    z[3,4,0]  R1037     4.9472215771675110e-01
    z[3,4,0]  R1038     -2.9698467254638672e-01
    z[3,4,0]  R1039     9.5166578888893127e-02
    z[3,4,0]  R1040     -8.4637673571705818e-03
    z[3,4,0]  R1041     3.5379037261009216e-01
    z[3,4,0]  R1042     -4.9908825755119324e-01
    z[3,4,0]  R1043     2.0909052342176437e-02
    z[3,4,0]  R1044     -1.6441054642200470e-01
    z[3,4,0]  R1045     -4.1640344262123108e-01
    z[3,4,0]  R1046     2.3950491845607758e-01
    z[3,4,0]  R1047     -3.0985912680625916e-01
    z[3,4,0]  R1048     1.3322702050209045e-01
    z[3,4,0]  R1049     2.8159549832344055e-01
    z[3,4,0]  R1050     -5.0860035419464111e-01
    z[3,4,0]  R1051     -2.9777538776397705e-01
    z[3,4,0]  R1052     1.0051559656858444e-01
    z[3,4,0]  R1053     -4.4247376918792725e-01
    z[3,4,0]  R1054     -1.9971807301044464e-01
    z[3,4,0]  R1055     -1.4479297399520874e-01
    z[3,4,0]  R1056     3.1530305743217468e-01
    z[3,4,0]  R1057     -4.0553700923919678e-01
    z[3,4,0]  R1058     2.8023305535316467e-01
    z[3,4,0]  R1059     1.1138470470905304e-01
    z[3,4,0]  R1060     -1.4050295948982239e-01
    z[3,4,0]  R1061     -1.6415895521640778e-01
    z[3,4,0]  R1062     -3.0126294121146202e-02
    z[3,4,0]  R1063     -2.0682542026042938e-01
    z[3,4,0]  R1064     0.910633385181427
    z[3,4,0]  R1065     8.6385035514831543e-01
    z[3,4,0]  R1066     9.6000903844833374e-01
    z[3,4,0]  R1067     8.4667760133743286e-01
    z[3,4,0]  R1068     8.0817246437072754e-01
    z[3,4,0]  R1069     5.7434415817260742e-01
    z[3,4,0]  R1070     7.5250571966171265e-01
    z[3,4,0]  R1071     -1.9204263389110565e-01
    z[3,4,0]  R1072     -3.1876403093338013e-01
    z[3,4,0]  R1073     -1.9027492403984070e-01
    z[3,4,0]  R1074     -2.0767155289649963e-01
    z[3,4,0]  R1075     -4.4648265838623047e-01
    z[3,4,0]  R1076     -0.127395898103714
    z[3,4,0]  R1077     -6.2777155637741089e-01
    z[3,4,0]  R1078     -2.4436137080192566e-01
    z[3,4,0]  R1079     -2.9672563076019287e-01
    z[3,4,0]  R1080     -5.6023168563842773e-01
    z[3,4,0]  R1081     -2.2943228483200073e-01
    z[3,4,0]  R1082     -3.3806160092353821e-01
    z[3,4,0]  R1083     -3.3537802100181580e-01
    z[3,4,0]  R1084     -2.8405603766441345e-01
    z[3,4,0]  R1085     -2.2720962762832642e-01
    z[3,4,0]  R1086     2.2040279582142830e-02
    z[3,4,0]  R1087     -0.0471559539437294
    z[3,4,0]  R1088     1.5134997665882111e-01
    z[3,4,0]  R1089     3.6984187364578247e-01
    z[3,4,0]  R1090     -5.7003587484359741e-01
    z[3,4,0]  R1091     1.9555503129959106e-01
    z[3,4,0]  R1092     -5.0418472290039062e-01
    z[3,4,0]  R1093     -0.566318929195404
    z[3,4,0]  R1094     -2.7169395238161087e-02
    z[3,4,0]  R1095     4.0753343701362610e-01
    z[3,4,0]  R1096     1.9366508722305298e-01
    z[3,4,0]  R1097     -7.1623331308364868e-01
    z[3,4,0]  R1098     3.7577813863754272e-01
    z[3,4,0]  R1099     1.7083208262920380e-01
    z[3,4,0]  R1100     1.7021400853991508e-03
    z[3,4,0]  R1101     3.0672988295555115e-01
    z[3,4,0]  R1102     3.3502897620201111e-01
    z[3,4,0]  R1103     -4.8495680093765259e-01
    z[3,4,0]  R1104     -7.5788080692291260e-01
    z[3,4,0]  R1105     -2.8400537371635437e-01
    z[3,4,0]  R1106     -1.9477254152297974e-01
    z[3,4,0]  R1107     -4.4092038273811340e-01
    z[3,4,0]  R1108     1.6808068752288818e-01
    z[3,4,0]  R1109     3.0650016665458679e-01
    z[3,4,0]  R1110     -4.8207080364227295e-01
    z[3,4,0]  R1111     0.021457489579916
    z[3,4,0]  R1112     1.5523508191108704e-01
    z[3,4,0]  R1113     1.5136989951133728e-01
    z[3,4,0]  R1114     1.7610202729701996e-01
    z[3,4,0]  R1115     1.2261650711297989e-01
    z[3,4,0]  R1116     -5.4844474792480469e-01
    z[3,4,0]  R1117     -5.2444231510162354e-01
    z[3,4,0]  R1118     -4.6172222495079041e-01
    z[3,4,0]  R1119     -0.569028913974762
    z[3,4,0]  R1120     -5.6284797191619873e-01
    z[3,4,0]  R1121     -4.1871842741966248e-01
    z[3,4,0]  R1122     -5.5132120847702026e-01
    z[3,4,0]  R1123     1.2665323913097382e-01
    z[3,4,0]  R1124     1.7611831426620483e-01
    z[3,4,0]  R1125     4.7245588898658752e-01
    z[3,4,0]  R1126     1.6912671923637390e-01
    z[3,4,0]  R1127     -5.5089020729064941e-01
    z[3,4,0]  R1128     -5.6645786762237549e-01
    z[3,4,0]  R1129     -4.5239266753196716e-01
    z[3,4,0]  R1130     -7.2609871625900269e-02
    z[3,4,0]  R1131     2.0316435396671295e-01
    z[3,4,0]  R1132     1.5671840310096741e-01
    z[3,4,0]  R1133     1.0520647466182709e-01
    z[3,4,1]  R30       -1
    z[3,4,1]  R39       1
    z[3,4,1]  R1002     -1
    z[3,4,1]  R1003     1
    z[3,4,1]  R1014     -5.2148234844207764e-01
    z[3,4,1]  R1015     8.3416923880577087e-02
    z[3,4,1]  R1016     -5.1724594831466675e-01
    z[3,4,1]  R1017     0.436928391456604
    z[3,4,1]  R1018     0.481802374124527
    z[3,4,1]  R1019     -4.2934402823448181e-01
    z[3,4,1]  R1020     4.3029200285673141e-02
    z[3,4,1]  R1021     -3.1166023015975952e-01
    z[3,4,1]  R1022     -9.3946449458599091e-02
    z[3,4,1]  R1023     2.3569411039352417e-01
    z[3,4,1]  R1024     -3.9549741148948669e-01
    z[3,4,1]  R1025     -3.2833805680274963e-01
    z[3,4,1]  R1026     -4.0744832158088684e-01
    z[3,4,1]  R1027     -7.6940737664699554e-02
    z[3,4,1]  R1028     -1.4032201468944550e-01
    z[3,4,1]  R1029     -2.6081937551498413e-01
    z[3,4,1]  R1030     -4.7939816117286682e-01
    z[3,4,1]  R1031     -5.7229530811309814e-01
    z[3,4,1]  R1032     -1.1862655729055405e-01
    z[3,4,1]  R1033     -2.3100028932094574e-01
    z[3,4,1]  R1034     -3.8691377639770508e-01
    z[3,4,1]  R1035     -1.3536162674427032e-01
    z[3,4,1]  R1036     -8.1442302465438843e-01
    z[3,4,1]  R1037     2.1609127521514893e-01
    z[3,4,1]  R1038     -8.0153423547744751e-01
    z[3,4,1]  R1039     -7.2501242160797119e-01
    z[3,4,1]  R1040     -9.2812252044677734e-01
    z[3,4,1]  R1041     5.6346774101257324e-01
    z[3,4,1]  R1042     0.726138710975647
    z[3,4,1]  R1043     -0.0324397049844265
    z[3,4,1]  R1044     -3.2403391599655151e-01
    z[3,4,1]  R1045     -4.0914842486381531e-01
    z[3,4,1]  R1046     -5.8479070663452148e-01
    z[3,4,1]  R1047     -6.0351520776748657e-01
    z[3,4,1]  R1048     1.4922253787517548e-01
    z[3,4,1]  R1049     5.9933638572692871e-01
    z[3,4,1]  R1050     4.6213066577911377e-01
    z[3,4,1]  R1051     0.813393771648407
    z[3,4,1]  R1052     4.7956377267837524e-01
    z[3,4,1]  R1053     6.3635557889938354e-01
    z[3,4,1]  R1054     -3.5282588005065918e-01
    z[3,4,1]  R1055     -5.1891523599624634e-01
    z[3,4,1]  R1056     -7.3771619796752930e-01
    z[3,4,1]  R1057     -6.7508661746978760e-01
    z[3,4,1]  R1058     3.8875925540924072e-01
    z[3,4,1]  R1059     5.7495909929275513e-01
    z[3,4,1]  R1060     5.7786947488784790e-01
    z[3,4,1]  R1061     8.9735507965087891e-01
    z[3,4,1]  R1062     4.3170607089996338e-01
    z[3,4,1]  R1063     7.3682177066802979e-01
    z[3,4,1]  R1064     1.1460566520690918e-01
    z[3,4,1]  R1065     2.5463491678237915e-02
    z[3,4,1]  R1066     -1.4563414454460144e-01
    z[3,4,1]  R1067     -1.5058070421218872e-01
    z[3,4,1]  R1068     -2.8103342652320862e-01
    z[3,4,1]  R1069     -3.2171329855918884e-01
    z[3,4,1]  R1070     -4.3177595734596252e-01
    z[3,4,1]  R1071     -5.6893426179885864e-01
    z[3,4,1]  R1072     -6.2713003158569336e-01
    z[3,4,1]  R1073     -3.3543795347213745e-01
    z[3,4,1]  R1074     -5.8244132995605469e-01
    z[3,4,1]  R1075     -6.3318848609924316e-01
    z[3,4,1]  R1076     -5.3689426183700562e-01
    z[3,4,1]  R1077     -4.2378321290016174e-01
    z[3,4,1]  R1078     8.1636792421340942e-01
    z[3,4,1]  R1079     8.2112735509872437e-01
    z[3,4,1]  R1080     7.6580405235290527e-01
    z[3,4,1]  R1081     7.6226824522018433e-01
    z[3,4,1]  R1082     7.1772933006286621e-01
    z[3,4,1]  R1083     7.8388285636901855e-01
    z[3,4,1]  R1084     -7.8066468238830566e-01
    z[3,4,1]  R1085     -5.2805393934249878e-01
    z[3,4,1]  R1086     -4.1029801964759827e-01
    z[3,4,1]  R1087     -2.5612908601760864e-01
    z[3,4,1]  R1088     -3.9278411865234375e-01
    z[3,4,1]  R1089     -5.1957917213439941e-01
    z[3,4,1]  R1090     7.5354062020778656e-02
    z[3,4,1]  R1091     6.4115965366363525e-01
    z[3,4,1]  R1092     6.8383723497390747e-01
    z[3,4,1]  R1093     6.3187509775161743e-01
    z[3,4,1]  R1094     -0.740505576133728
    z[3,4,1]  R1095     -7.3246729373931885e-01
    z[3,4,1]  R1096     -5.8310168981552124e-01
    z[3,4,1]  R1097     3.3649951219558716e-01
    z[3,4,1]  R1098     3.6887574195861816e-01
    z[3,4,1]  R1099     3.4796217083930969e-01
    z[3,4,1]  R1100     4.5040979981422424e-01
    z[3,4,1]  R1101     5.7220572233200073e-01
    z[3,4,1]  R1102     5.9585189819335938e-01
    z[3,4,1]  R1103     6.1750531196594238e-01
    z[3,4,1]  R1104     1.4881081879138947e-01
    z[3,4,1]  R1105     7.4363607168197632e-01
    z[3,4,1]  R1106     0.666480302810669
    z[3,4,1]  R1107     5.0507462024688721e-01
    z[3,4,1]  R1108     9.4165974855422974e-01
    z[3,4,1]  R1109     9.1493850946426392e-01
    z[3,4,1]  R1110     3.8173234462738037e-01
    z[3,4,1]  R1111     9.3927145004272461e-01
    z[3,4,1]  R1112     0.92210853099823
    z[3,4,1]  R1113     9.1048997640609741e-01
    z[3,4,1]  R1114     0.601198136806488
    z[3,4,1]  R1115     4.2409190535545349e-01
    z[3,4,1]  R1116     0.558688759803772
    z[3,4,1]  R1117     3.3374351263046265e-01
    z[3,4,1]  R1118     0.828164279460907
    z[3,4,1]  R1119     6.3915222883224487e-01
    z[3,4,1]  R1120     0.666843056678772
    z[3,4,1]  R1121     7.4222880601882935e-01
    z[3,4,1]  R1122     4.9861952662467957e-01
    z[3,4,1]  R1123     0.881424605846405
    z[3,4,1]  R1124     -4.2620584368705750e-01
    z[3,4,1]  R1125     -3.2889935374259949e-01
    z[3,4,1]  R1126     3.7889429926872253e-01
    z[3,4,1]  R1127     4.2418941855430603e-01
    z[3,4,1]  R1128     6.4593595266342163e-01
    z[3,4,1]  R1129     7.7900153398513794e-01
    z[3,4,1]  R1130     8.7439858913421631e-01
    z[3,4,1]  R1131     7.5653755664825439e-01
    z[3,4,1]  R1132     7.9470765590667725e-01
    z[3,4,1]  R1133     3.3972927927970886e-01
    z[3,4,2]  R31       -1
    z[3,4,2]  R40       1
    z[3,4,2]  R1004     -1
    z[3,4,2]  R1005     1
    z[3,4,2]  R1014     1.5335462987422943e-01
    z[3,4,2]  R1015     -6.0049909353256226e-01
    z[3,4,2]  R1016     5.4962551593780518e-01
    z[3,4,2]  R1017     -3.2779499888420105e-01
    z[3,4,2]  R1018     -3.8564798235893250e-01
    z[3,4,2]  R1019     -4.9620741046965122e-03
    z[3,4,2]  R1020     -4.8943346738815308e-01
    z[3,4,2]  R1021     1.8296520411968231e-01
    z[3,4,2]  R1022     -4.2893221974372864e-01
    z[3,4,2]  R1023     -2.5571811944246292e-02
    z[3,4,2]  R1024     3.3236268162727356e-01
    z[3,4,2]  R1025     4.7776794433593750e-01
    z[3,4,2]  R1026     5.4234284162521362e-01
    z[3,4,2]  R1027     3.3731272816658020e-01
    z[3,4,2]  R1028     6.2042981386184692e-01
    z[3,4,2]  R1029     -4.3763765692710876e-01
    z[3,4,2]  R1030     2.6428681612014771e-01
    z[3,4,2]  R1031     1.4328658580780029e-03
    z[3,4,2]  R1032     3.2177260518074036e-01
    z[3,4,2]  R1033     1.7702539265155792e-01
    z[3,4,2]  R1034     -7.1257036924362183e-01
    z[3,4,2]  R1035     -5.8643120527267456e-01
    z[3,4,2]  R1036     -1.3432666659355164e-01
    z[3,4,2]  R1037     4.8286509513854980e-01
    z[3,4,2]  R1038     -4.7755271196365356e-01
    z[3,4,2]  R1039     -2.8411459922790527e-01
    z[3,4,2]  R1040     -1.3416558504104614e-01
    z[3,4,2]  R1041     7.0129656791687012e-01
    z[3,4,2]  R1042     -3.3579519391059875e-01
    z[3,4,2]  R1043     1.0880029201507568e-01
    z[3,4,2]  R1044     -0.604345440864563
    z[3,4,2]  R1045     -2.9558802023530006e-02
    z[3,4,2]  R1046     1.1722157150506973e-01
    z[3,4,2]  R1047     3.9034938812255859e-01
    z[3,4,2]  R1048     4.1221952438354492e-01
    z[3,4,2]  R1049     -1.5346366167068481e-01
    z[3,4,2]  R1050     -6.5238827466964722e-01
    z[3,4,2]  R1051     -4.8277732729911804e-01
    z[3,4,2]  R1052     6.8101976066827774e-03
    z[3,4,2]  R1053     -5.9404021501541138e-01
    z[3,4,2]  R1054     -3.6452940106391907e-01
    z[3,4,2]  R1055     -2.5705328583717346e-01
    z[3,4,2]  R1056     -5.0469189882278442e-03
    z[3,4,2]  R1057     1.0578592121601105e-01
    z[3,4,2]  R1058     6.2631016969680786e-01
    z[3,4,2]  R1059     -2.6241201162338257e-01
    z[3,4,2]  R1060     -9.8471298813819885e-02
    z[3,4,2]  R1061     -3.2202121615409851e-01
    z[3,4,2]  R1062     -2.2024551033973694e-01
    z[3,4,2]  R1063     -3.5296049714088440e-01
    z[3,4,2]  R1064     -1.1033765971660614e-01
    z[3,4,2]  R1065     -2.3953357338905334e-01
    z[3,4,2]  R1066     -3.6573097109794617e-02
    z[3,4,2]  R1067     2.4638488888740540e-01
    z[3,4,2]  R1068     -4.1139110922813416e-02
    z[3,4,2]  R1069     -7.4872829020023346e-02
    z[3,4,2]  R1070     0.201263889670372
    z[3,4,2]  R1071     5.1678277552127838e-02
    z[3,4,2]  R1072     -2.8553009033203125e-01
    z[3,4,2]  R1073     2.0388789474964142e-01
    z[3,4,2]  R1074     3.0496206879615784e-01
    z[3,4,2]  R1075     1.5170499682426453e-01
    z[3,4,2]  R1076     3.4554663300514221e-01
    z[3,4,2]  R1077     4.3080207705497742e-01
    z[3,4,2]  R1078     -4.5506325364112854e-01
    z[3,4,2]  R1079     -4.5871418714523315e-01
    z[3,4,2]  R1080     -2.5207144021987915e-01
    z[3,4,2]  R1081     -5.3996407985687256e-01
    z[3,4,2]  R1082     -4.7224959731101990e-01
    z[3,4,2]  R1083     -4.2015898227691650e-01
    z[3,4,2]  R1084     -2.5683504343032837e-01
    z[3,4,2]  R1085     -0.00099270383361727
    z[3,4,2]  R1086     3.0738282203674316e-01
    z[3,4,2]  R1087     8.9336413145065308e-01
    z[3,4,2]  R1088     1.6484551131725311e-01
    z[3,4,2]  R1089     -5.5105859041213989e-01
    z[3,4,2]  R1090     -5.1811766624450684e-01
    z[3,4,2]  R1091     5.8941847085952759e-01
    z[3,4,2]  R1092     -3.3432438969612122e-01
    z[3,4,2]  R1093     -0.340804785490036
    z[3,4,2]  R1094     4.6320453286170959e-01
    z[3,4,2]  R1095     -5.8638896793127060e-02
    z[3,4,2]  R1096     -0.0315396711230278
    z[3,4,2]  R1097     -2.2471982240676880e-01
    z[3,4,2]  R1098     6.4761632680892944e-01
    z[3,4,2]  R1099     4.8071259260177612e-01
    z[3,4,2]  R1100     0.53521329164505
    z[3,4,2]  R1101     1.8668556213378906e-01
    z[3,4,2]  R1102     2.4896225333213806e-01
    z[3,4,2]  R1103     -3.5354679822921753e-01
    z[3,4,2]  R1104     -2.5364935398101807e-01
    z[3,4,2]  R1105     -5.8455985784530640e-01
    z[3,4,2]  R1106     -4.2960298061370850e-01
    z[3,4,2]  R1107     -3.8094425201416016e-01
    z[3,4,2]  R1108     -4.5056834816932678e-02
    z[3,4,2]  R1109     -1.1783744394779205e-01
    z[3,4,2]  R1110     -5.1590472459793091e-01
    z[3,4,2]  R1111     3.7413392215967178e-02
    z[3,4,2]  R1112     -5.4214667528867722e-02
    z[3,4,2]  R1113     -2.0445628464221954e-01
    z[3,4,2]  R1114     5.7721412181854248e-01
    z[3,4,2]  R1115     3.1412672996520996e-01
    z[3,4,2]  R1116     -4.0260905027389526e-01
    z[3,4,2]  R1117     -6.7133563756942749e-01
    z[3,4,2]  R1118     5.5074214935302734e-02
    z[3,4,2]  R1119     -1.4470370113849640e-01
    z[3,4,2]  R1120     -1.5852785110473633e-01
    z[3,4,2]  R1121     5.9551354497671127e-03
    z[3,4,2]  R1122     -2.4570623040199280e-01
    z[3,4,2]  R1123     -1.9592528045177460e-01
    z[3,4,2]  R1124     4.2542022466659546e-01
    z[3,4,2]  R1125     3.2853364944458008e-01
    z[3,4,2]  R1126     5.1375579833984375e-01
    z[3,4,2]  R1127     -5.5606234073638916e-01
    z[3,4,2]  R1128     -2.3779833316802979e-01
    z[3,4,2]  R1129     -1.7113822698593140e-01
    z[3,4,2]  R1130     0.0406145378947258
    z[3,4,2]  R1131     -3.0740597844123840e-01
    z[3,4,2]  R1132     2.9896411299705505e-01
    z[3,4,2]  R1133     -5.1972858607769012e-02
    z[3,4,3]  R32       -1
    z[3,4,3]  R41       1
    z[3,4,3]  R1006     -1
    z[3,4,3]  R1007     1
    z[3,4,3]  R1014     1.3980150222778320e-01
    z[3,4,3]  R1015     -4.8543652892112732e-01
    z[3,4,3]  R1016     0.349149614572525
    z[3,4,3]  R1017     -7.0498067140579224e-01
    z[3,4,3]  R1018     -6.4381921291351318e-01
    z[3,4,3]  R1019     2.5701728463172913e-01
    z[3,4,3]  R1020     -5.4006010293960571e-01
    z[3,4,3]  R1021     -0.0647614598274231
    z[3,4,3]  R1022     -1.8884766101837158e-01
    z[3,4,3]  R1023     -4.9562579393386841e-01
    z[3,4,3]  R1024     -7.6045602560043335e-01
    z[3,4,3]  R1025     -6.8463677167892456e-01
    z[3,4,3]  R1026     -3.7467747926712036e-01
    z[3,4,3]  R1027     -7.0945578813552856e-01
    z[3,4,3]  R1028     -4.7919160127639771e-01
    z[3,4,3]  R1029     -6.2790863215923309e-02
    z[3,4,3]  R1030     -5.4137378931045532e-01
    z[3,4,3]  R1031     -6.1908680200576782e-01
    z[3,4,3]  R1032     -5.0925046205520630e-01
    z[3,4,3]  R1033     -5.1862555742263794e-01
    z[3,4,3]  R1034     0.0450817309319973
    z[3,4,3]  R1035     -6.1120027303695679e-01
    z[3,4,3]  R1036     1.4381159842014313e-01
    z[3,4,3]  R1037     -4.9036917090415955e-01
    z[3,4,3]  R1038     -3.7112716585397720e-02
    z[3,4,3]  R1039     1.6053833067417145e-01
    z[3,4,3]  R1040     -2.5952902436256409e-01
    z[3,4,3]  R1041     -1.0738559067249298e-03
    z[3,4,3]  R1042     3.0714073777198792e-01
    z[3,4,3]  R1043     8.6557984352111816e-01
    z[3,4,3]  R1044     -4.5465391874313354e-01
    z[3,4,3]  R1045     -4.8944808542728424e-02
    z[3,4,3]  R1046     3.8044983148574829e-01
    z[3,4,3]  R1047     -2.1053658425807953e-01
    z[3,4,3]  R1048     8.1655263900756836e-01
    z[3,4,3]  R1049     -5.5685347318649292e-01
    z[3,4,3]  R1050     3.0859303474426270e-01
    z[3,4,3]  R1051     -6.4833253622055054e-02
    z[3,4,3]  R1052     6.2604665756225586e-01
    z[3,4,3]  R1053     1.9388185441493988e-01
    z[3,4,3]  R1054     -3.7968146800994873e-01
    z[3,4,3]  R1055     7.0764243602752686e-01
    z[3,4,3]  R1056     -2.8273233771324158e-01
    z[3,4,3]  R1057     7.9361535608768463e-02
    z[3,4,3]  R1058     -4.0932792425155640e-01
    z[3,4,3]  R1059     -6.0328519344329834e-01
    z[3,4,3]  R1060     7.1337640285491943e-01
    z[3,4,3]  R1061     1.6910864412784576e-01
    z[3,4,3]  R1062     6.6688686609268188e-01
    z[3,4,3]  R1063     8.0330856144428253e-02
    z[3,4,3]  R1064     -3.0676627159118652e-01
    z[3,4,3]  R1065     -3.7245699763298035e-01
    z[3,4,3]  R1066     -2.3310832679271698e-02
    z[3,4,3]  R1067     -2.8134772181510925e-01
    z[3,4,3]  R1068     -1.6613277792930603e-01
    z[3,4,3]  R1069     -7.2090911865234375e-01
    z[3,4,3]  R1070     3.1365206837654114e-01
    z[3,4,3]  R1071     3.5603219270706177e-01
    z[3,4,3]  R1072     5.1434355974197388e-01
    z[3,4,3]  R1073     7.0499561727046967e-02
    z[3,4,3]  R1074     -1.6654946375638247e-03
    z[3,4,3]  R1075     1.5276117250323296e-02
    z[3,4,3]  R1076     -4.7179181128740311e-02
    z[3,4,3]  R1077     -1.7511065304279327e-01
    z[3,4,3]  R1078     2.0056959986686707e-01
    z[3,4,3]  R1079     -2.2695591673254967e-02
    z[3,4,3]  R1080     -6.3069827854633331e-02
    z[3,4,3]  R1081     1.6770876944065094e-01
    z[3,4,3]  R1082     1.6817204654216766e-01
    z[3,4,3]  R1083     2.3151952773332596e-02
    z[3,4,3]  R1084     2.6901695132255554e-01
    z[3,4,3]  R1085     9.3601889908313751e-02
    z[3,4,3]  R1086     1.2430024892091751e-01
    z[3,4,3]  R1087     3.3441290725022554e-03
    z[3,4,3]  R1088     3.0803942680358887e-01
    z[3,4,3]  R1089     2.7731612324714661e-01
    z[3,4,3]  R1090     -1.8918864428997040e-01
    z[3,4,3]  R1091     -2.8639551997184753e-01
    z[3,4,3]  R1092     2.2982136905193329e-01
    z[3,4,3]  R1093     3.6958608776330948e-02
    z[3,4,3]  R1094     2.4177664518356323e-01
    z[3,4,3]  R1095     3.7974965572357178e-01
    z[3,4,3]  R1096     1.0621663928031921e-01
    z[3,4,3]  R1097     -2.0878523588180542e-01
    z[3,4,3]  R1098     -1.9266463816165924e-01
    z[3,4,3]  R1099     -0.259590208530426
    z[3,4,3]  R1100     -3.4287315607070923e-01
    z[3,4,3]  R1101     -1.7056691646575928e-01
    z[3,4,3]  R1102     -1.5326879918575287e-01
    z[3,4,3]  R1103     2.7780768275260925e-01
    z[3,4,3]  R1104     -2.1395921707153320e-01
    z[3,4,3]  R1105     -5.2395123988389969e-02
    z[3,4,3]  R1106     0.516957700252533
    z[3,4,3]  R1107     0.528457522392273
    z[3,4,3]  R1108     -2.6437327265739441e-01
    z[3,4,3]  R1109     -2.1248273551464081e-01
    z[3,4,3]  R1110     3.1534832715988159e-01
    z[3,4,3]  R1111     -0.283624529838562
    z[3,4,3]  R1112     -2.2017486393451691e-01
    z[3,4,3]  R1113     -2.1831075847148895e-01
    z[3,4,3]  R1114     -2.7722486853599548e-01
    z[3,4,3]  R1115     -2.7675676345825195e-01
    z[3,4,3]  R1116     4.1128787398338318e-01
    z[3,4,3]  R1117     3.1493067741394043e-01
    z[3,4,3]  R1118     2.9338827729225159e-01
    z[3,4,3]  R1119     1.9708785414695740e-01
    z[3,4,3]  R1120     -5.1215752959251404e-02
    z[3,4,3]  R1121     4.0755963325500488e-01
    z[3,4,3]  R1122     3.3523747324943542e-01
    z[3,4,3]  R1123     -2.8534629940986633e-01
    z[3,4,3]  R1124     1.2849889695644379e-01
    z[3,4,3]  R1125     1.1477474868297577e-01
    z[3,4,3]  R1126     -0.214838445186615
    z[3,4,3]  R1127     2.5786882638931274e-01
    z[3,4,3]  R1128     2.0320130884647369e-01
    z[3,4,3]  R1129     -1.7632950842380524e-01
    z[3,4,3]  R1130     -3.4535399079322815e-01
    z[3,4,3]  R1131     -1.1928913742303848e-01
    z[3,4,3]  R1132     -2.3364393413066864e-01
    z[3,4,3]  R1133     7.0739632844924927e-01
    z[3,4,4]  R33       -1
    z[3,4,4]  R42       1
    z[3,4,4]  R1008     -1
    z[3,4,4]  R1009     1
    z[3,4,4]  R1014     -4.8401427268981934e-01
    z[3,4,4]  R1015     4.6343751251697540e-02
    z[3,4,4]  R1016     5.4460112005472183e-02
    z[3,4,4]  R1017     -3.2666212320327759e-01
    z[3,4,4]  R1018     1.3809368014335632e-01
    z[3,4,4]  R1019     6.6078805923461914e-01
    z[3,4,4]  R1020     -3.1959589570760727e-02
    z[3,4,4]  R1021     4.6754062175750732e-01
    z[3,4,4]  R1022     -3.1381070613861084e-01
    z[3,4,4]  R1023     -6.2581133842468262e-01
    z[3,4,4]  R1024     -1.9610758870840073e-02
    z[3,4,4]  R1025     -4.9195587635040283e-02
    z[3,4,4]  R1026     2.2888121008872986e-01
    z[3,4,4]  R1027     1.2012667208909988e-01
    z[3,4,4]  R1028     -3.0425125360488892e-01
    z[3,4,4]  R1029     -7.9097676277160645e-01
    z[3,4,4]  R1030     2.3311580717563629e-01
    z[3,4,4]  R1031     -1.8523296713829041e-01
    z[3,4,4]  R1032     2.3390786349773407e-01
    z[3,4,4]  R1033     5.2037900686264038e-01
    z[3,4,4]  R1034     -2.6308125257492065e-01
    z[3,4,4]  R1035     4.4833451509475708e-01
    z[3,4,4]  R1036     -2.2582834959030151e-01
    z[3,4,4]  R1037     4.2494514584541321e-01
    z[3,4,4]  R1038     2.3748284205794334e-02
    z[3,4,4]  R1039     -5.7107824832201004e-02
    z[3,4,4]  R1040     1.9484585523605347e-01
    z[3,4,4]  R1041     4.0376982651650906e-03
    z[3,4,4]  R1042     1.2568618357181549e-01
    z[3,4,4]  R1043     -3.9516729116439819e-01
    z[3,4,4]  R1044     -4.3289104104042053e-01
    z[3,4,4]  R1045     1.7633788287639618e-01
    z[3,4,4]  R1046     -3.3293321728706360e-02
    z[3,4,4]  R1047     3.1441393494606018e-01
    z[3,4,4]  R1048     2.5045558810234070e-01
    z[3,4,4]  R1049     1.5220838785171509e-01
    z[3,4,4]  R1050     3.3705178648233414e-02
    z[3,4,4]  R1051     -8.6671836674213409e-02
    z[3,4,4]  R1052     5.3131759166717529e-01
    z[3,4,4]  R1053     -2.8040159493684769e-02
    z[3,4,4]  R1054     -1.8048363924026489e-01
    z[3,4,4]  R1055     2.8188863396644592e-01
    z[3,4,4]  R1056     -0.0724576786160469
    z[3,4,4]  R1057     2.1844211220741272e-01
    z[3,4,4]  R1058     -1.2153670191764832e-01
    z[3,4,4]  R1059     -1.3801916502416134e-02
    z[3,4,4]  R1060     2.5893816351890564e-01
    z[3,4,4]  R1061     4.8382304608821869e-02
    z[3,4,4]  R1062     -2.3363950848579407e-01
    z[3,4,4]  R1063     -4.4344505667686462e-01
    z[3,4,4]  R1064     -2.1605329215526581e-01
    z[3,4,4]  R1065     1.7489252984523773e-01
    z[3,4,4]  R1066     2.0510016381740570e-01
    z[3,4,4]  R1067     -1.3762958347797394e-01
    z[3,4,4]  R1068     -3.1085237860679626e-02
    z[3,4,4]  R1069     -1.3170013204216957e-02
    z[3,4,4]  R1070     2.0437940955162048e-01
    z[3,4,4]  R1071     -4.2405596375465393e-01
    z[3,4,4]  R1072     1.8331797420978546e-01
    z[3,4,4]  R1073     -1.0111937671899796e-01
    z[3,4,4]  R1074     1.5326094627380371e-01
    z[3,4,4]  R1075     -1.0808974504470825e-01
    z[3,4,4]  R1076     -4.3306279182434082e-01
    z[3,4,4]  R1077     3.9568793773651123e-01
    z[3,4,4]  R1078     1.1852863430976868e-01
    z[3,4,4]  R1079     1.4173589646816254e-01
    z[3,4,4]  R1080     -1.1155854910612106e-01
    z[3,4,4]  R1081     1.6141225397586823e-01
    z[3,4,4]  R1082     7.3472797870635986e-02
    z[3,4,4]  R1083     -5.3109776228666306e-02
    z[3,4,4]  R1084     -3.1306478381156921e-01
    z[3,4,4]  R1085     5.5055856704711914e-01
    z[3,4,4]  R1086     2.6041364669799805e-01
    z[3,4,4]  R1087     -2.0082934200763702e-01
    z[3,4,4]  R1088     -5.9684371948242188e-01
    z[3,4,4]  R1089     4.0093538165092468e-01
    z[3,4,4]  R1090     3.3297979831695557e-01
    z[3,4,4]  R1091     3.2784977555274963e-01
    z[3,4,4]  R1092     2.8037330508232117e-01
    z[3,4,4]  R1093     1.7677634954452515e-01
    z[3,4,4]  R1094     -2.9274460673332214e-01
    z[3,4,4]  R1095     7.1325547993183136e-02
    z[3,4,4]  R1096     6.5629088878631592e-01
    z[3,4,4]  R1097     -3.2649514079093933e-01
    z[3,4,4]  R1098     3.2498300075531006e-01
    z[3,4,4]  R1099     7.2262948751449585e-01
    z[3,4,4]  R1100     4.5627161860466003e-01
    z[3,4,4]  R1101     5.5931615829467773e-01
    z[3,4,4]  R1102     3.8837355375289917e-01
    z[3,4,4]  R1103     1.7797181010246277e-01
    z[3,4,4]  R1104     -2.0552127063274384e-01
    z[3,4,4]  R1105     -1.3959896750748158e-02
    z[3,4,4]  R1106     -1.4487208425998688e-01
    z[3,4,4]  R1107     -2.1121428906917572e-01
    z[3,4,4]  R1108     3.6880597472190857e-02
    z[3,4,4]  R1109     -5.3045139648020267e-03
    z[3,4,4]  R1110     -6.0588344931602478e-02
    z[3,4,4]  R1111     -9.6480615437030792e-02
    z[3,4,4]  R1112     -5.9477563947439194e-02
    z[3,4,4]  R1113     5.1358029246330261e-02
    z[3,4,4]  R1114     3.8351699709892273e-01
    z[3,4,4]  R1115     7.9344105720520020e-01
    z[3,4,4]  R1116     1.6153217852115631e-01
    z[3,4,4]  R1117     2.5022806599736214e-02
    z[3,4,4]  R1118     -0.0460795983672142
    z[3,4,4]  R1119     -2.1581773459911346e-01
    z[3,4,4]  R1120     -4.8652660101652145e-02
    z[3,4,4]  R1121     -1.3221164047718048e-01
    z[3,4,4]  R1122     -1.9343020021915436e-01
    z[3,4,4]  R1123     2.8541228175163269e-01
    z[3,4,4]  R1124     -1.5745188295841217e-01
    z[3,4,4]  R1125     -2.8067368548363447e-03
    z[3,4,4]  R1126     0.63071209192276
    z[3,4,4]  R1127     2.8684103488922119e-01
    z[3,4,4]  R1128     -1.5300603210926056e-01
    z[3,4,4]  R1129     1.2116441875696182e-01
    z[3,4,4]  R1130     -6.6729813814163208e-02
    z[3,4,4]  R1131     -3.4673970937728882e-01
    z[3,4,4]  R1132     -3.7755584716796875e-01
    z[3,4,4]  R1133     -4.7383829951286316e-01
    z[3,4,5]  R34       -1
    z[3,4,5]  R43       1
    z[3,4,5]  R1010     -1
    z[3,4,5]  R1011     1
    z[3,4,5]  R1014     -3.7373277544975281e-01
    z[3,4,5]  R1015     -2.8061193227767944e-01
    z[3,4,5]  R1016     -2.6671119034290314e-02
    z[3,4,5]  R1017     -1.1959427595138550e-01
    z[3,4,5]  R1018     -3.1937101483345032e-01
    z[3,4,5]  R1019     -3.6324670910835266e-01
    z[3,4,5]  R1020     -8.2112692296504974e-02
    z[3,4,5]  R1021     -6.9876688718795776e-01
    z[3,4,5]  R1022     -0.394333153963089
    z[3,4,5]  R1023     -4.3859738111495972e-01
    z[3,4,5]  R1024     3.3692322671413422e-02
    z[3,4,5]  R1025     -1.6348755359649658e-01
    z[3,4,5]  R1026     -2.0855288952589035e-02
    z[3,4,5]  R1027     2.0821157097816467e-01
    z[3,4,5]  R1028     -0.0433766171336174
    z[3,4,5]  R1029     -5.6146692484617233e-02
    z[3,4,5]  R1030     2.7365830540657043e-01
    z[3,4,5]  R1031     2.2968876361846924e-01
    z[3,4,5]  R1032     4.4170853495597839e-01
    z[3,4,5]  R1033     3.6483103036880493e-01
    z[3,4,5]  R1034     -4.5089519023895264e-01
    z[3,4,5]  R1035     -2.5357827544212341e-02
    z[3,4,5]  R1036     1.5495795011520386e-01
    z[3,4,5]  R1037     8.0810030922293663e-03
    z[3,4,5]  R1038     0.0723768025636673
    z[3,4,5]  R1039     5.9614843130111694e-01
    z[3,4,5]  R1040     5.4889399558305740e-02
    z[3,4,5]  R1041     -0.197321817278862
    z[3,4,5]  R1042     2.7102181687951088e-02
    z[3,4,5]  R1043     2.8337183594703674e-01
    z[3,4,5]  R1044     0.256511926651001
    z[3,4,5]  R1045     -6.9606119394302368e-01
    z[3,4,5]  R1046     3.4793254733085632e-01
    z[3,4,5]  R1047     4.8544409871101379e-01
    z[3,4,5]  R1048     -6.2928862869739532e-02
    z[3,4,5]  R1049     4.3521293997764587e-01
    z[3,4,5]  R1050     -2.1326787769794464e-02
    z[3,4,5]  R1051     1.4439002610743046e-02
    z[3,4,5]  R1052     2.5736328959465027e-01
    z[3,4,5]  R1053     -3.0850782990455627e-02
    z[3,4,5]  R1054     -7.2390139102935791e-01
    z[3,4,5]  R1055     2.4870058894157410e-01
    z[3,4,5]  R1056     5.1580244302749634e-01
    z[3,4,5]  R1057     0.545786440372467
    z[3,4,5]  R1058     -3.3381292223930359e-01
    z[3,4,5]  R1059     2.2834406793117523e-01
    z[3,4,5]  R1060     1.4479791745543480e-02
    z[3,4,5]  R1061     1.4484675228595734e-01
    z[3,4,5]  R1062     5.0283408164978027e-01
    z[3,4,5]  R1063     1.9192793965339661e-01
    z[3,4,5]  R1064     -6.7718826234340668e-02
    z[3,4,5]  R1065     -1.5975473821163177e-01
    z[3,4,5]  R1066     1.3967177830636501e-02
    z[3,4,5]  R1067     -3.1440812349319458e-01
    z[3,4,5]  R1068     1.2479781359434128e-01
    z[3,4,5]  R1069     -0.0166141539812088
    z[3,4,5]  R1070     -2.0086416602134705e-01
    z[3,4,5]  R1071     -3.5767531394958496e-01
    z[3,4,5]  R1072     -1.8736422061920166e-01
    z[3,4,5]  R1073     -8.6757856607437134e-01
    z[3,4,5]  R1074     3.3237785100936890e-01
    z[3,4,5]  R1075     8.4211677312850952e-02
    z[3,4,5]  R1076     6.0218435525894165e-01
    z[3,4,5]  R1077     1.7615026235580444e-01
    z[3,4,5]  R1078     9.3072645366191864e-02
    z[3,4,5]  R1079     -5.5267107672989368e-03
    z[3,4,5]  R1080     -1.2235080450773239e-01
    z[3,4,5]  R1081     -5.0252329558134079e-02
    z[3,4,5]  R1082     1.0249210149049759e-01
    z[3,4,5]  R1083     5.2654266357421875e-02
    z[3,4,5]  R1084     -2.7082479000091553e-01
    z[3,4,5]  R1085     -1.8426083028316498e-01
    z[3,4,5]  R1086     5.4612624645233154e-01
    z[3,4,5]  R1087     -1.3940142095088959e-01
    z[3,4,5]  R1088     -9.8460555076599121e-02
    z[3,4,5]  R1089     1.3949838280677795e-01
    z[3,4,5]  R1090     -4.2687162756919861e-01
    z[3,4,5]  R1091     -3.6988869309425354e-02
    z[3,4,5]  R1092     -8.5948094725608826e-02
    z[3,4,5]  R1093     2.4168232083320618e-01
    z[3,4,5]  R1094     2.2038803994655609e-01
    z[3,4,5]  R1095     0.325942724943161
    z[3,4,5]  R1096     1.8155101686716080e-02
    z[3,4,5]  R1097     -3.7361851334571838e-01
    z[3,4,5]  R1098     -3.0973193049430847e-01
    z[3,4,5]  R1099     -1.5568171441555023e-01
    z[3,4,5]  R1100     -0.204054057598114
    z[3,4,5]  R1101     -1.0616850107908249e-02
    z[3,4,5]  R1102     -0.316983163356781
    z[3,4,5]  R1103     1.1278515309095383e-01
    z[3,4,5]  R1104     -4.6136081218719482e-01
    z[3,4,5]  R1105     1.2181588262319565e-01
    z[3,4,5]  R1106     -5.6798618286848068e-02
    z[3,4,5]  R1107     2.6877734065055847e-01
    z[3,4,5]  R1108     9.8095230758190155e-02
    z[3,4,5]  R1109     6.8847984075546265e-02
    z[3,4,5]  R1110     4.6843016147613525e-01
    z[3,4,5]  R1111     -4.8404913395643234e-02
    z[3,4,5]  R1112     -0.00689234584569931
    z[3,4,5]  R1113     -1.0875558108091354e-01
    z[3,4,5]  R1114     1.2592312693595886e-01
    z[3,4,5]  R1115     1.4616641215980053e-02
    z[3,4,5]  R1116     -0.0735788494348526
    z[3,4,5]  R1117     2.4920323491096497e-01
    z[3,4,5]  R1118     7.6562032103538513e-02
    z[3,4,5]  R1119     3.3623912930488586e-01
    z[3,4,5]  R1120     4.5428311824798584e-01
    z[3,4,5]  R1121     1.6750530898571014e-01
    z[3,4,5]  R1122     0.454328328371048
    z[3,4,5]  R1123     1.5757321380078793e-03
    z[3,4,5]  R1124     -7.0956653356552124e-01
    z[3,4,5]  R1125     -1.7349001765251160e-01
    z[3,4,5]  R1126     -1.7410913482308388e-02
    z[3,4,5]  R1127     2.4181802570819855e-01
    z[3,4,5]  R1128     2.8184035420417786e-01
    z[3,4,5]  R1129     3.3563607931137085e-01
    z[3,4,5]  R1130     1.0348308086395264e-01
    z[3,4,5]  R1131     -3.4906560182571411e-01
    z[3,4,5]  R1132     1.1178135871887207e-01
    z[3,4,5]  R1133     1.6751761734485626e-01
    z[3,4,6]  R35       -1
    z[3,4,6]  R44       1
    z[3,4,6]  R1012     -1
    z[3,4,6]  R1013     1
    z[3,4,6]  R1014     -4.3678706884384155e-01
    z[3,4,6]  R1015     -4.6456691622734070e-01
    z[3,4,6]  R1016     -4.9688091874122620e-01
    z[3,4,6]  R1017     -2.5510832667350769e-01
    z[3,4,6]  R1018     -2.6143577694892883e-01
    z[3,4,6]  R1019     3.9746630191802979e-01
    z[3,4,6]  R1020     6.3786321878433228e-01
    z[3,4,6]  R1021     3.4531423449516296e-01
    z[3,4,6]  R1022     0.658897340297699
    z[3,4,6]  R1023     -3.0043545365333557e-01
    z[3,4,6]  R1024     4.7700032591819763e-02
    z[3,4,6]  R1025     1.6875910758972168e-01
    z[3,4,6]  R1026     3.4356853365898132e-01
    z[3,4,6]  R1027     -3.2359704375267029e-01
    z[3,4,6]  R1028     2.1930399537086487e-01
    z[3,4,6]  R1029     -4.2879793792963028e-02
    z[3,4,6]  R1030     2.2674646973609924e-01
    z[3,4,6]  R1031     3.6886653304100037e-01
    z[3,4,6]  R1032     1.3063828647136688e-01
    z[3,4,6]  R1033     8.7904646992683411e-02
    z[3,4,6]  R1034     -2.1914835274219513e-01
    z[3,4,6]  R1035     -4.5325968414545059e-02
    z[3,4,6]  R1036     4.7167718410491943e-01
    z[3,4,6]  R1037     2.3300263285636902e-01
    z[3,4,6]  R1038     -1.8468016386032104e-01
    z[3,4,6]  R1039     1.2350400909781456e-02
    z[3,4,6]  R1040     -1.1037850379943848e-01
    z[3,4,6]  R1041     -1.6299147903919220e-01
    z[3,4,6]  R1042     -2.8236522339284420e-03
    z[3,4,6]  R1043     3.1427938491106033e-02
    z[3,4,6]  R1044     2.0696519315242767e-01
    z[3,4,6]  R1045     -3.7461996078491211e-01
    z[3,4,6]  R1046     0.565693199634552
    z[3,4,6]  R1047     9.2446379363536835e-02
    z[3,4,6]  R1048     2.3793274164199829e-01
    z[3,4,6]  R1049     1.2363357841968536e-01
    z[3,4,6]  R1050     -7.3006264865398407e-02
    z[3,4,6]  R1051     6.8720698356628418e-02
    z[3,4,6]  R1052     1.3928471505641937e-01
    z[3,4,6]  R1053     0.0840034931898117
    z[3,4,6]  R1054     4.4490348547697067e-02
    z[3,4,6]  R1055     4.0182426571846008e-02
    z[3,4,6]  R1056     -7.1369171142578125e-02
    z[3,4,6]  R1057     -1.2926366925239563e-01
    z[3,4,6]  R1058     -2.9037842154502869e-01
    z[3,4,6]  R1059     4.1457340121269226e-01
    z[3,4,6]  R1060     2.4589551985263824e-01
    z[3,4,6]  R1061     -1.1040373146533966e-01
    z[3,4,6]  R1062     -1.0975638777017593e-01
    z[3,4,6]  R1063     -2.2316549718379974e-01
    z[3,4,6]  R1064     -8.2207638770341873e-03
    z[3,4,6]  R1065     3.0077984556555748e-02
    z[3,4,6]  R1066     1.1415420472621918e-01
    z[3,4,6]  R1067     -5.2973654121160507e-02
    z[3,4,6]  R1068     -4.7121551632881165e-01
    z[3,4,6]  R1069     -2.0214863121509552e-01
    z[3,4,6]  R1070     -1.6218061745166779e-01
    z[3,4,6]  R1071     -4.4972071051597595e-01
    z[3,4,6]  R1072     -3.0051621794700623e-01
    z[3,4,6]  R1073     -2.0449618995189667e-01
    z[3,4,6]  R1074     6.2503278255462646e-01
    z[3,4,6]  R1075     5.9808266162872314e-01
    z[3,4,6]  R1076     -1.5400396287441254e-01
    z[3,4,6]  R1077     1.4986211061477661e-01
    z[3,4,6]  R1078     6.1714071780443192e-02
    z[3,4,6]  R1079     8.1549547612667084e-02
    z[3,4,6]  R1080     -6.8933911621570587e-02
    z[3,4,6]  R1081     -1.3431830704212189e-01
    z[3,4,6]  R1082     -3.2151910662651062e-01
    z[3,4,6]  R1083     3.0064353346824646e-01
    z[3,4,6]  R1084     1.3593773357570171e-02
    z[3,4,6]  R1085     -5.6895136833190918e-01
    z[3,4,6]  R1086     -0.59595787525177
    z[3,4,6]  R1087     -2.7257740497589111e-01
    z[3,4,6]  R1088     -5.7864898443222046e-01
    z[3,4,6]  R1089     0.180210143327713
    z[3,4,6]  R1090     2.6841688156127930e-01
    z[3,4,6]  R1091     -1.1127635091543198e-01
    z[3,4,6]  R1092     -1.6606491804122925e-01
    z[3,4,6]  R1093     2.6989388465881348e-01
    z[3,4,6]  R1094     -2.0887459814548492e-01
    z[3,4,6]  R1095     -1.9604563713073730e-01
    z[3,4,6]  R1096     4.2327558994293213e-01
    z[3,4,6]  R1097     -1.8302398920059204e-01
    z[3,4,6]  R1098     2.5425758957862854e-01
    z[3,4,6]  R1099     6.9547399878501892e-02
    z[3,4,6]  R1100     3.7853807210922241e-01
    z[3,4,6]  R1101     -4.4900503754615784e-01
    z[3,4,6]  R1102     -4.4264003634452820e-01
    z[3,4,6]  R1103     3.7005007266998291e-01
    z[3,4,6]  R1104     1.9560858607292175e-01
    z[3,4,6]  R1105     -8.2806371152400970e-02
    z[3,4,6]  R1106     2.0457211136817932e-01
    z[3,4,6]  R1107     -9.6177399158477783e-02
    z[3,4,6]  R1108     -4.6039126813411713e-02
    z[3,4,6]  R1109     7.1710072457790375e-02
    z[3,4,6]  R1110     -1.8217626214027405e-01
    z[3,4,6]  R1111     -1.5431955456733704e-01
    z[3,4,6]  R1112     -2.6573812961578369e-01
    z[3,4,6]  R1113     -2.1016108989715576e-01
    z[3,4,6]  R1114     -1.8594941496849060e-01
    z[3,4,6]  R1115     -8.8872546330094337e-03
    z[3,4,6]  R1116     1.5593892335891724e-01
    z[3,4,6]  R1117     0.0312119722366333
    z[3,4,6]  R1118     6.2140613794326782e-02
    z[3,4,6]  R1119     2.1971276402473450e-01
    z[3,4,6]  R1120     -4.5035343617200851e-02
    z[3,4,6]  R1121     -2.4918465316295624e-01
    z[3,4,6]  R1122     -1.7560848593711853e-01
    z[3,4,6]  R1123     7.6011463999748230e-02
    z[3,4,6]  R1124     2.4811469018459320e-01
    z[3,4,6]  R1125     7.1930283308029175e-01
    z[3,4,6]  R1126     -3.4588134288787842e-01
    z[3,4,6]  R1127     1.1311681009829044e-02
    z[3,4,6]  R1128     2.4740378558635712e-01
    z[3,4,6]  R1129     -2.8012450784444809e-02
    z[3,4,6]  R1130     3.0671533942222595e-01
    z[3,4,6]  R1131     0.188604474067688
    z[3,4,6]  R1132     2.1181724965572357e-01
    z[3,4,6]  R1133     3.4324905276298523e-01
    z[4,3,0]  R29       1
    z[4,3,0]  R38       -1
    z[4,3,0]  R1134     -1
    z[4,3,0]  R1135     1
    z[4,3,0]  R1148     0.910633385181427
    z[4,3,0]  R1149     8.6385035514831543e-01
    z[4,3,0]  R1150     9.6000903844833374e-01
    z[4,3,0]  R1151     8.4667760133743286e-01
    z[4,3,0]  R1152     8.0817246437072754e-01
    z[4,3,0]  R1153     5.7434415817260742e-01
    z[4,3,0]  R1154     7.5250571966171265e-01
    z[4,3,0]  R1155     -1.9204263389110565e-01
    z[4,3,0]  R1156     -3.1876403093338013e-01
    z[4,3,0]  R1157     -1.9027492403984070e-01
    z[4,3,0]  R1158     -2.0767155289649963e-01
    z[4,3,0]  R1159     -4.4648265838623047e-01
    z[4,3,0]  R1160     -0.127395898103714
    z[4,3,0]  R1161     -6.2777155637741089e-01
    z[4,3,0]  R1162     -2.4436137080192566e-01
    z[4,3,0]  R1163     -2.9672563076019287e-01
    z[4,3,0]  R1164     -5.6023168563842773e-01
    z[4,3,0]  R1165     -2.2943228483200073e-01
    z[4,3,0]  R1166     -3.3806160092353821e-01
    z[4,3,0]  R1167     -3.3537802100181580e-01
    z[4,3,0]  R1168     -2.8405603766441345e-01
    z[4,3,0]  R1169     -2.2720962762832642e-01
    z[4,3,0]  R1170     2.2040279582142830e-02
    z[4,3,0]  R1171     -0.0471559539437294
    z[4,3,0]  R1172     1.5134997665882111e-01
    z[4,3,0]  R1173     3.6984187364578247e-01
    z[4,3,0]  R1174     -5.7003587484359741e-01
    z[4,3,0]  R1175     1.9555503129959106e-01
    z[4,3,0]  R1176     -5.0418472290039062e-01
    z[4,3,0]  R1177     -0.566318929195404
    z[4,3,0]  R1178     -2.7169395238161087e-02
    z[4,3,0]  R1179     4.0753343701362610e-01
    z[4,3,0]  R1180     1.9366508722305298e-01
    z[4,3,0]  R1181     -7.1623331308364868e-01
    z[4,3,0]  R1182     3.7577813863754272e-01
    z[4,3,0]  R1183     1.7083208262920380e-01
    z[4,3,0]  R1184     1.7021400853991508e-03
    z[4,3,0]  R1185     3.0672988295555115e-01
    z[4,3,0]  R1186     3.3502897620201111e-01
    z[4,3,0]  R1187     -4.8495680093765259e-01
    z[4,3,0]  R1188     -7.5788080692291260e-01
    z[4,3,0]  R1189     -2.8400537371635437e-01
    z[4,3,0]  R1190     -1.9477254152297974e-01
    z[4,3,0]  R1191     -4.4092038273811340e-01
    z[4,3,0]  R1192     1.6808068752288818e-01
    z[4,3,0]  R1193     3.0650016665458679e-01
    z[4,3,0]  R1194     -4.8207080364227295e-01
    z[4,3,0]  R1195     0.021457489579916
    z[4,3,0]  R1196     1.5523508191108704e-01
    z[4,3,0]  R1197     1.5136989951133728e-01
    z[4,3,0]  R1198     1.7610202729701996e-01
    z[4,3,0]  R1199     1.2261650711297989e-01
    z[4,3,0]  R1200     -5.4844474792480469e-01
    z[4,3,0]  R1201     -5.2444231510162354e-01
    z[4,3,0]  R1202     -4.6172222495079041e-01
    z[4,3,0]  R1203     -0.569028913974762
    z[4,3,0]  R1204     -5.6284797191619873e-01
    z[4,3,0]  R1205     -4.1871842741966248e-01
    z[4,3,0]  R1206     -5.5132120847702026e-01
    z[4,3,0]  R1207     1.2665323913097382e-01
    z[4,3,0]  R1208     1.7611831426620483e-01
    z[4,3,0]  R1209     4.7245588898658752e-01
    z[4,3,0]  R1210     1.6912671923637390e-01
    z[4,3,0]  R1211     -5.5089020729064941e-01
    z[4,3,0]  R1212     -5.6645786762237549e-01
    z[4,3,0]  R1213     -4.5239266753196716e-01
    z[4,3,0]  R1214     -7.2609871625900269e-02
    z[4,3,0]  R1215     2.0316435396671295e-01
    z[4,3,0]  R1216     1.5671840310096741e-01
    z[4,3,0]  R1217     1.0520647466182709e-01
    z[4,3,0]  R1218     -3.4679239988327026e-01
    z[4,3,0]  R1219     3.1635525822639465e-01
    z[4,3,0]  R1220     2.4061417579650879e-01
    z[4,3,0]  R1221     1.3621720671653748e-01
    z[4,3,0]  R1222     1.2337982654571533e-01
    z[4,3,0]  R1223     -1.5169952809810638e-01
    z[4,3,0]  R1224     2.2870300710201263e-01
    z[4,3,0]  R1225     -1.9770224392414093e-01
    z[4,3,0]  R1226     2.8880143165588379e-01
    z[4,3,0]  R1227     -1.5453328192234039e-01
    z[4,3,0]  R1228     3.8862389326095581e-01
    z[4,3,0]  R1229     3.7091308832168579e-01
    z[4,3,0]  R1230     0.478127658367157
    z[4,3,0]  R1231     4.6311464905738831e-01
    z[4,3,0]  R1232     4.7244840860366821e-01
    z[4,3,0]  R1233     -3.2537445425987244e-01
    z[4,3,0]  R1234     4.7602352499961853e-01
    z[4,3,0]  R1235     2.5705429911613464e-01
    z[4,3,0]  R1236     5.9679847955703735e-01
    z[4,3,0]  R1237     4.8446375131607056e-01
    z[4,3,0]  R1238     -1.4129619300365448e-01
    z[4,3,0]  R1239     -2.4598467350006104e-01
    z[4,3,0]  R1240     -2.2360714152455330e-02
    z[4,3,0]  R1241     4.9472215771675110e-01
    z[4,3,0]  R1242     -2.9698467254638672e-01
    z[4,3,0]  R1243     9.5166578888893127e-02
    z[4,3,0]  R1244     -8.4637673571705818e-03
    z[4,3,0]  R1245     3.5379037261009216e-01
    z[4,3,0]  R1246     -4.9908825755119324e-01
    z[4,3,0]  R1247     2.0909052342176437e-02
    z[4,3,0]  R1248     -1.6441054642200470e-01
    z[4,3,0]  R1249     -4.1640344262123108e-01
    z[4,3,0]  R1250     2.3950491845607758e-01
    z[4,3,0]  R1251     -3.0985912680625916e-01
    z[4,3,0]  R1252     1.3322702050209045e-01
    z[4,3,0]  R1253     2.8159549832344055e-01
    z[4,3,0]  R1254     -5.0860035419464111e-01
    z[4,3,0]  R1255     -2.9777538776397705e-01
    z[4,3,0]  R1256     1.0051559656858444e-01
    z[4,3,0]  R1257     -4.4247376918792725e-01
    z[4,3,0]  R1258     -1.9971807301044464e-01
    z[4,3,0]  R1259     -1.4479297399520874e-01
    z[4,3,0]  R1260     3.1530305743217468e-01
    z[4,3,0]  R1261     -4.0553700923919678e-01
    z[4,3,0]  R1262     2.8023305535316467e-01
    z[4,3,0]  R1263     1.1138470470905304e-01
    z[4,3,0]  R1264     -1.4050295948982239e-01
    z[4,3,0]  R1265     -1.6415895521640778e-01
    z[4,3,0]  R1266     -3.0126294121146202e-02
    z[4,3,0]  R1267     -2.0682542026042938e-01
    z[4,3,1]  R30       1
    z[4,3,1]  R39       -1
    z[4,3,1]  R1136     -1
    z[4,3,1]  R1137     1
    z[4,3,1]  R1148     1.1460566520690918e-01
    z[4,3,1]  R1149     2.5463491678237915e-02
    z[4,3,1]  R1150     -1.4563414454460144e-01
    z[4,3,1]  R1151     -1.5058070421218872e-01
    z[4,3,1]  R1152     -2.8103342652320862e-01
    z[4,3,1]  R1153     -3.2171329855918884e-01
    z[4,3,1]  R1154     -4.3177595734596252e-01
    z[4,3,1]  R1155     -5.6893426179885864e-01
    z[4,3,1]  R1156     -6.2713003158569336e-01
    z[4,3,1]  R1157     -3.3543795347213745e-01
    z[4,3,1]  R1158     -5.8244132995605469e-01
    z[4,3,1]  R1159     -6.3318848609924316e-01
    z[4,3,1]  R1160     -5.3689426183700562e-01
    z[4,3,1]  R1161     -4.2378321290016174e-01
    z[4,3,1]  R1162     8.1636792421340942e-01
    z[4,3,1]  R1163     8.2112735509872437e-01
    z[4,3,1]  R1164     7.6580405235290527e-01
    z[4,3,1]  R1165     7.6226824522018433e-01
    z[4,3,1]  R1166     7.1772933006286621e-01
    z[4,3,1]  R1167     7.8388285636901855e-01
    z[4,3,1]  R1168     -7.8066468238830566e-01
    z[4,3,1]  R1169     -5.2805393934249878e-01
    z[4,3,1]  R1170     -4.1029801964759827e-01
    z[4,3,1]  R1171     -2.5612908601760864e-01
    z[4,3,1]  R1172     -3.9278411865234375e-01
    z[4,3,1]  R1173     -5.1957917213439941e-01
    z[4,3,1]  R1174     7.5354062020778656e-02
    z[4,3,1]  R1175     6.4115965366363525e-01
    z[4,3,1]  R1176     6.8383723497390747e-01
    z[4,3,1]  R1177     6.3187509775161743e-01
    z[4,3,1]  R1178     -0.740505576133728
    z[4,3,1]  R1179     -7.3246729373931885e-01
    z[4,3,1]  R1180     -5.8310168981552124e-01
    z[4,3,1]  R1181     3.3649951219558716e-01
    z[4,3,1]  R1182     3.6887574195861816e-01
    z[4,3,1]  R1183     3.4796217083930969e-01
    z[4,3,1]  R1184     4.5040979981422424e-01
    z[4,3,1]  R1185     5.7220572233200073e-01
    z[4,3,1]  R1186     5.9585189819335938e-01
    z[4,3,1]  R1187     6.1750531196594238e-01
    z[4,3,1]  R1188     1.4881081879138947e-01
    z[4,3,1]  R1189     7.4363607168197632e-01
    z[4,3,1]  R1190     0.666480302810669
    z[4,3,1]  R1191     5.0507462024688721e-01
    z[4,3,1]  R1192     9.4165974855422974e-01
    z[4,3,1]  R1193     9.1493850946426392e-01
    z[4,3,1]  R1194     3.8173234462738037e-01
    z[4,3,1]  R1195     9.3927145004272461e-01
    z[4,3,1]  R1196     0.92210853099823
    z[4,3,1]  R1197     9.1048997640609741e-01
    z[4,3,1]  R1198     0.601198136806488
    z[4,3,1]  R1199     4.2409190535545349e-01
    z[4,3,1]  R1200     0.558688759803772
    z[4,3,1]  R1201     3.3374351263046265e-01
    z[4,3,1]  R1202     0.828164279460907
    z[4,3,1]  R1203     6.3915222883224487e-01
    z[4,3,1]  R1204     0.666843056678772
    z[4,3,1]  R1205     7.4222880601882935e-01
    z[4,3,1]  R1206     4.9861952662467957e-01
    z[4,3,1]  R1207     0.881424605846405
    z[4,3,1]  R1208     -4.2620584368705750e-01
    z[4,3,1]  R1209     -3.2889935374259949e-01
    z[4,3,1]  R1210     3.7889429926872253e-01
    z[4,3,1]  R1211     4.2418941855430603e-01
    z[4,3,1]  R1212     6.4593595266342163e-01
    z[4,3,1]  R1213     7.7900153398513794e-01
    z[4,3,1]  R1214     8.7439858913421631e-01
    z[4,3,1]  R1215     7.5653755664825439e-01
    z[4,3,1]  R1216     7.9470765590667725e-01
    z[4,3,1]  R1217     3.3972927927970886e-01
    z[4,3,1]  R1218     -5.2148234844207764e-01
    z[4,3,1]  R1219     8.3416923880577087e-02
    z[4,3,1]  R1220     -5.1724594831466675e-01
    z[4,3,1]  R1221     0.436928391456604
    z[4,3,1]  R1222     0.481802374124527
    z[4,3,1]  R1223     -4.2934402823448181e-01
    z[4,3,1]  R1224     4.3029200285673141e-02
    z[4,3,1]  R1225     -3.1166023015975952e-01
    z[4,3,1]  R1226     -9.3946449458599091e-02
    z[4,3,1]  R1227     2.3569411039352417e-01
    z[4,3,1]  R1228     -3.9549741148948669e-01
    z[4,3,1]  R1229     -3.2833805680274963e-01
    z[4,3,1]  R1230     -4.0744832158088684e-01
    z[4,3,1]  R1231     -7.6940737664699554e-02
    z[4,3,1]  R1232     -1.4032201468944550e-01
    z[4,3,1]  R1233     -2.6081937551498413e-01
    z[4,3,1]  R1234     -4.7939816117286682e-01
    z[4,3,1]  R1235     -5.7229530811309814e-01
    z[4,3,1]  R1236     -1.1862655729055405e-01
    z[4,3,1]  R1237     -2.3100028932094574e-01
    z[4,3,1]  R1238     -3.8691377639770508e-01
    z[4,3,1]  R1239     -1.3536162674427032e-01
    z[4,3,1]  R1240     -8.1442302465438843e-01
    z[4,3,1]  R1241     2.1609127521514893e-01
    z[4,3,1]  R1242     -8.0153423547744751e-01
    z[4,3,1]  R1243     -7.2501242160797119e-01
    z[4,3,1]  R1244     -9.2812252044677734e-01
    z[4,3,1]  R1245     5.6346774101257324e-01
    z[4,3,1]  R1246     0.726138710975647
    z[4,3,1]  R1247     -0.0324397049844265
    z[4,3,1]  R1248     -3.2403391599655151e-01
    z[4,3,1]  R1249     -4.0914842486381531e-01
    z[4,3,1]  R1250     -5.8479070663452148e-01
    z[4,3,1]  R1251     -6.0351520776748657e-01
    z[4,3,1]  R1252     1.4922253787517548e-01
    z[4,3,1]  R1253     5.9933638572692871e-01
    z[4,3,1]  R1254     4.6213066577911377e-01
    z[4,3,1]  R1255     0.813393771648407
    z[4,3,1]  R1256     4.7956377267837524e-01
    z[4,3,1]  R1257     6.3635557889938354e-01
    z[4,3,1]  R1258     -3.5282588005065918e-01
    z[4,3,1]  R1259     -5.1891523599624634e-01
    z[4,3,1]  R1260     -7.3771619796752930e-01
    z[4,3,1]  R1261     -6.7508661746978760e-01
    z[4,3,1]  R1262     3.8875925540924072e-01
    z[4,3,1]  R1263     5.7495909929275513e-01
    z[4,3,1]  R1264     5.7786947488784790e-01
    z[4,3,1]  R1265     8.9735507965087891e-01
    z[4,3,1]  R1266     4.3170607089996338e-01
    z[4,3,1]  R1267     7.3682177066802979e-01
    z[4,3,2]  R31       1
    z[4,3,2]  R40       -1
    z[4,3,2]  R1138     -1
    z[4,3,2]  R1139     1
    z[4,3,2]  R1148     -1.1033765971660614e-01
    z[4,3,2]  R1149     -2.3953357338905334e-01
    z[4,3,2]  R1150     -3.6573097109794617e-02
    z[4,3,2]  R1151     2.4638488888740540e-01
    z[4,3,2]  R1152     -4.1139110922813416e-02
    z[4,3,2]  R1153     -7.4872829020023346e-02
    z[4,3,2]  R1154     0.201263889670372
    z[4,3,2]  R1155     5.1678277552127838e-02
    z[4,3,2]  R1156     -2.8553009033203125e-01
    z[4,3,2]  R1157     2.0388789474964142e-01
    z[4,3,2]  R1158     3.0496206879615784e-01
    z[4,3,2]  R1159     1.5170499682426453e-01
    z[4,3,2]  R1160     3.4554663300514221e-01
    z[4,3,2]  R1161     4.3080207705497742e-01
    z[4,3,2]  R1162     -4.5506325364112854e-01
    z[4,3,2]  R1163     -4.5871418714523315e-01
    z[4,3,2]  R1164     -2.5207144021987915e-01
    z[4,3,2]  R1165     -5.3996407985687256e-01
    z[4,3,2]  R1166     -4.7224959731101990e-01
    z[4,3,2]  R1167     -4.2015898227691650e-01
    z[4,3,2]  R1168     -2.5683504343032837e-01
    z[4,3,2]  R1169     -0.00099270383361727
    z[4,3,2]  R1170     3.0738282203674316e-01
    z[4,3,2]  R1171     8.9336413145065308e-01
    z[4,3,2]  R1172     1.6484551131725311e-01
    z[4,3,2]  R1173     -5.5105859041213989e-01
    z[4,3,2]  R1174     -5.1811766624450684e-01
    z[4,3,2]  R1175     5.8941847085952759e-01
    z[4,3,2]  R1176     -3.3432438969612122e-01
    z[4,3,2]  R1177     -0.340804785490036
    z[4,3,2]  R1178     4.6320453286170959e-01
    z[4,3,2]  R1179     -5.8638896793127060e-02
    z[4,3,2]  R1180     -0.0315396711230278
    z[4,3,2]  R1181     -2.2471982240676880e-01
    z[4,3,2]  R1182     6.4761632680892944e-01
    z[4,3,2]  R1183     4.8071259260177612e-01
    z[4,3,2]  R1184     0.53521329164505
    z[4,3,2]  R1185     1.8668556213378906e-01
    z[4,3,2]  R1186     2.4896225333213806e-01
    z[4,3,2]  R1187     -3.5354679822921753e-01
    z[4,3,2]  R1188     -2.5364935398101807e-01
    z[4,3,2]  R1189     -5.8455985784530640e-01
    z[4,3,2]  R1190     -4.2960298061370850e-01
    z[4,3,2]  R1191     -3.8094425201416016e-01
    z[4,3,2]  R1192     -4.5056834816932678e-02
    z[4,3,2]  R1193     -1.1783744394779205e-01
    z[4,3,2]  R1194     -5.1590472459793091e-01
    z[4,3,2]  R1195     3.7413392215967178e-02
    z[4,3,2]  R1196     -5.4214667528867722e-02
    z[4,3,2]  R1197     -2.0445628464221954e-01
    z[4,3,2]  R1198     5.7721412181854248e-01
    z[4,3,2]  R1199     3.1412672996520996e-01
    z[4,3,2]  R1200     -4.0260905027389526e-01
    z[4,3,2]  R1201     -6.7133563756942749e-01
    z[4,3,2]  R1202     5.5074214935302734e-02
    z[4,3,2]  R1203     -1.4470370113849640e-01
    z[4,3,2]  R1204     -1.5852785110473633e-01
    z[4,3,2]  R1205     5.9551354497671127e-03
    z[4,3,2]  R1206     -2.4570623040199280e-01
    z[4,3,2]  R1207     -1.9592528045177460e-01
    z[4,3,2]  R1208     4.2542022466659546e-01
    z[4,3,2]  R1209     3.2853364944458008e-01
    z[4,3,2]  R1210     5.1375579833984375e-01
    z[4,3,2]  R1211     -5.5606234073638916e-01
    z[4,3,2]  R1212     -2.3779833316802979e-01
    z[4,3,2]  R1213     -1.7113822698593140e-01
    z[4,3,2]  R1214     0.0406145378947258
    z[4,3,2]  R1215     -3.0740597844123840e-01
    z[4,3,2]  R1216     2.9896411299705505e-01
    z[4,3,2]  R1217     -5.1972858607769012e-02
    z[4,3,2]  R1218     1.5335462987422943e-01
    z[4,3,2]  R1219     -6.0049909353256226e-01
    z[4,3,2]  R1220     5.4962551593780518e-01
    z[4,3,2]  R1221     -3.2779499888420105e-01
    z[4,3,2]  R1222     -3.8564798235893250e-01
    z[4,3,2]  R1223     -4.9620741046965122e-03
    z[4,3,2]  R1224     -4.8943346738815308e-01
    z[4,3,2]  R1225     1.8296520411968231e-01
    z[4,3,2]  R1226     -4.2893221974372864e-01
    z[4,3,2]  R1227     -2.5571811944246292e-02
    z[4,3,2]  R1228     3.3236268162727356e-01
    z[4,3,2]  R1229     4.7776794433593750e-01
    z[4,3,2]  R1230     5.4234284162521362e-01
    z[4,3,2]  R1231     3.3731272816658020e-01
    z[4,3,2]  R1232     6.2042981386184692e-01
    z[4,3,2]  R1233     -4.3763765692710876e-01
    z[4,3,2]  R1234     2.6428681612014771e-01
    z[4,3,2]  R1235     1.4328658580780029e-03
    z[4,3,2]  R1236     3.2177260518074036e-01
    z[4,3,2]  R1237     1.7702539265155792e-01
    z[4,3,2]  R1238     -7.1257036924362183e-01
    z[4,3,2]  R1239     -5.8643120527267456e-01
    z[4,3,2]  R1240     -1.3432666659355164e-01
    z[4,3,2]  R1241     4.8286509513854980e-01
    z[4,3,2]  R1242     -4.7755271196365356e-01
    z[4,3,2]  R1243     -2.8411459922790527e-01
    z[4,3,2]  R1244     -1.3416558504104614e-01
    z[4,3,2]  R1245     7.0129656791687012e-01
    z[4,3,2]  R1246     -3.3579519391059875e-01
    z[4,3,2]  R1247     1.0880029201507568e-01
    z[4,3,2]  R1248     -0.604345440864563
    z[4,3,2]  R1249     -2.9558802023530006e-02
    z[4,3,2]  R1250     1.1722157150506973e-01
    z[4,3,2]  R1251     3.9034938812255859e-01
    z[4,3,2]  R1252     4.1221952438354492e-01
    z[4,3,2]  R1253     -1.5346366167068481e-01
    z[4,3,2]  R1254     -6.5238827466964722e-01
    z[4,3,2]  R1255     -4.8277732729911804e-01
    z[4,3,2]  R1256     6.8101976066827774e-03
    z[4,3,2]  R1257     -5.9404021501541138e-01
    z[4,3,2]  R1258     -3.6452940106391907e-01
    z[4,3,2]  R1259     -2.5705328583717346e-01
    z[4,3,2]  R1260     -5.0469189882278442e-03
    z[4,3,2]  R1261     1.0578592121601105e-01
    z[4,3,2]  R1262     6.2631016969680786e-01
    z[4,3,2]  R1263     -2.6241201162338257e-01
    z[4,3,2]  R1264     -9.8471298813819885e-02
    z[4,3,2]  R1265     -3.2202121615409851e-01
    z[4,3,2]  R1266     -2.2024551033973694e-01
    z[4,3,2]  R1267     -3.5296049714088440e-01
    z[4,3,3]  R32       1
    z[4,3,3]  R41       -1
    z[4,3,3]  R1140     -1
    z[4,3,3]  R1141     1
    z[4,3,3]  R1148     -3.0676627159118652e-01
    z[4,3,3]  R1149     -3.7245699763298035e-01
    z[4,3,3]  R1150     -2.3310832679271698e-02
    z[4,3,3]  R1151     -2.8134772181510925e-01
    z[4,3,3]  R1152     -1.6613277792930603e-01
    z[4,3,3]  R1153     -7.2090911865234375e-01
    z[4,3,3]  R1154     3.1365206837654114e-01
    z[4,3,3]  R1155     3.5603219270706177e-01
    z[4,3,3]  R1156     5.1434355974197388e-01
    z[4,3,3]  R1157     7.0499561727046967e-02
    z[4,3,3]  R1158     -1.6654946375638247e-03
    z[4,3,3]  R1159     1.5276117250323296e-02
    z[4,3,3]  R1160     -4.7179181128740311e-02
    z[4,3,3]  R1161     -1.7511065304279327e-01
    z[4,3,3]  R1162     2.0056959986686707e-01
    z[4,3,3]  R1163     -2.2695591673254967e-02
    z[4,3,3]  R1164     -6.3069827854633331e-02
    z[4,3,3]  R1165     1.6770876944065094e-01
    z[4,3,3]  R1166     1.6817204654216766e-01
    z[4,3,3]  R1167     2.3151952773332596e-02
    z[4,3,3]  R1168     2.6901695132255554e-01
    z[4,3,3]  R1169     9.3601889908313751e-02
    z[4,3,3]  R1170     1.2430024892091751e-01
    z[4,3,3]  R1171     3.3441290725022554e-03
    z[4,3,3]  R1172     3.0803942680358887e-01
    z[4,3,3]  R1173     2.7731612324714661e-01
    z[4,3,3]  R1174     -1.8918864428997040e-01
    z[4,3,3]  R1175     -2.8639551997184753e-01
    z[4,3,3]  R1176     2.2982136905193329e-01
    z[4,3,3]  R1177     3.6958608776330948e-02
    z[4,3,3]  R1178     2.4177664518356323e-01
    z[4,3,3]  R1179     3.7974965572357178e-01
    z[4,3,3]  R1180     1.0621663928031921e-01
    z[4,3,3]  R1181     -2.0878523588180542e-01
    z[4,3,3]  R1182     -1.9266463816165924e-01
    z[4,3,3]  R1183     -0.259590208530426
    z[4,3,3]  R1184     -3.4287315607070923e-01
    z[4,3,3]  R1185     -1.7056691646575928e-01
    z[4,3,3]  R1186     -1.5326879918575287e-01
    z[4,3,3]  R1187     2.7780768275260925e-01
    z[4,3,3]  R1188     -2.1395921707153320e-01
    z[4,3,3]  R1189     -5.2395123988389969e-02
    z[4,3,3]  R1190     0.516957700252533
    z[4,3,3]  R1191     0.528457522392273
    z[4,3,3]  R1192     -2.6437327265739441e-01
    z[4,3,3]  R1193     -2.1248273551464081e-01
    z[4,3,3]  R1194     3.1534832715988159e-01
    z[4,3,3]  R1195     -0.283624529838562
    z[4,3,3]  R1196     -2.2017486393451691e-01
    z[4,3,3]  R1197     -2.1831075847148895e-01
    z[4,3,3]  R1198     -2.7722486853599548e-01
    z[4,3,3]  R1199     -2.7675676345825195e-01
    z[4,3,3]  R1200     4.1128787398338318e-01
    z[4,3,3]  R1201     3.1493067741394043e-01
    z[4,3,3]  R1202     2.9338827729225159e-01
    z[4,3,3]  R1203     1.9708785414695740e-01
    z[4,3,3]  R1204     -5.1215752959251404e-02
    z[4,3,3]  R1205     4.0755963325500488e-01
    z[4,3,3]  R1206     3.3523747324943542e-01
    z[4,3,3]  R1207     -2.8534629940986633e-01
    z[4,3,3]  R1208     1.2849889695644379e-01
    z[4,3,3]  R1209     1.1477474868297577e-01
    z[4,3,3]  R1210     -0.214838445186615
    z[4,3,3]  R1211     2.5786882638931274e-01
    z[4,3,3]  R1212     2.0320130884647369e-01
    z[4,3,3]  R1213     -1.7632950842380524e-01
    z[4,3,3]  R1214     -3.4535399079322815e-01
    z[4,3,3]  R1215     -1.1928913742303848e-01
    z[4,3,3]  R1216     -2.3364393413066864e-01
    z[4,3,3]  R1217     7.0739632844924927e-01
    z[4,3,3]  R1218     1.3980150222778320e-01
    z[4,3,3]  R1219     -4.8543652892112732e-01
    z[4,3,3]  R1220     0.349149614572525
    z[4,3,3]  R1221     -7.0498067140579224e-01
    z[4,3,3]  R1222     -6.4381921291351318e-01
    z[4,3,3]  R1223     2.5701728463172913e-01
    z[4,3,3]  R1224     -5.4006010293960571e-01
    z[4,3,3]  R1225     -0.0647614598274231
    z[4,3,3]  R1226     -1.8884766101837158e-01
    z[4,3,3]  R1227     -4.9562579393386841e-01
    z[4,3,3]  R1228     -7.6045602560043335e-01
    z[4,3,3]  R1229     -6.8463677167892456e-01
    z[4,3,3]  R1230     -3.7467747926712036e-01
    z[4,3,3]  R1231     -7.0945578813552856e-01
    z[4,3,3]  R1232     -4.7919160127639771e-01
    z[4,3,3]  R1233     -6.2790863215923309e-02
    z[4,3,3]  R1234     -5.4137378931045532e-01
    z[4,3,3]  R1235     -6.1908680200576782e-01
    z[4,3,3]  R1236     -5.0925046205520630e-01
    z[4,3,3]  R1237     -5.1862555742263794e-01
    z[4,3,3]  R1238     0.0450817309319973
    z[4,3,3]  R1239     -6.1120027303695679e-01
    z[4,3,3]  R1240     1.4381159842014313e-01
    z[4,3,3]  R1241     -4.9036917090415955e-01
    z[4,3,3]  R1242     -3.7112716585397720e-02
    z[4,3,3]  R1243     1.6053833067417145e-01
    z[4,3,3]  R1244     -2.5952902436256409e-01
    z[4,3,3]  R1245     -1.0738559067249298e-03
    z[4,3,3]  R1246     3.0714073777198792e-01
    z[4,3,3]  R1247     8.6557984352111816e-01
    z[4,3,3]  R1248     -4.5465391874313354e-01
    z[4,3,3]  R1249     -4.8944808542728424e-02
    z[4,3,3]  R1250     3.8044983148574829e-01
    z[4,3,3]  R1251     -2.1053658425807953e-01
    z[4,3,3]  R1252     8.1655263900756836e-01
    z[4,3,3]  R1253     -5.5685347318649292e-01
    z[4,3,3]  R1254     3.0859303474426270e-01
    z[4,3,3]  R1255     -6.4833253622055054e-02
    z[4,3,3]  R1256     6.2604665756225586e-01
    z[4,3,3]  R1257     1.9388185441493988e-01
    z[4,3,3]  R1258     -3.7968146800994873e-01
    z[4,3,3]  R1259     7.0764243602752686e-01
    z[4,3,3]  R1260     -2.8273233771324158e-01
    z[4,3,3]  R1261     7.9361535608768463e-02
    z[4,3,3]  R1262     -4.0932792425155640e-01
    z[4,3,3]  R1263     -6.0328519344329834e-01
    z[4,3,3]  R1264     7.1337640285491943e-01
    z[4,3,3]  R1265     1.6910864412784576e-01
    z[4,3,3]  R1266     6.6688686609268188e-01
    z[4,3,3]  R1267     8.0330856144428253e-02
    z[4,3,4]  R33       1
    z[4,3,4]  R42       -1
    z[4,3,4]  R1142     -1
    z[4,3,4]  R1143     1
    z[4,3,4]  R1148     -2.1605329215526581e-01
    z[4,3,4]  R1149     1.7489252984523773e-01
    z[4,3,4]  R1150     2.0510016381740570e-01
    z[4,3,4]  R1151     -1.3762958347797394e-01
    z[4,3,4]  R1152     -3.1085237860679626e-02
    z[4,3,4]  R1153     -1.3170013204216957e-02
    z[4,3,4]  R1154     2.0437940955162048e-01
    z[4,3,4]  R1155     -4.2405596375465393e-01
    z[4,3,4]  R1156     1.8331797420978546e-01
    z[4,3,4]  R1157     -1.0111937671899796e-01
    z[4,3,4]  R1158     1.5326094627380371e-01
    z[4,3,4]  R1159     -1.0808974504470825e-01
    z[4,3,4]  R1160     -4.3306279182434082e-01
    z[4,3,4]  R1161     3.9568793773651123e-01
    z[4,3,4]  R1162     1.1852863430976868e-01
    z[4,3,4]  R1163     1.4173589646816254e-01
    z[4,3,4]  R1164     -1.1155854910612106e-01
    z[4,3,4]  R1165     1.6141225397586823e-01
    z[4,3,4]  R1166     7.3472797870635986e-02
    z[4,3,4]  R1167     -5.3109776228666306e-02
    z[4,3,4]  R1168     -3.1306478381156921e-01
    z[4,3,4]  R1169     5.5055856704711914e-01
    z[4,3,4]  R1170     2.6041364669799805e-01
    z[4,3,4]  R1171     -2.0082934200763702e-01
    z[4,3,4]  R1172     -5.9684371948242188e-01
    z[4,3,4]  R1173     4.0093538165092468e-01
    z[4,3,4]  R1174     3.3297979831695557e-01
    z[4,3,4]  R1175     3.2784977555274963e-01
    z[4,3,4]  R1176     2.8037330508232117e-01
    z[4,3,4]  R1177     1.7677634954452515e-01
    z[4,3,4]  R1178     -2.9274460673332214e-01
    z[4,3,4]  R1179     7.1325547993183136e-02
    z[4,3,4]  R1180     6.5629088878631592e-01
    z[4,3,4]  R1181     -3.2649514079093933e-01
    z[4,3,4]  R1182     3.2498300075531006e-01
    z[4,3,4]  R1183     7.2262948751449585e-01
    z[4,3,4]  R1184     4.5627161860466003e-01
    z[4,3,4]  R1185     5.5931615829467773e-01
    z[4,3,4]  R1186     3.8837355375289917e-01
    z[4,3,4]  R1187     1.7797181010246277e-01
    z[4,3,4]  R1188     -2.0552127063274384e-01
    z[4,3,4]  R1189     -1.3959896750748158e-02
    z[4,3,4]  R1190     -1.4487208425998688e-01
    z[4,3,4]  R1191     -2.1121428906917572e-01
    z[4,3,4]  R1192     3.6880597472190857e-02
    z[4,3,4]  R1193     -5.3045139648020267e-03
    z[4,3,4]  R1194     -6.0588344931602478e-02
    z[4,3,4]  R1195     -9.6480615437030792e-02
    z[4,3,4]  R1196     -5.9477563947439194e-02
    z[4,3,4]  R1197     5.1358029246330261e-02
    z[4,3,4]  R1198     3.8351699709892273e-01
    z[4,3,4]  R1199     7.9344105720520020e-01
    z[4,3,4]  R1200     1.6153217852115631e-01
    z[4,3,4]  R1201     2.5022806599736214e-02
    z[4,3,4]  R1202     -0.0460795983672142
    z[4,3,4]  R1203     -2.1581773459911346e-01
    z[4,3,4]  R1204     -4.8652660101652145e-02
    z[4,3,4]  R1205     -1.3221164047718048e-01
    z[4,3,4]  R1206     -1.9343020021915436e-01
    z[4,3,4]  R1207     2.8541228175163269e-01
    z[4,3,4]  R1208     -1.5745188295841217e-01
    z[4,3,4]  R1209     -2.8067368548363447e-03
    z[4,3,4]  R1210     0.63071209192276
    z[4,3,4]  R1211     2.8684103488922119e-01
    z[4,3,4]  R1212     -1.5300603210926056e-01
    z[4,3,4]  R1213     1.2116441875696182e-01
    z[4,3,4]  R1214     -6.6729813814163208e-02
    z[4,3,4]  R1215     -3.4673970937728882e-01
    z[4,3,4]  R1216     -3.7755584716796875e-01
    z[4,3,4]  R1217     -4.7383829951286316e-01
    z[4,3,4]  R1218     -4.8401427268981934e-01
    z[4,3,4]  R1219     4.6343751251697540e-02
    z[4,3,4]  R1220     5.4460112005472183e-02
    z[4,3,4]  R1221     -3.2666212320327759e-01
    z[4,3,4]  R1222     1.3809368014335632e-01
    z[4,3,4]  R1223     6.6078805923461914e-01
    z[4,3,4]  R1224     -3.1959589570760727e-02
    z[4,3,4]  R1225     4.6754062175750732e-01
    z[4,3,4]  R1226     -3.1381070613861084e-01
    z[4,3,4]  R1227     -6.2581133842468262e-01
    z[4,3,4]  R1228     -1.9610758870840073e-02
    z[4,3,4]  R1229     -4.9195587635040283e-02
    z[4,3,4]  R1230     2.2888121008872986e-01
    z[4,3,4]  R1231     1.2012667208909988e-01
    z[4,3,4]  R1232     -3.0425125360488892e-01
    z[4,3,4]  R1233     -7.9097676277160645e-01
    z[4,3,4]  R1234     2.3311580717563629e-01
    z[4,3,4]  R1235     -1.8523296713829041e-01
    z[4,3,4]  R1236     2.3390786349773407e-01
    z[4,3,4]  R1237     5.2037900686264038e-01
    z[4,3,4]  R1238     -2.6308125257492065e-01
    z[4,3,4]  R1239     4.4833451509475708e-01
    z[4,3,4]  R1240     -2.2582834959030151e-01
    z[4,3,4]  R1241     4.2494514584541321e-01
    z[4,3,4]  R1242     2.3748284205794334e-02
    z[4,3,4]  R1243     -5.7107824832201004e-02
    z[4,3,4]  R1244     1.9484585523605347e-01
    z[4,3,4]  R1245     4.0376982651650906e-03
    z[4,3,4]  R1246     1.2568618357181549e-01
    z[4,3,4]  R1247     -3.9516729116439819e-01
    z[4,3,4]  R1248     -4.3289104104042053e-01
    z[4,3,4]  R1249     1.7633788287639618e-01
    z[4,3,4]  R1250     -3.3293321728706360e-02
    z[4,3,4]  R1251     3.1441393494606018e-01
    z[4,3,4]  R1252     2.5045558810234070e-01
    z[4,3,4]  R1253     1.5220838785171509e-01
    z[4,3,4]  R1254     3.3705178648233414e-02
    z[4,3,4]  R1255     -8.6671836674213409e-02
    z[4,3,4]  R1256     5.3131759166717529e-01
    z[4,3,4]  R1257     -2.8040159493684769e-02
    z[4,3,4]  R1258     -1.8048363924026489e-01
    z[4,3,4]  R1259     2.8188863396644592e-01
    z[4,3,4]  R1260     -0.0724576786160469
    z[4,3,4]  R1261     2.1844211220741272e-01
    z[4,3,4]  R1262     -1.2153670191764832e-01
    z[4,3,4]  R1263     -1.3801916502416134e-02
    z[4,3,4]  R1264     2.5893816351890564e-01
    z[4,3,4]  R1265     4.8382304608821869e-02
    z[4,3,4]  R1266     -2.3363950848579407e-01
    z[4,3,4]  R1267     -4.4344505667686462e-01
    z[4,3,5]  R34       1
    z[4,3,5]  R43       -1
    z[4,3,5]  R1144     -1
    z[4,3,5]  R1145     1
    z[4,3,5]  R1148     -6.7718826234340668e-02
    z[4,3,5]  R1149     -1.5975473821163177e-01
    z[4,3,5]  R1150     1.3967177830636501e-02
    z[4,3,5]  R1151     -3.1440812349319458e-01
    z[4,3,5]  R1152     1.2479781359434128e-01
    z[4,3,5]  R1153     -0.0166141539812088
    z[4,3,5]  R1154     -2.0086416602134705e-01
    z[4,3,5]  R1155     -3.5767531394958496e-01
    z[4,3,5]  R1156     -1.8736422061920166e-01
    z[4,3,5]  R1157     -8.6757856607437134e-01
    z[4,3,5]  R1158     3.3237785100936890e-01
    z[4,3,5]  R1159     8.4211677312850952e-02
    z[4,3,5]  R1160     6.0218435525894165e-01
    z[4,3,5]  R1161     1.7615026235580444e-01
    z[4,3,5]  R1162     9.3072645366191864e-02
    z[4,3,5]  R1163     -5.5267107672989368e-03
    z[4,3,5]  R1164     -1.2235080450773239e-01
    z[4,3,5]  R1165     -5.0252329558134079e-02
    z[4,3,5]  R1166     1.0249210149049759e-01
    z[4,3,5]  R1167     5.2654266357421875e-02
    z[4,3,5]  R1168     -2.7082479000091553e-01
    z[4,3,5]  R1169     -1.8426083028316498e-01
    z[4,3,5]  R1170     5.4612624645233154e-01
    z[4,3,5]  R1171     -1.3940142095088959e-01
    z[4,3,5]  R1172     -9.8460555076599121e-02
    z[4,3,5]  R1173     1.3949838280677795e-01
    z[4,3,5]  R1174     -4.2687162756919861e-01
    z[4,3,5]  R1175     -3.6988869309425354e-02
    z[4,3,5]  R1176     -8.5948094725608826e-02
    z[4,3,5]  R1177     2.4168232083320618e-01
    z[4,3,5]  R1178     2.2038803994655609e-01
    z[4,3,5]  R1179     0.325942724943161
    z[4,3,5]  R1180     1.8155101686716080e-02
    z[4,3,5]  R1181     -3.7361851334571838e-01
    z[4,3,5]  R1182     -3.0973193049430847e-01
    z[4,3,5]  R1183     -1.5568171441555023e-01
    z[4,3,5]  R1184     -0.204054057598114
    z[4,3,5]  R1185     -1.0616850107908249e-02
    z[4,3,5]  R1186     -0.316983163356781
    z[4,3,5]  R1187     1.1278515309095383e-01
    z[4,3,5]  R1188     -4.6136081218719482e-01
    z[4,3,5]  R1189     1.2181588262319565e-01
    z[4,3,5]  R1190     -5.6798618286848068e-02
    z[4,3,5]  R1191     2.6877734065055847e-01
    z[4,3,5]  R1192     9.8095230758190155e-02
    z[4,3,5]  R1193     6.8847984075546265e-02
    z[4,3,5]  R1194     4.6843016147613525e-01
    z[4,3,5]  R1195     -4.8404913395643234e-02
    z[4,3,5]  R1196     -0.00689234584569931
    z[4,3,5]  R1197     -1.0875558108091354e-01
    z[4,3,5]  R1198     1.2592312693595886e-01
    z[4,3,5]  R1199     1.4616641215980053e-02
    z[4,3,5]  R1200     -0.0735788494348526
    z[4,3,5]  R1201     2.4920323491096497e-01
    z[4,3,5]  R1202     7.6562032103538513e-02
    z[4,3,5]  R1203     3.3623912930488586e-01
    z[4,3,5]  R1204     4.5428311824798584e-01
    z[4,3,5]  R1205     1.6750530898571014e-01
    z[4,3,5]  R1206     0.454328328371048
    z[4,3,5]  R1207     1.5757321380078793e-03
    z[4,3,5]  R1208     -7.0956653356552124e-01
    z[4,3,5]  R1209     -1.7349001765251160e-01
    z[4,3,5]  R1210     -1.7410913482308388e-02
    z[4,3,5]  R1211     2.4181802570819855e-01
    z[4,3,5]  R1212     2.8184035420417786e-01
    z[4,3,5]  R1213     3.3563607931137085e-01
    z[4,3,5]  R1214     1.0348308086395264e-01
    z[4,3,5]  R1215     -3.4906560182571411e-01
    z[4,3,5]  R1216     1.1178135871887207e-01
    z[4,3,5]  R1217     1.6751761734485626e-01
    z[4,3,5]  R1218     -3.7373277544975281e-01
    z[4,3,5]  R1219     -2.8061193227767944e-01
    z[4,3,5]  R1220     -2.6671119034290314e-02
    z[4,3,5]  R1221     -1.1959427595138550e-01
    z[4,3,5]  R1222     -3.1937101483345032e-01
    z[4,3,5]  R1223     -3.6324670910835266e-01
    z[4,3,5]  R1224     -8.2112692296504974e-02
    z[4,3,5]  R1225     -6.9876688718795776e-01
    z[4,3,5]  R1226     -0.394333153963089
    z[4,3,5]  R1227     -4.3859738111495972e-01
    z[4,3,5]  R1228     3.3692322671413422e-02
    z[4,3,5]  R1229     -1.6348755359649658e-01
    z[4,3,5]  R1230     -2.0855288952589035e-02
    z[4,3,5]  R1231     2.0821157097816467e-01
    z[4,3,5]  R1232     -0.0433766171336174
    z[4,3,5]  R1233     -5.6146692484617233e-02
    z[4,3,5]  R1234     2.7365830540657043e-01
    z[4,3,5]  R1235     2.2968876361846924e-01
    z[4,3,5]  R1236     4.4170853495597839e-01
    z[4,3,5]  R1237     3.6483103036880493e-01
    z[4,3,5]  R1238     -4.5089519023895264e-01
    z[4,3,5]  R1239     -2.5357827544212341e-02
    z[4,3,5]  R1240     1.5495795011520386e-01
    z[4,3,5]  R1241     8.0810030922293663e-03
    z[4,3,5]  R1242     0.0723768025636673
    z[4,3,5]  R1243     5.9614843130111694e-01
    z[4,3,5]  R1244     5.4889399558305740e-02
    z[4,3,5]  R1245     -0.197321817278862
    z[4,3,5]  R1246     2.7102181687951088e-02
    z[4,3,5]  R1247     2.8337183594703674e-01
    z[4,3,5]  R1248     0.256511926651001
    z[4,3,5]  R1249     -6.9606119394302368e-01
    z[4,3,5]  R1250     3.4793254733085632e-01
    z[4,3,5]  R1251     4.8544409871101379e-01
    z[4,3,5]  R1252     -6.2928862869739532e-02
    z[4,3,5]  R1253     4.3521293997764587e-01
    z[4,3,5]  R1254     -2.1326787769794464e-02
    z[4,3,5]  R1255     1.4439002610743046e-02
    z[4,3,5]  R1256     2.5736328959465027e-01
    z[4,3,5]  R1257     -3.0850782990455627e-02
    z[4,3,5]  R1258     -7.2390139102935791e-01
    z[4,3,5]  R1259     2.4870058894157410e-01
    z[4,3,5]  R1260     5.1580244302749634e-01
    z[4,3,5]  R1261     0.545786440372467
    z[4,3,5]  R1262     -3.3381292223930359e-01
    z[4,3,5]  R1263     2.2834406793117523e-01
    z[4,3,5]  R1264     1.4479791745543480e-02
    z[4,3,5]  R1265     1.4484675228595734e-01
    z[4,3,5]  R1266     5.0283408164978027e-01
    z[4,3,5]  R1267     1.9192793965339661e-01
    z[4,3,6]  R35       1
    z[4,3,6]  R44       -1
    z[4,3,6]  R1146     -1
    z[4,3,6]  R1147     1
    z[4,3,6]  R1148     -8.2207638770341873e-03
    z[4,3,6]  R1149     3.0077984556555748e-02
    z[4,3,6]  R1150     1.1415420472621918e-01
    z[4,3,6]  R1151     -5.2973654121160507e-02
    z[4,3,6]  R1152     -4.7121551632881165e-01
    z[4,3,6]  R1153     -2.0214863121509552e-01
    z[4,3,6]  R1154     -1.6218061745166779e-01
    z[4,3,6]  R1155     -4.4972071051597595e-01
    z[4,3,6]  R1156     -3.0051621794700623e-01
    z[4,3,6]  R1157     -2.0449618995189667e-01
    z[4,3,6]  R1158     6.2503278255462646e-01
    z[4,3,6]  R1159     5.9808266162872314e-01
    z[4,3,6]  R1160     -1.5400396287441254e-01
    z[4,3,6]  R1161     1.4986211061477661e-01
    z[4,3,6]  R1162     6.1714071780443192e-02
    z[4,3,6]  R1163     8.1549547612667084e-02
    z[4,3,6]  R1164     -6.8933911621570587e-02
    z[4,3,6]  R1165     -1.3431830704212189e-01
    z[4,3,6]  R1166     -3.2151910662651062e-01
    z[4,3,6]  R1167     3.0064353346824646e-01
    z[4,3,6]  R1168     1.3593773357570171e-02
    z[4,3,6]  R1169     -5.6895136833190918e-01
    z[4,3,6]  R1170     -0.59595787525177
    z[4,3,6]  R1171     -2.7257740497589111e-01
    z[4,3,6]  R1172     -5.7864898443222046e-01
    z[4,3,6]  R1173     0.180210143327713
    z[4,3,6]  R1174     2.6841688156127930e-01
    z[4,3,6]  R1175     -1.1127635091543198e-01
    z[4,3,6]  R1176     -1.6606491804122925e-01
    z[4,3,6]  R1177     2.6989388465881348e-01
    z[4,3,6]  R1178     -2.0887459814548492e-01
    z[4,3,6]  R1179     -1.9604563713073730e-01
    z[4,3,6]  R1180     4.2327558994293213e-01
    z[4,3,6]  R1181     -1.8302398920059204e-01
    z[4,3,6]  R1182     2.5425758957862854e-01
    z[4,3,6]  R1183     6.9547399878501892e-02
    z[4,3,6]  R1184     3.7853807210922241e-01
    z[4,3,6]  R1185     -4.4900503754615784e-01
    z[4,3,6]  R1186     -4.4264003634452820e-01
    z[4,3,6]  R1187     3.7005007266998291e-01
    z[4,3,6]  R1188     1.9560858607292175e-01
    z[4,3,6]  R1189     -8.2806371152400970e-02
    z[4,3,6]  R1190     2.0457211136817932e-01
    z[4,3,6]  R1191     -9.6177399158477783e-02
    z[4,3,6]  R1192     -4.6039126813411713e-02
    z[4,3,6]  R1193     7.1710072457790375e-02
    z[4,3,6]  R1194     -1.8217626214027405e-01
    z[4,3,6]  R1195     -1.5431955456733704e-01
    z[4,3,6]  R1196     -2.6573812961578369e-01
    z[4,3,6]  R1197     -2.1016108989715576e-01
    z[4,3,6]  R1198     -1.8594941496849060e-01
    z[4,3,6]  R1199     -8.8872546330094337e-03
    z[4,3,6]  R1200     1.5593892335891724e-01
    z[4,3,6]  R1201     0.0312119722366333
    z[4,3,6]  R1202     6.2140613794326782e-02
    z[4,3,6]  R1203     2.1971276402473450e-01
    z[4,3,6]  R1204     -4.5035343617200851e-02
    z[4,3,6]  R1205     -2.4918465316295624e-01
    z[4,3,6]  R1206     -1.7560848593711853e-01
    z[4,3,6]  R1207     7.6011463999748230e-02
    z[4,3,6]  R1208     2.4811469018459320e-01
    z[4,3,6]  R1209     7.1930283308029175e-01
    z[4,3,6]  R1210     -3.4588134288787842e-01
    z[4,3,6]  R1211     1.1311681009829044e-02
    z[4,3,6]  R1212     2.4740378558635712e-01
    z[4,3,6]  R1213     -2.8012450784444809e-02
    z[4,3,6]  R1214     3.0671533942222595e-01
    z[4,3,6]  R1215     0.188604474067688
    z[4,3,6]  R1216     2.1181724965572357e-01
    z[4,3,6]  R1217     3.4324905276298523e-01
    z[4,3,6]  R1218     -4.3678706884384155e-01
    z[4,3,6]  R1219     -4.6456691622734070e-01
    z[4,3,6]  R1220     -4.9688091874122620e-01
    z[4,3,6]  R1221     -2.5510832667350769e-01
    z[4,3,6]  R1222     -2.6143577694892883e-01
    z[4,3,6]  R1223     3.9746630191802979e-01
    z[4,3,6]  R1224     6.3786321878433228e-01
    z[4,3,6]  R1225     3.4531423449516296e-01
    z[4,3,6]  R1226     0.658897340297699
    z[4,3,6]  R1227     -3.0043545365333557e-01
    z[4,3,6]  R1228     4.7700032591819763e-02
    z[4,3,6]  R1229     1.6875910758972168e-01
    z[4,3,6]  R1230     3.4356853365898132e-01
    z[4,3,6]  R1231     -3.2359704375267029e-01
    z[4,3,6]  R1232     2.1930399537086487e-01
    z[4,3,6]  R1233     -4.2879793792963028e-02
    z[4,3,6]  R1234     2.2674646973609924e-01
    z[4,3,6]  R1235     3.6886653304100037e-01
    z[4,3,6]  R1236     1.3063828647136688e-01
    z[4,3,6]  R1237     8.7904646992683411e-02
    z[4,3,6]  R1238     -2.1914835274219513e-01
    z[4,3,6]  R1239     -4.5325968414545059e-02
    z[4,3,6]  R1240     4.7167718410491943e-01
    z[4,3,6]  R1241     2.3300263285636902e-01
    z[4,3,6]  R1242     -1.8468016386032104e-01
    z[4,3,6]  R1243     1.2350400909781456e-02
    z[4,3,6]  R1244     -1.1037850379943848e-01
    z[4,3,6]  R1245     -1.6299147903919220e-01
    z[4,3,6]  R1246     -2.8236522339284420e-03
    z[4,3,6]  R1247     3.1427938491106033e-02
    z[4,3,6]  R1248     2.0696519315242767e-01
    z[4,3,6]  R1249     -3.7461996078491211e-01
    z[4,3,6]  R1250     0.565693199634552
    z[4,3,6]  R1251     9.2446379363536835e-02
    z[4,3,6]  R1252     2.3793274164199829e-01
    z[4,3,6]  R1253     1.2363357841968536e-01
    z[4,3,6]  R1254     -7.3006264865398407e-02
    z[4,3,6]  R1255     6.8720698356628418e-02
    z[4,3,6]  R1256     1.3928471505641937e-01
    z[4,3,6]  R1257     0.0840034931898117
    z[4,3,6]  R1258     4.4490348547697067e-02
    z[4,3,6]  R1259     4.0182426571846008e-02
    z[4,3,6]  R1260     -7.1369171142578125e-02
    z[4,3,6]  R1261     -1.2926366925239563e-01
    z[4,3,6]  R1262     -2.9037842154502869e-01
    z[4,3,6]  R1263     4.1457340121269226e-01
    z[4,3,6]  R1264     2.4589551985263824e-01
    z[4,3,6]  R1265     -1.1040373146533966e-01
    z[4,3,6]  R1266     -1.0975638777017593e-01
    z[4,3,6]  R1267     -2.2316549718379974e-01
    z[3,6,0]  R29       -1
    z[3,6,0]  R56       1
    z[3,6,0]  R1268     -1
    z[3,6,0]  R1269     1
    z[3,6,0]  R1282     -3.4679239988327026e-01
    z[3,6,0]  R1283     3.1635525822639465e-01
    z[3,6,0]  R1284     2.4061417579650879e-01
    z[3,6,0]  R1285     1.3621720671653748e-01
    z[3,6,0]  R1286     1.2337982654571533e-01
    z[3,6,0]  R1287     -1.5169952809810638e-01
    z[3,6,0]  R1288     2.2870300710201263e-01
    z[3,6,0]  R1289     -1.9770224392414093e-01
    z[3,6,0]  R1290     2.8880143165588379e-01
    z[3,6,0]  R1291     -1.5453328192234039e-01
    z[3,6,0]  R1292     3.8862389326095581e-01
    z[3,6,0]  R1293     3.7091308832168579e-01
    z[3,6,0]  R1294     0.478127658367157
    z[3,6,0]  R1295     4.6311464905738831e-01
    z[3,6,0]  R1296     4.7244840860366821e-01
    z[3,6,0]  R1297     -3.2537445425987244e-01
    z[3,6,0]  R1298     4.7602352499961853e-01
    z[3,6,0]  R1299     2.5705429911613464e-01
    z[3,6,0]  R1300     5.9679847955703735e-01
    z[3,6,0]  R1301     4.8446375131607056e-01
    z[3,6,0]  R1302     -1.4129619300365448e-01
    z[3,6,0]  R1303     -2.4598467350006104e-01
    z[3,6,0]  R1304     -2.2360714152455330e-02
    z[3,6,0]  R1305     4.9472215771675110e-01
    z[3,6,0]  R1306     -2.9698467254638672e-01
    z[3,6,0]  R1307     9.5166578888893127e-02
    z[3,6,0]  R1308     -8.4637673571705818e-03
    z[3,6,0]  R1309     3.5379037261009216e-01
    z[3,6,0]  R1310     -4.9908825755119324e-01
    z[3,6,0]  R1311     2.0909052342176437e-02
    z[3,6,0]  R1312     -1.6441054642200470e-01
    z[3,6,0]  R1313     -4.1640344262123108e-01
    z[3,6,0]  R1314     2.3950491845607758e-01
    z[3,6,0]  R1315     -3.0985912680625916e-01
    z[3,6,0]  R1316     1.3322702050209045e-01
    z[3,6,0]  R1317     2.8159549832344055e-01
    z[3,6,0]  R1318     -5.0860035419464111e-01
    z[3,6,0]  R1319     -2.9777538776397705e-01
    z[3,6,0]  R1320     1.0051559656858444e-01
    z[3,6,0]  R1321     -4.4247376918792725e-01
    z[3,6,0]  R1322     -1.9971807301044464e-01
    z[3,6,0]  R1323     -1.4479297399520874e-01
    z[3,6,0]  R1324     3.1530305743217468e-01
    z[3,6,0]  R1325     -4.0553700923919678e-01
    z[3,6,0]  R1326     2.8023305535316467e-01
    z[3,6,0]  R1327     1.1138470470905304e-01
    z[3,6,0]  R1328     -1.4050295948982239e-01
    z[3,6,0]  R1329     -1.6415895521640778e-01
    z[3,6,0]  R1330     -3.0126294121146202e-02
    z[3,6,0]  R1331     -2.0682542026042938e-01
    z[3,6,0]  R1332     0.00948364194482565
    z[3,6,0]  R1333     -7.2981618344783783e-02
    z[3,6,0]  R1334     1.3737419247627258e-01
    z[3,6,0]  R1335     3.1392046809196472e-01
    z[3,6,0]  R1336     -2.3087984323501587e-01
    z[3,6,0]  R1337     -4.2213848233222961e-01
    z[3,6,0]  R1338     1.6414934396743774e-01
    z[3,6,0]  R1339     3.0744003131985664e-02
    z[3,6,0]  R1340     -2.0722879469394684e-01
    z[3,6,0]  R1341     -4.4394785165786743e-01
    z[3,6,0]  R1342     1.7102941870689392e-01
    z[3,6,0]  R1343     -1.8538489937782288e-02
    z[3,6,0]  R1344     8.7123408913612366e-02
    z[3,6,0]  R1345     4.1409574449062347e-02
    z[3,6,0]  R1346     -3.5936015844345093e-01
    z[3,6,0]  R1347     4.4195351004600525e-01
    z[3,6,0]  R1348     6.2430912256240845e-01
    z[3,6,0]  R1349     -8.7492220103740692e-02
    z[3,6,0]  R1350     2.5624117255210876e-01
    z[3,6,0]  R1351     1.1700862646102905e-01
    z[3,6,0]  R1352     5.0234988331794739e-02
    z[3,6,0]  R1353     2.8864863514900208e-01
    z[3,6,0]  R1354     2.2634042799472809e-01
    z[3,6,0]  R1355     1.8652193248271942e-01
    z[3,6,0]  R1356     8.8945478200912476e-03
    z[3,6,0]  R1357     1.6408419609069824e-01
    z[3,6,0]  R1358     -1.7532561719417572e-01
    z[3,6,0]  R1359     -1.5319344401359558e-01
    z[3,6,0]  R1360     -1.9433531910181046e-02
    z[3,6,0]  R1361     -2.4648292362689972e-01
    z[3,6,0]  R1362     2.1938095986843109e-01
    z[3,6,0]  R1363     -1.9774494692683220e-02
    z[3,6,0]  R1364     -3.9564505219459534e-02
    z[3,6,0]  R1365     -1.0036766529083252e-01
    z[3,6,0]  R1366     6.9954305887222290e-02
    z[3,6,0]  R1367     9.8391972482204437e-02
    z[3,6,0]  R1368     -3.1425106525421143e-01
    z[3,6,0]  R1369     -1.5212918631732464e-02
    z[3,6,0]  R1370     2.8497523069381714e-01
    z[3,6,0]  R1371     2.9772745445370674e-02
    z[3,6,1]  R30       -1
    z[3,6,1]  R57       1
    z[3,6,1]  R1270     -1
    z[3,6,1]  R1271     1
    z[3,6,1]  R1282     -5.2148234844207764e-01
    z[3,6,1]  R1283     8.3416923880577087e-02
    z[3,6,1]  R1284     -5.1724594831466675e-01
    z[3,6,1]  R1285     0.436928391456604
    z[3,6,1]  R1286     0.481802374124527
    z[3,6,1]  R1287     -4.2934402823448181e-01
    z[3,6,1]  R1288     4.3029200285673141e-02
    z[3,6,1]  R1289     -3.1166023015975952e-01
    z[3,6,1]  R1290     -9.3946449458599091e-02
    z[3,6,1]  R1291     2.3569411039352417e-01
    z[3,6,1]  R1292     -3.9549741148948669e-01
    z[3,6,1]  R1293     -3.2833805680274963e-01
    z[3,6,1]  R1294     -4.0744832158088684e-01
    z[3,6,1]  R1295     -7.6940737664699554e-02
    z[3,6,1]  R1296     -1.4032201468944550e-01
    z[3,6,1]  R1297     -2.6081937551498413e-01
    z[3,6,1]  R1298     -4.7939816117286682e-01
    z[3,6,1]  R1299     -5.7229530811309814e-01
    z[3,6,1]  R1300     -1.1862655729055405e-01
    z[3,6,1]  R1301     -2.3100028932094574e-01
    z[3,6,1]  R1302     -3.8691377639770508e-01
    z[3,6,1]  R1303     -1.3536162674427032e-01
    z[3,6,1]  R1304     -8.1442302465438843e-01
    z[3,6,1]  R1305     2.1609127521514893e-01
    z[3,6,1]  R1306     -8.0153423547744751e-01
    z[3,6,1]  R1307     -7.2501242160797119e-01
    z[3,6,1]  R1308     -9.2812252044677734e-01
    z[3,6,1]  R1309     5.6346774101257324e-01
    z[3,6,1]  R1310     0.726138710975647
    z[3,6,1]  R1311     -0.0324397049844265
    z[3,6,1]  R1312     -3.2403391599655151e-01
    z[3,6,1]  R1313     -4.0914842486381531e-01
    z[3,6,1]  R1314     -5.8479070663452148e-01
    z[3,6,1]  R1315     -6.0351520776748657e-01
    z[3,6,1]  R1316     1.4922253787517548e-01
    z[3,6,1]  R1317     5.9933638572692871e-01
    z[3,6,1]  R1318     4.6213066577911377e-01
    z[3,6,1]  R1319     0.813393771648407
    z[3,6,1]  R1320     4.7956377267837524e-01
    z[3,6,1]  R1321     6.3635557889938354e-01
    z[3,6,1]  R1322     -3.5282588005065918e-01
    z[3,6,1]  R1323     -5.1891523599624634e-01
    z[3,6,1]  R1324     -7.3771619796752930e-01
    z[3,6,1]  R1325     -6.7508661746978760e-01
    z[3,6,1]  R1326     3.8875925540924072e-01
    z[3,6,1]  R1327     5.7495909929275513e-01
    z[3,6,1]  R1328     5.7786947488784790e-01
    z[3,6,1]  R1329     8.9735507965087891e-01
    z[3,6,1]  R1330     4.3170607089996338e-01
    z[3,6,1]  R1331     7.3682177066802979e-01
    z[3,6,1]  R1332     1.6811764240264893e-01
    z[3,6,1]  R1333     -1.8261192739009857e-01
    z[3,6,1]  R1334     1.1428344249725342e-01
    z[3,6,1]  R1335     -2.3681230843067169e-01
    z[3,6,1]  R1336     5.2666431665420532e-01
    z[3,6,1]  R1337     -6.3359868526458740e-01
    z[3,6,1]  R1338     -4.1051259636878967e-01
    z[3,6,1]  R1339     -7.9370737075805664e-01
    z[3,6,1]  R1340     -6.4974778890609741e-01
    z[3,6,1]  R1341     -4.7977665066719055e-01
    z[3,6,1]  R1342     -6.0350996255874634e-01
    z[3,6,1]  R1343     -6.1813724040985107e-01
    z[3,6,1]  R1344     -5.3952005691826344e-03
    z[3,6,1]  R1345     -5.5794250965118408e-01
    z[3,6,1]  R1346     -5.0592315196990967e-01
    z[3,6,1]  R1347     4.3353664875030518e-01
    z[3,6,1]  R1348     -3.8781440258026123e-01
    z[3,6,1]  R1349     -4.0554407238960266e-01
    z[3,6,1]  R1350     -0.0594235435128212
    z[3,6,1]  R1351     1.9486029446125031e-01
    z[3,6,1]  R1352     5.9816908091306686e-02
    z[3,6,1]  R1353     -2.2000917792320251e-01
    z[3,6,1]  R1354     -0.352643221616745
    z[3,6,1]  R1355     -6.9116353988647461e-02
    z[3,6,1]  R1356     -4.0837228298187256e-01
    z[3,6,1]  R1357     -0.362091600894928
    z[3,6,1]  R1358     6.3361212611198425e-02
    z[3,6,1]  R1359     -3.8537091016769409e-01
    z[3,6,1]  R1360     -0.638166606426239
    z[3,6,1]  R1361     -1.2333747744560242e-01
    z[3,6,1]  R1362     -3.1664052605628967e-01
    z[3,6,1]  R1363     3.8286406546831131e-02
    z[3,6,1]  R1364     -3.5802689194679260e-01
    z[3,6,1]  R1365     -2.6379999518394470e-01
    z[3,6,1]  R1366     -2.3484107851982117e-01
    z[3,6,1]  R1367     -9.1423398256301880e-01
    z[3,6,1]  R1368     1.8186372518539429e-01
    z[3,6,1]  R1369     8.9892917871475220e-01
    z[3,6,1]  R1370     -0.643058717250824
    z[3,6,1]  R1371     8.7337815761566162e-01
    z[3,6,2]  R31       -1
    z[3,6,2]  R58       1
    z[3,6,2]  R1272     -1
    z[3,6,2]  R1273     1
    z[3,6,2]  R1282     1.5335462987422943e-01
    z[3,6,2]  R1283     -6.0049909353256226e-01
    z[3,6,2]  R1284     5.4962551593780518e-01
    z[3,6,2]  R1285     -3.2779499888420105e-01
    z[3,6,2]  R1286     -3.8564798235893250e-01
    z[3,6,2]  R1287     -4.9620741046965122e-03
    z[3,6,2]  R1288     -4.8943346738815308e-01
    z[3,6,2]  R1289     1.8296520411968231e-01
    z[3,6,2]  R1290     -4.2893221974372864e-01
    z[3,6,2]  R1291     -2.5571811944246292e-02
    z[3,6,2]  R1292     3.3236268162727356e-01
    z[3,6,2]  R1293     4.7776794433593750e-01
    z[3,6,2]  R1294     5.4234284162521362e-01
    z[3,6,2]  R1295     3.3731272816658020e-01
    z[3,6,2]  R1296     6.2042981386184692e-01
    z[3,6,2]  R1297     -4.3763765692710876e-01
    z[3,6,2]  R1298     2.6428681612014771e-01
    z[3,6,2]  R1299     1.4328658580780029e-03
    z[3,6,2]  R1300     3.2177260518074036e-01
    z[3,6,2]  R1301     1.7702539265155792e-01
    z[3,6,2]  R1302     -7.1257036924362183e-01
    z[3,6,2]  R1303     -5.8643120527267456e-01
    z[3,6,2]  R1304     -1.3432666659355164e-01
    z[3,6,2]  R1305     4.8286509513854980e-01
    z[3,6,2]  R1306     -4.7755271196365356e-01
    z[3,6,2]  R1307     -2.8411459922790527e-01
    z[3,6,2]  R1308     -1.3416558504104614e-01
    z[3,6,2]  R1309     7.0129656791687012e-01
    z[3,6,2]  R1310     -3.3579519391059875e-01
    z[3,6,2]  R1311     1.0880029201507568e-01
    z[3,6,2]  R1312     -0.604345440864563
    z[3,6,2]  R1313     -2.9558802023530006e-02
    z[3,6,2]  R1314     1.1722157150506973e-01
    z[3,6,2]  R1315     3.9034938812255859e-01
    z[3,6,2]  R1316     4.1221952438354492e-01
    z[3,6,2]  R1317     -1.5346366167068481e-01
    z[3,6,2]  R1318     -6.5238827466964722e-01
    z[3,6,2]  R1319     -4.8277732729911804e-01
    z[3,6,2]  R1320     6.8101976066827774e-03
    z[3,6,2]  R1321     -5.9404021501541138e-01
    z[3,6,2]  R1322     -3.6452940106391907e-01
    z[3,6,2]  R1323     -2.5705328583717346e-01
    z[3,6,2]  R1324     -5.0469189882278442e-03
    z[3,6,2]  R1325     1.0578592121601105e-01
    z[3,6,2]  R1326     6.2631016969680786e-01
    z[3,6,2]  R1327     -2.6241201162338257e-01
    z[3,6,2]  R1328     -9.8471298813819885e-02
    z[3,6,2]  R1329     -3.2202121615409851e-01
    z[3,6,2]  R1330     -2.2024551033973694e-01
    z[3,6,2]  R1331     -3.5296049714088440e-01
    z[3,6,2]  R1332     -1.1657848954200745e-01
    z[3,6,2]  R1333     -0.27797931432724
    z[3,6,2]  R1334     -2.8962761163711548e-01
    z[3,6,2]  R1335     9.1380268335342407e-02
    z[3,6,2]  R1336     1.9642254710197449e-01
    z[3,6,2]  R1337     -3.4210613369941711e-01
    z[3,6,2]  R1338     1.8819691240787506e-01
    z[3,6,2]  R1339     -3.0000713467597961e-01
    z[3,6,2]  R1340     -9.1953672468662262e-02
    z[3,6,2]  R1341     -1.1292373389005661e-01
    z[3,6,2]  R1342     -1.0943014174699783e-01
    z[3,6,2]  R1343     -0.0857386440038681
    z[3,6,2]  R1344     -3.6604857444763184e-01
    z[3,6,2]  R1345     -2.0322367548942566e-01
    z[3,6,2]  R1346     2.7266851067543030e-01
    z[3,6,2]  R1347     1.0813126713037491e-01
    z[3,6,2]  R1348     1.0796468704938889e-01
    z[3,6,2]  R1349     7.8948169946670532e-01
    z[3,6,2]  R1350     2.6973477005958557e-01
    z[3,6,2]  R1351     4.8148965835571289e-01
    z[3,6,2]  R1352     0.413653701543808
    z[3,6,2]  R1353     0.342832088470459
    z[3,6,2]  R1354     -2.6855310425162315e-02
    z[3,6,2]  R1355     -0.0953153595328331
    z[3,6,2]  R1356     4.4445610046386719e-01
    z[3,6,2]  R1357     3.8897311687469482e-01
    z[3,6,2]  R1358     -1.4220274984836578e-01
    z[3,6,2]  R1359     0.567274808883667
    z[3,6,2]  R1360     6.6093361377716064e-01
    z[3,6,2]  R1361     4.6385416388511658e-01
    z[3,6,2]  R1362     4.8049096018075943e-02
    z[3,6,2]  R1363     1.9378603994846344e-01
    z[3,6,2]  R1364     7.5120642781257629e-02
    z[3,6,2]  R1365     -2.4247172474861145e-01
    z[3,6,2]  R1366     -4.8259615898132324e-01
    z[3,6,2]  R1367     3.5424941778182983e-01
    z[3,6,2]  R1368     -1.0859417915344238e-01
    z[3,6,2]  R1369     9.9274478852748871e-02
    z[3,6,2]  R1370     5.9204649925231934e-01
    z[3,6,2]  R1371     -5.3504716604948044e-02
    z[3,6,3]  R32       -1
    z[3,6,3]  R59       1
    z[3,6,3]  R1274     -1
    z[3,6,3]  R1275     1
    z[3,6,3]  R1282     1.3980150222778320e-01
    z[3,6,3]  R1283     -4.8543652892112732e-01
    z[3,6,3]  R1284     0.349149614572525
    z[3,6,3]  R1285     -7.0498067140579224e-01
    z[3,6,3]  R1286     -6.4381921291351318e-01
    z[3,6,3]  R1287     2.5701728463172913e-01
    z[3,6,3]  R1288     -5.4006010293960571e-01
    z[3,6,3]  R1289     -0.0647614598274231
    z[3,6,3]  R1290     -1.8884766101837158e-01
    z[3,6,3]  R1291     -4.9562579393386841e-01
    z[3,6,3]  R1292     -7.6045602560043335e-01
    z[3,6,3]  R1293     -6.8463677167892456e-01
    z[3,6,3]  R1294     -3.7467747926712036e-01
    z[3,6,3]  R1295     -7.0945578813552856e-01
    z[3,6,3]  R1296     -4.7919160127639771e-01
    z[3,6,3]  R1297     -6.2790863215923309e-02
    z[3,6,3]  R1298     -5.4137378931045532e-01
    z[3,6,3]  R1299     -6.1908680200576782e-01
    z[3,6,3]  R1300     -5.0925046205520630e-01
    z[3,6,3]  R1301     -5.1862555742263794e-01
    z[3,6,3]  R1302     0.0450817309319973
    z[3,6,3]  R1303     -6.1120027303695679e-01
    z[3,6,3]  R1304     1.4381159842014313e-01
    z[3,6,3]  R1305     -4.9036917090415955e-01
    z[3,6,3]  R1306     -3.7112716585397720e-02
    z[3,6,3]  R1307     1.6053833067417145e-01
    z[3,6,3]  R1308     -2.5952902436256409e-01
    z[3,6,3]  R1309     -1.0738559067249298e-03
    z[3,6,3]  R1310     3.0714073777198792e-01
    z[3,6,3]  R1311     8.6557984352111816e-01
    z[3,6,3]  R1312     -4.5465391874313354e-01
    z[3,6,3]  R1313     -4.8944808542728424e-02
    z[3,6,3]  R1314     3.8044983148574829e-01
    z[3,6,3]  R1315     -2.1053658425807953e-01
    z[3,6,3]  R1316     8.1655263900756836e-01
    z[3,6,3]  R1317     -5.5685347318649292e-01
    z[3,6,3]  R1318     3.0859303474426270e-01
    z[3,6,3]  R1319     -6.4833253622055054e-02
    z[3,6,3]  R1320     6.2604665756225586e-01
    z[3,6,3]  R1321     1.9388185441493988e-01
    z[3,6,3]  R1322     -3.7968146800994873e-01
    z[3,6,3]  R1323     7.0764243602752686e-01
    z[3,6,3]  R1324     -2.8273233771324158e-01
    z[3,6,3]  R1325     7.9361535608768463e-02
    z[3,6,3]  R1326     -4.0932792425155640e-01
    z[3,6,3]  R1327     -6.0328519344329834e-01
    z[3,6,3]  R1328     7.1337640285491943e-01
    z[3,6,3]  R1329     1.6910864412784576e-01
    z[3,6,3]  R1330     6.6688686609268188e-01
    z[3,6,3]  R1331     8.0330856144428253e-02
    z[3,6,3]  R1332     -0.85221928358078
    z[3,6,3]  R1333     -8.1240195035934448e-01
    z[3,6,3]  R1334     -5.2628499269485474e-01
    z[3,6,3]  R1335     -7.5213503837585449e-01
    z[3,6,3]  R1336     -4.3814745545387268e-01
    z[3,6,3]  R1337     1.2706759572029114e-01
    z[3,6,3]  R1338     3.4517151117324829e-01
    z[3,6,3]  R1339     -1.5411342494189739e-02
    z[3,6,3]  R1340     2.3107966780662537e-01
    z[3,6,3]  R1341     -5.8358427137136459e-02
    z[3,6,3]  R1342     4.1151252388954163e-01
    z[3,6,3]  R1343     5.9133970737457275e-01
    z[3,6,3]  R1344     5.1580494642257690e-01
    z[3,6,3]  R1345     7.1391516923904419e-01
    z[3,6,3]  R1346     3.2900074124336243e-01
    z[3,6,3]  R1347     6.9959261454641819e-03
    z[3,6,3]  R1348     3.8137266039848328e-01
    z[3,6,3]  R1349     0.338481068611145
    z[3,6,3]  R1350     2.3638258874416351e-01
    z[3,6,3]  R1351     -0.462100625038147
    z[3,6,3]  R1352     4.8471182584762573e-01
    z[3,6,3]  R1353     4.3285819888114929e-01
    z[3,6,3]  R1354     4.2439797520637512e-01
    z[3,6,3]  R1355     4.8455065488815308e-01
    z[3,6,3]  R1356     4.9847099184989929e-01
    z[3,6,3]  R1357     3.9329320192337036e-01
    z[3,6,3]  R1358     4.8132848739624023e-01
    z[3,6,3]  R1359     5.7116001844406128e-01
    z[3,6,3]  R1360     8.5973121225833893e-02
    z[3,6,3]  R1361     0.566581130027771
    z[3,6,3]  R1362     0.543865442276001
    z[3,6,3]  R1363     4.8258337378501892e-01
    z[3,6,3]  R1364     4.3860536813735962e-01
    z[3,6,3]  R1365     7.4338442087173462e-01
    z[3,6,3]  R1366     7.0555222034454346e-01
    z[3,6,3]  R1367     1.0699941217899323e-01
    z[3,6,3]  R1368     4.6006390452384949e-01
    z[3,6,3]  R1369     2.5437566637992859e-01
    z[3,6,3]  R1370     3.3498144149780273e-01
    z[3,6,3]  R1371     1.4639307558536530e-01
    z[3,6,4]  R33       -1
    z[3,6,4]  R60       1
    z[3,6,4]  R1276     -1
    z[3,6,4]  R1277     1
    z[3,6,4]  R1282     -4.8401427268981934e-01
    z[3,6,4]  R1283     4.6343751251697540e-02
    z[3,6,4]  R1284     5.4460112005472183e-02
    z[3,6,4]  R1285     -3.2666212320327759e-01
    z[3,6,4]  R1286     1.3809368014335632e-01
    z[3,6,4]  R1287     6.6078805923461914e-01
    z[3,6,4]  R1288     -3.1959589570760727e-02
    z[3,6,4]  R1289     4.6754062175750732e-01
    z[3,6,4]  R1290     -3.1381070613861084e-01
    z[3,6,4]  R1291     -6.2581133842468262e-01
    z[3,6,4]  R1292     -1.9610758870840073e-02
    z[3,6,4]  R1293     -4.9195587635040283e-02
    z[3,6,4]  R1294     2.2888121008872986e-01
    z[3,6,4]  R1295     1.2012667208909988e-01
    z[3,6,4]  R1296     -3.0425125360488892e-01
    z[3,6,4]  R1297     -7.9097676277160645e-01
    z[3,6,4]  R1298     2.3311580717563629e-01
    z[3,6,4]  R1299     -1.8523296713829041e-01
    z[3,6,4]  R1300     2.3390786349773407e-01
    z[3,6,4]  R1301     5.2037900686264038e-01
    z[3,6,4]  R1302     -2.6308125257492065e-01
    z[3,6,4]  R1303     4.4833451509475708e-01
    z[3,6,4]  R1304     -2.2582834959030151e-01
    z[3,6,4]  R1305     4.2494514584541321e-01
    z[3,6,4]  R1306     2.3748284205794334e-02
    z[3,6,4]  R1307     -5.7107824832201004e-02
    z[3,6,4]  R1308     1.9484585523605347e-01
    z[3,6,4]  R1309     4.0376982651650906e-03
    z[3,6,4]  R1310     1.2568618357181549e-01
    z[3,6,4]  R1311     -3.9516729116439819e-01
    z[3,6,4]  R1312     -4.3289104104042053e-01
    z[3,6,4]  R1313     1.7633788287639618e-01
    z[3,6,4]  R1314     -3.3293321728706360e-02
    z[3,6,4]  R1315     3.1441393494606018e-01
    z[3,6,4]  R1316     2.5045558810234070e-01
    z[3,6,4]  R1317     1.5220838785171509e-01
    z[3,6,4]  R1318     3.3705178648233414e-02
    z[3,6,4]  R1319     -8.6671836674213409e-02
    z[3,6,4]  R1320     5.3131759166717529e-01
    z[3,6,4]  R1321     -2.8040159493684769e-02
    z[3,6,4]  R1322     -1.8048363924026489e-01
    z[3,6,4]  R1323     2.8188863396644592e-01
    z[3,6,4]  R1324     -0.0724576786160469
    z[3,6,4]  R1325     2.1844211220741272e-01
    z[3,6,4]  R1326     -1.2153670191764832e-01
    z[3,6,4]  R1327     -1.3801916502416134e-02
    z[3,6,4]  R1328     2.5893816351890564e-01
    z[3,6,4]  R1329     4.8382304608821869e-02
    z[3,6,4]  R1330     -2.3363950848579407e-01
    z[3,6,4]  R1331     -4.4344505667686462e-01
    z[3,6,4]  R1332     2.0948500931262970e-01
    z[3,6,4]  R1333     -3.1193265318870544e-01
    z[3,6,4]  R1334     -1.3032099604606628e-01
    z[3,6,4]  R1335     -4.3716788291931152e-02
    z[3,6,4]  R1336     -2.6139837503433228e-01
    z[3,6,4]  R1337     -1.1416272819042206e-01
    z[3,6,4]  R1338     4.3638557195663452e-01
    z[3,6,4]  R1339     -2.4576272070407867e-01
    z[3,6,4]  R1340     -5.5505480617284775e-02
    z[3,6,4]  R1341     2.8016555309295654e-01
    z[3,6,4]  R1342     5.6557816267013550e-01
    z[3,6,4]  R1343     -3.4651103615760803e-01
    z[3,6,4]  R1344     -3.6873687058687210e-02
    z[3,6,4]  R1345     -1.4194028079509735e-01
    z[3,6,4]  R1346     -2.9900604486465454e-01
    z[3,6,4]  R1347     0.667676568031311
    z[3,6,4]  R1348     1.8114092946052551e-01
    z[3,6,4]  R1349     -4.0168181061744690e-02
    z[3,6,4]  R1350     2.1784137934446335e-02
    z[3,6,4]  R1351     -4.7689802944660187e-02
    z[3,6,4]  R1352     1.3894718885421753e-01
    z[3,6,4]  R1353     2.0598727464675903e-01
    z[3,6,4]  R1354     3.7436592578887939e-01
    z[3,6,4]  R1355     -1.3234195113182068e-01
    z[3,6,4]  R1356     -1.9997909665107727e-01
    z[3,6,4]  R1357     2.9672408103942871e-01
    z[3,6,4]  R1358     -3.4363400936126709e-01
    z[3,6,4]  R1359     -1.0641941428184509e-01
    z[3,6,4]  R1360     -0.382472962141037
    z[3,6,4]  R1361     -4.4036373496055603e-01
    z[3,6,4]  R1362     1.1417217552661896e-01
    z[3,6,4]  R1363     1.5343791246414185e-01
    z[3,6,4]  R1364     3.6165687441825867e-01
    z[3,6,4]  R1365     -4.7659203410148621e-01
    z[3,6,4]  R1366     -0.0654422715306282
    z[3,6,4]  R1367     4.0773589164018631e-02
    z[3,6,4]  R1368     3.0711600184440613e-01
    z[3,6,4]  R1369     9.1799207031726837e-02
    z[3,6,4]  R1370     9.9960751831531525e-02
    z[3,6,4]  R1371     3.4307071566581726e-01
    z[3,6,5]  R34       -1
    z[3,6,5]  R61       1
    z[3,6,5]  R1278     -1
    z[3,6,5]  R1279     1
    z[3,6,5]  R1282     -3.7373277544975281e-01
    z[3,6,5]  R1283     -2.8061193227767944e-01
    z[3,6,5]  R1284     -2.6671119034290314e-02
    z[3,6,5]  R1285     -1.1959427595138550e-01
    z[3,6,5]  R1286     -3.1937101483345032e-01
    z[3,6,5]  R1287     -3.6324670910835266e-01
    z[3,6,5]  R1288     -8.2112692296504974e-02
    z[3,6,5]  R1289     -6.9876688718795776e-01
    z[3,6,5]  R1290     -0.394333153963089
    z[3,6,5]  R1291     -4.3859738111495972e-01
    z[3,6,5]  R1292     3.3692322671413422e-02
    z[3,6,5]  R1293     -1.6348755359649658e-01
    z[3,6,5]  R1294     -2.0855288952589035e-02
    z[3,6,5]  R1295     2.0821157097816467e-01
    z[3,6,5]  R1296     -0.0433766171336174
    z[3,6,5]  R1297     -5.6146692484617233e-02
    z[3,6,5]  R1298     2.7365830540657043e-01
    z[3,6,5]  R1299     2.2968876361846924e-01
    z[3,6,5]  R1300     4.4170853495597839e-01
    z[3,6,5]  R1301     3.6483103036880493e-01
    z[3,6,5]  R1302     -4.5089519023895264e-01
    z[3,6,5]  R1303     -2.5357827544212341e-02
    z[3,6,5]  R1304     1.5495795011520386e-01
    z[3,6,5]  R1305     8.0810030922293663e-03
    z[3,6,5]  R1306     0.0723768025636673
    z[3,6,5]  R1307     5.9614843130111694e-01
    z[3,6,5]  R1308     5.4889399558305740e-02
    z[3,6,5]  R1309     -0.197321817278862
    z[3,6,5]  R1310     2.7102181687951088e-02
    z[3,6,5]  R1311     2.8337183594703674e-01
    z[3,6,5]  R1312     0.256511926651001
    z[3,6,5]  R1313     -6.9606119394302368e-01
    z[3,6,5]  R1314     3.4793254733085632e-01
    z[3,6,5]  R1315     4.8544409871101379e-01
    z[3,6,5]  R1316     -6.2928862869739532e-02
    z[3,6,5]  R1317     4.3521293997764587e-01
    z[3,6,5]  R1318     -2.1326787769794464e-02
    z[3,6,5]  R1319     1.4439002610743046e-02
    z[3,6,5]  R1320     2.5736328959465027e-01
    z[3,6,5]  R1321     -3.0850782990455627e-02
    z[3,6,5]  R1322     -7.2390139102935791e-01
    z[3,6,5]  R1323     2.4870058894157410e-01
    z[3,6,5]  R1324     5.1580244302749634e-01
    z[3,6,5]  R1325     0.545786440372467
    z[3,6,5]  R1326     -3.3381292223930359e-01
    z[3,6,5]  R1327     2.2834406793117523e-01
    z[3,6,5]  R1328     1.4479791745543480e-02
    z[3,6,5]  R1329     1.4484675228595734e-01
    z[3,6,5]  R1330     5.0283408164978027e-01
    z[3,6,5]  R1331     1.9192793965339661e-01
    z[3,6,5]  R1332     -4.1011118888854980e-01
    z[3,6,5]  R1333     -3.5467270016670227e-01
    z[3,6,5]  R1334     -6.7898106575012207e-01
    z[3,6,5]  R1335     -3.8434910774230957e-01
    z[3,6,5]  R1336     -6.0099124908447266e-01
    z[3,6,5]  R1337     8.2026623189449310e-02
    z[3,6,5]  R1338     -2.9660975933074951e-01
    z[3,6,5]  R1339     4.6530964970588684e-01
    z[3,6,5]  R1340     5.5250751972198486e-01
    z[3,6,5]  R1341     4.3743756413459778e-01
    z[3,6,5]  R1342     -3.0136564373970032e-01
    z[3,6,5]  R1343     3.5118868947029114e-01
    z[3,6,5]  R1344     7.3869693279266357e-01
    z[3,6,5]  R1345     -2.6882886886596680e-01
    z[3,6,5]  R1346     -4.3684488534927368e-01
    z[3,6,5]  R1347     3.1190750002861023e-01
    z[3,6,5]  R1348     5.0793045759201050e-01
    z[3,6,5]  R1349     4.7194175422191620e-02
    z[3,6,5]  R1350     8.8561016321182251e-01
    z[3,6,5]  R1351     7.0759785175323486e-01
    z[3,6,5]  R1352     7.4784934520721436e-01
    z[3,6,5]  R1353     7.0382225513458252e-01
    z[3,6,5]  R1354     7.0949828624725342e-01
    z[3,6,5]  R1355     7.6195400953292847e-01
    z[3,6,5]  R1356     5.8875405788421631e-01
    z[3,6,5]  R1357     6.5910464525222778e-01
    z[3,6,5]  R1358     7.7146822214126587e-01
    z[3,6,5]  R1359     2.8881141543388367e-01
    z[3,6,5]  R1360     -3.2654516398906708e-02
    z[3,6,5]  R1361     4.1194760799407959e-01
    z[3,6,5]  R1362     7.1507257223129272e-01
    z[3,6,5]  R1363     8.2039844989776611e-01
    z[3,6,5]  R1364     6.3013392686843872e-01
    z[3,6,5]  R1365     1.5305669605731964e-01
    z[3,6,5]  R1366     3.7789145112037659e-01
    z[3,6,5]  R1367     -4.2847845703363419e-02
    z[3,6,5]  R1368     4.6800276637077332e-01
    z[3,6,5]  R1369     3.1855154037475586e-01
    z[3,6,5]  R1370     1.1651323735713959e-01
    z[3,6,5]  R1371     3.0713552236557007e-01
    z[3,6,6]  R35       -1
    z[3,6,6]  R62       1
    z[3,6,6]  R1280     -1
    z[3,6,6]  R1281     1
    z[3,6,6]  R1282     -4.3678706884384155e-01
    z[3,6,6]  R1283     -4.6456691622734070e-01
    z[3,6,6]  R1284     -4.9688091874122620e-01
    z[3,6,6]  R1285     -2.5510832667350769e-01
    z[3,6,6]  R1286     -2.6143577694892883e-01
    z[3,6,6]  R1287     3.9746630191802979e-01
    z[3,6,6]  R1288     6.3786321878433228e-01
    z[3,6,6]  R1289     3.4531423449516296e-01
    z[3,6,6]  R1290     0.658897340297699
    z[3,6,6]  R1291     -3.0043545365333557e-01
    z[3,6,6]  R1292     4.7700032591819763e-02
    z[3,6,6]  R1293     1.6875910758972168e-01
    z[3,6,6]  R1294     3.4356853365898132e-01
    z[3,6,6]  R1295     -3.2359704375267029e-01
    z[3,6,6]  R1296     2.1930399537086487e-01
    z[3,6,6]  R1297     -4.2879793792963028e-02
    z[3,6,6]  R1298     2.2674646973609924e-01
    z[3,6,6]  R1299     3.6886653304100037e-01
    z[3,6,6]  R1300     1.3063828647136688e-01
    z[3,6,6]  R1301     8.7904646992683411e-02
    z[3,6,6]  R1302     -2.1914835274219513e-01
    z[3,6,6]  R1303     -4.5325968414545059e-02
    z[3,6,6]  R1304     4.7167718410491943e-01
    z[3,6,6]  R1305     2.3300263285636902e-01
    z[3,6,6]  R1306     -1.8468016386032104e-01
    z[3,6,6]  R1307     1.2350400909781456e-02
    z[3,6,6]  R1308     -1.1037850379943848e-01
    z[3,6,6]  R1309     -1.6299147903919220e-01
    z[3,6,6]  R1310     -2.8236522339284420e-03
    z[3,6,6]  R1311     3.1427938491106033e-02
    z[3,6,6]  R1312     2.0696519315242767e-01
    z[3,6,6]  R1313     -3.7461996078491211e-01
    z[3,6,6]  R1314     0.565693199634552
    z[3,6,6]  R1315     9.2446379363536835e-02
    z[3,6,6]  R1316     2.3793274164199829e-01
    z[3,6,6]  R1317     1.2363357841968536e-01
    z[3,6,6]  R1318     -7.3006264865398407e-02
    z[3,6,6]  R1319     6.8720698356628418e-02
    z[3,6,6]  R1320     1.3928471505641937e-01
    z[3,6,6]  R1321     0.0840034931898117
    z[3,6,6]  R1322     4.4490348547697067e-02
    z[3,6,6]  R1323     4.0182426571846008e-02
    z[3,6,6]  R1324     -7.1369171142578125e-02
    z[3,6,6]  R1325     -1.2926366925239563e-01
    z[3,6,6]  R1326     -2.9037842154502869e-01
    z[3,6,6]  R1327     4.1457340121269226e-01
    z[3,6,6]  R1328     2.4589551985263824e-01
    z[3,6,6]  R1329     -1.1040373146533966e-01
    z[3,6,6]  R1330     -1.0975638777017593e-01
    z[3,6,6]  R1331     -2.2316549718379974e-01
    z[3,6,6]  R1332     1.4036749303340912e-01
    z[3,6,6]  R1333     -3.1022084876894951e-02
    z[3,6,6]  R1334     -3.5945597290992737e-01
    z[3,6,6]  R1335     -3.4882813692092896e-01
    z[3,6,6]  R1336     0.0961492657661438
    z[3,6,6]  R1337     5.1711469888687134e-01
    z[3,6,6]  R1338     -6.0955983400344849e-01
    z[3,6,6]  R1339     -4.3923977762460709e-02
    z[3,6,6]  R1340     4.0581443905830383e-01
    z[3,6,6]  R1341     -5.3546506166458130e-01
    z[3,6,6]  R1342     1.2044569849967957e-01
    z[3,6,6]  R1343     -1.3086408376693726e-01
    z[3,6,6]  R1344     -2.1284069120883942e-01
    z[3,6,6]  R1345     -2.0879344642162323e-01
    z[3,6,6]  R1346     0.389967143535614
    z[3,6,6]  R1347     -2.4880394339561462e-01
    z[3,6,6]  R1348     1.0923012346029282e-01
    z[3,6,6]  R1349     2.9357701539993286e-01
    z[3,6,6]  R1350     -1.3189360499382019e-01
    z[3,6,6]  R1351     -4.1599976248107851e-04
    z[3,6,6]  R1352     9.6221163868904114e-02
    z[3,6,6]  R1353     -1.5994152426719666e-01
    z[3,6,6]  R1354     -6.3475859351456165e-03
    z[3,6,6]  R1355     -3.4419447183609009e-01
    z[3,6,6]  R1356     2.2703444585204124e-02
    z[3,6,6]  R1357     1.1628524214029312e-01
    z[3,6,6]  R1358     9.9947135895490646e-03
    z[3,6,6]  R1359     2.9199233651161194e-01
    z[3,6,6]  R1360     2.8093319386243820e-02
    z[3,6,6]  R1361     1.5568609535694122e-01
    z[3,6,6]  R1362     -1.7072907090187073e-01
    z[3,6,6]  R1363     1.7637057602405548e-01
    z[3,6,6]  R1364     3.7995925545692444e-01
    z[3,6,6]  R1365     -2.4157127737998962e-01
    z[3,6,6]  R1366     -2.4933594465255737e-01
    z[3,6,6]  R1367     1.1855491995811462e-01
    z[3,6,6]  R1368     5.7565051317214966e-01
    z[3,6,6]  R1369     -8.5030794143676758e-02
    z[3,6,6]  R1370     -1.3771559298038483e-01
    z[3,6,6]  R1371     -8.6030957754701376e-04
    z[6,3,0]  R29       1
    z[6,3,0]  R56       -1
    z[6,3,0]  R1372     -1
    z[6,3,0]  R1373     1
    z[6,3,0]  R1386     0.00948364194482565
    z[6,3,0]  R1387     -7.2981618344783783e-02
    z[6,3,0]  R1388     1.3737419247627258e-01
    z[6,3,0]  R1389     3.1392046809196472e-01
    z[6,3,0]  R1390     -2.3087984323501587e-01
    z[6,3,0]  R1391     -4.2213848233222961e-01
    z[6,3,0]  R1392     1.6414934396743774e-01
    z[6,3,0]  R1393     3.0744003131985664e-02
    z[6,3,0]  R1394     -2.0722879469394684e-01
    z[6,3,0]  R1395     -4.4394785165786743e-01
    z[6,3,0]  R1396     1.7102941870689392e-01
    z[6,3,0]  R1397     -1.8538489937782288e-02
    z[6,3,0]  R1398     8.7123408913612366e-02
    z[6,3,0]  R1399     4.1409574449062347e-02
    z[6,3,0]  R1400     -3.5936015844345093e-01
    z[6,3,0]  R1401     4.4195351004600525e-01
    z[6,3,0]  R1402     6.2430912256240845e-01
    z[6,3,0]  R1403     -8.7492220103740692e-02
    z[6,3,0]  R1404     2.5624117255210876e-01
    z[6,3,0]  R1405     1.1700862646102905e-01
    z[6,3,0]  R1406     5.0234988331794739e-02
    z[6,3,0]  R1407     2.8864863514900208e-01
    z[6,3,0]  R1408     2.2634042799472809e-01
    z[6,3,0]  R1409     1.8652193248271942e-01
    z[6,3,0]  R1410     8.8945478200912476e-03
    z[6,3,0]  R1411     1.6408419609069824e-01
    z[6,3,0]  R1412     -1.7532561719417572e-01
    z[6,3,0]  R1413     -1.5319344401359558e-01
    z[6,3,0]  R1414     -1.9433531910181046e-02
    z[6,3,0]  R1415     -2.4648292362689972e-01
    z[6,3,0]  R1416     2.1938095986843109e-01
    z[6,3,0]  R1417     -1.9774494692683220e-02
    z[6,3,0]  R1418     -3.9564505219459534e-02
    z[6,3,0]  R1419     -1.0036766529083252e-01
    z[6,3,0]  R1420     6.9954305887222290e-02
    z[6,3,0]  R1421     9.8391972482204437e-02
    z[6,3,0]  R1422     -3.1425106525421143e-01
    z[6,3,0]  R1423     -1.5212918631732464e-02
    z[6,3,0]  R1424     2.8497523069381714e-01
    z[6,3,0]  R1425     2.9772745445370674e-02
    z[6,3,0]  R1426     -3.4679239988327026e-01
    z[6,3,0]  R1427     3.1635525822639465e-01
    z[6,3,0]  R1428     2.4061417579650879e-01
    z[6,3,0]  R1429     1.3621720671653748e-01
    z[6,3,0]  R1430     1.2337982654571533e-01
    z[6,3,0]  R1431     -1.5169952809810638e-01
    z[6,3,0]  R1432     2.2870300710201263e-01
    z[6,3,0]  R1433     -1.9770224392414093e-01
    z[6,3,0]  R1434     2.8880143165588379e-01
    z[6,3,0]  R1435     -1.5453328192234039e-01
    z[6,3,0]  R1436     3.8862389326095581e-01
    z[6,3,0]  R1437     3.7091308832168579e-01
    z[6,3,0]  R1438     0.478127658367157
    z[6,3,0]  R1439     4.6311464905738831e-01
    z[6,3,0]  R1440     4.7244840860366821e-01
    z[6,3,0]  R1441     -3.2537445425987244e-01
    z[6,3,0]  R1442     4.7602352499961853e-01
    z[6,3,0]  R1443     2.5705429911613464e-01
    z[6,3,0]  R1444     5.9679847955703735e-01
    z[6,3,0]  R1445     4.8446375131607056e-01
    z[6,3,0]  R1446     -1.4129619300365448e-01
    z[6,3,0]  R1447     -2.4598467350006104e-01
    z[6,3,0]  R1448     -2.2360714152455330e-02
    z[6,3,0]  R1449     4.9472215771675110e-01
    z[6,3,0]  R1450     -2.9698467254638672e-01
    z[6,3,0]  R1451     9.5166578888893127e-02
    z[6,3,0]  R1452     -8.4637673571705818e-03
    z[6,3,0]  R1453     3.5379037261009216e-01
    z[6,3,0]  R1454     -4.9908825755119324e-01
    z[6,3,0]  R1455     2.0909052342176437e-02
    z[6,3,0]  R1456     -1.6441054642200470e-01
    z[6,3,0]  R1457     -4.1640344262123108e-01
    z[6,3,0]  R1458     2.3950491845607758e-01
    z[6,3,0]  R1459     -3.0985912680625916e-01
    z[6,3,0]  R1460     1.3322702050209045e-01
    z[6,3,0]  R1461     2.8159549832344055e-01
    z[6,3,0]  R1462     -5.0860035419464111e-01
    z[6,3,0]  R1463     -2.9777538776397705e-01
    z[6,3,0]  R1464     1.0051559656858444e-01
    z[6,3,0]  R1465     -4.4247376918792725e-01
    z[6,3,0]  R1466     -1.9971807301044464e-01
    z[6,3,0]  R1467     -1.4479297399520874e-01
    z[6,3,0]  R1468     3.1530305743217468e-01
    z[6,3,0]  R1469     -4.0553700923919678e-01
    z[6,3,0]  R1470     2.8023305535316467e-01
    z[6,3,0]  R1471     1.1138470470905304e-01
    z[6,3,0]  R1472     -1.4050295948982239e-01
    z[6,3,0]  R1473     -1.6415895521640778e-01
    z[6,3,0]  R1474     -3.0126294121146202e-02
    z[6,3,0]  R1475     -2.0682542026042938e-01
    z[6,3,1]  R30       1
    z[6,3,1]  R57       -1
    z[6,3,1]  R1374     -1
    z[6,3,1]  R1375     1
    z[6,3,1]  R1386     1.6811764240264893e-01
    z[6,3,1]  R1387     -1.8261192739009857e-01
    z[6,3,1]  R1388     1.1428344249725342e-01
    z[6,3,1]  R1389     -2.3681230843067169e-01
    z[6,3,1]  R1390     5.2666431665420532e-01
    z[6,3,1]  R1391     -6.3359868526458740e-01
    z[6,3,1]  R1392     -4.1051259636878967e-01
    z[6,3,1]  R1393     -7.9370737075805664e-01
    z[6,3,1]  R1394     -6.4974778890609741e-01
    z[6,3,1]  R1395     -4.7977665066719055e-01
    z[6,3,1]  R1396     -6.0350996255874634e-01
    z[6,3,1]  R1397     -6.1813724040985107e-01
    z[6,3,1]  R1398     -5.3952005691826344e-03
    z[6,3,1]  R1399     -5.5794250965118408e-01
    z[6,3,1]  R1400     -5.0592315196990967e-01
    z[6,3,1]  R1401     4.3353664875030518e-01
    z[6,3,1]  R1402     -3.8781440258026123e-01
    z[6,3,1]  R1403     -4.0554407238960266e-01
    z[6,3,1]  R1404     -0.0594235435128212
    z[6,3,1]  R1405     1.9486029446125031e-01
    z[6,3,1]  R1406     5.9816908091306686e-02
    z[6,3,1]  R1407     -2.2000917792320251e-01
    z[6,3,1]  R1408     -0.352643221616745
    z[6,3,1]  R1409     -6.9116353988647461e-02
    z[6,3,1]  R1410     -4.0837228298187256e-01
    z[6,3,1]  R1411     -0.362091600894928
    z[6,3,1]  R1412     6.3361212611198425e-02
    z[6,3,1]  R1413     -3.8537091016769409e-01
    z[6,3,1]  R1414     -0.638166606426239
    z[6,3,1]  R1415     -1.2333747744560242e-01
    z[6,3,1]  R1416     -3.1664052605628967e-01
    z[6,3,1]  R1417     3.8286406546831131e-02
    z[6,3,1]  R1418     -3.5802689194679260e-01
    z[6,3,1]  R1419     -2.6379999518394470e-01
    z[6,3,1]  R1420     -2.3484107851982117e-01
    z[6,3,1]  R1421     -9.1423398256301880e-01
    z[6,3,1]  R1422     1.8186372518539429e-01
    z[6,3,1]  R1423     8.9892917871475220e-01
    z[6,3,1]  R1424     -0.643058717250824
    z[6,3,1]  R1425     8.7337815761566162e-01
    z[6,3,1]  R1426     -5.2148234844207764e-01
    z[6,3,1]  R1427     8.3416923880577087e-02
    z[6,3,1]  R1428     -5.1724594831466675e-01
    z[6,3,1]  R1429     0.436928391456604
    z[6,3,1]  R1430     0.481802374124527
    z[6,3,1]  R1431     -4.2934402823448181e-01
    z[6,3,1]  R1432     4.3029200285673141e-02
    z[6,3,1]  R1433     -3.1166023015975952e-01
    z[6,3,1]  R1434     -9.3946449458599091e-02
    z[6,3,1]  R1435     2.3569411039352417e-01
    z[6,3,1]  R1436     -3.9549741148948669e-01
    z[6,3,1]  R1437     -3.2833805680274963e-01
    z[6,3,1]  R1438     -4.0744832158088684e-01
    z[6,3,1]  R1439     -7.6940737664699554e-02
    z[6,3,1]  R1440     -1.4032201468944550e-01
    z[6,3,1]  R1441     -2.6081937551498413e-01
    z[6,3,1]  R1442     -4.7939816117286682e-01
    z[6,3,1]  R1443     -5.7229530811309814e-01
    z[6,3,1]  R1444     -1.1862655729055405e-01
    z[6,3,1]  R1445     -2.3100028932094574e-01
    z[6,3,1]  R1446     -3.8691377639770508e-01
    z[6,3,1]  R1447     -1.3536162674427032e-01
    z[6,3,1]  R1448     -8.1442302465438843e-01
    z[6,3,1]  R1449     2.1609127521514893e-01
    z[6,3,1]  R1450     -8.0153423547744751e-01
    z[6,3,1]  R1451     -7.2501242160797119e-01
    z[6,3,1]  R1452     -9.2812252044677734e-01
    z[6,3,1]  R1453     5.6346774101257324e-01
    z[6,3,1]  R1454     0.726138710975647
    z[6,3,1]  R1455     -0.0324397049844265
    z[6,3,1]  R1456     -3.2403391599655151e-01
    z[6,3,1]  R1457     -4.0914842486381531e-01
    z[6,3,1]  R1458     -5.8479070663452148e-01
    z[6,3,1]  R1459     -6.0351520776748657e-01
    z[6,3,1]  R1460     1.4922253787517548e-01
    z[6,3,1]  R1461     5.9933638572692871e-01
    z[6,3,1]  R1462     4.6213066577911377e-01
    z[6,3,1]  R1463     0.813393771648407
    z[6,3,1]  R1464     4.7956377267837524e-01
    z[6,3,1]  R1465     6.3635557889938354e-01
    z[6,3,1]  R1466     -3.5282588005065918e-01
    z[6,3,1]  R1467     -5.1891523599624634e-01
    z[6,3,1]  R1468     -7.3771619796752930e-01
    z[6,3,1]  R1469     -6.7508661746978760e-01
    z[6,3,1]  R1470     3.8875925540924072e-01
    z[6,3,1]  R1471     5.7495909929275513e-01
    z[6,3,1]  R1472     5.7786947488784790e-01
    z[6,3,1]  R1473     8.9735507965087891e-01
    z[6,3,1]  R1474     4.3170607089996338e-01
    z[6,3,1]  R1475     7.3682177066802979e-01
    z[6,3,2]  R31       1
    z[6,3,2]  R58       -1
    z[6,3,2]  R1376     -1
    z[6,3,2]  R1377     1
    z[6,3,2]  R1386     -1.1657848954200745e-01
    z[6,3,2]  R1387     -0.27797931432724
    z[6,3,2]  R1388     -2.8962761163711548e-01
    z[6,3,2]  R1389     9.1380268335342407e-02
    z[6,3,2]  R1390     1.9642254710197449e-01
    z[6,3,2]  R1391     -3.4210613369941711e-01
    z[6,3,2]  R1392     1.8819691240787506e-01
    z[6,3,2]  R1393     -3.0000713467597961e-01
    z[6,3,2]  R1394     -9.1953672468662262e-02
    z[6,3,2]  R1395     -1.1292373389005661e-01
    z[6,3,2]  R1396     -1.0943014174699783e-01
    z[6,3,2]  R1397     -0.0857386440038681
    z[6,3,2]  R1398     -3.6604857444763184e-01
    z[6,3,2]  R1399     -2.0322367548942566e-01
    z[6,3,2]  R1400     2.7266851067543030e-01
    z[6,3,2]  R1401     1.0813126713037491e-01
    z[6,3,2]  R1402     1.0796468704938889e-01
    z[6,3,2]  R1403     7.8948169946670532e-01
    z[6,3,2]  R1404     2.6973477005958557e-01
    z[6,3,2]  R1405     4.8148965835571289e-01
    z[6,3,2]  R1406     0.413653701543808
    z[6,3,2]  R1407     0.342832088470459
    z[6,3,2]  R1408     -2.6855310425162315e-02
    z[6,3,2]  R1409     -0.0953153595328331
    z[6,3,2]  R1410     4.4445610046386719e-01
    z[6,3,2]  R1411     3.8897311687469482e-01
    z[6,3,2]  R1412     -1.4220274984836578e-01
    z[6,3,2]  R1413     0.567274808883667
    z[6,3,2]  R1414     6.6093361377716064e-01
    z[6,3,2]  R1415     4.6385416388511658e-01
    z[6,3,2]  R1416     4.8049096018075943e-02
    z[6,3,2]  R1417     1.9378603994846344e-01
    z[6,3,2]  R1418     7.5120642781257629e-02
    z[6,3,2]  R1419     -2.4247172474861145e-01
    z[6,3,2]  R1420     -4.8259615898132324e-01
    z[6,3,2]  R1421     3.5424941778182983e-01
    z[6,3,2]  R1422     -1.0859417915344238e-01
    z[6,3,2]  R1423     9.9274478852748871e-02
    z[6,3,2]  R1424     5.9204649925231934e-01
    z[6,3,2]  R1425     -5.3504716604948044e-02
    z[6,3,2]  R1426     1.5335462987422943e-01
    z[6,3,2]  R1427     -6.0049909353256226e-01
    z[6,3,2]  R1428     5.4962551593780518e-01
    z[6,3,2]  R1429     -3.2779499888420105e-01
    z[6,3,2]  R1430     -3.8564798235893250e-01
    z[6,3,2]  R1431     -4.9620741046965122e-03
    z[6,3,2]  R1432     -4.8943346738815308e-01
    z[6,3,2]  R1433     1.8296520411968231e-01
    z[6,3,2]  R1434     -4.2893221974372864e-01
    z[6,3,2]  R1435     -2.5571811944246292e-02
    z[6,3,2]  R1436     3.3236268162727356e-01
    z[6,3,2]  R1437     4.7776794433593750e-01
    z[6,3,2]  R1438     5.4234284162521362e-01
    z[6,3,2]  R1439     3.3731272816658020e-01
    z[6,3,2]  R1440     6.2042981386184692e-01
    z[6,3,2]  R1441     -4.3763765692710876e-01
    z[6,3,2]  R1442     2.6428681612014771e-01
    z[6,3,2]  R1443     1.4328658580780029e-03
    z[6,3,2]  R1444     3.2177260518074036e-01
    z[6,3,2]  R1445     1.7702539265155792e-01
    z[6,3,2]  R1446     -7.1257036924362183e-01
    z[6,3,2]  R1447     -5.8643120527267456e-01
    z[6,3,2]  R1448     -1.3432666659355164e-01
    z[6,3,2]  R1449     4.8286509513854980e-01
    z[6,3,2]  R1450     -4.7755271196365356e-01
    z[6,3,2]  R1451     -2.8411459922790527e-01
    z[6,3,2]  R1452     -1.3416558504104614e-01
    z[6,3,2]  R1453     7.0129656791687012e-01
    z[6,3,2]  R1454     -3.3579519391059875e-01
    z[6,3,2]  R1455     1.0880029201507568e-01
    z[6,3,2]  R1456     -0.604345440864563
    z[6,3,2]  R1457     -2.9558802023530006e-02
    z[6,3,2]  R1458     1.1722157150506973e-01
    z[6,3,2]  R1459     3.9034938812255859e-01
    z[6,3,2]  R1460     4.1221952438354492e-01
    z[6,3,2]  R1461     -1.5346366167068481e-01
    z[6,3,2]  R1462     -6.5238827466964722e-01
    z[6,3,2]  R1463     -4.8277732729911804e-01
    z[6,3,2]  R1464     6.8101976066827774e-03
    z[6,3,2]  R1465     -5.9404021501541138e-01
    z[6,3,2]  R1466     -3.6452940106391907e-01
    z[6,3,2]  R1467     -2.5705328583717346e-01
    z[6,3,2]  R1468     -5.0469189882278442e-03
    z[6,3,2]  R1469     1.0578592121601105e-01
    z[6,3,2]  R1470     6.2631016969680786e-01
    z[6,3,2]  R1471     -2.6241201162338257e-01
    z[6,3,2]  R1472     -9.8471298813819885e-02
    z[6,3,2]  R1473     -3.2202121615409851e-01
    z[6,3,2]  R1474     -2.2024551033973694e-01
    z[6,3,2]  R1475     -3.5296049714088440e-01
    z[6,3,3]  R32       1
    z[6,3,3]  R59       -1
    z[6,3,3]  R1378     -1
    z[6,3,3]  R1379     1
    z[6,3,3]  R1386     -0.85221928358078
    z[6,3,3]  R1387     -8.1240195035934448e-01
    z[6,3,3]  R1388     -5.2628499269485474e-01
    z[6,3,3]  R1389     -7.5213503837585449e-01
    z[6,3,3]  R1390     -4.3814745545387268e-01
    z[6,3,3]  R1391     1.2706759572029114e-01
    z[6,3,3]  R1392     3.4517151117324829e-01
    z[6,3,3]  R1393     -1.5411342494189739e-02
    z[6,3,3]  R1394     2.3107966780662537e-01
    z[6,3,3]  R1395     -5.8358427137136459e-02
    z[6,3,3]  R1396     4.1151252388954163e-01
    z[6,3,3]  R1397     5.9133970737457275e-01
    z[6,3,3]  R1398     5.1580494642257690e-01
    z[6,3,3]  R1399     7.1391516923904419e-01
    z[6,3,3]  R1400     3.2900074124336243e-01
    z[6,3,3]  R1401     6.9959261454641819e-03
    z[6,3,3]  R1402     3.8137266039848328e-01
    z[6,3,3]  R1403     0.338481068611145
    z[6,3,3]  R1404     2.3638258874416351e-01
    z[6,3,3]  R1405     -0.462100625038147
    z[6,3,3]  R1406     4.8471182584762573e-01
    z[6,3,3]  R1407     4.3285819888114929e-01
    z[6,3,3]  R1408     4.2439797520637512e-01
    z[6,3,3]  R1409     4.8455065488815308e-01
    z[6,3,3]  R1410     4.9847099184989929e-01
    z[6,3,3]  R1411     3.9329320192337036e-01
    z[6,3,3]  R1412     4.8132848739624023e-01
    z[6,3,3]  R1413     5.7116001844406128e-01
    z[6,3,3]  R1414     8.5973121225833893e-02
    z[6,3,3]  R1415     0.566581130027771
    z[6,3,3]  R1416     0.543865442276001
    z[6,3,3]  R1417     4.8258337378501892e-01
    z[6,3,3]  R1418     4.3860536813735962e-01
    z[6,3,3]  R1419     7.4338442087173462e-01
    z[6,3,3]  R1420     7.0555222034454346e-01
    z[6,3,3]  R1421     1.0699941217899323e-01
    z[6,3,3]  R1422     4.6006390452384949e-01
    z[6,3,3]  R1423     2.5437566637992859e-01
    z[6,3,3]  R1424     3.3498144149780273e-01
    z[6,3,3]  R1425     1.4639307558536530e-01
    z[6,3,3]  R1426     1.3980150222778320e-01
    z[6,3,3]  R1427     -4.8543652892112732e-01
    z[6,3,3]  R1428     0.349149614572525
    z[6,3,3]  R1429     -7.0498067140579224e-01
    z[6,3,3]  R1430     -6.4381921291351318e-01
    z[6,3,3]  R1431     2.5701728463172913e-01
    z[6,3,3]  R1432     -5.4006010293960571e-01
    z[6,3,3]  R1433     -0.0647614598274231
    z[6,3,3]  R1434     -1.8884766101837158e-01
    z[6,3,3]  R1435     -4.9562579393386841e-01
    z[6,3,3]  R1436     -7.6045602560043335e-01
    z[6,3,3]  R1437     -6.8463677167892456e-01
    z[6,3,3]  R1438     -3.7467747926712036e-01
    z[6,3,3]  R1439     -7.0945578813552856e-01
    z[6,3,3]  R1440     -4.7919160127639771e-01
    z[6,3,3]  R1441     -6.2790863215923309e-02
    z[6,3,3]  R1442     -5.4137378931045532e-01
    z[6,3,3]  R1443     -6.1908680200576782e-01
    z[6,3,3]  R1444     -5.0925046205520630e-01
    z[6,3,3]  R1445     -5.1862555742263794e-01
    z[6,3,3]  R1446     0.0450817309319973
    z[6,3,3]  R1447     -6.1120027303695679e-01
    z[6,3,3]  R1448     1.4381159842014313e-01
    z[6,3,3]  R1449     -4.9036917090415955e-01
    z[6,3,3]  R1450     -3.7112716585397720e-02
    z[6,3,3]  R1451     1.6053833067417145e-01
    z[6,3,3]  R1452     -2.5952902436256409e-01
    z[6,3,3]  R1453     -1.0738559067249298e-03
    z[6,3,3]  R1454     3.0714073777198792e-01
    z[6,3,3]  R1455     8.6557984352111816e-01
    z[6,3,3]  R1456     -4.5465391874313354e-01
    z[6,3,3]  R1457     -4.8944808542728424e-02
    z[6,3,3]  R1458     3.8044983148574829e-01
    z[6,3,3]  R1459     -2.1053658425807953e-01
    z[6,3,3]  R1460     8.1655263900756836e-01
    z[6,3,3]  R1461     -5.5685347318649292e-01
    z[6,3,3]  R1462     3.0859303474426270e-01
    z[6,3,3]  R1463     -6.4833253622055054e-02
    z[6,3,3]  R1464     6.2604665756225586e-01
    z[6,3,3]  R1465     1.9388185441493988e-01
    z[6,3,3]  R1466     -3.7968146800994873e-01
    z[6,3,3]  R1467     7.0764243602752686e-01
    z[6,3,3]  R1468     -2.8273233771324158e-01
    z[6,3,3]  R1469     7.9361535608768463e-02
    z[6,3,3]  R1470     -4.0932792425155640e-01
    z[6,3,3]  R1471     -6.0328519344329834e-01
    z[6,3,3]  R1472     7.1337640285491943e-01
    z[6,3,3]  R1473     1.6910864412784576e-01
    z[6,3,3]  R1474     6.6688686609268188e-01
    z[6,3,3]  R1475     8.0330856144428253e-02
    z[6,3,4]  R33       1
    z[6,3,4]  R60       -1
    z[6,3,4]  R1380     -1
    z[6,3,4]  R1381     1
    z[6,3,4]  R1386     2.0948500931262970e-01
    z[6,3,4]  R1387     -3.1193265318870544e-01
    z[6,3,4]  R1388     -1.3032099604606628e-01
    z[6,3,4]  R1389     -4.3716788291931152e-02
    z[6,3,4]  R1390     -2.6139837503433228e-01
    z[6,3,4]  R1391     -1.1416272819042206e-01
    z[6,3,4]  R1392     4.3638557195663452e-01
    z[6,3,4]  R1393     -2.4576272070407867e-01
    z[6,3,4]  R1394     -5.5505480617284775e-02
    z[6,3,4]  R1395     2.8016555309295654e-01
    z[6,3,4]  R1396     5.6557816267013550e-01
    z[6,3,4]  R1397     -3.4651103615760803e-01
    z[6,3,4]  R1398     -3.6873687058687210e-02
    z[6,3,4]  R1399     -1.4194028079509735e-01
    z[6,3,4]  R1400     -2.9900604486465454e-01
    z[6,3,4]  R1401     0.667676568031311
    z[6,3,4]  R1402     1.8114092946052551e-01
    z[6,3,4]  R1403     -4.0168181061744690e-02
    z[6,3,4]  R1404     2.1784137934446335e-02
    z[6,3,4]  R1405     -4.7689802944660187e-02
    z[6,3,4]  R1406     1.3894718885421753e-01
    z[6,3,4]  R1407     2.0598727464675903e-01
    z[6,3,4]  R1408     3.7436592578887939e-01
    z[6,3,4]  R1409     -1.3234195113182068e-01
    z[6,3,4]  R1410     -1.9997909665107727e-01
    z[6,3,4]  R1411     2.9672408103942871e-01
    z[6,3,4]  R1412     -3.4363400936126709e-01
    z[6,3,4]  R1413     -1.0641941428184509e-01
    z[6,3,4]  R1414     -0.382472962141037
    z[6,3,4]  R1415     -4.4036373496055603e-01
    z[6,3,4]  R1416     1.1417217552661896e-01
    z[6,3,4]  R1417     1.5343791246414185e-01
    z[6,3,4]  R1418     3.6165687441825867e-01
    z[6,3,4]  R1419     -4.7659203410148621e-01
    z[6,3,4]  R1420     -0.0654422715306282
    z[6,3,4]  R1421     4.0773589164018631e-02
    z[6,3,4]  R1422     3.0711600184440613e-01
    z[6,3,4]  R1423     9.1799207031726837e-02
    z[6,3,4]  R1424     9.9960751831531525e-02
    z[6,3,4]  R1425     3.4307071566581726e-01
    z[6,3,4]  R1426     -4.8401427268981934e-01
    z[6,3,4]  R1427     4.6343751251697540e-02
    z[6,3,4]  R1428     5.4460112005472183e-02
    z[6,3,4]  R1429     -3.2666212320327759e-01
    z[6,3,4]  R1430     1.3809368014335632e-01
    z[6,3,4]  R1431     6.6078805923461914e-01
    z[6,3,4]  R1432     -3.1959589570760727e-02
    z[6,3,4]  R1433     4.6754062175750732e-01
    z[6,3,4]  R1434     -3.1381070613861084e-01
    z[6,3,4]  R1435     -6.2581133842468262e-01
    z[6,3,4]  R1436     -1.9610758870840073e-02
    z[6,3,4]  R1437     -4.9195587635040283e-02
    z[6,3,4]  R1438     2.2888121008872986e-01
    z[6,3,4]  R1439     1.2012667208909988e-01
    z[6,3,4]  R1440     -3.0425125360488892e-01
    z[6,3,4]  R1441     -7.9097676277160645e-01
    z[6,3,4]  R1442     2.3311580717563629e-01
    z[6,3,4]  R1443     -1.8523296713829041e-01
    z[6,3,4]  R1444     2.3390786349773407e-01
    z[6,3,4]  R1445     5.2037900686264038e-01
    z[6,3,4]  R1446     -2.6308125257492065e-01
    z[6,3,4]  R1447     4.4833451509475708e-01
    z[6,3,4]  R1448     -2.2582834959030151e-01
    z[6,3,4]  R1449     4.2494514584541321e-01
    z[6,3,4]  R1450     2.3748284205794334e-02
    z[6,3,4]  R1451     -5.7107824832201004e-02
    z[6,3,4]  R1452     1.9484585523605347e-01
    z[6,3,4]  R1453     4.0376982651650906e-03
    z[6,3,4]  R1454     1.2568618357181549e-01
    z[6,3,4]  R1455     -3.9516729116439819e-01
    z[6,3,4]  R1456     -4.3289104104042053e-01
    z[6,3,4]  R1457     1.7633788287639618e-01
    z[6,3,4]  R1458     -3.3293321728706360e-02
    z[6,3,4]  R1459     3.1441393494606018e-01
    z[6,3,4]  R1460     2.5045558810234070e-01
    z[6,3,4]  R1461     1.5220838785171509e-01
    z[6,3,4]  R1462     3.3705178648233414e-02
    z[6,3,4]  R1463     -8.6671836674213409e-02
    z[6,3,4]  R1464     5.3131759166717529e-01
    z[6,3,4]  R1465     -2.8040159493684769e-02
    z[6,3,4]  R1466     -1.8048363924026489e-01
    z[6,3,4]  R1467     2.8188863396644592e-01
    z[6,3,4]  R1468     -0.0724576786160469
    z[6,3,4]  R1469     2.1844211220741272e-01
    z[6,3,4]  R1470     -1.2153670191764832e-01
    z[6,3,4]  R1471     -1.3801916502416134e-02
    z[6,3,4]  R1472     2.5893816351890564e-01
    z[6,3,4]  R1473     4.8382304608821869e-02
    z[6,3,4]  R1474     -2.3363950848579407e-01
    z[6,3,4]  R1475     -4.4344505667686462e-01
    z[6,3,5]  R34       1
    z[6,3,5]  R61       -1
    z[6,3,5]  R1382     -1
    z[6,3,5]  R1383     1
    z[6,3,5]  R1386     -4.1011118888854980e-01
    z[6,3,5]  R1387     -3.5467270016670227e-01
    z[6,3,5]  R1388     -6.7898106575012207e-01
    z[6,3,5]  R1389     -3.8434910774230957e-01
    z[6,3,5]  R1390     -6.0099124908447266e-01
    z[6,3,5]  R1391     8.2026623189449310e-02
    z[6,3,5]  R1392     -2.9660975933074951e-01
    z[6,3,5]  R1393     4.6530964970588684e-01
    z[6,3,5]  R1394     5.5250751972198486e-01
    z[6,3,5]  R1395     4.3743756413459778e-01
    z[6,3,5]  R1396     -3.0136564373970032e-01
    z[6,3,5]  R1397     3.5118868947029114e-01
    z[6,3,5]  R1398     7.3869693279266357e-01
    z[6,3,5]  R1399     -2.6882886886596680e-01
    z[6,3,5]  R1400     -4.3684488534927368e-01
    z[6,3,5]  R1401     3.1190750002861023e-01
    z[6,3,5]  R1402     5.0793045759201050e-01
    z[6,3,5]  R1403     4.7194175422191620e-02
    z[6,3,5]  R1404     8.8561016321182251e-01
    z[6,3,5]  R1405     7.0759785175323486e-01
    z[6,3,5]  R1406     7.4784934520721436e-01
    z[6,3,5]  R1407     7.0382225513458252e-01
    z[6,3,5]  R1408     7.0949828624725342e-01
    z[6,3,5]  R1409     7.6195400953292847e-01
    z[6,3,5]  R1410     5.8875405788421631e-01
    z[6,3,5]  R1411     6.5910464525222778e-01
    z[6,3,5]  R1412     7.7146822214126587e-01
    z[6,3,5]  R1413     2.8881141543388367e-01
    z[6,3,5]  R1414     -3.2654516398906708e-02
    z[6,3,5]  R1415     4.1194760799407959e-01
    z[6,3,5]  R1416     7.1507257223129272e-01
    z[6,3,5]  R1417     8.2039844989776611e-01
    z[6,3,5]  R1418     6.3013392686843872e-01
    z[6,3,5]  R1419     1.5305669605731964e-01
    z[6,3,5]  R1420     3.7789145112037659e-01
    z[6,3,5]  R1421     -4.2847845703363419e-02
    z[6,3,5]  R1422     4.6800276637077332e-01
    z[6,3,5]  R1423     3.1855154037475586e-01
    z[6,3,5]  R1424     1.1651323735713959e-01
    z[6,3,5]  R1425     3.0713552236557007e-01
    z[6,3,5]  R1426     -3.7373277544975281e-01
    z[6,3,5]  R1427     -2.8061193227767944e-01
    z[6,3,5]  R1428     -2.6671119034290314e-02
    z[6,3,5]  R1429     -1.1959427595138550e-01
    z[6,3,5]  R1430     -3.1937101483345032e-01
    z[6,3,5]  R1431     -3.6324670910835266e-01
    z[6,3,5]  R1432     -8.2112692296504974e-02
    z[6,3,5]  R1433     -6.9876688718795776e-01
    z[6,3,5]  R1434     -0.394333153963089
    z[6,3,5]  R1435     -4.3859738111495972e-01
    z[6,3,5]  R1436     3.3692322671413422e-02
    z[6,3,5]  R1437     -1.6348755359649658e-01
    z[6,3,5]  R1438     -2.0855288952589035e-02
    z[6,3,5]  R1439     2.0821157097816467e-01
    z[6,3,5]  R1440     -0.0433766171336174
    z[6,3,5]  R1441     -5.6146692484617233e-02
    z[6,3,5]  R1442     2.7365830540657043e-01
    z[6,3,5]  R1443     2.2968876361846924e-01
    z[6,3,5]  R1444     4.4170853495597839e-01
    z[6,3,5]  R1445     3.6483103036880493e-01
    z[6,3,5]  R1446     -4.5089519023895264e-01
    z[6,3,5]  R1447     -2.5357827544212341e-02
    z[6,3,5]  R1448     1.5495795011520386e-01
    z[6,3,5]  R1449     8.0810030922293663e-03
    z[6,3,5]  R1450     0.0723768025636673
    z[6,3,5]  R1451     5.9614843130111694e-01
    z[6,3,5]  R1452     5.4889399558305740e-02
    z[6,3,5]  R1453     -0.197321817278862
    z[6,3,5]  R1454     2.7102181687951088e-02
    z[6,3,5]  R1455     2.8337183594703674e-01
    z[6,3,5]  R1456     0.256511926651001
    z[6,3,5]  R1457     -6.9606119394302368e-01
    z[6,3,5]  R1458     3.4793254733085632e-01
    z[6,3,5]  R1459     4.8544409871101379e-01
    z[6,3,5]  R1460     -6.2928862869739532e-02
    z[6,3,5]  R1461     4.3521293997764587e-01
    z[6,3,5]  R1462     -2.1326787769794464e-02
    z[6,3,5]  R1463     1.4439002610743046e-02
    z[6,3,5]  R1464     2.5736328959465027e-01
    z[6,3,5]  R1465     -3.0850782990455627e-02
    z[6,3,5]  R1466     -7.2390139102935791e-01
    z[6,3,5]  R1467     2.4870058894157410e-01
    z[6,3,5]  R1468     5.1580244302749634e-01
    z[6,3,5]  R1469     0.545786440372467
    z[6,3,5]  R1470     -3.3381292223930359e-01
    z[6,3,5]  R1471     2.2834406793117523e-01
    z[6,3,5]  R1472     1.4479791745543480e-02
    z[6,3,5]  R1473     1.4484675228595734e-01
    z[6,3,5]  R1474     5.0283408164978027e-01
    z[6,3,5]  R1475     1.9192793965339661e-01
    z[6,3,6]  R35       1
    z[6,3,6]  R62       -1
    z[6,3,6]  R1384     -1
    z[6,3,6]  R1385     1
    z[6,3,6]  R1386     1.4036749303340912e-01
    z[6,3,6]  R1387     -3.1022084876894951e-02
    z[6,3,6]  R1388     -3.5945597290992737e-01
    z[6,3,6]  R1389     -3.4882813692092896e-01
    z[6,3,6]  R1390     0.0961492657661438
    z[6,3,6]  R1391     5.1711469888687134e-01
    z[6,3,6]  R1392     -6.0955983400344849e-01
    z[6,3,6]  R1393     -4.3923977762460709e-02
    z[6,3,6]  R1394     4.0581443905830383e-01
    z[6,3,6]  R1395     -5.3546506166458130e-01
    z[6,3,6]  R1396     1.2044569849967957e-01
    z[6,3,6]  R1397     -1.3086408376693726e-01
    z[6,3,6]  R1398     -2.1284069120883942e-01
    z[6,3,6]  R1399     -2.0879344642162323e-01
    z[6,3,6]  R1400     0.389967143535614
    z[6,3,6]  R1401     -2.4880394339561462e-01
    z[6,3,6]  R1402     1.0923012346029282e-01
    z[6,3,6]  R1403     2.9357701539993286e-01
    z[6,3,6]  R1404     -1.3189360499382019e-01
    z[6,3,6]  R1405     -4.1599976248107851e-04
    z[6,3,6]  R1406     9.6221163868904114e-02
    z[6,3,6]  R1407     -1.5994152426719666e-01
    z[6,3,6]  R1408     -6.3475859351456165e-03
    z[6,3,6]  R1409     -3.4419447183609009e-01
    z[6,3,6]  R1410     2.2703444585204124e-02
    z[6,3,6]  R1411     1.1628524214029312e-01
    z[6,3,6]  R1412     9.9947135895490646e-03
    z[6,3,6]  R1413     2.9199233651161194e-01
    z[6,3,6]  R1414     2.8093319386243820e-02
    z[6,3,6]  R1415     1.5568609535694122e-01
    z[6,3,6]  R1416     -1.7072907090187073e-01
    z[6,3,6]  R1417     1.7637057602405548e-01
    z[6,3,6]  R1418     3.7995925545692444e-01
    z[6,3,6]  R1419     -2.4157127737998962e-01
    z[6,3,6]  R1420     -2.4933594465255737e-01
    z[6,3,6]  R1421     1.1855491995811462e-01
    z[6,3,6]  R1422     5.7565051317214966e-01
    z[6,3,6]  R1423     -8.5030794143676758e-02
    z[6,3,6]  R1424     -1.3771559298038483e-01
    z[6,3,6]  R1425     -8.6030957754701376e-04
    z[6,3,6]  R1426     -4.3678706884384155e-01
    z[6,3,6]  R1427     -4.6456691622734070e-01
    z[6,3,6]  R1428     -4.9688091874122620e-01
    z[6,3,6]  R1429     -2.5510832667350769e-01
    z[6,3,6]  R1430     -2.6143577694892883e-01
    z[6,3,6]  R1431     3.9746630191802979e-01
    z[6,3,6]  R1432     6.3786321878433228e-01
    z[6,3,6]  R1433     3.4531423449516296e-01
    z[6,3,6]  R1434     0.658897340297699
    z[6,3,6]  R1435     -3.0043545365333557e-01
    z[6,3,6]  R1436     4.7700032591819763e-02
    z[6,3,6]  R1437     1.6875910758972168e-01
    z[6,3,6]  R1438     3.4356853365898132e-01
    z[6,3,6]  R1439     -3.2359704375267029e-01
    z[6,3,6]  R1440     2.1930399537086487e-01
    z[6,3,6]  R1441     -4.2879793792963028e-02
    z[6,3,6]  R1442     2.2674646973609924e-01
    z[6,3,6]  R1443     3.6886653304100037e-01
    z[6,3,6]  R1444     1.3063828647136688e-01
    z[6,3,6]  R1445     8.7904646992683411e-02
    z[6,3,6]  R1446     -2.1914835274219513e-01
    z[6,3,6]  R1447     -4.5325968414545059e-02
    z[6,3,6]  R1448     4.7167718410491943e-01
    z[6,3,6]  R1449     2.3300263285636902e-01
    z[6,3,6]  R1450     -1.8468016386032104e-01
    z[6,3,6]  R1451     1.2350400909781456e-02
    z[6,3,6]  R1452     -1.1037850379943848e-01
    z[6,3,6]  R1453     -1.6299147903919220e-01
    z[6,3,6]  R1454     -2.8236522339284420e-03
    z[6,3,6]  R1455     3.1427938491106033e-02
    z[6,3,6]  R1456     2.0696519315242767e-01
    z[6,3,6]  R1457     -3.7461996078491211e-01
    z[6,3,6]  R1458     0.565693199634552
    z[6,3,6]  R1459     9.2446379363536835e-02
    z[6,3,6]  R1460     2.3793274164199829e-01
    z[6,3,6]  R1461     1.2363357841968536e-01
    z[6,3,6]  R1462     -7.3006264865398407e-02
    z[6,3,6]  R1463     6.8720698356628418e-02
    z[6,3,6]  R1464     1.3928471505641937e-01
    z[6,3,6]  R1465     0.0840034931898117
    z[6,3,6]  R1466     4.4490348547697067e-02
    z[6,3,6]  R1467     4.0182426571846008e-02
    z[6,3,6]  R1468     -7.1369171142578125e-02
    z[6,3,6]  R1469     -1.2926366925239563e-01
    z[6,3,6]  R1470     -2.9037842154502869e-01
    z[6,3,6]  R1471     4.1457340121269226e-01
    z[6,3,6]  R1472     2.4589551985263824e-01
    z[6,3,6]  R1473     -1.1040373146533966e-01
    z[6,3,6]  R1474     -1.0975638777017593e-01
    z[6,3,6]  R1475     -2.2316549718379974e-01
    z[3,7,0]  R29       -1
    z[3,7,0]  R65       1
    z[3,7,0]  R1476     -1
    z[3,7,0]  R1477     1
    z[3,7,0]  R1490     -3.4679239988327026e-01
    z[3,7,0]  R1491     3.1635525822639465e-01
    z[3,7,0]  R1492     2.4061417579650879e-01
    z[3,7,0]  R1493     1.3621720671653748e-01
    z[3,7,0]  R1494     1.2337982654571533e-01
    z[3,7,0]  R1495     -1.5169952809810638e-01
    z[3,7,0]  R1496     2.2870300710201263e-01
    z[3,7,0]  R1497     -1.9770224392414093e-01
    z[3,7,0]  R1498     2.8880143165588379e-01
    z[3,7,0]  R1499     -1.5453328192234039e-01
    z[3,7,0]  R1500     3.8862389326095581e-01
    z[3,7,0]  R1501     3.7091308832168579e-01
    z[3,7,0]  R1502     0.478127658367157
    z[3,7,0]  R1503     4.6311464905738831e-01
    z[3,7,0]  R1504     4.7244840860366821e-01
    z[3,7,0]  R1505     -3.2537445425987244e-01
    z[3,7,0]  R1506     4.7602352499961853e-01
    z[3,7,0]  R1507     2.5705429911613464e-01
    z[3,7,0]  R1508     5.9679847955703735e-01
    z[3,7,0]  R1509     4.8446375131607056e-01
    z[3,7,0]  R1510     -1.4129619300365448e-01
    z[3,7,0]  R1511     -2.4598467350006104e-01
    z[3,7,0]  R1512     -2.2360714152455330e-02
    z[3,7,0]  R1513     4.9472215771675110e-01
    z[3,7,0]  R1514     -2.9698467254638672e-01
    z[3,7,0]  R1515     9.5166578888893127e-02
    z[3,7,0]  R1516     -8.4637673571705818e-03
    z[3,7,0]  R1517     3.5379037261009216e-01
    z[3,7,0]  R1518     -4.9908825755119324e-01
    z[3,7,0]  R1519     2.0909052342176437e-02
    z[3,7,0]  R1520     -1.6441054642200470e-01
    z[3,7,0]  R1521     -4.1640344262123108e-01
    z[3,7,0]  R1522     2.3950491845607758e-01
    z[3,7,0]  R1523     -3.0985912680625916e-01
    z[3,7,0]  R1524     1.3322702050209045e-01
    z[3,7,0]  R1525     2.8159549832344055e-01
    z[3,7,0]  R1526     -5.0860035419464111e-01
    z[3,7,0]  R1527     -2.9777538776397705e-01
    z[3,7,0]  R1528     1.0051559656858444e-01
    z[3,7,0]  R1529     -4.4247376918792725e-01
    z[3,7,0]  R1530     -1.9971807301044464e-01
    z[3,7,0]  R1531     -1.4479297399520874e-01
    z[3,7,0]  R1532     3.1530305743217468e-01
    z[3,7,0]  R1533     -4.0553700923919678e-01
    z[3,7,0]  R1534     2.8023305535316467e-01
    z[3,7,0]  R1535     1.1138470470905304e-01
    z[3,7,0]  R1536     -1.4050295948982239e-01
    z[3,7,0]  R1537     -1.6415895521640778e-01
    z[3,7,0]  R1538     -3.0126294121146202e-02
    z[3,7,0]  R1539     -2.0682542026042938e-01
    z[3,7,0]  R1540     0.831761360168457
    z[3,7,0]  R1541     9.2205941677093506e-01
    z[3,7,0]  R1542     8.5395079851150513e-01
    z[3,7,0]  R1543     7.1274155378341675e-01
    z[3,7,0]  R1544     8.4566819667816162e-01
    z[3,7,0]  R1545     6.3203769922256470e-01
    z[3,7,0]  R1546     6.9810485839843750e-01
    z[3,7,0]  R1547     -1.6135847568511963e-01
    z[3,7,0]  R1548     -1.4748410880565643e-01
    z[3,7,0]  R1549     1.5411005914211273e-01
    z[3,7,0]  R1550     -2.0003539323806763e-01
    z[3,7,0]  R1551     -5.4264968633651733e-01
    z[3,7,0]  R1552     -5.2113640308380127e-01
    z[3,7,0]  R1553     -5.5860871076583862e-01
    z[3,7,0]  R1554     -1.8229384720325470e-01
    z[3,7,0]  R1555     -4.6869260072708130e-01
    z[3,7,0]  R1556     -4.7543257474899292e-01
    z[3,7,0]  R1557     -5.8686113357543945e-01
    z[3,7,0]  R1558     -2.1261937916278839e-01
    z[3,7,0]  R1559     -5.0665266811847687e-02
    z[3,7,0]  R1560     -2.2017173469066620e-01
    z[3,7,0]  R1561     -1.0050955414772034e-01
    z[3,7,0]  R1562     -3.8916191458702087e-01
    z[3,7,0]  R1563     3.5358372330665588e-01
    z[3,7,0]  R1564     1.0035784542560577e-01
    z[3,7,0]  R1565     -3.2422360777854919e-01
    z[3,7,0]  R1566     5.0990432500839233e-01
    z[3,7,0]  R1567     7.3181706666946411e-01
    z[3,7,0]  R1568     3.9688837714493275e-03
    z[3,7,0]  R1569     -7.7977222204208374e-01
    z[3,7,0]  R1570     -0.8011514544487
    z[3,7,0]  R1571     -6.4584916830062866e-01
    z[3,7,0]  R1572     -6.4749133586883545e-01
    z[3,7,0]  R1573     -0.866128146648407
    z[3,7,0]  R1574     -5.2334684133529663e-01
    z[3,7,0]  R1575     -9.0055245161056519e-01
    z[3,7,0]  R1576     -5.1530826091766357e-01
    z[3,7,0]  R1577     -4.6573814749717712e-01
    z[3,7,0]  R1578     4.4696500897407532e-01
    z[3,7,0]  R1579     0.421758234500885
    z[3,7,0]  R1580     -0.128040611743927
    z[3,7,0]  R1581     -2.0239213481545448e-02
    z[3,7,0]  R1582     -7.9799783229827881e-01
    z[3,7,0]  R1583     -1.4799687266349792e-01
    z[3,7,0]  R1584     -3.1945714354515076e-01
    z[3,7,0]  R1585     0.718023955821991
    z[3,7,0]  R1586     1.3686415553092957e-01
    z[3,7,0]  R1587     2.3470732569694519e-01
    z[3,7,0]  R1588     1.2830194830894470e-01
    z[3,7,0]  R1589     -2.8881579637527466e-02
    z[3,7,0]  R1590     -1.2167088687419891e-01
    z[3,7,0]  R1591     2.9862058162689209e-01
    z[3,7,0]  R1592     -2.7959802746772766e-01
    z[3,7,0]  R1593     6.2875278294086456e-02
    z[3,7,0]  R1594     -0.276602566242218
    z[3,7,0]  R1595     -7.9921597242355347e-01
    z[3,7,0]  R1596     -1.3351860642433167e-01
    z[3,7,0]  R1597     -0.386550635099411
    z[3,7,0]  R1598     1.8768247961997986e-01
    z[3,7,0]  R1599     0.360411673784256
    z[3,7,1]  R30       -1
    z[3,7,1]  R66       1
    z[3,7,1]  R1478     -1
    z[3,7,1]  R1479     1
    z[3,7,1]  R1490     -5.2148234844207764e-01
    z[3,7,1]  R1491     8.3416923880577087e-02
    z[3,7,1]  R1492     -5.1724594831466675e-01
    z[3,7,1]  R1493     0.436928391456604
    z[3,7,1]  R1494     0.481802374124527
    z[3,7,1]  R1495     -4.2934402823448181e-01
    z[3,7,1]  R1496     4.3029200285673141e-02
    z[3,7,1]  R1497     -3.1166023015975952e-01
    z[3,7,1]  R1498     -9.3946449458599091e-02
    z[3,7,1]  R1499     2.3569411039352417e-01
    z[3,7,1]  R1500     -3.9549741148948669e-01
    z[3,7,1]  R1501     -3.2833805680274963e-01
    z[3,7,1]  R1502     -4.0744832158088684e-01
    z[3,7,1]  R1503     -7.6940737664699554e-02
    z[3,7,1]  R1504     -1.4032201468944550e-01
    z[3,7,1]  R1505     -2.6081937551498413e-01
    z[3,7,1]  R1506     -4.7939816117286682e-01
    z[3,7,1]  R1507     -5.7229530811309814e-01
    z[3,7,1]  R1508     -1.1862655729055405e-01
    z[3,7,1]  R1509     -2.3100028932094574e-01
    z[3,7,1]  R1510     -3.8691377639770508e-01
    z[3,7,1]  R1511     -1.3536162674427032e-01
    z[3,7,1]  R1512     -8.1442302465438843e-01
    z[3,7,1]  R1513     2.1609127521514893e-01
    z[3,7,1]  R1514     -8.0153423547744751e-01
    z[3,7,1]  R1515     -7.2501242160797119e-01
    z[3,7,1]  R1516     -9.2812252044677734e-01
    z[3,7,1]  R1517     5.6346774101257324e-01
    z[3,7,1]  R1518     0.726138710975647
    z[3,7,1]  R1519     -0.0324397049844265
    z[3,7,1]  R1520     -3.2403391599655151e-01
    z[3,7,1]  R1521     -4.0914842486381531e-01
    z[3,7,1]  R1522     -5.8479070663452148e-01
    z[3,7,1]  R1523     -6.0351520776748657e-01
    z[3,7,1]  R1524     1.4922253787517548e-01
    z[3,7,1]  R1525     5.9933638572692871e-01
    z[3,7,1]  R1526     4.6213066577911377e-01
    z[3,7,1]  R1527     0.813393771648407
    z[3,7,1]  R1528     4.7956377267837524e-01
    z[3,7,1]  R1529     6.3635557889938354e-01
    z[3,7,1]  R1530     -3.5282588005065918e-01
    z[3,7,1]  R1531     -5.1891523599624634e-01
    z[3,7,1]  R1532     -7.3771619796752930e-01
    z[3,7,1]  R1533     -6.7508661746978760e-01
    z[3,7,1]  R1534     3.8875925540924072e-01
    z[3,7,1]  R1535     5.7495909929275513e-01
    z[3,7,1]  R1536     5.7786947488784790e-01
    z[3,7,1]  R1537     8.9735507965087891e-01
    z[3,7,1]  R1538     4.3170607089996338e-01
    z[3,7,1]  R1539     7.3682177066802979e-01
    z[3,7,1]  R1540     1.1788117140531540e-01
    z[3,7,1]  R1541     -5.7180680334568024e-02
    z[3,7,1]  R1542     -1.2512235343456268e-01
    z[3,7,1]  R1543     -2.2064872086048126e-01
    z[3,7,1]  R1544     -0.262986958026886
    z[3,7,1]  R1545     -2.0322947204113007e-01
    z[3,7,1]  R1546     1.2710350751876831e-01
    z[3,7,1]  R1547     -6.1658447980880737e-01
    z[3,7,1]  R1548     -5.7900321483612061e-01
    z[3,7,1]  R1549     -6.4628767967224121e-01
    z[3,7,1]  R1550     1.9738541543483734e-01
    z[3,7,1]  R1551     6.6613882780075073e-01
    z[3,7,1]  R1552     7.3474103212356567e-01
    z[3,7,1]  R1553     7.4525296688079834e-02
    z[3,7,1]  R1554     -2.2945592645555735e-03
    z[3,7,1]  R1555     4.4102672487497330e-02
    z[3,7,1]  R1556     5.7743549346923828e-01
    z[3,7,1]  R1557     5.3636454045772552e-02
    z[3,7,1]  R1558     4.0496596693992615e-01
    z[3,7,1]  R1559     6.5669816732406616e-01
    z[3,7,1]  R1560     -6.7782026529312134e-01
    z[3,7,1]  R1561     -8.0523324012756348e-01
    z[3,7,1]  R1562     -5.9223777055740356e-01
    z[3,7,1]  R1563     -7.8164649009704590e-01
    z[3,7,1]  R1564     -7.4711662530899048e-01
    z[3,7,1]  R1565     -6.4996057748794556e-01
    z[3,7,1]  R1566     -0.512759268283844
    z[3,7,1]  R1567     -5.2422821521759033e-01
    z[3,7,1]  R1568     -4.5910209417343140e-01
    z[3,7,1]  R1569     1.1272864043712616e-01
    z[3,7,1]  R1570     -3.4529095888137817e-01
    z[3,7,1]  R1571     7.0104561746120453e-03
    z[3,7,1]  R1572     4.6046581119298935e-03
    z[3,7,1]  R1573     -5.4499473422765732e-02
    z[3,7,1]  R1574     1.7552489042282104e-01
    z[3,7,1]  R1575     -9.6060343086719513e-02
    z[3,7,1]  R1576     7.1108184754848480e-02
    z[3,7,1]  R1577     -4.3063253164291382e-01
    z[3,7,1]  R1578     2.3395034670829773e-01
    z[3,7,1]  R1579     1.2475195527076721e-01
    z[3,7,1]  R1580     -6.4332002401351929e-01
    z[3,7,1]  R1581     8.6006671190261841e-02
    z[3,7,1]  R1582     5.9089845418930054e-01
    z[3,7,1]  R1583     6.4706325531005859e-01
    z[3,7,1]  R1584     0.686769425868988
    z[3,7,1]  R1585     2.7850097417831421e-01
    z[3,7,1]  R1586     9.1011798381805420e-01
    z[3,7,1]  R1587     8.5468226671218872e-01
    z[3,7,1]  R1588     9.0942496061325073e-01
    z[3,7,1]  R1589     7.3431169986724854e-01
    z[3,7,1]  R1590     -7.3055410385131836e-01
    z[3,7,1]  R1591     -6.7307293415069580e-01
    z[3,7,1]  R1592     -7.0669221878051758e-01
    z[3,7,1]  R1593     -6.1387270689010620e-01
    z[3,7,1]  R1594     9.0618662536144257e-02
    z[3,7,1]  R1595     5.9256780147552490e-01
    z[3,7,1]  R1596     6.7437773942947388e-01
    z[3,7,1]  R1597     7.3519986867904663e-01
    z[3,7,1]  R1598     5.2971726655960083e-01
    z[3,7,1]  R1599     4.3057283759117126e-01
    z[3,7,2]  R31       -1
    z[3,7,2]  R67       1
    z[3,7,2]  R1480     -1
    z[3,7,2]  R1481     1
    z[3,7,2]  R1490     1.5335462987422943e-01
    z[3,7,2]  R1491     -6.0049909353256226e-01
    z[3,7,2]  R1492     5.4962551593780518e-01
    z[3,7,2]  R1493     -3.2779499888420105e-01
    z[3,7,2]  R1494     -3.8564798235893250e-01
    z[3,7,2]  R1495     -4.9620741046965122e-03
    z[3,7,2]  R1496     -4.8943346738815308e-01
    z[3,7,2]  R1497     1.8296520411968231e-01
    z[3,7,2]  R1498     -4.2893221974372864e-01
    z[3,7,2]  R1499     -2.5571811944246292e-02
    z[3,7,2]  R1500     3.3236268162727356e-01
    z[3,7,2]  R1501     4.7776794433593750e-01
    z[3,7,2]  R1502     5.4234284162521362e-01
    z[3,7,2]  R1503     3.3731272816658020e-01
    z[3,7,2]  R1504     6.2042981386184692e-01
    z[3,7,2]  R1505     -4.3763765692710876e-01
    z[3,7,2]  R1506     2.6428681612014771e-01
    z[3,7,2]  R1507     1.4328658580780029e-03
    z[3,7,2]  R1508     3.2177260518074036e-01
    z[3,7,2]  R1509     1.7702539265155792e-01
    z[3,7,2]  R1510     -7.1257036924362183e-01
    z[3,7,2]  R1511     -5.8643120527267456e-01
    z[3,7,2]  R1512     -1.3432666659355164e-01
    z[3,7,2]  R1513     4.8286509513854980e-01
    z[3,7,2]  R1514     -4.7755271196365356e-01
    z[3,7,2]  R1515     -2.8411459922790527e-01
    z[3,7,2]  R1516     -1.3416558504104614e-01
    z[3,7,2]  R1517     7.0129656791687012e-01
    z[3,7,2]  R1518     -3.3579519391059875e-01
    z[3,7,2]  R1519     1.0880029201507568e-01
    z[3,7,2]  R1520     -0.604345440864563
    z[3,7,2]  R1521     -2.9558802023530006e-02
    z[3,7,2]  R1522     1.1722157150506973e-01
    z[3,7,2]  R1523     3.9034938812255859e-01
    z[3,7,2]  R1524     4.1221952438354492e-01
    z[3,7,2]  R1525     -1.5346366167068481e-01
    z[3,7,2]  R1526     -6.5238827466964722e-01
    z[3,7,2]  R1527     -4.8277732729911804e-01
    z[3,7,2]  R1528     6.8101976066827774e-03
    z[3,7,2]  R1529     -5.9404021501541138e-01
    z[3,7,2]  R1530     -3.6452940106391907e-01
    z[3,7,2]  R1531     -2.5705328583717346e-01
    z[3,7,2]  R1532     -5.0469189882278442e-03
    z[3,7,2]  R1533     1.0578592121601105e-01
    z[3,7,2]  R1534     6.2631016969680786e-01
    z[3,7,2]  R1535     -2.6241201162338257e-01
    z[3,7,2]  R1536     -9.8471298813819885e-02
    z[3,7,2]  R1537     -3.2202121615409851e-01
    z[3,7,2]  R1538     -2.2024551033973694e-01
    z[3,7,2]  R1539     -3.5296049714088440e-01
    z[3,7,2]  R1540     1.5736088156700134e-01
    z[3,7,2]  R1541     3.1619224697351456e-02
    z[3,7,2]  R1542     -2.8328439593315125e-01
    z[3,7,2]  R1543     1.6663897037506104e-01
    z[3,7,2]  R1544     4.3664994835853577e-01
    z[3,7,2]  R1545     3.6473900079727173e-01
    z[3,7,2]  R1546     9.3046009540557861e-02
    z[3,7,2]  R1547     2.6254189014434814e-01
    z[3,7,2]  R1548     0.255932092666626
    z[3,7,2]  R1549     3.0451336503028870e-01
    z[3,7,2]  R1550     -7.3511481285095215e-01
    z[3,7,2]  R1551     -3.7339490652084351e-01
    z[3,7,2]  R1552     -2.5605386495590210e-01
    z[3,7,2]  R1553     -3.1785136461257935e-01
    z[3,7,2]  R1554     -8.7365549802780151e-01
    z[3,7,2]  R1555     -6.0707551240921021e-01
    z[3,7,2]  R1556     -3.5549452900886536e-01
    z[3,7,2]  R1557     -0.730562686920166
    z[3,7,2]  R1558     -7.2983330488204956e-01
    z[3,7,2]  R1559     -5.8316880464553833e-01
    z[3,7,2]  R1560     -5.9866684675216675e-01
    z[3,7,2]  R1561     -3.0322751402854919e-01
    z[3,7,2]  R1562     -2.2276845574378967e-01
    z[3,7,2]  R1563     -8.7085880339145660e-02
    z[3,7,2]  R1564     -1.8152470886707306e-01
    z[3,7,2]  R1565     -2.1618537604808807e-01
    z[3,7,2]  R1566     -4.0154952555894852e-02
    z[3,7,2]  R1567     1.2722371518611908e-01
    z[3,7,2]  R1568     7.7772176265716553e-01
    z[3,7,2]  R1569     -2.9540473222732544e-01
    z[3,7,2]  R1570     3.6096596717834473e-01
    z[3,7,2]  R1571     -3.6073359847068787e-01
    z[3,7,2]  R1572     -0.50264972448349
    z[3,7,2]  R1573     -1.4566515386104584e-01
    z[3,7,2]  R1574     -5.9669876098632812e-01
    z[3,7,2]  R1575     -4.2036834359169006e-01
    z[3,7,2]  R1576     -0.81169593334198
    z[3,7,2]  R1577     -8.8499732315540314e-02
    z[3,7,2]  R1578     5.6356781721115112e-01
    z[3,7,2]  R1579     6.6970270872116089e-01
    z[3,7,2]  R1580     2.8186139464378357e-01
    z[3,7,2]  R1581     -0.647044837474823
    z[3,7,2]  R1582     -7.7119171619415283e-02
    z[3,7,2]  R1583     -5.6557118892669678e-01
    z[3,7,2]  R1584     -4.3069493770599365e-01
    z[3,7,2]  R1585     4.9036827683448792e-01
    z[3,7,2]  R1586     6.6082730889320374e-02
    z[3,7,2]  R1587     1.8462300300598145e-01
    z[3,7,2]  R1588     -1.1157387867569923e-02
    z[3,7,2]  R1589     -5.1228034496307373e-01
    z[3,7,2]  R1590     2.6303809881210327e-01
    z[3,7,2]  R1591     5.2225303649902344e-01
    z[3,7,2]  R1592     1.6468265652656555e-01
    z[3,7,2]  R1593     -3.2448098063468933e-01
    z[3,7,2]  R1594     -0.89305579662323
    z[3,7,2]  R1595     -5.2912008017301559e-02
    z[3,7,2]  R1596     -6.0445809364318848e-01
    z[3,7,2]  R1597     -3.9572045207023621e-01
    z[3,7,2]  R1598     5.8833497762680054e-01
    z[3,7,2]  R1599     6.8056142330169678e-01
    z[3,7,3]  R32       -1
    z[3,7,3]  R68       1
    z[3,7,3]  R1482     -1
    z[3,7,3]  R1483     1
    z[3,7,3]  R1490     1.3980150222778320e-01
    z[3,7,3]  R1491     -4.8543652892112732e-01
    z[3,7,3]  R1492     0.349149614572525
    z[3,7,3]  R1493     -7.0498067140579224e-01
    z[3,7,3]  R1494     -6.4381921291351318e-01
    z[3,7,3]  R1495     2.5701728463172913e-01
    z[3,7,3]  R1496     -5.4006010293960571e-01
    z[3,7,3]  R1497     -0.0647614598274231
    z[3,7,3]  R1498     -1.8884766101837158e-01
    z[3,7,3]  R1499     -4.9562579393386841e-01
    z[3,7,3]  R1500     -7.6045602560043335e-01
    z[3,7,3]  R1501     -6.8463677167892456e-01
    z[3,7,3]  R1502     -3.7467747926712036e-01
    z[3,7,3]  R1503     -7.0945578813552856e-01
    z[3,7,3]  R1504     -4.7919160127639771e-01
    z[3,7,3]  R1505     -6.2790863215923309e-02
    z[3,7,3]  R1506     -5.4137378931045532e-01
    z[3,7,3]  R1507     -6.1908680200576782e-01
    z[3,7,3]  R1508     -5.0925046205520630e-01
    z[3,7,3]  R1509     -5.1862555742263794e-01
    z[3,7,3]  R1510     0.0450817309319973
    z[3,7,3]  R1511     -6.1120027303695679e-01
    z[3,7,3]  R1512     1.4381159842014313e-01
    z[3,7,3]  R1513     -4.9036917090415955e-01
    z[3,7,3]  R1514     -3.7112716585397720e-02
    z[3,7,3]  R1515     1.6053833067417145e-01
    z[3,7,3]  R1516     -2.5952902436256409e-01
    z[3,7,3]  R1517     -1.0738559067249298e-03
    z[3,7,3]  R1518     3.0714073777198792e-01
    z[3,7,3]  R1519     8.6557984352111816e-01
    z[3,7,3]  R1520     -4.5465391874313354e-01
    z[3,7,3]  R1521     -4.8944808542728424e-02
    z[3,7,3]  R1522     3.8044983148574829e-01
    z[3,7,3]  R1523     -2.1053658425807953e-01
    z[3,7,3]  R1524     8.1655263900756836e-01
    z[3,7,3]  R1525     -5.5685347318649292e-01
    z[3,7,3]  R1526     3.0859303474426270e-01
    z[3,7,3]  R1527     -6.4833253622055054e-02
    z[3,7,3]  R1528     6.2604665756225586e-01
    z[3,7,3]  R1529     1.9388185441493988e-01
    z[3,7,3]  R1530     -3.7968146800994873e-01
    z[3,7,3]  R1531     7.0764243602752686e-01
    z[3,7,3]  R1532     -2.8273233771324158e-01
    z[3,7,3]  R1533     7.9361535608768463e-02
    z[3,7,3]  R1534     -4.0932792425155640e-01
    z[3,7,3]  R1535     -6.0328519344329834e-01
    z[3,7,3]  R1536     7.1337640285491943e-01
    z[3,7,3]  R1537     1.6910864412784576e-01
    z[3,7,3]  R1538     6.6688686609268188e-01
    z[3,7,3]  R1539     8.0330856144428253e-02
    z[3,7,3]  R1540     -0.504252552986145
    z[3,7,3]  R1541     -2.4172352254390717e-01
    z[3,7,3]  R1542     -3.7082454562187195e-01
    z[3,7,3]  R1543     -4.2431572079658508e-01
    z[3,7,3]  R1544     -1.4273391105234623e-02
    z[3,7,3]  R1545     -4.8467060923576355e-01
    z[3,7,3]  R1546     -2.1092857420444489e-01
    z[3,7,3]  R1547     -1.8700738251209259e-01
    z[3,7,3]  R1548     5.6740206480026245e-01
    z[3,7,3]  R1549     -1.0911568999290466e-01
    z[3,7,3]  R1550     -4.2100772261619568e-02
    z[3,7,3]  R1551     -2.1732452511787415e-01
    z[3,7,3]  R1552     -0.109881691634655
    z[3,7,3]  R1553     -1.2937353551387787e-01
    z[3,7,3]  R1554     -1.6076089814305305e-02
    z[3,7,3]  R1555     5.3015798330307007e-02
    z[3,7,3]  R1556     -4.6307405829429626e-01
    z[3,7,3]  R1557     -1.3483323156833649e-02
    z[3,7,3]  R1558     1.8107822537422180e-01
    z[3,7,3]  R1559     -1.2303494662046432e-01
    z[3,7,3]  R1560     1.1183109134435654e-01
    z[3,7,3]  R1561     4.8025703430175781e-01
    z[3,7,3]  R1562     -4.1683989763259888e-01
    z[3,7,3]  R1563     2.5238654017448425e-01
    z[3,7,3]  R1564     1.8978676199913025e-01
    z[3,7,3]  R1565     -3.0419981479644775e-01
    z[3,7,3]  R1566     5.2527725696563721e-01
    z[3,7,3]  R1567     2.6501783728599548e-01
    z[3,7,3]  R1568     2.3504644632339478e-01
    z[3,7,3]  R1569     -3.0951502267271280e-03
    z[3,7,3]  R1570     -1.0267569869756699e-01
    z[3,7,3]  R1571     -9.5114611089229584e-02
    z[3,7,3]  R1572     -3.6320930719375610e-01
    z[3,7,3]  R1573     -3.2691818475723267e-01
    z[3,7,3]  R1574     1.5387211740016937e-01
    z[3,7,3]  R1575     1.2792519293725491e-02
    z[3,7,3]  R1576     9.7040623426437378e-02
    z[3,7,3]  R1577     -4.2647728323936462e-01
    z[3,7,3]  R1578     9.0673323720693588e-03
    z[3,7,3]  R1579     -3.9340332150459290e-01
    z[3,7,3]  R1580     3.7332630157470703e-01
    z[3,7,3]  R1581     -4.8981118947267532e-02
    z[3,7,3]  R1582     4.3991249054670334e-02
    z[3,7,3]  R1583     -1.4338363707065582e-01
    z[3,7,3]  R1584     -1.6163422167301178e-01
    z[3,7,3]  R1585     -2.2544270753860474e-01
    z[3,7,3]  R1586     -3.7036520242691040e-01
    z[3,7,3]  R1587     -3.8125243782997131e-01
    z[3,7,3]  R1588     -3.3912095427513123e-01
    z[3,7,3]  R1589     1.9066568464040756e-02
    z[3,7,3]  R1590     3.4886658191680908e-01
    z[3,7,3]  R1591     9.6905358135700226e-02
    z[3,7,3]  R1592     4.7653075307607651e-02
    z[3,7,3]  R1593     1.5867911279201508e-01
    z[3,7,3]  R1594     -4.2687293142080307e-02
    z[3,7,3]  R1595     -9.7977332770824432e-03
    z[3,7,3]  R1596     -6.8670073524117470e-03
    z[3,7,3]  R1597     -2.0256450772285461e-01
    z[3,7,3]  R1598     -5.2521169185638428e-01
    z[3,7,3]  R1599     -3.5196962952613831e-01
    z[3,7,4]  R33       -1
    z[3,7,4]  R69       1
    z[3,7,4]  R1484     -1
    z[3,7,4]  R1485     1
    z[3,7,4]  R1490     -4.8401427268981934e-01
    z[3,7,4]  R1491     4.6343751251697540e-02
    z[3,7,4]  R1492     5.4460112005472183e-02
    z[3,7,4]  R1493     -3.2666212320327759e-01
    z[3,7,4]  R1494     1.3809368014335632e-01
    z[3,7,4]  R1495     6.6078805923461914e-01
    z[3,7,4]  R1496     -3.1959589570760727e-02
    z[3,7,4]  R1497     4.6754062175750732e-01
    z[3,7,4]  R1498     -3.1381070613861084e-01
    z[3,7,4]  R1499     -6.2581133842468262e-01
    z[3,7,4]  R1500     -1.9610758870840073e-02
    z[3,7,4]  R1501     -4.9195587635040283e-02
    z[3,7,4]  R1502     2.2888121008872986e-01
    z[3,7,4]  R1503     1.2012667208909988e-01
    z[3,7,4]  R1504     -3.0425125360488892e-01
    z[3,7,4]  R1505     -7.9097676277160645e-01
    z[3,7,4]  R1506     2.3311580717563629e-01
    z[3,7,4]  R1507     -1.8523296713829041e-01
    z[3,7,4]  R1508     2.3390786349773407e-01
    z[3,7,4]  R1509     5.2037900686264038e-01
    z[3,7,4]  R1510     -2.6308125257492065e-01
    z[3,7,4]  R1511     4.4833451509475708e-01
    z[3,7,4]  R1512     -2.2582834959030151e-01
    z[3,7,4]  R1513     4.2494514584541321e-01
    z[3,7,4]  R1514     2.3748284205794334e-02
    z[3,7,4]  R1515     -5.7107824832201004e-02
    z[3,7,4]  R1516     1.9484585523605347e-01
    z[3,7,4]  R1517     4.0376982651650906e-03
    z[3,7,4]  R1518     1.2568618357181549e-01
    z[3,7,4]  R1519     -3.9516729116439819e-01
    z[3,7,4]  R1520     -4.3289104104042053e-01
    z[3,7,4]  R1521     1.7633788287639618e-01
    z[3,7,4]  R1522     -3.3293321728706360e-02
    z[3,7,4]  R1523     3.1441393494606018e-01
    z[3,7,4]  R1524     2.5045558810234070e-01
    z[3,7,4]  R1525     1.5220838785171509e-01
    z[3,7,4]  R1526     3.3705178648233414e-02
    z[3,7,4]  R1527     -8.6671836674213409e-02
    z[3,7,4]  R1528     5.3131759166717529e-01
    z[3,7,4]  R1529     -2.8040159493684769e-02
    z[3,7,4]  R1530     -1.8048363924026489e-01
    z[3,7,4]  R1531     2.8188863396644592e-01
    z[3,7,4]  R1532     -0.0724576786160469
    z[3,7,4]  R1533     2.1844211220741272e-01
    z[3,7,4]  R1534     -1.2153670191764832e-01
    z[3,7,4]  R1535     -1.3801916502416134e-02
    z[3,7,4]  R1536     2.5893816351890564e-01
    z[3,7,4]  R1537     4.8382304608821869e-02
    z[3,7,4]  R1538     -2.3363950848579407e-01
    z[3,7,4]  R1539     -4.4344505667686462e-01
    z[3,7,4]  R1540     -9.3567736446857452e-02
    z[3,7,4]  R1541     -4.1627362370491028e-03
    z[3,7,4]  R1542     -1.7485836520791054e-02
    z[3,7,4]  R1543     -3.9552173018455505e-01
    z[3,7,4]  R1544     -5.4580219089984894e-02
    z[3,7,4]  R1545     4.1839987039566040e-01
    z[3,7,4]  R1546     5.4671669006347656e-01
    z[3,7,4]  R1547     -4.9099615216255188e-01
    z[3,7,4]  R1548     1.4081904292106628e-01
    z[3,7,4]  R1549     1.8393313884735107e-01
    z[3,7,4]  R1550     -1.8558960407972336e-02
    z[3,7,4]  R1551     2.4832665920257568e-01
    z[3,7,4]  R1552     -2.2210772335529327e-01
    z[3,7,4]  R1553     6.6949248313903809e-01
    z[3,7,4]  R1554     3.9261576533317566e-01
    z[3,7,4]  R1555     6.2186169624328613e-01
    z[3,7,4]  R1556     1.2779118493199348e-02
    z[3,7,4]  R1557     -1.0554113984107971e-01
    z[3,7,4]  R1558     -3.8992649316787720e-01
    z[3,7,4]  R1559     -1.0634469240903854e-01
    z[3,7,4]  R1560     3.4463945031166077e-01
    z[3,7,4]  R1561     3.5495623946189880e-02
    z[3,7,4]  R1562     4.9213263392448425e-01
    z[3,7,4]  R1563     3.8332742452621460e-01
    z[3,7,4]  R1564     2.8598508238792419e-01
    z[3,7,4]  R1565     -1.3394100964069366e-01
    z[3,7,4]  R1566     -4.4146808981895447e-01
    z[3,7,4]  R1567     -2.3624691367149353e-01
    z[3,7,4]  R1568     -2.4334377050399780e-01
    z[3,7,4]  R1569     -4.7691500186920166e-01
    z[3,7,4]  R1570     2.7066943049430847e-01
    z[3,7,4]  R1571     5.8024022728204727e-02
    z[3,7,4]  R1572     -0.0924634113907814
    z[3,7,4]  R1573     1.2324440479278564e-01
    z[3,7,4]  R1574     1.5061776340007782e-01
    z[3,7,4]  R1575     -9.0359859168529510e-03
    z[3,7,4]  R1576     2.4451713263988495e-01
    z[3,7,4]  R1577     4.0662929415702820e-01
    z[3,7,4]  R1578     4.1545665264129639e-01
    z[3,7,4]  R1579     2.5468489527702332e-01
    z[3,7,4]  R1580     -4.1382867097854614e-01
    z[3,7,4]  R1581     -5.0561362504959106e-01
    z[3,7,4]  R1582     -3.6079576238989830e-03
    z[3,7,4]  R1583     -2.3232956230640411e-01
    z[3,7,4]  R1584     -2.8039303421974182e-01
    z[3,7,4]  R1585     -1.9280940294265747e-02
    z[3,7,4]  R1586     6.0891743749380112e-02
    z[3,7,4]  R1587     -3.9529930800199509e-02
    z[3,7,4]  R1588     -1.9411031901836395e-01
    z[3,7,4]  R1589     -4.1277384757995605e-01
    z[3,7,4]  R1590     -0.163431316614151
    z[3,7,4]  R1591     -1.5994679182767868e-02
    z[3,7,4]  R1592     -3.1727802753448486e-01
    z[3,7,4]  R1593     -1.9960127770900726e-01
    z[3,7,4]  R1594     -1.3360002636909485e-01
    z[3,7,4]  R1595     -5.7889252901077271e-02
    z[3,7,4]  R1596     -2.9758140444755554e-01
    z[3,7,4]  R1597     -1.0412189364433289e-01
    z[3,7,4]  R1598     2.4219968914985657e-01
    z[3,7,4]  R1599     2.4200481176376343e-01
    z[3,7,5]  R34       -1
    z[3,7,5]  R70       1
    z[3,7,5]  R1486     -1
    z[3,7,5]  R1487     1
    z[3,7,5]  R1490     -3.7373277544975281e-01
    z[3,7,5]  R1491     -2.8061193227767944e-01
    z[3,7,5]  R1492     -2.6671119034290314e-02
    z[3,7,5]  R1493     -1.1959427595138550e-01
    z[3,7,5]  R1494     -3.1937101483345032e-01
    z[3,7,5]  R1495     -3.6324670910835266e-01
    z[3,7,5]  R1496     -8.2112692296504974e-02
    z[3,7,5]  R1497     -6.9876688718795776e-01
    z[3,7,5]  R1498     -0.394333153963089
    z[3,7,5]  R1499     -4.3859738111495972e-01
    z[3,7,5]  R1500     3.3692322671413422e-02
    z[3,7,5]  R1501     -1.6348755359649658e-01
    z[3,7,5]  R1502     -2.0855288952589035e-02
    z[3,7,5]  R1503     2.0821157097816467e-01
    z[3,7,5]  R1504     -0.0433766171336174
    z[3,7,5]  R1505     -5.6146692484617233e-02
    z[3,7,5]  R1506     2.7365830540657043e-01
    z[3,7,5]  R1507     2.2968876361846924e-01
    z[3,7,5]  R1508     4.4170853495597839e-01
    z[3,7,5]  R1509     3.6483103036880493e-01
    z[3,7,5]  R1510     -4.5089519023895264e-01
    z[3,7,5]  R1511     -2.5357827544212341e-02
    z[3,7,5]  R1512     1.5495795011520386e-01
    z[3,7,5]  R1513     8.0810030922293663e-03
    z[3,7,5]  R1514     0.0723768025636673
    z[3,7,5]  R1515     5.9614843130111694e-01
    z[3,7,5]  R1516     5.4889399558305740e-02
    z[3,7,5]  R1517     -0.197321817278862
    z[3,7,5]  R1518     2.7102181687951088e-02
    z[3,7,5]  R1519     2.8337183594703674e-01
    z[3,7,5]  R1520     0.256511926651001
    z[3,7,5]  R1521     -6.9606119394302368e-01
    z[3,7,5]  R1522     3.4793254733085632e-01
    z[3,7,5]  R1523     4.8544409871101379e-01
    z[3,7,5]  R1524     -6.2928862869739532e-02
    z[3,7,5]  R1525     4.3521293997764587e-01
    z[3,7,5]  R1526     -2.1326787769794464e-02
    z[3,7,5]  R1527     1.4439002610743046e-02
    z[3,7,5]  R1528     2.5736328959465027e-01
    z[3,7,5]  R1529     -3.0850782990455627e-02
    z[3,7,5]  R1530     -7.2390139102935791e-01
    z[3,7,5]  R1531     2.4870058894157410e-01
    z[3,7,5]  R1532     5.1580244302749634e-01
    z[3,7,5]  R1533     0.545786440372467
    z[3,7,5]  R1534     -3.3381292223930359e-01
    z[3,7,5]  R1535     2.2834406793117523e-01
    z[3,7,5]  R1536     1.4479791745543480e-02
    z[3,7,5]  R1537     1.4484675228595734e-01
    z[3,7,5]  R1538     5.0283408164978027e-01
    z[3,7,5]  R1539     1.9192793965339661e-01
    z[3,7,5]  R1540     4.2699400335550308e-02
    z[3,7,5]  R1541     -1.3356618583202362e-01
    z[3,7,5]  R1542     -3.2809235155582428e-02
    z[3,7,5]  R1543     5.3201489150524139e-02
    z[3,7,5]  R1544     -1.0581449419260025e-01
    z[3,7,5]  R1545     0.0456363819539547
    z[3,7,5]  R1546     -1.0163668543100357e-01
    z[3,7,5]  R1547     -3.2858392596244812e-01
    z[3,7,5]  R1548     2.8948080539703369e-01
    z[3,7,5]  R1549     2.4532085657119751e-01
    z[3,7,5]  R1550     -5.8020043373107910e-01
    z[3,7,5]  R1551     5.5503454059362411e-02
    z[3,7,5]  R1552     1.2265937775373459e-01
    z[3,7,5]  R1553     -2.0580182969570160e-01
    z[3,7,5]  R1554     -0.162678524851799
    z[3,7,5]  R1555     1.8457837402820587e-02
    z[3,7,5]  R1556     -1.9807896018028259e-01
    z[3,7,5]  R1557     -8.4291743114590645e-03
    z[3,7,5]  R1558     2.5627663731575012e-01
    z[3,7,5]  R1559     3.3952635526657104e-01
    z[3,7,5]  R1560     3.5490646958351135e-02
    z[3,7,5]  R1561     -9.9709741771221161e-02
    z[3,7,5]  R1562     -1.2336204200983047e-01
    z[3,7,5]  R1563     -0.200625479221344
    z[3,7,5]  R1564     -5.1801913976669312e-01
    z[3,7,5]  R1565     5.2026188373565674e-01
    z[3,7,5]  R1566     -3.2877799123525620e-02
    z[3,7,5]  R1567     -1.8231348693370819e-01
    z[3,7,5]  R1568     1.1712416261434555e-01
    z[3,7,5]  R1569     -1.7633208632469177e-01
    z[3,7,5]  R1570     1.3752581179141998e-01
    z[3,7,5]  R1571     -5.5856925249099731e-01
    z[3,7,5]  R1572     -2.0876045525074005e-01
    z[3,7,5]  R1573     -0.320121705532074
    z[3,7,5]  R1574     -2.7869519591331482e-01
    z[3,7,5]  R1575     1.1142909526824951e-02
    z[3,7,5]  R1576     -6.2896623276174068e-03
    z[3,7,5]  R1577     -2.5724676251411438e-01
    z[3,7,5]  R1578     5.0354021787643433e-01
    z[3,7,5]  R1579     -3.6257150769233704e-01
    z[3,7,5]  R1580     3.9444151520729065e-01
    z[3,7,5]  R1581     -5.5814504623413086e-01
    z[3,7,5]  R1582     5.5932231247425079e-02
    z[3,7,5]  R1583     -1.4626109972596169e-02
    z[3,7,5]  R1584     3.1677356362342834e-01
    z[3,7,5]  R1585     1.9272281229496002e-01
    z[3,7,5]  R1586     2.3736661300063133e-02
    z[3,7,5]  R1587     -1.2253225594758987e-01
    z[3,7,5]  R1588     5.9116680175065994e-02
    z[3,7,5]  R1589     -3.1366065144538879e-02
    z[3,7,5]  R1590     4.3536716699600220e-01
    z[3,7,5]  R1591     -3.9726775884628296e-01
    z[3,7,5]  R1592     2.3148950934410095e-01
    z[3,7,5]  R1593     -3.2445770502090454e-01
    z[3,7,5]  R1594     -2.2903005778789520e-01
    z[3,7,5]  R1595     3.3493004739284515e-02
    z[3,7,5]  R1596     -1.6680642962455750e-01
    z[3,7,5]  R1597     3.0079308152198792e-01
    z[3,7,5]  R1598     -5.6932557374238968e-02
    z[3,7,5]  R1599     1.9158987700939178e-01
    z[3,7,6]  R35       -1
    z[3,7,6]  R71       1
    z[3,7,6]  R1488     -1
    z[3,7,6]  R1489     1
    z[3,7,6]  R1490     -4.3678706884384155e-01
    z[3,7,6]  R1491     -4.6456691622734070e-01
    z[3,7,6]  R1492     -4.9688091874122620e-01
    z[3,7,6]  R1493     -2.5510832667350769e-01
    z[3,7,6]  R1494     -2.6143577694892883e-01
    z[3,7,6]  R1495     3.9746630191802979e-01
    z[3,7,6]  R1496     6.3786321878433228e-01
    z[3,7,6]  R1497     3.4531423449516296e-01
    z[3,7,6]  R1498     0.658897340297699
    z[3,7,6]  R1499     -3.0043545365333557e-01
    z[3,7,6]  R1500     4.7700032591819763e-02
    z[3,7,6]  R1501     1.6875910758972168e-01
    z[3,7,6]  R1502     3.4356853365898132e-01
    z[3,7,6]  R1503     -3.2359704375267029e-01
    z[3,7,6]  R1504     2.1930399537086487e-01
    z[3,7,6]  R1505     -4.2879793792963028e-02
    z[3,7,6]  R1506     2.2674646973609924e-01
    z[3,7,6]  R1507     3.6886653304100037e-01
    z[3,7,6]  R1508     1.3063828647136688e-01
    z[3,7,6]  R1509     8.7904646992683411e-02
    z[3,7,6]  R1510     -2.1914835274219513e-01
    z[3,7,6]  R1511     -4.5325968414545059e-02
    z[3,7,6]  R1512     4.7167718410491943e-01
    z[3,7,6]  R1513     2.3300263285636902e-01
    z[3,7,6]  R1514     -1.8468016386032104e-01
    z[3,7,6]  R1515     1.2350400909781456e-02
    z[3,7,6]  R1516     -1.1037850379943848e-01
    z[3,7,6]  R1517     -1.6299147903919220e-01
    z[3,7,6]  R1518     -2.8236522339284420e-03
    z[3,7,6]  R1519     3.1427938491106033e-02
    z[3,7,6]  R1520     2.0696519315242767e-01
    z[3,7,6]  R1521     -3.7461996078491211e-01
    z[3,7,6]  R1522     0.565693199634552
    z[3,7,6]  R1523     9.2446379363536835e-02
    z[3,7,6]  R1524     2.3793274164199829e-01
    z[3,7,6]  R1525     1.2363357841968536e-01
    z[3,7,6]  R1526     -7.3006264865398407e-02
    z[3,7,6]  R1527     6.8720698356628418e-02
    z[3,7,6]  R1528     1.3928471505641937e-01
    z[3,7,6]  R1529     0.0840034931898117
    z[3,7,6]  R1530     4.4490348547697067e-02
    z[3,7,6]  R1531     4.0182426571846008e-02
    z[3,7,6]  R1532     -7.1369171142578125e-02
    z[3,7,6]  R1533     -1.2926366925239563e-01
    z[3,7,6]  R1534     -2.9037842154502869e-01
    z[3,7,6]  R1535     4.1457340121269226e-01
    z[3,7,6]  R1536     2.4589551985263824e-01
    z[3,7,6]  R1537     -1.1040373146533966e-01
    z[3,7,6]  R1538     -1.0975638777017593e-01
    z[3,7,6]  R1539     -2.2316549718379974e-01
    z[3,7,6]  R1540     -6.8305768072605133e-02
    z[3,7,6]  R1541     -2.6315292716026306e-01
    z[3,7,6]  R1542     1.8965634703636169e-01
    z[3,7,6]  R1543     2.7610439062118530e-01
    z[3,7,6]  R1544     1.0315315425395966e-01
    z[3,7,6]  R1545     1.1893185228109360e-01
    z[3,7,6]  R1546     3.6621958017349243e-01
    z[3,7,6]  R1547     -3.7528967857360840e-01
    z[3,7,6]  R1548     3.8977968692779541e-01
    z[3,7,6]  R1549     -5.9992820024490356e-01
    z[3,7,6]  R1550     2.0464979112148285e-01
    z[3,7,6]  R1551     1.0193166881799698e-01
    z[3,7,6]  R1552     -2.1577247977256775e-01
    z[3,7,6]  R1553     2.7214100956916809e-01
    z[3,7,6]  R1554     -1.5039950609207153e-01
    z[3,7,6]  R1555     1.4134421944618225e-01
    z[3,7,6]  R1556     -2.4560080468654633e-01
    z[3,7,6]  R1557     -3.2802972197532654e-01
    z[3,7,6]  R1558     -8.7344385683536530e-02
    z[3,7,6]  R1559     -2.9046475887298584e-01
    z[3,7,6]  R1560     -3.3763226121664047e-02
    z[3,7,6]  R1561     8.7758764624595642e-02
    z[3,7,6]  R1562     1.3043515384197235e-01
    z[3,7,6]  R1563     -7.4390277266502380e-02
    z[3,7,6]  R1564     1.1244340986013412e-01
    z[3,7,6]  R1565     2.1105460822582245e-01
    z[3,7,6]  R1566     5.9766110032796860e-02
    z[3,7,6]  R1567     -1.1898516118526459e-01
    z[3,7,6]  R1568     2.3701743781566620e-01
    z[3,7,6]  R1569     1.8284708261489868e-01
    z[3,7,6]  R1570     7.6919443905353546e-02
    z[3,7,6]  R1571     3.5817271471023560e-01
    z[3,7,6]  R1572     -3.7950697541236877e-01
    z[3,7,6]  R1573     3.3026900142431259e-02
    z[3,7,6]  R1574     4.6391418576240540e-01
    z[3,7,6]  R1575     5.1949676126241684e-02
    z[3,7,6]  R1576     3.6134470254182816e-02
    z[3,7,6]  R1577     -4.2000627517700195e-01
    z[3,7,6]  R1578     4.0516536682844162e-02
    z[3,7,6]  R1579     8.3466731011867523e-02
    z[3,7,6]  R1580     -1.5520407259464264e-01
    z[3,7,6]  R1581     -0.0628967210650444
    z[3,7,6]  R1582     -5.4903768002986908e-02
    z[3,7,6]  R1583     -4.0593791007995605e-01
    z[3,7,6]  R1584     -1.8895855545997620e-01
    z[3,7,6]  R1585     -2.7942699193954468e-01
    z[3,7,6]  R1586     8.4527529776096344e-02
    z[3,7,6]  R1587     1.3570147752761841e-01
    z[3,7,6]  R1588     -1.3549934141337872e-02
    z[3,7,6]  R1589     1.6059705615043640e-01
    z[3,7,6]  R1590     -2.1056039631366730e-01
    z[3,7,6]  R1591     1.3259758055210114e-01
    z[3,7,6]  R1592     -4.8863810300827026e-01
    z[3,7,6]  R1593     -5.8619666099548340e-01
    z[3,7,6]  R1594     -2.1355259418487549e-01
    z[3,7,6]  R1595     -5.2427347749471664e-02
    z[3,7,6]  R1596     2.1352234482765198e-01
    z[3,7,6]  R1597     -1.0542669147253036e-01
    z[3,7,6]  R1598     -1.6958503052592278e-02
    z[3,7,6]  R1599     -4.8897020518779755e-02
    z[7,3,0]  R29       1
    z[7,3,0]  R65       -1
    z[7,3,0]  R1600     -1
    z[7,3,0]  R1601     1
    z[7,3,0]  R1614     0.831761360168457
    z[7,3,0]  R1615     9.2205941677093506e-01
    z[7,3,0]  R1616     8.5395079851150513e-01
    z[7,3,0]  R1617     7.1274155378341675e-01
    z[7,3,0]  R1618     8.4566819667816162e-01
    z[7,3,0]  R1619     6.3203769922256470e-01
    z[7,3,0]  R1620     6.9810485839843750e-01
    z[7,3,0]  R1621     -1.6135847568511963e-01
    z[7,3,0]  R1622     -1.4748410880565643e-01
    z[7,3,0]  R1623     1.5411005914211273e-01
    z[7,3,0]  R1624     -2.0003539323806763e-01
    z[7,3,0]  R1625     -5.4264968633651733e-01
    z[7,3,0]  R1626     -5.2113640308380127e-01
    z[7,3,0]  R1627     -5.5860871076583862e-01
    z[7,3,0]  R1628     -1.8229384720325470e-01
    z[7,3,0]  R1629     -4.6869260072708130e-01
    z[7,3,0]  R1630     -4.7543257474899292e-01
    z[7,3,0]  R1631     -5.8686113357543945e-01
    z[7,3,0]  R1632     -2.1261937916278839e-01
    z[7,3,0]  R1633     -5.0665266811847687e-02
    z[7,3,0]  R1634     -2.2017173469066620e-01
    z[7,3,0]  R1635     -1.0050955414772034e-01
    z[7,3,0]  R1636     -3.8916191458702087e-01
    z[7,3,0]  R1637     3.5358372330665588e-01
    z[7,3,0]  R1638     1.0035784542560577e-01
    z[7,3,0]  R1639     -3.2422360777854919e-01
    z[7,3,0]  R1640     5.0990432500839233e-01
    z[7,3,0]  R1641     7.3181706666946411e-01
    z[7,3,0]  R1642     3.9688837714493275e-03
    z[7,3,0]  R1643     -7.7977222204208374e-01
    z[7,3,0]  R1644     -0.8011514544487
    z[7,3,0]  R1645     -6.4584916830062866e-01
    z[7,3,0]  R1646     -6.4749133586883545e-01
    z[7,3,0]  R1647     -0.866128146648407
    z[7,3,0]  R1648     -5.2334684133529663e-01
    z[7,3,0]  R1649     -9.0055245161056519e-01
    z[7,3,0]  R1650     -5.1530826091766357e-01
    z[7,3,0]  R1651     -4.6573814749717712e-01
    z[7,3,0]  R1652     4.4696500897407532e-01
    z[7,3,0]  R1653     0.421758234500885
    z[7,3,0]  R1654     -0.128040611743927
    z[7,3,0]  R1655     -2.0239213481545448e-02
    z[7,3,0]  R1656     -7.9799783229827881e-01
    z[7,3,0]  R1657     -1.4799687266349792e-01
    z[7,3,0]  R1658     -3.1945714354515076e-01
    z[7,3,0]  R1659     0.718023955821991
    z[7,3,0]  R1660     1.3686415553092957e-01
    z[7,3,0]  R1661     2.3470732569694519e-01
    z[7,3,0]  R1662     1.2830194830894470e-01
    z[7,3,0]  R1663     -2.8881579637527466e-02
    z[7,3,0]  R1664     -1.2167088687419891e-01
    z[7,3,0]  R1665     2.9862058162689209e-01
    z[7,3,0]  R1666     -2.7959802746772766e-01
    z[7,3,0]  R1667     6.2875278294086456e-02
    z[7,3,0]  R1668     -0.276602566242218
    z[7,3,0]  R1669     -7.9921597242355347e-01
    z[7,3,0]  R1670     -1.3351860642433167e-01
    z[7,3,0]  R1671     -0.386550635099411
    z[7,3,0]  R1672     1.8768247961997986e-01
    z[7,3,0]  R1673     0.360411673784256
    z[7,3,0]  R1674     -3.4679239988327026e-01
    z[7,3,0]  R1675     3.1635525822639465e-01
    z[7,3,0]  R1676     2.4061417579650879e-01
    z[7,3,0]  R1677     1.3621720671653748e-01
    z[7,3,0]  R1678     1.2337982654571533e-01
    z[7,3,0]  R1679     -1.5169952809810638e-01
    z[7,3,0]  R1680     2.2870300710201263e-01
    z[7,3,0]  R1681     -1.9770224392414093e-01
    z[7,3,0]  R1682     2.8880143165588379e-01
    z[7,3,0]  R1683     -1.5453328192234039e-01
    z[7,3,0]  R1684     3.8862389326095581e-01
    z[7,3,0]  R1685     3.7091308832168579e-01
    z[7,3,0]  R1686     0.478127658367157
    z[7,3,0]  R1687     4.6311464905738831e-01
    z[7,3,0]  R1688     4.7244840860366821e-01
    z[7,3,0]  R1689     -3.2537445425987244e-01
    z[7,3,0]  R1690     4.7602352499961853e-01
    z[7,3,0]  R1691     2.5705429911613464e-01
    z[7,3,0]  R1692     5.9679847955703735e-01
    z[7,3,0]  R1693     4.8446375131607056e-01
    z[7,3,0]  R1694     -1.4129619300365448e-01
    z[7,3,0]  R1695     -2.4598467350006104e-01
    z[7,3,0]  R1696     -2.2360714152455330e-02
    z[7,3,0]  R1697     4.9472215771675110e-01
    z[7,3,0]  R1698     -2.9698467254638672e-01
    z[7,3,0]  R1699     9.5166578888893127e-02
    z[7,3,0]  R1700     -8.4637673571705818e-03
    z[7,3,0]  R1701     3.5379037261009216e-01
    z[7,3,0]  R1702     -4.9908825755119324e-01
    z[7,3,0]  R1703     2.0909052342176437e-02
    z[7,3,0]  R1704     -1.6441054642200470e-01
    z[7,3,0]  R1705     -4.1640344262123108e-01
    z[7,3,0]  R1706     2.3950491845607758e-01
    z[7,3,0]  R1707     -3.0985912680625916e-01
    z[7,3,0]  R1708     1.3322702050209045e-01
    z[7,3,0]  R1709     2.8159549832344055e-01
    z[7,3,0]  R1710     -5.0860035419464111e-01
    z[7,3,0]  R1711     -2.9777538776397705e-01
    z[7,3,0]  R1712     1.0051559656858444e-01
    z[7,3,0]  R1713     -4.4247376918792725e-01
    z[7,3,0]  R1714     -1.9971807301044464e-01
    z[7,3,0]  R1715     -1.4479297399520874e-01
    z[7,3,0]  R1716     3.1530305743217468e-01
    z[7,3,0]  R1717     -4.0553700923919678e-01
    z[7,3,0]  R1718     2.8023305535316467e-01
    z[7,3,0]  R1719     1.1138470470905304e-01
    z[7,3,0]  R1720     -1.4050295948982239e-01
    z[7,3,0]  R1721     -1.6415895521640778e-01
    z[7,3,0]  R1722     -3.0126294121146202e-02
    z[7,3,0]  R1723     -2.0682542026042938e-01
    z[7,3,1]  R30       1
    z[7,3,1]  R66       -1
    z[7,3,1]  R1602     -1
    z[7,3,1]  R1603     1
    z[7,3,1]  R1614     1.1788117140531540e-01
    z[7,3,1]  R1615     -5.7180680334568024e-02
    z[7,3,1]  R1616     -1.2512235343456268e-01
    z[7,3,1]  R1617     -2.2064872086048126e-01
    z[7,3,1]  R1618     -0.262986958026886
    z[7,3,1]  R1619     -2.0322947204113007e-01
    z[7,3,1]  R1620     1.2710350751876831e-01
    z[7,3,1]  R1621     -6.1658447980880737e-01
    z[7,3,1]  R1622     -5.7900321483612061e-01
    z[7,3,1]  R1623     -6.4628767967224121e-01
    z[7,3,1]  R1624     1.9738541543483734e-01
    z[7,3,1]  R1625     6.6613882780075073e-01
    z[7,3,1]  R1626     7.3474103212356567e-01
    z[7,3,1]  R1627     7.4525296688079834e-02
    z[7,3,1]  R1628     -2.2945592645555735e-03
    z[7,3,1]  R1629     4.4102672487497330e-02
    z[7,3,1]  R1630     5.7743549346923828e-01
    z[7,3,1]  R1631     5.3636454045772552e-02
    z[7,3,1]  R1632     4.0496596693992615e-01
    z[7,3,1]  R1633     6.5669816732406616e-01
    z[7,3,1]  R1634     -6.7782026529312134e-01
    z[7,3,1]  R1635     -8.0523324012756348e-01
    z[7,3,1]  R1636     -5.9223777055740356e-01
    z[7,3,1]  R1637     -7.8164649009704590e-01
    z[7,3,1]  R1638     -7.4711662530899048e-01
    z[7,3,1]  R1639     -6.4996057748794556e-01
    z[7,3,1]  R1640     -0.512759268283844
    z[7,3,1]  R1641     -5.2422821521759033e-01
    z[7,3,1]  R1642     -4.5910209417343140e-01
    z[7,3,1]  R1643     1.1272864043712616e-01
    z[7,3,1]  R1644     -3.4529095888137817e-01
    z[7,3,1]  R1645     7.0104561746120453e-03
    z[7,3,1]  R1646     4.6046581119298935e-03
    z[7,3,1]  R1647     -5.4499473422765732e-02
    z[7,3,1]  R1648     1.7552489042282104e-01
    z[7,3,1]  R1649     -9.6060343086719513e-02
    z[7,3,1]  R1650     7.1108184754848480e-02
    z[7,3,1]  R1651     -4.3063253164291382e-01
    z[7,3,1]  R1652     2.3395034670829773e-01
    z[7,3,1]  R1653     1.2475195527076721e-01
    z[7,3,1]  R1654     -6.4332002401351929e-01
    z[7,3,1]  R1655     8.6006671190261841e-02
    z[7,3,1]  R1656     5.9089845418930054e-01
    z[7,3,1]  R1657     6.4706325531005859e-01
    z[7,3,1]  R1658     0.686769425868988
    z[7,3,1]  R1659     2.7850097417831421e-01
    z[7,3,1]  R1660     9.1011798381805420e-01
    z[7,3,1]  R1661     8.5468226671218872e-01
    z[7,3,1]  R1662     9.0942496061325073e-01
    z[7,3,1]  R1663     7.3431169986724854e-01
    z[7,3,1]  R1664     -7.3055410385131836e-01
    z[7,3,1]  R1665     -6.7307293415069580e-01
    z[7,3,1]  R1666     -7.0669221878051758e-01
    z[7,3,1]  R1667     -6.1387270689010620e-01
    z[7,3,1]  R1668     9.0618662536144257e-02
    z[7,3,1]  R1669     5.9256780147552490e-01
    z[7,3,1]  R1670     6.7437773942947388e-01
    z[7,3,1]  R1671     7.3519986867904663e-01
    z[7,3,1]  R1672     5.2971726655960083e-01
    z[7,3,1]  R1673     4.3057283759117126e-01
    z[7,3,1]  R1674     -5.2148234844207764e-01
    z[7,3,1]  R1675     8.3416923880577087e-02
    z[7,3,1]  R1676     -5.1724594831466675e-01
    z[7,3,1]  R1677     0.436928391456604
    z[7,3,1]  R1678     0.481802374124527
    z[7,3,1]  R1679     -4.2934402823448181e-01
    z[7,3,1]  R1680     4.3029200285673141e-02
    z[7,3,1]  R1681     -3.1166023015975952e-01
    z[7,3,1]  R1682     -9.3946449458599091e-02
    z[7,3,1]  R1683     2.3569411039352417e-01
    z[7,3,1]  R1684     -3.9549741148948669e-01
    z[7,3,1]  R1685     -3.2833805680274963e-01
    z[7,3,1]  R1686     -4.0744832158088684e-01
    z[7,3,1]  R1687     -7.6940737664699554e-02
    z[7,3,1]  R1688     -1.4032201468944550e-01
    z[7,3,1]  R1689     -2.6081937551498413e-01
    z[7,3,1]  R1690     -4.7939816117286682e-01
    z[7,3,1]  R1691     -5.7229530811309814e-01
    z[7,3,1]  R1692     -1.1862655729055405e-01
    z[7,3,1]  R1693     -2.3100028932094574e-01
    z[7,3,1]  R1694     -3.8691377639770508e-01
    z[7,3,1]  R1695     -1.3536162674427032e-01
    z[7,3,1]  R1696     -8.1442302465438843e-01
    z[7,3,1]  R1697     2.1609127521514893e-01
    z[7,3,1]  R1698     -8.0153423547744751e-01
    z[7,3,1]  R1699     -7.2501242160797119e-01
    z[7,3,1]  R1700     -9.2812252044677734e-01
    z[7,3,1]  R1701     5.6346774101257324e-01
    z[7,3,1]  R1702     0.726138710975647
    z[7,3,1]  R1703     -0.0324397049844265
    z[7,3,1]  R1704     -3.2403391599655151e-01
    z[7,3,1]  R1705     -4.0914842486381531e-01
    z[7,3,1]  R1706     -5.8479070663452148e-01
    z[7,3,1]  R1707     -6.0351520776748657e-01
    z[7,3,1]  R1708     1.4922253787517548e-01
    z[7,3,1]  R1709     5.9933638572692871e-01
    z[7,3,1]  R1710     4.6213066577911377e-01
    z[7,3,1]  R1711     0.813393771648407
    z[7,3,1]  R1712     4.7956377267837524e-01
    z[7,3,1]  R1713     6.3635557889938354e-01
    z[7,3,1]  R1714     -3.5282588005065918e-01
    z[7,3,1]  R1715     -5.1891523599624634e-01
    z[7,3,1]  R1716     -7.3771619796752930e-01
    z[7,3,1]  R1717     -6.7508661746978760e-01
    z[7,3,1]  R1718     3.8875925540924072e-01
    z[7,3,1]  R1719     5.7495909929275513e-01
    z[7,3,1]  R1720     5.7786947488784790e-01
    z[7,3,1]  R1721     8.9735507965087891e-01
    z[7,3,1]  R1722     4.3170607089996338e-01
    z[7,3,1]  R1723     7.3682177066802979e-01
    z[7,3,2]  R31       1
    z[7,3,2]  R67       -1
    z[7,3,2]  R1604     -1
    z[7,3,2]  R1605     1
    z[7,3,2]  R1614     1.5736088156700134e-01
    z[7,3,2]  R1615     3.1619224697351456e-02
    z[7,3,2]  R1616     -2.8328439593315125e-01
    z[7,3,2]  R1617     1.6663897037506104e-01
    z[7,3,2]  R1618     4.3664994835853577e-01
    z[7,3,2]  R1619     3.6473900079727173e-01
    z[7,3,2]  R1620     9.3046009540557861e-02
    z[7,3,2]  R1621     2.6254189014434814e-01
    z[7,3,2]  R1622     0.255932092666626
    z[7,3,2]  R1623     3.0451336503028870e-01
    z[7,3,2]  R1624     -7.3511481285095215e-01
    z[7,3,2]  R1625     -3.7339490652084351e-01
    z[7,3,2]  R1626     -2.5605386495590210e-01
    z[7,3,2]  R1627     -3.1785136461257935e-01
    z[7,3,2]  R1628     -8.7365549802780151e-01
    z[7,3,2]  R1629     -6.0707551240921021e-01
    z[7,3,2]  R1630     -3.5549452900886536e-01
    z[7,3,2]  R1631     -0.730562686920166
    z[7,3,2]  R1632     -7.2983330488204956e-01
    z[7,3,2]  R1633     -5.8316880464553833e-01
    z[7,3,2]  R1634     -5.9866684675216675e-01
    z[7,3,2]  R1635     -3.0322751402854919e-01
    z[7,3,2]  R1636     -2.2276845574378967e-01
    z[7,3,2]  R1637     -8.7085880339145660e-02
    z[7,3,2]  R1638     -1.8152470886707306e-01
    z[7,3,2]  R1639     -2.1618537604808807e-01
    z[7,3,2]  R1640     -4.0154952555894852e-02
    z[7,3,2]  R1641     1.2722371518611908e-01
    z[7,3,2]  R1642     7.7772176265716553e-01
    z[7,3,2]  R1643     -2.9540473222732544e-01
    z[7,3,2]  R1644     3.6096596717834473e-01
    z[7,3,2]  R1645     -3.6073359847068787e-01
    z[7,3,2]  R1646     -0.50264972448349
    z[7,3,2]  R1647     -1.4566515386104584e-01
    z[7,3,2]  R1648     -5.9669876098632812e-01
    z[7,3,2]  R1649     -4.2036834359169006e-01
    z[7,3,2]  R1650     -0.81169593334198
    z[7,3,2]  R1651     -8.8499732315540314e-02
    z[7,3,2]  R1652     5.6356781721115112e-01
    z[7,3,2]  R1653     6.6970270872116089e-01
    z[7,3,2]  R1654     2.8186139464378357e-01
    z[7,3,2]  R1655     -0.647044837474823
    z[7,3,2]  R1656     -7.7119171619415283e-02
    z[7,3,2]  R1657     -5.6557118892669678e-01
    z[7,3,2]  R1658     -4.3069493770599365e-01
    z[7,3,2]  R1659     4.9036827683448792e-01
    z[7,3,2]  R1660     6.6082730889320374e-02
    z[7,3,2]  R1661     1.8462300300598145e-01
    z[7,3,2]  R1662     -1.1157387867569923e-02
    z[7,3,2]  R1663     -5.1228034496307373e-01
    z[7,3,2]  R1664     2.6303809881210327e-01
    z[7,3,2]  R1665     5.2225303649902344e-01
    z[7,3,2]  R1666     1.6468265652656555e-01
    z[7,3,2]  R1667     -3.2448098063468933e-01
    z[7,3,2]  R1668     -0.89305579662323
    z[7,3,2]  R1669     -5.2912008017301559e-02
    z[7,3,2]  R1670     -6.0445809364318848e-01
    z[7,3,2]  R1671     -3.9572045207023621e-01
    z[7,3,2]  R1672     5.8833497762680054e-01
    z[7,3,2]  R1673     6.8056142330169678e-01
    z[7,3,2]  R1674     1.5335462987422943e-01
    z[7,3,2]  R1675     -6.0049909353256226e-01
    z[7,3,2]  R1676     5.4962551593780518e-01
    z[7,3,2]  R1677     -3.2779499888420105e-01
    z[7,3,2]  R1678     -3.8564798235893250e-01
    z[7,3,2]  R1679     -4.9620741046965122e-03
    z[7,3,2]  R1680     -4.8943346738815308e-01
    z[7,3,2]  R1681     1.8296520411968231e-01
    z[7,3,2]  R1682     -4.2893221974372864e-01
    z[7,3,2]  R1683     -2.5571811944246292e-02
    z[7,3,2]  R1684     3.3236268162727356e-01
    z[7,3,2]  R1685     4.7776794433593750e-01
    z[7,3,2]  R1686     5.4234284162521362e-01
    z[7,3,2]  R1687     3.3731272816658020e-01
    z[7,3,2]  R1688     6.2042981386184692e-01
    z[7,3,2]  R1689     -4.3763765692710876e-01
    z[7,3,2]  R1690     2.6428681612014771e-01
    z[7,3,2]  R1691     1.4328658580780029e-03
    z[7,3,2]  R1692     3.2177260518074036e-01
    z[7,3,2]  R1693     1.7702539265155792e-01
    z[7,3,2]  R1694     -7.1257036924362183e-01
    z[7,3,2]  R1695     -5.8643120527267456e-01
    z[7,3,2]  R1696     -1.3432666659355164e-01
    z[7,3,2]  R1697     4.8286509513854980e-01
    z[7,3,2]  R1698     -4.7755271196365356e-01
    z[7,3,2]  R1699     -2.8411459922790527e-01
    z[7,3,2]  R1700     -1.3416558504104614e-01
    z[7,3,2]  R1701     7.0129656791687012e-01
    z[7,3,2]  R1702     -3.3579519391059875e-01
    z[7,3,2]  R1703     1.0880029201507568e-01
    z[7,3,2]  R1704     -0.604345440864563
    z[7,3,2]  R1705     -2.9558802023530006e-02
    z[7,3,2]  R1706     1.1722157150506973e-01
    z[7,3,2]  R1707     3.9034938812255859e-01
    z[7,3,2]  R1708     4.1221952438354492e-01
    z[7,3,2]  R1709     -1.5346366167068481e-01
    z[7,3,2]  R1710     -6.5238827466964722e-01
    z[7,3,2]  R1711     -4.8277732729911804e-01
    z[7,3,2]  R1712     6.8101976066827774e-03
    z[7,3,2]  R1713     -5.9404021501541138e-01
    z[7,3,2]  R1714     -3.6452940106391907e-01
    z[7,3,2]  R1715     -2.5705328583717346e-01
    z[7,3,2]  R1716     -5.0469189882278442e-03
    z[7,3,2]  R1717     1.0578592121601105e-01
    z[7,3,2]  R1718     6.2631016969680786e-01
    z[7,3,2]  R1719     -2.6241201162338257e-01
    z[7,3,2]  R1720     -9.8471298813819885e-02
    z[7,3,2]  R1721     -3.2202121615409851e-01
    z[7,3,2]  R1722     -2.2024551033973694e-01
    z[7,3,2]  R1723     -3.5296049714088440e-01
    z[7,3,3]  R32       1
    z[7,3,3]  R68       -1
    z[7,3,3]  R1606     -1
    z[7,3,3]  R1607     1
    z[7,3,3]  R1614     -0.504252552986145
    z[7,3,3]  R1615     -2.4172352254390717e-01
    z[7,3,3]  R1616     -3.7082454562187195e-01
    z[7,3,3]  R1617     -4.2431572079658508e-01
    z[7,3,3]  R1618     -1.4273391105234623e-02
    z[7,3,3]  R1619     -4.8467060923576355e-01
    z[7,3,3]  R1620     -2.1092857420444489e-01
    z[7,3,3]  R1621     -1.8700738251209259e-01
    z[7,3,3]  R1622     5.6740206480026245e-01
    z[7,3,3]  R1623     -1.0911568999290466e-01
    z[7,3,3]  R1624     -4.2100772261619568e-02
    z[7,3,3]  R1625     -2.1732452511787415e-01
    z[7,3,3]  R1626     -0.109881691634655
    z[7,3,3]  R1627     -1.2937353551387787e-01
    z[7,3,3]  R1628     -1.6076089814305305e-02
    z[7,3,3]  R1629     5.3015798330307007e-02
    z[7,3,3]  R1630     -4.6307405829429626e-01
    z[7,3,3]  R1631     -1.3483323156833649e-02
    z[7,3,3]  R1632     1.8107822537422180e-01
    z[7,3,3]  R1633     -1.2303494662046432e-01
    z[7,3,3]  R1634     1.1183109134435654e-01
    z[7,3,3]  R1635     4.8025703430175781e-01
    z[7,3,3]  R1636     -4.1683989763259888e-01
    z[7,3,3]  R1637     2.5238654017448425e-01
    z[7,3,3]  R1638     1.8978676199913025e-01
    z[7,3,3]  R1639     -3.0419981479644775e-01
    z[7,3,3]  R1640     5.2527725696563721e-01
    z[7,3,3]  R1641     2.6501783728599548e-01
    z[7,3,3]  R1642     2.3504644632339478e-01
    z[7,3,3]  R1643     -3.0951502267271280e-03
    z[7,3,3]  R1644     -1.0267569869756699e-01
    z[7,3,3]  R1645     -9.5114611089229584e-02
    z[7,3,3]  R1646     -3.6320930719375610e-01
    z[7,3,3]  R1647     -3.2691818475723267e-01
    z[7,3,3]  R1648     1.5387211740016937e-01
    z[7,3,3]  R1649     1.2792519293725491e-02
    z[7,3,3]  R1650     9.7040623426437378e-02
    z[7,3,3]  R1651     -4.2647728323936462e-01
    z[7,3,3]  R1652     9.0673323720693588e-03
    z[7,3,3]  R1653     -3.9340332150459290e-01
    z[7,3,3]  R1654     3.7332630157470703e-01
    z[7,3,3]  R1655     -4.8981118947267532e-02
    z[7,3,3]  R1656     4.3991249054670334e-02
    z[7,3,3]  R1657     -1.4338363707065582e-01
    z[7,3,3]  R1658     -1.6163422167301178e-01
    z[7,3,3]  R1659     -2.2544270753860474e-01
    z[7,3,3]  R1660     -3.7036520242691040e-01
    z[7,3,3]  R1661     -3.8125243782997131e-01
    z[7,3,3]  R1662     -3.3912095427513123e-01
    z[7,3,3]  R1663     1.9066568464040756e-02
    z[7,3,3]  R1664     3.4886658191680908e-01
    z[7,3,3]  R1665     9.6905358135700226e-02
    z[7,3,3]  R1666     4.7653075307607651e-02
    z[7,3,3]  R1667     1.5867911279201508e-01
    z[7,3,3]  R1668     -4.2687293142080307e-02
    z[7,3,3]  R1669     -9.7977332770824432e-03
    z[7,3,3]  R1670     -6.8670073524117470e-03
    z[7,3,3]  R1671     -2.0256450772285461e-01
    z[7,3,3]  R1672     -5.2521169185638428e-01
    z[7,3,3]  R1673     -3.5196962952613831e-01
    z[7,3,3]  R1674     1.3980150222778320e-01
    z[7,3,3]  R1675     -4.8543652892112732e-01
    z[7,3,3]  R1676     0.349149614572525
    z[7,3,3]  R1677     -7.0498067140579224e-01
    z[7,3,3]  R1678     -6.4381921291351318e-01
    z[7,3,3]  R1679     2.5701728463172913e-01
    z[7,3,3]  R1680     -5.4006010293960571e-01
    z[7,3,3]  R1681     -0.0647614598274231
    z[7,3,3]  R1682     -1.8884766101837158e-01
    z[7,3,3]  R1683     -4.9562579393386841e-01
    z[7,3,3]  R1684     -7.6045602560043335e-01
    z[7,3,3]  R1685     -6.8463677167892456e-01
    z[7,3,3]  R1686     -3.7467747926712036e-01
    z[7,3,3]  R1687     -7.0945578813552856e-01
    z[7,3,3]  R1688     -4.7919160127639771e-01
    z[7,3,3]  R1689     -6.2790863215923309e-02
    z[7,3,3]  R1690     -5.4137378931045532e-01
    z[7,3,3]  R1691     -6.1908680200576782e-01
    z[7,3,3]  R1692     -5.0925046205520630e-01
    z[7,3,3]  R1693     -5.1862555742263794e-01
    z[7,3,3]  R1694     0.0450817309319973
    z[7,3,3]  R1695     -6.1120027303695679e-01
    z[7,3,3]  R1696     1.4381159842014313e-01
    z[7,3,3]  R1697     -4.9036917090415955e-01
    z[7,3,3]  R1698     -3.7112716585397720e-02
    z[7,3,3]  R1699     1.6053833067417145e-01
    z[7,3,3]  R1700     -2.5952902436256409e-01
    z[7,3,3]  R1701     -1.0738559067249298e-03
    z[7,3,3]  R1702     3.0714073777198792e-01
    z[7,3,3]  R1703     8.6557984352111816e-01
    z[7,3,3]  R1704     -4.5465391874313354e-01
    z[7,3,3]  R1705     -4.8944808542728424e-02
    z[7,3,3]  R1706     3.8044983148574829e-01
    z[7,3,3]  R1707     -2.1053658425807953e-01
    z[7,3,3]  R1708     8.1655263900756836e-01
    z[7,3,3]  R1709     -5.5685347318649292e-01
    z[7,3,3]  R1710     3.0859303474426270e-01
    z[7,3,3]  R1711     -6.4833253622055054e-02
    z[7,3,3]  R1712     6.2604665756225586e-01
    z[7,3,3]  R1713     1.9388185441493988e-01
    z[7,3,3]  R1714     -3.7968146800994873e-01
    z[7,3,3]  R1715     7.0764243602752686e-01
    z[7,3,3]  R1716     -2.8273233771324158e-01
    z[7,3,3]  R1717     7.9361535608768463e-02
    z[7,3,3]  R1718     -4.0932792425155640e-01
    z[7,3,3]  R1719     -6.0328519344329834e-01
    z[7,3,3]  R1720     7.1337640285491943e-01
    z[7,3,3]  R1721     1.6910864412784576e-01
    z[7,3,3]  R1722     6.6688686609268188e-01
    z[7,3,3]  R1723     8.0330856144428253e-02
    z[7,3,4]  R33       1
    z[7,3,4]  R69       -1
    z[7,3,4]  R1608     -1
    z[7,3,4]  R1609     1
    z[7,3,4]  R1614     -9.3567736446857452e-02
    z[7,3,4]  R1615     -4.1627362370491028e-03
    z[7,3,4]  R1616     -1.7485836520791054e-02
    z[7,3,4]  R1617     -3.9552173018455505e-01
    z[7,3,4]  R1618     -5.4580219089984894e-02
    z[7,3,4]  R1619     4.1839987039566040e-01
    z[7,3,4]  R1620     5.4671669006347656e-01
    z[7,3,4]  R1621     -4.9099615216255188e-01
    z[7,3,4]  R1622     1.4081904292106628e-01
    z[7,3,4]  R1623     1.8393313884735107e-01
    z[7,3,4]  R1624     -1.8558960407972336e-02
    z[7,3,4]  R1625     2.4832665920257568e-01
    z[7,3,4]  R1626     -2.2210772335529327e-01
    z[7,3,4]  R1627     6.6949248313903809e-01
    z[7,3,4]  R1628     3.9261576533317566e-01
    z[7,3,4]  R1629     6.2186169624328613e-01
    z[7,3,4]  R1630     1.2779118493199348e-02
    z[7,3,4]  R1631     -1.0554113984107971e-01
    z[7,3,4]  R1632     -3.8992649316787720e-01
    z[7,3,4]  R1633     -1.0634469240903854e-01
    z[7,3,4]  R1634     3.4463945031166077e-01
    z[7,3,4]  R1635     3.5495623946189880e-02
    z[7,3,4]  R1636     4.9213263392448425e-01
    z[7,3,4]  R1637     3.8332742452621460e-01
    z[7,3,4]  R1638     2.8598508238792419e-01
    z[7,3,4]  R1639     -1.3394100964069366e-01
    z[7,3,4]  R1640     -4.4146808981895447e-01
    z[7,3,4]  R1641     -2.3624691367149353e-01
    z[7,3,4]  R1642     -2.4334377050399780e-01
    z[7,3,4]  R1643     -4.7691500186920166e-01
    z[7,3,4]  R1644     2.7066943049430847e-01
    z[7,3,4]  R1645     5.8024022728204727e-02
    z[7,3,4]  R1646     -0.0924634113907814
    z[7,3,4]  R1647     1.2324440479278564e-01
    z[7,3,4]  R1648     1.5061776340007782e-01
    z[7,3,4]  R1649     -9.0359859168529510e-03
    z[7,3,4]  R1650     2.4451713263988495e-01
    z[7,3,4]  R1651     4.0662929415702820e-01
    z[7,3,4]  R1652     4.1545665264129639e-01
    z[7,3,4]  R1653     2.5468489527702332e-01
    z[7,3,4]  R1654     -4.1382867097854614e-01
    z[7,3,4]  R1655     -5.0561362504959106e-01
    z[7,3,4]  R1656     -3.6079576238989830e-03
    z[7,3,4]  R1657     -2.3232956230640411e-01
    z[7,3,4]  R1658     -2.8039303421974182e-01
    z[7,3,4]  R1659     -1.9280940294265747e-02
    z[7,3,4]  R1660     6.0891743749380112e-02
    z[7,3,4]  R1661     -3.9529930800199509e-02
    z[7,3,4]  R1662     -1.9411031901836395e-01
    z[7,3,4]  R1663     -4.1277384757995605e-01
    z[7,3,4]  R1664     -0.163431316614151
    z[7,3,4]  R1665     -1.5994679182767868e-02
    z[7,3,4]  R1666     -3.1727802753448486e-01
    z[7,3,4]  R1667     -1.9960127770900726e-01
    z[7,3,4]  R1668     -1.3360002636909485e-01
    z[7,3,4]  R1669     -5.7889252901077271e-02
    z[7,3,4]  R1670     -2.9758140444755554e-01
    z[7,3,4]  R1671     -1.0412189364433289e-01
    z[7,3,4]  R1672     2.4219968914985657e-01
    z[7,3,4]  R1673     2.4200481176376343e-01
    z[7,3,4]  R1674     -4.8401427268981934e-01
    z[7,3,4]  R1675     4.6343751251697540e-02
    z[7,3,4]  R1676     5.4460112005472183e-02
    z[7,3,4]  R1677     -3.2666212320327759e-01
    z[7,3,4]  R1678     1.3809368014335632e-01
    z[7,3,4]  R1679     6.6078805923461914e-01
    z[7,3,4]  R1680     -3.1959589570760727e-02
    z[7,3,4]  R1681     4.6754062175750732e-01
    z[7,3,4]  R1682     -3.1381070613861084e-01
    z[7,3,4]  R1683     -6.2581133842468262e-01
    z[7,3,4]  R1684     -1.9610758870840073e-02
    z[7,3,4]  R1685     -4.9195587635040283e-02
    z[7,3,4]  R1686     2.2888121008872986e-01
    z[7,3,4]  R1687     1.2012667208909988e-01
    z[7,3,4]  R1688     -3.0425125360488892e-01
    z[7,3,4]  R1689     -7.9097676277160645e-01
    z[7,3,4]  R1690     2.3311580717563629e-01
    z[7,3,4]  R1691     -1.8523296713829041e-01
    z[7,3,4]  R1692     2.3390786349773407e-01
    z[7,3,4]  R1693     5.2037900686264038e-01
    z[7,3,4]  R1694     -2.6308125257492065e-01
    z[7,3,4]  R1695     4.4833451509475708e-01
    z[7,3,4]  R1696     -2.2582834959030151e-01
    z[7,3,4]  R1697     4.2494514584541321e-01
    z[7,3,4]  R1698     2.3748284205794334e-02
    z[7,3,4]  R1699     -5.7107824832201004e-02
    z[7,3,4]  R1700     1.9484585523605347e-01
    z[7,3,4]  R1701     4.0376982651650906e-03
    z[7,3,4]  R1702     1.2568618357181549e-01
    z[7,3,4]  R1703     -3.9516729116439819e-01
    z[7,3,4]  R1704     -4.3289104104042053e-01
    z[7,3,4]  R1705     1.7633788287639618e-01
    z[7,3,4]  R1706     -3.3293321728706360e-02
    z[7,3,4]  R1707     3.1441393494606018e-01
    z[7,3,4]  R1708     2.5045558810234070e-01
    z[7,3,4]  R1709     1.5220838785171509e-01
    z[7,3,4]  R1710     3.3705178648233414e-02
    z[7,3,4]  R1711     -8.6671836674213409e-02
    z[7,3,4]  R1712     5.3131759166717529e-01
    z[7,3,4]  R1713     -2.8040159493684769e-02
    z[7,3,4]  R1714     -1.8048363924026489e-01
    z[7,3,4]  R1715     2.8188863396644592e-01
    z[7,3,4]  R1716     -0.0724576786160469
    z[7,3,4]  R1717     2.1844211220741272e-01
    z[7,3,4]  R1718     -1.2153670191764832e-01
    z[7,3,4]  R1719     -1.3801916502416134e-02
    z[7,3,4]  R1720     2.5893816351890564e-01
    z[7,3,4]  R1721     4.8382304608821869e-02
    z[7,3,4]  R1722     -2.3363950848579407e-01
    z[7,3,4]  R1723     -4.4344505667686462e-01
    z[7,3,5]  R34       1
    z[7,3,5]  R70       -1
    z[7,3,5]  R1610     -1
    z[7,3,5]  R1611     1
    z[7,3,5]  R1614     4.2699400335550308e-02
    z[7,3,5]  R1615     -1.3356618583202362e-01
    z[7,3,5]  R1616     -3.2809235155582428e-02
    z[7,3,5]  R1617     5.3201489150524139e-02
    z[7,3,5]  R1618     -1.0581449419260025e-01
    z[7,3,5]  R1619     0.0456363819539547
    z[7,3,5]  R1620     -1.0163668543100357e-01
    z[7,3,5]  R1621     -3.2858392596244812e-01
    z[7,3,5]  R1622     2.8948080539703369e-01
    z[7,3,5]  R1623     2.4532085657119751e-01
    z[7,3,5]  R1624     -5.8020043373107910e-01
    z[7,3,5]  R1625     5.5503454059362411e-02
    z[7,3,5]  R1626     1.2265937775373459e-01
    z[7,3,5]  R1627     -2.0580182969570160e-01
    z[7,3,5]  R1628     -0.162678524851799
    z[7,3,5]  R1629     1.8457837402820587e-02
    z[7,3,5]  R1630     -1.9807896018028259e-01
    z[7,3,5]  R1631     -8.4291743114590645e-03
    z[7,3,5]  R1632     2.5627663731575012e-01
    z[7,3,5]  R1633     3.3952635526657104e-01
    z[7,3,5]  R1634     3.5490646958351135e-02
    z[7,3,5]  R1635     -9.9709741771221161e-02
    z[7,3,5]  R1636     -1.2336204200983047e-01
    z[7,3,5]  R1637     -0.200625479221344
    z[7,3,5]  R1638     -5.1801913976669312e-01
    z[7,3,5]  R1639     5.2026188373565674e-01
    z[7,3,5]  R1640     -3.2877799123525620e-02
    z[7,3,5]  R1641     -1.8231348693370819e-01
    z[7,3,5]  R1642     1.1712416261434555e-01
    z[7,3,5]  R1643     -1.7633208632469177e-01
    z[7,3,5]  R1644     1.3752581179141998e-01
    z[7,3,5]  R1645     -5.5856925249099731e-01
    z[7,3,5]  R1646     -2.0876045525074005e-01
    z[7,3,5]  R1647     -0.320121705532074
    z[7,3,5]  R1648     -2.7869519591331482e-01
    z[7,3,5]  R1649     1.1142909526824951e-02
    z[7,3,5]  R1650     -6.2896623276174068e-03
    z[7,3,5]  R1651     -2.5724676251411438e-01
    z[7,3,5]  R1652     5.0354021787643433e-01
    z[7,3,5]  R1653     -3.6257150769233704e-01
    z[7,3,5]  R1654     3.9444151520729065e-01
    z[7,3,5]  R1655     -5.5814504623413086e-01
    z[7,3,5]  R1656     5.5932231247425079e-02
    z[7,3,5]  R1657     -1.4626109972596169e-02
    z[7,3,5]  R1658     3.1677356362342834e-01
    z[7,3,5]  R1659     1.9272281229496002e-01
    z[7,3,5]  R1660     2.3736661300063133e-02
    z[7,3,5]  R1661     -1.2253225594758987e-01
    z[7,3,5]  R1662     5.9116680175065994e-02
    z[7,3,5]  R1663     -3.1366065144538879e-02
    z[7,3,5]  R1664     4.3536716699600220e-01
    z[7,3,5]  R1665     -3.9726775884628296e-01
    z[7,3,5]  R1666     2.3148950934410095e-01
    z[7,3,5]  R1667     -3.2445770502090454e-01
    z[7,3,5]  R1668     -2.2903005778789520e-01
    z[7,3,5]  R1669     3.3493004739284515e-02
    z[7,3,5]  R1670     -1.6680642962455750e-01
    z[7,3,5]  R1671     3.0079308152198792e-01
    z[7,3,5]  R1672     -5.6932557374238968e-02
    z[7,3,5]  R1673     1.9158987700939178e-01
    z[7,3,5]  R1674     -3.7373277544975281e-01
    z[7,3,5]  R1675     -2.8061193227767944e-01
    z[7,3,5]  R1676     -2.6671119034290314e-02
    z[7,3,5]  R1677     -1.1959427595138550e-01
    z[7,3,5]  R1678     -3.1937101483345032e-01
    z[7,3,5]  R1679     -3.6324670910835266e-01
    z[7,3,5]  R1680     -8.2112692296504974e-02
    z[7,3,5]  R1681     -6.9876688718795776e-01
    z[7,3,5]  R1682     -0.394333153963089
    z[7,3,5]  R1683     -4.3859738111495972e-01
    z[7,3,5]  R1684     3.3692322671413422e-02
    z[7,3,5]  R1685     -1.6348755359649658e-01
    z[7,3,5]  R1686     -2.0855288952589035e-02
    z[7,3,5]  R1687     2.0821157097816467e-01
    z[7,3,5]  R1688     -0.0433766171336174
    z[7,3,5]  R1689     -5.6146692484617233e-02
    z[7,3,5]  R1690     2.7365830540657043e-01
    z[7,3,5]  R1691     2.2968876361846924e-01
    z[7,3,5]  R1692     4.4170853495597839e-01
    z[7,3,5]  R1693     3.6483103036880493e-01
    z[7,3,5]  R1694     -4.5089519023895264e-01
    z[7,3,5]  R1695     -2.5357827544212341e-02
    z[7,3,5]  R1696     1.5495795011520386e-01
    z[7,3,5]  R1697     8.0810030922293663e-03
    z[7,3,5]  R1698     0.0723768025636673
    z[7,3,5]  R1699     5.9614843130111694e-01
    z[7,3,5]  R1700     5.4889399558305740e-02
    z[7,3,5]  R1701     -0.197321817278862
    z[7,3,5]  R1702     2.7102181687951088e-02
    z[7,3,5]  R1703     2.8337183594703674e-01
    z[7,3,5]  R1704     0.256511926651001
    z[7,3,5]  R1705     -6.9606119394302368e-01
    z[7,3,5]  R1706     3.4793254733085632e-01
    z[7,3,5]  R1707     4.8544409871101379e-01
    z[7,3,5]  R1708     -6.2928862869739532e-02
    z[7,3,5]  R1709     4.3521293997764587e-01
    z[7,3,5]  R1710     -2.1326787769794464e-02
    z[7,3,5]  R1711     1.4439002610743046e-02
    z[7,3,5]  R1712     2.5736328959465027e-01
    z[7,3,5]  R1713     -3.0850782990455627e-02
    z[7,3,5]  R1714     -7.2390139102935791e-01
    z[7,3,5]  R1715     2.4870058894157410e-01
    z[7,3,5]  R1716     5.1580244302749634e-01
    z[7,3,5]  R1717     0.545786440372467
    z[7,3,5]  R1718     -3.3381292223930359e-01
    z[7,3,5]  R1719     2.2834406793117523e-01
    z[7,3,5]  R1720     1.4479791745543480e-02
    z[7,3,5]  R1721     1.4484675228595734e-01
    z[7,3,5]  R1722     5.0283408164978027e-01
    z[7,3,5]  R1723     1.9192793965339661e-01
    z[7,3,6]  R35       1
    z[7,3,6]  R71       -1
    z[7,3,6]  R1612     -1
    z[7,3,6]  R1613     1
    z[7,3,6]  R1614     -6.8305768072605133e-02
    z[7,3,6]  R1615     -2.6315292716026306e-01
    z[7,3,6]  R1616     1.8965634703636169e-01
    z[7,3,6]  R1617     2.7610439062118530e-01
    z[7,3,6]  R1618     1.0315315425395966e-01
    z[7,3,6]  R1619     1.1893185228109360e-01
    z[7,3,6]  R1620     3.6621958017349243e-01
    z[7,3,6]  R1621     -3.7528967857360840e-01
    z[7,3,6]  R1622     3.8977968692779541e-01
    z[7,3,6]  R1623     -5.9992820024490356e-01
    z[7,3,6]  R1624     2.0464979112148285e-01
    z[7,3,6]  R1625     1.0193166881799698e-01
    z[7,3,6]  R1626     -2.1577247977256775e-01
    z[7,3,6]  R1627     2.7214100956916809e-01
    z[7,3,6]  R1628     -1.5039950609207153e-01
    z[7,3,6]  R1629     1.4134421944618225e-01
    z[7,3,6]  R1630     -2.4560080468654633e-01
    z[7,3,6]  R1631     -3.2802972197532654e-01
    z[7,3,6]  R1632     -8.7344385683536530e-02
    z[7,3,6]  R1633     -2.9046475887298584e-01
    z[7,3,6]  R1634     -3.3763226121664047e-02
    z[7,3,6]  R1635     8.7758764624595642e-02
    z[7,3,6]  R1636     1.3043515384197235e-01
    z[7,3,6]  R1637     -7.4390277266502380e-02
    z[7,3,6]  R1638     1.1244340986013412e-01
    z[7,3,6]  R1639     2.1105460822582245e-01
    z[7,3,6]  R1640     5.9766110032796860e-02
    z[7,3,6]  R1641     -1.1898516118526459e-01
    z[7,3,6]  R1642     2.3701743781566620e-01
    z[7,3,6]  R1643     1.8284708261489868e-01
    z[7,3,6]  R1644     7.6919443905353546e-02
    z[7,3,6]  R1645     3.5817271471023560e-01
    z[7,3,6]  R1646     -3.7950697541236877e-01
    z[7,3,6]  R1647     3.3026900142431259e-02
    z[7,3,6]  R1648     4.6391418576240540e-01
    z[7,3,6]  R1649     5.1949676126241684e-02
    z[7,3,6]  R1650     3.6134470254182816e-02
    z[7,3,6]  R1651     -4.2000627517700195e-01
    z[7,3,6]  R1652     4.0516536682844162e-02
    z[7,3,6]  R1653     8.3466731011867523e-02
    z[7,3,6]  R1654     -1.5520407259464264e-01
    z[7,3,6]  R1655     -0.0628967210650444
    z[7,3,6]  R1656     -5.4903768002986908e-02
    z[7,3,6]  R1657     -4.0593791007995605e-01
    z[7,3,6]  R1658     -1.8895855545997620e-01
    z[7,3,6]  R1659     -2.7942699193954468e-01
    z[7,3,6]  R1660     8.4527529776096344e-02
    z[7,3,6]  R1661     1.3570147752761841e-01
    z[7,3,6]  R1662     -1.3549934141337872e-02
    z[7,3,6]  R1663     1.6059705615043640e-01
    z[7,3,6]  R1664     -2.1056039631366730e-01
    z[7,3,6]  R1665     1.3259758055210114e-01
    z[7,3,6]  R1666     -4.8863810300827026e-01
    z[7,3,6]  R1667     -5.8619666099548340e-01
    z[7,3,6]  R1668     -2.1355259418487549e-01
    z[7,3,6]  R1669     -5.2427347749471664e-02
    z[7,3,6]  R1670     2.1352234482765198e-01
    z[7,3,6]  R1671     -1.0542669147253036e-01
    z[7,3,6]  R1672     -1.6958503052592278e-02
    z[7,3,6]  R1673     -4.8897020518779755e-02
    z[7,3,6]  R1674     -4.3678706884384155e-01
    z[7,3,6]  R1675     -4.6456691622734070e-01
    z[7,3,6]  R1676     -4.9688091874122620e-01
    z[7,3,6]  R1677     -2.5510832667350769e-01
    z[7,3,6]  R1678     -2.6143577694892883e-01
    z[7,3,6]  R1679     3.9746630191802979e-01
    z[7,3,6]  R1680     6.3786321878433228e-01
    z[7,3,6]  R1681     3.4531423449516296e-01
    z[7,3,6]  R1682     0.658897340297699
    z[7,3,6]  R1683     -3.0043545365333557e-01
    z[7,3,6]  R1684     4.7700032591819763e-02
    z[7,3,6]  R1685     1.6875910758972168e-01
    z[7,3,6]  R1686     3.4356853365898132e-01
    z[7,3,6]  R1687     -3.2359704375267029e-01
    z[7,3,6]  R1688     2.1930399537086487e-01
    z[7,3,6]  R1689     -4.2879793792963028e-02
    z[7,3,6]  R1690     2.2674646973609924e-01
    z[7,3,6]  R1691     3.6886653304100037e-01
    z[7,3,6]  R1692     1.3063828647136688e-01
    z[7,3,6]  R1693     8.7904646992683411e-02
    z[7,3,6]  R1694     -2.1914835274219513e-01
    z[7,3,6]  R1695     -4.5325968414545059e-02
    z[7,3,6]  R1696     4.7167718410491943e-01
    z[7,3,6]  R1697     2.3300263285636902e-01
    z[7,3,6]  R1698     -1.8468016386032104e-01
    z[7,3,6]  R1699     1.2350400909781456e-02
    z[7,3,6]  R1700     -1.1037850379943848e-01
    z[7,3,6]  R1701     -1.6299147903919220e-01
    z[7,3,6]  R1702     -2.8236522339284420e-03
    z[7,3,6]  R1703     3.1427938491106033e-02
    z[7,3,6]  R1704     2.0696519315242767e-01
    z[7,3,6]  R1705     -3.7461996078491211e-01
    z[7,3,6]  R1706     0.565693199634552
    z[7,3,6]  R1707     9.2446379363536835e-02
    z[7,3,6]  R1708     2.3793274164199829e-01
    z[7,3,6]  R1709     1.2363357841968536e-01
    z[7,3,6]  R1710     -7.3006264865398407e-02
    z[7,3,6]  R1711     6.8720698356628418e-02
    z[7,3,6]  R1712     1.3928471505641937e-01
    z[7,3,6]  R1713     0.0840034931898117
    z[7,3,6]  R1714     4.4490348547697067e-02
    z[7,3,6]  R1715     4.0182426571846008e-02
    z[7,3,6]  R1716     -7.1369171142578125e-02
    z[7,3,6]  R1717     -1.2926366925239563e-01
    z[7,3,6]  R1718     -2.9037842154502869e-01
    z[7,3,6]  R1719     4.1457340121269226e-01
    z[7,3,6]  R1720     2.4589551985263824e-01
    z[7,3,6]  R1721     -1.1040373146533966e-01
    z[7,3,6]  R1722     -1.0975638777017593e-01
    z[7,3,6]  R1723     -2.2316549718379974e-01
    z[4,7,0]  R38       -1
    z[4,7,0]  R65       1
    z[4,7,0]  R1724     -1
    z[4,7,0]  R1725     1
    z[4,7,0]  R1738     0.910633385181427
    z[4,7,0]  R1739     8.6385035514831543e-01
    z[4,7,0]  R1740     9.6000903844833374e-01
    z[4,7,0]  R1741     8.4667760133743286e-01
    z[4,7,0]  R1742     8.0817246437072754e-01
    z[4,7,0]  R1743     5.7434415817260742e-01
    z[4,7,0]  R1744     7.5250571966171265e-01
    z[4,7,0]  R1745     -1.9204263389110565e-01
    z[4,7,0]  R1746     -3.1876403093338013e-01
    z[4,7,0]  R1747     -1.9027492403984070e-01
    z[4,7,0]  R1748     -2.0767155289649963e-01
    z[4,7,0]  R1749     -4.4648265838623047e-01
    z[4,7,0]  R1750     -0.127395898103714
    z[4,7,0]  R1751     -6.2777155637741089e-01
    z[4,7,0]  R1752     -2.4436137080192566e-01
    z[4,7,0]  R1753     -2.9672563076019287e-01
    z[4,7,0]  R1754     -5.6023168563842773e-01
    z[4,7,0]  R1755     -2.2943228483200073e-01
    z[4,7,0]  R1756     -3.3806160092353821e-01
    z[4,7,0]  R1757     -3.3537802100181580e-01
    z[4,7,0]  R1758     -2.8405603766441345e-01
    z[4,7,0]  R1759     -2.2720962762832642e-01
    z[4,7,0]  R1760     2.2040279582142830e-02
    z[4,7,0]  R1761     -0.0471559539437294
    z[4,7,0]  R1762     1.5134997665882111e-01
    z[4,7,0]  R1763     3.6984187364578247e-01
    z[4,7,0]  R1764     -5.7003587484359741e-01
    z[4,7,0]  R1765     1.9555503129959106e-01
    z[4,7,0]  R1766     -5.0418472290039062e-01
    z[4,7,0]  R1767     -0.566318929195404
    z[4,7,0]  R1768     -2.7169395238161087e-02
    z[4,7,0]  R1769     4.0753343701362610e-01
    z[4,7,0]  R1770     1.9366508722305298e-01
    z[4,7,0]  R1771     -7.1623331308364868e-01
    z[4,7,0]  R1772     3.7577813863754272e-01
    z[4,7,0]  R1773     1.7083208262920380e-01
    z[4,7,0]  R1774     1.7021400853991508e-03
    z[4,7,0]  R1775     3.0672988295555115e-01
    z[4,7,0]  R1776     3.3502897620201111e-01
    z[4,7,0]  R1777     -4.8495680093765259e-01
    z[4,7,0]  R1778     -7.5788080692291260e-01
    z[4,7,0]  R1779     -2.8400537371635437e-01
    z[4,7,0]  R1780     -1.9477254152297974e-01
    z[4,7,0]  R1781     -4.4092038273811340e-01
    z[4,7,0]  R1782     1.6808068752288818e-01
    z[4,7,0]  R1783     3.0650016665458679e-01
    z[4,7,0]  R1784     -4.8207080364227295e-01
    z[4,7,0]  R1785     0.021457489579916
    z[4,7,0]  R1786     1.5523508191108704e-01
    z[4,7,0]  R1787     1.5136989951133728e-01
    z[4,7,0]  R1788     1.7610202729701996e-01
    z[4,7,0]  R1789     1.2261650711297989e-01
    z[4,7,0]  R1790     -5.4844474792480469e-01
    z[4,7,0]  R1791     -5.2444231510162354e-01
    z[4,7,0]  R1792     -4.6172222495079041e-01
    z[4,7,0]  R1793     -0.569028913974762
    z[4,7,0]  R1794     -5.6284797191619873e-01
    z[4,7,0]  R1795     -4.1871842741966248e-01
    z[4,7,0]  R1796     -5.5132120847702026e-01
    z[4,7,0]  R1797     1.2665323913097382e-01
    z[4,7,0]  R1798     1.7611831426620483e-01
    z[4,7,0]  R1799     4.7245588898658752e-01
    z[4,7,0]  R1800     1.6912671923637390e-01
    z[4,7,0]  R1801     -5.5089020729064941e-01
    z[4,7,0]  R1802     -5.6645786762237549e-01
    z[4,7,0]  R1803     -4.5239266753196716e-01
    z[4,7,0]  R1804     -7.2609871625900269e-02
    z[4,7,0]  R1805     2.0316435396671295e-01
    z[4,7,0]  R1806     1.5671840310096741e-01
    z[4,7,0]  R1807     1.0520647466182709e-01
    z[4,7,0]  R1808     0.831761360168457
    z[4,7,0]  R1809     9.2205941677093506e-01
    z[4,7,0]  R1810     8.5395079851150513e-01
    z[4,7,0]  R1811     7.1274155378341675e-01
    z[4,7,0]  R1812     8.4566819667816162e-01
    z[4,7,0]  R1813     6.3203769922256470e-01
    z[4,7,0]  R1814     6.9810485839843750e-01
    z[4,7,0]  R1815     -1.6135847568511963e-01
    z[4,7,0]  R1816     -1.4748410880565643e-01
    z[4,7,0]  R1817     1.5411005914211273e-01
    z[4,7,0]  R1818     -2.0003539323806763e-01
    z[4,7,0]  R1819     -5.4264968633651733e-01
    z[4,7,0]  R1820     -5.2113640308380127e-01
    z[4,7,0]  R1821     -5.5860871076583862e-01
    z[4,7,0]  R1822     -1.8229384720325470e-01
    z[4,7,0]  R1823     -4.6869260072708130e-01
    z[4,7,0]  R1824     -4.7543257474899292e-01
    z[4,7,0]  R1825     -5.8686113357543945e-01
    z[4,7,0]  R1826     -2.1261937916278839e-01
    z[4,7,0]  R1827     -5.0665266811847687e-02
    z[4,7,0]  R1828     -2.2017173469066620e-01
    z[4,7,0]  R1829     -1.0050955414772034e-01
    z[4,7,0]  R1830     -3.8916191458702087e-01
    z[4,7,0]  R1831     3.5358372330665588e-01
    z[4,7,0]  R1832     1.0035784542560577e-01
    z[4,7,0]  R1833     -3.2422360777854919e-01
    z[4,7,0]  R1834     5.0990432500839233e-01
    z[4,7,0]  R1835     7.3181706666946411e-01
    z[4,7,0]  R1836     3.9688837714493275e-03
    z[4,7,0]  R1837     -7.7977222204208374e-01
    z[4,7,0]  R1838     -0.8011514544487
    z[4,7,0]  R1839     -6.4584916830062866e-01
    z[4,7,0]  R1840     -6.4749133586883545e-01
    z[4,7,0]  R1841     -0.866128146648407
    z[4,7,0]  R1842     -5.2334684133529663e-01
    z[4,7,0]  R1843     -9.0055245161056519e-01
    z[4,7,0]  R1844     -5.1530826091766357e-01
    z[4,7,0]  R1845     -4.6573814749717712e-01
    z[4,7,0]  R1846     4.4696500897407532e-01
    z[4,7,0]  R1847     0.421758234500885
    z[4,7,0]  R1848     -0.128040611743927
    z[4,7,0]  R1849     -2.0239213481545448e-02
    z[4,7,0]  R1850     -7.9799783229827881e-01
    z[4,7,0]  R1851     -1.4799687266349792e-01
    z[4,7,0]  R1852     -3.1945714354515076e-01
    z[4,7,0]  R1853     0.718023955821991
    z[4,7,0]  R1854     1.3686415553092957e-01
    z[4,7,0]  R1855     2.3470732569694519e-01
    z[4,7,0]  R1856     1.2830194830894470e-01
    z[4,7,0]  R1857     -2.8881579637527466e-02
    z[4,7,0]  R1858     -1.2167088687419891e-01
    z[4,7,0]  R1859     2.9862058162689209e-01
    z[4,7,0]  R1860     -2.7959802746772766e-01
    z[4,7,0]  R1861     6.2875278294086456e-02
    z[4,7,0]  R1862     -0.276602566242218
    z[4,7,0]  R1863     -7.9921597242355347e-01
    z[4,7,0]  R1864     -1.3351860642433167e-01
    z[4,7,0]  R1865     -0.386550635099411
    z[4,7,0]  R1866     1.8768247961997986e-01
    z[4,7,0]  R1867     0.360411673784256
    z[4,7,1]  R39       -1
    z[4,7,1]  R66       1
    z[4,7,1]  R1726     -1
    z[4,7,1]  R1727     1
    z[4,7,1]  R1738     1.1460566520690918e-01
    z[4,7,1]  R1739     2.5463491678237915e-02
    z[4,7,1]  R1740     -1.4563414454460144e-01
    z[4,7,1]  R1741     -1.5058070421218872e-01
    z[4,7,1]  R1742     -2.8103342652320862e-01
    z[4,7,1]  R1743     -3.2171329855918884e-01
    z[4,7,1]  R1744     -4.3177595734596252e-01
    z[4,7,1]  R1745     -5.6893426179885864e-01
    z[4,7,1]  R1746     -6.2713003158569336e-01
    z[4,7,1]  R1747     -3.3543795347213745e-01
    z[4,7,1]  R1748     -5.8244132995605469e-01
    z[4,7,1]  R1749     -6.3318848609924316e-01
    z[4,7,1]  R1750     -5.3689426183700562e-01
    z[4,7,1]  R1751     -4.2378321290016174e-01
    z[4,7,1]  R1752     8.1636792421340942e-01
    z[4,7,1]  R1753     8.2112735509872437e-01
    z[4,7,1]  R1754     7.6580405235290527e-01
    z[4,7,1]  R1755     7.6226824522018433e-01
    z[4,7,1]  R1756     7.1772933006286621e-01
    z[4,7,1]  R1757     7.8388285636901855e-01
    z[4,7,1]  R1758     -7.8066468238830566e-01
    z[4,7,1]  R1759     -5.2805393934249878e-01
    z[4,7,1]  R1760     -4.1029801964759827e-01
    z[4,7,1]  R1761     -2.5612908601760864e-01
    z[4,7,1]  R1762     -3.9278411865234375e-01
    z[4,7,1]  R1763     -5.1957917213439941e-01
    z[4,7,1]  R1764     7.5354062020778656e-02
    z[4,7,1]  R1765     6.4115965366363525e-01
    z[4,7,1]  R1766     6.8383723497390747e-01
    z[4,7,1]  R1767     6.3187509775161743e-01
    z[4,7,1]  R1768     -0.740505576133728
    z[4,7,1]  R1769     -7.3246729373931885e-01
    z[4,7,1]  R1770     -5.8310168981552124e-01
    z[4,7,1]  R1771     3.3649951219558716e-01
    z[4,7,1]  R1772     3.6887574195861816e-01
    z[4,7,1]  R1773     3.4796217083930969e-01
    z[4,7,1]  R1774     4.5040979981422424e-01
    z[4,7,1]  R1775     5.7220572233200073e-01
    z[4,7,1]  R1776     5.9585189819335938e-01
    z[4,7,1]  R1777     6.1750531196594238e-01
    z[4,7,1]  R1778     1.4881081879138947e-01
    z[4,7,1]  R1779     7.4363607168197632e-01
    z[4,7,1]  R1780     0.666480302810669
    z[4,7,1]  R1781     5.0507462024688721e-01
    z[4,7,1]  R1782     9.4165974855422974e-01
    z[4,7,1]  R1783     9.1493850946426392e-01
    z[4,7,1]  R1784     3.8173234462738037e-01
    z[4,7,1]  R1785     9.3927145004272461e-01
    z[4,7,1]  R1786     0.92210853099823
    z[4,7,1]  R1787     9.1048997640609741e-01
    z[4,7,1]  R1788     0.601198136806488
    z[4,7,1]  R1789     4.2409190535545349e-01
    z[4,7,1]  R1790     0.558688759803772
    z[4,7,1]  R1791     3.3374351263046265e-01
    z[4,7,1]  R1792     0.828164279460907
    z[4,7,1]  R1793     6.3915222883224487e-01
    z[4,7,1]  R1794     0.666843056678772
    z[4,7,1]  R1795     7.4222880601882935e-01
    z[4,7,1]  R1796     4.9861952662467957e-01
    z[4,7,1]  R1797     0.881424605846405
    z[4,7,1]  R1798     -4.2620584368705750e-01
    z[4,7,1]  R1799     -3.2889935374259949e-01
    z[4,7,1]  R1800     3.7889429926872253e-01
    z[4,7,1]  R1801     4.2418941855430603e-01
    z[4,7,1]  R1802     6.4593595266342163e-01
    z[4,7,1]  R1803     7.7900153398513794e-01
    z[4,7,1]  R1804     8.7439858913421631e-01
    z[4,7,1]  R1805     7.5653755664825439e-01
    z[4,7,1]  R1806     7.9470765590667725e-01
    z[4,7,1]  R1807     3.3972927927970886e-01
    z[4,7,1]  R1808     1.1788117140531540e-01
    z[4,7,1]  R1809     -5.7180680334568024e-02
    z[4,7,1]  R1810     -1.2512235343456268e-01
    z[4,7,1]  R1811     -2.2064872086048126e-01
    z[4,7,1]  R1812     -0.262986958026886
    z[4,7,1]  R1813     -2.0322947204113007e-01
    z[4,7,1]  R1814     1.2710350751876831e-01
    z[4,7,1]  R1815     -6.1658447980880737e-01
    z[4,7,1]  R1816     -5.7900321483612061e-01
    z[4,7,1]  R1817     -6.4628767967224121e-01
    z[4,7,1]  R1818     1.9738541543483734e-01
    z[4,7,1]  R1819     6.6613882780075073e-01
    z[4,7,1]  R1820     7.3474103212356567e-01
    z[4,7,1]  R1821     7.4525296688079834e-02
    z[4,7,1]  R1822     -2.2945592645555735e-03
    z[4,7,1]  R1823     4.4102672487497330e-02
    z[4,7,1]  R1824     5.7743549346923828e-01
    z[4,7,1]  R1825     5.3636454045772552e-02
    z[4,7,1]  R1826     4.0496596693992615e-01
    z[4,7,1]  R1827     6.5669816732406616e-01
    z[4,7,1]  R1828     -6.7782026529312134e-01
    z[4,7,1]  R1829     -8.0523324012756348e-01
    z[4,7,1]  R1830     -5.9223777055740356e-01
    z[4,7,1]  R1831     -7.8164649009704590e-01
    z[4,7,1]  R1832     -7.4711662530899048e-01
    z[4,7,1]  R1833     -6.4996057748794556e-01
    z[4,7,1]  R1834     -0.512759268283844
    z[4,7,1]  R1835     -5.2422821521759033e-01
    z[4,7,1]  R1836     -4.5910209417343140e-01
    z[4,7,1]  R1837     1.1272864043712616e-01
    z[4,7,1]  R1838     -3.4529095888137817e-01
    z[4,7,1]  R1839     7.0104561746120453e-03
    z[4,7,1]  R1840     4.6046581119298935e-03
    z[4,7,1]  R1841     -5.4499473422765732e-02
    z[4,7,1]  R1842     1.7552489042282104e-01
    z[4,7,1]  R1843     -9.6060343086719513e-02
    z[4,7,1]  R1844     7.1108184754848480e-02
    z[4,7,1]  R1845     -4.3063253164291382e-01
    z[4,7,1]  R1846     2.3395034670829773e-01
    z[4,7,1]  R1847     1.2475195527076721e-01
    z[4,7,1]  R1848     -6.4332002401351929e-01
    z[4,7,1]  R1849     8.6006671190261841e-02
    z[4,7,1]  R1850     5.9089845418930054e-01
    z[4,7,1]  R1851     6.4706325531005859e-01
    z[4,7,1]  R1852     0.686769425868988
    z[4,7,1]  R1853     2.7850097417831421e-01
    z[4,7,1]  R1854     9.1011798381805420e-01
    z[4,7,1]  R1855     8.5468226671218872e-01
    z[4,7,1]  R1856     9.0942496061325073e-01
    z[4,7,1]  R1857     7.3431169986724854e-01
    z[4,7,1]  R1858     -7.3055410385131836e-01
    z[4,7,1]  R1859     -6.7307293415069580e-01
    z[4,7,1]  R1860     -7.0669221878051758e-01
    z[4,7,1]  R1861     -6.1387270689010620e-01
    z[4,7,1]  R1862     9.0618662536144257e-02
    z[4,7,1]  R1863     5.9256780147552490e-01
    z[4,7,1]  R1864     6.7437773942947388e-01
    z[4,7,1]  R1865     7.3519986867904663e-01
    z[4,7,1]  R1866     5.2971726655960083e-01
    z[4,7,1]  R1867     4.3057283759117126e-01
    z[4,7,2]  R40       -1
    z[4,7,2]  R67       1
    z[4,7,2]  R1728     -1
    z[4,7,2]  R1729     1
    z[4,7,2]  R1738     -1.1033765971660614e-01
    z[4,7,2]  R1739     -2.3953357338905334e-01
    z[4,7,2]  R1740     -3.6573097109794617e-02
    z[4,7,2]  R1741     2.4638488888740540e-01
    z[4,7,2]  R1742     -4.1139110922813416e-02
    z[4,7,2]  R1743     -7.4872829020023346e-02
    z[4,7,2]  R1744     0.201263889670372
    z[4,7,2]  R1745     5.1678277552127838e-02
    z[4,7,2]  R1746     -2.8553009033203125e-01
    z[4,7,2]  R1747     2.0388789474964142e-01
    z[4,7,2]  R1748     3.0496206879615784e-01
    z[4,7,2]  R1749     1.5170499682426453e-01
    z[4,7,2]  R1750     3.4554663300514221e-01
    z[4,7,2]  R1751     4.3080207705497742e-01
    z[4,7,2]  R1752     -4.5506325364112854e-01
    z[4,7,2]  R1753     -4.5871418714523315e-01
    z[4,7,2]  R1754     -2.5207144021987915e-01
    z[4,7,2]  R1755     -5.3996407985687256e-01
    z[4,7,2]  R1756     -4.7224959731101990e-01
    z[4,7,2]  R1757     -4.2015898227691650e-01
    z[4,7,2]  R1758     -2.5683504343032837e-01
    z[4,7,2]  R1759     -0.00099270383361727
    z[4,7,2]  R1760     3.0738282203674316e-01
    z[4,7,2]  R1761     8.9336413145065308e-01
    z[4,7,2]  R1762     1.6484551131725311e-01
    z[4,7,2]  R1763     -5.5105859041213989e-01
    z[4,7,2]  R1764     -5.1811766624450684e-01
    z[4,7,2]  R1765     5.8941847085952759e-01
    z[4,7,2]  R1766     -3.3432438969612122e-01
    z[4,7,2]  R1767     -0.340804785490036
    z[4,7,2]  R1768     4.6320453286170959e-01
    z[4,7,2]  R1769     -5.8638896793127060e-02
    z[4,7,2]  R1770     -0.0315396711230278
    z[4,7,2]  R1771     -2.2471982240676880e-01
    z[4,7,2]  R1772     6.4761632680892944e-01
    z[4,7,2]  R1773     4.8071259260177612e-01
    z[4,7,2]  R1774     0.53521329164505
    z[4,7,2]  R1775     1.8668556213378906e-01
    z[4,7,2]  R1776     2.4896225333213806e-01
    z[4,7,2]  R1777     -3.5354679822921753e-01
    z[4,7,2]  R1778     -2.5364935398101807e-01
    z[4,7,2]  R1779     -5.8455985784530640e-01
    z[4,7,2]  R1780     -4.2960298061370850e-01
    z[4,7,2]  R1781     -3.8094425201416016e-01
    z[4,7,2]  R1782     -4.5056834816932678e-02
    z[4,7,2]  R1783     -1.1783744394779205e-01
    z[4,7,2]  R1784     -5.1590472459793091e-01
    z[4,7,2]  R1785     3.7413392215967178e-02
    z[4,7,2]  R1786     -5.4214667528867722e-02
    z[4,7,2]  R1787     -2.0445628464221954e-01
    z[4,7,2]  R1788     5.7721412181854248e-01
    z[4,7,2]  R1789     3.1412672996520996e-01
    z[4,7,2]  R1790     -4.0260905027389526e-01
    z[4,7,2]  R1791     -6.7133563756942749e-01
    z[4,7,2]  R1792     5.5074214935302734e-02
    z[4,7,2]  R1793     -1.4470370113849640e-01
    z[4,7,2]  R1794     -1.5852785110473633e-01
    z[4,7,2]  R1795     5.9551354497671127e-03
    z[4,7,2]  R1796     -2.4570623040199280e-01
    z[4,7,2]  R1797     -1.9592528045177460e-01
    z[4,7,2]  R1798     4.2542022466659546e-01
    z[4,7,2]  R1799     3.2853364944458008e-01
    z[4,7,2]  R1800     5.1375579833984375e-01
    z[4,7,2]  R1801     -5.5606234073638916e-01
    z[4,7,2]  R1802     -2.3779833316802979e-01
    z[4,7,2]  R1803     -1.7113822698593140e-01
    z[4,7,2]  R1804     0.0406145378947258
    z[4,7,2]  R1805     -3.0740597844123840e-01
    z[4,7,2]  R1806     2.9896411299705505e-01
    z[4,7,2]  R1807     -5.1972858607769012e-02
    z[4,7,2]  R1808     1.5736088156700134e-01
    z[4,7,2]  R1809     3.1619224697351456e-02
    z[4,7,2]  R1810     -2.8328439593315125e-01
    z[4,7,2]  R1811     1.6663897037506104e-01
    z[4,7,2]  R1812     4.3664994835853577e-01
    z[4,7,2]  R1813     3.6473900079727173e-01
    z[4,7,2]  R1814     9.3046009540557861e-02
    z[4,7,2]  R1815     2.6254189014434814e-01
    z[4,7,2]  R1816     0.255932092666626
    z[4,7,2]  R1817     3.0451336503028870e-01
    z[4,7,2]  R1818     -7.3511481285095215e-01
    z[4,7,2]  R1819     -3.7339490652084351e-01
    z[4,7,2]  R1820     -2.5605386495590210e-01
    z[4,7,2]  R1821     -3.1785136461257935e-01
    z[4,7,2]  R1822     -8.7365549802780151e-01
    z[4,7,2]  R1823     -6.0707551240921021e-01
    z[4,7,2]  R1824     -3.5549452900886536e-01
    z[4,7,2]  R1825     -0.730562686920166
    z[4,7,2]  R1826     -7.2983330488204956e-01
    z[4,7,2]  R1827     -5.8316880464553833e-01
    z[4,7,2]  R1828     -5.9866684675216675e-01
    z[4,7,2]  R1829     -3.0322751402854919e-01
    z[4,7,2]  R1830     -2.2276845574378967e-01
    z[4,7,2]  R1831     -8.7085880339145660e-02
    z[4,7,2]  R1832     -1.8152470886707306e-01
    z[4,7,2]  R1833     -2.1618537604808807e-01
    z[4,7,2]  R1834     -4.0154952555894852e-02
    z[4,7,2]  R1835     1.2722371518611908e-01
    z[4,7,2]  R1836     7.7772176265716553e-01
    z[4,7,2]  R1837     -2.9540473222732544e-01
    z[4,7,2]  R1838     3.6096596717834473e-01
    z[4,7,2]  R1839     -3.6073359847068787e-01
    z[4,7,2]  R1840     -0.50264972448349
    z[4,7,2]  R1841     -1.4566515386104584e-01
    z[4,7,2]  R1842     -5.9669876098632812e-01
    z[4,7,2]  R1843     -4.2036834359169006e-01
    z[4,7,2]  R1844     -0.81169593334198
    z[4,7,2]  R1845     -8.8499732315540314e-02
    z[4,7,2]  R1846     5.6356781721115112e-01
    z[4,7,2]  R1847     6.6970270872116089e-01
    z[4,7,2]  R1848     2.8186139464378357e-01
    z[4,7,2]  R1849     -0.647044837474823
    z[4,7,2]  R1850     -7.7119171619415283e-02
    z[4,7,2]  R1851     -5.6557118892669678e-01
    z[4,7,2]  R1852     -4.3069493770599365e-01
    z[4,7,2]  R1853     4.9036827683448792e-01
    z[4,7,2]  R1854     6.6082730889320374e-02
    z[4,7,2]  R1855     1.8462300300598145e-01
    z[4,7,2]  R1856     -1.1157387867569923e-02
    z[4,7,2]  R1857     -5.1228034496307373e-01
    z[4,7,2]  R1858     2.6303809881210327e-01
    z[4,7,2]  R1859     5.2225303649902344e-01
    z[4,7,2]  R1860     1.6468265652656555e-01
    z[4,7,2]  R1861     -3.2448098063468933e-01
    z[4,7,2]  R1862     -0.89305579662323
    z[4,7,2]  R1863     -5.2912008017301559e-02
    z[4,7,2]  R1864     -6.0445809364318848e-01
    z[4,7,2]  R1865     -3.9572045207023621e-01
    z[4,7,2]  R1866     5.8833497762680054e-01
    z[4,7,2]  R1867     6.8056142330169678e-01
    z[4,7,3]  R41       -1
    z[4,7,3]  R68       1
    z[4,7,3]  R1730     -1
    z[4,7,3]  R1731     1
    z[4,7,3]  R1738     -3.0676627159118652e-01
    z[4,7,3]  R1739     -3.7245699763298035e-01
    z[4,7,3]  R1740     -2.3310832679271698e-02
    z[4,7,3]  R1741     -2.8134772181510925e-01
    z[4,7,3]  R1742     -1.6613277792930603e-01
    z[4,7,3]  R1743     -7.2090911865234375e-01
    z[4,7,3]  R1744     3.1365206837654114e-01
    z[4,7,3]  R1745     3.5603219270706177e-01
    z[4,7,3]  R1746     5.1434355974197388e-01
    z[4,7,3]  R1747     7.0499561727046967e-02
    z[4,7,3]  R1748     -1.6654946375638247e-03
    z[4,7,3]  R1749     1.5276117250323296e-02
    z[4,7,3]  R1750     -4.7179181128740311e-02
    z[4,7,3]  R1751     -1.7511065304279327e-01
    z[4,7,3]  R1752     2.0056959986686707e-01
    z[4,7,3]  R1753     -2.2695591673254967e-02
    z[4,7,3]  R1754     -6.3069827854633331e-02
    z[4,7,3]  R1755     1.6770876944065094e-01
    z[4,7,3]  R1756     1.6817204654216766e-01
    z[4,7,3]  R1757     2.3151952773332596e-02
    z[4,7,3]  R1758     2.6901695132255554e-01
    z[4,7,3]  R1759     9.3601889908313751e-02
    z[4,7,3]  R1760     1.2430024892091751e-01
    z[4,7,3]  R1761     3.3441290725022554e-03
    z[4,7,3]  R1762     3.0803942680358887e-01
    z[4,7,3]  R1763     2.7731612324714661e-01
    z[4,7,3]  R1764     -1.8918864428997040e-01
    z[4,7,3]  R1765     -2.8639551997184753e-01
    z[4,7,3]  R1766     2.2982136905193329e-01
    z[4,7,3]  R1767     3.6958608776330948e-02
    z[4,7,3]  R1768     2.4177664518356323e-01
    z[4,7,3]  R1769     3.7974965572357178e-01
    z[4,7,3]  R1770     1.0621663928031921e-01
    z[4,7,3]  R1771     -2.0878523588180542e-01
    z[4,7,3]  R1772     -1.9266463816165924e-01
    z[4,7,3]  R1773     -0.259590208530426
    z[4,7,3]  R1774     -3.4287315607070923e-01
    z[4,7,3]  R1775     -1.7056691646575928e-01
    z[4,7,3]  R1776     -1.5326879918575287e-01
    z[4,7,3]  R1777     2.7780768275260925e-01
    z[4,7,3]  R1778     -2.1395921707153320e-01
    z[4,7,3]  R1779     -5.2395123988389969e-02
    z[4,7,3]  R1780     0.516957700252533
    z[4,7,3]  R1781     0.528457522392273
    z[4,7,3]  R1782     -2.6437327265739441e-01
    z[4,7,3]  R1783     -2.1248273551464081e-01
    z[4,7,3]  R1784     3.1534832715988159e-01
    z[4,7,3]  R1785     -0.283624529838562
    z[4,7,3]  R1786     -2.2017486393451691e-01
    z[4,7,3]  R1787     -2.1831075847148895e-01
    z[4,7,3]  R1788     -2.7722486853599548e-01
    z[4,7,3]  R1789     -2.7675676345825195e-01
    z[4,7,3]  R1790     4.1128787398338318e-01
    z[4,7,3]  R1791     3.1493067741394043e-01
    z[4,7,3]  R1792     2.9338827729225159e-01
    z[4,7,3]  R1793     1.9708785414695740e-01
    z[4,7,3]  R1794     -5.1215752959251404e-02
    z[4,7,3]  R1795     4.0755963325500488e-01
    z[4,7,3]  R1796     3.3523747324943542e-01
    z[4,7,3]  R1797     -2.8534629940986633e-01
    z[4,7,3]  R1798     1.2849889695644379e-01
    z[4,7,3]  R1799     1.1477474868297577e-01
    z[4,7,3]  R1800     -0.214838445186615
    z[4,7,3]  R1801     2.5786882638931274e-01
    z[4,7,3]  R1802     2.0320130884647369e-01
    z[4,7,3]  R1803     -1.7632950842380524e-01
    z[4,7,3]  R1804     -3.4535399079322815e-01
    z[4,7,3]  R1805     -1.1928913742303848e-01
    z[4,7,3]  R1806     -2.3364393413066864e-01
    z[4,7,3]  R1807     7.0739632844924927e-01
    z[4,7,3]  R1808     -0.504252552986145
    z[4,7,3]  R1809     -2.4172352254390717e-01
    z[4,7,3]  R1810     -3.7082454562187195e-01
    z[4,7,3]  R1811     -4.2431572079658508e-01
    z[4,7,3]  R1812     -1.4273391105234623e-02
    z[4,7,3]  R1813     -4.8467060923576355e-01
    z[4,7,3]  R1814     -2.1092857420444489e-01
    z[4,7,3]  R1815     -1.8700738251209259e-01
    z[4,7,3]  R1816     5.6740206480026245e-01
    z[4,7,3]  R1817     -1.0911568999290466e-01
    z[4,7,3]  R1818     -4.2100772261619568e-02
    z[4,7,3]  R1819     -2.1732452511787415e-01
    z[4,7,3]  R1820     -0.109881691634655
    z[4,7,3]  R1821     -1.2937353551387787e-01
    z[4,7,3]  R1822     -1.6076089814305305e-02
    z[4,7,3]  R1823     5.3015798330307007e-02
    z[4,7,3]  R1824     -4.6307405829429626e-01
    z[4,7,3]  R1825     -1.3483323156833649e-02
    z[4,7,3]  R1826     1.8107822537422180e-01
    z[4,7,3]  R1827     -1.2303494662046432e-01
    z[4,7,3]  R1828     1.1183109134435654e-01
    z[4,7,3]  R1829     4.8025703430175781e-01
    z[4,7,3]  R1830     -4.1683989763259888e-01
    z[4,7,3]  R1831     2.5238654017448425e-01
    z[4,7,3]  R1832     1.8978676199913025e-01
    z[4,7,3]  R1833     -3.0419981479644775e-01
    z[4,7,3]  R1834     5.2527725696563721e-01
    z[4,7,3]  R1835     2.6501783728599548e-01
    z[4,7,3]  R1836     2.3504644632339478e-01
    z[4,7,3]  R1837     -3.0951502267271280e-03
    z[4,7,3]  R1838     -1.0267569869756699e-01
    z[4,7,3]  R1839     -9.5114611089229584e-02
    z[4,7,3]  R1840     -3.6320930719375610e-01
    z[4,7,3]  R1841     -3.2691818475723267e-01
    z[4,7,3]  R1842     1.5387211740016937e-01
    z[4,7,3]  R1843     1.2792519293725491e-02
    z[4,7,3]  R1844     9.7040623426437378e-02
    z[4,7,3]  R1845     -4.2647728323936462e-01
    z[4,7,3]  R1846     9.0673323720693588e-03
    z[4,7,3]  R1847     -3.9340332150459290e-01
    z[4,7,3]  R1848     3.7332630157470703e-01
    z[4,7,3]  R1849     -4.8981118947267532e-02
    z[4,7,3]  R1850     4.3991249054670334e-02
    z[4,7,3]  R1851     -1.4338363707065582e-01
    z[4,7,3]  R1852     -1.6163422167301178e-01
    z[4,7,3]  R1853     -2.2544270753860474e-01
    z[4,7,3]  R1854     -3.7036520242691040e-01
    z[4,7,3]  R1855     -3.8125243782997131e-01
    z[4,7,3]  R1856     -3.3912095427513123e-01
    z[4,7,3]  R1857     1.9066568464040756e-02
    z[4,7,3]  R1858     3.4886658191680908e-01
    z[4,7,3]  R1859     9.6905358135700226e-02
    z[4,7,3]  R1860     4.7653075307607651e-02
    z[4,7,3]  R1861     1.5867911279201508e-01
    z[4,7,3]  R1862     -4.2687293142080307e-02
    z[4,7,3]  R1863     -9.7977332770824432e-03
    z[4,7,3]  R1864     -6.8670073524117470e-03
    z[4,7,3]  R1865     -2.0256450772285461e-01
    z[4,7,3]  R1866     -5.2521169185638428e-01
    z[4,7,3]  R1867     -3.5196962952613831e-01
    z[4,7,4]  R42       -1
    z[4,7,4]  R69       1
    z[4,7,4]  R1732     -1
    z[4,7,4]  R1733     1
    z[4,7,4]  R1738     -2.1605329215526581e-01
    z[4,7,4]  R1739     1.7489252984523773e-01
    z[4,7,4]  R1740     2.0510016381740570e-01
    z[4,7,4]  R1741     -1.3762958347797394e-01
    z[4,7,4]  R1742     -3.1085237860679626e-02
    z[4,7,4]  R1743     -1.3170013204216957e-02
    z[4,7,4]  R1744     2.0437940955162048e-01
    z[4,7,4]  R1745     -4.2405596375465393e-01
    z[4,7,4]  R1746     1.8331797420978546e-01
    z[4,7,4]  R1747     -1.0111937671899796e-01
    z[4,7,4]  R1748     1.5326094627380371e-01
    z[4,7,4]  R1749     -1.0808974504470825e-01
    z[4,7,4]  R1750     -4.3306279182434082e-01
    z[4,7,4]  R1751     3.9568793773651123e-01
    z[4,7,4]  R1752     1.1852863430976868e-01
    z[4,7,4]  R1753     1.4173589646816254e-01
    z[4,7,4]  R1754     -1.1155854910612106e-01
    z[4,7,4]  R1755     1.6141225397586823e-01
    z[4,7,4]  R1756     7.3472797870635986e-02
    z[4,7,4]  R1757     -5.3109776228666306e-02
    z[4,7,4]  R1758     -3.1306478381156921e-01
    z[4,7,4]  R1759     5.5055856704711914e-01
    z[4,7,4]  R1760     2.6041364669799805e-01
    z[4,7,4]  R1761     -2.0082934200763702e-01
    z[4,7,4]  R1762     -5.9684371948242188e-01
    z[4,7,4]  R1763     4.0093538165092468e-01
    z[4,7,4]  R1764     3.3297979831695557e-01
    z[4,7,4]  R1765     3.2784977555274963e-01
    z[4,7,4]  R1766     2.8037330508232117e-01
    z[4,7,4]  R1767     1.7677634954452515e-01
    z[4,7,4]  R1768     -2.9274460673332214e-01
    z[4,7,4]  R1769     7.1325547993183136e-02
    z[4,7,4]  R1770     6.5629088878631592e-01
    z[4,7,4]  R1771     -3.2649514079093933e-01
    z[4,7,4]  R1772     3.2498300075531006e-01
    z[4,7,4]  R1773     7.2262948751449585e-01
    z[4,7,4]  R1774     4.5627161860466003e-01
    z[4,7,4]  R1775     5.5931615829467773e-01
    z[4,7,4]  R1776     3.8837355375289917e-01
    z[4,7,4]  R1777     1.7797181010246277e-01
    z[4,7,4]  R1778     -2.0552127063274384e-01
    z[4,7,4]  R1779     -1.3959896750748158e-02
    z[4,7,4]  R1780     -1.4487208425998688e-01
    z[4,7,4]  R1781     -2.1121428906917572e-01
    z[4,7,4]  R1782     3.6880597472190857e-02
    z[4,7,4]  R1783     -5.3045139648020267e-03
    z[4,7,4]  R1784     -6.0588344931602478e-02
    z[4,7,4]  R1785     -9.6480615437030792e-02
    z[4,7,4]  R1786     -5.9477563947439194e-02
    z[4,7,4]  R1787     5.1358029246330261e-02
    z[4,7,4]  R1788     3.8351699709892273e-01
    z[4,7,4]  R1789     7.9344105720520020e-01
    z[4,7,4]  R1790     1.6153217852115631e-01
    z[4,7,4]  R1791     2.5022806599736214e-02
    z[4,7,4]  R1792     -0.0460795983672142
    z[4,7,4]  R1793     -2.1581773459911346e-01
    z[4,7,4]  R1794     -4.8652660101652145e-02
    z[4,7,4]  R1795     -1.3221164047718048e-01
    z[4,7,4]  R1796     -1.9343020021915436e-01
    z[4,7,4]  R1797     2.8541228175163269e-01
    z[4,7,4]  R1798     -1.5745188295841217e-01
    z[4,7,4]  R1799     -2.8067368548363447e-03
    z[4,7,4]  R1800     0.63071209192276
    z[4,7,4]  R1801     2.8684103488922119e-01
    z[4,7,4]  R1802     -1.5300603210926056e-01
    z[4,7,4]  R1803     1.2116441875696182e-01
    z[4,7,4]  R1804     -6.6729813814163208e-02
    z[4,7,4]  R1805     -3.4673970937728882e-01
    z[4,7,4]  R1806     -3.7755584716796875e-01
    z[4,7,4]  R1807     -4.7383829951286316e-01
    z[4,7,4]  R1808     -9.3567736446857452e-02
    z[4,7,4]  R1809     -4.1627362370491028e-03
    z[4,7,4]  R1810     -1.7485836520791054e-02
    z[4,7,4]  R1811     -3.9552173018455505e-01
    z[4,7,4]  R1812     -5.4580219089984894e-02
    z[4,7,4]  R1813     4.1839987039566040e-01
    z[4,7,4]  R1814     5.4671669006347656e-01
    z[4,7,4]  R1815     -4.9099615216255188e-01
    z[4,7,4]  R1816     1.4081904292106628e-01
    z[4,7,4]  R1817     1.8393313884735107e-01
    z[4,7,4]  R1818     -1.8558960407972336e-02
    z[4,7,4]  R1819     2.4832665920257568e-01
    z[4,7,4]  R1820     -2.2210772335529327e-01
    z[4,7,4]  R1821     6.6949248313903809e-01
    z[4,7,4]  R1822     3.9261576533317566e-01
    z[4,7,4]  R1823     6.2186169624328613e-01
    z[4,7,4]  R1824     1.2779118493199348e-02
    z[4,7,4]  R1825     -1.0554113984107971e-01
    z[4,7,4]  R1826     -3.8992649316787720e-01
    z[4,7,4]  R1827     -1.0634469240903854e-01
    z[4,7,4]  R1828     3.4463945031166077e-01
    z[4,7,4]  R1829     3.5495623946189880e-02
    z[4,7,4]  R1830     4.9213263392448425e-01
    z[4,7,4]  R1831     3.8332742452621460e-01
    z[4,7,4]  R1832     2.8598508238792419e-01
    z[4,7,4]  R1833     -1.3394100964069366e-01
    z[4,7,4]  R1834     -4.4146808981895447e-01
    z[4,7,4]  R1835     -2.3624691367149353e-01
    z[4,7,4]  R1836     -2.4334377050399780e-01
    z[4,7,4]  R1837     -4.7691500186920166e-01
    z[4,7,4]  R1838     2.7066943049430847e-01
    z[4,7,4]  R1839     5.8024022728204727e-02
    z[4,7,4]  R1840     -0.0924634113907814
    z[4,7,4]  R1841     1.2324440479278564e-01
    z[4,7,4]  R1842     1.5061776340007782e-01
    z[4,7,4]  R1843     -9.0359859168529510e-03
    z[4,7,4]  R1844     2.4451713263988495e-01
    z[4,7,4]  R1845     4.0662929415702820e-01
    z[4,7,4]  R1846     4.1545665264129639e-01
    z[4,7,4]  R1847     2.5468489527702332e-01
    z[4,7,4]  R1848     -4.1382867097854614e-01
    z[4,7,4]  R1849     -5.0561362504959106e-01
    z[4,7,4]  R1850     -3.6079576238989830e-03
    z[4,7,4]  R1851     -2.3232956230640411e-01
    z[4,7,4]  R1852     -2.8039303421974182e-01
    z[4,7,4]  R1853     -1.9280940294265747e-02
    z[4,7,4]  R1854     6.0891743749380112e-02
    z[4,7,4]  R1855     -3.9529930800199509e-02
    z[4,7,4]  R1856     -1.9411031901836395e-01
    z[4,7,4]  R1857     -4.1277384757995605e-01
    z[4,7,4]  R1858     -0.163431316614151
    z[4,7,4]  R1859     -1.5994679182767868e-02
    z[4,7,4]  R1860     -3.1727802753448486e-01
    z[4,7,4]  R1861     -1.9960127770900726e-01
    z[4,7,4]  R1862     -1.3360002636909485e-01
    z[4,7,4]  R1863     -5.7889252901077271e-02
    z[4,7,4]  R1864     -2.9758140444755554e-01
    z[4,7,4]  R1865     -1.0412189364433289e-01
    z[4,7,4]  R1866     2.4219968914985657e-01
    z[4,7,4]  R1867     2.4200481176376343e-01
    z[4,7,5]  R43       -1
    z[4,7,5]  R70       1
    z[4,7,5]  R1734     -1
    z[4,7,5]  R1735     1
    z[4,7,5]  R1738     -6.7718826234340668e-02
    z[4,7,5]  R1739     -1.5975473821163177e-01
    z[4,7,5]  R1740     1.3967177830636501e-02
    z[4,7,5]  R1741     -3.1440812349319458e-01
    z[4,7,5]  R1742     1.2479781359434128e-01
    z[4,7,5]  R1743     -0.0166141539812088
    z[4,7,5]  R1744     -2.0086416602134705e-01
    z[4,7,5]  R1745     -3.5767531394958496e-01
    z[4,7,5]  R1746     -1.8736422061920166e-01
    z[4,7,5]  R1747     -8.6757856607437134e-01
    z[4,7,5]  R1748     3.3237785100936890e-01
    z[4,7,5]  R1749     8.4211677312850952e-02
    z[4,7,5]  R1750     6.0218435525894165e-01
    z[4,7,5]  R1751     1.7615026235580444e-01
    z[4,7,5]  R1752     9.3072645366191864e-02
    z[4,7,5]  R1753     -5.5267107672989368e-03
    z[4,7,5]  R1754     -1.2235080450773239e-01
    z[4,7,5]  R1755     -5.0252329558134079e-02
    z[4,7,5]  R1756     1.0249210149049759e-01
    z[4,7,5]  R1757     5.2654266357421875e-02
    z[4,7,5]  R1758     -2.7082479000091553e-01
    z[4,7,5]  R1759     -1.8426083028316498e-01
    z[4,7,5]  R1760     5.4612624645233154e-01
    z[4,7,5]  R1761     -1.3940142095088959e-01
    z[4,7,5]  R1762     -9.8460555076599121e-02
    z[4,7,5]  R1763     1.3949838280677795e-01
    z[4,7,5]  R1764     -4.2687162756919861e-01
    z[4,7,5]  R1765     -3.6988869309425354e-02
    z[4,7,5]  R1766     -8.5948094725608826e-02
    z[4,7,5]  R1767     2.4168232083320618e-01
    z[4,7,5]  R1768     2.2038803994655609e-01
    z[4,7,5]  R1769     0.325942724943161
    z[4,7,5]  R1770     1.8155101686716080e-02
    z[4,7,5]  R1771     -3.7361851334571838e-01
    z[4,7,5]  R1772     -3.0973193049430847e-01
    z[4,7,5]  R1773     -1.5568171441555023e-01
    z[4,7,5]  R1774     -0.204054057598114
    z[4,7,5]  R1775     -1.0616850107908249e-02
    z[4,7,5]  R1776     -0.316983163356781
    z[4,7,5]  R1777     1.1278515309095383e-01
    z[4,7,5]  R1778     -4.6136081218719482e-01
    z[4,7,5]  R1779     1.2181588262319565e-01
    z[4,7,5]  R1780     -5.6798618286848068e-02
    z[4,7,5]  R1781     2.6877734065055847e-01
    z[4,7,5]  R1782     9.8095230758190155e-02
    z[4,7,5]  R1783     6.8847984075546265e-02
    z[4,7,5]  R1784     4.6843016147613525e-01
    z[4,7,5]  R1785     -4.8404913395643234e-02
    z[4,7,5]  R1786     -0.00689234584569931
    z[4,7,5]  R1787     -1.0875558108091354e-01
    z[4,7,5]  R1788     1.2592312693595886e-01
    z[4,7,5]  R1789     1.4616641215980053e-02
    z[4,7,5]  R1790     -0.0735788494348526
    z[4,7,5]  R1791     2.4920323491096497e-01
    z[4,7,5]  R1792     7.6562032103538513e-02
    z[4,7,5]  R1793     3.3623912930488586e-01
    z[4,7,5]  R1794     4.5428311824798584e-01
    z[4,7,5]  R1795     1.6750530898571014e-01
    z[4,7,5]  R1796     0.454328328371048
    z[4,7,5]  R1797     1.5757321380078793e-03
    z[4,7,5]  R1798     -7.0956653356552124e-01
    z[4,7,5]  R1799     -1.7349001765251160e-01
    z[4,7,5]  R1800     -1.7410913482308388e-02
    z[4,7,5]  R1801     2.4181802570819855e-01
    z[4,7,5]  R1802     2.8184035420417786e-01
    z[4,7,5]  R1803     3.3563607931137085e-01
    z[4,7,5]  R1804     1.0348308086395264e-01
    z[4,7,5]  R1805     -3.4906560182571411e-01
    z[4,7,5]  R1806     1.1178135871887207e-01
    z[4,7,5]  R1807     1.6751761734485626e-01
    z[4,7,5]  R1808     4.2699400335550308e-02
    z[4,7,5]  R1809     -1.3356618583202362e-01
    z[4,7,5]  R1810     -3.2809235155582428e-02
    z[4,7,5]  R1811     5.3201489150524139e-02
    z[4,7,5]  R1812     -1.0581449419260025e-01
    z[4,7,5]  R1813     0.0456363819539547
    z[4,7,5]  R1814     -1.0163668543100357e-01
    z[4,7,5]  R1815     -3.2858392596244812e-01
    z[4,7,5]  R1816     2.8948080539703369e-01
    z[4,7,5]  R1817     2.4532085657119751e-01
    z[4,7,5]  R1818     -5.8020043373107910e-01
    z[4,7,5]  R1819     5.5503454059362411e-02
    z[4,7,5]  R1820     1.2265937775373459e-01
    z[4,7,5]  R1821     -2.0580182969570160e-01
    z[4,7,5]  R1822     -0.162678524851799
    z[4,7,5]  R1823     1.8457837402820587e-02
    z[4,7,5]  R1824     -1.9807896018028259e-01
    z[4,7,5]  R1825     -8.4291743114590645e-03
    z[4,7,5]  R1826     2.5627663731575012e-01
    z[4,7,5]  R1827     3.3952635526657104e-01
    z[4,7,5]  R1828     3.5490646958351135e-02
    z[4,7,5]  R1829     -9.9709741771221161e-02
    z[4,7,5]  R1830     -1.2336204200983047e-01
    z[4,7,5]  R1831     -0.200625479221344
    z[4,7,5]  R1832     -5.1801913976669312e-01
    z[4,7,5]  R1833     5.2026188373565674e-01
    z[4,7,5]  R1834     -3.2877799123525620e-02
    z[4,7,5]  R1835     -1.8231348693370819e-01
    z[4,7,5]  R1836     1.1712416261434555e-01
    z[4,7,5]  R1837     -1.7633208632469177e-01
    z[4,7,5]  R1838     1.3752581179141998e-01
    z[4,7,5]  R1839     -5.5856925249099731e-01
    z[4,7,5]  R1840     -2.0876045525074005e-01
    z[4,7,5]  R1841     -0.320121705532074
    z[4,7,5]  R1842     -2.7869519591331482e-01
    z[4,7,5]  R1843     1.1142909526824951e-02
    z[4,7,5]  R1844     -6.2896623276174068e-03
    z[4,7,5]  R1845     -2.5724676251411438e-01
    z[4,7,5]  R1846     5.0354021787643433e-01
    z[4,7,5]  R1847     -3.6257150769233704e-01
    z[4,7,5]  R1848     3.9444151520729065e-01
    z[4,7,5]  R1849     -5.5814504623413086e-01
    z[4,7,5]  R1850     5.5932231247425079e-02
    z[4,7,5]  R1851     -1.4626109972596169e-02
    z[4,7,5]  R1852     3.1677356362342834e-01
    z[4,7,5]  R1853     1.9272281229496002e-01
    z[4,7,5]  R1854     2.3736661300063133e-02
    z[4,7,5]  R1855     -1.2253225594758987e-01
    z[4,7,5]  R1856     5.9116680175065994e-02
    z[4,7,5]  R1857     -3.1366065144538879e-02
    z[4,7,5]  R1858     4.3536716699600220e-01
    z[4,7,5]  R1859     -3.9726775884628296e-01
    z[4,7,5]  R1860     2.3148950934410095e-01
    z[4,7,5]  R1861     -3.2445770502090454e-01
    z[4,7,5]  R1862     -2.2903005778789520e-01
    z[4,7,5]  R1863     3.3493004739284515e-02
    z[4,7,5]  R1864     -1.6680642962455750e-01
    z[4,7,5]  R1865     3.0079308152198792e-01
    z[4,7,5]  R1866     -5.6932557374238968e-02
    z[4,7,5]  R1867     1.9158987700939178e-01
    z[4,7,6]  R44       -1
    z[4,7,6]  R71       1
    z[4,7,6]  R1736     -1
    z[4,7,6]  R1737     1
    z[4,7,6]  R1738     -8.2207638770341873e-03
    z[4,7,6]  R1739     3.0077984556555748e-02
    z[4,7,6]  R1740     1.1415420472621918e-01
    z[4,7,6]  R1741     -5.2973654121160507e-02
    z[4,7,6]  R1742     -4.7121551632881165e-01
    z[4,7,6]  R1743     -2.0214863121509552e-01
    z[4,7,6]  R1744     -1.6218061745166779e-01
    z[4,7,6]  R1745     -4.4972071051597595e-01
    z[4,7,6]  R1746     -3.0051621794700623e-01
    z[4,7,6]  R1747     -2.0449618995189667e-01
    z[4,7,6]  R1748     6.2503278255462646e-01
    z[4,7,6]  R1749     5.9808266162872314e-01
    z[4,7,6]  R1750     -1.5400396287441254e-01
    z[4,7,6]  R1751     1.4986211061477661e-01
    z[4,7,6]  R1752     6.1714071780443192e-02
    z[4,7,6]  R1753     8.1549547612667084e-02
    z[4,7,6]  R1754     -6.8933911621570587e-02
    z[4,7,6]  R1755     -1.3431830704212189e-01
    z[4,7,6]  R1756     -3.2151910662651062e-01
    z[4,7,6]  R1757     3.0064353346824646e-01
    z[4,7,6]  R1758     1.3593773357570171e-02
    z[4,7,6]  R1759     -5.6895136833190918e-01
    z[4,7,6]  R1760     -0.59595787525177
    z[4,7,6]  R1761     -2.7257740497589111e-01
    z[4,7,6]  R1762     -5.7864898443222046e-01
    z[4,7,6]  R1763     0.180210143327713
    z[4,7,6]  R1764     2.6841688156127930e-01
    z[4,7,6]  R1765     -1.1127635091543198e-01
    z[4,7,6]  R1766     -1.6606491804122925e-01
    z[4,7,6]  R1767     2.6989388465881348e-01
    z[4,7,6]  R1768     -2.0887459814548492e-01
    z[4,7,6]  R1769     -1.9604563713073730e-01
    z[4,7,6]  R1770     4.2327558994293213e-01
    z[4,7,6]  R1771     -1.8302398920059204e-01
    z[4,7,6]  R1772     2.5425758957862854e-01
    z[4,7,6]  R1773     6.9547399878501892e-02
    z[4,7,6]  R1774     3.7853807210922241e-01
    z[4,7,6]  R1775     -4.4900503754615784e-01
    z[4,7,6]  R1776     -4.4264003634452820e-01
    z[4,7,6]  R1777     3.7005007266998291e-01
    z[4,7,6]  R1778     1.9560858607292175e-01
    z[4,7,6]  R1779     -8.2806371152400970e-02
    z[4,7,6]  R1780     2.0457211136817932e-01
    z[4,7,6]  R1781     -9.6177399158477783e-02
    z[4,7,6]  R1782     -4.6039126813411713e-02
    z[4,7,6]  R1783     7.1710072457790375e-02
    z[4,7,6]  R1784     -1.8217626214027405e-01
    z[4,7,6]  R1785     -1.5431955456733704e-01
    z[4,7,6]  R1786     -2.6573812961578369e-01
    z[4,7,6]  R1787     -2.1016108989715576e-01
    z[4,7,6]  R1788     -1.8594941496849060e-01
    z[4,7,6]  R1789     -8.8872546330094337e-03
    z[4,7,6]  R1790     1.5593892335891724e-01
    z[4,7,6]  R1791     0.0312119722366333
    z[4,7,6]  R1792     6.2140613794326782e-02
    z[4,7,6]  R1793     2.1971276402473450e-01
    z[4,7,6]  R1794     -4.5035343617200851e-02
    z[4,7,6]  R1795     -2.4918465316295624e-01
    z[4,7,6]  R1796     -1.7560848593711853e-01
    z[4,7,6]  R1797     7.6011463999748230e-02
    z[4,7,6]  R1798     2.4811469018459320e-01
    z[4,7,6]  R1799     7.1930283308029175e-01
    z[4,7,6]  R1800     -3.4588134288787842e-01
    z[4,7,6]  R1801     1.1311681009829044e-02
    z[4,7,6]  R1802     2.4740378558635712e-01
    z[4,7,6]  R1803     -2.8012450784444809e-02
    z[4,7,6]  R1804     3.0671533942222595e-01
    z[4,7,6]  R1805     0.188604474067688
    z[4,7,6]  R1806     2.1181724965572357e-01
    z[4,7,6]  R1807     3.4324905276298523e-01
    z[4,7,6]  R1808     -6.8305768072605133e-02
    z[4,7,6]  R1809     -2.6315292716026306e-01
    z[4,7,6]  R1810     1.8965634703636169e-01
    z[4,7,6]  R1811     2.7610439062118530e-01
    z[4,7,6]  R1812     1.0315315425395966e-01
    z[4,7,6]  R1813     1.1893185228109360e-01
    z[4,7,6]  R1814     3.6621958017349243e-01
    z[4,7,6]  R1815     -3.7528967857360840e-01
    z[4,7,6]  R1816     3.8977968692779541e-01
    z[4,7,6]  R1817     -5.9992820024490356e-01
    z[4,7,6]  R1818     2.0464979112148285e-01
    z[4,7,6]  R1819     1.0193166881799698e-01
    z[4,7,6]  R1820     -2.1577247977256775e-01
    z[4,7,6]  R1821     2.7214100956916809e-01
    z[4,7,6]  R1822     -1.5039950609207153e-01
    z[4,7,6]  R1823     1.4134421944618225e-01
    z[4,7,6]  R1824     -2.4560080468654633e-01
    z[4,7,6]  R1825     -3.2802972197532654e-01
    z[4,7,6]  R1826     -8.7344385683536530e-02
    z[4,7,6]  R1827     -2.9046475887298584e-01
    z[4,7,6]  R1828     -3.3763226121664047e-02
    z[4,7,6]  R1829     8.7758764624595642e-02
    z[4,7,6]  R1830     1.3043515384197235e-01
    z[4,7,6]  R1831     -7.4390277266502380e-02
    z[4,7,6]  R1832     1.1244340986013412e-01
    z[4,7,6]  R1833     2.1105460822582245e-01
    z[4,7,6]  R1834     5.9766110032796860e-02
    z[4,7,6]  R1835     -1.1898516118526459e-01
    z[4,7,6]  R1836     2.3701743781566620e-01
    z[4,7,6]  R1837     1.8284708261489868e-01
    z[4,7,6]  R1838     7.6919443905353546e-02
    z[4,7,6]  R1839     3.5817271471023560e-01
    z[4,7,6]  R1840     -3.7950697541236877e-01
    z[4,7,6]  R1841     3.3026900142431259e-02
    z[4,7,6]  R1842     4.6391418576240540e-01
    z[4,7,6]  R1843     5.1949676126241684e-02
    z[4,7,6]  R1844     3.6134470254182816e-02
    z[4,7,6]  R1845     -4.2000627517700195e-01
    z[4,7,6]  R1846     4.0516536682844162e-02
    z[4,7,6]  R1847     8.3466731011867523e-02
    z[4,7,6]  R1848     -1.5520407259464264e-01
    z[4,7,6]  R1849     -0.0628967210650444
    z[4,7,6]  R1850     -5.4903768002986908e-02
    z[4,7,6]  R1851     -4.0593791007995605e-01
    z[4,7,6]  R1852     -1.8895855545997620e-01
    z[4,7,6]  R1853     -2.7942699193954468e-01
    z[4,7,6]  R1854     8.4527529776096344e-02
    z[4,7,6]  R1855     1.3570147752761841e-01
    z[4,7,6]  R1856     -1.3549934141337872e-02
    z[4,7,6]  R1857     1.6059705615043640e-01
    z[4,7,6]  R1858     -2.1056039631366730e-01
    z[4,7,6]  R1859     1.3259758055210114e-01
    z[4,7,6]  R1860     -4.8863810300827026e-01
    z[4,7,6]  R1861     -5.8619666099548340e-01
    z[4,7,6]  R1862     -2.1355259418487549e-01
    z[4,7,6]  R1863     -5.2427347749471664e-02
    z[4,7,6]  R1864     2.1352234482765198e-01
    z[4,7,6]  R1865     -1.0542669147253036e-01
    z[4,7,6]  R1866     -1.6958503052592278e-02
    z[4,7,6]  R1867     -4.8897020518779755e-02
    z[7,4,0]  R38       1
    z[7,4,0]  R65       -1
    z[7,4,0]  R1868     -1
    z[7,4,0]  R1869     1
    z[7,4,0]  R1882     0.831761360168457
    z[7,4,0]  R1883     9.2205941677093506e-01
    z[7,4,0]  R1884     8.5395079851150513e-01
    z[7,4,0]  R1885     7.1274155378341675e-01
    z[7,4,0]  R1886     8.4566819667816162e-01
    z[7,4,0]  R1887     6.3203769922256470e-01
    z[7,4,0]  R1888     6.9810485839843750e-01
    z[7,4,0]  R1889     -1.6135847568511963e-01
    z[7,4,0]  R1890     -1.4748410880565643e-01
    z[7,4,0]  R1891     1.5411005914211273e-01
    z[7,4,0]  R1892     -2.0003539323806763e-01
    z[7,4,0]  R1893     -5.4264968633651733e-01
    z[7,4,0]  R1894     -5.2113640308380127e-01
    z[7,4,0]  R1895     -5.5860871076583862e-01
    z[7,4,0]  R1896     -1.8229384720325470e-01
    z[7,4,0]  R1897     -4.6869260072708130e-01
    z[7,4,0]  R1898     -4.7543257474899292e-01
    z[7,4,0]  R1899     -5.8686113357543945e-01
    z[7,4,0]  R1900     -2.1261937916278839e-01
    z[7,4,0]  R1901     -5.0665266811847687e-02
    z[7,4,0]  R1902     -2.2017173469066620e-01
    z[7,4,0]  R1903     -1.0050955414772034e-01
    z[7,4,0]  R1904     -3.8916191458702087e-01
    z[7,4,0]  R1905     3.5358372330665588e-01
    z[7,4,0]  R1906     1.0035784542560577e-01
    z[7,4,0]  R1907     -3.2422360777854919e-01
    z[7,4,0]  R1908     5.0990432500839233e-01
    z[7,4,0]  R1909     7.3181706666946411e-01
    z[7,4,0]  R1910     3.9688837714493275e-03
    z[7,4,0]  R1911     -7.7977222204208374e-01
    z[7,4,0]  R1912     -0.8011514544487
    z[7,4,0]  R1913     -6.4584916830062866e-01
    z[7,4,0]  R1914     -6.4749133586883545e-01
    z[7,4,0]  R1915     -0.866128146648407
    z[7,4,0]  R1916     -5.2334684133529663e-01
    z[7,4,0]  R1917     -9.0055245161056519e-01
    z[7,4,0]  R1918     -5.1530826091766357e-01
    z[7,4,0]  R1919     -4.6573814749717712e-01
    z[7,4,0]  R1920     4.4696500897407532e-01
    z[7,4,0]  R1921     0.421758234500885
    z[7,4,0]  R1922     -0.128040611743927
    z[7,4,0]  R1923     -2.0239213481545448e-02
    z[7,4,0]  R1924     -7.9799783229827881e-01
    z[7,4,0]  R1925     -1.4799687266349792e-01
    z[7,4,0]  R1926     -3.1945714354515076e-01
    z[7,4,0]  R1927     0.718023955821991
    z[7,4,0]  R1928     1.3686415553092957e-01
    z[7,4,0]  R1929     2.3470732569694519e-01
    z[7,4,0]  R1930     1.2830194830894470e-01
    z[7,4,0]  R1931     -2.8881579637527466e-02
    z[7,4,0]  R1932     -1.2167088687419891e-01
    z[7,4,0]  R1933     2.9862058162689209e-01
    z[7,4,0]  R1934     -2.7959802746772766e-01
    z[7,4,0]  R1935     6.2875278294086456e-02
    z[7,4,0]  R1936     -0.276602566242218
    z[7,4,0]  R1937     -7.9921597242355347e-01
    z[7,4,0]  R1938     -1.3351860642433167e-01
    z[7,4,0]  R1939     -0.386550635099411
    z[7,4,0]  R1940     1.8768247961997986e-01
    z[7,4,0]  R1941     0.360411673784256
    z[7,4,0]  R1942     0.910633385181427
    z[7,4,0]  R1943     8.6385035514831543e-01
    z[7,4,0]  R1944     9.6000903844833374e-01
    z[7,4,0]  R1945     8.4667760133743286e-01
    z[7,4,0]  R1946     8.0817246437072754e-01
    z[7,4,0]  R1947     5.7434415817260742e-01
    z[7,4,0]  R1948     7.5250571966171265e-01
    z[7,4,0]  R1949     -1.9204263389110565e-01
    z[7,4,0]  R1950     -3.1876403093338013e-01
    z[7,4,0]  R1951     -1.9027492403984070e-01
    z[7,4,0]  R1952     -2.0767155289649963e-01
    z[7,4,0]  R1953     -4.4648265838623047e-01
    z[7,4,0]  R1954     -0.127395898103714
    z[7,4,0]  R1955     -6.2777155637741089e-01
    z[7,4,0]  R1956     -2.4436137080192566e-01
    z[7,4,0]  R1957     -2.9672563076019287e-01
    z[7,4,0]  R1958     -5.6023168563842773e-01
    z[7,4,0]  R1959     -2.2943228483200073e-01
    z[7,4,0]  R1960     -3.3806160092353821e-01
    z[7,4,0]  R1961     -3.3537802100181580e-01
    z[7,4,0]  R1962     -2.8405603766441345e-01
    z[7,4,0]  R1963     -2.2720962762832642e-01
    z[7,4,0]  R1964     2.2040279582142830e-02
    z[7,4,0]  R1965     -0.0471559539437294
    z[7,4,0]  R1966     1.5134997665882111e-01
    z[7,4,0]  R1967     3.6984187364578247e-01
    z[7,4,0]  R1968     -5.7003587484359741e-01
    z[7,4,0]  R1969     1.9555503129959106e-01
    z[7,4,0]  R1970     -5.0418472290039062e-01
    z[7,4,0]  R1971     -0.566318929195404
    z[7,4,0]  R1972     -2.7169395238161087e-02
    z[7,4,0]  R1973     4.0753343701362610e-01
    z[7,4,0]  R1974     1.9366508722305298e-01
    z[7,4,0]  R1975     -7.1623331308364868e-01
    z[7,4,0]  R1976     3.7577813863754272e-01
    z[7,4,0]  R1977     1.7083208262920380e-01
    z[7,4,0]  R1978     1.7021400853991508e-03
    z[7,4,0]  R1979     3.0672988295555115e-01
    z[7,4,0]  R1980     3.3502897620201111e-01
    z[7,4,0]  R1981     -4.8495680093765259e-01
    z[7,4,0]  R1982     -7.5788080692291260e-01
    z[7,4,0]  R1983     -2.8400537371635437e-01
    z[7,4,0]  R1984     -1.9477254152297974e-01
    z[7,4,0]  R1985     -4.4092038273811340e-01
    z[7,4,0]  R1986     1.6808068752288818e-01
    z[7,4,0]  R1987     3.0650016665458679e-01
    z[7,4,0]  R1988     -4.8207080364227295e-01
    z[7,4,0]  R1989     0.021457489579916
    z[7,4,0]  R1990     1.5523508191108704e-01
    z[7,4,0]  R1991     1.5136989951133728e-01
    z[7,4,0]  R1992     1.7610202729701996e-01
    z[7,4,0]  R1993     1.2261650711297989e-01
    z[7,4,0]  R1994     -5.4844474792480469e-01
    z[7,4,0]  R1995     -5.2444231510162354e-01
    z[7,4,0]  R1996     -4.6172222495079041e-01
    z[7,4,0]  R1997     -0.569028913974762
    z[7,4,0]  R1998     -5.6284797191619873e-01
    z[7,4,0]  R1999     -4.1871842741966248e-01
    z[7,4,0]  R2000     -5.5132120847702026e-01
    z[7,4,0]  R2001     1.2665323913097382e-01
    z[7,4,0]  R2002     1.7611831426620483e-01
    z[7,4,0]  R2003     4.7245588898658752e-01
    z[7,4,0]  R2004     1.6912671923637390e-01
    z[7,4,0]  R2005     -5.5089020729064941e-01
    z[7,4,0]  R2006     -5.6645786762237549e-01
    z[7,4,0]  R2007     -4.5239266753196716e-01
    z[7,4,0]  R2008     -7.2609871625900269e-02
    z[7,4,0]  R2009     2.0316435396671295e-01
    z[7,4,0]  R2010     1.5671840310096741e-01
    z[7,4,0]  R2011     1.0520647466182709e-01
    z[7,4,1]  R39       1
    z[7,4,1]  R66       -1
    z[7,4,1]  R1870     -1
    z[7,4,1]  R1871     1
    z[7,4,1]  R1882     1.1788117140531540e-01
    z[7,4,1]  R1883     -5.7180680334568024e-02
    z[7,4,1]  R1884     -1.2512235343456268e-01
    z[7,4,1]  R1885     -2.2064872086048126e-01
    z[7,4,1]  R1886     -0.262986958026886
    z[7,4,1]  R1887     -2.0322947204113007e-01
    z[7,4,1]  R1888     1.2710350751876831e-01
    z[7,4,1]  R1889     -6.1658447980880737e-01
    z[7,4,1]  R1890     -5.7900321483612061e-01
    z[7,4,1]  R1891     -6.4628767967224121e-01
    z[7,4,1]  R1892     1.9738541543483734e-01
    z[7,4,1]  R1893     6.6613882780075073e-01
    z[7,4,1]  R1894     7.3474103212356567e-01
    z[7,4,1]  R1895     7.4525296688079834e-02
    z[7,4,1]  R1896     -2.2945592645555735e-03
    z[7,4,1]  R1897     4.4102672487497330e-02
    z[7,4,1]  R1898     5.7743549346923828e-01
    z[7,4,1]  R1899     5.3636454045772552e-02
    z[7,4,1]  R1900     4.0496596693992615e-01
    z[7,4,1]  R1901     6.5669816732406616e-01
    z[7,4,1]  R1902     -6.7782026529312134e-01
    z[7,4,1]  R1903     -8.0523324012756348e-01
    z[7,4,1]  R1904     -5.9223777055740356e-01
    z[7,4,1]  R1905     -7.8164649009704590e-01
    z[7,4,1]  R1906     -7.4711662530899048e-01
    z[7,4,1]  R1907     -6.4996057748794556e-01
    z[7,4,1]  R1908     -0.512759268283844
    z[7,4,1]  R1909     -5.2422821521759033e-01
    z[7,4,1]  R1910     -4.5910209417343140e-01
    z[7,4,1]  R1911     1.1272864043712616e-01
    z[7,4,1]  R1912     -3.4529095888137817e-01
    z[7,4,1]  R1913     7.0104561746120453e-03
    z[7,4,1]  R1914     4.6046581119298935e-03
    z[7,4,1]  R1915     -5.4499473422765732e-02
    z[7,4,1]  R1916     1.7552489042282104e-01
    z[7,4,1]  R1917     -9.6060343086719513e-02
    z[7,4,1]  R1918     7.1108184754848480e-02
    z[7,4,1]  R1919     -4.3063253164291382e-01
    z[7,4,1]  R1920     2.3395034670829773e-01
    z[7,4,1]  R1921     1.2475195527076721e-01
    z[7,4,1]  R1922     -6.4332002401351929e-01
    z[7,4,1]  R1923     8.6006671190261841e-02
    z[7,4,1]  R1924     5.9089845418930054e-01
    z[7,4,1]  R1925     6.4706325531005859e-01
    z[7,4,1]  R1926     0.686769425868988
    z[7,4,1]  R1927     2.7850097417831421e-01
    z[7,4,1]  R1928     9.1011798381805420e-01
    z[7,4,1]  R1929     8.5468226671218872e-01
    z[7,4,1]  R1930     9.0942496061325073e-01
    z[7,4,1]  R1931     7.3431169986724854e-01
    z[7,4,1]  R1932     -7.3055410385131836e-01
    z[7,4,1]  R1933     -6.7307293415069580e-01
    z[7,4,1]  R1934     -7.0669221878051758e-01
    z[7,4,1]  R1935     -6.1387270689010620e-01
    z[7,4,1]  R1936     9.0618662536144257e-02
    z[7,4,1]  R1937     5.9256780147552490e-01
    z[7,4,1]  R1938     6.7437773942947388e-01
    z[7,4,1]  R1939     7.3519986867904663e-01
    z[7,4,1]  R1940     5.2971726655960083e-01
    z[7,4,1]  R1941     4.3057283759117126e-01
    z[7,4,1]  R1942     1.1460566520690918e-01
    z[7,4,1]  R1943     2.5463491678237915e-02
    z[7,4,1]  R1944     -1.4563414454460144e-01
    z[7,4,1]  R1945     -1.5058070421218872e-01
    z[7,4,1]  R1946     -2.8103342652320862e-01
    z[7,4,1]  R1947     -3.2171329855918884e-01
    z[7,4,1]  R1948     -4.3177595734596252e-01
    z[7,4,1]  R1949     -5.6893426179885864e-01
    z[7,4,1]  R1950     -6.2713003158569336e-01
    z[7,4,1]  R1951     -3.3543795347213745e-01
    z[7,4,1]  R1952     -5.8244132995605469e-01
    z[7,4,1]  R1953     -6.3318848609924316e-01
    z[7,4,1]  R1954     -5.3689426183700562e-01
    z[7,4,1]  R1955     -4.2378321290016174e-01
    z[7,4,1]  R1956     8.1636792421340942e-01
    z[7,4,1]  R1957     8.2112735509872437e-01
    z[7,4,1]  R1958     7.6580405235290527e-01
    z[7,4,1]  R1959     7.6226824522018433e-01
    z[7,4,1]  R1960     7.1772933006286621e-01
    z[7,4,1]  R1961     7.8388285636901855e-01
    z[7,4,1]  R1962     -7.8066468238830566e-01
    z[7,4,1]  R1963     -5.2805393934249878e-01
    z[7,4,1]  R1964     -4.1029801964759827e-01
    z[7,4,1]  R1965     -2.5612908601760864e-01
    z[7,4,1]  R1966     -3.9278411865234375e-01
    z[7,4,1]  R1967     -5.1957917213439941e-01
    z[7,4,1]  R1968     7.5354062020778656e-02
    z[7,4,1]  R1969     6.4115965366363525e-01
    z[7,4,1]  R1970     6.8383723497390747e-01
    z[7,4,1]  R1971     6.3187509775161743e-01
    z[7,4,1]  R1972     -0.740505576133728
    z[7,4,1]  R1973     -7.3246729373931885e-01
    z[7,4,1]  R1974     -5.8310168981552124e-01
    z[7,4,1]  R1975     3.3649951219558716e-01
    z[7,4,1]  R1976     3.6887574195861816e-01
    z[7,4,1]  R1977     3.4796217083930969e-01
    z[7,4,1]  R1978     4.5040979981422424e-01
    z[7,4,1]  R1979     5.7220572233200073e-01
    z[7,4,1]  R1980     5.9585189819335938e-01
    z[7,4,1]  R1981     6.1750531196594238e-01
    z[7,4,1]  R1982     1.4881081879138947e-01
    z[7,4,1]  R1983     7.4363607168197632e-01
    z[7,4,1]  R1984     0.666480302810669
    z[7,4,1]  R1985     5.0507462024688721e-01
    z[7,4,1]  R1986     9.4165974855422974e-01
    z[7,4,1]  R1987     9.1493850946426392e-01
    z[7,4,1]  R1988     3.8173234462738037e-01
    z[7,4,1]  R1989     9.3927145004272461e-01
    z[7,4,1]  R1990     0.92210853099823
    z[7,4,1]  R1991     9.1048997640609741e-01
    z[7,4,1]  R1992     0.601198136806488
    z[7,4,1]  R1993     4.2409190535545349e-01
    z[7,4,1]  R1994     0.558688759803772
    z[7,4,1]  R1995     3.3374351263046265e-01
    z[7,4,1]  R1996     0.828164279460907
    z[7,4,1]  R1997     6.3915222883224487e-01
    z[7,4,1]  R1998     0.666843056678772
    z[7,4,1]  R1999     7.4222880601882935e-01
    z[7,4,1]  R2000     4.9861952662467957e-01
    z[7,4,1]  R2001     0.881424605846405
    z[7,4,1]  R2002     -4.2620584368705750e-01
    z[7,4,1]  R2003     -3.2889935374259949e-01
    z[7,4,1]  R2004     3.7889429926872253e-01
    z[7,4,1]  R2005     4.2418941855430603e-01
    z[7,4,1]  R2006     6.4593595266342163e-01
    z[7,4,1]  R2007     7.7900153398513794e-01
    z[7,4,1]  R2008     8.7439858913421631e-01
    z[7,4,1]  R2009     7.5653755664825439e-01
    z[7,4,1]  R2010     7.9470765590667725e-01
    z[7,4,1]  R2011     3.3972927927970886e-01
    z[7,4,2]  R40       1
    z[7,4,2]  R67       -1
    z[7,4,2]  R1872     -1
    z[7,4,2]  R1873     1
    z[7,4,2]  R1882     1.5736088156700134e-01
    z[7,4,2]  R1883     3.1619224697351456e-02
    z[7,4,2]  R1884     -2.8328439593315125e-01
    z[7,4,2]  R1885     1.6663897037506104e-01
    z[7,4,2]  R1886     4.3664994835853577e-01
    z[7,4,2]  R1887     3.6473900079727173e-01
    z[7,4,2]  R1888     9.3046009540557861e-02
    z[7,4,2]  R1889     2.6254189014434814e-01
    z[7,4,2]  R1890     0.255932092666626
    z[7,4,2]  R1891     3.0451336503028870e-01
    z[7,4,2]  R1892     -7.3511481285095215e-01
    z[7,4,2]  R1893     -3.7339490652084351e-01
    z[7,4,2]  R1894     -2.5605386495590210e-01
    z[7,4,2]  R1895     -3.1785136461257935e-01
    z[7,4,2]  R1896     -8.7365549802780151e-01
    z[7,4,2]  R1897     -6.0707551240921021e-01
    z[7,4,2]  R1898     -3.5549452900886536e-01
    z[7,4,2]  R1899     -0.730562686920166
    z[7,4,2]  R1900     -7.2983330488204956e-01
    z[7,4,2]  R1901     -5.8316880464553833e-01
    z[7,4,2]  R1902     -5.9866684675216675e-01
    z[7,4,2]  R1903     -3.0322751402854919e-01
    z[7,4,2]  R1904     -2.2276845574378967e-01
    z[7,4,2]  R1905     -8.7085880339145660e-02
    z[7,4,2]  R1906     -1.8152470886707306e-01
    z[7,4,2]  R1907     -2.1618537604808807e-01
    z[7,4,2]  R1908     -4.0154952555894852e-02
    z[7,4,2]  R1909     1.2722371518611908e-01
    z[7,4,2]  R1910     7.7772176265716553e-01
    z[7,4,2]  R1911     -2.9540473222732544e-01
    z[7,4,2]  R1912     3.6096596717834473e-01
    z[7,4,2]  R1913     -3.6073359847068787e-01
    z[7,4,2]  R1914     -0.50264972448349
    z[7,4,2]  R1915     -1.4566515386104584e-01
    z[7,4,2]  R1916     -5.9669876098632812e-01
    z[7,4,2]  R1917     -4.2036834359169006e-01
    z[7,4,2]  R1918     -0.81169593334198
    z[7,4,2]  R1919     -8.8499732315540314e-02
    z[7,4,2]  R1920     5.6356781721115112e-01
    z[7,4,2]  R1921     6.6970270872116089e-01
    z[7,4,2]  R1922     2.8186139464378357e-01
    z[7,4,2]  R1923     -0.647044837474823
    z[7,4,2]  R1924     -7.7119171619415283e-02
    z[7,4,2]  R1925     -5.6557118892669678e-01
    z[7,4,2]  R1926     -4.3069493770599365e-01
    z[7,4,2]  R1927     4.9036827683448792e-01
    z[7,4,2]  R1928     6.6082730889320374e-02
    z[7,4,2]  R1929     1.8462300300598145e-01
    z[7,4,2]  R1930     -1.1157387867569923e-02
    z[7,4,2]  R1931     -5.1228034496307373e-01
    z[7,4,2]  R1932     2.6303809881210327e-01
    z[7,4,2]  R1933     5.2225303649902344e-01
    z[7,4,2]  R1934     1.6468265652656555e-01
    z[7,4,2]  R1935     -3.2448098063468933e-01
    z[7,4,2]  R1936     -0.89305579662323
    z[7,4,2]  R1937     -5.2912008017301559e-02
    z[7,4,2]  R1938     -6.0445809364318848e-01
    z[7,4,2]  R1939     -3.9572045207023621e-01
    z[7,4,2]  R1940     5.8833497762680054e-01
    z[7,4,2]  R1941     6.8056142330169678e-01
    z[7,4,2]  R1942     -1.1033765971660614e-01
    z[7,4,2]  R1943     -2.3953357338905334e-01
    z[7,4,2]  R1944     -3.6573097109794617e-02
    z[7,4,2]  R1945     2.4638488888740540e-01
    z[7,4,2]  R1946     -4.1139110922813416e-02
    z[7,4,2]  R1947     -7.4872829020023346e-02
    z[7,4,2]  R1948     0.201263889670372
    z[7,4,2]  R1949     5.1678277552127838e-02
    z[7,4,2]  R1950     -2.8553009033203125e-01
    z[7,4,2]  R1951     2.0388789474964142e-01
    z[7,4,2]  R1952     3.0496206879615784e-01
    z[7,4,2]  R1953     1.5170499682426453e-01
    z[7,4,2]  R1954     3.4554663300514221e-01
    z[7,4,2]  R1955     4.3080207705497742e-01
    z[7,4,2]  R1956     -4.5506325364112854e-01
    z[7,4,2]  R1957     -4.5871418714523315e-01
    z[7,4,2]  R1958     -2.5207144021987915e-01
    z[7,4,2]  R1959     -5.3996407985687256e-01
    z[7,4,2]  R1960     -4.7224959731101990e-01
    z[7,4,2]  R1961     -4.2015898227691650e-01
    z[7,4,2]  R1962     -2.5683504343032837e-01
    z[7,4,2]  R1963     -0.00099270383361727
    z[7,4,2]  R1964     3.0738282203674316e-01
    z[7,4,2]  R1965     8.9336413145065308e-01
    z[7,4,2]  R1966     1.6484551131725311e-01
    z[7,4,2]  R1967     -5.5105859041213989e-01
    z[7,4,2]  R1968     -5.1811766624450684e-01
    z[7,4,2]  R1969     5.8941847085952759e-01
    z[7,4,2]  R1970     -3.3432438969612122e-01
    z[7,4,2]  R1971     -0.340804785490036
    z[7,4,2]  R1972     4.6320453286170959e-01
    z[7,4,2]  R1973     -5.8638896793127060e-02
    z[7,4,2]  R1974     -0.0315396711230278
    z[7,4,2]  R1975     -2.2471982240676880e-01
    z[7,4,2]  R1976     6.4761632680892944e-01
    z[7,4,2]  R1977     4.8071259260177612e-01
    z[7,4,2]  R1978     0.53521329164505
    z[7,4,2]  R1979     1.8668556213378906e-01
    z[7,4,2]  R1980     2.4896225333213806e-01
    z[7,4,2]  R1981     -3.5354679822921753e-01
    z[7,4,2]  R1982     -2.5364935398101807e-01
    z[7,4,2]  R1983     -5.8455985784530640e-01
    z[7,4,2]  R1984     -4.2960298061370850e-01
    z[7,4,2]  R1985     -3.8094425201416016e-01
    z[7,4,2]  R1986     -4.5056834816932678e-02
    z[7,4,2]  R1987     -1.1783744394779205e-01
    z[7,4,2]  R1988     -5.1590472459793091e-01
    z[7,4,2]  R1989     3.7413392215967178e-02
    z[7,4,2]  R1990     -5.4214667528867722e-02
    z[7,4,2]  R1991     -2.0445628464221954e-01
    z[7,4,2]  R1992     5.7721412181854248e-01
    z[7,4,2]  R1993     3.1412672996520996e-01
    z[7,4,2]  R1994     -4.0260905027389526e-01
    z[7,4,2]  R1995     -6.7133563756942749e-01
    z[7,4,2]  R1996     5.5074214935302734e-02
    z[7,4,2]  R1997     -1.4470370113849640e-01
    z[7,4,2]  R1998     -1.5852785110473633e-01
    z[7,4,2]  R1999     5.9551354497671127e-03
    z[7,4,2]  R2000     -2.4570623040199280e-01
    z[7,4,2]  R2001     -1.9592528045177460e-01
    z[7,4,2]  R2002     4.2542022466659546e-01
    z[7,4,2]  R2003     3.2853364944458008e-01
    z[7,4,2]  R2004     5.1375579833984375e-01
    z[7,4,2]  R2005     -5.5606234073638916e-01
    z[7,4,2]  R2006     -2.3779833316802979e-01
    z[7,4,2]  R2007     -1.7113822698593140e-01
    z[7,4,2]  R2008     0.0406145378947258
    z[7,4,2]  R2009     -3.0740597844123840e-01
    z[7,4,2]  R2010     2.9896411299705505e-01
    z[7,4,2]  R2011     -5.1972858607769012e-02
    z[7,4,3]  R41       1
    z[7,4,3]  R68       -1
    z[7,4,3]  R1874     -1
    z[7,4,3]  R1875     1
    z[7,4,3]  R1882     -0.504252552986145
    z[7,4,3]  R1883     -2.4172352254390717e-01
    z[7,4,3]  R1884     -3.7082454562187195e-01
    z[7,4,3]  R1885     -4.2431572079658508e-01
    z[7,4,3]  R1886     -1.4273391105234623e-02
    z[7,4,3]  R1887     -4.8467060923576355e-01
    z[7,4,3]  R1888     -2.1092857420444489e-01
    z[7,4,3]  R1889     -1.8700738251209259e-01
    z[7,4,3]  R1890     5.6740206480026245e-01
    z[7,4,3]  R1891     -1.0911568999290466e-01
    z[7,4,3]  R1892     -4.2100772261619568e-02
    z[7,4,3]  R1893     -2.1732452511787415e-01
    z[7,4,3]  R1894     -0.109881691634655
    z[7,4,3]  R1895     -1.2937353551387787e-01
    z[7,4,3]  R1896     -1.6076089814305305e-02
    z[7,4,3]  R1897     5.3015798330307007e-02
    z[7,4,3]  R1898     -4.6307405829429626e-01
    z[7,4,3]  R1899     -1.3483323156833649e-02
    z[7,4,3]  R1900     1.8107822537422180e-01
    z[7,4,3]  R1901     -1.2303494662046432e-01
    z[7,4,3]  R1902     1.1183109134435654e-01
    z[7,4,3]  R1903     4.8025703430175781e-01
    z[7,4,3]  R1904     -4.1683989763259888e-01
    z[7,4,3]  R1905     2.5238654017448425e-01
    z[7,4,3]  R1906     1.8978676199913025e-01
    z[7,4,3]  R1907     -3.0419981479644775e-01
    z[7,4,3]  R1908     5.2527725696563721e-01
    z[7,4,3]  R1909     2.6501783728599548e-01
    z[7,4,3]  R1910     2.3504644632339478e-01
    z[7,4,3]  R1911     -3.0951502267271280e-03
    z[7,4,3]  R1912     -1.0267569869756699e-01
    z[7,4,3]  R1913     -9.5114611089229584e-02
    z[7,4,3]  R1914     -3.6320930719375610e-01
    z[7,4,3]  R1915     -3.2691818475723267e-01
    z[7,4,3]  R1916     1.5387211740016937e-01
    z[7,4,3]  R1917     1.2792519293725491e-02
    z[7,4,3]  R1918     9.7040623426437378e-02
    z[7,4,3]  R1919     -4.2647728323936462e-01
    z[7,4,3]  R1920     9.0673323720693588e-03
    z[7,4,3]  R1921     -3.9340332150459290e-01
    z[7,4,3]  R1922     3.7332630157470703e-01
    z[7,4,3]  R1923     -4.8981118947267532e-02
    z[7,4,3]  R1924     4.3991249054670334e-02
    z[7,4,3]  R1925     -1.4338363707065582e-01
    z[7,4,3]  R1926     -1.6163422167301178e-01
    z[7,4,3]  R1927     -2.2544270753860474e-01
    z[7,4,3]  R1928     -3.7036520242691040e-01
    z[7,4,3]  R1929     -3.8125243782997131e-01
    z[7,4,3]  R1930     -3.3912095427513123e-01
    z[7,4,3]  R1931     1.9066568464040756e-02
    z[7,4,3]  R1932     3.4886658191680908e-01
    z[7,4,3]  R1933     9.6905358135700226e-02
    z[7,4,3]  R1934     4.7653075307607651e-02
    z[7,4,3]  R1935     1.5867911279201508e-01
    z[7,4,3]  R1936     -4.2687293142080307e-02
    z[7,4,3]  R1937     -9.7977332770824432e-03
    z[7,4,3]  R1938     -6.8670073524117470e-03
    z[7,4,3]  R1939     -2.0256450772285461e-01
    z[7,4,3]  R1940     -5.2521169185638428e-01
    z[7,4,3]  R1941     -3.5196962952613831e-01
    z[7,4,3]  R1942     -3.0676627159118652e-01
    z[7,4,3]  R1943     -3.7245699763298035e-01
    z[7,4,3]  R1944     -2.3310832679271698e-02
    z[7,4,3]  R1945     -2.8134772181510925e-01
    z[7,4,3]  R1946     -1.6613277792930603e-01
    z[7,4,3]  R1947     -7.2090911865234375e-01
    z[7,4,3]  R1948     3.1365206837654114e-01
    z[7,4,3]  R1949     3.5603219270706177e-01
    z[7,4,3]  R1950     5.1434355974197388e-01
    z[7,4,3]  R1951     7.0499561727046967e-02
    z[7,4,3]  R1952     -1.6654946375638247e-03
    z[7,4,3]  R1953     1.5276117250323296e-02
    z[7,4,3]  R1954     -4.7179181128740311e-02
    z[7,4,3]  R1955     -1.7511065304279327e-01
    z[7,4,3]  R1956     2.0056959986686707e-01
    z[7,4,3]  R1957     -2.2695591673254967e-02
    z[7,4,3]  R1958     -6.3069827854633331e-02
    z[7,4,3]  R1959     1.6770876944065094e-01
    z[7,4,3]  R1960     1.6817204654216766e-01
    z[7,4,3]  R1961     2.3151952773332596e-02
    z[7,4,3]  R1962     2.6901695132255554e-01
    z[7,4,3]  R1963     9.3601889908313751e-02
    z[7,4,3]  R1964     1.2430024892091751e-01
    z[7,4,3]  R1965     3.3441290725022554e-03
    z[7,4,3]  R1966     3.0803942680358887e-01
    z[7,4,3]  R1967     2.7731612324714661e-01
    z[7,4,3]  R1968     -1.8918864428997040e-01
    z[7,4,3]  R1969     -2.8639551997184753e-01
    z[7,4,3]  R1970     2.2982136905193329e-01
    z[7,4,3]  R1971     3.6958608776330948e-02
    z[7,4,3]  R1972     2.4177664518356323e-01
    z[7,4,3]  R1973     3.7974965572357178e-01
    z[7,4,3]  R1974     1.0621663928031921e-01
    z[7,4,3]  R1975     -2.0878523588180542e-01
    z[7,4,3]  R1976     -1.9266463816165924e-01
    z[7,4,3]  R1977     -0.259590208530426
    z[7,4,3]  R1978     -3.4287315607070923e-01
    z[7,4,3]  R1979     -1.7056691646575928e-01
    z[7,4,3]  R1980     -1.5326879918575287e-01
    z[7,4,3]  R1981     2.7780768275260925e-01
    z[7,4,3]  R1982     -2.1395921707153320e-01
    z[7,4,3]  R1983     -5.2395123988389969e-02
    z[7,4,3]  R1984     0.516957700252533
    z[7,4,3]  R1985     0.528457522392273
    z[7,4,3]  R1986     -2.6437327265739441e-01
    z[7,4,3]  R1987     -2.1248273551464081e-01
    z[7,4,3]  R1988     3.1534832715988159e-01
    z[7,4,3]  R1989     -0.283624529838562
    z[7,4,3]  R1990     -2.2017486393451691e-01
    z[7,4,3]  R1991     -2.1831075847148895e-01
    z[7,4,3]  R1992     -2.7722486853599548e-01
    z[7,4,3]  R1993     -2.7675676345825195e-01
    z[7,4,3]  R1994     4.1128787398338318e-01
    z[7,4,3]  R1995     3.1493067741394043e-01
    z[7,4,3]  R1996     2.9338827729225159e-01
    z[7,4,3]  R1997     1.9708785414695740e-01
    z[7,4,3]  R1998     -5.1215752959251404e-02
    z[7,4,3]  R1999     4.0755963325500488e-01
    z[7,4,3]  R2000     3.3523747324943542e-01
    z[7,4,3]  R2001     -2.8534629940986633e-01
    z[7,4,3]  R2002     1.2849889695644379e-01
    z[7,4,3]  R2003     1.1477474868297577e-01
    z[7,4,3]  R2004     -0.214838445186615
    z[7,4,3]  R2005     2.5786882638931274e-01
    z[7,4,3]  R2006     2.0320130884647369e-01
    z[7,4,3]  R2007     -1.7632950842380524e-01
    z[7,4,3]  R2008     -3.4535399079322815e-01
    z[7,4,3]  R2009     -1.1928913742303848e-01
    z[7,4,3]  R2010     -2.3364393413066864e-01
    z[7,4,3]  R2011     7.0739632844924927e-01
    z[7,4,4]  R42       1
    z[7,4,4]  R69       -1
    z[7,4,4]  R1876     -1
    z[7,4,4]  R1877     1
    z[7,4,4]  R1882     -9.3567736446857452e-02
    z[7,4,4]  R1883     -4.1627362370491028e-03
    z[7,4,4]  R1884     -1.7485836520791054e-02
    z[7,4,4]  R1885     -3.9552173018455505e-01
    z[7,4,4]  R1886     -5.4580219089984894e-02
    z[7,4,4]  R1887     4.1839987039566040e-01
    z[7,4,4]  R1888     5.4671669006347656e-01
    z[7,4,4]  R1889     -4.9099615216255188e-01
    z[7,4,4]  R1890     1.4081904292106628e-01
    z[7,4,4]  R1891     1.8393313884735107e-01
    z[7,4,4]  R1892     -1.8558960407972336e-02
    z[7,4,4]  R1893     2.4832665920257568e-01
    z[7,4,4]  R1894     -2.2210772335529327e-01
    z[7,4,4]  R1895     6.6949248313903809e-01
    z[7,4,4]  R1896     3.9261576533317566e-01
    z[7,4,4]  R1897     6.2186169624328613e-01
    z[7,4,4]  R1898     1.2779118493199348e-02
    z[7,4,4]  R1899     -1.0554113984107971e-01
    z[7,4,4]  R1900     -3.8992649316787720e-01
    z[7,4,4]  R1901     -1.0634469240903854e-01
    z[7,4,4]  R1902     3.4463945031166077e-01
    z[7,4,4]  R1903     3.5495623946189880e-02
    z[7,4,4]  R1904     4.9213263392448425e-01
    z[7,4,4]  R1905     3.8332742452621460e-01
    z[7,4,4]  R1906     2.8598508238792419e-01
    z[7,4,4]  R1907     -1.3394100964069366e-01
    z[7,4,4]  R1908     -4.4146808981895447e-01
    z[7,4,4]  R1909     -2.3624691367149353e-01
    z[7,4,4]  R1910     -2.4334377050399780e-01
    z[7,4,4]  R1911     -4.7691500186920166e-01
    z[7,4,4]  R1912     2.7066943049430847e-01
    z[7,4,4]  R1913     5.8024022728204727e-02
    z[7,4,4]  R1914     -0.0924634113907814
    z[7,4,4]  R1915     1.2324440479278564e-01
    z[7,4,4]  R1916     1.5061776340007782e-01
    z[7,4,4]  R1917     -9.0359859168529510e-03
    z[7,4,4]  R1918     2.4451713263988495e-01
    z[7,4,4]  R1919     4.0662929415702820e-01
    z[7,4,4]  R1920     4.1545665264129639e-01
    z[7,4,4]  R1921     2.5468489527702332e-01
    z[7,4,4]  R1922     -4.1382867097854614e-01
    z[7,4,4]  R1923     -5.0561362504959106e-01
    z[7,4,4]  R1924     -3.6079576238989830e-03
    z[7,4,4]  R1925     -2.3232956230640411e-01
    z[7,4,4]  R1926     -2.8039303421974182e-01
    z[7,4,4]  R1927     -1.9280940294265747e-02
    z[7,4,4]  R1928     6.0891743749380112e-02
    z[7,4,4]  R1929     -3.9529930800199509e-02
    z[7,4,4]  R1930     -1.9411031901836395e-01
    z[7,4,4]  R1931     -4.1277384757995605e-01
    z[7,4,4]  R1932     -0.163431316614151
    z[7,4,4]  R1933     -1.5994679182767868e-02
    z[7,4,4]  R1934     -3.1727802753448486e-01
    z[7,4,4]  R1935     -1.9960127770900726e-01
    z[7,4,4]  R1936     -1.3360002636909485e-01
    z[7,4,4]  R1937     -5.7889252901077271e-02
    z[7,4,4]  R1938     -2.9758140444755554e-01
    z[7,4,4]  R1939     -1.0412189364433289e-01
    z[7,4,4]  R1940     2.4219968914985657e-01
    z[7,4,4]  R1941     2.4200481176376343e-01
    z[7,4,4]  R1942     -2.1605329215526581e-01
    z[7,4,4]  R1943     1.7489252984523773e-01
    z[7,4,4]  R1944     2.0510016381740570e-01
    z[7,4,4]  R1945     -1.3762958347797394e-01
    z[7,4,4]  R1946     -3.1085237860679626e-02
    z[7,4,4]  R1947     -1.3170013204216957e-02
    z[7,4,4]  R1948     2.0437940955162048e-01
    z[7,4,4]  R1949     -4.2405596375465393e-01
    z[7,4,4]  R1950     1.8331797420978546e-01
    z[7,4,4]  R1951     -1.0111937671899796e-01
    z[7,4,4]  R1952     1.5326094627380371e-01
    z[7,4,4]  R1953     -1.0808974504470825e-01
    z[7,4,4]  R1954     -4.3306279182434082e-01
    z[7,4,4]  R1955     3.9568793773651123e-01
    z[7,4,4]  R1956     1.1852863430976868e-01
    z[7,4,4]  R1957     1.4173589646816254e-01
    z[7,4,4]  R1958     -1.1155854910612106e-01
    z[7,4,4]  R1959     1.6141225397586823e-01
    z[7,4,4]  R1960     7.3472797870635986e-02
    z[7,4,4]  R1961     -5.3109776228666306e-02
    z[7,4,4]  R1962     -3.1306478381156921e-01
    z[7,4,4]  R1963     5.5055856704711914e-01
    z[7,4,4]  R1964     2.6041364669799805e-01
    z[7,4,4]  R1965     -2.0082934200763702e-01
    z[7,4,4]  R1966     -5.9684371948242188e-01
    z[7,4,4]  R1967     4.0093538165092468e-01
    z[7,4,4]  R1968     3.3297979831695557e-01
    z[7,4,4]  R1969     3.2784977555274963e-01
    z[7,4,4]  R1970     2.8037330508232117e-01
    z[7,4,4]  R1971     1.7677634954452515e-01
    z[7,4,4]  R1972     -2.9274460673332214e-01
    z[7,4,4]  R1973     7.1325547993183136e-02
    z[7,4,4]  R1974     6.5629088878631592e-01
    z[7,4,4]  R1975     -3.2649514079093933e-01
    z[7,4,4]  R1976     3.2498300075531006e-01
    z[7,4,4]  R1977     7.2262948751449585e-01
    z[7,4,4]  R1978     4.5627161860466003e-01
    z[7,4,4]  R1979     5.5931615829467773e-01
    z[7,4,4]  R1980     3.8837355375289917e-01
    z[7,4,4]  R1981     1.7797181010246277e-01
    z[7,4,4]  R1982     -2.0552127063274384e-01
    z[7,4,4]  R1983     -1.3959896750748158e-02
    z[7,4,4]  R1984     -1.4487208425998688e-01
    z[7,4,4]  R1985     -2.1121428906917572e-01
    z[7,4,4]  R1986     3.6880597472190857e-02
    z[7,4,4]  R1987     -5.3045139648020267e-03
    z[7,4,4]  R1988     -6.0588344931602478e-02
    z[7,4,4]  R1989     -9.6480615437030792e-02
    z[7,4,4]  R1990     -5.9477563947439194e-02
    z[7,4,4]  R1991     5.1358029246330261e-02
    z[7,4,4]  R1992     3.8351699709892273e-01
    z[7,4,4]  R1993     7.9344105720520020e-01
    z[7,4,4]  R1994     1.6153217852115631e-01
    z[7,4,4]  R1995     2.5022806599736214e-02
    z[7,4,4]  R1996     -0.0460795983672142
    z[7,4,4]  R1997     -2.1581773459911346e-01
    z[7,4,4]  R1998     -4.8652660101652145e-02
    z[7,4,4]  R1999     -1.3221164047718048e-01
    z[7,4,4]  R2000     -1.9343020021915436e-01
    z[7,4,4]  R2001     2.8541228175163269e-01
    z[7,4,4]  R2002     -1.5745188295841217e-01
    z[7,4,4]  R2003     -2.8067368548363447e-03
    z[7,4,4]  R2004     0.63071209192276
    z[7,4,4]  R2005     2.8684103488922119e-01
    z[7,4,4]  R2006     -1.5300603210926056e-01
    z[7,4,4]  R2007     1.2116441875696182e-01
    z[7,4,4]  R2008     -6.6729813814163208e-02
    z[7,4,4]  R2009     -3.4673970937728882e-01
    z[7,4,4]  R2010     -3.7755584716796875e-01
    z[7,4,4]  R2011     -4.7383829951286316e-01
    z[7,4,5]  R43       1
    z[7,4,5]  R70       -1
    z[7,4,5]  R1878     -1
    z[7,4,5]  R1879     1
    z[7,4,5]  R1882     4.2699400335550308e-02
    z[7,4,5]  R1883     -1.3356618583202362e-01
    z[7,4,5]  R1884     -3.2809235155582428e-02
    z[7,4,5]  R1885     5.3201489150524139e-02
    z[7,4,5]  R1886     -1.0581449419260025e-01
    z[7,4,5]  R1887     0.0456363819539547
    z[7,4,5]  R1888     -1.0163668543100357e-01
    z[7,4,5]  R1889     -3.2858392596244812e-01
    z[7,4,5]  R1890     2.8948080539703369e-01
    z[7,4,5]  R1891     2.4532085657119751e-01
    z[7,4,5]  R1892     -5.8020043373107910e-01
    z[7,4,5]  R1893     5.5503454059362411e-02
    z[7,4,5]  R1894     1.2265937775373459e-01
    z[7,4,5]  R1895     -2.0580182969570160e-01
    z[7,4,5]  R1896     -0.162678524851799
    z[7,4,5]  R1897     1.8457837402820587e-02
    z[7,4,5]  R1898     -1.9807896018028259e-01
    z[7,4,5]  R1899     -8.4291743114590645e-03
    z[7,4,5]  R1900     2.5627663731575012e-01
    z[7,4,5]  R1901     3.3952635526657104e-01
    z[7,4,5]  R1902     3.5490646958351135e-02
    z[7,4,5]  R1903     -9.9709741771221161e-02
    z[7,4,5]  R1904     -1.2336204200983047e-01
    z[7,4,5]  R1905     -0.200625479221344
    z[7,4,5]  R1906     -5.1801913976669312e-01
    z[7,4,5]  R1907     5.2026188373565674e-01
    z[7,4,5]  R1908     -3.2877799123525620e-02
    z[7,4,5]  R1909     -1.8231348693370819e-01
    z[7,4,5]  R1910     1.1712416261434555e-01
    z[7,4,5]  R1911     -1.7633208632469177e-01
    z[7,4,5]  R1912     1.3752581179141998e-01
    z[7,4,5]  R1913     -5.5856925249099731e-01
    z[7,4,5]  R1914     -2.0876045525074005e-01
    z[7,4,5]  R1915     -0.320121705532074
    z[7,4,5]  R1916     -2.7869519591331482e-01
    z[7,4,5]  R1917     1.1142909526824951e-02
    z[7,4,5]  R1918     -6.2896623276174068e-03
    z[7,4,5]  R1919     -2.5724676251411438e-01
    z[7,4,5]  R1920     5.0354021787643433e-01
    z[7,4,5]  R1921     -3.6257150769233704e-01
    z[7,4,5]  R1922     3.9444151520729065e-01
    z[7,4,5]  R1923     -5.5814504623413086e-01
    z[7,4,5]  R1924     5.5932231247425079e-02
    z[7,4,5]  R1925     -1.4626109972596169e-02
    z[7,4,5]  R1926     3.1677356362342834e-01
    z[7,4,5]  R1927     1.9272281229496002e-01
    z[7,4,5]  R1928     2.3736661300063133e-02
    z[7,4,5]  R1929     -1.2253225594758987e-01
    z[7,4,5]  R1930     5.9116680175065994e-02
    z[7,4,5]  R1931     -3.1366065144538879e-02
    z[7,4,5]  R1932     4.3536716699600220e-01
    z[7,4,5]  R1933     -3.9726775884628296e-01
    z[7,4,5]  R1934     2.3148950934410095e-01
    z[7,4,5]  R1935     -3.2445770502090454e-01
    z[7,4,5]  R1936     -2.2903005778789520e-01
    z[7,4,5]  R1937     3.3493004739284515e-02
    z[7,4,5]  R1938     -1.6680642962455750e-01
    z[7,4,5]  R1939     3.0079308152198792e-01
    z[7,4,5]  R1940     -5.6932557374238968e-02
    z[7,4,5]  R1941     1.9158987700939178e-01
    z[7,4,5]  R1942     -6.7718826234340668e-02
    z[7,4,5]  R1943     -1.5975473821163177e-01
    z[7,4,5]  R1944     1.3967177830636501e-02
    z[7,4,5]  R1945     -3.1440812349319458e-01
    z[7,4,5]  R1946     1.2479781359434128e-01
    z[7,4,5]  R1947     -0.0166141539812088
    z[7,4,5]  R1948     -2.0086416602134705e-01
    z[7,4,5]  R1949     -3.5767531394958496e-01
    z[7,4,5]  R1950     -1.8736422061920166e-01
    z[7,4,5]  R1951     -8.6757856607437134e-01
    z[7,4,5]  R1952     3.3237785100936890e-01
    z[7,4,5]  R1953     8.4211677312850952e-02
    z[7,4,5]  R1954     6.0218435525894165e-01
    z[7,4,5]  R1955     1.7615026235580444e-01
    z[7,4,5]  R1956     9.3072645366191864e-02
    z[7,4,5]  R1957     -5.5267107672989368e-03
    z[7,4,5]  R1958     -1.2235080450773239e-01
    z[7,4,5]  R1959     -5.0252329558134079e-02
    z[7,4,5]  R1960     1.0249210149049759e-01
    z[7,4,5]  R1961     5.2654266357421875e-02
    z[7,4,5]  R1962     -2.7082479000091553e-01
    z[7,4,5]  R1963     -1.8426083028316498e-01
    z[7,4,5]  R1964     5.4612624645233154e-01
    z[7,4,5]  R1965     -1.3940142095088959e-01
    z[7,4,5]  R1966     -9.8460555076599121e-02
    z[7,4,5]  R1967     1.3949838280677795e-01
    z[7,4,5]  R1968     -4.2687162756919861e-01
    z[7,4,5]  R1969     -3.6988869309425354e-02
    z[7,4,5]  R1970     -8.5948094725608826e-02
    z[7,4,5]  R1971     2.4168232083320618e-01
    z[7,4,5]  R1972     2.2038803994655609e-01
    z[7,4,5]  R1973     0.325942724943161
    z[7,4,5]  R1974     1.8155101686716080e-02
    z[7,4,5]  R1975     -3.7361851334571838e-01
    z[7,4,5]  R1976     -3.0973193049430847e-01
    z[7,4,5]  R1977     -1.5568171441555023e-01
    z[7,4,5]  R1978     -0.204054057598114
    z[7,4,5]  R1979     -1.0616850107908249e-02
    z[7,4,5]  R1980     -0.316983163356781
    z[7,4,5]  R1981     1.1278515309095383e-01
    z[7,4,5]  R1982     -4.6136081218719482e-01
    z[7,4,5]  R1983     1.2181588262319565e-01
    z[7,4,5]  R1984     -5.6798618286848068e-02
    z[7,4,5]  R1985     2.6877734065055847e-01
    z[7,4,5]  R1986     9.8095230758190155e-02
    z[7,4,5]  R1987     6.8847984075546265e-02
    z[7,4,5]  R1988     4.6843016147613525e-01
    z[7,4,5]  R1989     -4.8404913395643234e-02
    z[7,4,5]  R1990     -0.00689234584569931
    z[7,4,5]  R1991     -1.0875558108091354e-01
    z[7,4,5]  R1992     1.2592312693595886e-01
    z[7,4,5]  R1993     1.4616641215980053e-02
    z[7,4,5]  R1994     -0.0735788494348526
    z[7,4,5]  R1995     2.4920323491096497e-01
    z[7,4,5]  R1996     7.6562032103538513e-02
    z[7,4,5]  R1997     3.3623912930488586e-01
    z[7,4,5]  R1998     4.5428311824798584e-01
    z[7,4,5]  R1999     1.6750530898571014e-01
    z[7,4,5]  R2000     0.454328328371048
    z[7,4,5]  R2001     1.5757321380078793e-03
    z[7,4,5]  R2002     -7.0956653356552124e-01
    z[7,4,5]  R2003     -1.7349001765251160e-01
    z[7,4,5]  R2004     -1.7410913482308388e-02
    z[7,4,5]  R2005     2.4181802570819855e-01
    z[7,4,5]  R2006     2.8184035420417786e-01
    z[7,4,5]  R2007     3.3563607931137085e-01
    z[7,4,5]  R2008     1.0348308086395264e-01
    z[7,4,5]  R2009     -3.4906560182571411e-01
    z[7,4,5]  R2010     1.1178135871887207e-01
    z[7,4,5]  R2011     1.6751761734485626e-01
    z[7,4,6]  R44       1
    z[7,4,6]  R71       -1
    z[7,4,6]  R1880     -1
    z[7,4,6]  R1881     1
    z[7,4,6]  R1882     -6.8305768072605133e-02
    z[7,4,6]  R1883     -2.6315292716026306e-01
    z[7,4,6]  R1884     1.8965634703636169e-01
    z[7,4,6]  R1885     2.7610439062118530e-01
    z[7,4,6]  R1886     1.0315315425395966e-01
    z[7,4,6]  R1887     1.1893185228109360e-01
    z[7,4,6]  R1888     3.6621958017349243e-01
    z[7,4,6]  R1889     -3.7528967857360840e-01
    z[7,4,6]  R1890     3.8977968692779541e-01
    z[7,4,6]  R1891     -5.9992820024490356e-01
    z[7,4,6]  R1892     2.0464979112148285e-01
    z[7,4,6]  R1893     1.0193166881799698e-01
    z[7,4,6]  R1894     -2.1577247977256775e-01
    z[7,4,6]  R1895     2.7214100956916809e-01
    z[7,4,6]  R1896     -1.5039950609207153e-01
    z[7,4,6]  R1897     1.4134421944618225e-01
    z[7,4,6]  R1898     -2.4560080468654633e-01
    z[7,4,6]  R1899     -3.2802972197532654e-01
    z[7,4,6]  R1900     -8.7344385683536530e-02
    z[7,4,6]  R1901     -2.9046475887298584e-01
    z[7,4,6]  R1902     -3.3763226121664047e-02
    z[7,4,6]  R1903     8.7758764624595642e-02
    z[7,4,6]  R1904     1.3043515384197235e-01
    z[7,4,6]  R1905     -7.4390277266502380e-02
    z[7,4,6]  R1906     1.1244340986013412e-01
    z[7,4,6]  R1907     2.1105460822582245e-01
    z[7,4,6]  R1908     5.9766110032796860e-02
    z[7,4,6]  R1909     -1.1898516118526459e-01
    z[7,4,6]  R1910     2.3701743781566620e-01
    z[7,4,6]  R1911     1.8284708261489868e-01
    z[7,4,6]  R1912     7.6919443905353546e-02
    z[7,4,6]  R1913     3.5817271471023560e-01
    z[7,4,6]  R1914     -3.7950697541236877e-01
    z[7,4,6]  R1915     3.3026900142431259e-02
    z[7,4,6]  R1916     4.6391418576240540e-01
    z[7,4,6]  R1917     5.1949676126241684e-02
    z[7,4,6]  R1918     3.6134470254182816e-02
    z[7,4,6]  R1919     -4.2000627517700195e-01
    z[7,4,6]  R1920     4.0516536682844162e-02
    z[7,4,6]  R1921     8.3466731011867523e-02
    z[7,4,6]  R1922     -1.5520407259464264e-01
    z[7,4,6]  R1923     -0.0628967210650444
    z[7,4,6]  R1924     -5.4903768002986908e-02
    z[7,4,6]  R1925     -4.0593791007995605e-01
    z[7,4,6]  R1926     -1.8895855545997620e-01
    z[7,4,6]  R1927     -2.7942699193954468e-01
    z[7,4,6]  R1928     8.4527529776096344e-02
    z[7,4,6]  R1929     1.3570147752761841e-01
    z[7,4,6]  R1930     -1.3549934141337872e-02
    z[7,4,6]  R1931     1.6059705615043640e-01
    z[7,4,6]  R1932     -2.1056039631366730e-01
    z[7,4,6]  R1933     1.3259758055210114e-01
    z[7,4,6]  R1934     -4.8863810300827026e-01
    z[7,4,6]  R1935     -5.8619666099548340e-01
    z[7,4,6]  R1936     -2.1355259418487549e-01
    z[7,4,6]  R1937     -5.2427347749471664e-02
    z[7,4,6]  R1938     2.1352234482765198e-01
    z[7,4,6]  R1939     -1.0542669147253036e-01
    z[7,4,6]  R1940     -1.6958503052592278e-02
    z[7,4,6]  R1941     -4.8897020518779755e-02
    z[7,4,6]  R1942     -8.2207638770341873e-03
    z[7,4,6]  R1943     3.0077984556555748e-02
    z[7,4,6]  R1944     1.1415420472621918e-01
    z[7,4,6]  R1945     -5.2973654121160507e-02
    z[7,4,6]  R1946     -4.7121551632881165e-01
    z[7,4,6]  R1947     -2.0214863121509552e-01
    z[7,4,6]  R1948     -1.6218061745166779e-01
    z[7,4,6]  R1949     -4.4972071051597595e-01
    z[7,4,6]  R1950     -3.0051621794700623e-01
    z[7,4,6]  R1951     -2.0449618995189667e-01
    z[7,4,6]  R1952     6.2503278255462646e-01
    z[7,4,6]  R1953     5.9808266162872314e-01
    z[7,4,6]  R1954     -1.5400396287441254e-01
    z[7,4,6]  R1955     1.4986211061477661e-01
    z[7,4,6]  R1956     6.1714071780443192e-02
    z[7,4,6]  R1957     8.1549547612667084e-02
    z[7,4,6]  R1958     -6.8933911621570587e-02
    z[7,4,6]  R1959     -1.3431830704212189e-01
    z[7,4,6]  R1960     -3.2151910662651062e-01
    z[7,4,6]  R1961     3.0064353346824646e-01
    z[7,4,6]  R1962     1.3593773357570171e-02
    z[7,4,6]  R1963     -5.6895136833190918e-01
    z[7,4,6]  R1964     -0.59595787525177
    z[7,4,6]  R1965     -2.7257740497589111e-01
    z[7,4,6]  R1966     -5.7864898443222046e-01
    z[7,4,6]  R1967     0.180210143327713
    z[7,4,6]  R1968     2.6841688156127930e-01
    z[7,4,6]  R1969     -1.1127635091543198e-01
    z[7,4,6]  R1970     -1.6606491804122925e-01
    z[7,4,6]  R1971     2.6989388465881348e-01
    z[7,4,6]  R1972     -2.0887459814548492e-01
    z[7,4,6]  R1973     -1.9604563713073730e-01
    z[7,4,6]  R1974     4.2327558994293213e-01
    z[7,4,6]  R1975     -1.8302398920059204e-01
    z[7,4,6]  R1976     2.5425758957862854e-01
    z[7,4,6]  R1977     6.9547399878501892e-02
    z[7,4,6]  R1978     3.7853807210922241e-01
    z[7,4,6]  R1979     -4.4900503754615784e-01
    z[7,4,6]  R1980     -4.4264003634452820e-01
    z[7,4,6]  R1981     3.7005007266998291e-01
    z[7,4,6]  R1982     1.9560858607292175e-01
    z[7,4,6]  R1983     -8.2806371152400970e-02
    z[7,4,6]  R1984     2.0457211136817932e-01
    z[7,4,6]  R1985     -9.6177399158477783e-02
    z[7,4,6]  R1986     -4.6039126813411713e-02
    z[7,4,6]  R1987     7.1710072457790375e-02
    z[7,4,6]  R1988     -1.8217626214027405e-01
    z[7,4,6]  R1989     -1.5431955456733704e-01
    z[7,4,6]  R1990     -2.6573812961578369e-01
    z[7,4,6]  R1991     -2.1016108989715576e-01
    z[7,4,6]  R1992     -1.8594941496849060e-01
    z[7,4,6]  R1993     -8.8872546330094337e-03
    z[7,4,6]  R1994     1.5593892335891724e-01
    z[7,4,6]  R1995     0.0312119722366333
    z[7,4,6]  R1996     6.2140613794326782e-02
    z[7,4,6]  R1997     2.1971276402473450e-01
    z[7,4,6]  R1998     -4.5035343617200851e-02
    z[7,4,6]  R1999     -2.4918465316295624e-01
    z[7,4,6]  R2000     -1.7560848593711853e-01
    z[7,4,6]  R2001     7.6011463999748230e-02
    z[7,4,6]  R2002     2.4811469018459320e-01
    z[7,4,6]  R2003     7.1930283308029175e-01
    z[7,4,6]  R2004     -3.4588134288787842e-01
    z[7,4,6]  R2005     1.1311681009829044e-02
    z[7,4,6]  R2006     2.4740378558635712e-01
    z[7,4,6]  R2007     -2.8012450784444809e-02
    z[7,4,6]  R2008     3.0671533942222595e-01
    z[7,4,6]  R2009     0.188604474067688
    z[7,4,6]  R2010     2.1181724965572357e-01
    z[7,4,6]  R2011     3.4324905276298523e-01
    z[5,6,0]  R47       -1
    z[5,6,0]  R56       1
    z[5,6,0]  R2096     -1
    z[5,6,0]  R2097     1
    z[5,6,0]  R2110     2.9091495275497437e-01
    z[5,6,0]  R2111     -3.6083468794822693e-01
    z[5,6,0]  R2112     -4.6569105982780457e-01
    z[5,6,0]  R2113     -2.0228002965450287e-01
    z[5,6,0]  R2114     -3.6377462744712830e-01
    z[5,6,0]  R2115     -3.3797499537467957e-01
    z[5,6,0]  R2116     -5.4884368181228638e-01
    z[5,6,0]  R2117     -3.7617659568786621e-01
    z[5,6,0]  R2118     -3.1347030401229858e-01
    z[5,6,0]  R2119     -6.2527453899383545e-01
    z[5,6,0]  R2120     2.3207743465900421e-01
    z[5,6,0]  R2121     -5.0279909372329712e-01
    z[5,6,0]  R2122     -2.2818683087825775e-01
    z[5,6,0]  R2123     -2.1225777268409729e-01
    z[5,6,0]  R2124     -5.1677042245864868e-01
    z[5,6,0]  R2125     -4.4484436511993408e-01
    z[5,6,0]  R2126     2.0168316364288330e-01
    z[5,6,0]  R2127     -1.7646947875618935e-02
    z[5,6,0]  R2128     4.1896656155586243e-02
    z[5,6,0]  R2129     8.8463641703128815e-02
    z[5,6,0]  R2130     4.0395464748144150e-02
    z[5,6,0]  R2131     -4.8250782489776611e-01
    z[5,6,0]  R2132     4.6158574521541595e-02
    z[5,6,0]  R2133     5.9904003143310547e-01
    z[5,6,0]  R2134     5.6295675039291382e-01
    z[5,6,0]  R2135     4.4647005200386047e-01
    z[5,6,0]  R2136     -1.9672855734825134e-01
    z[5,6,0]  R2137     -9.8254628479480743e-02
    z[5,6,0]  R2138     3.3166274428367615e-01
    z[5,6,0]  R2139     5.9548731893301010e-02
    z[5,6,0]  R2140     -3.9123165607452393e-01
    z[5,6,0]  R2141     -1.0539588332176208e-01
    z[5,6,0]  R2142     2.6394993066787720e-01
    z[5,6,0]  R2143     5.4921209812164307e-01
    z[5,6,0]  R2144     -3.0321314930915833e-01
    z[5,6,0]  R2145     3.6329996585845947e-01
    z[5,6,0]  R2146     0.088935486972332
    z[5,6,0]  R2147     5.6920063495635986e-01
    z[5,6,0]  R2148     1.9802051782608032e-01
    z[5,6,0]  R2149     1.6972261667251587e-01
    z[5,6,0]  R2150     2.4450385570526123e-01
    z[5,6,0]  R2151     9.1531641781330109e-02
    z[5,6,0]  R2152     4.0710300207138062e-01
    z[5,6,0]  R2153     -9.8229393362998962e-02
    z[5,6,0]  R2154     4.2558785527944565e-02
    z[5,6,0]  R2155     -4.2971599847078323e-02
    z[5,6,0]  R2156     -2.2841045260429382e-01
    z[5,6,0]  R2157     6.3354569673538208e-01
    z[5,6,0]  R2158     8.4422230720520020e-01
    z[5,6,0]  R2159     7.1804314851760864e-01
    z[5,6,0]  R2160     0.00948364194482565
    z[5,6,0]  R2161     -7.2981618344783783e-02
    z[5,6,0]  R2162     1.3737419247627258e-01
    z[5,6,0]  R2163     3.1392046809196472e-01
    z[5,6,0]  R2164     -2.3087984323501587e-01
    z[5,6,0]  R2165     -4.2213848233222961e-01
    z[5,6,0]  R2166     1.6414934396743774e-01
    z[5,6,0]  R2167     3.0744003131985664e-02
    z[5,6,0]  R2168     -2.0722879469394684e-01
    z[5,6,0]  R2169     -4.4394785165786743e-01
    z[5,6,0]  R2170     1.7102941870689392e-01
    z[5,6,0]  R2171     -1.8538489937782288e-02
    z[5,6,0]  R2172     8.7123408913612366e-02
    z[5,6,0]  R2173     4.1409574449062347e-02
    z[5,6,0]  R2174     -3.5936015844345093e-01
    z[5,6,0]  R2175     4.4195351004600525e-01
    z[5,6,0]  R2176     6.2430912256240845e-01
    z[5,6,0]  R2177     -8.7492220103740692e-02
    z[5,6,0]  R2178     2.5624117255210876e-01
    z[5,6,0]  R2179     1.1700862646102905e-01
    z[5,6,0]  R2180     5.0234988331794739e-02
    z[5,6,0]  R2181     2.8864863514900208e-01
    z[5,6,0]  R2182     2.2634042799472809e-01
    z[5,6,0]  R2183     1.8652193248271942e-01
    z[5,6,0]  R2184     8.8945478200912476e-03
    z[5,6,0]  R2185     1.6408419609069824e-01
    z[5,6,0]  R2186     -1.7532561719417572e-01
    z[5,6,0]  R2187     -1.5319344401359558e-01
    z[5,6,0]  R2188     -1.9433531910181046e-02
    z[5,6,0]  R2189     -2.4648292362689972e-01
    z[5,6,0]  R2190     2.1938095986843109e-01
    z[5,6,0]  R2191     -1.9774494692683220e-02
    z[5,6,0]  R2192     -3.9564505219459534e-02
    z[5,6,0]  R2193     -1.0036766529083252e-01
    z[5,6,0]  R2194     6.9954305887222290e-02
    z[5,6,0]  R2195     9.8391972482204437e-02
    z[5,6,0]  R2196     -3.1425106525421143e-01
    z[5,6,0]  R2197     -1.5212918631732464e-02
    z[5,6,0]  R2198     2.8497523069381714e-01
    z[5,6,0]  R2199     2.9772745445370674e-02
    z[5,6,1]  R48       -1
    z[5,6,1]  R57       1
    z[5,6,1]  R2098     -1
    z[5,6,1]  R2099     1
    z[5,6,1]  R2110     -7.3565638065338135e-01
    z[5,6,1]  R2111     -6.4328014850616455e-02
    z[5,6,1]  R2112     -2.9201605916023254e-01
    z[5,6,1]  R2113     5.2661824971437454e-02
    z[5,6,1]  R2114     1.3025499880313873e-01
    z[5,6,1]  R2115     1.5686845779418945e-01
    z[5,6,1]  R2116     -2.4323178455233574e-02
    z[5,6,1]  R2117     -2.2287362813949585e-01
    z[5,6,1]  R2118     -2.6984763145446777e-01
    z[5,6,1]  R2119     1.4140671119093895e-02
    z[5,6,1]  R2120     -1.0301580280065536e-01
    z[5,6,1]  R2121     -2.9531466960906982e-01
    z[5,6,1]  R2122     -5.1376044750213623e-01
    z[5,6,1]  R2123     -1.5158012509346008e-01
    z[5,6,1]  R2124     -1.9731591641902924e-01
    z[5,6,1]  R2125     -5.2393499761819839e-02
    z[5,6,1]  R2126     -0.373665452003479
    z[5,6,1]  R2127     3.0326899886131287e-01
    z[5,6,1]  R2128     1.3561367988586426e-01
    z[5,6,1]  R2129     6.2951862812042236e-02
    z[5,6,1]  R2130     -2.7003467082977295e-01
    z[5,6,1]  R2131     -6.7096549272537231e-01
    z[5,6,1]  R2132     5.3244483470916748e-01
    z[5,6,1]  R2133     2.7409994602203369e-01
    z[5,6,1]  R2134     -0.0711694285273552
    z[5,6,1]  R2135     -1.6892926394939423e-01
    z[5,6,1]  R2136     -2.3674850165843964e-01
    z[5,6,1]  R2137     -2.7946993708610535e-01
    z[5,6,1]  R2138     4.6551775932312012e-01
    z[5,6,1]  R2139     -2.3112232983112335e-01
    z[5,6,1]  R2140     -6.2447714805603027e-01
    z[5,6,1]  R2141     -6.7923784255981445e-01
    z[5,6,1]  R2142     -7.1744000911712646e-01
    z[5,6,1]  R2143     -5.3574812412261963e-01
    z[5,6,1]  R2144     -7.0917648077011108e-01
    z[5,6,1]  R2145     -4.5288136601448059e-01
    z[5,6,1]  R2146     -5.1484644412994385e-01
    z[5,6,1]  R2147     -7.8515373170375824e-02
    z[5,6,1]  R2148     -0.761551022529602
    z[5,6,1]  R2149     -3.1575447320938110e-01
    z[5,6,1]  R2150     -5.6011569499969482e-01
    z[5,6,1]  R2151     -4.9273529648780823e-01
    z[5,6,1]  R2152     -4.4910877943038940e-01
    z[5,6,1]  R2153     -1.6063762828707695e-02
    z[5,6,1]  R2154     5.6766015291213989e-01
    z[5,6,1]  R2155     4.3509021401405334e-01
    z[5,6,1]  R2156     3.0859598517417908e-01
    z[5,6,1]  R2157     7.0993030071258545e-01
    z[5,6,1]  R2158     4.9765196442604065e-01
    z[5,6,1]  R2159     6.6561222076416016e-01
    z[5,6,1]  R2160     1.6811764240264893e-01
    z[5,6,1]  R2161     -1.8261192739009857e-01
    z[5,6,1]  R2162     1.1428344249725342e-01
    z[5,6,1]  R2163     -2.3681230843067169e-01
    z[5,6,1]  R2164     5.2666431665420532e-01
    z[5,6,1]  R2165     -6.3359868526458740e-01
    z[5,6,1]  R2166     -4.1051259636878967e-01
    z[5,6,1]  R2167     -7.9370737075805664e-01
    z[5,6,1]  R2168     -6.4974778890609741e-01
    z[5,6,1]  R2169     -4.7977665066719055e-01
    z[5,6,1]  R2170     -6.0350996255874634e-01
    z[5,6,1]  R2171     -6.1813724040985107e-01
    z[5,6,1]  R2172     -5.3952005691826344e-03
    z[5,6,1]  R2173     -5.5794250965118408e-01
    z[5,6,1]  R2174     -5.0592315196990967e-01
    z[5,6,1]  R2175     4.3353664875030518e-01
    z[5,6,1]  R2176     -3.8781440258026123e-01
    z[5,6,1]  R2177     -4.0554407238960266e-01
    z[5,6,1]  R2178     -0.0594235435128212
    z[5,6,1]  R2179     1.9486029446125031e-01
    z[5,6,1]  R2180     5.9816908091306686e-02
    z[5,6,1]  R2181     -2.2000917792320251e-01
    z[5,6,1]  R2182     -0.352643221616745
    z[5,6,1]  R2183     -6.9116353988647461e-02
    z[5,6,1]  R2184     -4.0837228298187256e-01
    z[5,6,1]  R2185     -0.362091600894928
    z[5,6,1]  R2186     6.3361212611198425e-02
    z[5,6,1]  R2187     -3.8537091016769409e-01
    z[5,6,1]  R2188     -0.638166606426239
    z[5,6,1]  R2189     -1.2333747744560242e-01
    z[5,6,1]  R2190     -3.1664052605628967e-01
    z[5,6,1]  R2191     3.8286406546831131e-02
    z[5,6,1]  R2192     -3.5802689194679260e-01
    z[5,6,1]  R2193     -2.6379999518394470e-01
    z[5,6,1]  R2194     -2.3484107851982117e-01
    z[5,6,1]  R2195     -9.1423398256301880e-01
    z[5,6,1]  R2196     1.8186372518539429e-01
    z[5,6,1]  R2197     8.9892917871475220e-01
    z[5,6,1]  R2198     -0.643058717250824
    z[5,6,1]  R2199     8.7337815761566162e-01
    z[5,6,2]  R49       -1
    z[5,6,2]  R58       1
    z[5,6,2]  R2100     -1
    z[5,6,2]  R2101     1
    z[5,6,2]  R2110     1.3208520412445068e-01
    z[5,6,2]  R2111     -3.8682025671005249e-01
    z[5,6,2]  R2112     -3.9834859967231750e-01
    z[5,6,2]  R2113     -3.8881012797355652e-01
    z[5,6,2]  R2114     -5.8433258533477783e-01
    z[5,6,2]  R2115     -3.4658560156822205e-01
    z[5,6,2]  R2116     -3.4464821219444275e-01
    z[5,6,2]  R2117     -1.6381615400314331e-01
    z[5,6,2]  R2118     -3.1097128987312317e-01
    z[5,6,2]  R2119     -1.8465775251388550e-01
    z[5,6,2]  R2120     6.1017107963562012e-01
    z[5,6,2]  R2121     3.4490790963172913e-01
    z[5,6,2]  R2122     2.8559392690658569e-01
    z[5,6,2]  R2123     7.7999740839004517e-01
    z[5,6,2]  R2124     3.7083712220191956e-01
    z[5,6,2]  R2125     7.3896294832229614e-01
    z[5,6,2]  R2126     0.58495032787323
    z[5,6,2]  R2127     4.0773600339889526e-01
    z[5,6,2]  R2128     1.9199748337268829e-01
    z[5,6,2]  R2129     6.0725563764572144e-01
    z[5,6,2]  R2130     1.7580537497997284e-01
    z[5,6,2]  R2131     2.8710660338401794e-01
    z[5,6,2]  R2132     -5.9267640113830566e-01
    z[5,6,2]  R2133     -4.9337202310562134e-01
    z[5,6,2]  R2134     -6.0816633701324463e-01
    z[5,6,2]  R2135     3.6779043078422546e-01
    z[5,6,2]  R2136     -3.5593810677528381e-01
    z[5,6,2]  R2137     -8.0446094274520874e-01
    z[5,6,2]  R2138     -6.1851215362548828e-01
    z[5,6,2]  R2139     -6.6251236200332642e-01
    z[5,6,2]  R2140     1.0689135640859604e-01
    z[5,6,2]  R2141     2.2233678400516510e-01
    z[5,6,2]  R2142     -1.5225446224212646e-01
    z[5,6,2]  R2143     2.5967153906822205e-01
    z[5,6,2]  R2144     3.7751322984695435e-01
    z[5,6,2]  R2145     1.2850096821784973e-01
    z[5,6,2]  R2146     -4.1867870092391968e-01
    z[5,6,2]  R2147     -3.2843223214149475e-01
    z[5,6,2]  R2148     -2.2259384393692017e-01
    z[5,6,2]  R2149     5.9010386466979980e-01
    z[5,6,2]  R2150     6.1665505170822144e-01
    z[5,6,2]  R2151     7.0563161373138428e-01
    z[5,6,2]  R2152     3.8184961676597595e-01
    z[5,6,2]  R2153     -6.5093362331390381e-01
    z[5,6,2]  R2154     -3.8382175564765930e-01
    z[5,6,2]  R2155     -1.7292433977127075e-01
    z[5,6,2]  R2156     -4.8232406377792358e-01
    z[5,6,2]  R2157     1.7470008134841919e-01
    z[5,6,2]  R2158     7.2153680026531219e-02
    z[5,6,2]  R2159     1.4411626756191254e-01
    z[5,6,2]  R2160     -1.1657848954200745e-01
    z[5,6,2]  R2161     -0.27797931432724
    z[5,6,2]  R2162     -2.8962761163711548e-01
    z[5,6,2]  R2163     9.1380268335342407e-02
    z[5,6,2]  R2164     1.9642254710197449e-01
    z[5,6,2]  R2165     -3.4210613369941711e-01
    z[5,6,2]  R2166     1.8819691240787506e-01
    z[5,6,2]  R2167     -3.0000713467597961e-01
    z[5,6,2]  R2168     -9.1953672468662262e-02
    z[5,6,2]  R2169     -1.1292373389005661e-01
    z[5,6,2]  R2170     -1.0943014174699783e-01
    z[5,6,2]  R2171     -0.0857386440038681
    z[5,6,2]  R2172     -3.6604857444763184e-01
    z[5,6,2]  R2173     -2.0322367548942566e-01
    z[5,6,2]  R2174     2.7266851067543030e-01
    z[5,6,2]  R2175     1.0813126713037491e-01
    z[5,6,2]  R2176     1.0796468704938889e-01
    z[5,6,2]  R2177     7.8948169946670532e-01
    z[5,6,2]  R2178     2.6973477005958557e-01
    z[5,6,2]  R2179     4.8148965835571289e-01
    z[5,6,2]  R2180     0.413653701543808
    z[5,6,2]  R2181     0.342832088470459
    z[5,6,2]  R2182     -2.6855310425162315e-02
    z[5,6,2]  R2183     -0.0953153595328331
    z[5,6,2]  R2184     4.4445610046386719e-01
    z[5,6,2]  R2185     3.8897311687469482e-01
    z[5,6,2]  R2186     -1.4220274984836578e-01
    z[5,6,2]  R2187     0.567274808883667
    z[5,6,2]  R2188     6.6093361377716064e-01
    z[5,6,2]  R2189     4.6385416388511658e-01
    z[5,6,2]  R2190     4.8049096018075943e-02
    z[5,6,2]  R2191     1.9378603994846344e-01
    z[5,6,2]  R2192     7.5120642781257629e-02
    z[5,6,2]  R2193     -2.4247172474861145e-01
    z[5,6,2]  R2194     -4.8259615898132324e-01
    z[5,6,2]  R2195     3.5424941778182983e-01
    z[5,6,2]  R2196     -1.0859417915344238e-01
    z[5,6,2]  R2197     9.9274478852748871e-02
    z[5,6,2]  R2198     5.9204649925231934e-01
    z[5,6,2]  R2199     -5.3504716604948044e-02
    z[5,6,3]  R50       -1
    z[5,6,3]  R59       1
    z[5,6,3]  R2102     -1
    z[5,6,3]  R2103     1
    z[5,6,3]  R2110     0.0196211077272892
    z[5,6,3]  R2111     -0.701768696308136
    z[5,6,3]  R2112     -6.5325957536697388e-01
    z[5,6,3]  R2113     -7.0325976610183716e-01
    z[5,6,3]  R2114     -6.5420705080032349e-01
    z[5,6,3]  R2115     -6.7545342445373535e-01
    z[5,6,3]  R2116     -6.6219961643218994e-01
    z[5,6,3]  R2117     -7.0152705907821655e-01
    z[5,6,3]  R2118     -7.6354062557220459e-01
    z[5,6,3]  R2119     -7.1497130393981934e-01
    z[5,6,3]  R2120     -1.7959071695804596e-01
    z[5,6,3]  R2121     7.4589416384696960e-02
    z[5,6,3]  R2122     2.4222701787948608e-01
    z[5,6,3]  R2123     2.7327957749366760e-01
    z[5,6,3]  R2124     -1.5850800275802612e-01
    z[5,6,3]  R2125     -4.3000063300132751e-01
    z[5,6,3]  R2126     2.2664192318916321e-01
    z[5,6,3]  R2127     1.2618897855281830e-01
    z[5,6,3]  R2128     -2.5506886839866638e-01
    z[5,6,3]  R2129     3.7588068842887878e-01
    z[5,6,3]  R2130     -2.2563324868679047e-01
    z[5,6,3]  R2131     2.3195911198854446e-02
    z[5,6,3]  R2132     0.390370637178421
    z[5,6,3]  R2133     3.8116759061813354e-01
    z[5,6,3]  R2134     3.2221826910972595e-01
    z[5,6,3]  R2135     -2.9729706048965454e-01
    z[5,6,3]  R2136     3.3737942576408386e-01
    z[5,6,3]  R2137     3.2657852768898010e-01
    z[5,6,3]  R2138     3.4689873456954956e-01
    z[5,6,3]  R2139     3.2710546255111694e-01
    z[5,6,3]  R2140     -3.4157100319862366e-01
    z[5,6,3]  R2141     -1.9333158433437347e-01
    z[5,6,3]  R2142     -3.9478850364685059e-01
    z[5,6,3]  R2143     -4.0185242891311646e-01
    z[5,6,3]  R2144     -1.7905758321285248e-01
    z[5,6,3]  R2145     -0.620050847530365
    z[5,6,3]  R2146     6.9500762224197388e-01
    z[5,6,3]  R2147     0.589187502861023
    z[5,6,3]  R2148     -1.3092766702175140e-01
    z[5,6,3]  R2149     -4.1605284810066223e-01
    z[5,6,3]  R2150     -3.2427427172660828e-01
    z[5,6,3]  R2151     2.1129217743873596e-01
    z[5,6,3]  R2152     3.5562857985496521e-01
    z[5,6,3]  R2153     6.7207229137420654e-01
    z[5,6,3]  R2154     5.5396783351898193e-01
    z[5,6,3]  R2155     4.8108518123626709e-01
    z[5,6,3]  R2156     4.1041249036788940e-01
    z[5,6,3]  R2157     -1.6488130390644073e-01
    z[5,6,3]  R2158     -1.4268906414508820e-01
    z[5,6,3]  R2159     8.8368929922580719e-02
    z[5,6,3]  R2160     -0.85221928358078
    z[5,6,3]  R2161     -8.1240195035934448e-01
    z[5,6,3]  R2162     -5.2628499269485474e-01
    z[5,6,3]  R2163     -7.5213503837585449e-01
    z[5,6,3]  R2164     -4.3814745545387268e-01
    z[5,6,3]  R2165     1.2706759572029114e-01
    z[5,6,3]  R2166     3.4517151117324829e-01
    z[5,6,3]  R2167     -1.5411342494189739e-02
    z[5,6,3]  R2168     2.3107966780662537e-01
    z[5,6,3]  R2169     -5.8358427137136459e-02
    z[5,6,3]  R2170     4.1151252388954163e-01
    z[5,6,3]  R2171     5.9133970737457275e-01
    z[5,6,3]  R2172     5.1580494642257690e-01
    z[5,6,3]  R2173     7.1391516923904419e-01
    z[5,6,3]  R2174     3.2900074124336243e-01
    z[5,6,3]  R2175     6.9959261454641819e-03
    z[5,6,3]  R2176     3.8137266039848328e-01
    z[5,6,3]  R2177     0.338481068611145
    z[5,6,3]  R2178     2.3638258874416351e-01
    z[5,6,3]  R2179     -0.462100625038147
    z[5,6,3]  R2180     4.8471182584762573e-01
    z[5,6,3]  R2181     4.3285819888114929e-01
    z[5,6,3]  R2182     4.2439797520637512e-01
    z[5,6,3]  R2183     4.8455065488815308e-01
    z[5,6,3]  R2184     4.9847099184989929e-01
    z[5,6,3]  R2185     3.9329320192337036e-01
    z[5,6,3]  R2186     4.8132848739624023e-01
    z[5,6,3]  R2187     5.7116001844406128e-01
    z[5,6,3]  R2188     8.5973121225833893e-02
    z[5,6,3]  R2189     0.566581130027771
    z[5,6,3]  R2190     0.543865442276001
    z[5,6,3]  R2191     4.8258337378501892e-01
    z[5,6,3]  R2192     4.3860536813735962e-01
    z[5,6,3]  R2193     7.4338442087173462e-01
    z[5,6,3]  R2194     7.0555222034454346e-01
    z[5,6,3]  R2195     1.0699941217899323e-01
    z[5,6,3]  R2196     4.6006390452384949e-01
    z[5,6,3]  R2197     2.5437566637992859e-01
    z[5,6,3]  R2198     3.3498144149780273e-01
    z[5,6,3]  R2199     1.4639307558536530e-01
    z[5,6,4]  R51       -1
    z[5,6,4]  R60       1
    z[5,6,4]  R2104     -1
    z[5,6,4]  R2105     1
    z[5,6,4]  R2110     1.5048332512378693e-01
    z[5,6,4]  R2111     -3.2633045315742493e-01
    z[5,6,4]  R2112     -1.6680608689785004e-01
    z[5,6,4]  R2113     -4.1913607716560364e-01
    z[5,6,4]  R2114     -9.9355258047580719e-02
    z[5,6,4]  R2115     -1.8634644150733948e-01
    z[5,6,4]  R2116     1.2752544879913330e-01
    z[5,6,4]  R2117     -1.3623578846454620e-01
    z[5,6,4]  R2118     -1.9300854206085205e-01
    z[5,6,4]  R2119     -2.0560650527477264e-01
    z[5,6,4]  R2120     -4.2824211716651917e-01
    z[5,6,4]  R2121     -1.6616936028003693e-01
    z[5,6,4]  R2122     -5.2697628736495972e-01
    z[5,6,4]  R2123     -4.4625130295753479e-01
    z[5,6,4]  R2124     3.8606348633766174e-01
    z[5,6,4]  R2125     -1.2558455578982830e-02
    z[5,6,4]  R2126     -5.8654683828353882e-01
    z[5,6,4]  R2127     1.7067460715770721e-01
    z[5,6,4]  R2128     3.1366115808486938e-01
    z[5,6,4]  R2129     2.1508924663066864e-01
    z[5,6,4]  R2130     3.9654234051704407e-01
    z[5,6,4]  R2131     -1.3074333965778351e-01
    z[5,6,4]  R2132     -2.6131460443139076e-02
    z[5,6,4]  R2133     -2.5739734992384911e-02
    z[5,6,4]  R2134     -4.4466635584831238e-01
    z[5,6,4]  R2135     5.0851291418075562e-01
    z[5,6,4]  R2136     -4.8996168375015259e-01
    z[5,6,4]  R2137     -3.6061301361769438e-03
    z[5,6,4]  R2138     2.9170578718185425e-01
    z[5,6,4]  R2139     6.2315058708190918e-01
    z[5,6,4]  R2140     -1.0473524034023285e-01
    z[5,6,4]  R2141     2.4731905758380890e-01
    z[5,6,4]  R2142     -4.7590738534927368e-01
    z[5,6,4]  R2143     1.2608104385435581e-02
    z[5,6,4]  R2144     -2.5923281908035278e-01
    z[5,6,4]  R2145     -2.3029941320419312e-01
    z[5,6,4]  R2146     -1.4339910447597504e-01
    z[5,6,4]  R2147     2.5317385792732239e-01
    z[5,6,4]  R2148     -1.3775067031383514e-01
    z[5,6,4]  R2149     4.3282940983772278e-01
    z[5,6,4]  R2150     -0.165388822555542
    z[5,6,4]  R2151     -1.3358780741691589e-01
    z[5,6,4]  R2152     -4.8172404058277607e-03
    z[5,6,4]  R2153     -0.0821036770939827
    z[5,6,4]  R2154     -1.8744440376758575e-01
    z[5,6,4]  R2155     5.8051735162734985e-01
    z[5,6,4]  R2156     5.5524122714996338e-01
    z[5,6,4]  R2157     -7.4247263371944427e-02
    z[5,6,4]  R2158     -4.5442916452884674e-02
    z[5,6,4]  R2159     -2.5031277909874916e-02
    z[5,6,4]  R2160     2.0948500931262970e-01
    z[5,6,4]  R2161     -3.1193265318870544e-01
    z[5,6,4]  R2162     -1.3032099604606628e-01
    z[5,6,4]  R2163     -4.3716788291931152e-02
    z[5,6,4]  R2164     -2.6139837503433228e-01
    z[5,6,4]  R2165     -1.1416272819042206e-01
    z[5,6,4]  R2166     4.3638557195663452e-01
    z[5,6,4]  R2167     -2.4576272070407867e-01
    z[5,6,4]  R2168     -5.5505480617284775e-02
    z[5,6,4]  R2169     2.8016555309295654e-01
    z[5,6,4]  R2170     5.6557816267013550e-01
    z[5,6,4]  R2171     -3.4651103615760803e-01
    z[5,6,4]  R2172     -3.6873687058687210e-02
    z[5,6,4]  R2173     -1.4194028079509735e-01
    z[5,6,4]  R2174     -2.9900604486465454e-01
    z[5,6,4]  R2175     0.667676568031311
    z[5,6,4]  R2176     1.8114092946052551e-01
    z[5,6,4]  R2177     -4.0168181061744690e-02
    z[5,6,4]  R2178     2.1784137934446335e-02
    z[5,6,4]  R2179     -4.7689802944660187e-02
    z[5,6,4]  R2180     1.3894718885421753e-01
    z[5,6,4]  R2181     2.0598727464675903e-01
    z[5,6,4]  R2182     3.7436592578887939e-01
    z[5,6,4]  R2183     -1.3234195113182068e-01
    z[5,6,4]  R2184     -1.9997909665107727e-01
    z[5,6,4]  R2185     2.9672408103942871e-01
    z[5,6,4]  R2186     -3.4363400936126709e-01
    z[5,6,4]  R2187     -1.0641941428184509e-01
    z[5,6,4]  R2188     -0.382472962141037
    z[5,6,4]  R2189     -4.4036373496055603e-01
    z[5,6,4]  R2190     1.1417217552661896e-01
    z[5,6,4]  R2191     1.5343791246414185e-01
    z[5,6,4]  R2192     3.6165687441825867e-01
    z[5,6,4]  R2193     -4.7659203410148621e-01
    z[5,6,4]  R2194     -0.0654422715306282
    z[5,6,4]  R2195     4.0773589164018631e-02
    z[5,6,4]  R2196     3.0711600184440613e-01
    z[5,6,4]  R2197     9.1799207031726837e-02
    z[5,6,4]  R2198     9.9960751831531525e-02
    z[5,6,4]  R2199     3.4307071566581726e-01
    z[5,6,5]  R52       -1
    z[5,6,5]  R61       1
    z[5,6,5]  R2106     -1
    z[5,6,5]  R2107     1
    z[5,6,5]  R2110     3.9202713966369629e-01
    z[5,6,5]  R2111     -3.0105775594711304e-01
    z[5,6,5]  R2112     -2.9000511765480042e-01
    z[5,6,5]  R2113     -3.1298825144767761e-01
    z[5,6,5]  R2114     -2.5966253876686096e-01
    z[5,6,5]  R2115     -3.7169870734214783e-01
    z[5,6,5]  R2116     -3.0928614735603333e-01
    z[5,6,5]  R2117     -4.8580473661422729e-01
    z[5,6,5]  R2118     -1.5923266112804413e-01
    z[5,6,5]  R2119     -1.8636988475918770e-02
    z[5,6,5]  R2120     4.3766376376152039e-01
    z[5,6,5]  R2121     4.7934854030609131e-01
    z[5,6,5]  R2122     3.0896827578544617e-01
    z[5,6,5]  R2123     -5.0114773213863373e-02
    z[5,6,5]  R2124     5.7238936424255371e-01
    z[5,6,5]  R2125     1.4931109547615051e-01
    z[5,6,5]  R2126     -2.4780185520648956e-01
    z[5,6,5]  R2127     6.6247540712356567e-01
    z[5,6,5]  R2128     7.9129147529602051e-01
    z[5,6,5]  R2129     6.2015217542648315e-01
    z[5,6,5]  R2130     8.2093071937561035e-01
    z[5,6,5]  R2131     -3.2185354828834534e-01
    z[5,6,5]  R2132     6.9746315479278564e-02
    z[5,6,5]  R2133     3.5823008418083191e-01
    z[5,6,5]  R2134     -2.6745175942778587e-02
    z[5,6,5]  R2135     -5.3570348024368286e-01
    z[5,6,5]  R2136     -6.4375501871109009e-01
    z[5,6,5]  R2137     -3.1721353530883789e-01
    z[5,6,5]  R2138     -2.1833148598670959e-01
    z[5,6,5]  R2139     1.3217644765973091e-02
    z[5,6,5]  R2140     4.9586769938468933e-01
    z[5,6,5]  R2141     -5.7216089963912964e-01
    z[5,6,5]  R2142     -7.6155602000653744e-03
    z[5,6,5]  R2143     -4.1675922274589539e-01
    z[5,6,5]  R2144     -2.5325170159339905e-01
    z[5,6,5]  R2145     -3.5454273223876953e-01
    z[5,6,5]  R2146     -4.6683784574270248e-02
    z[5,6,5]  R2147     2.7457234263420105e-01
    z[5,6,5]  R2148     -5.3711551427841187e-01
    z[5,6,5]  R2149     -2.4102471768856049e-01
    z[5,6,5]  R2150     2.3109711706638336e-01
    z[5,6,5]  R2151     -1.1135119944810867e-01
    z[5,6,5]  R2152     5.9610503911972046e-01
    z[5,6,5]  R2153     -3.2514768838882446e-01
    z[5,6,5]  R2154     -1.4958518743515015e-01
    z[5,6,5]  R2155     -2.8918331861495972e-01
    z[5,6,5]  R2156     3.2546848058700562e-01
    z[5,6,5]  R2157     -1.7712321877479553e-01
    z[5,6,5]  R2158     0.00496411370113492
    z[5,6,5]  R2159     -9.9545374512672424e-02
    z[5,6,5]  R2160     -4.1011118888854980e-01
    z[5,6,5]  R2161     -3.5467270016670227e-01
    z[5,6,5]  R2162     -6.7898106575012207e-01
    z[5,6,5]  R2163     -3.8434910774230957e-01
    z[5,6,5]  R2164     -6.0099124908447266e-01
    z[5,6,5]  R2165     8.2026623189449310e-02
    z[5,6,5]  R2166     -2.9660975933074951e-01
    z[5,6,5]  R2167     4.6530964970588684e-01
    z[5,6,5]  R2168     5.5250751972198486e-01
    z[5,6,5]  R2169     4.3743756413459778e-01
    z[5,6,5]  R2170     -3.0136564373970032e-01
    z[5,6,5]  R2171     3.5118868947029114e-01
    z[5,6,5]  R2172     7.3869693279266357e-01
    z[5,6,5]  R2173     -2.6882886886596680e-01
    z[5,6,5]  R2174     -4.3684488534927368e-01
    z[5,6,5]  R2175     3.1190750002861023e-01
    z[5,6,5]  R2176     5.0793045759201050e-01
    z[5,6,5]  R2177     4.7194175422191620e-02
    z[5,6,5]  R2178     8.8561016321182251e-01
    z[5,6,5]  R2179     7.0759785175323486e-01
    z[5,6,5]  R2180     7.4784934520721436e-01
    z[5,6,5]  R2181     7.0382225513458252e-01
    z[5,6,5]  R2182     7.0949828624725342e-01
    z[5,6,5]  R2183     7.6195400953292847e-01
    z[5,6,5]  R2184     5.8875405788421631e-01
    z[5,6,5]  R2185     6.5910464525222778e-01
    z[5,6,5]  R2186     7.7146822214126587e-01
    z[5,6,5]  R2187     2.8881141543388367e-01
    z[5,6,5]  R2188     -3.2654516398906708e-02
    z[5,6,5]  R2189     4.1194760799407959e-01
    z[5,6,5]  R2190     7.1507257223129272e-01
    z[5,6,5]  R2191     8.2039844989776611e-01
    z[5,6,5]  R2192     6.3013392686843872e-01
    z[5,6,5]  R2193     1.5305669605731964e-01
    z[5,6,5]  R2194     3.7789145112037659e-01
    z[5,6,5]  R2195     -4.2847845703363419e-02
    z[5,6,5]  R2196     4.6800276637077332e-01
    z[5,6,5]  R2197     3.1855154037475586e-01
    z[5,6,5]  R2198     1.1651323735713959e-01
    z[5,6,5]  R2199     3.0713552236557007e-01
    z[5,6,6]  R53       -1
    z[5,6,6]  R62       1
    z[5,6,6]  R2108     -1
    z[5,6,6]  R2109     1
    z[5,6,6]  R2110     -4.2428311705589294e-01
    z[5,6,6]  R2111     1.6255371272563934e-01
    z[5,6,6]  R2112     2.2395044565200806e-02
    z[5,6,6]  R2113     -1.9215951859951019e-01
    z[5,6,6]  R2114     -6.3041254878044128e-02
    z[5,6,6]  R2115     -3.3454650640487671e-01
    z[5,6,6]  R2116     -1.7019891738891602e-01
    z[5,6,6]  R2117     -1.8781930208206177e-01
    z[5,6,6]  R2118     -2.9430219531059265e-01
    z[5,6,6]  R2119     -1.4466480910778046e-01
    z[5,6,6]  R2120     3.9500033855438232e-01
    z[5,6,6]  R2121     5.2732348442077637e-01
    z[5,6,6]  R2122     4.1301050782203674e-01
    z[5,6,6]  R2123     2.1734927594661713e-01
    z[5,6,6]  R2124     2.3387011885643005e-01
    z[5,6,6]  R2125     2.1436008810997009e-01
    z[5,6,6]  R2126     -1.4395037293434143e-01
    z[5,6,6]  R2127     5.0748473405838013e-01
    z[5,6,6]  R2128     0.391669362783432
    z[5,6,6]  R2129     2.1751639246940613e-01
    z[5,6,6]  R2130     1.1161798238754272e-01
    z[5,6,6]  R2131     -3.3665984869003296e-01
    z[5,6,6]  R2132     4.5295679569244385e-01
    z[5,6,6]  R2133     2.1982754766941071e-01
    z[5,6,6]  R2134     0.0766829177737236
    z[5,6,6]  R2135     -5.3929977118968964e-02
    z[5,6,6]  R2136     -1.0123301297426224e-01
    z[5,6,6]  R2137     -2.4040430784225464e-01
    z[5,6,6]  R2138     -1.9400058686733246e-01
    z[5,6,6]  R2139     -9.2867843806743622e-02
    z[5,6,6]  R2140     2.6835662126541138e-01
    z[5,6,6]  R2141     2.2843407094478607e-01
    z[5,6,6]  R2142     1.0012534260749817e-01
    z[5,6,6]  R2143     9.2617996037006378e-02
    z[5,6,6]  R2144     -3.1498336791992188e-01
    z[5,6,6]  R2145     -2.8844013810157776e-01
    z[5,6,6]  R2146     -2.1436761319637299e-01
    z[5,6,6]  R2147     -2.7449825406074524e-01
    z[5,6,6]  R2148     8.1667736172676086e-02
    z[5,6,6]  R2149     -3.2363036274909973e-01
    z[5,6,6]  R2150     -2.4558429419994354e-01
    z[5,6,6]  R2151     -4.1955778002738953e-01
    z[5,6,6]  R2152     -7.0165641605854034e-02
    z[5,6,6]  R2153     -4.7278359532356262e-02
    z[5,6,6]  R2154     4.0526536107063293e-01
    z[5,6,6]  R2155     -3.5619777441024780e-01
    z[5,6,6]  R2156     1.9313147664070129e-01
    z[5,6,6]  R2157     -5.2450164221227169e-03
    z[5,6,6]  R2158     -1.0943074524402618e-01
    z[5,6,6]  R2159     -4.7539673745632172e-02
    z[5,6,6]  R2160     1.4036749303340912e-01
    z[5,6,6]  R2161     -3.1022084876894951e-02
    z[5,6,6]  R2162     -3.5945597290992737e-01
    z[5,6,6]  R2163     -3.4882813692092896e-01
    z[5,6,6]  R2164     0.0961492657661438
    z[5,6,6]  R2165     5.1711469888687134e-01
    z[5,6,6]  R2166     -6.0955983400344849e-01
    z[5,6,6]  R2167     -4.3923977762460709e-02
    z[5,6,6]  R2168     4.0581443905830383e-01
    z[5,6,6]  R2169     -5.3546506166458130e-01
    z[5,6,6]  R2170     1.2044569849967957e-01
    z[5,6,6]  R2171     -1.3086408376693726e-01
    z[5,6,6]  R2172     -2.1284069120883942e-01
    z[5,6,6]  R2173     -2.0879344642162323e-01
    z[5,6,6]  R2174     0.389967143535614
    z[5,6,6]  R2175     -2.4880394339561462e-01
    z[5,6,6]  R2176     1.0923012346029282e-01
    z[5,6,6]  R2177     2.9357701539993286e-01
    z[5,6,6]  R2178     -1.3189360499382019e-01
    z[5,6,6]  R2179     -4.1599976248107851e-04
    z[5,6,6]  R2180     9.6221163868904114e-02
    z[5,6,6]  R2181     -1.5994152426719666e-01
    z[5,6,6]  R2182     -6.3475859351456165e-03
    z[5,6,6]  R2183     -3.4419447183609009e-01
    z[5,6,6]  R2184     2.2703444585204124e-02
    z[5,6,6]  R2185     1.1628524214029312e-01
    z[5,6,6]  R2186     9.9947135895490646e-03
    z[5,6,6]  R2187     2.9199233651161194e-01
    z[5,6,6]  R2188     2.8093319386243820e-02
    z[5,6,6]  R2189     1.5568609535694122e-01
    z[5,6,6]  R2190     -1.7072907090187073e-01
    z[5,6,6]  R2191     1.7637057602405548e-01
    z[5,6,6]  R2192     3.7995925545692444e-01
    z[5,6,6]  R2193     -2.4157127737998962e-01
    z[5,6,6]  R2194     -2.4933594465255737e-01
    z[5,6,6]  R2195     1.1855491995811462e-01
    z[5,6,6]  R2196     5.7565051317214966e-01
    z[5,6,6]  R2197     -8.5030794143676758e-02
    z[5,6,6]  R2198     -1.3771559298038483e-01
    z[5,6,6]  R2199     -8.6030957754701376e-04
    z[6,5,0]  R47       1
    z[6,5,0]  R56       -1
    z[6,5,0]  R2200     -1
    z[6,5,0]  R2201     1
    z[6,5,0]  R2214     0.00948364194482565
    z[6,5,0]  R2215     -7.2981618344783783e-02
    z[6,5,0]  R2216     1.3737419247627258e-01
    z[6,5,0]  R2217     3.1392046809196472e-01
    z[6,5,0]  R2218     -2.3087984323501587e-01
    z[6,5,0]  R2219     -4.2213848233222961e-01
    z[6,5,0]  R2220     1.6414934396743774e-01
    z[6,5,0]  R2221     3.0744003131985664e-02
    z[6,5,0]  R2222     -2.0722879469394684e-01
    z[6,5,0]  R2223     -4.4394785165786743e-01
    z[6,5,0]  R2224     1.7102941870689392e-01
    z[6,5,0]  R2225     -1.8538489937782288e-02
    z[6,5,0]  R2226     8.7123408913612366e-02
    z[6,5,0]  R2227     4.1409574449062347e-02
    z[6,5,0]  R2228     -3.5936015844345093e-01
    z[6,5,0]  R2229     4.4195351004600525e-01
    z[6,5,0]  R2230     6.2430912256240845e-01
    z[6,5,0]  R2231     -8.7492220103740692e-02
    z[6,5,0]  R2232     2.5624117255210876e-01
    z[6,5,0]  R2233     1.1700862646102905e-01
    z[6,5,0]  R2234     5.0234988331794739e-02
    z[6,5,0]  R2235     2.8864863514900208e-01
    z[6,5,0]  R2236     2.2634042799472809e-01
    z[6,5,0]  R2237     1.8652193248271942e-01
    z[6,5,0]  R2238     8.8945478200912476e-03
    z[6,5,0]  R2239     1.6408419609069824e-01
    z[6,5,0]  R2240     -1.7532561719417572e-01
    z[6,5,0]  R2241     -1.5319344401359558e-01
    z[6,5,0]  R2242     -1.9433531910181046e-02
    z[6,5,0]  R2243     -2.4648292362689972e-01
    z[6,5,0]  R2244     2.1938095986843109e-01
    z[6,5,0]  R2245     -1.9774494692683220e-02
    z[6,5,0]  R2246     -3.9564505219459534e-02
    z[6,5,0]  R2247     -1.0036766529083252e-01
    z[6,5,0]  R2248     6.9954305887222290e-02
    z[6,5,0]  R2249     9.8391972482204437e-02
    z[6,5,0]  R2250     -3.1425106525421143e-01
    z[6,5,0]  R2251     -1.5212918631732464e-02
    z[6,5,0]  R2252     2.8497523069381714e-01
    z[6,5,0]  R2253     2.9772745445370674e-02
    z[6,5,0]  R2254     2.9091495275497437e-01
    z[6,5,0]  R2255     -3.6083468794822693e-01
    z[6,5,0]  R2256     -4.6569105982780457e-01
    z[6,5,0]  R2257     -2.0228002965450287e-01
    z[6,5,0]  R2258     -3.6377462744712830e-01
    z[6,5,0]  R2259     -3.3797499537467957e-01
    z[6,5,0]  R2260     -5.4884368181228638e-01
    z[6,5,0]  R2261     -3.7617659568786621e-01
    z[6,5,0]  R2262     -3.1347030401229858e-01
    z[6,5,0]  R2263     -6.2527453899383545e-01
    z[6,5,0]  R2264     2.3207743465900421e-01
    z[6,5,0]  R2265     -5.0279909372329712e-01
    z[6,5,0]  R2266     -2.2818683087825775e-01
    z[6,5,0]  R2267     -2.1225777268409729e-01
    z[6,5,0]  R2268     -5.1677042245864868e-01
    z[6,5,0]  R2269     -4.4484436511993408e-01
    z[6,5,0]  R2270     2.0168316364288330e-01
    z[6,5,0]  R2271     -1.7646947875618935e-02
    z[6,5,0]  R2272     4.1896656155586243e-02
    z[6,5,0]  R2273     8.8463641703128815e-02
    z[6,5,0]  R2274     4.0395464748144150e-02
    z[6,5,0]  R2275     -4.8250782489776611e-01
    z[6,5,0]  R2276     4.6158574521541595e-02
    z[6,5,0]  R2277     5.9904003143310547e-01
    z[6,5,0]  R2278     5.6295675039291382e-01
    z[6,5,0]  R2279     4.4647005200386047e-01
    z[6,5,0]  R2280     -1.9672855734825134e-01
    z[6,5,0]  R2281     -9.8254628479480743e-02
    z[6,5,0]  R2282     3.3166274428367615e-01
    z[6,5,0]  R2283     5.9548731893301010e-02
    z[6,5,0]  R2284     -3.9123165607452393e-01
    z[6,5,0]  R2285     -1.0539588332176208e-01
    z[6,5,0]  R2286     2.6394993066787720e-01
    z[6,5,0]  R2287     5.4921209812164307e-01
    z[6,5,0]  R2288     -3.0321314930915833e-01
    z[6,5,0]  R2289     3.6329996585845947e-01
    z[6,5,0]  R2290     0.088935486972332
    z[6,5,0]  R2291     5.6920063495635986e-01
    z[6,5,0]  R2292     1.9802051782608032e-01
    z[6,5,0]  R2293     1.6972261667251587e-01
    z[6,5,0]  R2294     2.4450385570526123e-01
    z[6,5,0]  R2295     9.1531641781330109e-02
    z[6,5,0]  R2296     4.0710300207138062e-01
    z[6,5,0]  R2297     -9.8229393362998962e-02
    z[6,5,0]  R2298     4.2558785527944565e-02
    z[6,5,0]  R2299     -4.2971599847078323e-02
    z[6,5,0]  R2300     -2.2841045260429382e-01
    z[6,5,0]  R2301     6.3354569673538208e-01
    z[6,5,0]  R2302     8.4422230720520020e-01
    z[6,5,0]  R2303     7.1804314851760864e-01
    z[6,5,1]  R48       1
    z[6,5,1]  R57       -1
    z[6,5,1]  R2202     -1
    z[6,5,1]  R2203     1
    z[6,5,1]  R2214     1.6811764240264893e-01
    z[6,5,1]  R2215     -1.8261192739009857e-01
    z[6,5,1]  R2216     1.1428344249725342e-01
    z[6,5,1]  R2217     -2.3681230843067169e-01
    z[6,5,1]  R2218     5.2666431665420532e-01
    z[6,5,1]  R2219     -6.3359868526458740e-01
    z[6,5,1]  R2220     -4.1051259636878967e-01
    z[6,5,1]  R2221     -7.9370737075805664e-01
    z[6,5,1]  R2222     -6.4974778890609741e-01
    z[6,5,1]  R2223     -4.7977665066719055e-01
    z[6,5,1]  R2224     -6.0350996255874634e-01
    z[6,5,1]  R2225     -6.1813724040985107e-01
    z[6,5,1]  R2226     -5.3952005691826344e-03
    z[6,5,1]  R2227     -5.5794250965118408e-01
    z[6,5,1]  R2228     -5.0592315196990967e-01
    z[6,5,1]  R2229     4.3353664875030518e-01
    z[6,5,1]  R2230     -3.8781440258026123e-01
    z[6,5,1]  R2231     -4.0554407238960266e-01
    z[6,5,1]  R2232     -0.0594235435128212
    z[6,5,1]  R2233     1.9486029446125031e-01
    z[6,5,1]  R2234     5.9816908091306686e-02
    z[6,5,1]  R2235     -2.2000917792320251e-01
    z[6,5,1]  R2236     -0.352643221616745
    z[6,5,1]  R2237     -6.9116353988647461e-02
    z[6,5,1]  R2238     -4.0837228298187256e-01
    z[6,5,1]  R2239     -0.362091600894928
    z[6,5,1]  R2240     6.3361212611198425e-02
    z[6,5,1]  R2241     -3.8537091016769409e-01
    z[6,5,1]  R2242     -0.638166606426239
    z[6,5,1]  R2243     -1.2333747744560242e-01
    z[6,5,1]  R2244     -3.1664052605628967e-01
    z[6,5,1]  R2245     3.8286406546831131e-02
    z[6,5,1]  R2246     -3.5802689194679260e-01
    z[6,5,1]  R2247     -2.6379999518394470e-01
    z[6,5,1]  R2248     -2.3484107851982117e-01
    z[6,5,1]  R2249     -9.1423398256301880e-01
    z[6,5,1]  R2250     1.8186372518539429e-01
    z[6,5,1]  R2251     8.9892917871475220e-01
    z[6,5,1]  R2252     -0.643058717250824
    z[6,5,1]  R2253     8.7337815761566162e-01
    z[6,5,1]  R2254     -7.3565638065338135e-01
    z[6,5,1]  R2255     -6.4328014850616455e-02
    z[6,5,1]  R2256     -2.9201605916023254e-01
    z[6,5,1]  R2257     5.2661824971437454e-02
    z[6,5,1]  R2258     1.3025499880313873e-01
    z[6,5,1]  R2259     1.5686845779418945e-01
    z[6,5,1]  R2260     -2.4323178455233574e-02
    z[6,5,1]  R2261     -2.2287362813949585e-01
    z[6,5,1]  R2262     -2.6984763145446777e-01
    z[6,5,1]  R2263     1.4140671119093895e-02
    z[6,5,1]  R2264     -1.0301580280065536e-01
    z[6,5,1]  R2265     -2.9531466960906982e-01
    z[6,5,1]  R2266     -5.1376044750213623e-01
    z[6,5,1]  R2267     -1.5158012509346008e-01
    z[6,5,1]  R2268     -1.9731591641902924e-01
    z[6,5,1]  R2269     -5.2393499761819839e-02
    z[6,5,1]  R2270     -0.373665452003479
    z[6,5,1]  R2271     3.0326899886131287e-01
    z[6,5,1]  R2272     1.3561367988586426e-01
    z[6,5,1]  R2273     6.2951862812042236e-02
    z[6,5,1]  R2274     -2.7003467082977295e-01
    z[6,5,1]  R2275     -6.7096549272537231e-01
    z[6,5,1]  R2276     5.3244483470916748e-01
    z[6,5,1]  R2277     2.7409994602203369e-01
    z[6,5,1]  R2278     -0.0711694285273552
    z[6,5,1]  R2279     -1.6892926394939423e-01
    z[6,5,1]  R2280     -2.3674850165843964e-01
    z[6,5,1]  R2281     -2.7946993708610535e-01
    z[6,5,1]  R2282     4.6551775932312012e-01
    z[6,5,1]  R2283     -2.3112232983112335e-01
    z[6,5,1]  R2284     -6.2447714805603027e-01
    z[6,5,1]  R2285     -6.7923784255981445e-01
    z[6,5,1]  R2286     -7.1744000911712646e-01
    z[6,5,1]  R2287     -5.3574812412261963e-01
    z[6,5,1]  R2288     -7.0917648077011108e-01
    z[6,5,1]  R2289     -4.5288136601448059e-01
    z[6,5,1]  R2290     -5.1484644412994385e-01
    z[6,5,1]  R2291     -7.8515373170375824e-02
    z[6,5,1]  R2292     -0.761551022529602
    z[6,5,1]  R2293     -3.1575447320938110e-01
    z[6,5,1]  R2294     -5.6011569499969482e-01
    z[6,5,1]  R2295     -4.9273529648780823e-01
    z[6,5,1]  R2296     -4.4910877943038940e-01
    z[6,5,1]  R2297     -1.6063762828707695e-02
    z[6,5,1]  R2298     5.6766015291213989e-01
    z[6,5,1]  R2299     4.3509021401405334e-01
    z[6,5,1]  R2300     3.0859598517417908e-01
    z[6,5,1]  R2301     7.0993030071258545e-01
    z[6,5,1]  R2302     4.9765196442604065e-01
    z[6,5,1]  R2303     6.6561222076416016e-01
    z[6,5,2]  R49       1
    z[6,5,2]  R58       -1
    z[6,5,2]  R2204     -1
    z[6,5,2]  R2205     1
    z[6,5,2]  R2214     -1.1657848954200745e-01
    z[6,5,2]  R2215     -0.27797931432724
    z[6,5,2]  R2216     -2.8962761163711548e-01
    z[6,5,2]  R2217     9.1380268335342407e-02
    z[6,5,2]  R2218     1.9642254710197449e-01
    z[6,5,2]  R2219     -3.4210613369941711e-01
    z[6,5,2]  R2220     1.8819691240787506e-01
    z[6,5,2]  R2221     -3.0000713467597961e-01
    z[6,5,2]  R2222     -9.1953672468662262e-02
    z[6,5,2]  R2223     -1.1292373389005661e-01
    z[6,5,2]  R2224     -1.0943014174699783e-01
    z[6,5,2]  R2225     -0.0857386440038681
    z[6,5,2]  R2226     -3.6604857444763184e-01
    z[6,5,2]  R2227     -2.0322367548942566e-01
    z[6,5,2]  R2228     2.7266851067543030e-01
    z[6,5,2]  R2229     1.0813126713037491e-01
    z[6,5,2]  R2230     1.0796468704938889e-01
    z[6,5,2]  R2231     7.8948169946670532e-01
    z[6,5,2]  R2232     2.6973477005958557e-01
    z[6,5,2]  R2233     4.8148965835571289e-01
    z[6,5,2]  R2234     0.413653701543808
    z[6,5,2]  R2235     0.342832088470459
    z[6,5,2]  R2236     -2.6855310425162315e-02
    z[6,5,2]  R2237     -0.0953153595328331
    z[6,5,2]  R2238     4.4445610046386719e-01
    z[6,5,2]  R2239     3.8897311687469482e-01
    z[6,5,2]  R2240     -1.4220274984836578e-01
    z[6,5,2]  R2241     0.567274808883667
    z[6,5,2]  R2242     6.6093361377716064e-01
    z[6,5,2]  R2243     4.6385416388511658e-01
    z[6,5,2]  R2244     4.8049096018075943e-02
    z[6,5,2]  R2245     1.9378603994846344e-01
    z[6,5,2]  R2246     7.5120642781257629e-02
    z[6,5,2]  R2247     -2.4247172474861145e-01
    z[6,5,2]  R2248     -4.8259615898132324e-01
    z[6,5,2]  R2249     3.5424941778182983e-01
    z[6,5,2]  R2250     -1.0859417915344238e-01
    z[6,5,2]  R2251     9.9274478852748871e-02
    z[6,5,2]  R2252     5.9204649925231934e-01
    z[6,5,2]  R2253     -5.3504716604948044e-02
    z[6,5,2]  R2254     1.3208520412445068e-01
    z[6,5,2]  R2255     -3.8682025671005249e-01
    z[6,5,2]  R2256     -3.9834859967231750e-01
    z[6,5,2]  R2257     -3.8881012797355652e-01
    z[6,5,2]  R2258     -5.8433258533477783e-01
    z[6,5,2]  R2259     -3.4658560156822205e-01
    z[6,5,2]  R2260     -3.4464821219444275e-01
    z[6,5,2]  R2261     -1.6381615400314331e-01
    z[6,5,2]  R2262     -3.1097128987312317e-01
    z[6,5,2]  R2263     -1.8465775251388550e-01
    z[6,5,2]  R2264     6.1017107963562012e-01
    z[6,5,2]  R2265     3.4490790963172913e-01
    z[6,5,2]  R2266     2.8559392690658569e-01
    z[6,5,2]  R2267     7.7999740839004517e-01
    z[6,5,2]  R2268     3.7083712220191956e-01
    z[6,5,2]  R2269     7.3896294832229614e-01
    z[6,5,2]  R2270     0.58495032787323
    z[6,5,2]  R2271     4.0773600339889526e-01
    z[6,5,2]  R2272     1.9199748337268829e-01
    z[6,5,2]  R2273     6.0725563764572144e-01
    z[6,5,2]  R2274     1.7580537497997284e-01
    z[6,5,2]  R2275     2.8710660338401794e-01
    z[6,5,2]  R2276     -5.9267640113830566e-01
    z[6,5,2]  R2277     -4.9337202310562134e-01
    z[6,5,2]  R2278     -6.0816633701324463e-01
    z[6,5,2]  R2279     3.6779043078422546e-01
    z[6,5,2]  R2280     -3.5593810677528381e-01
    z[6,5,2]  R2281     -8.0446094274520874e-01
    z[6,5,2]  R2282     -6.1851215362548828e-01
    z[6,5,2]  R2283     -6.6251236200332642e-01
    z[6,5,2]  R2284     1.0689135640859604e-01
    z[6,5,2]  R2285     2.2233678400516510e-01
    z[6,5,2]  R2286     -1.5225446224212646e-01
    z[6,5,2]  R2287     2.5967153906822205e-01
    z[6,5,2]  R2288     3.7751322984695435e-01
    z[6,5,2]  R2289     1.2850096821784973e-01
    z[6,5,2]  R2290     -4.1867870092391968e-01
    z[6,5,2]  R2291     -3.2843223214149475e-01
    z[6,5,2]  R2292     -2.2259384393692017e-01
    z[6,5,2]  R2293     5.9010386466979980e-01
    z[6,5,2]  R2294     6.1665505170822144e-01
    z[6,5,2]  R2295     7.0563161373138428e-01
    z[6,5,2]  R2296     3.8184961676597595e-01
    z[6,5,2]  R2297     -6.5093362331390381e-01
    z[6,5,2]  R2298     -3.8382175564765930e-01
    z[6,5,2]  R2299     -1.7292433977127075e-01
    z[6,5,2]  R2300     -4.8232406377792358e-01
    z[6,5,2]  R2301     1.7470008134841919e-01
    z[6,5,2]  R2302     7.2153680026531219e-02
    z[6,5,2]  R2303     1.4411626756191254e-01
    z[6,5,3]  R50       1
    z[6,5,3]  R59       -1
    z[6,5,3]  R2206     -1
    z[6,5,3]  R2207     1
    z[6,5,3]  R2214     -0.85221928358078
    z[6,5,3]  R2215     -8.1240195035934448e-01
    z[6,5,3]  R2216     -5.2628499269485474e-01
    z[6,5,3]  R2217     -7.5213503837585449e-01
    z[6,5,3]  R2218     -4.3814745545387268e-01
    z[6,5,3]  R2219     1.2706759572029114e-01
    z[6,5,3]  R2220     3.4517151117324829e-01
    z[6,5,3]  R2221     -1.5411342494189739e-02
    z[6,5,3]  R2222     2.3107966780662537e-01
    z[6,5,3]  R2223     -5.8358427137136459e-02
    z[6,5,3]  R2224     4.1151252388954163e-01
    z[6,5,3]  R2225     5.9133970737457275e-01
    z[6,5,3]  R2226     5.1580494642257690e-01
    z[6,5,3]  R2227     7.1391516923904419e-01
    z[6,5,3]  R2228     3.2900074124336243e-01
    z[6,5,3]  R2229     6.9959261454641819e-03
    z[6,5,3]  R2230     3.8137266039848328e-01
    z[6,5,3]  R2231     0.338481068611145
    z[6,5,3]  R2232     2.3638258874416351e-01
    z[6,5,3]  R2233     -0.462100625038147
    z[6,5,3]  R2234     4.8471182584762573e-01
    z[6,5,3]  R2235     4.3285819888114929e-01
    z[6,5,3]  R2236     4.2439797520637512e-01
    z[6,5,3]  R2237     4.8455065488815308e-01
    z[6,5,3]  R2238     4.9847099184989929e-01
    z[6,5,3]  R2239     3.9329320192337036e-01
    z[6,5,3]  R2240     4.8132848739624023e-01
    z[6,5,3]  R2241     5.7116001844406128e-01
    z[6,5,3]  R2242     8.5973121225833893e-02
    z[6,5,3]  R2243     0.566581130027771
    z[6,5,3]  R2244     0.543865442276001
    z[6,5,3]  R2245     4.8258337378501892e-01
    z[6,5,3]  R2246     4.3860536813735962e-01
    z[6,5,3]  R2247     7.4338442087173462e-01
    z[6,5,3]  R2248     7.0555222034454346e-01
    z[6,5,3]  R2249     1.0699941217899323e-01
    z[6,5,3]  R2250     4.6006390452384949e-01
    z[6,5,3]  R2251     2.5437566637992859e-01
    z[6,5,3]  R2252     3.3498144149780273e-01
    z[6,5,3]  R2253     1.4639307558536530e-01
    z[6,5,3]  R2254     0.0196211077272892
    z[6,5,3]  R2255     -0.701768696308136
    z[6,5,3]  R2256     -6.5325957536697388e-01
    z[6,5,3]  R2257     -7.0325976610183716e-01
    z[6,5,3]  R2258     -6.5420705080032349e-01
    z[6,5,3]  R2259     -6.7545342445373535e-01
    z[6,5,3]  R2260     -6.6219961643218994e-01
    z[6,5,3]  R2261     -7.0152705907821655e-01
    z[6,5,3]  R2262     -7.6354062557220459e-01
    z[6,5,3]  R2263     -7.1497130393981934e-01
    z[6,5,3]  R2264     -1.7959071695804596e-01
    z[6,5,3]  R2265     7.4589416384696960e-02
    z[6,5,3]  R2266     2.4222701787948608e-01
    z[6,5,3]  R2267     2.7327957749366760e-01
    z[6,5,3]  R2268     -1.5850800275802612e-01
    z[6,5,3]  R2269     -4.3000063300132751e-01
    z[6,5,3]  R2270     2.2664192318916321e-01
    z[6,5,3]  R2271     1.2618897855281830e-01
    z[6,5,3]  R2272     -2.5506886839866638e-01
    z[6,5,3]  R2273     3.7588068842887878e-01
    z[6,5,3]  R2274     -2.2563324868679047e-01
    z[6,5,3]  R2275     2.3195911198854446e-02
    z[6,5,3]  R2276     0.390370637178421
    z[6,5,3]  R2277     3.8116759061813354e-01
    z[6,5,3]  R2278     3.2221826910972595e-01
    z[6,5,3]  R2279     -2.9729706048965454e-01
    z[6,5,3]  R2280     3.3737942576408386e-01
    z[6,5,3]  R2281     3.2657852768898010e-01
    z[6,5,3]  R2282     3.4689873456954956e-01
    z[6,5,3]  R2283     3.2710546255111694e-01
    z[6,5,3]  R2284     -3.4157100319862366e-01
    z[6,5,3]  R2285     -1.9333158433437347e-01
    z[6,5,3]  R2286     -3.9478850364685059e-01
    z[6,5,3]  R2287     -4.0185242891311646e-01
    z[6,5,3]  R2288     -1.7905758321285248e-01
    z[6,5,3]  R2289     -0.620050847530365
    z[6,5,3]  R2290     6.9500762224197388e-01
    z[6,5,3]  R2291     0.589187502861023
    z[6,5,3]  R2292     -1.3092766702175140e-01
    z[6,5,3]  R2293     -4.1605284810066223e-01
    z[6,5,3]  R2294     -3.2427427172660828e-01
    z[6,5,3]  R2295     2.1129217743873596e-01
    z[6,5,3]  R2296     3.5562857985496521e-01
    z[6,5,3]  R2297     6.7207229137420654e-01
    z[6,5,3]  R2298     5.5396783351898193e-01
    z[6,5,3]  R2299     4.8108518123626709e-01
    z[6,5,3]  R2300     4.1041249036788940e-01
    z[6,5,3]  R2301     -1.6488130390644073e-01
    z[6,5,3]  R2302     -1.4268906414508820e-01
    z[6,5,3]  R2303     8.8368929922580719e-02
    z[6,5,4]  R51       1
    z[6,5,4]  R60       -1
    z[6,5,4]  R2208     -1
    z[6,5,4]  R2209     1
    z[6,5,4]  R2214     2.0948500931262970e-01
    z[6,5,4]  R2215     -3.1193265318870544e-01
    z[6,5,4]  R2216     -1.3032099604606628e-01
    z[6,5,4]  R2217     -4.3716788291931152e-02
    z[6,5,4]  R2218     -2.6139837503433228e-01
    z[6,5,4]  R2219     -1.1416272819042206e-01
    z[6,5,4]  R2220     4.3638557195663452e-01
    z[6,5,4]  R2221     -2.4576272070407867e-01
    z[6,5,4]  R2222     -5.5505480617284775e-02
    z[6,5,4]  R2223     2.8016555309295654e-01
    z[6,5,4]  R2224     5.6557816267013550e-01
    z[6,5,4]  R2225     -3.4651103615760803e-01
    z[6,5,4]  R2226     -3.6873687058687210e-02
    z[6,5,4]  R2227     -1.4194028079509735e-01
    z[6,5,4]  R2228     -2.9900604486465454e-01
    z[6,5,4]  R2229     0.667676568031311
    z[6,5,4]  R2230     1.8114092946052551e-01
    z[6,5,4]  R2231     -4.0168181061744690e-02
    z[6,5,4]  R2232     2.1784137934446335e-02
    z[6,5,4]  R2233     -4.7689802944660187e-02
    z[6,5,4]  R2234     1.3894718885421753e-01
    z[6,5,4]  R2235     2.0598727464675903e-01
    z[6,5,4]  R2236     3.7436592578887939e-01
    z[6,5,4]  R2237     -1.3234195113182068e-01
    z[6,5,4]  R2238     -1.9997909665107727e-01
    z[6,5,4]  R2239     2.9672408103942871e-01
    z[6,5,4]  R2240     -3.4363400936126709e-01
    z[6,5,4]  R2241     -1.0641941428184509e-01
    z[6,5,4]  R2242     -0.382472962141037
    z[6,5,4]  R2243     -4.4036373496055603e-01
    z[6,5,4]  R2244     1.1417217552661896e-01
    z[6,5,4]  R2245     1.5343791246414185e-01
    z[6,5,4]  R2246     3.6165687441825867e-01
    z[6,5,4]  R2247     -4.7659203410148621e-01
    z[6,5,4]  R2248     -0.0654422715306282
    z[6,5,4]  R2249     4.0773589164018631e-02
    z[6,5,4]  R2250     3.0711600184440613e-01
    z[6,5,4]  R2251     9.1799207031726837e-02
    z[6,5,4]  R2252     9.9960751831531525e-02
    z[6,5,4]  R2253     3.4307071566581726e-01
    z[6,5,4]  R2254     1.5048332512378693e-01
    z[6,5,4]  R2255     -3.2633045315742493e-01
    z[6,5,4]  R2256     -1.6680608689785004e-01
    z[6,5,4]  R2257     -4.1913607716560364e-01
    z[6,5,4]  R2258     -9.9355258047580719e-02
    z[6,5,4]  R2259     -1.8634644150733948e-01
    z[6,5,4]  R2260     1.2752544879913330e-01
    z[6,5,4]  R2261     -1.3623578846454620e-01
    z[6,5,4]  R2262     -1.9300854206085205e-01
    z[6,5,4]  R2263     -2.0560650527477264e-01
    z[6,5,4]  R2264     -4.2824211716651917e-01
    z[6,5,4]  R2265     -1.6616936028003693e-01
    z[6,5,4]  R2266     -5.2697628736495972e-01
    z[6,5,4]  R2267     -4.4625130295753479e-01
    z[6,5,4]  R2268     3.8606348633766174e-01
    z[6,5,4]  R2269     -1.2558455578982830e-02
    z[6,5,4]  R2270     -5.8654683828353882e-01
    z[6,5,4]  R2271     1.7067460715770721e-01
    z[6,5,4]  R2272     3.1366115808486938e-01
    z[6,5,4]  R2273     2.1508924663066864e-01
    z[6,5,4]  R2274     3.9654234051704407e-01
    z[6,5,4]  R2275     -1.3074333965778351e-01
    z[6,5,4]  R2276     -2.6131460443139076e-02
    z[6,5,4]  R2277     -2.5739734992384911e-02
    z[6,5,4]  R2278     -4.4466635584831238e-01
    z[6,5,4]  R2279     5.0851291418075562e-01
    z[6,5,4]  R2280     -4.8996168375015259e-01
    z[6,5,4]  R2281     -3.6061301361769438e-03
    z[6,5,4]  R2282     2.9170578718185425e-01
    z[6,5,4]  R2283     6.2315058708190918e-01
    z[6,5,4]  R2284     -1.0473524034023285e-01
    z[6,5,4]  R2285     2.4731905758380890e-01
    z[6,5,4]  R2286     -4.7590738534927368e-01
    z[6,5,4]  R2287     1.2608104385435581e-02
    z[6,5,4]  R2288     -2.5923281908035278e-01
    z[6,5,4]  R2289     -2.3029941320419312e-01
    z[6,5,4]  R2290     -1.4339910447597504e-01
    z[6,5,4]  R2291     2.5317385792732239e-01
    z[6,5,4]  R2292     -1.3775067031383514e-01
    z[6,5,4]  R2293     4.3282940983772278e-01
    z[6,5,4]  R2294     -0.165388822555542
    z[6,5,4]  R2295     -1.3358780741691589e-01
    z[6,5,4]  R2296     -4.8172404058277607e-03
    z[6,5,4]  R2297     -0.0821036770939827
    z[6,5,4]  R2298     -1.8744440376758575e-01
    z[6,5,4]  R2299     5.8051735162734985e-01
    z[6,5,4]  R2300     5.5524122714996338e-01
    z[6,5,4]  R2301     -7.4247263371944427e-02
    z[6,5,4]  R2302     -4.5442916452884674e-02
    z[6,5,4]  R2303     -2.5031277909874916e-02
    z[6,5,5]  R52       1
    z[6,5,5]  R61       -1
    z[6,5,5]  R2210     -1
    z[6,5,5]  R2211     1
    z[6,5,5]  R2214     -4.1011118888854980e-01
    z[6,5,5]  R2215     -3.5467270016670227e-01
    z[6,5,5]  R2216     -6.7898106575012207e-01
    z[6,5,5]  R2217     -3.8434910774230957e-01
    z[6,5,5]  R2218     -6.0099124908447266e-01
    z[6,5,5]  R2219     8.2026623189449310e-02
    z[6,5,5]  R2220     -2.9660975933074951e-01
    z[6,5,5]  R2221     4.6530964970588684e-01
    z[6,5,5]  R2222     5.5250751972198486e-01
    z[6,5,5]  R2223     4.3743756413459778e-01
    z[6,5,5]  R2224     -3.0136564373970032e-01
    z[6,5,5]  R2225     3.5118868947029114e-01
    z[6,5,5]  R2226     7.3869693279266357e-01
    z[6,5,5]  R2227     -2.6882886886596680e-01
    z[6,5,5]  R2228     -4.3684488534927368e-01
    z[6,5,5]  R2229     3.1190750002861023e-01
    z[6,5,5]  R2230     5.0793045759201050e-01
    z[6,5,5]  R2231     4.7194175422191620e-02
    z[6,5,5]  R2232     8.8561016321182251e-01
    z[6,5,5]  R2233     7.0759785175323486e-01
    z[6,5,5]  R2234     7.4784934520721436e-01
    z[6,5,5]  R2235     7.0382225513458252e-01
    z[6,5,5]  R2236     7.0949828624725342e-01
    z[6,5,5]  R2237     7.6195400953292847e-01
    z[6,5,5]  R2238     5.8875405788421631e-01
    z[6,5,5]  R2239     6.5910464525222778e-01
    z[6,5,5]  R2240     7.7146822214126587e-01
    z[6,5,5]  R2241     2.8881141543388367e-01
    z[6,5,5]  R2242     -3.2654516398906708e-02
    z[6,5,5]  R2243     4.1194760799407959e-01
    z[6,5,5]  R2244     7.1507257223129272e-01
    z[6,5,5]  R2245     8.2039844989776611e-01
    z[6,5,5]  R2246     6.3013392686843872e-01
    z[6,5,5]  R2247     1.5305669605731964e-01
    z[6,5,5]  R2248     3.7789145112037659e-01
    z[6,5,5]  R2249     -4.2847845703363419e-02
    z[6,5,5]  R2250     4.6800276637077332e-01
    z[6,5,5]  R2251     3.1855154037475586e-01
    z[6,5,5]  R2252     1.1651323735713959e-01
    z[6,5,5]  R2253     3.0713552236557007e-01
    z[6,5,5]  R2254     3.9202713966369629e-01
    z[6,5,5]  R2255     -3.0105775594711304e-01
    z[6,5,5]  R2256     -2.9000511765480042e-01
    z[6,5,5]  R2257     -3.1298825144767761e-01
    z[6,5,5]  R2258     -2.5966253876686096e-01
    z[6,5,5]  R2259     -3.7169870734214783e-01
    z[6,5,5]  R2260     -3.0928614735603333e-01
    z[6,5,5]  R2261     -4.8580473661422729e-01
    z[6,5,5]  R2262     -1.5923266112804413e-01
    z[6,5,5]  R2263     -1.8636988475918770e-02
    z[6,5,5]  R2264     4.3766376376152039e-01
    z[6,5,5]  R2265     4.7934854030609131e-01
    z[6,5,5]  R2266     3.0896827578544617e-01
    z[6,5,5]  R2267     -5.0114773213863373e-02
    z[6,5,5]  R2268     5.7238936424255371e-01
    z[6,5,5]  R2269     1.4931109547615051e-01
    z[6,5,5]  R2270     -2.4780185520648956e-01
    z[6,5,5]  R2271     6.6247540712356567e-01
    z[6,5,5]  R2272     7.9129147529602051e-01
    z[6,5,5]  R2273     6.2015217542648315e-01
    z[6,5,5]  R2274     8.2093071937561035e-01
    z[6,5,5]  R2275     -3.2185354828834534e-01
    z[6,5,5]  R2276     6.9746315479278564e-02
    z[6,5,5]  R2277     3.5823008418083191e-01
    z[6,5,5]  R2278     -2.6745175942778587e-02
    z[6,5,5]  R2279     -5.3570348024368286e-01
    z[6,5,5]  R2280     -6.4375501871109009e-01
    z[6,5,5]  R2281     -3.1721353530883789e-01
    z[6,5,5]  R2282     -2.1833148598670959e-01
    z[6,5,5]  R2283     1.3217644765973091e-02
    z[6,5,5]  R2284     4.9586769938468933e-01
    z[6,5,5]  R2285     -5.7216089963912964e-01
    z[6,5,5]  R2286     -7.6155602000653744e-03
    z[6,5,5]  R2287     -4.1675922274589539e-01
    z[6,5,5]  R2288     -2.5325170159339905e-01
    z[6,5,5]  R2289     -3.5454273223876953e-01
    z[6,5,5]  R2290     -4.6683784574270248e-02
    z[6,5,5]  R2291     2.7457234263420105e-01
    z[6,5,5]  R2292     -5.3711551427841187e-01
    z[6,5,5]  R2293     -2.4102471768856049e-01
    z[6,5,5]  R2294     2.3109711706638336e-01
    z[6,5,5]  R2295     -1.1135119944810867e-01
    z[6,5,5]  R2296     5.9610503911972046e-01
    z[6,5,5]  R2297     -3.2514768838882446e-01
    z[6,5,5]  R2298     -1.4958518743515015e-01
    z[6,5,5]  R2299     -2.8918331861495972e-01
    z[6,5,5]  R2300     3.2546848058700562e-01
    z[6,5,5]  R2301     -1.7712321877479553e-01
    z[6,5,5]  R2302     0.00496411370113492
    z[6,5,5]  R2303     -9.9545374512672424e-02
    z[6,5,6]  R53       1
    z[6,5,6]  R62       -1
    z[6,5,6]  R2212     -1
    z[6,5,6]  R2213     1
    z[6,5,6]  R2214     1.4036749303340912e-01
    z[6,5,6]  R2215     -3.1022084876894951e-02
    z[6,5,6]  R2216     -3.5945597290992737e-01
    z[6,5,6]  R2217     -3.4882813692092896e-01
    z[6,5,6]  R2218     0.0961492657661438
    z[6,5,6]  R2219     5.1711469888687134e-01
    z[6,5,6]  R2220     -6.0955983400344849e-01
    z[6,5,6]  R2221     -4.3923977762460709e-02
    z[6,5,6]  R2222     4.0581443905830383e-01
    z[6,5,6]  R2223     -5.3546506166458130e-01
    z[6,5,6]  R2224     1.2044569849967957e-01
    z[6,5,6]  R2225     -1.3086408376693726e-01
    z[6,5,6]  R2226     -2.1284069120883942e-01
    z[6,5,6]  R2227     -2.0879344642162323e-01
    z[6,5,6]  R2228     0.389967143535614
    z[6,5,6]  R2229     -2.4880394339561462e-01
    z[6,5,6]  R2230     1.0923012346029282e-01
    z[6,5,6]  R2231     2.9357701539993286e-01
    z[6,5,6]  R2232     -1.3189360499382019e-01
    z[6,5,6]  R2233     -4.1599976248107851e-04
    z[6,5,6]  R2234     9.6221163868904114e-02
    z[6,5,6]  R2235     -1.5994152426719666e-01
    z[6,5,6]  R2236     -6.3475859351456165e-03
    z[6,5,6]  R2237     -3.4419447183609009e-01
    z[6,5,6]  R2238     2.2703444585204124e-02
    z[6,5,6]  R2239     1.1628524214029312e-01
    z[6,5,6]  R2240     9.9947135895490646e-03
    z[6,5,6]  R2241     2.9199233651161194e-01
    z[6,5,6]  R2242     2.8093319386243820e-02
    z[6,5,6]  R2243     1.5568609535694122e-01
    z[6,5,6]  R2244     -1.7072907090187073e-01
    z[6,5,6]  R2245     1.7637057602405548e-01
    z[6,5,6]  R2246     3.7995925545692444e-01
    z[6,5,6]  R2247     -2.4157127737998962e-01
    z[6,5,6]  R2248     -2.4933594465255737e-01
    z[6,5,6]  R2249     1.1855491995811462e-01
    z[6,5,6]  R2250     5.7565051317214966e-01
    z[6,5,6]  R2251     -8.5030794143676758e-02
    z[6,5,6]  R2252     -1.3771559298038483e-01
    z[6,5,6]  R2253     -8.6030957754701376e-04
    z[6,5,6]  R2254     -4.2428311705589294e-01
    z[6,5,6]  R2255     1.6255371272563934e-01
    z[6,5,6]  R2256     2.2395044565200806e-02
    z[6,5,6]  R2257     -1.9215951859951019e-01
    z[6,5,6]  R2258     -6.3041254878044128e-02
    z[6,5,6]  R2259     -3.3454650640487671e-01
    z[6,5,6]  R2260     -1.7019891738891602e-01
    z[6,5,6]  R2261     -1.8781930208206177e-01
    z[6,5,6]  R2262     -2.9430219531059265e-01
    z[6,5,6]  R2263     -1.4466480910778046e-01
    z[6,5,6]  R2264     3.9500033855438232e-01
    z[6,5,6]  R2265     5.2732348442077637e-01
    z[6,5,6]  R2266     4.1301050782203674e-01
    z[6,5,6]  R2267     2.1734927594661713e-01
    z[6,5,6]  R2268     2.3387011885643005e-01
    z[6,5,6]  R2269     2.1436008810997009e-01
    z[6,5,6]  R2270     -1.4395037293434143e-01
    z[6,5,6]  R2271     5.0748473405838013e-01
    z[6,5,6]  R2272     0.391669362783432
    z[6,5,6]  R2273     2.1751639246940613e-01
    z[6,5,6]  R2274     1.1161798238754272e-01
    z[6,5,6]  R2275     -3.3665984869003296e-01
    z[6,5,6]  R2276     4.5295679569244385e-01
    z[6,5,6]  R2277     2.1982754766941071e-01
    z[6,5,6]  R2278     0.0766829177737236
    z[6,5,6]  R2279     -5.3929977118968964e-02
    z[6,5,6]  R2280     -1.0123301297426224e-01
    z[6,5,6]  R2281     -2.4040430784225464e-01
    z[6,5,6]  R2282     -1.9400058686733246e-01
    z[6,5,6]  R2283     -9.2867843806743622e-02
    z[6,5,6]  R2284     2.6835662126541138e-01
    z[6,5,6]  R2285     2.2843407094478607e-01
    z[6,5,6]  R2286     1.0012534260749817e-01
    z[6,5,6]  R2287     9.2617996037006378e-02
    z[6,5,6]  R2288     -3.1498336791992188e-01
    z[6,5,6]  R2289     -2.8844013810157776e-01
    z[6,5,6]  R2290     -2.1436761319637299e-01
    z[6,5,6]  R2291     -2.7449825406074524e-01
    z[6,5,6]  R2292     8.1667736172676086e-02
    z[6,5,6]  R2293     -3.2363036274909973e-01
    z[6,5,6]  R2294     -2.4558429419994354e-01
    z[6,5,6]  R2295     -4.1955778002738953e-01
    z[6,5,6]  R2296     -7.0165641605854034e-02
    z[6,5,6]  R2297     -4.7278359532356262e-02
    z[6,5,6]  R2298     4.0526536107063293e-01
    z[6,5,6]  R2299     -3.5619777441024780e-01
    z[6,5,6]  R2300     1.9313147664070129e-01
    z[6,5,6]  R2301     -5.2450164221227169e-03
    z[6,5,6]  R2302     -1.0943074524402618e-01
    z[6,5,6]  R2303     -4.7539673745632172e-02
    z[6,7,0]  R56       -1
    z[6,7,0]  R65       1
    z[6,7,0]  R2368     -1
    z[6,7,0]  R2369     1
    z[6,7,0]  R2382     0.00948364194482565
    z[6,7,0]  R2383     -7.2981618344783783e-02
    z[6,7,0]  R2384     1.3737419247627258e-01
    z[6,7,0]  R2385     3.1392046809196472e-01
    z[6,7,0]  R2386     -2.3087984323501587e-01
    z[6,7,0]  R2387     -4.2213848233222961e-01
    z[6,7,0]  R2388     1.6414934396743774e-01
    z[6,7,0]  R2389     3.0744003131985664e-02
    z[6,7,0]  R2390     -2.0722879469394684e-01
    z[6,7,0]  R2391     -4.4394785165786743e-01
    z[6,7,0]  R2392     1.7102941870689392e-01
    z[6,7,0]  R2393     -1.8538489937782288e-02
    z[6,7,0]  R2394     8.7123408913612366e-02
    z[6,7,0]  R2395     4.1409574449062347e-02
    z[6,7,0]  R2396     -3.5936015844345093e-01
    z[6,7,0]  R2397     4.4195351004600525e-01
    z[6,7,0]  R2398     6.2430912256240845e-01
    z[6,7,0]  R2399     -8.7492220103740692e-02
    z[6,7,0]  R2400     2.5624117255210876e-01
    z[6,7,0]  R2401     1.1700862646102905e-01
    z[6,7,0]  R2402     5.0234988331794739e-02
    z[6,7,0]  R2403     2.8864863514900208e-01
    z[6,7,0]  R2404     2.2634042799472809e-01
    z[6,7,0]  R2405     1.8652193248271942e-01
    z[6,7,0]  R2406     8.8945478200912476e-03
    z[6,7,0]  R2407     1.6408419609069824e-01
    z[6,7,0]  R2408     -1.7532561719417572e-01
    z[6,7,0]  R2409     -1.5319344401359558e-01
    z[6,7,0]  R2410     -1.9433531910181046e-02
    z[6,7,0]  R2411     -2.4648292362689972e-01
    z[6,7,0]  R2412     2.1938095986843109e-01
    z[6,7,0]  R2413     -1.9774494692683220e-02
    z[6,7,0]  R2414     -3.9564505219459534e-02
    z[6,7,0]  R2415     -1.0036766529083252e-01
    z[6,7,0]  R2416     6.9954305887222290e-02
    z[6,7,0]  R2417     9.8391972482204437e-02
    z[6,7,0]  R2418     -3.1425106525421143e-01
    z[6,7,0]  R2419     -1.5212918631732464e-02
    z[6,7,0]  R2420     2.8497523069381714e-01
    z[6,7,0]  R2421     2.9772745445370674e-02
    z[6,7,0]  R2422     0.831761360168457
    z[6,7,0]  R2423     9.2205941677093506e-01
    z[6,7,0]  R2424     8.5395079851150513e-01
    z[6,7,0]  R2425     7.1274155378341675e-01
    z[6,7,0]  R2426     8.4566819667816162e-01
    z[6,7,0]  R2427     6.3203769922256470e-01
    z[6,7,0]  R2428     6.9810485839843750e-01
    z[6,7,0]  R2429     -1.6135847568511963e-01
    z[6,7,0]  R2430     -1.4748410880565643e-01
    z[6,7,0]  R2431     1.5411005914211273e-01
    z[6,7,0]  R2432     -2.0003539323806763e-01
    z[6,7,0]  R2433     -5.4264968633651733e-01
    z[6,7,0]  R2434     -5.2113640308380127e-01
    z[6,7,0]  R2435     -5.5860871076583862e-01
    z[6,7,0]  R2436     -1.8229384720325470e-01
    z[6,7,0]  R2437     -4.6869260072708130e-01
    z[6,7,0]  R2438     -4.7543257474899292e-01
    z[6,7,0]  R2439     -5.8686113357543945e-01
    z[6,7,0]  R2440     -2.1261937916278839e-01
    z[6,7,0]  R2441     -5.0665266811847687e-02
    z[6,7,0]  R2442     -2.2017173469066620e-01
    z[6,7,0]  R2443     -1.0050955414772034e-01
    z[6,7,0]  R2444     -3.8916191458702087e-01
    z[6,7,0]  R2445     3.5358372330665588e-01
    z[6,7,0]  R2446     1.0035784542560577e-01
    z[6,7,0]  R2447     -3.2422360777854919e-01
    z[6,7,0]  R2448     5.0990432500839233e-01
    z[6,7,0]  R2449     7.3181706666946411e-01
    z[6,7,0]  R2450     3.9688837714493275e-03
    z[6,7,0]  R2451     -7.7977222204208374e-01
    z[6,7,0]  R2452     -0.8011514544487
    z[6,7,0]  R2453     -6.4584916830062866e-01
    z[6,7,0]  R2454     -6.4749133586883545e-01
    z[6,7,0]  R2455     -0.866128146648407
    z[6,7,0]  R2456     -5.2334684133529663e-01
    z[6,7,0]  R2457     -9.0055245161056519e-01
    z[6,7,0]  R2458     -5.1530826091766357e-01
    z[6,7,0]  R2459     -4.6573814749717712e-01
    z[6,7,0]  R2460     4.4696500897407532e-01
    z[6,7,0]  R2461     0.421758234500885
    z[6,7,0]  R2462     -0.128040611743927
    z[6,7,0]  R2463     -2.0239213481545448e-02
    z[6,7,0]  R2464     -7.9799783229827881e-01
    z[6,7,0]  R2465     -1.4799687266349792e-01
    z[6,7,0]  R2466     -3.1945714354515076e-01
    z[6,7,0]  R2467     0.718023955821991
    z[6,7,0]  R2468     1.3686415553092957e-01
    z[6,7,0]  R2469     2.3470732569694519e-01
    z[6,7,0]  R2470     1.2830194830894470e-01
    z[6,7,0]  R2471     -2.8881579637527466e-02
    z[6,7,0]  R2472     -1.2167088687419891e-01
    z[6,7,0]  R2473     2.9862058162689209e-01
    z[6,7,0]  R2474     -2.7959802746772766e-01
    z[6,7,0]  R2475     6.2875278294086456e-02
    z[6,7,0]  R2476     -0.276602566242218
    z[6,7,0]  R2477     -7.9921597242355347e-01
    z[6,7,0]  R2478     -1.3351860642433167e-01
    z[6,7,0]  R2479     -0.386550635099411
    z[6,7,0]  R2480     1.8768247961997986e-01
    z[6,7,0]  R2481     0.360411673784256
    z[6,7,1]  R57       -1
    z[6,7,1]  R66       1
    z[6,7,1]  R2370     -1
    z[6,7,1]  R2371     1
    z[6,7,1]  R2382     1.6811764240264893e-01
    z[6,7,1]  R2383     -1.8261192739009857e-01
    z[6,7,1]  R2384     1.1428344249725342e-01
    z[6,7,1]  R2385     -2.3681230843067169e-01
    z[6,7,1]  R2386     5.2666431665420532e-01
    z[6,7,1]  R2387     -6.3359868526458740e-01
    z[6,7,1]  R2388     -4.1051259636878967e-01
    z[6,7,1]  R2389     -7.9370737075805664e-01
    z[6,7,1]  R2390     -6.4974778890609741e-01
    z[6,7,1]  R2391     -4.7977665066719055e-01
    z[6,7,1]  R2392     -6.0350996255874634e-01
    z[6,7,1]  R2393     -6.1813724040985107e-01
    z[6,7,1]  R2394     -5.3952005691826344e-03
    z[6,7,1]  R2395     -5.5794250965118408e-01
    z[6,7,1]  R2396     -5.0592315196990967e-01
    z[6,7,1]  R2397     4.3353664875030518e-01
    z[6,7,1]  R2398     -3.8781440258026123e-01
    z[6,7,1]  R2399     -4.0554407238960266e-01
    z[6,7,1]  R2400     -0.0594235435128212
    z[6,7,1]  R2401     1.9486029446125031e-01
    z[6,7,1]  R2402     5.9816908091306686e-02
    z[6,7,1]  R2403     -2.2000917792320251e-01
    z[6,7,1]  R2404     -0.352643221616745
    z[6,7,1]  R2405     -6.9116353988647461e-02
    z[6,7,1]  R2406     -4.0837228298187256e-01
    z[6,7,1]  R2407     -0.362091600894928
    z[6,7,1]  R2408     6.3361212611198425e-02
    z[6,7,1]  R2409     -3.8537091016769409e-01
    z[6,7,1]  R2410     -0.638166606426239
    z[6,7,1]  R2411     -1.2333747744560242e-01
    z[6,7,1]  R2412     -3.1664052605628967e-01
    z[6,7,1]  R2413     3.8286406546831131e-02
    z[6,7,1]  R2414     -3.5802689194679260e-01
    z[6,7,1]  R2415     -2.6379999518394470e-01
    z[6,7,1]  R2416     -2.3484107851982117e-01
    z[6,7,1]  R2417     -9.1423398256301880e-01
    z[6,7,1]  R2418     1.8186372518539429e-01
    z[6,7,1]  R2419     8.9892917871475220e-01
    z[6,7,1]  R2420     -0.643058717250824
    z[6,7,1]  R2421     8.7337815761566162e-01
    z[6,7,1]  R2422     1.1788117140531540e-01
    z[6,7,1]  R2423     -5.7180680334568024e-02
    z[6,7,1]  R2424     -1.2512235343456268e-01
    z[6,7,1]  R2425     -2.2064872086048126e-01
    z[6,7,1]  R2426     -0.262986958026886
    z[6,7,1]  R2427     -2.0322947204113007e-01
    z[6,7,1]  R2428     1.2710350751876831e-01
    z[6,7,1]  R2429     -6.1658447980880737e-01
    z[6,7,1]  R2430     -5.7900321483612061e-01
    z[6,7,1]  R2431     -6.4628767967224121e-01
    z[6,7,1]  R2432     1.9738541543483734e-01
    z[6,7,1]  R2433     6.6613882780075073e-01
    z[6,7,1]  R2434     7.3474103212356567e-01
    z[6,7,1]  R2435     7.4525296688079834e-02
    z[6,7,1]  R2436     -2.2945592645555735e-03
    z[6,7,1]  R2437     4.4102672487497330e-02
    z[6,7,1]  R2438     5.7743549346923828e-01
    z[6,7,1]  R2439     5.3636454045772552e-02
    z[6,7,1]  R2440     4.0496596693992615e-01
    z[6,7,1]  R2441     6.5669816732406616e-01
    z[6,7,1]  R2442     -6.7782026529312134e-01
    z[6,7,1]  R2443     -8.0523324012756348e-01
    z[6,7,1]  R2444     -5.9223777055740356e-01
    z[6,7,1]  R2445     -7.8164649009704590e-01
    z[6,7,1]  R2446     -7.4711662530899048e-01
    z[6,7,1]  R2447     -6.4996057748794556e-01
    z[6,7,1]  R2448     -0.512759268283844
    z[6,7,1]  R2449     -5.2422821521759033e-01
    z[6,7,1]  R2450     -4.5910209417343140e-01
    z[6,7,1]  R2451     1.1272864043712616e-01
    z[6,7,1]  R2452     -3.4529095888137817e-01
    z[6,7,1]  R2453     7.0104561746120453e-03
    z[6,7,1]  R2454     4.6046581119298935e-03
    z[6,7,1]  R2455     -5.4499473422765732e-02
    z[6,7,1]  R2456     1.7552489042282104e-01
    z[6,7,1]  R2457     -9.6060343086719513e-02
    z[6,7,1]  R2458     7.1108184754848480e-02
    z[6,7,1]  R2459     -4.3063253164291382e-01
    z[6,7,1]  R2460     2.3395034670829773e-01
    z[6,7,1]  R2461     1.2475195527076721e-01
    z[6,7,1]  R2462     -6.4332002401351929e-01
    z[6,7,1]  R2463     8.6006671190261841e-02
    z[6,7,1]  R2464     5.9089845418930054e-01
    z[6,7,1]  R2465     6.4706325531005859e-01
    z[6,7,1]  R2466     0.686769425868988
    z[6,7,1]  R2467     2.7850097417831421e-01
    z[6,7,1]  R2468     9.1011798381805420e-01
    z[6,7,1]  R2469     8.5468226671218872e-01
    z[6,7,1]  R2470     9.0942496061325073e-01
    z[6,7,1]  R2471     7.3431169986724854e-01
    z[6,7,1]  R2472     -7.3055410385131836e-01
    z[6,7,1]  R2473     -6.7307293415069580e-01
    z[6,7,1]  R2474     -7.0669221878051758e-01
    z[6,7,1]  R2475     -6.1387270689010620e-01
    z[6,7,1]  R2476     9.0618662536144257e-02
    z[6,7,1]  R2477     5.9256780147552490e-01
    z[6,7,1]  R2478     6.7437773942947388e-01
    z[6,7,1]  R2479     7.3519986867904663e-01
    z[6,7,1]  R2480     5.2971726655960083e-01
    z[6,7,1]  R2481     4.3057283759117126e-01
    z[6,7,2]  R58       -1
    z[6,7,2]  R67       1
    z[6,7,2]  R2372     -1
    z[6,7,2]  R2373     1
    z[6,7,2]  R2382     -1.1657848954200745e-01
    z[6,7,2]  R2383     -0.27797931432724
    z[6,7,2]  R2384     -2.8962761163711548e-01
    z[6,7,2]  R2385     9.1380268335342407e-02
    z[6,7,2]  R2386     1.9642254710197449e-01
    z[6,7,2]  R2387     -3.4210613369941711e-01
    z[6,7,2]  R2388     1.8819691240787506e-01
    z[6,7,2]  R2389     -3.0000713467597961e-01
    z[6,7,2]  R2390     -9.1953672468662262e-02
    z[6,7,2]  R2391     -1.1292373389005661e-01
    z[6,7,2]  R2392     -1.0943014174699783e-01
    z[6,7,2]  R2393     -0.0857386440038681
    z[6,7,2]  R2394     -3.6604857444763184e-01
    z[6,7,2]  R2395     -2.0322367548942566e-01
    z[6,7,2]  R2396     2.7266851067543030e-01
    z[6,7,2]  R2397     1.0813126713037491e-01
    z[6,7,2]  R2398     1.0796468704938889e-01
    z[6,7,2]  R2399     7.8948169946670532e-01
    z[6,7,2]  R2400     2.6973477005958557e-01
    z[6,7,2]  R2401     4.8148965835571289e-01
    z[6,7,2]  R2402     0.413653701543808
    z[6,7,2]  R2403     0.342832088470459
    z[6,7,2]  R2404     -2.6855310425162315e-02
    z[6,7,2]  R2405     -0.0953153595328331
    z[6,7,2]  R2406     4.4445610046386719e-01
    z[6,7,2]  R2407     3.8897311687469482e-01
    z[6,7,2]  R2408     -1.4220274984836578e-01
    z[6,7,2]  R2409     0.567274808883667
    z[6,7,2]  R2410     6.6093361377716064e-01
    z[6,7,2]  R2411     4.6385416388511658e-01
    z[6,7,2]  R2412     4.8049096018075943e-02
    z[6,7,2]  R2413     1.9378603994846344e-01
    z[6,7,2]  R2414     7.5120642781257629e-02
    z[6,7,2]  R2415     -2.4247172474861145e-01
    z[6,7,2]  R2416     -4.8259615898132324e-01
    z[6,7,2]  R2417     3.5424941778182983e-01
    z[6,7,2]  R2418     -1.0859417915344238e-01
    z[6,7,2]  R2419     9.9274478852748871e-02
    z[6,7,2]  R2420     5.9204649925231934e-01
    z[6,7,2]  R2421     -5.3504716604948044e-02
    z[6,7,2]  R2422     1.5736088156700134e-01
    z[6,7,2]  R2423     3.1619224697351456e-02
    z[6,7,2]  R2424     -2.8328439593315125e-01
    z[6,7,2]  R2425     1.6663897037506104e-01
    z[6,7,2]  R2426     4.3664994835853577e-01
    z[6,7,2]  R2427     3.6473900079727173e-01
    z[6,7,2]  R2428     9.3046009540557861e-02
    z[6,7,2]  R2429     2.6254189014434814e-01
    z[6,7,2]  R2430     0.255932092666626
    z[6,7,2]  R2431     3.0451336503028870e-01
    z[6,7,2]  R2432     -7.3511481285095215e-01
    z[6,7,2]  R2433     -3.7339490652084351e-01
    z[6,7,2]  R2434     -2.5605386495590210e-01
    z[6,7,2]  R2435     -3.1785136461257935e-01
    z[6,7,2]  R2436     -8.7365549802780151e-01
    z[6,7,2]  R2437     -6.0707551240921021e-01
    z[6,7,2]  R2438     -3.5549452900886536e-01
    z[6,7,2]  R2439     -0.730562686920166
    z[6,7,2]  R2440     -7.2983330488204956e-01
    z[6,7,2]  R2441     -5.8316880464553833e-01
    z[6,7,2]  R2442     -5.9866684675216675e-01
    z[6,7,2]  R2443     -3.0322751402854919e-01
    z[6,7,2]  R2444     -2.2276845574378967e-01
    z[6,7,2]  R2445     -8.7085880339145660e-02
    z[6,7,2]  R2446     -1.8152470886707306e-01
    z[6,7,2]  R2447     -2.1618537604808807e-01
    z[6,7,2]  R2448     -4.0154952555894852e-02
    z[6,7,2]  R2449     1.2722371518611908e-01
    z[6,7,2]  R2450     7.7772176265716553e-01
    z[6,7,2]  R2451     -2.9540473222732544e-01
    z[6,7,2]  R2452     3.6096596717834473e-01
    z[6,7,2]  R2453     -3.6073359847068787e-01
    z[6,7,2]  R2454     -0.50264972448349
    z[6,7,2]  R2455     -1.4566515386104584e-01
    z[6,7,2]  R2456     -5.9669876098632812e-01
    z[6,7,2]  R2457     -4.2036834359169006e-01
    z[6,7,2]  R2458     -0.81169593334198
    z[6,7,2]  R2459     -8.8499732315540314e-02
    z[6,7,2]  R2460     5.6356781721115112e-01
    z[6,7,2]  R2461     6.6970270872116089e-01
    z[6,7,2]  R2462     2.8186139464378357e-01
    z[6,7,2]  R2463     -0.647044837474823
    z[6,7,2]  R2464     -7.7119171619415283e-02
    z[6,7,2]  R2465     -5.6557118892669678e-01
    z[6,7,2]  R2466     -4.3069493770599365e-01
    z[6,7,2]  R2467     4.9036827683448792e-01
    z[6,7,2]  R2468     6.6082730889320374e-02
    z[6,7,2]  R2469     1.8462300300598145e-01
    z[6,7,2]  R2470     -1.1157387867569923e-02
    z[6,7,2]  R2471     -5.1228034496307373e-01
    z[6,7,2]  R2472     2.6303809881210327e-01
    z[6,7,2]  R2473     5.2225303649902344e-01
    z[6,7,2]  R2474     1.6468265652656555e-01
    z[6,7,2]  R2475     -3.2448098063468933e-01
    z[6,7,2]  R2476     -0.89305579662323
    z[6,7,2]  R2477     -5.2912008017301559e-02
    z[6,7,2]  R2478     -6.0445809364318848e-01
    z[6,7,2]  R2479     -3.9572045207023621e-01
    z[6,7,2]  R2480     5.8833497762680054e-01
    z[6,7,2]  R2481     6.8056142330169678e-01
    z[6,7,3]  R59       -1
    z[6,7,3]  R68       1
    z[6,7,3]  R2374     -1
    z[6,7,3]  R2375     1
    z[6,7,3]  R2382     -0.85221928358078
    z[6,7,3]  R2383     -8.1240195035934448e-01
    z[6,7,3]  R2384     -5.2628499269485474e-01
    z[6,7,3]  R2385     -7.5213503837585449e-01
    z[6,7,3]  R2386     -4.3814745545387268e-01
    z[6,7,3]  R2387     1.2706759572029114e-01
    z[6,7,3]  R2388     3.4517151117324829e-01
    z[6,7,3]  R2389     -1.5411342494189739e-02
    z[6,7,3]  R2390     2.3107966780662537e-01
    z[6,7,3]  R2391     -5.8358427137136459e-02
    z[6,7,3]  R2392     4.1151252388954163e-01
    z[6,7,3]  R2393     5.9133970737457275e-01
    z[6,7,3]  R2394     5.1580494642257690e-01
    z[6,7,3]  R2395     7.1391516923904419e-01
    z[6,7,3]  R2396     3.2900074124336243e-01
    z[6,7,3]  R2397     6.9959261454641819e-03
    z[6,7,3]  R2398     3.8137266039848328e-01
    z[6,7,3]  R2399     0.338481068611145
    z[6,7,3]  R2400     2.3638258874416351e-01
    z[6,7,3]  R2401     -0.462100625038147
    z[6,7,3]  R2402     4.8471182584762573e-01
    z[6,7,3]  R2403     4.3285819888114929e-01
    z[6,7,3]  R2404     4.2439797520637512e-01
    z[6,7,3]  R2405     4.8455065488815308e-01
    z[6,7,3]  R2406     4.9847099184989929e-01
    z[6,7,3]  R2407     3.9329320192337036e-01
    z[6,7,3]  R2408     4.8132848739624023e-01
    z[6,7,3]  R2409     5.7116001844406128e-01
    z[6,7,3]  R2410     8.5973121225833893e-02
    z[6,7,3]  R2411     0.566581130027771
    z[6,7,3]  R2412     0.543865442276001
    z[6,7,3]  R2413     4.8258337378501892e-01
    z[6,7,3]  R2414     4.3860536813735962e-01
    z[6,7,3]  R2415     7.4338442087173462e-01
    z[6,7,3]  R2416     7.0555222034454346e-01
    z[6,7,3]  R2417     1.0699941217899323e-01
    z[6,7,3]  R2418     4.6006390452384949e-01
    z[6,7,3]  R2419     2.5437566637992859e-01
    z[6,7,3]  R2420     3.3498144149780273e-01
    z[6,7,3]  R2421     1.4639307558536530e-01
    z[6,7,3]  R2422     -0.504252552986145
    z[6,7,3]  R2423     -2.4172352254390717e-01
    z[6,7,3]  R2424     -3.7082454562187195e-01
    z[6,7,3]  R2425     -4.2431572079658508e-01
    z[6,7,3]  R2426     -1.4273391105234623e-02
    z[6,7,3]  R2427     -4.8467060923576355e-01
    z[6,7,3]  R2428     -2.1092857420444489e-01
    z[6,7,3]  R2429     -1.8700738251209259e-01
    z[6,7,3]  R2430     5.6740206480026245e-01
    z[6,7,3]  R2431     -1.0911568999290466e-01
    z[6,7,3]  R2432     -4.2100772261619568e-02
    z[6,7,3]  R2433     -2.1732452511787415e-01
    z[6,7,3]  R2434     -0.109881691634655
    z[6,7,3]  R2435     -1.2937353551387787e-01
    z[6,7,3]  R2436     -1.6076089814305305e-02
    z[6,7,3]  R2437     5.3015798330307007e-02
    z[6,7,3]  R2438     -4.6307405829429626e-01
    z[6,7,3]  R2439     -1.3483323156833649e-02
    z[6,7,3]  R2440     1.8107822537422180e-01
    z[6,7,3]  R2441     -1.2303494662046432e-01
    z[6,7,3]  R2442     1.1183109134435654e-01
    z[6,7,3]  R2443     4.8025703430175781e-01
    z[6,7,3]  R2444     -4.1683989763259888e-01
    z[6,7,3]  R2445     2.5238654017448425e-01
    z[6,7,3]  R2446     1.8978676199913025e-01
    z[6,7,3]  R2447     -3.0419981479644775e-01
    z[6,7,3]  R2448     5.2527725696563721e-01
    z[6,7,3]  R2449     2.6501783728599548e-01
    z[6,7,3]  R2450     2.3504644632339478e-01
    z[6,7,3]  R2451     -3.0951502267271280e-03
    z[6,7,3]  R2452     -1.0267569869756699e-01
    z[6,7,3]  R2453     -9.5114611089229584e-02
    z[6,7,3]  R2454     -3.6320930719375610e-01
    z[6,7,3]  R2455     -3.2691818475723267e-01
    z[6,7,3]  R2456     1.5387211740016937e-01
    z[6,7,3]  R2457     1.2792519293725491e-02
    z[6,7,3]  R2458     9.7040623426437378e-02
    z[6,7,3]  R2459     -4.2647728323936462e-01
    z[6,7,3]  R2460     9.0673323720693588e-03
    z[6,7,3]  R2461     -3.9340332150459290e-01
    z[6,7,3]  R2462     3.7332630157470703e-01
    z[6,7,3]  R2463     -4.8981118947267532e-02
    z[6,7,3]  R2464     4.3991249054670334e-02
    z[6,7,3]  R2465     -1.4338363707065582e-01
    z[6,7,3]  R2466     -1.6163422167301178e-01
    z[6,7,3]  R2467     -2.2544270753860474e-01
    z[6,7,3]  R2468     -3.7036520242691040e-01
    z[6,7,3]  R2469     -3.8125243782997131e-01
    z[6,7,3]  R2470     -3.3912095427513123e-01
    z[6,7,3]  R2471     1.9066568464040756e-02
    z[6,7,3]  R2472     3.4886658191680908e-01
    z[6,7,3]  R2473     9.6905358135700226e-02
    z[6,7,3]  R2474     4.7653075307607651e-02
    z[6,7,3]  R2475     1.5867911279201508e-01
    z[6,7,3]  R2476     -4.2687293142080307e-02
    z[6,7,3]  R2477     -9.7977332770824432e-03
    z[6,7,3]  R2478     -6.8670073524117470e-03
    z[6,7,3]  R2479     -2.0256450772285461e-01
    z[6,7,3]  R2480     -5.2521169185638428e-01
    z[6,7,3]  R2481     -3.5196962952613831e-01
    z[6,7,4]  R60       -1
    z[6,7,4]  R69       1
    z[6,7,4]  R2376     -1
    z[6,7,4]  R2377     1
    z[6,7,4]  R2382     2.0948500931262970e-01
    z[6,7,4]  R2383     -3.1193265318870544e-01
    z[6,7,4]  R2384     -1.3032099604606628e-01
    z[6,7,4]  R2385     -4.3716788291931152e-02
    z[6,7,4]  R2386     -2.6139837503433228e-01
    z[6,7,4]  R2387     -1.1416272819042206e-01
    z[6,7,4]  R2388     4.3638557195663452e-01
    z[6,7,4]  R2389     -2.4576272070407867e-01
    z[6,7,4]  R2390     -5.5505480617284775e-02
    z[6,7,4]  R2391     2.8016555309295654e-01
    z[6,7,4]  R2392     5.6557816267013550e-01
    z[6,7,4]  R2393     -3.4651103615760803e-01
    z[6,7,4]  R2394     -3.6873687058687210e-02
    z[6,7,4]  R2395     -1.4194028079509735e-01
    z[6,7,4]  R2396     -2.9900604486465454e-01
    z[6,7,4]  R2397     0.667676568031311
    z[6,7,4]  R2398     1.8114092946052551e-01
    z[6,7,4]  R2399     -4.0168181061744690e-02
    z[6,7,4]  R2400     2.1784137934446335e-02
    z[6,7,4]  R2401     -4.7689802944660187e-02
    z[6,7,4]  R2402     1.3894718885421753e-01
    z[6,7,4]  R2403     2.0598727464675903e-01
    z[6,7,4]  R2404     3.7436592578887939e-01
    z[6,7,4]  R2405     -1.3234195113182068e-01
    z[6,7,4]  R2406     -1.9997909665107727e-01
    z[6,7,4]  R2407     2.9672408103942871e-01
    z[6,7,4]  R2408     -3.4363400936126709e-01
    z[6,7,4]  R2409     -1.0641941428184509e-01
    z[6,7,4]  R2410     -0.382472962141037
    z[6,7,4]  R2411     -4.4036373496055603e-01
    z[6,7,4]  R2412     1.1417217552661896e-01
    z[6,7,4]  R2413     1.5343791246414185e-01
    z[6,7,4]  R2414     3.6165687441825867e-01
    z[6,7,4]  R2415     -4.7659203410148621e-01
    z[6,7,4]  R2416     -0.0654422715306282
    z[6,7,4]  R2417     4.0773589164018631e-02
    z[6,7,4]  R2418     3.0711600184440613e-01
    z[6,7,4]  R2419     9.1799207031726837e-02
    z[6,7,4]  R2420     9.9960751831531525e-02
    z[6,7,4]  R2421     3.4307071566581726e-01
    z[6,7,4]  R2422     -9.3567736446857452e-02
    z[6,7,4]  R2423     -4.1627362370491028e-03
    z[6,7,4]  R2424     -1.7485836520791054e-02
    z[6,7,4]  R2425     -3.9552173018455505e-01
    z[6,7,4]  R2426     -5.4580219089984894e-02
    z[6,7,4]  R2427     4.1839987039566040e-01
    z[6,7,4]  R2428     5.4671669006347656e-01
    z[6,7,4]  R2429     -4.9099615216255188e-01
    z[6,7,4]  R2430     1.4081904292106628e-01
    z[6,7,4]  R2431     1.8393313884735107e-01
    z[6,7,4]  R2432     -1.8558960407972336e-02
    z[6,7,4]  R2433     2.4832665920257568e-01
    z[6,7,4]  R2434     -2.2210772335529327e-01
    z[6,7,4]  R2435     6.6949248313903809e-01
    z[6,7,4]  R2436     3.9261576533317566e-01
    z[6,7,4]  R2437     6.2186169624328613e-01
    z[6,7,4]  R2438     1.2779118493199348e-02
    z[6,7,4]  R2439     -1.0554113984107971e-01
    z[6,7,4]  R2440     -3.8992649316787720e-01
    z[6,7,4]  R2441     -1.0634469240903854e-01
    z[6,7,4]  R2442     3.4463945031166077e-01
    z[6,7,4]  R2443     3.5495623946189880e-02
    z[6,7,4]  R2444     4.9213263392448425e-01
    z[6,7,4]  R2445     3.8332742452621460e-01
    z[6,7,4]  R2446     2.8598508238792419e-01
    z[6,7,4]  R2447     -1.3394100964069366e-01
    z[6,7,4]  R2448     -4.4146808981895447e-01
    z[6,7,4]  R2449     -2.3624691367149353e-01
    z[6,7,4]  R2450     -2.4334377050399780e-01
    z[6,7,4]  R2451     -4.7691500186920166e-01
    z[6,7,4]  R2452     2.7066943049430847e-01
    z[6,7,4]  R2453     5.8024022728204727e-02
    z[6,7,4]  R2454     -0.0924634113907814
    z[6,7,4]  R2455     1.2324440479278564e-01
    z[6,7,4]  R2456     1.5061776340007782e-01
    z[6,7,4]  R2457     -9.0359859168529510e-03
    z[6,7,4]  R2458     2.4451713263988495e-01
    z[6,7,4]  R2459     4.0662929415702820e-01
    z[6,7,4]  R2460     4.1545665264129639e-01
    z[6,7,4]  R2461     2.5468489527702332e-01
    z[6,7,4]  R2462     -4.1382867097854614e-01
    z[6,7,4]  R2463     -5.0561362504959106e-01
    z[6,7,4]  R2464     -3.6079576238989830e-03
    z[6,7,4]  R2465     -2.3232956230640411e-01
    z[6,7,4]  R2466     -2.8039303421974182e-01
    z[6,7,4]  R2467     -1.9280940294265747e-02
    z[6,7,4]  R2468     6.0891743749380112e-02
    z[6,7,4]  R2469     -3.9529930800199509e-02
    z[6,7,4]  R2470     -1.9411031901836395e-01
    z[6,7,4]  R2471     -4.1277384757995605e-01
    z[6,7,4]  R2472     -0.163431316614151
    z[6,7,4]  R2473     -1.5994679182767868e-02
    z[6,7,4]  R2474     -3.1727802753448486e-01
    z[6,7,4]  R2475     -1.9960127770900726e-01
    z[6,7,4]  R2476     -1.3360002636909485e-01
    z[6,7,4]  R2477     -5.7889252901077271e-02
    z[6,7,4]  R2478     -2.9758140444755554e-01
    z[6,7,4]  R2479     -1.0412189364433289e-01
    z[6,7,4]  R2480     2.4219968914985657e-01
    z[6,7,4]  R2481     2.4200481176376343e-01
    z[6,7,5]  R61       -1
    z[6,7,5]  R70       1
    z[6,7,5]  R2378     -1
    z[6,7,5]  R2379     1
    z[6,7,5]  R2382     -4.1011118888854980e-01
    z[6,7,5]  R2383     -3.5467270016670227e-01
    z[6,7,5]  R2384     -6.7898106575012207e-01
    z[6,7,5]  R2385     -3.8434910774230957e-01
    z[6,7,5]  R2386     -6.0099124908447266e-01
    z[6,7,5]  R2387     8.2026623189449310e-02
    z[6,7,5]  R2388     -2.9660975933074951e-01
    z[6,7,5]  R2389     4.6530964970588684e-01
    z[6,7,5]  R2390     5.5250751972198486e-01
    z[6,7,5]  R2391     4.3743756413459778e-01
    z[6,7,5]  R2392     -3.0136564373970032e-01
    z[6,7,5]  R2393     3.5118868947029114e-01
    z[6,7,5]  R2394     7.3869693279266357e-01
    z[6,7,5]  R2395     -2.6882886886596680e-01
    z[6,7,5]  R2396     -4.3684488534927368e-01
    z[6,7,5]  R2397     3.1190750002861023e-01
    z[6,7,5]  R2398     5.0793045759201050e-01
    z[6,7,5]  R2399     4.7194175422191620e-02
    z[6,7,5]  R2400     8.8561016321182251e-01
    z[6,7,5]  R2401     7.0759785175323486e-01
    z[6,7,5]  R2402     7.4784934520721436e-01
    z[6,7,5]  R2403     7.0382225513458252e-01
    z[6,7,5]  R2404     7.0949828624725342e-01
    z[6,7,5]  R2405     7.6195400953292847e-01
    z[6,7,5]  R2406     5.8875405788421631e-01
    z[6,7,5]  R2407     6.5910464525222778e-01
    z[6,7,5]  R2408     7.7146822214126587e-01
    z[6,7,5]  R2409     2.8881141543388367e-01
    z[6,7,5]  R2410     -3.2654516398906708e-02
    z[6,7,5]  R2411     4.1194760799407959e-01
    z[6,7,5]  R2412     7.1507257223129272e-01
    z[6,7,5]  R2413     8.2039844989776611e-01
    z[6,7,5]  R2414     6.3013392686843872e-01
    z[6,7,5]  R2415     1.5305669605731964e-01
    z[6,7,5]  R2416     3.7789145112037659e-01
    z[6,7,5]  R2417     -4.2847845703363419e-02
    z[6,7,5]  R2418     4.6800276637077332e-01
    z[6,7,5]  R2419     3.1855154037475586e-01
    z[6,7,5]  R2420     1.1651323735713959e-01
    z[6,7,5]  R2421     3.0713552236557007e-01
    z[6,7,5]  R2422     4.2699400335550308e-02
    z[6,7,5]  R2423     -1.3356618583202362e-01
    z[6,7,5]  R2424     -3.2809235155582428e-02
    z[6,7,5]  R2425     5.3201489150524139e-02
    z[6,7,5]  R2426     -1.0581449419260025e-01
    z[6,7,5]  R2427     0.0456363819539547
    z[6,7,5]  R2428     -1.0163668543100357e-01
    z[6,7,5]  R2429     -3.2858392596244812e-01
    z[6,7,5]  R2430     2.8948080539703369e-01
    z[6,7,5]  R2431     2.4532085657119751e-01
    z[6,7,5]  R2432     -5.8020043373107910e-01
    z[6,7,5]  R2433     5.5503454059362411e-02
    z[6,7,5]  R2434     1.2265937775373459e-01
    z[6,7,5]  R2435     -2.0580182969570160e-01
    z[6,7,5]  R2436     -0.162678524851799
    z[6,7,5]  R2437     1.8457837402820587e-02
    z[6,7,5]  R2438     -1.9807896018028259e-01
    z[6,7,5]  R2439     -8.4291743114590645e-03
    z[6,7,5]  R2440     2.5627663731575012e-01
    z[6,7,5]  R2441     3.3952635526657104e-01
    z[6,7,5]  R2442     3.5490646958351135e-02
    z[6,7,5]  R2443     -9.9709741771221161e-02
    z[6,7,5]  R2444     -1.2336204200983047e-01
    z[6,7,5]  R2445     -0.200625479221344
    z[6,7,5]  R2446     -5.1801913976669312e-01
    z[6,7,5]  R2447     5.2026188373565674e-01
    z[6,7,5]  R2448     -3.2877799123525620e-02
    z[6,7,5]  R2449     -1.8231348693370819e-01
    z[6,7,5]  R2450     1.1712416261434555e-01
    z[6,7,5]  R2451     -1.7633208632469177e-01
    z[6,7,5]  R2452     1.3752581179141998e-01
    z[6,7,5]  R2453     -5.5856925249099731e-01
    z[6,7,5]  R2454     -2.0876045525074005e-01
    z[6,7,5]  R2455     -0.320121705532074
    z[6,7,5]  R2456     -2.7869519591331482e-01
    z[6,7,5]  R2457     1.1142909526824951e-02
    z[6,7,5]  R2458     -6.2896623276174068e-03
    z[6,7,5]  R2459     -2.5724676251411438e-01
    z[6,7,5]  R2460     5.0354021787643433e-01
    z[6,7,5]  R2461     -3.6257150769233704e-01
    z[6,7,5]  R2462     3.9444151520729065e-01
    z[6,7,5]  R2463     -5.5814504623413086e-01
    z[6,7,5]  R2464     5.5932231247425079e-02
    z[6,7,5]  R2465     -1.4626109972596169e-02
    z[6,7,5]  R2466     3.1677356362342834e-01
    z[6,7,5]  R2467     1.9272281229496002e-01
    z[6,7,5]  R2468     2.3736661300063133e-02
    z[6,7,5]  R2469     -1.2253225594758987e-01
    z[6,7,5]  R2470     5.9116680175065994e-02
    z[6,7,5]  R2471     -3.1366065144538879e-02
    z[6,7,5]  R2472     4.3536716699600220e-01
    z[6,7,5]  R2473     -3.9726775884628296e-01
    z[6,7,5]  R2474     2.3148950934410095e-01
    z[6,7,5]  R2475     -3.2445770502090454e-01
    z[6,7,5]  R2476     -2.2903005778789520e-01
    z[6,7,5]  R2477     3.3493004739284515e-02
    z[6,7,5]  R2478     -1.6680642962455750e-01
    z[6,7,5]  R2479     3.0079308152198792e-01
    z[6,7,5]  R2480     -5.6932557374238968e-02
    z[6,7,5]  R2481     1.9158987700939178e-01
    z[6,7,6]  R62       -1
    z[6,7,6]  R71       1
    z[6,7,6]  R2380     -1
    z[6,7,6]  R2381     1
    z[6,7,6]  R2382     1.4036749303340912e-01
    z[6,7,6]  R2383     -3.1022084876894951e-02
    z[6,7,6]  R2384     -3.5945597290992737e-01
    z[6,7,6]  R2385     -3.4882813692092896e-01
    z[6,7,6]  R2386     0.0961492657661438
    z[6,7,6]  R2387     5.1711469888687134e-01
    z[6,7,6]  R2388     -6.0955983400344849e-01
    z[6,7,6]  R2389     -4.3923977762460709e-02
    z[6,7,6]  R2390     4.0581443905830383e-01
    z[6,7,6]  R2391     -5.3546506166458130e-01
    z[6,7,6]  R2392     1.2044569849967957e-01
    z[6,7,6]  R2393     -1.3086408376693726e-01
    z[6,7,6]  R2394     -2.1284069120883942e-01
    z[6,7,6]  R2395     -2.0879344642162323e-01
    z[6,7,6]  R2396     0.389967143535614
    z[6,7,6]  R2397     -2.4880394339561462e-01
    z[6,7,6]  R2398     1.0923012346029282e-01
    z[6,7,6]  R2399     2.9357701539993286e-01
    z[6,7,6]  R2400     -1.3189360499382019e-01
    z[6,7,6]  R2401     -4.1599976248107851e-04
    z[6,7,6]  R2402     9.6221163868904114e-02
    z[6,7,6]  R2403     -1.5994152426719666e-01
    z[6,7,6]  R2404     -6.3475859351456165e-03
    z[6,7,6]  R2405     -3.4419447183609009e-01
    z[6,7,6]  R2406     2.2703444585204124e-02
    z[6,7,6]  R2407     1.1628524214029312e-01
    z[6,7,6]  R2408     9.9947135895490646e-03
    z[6,7,6]  R2409     2.9199233651161194e-01
    z[6,7,6]  R2410     2.8093319386243820e-02
    z[6,7,6]  R2411     1.5568609535694122e-01
    z[6,7,6]  R2412     -1.7072907090187073e-01
    z[6,7,6]  R2413     1.7637057602405548e-01
    z[6,7,6]  R2414     3.7995925545692444e-01
    z[6,7,6]  R2415     -2.4157127737998962e-01
    z[6,7,6]  R2416     -2.4933594465255737e-01
    z[6,7,6]  R2417     1.1855491995811462e-01
    z[6,7,6]  R2418     5.7565051317214966e-01
    z[6,7,6]  R2419     -8.5030794143676758e-02
    z[6,7,6]  R2420     -1.3771559298038483e-01
    z[6,7,6]  R2421     -8.6030957754701376e-04
    z[6,7,6]  R2422     -6.8305768072605133e-02
    z[6,7,6]  R2423     -2.6315292716026306e-01
    z[6,7,6]  R2424     1.8965634703636169e-01
    z[6,7,6]  R2425     2.7610439062118530e-01
    z[6,7,6]  R2426     1.0315315425395966e-01
    z[6,7,6]  R2427     1.1893185228109360e-01
    z[6,7,6]  R2428     3.6621958017349243e-01
    z[6,7,6]  R2429     -3.7528967857360840e-01
    z[6,7,6]  R2430     3.8977968692779541e-01
    z[6,7,6]  R2431     -5.9992820024490356e-01
    z[6,7,6]  R2432     2.0464979112148285e-01
    z[6,7,6]  R2433     1.0193166881799698e-01
    z[6,7,6]  R2434     -2.1577247977256775e-01
    z[6,7,6]  R2435     2.7214100956916809e-01
    z[6,7,6]  R2436     -1.5039950609207153e-01
    z[6,7,6]  R2437     1.4134421944618225e-01
    z[6,7,6]  R2438     -2.4560080468654633e-01
    z[6,7,6]  R2439     -3.2802972197532654e-01
    z[6,7,6]  R2440     -8.7344385683536530e-02
    z[6,7,6]  R2441     -2.9046475887298584e-01
    z[6,7,6]  R2442     -3.3763226121664047e-02
    z[6,7,6]  R2443     8.7758764624595642e-02
    z[6,7,6]  R2444     1.3043515384197235e-01
    z[6,7,6]  R2445     -7.4390277266502380e-02
    z[6,7,6]  R2446     1.1244340986013412e-01
    z[6,7,6]  R2447     2.1105460822582245e-01
    z[6,7,6]  R2448     5.9766110032796860e-02
    z[6,7,6]  R2449     -1.1898516118526459e-01
    z[6,7,6]  R2450     2.3701743781566620e-01
    z[6,7,6]  R2451     1.8284708261489868e-01
    z[6,7,6]  R2452     7.6919443905353546e-02
    z[6,7,6]  R2453     3.5817271471023560e-01
    z[6,7,6]  R2454     -3.7950697541236877e-01
    z[6,7,6]  R2455     3.3026900142431259e-02
    z[6,7,6]  R2456     4.6391418576240540e-01
    z[6,7,6]  R2457     5.1949676126241684e-02
    z[6,7,6]  R2458     3.6134470254182816e-02
    z[6,7,6]  R2459     -4.2000627517700195e-01
    z[6,7,6]  R2460     4.0516536682844162e-02
    z[6,7,6]  R2461     8.3466731011867523e-02
    z[6,7,6]  R2462     -1.5520407259464264e-01
    z[6,7,6]  R2463     -0.0628967210650444
    z[6,7,6]  R2464     -5.4903768002986908e-02
    z[6,7,6]  R2465     -4.0593791007995605e-01
    z[6,7,6]  R2466     -1.8895855545997620e-01
    z[6,7,6]  R2467     -2.7942699193954468e-01
    z[6,7,6]  R2468     8.4527529776096344e-02
    z[6,7,6]  R2469     1.3570147752761841e-01
    z[6,7,6]  R2470     -1.3549934141337872e-02
    z[6,7,6]  R2471     1.6059705615043640e-01
    z[6,7,6]  R2472     -2.1056039631366730e-01
    z[6,7,6]  R2473     1.3259758055210114e-01
    z[6,7,6]  R2474     -4.8863810300827026e-01
    z[6,7,6]  R2475     -5.8619666099548340e-01
    z[6,7,6]  R2476     -2.1355259418487549e-01
    z[6,7,6]  R2477     -5.2427347749471664e-02
    z[6,7,6]  R2478     2.1352234482765198e-01
    z[6,7,6]  R2479     -1.0542669147253036e-01
    z[6,7,6]  R2480     -1.6958503052592278e-02
    z[6,7,6]  R2481     -4.8897020518779755e-02
    z[7,6,0]  R56       1
    z[7,6,0]  R65       -1
    z[7,6,0]  R2482     -1
    z[7,6,0]  R2483     1
    z[7,6,0]  R2496     0.831761360168457
    z[7,6,0]  R2497     9.2205941677093506e-01
    z[7,6,0]  R2498     8.5395079851150513e-01
    z[7,6,0]  R2499     7.1274155378341675e-01
    z[7,6,0]  R2500     8.4566819667816162e-01
    z[7,6,0]  R2501     6.3203769922256470e-01
    z[7,6,0]  R2502     6.9810485839843750e-01
    z[7,6,0]  R2503     -1.6135847568511963e-01
    z[7,6,0]  R2504     -1.4748410880565643e-01
    z[7,6,0]  R2505     1.5411005914211273e-01
    z[7,6,0]  R2506     -2.0003539323806763e-01
    z[7,6,0]  R2507     -5.4264968633651733e-01
    z[7,6,0]  R2508     -5.2113640308380127e-01
    z[7,6,0]  R2509     -5.5860871076583862e-01
    z[7,6,0]  R2510     -1.8229384720325470e-01
    z[7,6,0]  R2511     -4.6869260072708130e-01
    z[7,6,0]  R2512     -4.7543257474899292e-01
    z[7,6,0]  R2513     -5.8686113357543945e-01
    z[7,6,0]  R2514     -2.1261937916278839e-01
    z[7,6,0]  R2515     -5.0665266811847687e-02
    z[7,6,0]  R2516     -2.2017173469066620e-01
    z[7,6,0]  R2517     -1.0050955414772034e-01
    z[7,6,0]  R2518     -3.8916191458702087e-01
    z[7,6,0]  R2519     3.5358372330665588e-01
    z[7,6,0]  R2520     1.0035784542560577e-01
    z[7,6,0]  R2521     -3.2422360777854919e-01
    z[7,6,0]  R2522     5.0990432500839233e-01
    z[7,6,0]  R2523     7.3181706666946411e-01
    z[7,6,0]  R2524     3.9688837714493275e-03
    z[7,6,0]  R2525     -7.7977222204208374e-01
    z[7,6,0]  R2526     -0.8011514544487
    z[7,6,0]  R2527     -6.4584916830062866e-01
    z[7,6,0]  R2528     -6.4749133586883545e-01
    z[7,6,0]  R2529     -0.866128146648407
    z[7,6,0]  R2530     -5.2334684133529663e-01
    z[7,6,0]  R2531     -9.0055245161056519e-01
    z[7,6,0]  R2532     -5.1530826091766357e-01
    z[7,6,0]  R2533     -4.6573814749717712e-01
    z[7,6,0]  R2534     4.4696500897407532e-01
    z[7,6,0]  R2535     0.421758234500885
    z[7,6,0]  R2536     -0.128040611743927
    z[7,6,0]  R2537     -2.0239213481545448e-02
    z[7,6,0]  R2538     -7.9799783229827881e-01
    z[7,6,0]  R2539     -1.4799687266349792e-01
    z[7,6,0]  R2540     -3.1945714354515076e-01
    z[7,6,0]  R2541     0.718023955821991
    z[7,6,0]  R2542     1.3686415553092957e-01
    z[7,6,0]  R2543     2.3470732569694519e-01
    z[7,6,0]  R2544     1.2830194830894470e-01
    z[7,6,0]  R2545     -2.8881579637527466e-02
    z[7,6,0]  R2546     -1.2167088687419891e-01
    z[7,6,0]  R2547     2.9862058162689209e-01
    z[7,6,0]  R2548     -2.7959802746772766e-01
    z[7,6,0]  R2549     6.2875278294086456e-02
    z[7,6,0]  R2550     -0.276602566242218
    z[7,6,0]  R2551     -7.9921597242355347e-01
    z[7,6,0]  R2552     -1.3351860642433167e-01
    z[7,6,0]  R2553     -0.386550635099411
    z[7,6,0]  R2554     1.8768247961997986e-01
    z[7,6,0]  R2555     0.360411673784256
    z[7,6,0]  R2556     0.00948364194482565
    z[7,6,0]  R2557     -7.2981618344783783e-02
    z[7,6,0]  R2558     1.3737419247627258e-01
    z[7,6,0]  R2559     3.1392046809196472e-01
    z[7,6,0]  R2560     -2.3087984323501587e-01
    z[7,6,0]  R2561     -4.2213848233222961e-01
    z[7,6,0]  R2562     1.6414934396743774e-01
    z[7,6,0]  R2563     3.0744003131985664e-02
    z[7,6,0]  R2564     -2.0722879469394684e-01
    z[7,6,0]  R2565     -4.4394785165786743e-01
    z[7,6,0]  R2566     1.7102941870689392e-01
    z[7,6,0]  R2567     -1.8538489937782288e-02
    z[7,6,0]  R2568     8.7123408913612366e-02
    z[7,6,0]  R2569     4.1409574449062347e-02
    z[7,6,0]  R2570     -3.5936015844345093e-01
    z[7,6,0]  R2571     4.4195351004600525e-01
    z[7,6,0]  R2572     6.2430912256240845e-01
    z[7,6,0]  R2573     -8.7492220103740692e-02
    z[7,6,0]  R2574     2.5624117255210876e-01
    z[7,6,0]  R2575     1.1700862646102905e-01
    z[7,6,0]  R2576     5.0234988331794739e-02
    z[7,6,0]  R2577     2.8864863514900208e-01
    z[7,6,0]  R2578     2.2634042799472809e-01
    z[7,6,0]  R2579     1.8652193248271942e-01
    z[7,6,0]  R2580     8.8945478200912476e-03
    z[7,6,0]  R2581     1.6408419609069824e-01
    z[7,6,0]  R2582     -1.7532561719417572e-01
    z[7,6,0]  R2583     -1.5319344401359558e-01
    z[7,6,0]  R2584     -1.9433531910181046e-02
    z[7,6,0]  R2585     -2.4648292362689972e-01
    z[7,6,0]  R2586     2.1938095986843109e-01
    z[7,6,0]  R2587     -1.9774494692683220e-02
    z[7,6,0]  R2588     -3.9564505219459534e-02
    z[7,6,0]  R2589     -1.0036766529083252e-01
    z[7,6,0]  R2590     6.9954305887222290e-02
    z[7,6,0]  R2591     9.8391972482204437e-02
    z[7,6,0]  R2592     -3.1425106525421143e-01
    z[7,6,0]  R2593     -1.5212918631732464e-02
    z[7,6,0]  R2594     2.8497523069381714e-01
    z[7,6,0]  R2595     2.9772745445370674e-02
    z[7,6,1]  R57       1
    z[7,6,1]  R66       -1
    z[7,6,1]  R2484     -1
    z[7,6,1]  R2485     1
    z[7,6,1]  R2496     1.1788117140531540e-01
    z[7,6,1]  R2497     -5.7180680334568024e-02
    z[7,6,1]  R2498     -1.2512235343456268e-01
    z[7,6,1]  R2499     -2.2064872086048126e-01
    z[7,6,1]  R2500     -0.262986958026886
    z[7,6,1]  R2501     -2.0322947204113007e-01
    z[7,6,1]  R2502     1.2710350751876831e-01
    z[7,6,1]  R2503     -6.1658447980880737e-01
    z[7,6,1]  R2504     -5.7900321483612061e-01
    z[7,6,1]  R2505     -6.4628767967224121e-01
    z[7,6,1]  R2506     1.9738541543483734e-01
    z[7,6,1]  R2507     6.6613882780075073e-01
    z[7,6,1]  R2508     7.3474103212356567e-01
    z[7,6,1]  R2509     7.4525296688079834e-02
    z[7,6,1]  R2510     -2.2945592645555735e-03
    z[7,6,1]  R2511     4.4102672487497330e-02
    z[7,6,1]  R2512     5.7743549346923828e-01
    z[7,6,1]  R2513     5.3636454045772552e-02
    z[7,6,1]  R2514     4.0496596693992615e-01
    z[7,6,1]  R2515     6.5669816732406616e-01
    z[7,6,1]  R2516     -6.7782026529312134e-01
    z[7,6,1]  R2517     -8.0523324012756348e-01
    z[7,6,1]  R2518     -5.9223777055740356e-01
    z[7,6,1]  R2519     -7.8164649009704590e-01
    z[7,6,1]  R2520     -7.4711662530899048e-01
    z[7,6,1]  R2521     -6.4996057748794556e-01
    z[7,6,1]  R2522     -0.512759268283844
    z[7,6,1]  R2523     -5.2422821521759033e-01
    z[7,6,1]  R2524     -4.5910209417343140e-01
    z[7,6,1]  R2525     1.1272864043712616e-01
    z[7,6,1]  R2526     -3.4529095888137817e-01
    z[7,6,1]  R2527     7.0104561746120453e-03
    z[7,6,1]  R2528     4.6046581119298935e-03
    z[7,6,1]  R2529     -5.4499473422765732e-02
    z[7,6,1]  R2530     1.7552489042282104e-01
    z[7,6,1]  R2531     -9.6060343086719513e-02
    z[7,6,1]  R2532     7.1108184754848480e-02
    z[7,6,1]  R2533     -4.3063253164291382e-01
    z[7,6,1]  R2534     2.3395034670829773e-01
    z[7,6,1]  R2535     1.2475195527076721e-01
    z[7,6,1]  R2536     -6.4332002401351929e-01
    z[7,6,1]  R2537     8.6006671190261841e-02
    z[7,6,1]  R2538     5.9089845418930054e-01
    z[7,6,1]  R2539     6.4706325531005859e-01
    z[7,6,1]  R2540     0.686769425868988
    z[7,6,1]  R2541     2.7850097417831421e-01
    z[7,6,1]  R2542     9.1011798381805420e-01
    z[7,6,1]  R2543     8.5468226671218872e-01
    z[7,6,1]  R2544     9.0942496061325073e-01
    z[7,6,1]  R2545     7.3431169986724854e-01
    z[7,6,1]  R2546     -7.3055410385131836e-01
    z[7,6,1]  R2547     -6.7307293415069580e-01
    z[7,6,1]  R2548     -7.0669221878051758e-01
    z[7,6,1]  R2549     -6.1387270689010620e-01
    z[7,6,1]  R2550     9.0618662536144257e-02
    z[7,6,1]  R2551     5.9256780147552490e-01
    z[7,6,1]  R2552     6.7437773942947388e-01
    z[7,6,1]  R2553     7.3519986867904663e-01
    z[7,6,1]  R2554     5.2971726655960083e-01
    z[7,6,1]  R2555     4.3057283759117126e-01
    z[7,6,1]  R2556     1.6811764240264893e-01
    z[7,6,1]  R2557     -1.8261192739009857e-01
    z[7,6,1]  R2558     1.1428344249725342e-01
    z[7,6,1]  R2559     -2.3681230843067169e-01
    z[7,6,1]  R2560     5.2666431665420532e-01
    z[7,6,1]  R2561     -6.3359868526458740e-01
    z[7,6,1]  R2562     -4.1051259636878967e-01
    z[7,6,1]  R2563     -7.9370737075805664e-01
    z[7,6,1]  R2564     -6.4974778890609741e-01
    z[7,6,1]  R2565     -4.7977665066719055e-01
    z[7,6,1]  R2566     -6.0350996255874634e-01
    z[7,6,1]  R2567     -6.1813724040985107e-01
    z[7,6,1]  R2568     -5.3952005691826344e-03
    z[7,6,1]  R2569     -5.5794250965118408e-01
    z[7,6,1]  R2570     -5.0592315196990967e-01
    z[7,6,1]  R2571     4.3353664875030518e-01
    z[7,6,1]  R2572     -3.8781440258026123e-01
    z[7,6,1]  R2573     -4.0554407238960266e-01
    z[7,6,1]  R2574     -0.0594235435128212
    z[7,6,1]  R2575     1.9486029446125031e-01
    z[7,6,1]  R2576     5.9816908091306686e-02
    z[7,6,1]  R2577     -2.2000917792320251e-01
    z[7,6,1]  R2578     -0.352643221616745
    z[7,6,1]  R2579     -6.9116353988647461e-02
    z[7,6,1]  R2580     -4.0837228298187256e-01
    z[7,6,1]  R2581     -0.362091600894928
    z[7,6,1]  R2582     6.3361212611198425e-02
    z[7,6,1]  R2583     -3.8537091016769409e-01
    z[7,6,1]  R2584     -0.638166606426239
    z[7,6,1]  R2585     -1.2333747744560242e-01
    z[7,6,1]  R2586     -3.1664052605628967e-01
    z[7,6,1]  R2587     3.8286406546831131e-02
    z[7,6,1]  R2588     -3.5802689194679260e-01
    z[7,6,1]  R2589     -2.6379999518394470e-01
    z[7,6,1]  R2590     -2.3484107851982117e-01
    z[7,6,1]  R2591     -9.1423398256301880e-01
    z[7,6,1]  R2592     1.8186372518539429e-01
    z[7,6,1]  R2593     8.9892917871475220e-01
    z[7,6,1]  R2594     -0.643058717250824
    z[7,6,1]  R2595     8.7337815761566162e-01
    z[7,6,2]  R58       1
    z[7,6,2]  R67       -1
    z[7,6,2]  R2486     -1
    z[7,6,2]  R2487     1
    z[7,6,2]  R2496     1.5736088156700134e-01
    z[7,6,2]  R2497     3.1619224697351456e-02
    z[7,6,2]  R2498     -2.8328439593315125e-01
    z[7,6,2]  R2499     1.6663897037506104e-01
    z[7,6,2]  R2500     4.3664994835853577e-01
    z[7,6,2]  R2501     3.6473900079727173e-01
    z[7,6,2]  R2502     9.3046009540557861e-02
    z[7,6,2]  R2503     2.6254189014434814e-01
    z[7,6,2]  R2504     0.255932092666626
    z[7,6,2]  R2505     3.0451336503028870e-01
    z[7,6,2]  R2506     -7.3511481285095215e-01
    z[7,6,2]  R2507     -3.7339490652084351e-01
    z[7,6,2]  R2508     -2.5605386495590210e-01
    z[7,6,2]  R2509     -3.1785136461257935e-01
    z[7,6,2]  R2510     -8.7365549802780151e-01
    z[7,6,2]  R2511     -6.0707551240921021e-01
    z[7,6,2]  R2512     -3.5549452900886536e-01
    z[7,6,2]  R2513     -0.730562686920166
    z[7,6,2]  R2514     -7.2983330488204956e-01
    z[7,6,2]  R2515     -5.8316880464553833e-01
    z[7,6,2]  R2516     -5.9866684675216675e-01
    z[7,6,2]  R2517     -3.0322751402854919e-01
    z[7,6,2]  R2518     -2.2276845574378967e-01
    z[7,6,2]  R2519     -8.7085880339145660e-02
    z[7,6,2]  R2520     -1.8152470886707306e-01
    z[7,6,2]  R2521     -2.1618537604808807e-01
    z[7,6,2]  R2522     -4.0154952555894852e-02
    z[7,6,2]  R2523     1.2722371518611908e-01
    z[7,6,2]  R2524     7.7772176265716553e-01
    z[7,6,2]  R2525     -2.9540473222732544e-01
    z[7,6,2]  R2526     3.6096596717834473e-01
    z[7,6,2]  R2527     -3.6073359847068787e-01
    z[7,6,2]  R2528     -0.50264972448349
    z[7,6,2]  R2529     -1.4566515386104584e-01
    z[7,6,2]  R2530     -5.9669876098632812e-01
    z[7,6,2]  R2531     -4.2036834359169006e-01
    z[7,6,2]  R2532     -0.81169593334198
    z[7,6,2]  R2533     -8.8499732315540314e-02
    z[7,6,2]  R2534     5.6356781721115112e-01
    z[7,6,2]  R2535     6.6970270872116089e-01
    z[7,6,2]  R2536     2.8186139464378357e-01
    z[7,6,2]  R2537     -0.647044837474823
    z[7,6,2]  R2538     -7.7119171619415283e-02
    z[7,6,2]  R2539     -5.6557118892669678e-01
    z[7,6,2]  R2540     -4.3069493770599365e-01
    z[7,6,2]  R2541     4.9036827683448792e-01
    z[7,6,2]  R2542     6.6082730889320374e-02
    z[7,6,2]  R2543     1.8462300300598145e-01
    z[7,6,2]  R2544     -1.1157387867569923e-02
    z[7,6,2]  R2545     -5.1228034496307373e-01
    z[7,6,2]  R2546     2.6303809881210327e-01
    z[7,6,2]  R2547     5.2225303649902344e-01
    z[7,6,2]  R2548     1.6468265652656555e-01
    z[7,6,2]  R2549     -3.2448098063468933e-01
    z[7,6,2]  R2550     -0.89305579662323
    z[7,6,2]  R2551     -5.2912008017301559e-02
    z[7,6,2]  R2552     -6.0445809364318848e-01
    z[7,6,2]  R2553     -3.9572045207023621e-01
    z[7,6,2]  R2554     5.8833497762680054e-01
    z[7,6,2]  R2555     6.8056142330169678e-01
    z[7,6,2]  R2556     -1.1657848954200745e-01
    z[7,6,2]  R2557     -0.27797931432724
    z[7,6,2]  R2558     -2.8962761163711548e-01
    z[7,6,2]  R2559     9.1380268335342407e-02
    z[7,6,2]  R2560     1.9642254710197449e-01
    z[7,6,2]  R2561     -3.4210613369941711e-01
    z[7,6,2]  R2562     1.8819691240787506e-01
    z[7,6,2]  R2563     -3.0000713467597961e-01
    z[7,6,2]  R2564     -9.1953672468662262e-02
    z[7,6,2]  R2565     -1.1292373389005661e-01
    z[7,6,2]  R2566     -1.0943014174699783e-01
    z[7,6,2]  R2567     -0.0857386440038681
    z[7,6,2]  R2568     -3.6604857444763184e-01
    z[7,6,2]  R2569     -2.0322367548942566e-01
    z[7,6,2]  R2570     2.7266851067543030e-01
    z[7,6,2]  R2571     1.0813126713037491e-01
    z[7,6,2]  R2572     1.0796468704938889e-01
    z[7,6,2]  R2573     7.8948169946670532e-01
    z[7,6,2]  R2574     2.6973477005958557e-01
    z[7,6,2]  R2575     4.8148965835571289e-01
    z[7,6,2]  R2576     0.413653701543808
    z[7,6,2]  R2577     0.342832088470459
    z[7,6,2]  R2578     -2.6855310425162315e-02
    z[7,6,2]  R2579     -0.0953153595328331
    z[7,6,2]  R2580     4.4445610046386719e-01
    z[7,6,2]  R2581     3.8897311687469482e-01
    z[7,6,2]  R2582     -1.4220274984836578e-01
    z[7,6,2]  R2583     0.567274808883667
    z[7,6,2]  R2584     6.6093361377716064e-01
    z[7,6,2]  R2585     4.6385416388511658e-01
    z[7,6,2]  R2586     4.8049096018075943e-02
    z[7,6,2]  R2587     1.9378603994846344e-01
    z[7,6,2]  R2588     7.5120642781257629e-02
    z[7,6,2]  R2589     -2.4247172474861145e-01
    z[7,6,2]  R2590     -4.8259615898132324e-01
    z[7,6,2]  R2591     3.5424941778182983e-01
    z[7,6,2]  R2592     -1.0859417915344238e-01
    z[7,6,2]  R2593     9.9274478852748871e-02
    z[7,6,2]  R2594     5.9204649925231934e-01
    z[7,6,2]  R2595     -5.3504716604948044e-02
    z[7,6,3]  R59       1
    z[7,6,3]  R68       -1
    z[7,6,3]  R2488     -1
    z[7,6,3]  R2489     1
    z[7,6,3]  R2496     -0.504252552986145
    z[7,6,3]  R2497     -2.4172352254390717e-01
    z[7,6,3]  R2498     -3.7082454562187195e-01
    z[7,6,3]  R2499     -4.2431572079658508e-01
    z[7,6,3]  R2500     -1.4273391105234623e-02
    z[7,6,3]  R2501     -4.8467060923576355e-01
    z[7,6,3]  R2502     -2.1092857420444489e-01
    z[7,6,3]  R2503     -1.8700738251209259e-01
    z[7,6,3]  R2504     5.6740206480026245e-01
    z[7,6,3]  R2505     -1.0911568999290466e-01
    z[7,6,3]  R2506     -4.2100772261619568e-02
    z[7,6,3]  R2507     -2.1732452511787415e-01
    z[7,6,3]  R2508     -0.109881691634655
    z[7,6,3]  R2509     -1.2937353551387787e-01
    z[7,6,3]  R2510     -1.6076089814305305e-02
    z[7,6,3]  R2511     5.3015798330307007e-02
    z[7,6,3]  R2512     -4.6307405829429626e-01
    z[7,6,3]  R2513     -1.3483323156833649e-02
    z[7,6,3]  R2514     1.8107822537422180e-01
    z[7,6,3]  R2515     -1.2303494662046432e-01
    z[7,6,3]  R2516     1.1183109134435654e-01
    z[7,6,3]  R2517     4.8025703430175781e-01
    z[7,6,3]  R2518     -4.1683989763259888e-01
    z[7,6,3]  R2519     2.5238654017448425e-01
    z[7,6,3]  R2520     1.8978676199913025e-01
    z[7,6,3]  R2521     -3.0419981479644775e-01
    z[7,6,3]  R2522     5.2527725696563721e-01
    z[7,6,3]  R2523     2.6501783728599548e-01
    z[7,6,3]  R2524     2.3504644632339478e-01
    z[7,6,3]  R2525     -3.0951502267271280e-03
    z[7,6,3]  R2526     -1.0267569869756699e-01
    z[7,6,3]  R2527     -9.5114611089229584e-02
    z[7,6,3]  R2528     -3.6320930719375610e-01
    z[7,6,3]  R2529     -3.2691818475723267e-01
    z[7,6,3]  R2530     1.5387211740016937e-01
    z[7,6,3]  R2531     1.2792519293725491e-02
    z[7,6,3]  R2532     9.7040623426437378e-02
    z[7,6,3]  R2533     -4.2647728323936462e-01
    z[7,6,3]  R2534     9.0673323720693588e-03
    z[7,6,3]  R2535     -3.9340332150459290e-01
    z[7,6,3]  R2536     3.7332630157470703e-01
    z[7,6,3]  R2537     -4.8981118947267532e-02
    z[7,6,3]  R2538     4.3991249054670334e-02
    z[7,6,3]  R2539     -1.4338363707065582e-01
    z[7,6,3]  R2540     -1.6163422167301178e-01
    z[7,6,3]  R2541     -2.2544270753860474e-01
    z[7,6,3]  R2542     -3.7036520242691040e-01
    z[7,6,3]  R2543     -3.8125243782997131e-01
    z[7,6,3]  R2544     -3.3912095427513123e-01
    z[7,6,3]  R2545     1.9066568464040756e-02
    z[7,6,3]  R2546     3.4886658191680908e-01
    z[7,6,3]  R2547     9.6905358135700226e-02
    z[7,6,3]  R2548     4.7653075307607651e-02
    z[7,6,3]  R2549     1.5867911279201508e-01
    z[7,6,3]  R2550     -4.2687293142080307e-02
    z[7,6,3]  R2551     -9.7977332770824432e-03
    z[7,6,3]  R2552     -6.8670073524117470e-03
    z[7,6,3]  R2553     -2.0256450772285461e-01
    z[7,6,3]  R2554     -5.2521169185638428e-01
    z[7,6,3]  R2555     -3.5196962952613831e-01
    z[7,6,3]  R2556     -0.85221928358078
    z[7,6,3]  R2557     -8.1240195035934448e-01
    z[7,6,3]  R2558     -5.2628499269485474e-01
    z[7,6,3]  R2559     -7.5213503837585449e-01
    z[7,6,3]  R2560     -4.3814745545387268e-01
    z[7,6,3]  R2561     1.2706759572029114e-01
    z[7,6,3]  R2562     3.4517151117324829e-01
    z[7,6,3]  R2563     -1.5411342494189739e-02
    z[7,6,3]  R2564     2.3107966780662537e-01
    z[7,6,3]  R2565     -5.8358427137136459e-02
    z[7,6,3]  R2566     4.1151252388954163e-01
    z[7,6,3]  R2567     5.9133970737457275e-01
    z[7,6,3]  R2568     5.1580494642257690e-01
    z[7,6,3]  R2569     7.1391516923904419e-01
    z[7,6,3]  R2570     3.2900074124336243e-01
    z[7,6,3]  R2571     6.9959261454641819e-03
    z[7,6,3]  R2572     3.8137266039848328e-01
    z[7,6,3]  R2573     0.338481068611145
    z[7,6,3]  R2574     2.3638258874416351e-01
    z[7,6,3]  R2575     -0.462100625038147
    z[7,6,3]  R2576     4.8471182584762573e-01
    z[7,6,3]  R2577     4.3285819888114929e-01
    z[7,6,3]  R2578     4.2439797520637512e-01
    z[7,6,3]  R2579     4.8455065488815308e-01
    z[7,6,3]  R2580     4.9847099184989929e-01
    z[7,6,3]  R2581     3.9329320192337036e-01
    z[7,6,3]  R2582     4.8132848739624023e-01
    z[7,6,3]  R2583     5.7116001844406128e-01
    z[7,6,3]  R2584     8.5973121225833893e-02
    z[7,6,3]  R2585     0.566581130027771
    z[7,6,3]  R2586     0.543865442276001
    z[7,6,3]  R2587     4.8258337378501892e-01
    z[7,6,3]  R2588     4.3860536813735962e-01
    z[7,6,3]  R2589     7.4338442087173462e-01
    z[7,6,3]  R2590     7.0555222034454346e-01
    z[7,6,3]  R2591     1.0699941217899323e-01
    z[7,6,3]  R2592     4.6006390452384949e-01
    z[7,6,3]  R2593     2.5437566637992859e-01
    z[7,6,3]  R2594     3.3498144149780273e-01
    z[7,6,3]  R2595     1.4639307558536530e-01
    z[7,6,4]  R60       1
    z[7,6,4]  R69       -1
    z[7,6,4]  R2490     -1
    z[7,6,4]  R2491     1
    z[7,6,4]  R2496     -9.3567736446857452e-02
    z[7,6,4]  R2497     -4.1627362370491028e-03
    z[7,6,4]  R2498     -1.7485836520791054e-02
    z[7,6,4]  R2499     -3.9552173018455505e-01
    z[7,6,4]  R2500     -5.4580219089984894e-02
    z[7,6,4]  R2501     4.1839987039566040e-01
    z[7,6,4]  R2502     5.4671669006347656e-01
    z[7,6,4]  R2503     -4.9099615216255188e-01
    z[7,6,4]  R2504     1.4081904292106628e-01
    z[7,6,4]  R2505     1.8393313884735107e-01
    z[7,6,4]  R2506     -1.8558960407972336e-02
    z[7,6,4]  R2507     2.4832665920257568e-01
    z[7,6,4]  R2508     -2.2210772335529327e-01
    z[7,6,4]  R2509     6.6949248313903809e-01
    z[7,6,4]  R2510     3.9261576533317566e-01
    z[7,6,4]  R2511     6.2186169624328613e-01
    z[7,6,4]  R2512     1.2779118493199348e-02
    z[7,6,4]  R2513     -1.0554113984107971e-01
    z[7,6,4]  R2514     -3.8992649316787720e-01
    z[7,6,4]  R2515     -1.0634469240903854e-01
    z[7,6,4]  R2516     3.4463945031166077e-01
    z[7,6,4]  R2517     3.5495623946189880e-02
    z[7,6,4]  R2518     4.9213263392448425e-01
    z[7,6,4]  R2519     3.8332742452621460e-01
    z[7,6,4]  R2520     2.8598508238792419e-01
    z[7,6,4]  R2521     -1.3394100964069366e-01
    z[7,6,4]  R2522     -4.4146808981895447e-01
    z[7,6,4]  R2523     -2.3624691367149353e-01
    z[7,6,4]  R2524     -2.4334377050399780e-01
    z[7,6,4]  R2525     -4.7691500186920166e-01
    z[7,6,4]  R2526     2.7066943049430847e-01
    z[7,6,4]  R2527     5.8024022728204727e-02
    z[7,6,4]  R2528     -0.0924634113907814
    z[7,6,4]  R2529     1.2324440479278564e-01
    z[7,6,4]  R2530     1.5061776340007782e-01
    z[7,6,4]  R2531     -9.0359859168529510e-03
    z[7,6,4]  R2532     2.4451713263988495e-01
    z[7,6,4]  R2533     4.0662929415702820e-01
    z[7,6,4]  R2534     4.1545665264129639e-01
    z[7,6,4]  R2535     2.5468489527702332e-01
    z[7,6,4]  R2536     -4.1382867097854614e-01
    z[7,6,4]  R2537     -5.0561362504959106e-01
    z[7,6,4]  R2538     -3.6079576238989830e-03
    z[7,6,4]  R2539     -2.3232956230640411e-01
    z[7,6,4]  R2540     -2.8039303421974182e-01
    z[7,6,4]  R2541     -1.9280940294265747e-02
    z[7,6,4]  R2542     6.0891743749380112e-02
    z[7,6,4]  R2543     -3.9529930800199509e-02
    z[7,6,4]  R2544     -1.9411031901836395e-01
    z[7,6,4]  R2545     -4.1277384757995605e-01
    z[7,6,4]  R2546     -0.163431316614151
    z[7,6,4]  R2547     -1.5994679182767868e-02
    z[7,6,4]  R2548     -3.1727802753448486e-01
    z[7,6,4]  R2549     -1.9960127770900726e-01
    z[7,6,4]  R2550     -1.3360002636909485e-01
    z[7,6,4]  R2551     -5.7889252901077271e-02
    z[7,6,4]  R2552     -2.9758140444755554e-01
    z[7,6,4]  R2553     -1.0412189364433289e-01
    z[7,6,4]  R2554     2.4219968914985657e-01
    z[7,6,4]  R2555     2.4200481176376343e-01
    z[7,6,4]  R2556     2.0948500931262970e-01
    z[7,6,4]  R2557     -3.1193265318870544e-01
    z[7,6,4]  R2558     -1.3032099604606628e-01
    z[7,6,4]  R2559     -4.3716788291931152e-02
    z[7,6,4]  R2560     -2.6139837503433228e-01
    z[7,6,4]  R2561     -1.1416272819042206e-01
    z[7,6,4]  R2562     4.3638557195663452e-01
    z[7,6,4]  R2563     -2.4576272070407867e-01
    z[7,6,4]  R2564     -5.5505480617284775e-02
    z[7,6,4]  R2565     2.8016555309295654e-01
    z[7,6,4]  R2566     5.6557816267013550e-01
    z[7,6,4]  R2567     -3.4651103615760803e-01
    z[7,6,4]  R2568     -3.6873687058687210e-02
    z[7,6,4]  R2569     -1.4194028079509735e-01
    z[7,6,4]  R2570     -2.9900604486465454e-01
    z[7,6,4]  R2571     0.667676568031311
    z[7,6,4]  R2572     1.8114092946052551e-01
    z[7,6,4]  R2573     -4.0168181061744690e-02
    z[7,6,4]  R2574     2.1784137934446335e-02
    z[7,6,4]  R2575     -4.7689802944660187e-02
    z[7,6,4]  R2576     1.3894718885421753e-01
    z[7,6,4]  R2577     2.0598727464675903e-01
    z[7,6,4]  R2578     3.7436592578887939e-01
    z[7,6,4]  R2579     -1.3234195113182068e-01
    z[7,6,4]  R2580     -1.9997909665107727e-01
    z[7,6,4]  R2581     2.9672408103942871e-01
    z[7,6,4]  R2582     -3.4363400936126709e-01
    z[7,6,4]  R2583     -1.0641941428184509e-01
    z[7,6,4]  R2584     -0.382472962141037
    z[7,6,4]  R2585     -4.4036373496055603e-01
    z[7,6,4]  R2586     1.1417217552661896e-01
    z[7,6,4]  R2587     1.5343791246414185e-01
    z[7,6,4]  R2588     3.6165687441825867e-01
    z[7,6,4]  R2589     -4.7659203410148621e-01
    z[7,6,4]  R2590     -0.0654422715306282
    z[7,6,4]  R2591     4.0773589164018631e-02
    z[7,6,4]  R2592     3.0711600184440613e-01
    z[7,6,4]  R2593     9.1799207031726837e-02
    z[7,6,4]  R2594     9.9960751831531525e-02
    z[7,6,4]  R2595     3.4307071566581726e-01
    z[7,6,5]  R61       1
    z[7,6,5]  R70       -1
    z[7,6,5]  R2492     -1
    z[7,6,5]  R2493     1
    z[7,6,5]  R2496     4.2699400335550308e-02
    z[7,6,5]  R2497     -1.3356618583202362e-01
    z[7,6,5]  R2498     -3.2809235155582428e-02
    z[7,6,5]  R2499     5.3201489150524139e-02
    z[7,6,5]  R2500     -1.0581449419260025e-01
    z[7,6,5]  R2501     0.0456363819539547
    z[7,6,5]  R2502     -1.0163668543100357e-01
    z[7,6,5]  R2503     -3.2858392596244812e-01
    z[7,6,5]  R2504     2.8948080539703369e-01
    z[7,6,5]  R2505     2.4532085657119751e-01
    z[7,6,5]  R2506     -5.8020043373107910e-01
    z[7,6,5]  R2507     5.5503454059362411e-02
    z[7,6,5]  R2508     1.2265937775373459e-01
    z[7,6,5]  R2509     -2.0580182969570160e-01
    z[7,6,5]  R2510     -0.162678524851799
    z[7,6,5]  R2511     1.8457837402820587e-02
    z[7,6,5]  R2512     -1.9807896018028259e-01
    z[7,6,5]  R2513     -8.4291743114590645e-03
    z[7,6,5]  R2514     2.5627663731575012e-01
    z[7,6,5]  R2515     3.3952635526657104e-01
    z[7,6,5]  R2516     3.5490646958351135e-02
    z[7,6,5]  R2517     -9.9709741771221161e-02
    z[7,6,5]  R2518     -1.2336204200983047e-01
    z[7,6,5]  R2519     -0.200625479221344
    z[7,6,5]  R2520     -5.1801913976669312e-01
    z[7,6,5]  R2521     5.2026188373565674e-01
    z[7,6,5]  R2522     -3.2877799123525620e-02
    z[7,6,5]  R2523     -1.8231348693370819e-01
    z[7,6,5]  R2524     1.1712416261434555e-01
    z[7,6,5]  R2525     -1.7633208632469177e-01
    z[7,6,5]  R2526     1.3752581179141998e-01
    z[7,6,5]  R2527     -5.5856925249099731e-01
    z[7,6,5]  R2528     -2.0876045525074005e-01
    z[7,6,5]  R2529     -0.320121705532074
    z[7,6,5]  R2530     -2.7869519591331482e-01
    z[7,6,5]  R2531     1.1142909526824951e-02
    z[7,6,5]  R2532     -6.2896623276174068e-03
    z[7,6,5]  R2533     -2.5724676251411438e-01
    z[7,6,5]  R2534     5.0354021787643433e-01
    z[7,6,5]  R2535     -3.6257150769233704e-01
    z[7,6,5]  R2536     3.9444151520729065e-01
    z[7,6,5]  R2537     -5.5814504623413086e-01
    z[7,6,5]  R2538     5.5932231247425079e-02
    z[7,6,5]  R2539     -1.4626109972596169e-02
    z[7,6,5]  R2540     3.1677356362342834e-01
    z[7,6,5]  R2541     1.9272281229496002e-01
    z[7,6,5]  R2542     2.3736661300063133e-02
    z[7,6,5]  R2543     -1.2253225594758987e-01
    z[7,6,5]  R2544     5.9116680175065994e-02
    z[7,6,5]  R2545     -3.1366065144538879e-02
    z[7,6,5]  R2546     4.3536716699600220e-01
    z[7,6,5]  R2547     -3.9726775884628296e-01
    z[7,6,5]  R2548     2.3148950934410095e-01
    z[7,6,5]  R2549     -3.2445770502090454e-01
    z[7,6,5]  R2550     -2.2903005778789520e-01
    z[7,6,5]  R2551     3.3493004739284515e-02
    z[7,6,5]  R2552     -1.6680642962455750e-01
    z[7,6,5]  R2553     3.0079308152198792e-01
    z[7,6,5]  R2554     -5.6932557374238968e-02
    z[7,6,5]  R2555     1.9158987700939178e-01
    z[7,6,5]  R2556     -4.1011118888854980e-01
    z[7,6,5]  R2557     -3.5467270016670227e-01
    z[7,6,5]  R2558     -6.7898106575012207e-01
    z[7,6,5]  R2559     -3.8434910774230957e-01
    z[7,6,5]  R2560     -6.0099124908447266e-01
    z[7,6,5]  R2561     8.2026623189449310e-02
    z[7,6,5]  R2562     -2.9660975933074951e-01
    z[7,6,5]  R2563     4.6530964970588684e-01
    z[7,6,5]  R2564     5.5250751972198486e-01
    z[7,6,5]  R2565     4.3743756413459778e-01
    z[7,6,5]  R2566     -3.0136564373970032e-01
    z[7,6,5]  R2567     3.5118868947029114e-01
    z[7,6,5]  R2568     7.3869693279266357e-01
    z[7,6,5]  R2569     -2.6882886886596680e-01
    z[7,6,5]  R2570     -4.3684488534927368e-01
    z[7,6,5]  R2571     3.1190750002861023e-01
    z[7,6,5]  R2572     5.0793045759201050e-01
    z[7,6,5]  R2573     4.7194175422191620e-02
    z[7,6,5]  R2574     8.8561016321182251e-01
    z[7,6,5]  R2575     7.0759785175323486e-01
    z[7,6,5]  R2576     7.4784934520721436e-01
    z[7,6,5]  R2577     7.0382225513458252e-01
    z[7,6,5]  R2578     7.0949828624725342e-01
    z[7,6,5]  R2579     7.6195400953292847e-01
    z[7,6,5]  R2580     5.8875405788421631e-01
    z[7,6,5]  R2581     6.5910464525222778e-01
    z[7,6,5]  R2582     7.7146822214126587e-01
    z[7,6,5]  R2583     2.8881141543388367e-01
    z[7,6,5]  R2584     -3.2654516398906708e-02
    z[7,6,5]  R2585     4.1194760799407959e-01
    z[7,6,5]  R2586     7.1507257223129272e-01
    z[7,6,5]  R2587     8.2039844989776611e-01
    z[7,6,5]  R2588     6.3013392686843872e-01
    z[7,6,5]  R2589     1.5305669605731964e-01
    z[7,6,5]  R2590     3.7789145112037659e-01
    z[7,6,5]  R2591     -4.2847845703363419e-02
    z[7,6,5]  R2592     4.6800276637077332e-01
    z[7,6,5]  R2593     3.1855154037475586e-01
    z[7,6,5]  R2594     1.1651323735713959e-01
    z[7,6,5]  R2595     3.0713552236557007e-01
    z[7,6,6]  R62       1
    z[7,6,6]  R71       -1
    z[7,6,6]  R2494     -1
    z[7,6,6]  R2495     1
    z[7,6,6]  R2496     -6.8305768072605133e-02
    z[7,6,6]  R2497     -2.6315292716026306e-01
    z[7,6,6]  R2498     1.8965634703636169e-01
    z[7,6,6]  R2499     2.7610439062118530e-01
    z[7,6,6]  R2500     1.0315315425395966e-01
    z[7,6,6]  R2501     1.1893185228109360e-01
    z[7,6,6]  R2502     3.6621958017349243e-01
    z[7,6,6]  R2503     -3.7528967857360840e-01
    z[7,6,6]  R2504     3.8977968692779541e-01
    z[7,6,6]  R2505     -5.9992820024490356e-01
    z[7,6,6]  R2506     2.0464979112148285e-01
    z[7,6,6]  R2507     1.0193166881799698e-01
    z[7,6,6]  R2508     -2.1577247977256775e-01
    z[7,6,6]  R2509     2.7214100956916809e-01
    z[7,6,6]  R2510     -1.5039950609207153e-01
    z[7,6,6]  R2511     1.4134421944618225e-01
    z[7,6,6]  R2512     -2.4560080468654633e-01
    z[7,6,6]  R2513     -3.2802972197532654e-01
    z[7,6,6]  R2514     -8.7344385683536530e-02
    z[7,6,6]  R2515     -2.9046475887298584e-01
    z[7,6,6]  R2516     -3.3763226121664047e-02
    z[7,6,6]  R2517     8.7758764624595642e-02
    z[7,6,6]  R2518     1.3043515384197235e-01
    z[7,6,6]  R2519     -7.4390277266502380e-02
    z[7,6,6]  R2520     1.1244340986013412e-01
    z[7,6,6]  R2521     2.1105460822582245e-01
    z[7,6,6]  R2522     5.9766110032796860e-02
    z[7,6,6]  R2523     -1.1898516118526459e-01
    z[7,6,6]  R2524     2.3701743781566620e-01
    z[7,6,6]  R2525     1.8284708261489868e-01
    z[7,6,6]  R2526     7.6919443905353546e-02
    z[7,6,6]  R2527     3.5817271471023560e-01
    z[7,6,6]  R2528     -3.7950697541236877e-01
    z[7,6,6]  R2529     3.3026900142431259e-02
    z[7,6,6]  R2530     4.6391418576240540e-01
    z[7,6,6]  R2531     5.1949676126241684e-02
    z[7,6,6]  R2532     3.6134470254182816e-02
    z[7,6,6]  R2533     -4.2000627517700195e-01
    z[7,6,6]  R2534     4.0516536682844162e-02
    z[7,6,6]  R2535     8.3466731011867523e-02
    z[7,6,6]  R2536     -1.5520407259464264e-01
    z[7,6,6]  R2537     -0.0628967210650444
    z[7,6,6]  R2538     -5.4903768002986908e-02
    z[7,6,6]  R2539     -4.0593791007995605e-01
    z[7,6,6]  R2540     -1.8895855545997620e-01
    z[7,6,6]  R2541     -2.7942699193954468e-01
    z[7,6,6]  R2542     8.4527529776096344e-02
    z[7,6,6]  R2543     1.3570147752761841e-01
    z[7,6,6]  R2544     -1.3549934141337872e-02
    z[7,6,6]  R2545     1.6059705615043640e-01
    z[7,6,6]  R2546     -2.1056039631366730e-01
    z[7,6,6]  R2547     1.3259758055210114e-01
    z[7,6,6]  R2548     -4.8863810300827026e-01
    z[7,6,6]  R2549     -5.8619666099548340e-01
    z[7,6,6]  R2550     -2.1355259418487549e-01
    z[7,6,6]  R2551     -5.2427347749471664e-02
    z[7,6,6]  R2552     2.1352234482765198e-01
    z[7,6,6]  R2553     -1.0542669147253036e-01
    z[7,6,6]  R2554     -1.6958503052592278e-02
    z[7,6,6]  R2555     -4.8897020518779755e-02
    z[7,6,6]  R2556     1.4036749303340912e-01
    z[7,6,6]  R2557     -3.1022084876894951e-02
    z[7,6,6]  R2558     -3.5945597290992737e-01
    z[7,6,6]  R2559     -3.4882813692092896e-01
    z[7,6,6]  R2560     0.0961492657661438
    z[7,6,6]  R2561     5.1711469888687134e-01
    z[7,6,6]  R2562     -6.0955983400344849e-01
    z[7,6,6]  R2563     -4.3923977762460709e-02
    z[7,6,6]  R2564     4.0581443905830383e-01
    z[7,6,6]  R2565     -5.3546506166458130e-01
    z[7,6,6]  R2566     1.2044569849967957e-01
    z[7,6,6]  R2567     -1.3086408376693726e-01
    z[7,6,6]  R2568     -2.1284069120883942e-01
    z[7,6,6]  R2569     -2.0879344642162323e-01
    z[7,6,6]  R2570     0.389967143535614
    z[7,6,6]  R2571     -2.4880394339561462e-01
    z[7,6,6]  R2572     1.0923012346029282e-01
    z[7,6,6]  R2573     2.9357701539993286e-01
    z[7,6,6]  R2574     -1.3189360499382019e-01
    z[7,6,6]  R2575     -4.1599976248107851e-04
    z[7,6,6]  R2576     9.6221163868904114e-02
    z[7,6,6]  R2577     -1.5994152426719666e-01
    z[7,6,6]  R2578     -6.3475859351456165e-03
    z[7,6,6]  R2579     -3.4419447183609009e-01
    z[7,6,6]  R2580     2.2703444585204124e-02
    z[7,6,6]  R2581     1.1628524214029312e-01
    z[7,6,6]  R2582     9.9947135895490646e-03
    z[7,6,6]  R2583     2.9199233651161194e-01
    z[7,6,6]  R2584     2.8093319386243820e-02
    z[7,6,6]  R2585     1.5568609535694122e-01
    z[7,6,6]  R2586     -1.7072907090187073e-01
    z[7,6,6]  R2587     1.7637057602405548e-01
    z[7,6,6]  R2588     3.7995925545692444e-01
    z[7,6,6]  R2589     -2.4157127737998962e-01
    z[7,6,6]  R2590     -2.4933594465255737e-01
    z[7,6,6]  R2591     1.1855491995811462e-01
    z[7,6,6]  R2592     5.7565051317214966e-01
    z[7,6,6]  R2593     -8.5030794143676758e-02
    z[7,6,6]  R2594     -1.3771559298038483e-01
    z[7,6,6]  R2595     -8.6030957754701376e-04
    length[0]  OBJ       1
    length[1]  OBJ       1
    length[2]  OBJ       1
    length[3]  OBJ       1
    length[4]  OBJ       1
    length[5]  OBJ       1
    length[6]  OBJ       1
    length[7]  OBJ       1
    delta[0,0]  R2        1
    delta[0,1]  R3        1
    delta[0,2]  R4        1
    delta[0,3]  R5        1
    delta[0,4]  R6        1
    delta[0,5]  R7        1
    delta[0,6]  R8        1
    delta[1,0]  R11       1
    delta[1,1]  R12       1
    delta[1,2]  R13       1
    delta[1,3]  R14       1
    delta[1,4]  R15       1
    delta[1,5]  R16       1
    delta[1,6]  R17       1
    delta[2,0]  R20       1
    delta[2,1]  R21       1
    delta[2,2]  R22       1
    delta[2,3]  R23       1
    delta[2,4]  R24       1
    delta[2,5]  R25       1
    delta[2,6]  R26       1
    delta[3,0]  R29       1
    delta[3,1]  R30       1
    delta[3,2]  R31       1
    delta[3,3]  R32       1
    delta[3,4]  R33       1
    delta[3,5]  R34       1
    delta[3,6]  R35       1
    delta[4,0]  R38       1
    delta[4,1]  R39       1
    delta[4,2]  R40       1
    delta[4,3]  R41       1
    delta[4,4]  R42       1
    delta[4,5]  R43       1
    delta[4,6]  R44       1
    delta[5,0]  R47       1
    delta[5,1]  R48       1
    delta[5,2]  R49       1
    delta[5,3]  R50       1
    delta[5,4]  R51       1
    delta[5,5]  R52       1
    delta[5,6]  R53       1
    delta[6,0]  R56       1
    delta[6,1]  R57       1
    delta[6,2]  R58       1
    delta[6,3]  R59       1
    delta[6,4]  R60       1
    delta[6,5]  R61       1
    delta[6,6]  R62       1
    delta[7,0]  R65       1
    delta[7,1]  R66       1
    delta[7,2]  R67       1
    delta[7,3]  R68       1
    delta[7,4]  R69       1
    delta[7,5]  R70       1
    delta[7,6]  R71       1
RHS
    RHS1      R1        1
    RHS1      R10       1
    RHS1      R19       1
    RHS1      R28       1
    RHS1      R37       1
    RHS1      R46       1
    RHS1      R55       1
    RHS1      R64       1
    RHS1      R72       1
    RHS1      R73       -1
BOUNDS
 BV BND1      phi[0,1]
 BV BND1      phi[1,0]
 BV BND1      phi[0,5]
 BV BND1      phi[5,0]
 BV BND1      phi[8,0]
 BV BND1      phi[1,2]
 BV BND1      phi[2,1]
 BV BND1      phi[2,3]
 BV BND1      phi[3,2]
 BV BND1      phi[3,4]
 BV BND1      phi[4,3]
 BV BND1      phi[3,6]
 BV BND1      phi[6,3]
 BV BND1      phi[3,7]
 BV BND1      phi[7,3]
 BV BND1      phi[4,7]
 BV BND1      phi[7,4]
 BV BND1      phi[4,9]
 BV BND1      phi[5,6]
 BV BND1      phi[6,5]
 BV BND1      phi[8,5]
 BV BND1      phi[6,7]
 BV BND1      phi[7,6]
 BV BND1      phi[7,9]
 FR BND1      z[0,1,0]
 FR BND1      z[0,1,1]
 FR BND1      z[0,1,2]
 FR BND1      z[0,1,3]
 FR BND1      z[0,1,4]
 FR BND1      z[0,1,5]
 FR BND1      z[0,1,6]
 FR BND1      z[1,0,0]
 FR BND1      z[1,0,1]
 FR BND1      z[1,0,2]
 FR BND1      z[1,0,3]
 FR BND1      z[1,0,4]
 FR BND1      z[1,0,5]
 FR BND1      z[1,0,6]
 FR BND1      z[0,5,0]
 FR BND1      z[0,5,1]
 FR BND1      z[0,5,2]
 FR BND1      z[0,5,3]
 FR BND1      z[0,5,4]
 FR BND1      z[0,5,5]
 FR BND1      z[0,5,6]
 FR BND1      z[5,0,0]
 FR BND1      z[5,0,1]
 FR BND1      z[5,0,2]
 FR BND1      z[5,0,3]
 FR BND1      z[5,0,4]
 FR BND1      z[5,0,5]
 FR BND1      z[5,0,6]
 FR BND1      z[1,2,0]
 FR BND1      z[1,2,1]
 FR BND1      z[1,2,2]
 FR BND1      z[1,2,3]
 FR BND1      z[1,2,4]
 FR BND1      z[1,2,5]
 FR BND1      z[1,2,6]
 FR BND1      z[2,1,0]
 FR BND1      z[2,1,1]
 FR BND1      z[2,1,2]
 FR BND1      z[2,1,3]
 FR BND1      z[2,1,4]
 FR BND1      z[2,1,5]
 FR BND1      z[2,1,6]
 FR BND1      z[2,3,0]
 FR BND1      z[2,3,1]
 FR BND1      z[2,3,2]
 FR BND1      z[2,3,3]
 FR BND1      z[2,3,4]
 FR BND1      z[2,3,5]
 FR BND1      z[2,3,6]
 FR BND1      z[3,2,0]
 FR BND1      z[3,2,1]
 FR BND1      z[3,2,2]
 FR BND1      z[3,2,3]
 FR BND1      z[3,2,4]
 FR BND1      z[3,2,5]
 FR BND1      z[3,2,6]
 FR BND1      z[3,4,0]
 FR BND1      z[3,4,1]
 FR BND1      z[3,4,2]
 FR BND1      z[3,4,3]
 FR BND1      z[3,4,4]
 FR BND1      z[3,4,5]
 FR BND1      z[3,4,6]
 FR BND1      z[4,3,0]
 FR BND1      z[4,3,1]
 FR BND1      z[4,3,2]
 FR BND1      z[4,3,3]
 FR BND1      z[4,3,4]
 FR BND1      z[4,3,5]
 FR BND1      z[4,3,6]
 FR BND1      z[3,6,0]
 FR BND1      z[3,6,1]
 FR BND1      z[3,6,2]
 FR BND1      z[3,6,3]
 FR BND1      z[3,6,4]
 FR BND1      z[3,6,5]
 FR BND1      z[3,6,6]
 FR BND1      z[6,3,0]
 FR BND1      z[6,3,1]
 FR BND1      z[6,3,2]
 FR BND1      z[6,3,3]
 FR BND1      z[6,3,4]
 FR BND1      z[6,3,5]
 FR BND1      z[6,3,6]
 FR BND1      z[3,7,0]
 FR BND1      z[3,7,1]
 FR BND1      z[3,7,2]
 FR BND1      z[3,7,3]
 FR BND1      z[3,7,4]
 FR BND1      z[3,7,5]
 FR BND1      z[3,7,6]
 FR BND1      z[7,3,0]
 FR BND1      z[7,3,1]
 FR BND1      z[7,3,2]
 FR BND1      z[7,3,3]
 FR BND1      z[7,3,4]
 FR BND1      z[7,3,5]
 FR BND1      z[7,3,6]
 FR BND1      z[4,7,0]
 FR BND1      z[4,7,1]
 FR BND1      z[4,7,2]
 FR BND1      z[4,7,3]
 FR BND1      z[4,7,4]
 FR BND1      z[4,7,5]
 FR BND1      z[4,7,6]
 FR BND1      z[7,4,0]
 FR BND1      z[7,4,1]
 FR BND1      z[7,4,2]
 FR BND1      z[7,4,3]
 FR BND1      z[7,4,4]
 FR BND1      z[7,4,5]
 FR BND1      z[7,4,6]
 FR BND1      z[5,6,0]
 FR BND1      z[5,6,1]
 FR BND1      z[5,6,2]
 FR BND1      z[5,6,3]
 FR BND1      z[5,6,4]
 FR BND1      z[5,6,5]
 FR BND1      z[5,6,6]
 FR BND1      z[6,5,0]
 FR BND1      z[6,5,1]
 FR BND1      z[6,5,2]
 FR BND1      z[6,5,3]
 FR BND1      z[6,5,4]
 FR BND1      z[6,5,5]
 FR BND1      z[6,5,6]
 FR BND1      z[6,7,0]
 FR BND1      z[6,7,1]
 FR BND1      z[6,7,2]
 FR BND1      z[6,7,3]
 FR BND1      z[6,7,4]
 FR BND1      z[6,7,5]
 FR BND1      z[6,7,6]
 FR BND1      z[7,6,0]
 FR BND1      z[7,6,1]
 FR BND1      z[7,6,2]
 FR BND1      z[7,6,3]
 FR BND1      z[7,6,4]
 FR BND1      z[7,6,5]
 FR BND1      z[7,6,6]
 FR BND1      delta[0,0]
 FR BND1      delta[0,1]
 FR BND1      delta[0,2]
 FR BND1      delta[0,3]
 FR BND1      delta[0,4]
 FR BND1      delta[0,5]
 FR BND1      delta[0,6]
 FR BND1      delta[1,0]
 FR BND1      delta[1,1]
 FR BND1      delta[1,2]
 FR BND1      delta[1,3]
 FR BND1      delta[1,4]
 FR BND1      delta[1,5]
 FR BND1      delta[1,6]
 FR BND1      delta[2,0]
 FR BND1      delta[2,1]
 FR BND1      delta[2,2]
 FR BND1      delta[2,3]
 FR BND1      delta[2,4]
 FR BND1      delta[2,5]
 FR BND1      delta[2,6]
 FR BND1      delta[3,0]
 FR BND1      delta[3,1]
 FR BND1      delta[3,2]
 FR BND1      delta[3,3]
 FR BND1      delta[3,4]
 FR BND1      delta[3,5]
 FR BND1      delta[3,6]
 FR BND1      delta[4,0]
 FR BND1      delta[4,1]
 FR BND1      delta[4,2]
 FR BND1      delta[4,3]
 FR BND1      delta[4,4]
 FR BND1      delta[4,5]
 FR BND1      delta[4,6]
 FR BND1      delta[5,0]
 FR BND1      delta[5,1]
 FR BND1      delta[5,2]
 FR BND1      delta[5,3]
 FR BND1      delta[5,4]
 FR BND1      delta[5,5]
 FR BND1      delta[5,6]
 FR BND1      delta[6,0]
 FR BND1      delta[6,1]
 FR BND1      delta[6,2]
 FR BND1      delta[6,3]
 FR BND1      delta[6,4]
 FR BND1      delta[6,5]
 FR BND1      delta[6,6]
 FR BND1      delta[7,0]
 FR BND1      delta[7,1]
 FR BND1      delta[7,2]
 FR BND1      delta[7,3]
 FR BND1      delta[7,4]
 FR BND1      delta[7,5]
 FR BND1      delta[7,6]
QCMATRIX   qc0     
    length[0]  length[0]  -1
    delta[0,0]  delta[0,0]  1
    delta[0,1]  delta[0,1]  1
    delta[0,2]  delta[0,2]  1
    delta[0,3]  delta[0,3]  1
    delta[0,4]  delta[0,4]  1
    delta[0,5]  delta[0,5]  1
    delta[0,6]  delta[0,6]  1
QCMATRIX   qc1     
    length[1]  length[1]  -1
    delta[1,0]  delta[1,0]  1
    delta[1,1]  delta[1,1]  1
    delta[1,2]  delta[1,2]  1
    delta[1,3]  delta[1,3]  1
    delta[1,4]  delta[1,4]  1
    delta[1,5]  delta[1,5]  1
    delta[1,6]  delta[1,6]  1
QCMATRIX   qc2     
    length[2]  length[2]  -1
    delta[2,0]  delta[2,0]  1
    delta[2,1]  delta[2,1]  1
    delta[2,2]  delta[2,2]  1
    delta[2,3]  delta[2,3]  1
    delta[2,4]  delta[2,4]  1
    delta[2,5]  delta[2,5]  1
    delta[2,6]  delta[2,6]  1
QCMATRIX   qc3     
    length[3]  length[3]  -1
    delta[3,0]  delta[3,0]  1
    delta[3,1]  delta[3,1]  1
    delta[3,2]  delta[3,2]  1
    delta[3,3]  delta[3,3]  1
    delta[3,4]  delta[3,4]  1
    delta[3,5]  delta[3,5]  1
    delta[3,6]  delta[3,6]  1
QCMATRIX   qc4     
    length[4]  length[4]  -1
    delta[4,0]  delta[4,0]  1
    delta[4,1]  delta[4,1]  1
    delta[4,2]  delta[4,2]  1
    delta[4,3]  delta[4,3]  1
    delta[4,4]  delta[4,4]  1
    delta[4,5]  delta[4,5]  1
    delta[4,6]  delta[4,6]  1
QCMATRIX   qc5     
    length[5]  length[5]  -1
    delta[5,0]  delta[5,0]  1
    delta[5,1]  delta[5,1]  1
    delta[5,2]  delta[5,2]  1
    delta[5,3]  delta[5,3]  1
    delta[5,4]  delta[5,4]  1
    delta[5,5]  delta[5,5]  1
    delta[5,6]  delta[5,6]  1
QCMATRIX   qc6     
    length[6]  length[6]  -1
    delta[6,0]  delta[6,0]  1
    delta[6,1]  delta[6,1]  1
    delta[6,2]  delta[6,2]  1
    delta[6,3]  delta[6,3]  1
    delta[6,4]  delta[6,4]  1
    delta[6,5]  delta[6,5]  1
    delta[6,6]  delta[6,6]  1
QCMATRIX   qc7     
    length[7]  length[7]  -1
    delta[7,0]  delta[7,0]  1
    delta[7,1]  delta[7,1]  1
    delta[7,2]  delta[7,2]  1
    delta[7,3]  delta[7,3]  1
    delta[7,4]  delta[7,4]  1
    delta[7,5]  delta[7,5]  1
    delta[7,6]  delta[7,6]  1
ENDATA
