NAME LGCS_GCS_Eq5_5_projected
ROWS
 N  OBJ
 E  R0      
 L  R1      
 E  R2      
 E  R3      
 E  R4      
 E  R5      
 E  R6      
 E  R7      
 E  R8      
 E  R9      
 L  R10     
 E  R11     
 E  R12     
 E  R13     
 E  R14     
 E  R15     
 E  R16     
 E  R17     
 E  R18     
 L  R19     
 E  R20     
 E  R21     
 E  R22     
 E  R23     
 E  R24     
 E  R25     
 E  R26     
 E  R27     
 L  R28     
 E  R29     
 E  R30     
 E  R31     
 E  R32     
 E  R33     
 E  R34     
 E  R35     
 E  R36     
 L  R37     
 E  R38     
 E  R39     
 E  R40     
 E  R41     
 E  R42     
 E  R43     
 E  R44     
 E  R45     
 L  R46     
 E  R47     
 E  R48     
 E  R49     
 E  R50     
 E  R51     
 E  R52     
 E  R53     
 E  R54     
 L  R55     
 E  R56     
 E  R57     
 E  R58     
 E  R59     
 E  R60     
 E  R61     
 E  R62     
 E  R63     
 L  R64     
 E  R65     
 E  R66     
 E  R67     
 E  R68     
 E  R69     
 E  R70     
 E  R71     
 E  R72     
 L  R73     
 E  R74     
 E  R75     
 E  R76     
 E  R77     
 E  R78     
 E  R79     
 E  R80     
 E  R81     
 E  R82     
 L  R83     
 L  R84     
 L  R85     
 L  R86     
 L  R87     
 L  R88     
 L  R89     
 L  R90     
 L  R91     
 L  R92     
 L  R93     
 L  R94     
 L  R95     
 L  R96     
 L  R97     
 L  R98     
 L  R99     
 L  R100    
 L  R101    
 L  R102    
 L  R103    
 L  R104    
 L  R105    
 L  R106    
 L  R107    
 L  R108    
 L  R109    
 L  R110    
 L  R111    
 L  R112    
 L  R113    
 L  R114    
 L  R115    
 L  R116    
 L  R117    
 L  R118    
 L  R119    
 L  R120    
 L  R121    
 L  R122    
 L  R123    
 L  R124    
 L  R125    
 L  R126    
 L  R127    
 L  R128    
 L  R129    
 L  R130    
 L  R131    
 L  R132    
 L  R133    
 L  R134    
 L  R135    
 L  R136    
 L  R137    
 L  R138    
 L  R139    
 L  R140    
 L  R141    
 L  R142    
 L  R143    
 L  R144    
 L  R145    
 L  R146    
 L  R147    
 L  R148    
 L  R149    
 L  R150    
 L  R151    
 L  R152    
 L  R153    
 L  R154    
 L  R155    
 L  R156    
 L  R157    
 L  R158    
 L  R159    
 L  R160    
 L  R161    
 L  R162    
 L  R163    
 L  R164    
 L  R165    
 L  R166    
 L  R167    
 L  R168    
 L  R169    
 L  R170    
 L  R171    
 L  R172    
 L  R173    
 L  R174    
 L  R175    
 L  R176    
 L  R177    
 L  R178    
 L  R179    
 L  R180    
 L  R181    
 L  R182    
 L  R183    
 L  R184    
 L  R185    
 L  R186    
 L  R187    
 L  R188    
 L  R189    
 L  R190    
 L  R191    
 L  R192    
 L  R193    
 L  R194    
 L  R195    
 L  R196    
 L  R197    
 L  R198    
 L  R199    
 L  R200    
 L  R201    
 L  R202    
 L  R203    
 L  R204    
 L  R205    
 L  R206    
 L  R207    
 L  R208    
 L  R209    
 L  R210    
 L  R211    
 L  R212    
 L  R213    
 L  R214    
 L  R215    
 L  R216    
 L  R217    
 L  R218    
 L  R219    
 L  R220    
 L  R221    
 L  R222    
 L  R223    
 L  R224    
 L  R225    
 L  R226    
 L  R227    
 L  R228    
 L  R229    
 L  R230    
 L  R231    
 L  R232    
 L  R233    
 L  R234    
 L  R235    
 L  R236    
 L  R237    
 L  R238    
 L  R239    
 L  R240    
 L  R241    
 L  R242    
 L  R243    
 L  R244    
 L  R245    
 L  R246    
 L  R247    
 L  R248    
 L  R249    
 L  R250    
 L  R251    
 L  R252    
 L  R253    
 L  R254    
 L  R255    
 L  R256    
 L  R257    
 L  R258    
 L  R259    
 L  R260    
 L  R261    
 L  R262    
 L  R263    
 L  R264    
 L  R265    
 L  R266    
 L  R267    
 L  R268    
 L  R269    
 L  R270    
 L  R271    
 L  R272    
 L  R273    
 L  R274    
 L  R275    
 L  R276    
 L  R277    
 L  R278    
 L  R279    
 L  R280    
 L  R281    
 L  R282    
 L  R283    
 L  R284    
 L  R285    
 L  R286    
 L  R287    
 L  R288    
 L  R289    
 L  R290    
 L  R291    
 L  R292    
 L  R293    
 L  R294    
 L  R295    
 L  R296    
 L  R297    
 L  R298    
 L  R299    
 L  R300    
 L  R301    
 L  R302    
 L  R303    
 L  R304    
 L  R305    
 L  R306    
 L  R307    
 L  R308    
 L  R309    
 L  R310    
 L  R311    
 L  R312    
 L  R313    
 L  R314    
 L  R315    
 L  R316    
 L  R317    
 L  R318    
 L  R319    
 L  R320    
 L  R321    
 L  R322    
 L  R323    
 L  R324    
 L  R325    
 L  R326    
 L  R327    
 L  R328    
 L  R329    
 L  R330    
 L  R331    
 L  R332    
 L  R333    
 L  R334    
 L  R335    
 L  R336    
 L  R337    
 L  R338    
 L  R339    
 L  R340    
 L  R341    
 L  R342    
 L  R343    
 L  R344    
 L  R345    
 L  R346    
 L  R347    
 L  R348    
 L  R349    
 L  R350    
 L  R351    
 L  R352    
 L  R353    
 L  R354    
 L  R355    
 L  R356    
 L  R357    
 L  R358    
 L  R359    
 L  R360    
 L  R361    
 L  R362    
 L  R363    
 L  R364    
 L  R365    
 L  R366    
 L  R367    
 L  R368    
 L  R369    
 L  R370    
 L  R371    
 L  R372    
 L  R373    
 L  R374    
 L  R375    
 L  R376    
 L  R377    
 L  R378    
 L  R379    
 L  R380    
 L  R381    
 L  R382    
 L  R383    
 L  R384    
 L  R385    
 L  R386    
 L  R387    
 L  R388    
 L  R389    
 L  R390    
 L  R391    
 L  R392    
 L  R393    
 L  R394    
 L  R395    
 L  R396    
 L  R397    
 L  R398    
 L  R399    
 L  R400    
 L  R401    
 L  R402    
 L  R403    
 L  R404    
 L  R405    
 L  R406    
 L  R407    
 L  R408    
 L  R409    
 L  R410    
 L  R411    
 L  R412    
 L  R413    
 L  R414    
 L  R415    
 L  R416    
 L  R417    
 L  R418    
 L  R419    
 L  R420    
 L  R421    
 L  R422    
 L  R423    
 L  R424    
 L  R425    
 L  R426    
 L  R427    
 L  R428    
 L  R429    
 L  R430    
 L  R431    
 L  R432    
 L  R433    
 L  R434    
 L  R435    
 L  R436    
 L  R437    
 L  R438    
 L  R439    
 L  R440    
 L  R441    
 L  R442    
 L  R443    
 L  R444    
 L  R445    
 L  R446    
 L  R447    
 L  R448    
 L  R449    
 L  R450    
 L  R451    
 L  R452    
 L  R453    
 L  R454    
 L  R455    
 L  R456    
 L  R457    
 L  R458    
 L  R459    
 L  R460    
 L  R461    
 L  R462    
 L  R463    
 L  R464    
 L  R465    
 L  R466    
 L  R467    
 L  R468    
 L  R469    
 L  R470    
 L  R471    
 L  R472    
 L  R473    
 L  R474    
 L  R475    
 L  R476    
 L  R477    
 L  R478    
 L  R479    
 L  R480    
 L  R481    
 L  R482    
 L  R483    
 L  R484    
 L  R485    
 L  R486    
 L  R487    
 L  R488    
 L  R489    
 L  R490    
 L  R491    
 L  R492    
 L  R493    
 L  R494    
 L  R495    
 L  R496    
 L  R497    
 L  R498    
 L  R499    
 L  R500    
 L  R501    
 L  R502    
 L  R503    
 L  R504    
 L  R505    
 L  R506    
 L  R507    
 L  R508    
 L  R509    
 L  R510    
 L  R511    
 L  R512    
 L  R513    
 L  R514    
 L  R515    
 L  R516    
 L  R517    
 L  R518    
 L  R519    
 L  R520    
 L  R521    
 L  R522    
 L  R523    
 L  R524    
 L  R525    
 L  R526    
 L  R527    
 L  R528    
 L  R529    
 L  R530    
 L  R531    
 L  R532    
 L  R533    
 L  R534    
 L  R535    
 L  R536    
 L  R537    
 L  R538    
 L  R539    
 L  R540    
 L  R541    
 L  R542    
 L  R543    
 L  R544    
 L  R545    
 L  R546    
 L  R547    
 L  R548    
 L  R549    
 L  R550    
 L  R551    
 L  R552    
 L  R553    
 L  R554    
 L  R555    
 L  R556    
 L  R557    
 L  R558    
 L  R559    
 L  R560    
 L  R561    
 L  R562    
 L  R563    
 L  R564    
 L  R565    
 L  R566    
 L  R567    
 L  R568    
 L  R569    
 L  R570    
 L  R571    
 L  R572    
 L  R573    
 L  R574    
 L  R575    
 L  R576    
 L  R577    
 L  R578    
 L  R579    
 L  R580    
 L  R581    
 L  R582    
 L  R583    
 L  R584    
 L  R585    
 L  R586    
 L  R587    
 L  R588    
 L  R589    
 L  R590    
 L  R591    
 L  R592    
 L  R593    
 L  R594    
 L  R595    
 L  R596    
 L  R597    
 L  R598    
 L  R599    
 L  R600    
 L  R601    
 L  R602    
 L  R603    
 L  R604    
 L  R605    
 L  R606    
 L  R607    
 L  R608    
 L  R609    
 L  R610    
 L  R611    
 L  R612    
 L  R613    
 L  R614    
 L  R615    
 L  R616    
 L  R617    
 L  R618    
 L  R619    
 L  R620    
 L  R621    
 L  R622    
 L  R623    
 L  R624    
 L  R625    
 L  R626    
 L  R627    
 L  R628    
 L  R629    
 L  R630    
 L  R631    
 L  R632    
 L  R633    
 L  R634    
 L  R635    
 L  R636    
 L  R637    
 L  R638    
 L  R639    
 L  R640    
 L  R641    
 L  R642    
 L  R643    
 L  R644    
 L  R645    
 L  R646    
 L  R647    
 L  R648    
 L  R649    
 L  R650    
 L  R651    
 L  R652    
 L  R653    
 L  R654    
 L  R655    
 L  R656    
 L  R657    
 L  R658    
 L  R659    
 L  R660    
 L  R661    
 L  R662    
 L  R663    
 L  R664    
 L  R665    
 L  R666    
 L  R667    
 L  R668    
 L  R669    
 L  R670    
 L  R671    
 L  R672    
 L  R673    
 L  R674    
 L  R675    
 L  R676    
 L  R677    
 L  R678    
 L  R679    
 L  R680    
 L  R681    
 L  R682    
 L  R683    
 L  R684    
 L  R685    
 L  R686    
 L  R687    
 L  R688    
 L  R689    
 L  R690    
 L  R691    
 L  R692    
 L  R693    
 L  R694    
 L  R695    
 L  R696    
 L  R697    
 L  R698    
 L  R699    
 L  R700    
 L  R701    
 L  R702    
 L  R703    
 L  R704    
 L  R705    
 L  R706    
 L  R707    
 L  R708    
 L  R709    
 L  R710    
 L  R711    
 L  R712    
 L  R713    
 L  R714    
 L  R715    
 L  R716    
 L  R717    
 L  R718    
 L  R719    
 L  R720    
 L  R721    
 L  R722    
 L  R723    
 L  R724    
 L  R725    
 L  R726    
 L  R727    
 L  R728    
 L  R729    
 L  R730    
 L  R731    
 L  R732    
 L  R733    
 L  R734    
 L  R735    
 L  R736    
 L  R737    
 L  R738    
 L  R739    
 L  R740    
 L  R741    
 L  R742    
 L  R743    
 L  R744    
 L  R745    
 L  R746    
 L  R747    
 L  R748    
 L  R749    
 L  R750    
 L  R751    
 L  R752    
 L  R753    
 L  R754    
 L  R755    
 L  R756    
 L  R757    
 L  R758    
 L  R759    
 L  R760    
 L  R761    
 L  R762    
 L  R763    
 L  R764    
 L  R765    
 L  R766    
 L  R767    
 L  R768    
 L  R769    
 L  R770    
 L  R771    
 L  R772    
 L  R773    
 L  R774    
 L  R775    
 L  R776    
 L  R777    
 L  R778    
 L  R779    
 L  R780    
 L  R781    
 L  R782    
 L  R783    
 L  R784    
 L  R785    
 L  R786    
 L  R787    
 L  R788    
 L  R789    
 L  R790    
 L  R791    
 L  R792    
 L  R793    
 L  R794    
 L  R795    
 L  R796    
 L  R797    
 L  R798    
 L  R799    
 L  R800    
 L  R801    
 L  R802    
 L  R803    
 L  R804    
 L  R805    
 L  R806    
 L  R807    
 L  R808    
 L  R809    
 L  R810    
 L  R811    
 L  R812    
 L  R813    
 L  R814    
 L  R815    
 L  R816    
 L  R817    
 L  R818    
 L  R819    
 L  R820    
 L  R821    
 L  R822    
 L  R823    
 L  R824    
 L  R825    
 L  R826    
 L  R827    
 L  R828    
 L  R829    
 L  R830    
 L  R831    
 L  R832    
 L  R833    
 L  R834    
 L  R835    
 L  R836    
 L  R837    
 L  R838    
 L  R839    
 L  R840    
 L  R841    
 L  R842    
 L  R843    
 L  R844    
 L  R845    
 L  R846    
 L  R847    
 L  R848    
 L  R849    
 L  R850    
 L  R851    
 L  R852    
 L  R853    
 L  R854    
 L  R855    
 L  R856    
 L  R857    
 L  R858    
 L  R859    
 L  R860    
 L  R861    
 L  R862    
 L  R863    
 L  R864    
 L  R865    
 L  R866    
 L  R867    
 L  R868    
 L  R869    
 L  R870    
 L  R871    
 L  R872    
 L  R873    
 L  R874    
 L  R875    
 L  R876    
 L  R877    
 L  R878    
 L  R879    
 L  R880    
 L  R881    
 L  R882    
 L  R883    
 L  R884    
 L  R885    
 L  R886    
 L  R887    
 L  R888    
 L  R889    
 L  R890    
 L  R891    
 L  R892    
 L  R893    
 L  R894    
 L  R895    
 L  R896    
 L  R897    
 L  R898    
 L  R899    
 L  R900    
 L  R901    
 L  R902    
 L  R903    
 L  R904    
 L  R905    
 L  R906    
 L  R907    
 L  R908    
 L  R909    
 L  R910    
 L  R911    
 L  R912    
 L  R913    
 L  R914    
 L  R915    
 L  R916    
 L  R917    
 L  R918    
 L  R919    
 L  R920    
 L  R921    
 L  R922    
 L  R923    
 L  R924    
 L  R925    
 L  R926    
 L  R927    
 L  R928    
 L  R929    
 L  R930    
 L  R931    
 L  R932    
 L  R933    
 L  R934    
 L  R935    
 L  R936    
 L  R937    
 L  R938    
 L  R939    
 L  R940    
 L  R941    
 L  R942    
 L  R943    
 L  R944    
 L  R945    
 L  R946    
 L  R947    
 L  R948    
 L  R949    
 L  R950    
 L  R951    
 L  R952    
 L  R953    
 L  R954    
 L  R955    
 L  R956    
 L  R957    
 L  R958    
 L  R959    
 L  R960    
 L  R961    
 L  R962    
 L  R963    
 L  R964    
 L  R965    
 L  R966    
 L  R967    
 L  R968    
 L  R969    
 L  R970    
 L  R971    
 L  R972    
 L  R973    
 L  R974    
 L  R975    
 L  R976    
 L  R977    
 L  R978    
 L  R979    
 L  R980    
 L  R981    
 L  R982    
 L  R983    
 L  R984    
 L  R985    
 L  R986    
 L  R987    
 L  R988    
 L  R989    
 L  R990    
 L  R991    
 L  R992    
 L  R993    
 L  R994    
 L  R995    
 L  R996    
 L  R997    
 L  R998    
 L  R999    
 L  R1000   
 L  R1001   
 L  R1002   
 L  R1003   
 L  R1004   
 L  R1005   
 L  R1006   
 L  R1007   
 L  R1008   
 L  R1009   
 L  R1010   
 L  R1011   
 L  R1012   
 L  R1013   
 L  R1014   
 L  R1015   
 L  R1016   
 L  R1017   
 L  R1018   
 L  R1019   
 L  R1020   
 L  R1021   
 L  R1022   
 L  R1023   
 L  R1024   
 L  R1025   
 L  R1026   
 L  R1027   
 L  R1028   
 L  R1029   
 L  R1030   
 L  R1031   
 L  R1032   
 L  R1033   
 L  R1034   
 L  R1035   
 L  R1036   
 L  R1037   
 L  R1038   
 L  R1039   
 L  R1040   
 L  R1041   
 L  R1042   
 L  R1043   
 L  R1044   
 L  R1045   
 L  R1046   
 L  R1047   
 L  R1048   
 L  R1049   
 L  R1050   
 L  R1051   
 L  R1052   
 L  R1053   
 L  R1054   
 L  R1055   
 L  R1056   
 L  R1057   
 L  R1058   
 L  R1059   
 L  R1060   
 L  R1061   
 L  R1062   
 L  R1063   
 L  R1064   
 L  R1065   
 L  R1066   
 L  R1067   
 L  R1068   
 L  R1069   
 L  R1070   
 L  R1071   
 L  R1072   
 L  R1073   
 L  R1074   
 L  R1075   
 L  R1076   
 L  R1077   
 L  R1078   
 L  R1079   
 L  R1080   
 L  R1081   
 L  R1082   
 L  R1083   
 L  R1084   
 L  R1085   
 L  R1086   
 L  R1087   
 L  R1088   
 L  R1089   
 L  R1090   
 L  R1091   
 L  R1092   
 L  R1093   
 L  R1094   
 L  R1095   
 L  R1096   
 L  R1097   
 L  R1098   
 L  R1099   
 L  R1100   
 L  R1101   
 L  R1102   
 L  R1103   
 L  R1104   
 L  R1105   
 L  R1106   
 L  R1107   
 L  R1108   
 L  R1109   
 L  R1110   
 L  R1111   
 L  R1112   
 L  R1113   
 L  R1114   
 L  R1115   
 L  R1116   
 L  R1117   
 L  R1118   
 L  R1119   
 L  R1120   
 L  R1121   
 L  R1122   
 L  R1123   
 L  R1124   
 L  R1125   
 L  R1126   
 L  R1127   
 L  R1128   
 L  R1129   
 L  R1130   
 L  R1131   
 L  R1132   
 L  R1133   
 L  R1134   
 L  R1135   
 L  R1136   
 L  R1137   
 L  R1138   
 L  R1139   
 L  R1140   
 L  R1141   
 L  R1142   
 L  R1143   
 L  R1144   
 L  R1145   
 L  R1146   
 L  R1147   
 L  R1148   
 L  R1149   
 L  R1150   
 L  R1151   
 L  R1152   
 L  R1153   
 L  R1154   
 L  R1155   
 L  R1156   
 L  R1157   
 L  R1158   
 L  R1159   
 L  R1160   
 L  R1161   
 L  R1162   
 L  R1163   
 L  R1164   
 L  R1165   
 L  R1166   
 L  R1167   
 L  R1168   
 L  R1169   
 L  R1170   
 L  R1171   
 L  R1172   
 L  R1173   
 L  R1174   
 L  R1175   
 L  R1176   
 L  R1177   
 L  R1178   
 L  R1179   
 L  R1180   
 L  R1181   
 L  R1182   
 L  R1183   
 L  R1184   
 L  R1185   
 L  R1186   
 L  R1187   
 L  R1188   
 L  R1189   
 L  R1190   
 L  R1191   
 L  R1192   
 L  R1193   
 L  R1194   
 L  R1195   
 L  R1196   
 L  R1197   
 L  R1198   
 L  R1199   
 L  R1200   
 L  R1201   
 L  R1202   
 L  R1203   
 L  R1204   
 L  R1205   
 L  R1206   
 L  R1207   
 L  R1208   
 L  R1209   
 L  R1210   
 L  R1211   
 L  R1212   
 L  R1213   
 L  R1214   
 L  R1215   
 L  R1216   
 L  R1217   
 L  R1218   
 L  R1219   
 L  R1220   
 L  R1221   
 L  R1222   
 L  R1223   
 L  R1224   
 L  R1225   
 L  R1226   
 L  R1227   
 L  R1228   
 L  R1229   
 L  R1230   
 L  R1231   
 L  R1232   
 L  R1233   
 L  R1234   
 L  R1235   
 L  R1236   
 L  R1237   
 L  R1238   
 L  R1239   
 L  R1240   
 L  R1241   
 L  R1242   
 L  R1243   
 L  R1244   
 L  R1245   
 L  R1246   
 L  R1247   
 L  R1248   
 L  R1249   
 L  R1250   
 L  R1251   
 L  R1252   
 L  R1253   
 L  R1254   
 L  R1255   
 L  R1256   
 L  R1257   
 L  R1258   
 L  R1259   
 L  R1260   
 L  R1261   
 L  R1262   
 L  R1263   
 L  R1264   
 L  R1265   
 L  R1266   
 L  R1267   
 L  R1268   
 L  R1269   
 L  R1270   
 L  R1271   
 L  R1272   
 L  R1273   
 L  R1274   
 L  R1275   
 L  R1276   
 L  R1277   
 L  R1278   
 L  R1279   
 L  R1280   
 L  R1281   
 L  R1282   
 L  R1283   
 L  R1284   
 L  R1285   
 L  R1286   
 L  R1287   
 L  R1288   
 L  R1289   
 L  R1290   
 L  R1291   
 L  R1292   
 L  R1293   
 L  R1294   
 L  R1295   
 L  R1296   
 L  R1297   
 L  R1298   
 L  R1299   
 L  R1300   
 L  R1301   
 L  R1302   
 L  R1303   
 L  R1304   
 L  R1305   
 L  R1306   
 L  R1307   
 L  R1308   
 L  R1309   
 L  R1310   
 L  R1311   
 L  R1312   
 L  R1313   
 L  R1314   
 L  R1315   
 L  R1316   
 L  R1317   
 L  R1318   
 L  R1319   
 L  R1320   
 L  R1321   
 L  R1322   
 L  R1323   
 L  R1324   
 L  R1325   
 L  R1326   
 L  R1327   
 L  R1328   
 L  R1329   
 L  R1330   
 L  R1331   
 L  R1332   
 L  R1333   
 L  R1334   
 L  R1335   
 L  R1336   
 L  R1337   
 L  R1338   
 L  R1339   
 L  R1340   
 L  R1341   
 L  R1342   
 L  R1343   
 L  R1344   
 L  R1345   
 L  R1346   
 L  R1347   
 L  R1348   
 L  R1349   
 L  R1350   
 L  R1351   
 L  R1352   
 L  R1353   
 L  R1354   
 L  R1355   
 L  R1356   
 L  R1357   
 L  R1358   
 L  R1359   
 L  R1360   
 L  R1361   
 L  R1362   
 L  R1363   
 L  R1364   
 L  R1365   
 L  R1366   
 L  R1367   
 L  R1368   
 L  R1369   
 L  R1370   
 L  R1371   
 L  R1372   
 L  R1373   
 L  R1374   
 L  R1375   
 L  R1376   
 L  R1377   
 L  R1378   
 L  R1379   
 L  R1380   
 L  R1381   
 L  R1382   
 L  R1383   
 L  R1384   
 L  R1385   
 L  R1386   
 L  R1387   
 L  R1388   
 L  R1389   
 L  R1390   
 L  R1391   
 L  R1392   
 L  R1393   
 L  R1394   
 L  R1395   
 L  R1396   
 L  R1397   
 L  R1398   
 L  R1399   
 L  R1400   
 L  R1401   
 L  R1402   
 L  R1403   
 L  R1404   
 L  R1405   
 L  R1406   
 L  R1407   
 L  R1408   
 L  R1409   
 L  R1410   
 L  R1411   
 L  R1412   
 L  R1413   
 L  R1414   
 L  R1415   
 L  R1416   
 L  R1417   
 L  R1418   
 L  R1419   
 L  R1420   
 L  R1421   
 L  R1422   
 L  R1423   
 L  R1424   
 L  R1425   
 L  R1426   
 L  R1427   
 L  R1428   
 L  R1429   
 L  R1430   
 L  R1431   
 L  R1432   
 L  R1433   
 L  R1434   
 L  R1435   
 L  R1436   
 L  R1437   
 L  R1438   
 L  R1439   
 L  R1440   
 L  R1441   
 L  R1442   
 L  R1443   
 L  R1444   
 L  R1445   
 L  R1446   
 L  R1447   
 L  R1448   
 L  R1449   
 L  R1450   
 L  R1451   
 L  R1452   
 L  R1453   
 L  R1454   
 L  R1455   
 L  R1456   
 L  R1457   
 L  R1458   
 L  R1459   
 L  R1460   
 L  R1461   
 L  R1462   
 L  R1463   
 L  R1464   
 L  R1465   
 L  R1466   
 L  R1467   
 L  R1468   
 L  R1469   
 L  R1470   
 L  R1471   
 L  R1472   
 L  R1473   
 L  R1474   
 L  R1475   
 L  R1476   
 L  R1477   
 L  R1478   
 L  R1479   
 L  R1480   
 L  R1481   
 L  R1482   
 L  R1483   
 L  R1484   
 L  R1485   
 L  R1486   
 L  R1487   
 L  R1488   
 L  R1489   
 L  R1490   
 L  R1491   
 L  R1492   
 L  R1493   
 L  R1494   
 L  R1495   
 L  R1496   
 L  R1497   
 L  R1498   
 L  R1499   
 L  R1500   
 L  R1501   
 L  R1502   
 L  R1503   
 L  R1504   
 L  R1505   
 L  R1506   
 L  R1507   
 L  R1508   
 L  R1509   
 L  R1510   
 L  R1511   
 L  R1512   
 L  R1513   
 L  R1514   
 L  R1515   
 L  R1516   
 L  R1517   
 L  R1518   
 L  R1519   
 L  R1520   
 L  R1521   
 L  R1522   
 L  R1523   
 L  R1524   
 L  R1525   
 L  R1526   
 L  R1527   
 L  R1528   
 L  R1529   
 L  R1530   
 L  R1531   
 L  R1532   
 L  R1533   
 L  R1534   
 L  R1535   
 L  R1536   
 L  R1537   
 L  R1538   
 L  R1539   
 L  R1540   
 L  R1541   
 L  R1542   
 L  R1543   
 L  R1544   
 L  R1545   
 L  R1546   
 L  R1547   
 L  R1548   
 L  R1549   
 L  R1550   
 L  R1551   
 L  R1552   
 L  R1553   
 L  R1554   
 L  R1555   
 L  R1556   
 L  R1557   
 L  R1558   
 L  R1559   
 L  R1560   
 L  R1561   
 L  R1562   
 L  R1563   
 L  R1564   
 L  R1565   
 L  R1566   
 L  R1567   
 L  R1568   
 L  R1569   
 L  R1570   
 L  R1571   
 L  R1572   
 L  R1573   
 L  R1574   
 L  R1575   
 L  R1576   
 L  R1577   
 L  R1578   
 L  R1579   
 L  R1580   
 L  R1581   
 L  R1582   
 L  R1583   
 L  R1584   
 L  R1585   
 L  R1586   
 L  R1587   
 L  R1588   
 L  R1589   
 L  R1590   
 L  R1591   
 L  R1592   
 L  R1593   
 L  R1594   
 L  R1595   
 L  R1596   
 L  R1597   
 L  R1598   
 L  R1599   
 L  R1600   
 L  R1601   
 L  R1602   
 L  R1603   
 L  R1604   
 L  R1605   
 L  R1606   
 L  R1607   
 L  R1608   
 L  R1609   
 L  R1610   
 L  R1611   
 L  R1612   
 L  R1613   
 L  R1614   
 L  R1615   
 L  R1616   
 L  R1617   
 L  R1618   
 L  R1619   
 L  R1620   
 L  R1621   
 L  R1622   
 L  R1623   
 L  R1624   
 L  R1625   
 L  R1626   
 L  R1627   
 L  R1628   
 L  R1629   
 L  R1630   
 L  R1631   
 L  R1632   
 L  R1633   
 L  R1634   
 L  R1635   
 L  R1636   
 L  R1637   
 L  R1638   
 L  R1639   
 L  R1640   
 L  R1641   
 L  R1642   
 L  R1643   
 L  R1644   
 L  R1645   
 L  R1646   
 L  R1647   
 L  R1648   
 L  R1649   
 L  R1650   
 L  R1651   
 L  R1652   
 L  R1653   
 L  R1654   
 L  R1655   
 L  R1656   
 L  R1657   
 L  R1658   
 L  R1659   
 L  R1660   
 L  R1661   
 L  R1662   
 L  R1663   
 L  R1664   
 L  R1665   
 L  R1666   
 L  R1667   
 L  R1668   
 L  R1669   
 L  R1670   
 L  R1671   
 L  R1672   
 L  R1673   
 L  R1674   
 L  R1675   
 L  R1676   
 L  R1677   
 L  R1678   
 L  R1679   
 L  R1680   
 L  R1681   
 L  R1682   
 L  R1683   
 L  R1684   
 L  R1685   
 L  R1686   
 L  R1687   
 L  R1688   
 L  R1689   
 L  R1690   
 L  R1691   
 L  R1692   
 L  R1693   
 L  R1694   
 L  R1695   
 L  R1696   
 L  R1697   
 L  R1698   
 L  R1699   
 L  R1700   
 L  R1701   
 L  R1702   
 L  R1703   
 L  R1704   
 L  R1705   
 L  R1706   
 L  R1707   
 L  R1708   
 L  R1709   
 L  R1710   
 L  R1711   
 L  R1712   
 L  R1713   
 L  R1714   
 L  R1715   
 L  R1716   
 L  R1717   
 L  R1718   
 L  R1719   
 L  R1720   
 L  R1721   
 L  R1722   
 L  R1723   
 L  R1724   
 L  R1725   
 L  R1726   
 L  R1727   
 L  R1728   
 L  R1729   
 L  R1730   
 L  R1731   
 L  R1732   
 L  R1733   
 L  R1734   
 L  R1735   
 L  R1736   
 L  R1737   
 L  R1738   
 L  R1739   
 L  R1740   
 L  R1741   
 L  R1742   
 L  R1743   
 L  R1744   
 L  R1745   
 L  R1746   
 L  R1747   
 L  R1748   
 L  R1749   
 L  R1750   
 L  R1751   
 L  R1752   
 L  R1753   
 L  R1754   
 L  R1755   
 L  R1756   
 L  R1757   
 L  R1758   
 L  R1759   
 L  R1760   
 L  R1761   
 L  R1762   
 L  R1763   
 L  R1764   
 L  R1765   
 L  R1766   
 L  R1767   
 L  R1768   
 L  R1769   
 L  R1770   
 L  R1771   
 L  R1772   
 L  R1773   
 L  R1774   
 L  R1775   
 L  R1776   
 L  R1777   
 L  R1778   
 L  R1779   
 L  R1780   
 L  R1781   
 L  R1782   
 L  R1783   
 L  R1784   
 L  R1785   
 L  R1786   
 L  R1787   
 L  R1788   
 L  R1789   
 L  R1790   
 L  R1791   
 L  R1792   
 L  R1793   
 L  R1794   
 L  R1795   
 L  R1796   
 L  R1797   
 L  R1798   
 L  R1799   
 L  R1800   
 L  R1801   
 L  R1802   
 L  R1803   
 L  R1804   
 L  R1805   
 L  R1806   
 L  R1807   
 L  R1808   
 L  R1809   
 L  R1810   
 L  R1811   
 L  R1812   
 L  R1813   
 L  R1814   
 L  R1815   
 L  R1816   
 L  R1817   
 L  R1818   
 L  R1819   
 L  R1820   
 L  R1821   
 L  R1822   
 L  R1823   
 L  R1824   
 L  R1825   
 L  R1826   
 L  R1827   
 L  R1828   
 L  R1829   
 L  R1830   
 L  R1831   
 L  R1832   
 L  R1833   
 L  R1834   
 L  R1835   
 L  R1836   
 L  R1837   
 L  R1838   
 L  R1839   
 L  R1840   
 L  R1841   
 L  R1842   
 L  R1843   
 L  R1844   
 L  R1845   
 L  R1846   
 L  R1847   
 L  R1848   
 L  R1849   
 L  R1850   
 L  R1851   
 L  R1852   
 L  R1853   
 L  R1854   
 L  R1855   
 L  R1856   
 L  R1857   
 L  R1858   
 L  R1859   
 L  R1860   
 L  R1861   
 L  R1862   
 L  R1863   
 L  R1864   
 L  R1865   
 L  R1866   
 L  R1867   
 L  R1868   
 L  R1869   
 L  R1870   
 L  R1871   
 L  R1872   
 L  R1873   
 L  R1874   
 L  R1875   
 L  R1876   
 L  R1877   
 L  R1878   
 L  R1879   
 L  R1880   
 L  R1881   
 L  R1882   
 L  R1883   
 L  R1884   
 L  R1885   
 L  R1886   
 L  R1887   
 L  R1888   
 L  R1889   
 L  R1890   
 L  R1891   
 L  R1892   
 L  R1893   
 L  R1894   
 L  R1895   
 L  R1896   
 L  R1897   
 L  R1898   
 L  R1899   
 L  R1900   
 L  R1901   
 L  R1902   
 L  R1903   
 L  R1904   
 L  R1905   
 L  R1906   
 L  R1907   
 L  R1908   
 L  R1909   
 L  R1910   
 L  R1911   
 L  R1912   
 L  R1913   
 L  R1914   
 L  R1915   
 L  R1916   
 L  R1917   
 L  R1918   
 L  R1919   
 L  R1920   
 L  R1921   
 L  R1922   
 L  R1923   
 L  R1924   
 L  R1925   
 L  R1926   
 L  R1927   
 L  R1928   
 L  R1929   
 L  R1930   
 L  R1931   
 L  R1932   
 L  R1933   
 L  R1934   
 L  R1935   
 L  R1936   
 L  R1937   
 L  R1938   
 L  R1939   
 L  R1940   
 L  R1941   
 L  R1942   
 L  R1943   
 L  R1944   
 L  R1945   
 L  R1946   
 L  R1947   
 L  R1948   
 L  R1949   
 L  R1950   
 L  R1951   
 L  R1952   
 L  R1953   
 L  R1954   
 L  R1955   
 L  R1956   
 L  R1957   
 L  R1958   
 L  R1959   
 L  R1960   
 L  R1961   
 L  R1962   
 L  R1963   
 L  R1964   
 L  R1965   
 L  R1966   
 L  R1967   
 L  R1968   
 L  R1969   
 L  R1970   
 L  R1971   
 L  R1972   
 L  R1973   
 L  R1974   
 L  R1975   
 L  R1976   
 L  R1977   
 L  R1978   
 L  R1979   
 L  R1980   
 L  R1981   
 L  R1982   
 L  R1983   
 L  R1984   
 L  R1985   
 L  R1986   
 L  R1987   
 L  R1988   
 L  R1989   
 L  R1990   
 L  R1991   
 L  R1992   
 L  R1993   
 L  R1994   
 L  R1995   
 L  R1996   
 L  R1997   
 L  R1998   
 L  R1999   
 L  R2000   
 L  R2001   
 L  R2002   
 L  R2003   
 L  R2004   
 L  R2005   
 L  R2006   
 L  R2007   
 L  R2008   
 L  R2009   
 L  R2010   
 L  R2011   
 L  R2012   
 L  R2013   
 L  R2014   
 L  R2015   
 L  R2016   
 L  R2017   
 L  R2018   
 L  R2019   
 L  R2020   
 L  R2021   
 L  R2022   
 L  R2023   
 L  R2024   
 L  R2025   
 L  R2026   
 L  R2027   
 L  R2028   
 L  R2029   
 L  R2030   
 L  R2031   
 L  R2032   
 L  R2033   
 L  R2034   
 L  R2035   
 L  R2036   
 L  R2037   
 L  R2038   
 L  R2039   
 L  R2040   
 L  R2041   
 L  R2042   
 L  R2043   
 L  R2044   
 L  R2045   
 L  R2046   
 L  R2047   
 L  R2048   
 L  R2049   
 L  R2050   
 L  R2051   
 L  R2052   
 L  R2053   
 L  R2054   
 L  R2055   
 L  R2056   
 L  R2057   
 L  R2058   
 L  R2059   
 L  R2060   
 L  R2061   
 L  R2062   
 L  R2063   
 L  R2064   
 L  R2065   
 L  R2066   
 L  R2067   
 L  R2068   
 L  R2069   
 L  R2070   
 L  R2071   
 L  R2072   
 L  R2073   
 L  R2074   
 L  R2075   
 L  R2076   
 L  R2077   
 L  R2078   
 L  R2079   
 L  R2080   
 L  R2081   
 L  R2082   
 L  R2083   
 L  R2084   
 L  R2085   
 L  R2086   
 L  R2087   
 L  R2088   
 L  R2089   
 L  R2090   
 L  R2091   
 L  R2092   
 L  R2093   
 L  R2094   
 L  R2095   
 L  R2096   
 L  R2097   
 L  R2098   
 L  R2099   
 L  R2100   
 L  R2101   
 L  R2102   
 L  R2103   
 L  R2104   
 L  R2105   
 L  R2106   
 L  R2107   
 L  R2108   
 L  R2109   
 L  R2110   
 L  R2111   
 L  R2112   
 L  R2113   
 L  R2114   
 L  R2115   
 L  R2116   
 L  R2117   
 L  R2118   
 L  R2119   
 L  R2120   
 L  R2121   
 L  R2122   
 L  R2123   
 L  R2124   
 L  R2125   
 L  R2126   
 L  R2127   
 L  R2128   
 L  R2129   
 L  R2130   
 L  R2131   
 L  R2132   
 L  R2133   
 L  R2134   
 L  R2135   
 L  R2136   
 L  R2137   
 L  R2138   
 L  R2139   
 L  R2140   
 L  R2141   
 L  R2142   
 L  R2143   
 L  R2144   
 L  R2145   
 L  R2146   
 L  R2147   
 L  R2148   
 L  R2149   
 L  R2150   
 L  R2151   
 L  R2152   
 L  R2153   
 L  R2154   
 L  R2155   
 L  R2156   
 L  R2157   
 L  R2158   
 L  R2159   
 L  R2160   
 L  R2161   
 L  R2162   
 L  R2163   
 L  R2164   
 L  R2165   
 L  R2166   
 L  R2167   
 L  R2168   
 L  R2169   
 L  R2170   
 L  R2171   
 L  R2172   
 L  R2173   
 L  R2174   
 L  R2175   
 L  R2176   
 L  R2177   
 L  R2178   
 L  R2179   
 L  R2180   
 L  R2181   
 L  R2182   
 L  R2183   
 L  R2184   
 L  R2185   
 L  R2186   
 L  R2187   
 L  R2188   
 L  R2189   
 L  R2190   
 L  R2191   
 L  R2192   
 L  R2193   
 L  R2194   
 L  R2195   
 L  R2196   
 L  R2197   
 L  R2198   
 L  R2199   
 L  R2200   
 L  R2201   
 L  R2202   
 L  R2203   
 L  R2204   
 L  R2205   
 L  R2206   
 L  R2207   
 L  R2208   
 L  R2209   
 L  R2210   
 L  R2211   
 L  R2212   
 L  R2213   
 L  R2214   
 L  R2215   
 L  R2216   
 L  R2217   
 L  R2218   
 L  R2219   
 L  R2220   
 L  R2221   
 L  R2222   
 L  R2223   
 L  R2224   
 L  R2225   
 L  R2226   
 L  R2227   
 L  R2228   
 L  R2229   
 L  R2230   
 L  R2231   
 L  R2232   
 L  R2233   
 L  R2234   
 L  R2235   
 L  R2236   
 L  R2237   
 L  R2238   
 L  R2239   
 L  R2240   
 L  R2241   
 L  R2242   
 L  R2243   
 L  R2244   
 L  R2245   
 L  R2246   
 L  R2247   
 L  R2248   
 L  R2249   
 L  R2250   
 L  R2251   
 L  R2252   
 L  R2253   
 L  R2254   
 L  R2255   
 L  R2256   
 L  R2257   
 L  R2258   
 L  R2259   
 L  R2260   
 L  R2261   
 L  R2262   
 L  R2263   
 L  R2264   
 L  R2265   
 L  R2266   
 L  R2267   
 L  R2268   
 L  R2269   
 L  R2270   
 L  R2271   
 L  R2272   
 L  R2273   
 L  R2274   
 L  R2275   
 L  R2276   
 L  R2277   
 L  R2278   
 L  R2279   
 L  R2280   
 L  R2281   
 L  R2282   
 L  R2283   
 L  R2284   
 L  R2285   
 L  R2286   
 L  R2287   
 L  R2288   
 L  R2289   
 L  R2290   
 L  R2291   
 L  R2292   
 L  R2293   
 L  R2294   
 L  R2295   
 L  R2296   
 L  R2297   
 L  R2298   
 L  R2299   
 L  R2300   
 L  R2301   
 L  R2302   
 L  R2303   
 L  R2304   
 L  R2305   
 L  R2306   
 L  R2307   
 L  R2308   
 L  R2309   
 L  R2310   
 L  R2311   
 L  R2312   
 L  R2313   
 L  R2314   
 L  R2315   
 L  R2316   
 L  R2317   
 L  R2318   
 L  R2319   
 L  R2320   
 L  R2321   
 L  R2322   
 L  R2323   
 L  R2324   
 L  R2325   
 L  R2326   
 L  R2327   
 L  R2328   
 L  R2329   
 L  R2330   
 L  R2331   
 L  R2332   
 L  R2333   
 L  R2334   
 L  R2335   
 L  R2336   
 L  R2337   
 L  R2338   
 L  R2339   
 L  R2340   
 L  R2341   
 L  R2342   
 L  R2343   
 L  R2344   
 L  R2345   
 L  R2346   
 L  R2347   
 L  R2348   
 L  R2349   
 L  R2350   
 L  R2351   
 L  R2352   
 L  R2353   
 L  R2354   
 L  R2355   
 L  R2356   
 L  R2357   
 L  R2358   
 L  R2359   
 L  R2360   
 L  R2361   
 L  R2362   
 L  R2363   
 L  R2364   
 L  R2365   
 L  R2366   
 L  R2367   
 L  R2368   
 L  R2369   
 L  R2370   
 L  R2371   
 L  R2372   
 L  R2373   
 L  R2374   
 L  R2375   
 L  R2376   
 L  R2377   
 L  R2378   
 L  R2379   
 L  R2380   
 L  R2381   
 L  R2382   
 L  R2383   
 L  R2384   
 L  R2385   
 L  R2386   
 L  R2387   
 L  R2388   
 L  R2389   
 L  R2390   
 L  R2391   
 L  R2392   
 L  R2393   
 L  R2394   
 L  R2395   
 L  R2396   
 L  R2397   
 L  R2398   
 L  R2399   
 L  R2400   
 L  R2401   
 L  R2402   
 L  R2403   
 L  R2404   
 L  R2405   
 L  R2406   
 L  R2407   
 L  R2408   
 L  R2409   
 L  R2410   
 L  R2411   
 L  R2412   
 L  R2413   
 L  R2414   
 L  R2415   
 L  R2416   
 L  R2417   
 L  R2418   
 L  R2419   
 L  R2420   
 L  R2421   
 L  R2422   
 L  R2423   
 L  R2424   
 L  R2425   
 L  R2426   
 L  R2427   
 L  R2428   
 L  R2429   
 L  R2430   
 L  R2431   
 L  R2432   
 L  R2433   
 L  R2434   
 L  R2435   
 L  R2436   
 L  R2437   
 L  R2438   
 L  R2439   
 L  R2440   
 L  R2441   
 L  R2442   
 L  R2443   
 L  R2444   
 L  R2445   
 L  R2446   
 L  R2447   
 L  R2448   
 L  R2449   
 L  R2450   
 L  R2451   
 L  R2452   
 L  R2453   
 L  R2454   
 L  R2455   
 L  R2456   
 L  R2457   
 L  R2458   
 L  R2459   
 L  R2460   
 L  R2461   
 L  R2462   
 L  R2463   
 L  R2464   
 L  R2465   
 L  R2466   
 L  R2467   
 L  R2468   
 L  R2469   
 L  R2470   
 L  R2471   
 L  R2472   
 L  R2473   
 L  R2474   
 L  R2475   
 L  R2476   
 L  R2477   
 L  R2478   
 L  R2479   
 L  R2480   
 L  R2481   
 L  R2482   
 L  R2483   
 L  R2484   
 L  R2485   
 L  R2486   
 L  R2487   
 L  R2488   
 L  R2489   
 L  R2490   
 L  R2491   
 L  R2492   
 L  R2493   
 L  R2494   
 L  R2495   
 L  R2496   
 L  R2497   
 L  R2498   
 L  R2499   
 L  R2500   
 L  R2501   
 L  R2502   
 L  R2503   
 L  R2504   
 L  R2505   
 L  R2506   
 L  R2507   
 L  R2508   
 L  R2509   
 L  R2510   
 L  R2511   
 L  R2512   
 L  R2513   
 L  R2514   
 L  R2515   
 L  R2516   
 L  R2517   
 L  R2518   
 L  R2519   
 L  R2520   
 L  R2521   
 L  R2522   
 L  R2523   
 L  R2524   
 L  R2525   
 L  R2526   
 L  R2527   
 L  R2528   
 L  R2529   
 L  R2530   
 L  R2531   
 L  R2532   
 L  R2533   
 L  R2534   
 L  R2535   
 L  R2536   
 L  R2537   
 L  R2538   
 L  R2539   
 L  R2540   
 L  R2541   
 L  R2542   
 L  R2543   
 L  R2544   
 L  R2545   
 L  R2546   
 L  R2547   
 L  R2548   
 L  R2549   
 L  R2550   
 L  R2551   
 L  R2552   
 L  R2553   
 L  R2554   
 L  R2555   
 L  R2556   
 L  R2557   
 L  R2558   
 L  R2559   
 L  R2560   
 L  R2561   
 L  R2562   
 L  R2563   
 L  R2564   
 L  R2565   
 L  R2566   
 L  R2567   
 L  R2568   
 L  R2569   
 L  R2570   
 L  R2571   
 L  R2572   
 L  R2573   
 L  R2574   
 L  R2575   
 L  R2576   
 L  R2577   
 L  R2578   
 L  R2579   
 L  R2580   
 L  R2581   
 L  R2582   
 L  R2583   
 L  R2584   
 L  R2585   
 L  R2586   
 L  R2587   
 L  R2588   
 L  R2589   
 L  R2590   
 L  R2591   
 L  R2592   
 L  R2593   
 L  R2594   
 L  R2595   
 L  R2596   
 L  R2597   
 L  R2598   
 L  R2599   
 L  R2600   
 L  R2601   
 L  R2602   
 L  R2603   
 L  R2604   
 L  R2605   
 L  R2606   
 L  R2607   
 L  R2608   
 L  R2609   
 L  R2610   
 L  R2611   
 L  R2612   
 L  R2613   
 L  R2614   
 L  R2615   
 L  R2616   
 L  R2617   
 L  R2618   
 L  R2619   
 L  R2620   
 L  R2621   
 L  R2622   
 L  R2623   
 L  R2624   
 L  R2625   
 L  R2626   
 L  R2627   
 L  R2628   
 L  R2629   
 L  R2630   
 L  R2631   
 L  R2632   
 L  R2633   
 L  R2634   
 L  R2635   
 L  R2636   
 L  R2637   
 L  R2638   
 L  R2639   
 L  R2640   
 L  R2641   
 L  R2642   
 L  R2643   
 L  R2644   
 L  R2645   
 L  R2646   
 L  R2647   
 L  R2648   
 L  R2649   
 L  R2650   
 L  R2651   
 L  R2652   
 L  R2653   
 L  R2654   
 L  R2655   
 L  R2656   
 L  R2657   
 L  R2658   
 L  R2659   
 L  R2660   
 L  R2661   
 L  R2662   
 L  R2663   
 L  R2664   
 L  R2665   
 L  R2666   
 L  R2667   
 L  R2668   
 L  R2669   
 L  R2670   
 L  R2671   
 L  R2672   
 L  R2673   
 L  R2674   
 L  R2675   
 L  R2676   
 L  R2677   
 L  R2678   
 L  R2679   
 L  R2680   
 L  R2681   
 L  R2682   
 L  R2683   
 L  R2684   
 L  R2685   
 L  R2686   
 L  R2687   
 L  R2688   
 L  R2689   
 L  R2690   
 L  R2691   
 L  R2692   
 L  R2693   
 L  R2694   
 L  R2695   
 L  R2696   
 L  R2697   
 L  R2698   
 L  R2699   
 L  R2700   
 L  R2701   
 L  R2702   
 L  R2703   
 L  R2704   
 L  R2705   
 L  R2706   
 L  R2707   
 L  R2708   
 L  R2709   
 L  R2710   
 L  R2711   
 L  R2712   
 L  R2713   
 L  R2714   
 L  R2715   
 L  R2716   
 L  R2717   
 L  R2718   
 L  R2719   
 L  R2720   
 L  R2721   
 L  R2722   
 L  R2723   
 L  R2724   
 L  R2725   
 L  R2726   
 L  R2727   
 L  R2728   
 L  R2729   
 L  R2730   
 L  R2731   
 L  R2732   
 L  R2733   
 L  R2734   
 L  R2735   
 L  R2736   
 L  R2737   
 L  R2738   
 L  R2739   
 L  R2740   
 L  R2741   
 L  R2742   
 L  R2743   
 L  R2744   
 L  R2745   
 L  R2746   
 L  R2747   
 L  R2748   
 L  R2749   
 L  R2750   
 L  R2751   
 L  R2752   
 L  R2753   
 L  R2754   
 L  R2755   
 L  R2756   
 L  R2757   
 L  R2758   
 L  R2759   
 L  R2760   
 L  R2761   
 L  R2762   
 L  R2763   
 L  R2764   
 L  R2765   
 L  R2766   
 L  R2767   
 L  R2768   
 L  R2769   
 L  R2770   
 L  R2771   
 L  R2772   
 L  R2773   
 L  R2774   
 L  R2775   
 L  R2776   
 L  R2777   
 L  R2778   
 L  R2779   
 L  R2780   
 L  R2781   
 L  R2782   
 L  R2783   
 L  R2784   
 L  R2785   
 L  R2786   
 L  R2787   
 L  R2788   
 L  R2789   
 L  R2790   
 L  R2791   
 L  R2792   
 L  R2793   
 L  R2794   
 L  R2795   
 L  R2796   
 L  R2797   
 L  R2798   
 L  R2799   
 L  R2800   
 L  R2801   
 L  R2802   
 L  R2803   
 L  R2804   
 L  R2805   
 L  R2806   
 L  R2807   
 L  R2808   
 L  R2809   
 L  R2810   
 L  R2811   
 L  R2812   
 L  R2813   
 L  R2814   
 L  R2815   
 L  R2816   
 L  R2817   
 L  R2818   
 L  R2819   
 L  R2820   
 L  R2821   
 L  R2822   
 L  R2823   
 L  R2824   
 L  R2825   
 L  R2826   
 L  R2827   
 L  R2828   
 L  R2829   
 L  R2830   
 L  R2831   
 L  R2832   
 L  R2833   
 L  R2834   
 L  R2835   
 L  R2836   
 L  R2837   
 L  R2838   
 L  R2839   
 L  R2840   
 L  R2841   
 L  R2842   
 L  R2843   
 L  R2844   
 L  R2845   
 L  R2846   
 L  R2847   
 L  R2848   
 L  R2849   
 L  R2850   
 L  R2851   
 L  R2852   
 L  R2853   
 L  R2854   
 L  R2855   
 L  R2856   
 L  R2857   
 L  R2858   
 L  R2859   
 L  R2860   
 L  R2861   
 L  R2862   
 L  R2863   
 L  R2864   
 L  R2865   
 L  R2866   
 L  R2867   
 L  R2868   
 L  R2869   
 L  R2870   
 L  R2871   
 L  R2872   
 L  R2873   
 L  R2874   
 L  R2875   
 L  R2876   
 L  R2877   
 L  R2878   
 L  R2879   
 L  R2880   
 L  R2881   
 L  R2882   
 L  R2883   
 L  R2884   
 L  R2885   
 L  R2886   
 L  R2887   
 L  R2888   
 L  R2889   
 L  R2890   
 L  R2891   
 L  R2892   
 L  R2893   
 L  R2894   
 L  R2895   
 L  R2896   
 L  R2897   
 L  R2898   
 L  R2899   
 L  R2900   
 L  R2901   
 L  R2902   
 L  R2903   
 L  R2904   
 L  R2905   
 L  R2906   
 L  R2907   
 L  R2908   
 L  R2909   
 L  R2910   
 L  R2911   
 L  R2912   
 L  R2913   
 L  R2914   
 L  R2915   
 L  R2916   
 L  R2917   
 L  R2918   
 L  R2919   
 L  R2920   
 L  R2921   
 L  R2922   
 L  R2923   
 L  R2924   
 L  R2925   
 L  R2926   
 L  R2927   
 L  R2928   
 L  R2929   
 L  R2930   
 L  R2931   
 L  R2932   
 L  R2933   
 L  R2934   
 L  R2935   
 L  R2936   
 L  R2937   
 L  R2938   
 L  R2939   
 L  R2940   
 L  R2941   
 L  R2942   
 L  R2943   
 L  R2944   
 L  R2945   
 L  R2946   
 L  R2947   
 L  R2948   
 L  qc0     
 L  qc1     
 L  qc2     
 L  qc3     
 L  qc4     
 L  qc5     
 L  qc6     
 L  qc7     
 L  qc8     
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    phi[0,1]  R0        1
    phi[0,1]  R1        1
    phi[0,1]  R9        -1
    phi[0,1]  R83       -3.0999999046325684e+00
    phi[0,1]  R84       -3.0999999046325684e+00
    phi[0,1]  R85       -2.2400000095367432e+00
    phi[0,1]  R86       -2.2400000095367432e+00
    phi[0,1]  R87       -3.0999999046325684e+00
    phi[0,1]  R88       -3.0999999046325684e+00
    phi[0,1]  R89       -2.5699999332427979e+00
    phi[0,1]  R90       -2.5699999332427979e+00
    phi[0,1]  R91       -3.0999999046325684e+00
    phi[0,1]  R92       -3.0999999046325684e+00
    phi[0,1]  R93       -2.0899999141693115e+00
    phi[0,1]  R94       -2.0899999141693115e+00
    phi[0,1]  R95       -3.0999999046325684e+00
    phi[0,1]  R96       -3.0999999046325684e+00
    phi[0,1]  R97       1.9033046960830688e+00
    phi[0,1]  R98       1.4548109769821167e+00
    phi[0,1]  R99       8.3560341596603394e-01
    phi[0,1]  R100      1.8546886444091797e+00
    phi[0,1]  R101      -2.3408320546150208e-01
    phi[0,1]  R102      1.2651536464691162e+00
    phi[0,1]  R103      1.4013719558715820e-01
    phi[0,1]  R104      -8.9904159307479858e-01
    phi[0,1]  R105      3.9833462238311768e-01
    phi[0,1]  R106      8.2459098100662231e-01
    phi[0,1]  R107      -1.6912150382995605e+00
    phi[0,1]  R108      -1.6698158979415894e+00
    phi[0,1]  R109      -2.3897404968738556e-01
    phi[0,1]  R110      -1.0291640758514404e+00
    phi[0,1]  R111      -1.8030766248703003e+00
    phi[0,1]  R112      -1.7209169864654541e+00
    phi[0,1]  R113      -7.3829573392868042e-01
    phi[0,1]  R114      -7.9642450809478760e-01
    phi[0,1]  R115      -9.4345831871032715e-01
    phi[0,1]  R116      -1.4872291088104248e+00
    phi[0,1]  R117      -7.6452058553695679e-01
    phi[0,1]  R118      -2.5872340798377991e-01
    phi[0,1]  R119      4.1274213790893555e-01
    phi[0,1]  R120      -9.2371547222137451e-01
    phi[0,1]  R121      -1.7595784664154053e+00
    phi[0,1]  R122      -1.7720032930374146e+00
    phi[0,1]  R123      -2.8588857650756836e+00
    phi[0,1]  R124      -2.2926146984100342e+00
    phi[0,1]  R125      -1.7651401758193970e+00
    phi[0,1]  R126      -2.3026256561279297e+00
    phi[0,1]  R127      1.9058945775032043e-01
    phi[0,1]  R128      4.8903301358222961e-01
    phi[0,1]  R129      -0.795713484287262
    phi[0,1]  R130      1.6593933105468750e-01
    phi[0,1]  R131      -1.2644197940826416e+00
    phi[0,1]  R132      -0.456186443567276
    phi[0,1]  R133      -1.3580697774887085e+00
    phi[0,1]  R134      -9.5558124780654907e-01
    phi[0,1]  R135      3.9044272154569626e-02
    phi[0,1]  R136      -0.0509040504693985
    phi[0,1]  R137      -7.3835188150405884e-01
    phi[0,1]  R138      -1.3567718267440796e+00
    phi[0,1]  R139      -1.1599880456924438e+00
    phi[0,1]  R140      4.7649955749511719e-01
    phi[0,1]  R141      -1.2779865264892578e+00
    phi[0,1]  R142      -3.4315392374992371e-01
    phi[0,1]  R143      -2.7055428028106689e+00
    phi[0,1]  R144      -2.1489152908325195e+00
    phi[0,1]  R145      -2.4154279232025146e+00
    phi[0,1]  R146      -2.1296317577362061e+00
    phi[0,1]  R147      1.1319623142480850e-01
    phi[0,1]  R148      4.5273500680923462e-01
    phi[0,1]  R149      -6.2290906906127930e-01
    phi[0,1]  R150      -2.3396170139312744e+00
    phi[0,1]  R151      -2.0414905548095703e+00
    phi[0,1]  R152      -1.77381432056427
    phi[0,1]  R153      -2.3263442516326904e+00
    phi[0,1]  R154      -2.5793282985687256e+00
    phi[0,1]  R155      -2.0328917503356934e+00
    phi[0,1]  R156      -2.3577213287353516e+00
    phi[0,1]  R157      1.1874966621398926e+00
    phi[0,1]  R158      5.2083939313888550e-01
    phi[0,1]  R159      -1.6997894048690796e+00
    phi[0,1]  R160      1.5826981067657471e+00
    phi[0,1]  R161      0.0941983088850975
    phi[0,1]  R162      1.3233355283737183e+00
    phi[0,1]  R163      0.881929337978363
    phi[0,1]  R164      3.4591209888458252e+00
    phi[0,1]  R165      1.1403930932283401e-01
    phi[0,1]  R166      9.4206124544143677e-01
    phi[0,1]  R167      -3.9016110897064209e+00
    phi[0,1]  R168      -2.9241356849670410e+00
    phi[0,1]  R169      -2.5925626754760742e+00
    phi[0,1]  R170      -3.1569817066192627e+00
    phi[0,1]  R171      -4.6144809722900391e+00
    phi[0,1]  R172      -3.4229400753974915e-01
    phi[0,1]  R173      -1.7870420217514038e+00
    phi[0,1]  R174      -3.1353719234466553e+00
    phi[0,1]  R175      -2.7750325202941895e+00
    phi[0,1]  R176      1.3081914186477661e+00
    phi[0,1]  R177      -3.3668060302734375e+00
    phi[0,1]  R178      -1.48164701461792
    phi[0,1]  R179      -2.4508244991302490e+00
    phi[0,1]  R180      -3.2109253406524658e+00
    phi[0,1]  R181      -2.2541539669036865e+00
    phi[0,1]  R182      -1.3687264919281006e+00
    phi[0,1]  R183      -2.7434220314025879e+00
    phi[0,1]  R184      -3.07222056388855
    phi[0,1]  R185      1.7537190914154053e+00
    phi[0,1]  R186      1.6303237676620483e+00
    phi[0,1]  R187      -1.4082176685333252e+00
    phi[0,1]  R188      -7.6575976610183716e-01
    phi[0,1]  R189      -1.3458929061889648e+00
    phi[0,1]  R190      3.7411174178123474e-01
    phi[0,1]  R191      -1.0380614995956421e+00
    phi[0,1]  R192      -2.3804740905761719e+00
    phi[0,1]  R193      -2.4620616436004639e+00
    phi[0,1]  R194      -3.7006509304046631e+00
    phi[0,1]  R195      -3.1751546859741211e+00
    phi[0,1]  R196      -1.9792488813400269e+00
    phi[0,1]  R197      -1.1134316921234131e+00
    phi[0,1]  R198      -1.1269280910491943e+00
    phi[0,1]  R199      1.2252950668334961e+00
    phi[0,1]  R200      -1.7295559868216515e-02
    phi[0,1]  R201      -2.4152715206146240e+00
    phi[0,1]  R202      4.2217022180557251e-01
    phi[0,1]  R203      8.7850886583328247e-01
    phi[0,1]  R204      -3.2569916248321533e+00
    phi[0,1]  R205      -3.4877049922943115e+00
    phi[0,1]  R206      -2.9964764118194580e+00
    phi[0,1]  R207      7.3398929834365845e-01
    phi[0,1]  R208      -2.5989484786987305e+00
    phi[0,1]  R209      5.5961877107620239e-01
    phi[0,1]  R210      -2.8524696826934814e+00
    phi[0,1]  R211      -2.68194842338562
    phi[0,1]  R212      -2.1394681930541992e+00
    phi[0,1]  R213      -2.3897314071655273e+00
    phi[0,1]  R214      1.9141340255737305e-01
    phi[0,1]  R215      9.7458338737487793e-01
    phi[0,1]  R216      -3.4256836771965027e-01
    phi[0,1]  R217      -7.6971286535263062e-01
    phi[0,1]  R218      -4.5477727055549622e-01
    phi[0,1]  R219      1.1410349607467651e-01
    phi[0,1]  R220      2.8860026597976685e-01
    phi[0,1]  R221      -1.4300744533538818e+00
    phi[0,1]  R222      -2.5840611457824707e+00
    phi[0,1]  R223      -4.0059552192687988e+00
    phi[0,1]  R224      -2.5718414783477783e+00
    phi[0,1]  R225      -2.9546194076538086e+00
    phi[0,1]  R226      -1.6567565500736237e-01
    phi[0,1]  R227      -9.5090103149414062e-01
    phi[0,1]  R228      -1.1079283952713013e+00
    phi[0,1]  R229      -9.8982632160186768e-01
    phi[0,1]  R230      8.0232584476470947e-01
    phi[0,1]  R231      1.7316842079162598e+00
    phi[0,1]  R232      7.3911678791046143e-01
    phi[0,1]  R233      4.2590993642807007e-01
    phi[0,1]  R234      2.5651991367340088e-01
    phi[0,1]  R235      3.1610274314880371e-01
    phi[0,1]  R236      4.0780368447303772e-01
    phi[0,1]  R237      -2.3369871079921722e-01
    phi[0,1]  R238      -6.9420742988586426e-01
    phi[0,1]  R239      1.8794298171997070e+00
    phi[0,1]  R240      1.2809042930603027e+00
    phi[0,1]  R241      -6.8809598684310913e-02
    phi[0,1]  R242      1.2073887139558792e-01
    phi[0,1]  R243      2.1431192755699158e-01
    phi[0,1]  R244      1.9485074281692505e-01
    phi[0,1]  R245      7.3247164487838745e-02
    phi[0,1]  R246      6.8999719619750977e-01
    phi[1,0]  R0        -1
    phi[1,0]  R9        1
    phi[1,0]  R10       1
    phi[1,0]  R247      -3.0999999046325684e+00
    phi[1,0]  R248      -3.0999999046325684e+00
    phi[1,0]  R249      -2.2400000095367432e+00
    phi[1,0]  R250      -2.2400000095367432e+00
    phi[1,0]  R251      -3.0999999046325684e+00
    phi[1,0]  R252      -3.0999999046325684e+00
    phi[1,0]  R253      -2.5699999332427979e+00
    phi[1,0]  R254      -2.5699999332427979e+00
    phi[1,0]  R255      -3.0999999046325684e+00
    phi[1,0]  R256      -3.0999999046325684e+00
    phi[1,0]  R257      -2.0899999141693115e+00
    phi[1,0]  R258      -2.0899999141693115e+00
    phi[1,0]  R259      -3.0999999046325684e+00
    phi[1,0]  R260      -3.0999999046325684e+00
    phi[1,0]  R261      1.1874966621398926e+00
    phi[1,0]  R262      5.2083939313888550e-01
    phi[1,0]  R263      -1.6997894048690796e+00
    phi[1,0]  R264      1.5826981067657471e+00
    phi[1,0]  R265      0.0941983088850975
    phi[1,0]  R266      1.3233355283737183e+00
    phi[1,0]  R267      0.881929337978363
    phi[1,0]  R268      3.4591209888458252e+00
    phi[1,0]  R269      1.1403930932283401e-01
    phi[1,0]  R270      9.4206124544143677e-01
    phi[1,0]  R271      -3.9016110897064209e+00
    phi[1,0]  R272      -2.9241356849670410e+00
    phi[1,0]  R273      -2.5925626754760742e+00
    phi[1,0]  R274      -3.1569817066192627e+00
    phi[1,0]  R275      -4.6144809722900391e+00
    phi[1,0]  R276      -3.4229400753974915e-01
    phi[1,0]  R277      -1.7870420217514038e+00
    phi[1,0]  R278      -3.1353719234466553e+00
    phi[1,0]  R279      -2.7750325202941895e+00
    phi[1,0]  R280      1.3081914186477661e+00
    phi[1,0]  R281      -3.3668060302734375e+00
    phi[1,0]  R282      -1.48164701461792
    phi[1,0]  R283      -2.4508244991302490e+00
    phi[1,0]  R284      -3.2109253406524658e+00
    phi[1,0]  R285      -2.2541539669036865e+00
    phi[1,0]  R286      -1.3687264919281006e+00
    phi[1,0]  R287      -2.7434220314025879e+00
    phi[1,0]  R288      -3.07222056388855
    phi[1,0]  R289      1.7537190914154053e+00
    phi[1,0]  R290      1.6303237676620483e+00
    phi[1,0]  R291      -1.4082176685333252e+00
    phi[1,0]  R292      -7.6575976610183716e-01
    phi[1,0]  R293      -1.3458929061889648e+00
    phi[1,0]  R294      3.7411174178123474e-01
    phi[1,0]  R295      -1.0380614995956421e+00
    phi[1,0]  R296      -2.3804740905761719e+00
    phi[1,0]  R297      -2.4620616436004639e+00
    phi[1,0]  R298      -3.7006509304046631e+00
    phi[1,0]  R299      -3.1751546859741211e+00
    phi[1,0]  R300      -1.9792488813400269e+00
    phi[1,0]  R301      -1.1134316921234131e+00
    phi[1,0]  R302      -1.1269280910491943e+00
    phi[1,0]  R303      1.2252950668334961e+00
    phi[1,0]  R304      -1.7295559868216515e-02
    phi[1,0]  R305      -2.4152715206146240e+00
    phi[1,0]  R306      4.2217022180557251e-01
    phi[1,0]  R307      8.7850886583328247e-01
    phi[1,0]  R308      -3.2569916248321533e+00
    phi[1,0]  R309      -3.4877049922943115e+00
    phi[1,0]  R310      -2.9964764118194580e+00
    phi[1,0]  R311      7.3398929834365845e-01
    phi[1,0]  R312      -2.5989484786987305e+00
    phi[1,0]  R313      5.5961877107620239e-01
    phi[1,0]  R314      -2.8524696826934814e+00
    phi[1,0]  R315      -2.68194842338562
    phi[1,0]  R316      -2.1394681930541992e+00
    phi[1,0]  R317      -2.3897314071655273e+00
    phi[1,0]  R318      1.9141340255737305e-01
    phi[1,0]  R319      9.7458338737487793e-01
    phi[1,0]  R320      -3.4256836771965027e-01
    phi[1,0]  R321      -7.6971286535263062e-01
    phi[1,0]  R322      -4.5477727055549622e-01
    phi[1,0]  R323      1.1410349607467651e-01
    phi[1,0]  R324      2.8860026597976685e-01
    phi[1,0]  R325      -1.4300744533538818e+00
    phi[1,0]  R326      -2.5840611457824707e+00
    phi[1,0]  R327      -4.0059552192687988e+00
    phi[1,0]  R328      -2.5718414783477783e+00
    phi[1,0]  R329      -2.9546194076538086e+00
    phi[1,0]  R330      -1.6567565500736237e-01
    phi[1,0]  R331      -9.5090103149414062e-01
    phi[1,0]  R332      -1.1079283952713013e+00
    phi[1,0]  R333      -9.8982632160186768e-01
    phi[1,0]  R334      8.0232584476470947e-01
    phi[1,0]  R335      1.7316842079162598e+00
    phi[1,0]  R336      7.3911678791046143e-01
    phi[1,0]  R337      4.2590993642807007e-01
    phi[1,0]  R338      2.5651991367340088e-01
    phi[1,0]  R339      3.1610274314880371e-01
    phi[1,0]  R340      4.0780368447303772e-01
    phi[1,0]  R341      -2.3369871079921722e-01
    phi[1,0]  R342      -6.9420742988586426e-01
    phi[1,0]  R343      1.8794298171997070e+00
    phi[1,0]  R344      1.2809042930603027e+00
    phi[1,0]  R345      -6.8809598684310913e-02
    phi[1,0]  R346      1.2073887139558792e-01
    phi[1,0]  R347      2.1431192755699158e-01
    phi[1,0]  R348      1.9485074281692505e-01
    phi[1,0]  R349      7.3247164487838745e-02
    phi[1,0]  R350      6.8999719619750977e-01
    phi[1,0]  R351      1.9033046960830688e+00
    phi[1,0]  R352      1.4548109769821167e+00
    phi[1,0]  R353      8.3560341596603394e-01
    phi[1,0]  R354      1.8546886444091797e+00
    phi[1,0]  R355      -2.3408320546150208e-01
    phi[1,0]  R356      1.2651536464691162e+00
    phi[1,0]  R357      1.4013719558715820e-01
    phi[1,0]  R358      -8.9904159307479858e-01
    phi[1,0]  R359      3.9833462238311768e-01
    phi[1,0]  R360      8.2459098100662231e-01
    phi[1,0]  R361      -1.6912150382995605e+00
    phi[1,0]  R362      -1.6698158979415894e+00
    phi[1,0]  R363      -2.3897404968738556e-01
    phi[1,0]  R364      -1.0291640758514404e+00
    phi[1,0]  R365      -1.8030766248703003e+00
    phi[1,0]  R366      -1.7209169864654541e+00
    phi[1,0]  R367      -7.3829573392868042e-01
    phi[1,0]  R368      -7.9642450809478760e-01
    phi[1,0]  R369      -9.4345831871032715e-01
    phi[1,0]  R370      -1.4872291088104248e+00
    phi[1,0]  R371      -7.6452058553695679e-01
    phi[1,0]  R372      -2.5872340798377991e-01
    phi[1,0]  R373      4.1274213790893555e-01
    phi[1,0]  R374      -9.2371547222137451e-01
    phi[1,0]  R375      -1.7595784664154053e+00
    phi[1,0]  R376      -1.7720032930374146e+00
    phi[1,0]  R377      -2.8588857650756836e+00
    phi[1,0]  R378      -2.2926146984100342e+00
    phi[1,0]  R379      -1.7651401758193970e+00
    phi[1,0]  R380      -2.3026256561279297e+00
    phi[1,0]  R381      1.9058945775032043e-01
    phi[1,0]  R382      4.8903301358222961e-01
    phi[1,0]  R383      -0.795713484287262
    phi[1,0]  R384      1.6593933105468750e-01
    phi[1,0]  R385      -1.2644197940826416e+00
    phi[1,0]  R386      -0.456186443567276
    phi[1,0]  R387      -1.3580697774887085e+00
    phi[1,0]  R388      -9.5558124780654907e-01
    phi[1,0]  R389      3.9044272154569626e-02
    phi[1,0]  R390      -0.0509040504693985
    phi[1,0]  R391      -7.3835188150405884e-01
    phi[1,0]  R392      -1.3567718267440796e+00
    phi[1,0]  R393      -1.1599880456924438e+00
    phi[1,0]  R394      4.7649955749511719e-01
    phi[1,0]  R395      -1.2779865264892578e+00
    phi[1,0]  R396      -3.4315392374992371e-01
    phi[1,0]  R397      -2.7055428028106689e+00
    phi[1,0]  R398      -2.1489152908325195e+00
    phi[1,0]  R399      -2.4154279232025146e+00
    phi[1,0]  R400      -2.1296317577362061e+00
    phi[1,0]  R401      1.1319623142480850e-01
    phi[1,0]  R402      4.5273500680923462e-01
    phi[1,0]  R403      -6.2290906906127930e-01
    phi[1,0]  R404      -2.3396170139312744e+00
    phi[1,0]  R405      -2.0414905548095703e+00
    phi[1,0]  R406      -1.77381432056427
    phi[1,0]  R407      -2.3263442516326904e+00
    phi[1,0]  R408      -2.5793282985687256e+00
    phi[1,0]  R409      -2.0328917503356934e+00
    phi[1,0]  R410      -2.3577213287353516e+00
    phi[0,6]  R0        1
    phi[0,6]  R1        1
    phi[0,6]  R54       -1
    phi[0,6]  R411      -3.0999999046325684e+00
    phi[0,6]  R412      -3.0999999046325684e+00
    phi[0,6]  R413      -2.2400000095367432e+00
    phi[0,6]  R414      -2.2400000095367432e+00
    phi[0,6]  R415      -3.0999999046325684e+00
    phi[0,6]  R416      -3.0999999046325684e+00
    phi[0,6]  R417      -2.5699999332427979e+00
    phi[0,6]  R418      -2.5699999332427979e+00
    phi[0,6]  R419      -3.0999999046325684e+00
    phi[0,6]  R420      -3.0999999046325684e+00
    phi[0,6]  R421      -2.0899999141693115e+00
    phi[0,6]  R422      -2.0899999141693115e+00
    phi[0,6]  R423      -3.0999999046325684e+00
    phi[0,6]  R424      -3.0999999046325684e+00
    phi[0,6]  R425      1.9033046960830688e+00
    phi[0,6]  R426      1.4548109769821167e+00
    phi[0,6]  R427      8.3560341596603394e-01
    phi[0,6]  R428      1.8546886444091797e+00
    phi[0,6]  R429      -2.3408320546150208e-01
    phi[0,6]  R430      1.2651536464691162e+00
    phi[0,6]  R431      1.4013719558715820e-01
    phi[0,6]  R432      -8.9904159307479858e-01
    phi[0,6]  R433      3.9833462238311768e-01
    phi[0,6]  R434      8.2459098100662231e-01
    phi[0,6]  R435      -1.6912150382995605e+00
    phi[0,6]  R436      -1.6698158979415894e+00
    phi[0,6]  R437      -2.3897404968738556e-01
    phi[0,6]  R438      -1.0291640758514404e+00
    phi[0,6]  R439      -1.8030766248703003e+00
    phi[0,6]  R440      -1.7209169864654541e+00
    phi[0,6]  R441      -7.3829573392868042e-01
    phi[0,6]  R442      -7.9642450809478760e-01
    phi[0,6]  R443      -9.4345831871032715e-01
    phi[0,6]  R444      -1.4872291088104248e+00
    phi[0,6]  R445      -7.6452058553695679e-01
    phi[0,6]  R446      -2.5872340798377991e-01
    phi[0,6]  R447      4.1274213790893555e-01
    phi[0,6]  R448      -9.2371547222137451e-01
    phi[0,6]  R449      -1.7595784664154053e+00
    phi[0,6]  R450      -1.7720032930374146e+00
    phi[0,6]  R451      -2.8588857650756836e+00
    phi[0,6]  R452      -2.2926146984100342e+00
    phi[0,6]  R453      -1.7651401758193970e+00
    phi[0,6]  R454      -2.3026256561279297e+00
    phi[0,6]  R455      1.9058945775032043e-01
    phi[0,6]  R456      4.8903301358222961e-01
    phi[0,6]  R457      -0.795713484287262
    phi[0,6]  R458      1.6593933105468750e-01
    phi[0,6]  R459      -1.2644197940826416e+00
    phi[0,6]  R460      -0.456186443567276
    phi[0,6]  R461      -1.3580697774887085e+00
    phi[0,6]  R462      -9.5558124780654907e-01
    phi[0,6]  R463      3.9044272154569626e-02
    phi[0,6]  R464      -0.0509040504693985
    phi[0,6]  R465      -7.3835188150405884e-01
    phi[0,6]  R466      -1.3567718267440796e+00
    phi[0,6]  R467      -1.1599880456924438e+00
    phi[0,6]  R468      4.7649955749511719e-01
    phi[0,6]  R469      -1.2779865264892578e+00
    phi[0,6]  R470      -3.4315392374992371e-01
    phi[0,6]  R471      -2.7055428028106689e+00
    phi[0,6]  R472      -2.1489152908325195e+00
    phi[0,6]  R473      -2.4154279232025146e+00
    phi[0,6]  R474      -2.1296317577362061e+00
    phi[0,6]  R475      1.1319623142480850e-01
    phi[0,6]  R476      4.5273500680923462e-01
    phi[0,6]  R477      -6.2290906906127930e-01
    phi[0,6]  R478      -2.3396170139312744e+00
    phi[0,6]  R479      -2.0414905548095703e+00
    phi[0,6]  R480      -1.77381432056427
    phi[0,6]  R481      -2.3263442516326904e+00
    phi[0,6]  R482      -2.5793282985687256e+00
    phi[0,6]  R483      -2.0328917503356934e+00
    phi[0,6]  R484      -2.3577213287353516e+00
    phi[0,6]  R485      1.5287969112396240e+00
    phi[0,6]  R486      1.2251930236816406e+00
    phi[0,6]  R487      1.8496649265289307e+00
    phi[0,6]  R488      8.2207804918289185e-01
    phi[0,6]  R489      3.3011811971664429e-01
    phi[0,6]  R490      7.6574277877807617e-01
    phi[0,6]  R491      1.9281120300292969e+00
    phi[0,6]  R492      2.3882522583007812e+00
    phi[0,6]  R493      -8.3120399713516235e-01
    phi[0,6]  R494      2.2273474931716919e-01
    phi[0,6]  R495      -8.7682509422302246e-01
    phi[0,6]  R496      2.9664799571037292e-01
    phi[0,6]  R497      -2.8459697961807251e-01
    phi[0,6]  R498      -8.1182456016540527e-01
    phi[0,6]  R499      -1.9324302673339844e-01
    phi[0,6]  R500      -3.1624674797058105e-01
    phi[0,6]  R501      -2.1559913158416748e+00
    phi[0,6]  R502      1.8012432754039764e-01
    phi[0,6]  R503      -1.1272479295730591e+00
    phi[0,6]  R504      -2.4805190563201904e+00
    phi[0,6]  R505      8.8435572385787964e-01
    phi[0,6]  R506      1.7913125455379486e-02
    phi[0,6]  R507      7.9076486825942993e-01
    phi[0,6]  R508      -2.0657274127006531e-01
    phi[0,6]  R509      5.6026756763458252e-02
    phi[0,6]  R510      -2.3912830352783203e+00
    phi[0,6]  R511      -9.1737985610961914e-01
    phi[0,6]  R512      -2.2055718898773193e+00
    phi[0,6]  R513      -1.2220654487609863e+00
    phi[0,6]  R514      -6.4932554960250854e-01
    phi[0,6]  R515      1.2424324750900269e+00
    phi[0,6]  R516      -4.4023975729942322e-01
    phi[0,6]  R517      -1.6559355258941650e+00
    phi[0,6]  R518      5.7987719774246216e-01
    phi[0,6]  R519      2.0515391230583191e-01
    phi[0,6]  R520      -8.1085664033889771e-01
    phi[0,6]  R521      -1.1087069511413574e+00
    phi[0,6]  R522      1.1429567337036133e+00
    phi[0,6]  R523      3.6965510249137878e-01
    phi[0,6]  R524      -1.0223436355590820e-01
    phi[0,6]  R525      7.2915619611740112e-01
    phi[0,6]  R526      -1.5767264366149902e+00
    phi[0,6]  R527      -1.1388508081436157e+00
    phi[0,6]  R528      -1.3088898658752441e+00
    phi[0,6]  R529      -3.1540192663669586e-02
    phi[0,6]  R530      -1.8435820341110229e+00
    phi[0,6]  R531      -1.7670247554779053e+00
    phi[0,6]  R532      -1.93596351146698
    phi[0,6]  R533      -1.7743901014328003e+00
    phi[0,6]  R534      -2.748291015625
    phi[0,6]  R535      -9.0733373165130615e-01
    phi[0,6]  R536      9.8939800262451172e-01
    phi[0,6]  R537      -8.1240409612655640e-01
    phi[0,6]  R538      2.4008347094058990e-01
    phi[0,6]  R539      -2.2250094413757324e+00
    phi[0,6]  R540      -2.8969137668609619e+00
    phi[0,6]  R541      -1.3510568141937256e+00
    phi[0,6]  R542      -2.2803211212158203e+00
    phi[0,6]  R543      -2.1561982631683350e+00
    phi[0,6]  R544      -1.6440916061401367e+00
    phi[0,6]  R545      -4.7803664207458496e-01
    phi[0,6]  R546      -5.6152415275573730e-01
    phi[0,6]  R547      0.789250910282135
    phi[0,6]  R548      -1.8148900270462036e+00
    phi[0,6]  R549      -1.43842613697052
    phi[0,6]  R550      -1.4285249710083008e+00
    phi[0,6]  R551      -2.6473522186279297e+00
    phi[0,6]  R552      -1.8664598464965820e+00
    phi[0,6]  R553      -2.1407809257507324e+00
    phi[0,6]  R554      -3.3944652080535889e+00
    phi[6,0]  R0        -1
    phi[6,0]  R54       1
    phi[6,0]  R55       1
    phi[6,0]  R555      -3.0999999046325684e+00
    phi[6,0]  R556      -3.0999999046325684e+00
    phi[6,0]  R557      -2.2400000095367432e+00
    phi[6,0]  R558      -2.2400000095367432e+00
    phi[6,0]  R559      -3.0999999046325684e+00
    phi[6,0]  R560      -3.0999999046325684e+00
    phi[6,0]  R561      -2.5699999332427979e+00
    phi[6,0]  R562      -2.5699999332427979e+00
    phi[6,0]  R563      -3.0999999046325684e+00
    phi[6,0]  R564      -3.0999999046325684e+00
    phi[6,0]  R565      -2.0899999141693115e+00
    phi[6,0]  R566      -2.0899999141693115e+00
    phi[6,0]  R567      -3.0999999046325684e+00
    phi[6,0]  R568      -3.0999999046325684e+00
    phi[6,0]  R569      1.5287969112396240e+00
    phi[6,0]  R570      1.2251930236816406e+00
    phi[6,0]  R571      1.8496649265289307e+00
    phi[6,0]  R572      8.2207804918289185e-01
    phi[6,0]  R573      3.3011811971664429e-01
    phi[6,0]  R574      7.6574277877807617e-01
    phi[6,0]  R575      1.9281120300292969e+00
    phi[6,0]  R576      2.3882522583007812e+00
    phi[6,0]  R577      -8.3120399713516235e-01
    phi[6,0]  R578      2.2273474931716919e-01
    phi[6,0]  R579      -8.7682509422302246e-01
    phi[6,0]  R580      2.9664799571037292e-01
    phi[6,0]  R581      -2.8459697961807251e-01
    phi[6,0]  R582      -8.1182456016540527e-01
    phi[6,0]  R583      -1.9324302673339844e-01
    phi[6,0]  R584      -3.1624674797058105e-01
    phi[6,0]  R585      -2.1559913158416748e+00
    phi[6,0]  R586      1.8012432754039764e-01
    phi[6,0]  R587      -1.1272479295730591e+00
    phi[6,0]  R588      -2.4805190563201904e+00
    phi[6,0]  R589      8.8435572385787964e-01
    phi[6,0]  R590      1.7913125455379486e-02
    phi[6,0]  R591      7.9076486825942993e-01
    phi[6,0]  R592      -2.0657274127006531e-01
    phi[6,0]  R593      5.6026756763458252e-02
    phi[6,0]  R594      -2.3912830352783203e+00
    phi[6,0]  R595      -9.1737985610961914e-01
    phi[6,0]  R596      -2.2055718898773193e+00
    phi[6,0]  R597      -1.2220654487609863e+00
    phi[6,0]  R598      -6.4932554960250854e-01
    phi[6,0]  R599      1.2424324750900269e+00
    phi[6,0]  R600      -4.4023975729942322e-01
    phi[6,0]  R601      -1.6559355258941650e+00
    phi[6,0]  R602      5.7987719774246216e-01
    phi[6,0]  R603      2.0515391230583191e-01
    phi[6,0]  R604      -8.1085664033889771e-01
    phi[6,0]  R605      -1.1087069511413574e+00
    phi[6,0]  R606      1.1429567337036133e+00
    phi[6,0]  R607      3.6965510249137878e-01
    phi[6,0]  R608      -1.0223436355590820e-01
    phi[6,0]  R609      7.2915619611740112e-01
    phi[6,0]  R610      -1.5767264366149902e+00
    phi[6,0]  R611      -1.1388508081436157e+00
    phi[6,0]  R612      -1.3088898658752441e+00
    phi[6,0]  R613      -3.1540192663669586e-02
    phi[6,0]  R614      -1.8435820341110229e+00
    phi[6,0]  R615      -1.7670247554779053e+00
    phi[6,0]  R616      -1.93596351146698
    phi[6,0]  R617      -1.7743901014328003e+00
    phi[6,0]  R618      -2.748291015625
    phi[6,0]  R619      -9.0733373165130615e-01
    phi[6,0]  R620      9.8939800262451172e-01
    phi[6,0]  R621      -8.1240409612655640e-01
    phi[6,0]  R622      2.4008347094058990e-01
    phi[6,0]  R623      -2.2250094413757324e+00
    phi[6,0]  R624      -2.8969137668609619e+00
    phi[6,0]  R625      -1.3510568141937256e+00
    phi[6,0]  R626      -2.2803211212158203e+00
    phi[6,0]  R627      -2.1561982631683350e+00
    phi[6,0]  R628      -1.6440916061401367e+00
    phi[6,0]  R629      -4.7803664207458496e-01
    phi[6,0]  R630      -5.6152415275573730e-01
    phi[6,0]  R631      0.789250910282135
    phi[6,0]  R632      -1.8148900270462036e+00
    phi[6,0]  R633      -1.43842613697052
    phi[6,0]  R634      -1.4285249710083008e+00
    phi[6,0]  R635      -2.6473522186279297e+00
    phi[6,0]  R636      -1.8664598464965820e+00
    phi[6,0]  R637      -2.1407809257507324e+00
    phi[6,0]  R638      -3.3944652080535889e+00
    phi[6,0]  R639      1.9033046960830688e+00
    phi[6,0]  R640      1.4548109769821167e+00
    phi[6,0]  R641      8.3560341596603394e-01
    phi[6,0]  R642      1.8546886444091797e+00
    phi[6,0]  R643      -2.3408320546150208e-01
    phi[6,0]  R644      1.2651536464691162e+00
    phi[6,0]  R645      1.4013719558715820e-01
    phi[6,0]  R646      -8.9904159307479858e-01
    phi[6,0]  R647      3.9833462238311768e-01
    phi[6,0]  R648      8.2459098100662231e-01
    phi[6,0]  R649      -1.6912150382995605e+00
    phi[6,0]  R650      -1.6698158979415894e+00
    phi[6,0]  R651      -2.3897404968738556e-01
    phi[6,0]  R652      -1.0291640758514404e+00
    phi[6,0]  R653      -1.8030766248703003e+00
    phi[6,0]  R654      -1.7209169864654541e+00
    phi[6,0]  R655      -7.3829573392868042e-01
    phi[6,0]  R656      -7.9642450809478760e-01
    phi[6,0]  R657      -9.4345831871032715e-01
    phi[6,0]  R658      -1.4872291088104248e+00
    phi[6,0]  R659      -7.6452058553695679e-01
    phi[6,0]  R660      -2.5872340798377991e-01
    phi[6,0]  R661      4.1274213790893555e-01
    phi[6,0]  R662      -9.2371547222137451e-01
    phi[6,0]  R663      -1.7595784664154053e+00
    phi[6,0]  R664      -1.7720032930374146e+00
    phi[6,0]  R665      -2.8588857650756836e+00
    phi[6,0]  R666      -2.2926146984100342e+00
    phi[6,0]  R667      -1.7651401758193970e+00
    phi[6,0]  R668      -2.3026256561279297e+00
    phi[6,0]  R669      1.9058945775032043e-01
    phi[6,0]  R670      4.8903301358222961e-01
    phi[6,0]  R671      -0.795713484287262
    phi[6,0]  R672      1.6593933105468750e-01
    phi[6,0]  R673      -1.2644197940826416e+00
    phi[6,0]  R674      -0.456186443567276
    phi[6,0]  R675      -1.3580697774887085e+00
    phi[6,0]  R676      -9.5558124780654907e-01
    phi[6,0]  R677      3.9044272154569626e-02
    phi[6,0]  R678      -0.0509040504693985
    phi[6,0]  R679      -7.3835188150405884e-01
    phi[6,0]  R680      -1.3567718267440796e+00
    phi[6,0]  R681      -1.1599880456924438e+00
    phi[6,0]  R682      4.7649955749511719e-01
    phi[6,0]  R683      -1.2779865264892578e+00
    phi[6,0]  R684      -3.4315392374992371e-01
    phi[6,0]  R685      -2.7055428028106689e+00
    phi[6,0]  R686      -2.1489152908325195e+00
    phi[6,0]  R687      -2.4154279232025146e+00
    phi[6,0]  R688      -2.1296317577362061e+00
    phi[6,0]  R689      1.1319623142480850e-01
    phi[6,0]  R690      4.5273500680923462e-01
    phi[6,0]  R691      -6.2290906906127930e-01
    phi[6,0]  R692      -2.3396170139312744e+00
    phi[6,0]  R693      -2.0414905548095703e+00
    phi[6,0]  R694      -1.77381432056427
    phi[6,0]  R695      -2.3263442516326904e+00
    phi[6,0]  R696      -2.5793282985687256e+00
    phi[6,0]  R697      -2.0328917503356934e+00
    phi[6,0]  R698      -2.3577213287353516e+00
    phi[9,0]  R0        -1
    phi[9,0]  R2        -1.3662186085443053e+00
    phi[9,0]  R3        1.7399764913263560e-02
    phi[9,0]  R4        -6.4662269535883610e-01
    phi[9,0]  R5        -1.4391404286847327e+00
    phi[9,0]  R6        7.1012939330827551e-01
    phi[9,0]  R7        3.6219531726647070e-01
    phi[9,0]  R8        2.0850263072532003e+00
    phi[9,0]  R81       1
    phi[9,0]  R699      -1.7337812960882630e+00
    phi[9,0]  R700      -4.4662185131768739e+00
    phi[9,0]  R701      -2.2573997744500067e+00
    phi[9,0]  R702      -2.2226002446234796e+00
    phi[9,0]  R703      -2.4533772092737323e+00
    phi[9,0]  R704      -3.7466225999914045e+00
    phi[9,0]  R705      -1.1308595045580652e+00
    phi[9,0]  R706      -4.00914036192753
    phi[9,0]  R707      -3.8101292979408439e+00
    phi[9,0]  R708      -2.3898705113242928e+00
    phi[9,0]  R709      -2.4521952314357822e+00
    phi[9,0]  R710      -1.7278045969028408e+00
    phi[9,0]  R711      -5.1850262118857682e+00
    phi[9,0]  R712      -1.0149735973793681e+00
    phi[9,0]  R713      -1.8221772648974843e-01
    phi[9,0]  R714      -1.8884717019499631e-01
    phi[9,0]  R715      -1.8944334653476025e-01
    phi[9,0]  R716      -1.9350077113445563e-01
    phi[9,0]  R717      -2.1517234114517949e+00
    phi[9,0]  R718      -1.9758738376513030e-01
    phi[9,0]  R719      -1.9841675583172164e-01
    phi[9,0]  R720      -2.6708072198110258e+00
    phi[9,0]  R721      -2.2025671309094275e-01
    phi[9,0]  R722      -2.7856910556220882e-01
    phi[9,0]  R723      -3.7898369920378427e-01
    phi[9,0]  R724      -3.8078034705518982e-01
    phi[9,0]  R725      -3.8609450550235036e-01
    phi[9,0]  R726      -3.8826529497835183e-01
    phi[9,0]  R727      -3.8850368189099793e-01
    phi[9,0]  R728      -3.9518393100336757e-01
    phi[9,0]  R729      -4.0139035955267610e-01
    phi[9,0]  R730      -0.401541810740199
    phi[9,0]  R731      -4.0189097490687786e-01
    phi[9,0]  R732      -4.0284519336469238e-01
    phi[9,0]  R733      -0.519895488620165
    phi[9,0]  R734      -5.7701480227953017e-01
    phi[9,0]  R735      -5.8843189581903665e-01
    phi[9,0]  R736      -6.0531507740119539e-01
    phi[9,0]  R737      -6.1439172131927622e-01
    phi[9,0]  R738      -6.2482986533159113e-01
    phi[9,0]  R739      -6.3904447588481261e-01
    phi[9,0]  R740      -6.4053004618565468e-01
    phi[9,0]  R741      -6.4431459134267111e-01
    phi[9,0]  R742      -6.4622720026662828e-01
    phi[9,0]  R743      -4.3442258365207254e-01
    phi[9,0]  R744      -4.6021431584030792e-01
    phi[9,0]  R745      -4.7157772203037573e-01
    phi[9,0]  R746      -4.7923766023220526e-01
    phi[9,0]  R747      -4.8393714332664284e-01
    phi[9,0]  R748      -4.9139791365816188e-01
    phi[9,0]  R749      -0.519212911385149
    phi[9,0]  R750      -5.1975468619154885e-01
    phi[9,0]  R751      -0.525627352442348
    phi[9,0]  R752      -5.3553276415506135e-01
    phi[9,0]  R753      -4.2618784796964648e-01
    phi[9,0]  R754      -4.4450534182218027e-01
    phi[9,0]  R755      -4.6492704782583361e-01
    phi[9,0]  R756      -4.9416261598910705e-01
    phi[9,0]  R757      -4.9539317265029104e-01
    phi[9,0]  R758      -0.514728895685267
    phi[9,0]  R759      -5.5292096111948208e-01
    phi[9,0]  R760      -5.9547574346886312e-01
    phi[9,0]  R761      -6.2372375072900543e-01
    phi[9,0]  R762      -6.3238332570756306e-01
    phi[9,0]  R763      -4.1229751011778537e-01
    phi[9,0]  R764      -4.3270318389070672e-01
    phi[9,0]  R765      -4.9071884783110808e-01
    phi[9,0]  R766      -5.8747328009805422e-01
    phi[9,0]  R767      -6.0409372672235473e-01
    phi[9,0]  R768      -6.6836290228800133e-01
    phi[9,0]  R769      -6.8267710977372920e-01
    phi[9,0]  R770      -8.6404140727668977e-01
    phi[9,0]  R771      -8.7817844885995555e-01
    phi[9,0]  R772      -9.0301887168873818e-01
    phi[1,2]  R9        1
    phi[1,2]  R10       1
    phi[1,2]  R18       -1
    phi[1,2]  R773      -3.0999999046325684e+00
    phi[1,2]  R774      -3.0999999046325684e+00
    phi[1,2]  R775      -2.2400000095367432e+00
    phi[1,2]  R776      -2.2400000095367432e+00
    phi[1,2]  R777      -3.0999999046325684e+00
    phi[1,2]  R778      -3.0999999046325684e+00
    phi[1,2]  R779      -2.5699999332427979e+00
    phi[1,2]  R780      -2.5699999332427979e+00
    phi[1,2]  R781      -3.0999999046325684e+00
    phi[1,2]  R782      -3.0999999046325684e+00
    phi[1,2]  R783      -2.0899999141693115e+00
    phi[1,2]  R784      -2.0899999141693115e+00
    phi[1,2]  R785      -3.0999999046325684e+00
    phi[1,2]  R786      -3.0999999046325684e+00
    phi[1,2]  R787      1.1874966621398926e+00
    phi[1,2]  R788      5.2083939313888550e-01
    phi[1,2]  R789      -1.6997894048690796e+00
    phi[1,2]  R790      1.5826981067657471e+00
    phi[1,2]  R791      0.0941983088850975
    phi[1,2]  R792      1.3233355283737183e+00
    phi[1,2]  R793      0.881929337978363
    phi[1,2]  R794      3.4591209888458252e+00
    phi[1,2]  R795      1.1403930932283401e-01
    phi[1,2]  R796      9.4206124544143677e-01
    phi[1,2]  R797      -3.9016110897064209e+00
    phi[1,2]  R798      -2.9241356849670410e+00
    phi[1,2]  R799      -2.5925626754760742e+00
    phi[1,2]  R800      -3.1569817066192627e+00
    phi[1,2]  R801      -4.6144809722900391e+00
    phi[1,2]  R802      -3.4229400753974915e-01
    phi[1,2]  R803      -1.7870420217514038e+00
    phi[1,2]  R804      -3.1353719234466553e+00
    phi[1,2]  R805      -2.7750325202941895e+00
    phi[1,2]  R806      1.3081914186477661e+00
    phi[1,2]  R807      -3.3668060302734375e+00
    phi[1,2]  R808      -1.48164701461792
    phi[1,2]  R809      -2.4508244991302490e+00
    phi[1,2]  R810      -3.2109253406524658e+00
    phi[1,2]  R811      -2.2541539669036865e+00
    phi[1,2]  R812      -1.3687264919281006e+00
    phi[1,2]  R813      -2.7434220314025879e+00
    phi[1,2]  R814      -3.07222056388855
    phi[1,2]  R815      1.7537190914154053e+00
    phi[1,2]  R816      1.6303237676620483e+00
    phi[1,2]  R817      -1.4082176685333252e+00
    phi[1,2]  R818      -7.6575976610183716e-01
    phi[1,2]  R819      -1.3458929061889648e+00
    phi[1,2]  R820      3.7411174178123474e-01
    phi[1,2]  R821      -1.0380614995956421e+00
    phi[1,2]  R822      -2.3804740905761719e+00
    phi[1,2]  R823      -2.4620616436004639e+00
    phi[1,2]  R824      -3.7006509304046631e+00
    phi[1,2]  R825      -3.1751546859741211e+00
    phi[1,2]  R826      -1.9792488813400269e+00
    phi[1,2]  R827      -1.1134316921234131e+00
    phi[1,2]  R828      -1.1269280910491943e+00
    phi[1,2]  R829      1.2252950668334961e+00
    phi[1,2]  R830      -1.7295559868216515e-02
    phi[1,2]  R831      -2.4152715206146240e+00
    phi[1,2]  R832      4.2217022180557251e-01
    phi[1,2]  R833      8.7850886583328247e-01
    phi[1,2]  R834      -3.2569916248321533e+00
    phi[1,2]  R835      -3.4877049922943115e+00
    phi[1,2]  R836      -2.9964764118194580e+00
    phi[1,2]  R837      7.3398929834365845e-01
    phi[1,2]  R838      -2.5989484786987305e+00
    phi[1,2]  R839      5.5961877107620239e-01
    phi[1,2]  R840      -2.8524696826934814e+00
    phi[1,2]  R841      -2.68194842338562
    phi[1,2]  R842      -2.1394681930541992e+00
    phi[1,2]  R843      -2.3897314071655273e+00
    phi[1,2]  R844      1.9141340255737305e-01
    phi[1,2]  R845      9.7458338737487793e-01
    phi[1,2]  R846      -3.4256836771965027e-01
    phi[1,2]  R847      -7.6971286535263062e-01
    phi[1,2]  R848      -4.5477727055549622e-01
    phi[1,2]  R849      1.1410349607467651e-01
    phi[1,2]  R850      2.8860026597976685e-01
    phi[1,2]  R851      -1.4300744533538818e+00
    phi[1,2]  R852      -2.5840611457824707e+00
    phi[1,2]  R853      -4.0059552192687988e+00
    phi[1,2]  R854      -2.5718414783477783e+00
    phi[1,2]  R855      -2.9546194076538086e+00
    phi[1,2]  R856      -1.6567565500736237e-01
    phi[1,2]  R857      -9.5090103149414062e-01
    phi[1,2]  R858      -1.1079283952713013e+00
    phi[1,2]  R859      -9.8982632160186768e-01
    phi[1,2]  R860      8.0232584476470947e-01
    phi[1,2]  R861      1.7316842079162598e+00
    phi[1,2]  R862      7.3911678791046143e-01
    phi[1,2]  R863      4.2590993642807007e-01
    phi[1,2]  R864      2.5651991367340088e-01
    phi[1,2]  R865      3.1610274314880371e-01
    phi[1,2]  R866      4.0780368447303772e-01
    phi[1,2]  R867      -2.3369871079921722e-01
    phi[1,2]  R868      -6.9420742988586426e-01
    phi[1,2]  R869      1.8794298171997070e+00
    phi[1,2]  R870      1.2809042930603027e+00
    phi[1,2]  R871      -6.8809598684310913e-02
    phi[1,2]  R872      1.2073887139558792e-01
    phi[1,2]  R873      2.1431192755699158e-01
    phi[1,2]  R874      1.9485074281692505e-01
    phi[1,2]  R875      7.3247164487838745e-02
    phi[1,2]  R876      6.8999719619750977e-01
    phi[1,2]  R877      0.905867338180542
    phi[1,2]  R878      2.6969158649444580e+00
    phi[1,2]  R879      2.9463984966278076e+00
    phi[1,2]  R880      3.3854525089263916e+00
    phi[1,2]  R881      2.8374738693237305e+00
    phi[1,2]  R882      1.25606369972229
    phi[1,2]  R883      3.0293586254119873e+00
    phi[1,2]  R884      1.0531582832336426e+00
    phi[1,2]  R885      -7.0544439554214478e-01
    phi[1,2]  R886      3.2444691658020020e+00
    phi[1,2]  R887      -3.3327538967132568e+00
    phi[1,2]  R888      -1.8812834024429321e+00
    phi[1,2]  R889      -2.0100777149200439e+00
    phi[1,2]  R890      -2.3938519954681396e+00
    phi[1,2]  R891      -3.2478559017181396e+00
    phi[1,2]  R892      -3.6781766414642334e+00
    phi[1,2]  R893      -3.1794157028198242e+00
    phi[1,2]  R894      -8.7980324029922485e-01
    phi[1,2]  R895      -2.0299651622772217e+00
    phi[1,2]  R896      -3.0141227245330811e+00
    phi[1,2]  R897      1.1517108678817749e+00
    phi[1,2]  R898      -7.8119492530822754e-01
    phi[1,2]  R899      -2.5020503997802734e+00
    phi[1,2]  R900      -2.7851266860961914e+00
    phi[1,2]  R901      -3.8093159198760986e+00
    phi[1,2]  R902      -4.3751387596130371e+00
    phi[1,2]  R903      1.5700694322586060e+00
    phi[1,2]  R904      -2.1561694145202637e+00
    phi[1,2]  R905      -5.4267221689224243e-01
    phi[1,2]  R906      1.9510507583618164e-01
    phi[1,2]  R907      -1.1272684335708618e+00
    phi[1,2]  R908      -1.1329441070556641e+00
    phi[1,2]  R909      -2.8518109321594238e+00
    phi[1,2]  R910      -2.35213565826416
    phi[1,2]  R911      -1.6555424928665161e+00
    phi[1,2]  R912      1.2153778225183487e-01
    phi[1,2]  R913      1.7305892705917358e-01
    phi[1,2]  R914      -2.9955041408538818e+00
    phi[1,2]  R915      -2.0863366127014160e+00
    phi[1,2]  R916      -2.5343406200408936e+00
    phi[1,2]  R917      -2.1005580425262451e+00
    phi[1,2]  R918      1.4810546636581421e+00
    phi[1,2]  R919      -2.4977650642395020e+00
    phi[1,2]  R920      -2.59702205657959
    phi[1,2]  R921      -0.987958550453186
    phi[1,2]  R922      -1.0829851627349854e+00
    phi[1,2]  R923      -1.2768926620483398e+00
    phi[1,2]  R924      3.4231553077697754e+00
    phi[1,2]  R925      3.2463817596435547e+00
    phi[1,2]  R926      2.8668267726898193e+00
    phi[2,1]  R9        -1
    phi[2,1]  R18       1
    phi[2,1]  R19       1
    phi[2,1]  R927      -3.0999999046325684e+00
    phi[2,1]  R928      -3.0999999046325684e+00
    phi[2,1]  R929      -2.2400000095367432e+00
    phi[2,1]  R930      -2.2400000095367432e+00
    phi[2,1]  R931      -3.0999999046325684e+00
    phi[2,1]  R932      -3.0999999046325684e+00
    phi[2,1]  R933      -2.5699999332427979e+00
    phi[2,1]  R934      -2.5699999332427979e+00
    phi[2,1]  R935      -3.0999999046325684e+00
    phi[2,1]  R936      -3.0999999046325684e+00
    phi[2,1]  R937      -2.0899999141693115e+00
    phi[2,1]  R938      -2.0899999141693115e+00
    phi[2,1]  R939      -3.0999999046325684e+00
    phi[2,1]  R940      -3.0999999046325684e+00
    phi[2,1]  R941      0.905867338180542
    phi[2,1]  R942      2.6969158649444580e+00
    phi[2,1]  R943      2.9463984966278076e+00
    phi[2,1]  R944      3.3854525089263916e+00
    phi[2,1]  R945      2.8374738693237305e+00
    phi[2,1]  R946      1.25606369972229
    phi[2,1]  R947      3.0293586254119873e+00
    phi[2,1]  R948      1.0531582832336426e+00
    phi[2,1]  R949      -7.0544439554214478e-01
    phi[2,1]  R950      3.2444691658020020e+00
    phi[2,1]  R951      -3.3327538967132568e+00
    phi[2,1]  R952      -1.8812834024429321e+00
    phi[2,1]  R953      -2.0100777149200439e+00
    phi[2,1]  R954      -2.3938519954681396e+00
    phi[2,1]  R955      -3.2478559017181396e+00
    phi[2,1]  R956      -3.6781766414642334e+00
    phi[2,1]  R957      -3.1794157028198242e+00
    phi[2,1]  R958      -8.7980324029922485e-01
    phi[2,1]  R959      -2.0299651622772217e+00
    phi[2,1]  R960      -3.0141227245330811e+00
    phi[2,1]  R961      1.1517108678817749e+00
    phi[2,1]  R962      -7.8119492530822754e-01
    phi[2,1]  R963      -2.5020503997802734e+00
    phi[2,1]  R964      -2.7851266860961914e+00
    phi[2,1]  R965      -3.8093159198760986e+00
    phi[2,1]  R966      -4.3751387596130371e+00
    phi[2,1]  R967      1.5700694322586060e+00
    phi[2,1]  R968      -2.1561694145202637e+00
    phi[2,1]  R969      -5.4267221689224243e-01
    phi[2,1]  R970      1.9510507583618164e-01
    phi[2,1]  R971      -1.1272684335708618e+00
    phi[2,1]  R972      -1.1329441070556641e+00
    phi[2,1]  R973      -2.8518109321594238e+00
    phi[2,1]  R974      -2.35213565826416
    phi[2,1]  R975      -1.6555424928665161e+00
    phi[2,1]  R976      1.2153778225183487e-01
    phi[2,1]  R977      1.7305892705917358e-01
    phi[2,1]  R978      -2.9955041408538818e+00
    phi[2,1]  R979      -2.0863366127014160e+00
    phi[2,1]  R980      -2.5343406200408936e+00
    phi[2,1]  R981      -2.1005580425262451e+00
    phi[2,1]  R982      1.4810546636581421e+00
    phi[2,1]  R983      -2.4977650642395020e+00
    phi[2,1]  R984      -2.59702205657959
    phi[2,1]  R985      -0.987958550453186
    phi[2,1]  R986      -1.0829851627349854e+00
    phi[2,1]  R987      -1.2768926620483398e+00
    phi[2,1]  R988      3.4231553077697754e+00
    phi[2,1]  R989      3.2463817596435547e+00
    phi[2,1]  R990      2.8668267726898193e+00
    phi[2,1]  R991      1.1874966621398926e+00
    phi[2,1]  R992      5.2083939313888550e-01
    phi[2,1]  R993      -1.6997894048690796e+00
    phi[2,1]  R994      1.5826981067657471e+00
    phi[2,1]  R995      0.0941983088850975
    phi[2,1]  R996      1.3233355283737183e+00
    phi[2,1]  R997      0.881929337978363
    phi[2,1]  R998      3.4591209888458252e+00
    phi[2,1]  R999      1.1403930932283401e-01
    phi[2,1]  R1000     9.4206124544143677e-01
    phi[2,1]  R1001     -3.9016110897064209e+00
    phi[2,1]  R1002     -2.9241356849670410e+00
    phi[2,1]  R1003     -2.5925626754760742e+00
    phi[2,1]  R1004     -3.1569817066192627e+00
    phi[2,1]  R1005     -4.6144809722900391e+00
    phi[2,1]  R1006     -3.4229400753974915e-01
    phi[2,1]  R1007     -1.7870420217514038e+00
    phi[2,1]  R1008     -3.1353719234466553e+00
    phi[2,1]  R1009     -2.7750325202941895e+00
    phi[2,1]  R1010     1.3081914186477661e+00
    phi[2,1]  R1011     -3.3668060302734375e+00
    phi[2,1]  R1012     -1.48164701461792
    phi[2,1]  R1013     -2.4508244991302490e+00
    phi[2,1]  R1014     -3.2109253406524658e+00
    phi[2,1]  R1015     -2.2541539669036865e+00
    phi[2,1]  R1016     -1.3687264919281006e+00
    phi[2,1]  R1017     -2.7434220314025879e+00
    phi[2,1]  R1018     -3.07222056388855
    phi[2,1]  R1019     1.7537190914154053e+00
    phi[2,1]  R1020     1.6303237676620483e+00
    phi[2,1]  R1021     -1.4082176685333252e+00
    phi[2,1]  R1022     -7.6575976610183716e-01
    phi[2,1]  R1023     -1.3458929061889648e+00
    phi[2,1]  R1024     3.7411174178123474e-01
    phi[2,1]  R1025     -1.0380614995956421e+00
    phi[2,1]  R1026     -2.3804740905761719e+00
    phi[2,1]  R1027     -2.4620616436004639e+00
    phi[2,1]  R1028     -3.7006509304046631e+00
    phi[2,1]  R1029     -3.1751546859741211e+00
    phi[2,1]  R1030     -1.9792488813400269e+00
    phi[2,1]  R1031     -1.1134316921234131e+00
    phi[2,1]  R1032     -1.1269280910491943e+00
    phi[2,1]  R1033     1.2252950668334961e+00
    phi[2,1]  R1034     -1.7295559868216515e-02
    phi[2,1]  R1035     -2.4152715206146240e+00
    phi[2,1]  R1036     4.2217022180557251e-01
    phi[2,1]  R1037     8.7850886583328247e-01
    phi[2,1]  R1038     -3.2569916248321533e+00
    phi[2,1]  R1039     -3.4877049922943115e+00
    phi[2,1]  R1040     -2.9964764118194580e+00
    phi[2,1]  R1041     7.3398929834365845e-01
    phi[2,1]  R1042     -2.5989484786987305e+00
    phi[2,1]  R1043     5.5961877107620239e-01
    phi[2,1]  R1044     -2.8524696826934814e+00
    phi[2,1]  R1045     -2.68194842338562
    phi[2,1]  R1046     -2.1394681930541992e+00
    phi[2,1]  R1047     -2.3897314071655273e+00
    phi[2,1]  R1048     1.9141340255737305e-01
    phi[2,1]  R1049     9.7458338737487793e-01
    phi[2,1]  R1050     -3.4256836771965027e-01
    phi[2,1]  R1051     -7.6971286535263062e-01
    phi[2,1]  R1052     -4.5477727055549622e-01
    phi[2,1]  R1053     1.1410349607467651e-01
    phi[2,1]  R1054     2.8860026597976685e-01
    phi[2,1]  R1055     -1.4300744533538818e+00
    phi[2,1]  R1056     -2.5840611457824707e+00
    phi[2,1]  R1057     -4.0059552192687988e+00
    phi[2,1]  R1058     -2.5718414783477783e+00
    phi[2,1]  R1059     -2.9546194076538086e+00
    phi[2,1]  R1060     -1.6567565500736237e-01
    phi[2,1]  R1061     -9.5090103149414062e-01
    phi[2,1]  R1062     -1.1079283952713013e+00
    phi[2,1]  R1063     -9.8982632160186768e-01
    phi[2,1]  R1064     8.0232584476470947e-01
    phi[2,1]  R1065     1.7316842079162598e+00
    phi[2,1]  R1066     7.3911678791046143e-01
    phi[2,1]  R1067     4.2590993642807007e-01
    phi[2,1]  R1068     2.5651991367340088e-01
    phi[2,1]  R1069     3.1610274314880371e-01
    phi[2,1]  R1070     4.0780368447303772e-01
    phi[2,1]  R1071     -2.3369871079921722e-01
    phi[2,1]  R1072     -6.9420742988586426e-01
    phi[2,1]  R1073     1.8794298171997070e+00
    phi[2,1]  R1074     1.2809042930603027e+00
    phi[2,1]  R1075     -6.8809598684310913e-02
    phi[2,1]  R1076     1.2073887139558792e-01
    phi[2,1]  R1077     2.1431192755699158e-01
    phi[2,1]  R1078     1.9485074281692505e-01
    phi[2,1]  R1079     7.3247164487838745e-02
    phi[2,1]  R1080     6.8999719619750977e-01
    phi[2,3]  R18       1
    phi[2,3]  R19       1
    phi[2,3]  R27       -1
    phi[2,3]  R1081     -3.0999999046325684e+00
    phi[2,3]  R1082     -3.0999999046325684e+00
    phi[2,3]  R1083     -2.2400000095367432e+00
    phi[2,3]  R1084     -2.2400000095367432e+00
    phi[2,3]  R1085     -3.0999999046325684e+00
    phi[2,3]  R1086     -3.0999999046325684e+00
    phi[2,3]  R1087     -2.5699999332427979e+00
    phi[2,3]  R1088     -2.5699999332427979e+00
    phi[2,3]  R1089     -3.0999999046325684e+00
    phi[2,3]  R1090     -3.0999999046325684e+00
    phi[2,3]  R1091     -2.0899999141693115e+00
    phi[2,3]  R1092     -2.0899999141693115e+00
    phi[2,3]  R1093     -3.0999999046325684e+00
    phi[2,3]  R1094     -3.0999999046325684e+00
    phi[2,3]  R1095     0.905867338180542
    phi[2,3]  R1096     2.6969158649444580e+00
    phi[2,3]  R1097     2.9463984966278076e+00
    phi[2,3]  R1098     3.3854525089263916e+00
    phi[2,3]  R1099     2.8374738693237305e+00
    phi[2,3]  R1100     1.25606369972229
    phi[2,3]  R1101     3.0293586254119873e+00
    phi[2,3]  R1102     1.0531582832336426e+00
    phi[2,3]  R1103     -7.0544439554214478e-01
    phi[2,3]  R1104     3.2444691658020020e+00
    phi[2,3]  R1105     -3.3327538967132568e+00
    phi[2,3]  R1106     -1.8812834024429321e+00
    phi[2,3]  R1107     -2.0100777149200439e+00
    phi[2,3]  R1108     -2.3938519954681396e+00
    phi[2,3]  R1109     -3.2478559017181396e+00
    phi[2,3]  R1110     -3.6781766414642334e+00
    phi[2,3]  R1111     -3.1794157028198242e+00
    phi[2,3]  R1112     -8.7980324029922485e-01
    phi[2,3]  R1113     -2.0299651622772217e+00
    phi[2,3]  R1114     -3.0141227245330811e+00
    phi[2,3]  R1115     1.1517108678817749e+00
    phi[2,3]  R1116     -7.8119492530822754e-01
    phi[2,3]  R1117     -2.5020503997802734e+00
    phi[2,3]  R1118     -2.7851266860961914e+00
    phi[2,3]  R1119     -3.8093159198760986e+00
    phi[2,3]  R1120     -4.3751387596130371e+00
    phi[2,3]  R1121     1.5700694322586060e+00
    phi[2,3]  R1122     -2.1561694145202637e+00
    phi[2,3]  R1123     -5.4267221689224243e-01
    phi[2,3]  R1124     1.9510507583618164e-01
    phi[2,3]  R1125     -1.1272684335708618e+00
    phi[2,3]  R1126     -1.1329441070556641e+00
    phi[2,3]  R1127     -2.8518109321594238e+00
    phi[2,3]  R1128     -2.35213565826416
    phi[2,3]  R1129     -1.6555424928665161e+00
    phi[2,3]  R1130     1.2153778225183487e-01
    phi[2,3]  R1131     1.7305892705917358e-01
    phi[2,3]  R1132     -2.9955041408538818e+00
    phi[2,3]  R1133     -2.0863366127014160e+00
    phi[2,3]  R1134     -2.5343406200408936e+00
    phi[2,3]  R1135     -2.1005580425262451e+00
    phi[2,3]  R1136     1.4810546636581421e+00
    phi[2,3]  R1137     -2.4977650642395020e+00
    phi[2,3]  R1138     -2.59702205657959
    phi[2,3]  R1139     -0.987958550453186
    phi[2,3]  R1140     -1.0829851627349854e+00
    phi[2,3]  R1141     -1.2768926620483398e+00
    phi[2,3]  R1142     3.4231553077697754e+00
    phi[2,3]  R1143     3.2463817596435547e+00
    phi[2,3]  R1144     2.8668267726898193e+00
    phi[2,3]  R1145     3.3472101688385010e+00
    phi[2,3]  R1146     1.3084985017776489e+00
    phi[2,3]  R1147     2.0079648494720459e+00
    phi[2,3]  R1148     8.1774353981018066e-01
    phi[2,3]  R1149     -0.475978821516037
    phi[2,3]  R1150     1.4620501995086670e+00
    phi[2,3]  R1151     1.6063314676284790e+00
    phi[2,3]  R1152     1.0907442569732666e+00
    phi[2,3]  R1153     -2.9691624641418457e-01
    phi[2,3]  R1154     0.71807861328125
    phi[2,3]  R1155     -1.0853511095046997e+00
    phi[2,3]  R1156     -1.0113013982772827e+00
    phi[2,3]  R1157     -1.0803729295730591e+00
    phi[2,3]  R1158     -2.2517018318176270e+00
    phi[2,3]  R1159     -0.941821813583374
    phi[2,3]  R1160     -1.7487556934356689e+00
    phi[2,3]  R1161     -1.3687537908554077e+00
    phi[2,3]  R1162     -1.9885156154632568e+00
    phi[2,3]  R1163     -1.2804843187332153e+00
    phi[2,3]  R1164     -2.6465651988983154e+00
    phi[2,3]  R1165     5.8292299509048462e-01
    phi[2,3]  R1166     1.0333803892135620e+00
    phi[2,3]  R1167     1.6533536911010742e+00
    phi[2,3]  R1168     3.3055528998374939e-01
    phi[2,3]  R1169     -8.4623742103576660e-01
    phi[2,3]  R1170     1.7898873984813690e-01
    phi[2,3]  R1171     -7.7188891172409058e-01
    phi[2,3]  R1172     1.1617679595947266e+00
    phi[2,3]  R1173     -8.1293195486068726e-01
    phi[2,3]  R1174     1.2716345489025116e-01
    phi[2,3]  R1175     7.3049122095108032e-01
    phi[2,3]  R1176     -0.580988347530365
    phi[2,3]  R1177     3.6772155761718750e-01
    phi[2,3]  R1178     -1.5389579534530640e+00
    phi[2,3]  R1179     -3.1108215451240540e-01
    phi[2,3]  R1180     -2.14025616645813
    phi[2,3]  R1181     7.9058343172073364e-01
    phi[2,3]  R1182     3.8353833556175232e-01
    phi[2,3]  R1183     6.7698067426681519e-01
    phi[2,3]  R1184     1.5233312845230103e+00
    phi[2,3]  R1185     -2.0604968070983887e+00
    phi[2,3]  R1186     -7.1972668170928955e-01
    phi[2,3]  R1187     1.7803077697753906e+00
    phi[2,3]  R1188     -2.9981181621551514e+00
    phi[2,3]  R1189     -2.6410202980041504e+00
    phi[2,3]  R1190     -7.5139951705932617e-01
    phi[2,3]  R1191     -2.1478869915008545e+00
    phi[2,3]  R1192     -3.0063352584838867e+00
    phi[2,3]  R1193     -3.3105671405792236e+00
    phi[2,3]  R1194     -2.0319457054138184e+00
    phi[2,3]  R1195     -1.5181496143341064e+00
    phi[2,3]  R1196     5.9606772661209106e-01
    phi[2,3]  R1197     1.7837435007095337e+00
    phi[2,3]  R1198     8.2801789045333862e-01
    phi[2,3]  R1199     -5.6969958543777466e-01
    phi[2,3]  R1200     -3.82307767868042
    phi[2,3]  R1201     -3.5161182880401611e+00
    phi[2,3]  R1202     -4.2280626296997070e+00
    phi[2,3]  R1203     -4.5355324745178223e+00
    phi[2,3]  R1204     -3.6421120166778564e+00
    phi[3,2]  R18       -1
    phi[3,2]  R27       1
    phi[3,2]  R28       1
    phi[3,2]  R1205     -3.0999999046325684e+00
    phi[3,2]  R1206     -3.0999999046325684e+00
    phi[3,2]  R1207     -2.2400000095367432e+00
    phi[3,2]  R1208     -2.2400000095367432e+00
    phi[3,2]  R1209     -3.0999999046325684e+00
    phi[3,2]  R1210     -3.0999999046325684e+00
    phi[3,2]  R1211     -2.5699999332427979e+00
    phi[3,2]  R1212     -2.5699999332427979e+00
    phi[3,2]  R1213     -3.0999999046325684e+00
    phi[3,2]  R1214     -3.0999999046325684e+00
    phi[3,2]  R1215     -2.0899999141693115e+00
    phi[3,2]  R1216     -2.0899999141693115e+00
    phi[3,2]  R1217     -3.0999999046325684e+00
    phi[3,2]  R1218     -3.0999999046325684e+00
    phi[3,2]  R1219     3.3472101688385010e+00
    phi[3,2]  R1220     1.3084985017776489e+00
    phi[3,2]  R1221     2.0079648494720459e+00
    phi[3,2]  R1222     8.1774353981018066e-01
    phi[3,2]  R1223     -0.475978821516037
    phi[3,2]  R1224     1.4620501995086670e+00
    phi[3,2]  R1225     1.6063314676284790e+00
    phi[3,2]  R1226     1.0907442569732666e+00
    phi[3,2]  R1227     -2.9691624641418457e-01
    phi[3,2]  R1228     0.71807861328125
    phi[3,2]  R1229     -1.0853511095046997e+00
    phi[3,2]  R1230     -1.0113013982772827e+00
    phi[3,2]  R1231     -1.0803729295730591e+00
    phi[3,2]  R1232     -2.2517018318176270e+00
    phi[3,2]  R1233     -0.941821813583374
    phi[3,2]  R1234     -1.7487556934356689e+00
    phi[3,2]  R1235     -1.3687537908554077e+00
    phi[3,2]  R1236     -1.9885156154632568e+00
    phi[3,2]  R1237     -1.2804843187332153e+00
    phi[3,2]  R1238     -2.6465651988983154e+00
    phi[3,2]  R1239     5.8292299509048462e-01
    phi[3,2]  R1240     1.0333803892135620e+00
    phi[3,2]  R1241     1.6533536911010742e+00
    phi[3,2]  R1242     3.3055528998374939e-01
    phi[3,2]  R1243     -8.4623742103576660e-01
    phi[3,2]  R1244     1.7898873984813690e-01
    phi[3,2]  R1245     -7.7188891172409058e-01
    phi[3,2]  R1246     1.1617679595947266e+00
    phi[3,2]  R1247     -8.1293195486068726e-01
    phi[3,2]  R1248     1.2716345489025116e-01
    phi[3,2]  R1249     7.3049122095108032e-01
    phi[3,2]  R1250     -0.580988347530365
    phi[3,2]  R1251     3.6772155761718750e-01
    phi[3,2]  R1252     -1.5389579534530640e+00
    phi[3,2]  R1253     -3.1108215451240540e-01
    phi[3,2]  R1254     -2.14025616645813
    phi[3,2]  R1255     7.9058343172073364e-01
    phi[3,2]  R1256     3.8353833556175232e-01
    phi[3,2]  R1257     6.7698067426681519e-01
    phi[3,2]  R1258     1.5233312845230103e+00
    phi[3,2]  R1259     -2.0604968070983887e+00
    phi[3,2]  R1260     -7.1972668170928955e-01
    phi[3,2]  R1261     1.7803077697753906e+00
    phi[3,2]  R1262     -2.9981181621551514e+00
    phi[3,2]  R1263     -2.6410202980041504e+00
    phi[3,2]  R1264     -7.5139951705932617e-01
    phi[3,2]  R1265     -2.1478869915008545e+00
    phi[3,2]  R1266     -3.0063352584838867e+00
    phi[3,2]  R1267     -3.3105671405792236e+00
    phi[3,2]  R1268     -2.0319457054138184e+00
    phi[3,2]  R1269     -1.5181496143341064e+00
    phi[3,2]  R1270     5.9606772661209106e-01
    phi[3,2]  R1271     1.7837435007095337e+00
    phi[3,2]  R1272     8.2801789045333862e-01
    phi[3,2]  R1273     -5.6969958543777466e-01
    phi[3,2]  R1274     -3.82307767868042
    phi[3,2]  R1275     -3.5161182880401611e+00
    phi[3,2]  R1276     -4.2280626296997070e+00
    phi[3,2]  R1277     -4.5355324745178223e+00
    phi[3,2]  R1278     -3.6421120166778564e+00
    phi[3,2]  R1279     0.905867338180542
    phi[3,2]  R1280     2.6969158649444580e+00
    phi[3,2]  R1281     2.9463984966278076e+00
    phi[3,2]  R1282     3.3854525089263916e+00
    phi[3,2]  R1283     2.8374738693237305e+00
    phi[3,2]  R1284     1.25606369972229
    phi[3,2]  R1285     3.0293586254119873e+00
    phi[3,2]  R1286     1.0531582832336426e+00
    phi[3,2]  R1287     -7.0544439554214478e-01
    phi[3,2]  R1288     3.2444691658020020e+00
    phi[3,2]  R1289     -3.3327538967132568e+00
    phi[3,2]  R1290     -1.8812834024429321e+00
    phi[3,2]  R1291     -2.0100777149200439e+00
    phi[3,2]  R1292     -2.3938519954681396e+00
    phi[3,2]  R1293     -3.2478559017181396e+00
    phi[3,2]  R1294     -3.6781766414642334e+00
    phi[3,2]  R1295     -3.1794157028198242e+00
    phi[3,2]  R1296     -8.7980324029922485e-01
    phi[3,2]  R1297     -2.0299651622772217e+00
    phi[3,2]  R1298     -3.0141227245330811e+00
    phi[3,2]  R1299     1.1517108678817749e+00
    phi[3,2]  R1300     -7.8119492530822754e-01
    phi[3,2]  R1301     -2.5020503997802734e+00
    phi[3,2]  R1302     -2.7851266860961914e+00
    phi[3,2]  R1303     -3.8093159198760986e+00
    phi[3,2]  R1304     -4.3751387596130371e+00
    phi[3,2]  R1305     1.5700694322586060e+00
    phi[3,2]  R1306     -2.1561694145202637e+00
    phi[3,2]  R1307     -5.4267221689224243e-01
    phi[3,2]  R1308     1.9510507583618164e-01
    phi[3,2]  R1309     -1.1272684335708618e+00
    phi[3,2]  R1310     -1.1329441070556641e+00
    phi[3,2]  R1311     -2.8518109321594238e+00
    phi[3,2]  R1312     -2.35213565826416
    phi[3,2]  R1313     -1.6555424928665161e+00
    phi[3,2]  R1314     1.2153778225183487e-01
    phi[3,2]  R1315     1.7305892705917358e-01
    phi[3,2]  R1316     -2.9955041408538818e+00
    phi[3,2]  R1317     -2.0863366127014160e+00
    phi[3,2]  R1318     -2.5343406200408936e+00
    phi[3,2]  R1319     -2.1005580425262451e+00
    phi[3,2]  R1320     1.4810546636581421e+00
    phi[3,2]  R1321     -2.4977650642395020e+00
    phi[3,2]  R1322     -2.59702205657959
    phi[3,2]  R1323     -0.987958550453186
    phi[3,2]  R1324     -1.0829851627349854e+00
    phi[3,2]  R1325     -1.2768926620483398e+00
    phi[3,2]  R1326     3.4231553077697754e+00
    phi[3,2]  R1327     3.2463817596435547e+00
    phi[3,2]  R1328     2.8668267726898193e+00
    phi[2,8]  R18       1
    phi[2,8]  R19       1
    phi[2,8]  R72       -1
    phi[2,8]  R1329     -3.0999999046325684e+00
    phi[2,8]  R1330     -3.0999999046325684e+00
    phi[2,8]  R1331     -2.2400000095367432e+00
    phi[2,8]  R1332     -2.2400000095367432e+00
    phi[2,8]  R1333     -3.0999999046325684e+00
    phi[2,8]  R1334     -3.0999999046325684e+00
    phi[2,8]  R1335     -2.5699999332427979e+00
    phi[2,8]  R1336     -2.5699999332427979e+00
    phi[2,8]  R1337     -3.0999999046325684e+00
    phi[2,8]  R1338     -3.0999999046325684e+00
    phi[2,8]  R1339     -2.0899999141693115e+00
    phi[2,8]  R1340     -2.0899999141693115e+00
    phi[2,8]  R1341     -3.0999999046325684e+00
    phi[2,8]  R1342     -3.0999999046325684e+00
    phi[2,8]  R1343     0.905867338180542
    phi[2,8]  R1344     2.6969158649444580e+00
    phi[2,8]  R1345     2.9463984966278076e+00
    phi[2,8]  R1346     3.3854525089263916e+00
    phi[2,8]  R1347     2.8374738693237305e+00
    phi[2,8]  R1348     1.25606369972229
    phi[2,8]  R1349     3.0293586254119873e+00
    phi[2,8]  R1350     1.0531582832336426e+00
    phi[2,8]  R1351     -7.0544439554214478e-01
    phi[2,8]  R1352     3.2444691658020020e+00
    phi[2,8]  R1353     -3.3327538967132568e+00
    phi[2,8]  R1354     -1.8812834024429321e+00
    phi[2,8]  R1355     -2.0100777149200439e+00
    phi[2,8]  R1356     -2.3938519954681396e+00
    phi[2,8]  R1357     -3.2478559017181396e+00
    phi[2,8]  R1358     -3.6781766414642334e+00
    phi[2,8]  R1359     -3.1794157028198242e+00
    phi[2,8]  R1360     -8.7980324029922485e-01
    phi[2,8]  R1361     -2.0299651622772217e+00
    phi[2,8]  R1362     -3.0141227245330811e+00
    phi[2,8]  R1363     1.1517108678817749e+00
    phi[2,8]  R1364     -7.8119492530822754e-01
    phi[2,8]  R1365     -2.5020503997802734e+00
    phi[2,8]  R1366     -2.7851266860961914e+00
    phi[2,8]  R1367     -3.8093159198760986e+00
    phi[2,8]  R1368     -4.3751387596130371e+00
    phi[2,8]  R1369     1.5700694322586060e+00
    phi[2,8]  R1370     -2.1561694145202637e+00
    phi[2,8]  R1371     -5.4267221689224243e-01
    phi[2,8]  R1372     1.9510507583618164e-01
    phi[2,8]  R1373     -1.1272684335708618e+00
    phi[2,8]  R1374     -1.1329441070556641e+00
    phi[2,8]  R1375     -2.8518109321594238e+00
    phi[2,8]  R1376     -2.35213565826416
    phi[2,8]  R1377     -1.6555424928665161e+00
    phi[2,8]  R1378     1.2153778225183487e-01
    phi[2,8]  R1379     1.7305892705917358e-01
    phi[2,8]  R1380     -2.9955041408538818e+00
    phi[2,8]  R1381     -2.0863366127014160e+00
    phi[2,8]  R1382     -2.5343406200408936e+00
    phi[2,8]  R1383     -2.1005580425262451e+00
    phi[2,8]  R1384     1.4810546636581421e+00
    phi[2,8]  R1385     -2.4977650642395020e+00
    phi[2,8]  R1386     -2.59702205657959
    phi[2,8]  R1387     -0.987958550453186
    phi[2,8]  R1388     -1.0829851627349854e+00
    phi[2,8]  R1389     -1.2768926620483398e+00
    phi[2,8]  R1390     3.4231553077697754e+00
    phi[2,8]  R1391     3.2463817596435547e+00
    phi[2,8]  R1392     2.8668267726898193e+00
    phi[2,8]  R1393     2.4659178256988525e+00
    phi[2,8]  R1394     3.3490865230560303e+00
    phi[2,8]  R1395     2.4996743202209473e+00
    phi[2,8]  R1396     2.5079476833343506e+00
    phi[2,8]  R1397     1.29396653175354
    phi[2,8]  R1398     2.78867506980896
    phi[2,8]  R1399     1.9115095138549805e+00
    phi[2,8]  R1400     2.0590593814849854e+00
    phi[2,8]  R1401     2.8269140720367432e+00
    phi[2,8]  R1402     -2.0077536106109619e+00
    phi[2,8]  R1403     -2.0533299446105957e+00
    phi[2,8]  R1404     -1.9196538925170898e+00
    phi[2,8]  R1405     -1.9923603534698486e+00
    phi[2,8]  R1406     -1.9211567640304565e+00
    phi[2,8]  R1407     -1.8253394365310669e+00
    phi[2,8]  R1408     -2.2157876491546631e+00
    phi[2,8]  R1409     -1.5762580633163452e+00
    phi[2,8]  R1410     -2.4873320758342743e-01
    phi[2,8]  R1411     -2.8461503982543945e+00
    phi[2,8]  R1412     -7.6862621307373047e-01
    phi[2,8]  R1413     -6.4954203367233276e-01
    phi[2,8]  R1414     -3.4282701015472412e+00
    phi[2,8]  R1415     -3.9427180290222168e+00
    phi[2,8]  R1416     -4.2678065299987793e+00
    phi[2,8]  R1417     -3.0079858303070068e+00
    phi[2,8]  R1418     -3.0631160736083984e+00
    phi[2,8]  R1419     -1.46782648563385
    phi[2,8]  R1420     -3.0336687564849854e+00
    phi[2,8]  R1421     -3.8640193939208984e+00
    phi[2,8]  R1422     -3.2943956851959229e+00
    phi[2,8]  R1423     -1.1611177921295166e+00
    phi[2,8]  R1424     -5.7986313104629517e-01
    phi[2,8]  R1425     -1.9690148830413818e+00
    phi[2,8]  R1426     -8.2362568378448486e-01
    phi[2,8]  R1427     -6.1290186643600464e-01
    phi[2,8]  R1428     -4.0394032001495361e-01
    phi[2,8]  R1429     -1.3289914131164551e+00
    phi[2,8]  R1430     -8.8191002607345581e-01
    phi[2,8]  R1431     -1.0642046928405762e+00
    phi[2,8]  R1432     -3.0060732364654541e+00
    phi[2,8]  R1433     -1.0136628150939941e+00
    phi[2,8]  R1434     -5.7547622919082642e-01
    phi[2,8]  R1435     -2.0504245758056641e+00
    phi[2,8]  R1436     -3.5017967224121094e+00
    phi[2,8]  R1437     8.2845389842987061e-01
    phi[2,8]  R1438     -3.8474166393280029e+00
    phi[2,8]  R1439     -2.5357415676116943e+00
    phi[2,8]  R1440     -4.0705734491348267e-01
    phi[2,8]  R1441     -5.5479627847671509e-01
    phi[2,8]  R1442     -1.3401981592178345e+00
    phi[2,8]  R1443     2.2928394377231598e-01
    phi[2,8]  R1444     -1.3102151155471802e+00
    phi[2,8]  R1445     -2.6002879142761230e+00
    phi[2,8]  R1446     -1.1289610862731934e+00
    phi[2,8]  R1447     -4.5500600337982178e-01
    phi[2,8]  R1448     1.2885019779205322e+00
    phi[2,8]  R1449     1.6775111854076385e-01
    phi[2,8]  R1450     -8.9445686340332031e-01
    phi[2,8]  R1451     -0.572439968585968
    phi[2,8]  R1452     -4.0689194202423096e-01
    phi[2,8]  R1453     -5.3437036275863647e-01
    phi[2,8]  R1454     -3.1713981628417969e+00
    phi[2,8]  R1455     -1.8277709484100342e+00
    phi[2,8]  R1456     -2.3546919822692871e+00
    phi[2,8]  R1457     0.659534215927124
    phi[2,8]  R1458     -1.1701400279998779e+00
    phi[2,8]  R1459     6.1644750833511353e-01
    phi[2,8]  R1460     -1.9318168163299561e+00
    phi[2,8]  R1461     -3.9235424995422363e+00
    phi[2,8]  R1462     -1.4194416999816895e+00
    phi[2,8]  R1463     -1.4656705856323242e+00
    phi[2,8]  R1464     -1.6552976369857788e+00
    phi[2,8]  R1465     5.2774280309677124e-01
    phi[2,8]  R1466     -1.5542395114898682e+00
    phi[2,8]  R1467     -1.0921399593353271e+00
    phi[2,8]  R1468     -1.8403857946395874e+00
    phi[2,8]  R1469     5.6455695629119873e-01
    phi[2,8]  R1470     -5.8117306232452393e-01
    phi[2,8]  R1471     -1.3469942808151245e+00
    phi[2,8]  R1472     -1.0223016738891602e+00
    phi[8,2]  R18       -1
    phi[8,2]  R72       1
    phi[8,2]  R73       1
    phi[8,2]  R1473     -3.0999999046325684e+00
    phi[8,2]  R1474     -3.0999999046325684e+00
    phi[8,2]  R1475     -2.2400000095367432e+00
    phi[8,2]  R1476     -2.2400000095367432e+00
    phi[8,2]  R1477     -3.0999999046325684e+00
    phi[8,2]  R1478     -3.0999999046325684e+00
    phi[8,2]  R1479     -2.5699999332427979e+00
    phi[8,2]  R1480     -2.5699999332427979e+00
    phi[8,2]  R1481     -3.0999999046325684e+00
    phi[8,2]  R1482     -3.0999999046325684e+00
    phi[8,2]  R1483     -2.0899999141693115e+00
    phi[8,2]  R1484     -2.0899999141693115e+00
    phi[8,2]  R1485     -3.0999999046325684e+00
    phi[8,2]  R1486     -3.0999999046325684e+00
    phi[8,2]  R1487     2.4659178256988525e+00
    phi[8,2]  R1488     3.3490865230560303e+00
    phi[8,2]  R1489     2.4996743202209473e+00
    phi[8,2]  R1490     2.5079476833343506e+00
    phi[8,2]  R1491     1.29396653175354
    phi[8,2]  R1492     2.78867506980896
    phi[8,2]  R1493     1.9115095138549805e+00
    phi[8,2]  R1494     2.0590593814849854e+00
    phi[8,2]  R1495     2.8269140720367432e+00
    phi[8,2]  R1496     -2.0077536106109619e+00
    phi[8,2]  R1497     -2.0533299446105957e+00
    phi[8,2]  R1498     -1.9196538925170898e+00
    phi[8,2]  R1499     -1.9923603534698486e+00
    phi[8,2]  R1500     -1.9211567640304565e+00
    phi[8,2]  R1501     -1.8253394365310669e+00
    phi[8,2]  R1502     -2.2157876491546631e+00
    phi[8,2]  R1503     -1.5762580633163452e+00
    phi[8,2]  R1504     -2.4873320758342743e-01
    phi[8,2]  R1505     -2.8461503982543945e+00
    phi[8,2]  R1506     -7.6862621307373047e-01
    phi[8,2]  R1507     -6.4954203367233276e-01
    phi[8,2]  R1508     -3.4282701015472412e+00
    phi[8,2]  R1509     -3.9427180290222168e+00
    phi[8,2]  R1510     -4.2678065299987793e+00
    phi[8,2]  R1511     -3.0079858303070068e+00
    phi[8,2]  R1512     -3.0631160736083984e+00
    phi[8,2]  R1513     -1.46782648563385
    phi[8,2]  R1514     -3.0336687564849854e+00
    phi[8,2]  R1515     -3.8640193939208984e+00
    phi[8,2]  R1516     -3.2943956851959229e+00
    phi[8,2]  R1517     -1.1611177921295166e+00
    phi[8,2]  R1518     -5.7986313104629517e-01
    phi[8,2]  R1519     -1.9690148830413818e+00
    phi[8,2]  R1520     -8.2362568378448486e-01
    phi[8,2]  R1521     -6.1290186643600464e-01
    phi[8,2]  R1522     -4.0394032001495361e-01
    phi[8,2]  R1523     -1.3289914131164551e+00
    phi[8,2]  R1524     -8.8191002607345581e-01
    phi[8,2]  R1525     -1.0642046928405762e+00
    phi[8,2]  R1526     -3.0060732364654541e+00
    phi[8,2]  R1527     -1.0136628150939941e+00
    phi[8,2]  R1528     -5.7547622919082642e-01
    phi[8,2]  R1529     -2.0504245758056641e+00
    phi[8,2]  R1530     -3.5017967224121094e+00
    phi[8,2]  R1531     8.2845389842987061e-01
    phi[8,2]  R1532     -3.8474166393280029e+00
    phi[8,2]  R1533     -2.5357415676116943e+00
    phi[8,2]  R1534     -4.0705734491348267e-01
    phi[8,2]  R1535     -5.5479627847671509e-01
    phi[8,2]  R1536     -1.3401981592178345e+00
    phi[8,2]  R1537     2.2928394377231598e-01
    phi[8,2]  R1538     -1.3102151155471802e+00
    phi[8,2]  R1539     -2.6002879142761230e+00
    phi[8,2]  R1540     -1.1289610862731934e+00
    phi[8,2]  R1541     -4.5500600337982178e-01
    phi[8,2]  R1542     1.2885019779205322e+00
    phi[8,2]  R1543     1.6775111854076385e-01
    phi[8,2]  R1544     -8.9445686340332031e-01
    phi[8,2]  R1545     -0.572439968585968
    phi[8,2]  R1546     -4.0689194202423096e-01
    phi[8,2]  R1547     -5.3437036275863647e-01
    phi[8,2]  R1548     -3.1713981628417969e+00
    phi[8,2]  R1549     -1.8277709484100342e+00
    phi[8,2]  R1550     -2.3546919822692871e+00
    phi[8,2]  R1551     0.659534215927124
    phi[8,2]  R1552     -1.1701400279998779e+00
    phi[8,2]  R1553     6.1644750833511353e-01
    phi[8,2]  R1554     -1.9318168163299561e+00
    phi[8,2]  R1555     -3.9235424995422363e+00
    phi[8,2]  R1556     -1.4194416999816895e+00
    phi[8,2]  R1557     -1.4656705856323242e+00
    phi[8,2]  R1558     -1.6552976369857788e+00
    phi[8,2]  R1559     5.2774280309677124e-01
    phi[8,2]  R1560     -1.5542395114898682e+00
    phi[8,2]  R1561     -1.0921399593353271e+00
    phi[8,2]  R1562     -1.8403857946395874e+00
    phi[8,2]  R1563     5.6455695629119873e-01
    phi[8,2]  R1564     -5.8117306232452393e-01
    phi[8,2]  R1565     -1.3469942808151245e+00
    phi[8,2]  R1566     -1.0223016738891602e+00
    phi[8,2]  R1567     0.905867338180542
    phi[8,2]  R1568     2.6969158649444580e+00
    phi[8,2]  R1569     2.9463984966278076e+00
    phi[8,2]  R1570     3.3854525089263916e+00
    phi[8,2]  R1571     2.8374738693237305e+00
    phi[8,2]  R1572     1.25606369972229
    phi[8,2]  R1573     3.0293586254119873e+00
    phi[8,2]  R1574     1.0531582832336426e+00
    phi[8,2]  R1575     -7.0544439554214478e-01
    phi[8,2]  R1576     3.2444691658020020e+00
    phi[8,2]  R1577     -3.3327538967132568e+00
    phi[8,2]  R1578     -1.8812834024429321e+00
    phi[8,2]  R1579     -2.0100777149200439e+00
    phi[8,2]  R1580     -2.3938519954681396e+00
    phi[8,2]  R1581     -3.2478559017181396e+00
    phi[8,2]  R1582     -3.6781766414642334e+00
    phi[8,2]  R1583     -3.1794157028198242e+00
    phi[8,2]  R1584     -8.7980324029922485e-01
    phi[8,2]  R1585     -2.0299651622772217e+00
    phi[8,2]  R1586     -3.0141227245330811e+00
    phi[8,2]  R1587     1.1517108678817749e+00
    phi[8,2]  R1588     -7.8119492530822754e-01
    phi[8,2]  R1589     -2.5020503997802734e+00
    phi[8,2]  R1590     -2.7851266860961914e+00
    phi[8,2]  R1591     -3.8093159198760986e+00
    phi[8,2]  R1592     -4.3751387596130371e+00
    phi[8,2]  R1593     1.5700694322586060e+00
    phi[8,2]  R1594     -2.1561694145202637e+00
    phi[8,2]  R1595     -5.4267221689224243e-01
    phi[8,2]  R1596     1.9510507583618164e-01
    phi[8,2]  R1597     -1.1272684335708618e+00
    phi[8,2]  R1598     -1.1329441070556641e+00
    phi[8,2]  R1599     -2.8518109321594238e+00
    phi[8,2]  R1600     -2.35213565826416
    phi[8,2]  R1601     -1.6555424928665161e+00
    phi[8,2]  R1602     1.2153778225183487e-01
    phi[8,2]  R1603     1.7305892705917358e-01
    phi[8,2]  R1604     -2.9955041408538818e+00
    phi[8,2]  R1605     -2.0863366127014160e+00
    phi[8,2]  R1606     -2.5343406200408936e+00
    phi[8,2]  R1607     -2.1005580425262451e+00
    phi[8,2]  R1608     1.4810546636581421e+00
    phi[8,2]  R1609     -2.4977650642395020e+00
    phi[8,2]  R1610     -2.59702205657959
    phi[8,2]  R1611     -0.987958550453186
    phi[8,2]  R1612     -1.0829851627349854e+00
    phi[8,2]  R1613     -1.2768926620483398e+00
    phi[8,2]  R1614     3.4231553077697754e+00
    phi[8,2]  R1615     3.2463817596435547e+00
    phi[8,2]  R1616     2.8668267726898193e+00
    phi[3,4]  R27       1
    phi[3,4]  R28       1
    phi[3,4]  R36       -1
    phi[3,4]  R1617     -3.0999999046325684e+00
    phi[3,4]  R1618     -3.0999999046325684e+00
    phi[3,4]  R1619     -2.2400000095367432e+00
    phi[3,4]  R1620     -2.2400000095367432e+00
    phi[3,4]  R1621     -3.0999999046325684e+00
    phi[3,4]  R1622     -3.0999999046325684e+00
    phi[3,4]  R1623     -2.5699999332427979e+00
    phi[3,4]  R1624     -2.5699999332427979e+00
    phi[3,4]  R1625     -3.0999999046325684e+00
    phi[3,4]  R1626     -3.0999999046325684e+00
    phi[3,4]  R1627     -2.0899999141693115e+00
    phi[3,4]  R1628     -2.0899999141693115e+00
    phi[3,4]  R1629     -3.0999999046325684e+00
    phi[3,4]  R1630     -3.0999999046325684e+00
    phi[3,4]  R1631     3.3472101688385010e+00
    phi[3,4]  R1632     1.3084985017776489e+00
    phi[3,4]  R1633     2.0079648494720459e+00
    phi[3,4]  R1634     8.1774353981018066e-01
    phi[3,4]  R1635     -0.475978821516037
    phi[3,4]  R1636     1.4620501995086670e+00
    phi[3,4]  R1637     1.6063314676284790e+00
    phi[3,4]  R1638     1.0907442569732666e+00
    phi[3,4]  R1639     -2.9691624641418457e-01
    phi[3,4]  R1640     0.71807861328125
    phi[3,4]  R1641     -1.0853511095046997e+00
    phi[3,4]  R1642     -1.0113013982772827e+00
    phi[3,4]  R1643     -1.0803729295730591e+00
    phi[3,4]  R1644     -2.2517018318176270e+00
    phi[3,4]  R1645     -0.941821813583374
    phi[3,4]  R1646     -1.7487556934356689e+00
    phi[3,4]  R1647     -1.3687537908554077e+00
    phi[3,4]  R1648     -1.9885156154632568e+00
    phi[3,4]  R1649     -1.2804843187332153e+00
    phi[3,4]  R1650     -2.6465651988983154e+00
    phi[3,4]  R1651     5.8292299509048462e-01
    phi[3,4]  R1652     1.0333803892135620e+00
    phi[3,4]  R1653     1.6533536911010742e+00
    phi[3,4]  R1654     3.3055528998374939e-01
    phi[3,4]  R1655     -8.4623742103576660e-01
    phi[3,4]  R1656     1.7898873984813690e-01
    phi[3,4]  R1657     -7.7188891172409058e-01
    phi[3,4]  R1658     1.1617679595947266e+00
    phi[3,4]  R1659     -8.1293195486068726e-01
    phi[3,4]  R1660     1.2716345489025116e-01
    phi[3,4]  R1661     7.3049122095108032e-01
    phi[3,4]  R1662     -0.580988347530365
    phi[3,4]  R1663     3.6772155761718750e-01
    phi[3,4]  R1664     -1.5389579534530640e+00
    phi[3,4]  R1665     -3.1108215451240540e-01
    phi[3,4]  R1666     -2.14025616645813
    phi[3,4]  R1667     7.9058343172073364e-01
    phi[3,4]  R1668     3.8353833556175232e-01
    phi[3,4]  R1669     6.7698067426681519e-01
    phi[3,4]  R1670     1.5233312845230103e+00
    phi[3,4]  R1671     -2.0604968070983887e+00
    phi[3,4]  R1672     -7.1972668170928955e-01
    phi[3,4]  R1673     1.7803077697753906e+00
    phi[3,4]  R1674     -2.9981181621551514e+00
    phi[3,4]  R1675     -2.6410202980041504e+00
    phi[3,4]  R1676     -7.5139951705932617e-01
    phi[3,4]  R1677     -2.1478869915008545e+00
    phi[3,4]  R1678     -3.0063352584838867e+00
    phi[3,4]  R1679     -3.3105671405792236e+00
    phi[3,4]  R1680     -2.0319457054138184e+00
    phi[3,4]  R1681     -1.5181496143341064e+00
    phi[3,4]  R1682     5.9606772661209106e-01
    phi[3,4]  R1683     1.7837435007095337e+00
    phi[3,4]  R1684     8.2801789045333862e-01
    phi[3,4]  R1685     -5.6969958543777466e-01
    phi[3,4]  R1686     -3.82307767868042
    phi[3,4]  R1687     -3.5161182880401611e+00
    phi[3,4]  R1688     -4.2280626296997070e+00
    phi[3,4]  R1689     -4.5355324745178223e+00
    phi[3,4]  R1690     -3.6421120166778564e+00
    phi[3,4]  R1691     2.4554170668125153e-01
    phi[3,4]  R1692     2.0015807151794434e+00
    phi[3,4]  R1693     2.7209651470184326e-01
    phi[3,4]  R1694     9.1127502918243408e-01
    phi[3,4]  R1695     2.6279065012931824e-01
    phi[3,4]  R1696     1.8250066041946411e+00
    phi[3,4]  R1697     2.3525445461273193e+00
    phi[3,4]  R1698     -1.6637399196624756e+00
    phi[3,4]  R1699     1.6145361661911011e+00
    phi[3,4]  R1700     1.8228259086608887e+00
    phi[3,4]  R1701     -3.1709613800048828e+00
    phi[3,4]  R1702     -1.9620960950851440e+00
    phi[3,4]  R1703     -2.4418601989746094e+00
    phi[3,4]  R1704     -1.7502965927124023e+00
    phi[3,4]  R1705     -2.3642110824584961e+00
    phi[3,4]  R1706     1.8210785090923309e-01
    phi[3,4]  R1707     -1.7012616395950317e+00
    phi[3,4]  R1708     -1.3297581672668457e+00
    phi[3,4]  R1709     -1.4885883331298828e+00
    phi[3,4]  R1710     -6.2500774860382080e-01
    phi[3,4]  R1711     -1.1465466022491455e+00
    phi[3,4]  R1712     -3.0107921361923218e-01
    phi[3,4]  R1713     -3.3391624689102173e-01
    phi[3,4]  R1714     -5.0472670793533325e-01
    phi[3,4]  R1715     -5.0474262237548828e-01
    phi[3,4]  R1716     -9.4780218601226807e-01
    phi[3,4]  R1717     -8.0716520547866821e-02
    phi[3,4]  R1718     8.9250475168228149e-01
    phi[3,4]  R1719     -8.1894034147262573e-01
    phi[3,4]  R1720     -8.7835514545440674e-01
    phi[3,4]  R1721     -1.4548428058624268e+00
    phi[3,4]  R1722     -1.1421382427215576e-01
    phi[3,4]  R1723     -0.00703435018658638
    phi[3,4]  R1724     -1.0831748247146606e+00
    phi[3,4]  R1725     -1.3969817161560059e+00
    phi[3,4]  R1726     1.0149409770965576e+00
    phi[3,4]  R1727     -2.08876633644104
    phi[3,4]  R1728     2.0022043585777283e-01
    phi[3,4]  R1729     8.3592301607131958e-01
    phi[3,4]  R1730     3.3752602338790894e-01
    phi[3,4]  R1731     -2.7087352275848389e+00
    phi[3,4]  R1732     -1.6288059949874878e-01
    phi[3,4]  R1733     -2.1067297458648682e+00
    phi[3,4]  R1734     7.2264093160629272e-01
    phi[3,4]  R1735     2.1823601722717285e+00
    phi[3,4]  R1736     0.365295946598053
    phi[3,4]  R1737     2.2231190204620361e+00
    phi[3,4]  R1738     1.8392943143844604e+00
    phi[3,4]  R1739     1.3159852027893066e+00
    phi[3,4]  R1740     2.2020010948181152e+00
    phi[4,3]  R27       -1
    phi[4,3]  R36       1
    phi[4,3]  R37       1
    phi[4,3]  R1741     -3.0999999046325684e+00
    phi[4,3]  R1742     -3.0999999046325684e+00
    phi[4,3]  R1743     -2.2400000095367432e+00
    phi[4,3]  R1744     -2.2400000095367432e+00
    phi[4,3]  R1745     -3.0999999046325684e+00
    phi[4,3]  R1746     -3.0999999046325684e+00
    phi[4,3]  R1747     -2.5699999332427979e+00
    phi[4,3]  R1748     -2.5699999332427979e+00
    phi[4,3]  R1749     -3.0999999046325684e+00
    phi[4,3]  R1750     -3.0999999046325684e+00
    phi[4,3]  R1751     -2.0899999141693115e+00
    phi[4,3]  R1752     -2.0899999141693115e+00
    phi[4,3]  R1753     -3.0999999046325684e+00
    phi[4,3]  R1754     -3.0999999046325684e+00
    phi[4,3]  R1755     2.4554170668125153e-01
    phi[4,3]  R1756     2.0015807151794434e+00
    phi[4,3]  R1757     2.7209651470184326e-01
    phi[4,3]  R1758     9.1127502918243408e-01
    phi[4,3]  R1759     2.6279065012931824e-01
    phi[4,3]  R1760     1.8250066041946411e+00
    phi[4,3]  R1761     2.3525445461273193e+00
    phi[4,3]  R1762     -1.6637399196624756e+00
    phi[4,3]  R1763     1.6145361661911011e+00
    phi[4,3]  R1764     1.8228259086608887e+00
    phi[4,3]  R1765     -3.1709613800048828e+00
    phi[4,3]  R1766     -1.9620960950851440e+00
    phi[4,3]  R1767     -2.4418601989746094e+00
    phi[4,3]  R1768     -1.7502965927124023e+00
    phi[4,3]  R1769     -2.3642110824584961e+00
    phi[4,3]  R1770     1.8210785090923309e-01
    phi[4,3]  R1771     -1.7012616395950317e+00
    phi[4,3]  R1772     -1.3297581672668457e+00
    phi[4,3]  R1773     -1.4885883331298828e+00
    phi[4,3]  R1774     -6.2500774860382080e-01
    phi[4,3]  R1775     -1.1465466022491455e+00
    phi[4,3]  R1776     -3.0107921361923218e-01
    phi[4,3]  R1777     -3.3391624689102173e-01
    phi[4,3]  R1778     -5.0472670793533325e-01
    phi[4,3]  R1779     -5.0474262237548828e-01
    phi[4,3]  R1780     -9.4780218601226807e-01
    phi[4,3]  R1781     -8.0716520547866821e-02
    phi[4,3]  R1782     8.9250475168228149e-01
    phi[4,3]  R1783     -8.1894034147262573e-01
    phi[4,3]  R1784     -8.7835514545440674e-01
    phi[4,3]  R1785     -1.4548428058624268e+00
    phi[4,3]  R1786     -1.1421382427215576e-01
    phi[4,3]  R1787     -0.00703435018658638
    phi[4,3]  R1788     -1.0831748247146606e+00
    phi[4,3]  R1789     -1.3969817161560059e+00
    phi[4,3]  R1790     1.0149409770965576e+00
    phi[4,3]  R1791     -2.08876633644104
    phi[4,3]  R1792     2.0022043585777283e-01
    phi[4,3]  R1793     8.3592301607131958e-01
    phi[4,3]  R1794     3.3752602338790894e-01
    phi[4,3]  R1795     -2.7087352275848389e+00
    phi[4,3]  R1796     -1.6288059949874878e-01
    phi[4,3]  R1797     -2.1067297458648682e+00
    phi[4,3]  R1798     7.2264093160629272e-01
    phi[4,3]  R1799     2.1823601722717285e+00
    phi[4,3]  R1800     0.365295946598053
    phi[4,3]  R1801     2.2231190204620361e+00
    phi[4,3]  R1802     1.8392943143844604e+00
    phi[4,3]  R1803     1.3159852027893066e+00
    phi[4,3]  R1804     2.2020010948181152e+00
    phi[4,3]  R1805     3.3472101688385010e+00
    phi[4,3]  R1806     1.3084985017776489e+00
    phi[4,3]  R1807     2.0079648494720459e+00
    phi[4,3]  R1808     8.1774353981018066e-01
    phi[4,3]  R1809     -0.475978821516037
    phi[4,3]  R1810     1.4620501995086670e+00
    phi[4,3]  R1811     1.6063314676284790e+00
    phi[4,3]  R1812     1.0907442569732666e+00
    phi[4,3]  R1813     -2.9691624641418457e-01
    phi[4,3]  R1814     0.71807861328125
    phi[4,3]  R1815     -1.0853511095046997e+00
    phi[4,3]  R1816     -1.0113013982772827e+00
    phi[4,3]  R1817     -1.0803729295730591e+00
    phi[4,3]  R1818     -2.2517018318176270e+00
    phi[4,3]  R1819     -0.941821813583374
    phi[4,3]  R1820     -1.7487556934356689e+00
    phi[4,3]  R1821     -1.3687537908554077e+00
    phi[4,3]  R1822     -1.9885156154632568e+00
    phi[4,3]  R1823     -1.2804843187332153e+00
    phi[4,3]  R1824     -2.6465651988983154e+00
    phi[4,3]  R1825     5.8292299509048462e-01
    phi[4,3]  R1826     1.0333803892135620e+00
    phi[4,3]  R1827     1.6533536911010742e+00
    phi[4,3]  R1828     3.3055528998374939e-01
    phi[4,3]  R1829     -8.4623742103576660e-01
    phi[4,3]  R1830     1.7898873984813690e-01
    phi[4,3]  R1831     -7.7188891172409058e-01
    phi[4,3]  R1832     1.1617679595947266e+00
    phi[4,3]  R1833     -8.1293195486068726e-01
    phi[4,3]  R1834     1.2716345489025116e-01
    phi[4,3]  R1835     7.3049122095108032e-01
    phi[4,3]  R1836     -0.580988347530365
    phi[4,3]  R1837     3.6772155761718750e-01
    phi[4,3]  R1838     -1.5389579534530640e+00
    phi[4,3]  R1839     -3.1108215451240540e-01
    phi[4,3]  R1840     -2.14025616645813
    phi[4,3]  R1841     7.9058343172073364e-01
    phi[4,3]  R1842     3.8353833556175232e-01
    phi[4,3]  R1843     6.7698067426681519e-01
    phi[4,3]  R1844     1.5233312845230103e+00
    phi[4,3]  R1845     -2.0604968070983887e+00
    phi[4,3]  R1846     -7.1972668170928955e-01
    phi[4,3]  R1847     1.7803077697753906e+00
    phi[4,3]  R1848     -2.9981181621551514e+00
    phi[4,3]  R1849     -2.6410202980041504e+00
    phi[4,3]  R1850     -7.5139951705932617e-01
    phi[4,3]  R1851     -2.1478869915008545e+00
    phi[4,3]  R1852     -3.0063352584838867e+00
    phi[4,3]  R1853     -3.3105671405792236e+00
    phi[4,3]  R1854     -2.0319457054138184e+00
    phi[4,3]  R1855     -1.5181496143341064e+00
    phi[4,3]  R1856     5.9606772661209106e-01
    phi[4,3]  R1857     1.7837435007095337e+00
    phi[4,3]  R1858     8.2801789045333862e-01
    phi[4,3]  R1859     -5.6969958543777466e-01
    phi[4,3]  R1860     -3.82307767868042
    phi[4,3]  R1861     -3.5161182880401611e+00
    phi[4,3]  R1862     -4.2280626296997070e+00
    phi[4,3]  R1863     -4.5355324745178223e+00
    phi[4,3]  R1864     -3.6421120166778564e+00
    phi[3,8]  R27       1
    phi[3,8]  R28       1
    phi[3,8]  R72       -1
    phi[3,8]  R1865     -3.0999999046325684e+00
    phi[3,8]  R1866     -3.0999999046325684e+00
    phi[3,8]  R1867     -2.2400000095367432e+00
    phi[3,8]  R1868     -2.2400000095367432e+00
    phi[3,8]  R1869     -3.0999999046325684e+00
    phi[3,8]  R1870     -3.0999999046325684e+00
    phi[3,8]  R1871     -2.5699999332427979e+00
    phi[3,8]  R1872     -2.5699999332427979e+00
    phi[3,8]  R1873     -3.0999999046325684e+00
    phi[3,8]  R1874     -3.0999999046325684e+00
    phi[3,8]  R1875     -2.0899999141693115e+00
    phi[3,8]  R1876     -2.0899999141693115e+00
    phi[3,8]  R1877     -3.0999999046325684e+00
    phi[3,8]  R1878     -3.0999999046325684e+00
    phi[3,8]  R1879     3.3472101688385010e+00
    phi[3,8]  R1880     1.3084985017776489e+00
    phi[3,8]  R1881     2.0079648494720459e+00
    phi[3,8]  R1882     8.1774353981018066e-01
    phi[3,8]  R1883     -0.475978821516037
    phi[3,8]  R1884     1.4620501995086670e+00
    phi[3,8]  R1885     1.6063314676284790e+00
    phi[3,8]  R1886     1.0907442569732666e+00
    phi[3,8]  R1887     -2.9691624641418457e-01
    phi[3,8]  R1888     0.71807861328125
    phi[3,8]  R1889     -1.0853511095046997e+00
    phi[3,8]  R1890     -1.0113013982772827e+00
    phi[3,8]  R1891     -1.0803729295730591e+00
    phi[3,8]  R1892     -2.2517018318176270e+00
    phi[3,8]  R1893     -0.941821813583374
    phi[3,8]  R1894     -1.7487556934356689e+00
    phi[3,8]  R1895     -1.3687537908554077e+00
    phi[3,8]  R1896     -1.9885156154632568e+00
    phi[3,8]  R1897     -1.2804843187332153e+00
    phi[3,8]  R1898     -2.6465651988983154e+00
    phi[3,8]  R1899     5.8292299509048462e-01
    phi[3,8]  R1900     1.0333803892135620e+00
    phi[3,8]  R1901     1.6533536911010742e+00
    phi[3,8]  R1902     3.3055528998374939e-01
    phi[3,8]  R1903     -8.4623742103576660e-01
    phi[3,8]  R1904     1.7898873984813690e-01
    phi[3,8]  R1905     -7.7188891172409058e-01
    phi[3,8]  R1906     1.1617679595947266e+00
    phi[3,8]  R1907     -8.1293195486068726e-01
    phi[3,8]  R1908     1.2716345489025116e-01
    phi[3,8]  R1909     7.3049122095108032e-01
    phi[3,8]  R1910     -0.580988347530365
    phi[3,8]  R1911     3.6772155761718750e-01
    phi[3,8]  R1912     -1.5389579534530640e+00
    phi[3,8]  R1913     -3.1108215451240540e-01
    phi[3,8]  R1914     -2.14025616645813
    phi[3,8]  R1915     7.9058343172073364e-01
    phi[3,8]  R1916     3.8353833556175232e-01
    phi[3,8]  R1917     6.7698067426681519e-01
    phi[3,8]  R1918     1.5233312845230103e+00
    phi[3,8]  R1919     -2.0604968070983887e+00
    phi[3,8]  R1920     -7.1972668170928955e-01
    phi[3,8]  R1921     1.7803077697753906e+00
    phi[3,8]  R1922     -2.9981181621551514e+00
    phi[3,8]  R1923     -2.6410202980041504e+00
    phi[3,8]  R1924     -7.5139951705932617e-01
    phi[3,8]  R1925     -2.1478869915008545e+00
    phi[3,8]  R1926     -3.0063352584838867e+00
    phi[3,8]  R1927     -3.3105671405792236e+00
    phi[3,8]  R1928     -2.0319457054138184e+00
    phi[3,8]  R1929     -1.5181496143341064e+00
    phi[3,8]  R1930     5.9606772661209106e-01
    phi[3,8]  R1931     1.7837435007095337e+00
    phi[3,8]  R1932     8.2801789045333862e-01
    phi[3,8]  R1933     -5.6969958543777466e-01
    phi[3,8]  R1934     -3.82307767868042
    phi[3,8]  R1935     -3.5161182880401611e+00
    phi[3,8]  R1936     -4.2280626296997070e+00
    phi[3,8]  R1937     -4.5355324745178223e+00
    phi[3,8]  R1938     -3.6421120166778564e+00
    phi[3,8]  R1939     2.4659178256988525e+00
    phi[3,8]  R1940     3.3490865230560303e+00
    phi[3,8]  R1941     2.4996743202209473e+00
    phi[3,8]  R1942     2.5079476833343506e+00
    phi[3,8]  R1943     1.29396653175354
    phi[3,8]  R1944     2.78867506980896
    phi[3,8]  R1945     1.9115095138549805e+00
    phi[3,8]  R1946     2.0590593814849854e+00
    phi[3,8]  R1947     2.8269140720367432e+00
    phi[3,8]  R1948     -2.0077536106109619e+00
    phi[3,8]  R1949     -2.0533299446105957e+00
    phi[3,8]  R1950     -1.9196538925170898e+00
    phi[3,8]  R1951     -1.9923603534698486e+00
    phi[3,8]  R1952     -1.9211567640304565e+00
    phi[3,8]  R1953     -1.8253394365310669e+00
    phi[3,8]  R1954     -2.2157876491546631e+00
    phi[3,8]  R1955     -1.5762580633163452e+00
    phi[3,8]  R1956     -2.4873320758342743e-01
    phi[3,8]  R1957     -2.8461503982543945e+00
    phi[3,8]  R1958     -7.6862621307373047e-01
    phi[3,8]  R1959     -6.4954203367233276e-01
    phi[3,8]  R1960     -3.4282701015472412e+00
    phi[3,8]  R1961     -3.9427180290222168e+00
    phi[3,8]  R1962     -4.2678065299987793e+00
    phi[3,8]  R1963     -3.0079858303070068e+00
    phi[3,8]  R1964     -3.0631160736083984e+00
    phi[3,8]  R1965     -1.46782648563385
    phi[3,8]  R1966     -3.0336687564849854e+00
    phi[3,8]  R1967     -3.8640193939208984e+00
    phi[3,8]  R1968     -3.2943956851959229e+00
    phi[3,8]  R1969     -1.1611177921295166e+00
    phi[3,8]  R1970     -5.7986313104629517e-01
    phi[3,8]  R1971     -1.9690148830413818e+00
    phi[3,8]  R1972     -8.2362568378448486e-01
    phi[3,8]  R1973     -6.1290186643600464e-01
    phi[3,8]  R1974     -4.0394032001495361e-01
    phi[3,8]  R1975     -1.3289914131164551e+00
    phi[3,8]  R1976     -8.8191002607345581e-01
    phi[3,8]  R1977     -1.0642046928405762e+00
    phi[3,8]  R1978     -3.0060732364654541e+00
    phi[3,8]  R1979     -1.0136628150939941e+00
    phi[3,8]  R1980     -5.7547622919082642e-01
    phi[3,8]  R1981     -2.0504245758056641e+00
    phi[3,8]  R1982     -3.5017967224121094e+00
    phi[3,8]  R1983     8.2845389842987061e-01
    phi[3,8]  R1984     -3.8474166393280029e+00
    phi[3,8]  R1985     -2.5357415676116943e+00
    phi[3,8]  R1986     -4.0705734491348267e-01
    phi[3,8]  R1987     -5.5479627847671509e-01
    phi[3,8]  R1988     -1.3401981592178345e+00
    phi[3,8]  R1989     2.2928394377231598e-01
    phi[3,8]  R1990     -1.3102151155471802e+00
    phi[3,8]  R1991     -2.6002879142761230e+00
    phi[3,8]  R1992     -1.1289610862731934e+00
    phi[3,8]  R1993     -4.5500600337982178e-01
    phi[3,8]  R1994     1.2885019779205322e+00
    phi[3,8]  R1995     1.6775111854076385e-01
    phi[3,8]  R1996     -8.9445686340332031e-01
    phi[3,8]  R1997     -0.572439968585968
    phi[3,8]  R1998     -4.0689194202423096e-01
    phi[3,8]  R1999     -5.3437036275863647e-01
    phi[3,8]  R2000     -3.1713981628417969e+00
    phi[3,8]  R2001     -1.8277709484100342e+00
    phi[3,8]  R2002     -2.3546919822692871e+00
    phi[3,8]  R2003     0.659534215927124
    phi[3,8]  R2004     -1.1701400279998779e+00
    phi[3,8]  R2005     6.1644750833511353e-01
    phi[3,8]  R2006     -1.9318168163299561e+00
    phi[3,8]  R2007     -3.9235424995422363e+00
    phi[3,8]  R2008     -1.4194416999816895e+00
    phi[3,8]  R2009     -1.4656705856323242e+00
    phi[3,8]  R2010     -1.6552976369857788e+00
    phi[3,8]  R2011     5.2774280309677124e-01
    phi[3,8]  R2012     -1.5542395114898682e+00
    phi[3,8]  R2013     -1.0921399593353271e+00
    phi[3,8]  R2014     -1.8403857946395874e+00
    phi[3,8]  R2015     5.6455695629119873e-01
    phi[3,8]  R2016     -5.8117306232452393e-01
    phi[3,8]  R2017     -1.3469942808151245e+00
    phi[3,8]  R2018     -1.0223016738891602e+00
    phi[8,3]  R27       -1
    phi[8,3]  R72       1
    phi[8,3]  R73       1
    phi[8,3]  R2019     -3.0999999046325684e+00
    phi[8,3]  R2020     -3.0999999046325684e+00
    phi[8,3]  R2021     -2.2400000095367432e+00
    phi[8,3]  R2022     -2.2400000095367432e+00
    phi[8,3]  R2023     -3.0999999046325684e+00
    phi[8,3]  R2024     -3.0999999046325684e+00
    phi[8,3]  R2025     -2.5699999332427979e+00
    phi[8,3]  R2026     -2.5699999332427979e+00
    phi[8,3]  R2027     -3.0999999046325684e+00
    phi[8,3]  R2028     -3.0999999046325684e+00
    phi[8,3]  R2029     -2.0899999141693115e+00
    phi[8,3]  R2030     -2.0899999141693115e+00
    phi[8,3]  R2031     -3.0999999046325684e+00
    phi[8,3]  R2032     -3.0999999046325684e+00
    phi[8,3]  R2033     2.4659178256988525e+00
    phi[8,3]  R2034     3.3490865230560303e+00
    phi[8,3]  R2035     2.4996743202209473e+00
    phi[8,3]  R2036     2.5079476833343506e+00
    phi[8,3]  R2037     1.29396653175354
    phi[8,3]  R2038     2.78867506980896
    phi[8,3]  R2039     1.9115095138549805e+00
    phi[8,3]  R2040     2.0590593814849854e+00
    phi[8,3]  R2041     2.8269140720367432e+00
    phi[8,3]  R2042     -2.0077536106109619e+00
    phi[8,3]  R2043     -2.0533299446105957e+00
    phi[8,3]  R2044     -1.9196538925170898e+00
    phi[8,3]  R2045     -1.9923603534698486e+00
    phi[8,3]  R2046     -1.9211567640304565e+00
    phi[8,3]  R2047     -1.8253394365310669e+00
    phi[8,3]  R2048     -2.2157876491546631e+00
    phi[8,3]  R2049     -1.5762580633163452e+00
    phi[8,3]  R2050     -2.4873320758342743e-01
    phi[8,3]  R2051     -2.8461503982543945e+00
    phi[8,3]  R2052     -7.6862621307373047e-01
    phi[8,3]  R2053     -6.4954203367233276e-01
    phi[8,3]  R2054     -3.4282701015472412e+00
    phi[8,3]  R2055     -3.9427180290222168e+00
    phi[8,3]  R2056     -4.2678065299987793e+00
    phi[8,3]  R2057     -3.0079858303070068e+00
    phi[8,3]  R2058     -3.0631160736083984e+00
    phi[8,3]  R2059     -1.46782648563385
    phi[8,3]  R2060     -3.0336687564849854e+00
    phi[8,3]  R2061     -3.8640193939208984e+00
    phi[8,3]  R2062     -3.2943956851959229e+00
    phi[8,3]  R2063     -1.1611177921295166e+00
    phi[8,3]  R2064     -5.7986313104629517e-01
    phi[8,3]  R2065     -1.9690148830413818e+00
    phi[8,3]  R2066     -8.2362568378448486e-01
    phi[8,3]  R2067     -6.1290186643600464e-01
    phi[8,3]  R2068     -4.0394032001495361e-01
    phi[8,3]  R2069     -1.3289914131164551e+00
    phi[8,3]  R2070     -8.8191002607345581e-01
    phi[8,3]  R2071     -1.0642046928405762e+00
    phi[8,3]  R2072     -3.0060732364654541e+00
    phi[8,3]  R2073     -1.0136628150939941e+00
    phi[8,3]  R2074     -5.7547622919082642e-01
    phi[8,3]  R2075     -2.0504245758056641e+00
    phi[8,3]  R2076     -3.5017967224121094e+00
    phi[8,3]  R2077     8.2845389842987061e-01
    phi[8,3]  R2078     -3.8474166393280029e+00
    phi[8,3]  R2079     -2.5357415676116943e+00
    phi[8,3]  R2080     -4.0705734491348267e-01
    phi[8,3]  R2081     -5.5479627847671509e-01
    phi[8,3]  R2082     -1.3401981592178345e+00
    phi[8,3]  R2083     2.2928394377231598e-01
    phi[8,3]  R2084     -1.3102151155471802e+00
    phi[8,3]  R2085     -2.6002879142761230e+00
    phi[8,3]  R2086     -1.1289610862731934e+00
    phi[8,3]  R2087     -4.5500600337982178e-01
    phi[8,3]  R2088     1.2885019779205322e+00
    phi[8,3]  R2089     1.6775111854076385e-01
    phi[8,3]  R2090     -8.9445686340332031e-01
    phi[8,3]  R2091     -0.572439968585968
    phi[8,3]  R2092     -4.0689194202423096e-01
    phi[8,3]  R2093     -5.3437036275863647e-01
    phi[8,3]  R2094     -3.1713981628417969e+00
    phi[8,3]  R2095     -1.8277709484100342e+00
    phi[8,3]  R2096     -2.3546919822692871e+00
    phi[8,3]  R2097     0.659534215927124
    phi[8,3]  R2098     -1.1701400279998779e+00
    phi[8,3]  R2099     6.1644750833511353e-01
    phi[8,3]  R2100     -1.9318168163299561e+00
    phi[8,3]  R2101     -3.9235424995422363e+00
    phi[8,3]  R2102     -1.4194416999816895e+00
    phi[8,3]  R2103     -1.4656705856323242e+00
    phi[8,3]  R2104     -1.6552976369857788e+00
    phi[8,3]  R2105     5.2774280309677124e-01
    phi[8,3]  R2106     -1.5542395114898682e+00
    phi[8,3]  R2107     -1.0921399593353271e+00
    phi[8,3]  R2108     -1.8403857946395874e+00
    phi[8,3]  R2109     5.6455695629119873e-01
    phi[8,3]  R2110     -5.8117306232452393e-01
    phi[8,3]  R2111     -1.3469942808151245e+00
    phi[8,3]  R2112     -1.0223016738891602e+00
    phi[8,3]  R2113     3.3472101688385010e+00
    phi[8,3]  R2114     1.3084985017776489e+00
    phi[8,3]  R2115     2.0079648494720459e+00
    phi[8,3]  R2116     8.1774353981018066e-01
    phi[8,3]  R2117     -0.475978821516037
    phi[8,3]  R2118     1.4620501995086670e+00
    phi[8,3]  R2119     1.6063314676284790e+00
    phi[8,3]  R2120     1.0907442569732666e+00
    phi[8,3]  R2121     -2.9691624641418457e-01
    phi[8,3]  R2122     0.71807861328125
    phi[8,3]  R2123     -1.0853511095046997e+00
    phi[8,3]  R2124     -1.0113013982772827e+00
    phi[8,3]  R2125     -1.0803729295730591e+00
    phi[8,3]  R2126     -2.2517018318176270e+00
    phi[8,3]  R2127     -0.941821813583374
    phi[8,3]  R2128     -1.7487556934356689e+00
    phi[8,3]  R2129     -1.3687537908554077e+00
    phi[8,3]  R2130     -1.9885156154632568e+00
    phi[8,3]  R2131     -1.2804843187332153e+00
    phi[8,3]  R2132     -2.6465651988983154e+00
    phi[8,3]  R2133     5.8292299509048462e-01
    phi[8,3]  R2134     1.0333803892135620e+00
    phi[8,3]  R2135     1.6533536911010742e+00
    phi[8,3]  R2136     3.3055528998374939e-01
    phi[8,3]  R2137     -8.4623742103576660e-01
    phi[8,3]  R2138     1.7898873984813690e-01
    phi[8,3]  R2139     -7.7188891172409058e-01
    phi[8,3]  R2140     1.1617679595947266e+00
    phi[8,3]  R2141     -8.1293195486068726e-01
    phi[8,3]  R2142     1.2716345489025116e-01
    phi[8,3]  R2143     7.3049122095108032e-01
    phi[8,3]  R2144     -0.580988347530365
    phi[8,3]  R2145     3.6772155761718750e-01
    phi[8,3]  R2146     -1.5389579534530640e+00
    phi[8,3]  R2147     -3.1108215451240540e-01
    phi[8,3]  R2148     -2.14025616645813
    phi[8,3]  R2149     7.9058343172073364e-01
    phi[8,3]  R2150     3.8353833556175232e-01
    phi[8,3]  R2151     6.7698067426681519e-01
    phi[8,3]  R2152     1.5233312845230103e+00
    phi[8,3]  R2153     -2.0604968070983887e+00
    phi[8,3]  R2154     -7.1972668170928955e-01
    phi[8,3]  R2155     1.7803077697753906e+00
    phi[8,3]  R2156     -2.9981181621551514e+00
    phi[8,3]  R2157     -2.6410202980041504e+00
    phi[8,3]  R2158     -7.5139951705932617e-01
    phi[8,3]  R2159     -2.1478869915008545e+00
    phi[8,3]  R2160     -3.0063352584838867e+00
    phi[8,3]  R2161     -3.3105671405792236e+00
    phi[8,3]  R2162     -2.0319457054138184e+00
    phi[8,3]  R2163     -1.5181496143341064e+00
    phi[8,3]  R2164     5.9606772661209106e-01
    phi[8,3]  R2165     1.7837435007095337e+00
    phi[8,3]  R2166     8.2801789045333862e-01
    phi[8,3]  R2167     -5.6969958543777466e-01
    phi[8,3]  R2168     -3.82307767868042
    phi[8,3]  R2169     -3.5161182880401611e+00
    phi[8,3]  R2170     -4.2280626296997070e+00
    phi[8,3]  R2171     -4.5355324745178223e+00
    phi[8,3]  R2172     -3.6421120166778564e+00
    phi[4,5]  R36       1
    phi[4,5]  R37       1
    phi[4,5]  R45       -1
    phi[4,5]  R2173     -3.0999999046325684e+00
    phi[4,5]  R2174     -3.0999999046325684e+00
    phi[4,5]  R2175     -2.2400000095367432e+00
    phi[4,5]  R2176     -2.2400000095367432e+00
    phi[4,5]  R2177     -3.0999999046325684e+00
    phi[4,5]  R2178     -3.0999999046325684e+00
    phi[4,5]  R2179     -2.5699999332427979e+00
    phi[4,5]  R2180     -2.5699999332427979e+00
    phi[4,5]  R2181     -3.0999999046325684e+00
    phi[4,5]  R2182     -3.0999999046325684e+00
    phi[4,5]  R2183     -2.0899999141693115e+00
    phi[4,5]  R2184     -2.0899999141693115e+00
    phi[4,5]  R2185     -3.0999999046325684e+00
    phi[4,5]  R2186     -3.0999999046325684e+00
    phi[4,5]  R2187     2.4554170668125153e-01
    phi[4,5]  R2188     2.0015807151794434e+00
    phi[4,5]  R2189     2.7209651470184326e-01
    phi[4,5]  R2190     9.1127502918243408e-01
    phi[4,5]  R2191     2.6279065012931824e-01
    phi[4,5]  R2192     1.8250066041946411e+00
    phi[4,5]  R2193     2.3525445461273193e+00
    phi[4,5]  R2194     -1.6637399196624756e+00
    phi[4,5]  R2195     1.6145361661911011e+00
    phi[4,5]  R2196     1.8228259086608887e+00
    phi[4,5]  R2197     -3.1709613800048828e+00
    phi[4,5]  R2198     -1.9620960950851440e+00
    phi[4,5]  R2199     -2.4418601989746094e+00
    phi[4,5]  R2200     -1.7502965927124023e+00
    phi[4,5]  R2201     -2.3642110824584961e+00
    phi[4,5]  R2202     1.8210785090923309e-01
    phi[4,5]  R2203     -1.7012616395950317e+00
    phi[4,5]  R2204     -1.3297581672668457e+00
    phi[4,5]  R2205     -1.4885883331298828e+00
    phi[4,5]  R2206     -6.2500774860382080e-01
    phi[4,5]  R2207     -1.1465466022491455e+00
    phi[4,5]  R2208     -3.0107921361923218e-01
    phi[4,5]  R2209     -3.3391624689102173e-01
    phi[4,5]  R2210     -5.0472670793533325e-01
    phi[4,5]  R2211     -5.0474262237548828e-01
    phi[4,5]  R2212     -9.4780218601226807e-01
    phi[4,5]  R2213     -8.0716520547866821e-02
    phi[4,5]  R2214     8.9250475168228149e-01
    phi[4,5]  R2215     -8.1894034147262573e-01
    phi[4,5]  R2216     -8.7835514545440674e-01
    phi[4,5]  R2217     -1.4548428058624268e+00
    phi[4,5]  R2218     -1.1421382427215576e-01
    phi[4,5]  R2219     -0.00703435018658638
    phi[4,5]  R2220     -1.0831748247146606e+00
    phi[4,5]  R2221     -1.3969817161560059e+00
    phi[4,5]  R2222     1.0149409770965576e+00
    phi[4,5]  R2223     -2.08876633644104
    phi[4,5]  R2224     2.0022043585777283e-01
    phi[4,5]  R2225     8.3592301607131958e-01
    phi[4,5]  R2226     3.3752602338790894e-01
    phi[4,5]  R2227     -2.7087352275848389e+00
    phi[4,5]  R2228     -1.6288059949874878e-01
    phi[4,5]  R2229     -2.1067297458648682e+00
    phi[4,5]  R2230     7.2264093160629272e-01
    phi[4,5]  R2231     2.1823601722717285e+00
    phi[4,5]  R2232     0.365295946598053
    phi[4,5]  R2233     2.2231190204620361e+00
    phi[4,5]  R2234     1.8392943143844604e+00
    phi[4,5]  R2235     1.3159852027893066e+00
    phi[4,5]  R2236     2.2020010948181152e+00
    phi[4,5]  R2237     1.4089076519012451e+00
    phi[4,5]  R2238     5.0157934427261353e-01
    phi[4,5]  R2239     0.856260359287262
    phi[4,5]  R2240     -1.7058482170104980e+00
    phi[4,5]  R2241     1.4688451290130615e+00
    phi[4,5]  R2242     1.9081563949584961e+00
    phi[4,5]  R2243     1.6497502326965332e+00
    phi[4,5]  R2244     -1.2351997941732407e-01
    phi[4,5]  R2245     9.9750292301177979e-01
    phi[4,5]  R2246     1.8146909475326538e+00
    phi[4,5]  R2247     -2.26825213432312
    phi[4,5]  R2248     -3.0364022254943848e+00
    phi[4,5]  R2249     -1.4993966817855835e+00
    phi[4,5]  R2250     -6.7183154821395874e-01
    phi[4,5]  R2251     -8.2764267921447754e-01
    phi[4,5]  R2252     -1.3072822988033295e-01
    phi[4,5]  R2253     -1.4210142195224762e-01
    phi[4,5]  R2254     -6.3594490289688110e-01
    phi[4,5]  R2255     -4.8353064060211182e-01
    phi[4,5]  R2256     1.5891817808151245e+00
    phi[4,5]  R2257     -1.4965319633483887e+00
    phi[4,5]  R2258     -4.5388080179691315e-02
    phi[4,5]  R2259     -1.1536408662796021e+00
    phi[4,5]  R2260     -1.0147856473922729e+00
    phi[4,5]  R2261     3.1286403536796570e-01
    phi[4,5]  R2262     1.1194306612014771e+00
    phi[4,5]  R2263     8.9113295078277588e-01
    phi[4,5]  R2264     4.8250004649162292e-02
    phi[4,5]  R2265     1.1917916536331177e+00
    phi[4,5]  R2266     2.3246276378631592e-01
    phi[5,4]  R36       -1
    phi[5,4]  R45       1
    phi[5,4]  R46       1
    phi[5,4]  R2267     -3.0999999046325684e+00
    phi[5,4]  R2268     -3.0999999046325684e+00
    phi[5,4]  R2269     -2.2400000095367432e+00
    phi[5,4]  R2270     -2.2400000095367432e+00
    phi[5,4]  R2271     -3.0999999046325684e+00
    phi[5,4]  R2272     -3.0999999046325684e+00
    phi[5,4]  R2273     -2.5699999332427979e+00
    phi[5,4]  R2274     -2.5699999332427979e+00
    phi[5,4]  R2275     -3.0999999046325684e+00
    phi[5,4]  R2276     -3.0999999046325684e+00
    phi[5,4]  R2277     -2.0899999141693115e+00
    phi[5,4]  R2278     -2.0899999141693115e+00
    phi[5,4]  R2279     -3.0999999046325684e+00
    phi[5,4]  R2280     -3.0999999046325684e+00
    phi[5,4]  R2281     1.4089076519012451e+00
    phi[5,4]  R2282     5.0157934427261353e-01
    phi[5,4]  R2283     0.856260359287262
    phi[5,4]  R2284     -1.7058482170104980e+00
    phi[5,4]  R2285     1.4688451290130615e+00
    phi[5,4]  R2286     1.9081563949584961e+00
    phi[5,4]  R2287     1.6497502326965332e+00
    phi[5,4]  R2288     -1.2351997941732407e-01
    phi[5,4]  R2289     9.9750292301177979e-01
    phi[5,4]  R2290     1.8146909475326538e+00
    phi[5,4]  R2291     -2.26825213432312
    phi[5,4]  R2292     -3.0364022254943848e+00
    phi[5,4]  R2293     -1.4993966817855835e+00
    phi[5,4]  R2294     -6.7183154821395874e-01
    phi[5,4]  R2295     -8.2764267921447754e-01
    phi[5,4]  R2296     -1.3072822988033295e-01
    phi[5,4]  R2297     -1.4210142195224762e-01
    phi[5,4]  R2298     -6.3594490289688110e-01
    phi[5,4]  R2299     -4.8353064060211182e-01
    phi[5,4]  R2300     1.5891817808151245e+00
    phi[5,4]  R2301     -1.4965319633483887e+00
    phi[5,4]  R2302     -4.5388080179691315e-02
    phi[5,4]  R2303     -1.1536408662796021e+00
    phi[5,4]  R2304     -1.0147856473922729e+00
    phi[5,4]  R2305     3.1286403536796570e-01
    phi[5,4]  R2306     1.1194306612014771e+00
    phi[5,4]  R2307     8.9113295078277588e-01
    phi[5,4]  R2308     4.8250004649162292e-02
    phi[5,4]  R2309     1.1917916536331177e+00
    phi[5,4]  R2310     2.3246276378631592e-01
    phi[5,4]  R2311     2.4554170668125153e-01
    phi[5,4]  R2312     2.0015807151794434e+00
    phi[5,4]  R2313     2.7209651470184326e-01
    phi[5,4]  R2314     9.1127502918243408e-01
    phi[5,4]  R2315     2.6279065012931824e-01
    phi[5,4]  R2316     1.8250066041946411e+00
    phi[5,4]  R2317     2.3525445461273193e+00
    phi[5,4]  R2318     -1.6637399196624756e+00
    phi[5,4]  R2319     1.6145361661911011e+00
    phi[5,4]  R2320     1.8228259086608887e+00
    phi[5,4]  R2321     -3.1709613800048828e+00
    phi[5,4]  R2322     -1.9620960950851440e+00
    phi[5,4]  R2323     -2.4418601989746094e+00
    phi[5,4]  R2324     -1.7502965927124023e+00
    phi[5,4]  R2325     -2.3642110824584961e+00
    phi[5,4]  R2326     1.8210785090923309e-01
    phi[5,4]  R2327     -1.7012616395950317e+00
    phi[5,4]  R2328     -1.3297581672668457e+00
    phi[5,4]  R2329     -1.4885883331298828e+00
    phi[5,4]  R2330     -6.2500774860382080e-01
    phi[5,4]  R2331     -1.1465466022491455e+00
    phi[5,4]  R2332     -3.0107921361923218e-01
    phi[5,4]  R2333     -3.3391624689102173e-01
    phi[5,4]  R2334     -5.0472670793533325e-01
    phi[5,4]  R2335     -5.0474262237548828e-01
    phi[5,4]  R2336     -9.4780218601226807e-01
    phi[5,4]  R2337     -8.0716520547866821e-02
    phi[5,4]  R2338     8.9250475168228149e-01
    phi[5,4]  R2339     -8.1894034147262573e-01
    phi[5,4]  R2340     -8.7835514545440674e-01
    phi[5,4]  R2341     -1.4548428058624268e+00
    phi[5,4]  R2342     -1.1421382427215576e-01
    phi[5,4]  R2343     -0.00703435018658638
    phi[5,4]  R2344     -1.0831748247146606e+00
    phi[5,4]  R2345     -1.3969817161560059e+00
    phi[5,4]  R2346     1.0149409770965576e+00
    phi[5,4]  R2347     -2.08876633644104
    phi[5,4]  R2348     2.0022043585777283e-01
    phi[5,4]  R2349     8.3592301607131958e-01
    phi[5,4]  R2350     3.3752602338790894e-01
    phi[5,4]  R2351     -2.7087352275848389e+00
    phi[5,4]  R2352     -1.6288059949874878e-01
    phi[5,4]  R2353     -2.1067297458648682e+00
    phi[5,4]  R2354     7.2264093160629272e-01
    phi[5,4]  R2355     2.1823601722717285e+00
    phi[5,4]  R2356     0.365295946598053
    phi[5,4]  R2357     2.2231190204620361e+00
    phi[5,4]  R2358     1.8392943143844604e+00
    phi[5,4]  R2359     1.3159852027893066e+00
    phi[5,4]  R2360     2.2020010948181152e+00
    phi[5,10]  R45       1
    phi[5,10]  R46       1
    phi[5,10]  R47       3.0859786346867457e-01
    phi[5,10]  R48       -1.3267881320084234e+00
    phi[5,10]  R49       1.5193867570988120e+00
    phi[5,10]  R50       -3.2639590037716371e-01
    phi[5,10]  R51       1.5392165380217271e+00
    phi[5,10]  R52       -1.6226623347846192e+00
    phi[5,10]  R53       1.3995949929412517e+00
    phi[5,10]  R82       -1
    phi[5,10]  R2361     -2.7914020411638938e+00
    phi[5,10]  R2362     -3.4085977681012429e+00
    phi[5,10]  R2363     -3.5667881415451665e+00
    phi[5,10]  R2364     -9.1321187752831978e-01
    phi[5,10]  R2365     -1.5806131475337564e+00
    phi[5,10]  R2366     -4.61938666173138
    phi[5,10]  R2367     -2.8963958336199616e+00
    phi[5,10]  R2368     -2.2436040328656341e+00
    phi[5,10]  R2369     -1.5607833666108413e+00
    phi[5,10]  R2370     -4.6392164426542957e+00
    phi[5,10]  R2371     -3.7126622489539307e+00
    phi[5,10]  R2372     -4.6733757938469234e-01
    phi[5,10]  R2373     -1.7004049116913167e+00
    phi[5,10]  R2374     -4.49959489757382
    phi[5,10]  R2375     -2.4053825509499638e-01
    phi[5,10]  R2376     -4.5857871613615986e-02
    phi[5,10]  R2377     -6.5753309524060555e-01
    phi[5,10]  R2378     -1.0176190546814041e+00
    phi[5,10]  R2379     -4.9938841366813014e-01
    phi[5,10]  R2380     -4.7923691305776561e-02
    phi[5,10]  R2381     -4.9815080180571236e-02
    phi[5,10]  R2382     -5.8539670735634708e-02
    phi[5,10]  R2383     -5.8856097977276312e-02
    phi[5,10]  R2384     -7.0676348046598214e-01
    phi[5,10]  R2385     -4.6310731365102087e-01
    phi[5,10]  R2386     -2.1362438361278713e-02
    phi[5,10]  R2387     -6.0993541261459061e-02
    phi[5,10]  R2388     -3.5838620084418588e-01
    phi[5,10]  R2389     -7.1978998047661280e-02
    phi[5,10]  R2390     -1.0021839986611897e-01
    phi[5,10]  R2391     -1.1542893198418724e-01
    phi[5,10]  R2392     -1.2877505529867916e-01
    phi[5,10]  R2393     -1.6746621703726927e-01
    phi[5,10]  R2394     -1.9160646979768625e-01
    phi[5,10]  R2395     -0.763766841708778
    phi[5,10]  R2396     -1.4288804351774931e-02
    phi[5,10]  R2397     -2.5656834397033590e-02
    phi[5,10]  R2398     -2.6423781260698775e-02
    phi[5,10]  R2399     -0.0664141496367992
    phi[5,10]  R2400     -1.0087588311024098e-01
    phi[5,10]  R2401     -1.0702681010512483e-01
    phi[5,10]  R2402     -1.0904477476307697e-01
    phi[5,10]  R2403     -1.2287628971174880e-01
    phi[5,10]  R2404     -1.3704821237210585e-01
    phi[6,7]  R54       1
    phi[6,7]  R55       1
    phi[6,7]  R63       -1
    phi[6,7]  R2405     -3.0999999046325684e+00
    phi[6,7]  R2406     -3.0999999046325684e+00
    phi[6,7]  R2407     -2.2400000095367432e+00
    phi[6,7]  R2408     -2.2400000095367432e+00
    phi[6,7]  R2409     -3.0999999046325684e+00
    phi[6,7]  R2410     -3.0999999046325684e+00
    phi[6,7]  R2411     -2.5699999332427979e+00
    phi[6,7]  R2412     -2.5699999332427979e+00
    phi[6,7]  R2413     -3.0999999046325684e+00
    phi[6,7]  R2414     -3.0999999046325684e+00
    phi[6,7]  R2415     -2.0899999141693115e+00
    phi[6,7]  R2416     -2.0899999141693115e+00
    phi[6,7]  R2417     -3.0999999046325684e+00
    phi[6,7]  R2418     -3.0999999046325684e+00
    phi[6,7]  R2419     1.5287969112396240e+00
    phi[6,7]  R2420     1.2251930236816406e+00
    phi[6,7]  R2421     1.8496649265289307e+00
    phi[6,7]  R2422     8.2207804918289185e-01
    phi[6,7]  R2423     3.3011811971664429e-01
    phi[6,7]  R2424     7.6574277877807617e-01
    phi[6,7]  R2425     1.9281120300292969e+00
    phi[6,7]  R2426     2.3882522583007812e+00
    phi[6,7]  R2427     -8.3120399713516235e-01
    phi[6,7]  R2428     2.2273474931716919e-01
    phi[6,7]  R2429     -8.7682509422302246e-01
    phi[6,7]  R2430     2.9664799571037292e-01
    phi[6,7]  R2431     -2.8459697961807251e-01
    phi[6,7]  R2432     -8.1182456016540527e-01
    phi[6,7]  R2433     -1.9324302673339844e-01
    phi[6,7]  R2434     -3.1624674797058105e-01
    phi[6,7]  R2435     -2.1559913158416748e+00
    phi[6,7]  R2436     1.8012432754039764e-01
    phi[6,7]  R2437     -1.1272479295730591e+00
    phi[6,7]  R2438     -2.4805190563201904e+00
    phi[6,7]  R2439     8.8435572385787964e-01
    phi[6,7]  R2440     1.7913125455379486e-02
    phi[6,7]  R2441     7.9076486825942993e-01
    phi[6,7]  R2442     -2.0657274127006531e-01
    phi[6,7]  R2443     5.6026756763458252e-02
    phi[6,7]  R2444     -2.3912830352783203e+00
    phi[6,7]  R2445     -9.1737985610961914e-01
    phi[6,7]  R2446     -2.2055718898773193e+00
    phi[6,7]  R2447     -1.2220654487609863e+00
    phi[6,7]  R2448     -6.4932554960250854e-01
    phi[6,7]  R2449     1.2424324750900269e+00
    phi[6,7]  R2450     -4.4023975729942322e-01
    phi[6,7]  R2451     -1.6559355258941650e+00
    phi[6,7]  R2452     5.7987719774246216e-01
    phi[6,7]  R2453     2.0515391230583191e-01
    phi[6,7]  R2454     -8.1085664033889771e-01
    phi[6,7]  R2455     -1.1087069511413574e+00
    phi[6,7]  R2456     1.1429567337036133e+00
    phi[6,7]  R2457     3.6965510249137878e-01
    phi[6,7]  R2458     -1.0223436355590820e-01
    phi[6,7]  R2459     7.2915619611740112e-01
    phi[6,7]  R2460     -1.5767264366149902e+00
    phi[6,7]  R2461     -1.1388508081436157e+00
    phi[6,7]  R2462     -1.3088898658752441e+00
    phi[6,7]  R2463     -3.1540192663669586e-02
    phi[6,7]  R2464     -1.8435820341110229e+00
    phi[6,7]  R2465     -1.7670247554779053e+00
    phi[6,7]  R2466     -1.93596351146698
    phi[6,7]  R2467     -1.7743901014328003e+00
    phi[6,7]  R2468     -2.748291015625
    phi[6,7]  R2469     -9.0733373165130615e-01
    phi[6,7]  R2470     9.8939800262451172e-01
    phi[6,7]  R2471     -8.1240409612655640e-01
    phi[6,7]  R2472     2.4008347094058990e-01
    phi[6,7]  R2473     -2.2250094413757324e+00
    phi[6,7]  R2474     -2.8969137668609619e+00
    phi[6,7]  R2475     -1.3510568141937256e+00
    phi[6,7]  R2476     -2.2803211212158203e+00
    phi[6,7]  R2477     -2.1561982631683350e+00
    phi[6,7]  R2478     -1.6440916061401367e+00
    phi[6,7]  R2479     -4.7803664207458496e-01
    phi[6,7]  R2480     -5.6152415275573730e-01
    phi[6,7]  R2481     0.789250910282135
    phi[6,7]  R2482     -1.8148900270462036e+00
    phi[6,7]  R2483     -1.43842613697052
    phi[6,7]  R2484     -1.4285249710083008e+00
    phi[6,7]  R2485     -2.6473522186279297e+00
    phi[6,7]  R2486     -1.8664598464965820e+00
    phi[6,7]  R2487     -2.1407809257507324e+00
    phi[6,7]  R2488     -3.3944652080535889e+00
    phi[6,7]  R2489     1.7752698659896851e+00
    phi[6,7]  R2490     1.5124298334121704e+00
    phi[6,7]  R2491     2.2887554168701172e+00
    phi[6,7]  R2492     1.0413560867309570e+00
    phi[6,7]  R2493     1.5172356367111206e+00
    phi[6,7]  R2494     1.6747601032257080e+00
    phi[6,7]  R2495     8.3849179744720459e-01
    phi[6,7]  R2496     1.2317837476730347e+00
    phi[6,7]  R2497     2.8787943720817566e-01
    phi[6,7]  R2498     -0.153577983379364
    phi[6,7]  R2499     -1.4564617872238159e+00
    phi[6,7]  R2500     -3.6475213365741972e+00
    phi[6,7]  R2501     -4.6489146351814270e-01
    phi[6,7]  R2502     -2.7162692546844482e+00
    phi[6,7]  R2503     -2.6751253604888916e+00
    phi[6,7]  R2504     -1.0896718502044678e+00
    phi[6,7]  R2505     -2.2703313827514648e+00
    phi[6,7]  R2506     1.6885892152786255e+00
    phi[6,7]  R2507     -4.3220141530036926e-01
    phi[6,7]  R2508     -1.4374911785125732e+00
    phi[6,7]  R2509     -1.7562206983566284e+00
    phi[6,7]  R2510     -2.4429554939270020e+00
    phi[6,7]  R2511     -1.6784943342208862e+00
    phi[6,7]  R2512     -1.6507213935256004e-02
    phi[6,7]  R2513     1.8147727251052856e+00
    phi[6,7]  R2514     -9.0340659022331238e-02
    phi[7,6]  R54       -1
    phi[7,6]  R63       1
    phi[7,6]  R64       1
    phi[7,6]  R2515     -3.0999999046325684e+00
    phi[7,6]  R2516     -3.0999999046325684e+00
    phi[7,6]  R2517     -2.2400000095367432e+00
    phi[7,6]  R2518     -2.2400000095367432e+00
    phi[7,6]  R2519     -3.0999999046325684e+00
    phi[7,6]  R2520     -3.0999999046325684e+00
    phi[7,6]  R2521     -2.5699999332427979e+00
    phi[7,6]  R2522     -2.5699999332427979e+00
    phi[7,6]  R2523     -3.0999999046325684e+00
    phi[7,6]  R2524     -3.0999999046325684e+00
    phi[7,6]  R2525     -2.0899999141693115e+00
    phi[7,6]  R2526     -2.0899999141693115e+00
    phi[7,6]  R2527     -3.0999999046325684e+00
    phi[7,6]  R2528     -3.0999999046325684e+00
    phi[7,6]  R2529     1.7752698659896851e+00
    phi[7,6]  R2530     1.5124298334121704e+00
    phi[7,6]  R2531     2.2887554168701172e+00
    phi[7,6]  R2532     1.0413560867309570e+00
    phi[7,6]  R2533     1.5172356367111206e+00
    phi[7,6]  R2534     1.6747601032257080e+00
    phi[7,6]  R2535     8.3849179744720459e-01
    phi[7,6]  R2536     1.2317837476730347e+00
    phi[7,6]  R2537     2.8787943720817566e-01
    phi[7,6]  R2538     -0.153577983379364
    phi[7,6]  R2539     -1.4564617872238159e+00
    phi[7,6]  R2540     -3.6475213365741972e+00
    phi[7,6]  R2541     -4.6489146351814270e-01
    phi[7,6]  R2542     -2.7162692546844482e+00
    phi[7,6]  R2543     -2.6751253604888916e+00
    phi[7,6]  R2544     -1.0896718502044678e+00
    phi[7,6]  R2545     -2.2703313827514648e+00
    phi[7,6]  R2546     1.6885892152786255e+00
    phi[7,6]  R2547     -4.3220141530036926e-01
    phi[7,6]  R2548     -1.4374911785125732e+00
    phi[7,6]  R2549     -1.7562206983566284e+00
    phi[7,6]  R2550     -2.4429554939270020e+00
    phi[7,6]  R2551     -1.6784943342208862e+00
    phi[7,6]  R2552     -1.6507213935256004e-02
    phi[7,6]  R2553     1.8147727251052856e+00
    phi[7,6]  R2554     -9.0340659022331238e-02
    phi[7,6]  R2555     1.5287969112396240e+00
    phi[7,6]  R2556     1.2251930236816406e+00
    phi[7,6]  R2557     1.8496649265289307e+00
    phi[7,6]  R2558     8.2207804918289185e-01
    phi[7,6]  R2559     3.3011811971664429e-01
    phi[7,6]  R2560     7.6574277877807617e-01
    phi[7,6]  R2561     1.9281120300292969e+00
    phi[7,6]  R2562     2.3882522583007812e+00
    phi[7,6]  R2563     -8.3120399713516235e-01
    phi[7,6]  R2564     2.2273474931716919e-01
    phi[7,6]  R2565     -8.7682509422302246e-01
    phi[7,6]  R2566     2.9664799571037292e-01
    phi[7,6]  R2567     -2.8459697961807251e-01
    phi[7,6]  R2568     -8.1182456016540527e-01
    phi[7,6]  R2569     -1.9324302673339844e-01
    phi[7,6]  R2570     -3.1624674797058105e-01
    phi[7,6]  R2571     -2.1559913158416748e+00
    phi[7,6]  R2572     1.8012432754039764e-01
    phi[7,6]  R2573     -1.1272479295730591e+00
    phi[7,6]  R2574     -2.4805190563201904e+00
    phi[7,6]  R2575     8.8435572385787964e-01
    phi[7,6]  R2576     1.7913125455379486e-02
    phi[7,6]  R2577     7.9076486825942993e-01
    phi[7,6]  R2578     -2.0657274127006531e-01
    phi[7,6]  R2579     5.6026756763458252e-02
    phi[7,6]  R2580     -2.3912830352783203e+00
    phi[7,6]  R2581     -9.1737985610961914e-01
    phi[7,6]  R2582     -2.2055718898773193e+00
    phi[7,6]  R2583     -1.2220654487609863e+00
    phi[7,6]  R2584     -6.4932554960250854e-01
    phi[7,6]  R2585     1.2424324750900269e+00
    phi[7,6]  R2586     -4.4023975729942322e-01
    phi[7,6]  R2587     -1.6559355258941650e+00
    phi[7,6]  R2588     5.7987719774246216e-01
    phi[7,6]  R2589     2.0515391230583191e-01
    phi[7,6]  R2590     -8.1085664033889771e-01
    phi[7,6]  R2591     -1.1087069511413574e+00
    phi[7,6]  R2592     1.1429567337036133e+00
    phi[7,6]  R2593     3.6965510249137878e-01
    phi[7,6]  R2594     -1.0223436355590820e-01
    phi[7,6]  R2595     7.2915619611740112e-01
    phi[7,6]  R2596     -1.5767264366149902e+00
    phi[7,6]  R2597     -1.1388508081436157e+00
    phi[7,6]  R2598     -1.3088898658752441e+00
    phi[7,6]  R2599     -3.1540192663669586e-02
    phi[7,6]  R2600     -1.8435820341110229e+00
    phi[7,6]  R2601     -1.7670247554779053e+00
    phi[7,6]  R2602     -1.93596351146698
    phi[7,6]  R2603     -1.7743901014328003e+00
    phi[7,6]  R2604     -2.748291015625
    phi[7,6]  R2605     -9.0733373165130615e-01
    phi[7,6]  R2606     9.8939800262451172e-01
    phi[7,6]  R2607     -8.1240409612655640e-01
    phi[7,6]  R2608     2.4008347094058990e-01
    phi[7,6]  R2609     -2.2250094413757324e+00
    phi[7,6]  R2610     -2.8969137668609619e+00
    phi[7,6]  R2611     -1.3510568141937256e+00
    phi[7,6]  R2612     -2.2803211212158203e+00
    phi[7,6]  R2613     -2.1561982631683350e+00
    phi[7,6]  R2614     -1.6440916061401367e+00
    phi[7,6]  R2615     -4.7803664207458496e-01
    phi[7,6]  R2616     -5.6152415275573730e-01
    phi[7,6]  R2617     0.789250910282135
    phi[7,6]  R2618     -1.8148900270462036e+00
    phi[7,6]  R2619     -1.43842613697052
    phi[7,6]  R2620     -1.4285249710083008e+00
    phi[7,6]  R2621     -2.6473522186279297e+00
    phi[7,6]  R2622     -1.8664598464965820e+00
    phi[7,6]  R2623     -2.1407809257507324e+00
    phi[7,6]  R2624     -3.3944652080535889e+00
    phi[9,6]  R54       -1
    phi[9,6]  R56       -1.3662186085443053e+00
    phi[9,6]  R57       1.7399764913263560e-02
    phi[9,6]  R58       -6.4662269535883610e-01
    phi[9,6]  R59       -1.4391404286847327e+00
    phi[9,6]  R60       7.1012939330827551e-01
    phi[9,6]  R61       3.6219531726647070e-01
    phi[9,6]  R62       2.0850263072532003e+00
    phi[9,6]  R81       1
    phi[9,6]  R2625     -1.7337812960882630e+00
    phi[9,6]  R2626     -4.4662185131768739e+00
    phi[9,6]  R2627     -2.2573997744500067e+00
    phi[9,6]  R2628     -2.2226002446234796e+00
    phi[9,6]  R2629     -2.4533772092737323e+00
    phi[9,6]  R2630     -3.7466225999914045e+00
    phi[9,6]  R2631     -1.1308595045580652e+00
    phi[9,6]  R2632     -4.00914036192753
    phi[9,6]  R2633     -3.8101292979408439e+00
    phi[9,6]  R2634     -2.3898705113242928e+00
    phi[9,6]  R2635     -2.4521952314357822e+00
    phi[9,6]  R2636     -1.7278045969028408e+00
    phi[9,6]  R2637     -5.1850262118857682e+00
    phi[9,6]  R2638     -1.0149735973793681e+00
    phi[9,6]  R2639     -2.3243251059133141e-01
    phi[9,6]  R2640     -2.3682027044789811e-01
    phi[9,6]  R2641     -2.3727276262069408e-01
    phi[9,6]  R2642     -2.3832331317976374e-01
    phi[9,6]  R2643     -2.3870818471817923e-01
    phi[9,6]  R2644     -2.4148751808087821e-01
    phi[9,6]  R2645     -2.4678274475900608e-01
    phi[9,6]  R2646     -2.6534938496566518e-01
    phi[9,6]  R2647     -2.6556265713292659e-01
    phi[9,6]  R2648     -2.6587764317897689e-01
    phi[9,6]  R2649     -4.4785751422742759e-01
    phi[9,6]  R2650     -0.466041533859487
    phi[9,6]  R2651     -4.7133749073026981e-01
    phi[9,6]  R2652     -4.8263287477917682e-01
    phi[9,6]  R2653     -4.8660463801827158e-01
    phi[9,6]  R2654     -5.0051263098341592e-01
    phi[9,6]  R2655     -5.0399193506189421e-01
    phi[9,6]  R2656     -5.0933480539172293e-01
    phi[9,6]  R2657     -5.7991226063569068e-01
    phi[9,6]  R2658     -0.594664048056416
    phi[9,6]  R2659     -3.5215809668186604e-01
    phi[9,6]  R2660     -3.5598534907511226e-01
    phi[9,6]  R2661     -4.1608531342693889e-01
    phi[9,6]  R2662     -4.4637236424969839e-01
    phi[9,6]  R2663     -4.4716545223509052e-01
    phi[9,6]  R2664     -4.7102002200789417e-01
    phi[9,6]  R2665     -4.7909951203276663e-01
    phi[9,6]  R2666     -4.8412744796888019e-01
    phi[9,6]  R2667     -4.8912082393883405e-01
    phi[9,6]  R2668     -4.9112352070715415e-01
    phi[9,6]  R2669     -3.5656928052244963e-01
    phi[9,6]  R2670     -3.5793124087719452e-01
    phi[9,6]  R2671     -3.6386995960052126e-01
    phi[9,6]  R2672     -3.7062293292610748e-01
    phi[9,6]  R2673     -3.7096048214423161e-01
    phi[9,6]  R2674     -3.7155195457218415e-01
    phi[9,6]  R2675     -3.8507492215746386e-01
    phi[9,6]  R2676     -3.8608039926574378e-01
    phi[9,6]  R2677     -3.9936119605239029e-01
    phi[9,6]  R2678     -4.0466428525435061e-01
    phi[9,6]  R2679     -3.6926260333981387e-01
    phi[9,6]  R2680     -3.8093487640042167e-01
    phi[9,6]  R2681     -4.1258774525918862e-01
    phi[9,6]  R2682     -4.1924563555029359e-01
    phi[9,6]  R2683     -4.2185075164227148e-01
    phi[9,6]  R2684     -4.7125243149358287e-01
    phi[9,6]  R2685     -5.7970888986598434e-01
    phi[9,6]  R2686     -0.594785209671598
    phi[9,6]  R2687     -6.0271341099657350e-01
    phi[9,6]  R2688     -6.1848158050286983e-01
    phi[9,6]  R2689     -3.5586885045530936e-01
    phi[9,6]  R2690     -3.6702329970802827e-01
    phi[9,6]  R2691     -0.395384720499079
    phi[9,6]  R2692     -4.9346749422174541e-01
    phi[9,6]  R2693     -5.4025016015363425e-01
    phi[9,6]  R2694     -5.9417240267779725e-01
    phi[9,6]  R2695     -0.616542077420112
    phi[9,6]  R2696     -6.7922065244701946e-01
    phi[9,6]  R2697     -6.8032852796989562e-01
    phi[9,6]  R2698     -6.8718075445512650e-01
    phi[9,6]  R2699     -3.3617139987501365e-01
    phi[9,6]  R2700     -3.6162746033246407e-01
    phi[9,6]  R2701     -3.6848892217864027e-01
    phi[9,6]  R2702     -3.8148069550158370e-01
    phi[9,6]  R2703     -4.7607389415110923e-01
    phi[9,6]  R2704     -5.0626551189140190e-01
    phi[9,6]  R2705     -5.2889813574324851e-01
    phi[9,6]  R2706     -5.3403571035276132e-01
    phi[9,6]  R2707     -5.4068396296069432e-01
    phi[9,6]  R2708     -5.4300349852806740e-01
    phi[7,8]  R63       1
    phi[7,8]  R64       1
    phi[7,8]  R72       -1
    phi[7,8]  R2709     -3.0999999046325684e+00
    phi[7,8]  R2710     -3.0999999046325684e+00
    phi[7,8]  R2711     -2.2400000095367432e+00
    phi[7,8]  R2712     -2.2400000095367432e+00
    phi[7,8]  R2713     -3.0999999046325684e+00
    phi[7,8]  R2714     -3.0999999046325684e+00
    phi[7,8]  R2715     -2.5699999332427979e+00
    phi[7,8]  R2716     -2.5699999332427979e+00
    phi[7,8]  R2717     -3.0999999046325684e+00
    phi[7,8]  R2718     -3.0999999046325684e+00
    phi[7,8]  R2719     -2.0899999141693115e+00
    phi[7,8]  R2720     -2.0899999141693115e+00
    phi[7,8]  R2721     -3.0999999046325684e+00
    phi[7,8]  R2722     -3.0999999046325684e+00
    phi[7,8]  R2723     1.7752698659896851e+00
    phi[7,8]  R2724     1.5124298334121704e+00
    phi[7,8]  R2725     2.2887554168701172e+00
    phi[7,8]  R2726     1.0413560867309570e+00
    phi[7,8]  R2727     1.5172356367111206e+00
    phi[7,8]  R2728     1.6747601032257080e+00
    phi[7,8]  R2729     8.3849179744720459e-01
    phi[7,8]  R2730     1.2317837476730347e+00
    phi[7,8]  R2731     2.8787943720817566e-01
    phi[7,8]  R2732     -0.153577983379364
    phi[7,8]  R2733     -1.4564617872238159e+00
    phi[7,8]  R2734     -3.6475213365741972e+00
    phi[7,8]  R2735     -4.6489146351814270e-01
    phi[7,8]  R2736     -2.7162692546844482e+00
    phi[7,8]  R2737     -2.6751253604888916e+00
    phi[7,8]  R2738     -1.0896718502044678e+00
    phi[7,8]  R2739     -2.2703313827514648e+00
    phi[7,8]  R2740     1.6885892152786255e+00
    phi[7,8]  R2741     -4.3220141530036926e-01
    phi[7,8]  R2742     -1.4374911785125732e+00
    phi[7,8]  R2743     -1.7562206983566284e+00
    phi[7,8]  R2744     -2.4429554939270020e+00
    phi[7,8]  R2745     -1.6784943342208862e+00
    phi[7,8]  R2746     -1.6507213935256004e-02
    phi[7,8]  R2747     1.8147727251052856e+00
    phi[7,8]  R2748     -9.0340659022331238e-02
    phi[7,8]  R2749     2.4659178256988525e+00
    phi[7,8]  R2750     3.3490865230560303e+00
    phi[7,8]  R2751     2.4996743202209473e+00
    phi[7,8]  R2752     2.5079476833343506e+00
    phi[7,8]  R2753     1.29396653175354
    phi[7,8]  R2754     2.78867506980896
    phi[7,8]  R2755     1.9115095138549805e+00
    phi[7,8]  R2756     2.0590593814849854e+00
    phi[7,8]  R2757     2.8269140720367432e+00
    phi[7,8]  R2758     -2.0077536106109619e+00
    phi[7,8]  R2759     -2.0533299446105957e+00
    phi[7,8]  R2760     -1.9196538925170898e+00
    phi[7,8]  R2761     -1.9923603534698486e+00
    phi[7,8]  R2762     -1.9211567640304565e+00
    phi[7,8]  R2763     -1.8253394365310669e+00
    phi[7,8]  R2764     -2.2157876491546631e+00
    phi[7,8]  R2765     -1.5762580633163452e+00
    phi[7,8]  R2766     -2.4873320758342743e-01
    phi[7,8]  R2767     -2.8461503982543945e+00
    phi[7,8]  R2768     -7.6862621307373047e-01
    phi[7,8]  R2769     -6.4954203367233276e-01
    phi[7,8]  R2770     -3.4282701015472412e+00
    phi[7,8]  R2771     -3.9427180290222168e+00
    phi[7,8]  R2772     -4.2678065299987793e+00
    phi[7,8]  R2773     -3.0079858303070068e+00
    phi[7,8]  R2774     -3.0631160736083984e+00
    phi[7,8]  R2775     -1.46782648563385
    phi[7,8]  R2776     -3.0336687564849854e+00
    phi[7,8]  R2777     -3.8640193939208984e+00
    phi[7,8]  R2778     -3.2943956851959229e+00
    phi[7,8]  R2779     -1.1611177921295166e+00
    phi[7,8]  R2780     -5.7986313104629517e-01
    phi[7,8]  R2781     -1.9690148830413818e+00
    phi[7,8]  R2782     -8.2362568378448486e-01
    phi[7,8]  R2783     -6.1290186643600464e-01
    phi[7,8]  R2784     -4.0394032001495361e-01
    phi[7,8]  R2785     -1.3289914131164551e+00
    phi[7,8]  R2786     -8.8191002607345581e-01
    phi[7,8]  R2787     -1.0642046928405762e+00
    phi[7,8]  R2788     -3.0060732364654541e+00
    phi[7,8]  R2789     -1.0136628150939941e+00
    phi[7,8]  R2790     -5.7547622919082642e-01
    phi[7,8]  R2791     -2.0504245758056641e+00
    phi[7,8]  R2792     -3.5017967224121094e+00
    phi[7,8]  R2793     8.2845389842987061e-01
    phi[7,8]  R2794     -3.8474166393280029e+00
    phi[7,8]  R2795     -2.5357415676116943e+00
    phi[7,8]  R2796     -4.0705734491348267e-01
    phi[7,8]  R2797     -5.5479627847671509e-01
    phi[7,8]  R2798     -1.3401981592178345e+00
    phi[7,8]  R2799     2.2928394377231598e-01
    phi[7,8]  R2800     -1.3102151155471802e+00
    phi[7,8]  R2801     -2.6002879142761230e+00
    phi[7,8]  R2802     -1.1289610862731934e+00
    phi[7,8]  R2803     -4.5500600337982178e-01
    phi[7,8]  R2804     1.2885019779205322e+00
    phi[7,8]  R2805     1.6775111854076385e-01
    phi[7,8]  R2806     -8.9445686340332031e-01
    phi[7,8]  R2807     -0.572439968585968
    phi[7,8]  R2808     -4.0689194202423096e-01
    phi[7,8]  R2809     -5.3437036275863647e-01
    phi[7,8]  R2810     -3.1713981628417969e+00
    phi[7,8]  R2811     -1.8277709484100342e+00
    phi[7,8]  R2812     -2.3546919822692871e+00
    phi[7,8]  R2813     0.659534215927124
    phi[7,8]  R2814     -1.1701400279998779e+00
    phi[7,8]  R2815     6.1644750833511353e-01
    phi[7,8]  R2816     -1.9318168163299561e+00
    phi[7,8]  R2817     -3.9235424995422363e+00
    phi[7,8]  R2818     -1.4194416999816895e+00
    phi[7,8]  R2819     -1.4656705856323242e+00
    phi[7,8]  R2820     -1.6552976369857788e+00
    phi[7,8]  R2821     5.2774280309677124e-01
    phi[7,8]  R2822     -1.5542395114898682e+00
    phi[7,8]  R2823     -1.0921399593353271e+00
    phi[7,8]  R2824     -1.8403857946395874e+00
    phi[7,8]  R2825     5.6455695629119873e-01
    phi[7,8]  R2826     -5.8117306232452393e-01
    phi[7,8]  R2827     -1.3469942808151245e+00
    phi[7,8]  R2828     -1.0223016738891602e+00
    phi[8,7]  R63       -1
    phi[8,7]  R72       1
    phi[8,7]  R73       1
    phi[8,7]  R2829     -3.0999999046325684e+00
    phi[8,7]  R2830     -3.0999999046325684e+00
    phi[8,7]  R2831     -2.2400000095367432e+00
    phi[8,7]  R2832     -2.2400000095367432e+00
    phi[8,7]  R2833     -3.0999999046325684e+00
    phi[8,7]  R2834     -3.0999999046325684e+00
    phi[8,7]  R2835     -2.5699999332427979e+00
    phi[8,7]  R2836     -2.5699999332427979e+00
    phi[8,7]  R2837     -3.0999999046325684e+00
    phi[8,7]  R2838     -3.0999999046325684e+00
    phi[8,7]  R2839     -2.0899999141693115e+00
    phi[8,7]  R2840     -2.0899999141693115e+00
    phi[8,7]  R2841     -3.0999999046325684e+00
    phi[8,7]  R2842     -3.0999999046325684e+00
    phi[8,7]  R2843     2.4659178256988525e+00
    phi[8,7]  R2844     3.3490865230560303e+00
    phi[8,7]  R2845     2.4996743202209473e+00
    phi[8,7]  R2846     2.5079476833343506e+00
    phi[8,7]  R2847     1.29396653175354
    phi[8,7]  R2848     2.78867506980896
    phi[8,7]  R2849     1.9115095138549805e+00
    phi[8,7]  R2850     2.0590593814849854e+00
    phi[8,7]  R2851     2.8269140720367432e+00
    phi[8,7]  R2852     -2.0077536106109619e+00
    phi[8,7]  R2853     -2.0533299446105957e+00
    phi[8,7]  R2854     -1.9196538925170898e+00
    phi[8,7]  R2855     -1.9923603534698486e+00
    phi[8,7]  R2856     -1.9211567640304565e+00
    phi[8,7]  R2857     -1.8253394365310669e+00
    phi[8,7]  R2858     -2.2157876491546631e+00
    phi[8,7]  R2859     -1.5762580633163452e+00
    phi[8,7]  R2860     -2.4873320758342743e-01
    phi[8,7]  R2861     -2.8461503982543945e+00
    phi[8,7]  R2862     -7.6862621307373047e-01
    phi[8,7]  R2863     -6.4954203367233276e-01
    phi[8,7]  R2864     -3.4282701015472412e+00
    phi[8,7]  R2865     -3.9427180290222168e+00
    phi[8,7]  R2866     -4.2678065299987793e+00
    phi[8,7]  R2867     -3.0079858303070068e+00
    phi[8,7]  R2868     -3.0631160736083984e+00
    phi[8,7]  R2869     -1.46782648563385
    phi[8,7]  R2870     -3.0336687564849854e+00
    phi[8,7]  R2871     -3.8640193939208984e+00
    phi[8,7]  R2872     -3.2943956851959229e+00
    phi[8,7]  R2873     -1.1611177921295166e+00
    phi[8,7]  R2874     -5.7986313104629517e-01
    phi[8,7]  R2875     -1.9690148830413818e+00
    phi[8,7]  R2876     -8.2362568378448486e-01
    phi[8,7]  R2877     -6.1290186643600464e-01
    phi[8,7]  R2878     -4.0394032001495361e-01
    phi[8,7]  R2879     -1.3289914131164551e+00
    phi[8,7]  R2880     -8.8191002607345581e-01
    phi[8,7]  R2881     -1.0642046928405762e+00
    phi[8,7]  R2882     -3.0060732364654541e+00
    phi[8,7]  R2883     -1.0136628150939941e+00
    phi[8,7]  R2884     -5.7547622919082642e-01
    phi[8,7]  R2885     -2.0504245758056641e+00
    phi[8,7]  R2886     -3.5017967224121094e+00
    phi[8,7]  R2887     8.2845389842987061e-01
    phi[8,7]  R2888     -3.8474166393280029e+00
    phi[8,7]  R2889     -2.5357415676116943e+00
    phi[8,7]  R2890     -4.0705734491348267e-01
    phi[8,7]  R2891     -5.5479627847671509e-01
    phi[8,7]  R2892     -1.3401981592178345e+00
    phi[8,7]  R2893     2.2928394377231598e-01
    phi[8,7]  R2894     -1.3102151155471802e+00
    phi[8,7]  R2895     -2.6002879142761230e+00
    phi[8,7]  R2896     -1.1289610862731934e+00
    phi[8,7]  R2897     -4.5500600337982178e-01
    phi[8,7]  R2898     1.2885019779205322e+00
    phi[8,7]  R2899     1.6775111854076385e-01
    phi[8,7]  R2900     -8.9445686340332031e-01
    phi[8,7]  R2901     -0.572439968585968
    phi[8,7]  R2902     -4.0689194202423096e-01
    phi[8,7]  R2903     -5.3437036275863647e-01
    phi[8,7]  R2904     -3.1713981628417969e+00
    phi[8,7]  R2905     -1.8277709484100342e+00
    phi[8,7]  R2906     -2.3546919822692871e+00
    phi[8,7]  R2907     0.659534215927124
    phi[8,7]  R2908     -1.1701400279998779e+00
    phi[8,7]  R2909     6.1644750833511353e-01
    phi[8,7]  R2910     -1.9318168163299561e+00
    phi[8,7]  R2911     -3.9235424995422363e+00
    phi[8,7]  R2912     -1.4194416999816895e+00
    phi[8,7]  R2913     -1.4656705856323242e+00
    phi[8,7]  R2914     -1.6552976369857788e+00
    phi[8,7]  R2915     5.2774280309677124e-01
    phi[8,7]  R2916     -1.5542395114898682e+00
    phi[8,7]  R2917     -1.0921399593353271e+00
    phi[8,7]  R2918     -1.8403857946395874e+00
    phi[8,7]  R2919     5.6455695629119873e-01
    phi[8,7]  R2920     -5.8117306232452393e-01
    phi[8,7]  R2921     -1.3469942808151245e+00
    phi[8,7]  R2922     -1.0223016738891602e+00
    phi[8,7]  R2923     1.7752698659896851e+00
    phi[8,7]  R2924     1.5124298334121704e+00
    phi[8,7]  R2925     2.2887554168701172e+00
    phi[8,7]  R2926     1.0413560867309570e+00
    phi[8,7]  R2927     1.5172356367111206e+00
    phi[8,7]  R2928     1.6747601032257080e+00
    phi[8,7]  R2929     8.3849179744720459e-01
    phi[8,7]  R2930     1.2317837476730347e+00
    phi[8,7]  R2931     2.8787943720817566e-01
    phi[8,7]  R2932     -0.153577983379364
    phi[8,7]  R2933     -1.4564617872238159e+00
    phi[8,7]  R2934     -3.6475213365741972e+00
    phi[8,7]  R2935     -4.6489146351814270e-01
    phi[8,7]  R2936     -2.7162692546844482e+00
    phi[8,7]  R2937     -2.6751253604888916e+00
    phi[8,7]  R2938     -1.0896718502044678e+00
    phi[8,7]  R2939     -2.2703313827514648e+00
    phi[8,7]  R2940     1.6885892152786255e+00
    phi[8,7]  R2941     -4.3220141530036926e-01
    phi[8,7]  R2942     -1.4374911785125732e+00
    phi[8,7]  R2943     -1.7562206983566284e+00
    phi[8,7]  R2944     -2.4429554939270020e+00
    phi[8,7]  R2945     -1.6784943342208862e+00
    phi[8,7]  R2946     -1.6507213935256004e-02
    phi[8,7]  R2947     1.8147727251052856e+00
    phi[8,7]  R2948     -9.0340659022331238e-02
    MARKER    'MARKER'                 'INTEND'
    z[0,1,0]  R2        -1
    z[0,1,0]  R11       1
    z[0,1,0]  R83       -1
    z[0,1,0]  R84       1
    z[0,1,0]  R97       3.1617248058319092e-01
    z[0,1,0]  R98       5.7669192552566528e-01
    z[0,1,0]  R99       4.7605317831039429e-01
    z[0,1,0]  R100      4.6785807609558105e-01
    z[0,1,0]  R101      8.7497037649154663e-01
    z[0,1,0]  R102      7.1143907308578491e-01
    z[0,1,0]  R103      6.8296575546264648e-01
    z[0,1,0]  R104      8.1498926877975464e-01
    z[0,1,0]  R105      0.185358464717865
    z[0,1,0]  R106      4.7616714239120483e-01
    z[0,1,0]  R107      -4.9223318696022034e-01
    z[0,1,0]  R108      -5.4711413383483887e-01
    z[0,1,0]  R109      -2.4950566887855530e-01
    z[0,1,0]  R110      -4.1189306974411011e-01
    z[0,1,0]  R111      -3.0863013863563538e-01
    z[0,1,0]  R112      -4.8976475000381470e-01
    z[0,1,0]  R113      -1.5400357544422150e-01
    z[0,1,0]  R114      -4.3866270780563354e-01
    z[0,1,0]  R115      -4.7704404592514038e-01
    z[0,1,0]  R116      -2.4821718037128448e-01
    z[0,1,0]  R117      1.1715054512023926e-01
    z[0,1,0]  R118      -7.2085000574588776e-02
    z[0,1,0]  R119      -7.1591906249523163e-02
    z[0,1,0]  R120      2.9847750067710876e-01
    z[0,1,0]  R121      -4.2866292595863342e-01
    z[0,1,0]  R122      -0.407634973526001
    z[0,1,0]  R123      -3.9184358716011047e-01
    z[0,1,0]  R124      -5.7812762260437012e-01
    z[0,1,0]  R125      2.7833279222249985e-02
    z[0,1,0]  R126      -2.9819878935813904e-01
    z[0,1,0]  R127      6.3001766800880432e-02
    z[0,1,0]  R128      0.0899825319647789
    z[0,1,0]  R129      2.5428640842437744e-01
    z[0,1,0]  R130      3.2596611976623535e-01
    z[0,1,0]  R131      3.4396609663963318e-01
    z[0,1,0]  R132      -2.6913258433341980e-01
    z[0,1,0]  R133      -2.6759406924247742e-01
    z[0,1,0]  R134      3.4607195854187012e-01
    z[0,1,0]  R135      4.3527016043663025e-01
    z[0,1,0]  R136      -1.2859259545803070e-01
    z[0,1,0]  R137      9.0489076683297753e-04
    z[0,1,0]  R138      1.2812386453151703e-01
    z[0,1,0]  R139      2.0964090526103973e-01
    z[0,1,0]  R140      3.1280410289764404e-01
    z[0,1,0]  R141      1.2833017110824585e-01
    z[0,1,0]  R142      -0.756442666053772
    z[0,1,0]  R143      -3.5724371671676636e-01
    z[0,1,0]  R144      -3.8763898611068726e-01
    z[0,1,0]  R145      -2.8695088624954224e-01
    z[0,1,0]  R146      -5.0645190477371216e-01
    z[0,1,0]  R147      -6.2723271548748016e-02
    z[0,1,0]  R148      1.7746257781982422e-01
    z[0,1,0]  R149      -7.8412890434265137e-01
    z[0,1,0]  R150      -3.7134975194931030e-01
    z[0,1,0]  R151      -4.2428565025329590e-01
    z[0,1,0]  R152      -3.3557087182998657e-01
    z[0,1,0]  R153      -1.0943162441253662e-01
    z[0,1,0]  R154      -4.9729606509208679e-01
    z[0,1,0]  R155      -8.1524938344955444e-01
    z[0,1,0]  R156      -7.9225832223892212e-01
    z[0,1,0]  R157      -2.4888327717781067e-01
    z[0,1,0]  R158      2.9550388455390930e-01
    z[0,1,0]  R159      8.3232897520065308e-01
    z[0,1,0]  R160      -1.4328254759311676e-01
    z[0,1,0]  R161      6.8893134593963623e-01
    z[0,1,0]  R162      6.3776654005050659e-01
    z[0,1,0]  R163      6.7820006608963013e-01
    z[0,1,0]  R164      2.3337113857269287e-01
    z[0,1,0]  R165      6.2497007846832275e-01
    z[0,1,0]  R166      2.1322837099432945e-02
    z[0,1,0]  R167      -4.1167397052049637e-02
    z[0,1,0]  R168      0.197298064827919
    z[0,1,0]  R169      7.4670299887657166e-02
    z[0,1,0]  R170      -3.1563094258308411e-01
    z[0,1,0]  R171      2.6661109924316406e-01
    z[0,1,0]  R172      -3.2656931877136230e-01
    z[0,1,0]  R173      9.9142841994762421e-02
    z[0,1,0]  R174      -1.1139763146638870e-01
    z[0,1,0]  R175      -0.272646963596344
    z[0,1,0]  R176      -8.6569702625274658e-01
    z[0,1,0]  R177      5.5740630626678467e-01
    z[0,1,0]  R178      3.8298237323760986e-01
    z[0,1,0]  R179      5.6362771987915039e-01
    z[0,1,0]  R180      -1.5003240108489990e-01
    z[0,1,0]  R181      3.6029480397701263e-02
    z[0,1,0]  R182      5.7309955358505249e-01
    z[0,1,0]  R183      2.9047846794128418e-01
    z[0,1,0]  R184      -4.2058023810386658e-01
    z[0,1,0]  R185      1.9371148943901062e-01
    z[0,1,0]  R186      1.0605355352163315e-01
    z[0,1,0]  R187      -4.2197060585021973e-01
    z[0,1,0]  R188      3.2461223006248474e-01
    z[0,1,0]  R189      -3.6581054329872131e-02
    z[0,1,0]  R190      -6.8960803747177124e-01
    z[0,1,0]  R191      4.0713912248611450e-01
    z[0,1,0]  R192      4.5497044920921326e-01
    z[0,1,0]  R193      1.2219832837581635e-01
    z[0,1,0]  R194      3.0583182349801064e-02
    z[0,1,0]  R195      5.2356415987014771e-01
    z[0,1,0]  R196      -2.0894527435302734e-01
    z[0,1,0]  R197      -3.1633329391479492e-01
    z[0,1,0]  R198      5.6508135795593262e-01
    z[0,1,0]  R199      4.9432608485221863e-01
    z[0,1,0]  R200      -2.7010399103164673e-01
    z[0,1,0]  R201      4.9844551086425781e-01
    z[0,1,0]  R202      7.7687317132949829e-01
    z[0,1,0]  R203      4.5036911964416504e-01
    z[0,1,0]  R204      1.1800721287727356e-01
    z[0,1,0]  R205      7.1246273815631866e-02
    z[0,1,0]  R206      -5.7230882346630096e-02
    z[0,1,0]  R207      5.3158521652221680e-01
    z[0,1,0]  R208      6.1826932430267334e-01
    z[0,1,0]  R209      0.55652916431427
    z[0,1,0]  R210      -1.5125067532062531e-01
    z[0,1,0]  R211      -2.2938007116317749e-01
    z[0,1,0]  R212      4.9938037991523743e-02
    z[0,1,0]  R213      3.5751166939735413e-01
    z[0,1,0]  R214      -8.9586025476455688e-01
    z[0,1,0]  R215      -8.6483961343765259e-01
    z[0,1,0]  R216      -1.9328846037387848e-01
    z[0,1,0]  R217      8.0055320262908936e-01
    z[0,1,0]  R218      5.7469260692596436e-01
    z[0,1,0]  R219      4.0401884913444519e-01
    z[0,1,0]  R220      6.0170054435729980e-01
    z[0,1,0]  R221      5.9632128477096558e-01
    z[0,1,0]  R222      4.4133958220481873e-01
    z[0,1,0]  R223      1.0224746540188789e-02
    z[0,1,0]  R224      1.9180500507354736e-01
    z[0,1,0]  R225      -1.4825040102005005e-01
    z[0,1,0]  R226      -8.7072724103927612e-01
    z[0,1,0]  R227      7.7404584735631943e-03
    z[0,1,0]  R228      2.9487663507461548e-01
    z[0,1,0]  R229      5.8443647623062134e-01
    z[0,1,0]  R230      5.4683828353881836e-01
    z[0,1,0]  R231      2.2184620797634125e-01
    z[0,1,0]  R232      -2.4688437581062317e-01
    z[0,1,0]  R233      -3.2373899221420288e-01
    z[0,1,0]  R234      -3.7914934754371643e-01
    z[0,1,0]  R235      -4.8320788145065308e-01
    z[0,1,0]  R236      -3.3936527371406555e-01
    z[0,1,0]  R237      -2.8650021553039551e-01
    z[0,1,0]  R238      5.4303503036499023e-01
    z[0,1,0]  R239      -8.1450039148330688e-01
    z[0,1,0]  R240      -1.3905651867389679e-01
    z[0,1,0]  R241      -4.7093746066093445e-01
    z[0,1,0]  R242      -2.9865953326225281e-01
    z[0,1,0]  R243      -3.7797302007675171e-01
    z[0,1,0]  R244      -8.5167139768600464e-01
    z[0,1,0]  R245      -2.7430984377861023e-01
    z[0,1,0]  R246      -3.3804914355278015e-01
    z[0,1,1]  R3        -1
    z[0,1,1]  R12       1
    z[0,1,1]  R85       -1
    z[0,1,1]  R86       1
    z[0,1,1]  R97       -2.2488594055175781e-01
    z[0,1,1]  R98       -1.2939150631427765e-01
    z[0,1,1]  R99       -2.1679200232028961e-01
    z[0,1,1]  R100      -4.0721505880355835e-01
    z[0,1,1]  R101      -1.8201905488967896e-01
    z[0,1,1]  R102      -3.6664776504039764e-02
    z[0,1,1]  R103      -3.5846021771430969e-01
    z[0,1,1]  R104      -2.6038247346878052e-01
    z[0,1,1]  R105      -6.8155348300933838e-01
    z[0,1,1]  R106      -2.8164952993392944e-01
    z[0,1,1]  R107      6.2968921661376953e-01
    z[0,1,1]  R108      6.2375122308731079e-01
    z[0,1,1]  R109      6.4590960741043091e-01
    z[0,1,1]  R110      8.7937724590301514e-01
    z[0,1,1]  R111      7.2811561822891235e-01
    z[0,1,1]  R112      4.4551664590835571e-01
    z[0,1,1]  R113      7.0651078224182129e-01
    z[0,1,1]  R114      6.0509574413299561e-01
    z[0,1,1]  R115      4.0943464636802673e-01
    z[0,1,1]  R116      0.868427574634552
    z[0,1,1]  R117      7.7697628736495972e-01
    z[0,1,1]  R118      8.2676619291305542e-01
    z[0,1,1]  R119      7.4282425642013550e-01
    z[0,1,1]  R120      5.9907871484756470e-01
    z[0,1,1]  R121      3.6086297035217285e-01
    z[0,1,1]  R122      -5.0757569074630737e-01
    z[0,1,1]  R123      1.7272317409515381e-01
    z[0,1,1]  R124      -3.2708102464675903e-01
    z[0,1,1]  R125      4.5395290851593018e-01
    z[0,1,1]  R126      -2.8362569212913513e-01
    z[0,1,1]  R127      9.4584661722183228e-01
    z[0,1,1]  R128      8.3826774358749390e-01
    z[0,1,1]  R129      7.8720378875732422e-01
    z[0,1,1]  R130      8.5944074392318726e-01
    z[0,1,1]  R131      7.4405682086944580e-01
    z[0,1,1]  R132      8.2526820898056030e-01
    z[0,1,1]  R133      7.6957190036773682e-01
    z[0,1,1]  R134      0.693574070930481
    z[0,1,1]  R135      7.0397454500198364e-01
    z[0,1,1]  R136      7.1981674432754517e-01
    z[0,1,1]  R137      8.8600194454193115e-01
    z[0,1,1]  R138      8.1919866800308228e-01
    z[0,1,1]  R139      7.5020068883895874e-01
    z[0,1,1]  R140      7.7050465345382690e-01
    z[0,1,1]  R141      7.8837692737579346e-01
    z[0,1,1]  R142      3.5375913977622986e-01
    z[0,1,1]  R143      3.5882890224456787e-01
    z[0,1,1]  R144      2.7233263850212097e-01
    z[0,1,1]  R145      -6.9074638187885284e-02
    z[0,1,1]  R146      3.1501409411430359e-01
    z[0,1,1]  R147      9.6092832088470459e-01
    z[0,1,1]  R148      9.0106505155563354e-01
    z[0,1,1]  R149      3.6725702881813049e-01
    z[0,1,1]  R150      -4.7007972002029419e-01
    z[0,1,1]  R151      -2.9570633172988892e-01
    z[0,1,1]  R152      3.7011715769767761e-01
    z[0,1,1]  R153      -5.1091857254505157e-02
    z[0,1,1]  R154      -3.9350786805152893e-01
    z[0,1,1]  R155      -0.486627459526062
    z[0,1,1]  R156      -5.2580362558364868e-01
    z[0,1,1]  R157      2.4882024526596069e-01
    z[0,1,1]  R158      2.6027470827102661e-01
    z[0,1,1]  R159      -4.2193830013275146e-01
    z[0,1,1]  R160      0.357695609331131
    z[0,1,1]  R161      -3.3583068847656250e-01
    z[0,1,1]  R162      -3.4383061528205872e-01
    z[0,1,1]  R163      -1.9444961845874786e-01
    z[0,1,1]  R164      1.3967826031148434e-02
    z[0,1,1]  R165      -3.1188753247261047e-01
    z[0,1,1]  R166      2.2355954349040985e-01
    z[0,1,1]  R167      0.705487847328186
    z[0,1,1]  R168      8.1740945577621460e-01
    z[0,1,1]  R169      8.3081430196762085e-01
    z[0,1,1]  R170      2.1704234182834625e-02
    z[0,1,1]  R171      -1.3921430706977844e-01
    z[0,1,1]  R172      6.7283344268798828e-01
    z[0,1,1]  R173      -1.8174204230308533e-01
    z[0,1,1]  R174      -1.8991971015930176e-01
    z[0,1,1]  R175      -4.8471625894308090e-02
    z[0,1,1]  R176      2.9968783259391785e-01
    z[0,1,1]  R177      -9.8242938518524170e-02
    z[0,1,1]  R178      5.8050528168678284e-03
    z[0,1,1]  R179      -3.5034117102622986e-01
    z[0,1,1]  R180      -1.2987117469310760e-01
    z[0,1,1]  R181      1.1567724496126175e-01
    z[0,1,1]  R182      1.6094347462058067e-02
    z[0,1,1]  R183      -1.6576437279582024e-02
    z[0,1,1]  R184      -2.4119272828102112e-02
    z[0,1,1]  R185      1.4139761030673981e-01
    z[0,1,1]  R186      2.7130430936813354e-01
    z[0,1,1]  R187      1.3013286888599396e-01
    z[0,1,1]  R188      3.7456490099430084e-02
    z[0,1,1]  R189      1.4031082391738892e-01
    z[0,1,1]  R190      6.1334484815597534e-01
    z[0,1,1]  R191      -2.7111306786537170e-01
    z[0,1,1]  R192      -1.4592204988002777e-01
    z[0,1,1]  R193      3.8224789313971996e-03
    z[0,1,1]  R194      -1.3744835555553436e-01
    z[0,1,1]  R195      1.4315118081867695e-02
    z[0,1,1]  R196      4.2679074406623840e-01
    z[0,1,1]  R197      2.2771829366683960e-01
    z[0,1,1]  R198      -1.6862352192401886e-01
    z[0,1,1]  R199      -1.5798328816890717e-01
    z[0,1,1]  R200      7.6394850015640259e-01
    z[0,1,1]  R201      -1.6039286553859711e-01
    z[0,1,1]  R202      -2.6861509680747986e-01
    z[0,1,1]  R203      -8.6294472217559814e-02
    z[0,1,1]  R204      -2.0825612545013428e-01
    z[0,1,1]  R205      -4.2793910950422287e-02
    z[0,1,1]  R206      1.2584343552589417e-02
    z[0,1,1]  R207      -1.5589401125907898e-01
    z[0,1,1]  R208      -1.0465943068265915e-01
    z[0,1,1]  R209      -2.6423647999763489e-01
    z[0,1,1]  R210      5.7704836130142212e-02
    z[0,1,1]  R211      1.0573582351207733e-01
    z[0,1,1]  R212      -9.8005570471286774e-02
    z[0,1,1]  R213      1.0065460205078125e-01
    z[0,1,1]  R214      2.9242733120918274e-01
    z[0,1,1]  R215      2.2574819624423981e-01
    z[0,1,1]  R216      -7.5025148689746857e-02
    z[0,1,1]  R217      -1.9033451378345490e-01
    z[0,1,1]  R218      -3.3282455801963806e-01
    z[0,1,1]  R219      6.4190918207168579e-01
    z[0,1,1]  R220      -2.4728335440158844e-01
    z[0,1,1]  R221      -2.0644631981849670e-01
    z[0,1,1]  R222      -2.3136278986930847e-01
    z[0,1,1]  R223      -8.6752094328403473e-02
    z[0,1,1]  R224      1.9959920644760132e-01
    z[0,1,1]  R225      3.5830289125442505e-02
    z[0,1,1]  R226      2.3080386221408844e-01
    z[0,1,1]  R227      2.6614561676979065e-01
    z[0,1,1]  R228      1.9011251628398895e-01
    z[0,1,1]  R229      -3.3396637439727783e-01
    z[0,1,1]  R230      -5.5149450898170471e-02
    z[0,1,1]  R231      2.3891791701316833e-01
    z[0,1,1]  R232      2.1255789697170258e-01
    z[0,1,1]  R233      2.9950019717216492e-01
    z[0,1,1]  R234      2.9912093281745911e-01
    z[0,1,1]  R235      -0.189732626080513
    z[0,1,1]  R236      -3.0053177475929260e-01
    z[0,1,1]  R237      1.2896591797471046e-02
    z[0,1,1]  R238      -0.0914396345615387
    z[0,1,1]  R239      1.4442013204097748e-01
    z[0,1,1]  R240      -2.7446159720420837e-01
    z[0,1,1]  R241      1.1482341587543488e-01
    z[0,1,1]  R242      -1.2507946230471134e-02
    z[0,1,1]  R243      2.3167058825492859e-01
    z[0,1,1]  R244      7.7691055834293365e-02
    z[0,1,1]  R245      1.3147634267807007e-01
    z[0,1,1]  R246      -7.9999083280563354e-01
    z[0,1,2]  R4        -1
    z[0,1,2]  R13       1
    z[0,1,2]  R87       -1
    z[0,1,2]  R88       1
    z[0,1,2]  R97       6.9641411304473877e-01
    z[0,1,2]  R98       6.1756026744842529e-01
    z[0,1,2]  R99       0.746904730796814
    z[0,1,2]  R100      4.7763559222221375e-01
    z[0,1,2]  R101      3.4936192631721497e-01
    z[0,1,2]  R102      5.7652479410171509e-01
    z[0,1,2]  R103      2.7917012572288513e-01
    z[0,1,2]  R104      7.9882211983203888e-02
    z[0,1,2]  R105      4.9595010280609131e-01
    z[0,1,2]  R106      -3.1767857726663351e-03
    z[0,1,2]  R107      -3.7552466988563538e-01
    z[0,1,2]  R108      -5.4819935560226440e-01
    z[0,1,2]  R109      -5.2614951133728027e-01
    z[0,1,2]  R110      -1.4535656571388245e-01
    z[0,1,2]  R111      -3.7699118256568909e-01
    z[0,1,2]  R112      -5.6106412410736084e-01
    z[0,1,2]  R113      -4.4130784273147583e-01
    z[0,1,2]  R114      -4.3506258726119995e-01
    z[0,1,2]  R115      -5.6248861551284790e-01
    z[0,1,2]  R116      -3.6139541864395142e-01
    z[0,1,2]  R117      1.6493658721446991e-01
    z[0,1,2]  R118      1.7390790581703186e-01
    z[0,1,2]  R119      3.4230497479438782e-01
    z[0,1,2]  R120      -1.2580266594886780e-01
    z[0,1,2]  R121      -1.4868043363094330e-01
    z[0,1,2]  R122      -1.2460289150476456e-01
    z[0,1,2]  R123      -0.503728985786438
    z[0,1,2]  R124      8.4312453866004944e-02
    z[0,1,2]  R125      -2.4389077723026276e-01
    z[0,1,2]  R126      -3.0800363421440125e-01
    z[0,1,2]  R127      1.3863548636436462e-01
    z[0,1,2]  R128      -2.7512248605489731e-02
    z[0,1,2]  R129      -6.1390563845634460e-02
    z[0,1,2]  R130      -1.9287452101707458e-01
    z[0,1,2]  R131      -3.9840704202651978e-01
    z[0,1,2]  R132      -1.1714725941419601e-01
    z[0,1,2]  R133      -2.4716173112392426e-01
    z[0,1,2]  R134      -2.9159530997276306e-01
    z[0,1,2]  R135      -1.0140753537416458e-01
    z[0,1,2]  R136      -3.0194488167762756e-01
    z[0,1,2]  R137      -1.9755041599273682e-01
    z[0,1,2]  R138      -2.4487484991550446e-01
    z[0,1,2]  R139      -0.43577840924263
    z[0,1,2]  R140      -1.1846154229715466e-03
    z[0,1,2]  R141      7.1419939398765564e-02
    z[0,1,2]  R142      -1.8547539412975311e-01
    z[0,1,2]  R143      -3.4186357259750366e-01
    z[0,1,2]  R144      -5.1645022630691528e-01
    z[0,1,2]  R145      -1.0560575872659683e-01
    z[0,1,2]  R146      -1.4410842955112457e-01
    z[0,1,2]  R147      6.8419404327869415e-02
    z[0,1,2]  R148      -4.0451448410749435e-02
    z[0,1,2]  R149      -1.9884806871414185e-01
    z[0,1,2]  R150      -2.1745659410953522e-01
    z[0,1,2]  R151      -2.4599377810955048e-01
    z[0,1,2]  R152      2.0575824379920959e-01
    z[0,1,2]  R153      -4.7127166390419006e-01
    z[0,1,2]  R154      1.4961537718772888e-01
    z[0,1,2]  R155      -1.8319293856620789e-01
    z[0,1,2]  R156      -1.3706816732883453e-01
    z[0,1,2]  R157      -1.3974243402481079e-01
    z[0,1,2]  R158      -1.0791204869747162e-01
    z[0,1,2]  R159      -1.3351014256477356e-01
    z[0,1,2]  R160      -1.4141140878200531e-01
    z[0,1,2]  R161      3.7054324150085449e-01
    z[0,1,2]  R162      0.481171190738678
    z[0,1,2]  R163      4.4943156838417053e-01
    z[0,1,2]  R164      6.2327116727828979e-01
    z[0,1,2]  R165      8.0959469079971313e-02
    z[0,1,2]  R166      0.0745064914226532
    z[0,1,2]  R167      -5.1401269435882568e-01
    z[0,1,2]  R168      -4.1547033190727234e-01
    z[0,1,2]  R169      -4.5047828555107117e-01
    z[0,1,2]  R170      -6.2747198343276978e-01
    z[0,1,2]  R171      -4.7564360499382019e-01
    z[0,1,2]  R172      3.9179524779319763e-01
    z[0,1,2]  R173      4.8451694846153259e-01
    z[0,1,2]  R174      -8.9959733188152313e-02
    z[0,1,2]  R175      1.5008051693439484e-01
    z[0,1,2]  R176      2.6233983039855957e-01
    z[0,1,2]  R177      -6.8765640258789062e-01
    z[0,1,2]  R178      -0.522006094455719
    z[0,1,2]  R179      2.1208065748214722e-01
    z[0,1,2]  R180      -4.6540012955665588e-01
    z[0,1,2]  R181      -4.6059334278106689e-01
    z[0,1,2]  R182      -0.485392302274704
    z[0,1,2]  R183      -7.0152807235717773e-01
    z[0,1,2]  R184      -0.0619235597550869
    z[0,1,2]  R185      1.6759210824966431e-01
    z[0,1,2]  R186      0.0671146884560585
    z[0,1,2]  R187      -6.9854712486267090e-01
    z[0,1,2]  R188      -0.712831974029541
    z[0,1,2]  R189      -8.8186144828796387e-01
    z[0,1,2]  R190      -2.0456868410110474e-01
    z[0,1,2]  R191      -8.0457948148250580e-02
    z[0,1,2]  R192      6.7947648465633392e-02
    z[0,1,2]  R193      1.7455644905567169e-01
    z[0,1,2]  R194      -2.1403209865093231e-01
    z[0,1,2]  R195      1.9011916220188141e-01
    z[0,1,2]  R196      3.9396515488624573e-01
    z[0,1,2]  R197      -6.0739632695913315e-02
    z[0,1,2]  R198      -1.7637857794761658e-01
    z[0,1,2]  R199      -0.0888201892375946
    z[0,1,2]  R200      2.8243938088417053e-01
    z[0,1,2]  R201      -3.3264991641044617e-01
    z[0,1,2]  R202      0.207072451710701
    z[0,1,2]  R203      0.0663580447435379
    z[0,1,2]  R204      -5.1376353949308395e-02
    z[0,1,2]  R205      -1.8423390388488770e-01
    z[0,1,2]  R206      6.5412461757659912e-02
    z[0,1,2]  R207      5.2865464240312576e-02
    z[0,1,2]  R208      -2.3262429982423782e-02
    z[0,1,2]  R209      0.0476471409201622
    z[0,1,2]  R210      -7.3751728050410748e-03
    z[0,1,2]  R211      1.7571914196014404e-01
    z[0,1,2]  R212      4.0155026316642761e-01
    z[0,1,2]  R213      0.446807324886322
    z[0,1,2]  R214      -1.3759591616690159e-02
    z[0,1,2]  R215      2.1937979757785797e-01
    z[0,1,2]  R216      2.4245730042457581e-01
    z[0,1,2]  R217      3.4914985299110413e-01
    z[0,1,2]  R218      4.2426955699920654e-01
    z[0,1,2]  R219      1.7419147491455078e-01
    z[0,1,2]  R220      1.3603346049785614e-01
    z[0,1,2]  R221      2.2313900291919708e-01
    z[0,1,2]  R222      -3.4275189042091370e-01
    z[0,1,2]  R223      -2.7045145630836487e-01
    z[0,1,2]  R224      3.9838257431983948e-01
    z[0,1,2]  R225      1.9918428361415863e-01
    z[0,1,2]  R226      1.8702767789363861e-01
    z[0,1,2]  R227      -2.1489652991294861e-01
    z[0,1,2]  R228      -5.1691156625747681e-01
    z[0,1,2]  R229      1.2027036398649216e-01
    z[0,1,2]  R230      -5.3264591842889786e-02
    z[0,1,2]  R231      0.0594746358692646
    z[0,1,2]  R232      4.1544923186302185e-01
    z[0,1,2]  R233      3.5326632857322693e-01
    z[0,1,2]  R234      1.8077576160430908e-01
    z[0,1,2]  R235      5.1298856735229492e-01
    z[0,1,2]  R236      4.4338029623031616e-01
    z[0,1,2]  R237      -4.2498657107353210e-01
    z[0,1,2]  R238      -2.2581714391708374e-01
    z[0,1,2]  R239      0.324491411447525
    z[0,1,2]  R240      4.4395741820335388e-01
    z[0,1,2]  R241      4.9326434731483459e-01
    z[0,1,2]  R242      3.2187905907630920e-01
    z[0,1,2]  R243      4.0216556191444397e-01
    z[0,1,2]  R244      2.0421876013278961e-01
    z[0,1,2]  R245      7.1265482902526855e-01
    z[0,1,2]  R246      1.3422681391239166e-01
    z[0,1,3]  R5        -1
    z[0,1,3]  R14       1
    z[0,1,3]  R89       -1
    z[0,1,3]  R90       1
    z[0,1,3]  R97       5.1677453517913818e-01
    z[0,1,3]  R98       1.2330103665590286e-01
    z[0,1,3]  R99       1.6277417540550232e-01
    z[0,1,3]  R100      4.2016741633415222e-01
    z[0,1,3]  R101      2.2670869529247284e-01
    z[0,1,3]  R102      2.6785820722579956e-01
    z[0,1,3]  R103      -1.0430599562823772e-02
    z[0,1,3]  R104      3.7662589550018311e-01
    z[0,1,3]  R105      2.8773674368858337e-01
    z[0,1,3]  R106      7.7458918094635010e-01
    z[0,1,3]  R107      1.6704623401165009e-01
    z[0,1,3]  R108      2.3247901350259781e-02
    z[0,1,3]  R109      4.1320866346359253e-01
    z[0,1,3]  R110      0.0545872300863266
    z[0,1,3]  R111      1.2594187259674072e-01
    z[0,1,3]  R112      1.6451855003833771e-01
    z[0,1,3]  R113      3.3085045218467712e-01
    z[0,1,3]  R114      2.4973908066749573e-01
    z[0,1,3]  R115      3.9302092790603638e-01
    z[0,1,3]  R116      -8.9879669249057770e-02
    z[0,1,3]  R117      -5.6031066179275513e-01
    z[0,1,3]  R118      -9.8044604063034058e-02
    z[0,1,3]  R119      -1.3259139657020569e-01
    z[0,1,3]  R120      -0.507114827632904
    z[0,1,3]  R121      -6.7938894033432007e-01
    z[0,1,3]  R122      -6.5618109703063965e-01
    z[0,1,3]  R123      -6.9857668876647949e-01
    z[0,1,3]  R124      -6.7651957273483276e-01
    z[0,1,3]  R125      -0.729148805141449
    z[0,1,3]  R126      -6.4328622817993164e-01
    z[0,1,3]  R127      6.0929656028747559e-02
    z[0,1,3]  R128      4.4564566016197205e-01
    z[0,1,3]  R129      -4.6845340728759766e-01
    z[0,1,3]  R130      0.217659592628479
    z[0,1,3]  R131      -2.1393077075481415e-01
    z[0,1,3]  R132      -2.3716230690479279e-01
    z[0,1,3]  R133      -3.2082572579383850e-01
    z[0,1,3]  R134      4.1865665465593338e-02
    z[0,1,3]  R135      -9.6946984529495239e-02
    z[0,1,3]  R136      8.9062482118606567e-02
    z[0,1,3]  R137      -3.2469424605369568e-01
    z[0,1,3]  R138      -3.8564404845237732e-01
    z[0,1,3]  R139      1.9415273563936353e-03
    z[0,1,3]  R140      -0.000567007577046752
    z[0,1,3]  R141      -0.308651328086853
    z[0,1,3]  R142      2.7416145801544189e-01
    z[0,1,3]  R143      -7.5802463293075562e-01
    z[0,1,3]  R144      -6.2473946809768677e-01
    z[0,1,3]  R145      -0.938624382019043
    z[0,1,3]  R146      -6.4770805835723877e-01
    z[0,1,3]  R147      5.8693759143352509e-02
    z[0,1,3]  R148      1.9043010473251343e-01
    z[0,1,3]  R149      2.8132423758506775e-01
    z[0,1,3]  R150      -7.3013061285018921e-01
    z[0,1,3]  R151      -7.1067994832992554e-01
    z[0,1,3]  R152      -7.9846704006195068e-01
    z[0,1,3]  R153      -0.622801661491394
    z[0,1,3]  R154      -4.3773502111434937e-01
    z[0,1,3]  R155      1.8729162216186523e-01
    z[0,1,3]  R156      -9.3009635806083679e-02
    z[0,1,3]  R157      4.2786693572998047e-01
    z[0,1,3]  R158      5.6138175725936890e-01
    z[0,1,3]  R159      -2.1517328917980194e-02
    z[0,1,3]  R160      6.8580663204193115e-01
    z[0,1,3]  R161      -3.8698457647114992e-03
    z[0,1,3]  R162      3.2861644029617310e-01
    z[0,1,3]  R163      -1.2012303620576859e-01
    z[0,1,3]  R164      5.5567485094070435e-01
    z[0,1,3]  R165      -1.2867744266986847e-01
    z[0,1,3]  R166      -5.6563433259725571e-02
    z[0,1,3]  R167      -9.4751402735710144e-02
    z[0,1,3]  R168      -3.3500720746815205e-03
    z[0,1,3]  R169      -2.4091796576976776e-01
    z[0,1,3]  R170      5.9733642265200615e-03
    z[0,1,3]  R171      -6.5414440631866455e-01
    z[0,1,3]  R172      2.4336710572242737e-01
    z[0,1,3]  R173      -4.4006025791168213e-01
    z[0,1,3]  R174      -4.2608228325843811e-01
    z[0,1,3]  R175      -7.2649914026260376e-01
    z[0,1,3]  R176      -1.6354420781135559e-01
    z[0,1,3]  R177      6.0123833827674389e-03
    z[0,1,3]  R178      6.9074296951293945e-01
    z[0,1,3]  R179      -1.8271112442016602e-01
    z[0,1,3]  R180      -2.5598838925361633e-02
    z[0,1,3]  R181      -4.3165674805641174e-01
    z[0,1,3]  R182      4.8092268407344818e-02
    z[0,1,3]  R183      -2.3779571056365967e-01
    z[0,1,3]  R184      -6.3250350952148438e-01
    z[0,1,3]  R185      2.6156967878341675e-01
    z[0,1,3]  R186      -8.4441676735877991e-02
    z[0,1,3]  R187      4.3929345905780792e-02
    z[0,1,3]  R188      2.3876060545444489e-01
    z[0,1,3]  R189      3.4031070768833160e-02
    z[0,1,3]  R190      1.9250829517841339e-01
    z[0,1,3]  R191      5.1246255636215210e-01
    z[0,1,3]  R192      -6.0873252153396606e-01
    z[0,1,3]  R193      -9.0511363744735718e-01
    z[0,1,3]  R194      -7.3025971651077271e-01
    z[0,1,3]  R195      -5.0211775302886963e-01
    z[0,1,3]  R196      -5.5745714902877808e-01
    z[0,1,3]  R197      5.2649700641632080e-01
    z[0,1,3]  R198      1.9932985305786133e-01
    z[0,1,3]  R199      7.8748238086700439e-01
    z[0,1,3]  R200      4.3566811084747314e-01
    z[0,1,3]  R201      -8.1966057419776917e-02
    z[0,1,3]  R202      5.2357977628707886e-01
    z[0,1,3]  R203      1.8273739516735077e-01
    z[0,1,3]  R204      -2.8898784518241882e-01
    z[0,1,3]  R205      -5.8250063657760620e-01
    z[0,1,3]  R206      -8.3422678709030151e-01
    z[0,1,3]  R207      5.9759140014648438e-01
    z[0,1,3]  R208      -5.3690886497497559e-01
    z[0,1,3]  R209      6.7187029123306274e-01
    z[0,1,3]  R210      -9.2615431547164917e-01
    z[0,1,3]  R211      -5.2048432826995850e-01
    z[0,1,3]  R212      -4.4863912463188171e-01
    z[0,1,3]  R213      -7.5512075424194336e-01
    z[0,1,3]  R214      -9.8633371293544769e-02
    z[0,1,3]  R215      1.2380762398242950e-01
    z[0,1,3]  R216      -7.0751684904098511e-01
    z[0,1,3]  R217      -3.8104152679443359e-01
    z[0,1,3]  R218      3.2583260536193848e-01
    z[0,1,3]  R219      5.6155413389205933e-01
    z[0,1,3]  R220      -1.7436213791370392e-01
    z[0,1,3]  R221      -5.1284188032150269e-01
    z[0,1,3]  R222      2.0295481383800507e-01
    z[0,1,3]  R223      -8.3560156822204590e-01
    z[0,1,3]  R224      -4.8282131552696228e-01
    z[0,1,3]  R225      -0.545455276966095
    z[0,1,3]  R226      -0.336578905582428
    z[0,1,3]  R227      5.5588185787200928e-01
    z[0,1,3]  R228      7.5425481796264648e-01
    z[0,1,3]  R229      4.5786008238792419e-01
    z[0,1,3]  R230      3.0420255661010742e-01
    z[0,1,3]  R231      0.0747174620628357
    z[0,1,3]  R232      -0.641779899597168
    z[0,1,3]  R233      -6.8036824464797974e-01
    z[0,1,3]  R234      -6.4183020591735840e-01
    z[0,1,3]  R235      -6.0219085216522217e-01
    z[0,1,3]  R236      -5.9417766332626343e-01
    z[0,1,3]  R237      6.6427206993103027e-01
    z[0,1,3]  R238      2.7343866229057312e-01
    z[0,1,3]  R239      4.0755501389503479e-01
    z[0,1,3]  R240      2.5693568587303162e-01
    z[0,1,3]  R241      -0.682981014251709
    z[0,1,3]  R242      -6.3763946294784546e-01
    z[0,1,3]  R243      -6.9238191843032837e-01
    z[0,1,3]  R244      1.2699677050113678e-01
    z[0,1,3]  R245      -5.9325700998306274e-01
    z[0,1,3]  R246      3.0823636054992676e-01
    z[0,1,4]  R6        -1
    z[0,1,4]  R15       1
    z[0,1,4]  R91       -1
    z[0,1,4]  R92       1
    z[0,1,4]  R97       -4.1218571364879608e-02
    z[0,1,4]  R98       0.352463036775589
    z[0,1,4]  R99       -2.4997876584529877e-01
    z[0,1,4]  R100      3.1200459599494934e-01
    z[0,1,4]  R101      -1.5997199714183807e-01
    z[0,1,4]  R102      -5.0467513501644135e-02
    z[0,1,4]  R103      3.9517077803611755e-01
    z[0,1,4]  R104      -3.3496016263961792e-01
    z[0,1,4]  R105      -2.5108709931373596e-01
    z[0,1,4]  R106      5.7777430862188339e-02
    z[0,1,4]  R107      -2.4556618183851242e-02
    z[0,1,4]  R108      -7.3936069384217262e-03
    z[0,1,4]  R109      1.3218869268894196e-01
    z[0,1,4]  R110      4.1001036763191223e-02
    z[0,1,4]  R111      2.5220713019371033e-01
    z[0,1,4]  R112      1.9193364679813385e-01
    z[0,1,4]  R113      -5.9747759252786636e-02
    z[0,1,4]  R114      -8.6109027266502380e-02
    z[0,1,4]  R115      1.3745196163654327e-01
    z[0,1,4]  R116      0.0350436307489872
    z[0,1,4]  R117      9.5477670431137085e-02
    z[0,1,4]  R118      -3.7079265713691711e-01
    z[0,1,4]  R119      -1.3064685463905334e-01
    z[0,1,4]  R120      3.2557407021522522e-01
    z[0,1,4]  R121      -1.3982348144054413e-01
    z[0,1,4]  R122      1.1141499131917953e-01
    z[0,1,4]  R123      -7.0524394512176514e-02
    z[0,1,4]  R124      8.8269263505935669e-02
    z[0,1,4]  R125      4.1587015986442566e-01
    z[0,1,4]  R126      4.0703928470611572e-01
    z[0,1,4]  R127      -2.1439389884471893e-01
    z[0,1,4]  R128      -2.3072990775108337e-01
    z[0,1,4]  R129      2.6333945989608765e-01
    z[0,1,4]  R130      2.4770571291446686e-01
    z[0,1,4]  R131      2.1385875344276428e-01
    z[0,1,4]  R132      6.0413964092731476e-02
    z[0,1,4]  R133      -2.5798571109771729e-01
    z[0,1,4]  R134      -1.1370173841714859e-01
    z[0,1,4]  R135      0.359660267829895
    z[0,1,4]  R136      5.8230042457580566e-02
    z[0,1,4]  R137      1.2516547739505768e-01
    z[0,1,4]  R138      -3.8943123072385788e-02
    z[0,1,4]  R139      -5.8395609259605408e-02
    z[0,1,4]  R140      0.284589558839798
    z[0,1,4]  R141      -3.4502550959587097e-01
    z[0,1,4]  R142      -6.8094119429588318e-02
    z[0,1,4]  R143      -7.7331632375717163e-02
    z[0,1,4]  R144      2.8215774893760681e-01
    z[0,1,4]  R145      1.0871417075395584e-01
    z[0,1,4]  R146      -1.9560030195862055e-03
    z[0,1,4]  R147      -1.1534772813320160e-01
    z[0,1,4]  R148      1.9251872599124908e-01
    z[0,1,4]  R149      0.0800652801990509
    z[0,1,4]  R150      1.9722582772374153e-02
    z[0,1,4]  R151      5.0033140927553177e-02
    z[0,1,4]  R152      -2.4309885501861572e-01
    z[0,1,4]  R153      9.8878055810928345e-02
    z[0,1,4]  R154      5.3946918249130249e-01
    z[0,1,4]  R155      1.6274869441986084e-01
    z[0,1,4]  R156      -4.7675538808107376e-03
    z[0,1,4]  R157      -1.1247880756855011e-01
    z[0,1,4]  R158      2.2592009976506233e-02
    z[0,1,4]  R159      -0.00748852826654911
    z[0,1,4]  R160      3.2927727699279785e-01
    z[0,1,4]  R161      1.2413238175213337e-02
    z[0,1,4]  R162      0.106113001704216
    z[0,1,4]  R163      5.0413364171981812e-01
    z[0,1,4]  R164      4.1448852419853210e-01
    z[0,1,4]  R165      6.7392474412918091e-01
    z[0,1,4]  R166      9.4905763864517212e-02
    z[0,1,4]  R167      -3.9633101224899292e-01
    z[0,1,4]  R168      9.5441611483693123e-03
    z[0,1,4]  R169      1.9344888627529144e-01
    z[0,1,4]  R170      -5.0751698017120361e-01
    z[0,1,4]  R171      -4.6170118451118469e-01
    z[0,1,4]  R172      -2.2196891903877258e-01
    z[0,1,4]  R173      -3.5769772529602051e-01
    z[0,1,4]  R174      -3.0726441740989685e-01
    z[0,1,4]  R175      -4.0538829565048218e-01
    z[0,1,4]  R176      2.3168230056762695e-01
    z[0,1,4]  R177      -3.4652435779571533e-01
    z[0,1,4]  R178      -1.8786557018756866e-01
    z[0,1,4]  R179      -6.7668128013610840e-01
    z[0,1,4]  R180      -8.4895169734954834e-01
    z[0,1,4]  R181      -2.6113060116767883e-01
    z[0,1,4]  R182      1.1247245222330093e-01
    z[0,1,4]  R183      -1.2196033447980881e-01
    z[0,1,4]  R184      -5.4073190689086914e-01
    z[0,1,4]  R185      7.0605689287185669e-01
    z[0,1,4]  R186      9.4362515211105347e-01
    z[0,1,4]  R187      -2.0223446190357208e-01
    z[0,1,4]  R188      3.1554073095321655e-01
    z[0,1,4]  R189      3.3984726667404175e-01
    z[0,1,4]  R190      2.1140135824680328e-01
    z[0,1,4]  R191      -1.7125698924064636e-01
    z[0,1,4]  R192      -0.0864894762635231
    z[0,1,4]  R193      -1.9900390878319740e-02
    z[0,1,4]  R194      -2.2850982844829559e-01
    z[0,1,4]  R195      -2.0756879448890686e-01
    z[0,1,4]  R196      -1.8477097153663635e-01
    z[0,1,4]  R197      -6.6944587230682373e-01
    z[0,1,4]  R198      1.9878487288951874e-01
    z[0,1,4]  R199      2.5809904932975769e-01
    z[0,1,4]  R200      -1.8200004100799561e-01
    z[0,1,4]  R201      -1.8569459021091461e-01
    z[0,1,4]  R202      7.6844438910484314e-02
    z[0,1,4]  R203      6.8372821807861328e-01
    z[0,1,4]  R204      -5.6160074472427368e-01
    z[0,1,4]  R205      -4.6660301089286804e-01
    z[0,1,4]  R206      -3.5465580224990845e-01
    z[0,1,4]  R207      -1.1367820203304291e-01
    z[0,1,4]  R208      -1.2245580554008484e-01
    z[0,1,4]  R209      1.8623976409435272e-01
    z[0,1,4]  R210      -1.2363362312316895e-01
    z[0,1,4]  R211      -0.319595068693161
    z[0,1,4]  R212      -3.0021873116493225e-01
    z[0,1,4]  R213      -1.8565380573272705e-01
    z[0,1,4]  R214      -3.3730342984199524e-02
    z[0,1,4]  R215      -8.9219413697719574e-02
    z[0,1,4]  R216      5.2021449804306030e-01
    z[0,1,4]  R217      1.5052796900272369e-01
    z[0,1,4]  R218      -4.8418673872947693e-01
    z[0,1,4]  R219      -1.1262041516602039e-02
    z[0,1,4]  R220      4.5991101861000061e-01
    z[0,1,4]  R221      4.5816510915756226e-02
    z[0,1,4]  R222      -0.678889811038971
    z[0,1,4]  R223      -3.2943999767303467e-01
    z[0,1,4]  R224      -0.4470234811306
    z[0,1,4]  R225      -7.9936087131500244e-01
    z[0,1,4]  R226      -2.0046986639499664e-01
    z[0,1,4]  R227      -5.5702561140060425e-01
    z[0,1,4]  R228      -3.3359881490468979e-02
    z[0,1,4]  R229      -5.0087904930114746e-01
    z[0,1,4]  R230      7.2544181346893311e-01
    z[0,1,4]  R231      8.0137783288955688e-01
    z[0,1,4]  R232      3.9924103021621704e-01
    z[0,1,4]  R233      4.4599962234497070e-01
    z[0,1,4]  R234      5.6706315279006958e-01
    z[0,1,4]  R235      2.8938525915145874e-01
    z[0,1,4]  R236      2.6491126418113708e-01
    z[0,1,4]  R237      -3.9084357023239136e-01
    z[0,1,4]  R238      -2.1561355888843536e-01
    z[0,1,4]  R239      -6.1471585184335709e-02
    z[0,1,4]  R240      4.0813198685646057e-01
    z[0,1,4]  R241      1.0320943593978882e-01
    z[0,1,4]  R242      5.1756995916366577e-01
    z[0,1,4]  R243      0.363953173160553
    z[0,1,4]  R244      -2.6761695742607117e-01
    z[0,1,4]  R245      -7.7543191611766815e-02
    z[0,1,4]  R246      3.5110303759574890e-01
    z[0,1,5]  R7        -1
    z[0,1,5]  R16       1
    z[0,1,5]  R93       -1
    z[0,1,5]  R94       1
    z[0,1,5]  R97       1.9684407114982605e-01
    z[0,1,5]  R98       2.1400873363018036e-01
    z[0,1,5]  R99       1.7545576393604279e-01
    z[0,1,5]  R100      -8.3863191306591034e-02
    z[0,1,5]  R101      3.5342969000339508e-02
    z[0,1,5]  R102      -2.2698865830898285e-01
    z[0,1,5]  R103      3.7799999117851257e-01
    z[0,1,5]  R104      -7.9122260212898254e-03
    z[0,1,5]  R105      2.4082399904727936e-01
    z[0,1,5]  R106      1.1017414927482605e-01
    z[0,1,5]  R107      3.6226198077201843e-01
    z[0,1,5]  R108      3.0144955962896347e-02
    z[0,1,5]  R109      1.4294551312923431e-01
    z[0,1,5]  R110      1.7544165253639221e-01
    z[0,1,5]  R111      2.3372095823287964e-01
    z[0,1,5]  R112      4.1231876611709595e-01
    z[0,1,5]  R113      3.9987576007843018e-01
    z[0,1,5]  R114      4.1314443945884705e-01
    z[0,1,5]  R115      3.3306348323822021e-01
    z[0,1,5]  R116      1.6043521463871002e-01
    z[0,1,5]  R117      -5.6281950324773788e-02
    z[0,1,5]  R118      -3.6464065313339233e-01
    z[0,1,5]  R119      -3.4621521830558777e-01
    z[0,1,5]  R120      -4.0698921680450439e-01
    z[0,1,5]  R121      -4.0686112642288208e-01
    z[0,1,5]  R122      -2.8368967771530151e-01
    z[0,1,5]  R123      -1.4950375258922577e-01
    z[0,1,5]  R124      -2.9358950257301331e-01
    z[0,1,5]  R125      9.5859030261635780e-03
    z[0,1,5]  R126      -3.9522635936737061e-01
    z[0,1,5]  R127      -1.6145195066928864e-01
    z[0,1,5]  R128      -1.9120676815509796e-01
    z[0,1,5]  R129      -1.1766610294580460e-01
    z[0,1,5]  R130      -2.3118594661355019e-02
    z[0,1,5]  R131      -8.8029861450195312e-02
    z[0,1,5]  R132      -1.0294277220964432e-01
    z[0,1,5]  R133      -3.1823366880416870e-01
    z[0,1,5]  R134      -2.9804265499114990e-01
    z[0,1,5]  R135      -3.8015264272689819e-01
    z[0,1,5]  R136      -5.3212952613830566e-01
    z[0,1,5]  R137      -1.7609718441963196e-01
    z[0,1,5]  R138      -2.2707961499691010e-01
    z[0,1,5]  R139      -2.2068646550178528e-01
    z[0,1,5]  R140      -3.7052431702613831e-01
    z[0,1,5]  R141      1.1809995397925377e-02
    z[0,1,5]  R142      -1.8104976415634155e-01
    z[0,1,5]  R143      1.3202938437461853e-01
    z[0,1,5]  R144      -9.1548189520835876e-03
    z[0,1,5]  R145      -8.9364543557167053e-02
    z[0,1,5]  R146      4.1444590687751770e-01
    z[0,1,5]  R147      7.5835309922695160e-02
    z[0,1,5]  R148      7.5173109769821167e-02
    z[0,1,5]  R149      -1.4381489157676697e-01
    z[0,1,5]  R150      -2.3718622326850891e-01
    z[0,1,5]  R151      -3.9254122972488403e-01
    z[0,1,5]  R152      -6.2953993678092957e-02
    z[0,1,5]  R153      -5.6849384307861328e-01
    z[0,1,5]  R154      3.0457329750061035e-01
    z[0,1,5]  R155      4.8995118588209152e-02
    z[0,1,5]  R156      2.5946235656738281e-01
    z[0,1,5]  R157      -5.9924560785293579e-01
    z[0,1,5]  R158      -6.7017114162445068e-01
    z[0,1,5]  R159      -1.7075255513191223e-01
    z[0,1,5]  R160      -3.4536325931549072e-01
    z[0,1,5]  R161      -4.1791123151779175e-01
    z[0,1,5]  R162      -1.6387729346752167e-01
    z[0,1,5]  R163      -2.5673899799585342e-02
    z[0,1,5]  R164      -2.7564057707786560e-01
    z[0,1,5]  R165      1.8572375178337097e-01
    z[0,1,5]  R166      -9.6274352073669434e-01
    z[0,1,5]  R167      2.6516011357307434e-01
    z[0,1,5]  R168      3.3366104960441589e-01
    z[0,1,5]  R169      7.6006367802619934e-02
    z[0,1,5]  R170      -2.2798164281994104e-03
    z[0,1,5]  R171      1.8446385860443115e-01
    z[0,1,5]  R172      4.1964945197105408e-01
    z[0,1,5]  R173      6.3277292251586914e-01
    z[0,1,5]  R174      6.8420600891113281e-01
    z[0,1,5]  R175      4.3545350432395935e-01
    z[0,1,5]  R176      0.063116155564785
    z[0,1,5]  R177      -1.3539710640907288e-01
    z[0,1,5]  R178      1.9015109539031982e-01
    z[0,1,5]  R179      -3.3738423138856888e-02
    z[0,1,5]  R180      -1.1009259521961212e-01
    z[0,1,5]  R181      -6.6776549816131592e-01
    z[0,1,5]  R182      -2.7803018689155579e-01
    z[0,1,5]  R183      -5.8783525228500366e-01
    z[0,1,5]  R184      3.4181165695190430e-01
    z[0,1,5]  R185      3.4685772657394409e-01
    z[0,1,5]  R186      -1.1427142471075058e-01
    z[0,1,5]  R187      -5.1246547698974609e-01
    z[0,1,5]  R188      -4.7744181752204895e-01
    z[0,1,5]  R189      -2.8765550255775452e-01
    z[0,1,5]  R190      7.3895724490284920e-03
    z[0,1,5]  R191      6.5908366441726685e-01
    z[0,1,5]  R192      2.7482289075851440e-01
    z[0,1,5]  R193      3.5857841372489929e-01
    z[0,1,5]  R194      2.5697714090347290e-01
    z[0,1,5]  R195      6.2740236520767212e-01
    z[0,1,5]  R196      5.1673984527587891e-01
    z[0,1,5]  R197      -5.4225660860538483e-02
    z[0,1,5]  R198      6.7273318767547607e-01
    z[0,1,5]  R199      -1.2929636240005493e-01
    z[0,1,5]  R200      1.8573950231075287e-01
    z[0,1,5]  R201      2.3989351093769073e-01
    z[0,1,5]  R202      2.4207981303334236e-02
    z[0,1,5]  R203      6.8009041249752045e-02
    z[0,1,5]  R204      0.700463056564331
    z[0,1,5]  R205      3.8692724704742432e-01
    z[0,1,5]  R206      3.0215749144554138e-01
    z[0,1,5]  R207      -5.6540167331695557e-01
    z[0,1,5]  R208      2.5111094117164612e-01
    z[0,1,5]  R209      1.6509608924388885e-01
    z[0,1,5]  R210      3.1623688340187073e-01
    z[0,1,5]  R211      5.9986698627471924e-01
    z[0,1,5]  R212      6.2607699632644653e-01
    z[0,1,5]  R213      1.8678721785545349e-01
    z[0,1,5]  R214      1.6764141619205475e-01
    z[0,1,5]  R215      2.6683539152145386e-01
    z[0,1,5]  R216      5.9409722685813904e-02
    z[0,1,5]  R217      -6.5568573772907257e-02
    z[0,1,5]  R218      1.6529381275177002e-01
    z[0,1,5]  R219      -6.3907362520694733e-02
    z[0,1,5]  R220      -0.189733624458313
    z[0,1,5]  R221      1.4546598494052887e-01
    z[0,1,5]  R222      -2.4480000138282776e-01
    z[0,1,5]  R223      2.4261584877967834e-01
    z[0,1,5]  R224      5.1766520738601685e-01
    z[0,1,5]  R225      -2.2911494597792625e-02
    z[0,1,5]  R226      -1.3159135123714805e-03
    z[0,1,5]  R227      -4.8959231376647949e-01
    z[0,1,5]  R228      1.2369251251220703e-01
    z[0,1,5]  R229      1.8714118003845215e-01
    z[0,1,5]  R230      0.262578547000885
    z[0,1,5]  R231      -8.0211512744426727e-02
    z[0,1,5]  R232      -3.1390699744224548e-01
    z[0,1,5]  R233      -5.3827010095119476e-02
    z[0,1,5]  R234      2.3970412090420723e-02
    z[0,1,5]  R235      7.8765578567981720e-02
    z[0,1,5]  R236      -3.7683773040771484e-01
    z[0,1,5]  R237      -0.0905112773180008
    z[0,1,5]  R238      -6.7866414785385132e-01
    z[0,1,5]  R239      -1.1712118051946163e-02
    z[0,1,5]  R240      6.3943368196487427e-01
    z[0,1,5]  R241      -1.3582212850451469e-02
    z[0,1,5]  R242      2.7645006775856018e-01
    z[0,1,5]  R243      -1.7054859548807144e-02
    z[0,1,5]  R244      2.4767701327800751e-01
    z[0,1,5]  R245      7.2591237723827362e-02
    z[0,1,5]  R246      9.5383025705814362e-02
    z[0,1,6]  R8        -1
    z[0,1,6]  R17       1
    z[0,1,6]  R95       -1
    z[0,1,6]  R96       1
    z[0,1,6]  R97       -2.3867608606815338e-01
    z[0,1,6]  R98       -2.8994879126548767e-01
    z[0,1,6]  R99       2.2076773643493652e-01
    z[0,1,6]  R100      -3.2592701911926270e-01
    z[0,1,6]  R101      -3.1702980399131775e-02
    z[0,1,6]  R102      1.8523052334785461e-01
    z[0,1,6]  R103      1.6725838184356689e-01
    z[0,1,6]  R104      8.6627446115016937e-02
    z[0,1,6]  R105      2.2655488550662994e-01
    z[0,1,6]  R106      2.8011319041252136e-01
    z[0,1,6]  R107      0.245841383934021
    z[0,1,6]  R108      0.097848080098629
    z[0,1,6]  R109      -1.8725836277008057e-01
    z[0,1,6]  R110      -2.1693013608455658e-02
    z[0,1,6]  R111      3.1365182995796204e-01
    z[0,1,6]  R112      1.1375698447227478e-01
    z[0,1,6]  R113      9.7162231802940369e-02
    z[0,1,6]  R114      -1.0808359831571579e-01
    z[0,1,6]  R115      -6.4100623130798340e-02
    z[0,1,6]  R116      1.3626888394355774e-01
    z[0,1,6]  R117      -1.7072747647762299e-01
    z[0,1,6]  R118      -3.0899396166205406e-02
    z[0,1,6]  R119      -4.1400483250617981e-01
    z[0,1,6]  R120      -8.5938654839992523e-02
    z[0,1,6]  R121      -1.3139389455318451e-01
    z[0,1,6]  R122      -1.9289404153823853e-01
    z[0,1,6]  R123      2.1805499494075775e-01
    z[0,1,6]  R124      -3.6004860885441303e-03
    z[0,1,6]  R125      -1.7021040618419647e-01
    z[0,1,6]  R126      -8.1121474504470825e-03
    z[0,1,6]  R127      -8.0257803201675415e-02
    z[0,1,6]  R128      0.00755949504673481
    z[0,1,6]  R129      -9.6115969121456146e-02
    z[0,1,6]  R130      -9.2945620417594910e-02
    z[0,1,6]  R131      2.6474019885063171e-01
    z[0,1,6]  R132      -4.0284439921379089e-01
    z[0,1,6]  R133      6.5613955259323120e-02
    z[0,1,6]  R134      4.5896759629249573e-01
    z[0,1,6]  R135      -1.4630749821662903e-01
    z[0,1,6]  R136      -2.8226310014724731e-01
    z[0,1,6]  R137      -0.154501274228096
    z[0,1,6]  R138      2.2523556649684906e-01
    z[0,1,6]  R139      3.8888379931449890e-01
    z[0,1,6]  R140      -3.0032485723495483e-01
    z[0,1,6]  R141      3.7741836905479431e-01
    z[0,1,6]  R142      -3.9454710483551025e-01
    z[0,1,6]  R143      1.6951330006122589e-01
    z[0,1,6]  R144      -1.9711382687091827e-01
    z[0,1,6]  R145      -3.0246462672948837e-02
    z[0,1,6]  R146      -1.7947243154048920e-01
    z[0,1,6]  R147      -2.1330793201923370e-01
    z[0,1,6]  R148      -2.7563467621803284e-01
    z[0,1,6]  R149      -3.2324469089508057e-01
    z[0,1,6]  R150      6.4031504094600677e-02
    z[0,1,6]  R151      -1.0182687640190125e-01
    z[0,1,6]  R152      -8.6366616189479828e-02
    z[0,1,6]  R153      2.0609053969383240e-01
    z[0,1,6]  R154      7.7185044065117836e-03
    z[0,1,6]  R155      3.2198838889598846e-02
    z[0,1,6]  R156      0.0327945351600647
    z[0,1,6]  R157      5.4936385154724121e-01
    z[0,1,6]  R158      -2.6172572374343872e-01
    z[0,1,6]  R159      -0.285825252532959
    z[0,1,6]  R160      -3.6537206172943115e-01
    z[0,1,6]  R161      -3.1697034835815430e-01
    z[0,1,6]  R162      3.1209623813629150e-01
    z[0,1,6]  R163      -1.7608475685119629e-01
    z[0,1,6]  R164      -1.7964359372854233e-02
    z[0,1,6]  R165      1.8934594467282295e-02
    z[0,1,6]  R166      7.0240586996078491e-02
    z[0,1,6]  R167      -4.1481410153210163e-03
    z[0,1,6]  R168      9.4167903065681458e-02
    z[0,1,6]  R169      -5.0156249199062586e-04
    z[0,1,6]  R170      -4.9856850504875183e-01
    z[0,1,6]  R171      9.0561136603355408e-02
    z[0,1,6]  R172      5.0405509769916534e-02
    z[0,1,6]  R173      -1.9536618143320084e-02
    z[0,1,6]  R174      -4.4646725058555603e-01
    z[0,1,6]  R175      -1.3794755935668945e-01
    z[0,1,6]  R176      -8.6756169795989990e-02
    z[0,1,6]  R177      2.6139521598815918e-01
    z[0,1,6]  R178      1.7950955033302307e-01
    z[0,1,6]  R179      -1.4895421266555786e-01
    z[0,1,6]  R180      1.0262466222047806e-01
    z[0,1,6]  R181      2.6971647143363953e-01
    z[0,1,6]  R182      5.8602774143218994e-01
    z[0,1,6]  R183      -0.0789579525589943
    z[0,1,6]  R184      -9.7000725567340851e-02
    z[0,1,6]  R185      4.7660249471664429e-01
    z[0,1,6]  R186      -5.0564175471663475e-03
    z[0,1,6]  R187      -1.0765118151903152e-01
    z[0,1,6]  R188      -2.3900514468550682e-02
    z[0,1,6]  R189      -4.3533239513635635e-02
    z[0,1,6]  R190      -1.5683084726333618e-01
    z[0,1,6]  R191      1.6710405051708221e-01
    z[0,1,6]  R192      0.559935986995697
    z[0,1,6]  R193      7.9860344529151917e-02
    z[0,1,6]  R194      -5.3181725740432739e-01
    z[0,1,6]  R195      2.6263775303959846e-02
    z[0,1,6]  R196      -8.4048651158809662e-02
    z[0,1,6]  R197      -3.4072157740592957e-01
    z[0,1,6]  R198      2.9886773228645325e-01
    z[0,1,6]  R199      1.3904240727424622e-01
    z[0,1,6]  R200      -7.8896619379520416e-02
    z[0,1,6]  R201      0.7186239361763
    z[0,1,6]  R202      -2.8426237404346466e-02
    z[0,1,6]  R203      -5.2897542715072632e-01
    z[0,1,6]  R204      2.2473634779453278e-01
    z[0,1,6]  R205      0.502406656742096
    z[0,1,6]  R206      2.8155499696731567e-01
    z[0,1,6]  R207      2.4540470913052559e-02
    z[0,1,6]  R208      4.8982140421867371e-01
    z[0,1,6]  R209      -3.2377848029136658e-01
    z[0,1,6]  R210      2.6192527264356613e-02
    z[0,1,6]  R211      -4.1526150703430176e-01
    z[0,1,6]  R212      -3.7852057814598083e-01
    z[0,1,6]  R213      -1.5117228031158447e-01
    z[0,1,6]  R214      2.6974314451217651e-01
    z[0,1,6]  R215      2.4181246757507324e-01
    z[0,1,6]  R216      -3.5141488909721375e-01
    z[0,1,6]  R217      -1.6979727149009705e-01
    z[0,1,6]  R218      1.0500414669513702e-01
    z[0,1,6]  R219      2.7354088425636292e-01
    z[0,1,6]  R220      5.2951216697692871e-01
    z[0,1,6]  R221      5.1548373699188232e-01
    z[0,1,6]  R222      2.6870566606521606e-01
    z[0,1,6]  R223      -2.3152175545692444e-01
    z[0,1,6]  R224      2.5246503949165344e-01
    z[0,1,6]  R225      -6.2848613597452641e-03
    z[0,1,6]  R226      -1.0438323020935059e-02
    z[0,1,6]  R227      -1.5473565459251404e-01
    z[0,1,6]  R228      -1.5618702769279480e-01
    z[0,1,6]  R229      1.9208897650241852e-01
    z[0,1,6]  R230      -0.0856553316116333
    z[0,1,6]  R231      4.8573899269104004e-01
    z[0,1,6]  R232      2.2684057056903839e-01
    z[0,1,6]  R233      1.2641890347003937e-01
    z[0,1,6]  R234      -3.3749712165445089e-03
    z[0,1,6]  R235      -1.2154351174831390e-01
    z[0,1,6]  R236      0.180814728140831
    z[0,1,6]  R237      3.6732730269432068e-01
    z[0,1,6]  R238      2.5281503796577454e-01
    z[0,1,6]  R239      -2.0104783773422241e-01
    z[0,1,6]  R240      -2.5840455293655396e-01
    z[0,1,6]  R241      -2.1076993644237518e-01
    z[0,1,6]  R242      2.3696507513523102e-01
    z[0,1,6]  R243      -1.7199589312076569e-01
    z[0,1,6]  R244      -2.7896878123283386e-01
    z[0,1,6]  R245      1.9066981971263885e-01
    z[0,1,6]  R246      1.8433047458529472e-02
    z[1,0,0]  R2        1
    z[1,0,0]  R11       -1
    z[1,0,0]  R247      -1
    z[1,0,0]  R248      1
    z[1,0,0]  R261      -2.4888327717781067e-01
    z[1,0,0]  R262      2.9550388455390930e-01
    z[1,0,0]  R263      8.3232897520065308e-01
    z[1,0,0]  R264      -1.4328254759311676e-01
    z[1,0,0]  R265      6.8893134593963623e-01
    z[1,0,0]  R266      6.3776654005050659e-01
    z[1,0,0]  R267      6.7820006608963013e-01
    z[1,0,0]  R268      2.3337113857269287e-01
    z[1,0,0]  R269      6.2497007846832275e-01
    z[1,0,0]  R270      2.1322837099432945e-02
    z[1,0,0]  R271      -4.1167397052049637e-02
    z[1,0,0]  R272      0.197298064827919
    z[1,0,0]  R273      7.4670299887657166e-02
    z[1,0,0]  R274      -3.1563094258308411e-01
    z[1,0,0]  R275      2.6661109924316406e-01
    z[1,0,0]  R276      -3.2656931877136230e-01
    z[1,0,0]  R277      9.9142841994762421e-02
    z[1,0,0]  R278      -1.1139763146638870e-01
    z[1,0,0]  R279      -0.272646963596344
    z[1,0,0]  R280      -8.6569702625274658e-01
    z[1,0,0]  R281      5.5740630626678467e-01
    z[1,0,0]  R282      3.8298237323760986e-01
    z[1,0,0]  R283      5.6362771987915039e-01
    z[1,0,0]  R284      -1.5003240108489990e-01
    z[1,0,0]  R285      3.6029480397701263e-02
    z[1,0,0]  R286      5.7309955358505249e-01
    z[1,0,0]  R287      2.9047846794128418e-01
    z[1,0,0]  R288      -4.2058023810386658e-01
    z[1,0,0]  R289      1.9371148943901062e-01
    z[1,0,0]  R290      1.0605355352163315e-01
    z[1,0,0]  R291      -4.2197060585021973e-01
    z[1,0,0]  R292      3.2461223006248474e-01
    z[1,0,0]  R293      -3.6581054329872131e-02
    z[1,0,0]  R294      -6.8960803747177124e-01
    z[1,0,0]  R295      4.0713912248611450e-01
    z[1,0,0]  R296      4.5497044920921326e-01
    z[1,0,0]  R297      1.2219832837581635e-01
    z[1,0,0]  R298      3.0583182349801064e-02
    z[1,0,0]  R299      5.2356415987014771e-01
    z[1,0,0]  R300      -2.0894527435302734e-01
    z[1,0,0]  R301      -3.1633329391479492e-01
    z[1,0,0]  R302      5.6508135795593262e-01
    z[1,0,0]  R303      4.9432608485221863e-01
    z[1,0,0]  R304      -2.7010399103164673e-01
    z[1,0,0]  R305      4.9844551086425781e-01
    z[1,0,0]  R306      7.7687317132949829e-01
    z[1,0,0]  R307      4.5036911964416504e-01
    z[1,0,0]  R308      1.1800721287727356e-01
    z[1,0,0]  R309      7.1246273815631866e-02
    z[1,0,0]  R310      -5.7230882346630096e-02
    z[1,0,0]  R311      5.3158521652221680e-01
    z[1,0,0]  R312      6.1826932430267334e-01
    z[1,0,0]  R313      0.55652916431427
    z[1,0,0]  R314      -1.5125067532062531e-01
    z[1,0,0]  R315      -2.2938007116317749e-01
    z[1,0,0]  R316      4.9938037991523743e-02
    z[1,0,0]  R317      3.5751166939735413e-01
    z[1,0,0]  R318      -8.9586025476455688e-01
    z[1,0,0]  R319      -8.6483961343765259e-01
    z[1,0,0]  R320      -1.9328846037387848e-01
    z[1,0,0]  R321      8.0055320262908936e-01
    z[1,0,0]  R322      5.7469260692596436e-01
    z[1,0,0]  R323      4.0401884913444519e-01
    z[1,0,0]  R324      6.0170054435729980e-01
    z[1,0,0]  R325      5.9632128477096558e-01
    z[1,0,0]  R326      4.4133958220481873e-01
    z[1,0,0]  R327      1.0224746540188789e-02
    z[1,0,0]  R328      1.9180500507354736e-01
    z[1,0,0]  R329      -1.4825040102005005e-01
    z[1,0,0]  R330      -8.7072724103927612e-01
    z[1,0,0]  R331      7.7404584735631943e-03
    z[1,0,0]  R332      2.9487663507461548e-01
    z[1,0,0]  R333      5.8443647623062134e-01
    z[1,0,0]  R334      5.4683828353881836e-01
    z[1,0,0]  R335      2.2184620797634125e-01
    z[1,0,0]  R336      -2.4688437581062317e-01
    z[1,0,0]  R337      -3.2373899221420288e-01
    z[1,0,0]  R338      -3.7914934754371643e-01
    z[1,0,0]  R339      -4.8320788145065308e-01
    z[1,0,0]  R340      -3.3936527371406555e-01
    z[1,0,0]  R341      -2.8650021553039551e-01
    z[1,0,0]  R342      5.4303503036499023e-01
    z[1,0,0]  R343      -8.1450039148330688e-01
    z[1,0,0]  R344      -1.3905651867389679e-01
    z[1,0,0]  R345      -4.7093746066093445e-01
    z[1,0,0]  R346      -2.9865953326225281e-01
    z[1,0,0]  R347      -3.7797302007675171e-01
    z[1,0,0]  R348      -8.5167139768600464e-01
    z[1,0,0]  R349      -2.7430984377861023e-01
    z[1,0,0]  R350      -3.3804914355278015e-01
    z[1,0,0]  R351      3.1617248058319092e-01
    z[1,0,0]  R352      5.7669192552566528e-01
    z[1,0,0]  R353      4.7605317831039429e-01
    z[1,0,0]  R354      4.6785807609558105e-01
    z[1,0,0]  R355      8.7497037649154663e-01
    z[1,0,0]  R356      7.1143907308578491e-01
    z[1,0,0]  R357      6.8296575546264648e-01
    z[1,0,0]  R358      8.1498926877975464e-01
    z[1,0,0]  R359      0.185358464717865
    z[1,0,0]  R360      4.7616714239120483e-01
    z[1,0,0]  R361      -4.9223318696022034e-01
    z[1,0,0]  R362      -5.4711413383483887e-01
    z[1,0,0]  R363      -2.4950566887855530e-01
    z[1,0,0]  R364      -4.1189306974411011e-01
    z[1,0,0]  R365      -3.0863013863563538e-01
    z[1,0,0]  R366      -4.8976475000381470e-01
    z[1,0,0]  R367      -1.5400357544422150e-01
    z[1,0,0]  R368      -4.3866270780563354e-01
    z[1,0,0]  R369      -4.7704404592514038e-01
    z[1,0,0]  R370      -2.4821718037128448e-01
    z[1,0,0]  R371      1.1715054512023926e-01
    z[1,0,0]  R372      -7.2085000574588776e-02
    z[1,0,0]  R373      -7.1591906249523163e-02
    z[1,0,0]  R374      2.9847750067710876e-01
    z[1,0,0]  R375      -4.2866292595863342e-01
    z[1,0,0]  R376      -0.407634973526001
    z[1,0,0]  R377      -3.9184358716011047e-01
    z[1,0,0]  R378      -5.7812762260437012e-01
    z[1,0,0]  R379      2.7833279222249985e-02
    z[1,0,0]  R380      -2.9819878935813904e-01
    z[1,0,0]  R381      6.3001766800880432e-02
    z[1,0,0]  R382      0.0899825319647789
    z[1,0,0]  R383      2.5428640842437744e-01
    z[1,0,0]  R384      3.2596611976623535e-01
    z[1,0,0]  R385      3.4396609663963318e-01
    z[1,0,0]  R386      -2.6913258433341980e-01
    z[1,0,0]  R387      -2.6759406924247742e-01
    z[1,0,0]  R388      3.4607195854187012e-01
    z[1,0,0]  R389      4.3527016043663025e-01
    z[1,0,0]  R390      -1.2859259545803070e-01
    z[1,0,0]  R391      9.0489076683297753e-04
    z[1,0,0]  R392      1.2812386453151703e-01
    z[1,0,0]  R393      2.0964090526103973e-01
    z[1,0,0]  R394      3.1280410289764404e-01
    z[1,0,0]  R395      1.2833017110824585e-01
    z[1,0,0]  R396      -0.756442666053772
    z[1,0,0]  R397      -3.5724371671676636e-01
    z[1,0,0]  R398      -3.8763898611068726e-01
    z[1,0,0]  R399      -2.8695088624954224e-01
    z[1,0,0]  R400      -5.0645190477371216e-01
    z[1,0,0]  R401      -6.2723271548748016e-02
    z[1,0,0]  R402      1.7746257781982422e-01
    z[1,0,0]  R403      -7.8412890434265137e-01
    z[1,0,0]  R404      -3.7134975194931030e-01
    z[1,0,0]  R405      -4.2428565025329590e-01
    z[1,0,0]  R406      -3.3557087182998657e-01
    z[1,0,0]  R407      -1.0943162441253662e-01
    z[1,0,0]  R408      -4.9729606509208679e-01
    z[1,0,0]  R409      -8.1524938344955444e-01
    z[1,0,0]  R410      -7.9225832223892212e-01
    z[1,0,1]  R3        1
    z[1,0,1]  R12       -1
    z[1,0,1]  R249      -1
    z[1,0,1]  R250      1
    z[1,0,1]  R261      2.4882024526596069e-01
    z[1,0,1]  R262      2.6027470827102661e-01
    z[1,0,1]  R263      -4.2193830013275146e-01
    z[1,0,1]  R264      0.357695609331131
    z[1,0,1]  R265      -3.3583068847656250e-01
    z[1,0,1]  R266      -3.4383061528205872e-01
    z[1,0,1]  R267      -1.9444961845874786e-01
    z[1,0,1]  R268      1.3967826031148434e-02
    z[1,0,1]  R269      -3.1188753247261047e-01
    z[1,0,1]  R270      2.2355954349040985e-01
    z[1,0,1]  R271      0.705487847328186
    z[1,0,1]  R272      8.1740945577621460e-01
    z[1,0,1]  R273      8.3081430196762085e-01
    z[1,0,1]  R274      2.1704234182834625e-02
    z[1,0,1]  R275      -1.3921430706977844e-01
    z[1,0,1]  R276      6.7283344268798828e-01
    z[1,0,1]  R277      -1.8174204230308533e-01
    z[1,0,1]  R278      -1.8991971015930176e-01
    z[1,0,1]  R279      -4.8471625894308090e-02
    z[1,0,1]  R280      2.9968783259391785e-01
    z[1,0,1]  R281      -9.8242938518524170e-02
    z[1,0,1]  R282      5.8050528168678284e-03
    z[1,0,1]  R283      -3.5034117102622986e-01
    z[1,0,1]  R284      -1.2987117469310760e-01
    z[1,0,1]  R285      1.1567724496126175e-01
    z[1,0,1]  R286      1.6094347462058067e-02
    z[1,0,1]  R287      -1.6576437279582024e-02
    z[1,0,1]  R288      -2.4119272828102112e-02
    z[1,0,1]  R289      1.4139761030673981e-01
    z[1,0,1]  R290      2.7130430936813354e-01
    z[1,0,1]  R291      1.3013286888599396e-01
    z[1,0,1]  R292      3.7456490099430084e-02
    z[1,0,1]  R293      1.4031082391738892e-01
    z[1,0,1]  R294      6.1334484815597534e-01
    z[1,0,1]  R295      -2.7111306786537170e-01
    z[1,0,1]  R296      -1.4592204988002777e-01
    z[1,0,1]  R297      3.8224789313971996e-03
    z[1,0,1]  R298      -1.3744835555553436e-01
    z[1,0,1]  R299      1.4315118081867695e-02
    z[1,0,1]  R300      4.2679074406623840e-01
    z[1,0,1]  R301      2.2771829366683960e-01
    z[1,0,1]  R302      -1.6862352192401886e-01
    z[1,0,1]  R303      -1.5798328816890717e-01
    z[1,0,1]  R304      7.6394850015640259e-01
    z[1,0,1]  R305      -1.6039286553859711e-01
    z[1,0,1]  R306      -2.6861509680747986e-01
    z[1,0,1]  R307      -8.6294472217559814e-02
    z[1,0,1]  R308      -2.0825612545013428e-01
    z[1,0,1]  R309      -4.2793910950422287e-02
    z[1,0,1]  R310      1.2584343552589417e-02
    z[1,0,1]  R311      -1.5589401125907898e-01
    z[1,0,1]  R312      -1.0465943068265915e-01
    z[1,0,1]  R313      -2.6423647999763489e-01
    z[1,0,1]  R314      5.7704836130142212e-02
    z[1,0,1]  R315      1.0573582351207733e-01
    z[1,0,1]  R316      -9.8005570471286774e-02
    z[1,0,1]  R317      1.0065460205078125e-01
    z[1,0,1]  R318      2.9242733120918274e-01
    z[1,0,1]  R319      2.2574819624423981e-01
    z[1,0,1]  R320      -7.5025148689746857e-02
    z[1,0,1]  R321      -1.9033451378345490e-01
    z[1,0,1]  R322      -3.3282455801963806e-01
    z[1,0,1]  R323      6.4190918207168579e-01
    z[1,0,1]  R324      -2.4728335440158844e-01
    z[1,0,1]  R325      -2.0644631981849670e-01
    z[1,0,1]  R326      -2.3136278986930847e-01
    z[1,0,1]  R327      -8.6752094328403473e-02
    z[1,0,1]  R328      1.9959920644760132e-01
    z[1,0,1]  R329      3.5830289125442505e-02
    z[1,0,1]  R330      2.3080386221408844e-01
    z[1,0,1]  R331      2.6614561676979065e-01
    z[1,0,1]  R332      1.9011251628398895e-01
    z[1,0,1]  R333      -3.3396637439727783e-01
    z[1,0,1]  R334      -5.5149450898170471e-02
    z[1,0,1]  R335      2.3891791701316833e-01
    z[1,0,1]  R336      2.1255789697170258e-01
    z[1,0,1]  R337      2.9950019717216492e-01
    z[1,0,1]  R338      2.9912093281745911e-01
    z[1,0,1]  R339      -0.189732626080513
    z[1,0,1]  R340      -3.0053177475929260e-01
    z[1,0,1]  R341      1.2896591797471046e-02
    z[1,0,1]  R342      -0.0914396345615387
    z[1,0,1]  R343      1.4442013204097748e-01
    z[1,0,1]  R344      -2.7446159720420837e-01
    z[1,0,1]  R345      1.1482341587543488e-01
    z[1,0,1]  R346      -1.2507946230471134e-02
    z[1,0,1]  R347      2.3167058825492859e-01
    z[1,0,1]  R348      7.7691055834293365e-02
    z[1,0,1]  R349      1.3147634267807007e-01
    z[1,0,1]  R350      -7.9999083280563354e-01
    z[1,0,1]  R351      -2.2488594055175781e-01
    z[1,0,1]  R352      -1.2939150631427765e-01
    z[1,0,1]  R353      -2.1679200232028961e-01
    z[1,0,1]  R354      -4.0721505880355835e-01
    z[1,0,1]  R355      -1.8201905488967896e-01
    z[1,0,1]  R356      -3.6664776504039764e-02
    z[1,0,1]  R357      -3.5846021771430969e-01
    z[1,0,1]  R358      -2.6038247346878052e-01
    z[1,0,1]  R359      -6.8155348300933838e-01
    z[1,0,1]  R360      -2.8164952993392944e-01
    z[1,0,1]  R361      6.2968921661376953e-01
    z[1,0,1]  R362      6.2375122308731079e-01
    z[1,0,1]  R363      6.4590960741043091e-01
    z[1,0,1]  R364      8.7937724590301514e-01
    z[1,0,1]  R365      7.2811561822891235e-01
    z[1,0,1]  R366      4.4551664590835571e-01
    z[1,0,1]  R367      7.0651078224182129e-01
    z[1,0,1]  R368      6.0509574413299561e-01
    z[1,0,1]  R369      4.0943464636802673e-01
    z[1,0,1]  R370      0.868427574634552
    z[1,0,1]  R371      7.7697628736495972e-01
    z[1,0,1]  R372      8.2676619291305542e-01
    z[1,0,1]  R373      7.4282425642013550e-01
    z[1,0,1]  R374      5.9907871484756470e-01
    z[1,0,1]  R375      3.6086297035217285e-01
    z[1,0,1]  R376      -5.0757569074630737e-01
    z[1,0,1]  R377      1.7272317409515381e-01
    z[1,0,1]  R378      -3.2708102464675903e-01
    z[1,0,1]  R379      4.5395290851593018e-01
    z[1,0,1]  R380      -2.8362569212913513e-01
    z[1,0,1]  R381      9.4584661722183228e-01
    z[1,0,1]  R382      8.3826774358749390e-01
    z[1,0,1]  R383      7.8720378875732422e-01
    z[1,0,1]  R384      8.5944074392318726e-01
    z[1,0,1]  R385      7.4405682086944580e-01
    z[1,0,1]  R386      8.2526820898056030e-01
    z[1,0,1]  R387      7.6957190036773682e-01
    z[1,0,1]  R388      0.693574070930481
    z[1,0,1]  R389      7.0397454500198364e-01
    z[1,0,1]  R390      7.1981674432754517e-01
    z[1,0,1]  R391      8.8600194454193115e-01
    z[1,0,1]  R392      8.1919866800308228e-01
    z[1,0,1]  R393      7.5020068883895874e-01
    z[1,0,1]  R394      7.7050465345382690e-01
    z[1,0,1]  R395      7.8837692737579346e-01
    z[1,0,1]  R396      3.5375913977622986e-01
    z[1,0,1]  R397      3.5882890224456787e-01
    z[1,0,1]  R398      2.7233263850212097e-01
    z[1,0,1]  R399      -6.9074638187885284e-02
    z[1,0,1]  R400      3.1501409411430359e-01
    z[1,0,1]  R401      9.6092832088470459e-01
    z[1,0,1]  R402      9.0106505155563354e-01
    z[1,0,1]  R403      3.6725702881813049e-01
    z[1,0,1]  R404      -4.7007972002029419e-01
    z[1,0,1]  R405      -2.9570633172988892e-01
    z[1,0,1]  R406      3.7011715769767761e-01
    z[1,0,1]  R407      -5.1091857254505157e-02
    z[1,0,1]  R408      -3.9350786805152893e-01
    z[1,0,1]  R409      -0.486627459526062
    z[1,0,1]  R410      -5.2580362558364868e-01
    z[1,0,2]  R4        1
    z[1,0,2]  R13       -1
    z[1,0,2]  R251      -1
    z[1,0,2]  R252      1
    z[1,0,2]  R261      -1.3974243402481079e-01
    z[1,0,2]  R262      -1.0791204869747162e-01
    z[1,0,2]  R263      -1.3351014256477356e-01
    z[1,0,2]  R264      -1.4141140878200531e-01
    z[1,0,2]  R265      3.7054324150085449e-01
    z[1,0,2]  R266      0.481171190738678
    z[1,0,2]  R267      4.4943156838417053e-01
    z[1,0,2]  R268      6.2327116727828979e-01
    z[1,0,2]  R269      8.0959469079971313e-02
    z[1,0,2]  R270      0.0745064914226532
    z[1,0,2]  R271      -5.1401269435882568e-01
    z[1,0,2]  R272      -4.1547033190727234e-01
    z[1,0,2]  R273      -4.5047828555107117e-01
    z[1,0,2]  R274      -6.2747198343276978e-01
    z[1,0,2]  R275      -4.7564360499382019e-01
    z[1,0,2]  R276      3.9179524779319763e-01
    z[1,0,2]  R277      4.8451694846153259e-01
    z[1,0,2]  R278      -8.9959733188152313e-02
    z[1,0,2]  R279      1.5008051693439484e-01
    z[1,0,2]  R280      2.6233983039855957e-01
    z[1,0,2]  R281      -6.8765640258789062e-01
    z[1,0,2]  R282      -0.522006094455719
    z[1,0,2]  R283      2.1208065748214722e-01
    z[1,0,2]  R284      -4.6540012955665588e-01
    z[1,0,2]  R285      -4.6059334278106689e-01
    z[1,0,2]  R286      -0.485392302274704
    z[1,0,2]  R287      -7.0152807235717773e-01
    z[1,0,2]  R288      -0.0619235597550869
    z[1,0,2]  R289      1.6759210824966431e-01
    z[1,0,2]  R290      0.0671146884560585
    z[1,0,2]  R291      -6.9854712486267090e-01
    z[1,0,2]  R292      -0.712831974029541
    z[1,0,2]  R293      -8.8186144828796387e-01
    z[1,0,2]  R294      -2.0456868410110474e-01
    z[1,0,2]  R295      -8.0457948148250580e-02
    z[1,0,2]  R296      6.7947648465633392e-02
    z[1,0,2]  R297      1.7455644905567169e-01
    z[1,0,2]  R298      -2.1403209865093231e-01
    z[1,0,2]  R299      1.9011916220188141e-01
    z[1,0,2]  R300      3.9396515488624573e-01
    z[1,0,2]  R301      -6.0739632695913315e-02
    z[1,0,2]  R302      -1.7637857794761658e-01
    z[1,0,2]  R303      -0.0888201892375946
    z[1,0,2]  R304      2.8243938088417053e-01
    z[1,0,2]  R305      -3.3264991641044617e-01
    z[1,0,2]  R306      0.207072451710701
    z[1,0,2]  R307      0.0663580447435379
    z[1,0,2]  R308      -5.1376353949308395e-02
    z[1,0,2]  R309      -1.8423390388488770e-01
    z[1,0,2]  R310      6.5412461757659912e-02
    z[1,0,2]  R311      5.2865464240312576e-02
    z[1,0,2]  R312      -2.3262429982423782e-02
    z[1,0,2]  R313      0.0476471409201622
    z[1,0,2]  R314      -7.3751728050410748e-03
    z[1,0,2]  R315      1.7571914196014404e-01
    z[1,0,2]  R316      4.0155026316642761e-01
    z[1,0,2]  R317      0.446807324886322
    z[1,0,2]  R318      -1.3759591616690159e-02
    z[1,0,2]  R319      2.1937979757785797e-01
    z[1,0,2]  R320      2.4245730042457581e-01
    z[1,0,2]  R321      3.4914985299110413e-01
    z[1,0,2]  R322      4.2426955699920654e-01
    z[1,0,2]  R323      1.7419147491455078e-01
    z[1,0,2]  R324      1.3603346049785614e-01
    z[1,0,2]  R325      2.2313900291919708e-01
    z[1,0,2]  R326      -3.4275189042091370e-01
    z[1,0,2]  R327      -2.7045145630836487e-01
    z[1,0,2]  R328      3.9838257431983948e-01
    z[1,0,2]  R329      1.9918428361415863e-01
    z[1,0,2]  R330      1.8702767789363861e-01
    z[1,0,2]  R331      -2.1489652991294861e-01
    z[1,0,2]  R332      -5.1691156625747681e-01
    z[1,0,2]  R333      1.2027036398649216e-01
    z[1,0,2]  R334      -5.3264591842889786e-02
    z[1,0,2]  R335      0.0594746358692646
    z[1,0,2]  R336      4.1544923186302185e-01
    z[1,0,2]  R337      3.5326632857322693e-01
    z[1,0,2]  R338      1.8077576160430908e-01
    z[1,0,2]  R339      5.1298856735229492e-01
    z[1,0,2]  R340      4.4338029623031616e-01
    z[1,0,2]  R341      -4.2498657107353210e-01
    z[1,0,2]  R342      -2.2581714391708374e-01
    z[1,0,2]  R343      0.324491411447525
    z[1,0,2]  R344      4.4395741820335388e-01
    z[1,0,2]  R345      4.9326434731483459e-01
    z[1,0,2]  R346      3.2187905907630920e-01
    z[1,0,2]  R347      4.0216556191444397e-01
    z[1,0,2]  R348      2.0421876013278961e-01
    z[1,0,2]  R349      7.1265482902526855e-01
    z[1,0,2]  R350      1.3422681391239166e-01
    z[1,0,2]  R351      6.9641411304473877e-01
    z[1,0,2]  R352      6.1756026744842529e-01
    z[1,0,2]  R353      0.746904730796814
    z[1,0,2]  R354      4.7763559222221375e-01
    z[1,0,2]  R355      3.4936192631721497e-01
    z[1,0,2]  R356      5.7652479410171509e-01
    z[1,0,2]  R357      2.7917012572288513e-01
    z[1,0,2]  R358      7.9882211983203888e-02
    z[1,0,2]  R359      4.9595010280609131e-01
    z[1,0,2]  R360      -3.1767857726663351e-03
    z[1,0,2]  R361      -3.7552466988563538e-01
    z[1,0,2]  R362      -5.4819935560226440e-01
    z[1,0,2]  R363      -5.2614951133728027e-01
    z[1,0,2]  R364      -1.4535656571388245e-01
    z[1,0,2]  R365      -3.7699118256568909e-01
    z[1,0,2]  R366      -5.6106412410736084e-01
    z[1,0,2]  R367      -4.4130784273147583e-01
    z[1,0,2]  R368      -4.3506258726119995e-01
    z[1,0,2]  R369      -5.6248861551284790e-01
    z[1,0,2]  R370      -3.6139541864395142e-01
    z[1,0,2]  R371      1.6493658721446991e-01
    z[1,0,2]  R372      1.7390790581703186e-01
    z[1,0,2]  R373      3.4230497479438782e-01
    z[1,0,2]  R374      -1.2580266594886780e-01
    z[1,0,2]  R375      -1.4868043363094330e-01
    z[1,0,2]  R376      -1.2460289150476456e-01
    z[1,0,2]  R377      -0.503728985786438
    z[1,0,2]  R378      8.4312453866004944e-02
    z[1,0,2]  R379      -2.4389077723026276e-01
    z[1,0,2]  R380      -3.0800363421440125e-01
    z[1,0,2]  R381      1.3863548636436462e-01
    z[1,0,2]  R382      -2.7512248605489731e-02
    z[1,0,2]  R383      -6.1390563845634460e-02
    z[1,0,2]  R384      -1.9287452101707458e-01
    z[1,0,2]  R385      -3.9840704202651978e-01
    z[1,0,2]  R386      -1.1714725941419601e-01
    z[1,0,2]  R387      -2.4716173112392426e-01
    z[1,0,2]  R388      -2.9159530997276306e-01
    z[1,0,2]  R389      -1.0140753537416458e-01
    z[1,0,2]  R390      -3.0194488167762756e-01
    z[1,0,2]  R391      -1.9755041599273682e-01
    z[1,0,2]  R392      -2.4487484991550446e-01
    z[1,0,2]  R393      -0.43577840924263
    z[1,0,2]  R394      -1.1846154229715466e-03
    z[1,0,2]  R395      7.1419939398765564e-02
    z[1,0,2]  R396      -1.8547539412975311e-01
    z[1,0,2]  R397      -3.4186357259750366e-01
    z[1,0,2]  R398      -5.1645022630691528e-01
    z[1,0,2]  R399      -1.0560575872659683e-01
    z[1,0,2]  R400      -1.4410842955112457e-01
    z[1,0,2]  R401      6.8419404327869415e-02
    z[1,0,2]  R402      -4.0451448410749435e-02
    z[1,0,2]  R403      -1.9884806871414185e-01
    z[1,0,2]  R404      -2.1745659410953522e-01
    z[1,0,2]  R405      -2.4599377810955048e-01
    z[1,0,2]  R406      2.0575824379920959e-01
    z[1,0,2]  R407      -4.7127166390419006e-01
    z[1,0,2]  R408      1.4961537718772888e-01
    z[1,0,2]  R409      -1.8319293856620789e-01
    z[1,0,2]  R410      -1.3706816732883453e-01
    z[1,0,3]  R5        1
    z[1,0,3]  R14       -1
    z[1,0,3]  R253      -1
    z[1,0,3]  R254      1
    z[1,0,3]  R261      4.2786693572998047e-01
    z[1,0,3]  R262      5.6138175725936890e-01
    z[1,0,3]  R263      -2.1517328917980194e-02
    z[1,0,3]  R264      6.8580663204193115e-01
    z[1,0,3]  R265      -3.8698457647114992e-03
    z[1,0,3]  R266      3.2861644029617310e-01
    z[1,0,3]  R267      -1.2012303620576859e-01
    z[1,0,3]  R268      5.5567485094070435e-01
    z[1,0,3]  R269      -1.2867744266986847e-01
    z[1,0,3]  R270      -5.6563433259725571e-02
    z[1,0,3]  R271      -9.4751402735710144e-02
    z[1,0,3]  R272      -3.3500720746815205e-03
    z[1,0,3]  R273      -2.4091796576976776e-01
    z[1,0,3]  R274      5.9733642265200615e-03
    z[1,0,3]  R275      -6.5414440631866455e-01
    z[1,0,3]  R276      2.4336710572242737e-01
    z[1,0,3]  R277      -4.4006025791168213e-01
    z[1,0,3]  R278      -4.2608228325843811e-01
    z[1,0,3]  R279      -7.2649914026260376e-01
    z[1,0,3]  R280      -1.6354420781135559e-01
    z[1,0,3]  R281      6.0123833827674389e-03
    z[1,0,3]  R282      6.9074296951293945e-01
    z[1,0,3]  R283      -1.8271112442016602e-01
    z[1,0,3]  R284      -2.5598838925361633e-02
    z[1,0,3]  R285      -4.3165674805641174e-01
    z[1,0,3]  R286      4.8092268407344818e-02
    z[1,0,3]  R287      -2.3779571056365967e-01
    z[1,0,3]  R288      -6.3250350952148438e-01
    z[1,0,3]  R289      2.6156967878341675e-01
    z[1,0,3]  R290      -8.4441676735877991e-02
    z[1,0,3]  R291      4.3929345905780792e-02
    z[1,0,3]  R292      2.3876060545444489e-01
    z[1,0,3]  R293      3.4031070768833160e-02
    z[1,0,3]  R294      1.9250829517841339e-01
    z[1,0,3]  R295      5.1246255636215210e-01
    z[1,0,3]  R296      -6.0873252153396606e-01
    z[1,0,3]  R297      -9.0511363744735718e-01
    z[1,0,3]  R298      -7.3025971651077271e-01
    z[1,0,3]  R299      -5.0211775302886963e-01
    z[1,0,3]  R300      -5.5745714902877808e-01
    z[1,0,3]  R301      5.2649700641632080e-01
    z[1,0,3]  R302      1.9932985305786133e-01
    z[1,0,3]  R303      7.8748238086700439e-01
    z[1,0,3]  R304      4.3566811084747314e-01
    z[1,0,3]  R305      -8.1966057419776917e-02
    z[1,0,3]  R306      5.2357977628707886e-01
    z[1,0,3]  R307      1.8273739516735077e-01
    z[1,0,3]  R308      -2.8898784518241882e-01
    z[1,0,3]  R309      -5.8250063657760620e-01
    z[1,0,3]  R310      -8.3422678709030151e-01
    z[1,0,3]  R311      5.9759140014648438e-01
    z[1,0,3]  R312      -5.3690886497497559e-01
    z[1,0,3]  R313      6.7187029123306274e-01
    z[1,0,3]  R314      -9.2615431547164917e-01
    z[1,0,3]  R315      -5.2048432826995850e-01
    z[1,0,3]  R316      -4.4863912463188171e-01
    z[1,0,3]  R317      -7.5512075424194336e-01
    z[1,0,3]  R318      -9.8633371293544769e-02
    z[1,0,3]  R319      1.2380762398242950e-01
    z[1,0,3]  R320      -7.0751684904098511e-01
    z[1,0,3]  R321      -3.8104152679443359e-01
    z[1,0,3]  R322      3.2583260536193848e-01
    z[1,0,3]  R323      5.6155413389205933e-01
    z[1,0,3]  R324      -1.7436213791370392e-01
    z[1,0,3]  R325      -5.1284188032150269e-01
    z[1,0,3]  R326      2.0295481383800507e-01
    z[1,0,3]  R327      -8.3560156822204590e-01
    z[1,0,3]  R328      -4.8282131552696228e-01
    z[1,0,3]  R329      -0.545455276966095
    z[1,0,3]  R330      -0.336578905582428
    z[1,0,3]  R331      5.5588185787200928e-01
    z[1,0,3]  R332      7.5425481796264648e-01
    z[1,0,3]  R333      4.5786008238792419e-01
    z[1,0,3]  R334      3.0420255661010742e-01
    z[1,0,3]  R335      0.0747174620628357
    z[1,0,3]  R336      -0.641779899597168
    z[1,0,3]  R337      -6.8036824464797974e-01
    z[1,0,3]  R338      -6.4183020591735840e-01
    z[1,0,3]  R339      -6.0219085216522217e-01
    z[1,0,3]  R340      -5.9417766332626343e-01
    z[1,0,3]  R341      6.6427206993103027e-01
    z[1,0,3]  R342      2.7343866229057312e-01
    z[1,0,3]  R343      4.0755501389503479e-01
    z[1,0,3]  R344      2.5693568587303162e-01
    z[1,0,3]  R345      -0.682981014251709
    z[1,0,3]  R346      -6.3763946294784546e-01
    z[1,0,3]  R347      -6.9238191843032837e-01
    z[1,0,3]  R348      1.2699677050113678e-01
    z[1,0,3]  R349      -5.9325700998306274e-01
    z[1,0,3]  R350      3.0823636054992676e-01
    z[1,0,3]  R351      5.1677453517913818e-01
    z[1,0,3]  R352      1.2330103665590286e-01
    z[1,0,3]  R353      1.6277417540550232e-01
    z[1,0,3]  R354      4.2016741633415222e-01
    z[1,0,3]  R355      2.2670869529247284e-01
    z[1,0,3]  R356      2.6785820722579956e-01
    z[1,0,3]  R357      -1.0430599562823772e-02
    z[1,0,3]  R358      3.7662589550018311e-01
    z[1,0,3]  R359      2.8773674368858337e-01
    z[1,0,3]  R360      7.7458918094635010e-01
    z[1,0,3]  R361      1.6704623401165009e-01
    z[1,0,3]  R362      2.3247901350259781e-02
    z[1,0,3]  R363      4.1320866346359253e-01
    z[1,0,3]  R364      0.0545872300863266
    z[1,0,3]  R365      1.2594187259674072e-01
    z[1,0,3]  R366      1.6451855003833771e-01
    z[1,0,3]  R367      3.3085045218467712e-01
    z[1,0,3]  R368      2.4973908066749573e-01
    z[1,0,3]  R369      3.9302092790603638e-01
    z[1,0,3]  R370      -8.9879669249057770e-02
    z[1,0,3]  R371      -5.6031066179275513e-01
    z[1,0,3]  R372      -9.8044604063034058e-02
    z[1,0,3]  R373      -1.3259139657020569e-01
    z[1,0,3]  R374      -0.507114827632904
    z[1,0,3]  R375      -6.7938894033432007e-01
    z[1,0,3]  R376      -6.5618109703063965e-01
    z[1,0,3]  R377      -6.9857668876647949e-01
    z[1,0,3]  R378      -6.7651957273483276e-01
    z[1,0,3]  R379      -0.729148805141449
    z[1,0,3]  R380      -6.4328622817993164e-01
    z[1,0,3]  R381      6.0929656028747559e-02
    z[1,0,3]  R382      4.4564566016197205e-01
    z[1,0,3]  R383      -4.6845340728759766e-01
    z[1,0,3]  R384      0.217659592628479
    z[1,0,3]  R385      -2.1393077075481415e-01
    z[1,0,3]  R386      -2.3716230690479279e-01
    z[1,0,3]  R387      -3.2082572579383850e-01
    z[1,0,3]  R388      4.1865665465593338e-02
    z[1,0,3]  R389      -9.6946984529495239e-02
    z[1,0,3]  R390      8.9062482118606567e-02
    z[1,0,3]  R391      -3.2469424605369568e-01
    z[1,0,3]  R392      -3.8564404845237732e-01
    z[1,0,3]  R393      1.9415273563936353e-03
    z[1,0,3]  R394      -0.000567007577046752
    z[1,0,3]  R395      -0.308651328086853
    z[1,0,3]  R396      2.7416145801544189e-01
    z[1,0,3]  R397      -7.5802463293075562e-01
    z[1,0,3]  R398      -6.2473946809768677e-01
    z[1,0,3]  R399      -0.938624382019043
    z[1,0,3]  R400      -6.4770805835723877e-01
    z[1,0,3]  R401      5.8693759143352509e-02
    z[1,0,3]  R402      1.9043010473251343e-01
    z[1,0,3]  R403      2.8132423758506775e-01
    z[1,0,3]  R404      -7.3013061285018921e-01
    z[1,0,3]  R405      -7.1067994832992554e-01
    z[1,0,3]  R406      -7.9846704006195068e-01
    z[1,0,3]  R407      -0.622801661491394
    z[1,0,3]  R408      -4.3773502111434937e-01
    z[1,0,3]  R409      1.8729162216186523e-01
    z[1,0,3]  R410      -9.3009635806083679e-02
    z[1,0,4]  R6        1
    z[1,0,4]  R15       -1
    z[1,0,4]  R255      -1
    z[1,0,4]  R256      1
    z[1,0,4]  R261      -1.1247880756855011e-01
    z[1,0,4]  R262      2.2592009976506233e-02
    z[1,0,4]  R263      -0.00748852826654911
    z[1,0,4]  R264      3.2927727699279785e-01
    z[1,0,4]  R265      1.2413238175213337e-02
    z[1,0,4]  R266      0.106113001704216
    z[1,0,4]  R267      5.0413364171981812e-01
    z[1,0,4]  R268      4.1448852419853210e-01
    z[1,0,4]  R269      6.7392474412918091e-01
    z[1,0,4]  R270      9.4905763864517212e-02
    z[1,0,4]  R271      -3.9633101224899292e-01
    z[1,0,4]  R272      9.5441611483693123e-03
    z[1,0,4]  R273      1.9344888627529144e-01
    z[1,0,4]  R274      -5.0751698017120361e-01
    z[1,0,4]  R275      -4.6170118451118469e-01
    z[1,0,4]  R276      -2.2196891903877258e-01
    z[1,0,4]  R277      -3.5769772529602051e-01
    z[1,0,4]  R278      -3.0726441740989685e-01
    z[1,0,4]  R279      -4.0538829565048218e-01
    z[1,0,4]  R280      2.3168230056762695e-01
    z[1,0,4]  R281      -3.4652435779571533e-01
    z[1,0,4]  R282      -1.8786557018756866e-01
    z[1,0,4]  R283      -6.7668128013610840e-01
    z[1,0,4]  R284      -8.4895169734954834e-01
    z[1,0,4]  R285      -2.6113060116767883e-01
    z[1,0,4]  R286      1.1247245222330093e-01
    z[1,0,4]  R287      -1.2196033447980881e-01
    z[1,0,4]  R288      -5.4073190689086914e-01
    z[1,0,4]  R289      7.0605689287185669e-01
    z[1,0,4]  R290      9.4362515211105347e-01
    z[1,0,4]  R291      -2.0223446190357208e-01
    z[1,0,4]  R292      3.1554073095321655e-01
    z[1,0,4]  R293      3.3984726667404175e-01
    z[1,0,4]  R294      2.1140135824680328e-01
    z[1,0,4]  R295      -1.7125698924064636e-01
    z[1,0,4]  R296      -0.0864894762635231
    z[1,0,4]  R297      -1.9900390878319740e-02
    z[1,0,4]  R298      -2.2850982844829559e-01
    z[1,0,4]  R299      -2.0756879448890686e-01
    z[1,0,4]  R300      -1.8477097153663635e-01
    z[1,0,4]  R301      -6.6944587230682373e-01
    z[1,0,4]  R302      1.9878487288951874e-01
    z[1,0,4]  R303      2.5809904932975769e-01
    z[1,0,4]  R304      -1.8200004100799561e-01
    z[1,0,4]  R305      -1.8569459021091461e-01
    z[1,0,4]  R306      7.6844438910484314e-02
    z[1,0,4]  R307      6.8372821807861328e-01
    z[1,0,4]  R308      -5.6160074472427368e-01
    z[1,0,4]  R309      -4.6660301089286804e-01
    z[1,0,4]  R310      -3.5465580224990845e-01
    z[1,0,4]  R311      -1.1367820203304291e-01
    z[1,0,4]  R312      -1.2245580554008484e-01
    z[1,0,4]  R313      1.8623976409435272e-01
    z[1,0,4]  R314      -1.2363362312316895e-01
    z[1,0,4]  R315      -0.319595068693161
    z[1,0,4]  R316      -3.0021873116493225e-01
    z[1,0,4]  R317      -1.8565380573272705e-01
    z[1,0,4]  R318      -3.3730342984199524e-02
    z[1,0,4]  R319      -8.9219413697719574e-02
    z[1,0,4]  R320      5.2021449804306030e-01
    z[1,0,4]  R321      1.5052796900272369e-01
    z[1,0,4]  R322      -4.8418673872947693e-01
    z[1,0,4]  R323      -1.1262041516602039e-02
    z[1,0,4]  R324      4.5991101861000061e-01
    z[1,0,4]  R325      4.5816510915756226e-02
    z[1,0,4]  R326      -0.678889811038971
    z[1,0,4]  R327      -3.2943999767303467e-01
    z[1,0,4]  R328      -0.4470234811306
    z[1,0,4]  R329      -7.9936087131500244e-01
    z[1,0,4]  R330      -2.0046986639499664e-01
    z[1,0,4]  R331      -5.5702561140060425e-01
    z[1,0,4]  R332      -3.3359881490468979e-02
    z[1,0,4]  R333      -5.0087904930114746e-01
    z[1,0,4]  R334      7.2544181346893311e-01
    z[1,0,4]  R335      8.0137783288955688e-01
    z[1,0,4]  R336      3.9924103021621704e-01
    z[1,0,4]  R337      4.4599962234497070e-01
    z[1,0,4]  R338      5.6706315279006958e-01
    z[1,0,4]  R339      2.8938525915145874e-01
    z[1,0,4]  R340      2.6491126418113708e-01
    z[1,0,4]  R341      -3.9084357023239136e-01
    z[1,0,4]  R342      -2.1561355888843536e-01
    z[1,0,4]  R343      -6.1471585184335709e-02
    z[1,0,4]  R344      4.0813198685646057e-01
    z[1,0,4]  R345      1.0320943593978882e-01
    z[1,0,4]  R346      5.1756995916366577e-01
    z[1,0,4]  R347      0.363953173160553
    z[1,0,4]  R348      -2.6761695742607117e-01
    z[1,0,4]  R349      -7.7543191611766815e-02
    z[1,0,4]  R350      3.5110303759574890e-01
    z[1,0,4]  R351      -4.1218571364879608e-02
    z[1,0,4]  R352      0.352463036775589
    z[1,0,4]  R353      -2.4997876584529877e-01
    z[1,0,4]  R354      3.1200459599494934e-01
    z[1,0,4]  R355      -1.5997199714183807e-01
    z[1,0,4]  R356      -5.0467513501644135e-02
    z[1,0,4]  R357      3.9517077803611755e-01
    z[1,0,4]  R358      -3.3496016263961792e-01
    z[1,0,4]  R359      -2.5108709931373596e-01
    z[1,0,4]  R360      5.7777430862188339e-02
    z[1,0,4]  R361      -2.4556618183851242e-02
    z[1,0,4]  R362      -7.3936069384217262e-03
    z[1,0,4]  R363      1.3218869268894196e-01
    z[1,0,4]  R364      4.1001036763191223e-02
    z[1,0,4]  R365      2.5220713019371033e-01
    z[1,0,4]  R366      1.9193364679813385e-01
    z[1,0,4]  R367      -5.9747759252786636e-02
    z[1,0,4]  R368      -8.6109027266502380e-02
    z[1,0,4]  R369      1.3745196163654327e-01
    z[1,0,4]  R370      0.0350436307489872
    z[1,0,4]  R371      9.5477670431137085e-02
    z[1,0,4]  R372      -3.7079265713691711e-01
    z[1,0,4]  R373      -1.3064685463905334e-01
    z[1,0,4]  R374      3.2557407021522522e-01
    z[1,0,4]  R375      -1.3982348144054413e-01
    z[1,0,4]  R376      1.1141499131917953e-01
    z[1,0,4]  R377      -7.0524394512176514e-02
    z[1,0,4]  R378      8.8269263505935669e-02
    z[1,0,4]  R379      4.1587015986442566e-01
    z[1,0,4]  R380      4.0703928470611572e-01
    z[1,0,4]  R381      -2.1439389884471893e-01
    z[1,0,4]  R382      -2.3072990775108337e-01
    z[1,0,4]  R383      2.6333945989608765e-01
    z[1,0,4]  R384      2.4770571291446686e-01
    z[1,0,4]  R385      2.1385875344276428e-01
    z[1,0,4]  R386      6.0413964092731476e-02
    z[1,0,4]  R387      -2.5798571109771729e-01
    z[1,0,4]  R388      -1.1370173841714859e-01
    z[1,0,4]  R389      0.359660267829895
    z[1,0,4]  R390      5.8230042457580566e-02
    z[1,0,4]  R391      1.2516547739505768e-01
    z[1,0,4]  R392      -3.8943123072385788e-02
    z[1,0,4]  R393      -5.8395609259605408e-02
    z[1,0,4]  R394      0.284589558839798
    z[1,0,4]  R395      -3.4502550959587097e-01
    z[1,0,4]  R396      -6.8094119429588318e-02
    z[1,0,4]  R397      -7.7331632375717163e-02
    z[1,0,4]  R398      2.8215774893760681e-01
    z[1,0,4]  R399      1.0871417075395584e-01
    z[1,0,4]  R400      -1.9560030195862055e-03
    z[1,0,4]  R401      -1.1534772813320160e-01
    z[1,0,4]  R402      1.9251872599124908e-01
    z[1,0,4]  R403      0.0800652801990509
    z[1,0,4]  R404      1.9722582772374153e-02
    z[1,0,4]  R405      5.0033140927553177e-02
    z[1,0,4]  R406      -2.4309885501861572e-01
    z[1,0,4]  R407      9.8878055810928345e-02
    z[1,0,4]  R408      5.3946918249130249e-01
    z[1,0,4]  R409      1.6274869441986084e-01
    z[1,0,4]  R410      -4.7675538808107376e-03
    z[1,0,5]  R7        1
    z[1,0,5]  R16       -1
    z[1,0,5]  R257      -1
    z[1,0,5]  R258      1
    z[1,0,5]  R261      -5.9924560785293579e-01
    z[1,0,5]  R262      -6.7017114162445068e-01
    z[1,0,5]  R263      -1.7075255513191223e-01
    z[1,0,5]  R264      -3.4536325931549072e-01
    z[1,0,5]  R265      -4.1791123151779175e-01
    z[1,0,5]  R266      -1.6387729346752167e-01
    z[1,0,5]  R267      -2.5673899799585342e-02
    z[1,0,5]  R268      -2.7564057707786560e-01
    z[1,0,5]  R269      1.8572375178337097e-01
    z[1,0,5]  R270      -9.6274352073669434e-01
    z[1,0,5]  R271      2.6516011357307434e-01
    z[1,0,5]  R272      3.3366104960441589e-01
    z[1,0,5]  R273      7.6006367802619934e-02
    z[1,0,5]  R274      -2.2798164281994104e-03
    z[1,0,5]  R275      1.8446385860443115e-01
    z[1,0,5]  R276      4.1964945197105408e-01
    z[1,0,5]  R277      6.3277292251586914e-01
    z[1,0,5]  R278      6.8420600891113281e-01
    z[1,0,5]  R279      4.3545350432395935e-01
    z[1,0,5]  R280      0.063116155564785
    z[1,0,5]  R281      -1.3539710640907288e-01
    z[1,0,5]  R282      1.9015109539031982e-01
    z[1,0,5]  R283      -3.3738423138856888e-02
    z[1,0,5]  R284      -1.1009259521961212e-01
    z[1,0,5]  R285      -6.6776549816131592e-01
    z[1,0,5]  R286      -2.7803018689155579e-01
    z[1,0,5]  R287      -5.8783525228500366e-01
    z[1,0,5]  R288      3.4181165695190430e-01
    z[1,0,5]  R289      3.4685772657394409e-01
    z[1,0,5]  R290      -1.1427142471075058e-01
    z[1,0,5]  R291      -5.1246547698974609e-01
    z[1,0,5]  R292      -4.7744181752204895e-01
    z[1,0,5]  R293      -2.8765550255775452e-01
    z[1,0,5]  R294      7.3895724490284920e-03
    z[1,0,5]  R295      6.5908366441726685e-01
    z[1,0,5]  R296      2.7482289075851440e-01
    z[1,0,5]  R297      3.5857841372489929e-01
    z[1,0,5]  R298      2.5697714090347290e-01
    z[1,0,5]  R299      6.2740236520767212e-01
    z[1,0,5]  R300      5.1673984527587891e-01
    z[1,0,5]  R301      -5.4225660860538483e-02
    z[1,0,5]  R302      6.7273318767547607e-01
    z[1,0,5]  R303      -1.2929636240005493e-01
    z[1,0,5]  R304      1.8573950231075287e-01
    z[1,0,5]  R305      2.3989351093769073e-01
    z[1,0,5]  R306      2.4207981303334236e-02
    z[1,0,5]  R307      6.8009041249752045e-02
    z[1,0,5]  R308      0.700463056564331
    z[1,0,5]  R309      3.8692724704742432e-01
    z[1,0,5]  R310      3.0215749144554138e-01
    z[1,0,5]  R311      -5.6540167331695557e-01
    z[1,0,5]  R312      2.5111094117164612e-01
    z[1,0,5]  R313      1.6509608924388885e-01
    z[1,0,5]  R314      3.1623688340187073e-01
    z[1,0,5]  R315      5.9986698627471924e-01
    z[1,0,5]  R316      6.2607699632644653e-01
    z[1,0,5]  R317      1.8678721785545349e-01
    z[1,0,5]  R318      1.6764141619205475e-01
    z[1,0,5]  R319      2.6683539152145386e-01
    z[1,0,5]  R320      5.9409722685813904e-02
    z[1,0,5]  R321      -6.5568573772907257e-02
    z[1,0,5]  R322      1.6529381275177002e-01
    z[1,0,5]  R323      -6.3907362520694733e-02
    z[1,0,5]  R324      -0.189733624458313
    z[1,0,5]  R325      1.4546598494052887e-01
    z[1,0,5]  R326      -2.4480000138282776e-01
    z[1,0,5]  R327      2.4261584877967834e-01
    z[1,0,5]  R328      5.1766520738601685e-01
    z[1,0,5]  R329      -2.2911494597792625e-02
    z[1,0,5]  R330      -1.3159135123714805e-03
    z[1,0,5]  R331      -4.8959231376647949e-01
    z[1,0,5]  R332      1.2369251251220703e-01
    z[1,0,5]  R333      1.8714118003845215e-01
    z[1,0,5]  R334      0.262578547000885
    z[1,0,5]  R335      -8.0211512744426727e-02
    z[1,0,5]  R336      -3.1390699744224548e-01
    z[1,0,5]  R337      -5.3827010095119476e-02
    z[1,0,5]  R338      2.3970412090420723e-02
    z[1,0,5]  R339      7.8765578567981720e-02
    z[1,0,5]  R340      -3.7683773040771484e-01
    z[1,0,5]  R341      -0.0905112773180008
    z[1,0,5]  R342      -6.7866414785385132e-01
    z[1,0,5]  R343      -1.1712118051946163e-02
    z[1,0,5]  R344      6.3943368196487427e-01
    z[1,0,5]  R345      -1.3582212850451469e-02
    z[1,0,5]  R346      2.7645006775856018e-01
    z[1,0,5]  R347      -1.7054859548807144e-02
    z[1,0,5]  R348      2.4767701327800751e-01
    z[1,0,5]  R349      7.2591237723827362e-02
    z[1,0,5]  R350      9.5383025705814362e-02
    z[1,0,5]  R351      1.9684407114982605e-01
    z[1,0,5]  R352      2.1400873363018036e-01
    z[1,0,5]  R353      1.7545576393604279e-01
    z[1,0,5]  R354      -8.3863191306591034e-02
    z[1,0,5]  R355      3.5342969000339508e-02
    z[1,0,5]  R356      -2.2698865830898285e-01
    z[1,0,5]  R357      3.7799999117851257e-01
    z[1,0,5]  R358      -7.9122260212898254e-03
    z[1,0,5]  R359      2.4082399904727936e-01
    z[1,0,5]  R360      1.1017414927482605e-01
    z[1,0,5]  R361      3.6226198077201843e-01
    z[1,0,5]  R362      3.0144955962896347e-02
    z[1,0,5]  R363      1.4294551312923431e-01
    z[1,0,5]  R364      1.7544165253639221e-01
    z[1,0,5]  R365      2.3372095823287964e-01
    z[1,0,5]  R366      4.1231876611709595e-01
    z[1,0,5]  R367      3.9987576007843018e-01
    z[1,0,5]  R368      4.1314443945884705e-01
    z[1,0,5]  R369      3.3306348323822021e-01
    z[1,0,5]  R370      1.6043521463871002e-01
    z[1,0,5]  R371      -5.6281950324773788e-02
    z[1,0,5]  R372      -3.6464065313339233e-01
    z[1,0,5]  R373      -3.4621521830558777e-01
    z[1,0,5]  R374      -4.0698921680450439e-01
    z[1,0,5]  R375      -4.0686112642288208e-01
    z[1,0,5]  R376      -2.8368967771530151e-01
    z[1,0,5]  R377      -1.4950375258922577e-01
    z[1,0,5]  R378      -2.9358950257301331e-01
    z[1,0,5]  R379      9.5859030261635780e-03
    z[1,0,5]  R380      -3.9522635936737061e-01
    z[1,0,5]  R381      -1.6145195066928864e-01
    z[1,0,5]  R382      -1.9120676815509796e-01
    z[1,0,5]  R383      -1.1766610294580460e-01
    z[1,0,5]  R384      -2.3118594661355019e-02
    z[1,0,5]  R385      -8.8029861450195312e-02
    z[1,0,5]  R386      -1.0294277220964432e-01
    z[1,0,5]  R387      -3.1823366880416870e-01
    z[1,0,5]  R388      -2.9804265499114990e-01
    z[1,0,5]  R389      -3.8015264272689819e-01
    z[1,0,5]  R390      -5.3212952613830566e-01
    z[1,0,5]  R391      -1.7609718441963196e-01
    z[1,0,5]  R392      -2.2707961499691010e-01
    z[1,0,5]  R393      -2.2068646550178528e-01
    z[1,0,5]  R394      -3.7052431702613831e-01
    z[1,0,5]  R395      1.1809995397925377e-02
    z[1,0,5]  R396      -1.8104976415634155e-01
    z[1,0,5]  R397      1.3202938437461853e-01
    z[1,0,5]  R398      -9.1548189520835876e-03
    z[1,0,5]  R399      -8.9364543557167053e-02
    z[1,0,5]  R400      4.1444590687751770e-01
    z[1,0,5]  R401      7.5835309922695160e-02
    z[1,0,5]  R402      7.5173109769821167e-02
    z[1,0,5]  R403      -1.4381489157676697e-01
    z[1,0,5]  R404      -2.3718622326850891e-01
    z[1,0,5]  R405      -3.9254122972488403e-01
    z[1,0,5]  R406      -6.2953993678092957e-02
    z[1,0,5]  R407      -5.6849384307861328e-01
    z[1,0,5]  R408      3.0457329750061035e-01
    z[1,0,5]  R409      4.8995118588209152e-02
    z[1,0,5]  R410      2.5946235656738281e-01
    z[1,0,6]  R8        1
    z[1,0,6]  R17       -1
    z[1,0,6]  R259      -1
    z[1,0,6]  R260      1
    z[1,0,6]  R261      5.4936385154724121e-01
    z[1,0,6]  R262      -2.6172572374343872e-01
    z[1,0,6]  R263      -0.285825252532959
    z[1,0,6]  R264      -3.6537206172943115e-01
    z[1,0,6]  R265      -3.1697034835815430e-01
    z[1,0,6]  R266      3.1209623813629150e-01
    z[1,0,6]  R267      -1.7608475685119629e-01
    z[1,0,6]  R268      -1.7964359372854233e-02
    z[1,0,6]  R269      1.8934594467282295e-02
    z[1,0,6]  R270      7.0240586996078491e-02
    z[1,0,6]  R271      -4.1481410153210163e-03
    z[1,0,6]  R272      9.4167903065681458e-02
    z[1,0,6]  R273      -5.0156249199062586e-04
    z[1,0,6]  R274      -4.9856850504875183e-01
    z[1,0,6]  R275      9.0561136603355408e-02
    z[1,0,6]  R276      5.0405509769916534e-02
    z[1,0,6]  R277      -1.9536618143320084e-02
    z[1,0,6]  R278      -4.4646725058555603e-01
    z[1,0,6]  R279      -1.3794755935668945e-01
    z[1,0,6]  R280      -8.6756169795989990e-02
    z[1,0,6]  R281      2.6139521598815918e-01
    z[1,0,6]  R282      1.7950955033302307e-01
    z[1,0,6]  R283      -1.4895421266555786e-01
    z[1,0,6]  R284      1.0262466222047806e-01
    z[1,0,6]  R285      2.6971647143363953e-01
    z[1,0,6]  R286      5.8602774143218994e-01
    z[1,0,6]  R287      -0.0789579525589943
    z[1,0,6]  R288      -9.7000725567340851e-02
    z[1,0,6]  R289      4.7660249471664429e-01
    z[1,0,6]  R290      -5.0564175471663475e-03
    z[1,0,6]  R291      -1.0765118151903152e-01
    z[1,0,6]  R292      -2.3900514468550682e-02
    z[1,0,6]  R293      -4.3533239513635635e-02
    z[1,0,6]  R294      -1.5683084726333618e-01
    z[1,0,6]  R295      1.6710405051708221e-01
    z[1,0,6]  R296      0.559935986995697
    z[1,0,6]  R297      7.9860344529151917e-02
    z[1,0,6]  R298      -5.3181725740432739e-01
    z[1,0,6]  R299      2.6263775303959846e-02
    z[1,0,6]  R300      -8.4048651158809662e-02
    z[1,0,6]  R301      -3.4072157740592957e-01
    z[1,0,6]  R302      2.9886773228645325e-01
    z[1,0,6]  R303      1.3904240727424622e-01
    z[1,0,6]  R304      -7.8896619379520416e-02
    z[1,0,6]  R305      0.7186239361763
    z[1,0,6]  R306      -2.8426237404346466e-02
    z[1,0,6]  R307      -5.2897542715072632e-01
    z[1,0,6]  R308      2.2473634779453278e-01
    z[1,0,6]  R309      0.502406656742096
    z[1,0,6]  R310      2.8155499696731567e-01
    z[1,0,6]  R311      2.4540470913052559e-02
    z[1,0,6]  R312      4.8982140421867371e-01
    z[1,0,6]  R313      -3.2377848029136658e-01
    z[1,0,6]  R314      2.6192527264356613e-02
    z[1,0,6]  R315      -4.1526150703430176e-01
    z[1,0,6]  R316      -3.7852057814598083e-01
    z[1,0,6]  R317      -1.5117228031158447e-01
    z[1,0,6]  R318      2.6974314451217651e-01
    z[1,0,6]  R319      2.4181246757507324e-01
    z[1,0,6]  R320      -3.5141488909721375e-01
    z[1,0,6]  R321      -1.6979727149009705e-01
    z[1,0,6]  R322      1.0500414669513702e-01
    z[1,0,6]  R323      2.7354088425636292e-01
    z[1,0,6]  R324      5.2951216697692871e-01
    z[1,0,6]  R325      5.1548373699188232e-01
    z[1,0,6]  R326      2.6870566606521606e-01
    z[1,0,6]  R327      -2.3152175545692444e-01
    z[1,0,6]  R328      2.5246503949165344e-01
    z[1,0,6]  R329      -6.2848613597452641e-03
    z[1,0,6]  R330      -1.0438323020935059e-02
    z[1,0,6]  R331      -1.5473565459251404e-01
    z[1,0,6]  R332      -1.5618702769279480e-01
    z[1,0,6]  R333      1.9208897650241852e-01
    z[1,0,6]  R334      -0.0856553316116333
    z[1,0,6]  R335      4.8573899269104004e-01
    z[1,0,6]  R336      2.2684057056903839e-01
    z[1,0,6]  R337      1.2641890347003937e-01
    z[1,0,6]  R338      -3.3749712165445089e-03
    z[1,0,6]  R339      -1.2154351174831390e-01
    z[1,0,6]  R340      0.180814728140831
    z[1,0,6]  R341      3.6732730269432068e-01
    z[1,0,6]  R342      2.5281503796577454e-01
    z[1,0,6]  R343      -2.0104783773422241e-01
    z[1,0,6]  R344      -2.5840455293655396e-01
    z[1,0,6]  R345      -2.1076993644237518e-01
    z[1,0,6]  R346      2.3696507513523102e-01
    z[1,0,6]  R347      -1.7199589312076569e-01
    z[1,0,6]  R348      -2.7896878123283386e-01
    z[1,0,6]  R349      1.9066981971263885e-01
    z[1,0,6]  R350      1.8433047458529472e-02
    z[1,0,6]  R351      -2.3867608606815338e-01
    z[1,0,6]  R352      -2.8994879126548767e-01
    z[1,0,6]  R353      2.2076773643493652e-01
    z[1,0,6]  R354      -3.2592701911926270e-01
    z[1,0,6]  R355      -3.1702980399131775e-02
    z[1,0,6]  R356      1.8523052334785461e-01
    z[1,0,6]  R357      1.6725838184356689e-01
    z[1,0,6]  R358      8.6627446115016937e-02
    z[1,0,6]  R359      2.2655488550662994e-01
    z[1,0,6]  R360      2.8011319041252136e-01
    z[1,0,6]  R361      0.245841383934021
    z[1,0,6]  R362      0.097848080098629
    z[1,0,6]  R363      -1.8725836277008057e-01
    z[1,0,6]  R364      -2.1693013608455658e-02
    z[1,0,6]  R365      3.1365182995796204e-01
    z[1,0,6]  R366      1.1375698447227478e-01
    z[1,0,6]  R367      9.7162231802940369e-02
    z[1,0,6]  R368      -1.0808359831571579e-01
    z[1,0,6]  R369      -6.4100623130798340e-02
    z[1,0,6]  R370      1.3626888394355774e-01
    z[1,0,6]  R371      -1.7072747647762299e-01
    z[1,0,6]  R372      -3.0899396166205406e-02
    z[1,0,6]  R373      -4.1400483250617981e-01
    z[1,0,6]  R374      -8.5938654839992523e-02
    z[1,0,6]  R375      -1.3139389455318451e-01
    z[1,0,6]  R376      -1.9289404153823853e-01
    z[1,0,6]  R377      2.1805499494075775e-01
    z[1,0,6]  R378      -3.6004860885441303e-03
    z[1,0,6]  R379      -1.7021040618419647e-01
    z[1,0,6]  R380      -8.1121474504470825e-03
    z[1,0,6]  R381      -8.0257803201675415e-02
    z[1,0,6]  R382      0.00755949504673481
    z[1,0,6]  R383      -9.6115969121456146e-02
    z[1,0,6]  R384      -9.2945620417594910e-02
    z[1,0,6]  R385      2.6474019885063171e-01
    z[1,0,6]  R386      -4.0284439921379089e-01
    z[1,0,6]  R387      6.5613955259323120e-02
    z[1,0,6]  R388      4.5896759629249573e-01
    z[1,0,6]  R389      -1.4630749821662903e-01
    z[1,0,6]  R390      -2.8226310014724731e-01
    z[1,0,6]  R391      -0.154501274228096
    z[1,0,6]  R392      2.2523556649684906e-01
    z[1,0,6]  R393      3.8888379931449890e-01
    z[1,0,6]  R394      -3.0032485723495483e-01
    z[1,0,6]  R395      3.7741836905479431e-01
    z[1,0,6]  R396      -3.9454710483551025e-01
    z[1,0,6]  R397      1.6951330006122589e-01
    z[1,0,6]  R398      -1.9711382687091827e-01
    z[1,0,6]  R399      -3.0246462672948837e-02
    z[1,0,6]  R400      -1.7947243154048920e-01
    z[1,0,6]  R401      -2.1330793201923370e-01
    z[1,0,6]  R402      -2.7563467621803284e-01
    z[1,0,6]  R403      -3.2324469089508057e-01
    z[1,0,6]  R404      6.4031504094600677e-02
    z[1,0,6]  R405      -1.0182687640190125e-01
    z[1,0,6]  R406      -8.6366616189479828e-02
    z[1,0,6]  R407      2.0609053969383240e-01
    z[1,0,6]  R408      7.7185044065117836e-03
    z[1,0,6]  R409      3.2198838889598846e-02
    z[1,0,6]  R410      0.0327945351600647
    z[0,6,0]  R2        -1
    z[0,6,0]  R56       1
    z[0,6,0]  R411      -1
    z[0,6,0]  R412      1
    z[0,6,0]  R425      3.1617248058319092e-01
    z[0,6,0]  R426      5.7669192552566528e-01
    z[0,6,0]  R427      4.7605317831039429e-01
    z[0,6,0]  R428      4.6785807609558105e-01
    z[0,6,0]  R429      8.7497037649154663e-01
    z[0,6,0]  R430      7.1143907308578491e-01
    z[0,6,0]  R431      6.8296575546264648e-01
    z[0,6,0]  R432      8.1498926877975464e-01
    z[0,6,0]  R433      0.185358464717865
    z[0,6,0]  R434      4.7616714239120483e-01
    z[0,6,0]  R435      -4.9223318696022034e-01
    z[0,6,0]  R436      -5.4711413383483887e-01
    z[0,6,0]  R437      -2.4950566887855530e-01
    z[0,6,0]  R438      -4.1189306974411011e-01
    z[0,6,0]  R439      -3.0863013863563538e-01
    z[0,6,0]  R440      -4.8976475000381470e-01
    z[0,6,0]  R441      -1.5400357544422150e-01
    z[0,6,0]  R442      -4.3866270780563354e-01
    z[0,6,0]  R443      -4.7704404592514038e-01
    z[0,6,0]  R444      -2.4821718037128448e-01
    z[0,6,0]  R445      1.1715054512023926e-01
    z[0,6,0]  R446      -7.2085000574588776e-02
    z[0,6,0]  R447      -7.1591906249523163e-02
    z[0,6,0]  R448      2.9847750067710876e-01
    z[0,6,0]  R449      -4.2866292595863342e-01
    z[0,6,0]  R450      -0.407634973526001
    z[0,6,0]  R451      -3.9184358716011047e-01
    z[0,6,0]  R452      -5.7812762260437012e-01
    z[0,6,0]  R453      2.7833279222249985e-02
    z[0,6,0]  R454      -2.9819878935813904e-01
    z[0,6,0]  R455      6.3001766800880432e-02
    z[0,6,0]  R456      0.0899825319647789
    z[0,6,0]  R457      2.5428640842437744e-01
    z[0,6,0]  R458      3.2596611976623535e-01
    z[0,6,0]  R459      3.4396609663963318e-01
    z[0,6,0]  R460      -2.6913258433341980e-01
    z[0,6,0]  R461      -2.6759406924247742e-01
    z[0,6,0]  R462      3.4607195854187012e-01
    z[0,6,0]  R463      4.3527016043663025e-01
    z[0,6,0]  R464      -1.2859259545803070e-01
    z[0,6,0]  R465      9.0489076683297753e-04
    z[0,6,0]  R466      1.2812386453151703e-01
    z[0,6,0]  R467      2.0964090526103973e-01
    z[0,6,0]  R468      3.1280410289764404e-01
    z[0,6,0]  R469      1.2833017110824585e-01
    z[0,6,0]  R470      -0.756442666053772
    z[0,6,0]  R471      -3.5724371671676636e-01
    z[0,6,0]  R472      -3.8763898611068726e-01
    z[0,6,0]  R473      -2.8695088624954224e-01
    z[0,6,0]  R474      -5.0645190477371216e-01
    z[0,6,0]  R475      -6.2723271548748016e-02
    z[0,6,0]  R476      1.7746257781982422e-01
    z[0,6,0]  R477      -7.8412890434265137e-01
    z[0,6,0]  R478      -3.7134975194931030e-01
    z[0,6,0]  R479      -4.2428565025329590e-01
    z[0,6,0]  R480      -3.3557087182998657e-01
    z[0,6,0]  R481      -1.0943162441253662e-01
    z[0,6,0]  R482      -4.9729606509208679e-01
    z[0,6,0]  R483      -8.1524938344955444e-01
    z[0,6,0]  R484      -7.9225832223892212e-01
    z[0,6,0]  R485      4.4110476970672607e-01
    z[0,6,0]  R486      3.3901163935661316e-01
    z[0,6,0]  R487      5.2272677421569824e-01
    z[0,6,0]  R488      6.3964354991912842e-01
    z[0,6,0]  R489      1.7448575794696808e-01
    z[0,6,0]  R490      3.4932801127433777e-01
    z[0,6,0]  R491      4.8197889328002930e-01
    z[0,6,0]  R492      3.0211597681045532e-01
    z[0,6,0]  R493      -2.7162078768014908e-02
    z[0,6,0]  R494      6.8654817342758179e-01
    z[0,6,0]  R495      -6.1936073005199432e-02
    z[0,6,0]  R496      -1.7271035909652710e-01
    z[0,6,0]  R497      -4.2474997043609619e-01
    z[0,6,0]  R498      -1.7868795990943909e-01
    z[0,6,0]  R499      -1.7778226733207703e-01
    z[0,6,0]  R500      -3.4068015217781067e-01
    z[0,6,0]  R501      -1.1456552892923355e-01
    z[0,6,0]  R502      -1.4042910933494568e-01
    z[0,6,0]  R503      -3.1393563747406006e-01
    z[0,6,0]  R504      -7.5816917419433594e-01
    z[0,6,0]  R505      -0.279852956533432
    z[0,6,0]  R506      -9.2264115810394287e-02
    z[0,6,0]  R507      8.9268334209918976e-02
    z[0,6,0]  R508      -4.4528219103813171e-01
    z[0,6,0]  R509      -2.0623424649238586e-01
    z[0,6,0]  R510      -5.1273441314697266e-01
    z[0,6,0]  R511      5.5959355831146240e-01
    z[0,6,0]  R512      -6.4229393005371094e-01
    z[0,6,0]  R513      4.3120759725570679e-01
    z[0,6,0]  R514      -5.2551096677780151e-01
    z[0,6,0]  R515      4.0983331203460693e-01
    z[0,6,0]  R516      2.7934926748275757e-01
    z[0,6,0]  R517      -6.5420351922512054e-02
    z[0,6,0]  R518      -2.1329589188098907e-02
    z[0,6,0]  R519      8.3455525338649750e-02
    z[0,6,0]  R520      -2.1819558739662170e-01
    z[0,6,0]  R521      -1.3673183321952820e-01
    z[0,6,0]  R522      1.0967677831649780e-01
    z[0,6,0]  R523      3.1910541653633118e-01
    z[0,6,0]  R524      5.0385850667953491e-01
    z[0,6,0]  R525      1.7317111790180206e-01
    z[0,6,0]  R526      -1.8343149125576019e-01
    z[0,6,0]  R527      -2.9323059320449829e-01
    z[0,6,0]  R528      -4.5411375164985657e-01
    z[0,6,0]  R529      -1.2677389383316040e-01
    z[0,6,0]  R530      -5.2489918470382690e-01
    z[0,6,0]  R531      -8.7438768148422241e-01
    z[0,6,0]  R532      -7.0522385835647583e-01
    z[0,6,0]  R533      -8.1494313478469849e-01
    z[0,6,0]  R534      -2.6639264822006226e-01
    z[0,6,0]  R535      -1.7448942363262177e-01
    z[0,6,0]  R536      4.9027130007743835e-01
    z[0,6,0]  R537      1.6009068489074707e-01
    z[0,6,0]  R538      2.4896232783794403e-01
    z[0,6,0]  R539      -7.0342606306076050e-01
    z[0,6,0]  R540      -4.4413122534751892e-01
    z[0,6,0]  R541      -3.1985759735107422e-01
    z[0,6,0]  R542      -5.9791624546051025e-01
    z[0,6,0]  R543      -5.5491024255752563e-01
    z[0,6,0]  R544      -5.0269585847854614e-01
    z[0,6,0]  R545      1.9270670600235462e-03
    z[0,6,0]  R546      1.5989714860916138e-01
    z[0,6,0]  R547      -1.4859504997730255e-01
    z[0,6,0]  R548      -2.9126900434494019e-01
    z[0,6,0]  R549      -1.5396639704704285e-01
    z[0,6,0]  R550      -6.7126137018203735e-01
    z[0,6,0]  R551      -0.634260892868042
    z[0,6,0]  R552      -6.2756544351577759e-01
    z[0,6,0]  R553      -8.7570679187774658e-01
    z[0,6,0]  R554      -3.9466273784637451e-01
    z[0,6,1]  R3        -1
    z[0,6,1]  R57       1
    z[0,6,1]  R413      -1
    z[0,6,1]  R414      1
    z[0,6,1]  R425      -2.2488594055175781e-01
    z[0,6,1]  R426      -1.2939150631427765e-01
    z[0,6,1]  R427      -2.1679200232028961e-01
    z[0,6,1]  R428      -4.0721505880355835e-01
    z[0,6,1]  R429      -1.8201905488967896e-01
    z[0,6,1]  R430      -3.6664776504039764e-02
    z[0,6,1]  R431      -3.5846021771430969e-01
    z[0,6,1]  R432      -2.6038247346878052e-01
    z[0,6,1]  R433      -6.8155348300933838e-01
    z[0,6,1]  R434      -2.8164952993392944e-01
    z[0,6,1]  R435      6.2968921661376953e-01
    z[0,6,1]  R436      6.2375122308731079e-01
    z[0,6,1]  R437      6.4590960741043091e-01
    z[0,6,1]  R438      8.7937724590301514e-01
    z[0,6,1]  R439      7.2811561822891235e-01
    z[0,6,1]  R440      4.4551664590835571e-01
    z[0,6,1]  R441      7.0651078224182129e-01
    z[0,6,1]  R442      6.0509574413299561e-01
    z[0,6,1]  R443      4.0943464636802673e-01
    z[0,6,1]  R444      0.868427574634552
    z[0,6,1]  R445      7.7697628736495972e-01
    z[0,6,1]  R446      8.2676619291305542e-01
    z[0,6,1]  R447      7.4282425642013550e-01
    z[0,6,1]  R448      5.9907871484756470e-01
    z[0,6,1]  R449      3.6086297035217285e-01
    z[0,6,1]  R450      -5.0757569074630737e-01
    z[0,6,1]  R451      1.7272317409515381e-01
    z[0,6,1]  R452      -3.2708102464675903e-01
    z[0,6,1]  R453      4.5395290851593018e-01
    z[0,6,1]  R454      -2.8362569212913513e-01
    z[0,6,1]  R455      9.4584661722183228e-01
    z[0,6,1]  R456      8.3826774358749390e-01
    z[0,6,1]  R457      7.8720378875732422e-01
    z[0,6,1]  R458      8.5944074392318726e-01
    z[0,6,1]  R459      7.4405682086944580e-01
    z[0,6,1]  R460      8.2526820898056030e-01
    z[0,6,1]  R461      7.6957190036773682e-01
    z[0,6,1]  R462      0.693574070930481
    z[0,6,1]  R463      7.0397454500198364e-01
    z[0,6,1]  R464      7.1981674432754517e-01
    z[0,6,1]  R465      8.8600194454193115e-01
    z[0,6,1]  R466      8.1919866800308228e-01
    z[0,6,1]  R467      7.5020068883895874e-01
    z[0,6,1]  R468      7.7050465345382690e-01
    z[0,6,1]  R469      7.8837692737579346e-01
    z[0,6,1]  R470      3.5375913977622986e-01
    z[0,6,1]  R471      3.5882890224456787e-01
    z[0,6,1]  R472      2.7233263850212097e-01
    z[0,6,1]  R473      -6.9074638187885284e-02
    z[0,6,1]  R474      3.1501409411430359e-01
    z[0,6,1]  R475      9.6092832088470459e-01
    z[0,6,1]  R476      9.0106505155563354e-01
    z[0,6,1]  R477      3.6725702881813049e-01
    z[0,6,1]  R478      -4.7007972002029419e-01
    z[0,6,1]  R479      -2.9570633172988892e-01
    z[0,6,1]  R480      3.7011715769767761e-01
    z[0,6,1]  R481      -5.1091857254505157e-02
    z[0,6,1]  R482      -3.9350786805152893e-01
    z[0,6,1]  R483      -0.486627459526062
    z[0,6,1]  R484      -5.2580362558364868e-01
    z[0,6,1]  R485      -3.4781205654144287e-01
    z[0,6,1]  R486      -4.5336815714836121e-01
    z[0,6,1]  R487      -1.6562427580356598e-01
    z[0,6,1]  R488      -2.9412621259689331e-01
    z[0,6,1]  R489      -7.4184560775756836e-01
    z[0,6,1]  R490      -5.8842420578002930e-01
    z[0,6,1]  R491      -4.4590777158737183e-01
    z[0,6,1]  R492      -3.2684186100959778e-01
    z[0,6,1]  R493      8.6725711822509766e-01
    z[0,6,1]  R494      -1.7752040922641754e-01
    z[0,6,1]  R495      6.0188430547714233e-01
    z[0,6,1]  R496      4.9670571088790894e-01
    z[0,6,1]  R497      5.2763450145721436e-01
    z[0,6,1]  R498      0.529279887676239
    z[0,6,1]  R499      5.2224355936050415e-01
    z[0,6,1]  R500      4.6737614274024963e-01
    z[0,6,1]  R501      4.6169325709342957e-01
    z[0,6,1]  R502      5.2379059791564941e-01
    z[0,6,1]  R503      1.6510948538780212e-01
    z[0,6,1]  R504      1.5629744529724121e-01
    z[0,6,1]  R505      0.700522780418396
    z[0,6,1]  R506      7.7344727516174316e-01
    z[0,6,1]  R507      6.8620622158050537e-01
    z[0,6,1]  R508      5.1303267478942871e-01
    z[0,6,1]  R509      5.3101956844329834e-01
    z[0,6,1]  R510      1.9648061692714691e-01
    z[0,6,1]  R511      4.9735376238822937e-01
    z[0,6,1]  R512      4.2687851190567017e-01
    z[0,6,1]  R513      5.7654422521591187e-01
    z[0,6,1]  R514      0.585563063621521
    z[0,6,1]  R515      7.2807049751281738e-01
    z[0,6,1]  R516      7.2795051336288452e-01
    z[0,6,1]  R517      7.9143977165222168e-01
    z[0,6,1]  R518      5.9142118692398071e-01
    z[0,6,1]  R519      8.2396847009658813e-01
    z[0,6,1]  R520      7.5865799188613892e-01
    z[0,6,1]  R521      6.1866432428359985e-01
    z[0,6,1]  R522      6.2044388055801392e-01
    z[0,6,1]  R523      6.3771826028823853e-01
    z[0,6,1]  R524      6.7984002828598022e-01
    z[0,6,1]  R525      6.6794329881668091e-01
    z[0,6,1]  R526      7.1713459491729736e-01
    z[0,6,1]  R527      6.1718851327896118e-01
    z[0,6,1]  R528      5.7492977380752563e-01
    z[0,6,1]  R529      5.3688865900039673e-01
    z[0,6,1]  R530      1.6145062446594238e-01
    z[0,6,1]  R531      3.0128052830696106e-01
    z[0,6,1]  R532      2.2331005334854126e-01
    z[0,6,1]  R533      2.2012549638748169e-01
    z[0,6,1]  R534      -4.5834100246429443e-01
    z[0,6,1]  R535      6.2749165296554565e-01
    z[0,6,1]  R536      7.1932464838027954e-01
    z[0,6,1]  R537      6.8802893161773682e-01
    z[0,6,1]  R538      4.7478458285331726e-01
    z[0,6,1]  R539      3.2687309384346008e-01
    z[0,6,1]  R540      1.3411889970302582e-01
    z[0,6,1]  R541      1.7444875836372375e-01
    z[0,6,1]  R542      -0.523600161075592
    z[0,6,1]  R543      -2.7035170793533325e-01
    z[0,6,1]  R544      -4.4116139411926270e-01
    z[0,6,1]  R545      8.4566336870193481e-01
    z[0,6,1]  R546      7.2292298078536987e-01
    z[0,6,1]  R547      7.2194844484329224e-01
    z[0,6,1]  R548      5.5753582715988159e-01
    z[0,6,1]  R549      4.7758224606513977e-01
    z[0,6,1]  R550      4.0005820989608765e-01
    z[0,6,1]  R551      3.1105974316596985e-01
    z[0,6,1]  R552      3.3201286196708679e-01
    z[0,6,1]  R553      2.6688948273658752e-01
    z[0,6,1]  R554      2.1507333219051361e-01
    z[0,6,2]  R4        -1
    z[0,6,2]  R58       1
    z[0,6,2]  R415      -1
    z[0,6,2]  R416      1
    z[0,6,2]  R425      6.9641411304473877e-01
    z[0,6,2]  R426      6.1756026744842529e-01
    z[0,6,2]  R427      0.746904730796814
    z[0,6,2]  R428      4.7763559222221375e-01
    z[0,6,2]  R429      3.4936192631721497e-01
    z[0,6,2]  R430      5.7652479410171509e-01
    z[0,6,2]  R431      2.7917012572288513e-01
    z[0,6,2]  R432      7.9882211983203888e-02
    z[0,6,2]  R433      4.9595010280609131e-01
    z[0,6,2]  R434      -3.1767857726663351e-03
    z[0,6,2]  R435      -3.7552466988563538e-01
    z[0,6,2]  R436      -5.4819935560226440e-01
    z[0,6,2]  R437      -5.2614951133728027e-01
    z[0,6,2]  R438      -1.4535656571388245e-01
    z[0,6,2]  R439      -3.7699118256568909e-01
    z[0,6,2]  R440      -5.6106412410736084e-01
    z[0,6,2]  R441      -4.4130784273147583e-01
    z[0,6,2]  R442      -4.3506258726119995e-01
    z[0,6,2]  R443      -5.6248861551284790e-01
    z[0,6,2]  R444      -3.6139541864395142e-01
    z[0,6,2]  R445      1.6493658721446991e-01
    z[0,6,2]  R446      1.7390790581703186e-01
    z[0,6,2]  R447      3.4230497479438782e-01
    z[0,6,2]  R448      -1.2580266594886780e-01
    z[0,6,2]  R449      -1.4868043363094330e-01
    z[0,6,2]  R450      -1.2460289150476456e-01
    z[0,6,2]  R451      -0.503728985786438
    z[0,6,2]  R452      8.4312453866004944e-02
    z[0,6,2]  R453      -2.4389077723026276e-01
    z[0,6,2]  R454      -3.0800363421440125e-01
    z[0,6,2]  R455      1.3863548636436462e-01
    z[0,6,2]  R456      -2.7512248605489731e-02
    z[0,6,2]  R457      -6.1390563845634460e-02
    z[0,6,2]  R458      -1.9287452101707458e-01
    z[0,6,2]  R459      -3.9840704202651978e-01
    z[0,6,2]  R460      -1.1714725941419601e-01
    z[0,6,2]  R461      -2.4716173112392426e-01
    z[0,6,2]  R462      -2.9159530997276306e-01
    z[0,6,2]  R463      -1.0140753537416458e-01
    z[0,6,2]  R464      -3.0194488167762756e-01
    z[0,6,2]  R465      -1.9755041599273682e-01
    z[0,6,2]  R466      -2.4487484991550446e-01
    z[0,6,2]  R467      -0.43577840924263
    z[0,6,2]  R468      -1.1846154229715466e-03
    z[0,6,2]  R469      7.1419939398765564e-02
    z[0,6,2]  R470      -1.8547539412975311e-01
    z[0,6,2]  R471      -3.4186357259750366e-01
    z[0,6,2]  R472      -5.1645022630691528e-01
    z[0,6,2]  R473      -1.0560575872659683e-01
    z[0,6,2]  R474      -1.4410842955112457e-01
    z[0,6,2]  R475      6.8419404327869415e-02
    z[0,6,2]  R476      -4.0451448410749435e-02
    z[0,6,2]  R477      -1.9884806871414185e-01
    z[0,6,2]  R478      -2.1745659410953522e-01
    z[0,6,2]  R479      -2.4599377810955048e-01
    z[0,6,2]  R480      2.0575824379920959e-01
    z[0,6,2]  R481      -4.7127166390419006e-01
    z[0,6,2]  R482      1.4961537718772888e-01
    z[0,6,2]  R483      -1.8319293856620789e-01
    z[0,6,2]  R484      -1.3706816732883453e-01
    z[0,6,2]  R485      7.3024737834930420e-01
    z[0,6,2]  R486      6.4887338876724243e-01
    z[0,6,2]  R487      7.5980907678604126e-01
    z[0,6,2]  R488      4.9294778704643250e-01
    z[0,6,2]  R489      0.561560869216919
    z[0,6,2]  R490      5.1509636640548706e-01
    z[0,6,2]  R491      4.7796097397804260e-01
    z[0,6,2]  R492      4.7889927029609680e-01
    z[0,6,2]  R493      -2.6386895775794983e-01
    z[0,6,2]  R494      2.3604415357112885e-01
    z[0,6,2]  R495      1.4005483686923981e-01
    z[0,6,2]  R496      -1.2100974470376968e-01
    z[0,6,2]  R497      2.4701626598834991e-01
    z[0,6,2]  R498      2.2184227406978607e-01
    z[0,6,2]  R499      2.1186850965023041e-01
    z[0,6,2]  R500      1.0004695504903793e-02
    z[0,6,2]  R501      -1.4007289707660675e-01
    z[0,6,2]  R502      -2.6390699669718742e-02
    z[0,6,2]  R503      -8.2079136371612549e-01
    z[0,6,2]  R504      -3.0513361096382141e-01
    z[0,6,2]  R505      1.3260711729526520e-01
    z[0,6,2]  R506      4.3324571847915649e-01
    z[0,6,2]  R507      9.5791496336460114e-02
    z[0,6,2]  R508      -4.3592703342437744e-01
    z[0,6,2]  R509      -7.1677841246128082e-02
    z[0,6,2]  R510      -0.585075855255127
    z[0,6,2]  R511      1.4758314192295074e-01
    z[0,6,2]  R512      -4.2893978953361511e-01
    z[0,6,2]  R513      3.5841426253318787e-01
    z[0,6,2]  R514      -7.8127644956111908e-02
    z[0,6,2]  R515      2.0337031781673431e-01
    z[0,6,2]  R516      2.7745169401168823e-01
    z[0,6,2]  R517      -3.3047281205654144e-02
    z[0,6,2]  R518      -4.7553098201751709e-01
    z[0,6,2]  R519      7.8497342765331268e-02
    z[0,6,2]  R520      0.196327343583107
    z[0,6,2]  R521      -2.2312331199645996e-01
    z[0,6,2]  R522      -1.5412187576293945e-01
    z[0,6,2]  R523      -1.4433591067790985e-01
    z[0,6,2]  R524      3.6017143726348877e-01
    z[0,6,2]  R525      -1.4645195007324219e-01
    z[0,6,2]  R526      7.0014052093029022e-02
    z[0,6,2]  R527      5.3152061998844147e-02
    z[0,6,2]  R528      -0.342255175113678
    z[0,6,2]  R529      -2.1780113875865936e-01
    z[0,6,2]  R530      -6.9982111454010010e-01
    z[0,6,2]  R531      -1.4328017830848694e-01
    z[0,6,2]  R532      -2.4706965684890747e-01
    z[0,6,2]  R533      8.7146468460559845e-02
    z[0,6,2]  R534      -3.1852287054061890e-01
    z[0,6,2]  R535      -3.0735307931900024e-01
    z[0,6,2]  R536      1.8711790442466736e-01
    z[0,6,2]  R537      -1.2212514411658049e-03
    z[0,6,2]  R538      5.8216166496276855e-01
    z[0,6,2]  R539      -1.7080813646316528e-01
    z[0,6,2]  R540      -5.5677533149719238e-02
    z[0,6,2]  R541      -0.00486822659149766
    z[0,6,2]  R542      9.9580520763993263e-03
    z[0,6,2]  R543      -0.0617239810526371
    z[0,6,2]  R544      -1.9903749227523804e-01
    z[0,6,2]  R545      2.5639909505844116e-01
    z[0,6,2]  R546      2.2625628858804703e-02
    z[0,6,2]  R547      -3.9600737392902374e-02
    z[0,6,2]  R548      -4.6437847614288330e-01
    z[0,6,2]  R549      -5.7949042320251465e-01
    z[0,6,2]  R550      -2.7532967925071716e-01
    z[0,6,2]  R551      -1.9601751863956451e-01
    z[0,6,2]  R552      -9.1783374547958374e-02
    z[0,6,2]  R553      -0.0622575469315052
    z[0,6,2]  R554      -3.6990141868591309e-01
    z[0,6,3]  R5        -1
    z[0,6,3]  R59       1
    z[0,6,3]  R417      -1
    z[0,6,3]  R418      1
    z[0,6,3]  R425      5.1677453517913818e-01
    z[0,6,3]  R426      1.2330103665590286e-01
    z[0,6,3]  R427      1.6277417540550232e-01
    z[0,6,3]  R428      4.2016741633415222e-01
    z[0,6,3]  R429      2.2670869529247284e-01
    z[0,6,3]  R430      2.6785820722579956e-01
    z[0,6,3]  R431      -1.0430599562823772e-02
    z[0,6,3]  R432      3.7662589550018311e-01
    z[0,6,3]  R433      2.8773674368858337e-01
    z[0,6,3]  R434      7.7458918094635010e-01
    z[0,6,3]  R435      1.6704623401165009e-01
    z[0,6,3]  R436      2.3247901350259781e-02
    z[0,6,3]  R437      4.1320866346359253e-01
    z[0,6,3]  R438      0.0545872300863266
    z[0,6,3]  R439      1.2594187259674072e-01
    z[0,6,3]  R440      1.6451855003833771e-01
    z[0,6,3]  R441      3.3085045218467712e-01
    z[0,6,3]  R442      2.4973908066749573e-01
    z[0,6,3]  R443      3.9302092790603638e-01
    z[0,6,3]  R444      -8.9879669249057770e-02
    z[0,6,3]  R445      -5.6031066179275513e-01
    z[0,6,3]  R446      -9.8044604063034058e-02
    z[0,6,3]  R447      -1.3259139657020569e-01
    z[0,6,3]  R448      -0.507114827632904
    z[0,6,3]  R449      -6.7938894033432007e-01
    z[0,6,3]  R450      -6.5618109703063965e-01
    z[0,6,3]  R451      -6.9857668876647949e-01
    z[0,6,3]  R452      -6.7651957273483276e-01
    z[0,6,3]  R453      -0.729148805141449
    z[0,6,3]  R454      -6.4328622817993164e-01
    z[0,6,3]  R455      6.0929656028747559e-02
    z[0,6,3]  R456      4.4564566016197205e-01
    z[0,6,3]  R457      -4.6845340728759766e-01
    z[0,6,3]  R458      0.217659592628479
    z[0,6,3]  R459      -2.1393077075481415e-01
    z[0,6,3]  R460      -2.3716230690479279e-01
    z[0,6,3]  R461      -3.2082572579383850e-01
    z[0,6,3]  R462      4.1865665465593338e-02
    z[0,6,3]  R463      -9.6946984529495239e-02
    z[0,6,3]  R464      8.9062482118606567e-02
    z[0,6,3]  R465      -3.2469424605369568e-01
    z[0,6,3]  R466      -3.8564404845237732e-01
    z[0,6,3]  R467      1.9415273563936353e-03
    z[0,6,3]  R468      -0.000567007577046752
    z[0,6,3]  R469      -0.308651328086853
    z[0,6,3]  R470      2.7416145801544189e-01
    z[0,6,3]  R471      -7.5802463293075562e-01
    z[0,6,3]  R472      -6.2473946809768677e-01
    z[0,6,3]  R473      -0.938624382019043
    z[0,6,3]  R474      -6.4770805835723877e-01
    z[0,6,3]  R475      5.8693759143352509e-02
    z[0,6,3]  R476      1.9043010473251343e-01
    z[0,6,3]  R477      2.8132423758506775e-01
    z[0,6,3]  R478      -7.3013061285018921e-01
    z[0,6,3]  R479      -7.1067994832992554e-01
    z[0,6,3]  R480      -7.9846704006195068e-01
    z[0,6,3]  R481      -0.622801661491394
    z[0,6,3]  R482      -4.3773502111434937e-01
    z[0,6,3]  R483      1.8729162216186523e-01
    z[0,6,3]  R484      -9.3009635806083679e-02
    z[0,6,3]  R485      0.336246132850647
    z[0,6,3]  R486      3.3790368586778641e-02
    z[0,6,3]  R487      1.8210436403751373e-01
    z[0,6,3]  R488      2.6490703225135803e-01
    z[0,6,3]  R489      1.2282897531986237e-01
    z[0,6,3]  R490      2.3171609640121460e-01
    z[0,6,3]  R491      1.9285863637924194e-01
    z[0,6,3]  R492      5.6925266981124878e-01
    z[0,6,3]  R493      -2.0015256106853485e-01
    z[0,6,3]  R494      3.7729573249816895e-01
    z[0,6,3]  R495      2.9598088003695011e-03
    z[0,6,3]  R496      3.4835198521614075e-01
    z[0,6,3]  R497      1.5558812022209167e-01
    z[0,6,3]  R498      2.9040387272834778e-01
    z[0,6,3]  R499      3.7722852826118469e-01
    z[0,6,3]  R500      3.2994246482849121e-01
    z[0,6,3]  R501      1.3568203151226044e-01
    z[0,6,3]  R502      0.705918550491333
    z[0,6,3]  R503      3.3525240421295166e-01
    z[0,6,3]  R504      -2.5709119439125061e-01
    z[0,6,3]  R505      1.7381575703620911e-01
    z[0,6,3]  R506      -2.7148360013961792e-01
    z[0,6,3]  R507      -9.1571047902107239e-02
    z[0,6,3]  R508      5.1690524816513062e-01
    z[0,6,3]  R509      6.6644591093063354e-01
    z[0,6,3]  R510      -5.8813279867172241e-01
    z[0,6,3]  R511      -2.9042765498161316e-01
    z[0,6,3]  R512      -6.5719529986381531e-02
    z[0,6,3]  R513      -3.1762981414794922e-01
    z[0,6,3]  R514      5.0791448354721069e-01
    z[0,6,3]  R515      4.5159086585044861e-01
    z[0,6,3]  R516      1.4282864332199097e-01
    z[0,6,3]  R517      -3.9496548473834991e-02
    z[0,6,3]  R518      4.8942431807518005e-01
    z[0,6,3]  R519      1.5942543745040894e-02
    z[0,6,3]  R520      1.8004053831100464e-01
    z[0,6,3]  R521      4.3607655167579651e-01
    z[0,6,3]  R522      6.8976312875747681e-01
    z[0,6,3]  R523      4.6873083710670471e-01
    z[0,6,3]  R524      -2.3597058653831482e-01
    z[0,6,3]  R525      -8.0088503658771515e-02
    z[0,6,3]  R526      -4.7161877155303955e-01
    z[0,6,3]  R527      1.7595584690570831e-01
    z[0,6,3]  R528      3.2299000024795532e-01
    z[0,6,3]  R529      2.6775670051574707e-01
    z[0,6,3]  R530      3.1743991374969482e-01
    z[0,6,3]  R531      -6.0094580054283142e-02
    z[0,6,3]  R532      -2.7603381872177124e-01
    z[0,6,3]  R533      2.6966568827629089e-01
    z[0,6,3]  R534      -7.0699453353881836e-01
    z[0,6,3]  R535      5.0980645418167114e-01
    z[0,6,3]  R536      1.3615450263023376e-01
    z[0,6,3]  R537      4.0435156226158142e-01
    z[0,6,3]  R538      2.5491121411323547e-01
    z[0,6,3]  R539      2.4826650321483612e-01
    z[0,6,3]  R540      -7.4099951982498169e-01
    z[0,6,3]  R541      -8.2505196332931519e-01
    z[0,6,3]  R542      -4.7321224212646484e-01
    z[0,6,3]  R543      -0.572223961353302
    z[0,6,3]  R544      -5.6724369525909424e-01
    z[0,6,3]  R545      -5.7623300701379776e-02
    z[0,6,3]  R546      0.425167053937912
    z[0,6,3]  R547      5.2429586648941040e-01
    z[0,6,3]  R548      2.2048802673816681e-01
    z[0,6,3]  R549      -2.1327883005142212e-01
    z[0,6,3]  R550      -2.3043704032897949e-01
    z[0,6,3]  R551      -5.8678174018859863e-01
    z[0,6,3]  R552      -3.4693691134452820e-01
    z[0,6,3]  R553      2.3797741532325745e-01
    z[0,6,3]  R554      -5.7473677396774292e-01
    z[0,6,4]  R6        -1
    z[0,6,4]  R60       1
    z[0,6,4]  R419      -1
    z[0,6,4]  R420      1
    z[0,6,4]  R425      -4.1218571364879608e-02
    z[0,6,4]  R426      0.352463036775589
    z[0,6,4]  R427      -2.4997876584529877e-01
    z[0,6,4]  R428      3.1200459599494934e-01
    z[0,6,4]  R429      -1.5997199714183807e-01
    z[0,6,4]  R430      -5.0467513501644135e-02
    z[0,6,4]  R431      3.9517077803611755e-01
    z[0,6,4]  R432      -3.3496016263961792e-01
    z[0,6,4]  R433      -2.5108709931373596e-01
    z[0,6,4]  R434      5.7777430862188339e-02
    z[0,6,4]  R435      -2.4556618183851242e-02
    z[0,6,4]  R436      -7.3936069384217262e-03
    z[0,6,4]  R437      1.3218869268894196e-01
    z[0,6,4]  R438      4.1001036763191223e-02
    z[0,6,4]  R439      2.5220713019371033e-01
    z[0,6,4]  R440      1.9193364679813385e-01
    z[0,6,4]  R441      -5.9747759252786636e-02
    z[0,6,4]  R442      -8.6109027266502380e-02
    z[0,6,4]  R443      1.3745196163654327e-01
    z[0,6,4]  R444      0.0350436307489872
    z[0,6,4]  R445      9.5477670431137085e-02
    z[0,6,4]  R446      -3.7079265713691711e-01
    z[0,6,4]  R447      -1.3064685463905334e-01
    z[0,6,4]  R448      3.2557407021522522e-01
    z[0,6,4]  R449      -1.3982348144054413e-01
    z[0,6,4]  R450      1.1141499131917953e-01
    z[0,6,4]  R451      -7.0524394512176514e-02
    z[0,6,4]  R452      8.8269263505935669e-02
    z[0,6,4]  R453      4.1587015986442566e-01
    z[0,6,4]  R454      4.0703928470611572e-01
    z[0,6,4]  R455      -2.1439389884471893e-01
    z[0,6,4]  R456      -2.3072990775108337e-01
    z[0,6,4]  R457      2.6333945989608765e-01
    z[0,6,4]  R458      2.4770571291446686e-01
    z[0,6,4]  R459      2.1385875344276428e-01
    z[0,6,4]  R460      6.0413964092731476e-02
    z[0,6,4]  R461      -2.5798571109771729e-01
    z[0,6,4]  R462      -1.1370173841714859e-01
    z[0,6,4]  R463      0.359660267829895
    z[0,6,4]  R464      5.8230042457580566e-02
    z[0,6,4]  R465      1.2516547739505768e-01
    z[0,6,4]  R466      -3.8943123072385788e-02
    z[0,6,4]  R467      -5.8395609259605408e-02
    z[0,6,4]  R468      0.284589558839798
    z[0,6,4]  R469      -3.4502550959587097e-01
    z[0,6,4]  R470      -6.8094119429588318e-02
    z[0,6,4]  R471      -7.7331632375717163e-02
    z[0,6,4]  R472      2.8215774893760681e-01
    z[0,6,4]  R473      1.0871417075395584e-01
    z[0,6,4]  R474      -1.9560030195862055e-03
    z[0,6,4]  R475      -1.1534772813320160e-01
    z[0,6,4]  R476      1.9251872599124908e-01
    z[0,6,4]  R477      0.0800652801990509
    z[0,6,4]  R478      1.9722582772374153e-02
    z[0,6,4]  R479      5.0033140927553177e-02
    z[0,6,4]  R480      -2.4309885501861572e-01
    z[0,6,4]  R481      9.8878055810928345e-02
    z[0,6,4]  R482      5.3946918249130249e-01
    z[0,6,4]  R483      1.6274869441986084e-01
    z[0,6,4]  R484      -4.7675538808107376e-03
    z[0,6,4]  R485      -1.9321829080581665e-01
    z[0,6,4]  R486      -3.2461011409759521e-01
    z[0,6,4]  R487      -1.3278612494468689e-01
    z[0,6,4]  R488      -0.0118703069165349
    z[0,6,4]  R489      -2.2214166820049286e-01
    z[0,6,4]  R490      -2.7712747454643250e-01
    z[0,6,4]  R491      1.8192107975482941e-01
    z[0,6,4]  R492      -1.8020243942737579e-01
    z[0,6,4]  R493      3.1285938620567322e-01
    z[0,6,4]  R494      3.2869994640350342e-01
    z[0,6,4]  R495      -0.469272255897522
    z[0,6,4]  R496      -5.0573742389678955e-01
    z[0,6,4]  R497      -0.673651397228241
    z[0,6,4]  R498      -5.4611217975616455e-01
    z[0,6,4]  R499      -6.1120033264160156e-01
    z[0,6,4]  R500      -6.5022456645965576e-01
    z[0,6,4]  R501      -1.9623193144798279e-01
    z[0,6,4]  R502      -4.0855661034584045e-01
    z[0,6,4]  R503      1.0501979850232601e-02
    z[0,6,4]  R504      -3.9771673083305359e-01
    z[0,6,4]  R505      -3.6315000057220459e-01
    z[0,6,4]  R506      -2.2095610201358795e-01
    z[0,6,4]  R507      -1.9793076813220978e-01
    z[0,6,4]  R508      -2.4136649072170258e-01
    z[0,6,4]  R509      -1.5399551391601562e-01
    z[0,6,4]  R510      7.9972252249717712e-02
    z[0,6,4]  R511      3.1315460801124573e-01
    z[0,6,4]  R512      -3.2879498600959778e-01
    z[0,6,4]  R513      1.6948254406452179e-01
    z[0,6,4]  R514      -1.8101902306079865e-01
    z[0,6,4]  R515      -1.0094108991324902e-02
    z[0,6,4]  R516      -1.5355275571346283e-01
    z[0,6,4]  R517      -1.4392051100730896e-01
    z[0,6,4]  R518      -1.3392525725066662e-02
    z[0,6,4]  R519      -2.5080311298370361e-01
    z[0,6,4]  R520      -3.9165604114532471e-01
    z[0,6,4]  R521      -2.1455757319927216e-01
    z[0,6,4]  R522      8.1501238048076630e-02
    z[0,6,4]  R523      -1.5934186056256294e-02
    z[0,6,4]  R524      1.5481737256050110e-01
    z[0,6,4]  R525      0.0746997743844986
    z[0,6,4]  R526      -2.7021676301956177e-01
    z[0,6,4]  R527      -7.6813362538814545e-02
    z[0,6,4]  R528      -1.2768602371215820e-01
    z[0,6,4]  R529      -4.0867531299591064e-01
    z[0,6,4]  R530      8.3716578781604767e-02
    z[0,6,4]  R531      2.8910359740257263e-01
    z[0,6,4]  R532      -1.3713514804840088e-01
    z[0,6,4]  R533      3.2937932014465332e-01
    z[0,6,4]  R534      7.1384929120540619e-02
    z[0,6,4]  R535      -2.1763689815998077e-02
    z[0,6,4]  R536      3.2222241163253784e-01
    z[0,6,4]  R537      0.0884227603673935
    z[0,6,4]  R538      7.1762814186513424e-03
    z[0,6,4]  R539      3.3743911981582642e-01
    z[0,6,4]  R540      4.5541308820247650e-02
    z[0,6,4]  R541      -1.0859984159469604e-01
    z[0,6,4]  R542      3.4488552808761597e-01
    z[0,6,4]  R543      3.4778553247451782e-01
    z[0,6,4]  R544      -2.7931997179985046e-01
    z[0,6,4]  R545      -3.2818517088890076e-01
    z[0,6,4]  R546      0.0850084200501442
    z[0,6,4]  R547      -3.6288848519325256e-01
    z[0,6,4]  R548      -1.4695268869400024e-01
    z[0,6,4]  R549      1.9674357026815414e-03
    z[0,6,4]  R550      -4.7718450427055359e-01
    z[0,6,4]  R551      -2.0010271668434143e-01
    z[0,6,4]  R552      -1.2761971354484558e-01
    z[0,6,4]  R553      8.7412588298320770e-02
    z[0,6,4]  R554      1.0059091448783875e-01
    z[0,6,5]  R7        -1
    z[0,6,5]  R61       1
    z[0,6,5]  R421      -1
    z[0,6,5]  R422      1
    z[0,6,5]  R425      1.9684407114982605e-01
    z[0,6,5]  R426      2.1400873363018036e-01
    z[0,6,5]  R427      1.7545576393604279e-01
    z[0,6,5]  R428      -8.3863191306591034e-02
    z[0,6,5]  R429      3.5342969000339508e-02
    z[0,6,5]  R430      -2.2698865830898285e-01
    z[0,6,5]  R431      3.7799999117851257e-01
    z[0,6,5]  R432      -7.9122260212898254e-03
    z[0,6,5]  R433      2.4082399904727936e-01
    z[0,6,5]  R434      1.1017414927482605e-01
    z[0,6,5]  R435      3.6226198077201843e-01
    z[0,6,5]  R436      3.0144955962896347e-02
    z[0,6,5]  R437      1.4294551312923431e-01
    z[0,6,5]  R438      1.7544165253639221e-01
    z[0,6,5]  R439      2.3372095823287964e-01
    z[0,6,5]  R440      4.1231876611709595e-01
    z[0,6,5]  R441      3.9987576007843018e-01
    z[0,6,5]  R442      4.1314443945884705e-01
    z[0,6,5]  R443      3.3306348323822021e-01
    z[0,6,5]  R444      1.6043521463871002e-01
    z[0,6,5]  R445      -5.6281950324773788e-02
    z[0,6,5]  R446      -3.6464065313339233e-01
    z[0,6,5]  R447      -3.4621521830558777e-01
    z[0,6,5]  R448      -4.0698921680450439e-01
    z[0,6,5]  R449      -4.0686112642288208e-01
    z[0,6,5]  R450      -2.8368967771530151e-01
    z[0,6,5]  R451      -1.4950375258922577e-01
    z[0,6,5]  R452      -2.9358950257301331e-01
    z[0,6,5]  R453      9.5859030261635780e-03
    z[0,6,5]  R454      -3.9522635936737061e-01
    z[0,6,5]  R455      -1.6145195066928864e-01
    z[0,6,5]  R456      -1.9120676815509796e-01
    z[0,6,5]  R457      -1.1766610294580460e-01
    z[0,6,5]  R458      -2.3118594661355019e-02
    z[0,6,5]  R459      -8.8029861450195312e-02
    z[0,6,5]  R460      -1.0294277220964432e-01
    z[0,6,5]  R461      -3.1823366880416870e-01
    z[0,6,5]  R462      -2.9804265499114990e-01
    z[0,6,5]  R463      -3.8015264272689819e-01
    z[0,6,5]  R464      -5.3212952613830566e-01
    z[0,6,5]  R465      -1.7609718441963196e-01
    z[0,6,5]  R466      -2.2707961499691010e-01
    z[0,6,5]  R467      -2.2068646550178528e-01
    z[0,6,5]  R468      -3.7052431702613831e-01
    z[0,6,5]  R469      1.1809995397925377e-02
    z[0,6,5]  R470      -1.8104976415634155e-01
    z[0,6,5]  R471      1.3202938437461853e-01
    z[0,6,5]  R472      -9.1548189520835876e-03
    z[0,6,5]  R473      -8.9364543557167053e-02
    z[0,6,5]  R474      4.1444590687751770e-01
    z[0,6,5]  R475      7.5835309922695160e-02
    z[0,6,5]  R476      7.5173109769821167e-02
    z[0,6,5]  R477      -1.4381489157676697e-01
    z[0,6,5]  R478      -2.3718622326850891e-01
    z[0,6,5]  R479      -3.9254122972488403e-01
    z[0,6,5]  R480      -6.2953993678092957e-02
    z[0,6,5]  R481      -5.6849384307861328e-01
    z[0,6,5]  R482      3.0457329750061035e-01
    z[0,6,5]  R483      4.8995118588209152e-02
    z[0,6,5]  R484      2.5946235656738281e-01
    z[0,6,5]  R485      -1.0714598465710878e-03
    z[0,6,5]  R486      -3.8282147049903870e-01
    z[0,6,5]  R487      -1.4236196875572205e-01
    z[0,6,5]  R488      -3.1125918030738831e-01
    z[0,6,5]  R489      1.1419694125652313e-01
    z[0,6,5]  R490      -2.9830756783485413e-01
    z[0,6,5]  R491      6.5622150897979736e-02
    z[0,6,5]  R492      -3.1495410948991776e-02
    z[0,6,5]  R493      1.6625548899173737e-01
    z[0,6,5]  R494      0.00990427378565073
    z[0,6,5]  R495      -4.4501629471778870e-01
    z[0,6,5]  R496      -0.575872540473938
    z[0,6,5]  R497      -1.5416010282933712e-02
    z[0,6,5]  R498      -6.1678472906351089e-02
    z[0,6,5]  R499      -2.0075160264968872e-01
    z[0,6,5]  R500      -3.1188848614692688e-01
    z[0,6,5]  R501      -2.4093411862850189e-02
    z[0,6,5]  R502      -0.0340031236410141
    z[0,6,5]  R503      -2.8606840968132019e-01
    z[0,6,5]  R504      1.5666624903678894e-01
    z[0,6,5]  R505      1.9608432427048683e-02
    z[0,6,5]  R506      1.4477960765361786e-01
    z[0,6,5]  R507      -5.5478483438491821e-01
    z[0,6,5]  R508      8.9255966246128082e-02
    z[0,6,5]  R509      4.4888880848884583e-01
    z[0,6,5]  R510      -5.8699328452348709e-02
    z[0,6,5]  R511      -3.1769070029258728e-01
    z[0,6,5]  R512      5.2408918738365173e-02
    z[0,6,5]  R513      -4.2835228145122528e-02
    z[0,6,5]  R514      -2.4383455514907837e-01
    z[0,6,5]  R515      -2.2099788486957550e-01
    z[0,6,5]  R516      -1.8712574243545532e-01
    z[0,6,5]  R517      -3.2201047986745834e-02
    z[0,6,5]  R518      -3.7080207467079163e-01
    z[0,6,5]  R519      -4.9428188800811768e-01
    z[0,6,5]  R520      1.7356021702289581e-01
    z[0,6,5]  R521      -1.0440428741276264e-02
    z[0,6,5]  R522      1.2030643969774246e-01
    z[0,6,5]  R523      -0.459465891122818
    z[0,6,5]  R524      -2.4612739682197571e-01
    z[0,6,5]  R525      -5.3476333618164062e-01
    z[0,6,5]  R526      -2.6849892735481262e-01
    z[0,6,5]  R527      6.7392992973327637e-01
    z[0,6,5]  R528      4.2553851008415222e-01
    z[0,6,5]  R529      -6.3333910703659058e-01
    z[0,6,5]  R530      1.9187904894351959e-01
    z[0,6,5]  R531      -0.0735400915145874
    z[0,6,5]  R532      5.2827745676040649e-01
    z[0,6,5]  R533      0.305154412984848
    z[0,6,5]  R534      -1.9441099464893341e-01
    z[0,6,5]  R535      3.0759319663047791e-01
    z[0,6,5]  R536      -1.1642579920589924e-02
    z[0,6,5]  R537      2.8545862436294556e-01
    z[0,6,5]  R538      5.5168390274047852e-01
    z[0,6,5]  R539      -2.1335309743881226e-01
    z[0,6,5]  R540      4.4023346900939941e-01
    z[0,6,5]  R541      -2.2197972238063812e-01
    z[0,6,5]  R542      -1.5570557117462158e-01
    z[0,6,5]  R543      -3.9092016220092773e-01
    z[0,6,5]  R544      -2.8752014040946960e-01
    z[0,6,5]  R545      -2.1267127990722656e-01
    z[0,6,5]  R546      3.0411267280578613e-01
    z[0,6,5]  R547      -1.5266118943691254e-01
    z[0,6,5]  R548      -0.0618041455745697
    z[0,6,5]  R549      -5.9121972322463989e-01
    z[0,6,5]  R550      -1.7312206327915192e-01
    z[0,6,5]  R551      2.2901852428913116e-01
    z[0,6,5]  R552      5.8368885517120361e-01
    z[0,6,5]  R553      2.1584718488156796e-03
    z[0,6,5]  R554      2.1394230425357819e-01
    z[0,6,6]  R8        -1
    z[0,6,6]  R62       1
    z[0,6,6]  R423      -1
    z[0,6,6]  R424      1
    z[0,6,6]  R425      -2.3867608606815338e-01
    z[0,6,6]  R426      -2.8994879126548767e-01
    z[0,6,6]  R427      2.2076773643493652e-01
    z[0,6,6]  R428      -3.2592701911926270e-01
    z[0,6,6]  R429      -3.1702980399131775e-02
    z[0,6,6]  R430      1.8523052334785461e-01
    z[0,6,6]  R431      1.6725838184356689e-01
    z[0,6,6]  R432      8.6627446115016937e-02
    z[0,6,6]  R433      2.2655488550662994e-01
    z[0,6,6]  R434      2.8011319041252136e-01
    z[0,6,6]  R435      0.245841383934021
    z[0,6,6]  R436      0.097848080098629
    z[0,6,6]  R437      -1.8725836277008057e-01
    z[0,6,6]  R438      -2.1693013608455658e-02
    z[0,6,6]  R439      3.1365182995796204e-01
    z[0,6,6]  R440      1.1375698447227478e-01
    z[0,6,6]  R441      9.7162231802940369e-02
    z[0,6,6]  R442      -1.0808359831571579e-01
    z[0,6,6]  R443      -6.4100623130798340e-02
    z[0,6,6]  R444      1.3626888394355774e-01
    z[0,6,6]  R445      -1.7072747647762299e-01
    z[0,6,6]  R446      -3.0899396166205406e-02
    z[0,6,6]  R447      -4.1400483250617981e-01
    z[0,6,6]  R448      -8.5938654839992523e-02
    z[0,6,6]  R449      -1.3139389455318451e-01
    z[0,6,6]  R450      -1.9289404153823853e-01
    z[0,6,6]  R451      2.1805499494075775e-01
    z[0,6,6]  R452      -3.6004860885441303e-03
    z[0,6,6]  R453      -1.7021040618419647e-01
    z[0,6,6]  R454      -8.1121474504470825e-03
    z[0,6,6]  R455      -8.0257803201675415e-02
    z[0,6,6]  R456      0.00755949504673481
    z[0,6,6]  R457      -9.6115969121456146e-02
    z[0,6,6]  R458      -9.2945620417594910e-02
    z[0,6,6]  R459      2.6474019885063171e-01
    z[0,6,6]  R460      -4.0284439921379089e-01
    z[0,6,6]  R461      6.5613955259323120e-02
    z[0,6,6]  R462      4.5896759629249573e-01
    z[0,6,6]  R463      -1.4630749821662903e-01
    z[0,6,6]  R464      -2.8226310014724731e-01
    z[0,6,6]  R465      -0.154501274228096
    z[0,6,6]  R466      2.2523556649684906e-01
    z[0,6,6]  R467      3.8888379931449890e-01
    z[0,6,6]  R468      -3.0032485723495483e-01
    z[0,6,6]  R469      3.7741836905479431e-01
    z[0,6,6]  R470      -3.9454710483551025e-01
    z[0,6,6]  R471      1.6951330006122589e-01
    z[0,6,6]  R472      -1.9711382687091827e-01
    z[0,6,6]  R473      -3.0246462672948837e-02
    z[0,6,6]  R474      -1.7947243154048920e-01
    z[0,6,6]  R475      -2.1330793201923370e-01
    z[0,6,6]  R476      -2.7563467621803284e-01
    z[0,6,6]  R477      -3.2324469089508057e-01
    z[0,6,6]  R478      6.4031504094600677e-02
    z[0,6,6]  R479      -1.0182687640190125e-01
    z[0,6,6]  R480      -8.6366616189479828e-02
    z[0,6,6]  R481      2.0609053969383240e-01
    z[0,6,6]  R482      7.7185044065117836e-03
    z[0,6,6]  R483      3.2198838889598846e-02
    z[0,6,6]  R484      0.0327945351600647
    z[0,6,6]  R485      -2.8217405080795288e-02
    z[0,6,6]  R486      -7.3660515248775482e-02
    z[0,6,6]  R487      -2.2573101520538330e-01
    z[0,6,6]  R488      3.0683785676956177e-01
    z[0,6,6]  R489      1.6246375441551208e-01
    z[0,6,6]  R490      2.1661767363548279e-01
    z[0,6,6]  R491      -5.1557719707489014e-01
    z[0,6,6]  R492      -4.6372652053833008e-01
    z[0,6,6]  R493      -1.0916743427515030e-01
    z[0,6,6]  R494      4.3695256114006042e-01
    z[0,6,6]  R495      4.4274058938026428e-01
    z[0,6,6]  R496      -7.9112062230706215e-03
    z[0,6,6]  R497      0.0438268817961216
    z[0,6,6]  R498      5.0233691930770874e-01
    z[0,6,6]  R499      3.0756852030754089e-01
    z[0,6,6]  R500      1.9096605479717255e-01
    z[0,6,6]  R501      8.3462363481521606e-01
    z[0,6,6]  R502      1.9705511629581451e-01
    z[0,6,6]  R503      7.8390344977378845e-02
    z[0,6,6]  R504      2.4253916740417480e-01
    z[0,6,6]  R505      -5.0089037418365479e-01
    z[0,6,6]  R506      -2.4915599822998047e-01
    z[0,6,6]  R507      -3.9576271176338196e-01
    z[0,6,6]  R508      -1.2277390062808990e-01
    z[0,6,6]  R509      3.1337331980466843e-02
    z[0,6,6]  R510      -2.1065460518002510e-02
    z[0,6,6]  R511      3.6656796932220459e-01
    z[0,6,6]  R512      3.2568693161010742e-01
    z[0,6,6]  R513      4.7090139985084534e-01
    z[0,6,6]  R514      1.5700249373912811e-01
    z[0,6,6]  R515      -0.0878305733203888
    z[0,6,6]  R516      4.8587873578071594e-01
    z[0,6,6]  R517      5.8731693029403687e-01
    z[0,6,6]  R518      -2.1546836197376251e-01
    z[0,6,6]  R519      -2.1871086210012436e-02
    z[0,6,6]  R520      3.4978860616683960e-01
    z[0,6,6]  R521      5.5898851156234741e-01
    z[0,6,6]  R522      -2.8701499104499817e-01
    z[0,6,6]  R523      1.9895464181900024e-01
    z[0,6,6]  R524      1.1828528344631195e-01
    z[0,6,6]  R525      -4.5216059684753418e-01
    z[0,6,6]  R526      2.8219836950302124e-01
    z[0,6,6]  R527      1.9805730879306793e-01
    z[0,6,6]  R528      2.1068581938743591e-01
    z[0,6,6]  R529      0.0917283371090889
    z[0,6,6]  R530      2.5312221050262451e-01
    z[0,6,6]  R531      -1.7761354148387909e-01
    z[0,6,6]  R532      -1.3293136656284332e-01
    z[0,6,6]  R533      7.4083633720874786e-02
    z[0,6,6]  R534      2.7343901991844177e-01
    z[0,6,6]  R535      3.5546016693115234e-01
    z[0,6,6]  R536      -2.9101896286010742e-01
    z[0,6,6]  R537      4.9817708134651184e-01
    z[0,6,6]  R538      0.06556436419487
    z[0,6,6]  R539      3.8490161299705505e-01
    z[0,6,6]  R540      1.9157165288925171e-01
    z[0,6,6]  R541      -3.5419678688049316e-01
    z[0,6,6]  R542      -3.3462695777416229e-02
    z[0,6,6]  R543      -1.1815723776817322e-01
    z[0,6,6]  R544      -1.7494225502014160e-01
    z[0,6,6]  R545      2.5070744752883911e-01
    z[0,6,6]  R546      4.1331019997596741e-01
    z[0,6,6]  R547      -1.5894058346748352e-01
    z[0,6,6]  R548      5.6092691421508789e-01
    z[0,6,6]  R549      1.3178764283657074e-01
    z[0,6,6]  R550      -5.2704453468322754e-02
    z[0,6,6]  R551      1.6040150821208954e-01
    z[0,6,6]  R552      -1.0079844295978546e-01
    z[0,6,6]  R553      3.0619084835052490e-01
    z[0,6,6]  R554      5.2435255050659180e-01
    z[6,0,0]  R2        1
    z[6,0,0]  R56       -1
    z[6,0,0]  R555      -1
    z[6,0,0]  R556      1
    z[6,0,0]  R569      4.4110476970672607e-01
    z[6,0,0]  R570      3.3901163935661316e-01
    z[6,0,0]  R571      5.2272677421569824e-01
    z[6,0,0]  R572      6.3964354991912842e-01
    z[6,0,0]  R573      1.7448575794696808e-01
    z[6,0,0]  R574      3.4932801127433777e-01
    z[6,0,0]  R575      4.8197889328002930e-01
    z[6,0,0]  R576      3.0211597681045532e-01
    z[6,0,0]  R577      -2.7162078768014908e-02
    z[6,0,0]  R578      6.8654817342758179e-01
    z[6,0,0]  R579      -6.1936073005199432e-02
    z[6,0,0]  R580      -1.7271035909652710e-01
    z[6,0,0]  R581      -4.2474997043609619e-01
    z[6,0,0]  R582      -1.7868795990943909e-01
    z[6,0,0]  R583      -1.7778226733207703e-01
    z[6,0,0]  R584      -3.4068015217781067e-01
    z[6,0,0]  R585      -1.1456552892923355e-01
    z[6,0,0]  R586      -1.4042910933494568e-01
    z[6,0,0]  R587      -3.1393563747406006e-01
    z[6,0,0]  R588      -7.5816917419433594e-01
    z[6,0,0]  R589      -0.279852956533432
    z[6,0,0]  R590      -9.2264115810394287e-02
    z[6,0,0]  R591      8.9268334209918976e-02
    z[6,0,0]  R592      -4.4528219103813171e-01
    z[6,0,0]  R593      -2.0623424649238586e-01
    z[6,0,0]  R594      -5.1273441314697266e-01
    z[6,0,0]  R595      5.5959355831146240e-01
    z[6,0,0]  R596      -6.4229393005371094e-01
    z[6,0,0]  R597      4.3120759725570679e-01
    z[6,0,0]  R598      -5.2551096677780151e-01
    z[6,0,0]  R599      4.0983331203460693e-01
    z[6,0,0]  R600      2.7934926748275757e-01
    z[6,0,0]  R601      -6.5420351922512054e-02
    z[6,0,0]  R602      -2.1329589188098907e-02
    z[6,0,0]  R603      8.3455525338649750e-02
    z[6,0,0]  R604      -2.1819558739662170e-01
    z[6,0,0]  R605      -1.3673183321952820e-01
    z[6,0,0]  R606      1.0967677831649780e-01
    z[6,0,0]  R607      3.1910541653633118e-01
    z[6,0,0]  R608      5.0385850667953491e-01
    z[6,0,0]  R609      1.7317111790180206e-01
    z[6,0,0]  R610      -1.8343149125576019e-01
    z[6,0,0]  R611      -2.9323059320449829e-01
    z[6,0,0]  R612      -4.5411375164985657e-01
    z[6,0,0]  R613      -1.2677389383316040e-01
    z[6,0,0]  R614      -5.2489918470382690e-01
    z[6,0,0]  R615      -8.7438768148422241e-01
    z[6,0,0]  R616      -7.0522385835647583e-01
    z[6,0,0]  R617      -8.1494313478469849e-01
    z[6,0,0]  R618      -2.6639264822006226e-01
    z[6,0,0]  R619      -1.7448942363262177e-01
    z[6,0,0]  R620      4.9027130007743835e-01
    z[6,0,0]  R621      1.6009068489074707e-01
    z[6,0,0]  R622      2.4896232783794403e-01
    z[6,0,0]  R623      -7.0342606306076050e-01
    z[6,0,0]  R624      -4.4413122534751892e-01
    z[6,0,0]  R625      -3.1985759735107422e-01
    z[6,0,0]  R626      -5.9791624546051025e-01
    z[6,0,0]  R627      -5.5491024255752563e-01
    z[6,0,0]  R628      -5.0269585847854614e-01
    z[6,0,0]  R629      1.9270670600235462e-03
    z[6,0,0]  R630      1.5989714860916138e-01
    z[6,0,0]  R631      -1.4859504997730255e-01
    z[6,0,0]  R632      -2.9126900434494019e-01
    z[6,0,0]  R633      -1.5396639704704285e-01
    z[6,0,0]  R634      -6.7126137018203735e-01
    z[6,0,0]  R635      -0.634260892868042
    z[6,0,0]  R636      -6.2756544351577759e-01
    z[6,0,0]  R637      -8.7570679187774658e-01
    z[6,0,0]  R638      -3.9466273784637451e-01
    z[6,0,0]  R639      3.1617248058319092e-01
    z[6,0,0]  R640      5.7669192552566528e-01
    z[6,0,0]  R641      4.7605317831039429e-01
    z[6,0,0]  R642      4.6785807609558105e-01
    z[6,0,0]  R643      8.7497037649154663e-01
    z[6,0,0]  R644      7.1143907308578491e-01
    z[6,0,0]  R645      6.8296575546264648e-01
    z[6,0,0]  R646      8.1498926877975464e-01
    z[6,0,0]  R647      0.185358464717865
    z[6,0,0]  R648      4.7616714239120483e-01
    z[6,0,0]  R649      -4.9223318696022034e-01
    z[6,0,0]  R650      -5.4711413383483887e-01
    z[6,0,0]  R651      -2.4950566887855530e-01
    z[6,0,0]  R652      -4.1189306974411011e-01
    z[6,0,0]  R653      -3.0863013863563538e-01
    z[6,0,0]  R654      -4.8976475000381470e-01
    z[6,0,0]  R655      -1.5400357544422150e-01
    z[6,0,0]  R656      -4.3866270780563354e-01
    z[6,0,0]  R657      -4.7704404592514038e-01
    z[6,0,0]  R658      -2.4821718037128448e-01
    z[6,0,0]  R659      1.1715054512023926e-01
    z[6,0,0]  R660      -7.2085000574588776e-02
    z[6,0,0]  R661      -7.1591906249523163e-02
    z[6,0,0]  R662      2.9847750067710876e-01
    z[6,0,0]  R663      -4.2866292595863342e-01
    z[6,0,0]  R664      -0.407634973526001
    z[6,0,0]  R665      -3.9184358716011047e-01
    z[6,0,0]  R666      -5.7812762260437012e-01
    z[6,0,0]  R667      2.7833279222249985e-02
    z[6,0,0]  R668      -2.9819878935813904e-01
    z[6,0,0]  R669      6.3001766800880432e-02
    z[6,0,0]  R670      0.0899825319647789
    z[6,0,0]  R671      2.5428640842437744e-01
    z[6,0,0]  R672      3.2596611976623535e-01
    z[6,0,0]  R673      3.4396609663963318e-01
    z[6,0,0]  R674      -2.6913258433341980e-01
    z[6,0,0]  R675      -2.6759406924247742e-01
    z[6,0,0]  R676      3.4607195854187012e-01
    z[6,0,0]  R677      4.3527016043663025e-01
    z[6,0,0]  R678      -1.2859259545803070e-01
    z[6,0,0]  R679      9.0489076683297753e-04
    z[6,0,0]  R680      1.2812386453151703e-01
    z[6,0,0]  R681      2.0964090526103973e-01
    z[6,0,0]  R682      3.1280410289764404e-01
    z[6,0,0]  R683      1.2833017110824585e-01
    z[6,0,0]  R684      -0.756442666053772
    z[6,0,0]  R685      -3.5724371671676636e-01
    z[6,0,0]  R686      -3.8763898611068726e-01
    z[6,0,0]  R687      -2.8695088624954224e-01
    z[6,0,0]  R688      -5.0645190477371216e-01
    z[6,0,0]  R689      -6.2723271548748016e-02
    z[6,0,0]  R690      1.7746257781982422e-01
    z[6,0,0]  R691      -7.8412890434265137e-01
    z[6,0,0]  R692      -3.7134975194931030e-01
    z[6,0,0]  R693      -4.2428565025329590e-01
    z[6,0,0]  R694      -3.3557087182998657e-01
    z[6,0,0]  R695      -1.0943162441253662e-01
    z[6,0,0]  R696      -4.9729606509208679e-01
    z[6,0,0]  R697      -8.1524938344955444e-01
    z[6,0,0]  R698      -7.9225832223892212e-01
    z[6,0,1]  R3        1
    z[6,0,1]  R57       -1
    z[6,0,1]  R557      -1
    z[6,0,1]  R558      1
    z[6,0,1]  R569      -3.4781205654144287e-01
    z[6,0,1]  R570      -4.5336815714836121e-01
    z[6,0,1]  R571      -1.6562427580356598e-01
    z[6,0,1]  R572      -2.9412621259689331e-01
    z[6,0,1]  R573      -7.4184560775756836e-01
    z[6,0,1]  R574      -5.8842420578002930e-01
    z[6,0,1]  R575      -4.4590777158737183e-01
    z[6,0,1]  R576      -3.2684186100959778e-01
    z[6,0,1]  R577      8.6725711822509766e-01
    z[6,0,1]  R578      -1.7752040922641754e-01
    z[6,0,1]  R579      6.0188430547714233e-01
    z[6,0,1]  R580      4.9670571088790894e-01
    z[6,0,1]  R581      5.2763450145721436e-01
    z[6,0,1]  R582      0.529279887676239
    z[6,0,1]  R583      5.2224355936050415e-01
    z[6,0,1]  R584      4.6737614274024963e-01
    z[6,0,1]  R585      4.6169325709342957e-01
    z[6,0,1]  R586      5.2379059791564941e-01
    z[6,0,1]  R587      1.6510948538780212e-01
    z[6,0,1]  R588      1.5629744529724121e-01
    z[6,0,1]  R589      0.700522780418396
    z[6,0,1]  R590      7.7344727516174316e-01
    z[6,0,1]  R591      6.8620622158050537e-01
    z[6,0,1]  R592      5.1303267478942871e-01
    z[6,0,1]  R593      5.3101956844329834e-01
    z[6,0,1]  R594      1.9648061692714691e-01
    z[6,0,1]  R595      4.9735376238822937e-01
    z[6,0,1]  R596      4.2687851190567017e-01
    z[6,0,1]  R597      5.7654422521591187e-01
    z[6,0,1]  R598      0.585563063621521
    z[6,0,1]  R599      7.2807049751281738e-01
    z[6,0,1]  R600      7.2795051336288452e-01
    z[6,0,1]  R601      7.9143977165222168e-01
    z[6,0,1]  R602      5.9142118692398071e-01
    z[6,0,1]  R603      8.2396847009658813e-01
    z[6,0,1]  R604      7.5865799188613892e-01
    z[6,0,1]  R605      6.1866432428359985e-01
    z[6,0,1]  R606      6.2044388055801392e-01
    z[6,0,1]  R607      6.3771826028823853e-01
    z[6,0,1]  R608      6.7984002828598022e-01
    z[6,0,1]  R609      6.6794329881668091e-01
    z[6,0,1]  R610      7.1713459491729736e-01
    z[6,0,1]  R611      6.1718851327896118e-01
    z[6,0,1]  R612      5.7492977380752563e-01
    z[6,0,1]  R613      5.3688865900039673e-01
    z[6,0,1]  R614      1.6145062446594238e-01
    z[6,0,1]  R615      3.0128052830696106e-01
    z[6,0,1]  R616      2.2331005334854126e-01
    z[6,0,1]  R617      2.2012549638748169e-01
    z[6,0,1]  R618      -4.5834100246429443e-01
    z[6,0,1]  R619      6.2749165296554565e-01
    z[6,0,1]  R620      7.1932464838027954e-01
    z[6,0,1]  R621      6.8802893161773682e-01
    z[6,0,1]  R622      4.7478458285331726e-01
    z[6,0,1]  R623      3.2687309384346008e-01
    z[6,0,1]  R624      1.3411889970302582e-01
    z[6,0,1]  R625      1.7444875836372375e-01
    z[6,0,1]  R626      -0.523600161075592
    z[6,0,1]  R627      -2.7035170793533325e-01
    z[6,0,1]  R628      -4.4116139411926270e-01
    z[6,0,1]  R629      8.4566336870193481e-01
    z[6,0,1]  R630      7.2292298078536987e-01
    z[6,0,1]  R631      7.2194844484329224e-01
    z[6,0,1]  R632      5.5753582715988159e-01
    z[6,0,1]  R633      4.7758224606513977e-01
    z[6,0,1]  R634      4.0005820989608765e-01
    z[6,0,1]  R635      3.1105974316596985e-01
    z[6,0,1]  R636      3.3201286196708679e-01
    z[6,0,1]  R637      2.6688948273658752e-01
    z[6,0,1]  R638      2.1507333219051361e-01
    z[6,0,1]  R639      -2.2488594055175781e-01
    z[6,0,1]  R640      -1.2939150631427765e-01
    z[6,0,1]  R641      -2.1679200232028961e-01
    z[6,0,1]  R642      -4.0721505880355835e-01
    z[6,0,1]  R643      -1.8201905488967896e-01
    z[6,0,1]  R644      -3.6664776504039764e-02
    z[6,0,1]  R645      -3.5846021771430969e-01
    z[6,0,1]  R646      -2.6038247346878052e-01
    z[6,0,1]  R647      -6.8155348300933838e-01
    z[6,0,1]  R648      -2.8164952993392944e-01
    z[6,0,1]  R649      6.2968921661376953e-01
    z[6,0,1]  R650      6.2375122308731079e-01
    z[6,0,1]  R651      6.4590960741043091e-01
    z[6,0,1]  R652      8.7937724590301514e-01
    z[6,0,1]  R653      7.2811561822891235e-01
    z[6,0,1]  R654      4.4551664590835571e-01
    z[6,0,1]  R655      7.0651078224182129e-01
    z[6,0,1]  R656      6.0509574413299561e-01
    z[6,0,1]  R657      4.0943464636802673e-01
    z[6,0,1]  R658      0.868427574634552
    z[6,0,1]  R659      7.7697628736495972e-01
    z[6,0,1]  R660      8.2676619291305542e-01
    z[6,0,1]  R661      7.4282425642013550e-01
    z[6,0,1]  R662      5.9907871484756470e-01
    z[6,0,1]  R663      3.6086297035217285e-01
    z[6,0,1]  R664      -5.0757569074630737e-01
    z[6,0,1]  R665      1.7272317409515381e-01
    z[6,0,1]  R666      -3.2708102464675903e-01
    z[6,0,1]  R667      4.5395290851593018e-01
    z[6,0,1]  R668      -2.8362569212913513e-01
    z[6,0,1]  R669      9.4584661722183228e-01
    z[6,0,1]  R670      8.3826774358749390e-01
    z[6,0,1]  R671      7.8720378875732422e-01
    z[6,0,1]  R672      8.5944074392318726e-01
    z[6,0,1]  R673      7.4405682086944580e-01
    z[6,0,1]  R674      8.2526820898056030e-01
    z[6,0,1]  R675      7.6957190036773682e-01
    z[6,0,1]  R676      0.693574070930481
    z[6,0,1]  R677      7.0397454500198364e-01
    z[6,0,1]  R678      7.1981674432754517e-01
    z[6,0,1]  R679      8.8600194454193115e-01
    z[6,0,1]  R680      8.1919866800308228e-01
    z[6,0,1]  R681      7.5020068883895874e-01
    z[6,0,1]  R682      7.7050465345382690e-01
    z[6,0,1]  R683      7.8837692737579346e-01
    z[6,0,1]  R684      3.5375913977622986e-01
    z[6,0,1]  R685      3.5882890224456787e-01
    z[6,0,1]  R686      2.7233263850212097e-01
    z[6,0,1]  R687      -6.9074638187885284e-02
    z[6,0,1]  R688      3.1501409411430359e-01
    z[6,0,1]  R689      9.6092832088470459e-01
    z[6,0,1]  R690      9.0106505155563354e-01
    z[6,0,1]  R691      3.6725702881813049e-01
    z[6,0,1]  R692      -4.7007972002029419e-01
    z[6,0,1]  R693      -2.9570633172988892e-01
    z[6,0,1]  R694      3.7011715769767761e-01
    z[6,0,1]  R695      -5.1091857254505157e-02
    z[6,0,1]  R696      -3.9350786805152893e-01
    z[6,0,1]  R697      -0.486627459526062
    z[6,0,1]  R698      -5.2580362558364868e-01
    z[6,0,2]  R4        1
    z[6,0,2]  R58       -1
    z[6,0,2]  R559      -1
    z[6,0,2]  R560      1
    z[6,0,2]  R569      7.3024737834930420e-01
    z[6,0,2]  R570      6.4887338876724243e-01
    z[6,0,2]  R571      7.5980907678604126e-01
    z[6,0,2]  R572      4.9294778704643250e-01
    z[6,0,2]  R573      0.561560869216919
    z[6,0,2]  R574      5.1509636640548706e-01
    z[6,0,2]  R575      4.7796097397804260e-01
    z[6,0,2]  R576      4.7889927029609680e-01
    z[6,0,2]  R577      -2.6386895775794983e-01
    z[6,0,2]  R578      2.3604415357112885e-01
    z[6,0,2]  R579      1.4005483686923981e-01
    z[6,0,2]  R580      -1.2100974470376968e-01
    z[6,0,2]  R581      2.4701626598834991e-01
    z[6,0,2]  R582      2.2184227406978607e-01
    z[6,0,2]  R583      2.1186850965023041e-01
    z[6,0,2]  R584      1.0004695504903793e-02
    z[6,0,2]  R585      -1.4007289707660675e-01
    z[6,0,2]  R586      -2.6390699669718742e-02
    z[6,0,2]  R587      -8.2079136371612549e-01
    z[6,0,2]  R588      -3.0513361096382141e-01
    z[6,0,2]  R589      1.3260711729526520e-01
    z[6,0,2]  R590      4.3324571847915649e-01
    z[6,0,2]  R591      9.5791496336460114e-02
    z[6,0,2]  R592      -4.3592703342437744e-01
    z[6,0,2]  R593      -7.1677841246128082e-02
    z[6,0,2]  R594      -0.585075855255127
    z[6,0,2]  R595      1.4758314192295074e-01
    z[6,0,2]  R596      -4.2893978953361511e-01
    z[6,0,2]  R597      3.5841426253318787e-01
    z[6,0,2]  R598      -7.8127644956111908e-02
    z[6,0,2]  R599      2.0337031781673431e-01
    z[6,0,2]  R600      2.7745169401168823e-01
    z[6,0,2]  R601      -3.3047281205654144e-02
    z[6,0,2]  R602      -4.7553098201751709e-01
    z[6,0,2]  R603      7.8497342765331268e-02
    z[6,0,2]  R604      0.196327343583107
    z[6,0,2]  R605      -2.2312331199645996e-01
    z[6,0,2]  R606      -1.5412187576293945e-01
    z[6,0,2]  R607      -1.4433591067790985e-01
    z[6,0,2]  R608      3.6017143726348877e-01
    z[6,0,2]  R609      -1.4645195007324219e-01
    z[6,0,2]  R610      7.0014052093029022e-02
    z[6,0,2]  R611      5.3152061998844147e-02
    z[6,0,2]  R612      -0.342255175113678
    z[6,0,2]  R613      -2.1780113875865936e-01
    z[6,0,2]  R614      -6.9982111454010010e-01
    z[6,0,2]  R615      -1.4328017830848694e-01
    z[6,0,2]  R616      -2.4706965684890747e-01
    z[6,0,2]  R617      8.7146468460559845e-02
    z[6,0,2]  R618      -3.1852287054061890e-01
    z[6,0,2]  R619      -3.0735307931900024e-01
    z[6,0,2]  R620      1.8711790442466736e-01
    z[6,0,2]  R621      -1.2212514411658049e-03
    z[6,0,2]  R622      5.8216166496276855e-01
    z[6,0,2]  R623      -1.7080813646316528e-01
    z[6,0,2]  R624      -5.5677533149719238e-02
    z[6,0,2]  R625      -0.00486822659149766
    z[6,0,2]  R626      9.9580520763993263e-03
    z[6,0,2]  R627      -0.0617239810526371
    z[6,0,2]  R628      -1.9903749227523804e-01
    z[6,0,2]  R629      2.5639909505844116e-01
    z[6,0,2]  R630      2.2625628858804703e-02
    z[6,0,2]  R631      -3.9600737392902374e-02
    z[6,0,2]  R632      -4.6437847614288330e-01
    z[6,0,2]  R633      -5.7949042320251465e-01
    z[6,0,2]  R634      -2.7532967925071716e-01
    z[6,0,2]  R635      -1.9601751863956451e-01
    z[6,0,2]  R636      -9.1783374547958374e-02
    z[6,0,2]  R637      -0.0622575469315052
    z[6,0,2]  R638      -3.6990141868591309e-01
    z[6,0,2]  R639      6.9641411304473877e-01
    z[6,0,2]  R640      6.1756026744842529e-01
    z[6,0,2]  R641      0.746904730796814
    z[6,0,2]  R642      4.7763559222221375e-01
    z[6,0,2]  R643      3.4936192631721497e-01
    z[6,0,2]  R644      5.7652479410171509e-01
    z[6,0,2]  R645      2.7917012572288513e-01
    z[6,0,2]  R646      7.9882211983203888e-02
    z[6,0,2]  R647      4.9595010280609131e-01
    z[6,0,2]  R648      -3.1767857726663351e-03
    z[6,0,2]  R649      -3.7552466988563538e-01
    z[6,0,2]  R650      -5.4819935560226440e-01
    z[6,0,2]  R651      -5.2614951133728027e-01
    z[6,0,2]  R652      -1.4535656571388245e-01
    z[6,0,2]  R653      -3.7699118256568909e-01
    z[6,0,2]  R654      -5.6106412410736084e-01
    z[6,0,2]  R655      -4.4130784273147583e-01
    z[6,0,2]  R656      -4.3506258726119995e-01
    z[6,0,2]  R657      -5.6248861551284790e-01
    z[6,0,2]  R658      -3.6139541864395142e-01
    z[6,0,2]  R659      1.6493658721446991e-01
    z[6,0,2]  R660      1.7390790581703186e-01
    z[6,0,2]  R661      3.4230497479438782e-01
    z[6,0,2]  R662      -1.2580266594886780e-01
    z[6,0,2]  R663      -1.4868043363094330e-01
    z[6,0,2]  R664      -1.2460289150476456e-01
    z[6,0,2]  R665      -0.503728985786438
    z[6,0,2]  R666      8.4312453866004944e-02
    z[6,0,2]  R667      -2.4389077723026276e-01
    z[6,0,2]  R668      -3.0800363421440125e-01
    z[6,0,2]  R669      1.3863548636436462e-01
    z[6,0,2]  R670      -2.7512248605489731e-02
    z[6,0,2]  R671      -6.1390563845634460e-02
    z[6,0,2]  R672      -1.9287452101707458e-01
    z[6,0,2]  R673      -3.9840704202651978e-01
    z[6,0,2]  R674      -1.1714725941419601e-01
    z[6,0,2]  R675      -2.4716173112392426e-01
    z[6,0,2]  R676      -2.9159530997276306e-01
    z[6,0,2]  R677      -1.0140753537416458e-01
    z[6,0,2]  R678      -3.0194488167762756e-01
    z[6,0,2]  R679      -1.9755041599273682e-01
    z[6,0,2]  R680      -2.4487484991550446e-01
    z[6,0,2]  R681      -0.43577840924263
    z[6,0,2]  R682      -1.1846154229715466e-03
    z[6,0,2]  R683      7.1419939398765564e-02
    z[6,0,2]  R684      -1.8547539412975311e-01
    z[6,0,2]  R685      -3.4186357259750366e-01
    z[6,0,2]  R686      -5.1645022630691528e-01
    z[6,0,2]  R687      -1.0560575872659683e-01
    z[6,0,2]  R688      -1.4410842955112457e-01
    z[6,0,2]  R689      6.8419404327869415e-02
    z[6,0,2]  R690      -4.0451448410749435e-02
    z[6,0,2]  R691      -1.9884806871414185e-01
    z[6,0,2]  R692      -2.1745659410953522e-01
    z[6,0,2]  R693      -2.4599377810955048e-01
    z[6,0,2]  R694      2.0575824379920959e-01
    z[6,0,2]  R695      -4.7127166390419006e-01
    z[6,0,2]  R696      1.4961537718772888e-01
    z[6,0,2]  R697      -1.8319293856620789e-01
    z[6,0,2]  R698      -1.3706816732883453e-01
    z[6,0,3]  R5        1
    z[6,0,3]  R59       -1
    z[6,0,3]  R561      -1
    z[6,0,3]  R562      1
    z[6,0,3]  R569      0.336246132850647
    z[6,0,3]  R570      3.3790368586778641e-02
    z[6,0,3]  R571      1.8210436403751373e-01
    z[6,0,3]  R572      2.6490703225135803e-01
    z[6,0,3]  R573      1.2282897531986237e-01
    z[6,0,3]  R574      2.3171609640121460e-01
    z[6,0,3]  R575      1.9285863637924194e-01
    z[6,0,3]  R576      5.6925266981124878e-01
    z[6,0,3]  R577      -2.0015256106853485e-01
    z[6,0,3]  R578      3.7729573249816895e-01
    z[6,0,3]  R579      2.9598088003695011e-03
    z[6,0,3]  R580      3.4835198521614075e-01
    z[6,0,3]  R581      1.5558812022209167e-01
    z[6,0,3]  R582      2.9040387272834778e-01
    z[6,0,3]  R583      3.7722852826118469e-01
    z[6,0,3]  R584      3.2994246482849121e-01
    z[6,0,3]  R585      1.3568203151226044e-01
    z[6,0,3]  R586      0.705918550491333
    z[6,0,3]  R587      3.3525240421295166e-01
    z[6,0,3]  R588      -2.5709119439125061e-01
    z[6,0,3]  R589      1.7381575703620911e-01
    z[6,0,3]  R590      -2.7148360013961792e-01
    z[6,0,3]  R591      -9.1571047902107239e-02
    z[6,0,3]  R592      5.1690524816513062e-01
    z[6,0,3]  R593      6.6644591093063354e-01
    z[6,0,3]  R594      -5.8813279867172241e-01
    z[6,0,3]  R595      -2.9042765498161316e-01
    z[6,0,3]  R596      -6.5719529986381531e-02
    z[6,0,3]  R597      -3.1762981414794922e-01
    z[6,0,3]  R598      5.0791448354721069e-01
    z[6,0,3]  R599      4.5159086585044861e-01
    z[6,0,3]  R600      1.4282864332199097e-01
    z[6,0,3]  R601      -3.9496548473834991e-02
    z[6,0,3]  R602      4.8942431807518005e-01
    z[6,0,3]  R603      1.5942543745040894e-02
    z[6,0,3]  R604      1.8004053831100464e-01
    z[6,0,3]  R605      4.3607655167579651e-01
    z[6,0,3]  R606      6.8976312875747681e-01
    z[6,0,3]  R607      4.6873083710670471e-01
    z[6,0,3]  R608      -2.3597058653831482e-01
    z[6,0,3]  R609      -8.0088503658771515e-02
    z[6,0,3]  R610      -4.7161877155303955e-01
    z[6,0,3]  R611      1.7595584690570831e-01
    z[6,0,3]  R612      3.2299000024795532e-01
    z[6,0,3]  R613      2.6775670051574707e-01
    z[6,0,3]  R614      3.1743991374969482e-01
    z[6,0,3]  R615      -6.0094580054283142e-02
    z[6,0,3]  R616      -2.7603381872177124e-01
    z[6,0,3]  R617      2.6966568827629089e-01
    z[6,0,3]  R618      -7.0699453353881836e-01
    z[6,0,3]  R619      5.0980645418167114e-01
    z[6,0,3]  R620      1.3615450263023376e-01
    z[6,0,3]  R621      4.0435156226158142e-01
    z[6,0,3]  R622      2.5491121411323547e-01
    z[6,0,3]  R623      2.4826650321483612e-01
    z[6,0,3]  R624      -7.4099951982498169e-01
    z[6,0,3]  R625      -8.2505196332931519e-01
    z[6,0,3]  R626      -4.7321224212646484e-01
    z[6,0,3]  R627      -0.572223961353302
    z[6,0,3]  R628      -5.6724369525909424e-01
    z[6,0,3]  R629      -5.7623300701379776e-02
    z[6,0,3]  R630      0.425167053937912
    z[6,0,3]  R631      5.2429586648941040e-01
    z[6,0,3]  R632      2.2048802673816681e-01
    z[6,0,3]  R633      -2.1327883005142212e-01
    z[6,0,3]  R634      -2.3043704032897949e-01
    z[6,0,3]  R635      -5.8678174018859863e-01
    z[6,0,3]  R636      -3.4693691134452820e-01
    z[6,0,3]  R637      2.3797741532325745e-01
    z[6,0,3]  R638      -5.7473677396774292e-01
    z[6,0,3]  R639      5.1677453517913818e-01
    z[6,0,3]  R640      1.2330103665590286e-01
    z[6,0,3]  R641      1.6277417540550232e-01
    z[6,0,3]  R642      4.2016741633415222e-01
    z[6,0,3]  R643      2.2670869529247284e-01
    z[6,0,3]  R644      2.6785820722579956e-01
    z[6,0,3]  R645      -1.0430599562823772e-02
    z[6,0,3]  R646      3.7662589550018311e-01
    z[6,0,3]  R647      2.8773674368858337e-01
    z[6,0,3]  R648      7.7458918094635010e-01
    z[6,0,3]  R649      1.6704623401165009e-01
    z[6,0,3]  R650      2.3247901350259781e-02
    z[6,0,3]  R651      4.1320866346359253e-01
    z[6,0,3]  R652      0.0545872300863266
    z[6,0,3]  R653      1.2594187259674072e-01
    z[6,0,3]  R654      1.6451855003833771e-01
    z[6,0,3]  R655      3.3085045218467712e-01
    z[6,0,3]  R656      2.4973908066749573e-01
    z[6,0,3]  R657      3.9302092790603638e-01
    z[6,0,3]  R658      -8.9879669249057770e-02
    z[6,0,3]  R659      -5.6031066179275513e-01
    z[6,0,3]  R660      -9.8044604063034058e-02
    z[6,0,3]  R661      -1.3259139657020569e-01
    z[6,0,3]  R662      -0.507114827632904
    z[6,0,3]  R663      -6.7938894033432007e-01
    z[6,0,3]  R664      -6.5618109703063965e-01
    z[6,0,3]  R665      -6.9857668876647949e-01
    z[6,0,3]  R666      -6.7651957273483276e-01
    z[6,0,3]  R667      -0.729148805141449
    z[6,0,3]  R668      -6.4328622817993164e-01
    z[6,0,3]  R669      6.0929656028747559e-02
    z[6,0,3]  R670      4.4564566016197205e-01
    z[6,0,3]  R671      -4.6845340728759766e-01
    z[6,0,3]  R672      0.217659592628479
    z[6,0,3]  R673      -2.1393077075481415e-01
    z[6,0,3]  R674      -2.3716230690479279e-01
    z[6,0,3]  R675      -3.2082572579383850e-01
    z[6,0,3]  R676      4.1865665465593338e-02
    z[6,0,3]  R677      -9.6946984529495239e-02
    z[6,0,3]  R678      8.9062482118606567e-02
    z[6,0,3]  R679      -3.2469424605369568e-01
    z[6,0,3]  R680      -3.8564404845237732e-01
    z[6,0,3]  R681      1.9415273563936353e-03
    z[6,0,3]  R682      -0.000567007577046752
    z[6,0,3]  R683      -0.308651328086853
    z[6,0,3]  R684      2.7416145801544189e-01
    z[6,0,3]  R685      -7.5802463293075562e-01
    z[6,0,3]  R686      -6.2473946809768677e-01
    z[6,0,3]  R687      -0.938624382019043
    z[6,0,3]  R688      -6.4770805835723877e-01
    z[6,0,3]  R689      5.8693759143352509e-02
    z[6,0,3]  R690      1.9043010473251343e-01
    z[6,0,3]  R691      2.8132423758506775e-01
    z[6,0,3]  R692      -7.3013061285018921e-01
    z[6,0,3]  R693      -7.1067994832992554e-01
    z[6,0,3]  R694      -7.9846704006195068e-01
    z[6,0,3]  R695      -0.622801661491394
    z[6,0,3]  R696      -4.3773502111434937e-01
    z[6,0,3]  R697      1.8729162216186523e-01
    z[6,0,3]  R698      -9.3009635806083679e-02
    z[6,0,4]  R6        1
    z[6,0,4]  R60       -1
    z[6,0,4]  R563      -1
    z[6,0,4]  R564      1
    z[6,0,4]  R569      -1.9321829080581665e-01
    z[6,0,4]  R570      -3.2461011409759521e-01
    z[6,0,4]  R571      -1.3278612494468689e-01
    z[6,0,4]  R572      -0.0118703069165349
    z[6,0,4]  R573      -2.2214166820049286e-01
    z[6,0,4]  R574      -2.7712747454643250e-01
    z[6,0,4]  R575      1.8192107975482941e-01
    z[6,0,4]  R576      -1.8020243942737579e-01
    z[6,0,4]  R577      3.1285938620567322e-01
    z[6,0,4]  R578      3.2869994640350342e-01
    z[6,0,4]  R579      -0.469272255897522
    z[6,0,4]  R580      -5.0573742389678955e-01
    z[6,0,4]  R581      -0.673651397228241
    z[6,0,4]  R582      -5.4611217975616455e-01
    z[6,0,4]  R583      -6.1120033264160156e-01
    z[6,0,4]  R584      -6.5022456645965576e-01
    z[6,0,4]  R585      -1.9623193144798279e-01
    z[6,0,4]  R586      -4.0855661034584045e-01
    z[6,0,4]  R587      1.0501979850232601e-02
    z[6,0,4]  R588      -3.9771673083305359e-01
    z[6,0,4]  R589      -3.6315000057220459e-01
    z[6,0,4]  R590      -2.2095610201358795e-01
    z[6,0,4]  R591      -1.9793076813220978e-01
    z[6,0,4]  R592      -2.4136649072170258e-01
    z[6,0,4]  R593      -1.5399551391601562e-01
    z[6,0,4]  R594      7.9972252249717712e-02
    z[6,0,4]  R595      3.1315460801124573e-01
    z[6,0,4]  R596      -3.2879498600959778e-01
    z[6,0,4]  R597      1.6948254406452179e-01
    z[6,0,4]  R598      -1.8101902306079865e-01
    z[6,0,4]  R599      -1.0094108991324902e-02
    z[6,0,4]  R600      -1.5355275571346283e-01
    z[6,0,4]  R601      -1.4392051100730896e-01
    z[6,0,4]  R602      -1.3392525725066662e-02
    z[6,0,4]  R603      -2.5080311298370361e-01
    z[6,0,4]  R604      -3.9165604114532471e-01
    z[6,0,4]  R605      -2.1455757319927216e-01
    z[6,0,4]  R606      8.1501238048076630e-02
    z[6,0,4]  R607      -1.5934186056256294e-02
    z[6,0,4]  R608      1.5481737256050110e-01
    z[6,0,4]  R609      0.0746997743844986
    z[6,0,4]  R610      -2.7021676301956177e-01
    z[6,0,4]  R611      -7.6813362538814545e-02
    z[6,0,4]  R612      -1.2768602371215820e-01
    z[6,0,4]  R613      -4.0867531299591064e-01
    z[6,0,4]  R614      8.3716578781604767e-02
    z[6,0,4]  R615      2.8910359740257263e-01
    z[6,0,4]  R616      -1.3713514804840088e-01
    z[6,0,4]  R617      3.2937932014465332e-01
    z[6,0,4]  R618      7.1384929120540619e-02
    z[6,0,4]  R619      -2.1763689815998077e-02
    z[6,0,4]  R620      3.2222241163253784e-01
    z[6,0,4]  R621      0.0884227603673935
    z[6,0,4]  R622      7.1762814186513424e-03
    z[6,0,4]  R623      3.3743911981582642e-01
    z[6,0,4]  R624      4.5541308820247650e-02
    z[6,0,4]  R625      -1.0859984159469604e-01
    z[6,0,4]  R626      3.4488552808761597e-01
    z[6,0,4]  R627      3.4778553247451782e-01
    z[6,0,4]  R628      -2.7931997179985046e-01
    z[6,0,4]  R629      -3.2818517088890076e-01
    z[6,0,4]  R630      0.0850084200501442
    z[6,0,4]  R631      -3.6288848519325256e-01
    z[6,0,4]  R632      -1.4695268869400024e-01
    z[6,0,4]  R633      1.9674357026815414e-03
    z[6,0,4]  R634      -4.7718450427055359e-01
    z[6,0,4]  R635      -2.0010271668434143e-01
    z[6,0,4]  R636      -1.2761971354484558e-01
    z[6,0,4]  R637      8.7412588298320770e-02
    z[6,0,4]  R638      1.0059091448783875e-01
    z[6,0,4]  R639      -4.1218571364879608e-02
    z[6,0,4]  R640      0.352463036775589
    z[6,0,4]  R641      -2.4997876584529877e-01
    z[6,0,4]  R642      3.1200459599494934e-01
    z[6,0,4]  R643      -1.5997199714183807e-01
    z[6,0,4]  R644      -5.0467513501644135e-02
    z[6,0,4]  R645      3.9517077803611755e-01
    z[6,0,4]  R646      -3.3496016263961792e-01
    z[6,0,4]  R647      -2.5108709931373596e-01
    z[6,0,4]  R648      5.7777430862188339e-02
    z[6,0,4]  R649      -2.4556618183851242e-02
    z[6,0,4]  R650      -7.3936069384217262e-03
    z[6,0,4]  R651      1.3218869268894196e-01
    z[6,0,4]  R652      4.1001036763191223e-02
    z[6,0,4]  R653      2.5220713019371033e-01
    z[6,0,4]  R654      1.9193364679813385e-01
    z[6,0,4]  R655      -5.9747759252786636e-02
    z[6,0,4]  R656      -8.6109027266502380e-02
    z[6,0,4]  R657      1.3745196163654327e-01
    z[6,0,4]  R658      0.0350436307489872
    z[6,0,4]  R659      9.5477670431137085e-02
    z[6,0,4]  R660      -3.7079265713691711e-01
    z[6,0,4]  R661      -1.3064685463905334e-01
    z[6,0,4]  R662      3.2557407021522522e-01
    z[6,0,4]  R663      -1.3982348144054413e-01
    z[6,0,4]  R664      1.1141499131917953e-01
    z[6,0,4]  R665      -7.0524394512176514e-02
    z[6,0,4]  R666      8.8269263505935669e-02
    z[6,0,4]  R667      4.1587015986442566e-01
    z[6,0,4]  R668      4.0703928470611572e-01
    z[6,0,4]  R669      -2.1439389884471893e-01
    z[6,0,4]  R670      -2.3072990775108337e-01
    z[6,0,4]  R671      2.6333945989608765e-01
    z[6,0,4]  R672      2.4770571291446686e-01
    z[6,0,4]  R673      2.1385875344276428e-01
    z[6,0,4]  R674      6.0413964092731476e-02
    z[6,0,4]  R675      -2.5798571109771729e-01
    z[6,0,4]  R676      -1.1370173841714859e-01
    z[6,0,4]  R677      0.359660267829895
    z[6,0,4]  R678      5.8230042457580566e-02
    z[6,0,4]  R679      1.2516547739505768e-01
    z[6,0,4]  R680      -3.8943123072385788e-02
    z[6,0,4]  R681      -5.8395609259605408e-02
    z[6,0,4]  R682      0.284589558839798
    z[6,0,4]  R683      -3.4502550959587097e-01
    z[6,0,4]  R684      -6.8094119429588318e-02
    z[6,0,4]  R685      -7.7331632375717163e-02
    z[6,0,4]  R686      2.8215774893760681e-01
    z[6,0,4]  R687      1.0871417075395584e-01
    z[6,0,4]  R688      -1.9560030195862055e-03
    z[6,0,4]  R689      -1.1534772813320160e-01
    z[6,0,4]  R690      1.9251872599124908e-01
    z[6,0,4]  R691      0.0800652801990509
    z[6,0,4]  R692      1.9722582772374153e-02
    z[6,0,4]  R693      5.0033140927553177e-02
    z[6,0,4]  R694      -2.4309885501861572e-01
    z[6,0,4]  R695      9.8878055810928345e-02
    z[6,0,4]  R696      5.3946918249130249e-01
    z[6,0,4]  R697      1.6274869441986084e-01
    z[6,0,4]  R698      -4.7675538808107376e-03
    z[6,0,5]  R7        1
    z[6,0,5]  R61       -1
    z[6,0,5]  R565      -1
    z[6,0,5]  R566      1
    z[6,0,5]  R569      -1.0714598465710878e-03
    z[6,0,5]  R570      -3.8282147049903870e-01
    z[6,0,5]  R571      -1.4236196875572205e-01
    z[6,0,5]  R572      -3.1125918030738831e-01
    z[6,0,5]  R573      1.1419694125652313e-01
    z[6,0,5]  R574      -2.9830756783485413e-01
    z[6,0,5]  R575      6.5622150897979736e-02
    z[6,0,5]  R576      -3.1495410948991776e-02
    z[6,0,5]  R577      1.6625548899173737e-01
    z[6,0,5]  R578      0.00990427378565073
    z[6,0,5]  R579      -4.4501629471778870e-01
    z[6,0,5]  R580      -0.575872540473938
    z[6,0,5]  R581      -1.5416010282933712e-02
    z[6,0,5]  R582      -6.1678472906351089e-02
    z[6,0,5]  R583      -2.0075160264968872e-01
    z[6,0,5]  R584      -3.1188848614692688e-01
    z[6,0,5]  R585      -2.4093411862850189e-02
    z[6,0,5]  R586      -0.0340031236410141
    z[6,0,5]  R587      -2.8606840968132019e-01
    z[6,0,5]  R588      1.5666624903678894e-01
    z[6,0,5]  R589      1.9608432427048683e-02
    z[6,0,5]  R590      1.4477960765361786e-01
    z[6,0,5]  R591      -5.5478483438491821e-01
    z[6,0,5]  R592      8.9255966246128082e-02
    z[6,0,5]  R593      4.4888880848884583e-01
    z[6,0,5]  R594      -5.8699328452348709e-02
    z[6,0,5]  R595      -3.1769070029258728e-01
    z[6,0,5]  R596      5.2408918738365173e-02
    z[6,0,5]  R597      -4.2835228145122528e-02
    z[6,0,5]  R598      -2.4383455514907837e-01
    z[6,0,5]  R599      -2.2099788486957550e-01
    z[6,0,5]  R600      -1.8712574243545532e-01
    z[6,0,5]  R601      -3.2201047986745834e-02
    z[6,0,5]  R602      -3.7080207467079163e-01
    z[6,0,5]  R603      -4.9428188800811768e-01
    z[6,0,5]  R604      1.7356021702289581e-01
    z[6,0,5]  R605      -1.0440428741276264e-02
    z[6,0,5]  R606      1.2030643969774246e-01
    z[6,0,5]  R607      -0.459465891122818
    z[6,0,5]  R608      -2.4612739682197571e-01
    z[6,0,5]  R609      -5.3476333618164062e-01
    z[6,0,5]  R610      -2.6849892735481262e-01
    z[6,0,5]  R611      6.7392992973327637e-01
    z[6,0,5]  R612      4.2553851008415222e-01
    z[6,0,5]  R613      -6.3333910703659058e-01
    z[6,0,5]  R614      1.9187904894351959e-01
    z[6,0,5]  R615      -0.0735400915145874
    z[6,0,5]  R616      5.2827745676040649e-01
    z[6,0,5]  R617      0.305154412984848
    z[6,0,5]  R618      -1.9441099464893341e-01
    z[6,0,5]  R619      3.0759319663047791e-01
    z[6,0,5]  R620      -1.1642579920589924e-02
    z[6,0,5]  R621      2.8545862436294556e-01
    z[6,0,5]  R622      5.5168390274047852e-01
    z[6,0,5]  R623      -2.1335309743881226e-01
    z[6,0,5]  R624      4.4023346900939941e-01
    z[6,0,5]  R625      -2.2197972238063812e-01
    z[6,0,5]  R626      -1.5570557117462158e-01
    z[6,0,5]  R627      -3.9092016220092773e-01
    z[6,0,5]  R628      -2.8752014040946960e-01
    z[6,0,5]  R629      -2.1267127990722656e-01
    z[6,0,5]  R630      3.0411267280578613e-01
    z[6,0,5]  R631      -1.5266118943691254e-01
    z[6,0,5]  R632      -0.0618041455745697
    z[6,0,5]  R633      -5.9121972322463989e-01
    z[6,0,5]  R634      -1.7312206327915192e-01
    z[6,0,5]  R635      2.2901852428913116e-01
    z[6,0,5]  R636      5.8368885517120361e-01
    z[6,0,5]  R637      2.1584718488156796e-03
    z[6,0,5]  R638      2.1394230425357819e-01
    z[6,0,5]  R639      1.9684407114982605e-01
    z[6,0,5]  R640      2.1400873363018036e-01
    z[6,0,5]  R641      1.7545576393604279e-01
    z[6,0,5]  R642      -8.3863191306591034e-02
    z[6,0,5]  R643      3.5342969000339508e-02
    z[6,0,5]  R644      -2.2698865830898285e-01
    z[6,0,5]  R645      3.7799999117851257e-01
    z[6,0,5]  R646      -7.9122260212898254e-03
    z[6,0,5]  R647      2.4082399904727936e-01
    z[6,0,5]  R648      1.1017414927482605e-01
    z[6,0,5]  R649      3.6226198077201843e-01
    z[6,0,5]  R650      3.0144955962896347e-02
    z[6,0,5]  R651      1.4294551312923431e-01
    z[6,0,5]  R652      1.7544165253639221e-01
    z[6,0,5]  R653      2.3372095823287964e-01
    z[6,0,5]  R654      4.1231876611709595e-01
    z[6,0,5]  R655      3.9987576007843018e-01
    z[6,0,5]  R656      4.1314443945884705e-01
    z[6,0,5]  R657      3.3306348323822021e-01
    z[6,0,5]  R658      1.6043521463871002e-01
    z[6,0,5]  R659      -5.6281950324773788e-02
    z[6,0,5]  R660      -3.6464065313339233e-01
    z[6,0,5]  R661      -3.4621521830558777e-01
    z[6,0,5]  R662      -4.0698921680450439e-01
    z[6,0,5]  R663      -4.0686112642288208e-01
    z[6,0,5]  R664      -2.8368967771530151e-01
    z[6,0,5]  R665      -1.4950375258922577e-01
    z[6,0,5]  R666      -2.9358950257301331e-01
    z[6,0,5]  R667      9.5859030261635780e-03
    z[6,0,5]  R668      -3.9522635936737061e-01
    z[6,0,5]  R669      -1.6145195066928864e-01
    z[6,0,5]  R670      -1.9120676815509796e-01
    z[6,0,5]  R671      -1.1766610294580460e-01
    z[6,0,5]  R672      -2.3118594661355019e-02
    z[6,0,5]  R673      -8.8029861450195312e-02
    z[6,0,5]  R674      -1.0294277220964432e-01
    z[6,0,5]  R675      -3.1823366880416870e-01
    z[6,0,5]  R676      -2.9804265499114990e-01
    z[6,0,5]  R677      -3.8015264272689819e-01
    z[6,0,5]  R678      -5.3212952613830566e-01
    z[6,0,5]  R679      -1.7609718441963196e-01
    z[6,0,5]  R680      -2.2707961499691010e-01
    z[6,0,5]  R681      -2.2068646550178528e-01
    z[6,0,5]  R682      -3.7052431702613831e-01
    z[6,0,5]  R683      1.1809995397925377e-02
    z[6,0,5]  R684      -1.8104976415634155e-01
    z[6,0,5]  R685      1.3202938437461853e-01
    z[6,0,5]  R686      -9.1548189520835876e-03
    z[6,0,5]  R687      -8.9364543557167053e-02
    z[6,0,5]  R688      4.1444590687751770e-01
    z[6,0,5]  R689      7.5835309922695160e-02
    z[6,0,5]  R690      7.5173109769821167e-02
    z[6,0,5]  R691      -1.4381489157676697e-01
    z[6,0,5]  R692      -2.3718622326850891e-01
    z[6,0,5]  R693      -3.9254122972488403e-01
    z[6,0,5]  R694      -6.2953993678092957e-02
    z[6,0,5]  R695      -5.6849384307861328e-01
    z[6,0,5]  R696      3.0457329750061035e-01
    z[6,0,5]  R697      4.8995118588209152e-02
    z[6,0,5]  R698      2.5946235656738281e-01
    z[6,0,6]  R8        1
    z[6,0,6]  R62       -1
    z[6,0,6]  R567      -1
    z[6,0,6]  R568      1
    z[6,0,6]  R569      -2.8217405080795288e-02
    z[6,0,6]  R570      -7.3660515248775482e-02
    z[6,0,6]  R571      -2.2573101520538330e-01
    z[6,0,6]  R572      3.0683785676956177e-01
    z[6,0,6]  R573      1.6246375441551208e-01
    z[6,0,6]  R574      2.1661767363548279e-01
    z[6,0,6]  R575      -5.1557719707489014e-01
    z[6,0,6]  R576      -4.6372652053833008e-01
    z[6,0,6]  R577      -1.0916743427515030e-01
    z[6,0,6]  R578      4.3695256114006042e-01
    z[6,0,6]  R579      4.4274058938026428e-01
    z[6,0,6]  R580      -7.9112062230706215e-03
    z[6,0,6]  R581      0.0438268817961216
    z[6,0,6]  R582      5.0233691930770874e-01
    z[6,0,6]  R583      3.0756852030754089e-01
    z[6,0,6]  R584      1.9096605479717255e-01
    z[6,0,6]  R585      8.3462363481521606e-01
    z[6,0,6]  R586      1.9705511629581451e-01
    z[6,0,6]  R587      7.8390344977378845e-02
    z[6,0,6]  R588      2.4253916740417480e-01
    z[6,0,6]  R589      -5.0089037418365479e-01
    z[6,0,6]  R590      -2.4915599822998047e-01
    z[6,0,6]  R591      -3.9576271176338196e-01
    z[6,0,6]  R592      -1.2277390062808990e-01
    z[6,0,6]  R593      3.1337331980466843e-02
    z[6,0,6]  R594      -2.1065460518002510e-02
    z[6,0,6]  R595      3.6656796932220459e-01
    z[6,0,6]  R596      3.2568693161010742e-01
    z[6,0,6]  R597      4.7090139985084534e-01
    z[6,0,6]  R598      1.5700249373912811e-01
    z[6,0,6]  R599      -0.0878305733203888
    z[6,0,6]  R600      4.8587873578071594e-01
    z[6,0,6]  R601      5.8731693029403687e-01
    z[6,0,6]  R602      -2.1546836197376251e-01
    z[6,0,6]  R603      -2.1871086210012436e-02
    z[6,0,6]  R604      3.4978860616683960e-01
    z[6,0,6]  R605      5.5898851156234741e-01
    z[6,0,6]  R606      -2.8701499104499817e-01
    z[6,0,6]  R607      1.9895464181900024e-01
    z[6,0,6]  R608      1.1828528344631195e-01
    z[6,0,6]  R609      -4.5216059684753418e-01
    z[6,0,6]  R610      2.8219836950302124e-01
    z[6,0,6]  R611      1.9805730879306793e-01
    z[6,0,6]  R612      2.1068581938743591e-01
    z[6,0,6]  R613      0.0917283371090889
    z[6,0,6]  R614      2.5312221050262451e-01
    z[6,0,6]  R615      -1.7761354148387909e-01
    z[6,0,6]  R616      -1.3293136656284332e-01
    z[6,0,6]  R617      7.4083633720874786e-02
    z[6,0,6]  R618      2.7343901991844177e-01
    z[6,0,6]  R619      3.5546016693115234e-01
    z[6,0,6]  R620      -2.9101896286010742e-01
    z[6,0,6]  R621      4.9817708134651184e-01
    z[6,0,6]  R622      0.06556436419487
    z[6,0,6]  R623      3.8490161299705505e-01
    z[6,0,6]  R624      1.9157165288925171e-01
    z[6,0,6]  R625      -3.5419678688049316e-01
    z[6,0,6]  R626      -3.3462695777416229e-02
    z[6,0,6]  R627      -1.1815723776817322e-01
    z[6,0,6]  R628      -1.7494225502014160e-01
    z[6,0,6]  R629      2.5070744752883911e-01
    z[6,0,6]  R630      4.1331019997596741e-01
    z[6,0,6]  R631      -1.5894058346748352e-01
    z[6,0,6]  R632      5.6092691421508789e-01
    z[6,0,6]  R633      1.3178764283657074e-01
    z[6,0,6]  R634      -5.2704453468322754e-02
    z[6,0,6]  R635      1.6040150821208954e-01
    z[6,0,6]  R636      -1.0079844295978546e-01
    z[6,0,6]  R637      3.0619084835052490e-01
    z[6,0,6]  R638      5.2435255050659180e-01
    z[6,0,6]  R639      -2.3867608606815338e-01
    z[6,0,6]  R640      -2.8994879126548767e-01
    z[6,0,6]  R641      2.2076773643493652e-01
    z[6,0,6]  R642      -3.2592701911926270e-01
    z[6,0,6]  R643      -3.1702980399131775e-02
    z[6,0,6]  R644      1.8523052334785461e-01
    z[6,0,6]  R645      1.6725838184356689e-01
    z[6,0,6]  R646      8.6627446115016937e-02
    z[6,0,6]  R647      2.2655488550662994e-01
    z[6,0,6]  R648      2.8011319041252136e-01
    z[6,0,6]  R649      0.245841383934021
    z[6,0,6]  R650      0.097848080098629
    z[6,0,6]  R651      -1.8725836277008057e-01
    z[6,0,6]  R652      -2.1693013608455658e-02
    z[6,0,6]  R653      3.1365182995796204e-01
    z[6,0,6]  R654      1.1375698447227478e-01
    z[6,0,6]  R655      9.7162231802940369e-02
    z[6,0,6]  R656      -1.0808359831571579e-01
    z[6,0,6]  R657      -6.4100623130798340e-02
    z[6,0,6]  R658      1.3626888394355774e-01
    z[6,0,6]  R659      -1.7072747647762299e-01
    z[6,0,6]  R660      -3.0899396166205406e-02
    z[6,0,6]  R661      -4.1400483250617981e-01
    z[6,0,6]  R662      -8.5938654839992523e-02
    z[6,0,6]  R663      -1.3139389455318451e-01
    z[6,0,6]  R664      -1.9289404153823853e-01
    z[6,0,6]  R665      2.1805499494075775e-01
    z[6,0,6]  R666      -3.6004860885441303e-03
    z[6,0,6]  R667      -1.7021040618419647e-01
    z[6,0,6]  R668      -8.1121474504470825e-03
    z[6,0,6]  R669      -8.0257803201675415e-02
    z[6,0,6]  R670      0.00755949504673481
    z[6,0,6]  R671      -9.6115969121456146e-02
    z[6,0,6]  R672      -9.2945620417594910e-02
    z[6,0,6]  R673      2.6474019885063171e-01
    z[6,0,6]  R674      -4.0284439921379089e-01
    z[6,0,6]  R675      6.5613955259323120e-02
    z[6,0,6]  R676      4.5896759629249573e-01
    z[6,0,6]  R677      -1.4630749821662903e-01
    z[6,0,6]  R678      -2.8226310014724731e-01
    z[6,0,6]  R679      -0.154501274228096
    z[6,0,6]  R680      2.2523556649684906e-01
    z[6,0,6]  R681      3.8888379931449890e-01
    z[6,0,6]  R682      -3.0032485723495483e-01
    z[6,0,6]  R683      3.7741836905479431e-01
    z[6,0,6]  R684      -3.9454710483551025e-01
    z[6,0,6]  R685      1.6951330006122589e-01
    z[6,0,6]  R686      -1.9711382687091827e-01
    z[6,0,6]  R687      -3.0246462672948837e-02
    z[6,0,6]  R688      -1.7947243154048920e-01
    z[6,0,6]  R689      -2.1330793201923370e-01
    z[6,0,6]  R690      -2.7563467621803284e-01
    z[6,0,6]  R691      -3.2324469089508057e-01
    z[6,0,6]  R692      6.4031504094600677e-02
    z[6,0,6]  R693      -1.0182687640190125e-01
    z[6,0,6]  R694      -8.6366616189479828e-02
    z[6,0,6]  R695      2.0609053969383240e-01
    z[6,0,6]  R696      7.7185044065117836e-03
    z[6,0,6]  R697      3.2198838889598846e-02
    z[6,0,6]  R698      0.0327945351600647
    z[1,2,0]  R11       -1
    z[1,2,0]  R20       1
    z[1,2,0]  R773      -1
    z[1,2,0]  R774      1
    z[1,2,0]  R787      -2.4888327717781067e-01
    z[1,2,0]  R788      2.9550388455390930e-01
    z[1,2,0]  R789      8.3232897520065308e-01
    z[1,2,0]  R790      -1.4328254759311676e-01
    z[1,2,0]  R791      6.8893134593963623e-01
    z[1,2,0]  R792      6.3776654005050659e-01
    z[1,2,0]  R793      6.7820006608963013e-01
    z[1,2,0]  R794      2.3337113857269287e-01
    z[1,2,0]  R795      6.2497007846832275e-01
    z[1,2,0]  R796      2.1322837099432945e-02
    z[1,2,0]  R797      -4.1167397052049637e-02
    z[1,2,0]  R798      0.197298064827919
    z[1,2,0]  R799      7.4670299887657166e-02
    z[1,2,0]  R800      -3.1563094258308411e-01
    z[1,2,0]  R801      2.6661109924316406e-01
    z[1,2,0]  R802      -3.2656931877136230e-01
    z[1,2,0]  R803      9.9142841994762421e-02
    z[1,2,0]  R804      -1.1139763146638870e-01
    z[1,2,0]  R805      -0.272646963596344
    z[1,2,0]  R806      -8.6569702625274658e-01
    z[1,2,0]  R807      5.5740630626678467e-01
    z[1,2,0]  R808      3.8298237323760986e-01
    z[1,2,0]  R809      5.6362771987915039e-01
    z[1,2,0]  R810      -1.5003240108489990e-01
    z[1,2,0]  R811      3.6029480397701263e-02
    z[1,2,0]  R812      5.7309955358505249e-01
    z[1,2,0]  R813      2.9047846794128418e-01
    z[1,2,0]  R814      -4.2058023810386658e-01
    z[1,2,0]  R815      1.9371148943901062e-01
    z[1,2,0]  R816      1.0605355352163315e-01
    z[1,2,0]  R817      -4.2197060585021973e-01
    z[1,2,0]  R818      3.2461223006248474e-01
    z[1,2,0]  R819      -3.6581054329872131e-02
    z[1,2,0]  R820      -6.8960803747177124e-01
    z[1,2,0]  R821      4.0713912248611450e-01
    z[1,2,0]  R822      4.5497044920921326e-01
    z[1,2,0]  R823      1.2219832837581635e-01
    z[1,2,0]  R824      3.0583182349801064e-02
    z[1,2,0]  R825      5.2356415987014771e-01
    z[1,2,0]  R826      -2.0894527435302734e-01
    z[1,2,0]  R827      -3.1633329391479492e-01
    z[1,2,0]  R828      5.6508135795593262e-01
    z[1,2,0]  R829      4.9432608485221863e-01
    z[1,2,0]  R830      -2.7010399103164673e-01
    z[1,2,0]  R831      4.9844551086425781e-01
    z[1,2,0]  R832      7.7687317132949829e-01
    z[1,2,0]  R833      4.5036911964416504e-01
    z[1,2,0]  R834      1.1800721287727356e-01
    z[1,2,0]  R835      7.1246273815631866e-02
    z[1,2,0]  R836      -5.7230882346630096e-02
    z[1,2,0]  R837      5.3158521652221680e-01
    z[1,2,0]  R838      6.1826932430267334e-01
    z[1,2,0]  R839      0.55652916431427
    z[1,2,0]  R840      -1.5125067532062531e-01
    z[1,2,0]  R841      -2.2938007116317749e-01
    z[1,2,0]  R842      4.9938037991523743e-02
    z[1,2,0]  R843      3.5751166939735413e-01
    z[1,2,0]  R844      -8.9586025476455688e-01
    z[1,2,0]  R845      -8.6483961343765259e-01
    z[1,2,0]  R846      -1.9328846037387848e-01
    z[1,2,0]  R847      8.0055320262908936e-01
    z[1,2,0]  R848      5.7469260692596436e-01
    z[1,2,0]  R849      4.0401884913444519e-01
    z[1,2,0]  R850      6.0170054435729980e-01
    z[1,2,0]  R851      5.9632128477096558e-01
    z[1,2,0]  R852      4.4133958220481873e-01
    z[1,2,0]  R853      1.0224746540188789e-02
    z[1,2,0]  R854      1.9180500507354736e-01
    z[1,2,0]  R855      -1.4825040102005005e-01
    z[1,2,0]  R856      -8.7072724103927612e-01
    z[1,2,0]  R857      7.7404584735631943e-03
    z[1,2,0]  R858      2.9487663507461548e-01
    z[1,2,0]  R859      5.8443647623062134e-01
    z[1,2,0]  R860      5.4683828353881836e-01
    z[1,2,0]  R861      2.2184620797634125e-01
    z[1,2,0]  R862      -2.4688437581062317e-01
    z[1,2,0]  R863      -3.2373899221420288e-01
    z[1,2,0]  R864      -3.7914934754371643e-01
    z[1,2,0]  R865      -4.8320788145065308e-01
    z[1,2,0]  R866      -3.3936527371406555e-01
    z[1,2,0]  R867      -2.8650021553039551e-01
    z[1,2,0]  R868      5.4303503036499023e-01
    z[1,2,0]  R869      -8.1450039148330688e-01
    z[1,2,0]  R870      -1.3905651867389679e-01
    z[1,2,0]  R871      -4.7093746066093445e-01
    z[1,2,0]  R872      -2.9865953326225281e-01
    z[1,2,0]  R873      -3.7797302007675171e-01
    z[1,2,0]  R874      -8.5167139768600464e-01
    z[1,2,0]  R875      -2.7430984377861023e-01
    z[1,2,0]  R876      -3.3804914355278015e-01
    z[1,2,0]  R877      -2.1391913294792175e-01
    z[1,2,0]  R878      -2.6369300484657288e-01
    z[1,2,0]  R879      -2.0321425795555115e-01
    z[1,2,0]  R880      -1.2211536616086960e-01
    z[1,2,0]  R881      -2.1548202633857727e-01
    z[1,2,0]  R882      -5.0030261278152466e-01
    z[1,2,0]  R883      -0.0824422836303711
    z[1,2,0]  R884      -6.5397894382476807e-01
    z[1,2,0]  R885      4.9234387278556824e-01
    z[1,2,0]  R886      1.8694119155406952e-01
    z[1,2,0]  R887      1.5439975261688232e-01
    z[1,2,0]  R888      1.5032652020454407e-01
    z[1,2,0]  R889      4.4251907616853714e-02
    z[1,2,0]  R890      -1.5841630101203918e-01
    z[1,2,0]  R891      -9.2788815498352051e-02
    z[1,2,0]  R892      -1.2571211159229279e-01
    z[1,2,0]  R893      -2.2419813275337219e-01
    z[1,2,0]  R894      2.2780667245388031e-01
    z[1,2,0]  R895      -3.2894098758697510e-01
    z[1,2,0]  R896      -2.4866597354412079e-01
    z[1,2,0]  R897      5.2616402506828308e-02
    z[1,2,0]  R898      2.7954089641571045e-01
    z[1,2,0]  R899      6.4820271730422974e-01
    z[1,2,0]  R900      -1.4740100130438805e-02
    z[1,2,0]  R901      -4.6165034174919128e-02
    z[1,2,0]  R902      7.8379977494478226e-03
    z[1,2,0]  R903      6.3006269931793213e-01
    z[1,2,0]  R904      1.4017288386821747e-01
    z[1,2,0]  R905      -2.4023541808128357e-01
    z[1,2,0]  R906      -3.9358308911323547e-01
    z[1,2,0]  R907      -1.4701075851917267e-01
    z[1,2,0]  R908      4.1678366065025330e-01
    z[1,2,0]  R909      -1.3015897572040558e-01
    z[1,2,0]  R910      6.1288721859455109e-02
    z[1,2,0]  R911      -1.8016344308853149e-01
    z[1,2,0]  R912      2.5706410408020020e-01
    z[1,2,0]  R913      1.9248086214065552e-01
    z[1,2,0]  R914      5.2797567844390869e-01
    z[1,2,0]  R915      -6.0768104158341885e-03
    z[1,2,0]  R916      -1.8545801937580109e-01
    z[1,2,0]  R917      3.7204214930534363e-01
    z[1,2,0]  R918      3.1403880566358566e-02
    z[1,2,0]  R919      4.0567180514335632e-01
    z[1,2,0]  R920      2.0946851000189781e-03
    z[1,2,0]  R921      -1.9522626698017120e-01
    z[1,2,0]  R922      1.6009330749511719e-01
    z[1,2,0]  R923      5.6637412309646606e-01
    z[1,2,0]  R924      1.4716935157775879e-01
    z[1,2,0]  R925      2.0530971884727478e-01
    z[1,2,0]  R926      2.2877733409404755e-01
    z[1,2,1]  R12       -1
    z[1,2,1]  R21       1
    z[1,2,1]  R775      -1
    z[1,2,1]  R776      1
    z[1,2,1]  R787      2.4882024526596069e-01
    z[1,2,1]  R788      2.6027470827102661e-01
    z[1,2,1]  R789      -4.2193830013275146e-01
    z[1,2,1]  R790      0.357695609331131
    z[1,2,1]  R791      -3.3583068847656250e-01
    z[1,2,1]  R792      -3.4383061528205872e-01
    z[1,2,1]  R793      -1.9444961845874786e-01
    z[1,2,1]  R794      1.3967826031148434e-02
    z[1,2,1]  R795      -3.1188753247261047e-01
    z[1,2,1]  R796      2.2355954349040985e-01
    z[1,2,1]  R797      0.705487847328186
    z[1,2,1]  R798      8.1740945577621460e-01
    z[1,2,1]  R799      8.3081430196762085e-01
    z[1,2,1]  R800      2.1704234182834625e-02
    z[1,2,1]  R801      -1.3921430706977844e-01
    z[1,2,1]  R802      6.7283344268798828e-01
    z[1,2,1]  R803      -1.8174204230308533e-01
    z[1,2,1]  R804      -1.8991971015930176e-01
    z[1,2,1]  R805      -4.8471625894308090e-02
    z[1,2,1]  R806      2.9968783259391785e-01
    z[1,2,1]  R807      -9.8242938518524170e-02
    z[1,2,1]  R808      5.8050528168678284e-03
    z[1,2,1]  R809      -3.5034117102622986e-01
    z[1,2,1]  R810      -1.2987117469310760e-01
    z[1,2,1]  R811      1.1567724496126175e-01
    z[1,2,1]  R812      1.6094347462058067e-02
    z[1,2,1]  R813      -1.6576437279582024e-02
    z[1,2,1]  R814      -2.4119272828102112e-02
    z[1,2,1]  R815      1.4139761030673981e-01
    z[1,2,1]  R816      2.7130430936813354e-01
    z[1,2,1]  R817      1.3013286888599396e-01
    z[1,2,1]  R818      3.7456490099430084e-02
    z[1,2,1]  R819      1.4031082391738892e-01
    z[1,2,1]  R820      6.1334484815597534e-01
    z[1,2,1]  R821      -2.7111306786537170e-01
    z[1,2,1]  R822      -1.4592204988002777e-01
    z[1,2,1]  R823      3.8224789313971996e-03
    z[1,2,1]  R824      -1.3744835555553436e-01
    z[1,2,1]  R825      1.4315118081867695e-02
    z[1,2,1]  R826      4.2679074406623840e-01
    z[1,2,1]  R827      2.2771829366683960e-01
    z[1,2,1]  R828      -1.6862352192401886e-01
    z[1,2,1]  R829      -1.5798328816890717e-01
    z[1,2,1]  R830      7.6394850015640259e-01
    z[1,2,1]  R831      -1.6039286553859711e-01
    z[1,2,1]  R832      -2.6861509680747986e-01
    z[1,2,1]  R833      -8.6294472217559814e-02
    z[1,2,1]  R834      -2.0825612545013428e-01
    z[1,2,1]  R835      -4.2793910950422287e-02
    z[1,2,1]  R836      1.2584343552589417e-02
    z[1,2,1]  R837      -1.5589401125907898e-01
    z[1,2,1]  R838      -1.0465943068265915e-01
    z[1,2,1]  R839      -2.6423647999763489e-01
    z[1,2,1]  R840      5.7704836130142212e-02
    z[1,2,1]  R841      1.0573582351207733e-01
    z[1,2,1]  R842      -9.8005570471286774e-02
    z[1,2,1]  R843      1.0065460205078125e-01
    z[1,2,1]  R844      2.9242733120918274e-01
    z[1,2,1]  R845      2.2574819624423981e-01
    z[1,2,1]  R846      -7.5025148689746857e-02
    z[1,2,1]  R847      -1.9033451378345490e-01
    z[1,2,1]  R848      -3.3282455801963806e-01
    z[1,2,1]  R849      6.4190918207168579e-01
    z[1,2,1]  R850      -2.4728335440158844e-01
    z[1,2,1]  R851      -2.0644631981849670e-01
    z[1,2,1]  R852      -2.3136278986930847e-01
    z[1,2,1]  R853      -8.6752094328403473e-02
    z[1,2,1]  R854      1.9959920644760132e-01
    z[1,2,1]  R855      3.5830289125442505e-02
    z[1,2,1]  R856      2.3080386221408844e-01
    z[1,2,1]  R857      2.6614561676979065e-01
    z[1,2,1]  R858      1.9011251628398895e-01
    z[1,2,1]  R859      -3.3396637439727783e-01
    z[1,2,1]  R860      -5.5149450898170471e-02
    z[1,2,1]  R861      2.3891791701316833e-01
    z[1,2,1]  R862      2.1255789697170258e-01
    z[1,2,1]  R863      2.9950019717216492e-01
    z[1,2,1]  R864      2.9912093281745911e-01
    z[1,2,1]  R865      -0.189732626080513
    z[1,2,1]  R866      -3.0053177475929260e-01
    z[1,2,1]  R867      1.2896591797471046e-02
    z[1,2,1]  R868      -0.0914396345615387
    z[1,2,1]  R869      1.4442013204097748e-01
    z[1,2,1]  R870      -2.7446159720420837e-01
    z[1,2,1]  R871      1.1482341587543488e-01
    z[1,2,1]  R872      -1.2507946230471134e-02
    z[1,2,1]  R873      2.3167058825492859e-01
    z[1,2,1]  R874      7.7691055834293365e-02
    z[1,2,1]  R875      1.3147634267807007e-01
    z[1,2,1]  R876      -7.9999083280563354e-01
    z[1,2,1]  R877      3.6962968111038208e-01
    z[1,2,1]  R878      -2.2585336863994598e-01
    z[1,2,1]  R879      -6.3878291845321655e-01
    z[1,2,1]  R880      -0.637885332107544
    z[1,2,1]  R881      -6.2792015075683594e-01
    z[1,2,1]  R882      -2.5551816448569298e-02
    z[1,2,1]  R883      -5.1065891981124878e-01
    z[1,2,1]  R884      -1.5931475162506104e-01
    z[1,2,1]  R885      3.9877825975418091e-01
    z[1,2,1]  R886      -3.3519566059112549e-01
    z[1,2,1]  R887      7.4821001291275024e-01
    z[1,2,1]  R888      6.2233549356460571e-01
    z[1,2,1]  R889      7.0716559886932373e-01
    z[1,2,1]  R890      3.4581381082534790e-01
    z[1,2,1]  R891      6.0509526729583740e-01
    z[1,2,1]  R892      4.4489392638206482e-01
    z[1,2,1]  R893      3.5442498326301575e-01
    z[1,2,1]  R894      7.3422580957412720e-01
    z[1,2,1]  R895      2.3457735776901245e-01
    z[1,2,1]  R896      -9.4344671815633774e-03
    z[1,2,1]  R897      -2.1630187332630157e-01
    z[1,2,1]  R898      2.5966829061508179e-01
    z[1,2,1]  R899      -8.5281684994697571e-02
    z[1,2,1]  R900      -3.4813082218170166e-01
    z[1,2,1]  R901      1.0931760072708130e-01
    z[1,2,1]  R902      1.7637154459953308e-01
    z[1,2,1]  R903      2.9924153932370245e-04
    z[1,2,1]  R904      -1.2882173061370850e-01
    z[1,2,1]  R905      -8.5850799083709717e-01
    z[1,2,1]  R906      -7.5027018785476685e-01
    z[1,2,1]  R907      4.6310821175575256e-01
    z[1,2,1]  R908      -2.0021395385265350e-01
    z[1,2,1]  R909      4.8950418829917908e-01
    z[1,2,1]  R910      9.9311359226703644e-02
    z[1,2,1]  R911      1.8918801844120026e-01
    z[1,2,1]  R912      3.7089128047227859e-02
    z[1,2,1]  R913      1.0083258152008057e-01
    z[1,2,1]  R914      3.7639137357473373e-02
    z[1,2,1]  R915      -2.0759311318397522e-01
    z[1,2,1]  R916      -9.5413953065872192e-02
    z[1,2,1]  R917      7.0166522264480591e-01
    z[1,2,1]  R918      -3.6928680539131165e-01
    z[1,2,1]  R919      3.2252028584480286e-01
    z[1,2,1]  R920      8.6657595634460449e-01
    z[1,2,1]  R921      0.43874591588974
    z[1,2,1]  R922      0.78117436170578
    z[1,2,1]  R923      5.4525947570800781e-01
    z[1,2,1]  R924      1.4030268788337708e-01
    z[1,2,1]  R925      -2.6873552799224854e-01
    z[1,2,1]  R926      -4.1345305740833282e-02
    z[1,2,2]  R13       -1
    z[1,2,2]  R22       1
    z[1,2,2]  R777      -1
    z[1,2,2]  R778      1
    z[1,2,2]  R787      -1.3974243402481079e-01
    z[1,2,2]  R788      -1.0791204869747162e-01
    z[1,2,2]  R789      -1.3351014256477356e-01
    z[1,2,2]  R790      -1.4141140878200531e-01
    z[1,2,2]  R791      3.7054324150085449e-01
    z[1,2,2]  R792      0.481171190738678
    z[1,2,2]  R793      4.4943156838417053e-01
    z[1,2,2]  R794      6.2327116727828979e-01
    z[1,2,2]  R795      8.0959469079971313e-02
    z[1,2,2]  R796      0.0745064914226532
    z[1,2,2]  R797      -5.1401269435882568e-01
    z[1,2,2]  R798      -4.1547033190727234e-01
    z[1,2,2]  R799      -4.5047828555107117e-01
    z[1,2,2]  R800      -6.2747198343276978e-01
    z[1,2,2]  R801      -4.7564360499382019e-01
    z[1,2,2]  R802      3.9179524779319763e-01
    z[1,2,2]  R803      4.8451694846153259e-01
    z[1,2,2]  R804      -8.9959733188152313e-02
    z[1,2,2]  R805      1.5008051693439484e-01
    z[1,2,2]  R806      2.6233983039855957e-01
    z[1,2,2]  R807      -6.8765640258789062e-01
    z[1,2,2]  R808      -0.522006094455719
    z[1,2,2]  R809      2.1208065748214722e-01
    z[1,2,2]  R810      -4.6540012955665588e-01
    z[1,2,2]  R811      -4.6059334278106689e-01
    z[1,2,2]  R812      -0.485392302274704
    z[1,2,2]  R813      -7.0152807235717773e-01
    z[1,2,2]  R814      -0.0619235597550869
    z[1,2,2]  R815      1.6759210824966431e-01
    z[1,2,2]  R816      0.0671146884560585
    z[1,2,2]  R817      -6.9854712486267090e-01
    z[1,2,2]  R818      -0.712831974029541
    z[1,2,2]  R819      -8.8186144828796387e-01
    z[1,2,2]  R820      -2.0456868410110474e-01
    z[1,2,2]  R821      -8.0457948148250580e-02
    z[1,2,2]  R822      6.7947648465633392e-02
    z[1,2,2]  R823      1.7455644905567169e-01
    z[1,2,2]  R824      -2.1403209865093231e-01
    z[1,2,2]  R825      1.9011916220188141e-01
    z[1,2,2]  R826      3.9396515488624573e-01
    z[1,2,2]  R827      -6.0739632695913315e-02
    z[1,2,2]  R828      -1.7637857794761658e-01
    z[1,2,2]  R829      -0.0888201892375946
    z[1,2,2]  R830      2.8243938088417053e-01
    z[1,2,2]  R831      -3.3264991641044617e-01
    z[1,2,2]  R832      0.207072451710701
    z[1,2,2]  R833      0.0663580447435379
    z[1,2,2]  R834      -5.1376353949308395e-02
    z[1,2,2]  R835      -1.8423390388488770e-01
    z[1,2,2]  R836      6.5412461757659912e-02
    z[1,2,2]  R837      5.2865464240312576e-02
    z[1,2,2]  R838      -2.3262429982423782e-02
    z[1,2,2]  R839      0.0476471409201622
    z[1,2,2]  R840      -7.3751728050410748e-03
    z[1,2,2]  R841      1.7571914196014404e-01
    z[1,2,2]  R842      4.0155026316642761e-01
    z[1,2,2]  R843      0.446807324886322
    z[1,2,2]  R844      -1.3759591616690159e-02
    z[1,2,2]  R845      2.1937979757785797e-01
    z[1,2,2]  R846      2.4245730042457581e-01
    z[1,2,2]  R847      3.4914985299110413e-01
    z[1,2,2]  R848      4.2426955699920654e-01
    z[1,2,2]  R849      1.7419147491455078e-01
    z[1,2,2]  R850      1.3603346049785614e-01
    z[1,2,2]  R851      2.2313900291919708e-01
    z[1,2,2]  R852      -3.4275189042091370e-01
    z[1,2,2]  R853      -2.7045145630836487e-01
    z[1,2,2]  R854      3.9838257431983948e-01
    z[1,2,2]  R855      1.9918428361415863e-01
    z[1,2,2]  R856      1.8702767789363861e-01
    z[1,2,2]  R857      -2.1489652991294861e-01
    z[1,2,2]  R858      -5.1691156625747681e-01
    z[1,2,2]  R859      1.2027036398649216e-01
    z[1,2,2]  R860      -5.3264591842889786e-02
    z[1,2,2]  R861      0.0594746358692646
    z[1,2,2]  R862      4.1544923186302185e-01
    z[1,2,2]  R863      3.5326632857322693e-01
    z[1,2,2]  R864      1.8077576160430908e-01
    z[1,2,2]  R865      5.1298856735229492e-01
    z[1,2,2]  R866      4.4338029623031616e-01
    z[1,2,2]  R867      -4.2498657107353210e-01
    z[1,2,2]  R868      -2.2581714391708374e-01
    z[1,2,2]  R869      0.324491411447525
    z[1,2,2]  R870      4.4395741820335388e-01
    z[1,2,2]  R871      4.9326434731483459e-01
    z[1,2,2]  R872      3.2187905907630920e-01
    z[1,2,2]  R873      4.0216556191444397e-01
    z[1,2,2]  R874      2.0421876013278961e-01
    z[1,2,2]  R875      7.1265482902526855e-01
    z[1,2,2]  R876      1.3422681391239166e-01
    z[1,2,2]  R877      -1.7148266732692719e-01
    z[1,2,2]  R878      8.2171314954757690e-01
    z[1,2,2]  R879      0.659396231174469
    z[1,2,2]  R880      2.9673033952713013e-01
    z[1,2,2]  R881      4.8074802756309509e-01
    z[1,2,2]  R882      8.3655959367752075e-01
    z[1,2,2]  R883      6.2870103120803833e-01
    z[1,2,2]  R884      4.0047213435173035e-01
    z[1,2,2]  R885      -5.6966669857501984e-02
    z[1,2,2]  R886      7.4343693256378174e-01
    z[1,2,2]  R887      -4.4365558028221130e-01
    z[1,2,2]  R888      -5.0853508710861206e-01
    z[1,2,2]  R889      -5.2227860689163208e-01
    z[1,2,2]  R890      -8.5057616233825684e-01
    z[1,2,2]  R891      -5.3677064180374146e-01
    z[1,2,2]  R892      -7.6897680759429932e-01
    z[1,2,2]  R893      -7.4780440330505371e-01
    z[1,2,2]  R894      -2.5453430414199829e-01
    z[1,2,2]  R895      3.2538837194442749e-01
    z[1,2,2]  R896      1.6030944883823395e-01
    z[1,2,2]  R897      0.250957727432251
    z[1,2,2]  R898      2.2730448842048645e-01
    z[1,2,2]  R899      -2.0786218345165253e-01
    z[1,2,2]  R900      7.3982700705528259e-02
    z[1,2,2]  R901      -1.1089028790593147e-02
    z[1,2,2]  R902      -2.5956982374191284e-01
    z[1,2,2]  R903      2.1277728676795959e-01
    z[1,2,2]  R904      4.4958975911140442e-01
    z[1,2,2]  R905      -6.7659132182598114e-02
    z[1,2,2]  R906      -2.0726792514324188e-01
    z[1,2,2]  R907      -0.559663712978363
    z[1,2,2]  R908      -5.7365173101425171e-01
    z[1,2,2]  R909      -8.0755275487899780e-01
    z[1,2,2]  R910      -5.2722561359405518e-01
    z[1,2,2]  R911      -4.7982862591743469e-01
    z[1,2,2]  R912      -0.598857045173645
    z[1,2,2]  R913      0.886725664138794
    z[1,2,2]  R914      -7.9085886478424072e-01
    z[1,2,2]  R915      1.1493320018053055e-01
    z[1,2,2]  R916      -5.6808573007583618e-01
    z[1,2,2]  R917      -1.2841895222663879e-01
    z[1,2,2]  R918      2.0998318493366241e-01
    z[1,2,2]  R919      -4.9523675441741943e-01
    z[1,2,2]  R920      -0.351829469203949
    z[1,2,2]  R921      -5.7935726642608643e-01
    z[1,2,2]  R922      -1.5869230031967163e-01
    z[1,2,2]  R923      -1.7285600304603577e-01
    z[1,2,2]  R924      3.6849480867385864e-01
    z[1,2,2]  R925      4.0468290448188782e-01
    z[1,2,2]  R926      3.7011903524398804e-01
    z[1,2,3]  R14       -1
    z[1,2,3]  R23       1
    z[1,2,3]  R779      -1
    z[1,2,3]  R780      1
    z[1,2,3]  R787      4.2786693572998047e-01
    z[1,2,3]  R788      5.6138175725936890e-01
    z[1,2,3]  R789      -2.1517328917980194e-02
    z[1,2,3]  R790      6.8580663204193115e-01
    z[1,2,3]  R791      -3.8698457647114992e-03
    z[1,2,3]  R792      3.2861644029617310e-01
    z[1,2,3]  R793      -1.2012303620576859e-01
    z[1,2,3]  R794      5.5567485094070435e-01
    z[1,2,3]  R795      -1.2867744266986847e-01
    z[1,2,3]  R796      -5.6563433259725571e-02
    z[1,2,3]  R797      -9.4751402735710144e-02
    z[1,2,3]  R798      -3.3500720746815205e-03
    z[1,2,3]  R799      -2.4091796576976776e-01
    z[1,2,3]  R800      5.9733642265200615e-03
    z[1,2,3]  R801      -6.5414440631866455e-01
    z[1,2,3]  R802      2.4336710572242737e-01
    z[1,2,3]  R803      -4.4006025791168213e-01
    z[1,2,3]  R804      -4.2608228325843811e-01
    z[1,2,3]  R805      -7.2649914026260376e-01
    z[1,2,3]  R806      -1.6354420781135559e-01
    z[1,2,3]  R807      6.0123833827674389e-03
    z[1,2,3]  R808      6.9074296951293945e-01
    z[1,2,3]  R809      -1.8271112442016602e-01
    z[1,2,3]  R810      -2.5598838925361633e-02
    z[1,2,3]  R811      -4.3165674805641174e-01
    z[1,2,3]  R812      4.8092268407344818e-02
    z[1,2,3]  R813      -2.3779571056365967e-01
    z[1,2,3]  R814      -6.3250350952148438e-01
    z[1,2,3]  R815      2.6156967878341675e-01
    z[1,2,3]  R816      -8.4441676735877991e-02
    z[1,2,3]  R817      4.3929345905780792e-02
    z[1,2,3]  R818      2.3876060545444489e-01
    z[1,2,3]  R819      3.4031070768833160e-02
    z[1,2,3]  R820      1.9250829517841339e-01
    z[1,2,3]  R821      5.1246255636215210e-01
    z[1,2,3]  R822      -6.0873252153396606e-01
    z[1,2,3]  R823      -9.0511363744735718e-01
    z[1,2,3]  R824      -7.3025971651077271e-01
    z[1,2,3]  R825      -5.0211775302886963e-01
    z[1,2,3]  R826      -5.5745714902877808e-01
    z[1,2,3]  R827      5.2649700641632080e-01
    z[1,2,3]  R828      1.9932985305786133e-01
    z[1,2,3]  R829      7.8748238086700439e-01
    z[1,2,3]  R830      4.3566811084747314e-01
    z[1,2,3]  R831      -8.1966057419776917e-02
    z[1,2,3]  R832      5.2357977628707886e-01
    z[1,2,3]  R833      1.8273739516735077e-01
    z[1,2,3]  R834      -2.8898784518241882e-01
    z[1,2,3]  R835      -5.8250063657760620e-01
    z[1,2,3]  R836      -8.3422678709030151e-01
    z[1,2,3]  R837      5.9759140014648438e-01
    z[1,2,3]  R838      -5.3690886497497559e-01
    z[1,2,3]  R839      6.7187029123306274e-01
    z[1,2,3]  R840      -9.2615431547164917e-01
    z[1,2,3]  R841      -5.2048432826995850e-01
    z[1,2,3]  R842      -4.4863912463188171e-01
    z[1,2,3]  R843      -7.5512075424194336e-01
    z[1,2,3]  R844      -9.8633371293544769e-02
    z[1,2,3]  R845      1.2380762398242950e-01
    z[1,2,3]  R846      -7.0751684904098511e-01
    z[1,2,3]  R847      -3.8104152679443359e-01
    z[1,2,3]  R848      3.2583260536193848e-01
    z[1,2,3]  R849      5.6155413389205933e-01
    z[1,2,3]  R850      -1.7436213791370392e-01
    z[1,2,3]  R851      -5.1284188032150269e-01
    z[1,2,3]  R852      2.0295481383800507e-01
    z[1,2,3]  R853      -8.3560156822204590e-01
    z[1,2,3]  R854      -4.8282131552696228e-01
    z[1,2,3]  R855      -0.545455276966095
    z[1,2,3]  R856      -0.336578905582428
    z[1,2,3]  R857      5.5588185787200928e-01
    z[1,2,3]  R858      7.5425481796264648e-01
    z[1,2,3]  R859      4.5786008238792419e-01
    z[1,2,3]  R860      3.0420255661010742e-01
    z[1,2,3]  R861      0.0747174620628357
    z[1,2,3]  R862      -0.641779899597168
    z[1,2,3]  R863      -6.8036824464797974e-01
    z[1,2,3]  R864      -6.4183020591735840e-01
    z[1,2,3]  R865      -6.0219085216522217e-01
    z[1,2,3]  R866      -5.9417766332626343e-01
    z[1,2,3]  R867      6.6427206993103027e-01
    z[1,2,3]  R868      2.7343866229057312e-01
    z[1,2,3]  R869      4.0755501389503479e-01
    z[1,2,3]  R870      2.5693568587303162e-01
    z[1,2,3]  R871      -0.682981014251709
    z[1,2,3]  R872      -6.3763946294784546e-01
    z[1,2,3]  R873      -6.9238191843032837e-01
    z[1,2,3]  R874      1.2699677050113678e-01
    z[1,2,3]  R875      -5.9325700998306274e-01
    z[1,2,3]  R876      3.0823636054992676e-01
    z[1,2,3]  R877      4.5843076705932617e-01
    z[1,2,3]  R878      -3.1058143824338913e-02
    z[1,2,3]  R879      2.8784537315368652e-01
    z[1,2,3]  R880      6.5112829208374023e-01
    z[1,2,3]  R881      5.1474034786224365e-01
    z[1,2,3]  R882      -1.1923284828662872e-01
    z[1,2,3]  R883      4.3017926812171936e-01
    z[1,2,3]  R884      -2.0549426972866058e-01
    z[1,2,3]  R885      -5.2066117525100708e-02
    z[1,2,3]  R886      5.0769889354705811e-01
    z[1,2,3]  R887      1.1674515157938004e-01
    z[1,2,3]  R888      3.5537999868392944e-01
    z[1,2,3]  R889      -5.1625583320856094e-02
    z[1,2,3]  R890      6.0137853026390076e-02
    z[1,2,3]  R891      -0.157786563038826
    z[1,2,3]  R892      -1.7026992142200470e-01
    z[1,2,3]  R893      -1.0650216601788998e-02
    z[1,2,3]  R894      6.5115690231323242e-02
    z[1,2,3]  R895      1.1661132425069809e-01
    z[1,2,3]  R896      -7.1028995513916016e-01
    z[1,2,3]  R897      2.7433764189481735e-03
    z[1,2,3]  R898      -6.7830830812454224e-01
    z[1,2,3]  R899      2.4954505264759064e-01
    z[1,2,3]  R900      -4.4995075464248657e-01
    z[1,2,3]  R901      -6.2988221645355225e-01
    z[1,2,3]  R902      -2.2799676656723022e-01
    z[1,2,3]  R903      4.4768846035003662e-01
    z[1,2,3]  R904      -6.1550658941268921e-01
    z[1,2,3]  R905      -3.3372217416763306e-01
    z[1,2,3]  R906      -4.2903545498847961e-01
    z[1,2,3]  R907      3.1411767005920410e-01
    z[1,2,3]  R908      1.0412068665027618e-01
    z[1,2,3]  R909      1.8298628926277161e-01
    z[1,2,3]  R910      5.0356507301330566e-01
    z[1,2,3]  R911      6.1112821102142334e-01
    z[1,2,3]  R912      2.8271466493606567e-01
    z[1,2,3]  R913      -2.6987859606742859e-01
    z[1,2,3]  R914      1.9051222503185272e-01
    z[1,2,3]  R915      -2.8663340210914612e-01
    z[1,2,3]  R916      -1.5051684342324734e-02
    z[1,2,3]  R917      2.8195375204086304e-01
    z[1,2,3]  R918      -3.0767318606376648e-01
    z[1,2,3]  R919      -3.2623484730720520e-01
    z[1,2,3]  R920      -2.9760724306106567e-01
    z[1,2,3]  R921      4.8644068837165833e-01
    z[1,2,3]  R922      1.4212132990360260e-01
    z[1,2,3]  R923      -1.8289128318428993e-02
    z[1,2,3]  R924      6.3790738582611084e-01
    z[1,2,3]  R925      7.4694973230361938e-01
    z[1,2,3]  R926      5.3082180023193359e-01
    z[1,2,4]  R15       -1
    z[1,2,4]  R24       1
    z[1,2,4]  R781      -1
    z[1,2,4]  R782      1
    z[1,2,4]  R787      -1.1247880756855011e-01
    z[1,2,4]  R788      2.2592009976506233e-02
    z[1,2,4]  R789      -0.00748852826654911
    z[1,2,4]  R790      3.2927727699279785e-01
    z[1,2,4]  R791      1.2413238175213337e-02
    z[1,2,4]  R792      0.106113001704216
    z[1,2,4]  R793      5.0413364171981812e-01
    z[1,2,4]  R794      4.1448852419853210e-01
    z[1,2,4]  R795      6.7392474412918091e-01
    z[1,2,4]  R796      9.4905763864517212e-02
    z[1,2,4]  R797      -3.9633101224899292e-01
    z[1,2,4]  R798      9.5441611483693123e-03
    z[1,2,4]  R799      1.9344888627529144e-01
    z[1,2,4]  R800      -5.0751698017120361e-01
    z[1,2,4]  R801      -4.6170118451118469e-01
    z[1,2,4]  R802      -2.2196891903877258e-01
    z[1,2,4]  R803      -3.5769772529602051e-01
    z[1,2,4]  R804      -3.0726441740989685e-01
    z[1,2,4]  R805      -4.0538829565048218e-01
    z[1,2,4]  R806      2.3168230056762695e-01
    z[1,2,4]  R807      -3.4652435779571533e-01
    z[1,2,4]  R808      -1.8786557018756866e-01
    z[1,2,4]  R809      -6.7668128013610840e-01
    z[1,2,4]  R810      -8.4895169734954834e-01
    z[1,2,4]  R811      -2.6113060116767883e-01
    z[1,2,4]  R812      1.1247245222330093e-01
    z[1,2,4]  R813      -1.2196033447980881e-01
    z[1,2,4]  R814      -5.4073190689086914e-01
    z[1,2,4]  R815      7.0605689287185669e-01
    z[1,2,4]  R816      9.4362515211105347e-01
    z[1,2,4]  R817      -2.0223446190357208e-01
    z[1,2,4]  R818      3.1554073095321655e-01
    z[1,2,4]  R819      3.3984726667404175e-01
    z[1,2,4]  R820      2.1140135824680328e-01
    z[1,2,4]  R821      -1.7125698924064636e-01
    z[1,2,4]  R822      -0.0864894762635231
    z[1,2,4]  R823      -1.9900390878319740e-02
    z[1,2,4]  R824      -2.2850982844829559e-01
    z[1,2,4]  R825      -2.0756879448890686e-01
    z[1,2,4]  R826      -1.8477097153663635e-01
    z[1,2,4]  R827      -6.6944587230682373e-01
    z[1,2,4]  R828      1.9878487288951874e-01
    z[1,2,4]  R829      2.5809904932975769e-01
    z[1,2,4]  R830      -1.8200004100799561e-01
    z[1,2,4]  R831      -1.8569459021091461e-01
    z[1,2,4]  R832      7.6844438910484314e-02
    z[1,2,4]  R833      6.8372821807861328e-01
    z[1,2,4]  R834      -5.6160074472427368e-01
    z[1,2,4]  R835      -4.6660301089286804e-01
    z[1,2,4]  R836      -3.5465580224990845e-01
    z[1,2,4]  R837      -1.1367820203304291e-01
    z[1,2,4]  R838      -1.2245580554008484e-01
    z[1,2,4]  R839      1.8623976409435272e-01
    z[1,2,4]  R840      -1.2363362312316895e-01
    z[1,2,4]  R841      -0.319595068693161
    z[1,2,4]  R842      -3.0021873116493225e-01
    z[1,2,4]  R843      -1.8565380573272705e-01
    z[1,2,4]  R844      -3.3730342984199524e-02
    z[1,2,4]  R845      -8.9219413697719574e-02
    z[1,2,4]  R846      5.2021449804306030e-01
    z[1,2,4]  R847      1.5052796900272369e-01
    z[1,2,4]  R848      -4.8418673872947693e-01
    z[1,2,4]  R849      -1.1262041516602039e-02
    z[1,2,4]  R850      4.5991101861000061e-01
    z[1,2,4]  R851      4.5816510915756226e-02
    z[1,2,4]  R852      -0.678889811038971
    z[1,2,4]  R853      -3.2943999767303467e-01
    z[1,2,4]  R854      -0.4470234811306
    z[1,2,4]  R855      -7.9936087131500244e-01
    z[1,2,4]  R856      -2.0046986639499664e-01
    z[1,2,4]  R857      -5.5702561140060425e-01
    z[1,2,4]  R858      -3.3359881490468979e-02
    z[1,2,4]  R859      -5.0087904930114746e-01
    z[1,2,4]  R860      7.2544181346893311e-01
    z[1,2,4]  R861      8.0137783288955688e-01
    z[1,2,4]  R862      3.9924103021621704e-01
    z[1,2,4]  R863      4.4599962234497070e-01
    z[1,2,4]  R864      5.6706315279006958e-01
    z[1,2,4]  R865      2.8938525915145874e-01
    z[1,2,4]  R866      2.6491126418113708e-01
    z[1,2,4]  R867      -3.9084357023239136e-01
    z[1,2,4]  R868      -2.1561355888843536e-01
    z[1,2,4]  R869      -6.1471585184335709e-02
    z[1,2,4]  R870      4.0813198685646057e-01
    z[1,2,4]  R871      1.0320943593978882e-01
    z[1,2,4]  R872      5.1756995916366577e-01
    z[1,2,4]  R873      0.363953173160553
    z[1,2,4]  R874      -2.6761695742607117e-01
    z[1,2,4]  R875      -7.7543191611766815e-02
    z[1,2,4]  R876      3.5110303759574890e-01
    z[1,2,4]  R877      -7.8915923833847046e-02
    z[1,2,4]  R878      0.428545743227005
    z[1,2,4]  R879      4.0092658251523972e-02
    z[1,2,4]  R880      2.3380656540393829e-01
    z[1,2,4]  R881      6.9126054644584656e-02
    z[1,2,4]  R882      1.3722635805606842e-02
    z[1,2,4]  R883      -4.2954348027706146e-02
    z[1,2,4]  R884      6.9148249924182892e-02
    z[1,2,4]  R885      7.5694270431995392e-02
    z[1,2,4]  R886      1.7689904570579529e-01
    z[1,2,4]  R887      -2.0937469601631165e-01
    z[1,2,4]  R888      1.7088751494884491e-01
    z[1,2,4]  R889      2.6169770956039429e-01
    z[1,2,4]  R890      1.4486806094646454e-01
    z[1,2,4]  R891      -2.8544503450393677e-01
    z[1,2,4]  R892      -1.3903099298477173e-01
    z[1,2,4]  R893      -3.1329038739204407e-01
    z[1,2,4]  R894      5.2991223335266113e-01
    z[1,2,4]  R895      -1.5408030152320862e-01
    z[1,2,4]  R896      -3.4385478496551514e-01
    z[1,2,4]  R897      0.374213308095932
    z[1,2,4]  R898      4.6642562747001648e-01
    z[1,2,4]  R899      -6.1091583967208862e-01
    z[1,2,4]  R900      -6.4970010519027710e-01
    z[1,2,4]  R901      -7.3790538311004639e-01
    z[1,2,4]  R902      -7.9327005147933960e-01
    z[1,2,4]  R903      5.8784413337707520e-01
    z[1,2,4]  R904      -5.4279690980911255e-01
    z[1,2,4]  R905      -1.8567000329494476e-01
    z[1,2,4]  R906      0.0546242892742157
    z[1,2,4]  R907      2.1512266248464584e-02
    z[1,2,4]  R908      -5.9000805020332336e-02
    z[1,2,4]  R909      -9.3802623450756073e-02
    z[1,2,4]  R910      -5.2126395702362061e-01
    z[1,2,4]  R911      -5.5842298269271851e-01
    z[1,2,4]  R912      3.6576637625694275e-01
    z[1,2,4]  R913      -5.5177640169858932e-02
    z[1,2,4]  R914      -1.4764183759689331e-01
    z[1,2,4]  R915      1.4394259080290794e-02
    z[1,2,4]  R916      -6.8140465021133423e-01
    z[1,2,4]  R917      -4.2736735939979553e-01
    z[1,2,4]  R918      7.8438544273376465e-01
    z[1,2,4]  R919      -3.9450488984584808e-02
    z[1,2,4]  R920      -2.9868612065911293e-02
    z[1,2,4]  R921      -1.2888021767139435e-01
    z[1,2,4]  R922      1.3152818381786346e-01
    z[1,2,4]  R923      2.6210722327232361e-01
    z[1,2,4]  R924      5.1603776216506958e-01
    z[1,2,4]  R925      3.6167123913764954e-01
    z[1,2,4]  R926      5.5798208713531494e-01
    z[1,2,5]  R16       -1
    z[1,2,5]  R25       1
    z[1,2,5]  R783      -1
    z[1,2,5]  R784      1
    z[1,2,5]  R787      -5.9924560785293579e-01
    z[1,2,5]  R788      -6.7017114162445068e-01
    z[1,2,5]  R789      -1.7075255513191223e-01
    z[1,2,5]  R790      -3.4536325931549072e-01
    z[1,2,5]  R791      -4.1791123151779175e-01
    z[1,2,5]  R792      -1.6387729346752167e-01
    z[1,2,5]  R793      -2.5673899799585342e-02
    z[1,2,5]  R794      -2.7564057707786560e-01
    z[1,2,5]  R795      1.8572375178337097e-01
    z[1,2,5]  R796      -9.6274352073669434e-01
    z[1,2,5]  R797      2.6516011357307434e-01
    z[1,2,5]  R798      3.3366104960441589e-01
    z[1,2,5]  R799      7.6006367802619934e-02
    z[1,2,5]  R800      -2.2798164281994104e-03
    z[1,2,5]  R801      1.8446385860443115e-01
    z[1,2,5]  R802      4.1964945197105408e-01
    z[1,2,5]  R803      6.3277292251586914e-01
    z[1,2,5]  R804      6.8420600891113281e-01
    z[1,2,5]  R805      4.3545350432395935e-01
    z[1,2,5]  R806      0.063116155564785
    z[1,2,5]  R807      -1.3539710640907288e-01
    z[1,2,5]  R808      1.9015109539031982e-01
    z[1,2,5]  R809      -3.3738423138856888e-02
    z[1,2,5]  R810      -1.1009259521961212e-01
    z[1,2,5]  R811      -6.6776549816131592e-01
    z[1,2,5]  R812      -2.7803018689155579e-01
    z[1,2,5]  R813      -5.8783525228500366e-01
    z[1,2,5]  R814      3.4181165695190430e-01
    z[1,2,5]  R815      3.4685772657394409e-01
    z[1,2,5]  R816      -1.1427142471075058e-01
    z[1,2,5]  R817      -5.1246547698974609e-01
    z[1,2,5]  R818      -4.7744181752204895e-01
    z[1,2,5]  R819      -2.8765550255775452e-01
    z[1,2,5]  R820      7.3895724490284920e-03
    z[1,2,5]  R821      6.5908366441726685e-01
    z[1,2,5]  R822      2.7482289075851440e-01
    z[1,2,5]  R823      3.5857841372489929e-01
    z[1,2,5]  R824      2.5697714090347290e-01
    z[1,2,5]  R825      6.2740236520767212e-01
    z[1,2,5]  R826      5.1673984527587891e-01
    z[1,2,5]  R827      -5.4225660860538483e-02
    z[1,2,5]  R828      6.7273318767547607e-01
    z[1,2,5]  R829      -1.2929636240005493e-01
    z[1,2,5]  R830      1.8573950231075287e-01
    z[1,2,5]  R831      2.3989351093769073e-01
    z[1,2,5]  R832      2.4207981303334236e-02
    z[1,2,5]  R833      6.8009041249752045e-02
    z[1,2,5]  R834      0.700463056564331
    z[1,2,5]  R835      3.8692724704742432e-01
    z[1,2,5]  R836      3.0215749144554138e-01
    z[1,2,5]  R837      -5.6540167331695557e-01
    z[1,2,5]  R838      2.5111094117164612e-01
    z[1,2,5]  R839      1.6509608924388885e-01
    z[1,2,5]  R840      3.1623688340187073e-01
    z[1,2,5]  R841      5.9986698627471924e-01
    z[1,2,5]  R842      6.2607699632644653e-01
    z[1,2,5]  R843      1.8678721785545349e-01
    z[1,2,5]  R844      1.6764141619205475e-01
    z[1,2,5]  R845      2.6683539152145386e-01
    z[1,2,5]  R846      5.9409722685813904e-02
    z[1,2,5]  R847      -6.5568573772907257e-02
    z[1,2,5]  R848      1.6529381275177002e-01
    z[1,2,5]  R849      -6.3907362520694733e-02
    z[1,2,5]  R850      -0.189733624458313
    z[1,2,5]  R851      1.4546598494052887e-01
    z[1,2,5]  R852      -2.4480000138282776e-01
    z[1,2,5]  R853      2.4261584877967834e-01
    z[1,2,5]  R854      5.1766520738601685e-01
    z[1,2,5]  R855      -2.2911494597792625e-02
    z[1,2,5]  R856      -1.3159135123714805e-03
    z[1,2,5]  R857      -4.8959231376647949e-01
    z[1,2,5]  R858      1.2369251251220703e-01
    z[1,2,5]  R859      1.8714118003845215e-01
    z[1,2,5]  R860      0.262578547000885
    z[1,2,5]  R861      -8.0211512744426727e-02
    z[1,2,5]  R862      -3.1390699744224548e-01
    z[1,2,5]  R863      -5.3827010095119476e-02
    z[1,2,5]  R864      2.3970412090420723e-02
    z[1,2,5]  R865      7.8765578567981720e-02
    z[1,2,5]  R866      -3.7683773040771484e-01
    z[1,2,5]  R867      -0.0905112773180008
    z[1,2,5]  R868      -6.7866414785385132e-01
    z[1,2,5]  R869      -1.1712118051946163e-02
    z[1,2,5]  R870      6.3943368196487427e-01
    z[1,2,5]  R871      -1.3582212850451469e-02
    z[1,2,5]  R872      2.7645006775856018e-01
    z[1,2,5]  R873      -1.7054859548807144e-02
    z[1,2,5]  R874      2.4767701327800751e-01
    z[1,2,5]  R875      7.2591237723827362e-02
    z[1,2,5]  R876      9.5383025705814362e-02
    z[1,2,5]  R877      -7.5600284337997437e-01
    z[1,2,5]  R878      2.0925825461745262e-02
    z[1,2,5]  R879      -1.7519956827163696e-01
    z[1,2,5]  R880      -8.5107326507568359e-02
    z[1,2,5]  R881      -0.129975363612175
    z[1,2,5]  R882      -1.1450179852545261e-02
    z[1,2,5]  R883      -1.1037198454141617e-01
    z[1,2,5]  R884      -2.7068577706813812e-02
    z[1,2,5]  R885      -7.5989085435867310e-01
    z[1,2,5]  R886      -3.5837404429912567e-02
    z[1,2,5]  R887      3.9327001571655273e-01
    z[1,2,5]  R888      4.1641193628311157e-01
    z[1,2,5]  R889      2.6392295956611633e-01
    z[1,2,5]  R890      3.1351518630981445e-01
    z[1,2,5]  R891      2.3337078094482422e-01
    z[1,2,5]  R892      1.4271828532218933e-01
    z[1,2,5]  R893      2.5921770930290222e-01
    z[1,2,5]  R894      7.6674565672874451e-02
    z[1,2,5]  R895      6.4962792396545410e-01
    z[1,2,5]  R896      1.5710996091365814e-01
    z[1,2,5]  R897      5.7025891542434692e-01
    z[1,2,5]  R898      3.2565575838088989e-01
    z[1,2,5]  R899      -1.7744678258895874e-01
    z[1,2,5]  R900      4.8563620448112488e-01
    z[1,2,5]  R901      4.1208315640687943e-02
    z[1,2,5]  R902      4.6365055441856384e-01
    z[1,2,5]  R903      0.0964667871594429
    z[1,2,5]  R904      2.7510568499565125e-01
    z[1,2,5]  R905      1.1066298931837082e-01
    z[1,2,5]  R906      -1.0694700479507446e-01
    z[1,2,5]  R907      -3.7286561727523804e-01
    z[1,2,5]  R908      -6.1039716005325317e-01
    z[1,2,5]  R909      1.7148524522781372e-01
    z[1,2,5]  R910      -8.9085720479488373e-02
    z[1,2,5]  R911      6.5611422061920166e-02
    z[1,2,5]  R912      -4.1812869906425476e-01
    z[1,2,5]  R913      0.286979079246521
    z[1,2,5]  R914      -1.7271885275840759e-01
    z[1,2,5]  R915      8.1810927391052246e-01
    z[1,2,5]  R916      -3.4268322587013245e-01
    z[1,2,5]  R917      -2.9487481713294983e-01
    z[1,2,5]  R918      3.1709179282188416e-01
    z[1,2,5]  R919      -6.1188173294067383e-01
    z[1,2,5]  R920      -1.8844248354434967e-01
    z[1,2,5]  R921      -2.4835785850882530e-02
    z[1,2,5]  R922      1.9847498834133148e-01
    z[1,2,5]  R923      -4.3695300817489624e-01
    z[1,2,5]  R924      -3.2630094885826111e-01
    z[1,2,5]  R925      -1.2975083291530609e-01
    z[1,2,5]  R926      -2.3591253161430359e-01
    z[1,2,6]  R17       -1
    z[1,2,6]  R26       1
    z[1,2,6]  R785      -1
    z[1,2,6]  R786      1
    z[1,2,6]  R787      5.4936385154724121e-01
    z[1,2,6]  R788      -2.6172572374343872e-01
    z[1,2,6]  R789      -0.285825252532959
    z[1,2,6]  R790      -3.6537206172943115e-01
    z[1,2,6]  R791      -3.1697034835815430e-01
    z[1,2,6]  R792      3.1209623813629150e-01
    z[1,2,6]  R793      -1.7608475685119629e-01
    z[1,2,6]  R794      -1.7964359372854233e-02
    z[1,2,6]  R795      1.8934594467282295e-02
    z[1,2,6]  R796      7.0240586996078491e-02
    z[1,2,6]  R797      -4.1481410153210163e-03
    z[1,2,6]  R798      9.4167903065681458e-02
    z[1,2,6]  R799      -5.0156249199062586e-04
    z[1,2,6]  R800      -4.9856850504875183e-01
    z[1,2,6]  R801      9.0561136603355408e-02
    z[1,2,6]  R802      5.0405509769916534e-02
    z[1,2,6]  R803      -1.9536618143320084e-02
    z[1,2,6]  R804      -4.4646725058555603e-01
    z[1,2,6]  R805      -1.3794755935668945e-01
    z[1,2,6]  R806      -8.6756169795989990e-02
    z[1,2,6]  R807      2.6139521598815918e-01
    z[1,2,6]  R808      1.7950955033302307e-01
    z[1,2,6]  R809      -1.4895421266555786e-01
    z[1,2,6]  R810      1.0262466222047806e-01
    z[1,2,6]  R811      2.6971647143363953e-01
    z[1,2,6]  R812      5.8602774143218994e-01
    z[1,2,6]  R813      -0.0789579525589943
    z[1,2,6]  R814      -9.7000725567340851e-02
    z[1,2,6]  R815      4.7660249471664429e-01
    z[1,2,6]  R816      -5.0564175471663475e-03
    z[1,2,6]  R817      -1.0765118151903152e-01
    z[1,2,6]  R818      -2.3900514468550682e-02
    z[1,2,6]  R819      -4.3533239513635635e-02
    z[1,2,6]  R820      -1.5683084726333618e-01
    z[1,2,6]  R821      1.6710405051708221e-01
    z[1,2,6]  R822      0.559935986995697
    z[1,2,6]  R823      7.9860344529151917e-02
    z[1,2,6]  R824      -5.3181725740432739e-01
    z[1,2,6]  R825      2.6263775303959846e-02
    z[1,2,6]  R826      -8.4048651158809662e-02
    z[1,2,6]  R827      -3.4072157740592957e-01
    z[1,2,6]  R828      2.9886773228645325e-01
    z[1,2,6]  R829      1.3904240727424622e-01
    z[1,2,6]  R830      -7.8896619379520416e-02
    z[1,2,6]  R831      0.7186239361763
    z[1,2,6]  R832      -2.8426237404346466e-02
    z[1,2,6]  R833      -5.2897542715072632e-01
    z[1,2,6]  R834      2.2473634779453278e-01
    z[1,2,6]  R835      0.502406656742096
    z[1,2,6]  R836      2.8155499696731567e-01
    z[1,2,6]  R837      2.4540470913052559e-02
    z[1,2,6]  R838      4.8982140421867371e-01
    z[1,2,6]  R839      -3.2377848029136658e-01
    z[1,2,6]  R840      2.6192527264356613e-02
    z[1,2,6]  R841      -4.1526150703430176e-01
    z[1,2,6]  R842      -3.7852057814598083e-01
    z[1,2,6]  R843      -1.5117228031158447e-01
    z[1,2,6]  R844      2.6974314451217651e-01
    z[1,2,6]  R845      2.4181246757507324e-01
    z[1,2,6]  R846      -3.5141488909721375e-01
    z[1,2,6]  R847      -1.6979727149009705e-01
    z[1,2,6]  R848      1.0500414669513702e-01
    z[1,2,6]  R849      2.7354088425636292e-01
    z[1,2,6]  R850      5.2951216697692871e-01
    z[1,2,6]  R851      5.1548373699188232e-01
    z[1,2,6]  R852      2.6870566606521606e-01
    z[1,2,6]  R853      -2.3152175545692444e-01
    z[1,2,6]  R854      2.5246503949165344e-01
    z[1,2,6]  R855      -6.2848613597452641e-03
    z[1,2,6]  R856      -1.0438323020935059e-02
    z[1,2,6]  R857      -1.5473565459251404e-01
    z[1,2,6]  R858      -1.5618702769279480e-01
    z[1,2,6]  R859      1.9208897650241852e-01
    z[1,2,6]  R860      -0.0856553316116333
    z[1,2,6]  R861      4.8573899269104004e-01
    z[1,2,6]  R862      2.2684057056903839e-01
    z[1,2,6]  R863      1.2641890347003937e-01
    z[1,2,6]  R864      -3.3749712165445089e-03
    z[1,2,6]  R865      -1.2154351174831390e-01
    z[1,2,6]  R866      0.180814728140831
    z[1,2,6]  R867      3.6732730269432068e-01
    z[1,2,6]  R868      2.5281503796577454e-01
    z[1,2,6]  R869      -2.0104783773422241e-01
    z[1,2,6]  R870      -2.5840455293655396e-01
    z[1,2,6]  R871      -2.1076993644237518e-01
    z[1,2,6]  R872      2.3696507513523102e-01
    z[1,2,6]  R873      -1.7199589312076569e-01
    z[1,2,6]  R874      -2.7896878123283386e-01
    z[1,2,6]  R875      1.9066981971263885e-01
    z[1,2,6]  R876      1.8433047458529472e-02
    z[1,2,6]  R877      1.6713712364435196e-02
    z[1,2,6]  R878      1.3852766156196594e-01
    z[1,2,6]  R879      -2.6451028883457184e-02
    z[1,2,6]  R880      6.5301500260829926e-02
    z[1,2,6]  R881      -2.0380245149135590e-01
    z[1,2,6]  R882      1.8621627986431122e-01
    z[1,2,6]  R883      3.7159714102745056e-01
    z[1,2,6]  R884      5.8207410573959351e-01
    z[1,2,6]  R885      -9.7229331731796265e-02
    z[1,2,6]  R886      9.8299160599708557e-02
    z[1,2,6]  R887      -8.5928887128829956e-02
    z[1,2,6]  R888      -5.0952263176441193e-02
    z[1,2,6]  R889      0.290477991104126
    z[1,2,6]  R890      9.4562888145446777e-02
    z[1,2,6]  R891      4.1986885666847229e-01
    z[1,2,6]  R892      -0.355317622423172
    z[1,2,6]  R893      3.1535494327545166e-01
    z[1,2,6]  R894      -2.3087418079376221e-01
    z[1,2,6]  R895      -5.2109336853027344e-01
    z[1,2,6]  R896      -5.1472866535186768e-01
    z[1,2,6]  R897      6.4978986978530884e-01
    z[1,2,6]  R898      1.3804058730602264e-01
    z[1,2,6]  R899      2.4975056946277618e-01
    z[1,2,6]  R900      1.1272017657756805e-01
    z[1,2,6]  R901      -2.0698155462741852e-01
    z[1,2,6]  R902      -7.2273783385753632e-02
    z[1,2,6]  R903      4.9550160765647888e-02
    z[1,2,6]  R904      1.1164902895689011e-01
    z[1,2,6]  R905      -2.0635692775249481e-01
    z[1,2,6]  R906      2.0182704925537109e-01
    z[1,2,6]  R907      -4.6101385354995728e-01
    z[1,2,6]  R908      2.6499542593955994e-01
    z[1,2,6]  R909      -1.4004588127136230e-01
    z[1,2,6]  R910      -4.1854989528656006e-01
    z[1,2,6]  R911      1.0906316339969635e-01
    z[1,2,6]  R912      4.3054428696632385e-01
    z[1,2,6]  R913      0.090914286673069
    z[1,2,6]  R914      -0.0802655816078186
    z[1,2,6]  R915      -4.3816640973091125e-01
    z[1,2,6]  R916      2.2761696577072144e-01
    z[1,2,6]  R917      6.0557309538125992e-02
    z[1,2,6]  R918      -8.9875146746635437e-02
    z[1,2,6]  R919      6.1374053359031677e-02
    z[1,2,6]  R920      1.6884168609976768e-02
    z[1,2,6]  R921      4.2412549257278442e-01
    z[1,2,6]  R922      5.1192098855972290e-01
    z[1,2,6]  R923      -3.0343142151832581e-01
    z[1,2,6]  R924      2.0778505504131317e-01
    z[1,2,6]  R925      -1.2761445343494415e-01
    z[1,2,6]  R926      -0.400240957736969
    z[2,1,0]  R11       1
    z[2,1,0]  R20       -1
    z[2,1,0]  R927      -1
    z[2,1,0]  R928      1
    z[2,1,0]  R941      -2.1391913294792175e-01
    z[2,1,0]  R942      -2.6369300484657288e-01
    z[2,1,0]  R943      -2.0321425795555115e-01
    z[2,1,0]  R944      -1.2211536616086960e-01
    z[2,1,0]  R945      -2.1548202633857727e-01
    z[2,1,0]  R946      -5.0030261278152466e-01
    z[2,1,0]  R947      -0.0824422836303711
    z[2,1,0]  R948      -6.5397894382476807e-01
    z[2,1,0]  R949      4.9234387278556824e-01
    z[2,1,0]  R950      1.8694119155406952e-01
    z[2,1,0]  R951      1.5439975261688232e-01
    z[2,1,0]  R952      1.5032652020454407e-01
    z[2,1,0]  R953      4.4251907616853714e-02
    z[2,1,0]  R954      -1.5841630101203918e-01
    z[2,1,0]  R955      -9.2788815498352051e-02
    z[2,1,0]  R956      -1.2571211159229279e-01
    z[2,1,0]  R957      -2.2419813275337219e-01
    z[2,1,0]  R958      2.2780667245388031e-01
    z[2,1,0]  R959      -3.2894098758697510e-01
    z[2,1,0]  R960      -2.4866597354412079e-01
    z[2,1,0]  R961      5.2616402506828308e-02
    z[2,1,0]  R962      2.7954089641571045e-01
    z[2,1,0]  R963      6.4820271730422974e-01
    z[2,1,0]  R964      -1.4740100130438805e-02
    z[2,1,0]  R965      -4.6165034174919128e-02
    z[2,1,0]  R966      7.8379977494478226e-03
    z[2,1,0]  R967      6.3006269931793213e-01
    z[2,1,0]  R968      1.4017288386821747e-01
    z[2,1,0]  R969      -2.4023541808128357e-01
    z[2,1,0]  R970      -3.9358308911323547e-01
    z[2,1,0]  R971      -1.4701075851917267e-01
    z[2,1,0]  R972      4.1678366065025330e-01
    z[2,1,0]  R973      -1.3015897572040558e-01
    z[2,1,0]  R974      6.1288721859455109e-02
    z[2,1,0]  R975      -1.8016344308853149e-01
    z[2,1,0]  R976      2.5706410408020020e-01
    z[2,1,0]  R977      1.9248086214065552e-01
    z[2,1,0]  R978      5.2797567844390869e-01
    z[2,1,0]  R979      -6.0768104158341885e-03
    z[2,1,0]  R980      -1.8545801937580109e-01
    z[2,1,0]  R981      3.7204214930534363e-01
    z[2,1,0]  R982      3.1403880566358566e-02
    z[2,1,0]  R983      4.0567180514335632e-01
    z[2,1,0]  R984      2.0946851000189781e-03
    z[2,1,0]  R985      -1.9522626698017120e-01
    z[2,1,0]  R986      1.6009330749511719e-01
    z[2,1,0]  R987      5.6637412309646606e-01
    z[2,1,0]  R988      1.4716935157775879e-01
    z[2,1,0]  R989      2.0530971884727478e-01
    z[2,1,0]  R990      2.2877733409404755e-01
    z[2,1,0]  R991      -2.4888327717781067e-01
    z[2,1,0]  R992      2.9550388455390930e-01
    z[2,1,0]  R993      8.3232897520065308e-01
    z[2,1,0]  R994      -1.4328254759311676e-01
    z[2,1,0]  R995      6.8893134593963623e-01
    z[2,1,0]  R996      6.3776654005050659e-01
    z[2,1,0]  R997      6.7820006608963013e-01
    z[2,1,0]  R998      2.3337113857269287e-01
    z[2,1,0]  R999      6.2497007846832275e-01
    z[2,1,0]  R1000     2.1322837099432945e-02
    z[2,1,0]  R1001     -4.1167397052049637e-02
    z[2,1,0]  R1002     0.197298064827919
    z[2,1,0]  R1003     7.4670299887657166e-02
    z[2,1,0]  R1004     -3.1563094258308411e-01
    z[2,1,0]  R1005     2.6661109924316406e-01
    z[2,1,0]  R1006     -3.2656931877136230e-01
    z[2,1,0]  R1007     9.9142841994762421e-02
    z[2,1,0]  R1008     -1.1139763146638870e-01
    z[2,1,0]  R1009     -0.272646963596344
    z[2,1,0]  R1010     -8.6569702625274658e-01
    z[2,1,0]  R1011     5.5740630626678467e-01
    z[2,1,0]  R1012     3.8298237323760986e-01
    z[2,1,0]  R1013     5.6362771987915039e-01
    z[2,1,0]  R1014     -1.5003240108489990e-01
    z[2,1,0]  R1015     3.6029480397701263e-02
    z[2,1,0]  R1016     5.7309955358505249e-01
    z[2,1,0]  R1017     2.9047846794128418e-01
    z[2,1,0]  R1018     -4.2058023810386658e-01
    z[2,1,0]  R1019     1.9371148943901062e-01
    z[2,1,0]  R1020     1.0605355352163315e-01
    z[2,1,0]  R1021     -4.2197060585021973e-01
    z[2,1,0]  R1022     3.2461223006248474e-01
    z[2,1,0]  R1023     -3.6581054329872131e-02
    z[2,1,0]  R1024     -6.8960803747177124e-01
    z[2,1,0]  R1025     4.0713912248611450e-01
    z[2,1,0]  R1026     4.5497044920921326e-01
    z[2,1,0]  R1027     1.2219832837581635e-01
    z[2,1,0]  R1028     3.0583182349801064e-02
    z[2,1,0]  R1029     5.2356415987014771e-01
    z[2,1,0]  R1030     -2.0894527435302734e-01
    z[2,1,0]  R1031     -3.1633329391479492e-01
    z[2,1,0]  R1032     5.6508135795593262e-01
    z[2,1,0]  R1033     4.9432608485221863e-01
    z[2,1,0]  R1034     -2.7010399103164673e-01
    z[2,1,0]  R1035     4.9844551086425781e-01
    z[2,1,0]  R1036     7.7687317132949829e-01
    z[2,1,0]  R1037     4.5036911964416504e-01
    z[2,1,0]  R1038     1.1800721287727356e-01
    z[2,1,0]  R1039     7.1246273815631866e-02
    z[2,1,0]  R1040     -5.7230882346630096e-02
    z[2,1,0]  R1041     5.3158521652221680e-01
    z[2,1,0]  R1042     6.1826932430267334e-01
    z[2,1,0]  R1043     0.55652916431427
    z[2,1,0]  R1044     -1.5125067532062531e-01
    z[2,1,0]  R1045     -2.2938007116317749e-01
    z[2,1,0]  R1046     4.9938037991523743e-02
    z[2,1,0]  R1047     3.5751166939735413e-01
    z[2,1,0]  R1048     -8.9586025476455688e-01
    z[2,1,0]  R1049     -8.6483961343765259e-01
    z[2,1,0]  R1050     -1.9328846037387848e-01
    z[2,1,0]  R1051     8.0055320262908936e-01
    z[2,1,0]  R1052     5.7469260692596436e-01
    z[2,1,0]  R1053     4.0401884913444519e-01
    z[2,1,0]  R1054     6.0170054435729980e-01
    z[2,1,0]  R1055     5.9632128477096558e-01
    z[2,1,0]  R1056     4.4133958220481873e-01
    z[2,1,0]  R1057     1.0224746540188789e-02
    z[2,1,0]  R1058     1.9180500507354736e-01
    z[2,1,0]  R1059     -1.4825040102005005e-01
    z[2,1,0]  R1060     -8.7072724103927612e-01
    z[2,1,0]  R1061     7.7404584735631943e-03
    z[2,1,0]  R1062     2.9487663507461548e-01
    z[2,1,0]  R1063     5.8443647623062134e-01
    z[2,1,0]  R1064     5.4683828353881836e-01
    z[2,1,0]  R1065     2.2184620797634125e-01
    z[2,1,0]  R1066     -2.4688437581062317e-01
    z[2,1,0]  R1067     -3.2373899221420288e-01
    z[2,1,0]  R1068     -3.7914934754371643e-01
    z[2,1,0]  R1069     -4.8320788145065308e-01
    z[2,1,0]  R1070     -3.3936527371406555e-01
    z[2,1,0]  R1071     -2.8650021553039551e-01
    z[2,1,0]  R1072     5.4303503036499023e-01
    z[2,1,0]  R1073     -8.1450039148330688e-01
    z[2,1,0]  R1074     -1.3905651867389679e-01
    z[2,1,0]  R1075     -4.7093746066093445e-01
    z[2,1,0]  R1076     -2.9865953326225281e-01
    z[2,1,0]  R1077     -3.7797302007675171e-01
    z[2,1,0]  R1078     -8.5167139768600464e-01
    z[2,1,0]  R1079     -2.7430984377861023e-01
    z[2,1,0]  R1080     -3.3804914355278015e-01
    z[2,1,1]  R12       1
    z[2,1,1]  R21       -1
    z[2,1,1]  R929      -1
    z[2,1,1]  R930      1
    z[2,1,1]  R941      3.6962968111038208e-01
    z[2,1,1]  R942      -2.2585336863994598e-01
    z[2,1,1]  R943      -6.3878291845321655e-01
    z[2,1,1]  R944      -0.637885332107544
    z[2,1,1]  R945      -6.2792015075683594e-01
    z[2,1,1]  R946      -2.5551816448569298e-02
    z[2,1,1]  R947      -5.1065891981124878e-01
    z[2,1,1]  R948      -1.5931475162506104e-01
    z[2,1,1]  R949      3.9877825975418091e-01
    z[2,1,1]  R950      -3.3519566059112549e-01
    z[2,1,1]  R951      7.4821001291275024e-01
    z[2,1,1]  R952      6.2233549356460571e-01
    z[2,1,1]  R953      7.0716559886932373e-01
    z[2,1,1]  R954      3.4581381082534790e-01
    z[2,1,1]  R955      6.0509526729583740e-01
    z[2,1,1]  R956      4.4489392638206482e-01
    z[2,1,1]  R957      3.5442498326301575e-01
    z[2,1,1]  R958      7.3422580957412720e-01
    z[2,1,1]  R959      2.3457735776901245e-01
    z[2,1,1]  R960      -9.4344671815633774e-03
    z[2,1,1]  R961      -2.1630187332630157e-01
    z[2,1,1]  R962      2.5966829061508179e-01
    z[2,1,1]  R963      -8.5281684994697571e-02
    z[2,1,1]  R964      -3.4813082218170166e-01
    z[2,1,1]  R965      1.0931760072708130e-01
    z[2,1,1]  R966      1.7637154459953308e-01
    z[2,1,1]  R967      2.9924153932370245e-04
    z[2,1,1]  R968      -1.2882173061370850e-01
    z[2,1,1]  R969      -8.5850799083709717e-01
    z[2,1,1]  R970      -7.5027018785476685e-01
    z[2,1,1]  R971      4.6310821175575256e-01
    z[2,1,1]  R972      -2.0021395385265350e-01
    z[2,1,1]  R973      4.8950418829917908e-01
    z[2,1,1]  R974      9.9311359226703644e-02
    z[2,1,1]  R975      1.8918801844120026e-01
    z[2,1,1]  R976      3.7089128047227859e-02
    z[2,1,1]  R977      1.0083258152008057e-01
    z[2,1,1]  R978      3.7639137357473373e-02
    z[2,1,1]  R979      -2.0759311318397522e-01
    z[2,1,1]  R980      -9.5413953065872192e-02
    z[2,1,1]  R981      7.0166522264480591e-01
    z[2,1,1]  R982      -3.6928680539131165e-01
    z[2,1,1]  R983      3.2252028584480286e-01
    z[2,1,1]  R984      8.6657595634460449e-01
    z[2,1,1]  R985      0.43874591588974
    z[2,1,1]  R986      0.78117436170578
    z[2,1,1]  R987      5.4525947570800781e-01
    z[2,1,1]  R988      1.4030268788337708e-01
    z[2,1,1]  R989      -2.6873552799224854e-01
    z[2,1,1]  R990      -4.1345305740833282e-02
    z[2,1,1]  R991      2.4882024526596069e-01
    z[2,1,1]  R992      2.6027470827102661e-01
    z[2,1,1]  R993      -4.2193830013275146e-01
    z[2,1,1]  R994      0.357695609331131
    z[2,1,1]  R995      -3.3583068847656250e-01
    z[2,1,1]  R996      -3.4383061528205872e-01
    z[2,1,1]  R997      -1.9444961845874786e-01
    z[2,1,1]  R998      1.3967826031148434e-02
    z[2,1,1]  R999      -3.1188753247261047e-01
    z[2,1,1]  R1000     2.2355954349040985e-01
    z[2,1,1]  R1001     0.705487847328186
    z[2,1,1]  R1002     8.1740945577621460e-01
    z[2,1,1]  R1003     8.3081430196762085e-01
    z[2,1,1]  R1004     2.1704234182834625e-02
    z[2,1,1]  R1005     -1.3921430706977844e-01
    z[2,1,1]  R1006     6.7283344268798828e-01
    z[2,1,1]  R1007     -1.8174204230308533e-01
    z[2,1,1]  R1008     -1.8991971015930176e-01
    z[2,1,1]  R1009     -4.8471625894308090e-02
    z[2,1,1]  R1010     2.9968783259391785e-01
    z[2,1,1]  R1011     -9.8242938518524170e-02
    z[2,1,1]  R1012     5.8050528168678284e-03
    z[2,1,1]  R1013     -3.5034117102622986e-01
    z[2,1,1]  R1014     -1.2987117469310760e-01
    z[2,1,1]  R1015     1.1567724496126175e-01
    z[2,1,1]  R1016     1.6094347462058067e-02
    z[2,1,1]  R1017     -1.6576437279582024e-02
    z[2,1,1]  R1018     -2.4119272828102112e-02
    z[2,1,1]  R1019     1.4139761030673981e-01
    z[2,1,1]  R1020     2.7130430936813354e-01
    z[2,1,1]  R1021     1.3013286888599396e-01
    z[2,1,1]  R1022     3.7456490099430084e-02
    z[2,1,1]  R1023     1.4031082391738892e-01
    z[2,1,1]  R1024     6.1334484815597534e-01
    z[2,1,1]  R1025     -2.7111306786537170e-01
    z[2,1,1]  R1026     -1.4592204988002777e-01
    z[2,1,1]  R1027     3.8224789313971996e-03
    z[2,1,1]  R1028     -1.3744835555553436e-01
    z[2,1,1]  R1029     1.4315118081867695e-02
    z[2,1,1]  R1030     4.2679074406623840e-01
    z[2,1,1]  R1031     2.2771829366683960e-01
    z[2,1,1]  R1032     -1.6862352192401886e-01
    z[2,1,1]  R1033     -1.5798328816890717e-01
    z[2,1,1]  R1034     7.6394850015640259e-01
    z[2,1,1]  R1035     -1.6039286553859711e-01
    z[2,1,1]  R1036     -2.6861509680747986e-01
    z[2,1,1]  R1037     -8.6294472217559814e-02
    z[2,1,1]  R1038     -2.0825612545013428e-01
    z[2,1,1]  R1039     -4.2793910950422287e-02
    z[2,1,1]  R1040     1.2584343552589417e-02
    z[2,1,1]  R1041     -1.5589401125907898e-01
    z[2,1,1]  R1042     -1.0465943068265915e-01
    z[2,1,1]  R1043     -2.6423647999763489e-01
    z[2,1,1]  R1044     5.7704836130142212e-02
    z[2,1,1]  R1045     1.0573582351207733e-01
    z[2,1,1]  R1046     -9.8005570471286774e-02
    z[2,1,1]  R1047     1.0065460205078125e-01
    z[2,1,1]  R1048     2.9242733120918274e-01
    z[2,1,1]  R1049     2.2574819624423981e-01
    z[2,1,1]  R1050     -7.5025148689746857e-02
    z[2,1,1]  R1051     -1.9033451378345490e-01
    z[2,1,1]  R1052     -3.3282455801963806e-01
    z[2,1,1]  R1053     6.4190918207168579e-01
    z[2,1,1]  R1054     -2.4728335440158844e-01
    z[2,1,1]  R1055     -2.0644631981849670e-01
    z[2,1,1]  R1056     -2.3136278986930847e-01
    z[2,1,1]  R1057     -8.6752094328403473e-02
    z[2,1,1]  R1058     1.9959920644760132e-01
    z[2,1,1]  R1059     3.5830289125442505e-02
    z[2,1,1]  R1060     2.3080386221408844e-01
    z[2,1,1]  R1061     2.6614561676979065e-01
    z[2,1,1]  R1062     1.9011251628398895e-01
    z[2,1,1]  R1063     -3.3396637439727783e-01
    z[2,1,1]  R1064     -5.5149450898170471e-02
    z[2,1,1]  R1065     2.3891791701316833e-01
    z[2,1,1]  R1066     2.1255789697170258e-01
    z[2,1,1]  R1067     2.9950019717216492e-01
    z[2,1,1]  R1068     2.9912093281745911e-01
    z[2,1,1]  R1069     -0.189732626080513
    z[2,1,1]  R1070     -3.0053177475929260e-01
    z[2,1,1]  R1071     1.2896591797471046e-02
    z[2,1,1]  R1072     -0.0914396345615387
    z[2,1,1]  R1073     1.4442013204097748e-01
    z[2,1,1]  R1074     -2.7446159720420837e-01
    z[2,1,1]  R1075     1.1482341587543488e-01
    z[2,1,1]  R1076     -1.2507946230471134e-02
    z[2,1,1]  R1077     2.3167058825492859e-01
    z[2,1,1]  R1078     7.7691055834293365e-02
    z[2,1,1]  R1079     1.3147634267807007e-01
    z[2,1,1]  R1080     -7.9999083280563354e-01
    z[2,1,2]  R13       1
    z[2,1,2]  R22       -1
    z[2,1,2]  R931      -1
    z[2,1,2]  R932      1
    z[2,1,2]  R941      -1.7148266732692719e-01
    z[2,1,2]  R942      8.2171314954757690e-01
    z[2,1,2]  R943      0.659396231174469
    z[2,1,2]  R944      2.9673033952713013e-01
    z[2,1,2]  R945      4.8074802756309509e-01
    z[2,1,2]  R946      8.3655959367752075e-01
    z[2,1,2]  R947      6.2870103120803833e-01
    z[2,1,2]  R948      4.0047213435173035e-01
    z[2,1,2]  R949      -5.6966669857501984e-02
    z[2,1,2]  R950      7.4343693256378174e-01
    z[2,1,2]  R951      -4.4365558028221130e-01
    z[2,1,2]  R952      -5.0853508710861206e-01
    z[2,1,2]  R953      -5.2227860689163208e-01
    z[2,1,2]  R954      -8.5057616233825684e-01
    z[2,1,2]  R955      -5.3677064180374146e-01
    z[2,1,2]  R956      -7.6897680759429932e-01
    z[2,1,2]  R957      -7.4780440330505371e-01
    z[2,1,2]  R958      -2.5453430414199829e-01
    z[2,1,2]  R959      3.2538837194442749e-01
    z[2,1,2]  R960      1.6030944883823395e-01
    z[2,1,2]  R961      0.250957727432251
    z[2,1,2]  R962      2.2730448842048645e-01
    z[2,1,2]  R963      -2.0786218345165253e-01
    z[2,1,2]  R964      7.3982700705528259e-02
    z[2,1,2]  R965      -1.1089028790593147e-02
    z[2,1,2]  R966      -2.5956982374191284e-01
    z[2,1,2]  R967      2.1277728676795959e-01
    z[2,1,2]  R968      4.4958975911140442e-01
    z[2,1,2]  R969      -6.7659132182598114e-02
    z[2,1,2]  R970      -2.0726792514324188e-01
    z[2,1,2]  R971      -0.559663712978363
    z[2,1,2]  R972      -5.7365173101425171e-01
    z[2,1,2]  R973      -8.0755275487899780e-01
    z[2,1,2]  R974      -5.2722561359405518e-01
    z[2,1,2]  R975      -4.7982862591743469e-01
    z[2,1,2]  R976      -0.598857045173645
    z[2,1,2]  R977      0.886725664138794
    z[2,1,2]  R978      -7.9085886478424072e-01
    z[2,1,2]  R979      1.1493320018053055e-01
    z[2,1,2]  R980      -5.6808573007583618e-01
    z[2,1,2]  R981      -1.2841895222663879e-01
    z[2,1,2]  R982      2.0998318493366241e-01
    z[2,1,2]  R983      -4.9523675441741943e-01
    z[2,1,2]  R984      -0.351829469203949
    z[2,1,2]  R985      -5.7935726642608643e-01
    z[2,1,2]  R986      -1.5869230031967163e-01
    z[2,1,2]  R987      -1.7285600304603577e-01
    z[2,1,2]  R988      3.6849480867385864e-01
    z[2,1,2]  R989      4.0468290448188782e-01
    z[2,1,2]  R990      3.7011903524398804e-01
    z[2,1,2]  R991      -1.3974243402481079e-01
    z[2,1,2]  R992      -1.0791204869747162e-01
    z[2,1,2]  R993      -1.3351014256477356e-01
    z[2,1,2]  R994      -1.4141140878200531e-01
    z[2,1,2]  R995      3.7054324150085449e-01
    z[2,1,2]  R996      0.481171190738678
    z[2,1,2]  R997      4.4943156838417053e-01
    z[2,1,2]  R998      6.2327116727828979e-01
    z[2,1,2]  R999      8.0959469079971313e-02
    z[2,1,2]  R1000     0.0745064914226532
    z[2,1,2]  R1001     -5.1401269435882568e-01
    z[2,1,2]  R1002     -4.1547033190727234e-01
    z[2,1,2]  R1003     -4.5047828555107117e-01
    z[2,1,2]  R1004     -6.2747198343276978e-01
    z[2,1,2]  R1005     -4.7564360499382019e-01
    z[2,1,2]  R1006     3.9179524779319763e-01
    z[2,1,2]  R1007     4.8451694846153259e-01
    z[2,1,2]  R1008     -8.9959733188152313e-02
    z[2,1,2]  R1009     1.5008051693439484e-01
    z[2,1,2]  R1010     2.6233983039855957e-01
    z[2,1,2]  R1011     -6.8765640258789062e-01
    z[2,1,2]  R1012     -0.522006094455719
    z[2,1,2]  R1013     2.1208065748214722e-01
    z[2,1,2]  R1014     -4.6540012955665588e-01
    z[2,1,2]  R1015     -4.6059334278106689e-01
    z[2,1,2]  R1016     -0.485392302274704
    z[2,1,2]  R1017     -7.0152807235717773e-01
    z[2,1,2]  R1018     -0.0619235597550869
    z[2,1,2]  R1019     1.6759210824966431e-01
    z[2,1,2]  R1020     0.0671146884560585
    z[2,1,2]  R1021     -6.9854712486267090e-01
    z[2,1,2]  R1022     -0.712831974029541
    z[2,1,2]  R1023     -8.8186144828796387e-01
    z[2,1,2]  R1024     -2.0456868410110474e-01
    z[2,1,2]  R1025     -8.0457948148250580e-02
    z[2,1,2]  R1026     6.7947648465633392e-02
    z[2,1,2]  R1027     1.7455644905567169e-01
    z[2,1,2]  R1028     -2.1403209865093231e-01
    z[2,1,2]  R1029     1.9011916220188141e-01
    z[2,1,2]  R1030     3.9396515488624573e-01
    z[2,1,2]  R1031     -6.0739632695913315e-02
    z[2,1,2]  R1032     -1.7637857794761658e-01
    z[2,1,2]  R1033     -0.0888201892375946
    z[2,1,2]  R1034     2.8243938088417053e-01
    z[2,1,2]  R1035     -3.3264991641044617e-01
    z[2,1,2]  R1036     0.207072451710701
    z[2,1,2]  R1037     0.0663580447435379
    z[2,1,2]  R1038     -5.1376353949308395e-02
    z[2,1,2]  R1039     -1.8423390388488770e-01
    z[2,1,2]  R1040     6.5412461757659912e-02
    z[2,1,2]  R1041     5.2865464240312576e-02
    z[2,1,2]  R1042     -2.3262429982423782e-02
    z[2,1,2]  R1043     0.0476471409201622
    z[2,1,2]  R1044     -7.3751728050410748e-03
    z[2,1,2]  R1045     1.7571914196014404e-01
    z[2,1,2]  R1046     4.0155026316642761e-01
    z[2,1,2]  R1047     0.446807324886322
    z[2,1,2]  R1048     -1.3759591616690159e-02
    z[2,1,2]  R1049     2.1937979757785797e-01
    z[2,1,2]  R1050     2.4245730042457581e-01
    z[2,1,2]  R1051     3.4914985299110413e-01
    z[2,1,2]  R1052     4.2426955699920654e-01
    z[2,1,2]  R1053     1.7419147491455078e-01
    z[2,1,2]  R1054     1.3603346049785614e-01
    z[2,1,2]  R1055     2.2313900291919708e-01
    z[2,1,2]  R1056     -3.4275189042091370e-01
    z[2,1,2]  R1057     -2.7045145630836487e-01
    z[2,1,2]  R1058     3.9838257431983948e-01
    z[2,1,2]  R1059     1.9918428361415863e-01
    z[2,1,2]  R1060     1.8702767789363861e-01
    z[2,1,2]  R1061     -2.1489652991294861e-01
    z[2,1,2]  R1062     -5.1691156625747681e-01
    z[2,1,2]  R1063     1.2027036398649216e-01
    z[2,1,2]  R1064     -5.3264591842889786e-02
    z[2,1,2]  R1065     0.0594746358692646
    z[2,1,2]  R1066     4.1544923186302185e-01
    z[2,1,2]  R1067     3.5326632857322693e-01
    z[2,1,2]  R1068     1.8077576160430908e-01
    z[2,1,2]  R1069     5.1298856735229492e-01
    z[2,1,2]  R1070     4.4338029623031616e-01
    z[2,1,2]  R1071     -4.2498657107353210e-01
    z[2,1,2]  R1072     -2.2581714391708374e-01
    z[2,1,2]  R1073     0.324491411447525
    z[2,1,2]  R1074     4.4395741820335388e-01
    z[2,1,2]  R1075     4.9326434731483459e-01
    z[2,1,2]  R1076     3.2187905907630920e-01
    z[2,1,2]  R1077     4.0216556191444397e-01
    z[2,1,2]  R1078     2.0421876013278961e-01
    z[2,1,2]  R1079     7.1265482902526855e-01
    z[2,1,2]  R1080     1.3422681391239166e-01
    z[2,1,3]  R14       1
    z[2,1,3]  R23       -1
    z[2,1,3]  R933      -1
    z[2,1,3]  R934      1
    z[2,1,3]  R941      4.5843076705932617e-01
    z[2,1,3]  R942      -3.1058143824338913e-02
    z[2,1,3]  R943      2.8784537315368652e-01
    z[2,1,3]  R944      6.5112829208374023e-01
    z[2,1,3]  R945      5.1474034786224365e-01
    z[2,1,3]  R946      -1.1923284828662872e-01
    z[2,1,3]  R947      4.3017926812171936e-01
    z[2,1,3]  R948      -2.0549426972866058e-01
    z[2,1,3]  R949      -5.2066117525100708e-02
    z[2,1,3]  R950      5.0769889354705811e-01
    z[2,1,3]  R951      1.1674515157938004e-01
    z[2,1,3]  R952      3.5537999868392944e-01
    z[2,1,3]  R953      -5.1625583320856094e-02
    z[2,1,3]  R954      6.0137853026390076e-02
    z[2,1,3]  R955      -0.157786563038826
    z[2,1,3]  R956      -1.7026992142200470e-01
    z[2,1,3]  R957      -1.0650216601788998e-02
    z[2,1,3]  R958      6.5115690231323242e-02
    z[2,1,3]  R959      1.1661132425069809e-01
    z[2,1,3]  R960      -7.1028995513916016e-01
    z[2,1,3]  R961      2.7433764189481735e-03
    z[2,1,3]  R962      -6.7830830812454224e-01
    z[2,1,3]  R963      2.4954505264759064e-01
    z[2,1,3]  R964      -4.4995075464248657e-01
    z[2,1,3]  R965      -6.2988221645355225e-01
    z[2,1,3]  R966      -2.2799676656723022e-01
    z[2,1,3]  R967      4.4768846035003662e-01
    z[2,1,3]  R968      -6.1550658941268921e-01
    z[2,1,3]  R969      -3.3372217416763306e-01
    z[2,1,3]  R970      -4.2903545498847961e-01
    z[2,1,3]  R971      3.1411767005920410e-01
    z[2,1,3]  R972      1.0412068665027618e-01
    z[2,1,3]  R973      1.8298628926277161e-01
    z[2,1,3]  R974      5.0356507301330566e-01
    z[2,1,3]  R975      6.1112821102142334e-01
    z[2,1,3]  R976      2.8271466493606567e-01
    z[2,1,3]  R977      -2.6987859606742859e-01
    z[2,1,3]  R978      1.9051222503185272e-01
    z[2,1,3]  R979      -2.8663340210914612e-01
    z[2,1,3]  R980      -1.5051684342324734e-02
    z[2,1,3]  R981      2.8195375204086304e-01
    z[2,1,3]  R982      -3.0767318606376648e-01
    z[2,1,3]  R983      -3.2623484730720520e-01
    z[2,1,3]  R984      -2.9760724306106567e-01
    z[2,1,3]  R985      4.8644068837165833e-01
    z[2,1,3]  R986      1.4212132990360260e-01
    z[2,1,3]  R987      -1.8289128318428993e-02
    z[2,1,3]  R988      6.3790738582611084e-01
    z[2,1,3]  R989      7.4694973230361938e-01
    z[2,1,3]  R990      5.3082180023193359e-01
    z[2,1,3]  R991      4.2786693572998047e-01
    z[2,1,3]  R992      5.6138175725936890e-01
    z[2,1,3]  R993      -2.1517328917980194e-02
    z[2,1,3]  R994      6.8580663204193115e-01
    z[2,1,3]  R995      -3.8698457647114992e-03
    z[2,1,3]  R996      3.2861644029617310e-01
    z[2,1,3]  R997      -1.2012303620576859e-01
    z[2,1,3]  R998      5.5567485094070435e-01
    z[2,1,3]  R999      -1.2867744266986847e-01
    z[2,1,3]  R1000     -5.6563433259725571e-02
    z[2,1,3]  R1001     -9.4751402735710144e-02
    z[2,1,3]  R1002     -3.3500720746815205e-03
    z[2,1,3]  R1003     -2.4091796576976776e-01
    z[2,1,3]  R1004     5.9733642265200615e-03
    z[2,1,3]  R1005     -6.5414440631866455e-01
    z[2,1,3]  R1006     2.4336710572242737e-01
    z[2,1,3]  R1007     -4.4006025791168213e-01
    z[2,1,3]  R1008     -4.2608228325843811e-01
    z[2,1,3]  R1009     -7.2649914026260376e-01
    z[2,1,3]  R1010     -1.6354420781135559e-01
    z[2,1,3]  R1011     6.0123833827674389e-03
    z[2,1,3]  R1012     6.9074296951293945e-01
    z[2,1,3]  R1013     -1.8271112442016602e-01
    z[2,1,3]  R1014     -2.5598838925361633e-02
    z[2,1,3]  R1015     -4.3165674805641174e-01
    z[2,1,3]  R1016     4.8092268407344818e-02
    z[2,1,3]  R1017     -2.3779571056365967e-01
    z[2,1,3]  R1018     -6.3250350952148438e-01
    z[2,1,3]  R1019     2.6156967878341675e-01
    z[2,1,3]  R1020     -8.4441676735877991e-02
    z[2,1,3]  R1021     4.3929345905780792e-02
    z[2,1,3]  R1022     2.3876060545444489e-01
    z[2,1,3]  R1023     3.4031070768833160e-02
    z[2,1,3]  R1024     1.9250829517841339e-01
    z[2,1,3]  R1025     5.1246255636215210e-01
    z[2,1,3]  R1026     -6.0873252153396606e-01
    z[2,1,3]  R1027     -9.0511363744735718e-01
    z[2,1,3]  R1028     -7.3025971651077271e-01
    z[2,1,3]  R1029     -5.0211775302886963e-01
    z[2,1,3]  R1030     -5.5745714902877808e-01
    z[2,1,3]  R1031     5.2649700641632080e-01
    z[2,1,3]  R1032     1.9932985305786133e-01
    z[2,1,3]  R1033     7.8748238086700439e-01
    z[2,1,3]  R1034     4.3566811084747314e-01
    z[2,1,3]  R1035     -8.1966057419776917e-02
    z[2,1,3]  R1036     5.2357977628707886e-01
    z[2,1,3]  R1037     1.8273739516735077e-01
    z[2,1,3]  R1038     -2.8898784518241882e-01
    z[2,1,3]  R1039     -5.8250063657760620e-01
    z[2,1,3]  R1040     -8.3422678709030151e-01
    z[2,1,3]  R1041     5.9759140014648438e-01
    z[2,1,3]  R1042     -5.3690886497497559e-01
    z[2,1,3]  R1043     6.7187029123306274e-01
    z[2,1,3]  R1044     -9.2615431547164917e-01
    z[2,1,3]  R1045     -5.2048432826995850e-01
    z[2,1,3]  R1046     -4.4863912463188171e-01
    z[2,1,3]  R1047     -7.5512075424194336e-01
    z[2,1,3]  R1048     -9.8633371293544769e-02
    z[2,1,3]  R1049     1.2380762398242950e-01
    z[2,1,3]  R1050     -7.0751684904098511e-01
    z[2,1,3]  R1051     -3.8104152679443359e-01
    z[2,1,3]  R1052     3.2583260536193848e-01
    z[2,1,3]  R1053     5.6155413389205933e-01
    z[2,1,3]  R1054     -1.7436213791370392e-01
    z[2,1,3]  R1055     -5.1284188032150269e-01
    z[2,1,3]  R1056     2.0295481383800507e-01
    z[2,1,3]  R1057     -8.3560156822204590e-01
    z[2,1,3]  R1058     -4.8282131552696228e-01
    z[2,1,3]  R1059     -0.545455276966095
    z[2,1,3]  R1060     -0.336578905582428
    z[2,1,3]  R1061     5.5588185787200928e-01
    z[2,1,3]  R1062     7.5425481796264648e-01
    z[2,1,3]  R1063     4.5786008238792419e-01
    z[2,1,3]  R1064     3.0420255661010742e-01
    z[2,1,3]  R1065     0.0747174620628357
    z[2,1,3]  R1066     -0.641779899597168
    z[2,1,3]  R1067     -6.8036824464797974e-01
    z[2,1,3]  R1068     -6.4183020591735840e-01
    z[2,1,3]  R1069     -6.0219085216522217e-01
    z[2,1,3]  R1070     -5.9417766332626343e-01
    z[2,1,3]  R1071     6.6427206993103027e-01
    z[2,1,3]  R1072     2.7343866229057312e-01
    z[2,1,3]  R1073     4.0755501389503479e-01
    z[2,1,3]  R1074     2.5693568587303162e-01
    z[2,1,3]  R1075     -0.682981014251709
    z[2,1,3]  R1076     -6.3763946294784546e-01
    z[2,1,3]  R1077     -6.9238191843032837e-01
    z[2,1,3]  R1078     1.2699677050113678e-01
    z[2,1,3]  R1079     -5.9325700998306274e-01
    z[2,1,3]  R1080     3.0823636054992676e-01
    z[2,1,4]  R15       1
    z[2,1,4]  R24       -1
    z[2,1,4]  R935      -1
    z[2,1,4]  R936      1
    z[2,1,4]  R941      -7.8915923833847046e-02
    z[2,1,4]  R942      0.428545743227005
    z[2,1,4]  R943      4.0092658251523972e-02
    z[2,1,4]  R944      2.3380656540393829e-01
    z[2,1,4]  R945      6.9126054644584656e-02
    z[2,1,4]  R946      1.3722635805606842e-02
    z[2,1,4]  R947      -4.2954348027706146e-02
    z[2,1,4]  R948      6.9148249924182892e-02
    z[2,1,4]  R949      7.5694270431995392e-02
    z[2,1,4]  R950      1.7689904570579529e-01
    z[2,1,4]  R951      -2.0937469601631165e-01
    z[2,1,4]  R952      1.7088751494884491e-01
    z[2,1,4]  R953      2.6169770956039429e-01
    z[2,1,4]  R954      1.4486806094646454e-01
    z[2,1,4]  R955      -2.8544503450393677e-01
    z[2,1,4]  R956      -1.3903099298477173e-01
    z[2,1,4]  R957      -3.1329038739204407e-01
    z[2,1,4]  R958      5.2991223335266113e-01
    z[2,1,4]  R959      -1.5408030152320862e-01
    z[2,1,4]  R960      -3.4385478496551514e-01
    z[2,1,4]  R961      0.374213308095932
    z[2,1,4]  R962      4.6642562747001648e-01
    z[2,1,4]  R963      -6.1091583967208862e-01
    z[2,1,4]  R964      -6.4970010519027710e-01
    z[2,1,4]  R965      -7.3790538311004639e-01
    z[2,1,4]  R966      -7.9327005147933960e-01
    z[2,1,4]  R967      5.8784413337707520e-01
    z[2,1,4]  R968      -5.4279690980911255e-01
    z[2,1,4]  R969      -1.8567000329494476e-01
    z[2,1,4]  R970      0.0546242892742157
    z[2,1,4]  R971      2.1512266248464584e-02
    z[2,1,4]  R972      -5.9000805020332336e-02
    z[2,1,4]  R973      -9.3802623450756073e-02
    z[2,1,4]  R974      -5.2126395702362061e-01
    z[2,1,4]  R975      -5.5842298269271851e-01
    z[2,1,4]  R976      3.6576637625694275e-01
    z[2,1,4]  R977      -5.5177640169858932e-02
    z[2,1,4]  R978      -1.4764183759689331e-01
    z[2,1,4]  R979      1.4394259080290794e-02
    z[2,1,4]  R980      -6.8140465021133423e-01
    z[2,1,4]  R981      -4.2736735939979553e-01
    z[2,1,4]  R982      7.8438544273376465e-01
    z[2,1,4]  R983      -3.9450488984584808e-02
    z[2,1,4]  R984      -2.9868612065911293e-02
    z[2,1,4]  R985      -1.2888021767139435e-01
    z[2,1,4]  R986      1.3152818381786346e-01
    z[2,1,4]  R987      2.6210722327232361e-01
    z[2,1,4]  R988      5.1603776216506958e-01
    z[2,1,4]  R989      3.6167123913764954e-01
    z[2,1,4]  R990      5.5798208713531494e-01
    z[2,1,4]  R991      -1.1247880756855011e-01
    z[2,1,4]  R992      2.2592009976506233e-02
    z[2,1,4]  R993      -0.00748852826654911
    z[2,1,4]  R994      3.2927727699279785e-01
    z[2,1,4]  R995      1.2413238175213337e-02
    z[2,1,4]  R996      0.106113001704216
    z[2,1,4]  R997      5.0413364171981812e-01
    z[2,1,4]  R998      4.1448852419853210e-01
    z[2,1,4]  R999      6.7392474412918091e-01
    z[2,1,4]  R1000     9.4905763864517212e-02
    z[2,1,4]  R1001     -3.9633101224899292e-01
    z[2,1,4]  R1002     9.5441611483693123e-03
    z[2,1,4]  R1003     1.9344888627529144e-01
    z[2,1,4]  R1004     -5.0751698017120361e-01
    z[2,1,4]  R1005     -4.6170118451118469e-01
    z[2,1,4]  R1006     -2.2196891903877258e-01
    z[2,1,4]  R1007     -3.5769772529602051e-01
    z[2,1,4]  R1008     -3.0726441740989685e-01
    z[2,1,4]  R1009     -4.0538829565048218e-01
    z[2,1,4]  R1010     2.3168230056762695e-01
    z[2,1,4]  R1011     -3.4652435779571533e-01
    z[2,1,4]  R1012     -1.8786557018756866e-01
    z[2,1,4]  R1013     -6.7668128013610840e-01
    z[2,1,4]  R1014     -8.4895169734954834e-01
    z[2,1,4]  R1015     -2.6113060116767883e-01
    z[2,1,4]  R1016     1.1247245222330093e-01
    z[2,1,4]  R1017     -1.2196033447980881e-01
    z[2,1,4]  R1018     -5.4073190689086914e-01
    z[2,1,4]  R1019     7.0605689287185669e-01
    z[2,1,4]  R1020     9.4362515211105347e-01
    z[2,1,4]  R1021     -2.0223446190357208e-01
    z[2,1,4]  R1022     3.1554073095321655e-01
    z[2,1,4]  R1023     3.3984726667404175e-01
    z[2,1,4]  R1024     2.1140135824680328e-01
    z[2,1,4]  R1025     -1.7125698924064636e-01
    z[2,1,4]  R1026     -0.0864894762635231
    z[2,1,4]  R1027     -1.9900390878319740e-02
    z[2,1,4]  R1028     -2.2850982844829559e-01
    z[2,1,4]  R1029     -2.0756879448890686e-01
    z[2,1,4]  R1030     -1.8477097153663635e-01
    z[2,1,4]  R1031     -6.6944587230682373e-01
    z[2,1,4]  R1032     1.9878487288951874e-01
    z[2,1,4]  R1033     2.5809904932975769e-01
    z[2,1,4]  R1034     -1.8200004100799561e-01
    z[2,1,4]  R1035     -1.8569459021091461e-01
    z[2,1,4]  R1036     7.6844438910484314e-02
    z[2,1,4]  R1037     6.8372821807861328e-01
    z[2,1,4]  R1038     -5.6160074472427368e-01
    z[2,1,4]  R1039     -4.6660301089286804e-01
    z[2,1,4]  R1040     -3.5465580224990845e-01
    z[2,1,4]  R1041     -1.1367820203304291e-01
    z[2,1,4]  R1042     -1.2245580554008484e-01
    z[2,1,4]  R1043     1.8623976409435272e-01
    z[2,1,4]  R1044     -1.2363362312316895e-01
    z[2,1,4]  R1045     -0.319595068693161
    z[2,1,4]  R1046     -3.0021873116493225e-01
    z[2,1,4]  R1047     -1.8565380573272705e-01
    z[2,1,4]  R1048     -3.3730342984199524e-02
    z[2,1,4]  R1049     -8.9219413697719574e-02
    z[2,1,4]  R1050     5.2021449804306030e-01
    z[2,1,4]  R1051     1.5052796900272369e-01
    z[2,1,4]  R1052     -4.8418673872947693e-01
    z[2,1,4]  R1053     -1.1262041516602039e-02
    z[2,1,4]  R1054     4.5991101861000061e-01
    z[2,1,4]  R1055     4.5816510915756226e-02
    z[2,1,4]  R1056     -0.678889811038971
    z[2,1,4]  R1057     -3.2943999767303467e-01
    z[2,1,4]  R1058     -0.4470234811306
    z[2,1,4]  R1059     -7.9936087131500244e-01
    z[2,1,4]  R1060     -2.0046986639499664e-01
    z[2,1,4]  R1061     -5.5702561140060425e-01
    z[2,1,4]  R1062     -3.3359881490468979e-02
    z[2,1,4]  R1063     -5.0087904930114746e-01
    z[2,1,4]  R1064     7.2544181346893311e-01
    z[2,1,4]  R1065     8.0137783288955688e-01
    z[2,1,4]  R1066     3.9924103021621704e-01
    z[2,1,4]  R1067     4.4599962234497070e-01
    z[2,1,4]  R1068     5.6706315279006958e-01
    z[2,1,4]  R1069     2.8938525915145874e-01
    z[2,1,4]  R1070     2.6491126418113708e-01
    z[2,1,4]  R1071     -3.9084357023239136e-01
    z[2,1,4]  R1072     -2.1561355888843536e-01
    z[2,1,4]  R1073     -6.1471585184335709e-02
    z[2,1,4]  R1074     4.0813198685646057e-01
    z[2,1,4]  R1075     1.0320943593978882e-01
    z[2,1,4]  R1076     5.1756995916366577e-01
    z[2,1,4]  R1077     0.363953173160553
    z[2,1,4]  R1078     -2.6761695742607117e-01
    z[2,1,4]  R1079     -7.7543191611766815e-02
    z[2,1,4]  R1080     3.5110303759574890e-01
    z[2,1,5]  R16       1
    z[2,1,5]  R25       -1
    z[2,1,5]  R937      -1
    z[2,1,5]  R938      1
    z[2,1,5]  R941      -7.5600284337997437e-01
    z[2,1,5]  R942      2.0925825461745262e-02
    z[2,1,5]  R943      -1.7519956827163696e-01
    z[2,1,5]  R944      -8.5107326507568359e-02
    z[2,1,5]  R945      -0.129975363612175
    z[2,1,5]  R946      -1.1450179852545261e-02
    z[2,1,5]  R947      -1.1037198454141617e-01
    z[2,1,5]  R948      -2.7068577706813812e-02
    z[2,1,5]  R949      -7.5989085435867310e-01
    z[2,1,5]  R950      -3.5837404429912567e-02
    z[2,1,5]  R951      3.9327001571655273e-01
    z[2,1,5]  R952      4.1641193628311157e-01
    z[2,1,5]  R953      2.6392295956611633e-01
    z[2,1,5]  R954      3.1351518630981445e-01
    z[2,1,5]  R955      2.3337078094482422e-01
    z[2,1,5]  R956      1.4271828532218933e-01
    z[2,1,5]  R957      2.5921770930290222e-01
    z[2,1,5]  R958      7.6674565672874451e-02
    z[2,1,5]  R959      6.4962792396545410e-01
    z[2,1,5]  R960      1.5710996091365814e-01
    z[2,1,5]  R961      5.7025891542434692e-01
    z[2,1,5]  R962      3.2565575838088989e-01
    z[2,1,5]  R963      -1.7744678258895874e-01
    z[2,1,5]  R964      4.8563620448112488e-01
    z[2,1,5]  R965      4.1208315640687943e-02
    z[2,1,5]  R966      4.6365055441856384e-01
    z[2,1,5]  R967      0.0964667871594429
    z[2,1,5]  R968      2.7510568499565125e-01
    z[2,1,5]  R969      1.1066298931837082e-01
    z[2,1,5]  R970      -1.0694700479507446e-01
    z[2,1,5]  R971      -3.7286561727523804e-01
    z[2,1,5]  R972      -6.1039716005325317e-01
    z[2,1,5]  R973      1.7148524522781372e-01
    z[2,1,5]  R974      -8.9085720479488373e-02
    z[2,1,5]  R975      6.5611422061920166e-02
    z[2,1,5]  R976      -4.1812869906425476e-01
    z[2,1,5]  R977      0.286979079246521
    z[2,1,5]  R978      -1.7271885275840759e-01
    z[2,1,5]  R979      8.1810927391052246e-01
    z[2,1,5]  R980      -3.4268322587013245e-01
    z[2,1,5]  R981      -2.9487481713294983e-01
    z[2,1,5]  R982      3.1709179282188416e-01
    z[2,1,5]  R983      -6.1188173294067383e-01
    z[2,1,5]  R984      -1.8844248354434967e-01
    z[2,1,5]  R985      -2.4835785850882530e-02
    z[2,1,5]  R986      1.9847498834133148e-01
    z[2,1,5]  R987      -4.3695300817489624e-01
    z[2,1,5]  R988      -3.2630094885826111e-01
    z[2,1,5]  R989      -1.2975083291530609e-01
    z[2,1,5]  R990      -2.3591253161430359e-01
    z[2,1,5]  R991      -5.9924560785293579e-01
    z[2,1,5]  R992      -6.7017114162445068e-01
    z[2,1,5]  R993      -1.7075255513191223e-01
    z[2,1,5]  R994      -3.4536325931549072e-01
    z[2,1,5]  R995      -4.1791123151779175e-01
    z[2,1,5]  R996      -1.6387729346752167e-01
    z[2,1,5]  R997      -2.5673899799585342e-02
    z[2,1,5]  R998      -2.7564057707786560e-01
    z[2,1,5]  R999      1.8572375178337097e-01
    z[2,1,5]  R1000     -9.6274352073669434e-01
    z[2,1,5]  R1001     2.6516011357307434e-01
    z[2,1,5]  R1002     3.3366104960441589e-01
    z[2,1,5]  R1003     7.6006367802619934e-02
    z[2,1,5]  R1004     -2.2798164281994104e-03
    z[2,1,5]  R1005     1.8446385860443115e-01
    z[2,1,5]  R1006     4.1964945197105408e-01
    z[2,1,5]  R1007     6.3277292251586914e-01
    z[2,1,5]  R1008     6.8420600891113281e-01
    z[2,1,5]  R1009     4.3545350432395935e-01
    z[2,1,5]  R1010     0.063116155564785
    z[2,1,5]  R1011     -1.3539710640907288e-01
    z[2,1,5]  R1012     1.9015109539031982e-01
    z[2,1,5]  R1013     -3.3738423138856888e-02
    z[2,1,5]  R1014     -1.1009259521961212e-01
    z[2,1,5]  R1015     -6.6776549816131592e-01
    z[2,1,5]  R1016     -2.7803018689155579e-01
    z[2,1,5]  R1017     -5.8783525228500366e-01
    z[2,1,5]  R1018     3.4181165695190430e-01
    z[2,1,5]  R1019     3.4685772657394409e-01
    z[2,1,5]  R1020     -1.1427142471075058e-01
    z[2,1,5]  R1021     -5.1246547698974609e-01
    z[2,1,5]  R1022     -4.7744181752204895e-01
    z[2,1,5]  R1023     -2.8765550255775452e-01
    z[2,1,5]  R1024     7.3895724490284920e-03
    z[2,1,5]  R1025     6.5908366441726685e-01
    z[2,1,5]  R1026     2.7482289075851440e-01
    z[2,1,5]  R1027     3.5857841372489929e-01
    z[2,1,5]  R1028     2.5697714090347290e-01
    z[2,1,5]  R1029     6.2740236520767212e-01
    z[2,1,5]  R1030     5.1673984527587891e-01
    z[2,1,5]  R1031     -5.4225660860538483e-02
    z[2,1,5]  R1032     6.7273318767547607e-01
    z[2,1,5]  R1033     -1.2929636240005493e-01
    z[2,1,5]  R1034     1.8573950231075287e-01
    z[2,1,5]  R1035     2.3989351093769073e-01
    z[2,1,5]  R1036     2.4207981303334236e-02
    z[2,1,5]  R1037     6.8009041249752045e-02
    z[2,1,5]  R1038     0.700463056564331
    z[2,1,5]  R1039     3.8692724704742432e-01
    z[2,1,5]  R1040     3.0215749144554138e-01
    z[2,1,5]  R1041     -5.6540167331695557e-01
    z[2,1,5]  R1042     2.5111094117164612e-01
    z[2,1,5]  R1043     1.6509608924388885e-01
    z[2,1,5]  R1044     3.1623688340187073e-01
    z[2,1,5]  R1045     5.9986698627471924e-01
    z[2,1,5]  R1046     6.2607699632644653e-01
    z[2,1,5]  R1047     1.8678721785545349e-01
    z[2,1,5]  R1048     1.6764141619205475e-01
    z[2,1,5]  R1049     2.6683539152145386e-01
    z[2,1,5]  R1050     5.9409722685813904e-02
    z[2,1,5]  R1051     -6.5568573772907257e-02
    z[2,1,5]  R1052     1.6529381275177002e-01
    z[2,1,5]  R1053     -6.3907362520694733e-02
    z[2,1,5]  R1054     -0.189733624458313
    z[2,1,5]  R1055     1.4546598494052887e-01
    z[2,1,5]  R1056     -2.4480000138282776e-01
    z[2,1,5]  R1057     2.4261584877967834e-01
    z[2,1,5]  R1058     5.1766520738601685e-01
    z[2,1,5]  R1059     -2.2911494597792625e-02
    z[2,1,5]  R1060     -1.3159135123714805e-03
    z[2,1,5]  R1061     -4.8959231376647949e-01
    z[2,1,5]  R1062     1.2369251251220703e-01
    z[2,1,5]  R1063     1.8714118003845215e-01
    z[2,1,5]  R1064     0.262578547000885
    z[2,1,5]  R1065     -8.0211512744426727e-02
    z[2,1,5]  R1066     -3.1390699744224548e-01
    z[2,1,5]  R1067     -5.3827010095119476e-02
    z[2,1,5]  R1068     2.3970412090420723e-02
    z[2,1,5]  R1069     7.8765578567981720e-02
    z[2,1,5]  R1070     -3.7683773040771484e-01
    z[2,1,5]  R1071     -0.0905112773180008
    z[2,1,5]  R1072     -6.7866414785385132e-01
    z[2,1,5]  R1073     -1.1712118051946163e-02
    z[2,1,5]  R1074     6.3943368196487427e-01
    z[2,1,5]  R1075     -1.3582212850451469e-02
    z[2,1,5]  R1076     2.7645006775856018e-01
    z[2,1,5]  R1077     -1.7054859548807144e-02
    z[2,1,5]  R1078     2.4767701327800751e-01
    z[2,1,5]  R1079     7.2591237723827362e-02
    z[2,1,5]  R1080     9.5383025705814362e-02
    z[2,1,6]  R17       1
    z[2,1,6]  R26       -1
    z[2,1,6]  R939      -1
    z[2,1,6]  R940      1
    z[2,1,6]  R941      1.6713712364435196e-02
    z[2,1,6]  R942      1.3852766156196594e-01
    z[2,1,6]  R943      -2.6451028883457184e-02
    z[2,1,6]  R944      6.5301500260829926e-02
    z[2,1,6]  R945      -2.0380245149135590e-01
    z[2,1,6]  R946      1.8621627986431122e-01
    z[2,1,6]  R947      3.7159714102745056e-01
    z[2,1,6]  R948      5.8207410573959351e-01
    z[2,1,6]  R949      -9.7229331731796265e-02
    z[2,1,6]  R950      9.8299160599708557e-02
    z[2,1,6]  R951      -8.5928887128829956e-02
    z[2,1,6]  R952      -5.0952263176441193e-02
    z[2,1,6]  R953      0.290477991104126
    z[2,1,6]  R954      9.4562888145446777e-02
    z[2,1,6]  R955      4.1986885666847229e-01
    z[2,1,6]  R956      -0.355317622423172
    z[2,1,6]  R957      3.1535494327545166e-01
    z[2,1,6]  R958      -2.3087418079376221e-01
    z[2,1,6]  R959      -5.2109336853027344e-01
    z[2,1,6]  R960      -5.1472866535186768e-01
    z[2,1,6]  R961      6.4978986978530884e-01
    z[2,1,6]  R962      1.3804058730602264e-01
    z[2,1,6]  R963      2.4975056946277618e-01
    z[2,1,6]  R964      1.1272017657756805e-01
    z[2,1,6]  R965      -2.0698155462741852e-01
    z[2,1,6]  R966      -7.2273783385753632e-02
    z[2,1,6]  R967      4.9550160765647888e-02
    z[2,1,6]  R968      1.1164902895689011e-01
    z[2,1,6]  R969      -2.0635692775249481e-01
    z[2,1,6]  R970      2.0182704925537109e-01
    z[2,1,6]  R971      -4.6101385354995728e-01
    z[2,1,6]  R972      2.6499542593955994e-01
    z[2,1,6]  R973      -1.4004588127136230e-01
    z[2,1,6]  R974      -4.1854989528656006e-01
    z[2,1,6]  R975      1.0906316339969635e-01
    z[2,1,6]  R976      4.3054428696632385e-01
    z[2,1,6]  R977      0.090914286673069
    z[2,1,6]  R978      -0.0802655816078186
    z[2,1,6]  R979      -4.3816640973091125e-01
    z[2,1,6]  R980      2.2761696577072144e-01
    z[2,1,6]  R981      6.0557309538125992e-02
    z[2,1,6]  R982      -8.9875146746635437e-02
    z[2,1,6]  R983      6.1374053359031677e-02
    z[2,1,6]  R984      1.6884168609976768e-02
    z[2,1,6]  R985      4.2412549257278442e-01
    z[2,1,6]  R986      5.1192098855972290e-01
    z[2,1,6]  R987      -3.0343142151832581e-01
    z[2,1,6]  R988      2.0778505504131317e-01
    z[2,1,6]  R989      -1.2761445343494415e-01
    z[2,1,6]  R990      -0.400240957736969
    z[2,1,6]  R991      5.4936385154724121e-01
    z[2,1,6]  R992      -2.6172572374343872e-01
    z[2,1,6]  R993      -0.285825252532959
    z[2,1,6]  R994      -3.6537206172943115e-01
    z[2,1,6]  R995      -3.1697034835815430e-01
    z[2,1,6]  R996      3.1209623813629150e-01
    z[2,1,6]  R997      -1.7608475685119629e-01
    z[2,1,6]  R998      -1.7964359372854233e-02
    z[2,1,6]  R999      1.8934594467282295e-02
    z[2,1,6]  R1000     7.0240586996078491e-02
    z[2,1,6]  R1001     -4.1481410153210163e-03
    z[2,1,6]  R1002     9.4167903065681458e-02
    z[2,1,6]  R1003     -5.0156249199062586e-04
    z[2,1,6]  R1004     -4.9856850504875183e-01
    z[2,1,6]  R1005     9.0561136603355408e-02
    z[2,1,6]  R1006     5.0405509769916534e-02
    z[2,1,6]  R1007     -1.9536618143320084e-02
    z[2,1,6]  R1008     -4.4646725058555603e-01
    z[2,1,6]  R1009     -1.3794755935668945e-01
    z[2,1,6]  R1010     -8.6756169795989990e-02
    z[2,1,6]  R1011     2.6139521598815918e-01
    z[2,1,6]  R1012     1.7950955033302307e-01
    z[2,1,6]  R1013     -1.4895421266555786e-01
    z[2,1,6]  R1014     1.0262466222047806e-01
    z[2,1,6]  R1015     2.6971647143363953e-01
    z[2,1,6]  R1016     5.8602774143218994e-01
    z[2,1,6]  R1017     -0.0789579525589943
    z[2,1,6]  R1018     -9.7000725567340851e-02
    z[2,1,6]  R1019     4.7660249471664429e-01
    z[2,1,6]  R1020     -5.0564175471663475e-03
    z[2,1,6]  R1021     -1.0765118151903152e-01
    z[2,1,6]  R1022     -2.3900514468550682e-02
    z[2,1,6]  R1023     -4.3533239513635635e-02
    z[2,1,6]  R1024     -1.5683084726333618e-01
    z[2,1,6]  R1025     1.6710405051708221e-01
    z[2,1,6]  R1026     0.559935986995697
    z[2,1,6]  R1027     7.9860344529151917e-02
    z[2,1,6]  R1028     -5.3181725740432739e-01
    z[2,1,6]  R1029     2.6263775303959846e-02
    z[2,1,6]  R1030     -8.4048651158809662e-02
    z[2,1,6]  R1031     -3.4072157740592957e-01
    z[2,1,6]  R1032     2.9886773228645325e-01
    z[2,1,6]  R1033     1.3904240727424622e-01
    z[2,1,6]  R1034     -7.8896619379520416e-02
    z[2,1,6]  R1035     0.7186239361763
    z[2,1,6]  R1036     -2.8426237404346466e-02
    z[2,1,6]  R1037     -5.2897542715072632e-01
    z[2,1,6]  R1038     2.2473634779453278e-01
    z[2,1,6]  R1039     0.502406656742096
    z[2,1,6]  R1040     2.8155499696731567e-01
    z[2,1,6]  R1041     2.4540470913052559e-02
    z[2,1,6]  R1042     4.8982140421867371e-01
    z[2,1,6]  R1043     -3.2377848029136658e-01
    z[2,1,6]  R1044     2.6192527264356613e-02
    z[2,1,6]  R1045     -4.1526150703430176e-01
    z[2,1,6]  R1046     -3.7852057814598083e-01
    z[2,1,6]  R1047     -1.5117228031158447e-01
    z[2,1,6]  R1048     2.6974314451217651e-01
    z[2,1,6]  R1049     2.4181246757507324e-01
    z[2,1,6]  R1050     -3.5141488909721375e-01
    z[2,1,6]  R1051     -1.6979727149009705e-01
    z[2,1,6]  R1052     1.0500414669513702e-01
    z[2,1,6]  R1053     2.7354088425636292e-01
    z[2,1,6]  R1054     5.2951216697692871e-01
    z[2,1,6]  R1055     5.1548373699188232e-01
    z[2,1,6]  R1056     2.6870566606521606e-01
    z[2,1,6]  R1057     -2.3152175545692444e-01
    z[2,1,6]  R1058     2.5246503949165344e-01
    z[2,1,6]  R1059     -6.2848613597452641e-03
    z[2,1,6]  R1060     -1.0438323020935059e-02
    z[2,1,6]  R1061     -1.5473565459251404e-01
    z[2,1,6]  R1062     -1.5618702769279480e-01
    z[2,1,6]  R1063     1.9208897650241852e-01
    z[2,1,6]  R1064     -0.0856553316116333
    z[2,1,6]  R1065     4.8573899269104004e-01
    z[2,1,6]  R1066     2.2684057056903839e-01
    z[2,1,6]  R1067     1.2641890347003937e-01
    z[2,1,6]  R1068     -3.3749712165445089e-03
    z[2,1,6]  R1069     -1.2154351174831390e-01
    z[2,1,6]  R1070     0.180814728140831
    z[2,1,6]  R1071     3.6732730269432068e-01
    z[2,1,6]  R1072     2.5281503796577454e-01
    z[2,1,6]  R1073     -2.0104783773422241e-01
    z[2,1,6]  R1074     -2.5840455293655396e-01
    z[2,1,6]  R1075     -2.1076993644237518e-01
    z[2,1,6]  R1076     2.3696507513523102e-01
    z[2,1,6]  R1077     -1.7199589312076569e-01
    z[2,1,6]  R1078     -2.7896878123283386e-01
    z[2,1,6]  R1079     1.9066981971263885e-01
    z[2,1,6]  R1080     1.8433047458529472e-02
    z[2,3,0]  R20       -1
    z[2,3,0]  R29       1
    z[2,3,0]  R1081     -1
    z[2,3,0]  R1082     1
    z[2,3,0]  R1095     -2.1391913294792175e-01
    z[2,3,0]  R1096     -2.6369300484657288e-01
    z[2,3,0]  R1097     -2.0321425795555115e-01
    z[2,3,0]  R1098     -1.2211536616086960e-01
    z[2,3,0]  R1099     -2.1548202633857727e-01
    z[2,3,0]  R1100     -5.0030261278152466e-01
    z[2,3,0]  R1101     -0.0824422836303711
    z[2,3,0]  R1102     -6.5397894382476807e-01
    z[2,3,0]  R1103     4.9234387278556824e-01
    z[2,3,0]  R1104     1.8694119155406952e-01
    z[2,3,0]  R1105     1.5439975261688232e-01
    z[2,3,0]  R1106     1.5032652020454407e-01
    z[2,3,0]  R1107     4.4251907616853714e-02
    z[2,3,0]  R1108     -1.5841630101203918e-01
    z[2,3,0]  R1109     -9.2788815498352051e-02
    z[2,3,0]  R1110     -1.2571211159229279e-01
    z[2,3,0]  R1111     -2.2419813275337219e-01
    z[2,3,0]  R1112     2.2780667245388031e-01
    z[2,3,0]  R1113     -3.2894098758697510e-01
    z[2,3,0]  R1114     -2.4866597354412079e-01
    z[2,3,0]  R1115     5.2616402506828308e-02
    z[2,3,0]  R1116     2.7954089641571045e-01
    z[2,3,0]  R1117     6.4820271730422974e-01
    z[2,3,0]  R1118     -1.4740100130438805e-02
    z[2,3,0]  R1119     -4.6165034174919128e-02
    z[2,3,0]  R1120     7.8379977494478226e-03
    z[2,3,0]  R1121     6.3006269931793213e-01
    z[2,3,0]  R1122     1.4017288386821747e-01
    z[2,3,0]  R1123     -2.4023541808128357e-01
    z[2,3,0]  R1124     -3.9358308911323547e-01
    z[2,3,0]  R1125     -1.4701075851917267e-01
    z[2,3,0]  R1126     4.1678366065025330e-01
    z[2,3,0]  R1127     -1.3015897572040558e-01
    z[2,3,0]  R1128     6.1288721859455109e-02
    z[2,3,0]  R1129     -1.8016344308853149e-01
    z[2,3,0]  R1130     2.5706410408020020e-01
    z[2,3,0]  R1131     1.9248086214065552e-01
    z[2,3,0]  R1132     5.2797567844390869e-01
    z[2,3,0]  R1133     -6.0768104158341885e-03
    z[2,3,0]  R1134     -1.8545801937580109e-01
    z[2,3,0]  R1135     3.7204214930534363e-01
    z[2,3,0]  R1136     3.1403880566358566e-02
    z[2,3,0]  R1137     4.0567180514335632e-01
    z[2,3,0]  R1138     2.0946851000189781e-03
    z[2,3,0]  R1139     -1.9522626698017120e-01
    z[2,3,0]  R1140     1.6009330749511719e-01
    z[2,3,0]  R1141     5.6637412309646606e-01
    z[2,3,0]  R1142     1.4716935157775879e-01
    z[2,3,0]  R1143     2.0530971884727478e-01
    z[2,3,0]  R1144     2.2877733409404755e-01
    z[2,3,0]  R1145     3.8435712456703186e-01
    z[2,3,0]  R1146     4.6964627504348755e-01
    z[2,3,0]  R1147     1.2871317565441132e-01
    z[2,3,0]  R1148     3.3063021302223206e-01
    z[2,3,0]  R1149     -1.5768514573574066e-01
    z[2,3,0]  R1150     -6.0754650831222534e-01
    z[2,3,0]  R1151     -4.4395166635513306e-01
    z[2,3,0]  R1152     -1.7489361763000488e-01
    z[2,3,0]  R1153     -6.6080474853515625e-01
    z[2,3,0]  R1154     -6.0426956415176392e-01
    z[2,3,0]  R1155     -3.8641926646232605e-01
    z[2,3,0]  R1156     -2.2747081518173218e-01
    z[2,3,0]  R1157     -1.8546903133392334e-01
    z[2,3,0]  R1158     -2.2525892127305269e-03
    z[2,3,0]  R1159     -3.2109636068344116e-01
    z[2,3,0]  R1160     -2.2801786661148071e-02
    z[2,3,0]  R1161     -5.9258061647415161e-01
    z[2,3,0]  R1162     -3.0523759126663208e-01
    z[2,3,0]  R1163     -4.9144953489303589e-01
    z[2,3,0]  R1164     3.5981366038322449e-01
    z[2,3,0]  R1165     4.6973848342895508e-01
    z[2,3,0]  R1166     3.7984788417816162e-01
    z[2,3,0]  R1167     3.2363331317901611e-01
    z[2,3,0]  R1168     -1.0073760896921158e-01
    z[2,3,0]  R1169     -5.3915452957153320e-01
    z[2,3,0]  R1170     0.573432981967926
    z[2,3,0]  R1171     5.8630925416946411e-01
    z[2,3,0]  R1172     6.3679113984107971e-02
    z[2,3,0]  R1173     1.5071780420839787e-02
    z[2,3,0]  R1174     1.0220363736152649e-01
    z[2,3,0]  R1175     7.9044562578201294e-01
    z[2,3,0]  R1176     -8.5493430495262146e-02
    z[2,3,0]  R1177     -2.8234678506851196e-01
    z[2,3,0]  R1178     -1.1949960142374039e-01
    z[2,3,0]  R1179     -4.2563432455062866e-01
    z[2,3,0]  R1180     -3.5032281279563904e-01
    z[2,3,0]  R1181     -2.7937644720077515e-01
    z[2,3,0]  R1182     -3.0842721462249756e-01
    z[2,3,0]  R1183     -6.1874139308929443e-01
    z[2,3,0]  R1184     -4.4269609451293945e-01
    z[2,3,0]  R1185     1.0344447195529938e-01
    z[2,3,0]  R1186     -9.6073616296052933e-03
    z[2,3,0]  R1187     -3.5229781270027161e-01
    z[2,3,0]  R1188     2.1113598719239235e-02
    z[2,3,0]  R1189     -1.6194912791252136e-01
    z[2,3,0]  R1190     1.4746780693531036e-01
    z[2,3,0]  R1191     -3.9892011880874634e-01
    z[2,3,0]  R1192     -2.4754211306571960e-01
    z[2,3,0]  R1193     -5.6692034006118774e-01
    z[2,3,0]  R1194     -6.1223447322845459e-01
    z[2,3,0]  R1195     -8.9415594935417175e-02
    z[2,3,0]  R1196     5.4197525978088379e-01
    z[2,3,0]  R1197     -3.4987998008728027e-01
    z[2,3,0]  R1198     -5.3841060400009155e-01
    z[2,3,0]  R1199     1.6175134107470512e-02
    z[2,3,0]  R1200     1.9008865579962730e-02
    z[2,3,0]  R1201     -1.1379750072956085e-01
    z[2,3,0]  R1202     8.3032414317131042e-02
    z[2,3,0]  R1203     -6.1901800334453583e-02
    z[2,3,0]  R1204     2.9676225781440735e-01
    z[2,3,1]  R21       -1
    z[2,3,1]  R30       1
    z[2,3,1]  R1083     -1
    z[2,3,1]  R1084     1
    z[2,3,1]  R1095     3.6962968111038208e-01
    z[2,3,1]  R1096     -2.2585336863994598e-01
    z[2,3,1]  R1097     -6.3878291845321655e-01
    z[2,3,1]  R1098     -0.637885332107544
    z[2,3,1]  R1099     -6.2792015075683594e-01
    z[2,3,1]  R1100     -2.5551816448569298e-02
    z[2,3,1]  R1101     -5.1065891981124878e-01
    z[2,3,1]  R1102     -1.5931475162506104e-01
    z[2,3,1]  R1103     3.9877825975418091e-01
    z[2,3,1]  R1104     -3.3519566059112549e-01
    z[2,3,1]  R1105     7.4821001291275024e-01
    z[2,3,1]  R1106     6.2233549356460571e-01
    z[2,3,1]  R1107     7.0716559886932373e-01
    z[2,3,1]  R1108     3.4581381082534790e-01
    z[2,3,1]  R1109     6.0509526729583740e-01
    z[2,3,1]  R1110     4.4489392638206482e-01
    z[2,3,1]  R1111     3.5442498326301575e-01
    z[2,3,1]  R1112     7.3422580957412720e-01
    z[2,3,1]  R1113     2.3457735776901245e-01
    z[2,3,1]  R1114     -9.4344671815633774e-03
    z[2,3,1]  R1115     -2.1630187332630157e-01
    z[2,3,1]  R1116     2.5966829061508179e-01
    z[2,3,1]  R1117     -8.5281684994697571e-02
    z[2,3,1]  R1118     -3.4813082218170166e-01
    z[2,3,1]  R1119     1.0931760072708130e-01
    z[2,3,1]  R1120     1.7637154459953308e-01
    z[2,3,1]  R1121     2.9924153932370245e-04
    z[2,3,1]  R1122     -1.2882173061370850e-01
    z[2,3,1]  R1123     -8.5850799083709717e-01
    z[2,3,1]  R1124     -7.5027018785476685e-01
    z[2,3,1]  R1125     4.6310821175575256e-01
    z[2,3,1]  R1126     -2.0021395385265350e-01
    z[2,3,1]  R1127     4.8950418829917908e-01
    z[2,3,1]  R1128     9.9311359226703644e-02
    z[2,3,1]  R1129     1.8918801844120026e-01
    z[2,3,1]  R1130     3.7089128047227859e-02
    z[2,3,1]  R1131     1.0083258152008057e-01
    z[2,3,1]  R1132     3.7639137357473373e-02
    z[2,3,1]  R1133     -2.0759311318397522e-01
    z[2,3,1]  R1134     -9.5413953065872192e-02
    z[2,3,1]  R1135     7.0166522264480591e-01
    z[2,3,1]  R1136     -3.6928680539131165e-01
    z[2,3,1]  R1137     3.2252028584480286e-01
    z[2,3,1]  R1138     8.6657595634460449e-01
    z[2,3,1]  R1139     0.43874591588974
    z[2,3,1]  R1140     0.78117436170578
    z[2,3,1]  R1141     5.4525947570800781e-01
    z[2,3,1]  R1142     1.4030268788337708e-01
    z[2,3,1]  R1143     -2.6873552799224854e-01
    z[2,3,1]  R1144     -4.1345305740833282e-02
    z[2,3,1]  R1145     -3.8943392038345337e-01
    z[2,3,1]  R1146     1.0056421905755997e-01
    z[2,3,1]  R1147     1.5411810576915741e-01
    z[2,3,1]  R1148     -7.9090172052383423e-01
    z[2,3,1]  R1149     -0.0875360444188118
    z[2,3,1]  R1150     -6.2563389539718628e-01
    z[2,3,1]  R1151     -0.704354465007782
    z[2,3,1]  R1152     -7.9132989048957825e-02
    z[2,3,1]  R1153     -6.2296229600906372e-01
    z[2,3,1]  R1154     -6.6563093662261963e-01
    z[2,3,1]  R1155     -4.1182957589626312e-02
    z[2,3,1]  R1156     -3.4564676880836487e-01
    z[2,3,1]  R1157     2.8088864684104919e-01
    z[2,3,1]  R1158     3.0188298225402832e-01
    z[2,3,1]  R1159     6.1274491250514984e-02
    z[2,3,1]  R1160     0.0978856310248375
    z[2,3,1]  R1161     2.0466198027133942e-01
    z[2,3,1]  R1162     6.6788643598556519e-03
    z[2,3,1]  R1163     1.1274852603673935e-01
    z[2,3,1]  R1164     4.3839445710182190e-01
    z[2,3,1]  R1165     3.5533255338668823e-01
    z[2,3,1]  R1166     -6.9836688041687012e-01
    z[2,3,1]  R1167     -3.9601841568946838e-01
    z[2,3,1]  R1168     1.1077233403921127e-01
    z[2,3,1]  R1169     2.0387648046016693e-01
    z[2,3,1]  R1170     -2.1392878890037537e-01
    z[2,3,1]  R1171     3.0866166949272156e-01
    z[2,3,1]  R1172     -1.5111443400382996e-01
    z[2,3,1]  R1173     2.5715095922350883e-02
    z[2,3,1]  R1174     -1.4068578183650970e-01
    z[2,3,1]  R1175     -0.302144318819046
    z[2,3,1]  R1176     3.4736540168523788e-02
    z[2,3,1]  R1177     -1.4574143290519714e-01
    z[2,3,1]  R1178     -2.2250409424304962e-01
    z[2,3,1]  R1179     -4.6310713887214661e-01
    z[2,3,1]  R1180     2.1093061566352844e-01
    z[2,3,1]  R1181     -8.5881382226943970e-01
    z[2,3,1]  R1182     -4.4231769442558289e-01
    z[2,3,1]  R1183     -0.606364369392395
    z[2,3,1]  R1184     -7.1295052766799927e-01
    z[2,3,1]  R1185     7.0980495214462280e-01
    z[2,3,1]  R1186     -4.2589294910430908e-01
    z[2,3,1]  R1187     -1.5035982429981232e-01
    z[2,3,1]  R1188     9.3660390377044678e-01
    z[2,3,1]  R1189     9.3908828496932983e-01
    z[2,3,1]  R1190     8.6301565170288086e-01
    z[2,3,1]  R1191     5.0970077514648438e-01
    z[2,3,1]  R1192     7.0335948467254639e-01
    z[2,3,1]  R1193     2.9809432104229927e-02
    z[2,3,1]  R1194     -9.8309412598609924e-02
    z[2,3,1]  R1195     6.9336611032485962e-01
    z[2,3,1]  R1196     -6.0947406291961670e-01
    z[2,3,1]  R1197     -2.0571936666965485e-01
    z[2,3,1]  R1198     -7.4226832389831543e-01
    z[2,3,1]  R1199     1.8295995891094208e-01
    z[2,3,1]  R1200     6.1455290764570236e-02
    z[2,3,1]  R1201     1.7191922664642334e-01
    z[2,3,1]  R1202     2.5506317615509033e-01
    z[2,3,1]  R1203     9.5106415450572968e-02
    z[2,3,1]  R1204     -8.0855406820774078e-02
    z[2,3,2]  R22       -1
    z[2,3,2]  R31       1
    z[2,3,2]  R1085     -1
    z[2,3,2]  R1086     1
    z[2,3,2]  R1095     -1.7148266732692719e-01
    z[2,3,2]  R1096     8.2171314954757690e-01
    z[2,3,2]  R1097     0.659396231174469
    z[2,3,2]  R1098     2.9673033952713013e-01
    z[2,3,2]  R1099     4.8074802756309509e-01
    z[2,3,2]  R1100     8.3655959367752075e-01
    z[2,3,2]  R1101     6.2870103120803833e-01
    z[2,3,2]  R1102     4.0047213435173035e-01
    z[2,3,2]  R1103     -5.6966669857501984e-02
    z[2,3,2]  R1104     7.4343693256378174e-01
    z[2,3,2]  R1105     -4.4365558028221130e-01
    z[2,3,2]  R1106     -5.0853508710861206e-01
    z[2,3,2]  R1107     -5.2227860689163208e-01
    z[2,3,2]  R1108     -8.5057616233825684e-01
    z[2,3,2]  R1109     -5.3677064180374146e-01
    z[2,3,2]  R1110     -7.6897680759429932e-01
    z[2,3,2]  R1111     -7.4780440330505371e-01
    z[2,3,2]  R1112     -2.5453430414199829e-01
    z[2,3,2]  R1113     3.2538837194442749e-01
    z[2,3,2]  R1114     1.6030944883823395e-01
    z[2,3,2]  R1115     0.250957727432251
    z[2,3,2]  R1116     2.2730448842048645e-01
    z[2,3,2]  R1117     -2.0786218345165253e-01
    z[2,3,2]  R1118     7.3982700705528259e-02
    z[2,3,2]  R1119     -1.1089028790593147e-02
    z[2,3,2]  R1120     -2.5956982374191284e-01
    z[2,3,2]  R1121     2.1277728676795959e-01
    z[2,3,2]  R1122     4.4958975911140442e-01
    z[2,3,2]  R1123     -6.7659132182598114e-02
    z[2,3,2]  R1124     -2.0726792514324188e-01
    z[2,3,2]  R1125     -0.559663712978363
    z[2,3,2]  R1126     -5.7365173101425171e-01
    z[2,3,2]  R1127     -8.0755275487899780e-01
    z[2,3,2]  R1128     -5.2722561359405518e-01
    z[2,3,2]  R1129     -4.7982862591743469e-01
    z[2,3,2]  R1130     -0.598857045173645
    z[2,3,2]  R1131     0.886725664138794
    z[2,3,2]  R1132     -7.9085886478424072e-01
    z[2,3,2]  R1133     1.1493320018053055e-01
    z[2,3,2]  R1134     -5.6808573007583618e-01
    z[2,3,2]  R1135     -1.2841895222663879e-01
    z[2,3,2]  R1136     2.0998318493366241e-01
    z[2,3,2]  R1137     -4.9523675441741943e-01
    z[2,3,2]  R1138     -0.351829469203949
    z[2,3,2]  R1139     -5.7935726642608643e-01
    z[2,3,2]  R1140     -1.5869230031967163e-01
    z[2,3,2]  R1141     -1.7285600304603577e-01
    z[2,3,2]  R1142     3.6849480867385864e-01
    z[2,3,2]  R1143     4.0468290448188782e-01
    z[2,3,2]  R1144     3.7011903524398804e-01
    z[2,3,2]  R1145     -1.3613632321357727e-01
    z[2,3,2]  R1146     -3.2119369506835938e-01
    z[2,3,2]  R1147     0.11175537109375
    z[2,3,2]  R1148     3.1654998660087585e-02
    z[2,3,2]  R1149     8.4770750999450684e-01
    z[2,3,2]  R1150     -1.4828373491764069e-01
    z[2,3,2]  R1151     2.9359790682792664e-01
    z[2,3,2]  R1152     0.686779260635376
    z[2,3,2]  R1153     -3.4933474659919739e-01
    z[2,3,2]  R1154     -1.5206056833267212e-01
    z[2,3,2]  R1155     1.1364550888538361e-01
    z[2,3,2]  R1156     3.4251266717910767e-01
    z[2,3,2]  R1157     8.4152139723300934e-02
    z[2,3,2]  R1158     -7.0116829872131348e-01
    z[2,3,2]  R1159     0.310958594083786
    z[2,3,2]  R1160     -4.8581293225288391e-01
    z[2,3,2]  R1161     1.5351407229900360e-01
    z[2,3,2]  R1162     -2.2517786920070648e-01
    z[2,3,2]  R1163     2.1858850494027138e-02
    z[2,3,2]  R1164     -4.2397168278694153e-01
    z[2,3,2]  R1165     1.2479174137115479e-01
    z[2,3,2]  R1166     4.9236118793487549e-01
    z[2,3,2]  R1167     7.7350640296936035e-01
    z[2,3,2]  R1168     4.2019265890121460e-01
    z[2,3,2]  R1169     3.5428783297538757e-01
    z[2,3,2]  R1170     3.6612513661384583e-01
    z[2,3,2]  R1171     1.0885686427354813e-01
    z[2,3,2]  R1172     5.1020783185958862e-01
    z[2,3,2]  R1173     6.2840634584426880e-01
    z[2,3,2]  R1174     9.5704257488250732e-02
    z[2,3,2]  R1175     4.8155072331428528e-01
    z[2,3,2]  R1176     0.616873025894165
    z[2,3,2]  R1177     4.6412819623947144e-01
    z[2,3,2]  R1178     1.1298055946826935e-01
    z[2,3,2]  R1179     4.5124284923076630e-02
    z[2,3,2]  R1180     6.3735512085258961e-03
    z[2,3,2]  R1181     -2.0513303577899933e-01
    z[2,3,2]  R1182     -1.2549702823162079e-01
    z[2,3,2]  R1183     -1.3414016366004944e-01
    z[2,3,2]  R1184     2.1963019669055939e-01
    z[2,3,2]  R1185     -4.5000827312469482e-01
    z[2,3,2]  R1186     8.7170645594596863e-02
    z[2,3,2]  R1187     2.8488731384277344e-01
    z[2,3,2]  R1188     2.7279371395707130e-02
    z[2,3,2]  R1189     -1.3675086200237274e-01
    z[2,3,2]  R1190     3.0031827092170715e-01
    z[2,3,2]  R1191     -6.9078212976455688e-01
    z[2,3,2]  R1192     -5.2651494741439819e-01
    z[2,3,2]  R1193     2.8083970770239830e-02
    z[2,3,2]  R1194     2.4156154692173004e-01
    z[2,3,2]  R1195     -5.5537432432174683e-01
    z[2,3,2]  R1196     2.1817199885845184e-01
    z[2,3,2]  R1197     2.2642841935157776e-01
    z[2,3,2]  R1198     -1.9141036272048950e-01
    z[2,3,2]  R1199     1.1570196598768234e-01
    z[2,3,2]  R1200     -0.0828382596373558
    z[2,3,2]  R1201     2.0725773274898529e-01
    z[2,3,2]  R1202     8.0018816515803337e-03
    z[2,3,2]  R1203     -3.0644190311431885e-01
    z[2,3,2]  R1204     -1.1769544333219528e-01
    z[2,3,3]  R23       -1
    z[2,3,3]  R32       1
    z[2,3,3]  R1087     -1
    z[2,3,3]  R1088     1
    z[2,3,3]  R1095     4.5843076705932617e-01
    z[2,3,3]  R1096     -3.1058143824338913e-02
    z[2,3,3]  R1097     2.8784537315368652e-01
    z[2,3,3]  R1098     6.5112829208374023e-01
    z[2,3,3]  R1099     5.1474034786224365e-01
    z[2,3,3]  R1100     -1.1923284828662872e-01
    z[2,3,3]  R1101     4.3017926812171936e-01
    z[2,3,3]  R1102     -2.0549426972866058e-01
    z[2,3,3]  R1103     -5.2066117525100708e-02
    z[2,3,3]  R1104     5.0769889354705811e-01
    z[2,3,3]  R1105     1.1674515157938004e-01
    z[2,3,3]  R1106     3.5537999868392944e-01
    z[2,3,3]  R1107     -5.1625583320856094e-02
    z[2,3,3]  R1108     6.0137853026390076e-02
    z[2,3,3]  R1109     -0.157786563038826
    z[2,3,3]  R1110     -1.7026992142200470e-01
    z[2,3,3]  R1111     -1.0650216601788998e-02
    z[2,3,3]  R1112     6.5115690231323242e-02
    z[2,3,3]  R1113     1.1661132425069809e-01
    z[2,3,3]  R1114     -7.1028995513916016e-01
    z[2,3,3]  R1115     2.7433764189481735e-03
    z[2,3,3]  R1116     -6.7830830812454224e-01
    z[2,3,3]  R1117     2.4954505264759064e-01
    z[2,3,3]  R1118     -4.4995075464248657e-01
    z[2,3,3]  R1119     -6.2988221645355225e-01
    z[2,3,3]  R1120     -2.2799676656723022e-01
    z[2,3,3]  R1121     4.4768846035003662e-01
    z[2,3,3]  R1122     -6.1550658941268921e-01
    z[2,3,3]  R1123     -3.3372217416763306e-01
    z[2,3,3]  R1124     -4.2903545498847961e-01
    z[2,3,3]  R1125     3.1411767005920410e-01
    z[2,3,3]  R1126     1.0412068665027618e-01
    z[2,3,3]  R1127     1.8298628926277161e-01
    z[2,3,3]  R1128     5.0356507301330566e-01
    z[2,3,3]  R1129     6.1112821102142334e-01
    z[2,3,3]  R1130     2.8271466493606567e-01
    z[2,3,3]  R1131     -2.6987859606742859e-01
    z[2,3,3]  R1132     1.9051222503185272e-01
    z[2,3,3]  R1133     -2.8663340210914612e-01
    z[2,3,3]  R1134     -1.5051684342324734e-02
    z[2,3,3]  R1135     2.8195375204086304e-01
    z[2,3,3]  R1136     -3.0767318606376648e-01
    z[2,3,3]  R1137     -3.2623484730720520e-01
    z[2,3,3]  R1138     -2.9760724306106567e-01
    z[2,3,3]  R1139     4.8644068837165833e-01
    z[2,3,3]  R1140     1.4212132990360260e-01
    z[2,3,3]  R1141     -1.8289128318428993e-02
    z[2,3,3]  R1142     6.3790738582611084e-01
    z[2,3,3]  R1143     7.4694973230361938e-01
    z[2,3,3]  R1144     5.3082180023193359e-01
    z[2,3,3]  R1145     4.5321959257125854e-01
    z[2,3,3]  R1146     4.4695851206779480e-01
    z[2,3,3]  R1147     9.3673390150070190e-01
    z[2,3,3]  R1148     1.9504196941852570e-01
    z[2,3,3]  R1149     -2.9698863625526428e-01
    z[2,3,3]  R1150     -0.0312623456120491
    z[2,3,3]  R1151     -2.2925306856632233e-01
    z[2,3,3]  R1152     -4.2882928252220154e-01
    z[2,3,3]  R1153     6.9269701838493347e-02
    z[2,3,3]  R1154     3.7578254938125610e-01
    z[2,3,3]  R1155     -8.1052398681640625e-01
    z[2,3,3]  R1156     -5.8123838901519775e-01
    z[2,3,3]  R1157     -0.560954213142395
    z[2,3,3]  R1158     1.1045350879430771e-01
    z[2,3,3]  R1159     -3.7698951363563538e-01
    z[2,3,3]  R1160     4.2962488532066345e-01
    z[2,3,3]  R1161     -4.0225467085838318e-01
    z[2,3,3]  R1162     -5.8202630281448364e-01
    z[2,3,3]  R1163     -4.1785049438476562e-01
    z[2,3,3]  R1164     -3.0952779576182365e-02
    z[2,3,3]  R1165     2.3720730841159821e-01
    z[2,3,3]  R1166     6.9490201771259308e-02
    z[2,3,3]  R1167     1.2240605801343918e-01
    z[2,3,3]  R1168     -6.0070788860321045e-01
    z[2,3,3]  R1169     -0.522066593170166
    z[2,3,3]  R1170     3.8913151621818542e-01
    z[2,3,3]  R1171     3.6415389180183411e-01
    z[2,3,3]  R1172     -1.9415524601936340e-01
    z[2,3,3]  R1173     -3.3607918024063110e-01
    z[2,3,3]  R1174     -3.9141789078712463e-01
    z[2,3,3]  R1175     -8.4982894361019135e-02
    z[2,3,3]  R1176     -5.5730760097503662e-01
    z[2,3,3]  R1177     -9.1690264642238617e-02
    z[2,3,3]  R1178     -7.2996979951858521e-01
    z[2,3,3]  R1179     -5.5128979682922363e-01
    z[2,3,3]  R1180     -0.838477373123169
    z[2,3,3]  R1181     -2.7604243159294128e-01
    z[2,3,3]  R1182     6.3116061687469482e-01
    z[2,3,3]  R1183     -4.3238624930381775e-02
    z[2,3,3]  R1184     3.6420649290084839e-01
    z[2,3,3]  R1185     -3.9759587496519089e-02
    z[2,3,3]  R1186     -2.7081990242004395e-01
    z[2,3,3]  R1187     3.9089463651180267e-02
    z[2,3,3]  R1188     -1.4939683675765991e-01
    z[2,3,3]  R1189     1.0562177002429962e-01
    z[2,3,3]  R1190     4.4475674629211426e-02
    z[2,3,3]  R1191     2.0891658961772919e-01
    z[2,3,3]  R1192     0.14479960501194
    z[2,3,3]  R1193     -2.2908157110214233e-01
    z[2,3,3]  R1194     -8.4188235923647881e-03
    z[2,3,3]  R1195     3.7611511349678040e-01
    z[2,3,3]  R1196     -2.1606069058179855e-02
    z[2,3,3]  R1197     -2.7403208613395691e-01
    z[2,3,3]  R1198     1.7212149500846863e-01
    z[2,3,3]  R1199     4.7052096575498581e-02
    z[2,3,3]  R1200     -3.6566668748855591e-01
    z[2,3,3]  R1201     -4.7412046790122986e-01
    z[2,3,3]  R1202     -4.2067438364028931e-01
    z[2,3,3]  R1203     -4.8991143703460693e-01
    z[2,3,3]  R1204     -2.5718429684638977e-01
    z[2,3,4]  R24       -1
    z[2,3,4]  R33       1
    z[2,3,4]  R1089     -1
    z[2,3,4]  R1090     1
    z[2,3,4]  R1095     -7.8915923833847046e-02
    z[2,3,4]  R1096     0.428545743227005
    z[2,3,4]  R1097     4.0092658251523972e-02
    z[2,3,4]  R1098     2.3380656540393829e-01
    z[2,3,4]  R1099     6.9126054644584656e-02
    z[2,3,4]  R1100     1.3722635805606842e-02
    z[2,3,4]  R1101     -4.2954348027706146e-02
    z[2,3,4]  R1102     6.9148249924182892e-02
    z[2,3,4]  R1103     7.5694270431995392e-02
    z[2,3,4]  R1104     1.7689904570579529e-01
    z[2,3,4]  R1105     -2.0937469601631165e-01
    z[2,3,4]  R1106     1.7088751494884491e-01
    z[2,3,4]  R1107     2.6169770956039429e-01
    z[2,3,4]  R1108     1.4486806094646454e-01
    z[2,3,4]  R1109     -2.8544503450393677e-01
    z[2,3,4]  R1110     -1.3903099298477173e-01
    z[2,3,4]  R1111     -3.1329038739204407e-01
    z[2,3,4]  R1112     5.2991223335266113e-01
    z[2,3,4]  R1113     -1.5408030152320862e-01
    z[2,3,4]  R1114     -3.4385478496551514e-01
    z[2,3,4]  R1115     0.374213308095932
    z[2,3,4]  R1116     4.6642562747001648e-01
    z[2,3,4]  R1117     -6.1091583967208862e-01
    z[2,3,4]  R1118     -6.4970010519027710e-01
    z[2,3,4]  R1119     -7.3790538311004639e-01
    z[2,3,4]  R1120     -7.9327005147933960e-01
    z[2,3,4]  R1121     5.8784413337707520e-01
    z[2,3,4]  R1122     -5.4279690980911255e-01
    z[2,3,4]  R1123     -1.8567000329494476e-01
    z[2,3,4]  R1124     0.0546242892742157
    z[2,3,4]  R1125     2.1512266248464584e-02
    z[2,3,4]  R1126     -5.9000805020332336e-02
    z[2,3,4]  R1127     -9.3802623450756073e-02
    z[2,3,4]  R1128     -5.2126395702362061e-01
    z[2,3,4]  R1129     -5.5842298269271851e-01
    z[2,3,4]  R1130     3.6576637625694275e-01
    z[2,3,4]  R1131     -5.5177640169858932e-02
    z[2,3,4]  R1132     -1.4764183759689331e-01
    z[2,3,4]  R1133     1.4394259080290794e-02
    z[2,3,4]  R1134     -6.8140465021133423e-01
    z[2,3,4]  R1135     -4.2736735939979553e-01
    z[2,3,4]  R1136     7.8438544273376465e-01
    z[2,3,4]  R1137     -3.9450488984584808e-02
    z[2,3,4]  R1138     -2.9868612065911293e-02
    z[2,3,4]  R1139     -1.2888021767139435e-01
    z[2,3,4]  R1140     1.3152818381786346e-01
    z[2,3,4]  R1141     2.6210722327232361e-01
    z[2,3,4]  R1142     5.1603776216506958e-01
    z[2,3,4]  R1143     3.6167123913764954e-01
    z[2,3,4]  R1144     5.5798208713531494e-01
    z[2,3,4]  R1145     3.4688645601272583e-01
    z[2,3,4]  R1146     5.9636777639389038e-01
    z[2,3,4]  R1147     1.8472562730312347e-01
    z[2,3,4]  R1148     -5.8635283261537552e-02
    z[2,3,4]  R1149     -2.3713652789592743e-01
    z[2,3,4]  R1150     4.5625463128089905e-01
    z[2,3,4]  R1151     1.0159126482903957e-02
    z[2,3,4]  R1152     1.3070702552795410e-01
    z[2,3,4]  R1153     -1.1682728677988052e-01
    z[2,3,4]  R1154     -4.6683631837368011e-02
    z[2,3,4]  R1155     3.4998500347137451e-01
    z[2,3,4]  R1156     1.3148643076419830e-01
    z[2,3,4]  R1157     5.9449046850204468e-01
    z[2,3,4]  R1158     -4.5888105034828186e-01
    z[2,3,4]  R1159     3.9809507131576538e-01
    z[2,3,4]  R1160     -6.9887173175811768e-01
    z[2,3,4]  R1161     3.2974988222122192e-01
    z[2,3,4]  R1162     4.0062639117240906e-01
    z[2,3,4]  R1163     1.9780324399471283e-01
    z[2,3,4]  R1164     -5.7936644554138184e-01
    z[2,3,4]  R1165     -0.341208279132843
    z[2,3,4]  R1166     -2.5814184546470642e-01
    z[2,3,4]  R1167     2.8583295643329620e-03
    z[2,3,4]  R1168     5.9135907888412476e-01
    z[2,3,4]  R1169     2.5743296742439270e-01
    z[2,3,4]  R1170     -5.7720959186553955e-01
    z[2,3,4]  R1171     -5.6938838958740234e-01
    z[2,3,4]  R1172     6.3056260347366333e-01
    z[2,3,4]  R1173     0.110362209379673
    z[2,3,4]  R1174     6.8434321880340576e-01
    z[2,3,4]  R1175     -1.5113914012908936e-01
    z[2,3,4]  R1176     2.0056955516338348e-01
    z[2,3,4]  R1177     4.2378431558609009e-01
    z[2,3,4]  R1178     5.9284854680299759e-02
    z[2,3,4]  R1179     2.3376183211803436e-01
    z[2,3,4]  R1180     1.8640869855880737e-01
    z[2,3,4]  R1181     5.0026741810142994e-03
    z[2,3,4]  R1182     -0.529833972454071
    z[2,3,4]  R1183     -2.1755275130271912e-01
    z[2,3,4]  R1184     3.9323933422565460e-02
    z[2,3,4]  R1185     -2.9293003678321838e-01
    z[2,3,4]  R1186     1.9246637821197510e-01
    z[2,3,4]  R1187     4.1980087757110596e-01
    z[2,3,4]  R1188     -0.105362668633461
    z[2,3,4]  R1189     -9.4741076231002808e-02
    z[2,3,4]  R1190     2.9477930068969727e-01
    z[2,3,4]  R1191     6.4331911504268646e-02
    z[2,3,4]  R1192     -3.6906756460666656e-02
    z[2,3,4]  R1193     -5.6205880641937256e-01
    z[2,3,4]  R1194     -5.7529205083847046e-01
    z[2,3,4]  R1195     -1.3045415282249451e-01
    z[2,3,4]  R1196     -4.6280416846275330e-01
    z[2,3,4]  R1197     6.5524756908416748e-01
    z[2,3,4]  R1198     1.6345609724521637e-01
    z[2,3,4]  R1199     -1.2294919788837433e-01
    z[2,3,4]  R1200     -8.3895868062973022e-01
    z[2,3,4]  R1201     -8.0667078495025635e-01
    z[2,3,4]  R1202     -7.0341515541076660e-01
    z[2,3,4]  R1203     -6.1113911867141724e-01
    z[2,3,4]  R1204     -6.0859465599060059e-01
    z[2,3,5]  R25       -1
    z[2,3,5]  R34       1
    z[2,3,5]  R1091     -1
    z[2,3,5]  R1092     1
    z[2,3,5]  R1095     -7.5600284337997437e-01
    z[2,3,5]  R1096     2.0925825461745262e-02
    z[2,3,5]  R1097     -1.7519956827163696e-01
    z[2,3,5]  R1098     -8.5107326507568359e-02
    z[2,3,5]  R1099     -0.129975363612175
    z[2,3,5]  R1100     -1.1450179852545261e-02
    z[2,3,5]  R1101     -1.1037198454141617e-01
    z[2,3,5]  R1102     -2.7068577706813812e-02
    z[2,3,5]  R1103     -7.5989085435867310e-01
    z[2,3,5]  R1104     -3.5837404429912567e-02
    z[2,3,5]  R1105     3.9327001571655273e-01
    z[2,3,5]  R1106     4.1641193628311157e-01
    z[2,3,5]  R1107     2.6392295956611633e-01
    z[2,3,5]  R1108     3.1351518630981445e-01
    z[2,3,5]  R1109     2.3337078094482422e-01
    z[2,3,5]  R1110     1.4271828532218933e-01
    z[2,3,5]  R1111     2.5921770930290222e-01
    z[2,3,5]  R1112     7.6674565672874451e-02
    z[2,3,5]  R1113     6.4962792396545410e-01
    z[2,3,5]  R1114     1.5710996091365814e-01
    z[2,3,5]  R1115     5.7025891542434692e-01
    z[2,3,5]  R1116     3.2565575838088989e-01
    z[2,3,5]  R1117     -1.7744678258895874e-01
    z[2,3,5]  R1118     4.8563620448112488e-01
    z[2,3,5]  R1119     4.1208315640687943e-02
    z[2,3,5]  R1120     4.6365055441856384e-01
    z[2,3,5]  R1121     0.0964667871594429
    z[2,3,5]  R1122     2.7510568499565125e-01
    z[2,3,5]  R1123     1.1066298931837082e-01
    z[2,3,5]  R1124     -1.0694700479507446e-01
    z[2,3,5]  R1125     -3.7286561727523804e-01
    z[2,3,5]  R1126     -6.1039716005325317e-01
    z[2,3,5]  R1127     1.7148524522781372e-01
    z[2,3,5]  R1128     -8.9085720479488373e-02
    z[2,3,5]  R1129     6.5611422061920166e-02
    z[2,3,5]  R1130     -4.1812869906425476e-01
    z[2,3,5]  R1131     0.286979079246521
    z[2,3,5]  R1132     -1.7271885275840759e-01
    z[2,3,5]  R1133     8.1810927391052246e-01
    z[2,3,5]  R1134     -3.4268322587013245e-01
    z[2,3,5]  R1135     -2.9487481713294983e-01
    z[2,3,5]  R1136     3.1709179282188416e-01
    z[2,3,5]  R1137     -6.1188173294067383e-01
    z[2,3,5]  R1138     -1.8844248354434967e-01
    z[2,3,5]  R1139     -2.4835785850882530e-02
    z[2,3,5]  R1140     1.9847498834133148e-01
    z[2,3,5]  R1141     -4.3695300817489624e-01
    z[2,3,5]  R1142     -3.2630094885826111e-01
    z[2,3,5]  R1143     -1.2975083291530609e-01
    z[2,3,5]  R1144     -2.3591253161430359e-01
    z[2,3,5]  R1145     -0.553044319152832
    z[2,3,5]  R1146     -4.2993504554033279e-02
    z[2,3,5]  R1147     1.1749506741762161e-01
    z[2,3,5]  R1148     1.4075703918933868e-01
    z[2,3,5]  R1149     3.2285955548286438e-01
    z[2,3,5]  R1150     7.0158019661903381e-02
    z[2,3,5]  R1151     -1.0275598615407944e-01
    z[2,3,5]  R1152     0.0361696258187294
    z[2,3,5]  R1153     -3.3468861132860184e-02
    z[2,3,5]  R1154     1.3391450047492981e-01
    z[2,3,5]  R1155     2.3491376638412476e-01
    z[2,3,5]  R1156     5.3270930051803589e-01
    z[2,3,5]  R1157     4.1350486874580383e-01
    z[2,3,5]  R1158     -4.1556110978126526e-01
    z[2,3,5]  R1159     6.7152678966522217e-01
    z[2,3,5]  R1160     -0.263075053691864
    z[2,3,5]  R1161     5.5658805370330811e-01
    z[2,3,5]  R1162     5.5850416421890259e-01
    z[2,3,5]  R1163     5.6426358222961426e-01
    z[2,3,5]  R1164     -3.5225117206573486e-01
    z[2,3,5]  R1165     -5.2893179655075073e-01
    z[2,3,5]  R1166     1.7745985090732574e-01
    z[2,3,5]  R1167     3.4801909327507019e-01
    z[2,3,5]  R1168     2.7866625785827637e-01
    z[2,3,5]  R1169     4.0741279721260071e-01
    z[2,3,5]  R1170     2.2728929296135902e-02
    z[2,3,5]  R1171     -2.8804320096969604e-01
    z[2,3,5]  R1172     5.1546716690063477e-01
    z[2,3,5]  R1173     6.7101502418518066e-01
    z[2,3,5]  R1174     5.8186775445938110e-01
    z[2,3,5]  R1175     -1.0468350723385811e-02
    z[2,3,5]  R1176     5.1003140211105347e-01
    z[2,3,5]  R1177     6.9440108537673950e-01
    z[2,3,5]  R1178     5.5458873510360718e-01
    z[2,3,5]  R1179     0.413343220949173
    z[2,3,5]  R1180     2.9687958955764771e-01
    z[2,3,5]  R1181     -2.5644791126251221e-01
    z[2,3,5]  R1182     -6.2193788588047028e-02
    z[2,3,5]  R1183     -2.6785546541213989e-01
    z[2,3,5]  R1184     3.3473879098892212e-01
    z[2,3,5]  R1185     -4.3114152550697327e-01
    z[2,3,5]  R1186     8.2911419868469238e-01
    z[2,3,5]  R1187     2.9068300127983093e-01
    z[2,3,5]  R1188     2.2954536974430084e-01
    z[2,3,5]  R1189     2.1932075917720795e-01
    z[2,3,5]  R1190     2.2315025329589844e-01
    z[2,3,5]  R1191     2.0577101409435272e-01
    z[2,3,5]  R1192     3.7524858117103577e-01
    z[2,3,5]  R1193     5.0734555721282959e-01
    z[2,3,5]  R1194     4.7492590546607971e-01
    z[2,3,5]  R1195     -2.1041874587535858e-01
    z[2,3,5]  R1196     -2.5743770599365234e-01
    z[2,3,5]  R1197     1.7963384091854095e-01
    z[2,3,5]  R1198     2.0145660638809204e-01
    z[2,3,5]  R1199     -7.7882564067840576e-01
    z[2,3,5]  R1200     3.7007558345794678e-01
    z[2,3,5]  R1201     1.8400555849075317e-01
    z[2,3,5]  R1202     3.5417270660400391e-01
    z[2,3,5]  R1203     4.2507287859916687e-01
    z[2,3,5]  R1204     6.5993052721023560e-01
    z[2,3,6]  R26       -1
    z[2,3,6]  R35       1
    z[2,3,6]  R1093     -1
    z[2,3,6]  R1094     1
    z[2,3,6]  R1095     1.6713712364435196e-02
    z[2,3,6]  R1096     1.3852766156196594e-01
    z[2,3,6]  R1097     -2.6451028883457184e-02
    z[2,3,6]  R1098     6.5301500260829926e-02
    z[2,3,6]  R1099     -2.0380245149135590e-01
    z[2,3,6]  R1100     1.8621627986431122e-01
    z[2,3,6]  R1101     3.7159714102745056e-01
    z[2,3,6]  R1102     5.8207410573959351e-01
    z[2,3,6]  R1103     -9.7229331731796265e-02
    z[2,3,6]  R1104     9.8299160599708557e-02
    z[2,3,6]  R1105     -8.5928887128829956e-02
    z[2,3,6]  R1106     -5.0952263176441193e-02
    z[2,3,6]  R1107     0.290477991104126
    z[2,3,6]  R1108     9.4562888145446777e-02
    z[2,3,6]  R1109     4.1986885666847229e-01
    z[2,3,6]  R1110     -0.355317622423172
    z[2,3,6]  R1111     3.1535494327545166e-01
    z[2,3,6]  R1112     -2.3087418079376221e-01
    z[2,3,6]  R1113     -5.2109336853027344e-01
    z[2,3,6]  R1114     -5.1472866535186768e-01
    z[2,3,6]  R1115     6.4978986978530884e-01
    z[2,3,6]  R1116     1.3804058730602264e-01
    z[2,3,6]  R1117     2.4975056946277618e-01
    z[2,3,6]  R1118     1.1272017657756805e-01
    z[2,3,6]  R1119     -2.0698155462741852e-01
    z[2,3,6]  R1120     -7.2273783385753632e-02
    z[2,3,6]  R1121     4.9550160765647888e-02
    z[2,3,6]  R1122     1.1164902895689011e-01
    z[2,3,6]  R1123     -2.0635692775249481e-01
    z[2,3,6]  R1124     2.0182704925537109e-01
    z[2,3,6]  R1125     -4.6101385354995728e-01
    z[2,3,6]  R1126     2.6499542593955994e-01
    z[2,3,6]  R1127     -1.4004588127136230e-01
    z[2,3,6]  R1128     -4.1854989528656006e-01
    z[2,3,6]  R1129     1.0906316339969635e-01
    z[2,3,6]  R1130     4.3054428696632385e-01
    z[2,3,6]  R1131     0.090914286673069
    z[2,3,6]  R1132     -0.0802655816078186
    z[2,3,6]  R1133     -4.3816640973091125e-01
    z[2,3,6]  R1134     2.2761696577072144e-01
    z[2,3,6]  R1135     6.0557309538125992e-02
    z[2,3,6]  R1136     -8.9875146746635437e-02
    z[2,3,6]  R1137     6.1374053359031677e-02
    z[2,3,6]  R1138     1.6884168609976768e-02
    z[2,3,6]  R1139     4.2412549257278442e-01
    z[2,3,6]  R1140     5.1192098855972290e-01
    z[2,3,6]  R1141     -3.0343142151832581e-01
    z[2,3,6]  R1142     2.0778505504131317e-01
    z[2,3,6]  R1143     -1.2761445343494415e-01
    z[2,3,6]  R1144     -0.400240957736969
    z[2,3,6]  R1145     2.2468097507953644e-01
    z[2,3,6]  R1146     -3.2996791601181030e-01
    z[2,3,6]  R1147     1.4762161672115326e-01
    z[2,3,6]  R1148     -4.5040425658226013e-01
    z[2,3,6]  R1149     1.3805608265101910e-02
    z[2,3,6]  R1150     5.8425735682249069e-02
    z[2,3,6]  R1151     3.9670267701148987e-01
    z[2,3,6]  R1152     0.537770688533783
    z[2,3,6]  R1153     -1.8344806134700775e-01
    z[2,3,6]  R1154     -8.5710622370243073e-02
    z[2,3,6]  R1155     -3.8023035973310471e-02
    z[2,3,6]  R1156     -0.269378125667572
    z[2,3,6]  R1157     -2.0136094093322754e-01
    z[2,3,6]  R1158     -1.4751872420310974e-01
    z[2,3,6]  R1159     -2.1189206838607788e-01
    z[2,3,6]  R1160     -1.0805781185626984e-01
    z[2,3,6]  R1161     -5.5326286703348160e-02
    z[2,3,6]  R1162     -2.1189002692699432e-01
    z[2,3,6]  R1163     4.6170207858085632e-01
    z[2,3,6]  R1164     -1.9464819133281708e-01
    z[2,3,6]  R1165     4.3017691373825073e-01
    z[2,3,6]  R1166     -1.5040473639965057e-01
    z[2,3,6]  R1167     6.3325248658657074e-02
    z[2,3,6]  R1168     1.1317790299654007e-01
    z[2,3,6]  R1169     1.9343329966068268e-01
    z[2,3,6]  R1170     -7.9061530530452728e-02
    z[2,3,6]  R1171     -9.6641272306442261e-02
    z[2,3,6]  R1172     -1.0856087505817413e-01
    z[2,3,6]  R1173     -1.6978496313095093e-01
    z[2,3,6]  R1174     -2.2336056455969810e-02
    z[2,3,6]  R1175     -1.4777894318103790e-01
    z[2,3,6]  R1176     9.7572272352408618e-05
    z[2,3,6]  R1177     -1.1589463800191879e-01
    z[2,3,6]  R1178     2.8197151422500610e-01
    z[2,3,6]  R1179     2.7002471685409546e-01
    z[2,3,6]  R1180     8.2531832158565521e-02
    z[2,3,6]  R1181     -1.7834395170211792e-02
    z[2,3,6]  R1182     1.0257884860038757e-01
    z[2,3,6]  R1183     3.3247941732406616e-01
    z[2,3,6]  R1184     3.5234186798334122e-02
    z[2,3,6]  R1185     0.0984724834561348
    z[2,3,6]  R1186     1.1448633670806885e-01
    z[2,3,6]  R1187     7.1404480934143066e-01
    z[2,3,6]  R1188     -1.8833881616592407e-01
    z[2,3,6]  R1189     -7.0366062223911285e-02
    z[2,3,6]  R1190     6.7802697420120239e-02
    z[2,3,6]  R1191     1.1730934679508209e-01
    z[2,3,6]  R1192     -6.0412295162677765e-02
    z[2,3,6]  R1193     -2.2613309323787689e-01
    z[2,3,6]  R1194     2.3787630721926689e-02
    z[2,3,6]  R1195     7.1329828351736069e-03
    z[2,3,6]  R1196     -7.9224541783332825e-02
    z[2,3,6]  R1197     4.9727505445480347e-01
    z[2,3,6]  R1198     -1.5995460748672485e-01
    z[2,3,6]  R1199     -5.7356536388397217e-01
    z[2,3,6]  R1200     1.2033274024724960e-01
    z[2,3,6]  R1201     -7.1916177868843079e-02
    z[2,3,6]  R1202     -3.6164382100105286e-01
    z[2,3,6]  R1203     -3.1468236446380615e-01
    z[2,3,6]  R1204     -1.3965220749378204e-01
    z[3,2,0]  R20       1
    z[3,2,0]  R29       -1
    z[3,2,0]  R1205     -1
    z[3,2,0]  R1206     1
    z[3,2,0]  R1219     3.8435712456703186e-01
    z[3,2,0]  R1220     4.6964627504348755e-01
    z[3,2,0]  R1221     1.2871317565441132e-01
    z[3,2,0]  R1222     3.3063021302223206e-01
    z[3,2,0]  R1223     -1.5768514573574066e-01
    z[3,2,0]  R1224     -6.0754650831222534e-01
    z[3,2,0]  R1225     -4.4395166635513306e-01
    z[3,2,0]  R1226     -1.7489361763000488e-01
    z[3,2,0]  R1227     -6.6080474853515625e-01
    z[3,2,0]  R1228     -6.0426956415176392e-01
    z[3,2,0]  R1229     -3.8641926646232605e-01
    z[3,2,0]  R1230     -2.2747081518173218e-01
    z[3,2,0]  R1231     -1.8546903133392334e-01
    z[3,2,0]  R1232     -2.2525892127305269e-03
    z[3,2,0]  R1233     -3.2109636068344116e-01
    z[3,2,0]  R1234     -2.2801786661148071e-02
    z[3,2,0]  R1235     -5.9258061647415161e-01
    z[3,2,0]  R1236     -3.0523759126663208e-01
    z[3,2,0]  R1237     -4.9144953489303589e-01
    z[3,2,0]  R1238     3.5981366038322449e-01
    z[3,2,0]  R1239     4.6973848342895508e-01
    z[3,2,0]  R1240     3.7984788417816162e-01
    z[3,2,0]  R1241     3.2363331317901611e-01
    z[3,2,0]  R1242     -1.0073760896921158e-01
    z[3,2,0]  R1243     -5.3915452957153320e-01
    z[3,2,0]  R1244     0.573432981967926
    z[3,2,0]  R1245     5.8630925416946411e-01
    z[3,2,0]  R1246     6.3679113984107971e-02
    z[3,2,0]  R1247     1.5071780420839787e-02
    z[3,2,0]  R1248     1.0220363736152649e-01
    z[3,2,0]  R1249     7.9044562578201294e-01
    z[3,2,0]  R1250     -8.5493430495262146e-02
    z[3,2,0]  R1251     -2.8234678506851196e-01
    z[3,2,0]  R1252     -1.1949960142374039e-01
    z[3,2,0]  R1253     -4.2563432455062866e-01
    z[3,2,0]  R1254     -3.5032281279563904e-01
    z[3,2,0]  R1255     -2.7937644720077515e-01
    z[3,2,0]  R1256     -3.0842721462249756e-01
    z[3,2,0]  R1257     -6.1874139308929443e-01
    z[3,2,0]  R1258     -4.4269609451293945e-01
    z[3,2,0]  R1259     1.0344447195529938e-01
    z[3,2,0]  R1260     -9.6073616296052933e-03
    z[3,2,0]  R1261     -3.5229781270027161e-01
    z[3,2,0]  R1262     2.1113598719239235e-02
    z[3,2,0]  R1263     -1.6194912791252136e-01
    z[3,2,0]  R1264     1.4746780693531036e-01
    z[3,2,0]  R1265     -3.9892011880874634e-01
    z[3,2,0]  R1266     -2.4754211306571960e-01
    z[3,2,0]  R1267     -5.6692034006118774e-01
    z[3,2,0]  R1268     -6.1223447322845459e-01
    z[3,2,0]  R1269     -8.9415594935417175e-02
    z[3,2,0]  R1270     5.4197525978088379e-01
    z[3,2,0]  R1271     -3.4987998008728027e-01
    z[3,2,0]  R1272     -5.3841060400009155e-01
    z[3,2,0]  R1273     1.6175134107470512e-02
    z[3,2,0]  R1274     1.9008865579962730e-02
    z[3,2,0]  R1275     -1.1379750072956085e-01
    z[3,2,0]  R1276     8.3032414317131042e-02
    z[3,2,0]  R1277     -6.1901800334453583e-02
    z[3,2,0]  R1278     2.9676225781440735e-01
    z[3,2,0]  R1279     -2.1391913294792175e-01
    z[3,2,0]  R1280     -2.6369300484657288e-01
    z[3,2,0]  R1281     -2.0321425795555115e-01
    z[3,2,0]  R1282     -1.2211536616086960e-01
    z[3,2,0]  R1283     -2.1548202633857727e-01
    z[3,2,0]  R1284     -5.0030261278152466e-01
    z[3,2,0]  R1285     -0.0824422836303711
    z[3,2,0]  R1286     -6.5397894382476807e-01
    z[3,2,0]  R1287     4.9234387278556824e-01
    z[3,2,0]  R1288     1.8694119155406952e-01
    z[3,2,0]  R1289     1.5439975261688232e-01
    z[3,2,0]  R1290     1.5032652020454407e-01
    z[3,2,0]  R1291     4.4251907616853714e-02
    z[3,2,0]  R1292     -1.5841630101203918e-01
    z[3,2,0]  R1293     -9.2788815498352051e-02
    z[3,2,0]  R1294     -1.2571211159229279e-01
    z[3,2,0]  R1295     -2.2419813275337219e-01
    z[3,2,0]  R1296     2.2780667245388031e-01
    z[3,2,0]  R1297     -3.2894098758697510e-01
    z[3,2,0]  R1298     -2.4866597354412079e-01
    z[3,2,0]  R1299     5.2616402506828308e-02
    z[3,2,0]  R1300     2.7954089641571045e-01
    z[3,2,0]  R1301     6.4820271730422974e-01
    z[3,2,0]  R1302     -1.4740100130438805e-02
    z[3,2,0]  R1303     -4.6165034174919128e-02
    z[3,2,0]  R1304     7.8379977494478226e-03
    z[3,2,0]  R1305     6.3006269931793213e-01
    z[3,2,0]  R1306     1.4017288386821747e-01
    z[3,2,0]  R1307     -2.4023541808128357e-01
    z[3,2,0]  R1308     -3.9358308911323547e-01
    z[3,2,0]  R1309     -1.4701075851917267e-01
    z[3,2,0]  R1310     4.1678366065025330e-01
    z[3,2,0]  R1311     -1.3015897572040558e-01
    z[3,2,0]  R1312     6.1288721859455109e-02
    z[3,2,0]  R1313     -1.8016344308853149e-01
    z[3,2,0]  R1314     2.5706410408020020e-01
    z[3,2,0]  R1315     1.9248086214065552e-01
    z[3,2,0]  R1316     5.2797567844390869e-01
    z[3,2,0]  R1317     -6.0768104158341885e-03
    z[3,2,0]  R1318     -1.8545801937580109e-01
    z[3,2,0]  R1319     3.7204214930534363e-01
    z[3,2,0]  R1320     3.1403880566358566e-02
    z[3,2,0]  R1321     4.0567180514335632e-01
    z[3,2,0]  R1322     2.0946851000189781e-03
    z[3,2,0]  R1323     -1.9522626698017120e-01
    z[3,2,0]  R1324     1.6009330749511719e-01
    z[3,2,0]  R1325     5.6637412309646606e-01
    z[3,2,0]  R1326     1.4716935157775879e-01
    z[3,2,0]  R1327     2.0530971884727478e-01
    z[3,2,0]  R1328     2.2877733409404755e-01
    z[3,2,1]  R21       1
    z[3,2,1]  R30       -1
    z[3,2,1]  R1207     -1
    z[3,2,1]  R1208     1
    z[3,2,1]  R1219     -3.8943392038345337e-01
    z[3,2,1]  R1220     1.0056421905755997e-01
    z[3,2,1]  R1221     1.5411810576915741e-01
    z[3,2,1]  R1222     -7.9090172052383423e-01
    z[3,2,1]  R1223     -0.0875360444188118
    z[3,2,1]  R1224     -6.2563389539718628e-01
    z[3,2,1]  R1225     -0.704354465007782
    z[3,2,1]  R1226     -7.9132989048957825e-02
    z[3,2,1]  R1227     -6.2296229600906372e-01
    z[3,2,1]  R1228     -6.6563093662261963e-01
    z[3,2,1]  R1229     -4.1182957589626312e-02
    z[3,2,1]  R1230     -3.4564676880836487e-01
    z[3,2,1]  R1231     2.8088864684104919e-01
    z[3,2,1]  R1232     3.0188298225402832e-01
    z[3,2,1]  R1233     6.1274491250514984e-02
    z[3,2,1]  R1234     0.0978856310248375
    z[3,2,1]  R1235     2.0466198027133942e-01
    z[3,2,1]  R1236     6.6788643598556519e-03
    z[3,2,1]  R1237     1.1274852603673935e-01
    z[3,2,1]  R1238     4.3839445710182190e-01
    z[3,2,1]  R1239     3.5533255338668823e-01
    z[3,2,1]  R1240     -6.9836688041687012e-01
    z[3,2,1]  R1241     -3.9601841568946838e-01
    z[3,2,1]  R1242     1.1077233403921127e-01
    z[3,2,1]  R1243     2.0387648046016693e-01
    z[3,2,1]  R1244     -2.1392878890037537e-01
    z[3,2,1]  R1245     3.0866166949272156e-01
    z[3,2,1]  R1246     -1.5111443400382996e-01
    z[3,2,1]  R1247     2.5715095922350883e-02
    z[3,2,1]  R1248     -1.4068578183650970e-01
    z[3,2,1]  R1249     -0.302144318819046
    z[3,2,1]  R1250     3.4736540168523788e-02
    z[3,2,1]  R1251     -1.4574143290519714e-01
    z[3,2,1]  R1252     -2.2250409424304962e-01
    z[3,2,1]  R1253     -4.6310713887214661e-01
    z[3,2,1]  R1254     2.1093061566352844e-01
    z[3,2,1]  R1255     -8.5881382226943970e-01
    z[3,2,1]  R1256     -4.4231769442558289e-01
    z[3,2,1]  R1257     -0.606364369392395
    z[3,2,1]  R1258     -7.1295052766799927e-01
    z[3,2,1]  R1259     7.0980495214462280e-01
    z[3,2,1]  R1260     -4.2589294910430908e-01
    z[3,2,1]  R1261     -1.5035982429981232e-01
    z[3,2,1]  R1262     9.3660390377044678e-01
    z[3,2,1]  R1263     9.3908828496932983e-01
    z[3,2,1]  R1264     8.6301565170288086e-01
    z[3,2,1]  R1265     5.0970077514648438e-01
    z[3,2,1]  R1266     7.0335948467254639e-01
    z[3,2,1]  R1267     2.9809432104229927e-02
    z[3,2,1]  R1268     -9.8309412598609924e-02
    z[3,2,1]  R1269     6.9336611032485962e-01
    z[3,2,1]  R1270     -6.0947406291961670e-01
    z[3,2,1]  R1271     -2.0571936666965485e-01
    z[3,2,1]  R1272     -7.4226832389831543e-01
    z[3,2,1]  R1273     1.8295995891094208e-01
    z[3,2,1]  R1274     6.1455290764570236e-02
    z[3,2,1]  R1275     1.7191922664642334e-01
    z[3,2,1]  R1276     2.5506317615509033e-01
    z[3,2,1]  R1277     9.5106415450572968e-02
    z[3,2,1]  R1278     -8.0855406820774078e-02
    z[3,2,1]  R1279     3.6962968111038208e-01
    z[3,2,1]  R1280     -2.2585336863994598e-01
    z[3,2,1]  R1281     -6.3878291845321655e-01
    z[3,2,1]  R1282     -0.637885332107544
    z[3,2,1]  R1283     -6.2792015075683594e-01
    z[3,2,1]  R1284     -2.5551816448569298e-02
    z[3,2,1]  R1285     -5.1065891981124878e-01
    z[3,2,1]  R1286     -1.5931475162506104e-01
    z[3,2,1]  R1287     3.9877825975418091e-01
    z[3,2,1]  R1288     -3.3519566059112549e-01
    z[3,2,1]  R1289     7.4821001291275024e-01
    z[3,2,1]  R1290     6.2233549356460571e-01
    z[3,2,1]  R1291     7.0716559886932373e-01
    z[3,2,1]  R1292     3.4581381082534790e-01
    z[3,2,1]  R1293     6.0509526729583740e-01
    z[3,2,1]  R1294     4.4489392638206482e-01
    z[3,2,1]  R1295     3.5442498326301575e-01
    z[3,2,1]  R1296     7.3422580957412720e-01
    z[3,2,1]  R1297     2.3457735776901245e-01
    z[3,2,1]  R1298     -9.4344671815633774e-03
    z[3,2,1]  R1299     -2.1630187332630157e-01
    z[3,2,1]  R1300     2.5966829061508179e-01
    z[3,2,1]  R1301     -8.5281684994697571e-02
    z[3,2,1]  R1302     -3.4813082218170166e-01
    z[3,2,1]  R1303     1.0931760072708130e-01
    z[3,2,1]  R1304     1.7637154459953308e-01
    z[3,2,1]  R1305     2.9924153932370245e-04
    z[3,2,1]  R1306     -1.2882173061370850e-01
    z[3,2,1]  R1307     -8.5850799083709717e-01
    z[3,2,1]  R1308     -7.5027018785476685e-01
    z[3,2,1]  R1309     4.6310821175575256e-01
    z[3,2,1]  R1310     -2.0021395385265350e-01
    z[3,2,1]  R1311     4.8950418829917908e-01
    z[3,2,1]  R1312     9.9311359226703644e-02
    z[3,2,1]  R1313     1.8918801844120026e-01
    z[3,2,1]  R1314     3.7089128047227859e-02
    z[3,2,1]  R1315     1.0083258152008057e-01
    z[3,2,1]  R1316     3.7639137357473373e-02
    z[3,2,1]  R1317     -2.0759311318397522e-01
    z[3,2,1]  R1318     -9.5413953065872192e-02
    z[3,2,1]  R1319     7.0166522264480591e-01
    z[3,2,1]  R1320     -3.6928680539131165e-01
    z[3,2,1]  R1321     3.2252028584480286e-01
    z[3,2,1]  R1322     8.6657595634460449e-01
    z[3,2,1]  R1323     0.43874591588974
    z[3,2,1]  R1324     0.78117436170578
    z[3,2,1]  R1325     5.4525947570800781e-01
    z[3,2,1]  R1326     1.4030268788337708e-01
    z[3,2,1]  R1327     -2.6873552799224854e-01
    z[3,2,1]  R1328     -4.1345305740833282e-02
    z[3,2,2]  R22       1
    z[3,2,2]  R31       -1
    z[3,2,2]  R1209     -1
    z[3,2,2]  R1210     1
    z[3,2,2]  R1219     -1.3613632321357727e-01
    z[3,2,2]  R1220     -3.2119369506835938e-01
    z[3,2,2]  R1221     0.11175537109375
    z[3,2,2]  R1222     3.1654998660087585e-02
    z[3,2,2]  R1223     8.4770750999450684e-01
    z[3,2,2]  R1224     -1.4828373491764069e-01
    z[3,2,2]  R1225     2.9359790682792664e-01
    z[3,2,2]  R1226     0.686779260635376
    z[3,2,2]  R1227     -3.4933474659919739e-01
    z[3,2,2]  R1228     -1.5206056833267212e-01
    z[3,2,2]  R1229     1.1364550888538361e-01
    z[3,2,2]  R1230     3.4251266717910767e-01
    z[3,2,2]  R1231     8.4152139723300934e-02
    z[3,2,2]  R1232     -7.0116829872131348e-01
    z[3,2,2]  R1233     0.310958594083786
    z[3,2,2]  R1234     -4.8581293225288391e-01
    z[3,2,2]  R1235     1.5351407229900360e-01
    z[3,2,2]  R1236     -2.2517786920070648e-01
    z[3,2,2]  R1237     2.1858850494027138e-02
    z[3,2,2]  R1238     -4.2397168278694153e-01
    z[3,2,2]  R1239     1.2479174137115479e-01
    z[3,2,2]  R1240     4.9236118793487549e-01
    z[3,2,2]  R1241     7.7350640296936035e-01
    z[3,2,2]  R1242     4.2019265890121460e-01
    z[3,2,2]  R1243     3.5428783297538757e-01
    z[3,2,2]  R1244     3.6612513661384583e-01
    z[3,2,2]  R1245     1.0885686427354813e-01
    z[3,2,2]  R1246     5.1020783185958862e-01
    z[3,2,2]  R1247     6.2840634584426880e-01
    z[3,2,2]  R1248     9.5704257488250732e-02
    z[3,2,2]  R1249     4.8155072331428528e-01
    z[3,2,2]  R1250     0.616873025894165
    z[3,2,2]  R1251     4.6412819623947144e-01
    z[3,2,2]  R1252     1.1298055946826935e-01
    z[3,2,2]  R1253     4.5124284923076630e-02
    z[3,2,2]  R1254     6.3735512085258961e-03
    z[3,2,2]  R1255     -2.0513303577899933e-01
    z[3,2,2]  R1256     -1.2549702823162079e-01
    z[3,2,2]  R1257     -1.3414016366004944e-01
    z[3,2,2]  R1258     2.1963019669055939e-01
    z[3,2,2]  R1259     -4.5000827312469482e-01
    z[3,2,2]  R1260     8.7170645594596863e-02
    z[3,2,2]  R1261     2.8488731384277344e-01
    z[3,2,2]  R1262     2.7279371395707130e-02
    z[3,2,2]  R1263     -1.3675086200237274e-01
    z[3,2,2]  R1264     3.0031827092170715e-01
    z[3,2,2]  R1265     -6.9078212976455688e-01
    z[3,2,2]  R1266     -5.2651494741439819e-01
    z[3,2,2]  R1267     2.8083970770239830e-02
    z[3,2,2]  R1268     2.4156154692173004e-01
    z[3,2,2]  R1269     -5.5537432432174683e-01
    z[3,2,2]  R1270     2.1817199885845184e-01
    z[3,2,2]  R1271     2.2642841935157776e-01
    z[3,2,2]  R1272     -1.9141036272048950e-01
    z[3,2,2]  R1273     1.1570196598768234e-01
    z[3,2,2]  R1274     -0.0828382596373558
    z[3,2,2]  R1275     2.0725773274898529e-01
    z[3,2,2]  R1276     8.0018816515803337e-03
    z[3,2,2]  R1277     -3.0644190311431885e-01
    z[3,2,2]  R1278     -1.1769544333219528e-01
    z[3,2,2]  R1279     -1.7148266732692719e-01
    z[3,2,2]  R1280     8.2171314954757690e-01
    z[3,2,2]  R1281     0.659396231174469
    z[3,2,2]  R1282     2.9673033952713013e-01
    z[3,2,2]  R1283     4.8074802756309509e-01
    z[3,2,2]  R1284     8.3655959367752075e-01
    z[3,2,2]  R1285     6.2870103120803833e-01
    z[3,2,2]  R1286     4.0047213435173035e-01
    z[3,2,2]  R1287     -5.6966669857501984e-02
    z[3,2,2]  R1288     7.4343693256378174e-01
    z[3,2,2]  R1289     -4.4365558028221130e-01
    z[3,2,2]  R1290     -5.0853508710861206e-01
    z[3,2,2]  R1291     -5.2227860689163208e-01
    z[3,2,2]  R1292     -8.5057616233825684e-01
    z[3,2,2]  R1293     -5.3677064180374146e-01
    z[3,2,2]  R1294     -7.6897680759429932e-01
    z[3,2,2]  R1295     -7.4780440330505371e-01
    z[3,2,2]  R1296     -2.5453430414199829e-01
    z[3,2,2]  R1297     3.2538837194442749e-01
    z[3,2,2]  R1298     1.6030944883823395e-01
    z[3,2,2]  R1299     0.250957727432251
    z[3,2,2]  R1300     2.2730448842048645e-01
    z[3,2,2]  R1301     -2.0786218345165253e-01
    z[3,2,2]  R1302     7.3982700705528259e-02
    z[3,2,2]  R1303     -1.1089028790593147e-02
    z[3,2,2]  R1304     -2.5956982374191284e-01
    z[3,2,2]  R1305     2.1277728676795959e-01
    z[3,2,2]  R1306     4.4958975911140442e-01
    z[3,2,2]  R1307     -6.7659132182598114e-02
    z[3,2,2]  R1308     -2.0726792514324188e-01
    z[3,2,2]  R1309     -0.559663712978363
    z[3,2,2]  R1310     -5.7365173101425171e-01
    z[3,2,2]  R1311     -8.0755275487899780e-01
    z[3,2,2]  R1312     -5.2722561359405518e-01
    z[3,2,2]  R1313     -4.7982862591743469e-01
    z[3,2,2]  R1314     -0.598857045173645
    z[3,2,2]  R1315     0.886725664138794
    z[3,2,2]  R1316     -7.9085886478424072e-01
    z[3,2,2]  R1317     1.1493320018053055e-01
    z[3,2,2]  R1318     -5.6808573007583618e-01
    z[3,2,2]  R1319     -1.2841895222663879e-01
    z[3,2,2]  R1320     2.0998318493366241e-01
    z[3,2,2]  R1321     -4.9523675441741943e-01
    z[3,2,2]  R1322     -0.351829469203949
    z[3,2,2]  R1323     -5.7935726642608643e-01
    z[3,2,2]  R1324     -1.5869230031967163e-01
    z[3,2,2]  R1325     -1.7285600304603577e-01
    z[3,2,2]  R1326     3.6849480867385864e-01
    z[3,2,2]  R1327     4.0468290448188782e-01
    z[3,2,2]  R1328     3.7011903524398804e-01
    z[3,2,3]  R23       1
    z[3,2,3]  R32       -1
    z[3,2,3]  R1211     -1
    z[3,2,3]  R1212     1
    z[3,2,3]  R1219     4.5321959257125854e-01
    z[3,2,3]  R1220     4.4695851206779480e-01
    z[3,2,3]  R1221     9.3673390150070190e-01
    z[3,2,3]  R1222     1.9504196941852570e-01
    z[3,2,3]  R1223     -2.9698863625526428e-01
    z[3,2,3]  R1224     -0.0312623456120491
    z[3,2,3]  R1225     -2.2925306856632233e-01
    z[3,2,3]  R1226     -4.2882928252220154e-01
    z[3,2,3]  R1227     6.9269701838493347e-02
    z[3,2,3]  R1228     3.7578254938125610e-01
    z[3,2,3]  R1229     -8.1052398681640625e-01
    z[3,2,3]  R1230     -5.8123838901519775e-01
    z[3,2,3]  R1231     -0.560954213142395
    z[3,2,3]  R1232     1.1045350879430771e-01
    z[3,2,3]  R1233     -3.7698951363563538e-01
    z[3,2,3]  R1234     4.2962488532066345e-01
    z[3,2,3]  R1235     -4.0225467085838318e-01
    z[3,2,3]  R1236     -5.8202630281448364e-01
    z[3,2,3]  R1237     -4.1785049438476562e-01
    z[3,2,3]  R1238     -3.0952779576182365e-02
    z[3,2,3]  R1239     2.3720730841159821e-01
    z[3,2,3]  R1240     6.9490201771259308e-02
    z[3,2,3]  R1241     1.2240605801343918e-01
    z[3,2,3]  R1242     -6.0070788860321045e-01
    z[3,2,3]  R1243     -0.522066593170166
    z[3,2,3]  R1244     3.8913151621818542e-01
    z[3,2,3]  R1245     3.6415389180183411e-01
    z[3,2,3]  R1246     -1.9415524601936340e-01
    z[3,2,3]  R1247     -3.3607918024063110e-01
    z[3,2,3]  R1248     -3.9141789078712463e-01
    z[3,2,3]  R1249     -8.4982894361019135e-02
    z[3,2,3]  R1250     -5.5730760097503662e-01
    z[3,2,3]  R1251     -9.1690264642238617e-02
    z[3,2,3]  R1252     -7.2996979951858521e-01
    z[3,2,3]  R1253     -5.5128979682922363e-01
    z[3,2,3]  R1254     -0.838477373123169
    z[3,2,3]  R1255     -2.7604243159294128e-01
    z[3,2,3]  R1256     6.3116061687469482e-01
    z[3,2,3]  R1257     -4.3238624930381775e-02
    z[3,2,3]  R1258     3.6420649290084839e-01
    z[3,2,3]  R1259     -3.9759587496519089e-02
    z[3,2,3]  R1260     -2.7081990242004395e-01
    z[3,2,3]  R1261     3.9089463651180267e-02
    z[3,2,3]  R1262     -1.4939683675765991e-01
    z[3,2,3]  R1263     1.0562177002429962e-01
    z[3,2,3]  R1264     4.4475674629211426e-02
    z[3,2,3]  R1265     2.0891658961772919e-01
    z[3,2,3]  R1266     0.14479960501194
    z[3,2,3]  R1267     -2.2908157110214233e-01
    z[3,2,3]  R1268     -8.4188235923647881e-03
    z[3,2,3]  R1269     3.7611511349678040e-01
    z[3,2,3]  R1270     -2.1606069058179855e-02
    z[3,2,3]  R1271     -2.7403208613395691e-01
    z[3,2,3]  R1272     1.7212149500846863e-01
    z[3,2,3]  R1273     4.7052096575498581e-02
    z[3,2,3]  R1274     -3.6566668748855591e-01
    z[3,2,3]  R1275     -4.7412046790122986e-01
    z[3,2,3]  R1276     -4.2067438364028931e-01
    z[3,2,3]  R1277     -4.8991143703460693e-01
    z[3,2,3]  R1278     -2.5718429684638977e-01
    z[3,2,3]  R1279     4.5843076705932617e-01
    z[3,2,3]  R1280     -3.1058143824338913e-02
    z[3,2,3]  R1281     2.8784537315368652e-01
    z[3,2,3]  R1282     6.5112829208374023e-01
    z[3,2,3]  R1283     5.1474034786224365e-01
    z[3,2,3]  R1284     -1.1923284828662872e-01
    z[3,2,3]  R1285     4.3017926812171936e-01
    z[3,2,3]  R1286     -2.0549426972866058e-01
    z[3,2,3]  R1287     -5.2066117525100708e-02
    z[3,2,3]  R1288     5.0769889354705811e-01
    z[3,2,3]  R1289     1.1674515157938004e-01
    z[3,2,3]  R1290     3.5537999868392944e-01
    z[3,2,3]  R1291     -5.1625583320856094e-02
    z[3,2,3]  R1292     6.0137853026390076e-02
    z[3,2,3]  R1293     -0.157786563038826
    z[3,2,3]  R1294     -1.7026992142200470e-01
    z[3,2,3]  R1295     -1.0650216601788998e-02
    z[3,2,3]  R1296     6.5115690231323242e-02
    z[3,2,3]  R1297     1.1661132425069809e-01
    z[3,2,3]  R1298     -7.1028995513916016e-01
    z[3,2,3]  R1299     2.7433764189481735e-03
    z[3,2,3]  R1300     -6.7830830812454224e-01
    z[3,2,3]  R1301     2.4954505264759064e-01
    z[3,2,3]  R1302     -4.4995075464248657e-01
    z[3,2,3]  R1303     -6.2988221645355225e-01
    z[3,2,3]  R1304     -2.2799676656723022e-01
    z[3,2,3]  R1305     4.4768846035003662e-01
    z[3,2,3]  R1306     -6.1550658941268921e-01
    z[3,2,3]  R1307     -3.3372217416763306e-01
    z[3,2,3]  R1308     -4.2903545498847961e-01
    z[3,2,3]  R1309     3.1411767005920410e-01
    z[3,2,3]  R1310     1.0412068665027618e-01
    z[3,2,3]  R1311     1.8298628926277161e-01
    z[3,2,3]  R1312     5.0356507301330566e-01
    z[3,2,3]  R1313     6.1112821102142334e-01
    z[3,2,3]  R1314     2.8271466493606567e-01
    z[3,2,3]  R1315     -2.6987859606742859e-01
    z[3,2,3]  R1316     1.9051222503185272e-01
    z[3,2,3]  R1317     -2.8663340210914612e-01
    z[3,2,3]  R1318     -1.5051684342324734e-02
    z[3,2,3]  R1319     2.8195375204086304e-01
    z[3,2,3]  R1320     -3.0767318606376648e-01
    z[3,2,3]  R1321     -3.2623484730720520e-01
    z[3,2,3]  R1322     -2.9760724306106567e-01
    z[3,2,3]  R1323     4.8644068837165833e-01
    z[3,2,3]  R1324     1.4212132990360260e-01
    z[3,2,3]  R1325     -1.8289128318428993e-02
    z[3,2,3]  R1326     6.3790738582611084e-01
    z[3,2,3]  R1327     7.4694973230361938e-01
    z[3,2,3]  R1328     5.3082180023193359e-01
    z[3,2,4]  R24       1
    z[3,2,4]  R33       -1
    z[3,2,4]  R1213     -1
    z[3,2,4]  R1214     1
    z[3,2,4]  R1219     3.4688645601272583e-01
    z[3,2,4]  R1220     5.9636777639389038e-01
    z[3,2,4]  R1221     1.8472562730312347e-01
    z[3,2,4]  R1222     -5.8635283261537552e-02
    z[3,2,4]  R1223     -2.3713652789592743e-01
    z[3,2,4]  R1224     4.5625463128089905e-01
    z[3,2,4]  R1225     1.0159126482903957e-02
    z[3,2,4]  R1226     1.3070702552795410e-01
    z[3,2,4]  R1227     -1.1682728677988052e-01
    z[3,2,4]  R1228     -4.6683631837368011e-02
    z[3,2,4]  R1229     3.4998500347137451e-01
    z[3,2,4]  R1230     1.3148643076419830e-01
    z[3,2,4]  R1231     5.9449046850204468e-01
    z[3,2,4]  R1232     -4.5888105034828186e-01
    z[3,2,4]  R1233     3.9809507131576538e-01
    z[3,2,4]  R1234     -6.9887173175811768e-01
    z[3,2,4]  R1235     3.2974988222122192e-01
    z[3,2,4]  R1236     4.0062639117240906e-01
    z[3,2,4]  R1237     1.9780324399471283e-01
    z[3,2,4]  R1238     -5.7936644554138184e-01
    z[3,2,4]  R1239     -0.341208279132843
    z[3,2,4]  R1240     -2.5814184546470642e-01
    z[3,2,4]  R1241     2.8583295643329620e-03
    z[3,2,4]  R1242     5.9135907888412476e-01
    z[3,2,4]  R1243     2.5743296742439270e-01
    z[3,2,4]  R1244     -5.7720959186553955e-01
    z[3,2,4]  R1245     -5.6938838958740234e-01
    z[3,2,4]  R1246     6.3056260347366333e-01
    z[3,2,4]  R1247     0.110362209379673
    z[3,2,4]  R1248     6.8434321880340576e-01
    z[3,2,4]  R1249     -1.5113914012908936e-01
    z[3,2,4]  R1250     2.0056955516338348e-01
    z[3,2,4]  R1251     4.2378431558609009e-01
    z[3,2,4]  R1252     5.9284854680299759e-02
    z[3,2,4]  R1253     2.3376183211803436e-01
    z[3,2,4]  R1254     1.8640869855880737e-01
    z[3,2,4]  R1255     5.0026741810142994e-03
    z[3,2,4]  R1256     -0.529833972454071
    z[3,2,4]  R1257     -2.1755275130271912e-01
    z[3,2,4]  R1258     3.9323933422565460e-02
    z[3,2,4]  R1259     -2.9293003678321838e-01
    z[3,2,4]  R1260     1.9246637821197510e-01
    z[3,2,4]  R1261     4.1980087757110596e-01
    z[3,2,4]  R1262     -0.105362668633461
    z[3,2,4]  R1263     -9.4741076231002808e-02
    z[3,2,4]  R1264     2.9477930068969727e-01
    z[3,2,4]  R1265     6.4331911504268646e-02
    z[3,2,4]  R1266     -3.6906756460666656e-02
    z[3,2,4]  R1267     -5.6205880641937256e-01
    z[3,2,4]  R1268     -5.7529205083847046e-01
    z[3,2,4]  R1269     -1.3045415282249451e-01
    z[3,2,4]  R1270     -4.6280416846275330e-01
    z[3,2,4]  R1271     6.5524756908416748e-01
    z[3,2,4]  R1272     1.6345609724521637e-01
    z[3,2,4]  R1273     -1.2294919788837433e-01
    z[3,2,4]  R1274     -8.3895868062973022e-01
    z[3,2,4]  R1275     -8.0667078495025635e-01
    z[3,2,4]  R1276     -7.0341515541076660e-01
    z[3,2,4]  R1277     -6.1113911867141724e-01
    z[3,2,4]  R1278     -6.0859465599060059e-01
    z[3,2,4]  R1279     -7.8915923833847046e-02
    z[3,2,4]  R1280     0.428545743227005
    z[3,2,4]  R1281     4.0092658251523972e-02
    z[3,2,4]  R1282     2.3380656540393829e-01
    z[3,2,4]  R1283     6.9126054644584656e-02
    z[3,2,4]  R1284     1.3722635805606842e-02
    z[3,2,4]  R1285     -4.2954348027706146e-02
    z[3,2,4]  R1286     6.9148249924182892e-02
    z[3,2,4]  R1287     7.5694270431995392e-02
    z[3,2,4]  R1288     1.7689904570579529e-01
    z[3,2,4]  R1289     -2.0937469601631165e-01
    z[3,2,4]  R1290     1.7088751494884491e-01
    z[3,2,4]  R1291     2.6169770956039429e-01
    z[3,2,4]  R1292     1.4486806094646454e-01
    z[3,2,4]  R1293     -2.8544503450393677e-01
    z[3,2,4]  R1294     -1.3903099298477173e-01
    z[3,2,4]  R1295     -3.1329038739204407e-01
    z[3,2,4]  R1296     5.2991223335266113e-01
    z[3,2,4]  R1297     -1.5408030152320862e-01
    z[3,2,4]  R1298     -3.4385478496551514e-01
    z[3,2,4]  R1299     0.374213308095932
    z[3,2,4]  R1300     4.6642562747001648e-01
    z[3,2,4]  R1301     -6.1091583967208862e-01
    z[3,2,4]  R1302     -6.4970010519027710e-01
    z[3,2,4]  R1303     -7.3790538311004639e-01
    z[3,2,4]  R1304     -7.9327005147933960e-01
    z[3,2,4]  R1305     5.8784413337707520e-01
    z[3,2,4]  R1306     -5.4279690980911255e-01
    z[3,2,4]  R1307     -1.8567000329494476e-01
    z[3,2,4]  R1308     0.0546242892742157
    z[3,2,4]  R1309     2.1512266248464584e-02
    z[3,2,4]  R1310     -5.9000805020332336e-02
    z[3,2,4]  R1311     -9.3802623450756073e-02
    z[3,2,4]  R1312     -5.2126395702362061e-01
    z[3,2,4]  R1313     -5.5842298269271851e-01
    z[3,2,4]  R1314     3.6576637625694275e-01
    z[3,2,4]  R1315     -5.5177640169858932e-02
    z[3,2,4]  R1316     -1.4764183759689331e-01
    z[3,2,4]  R1317     1.4394259080290794e-02
    z[3,2,4]  R1318     -6.8140465021133423e-01
    z[3,2,4]  R1319     -4.2736735939979553e-01
    z[3,2,4]  R1320     7.8438544273376465e-01
    z[3,2,4]  R1321     -3.9450488984584808e-02
    z[3,2,4]  R1322     -2.9868612065911293e-02
    z[3,2,4]  R1323     -1.2888021767139435e-01
    z[3,2,4]  R1324     1.3152818381786346e-01
    z[3,2,4]  R1325     2.6210722327232361e-01
    z[3,2,4]  R1326     5.1603776216506958e-01
    z[3,2,4]  R1327     3.6167123913764954e-01
    z[3,2,4]  R1328     5.5798208713531494e-01
    z[3,2,5]  R25       1
    z[3,2,5]  R34       -1
    z[3,2,5]  R1215     -1
    z[3,2,5]  R1216     1
    z[3,2,5]  R1219     -0.553044319152832
    z[3,2,5]  R1220     -4.2993504554033279e-02
    z[3,2,5]  R1221     1.1749506741762161e-01
    z[3,2,5]  R1222     1.4075703918933868e-01
    z[3,2,5]  R1223     3.2285955548286438e-01
    z[3,2,5]  R1224     7.0158019661903381e-02
    z[3,2,5]  R1225     -1.0275598615407944e-01
    z[3,2,5]  R1226     0.0361696258187294
    z[3,2,5]  R1227     -3.3468861132860184e-02
    z[3,2,5]  R1228     1.3391450047492981e-01
    z[3,2,5]  R1229     2.3491376638412476e-01
    z[3,2,5]  R1230     5.3270930051803589e-01
    z[3,2,5]  R1231     4.1350486874580383e-01
    z[3,2,5]  R1232     -4.1556110978126526e-01
    z[3,2,5]  R1233     6.7152678966522217e-01
    z[3,2,5]  R1234     -0.263075053691864
    z[3,2,5]  R1235     5.5658805370330811e-01
    z[3,2,5]  R1236     5.5850416421890259e-01
    z[3,2,5]  R1237     5.6426358222961426e-01
    z[3,2,5]  R1238     -3.5225117206573486e-01
    z[3,2,5]  R1239     -5.2893179655075073e-01
    z[3,2,5]  R1240     1.7745985090732574e-01
    z[3,2,5]  R1241     3.4801909327507019e-01
    z[3,2,5]  R1242     2.7866625785827637e-01
    z[3,2,5]  R1243     4.0741279721260071e-01
    z[3,2,5]  R1244     2.2728929296135902e-02
    z[3,2,5]  R1245     -2.8804320096969604e-01
    z[3,2,5]  R1246     5.1546716690063477e-01
    z[3,2,5]  R1247     6.7101502418518066e-01
    z[3,2,5]  R1248     5.8186775445938110e-01
    z[3,2,5]  R1249     -1.0468350723385811e-02
    z[3,2,5]  R1250     5.1003140211105347e-01
    z[3,2,5]  R1251     6.9440108537673950e-01
    z[3,2,5]  R1252     5.5458873510360718e-01
    z[3,2,5]  R1253     0.413343220949173
    z[3,2,5]  R1254     2.9687958955764771e-01
    z[3,2,5]  R1255     -2.5644791126251221e-01
    z[3,2,5]  R1256     -6.2193788588047028e-02
    z[3,2,5]  R1257     -2.6785546541213989e-01
    z[3,2,5]  R1258     3.3473879098892212e-01
    z[3,2,5]  R1259     -4.3114152550697327e-01
    z[3,2,5]  R1260     8.2911419868469238e-01
    z[3,2,5]  R1261     2.9068300127983093e-01
    z[3,2,5]  R1262     2.2954536974430084e-01
    z[3,2,5]  R1263     2.1932075917720795e-01
    z[3,2,5]  R1264     2.2315025329589844e-01
    z[3,2,5]  R1265     2.0577101409435272e-01
    z[3,2,5]  R1266     3.7524858117103577e-01
    z[3,2,5]  R1267     5.0734555721282959e-01
    z[3,2,5]  R1268     4.7492590546607971e-01
    z[3,2,5]  R1269     -2.1041874587535858e-01
    z[3,2,5]  R1270     -2.5743770599365234e-01
    z[3,2,5]  R1271     1.7963384091854095e-01
    z[3,2,5]  R1272     2.0145660638809204e-01
    z[3,2,5]  R1273     -7.7882564067840576e-01
    z[3,2,5]  R1274     3.7007558345794678e-01
    z[3,2,5]  R1275     1.8400555849075317e-01
    z[3,2,5]  R1276     3.5417270660400391e-01
    z[3,2,5]  R1277     4.2507287859916687e-01
    z[3,2,5]  R1278     6.5993052721023560e-01
    z[3,2,5]  R1279     -7.5600284337997437e-01
    z[3,2,5]  R1280     2.0925825461745262e-02
    z[3,2,5]  R1281     -1.7519956827163696e-01
    z[3,2,5]  R1282     -8.5107326507568359e-02
    z[3,2,5]  R1283     -0.129975363612175
    z[3,2,5]  R1284     -1.1450179852545261e-02
    z[3,2,5]  R1285     -1.1037198454141617e-01
    z[3,2,5]  R1286     -2.7068577706813812e-02
    z[3,2,5]  R1287     -7.5989085435867310e-01
    z[3,2,5]  R1288     -3.5837404429912567e-02
    z[3,2,5]  R1289     3.9327001571655273e-01
    z[3,2,5]  R1290     4.1641193628311157e-01
    z[3,2,5]  R1291     2.6392295956611633e-01
    z[3,2,5]  R1292     3.1351518630981445e-01
    z[3,2,5]  R1293     2.3337078094482422e-01
    z[3,2,5]  R1294     1.4271828532218933e-01
    z[3,2,5]  R1295     2.5921770930290222e-01
    z[3,2,5]  R1296     7.6674565672874451e-02
    z[3,2,5]  R1297     6.4962792396545410e-01
    z[3,2,5]  R1298     1.5710996091365814e-01
    z[3,2,5]  R1299     5.7025891542434692e-01
    z[3,2,5]  R1300     3.2565575838088989e-01
    z[3,2,5]  R1301     -1.7744678258895874e-01
    z[3,2,5]  R1302     4.8563620448112488e-01
    z[3,2,5]  R1303     4.1208315640687943e-02
    z[3,2,5]  R1304     4.6365055441856384e-01
    z[3,2,5]  R1305     0.0964667871594429
    z[3,2,5]  R1306     2.7510568499565125e-01
    z[3,2,5]  R1307     1.1066298931837082e-01
    z[3,2,5]  R1308     -1.0694700479507446e-01
    z[3,2,5]  R1309     -3.7286561727523804e-01
    z[3,2,5]  R1310     -6.1039716005325317e-01
    z[3,2,5]  R1311     1.7148524522781372e-01
    z[3,2,5]  R1312     -8.9085720479488373e-02
    z[3,2,5]  R1313     6.5611422061920166e-02
    z[3,2,5]  R1314     -4.1812869906425476e-01
    z[3,2,5]  R1315     0.286979079246521
    z[3,2,5]  R1316     -1.7271885275840759e-01
    z[3,2,5]  R1317     8.1810927391052246e-01
    z[3,2,5]  R1318     -3.4268322587013245e-01
    z[3,2,5]  R1319     -2.9487481713294983e-01
    z[3,2,5]  R1320     3.1709179282188416e-01
    z[3,2,5]  R1321     -6.1188173294067383e-01
    z[3,2,5]  R1322     -1.8844248354434967e-01
    z[3,2,5]  R1323     -2.4835785850882530e-02
    z[3,2,5]  R1324     1.9847498834133148e-01
    z[3,2,5]  R1325     -4.3695300817489624e-01
    z[3,2,5]  R1326     -3.2630094885826111e-01
    z[3,2,5]  R1327     -1.2975083291530609e-01
    z[3,2,5]  R1328     -2.3591253161430359e-01
    z[3,2,6]  R26       1
    z[3,2,6]  R35       -1
    z[3,2,6]  R1217     -1
    z[3,2,6]  R1218     1
    z[3,2,6]  R1219     2.2468097507953644e-01
    z[3,2,6]  R1220     -3.2996791601181030e-01
    z[3,2,6]  R1221     1.4762161672115326e-01
    z[3,2,6]  R1222     -4.5040425658226013e-01
    z[3,2,6]  R1223     1.3805608265101910e-02
    z[3,2,6]  R1224     5.8425735682249069e-02
    z[3,2,6]  R1225     3.9670267701148987e-01
    z[3,2,6]  R1226     0.537770688533783
    z[3,2,6]  R1227     -1.8344806134700775e-01
    z[3,2,6]  R1228     -8.5710622370243073e-02
    z[3,2,6]  R1229     -3.8023035973310471e-02
    z[3,2,6]  R1230     -0.269378125667572
    z[3,2,6]  R1231     -2.0136094093322754e-01
    z[3,2,6]  R1232     -1.4751872420310974e-01
    z[3,2,6]  R1233     -2.1189206838607788e-01
    z[3,2,6]  R1234     -1.0805781185626984e-01
    z[3,2,6]  R1235     -5.5326286703348160e-02
    z[3,2,6]  R1236     -2.1189002692699432e-01
    z[3,2,6]  R1237     4.6170207858085632e-01
    z[3,2,6]  R1238     -1.9464819133281708e-01
    z[3,2,6]  R1239     4.3017691373825073e-01
    z[3,2,6]  R1240     -1.5040473639965057e-01
    z[3,2,6]  R1241     6.3325248658657074e-02
    z[3,2,6]  R1242     1.1317790299654007e-01
    z[3,2,6]  R1243     1.9343329966068268e-01
    z[3,2,6]  R1244     -7.9061530530452728e-02
    z[3,2,6]  R1245     -9.6641272306442261e-02
    z[3,2,6]  R1246     -1.0856087505817413e-01
    z[3,2,6]  R1247     -1.6978496313095093e-01
    z[3,2,6]  R1248     -2.2336056455969810e-02
    z[3,2,6]  R1249     -1.4777894318103790e-01
    z[3,2,6]  R1250     9.7572272352408618e-05
    z[3,2,6]  R1251     -1.1589463800191879e-01
    z[3,2,6]  R1252     2.8197151422500610e-01
    z[3,2,6]  R1253     2.7002471685409546e-01
    z[3,2,6]  R1254     8.2531832158565521e-02
    z[3,2,6]  R1255     -1.7834395170211792e-02
    z[3,2,6]  R1256     1.0257884860038757e-01
    z[3,2,6]  R1257     3.3247941732406616e-01
    z[3,2,6]  R1258     3.5234186798334122e-02
    z[3,2,6]  R1259     0.0984724834561348
    z[3,2,6]  R1260     1.1448633670806885e-01
    z[3,2,6]  R1261     7.1404480934143066e-01
    z[3,2,6]  R1262     -1.8833881616592407e-01
    z[3,2,6]  R1263     -7.0366062223911285e-02
    z[3,2,6]  R1264     6.7802697420120239e-02
    z[3,2,6]  R1265     1.1730934679508209e-01
    z[3,2,6]  R1266     -6.0412295162677765e-02
    z[3,2,6]  R1267     -2.2613309323787689e-01
    z[3,2,6]  R1268     2.3787630721926689e-02
    z[3,2,6]  R1269     7.1329828351736069e-03
    z[3,2,6]  R1270     -7.9224541783332825e-02
    z[3,2,6]  R1271     4.9727505445480347e-01
    z[3,2,6]  R1272     -1.5995460748672485e-01
    z[3,2,6]  R1273     -5.7356536388397217e-01
    z[3,2,6]  R1274     1.2033274024724960e-01
    z[3,2,6]  R1275     -7.1916177868843079e-02
    z[3,2,6]  R1276     -3.6164382100105286e-01
    z[3,2,6]  R1277     -3.1468236446380615e-01
    z[3,2,6]  R1278     -1.3965220749378204e-01
    z[3,2,6]  R1279     1.6713712364435196e-02
    z[3,2,6]  R1280     1.3852766156196594e-01
    z[3,2,6]  R1281     -2.6451028883457184e-02
    z[3,2,6]  R1282     6.5301500260829926e-02
    z[3,2,6]  R1283     -2.0380245149135590e-01
    z[3,2,6]  R1284     1.8621627986431122e-01
    z[3,2,6]  R1285     3.7159714102745056e-01
    z[3,2,6]  R1286     5.8207410573959351e-01
    z[3,2,6]  R1287     -9.7229331731796265e-02
    z[3,2,6]  R1288     9.8299160599708557e-02
    z[3,2,6]  R1289     -8.5928887128829956e-02
    z[3,2,6]  R1290     -5.0952263176441193e-02
    z[3,2,6]  R1291     0.290477991104126
    z[3,2,6]  R1292     9.4562888145446777e-02
    z[3,2,6]  R1293     4.1986885666847229e-01
    z[3,2,6]  R1294     -0.355317622423172
    z[3,2,6]  R1295     3.1535494327545166e-01
    z[3,2,6]  R1296     -2.3087418079376221e-01
    z[3,2,6]  R1297     -5.2109336853027344e-01
    z[3,2,6]  R1298     -5.1472866535186768e-01
    z[3,2,6]  R1299     6.4978986978530884e-01
    z[3,2,6]  R1300     1.3804058730602264e-01
    z[3,2,6]  R1301     2.4975056946277618e-01
    z[3,2,6]  R1302     1.1272017657756805e-01
    z[3,2,6]  R1303     -2.0698155462741852e-01
    z[3,2,6]  R1304     -7.2273783385753632e-02
    z[3,2,6]  R1305     4.9550160765647888e-02
    z[3,2,6]  R1306     1.1164902895689011e-01
    z[3,2,6]  R1307     -2.0635692775249481e-01
    z[3,2,6]  R1308     2.0182704925537109e-01
    z[3,2,6]  R1309     -4.6101385354995728e-01
    z[3,2,6]  R1310     2.6499542593955994e-01
    z[3,2,6]  R1311     -1.4004588127136230e-01
    z[3,2,6]  R1312     -4.1854989528656006e-01
    z[3,2,6]  R1313     1.0906316339969635e-01
    z[3,2,6]  R1314     4.3054428696632385e-01
    z[3,2,6]  R1315     0.090914286673069
    z[3,2,6]  R1316     -0.0802655816078186
    z[3,2,6]  R1317     -4.3816640973091125e-01
    z[3,2,6]  R1318     2.2761696577072144e-01
    z[3,2,6]  R1319     6.0557309538125992e-02
    z[3,2,6]  R1320     -8.9875146746635437e-02
    z[3,2,6]  R1321     6.1374053359031677e-02
    z[3,2,6]  R1322     1.6884168609976768e-02
    z[3,2,6]  R1323     4.2412549257278442e-01
    z[3,2,6]  R1324     5.1192098855972290e-01
    z[3,2,6]  R1325     -3.0343142151832581e-01
    z[3,2,6]  R1326     2.0778505504131317e-01
    z[3,2,6]  R1327     -1.2761445343494415e-01
    z[3,2,6]  R1328     -0.400240957736969
    z[2,8,0]  R20       -1
    z[2,8,0]  R74       1
    z[2,8,0]  R1329     -1
    z[2,8,0]  R1330     1
    z[2,8,0]  R1343     -2.1391913294792175e-01
    z[2,8,0]  R1344     -2.6369300484657288e-01
    z[2,8,0]  R1345     -2.0321425795555115e-01
    z[2,8,0]  R1346     -1.2211536616086960e-01
    z[2,8,0]  R1347     -2.1548202633857727e-01
    z[2,8,0]  R1348     -5.0030261278152466e-01
    z[2,8,0]  R1349     -0.0824422836303711
    z[2,8,0]  R1350     -6.5397894382476807e-01
    z[2,8,0]  R1351     4.9234387278556824e-01
    z[2,8,0]  R1352     1.8694119155406952e-01
    z[2,8,0]  R1353     1.5439975261688232e-01
    z[2,8,0]  R1354     1.5032652020454407e-01
    z[2,8,0]  R1355     4.4251907616853714e-02
    z[2,8,0]  R1356     -1.5841630101203918e-01
    z[2,8,0]  R1357     -9.2788815498352051e-02
    z[2,8,0]  R1358     -1.2571211159229279e-01
    z[2,8,0]  R1359     -2.2419813275337219e-01
    z[2,8,0]  R1360     2.2780667245388031e-01
    z[2,8,0]  R1361     -3.2894098758697510e-01
    z[2,8,0]  R1362     -2.4866597354412079e-01
    z[2,8,0]  R1363     5.2616402506828308e-02
    z[2,8,0]  R1364     2.7954089641571045e-01
    z[2,8,0]  R1365     6.4820271730422974e-01
    z[2,8,0]  R1366     -1.4740100130438805e-02
    z[2,8,0]  R1367     -4.6165034174919128e-02
    z[2,8,0]  R1368     7.8379977494478226e-03
    z[2,8,0]  R1369     6.3006269931793213e-01
    z[2,8,0]  R1370     1.4017288386821747e-01
    z[2,8,0]  R1371     -2.4023541808128357e-01
    z[2,8,0]  R1372     -3.9358308911323547e-01
    z[2,8,0]  R1373     -1.4701075851917267e-01
    z[2,8,0]  R1374     4.1678366065025330e-01
    z[2,8,0]  R1375     -1.3015897572040558e-01
    z[2,8,0]  R1376     6.1288721859455109e-02
    z[2,8,0]  R1377     -1.8016344308853149e-01
    z[2,8,0]  R1378     2.5706410408020020e-01
    z[2,8,0]  R1379     1.9248086214065552e-01
    z[2,8,0]  R1380     5.2797567844390869e-01
    z[2,8,0]  R1381     -6.0768104158341885e-03
    z[2,8,0]  R1382     -1.8545801937580109e-01
    z[2,8,0]  R1383     3.7204214930534363e-01
    z[2,8,0]  R1384     3.1403880566358566e-02
    z[2,8,0]  R1385     4.0567180514335632e-01
    z[2,8,0]  R1386     2.0946851000189781e-03
    z[2,8,0]  R1387     -1.9522626698017120e-01
    z[2,8,0]  R1388     1.6009330749511719e-01
    z[2,8,0]  R1389     5.6637412309646606e-01
    z[2,8,0]  R1390     1.4716935157775879e-01
    z[2,8,0]  R1391     2.0530971884727478e-01
    z[2,8,0]  R1392     2.2877733409404755e-01
    z[2,8,0]  R1393     -4.1689458489418030e-01
    z[2,8,0]  R1394     -4.8468196392059326e-01
    z[2,8,0]  R1395     -5.7306480407714844e-01
    z[2,8,0]  R1396     -3.4239238500595093e-01
    z[2,8,0]  R1397     -6.0957503318786621e-01
    z[2,8,0]  R1398     -3.2015225291252136e-01
    z[2,8,0]  R1399     -3.0857360363006592e-01
    z[2,8,0]  R1400     -3.9235708117485046e-01
    z[2,8,0]  R1401     -3.4801444411277771e-01
    z[2,8,0]  R1402     3.6987990140914917e-02
    z[2,8,0]  R1403     3.7160363048315048e-02
    z[2,8,0]  R1404     4.9446426331996918e-02
    z[2,8,0]  R1405     9.2987410724163055e-02
    z[2,8,0]  R1406     1.6451187431812286e-01
    z[2,8,0]  R1407     3.8392234593629837e-02
    z[2,8,0]  R1408     2.3820878937840462e-02
    z[2,8,0]  R1409     -3.6871144175529480e-01
    z[2,8,0]  R1410     -1.8168369308114052e-02
    z[2,8,0]  R1411     4.3558844923973083e-01
    z[2,8,0]  R1412     -3.8961544632911682e-02
    z[2,8,0]  R1413     2.1219049394130707e-01
    z[2,8,0]  R1414     1.0946871340274811e-01
    z[2,8,0]  R1415     -1.0069070756435394e-01
    z[2,8,0]  R1416     5.2443742752075195e-02
    z[2,8,0]  R1417     2.7736195921897888e-01
    z[2,8,0]  R1418     -9.2849425971508026e-02
    z[2,8,0]  R1419     -9.0580090880393982e-02
    z[2,8,0]  R1420     -1.5218126773834229e-01
    z[2,8,0]  R1421     -3.0100749805569649e-02
    z[2,8,0]  R1422     -3.4075182676315308e-01
    z[2,8,0]  R1423     -1.8804021179676056e-01
    z[2,8,0]  R1424     -1.2020721286535263e-01
    z[2,8,0]  R1425     1.3284712098538876e-02
    z[2,8,0]  R1426     -1.1131456494331360e-01
    z[2,8,0]  R1427     -1.0430975258350372e-01
    z[2,8,0]  R1428     -2.2587503492832184e-01
    z[2,8,0]  R1429     -1.0576321184635162e-01
    z[2,8,0]  R1430     -2.6120189577341080e-02
    z[2,8,0]  R1431     8.6152262985706329e-02
    z[2,8,0]  R1432     1.7868988215923309e-01
    z[2,8,0]  R1433     2.1687847375869751e-01
    z[2,8,0]  R1434     -7.6703220605850220e-02
    z[2,8,0]  R1435     -5.7236045598983765e-01
    z[2,8,0]  R1436     3.7944954633712769e-01
    z[2,8,0]  R1437     -1.9736465811729431e-01
    z[2,8,0]  R1438     -3.9486771821975708e-01
    z[2,8,0]  R1439     0.0852629616856575
    z[2,8,0]  R1440     -2.9006785154342651e-01
    z[2,8,0]  R1441     1.5264980494976044e-01
    z[2,8,0]  R1442     2.2403240203857422e-01
    z[2,8,0]  R1443     -2.2230571508407593e-01
    z[2,8,0]  R1444     -3.1105026602745056e-01
    z[2,8,0]  R1445     -5.1620435714721680e-01
    z[2,8,0]  R1446     -1.7105893790721893e-01
    z[2,8,0]  R1447     2.1935540437698364e-01
    z[2,8,0]  R1448     1.0663330322131515e-03
    z[2,8,0]  R1449     -3.1086322665214539e-01
    z[2,8,0]  R1450     4.4636088609695435e-01
    z[2,8,0]  R1451     6.9318538904190063e-01
    z[2,8,0]  R1452     8.1855165958404541e-01
    z[2,8,0]  R1453     4.0272515267133713e-02
    z[2,8,0]  R1454     3.4263002872467041e-01
    z[2,8,0]  R1455     -1.5010145306587219e-01
    z[2,8,0]  R1456     -1.5877915918827057e-01
    z[2,8,0]  R1457     -2.8038141131401062e-01
    z[2,8,0]  R1458     2.9783645272254944e-01
    z[2,8,0]  R1459     -3.5361889004707336e-01
    z[2,8,0]  R1460     -2.7545174956321716e-01
    z[2,8,0]  R1461     -3.9055564999580383e-01
    z[2,8,0]  R1462     3.1482365727424622e-01
    z[2,8,0]  R1463     1.7461758852005005e-01
    z[2,8,0]  R1464     -2.4204730987548828e-01
    z[2,8,0]  R1465     -3.5855054855346680e-01
    z[2,8,0]  R1466     -2.6036825776100159e-01
    z[2,8,0]  R1467     2.1546375751495361e-01
    z[2,8,0]  R1468     6.7238390445709229e-02
    z[2,8,0]  R1469     -2.7760851383209229e-01
    z[2,8,0]  R1470     7.6810318231582642e-01
    z[2,8,0]  R1471     9.5003110170364380e-01
    z[2,8,0]  R1472     9.3456918001174927e-01
    z[2,8,1]  R21       -1
    z[2,8,1]  R75       1
    z[2,8,1]  R1331     -1
    z[2,8,1]  R1332     1
    z[2,8,1]  R1343     3.6962968111038208e-01
    z[2,8,1]  R1344     -2.2585336863994598e-01
    z[2,8,1]  R1345     -6.3878291845321655e-01
    z[2,8,1]  R1346     -0.637885332107544
    z[2,8,1]  R1347     -6.2792015075683594e-01
    z[2,8,1]  R1348     -2.5551816448569298e-02
    z[2,8,1]  R1349     -5.1065891981124878e-01
    z[2,8,1]  R1350     -1.5931475162506104e-01
    z[2,8,1]  R1351     3.9877825975418091e-01
    z[2,8,1]  R1352     -3.3519566059112549e-01
    z[2,8,1]  R1353     7.4821001291275024e-01
    z[2,8,1]  R1354     6.2233549356460571e-01
    z[2,8,1]  R1355     7.0716559886932373e-01
    z[2,8,1]  R1356     3.4581381082534790e-01
    z[2,8,1]  R1357     6.0509526729583740e-01
    z[2,8,1]  R1358     4.4489392638206482e-01
    z[2,8,1]  R1359     3.5442498326301575e-01
    z[2,8,1]  R1360     7.3422580957412720e-01
    z[2,8,1]  R1361     2.3457735776901245e-01
    z[2,8,1]  R1362     -9.4344671815633774e-03
    z[2,8,1]  R1363     -2.1630187332630157e-01
    z[2,8,1]  R1364     2.5966829061508179e-01
    z[2,8,1]  R1365     -8.5281684994697571e-02
    z[2,8,1]  R1366     -3.4813082218170166e-01
    z[2,8,1]  R1367     1.0931760072708130e-01
    z[2,8,1]  R1368     1.7637154459953308e-01
    z[2,8,1]  R1369     2.9924153932370245e-04
    z[2,8,1]  R1370     -1.2882173061370850e-01
    z[2,8,1]  R1371     -8.5850799083709717e-01
    z[2,8,1]  R1372     -7.5027018785476685e-01
    z[2,8,1]  R1373     4.6310821175575256e-01
    z[2,8,1]  R1374     -2.0021395385265350e-01
    z[2,8,1]  R1375     4.8950418829917908e-01
    z[2,8,1]  R1376     9.9311359226703644e-02
    z[2,8,1]  R1377     1.8918801844120026e-01
    z[2,8,1]  R1378     3.7089128047227859e-02
    z[2,8,1]  R1379     1.0083258152008057e-01
    z[2,8,1]  R1380     3.7639137357473373e-02
    z[2,8,1]  R1381     -2.0759311318397522e-01
    z[2,8,1]  R1382     -9.5413953065872192e-02
    z[2,8,1]  R1383     7.0166522264480591e-01
    z[2,8,1]  R1384     -3.6928680539131165e-01
    z[2,8,1]  R1385     3.2252028584480286e-01
    z[2,8,1]  R1386     8.6657595634460449e-01
    z[2,8,1]  R1387     0.43874591588974
    z[2,8,1]  R1388     0.78117436170578
    z[2,8,1]  R1389     5.4525947570800781e-01
    z[2,8,1]  R1390     1.4030268788337708e-01
    z[2,8,1]  R1391     -2.6873552799224854e-01
    z[2,8,1]  R1392     -4.1345305740833282e-02
    z[2,8,1]  R1393     -3.3204442262649536e-01
    z[2,8,1]  R1394     -2.5690299272537231e-01
    z[2,8,1]  R1395     -4.6997055411338806e-01
    z[2,8,1]  R1396     -4.6174040436744690e-01
    z[2,8,1]  R1397     -4.8508054018020630e-01
    z[2,8,1]  R1398     -0.602096676826477
    z[2,8,1]  R1399     1.2655800208449364e-02
    z[2,8,1]  R1400     -1.6722084954380989e-02
    z[2,8,1]  R1401     -1.5665067732334137e-01
    z[2,8,1]  R1402     2.9285481572151184e-01
    z[2,8,1]  R1403     7.0536142587661743e-01
    z[2,8,1]  R1404     3.4541028738021851e-01
    z[2,8,1]  R1405     0.516209065914154
    z[2,8,1]  R1406     4.8548287153244019e-01
    z[2,8,1]  R1407     3.3199149370193481e-01
    z[2,8,1]  R1408     5.1212704181671143e-01
    z[2,8,1]  R1409     5.9532564878463745e-01
    z[2,8,1]  R1410     6.3990515470504761e-01
    z[2,8,1]  R1411     4.8651802539825439e-01
    z[2,8,1]  R1412     4.3544858694076538e-01
    z[2,8,1]  R1413     -3.4603667259216309e-01
    z[2,8,1]  R1414     0.720102846622467
    z[2,8,1]  R1415     -4.8885107971727848e-03
    z[2,8,1]  R1416     6.4501903951168060e-02
    z[2,8,1]  R1417     -2.0838995277881622e-01
    z[2,8,1]  R1418     -2.4802862107753754e-01
    z[2,8,1]  R1419     -7.4762886762619019e-01
    z[2,8,1]  R1420     4.9201175570487976e-02
    z[2,8,1]  R1421     3.2671761512756348e-01
    z[2,8,1]  R1422     -1.0198544710874557e-01
    z[2,8,1]  R1423     -2.8616625815629959e-02
    z[2,8,1]  R1424     3.1933152675628662e-01
    z[2,8,1]  R1425     6.5530651807785034e-01
    z[2,8,1]  R1426     -7.6302891969680786e-01
    z[2,8,1]  R1427     -0.713287353515625
    z[2,8,1]  R1428     3.4502479434013367e-01
    z[2,8,1]  R1429     -1.5632529556751251e-01
    z[2,8,1]  R1430     4.4123733043670654e-01
    z[2,8,1]  R1431     -4.0507555007934570e-01
    z[2,8,1]  R1432     -7.1970999240875244e-02
    z[2,8,1]  R1433     -1.0386711359024048e-01
    z[2,8,1]  R1434     -0.826941728591919
    z[2,8,1]  R1435     5.5064874887466431e-01
    z[2,8,1]  R1436     5.6682562828063965e-01
    z[2,8,1]  R1437     -0.637488067150116
    z[2,8,1]  R1438     3.1302982568740845e-01
    z[2,8,1]  R1439     -4.3343013525009155e-01
    z[2,8,1]  R1440     -5.8169806003570557e-01
    z[2,8,1]  R1441     8.8284105062484741e-01
    z[2,8,1]  R1442     7.3823785781860352e-01
    z[2,8,1]  R1443     -7.5214987993240356e-01
    z[2,8,1]  R1444     4.9054896831512451e-01
    z[2,8,1]  R1445     4.3570250272750854e-01
    z[2,8,1]  R1446     9.2652714252471924e-01
    z[2,8,1]  R1447     8.0565035343170166e-01
    z[2,8,1]  R1448     -5.6556481122970581e-01
    z[2,8,1]  R1449     4.0573990345001221e-01
    z[2,8,1]  R1450     6.1703330278396606e-01
    z[2,8,1]  R1451     -1.1697446554899216e-01
    z[2,8,1]  R1452     -1.9792547821998596e-01
    z[2,8,1]  R1453     -1.3860097527503967e-01
    z[2,8,1]  R1454     0.715706467628479
    z[2,8,1]  R1455     6.6889148950576782e-01
    z[2,8,1]  R1456     2.9724597930908203e-01
    z[2,8,1]  R1457     -6.8008792400360107e-01
    z[2,8,1]  R1458     8.8679903745651245e-01
    z[2,8,1]  R1459     -7.1929872035980225e-01
    z[2,8,1]  R1460     -3.0911669135093689e-01
    z[2,8,1]  R1461     3.7147161364555359e-01
    z[2,8,1]  R1462     0.74797123670578
    z[2,8,1]  R1463     7.5768578052520752e-01
    z[2,8,1]  R1464     -3.3206534385681152e-01
    z[2,8,1]  R1465     -7.1302127838134766e-01
    z[2,8,1]  R1466     6.7258435487747192e-01
    z[2,8,1]  R1467     7.0505040884017944e-01
    z[2,8,1]  R1468     -6.5480205230414867e-03
    z[2,8,1]  R1469     -7.0366328954696655e-01
    z[2,8,1]  R1470     -3.0529114603996277e-01
    z[2,8,1]  R1471     1.3688798062503338e-02
    z[2,8,1]  R1472     4.1255757212638855e-02
    z[2,8,2]  R22       -1
    z[2,8,2]  R76       1
    z[2,8,2]  R1333     -1
    z[2,8,2]  R1334     1
    z[2,8,2]  R1343     -1.7148266732692719e-01
    z[2,8,2]  R1344     8.2171314954757690e-01
    z[2,8,2]  R1345     0.659396231174469
    z[2,8,2]  R1346     2.9673033952713013e-01
    z[2,8,2]  R1347     4.8074802756309509e-01
    z[2,8,2]  R1348     8.3655959367752075e-01
    z[2,8,2]  R1349     6.2870103120803833e-01
    z[2,8,2]  R1350     4.0047213435173035e-01
    z[2,8,2]  R1351     -5.6966669857501984e-02
    z[2,8,2]  R1352     7.4343693256378174e-01
    z[2,8,2]  R1353     -4.4365558028221130e-01
    z[2,8,2]  R1354     -5.0853508710861206e-01
    z[2,8,2]  R1355     -5.2227860689163208e-01
    z[2,8,2]  R1356     -8.5057616233825684e-01
    z[2,8,2]  R1357     -5.3677064180374146e-01
    z[2,8,2]  R1358     -7.6897680759429932e-01
    z[2,8,2]  R1359     -7.4780440330505371e-01
    z[2,8,2]  R1360     -2.5453430414199829e-01
    z[2,8,2]  R1361     3.2538837194442749e-01
    z[2,8,2]  R1362     1.6030944883823395e-01
    z[2,8,2]  R1363     0.250957727432251
    z[2,8,2]  R1364     2.2730448842048645e-01
    z[2,8,2]  R1365     -2.0786218345165253e-01
    z[2,8,2]  R1366     7.3982700705528259e-02
    z[2,8,2]  R1367     -1.1089028790593147e-02
    z[2,8,2]  R1368     -2.5956982374191284e-01
    z[2,8,2]  R1369     2.1277728676795959e-01
    z[2,8,2]  R1370     4.4958975911140442e-01
    z[2,8,2]  R1371     -6.7659132182598114e-02
    z[2,8,2]  R1372     -2.0726792514324188e-01
    z[2,8,2]  R1373     -0.559663712978363
    z[2,8,2]  R1374     -5.7365173101425171e-01
    z[2,8,2]  R1375     -8.0755275487899780e-01
    z[2,8,2]  R1376     -5.2722561359405518e-01
    z[2,8,2]  R1377     -4.7982862591743469e-01
    z[2,8,2]  R1378     -0.598857045173645
    z[2,8,2]  R1379     0.886725664138794
    z[2,8,2]  R1380     -7.9085886478424072e-01
    z[2,8,2]  R1381     1.1493320018053055e-01
    z[2,8,2]  R1382     -5.6808573007583618e-01
    z[2,8,2]  R1383     -1.2841895222663879e-01
    z[2,8,2]  R1384     2.0998318493366241e-01
    z[2,8,2]  R1385     -4.9523675441741943e-01
    z[2,8,2]  R1386     -0.351829469203949
    z[2,8,2]  R1387     -5.7935726642608643e-01
    z[2,8,2]  R1388     -1.5869230031967163e-01
    z[2,8,2]  R1389     -1.7285600304603577e-01
    z[2,8,2]  R1390     3.6849480867385864e-01
    z[2,8,2]  R1391     4.0468290448188782e-01
    z[2,8,2]  R1392     3.7011903524398804e-01
    z[2,8,2]  R1393     4.2972904443740845e-01
    z[2,8,2]  R1394     2.9859790205955505e-01
    z[2,8,2]  R1395     -1.4298494160175323e-01
    z[2,8,2]  R1396     1.9827237725257874e-01
    z[2,8,2]  R1397     2.4667717516422272e-01
    z[2,8,2]  R1398     6.6764909029006958e-01
    z[2,8,2]  R1399     0.749691903591156
    z[2,8,2]  R1400     0.794209361076355
    z[2,8,2]  R1401     7.4640804529190063e-01
    z[2,8,2]  R1402     -5.7840985059738159e-01
    z[2,8,2]  R1403     -4.9356621503829956e-01
    z[2,8,2]  R1404     -5.4023534059524536e-01
    z[2,8,2]  R1405     -6.4635413885116577e-01
    z[2,8,2]  R1406     -9.2058137059211731e-02
    z[2,8,2]  R1407     -7.9390835762023926e-01
    z[2,8,2]  R1408     -4.5745104551315308e-01
    z[2,8,2]  R1409     -3.7056869268417358e-01
    z[2,8,2]  R1410     -4.0922570228576660e-01
    z[2,8,2]  R1411     -4.8002764582633972e-01
    z[2,8,2]  R1412     -6.8645268678665161e-01
    z[2,8,2]  R1413     4.0704756975173950e-01
    z[2,8,2]  R1414     -3.5753306746482849e-01
    z[2,8,2]  R1415     -3.2452747225761414e-01
    z[2,8,2]  R1416     -1.6314937174320221e-01
    z[2,8,2]  R1417     1.8298590555787086e-02
    z[2,8,2]  R1418     -2.8553183656185865e-03
    z[2,8,2]  R1419     -4.5324909687042236e-01
    z[2,8,2]  R1420     7.4352012015879154e-03
    z[2,8,2]  R1421     1.7782163619995117e-01
    z[2,8,2]  R1422     9.8059467971324921e-02
    z[2,8,2]  R1423     3.7972810864448547e-01
    z[2,8,2]  R1424     -6.2939512729644775e-01
    z[2,8,2]  R1425     -0.642380952835083
    z[2,8,2]  R1426     -6.9627188146114349e-02
    z[2,8,2]  R1427     -1.6084440052509308e-01
    z[2,8,2]  R1428     -5.4775995016098022e-01
    z[2,8,2]  R1429     -4.4738808274269104e-01
    z[2,8,2]  R1430     -5.5230081081390381e-01
    z[2,8,2]  R1431     4.3478560447692871e-01
    z[2,8,2]  R1432     -5.3456395864486694e-01
    z[2,8,2]  R1433     4.4696268439292908e-01
    z[2,8,2]  R1434     -2.2541087865829468e-01
    z[2,8,2]  R1435     -4.3915849924087524e-01
    z[2,8,2]  R1436     -6.5261960029602051e-01
    z[2,8,2]  R1437     -1.2304015457630157e-01
    z[2,8,2]  R1438     -6.2947779893875122e-01
    z[2,8,2]  R1439     -3.2969605177640915e-02
    z[2,8,2]  R1440     -3.2634842395782471e-01
    z[2,8,2]  R1441     2.6758614182472229e-01
    z[2,8,2]  R1442     4.3983215093612671e-01
    z[2,8,2]  R1443     -9.5280326902866364e-02
    z[2,8,2]  R1444     -0.634859025478363
    z[2,8,2]  R1445     -6.4517909288406372e-01
    z[2,8,2]  R1446     0.0360434390604496
    z[2,8,2]  R1447     4.5218861103057861e-01
    z[2,8,2]  R1448     -1.2078131549060345e-02
    z[2,8,2]  R1449     1.2855865061283112e-01
    z[2,8,2]  R1450     5.5934345722198486e-01
    z[2,8,2]  R1451     -2.0315490663051605e-01
    z[2,8,2]  R1452     -1.4706824719905853e-01
    z[2,8,2]  R1453     1.7670039832592010e-01
    z[2,8,2]  R1454     -4.8426979780197144e-01
    z[2,8,2]  R1455     -2.8648141026496887e-01
    z[2,8,2]  R1456     -6.8398404121398926e-01
    z[2,8,2]  R1457     -5.9787672013044357e-02
    z[2,8,2]  R1458     -1.4526379108428955e-01
    z[2,8,2]  R1459     3.9475105702877045e-02
    z[2,8,2]  R1460     2.5788527727127075e-01
    z[2,8,2]  R1461     -4.6022129058837891e-01
    z[2,8,2]  R1462     5.2115124464035034e-01
    z[2,8,2]  R1463     -2.4724586308002472e-01
    z[2,8,2]  R1464     3.8947898149490356e-01
    z[2,8,2]  R1465     -1.5772011876106262e-01
    z[2,8,2]  R1466     -0.574109673500061
    z[2,8,2]  R1467     -4.5492088794708252e-01
    z[2,8,2]  R1468     4.2822387814521790e-01
    z[2,8,2]  R1469     -2.8702369332313538e-01
    z[2,8,2]  R1470     -0.175094336271286
    z[2,8,2]  R1471     6.2799490988254547e-02
    z[2,8,2]  R1472     2.5760421156883240e-01
    z[2,8,3]  R23       -1
    z[2,8,3]  R77       1
    z[2,8,3]  R1335     -1
    z[2,8,3]  R1336     1
    z[2,8,3]  R1343     4.5843076705932617e-01
    z[2,8,3]  R1344     -3.1058143824338913e-02
    z[2,8,3]  R1345     2.8784537315368652e-01
    z[2,8,3]  R1346     6.5112829208374023e-01
    z[2,8,3]  R1347     5.1474034786224365e-01
    z[2,8,3]  R1348     -1.1923284828662872e-01
    z[2,8,3]  R1349     4.3017926812171936e-01
    z[2,8,3]  R1350     -2.0549426972866058e-01
    z[2,8,3]  R1351     -5.2066117525100708e-02
    z[2,8,3]  R1352     5.0769889354705811e-01
    z[2,8,3]  R1353     1.1674515157938004e-01
    z[2,8,3]  R1354     3.5537999868392944e-01
    z[2,8,3]  R1355     -5.1625583320856094e-02
    z[2,8,3]  R1356     6.0137853026390076e-02
    z[2,8,3]  R1357     -0.157786563038826
    z[2,8,3]  R1358     -1.7026992142200470e-01
    z[2,8,3]  R1359     -1.0650216601788998e-02
    z[2,8,3]  R1360     6.5115690231323242e-02
    z[2,8,3]  R1361     1.1661132425069809e-01
    z[2,8,3]  R1362     -7.1028995513916016e-01
    z[2,8,3]  R1363     2.7433764189481735e-03
    z[2,8,3]  R1364     -6.7830830812454224e-01
    z[2,8,3]  R1365     2.4954505264759064e-01
    z[2,8,3]  R1366     -4.4995075464248657e-01
    z[2,8,3]  R1367     -6.2988221645355225e-01
    z[2,8,3]  R1368     -2.2799676656723022e-01
    z[2,8,3]  R1369     4.4768846035003662e-01
    z[2,8,3]  R1370     -6.1550658941268921e-01
    z[2,8,3]  R1371     -3.3372217416763306e-01
    z[2,8,3]  R1372     -4.2903545498847961e-01
    z[2,8,3]  R1373     3.1411767005920410e-01
    z[2,8,3]  R1374     1.0412068665027618e-01
    z[2,8,3]  R1375     1.8298628926277161e-01
    z[2,8,3]  R1376     5.0356507301330566e-01
    z[2,8,3]  R1377     6.1112821102142334e-01
    z[2,8,3]  R1378     2.8271466493606567e-01
    z[2,8,3]  R1379     -2.6987859606742859e-01
    z[2,8,3]  R1380     1.9051222503185272e-01
    z[2,8,3]  R1381     -2.8663340210914612e-01
    z[2,8,3]  R1382     -1.5051684342324734e-02
    z[2,8,3]  R1383     2.8195375204086304e-01
    z[2,8,3]  R1384     -3.0767318606376648e-01
    z[2,8,3]  R1385     -3.2623484730720520e-01
    z[2,8,3]  R1386     -2.9760724306106567e-01
    z[2,8,3]  R1387     4.8644068837165833e-01
    z[2,8,3]  R1388     1.4212132990360260e-01
    z[2,8,3]  R1389     -1.8289128318428993e-02
    z[2,8,3]  R1390     6.3790738582611084e-01
    z[2,8,3]  R1391     7.4694973230361938e-01
    z[2,8,3]  R1392     5.3082180023193359e-01
    z[2,8,3]  R1393     7.0460617542266846e-01
    z[2,8,3]  R1394     6.3385230302810669e-01
    z[2,8,3]  R1395     5.1752287149429321e-01
    z[2,8,3]  R1396     0.691716730594635
    z[2,8,3]  R1397     -2.8274807333946228e-01
    z[2,8,3]  R1398     2.2858205437660217e-01
    z[2,8,3]  R1399     -9.3946717679500580e-02
    z[2,8,3]  R1400     -9.8623782396316528e-02
    z[2,8,3]  R1401     1.6305133700370789e-02
    z[2,8,3]  R1402     2.3331997916102409e-02
    z[2,8,3]  R1403     6.5564163029193878e-02
    z[2,8,3]  R1404     5.2176183462142944e-01
    z[2,8,3]  R1405     4.3301886320114136e-01
    z[2,8,3]  R1406     -7.2795635461807251e-01
    z[2,8,3]  R1407     1.0284223407506943e-01
    z[2,8,3]  R1408     5.7892650365829468e-01
    z[2,8,3]  R1409     1.1072061210870743e-01
    z[2,8,3]  R1410     4.8190414905548096e-01
    z[2,8,3]  R1411     5.4360177367925644e-02
    z[2,8,3]  R1412     -6.8826384842395782e-02
    z[2,8,3]  R1413     -8.1118786334991455e-01
    z[2,8,3]  R1414     0.0860656350851059
    z[2,8,3]  R1415     -0.528769314289093
    z[2,8,3]  R1416     -4.9167567491531372e-01
    z[2,8,3]  R1417     -6.5119296312332153e-01
    z[2,8,3]  R1418     -7.0396721363067627e-01
    z[2,8,3]  R1419     -3.1340688467025757e-01
    z[2,8,3]  R1420     -6.6030627489089966e-01
    z[2,8,3]  R1421     -4.8219156265258789e-01
    z[2,8,3]  R1422     -5.1669472455978394e-01
    z[2,8,3]  R1423     -0.783909022808075
    z[2,8,3]  R1424     6.4680272340774536e-01
    z[2,8,3]  R1425     1.1100284755229950e-02
    z[2,8,3]  R1426     -1.9375425577163696e-01
    z[2,8,3]  R1427     4.3256103992462158e-02
    z[2,8,3]  R1428     6.3257914781570435e-01
    z[2,8,3]  R1429     -4.0427660942077637e-01
    z[2,8,3]  R1430     2.4229690432548523e-01
    z[2,8,3]  R1431     3.9681177586317062e-02
    z[2,8,3]  R1432     -7.1501910686492920e-01
    z[2,8,3]  R1433     -7.5669950246810913e-01
    z[2,8,3]  R1434     4.7563002444803715e-03
    z[2,8,3]  R1435     8.6002998054027557e-02
    z[2,8,3]  R1436     -1.5803065896034241e-01
    z[2,8,3]  R1437     -5.2056068181991577e-01
    z[2,8,3]  R1438     -8.8108986616134644e-02
    z[2,8,3]  R1439     -1.6161488369107246e-02
    z[2,8,3]  R1440     -3.6090412735939026e-01
    z[2,8,3]  R1441     2.4224698543548584e-01
    z[2,8,3]  R1442     2.5279900431632996e-01
    z[2,8,3]  R1443     3.5884881019592285e-01
    z[2,8,3]  R1444     1.4230453968048096e-01
    z[2,8,3]  R1445     -1.0548471659421921e-01
    z[2,8,3]  R1446     9.3076996505260468e-02
    z[2,8,3]  R1447     1.9540201127529144e-01
    z[2,8,3]  R1448     -3.2591944932937622e-01
    z[2,8,3]  R1449     1.2794514000415802e-01
    z[2,8,3]  R1450     -3.7251997739076614e-02
    z[2,8,3]  R1451     -2.0874477922916412e-01
    z[2,8,3]  R1452     -4.8169005662202835e-02
    z[2,8,3]  R1453     -5.8753520250320435e-01
    z[2,8,3]  R1454     8.5866108536720276e-02
    z[2,8,3]  R1455     3.1356829404830933e-01
    z[2,8,3]  R1456     3.1444475054740906e-01
    z[2,8,3]  R1457     -4.0305379033088684e-01
    z[2,8,3]  R1458     1.4074213802814484e-01
    z[2,8,3]  R1459     -0.36433145403862
    z[2,8,3]  R1460     -1.5327471494674683e-01
    z[2,8,3]  R1461     6.5086834132671356e-02
    z[2,8,3]  R1462     -1.3650661706924438e-01
    z[2,8,3]  R1463     5.3470355272293091e-01
    z[2,8,3]  R1464     -1.8591515719890594e-01
    z[2,8,3]  R1465     -3.2681983709335327e-01
    z[2,8,3]  R1466     -1.1359921097755432e-01
    z[2,8,3]  R1467     1.7740766704082489e-01
    z[2,8,3]  R1468     -2.6093408465385437e-01
    z[2,8,3]  R1469     -2.4626623094081879e-01
    z[2,8,3]  R1470     1.6839888691902161e-01
    z[2,8,3]  R1471     1.1186099052429199e-01
    z[2,8,3]  R1472     2.2514252364635468e-01
    z[2,8,4]  R24       -1
    z[2,8,4]  R78       1
    z[2,8,4]  R1337     -1
    z[2,8,4]  R1338     1
    z[2,8,4]  R1343     -7.8915923833847046e-02
    z[2,8,4]  R1344     0.428545743227005
    z[2,8,4]  R1345     4.0092658251523972e-02
    z[2,8,4]  R1346     2.3380656540393829e-01
    z[2,8,4]  R1347     6.9126054644584656e-02
    z[2,8,4]  R1348     1.3722635805606842e-02
    z[2,8,4]  R1349     -4.2954348027706146e-02
    z[2,8,4]  R1350     6.9148249924182892e-02
    z[2,8,4]  R1351     7.5694270431995392e-02
    z[2,8,4]  R1352     1.7689904570579529e-01
    z[2,8,4]  R1353     -2.0937469601631165e-01
    z[2,8,4]  R1354     1.7088751494884491e-01
    z[2,8,4]  R1355     2.6169770956039429e-01
    z[2,8,4]  R1356     1.4486806094646454e-01
    z[2,8,4]  R1357     -2.8544503450393677e-01
    z[2,8,4]  R1358     -1.3903099298477173e-01
    z[2,8,4]  R1359     -3.1329038739204407e-01
    z[2,8,4]  R1360     5.2991223335266113e-01
    z[2,8,4]  R1361     -1.5408030152320862e-01
    z[2,8,4]  R1362     -3.4385478496551514e-01
    z[2,8,4]  R1363     0.374213308095932
    z[2,8,4]  R1364     4.6642562747001648e-01
    z[2,8,4]  R1365     -6.1091583967208862e-01
    z[2,8,4]  R1366     -6.4970010519027710e-01
    z[2,8,4]  R1367     -7.3790538311004639e-01
    z[2,8,4]  R1368     -7.9327005147933960e-01
    z[2,8,4]  R1369     5.8784413337707520e-01
    z[2,8,4]  R1370     -5.4279690980911255e-01
    z[2,8,4]  R1371     -1.8567000329494476e-01
    z[2,8,4]  R1372     0.0546242892742157
    z[2,8,4]  R1373     2.1512266248464584e-02
    z[2,8,4]  R1374     -5.9000805020332336e-02
    z[2,8,4]  R1375     -9.3802623450756073e-02
    z[2,8,4]  R1376     -5.2126395702362061e-01
    z[2,8,4]  R1377     -5.5842298269271851e-01
    z[2,8,4]  R1378     3.6576637625694275e-01
    z[2,8,4]  R1379     -5.5177640169858932e-02
    z[2,8,4]  R1380     -1.4764183759689331e-01
    z[2,8,4]  R1381     1.4394259080290794e-02
    z[2,8,4]  R1382     -6.8140465021133423e-01
    z[2,8,4]  R1383     -4.2736735939979553e-01
    z[2,8,4]  R1384     7.8438544273376465e-01
    z[2,8,4]  R1385     -3.9450488984584808e-02
    z[2,8,4]  R1386     -2.9868612065911293e-02
    z[2,8,4]  R1387     -1.2888021767139435e-01
    z[2,8,4]  R1388     1.3152818381786346e-01
    z[2,8,4]  R1389     2.6210722327232361e-01
    z[2,8,4]  R1390     5.1603776216506958e-01
    z[2,8,4]  R1391     3.6167123913764954e-01
    z[2,8,4]  R1392     5.5798208713531494e-01
    z[2,8,4]  R1393     6.0182854533195496e-02
    z[2,8,4]  R1394     0.334433376789093
    z[2,8,4]  R1395     3.5058698058128357e-01
    z[2,8,4]  R1396     -1.5981499850749969e-01
    z[2,8,4]  R1397     4.5273166894912720e-01
    z[2,8,4]  R1398     7.1975603699684143e-02
    z[2,8,4]  R1399     2.0932009816169739e-01
    z[2,8,4]  R1400     4.3899127840995789e-01
    z[2,8,4]  R1401     4.7448903322219849e-01
    z[2,8,4]  R1402     1.0534477978944778e-01
    z[2,8,4]  R1403     -2.8116098046302795e-01
    z[2,8,4]  R1404     -3.7564691901206970e-01
    z[2,8,4]  R1405     -2.3733133077621460e-01
    z[2,8,4]  R1406     4.0176185965538025e-01
    z[2,8,4]  R1407     -3.4186564385890961e-02
    z[2,8,4]  R1408     -2.3181053996086121e-01
    z[2,8,4]  R1409     -1.7737166583538055e-01
    z[2,8,4]  R1410     1.1563534289598465e-01
    z[2,8,4]  R1411     -0.551505982875824
    z[2,8,4]  R1412     3.9585113525390625e-01
    z[2,8,4]  R1413     1.0906083509325981e-02
    z[2,8,4]  R1414     -3.6826786398887634e-01
    z[2,8,4]  R1415     -6.5377938747406006e-01
    z[2,8,4]  R1416     -7.1659630537033081e-01
    z[2,8,4]  R1417     -5.6170392036437988e-01
    z[2,8,4]  R1418     -6.2472081184387207e-01
    z[2,8,4]  R1419     -0.252750426530838
    z[2,8,4]  R1420     -6.1852902173995972e-01
    z[2,8,4]  R1421     -7.0063984394073486e-01
    z[2,8,4]  R1422     -6.9972926378250122e-01
    z[2,8,4]  R1423     2.1617035567760468e-01
    z[2,8,4]  R1424     -1.0089616477489471e-01
    z[2,8,4]  R1425     3.2417541742324829e-01
    z[2,8,4]  R1426     -2.3014199733734131e-01
    z[2,8,4]  R1427     -3.6255308985710144e-01
    z[2,8,4]  R1428     1.5050463378429413e-01
    z[2,8,4]  R1429     2.3566101491451263e-01
    z[2,8,4]  R1430     2.0459690690040588e-01
    z[2,8,4]  R1431     -4.9369612336158752e-01
    z[2,8,4]  R1432     1.3406861573457718e-02
    z[2,8,4]  R1433     7.9505115747451782e-02
    z[2,8,4]  R1434     -4.9428895115852356e-01
    z[2,8,4]  R1435     -0.0761650800704956
    z[2,8,4]  R1436     -2.6672041416168213e-01
    z[2,8,4]  R1437     3.6464941501617432e-01
    z[2,8,4]  R1438     -2.1595989167690277e-01
    z[2,8,4]  R1439     -6.0959827899932861e-01
    z[2,8,4]  R1440     3.5240563750267029e-01
    z[2,8,4]  R1441     1.9147807359695435e-01
    z[2,8,4]  R1442     -9.4949059188365936e-02
    z[2,8,4]  R1443     -4.2940896749496460e-01
    z[2,8,4]  R1444     2.9315361380577087e-01
    z[2,8,4]  R1445     -0.0841350331902504
    z[2,8,4]  R1446     1.3752470910549164e-01
    z[2,8,4]  R1447     1.0821728408336639e-01
    z[2,8,4]  R1448     -3.8458526134490967e-02
    z[2,8,4]  R1449     7.3545169830322266e-01
    z[2,8,4]  R1450     -2.6146358251571655e-01
    z[2,8,4]  R1451     2.3412831127643585e-02
    z[2,8,4]  R1452     4.8646613955497742e-02
    z[2,8,4]  R1453     1.9688895344734192e-01
    z[2,8,4]  R1454     -2.6365187764167786e-01
    z[2,8,4]  R1455     1.6216847300529480e-01
    z[2,8,4]  R1456     1.0183297097682953e-01
    z[2,8,4]  R1457     3.6613830924034119e-01
    z[2,8,4]  R1458     2.5276171043515205e-02
    z[2,8,4]  R1459     3.9034810662269592e-01
    z[2,8,4]  R1460     -5.8465617895126343e-01
    z[2,8,4]  R1461     -5.4090458154678345e-01
    z[2,8,4]  R1462     -2.1702301502227783e-01
    z[2,8,4]  R1463     -2.1139633655548096e-01
    z[2,8,4]  R1464     -5.1421147584915161e-01
    z[2,8,4]  R1465     3.8064935803413391e-01
    z[2,8,4]  R1466     2.8179755806922913e-01
    z[2,8,4]  R1467     1.6003543511033058e-02
    z[2,8,4]  R1468     -2.0782912150025368e-02
    z[2,8,4]  R1469     2.2558422386646271e-01
    z[2,8,4]  R1470     -1.8514131009578705e-01
    z[2,8,4]  R1471     2.2753329575061798e-01
    z[2,8,4]  R1472     5.2067141979932785e-02
    z[2,8,5]  R25       -1
    z[2,8,5]  R79       1
    z[2,8,5]  R1339     -1
    z[2,8,5]  R1340     1
    z[2,8,5]  R1343     -7.5600284337997437e-01
    z[2,8,5]  R1344     2.0925825461745262e-02
    z[2,8,5]  R1345     -1.7519956827163696e-01
    z[2,8,5]  R1346     -8.5107326507568359e-02
    z[2,8,5]  R1347     -0.129975363612175
    z[2,8,5]  R1348     -1.1450179852545261e-02
    z[2,8,5]  R1349     -1.1037198454141617e-01
    z[2,8,5]  R1350     -2.7068577706813812e-02
    z[2,8,5]  R1351     -7.5989085435867310e-01
    z[2,8,5]  R1352     -3.5837404429912567e-02
    z[2,8,5]  R1353     3.9327001571655273e-01
    z[2,8,5]  R1354     4.1641193628311157e-01
    z[2,8,5]  R1355     2.6392295956611633e-01
    z[2,8,5]  R1356     3.1351518630981445e-01
    z[2,8,5]  R1357     2.3337078094482422e-01
    z[2,8,5]  R1358     1.4271828532218933e-01
    z[2,8,5]  R1359     2.5921770930290222e-01
    z[2,8,5]  R1360     7.6674565672874451e-02
    z[2,8,5]  R1361     6.4962792396545410e-01
    z[2,8,5]  R1362     1.5710996091365814e-01
    z[2,8,5]  R1363     5.7025891542434692e-01
    z[2,8,5]  R1364     3.2565575838088989e-01
    z[2,8,5]  R1365     -1.7744678258895874e-01
    z[2,8,5]  R1366     4.8563620448112488e-01
    z[2,8,5]  R1367     4.1208315640687943e-02
    z[2,8,5]  R1368     4.6365055441856384e-01
    z[2,8,5]  R1369     0.0964667871594429
    z[2,8,5]  R1370     2.7510568499565125e-01
    z[2,8,5]  R1371     1.1066298931837082e-01
    z[2,8,5]  R1372     -1.0694700479507446e-01
    z[2,8,5]  R1373     -3.7286561727523804e-01
    z[2,8,5]  R1374     -6.1039716005325317e-01
    z[2,8,5]  R1375     1.7148524522781372e-01
    z[2,8,5]  R1376     -8.9085720479488373e-02
    z[2,8,5]  R1377     6.5611422061920166e-02
    z[2,8,5]  R1378     -4.1812869906425476e-01
    z[2,8,5]  R1379     0.286979079246521
    z[2,8,5]  R1380     -1.7271885275840759e-01
    z[2,8,5]  R1381     8.1810927391052246e-01
    z[2,8,5]  R1382     -3.4268322587013245e-01
    z[2,8,5]  R1383     -2.9487481713294983e-01
    z[2,8,5]  R1384     3.1709179282188416e-01
    z[2,8,5]  R1385     -6.1188173294067383e-01
    z[2,8,5]  R1386     -1.8844248354434967e-01
    z[2,8,5]  R1387     -2.4835785850882530e-02
    z[2,8,5]  R1388     1.9847498834133148e-01
    z[2,8,5]  R1389     -4.3695300817489624e-01
    z[2,8,5]  R1390     -3.2630094885826111e-01
    z[2,8,5]  R1391     -1.2975083291530609e-01
    z[2,8,5]  R1392     -2.3591253161430359e-01
    z[2,8,5]  R1393     -4.0111333131790161e-02
    z[2,8,5]  R1394     -2.9458436369895935e-01
    z[2,8,5]  R1395     -1.7900609970092773e-01
    z[2,8,5]  R1396     -2.3825907707214355e-01
    z[2,8,5]  R1397     1.9674451649188995e-01
    z[2,8,5]  R1398     -1.5321678481996059e-02
    z[2,8,5]  R1399     1.6504010185599327e-02
    z[2,8,5]  R1400     -5.1086336374282837e-02
    z[2,8,5]  R1401     -2.1501930430531502e-02
    z[2,8,5]  R1402     -2.1900095045566559e-01
    z[2,8,5]  R1403     -3.8801664113998413e-01
    z[2,8,5]  R1404     2.5432538986206055e-01
    z[2,8,5]  R1405     7.7942825853824615e-02
    z[2,8,5]  R1406     4.9140501767396927e-02
    z[2,8,5]  R1407     7.6111115515232086e-02
    z[2,8,5]  R1408     2.5701296329498291e-01
    z[2,8,5]  R1409     -8.5745364427566528e-02
    z[2,8,5]  R1410     -1.9198076426982880e-01
    z[2,8,5]  R1411     -9.8238639533519745e-02
    z[2,8,5]  R1412     -1.8779900670051575e-01
    z[2,8,5]  R1413     9.1455176472663879e-02
    z[2,8,5]  R1414     5.8820914477109909e-02
    z[2,8,5]  R1415     3.6578190326690674e-01
    z[2,8,5]  R1416     3.0248314142227173e-01
    z[2,8,5]  R1417     3.5836723446846008e-01
    z[2,8,5]  R1418     2.0174258947372437e-01
    z[2,8,5]  R1419     2.4466985464096069e-01
    z[2,8,5]  R1420     1.2938182055950165e-01
    z[2,8,5]  R1421     0.203104168176651
    z[2,8,5]  R1422     1.5726454555988312e-01
    z[2,8,5]  R1423     2.4988044798374176e-01
    z[2,8,5]  R1424     -1.2344833463430405e-01
    z[2,8,5]  R1425     1.9207081198692322e-01
    z[2,8,5]  R1426     1.0046100616455078e-01
    z[2,8,5]  R1427     -9.2327609658241272e-02
    z[2,8,5]  R1428     -1.4799048006534576e-01
    z[2,8,5]  R1429     4.6228629350662231e-01
    z[2,8,5]  R1430     -4.0209221839904785e-01
    z[2,8,5]  R1431     2.8853037953376770e-01
    z[2,8,5]  R1432     3.7438431382179260e-01
    z[2,8,5]  R1433     3.8681104779243469e-01
    z[2,8,5]  R1434     -3.5120215266942978e-02
    z[2,8,5]  R1435     1.3741073012351990e-01
    z[2,8,5]  R1436     2.6251502335071564e-02
    z[2,8,5]  R1437     -3.3485063910484314e-01
    z[2,8,5]  R1438     5.3847837448120117e-01
    z[2,8,5]  R1439     6.3186037540435791e-01
    z[2,8,5]  R1440     3.7381444126367569e-02
    z[2,8,5]  R1441     9.3511477112770081e-02
    z[2,8,5]  R1442     0.371217280626297
    z[2,8,5]  R1443     3.6413182970136404e-03
    z[2,8,5]  R1444     -2.0216912031173706e-01
    z[2,8,5]  R1445     1.0431414842605591e-01
    z[2,8,5]  R1446     1.1590618640184402e-02
    z[2,8,5]  R1447     -7.2658024728298187e-02
    z[2,8,5]  R1448     -6.2452876567840576e-01
    z[2,8,5]  R1449     3.4534335136413574e-01
    z[2,8,5]  R1450     -1.0845420509576797e-01
    z[2,8,5]  R1451     -6.4834314584732056e-01
    z[2,8,5]  R1452     -4.9363338947296143e-01
    z[2,8,5]  R1453     0.472953200340271
    z[2,8,5]  R1454     7.3955051600933075e-02
    z[2,8,5]  R1455     5.4328376054763794e-01
    z[2,8,5]  R1456     3.9821276068687439e-01
    z[2,8,5]  R1457     -1.3570861518383026e-01
    z[2,8,5]  R1458     -2.8387421369552612e-01
    z[2,8,5]  R1459     1.7517729103565216e-01
    z[2,8,5]  R1460     5.7705128192901611e-01
    z[2,8,5]  R1461     4.4803205132484436e-01
    z[2,8,5]  R1462     -4.0736470371484756e-02
    z[2,8,5]  R1463     -3.5944998264312744e-02
    z[2,8,5]  R1464     6.0712260007858276e-01
    z[2,8,5]  R1465     2.9833678156137466e-02
    z[2,8,5]  R1466     -2.2303852438926697e-01
    z[2,8,5]  R1467     -4.6621689200401306e-01
    z[2,8,5]  R1468     7.1863436698913574e-01
    z[2,8,5]  R1469     -3.0003547668457031e-01
    z[2,8,5]  R1470     -4.7163897752761841e-01
    z[2,8,5]  R1471     1.7729481682181358e-02
    z[2,8,5]  R1472     -9.3078408390283585e-03
    z[2,8,6]  R26       -1
    z[2,8,6]  R80       1
    z[2,8,6]  R1341     -1
    z[2,8,6]  R1342     1
    z[2,8,6]  R1343     1.6713712364435196e-02
    z[2,8,6]  R1344     1.3852766156196594e-01
    z[2,8,6]  R1345     -2.6451028883457184e-02
    z[2,8,6]  R1346     6.5301500260829926e-02
    z[2,8,6]  R1347     -2.0380245149135590e-01
    z[2,8,6]  R1348     1.8621627986431122e-01
    z[2,8,6]  R1349     3.7159714102745056e-01
    z[2,8,6]  R1350     5.8207410573959351e-01
    z[2,8,6]  R1351     -9.7229331731796265e-02
    z[2,8,6]  R1352     9.8299160599708557e-02
    z[2,8,6]  R1353     -8.5928887128829956e-02
    z[2,8,6]  R1354     -5.0952263176441193e-02
    z[2,8,6]  R1355     0.290477991104126
    z[2,8,6]  R1356     9.4562888145446777e-02
    z[2,8,6]  R1357     4.1986885666847229e-01
    z[2,8,6]  R1358     -0.355317622423172
    z[2,8,6]  R1359     3.1535494327545166e-01
    z[2,8,6]  R1360     -2.3087418079376221e-01
    z[2,8,6]  R1361     -5.2109336853027344e-01
    z[2,8,6]  R1362     -5.1472866535186768e-01
    z[2,8,6]  R1363     6.4978986978530884e-01
    z[2,8,6]  R1364     1.3804058730602264e-01
    z[2,8,6]  R1365     2.4975056946277618e-01
    z[2,8,6]  R1366     1.1272017657756805e-01
    z[2,8,6]  R1367     -2.0698155462741852e-01
    z[2,8,6]  R1368     -7.2273783385753632e-02
    z[2,8,6]  R1369     4.9550160765647888e-02
    z[2,8,6]  R1370     1.1164902895689011e-01
    z[2,8,6]  R1371     -2.0635692775249481e-01
    z[2,8,6]  R1372     2.0182704925537109e-01
    z[2,8,6]  R1373     -4.6101385354995728e-01
    z[2,8,6]  R1374     2.6499542593955994e-01
    z[2,8,6]  R1375     -1.4004588127136230e-01
    z[2,8,6]  R1376     -4.1854989528656006e-01
    z[2,8,6]  R1377     1.0906316339969635e-01
    z[2,8,6]  R1378     4.3054428696632385e-01
    z[2,8,6]  R1379     0.090914286673069
    z[2,8,6]  R1380     -0.0802655816078186
    z[2,8,6]  R1381     -4.3816640973091125e-01
    z[2,8,6]  R1382     2.2761696577072144e-01
    z[2,8,6]  R1383     6.0557309538125992e-02
    z[2,8,6]  R1384     -8.9875146746635437e-02
    z[2,8,6]  R1385     6.1374053359031677e-02
    z[2,8,6]  R1386     1.6884168609976768e-02
    z[2,8,6]  R1387     4.2412549257278442e-01
    z[2,8,6]  R1388     5.1192098855972290e-01
    z[2,8,6]  R1389     -3.0343142151832581e-01
    z[2,8,6]  R1390     2.0778505504131317e-01
    z[2,8,6]  R1391     -1.2761445343494415e-01
    z[2,8,6]  R1392     -0.400240957736969
    z[2,8,6]  R1393     -1.7198163270950317e-01
    z[2,8,6]  R1394     9.7616732120513916e-02
    z[2,8,6]  R1395     8.6575500667095184e-02
    z[2,8,6]  R1396     2.6357337832450867e-01
    z[2,8,6]  R1397     9.2977419495582581e-02
    z[2,8,6]  R1398     1.7765671014785767e-01
    z[2,8,6]  R1399     0.538210928440094
    z[2,8,6]  R1400     -9.9790245294570923e-02
    z[2,8,6]  R1401     0.267120897769928
    z[2,8,6]  R1402     -7.2021287679672241e-01
    z[2,8,6]  R1403     1.5352459251880646e-01
    z[2,8,6]  R1404     0.329188734292984
    z[2,8,6]  R1405     2.3916792869567871e-01
    z[2,8,6]  R1406     -1.8713575601577759e-01
    z[2,8,6]  R1407     4.9038669466972351e-01
    z[2,8,6]  R1408     -2.7009156346321106e-01
    z[2,8,6]  R1409     5.6678575277328491e-01
    z[2,8,6]  R1410     3.7452098727226257e-01
    z[2,8,6]  R1411     1.6239304840564728e-01
    z[2,8,6]  R1412     3.7542721629142761e-01
    z[2,8,6]  R1413     -5.5112581700086594e-02
    z[2,8,6]  R1414     -4.4175809621810913e-01
    z[2,8,6]  R1415     2.0904199779033661e-01
    z[2,8,6]  R1416     -3.4600594639778137e-01
    z[2,8,6]  R1417     1.0638792812824249e-01
    z[2,8,6]  R1418     5.7504154741764069e-02
    z[2,8,6]  R1419     7.3766849935054779e-02
    z[2,8,6]  R1420     3.7288421392440796e-01
    z[2,8,6]  R1421     -3.0995625257492065e-01
    z[2,8,6]  R1422     -2.8730648756027222e-01
    z[2,8,6]  R1423     -3.0975034832954407e-01
    z[2,8,6]  R1424     2.0896416902542114e-01
    z[2,8,6]  R1425     1.2505804002285004e-01
    z[2,8,6]  R1426     -5.4767656326293945e-01
    z[2,8,6]  R1427     -5.5913275480270386e-01
    z[2,8,6]  R1428     -2.9187005758285522e-01
    z[2,8,6]  R1429     5.7579171657562256e-01
    z[2,8,6]  R1430     -4.8718109726905823e-01
    z[2,8,6]  R1431     -5.5757766962051392e-01
    z[2,8,6]  R1432     1.5979956090450287e-01
    z[2,8,6]  R1433     1.1773577332496643e-01
    z[2,8,6]  R1434     -1.1788261681795120e-01
    z[2,8,6]  R1435     3.7980252504348755e-01
    z[2,8,6]  R1436     -1.0959913581609726e-01
    z[2,8,6]  R1437     -1.5310059487819672e-01
    z[2,8,6]  R1438     -7.4085518717765808e-02
    z[2,8,6]  R1439     -1.8072827160358429e-01
    z[2,8,6]  R1440     -4.6383801102638245e-01
    z[2,8,6]  R1441     1.4695416390895844e-01
    z[2,8,6]  R1442     2.5241279974579811e-02
    z[2,8,6]  R1443     -2.5018927454948425e-01
    z[2,8,6]  R1444     -3.3541226387023926e-01
    z[2,8,6]  R1445     3.1361293792724609e-01
    z[2,8,6]  R1446     2.8857663273811340e-01
    z[2,8,6]  R1447     -2.0775970816612244e-01
    z[2,8,6]  R1448     4.2690834403038025e-01
    z[2,8,6]  R1449     -2.1375331282615662e-01
    z[2,8,6]  R1450     1.6016711294651031e-01
    z[2,8,6]  R1451     8.2306535914540291e-03
    z[2,8,6]  R1452     1.4425319433212280e-01
    z[2,8,6]  R1453     5.8335000276565552e-01
    z[2,8,6]  R1454     -2.3129422962665558e-01
    z[2,8,6]  R1455     1.6793212294578552e-01
    z[2,8,6]  R1456     -3.8830515742301941e-01
    z[2,8,6]  R1457     -3.7465396523475647e-01
    z[2,8,6]  R1458     5.2417159080505371e-02
    z[2,8,6]  R1459     -0.200520858168602
    z[2,8,6]  R1460     2.5251591205596924e-01
    z[2,8,6]  R1461     -0.011157201603055
    z[2,8,6]  R1462     4.9335334450006485e-02
    z[2,8,6]  R1463     -4.9009706825017929e-02
    z[2,8,6]  R1464     1.0897734016180038e-01
    z[2,8,6]  R1465     -2.9252591729164124e-01
    z[2,8,6]  R1466     9.0420506894588470e-02
    z[2,8,6]  R1467     -2.0941365510225296e-02
    z[2,8,6]  R1468     -4.7655689716339111e-01
    z[2,8,6]  R1469     -3.7927865982055664e-01
    z[2,8,6]  R1470     0.0328315831720829
    z[2,8,6]  R1471     -1.6944380104541779e-01
    z[2,8,6]  R1472     -7.0934578776359558e-02
    z[8,2,0]  R20       1
    z[8,2,0]  R74       -1
    z[8,2,0]  R1473     -1
    z[8,2,0]  R1474     1
    z[8,2,0]  R1487     -4.1689458489418030e-01
    z[8,2,0]  R1488     -4.8468196392059326e-01
    z[8,2,0]  R1489     -5.7306480407714844e-01
    z[8,2,0]  R1490     -3.4239238500595093e-01
    z[8,2,0]  R1491     -6.0957503318786621e-01
    z[8,2,0]  R1492     -3.2015225291252136e-01
    z[8,2,0]  R1493     -3.0857360363006592e-01
    z[8,2,0]  R1494     -3.9235708117485046e-01
    z[8,2,0]  R1495     -3.4801444411277771e-01
    z[8,2,0]  R1496     3.6987990140914917e-02
    z[8,2,0]  R1497     3.7160363048315048e-02
    z[8,2,0]  R1498     4.9446426331996918e-02
    z[8,2,0]  R1499     9.2987410724163055e-02
    z[8,2,0]  R1500     1.6451187431812286e-01
    z[8,2,0]  R1501     3.8392234593629837e-02
    z[8,2,0]  R1502     2.3820878937840462e-02
    z[8,2,0]  R1503     -3.6871144175529480e-01
    z[8,2,0]  R1504     -1.8168369308114052e-02
    z[8,2,0]  R1505     4.3558844923973083e-01
    z[8,2,0]  R1506     -3.8961544632911682e-02
    z[8,2,0]  R1507     2.1219049394130707e-01
    z[8,2,0]  R1508     1.0946871340274811e-01
    z[8,2,0]  R1509     -1.0069070756435394e-01
    z[8,2,0]  R1510     5.2443742752075195e-02
    z[8,2,0]  R1511     2.7736195921897888e-01
    z[8,2,0]  R1512     -9.2849425971508026e-02
    z[8,2,0]  R1513     -9.0580090880393982e-02
    z[8,2,0]  R1514     -1.5218126773834229e-01
    z[8,2,0]  R1515     -3.0100749805569649e-02
    z[8,2,0]  R1516     -3.4075182676315308e-01
    z[8,2,0]  R1517     -1.8804021179676056e-01
    z[8,2,0]  R1518     -1.2020721286535263e-01
    z[8,2,0]  R1519     1.3284712098538876e-02
    z[8,2,0]  R1520     -1.1131456494331360e-01
    z[8,2,0]  R1521     -1.0430975258350372e-01
    z[8,2,0]  R1522     -2.2587503492832184e-01
    z[8,2,0]  R1523     -1.0576321184635162e-01
    z[8,2,0]  R1524     -2.6120189577341080e-02
    z[8,2,0]  R1525     8.6152262985706329e-02
    z[8,2,0]  R1526     1.7868988215923309e-01
    z[8,2,0]  R1527     2.1687847375869751e-01
    z[8,2,0]  R1528     -7.6703220605850220e-02
    z[8,2,0]  R1529     -5.7236045598983765e-01
    z[8,2,0]  R1530     3.7944954633712769e-01
    z[8,2,0]  R1531     -1.9736465811729431e-01
    z[8,2,0]  R1532     -3.9486771821975708e-01
    z[8,2,0]  R1533     0.0852629616856575
    z[8,2,0]  R1534     -2.9006785154342651e-01
    z[8,2,0]  R1535     1.5264980494976044e-01
    z[8,2,0]  R1536     2.2403240203857422e-01
    z[8,2,0]  R1537     -2.2230571508407593e-01
    z[8,2,0]  R1538     -3.1105026602745056e-01
    z[8,2,0]  R1539     -5.1620435714721680e-01
    z[8,2,0]  R1540     -1.7105893790721893e-01
    z[8,2,0]  R1541     2.1935540437698364e-01
    z[8,2,0]  R1542     1.0663330322131515e-03
    z[8,2,0]  R1543     -3.1086322665214539e-01
    z[8,2,0]  R1544     4.4636088609695435e-01
    z[8,2,0]  R1545     6.9318538904190063e-01
    z[8,2,0]  R1546     8.1855165958404541e-01
    z[8,2,0]  R1547     4.0272515267133713e-02
    z[8,2,0]  R1548     3.4263002872467041e-01
    z[8,2,0]  R1549     -1.5010145306587219e-01
    z[8,2,0]  R1550     -1.5877915918827057e-01
    z[8,2,0]  R1551     -2.8038141131401062e-01
    z[8,2,0]  R1552     2.9783645272254944e-01
    z[8,2,0]  R1553     -3.5361889004707336e-01
    z[8,2,0]  R1554     -2.7545174956321716e-01
    z[8,2,0]  R1555     -3.9055564999580383e-01
    z[8,2,0]  R1556     3.1482365727424622e-01
    z[8,2,0]  R1557     1.7461758852005005e-01
    z[8,2,0]  R1558     -2.4204730987548828e-01
    z[8,2,0]  R1559     -3.5855054855346680e-01
    z[8,2,0]  R1560     -2.6036825776100159e-01
    z[8,2,0]  R1561     2.1546375751495361e-01
    z[8,2,0]  R1562     6.7238390445709229e-02
    z[8,2,0]  R1563     -2.7760851383209229e-01
    z[8,2,0]  R1564     7.6810318231582642e-01
    z[8,2,0]  R1565     9.5003110170364380e-01
    z[8,2,0]  R1566     9.3456918001174927e-01
    z[8,2,0]  R1567     -2.1391913294792175e-01
    z[8,2,0]  R1568     -2.6369300484657288e-01
    z[8,2,0]  R1569     -2.0321425795555115e-01
    z[8,2,0]  R1570     -1.2211536616086960e-01
    z[8,2,0]  R1571     -2.1548202633857727e-01
    z[8,2,0]  R1572     -5.0030261278152466e-01
    z[8,2,0]  R1573     -0.0824422836303711
    z[8,2,0]  R1574     -6.5397894382476807e-01
    z[8,2,0]  R1575     4.9234387278556824e-01
    z[8,2,0]  R1576     1.8694119155406952e-01
    z[8,2,0]  R1577     1.5439975261688232e-01
    z[8,2,0]  R1578     1.5032652020454407e-01
    z[8,2,0]  R1579     4.4251907616853714e-02
    z[8,2,0]  R1580     -1.5841630101203918e-01
    z[8,2,0]  R1581     -9.2788815498352051e-02
    z[8,2,0]  R1582     -1.2571211159229279e-01
    z[8,2,0]  R1583     -2.2419813275337219e-01
    z[8,2,0]  R1584     2.2780667245388031e-01
    z[8,2,0]  R1585     -3.2894098758697510e-01
    z[8,2,0]  R1586     -2.4866597354412079e-01
    z[8,2,0]  R1587     5.2616402506828308e-02
    z[8,2,0]  R1588     2.7954089641571045e-01
    z[8,2,0]  R1589     6.4820271730422974e-01
    z[8,2,0]  R1590     -1.4740100130438805e-02
    z[8,2,0]  R1591     -4.6165034174919128e-02
    z[8,2,0]  R1592     7.8379977494478226e-03
    z[8,2,0]  R1593     6.3006269931793213e-01
    z[8,2,0]  R1594     1.4017288386821747e-01
    z[8,2,0]  R1595     -2.4023541808128357e-01
    z[8,2,0]  R1596     -3.9358308911323547e-01
    z[8,2,0]  R1597     -1.4701075851917267e-01
    z[8,2,0]  R1598     4.1678366065025330e-01
    z[8,2,0]  R1599     -1.3015897572040558e-01
    z[8,2,0]  R1600     6.1288721859455109e-02
    z[8,2,0]  R1601     -1.8016344308853149e-01
    z[8,2,0]  R1602     2.5706410408020020e-01
    z[8,2,0]  R1603     1.9248086214065552e-01
    z[8,2,0]  R1604     5.2797567844390869e-01
    z[8,2,0]  R1605     -6.0768104158341885e-03
    z[8,2,0]  R1606     -1.8545801937580109e-01
    z[8,2,0]  R1607     3.7204214930534363e-01
    z[8,2,0]  R1608     3.1403880566358566e-02
    z[8,2,0]  R1609     4.0567180514335632e-01
    z[8,2,0]  R1610     2.0946851000189781e-03
    z[8,2,0]  R1611     -1.9522626698017120e-01
    z[8,2,0]  R1612     1.6009330749511719e-01
    z[8,2,0]  R1613     5.6637412309646606e-01
    z[8,2,0]  R1614     1.4716935157775879e-01
    z[8,2,0]  R1615     2.0530971884727478e-01
    z[8,2,0]  R1616     2.2877733409404755e-01
    z[8,2,1]  R21       1
    z[8,2,1]  R75       -1
    z[8,2,1]  R1475     -1
    z[8,2,1]  R1476     1
    z[8,2,1]  R1487     -3.3204442262649536e-01
    z[8,2,1]  R1488     -2.5690299272537231e-01
    z[8,2,1]  R1489     -4.6997055411338806e-01
    z[8,2,1]  R1490     -4.6174040436744690e-01
    z[8,2,1]  R1491     -4.8508054018020630e-01
    z[8,2,1]  R1492     -0.602096676826477
    z[8,2,1]  R1493     1.2655800208449364e-02
    z[8,2,1]  R1494     -1.6722084954380989e-02
    z[8,2,1]  R1495     -1.5665067732334137e-01
    z[8,2,1]  R1496     2.9285481572151184e-01
    z[8,2,1]  R1497     7.0536142587661743e-01
    z[8,2,1]  R1498     3.4541028738021851e-01
    z[8,2,1]  R1499     0.516209065914154
    z[8,2,1]  R1500     4.8548287153244019e-01
    z[8,2,1]  R1501     3.3199149370193481e-01
    z[8,2,1]  R1502     5.1212704181671143e-01
    z[8,2,1]  R1503     5.9532564878463745e-01
    z[8,2,1]  R1504     6.3990515470504761e-01
    z[8,2,1]  R1505     4.8651802539825439e-01
    z[8,2,1]  R1506     4.3544858694076538e-01
    z[8,2,1]  R1507     -3.4603667259216309e-01
    z[8,2,1]  R1508     0.720102846622467
    z[8,2,1]  R1509     -4.8885107971727848e-03
    z[8,2,1]  R1510     6.4501903951168060e-02
    z[8,2,1]  R1511     -2.0838995277881622e-01
    z[8,2,1]  R1512     -2.4802862107753754e-01
    z[8,2,1]  R1513     -7.4762886762619019e-01
    z[8,2,1]  R1514     4.9201175570487976e-02
    z[8,2,1]  R1515     3.2671761512756348e-01
    z[8,2,1]  R1516     -1.0198544710874557e-01
    z[8,2,1]  R1517     -2.8616625815629959e-02
    z[8,2,1]  R1518     3.1933152675628662e-01
    z[8,2,1]  R1519     6.5530651807785034e-01
    z[8,2,1]  R1520     -7.6302891969680786e-01
    z[8,2,1]  R1521     -0.713287353515625
    z[8,2,1]  R1522     3.4502479434013367e-01
    z[8,2,1]  R1523     -1.5632529556751251e-01
    z[8,2,1]  R1524     4.4123733043670654e-01
    z[8,2,1]  R1525     -4.0507555007934570e-01
    z[8,2,1]  R1526     -7.1970999240875244e-02
    z[8,2,1]  R1527     -1.0386711359024048e-01
    z[8,2,1]  R1528     -0.826941728591919
    z[8,2,1]  R1529     5.5064874887466431e-01
    z[8,2,1]  R1530     5.6682562828063965e-01
    z[8,2,1]  R1531     -0.637488067150116
    z[8,2,1]  R1532     3.1302982568740845e-01
    z[8,2,1]  R1533     -4.3343013525009155e-01
    z[8,2,1]  R1534     -5.8169806003570557e-01
    z[8,2,1]  R1535     8.8284105062484741e-01
    z[8,2,1]  R1536     7.3823785781860352e-01
    z[8,2,1]  R1537     -7.5214987993240356e-01
    z[8,2,1]  R1538     4.9054896831512451e-01
    z[8,2,1]  R1539     4.3570250272750854e-01
    z[8,2,1]  R1540     9.2652714252471924e-01
    z[8,2,1]  R1541     8.0565035343170166e-01
    z[8,2,1]  R1542     -5.6556481122970581e-01
    z[8,2,1]  R1543     4.0573990345001221e-01
    z[8,2,1]  R1544     6.1703330278396606e-01
    z[8,2,1]  R1545     -1.1697446554899216e-01
    z[8,2,1]  R1546     -1.9792547821998596e-01
    z[8,2,1]  R1547     -1.3860097527503967e-01
    z[8,2,1]  R1548     0.715706467628479
    z[8,2,1]  R1549     6.6889148950576782e-01
    z[8,2,1]  R1550     2.9724597930908203e-01
    z[8,2,1]  R1551     -6.8008792400360107e-01
    z[8,2,1]  R1552     8.8679903745651245e-01
    z[8,2,1]  R1553     -7.1929872035980225e-01
    z[8,2,1]  R1554     -3.0911669135093689e-01
    z[8,2,1]  R1555     3.7147161364555359e-01
    z[8,2,1]  R1556     0.74797123670578
    z[8,2,1]  R1557     7.5768578052520752e-01
    z[8,2,1]  R1558     -3.3206534385681152e-01
    z[8,2,1]  R1559     -7.1302127838134766e-01
    z[8,2,1]  R1560     6.7258435487747192e-01
    z[8,2,1]  R1561     7.0505040884017944e-01
    z[8,2,1]  R1562     -6.5480205230414867e-03
    z[8,2,1]  R1563     -7.0366328954696655e-01
    z[8,2,1]  R1564     -3.0529114603996277e-01
    z[8,2,1]  R1565     1.3688798062503338e-02
    z[8,2,1]  R1566     4.1255757212638855e-02
    z[8,2,1]  R1567     3.6962968111038208e-01
    z[8,2,1]  R1568     -2.2585336863994598e-01
    z[8,2,1]  R1569     -6.3878291845321655e-01
    z[8,2,1]  R1570     -0.637885332107544
    z[8,2,1]  R1571     -6.2792015075683594e-01
    z[8,2,1]  R1572     -2.5551816448569298e-02
    z[8,2,1]  R1573     -5.1065891981124878e-01
    z[8,2,1]  R1574     -1.5931475162506104e-01
    z[8,2,1]  R1575     3.9877825975418091e-01
    z[8,2,1]  R1576     -3.3519566059112549e-01
    z[8,2,1]  R1577     7.4821001291275024e-01
    z[8,2,1]  R1578     6.2233549356460571e-01
    z[8,2,1]  R1579     7.0716559886932373e-01
    z[8,2,1]  R1580     3.4581381082534790e-01
    z[8,2,1]  R1581     6.0509526729583740e-01
    z[8,2,1]  R1582     4.4489392638206482e-01
    z[8,2,1]  R1583     3.5442498326301575e-01
    z[8,2,1]  R1584     7.3422580957412720e-01
    z[8,2,1]  R1585     2.3457735776901245e-01
    z[8,2,1]  R1586     -9.4344671815633774e-03
    z[8,2,1]  R1587     -2.1630187332630157e-01
    z[8,2,1]  R1588     2.5966829061508179e-01
    z[8,2,1]  R1589     -8.5281684994697571e-02
    z[8,2,1]  R1590     -3.4813082218170166e-01
    z[8,2,1]  R1591     1.0931760072708130e-01
    z[8,2,1]  R1592     1.7637154459953308e-01
    z[8,2,1]  R1593     2.9924153932370245e-04
    z[8,2,1]  R1594     -1.2882173061370850e-01
    z[8,2,1]  R1595     -8.5850799083709717e-01
    z[8,2,1]  R1596     -7.5027018785476685e-01
    z[8,2,1]  R1597     4.6310821175575256e-01
    z[8,2,1]  R1598     -2.0021395385265350e-01
    z[8,2,1]  R1599     4.8950418829917908e-01
    z[8,2,1]  R1600     9.9311359226703644e-02
    z[8,2,1]  R1601     1.8918801844120026e-01
    z[8,2,1]  R1602     3.7089128047227859e-02
    z[8,2,1]  R1603     1.0083258152008057e-01
    z[8,2,1]  R1604     3.7639137357473373e-02
    z[8,2,1]  R1605     -2.0759311318397522e-01
    z[8,2,1]  R1606     -9.5413953065872192e-02
    z[8,2,1]  R1607     7.0166522264480591e-01
    z[8,2,1]  R1608     -3.6928680539131165e-01
    z[8,2,1]  R1609     3.2252028584480286e-01
    z[8,2,1]  R1610     8.6657595634460449e-01
    z[8,2,1]  R1611     0.43874591588974
    z[8,2,1]  R1612     0.78117436170578
    z[8,2,1]  R1613     5.4525947570800781e-01
    z[8,2,1]  R1614     1.4030268788337708e-01
    z[8,2,1]  R1615     -2.6873552799224854e-01
    z[8,2,1]  R1616     -4.1345305740833282e-02
    z[8,2,2]  R22       1
    z[8,2,2]  R76       -1
    z[8,2,2]  R1477     -1
    z[8,2,2]  R1478     1
    z[8,2,2]  R1487     4.2972904443740845e-01
    z[8,2,2]  R1488     2.9859790205955505e-01
    z[8,2,2]  R1489     -1.4298494160175323e-01
    z[8,2,2]  R1490     1.9827237725257874e-01
    z[8,2,2]  R1491     2.4667717516422272e-01
    z[8,2,2]  R1492     6.6764909029006958e-01
    z[8,2,2]  R1493     0.749691903591156
    z[8,2,2]  R1494     0.794209361076355
    z[8,2,2]  R1495     7.4640804529190063e-01
    z[8,2,2]  R1496     -5.7840985059738159e-01
    z[8,2,2]  R1497     -4.9356621503829956e-01
    z[8,2,2]  R1498     -5.4023534059524536e-01
    z[8,2,2]  R1499     -6.4635413885116577e-01
    z[8,2,2]  R1500     -9.2058137059211731e-02
    z[8,2,2]  R1501     -7.9390835762023926e-01
    z[8,2,2]  R1502     -4.5745104551315308e-01
    z[8,2,2]  R1503     -3.7056869268417358e-01
    z[8,2,2]  R1504     -4.0922570228576660e-01
    z[8,2,2]  R1505     -4.8002764582633972e-01
    z[8,2,2]  R1506     -6.8645268678665161e-01
    z[8,2,2]  R1507     4.0704756975173950e-01
    z[8,2,2]  R1508     -3.5753306746482849e-01
    z[8,2,2]  R1509     -3.2452747225761414e-01
    z[8,2,2]  R1510     -1.6314937174320221e-01
    z[8,2,2]  R1511     1.8298590555787086e-02
    z[8,2,2]  R1512     -2.8553183656185865e-03
    z[8,2,2]  R1513     -4.5324909687042236e-01
    z[8,2,2]  R1514     7.4352012015879154e-03
    z[8,2,2]  R1515     1.7782163619995117e-01
    z[8,2,2]  R1516     9.8059467971324921e-02
    z[8,2,2]  R1517     3.7972810864448547e-01
    z[8,2,2]  R1518     -6.2939512729644775e-01
    z[8,2,2]  R1519     -0.642380952835083
    z[8,2,2]  R1520     -6.9627188146114349e-02
    z[8,2,2]  R1521     -1.6084440052509308e-01
    z[8,2,2]  R1522     -5.4775995016098022e-01
    z[8,2,2]  R1523     -4.4738808274269104e-01
    z[8,2,2]  R1524     -5.5230081081390381e-01
    z[8,2,2]  R1525     4.3478560447692871e-01
    z[8,2,2]  R1526     -5.3456395864486694e-01
    z[8,2,2]  R1527     4.4696268439292908e-01
    z[8,2,2]  R1528     -2.2541087865829468e-01
    z[8,2,2]  R1529     -4.3915849924087524e-01
    z[8,2,2]  R1530     -6.5261960029602051e-01
    z[8,2,2]  R1531     -1.2304015457630157e-01
    z[8,2,2]  R1532     -6.2947779893875122e-01
    z[8,2,2]  R1533     -3.2969605177640915e-02
    z[8,2,2]  R1534     -3.2634842395782471e-01
    z[8,2,2]  R1535     2.6758614182472229e-01
    z[8,2,2]  R1536     4.3983215093612671e-01
    z[8,2,2]  R1537     -9.5280326902866364e-02
    z[8,2,2]  R1538     -0.634859025478363
    z[8,2,2]  R1539     -6.4517909288406372e-01
    z[8,2,2]  R1540     0.0360434390604496
    z[8,2,2]  R1541     4.5218861103057861e-01
    z[8,2,2]  R1542     -1.2078131549060345e-02
    z[8,2,2]  R1543     1.2855865061283112e-01
    z[8,2,2]  R1544     5.5934345722198486e-01
    z[8,2,2]  R1545     -2.0315490663051605e-01
    z[8,2,2]  R1546     -1.4706824719905853e-01
    z[8,2,2]  R1547     1.7670039832592010e-01
    z[8,2,2]  R1548     -4.8426979780197144e-01
    z[8,2,2]  R1549     -2.8648141026496887e-01
    z[8,2,2]  R1550     -6.8398404121398926e-01
    z[8,2,2]  R1551     -5.9787672013044357e-02
    z[8,2,2]  R1552     -1.4526379108428955e-01
    z[8,2,2]  R1553     3.9475105702877045e-02
    z[8,2,2]  R1554     2.5788527727127075e-01
    z[8,2,2]  R1555     -4.6022129058837891e-01
    z[8,2,2]  R1556     5.2115124464035034e-01
    z[8,2,2]  R1557     -2.4724586308002472e-01
    z[8,2,2]  R1558     3.8947898149490356e-01
    z[8,2,2]  R1559     -1.5772011876106262e-01
    z[8,2,2]  R1560     -0.574109673500061
    z[8,2,2]  R1561     -4.5492088794708252e-01
    z[8,2,2]  R1562     4.2822387814521790e-01
    z[8,2,2]  R1563     -2.8702369332313538e-01
    z[8,2,2]  R1564     -0.175094336271286
    z[8,2,2]  R1565     6.2799490988254547e-02
    z[8,2,2]  R1566     2.5760421156883240e-01
    z[8,2,2]  R1567     -1.7148266732692719e-01
    z[8,2,2]  R1568     8.2171314954757690e-01
    z[8,2,2]  R1569     0.659396231174469
    z[8,2,2]  R1570     2.9673033952713013e-01
    z[8,2,2]  R1571     4.8074802756309509e-01
    z[8,2,2]  R1572     8.3655959367752075e-01
    z[8,2,2]  R1573     6.2870103120803833e-01
    z[8,2,2]  R1574     4.0047213435173035e-01
    z[8,2,2]  R1575     -5.6966669857501984e-02
    z[8,2,2]  R1576     7.4343693256378174e-01
    z[8,2,2]  R1577     -4.4365558028221130e-01
    z[8,2,2]  R1578     -5.0853508710861206e-01
    z[8,2,2]  R1579     -5.2227860689163208e-01
    z[8,2,2]  R1580     -8.5057616233825684e-01
    z[8,2,2]  R1581     -5.3677064180374146e-01
    z[8,2,2]  R1582     -7.6897680759429932e-01
    z[8,2,2]  R1583     -7.4780440330505371e-01
    z[8,2,2]  R1584     -2.5453430414199829e-01
    z[8,2,2]  R1585     3.2538837194442749e-01
    z[8,2,2]  R1586     1.6030944883823395e-01
    z[8,2,2]  R1587     0.250957727432251
    z[8,2,2]  R1588     2.2730448842048645e-01
    z[8,2,2]  R1589     -2.0786218345165253e-01
    z[8,2,2]  R1590     7.3982700705528259e-02
    z[8,2,2]  R1591     -1.1089028790593147e-02
    z[8,2,2]  R1592     -2.5956982374191284e-01
    z[8,2,2]  R1593     2.1277728676795959e-01
    z[8,2,2]  R1594     4.4958975911140442e-01
    z[8,2,2]  R1595     -6.7659132182598114e-02
    z[8,2,2]  R1596     -2.0726792514324188e-01
    z[8,2,2]  R1597     -0.559663712978363
    z[8,2,2]  R1598     -5.7365173101425171e-01
    z[8,2,2]  R1599     -8.0755275487899780e-01
    z[8,2,2]  R1600     -5.2722561359405518e-01
    z[8,2,2]  R1601     -4.7982862591743469e-01
    z[8,2,2]  R1602     -0.598857045173645
    z[8,2,2]  R1603     0.886725664138794
    z[8,2,2]  R1604     -7.9085886478424072e-01
    z[8,2,2]  R1605     1.1493320018053055e-01
    z[8,2,2]  R1606     -5.6808573007583618e-01
    z[8,2,2]  R1607     -1.2841895222663879e-01
    z[8,2,2]  R1608     2.0998318493366241e-01
    z[8,2,2]  R1609     -4.9523675441741943e-01
    z[8,2,2]  R1610     -0.351829469203949
    z[8,2,2]  R1611     -5.7935726642608643e-01
    z[8,2,2]  R1612     -1.5869230031967163e-01
    z[8,2,2]  R1613     -1.7285600304603577e-01
    z[8,2,2]  R1614     3.6849480867385864e-01
    z[8,2,2]  R1615     4.0468290448188782e-01
    z[8,2,2]  R1616     3.7011903524398804e-01
    z[8,2,3]  R23       1
    z[8,2,3]  R77       -1
    z[8,2,3]  R1479     -1
    z[8,2,3]  R1480     1
    z[8,2,3]  R1487     7.0460617542266846e-01
    z[8,2,3]  R1488     6.3385230302810669e-01
    z[8,2,3]  R1489     5.1752287149429321e-01
    z[8,2,3]  R1490     0.691716730594635
    z[8,2,3]  R1491     -2.8274807333946228e-01
    z[8,2,3]  R1492     2.2858205437660217e-01
    z[8,2,3]  R1493     -9.3946717679500580e-02
    z[8,2,3]  R1494     -9.8623782396316528e-02
    z[8,2,3]  R1495     1.6305133700370789e-02
    z[8,2,3]  R1496     2.3331997916102409e-02
    z[8,2,3]  R1497     6.5564163029193878e-02
    z[8,2,3]  R1498     5.2176183462142944e-01
    z[8,2,3]  R1499     4.3301886320114136e-01
    z[8,2,3]  R1500     -7.2795635461807251e-01
    z[8,2,3]  R1501     1.0284223407506943e-01
    z[8,2,3]  R1502     5.7892650365829468e-01
    z[8,2,3]  R1503     1.1072061210870743e-01
    z[8,2,3]  R1504     4.8190414905548096e-01
    z[8,2,3]  R1505     5.4360177367925644e-02
    z[8,2,3]  R1506     -6.8826384842395782e-02
    z[8,2,3]  R1507     -8.1118786334991455e-01
    z[8,2,3]  R1508     0.0860656350851059
    z[8,2,3]  R1509     -0.528769314289093
    z[8,2,3]  R1510     -4.9167567491531372e-01
    z[8,2,3]  R1511     -6.5119296312332153e-01
    z[8,2,3]  R1512     -7.0396721363067627e-01
    z[8,2,3]  R1513     -3.1340688467025757e-01
    z[8,2,3]  R1514     -6.6030627489089966e-01
    z[8,2,3]  R1515     -4.8219156265258789e-01
    z[8,2,3]  R1516     -5.1669472455978394e-01
    z[8,2,3]  R1517     -0.783909022808075
    z[8,2,3]  R1518     6.4680272340774536e-01
    z[8,2,3]  R1519     1.1100284755229950e-02
    z[8,2,3]  R1520     -1.9375425577163696e-01
    z[8,2,3]  R1521     4.3256103992462158e-02
    z[8,2,3]  R1522     6.3257914781570435e-01
    z[8,2,3]  R1523     -4.0427660942077637e-01
    z[8,2,3]  R1524     2.4229690432548523e-01
    z[8,2,3]  R1525     3.9681177586317062e-02
    z[8,2,3]  R1526     -7.1501910686492920e-01
    z[8,2,3]  R1527     -7.5669950246810913e-01
    z[8,2,3]  R1528     4.7563002444803715e-03
    z[8,2,3]  R1529     8.6002998054027557e-02
    z[8,2,3]  R1530     -1.5803065896034241e-01
    z[8,2,3]  R1531     -5.2056068181991577e-01
    z[8,2,3]  R1532     -8.8108986616134644e-02
    z[8,2,3]  R1533     -1.6161488369107246e-02
    z[8,2,3]  R1534     -3.6090412735939026e-01
    z[8,2,3]  R1535     2.4224698543548584e-01
    z[8,2,3]  R1536     2.5279900431632996e-01
    z[8,2,3]  R1537     3.5884881019592285e-01
    z[8,2,3]  R1538     1.4230453968048096e-01
    z[8,2,3]  R1539     -1.0548471659421921e-01
    z[8,2,3]  R1540     9.3076996505260468e-02
    z[8,2,3]  R1541     1.9540201127529144e-01
    z[8,2,3]  R1542     -3.2591944932937622e-01
    z[8,2,3]  R1543     1.2794514000415802e-01
    z[8,2,3]  R1544     -3.7251997739076614e-02
    z[8,2,3]  R1545     -2.0874477922916412e-01
    z[8,2,3]  R1546     -4.8169005662202835e-02
    z[8,2,3]  R1547     -5.8753520250320435e-01
    z[8,2,3]  R1548     8.5866108536720276e-02
    z[8,2,3]  R1549     3.1356829404830933e-01
    z[8,2,3]  R1550     3.1444475054740906e-01
    z[8,2,3]  R1551     -4.0305379033088684e-01
    z[8,2,3]  R1552     1.4074213802814484e-01
    z[8,2,3]  R1553     -0.36433145403862
    z[8,2,3]  R1554     -1.5327471494674683e-01
    z[8,2,3]  R1555     6.5086834132671356e-02
    z[8,2,3]  R1556     -1.3650661706924438e-01
    z[8,2,3]  R1557     5.3470355272293091e-01
    z[8,2,3]  R1558     -1.8591515719890594e-01
    z[8,2,3]  R1559     -3.2681983709335327e-01
    z[8,2,3]  R1560     -1.1359921097755432e-01
    z[8,2,3]  R1561     1.7740766704082489e-01
    z[8,2,3]  R1562     -2.6093408465385437e-01
    z[8,2,3]  R1563     -2.4626623094081879e-01
    z[8,2,3]  R1564     1.6839888691902161e-01
    z[8,2,3]  R1565     1.1186099052429199e-01
    z[8,2,3]  R1566     2.2514252364635468e-01
    z[8,2,3]  R1567     4.5843076705932617e-01
    z[8,2,3]  R1568     -3.1058143824338913e-02
    z[8,2,3]  R1569     2.8784537315368652e-01
    z[8,2,3]  R1570     6.5112829208374023e-01
    z[8,2,3]  R1571     5.1474034786224365e-01
    z[8,2,3]  R1572     -1.1923284828662872e-01
    z[8,2,3]  R1573     4.3017926812171936e-01
    z[8,2,3]  R1574     -2.0549426972866058e-01
    z[8,2,3]  R1575     -5.2066117525100708e-02
    z[8,2,3]  R1576     5.0769889354705811e-01
    z[8,2,3]  R1577     1.1674515157938004e-01
    z[8,2,3]  R1578     3.5537999868392944e-01
    z[8,2,3]  R1579     -5.1625583320856094e-02
    z[8,2,3]  R1580     6.0137853026390076e-02
    z[8,2,3]  R1581     -0.157786563038826
    z[8,2,3]  R1582     -1.7026992142200470e-01
    z[8,2,3]  R1583     -1.0650216601788998e-02
    z[8,2,3]  R1584     6.5115690231323242e-02
    z[8,2,3]  R1585     1.1661132425069809e-01
    z[8,2,3]  R1586     -7.1028995513916016e-01
    z[8,2,3]  R1587     2.7433764189481735e-03
    z[8,2,3]  R1588     -6.7830830812454224e-01
    z[8,2,3]  R1589     2.4954505264759064e-01
    z[8,2,3]  R1590     -4.4995075464248657e-01
    z[8,2,3]  R1591     -6.2988221645355225e-01
    z[8,2,3]  R1592     -2.2799676656723022e-01
    z[8,2,3]  R1593     4.4768846035003662e-01
    z[8,2,3]  R1594     -6.1550658941268921e-01
    z[8,2,3]  R1595     -3.3372217416763306e-01
    z[8,2,3]  R1596     -4.2903545498847961e-01
    z[8,2,3]  R1597     3.1411767005920410e-01
    z[8,2,3]  R1598     1.0412068665027618e-01
    z[8,2,3]  R1599     1.8298628926277161e-01
    z[8,2,3]  R1600     5.0356507301330566e-01
    z[8,2,3]  R1601     6.1112821102142334e-01
    z[8,2,3]  R1602     2.8271466493606567e-01
    z[8,2,3]  R1603     -2.6987859606742859e-01
    z[8,2,3]  R1604     1.9051222503185272e-01
    z[8,2,3]  R1605     -2.8663340210914612e-01
    z[8,2,3]  R1606     -1.5051684342324734e-02
    z[8,2,3]  R1607     2.8195375204086304e-01
    z[8,2,3]  R1608     -3.0767318606376648e-01
    z[8,2,3]  R1609     -3.2623484730720520e-01
    z[8,2,3]  R1610     -2.9760724306106567e-01
    z[8,2,3]  R1611     4.8644068837165833e-01
    z[8,2,3]  R1612     1.4212132990360260e-01
    z[8,2,3]  R1613     -1.8289128318428993e-02
    z[8,2,3]  R1614     6.3790738582611084e-01
    z[8,2,3]  R1615     7.4694973230361938e-01
    z[8,2,3]  R1616     5.3082180023193359e-01
    z[8,2,4]  R24       1
    z[8,2,4]  R78       -1
    z[8,2,4]  R1481     -1
    z[8,2,4]  R1482     1
    z[8,2,4]  R1487     6.0182854533195496e-02
    z[8,2,4]  R1488     0.334433376789093
    z[8,2,4]  R1489     3.5058698058128357e-01
    z[8,2,4]  R1490     -1.5981499850749969e-01
    z[8,2,4]  R1491     4.5273166894912720e-01
    z[8,2,4]  R1492     7.1975603699684143e-02
    z[8,2,4]  R1493     2.0932009816169739e-01
    z[8,2,4]  R1494     4.3899127840995789e-01
    z[8,2,4]  R1495     4.7448903322219849e-01
    z[8,2,4]  R1496     1.0534477978944778e-01
    z[8,2,4]  R1497     -2.8116098046302795e-01
    z[8,2,4]  R1498     -3.7564691901206970e-01
    z[8,2,4]  R1499     -2.3733133077621460e-01
    z[8,2,4]  R1500     4.0176185965538025e-01
    z[8,2,4]  R1501     -3.4186564385890961e-02
    z[8,2,4]  R1502     -2.3181053996086121e-01
    z[8,2,4]  R1503     -1.7737166583538055e-01
    z[8,2,4]  R1504     1.1563534289598465e-01
    z[8,2,4]  R1505     -0.551505982875824
    z[8,2,4]  R1506     3.9585113525390625e-01
    z[8,2,4]  R1507     1.0906083509325981e-02
    z[8,2,4]  R1508     -3.6826786398887634e-01
    z[8,2,4]  R1509     -6.5377938747406006e-01
    z[8,2,4]  R1510     -7.1659630537033081e-01
    z[8,2,4]  R1511     -5.6170392036437988e-01
    z[8,2,4]  R1512     -6.2472081184387207e-01
    z[8,2,4]  R1513     -0.252750426530838
    z[8,2,4]  R1514     -6.1852902173995972e-01
    z[8,2,4]  R1515     -7.0063984394073486e-01
    z[8,2,4]  R1516     -6.9972926378250122e-01
    z[8,2,4]  R1517     2.1617035567760468e-01
    z[8,2,4]  R1518     -1.0089616477489471e-01
    z[8,2,4]  R1519     3.2417541742324829e-01
    z[8,2,4]  R1520     -2.3014199733734131e-01
    z[8,2,4]  R1521     -3.6255308985710144e-01
    z[8,2,4]  R1522     1.5050463378429413e-01
    z[8,2,4]  R1523     2.3566101491451263e-01
    z[8,2,4]  R1524     2.0459690690040588e-01
    z[8,2,4]  R1525     -4.9369612336158752e-01
    z[8,2,4]  R1526     1.3406861573457718e-02
    z[8,2,4]  R1527     7.9505115747451782e-02
    z[8,2,4]  R1528     -4.9428895115852356e-01
    z[8,2,4]  R1529     -0.0761650800704956
    z[8,2,4]  R1530     -2.6672041416168213e-01
    z[8,2,4]  R1531     3.6464941501617432e-01
    z[8,2,4]  R1532     -2.1595989167690277e-01
    z[8,2,4]  R1533     -6.0959827899932861e-01
    z[8,2,4]  R1534     3.5240563750267029e-01
    z[8,2,4]  R1535     1.9147807359695435e-01
    z[8,2,4]  R1536     -9.4949059188365936e-02
    z[8,2,4]  R1537     -4.2940896749496460e-01
    z[8,2,4]  R1538     2.9315361380577087e-01
    z[8,2,4]  R1539     -0.0841350331902504
    z[8,2,4]  R1540     1.3752470910549164e-01
    z[8,2,4]  R1541     1.0821728408336639e-01
    z[8,2,4]  R1542     -3.8458526134490967e-02
    z[8,2,4]  R1543     7.3545169830322266e-01
    z[8,2,4]  R1544     -2.6146358251571655e-01
    z[8,2,4]  R1545     2.3412831127643585e-02
    z[8,2,4]  R1546     4.8646613955497742e-02
    z[8,2,4]  R1547     1.9688895344734192e-01
    z[8,2,4]  R1548     -2.6365187764167786e-01
    z[8,2,4]  R1549     1.6216847300529480e-01
    z[8,2,4]  R1550     1.0183297097682953e-01
    z[8,2,4]  R1551     3.6613830924034119e-01
    z[8,2,4]  R1552     2.5276171043515205e-02
    z[8,2,4]  R1553     3.9034810662269592e-01
    z[8,2,4]  R1554     -5.8465617895126343e-01
    z[8,2,4]  R1555     -5.4090458154678345e-01
    z[8,2,4]  R1556     -2.1702301502227783e-01
    z[8,2,4]  R1557     -2.1139633655548096e-01
    z[8,2,4]  R1558     -5.1421147584915161e-01
    z[8,2,4]  R1559     3.8064935803413391e-01
    z[8,2,4]  R1560     2.8179755806922913e-01
    z[8,2,4]  R1561     1.6003543511033058e-02
    z[8,2,4]  R1562     -2.0782912150025368e-02
    z[8,2,4]  R1563     2.2558422386646271e-01
    z[8,2,4]  R1564     -1.8514131009578705e-01
    z[8,2,4]  R1565     2.2753329575061798e-01
    z[8,2,4]  R1566     5.2067141979932785e-02
    z[8,2,4]  R1567     -7.8915923833847046e-02
    z[8,2,4]  R1568     0.428545743227005
    z[8,2,4]  R1569     4.0092658251523972e-02
    z[8,2,4]  R1570     2.3380656540393829e-01
    z[8,2,4]  R1571     6.9126054644584656e-02
    z[8,2,4]  R1572     1.3722635805606842e-02
    z[8,2,4]  R1573     -4.2954348027706146e-02
    z[8,2,4]  R1574     6.9148249924182892e-02
    z[8,2,4]  R1575     7.5694270431995392e-02
    z[8,2,4]  R1576     1.7689904570579529e-01
    z[8,2,4]  R1577     -2.0937469601631165e-01
    z[8,2,4]  R1578     1.7088751494884491e-01
    z[8,2,4]  R1579     2.6169770956039429e-01
    z[8,2,4]  R1580     1.4486806094646454e-01
    z[8,2,4]  R1581     -2.8544503450393677e-01
    z[8,2,4]  R1582     -1.3903099298477173e-01
    z[8,2,4]  R1583     -3.1329038739204407e-01
    z[8,2,4]  R1584     5.2991223335266113e-01
    z[8,2,4]  R1585     -1.5408030152320862e-01
    z[8,2,4]  R1586     -3.4385478496551514e-01
    z[8,2,4]  R1587     0.374213308095932
    z[8,2,4]  R1588     4.6642562747001648e-01
    z[8,2,4]  R1589     -6.1091583967208862e-01
    z[8,2,4]  R1590     -6.4970010519027710e-01
    z[8,2,4]  R1591     -7.3790538311004639e-01
    z[8,2,4]  R1592     -7.9327005147933960e-01
    z[8,2,4]  R1593     5.8784413337707520e-01
    z[8,2,4]  R1594     -5.4279690980911255e-01
    z[8,2,4]  R1595     -1.8567000329494476e-01
    z[8,2,4]  R1596     0.0546242892742157
    z[8,2,4]  R1597     2.1512266248464584e-02
    z[8,2,4]  R1598     -5.9000805020332336e-02
    z[8,2,4]  R1599     -9.3802623450756073e-02
    z[8,2,4]  R1600     -5.2126395702362061e-01
    z[8,2,4]  R1601     -5.5842298269271851e-01
    z[8,2,4]  R1602     3.6576637625694275e-01
    z[8,2,4]  R1603     -5.5177640169858932e-02
    z[8,2,4]  R1604     -1.4764183759689331e-01
    z[8,2,4]  R1605     1.4394259080290794e-02
    z[8,2,4]  R1606     -6.8140465021133423e-01
    z[8,2,4]  R1607     -4.2736735939979553e-01
    z[8,2,4]  R1608     7.8438544273376465e-01
    z[8,2,4]  R1609     -3.9450488984584808e-02
    z[8,2,4]  R1610     -2.9868612065911293e-02
    z[8,2,4]  R1611     -1.2888021767139435e-01
    z[8,2,4]  R1612     1.3152818381786346e-01
    z[8,2,4]  R1613     2.6210722327232361e-01
    z[8,2,4]  R1614     5.1603776216506958e-01
    z[8,2,4]  R1615     3.6167123913764954e-01
    z[8,2,4]  R1616     5.5798208713531494e-01
    z[8,2,5]  R25       1
    z[8,2,5]  R79       -1
    z[8,2,5]  R1483     -1
    z[8,2,5]  R1484     1
    z[8,2,5]  R1487     -4.0111333131790161e-02
    z[8,2,5]  R1488     -2.9458436369895935e-01
    z[8,2,5]  R1489     -1.7900609970092773e-01
    z[8,2,5]  R1490     -2.3825907707214355e-01
    z[8,2,5]  R1491     1.9674451649188995e-01
    z[8,2,5]  R1492     -1.5321678481996059e-02
    z[8,2,5]  R1493     1.6504010185599327e-02
    z[8,2,5]  R1494     -5.1086336374282837e-02
    z[8,2,5]  R1495     -2.1501930430531502e-02
    z[8,2,5]  R1496     -2.1900095045566559e-01
    z[8,2,5]  R1497     -3.8801664113998413e-01
    z[8,2,5]  R1498     2.5432538986206055e-01
    z[8,2,5]  R1499     7.7942825853824615e-02
    z[8,2,5]  R1500     4.9140501767396927e-02
    z[8,2,5]  R1501     7.6111115515232086e-02
    z[8,2,5]  R1502     2.5701296329498291e-01
    z[8,2,5]  R1503     -8.5745364427566528e-02
    z[8,2,5]  R1504     -1.9198076426982880e-01
    z[8,2,5]  R1505     -9.8238639533519745e-02
    z[8,2,5]  R1506     -1.8779900670051575e-01
    z[8,2,5]  R1507     9.1455176472663879e-02
    z[8,2,5]  R1508     5.8820914477109909e-02
    z[8,2,5]  R1509     3.6578190326690674e-01
    z[8,2,5]  R1510     3.0248314142227173e-01
    z[8,2,5]  R1511     3.5836723446846008e-01
    z[8,2,5]  R1512     2.0174258947372437e-01
    z[8,2,5]  R1513     2.4466985464096069e-01
    z[8,2,5]  R1514     1.2938182055950165e-01
    z[8,2,5]  R1515     0.203104168176651
    z[8,2,5]  R1516     1.5726454555988312e-01
    z[8,2,5]  R1517     2.4988044798374176e-01
    z[8,2,5]  R1518     -1.2344833463430405e-01
    z[8,2,5]  R1519     1.9207081198692322e-01
    z[8,2,5]  R1520     1.0046100616455078e-01
    z[8,2,5]  R1521     -9.2327609658241272e-02
    z[8,2,5]  R1522     -1.4799048006534576e-01
    z[8,2,5]  R1523     4.6228629350662231e-01
    z[8,2,5]  R1524     -4.0209221839904785e-01
    z[8,2,5]  R1525     2.8853037953376770e-01
    z[8,2,5]  R1526     3.7438431382179260e-01
    z[8,2,5]  R1527     3.8681104779243469e-01
    z[8,2,5]  R1528     -3.5120215266942978e-02
    z[8,2,5]  R1529     1.3741073012351990e-01
    z[8,2,5]  R1530     2.6251502335071564e-02
    z[8,2,5]  R1531     -3.3485063910484314e-01
    z[8,2,5]  R1532     5.3847837448120117e-01
    z[8,2,5]  R1533     6.3186037540435791e-01
    z[8,2,5]  R1534     3.7381444126367569e-02
    z[8,2,5]  R1535     9.3511477112770081e-02
    z[8,2,5]  R1536     0.371217280626297
    z[8,2,5]  R1537     3.6413182970136404e-03
    z[8,2,5]  R1538     -2.0216912031173706e-01
    z[8,2,5]  R1539     1.0431414842605591e-01
    z[8,2,5]  R1540     1.1590618640184402e-02
    z[8,2,5]  R1541     -7.2658024728298187e-02
    z[8,2,5]  R1542     -6.2452876567840576e-01
    z[8,2,5]  R1543     3.4534335136413574e-01
    z[8,2,5]  R1544     -1.0845420509576797e-01
    z[8,2,5]  R1545     -6.4834314584732056e-01
    z[8,2,5]  R1546     -4.9363338947296143e-01
    z[8,2,5]  R1547     0.472953200340271
    z[8,2,5]  R1548     7.3955051600933075e-02
    z[8,2,5]  R1549     5.4328376054763794e-01
    z[8,2,5]  R1550     3.9821276068687439e-01
    z[8,2,5]  R1551     -1.3570861518383026e-01
    z[8,2,5]  R1552     -2.8387421369552612e-01
    z[8,2,5]  R1553     1.7517729103565216e-01
    z[8,2,5]  R1554     5.7705128192901611e-01
    z[8,2,5]  R1555     4.4803205132484436e-01
    z[8,2,5]  R1556     -4.0736470371484756e-02
    z[8,2,5]  R1557     -3.5944998264312744e-02
    z[8,2,5]  R1558     6.0712260007858276e-01
    z[8,2,5]  R1559     2.9833678156137466e-02
    z[8,2,5]  R1560     -2.2303852438926697e-01
    z[8,2,5]  R1561     -4.6621689200401306e-01
    z[8,2,5]  R1562     7.1863436698913574e-01
    z[8,2,5]  R1563     -3.0003547668457031e-01
    z[8,2,5]  R1564     -4.7163897752761841e-01
    z[8,2,5]  R1565     1.7729481682181358e-02
    z[8,2,5]  R1566     -9.3078408390283585e-03
    z[8,2,5]  R1567     -7.5600284337997437e-01
    z[8,2,5]  R1568     2.0925825461745262e-02
    z[8,2,5]  R1569     -1.7519956827163696e-01
    z[8,2,5]  R1570     -8.5107326507568359e-02
    z[8,2,5]  R1571     -0.129975363612175
    z[8,2,5]  R1572     -1.1450179852545261e-02
    z[8,2,5]  R1573     -1.1037198454141617e-01
    z[8,2,5]  R1574     -2.7068577706813812e-02
    z[8,2,5]  R1575     -7.5989085435867310e-01
    z[8,2,5]  R1576     -3.5837404429912567e-02
    z[8,2,5]  R1577     3.9327001571655273e-01
    z[8,2,5]  R1578     4.1641193628311157e-01
    z[8,2,5]  R1579     2.6392295956611633e-01
    z[8,2,5]  R1580     3.1351518630981445e-01
    z[8,2,5]  R1581     2.3337078094482422e-01
    z[8,2,5]  R1582     1.4271828532218933e-01
    z[8,2,5]  R1583     2.5921770930290222e-01
    z[8,2,5]  R1584     7.6674565672874451e-02
    z[8,2,5]  R1585     6.4962792396545410e-01
    z[8,2,5]  R1586     1.5710996091365814e-01
    z[8,2,5]  R1587     5.7025891542434692e-01
    z[8,2,5]  R1588     3.2565575838088989e-01
    z[8,2,5]  R1589     -1.7744678258895874e-01
    z[8,2,5]  R1590     4.8563620448112488e-01
    z[8,2,5]  R1591     4.1208315640687943e-02
    z[8,2,5]  R1592     4.6365055441856384e-01
    z[8,2,5]  R1593     0.0964667871594429
    z[8,2,5]  R1594     2.7510568499565125e-01
    z[8,2,5]  R1595     1.1066298931837082e-01
    z[8,2,5]  R1596     -1.0694700479507446e-01
    z[8,2,5]  R1597     -3.7286561727523804e-01
    z[8,2,5]  R1598     -6.1039716005325317e-01
    z[8,2,5]  R1599     1.7148524522781372e-01
    z[8,2,5]  R1600     -8.9085720479488373e-02
    z[8,2,5]  R1601     6.5611422061920166e-02
    z[8,2,5]  R1602     -4.1812869906425476e-01
    z[8,2,5]  R1603     0.286979079246521
    z[8,2,5]  R1604     -1.7271885275840759e-01
    z[8,2,5]  R1605     8.1810927391052246e-01
    z[8,2,5]  R1606     -3.4268322587013245e-01
    z[8,2,5]  R1607     -2.9487481713294983e-01
    z[8,2,5]  R1608     3.1709179282188416e-01
    z[8,2,5]  R1609     -6.1188173294067383e-01
    z[8,2,5]  R1610     -1.8844248354434967e-01
    z[8,2,5]  R1611     -2.4835785850882530e-02
    z[8,2,5]  R1612     1.9847498834133148e-01
    z[8,2,5]  R1613     -4.3695300817489624e-01
    z[8,2,5]  R1614     -3.2630094885826111e-01
    z[8,2,5]  R1615     -1.2975083291530609e-01
    z[8,2,5]  R1616     -2.3591253161430359e-01
    z[8,2,6]  R26       1
    z[8,2,6]  R80       -1
    z[8,2,6]  R1485     -1
    z[8,2,6]  R1486     1
    z[8,2,6]  R1487     -1.7198163270950317e-01
    z[8,2,6]  R1488     9.7616732120513916e-02
    z[8,2,6]  R1489     8.6575500667095184e-02
    z[8,2,6]  R1490     2.6357337832450867e-01
    z[8,2,6]  R1491     9.2977419495582581e-02
    z[8,2,6]  R1492     1.7765671014785767e-01
    z[8,2,6]  R1493     0.538210928440094
    z[8,2,6]  R1494     -9.9790245294570923e-02
    z[8,2,6]  R1495     0.267120897769928
    z[8,2,6]  R1496     -7.2021287679672241e-01
    z[8,2,6]  R1497     1.5352459251880646e-01
    z[8,2,6]  R1498     0.329188734292984
    z[8,2,6]  R1499     2.3916792869567871e-01
    z[8,2,6]  R1500     -1.8713575601577759e-01
    z[8,2,6]  R1501     4.9038669466972351e-01
    z[8,2,6]  R1502     -2.7009156346321106e-01
    z[8,2,6]  R1503     5.6678575277328491e-01
    z[8,2,6]  R1504     3.7452098727226257e-01
    z[8,2,6]  R1505     1.6239304840564728e-01
    z[8,2,6]  R1506     3.7542721629142761e-01
    z[8,2,6]  R1507     -5.5112581700086594e-02
    z[8,2,6]  R1508     -4.4175809621810913e-01
    z[8,2,6]  R1509     2.0904199779033661e-01
    z[8,2,6]  R1510     -3.4600594639778137e-01
    z[8,2,6]  R1511     1.0638792812824249e-01
    z[8,2,6]  R1512     5.7504154741764069e-02
    z[8,2,6]  R1513     7.3766849935054779e-02
    z[8,2,6]  R1514     3.7288421392440796e-01
    z[8,2,6]  R1515     -3.0995625257492065e-01
    z[8,2,6]  R1516     -2.8730648756027222e-01
    z[8,2,6]  R1517     -3.0975034832954407e-01
    z[8,2,6]  R1518     2.0896416902542114e-01
    z[8,2,6]  R1519     1.2505804002285004e-01
    z[8,2,6]  R1520     -5.4767656326293945e-01
    z[8,2,6]  R1521     -5.5913275480270386e-01
    z[8,2,6]  R1522     -2.9187005758285522e-01
    z[8,2,6]  R1523     5.7579171657562256e-01
    z[8,2,6]  R1524     -4.8718109726905823e-01
    z[8,2,6]  R1525     -5.5757766962051392e-01
    z[8,2,6]  R1526     1.5979956090450287e-01
    z[8,2,6]  R1527     1.1773577332496643e-01
    z[8,2,6]  R1528     -1.1788261681795120e-01
    z[8,2,6]  R1529     3.7980252504348755e-01
    z[8,2,6]  R1530     -1.0959913581609726e-01
    z[8,2,6]  R1531     -1.5310059487819672e-01
    z[8,2,6]  R1532     -7.4085518717765808e-02
    z[8,2,6]  R1533     -1.8072827160358429e-01
    z[8,2,6]  R1534     -4.6383801102638245e-01
    z[8,2,6]  R1535     1.4695416390895844e-01
    z[8,2,6]  R1536     2.5241279974579811e-02
    z[8,2,6]  R1537     -2.5018927454948425e-01
    z[8,2,6]  R1538     -3.3541226387023926e-01
    z[8,2,6]  R1539     3.1361293792724609e-01
    z[8,2,6]  R1540     2.8857663273811340e-01
    z[8,2,6]  R1541     -2.0775970816612244e-01
    z[8,2,6]  R1542     4.2690834403038025e-01
    z[8,2,6]  R1543     -2.1375331282615662e-01
    z[8,2,6]  R1544     1.6016711294651031e-01
    z[8,2,6]  R1545     8.2306535914540291e-03
    z[8,2,6]  R1546     1.4425319433212280e-01
    z[8,2,6]  R1547     5.8335000276565552e-01
    z[8,2,6]  R1548     -2.3129422962665558e-01
    z[8,2,6]  R1549     1.6793212294578552e-01
    z[8,2,6]  R1550     -3.8830515742301941e-01
    z[8,2,6]  R1551     -3.7465396523475647e-01
    z[8,2,6]  R1552     5.2417159080505371e-02
    z[8,2,6]  R1553     -0.200520858168602
    z[8,2,6]  R1554     2.5251591205596924e-01
    z[8,2,6]  R1555     -0.011157201603055
    z[8,2,6]  R1556     4.9335334450006485e-02
    z[8,2,6]  R1557     -4.9009706825017929e-02
    z[8,2,6]  R1558     1.0897734016180038e-01
    z[8,2,6]  R1559     -2.9252591729164124e-01
    z[8,2,6]  R1560     9.0420506894588470e-02
    z[8,2,6]  R1561     -2.0941365510225296e-02
    z[8,2,6]  R1562     -4.7655689716339111e-01
    z[8,2,6]  R1563     -3.7927865982055664e-01
    z[8,2,6]  R1564     0.0328315831720829
    z[8,2,6]  R1565     -1.6944380104541779e-01
    z[8,2,6]  R1566     -7.0934578776359558e-02
    z[8,2,6]  R1567     1.6713712364435196e-02
    z[8,2,6]  R1568     1.3852766156196594e-01
    z[8,2,6]  R1569     -2.6451028883457184e-02
    z[8,2,6]  R1570     6.5301500260829926e-02
    z[8,2,6]  R1571     -2.0380245149135590e-01
    z[8,2,6]  R1572     1.8621627986431122e-01
    z[8,2,6]  R1573     3.7159714102745056e-01
    z[8,2,6]  R1574     5.8207410573959351e-01
    z[8,2,6]  R1575     -9.7229331731796265e-02
    z[8,2,6]  R1576     9.8299160599708557e-02
    z[8,2,6]  R1577     -8.5928887128829956e-02
    z[8,2,6]  R1578     -5.0952263176441193e-02
    z[8,2,6]  R1579     0.290477991104126
    z[8,2,6]  R1580     9.4562888145446777e-02
    z[8,2,6]  R1581     4.1986885666847229e-01
    z[8,2,6]  R1582     -0.355317622423172
    z[8,2,6]  R1583     3.1535494327545166e-01
    z[8,2,6]  R1584     -2.3087418079376221e-01
    z[8,2,6]  R1585     -5.2109336853027344e-01
    z[8,2,6]  R1586     -5.1472866535186768e-01
    z[8,2,6]  R1587     6.4978986978530884e-01
    z[8,2,6]  R1588     1.3804058730602264e-01
    z[8,2,6]  R1589     2.4975056946277618e-01
    z[8,2,6]  R1590     1.1272017657756805e-01
    z[8,2,6]  R1591     -2.0698155462741852e-01
    z[8,2,6]  R1592     -7.2273783385753632e-02
    z[8,2,6]  R1593     4.9550160765647888e-02
    z[8,2,6]  R1594     1.1164902895689011e-01
    z[8,2,6]  R1595     -2.0635692775249481e-01
    z[8,2,6]  R1596     2.0182704925537109e-01
    z[8,2,6]  R1597     -4.6101385354995728e-01
    z[8,2,6]  R1598     2.6499542593955994e-01
    z[8,2,6]  R1599     -1.4004588127136230e-01
    z[8,2,6]  R1600     -4.1854989528656006e-01
    z[8,2,6]  R1601     1.0906316339969635e-01
    z[8,2,6]  R1602     4.3054428696632385e-01
    z[8,2,6]  R1603     0.090914286673069
    z[8,2,6]  R1604     -0.0802655816078186
    z[8,2,6]  R1605     -4.3816640973091125e-01
    z[8,2,6]  R1606     2.2761696577072144e-01
    z[8,2,6]  R1607     6.0557309538125992e-02
    z[8,2,6]  R1608     -8.9875146746635437e-02
    z[8,2,6]  R1609     6.1374053359031677e-02
    z[8,2,6]  R1610     1.6884168609976768e-02
    z[8,2,6]  R1611     4.2412549257278442e-01
    z[8,2,6]  R1612     5.1192098855972290e-01
    z[8,2,6]  R1613     -3.0343142151832581e-01
    z[8,2,6]  R1614     2.0778505504131317e-01
    z[8,2,6]  R1615     -1.2761445343494415e-01
    z[8,2,6]  R1616     -0.400240957736969
    z[3,4,0]  R29       -1
    z[3,4,0]  R38       1
    z[3,4,0]  R1617     -1
    z[3,4,0]  R1618     1
    z[3,4,0]  R1631     3.8435712456703186e-01
    z[3,4,0]  R1632     4.6964627504348755e-01
    z[3,4,0]  R1633     1.2871317565441132e-01
    z[3,4,0]  R1634     3.3063021302223206e-01
    z[3,4,0]  R1635     -1.5768514573574066e-01
    z[3,4,0]  R1636     -6.0754650831222534e-01
    z[3,4,0]  R1637     -4.4395166635513306e-01
    z[3,4,0]  R1638     -1.7489361763000488e-01
    z[3,4,0]  R1639     -6.6080474853515625e-01
    z[3,4,0]  R1640     -6.0426956415176392e-01
    z[3,4,0]  R1641     -3.8641926646232605e-01
    z[3,4,0]  R1642     -2.2747081518173218e-01
    z[3,4,0]  R1643     -1.8546903133392334e-01
    z[3,4,0]  R1644     -2.2525892127305269e-03
    z[3,4,0]  R1645     -3.2109636068344116e-01
    z[3,4,0]  R1646     -2.2801786661148071e-02
    z[3,4,0]  R1647     -5.9258061647415161e-01
    z[3,4,0]  R1648     -3.0523759126663208e-01
    z[3,4,0]  R1649     -4.9144953489303589e-01
    z[3,4,0]  R1650     3.5981366038322449e-01
    z[3,4,0]  R1651     4.6973848342895508e-01
    z[3,4,0]  R1652     3.7984788417816162e-01
    z[3,4,0]  R1653     3.2363331317901611e-01
    z[3,4,0]  R1654     -1.0073760896921158e-01
    z[3,4,0]  R1655     -5.3915452957153320e-01
    z[3,4,0]  R1656     0.573432981967926
    z[3,4,0]  R1657     5.8630925416946411e-01
    z[3,4,0]  R1658     6.3679113984107971e-02
    z[3,4,0]  R1659     1.5071780420839787e-02
    z[3,4,0]  R1660     1.0220363736152649e-01
    z[3,4,0]  R1661     7.9044562578201294e-01
    z[3,4,0]  R1662     -8.5493430495262146e-02
    z[3,4,0]  R1663     -2.8234678506851196e-01
    z[3,4,0]  R1664     -1.1949960142374039e-01
    z[3,4,0]  R1665     -4.2563432455062866e-01
    z[3,4,0]  R1666     -3.5032281279563904e-01
    z[3,4,0]  R1667     -2.7937644720077515e-01
    z[3,4,0]  R1668     -3.0842721462249756e-01
    z[3,4,0]  R1669     -6.1874139308929443e-01
    z[3,4,0]  R1670     -4.4269609451293945e-01
    z[3,4,0]  R1671     1.0344447195529938e-01
    z[3,4,0]  R1672     -9.6073616296052933e-03
    z[3,4,0]  R1673     -3.5229781270027161e-01
    z[3,4,0]  R1674     2.1113598719239235e-02
    z[3,4,0]  R1675     -1.6194912791252136e-01
    z[3,4,0]  R1676     1.4746780693531036e-01
    z[3,4,0]  R1677     -3.9892011880874634e-01
    z[3,4,0]  R1678     -2.4754211306571960e-01
    z[3,4,0]  R1679     -5.6692034006118774e-01
    z[3,4,0]  R1680     -6.1223447322845459e-01
    z[3,4,0]  R1681     -8.9415594935417175e-02
    z[3,4,0]  R1682     5.4197525978088379e-01
    z[3,4,0]  R1683     -3.4987998008728027e-01
    z[3,4,0]  R1684     -5.3841060400009155e-01
    z[3,4,0]  R1685     1.6175134107470512e-02
    z[3,4,0]  R1686     1.9008865579962730e-02
    z[3,4,0]  R1687     -1.1379750072956085e-01
    z[3,4,0]  R1688     8.3032414317131042e-02
    z[3,4,0]  R1689     -6.1901800334453583e-02
    z[3,4,0]  R1690     2.9676225781440735e-01
    z[3,4,0]  R1691     -3.2573610544204712e-01
    z[3,4,0]  R1692     -2.5934723019599915e-01
    z[3,4,0]  R1693     8.8120587170124054e-02
    z[3,4,0]  R1694     9.8550565540790558e-02
    z[3,4,0]  R1695     6.9516366720199585e-01
    z[3,4,0]  R1696     3.5381710529327393e-01
    z[3,4,0]  R1697     5.3135710954666138e-01
    z[3,4,0]  R1698     5.0062006711959839e-01
    z[3,4,0]  R1699     -0.0803113803267479
    z[3,4,0]  R1700     -4.1130515933036804e-01
    z[3,4,0]  R1701     -0.427592396736145
    z[3,4,0]  R1702     2.0544408261775970e-01
    z[3,4,0]  R1703     0.0890294685959816
    z[3,4,0]  R1704     -6.0372769832611084e-02
    z[3,4,0]  R1705     -3.5978186130523682e-01
    z[3,4,0]  R1706     -2.9932841658592224e-01
    z[3,4,0]  R1707     -1.1968418210744858e-01
    z[3,4,0]  R1708     -1.6735707223415375e-01
    z[3,4,0]  R1709     -7.3670989274978638e-01
    z[3,4,0]  R1710     -7.2185647487640381e-01
    z[3,4,0]  R1711     5.0655186176300049e-01
    z[3,4,0]  R1712     -3.5451275110244751e-01
    z[3,4,0]  R1713     7.0910400152206421e-01
    z[3,4,0]  R1714     -3.2608368992805481e-01
    z[3,4,0]  R1715     -4.0962222218513489e-01
    z[3,4,0]  R1716     -5.7422578334808350e-01
    z[3,4,0]  R1717     4.8209443688392639e-01
    z[3,4,0]  R1718     -2.2729055583477020e-01
    z[3,4,0]  R1719     -5.2984601259231567e-01
    z[3,4,0]  R1720     -8.7798461318016052e-02
    z[3,4,0]  R1721     -2.1332009136676788e-01
    z[3,4,0]  R1722     1.4889524877071381e-01
    z[3,4,0]  R1723     6.1367547512054443e-01
    z[3,4,0]  R1724     3.5424154996871948e-01
    z[3,4,0]  R1725     7.5880038738250732e-01
    z[3,4,0]  R1726     -1.2219431251287460e-01
    z[3,4,0]  R1727     -1.5539045631885529e-01
    z[3,4,0]  R1728     -4.0151676535606384e-01
    z[3,4,0]  R1729     -4.3038254976272583e-01
    z[3,4,0]  R1730     -5.8152490854263306e-01
    z[3,4,0]  R1731     4.6116787195205688e-01
    z[3,4,0]  R1732     7.4232870340347290e-01
    z[3,4,0]  R1733     -2.1970137953758240e-01
    z[3,4,0]  R1734     -2.8013315796852112e-01
    z[3,4,0]  R1735     -2.9905471205711365e-01
    z[3,4,0]  R1736     -5.3870719671249390e-01
    z[3,4,0]  R1737     -2.1344721317291260e-01
    z[3,4,0]  R1738     -6.4537745714187622e-01
    z[3,4,0]  R1739     -6.8506032228469849e-01
    z[3,4,0]  R1740     -1.5146845579147339e-01
    z[3,4,1]  R30       -1
    z[3,4,1]  R39       1
    z[3,4,1]  R1619     -1
    z[3,4,1]  R1620     1
    z[3,4,1]  R1631     -3.8943392038345337e-01
    z[3,4,1]  R1632     1.0056421905755997e-01
    z[3,4,1]  R1633     1.5411810576915741e-01
    z[3,4,1]  R1634     -7.9090172052383423e-01
    z[3,4,1]  R1635     -0.0875360444188118
    z[3,4,1]  R1636     -6.2563389539718628e-01
    z[3,4,1]  R1637     -0.704354465007782
    z[3,4,1]  R1638     -7.9132989048957825e-02
    z[3,4,1]  R1639     -6.2296229600906372e-01
    z[3,4,1]  R1640     -6.6563093662261963e-01
    z[3,4,1]  R1641     -4.1182957589626312e-02
    z[3,4,1]  R1642     -3.4564676880836487e-01
    z[3,4,1]  R1643     2.8088864684104919e-01
    z[3,4,1]  R1644     3.0188298225402832e-01
    z[3,4,1]  R1645     6.1274491250514984e-02
    z[3,4,1]  R1646     0.0978856310248375
    z[3,4,1]  R1647     2.0466198027133942e-01
    z[3,4,1]  R1648     6.6788643598556519e-03
    z[3,4,1]  R1649     1.1274852603673935e-01
    z[3,4,1]  R1650     4.3839445710182190e-01
    z[3,4,1]  R1651     3.5533255338668823e-01
    z[3,4,1]  R1652     -6.9836688041687012e-01
    z[3,4,1]  R1653     -3.9601841568946838e-01
    z[3,4,1]  R1654     1.1077233403921127e-01
    z[3,4,1]  R1655     2.0387648046016693e-01
    z[3,4,1]  R1656     -2.1392878890037537e-01
    z[3,4,1]  R1657     3.0866166949272156e-01
    z[3,4,1]  R1658     -1.5111443400382996e-01
    z[3,4,1]  R1659     2.5715095922350883e-02
    z[3,4,1]  R1660     -1.4068578183650970e-01
    z[3,4,1]  R1661     -0.302144318819046
    z[3,4,1]  R1662     3.4736540168523788e-02
    z[3,4,1]  R1663     -1.4574143290519714e-01
    z[3,4,1]  R1664     -2.2250409424304962e-01
    z[3,4,1]  R1665     -4.6310713887214661e-01
    z[3,4,1]  R1666     2.1093061566352844e-01
    z[3,4,1]  R1667     -8.5881382226943970e-01
    z[3,4,1]  R1668     -4.4231769442558289e-01
    z[3,4,1]  R1669     -0.606364369392395
    z[3,4,1]  R1670     -7.1295052766799927e-01
    z[3,4,1]  R1671     7.0980495214462280e-01
    z[3,4,1]  R1672     -4.2589294910430908e-01
    z[3,4,1]  R1673     -1.5035982429981232e-01
    z[3,4,1]  R1674     9.3660390377044678e-01
    z[3,4,1]  R1675     9.3908828496932983e-01
    z[3,4,1]  R1676     8.6301565170288086e-01
    z[3,4,1]  R1677     5.0970077514648438e-01
    z[3,4,1]  R1678     7.0335948467254639e-01
    z[3,4,1]  R1679     2.9809432104229927e-02
    z[3,4,1]  R1680     -9.8309412598609924e-02
    z[3,4,1]  R1681     6.9336611032485962e-01
    z[3,4,1]  R1682     -6.0947406291961670e-01
    z[3,4,1]  R1683     -2.0571936666965485e-01
    z[3,4,1]  R1684     -7.4226832389831543e-01
    z[3,4,1]  R1685     1.8295995891094208e-01
    z[3,4,1]  R1686     6.1455290764570236e-02
    z[3,4,1]  R1687     1.7191922664642334e-01
    z[3,4,1]  R1688     2.5506317615509033e-01
    z[3,4,1]  R1689     9.5106415450572968e-02
    z[3,4,1]  R1690     -8.0855406820774078e-02
    z[3,4,1]  R1691     8.6098372936248779e-02
    z[3,4,1]  R1692     4.0809374302625656e-02
    z[3,4,1]  R1693     1.4856897294521332e-02
    z[3,4,1]  R1694     3.5770680755376816e-02
    z[3,4,1]  R1695     2.9243474826216698e-02
    z[3,4,1]  R1696     3.3882107585668564e-02
    z[3,4,1]  R1697     4.2408645153045654e-02
    z[3,4,1]  R1698     -2.6837334036827087e-02
    z[3,4,1]  R1699     -9.8626506328582764e-01
    z[3,4,1]  R1700     -7.7075231075286865e-01
    z[3,4,1]  R1701     3.3755227923393250e-01
    z[3,4,1]  R1702     4.6453335881233215e-01
    z[3,4,1]  R1703     2.0314882695674896e-01
    z[3,4,1]  R1704     -4.5288348197937012e-01
    z[3,4,1]  R1705     -2.2510962188243866e-01
    z[3,4,1]  R1706     7.5029619038105011e-02
    z[3,4,1]  R1707     -1.1169072240591049e-01
    z[3,4,1]  R1708     -2.0647212862968445e-01
    z[3,4,1]  R1709     3.1193214654922485e-01
    z[3,4,1]  R1710     1.0958223044872284e-01
    z[3,4,1]  R1711     7.0791471004486084e-01
    z[3,4,1]  R1712     7.0677822828292847e-01
    z[3,4,1]  R1713     -9.4216220080852509e-02
    z[3,4,1]  R1714     -1.8292379379272461e-01
    z[3,4,1]  R1715     -3.1834807991981506e-01
    z[3,4,1]  R1716     -2.9790893197059631e-02
    z[3,4,1]  R1717     -6.2753939628601074e-01
    z[3,4,1]  R1718     -2.8487288951873779e-01
    z[3,4,1]  R1719     -2.7020066976547241e-01
    z[3,4,1]  R1720     -8.7465830147266388e-02
    z[3,4,1]  R1721     9.1370832920074463e-01
    z[3,4,1]  R1722     6.0478651523590088e-01
    z[3,4,1]  R1723     -5.3782677650451660e-01
    z[3,4,1]  R1724     -2.0813673734664917e-01
    z[3,4,1]  R1725     -1.4956003427505493e-01
    z[3,4,1]  R1726     -9.1522234678268433e-01
    z[3,4,1]  R1727     -3.5401773452758789e-01
    z[3,4,1]  R1728     -7.9296404123306274e-01
    z[3,4,1]  R1729     -7.6892828941345215e-01
    z[3,4,1]  R1730     -7.2409129142761230e-01
    z[3,4,1]  R1731     2.1006102859973907e-01
    z[3,4,1]  R1732     -0.37724769115448
    z[3,4,1]  R1733     -2.4791140854358673e-01
    z[3,4,1]  R1734     -8.7415516376495361e-01
    z[3,4,1]  R1735     -8.2212585210800171e-01
    z[3,4,1]  R1736     -7.7263385057449341e-01
    z[3,4,1]  R1737     -8.1514602899551392e-01
    z[3,4,1]  R1738     -6.6241323947906494e-01
    z[3,4,1]  R1739     -5.7923221588134766e-01
    z[3,4,1]  R1740     -8.5195028781890869e-01
    z[3,4,2]  R31       -1
    z[3,4,2]  R40       1
    z[3,4,2]  R1621     -1
    z[3,4,2]  R1622     1
    z[3,4,2]  R1631     -1.3613632321357727e-01
    z[3,4,2]  R1632     -3.2119369506835938e-01
    z[3,4,2]  R1633     0.11175537109375
    z[3,4,2]  R1634     3.1654998660087585e-02
    z[3,4,2]  R1635     8.4770750999450684e-01
    z[3,4,2]  R1636     -1.4828373491764069e-01
    z[3,4,2]  R1637     2.9359790682792664e-01
    z[3,4,2]  R1638     0.686779260635376
    z[3,4,2]  R1639     -3.4933474659919739e-01
    z[3,4,2]  R1640     -1.5206056833267212e-01
    z[3,4,2]  R1641     1.1364550888538361e-01
    z[3,4,2]  R1642     3.4251266717910767e-01
    z[3,4,2]  R1643     8.4152139723300934e-02
    z[3,4,2]  R1644     -7.0116829872131348e-01
    z[3,4,2]  R1645     0.310958594083786
    z[3,4,2]  R1646     -4.8581293225288391e-01
    z[3,4,2]  R1647     1.5351407229900360e-01
    z[3,4,2]  R1648     -2.2517786920070648e-01
    z[3,4,2]  R1649     2.1858850494027138e-02
    z[3,4,2]  R1650     -4.2397168278694153e-01
    z[3,4,2]  R1651     1.2479174137115479e-01
    z[3,4,2]  R1652     4.9236118793487549e-01
    z[3,4,2]  R1653     7.7350640296936035e-01
    z[3,4,2]  R1654     4.2019265890121460e-01
    z[3,4,2]  R1655     3.5428783297538757e-01
    z[3,4,2]  R1656     3.6612513661384583e-01
    z[3,4,2]  R1657     1.0885686427354813e-01
    z[3,4,2]  R1658     5.1020783185958862e-01
    z[3,4,2]  R1659     6.2840634584426880e-01
    z[3,4,2]  R1660     9.5704257488250732e-02
    z[3,4,2]  R1661     4.8155072331428528e-01
    z[3,4,2]  R1662     0.616873025894165
    z[3,4,2]  R1663     4.6412819623947144e-01
    z[3,4,2]  R1664     1.1298055946826935e-01
    z[3,4,2]  R1665     4.5124284923076630e-02
    z[3,4,2]  R1666     6.3735512085258961e-03
    z[3,4,2]  R1667     -2.0513303577899933e-01
    z[3,4,2]  R1668     -1.2549702823162079e-01
    z[3,4,2]  R1669     -1.3414016366004944e-01
    z[3,4,2]  R1670     2.1963019669055939e-01
    z[3,4,2]  R1671     -4.5000827312469482e-01
    z[3,4,2]  R1672     8.7170645594596863e-02
    z[3,4,2]  R1673     2.8488731384277344e-01
    z[3,4,2]  R1674     2.7279371395707130e-02
    z[3,4,2]  R1675     -1.3675086200237274e-01
    z[3,4,2]  R1676     3.0031827092170715e-01
    z[3,4,2]  R1677     -6.9078212976455688e-01
    z[3,4,2]  R1678     -5.2651494741439819e-01
    z[3,4,2]  R1679     2.8083970770239830e-02
    z[3,4,2]  R1680     2.4156154692173004e-01
    z[3,4,2]  R1681     -5.5537432432174683e-01
    z[3,4,2]  R1682     2.1817199885845184e-01
    z[3,4,2]  R1683     2.2642841935157776e-01
    z[3,4,2]  R1684     -1.9141036272048950e-01
    z[3,4,2]  R1685     1.1570196598768234e-01
    z[3,4,2]  R1686     -0.0828382596373558
    z[3,4,2]  R1687     2.0725773274898529e-01
    z[3,4,2]  R1688     8.0018816515803337e-03
    z[3,4,2]  R1689     -3.0644190311431885e-01
    z[3,4,2]  R1690     -1.1769544333219528e-01
    z[3,4,2]  R1691     8.7004798650741577e-01
    z[3,4,2]  R1692     -3.1570014357566833e-01
    z[3,4,2]  R1693     -3.2411649823188782e-01
    z[3,4,2]  R1694     -4.5273759961128235e-01
    z[3,4,2]  R1695     -3.1902936100959778e-01
    z[3,4,2]  R1696     -3.8057672977447510e-01
    z[3,4,2]  R1697     2.3256923258304596e-01
    z[3,4,2]  R1698     -5.2614736557006836e-01
    z[3,4,2]  R1699     3.5125121474266052e-02
    z[3,4,2]  R1700     -0.135227769613266
    z[3,4,2]  R1701     -6.6119629144668579e-01
    z[3,4,2]  R1702     2.4024224281311035e-01
    z[3,4,2]  R1703     -3.2324683666229248e-01
    z[3,4,2]  R1704     2.6352068781852722e-01
    z[3,4,2]  R1705     1.5180575847625732e-01
    z[3,4,2]  R1706     1.7123924195766449e-01
    z[3,4,2]  R1707     -3.2004401087760925e-02
    z[3,4,2]  R1708     4.7869232296943665e-01
    z[3,4,2]  R1709     3.6024913191795349e-01
    z[3,4,2]  R1710     6.1882162094116211e-01
    z[3,4,2]  R1711     -3.1423881649971008e-01
    z[3,4,2]  R1712     2.6292544603347778e-01
    z[3,4,2]  R1713     2.8887814283370972e-01
    z[3,4,2]  R1714     7.3006629943847656e-01
    z[3,4,2]  R1715     3.7077632546424866e-01
    z[3,4,2]  R1716     4.2833951115608215e-01
    z[3,4,2]  R1717     -2.1611212193965912e-01
    z[3,4,2]  R1718     7.2118914127349854e-01
    z[3,4,2]  R1719     4.2355710268020630e-01
    z[3,4,2]  R1720     3.1084164977073669e-01
    z[3,4,2]  R1721     -1.4423248171806335e-01
    z[3,4,2]  R1722     6.9796758890151978e-01
    z[3,4,2]  R1723     -4.3535566329956055e-01
    z[3,4,2]  R1724     -6.3349805772304535e-02
    z[3,4,2]  R1725     -2.9123482108116150e-01
    z[3,4,2]  R1726     -3.1179878115653992e-01
    z[3,4,2]  R1727     2.2285149991512299e-01
    z[3,4,2]  R1728     -0.224463552236557
    z[3,4,2]  R1729     -3.3415627479553223e-01
    z[3,4,2]  R1730     1.4328600466251373e-01
    z[3,4,2]  R1731     -4.3183878064155579e-01
    z[3,4,2]  R1732     -1.9323955476284027e-01
    z[3,4,2]  R1733     2.3670576512813568e-01
    z[3,4,2]  R1734     -4.6494167298078537e-02
    z[3,4,2]  R1735     -2.1576589345932007e-01
    z[3,4,2]  R1736     -1.8845294415950775e-01
    z[3,4,2]  R1737     8.5460282862186432e-02
    z[3,4,2]  R1738     9.2955529689788818e-02
    z[3,4,2]  R1739     1.5348492562770844e-01
    z[3,4,2]  R1740     3.5969346761703491e-01
    z[3,4,3]  R32       -1
    z[3,4,3]  R41       1
    z[3,4,3]  R1623     -1
    z[3,4,3]  R1624     1
    z[3,4,3]  R1631     4.5321959257125854e-01
    z[3,4,3]  R1632     4.4695851206779480e-01
    z[3,4,3]  R1633     9.3673390150070190e-01
    z[3,4,3]  R1634     1.9504196941852570e-01
    z[3,4,3]  R1635     -2.9698863625526428e-01
    z[3,4,3]  R1636     -0.0312623456120491
    z[3,4,3]  R1637     -2.2925306856632233e-01
    z[3,4,3]  R1638     -4.2882928252220154e-01
    z[3,4,3]  R1639     6.9269701838493347e-02
    z[3,4,3]  R1640     3.7578254938125610e-01
    z[3,4,3]  R1641     -8.1052398681640625e-01
    z[3,4,3]  R1642     -5.8123838901519775e-01
    z[3,4,3]  R1643     -0.560954213142395
    z[3,4,3]  R1644     1.1045350879430771e-01
    z[3,4,3]  R1645     -3.7698951363563538e-01
    z[3,4,3]  R1646     4.2962488532066345e-01
    z[3,4,3]  R1647     -4.0225467085838318e-01
    z[3,4,3]  R1648     -5.8202630281448364e-01
    z[3,4,3]  R1649     -4.1785049438476562e-01
    z[3,4,3]  R1650     -3.0952779576182365e-02
    z[3,4,3]  R1651     2.3720730841159821e-01
    z[3,4,3]  R1652     6.9490201771259308e-02
    z[3,4,3]  R1653     1.2240605801343918e-01
    z[3,4,3]  R1654     -6.0070788860321045e-01
    z[3,4,3]  R1655     -0.522066593170166
    z[3,4,3]  R1656     3.8913151621818542e-01
    z[3,4,3]  R1657     3.6415389180183411e-01
    z[3,4,3]  R1658     -1.9415524601936340e-01
    z[3,4,3]  R1659     -3.3607918024063110e-01
    z[3,4,3]  R1660     -3.9141789078712463e-01
    z[3,4,3]  R1661     -8.4982894361019135e-02
    z[3,4,3]  R1662     -5.5730760097503662e-01
    z[3,4,3]  R1663     -9.1690264642238617e-02
    z[3,4,3]  R1664     -7.2996979951858521e-01
    z[3,4,3]  R1665     -5.5128979682922363e-01
    z[3,4,3]  R1666     -0.838477373123169
    z[3,4,3]  R1667     -2.7604243159294128e-01
    z[3,4,3]  R1668     6.3116061687469482e-01
    z[3,4,3]  R1669     -4.3238624930381775e-02
    z[3,4,3]  R1670     3.6420649290084839e-01
    z[3,4,3]  R1671     -3.9759587496519089e-02
    z[3,4,3]  R1672     -2.7081990242004395e-01
    z[3,4,3]  R1673     3.9089463651180267e-02
    z[3,4,3]  R1674     -1.4939683675765991e-01
    z[3,4,3]  R1675     1.0562177002429962e-01
    z[3,4,3]  R1676     4.4475674629211426e-02
    z[3,4,3]  R1677     2.0891658961772919e-01
    z[3,4,3]  R1678     0.14479960501194
    z[3,4,3]  R1679     -2.2908157110214233e-01
    z[3,4,3]  R1680     -8.4188235923647881e-03
    z[3,4,3]  R1681     3.7611511349678040e-01
    z[3,4,3]  R1682     -2.1606069058179855e-02
    z[3,4,3]  R1683     -2.7403208613395691e-01
    z[3,4,3]  R1684     1.7212149500846863e-01
    z[3,4,3]  R1685     4.7052096575498581e-02
    z[3,4,3]  R1686     -3.6566668748855591e-01
    z[3,4,3]  R1687     -4.7412046790122986e-01
    z[3,4,3]  R1688     -4.2067438364028931e-01
    z[3,4,3]  R1689     -4.8991143703460693e-01
    z[3,4,3]  R1690     -2.5718429684638977e-01
    z[3,4,3]  R1691     -2.4330346286296844e-01
    z[3,4,3]  R1692     6.4088380336761475e-01
    z[3,4,3]  R1693     8.3118927478790283e-01
    z[3,4,3]  R1694     5.0202047824859619e-01
    z[3,4,3]  R1695     6.1825442314147949e-01
    z[3,4,3]  R1696     5.3561651706695557e-01
    z[3,4,3]  R1697     -2.1502526104450226e-01
    z[3,4,3]  R1698     3.4871095418930054e-01
    z[3,4,3]  R1699     6.1747943982481956e-03
    z[3,4,3]  R1700     -7.8910492360591888e-02
    z[3,4,3]  R1701     -4.9729026854038239e-02
    z[3,4,3]  R1702     -1.3379671610891819e-02
    z[3,4,3]  R1703     -3.6287495493888855e-01
    z[3,4,3]  R1704     -6.2828463315963745e-01
    z[3,4,3]  R1705     -7.9960060119628906e-01
    z[3,4,3]  R1706     -5.5615299940109253e-01
    z[3,4,3]  R1707     -8.0680477619171143e-01
    z[3,4,3]  R1708     -5.9920346736907959e-01
    z[3,4,3]  R1709     -4.7588801383972168e-01
    z[3,4,3]  R1710     -1.9305257499217987e-01
    z[3,4,3]  R1711     -2.4466849863529205e-01
    z[3,4,3]  R1712     -2.2717629373073578e-01
    z[3,4,3]  R1713     6.1988256871700287e-02
    z[3,4,3]  R1714     -4.9140679836273193e-01
    z[3,4,3]  R1715     -0.562491238117218
    z[3,4,3]  R1716     -6.5210080146789551e-01
    z[3,4,3]  R1717     2.4216838181018829e-01
    z[3,4,3]  R1718     -4.3520128726959229e-01
    z[3,4,3]  R1719     -5.5447423458099365e-01
    z[3,4,3]  R1720     -8.6597663164138794e-01
    z[3,4,3]  R1721     -8.7393987923860550e-03
    z[3,4,3]  R1722     -0.0466126874089241
    z[3,4,3]  R1723     1.2584270536899567e-01
    z[3,4,3]  R1724     3.3088415861129761e-01
    z[3,4,3]  R1725     -2.1796119399368763e-03
    z[3,4,3]  R1726     -2.2579845041036606e-02
    z[3,4,3]  R1727     -5.8057314157485962e-01
    z[3,4,3]  R1728     9.4112195074558258e-03
    z[3,4,3]  R1729     -1.8776719272136688e-01
    z[3,4,3]  R1730     -0.0934593677520752
    z[3,4,3]  R1731     1.7307612299919128e-01
    z[3,4,3]  R1732     8.0016024410724640e-02
    z[3,4,3]  R1733     -7.9326313734054565e-01
    z[3,4,3]  R1734     4.2148139327764511e-02
    z[3,4,3]  R1735     2.2905036807060242e-01
    z[3,4,3]  R1736     1.7671939730644226e-01
    z[3,4,3]  R1737     -5.6692283600568771e-02
    z[3,4,3]  R1738     2.2062557935714722e-01
    z[3,4,3]  R1739     2.2669243812561035e-01
    z[3,4,3]  R1740     -1.0020788758993149e-01
    z[3,4,4]  R33       -1
    z[3,4,4]  R42       1
    z[3,4,4]  R1625     -1
    z[3,4,4]  R1626     1
    z[3,4,4]  R1631     3.4688645601272583e-01
    z[3,4,4]  R1632     5.9636777639389038e-01
    z[3,4,4]  R1633     1.8472562730312347e-01
    z[3,4,4]  R1634     -5.8635283261537552e-02
    z[3,4,4]  R1635     -2.3713652789592743e-01
    z[3,4,4]  R1636     4.5625463128089905e-01
    z[3,4,4]  R1637     1.0159126482903957e-02
    z[3,4,4]  R1638     1.3070702552795410e-01
    z[3,4,4]  R1639     -1.1682728677988052e-01
    z[3,4,4]  R1640     -4.6683631837368011e-02
    z[3,4,4]  R1641     3.4998500347137451e-01
    z[3,4,4]  R1642     1.3148643076419830e-01
    z[3,4,4]  R1643     5.9449046850204468e-01
    z[3,4,4]  R1644     -4.5888105034828186e-01
    z[3,4,4]  R1645     3.9809507131576538e-01
    z[3,4,4]  R1646     -6.9887173175811768e-01
    z[3,4,4]  R1647     3.2974988222122192e-01
    z[3,4,4]  R1648     4.0062639117240906e-01
    z[3,4,4]  R1649     1.9780324399471283e-01
    z[3,4,4]  R1650     -5.7936644554138184e-01
    z[3,4,4]  R1651     -0.341208279132843
    z[3,4,4]  R1652     -2.5814184546470642e-01
    z[3,4,4]  R1653     2.8583295643329620e-03
    z[3,4,4]  R1654     5.9135907888412476e-01
    z[3,4,4]  R1655     2.5743296742439270e-01
    z[3,4,4]  R1656     -5.7720959186553955e-01
    z[3,4,4]  R1657     -5.6938838958740234e-01
    z[3,4,4]  R1658     6.3056260347366333e-01
    z[3,4,4]  R1659     0.110362209379673
    z[3,4,4]  R1660     6.8434321880340576e-01
    z[3,4,4]  R1661     -1.5113914012908936e-01
    z[3,4,4]  R1662     2.0056955516338348e-01
    z[3,4,4]  R1663     4.2378431558609009e-01
    z[3,4,4]  R1664     5.9284854680299759e-02
    z[3,4,4]  R1665     2.3376183211803436e-01
    z[3,4,4]  R1666     1.8640869855880737e-01
    z[3,4,4]  R1667     5.0026741810142994e-03
    z[3,4,4]  R1668     -0.529833972454071
    z[3,4,4]  R1669     -2.1755275130271912e-01
    z[3,4,4]  R1670     3.9323933422565460e-02
    z[3,4,4]  R1671     -2.9293003678321838e-01
    z[3,4,4]  R1672     1.9246637821197510e-01
    z[3,4,4]  R1673     4.1980087757110596e-01
    z[3,4,4]  R1674     -0.105362668633461
    z[3,4,4]  R1675     -9.4741076231002808e-02
    z[3,4,4]  R1676     2.9477930068969727e-01
    z[3,4,4]  R1677     6.4331911504268646e-02
    z[3,4,4]  R1678     -3.6906756460666656e-02
    z[3,4,4]  R1679     -5.6205880641937256e-01
    z[3,4,4]  R1680     -5.7529205083847046e-01
    z[3,4,4]  R1681     -1.3045415282249451e-01
    z[3,4,4]  R1682     -4.6280416846275330e-01
    z[3,4,4]  R1683     6.5524756908416748e-01
    z[3,4,4]  R1684     1.6345609724521637e-01
    z[3,4,4]  R1685     -1.2294919788837433e-01
    z[3,4,4]  R1686     -8.3895868062973022e-01
    z[3,4,4]  R1687     -8.0667078495025635e-01
    z[3,4,4]  R1688     -7.0341515541076660e-01
    z[3,4,4]  R1689     -6.1113911867141724e-01
    z[3,4,4]  R1690     -6.0859465599060059e-01
    z[3,4,4]  R1691     1.7166081070899963e-01
    z[3,4,4]  R1692     2.6555103063583374e-01
    z[3,4,4]  R1693     -3.5666882991790771e-01
    z[3,4,4]  R1694     6.2006723880767822e-01
    z[3,4,4]  R1695     7.9848326742649078e-02
    z[3,4,4]  R1696     5.8126222342252731e-02
    z[3,4,4]  R1697     5.9390628337860107e-01
    z[3,4,4]  R1698     -3.8776338100433350e-01
    z[3,4,4]  R1699     2.5676438584923744e-02
    z[3,4,4]  R1700     3.1820493936538696e-01
    z[3,4,4]  R1701     -1.7874620854854584e-01
    z[3,4,4]  R1702     -2.6201993227005005e-01
    z[3,4,4]  R1703     -1.4919523894786835e-01
    z[3,4,4]  R1704     -2.1776072680950165e-01
    z[3,4,4]  R1705     -3.7224754691123962e-01
    z[3,4,4]  R1706     5.7311993837356567e-01
    z[3,4,4]  R1707     3.3144921064376831e-01
    z[3,4,4]  R1708     -5.3990882635116577e-01
    z[3,4,4]  R1709     3.5976175218820572e-02
    z[3,4,4]  R1710     -0.162450909614563
    z[3,4,4]  R1711     2.7533066272735596e-01
    z[3,4,4]  R1712     2.1661397814750671e-01
    z[3,4,4]  R1713     -3.1194350123405457e-01
    z[3,4,4]  R1714     5.3216083906590939e-03
    z[3,4,4]  R1715     2.2346168756484985e-01
    z[3,4,4]  R1716     1.5192779898643494e-01
    z[3,4,4]  R1717     -2.9828497767448425e-01
    z[3,4,4]  R1718     0.280141681432724
    z[3,4,4]  R1719     -2.0264382660388947e-01
    z[3,4,4]  R1720     2.8758466243743896e-01
    z[3,4,4]  R1721     8.5873436182737350e-04
    z[3,4,4]  R1722     -1.1589819192886353e-01
    z[3,4,4]  R1723     -4.7125168144702911e-02
    z[3,4,4]  R1724     -5.8494526147842407e-01
    z[3,4,4]  R1725     -4.6181634068489075e-01
    z[3,4,4]  R1726     1.4247675240039825e-01
    z[3,4,4]  R1727     -1.6923119127750397e-01
    z[3,4,4]  R1728     -2.9892298579216003e-01
    z[3,4,4]  R1729     3.5811014473438263e-02
    z[3,4,4]  R1730     -1.5946429967880249e-01
    z[3,4,4]  R1731     -5.0564610958099365e-01
    z[3,4,4]  R1732     -1.6528847813606262e-01
    z[3,4,4]  R1733     -3.4734913706779480e-01
    z[3,4,4]  R1734     -2.7560099959373474e-01
    z[3,4,4]  R1735     1.1525370180606842e-01
    z[3,4,4]  R1736     -1.2992176413536072e-01
    z[3,4,4]  R1737     2.5555733591318130e-03
    z[3,4,4]  R1738     4.9524795264005661e-02
    z[3,4,4]  R1739     -1.4719154569320381e-04
    z[3,4,4]  R1740     2.0635944604873657e-01
    z[3,4,5]  R34       -1
    z[3,4,5]  R43       1
    z[3,4,5]  R1627     -1
    z[3,4,5]  R1628     1
    z[3,4,5]  R1631     -0.553044319152832
    z[3,4,5]  R1632     -4.2993504554033279e-02
    z[3,4,5]  R1633     1.1749506741762161e-01
    z[3,4,5]  R1634     1.4075703918933868e-01
    z[3,4,5]  R1635     3.2285955548286438e-01
    z[3,4,5]  R1636     7.0158019661903381e-02
    z[3,4,5]  R1637     -1.0275598615407944e-01
    z[3,4,5]  R1638     0.0361696258187294
    z[3,4,5]  R1639     -3.3468861132860184e-02
    z[3,4,5]  R1640     1.3391450047492981e-01
    z[3,4,5]  R1641     2.3491376638412476e-01
    z[3,4,5]  R1642     5.3270930051803589e-01
    z[3,4,5]  R1643     4.1350486874580383e-01
    z[3,4,5]  R1644     -4.1556110978126526e-01
    z[3,4,5]  R1645     6.7152678966522217e-01
    z[3,4,5]  R1646     -0.263075053691864
    z[3,4,5]  R1647     5.5658805370330811e-01
    z[3,4,5]  R1648     5.5850416421890259e-01
    z[3,4,5]  R1649     5.6426358222961426e-01
    z[3,4,5]  R1650     -3.5225117206573486e-01
    z[3,4,5]  R1651     -5.2893179655075073e-01
    z[3,4,5]  R1652     1.7745985090732574e-01
    z[3,4,5]  R1653     3.4801909327507019e-01
    z[3,4,5]  R1654     2.7866625785827637e-01
    z[3,4,5]  R1655     4.0741279721260071e-01
    z[3,4,5]  R1656     2.2728929296135902e-02
    z[3,4,5]  R1657     -2.8804320096969604e-01
    z[3,4,5]  R1658     5.1546716690063477e-01
    z[3,4,5]  R1659     6.7101502418518066e-01
    z[3,4,5]  R1660     5.8186775445938110e-01
    z[3,4,5]  R1661     -1.0468350723385811e-02
    z[3,4,5]  R1662     5.1003140211105347e-01
    z[3,4,5]  R1663     6.9440108537673950e-01
    z[3,4,5]  R1664     5.5458873510360718e-01
    z[3,4,5]  R1665     0.413343220949173
    z[3,4,5]  R1666     2.9687958955764771e-01
    z[3,4,5]  R1667     -2.5644791126251221e-01
    z[3,4,5]  R1668     -6.2193788588047028e-02
    z[3,4,5]  R1669     -2.6785546541213989e-01
    z[3,4,5]  R1670     3.3473879098892212e-01
    z[3,4,5]  R1671     -4.3114152550697327e-01
    z[3,4,5]  R1672     8.2911419868469238e-01
    z[3,4,5]  R1673     2.9068300127983093e-01
    z[3,4,5]  R1674     2.2954536974430084e-01
    z[3,4,5]  R1675     2.1932075917720795e-01
    z[3,4,5]  R1676     2.2315025329589844e-01
    z[3,4,5]  R1677     2.0577101409435272e-01
    z[3,4,5]  R1678     3.7524858117103577e-01
    z[3,4,5]  R1679     5.0734555721282959e-01
    z[3,4,5]  R1680     4.7492590546607971e-01
    z[3,4,5]  R1681     -2.1041874587535858e-01
    z[3,4,5]  R1682     -2.5743770599365234e-01
    z[3,4,5]  R1683     1.7963384091854095e-01
    z[3,4,5]  R1684     2.0145660638809204e-01
    z[3,4,5]  R1685     -7.7882564067840576e-01
    z[3,4,5]  R1686     3.7007558345794678e-01
    z[3,4,5]  R1687     1.8400555849075317e-01
    z[3,4,5]  R1688     3.5417270660400391e-01
    z[3,4,5]  R1689     4.2507287859916687e-01
    z[3,4,5]  R1690     6.5993052721023560e-01
    z[3,4,5]  R1691     -8.7248824536800385e-02
    z[3,4,5]  R1692     -3.4173485636711121e-01
    z[3,4,5]  R1693     -2.6238659024238586e-01
    z[3,4,5]  R1694     -3.4383806586265564e-01
    z[3,4,5]  R1695     9.3546412885189056e-02
    z[3,4,5]  R1696     -6.0945028066635132e-01
    z[3,4,5]  R1697     -4.6668532490730286e-01
    z[3,4,5]  R1698     3.9792710542678833e-01
    z[3,4,5]  R1699     1.2828531861305237e-01
    z[3,4,5]  R1700     9.0913869440555573e-02
    z[3,4,5]  R1701     4.4212940335273743e-01
    z[3,4,5]  R1702     7.7977198362350464e-01
    z[3,4,5]  R1703     -4.2695045471191406e-01
    z[3,4,5]  R1704     3.7409138679504395e-01
    z[3,4,5]  R1705     9.4170890748500824e-02
    z[3,4,5]  R1706     3.5449784994125366e-01
    z[3,4,5]  R1707     3.2058224081993103e-01
    z[3,4,5]  R1708     0.0108823636546731
    z[3,4,5]  R1709     -0.0410323366522789
    z[3,4,5]  R1710     5.7950407266616821e-02
    z[3,4,5]  R1711     -2.5654423981904984e-02
    z[3,4,5]  R1712     -3.8571065664291382e-01
    z[3,4,5]  R1713     -2.5312250852584839e-01
    z[3,4,5]  R1714     2.0238001644611359e-01
    z[3,4,5]  R1715     4.6938553452491760e-01
    z[3,4,5]  R1716     1.9093506038188934e-01
    z[3,4,5]  R1717     0.0532853901386261
    z[3,4,5]  R1718     2.6255580782890320e-01
    z[3,4,5]  R1719     2.5324231386184692e-01
    z[3,4,5]  R1720     2.3000319302082062e-01
    z[3,4,5]  R1721     -2.4678705632686615e-01
    z[3,4,5]  R1722     -3.2962822914123535e-01
    z[3,4,5]  R1723     2.6725775003433228e-01
    z[3,4,5]  R1724     -2.3675398528575897e-01
    z[3,4,5]  R1725     -6.3373476266860962e-02
    z[3,4,5]  R1726     2.2593397647142410e-02
    z[3,4,5]  R1727     4.6157222986221313e-01
    z[3,4,5]  R1728     -2.4501267075538635e-01
    z[3,4,5]  R1729     -2.2183151543140411e-01
    z[3,4,5]  R1730     -1.8626582622528076e-01
    z[3,4,5]  R1731     1.2021089345216751e-01
    z[3,4,5]  R1732     -1.2923605740070343e-01
    z[3,4,5]  R1733     2.9020580649375916e-01
    z[3,4,5]  R1734     -2.4687018990516663e-01
    z[3,4,5]  R1735     -7.4510313570499420e-02
    z[3,4,5]  R1736     1.5238919854164124e-01
    z[3,4,5]  R1737     -4.1781923174858093e-01
    z[3,4,5]  R1738     -2.3594839870929718e-01
    z[3,4,5]  R1739     1.7438188195228577e-01
    z[3,4,5]  R1740     -2.5090718269348145e-01
    z[3,4,6]  R35       -1
    z[3,4,6]  R44       1
    z[3,4,6]  R1629     -1
    z[3,4,6]  R1630     1
    z[3,4,6]  R1631     2.2468097507953644e-01
    z[3,4,6]  R1632     -3.2996791601181030e-01
    z[3,4,6]  R1633     1.4762161672115326e-01
    z[3,4,6]  R1634     -4.5040425658226013e-01
    z[3,4,6]  R1635     1.3805608265101910e-02
    z[3,4,6]  R1636     5.8425735682249069e-02
    z[3,4,6]  R1637     3.9670267701148987e-01
    z[3,4,6]  R1638     0.537770688533783
    z[3,4,6]  R1639     -1.8344806134700775e-01
    z[3,4,6]  R1640     -8.5710622370243073e-02
    z[3,4,6]  R1641     -3.8023035973310471e-02
    z[3,4,6]  R1642     -0.269378125667572
    z[3,4,6]  R1643     -2.0136094093322754e-01
    z[3,4,6]  R1644     -1.4751872420310974e-01
    z[3,4,6]  R1645     -2.1189206838607788e-01
    z[3,4,6]  R1646     -1.0805781185626984e-01
    z[3,4,6]  R1647     -5.5326286703348160e-02
    z[3,4,6]  R1648     -2.1189002692699432e-01
    z[3,4,6]  R1649     4.6170207858085632e-01
    z[3,4,6]  R1650     -1.9464819133281708e-01
    z[3,4,6]  R1651     4.3017691373825073e-01
    z[3,4,6]  R1652     -1.5040473639965057e-01
    z[3,4,6]  R1653     6.3325248658657074e-02
    z[3,4,6]  R1654     1.1317790299654007e-01
    z[3,4,6]  R1655     1.9343329966068268e-01
    z[3,4,6]  R1656     -7.9061530530452728e-02
    z[3,4,6]  R1657     -9.6641272306442261e-02
    z[3,4,6]  R1658     -1.0856087505817413e-01
    z[3,4,6]  R1659     -1.6978496313095093e-01
    z[3,4,6]  R1660     -2.2336056455969810e-02
    z[3,4,6]  R1661     -1.4777894318103790e-01
    z[3,4,6]  R1662     9.7572272352408618e-05
    z[3,4,6]  R1663     -1.1589463800191879e-01
    z[3,4,6]  R1664     2.8197151422500610e-01
    z[3,4,6]  R1665     2.7002471685409546e-01
    z[3,4,6]  R1666     8.2531832158565521e-02
    z[3,4,6]  R1667     -1.7834395170211792e-02
    z[3,4,6]  R1668     1.0257884860038757e-01
    z[3,4,6]  R1669     3.3247941732406616e-01
    z[3,4,6]  R1670     3.5234186798334122e-02
    z[3,4,6]  R1671     0.0984724834561348
    z[3,4,6]  R1672     1.1448633670806885e-01
    z[3,4,6]  R1673     7.1404480934143066e-01
    z[3,4,6]  R1674     -1.8833881616592407e-01
    z[3,4,6]  R1675     -7.0366062223911285e-02
    z[3,4,6]  R1676     6.7802697420120239e-02
    z[3,4,6]  R1677     1.1730934679508209e-01
    z[3,4,6]  R1678     -6.0412295162677765e-02
    z[3,4,6]  R1679     -2.2613309323787689e-01
    z[3,4,6]  R1680     2.3787630721926689e-02
    z[3,4,6]  R1681     7.1329828351736069e-03
    z[3,4,6]  R1682     -7.9224541783332825e-02
    z[3,4,6]  R1683     4.9727505445480347e-01
    z[3,4,6]  R1684     -1.5995460748672485e-01
    z[3,4,6]  R1685     -5.7356536388397217e-01
    z[3,4,6]  R1686     1.2033274024724960e-01
    z[3,4,6]  R1687     -7.1916177868843079e-02
    z[3,4,6]  R1688     -3.6164382100105286e-01
    z[3,4,6]  R1689     -3.1468236446380615e-01
    z[3,4,6]  R1690     -1.3965220749378204e-01
    z[3,4,6]  R1691     -1.8227215111255646e-01
    z[3,4,6]  R1692     4.8308894038200378e-01
    z[3,4,6]  R1693     -5.2540283650159836e-03
    z[3,4,6]  R1694     -1.7118491232395172e-01
    z[3,4,6]  R1695     -1.2941205501556396e-01
    z[3,4,6]  R1696     0.259101003408432
    z[3,4,6]  R1697     2.1217225492000580e-01
    z[3,4,6]  R1698     -2.0377086102962494e-01
    z[3,4,6]  R1699     4.9424994736909866e-02
    z[3,4,6]  R1700     3.2052415609359741e-01
    z[3,4,6]  R1701     -1.9010773301124573e-01
    z[3,4,6]  R1702     8.6065813899040222e-02
    z[3,4,6]  R1703     -7.1420705318450928e-01
    z[3,4,6]  R1704     -3.7376844882965088e-01
    z[3,4,6]  R1705     -1.0020061582326889e-01
    z[3,4,6]  R1706     3.3467730879783630e-01
    z[3,4,6]  R1707     -3.2956176996231079e-01
    z[3,4,6]  R1708     2.2259773313999176e-01
    z[3,4,6]  R1709     -2.7017902582883835e-02
    z[3,4,6]  R1710     1.3021923601627350e-01
    z[3,4,6]  R1711     8.4782741963863373e-02
    z[3,4,6]  R1712     2.4156148731708527e-01
    z[3,4,6]  R1713     -4.8951196670532227e-01
    z[3,4,6]  R1714     -2.1152982115745544e-01
    z[3,4,6]  R1715     -0.0820658802986145
    z[3,4,6]  R1716     -3.3595755696296692e-02
    z[3,4,6]  R1717     -4.2025718092918396e-01
    z[3,4,6]  R1718     1.0127981007099152e-01
    z[3,4,6]  R1719     2.3284368216991425e-01
    z[3,4,6]  R1720     -4.9966756254434586e-02
    z[3,4,6]  R1721     1.9454509019851685e-01
    z[3,4,6]  R1722     2.5387939065694809e-02
    z[3,4,6]  R1723     -2.3479017615318298e-01
    z[3,4,6]  R1724     -5.6522661447525024e-01
    z[3,4,6]  R1725     -3.1581774353981018e-01
    z[3,4,6]  R1726     -1.6999433934688568e-01
    z[3,4,6]  R1727     -4.7128465771675110e-01
    z[3,4,6]  R1728     -1.0066631436347961e-01
    z[3,4,6]  R1729     1.6159044206142426e-01
    z[3,4,6]  R1730     -2.1938814222812653e-01
    z[3,4,6]  R1731     -5.0658637285232544e-01
    z[3,4,6]  R1732     -4.6783113479614258e-01
    z[3,4,6]  R1733     1.0208971798419952e-02
    z[3,4,6]  R1734     -1.2860514223575592e-01
    z[3,4,6]  R1735     3.4179106354713440e-01
    z[3,4,6]  R1736     -7.7363565564155579e-02
    z[3,4,6]  R1737     3.2385224103927612e-01
    z[3,4,6]  R1738     1.7104333639144897e-01
    z[3,4,6]  R1739     2.9971027374267578e-01
    z[3,4,6]  R1740     -0.0792362168431282
    z[4,3,0]  R29       1
    z[4,3,0]  R38       -1
    z[4,3,0]  R1741     -1
    z[4,3,0]  R1742     1
    z[4,3,0]  R1755     -3.2573610544204712e-01
    z[4,3,0]  R1756     -2.5934723019599915e-01
    z[4,3,0]  R1757     8.8120587170124054e-02
    z[4,3,0]  R1758     9.8550565540790558e-02
    z[4,3,0]  R1759     6.9516366720199585e-01
    z[4,3,0]  R1760     3.5381710529327393e-01
    z[4,3,0]  R1761     5.3135710954666138e-01
    z[4,3,0]  R1762     5.0062006711959839e-01
    z[4,3,0]  R1763     -0.0803113803267479
    z[4,3,0]  R1764     -4.1130515933036804e-01
    z[4,3,0]  R1765     -0.427592396736145
    z[4,3,0]  R1766     2.0544408261775970e-01
    z[4,3,0]  R1767     0.0890294685959816
    z[4,3,0]  R1768     -6.0372769832611084e-02
    z[4,3,0]  R1769     -3.5978186130523682e-01
    z[4,3,0]  R1770     -2.9932841658592224e-01
    z[4,3,0]  R1771     -1.1968418210744858e-01
    z[4,3,0]  R1772     -1.6735707223415375e-01
    z[4,3,0]  R1773     -7.3670989274978638e-01
    z[4,3,0]  R1774     -7.2185647487640381e-01
    z[4,3,0]  R1775     5.0655186176300049e-01
    z[4,3,0]  R1776     -3.5451275110244751e-01
    z[4,3,0]  R1777     7.0910400152206421e-01
    z[4,3,0]  R1778     -3.2608368992805481e-01
    z[4,3,0]  R1779     -4.0962222218513489e-01
    z[4,3,0]  R1780     -5.7422578334808350e-01
    z[4,3,0]  R1781     4.8209443688392639e-01
    z[4,3,0]  R1782     -2.2729055583477020e-01
    z[4,3,0]  R1783     -5.2984601259231567e-01
    z[4,3,0]  R1784     -8.7798461318016052e-02
    z[4,3,0]  R1785     -2.1332009136676788e-01
    z[4,3,0]  R1786     1.4889524877071381e-01
    z[4,3,0]  R1787     6.1367547512054443e-01
    z[4,3,0]  R1788     3.5424154996871948e-01
    z[4,3,0]  R1789     7.5880038738250732e-01
    z[4,3,0]  R1790     -1.2219431251287460e-01
    z[4,3,0]  R1791     -1.5539045631885529e-01
    z[4,3,0]  R1792     -4.0151676535606384e-01
    z[4,3,0]  R1793     -4.3038254976272583e-01
    z[4,3,0]  R1794     -5.8152490854263306e-01
    z[4,3,0]  R1795     4.6116787195205688e-01
    z[4,3,0]  R1796     7.4232870340347290e-01
    z[4,3,0]  R1797     -2.1970137953758240e-01
    z[4,3,0]  R1798     -2.8013315796852112e-01
    z[4,3,0]  R1799     -2.9905471205711365e-01
    z[4,3,0]  R1800     -5.3870719671249390e-01
    z[4,3,0]  R1801     -2.1344721317291260e-01
    z[4,3,0]  R1802     -6.4537745714187622e-01
    z[4,3,0]  R1803     -6.8506032228469849e-01
    z[4,3,0]  R1804     -1.5146845579147339e-01
    z[4,3,0]  R1805     3.8435712456703186e-01
    z[4,3,0]  R1806     4.6964627504348755e-01
    z[4,3,0]  R1807     1.2871317565441132e-01
    z[4,3,0]  R1808     3.3063021302223206e-01
    z[4,3,0]  R1809     -1.5768514573574066e-01
    z[4,3,0]  R1810     -6.0754650831222534e-01
    z[4,3,0]  R1811     -4.4395166635513306e-01
    z[4,3,0]  R1812     -1.7489361763000488e-01
    z[4,3,0]  R1813     -6.6080474853515625e-01
    z[4,3,0]  R1814     -6.0426956415176392e-01
    z[4,3,0]  R1815     -3.8641926646232605e-01
    z[4,3,0]  R1816     -2.2747081518173218e-01
    z[4,3,0]  R1817     -1.8546903133392334e-01
    z[4,3,0]  R1818     -2.2525892127305269e-03
    z[4,3,0]  R1819     -3.2109636068344116e-01
    z[4,3,0]  R1820     -2.2801786661148071e-02
    z[4,3,0]  R1821     -5.9258061647415161e-01
    z[4,3,0]  R1822     -3.0523759126663208e-01
    z[4,3,0]  R1823     -4.9144953489303589e-01
    z[4,3,0]  R1824     3.5981366038322449e-01
    z[4,3,0]  R1825     4.6973848342895508e-01
    z[4,3,0]  R1826     3.7984788417816162e-01
    z[4,3,0]  R1827     3.2363331317901611e-01
    z[4,3,0]  R1828     -1.0073760896921158e-01
    z[4,3,0]  R1829     -5.3915452957153320e-01
    z[4,3,0]  R1830     0.573432981967926
    z[4,3,0]  R1831     5.8630925416946411e-01
    z[4,3,0]  R1832     6.3679113984107971e-02
    z[4,3,0]  R1833     1.5071780420839787e-02
    z[4,3,0]  R1834     1.0220363736152649e-01
    z[4,3,0]  R1835     7.9044562578201294e-01
    z[4,3,0]  R1836     -8.5493430495262146e-02
    z[4,3,0]  R1837     -2.8234678506851196e-01
    z[4,3,0]  R1838     -1.1949960142374039e-01
    z[4,3,0]  R1839     -4.2563432455062866e-01
    z[4,3,0]  R1840     -3.5032281279563904e-01
    z[4,3,0]  R1841     -2.7937644720077515e-01
    z[4,3,0]  R1842     -3.0842721462249756e-01
    z[4,3,0]  R1843     -6.1874139308929443e-01
    z[4,3,0]  R1844     -4.4269609451293945e-01
    z[4,3,0]  R1845     1.0344447195529938e-01
    z[4,3,0]  R1846     -9.6073616296052933e-03
    z[4,3,0]  R1847     -3.5229781270027161e-01
    z[4,3,0]  R1848     2.1113598719239235e-02
    z[4,3,0]  R1849     -1.6194912791252136e-01
    z[4,3,0]  R1850     1.4746780693531036e-01
    z[4,3,0]  R1851     -3.9892011880874634e-01
    z[4,3,0]  R1852     -2.4754211306571960e-01
    z[4,3,0]  R1853     -5.6692034006118774e-01
    z[4,3,0]  R1854     -6.1223447322845459e-01
    z[4,3,0]  R1855     -8.9415594935417175e-02
    z[4,3,0]  R1856     5.4197525978088379e-01
    z[4,3,0]  R1857     -3.4987998008728027e-01
    z[4,3,0]  R1858     -5.3841060400009155e-01
    z[4,3,0]  R1859     1.6175134107470512e-02
    z[4,3,0]  R1860     1.9008865579962730e-02
    z[4,3,0]  R1861     -1.1379750072956085e-01
    z[4,3,0]  R1862     8.3032414317131042e-02
    z[4,3,0]  R1863     -6.1901800334453583e-02
    z[4,3,0]  R1864     2.9676225781440735e-01
    z[4,3,1]  R30       1
    z[4,3,1]  R39       -1
    z[4,3,1]  R1743     -1
    z[4,3,1]  R1744     1
    z[4,3,1]  R1755     8.6098372936248779e-02
    z[4,3,1]  R1756     4.0809374302625656e-02
    z[4,3,1]  R1757     1.4856897294521332e-02
    z[4,3,1]  R1758     3.5770680755376816e-02
    z[4,3,1]  R1759     2.9243474826216698e-02
    z[4,3,1]  R1760     3.3882107585668564e-02
    z[4,3,1]  R1761     4.2408645153045654e-02
    z[4,3,1]  R1762     -2.6837334036827087e-02
    z[4,3,1]  R1763     -9.8626506328582764e-01
    z[4,3,1]  R1764     -7.7075231075286865e-01
    z[4,3,1]  R1765     3.3755227923393250e-01
    z[4,3,1]  R1766     4.6453335881233215e-01
    z[4,3,1]  R1767     2.0314882695674896e-01
    z[4,3,1]  R1768     -4.5288348197937012e-01
    z[4,3,1]  R1769     -2.2510962188243866e-01
    z[4,3,1]  R1770     7.5029619038105011e-02
    z[4,3,1]  R1771     -1.1169072240591049e-01
    z[4,3,1]  R1772     -2.0647212862968445e-01
    z[4,3,1]  R1773     3.1193214654922485e-01
    z[4,3,1]  R1774     1.0958223044872284e-01
    z[4,3,1]  R1775     7.0791471004486084e-01
    z[4,3,1]  R1776     7.0677822828292847e-01
    z[4,3,1]  R1777     -9.4216220080852509e-02
    z[4,3,1]  R1778     -1.8292379379272461e-01
    z[4,3,1]  R1779     -3.1834807991981506e-01
    z[4,3,1]  R1780     -2.9790893197059631e-02
    z[4,3,1]  R1781     -6.2753939628601074e-01
    z[4,3,1]  R1782     -2.8487288951873779e-01
    z[4,3,1]  R1783     -2.7020066976547241e-01
    z[4,3,1]  R1784     -8.7465830147266388e-02
    z[4,3,1]  R1785     9.1370832920074463e-01
    z[4,3,1]  R1786     6.0478651523590088e-01
    z[4,3,1]  R1787     -5.3782677650451660e-01
    z[4,3,1]  R1788     -2.0813673734664917e-01
    z[4,3,1]  R1789     -1.4956003427505493e-01
    z[4,3,1]  R1790     -9.1522234678268433e-01
    z[4,3,1]  R1791     -3.5401773452758789e-01
    z[4,3,1]  R1792     -7.9296404123306274e-01
    z[4,3,1]  R1793     -7.6892828941345215e-01
    z[4,3,1]  R1794     -7.2409129142761230e-01
    z[4,3,1]  R1795     2.1006102859973907e-01
    z[4,3,1]  R1796     -0.37724769115448
    z[4,3,1]  R1797     -2.4791140854358673e-01
    z[4,3,1]  R1798     -8.7415516376495361e-01
    z[4,3,1]  R1799     -8.2212585210800171e-01
    z[4,3,1]  R1800     -7.7263385057449341e-01
    z[4,3,1]  R1801     -8.1514602899551392e-01
    z[4,3,1]  R1802     -6.6241323947906494e-01
    z[4,3,1]  R1803     -5.7923221588134766e-01
    z[4,3,1]  R1804     -8.5195028781890869e-01
    z[4,3,1]  R1805     -3.8943392038345337e-01
    z[4,3,1]  R1806     1.0056421905755997e-01
    z[4,3,1]  R1807     1.5411810576915741e-01
    z[4,3,1]  R1808     -7.9090172052383423e-01
    z[4,3,1]  R1809     -0.0875360444188118
    z[4,3,1]  R1810     -6.2563389539718628e-01
    z[4,3,1]  R1811     -0.704354465007782
    z[4,3,1]  R1812     -7.9132989048957825e-02
    z[4,3,1]  R1813     -6.2296229600906372e-01
    z[4,3,1]  R1814     -6.6563093662261963e-01
    z[4,3,1]  R1815     -4.1182957589626312e-02
    z[4,3,1]  R1816     -3.4564676880836487e-01
    z[4,3,1]  R1817     2.8088864684104919e-01
    z[4,3,1]  R1818     3.0188298225402832e-01
    z[4,3,1]  R1819     6.1274491250514984e-02
    z[4,3,1]  R1820     0.0978856310248375
    z[4,3,1]  R1821     2.0466198027133942e-01
    z[4,3,1]  R1822     6.6788643598556519e-03
    z[4,3,1]  R1823     1.1274852603673935e-01
    z[4,3,1]  R1824     4.3839445710182190e-01
    z[4,3,1]  R1825     3.5533255338668823e-01
    z[4,3,1]  R1826     -6.9836688041687012e-01
    z[4,3,1]  R1827     -3.9601841568946838e-01
    z[4,3,1]  R1828     1.1077233403921127e-01
    z[4,3,1]  R1829     2.0387648046016693e-01
    z[4,3,1]  R1830     -2.1392878890037537e-01
    z[4,3,1]  R1831     3.0866166949272156e-01
    z[4,3,1]  R1832     -1.5111443400382996e-01
    z[4,3,1]  R1833     2.5715095922350883e-02
    z[4,3,1]  R1834     -1.4068578183650970e-01
    z[4,3,1]  R1835     -0.302144318819046
    z[4,3,1]  R1836     3.4736540168523788e-02
    z[4,3,1]  R1837     -1.4574143290519714e-01
    z[4,3,1]  R1838     -2.2250409424304962e-01
    z[4,3,1]  R1839     -4.6310713887214661e-01
    z[4,3,1]  R1840     2.1093061566352844e-01
    z[4,3,1]  R1841     -8.5881382226943970e-01
    z[4,3,1]  R1842     -4.4231769442558289e-01
    z[4,3,1]  R1843     -0.606364369392395
    z[4,3,1]  R1844     -7.1295052766799927e-01
    z[4,3,1]  R1845     7.0980495214462280e-01
    z[4,3,1]  R1846     -4.2589294910430908e-01
    z[4,3,1]  R1847     -1.5035982429981232e-01
    z[4,3,1]  R1848     9.3660390377044678e-01
    z[4,3,1]  R1849     9.3908828496932983e-01
    z[4,3,1]  R1850     8.6301565170288086e-01
    z[4,3,1]  R1851     5.0970077514648438e-01
    z[4,3,1]  R1852     7.0335948467254639e-01
    z[4,3,1]  R1853     2.9809432104229927e-02
    z[4,3,1]  R1854     -9.8309412598609924e-02
    z[4,3,1]  R1855     6.9336611032485962e-01
    z[4,3,1]  R1856     -6.0947406291961670e-01
    z[4,3,1]  R1857     -2.0571936666965485e-01
    z[4,3,1]  R1858     -7.4226832389831543e-01
    z[4,3,1]  R1859     1.8295995891094208e-01
    z[4,3,1]  R1860     6.1455290764570236e-02
    z[4,3,1]  R1861     1.7191922664642334e-01
    z[4,3,1]  R1862     2.5506317615509033e-01
    z[4,3,1]  R1863     9.5106415450572968e-02
    z[4,3,1]  R1864     -8.0855406820774078e-02
    z[4,3,2]  R31       1
    z[4,3,2]  R40       -1
    z[4,3,2]  R1745     -1
    z[4,3,2]  R1746     1
    z[4,3,2]  R1755     8.7004798650741577e-01
    z[4,3,2]  R1756     -3.1570014357566833e-01
    z[4,3,2]  R1757     -3.2411649823188782e-01
    z[4,3,2]  R1758     -4.5273759961128235e-01
    z[4,3,2]  R1759     -3.1902936100959778e-01
    z[4,3,2]  R1760     -3.8057672977447510e-01
    z[4,3,2]  R1761     2.3256923258304596e-01
    z[4,3,2]  R1762     -5.2614736557006836e-01
    z[4,3,2]  R1763     3.5125121474266052e-02
    z[4,3,2]  R1764     -0.135227769613266
    z[4,3,2]  R1765     -6.6119629144668579e-01
    z[4,3,2]  R1766     2.4024224281311035e-01
    z[4,3,2]  R1767     -3.2324683666229248e-01
    z[4,3,2]  R1768     2.6352068781852722e-01
    z[4,3,2]  R1769     1.5180575847625732e-01
    z[4,3,2]  R1770     1.7123924195766449e-01
    z[4,3,2]  R1771     -3.2004401087760925e-02
    z[4,3,2]  R1772     4.7869232296943665e-01
    z[4,3,2]  R1773     3.6024913191795349e-01
    z[4,3,2]  R1774     6.1882162094116211e-01
    z[4,3,2]  R1775     -3.1423881649971008e-01
    z[4,3,2]  R1776     2.6292544603347778e-01
    z[4,3,2]  R1777     2.8887814283370972e-01
    z[4,3,2]  R1778     7.3006629943847656e-01
    z[4,3,2]  R1779     3.7077632546424866e-01
    z[4,3,2]  R1780     4.2833951115608215e-01
    z[4,3,2]  R1781     -2.1611212193965912e-01
    z[4,3,2]  R1782     7.2118914127349854e-01
    z[4,3,2]  R1783     4.2355710268020630e-01
    z[4,3,2]  R1784     3.1084164977073669e-01
    z[4,3,2]  R1785     -1.4423248171806335e-01
    z[4,3,2]  R1786     6.9796758890151978e-01
    z[4,3,2]  R1787     -4.3535566329956055e-01
    z[4,3,2]  R1788     -6.3349805772304535e-02
    z[4,3,2]  R1789     -2.9123482108116150e-01
    z[4,3,2]  R1790     -3.1179878115653992e-01
    z[4,3,2]  R1791     2.2285149991512299e-01
    z[4,3,2]  R1792     -0.224463552236557
    z[4,3,2]  R1793     -3.3415627479553223e-01
    z[4,3,2]  R1794     1.4328600466251373e-01
    z[4,3,2]  R1795     -4.3183878064155579e-01
    z[4,3,2]  R1796     -1.9323955476284027e-01
    z[4,3,2]  R1797     2.3670576512813568e-01
    z[4,3,2]  R1798     -4.6494167298078537e-02
    z[4,3,2]  R1799     -2.1576589345932007e-01
    z[4,3,2]  R1800     -1.8845294415950775e-01
    z[4,3,2]  R1801     8.5460282862186432e-02
    z[4,3,2]  R1802     9.2955529689788818e-02
    z[4,3,2]  R1803     1.5348492562770844e-01
    z[4,3,2]  R1804     3.5969346761703491e-01
    z[4,3,2]  R1805     -1.3613632321357727e-01
    z[4,3,2]  R1806     -3.2119369506835938e-01
    z[4,3,2]  R1807     0.11175537109375
    z[4,3,2]  R1808     3.1654998660087585e-02
    z[4,3,2]  R1809     8.4770750999450684e-01
    z[4,3,2]  R1810     -1.4828373491764069e-01
    z[4,3,2]  R1811     2.9359790682792664e-01
    z[4,3,2]  R1812     0.686779260635376
    z[4,3,2]  R1813     -3.4933474659919739e-01
    z[4,3,2]  R1814     -1.5206056833267212e-01
    z[4,3,2]  R1815     1.1364550888538361e-01
    z[4,3,2]  R1816     3.4251266717910767e-01
    z[4,3,2]  R1817     8.4152139723300934e-02
    z[4,3,2]  R1818     -7.0116829872131348e-01
    z[4,3,2]  R1819     0.310958594083786
    z[4,3,2]  R1820     -4.8581293225288391e-01
    z[4,3,2]  R1821     1.5351407229900360e-01
    z[4,3,2]  R1822     -2.2517786920070648e-01
    z[4,3,2]  R1823     2.1858850494027138e-02
    z[4,3,2]  R1824     -4.2397168278694153e-01
    z[4,3,2]  R1825     1.2479174137115479e-01
    z[4,3,2]  R1826     4.9236118793487549e-01
    z[4,3,2]  R1827     7.7350640296936035e-01
    z[4,3,2]  R1828     4.2019265890121460e-01
    z[4,3,2]  R1829     3.5428783297538757e-01
    z[4,3,2]  R1830     3.6612513661384583e-01
    z[4,3,2]  R1831     1.0885686427354813e-01
    z[4,3,2]  R1832     5.1020783185958862e-01
    z[4,3,2]  R1833     6.2840634584426880e-01
    z[4,3,2]  R1834     9.5704257488250732e-02
    z[4,3,2]  R1835     4.8155072331428528e-01
    z[4,3,2]  R1836     0.616873025894165
    z[4,3,2]  R1837     4.6412819623947144e-01
    z[4,3,2]  R1838     1.1298055946826935e-01
    z[4,3,2]  R1839     4.5124284923076630e-02
    z[4,3,2]  R1840     6.3735512085258961e-03
    z[4,3,2]  R1841     -2.0513303577899933e-01
    z[4,3,2]  R1842     -1.2549702823162079e-01
    z[4,3,2]  R1843     -1.3414016366004944e-01
    z[4,3,2]  R1844     2.1963019669055939e-01
    z[4,3,2]  R1845     -4.5000827312469482e-01
    z[4,3,2]  R1846     8.7170645594596863e-02
    z[4,3,2]  R1847     2.8488731384277344e-01
    z[4,3,2]  R1848     2.7279371395707130e-02
    z[4,3,2]  R1849     -1.3675086200237274e-01
    z[4,3,2]  R1850     3.0031827092170715e-01
    z[4,3,2]  R1851     -6.9078212976455688e-01
    z[4,3,2]  R1852     -5.2651494741439819e-01
    z[4,3,2]  R1853     2.8083970770239830e-02
    z[4,3,2]  R1854     2.4156154692173004e-01
    z[4,3,2]  R1855     -5.5537432432174683e-01
    z[4,3,2]  R1856     2.1817199885845184e-01
    z[4,3,2]  R1857     2.2642841935157776e-01
    z[4,3,2]  R1858     -1.9141036272048950e-01
    z[4,3,2]  R1859     1.1570196598768234e-01
    z[4,3,2]  R1860     -0.0828382596373558
    z[4,3,2]  R1861     2.0725773274898529e-01
    z[4,3,2]  R1862     8.0018816515803337e-03
    z[4,3,2]  R1863     -3.0644190311431885e-01
    z[4,3,2]  R1864     -1.1769544333219528e-01
    z[4,3,3]  R32       1
    z[4,3,3]  R41       -1
    z[4,3,3]  R1747     -1
    z[4,3,3]  R1748     1
    z[4,3,3]  R1755     -2.4330346286296844e-01
    z[4,3,3]  R1756     6.4088380336761475e-01
    z[4,3,3]  R1757     8.3118927478790283e-01
    z[4,3,3]  R1758     5.0202047824859619e-01
    z[4,3,3]  R1759     6.1825442314147949e-01
    z[4,3,3]  R1760     5.3561651706695557e-01
    z[4,3,3]  R1761     -2.1502526104450226e-01
    z[4,3,3]  R1762     3.4871095418930054e-01
    z[4,3,3]  R1763     6.1747943982481956e-03
    z[4,3,3]  R1764     -7.8910492360591888e-02
    z[4,3,3]  R1765     -4.9729026854038239e-02
    z[4,3,3]  R1766     -1.3379671610891819e-02
    z[4,3,3]  R1767     -3.6287495493888855e-01
    z[4,3,3]  R1768     -6.2828463315963745e-01
    z[4,3,3]  R1769     -7.9960060119628906e-01
    z[4,3,3]  R1770     -5.5615299940109253e-01
    z[4,3,3]  R1771     -8.0680477619171143e-01
    z[4,3,3]  R1772     -5.9920346736907959e-01
    z[4,3,3]  R1773     -4.7588801383972168e-01
    z[4,3,3]  R1774     -1.9305257499217987e-01
    z[4,3,3]  R1775     -2.4466849863529205e-01
    z[4,3,3]  R1776     -2.2717629373073578e-01
    z[4,3,3]  R1777     6.1988256871700287e-02
    z[4,3,3]  R1778     -4.9140679836273193e-01
    z[4,3,3]  R1779     -0.562491238117218
    z[4,3,3]  R1780     -6.5210080146789551e-01
    z[4,3,3]  R1781     2.4216838181018829e-01
    z[4,3,3]  R1782     -4.3520128726959229e-01
    z[4,3,3]  R1783     -5.5447423458099365e-01
    z[4,3,3]  R1784     -8.6597663164138794e-01
    z[4,3,3]  R1785     -8.7393987923860550e-03
    z[4,3,3]  R1786     -0.0466126874089241
    z[4,3,3]  R1787     1.2584270536899567e-01
    z[4,3,3]  R1788     3.3088415861129761e-01
    z[4,3,3]  R1789     -2.1796119399368763e-03
    z[4,3,3]  R1790     -2.2579845041036606e-02
    z[4,3,3]  R1791     -5.8057314157485962e-01
    z[4,3,3]  R1792     9.4112195074558258e-03
    z[4,3,3]  R1793     -1.8776719272136688e-01
    z[4,3,3]  R1794     -0.0934593677520752
    z[4,3,3]  R1795     1.7307612299919128e-01
    z[4,3,3]  R1796     8.0016024410724640e-02
    z[4,3,3]  R1797     -7.9326313734054565e-01
    z[4,3,3]  R1798     4.2148139327764511e-02
    z[4,3,3]  R1799     2.2905036807060242e-01
    z[4,3,3]  R1800     1.7671939730644226e-01
    z[4,3,3]  R1801     -5.6692283600568771e-02
    z[4,3,3]  R1802     2.2062557935714722e-01
    z[4,3,3]  R1803     2.2669243812561035e-01
    z[4,3,3]  R1804     -1.0020788758993149e-01
    z[4,3,3]  R1805     4.5321959257125854e-01
    z[4,3,3]  R1806     4.4695851206779480e-01
    z[4,3,3]  R1807     9.3673390150070190e-01
    z[4,3,3]  R1808     1.9504196941852570e-01
    z[4,3,3]  R1809     -2.9698863625526428e-01
    z[4,3,3]  R1810     -0.0312623456120491
    z[4,3,3]  R1811     -2.2925306856632233e-01
    z[4,3,3]  R1812     -4.2882928252220154e-01
    z[4,3,3]  R1813     6.9269701838493347e-02
    z[4,3,3]  R1814     3.7578254938125610e-01
    z[4,3,3]  R1815     -8.1052398681640625e-01
    z[4,3,3]  R1816     -5.8123838901519775e-01
    z[4,3,3]  R1817     -0.560954213142395
    z[4,3,3]  R1818     1.1045350879430771e-01
    z[4,3,3]  R1819     -3.7698951363563538e-01
    z[4,3,3]  R1820     4.2962488532066345e-01
    z[4,3,3]  R1821     -4.0225467085838318e-01
    z[4,3,3]  R1822     -5.8202630281448364e-01
    z[4,3,3]  R1823     -4.1785049438476562e-01
    z[4,3,3]  R1824     -3.0952779576182365e-02
    z[4,3,3]  R1825     2.3720730841159821e-01
    z[4,3,3]  R1826     6.9490201771259308e-02
    z[4,3,3]  R1827     1.2240605801343918e-01
    z[4,3,3]  R1828     -6.0070788860321045e-01
    z[4,3,3]  R1829     -0.522066593170166
    z[4,3,3]  R1830     3.8913151621818542e-01
    z[4,3,3]  R1831     3.6415389180183411e-01
    z[4,3,3]  R1832     -1.9415524601936340e-01
    z[4,3,3]  R1833     -3.3607918024063110e-01
    z[4,3,3]  R1834     -3.9141789078712463e-01
    z[4,3,3]  R1835     -8.4982894361019135e-02
    z[4,3,3]  R1836     -5.5730760097503662e-01
    z[4,3,3]  R1837     -9.1690264642238617e-02
    z[4,3,3]  R1838     -7.2996979951858521e-01
    z[4,3,3]  R1839     -5.5128979682922363e-01
    z[4,3,3]  R1840     -0.838477373123169
    z[4,3,3]  R1841     -2.7604243159294128e-01
    z[4,3,3]  R1842     6.3116061687469482e-01
    z[4,3,3]  R1843     -4.3238624930381775e-02
    z[4,3,3]  R1844     3.6420649290084839e-01
    z[4,3,3]  R1845     -3.9759587496519089e-02
    z[4,3,3]  R1846     -2.7081990242004395e-01
    z[4,3,3]  R1847     3.9089463651180267e-02
    z[4,3,3]  R1848     -1.4939683675765991e-01
    z[4,3,3]  R1849     1.0562177002429962e-01
    z[4,3,3]  R1850     4.4475674629211426e-02
    z[4,3,3]  R1851     2.0891658961772919e-01
    z[4,3,3]  R1852     0.14479960501194
    z[4,3,3]  R1853     -2.2908157110214233e-01
    z[4,3,3]  R1854     -8.4188235923647881e-03
    z[4,3,3]  R1855     3.7611511349678040e-01
    z[4,3,3]  R1856     -2.1606069058179855e-02
    z[4,3,3]  R1857     -2.7403208613395691e-01
    z[4,3,3]  R1858     1.7212149500846863e-01
    z[4,3,3]  R1859     4.7052096575498581e-02
    z[4,3,3]  R1860     -3.6566668748855591e-01
    z[4,3,3]  R1861     -4.7412046790122986e-01
    z[4,3,3]  R1862     -4.2067438364028931e-01
    z[4,3,3]  R1863     -4.8991143703460693e-01
    z[4,3,3]  R1864     -2.5718429684638977e-01
    z[4,3,4]  R33       1
    z[4,3,4]  R42       -1
    z[4,3,4]  R1749     -1
    z[4,3,4]  R1750     1
    z[4,3,4]  R1755     1.7166081070899963e-01
    z[4,3,4]  R1756     2.6555103063583374e-01
    z[4,3,4]  R1757     -3.5666882991790771e-01
    z[4,3,4]  R1758     6.2006723880767822e-01
    z[4,3,4]  R1759     7.9848326742649078e-02
    z[4,3,4]  R1760     5.8126222342252731e-02
    z[4,3,4]  R1761     5.9390628337860107e-01
    z[4,3,4]  R1762     -3.8776338100433350e-01
    z[4,3,4]  R1763     2.5676438584923744e-02
    z[4,3,4]  R1764     3.1820493936538696e-01
    z[4,3,4]  R1765     -1.7874620854854584e-01
    z[4,3,4]  R1766     -2.6201993227005005e-01
    z[4,3,4]  R1767     -1.4919523894786835e-01
    z[4,3,4]  R1768     -2.1776072680950165e-01
    z[4,3,4]  R1769     -3.7224754691123962e-01
    z[4,3,4]  R1770     5.7311993837356567e-01
    z[4,3,4]  R1771     3.3144921064376831e-01
    z[4,3,4]  R1772     -5.3990882635116577e-01
    z[4,3,4]  R1773     3.5976175218820572e-02
    z[4,3,4]  R1774     -0.162450909614563
    z[4,3,4]  R1775     2.7533066272735596e-01
    z[4,3,4]  R1776     2.1661397814750671e-01
    z[4,3,4]  R1777     -3.1194350123405457e-01
    z[4,3,4]  R1778     5.3216083906590939e-03
    z[4,3,4]  R1779     2.2346168756484985e-01
    z[4,3,4]  R1780     1.5192779898643494e-01
    z[4,3,4]  R1781     -2.9828497767448425e-01
    z[4,3,4]  R1782     0.280141681432724
    z[4,3,4]  R1783     -2.0264382660388947e-01
    z[4,3,4]  R1784     2.8758466243743896e-01
    z[4,3,4]  R1785     8.5873436182737350e-04
    z[4,3,4]  R1786     -1.1589819192886353e-01
    z[4,3,4]  R1787     -4.7125168144702911e-02
    z[4,3,4]  R1788     -5.8494526147842407e-01
    z[4,3,4]  R1789     -4.6181634068489075e-01
    z[4,3,4]  R1790     1.4247675240039825e-01
    z[4,3,4]  R1791     -1.6923119127750397e-01
    z[4,3,4]  R1792     -2.9892298579216003e-01
    z[4,3,4]  R1793     3.5811014473438263e-02
    z[4,3,4]  R1794     -1.5946429967880249e-01
    z[4,3,4]  R1795     -5.0564610958099365e-01
    z[4,3,4]  R1796     -1.6528847813606262e-01
    z[4,3,4]  R1797     -3.4734913706779480e-01
    z[4,3,4]  R1798     -2.7560099959373474e-01
    z[4,3,4]  R1799     1.1525370180606842e-01
    z[4,3,4]  R1800     -1.2992176413536072e-01
    z[4,3,4]  R1801     2.5555733591318130e-03
    z[4,3,4]  R1802     4.9524795264005661e-02
    z[4,3,4]  R1803     -1.4719154569320381e-04
    z[4,3,4]  R1804     2.0635944604873657e-01
    z[4,3,4]  R1805     3.4688645601272583e-01
    z[4,3,4]  R1806     5.9636777639389038e-01
    z[4,3,4]  R1807     1.8472562730312347e-01
    z[4,3,4]  R1808     -5.8635283261537552e-02
    z[4,3,4]  R1809     -2.3713652789592743e-01
    z[4,3,4]  R1810     4.5625463128089905e-01
    z[4,3,4]  R1811     1.0159126482903957e-02
    z[4,3,4]  R1812     1.3070702552795410e-01
    z[4,3,4]  R1813     -1.1682728677988052e-01
    z[4,3,4]  R1814     -4.6683631837368011e-02
    z[4,3,4]  R1815     3.4998500347137451e-01
    z[4,3,4]  R1816     1.3148643076419830e-01
    z[4,3,4]  R1817     5.9449046850204468e-01
    z[4,3,4]  R1818     -4.5888105034828186e-01
    z[4,3,4]  R1819     3.9809507131576538e-01
    z[4,3,4]  R1820     -6.9887173175811768e-01
    z[4,3,4]  R1821     3.2974988222122192e-01
    z[4,3,4]  R1822     4.0062639117240906e-01
    z[4,3,4]  R1823     1.9780324399471283e-01
    z[4,3,4]  R1824     -5.7936644554138184e-01
    z[4,3,4]  R1825     -0.341208279132843
    z[4,3,4]  R1826     -2.5814184546470642e-01
    z[4,3,4]  R1827     2.8583295643329620e-03
    z[4,3,4]  R1828     5.9135907888412476e-01
    z[4,3,4]  R1829     2.5743296742439270e-01
    z[4,3,4]  R1830     -5.7720959186553955e-01
    z[4,3,4]  R1831     -5.6938838958740234e-01
    z[4,3,4]  R1832     6.3056260347366333e-01
    z[4,3,4]  R1833     0.110362209379673
    z[4,3,4]  R1834     6.8434321880340576e-01
    z[4,3,4]  R1835     -1.5113914012908936e-01
    z[4,3,4]  R1836     2.0056955516338348e-01
    z[4,3,4]  R1837     4.2378431558609009e-01
    z[4,3,4]  R1838     5.9284854680299759e-02
    z[4,3,4]  R1839     2.3376183211803436e-01
    z[4,3,4]  R1840     1.8640869855880737e-01
    z[4,3,4]  R1841     5.0026741810142994e-03
    z[4,3,4]  R1842     -0.529833972454071
    z[4,3,4]  R1843     -2.1755275130271912e-01
    z[4,3,4]  R1844     3.9323933422565460e-02
    z[4,3,4]  R1845     -2.9293003678321838e-01
    z[4,3,4]  R1846     1.9246637821197510e-01
    z[4,3,4]  R1847     4.1980087757110596e-01
    z[4,3,4]  R1848     -0.105362668633461
    z[4,3,4]  R1849     -9.4741076231002808e-02
    z[4,3,4]  R1850     2.9477930068969727e-01
    z[4,3,4]  R1851     6.4331911504268646e-02
    z[4,3,4]  R1852     -3.6906756460666656e-02
    z[4,3,4]  R1853     -5.6205880641937256e-01
    z[4,3,4]  R1854     -5.7529205083847046e-01
    z[4,3,4]  R1855     -1.3045415282249451e-01
    z[4,3,4]  R1856     -4.6280416846275330e-01
    z[4,3,4]  R1857     6.5524756908416748e-01
    z[4,3,4]  R1858     1.6345609724521637e-01
    z[4,3,4]  R1859     -1.2294919788837433e-01
    z[4,3,4]  R1860     -8.3895868062973022e-01
    z[4,3,4]  R1861     -8.0667078495025635e-01
    z[4,3,4]  R1862     -7.0341515541076660e-01
    z[4,3,4]  R1863     -6.1113911867141724e-01
    z[4,3,4]  R1864     -6.0859465599060059e-01
    z[4,3,5]  R34       1
    z[4,3,5]  R43       -1
    z[4,3,5]  R1751     -1
    z[4,3,5]  R1752     1
    z[4,3,5]  R1755     -8.7248824536800385e-02
    z[4,3,5]  R1756     -3.4173485636711121e-01
    z[4,3,5]  R1757     -2.6238659024238586e-01
    z[4,3,5]  R1758     -3.4383806586265564e-01
    z[4,3,5]  R1759     9.3546412885189056e-02
    z[4,3,5]  R1760     -6.0945028066635132e-01
    z[4,3,5]  R1761     -4.6668532490730286e-01
    z[4,3,5]  R1762     3.9792710542678833e-01
    z[4,3,5]  R1763     1.2828531861305237e-01
    z[4,3,5]  R1764     9.0913869440555573e-02
    z[4,3,5]  R1765     4.4212940335273743e-01
    z[4,3,5]  R1766     7.7977198362350464e-01
    z[4,3,5]  R1767     -4.2695045471191406e-01
    z[4,3,5]  R1768     3.7409138679504395e-01
    z[4,3,5]  R1769     9.4170890748500824e-02
    z[4,3,5]  R1770     3.5449784994125366e-01
    z[4,3,5]  R1771     3.2058224081993103e-01
    z[4,3,5]  R1772     0.0108823636546731
    z[4,3,5]  R1773     -0.0410323366522789
    z[4,3,5]  R1774     5.7950407266616821e-02
    z[4,3,5]  R1775     -2.5654423981904984e-02
    z[4,3,5]  R1776     -3.8571065664291382e-01
    z[4,3,5]  R1777     -2.5312250852584839e-01
    z[4,3,5]  R1778     2.0238001644611359e-01
    z[4,3,5]  R1779     4.6938553452491760e-01
    z[4,3,5]  R1780     1.9093506038188934e-01
    z[4,3,5]  R1781     0.0532853901386261
    z[4,3,5]  R1782     2.6255580782890320e-01
    z[4,3,5]  R1783     2.5324231386184692e-01
    z[4,3,5]  R1784     2.3000319302082062e-01
    z[4,3,5]  R1785     -2.4678705632686615e-01
    z[4,3,5]  R1786     -3.2962822914123535e-01
    z[4,3,5]  R1787     2.6725775003433228e-01
    z[4,3,5]  R1788     -2.3675398528575897e-01
    z[4,3,5]  R1789     -6.3373476266860962e-02
    z[4,3,5]  R1790     2.2593397647142410e-02
    z[4,3,5]  R1791     4.6157222986221313e-01
    z[4,3,5]  R1792     -2.4501267075538635e-01
    z[4,3,5]  R1793     -2.2183151543140411e-01
    z[4,3,5]  R1794     -1.8626582622528076e-01
    z[4,3,5]  R1795     1.2021089345216751e-01
    z[4,3,5]  R1796     -1.2923605740070343e-01
    z[4,3,5]  R1797     2.9020580649375916e-01
    z[4,3,5]  R1798     -2.4687018990516663e-01
    z[4,3,5]  R1799     -7.4510313570499420e-02
    z[4,3,5]  R1800     1.5238919854164124e-01
    z[4,3,5]  R1801     -4.1781923174858093e-01
    z[4,3,5]  R1802     -2.3594839870929718e-01
    z[4,3,5]  R1803     1.7438188195228577e-01
    z[4,3,5]  R1804     -2.5090718269348145e-01
    z[4,3,5]  R1805     -0.553044319152832
    z[4,3,5]  R1806     -4.2993504554033279e-02
    z[4,3,5]  R1807     1.1749506741762161e-01
    z[4,3,5]  R1808     1.4075703918933868e-01
    z[4,3,5]  R1809     3.2285955548286438e-01
    z[4,3,5]  R1810     7.0158019661903381e-02
    z[4,3,5]  R1811     -1.0275598615407944e-01
    z[4,3,5]  R1812     0.0361696258187294
    z[4,3,5]  R1813     -3.3468861132860184e-02
    z[4,3,5]  R1814     1.3391450047492981e-01
    z[4,3,5]  R1815     2.3491376638412476e-01
    z[4,3,5]  R1816     5.3270930051803589e-01
    z[4,3,5]  R1817     4.1350486874580383e-01
    z[4,3,5]  R1818     -4.1556110978126526e-01
    z[4,3,5]  R1819     6.7152678966522217e-01
    z[4,3,5]  R1820     -0.263075053691864
    z[4,3,5]  R1821     5.5658805370330811e-01
    z[4,3,5]  R1822     5.5850416421890259e-01
    z[4,3,5]  R1823     5.6426358222961426e-01
    z[4,3,5]  R1824     -3.5225117206573486e-01
    z[4,3,5]  R1825     -5.2893179655075073e-01
    z[4,3,5]  R1826     1.7745985090732574e-01
    z[4,3,5]  R1827     3.4801909327507019e-01
    z[4,3,5]  R1828     2.7866625785827637e-01
    z[4,3,5]  R1829     4.0741279721260071e-01
    z[4,3,5]  R1830     2.2728929296135902e-02
    z[4,3,5]  R1831     -2.8804320096969604e-01
    z[4,3,5]  R1832     5.1546716690063477e-01
    z[4,3,5]  R1833     6.7101502418518066e-01
    z[4,3,5]  R1834     5.8186775445938110e-01
    z[4,3,5]  R1835     -1.0468350723385811e-02
    z[4,3,5]  R1836     5.1003140211105347e-01
    z[4,3,5]  R1837     6.9440108537673950e-01
    z[4,3,5]  R1838     5.5458873510360718e-01
    z[4,3,5]  R1839     0.413343220949173
    z[4,3,5]  R1840     2.9687958955764771e-01
    z[4,3,5]  R1841     -2.5644791126251221e-01
    z[4,3,5]  R1842     -6.2193788588047028e-02
    z[4,3,5]  R1843     -2.6785546541213989e-01
    z[4,3,5]  R1844     3.3473879098892212e-01
    z[4,3,5]  R1845     -4.3114152550697327e-01
    z[4,3,5]  R1846     8.2911419868469238e-01
    z[4,3,5]  R1847     2.9068300127983093e-01
    z[4,3,5]  R1848     2.2954536974430084e-01
    z[4,3,5]  R1849     2.1932075917720795e-01
    z[4,3,5]  R1850     2.2315025329589844e-01
    z[4,3,5]  R1851     2.0577101409435272e-01
    z[4,3,5]  R1852     3.7524858117103577e-01
    z[4,3,5]  R1853     5.0734555721282959e-01
    z[4,3,5]  R1854     4.7492590546607971e-01
    z[4,3,5]  R1855     -2.1041874587535858e-01
    z[4,3,5]  R1856     -2.5743770599365234e-01
    z[4,3,5]  R1857     1.7963384091854095e-01
    z[4,3,5]  R1858     2.0145660638809204e-01
    z[4,3,5]  R1859     -7.7882564067840576e-01
    z[4,3,5]  R1860     3.7007558345794678e-01
    z[4,3,5]  R1861     1.8400555849075317e-01
    z[4,3,5]  R1862     3.5417270660400391e-01
    z[4,3,5]  R1863     4.2507287859916687e-01
    z[4,3,5]  R1864     6.5993052721023560e-01
    z[4,3,6]  R35       1
    z[4,3,6]  R44       -1
    z[4,3,6]  R1753     -1
    z[4,3,6]  R1754     1
    z[4,3,6]  R1755     -1.8227215111255646e-01
    z[4,3,6]  R1756     4.8308894038200378e-01
    z[4,3,6]  R1757     -5.2540283650159836e-03
    z[4,3,6]  R1758     -1.7118491232395172e-01
    z[4,3,6]  R1759     -1.2941205501556396e-01
    z[4,3,6]  R1760     0.259101003408432
    z[4,3,6]  R1761     2.1217225492000580e-01
    z[4,3,6]  R1762     -2.0377086102962494e-01
    z[4,3,6]  R1763     4.9424994736909866e-02
    z[4,3,6]  R1764     3.2052415609359741e-01
    z[4,3,6]  R1765     -1.9010773301124573e-01
    z[4,3,6]  R1766     8.6065813899040222e-02
    z[4,3,6]  R1767     -7.1420705318450928e-01
    z[4,3,6]  R1768     -3.7376844882965088e-01
    z[4,3,6]  R1769     -1.0020061582326889e-01
    z[4,3,6]  R1770     3.3467730879783630e-01
    z[4,3,6]  R1771     -3.2956176996231079e-01
    z[4,3,6]  R1772     2.2259773313999176e-01
    z[4,3,6]  R1773     -2.7017902582883835e-02
    z[4,3,6]  R1774     1.3021923601627350e-01
    z[4,3,6]  R1775     8.4782741963863373e-02
    z[4,3,6]  R1776     2.4156148731708527e-01
    z[4,3,6]  R1777     -4.8951196670532227e-01
    z[4,3,6]  R1778     -2.1152982115745544e-01
    z[4,3,6]  R1779     -0.0820658802986145
    z[4,3,6]  R1780     -3.3595755696296692e-02
    z[4,3,6]  R1781     -4.2025718092918396e-01
    z[4,3,6]  R1782     1.0127981007099152e-01
    z[4,3,6]  R1783     2.3284368216991425e-01
    z[4,3,6]  R1784     -4.9966756254434586e-02
    z[4,3,6]  R1785     1.9454509019851685e-01
    z[4,3,6]  R1786     2.5387939065694809e-02
    z[4,3,6]  R1787     -2.3479017615318298e-01
    z[4,3,6]  R1788     -5.6522661447525024e-01
    z[4,3,6]  R1789     -3.1581774353981018e-01
    z[4,3,6]  R1790     -1.6999433934688568e-01
    z[4,3,6]  R1791     -4.7128465771675110e-01
    z[4,3,6]  R1792     -1.0066631436347961e-01
    z[4,3,6]  R1793     1.6159044206142426e-01
    z[4,3,6]  R1794     -2.1938814222812653e-01
    z[4,3,6]  R1795     -5.0658637285232544e-01
    z[4,3,6]  R1796     -4.6783113479614258e-01
    z[4,3,6]  R1797     1.0208971798419952e-02
    z[4,3,6]  R1798     -1.2860514223575592e-01
    z[4,3,6]  R1799     3.4179106354713440e-01
    z[4,3,6]  R1800     -7.7363565564155579e-02
    z[4,3,6]  R1801     3.2385224103927612e-01
    z[4,3,6]  R1802     1.7104333639144897e-01
    z[4,3,6]  R1803     2.9971027374267578e-01
    z[4,3,6]  R1804     -0.0792362168431282
    z[4,3,6]  R1805     2.2468097507953644e-01
    z[4,3,6]  R1806     -3.2996791601181030e-01
    z[4,3,6]  R1807     1.4762161672115326e-01
    z[4,3,6]  R1808     -4.5040425658226013e-01
    z[4,3,6]  R1809     1.3805608265101910e-02
    z[4,3,6]  R1810     5.8425735682249069e-02
    z[4,3,6]  R1811     3.9670267701148987e-01
    z[4,3,6]  R1812     0.537770688533783
    z[4,3,6]  R1813     -1.8344806134700775e-01
    z[4,3,6]  R1814     -8.5710622370243073e-02
    z[4,3,6]  R1815     -3.8023035973310471e-02
    z[4,3,6]  R1816     -0.269378125667572
    z[4,3,6]  R1817     -2.0136094093322754e-01
    z[4,3,6]  R1818     -1.4751872420310974e-01
    z[4,3,6]  R1819     -2.1189206838607788e-01
    z[4,3,6]  R1820     -1.0805781185626984e-01
    z[4,3,6]  R1821     -5.5326286703348160e-02
    z[4,3,6]  R1822     -2.1189002692699432e-01
    z[4,3,6]  R1823     4.6170207858085632e-01
    z[4,3,6]  R1824     -1.9464819133281708e-01
    z[4,3,6]  R1825     4.3017691373825073e-01
    z[4,3,6]  R1826     -1.5040473639965057e-01
    z[4,3,6]  R1827     6.3325248658657074e-02
    z[4,3,6]  R1828     1.1317790299654007e-01
    z[4,3,6]  R1829     1.9343329966068268e-01
    z[4,3,6]  R1830     -7.9061530530452728e-02
    z[4,3,6]  R1831     -9.6641272306442261e-02
    z[4,3,6]  R1832     -1.0856087505817413e-01
    z[4,3,6]  R1833     -1.6978496313095093e-01
    z[4,3,6]  R1834     -2.2336056455969810e-02
    z[4,3,6]  R1835     -1.4777894318103790e-01
    z[4,3,6]  R1836     9.7572272352408618e-05
    z[4,3,6]  R1837     -1.1589463800191879e-01
    z[4,3,6]  R1838     2.8197151422500610e-01
    z[4,3,6]  R1839     2.7002471685409546e-01
    z[4,3,6]  R1840     8.2531832158565521e-02
    z[4,3,6]  R1841     -1.7834395170211792e-02
    z[4,3,6]  R1842     1.0257884860038757e-01
    z[4,3,6]  R1843     3.3247941732406616e-01
    z[4,3,6]  R1844     3.5234186798334122e-02
    z[4,3,6]  R1845     0.0984724834561348
    z[4,3,6]  R1846     1.1448633670806885e-01
    z[4,3,6]  R1847     7.1404480934143066e-01
    z[4,3,6]  R1848     -1.8833881616592407e-01
    z[4,3,6]  R1849     -7.0366062223911285e-02
    z[4,3,6]  R1850     6.7802697420120239e-02
    z[4,3,6]  R1851     1.1730934679508209e-01
    z[4,3,6]  R1852     -6.0412295162677765e-02
    z[4,3,6]  R1853     -2.2613309323787689e-01
    z[4,3,6]  R1854     2.3787630721926689e-02
    z[4,3,6]  R1855     7.1329828351736069e-03
    z[4,3,6]  R1856     -7.9224541783332825e-02
    z[4,3,6]  R1857     4.9727505445480347e-01
    z[4,3,6]  R1858     -1.5995460748672485e-01
    z[4,3,6]  R1859     -5.7356536388397217e-01
    z[4,3,6]  R1860     1.2033274024724960e-01
    z[4,3,6]  R1861     -7.1916177868843079e-02
    z[4,3,6]  R1862     -3.6164382100105286e-01
    z[4,3,6]  R1863     -3.1468236446380615e-01
    z[4,3,6]  R1864     -1.3965220749378204e-01
    z[3,8,0]  R29       -1
    z[3,8,0]  R74       1
    z[3,8,0]  R1865     -1
    z[3,8,0]  R1866     1
    z[3,8,0]  R1879     3.8435712456703186e-01
    z[3,8,0]  R1880     4.6964627504348755e-01
    z[3,8,0]  R1881     1.2871317565441132e-01
    z[3,8,0]  R1882     3.3063021302223206e-01
    z[3,8,0]  R1883     -1.5768514573574066e-01
    z[3,8,0]  R1884     -6.0754650831222534e-01
    z[3,8,0]  R1885     -4.4395166635513306e-01
    z[3,8,0]  R1886     -1.7489361763000488e-01
    z[3,8,0]  R1887     -6.6080474853515625e-01
    z[3,8,0]  R1888     -6.0426956415176392e-01
    z[3,8,0]  R1889     -3.8641926646232605e-01
    z[3,8,0]  R1890     -2.2747081518173218e-01
    z[3,8,0]  R1891     -1.8546903133392334e-01
    z[3,8,0]  R1892     -2.2525892127305269e-03
    z[3,8,0]  R1893     -3.2109636068344116e-01
    z[3,8,0]  R1894     -2.2801786661148071e-02
    z[3,8,0]  R1895     -5.9258061647415161e-01
    z[3,8,0]  R1896     -3.0523759126663208e-01
    z[3,8,0]  R1897     -4.9144953489303589e-01
    z[3,8,0]  R1898     3.5981366038322449e-01
    z[3,8,0]  R1899     4.6973848342895508e-01
    z[3,8,0]  R1900     3.7984788417816162e-01
    z[3,8,0]  R1901     3.2363331317901611e-01
    z[3,8,0]  R1902     -1.0073760896921158e-01
    z[3,8,0]  R1903     -5.3915452957153320e-01
    z[3,8,0]  R1904     0.573432981967926
    z[3,8,0]  R1905     5.8630925416946411e-01
    z[3,8,0]  R1906     6.3679113984107971e-02
    z[3,8,0]  R1907     1.5071780420839787e-02
    z[3,8,0]  R1908     1.0220363736152649e-01
    z[3,8,0]  R1909     7.9044562578201294e-01
    z[3,8,0]  R1910     -8.5493430495262146e-02
    z[3,8,0]  R1911     -2.8234678506851196e-01
    z[3,8,0]  R1912     -1.1949960142374039e-01
    z[3,8,0]  R1913     -4.2563432455062866e-01
    z[3,8,0]  R1914     -3.5032281279563904e-01
    z[3,8,0]  R1915     -2.7937644720077515e-01
    z[3,8,0]  R1916     -3.0842721462249756e-01
    z[3,8,0]  R1917     -6.1874139308929443e-01
    z[3,8,0]  R1918     -4.4269609451293945e-01
    z[3,8,0]  R1919     1.0344447195529938e-01
    z[3,8,0]  R1920     -9.6073616296052933e-03
    z[3,8,0]  R1921     -3.5229781270027161e-01
    z[3,8,0]  R1922     2.1113598719239235e-02
    z[3,8,0]  R1923     -1.6194912791252136e-01
    z[3,8,0]  R1924     1.4746780693531036e-01
    z[3,8,0]  R1925     -3.9892011880874634e-01
    z[3,8,0]  R1926     -2.4754211306571960e-01
    z[3,8,0]  R1927     -5.6692034006118774e-01
    z[3,8,0]  R1928     -6.1223447322845459e-01
    z[3,8,0]  R1929     -8.9415594935417175e-02
    z[3,8,0]  R1930     5.4197525978088379e-01
    z[3,8,0]  R1931     -3.4987998008728027e-01
    z[3,8,0]  R1932     -5.3841060400009155e-01
    z[3,8,0]  R1933     1.6175134107470512e-02
    z[3,8,0]  R1934     1.9008865579962730e-02
    z[3,8,0]  R1935     -1.1379750072956085e-01
    z[3,8,0]  R1936     8.3032414317131042e-02
    z[3,8,0]  R1937     -6.1901800334453583e-02
    z[3,8,0]  R1938     2.9676225781440735e-01
    z[3,8,0]  R1939     -4.1689458489418030e-01
    z[3,8,0]  R1940     -4.8468196392059326e-01
    z[3,8,0]  R1941     -5.7306480407714844e-01
    z[3,8,0]  R1942     -3.4239238500595093e-01
    z[3,8,0]  R1943     -6.0957503318786621e-01
    z[3,8,0]  R1944     -3.2015225291252136e-01
    z[3,8,0]  R1945     -3.0857360363006592e-01
    z[3,8,0]  R1946     -3.9235708117485046e-01
    z[3,8,0]  R1947     -3.4801444411277771e-01
    z[3,8,0]  R1948     3.6987990140914917e-02
    z[3,8,0]  R1949     3.7160363048315048e-02
    z[3,8,0]  R1950     4.9446426331996918e-02
    z[3,8,0]  R1951     9.2987410724163055e-02
    z[3,8,0]  R1952     1.6451187431812286e-01
    z[3,8,0]  R1953     3.8392234593629837e-02
    z[3,8,0]  R1954     2.3820878937840462e-02
    z[3,8,0]  R1955     -3.6871144175529480e-01
    z[3,8,0]  R1956     -1.8168369308114052e-02
    z[3,8,0]  R1957     4.3558844923973083e-01
    z[3,8,0]  R1958     -3.8961544632911682e-02
    z[3,8,0]  R1959     2.1219049394130707e-01
    z[3,8,0]  R1960     1.0946871340274811e-01
    z[3,8,0]  R1961     -1.0069070756435394e-01
    z[3,8,0]  R1962     5.2443742752075195e-02
    z[3,8,0]  R1963     2.7736195921897888e-01
    z[3,8,0]  R1964     -9.2849425971508026e-02
    z[3,8,0]  R1965     -9.0580090880393982e-02
    z[3,8,0]  R1966     -1.5218126773834229e-01
    z[3,8,0]  R1967     -3.0100749805569649e-02
    z[3,8,0]  R1968     -3.4075182676315308e-01
    z[3,8,0]  R1969     -1.8804021179676056e-01
    z[3,8,0]  R1970     -1.2020721286535263e-01
    z[3,8,0]  R1971     1.3284712098538876e-02
    z[3,8,0]  R1972     -1.1131456494331360e-01
    z[3,8,0]  R1973     -1.0430975258350372e-01
    z[3,8,0]  R1974     -2.2587503492832184e-01
    z[3,8,0]  R1975     -1.0576321184635162e-01
    z[3,8,0]  R1976     -2.6120189577341080e-02
    z[3,8,0]  R1977     8.6152262985706329e-02
    z[3,8,0]  R1978     1.7868988215923309e-01
    z[3,8,0]  R1979     2.1687847375869751e-01
    z[3,8,0]  R1980     -7.6703220605850220e-02
    z[3,8,0]  R1981     -5.7236045598983765e-01
    z[3,8,0]  R1982     3.7944954633712769e-01
    z[3,8,0]  R1983     -1.9736465811729431e-01
    z[3,8,0]  R1984     -3.9486771821975708e-01
    z[3,8,0]  R1985     0.0852629616856575
    z[3,8,0]  R1986     -2.9006785154342651e-01
    z[3,8,0]  R1987     1.5264980494976044e-01
    z[3,8,0]  R1988     2.2403240203857422e-01
    z[3,8,0]  R1989     -2.2230571508407593e-01
    z[3,8,0]  R1990     -3.1105026602745056e-01
    z[3,8,0]  R1991     -5.1620435714721680e-01
    z[3,8,0]  R1992     -1.7105893790721893e-01
    z[3,8,0]  R1993     2.1935540437698364e-01
    z[3,8,0]  R1994     1.0663330322131515e-03
    z[3,8,0]  R1995     -3.1086322665214539e-01
    z[3,8,0]  R1996     4.4636088609695435e-01
    z[3,8,0]  R1997     6.9318538904190063e-01
    z[3,8,0]  R1998     8.1855165958404541e-01
    z[3,8,0]  R1999     4.0272515267133713e-02
    z[3,8,0]  R2000     3.4263002872467041e-01
    z[3,8,0]  R2001     -1.5010145306587219e-01
    z[3,8,0]  R2002     -1.5877915918827057e-01
    z[3,8,0]  R2003     -2.8038141131401062e-01
    z[3,8,0]  R2004     2.9783645272254944e-01
    z[3,8,0]  R2005     -3.5361889004707336e-01
    z[3,8,0]  R2006     -2.7545174956321716e-01
    z[3,8,0]  R2007     -3.9055564999580383e-01
    z[3,8,0]  R2008     3.1482365727424622e-01
    z[3,8,0]  R2009     1.7461758852005005e-01
    z[3,8,0]  R2010     -2.4204730987548828e-01
    z[3,8,0]  R2011     -3.5855054855346680e-01
    z[3,8,0]  R2012     -2.6036825776100159e-01
    z[3,8,0]  R2013     2.1546375751495361e-01
    z[3,8,0]  R2014     6.7238390445709229e-02
    z[3,8,0]  R2015     -2.7760851383209229e-01
    z[3,8,0]  R2016     7.6810318231582642e-01
    z[3,8,0]  R2017     9.5003110170364380e-01
    z[3,8,0]  R2018     9.3456918001174927e-01
    z[3,8,1]  R30       -1
    z[3,8,1]  R75       1
    z[3,8,1]  R1867     -1
    z[3,8,1]  R1868     1
    z[3,8,1]  R1879     -3.8943392038345337e-01
    z[3,8,1]  R1880     1.0056421905755997e-01
    z[3,8,1]  R1881     1.5411810576915741e-01
    z[3,8,1]  R1882     -7.9090172052383423e-01
    z[3,8,1]  R1883     -0.0875360444188118
    z[3,8,1]  R1884     -6.2563389539718628e-01
    z[3,8,1]  R1885     -0.704354465007782
    z[3,8,1]  R1886     -7.9132989048957825e-02
    z[3,8,1]  R1887     -6.2296229600906372e-01
    z[3,8,1]  R1888     -6.6563093662261963e-01
    z[3,8,1]  R1889     -4.1182957589626312e-02
    z[3,8,1]  R1890     -3.4564676880836487e-01
    z[3,8,1]  R1891     2.8088864684104919e-01
    z[3,8,1]  R1892     3.0188298225402832e-01
    z[3,8,1]  R1893     6.1274491250514984e-02
    z[3,8,1]  R1894     0.0978856310248375
    z[3,8,1]  R1895     2.0466198027133942e-01
    z[3,8,1]  R1896     6.6788643598556519e-03
    z[3,8,1]  R1897     1.1274852603673935e-01
    z[3,8,1]  R1898     4.3839445710182190e-01
    z[3,8,1]  R1899     3.5533255338668823e-01
    z[3,8,1]  R1900     -6.9836688041687012e-01
    z[3,8,1]  R1901     -3.9601841568946838e-01
    z[3,8,1]  R1902     1.1077233403921127e-01
    z[3,8,1]  R1903     2.0387648046016693e-01
    z[3,8,1]  R1904     -2.1392878890037537e-01
    z[3,8,1]  R1905     3.0866166949272156e-01
    z[3,8,1]  R1906     -1.5111443400382996e-01
    z[3,8,1]  R1907     2.5715095922350883e-02
    z[3,8,1]  R1908     -1.4068578183650970e-01
    z[3,8,1]  R1909     -0.302144318819046
    z[3,8,1]  R1910     3.4736540168523788e-02
    z[3,8,1]  R1911     -1.4574143290519714e-01
    z[3,8,1]  R1912     -2.2250409424304962e-01
    z[3,8,1]  R1913     -4.6310713887214661e-01
    z[3,8,1]  R1914     2.1093061566352844e-01
    z[3,8,1]  R1915     -8.5881382226943970e-01
    z[3,8,1]  R1916     -4.4231769442558289e-01
    z[3,8,1]  R1917     -0.606364369392395
    z[3,8,1]  R1918     -7.1295052766799927e-01
    z[3,8,1]  R1919     7.0980495214462280e-01
    z[3,8,1]  R1920     -4.2589294910430908e-01
    z[3,8,1]  R1921     -1.5035982429981232e-01
    z[3,8,1]  R1922     9.3660390377044678e-01
    z[3,8,1]  R1923     9.3908828496932983e-01
    z[3,8,1]  R1924     8.6301565170288086e-01
    z[3,8,1]  R1925     5.0970077514648438e-01
    z[3,8,1]  R1926     7.0335948467254639e-01
    z[3,8,1]  R1927     2.9809432104229927e-02
    z[3,8,1]  R1928     -9.8309412598609924e-02
    z[3,8,1]  R1929     6.9336611032485962e-01
    z[3,8,1]  R1930     -6.0947406291961670e-01
    z[3,8,1]  R1931     -2.0571936666965485e-01
    z[3,8,1]  R1932     -7.4226832389831543e-01
    z[3,8,1]  R1933     1.8295995891094208e-01
    z[3,8,1]  R1934     6.1455290764570236e-02
    z[3,8,1]  R1935     1.7191922664642334e-01
    z[3,8,1]  R1936     2.5506317615509033e-01
    z[3,8,1]  R1937     9.5106415450572968e-02
    z[3,8,1]  R1938     -8.0855406820774078e-02
    z[3,8,1]  R1939     -3.3204442262649536e-01
    z[3,8,1]  R1940     -2.5690299272537231e-01
    z[3,8,1]  R1941     -4.6997055411338806e-01
    z[3,8,1]  R1942     -4.6174040436744690e-01
    z[3,8,1]  R1943     -4.8508054018020630e-01
    z[3,8,1]  R1944     -0.602096676826477
    z[3,8,1]  R1945     1.2655800208449364e-02
    z[3,8,1]  R1946     -1.6722084954380989e-02
    z[3,8,1]  R1947     -1.5665067732334137e-01
    z[3,8,1]  R1948     2.9285481572151184e-01
    z[3,8,1]  R1949     7.0536142587661743e-01
    z[3,8,1]  R1950     3.4541028738021851e-01
    z[3,8,1]  R1951     0.516209065914154
    z[3,8,1]  R1952     4.8548287153244019e-01
    z[3,8,1]  R1953     3.3199149370193481e-01
    z[3,8,1]  R1954     5.1212704181671143e-01
    z[3,8,1]  R1955     5.9532564878463745e-01
    z[3,8,1]  R1956     6.3990515470504761e-01
    z[3,8,1]  R1957     4.8651802539825439e-01
    z[3,8,1]  R1958     4.3544858694076538e-01
    z[3,8,1]  R1959     -3.4603667259216309e-01
    z[3,8,1]  R1960     0.720102846622467
    z[3,8,1]  R1961     -4.8885107971727848e-03
    z[3,8,1]  R1962     6.4501903951168060e-02
    z[3,8,1]  R1963     -2.0838995277881622e-01
    z[3,8,1]  R1964     -2.4802862107753754e-01
    z[3,8,1]  R1965     -7.4762886762619019e-01
    z[3,8,1]  R1966     4.9201175570487976e-02
    z[3,8,1]  R1967     3.2671761512756348e-01
    z[3,8,1]  R1968     -1.0198544710874557e-01
    z[3,8,1]  R1969     -2.8616625815629959e-02
    z[3,8,1]  R1970     3.1933152675628662e-01
    z[3,8,1]  R1971     6.5530651807785034e-01
    z[3,8,1]  R1972     -7.6302891969680786e-01
    z[3,8,1]  R1973     -0.713287353515625
    z[3,8,1]  R1974     3.4502479434013367e-01
    z[3,8,1]  R1975     -1.5632529556751251e-01
    z[3,8,1]  R1976     4.4123733043670654e-01
    z[3,8,1]  R1977     -4.0507555007934570e-01
    z[3,8,1]  R1978     -7.1970999240875244e-02
    z[3,8,1]  R1979     -1.0386711359024048e-01
    z[3,8,1]  R1980     -0.826941728591919
    z[3,8,1]  R1981     5.5064874887466431e-01
    z[3,8,1]  R1982     5.6682562828063965e-01
    z[3,8,1]  R1983     -0.637488067150116
    z[3,8,1]  R1984     3.1302982568740845e-01
    z[3,8,1]  R1985     -4.3343013525009155e-01
    z[3,8,1]  R1986     -5.8169806003570557e-01
    z[3,8,1]  R1987     8.8284105062484741e-01
    z[3,8,1]  R1988     7.3823785781860352e-01
    z[3,8,1]  R1989     -7.5214987993240356e-01
    z[3,8,1]  R1990     4.9054896831512451e-01
    z[3,8,1]  R1991     4.3570250272750854e-01
    z[3,8,1]  R1992     9.2652714252471924e-01
    z[3,8,1]  R1993     8.0565035343170166e-01
    z[3,8,1]  R1994     -5.6556481122970581e-01
    z[3,8,1]  R1995     4.0573990345001221e-01
    z[3,8,1]  R1996     6.1703330278396606e-01
    z[3,8,1]  R1997     -1.1697446554899216e-01
    z[3,8,1]  R1998     -1.9792547821998596e-01
    z[3,8,1]  R1999     -1.3860097527503967e-01
    z[3,8,1]  R2000     0.715706467628479
    z[3,8,1]  R2001     6.6889148950576782e-01
    z[3,8,1]  R2002     2.9724597930908203e-01
    z[3,8,1]  R2003     -6.8008792400360107e-01
    z[3,8,1]  R2004     8.8679903745651245e-01
    z[3,8,1]  R2005     -7.1929872035980225e-01
    z[3,8,1]  R2006     -3.0911669135093689e-01
    z[3,8,1]  R2007     3.7147161364555359e-01
    z[3,8,1]  R2008     0.74797123670578
    z[3,8,1]  R2009     7.5768578052520752e-01
    z[3,8,1]  R2010     -3.3206534385681152e-01
    z[3,8,1]  R2011     -7.1302127838134766e-01
    z[3,8,1]  R2012     6.7258435487747192e-01
    z[3,8,1]  R2013     7.0505040884017944e-01
    z[3,8,1]  R2014     -6.5480205230414867e-03
    z[3,8,1]  R2015     -7.0366328954696655e-01
    z[3,8,1]  R2016     -3.0529114603996277e-01
    z[3,8,1]  R2017     1.3688798062503338e-02
    z[3,8,1]  R2018     4.1255757212638855e-02
    z[3,8,2]  R31       -1
    z[3,8,2]  R76       1
    z[3,8,2]  R1869     -1
    z[3,8,2]  R1870     1
    z[3,8,2]  R1879     -1.3613632321357727e-01
    z[3,8,2]  R1880     -3.2119369506835938e-01
    z[3,8,2]  R1881     0.11175537109375
    z[3,8,2]  R1882     3.1654998660087585e-02
    z[3,8,2]  R1883     8.4770750999450684e-01
    z[3,8,2]  R1884     -1.4828373491764069e-01
    z[3,8,2]  R1885     2.9359790682792664e-01
    z[3,8,2]  R1886     0.686779260635376
    z[3,8,2]  R1887     -3.4933474659919739e-01
    z[3,8,2]  R1888     -1.5206056833267212e-01
    z[3,8,2]  R1889     1.1364550888538361e-01
    z[3,8,2]  R1890     3.4251266717910767e-01
    z[3,8,2]  R1891     8.4152139723300934e-02
    z[3,8,2]  R1892     -7.0116829872131348e-01
    z[3,8,2]  R1893     0.310958594083786
    z[3,8,2]  R1894     -4.8581293225288391e-01
    z[3,8,2]  R1895     1.5351407229900360e-01
    z[3,8,2]  R1896     -2.2517786920070648e-01
    z[3,8,2]  R1897     2.1858850494027138e-02
    z[3,8,2]  R1898     -4.2397168278694153e-01
    z[3,8,2]  R1899     1.2479174137115479e-01
    z[3,8,2]  R1900     4.9236118793487549e-01
    z[3,8,2]  R1901     7.7350640296936035e-01
    z[3,8,2]  R1902     4.2019265890121460e-01
    z[3,8,2]  R1903     3.5428783297538757e-01
    z[3,8,2]  R1904     3.6612513661384583e-01
    z[3,8,2]  R1905     1.0885686427354813e-01
    z[3,8,2]  R1906     5.1020783185958862e-01
    z[3,8,2]  R1907     6.2840634584426880e-01
    z[3,8,2]  R1908     9.5704257488250732e-02
    z[3,8,2]  R1909     4.8155072331428528e-01
    z[3,8,2]  R1910     0.616873025894165
    z[3,8,2]  R1911     4.6412819623947144e-01
    z[3,8,2]  R1912     1.1298055946826935e-01
    z[3,8,2]  R1913     4.5124284923076630e-02
    z[3,8,2]  R1914     6.3735512085258961e-03
    z[3,8,2]  R1915     -2.0513303577899933e-01
    z[3,8,2]  R1916     -1.2549702823162079e-01
    z[3,8,2]  R1917     -1.3414016366004944e-01
    z[3,8,2]  R1918     2.1963019669055939e-01
    z[3,8,2]  R1919     -4.5000827312469482e-01
    z[3,8,2]  R1920     8.7170645594596863e-02
    z[3,8,2]  R1921     2.8488731384277344e-01
    z[3,8,2]  R1922     2.7279371395707130e-02
    z[3,8,2]  R1923     -1.3675086200237274e-01
    z[3,8,2]  R1924     3.0031827092170715e-01
    z[3,8,2]  R1925     -6.9078212976455688e-01
    z[3,8,2]  R1926     -5.2651494741439819e-01
    z[3,8,2]  R1927     2.8083970770239830e-02
    z[3,8,2]  R1928     2.4156154692173004e-01
    z[3,8,2]  R1929     -5.5537432432174683e-01
    z[3,8,2]  R1930     2.1817199885845184e-01
    z[3,8,2]  R1931     2.2642841935157776e-01
    z[3,8,2]  R1932     -1.9141036272048950e-01
    z[3,8,2]  R1933     1.1570196598768234e-01
    z[3,8,2]  R1934     -0.0828382596373558
    z[3,8,2]  R1935     2.0725773274898529e-01
    z[3,8,2]  R1936     8.0018816515803337e-03
    z[3,8,2]  R1937     -3.0644190311431885e-01
    z[3,8,2]  R1938     -1.1769544333219528e-01
    z[3,8,2]  R1939     4.2972904443740845e-01
    z[3,8,2]  R1940     2.9859790205955505e-01
    z[3,8,2]  R1941     -1.4298494160175323e-01
    z[3,8,2]  R1942     1.9827237725257874e-01
    z[3,8,2]  R1943     2.4667717516422272e-01
    z[3,8,2]  R1944     6.6764909029006958e-01
    z[3,8,2]  R1945     0.749691903591156
    z[3,8,2]  R1946     0.794209361076355
    z[3,8,2]  R1947     7.4640804529190063e-01
    z[3,8,2]  R1948     -5.7840985059738159e-01
    z[3,8,2]  R1949     -4.9356621503829956e-01
    z[3,8,2]  R1950     -5.4023534059524536e-01
    z[3,8,2]  R1951     -6.4635413885116577e-01
    z[3,8,2]  R1952     -9.2058137059211731e-02
    z[3,8,2]  R1953     -7.9390835762023926e-01
    z[3,8,2]  R1954     -4.5745104551315308e-01
    z[3,8,2]  R1955     -3.7056869268417358e-01
    z[3,8,2]  R1956     -4.0922570228576660e-01
    z[3,8,2]  R1957     -4.8002764582633972e-01
    z[3,8,2]  R1958     -6.8645268678665161e-01
    z[3,8,2]  R1959     4.0704756975173950e-01
    z[3,8,2]  R1960     -3.5753306746482849e-01
    z[3,8,2]  R1961     -3.2452747225761414e-01
    z[3,8,2]  R1962     -1.6314937174320221e-01
    z[3,8,2]  R1963     1.8298590555787086e-02
    z[3,8,2]  R1964     -2.8553183656185865e-03
    z[3,8,2]  R1965     -4.5324909687042236e-01
    z[3,8,2]  R1966     7.4352012015879154e-03
    z[3,8,2]  R1967     1.7782163619995117e-01
    z[3,8,2]  R1968     9.8059467971324921e-02
    z[3,8,2]  R1969     3.7972810864448547e-01
    z[3,8,2]  R1970     -6.2939512729644775e-01
    z[3,8,2]  R1971     -0.642380952835083
    z[3,8,2]  R1972     -6.9627188146114349e-02
    z[3,8,2]  R1973     -1.6084440052509308e-01
    z[3,8,2]  R1974     -5.4775995016098022e-01
    z[3,8,2]  R1975     -4.4738808274269104e-01
    z[3,8,2]  R1976     -5.5230081081390381e-01
    z[3,8,2]  R1977     4.3478560447692871e-01
    z[3,8,2]  R1978     -5.3456395864486694e-01
    z[3,8,2]  R1979     4.4696268439292908e-01
    z[3,8,2]  R1980     -2.2541087865829468e-01
    z[3,8,2]  R1981     -4.3915849924087524e-01
    z[3,8,2]  R1982     -6.5261960029602051e-01
    z[3,8,2]  R1983     -1.2304015457630157e-01
    z[3,8,2]  R1984     -6.2947779893875122e-01
    z[3,8,2]  R1985     -3.2969605177640915e-02
    z[3,8,2]  R1986     -3.2634842395782471e-01
    z[3,8,2]  R1987     2.6758614182472229e-01
    z[3,8,2]  R1988     4.3983215093612671e-01
    z[3,8,2]  R1989     -9.5280326902866364e-02
    z[3,8,2]  R1990     -0.634859025478363
    z[3,8,2]  R1991     -6.4517909288406372e-01
    z[3,8,2]  R1992     0.0360434390604496
    z[3,8,2]  R1993     4.5218861103057861e-01
    z[3,8,2]  R1994     -1.2078131549060345e-02
    z[3,8,2]  R1995     1.2855865061283112e-01
    z[3,8,2]  R1996     5.5934345722198486e-01
    z[3,8,2]  R1997     -2.0315490663051605e-01
    z[3,8,2]  R1998     -1.4706824719905853e-01
    z[3,8,2]  R1999     1.7670039832592010e-01
    z[3,8,2]  R2000     -4.8426979780197144e-01
    z[3,8,2]  R2001     -2.8648141026496887e-01
    z[3,8,2]  R2002     -6.8398404121398926e-01
    z[3,8,2]  R2003     -5.9787672013044357e-02
    z[3,8,2]  R2004     -1.4526379108428955e-01
    z[3,8,2]  R2005     3.9475105702877045e-02
    z[3,8,2]  R2006     2.5788527727127075e-01
    z[3,8,2]  R2007     -4.6022129058837891e-01
    z[3,8,2]  R2008     5.2115124464035034e-01
    z[3,8,2]  R2009     -2.4724586308002472e-01
    z[3,8,2]  R2010     3.8947898149490356e-01
    z[3,8,2]  R2011     -1.5772011876106262e-01
    z[3,8,2]  R2012     -0.574109673500061
    z[3,8,2]  R2013     -4.5492088794708252e-01
    z[3,8,2]  R2014     4.2822387814521790e-01
    z[3,8,2]  R2015     -2.8702369332313538e-01
    z[3,8,2]  R2016     -0.175094336271286
    z[3,8,2]  R2017     6.2799490988254547e-02
    z[3,8,2]  R2018     2.5760421156883240e-01
    z[3,8,3]  R32       -1
    z[3,8,3]  R77       1
    z[3,8,3]  R1871     -1
    z[3,8,3]  R1872     1
    z[3,8,3]  R1879     4.5321959257125854e-01
    z[3,8,3]  R1880     4.4695851206779480e-01
    z[3,8,3]  R1881     9.3673390150070190e-01
    z[3,8,3]  R1882     1.9504196941852570e-01
    z[3,8,3]  R1883     -2.9698863625526428e-01
    z[3,8,3]  R1884     -0.0312623456120491
    z[3,8,3]  R1885     -2.2925306856632233e-01
    z[3,8,3]  R1886     -4.2882928252220154e-01
    z[3,8,3]  R1887     6.9269701838493347e-02
    z[3,8,3]  R1888     3.7578254938125610e-01
    z[3,8,3]  R1889     -8.1052398681640625e-01
    z[3,8,3]  R1890     -5.8123838901519775e-01
    z[3,8,3]  R1891     -0.560954213142395
    z[3,8,3]  R1892     1.1045350879430771e-01
    z[3,8,3]  R1893     -3.7698951363563538e-01
    z[3,8,3]  R1894     4.2962488532066345e-01
    z[3,8,3]  R1895     -4.0225467085838318e-01
    z[3,8,3]  R1896     -5.8202630281448364e-01
    z[3,8,3]  R1897     -4.1785049438476562e-01
    z[3,8,3]  R1898     -3.0952779576182365e-02
    z[3,8,3]  R1899     2.3720730841159821e-01
    z[3,8,3]  R1900     6.9490201771259308e-02
    z[3,8,3]  R1901     1.2240605801343918e-01
    z[3,8,3]  R1902     -6.0070788860321045e-01
    z[3,8,3]  R1903     -0.522066593170166
    z[3,8,3]  R1904     3.8913151621818542e-01
    z[3,8,3]  R1905     3.6415389180183411e-01
    z[3,8,3]  R1906     -1.9415524601936340e-01
    z[3,8,3]  R1907     -3.3607918024063110e-01
    z[3,8,3]  R1908     -3.9141789078712463e-01
    z[3,8,3]  R1909     -8.4982894361019135e-02
    z[3,8,3]  R1910     -5.5730760097503662e-01
    z[3,8,3]  R1911     -9.1690264642238617e-02
    z[3,8,3]  R1912     -7.2996979951858521e-01
    z[3,8,3]  R1913     -5.5128979682922363e-01
    z[3,8,3]  R1914     -0.838477373123169
    z[3,8,3]  R1915     -2.7604243159294128e-01
    z[3,8,3]  R1916     6.3116061687469482e-01
    z[3,8,3]  R1917     -4.3238624930381775e-02
    z[3,8,3]  R1918     3.6420649290084839e-01
    z[3,8,3]  R1919     -3.9759587496519089e-02
    z[3,8,3]  R1920     -2.7081990242004395e-01
    z[3,8,3]  R1921     3.9089463651180267e-02
    z[3,8,3]  R1922     -1.4939683675765991e-01
    z[3,8,3]  R1923     1.0562177002429962e-01
    z[3,8,3]  R1924     4.4475674629211426e-02
    z[3,8,3]  R1925     2.0891658961772919e-01
    z[3,8,3]  R1926     0.14479960501194
    z[3,8,3]  R1927     -2.2908157110214233e-01
    z[3,8,3]  R1928     -8.4188235923647881e-03
    z[3,8,3]  R1929     3.7611511349678040e-01
    z[3,8,3]  R1930     -2.1606069058179855e-02
    z[3,8,3]  R1931     -2.7403208613395691e-01
    z[3,8,3]  R1932     1.7212149500846863e-01
    z[3,8,3]  R1933     4.7052096575498581e-02
    z[3,8,3]  R1934     -3.6566668748855591e-01
    z[3,8,3]  R1935     -4.7412046790122986e-01
    z[3,8,3]  R1936     -4.2067438364028931e-01
    z[3,8,3]  R1937     -4.8991143703460693e-01
    z[3,8,3]  R1938     -2.5718429684638977e-01
    z[3,8,3]  R1939     7.0460617542266846e-01
    z[3,8,3]  R1940     6.3385230302810669e-01
    z[3,8,3]  R1941     5.1752287149429321e-01
    z[3,8,3]  R1942     0.691716730594635
    z[3,8,3]  R1943     -2.8274807333946228e-01
    z[3,8,3]  R1944     2.2858205437660217e-01
    z[3,8,3]  R1945     -9.3946717679500580e-02
    z[3,8,3]  R1946     -9.8623782396316528e-02
    z[3,8,3]  R1947     1.6305133700370789e-02
    z[3,8,3]  R1948     2.3331997916102409e-02
    z[3,8,3]  R1949     6.5564163029193878e-02
    z[3,8,3]  R1950     5.2176183462142944e-01
    z[3,8,3]  R1951     4.3301886320114136e-01
    z[3,8,3]  R1952     -7.2795635461807251e-01
    z[3,8,3]  R1953     1.0284223407506943e-01
    z[3,8,3]  R1954     5.7892650365829468e-01
    z[3,8,3]  R1955     1.1072061210870743e-01
    z[3,8,3]  R1956     4.8190414905548096e-01
    z[3,8,3]  R1957     5.4360177367925644e-02
    z[3,8,3]  R1958     -6.8826384842395782e-02
    z[3,8,3]  R1959     -8.1118786334991455e-01
    z[3,8,3]  R1960     0.0860656350851059
    z[3,8,3]  R1961     -0.528769314289093
    z[3,8,3]  R1962     -4.9167567491531372e-01
    z[3,8,3]  R1963     -6.5119296312332153e-01
    z[3,8,3]  R1964     -7.0396721363067627e-01
    z[3,8,3]  R1965     -3.1340688467025757e-01
    z[3,8,3]  R1966     -6.6030627489089966e-01
    z[3,8,3]  R1967     -4.8219156265258789e-01
    z[3,8,3]  R1968     -5.1669472455978394e-01
    z[3,8,3]  R1969     -0.783909022808075
    z[3,8,3]  R1970     6.4680272340774536e-01
    z[3,8,3]  R1971     1.1100284755229950e-02
    z[3,8,3]  R1972     -1.9375425577163696e-01
    z[3,8,3]  R1973     4.3256103992462158e-02
    z[3,8,3]  R1974     6.3257914781570435e-01
    z[3,8,3]  R1975     -4.0427660942077637e-01
    z[3,8,3]  R1976     2.4229690432548523e-01
    z[3,8,3]  R1977     3.9681177586317062e-02
    z[3,8,3]  R1978     -7.1501910686492920e-01
    z[3,8,3]  R1979     -7.5669950246810913e-01
    z[3,8,3]  R1980     4.7563002444803715e-03
    z[3,8,3]  R1981     8.6002998054027557e-02
    z[3,8,3]  R1982     -1.5803065896034241e-01
    z[3,8,3]  R1983     -5.2056068181991577e-01
    z[3,8,3]  R1984     -8.8108986616134644e-02
    z[3,8,3]  R1985     -1.6161488369107246e-02
    z[3,8,3]  R1986     -3.6090412735939026e-01
    z[3,8,3]  R1987     2.4224698543548584e-01
    z[3,8,3]  R1988     2.5279900431632996e-01
    z[3,8,3]  R1989     3.5884881019592285e-01
    z[3,8,3]  R1990     1.4230453968048096e-01
    z[3,8,3]  R1991     -1.0548471659421921e-01
    z[3,8,3]  R1992     9.3076996505260468e-02
    z[3,8,3]  R1993     1.9540201127529144e-01
    z[3,8,3]  R1994     -3.2591944932937622e-01
    z[3,8,3]  R1995     1.2794514000415802e-01
    z[3,8,3]  R1996     -3.7251997739076614e-02
    z[3,8,3]  R1997     -2.0874477922916412e-01
    z[3,8,3]  R1998     -4.8169005662202835e-02
    z[3,8,3]  R1999     -5.8753520250320435e-01
    z[3,8,3]  R2000     8.5866108536720276e-02
    z[3,8,3]  R2001     3.1356829404830933e-01
    z[3,8,3]  R2002     3.1444475054740906e-01
    z[3,8,3]  R2003     -4.0305379033088684e-01
    z[3,8,3]  R2004     1.4074213802814484e-01
    z[3,8,3]  R2005     -0.36433145403862
    z[3,8,3]  R2006     -1.5327471494674683e-01
    z[3,8,3]  R2007     6.5086834132671356e-02
    z[3,8,3]  R2008     -1.3650661706924438e-01
    z[3,8,3]  R2009     5.3470355272293091e-01
    z[3,8,3]  R2010     -1.8591515719890594e-01
    z[3,8,3]  R2011     -3.2681983709335327e-01
    z[3,8,3]  R2012     -1.1359921097755432e-01
    z[3,8,3]  R2013     1.7740766704082489e-01
    z[3,8,3]  R2014     -2.6093408465385437e-01
    z[3,8,3]  R2015     -2.4626623094081879e-01
    z[3,8,3]  R2016     1.6839888691902161e-01
    z[3,8,3]  R2017     1.1186099052429199e-01
    z[3,8,3]  R2018     2.2514252364635468e-01
    z[3,8,4]  R33       -1
    z[3,8,4]  R78       1
    z[3,8,4]  R1873     -1
    z[3,8,4]  R1874     1
    z[3,8,4]  R1879     3.4688645601272583e-01
    z[3,8,4]  R1880     5.9636777639389038e-01
    z[3,8,4]  R1881     1.8472562730312347e-01
    z[3,8,4]  R1882     -5.8635283261537552e-02
    z[3,8,4]  R1883     -2.3713652789592743e-01
    z[3,8,4]  R1884     4.5625463128089905e-01
    z[3,8,4]  R1885     1.0159126482903957e-02
    z[3,8,4]  R1886     1.3070702552795410e-01
    z[3,8,4]  R1887     -1.1682728677988052e-01
    z[3,8,4]  R1888     -4.6683631837368011e-02
    z[3,8,4]  R1889     3.4998500347137451e-01
    z[3,8,4]  R1890     1.3148643076419830e-01
    z[3,8,4]  R1891     5.9449046850204468e-01
    z[3,8,4]  R1892     -4.5888105034828186e-01
    z[3,8,4]  R1893     3.9809507131576538e-01
    z[3,8,4]  R1894     -6.9887173175811768e-01
    z[3,8,4]  R1895     3.2974988222122192e-01
    z[3,8,4]  R1896     4.0062639117240906e-01
    z[3,8,4]  R1897     1.9780324399471283e-01
    z[3,8,4]  R1898     -5.7936644554138184e-01
    z[3,8,4]  R1899     -0.341208279132843
    z[3,8,4]  R1900     -2.5814184546470642e-01
    z[3,8,4]  R1901     2.8583295643329620e-03
    z[3,8,4]  R1902     5.9135907888412476e-01
    z[3,8,4]  R1903     2.5743296742439270e-01
    z[3,8,4]  R1904     -5.7720959186553955e-01
    z[3,8,4]  R1905     -5.6938838958740234e-01
    z[3,8,4]  R1906     6.3056260347366333e-01
    z[3,8,4]  R1907     0.110362209379673
    z[3,8,4]  R1908     6.8434321880340576e-01
    z[3,8,4]  R1909     -1.5113914012908936e-01
    z[3,8,4]  R1910     2.0056955516338348e-01
    z[3,8,4]  R1911     4.2378431558609009e-01
    z[3,8,4]  R1912     5.9284854680299759e-02
    z[3,8,4]  R1913     2.3376183211803436e-01
    z[3,8,4]  R1914     1.8640869855880737e-01
    z[3,8,4]  R1915     5.0026741810142994e-03
    z[3,8,4]  R1916     -0.529833972454071
    z[3,8,4]  R1917     -2.1755275130271912e-01
    z[3,8,4]  R1918     3.9323933422565460e-02
    z[3,8,4]  R1919     -2.9293003678321838e-01
    z[3,8,4]  R1920     1.9246637821197510e-01
    z[3,8,4]  R1921     4.1980087757110596e-01
    z[3,8,4]  R1922     -0.105362668633461
    z[3,8,4]  R1923     -9.4741076231002808e-02
    z[3,8,4]  R1924     2.9477930068969727e-01
    z[3,8,4]  R1925     6.4331911504268646e-02
    z[3,8,4]  R1926     -3.6906756460666656e-02
    z[3,8,4]  R1927     -5.6205880641937256e-01
    z[3,8,4]  R1928     -5.7529205083847046e-01
    z[3,8,4]  R1929     -1.3045415282249451e-01
    z[3,8,4]  R1930     -4.6280416846275330e-01
    z[3,8,4]  R1931     6.5524756908416748e-01
    z[3,8,4]  R1932     1.6345609724521637e-01
    z[3,8,4]  R1933     -1.2294919788837433e-01
    z[3,8,4]  R1934     -8.3895868062973022e-01
    z[3,8,4]  R1935     -8.0667078495025635e-01
    z[3,8,4]  R1936     -7.0341515541076660e-01
    z[3,8,4]  R1937     -6.1113911867141724e-01
    z[3,8,4]  R1938     -6.0859465599060059e-01
    z[3,8,4]  R1939     6.0182854533195496e-02
    z[3,8,4]  R1940     0.334433376789093
    z[3,8,4]  R1941     3.5058698058128357e-01
    z[3,8,4]  R1942     -1.5981499850749969e-01
    z[3,8,4]  R1943     4.5273166894912720e-01
    z[3,8,4]  R1944     7.1975603699684143e-02
    z[3,8,4]  R1945     2.0932009816169739e-01
    z[3,8,4]  R1946     4.3899127840995789e-01
    z[3,8,4]  R1947     4.7448903322219849e-01
    z[3,8,4]  R1948     1.0534477978944778e-01
    z[3,8,4]  R1949     -2.8116098046302795e-01
    z[3,8,4]  R1950     -3.7564691901206970e-01
    z[3,8,4]  R1951     -2.3733133077621460e-01
    z[3,8,4]  R1952     4.0176185965538025e-01
    z[3,8,4]  R1953     -3.4186564385890961e-02
    z[3,8,4]  R1954     -2.3181053996086121e-01
    z[3,8,4]  R1955     -1.7737166583538055e-01
    z[3,8,4]  R1956     1.1563534289598465e-01
    z[3,8,4]  R1957     -0.551505982875824
    z[3,8,4]  R1958     3.9585113525390625e-01
    z[3,8,4]  R1959     1.0906083509325981e-02
    z[3,8,4]  R1960     -3.6826786398887634e-01
    z[3,8,4]  R1961     -6.5377938747406006e-01
    z[3,8,4]  R1962     -7.1659630537033081e-01
    z[3,8,4]  R1963     -5.6170392036437988e-01
    z[3,8,4]  R1964     -6.2472081184387207e-01
    z[3,8,4]  R1965     -0.252750426530838
    z[3,8,4]  R1966     -6.1852902173995972e-01
    z[3,8,4]  R1967     -7.0063984394073486e-01
    z[3,8,4]  R1968     -6.9972926378250122e-01
    z[3,8,4]  R1969     2.1617035567760468e-01
    z[3,8,4]  R1970     -1.0089616477489471e-01
    z[3,8,4]  R1971     3.2417541742324829e-01
    z[3,8,4]  R1972     -2.3014199733734131e-01
    z[3,8,4]  R1973     -3.6255308985710144e-01
    z[3,8,4]  R1974     1.5050463378429413e-01
    z[3,8,4]  R1975     2.3566101491451263e-01
    z[3,8,4]  R1976     2.0459690690040588e-01
    z[3,8,4]  R1977     -4.9369612336158752e-01
    z[3,8,4]  R1978     1.3406861573457718e-02
    z[3,8,4]  R1979     7.9505115747451782e-02
    z[3,8,4]  R1980     -4.9428895115852356e-01
    z[3,8,4]  R1981     -0.0761650800704956
    z[3,8,4]  R1982     -2.6672041416168213e-01
    z[3,8,4]  R1983     3.6464941501617432e-01
    z[3,8,4]  R1984     -2.1595989167690277e-01
    z[3,8,4]  R1985     -6.0959827899932861e-01
    z[3,8,4]  R1986     3.5240563750267029e-01
    z[3,8,4]  R1987     1.9147807359695435e-01
    z[3,8,4]  R1988     -9.4949059188365936e-02
    z[3,8,4]  R1989     -4.2940896749496460e-01
    z[3,8,4]  R1990     2.9315361380577087e-01
    z[3,8,4]  R1991     -0.0841350331902504
    z[3,8,4]  R1992     1.3752470910549164e-01
    z[3,8,4]  R1993     1.0821728408336639e-01
    z[3,8,4]  R1994     -3.8458526134490967e-02
    z[3,8,4]  R1995     7.3545169830322266e-01
    z[3,8,4]  R1996     -2.6146358251571655e-01
    z[3,8,4]  R1997     2.3412831127643585e-02
    z[3,8,4]  R1998     4.8646613955497742e-02
    z[3,8,4]  R1999     1.9688895344734192e-01
    z[3,8,4]  R2000     -2.6365187764167786e-01
    z[3,8,4]  R2001     1.6216847300529480e-01
    z[3,8,4]  R2002     1.0183297097682953e-01
    z[3,8,4]  R2003     3.6613830924034119e-01
    z[3,8,4]  R2004     2.5276171043515205e-02
    z[3,8,4]  R2005     3.9034810662269592e-01
    z[3,8,4]  R2006     -5.8465617895126343e-01
    z[3,8,4]  R2007     -5.4090458154678345e-01
    z[3,8,4]  R2008     -2.1702301502227783e-01
    z[3,8,4]  R2009     -2.1139633655548096e-01
    z[3,8,4]  R2010     -5.1421147584915161e-01
    z[3,8,4]  R2011     3.8064935803413391e-01
    z[3,8,4]  R2012     2.8179755806922913e-01
    z[3,8,4]  R2013     1.6003543511033058e-02
    z[3,8,4]  R2014     -2.0782912150025368e-02
    z[3,8,4]  R2015     2.2558422386646271e-01
    z[3,8,4]  R2016     -1.8514131009578705e-01
    z[3,8,4]  R2017     2.2753329575061798e-01
    z[3,8,4]  R2018     5.2067141979932785e-02
    z[3,8,5]  R34       -1
    z[3,8,5]  R79       1
    z[3,8,5]  R1875     -1
    z[3,8,5]  R1876     1
    z[3,8,5]  R1879     -0.553044319152832
    z[3,8,5]  R1880     -4.2993504554033279e-02
    z[3,8,5]  R1881     1.1749506741762161e-01
    z[3,8,5]  R1882     1.4075703918933868e-01
    z[3,8,5]  R1883     3.2285955548286438e-01
    z[3,8,5]  R1884     7.0158019661903381e-02
    z[3,8,5]  R1885     -1.0275598615407944e-01
    z[3,8,5]  R1886     0.0361696258187294
    z[3,8,5]  R1887     -3.3468861132860184e-02
    z[3,8,5]  R1888     1.3391450047492981e-01
    z[3,8,5]  R1889     2.3491376638412476e-01
    z[3,8,5]  R1890     5.3270930051803589e-01
    z[3,8,5]  R1891     4.1350486874580383e-01
    z[3,8,5]  R1892     -4.1556110978126526e-01
    z[3,8,5]  R1893     6.7152678966522217e-01
    z[3,8,5]  R1894     -0.263075053691864
    z[3,8,5]  R1895     5.5658805370330811e-01
    z[3,8,5]  R1896     5.5850416421890259e-01
    z[3,8,5]  R1897     5.6426358222961426e-01
    z[3,8,5]  R1898     -3.5225117206573486e-01
    z[3,8,5]  R1899     -5.2893179655075073e-01
    z[3,8,5]  R1900     1.7745985090732574e-01
    z[3,8,5]  R1901     3.4801909327507019e-01
    z[3,8,5]  R1902     2.7866625785827637e-01
    z[3,8,5]  R1903     4.0741279721260071e-01
    z[3,8,5]  R1904     2.2728929296135902e-02
    z[3,8,5]  R1905     -2.8804320096969604e-01
    z[3,8,5]  R1906     5.1546716690063477e-01
    z[3,8,5]  R1907     6.7101502418518066e-01
    z[3,8,5]  R1908     5.8186775445938110e-01
    z[3,8,5]  R1909     -1.0468350723385811e-02
    z[3,8,5]  R1910     5.1003140211105347e-01
    z[3,8,5]  R1911     6.9440108537673950e-01
    z[3,8,5]  R1912     5.5458873510360718e-01
    z[3,8,5]  R1913     0.413343220949173
    z[3,8,5]  R1914     2.9687958955764771e-01
    z[3,8,5]  R1915     -2.5644791126251221e-01
    z[3,8,5]  R1916     -6.2193788588047028e-02
    z[3,8,5]  R1917     -2.6785546541213989e-01
    z[3,8,5]  R1918     3.3473879098892212e-01
    z[3,8,5]  R1919     -4.3114152550697327e-01
    z[3,8,5]  R1920     8.2911419868469238e-01
    z[3,8,5]  R1921     2.9068300127983093e-01
    z[3,8,5]  R1922     2.2954536974430084e-01
    z[3,8,5]  R1923     2.1932075917720795e-01
    z[3,8,5]  R1924     2.2315025329589844e-01
    z[3,8,5]  R1925     2.0577101409435272e-01
    z[3,8,5]  R1926     3.7524858117103577e-01
    z[3,8,5]  R1927     5.0734555721282959e-01
    z[3,8,5]  R1928     4.7492590546607971e-01
    z[3,8,5]  R1929     -2.1041874587535858e-01
    z[3,8,5]  R1930     -2.5743770599365234e-01
    z[3,8,5]  R1931     1.7963384091854095e-01
    z[3,8,5]  R1932     2.0145660638809204e-01
    z[3,8,5]  R1933     -7.7882564067840576e-01
    z[3,8,5]  R1934     3.7007558345794678e-01
    z[3,8,5]  R1935     1.8400555849075317e-01
    z[3,8,5]  R1936     3.5417270660400391e-01
    z[3,8,5]  R1937     4.2507287859916687e-01
    z[3,8,5]  R1938     6.5993052721023560e-01
    z[3,8,5]  R1939     -4.0111333131790161e-02
    z[3,8,5]  R1940     -2.9458436369895935e-01
    z[3,8,5]  R1941     -1.7900609970092773e-01
    z[3,8,5]  R1942     -2.3825907707214355e-01
    z[3,8,5]  R1943     1.9674451649188995e-01
    z[3,8,5]  R1944     -1.5321678481996059e-02
    z[3,8,5]  R1945     1.6504010185599327e-02
    z[3,8,5]  R1946     -5.1086336374282837e-02
    z[3,8,5]  R1947     -2.1501930430531502e-02
    z[3,8,5]  R1948     -2.1900095045566559e-01
    z[3,8,5]  R1949     -3.8801664113998413e-01
    z[3,8,5]  R1950     2.5432538986206055e-01
    z[3,8,5]  R1951     7.7942825853824615e-02
    z[3,8,5]  R1952     4.9140501767396927e-02
    z[3,8,5]  R1953     7.6111115515232086e-02
    z[3,8,5]  R1954     2.5701296329498291e-01
    z[3,8,5]  R1955     -8.5745364427566528e-02
    z[3,8,5]  R1956     -1.9198076426982880e-01
    z[3,8,5]  R1957     -9.8238639533519745e-02
    z[3,8,5]  R1958     -1.8779900670051575e-01
    z[3,8,5]  R1959     9.1455176472663879e-02
    z[3,8,5]  R1960     5.8820914477109909e-02
    z[3,8,5]  R1961     3.6578190326690674e-01
    z[3,8,5]  R1962     3.0248314142227173e-01
    z[3,8,5]  R1963     3.5836723446846008e-01
    z[3,8,5]  R1964     2.0174258947372437e-01
    z[3,8,5]  R1965     2.4466985464096069e-01
    z[3,8,5]  R1966     1.2938182055950165e-01
    z[3,8,5]  R1967     0.203104168176651
    z[3,8,5]  R1968     1.5726454555988312e-01
    z[3,8,5]  R1969     2.4988044798374176e-01
    z[3,8,5]  R1970     -1.2344833463430405e-01
    z[3,8,5]  R1971     1.9207081198692322e-01
    z[3,8,5]  R1972     1.0046100616455078e-01
    z[3,8,5]  R1973     -9.2327609658241272e-02
    z[3,8,5]  R1974     -1.4799048006534576e-01
    z[3,8,5]  R1975     4.6228629350662231e-01
    z[3,8,5]  R1976     -4.0209221839904785e-01
    z[3,8,5]  R1977     2.8853037953376770e-01
    z[3,8,5]  R1978     3.7438431382179260e-01
    z[3,8,5]  R1979     3.8681104779243469e-01
    z[3,8,5]  R1980     -3.5120215266942978e-02
    z[3,8,5]  R1981     1.3741073012351990e-01
    z[3,8,5]  R1982     2.6251502335071564e-02
    z[3,8,5]  R1983     -3.3485063910484314e-01
    z[3,8,5]  R1984     5.3847837448120117e-01
    z[3,8,5]  R1985     6.3186037540435791e-01
    z[3,8,5]  R1986     3.7381444126367569e-02
    z[3,8,5]  R1987     9.3511477112770081e-02
    z[3,8,5]  R1988     0.371217280626297
    z[3,8,5]  R1989     3.6413182970136404e-03
    z[3,8,5]  R1990     -2.0216912031173706e-01
    z[3,8,5]  R1991     1.0431414842605591e-01
    z[3,8,5]  R1992     1.1590618640184402e-02
    z[3,8,5]  R1993     -7.2658024728298187e-02
    z[3,8,5]  R1994     -6.2452876567840576e-01
    z[3,8,5]  R1995     3.4534335136413574e-01
    z[3,8,5]  R1996     -1.0845420509576797e-01
    z[3,8,5]  R1997     -6.4834314584732056e-01
    z[3,8,5]  R1998     -4.9363338947296143e-01
    z[3,8,5]  R1999     0.472953200340271
    z[3,8,5]  R2000     7.3955051600933075e-02
    z[3,8,5]  R2001     5.4328376054763794e-01
    z[3,8,5]  R2002     3.9821276068687439e-01
    z[3,8,5]  R2003     -1.3570861518383026e-01
    z[3,8,5]  R2004     -2.8387421369552612e-01
    z[3,8,5]  R2005     1.7517729103565216e-01
    z[3,8,5]  R2006     5.7705128192901611e-01
    z[3,8,5]  R2007     4.4803205132484436e-01
    z[3,8,5]  R2008     -4.0736470371484756e-02
    z[3,8,5]  R2009     -3.5944998264312744e-02
    z[3,8,5]  R2010     6.0712260007858276e-01
    z[3,8,5]  R2011     2.9833678156137466e-02
    z[3,8,5]  R2012     -2.2303852438926697e-01
    z[3,8,5]  R2013     -4.6621689200401306e-01
    z[3,8,5]  R2014     7.1863436698913574e-01
    z[3,8,5]  R2015     -3.0003547668457031e-01
    z[3,8,5]  R2016     -4.7163897752761841e-01
    z[3,8,5]  R2017     1.7729481682181358e-02
    z[3,8,5]  R2018     -9.3078408390283585e-03
    z[3,8,6]  R35       -1
    z[3,8,6]  R80       1
    z[3,8,6]  R1877     -1
    z[3,8,6]  R1878     1
    z[3,8,6]  R1879     2.2468097507953644e-01
    z[3,8,6]  R1880     -3.2996791601181030e-01
    z[3,8,6]  R1881     1.4762161672115326e-01
    z[3,8,6]  R1882     -4.5040425658226013e-01
    z[3,8,6]  R1883     1.3805608265101910e-02
    z[3,8,6]  R1884     5.8425735682249069e-02
    z[3,8,6]  R1885     3.9670267701148987e-01
    z[3,8,6]  R1886     0.537770688533783
    z[3,8,6]  R1887     -1.8344806134700775e-01
    z[3,8,6]  R1888     -8.5710622370243073e-02
    z[3,8,6]  R1889     -3.8023035973310471e-02
    z[3,8,6]  R1890     -0.269378125667572
    z[3,8,6]  R1891     -2.0136094093322754e-01
    z[3,8,6]  R1892     -1.4751872420310974e-01
    z[3,8,6]  R1893     -2.1189206838607788e-01
    z[3,8,6]  R1894     -1.0805781185626984e-01
    z[3,8,6]  R1895     -5.5326286703348160e-02
    z[3,8,6]  R1896     -2.1189002692699432e-01
    z[3,8,6]  R1897     4.6170207858085632e-01
    z[3,8,6]  R1898     -1.9464819133281708e-01
    z[3,8,6]  R1899     4.3017691373825073e-01
    z[3,8,6]  R1900     -1.5040473639965057e-01
    z[3,8,6]  R1901     6.3325248658657074e-02
    z[3,8,6]  R1902     1.1317790299654007e-01
    z[3,8,6]  R1903     1.9343329966068268e-01
    z[3,8,6]  R1904     -7.9061530530452728e-02
    z[3,8,6]  R1905     -9.6641272306442261e-02
    z[3,8,6]  R1906     -1.0856087505817413e-01
    z[3,8,6]  R1907     -1.6978496313095093e-01
    z[3,8,6]  R1908     -2.2336056455969810e-02
    z[3,8,6]  R1909     -1.4777894318103790e-01
    z[3,8,6]  R1910     9.7572272352408618e-05
    z[3,8,6]  R1911     -1.1589463800191879e-01
    z[3,8,6]  R1912     2.8197151422500610e-01
    z[3,8,6]  R1913     2.7002471685409546e-01
    z[3,8,6]  R1914     8.2531832158565521e-02
    z[3,8,6]  R1915     -1.7834395170211792e-02
    z[3,8,6]  R1916     1.0257884860038757e-01
    z[3,8,6]  R1917     3.3247941732406616e-01
    z[3,8,6]  R1918     3.5234186798334122e-02
    z[3,8,6]  R1919     0.0984724834561348
    z[3,8,6]  R1920     1.1448633670806885e-01
    z[3,8,6]  R1921     7.1404480934143066e-01
    z[3,8,6]  R1922     -1.8833881616592407e-01
    z[3,8,6]  R1923     -7.0366062223911285e-02
    z[3,8,6]  R1924     6.7802697420120239e-02
    z[3,8,6]  R1925     1.1730934679508209e-01
    z[3,8,6]  R1926     -6.0412295162677765e-02
    z[3,8,6]  R1927     -2.2613309323787689e-01
    z[3,8,6]  R1928     2.3787630721926689e-02
    z[3,8,6]  R1929     7.1329828351736069e-03
    z[3,8,6]  R1930     -7.9224541783332825e-02
    z[3,8,6]  R1931     4.9727505445480347e-01
    z[3,8,6]  R1932     -1.5995460748672485e-01
    z[3,8,6]  R1933     -5.7356536388397217e-01
    z[3,8,6]  R1934     1.2033274024724960e-01
    z[3,8,6]  R1935     -7.1916177868843079e-02
    z[3,8,6]  R1936     -3.6164382100105286e-01
    z[3,8,6]  R1937     -3.1468236446380615e-01
    z[3,8,6]  R1938     -1.3965220749378204e-01
    z[3,8,6]  R1939     -1.7198163270950317e-01
    z[3,8,6]  R1940     9.7616732120513916e-02
    z[3,8,6]  R1941     8.6575500667095184e-02
    z[3,8,6]  R1942     2.6357337832450867e-01
    z[3,8,6]  R1943     9.2977419495582581e-02
    z[3,8,6]  R1944     1.7765671014785767e-01
    z[3,8,6]  R1945     0.538210928440094
    z[3,8,6]  R1946     -9.9790245294570923e-02
    z[3,8,6]  R1947     0.267120897769928
    z[3,8,6]  R1948     -7.2021287679672241e-01
    z[3,8,6]  R1949     1.5352459251880646e-01
    z[3,8,6]  R1950     0.329188734292984
    z[3,8,6]  R1951     2.3916792869567871e-01
    z[3,8,6]  R1952     -1.8713575601577759e-01
    z[3,8,6]  R1953     4.9038669466972351e-01
    z[3,8,6]  R1954     -2.7009156346321106e-01
    z[3,8,6]  R1955     5.6678575277328491e-01
    z[3,8,6]  R1956     3.7452098727226257e-01
    z[3,8,6]  R1957     1.6239304840564728e-01
    z[3,8,6]  R1958     3.7542721629142761e-01
    z[3,8,6]  R1959     -5.5112581700086594e-02
    z[3,8,6]  R1960     -4.4175809621810913e-01
    z[3,8,6]  R1961     2.0904199779033661e-01
    z[3,8,6]  R1962     -3.4600594639778137e-01
    z[3,8,6]  R1963     1.0638792812824249e-01
    z[3,8,6]  R1964     5.7504154741764069e-02
    z[3,8,6]  R1965     7.3766849935054779e-02
    z[3,8,6]  R1966     3.7288421392440796e-01
    z[3,8,6]  R1967     -3.0995625257492065e-01
    z[3,8,6]  R1968     -2.8730648756027222e-01
    z[3,8,6]  R1969     -3.0975034832954407e-01
    z[3,8,6]  R1970     2.0896416902542114e-01
    z[3,8,6]  R1971     1.2505804002285004e-01
    z[3,8,6]  R1972     -5.4767656326293945e-01
    z[3,8,6]  R1973     -5.5913275480270386e-01
    z[3,8,6]  R1974     -2.9187005758285522e-01
    z[3,8,6]  R1975     5.7579171657562256e-01
    z[3,8,6]  R1976     -4.8718109726905823e-01
    z[3,8,6]  R1977     -5.5757766962051392e-01
    z[3,8,6]  R1978     1.5979956090450287e-01
    z[3,8,6]  R1979     1.1773577332496643e-01
    z[3,8,6]  R1980     -1.1788261681795120e-01
    z[3,8,6]  R1981     3.7980252504348755e-01
    z[3,8,6]  R1982     -1.0959913581609726e-01
    z[3,8,6]  R1983     -1.5310059487819672e-01
    z[3,8,6]  R1984     -7.4085518717765808e-02
    z[3,8,6]  R1985     -1.8072827160358429e-01
    z[3,8,6]  R1986     -4.6383801102638245e-01
    z[3,8,6]  R1987     1.4695416390895844e-01
    z[3,8,6]  R1988     2.5241279974579811e-02
    z[3,8,6]  R1989     -2.5018927454948425e-01
    z[3,8,6]  R1990     -3.3541226387023926e-01
    z[3,8,6]  R1991     3.1361293792724609e-01
    z[3,8,6]  R1992     2.8857663273811340e-01
    z[3,8,6]  R1993     -2.0775970816612244e-01
    z[3,8,6]  R1994     4.2690834403038025e-01
    z[3,8,6]  R1995     -2.1375331282615662e-01
    z[3,8,6]  R1996     1.6016711294651031e-01
    z[3,8,6]  R1997     8.2306535914540291e-03
    z[3,8,6]  R1998     1.4425319433212280e-01
    z[3,8,6]  R1999     5.8335000276565552e-01
    z[3,8,6]  R2000     -2.3129422962665558e-01
    z[3,8,6]  R2001     1.6793212294578552e-01
    z[3,8,6]  R2002     -3.8830515742301941e-01
    z[3,8,6]  R2003     -3.7465396523475647e-01
    z[3,8,6]  R2004     5.2417159080505371e-02
    z[3,8,6]  R2005     -0.200520858168602
    z[3,8,6]  R2006     2.5251591205596924e-01
    z[3,8,6]  R2007     -0.011157201603055
    z[3,8,6]  R2008     4.9335334450006485e-02
    z[3,8,6]  R2009     -4.9009706825017929e-02
    z[3,8,6]  R2010     1.0897734016180038e-01
    z[3,8,6]  R2011     -2.9252591729164124e-01
    z[3,8,6]  R2012     9.0420506894588470e-02
    z[3,8,6]  R2013     -2.0941365510225296e-02
    z[3,8,6]  R2014     -4.7655689716339111e-01
    z[3,8,6]  R2015     -3.7927865982055664e-01
    z[3,8,6]  R2016     0.0328315831720829
    z[3,8,6]  R2017     -1.6944380104541779e-01
    z[3,8,6]  R2018     -7.0934578776359558e-02
    z[8,3,0]  R29       1
    z[8,3,0]  R74       -1
    z[8,3,0]  R2019     -1
    z[8,3,0]  R2020     1
    z[8,3,0]  R2033     -4.1689458489418030e-01
    z[8,3,0]  R2034     -4.8468196392059326e-01
    z[8,3,0]  R2035     -5.7306480407714844e-01
    z[8,3,0]  R2036     -3.4239238500595093e-01
    z[8,3,0]  R2037     -6.0957503318786621e-01
    z[8,3,0]  R2038     -3.2015225291252136e-01
    z[8,3,0]  R2039     -3.0857360363006592e-01
    z[8,3,0]  R2040     -3.9235708117485046e-01
    z[8,3,0]  R2041     -3.4801444411277771e-01
    z[8,3,0]  R2042     3.6987990140914917e-02
    z[8,3,0]  R2043     3.7160363048315048e-02
    z[8,3,0]  R2044     4.9446426331996918e-02
    z[8,3,0]  R2045     9.2987410724163055e-02
    z[8,3,0]  R2046     1.6451187431812286e-01
    z[8,3,0]  R2047     3.8392234593629837e-02
    z[8,3,0]  R2048     2.3820878937840462e-02
    z[8,3,0]  R2049     -3.6871144175529480e-01
    z[8,3,0]  R2050     -1.8168369308114052e-02
    z[8,3,0]  R2051     4.3558844923973083e-01
    z[8,3,0]  R2052     -3.8961544632911682e-02
    z[8,3,0]  R2053     2.1219049394130707e-01
    z[8,3,0]  R2054     1.0946871340274811e-01
    z[8,3,0]  R2055     -1.0069070756435394e-01
    z[8,3,0]  R2056     5.2443742752075195e-02
    z[8,3,0]  R2057     2.7736195921897888e-01
    z[8,3,0]  R2058     -9.2849425971508026e-02
    z[8,3,0]  R2059     -9.0580090880393982e-02
    z[8,3,0]  R2060     -1.5218126773834229e-01
    z[8,3,0]  R2061     -3.0100749805569649e-02
    z[8,3,0]  R2062     -3.4075182676315308e-01
    z[8,3,0]  R2063     -1.8804021179676056e-01
    z[8,3,0]  R2064     -1.2020721286535263e-01
    z[8,3,0]  R2065     1.3284712098538876e-02
    z[8,3,0]  R2066     -1.1131456494331360e-01
    z[8,3,0]  R2067     -1.0430975258350372e-01
    z[8,3,0]  R2068     -2.2587503492832184e-01
    z[8,3,0]  R2069     -1.0576321184635162e-01
    z[8,3,0]  R2070     -2.6120189577341080e-02
    z[8,3,0]  R2071     8.6152262985706329e-02
    z[8,3,0]  R2072     1.7868988215923309e-01
    z[8,3,0]  R2073     2.1687847375869751e-01
    z[8,3,0]  R2074     -7.6703220605850220e-02
    z[8,3,0]  R2075     -5.7236045598983765e-01
    z[8,3,0]  R2076     3.7944954633712769e-01
    z[8,3,0]  R2077     -1.9736465811729431e-01
    z[8,3,0]  R2078     -3.9486771821975708e-01
    z[8,3,0]  R2079     0.0852629616856575
    z[8,3,0]  R2080     -2.9006785154342651e-01
    z[8,3,0]  R2081     1.5264980494976044e-01
    z[8,3,0]  R2082     2.2403240203857422e-01
    z[8,3,0]  R2083     -2.2230571508407593e-01
    z[8,3,0]  R2084     -3.1105026602745056e-01
    z[8,3,0]  R2085     -5.1620435714721680e-01
    z[8,3,0]  R2086     -1.7105893790721893e-01
    z[8,3,0]  R2087     2.1935540437698364e-01
    z[8,3,0]  R2088     1.0663330322131515e-03
    z[8,3,0]  R2089     -3.1086322665214539e-01
    z[8,3,0]  R2090     4.4636088609695435e-01
    z[8,3,0]  R2091     6.9318538904190063e-01
    z[8,3,0]  R2092     8.1855165958404541e-01
    z[8,3,0]  R2093     4.0272515267133713e-02
    z[8,3,0]  R2094     3.4263002872467041e-01
    z[8,3,0]  R2095     -1.5010145306587219e-01
    z[8,3,0]  R2096     -1.5877915918827057e-01
    z[8,3,0]  R2097     -2.8038141131401062e-01
    z[8,3,0]  R2098     2.9783645272254944e-01
    z[8,3,0]  R2099     -3.5361889004707336e-01
    z[8,3,0]  R2100     -2.7545174956321716e-01
    z[8,3,0]  R2101     -3.9055564999580383e-01
    z[8,3,0]  R2102     3.1482365727424622e-01
    z[8,3,0]  R2103     1.7461758852005005e-01
    z[8,3,0]  R2104     -2.4204730987548828e-01
    z[8,3,0]  R2105     -3.5855054855346680e-01
    z[8,3,0]  R2106     -2.6036825776100159e-01
    z[8,3,0]  R2107     2.1546375751495361e-01
    z[8,3,0]  R2108     6.7238390445709229e-02
    z[8,3,0]  R2109     -2.7760851383209229e-01
    z[8,3,0]  R2110     7.6810318231582642e-01
    z[8,3,0]  R2111     9.5003110170364380e-01
    z[8,3,0]  R2112     9.3456918001174927e-01
    z[8,3,0]  R2113     3.8435712456703186e-01
    z[8,3,0]  R2114     4.6964627504348755e-01
    z[8,3,0]  R2115     1.2871317565441132e-01
    z[8,3,0]  R2116     3.3063021302223206e-01
    z[8,3,0]  R2117     -1.5768514573574066e-01
    z[8,3,0]  R2118     -6.0754650831222534e-01
    z[8,3,0]  R2119     -4.4395166635513306e-01
    z[8,3,0]  R2120     -1.7489361763000488e-01
    z[8,3,0]  R2121     -6.6080474853515625e-01
    z[8,3,0]  R2122     -6.0426956415176392e-01
    z[8,3,0]  R2123     -3.8641926646232605e-01
    z[8,3,0]  R2124     -2.2747081518173218e-01
    z[8,3,0]  R2125     -1.8546903133392334e-01
    z[8,3,0]  R2126     -2.2525892127305269e-03
    z[8,3,0]  R2127     -3.2109636068344116e-01
    z[8,3,0]  R2128     -2.2801786661148071e-02
    z[8,3,0]  R2129     -5.9258061647415161e-01
    z[8,3,0]  R2130     -3.0523759126663208e-01
    z[8,3,0]  R2131     -4.9144953489303589e-01
    z[8,3,0]  R2132     3.5981366038322449e-01
    z[8,3,0]  R2133     4.6973848342895508e-01
    z[8,3,0]  R2134     3.7984788417816162e-01
    z[8,3,0]  R2135     3.2363331317901611e-01
    z[8,3,0]  R2136     -1.0073760896921158e-01
    z[8,3,0]  R2137     -5.3915452957153320e-01
    z[8,3,0]  R2138     0.573432981967926
    z[8,3,0]  R2139     5.8630925416946411e-01
    z[8,3,0]  R2140     6.3679113984107971e-02
    z[8,3,0]  R2141     1.5071780420839787e-02
    z[8,3,0]  R2142     1.0220363736152649e-01
    z[8,3,0]  R2143     7.9044562578201294e-01
    z[8,3,0]  R2144     -8.5493430495262146e-02
    z[8,3,0]  R2145     -2.8234678506851196e-01
    z[8,3,0]  R2146     -1.1949960142374039e-01
    z[8,3,0]  R2147     -4.2563432455062866e-01
    z[8,3,0]  R2148     -3.5032281279563904e-01
    z[8,3,0]  R2149     -2.7937644720077515e-01
    z[8,3,0]  R2150     -3.0842721462249756e-01
    z[8,3,0]  R2151     -6.1874139308929443e-01
    z[8,3,0]  R2152     -4.4269609451293945e-01
    z[8,3,0]  R2153     1.0344447195529938e-01
    z[8,3,0]  R2154     -9.6073616296052933e-03
    z[8,3,0]  R2155     -3.5229781270027161e-01
    z[8,3,0]  R2156     2.1113598719239235e-02
    z[8,3,0]  R2157     -1.6194912791252136e-01
    z[8,3,0]  R2158     1.4746780693531036e-01
    z[8,3,0]  R2159     -3.9892011880874634e-01
    z[8,3,0]  R2160     -2.4754211306571960e-01
    z[8,3,0]  R2161     -5.6692034006118774e-01
    z[8,3,0]  R2162     -6.1223447322845459e-01
    z[8,3,0]  R2163     -8.9415594935417175e-02
    z[8,3,0]  R2164     5.4197525978088379e-01
    z[8,3,0]  R2165     -3.4987998008728027e-01
    z[8,3,0]  R2166     -5.3841060400009155e-01
    z[8,3,0]  R2167     1.6175134107470512e-02
    z[8,3,0]  R2168     1.9008865579962730e-02
    z[8,3,0]  R2169     -1.1379750072956085e-01
    z[8,3,0]  R2170     8.3032414317131042e-02
    z[8,3,0]  R2171     -6.1901800334453583e-02
    z[8,3,0]  R2172     2.9676225781440735e-01
    z[8,3,1]  R30       1
    z[8,3,1]  R75       -1
    z[8,3,1]  R2021     -1
    z[8,3,1]  R2022     1
    z[8,3,1]  R2033     -3.3204442262649536e-01
    z[8,3,1]  R2034     -2.5690299272537231e-01
    z[8,3,1]  R2035     -4.6997055411338806e-01
    z[8,3,1]  R2036     -4.6174040436744690e-01
    z[8,3,1]  R2037     -4.8508054018020630e-01
    z[8,3,1]  R2038     -0.602096676826477
    z[8,3,1]  R2039     1.2655800208449364e-02
    z[8,3,1]  R2040     -1.6722084954380989e-02
    z[8,3,1]  R2041     -1.5665067732334137e-01
    z[8,3,1]  R2042     2.9285481572151184e-01
    z[8,3,1]  R2043     7.0536142587661743e-01
    z[8,3,1]  R2044     3.4541028738021851e-01
    z[8,3,1]  R2045     0.516209065914154
    z[8,3,1]  R2046     4.8548287153244019e-01
    z[8,3,1]  R2047     3.3199149370193481e-01
    z[8,3,1]  R2048     5.1212704181671143e-01
    z[8,3,1]  R2049     5.9532564878463745e-01
    z[8,3,1]  R2050     6.3990515470504761e-01
    z[8,3,1]  R2051     4.8651802539825439e-01
    z[8,3,1]  R2052     4.3544858694076538e-01
    z[8,3,1]  R2053     -3.4603667259216309e-01
    z[8,3,1]  R2054     0.720102846622467
    z[8,3,1]  R2055     -4.8885107971727848e-03
    z[8,3,1]  R2056     6.4501903951168060e-02
    z[8,3,1]  R2057     -2.0838995277881622e-01
    z[8,3,1]  R2058     -2.4802862107753754e-01
    z[8,3,1]  R2059     -7.4762886762619019e-01
    z[8,3,1]  R2060     4.9201175570487976e-02
    z[8,3,1]  R2061     3.2671761512756348e-01
    z[8,3,1]  R2062     -1.0198544710874557e-01
    z[8,3,1]  R2063     -2.8616625815629959e-02
    z[8,3,1]  R2064     3.1933152675628662e-01
    z[8,3,1]  R2065     6.5530651807785034e-01
    z[8,3,1]  R2066     -7.6302891969680786e-01
    z[8,3,1]  R2067     -0.713287353515625
    z[8,3,1]  R2068     3.4502479434013367e-01
    z[8,3,1]  R2069     -1.5632529556751251e-01
    z[8,3,1]  R2070     4.4123733043670654e-01
    z[8,3,1]  R2071     -4.0507555007934570e-01
    z[8,3,1]  R2072     -7.1970999240875244e-02
    z[8,3,1]  R2073     -1.0386711359024048e-01
    z[8,3,1]  R2074     -0.826941728591919
    z[8,3,1]  R2075     5.5064874887466431e-01
    z[8,3,1]  R2076     5.6682562828063965e-01
    z[8,3,1]  R2077     -0.637488067150116
    z[8,3,1]  R2078     3.1302982568740845e-01
    z[8,3,1]  R2079     -4.3343013525009155e-01
    z[8,3,1]  R2080     -5.8169806003570557e-01
    z[8,3,1]  R2081     8.8284105062484741e-01
    z[8,3,1]  R2082     7.3823785781860352e-01
    z[8,3,1]  R2083     -7.5214987993240356e-01
    z[8,3,1]  R2084     4.9054896831512451e-01
    z[8,3,1]  R2085     4.3570250272750854e-01
    z[8,3,1]  R2086     9.2652714252471924e-01
    z[8,3,1]  R2087     8.0565035343170166e-01
    z[8,3,1]  R2088     -5.6556481122970581e-01
    z[8,3,1]  R2089     4.0573990345001221e-01
    z[8,3,1]  R2090     6.1703330278396606e-01
    z[8,3,1]  R2091     -1.1697446554899216e-01
    z[8,3,1]  R2092     -1.9792547821998596e-01
    z[8,3,1]  R2093     -1.3860097527503967e-01
    z[8,3,1]  R2094     0.715706467628479
    z[8,3,1]  R2095     6.6889148950576782e-01
    z[8,3,1]  R2096     2.9724597930908203e-01
    z[8,3,1]  R2097     -6.8008792400360107e-01
    z[8,3,1]  R2098     8.8679903745651245e-01
    z[8,3,1]  R2099     -7.1929872035980225e-01
    z[8,3,1]  R2100     -3.0911669135093689e-01
    z[8,3,1]  R2101     3.7147161364555359e-01
    z[8,3,1]  R2102     0.74797123670578
    z[8,3,1]  R2103     7.5768578052520752e-01
    z[8,3,1]  R2104     -3.3206534385681152e-01
    z[8,3,1]  R2105     -7.1302127838134766e-01
    z[8,3,1]  R2106     6.7258435487747192e-01
    z[8,3,1]  R2107     7.0505040884017944e-01
    z[8,3,1]  R2108     -6.5480205230414867e-03
    z[8,3,1]  R2109     -7.0366328954696655e-01
    z[8,3,1]  R2110     -3.0529114603996277e-01
    z[8,3,1]  R2111     1.3688798062503338e-02
    z[8,3,1]  R2112     4.1255757212638855e-02
    z[8,3,1]  R2113     -3.8943392038345337e-01
    z[8,3,1]  R2114     1.0056421905755997e-01
    z[8,3,1]  R2115     1.5411810576915741e-01
    z[8,3,1]  R2116     -7.9090172052383423e-01
    z[8,3,1]  R2117     -0.0875360444188118
    z[8,3,1]  R2118     -6.2563389539718628e-01
    z[8,3,1]  R2119     -0.704354465007782
    z[8,3,1]  R2120     -7.9132989048957825e-02
    z[8,3,1]  R2121     -6.2296229600906372e-01
    z[8,3,1]  R2122     -6.6563093662261963e-01
    z[8,3,1]  R2123     -4.1182957589626312e-02
    z[8,3,1]  R2124     -3.4564676880836487e-01
    z[8,3,1]  R2125     2.8088864684104919e-01
    z[8,3,1]  R2126     3.0188298225402832e-01
    z[8,3,1]  R2127     6.1274491250514984e-02
    z[8,3,1]  R2128     0.0978856310248375
    z[8,3,1]  R2129     2.0466198027133942e-01
    z[8,3,1]  R2130     6.6788643598556519e-03
    z[8,3,1]  R2131     1.1274852603673935e-01
    z[8,3,1]  R2132     4.3839445710182190e-01
    z[8,3,1]  R2133     3.5533255338668823e-01
    z[8,3,1]  R2134     -6.9836688041687012e-01
    z[8,3,1]  R2135     -3.9601841568946838e-01
    z[8,3,1]  R2136     1.1077233403921127e-01
    z[8,3,1]  R2137     2.0387648046016693e-01
    z[8,3,1]  R2138     -2.1392878890037537e-01
    z[8,3,1]  R2139     3.0866166949272156e-01
    z[8,3,1]  R2140     -1.5111443400382996e-01
    z[8,3,1]  R2141     2.5715095922350883e-02
    z[8,3,1]  R2142     -1.4068578183650970e-01
    z[8,3,1]  R2143     -0.302144318819046
    z[8,3,1]  R2144     3.4736540168523788e-02
    z[8,3,1]  R2145     -1.4574143290519714e-01
    z[8,3,1]  R2146     -2.2250409424304962e-01
    z[8,3,1]  R2147     -4.6310713887214661e-01
    z[8,3,1]  R2148     2.1093061566352844e-01
    z[8,3,1]  R2149     -8.5881382226943970e-01
    z[8,3,1]  R2150     -4.4231769442558289e-01
    z[8,3,1]  R2151     -0.606364369392395
    z[8,3,1]  R2152     -7.1295052766799927e-01
    z[8,3,1]  R2153     7.0980495214462280e-01
    z[8,3,1]  R2154     -4.2589294910430908e-01
    z[8,3,1]  R2155     -1.5035982429981232e-01
    z[8,3,1]  R2156     9.3660390377044678e-01
    z[8,3,1]  R2157     9.3908828496932983e-01
    z[8,3,1]  R2158     8.6301565170288086e-01
    z[8,3,1]  R2159     5.0970077514648438e-01
    z[8,3,1]  R2160     7.0335948467254639e-01
    z[8,3,1]  R2161     2.9809432104229927e-02
    z[8,3,1]  R2162     -9.8309412598609924e-02
    z[8,3,1]  R2163     6.9336611032485962e-01
    z[8,3,1]  R2164     -6.0947406291961670e-01
    z[8,3,1]  R2165     -2.0571936666965485e-01
    z[8,3,1]  R2166     -7.4226832389831543e-01
    z[8,3,1]  R2167     1.8295995891094208e-01
    z[8,3,1]  R2168     6.1455290764570236e-02
    z[8,3,1]  R2169     1.7191922664642334e-01
    z[8,3,1]  R2170     2.5506317615509033e-01
    z[8,3,1]  R2171     9.5106415450572968e-02
    z[8,3,1]  R2172     -8.0855406820774078e-02
    z[8,3,2]  R31       1
    z[8,3,2]  R76       -1
    z[8,3,2]  R2023     -1
    z[8,3,2]  R2024     1
    z[8,3,2]  R2033     4.2972904443740845e-01
    z[8,3,2]  R2034     2.9859790205955505e-01
    z[8,3,2]  R2035     -1.4298494160175323e-01
    z[8,3,2]  R2036     1.9827237725257874e-01
    z[8,3,2]  R2037     2.4667717516422272e-01
    z[8,3,2]  R2038     6.6764909029006958e-01
    z[8,3,2]  R2039     0.749691903591156
    z[8,3,2]  R2040     0.794209361076355
    z[8,3,2]  R2041     7.4640804529190063e-01
    z[8,3,2]  R2042     -5.7840985059738159e-01
    z[8,3,2]  R2043     -4.9356621503829956e-01
    z[8,3,2]  R2044     -5.4023534059524536e-01
    z[8,3,2]  R2045     -6.4635413885116577e-01
    z[8,3,2]  R2046     -9.2058137059211731e-02
    z[8,3,2]  R2047     -7.9390835762023926e-01
    z[8,3,2]  R2048     -4.5745104551315308e-01
    z[8,3,2]  R2049     -3.7056869268417358e-01
    z[8,3,2]  R2050     -4.0922570228576660e-01
    z[8,3,2]  R2051     -4.8002764582633972e-01
    z[8,3,2]  R2052     -6.8645268678665161e-01
    z[8,3,2]  R2053     4.0704756975173950e-01
    z[8,3,2]  R2054     -3.5753306746482849e-01
    z[8,3,2]  R2055     -3.2452747225761414e-01
    z[8,3,2]  R2056     -1.6314937174320221e-01
    z[8,3,2]  R2057     1.8298590555787086e-02
    z[8,3,2]  R2058     -2.8553183656185865e-03
    z[8,3,2]  R2059     -4.5324909687042236e-01
    z[8,3,2]  R2060     7.4352012015879154e-03
    z[8,3,2]  R2061     1.7782163619995117e-01
    z[8,3,2]  R2062     9.8059467971324921e-02
    z[8,3,2]  R2063     3.7972810864448547e-01
    z[8,3,2]  R2064     -6.2939512729644775e-01
    z[8,3,2]  R2065     -0.642380952835083
    z[8,3,2]  R2066     -6.9627188146114349e-02
    z[8,3,2]  R2067     -1.6084440052509308e-01
    z[8,3,2]  R2068     -5.4775995016098022e-01
    z[8,3,2]  R2069     -4.4738808274269104e-01
    z[8,3,2]  R2070     -5.5230081081390381e-01
    z[8,3,2]  R2071     4.3478560447692871e-01
    z[8,3,2]  R2072     -5.3456395864486694e-01
    z[8,3,2]  R2073     4.4696268439292908e-01
    z[8,3,2]  R2074     -2.2541087865829468e-01
    z[8,3,2]  R2075     -4.3915849924087524e-01
    z[8,3,2]  R2076     -6.5261960029602051e-01
    z[8,3,2]  R2077     -1.2304015457630157e-01
    z[8,3,2]  R2078     -6.2947779893875122e-01
    z[8,3,2]  R2079     -3.2969605177640915e-02
    z[8,3,2]  R2080     -3.2634842395782471e-01
    z[8,3,2]  R2081     2.6758614182472229e-01
    z[8,3,2]  R2082     4.3983215093612671e-01
    z[8,3,2]  R2083     -9.5280326902866364e-02
    z[8,3,2]  R2084     -0.634859025478363
    z[8,3,2]  R2085     -6.4517909288406372e-01
    z[8,3,2]  R2086     0.0360434390604496
    z[8,3,2]  R2087     4.5218861103057861e-01
    z[8,3,2]  R2088     -1.2078131549060345e-02
    z[8,3,2]  R2089     1.2855865061283112e-01
    z[8,3,2]  R2090     5.5934345722198486e-01
    z[8,3,2]  R2091     -2.0315490663051605e-01
    z[8,3,2]  R2092     -1.4706824719905853e-01
    z[8,3,2]  R2093     1.7670039832592010e-01
    z[8,3,2]  R2094     -4.8426979780197144e-01
    z[8,3,2]  R2095     -2.8648141026496887e-01
    z[8,3,2]  R2096     -6.8398404121398926e-01
    z[8,3,2]  R2097     -5.9787672013044357e-02
    z[8,3,2]  R2098     -1.4526379108428955e-01
    z[8,3,2]  R2099     3.9475105702877045e-02
    z[8,3,2]  R2100     2.5788527727127075e-01
    z[8,3,2]  R2101     -4.6022129058837891e-01
    z[8,3,2]  R2102     5.2115124464035034e-01
    z[8,3,2]  R2103     -2.4724586308002472e-01
    z[8,3,2]  R2104     3.8947898149490356e-01
    z[8,3,2]  R2105     -1.5772011876106262e-01
    z[8,3,2]  R2106     -0.574109673500061
    z[8,3,2]  R2107     -4.5492088794708252e-01
    z[8,3,2]  R2108     4.2822387814521790e-01
    z[8,3,2]  R2109     -2.8702369332313538e-01
    z[8,3,2]  R2110     -0.175094336271286
    z[8,3,2]  R2111     6.2799490988254547e-02
    z[8,3,2]  R2112     2.5760421156883240e-01
    z[8,3,2]  R2113     -1.3613632321357727e-01
    z[8,3,2]  R2114     -3.2119369506835938e-01
    z[8,3,2]  R2115     0.11175537109375
    z[8,3,2]  R2116     3.1654998660087585e-02
    z[8,3,2]  R2117     8.4770750999450684e-01
    z[8,3,2]  R2118     -1.4828373491764069e-01
    z[8,3,2]  R2119     2.9359790682792664e-01
    z[8,3,2]  R2120     0.686779260635376
    z[8,3,2]  R2121     -3.4933474659919739e-01
    z[8,3,2]  R2122     -1.5206056833267212e-01
    z[8,3,2]  R2123     1.1364550888538361e-01
    z[8,3,2]  R2124     3.4251266717910767e-01
    z[8,3,2]  R2125     8.4152139723300934e-02
    z[8,3,2]  R2126     -7.0116829872131348e-01
    z[8,3,2]  R2127     0.310958594083786
    z[8,3,2]  R2128     -4.8581293225288391e-01
    z[8,3,2]  R2129     1.5351407229900360e-01
    z[8,3,2]  R2130     -2.2517786920070648e-01
    z[8,3,2]  R2131     2.1858850494027138e-02
    z[8,3,2]  R2132     -4.2397168278694153e-01
    z[8,3,2]  R2133     1.2479174137115479e-01
    z[8,3,2]  R2134     4.9236118793487549e-01
    z[8,3,2]  R2135     7.7350640296936035e-01
    z[8,3,2]  R2136     4.2019265890121460e-01
    z[8,3,2]  R2137     3.5428783297538757e-01
    z[8,3,2]  R2138     3.6612513661384583e-01
    z[8,3,2]  R2139     1.0885686427354813e-01
    z[8,3,2]  R2140     5.1020783185958862e-01
    z[8,3,2]  R2141     6.2840634584426880e-01
    z[8,3,2]  R2142     9.5704257488250732e-02
    z[8,3,2]  R2143     4.8155072331428528e-01
    z[8,3,2]  R2144     0.616873025894165
    z[8,3,2]  R2145     4.6412819623947144e-01
    z[8,3,2]  R2146     1.1298055946826935e-01
    z[8,3,2]  R2147     4.5124284923076630e-02
    z[8,3,2]  R2148     6.3735512085258961e-03
    z[8,3,2]  R2149     -2.0513303577899933e-01
    z[8,3,2]  R2150     -1.2549702823162079e-01
    z[8,3,2]  R2151     -1.3414016366004944e-01
    z[8,3,2]  R2152     2.1963019669055939e-01
    z[8,3,2]  R2153     -4.5000827312469482e-01
    z[8,3,2]  R2154     8.7170645594596863e-02
    z[8,3,2]  R2155     2.8488731384277344e-01
    z[8,3,2]  R2156     2.7279371395707130e-02
    z[8,3,2]  R2157     -1.3675086200237274e-01
    z[8,3,2]  R2158     3.0031827092170715e-01
    z[8,3,2]  R2159     -6.9078212976455688e-01
    z[8,3,2]  R2160     -5.2651494741439819e-01
    z[8,3,2]  R2161     2.8083970770239830e-02
    z[8,3,2]  R2162     2.4156154692173004e-01
    z[8,3,2]  R2163     -5.5537432432174683e-01
    z[8,3,2]  R2164     2.1817199885845184e-01
    z[8,3,2]  R2165     2.2642841935157776e-01
    z[8,3,2]  R2166     -1.9141036272048950e-01
    z[8,3,2]  R2167     1.1570196598768234e-01
    z[8,3,2]  R2168     -0.0828382596373558
    z[8,3,2]  R2169     2.0725773274898529e-01
    z[8,3,2]  R2170     8.0018816515803337e-03
    z[8,3,2]  R2171     -3.0644190311431885e-01
    z[8,3,2]  R2172     -1.1769544333219528e-01
    z[8,3,3]  R32       1
    z[8,3,3]  R77       -1
    z[8,3,3]  R2025     -1
    z[8,3,3]  R2026     1
    z[8,3,3]  R2033     7.0460617542266846e-01
    z[8,3,3]  R2034     6.3385230302810669e-01
    z[8,3,3]  R2035     5.1752287149429321e-01
    z[8,3,3]  R2036     0.691716730594635
    z[8,3,3]  R2037     -2.8274807333946228e-01
    z[8,3,3]  R2038     2.2858205437660217e-01
    z[8,3,3]  R2039     -9.3946717679500580e-02
    z[8,3,3]  R2040     -9.8623782396316528e-02
    z[8,3,3]  R2041     1.6305133700370789e-02
    z[8,3,3]  R2042     2.3331997916102409e-02
    z[8,3,3]  R2043     6.5564163029193878e-02
    z[8,3,3]  R2044     5.2176183462142944e-01
    z[8,3,3]  R2045     4.3301886320114136e-01
    z[8,3,3]  R2046     -7.2795635461807251e-01
    z[8,3,3]  R2047     1.0284223407506943e-01
    z[8,3,3]  R2048     5.7892650365829468e-01
    z[8,3,3]  R2049     1.1072061210870743e-01
    z[8,3,3]  R2050     4.8190414905548096e-01
    z[8,3,3]  R2051     5.4360177367925644e-02
    z[8,3,3]  R2052     -6.8826384842395782e-02
    z[8,3,3]  R2053     -8.1118786334991455e-01
    z[8,3,3]  R2054     0.0860656350851059
    z[8,3,3]  R2055     -0.528769314289093
    z[8,3,3]  R2056     -4.9167567491531372e-01
    z[8,3,3]  R2057     -6.5119296312332153e-01
    z[8,3,3]  R2058     -7.0396721363067627e-01
    z[8,3,3]  R2059     -3.1340688467025757e-01
    z[8,3,3]  R2060     -6.6030627489089966e-01
    z[8,3,3]  R2061     -4.8219156265258789e-01
    z[8,3,3]  R2062     -5.1669472455978394e-01
    z[8,3,3]  R2063     -0.783909022808075
    z[8,3,3]  R2064     6.4680272340774536e-01
    z[8,3,3]  R2065     1.1100284755229950e-02
    z[8,3,3]  R2066     -1.9375425577163696e-01
    z[8,3,3]  R2067     4.3256103992462158e-02
    z[8,3,3]  R2068     6.3257914781570435e-01
    z[8,3,3]  R2069     -4.0427660942077637e-01
    z[8,3,3]  R2070     2.4229690432548523e-01
    z[8,3,3]  R2071     3.9681177586317062e-02
    z[8,3,3]  R2072     -7.1501910686492920e-01
    z[8,3,3]  R2073     -7.5669950246810913e-01
    z[8,3,3]  R2074     4.7563002444803715e-03
    z[8,3,3]  R2075     8.6002998054027557e-02
    z[8,3,3]  R2076     -1.5803065896034241e-01
    z[8,3,3]  R2077     -5.2056068181991577e-01
    z[8,3,3]  R2078     -8.8108986616134644e-02
    z[8,3,3]  R2079     -1.6161488369107246e-02
    z[8,3,3]  R2080     -3.6090412735939026e-01
    z[8,3,3]  R2081     2.4224698543548584e-01
    z[8,3,3]  R2082     2.5279900431632996e-01
    z[8,3,3]  R2083     3.5884881019592285e-01
    z[8,3,3]  R2084     1.4230453968048096e-01
    z[8,3,3]  R2085     -1.0548471659421921e-01
    z[8,3,3]  R2086     9.3076996505260468e-02
    z[8,3,3]  R2087     1.9540201127529144e-01
    z[8,3,3]  R2088     -3.2591944932937622e-01
    z[8,3,3]  R2089     1.2794514000415802e-01
    z[8,3,3]  R2090     -3.7251997739076614e-02
    z[8,3,3]  R2091     -2.0874477922916412e-01
    z[8,3,3]  R2092     -4.8169005662202835e-02
    z[8,3,3]  R2093     -5.8753520250320435e-01
    z[8,3,3]  R2094     8.5866108536720276e-02
    z[8,3,3]  R2095     3.1356829404830933e-01
    z[8,3,3]  R2096     3.1444475054740906e-01
    z[8,3,3]  R2097     -4.0305379033088684e-01
    z[8,3,3]  R2098     1.4074213802814484e-01
    z[8,3,3]  R2099     -0.36433145403862
    z[8,3,3]  R2100     -1.5327471494674683e-01
    z[8,3,3]  R2101     6.5086834132671356e-02
    z[8,3,3]  R2102     -1.3650661706924438e-01
    z[8,3,3]  R2103     5.3470355272293091e-01
    z[8,3,3]  R2104     -1.8591515719890594e-01
    z[8,3,3]  R2105     -3.2681983709335327e-01
    z[8,3,3]  R2106     -1.1359921097755432e-01
    z[8,3,3]  R2107     1.7740766704082489e-01
    z[8,3,3]  R2108     -2.6093408465385437e-01
    z[8,3,3]  R2109     -2.4626623094081879e-01
    z[8,3,3]  R2110     1.6839888691902161e-01
    z[8,3,3]  R2111     1.1186099052429199e-01
    z[8,3,3]  R2112     2.2514252364635468e-01
    z[8,3,3]  R2113     4.5321959257125854e-01
    z[8,3,3]  R2114     4.4695851206779480e-01
    z[8,3,3]  R2115     9.3673390150070190e-01
    z[8,3,3]  R2116     1.9504196941852570e-01
    z[8,3,3]  R2117     -2.9698863625526428e-01
    z[8,3,3]  R2118     -0.0312623456120491
    z[8,3,3]  R2119     -2.2925306856632233e-01
    z[8,3,3]  R2120     -4.2882928252220154e-01
    z[8,3,3]  R2121     6.9269701838493347e-02
    z[8,3,3]  R2122     3.7578254938125610e-01
    z[8,3,3]  R2123     -8.1052398681640625e-01
    z[8,3,3]  R2124     -5.8123838901519775e-01
    z[8,3,3]  R2125     -0.560954213142395
    z[8,3,3]  R2126     1.1045350879430771e-01
    z[8,3,3]  R2127     -3.7698951363563538e-01
    z[8,3,3]  R2128     4.2962488532066345e-01
    z[8,3,3]  R2129     -4.0225467085838318e-01
    z[8,3,3]  R2130     -5.8202630281448364e-01
    z[8,3,3]  R2131     -4.1785049438476562e-01
    z[8,3,3]  R2132     -3.0952779576182365e-02
    z[8,3,3]  R2133     2.3720730841159821e-01
    z[8,3,3]  R2134     6.9490201771259308e-02
    z[8,3,3]  R2135     1.2240605801343918e-01
    z[8,3,3]  R2136     -6.0070788860321045e-01
    z[8,3,3]  R2137     -0.522066593170166
    z[8,3,3]  R2138     3.8913151621818542e-01
    z[8,3,3]  R2139     3.6415389180183411e-01
    z[8,3,3]  R2140     -1.9415524601936340e-01
    z[8,3,3]  R2141     -3.3607918024063110e-01
    z[8,3,3]  R2142     -3.9141789078712463e-01
    z[8,3,3]  R2143     -8.4982894361019135e-02
    z[8,3,3]  R2144     -5.5730760097503662e-01
    z[8,3,3]  R2145     -9.1690264642238617e-02
    z[8,3,3]  R2146     -7.2996979951858521e-01
    z[8,3,3]  R2147     -5.5128979682922363e-01
    z[8,3,3]  R2148     -0.838477373123169
    z[8,3,3]  R2149     -2.7604243159294128e-01
    z[8,3,3]  R2150     6.3116061687469482e-01
    z[8,3,3]  R2151     -4.3238624930381775e-02
    z[8,3,3]  R2152     3.6420649290084839e-01
    z[8,3,3]  R2153     -3.9759587496519089e-02
    z[8,3,3]  R2154     -2.7081990242004395e-01
    z[8,3,3]  R2155     3.9089463651180267e-02
    z[8,3,3]  R2156     -1.4939683675765991e-01
    z[8,3,3]  R2157     1.0562177002429962e-01
    z[8,3,3]  R2158     4.4475674629211426e-02
    z[8,3,3]  R2159     2.0891658961772919e-01
    z[8,3,3]  R2160     0.14479960501194
    z[8,3,3]  R2161     -2.2908157110214233e-01
    z[8,3,3]  R2162     -8.4188235923647881e-03
    z[8,3,3]  R2163     3.7611511349678040e-01
    z[8,3,3]  R2164     -2.1606069058179855e-02
    z[8,3,3]  R2165     -2.7403208613395691e-01
    z[8,3,3]  R2166     1.7212149500846863e-01
    z[8,3,3]  R2167     4.7052096575498581e-02
    z[8,3,3]  R2168     -3.6566668748855591e-01
    z[8,3,3]  R2169     -4.7412046790122986e-01
    z[8,3,3]  R2170     -4.2067438364028931e-01
    z[8,3,3]  R2171     -4.8991143703460693e-01
    z[8,3,3]  R2172     -2.5718429684638977e-01
    z[8,3,4]  R33       1
    z[8,3,4]  R78       -1
    z[8,3,4]  R2027     -1
    z[8,3,4]  R2028     1
    z[8,3,4]  R2033     6.0182854533195496e-02
    z[8,3,4]  R2034     0.334433376789093
    z[8,3,4]  R2035     3.5058698058128357e-01
    z[8,3,4]  R2036     -1.5981499850749969e-01
    z[8,3,4]  R2037     4.5273166894912720e-01
    z[8,3,4]  R2038     7.1975603699684143e-02
    z[8,3,4]  R2039     2.0932009816169739e-01
    z[8,3,4]  R2040     4.3899127840995789e-01
    z[8,3,4]  R2041     4.7448903322219849e-01
    z[8,3,4]  R2042     1.0534477978944778e-01
    z[8,3,4]  R2043     -2.8116098046302795e-01
    z[8,3,4]  R2044     -3.7564691901206970e-01
    z[8,3,4]  R2045     -2.3733133077621460e-01
    z[8,3,4]  R2046     4.0176185965538025e-01
    z[8,3,4]  R2047     -3.4186564385890961e-02
    z[8,3,4]  R2048     -2.3181053996086121e-01
    z[8,3,4]  R2049     -1.7737166583538055e-01
    z[8,3,4]  R2050     1.1563534289598465e-01
    z[8,3,4]  R2051     -0.551505982875824
    z[8,3,4]  R2052     3.9585113525390625e-01
    z[8,3,4]  R2053     1.0906083509325981e-02
    z[8,3,4]  R2054     -3.6826786398887634e-01
    z[8,3,4]  R2055     -6.5377938747406006e-01
    z[8,3,4]  R2056     -7.1659630537033081e-01
    z[8,3,4]  R2057     -5.6170392036437988e-01
    z[8,3,4]  R2058     -6.2472081184387207e-01
    z[8,3,4]  R2059     -0.252750426530838
    z[8,3,4]  R2060     -6.1852902173995972e-01
    z[8,3,4]  R2061     -7.0063984394073486e-01
    z[8,3,4]  R2062     -6.9972926378250122e-01
    z[8,3,4]  R2063     2.1617035567760468e-01
    z[8,3,4]  R2064     -1.0089616477489471e-01
    z[8,3,4]  R2065     3.2417541742324829e-01
    z[8,3,4]  R2066     -2.3014199733734131e-01
    z[8,3,4]  R2067     -3.6255308985710144e-01
    z[8,3,4]  R2068     1.5050463378429413e-01
    z[8,3,4]  R2069     2.3566101491451263e-01
    z[8,3,4]  R2070     2.0459690690040588e-01
    z[8,3,4]  R2071     -4.9369612336158752e-01
    z[8,3,4]  R2072     1.3406861573457718e-02
    z[8,3,4]  R2073     7.9505115747451782e-02
    z[8,3,4]  R2074     -4.9428895115852356e-01
    z[8,3,4]  R2075     -0.0761650800704956
    z[8,3,4]  R2076     -2.6672041416168213e-01
    z[8,3,4]  R2077     3.6464941501617432e-01
    z[8,3,4]  R2078     -2.1595989167690277e-01
    z[8,3,4]  R2079     -6.0959827899932861e-01
    z[8,3,4]  R2080     3.5240563750267029e-01
    z[8,3,4]  R2081     1.9147807359695435e-01
    z[8,3,4]  R2082     -9.4949059188365936e-02
    z[8,3,4]  R2083     -4.2940896749496460e-01
    z[8,3,4]  R2084     2.9315361380577087e-01
    z[8,3,4]  R2085     -0.0841350331902504
    z[8,3,4]  R2086     1.3752470910549164e-01
    z[8,3,4]  R2087     1.0821728408336639e-01
    z[8,3,4]  R2088     -3.8458526134490967e-02
    z[8,3,4]  R2089     7.3545169830322266e-01
    z[8,3,4]  R2090     -2.6146358251571655e-01
    z[8,3,4]  R2091     2.3412831127643585e-02
    z[8,3,4]  R2092     4.8646613955497742e-02
    z[8,3,4]  R2093     1.9688895344734192e-01
    z[8,3,4]  R2094     -2.6365187764167786e-01
    z[8,3,4]  R2095     1.6216847300529480e-01
    z[8,3,4]  R2096     1.0183297097682953e-01
    z[8,3,4]  R2097     3.6613830924034119e-01
    z[8,3,4]  R2098     2.5276171043515205e-02
    z[8,3,4]  R2099     3.9034810662269592e-01
    z[8,3,4]  R2100     -5.8465617895126343e-01
    z[8,3,4]  R2101     -5.4090458154678345e-01
    z[8,3,4]  R2102     -2.1702301502227783e-01
    z[8,3,4]  R2103     -2.1139633655548096e-01
    z[8,3,4]  R2104     -5.1421147584915161e-01
    z[8,3,4]  R2105     3.8064935803413391e-01
    z[8,3,4]  R2106     2.8179755806922913e-01
    z[8,3,4]  R2107     1.6003543511033058e-02
    z[8,3,4]  R2108     -2.0782912150025368e-02
    z[8,3,4]  R2109     2.2558422386646271e-01
    z[8,3,4]  R2110     -1.8514131009578705e-01
    z[8,3,4]  R2111     2.2753329575061798e-01
    z[8,3,4]  R2112     5.2067141979932785e-02
    z[8,3,4]  R2113     3.4688645601272583e-01
    z[8,3,4]  R2114     5.9636777639389038e-01
    z[8,3,4]  R2115     1.8472562730312347e-01
    z[8,3,4]  R2116     -5.8635283261537552e-02
    z[8,3,4]  R2117     -2.3713652789592743e-01
    z[8,3,4]  R2118     4.5625463128089905e-01
    z[8,3,4]  R2119     1.0159126482903957e-02
    z[8,3,4]  R2120     1.3070702552795410e-01
    z[8,3,4]  R2121     -1.1682728677988052e-01
    z[8,3,4]  R2122     -4.6683631837368011e-02
    z[8,3,4]  R2123     3.4998500347137451e-01
    z[8,3,4]  R2124     1.3148643076419830e-01
    z[8,3,4]  R2125     5.9449046850204468e-01
    z[8,3,4]  R2126     -4.5888105034828186e-01
    z[8,3,4]  R2127     3.9809507131576538e-01
    z[8,3,4]  R2128     -6.9887173175811768e-01
    z[8,3,4]  R2129     3.2974988222122192e-01
    z[8,3,4]  R2130     4.0062639117240906e-01
    z[8,3,4]  R2131     1.9780324399471283e-01
    z[8,3,4]  R2132     -5.7936644554138184e-01
    z[8,3,4]  R2133     -0.341208279132843
    z[8,3,4]  R2134     -2.5814184546470642e-01
    z[8,3,4]  R2135     2.8583295643329620e-03
    z[8,3,4]  R2136     5.9135907888412476e-01
    z[8,3,4]  R2137     2.5743296742439270e-01
    z[8,3,4]  R2138     -5.7720959186553955e-01
    z[8,3,4]  R2139     -5.6938838958740234e-01
    z[8,3,4]  R2140     6.3056260347366333e-01
    z[8,3,4]  R2141     0.110362209379673
    z[8,3,4]  R2142     6.8434321880340576e-01
    z[8,3,4]  R2143     -1.5113914012908936e-01
    z[8,3,4]  R2144     2.0056955516338348e-01
    z[8,3,4]  R2145     4.2378431558609009e-01
    z[8,3,4]  R2146     5.9284854680299759e-02
    z[8,3,4]  R2147     2.3376183211803436e-01
    z[8,3,4]  R2148     1.8640869855880737e-01
    z[8,3,4]  R2149     5.0026741810142994e-03
    z[8,3,4]  R2150     -0.529833972454071
    z[8,3,4]  R2151     -2.1755275130271912e-01
    z[8,3,4]  R2152     3.9323933422565460e-02
    z[8,3,4]  R2153     -2.9293003678321838e-01
    z[8,3,4]  R2154     1.9246637821197510e-01
    z[8,3,4]  R2155     4.1980087757110596e-01
    z[8,3,4]  R2156     -0.105362668633461
    z[8,3,4]  R2157     -9.4741076231002808e-02
    z[8,3,4]  R2158     2.9477930068969727e-01
    z[8,3,4]  R2159     6.4331911504268646e-02
    z[8,3,4]  R2160     -3.6906756460666656e-02
    z[8,3,4]  R2161     -5.6205880641937256e-01
    z[8,3,4]  R2162     -5.7529205083847046e-01
    z[8,3,4]  R2163     -1.3045415282249451e-01
    z[8,3,4]  R2164     -4.6280416846275330e-01
    z[8,3,4]  R2165     6.5524756908416748e-01
    z[8,3,4]  R2166     1.6345609724521637e-01
    z[8,3,4]  R2167     -1.2294919788837433e-01
    z[8,3,4]  R2168     -8.3895868062973022e-01
    z[8,3,4]  R2169     -8.0667078495025635e-01
    z[8,3,4]  R2170     -7.0341515541076660e-01
    z[8,3,4]  R2171     -6.1113911867141724e-01
    z[8,3,4]  R2172     -6.0859465599060059e-01
    z[8,3,5]  R34       1
    z[8,3,5]  R79       -1
    z[8,3,5]  R2029     -1
    z[8,3,5]  R2030     1
    z[8,3,5]  R2033     -4.0111333131790161e-02
    z[8,3,5]  R2034     -2.9458436369895935e-01
    z[8,3,5]  R2035     -1.7900609970092773e-01
    z[8,3,5]  R2036     -2.3825907707214355e-01
    z[8,3,5]  R2037     1.9674451649188995e-01
    z[8,3,5]  R2038     -1.5321678481996059e-02
    z[8,3,5]  R2039     1.6504010185599327e-02
    z[8,3,5]  R2040     -5.1086336374282837e-02
    z[8,3,5]  R2041     -2.1501930430531502e-02
    z[8,3,5]  R2042     -2.1900095045566559e-01
    z[8,3,5]  R2043     -3.8801664113998413e-01
    z[8,3,5]  R2044     2.5432538986206055e-01
    z[8,3,5]  R2045     7.7942825853824615e-02
    z[8,3,5]  R2046     4.9140501767396927e-02
    z[8,3,5]  R2047     7.6111115515232086e-02
    z[8,3,5]  R2048     2.5701296329498291e-01
    z[8,3,5]  R2049     -8.5745364427566528e-02
    z[8,3,5]  R2050     -1.9198076426982880e-01
    z[8,3,5]  R2051     -9.8238639533519745e-02
    z[8,3,5]  R2052     -1.8779900670051575e-01
    z[8,3,5]  R2053     9.1455176472663879e-02
    z[8,3,5]  R2054     5.8820914477109909e-02
    z[8,3,5]  R2055     3.6578190326690674e-01
    z[8,3,5]  R2056     3.0248314142227173e-01
    z[8,3,5]  R2057     3.5836723446846008e-01
    z[8,3,5]  R2058     2.0174258947372437e-01
    z[8,3,5]  R2059     2.4466985464096069e-01
    z[8,3,5]  R2060     1.2938182055950165e-01
    z[8,3,5]  R2061     0.203104168176651
    z[8,3,5]  R2062     1.5726454555988312e-01
    z[8,3,5]  R2063     2.4988044798374176e-01
    z[8,3,5]  R2064     -1.2344833463430405e-01
    z[8,3,5]  R2065     1.9207081198692322e-01
    z[8,3,5]  R2066     1.0046100616455078e-01
    z[8,3,5]  R2067     -9.2327609658241272e-02
    z[8,3,5]  R2068     -1.4799048006534576e-01
    z[8,3,5]  R2069     4.6228629350662231e-01
    z[8,3,5]  R2070     -4.0209221839904785e-01
    z[8,3,5]  R2071     2.8853037953376770e-01
    z[8,3,5]  R2072     3.7438431382179260e-01
    z[8,3,5]  R2073     3.8681104779243469e-01
    z[8,3,5]  R2074     -3.5120215266942978e-02
    z[8,3,5]  R2075     1.3741073012351990e-01
    z[8,3,5]  R2076     2.6251502335071564e-02
    z[8,3,5]  R2077     -3.3485063910484314e-01
    z[8,3,5]  R2078     5.3847837448120117e-01
    z[8,3,5]  R2079     6.3186037540435791e-01
    z[8,3,5]  R2080     3.7381444126367569e-02
    z[8,3,5]  R2081     9.3511477112770081e-02
    z[8,3,5]  R2082     0.371217280626297
    z[8,3,5]  R2083     3.6413182970136404e-03
    z[8,3,5]  R2084     -2.0216912031173706e-01
    z[8,3,5]  R2085     1.0431414842605591e-01
    z[8,3,5]  R2086     1.1590618640184402e-02
    z[8,3,5]  R2087     -7.2658024728298187e-02
    z[8,3,5]  R2088     -6.2452876567840576e-01
    z[8,3,5]  R2089     3.4534335136413574e-01
    z[8,3,5]  R2090     -1.0845420509576797e-01
    z[8,3,5]  R2091     -6.4834314584732056e-01
    z[8,3,5]  R2092     -4.9363338947296143e-01
    z[8,3,5]  R2093     0.472953200340271
    z[8,3,5]  R2094     7.3955051600933075e-02
    z[8,3,5]  R2095     5.4328376054763794e-01
    z[8,3,5]  R2096     3.9821276068687439e-01
    z[8,3,5]  R2097     -1.3570861518383026e-01
    z[8,3,5]  R2098     -2.8387421369552612e-01
    z[8,3,5]  R2099     1.7517729103565216e-01
    z[8,3,5]  R2100     5.7705128192901611e-01
    z[8,3,5]  R2101     4.4803205132484436e-01
    z[8,3,5]  R2102     -4.0736470371484756e-02
    z[8,3,5]  R2103     -3.5944998264312744e-02
    z[8,3,5]  R2104     6.0712260007858276e-01
    z[8,3,5]  R2105     2.9833678156137466e-02
    z[8,3,5]  R2106     -2.2303852438926697e-01
    z[8,3,5]  R2107     -4.6621689200401306e-01
    z[8,3,5]  R2108     7.1863436698913574e-01
    z[8,3,5]  R2109     -3.0003547668457031e-01
    z[8,3,5]  R2110     -4.7163897752761841e-01
    z[8,3,5]  R2111     1.7729481682181358e-02
    z[8,3,5]  R2112     -9.3078408390283585e-03
    z[8,3,5]  R2113     -0.553044319152832
    z[8,3,5]  R2114     -4.2993504554033279e-02
    z[8,3,5]  R2115     1.1749506741762161e-01
    z[8,3,5]  R2116     1.4075703918933868e-01
    z[8,3,5]  R2117     3.2285955548286438e-01
    z[8,3,5]  R2118     7.0158019661903381e-02
    z[8,3,5]  R2119     -1.0275598615407944e-01
    z[8,3,5]  R2120     0.0361696258187294
    z[8,3,5]  R2121     -3.3468861132860184e-02
    z[8,3,5]  R2122     1.3391450047492981e-01
    z[8,3,5]  R2123     2.3491376638412476e-01
    z[8,3,5]  R2124     5.3270930051803589e-01
    z[8,3,5]  R2125     4.1350486874580383e-01
    z[8,3,5]  R2126     -4.1556110978126526e-01
    z[8,3,5]  R2127     6.7152678966522217e-01
    z[8,3,5]  R2128     -0.263075053691864
    z[8,3,5]  R2129     5.5658805370330811e-01
    z[8,3,5]  R2130     5.5850416421890259e-01
    z[8,3,5]  R2131     5.6426358222961426e-01
    z[8,3,5]  R2132     -3.5225117206573486e-01
    z[8,3,5]  R2133     -5.2893179655075073e-01
    z[8,3,5]  R2134     1.7745985090732574e-01
    z[8,3,5]  R2135     3.4801909327507019e-01
    z[8,3,5]  R2136     2.7866625785827637e-01
    z[8,3,5]  R2137     4.0741279721260071e-01
    z[8,3,5]  R2138     2.2728929296135902e-02
    z[8,3,5]  R2139     -2.8804320096969604e-01
    z[8,3,5]  R2140     5.1546716690063477e-01
    z[8,3,5]  R2141     6.7101502418518066e-01
    z[8,3,5]  R2142     5.8186775445938110e-01
    z[8,3,5]  R2143     -1.0468350723385811e-02
    z[8,3,5]  R2144     5.1003140211105347e-01
    z[8,3,5]  R2145     6.9440108537673950e-01
    z[8,3,5]  R2146     5.5458873510360718e-01
    z[8,3,5]  R2147     0.413343220949173
    z[8,3,5]  R2148     2.9687958955764771e-01
    z[8,3,5]  R2149     -2.5644791126251221e-01
    z[8,3,5]  R2150     -6.2193788588047028e-02
    z[8,3,5]  R2151     -2.6785546541213989e-01
    z[8,3,5]  R2152     3.3473879098892212e-01
    z[8,3,5]  R2153     -4.3114152550697327e-01
    z[8,3,5]  R2154     8.2911419868469238e-01
    z[8,3,5]  R2155     2.9068300127983093e-01
    z[8,3,5]  R2156     2.2954536974430084e-01
    z[8,3,5]  R2157     2.1932075917720795e-01
    z[8,3,5]  R2158     2.2315025329589844e-01
    z[8,3,5]  R2159     2.0577101409435272e-01
    z[8,3,5]  R2160     3.7524858117103577e-01
    z[8,3,5]  R2161     5.0734555721282959e-01
    z[8,3,5]  R2162     4.7492590546607971e-01
    z[8,3,5]  R2163     -2.1041874587535858e-01
    z[8,3,5]  R2164     -2.5743770599365234e-01
    z[8,3,5]  R2165     1.7963384091854095e-01
    z[8,3,5]  R2166     2.0145660638809204e-01
    z[8,3,5]  R2167     -7.7882564067840576e-01
    z[8,3,5]  R2168     3.7007558345794678e-01
    z[8,3,5]  R2169     1.8400555849075317e-01
    z[8,3,5]  R2170     3.5417270660400391e-01
    z[8,3,5]  R2171     4.2507287859916687e-01
    z[8,3,5]  R2172     6.5993052721023560e-01
    z[8,3,6]  R35       1
    z[8,3,6]  R80       -1
    z[8,3,6]  R2031     -1
    z[8,3,6]  R2032     1
    z[8,3,6]  R2033     -1.7198163270950317e-01
    z[8,3,6]  R2034     9.7616732120513916e-02
    z[8,3,6]  R2035     8.6575500667095184e-02
    z[8,3,6]  R2036     2.6357337832450867e-01
    z[8,3,6]  R2037     9.2977419495582581e-02
    z[8,3,6]  R2038     1.7765671014785767e-01
    z[8,3,6]  R2039     0.538210928440094
    z[8,3,6]  R2040     -9.9790245294570923e-02
    z[8,3,6]  R2041     0.267120897769928
    z[8,3,6]  R2042     -7.2021287679672241e-01
    z[8,3,6]  R2043     1.5352459251880646e-01
    z[8,3,6]  R2044     0.329188734292984
    z[8,3,6]  R2045     2.3916792869567871e-01
    z[8,3,6]  R2046     -1.8713575601577759e-01
    z[8,3,6]  R2047     4.9038669466972351e-01
    z[8,3,6]  R2048     -2.7009156346321106e-01
    z[8,3,6]  R2049     5.6678575277328491e-01
    z[8,3,6]  R2050     3.7452098727226257e-01
    z[8,3,6]  R2051     1.6239304840564728e-01
    z[8,3,6]  R2052     3.7542721629142761e-01
    z[8,3,6]  R2053     -5.5112581700086594e-02
    z[8,3,6]  R2054     -4.4175809621810913e-01
    z[8,3,6]  R2055     2.0904199779033661e-01
    z[8,3,6]  R2056     -3.4600594639778137e-01
    z[8,3,6]  R2057     1.0638792812824249e-01
    z[8,3,6]  R2058     5.7504154741764069e-02
    z[8,3,6]  R2059     7.3766849935054779e-02
    z[8,3,6]  R2060     3.7288421392440796e-01
    z[8,3,6]  R2061     -3.0995625257492065e-01
    z[8,3,6]  R2062     -2.8730648756027222e-01
    z[8,3,6]  R2063     -3.0975034832954407e-01
    z[8,3,6]  R2064     2.0896416902542114e-01
    z[8,3,6]  R2065     1.2505804002285004e-01
    z[8,3,6]  R2066     -5.4767656326293945e-01
    z[8,3,6]  R2067     -5.5913275480270386e-01
    z[8,3,6]  R2068     -2.9187005758285522e-01
    z[8,3,6]  R2069     5.7579171657562256e-01
    z[8,3,6]  R2070     -4.8718109726905823e-01
    z[8,3,6]  R2071     -5.5757766962051392e-01
    z[8,3,6]  R2072     1.5979956090450287e-01
    z[8,3,6]  R2073     1.1773577332496643e-01
    z[8,3,6]  R2074     -1.1788261681795120e-01
    z[8,3,6]  R2075     3.7980252504348755e-01
    z[8,3,6]  R2076     -1.0959913581609726e-01
    z[8,3,6]  R2077     -1.5310059487819672e-01
    z[8,3,6]  R2078     -7.4085518717765808e-02
    z[8,3,6]  R2079     -1.8072827160358429e-01
    z[8,3,6]  R2080     -4.6383801102638245e-01
    z[8,3,6]  R2081     1.4695416390895844e-01
    z[8,3,6]  R2082     2.5241279974579811e-02
    z[8,3,6]  R2083     -2.5018927454948425e-01
    z[8,3,6]  R2084     -3.3541226387023926e-01
    z[8,3,6]  R2085     3.1361293792724609e-01
    z[8,3,6]  R2086     2.8857663273811340e-01
    z[8,3,6]  R2087     -2.0775970816612244e-01
    z[8,3,6]  R2088     4.2690834403038025e-01
    z[8,3,6]  R2089     -2.1375331282615662e-01
    z[8,3,6]  R2090     1.6016711294651031e-01
    z[8,3,6]  R2091     8.2306535914540291e-03
    z[8,3,6]  R2092     1.4425319433212280e-01
    z[8,3,6]  R2093     5.8335000276565552e-01
    z[8,3,6]  R2094     -2.3129422962665558e-01
    z[8,3,6]  R2095     1.6793212294578552e-01
    z[8,3,6]  R2096     -3.8830515742301941e-01
    z[8,3,6]  R2097     -3.7465396523475647e-01
    z[8,3,6]  R2098     5.2417159080505371e-02
    z[8,3,6]  R2099     -0.200520858168602
    z[8,3,6]  R2100     2.5251591205596924e-01
    z[8,3,6]  R2101     -0.011157201603055
    z[8,3,6]  R2102     4.9335334450006485e-02
    z[8,3,6]  R2103     -4.9009706825017929e-02
    z[8,3,6]  R2104     1.0897734016180038e-01
    z[8,3,6]  R2105     -2.9252591729164124e-01
    z[8,3,6]  R2106     9.0420506894588470e-02
    z[8,3,6]  R2107     -2.0941365510225296e-02
    z[8,3,6]  R2108     -4.7655689716339111e-01
    z[8,3,6]  R2109     -3.7927865982055664e-01
    z[8,3,6]  R2110     0.0328315831720829
    z[8,3,6]  R2111     -1.6944380104541779e-01
    z[8,3,6]  R2112     -7.0934578776359558e-02
    z[8,3,6]  R2113     2.2468097507953644e-01
    z[8,3,6]  R2114     -3.2996791601181030e-01
    z[8,3,6]  R2115     1.4762161672115326e-01
    z[8,3,6]  R2116     -4.5040425658226013e-01
    z[8,3,6]  R2117     1.3805608265101910e-02
    z[8,3,6]  R2118     5.8425735682249069e-02
    z[8,3,6]  R2119     3.9670267701148987e-01
    z[8,3,6]  R2120     0.537770688533783
    z[8,3,6]  R2121     -1.8344806134700775e-01
    z[8,3,6]  R2122     -8.5710622370243073e-02
    z[8,3,6]  R2123     -3.8023035973310471e-02
    z[8,3,6]  R2124     -0.269378125667572
    z[8,3,6]  R2125     -2.0136094093322754e-01
    z[8,3,6]  R2126     -1.4751872420310974e-01
    z[8,3,6]  R2127     -2.1189206838607788e-01
    z[8,3,6]  R2128     -1.0805781185626984e-01
    z[8,3,6]  R2129     -5.5326286703348160e-02
    z[8,3,6]  R2130     -2.1189002692699432e-01
    z[8,3,6]  R2131     4.6170207858085632e-01
    z[8,3,6]  R2132     -1.9464819133281708e-01
    z[8,3,6]  R2133     4.3017691373825073e-01
    z[8,3,6]  R2134     -1.5040473639965057e-01
    z[8,3,6]  R2135     6.3325248658657074e-02
    z[8,3,6]  R2136     1.1317790299654007e-01
    z[8,3,6]  R2137     1.9343329966068268e-01
    z[8,3,6]  R2138     -7.9061530530452728e-02
    z[8,3,6]  R2139     -9.6641272306442261e-02
    z[8,3,6]  R2140     -1.0856087505817413e-01
    z[8,3,6]  R2141     -1.6978496313095093e-01
    z[8,3,6]  R2142     -2.2336056455969810e-02
    z[8,3,6]  R2143     -1.4777894318103790e-01
    z[8,3,6]  R2144     9.7572272352408618e-05
    z[8,3,6]  R2145     -1.1589463800191879e-01
    z[8,3,6]  R2146     2.8197151422500610e-01
    z[8,3,6]  R2147     2.7002471685409546e-01
    z[8,3,6]  R2148     8.2531832158565521e-02
    z[8,3,6]  R2149     -1.7834395170211792e-02
    z[8,3,6]  R2150     1.0257884860038757e-01
    z[8,3,6]  R2151     3.3247941732406616e-01
    z[8,3,6]  R2152     3.5234186798334122e-02
    z[8,3,6]  R2153     0.0984724834561348
    z[8,3,6]  R2154     1.1448633670806885e-01
    z[8,3,6]  R2155     7.1404480934143066e-01
    z[8,3,6]  R2156     -1.8833881616592407e-01
    z[8,3,6]  R2157     -7.0366062223911285e-02
    z[8,3,6]  R2158     6.7802697420120239e-02
    z[8,3,6]  R2159     1.1730934679508209e-01
    z[8,3,6]  R2160     -6.0412295162677765e-02
    z[8,3,6]  R2161     -2.2613309323787689e-01
    z[8,3,6]  R2162     2.3787630721926689e-02
    z[8,3,6]  R2163     7.1329828351736069e-03
    z[8,3,6]  R2164     -7.9224541783332825e-02
    z[8,3,6]  R2165     4.9727505445480347e-01
    z[8,3,6]  R2166     -1.5995460748672485e-01
    z[8,3,6]  R2167     -5.7356536388397217e-01
    z[8,3,6]  R2168     1.2033274024724960e-01
    z[8,3,6]  R2169     -7.1916177868843079e-02
    z[8,3,6]  R2170     -3.6164382100105286e-01
    z[8,3,6]  R2171     -3.1468236446380615e-01
    z[8,3,6]  R2172     -1.3965220749378204e-01
    z[4,5,0]  R38       -1
    z[4,5,0]  R47       1
    z[4,5,0]  R2173     -1
    z[4,5,0]  R2174     1
    z[4,5,0]  R2187     -3.2573610544204712e-01
    z[4,5,0]  R2188     -2.5934723019599915e-01
    z[4,5,0]  R2189     8.8120587170124054e-02
    z[4,5,0]  R2190     9.8550565540790558e-02
    z[4,5,0]  R2191     6.9516366720199585e-01
    z[4,5,0]  R2192     3.5381710529327393e-01
    z[4,5,0]  R2193     5.3135710954666138e-01
    z[4,5,0]  R2194     5.0062006711959839e-01
    z[4,5,0]  R2195     -0.0803113803267479
    z[4,5,0]  R2196     -4.1130515933036804e-01
    z[4,5,0]  R2197     -0.427592396736145
    z[4,5,0]  R2198     2.0544408261775970e-01
    z[4,5,0]  R2199     0.0890294685959816
    z[4,5,0]  R2200     -6.0372769832611084e-02
    z[4,5,0]  R2201     -3.5978186130523682e-01
    z[4,5,0]  R2202     -2.9932841658592224e-01
    z[4,5,0]  R2203     -1.1968418210744858e-01
    z[4,5,0]  R2204     -1.6735707223415375e-01
    z[4,5,0]  R2205     -7.3670989274978638e-01
    z[4,5,0]  R2206     -7.2185647487640381e-01
    z[4,5,0]  R2207     5.0655186176300049e-01
    z[4,5,0]  R2208     -3.5451275110244751e-01
    z[4,5,0]  R2209     7.0910400152206421e-01
    z[4,5,0]  R2210     -3.2608368992805481e-01
    z[4,5,0]  R2211     -4.0962222218513489e-01
    z[4,5,0]  R2212     -5.7422578334808350e-01
    z[4,5,0]  R2213     4.8209443688392639e-01
    z[4,5,0]  R2214     -2.2729055583477020e-01
    z[4,5,0]  R2215     -5.2984601259231567e-01
    z[4,5,0]  R2216     -8.7798461318016052e-02
    z[4,5,0]  R2217     -2.1332009136676788e-01
    z[4,5,0]  R2218     1.4889524877071381e-01
    z[4,5,0]  R2219     6.1367547512054443e-01
    z[4,5,0]  R2220     3.5424154996871948e-01
    z[4,5,0]  R2221     7.5880038738250732e-01
    z[4,5,0]  R2222     -1.2219431251287460e-01
    z[4,5,0]  R2223     -1.5539045631885529e-01
    z[4,5,0]  R2224     -4.0151676535606384e-01
    z[4,5,0]  R2225     -4.3038254976272583e-01
    z[4,5,0]  R2226     -5.8152490854263306e-01
    z[4,5,0]  R2227     4.6116787195205688e-01
    z[4,5,0]  R2228     7.4232870340347290e-01
    z[4,5,0]  R2229     -2.1970137953758240e-01
    z[4,5,0]  R2230     -2.8013315796852112e-01
    z[4,5,0]  R2231     -2.9905471205711365e-01
    z[4,5,0]  R2232     -5.3870719671249390e-01
    z[4,5,0]  R2233     -2.1344721317291260e-01
    z[4,5,0]  R2234     -6.4537745714187622e-01
    z[4,5,0]  R2235     -6.8506032228469849e-01
    z[4,5,0]  R2236     -1.5146845579147339e-01
    z[4,5,0]  R2237     4.9648988246917725e-01
    z[4,5,0]  R2238     -2.6639136672019958e-01
    z[4,5,0]  R2239     -1.2950626015663147e-01
    z[4,5,0]  R2240     -7.9698067903518677e-01
    z[4,5,0]  R2241     -3.7656205892562866e-01
    z[4,5,0]  R2242     -5.1015269756317139e-01
    z[4,5,0]  R2243     -4.2382824420928955e-01
    z[4,5,0]  R2244     -4.6033310890197754e-01
    z[4,5,0]  R2245     -5.0955390930175781e-01
    z[4,5,0]  R2246     0.242109477519989
    z[4,5,0]  R2247     6.1530214548110962e-01
    z[4,5,0]  R2248     -2.3542794585227966e-01
    z[4,5,0]  R2249     1.2747491896152496e-01
    z[4,5,0]  R2250     -1.9518758356571198e-01
    z[4,5,0]  R2251     7.8302729129791260e-01
    z[4,5,0]  R2252     -5.4339367151260376e-01
    z[4,5,0]  R2253     -3.0413594841957092e-01
    z[4,5,0]  R2254     -3.3105167746543884e-01
    z[4,5,0]  R2255     8.1613563001155853e-02
    z[4,5,0]  R2256     2.4063149094581604e-01
    z[4,5,0]  R2257     3.8187541067600250e-02
    z[4,5,0]  R2258     -1.1935734748840332e-01
    z[4,5,0]  R2259     -1.2596021592617035e-01
    z[4,5,0]  R2260     -1.0391132533550262e-01
    z[4,5,0]  R2261     -6.1322432756423950e-01
    z[4,5,0]  R2262     7.5107455253601074e-01
    z[4,5,0]  R2263     5.7250422239303589e-01
    z[4,5,0]  R2264     6.0374909639358521e-01
    z[4,5,0]  R2265     5.4553002119064331e-01
    z[4,5,0]  R2266     5.9053015708923340e-01
    z[4,5,1]  R39       -1
    z[4,5,1]  R48       1
    z[4,5,1]  R2175     -1
    z[4,5,1]  R2176     1
    z[4,5,1]  R2187     8.6098372936248779e-02
    z[4,5,1]  R2188     4.0809374302625656e-02
    z[4,5,1]  R2189     1.4856897294521332e-02
    z[4,5,1]  R2190     3.5770680755376816e-02
    z[4,5,1]  R2191     2.9243474826216698e-02
    z[4,5,1]  R2192     3.3882107585668564e-02
    z[4,5,1]  R2193     4.2408645153045654e-02
    z[4,5,1]  R2194     -2.6837334036827087e-02
    z[4,5,1]  R2195     -9.8626506328582764e-01
    z[4,5,1]  R2196     -7.7075231075286865e-01
    z[4,5,1]  R2197     3.3755227923393250e-01
    z[4,5,1]  R2198     4.6453335881233215e-01
    z[4,5,1]  R2199     2.0314882695674896e-01
    z[4,5,1]  R2200     -4.5288348197937012e-01
    z[4,5,1]  R2201     -2.2510962188243866e-01
    z[4,5,1]  R2202     7.5029619038105011e-02
    z[4,5,1]  R2203     -1.1169072240591049e-01
    z[4,5,1]  R2204     -2.0647212862968445e-01
    z[4,5,1]  R2205     3.1193214654922485e-01
    z[4,5,1]  R2206     1.0958223044872284e-01
    z[4,5,1]  R2207     7.0791471004486084e-01
    z[4,5,1]  R2208     7.0677822828292847e-01
    z[4,5,1]  R2209     -9.4216220080852509e-02
    z[4,5,1]  R2210     -1.8292379379272461e-01
    z[4,5,1]  R2211     -3.1834807991981506e-01
    z[4,5,1]  R2212     -2.9790893197059631e-02
    z[4,5,1]  R2213     -6.2753939628601074e-01
    z[4,5,1]  R2214     -2.8487288951873779e-01
    z[4,5,1]  R2215     -2.7020066976547241e-01
    z[4,5,1]  R2216     -8.7465830147266388e-02
    z[4,5,1]  R2217     9.1370832920074463e-01
    z[4,5,1]  R2218     6.0478651523590088e-01
    z[4,5,1]  R2219     -5.3782677650451660e-01
    z[4,5,1]  R2220     -2.0813673734664917e-01
    z[4,5,1]  R2221     -1.4956003427505493e-01
    z[4,5,1]  R2222     -9.1522234678268433e-01
    z[4,5,1]  R2223     -3.5401773452758789e-01
    z[4,5,1]  R2224     -7.9296404123306274e-01
    z[4,5,1]  R2225     -7.6892828941345215e-01
    z[4,5,1]  R2226     -7.2409129142761230e-01
    z[4,5,1]  R2227     2.1006102859973907e-01
    z[4,5,1]  R2228     -0.37724769115448
    z[4,5,1]  R2229     -2.4791140854358673e-01
    z[4,5,1]  R2230     -8.7415516376495361e-01
    z[4,5,1]  R2231     -8.2212585210800171e-01
    z[4,5,1]  R2232     -7.7263385057449341e-01
    z[4,5,1]  R2233     -8.1514602899551392e-01
    z[4,5,1]  R2234     -6.6241323947906494e-01
    z[4,5,1]  R2235     -5.7923221588134766e-01
    z[4,5,1]  R2236     -8.5195028781890869e-01
    z[4,5,1]  R2237     4.3844223022460938e-02
    z[4,5,1]  R2238     -8.0521166324615479e-01
    z[4,5,1]  R2239     1.7489878460764885e-02
    z[4,5,1]  R2240     6.2313683331012726e-02
    z[4,5,1]  R2241     3.1382761895656586e-02
    z[4,5,1]  R2242     -4.2410698533058167e-01
    z[4,5,1]  R2243     -4.4718232750892639e-01
    z[4,5,1]  R2244     -3.6831203103065491e-01
    z[4,5,1]  R2245     -5.1659411191940308e-01
    z[4,5,1]  R2246     1.9754158332943916e-02
    z[4,5,1]  R2247     1.8612654507160187e-01
    z[4,5,1]  R2248     2.8649359941482544e-01
    z[4,5,1]  R2249     8.9528091251850128e-02
    z[4,5,1]  R2250     1.1711125075817108e-01
    z[4,5,1]  R2251     4.3407621979713440e-01
    z[4,5,1]  R2252     8.4541819989681244e-02
    z[4,5,1]  R2253     -3.3135646581649780e-01
    z[4,5,1]  R2254     -1.7478680610656738e-01
    z[4,5,1]  R2255     6.7083835601806641e-01
    z[4,5,1]  R2256     -4.4888365268707275e-01
    z[4,5,1]  R2257     9.6127837896347046e-01
    z[4,5,1]  R2258     8.2246738672256470e-01
    z[4,5,1]  R2259     4.5424845814704895e-01
    z[4,5,1]  R2260     0.443109393119812
    z[4,5,1]  R2261     -3.7199783325195312e-01
    z[4,5,1]  R2262     -3.4101182222366333e-01
    z[4,5,1]  R2263     -4.5097431540489197e-01
    z[4,5,1]  R2264     -3.9959374070167542e-01
    z[4,5,1]  R2265     -2.4694876372814178e-01
    z[4,5,1]  R2266     -5.7367813587188721e-01
    z[4,5,2]  R40       -1
    z[4,5,2]  R49       1
    z[4,5,2]  R2177     -1
    z[4,5,2]  R2178     1
    z[4,5,2]  R2187     8.7004798650741577e-01
    z[4,5,2]  R2188     -3.1570014357566833e-01
    z[4,5,2]  R2189     -3.2411649823188782e-01
    z[4,5,2]  R2190     -4.5273759961128235e-01
    z[4,5,2]  R2191     -3.1902936100959778e-01
    z[4,5,2]  R2192     -3.8057672977447510e-01
    z[4,5,2]  R2193     2.3256923258304596e-01
    z[4,5,2]  R2194     -5.2614736557006836e-01
    z[4,5,2]  R2195     3.5125121474266052e-02
    z[4,5,2]  R2196     -0.135227769613266
    z[4,5,2]  R2197     -6.6119629144668579e-01
    z[4,5,2]  R2198     2.4024224281311035e-01
    z[4,5,2]  R2199     -3.2324683666229248e-01
    z[4,5,2]  R2200     2.6352068781852722e-01
    z[4,5,2]  R2201     1.5180575847625732e-01
    z[4,5,2]  R2202     1.7123924195766449e-01
    z[4,5,2]  R2203     -3.2004401087760925e-02
    z[4,5,2]  R2204     4.7869232296943665e-01
    z[4,5,2]  R2205     3.6024913191795349e-01
    z[4,5,2]  R2206     6.1882162094116211e-01
    z[4,5,2]  R2207     -3.1423881649971008e-01
    z[4,5,2]  R2208     2.6292544603347778e-01
    z[4,5,2]  R2209     2.8887814283370972e-01
    z[4,5,2]  R2210     7.3006629943847656e-01
    z[4,5,2]  R2211     3.7077632546424866e-01
    z[4,5,2]  R2212     4.2833951115608215e-01
    z[4,5,2]  R2213     -2.1611212193965912e-01
    z[4,5,2]  R2214     7.2118914127349854e-01
    z[4,5,2]  R2215     4.2355710268020630e-01
    z[4,5,2]  R2216     3.1084164977073669e-01
    z[4,5,2]  R2217     -1.4423248171806335e-01
    z[4,5,2]  R2218     6.9796758890151978e-01
    z[4,5,2]  R2219     -4.3535566329956055e-01
    z[4,5,2]  R2220     -6.3349805772304535e-02
    z[4,5,2]  R2221     -2.9123482108116150e-01
    z[4,5,2]  R2222     -3.1179878115653992e-01
    z[4,5,2]  R2223     2.2285149991512299e-01
    z[4,5,2]  R2224     -0.224463552236557
    z[4,5,2]  R2225     -3.3415627479553223e-01
    z[4,5,2]  R2226     1.4328600466251373e-01
    z[4,5,2]  R2227     -4.3183878064155579e-01
    z[4,5,2]  R2228     -1.9323955476284027e-01
    z[4,5,2]  R2229     2.3670576512813568e-01
    z[4,5,2]  R2230     -4.6494167298078537e-02
    z[4,5,2]  R2231     -2.1576589345932007e-01
    z[4,5,2]  R2232     -1.8845294415950775e-01
    z[4,5,2]  R2233     8.5460282862186432e-02
    z[4,5,2]  R2234     9.2955529689788818e-02
    z[4,5,2]  R2235     1.5348492562770844e-01
    z[4,5,2]  R2236     3.5969346761703491e-01
    z[4,5,2]  R2237     4.8482915759086609e-01
    z[4,5,2]  R2238     -9.0091131627559662e-02
    z[4,5,2]  R2239     7.8116357326507568e-01
    z[4,5,2]  R2240     1.9263638183474541e-02
    z[4,5,2]  R2241     8.7549078464508057e-01
    z[4,5,2]  R2242     1.1950641125440598e-01
    z[4,5,2]  R2243     0.636570155620575
    z[4,5,2]  R2244     -6.6055871546268463e-02
    z[4,5,2]  R2245     2.6292216777801514e-01
    z[4,5,2]  R2246     4.7815990447998047e-01
    z[4,5,2]  R2247     -3.6712530255317688e-01
    z[4,5,2]  R2248     -4.8442426323890686e-01
    z[4,5,2]  R2249     -8.3194905519485474e-01
    z[4,5,2]  R2250     -4.4412112236022949e-01
    z[4,5,2]  R2251     -8.4590762853622437e-02
    z[4,5,2]  R2252     -0.654270589351654
    z[4,5,2]  R2253     -4.4473114609718323e-01
    z[4,5,2]  R2254     -1.5737813711166382e-01
    z[4,5,2]  R2255     4.3987524509429932e-01
    z[4,5,2]  R2256     -0.320712685585022
    z[4,5,2]  R2257     2.4135455489158630e-01
    z[4,5,2]  R2258     -1.4329555444419384e-02
    z[4,5,2]  R2259     -4.6941635012626648e-01
    z[4,5,2]  R2260     -1.7301650345325470e-01
    z[4,5,2]  R2261     4.5983624458312988e-01
    z[4,5,2]  R2262     -0.0899103432893753
    z[4,5,2]  R2263     2.9243247583508492e-02
    z[4,5,2]  R2264     -3.3227629959583282e-02
    z[4,5,2]  R2265     4.6476915478706360e-01
    z[4,5,2]  R2266     3.0124038457870483e-01
    z[4,5,3]  R41       -1
    z[4,5,3]  R50       1
    z[4,5,3]  R2179     -1
    z[4,5,3]  R2180     1
    z[4,5,3]  R2187     -2.4330346286296844e-01
    z[4,5,3]  R2188     6.4088380336761475e-01
    z[4,5,3]  R2189     8.3118927478790283e-01
    z[4,5,3]  R2190     5.0202047824859619e-01
    z[4,5,3]  R2191     6.1825442314147949e-01
    z[4,5,3]  R2192     5.3561651706695557e-01
    z[4,5,3]  R2193     -2.1502526104450226e-01
    z[4,5,3]  R2194     3.4871095418930054e-01
    z[4,5,3]  R2195     6.1747943982481956e-03
    z[4,5,3]  R2196     -7.8910492360591888e-02
    z[4,5,3]  R2197     -4.9729026854038239e-02
    z[4,5,3]  R2198     -1.3379671610891819e-02
    z[4,5,3]  R2199     -3.6287495493888855e-01
    z[4,5,3]  R2200     -6.2828463315963745e-01
    z[4,5,3]  R2201     -7.9960060119628906e-01
    z[4,5,3]  R2202     -5.5615299940109253e-01
    z[4,5,3]  R2203     -8.0680477619171143e-01
    z[4,5,3]  R2204     -5.9920346736907959e-01
    z[4,5,3]  R2205     -4.7588801383972168e-01
    z[4,5,3]  R2206     -1.9305257499217987e-01
    z[4,5,3]  R2207     -2.4466849863529205e-01
    z[4,5,3]  R2208     -2.2717629373073578e-01
    z[4,5,3]  R2209     6.1988256871700287e-02
    z[4,5,3]  R2210     -4.9140679836273193e-01
    z[4,5,3]  R2211     -0.562491238117218
    z[4,5,3]  R2212     -6.5210080146789551e-01
    z[4,5,3]  R2213     2.4216838181018829e-01
    z[4,5,3]  R2214     -4.3520128726959229e-01
    z[4,5,3]  R2215     -5.5447423458099365e-01
    z[4,5,3]  R2216     -8.6597663164138794e-01
    z[4,5,3]  R2217     -8.7393987923860550e-03
    z[4,5,3]  R2218     -0.0466126874089241
    z[4,5,3]  R2219     1.2584270536899567e-01
    z[4,5,3]  R2220     3.3088415861129761e-01
    z[4,5,3]  R2221     -2.1796119399368763e-03
    z[4,5,3]  R2222     -2.2579845041036606e-02
    z[4,5,3]  R2223     -5.8057314157485962e-01
    z[4,5,3]  R2224     9.4112195074558258e-03
    z[4,5,3]  R2225     -1.8776719272136688e-01
    z[4,5,3]  R2226     -0.0934593677520752
    z[4,5,3]  R2227     1.7307612299919128e-01
    z[4,5,3]  R2228     8.0016024410724640e-02
    z[4,5,3]  R2229     -7.9326313734054565e-01
    z[4,5,3]  R2230     4.2148139327764511e-02
    z[4,5,3]  R2231     2.2905036807060242e-01
    z[4,5,3]  R2232     1.7671939730644226e-01
    z[4,5,3]  R2233     -5.6692283600568771e-02
    z[4,5,3]  R2234     2.2062557935714722e-01
    z[4,5,3]  R2235     2.2669243812561035e-01
    z[4,5,3]  R2236     -1.0020788758993149e-01
    z[4,5,3]  R2237     -2.5866144895553589e-01
    z[4,5,3]  R2238     2.8459358215332031e-01
    z[4,5,3]  R2239     -2.8216877579689026e-01
    z[4,5,3]  R2240     -3.9917609095573425e-01
    z[4,5,3]  R2241     -4.4421613216400146e-02
    z[4,5,3]  R2242     3.2486149668693542e-01
    z[4,5,3]  R2243     2.8203946352005005e-01
    z[4,5,3]  R2244     7.6594430208206177e-01
    z[4,5,3]  R2245     7.3680356144905090e-02
    z[4,5,3]  R2246     -2.6583209633827209e-01
    z[4,5,3]  R2247     -2.9930931329727173e-01
    z[4,5,3]  R2248     3.0626082420349121e-01
    z[4,5,3]  R2249     1.1325030773878098e-01
    z[4,5,3]  R2250     -4.4818982481956482e-01
    z[4,5,3]  R2251     1.8112331628799438e-01
    z[4,5,3]  R2252     -2.3785674571990967e-01
    z[4,5,3]  R2253     -5.3479743003845215e-01
    z[4,5,3]  R2254     -0.523095965385437
    z[4,5,3]  R2255     1.0609175264835358e-01
    z[4,5,3]  R2256     -5.9104657173156738e-01
    z[4,5,3]  R2257     5.4408796131610870e-02
    z[4,5,3]  R2258     2.6956740021705627e-01
    z[4,5,3]  R2259     -2.3281428217887878e-01
    z[4,5,3]  R2260     2.6498386263847351e-01
    z[4,5,3]  R2261     -9.6142947673797607e-02
    z[4,5,3]  R2262     -5.0653403997421265e-01
    z[4,5,3]  R2263     -5.6126654148101807e-01
    z[4,5,3]  R2264     -5.6971663236618042e-01
    z[4,5,3]  R2265     -4.8686710000038147e-01
    z[4,5,3]  R2266     -1.4440187811851501e-01
    z[4,5,4]  R42       -1
    z[4,5,4]  R51       1
    z[4,5,4]  R2181     -1
    z[4,5,4]  R2182     1
    z[4,5,4]  R2187     1.7166081070899963e-01
    z[4,5,4]  R2188     2.6555103063583374e-01
    z[4,5,4]  R2189     -3.5666882991790771e-01
    z[4,5,4]  R2190     6.2006723880767822e-01
    z[4,5,4]  R2191     7.9848326742649078e-02
    z[4,5,4]  R2192     5.8126222342252731e-02
    z[4,5,4]  R2193     5.9390628337860107e-01
    z[4,5,4]  R2194     -3.8776338100433350e-01
    z[4,5,4]  R2195     2.5676438584923744e-02
    z[4,5,4]  R2196     3.1820493936538696e-01
    z[4,5,4]  R2197     -1.7874620854854584e-01
    z[4,5,4]  R2198     -2.6201993227005005e-01
    z[4,5,4]  R2199     -1.4919523894786835e-01
    z[4,5,4]  R2200     -2.1776072680950165e-01
    z[4,5,4]  R2201     -3.7224754691123962e-01
    z[4,5,4]  R2202     5.7311993837356567e-01
    z[4,5,4]  R2203     3.3144921064376831e-01
    z[4,5,4]  R2204     -5.3990882635116577e-01
    z[4,5,4]  R2205     3.5976175218820572e-02
    z[4,5,4]  R2206     -0.162450909614563
    z[4,5,4]  R2207     2.7533066272735596e-01
    z[4,5,4]  R2208     2.1661397814750671e-01
    z[4,5,4]  R2209     -3.1194350123405457e-01
    z[4,5,4]  R2210     5.3216083906590939e-03
    z[4,5,4]  R2211     2.2346168756484985e-01
    z[4,5,4]  R2212     1.5192779898643494e-01
    z[4,5,4]  R2213     -2.9828497767448425e-01
    z[4,5,4]  R2214     0.280141681432724
    z[4,5,4]  R2215     -2.0264382660388947e-01
    z[4,5,4]  R2216     2.8758466243743896e-01
    z[4,5,4]  R2217     8.5873436182737350e-04
    z[4,5,4]  R2218     -1.1589819192886353e-01
    z[4,5,4]  R2219     -4.7125168144702911e-02
    z[4,5,4]  R2220     -5.8494526147842407e-01
    z[4,5,4]  R2221     -4.6181634068489075e-01
    z[4,5,4]  R2222     1.4247675240039825e-01
    z[4,5,4]  R2223     -1.6923119127750397e-01
    z[4,5,4]  R2224     -2.9892298579216003e-01
    z[4,5,4]  R2225     3.5811014473438263e-02
    z[4,5,4]  R2226     -1.5946429967880249e-01
    z[4,5,4]  R2227     -5.0564610958099365e-01
    z[4,5,4]  R2228     -1.6528847813606262e-01
    z[4,5,4]  R2229     -3.4734913706779480e-01
    z[4,5,4]  R2230     -2.7560099959373474e-01
    z[4,5,4]  R2231     1.1525370180606842e-01
    z[4,5,4]  R2232     -1.2992176413536072e-01
    z[4,5,4]  R2233     2.5555733591318130e-03
    z[4,5,4]  R2234     4.9524795264005661e-02
    z[4,5,4]  R2235     -1.4719154569320381e-04
    z[4,5,4]  R2236     2.0635944604873657e-01
    z[4,5,4]  R2237     -2.9757422208786011e-01
    z[4,5,4]  R2238     2.0776192843914032e-01
    z[4,5,4]  R2239     -3.4446901082992554e-01
    z[4,5,4]  R2240     -3.9735859632492065e-01
    z[4,5,4]  R2241     1.4652957022190094e-01
    z[4,5,4]  R2242     5.7656061649322510e-01
    z[4,5,4]  R2243     3.5364833474159241e-01
    z[4,5,4]  R2244     -1.7526137828826904e-01
    z[4,5,4]  R2245     -3.2261142134666443e-01
    z[4,5,4]  R2246     6.1804372072219849e-01
    z[4,5,4]  R2247     4.1991323814727366e-04
    z[4,5,4]  R2248     -1.4301495254039764e-01
    z[4,5,4]  R2249     1.8313780426979065e-01
    z[4,5,4]  R2250     5.4839968681335449e-01
    z[4,5,4]  R2251     2.6046988368034363e-01
    z[4,5,4]  R2252     1.9126552343368530e-01
    z[4,5,4]  R2253     2.1001639962196350e-01
    z[4,5,4]  R2254     -4.0290430188179016e-01
    z[4,5,4]  R2255     -1.2991668283939362e-01
    z[4,5,4]  R2256     3.6405879259109497e-01
    z[4,5,4]  R2257     1.0645199567079544e-02
    z[4,5,4]  R2258     2.7664875984191895e-01
    z[4,5,4]  R2259     -5.1507055759429932e-01
    z[4,5,4]  R2260     -5.9713596105575562e-01
    z[4,5,4]  R2261     -1.3740111887454987e-01
    z[4,5,4]  R2262     3.2693885266780853e-02
    z[4,5,4]  R2263     2.0006994903087616e-01
    z[4,5,4]  R2264     -2.5432524085044861e-01
    z[4,5,4]  R2265     -1.9584493339061737e-01
    z[4,5,4]  R2266     -2.0171651244163513e-01
    z[4,5,5]  R43       -1
    z[4,5,5]  R52       1
    z[4,5,5]  R2183     -1
    z[4,5,5]  R2184     1
    z[4,5,5]  R2187     -8.7248824536800385e-02
    z[4,5,5]  R2188     -3.4173485636711121e-01
    z[4,5,5]  R2189     -2.6238659024238586e-01
    z[4,5,5]  R2190     -3.4383806586265564e-01
    z[4,5,5]  R2191     9.3546412885189056e-02
    z[4,5,5]  R2192     -6.0945028066635132e-01
    z[4,5,5]  R2193     -4.6668532490730286e-01
    z[4,5,5]  R2194     3.9792710542678833e-01
    z[4,5,5]  R2195     1.2828531861305237e-01
    z[4,5,5]  R2196     9.0913869440555573e-02
    z[4,5,5]  R2197     4.4212940335273743e-01
    z[4,5,5]  R2198     7.7977198362350464e-01
    z[4,5,5]  R2199     -4.2695045471191406e-01
    z[4,5,5]  R2200     3.7409138679504395e-01
    z[4,5,5]  R2201     9.4170890748500824e-02
    z[4,5,5]  R2202     3.5449784994125366e-01
    z[4,5,5]  R2203     3.2058224081993103e-01
    z[4,5,5]  R2204     0.0108823636546731
    z[4,5,5]  R2205     -0.0410323366522789
    z[4,5,5]  R2206     5.7950407266616821e-02
    z[4,5,5]  R2207     -2.5654423981904984e-02
    z[4,5,5]  R2208     -3.8571065664291382e-01
    z[4,5,5]  R2209     -2.5312250852584839e-01
    z[4,5,5]  R2210     2.0238001644611359e-01
    z[4,5,5]  R2211     4.6938553452491760e-01
    z[4,5,5]  R2212     1.9093506038188934e-01
    z[4,5,5]  R2213     0.0532853901386261
    z[4,5,5]  R2214     2.6255580782890320e-01
    z[4,5,5]  R2215     2.5324231386184692e-01
    z[4,5,5]  R2216     2.3000319302082062e-01
    z[4,5,5]  R2217     -2.4678705632686615e-01
    z[4,5,5]  R2218     -3.2962822914123535e-01
    z[4,5,5]  R2219     2.6725775003433228e-01
    z[4,5,5]  R2220     -2.3675398528575897e-01
    z[4,5,5]  R2221     -6.3373476266860962e-02
    z[4,5,5]  R2222     2.2593397647142410e-02
    z[4,5,5]  R2223     4.6157222986221313e-01
    z[4,5,5]  R2224     -2.4501267075538635e-01
    z[4,5,5]  R2225     -2.2183151543140411e-01
    z[4,5,5]  R2226     -1.8626582622528076e-01
    z[4,5,5]  R2227     1.2021089345216751e-01
    z[4,5,5]  R2228     -1.2923605740070343e-01
    z[4,5,5]  R2229     2.9020580649375916e-01
    z[4,5,5]  R2230     -2.4687018990516663e-01
    z[4,5,5]  R2231     -7.4510313570499420e-02
    z[4,5,5]  R2232     1.5238919854164124e-01
    z[4,5,5]  R2233     -4.1781923174858093e-01
    z[4,5,5]  R2234     -2.3594839870929718e-01
    z[4,5,5]  R2235     1.7438188195228577e-01
    z[4,5,5]  R2236     -2.5090718269348145e-01
    z[4,5,5]  R2237     -5.6988209486007690e-01
    z[4,5,5]  R2238     -6.3853855244815350e-03
    z[4,5,5]  R2239     -3.9604845643043518e-01
    z[4,5,5]  R2240     -1.6567985713481903e-01
    z[4,5,5]  R2241     -1.9466885924339294e-01
    z[4,5,5]  R2242     -9.0171068906784058e-02
    z[4,5,5]  R2243     2.6869205757975578e-02
    z[4,5,5]  R2244     2.1448722109198570e-02
    z[4,5,5]  R2245     -5.2375471591949463e-01
    z[4,5,5]  R2246     -5.0364631414413452e-01
    z[4,5,5]  R2247     4.7354102134704590e-01
    z[4,5,5]  R2248     6.2358152866363525e-01
    z[4,5,5]  R2249     -1.8069872260093689e-01
    z[4,5,5]  R2250     4.4689774513244629e-01
    z[4,5,5]  R2251     1.8895292282104492e-01
    z[4,5,5]  R2252     -2.3948937654495239e-01
    z[4,5,5]  R2253     4.0278565883636475e-01
    z[4,5,5]  R2254     3.9408656954765320e-01
    z[4,5,5]  R2255     3.2812082767486572e-01
    z[4,5,5]  R2256     -3.1141281127929688e-01
    z[4,5,5]  R2257     -1.1388673633337021e-01
    z[4,5,5]  R2258     -1.6845078766345978e-01
    z[4,5,5]  R2259     -1.9640058279037476e-01
    z[4,5,5]  R2260     -5.7908177375793457e-01
    z[4,5,5]  R2261     4.5114055275917053e-01
    z[4,5,5]  R2262     -2.2129443287849426e-01
    z[4,5,5]  R2263     3.0819091200828552e-01
    z[4,5,5]  R2264     2.7421155571937561e-01
    z[4,5,5]  R2265     1.5060122311115265e-01
    z[4,5,5]  R2266     1.3864484429359436e-01
    z[4,5,6]  R44       -1
    z[4,5,6]  R53       1
    z[4,5,6]  R2185     -1
    z[4,5,6]  R2186     1
    z[4,5,6]  R2187     -1.8227215111255646e-01
    z[4,5,6]  R2188     4.8308894038200378e-01
    z[4,5,6]  R2189     -5.2540283650159836e-03
    z[4,5,6]  R2190     -1.7118491232395172e-01
    z[4,5,6]  R2191     -1.2941205501556396e-01
    z[4,5,6]  R2192     0.259101003408432
    z[4,5,6]  R2193     2.1217225492000580e-01
    z[4,5,6]  R2194     -2.0377086102962494e-01
    z[4,5,6]  R2195     4.9424994736909866e-02
    z[4,5,6]  R2196     3.2052415609359741e-01
    z[4,5,6]  R2197     -1.9010773301124573e-01
    z[4,5,6]  R2198     8.6065813899040222e-02
    z[4,5,6]  R2199     -7.1420705318450928e-01
    z[4,5,6]  R2200     -3.7376844882965088e-01
    z[4,5,6]  R2201     -1.0020061582326889e-01
    z[4,5,6]  R2202     3.3467730879783630e-01
    z[4,5,6]  R2203     -3.2956176996231079e-01
    z[4,5,6]  R2204     2.2259773313999176e-01
    z[4,5,6]  R2205     -2.7017902582883835e-02
    z[4,5,6]  R2206     1.3021923601627350e-01
    z[4,5,6]  R2207     8.4782741963863373e-02
    z[4,5,6]  R2208     2.4156148731708527e-01
    z[4,5,6]  R2209     -4.8951196670532227e-01
    z[4,5,6]  R2210     -2.1152982115745544e-01
    z[4,5,6]  R2211     -0.0820658802986145
    z[4,5,6]  R2212     -3.3595755696296692e-02
    z[4,5,6]  R2213     -4.2025718092918396e-01
    z[4,5,6]  R2214     1.0127981007099152e-01
    z[4,5,6]  R2215     2.3284368216991425e-01
    z[4,5,6]  R2216     -4.9966756254434586e-02
    z[4,5,6]  R2217     1.9454509019851685e-01
    z[4,5,6]  R2218     2.5387939065694809e-02
    z[4,5,6]  R2219     -2.3479017615318298e-01
    z[4,5,6]  R2220     -5.6522661447525024e-01
    z[4,5,6]  R2221     -3.1581774353981018e-01
    z[4,5,6]  R2222     -1.6999433934688568e-01
    z[4,5,6]  R2223     -4.7128465771675110e-01
    z[4,5,6]  R2224     -1.0066631436347961e-01
    z[4,5,6]  R2225     1.6159044206142426e-01
    z[4,5,6]  R2226     -2.1938814222812653e-01
    z[4,5,6]  R2227     -5.0658637285232544e-01
    z[4,5,6]  R2228     -4.6783113479614258e-01
    z[4,5,6]  R2229     1.0208971798419952e-02
    z[4,5,6]  R2230     -1.2860514223575592e-01
    z[4,5,6]  R2231     3.4179106354713440e-01
    z[4,5,6]  R2232     -7.7363565564155579e-02
    z[4,5,6]  R2233     3.2385224103927612e-01
    z[4,5,6]  R2234     1.7104333639144897e-01
    z[4,5,6]  R2235     2.9971027374267578e-01
    z[4,5,6]  R2236     -0.0792362168431282
    z[4,5,6]  R2237     1.9051089882850647e-01
    z[4,5,6]  R2238     -0.38516765832901
    z[4,5,6]  R2239     1.3256359100341797e-01
    z[4,5,6]  R2240     -1.2602607905864716e-01
    z[4,5,6]  R2241     1.7144057154655457e-01
    z[4,5,6]  R2242     0.315448522567749
    z[4,5,6]  R2243     -9.9200025200843811e-02
    z[4,5,6]  R2244     1.7386473715305328e-01
    z[4,5,6]  R2245     -1.4328743517398834e-01
    z[4,5,6]  R2246     -7.7792368829250336e-02
    z[4,5,6]  R2247     -3.7168782949447632e-01
    z[4,5,6]  R2248     -3.5316473245620728e-01
    z[4,5,6]  R2249     -4.5230352878570557e-01
    z[4,5,6]  R2250     2.2273132205009460e-01
    z[4,5,6]  R2251     -2.3438625037670135e-01
    z[4,5,6]  R2252     3.4495303034782410e-01
    z[4,5,6]  R2253     3.2797396183013916e-01
    z[4,5,6]  R2254     4.9378228187561035e-01
    z[4,5,6]  R2255     4.6263146400451660e-01
    z[4,5,6]  R2256     2.4267353117465973e-01
    z[4,5,6]  R2257     -1.3771170750260353e-02
    z[4,5,6]  R2258     3.6265552043914795e-01
    z[4,5,6]  R2259     4.4650569558143616e-01
    z[4,5,6]  R2260     -2.8255870565772057e-02
    z[4,5,6]  R2261     2.0609153807163239e-01
    z[4,5,6]  R2262     0.0699809193611145
    z[4,5,6]  R2263     1.3407501578330994e-01
    z[4,5,6]  R2264     1.0127907991409302e-01
    z[4,5,6]  R2265     3.5682967305183411e-01
    z[4,5,6]  R2266     -3.8814684748649597e-01
    z[5,4,0]  R38       1
    z[5,4,0]  R47       -1
    z[5,4,0]  R2267     -1
    z[5,4,0]  R2268     1
    z[5,4,0]  R2281     4.9648988246917725e-01
    z[5,4,0]  R2282     -2.6639136672019958e-01
    z[5,4,0]  R2283     -1.2950626015663147e-01
    z[5,4,0]  R2284     -7.9698067903518677e-01
    z[5,4,0]  R2285     -3.7656205892562866e-01
    z[5,4,0]  R2286     -5.1015269756317139e-01
    z[5,4,0]  R2287     -4.2382824420928955e-01
    z[5,4,0]  R2288     -4.6033310890197754e-01
    z[5,4,0]  R2289     -5.0955390930175781e-01
    z[5,4,0]  R2290     0.242109477519989
    z[5,4,0]  R2291     6.1530214548110962e-01
    z[5,4,0]  R2292     -2.3542794585227966e-01
    z[5,4,0]  R2293     1.2747491896152496e-01
    z[5,4,0]  R2294     -1.9518758356571198e-01
    z[5,4,0]  R2295     7.8302729129791260e-01
    z[5,4,0]  R2296     -5.4339367151260376e-01
    z[5,4,0]  R2297     -3.0413594841957092e-01
    z[5,4,0]  R2298     -3.3105167746543884e-01
    z[5,4,0]  R2299     8.1613563001155853e-02
    z[5,4,0]  R2300     2.4063149094581604e-01
    z[5,4,0]  R2301     3.8187541067600250e-02
    z[5,4,0]  R2302     -1.1935734748840332e-01
    z[5,4,0]  R2303     -1.2596021592617035e-01
    z[5,4,0]  R2304     -1.0391132533550262e-01
    z[5,4,0]  R2305     -6.1322432756423950e-01
    z[5,4,0]  R2306     7.5107455253601074e-01
    z[5,4,0]  R2307     5.7250422239303589e-01
    z[5,4,0]  R2308     6.0374909639358521e-01
    z[5,4,0]  R2309     5.4553002119064331e-01
    z[5,4,0]  R2310     5.9053015708923340e-01
    z[5,4,0]  R2311     -3.2573610544204712e-01
    z[5,4,0]  R2312     -2.5934723019599915e-01
    z[5,4,0]  R2313     8.8120587170124054e-02
    z[5,4,0]  R2314     9.8550565540790558e-02
    z[5,4,0]  R2315     6.9516366720199585e-01
    z[5,4,0]  R2316     3.5381710529327393e-01
    z[5,4,0]  R2317     5.3135710954666138e-01
    z[5,4,0]  R2318     5.0062006711959839e-01
    z[5,4,0]  R2319     -0.0803113803267479
    z[5,4,0]  R2320     -4.1130515933036804e-01
    z[5,4,0]  R2321     -0.427592396736145
    z[5,4,0]  R2322     2.0544408261775970e-01
    z[5,4,0]  R2323     0.0890294685959816
    z[5,4,0]  R2324     -6.0372769832611084e-02
    z[5,4,0]  R2325     -3.5978186130523682e-01
    z[5,4,0]  R2326     -2.9932841658592224e-01
    z[5,4,0]  R2327     -1.1968418210744858e-01
    z[5,4,0]  R2328     -1.6735707223415375e-01
    z[5,4,0]  R2329     -7.3670989274978638e-01
    z[5,4,0]  R2330     -7.2185647487640381e-01
    z[5,4,0]  R2331     5.0655186176300049e-01
    z[5,4,0]  R2332     -3.5451275110244751e-01
    z[5,4,0]  R2333     7.0910400152206421e-01
    z[5,4,0]  R2334     -3.2608368992805481e-01
    z[5,4,0]  R2335     -4.0962222218513489e-01
    z[5,4,0]  R2336     -5.7422578334808350e-01
    z[5,4,0]  R2337     4.8209443688392639e-01
    z[5,4,0]  R2338     -2.2729055583477020e-01
    z[5,4,0]  R2339     -5.2984601259231567e-01
    z[5,4,0]  R2340     -8.7798461318016052e-02
    z[5,4,0]  R2341     -2.1332009136676788e-01
    z[5,4,0]  R2342     1.4889524877071381e-01
    z[5,4,0]  R2343     6.1367547512054443e-01
    z[5,4,0]  R2344     3.5424154996871948e-01
    z[5,4,0]  R2345     7.5880038738250732e-01
    z[5,4,0]  R2346     -1.2219431251287460e-01
    z[5,4,0]  R2347     -1.5539045631885529e-01
    z[5,4,0]  R2348     -4.0151676535606384e-01
    z[5,4,0]  R2349     -4.3038254976272583e-01
    z[5,4,0]  R2350     -5.8152490854263306e-01
    z[5,4,0]  R2351     4.6116787195205688e-01
    z[5,4,0]  R2352     7.4232870340347290e-01
    z[5,4,0]  R2353     -2.1970137953758240e-01
    z[5,4,0]  R2354     -2.8013315796852112e-01
    z[5,4,0]  R2355     -2.9905471205711365e-01
    z[5,4,0]  R2356     -5.3870719671249390e-01
    z[5,4,0]  R2357     -2.1344721317291260e-01
    z[5,4,0]  R2358     -6.4537745714187622e-01
    z[5,4,0]  R2359     -6.8506032228469849e-01
    z[5,4,0]  R2360     -1.5146845579147339e-01
    z[5,4,1]  R39       1
    z[5,4,1]  R48       -1
    z[5,4,1]  R2269     -1
    z[5,4,1]  R2270     1
    z[5,4,1]  R2281     4.3844223022460938e-02
    z[5,4,1]  R2282     -8.0521166324615479e-01
    z[5,4,1]  R2283     1.7489878460764885e-02
    z[5,4,1]  R2284     6.2313683331012726e-02
    z[5,4,1]  R2285     3.1382761895656586e-02
    z[5,4,1]  R2286     -4.2410698533058167e-01
    z[5,4,1]  R2287     -4.4718232750892639e-01
    z[5,4,1]  R2288     -3.6831203103065491e-01
    z[5,4,1]  R2289     -5.1659411191940308e-01
    z[5,4,1]  R2290     1.9754158332943916e-02
    z[5,4,1]  R2291     1.8612654507160187e-01
    z[5,4,1]  R2292     2.8649359941482544e-01
    z[5,4,1]  R2293     8.9528091251850128e-02
    z[5,4,1]  R2294     1.1711125075817108e-01
    z[5,4,1]  R2295     4.3407621979713440e-01
    z[5,4,1]  R2296     8.4541819989681244e-02
    z[5,4,1]  R2297     -3.3135646581649780e-01
    z[5,4,1]  R2298     -1.7478680610656738e-01
    z[5,4,1]  R2299     6.7083835601806641e-01
    z[5,4,1]  R2300     -4.4888365268707275e-01
    z[5,4,1]  R2301     9.6127837896347046e-01
    z[5,4,1]  R2302     8.2246738672256470e-01
    z[5,4,1]  R2303     4.5424845814704895e-01
    z[5,4,1]  R2304     0.443109393119812
    z[5,4,1]  R2305     -3.7199783325195312e-01
    z[5,4,1]  R2306     -3.4101182222366333e-01
    z[5,4,1]  R2307     -4.5097431540489197e-01
    z[5,4,1]  R2308     -3.9959374070167542e-01
    z[5,4,1]  R2309     -2.4694876372814178e-01
    z[5,4,1]  R2310     -5.7367813587188721e-01
    z[5,4,1]  R2311     8.6098372936248779e-02
    z[5,4,1]  R2312     4.0809374302625656e-02
    z[5,4,1]  R2313     1.4856897294521332e-02
    z[5,4,1]  R2314     3.5770680755376816e-02
    z[5,4,1]  R2315     2.9243474826216698e-02
    z[5,4,1]  R2316     3.3882107585668564e-02
    z[5,4,1]  R2317     4.2408645153045654e-02
    z[5,4,1]  R2318     -2.6837334036827087e-02
    z[5,4,1]  R2319     -9.8626506328582764e-01
    z[5,4,1]  R2320     -7.7075231075286865e-01
    z[5,4,1]  R2321     3.3755227923393250e-01
    z[5,4,1]  R2322     4.6453335881233215e-01
    z[5,4,1]  R2323     2.0314882695674896e-01
    z[5,4,1]  R2324     -4.5288348197937012e-01
    z[5,4,1]  R2325     -2.2510962188243866e-01
    z[5,4,1]  R2326     7.5029619038105011e-02
    z[5,4,1]  R2327     -1.1169072240591049e-01
    z[5,4,1]  R2328     -2.0647212862968445e-01
    z[5,4,1]  R2329     3.1193214654922485e-01
    z[5,4,1]  R2330     1.0958223044872284e-01
    z[5,4,1]  R2331     7.0791471004486084e-01
    z[5,4,1]  R2332     7.0677822828292847e-01
    z[5,4,1]  R2333     -9.4216220080852509e-02
    z[5,4,1]  R2334     -1.8292379379272461e-01
    z[5,4,1]  R2335     -3.1834807991981506e-01
    z[5,4,1]  R2336     -2.9790893197059631e-02
    z[5,4,1]  R2337     -6.2753939628601074e-01
    z[5,4,1]  R2338     -2.8487288951873779e-01
    z[5,4,1]  R2339     -2.7020066976547241e-01
    z[5,4,1]  R2340     -8.7465830147266388e-02
    z[5,4,1]  R2341     9.1370832920074463e-01
    z[5,4,1]  R2342     6.0478651523590088e-01
    z[5,4,1]  R2343     -5.3782677650451660e-01
    z[5,4,1]  R2344     -2.0813673734664917e-01
    z[5,4,1]  R2345     -1.4956003427505493e-01
    z[5,4,1]  R2346     -9.1522234678268433e-01
    z[5,4,1]  R2347     -3.5401773452758789e-01
    z[5,4,1]  R2348     -7.9296404123306274e-01
    z[5,4,1]  R2349     -7.6892828941345215e-01
    z[5,4,1]  R2350     -7.2409129142761230e-01
    z[5,4,1]  R2351     2.1006102859973907e-01
    z[5,4,1]  R2352     -0.37724769115448
    z[5,4,1]  R2353     -2.4791140854358673e-01
    z[5,4,1]  R2354     -8.7415516376495361e-01
    z[5,4,1]  R2355     -8.2212585210800171e-01
    z[5,4,1]  R2356     -7.7263385057449341e-01
    z[5,4,1]  R2357     -8.1514602899551392e-01
    z[5,4,1]  R2358     -6.6241323947906494e-01
    z[5,4,1]  R2359     -5.7923221588134766e-01
    z[5,4,1]  R2360     -8.5195028781890869e-01
    z[5,4,2]  R40       1
    z[5,4,2]  R49       -1
    z[5,4,2]  R2271     -1
    z[5,4,2]  R2272     1
    z[5,4,2]  R2281     4.8482915759086609e-01
    z[5,4,2]  R2282     -9.0091131627559662e-02
    z[5,4,2]  R2283     7.8116357326507568e-01
    z[5,4,2]  R2284     1.9263638183474541e-02
    z[5,4,2]  R2285     8.7549078464508057e-01
    z[5,4,2]  R2286     1.1950641125440598e-01
    z[5,4,2]  R2287     0.636570155620575
    z[5,4,2]  R2288     -6.6055871546268463e-02
    z[5,4,2]  R2289     2.6292216777801514e-01
    z[5,4,2]  R2290     4.7815990447998047e-01
    z[5,4,2]  R2291     -3.6712530255317688e-01
    z[5,4,2]  R2292     -4.8442426323890686e-01
    z[5,4,2]  R2293     -8.3194905519485474e-01
    z[5,4,2]  R2294     -4.4412112236022949e-01
    z[5,4,2]  R2295     -8.4590762853622437e-02
    z[5,4,2]  R2296     -0.654270589351654
    z[5,4,2]  R2297     -4.4473114609718323e-01
    z[5,4,2]  R2298     -1.5737813711166382e-01
    z[5,4,2]  R2299     4.3987524509429932e-01
    z[5,4,2]  R2300     -0.320712685585022
    z[5,4,2]  R2301     2.4135455489158630e-01
    z[5,4,2]  R2302     -1.4329555444419384e-02
    z[5,4,2]  R2303     -4.6941635012626648e-01
    z[5,4,2]  R2304     -1.7301650345325470e-01
    z[5,4,2]  R2305     4.5983624458312988e-01
    z[5,4,2]  R2306     -0.0899103432893753
    z[5,4,2]  R2307     2.9243247583508492e-02
    z[5,4,2]  R2308     -3.3227629959583282e-02
    z[5,4,2]  R2309     4.6476915478706360e-01
    z[5,4,2]  R2310     3.0124038457870483e-01
    z[5,4,2]  R2311     8.7004798650741577e-01
    z[5,4,2]  R2312     -3.1570014357566833e-01
    z[5,4,2]  R2313     -3.2411649823188782e-01
    z[5,4,2]  R2314     -4.5273759961128235e-01
    z[5,4,2]  R2315     -3.1902936100959778e-01
    z[5,4,2]  R2316     -3.8057672977447510e-01
    z[5,4,2]  R2317     2.3256923258304596e-01
    z[5,4,2]  R2318     -5.2614736557006836e-01
    z[5,4,2]  R2319     3.5125121474266052e-02
    z[5,4,2]  R2320     -0.135227769613266
    z[5,4,2]  R2321     -6.6119629144668579e-01
    z[5,4,2]  R2322     2.4024224281311035e-01
    z[5,4,2]  R2323     -3.2324683666229248e-01
    z[5,4,2]  R2324     2.6352068781852722e-01
    z[5,4,2]  R2325     1.5180575847625732e-01
    z[5,4,2]  R2326     1.7123924195766449e-01
    z[5,4,2]  R2327     -3.2004401087760925e-02
    z[5,4,2]  R2328     4.7869232296943665e-01
    z[5,4,2]  R2329     3.6024913191795349e-01
    z[5,4,2]  R2330     6.1882162094116211e-01
    z[5,4,2]  R2331     -3.1423881649971008e-01
    z[5,4,2]  R2332     2.6292544603347778e-01
    z[5,4,2]  R2333     2.8887814283370972e-01
    z[5,4,2]  R2334     7.3006629943847656e-01
    z[5,4,2]  R2335     3.7077632546424866e-01
    z[5,4,2]  R2336     4.2833951115608215e-01
    z[5,4,2]  R2337     -2.1611212193965912e-01
    z[5,4,2]  R2338     7.2118914127349854e-01
    z[5,4,2]  R2339     4.2355710268020630e-01
    z[5,4,2]  R2340     3.1084164977073669e-01
    z[5,4,2]  R2341     -1.4423248171806335e-01
    z[5,4,2]  R2342     6.9796758890151978e-01
    z[5,4,2]  R2343     -4.3535566329956055e-01
    z[5,4,2]  R2344     -6.3349805772304535e-02
    z[5,4,2]  R2345     -2.9123482108116150e-01
    z[5,4,2]  R2346     -3.1179878115653992e-01
    z[5,4,2]  R2347     2.2285149991512299e-01
    z[5,4,2]  R2348     -0.224463552236557
    z[5,4,2]  R2349     -3.3415627479553223e-01
    z[5,4,2]  R2350     1.4328600466251373e-01
    z[5,4,2]  R2351     -4.3183878064155579e-01
    z[5,4,2]  R2352     -1.9323955476284027e-01
    z[5,4,2]  R2353     2.3670576512813568e-01
    z[5,4,2]  R2354     -4.6494167298078537e-02
    z[5,4,2]  R2355     -2.1576589345932007e-01
    z[5,4,2]  R2356     -1.8845294415950775e-01
    z[5,4,2]  R2357     8.5460282862186432e-02
    z[5,4,2]  R2358     9.2955529689788818e-02
    z[5,4,2]  R2359     1.5348492562770844e-01
    z[5,4,2]  R2360     3.5969346761703491e-01
    z[5,4,3]  R41       1
    z[5,4,3]  R50       -1
    z[5,4,3]  R2273     -1
    z[5,4,3]  R2274     1
    z[5,4,3]  R2281     -2.5866144895553589e-01
    z[5,4,3]  R2282     2.8459358215332031e-01
    z[5,4,3]  R2283     -2.8216877579689026e-01
    z[5,4,3]  R2284     -3.9917609095573425e-01
    z[5,4,3]  R2285     -4.4421613216400146e-02
    z[5,4,3]  R2286     3.2486149668693542e-01
    z[5,4,3]  R2287     2.8203946352005005e-01
    z[5,4,3]  R2288     7.6594430208206177e-01
    z[5,4,3]  R2289     7.3680356144905090e-02
    z[5,4,3]  R2290     -2.6583209633827209e-01
    z[5,4,3]  R2291     -2.9930931329727173e-01
    z[5,4,3]  R2292     3.0626082420349121e-01
    z[5,4,3]  R2293     1.1325030773878098e-01
    z[5,4,3]  R2294     -4.4818982481956482e-01
    z[5,4,3]  R2295     1.8112331628799438e-01
    z[5,4,3]  R2296     -2.3785674571990967e-01
    z[5,4,3]  R2297     -5.3479743003845215e-01
    z[5,4,3]  R2298     -0.523095965385437
    z[5,4,3]  R2299     1.0609175264835358e-01
    z[5,4,3]  R2300     -5.9104657173156738e-01
    z[5,4,3]  R2301     5.4408796131610870e-02
    z[5,4,3]  R2302     2.6956740021705627e-01
    z[5,4,3]  R2303     -2.3281428217887878e-01
    z[5,4,3]  R2304     2.6498386263847351e-01
    z[5,4,3]  R2305     -9.6142947673797607e-02
    z[5,4,3]  R2306     -5.0653403997421265e-01
    z[5,4,3]  R2307     -5.6126654148101807e-01
    z[5,4,3]  R2308     -5.6971663236618042e-01
    z[5,4,3]  R2309     -4.8686710000038147e-01
    z[5,4,3]  R2310     -1.4440187811851501e-01
    z[5,4,3]  R2311     -2.4330346286296844e-01
    z[5,4,3]  R2312     6.4088380336761475e-01
    z[5,4,3]  R2313     8.3118927478790283e-01
    z[5,4,3]  R2314     5.0202047824859619e-01
    z[5,4,3]  R2315     6.1825442314147949e-01
    z[5,4,3]  R2316     5.3561651706695557e-01
    z[5,4,3]  R2317     -2.1502526104450226e-01
    z[5,4,3]  R2318     3.4871095418930054e-01
    z[5,4,3]  R2319     6.1747943982481956e-03
    z[5,4,3]  R2320     -7.8910492360591888e-02
    z[5,4,3]  R2321     -4.9729026854038239e-02
    z[5,4,3]  R2322     -1.3379671610891819e-02
    z[5,4,3]  R2323     -3.6287495493888855e-01
    z[5,4,3]  R2324     -6.2828463315963745e-01
    z[5,4,3]  R2325     -7.9960060119628906e-01
    z[5,4,3]  R2326     -5.5615299940109253e-01
    z[5,4,3]  R2327     -8.0680477619171143e-01
    z[5,4,3]  R2328     -5.9920346736907959e-01
    z[5,4,3]  R2329     -4.7588801383972168e-01
    z[5,4,3]  R2330     -1.9305257499217987e-01
    z[5,4,3]  R2331     -2.4466849863529205e-01
    z[5,4,3]  R2332     -2.2717629373073578e-01
    z[5,4,3]  R2333     6.1988256871700287e-02
    z[5,4,3]  R2334     -4.9140679836273193e-01
    z[5,4,3]  R2335     -0.562491238117218
    z[5,4,3]  R2336     -6.5210080146789551e-01
    z[5,4,3]  R2337     2.4216838181018829e-01
    z[5,4,3]  R2338     -4.3520128726959229e-01
    z[5,4,3]  R2339     -5.5447423458099365e-01
    z[5,4,3]  R2340     -8.6597663164138794e-01
    z[5,4,3]  R2341     -8.7393987923860550e-03
    z[5,4,3]  R2342     -0.0466126874089241
    z[5,4,3]  R2343     1.2584270536899567e-01
    z[5,4,3]  R2344     3.3088415861129761e-01
    z[5,4,3]  R2345     -2.1796119399368763e-03
    z[5,4,3]  R2346     -2.2579845041036606e-02
    z[5,4,3]  R2347     -5.8057314157485962e-01
    z[5,4,3]  R2348     9.4112195074558258e-03
    z[5,4,3]  R2349     -1.8776719272136688e-01
    z[5,4,3]  R2350     -0.0934593677520752
    z[5,4,3]  R2351     1.7307612299919128e-01
    z[5,4,3]  R2352     8.0016024410724640e-02
    z[5,4,3]  R2353     -7.9326313734054565e-01
    z[5,4,3]  R2354     4.2148139327764511e-02
    z[5,4,3]  R2355     2.2905036807060242e-01
    z[5,4,3]  R2356     1.7671939730644226e-01
    z[5,4,3]  R2357     -5.6692283600568771e-02
    z[5,4,3]  R2358     2.2062557935714722e-01
    z[5,4,3]  R2359     2.2669243812561035e-01
    z[5,4,3]  R2360     -1.0020788758993149e-01
    z[5,4,4]  R42       1
    z[5,4,4]  R51       -1
    z[5,4,4]  R2275     -1
    z[5,4,4]  R2276     1
    z[5,4,4]  R2281     -2.9757422208786011e-01
    z[5,4,4]  R2282     2.0776192843914032e-01
    z[5,4,4]  R2283     -3.4446901082992554e-01
    z[5,4,4]  R2284     -3.9735859632492065e-01
    z[5,4,4]  R2285     1.4652957022190094e-01
    z[5,4,4]  R2286     5.7656061649322510e-01
    z[5,4,4]  R2287     3.5364833474159241e-01
    z[5,4,4]  R2288     -1.7526137828826904e-01
    z[5,4,4]  R2289     -3.2261142134666443e-01
    z[5,4,4]  R2290     6.1804372072219849e-01
    z[5,4,4]  R2291     4.1991323814727366e-04
    z[5,4,4]  R2292     -1.4301495254039764e-01
    z[5,4,4]  R2293     1.8313780426979065e-01
    z[5,4,4]  R2294     5.4839968681335449e-01
    z[5,4,4]  R2295     2.6046988368034363e-01
    z[5,4,4]  R2296     1.9126552343368530e-01
    z[5,4,4]  R2297     2.1001639962196350e-01
    z[5,4,4]  R2298     -4.0290430188179016e-01
    z[5,4,4]  R2299     -1.2991668283939362e-01
    z[5,4,4]  R2300     3.6405879259109497e-01
    z[5,4,4]  R2301     1.0645199567079544e-02
    z[5,4,4]  R2302     2.7664875984191895e-01
    z[5,4,4]  R2303     -5.1507055759429932e-01
    z[5,4,4]  R2304     -5.9713596105575562e-01
    z[5,4,4]  R2305     -1.3740111887454987e-01
    z[5,4,4]  R2306     3.2693885266780853e-02
    z[5,4,4]  R2307     2.0006994903087616e-01
    z[5,4,4]  R2308     -2.5432524085044861e-01
    z[5,4,4]  R2309     -1.9584493339061737e-01
    z[5,4,4]  R2310     -2.0171651244163513e-01
    z[5,4,4]  R2311     1.7166081070899963e-01
    z[5,4,4]  R2312     2.6555103063583374e-01
    z[5,4,4]  R2313     -3.5666882991790771e-01
    z[5,4,4]  R2314     6.2006723880767822e-01
    z[5,4,4]  R2315     7.9848326742649078e-02
    z[5,4,4]  R2316     5.8126222342252731e-02
    z[5,4,4]  R2317     5.9390628337860107e-01
    z[5,4,4]  R2318     -3.8776338100433350e-01
    z[5,4,4]  R2319     2.5676438584923744e-02
    z[5,4,4]  R2320     3.1820493936538696e-01
    z[5,4,4]  R2321     -1.7874620854854584e-01
    z[5,4,4]  R2322     -2.6201993227005005e-01
    z[5,4,4]  R2323     -1.4919523894786835e-01
    z[5,4,4]  R2324     -2.1776072680950165e-01
    z[5,4,4]  R2325     -3.7224754691123962e-01
    z[5,4,4]  R2326     5.7311993837356567e-01
    z[5,4,4]  R2327     3.3144921064376831e-01
    z[5,4,4]  R2328     -5.3990882635116577e-01
    z[5,4,4]  R2329     3.5976175218820572e-02
    z[5,4,4]  R2330     -0.162450909614563
    z[5,4,4]  R2331     2.7533066272735596e-01
    z[5,4,4]  R2332     2.1661397814750671e-01
    z[5,4,4]  R2333     -3.1194350123405457e-01
    z[5,4,4]  R2334     5.3216083906590939e-03
    z[5,4,4]  R2335     2.2346168756484985e-01
    z[5,4,4]  R2336     1.5192779898643494e-01
    z[5,4,4]  R2337     -2.9828497767448425e-01
    z[5,4,4]  R2338     0.280141681432724
    z[5,4,4]  R2339     -2.0264382660388947e-01
    z[5,4,4]  R2340     2.8758466243743896e-01
    z[5,4,4]  R2341     8.5873436182737350e-04
    z[5,4,4]  R2342     -1.1589819192886353e-01
    z[5,4,4]  R2343     -4.7125168144702911e-02
    z[5,4,4]  R2344     -5.8494526147842407e-01
    z[5,4,4]  R2345     -4.6181634068489075e-01
    z[5,4,4]  R2346     1.4247675240039825e-01
    z[5,4,4]  R2347     -1.6923119127750397e-01
    z[5,4,4]  R2348     -2.9892298579216003e-01
    z[5,4,4]  R2349     3.5811014473438263e-02
    z[5,4,4]  R2350     -1.5946429967880249e-01
    z[5,4,4]  R2351     -5.0564610958099365e-01
    z[5,4,4]  R2352     -1.6528847813606262e-01
    z[5,4,4]  R2353     -3.4734913706779480e-01
    z[5,4,4]  R2354     -2.7560099959373474e-01
    z[5,4,4]  R2355     1.1525370180606842e-01
    z[5,4,4]  R2356     -1.2992176413536072e-01
    z[5,4,4]  R2357     2.5555733591318130e-03
    z[5,4,4]  R2358     4.9524795264005661e-02
    z[5,4,4]  R2359     -1.4719154569320381e-04
    z[5,4,4]  R2360     2.0635944604873657e-01
    z[5,4,5]  R43       1
    z[5,4,5]  R52       -1
    z[5,4,5]  R2277     -1
    z[5,4,5]  R2278     1
    z[5,4,5]  R2281     -5.6988209486007690e-01
    z[5,4,5]  R2282     -6.3853855244815350e-03
    z[5,4,5]  R2283     -3.9604845643043518e-01
    z[5,4,5]  R2284     -1.6567985713481903e-01
    z[5,4,5]  R2285     -1.9466885924339294e-01
    z[5,4,5]  R2286     -9.0171068906784058e-02
    z[5,4,5]  R2287     2.6869205757975578e-02
    z[5,4,5]  R2288     2.1448722109198570e-02
    z[5,4,5]  R2289     -5.2375471591949463e-01
    z[5,4,5]  R2290     -5.0364631414413452e-01
    z[5,4,5]  R2291     4.7354102134704590e-01
    z[5,4,5]  R2292     6.2358152866363525e-01
    z[5,4,5]  R2293     -1.8069872260093689e-01
    z[5,4,5]  R2294     4.4689774513244629e-01
    z[5,4,5]  R2295     1.8895292282104492e-01
    z[5,4,5]  R2296     -2.3948937654495239e-01
    z[5,4,5]  R2297     4.0278565883636475e-01
    z[5,4,5]  R2298     3.9408656954765320e-01
    z[5,4,5]  R2299     3.2812082767486572e-01
    z[5,4,5]  R2300     -3.1141281127929688e-01
    z[5,4,5]  R2301     -1.1388673633337021e-01
    z[5,4,5]  R2302     -1.6845078766345978e-01
    z[5,4,5]  R2303     -1.9640058279037476e-01
    z[5,4,5]  R2304     -5.7908177375793457e-01
    z[5,4,5]  R2305     4.5114055275917053e-01
    z[5,4,5]  R2306     -2.2129443287849426e-01
    z[5,4,5]  R2307     3.0819091200828552e-01
    z[5,4,5]  R2308     2.7421155571937561e-01
    z[5,4,5]  R2309     1.5060122311115265e-01
    z[5,4,5]  R2310     1.3864484429359436e-01
    z[5,4,5]  R2311     -8.7248824536800385e-02
    z[5,4,5]  R2312     -3.4173485636711121e-01
    z[5,4,5]  R2313     -2.6238659024238586e-01
    z[5,4,5]  R2314     -3.4383806586265564e-01
    z[5,4,5]  R2315     9.3546412885189056e-02
    z[5,4,5]  R2316     -6.0945028066635132e-01
    z[5,4,5]  R2317     -4.6668532490730286e-01
    z[5,4,5]  R2318     3.9792710542678833e-01
    z[5,4,5]  R2319     1.2828531861305237e-01
    z[5,4,5]  R2320     9.0913869440555573e-02
    z[5,4,5]  R2321     4.4212940335273743e-01
    z[5,4,5]  R2322     7.7977198362350464e-01
    z[5,4,5]  R2323     -4.2695045471191406e-01
    z[5,4,5]  R2324     3.7409138679504395e-01
    z[5,4,5]  R2325     9.4170890748500824e-02
    z[5,4,5]  R2326     3.5449784994125366e-01
    z[5,4,5]  R2327     3.2058224081993103e-01
    z[5,4,5]  R2328     0.0108823636546731
    z[5,4,5]  R2329     -0.0410323366522789
    z[5,4,5]  R2330     5.7950407266616821e-02
    z[5,4,5]  R2331     -2.5654423981904984e-02
    z[5,4,5]  R2332     -3.8571065664291382e-01
    z[5,4,5]  R2333     -2.5312250852584839e-01
    z[5,4,5]  R2334     2.0238001644611359e-01
    z[5,4,5]  R2335     4.6938553452491760e-01
    z[5,4,5]  R2336     1.9093506038188934e-01
    z[5,4,5]  R2337     0.0532853901386261
    z[5,4,5]  R2338     2.6255580782890320e-01
    z[5,4,5]  R2339     2.5324231386184692e-01
    z[5,4,5]  R2340     2.3000319302082062e-01
    z[5,4,5]  R2341     -2.4678705632686615e-01
    z[5,4,5]  R2342     -3.2962822914123535e-01
    z[5,4,5]  R2343     2.6725775003433228e-01
    z[5,4,5]  R2344     -2.3675398528575897e-01
    z[5,4,5]  R2345     -6.3373476266860962e-02
    z[5,4,5]  R2346     2.2593397647142410e-02
    z[5,4,5]  R2347     4.6157222986221313e-01
    z[5,4,5]  R2348     -2.4501267075538635e-01
    z[5,4,5]  R2349     -2.2183151543140411e-01
    z[5,4,5]  R2350     -1.8626582622528076e-01
    z[5,4,5]  R2351     1.2021089345216751e-01
    z[5,4,5]  R2352     -1.2923605740070343e-01
    z[5,4,5]  R2353     2.9020580649375916e-01
    z[5,4,5]  R2354     -2.4687018990516663e-01
    z[5,4,5]  R2355     -7.4510313570499420e-02
    z[5,4,5]  R2356     1.5238919854164124e-01
    z[5,4,5]  R2357     -4.1781923174858093e-01
    z[5,4,5]  R2358     -2.3594839870929718e-01
    z[5,4,5]  R2359     1.7438188195228577e-01
    z[5,4,5]  R2360     -2.5090718269348145e-01
    z[5,4,6]  R44       1
    z[5,4,6]  R53       -1
    z[5,4,6]  R2279     -1
    z[5,4,6]  R2280     1
    z[5,4,6]  R2281     1.9051089882850647e-01
    z[5,4,6]  R2282     -0.38516765832901
    z[5,4,6]  R2283     1.3256359100341797e-01
    z[5,4,6]  R2284     -1.2602607905864716e-01
    z[5,4,6]  R2285     1.7144057154655457e-01
    z[5,4,6]  R2286     0.315448522567749
    z[5,4,6]  R2287     -9.9200025200843811e-02
    z[5,4,6]  R2288     1.7386473715305328e-01
    z[5,4,6]  R2289     -1.4328743517398834e-01
    z[5,4,6]  R2290     -7.7792368829250336e-02
    z[5,4,6]  R2291     -3.7168782949447632e-01
    z[5,4,6]  R2292     -3.5316473245620728e-01
    z[5,4,6]  R2293     -4.5230352878570557e-01
    z[5,4,6]  R2294     2.2273132205009460e-01
    z[5,4,6]  R2295     -2.3438625037670135e-01
    z[5,4,6]  R2296     3.4495303034782410e-01
    z[5,4,6]  R2297     3.2797396183013916e-01
    z[5,4,6]  R2298     4.9378228187561035e-01
    z[5,4,6]  R2299     4.6263146400451660e-01
    z[5,4,6]  R2300     2.4267353117465973e-01
    z[5,4,6]  R2301     -1.3771170750260353e-02
    z[5,4,6]  R2302     3.6265552043914795e-01
    z[5,4,6]  R2303     4.4650569558143616e-01
    z[5,4,6]  R2304     -2.8255870565772057e-02
    z[5,4,6]  R2305     2.0609153807163239e-01
    z[5,4,6]  R2306     0.0699809193611145
    z[5,4,6]  R2307     1.3407501578330994e-01
    z[5,4,6]  R2308     1.0127907991409302e-01
    z[5,4,6]  R2309     3.5682967305183411e-01
    z[5,4,6]  R2310     -3.8814684748649597e-01
    z[5,4,6]  R2311     -1.8227215111255646e-01
    z[5,4,6]  R2312     4.8308894038200378e-01
    z[5,4,6]  R2313     -5.2540283650159836e-03
    z[5,4,6]  R2314     -1.7118491232395172e-01
    z[5,4,6]  R2315     -1.2941205501556396e-01
    z[5,4,6]  R2316     0.259101003408432
    z[5,4,6]  R2317     2.1217225492000580e-01
    z[5,4,6]  R2318     -2.0377086102962494e-01
    z[5,4,6]  R2319     4.9424994736909866e-02
    z[5,4,6]  R2320     3.2052415609359741e-01
    z[5,4,6]  R2321     -1.9010773301124573e-01
    z[5,4,6]  R2322     8.6065813899040222e-02
    z[5,4,6]  R2323     -7.1420705318450928e-01
    z[5,4,6]  R2324     -3.7376844882965088e-01
    z[5,4,6]  R2325     -1.0020061582326889e-01
    z[5,4,6]  R2326     3.3467730879783630e-01
    z[5,4,6]  R2327     -3.2956176996231079e-01
    z[5,4,6]  R2328     2.2259773313999176e-01
    z[5,4,6]  R2329     -2.7017902582883835e-02
    z[5,4,6]  R2330     1.3021923601627350e-01
    z[5,4,6]  R2331     8.4782741963863373e-02
    z[5,4,6]  R2332     2.4156148731708527e-01
    z[5,4,6]  R2333     -4.8951196670532227e-01
    z[5,4,6]  R2334     -2.1152982115745544e-01
    z[5,4,6]  R2335     -0.0820658802986145
    z[5,4,6]  R2336     -3.3595755696296692e-02
    z[5,4,6]  R2337     -4.2025718092918396e-01
    z[5,4,6]  R2338     1.0127981007099152e-01
    z[5,4,6]  R2339     2.3284368216991425e-01
    z[5,4,6]  R2340     -4.9966756254434586e-02
    z[5,4,6]  R2341     1.9454509019851685e-01
    z[5,4,6]  R2342     2.5387939065694809e-02
    z[5,4,6]  R2343     -2.3479017615318298e-01
    z[5,4,6]  R2344     -5.6522661447525024e-01
    z[5,4,6]  R2345     -3.1581774353981018e-01
    z[5,4,6]  R2346     -1.6999433934688568e-01
    z[5,4,6]  R2347     -4.7128465771675110e-01
    z[5,4,6]  R2348     -1.0066631436347961e-01
    z[5,4,6]  R2349     1.6159044206142426e-01
    z[5,4,6]  R2350     -2.1938814222812653e-01
    z[5,4,6]  R2351     -5.0658637285232544e-01
    z[5,4,6]  R2352     -4.6783113479614258e-01
    z[5,4,6]  R2353     1.0208971798419952e-02
    z[5,4,6]  R2354     -1.2860514223575592e-01
    z[5,4,6]  R2355     3.4179106354713440e-01
    z[5,4,6]  R2356     -7.7363565564155579e-02
    z[5,4,6]  R2357     3.2385224103927612e-01
    z[5,4,6]  R2358     1.7104333639144897e-01
    z[5,4,6]  R2359     2.9971027374267578e-01
    z[5,4,6]  R2360     -0.0792362168431282
    z[6,7,0]  R56       -1
    z[6,7,0]  R65       1
    z[6,7,0]  R2405     -1
    z[6,7,0]  R2406     1
    z[6,7,0]  R2419     4.4110476970672607e-01
    z[6,7,0]  R2420     3.3901163935661316e-01
    z[6,7,0]  R2421     5.2272677421569824e-01
    z[6,7,0]  R2422     6.3964354991912842e-01
    z[6,7,0]  R2423     1.7448575794696808e-01
    z[6,7,0]  R2424     3.4932801127433777e-01
    z[6,7,0]  R2425     4.8197889328002930e-01
    z[6,7,0]  R2426     3.0211597681045532e-01
    z[6,7,0]  R2427     -2.7162078768014908e-02
    z[6,7,0]  R2428     6.8654817342758179e-01
    z[6,7,0]  R2429     -6.1936073005199432e-02
    z[6,7,0]  R2430     -1.7271035909652710e-01
    z[6,7,0]  R2431     -4.2474997043609619e-01
    z[6,7,0]  R2432     -1.7868795990943909e-01
    z[6,7,0]  R2433     -1.7778226733207703e-01
    z[6,7,0]  R2434     -3.4068015217781067e-01
    z[6,7,0]  R2435     -1.1456552892923355e-01
    z[6,7,0]  R2436     -1.4042910933494568e-01
    z[6,7,0]  R2437     -3.1393563747406006e-01
    z[6,7,0]  R2438     -7.5816917419433594e-01
    z[6,7,0]  R2439     -0.279852956533432
    z[6,7,0]  R2440     -9.2264115810394287e-02
    z[6,7,0]  R2441     8.9268334209918976e-02
    z[6,7,0]  R2442     -4.4528219103813171e-01
    z[6,7,0]  R2443     -2.0623424649238586e-01
    z[6,7,0]  R2444     -5.1273441314697266e-01
    z[6,7,0]  R2445     5.5959355831146240e-01
    z[6,7,0]  R2446     -6.4229393005371094e-01
    z[6,7,0]  R2447     4.3120759725570679e-01
    z[6,7,0]  R2448     -5.2551096677780151e-01
    z[6,7,0]  R2449     4.0983331203460693e-01
    z[6,7,0]  R2450     2.7934926748275757e-01
    z[6,7,0]  R2451     -6.5420351922512054e-02
    z[6,7,0]  R2452     -2.1329589188098907e-02
    z[6,7,0]  R2453     8.3455525338649750e-02
    z[6,7,0]  R2454     -2.1819558739662170e-01
    z[6,7,0]  R2455     -1.3673183321952820e-01
    z[6,7,0]  R2456     1.0967677831649780e-01
    z[6,7,0]  R2457     3.1910541653633118e-01
    z[6,7,0]  R2458     5.0385850667953491e-01
    z[6,7,0]  R2459     1.7317111790180206e-01
    z[6,7,0]  R2460     -1.8343149125576019e-01
    z[6,7,0]  R2461     -2.9323059320449829e-01
    z[6,7,0]  R2462     -4.5411375164985657e-01
    z[6,7,0]  R2463     -1.2677389383316040e-01
    z[6,7,0]  R2464     -5.2489918470382690e-01
    z[6,7,0]  R2465     -8.7438768148422241e-01
    z[6,7,0]  R2466     -7.0522385835647583e-01
    z[6,7,0]  R2467     -8.1494313478469849e-01
    z[6,7,0]  R2468     -2.6639264822006226e-01
    z[6,7,0]  R2469     -1.7448942363262177e-01
    z[6,7,0]  R2470     4.9027130007743835e-01
    z[6,7,0]  R2471     1.6009068489074707e-01
    z[6,7,0]  R2472     2.4896232783794403e-01
    z[6,7,0]  R2473     -7.0342606306076050e-01
    z[6,7,0]  R2474     -4.4413122534751892e-01
    z[6,7,0]  R2475     -3.1985759735107422e-01
    z[6,7,0]  R2476     -5.9791624546051025e-01
    z[6,7,0]  R2477     -5.5491024255752563e-01
    z[6,7,0]  R2478     -5.0269585847854614e-01
    z[6,7,0]  R2479     1.9270670600235462e-03
    z[6,7,0]  R2480     1.5989714860916138e-01
    z[6,7,0]  R2481     -1.4859504997730255e-01
    z[6,7,0]  R2482     -2.9126900434494019e-01
    z[6,7,0]  R2483     -1.5396639704704285e-01
    z[6,7,0]  R2484     -6.7126137018203735e-01
    z[6,7,0]  R2485     -0.634260892868042
    z[6,7,0]  R2486     -6.2756544351577759e-01
    z[6,7,0]  R2487     -8.7570679187774658e-01
    z[6,7,0]  R2488     -3.9466273784637451e-01
    z[6,7,0]  R2489     -0.875144362449646
    z[6,7,0]  R2490     -8.4285628795623779e-01
    z[6,7,0]  R2491     3.0327999591827393e-01
    z[6,7,0]  R2492     0.49473837018013
    z[6,7,0]  R2493     -0.752993643283844
    z[6,7,0]  R2494     -0.77369225025177
    z[6,7,0]  R2495     4.2660427093505859e-01
    z[6,7,0]  R2496     4.4296678900718689e-01
    z[6,7,0]  R2497     -9.2004263401031494e-01
    z[6,7,0]  R2498     4.6739596128463745e-01
    z[6,7,0]  R2499     2.0212334394454956e-01
    z[6,7,0]  R2500     1.2268134206533432e-01
    z[6,7,0]  R2501     -3.7628674507141113e-01
    z[6,7,0]  R2502     -1.9652925431728363e-02
    z[6,7,0]  R2503     0.600912868976593
    z[6,7,0]  R2504     -4.9089828133583069e-01
    z[6,7,0]  R2505     2.5963410735130310e-01
    z[6,7,0]  R2506     1.5229165554046631e-01
    z[6,7,0]  R2507     6.2417393922805786e-01
    z[6,7,0]  R2508     -0.00672629289329052
    z[6,7,0]  R2509     -5.8581322431564331e-01
    z[6,7,0]  R2510     3.2990756630897522e-01
    z[6,7,0]  R2511     -3.9063400030136108e-01
    z[6,7,0]  R2512     0.0756821483373642
    z[6,7,0]  R2513     -7.0084281265735626e-02
    z[6,7,0]  R2514     -2.7865487337112427e-01
    z[6,7,1]  R57       -1
    z[6,7,1]  R66       1
    z[6,7,1]  R2407     -1
    z[6,7,1]  R2408     1
    z[6,7,1]  R2419     -3.4781205654144287e-01
    z[6,7,1]  R2420     -4.5336815714836121e-01
    z[6,7,1]  R2421     -1.6562427580356598e-01
    z[6,7,1]  R2422     -2.9412621259689331e-01
    z[6,7,1]  R2423     -7.4184560775756836e-01
    z[6,7,1]  R2424     -5.8842420578002930e-01
    z[6,7,1]  R2425     -4.4590777158737183e-01
    z[6,7,1]  R2426     -3.2684186100959778e-01
    z[6,7,1]  R2427     8.6725711822509766e-01
    z[6,7,1]  R2428     -1.7752040922641754e-01
    z[6,7,1]  R2429     6.0188430547714233e-01
    z[6,7,1]  R2430     4.9670571088790894e-01
    z[6,7,1]  R2431     5.2763450145721436e-01
    z[6,7,1]  R2432     0.529279887676239
    z[6,7,1]  R2433     5.2224355936050415e-01
    z[6,7,1]  R2434     4.6737614274024963e-01
    z[6,7,1]  R2435     4.6169325709342957e-01
    z[6,7,1]  R2436     5.2379059791564941e-01
    z[6,7,1]  R2437     1.6510948538780212e-01
    z[6,7,1]  R2438     1.5629744529724121e-01
    z[6,7,1]  R2439     0.700522780418396
    z[6,7,1]  R2440     7.7344727516174316e-01
    z[6,7,1]  R2441     6.8620622158050537e-01
    z[6,7,1]  R2442     5.1303267478942871e-01
    z[6,7,1]  R2443     5.3101956844329834e-01
    z[6,7,1]  R2444     1.9648061692714691e-01
    z[6,7,1]  R2445     4.9735376238822937e-01
    z[6,7,1]  R2446     4.2687851190567017e-01
    z[6,7,1]  R2447     5.7654422521591187e-01
    z[6,7,1]  R2448     0.585563063621521
    z[6,7,1]  R2449     7.2807049751281738e-01
    z[6,7,1]  R2450     7.2795051336288452e-01
    z[6,7,1]  R2451     7.9143977165222168e-01
    z[6,7,1]  R2452     5.9142118692398071e-01
    z[6,7,1]  R2453     8.2396847009658813e-01
    z[6,7,1]  R2454     7.5865799188613892e-01
    z[6,7,1]  R2455     6.1866432428359985e-01
    z[6,7,1]  R2456     6.2044388055801392e-01
    z[6,7,1]  R2457     6.3771826028823853e-01
    z[6,7,1]  R2458     6.7984002828598022e-01
    z[6,7,1]  R2459     6.6794329881668091e-01
    z[6,7,1]  R2460     7.1713459491729736e-01
    z[6,7,1]  R2461     6.1718851327896118e-01
    z[6,7,1]  R2462     5.7492977380752563e-01
    z[6,7,1]  R2463     5.3688865900039673e-01
    z[6,7,1]  R2464     1.6145062446594238e-01
    z[6,7,1]  R2465     3.0128052830696106e-01
    z[6,7,1]  R2466     2.2331005334854126e-01
    z[6,7,1]  R2467     2.2012549638748169e-01
    z[6,7,1]  R2468     -4.5834100246429443e-01
    z[6,7,1]  R2469     6.2749165296554565e-01
    z[6,7,1]  R2470     7.1932464838027954e-01
    z[6,7,1]  R2471     6.8802893161773682e-01
    z[6,7,1]  R2472     4.7478458285331726e-01
    z[6,7,1]  R2473     3.2687309384346008e-01
    z[6,7,1]  R2474     1.3411889970302582e-01
    z[6,7,1]  R2475     1.7444875836372375e-01
    z[6,7,1]  R2476     -0.523600161075592
    z[6,7,1]  R2477     -2.7035170793533325e-01
    z[6,7,1]  R2478     -4.4116139411926270e-01
    z[6,7,1]  R2479     8.4566336870193481e-01
    z[6,7,1]  R2480     7.2292298078536987e-01
    z[6,7,1]  R2481     7.2194844484329224e-01
    z[6,7,1]  R2482     5.5753582715988159e-01
    z[6,7,1]  R2483     4.7758224606513977e-01
    z[6,7,1]  R2484     4.0005820989608765e-01
    z[6,7,1]  R2485     3.1105974316596985e-01
    z[6,7,1]  R2486     3.3201286196708679e-01
    z[6,7,1]  R2487     2.6688948273658752e-01
    z[6,7,1]  R2488     2.1507333219051361e-01
    z[6,7,1]  R2489     -3.2509317994117737e-01
    z[6,7,1]  R2490     -3.7371414899826050e-01
    z[6,7,1]  R2491     -1.4021454751491547e-01
    z[6,7,1]  R2492     -5.7073984295129776e-02
    z[6,7,1]  R2493     -3.5664337873458862e-01
    z[6,7,1]  R2494     -4.2401197552680969e-01
    z[6,7,1]  R2495     1.3849431276321411e-01
    z[6,7,1]  R2496     -5.0555467605590820e-01
    z[6,7,1]  R2497     -1.2142102420330048e-01
    z[6,7,1]  R2498     -8.8083013892173767e-02
    z[6,7,1]  R2499     2.7182260155677795e-01
    z[6,7,1]  R2500     -5.5153530836105347e-01
    z[6,7,1]  R2501     -1.0597542673349380e-01
    z[6,7,1]  R2502     7.0410065352916718e-02
    z[6,7,1]  R2503     -1.9849333167076111e-01
    z[6,7,1]  R2504     6.2866485118865967e-01
    z[6,7,1]  R2505     6.6600114107131958e-01
    z[6,7,1]  R2506     -7.1782833337783813e-01
    z[6,7,1]  R2507     2.1348838508129120e-01
    z[6,7,1]  R2508     6.4152634143829346e-01
    z[6,7,1]  R2509     1.6194520890712738e-01
    z[6,7,1]  R2510     4.6813324093818665e-01
    z[6,7,1]  R2511     2.2116348147392273e-01
    z[6,7,1]  R2512     -4.2823565006256104e-01
    z[6,7,1]  R2513     -7.7649158239364624e-01
    z[6,7,1]  R2514     5.6602191925048828e-01
    z[6,7,2]  R58       -1
    z[6,7,2]  R67       1
    z[6,7,2]  R2409     -1
    z[6,7,2]  R2410     1
    z[6,7,2]  R2419     7.3024737834930420e-01
    z[6,7,2]  R2420     6.4887338876724243e-01
    z[6,7,2]  R2421     7.5980907678604126e-01
    z[6,7,2]  R2422     4.9294778704643250e-01
    z[6,7,2]  R2423     0.561560869216919
    z[6,7,2]  R2424     5.1509636640548706e-01
    z[6,7,2]  R2425     4.7796097397804260e-01
    z[6,7,2]  R2426     4.7889927029609680e-01
    z[6,7,2]  R2427     -2.6386895775794983e-01
    z[6,7,2]  R2428     2.3604415357112885e-01
    z[6,7,2]  R2429     1.4005483686923981e-01
    z[6,7,2]  R2430     -1.2100974470376968e-01
    z[6,7,2]  R2431     2.4701626598834991e-01
    z[6,7,2]  R2432     2.2184227406978607e-01
    z[6,7,2]  R2433     2.1186850965023041e-01
    z[6,7,2]  R2434     1.0004695504903793e-02
    z[6,7,2]  R2435     -1.4007289707660675e-01
    z[6,7,2]  R2436     -2.6390699669718742e-02
    z[6,7,2]  R2437     -8.2079136371612549e-01
    z[6,7,2]  R2438     -3.0513361096382141e-01
    z[6,7,2]  R2439     1.3260711729526520e-01
    z[6,7,2]  R2440     4.3324571847915649e-01
    z[6,7,2]  R2441     9.5791496336460114e-02
    z[6,7,2]  R2442     -4.3592703342437744e-01
    z[6,7,2]  R2443     -7.1677841246128082e-02
    z[6,7,2]  R2444     -0.585075855255127
    z[6,7,2]  R2445     1.4758314192295074e-01
    z[6,7,2]  R2446     -4.2893978953361511e-01
    z[6,7,2]  R2447     3.5841426253318787e-01
    z[6,7,2]  R2448     -7.8127644956111908e-02
    z[6,7,2]  R2449     2.0337031781673431e-01
    z[6,7,2]  R2450     2.7745169401168823e-01
    z[6,7,2]  R2451     -3.3047281205654144e-02
    z[6,7,2]  R2452     -4.7553098201751709e-01
    z[6,7,2]  R2453     7.8497342765331268e-02
    z[6,7,2]  R2454     0.196327343583107
    z[6,7,2]  R2455     -2.2312331199645996e-01
    z[6,7,2]  R2456     -1.5412187576293945e-01
    z[6,7,2]  R2457     -1.4433591067790985e-01
    z[6,7,2]  R2458     3.6017143726348877e-01
    z[6,7,2]  R2459     -1.4645195007324219e-01
    z[6,7,2]  R2460     7.0014052093029022e-02
    z[6,7,2]  R2461     5.3152061998844147e-02
    z[6,7,2]  R2462     -0.342255175113678
    z[6,7,2]  R2463     -2.1780113875865936e-01
    z[6,7,2]  R2464     -6.9982111454010010e-01
    z[6,7,2]  R2465     -1.4328017830848694e-01
    z[6,7,2]  R2466     -2.4706965684890747e-01
    z[6,7,2]  R2467     8.7146468460559845e-02
    z[6,7,2]  R2468     -3.1852287054061890e-01
    z[6,7,2]  R2469     -3.0735307931900024e-01
    z[6,7,2]  R2470     1.8711790442466736e-01
    z[6,7,2]  R2471     -1.2212514411658049e-03
    z[6,7,2]  R2472     5.8216166496276855e-01
    z[6,7,2]  R2473     -1.7080813646316528e-01
    z[6,7,2]  R2474     -5.5677533149719238e-02
    z[6,7,2]  R2475     -0.00486822659149766
    z[6,7,2]  R2476     9.9580520763993263e-03
    z[6,7,2]  R2477     -0.0617239810526371
    z[6,7,2]  R2478     -1.9903749227523804e-01
    z[6,7,2]  R2479     2.5639909505844116e-01
    z[6,7,2]  R2480     2.2625628858804703e-02
    z[6,7,2]  R2481     -3.9600737392902374e-02
    z[6,7,2]  R2482     -4.6437847614288330e-01
    z[6,7,2]  R2483     -5.7949042320251465e-01
    z[6,7,2]  R2484     -2.7532967925071716e-01
    z[6,7,2]  R2485     -1.9601751863956451e-01
    z[6,7,2]  R2486     -9.1783374547958374e-02
    z[6,7,2]  R2487     -0.0622575469315052
    z[6,7,2]  R2488     -3.6990141868591309e-01
    z[6,7,2]  R2489     -8.3633601665496826e-02
    z[6,7,2]  R2490     -1.8221169710159302e-01
    z[6,7,2]  R2491     1.1443043500185013e-01
    z[6,7,2]  R2492     -7.1232281625270844e-03
    z[6,7,2]  R2493     4.2429044842720032e-01
    z[6,7,2]  R2494     2.5737419724464417e-01
    z[6,7,2]  R2495     0.021140206605196
    z[6,7,2]  R2496     1.1720012128353119e-01
    z[6,7,2]  R2497     1.7755547165870667e-01
    z[6,7,2]  R2498     -2.3838618397712708e-01
    z[6,7,2]  R2499     0.489644855260849
    z[6,7,2]  R2500     -6.5385311841964722e-01
    z[6,7,2]  R2501     4.6000808477401733e-01
    z[6,7,2]  R2502     -0.362640917301178
    z[6,7,2]  R2503     -2.2667229175567627e-01
    z[6,7,2]  R2504     -3.2671579718589783e-01
    z[6,7,2]  R2505     -6.1208885908126831e-01
    z[6,7,2]  R2506     4.4338649511337280e-01
    z[6,7,2]  R2507     -2.5458136200904846e-01
    z[6,7,2]  R2508     4.2926692962646484e-01
    z[6,7,2]  R2509     -2.9571041464805603e-01
    z[6,7,2]  R2510     -5.3677827119827271e-01
    z[6,7,2]  R2511     -4.1452956199645996e-01
    z[6,7,2]  R2512     2.5877401232719421e-01
    z[6,7,2]  R2513     1.3095535337924957e-01
    z[6,7,2]  R2514     3.1691205501556396e-01
    z[6,7,3]  R59       -1
    z[6,7,3]  R68       1
    z[6,7,3]  R2411     -1
    z[6,7,3]  R2412     1
    z[6,7,3]  R2419     0.336246132850647
    z[6,7,3]  R2420     3.3790368586778641e-02
    z[6,7,3]  R2421     1.8210436403751373e-01
    z[6,7,3]  R2422     2.6490703225135803e-01
    z[6,7,3]  R2423     1.2282897531986237e-01
    z[6,7,3]  R2424     2.3171609640121460e-01
    z[6,7,3]  R2425     1.9285863637924194e-01
    z[6,7,3]  R2426     5.6925266981124878e-01
    z[6,7,3]  R2427     -2.0015256106853485e-01
    z[6,7,3]  R2428     3.7729573249816895e-01
    z[6,7,3]  R2429     2.9598088003695011e-03
    z[6,7,3]  R2430     3.4835198521614075e-01
    z[6,7,3]  R2431     1.5558812022209167e-01
    z[6,7,3]  R2432     2.9040387272834778e-01
    z[6,7,3]  R2433     3.7722852826118469e-01
    z[6,7,3]  R2434     3.2994246482849121e-01
    z[6,7,3]  R2435     1.3568203151226044e-01
    z[6,7,3]  R2436     0.705918550491333
    z[6,7,3]  R2437     3.3525240421295166e-01
    z[6,7,3]  R2438     -2.5709119439125061e-01
    z[6,7,3]  R2439     1.7381575703620911e-01
    z[6,7,3]  R2440     -2.7148360013961792e-01
    z[6,7,3]  R2441     -9.1571047902107239e-02
    z[6,7,3]  R2442     5.1690524816513062e-01
    z[6,7,3]  R2443     6.6644591093063354e-01
    z[6,7,3]  R2444     -5.8813279867172241e-01
    z[6,7,3]  R2445     -2.9042765498161316e-01
    z[6,7,3]  R2446     -6.5719529986381531e-02
    z[6,7,3]  R2447     -3.1762981414794922e-01
    z[6,7,3]  R2448     5.0791448354721069e-01
    z[6,7,3]  R2449     4.5159086585044861e-01
    z[6,7,3]  R2450     1.4282864332199097e-01
    z[6,7,3]  R2451     -3.9496548473834991e-02
    z[6,7,3]  R2452     4.8942431807518005e-01
    z[6,7,3]  R2453     1.5942543745040894e-02
    z[6,7,3]  R2454     1.8004053831100464e-01
    z[6,7,3]  R2455     4.3607655167579651e-01
    z[6,7,3]  R2456     6.8976312875747681e-01
    z[6,7,3]  R2457     4.6873083710670471e-01
    z[6,7,3]  R2458     -2.3597058653831482e-01
    z[6,7,3]  R2459     -8.0088503658771515e-02
    z[6,7,3]  R2460     -4.7161877155303955e-01
    z[6,7,3]  R2461     1.7595584690570831e-01
    z[6,7,3]  R2462     3.2299000024795532e-01
    z[6,7,3]  R2463     2.6775670051574707e-01
    z[6,7,3]  R2464     3.1743991374969482e-01
    z[6,7,3]  R2465     -6.0094580054283142e-02
    z[6,7,3]  R2466     -2.7603381872177124e-01
    z[6,7,3]  R2467     2.6966568827629089e-01
    z[6,7,3]  R2468     -7.0699453353881836e-01
    z[6,7,3]  R2469     5.0980645418167114e-01
    z[6,7,3]  R2470     1.3615450263023376e-01
    z[6,7,3]  R2471     4.0435156226158142e-01
    z[6,7,3]  R2472     2.5491121411323547e-01
    z[6,7,3]  R2473     2.4826650321483612e-01
    z[6,7,3]  R2474     -7.4099951982498169e-01
    z[6,7,3]  R2475     -8.2505196332931519e-01
    z[6,7,3]  R2476     -4.7321224212646484e-01
    z[6,7,3]  R2477     -0.572223961353302
    z[6,7,3]  R2478     -5.6724369525909424e-01
    z[6,7,3]  R2479     -5.7623300701379776e-02
    z[6,7,3]  R2480     0.425167053937912
    z[6,7,3]  R2481     5.2429586648941040e-01
    z[6,7,3]  R2482     2.2048802673816681e-01
    z[6,7,3]  R2483     -2.1327883005142212e-01
    z[6,7,3]  R2484     -2.3043704032897949e-01
    z[6,7,3]  R2485     -5.8678174018859863e-01
    z[6,7,3]  R2486     -3.4693691134452820e-01
    z[6,7,3]  R2487     2.3797741532325745e-01
    z[6,7,3]  R2488     -5.7473677396774292e-01
    z[6,7,3]  R2489     2.1107150614261627e-01
    z[6,7,3]  R2490     1.2576033174991608e-01
    z[6,7,3]  R2491     3.3855074644088745e-01
    z[6,7,3]  R2492     6.2545055150985718e-01
    z[6,7,3]  R2493     -2.8825110197067261e-01
    z[6,7,3]  R2494     -6.9849081337451935e-02
    z[6,7,3]  R2495     -2.2724264860153198e-01
    z[6,7,3]  R2496     -4.1251521557569504e-02
    z[6,7,3]  R2497     -1.6425649821758270e-01
    z[6,7,3]  R2498     1.4775149524211884e-01
    z[6,7,3]  R2499     -2.7906140685081482e-01
    z[6,7,3]  R2500     -1.4813390374183655e-01
    z[6,7,3]  R2501     -4.4711455702781677e-03
    z[6,7,3]  R2502     1.3549655675888062e-01
    z[6,7,3]  R2503     -6.8883955478668213e-02
    z[6,7,3]  R2504     -2.3259213566780090e-01
    z[6,7,3]  R2505     1.3596434891223907e-01
    z[6,7,3]  R2506     3.0119559168815613e-01
    z[6,7,3]  R2507     4.7901353240013123e-01
    z[6,7,3]  R2508     -1.2442321516573429e-02
    z[6,7,3]  R2509     -4.5735651254653931e-01
    z[6,7,3]  R2510     -1.4352932572364807e-01
    z[6,7,3]  R2511     -7.3164153099060059e-01
    z[6,7,3]  R2512     -4.7864401340484619e-01
    z[6,7,3]  R2513     0.517343282699585
    z[6,7,3]  R2514     3.3343502879142761e-01
    z[6,7,4]  R60       -1
    z[6,7,4]  R69       1
    z[6,7,4]  R2413     -1
    z[6,7,4]  R2414     1
    z[6,7,4]  R2419     -1.9321829080581665e-01
    z[6,7,4]  R2420     -3.2461011409759521e-01
    z[6,7,4]  R2421     -1.3278612494468689e-01
    z[6,7,4]  R2422     -0.0118703069165349
    z[6,7,4]  R2423     -2.2214166820049286e-01
    z[6,7,4]  R2424     -2.7712747454643250e-01
    z[6,7,4]  R2425     1.8192107975482941e-01
    z[6,7,4]  R2426     -1.8020243942737579e-01
    z[6,7,4]  R2427     3.1285938620567322e-01
    z[6,7,4]  R2428     3.2869994640350342e-01
    z[6,7,4]  R2429     -0.469272255897522
    z[6,7,4]  R2430     -5.0573742389678955e-01
    z[6,7,4]  R2431     -0.673651397228241
    z[6,7,4]  R2432     -5.4611217975616455e-01
    z[6,7,4]  R2433     -6.1120033264160156e-01
    z[6,7,4]  R2434     -6.5022456645965576e-01
    z[6,7,4]  R2435     -1.9623193144798279e-01
    z[6,7,4]  R2436     -4.0855661034584045e-01
    z[6,7,4]  R2437     1.0501979850232601e-02
    z[6,7,4]  R2438     -3.9771673083305359e-01
    z[6,7,4]  R2439     -3.6315000057220459e-01
    z[6,7,4]  R2440     -2.2095610201358795e-01
    z[6,7,4]  R2441     -1.9793076813220978e-01
    z[6,7,4]  R2442     -2.4136649072170258e-01
    z[6,7,4]  R2443     -1.5399551391601562e-01
    z[6,7,4]  R2444     7.9972252249717712e-02
    z[6,7,4]  R2445     3.1315460801124573e-01
    z[6,7,4]  R2446     -3.2879498600959778e-01
    z[6,7,4]  R2447     1.6948254406452179e-01
    z[6,7,4]  R2448     -1.8101902306079865e-01
    z[6,7,4]  R2449     -1.0094108991324902e-02
    z[6,7,4]  R2450     -1.5355275571346283e-01
    z[6,7,4]  R2451     -1.4392051100730896e-01
    z[6,7,4]  R2452     -1.3392525725066662e-02
    z[6,7,4]  R2453     -2.5080311298370361e-01
    z[6,7,4]  R2454     -3.9165604114532471e-01
    z[6,7,4]  R2455     -2.1455757319927216e-01
    z[6,7,4]  R2456     8.1501238048076630e-02
    z[6,7,4]  R2457     -1.5934186056256294e-02
    z[6,7,4]  R2458     1.5481737256050110e-01
    z[6,7,4]  R2459     0.0746997743844986
    z[6,7,4]  R2460     -2.7021676301956177e-01
    z[6,7,4]  R2461     -7.6813362538814545e-02
    z[6,7,4]  R2462     -1.2768602371215820e-01
    z[6,7,4]  R2463     -4.0867531299591064e-01
    z[6,7,4]  R2464     8.3716578781604767e-02
    z[6,7,4]  R2465     2.8910359740257263e-01
    z[6,7,4]  R2466     -1.3713514804840088e-01
    z[6,7,4]  R2467     3.2937932014465332e-01
    z[6,7,4]  R2468     7.1384929120540619e-02
    z[6,7,4]  R2469     -2.1763689815998077e-02
    z[6,7,4]  R2470     3.2222241163253784e-01
    z[6,7,4]  R2471     0.0884227603673935
    z[6,7,4]  R2472     7.1762814186513424e-03
    z[6,7,4]  R2473     3.3743911981582642e-01
    z[6,7,4]  R2474     4.5541308820247650e-02
    z[6,7,4]  R2475     -1.0859984159469604e-01
    z[6,7,4]  R2476     3.4488552808761597e-01
    z[6,7,4]  R2477     3.4778553247451782e-01
    z[6,7,4]  R2478     -2.7931997179985046e-01
    z[6,7,4]  R2479     -3.2818517088890076e-01
    z[6,7,4]  R2480     0.0850084200501442
    z[6,7,4]  R2481     -3.6288848519325256e-01
    z[6,7,4]  R2482     -1.4695268869400024e-01
    z[6,7,4]  R2483     1.9674357026815414e-03
    z[6,7,4]  R2484     -4.7718450427055359e-01
    z[6,7,4]  R2485     -2.0010271668434143e-01
    z[6,7,4]  R2486     -1.2761971354484558e-01
    z[6,7,4]  R2487     8.7412588298320770e-02
    z[6,7,4]  R2488     1.0059091448783875e-01
    z[6,7,4]  R2489     1.9864018261432648e-01
    z[6,7,4]  R2490     1.1640612035989761e-01
    z[6,7,4]  R2491     2.6952770352363586e-01
    z[6,7,4]  R2492     -7.7194280922412872e-02
    z[6,7,4]  R2493     1.9731834530830383e-01
    z[6,7,4]  R2494     2.3781789839267731e-01
    z[6,7,4]  R2495     4.3728187680244446e-01
    z[6,7,4]  R2496     2.4609817564487457e-01
    z[6,7,4]  R2497     -2.6951423287391663e-01
    z[6,7,4]  R2498     -1.8707261979579926e-01
    z[6,7,4]  R2499     -4.1319724172353745e-02
    z[6,7,4]  R2500     -1.4623653143644333e-02
    z[6,7,4]  R2501     -7.5215756893157959e-01
    z[6,7,4]  R2502     -8.8260918855667114e-01
    z[6,7,4]  R2503     -5.8108150959014893e-01
    z[6,7,4]  R2504     3.1479981541633606e-01
    z[6,7,4]  R2505     2.9891505837440491e-01
    z[6,7,4]  R2506     3.9248377084732056e-01
    z[6,7,4]  R2507     4.9551013112068176e-01
    z[6,7,4]  R2508     1.4640846848487854e-01
    z[6,7,4]  R2509     1.4568759500980377e-01
    z[6,7,4]  R2510     3.9291998744010925e-01
    z[6,7,4]  R2511     8.3928229287266731e-03
    z[6,7,4]  R2512     5.3994381427764893e-01
    z[6,7,4]  R2513     3.2386413216590881e-01
    z[6,7,4]  R2514     2.9771456122398376e-01
    z[6,7,5]  R61       -1
    z[6,7,5]  R70       1
    z[6,7,5]  R2415     -1
    z[6,7,5]  R2416     1
    z[6,7,5]  R2419     -1.0714598465710878e-03
    z[6,7,5]  R2420     -3.8282147049903870e-01
    z[6,7,5]  R2421     -1.4236196875572205e-01
    z[6,7,5]  R2422     -3.1125918030738831e-01
    z[6,7,5]  R2423     1.1419694125652313e-01
    z[6,7,5]  R2424     -2.9830756783485413e-01
    z[6,7,5]  R2425     6.5622150897979736e-02
    z[6,7,5]  R2426     -3.1495410948991776e-02
    z[6,7,5]  R2427     1.6625548899173737e-01
    z[6,7,5]  R2428     0.00990427378565073
    z[6,7,5]  R2429     -4.4501629471778870e-01
    z[6,7,5]  R2430     -0.575872540473938
    z[6,7,5]  R2431     -1.5416010282933712e-02
    z[6,7,5]  R2432     -6.1678472906351089e-02
    z[6,7,5]  R2433     -2.0075160264968872e-01
    z[6,7,5]  R2434     -3.1188848614692688e-01
    z[6,7,5]  R2435     -2.4093411862850189e-02
    z[6,7,5]  R2436     -0.0340031236410141
    z[6,7,5]  R2437     -2.8606840968132019e-01
    z[6,7,5]  R2438     1.5666624903678894e-01
    z[6,7,5]  R2439     1.9608432427048683e-02
    z[6,7,5]  R2440     1.4477960765361786e-01
    z[6,7,5]  R2441     -5.5478483438491821e-01
    z[6,7,5]  R2442     8.9255966246128082e-02
    z[6,7,5]  R2443     4.4888880848884583e-01
    z[6,7,5]  R2444     -5.8699328452348709e-02
    z[6,7,5]  R2445     -3.1769070029258728e-01
    z[6,7,5]  R2446     5.2408918738365173e-02
    z[6,7,5]  R2447     -4.2835228145122528e-02
    z[6,7,5]  R2448     -2.4383455514907837e-01
    z[6,7,5]  R2449     -2.2099788486957550e-01
    z[6,7,5]  R2450     -1.8712574243545532e-01
    z[6,7,5]  R2451     -3.2201047986745834e-02
    z[6,7,5]  R2452     -3.7080207467079163e-01
    z[6,7,5]  R2453     -4.9428188800811768e-01
    z[6,7,5]  R2454     1.7356021702289581e-01
    z[6,7,5]  R2455     -1.0440428741276264e-02
    z[6,7,5]  R2456     1.2030643969774246e-01
    z[6,7,5]  R2457     -0.459465891122818
    z[6,7,5]  R2458     -2.4612739682197571e-01
    z[6,7,5]  R2459     -5.3476333618164062e-01
    z[6,7,5]  R2460     -2.6849892735481262e-01
    z[6,7,5]  R2461     6.7392992973327637e-01
    z[6,7,5]  R2462     4.2553851008415222e-01
    z[6,7,5]  R2463     -6.3333910703659058e-01
    z[6,7,5]  R2464     1.9187904894351959e-01
    z[6,7,5]  R2465     -0.0735400915145874
    z[6,7,5]  R2466     5.2827745676040649e-01
    z[6,7,5]  R2467     0.305154412984848
    z[6,7,5]  R2468     -1.9441099464893341e-01
    z[6,7,5]  R2469     3.0759319663047791e-01
    z[6,7,5]  R2470     -1.1642579920589924e-02
    z[6,7,5]  R2471     2.8545862436294556e-01
    z[6,7,5]  R2472     5.5168390274047852e-01
    z[6,7,5]  R2473     -2.1335309743881226e-01
    z[6,7,5]  R2474     4.4023346900939941e-01
    z[6,7,5]  R2475     -2.2197972238063812e-01
    z[6,7,5]  R2476     -1.5570557117462158e-01
    z[6,7,5]  R2477     -3.9092016220092773e-01
    z[6,7,5]  R2478     -2.8752014040946960e-01
    z[6,7,5]  R2479     -2.1267127990722656e-01
    z[6,7,5]  R2480     3.0411267280578613e-01
    z[6,7,5]  R2481     -1.5266118943691254e-01
    z[6,7,5]  R2482     -0.0618041455745697
    z[6,7,5]  R2483     -5.9121972322463989e-01
    z[6,7,5]  R2484     -1.7312206327915192e-01
    z[6,7,5]  R2485     2.2901852428913116e-01
    z[6,7,5]  R2486     5.8368885517120361e-01
    z[6,7,5]  R2487     2.1584718488156796e-03
    z[6,7,5]  R2488     2.1394230425357819e-01
    z[6,7,5]  R2489     -1.5223556756973267e-01
    z[6,7,5]  R2490     -2.9553923010826111e-01
    z[6,7,5]  R2491     -8.2567328214645386e-01
    z[6,7,5]  R2492     -5.8892178535461426e-01
    z[6,7,5]  R2493     0.0102920550853014
    z[6,7,5]  R2494     -1.5354523062705994e-01
    z[6,7,5]  R2495     -7.4437719583511353e-01
    z[6,7,5]  R2496     -6.2923544645309448e-01
    z[6,7,5]  R2497     1.0003616334870458e-03
    z[6,7,5]  R2498     -7.8459191322326660e-01
    z[6,7,5]  R2499     3.2752317190170288e-01
    z[6,7,5]  R2500     2.9305151104927063e-01
    z[6,7,5]  R2501     0.25819131731987
    z[6,7,5]  R2502     1.6984629631042480e-01
    z[6,7,5]  R2503     1.3491080701351166e-01
    z[6,7,5]  R2504     1.9046208262443542e-01
    z[6,7,5]  R2505     7.5718492269515991e-02
    z[6,7,5]  R2506     1.3869504630565643e-01
    z[6,7,5]  R2507     6.6094011999666691e-03
    z[6,7,5]  R2508     -1.0102125257253647e-01
    z[6,7,5]  R2509     5.5727428197860718e-01
    z[6,7,5]  R2510     4.5685586333274841e-01
    z[6,7,5]  R2511     -1.7816029489040375e-01
    z[6,7,5]  R2512     4.1981360316276550e-01
    z[6,7,5]  R2513     -6.5648332238197327e-03
    z[6,7,5]  R2514     -2.5988611578941345e-01
    z[6,7,6]  R62       -1
    z[6,7,6]  R71       1
    z[6,7,6]  R2417     -1
    z[6,7,6]  R2418     1
    z[6,7,6]  R2419     -2.8217405080795288e-02
    z[6,7,6]  R2420     -7.3660515248775482e-02
    z[6,7,6]  R2421     -2.2573101520538330e-01
    z[6,7,6]  R2422     3.0683785676956177e-01
    z[6,7,6]  R2423     1.6246375441551208e-01
    z[6,7,6]  R2424     2.1661767363548279e-01
    z[6,7,6]  R2425     -5.1557719707489014e-01
    z[6,7,6]  R2426     -4.6372652053833008e-01
    z[6,7,6]  R2427     -1.0916743427515030e-01
    z[6,7,6]  R2428     4.3695256114006042e-01
    z[6,7,6]  R2429     4.4274058938026428e-01
    z[6,7,6]  R2430     -7.9112062230706215e-03
    z[6,7,6]  R2431     0.0438268817961216
    z[6,7,6]  R2432     5.0233691930770874e-01
    z[6,7,6]  R2433     3.0756852030754089e-01
    z[6,7,6]  R2434     1.9096605479717255e-01
    z[6,7,6]  R2435     8.3462363481521606e-01
    z[6,7,6]  R2436     1.9705511629581451e-01
    z[6,7,6]  R2437     7.8390344977378845e-02
    z[6,7,6]  R2438     2.4253916740417480e-01
    z[6,7,6]  R2439     -5.0089037418365479e-01
    z[6,7,6]  R2440     -2.4915599822998047e-01
    z[6,7,6]  R2441     -3.9576271176338196e-01
    z[6,7,6]  R2442     -1.2277390062808990e-01
    z[6,7,6]  R2443     3.1337331980466843e-02
    z[6,7,6]  R2444     -2.1065460518002510e-02
    z[6,7,6]  R2445     3.6656796932220459e-01
    z[6,7,6]  R2446     3.2568693161010742e-01
    z[6,7,6]  R2447     4.7090139985084534e-01
    z[6,7,6]  R2448     1.5700249373912811e-01
    z[6,7,6]  R2449     -0.0878305733203888
    z[6,7,6]  R2450     4.8587873578071594e-01
    z[6,7,6]  R2451     5.8731693029403687e-01
    z[6,7,6]  R2452     -2.1546836197376251e-01
    z[6,7,6]  R2453     -2.1871086210012436e-02
    z[6,7,6]  R2454     3.4978860616683960e-01
    z[6,7,6]  R2455     5.5898851156234741e-01
    z[6,7,6]  R2456     -2.8701499104499817e-01
    z[6,7,6]  R2457     1.9895464181900024e-01
    z[6,7,6]  R2458     1.1828528344631195e-01
    z[6,7,6]  R2459     -4.5216059684753418e-01
    z[6,7,6]  R2460     2.8219836950302124e-01
    z[6,7,6]  R2461     1.9805730879306793e-01
    z[6,7,6]  R2462     2.1068581938743591e-01
    z[6,7,6]  R2463     0.0917283371090889
    z[6,7,6]  R2464     2.5312221050262451e-01
    z[6,7,6]  R2465     -1.7761354148387909e-01
    z[6,7,6]  R2466     -1.3293136656284332e-01
    z[6,7,6]  R2467     7.4083633720874786e-02
    z[6,7,6]  R2468     2.7343901991844177e-01
    z[6,7,6]  R2469     3.5546016693115234e-01
    z[6,7,6]  R2470     -2.9101896286010742e-01
    z[6,7,6]  R2471     4.9817708134651184e-01
    z[6,7,6]  R2472     0.06556436419487
    z[6,7,6]  R2473     3.8490161299705505e-01
    z[6,7,6]  R2474     1.9157165288925171e-01
    z[6,7,6]  R2475     -3.5419678688049316e-01
    z[6,7,6]  R2476     -3.3462695777416229e-02
    z[6,7,6]  R2477     -1.1815723776817322e-01
    z[6,7,6]  R2478     -1.7494225502014160e-01
    z[6,7,6]  R2479     2.5070744752883911e-01
    z[6,7,6]  R2480     4.1331019997596741e-01
    z[6,7,6]  R2481     -1.5894058346748352e-01
    z[6,7,6]  R2482     5.6092691421508789e-01
    z[6,7,6]  R2483     1.3178764283657074e-01
    z[6,7,6]  R2484     -5.2704453468322754e-02
    z[6,7,6]  R2485     1.6040150821208954e-01
    z[6,7,6]  R2486     -1.0079844295978546e-01
    z[6,7,6]  R2487     3.0619084835052490e-01
    z[6,7,6]  R2488     5.2435255050659180e-01
    z[6,7,6]  R2489     1.1940453946590424e-01
    z[6,7,6]  R2490     4.5191212557256222e-03
    z[6,7,6]  R2491     7.9175412654876709e-02
    z[6,7,6]  R2492     8.9159548282623291e-02
    z[6,7,6]  R2493     6.0453094542026520e-02
    z[6,7,6]  R2494     -2.6525512337684631e-01
    z[6,7,6]  R2495     -3.7803087383508682e-02
    z[6,7,6]  R2496     -2.7614429593086243e-01
    z[6,7,6]  R2497     8.7367840111255646e-02
    z[6,7,6]  R2498     -2.1105292439460754e-01
    z[6,7,6]  R2499     6.7723888158798218e-01
    z[6,7,6]  R2500     3.8104796409606934e-01
    z[6,7,6]  R2501     5.6091502308845520e-02
    z[6,7,6]  R2502     -1.9220207631587982e-01
    z[6,7,6]  R2503     -4.3303820490837097e-01
    z[6,7,6]  R2504     2.5996601581573486e-01
    z[6,7,6]  R2505     -2.8459662571549416e-02
    z[6,7,6]  R2506     -3.0651116743683815e-02
    z[6,7,6]  R2507     1.5808257460594177e-01
    z[6,7,6]  R2508     -6.1019110679626465e-01
    z[6,7,6]  R2509     -0.0468759723007679
    z[6,7,6]  R2510     -1.3311263173818588e-02
    z[6,7,6]  R2511     -2.4402081966400146e-01
    z[6,7,6]  R2512     -2.1688601374626160e-01
    z[6,7,6]  R2513     -4.9238704144954681e-02
    z[6,7,6]  R2514     -4.8392537236213684e-01
    z[7,6,0]  R56       1
    z[7,6,0]  R65       -1
    z[7,6,0]  R2515     -1
    z[7,6,0]  R2516     1
    z[7,6,0]  R2529     -0.875144362449646
    z[7,6,0]  R2530     -8.4285628795623779e-01
    z[7,6,0]  R2531     3.0327999591827393e-01
    z[7,6,0]  R2532     0.49473837018013
    z[7,6,0]  R2533     -0.752993643283844
    z[7,6,0]  R2534     -0.77369225025177
    z[7,6,0]  R2535     4.2660427093505859e-01
    z[7,6,0]  R2536     4.4296678900718689e-01
    z[7,6,0]  R2537     -9.2004263401031494e-01
    z[7,6,0]  R2538     4.6739596128463745e-01
    z[7,6,0]  R2539     2.0212334394454956e-01
    z[7,6,0]  R2540     1.2268134206533432e-01
    z[7,6,0]  R2541     -3.7628674507141113e-01
    z[7,6,0]  R2542     -1.9652925431728363e-02
    z[7,6,0]  R2543     0.600912868976593
    z[7,6,0]  R2544     -4.9089828133583069e-01
    z[7,6,0]  R2545     2.5963410735130310e-01
    z[7,6,0]  R2546     1.5229165554046631e-01
    z[7,6,0]  R2547     6.2417393922805786e-01
    z[7,6,0]  R2548     -0.00672629289329052
    z[7,6,0]  R2549     -5.8581322431564331e-01
    z[7,6,0]  R2550     3.2990756630897522e-01
    z[7,6,0]  R2551     -3.9063400030136108e-01
    z[7,6,0]  R2552     0.0756821483373642
    z[7,6,0]  R2553     -7.0084281265735626e-02
    z[7,6,0]  R2554     -2.7865487337112427e-01
    z[7,6,0]  R2555     4.4110476970672607e-01
    z[7,6,0]  R2556     3.3901163935661316e-01
    z[7,6,0]  R2557     5.2272677421569824e-01
    z[7,6,0]  R2558     6.3964354991912842e-01
    z[7,6,0]  R2559     1.7448575794696808e-01
    z[7,6,0]  R2560     3.4932801127433777e-01
    z[7,6,0]  R2561     4.8197889328002930e-01
    z[7,6,0]  R2562     3.0211597681045532e-01
    z[7,6,0]  R2563     -2.7162078768014908e-02
    z[7,6,0]  R2564     6.8654817342758179e-01
    z[7,6,0]  R2565     -6.1936073005199432e-02
    z[7,6,0]  R2566     -1.7271035909652710e-01
    z[7,6,0]  R2567     -4.2474997043609619e-01
    z[7,6,0]  R2568     -1.7868795990943909e-01
    z[7,6,0]  R2569     -1.7778226733207703e-01
    z[7,6,0]  R2570     -3.4068015217781067e-01
    z[7,6,0]  R2571     -1.1456552892923355e-01
    z[7,6,0]  R2572     -1.4042910933494568e-01
    z[7,6,0]  R2573     -3.1393563747406006e-01
    z[7,6,0]  R2574     -7.5816917419433594e-01
    z[7,6,0]  R2575     -0.279852956533432
    z[7,6,0]  R2576     -9.2264115810394287e-02
    z[7,6,0]  R2577     8.9268334209918976e-02
    z[7,6,0]  R2578     -4.4528219103813171e-01
    z[7,6,0]  R2579     -2.0623424649238586e-01
    z[7,6,0]  R2580     -5.1273441314697266e-01
    z[7,6,0]  R2581     5.5959355831146240e-01
    z[7,6,0]  R2582     -6.4229393005371094e-01
    z[7,6,0]  R2583     4.3120759725570679e-01
    z[7,6,0]  R2584     -5.2551096677780151e-01
    z[7,6,0]  R2585     4.0983331203460693e-01
    z[7,6,0]  R2586     2.7934926748275757e-01
    z[7,6,0]  R2587     -6.5420351922512054e-02
    z[7,6,0]  R2588     -2.1329589188098907e-02
    z[7,6,0]  R2589     8.3455525338649750e-02
    z[7,6,0]  R2590     -2.1819558739662170e-01
    z[7,6,0]  R2591     -1.3673183321952820e-01
    z[7,6,0]  R2592     1.0967677831649780e-01
    z[7,6,0]  R2593     3.1910541653633118e-01
    z[7,6,0]  R2594     5.0385850667953491e-01
    z[7,6,0]  R2595     1.7317111790180206e-01
    z[7,6,0]  R2596     -1.8343149125576019e-01
    z[7,6,0]  R2597     -2.9323059320449829e-01
    z[7,6,0]  R2598     -4.5411375164985657e-01
    z[7,6,0]  R2599     -1.2677389383316040e-01
    z[7,6,0]  R2600     -5.2489918470382690e-01
    z[7,6,0]  R2601     -8.7438768148422241e-01
    z[7,6,0]  R2602     -7.0522385835647583e-01
    z[7,6,0]  R2603     -8.1494313478469849e-01
    z[7,6,0]  R2604     -2.6639264822006226e-01
    z[7,6,0]  R2605     -1.7448942363262177e-01
    z[7,6,0]  R2606     4.9027130007743835e-01
    z[7,6,0]  R2607     1.6009068489074707e-01
    z[7,6,0]  R2608     2.4896232783794403e-01
    z[7,6,0]  R2609     -7.0342606306076050e-01
    z[7,6,0]  R2610     -4.4413122534751892e-01
    z[7,6,0]  R2611     -3.1985759735107422e-01
    z[7,6,0]  R2612     -5.9791624546051025e-01
    z[7,6,0]  R2613     -5.5491024255752563e-01
    z[7,6,0]  R2614     -5.0269585847854614e-01
    z[7,6,0]  R2615     1.9270670600235462e-03
    z[7,6,0]  R2616     1.5989714860916138e-01
    z[7,6,0]  R2617     -1.4859504997730255e-01
    z[7,6,0]  R2618     -2.9126900434494019e-01
    z[7,6,0]  R2619     -1.5396639704704285e-01
    z[7,6,0]  R2620     -6.7126137018203735e-01
    z[7,6,0]  R2621     -0.634260892868042
    z[7,6,0]  R2622     -6.2756544351577759e-01
    z[7,6,0]  R2623     -8.7570679187774658e-01
    z[7,6,0]  R2624     -3.9466273784637451e-01
    z[7,6,1]  R57       1
    z[7,6,1]  R66       -1
    z[7,6,1]  R2517     -1
    z[7,6,1]  R2518     1
    z[7,6,1]  R2529     -3.2509317994117737e-01
    z[7,6,1]  R2530     -3.7371414899826050e-01
    z[7,6,1]  R2531     -1.4021454751491547e-01
    z[7,6,1]  R2532     -5.7073984295129776e-02
    z[7,6,1]  R2533     -3.5664337873458862e-01
    z[7,6,1]  R2534     -4.2401197552680969e-01
    z[7,6,1]  R2535     1.3849431276321411e-01
    z[7,6,1]  R2536     -5.0555467605590820e-01
    z[7,6,1]  R2537     -1.2142102420330048e-01
    z[7,6,1]  R2538     -8.8083013892173767e-02
    z[7,6,1]  R2539     2.7182260155677795e-01
    z[7,6,1]  R2540     -5.5153530836105347e-01
    z[7,6,1]  R2541     -1.0597542673349380e-01
    z[7,6,1]  R2542     7.0410065352916718e-02
    z[7,6,1]  R2543     -1.9849333167076111e-01
    z[7,6,1]  R2544     6.2866485118865967e-01
    z[7,6,1]  R2545     6.6600114107131958e-01
    z[7,6,1]  R2546     -7.1782833337783813e-01
    z[7,6,1]  R2547     2.1348838508129120e-01
    z[7,6,1]  R2548     6.4152634143829346e-01
    z[7,6,1]  R2549     1.6194520890712738e-01
    z[7,6,1]  R2550     4.6813324093818665e-01
    z[7,6,1]  R2551     2.2116348147392273e-01
    z[7,6,1]  R2552     -4.2823565006256104e-01
    z[7,6,1]  R2553     -7.7649158239364624e-01
    z[7,6,1]  R2554     5.6602191925048828e-01
    z[7,6,1]  R2555     -3.4781205654144287e-01
    z[7,6,1]  R2556     -4.5336815714836121e-01
    z[7,6,1]  R2557     -1.6562427580356598e-01
    z[7,6,1]  R2558     -2.9412621259689331e-01
    z[7,6,1]  R2559     -7.4184560775756836e-01
    z[7,6,1]  R2560     -5.8842420578002930e-01
    z[7,6,1]  R2561     -4.4590777158737183e-01
    z[7,6,1]  R2562     -3.2684186100959778e-01
    z[7,6,1]  R2563     8.6725711822509766e-01
    z[7,6,1]  R2564     -1.7752040922641754e-01
    z[7,6,1]  R2565     6.0188430547714233e-01
    z[7,6,1]  R2566     4.9670571088790894e-01
    z[7,6,1]  R2567     5.2763450145721436e-01
    z[7,6,1]  R2568     0.529279887676239
    z[7,6,1]  R2569     5.2224355936050415e-01
    z[7,6,1]  R2570     4.6737614274024963e-01
    z[7,6,1]  R2571     4.6169325709342957e-01
    z[7,6,1]  R2572     5.2379059791564941e-01
    z[7,6,1]  R2573     1.6510948538780212e-01
    z[7,6,1]  R2574     1.5629744529724121e-01
    z[7,6,1]  R2575     0.700522780418396
    z[7,6,1]  R2576     7.7344727516174316e-01
    z[7,6,1]  R2577     6.8620622158050537e-01
    z[7,6,1]  R2578     5.1303267478942871e-01
    z[7,6,1]  R2579     5.3101956844329834e-01
    z[7,6,1]  R2580     1.9648061692714691e-01
    z[7,6,1]  R2581     4.9735376238822937e-01
    z[7,6,1]  R2582     4.2687851190567017e-01
    z[7,6,1]  R2583     5.7654422521591187e-01
    z[7,6,1]  R2584     0.585563063621521
    z[7,6,1]  R2585     7.2807049751281738e-01
    z[7,6,1]  R2586     7.2795051336288452e-01
    z[7,6,1]  R2587     7.9143977165222168e-01
    z[7,6,1]  R2588     5.9142118692398071e-01
    z[7,6,1]  R2589     8.2396847009658813e-01
    z[7,6,1]  R2590     7.5865799188613892e-01
    z[7,6,1]  R2591     6.1866432428359985e-01
    z[7,6,1]  R2592     6.2044388055801392e-01
    z[7,6,1]  R2593     6.3771826028823853e-01
    z[7,6,1]  R2594     6.7984002828598022e-01
    z[7,6,1]  R2595     6.6794329881668091e-01
    z[7,6,1]  R2596     7.1713459491729736e-01
    z[7,6,1]  R2597     6.1718851327896118e-01
    z[7,6,1]  R2598     5.7492977380752563e-01
    z[7,6,1]  R2599     5.3688865900039673e-01
    z[7,6,1]  R2600     1.6145062446594238e-01
    z[7,6,1]  R2601     3.0128052830696106e-01
    z[7,6,1]  R2602     2.2331005334854126e-01
    z[7,6,1]  R2603     2.2012549638748169e-01
    z[7,6,1]  R2604     -4.5834100246429443e-01
    z[7,6,1]  R2605     6.2749165296554565e-01
    z[7,6,1]  R2606     7.1932464838027954e-01
    z[7,6,1]  R2607     6.8802893161773682e-01
    z[7,6,1]  R2608     4.7478458285331726e-01
    z[7,6,1]  R2609     3.2687309384346008e-01
    z[7,6,1]  R2610     1.3411889970302582e-01
    z[7,6,1]  R2611     1.7444875836372375e-01
    z[7,6,1]  R2612     -0.523600161075592
    z[7,6,1]  R2613     -2.7035170793533325e-01
    z[7,6,1]  R2614     -4.4116139411926270e-01
    z[7,6,1]  R2615     8.4566336870193481e-01
    z[7,6,1]  R2616     7.2292298078536987e-01
    z[7,6,1]  R2617     7.2194844484329224e-01
    z[7,6,1]  R2618     5.5753582715988159e-01
    z[7,6,1]  R2619     4.7758224606513977e-01
    z[7,6,1]  R2620     4.0005820989608765e-01
    z[7,6,1]  R2621     3.1105974316596985e-01
    z[7,6,1]  R2622     3.3201286196708679e-01
    z[7,6,1]  R2623     2.6688948273658752e-01
    z[7,6,1]  R2624     2.1507333219051361e-01
    z[7,6,2]  R58       1
    z[7,6,2]  R67       -1
    z[7,6,2]  R2519     -1
    z[7,6,2]  R2520     1
    z[7,6,2]  R2529     -8.3633601665496826e-02
    z[7,6,2]  R2530     -1.8221169710159302e-01
    z[7,6,2]  R2531     1.1443043500185013e-01
    z[7,6,2]  R2532     -7.1232281625270844e-03
    z[7,6,2]  R2533     4.2429044842720032e-01
    z[7,6,2]  R2534     2.5737419724464417e-01
    z[7,6,2]  R2535     0.021140206605196
    z[7,6,2]  R2536     1.1720012128353119e-01
    z[7,6,2]  R2537     1.7755547165870667e-01
    z[7,6,2]  R2538     -2.3838618397712708e-01
    z[7,6,2]  R2539     0.489644855260849
    z[7,6,2]  R2540     -6.5385311841964722e-01
    z[7,6,2]  R2541     4.6000808477401733e-01
    z[7,6,2]  R2542     -0.362640917301178
    z[7,6,2]  R2543     -2.2667229175567627e-01
    z[7,6,2]  R2544     -3.2671579718589783e-01
    z[7,6,2]  R2545     -6.1208885908126831e-01
    z[7,6,2]  R2546     4.4338649511337280e-01
    z[7,6,2]  R2547     -2.5458136200904846e-01
    z[7,6,2]  R2548     4.2926692962646484e-01
    z[7,6,2]  R2549     -2.9571041464805603e-01
    z[7,6,2]  R2550     -5.3677827119827271e-01
    z[7,6,2]  R2551     -4.1452956199645996e-01
    z[7,6,2]  R2552     2.5877401232719421e-01
    z[7,6,2]  R2553     1.3095535337924957e-01
    z[7,6,2]  R2554     3.1691205501556396e-01
    z[7,6,2]  R2555     7.3024737834930420e-01
    z[7,6,2]  R2556     6.4887338876724243e-01
    z[7,6,2]  R2557     7.5980907678604126e-01
    z[7,6,2]  R2558     4.9294778704643250e-01
    z[7,6,2]  R2559     0.561560869216919
    z[7,6,2]  R2560     5.1509636640548706e-01
    z[7,6,2]  R2561     4.7796097397804260e-01
    z[7,6,2]  R2562     4.7889927029609680e-01
    z[7,6,2]  R2563     -2.6386895775794983e-01
    z[7,6,2]  R2564     2.3604415357112885e-01
    z[7,6,2]  R2565     1.4005483686923981e-01
    z[7,6,2]  R2566     -1.2100974470376968e-01
    z[7,6,2]  R2567     2.4701626598834991e-01
    z[7,6,2]  R2568     2.2184227406978607e-01
    z[7,6,2]  R2569     2.1186850965023041e-01
    z[7,6,2]  R2570     1.0004695504903793e-02
    z[7,6,2]  R2571     -1.4007289707660675e-01
    z[7,6,2]  R2572     -2.6390699669718742e-02
    z[7,6,2]  R2573     -8.2079136371612549e-01
    z[7,6,2]  R2574     -3.0513361096382141e-01
    z[7,6,2]  R2575     1.3260711729526520e-01
    z[7,6,2]  R2576     4.3324571847915649e-01
    z[7,6,2]  R2577     9.5791496336460114e-02
    z[7,6,2]  R2578     -4.3592703342437744e-01
    z[7,6,2]  R2579     -7.1677841246128082e-02
    z[7,6,2]  R2580     -0.585075855255127
    z[7,6,2]  R2581     1.4758314192295074e-01
    z[7,6,2]  R2582     -4.2893978953361511e-01
    z[7,6,2]  R2583     3.5841426253318787e-01
    z[7,6,2]  R2584     -7.8127644956111908e-02
    z[7,6,2]  R2585     2.0337031781673431e-01
    z[7,6,2]  R2586     2.7745169401168823e-01
    z[7,6,2]  R2587     -3.3047281205654144e-02
    z[7,6,2]  R2588     -4.7553098201751709e-01
    z[7,6,2]  R2589     7.8497342765331268e-02
    z[7,6,2]  R2590     0.196327343583107
    z[7,6,2]  R2591     -2.2312331199645996e-01
    z[7,6,2]  R2592     -1.5412187576293945e-01
    z[7,6,2]  R2593     -1.4433591067790985e-01
    z[7,6,2]  R2594     3.6017143726348877e-01
    z[7,6,2]  R2595     -1.4645195007324219e-01
    z[7,6,2]  R2596     7.0014052093029022e-02
    z[7,6,2]  R2597     5.3152061998844147e-02
    z[7,6,2]  R2598     -0.342255175113678
    z[7,6,2]  R2599     -2.1780113875865936e-01
    z[7,6,2]  R2600     -6.9982111454010010e-01
    z[7,6,2]  R2601     -1.4328017830848694e-01
    z[7,6,2]  R2602     -2.4706965684890747e-01
    z[7,6,2]  R2603     8.7146468460559845e-02
    z[7,6,2]  R2604     -3.1852287054061890e-01
    z[7,6,2]  R2605     -3.0735307931900024e-01
    z[7,6,2]  R2606     1.8711790442466736e-01
    z[7,6,2]  R2607     -1.2212514411658049e-03
    z[7,6,2]  R2608     5.8216166496276855e-01
    z[7,6,2]  R2609     -1.7080813646316528e-01
    z[7,6,2]  R2610     -5.5677533149719238e-02
    z[7,6,2]  R2611     -0.00486822659149766
    z[7,6,2]  R2612     9.9580520763993263e-03
    z[7,6,2]  R2613     -0.0617239810526371
    z[7,6,2]  R2614     -1.9903749227523804e-01
    z[7,6,2]  R2615     2.5639909505844116e-01
    z[7,6,2]  R2616     2.2625628858804703e-02
    z[7,6,2]  R2617     -3.9600737392902374e-02
    z[7,6,2]  R2618     -4.6437847614288330e-01
    z[7,6,2]  R2619     -5.7949042320251465e-01
    z[7,6,2]  R2620     -2.7532967925071716e-01
    z[7,6,2]  R2621     -1.9601751863956451e-01
    z[7,6,2]  R2622     -9.1783374547958374e-02
    z[7,6,2]  R2623     -0.0622575469315052
    z[7,6,2]  R2624     -3.6990141868591309e-01
    z[7,6,3]  R59       1
    z[7,6,3]  R68       -1
    z[7,6,3]  R2521     -1
    z[7,6,3]  R2522     1
    z[7,6,3]  R2529     2.1107150614261627e-01
    z[7,6,3]  R2530     1.2576033174991608e-01
    z[7,6,3]  R2531     3.3855074644088745e-01
    z[7,6,3]  R2532     6.2545055150985718e-01
    z[7,6,3]  R2533     -2.8825110197067261e-01
    z[7,6,3]  R2534     -6.9849081337451935e-02
    z[7,6,3]  R2535     -2.2724264860153198e-01
    z[7,6,3]  R2536     -4.1251521557569504e-02
    z[7,6,3]  R2537     -1.6425649821758270e-01
    z[7,6,3]  R2538     1.4775149524211884e-01
    z[7,6,3]  R2539     -2.7906140685081482e-01
    z[7,6,3]  R2540     -1.4813390374183655e-01
    z[7,6,3]  R2541     -4.4711455702781677e-03
    z[7,6,3]  R2542     1.3549655675888062e-01
    z[7,6,3]  R2543     -6.8883955478668213e-02
    z[7,6,3]  R2544     -2.3259213566780090e-01
    z[7,6,3]  R2545     1.3596434891223907e-01
    z[7,6,3]  R2546     3.0119559168815613e-01
    z[7,6,3]  R2547     4.7901353240013123e-01
    z[7,6,3]  R2548     -1.2442321516573429e-02
    z[7,6,3]  R2549     -4.5735651254653931e-01
    z[7,6,3]  R2550     -1.4352932572364807e-01
    z[7,6,3]  R2551     -7.3164153099060059e-01
    z[7,6,3]  R2552     -4.7864401340484619e-01
    z[7,6,3]  R2553     0.517343282699585
    z[7,6,3]  R2554     3.3343502879142761e-01
    z[7,6,3]  R2555     0.336246132850647
    z[7,6,3]  R2556     3.3790368586778641e-02
    z[7,6,3]  R2557     1.8210436403751373e-01
    z[7,6,3]  R2558     2.6490703225135803e-01
    z[7,6,3]  R2559     1.2282897531986237e-01
    z[7,6,3]  R2560     2.3171609640121460e-01
    z[7,6,3]  R2561     1.9285863637924194e-01
    z[7,6,3]  R2562     5.6925266981124878e-01
    z[7,6,3]  R2563     -2.0015256106853485e-01
    z[7,6,3]  R2564     3.7729573249816895e-01
    z[7,6,3]  R2565     2.9598088003695011e-03
    z[7,6,3]  R2566     3.4835198521614075e-01
    z[7,6,3]  R2567     1.5558812022209167e-01
    z[7,6,3]  R2568     2.9040387272834778e-01
    z[7,6,3]  R2569     3.7722852826118469e-01
    z[7,6,3]  R2570     3.2994246482849121e-01
    z[7,6,3]  R2571     1.3568203151226044e-01
    z[7,6,3]  R2572     0.705918550491333
    z[7,6,3]  R2573     3.3525240421295166e-01
    z[7,6,3]  R2574     -2.5709119439125061e-01
    z[7,6,3]  R2575     1.7381575703620911e-01
    z[7,6,3]  R2576     -2.7148360013961792e-01
    z[7,6,3]  R2577     -9.1571047902107239e-02
    z[7,6,3]  R2578     5.1690524816513062e-01
    z[7,6,3]  R2579     6.6644591093063354e-01
    z[7,6,3]  R2580     -5.8813279867172241e-01
    z[7,6,3]  R2581     -2.9042765498161316e-01
    z[7,6,3]  R2582     -6.5719529986381531e-02
    z[7,6,3]  R2583     -3.1762981414794922e-01
    z[7,6,3]  R2584     5.0791448354721069e-01
    z[7,6,3]  R2585     4.5159086585044861e-01
    z[7,6,3]  R2586     1.4282864332199097e-01
    z[7,6,3]  R2587     -3.9496548473834991e-02
    z[7,6,3]  R2588     4.8942431807518005e-01
    z[7,6,3]  R2589     1.5942543745040894e-02
    z[7,6,3]  R2590     1.8004053831100464e-01
    z[7,6,3]  R2591     4.3607655167579651e-01
    z[7,6,3]  R2592     6.8976312875747681e-01
    z[7,6,3]  R2593     4.6873083710670471e-01
    z[7,6,3]  R2594     -2.3597058653831482e-01
    z[7,6,3]  R2595     -8.0088503658771515e-02
    z[7,6,3]  R2596     -4.7161877155303955e-01
    z[7,6,3]  R2597     1.7595584690570831e-01
    z[7,6,3]  R2598     3.2299000024795532e-01
    z[7,6,3]  R2599     2.6775670051574707e-01
    z[7,6,3]  R2600     3.1743991374969482e-01
    z[7,6,3]  R2601     -6.0094580054283142e-02
    z[7,6,3]  R2602     -2.7603381872177124e-01
    z[7,6,3]  R2603     2.6966568827629089e-01
    z[7,6,3]  R2604     -7.0699453353881836e-01
    z[7,6,3]  R2605     5.0980645418167114e-01
    z[7,6,3]  R2606     1.3615450263023376e-01
    z[7,6,3]  R2607     4.0435156226158142e-01
    z[7,6,3]  R2608     2.5491121411323547e-01
    z[7,6,3]  R2609     2.4826650321483612e-01
    z[7,6,3]  R2610     -7.4099951982498169e-01
    z[7,6,3]  R2611     -8.2505196332931519e-01
    z[7,6,3]  R2612     -4.7321224212646484e-01
    z[7,6,3]  R2613     -0.572223961353302
    z[7,6,3]  R2614     -5.6724369525909424e-01
    z[7,6,3]  R2615     -5.7623300701379776e-02
    z[7,6,3]  R2616     0.425167053937912
    z[7,6,3]  R2617     5.2429586648941040e-01
    z[7,6,3]  R2618     2.2048802673816681e-01
    z[7,6,3]  R2619     -2.1327883005142212e-01
    z[7,6,3]  R2620     -2.3043704032897949e-01
    z[7,6,3]  R2621     -5.8678174018859863e-01
    z[7,6,3]  R2622     -3.4693691134452820e-01
    z[7,6,3]  R2623     2.3797741532325745e-01
    z[7,6,3]  R2624     -5.7473677396774292e-01
    z[7,6,4]  R60       1
    z[7,6,4]  R69       -1
    z[7,6,4]  R2523     -1
    z[7,6,4]  R2524     1
    z[7,6,4]  R2529     1.9864018261432648e-01
    z[7,6,4]  R2530     1.1640612035989761e-01
    z[7,6,4]  R2531     2.6952770352363586e-01
    z[7,6,4]  R2532     -7.7194280922412872e-02
    z[7,6,4]  R2533     1.9731834530830383e-01
    z[7,6,4]  R2534     2.3781789839267731e-01
    z[7,6,4]  R2535     4.3728187680244446e-01
    z[7,6,4]  R2536     2.4609817564487457e-01
    z[7,6,4]  R2537     -2.6951423287391663e-01
    z[7,6,4]  R2538     -1.8707261979579926e-01
    z[7,6,4]  R2539     -4.1319724172353745e-02
    z[7,6,4]  R2540     -1.4623653143644333e-02
    z[7,6,4]  R2541     -7.5215756893157959e-01
    z[7,6,4]  R2542     -8.8260918855667114e-01
    z[7,6,4]  R2543     -5.8108150959014893e-01
    z[7,6,4]  R2544     3.1479981541633606e-01
    z[7,6,4]  R2545     2.9891505837440491e-01
    z[7,6,4]  R2546     3.9248377084732056e-01
    z[7,6,4]  R2547     4.9551013112068176e-01
    z[7,6,4]  R2548     1.4640846848487854e-01
    z[7,6,4]  R2549     1.4568759500980377e-01
    z[7,6,4]  R2550     3.9291998744010925e-01
    z[7,6,4]  R2551     8.3928229287266731e-03
    z[7,6,4]  R2552     5.3994381427764893e-01
    z[7,6,4]  R2553     3.2386413216590881e-01
    z[7,6,4]  R2554     2.9771456122398376e-01
    z[7,6,4]  R2555     -1.9321829080581665e-01
    z[7,6,4]  R2556     -3.2461011409759521e-01
    z[7,6,4]  R2557     -1.3278612494468689e-01
    z[7,6,4]  R2558     -0.0118703069165349
    z[7,6,4]  R2559     -2.2214166820049286e-01
    z[7,6,4]  R2560     -2.7712747454643250e-01
    z[7,6,4]  R2561     1.8192107975482941e-01
    z[7,6,4]  R2562     -1.8020243942737579e-01
    z[7,6,4]  R2563     3.1285938620567322e-01
    z[7,6,4]  R2564     3.2869994640350342e-01
    z[7,6,4]  R2565     -0.469272255897522
    z[7,6,4]  R2566     -5.0573742389678955e-01
    z[7,6,4]  R2567     -0.673651397228241
    z[7,6,4]  R2568     -5.4611217975616455e-01
    z[7,6,4]  R2569     -6.1120033264160156e-01
    z[7,6,4]  R2570     -6.5022456645965576e-01
    z[7,6,4]  R2571     -1.9623193144798279e-01
    z[7,6,4]  R2572     -4.0855661034584045e-01
    z[7,6,4]  R2573     1.0501979850232601e-02
    z[7,6,4]  R2574     -3.9771673083305359e-01
    z[7,6,4]  R2575     -3.6315000057220459e-01
    z[7,6,4]  R2576     -2.2095610201358795e-01
    z[7,6,4]  R2577     -1.9793076813220978e-01
    z[7,6,4]  R2578     -2.4136649072170258e-01
    z[7,6,4]  R2579     -1.5399551391601562e-01
    z[7,6,4]  R2580     7.9972252249717712e-02
    z[7,6,4]  R2581     3.1315460801124573e-01
    z[7,6,4]  R2582     -3.2879498600959778e-01
    z[7,6,4]  R2583     1.6948254406452179e-01
    z[7,6,4]  R2584     -1.8101902306079865e-01
    z[7,6,4]  R2585     -1.0094108991324902e-02
    z[7,6,4]  R2586     -1.5355275571346283e-01
    z[7,6,4]  R2587     -1.4392051100730896e-01
    z[7,6,4]  R2588     -1.3392525725066662e-02
    z[7,6,4]  R2589     -2.5080311298370361e-01
    z[7,6,4]  R2590     -3.9165604114532471e-01
    z[7,6,4]  R2591     -2.1455757319927216e-01
    z[7,6,4]  R2592     8.1501238048076630e-02
    z[7,6,4]  R2593     -1.5934186056256294e-02
    z[7,6,4]  R2594     1.5481737256050110e-01
    z[7,6,4]  R2595     0.0746997743844986
    z[7,6,4]  R2596     -2.7021676301956177e-01
    z[7,6,4]  R2597     -7.6813362538814545e-02
    z[7,6,4]  R2598     -1.2768602371215820e-01
    z[7,6,4]  R2599     -4.0867531299591064e-01
    z[7,6,4]  R2600     8.3716578781604767e-02
    z[7,6,4]  R2601     2.8910359740257263e-01
    z[7,6,4]  R2602     -1.3713514804840088e-01
    z[7,6,4]  R2603     3.2937932014465332e-01
    z[7,6,4]  R2604     7.1384929120540619e-02
    z[7,6,4]  R2605     -2.1763689815998077e-02
    z[7,6,4]  R2606     3.2222241163253784e-01
    z[7,6,4]  R2607     0.0884227603673935
    z[7,6,4]  R2608     7.1762814186513424e-03
    z[7,6,4]  R2609     3.3743911981582642e-01
    z[7,6,4]  R2610     4.5541308820247650e-02
    z[7,6,4]  R2611     -1.0859984159469604e-01
    z[7,6,4]  R2612     3.4488552808761597e-01
    z[7,6,4]  R2613     3.4778553247451782e-01
    z[7,6,4]  R2614     -2.7931997179985046e-01
    z[7,6,4]  R2615     -3.2818517088890076e-01
    z[7,6,4]  R2616     0.0850084200501442
    z[7,6,4]  R2617     -3.6288848519325256e-01
    z[7,6,4]  R2618     -1.4695268869400024e-01
    z[7,6,4]  R2619     1.9674357026815414e-03
    z[7,6,4]  R2620     -4.7718450427055359e-01
    z[7,6,4]  R2621     -2.0010271668434143e-01
    z[7,6,4]  R2622     -1.2761971354484558e-01
    z[7,6,4]  R2623     8.7412588298320770e-02
    z[7,6,4]  R2624     1.0059091448783875e-01
    z[7,6,5]  R61       1
    z[7,6,5]  R70       -1
    z[7,6,5]  R2525     -1
    z[7,6,5]  R2526     1
    z[7,6,5]  R2529     -1.5223556756973267e-01
    z[7,6,5]  R2530     -2.9553923010826111e-01
    z[7,6,5]  R2531     -8.2567328214645386e-01
    z[7,6,5]  R2532     -5.8892178535461426e-01
    z[7,6,5]  R2533     0.0102920550853014
    z[7,6,5]  R2534     -1.5354523062705994e-01
    z[7,6,5]  R2535     -7.4437719583511353e-01
    z[7,6,5]  R2536     -6.2923544645309448e-01
    z[7,6,5]  R2537     1.0003616334870458e-03
    z[7,6,5]  R2538     -7.8459191322326660e-01
    z[7,6,5]  R2539     3.2752317190170288e-01
    z[7,6,5]  R2540     2.9305151104927063e-01
    z[7,6,5]  R2541     0.25819131731987
    z[7,6,5]  R2542     1.6984629631042480e-01
    z[7,6,5]  R2543     1.3491080701351166e-01
    z[7,6,5]  R2544     1.9046208262443542e-01
    z[7,6,5]  R2545     7.5718492269515991e-02
    z[7,6,5]  R2546     1.3869504630565643e-01
    z[7,6,5]  R2547     6.6094011999666691e-03
    z[7,6,5]  R2548     -1.0102125257253647e-01
    z[7,6,5]  R2549     5.5727428197860718e-01
    z[7,6,5]  R2550     4.5685586333274841e-01
    z[7,6,5]  R2551     -1.7816029489040375e-01
    z[7,6,5]  R2552     4.1981360316276550e-01
    z[7,6,5]  R2553     -6.5648332238197327e-03
    z[7,6,5]  R2554     -2.5988611578941345e-01
    z[7,6,5]  R2555     -1.0714598465710878e-03
    z[7,6,5]  R2556     -3.8282147049903870e-01
    z[7,6,5]  R2557     -1.4236196875572205e-01
    z[7,6,5]  R2558     -3.1125918030738831e-01
    z[7,6,5]  R2559     1.1419694125652313e-01
    z[7,6,5]  R2560     -2.9830756783485413e-01
    z[7,6,5]  R2561     6.5622150897979736e-02
    z[7,6,5]  R2562     -3.1495410948991776e-02
    z[7,6,5]  R2563     1.6625548899173737e-01
    z[7,6,5]  R2564     0.00990427378565073
    z[7,6,5]  R2565     -4.4501629471778870e-01
    z[7,6,5]  R2566     -0.575872540473938
    z[7,6,5]  R2567     -1.5416010282933712e-02
    z[7,6,5]  R2568     -6.1678472906351089e-02
    z[7,6,5]  R2569     -2.0075160264968872e-01
    z[7,6,5]  R2570     -3.1188848614692688e-01
    z[7,6,5]  R2571     -2.4093411862850189e-02
    z[7,6,5]  R2572     -0.0340031236410141
    z[7,6,5]  R2573     -2.8606840968132019e-01
    z[7,6,5]  R2574     1.5666624903678894e-01
    z[7,6,5]  R2575     1.9608432427048683e-02
    z[7,6,5]  R2576     1.4477960765361786e-01
    z[7,6,5]  R2577     -5.5478483438491821e-01
    z[7,6,5]  R2578     8.9255966246128082e-02
    z[7,6,5]  R2579     4.4888880848884583e-01
    z[7,6,5]  R2580     -5.8699328452348709e-02
    z[7,6,5]  R2581     -3.1769070029258728e-01
    z[7,6,5]  R2582     5.2408918738365173e-02
    z[7,6,5]  R2583     -4.2835228145122528e-02
    z[7,6,5]  R2584     -2.4383455514907837e-01
    z[7,6,5]  R2585     -2.2099788486957550e-01
    z[7,6,5]  R2586     -1.8712574243545532e-01
    z[7,6,5]  R2587     -3.2201047986745834e-02
    z[7,6,5]  R2588     -3.7080207467079163e-01
    z[7,6,5]  R2589     -4.9428188800811768e-01
    z[7,6,5]  R2590     1.7356021702289581e-01
    z[7,6,5]  R2591     -1.0440428741276264e-02
    z[7,6,5]  R2592     1.2030643969774246e-01
    z[7,6,5]  R2593     -0.459465891122818
    z[7,6,5]  R2594     -2.4612739682197571e-01
    z[7,6,5]  R2595     -5.3476333618164062e-01
    z[7,6,5]  R2596     -2.6849892735481262e-01
    z[7,6,5]  R2597     6.7392992973327637e-01
    z[7,6,5]  R2598     4.2553851008415222e-01
    z[7,6,5]  R2599     -6.3333910703659058e-01
    z[7,6,5]  R2600     1.9187904894351959e-01
    z[7,6,5]  R2601     -0.0735400915145874
    z[7,6,5]  R2602     5.2827745676040649e-01
    z[7,6,5]  R2603     0.305154412984848
    z[7,6,5]  R2604     -1.9441099464893341e-01
    z[7,6,5]  R2605     3.0759319663047791e-01
    z[7,6,5]  R2606     -1.1642579920589924e-02
    z[7,6,5]  R2607     2.8545862436294556e-01
    z[7,6,5]  R2608     5.5168390274047852e-01
    z[7,6,5]  R2609     -2.1335309743881226e-01
    z[7,6,5]  R2610     4.4023346900939941e-01
    z[7,6,5]  R2611     -2.2197972238063812e-01
    z[7,6,5]  R2612     -1.5570557117462158e-01
    z[7,6,5]  R2613     -3.9092016220092773e-01
    z[7,6,5]  R2614     -2.8752014040946960e-01
    z[7,6,5]  R2615     -2.1267127990722656e-01
    z[7,6,5]  R2616     3.0411267280578613e-01
    z[7,6,5]  R2617     -1.5266118943691254e-01
    z[7,6,5]  R2618     -0.0618041455745697
    z[7,6,5]  R2619     -5.9121972322463989e-01
    z[7,6,5]  R2620     -1.7312206327915192e-01
    z[7,6,5]  R2621     2.2901852428913116e-01
    z[7,6,5]  R2622     5.8368885517120361e-01
    z[7,6,5]  R2623     2.1584718488156796e-03
    z[7,6,5]  R2624     2.1394230425357819e-01
    z[7,6,6]  R62       1
    z[7,6,6]  R71       -1
    z[7,6,6]  R2527     -1
    z[7,6,6]  R2528     1
    z[7,6,6]  R2529     1.1940453946590424e-01
    z[7,6,6]  R2530     4.5191212557256222e-03
    z[7,6,6]  R2531     7.9175412654876709e-02
    z[7,6,6]  R2532     8.9159548282623291e-02
    z[7,6,6]  R2533     6.0453094542026520e-02
    z[7,6,6]  R2534     -2.6525512337684631e-01
    z[7,6,6]  R2535     -3.7803087383508682e-02
    z[7,6,6]  R2536     -2.7614429593086243e-01
    z[7,6,6]  R2537     8.7367840111255646e-02
    z[7,6,6]  R2538     -2.1105292439460754e-01
    z[7,6,6]  R2539     6.7723888158798218e-01
    z[7,6,6]  R2540     3.8104796409606934e-01
    z[7,6,6]  R2541     5.6091502308845520e-02
    z[7,6,6]  R2542     -1.9220207631587982e-01
    z[7,6,6]  R2543     -4.3303820490837097e-01
    z[7,6,6]  R2544     2.5996601581573486e-01
    z[7,6,6]  R2545     -2.8459662571549416e-02
    z[7,6,6]  R2546     -3.0651116743683815e-02
    z[7,6,6]  R2547     1.5808257460594177e-01
    z[7,6,6]  R2548     -6.1019110679626465e-01
    z[7,6,6]  R2549     -0.0468759723007679
    z[7,6,6]  R2550     -1.3311263173818588e-02
    z[7,6,6]  R2551     -2.4402081966400146e-01
    z[7,6,6]  R2552     -2.1688601374626160e-01
    z[7,6,6]  R2553     -4.9238704144954681e-02
    z[7,6,6]  R2554     -4.8392537236213684e-01
    z[7,6,6]  R2555     -2.8217405080795288e-02
    z[7,6,6]  R2556     -7.3660515248775482e-02
    z[7,6,6]  R2557     -2.2573101520538330e-01
    z[7,6,6]  R2558     3.0683785676956177e-01
    z[7,6,6]  R2559     1.6246375441551208e-01
    z[7,6,6]  R2560     2.1661767363548279e-01
    z[7,6,6]  R2561     -5.1557719707489014e-01
    z[7,6,6]  R2562     -4.6372652053833008e-01
    z[7,6,6]  R2563     -1.0916743427515030e-01
    z[7,6,6]  R2564     4.3695256114006042e-01
    z[7,6,6]  R2565     4.4274058938026428e-01
    z[7,6,6]  R2566     -7.9112062230706215e-03
    z[7,6,6]  R2567     0.0438268817961216
    z[7,6,6]  R2568     5.0233691930770874e-01
    z[7,6,6]  R2569     3.0756852030754089e-01
    z[7,6,6]  R2570     1.9096605479717255e-01
    z[7,6,6]  R2571     8.3462363481521606e-01
    z[7,6,6]  R2572     1.9705511629581451e-01
    z[7,6,6]  R2573     7.8390344977378845e-02
    z[7,6,6]  R2574     2.4253916740417480e-01
    z[7,6,6]  R2575     -5.0089037418365479e-01
    z[7,6,6]  R2576     -2.4915599822998047e-01
    z[7,6,6]  R2577     -3.9576271176338196e-01
    z[7,6,6]  R2578     -1.2277390062808990e-01
    z[7,6,6]  R2579     3.1337331980466843e-02
    z[7,6,6]  R2580     -2.1065460518002510e-02
    z[7,6,6]  R2581     3.6656796932220459e-01
    z[7,6,6]  R2582     3.2568693161010742e-01
    z[7,6,6]  R2583     4.7090139985084534e-01
    z[7,6,6]  R2584     1.5700249373912811e-01
    z[7,6,6]  R2585     -0.0878305733203888
    z[7,6,6]  R2586     4.8587873578071594e-01
    z[7,6,6]  R2587     5.8731693029403687e-01
    z[7,6,6]  R2588     -2.1546836197376251e-01
    z[7,6,6]  R2589     -2.1871086210012436e-02
    z[7,6,6]  R2590     3.4978860616683960e-01
    z[7,6,6]  R2591     5.5898851156234741e-01
    z[7,6,6]  R2592     -2.8701499104499817e-01
    z[7,6,6]  R2593     1.9895464181900024e-01
    z[7,6,6]  R2594     1.1828528344631195e-01
    z[7,6,6]  R2595     -4.5216059684753418e-01
    z[7,6,6]  R2596     2.8219836950302124e-01
    z[7,6,6]  R2597     1.9805730879306793e-01
    z[7,6,6]  R2598     2.1068581938743591e-01
    z[7,6,6]  R2599     0.0917283371090889
    z[7,6,6]  R2600     2.5312221050262451e-01
    z[7,6,6]  R2601     -1.7761354148387909e-01
    z[7,6,6]  R2602     -1.3293136656284332e-01
    z[7,6,6]  R2603     7.4083633720874786e-02
    z[7,6,6]  R2604     2.7343901991844177e-01
    z[7,6,6]  R2605     3.5546016693115234e-01
    z[7,6,6]  R2606     -2.9101896286010742e-01
    z[7,6,6]  R2607     4.9817708134651184e-01
    z[7,6,6]  R2608     0.06556436419487
    z[7,6,6]  R2609     3.8490161299705505e-01
    z[7,6,6]  R2610     1.9157165288925171e-01
    z[7,6,6]  R2611     -3.5419678688049316e-01
    z[7,6,6]  R2612     -3.3462695777416229e-02
    z[7,6,6]  R2613     -1.1815723776817322e-01
    z[7,6,6]  R2614     -1.7494225502014160e-01
    z[7,6,6]  R2615     2.5070744752883911e-01
    z[7,6,6]  R2616     4.1331019997596741e-01
    z[7,6,6]  R2617     -1.5894058346748352e-01
    z[7,6,6]  R2618     5.6092691421508789e-01
    z[7,6,6]  R2619     1.3178764283657074e-01
    z[7,6,6]  R2620     -5.2704453468322754e-02
    z[7,6,6]  R2621     1.6040150821208954e-01
    z[7,6,6]  R2622     -1.0079844295978546e-01
    z[7,6,6]  R2623     3.0619084835052490e-01
    z[7,6,6]  R2624     5.2435255050659180e-01
    z[7,8,0]  R65       -1
    z[7,8,0]  R74       1
    z[7,8,0]  R2709     -1
    z[7,8,0]  R2710     1
    z[7,8,0]  R2723     -0.875144362449646
    z[7,8,0]  R2724     -8.4285628795623779e-01
    z[7,8,0]  R2725     3.0327999591827393e-01
    z[7,8,0]  R2726     0.49473837018013
    z[7,8,0]  R2727     -0.752993643283844
    z[7,8,0]  R2728     -0.77369225025177
    z[7,8,0]  R2729     4.2660427093505859e-01
    z[7,8,0]  R2730     4.4296678900718689e-01
    z[7,8,0]  R2731     -9.2004263401031494e-01
    z[7,8,0]  R2732     4.6739596128463745e-01
    z[7,8,0]  R2733     2.0212334394454956e-01
    z[7,8,0]  R2734     1.2268134206533432e-01
    z[7,8,0]  R2735     -3.7628674507141113e-01
    z[7,8,0]  R2736     -1.9652925431728363e-02
    z[7,8,0]  R2737     0.600912868976593
    z[7,8,0]  R2738     -4.9089828133583069e-01
    z[7,8,0]  R2739     2.5963410735130310e-01
    z[7,8,0]  R2740     1.5229165554046631e-01
    z[7,8,0]  R2741     6.2417393922805786e-01
    z[7,8,0]  R2742     -0.00672629289329052
    z[7,8,0]  R2743     -5.8581322431564331e-01
    z[7,8,0]  R2744     3.2990756630897522e-01
    z[7,8,0]  R2745     -3.9063400030136108e-01
    z[7,8,0]  R2746     0.0756821483373642
    z[7,8,0]  R2747     -7.0084281265735626e-02
    z[7,8,0]  R2748     -2.7865487337112427e-01
    z[7,8,0]  R2749     -4.1689458489418030e-01
    z[7,8,0]  R2750     -4.8468196392059326e-01
    z[7,8,0]  R2751     -5.7306480407714844e-01
    z[7,8,0]  R2752     -3.4239238500595093e-01
    z[7,8,0]  R2753     -6.0957503318786621e-01
    z[7,8,0]  R2754     -3.2015225291252136e-01
    z[7,8,0]  R2755     -3.0857360363006592e-01
    z[7,8,0]  R2756     -3.9235708117485046e-01
    z[7,8,0]  R2757     -3.4801444411277771e-01
    z[7,8,0]  R2758     3.6987990140914917e-02
    z[7,8,0]  R2759     3.7160363048315048e-02
    z[7,8,0]  R2760     4.9446426331996918e-02
    z[7,8,0]  R2761     9.2987410724163055e-02
    z[7,8,0]  R2762     1.6451187431812286e-01
    z[7,8,0]  R2763     3.8392234593629837e-02
    z[7,8,0]  R2764     2.3820878937840462e-02
    z[7,8,0]  R2765     -3.6871144175529480e-01
    z[7,8,0]  R2766     -1.8168369308114052e-02
    z[7,8,0]  R2767     4.3558844923973083e-01
    z[7,8,0]  R2768     -3.8961544632911682e-02
    z[7,8,0]  R2769     2.1219049394130707e-01
    z[7,8,0]  R2770     1.0946871340274811e-01
    z[7,8,0]  R2771     -1.0069070756435394e-01
    z[7,8,0]  R2772     5.2443742752075195e-02
    z[7,8,0]  R2773     2.7736195921897888e-01
    z[7,8,0]  R2774     -9.2849425971508026e-02
    z[7,8,0]  R2775     -9.0580090880393982e-02
    z[7,8,0]  R2776     -1.5218126773834229e-01
    z[7,8,0]  R2777     -3.0100749805569649e-02
    z[7,8,0]  R2778     -3.4075182676315308e-01
    z[7,8,0]  R2779     -1.8804021179676056e-01
    z[7,8,0]  R2780     -1.2020721286535263e-01
    z[7,8,0]  R2781     1.3284712098538876e-02
    z[7,8,0]  R2782     -1.1131456494331360e-01
    z[7,8,0]  R2783     -1.0430975258350372e-01
    z[7,8,0]  R2784     -2.2587503492832184e-01
    z[7,8,0]  R2785     -1.0576321184635162e-01
    z[7,8,0]  R2786     -2.6120189577341080e-02
    z[7,8,0]  R2787     8.6152262985706329e-02
    z[7,8,0]  R2788     1.7868988215923309e-01
    z[7,8,0]  R2789     2.1687847375869751e-01
    z[7,8,0]  R2790     -7.6703220605850220e-02
    z[7,8,0]  R2791     -5.7236045598983765e-01
    z[7,8,0]  R2792     3.7944954633712769e-01
    z[7,8,0]  R2793     -1.9736465811729431e-01
    z[7,8,0]  R2794     -3.9486771821975708e-01
    z[7,8,0]  R2795     0.0852629616856575
    z[7,8,0]  R2796     -2.9006785154342651e-01
    z[7,8,0]  R2797     1.5264980494976044e-01
    z[7,8,0]  R2798     2.2403240203857422e-01
    z[7,8,0]  R2799     -2.2230571508407593e-01
    z[7,8,0]  R2800     -3.1105026602745056e-01
    z[7,8,0]  R2801     -5.1620435714721680e-01
    z[7,8,0]  R2802     -1.7105893790721893e-01
    z[7,8,0]  R2803     2.1935540437698364e-01
    z[7,8,0]  R2804     1.0663330322131515e-03
    z[7,8,0]  R2805     -3.1086322665214539e-01
    z[7,8,0]  R2806     4.4636088609695435e-01
    z[7,8,0]  R2807     6.9318538904190063e-01
    z[7,8,0]  R2808     8.1855165958404541e-01
    z[7,8,0]  R2809     4.0272515267133713e-02
    z[7,8,0]  R2810     3.4263002872467041e-01
    z[7,8,0]  R2811     -1.5010145306587219e-01
    z[7,8,0]  R2812     -1.5877915918827057e-01
    z[7,8,0]  R2813     -2.8038141131401062e-01
    z[7,8,0]  R2814     2.9783645272254944e-01
    z[7,8,0]  R2815     -3.5361889004707336e-01
    z[7,8,0]  R2816     -2.7545174956321716e-01
    z[7,8,0]  R2817     -3.9055564999580383e-01
    z[7,8,0]  R2818     3.1482365727424622e-01
    z[7,8,0]  R2819     1.7461758852005005e-01
    z[7,8,0]  R2820     -2.4204730987548828e-01
    z[7,8,0]  R2821     -3.5855054855346680e-01
    z[7,8,0]  R2822     -2.6036825776100159e-01
    z[7,8,0]  R2823     2.1546375751495361e-01
    z[7,8,0]  R2824     6.7238390445709229e-02
    z[7,8,0]  R2825     -2.7760851383209229e-01
    z[7,8,0]  R2826     7.6810318231582642e-01
    z[7,8,0]  R2827     9.5003110170364380e-01
    z[7,8,0]  R2828     9.3456918001174927e-01
    z[7,8,1]  R66       -1
    z[7,8,1]  R75       1
    z[7,8,1]  R2711     -1
    z[7,8,1]  R2712     1
    z[7,8,1]  R2723     -3.2509317994117737e-01
    z[7,8,1]  R2724     -3.7371414899826050e-01
    z[7,8,1]  R2725     -1.4021454751491547e-01
    z[7,8,1]  R2726     -5.7073984295129776e-02
    z[7,8,1]  R2727     -3.5664337873458862e-01
    z[7,8,1]  R2728     -4.2401197552680969e-01
    z[7,8,1]  R2729     1.3849431276321411e-01
    z[7,8,1]  R2730     -5.0555467605590820e-01
    z[7,8,1]  R2731     -1.2142102420330048e-01
    z[7,8,1]  R2732     -8.8083013892173767e-02
    z[7,8,1]  R2733     2.7182260155677795e-01
    z[7,8,1]  R2734     -5.5153530836105347e-01
    z[7,8,1]  R2735     -1.0597542673349380e-01
    z[7,8,1]  R2736     7.0410065352916718e-02
    z[7,8,1]  R2737     -1.9849333167076111e-01
    z[7,8,1]  R2738     6.2866485118865967e-01
    z[7,8,1]  R2739     6.6600114107131958e-01
    z[7,8,1]  R2740     -7.1782833337783813e-01
    z[7,8,1]  R2741     2.1348838508129120e-01
    z[7,8,1]  R2742     6.4152634143829346e-01
    z[7,8,1]  R2743     1.6194520890712738e-01
    z[7,8,1]  R2744     4.6813324093818665e-01
    z[7,8,1]  R2745     2.2116348147392273e-01
    z[7,8,1]  R2746     -4.2823565006256104e-01
    z[7,8,1]  R2747     -7.7649158239364624e-01
    z[7,8,1]  R2748     5.6602191925048828e-01
    z[7,8,1]  R2749     -3.3204442262649536e-01
    z[7,8,1]  R2750     -2.5690299272537231e-01
    z[7,8,1]  R2751     -4.6997055411338806e-01
    z[7,8,1]  R2752     -4.6174040436744690e-01
    z[7,8,1]  R2753     -4.8508054018020630e-01
    z[7,8,1]  R2754     -0.602096676826477
    z[7,8,1]  R2755     1.2655800208449364e-02
    z[7,8,1]  R2756     -1.6722084954380989e-02
    z[7,8,1]  R2757     -1.5665067732334137e-01
    z[7,8,1]  R2758     2.9285481572151184e-01
    z[7,8,1]  R2759     7.0536142587661743e-01
    z[7,8,1]  R2760     3.4541028738021851e-01
    z[7,8,1]  R2761     0.516209065914154
    z[7,8,1]  R2762     4.8548287153244019e-01
    z[7,8,1]  R2763     3.3199149370193481e-01
    z[7,8,1]  R2764     5.1212704181671143e-01
    z[7,8,1]  R2765     5.9532564878463745e-01
    z[7,8,1]  R2766     6.3990515470504761e-01
    z[7,8,1]  R2767     4.8651802539825439e-01
    z[7,8,1]  R2768     4.3544858694076538e-01
    z[7,8,1]  R2769     -3.4603667259216309e-01
    z[7,8,1]  R2770     0.720102846622467
    z[7,8,1]  R2771     -4.8885107971727848e-03
    z[7,8,1]  R2772     6.4501903951168060e-02
    z[7,8,1]  R2773     -2.0838995277881622e-01
    z[7,8,1]  R2774     -2.4802862107753754e-01
    z[7,8,1]  R2775     -7.4762886762619019e-01
    z[7,8,1]  R2776     4.9201175570487976e-02
    z[7,8,1]  R2777     3.2671761512756348e-01
    z[7,8,1]  R2778     -1.0198544710874557e-01
    z[7,8,1]  R2779     -2.8616625815629959e-02
    z[7,8,1]  R2780     3.1933152675628662e-01
    z[7,8,1]  R2781     6.5530651807785034e-01
    z[7,8,1]  R2782     -7.6302891969680786e-01
    z[7,8,1]  R2783     -0.713287353515625
    z[7,8,1]  R2784     3.4502479434013367e-01
    z[7,8,1]  R2785     -1.5632529556751251e-01
    z[7,8,1]  R2786     4.4123733043670654e-01
    z[7,8,1]  R2787     -4.0507555007934570e-01
    z[7,8,1]  R2788     -7.1970999240875244e-02
    z[7,8,1]  R2789     -1.0386711359024048e-01
    z[7,8,1]  R2790     -0.826941728591919
    z[7,8,1]  R2791     5.5064874887466431e-01
    z[7,8,1]  R2792     5.6682562828063965e-01
    z[7,8,1]  R2793     -0.637488067150116
    z[7,8,1]  R2794     3.1302982568740845e-01
    z[7,8,1]  R2795     -4.3343013525009155e-01
    z[7,8,1]  R2796     -5.8169806003570557e-01
    z[7,8,1]  R2797     8.8284105062484741e-01
    z[7,8,1]  R2798     7.3823785781860352e-01
    z[7,8,1]  R2799     -7.5214987993240356e-01
    z[7,8,1]  R2800     4.9054896831512451e-01
    z[7,8,1]  R2801     4.3570250272750854e-01
    z[7,8,1]  R2802     9.2652714252471924e-01
    z[7,8,1]  R2803     8.0565035343170166e-01
    z[7,8,1]  R2804     -5.6556481122970581e-01
    z[7,8,1]  R2805     4.0573990345001221e-01
    z[7,8,1]  R2806     6.1703330278396606e-01
    z[7,8,1]  R2807     -1.1697446554899216e-01
    z[7,8,1]  R2808     -1.9792547821998596e-01
    z[7,8,1]  R2809     -1.3860097527503967e-01
    z[7,8,1]  R2810     0.715706467628479
    z[7,8,1]  R2811     6.6889148950576782e-01
    z[7,8,1]  R2812     2.9724597930908203e-01
    z[7,8,1]  R2813     -6.8008792400360107e-01
    z[7,8,1]  R2814     8.8679903745651245e-01
    z[7,8,1]  R2815     -7.1929872035980225e-01
    z[7,8,1]  R2816     -3.0911669135093689e-01
    z[7,8,1]  R2817     3.7147161364555359e-01
    z[7,8,1]  R2818     0.74797123670578
    z[7,8,1]  R2819     7.5768578052520752e-01
    z[7,8,1]  R2820     -3.3206534385681152e-01
    z[7,8,1]  R2821     -7.1302127838134766e-01
    z[7,8,1]  R2822     6.7258435487747192e-01
    z[7,8,1]  R2823     7.0505040884017944e-01
    z[7,8,1]  R2824     -6.5480205230414867e-03
    z[7,8,1]  R2825     -7.0366328954696655e-01
    z[7,8,1]  R2826     -3.0529114603996277e-01
    z[7,8,1]  R2827     1.3688798062503338e-02
    z[7,8,1]  R2828     4.1255757212638855e-02
    z[7,8,2]  R67       -1
    z[7,8,2]  R76       1
    z[7,8,2]  R2713     -1
    z[7,8,2]  R2714     1
    z[7,8,2]  R2723     -8.3633601665496826e-02
    z[7,8,2]  R2724     -1.8221169710159302e-01
    z[7,8,2]  R2725     1.1443043500185013e-01
    z[7,8,2]  R2726     -7.1232281625270844e-03
    z[7,8,2]  R2727     4.2429044842720032e-01
    z[7,8,2]  R2728     2.5737419724464417e-01
    z[7,8,2]  R2729     0.021140206605196
    z[7,8,2]  R2730     1.1720012128353119e-01
    z[7,8,2]  R2731     1.7755547165870667e-01
    z[7,8,2]  R2732     -2.3838618397712708e-01
    z[7,8,2]  R2733     0.489644855260849
    z[7,8,2]  R2734     -6.5385311841964722e-01
    z[7,8,2]  R2735     4.6000808477401733e-01
    z[7,8,2]  R2736     -0.362640917301178
    z[7,8,2]  R2737     -2.2667229175567627e-01
    z[7,8,2]  R2738     -3.2671579718589783e-01
    z[7,8,2]  R2739     -6.1208885908126831e-01
    z[7,8,2]  R2740     4.4338649511337280e-01
    z[7,8,2]  R2741     -2.5458136200904846e-01
    z[7,8,2]  R2742     4.2926692962646484e-01
    z[7,8,2]  R2743     -2.9571041464805603e-01
    z[7,8,2]  R2744     -5.3677827119827271e-01
    z[7,8,2]  R2745     -4.1452956199645996e-01
    z[7,8,2]  R2746     2.5877401232719421e-01
    z[7,8,2]  R2747     1.3095535337924957e-01
    z[7,8,2]  R2748     3.1691205501556396e-01
    z[7,8,2]  R2749     4.2972904443740845e-01
    z[7,8,2]  R2750     2.9859790205955505e-01
    z[7,8,2]  R2751     -1.4298494160175323e-01
    z[7,8,2]  R2752     1.9827237725257874e-01
    z[7,8,2]  R2753     2.4667717516422272e-01
    z[7,8,2]  R2754     6.6764909029006958e-01
    z[7,8,2]  R2755     0.749691903591156
    z[7,8,2]  R2756     0.794209361076355
    z[7,8,2]  R2757     7.4640804529190063e-01
    z[7,8,2]  R2758     -5.7840985059738159e-01
    z[7,8,2]  R2759     -4.9356621503829956e-01
    z[7,8,2]  R2760     -5.4023534059524536e-01
    z[7,8,2]  R2761     -6.4635413885116577e-01
    z[7,8,2]  R2762     -9.2058137059211731e-02
    z[7,8,2]  R2763     -7.9390835762023926e-01
    z[7,8,2]  R2764     -4.5745104551315308e-01
    z[7,8,2]  R2765     -3.7056869268417358e-01
    z[7,8,2]  R2766     -4.0922570228576660e-01
    z[7,8,2]  R2767     -4.8002764582633972e-01
    z[7,8,2]  R2768     -6.8645268678665161e-01
    z[7,8,2]  R2769     4.0704756975173950e-01
    z[7,8,2]  R2770     -3.5753306746482849e-01
    z[7,8,2]  R2771     -3.2452747225761414e-01
    z[7,8,2]  R2772     -1.6314937174320221e-01
    z[7,8,2]  R2773     1.8298590555787086e-02
    z[7,8,2]  R2774     -2.8553183656185865e-03
    z[7,8,2]  R2775     -4.5324909687042236e-01
    z[7,8,2]  R2776     7.4352012015879154e-03
    z[7,8,2]  R2777     1.7782163619995117e-01
    z[7,8,2]  R2778     9.8059467971324921e-02
    z[7,8,2]  R2779     3.7972810864448547e-01
    z[7,8,2]  R2780     -6.2939512729644775e-01
    z[7,8,2]  R2781     -0.642380952835083
    z[7,8,2]  R2782     -6.9627188146114349e-02
    z[7,8,2]  R2783     -1.6084440052509308e-01
    z[7,8,2]  R2784     -5.4775995016098022e-01
    z[7,8,2]  R2785     -4.4738808274269104e-01
    z[7,8,2]  R2786     -5.5230081081390381e-01
    z[7,8,2]  R2787     4.3478560447692871e-01
    z[7,8,2]  R2788     -5.3456395864486694e-01
    z[7,8,2]  R2789     4.4696268439292908e-01
    z[7,8,2]  R2790     -2.2541087865829468e-01
    z[7,8,2]  R2791     -4.3915849924087524e-01
    z[7,8,2]  R2792     -6.5261960029602051e-01
    z[7,8,2]  R2793     -1.2304015457630157e-01
    z[7,8,2]  R2794     -6.2947779893875122e-01
    z[7,8,2]  R2795     -3.2969605177640915e-02
    z[7,8,2]  R2796     -3.2634842395782471e-01
    z[7,8,2]  R2797     2.6758614182472229e-01
    z[7,8,2]  R2798     4.3983215093612671e-01
    z[7,8,2]  R2799     -9.5280326902866364e-02
    z[7,8,2]  R2800     -0.634859025478363
    z[7,8,2]  R2801     -6.4517909288406372e-01
    z[7,8,2]  R2802     0.0360434390604496
    z[7,8,2]  R2803     4.5218861103057861e-01
    z[7,8,2]  R2804     -1.2078131549060345e-02
    z[7,8,2]  R2805     1.2855865061283112e-01
    z[7,8,2]  R2806     5.5934345722198486e-01
    z[7,8,2]  R2807     -2.0315490663051605e-01
    z[7,8,2]  R2808     -1.4706824719905853e-01
    z[7,8,2]  R2809     1.7670039832592010e-01
    z[7,8,2]  R2810     -4.8426979780197144e-01
    z[7,8,2]  R2811     -2.8648141026496887e-01
    z[7,8,2]  R2812     -6.8398404121398926e-01
    z[7,8,2]  R2813     -5.9787672013044357e-02
    z[7,8,2]  R2814     -1.4526379108428955e-01
    z[7,8,2]  R2815     3.9475105702877045e-02
    z[7,8,2]  R2816     2.5788527727127075e-01
    z[7,8,2]  R2817     -4.6022129058837891e-01
    z[7,8,2]  R2818     5.2115124464035034e-01
    z[7,8,2]  R2819     -2.4724586308002472e-01
    z[7,8,2]  R2820     3.8947898149490356e-01
    z[7,8,2]  R2821     -1.5772011876106262e-01
    z[7,8,2]  R2822     -0.574109673500061
    z[7,8,2]  R2823     -4.5492088794708252e-01
    z[7,8,2]  R2824     4.2822387814521790e-01
    z[7,8,2]  R2825     -2.8702369332313538e-01
    z[7,8,2]  R2826     -0.175094336271286
    z[7,8,2]  R2827     6.2799490988254547e-02
    z[7,8,2]  R2828     2.5760421156883240e-01
    z[7,8,3]  R68       -1
    z[7,8,3]  R77       1
    z[7,8,3]  R2715     -1
    z[7,8,3]  R2716     1
    z[7,8,3]  R2723     2.1107150614261627e-01
    z[7,8,3]  R2724     1.2576033174991608e-01
    z[7,8,3]  R2725     3.3855074644088745e-01
    z[7,8,3]  R2726     6.2545055150985718e-01
    z[7,8,3]  R2727     -2.8825110197067261e-01
    z[7,8,3]  R2728     -6.9849081337451935e-02
    z[7,8,3]  R2729     -2.2724264860153198e-01
    z[7,8,3]  R2730     -4.1251521557569504e-02
    z[7,8,3]  R2731     -1.6425649821758270e-01
    z[7,8,3]  R2732     1.4775149524211884e-01
    z[7,8,3]  R2733     -2.7906140685081482e-01
    z[7,8,3]  R2734     -1.4813390374183655e-01
    z[7,8,3]  R2735     -4.4711455702781677e-03
    z[7,8,3]  R2736     1.3549655675888062e-01
    z[7,8,3]  R2737     -6.8883955478668213e-02
    z[7,8,3]  R2738     -2.3259213566780090e-01
    z[7,8,3]  R2739     1.3596434891223907e-01
    z[7,8,3]  R2740     3.0119559168815613e-01
    z[7,8,3]  R2741     4.7901353240013123e-01
    z[7,8,3]  R2742     -1.2442321516573429e-02
    z[7,8,3]  R2743     -4.5735651254653931e-01
    z[7,8,3]  R2744     -1.4352932572364807e-01
    z[7,8,3]  R2745     -7.3164153099060059e-01
    z[7,8,3]  R2746     -4.7864401340484619e-01
    z[7,8,3]  R2747     0.517343282699585
    z[7,8,3]  R2748     3.3343502879142761e-01
    z[7,8,3]  R2749     7.0460617542266846e-01
    z[7,8,3]  R2750     6.3385230302810669e-01
    z[7,8,3]  R2751     5.1752287149429321e-01
    z[7,8,3]  R2752     0.691716730594635
    z[7,8,3]  R2753     -2.8274807333946228e-01
    z[7,8,3]  R2754     2.2858205437660217e-01
    z[7,8,3]  R2755     -9.3946717679500580e-02
    z[7,8,3]  R2756     -9.8623782396316528e-02
    z[7,8,3]  R2757     1.6305133700370789e-02
    z[7,8,3]  R2758     2.3331997916102409e-02
    z[7,8,3]  R2759     6.5564163029193878e-02
    z[7,8,3]  R2760     5.2176183462142944e-01
    z[7,8,3]  R2761     4.3301886320114136e-01
    z[7,8,3]  R2762     -7.2795635461807251e-01
    z[7,8,3]  R2763     1.0284223407506943e-01
    z[7,8,3]  R2764     5.7892650365829468e-01
    z[7,8,3]  R2765     1.1072061210870743e-01
    z[7,8,3]  R2766     4.8190414905548096e-01
    z[7,8,3]  R2767     5.4360177367925644e-02
    z[7,8,3]  R2768     -6.8826384842395782e-02
    z[7,8,3]  R2769     -8.1118786334991455e-01
    z[7,8,3]  R2770     0.0860656350851059
    z[7,8,3]  R2771     -0.528769314289093
    z[7,8,3]  R2772     -4.9167567491531372e-01
    z[7,8,3]  R2773     -6.5119296312332153e-01
    z[7,8,3]  R2774     -7.0396721363067627e-01
    z[7,8,3]  R2775     -3.1340688467025757e-01
    z[7,8,3]  R2776     -6.6030627489089966e-01
    z[7,8,3]  R2777     -4.8219156265258789e-01
    z[7,8,3]  R2778     -5.1669472455978394e-01
    z[7,8,3]  R2779     -0.783909022808075
    z[7,8,3]  R2780     6.4680272340774536e-01
    z[7,8,3]  R2781     1.1100284755229950e-02
    z[7,8,3]  R2782     -1.9375425577163696e-01
    z[7,8,3]  R2783     4.3256103992462158e-02
    z[7,8,3]  R2784     6.3257914781570435e-01
    z[7,8,3]  R2785     -4.0427660942077637e-01
    z[7,8,3]  R2786     2.4229690432548523e-01
    z[7,8,3]  R2787     3.9681177586317062e-02
    z[7,8,3]  R2788     -7.1501910686492920e-01
    z[7,8,3]  R2789     -7.5669950246810913e-01
    z[7,8,3]  R2790     4.7563002444803715e-03
    z[7,8,3]  R2791     8.6002998054027557e-02
    z[7,8,3]  R2792     -1.5803065896034241e-01
    z[7,8,3]  R2793     -5.2056068181991577e-01
    z[7,8,3]  R2794     -8.8108986616134644e-02
    z[7,8,3]  R2795     -1.6161488369107246e-02
    z[7,8,3]  R2796     -3.6090412735939026e-01
    z[7,8,3]  R2797     2.4224698543548584e-01
    z[7,8,3]  R2798     2.5279900431632996e-01
    z[7,8,3]  R2799     3.5884881019592285e-01
    z[7,8,3]  R2800     1.4230453968048096e-01
    z[7,8,3]  R2801     -1.0548471659421921e-01
    z[7,8,3]  R2802     9.3076996505260468e-02
    z[7,8,3]  R2803     1.9540201127529144e-01
    z[7,8,3]  R2804     -3.2591944932937622e-01
    z[7,8,3]  R2805     1.2794514000415802e-01
    z[7,8,3]  R2806     -3.7251997739076614e-02
    z[7,8,3]  R2807     -2.0874477922916412e-01
    z[7,8,3]  R2808     -4.8169005662202835e-02
    z[7,8,3]  R2809     -5.8753520250320435e-01
    z[7,8,3]  R2810     8.5866108536720276e-02
    z[7,8,3]  R2811     3.1356829404830933e-01
    z[7,8,3]  R2812     3.1444475054740906e-01
    z[7,8,3]  R2813     -4.0305379033088684e-01
    z[7,8,3]  R2814     1.4074213802814484e-01
    z[7,8,3]  R2815     -0.36433145403862
    z[7,8,3]  R2816     -1.5327471494674683e-01
    z[7,8,3]  R2817     6.5086834132671356e-02
    z[7,8,3]  R2818     -1.3650661706924438e-01
    z[7,8,3]  R2819     5.3470355272293091e-01
    z[7,8,3]  R2820     -1.8591515719890594e-01
    z[7,8,3]  R2821     -3.2681983709335327e-01
    z[7,8,3]  R2822     -1.1359921097755432e-01
    z[7,8,3]  R2823     1.7740766704082489e-01
    z[7,8,3]  R2824     -2.6093408465385437e-01
    z[7,8,3]  R2825     -2.4626623094081879e-01
    z[7,8,3]  R2826     1.6839888691902161e-01
    z[7,8,3]  R2827     1.1186099052429199e-01
    z[7,8,3]  R2828     2.2514252364635468e-01
    z[7,8,4]  R69       -1
    z[7,8,4]  R78       1
    z[7,8,4]  R2717     -1
    z[7,8,4]  R2718     1
    z[7,8,4]  R2723     1.9864018261432648e-01
    z[7,8,4]  R2724     1.1640612035989761e-01
    z[7,8,4]  R2725     2.6952770352363586e-01
    z[7,8,4]  R2726     -7.7194280922412872e-02
    z[7,8,4]  R2727     1.9731834530830383e-01
    z[7,8,4]  R2728     2.3781789839267731e-01
    z[7,8,4]  R2729     4.3728187680244446e-01
    z[7,8,4]  R2730     2.4609817564487457e-01
    z[7,8,4]  R2731     -2.6951423287391663e-01
    z[7,8,4]  R2732     -1.8707261979579926e-01
    z[7,8,4]  R2733     -4.1319724172353745e-02
    z[7,8,4]  R2734     -1.4623653143644333e-02
    z[7,8,4]  R2735     -7.5215756893157959e-01
    z[7,8,4]  R2736     -8.8260918855667114e-01
    z[7,8,4]  R2737     -5.8108150959014893e-01
    z[7,8,4]  R2738     3.1479981541633606e-01
    z[7,8,4]  R2739     2.9891505837440491e-01
    z[7,8,4]  R2740     3.9248377084732056e-01
    z[7,8,4]  R2741     4.9551013112068176e-01
    z[7,8,4]  R2742     1.4640846848487854e-01
    z[7,8,4]  R2743     1.4568759500980377e-01
    z[7,8,4]  R2744     3.9291998744010925e-01
    z[7,8,4]  R2745     8.3928229287266731e-03
    z[7,8,4]  R2746     5.3994381427764893e-01
    z[7,8,4]  R2747     3.2386413216590881e-01
    z[7,8,4]  R2748     2.9771456122398376e-01
    z[7,8,4]  R2749     6.0182854533195496e-02
    z[7,8,4]  R2750     0.334433376789093
    z[7,8,4]  R2751     3.5058698058128357e-01
    z[7,8,4]  R2752     -1.5981499850749969e-01
    z[7,8,4]  R2753     4.5273166894912720e-01
    z[7,8,4]  R2754     7.1975603699684143e-02
    z[7,8,4]  R2755     2.0932009816169739e-01
    z[7,8,4]  R2756     4.3899127840995789e-01
    z[7,8,4]  R2757     4.7448903322219849e-01
    z[7,8,4]  R2758     1.0534477978944778e-01
    z[7,8,4]  R2759     -2.8116098046302795e-01
    z[7,8,4]  R2760     -3.7564691901206970e-01
    z[7,8,4]  R2761     -2.3733133077621460e-01
    z[7,8,4]  R2762     4.0176185965538025e-01
    z[7,8,4]  R2763     -3.4186564385890961e-02
    z[7,8,4]  R2764     -2.3181053996086121e-01
    z[7,8,4]  R2765     -1.7737166583538055e-01
    z[7,8,4]  R2766     1.1563534289598465e-01
    z[7,8,4]  R2767     -0.551505982875824
    z[7,8,4]  R2768     3.9585113525390625e-01
    z[7,8,4]  R2769     1.0906083509325981e-02
    z[7,8,4]  R2770     -3.6826786398887634e-01
    z[7,8,4]  R2771     -6.5377938747406006e-01
    z[7,8,4]  R2772     -7.1659630537033081e-01
    z[7,8,4]  R2773     -5.6170392036437988e-01
    z[7,8,4]  R2774     -6.2472081184387207e-01
    z[7,8,4]  R2775     -0.252750426530838
    z[7,8,4]  R2776     -6.1852902173995972e-01
    z[7,8,4]  R2777     -7.0063984394073486e-01
    z[7,8,4]  R2778     -6.9972926378250122e-01
    z[7,8,4]  R2779     2.1617035567760468e-01
    z[7,8,4]  R2780     -1.0089616477489471e-01
    z[7,8,4]  R2781     3.2417541742324829e-01
    z[7,8,4]  R2782     -2.3014199733734131e-01
    z[7,8,4]  R2783     -3.6255308985710144e-01
    z[7,8,4]  R2784     1.5050463378429413e-01
    z[7,8,4]  R2785     2.3566101491451263e-01
    z[7,8,4]  R2786     2.0459690690040588e-01
    z[7,8,4]  R2787     -4.9369612336158752e-01
    z[7,8,4]  R2788     1.3406861573457718e-02
    z[7,8,4]  R2789     7.9505115747451782e-02
    z[7,8,4]  R2790     -4.9428895115852356e-01
    z[7,8,4]  R2791     -0.0761650800704956
    z[7,8,4]  R2792     -2.6672041416168213e-01
    z[7,8,4]  R2793     3.6464941501617432e-01
    z[7,8,4]  R2794     -2.1595989167690277e-01
    z[7,8,4]  R2795     -6.0959827899932861e-01
    z[7,8,4]  R2796     3.5240563750267029e-01
    z[7,8,4]  R2797     1.9147807359695435e-01
    z[7,8,4]  R2798     -9.4949059188365936e-02
    z[7,8,4]  R2799     -4.2940896749496460e-01
    z[7,8,4]  R2800     2.9315361380577087e-01
    z[7,8,4]  R2801     -0.0841350331902504
    z[7,8,4]  R2802     1.3752470910549164e-01
    z[7,8,4]  R2803     1.0821728408336639e-01
    z[7,8,4]  R2804     -3.8458526134490967e-02
    z[7,8,4]  R2805     7.3545169830322266e-01
    z[7,8,4]  R2806     -2.6146358251571655e-01
    z[7,8,4]  R2807     2.3412831127643585e-02
    z[7,8,4]  R2808     4.8646613955497742e-02
    z[7,8,4]  R2809     1.9688895344734192e-01
    z[7,8,4]  R2810     -2.6365187764167786e-01
    z[7,8,4]  R2811     1.6216847300529480e-01
    z[7,8,4]  R2812     1.0183297097682953e-01
    z[7,8,4]  R2813     3.6613830924034119e-01
    z[7,8,4]  R2814     2.5276171043515205e-02
    z[7,8,4]  R2815     3.9034810662269592e-01
    z[7,8,4]  R2816     -5.8465617895126343e-01
    z[7,8,4]  R2817     -5.4090458154678345e-01
    z[7,8,4]  R2818     -2.1702301502227783e-01
    z[7,8,4]  R2819     -2.1139633655548096e-01
    z[7,8,4]  R2820     -5.1421147584915161e-01
    z[7,8,4]  R2821     3.8064935803413391e-01
    z[7,8,4]  R2822     2.8179755806922913e-01
    z[7,8,4]  R2823     1.6003543511033058e-02
    z[7,8,4]  R2824     -2.0782912150025368e-02
    z[7,8,4]  R2825     2.2558422386646271e-01
    z[7,8,4]  R2826     -1.8514131009578705e-01
    z[7,8,4]  R2827     2.2753329575061798e-01
    z[7,8,4]  R2828     5.2067141979932785e-02
    z[7,8,5]  R70       -1
    z[7,8,5]  R79       1
    z[7,8,5]  R2719     -1
    z[7,8,5]  R2720     1
    z[7,8,5]  R2723     -1.5223556756973267e-01
    z[7,8,5]  R2724     -2.9553923010826111e-01
    z[7,8,5]  R2725     -8.2567328214645386e-01
    z[7,8,5]  R2726     -5.8892178535461426e-01
    z[7,8,5]  R2727     0.0102920550853014
    z[7,8,5]  R2728     -1.5354523062705994e-01
    z[7,8,5]  R2729     -7.4437719583511353e-01
    z[7,8,5]  R2730     -6.2923544645309448e-01
    z[7,8,5]  R2731     1.0003616334870458e-03
    z[7,8,5]  R2732     -7.8459191322326660e-01
    z[7,8,5]  R2733     3.2752317190170288e-01
    z[7,8,5]  R2734     2.9305151104927063e-01
    z[7,8,5]  R2735     0.25819131731987
    z[7,8,5]  R2736     1.6984629631042480e-01
    z[7,8,5]  R2737     1.3491080701351166e-01
    z[7,8,5]  R2738     1.9046208262443542e-01
    z[7,8,5]  R2739     7.5718492269515991e-02
    z[7,8,5]  R2740     1.3869504630565643e-01
    z[7,8,5]  R2741     6.6094011999666691e-03
    z[7,8,5]  R2742     -1.0102125257253647e-01
    z[7,8,5]  R2743     5.5727428197860718e-01
    z[7,8,5]  R2744     4.5685586333274841e-01
    z[7,8,5]  R2745     -1.7816029489040375e-01
    z[7,8,5]  R2746     4.1981360316276550e-01
    z[7,8,5]  R2747     -6.5648332238197327e-03
    z[7,8,5]  R2748     -2.5988611578941345e-01
    z[7,8,5]  R2749     -4.0111333131790161e-02
    z[7,8,5]  R2750     -2.9458436369895935e-01
    z[7,8,5]  R2751     -1.7900609970092773e-01
    z[7,8,5]  R2752     -2.3825907707214355e-01
    z[7,8,5]  R2753     1.9674451649188995e-01
    z[7,8,5]  R2754     -1.5321678481996059e-02
    z[7,8,5]  R2755     1.6504010185599327e-02
    z[7,8,5]  R2756     -5.1086336374282837e-02
    z[7,8,5]  R2757     -2.1501930430531502e-02
    z[7,8,5]  R2758     -2.1900095045566559e-01
    z[7,8,5]  R2759     -3.8801664113998413e-01
    z[7,8,5]  R2760     2.5432538986206055e-01
    z[7,8,5]  R2761     7.7942825853824615e-02
    z[7,8,5]  R2762     4.9140501767396927e-02
    z[7,8,5]  R2763     7.6111115515232086e-02
    z[7,8,5]  R2764     2.5701296329498291e-01
    z[7,8,5]  R2765     -8.5745364427566528e-02
    z[7,8,5]  R2766     -1.9198076426982880e-01
    z[7,8,5]  R2767     -9.8238639533519745e-02
    z[7,8,5]  R2768     -1.8779900670051575e-01
    z[7,8,5]  R2769     9.1455176472663879e-02
    z[7,8,5]  R2770     5.8820914477109909e-02
    z[7,8,5]  R2771     3.6578190326690674e-01
    z[7,8,5]  R2772     3.0248314142227173e-01
    z[7,8,5]  R2773     3.5836723446846008e-01
    z[7,8,5]  R2774     2.0174258947372437e-01
    z[7,8,5]  R2775     2.4466985464096069e-01
    z[7,8,5]  R2776     1.2938182055950165e-01
    z[7,8,5]  R2777     0.203104168176651
    z[7,8,5]  R2778     1.5726454555988312e-01
    z[7,8,5]  R2779     2.4988044798374176e-01
    z[7,8,5]  R2780     -1.2344833463430405e-01
    z[7,8,5]  R2781     1.9207081198692322e-01
    z[7,8,5]  R2782     1.0046100616455078e-01
    z[7,8,5]  R2783     -9.2327609658241272e-02
    z[7,8,5]  R2784     -1.4799048006534576e-01
    z[7,8,5]  R2785     4.6228629350662231e-01
    z[7,8,5]  R2786     -4.0209221839904785e-01
    z[7,8,5]  R2787     2.8853037953376770e-01
    z[7,8,5]  R2788     3.7438431382179260e-01
    z[7,8,5]  R2789     3.8681104779243469e-01
    z[7,8,5]  R2790     -3.5120215266942978e-02
    z[7,8,5]  R2791     1.3741073012351990e-01
    z[7,8,5]  R2792     2.6251502335071564e-02
    z[7,8,5]  R2793     -3.3485063910484314e-01
    z[7,8,5]  R2794     5.3847837448120117e-01
    z[7,8,5]  R2795     6.3186037540435791e-01
    z[7,8,5]  R2796     3.7381444126367569e-02
    z[7,8,5]  R2797     9.3511477112770081e-02
    z[7,8,5]  R2798     0.371217280626297
    z[7,8,5]  R2799     3.6413182970136404e-03
    z[7,8,5]  R2800     -2.0216912031173706e-01
    z[7,8,5]  R2801     1.0431414842605591e-01
    z[7,8,5]  R2802     1.1590618640184402e-02
    z[7,8,5]  R2803     -7.2658024728298187e-02
    z[7,8,5]  R2804     -6.2452876567840576e-01
    z[7,8,5]  R2805     3.4534335136413574e-01
    z[7,8,5]  R2806     -1.0845420509576797e-01
    z[7,8,5]  R2807     -6.4834314584732056e-01
    z[7,8,5]  R2808     -4.9363338947296143e-01
    z[7,8,5]  R2809     0.472953200340271
    z[7,8,5]  R2810     7.3955051600933075e-02
    z[7,8,5]  R2811     5.4328376054763794e-01
    z[7,8,5]  R2812     3.9821276068687439e-01
    z[7,8,5]  R2813     -1.3570861518383026e-01
    z[7,8,5]  R2814     -2.8387421369552612e-01
    z[7,8,5]  R2815     1.7517729103565216e-01
    z[7,8,5]  R2816     5.7705128192901611e-01
    z[7,8,5]  R2817     4.4803205132484436e-01
    z[7,8,5]  R2818     -4.0736470371484756e-02
    z[7,8,5]  R2819     -3.5944998264312744e-02
    z[7,8,5]  R2820     6.0712260007858276e-01
    z[7,8,5]  R2821     2.9833678156137466e-02
    z[7,8,5]  R2822     -2.2303852438926697e-01
    z[7,8,5]  R2823     -4.6621689200401306e-01
    z[7,8,5]  R2824     7.1863436698913574e-01
    z[7,8,5]  R2825     -3.0003547668457031e-01
    z[7,8,5]  R2826     -4.7163897752761841e-01
    z[7,8,5]  R2827     1.7729481682181358e-02
    z[7,8,5]  R2828     -9.3078408390283585e-03
    z[7,8,6]  R71       -1
    z[7,8,6]  R80       1
    z[7,8,6]  R2721     -1
    z[7,8,6]  R2722     1
    z[7,8,6]  R2723     1.1940453946590424e-01
    z[7,8,6]  R2724     4.5191212557256222e-03
    z[7,8,6]  R2725     7.9175412654876709e-02
    z[7,8,6]  R2726     8.9159548282623291e-02
    z[7,8,6]  R2727     6.0453094542026520e-02
    z[7,8,6]  R2728     -2.6525512337684631e-01
    z[7,8,6]  R2729     -3.7803087383508682e-02
    z[7,8,6]  R2730     -2.7614429593086243e-01
    z[7,8,6]  R2731     8.7367840111255646e-02
    z[7,8,6]  R2732     -2.1105292439460754e-01
    z[7,8,6]  R2733     6.7723888158798218e-01
    z[7,8,6]  R2734     3.8104796409606934e-01
    z[7,8,6]  R2735     5.6091502308845520e-02
    z[7,8,6]  R2736     -1.9220207631587982e-01
    z[7,8,6]  R2737     -4.3303820490837097e-01
    z[7,8,6]  R2738     2.5996601581573486e-01
    z[7,8,6]  R2739     -2.8459662571549416e-02
    z[7,8,6]  R2740     -3.0651116743683815e-02
    z[7,8,6]  R2741     1.5808257460594177e-01
    z[7,8,6]  R2742     -6.1019110679626465e-01
    z[7,8,6]  R2743     -0.0468759723007679
    z[7,8,6]  R2744     -1.3311263173818588e-02
    z[7,8,6]  R2745     -2.4402081966400146e-01
    z[7,8,6]  R2746     -2.1688601374626160e-01
    z[7,8,6]  R2747     -4.9238704144954681e-02
    z[7,8,6]  R2748     -4.8392537236213684e-01
    z[7,8,6]  R2749     -1.7198163270950317e-01
    z[7,8,6]  R2750     9.7616732120513916e-02
    z[7,8,6]  R2751     8.6575500667095184e-02
    z[7,8,6]  R2752     2.6357337832450867e-01
    z[7,8,6]  R2753     9.2977419495582581e-02
    z[7,8,6]  R2754     1.7765671014785767e-01
    z[7,8,6]  R2755     0.538210928440094
    z[7,8,6]  R2756     -9.9790245294570923e-02
    z[7,8,6]  R2757     0.267120897769928
    z[7,8,6]  R2758     -7.2021287679672241e-01
    z[7,8,6]  R2759     1.5352459251880646e-01
    z[7,8,6]  R2760     0.329188734292984
    z[7,8,6]  R2761     2.3916792869567871e-01
    z[7,8,6]  R2762     -1.8713575601577759e-01
    z[7,8,6]  R2763     4.9038669466972351e-01
    z[7,8,6]  R2764     -2.7009156346321106e-01
    z[7,8,6]  R2765     5.6678575277328491e-01
    z[7,8,6]  R2766     3.7452098727226257e-01
    z[7,8,6]  R2767     1.6239304840564728e-01
    z[7,8,6]  R2768     3.7542721629142761e-01
    z[7,8,6]  R2769     -5.5112581700086594e-02
    z[7,8,6]  R2770     -4.4175809621810913e-01
    z[7,8,6]  R2771     2.0904199779033661e-01
    z[7,8,6]  R2772     -3.4600594639778137e-01
    z[7,8,6]  R2773     1.0638792812824249e-01
    z[7,8,6]  R2774     5.7504154741764069e-02
    z[7,8,6]  R2775     7.3766849935054779e-02
    z[7,8,6]  R2776     3.7288421392440796e-01
    z[7,8,6]  R2777     -3.0995625257492065e-01
    z[7,8,6]  R2778     -2.8730648756027222e-01
    z[7,8,6]  R2779     -3.0975034832954407e-01
    z[7,8,6]  R2780     2.0896416902542114e-01
    z[7,8,6]  R2781     1.2505804002285004e-01
    z[7,8,6]  R2782     -5.4767656326293945e-01
    z[7,8,6]  R2783     -5.5913275480270386e-01
    z[7,8,6]  R2784     -2.9187005758285522e-01
    z[7,8,6]  R2785     5.7579171657562256e-01
    z[7,8,6]  R2786     -4.8718109726905823e-01
    z[7,8,6]  R2787     -5.5757766962051392e-01
    z[7,8,6]  R2788     1.5979956090450287e-01
    z[7,8,6]  R2789     1.1773577332496643e-01
    z[7,8,6]  R2790     -1.1788261681795120e-01
    z[7,8,6]  R2791     3.7980252504348755e-01
    z[7,8,6]  R2792     -1.0959913581609726e-01
    z[7,8,6]  R2793     -1.5310059487819672e-01
    z[7,8,6]  R2794     -7.4085518717765808e-02
    z[7,8,6]  R2795     -1.8072827160358429e-01
    z[7,8,6]  R2796     -4.6383801102638245e-01
    z[7,8,6]  R2797     1.4695416390895844e-01
    z[7,8,6]  R2798     2.5241279974579811e-02
    z[7,8,6]  R2799     -2.5018927454948425e-01
    z[7,8,6]  R2800     -3.3541226387023926e-01
    z[7,8,6]  R2801     3.1361293792724609e-01
    z[7,8,6]  R2802     2.8857663273811340e-01
    z[7,8,6]  R2803     -2.0775970816612244e-01
    z[7,8,6]  R2804     4.2690834403038025e-01
    z[7,8,6]  R2805     -2.1375331282615662e-01
    z[7,8,6]  R2806     1.6016711294651031e-01
    z[7,8,6]  R2807     8.2306535914540291e-03
    z[7,8,6]  R2808     1.4425319433212280e-01
    z[7,8,6]  R2809     5.8335000276565552e-01
    z[7,8,6]  R2810     -2.3129422962665558e-01
    z[7,8,6]  R2811     1.6793212294578552e-01
    z[7,8,6]  R2812     -3.8830515742301941e-01
    z[7,8,6]  R2813     -3.7465396523475647e-01
    z[7,8,6]  R2814     5.2417159080505371e-02
    z[7,8,6]  R2815     -0.200520858168602
    z[7,8,6]  R2816     2.5251591205596924e-01
    z[7,8,6]  R2817     -0.011157201603055
    z[7,8,6]  R2818     4.9335334450006485e-02
    z[7,8,6]  R2819     -4.9009706825017929e-02
    z[7,8,6]  R2820     1.0897734016180038e-01
    z[7,8,6]  R2821     -2.9252591729164124e-01
    z[7,8,6]  R2822     9.0420506894588470e-02
    z[7,8,6]  R2823     -2.0941365510225296e-02
    z[7,8,6]  R2824     -4.7655689716339111e-01
    z[7,8,6]  R2825     -3.7927865982055664e-01
    z[7,8,6]  R2826     0.0328315831720829
    z[7,8,6]  R2827     -1.6944380104541779e-01
    z[7,8,6]  R2828     -7.0934578776359558e-02
    z[8,7,0]  R65       1
    z[8,7,0]  R74       -1
    z[8,7,0]  R2829     -1
    z[8,7,0]  R2830     1
    z[8,7,0]  R2843     -4.1689458489418030e-01
    z[8,7,0]  R2844     -4.8468196392059326e-01
    z[8,7,0]  R2845     -5.7306480407714844e-01
    z[8,7,0]  R2846     -3.4239238500595093e-01
    z[8,7,0]  R2847     -6.0957503318786621e-01
    z[8,7,0]  R2848     -3.2015225291252136e-01
    z[8,7,0]  R2849     -3.0857360363006592e-01
    z[8,7,0]  R2850     -3.9235708117485046e-01
    z[8,7,0]  R2851     -3.4801444411277771e-01
    z[8,7,0]  R2852     3.6987990140914917e-02
    z[8,7,0]  R2853     3.7160363048315048e-02
    z[8,7,0]  R2854     4.9446426331996918e-02
    z[8,7,0]  R2855     9.2987410724163055e-02
    z[8,7,0]  R2856     1.6451187431812286e-01
    z[8,7,0]  R2857     3.8392234593629837e-02
    z[8,7,0]  R2858     2.3820878937840462e-02
    z[8,7,0]  R2859     -3.6871144175529480e-01
    z[8,7,0]  R2860     -1.8168369308114052e-02
    z[8,7,0]  R2861     4.3558844923973083e-01
    z[8,7,0]  R2862     -3.8961544632911682e-02
    z[8,7,0]  R2863     2.1219049394130707e-01
    z[8,7,0]  R2864     1.0946871340274811e-01
    z[8,7,0]  R2865     -1.0069070756435394e-01
    z[8,7,0]  R2866     5.2443742752075195e-02
    z[8,7,0]  R2867     2.7736195921897888e-01
    z[8,7,0]  R2868     -9.2849425971508026e-02
    z[8,7,0]  R2869     -9.0580090880393982e-02
    z[8,7,0]  R2870     -1.5218126773834229e-01
    z[8,7,0]  R2871     -3.0100749805569649e-02
    z[8,7,0]  R2872     -3.4075182676315308e-01
    z[8,7,0]  R2873     -1.8804021179676056e-01
    z[8,7,0]  R2874     -1.2020721286535263e-01
    z[8,7,0]  R2875     1.3284712098538876e-02
    z[8,7,0]  R2876     -1.1131456494331360e-01
    z[8,7,0]  R2877     -1.0430975258350372e-01
    z[8,7,0]  R2878     -2.2587503492832184e-01
    z[8,7,0]  R2879     -1.0576321184635162e-01
    z[8,7,0]  R2880     -2.6120189577341080e-02
    z[8,7,0]  R2881     8.6152262985706329e-02
    z[8,7,0]  R2882     1.7868988215923309e-01
    z[8,7,0]  R2883     2.1687847375869751e-01
    z[8,7,0]  R2884     -7.6703220605850220e-02
    z[8,7,0]  R2885     -5.7236045598983765e-01
    z[8,7,0]  R2886     3.7944954633712769e-01
    z[8,7,0]  R2887     -1.9736465811729431e-01
    z[8,7,0]  R2888     -3.9486771821975708e-01
    z[8,7,0]  R2889     0.0852629616856575
    z[8,7,0]  R2890     -2.9006785154342651e-01
    z[8,7,0]  R2891     1.5264980494976044e-01
    z[8,7,0]  R2892     2.2403240203857422e-01
    z[8,7,0]  R2893     -2.2230571508407593e-01
    z[8,7,0]  R2894     -3.1105026602745056e-01
    z[8,7,0]  R2895     -5.1620435714721680e-01
    z[8,7,0]  R2896     -1.7105893790721893e-01
    z[8,7,0]  R2897     2.1935540437698364e-01
    z[8,7,0]  R2898     1.0663330322131515e-03
    z[8,7,0]  R2899     -3.1086322665214539e-01
    z[8,7,0]  R2900     4.4636088609695435e-01
    z[8,7,0]  R2901     6.9318538904190063e-01
    z[8,7,0]  R2902     8.1855165958404541e-01
    z[8,7,0]  R2903     4.0272515267133713e-02
    z[8,7,0]  R2904     3.4263002872467041e-01
    z[8,7,0]  R2905     -1.5010145306587219e-01
    z[8,7,0]  R2906     -1.5877915918827057e-01
    z[8,7,0]  R2907     -2.8038141131401062e-01
    z[8,7,0]  R2908     2.9783645272254944e-01
    z[8,7,0]  R2909     -3.5361889004707336e-01
    z[8,7,0]  R2910     -2.7545174956321716e-01
    z[8,7,0]  R2911     -3.9055564999580383e-01
    z[8,7,0]  R2912     3.1482365727424622e-01
    z[8,7,0]  R2913     1.7461758852005005e-01
    z[8,7,0]  R2914     -2.4204730987548828e-01
    z[8,7,0]  R2915     -3.5855054855346680e-01
    z[8,7,0]  R2916     -2.6036825776100159e-01
    z[8,7,0]  R2917     2.1546375751495361e-01
    z[8,7,0]  R2918     6.7238390445709229e-02
    z[8,7,0]  R2919     -2.7760851383209229e-01
    z[8,7,0]  R2920     7.6810318231582642e-01
    z[8,7,0]  R2921     9.5003110170364380e-01
    z[8,7,0]  R2922     9.3456918001174927e-01
    z[8,7,0]  R2923     -0.875144362449646
    z[8,7,0]  R2924     -8.4285628795623779e-01
    z[8,7,0]  R2925     3.0327999591827393e-01
    z[8,7,0]  R2926     0.49473837018013
    z[8,7,0]  R2927     -0.752993643283844
    z[8,7,0]  R2928     -0.77369225025177
    z[8,7,0]  R2929     4.2660427093505859e-01
    z[8,7,0]  R2930     4.4296678900718689e-01
    z[8,7,0]  R2931     -9.2004263401031494e-01
    z[8,7,0]  R2932     4.6739596128463745e-01
    z[8,7,0]  R2933     2.0212334394454956e-01
    z[8,7,0]  R2934     1.2268134206533432e-01
    z[8,7,0]  R2935     -3.7628674507141113e-01
    z[8,7,0]  R2936     -1.9652925431728363e-02
    z[8,7,0]  R2937     0.600912868976593
    z[8,7,0]  R2938     -4.9089828133583069e-01
    z[8,7,0]  R2939     2.5963410735130310e-01
    z[8,7,0]  R2940     1.5229165554046631e-01
    z[8,7,0]  R2941     6.2417393922805786e-01
    z[8,7,0]  R2942     -0.00672629289329052
    z[8,7,0]  R2943     -5.8581322431564331e-01
    z[8,7,0]  R2944     3.2990756630897522e-01
    z[8,7,0]  R2945     -3.9063400030136108e-01
    z[8,7,0]  R2946     0.0756821483373642
    z[8,7,0]  R2947     -7.0084281265735626e-02
    z[8,7,0]  R2948     -2.7865487337112427e-01
    z[8,7,1]  R66       1
    z[8,7,1]  R75       -1
    z[8,7,1]  R2831     -1
    z[8,7,1]  R2832     1
    z[8,7,1]  R2843     -3.3204442262649536e-01
    z[8,7,1]  R2844     -2.5690299272537231e-01
    z[8,7,1]  R2845     -4.6997055411338806e-01
    z[8,7,1]  R2846     -4.6174040436744690e-01
    z[8,7,1]  R2847     -4.8508054018020630e-01
    z[8,7,1]  R2848     -0.602096676826477
    z[8,7,1]  R2849     1.2655800208449364e-02
    z[8,7,1]  R2850     -1.6722084954380989e-02
    z[8,7,1]  R2851     -1.5665067732334137e-01
    z[8,7,1]  R2852     2.9285481572151184e-01
    z[8,7,1]  R2853     7.0536142587661743e-01
    z[8,7,1]  R2854     3.4541028738021851e-01
    z[8,7,1]  R2855     0.516209065914154
    z[8,7,1]  R2856     4.8548287153244019e-01
    z[8,7,1]  R2857     3.3199149370193481e-01
    z[8,7,1]  R2858     5.1212704181671143e-01
    z[8,7,1]  R2859     5.9532564878463745e-01
    z[8,7,1]  R2860     6.3990515470504761e-01
    z[8,7,1]  R2861     4.8651802539825439e-01
    z[8,7,1]  R2862     4.3544858694076538e-01
    z[8,7,1]  R2863     -3.4603667259216309e-01
    z[8,7,1]  R2864     0.720102846622467
    z[8,7,1]  R2865     -4.8885107971727848e-03
    z[8,7,1]  R2866     6.4501903951168060e-02
    z[8,7,1]  R2867     -2.0838995277881622e-01
    z[8,7,1]  R2868     -2.4802862107753754e-01
    z[8,7,1]  R2869     -7.4762886762619019e-01
    z[8,7,1]  R2870     4.9201175570487976e-02
    z[8,7,1]  R2871     3.2671761512756348e-01
    z[8,7,1]  R2872     -1.0198544710874557e-01
    z[8,7,1]  R2873     -2.8616625815629959e-02
    z[8,7,1]  R2874     3.1933152675628662e-01
    z[8,7,1]  R2875     6.5530651807785034e-01
    z[8,7,1]  R2876     -7.6302891969680786e-01
    z[8,7,1]  R2877     -0.713287353515625
    z[8,7,1]  R2878     3.4502479434013367e-01
    z[8,7,1]  R2879     -1.5632529556751251e-01
    z[8,7,1]  R2880     4.4123733043670654e-01
    z[8,7,1]  R2881     -4.0507555007934570e-01
    z[8,7,1]  R2882     -7.1970999240875244e-02
    z[8,7,1]  R2883     -1.0386711359024048e-01
    z[8,7,1]  R2884     -0.826941728591919
    z[8,7,1]  R2885     5.5064874887466431e-01
    z[8,7,1]  R2886     5.6682562828063965e-01
    z[8,7,1]  R2887     -0.637488067150116
    z[8,7,1]  R2888     3.1302982568740845e-01
    z[8,7,1]  R2889     -4.3343013525009155e-01
    z[8,7,1]  R2890     -5.8169806003570557e-01
    z[8,7,1]  R2891     8.8284105062484741e-01
    z[8,7,1]  R2892     7.3823785781860352e-01
    z[8,7,1]  R2893     -7.5214987993240356e-01
    z[8,7,1]  R2894     4.9054896831512451e-01
    z[8,7,1]  R2895     4.3570250272750854e-01
    z[8,7,1]  R2896     9.2652714252471924e-01
    z[8,7,1]  R2897     8.0565035343170166e-01
    z[8,7,1]  R2898     -5.6556481122970581e-01
    z[8,7,1]  R2899     4.0573990345001221e-01
    z[8,7,1]  R2900     6.1703330278396606e-01
    z[8,7,1]  R2901     -1.1697446554899216e-01
    z[8,7,1]  R2902     -1.9792547821998596e-01
    z[8,7,1]  R2903     -1.3860097527503967e-01
    z[8,7,1]  R2904     0.715706467628479
    z[8,7,1]  R2905     6.6889148950576782e-01
    z[8,7,1]  R2906     2.9724597930908203e-01
    z[8,7,1]  R2907     -6.8008792400360107e-01
    z[8,7,1]  R2908     8.8679903745651245e-01
    z[8,7,1]  R2909     -7.1929872035980225e-01
    z[8,7,1]  R2910     -3.0911669135093689e-01
    z[8,7,1]  R2911     3.7147161364555359e-01
    z[8,7,1]  R2912     0.74797123670578
    z[8,7,1]  R2913     7.5768578052520752e-01
    z[8,7,1]  R2914     -3.3206534385681152e-01
    z[8,7,1]  R2915     -7.1302127838134766e-01
    z[8,7,1]  R2916     6.7258435487747192e-01
    z[8,7,1]  R2917     7.0505040884017944e-01
    z[8,7,1]  R2918     -6.5480205230414867e-03
    z[8,7,1]  R2919     -7.0366328954696655e-01
    z[8,7,1]  R2920     -3.0529114603996277e-01
    z[8,7,1]  R2921     1.3688798062503338e-02
    z[8,7,1]  R2922     4.1255757212638855e-02
    z[8,7,1]  R2923     -3.2509317994117737e-01
    z[8,7,1]  R2924     -3.7371414899826050e-01
    z[8,7,1]  R2925     -1.4021454751491547e-01
    z[8,7,1]  R2926     -5.7073984295129776e-02
    z[8,7,1]  R2927     -3.5664337873458862e-01
    z[8,7,1]  R2928     -4.2401197552680969e-01
    z[8,7,1]  R2929     1.3849431276321411e-01
    z[8,7,1]  R2930     -5.0555467605590820e-01
    z[8,7,1]  R2931     -1.2142102420330048e-01
    z[8,7,1]  R2932     -8.8083013892173767e-02
    z[8,7,1]  R2933     2.7182260155677795e-01
    z[8,7,1]  R2934     -5.5153530836105347e-01
    z[8,7,1]  R2935     -1.0597542673349380e-01
    z[8,7,1]  R2936     7.0410065352916718e-02
    z[8,7,1]  R2937     -1.9849333167076111e-01
    z[8,7,1]  R2938     6.2866485118865967e-01
    z[8,7,1]  R2939     6.6600114107131958e-01
    z[8,7,1]  R2940     -7.1782833337783813e-01
    z[8,7,1]  R2941     2.1348838508129120e-01
    z[8,7,1]  R2942     6.4152634143829346e-01
    z[8,7,1]  R2943     1.6194520890712738e-01
    z[8,7,1]  R2944     4.6813324093818665e-01
    z[8,7,1]  R2945     2.2116348147392273e-01
    z[8,7,1]  R2946     -4.2823565006256104e-01
    z[8,7,1]  R2947     -7.7649158239364624e-01
    z[8,7,1]  R2948     5.6602191925048828e-01
    z[8,7,2]  R67       1
    z[8,7,2]  R76       -1
    z[8,7,2]  R2833     -1
    z[8,7,2]  R2834     1
    z[8,7,2]  R2843     4.2972904443740845e-01
    z[8,7,2]  R2844     2.9859790205955505e-01
    z[8,7,2]  R2845     -1.4298494160175323e-01
    z[8,7,2]  R2846     1.9827237725257874e-01
    z[8,7,2]  R2847     2.4667717516422272e-01
    z[8,7,2]  R2848     6.6764909029006958e-01
    z[8,7,2]  R2849     0.749691903591156
    z[8,7,2]  R2850     0.794209361076355
    z[8,7,2]  R2851     7.4640804529190063e-01
    z[8,7,2]  R2852     -5.7840985059738159e-01
    z[8,7,2]  R2853     -4.9356621503829956e-01
    z[8,7,2]  R2854     -5.4023534059524536e-01
    z[8,7,2]  R2855     -6.4635413885116577e-01
    z[8,7,2]  R2856     -9.2058137059211731e-02
    z[8,7,2]  R2857     -7.9390835762023926e-01
    z[8,7,2]  R2858     -4.5745104551315308e-01
    z[8,7,2]  R2859     -3.7056869268417358e-01
    z[8,7,2]  R2860     -4.0922570228576660e-01
    z[8,7,2]  R2861     -4.8002764582633972e-01
    z[8,7,2]  R2862     -6.8645268678665161e-01
    z[8,7,2]  R2863     4.0704756975173950e-01
    z[8,7,2]  R2864     -3.5753306746482849e-01
    z[8,7,2]  R2865     -3.2452747225761414e-01
    z[8,7,2]  R2866     -1.6314937174320221e-01
    z[8,7,2]  R2867     1.8298590555787086e-02
    z[8,7,2]  R2868     -2.8553183656185865e-03
    z[8,7,2]  R2869     -4.5324909687042236e-01
    z[8,7,2]  R2870     7.4352012015879154e-03
    z[8,7,2]  R2871     1.7782163619995117e-01
    z[8,7,2]  R2872     9.8059467971324921e-02
    z[8,7,2]  R2873     3.7972810864448547e-01
    z[8,7,2]  R2874     -6.2939512729644775e-01
    z[8,7,2]  R2875     -0.642380952835083
    z[8,7,2]  R2876     -6.9627188146114349e-02
    z[8,7,2]  R2877     -1.6084440052509308e-01
    z[8,7,2]  R2878     -5.4775995016098022e-01
    z[8,7,2]  R2879     -4.4738808274269104e-01
    z[8,7,2]  R2880     -5.5230081081390381e-01
    z[8,7,2]  R2881     4.3478560447692871e-01
    z[8,7,2]  R2882     -5.3456395864486694e-01
    z[8,7,2]  R2883     4.4696268439292908e-01
    z[8,7,2]  R2884     -2.2541087865829468e-01
    z[8,7,2]  R2885     -4.3915849924087524e-01
    z[8,7,2]  R2886     -6.5261960029602051e-01
    z[8,7,2]  R2887     -1.2304015457630157e-01
    z[8,7,2]  R2888     -6.2947779893875122e-01
    z[8,7,2]  R2889     -3.2969605177640915e-02
    z[8,7,2]  R2890     -3.2634842395782471e-01
    z[8,7,2]  R2891     2.6758614182472229e-01
    z[8,7,2]  R2892     4.3983215093612671e-01
    z[8,7,2]  R2893     -9.5280326902866364e-02
    z[8,7,2]  R2894     -0.634859025478363
    z[8,7,2]  R2895     -6.4517909288406372e-01
    z[8,7,2]  R2896     0.0360434390604496
    z[8,7,2]  R2897     4.5218861103057861e-01
    z[8,7,2]  R2898     -1.2078131549060345e-02
    z[8,7,2]  R2899     1.2855865061283112e-01
    z[8,7,2]  R2900     5.5934345722198486e-01
    z[8,7,2]  R2901     -2.0315490663051605e-01
    z[8,7,2]  R2902     -1.4706824719905853e-01
    z[8,7,2]  R2903     1.7670039832592010e-01
    z[8,7,2]  R2904     -4.8426979780197144e-01
    z[8,7,2]  R2905     -2.8648141026496887e-01
    z[8,7,2]  R2906     -6.8398404121398926e-01
    z[8,7,2]  R2907     -5.9787672013044357e-02
    z[8,7,2]  R2908     -1.4526379108428955e-01
    z[8,7,2]  R2909     3.9475105702877045e-02
    z[8,7,2]  R2910     2.5788527727127075e-01
    z[8,7,2]  R2911     -4.6022129058837891e-01
    z[8,7,2]  R2912     5.2115124464035034e-01
    z[8,7,2]  R2913     -2.4724586308002472e-01
    z[8,7,2]  R2914     3.8947898149490356e-01
    z[8,7,2]  R2915     -1.5772011876106262e-01
    z[8,7,2]  R2916     -0.574109673500061
    z[8,7,2]  R2917     -4.5492088794708252e-01
    z[8,7,2]  R2918     4.2822387814521790e-01
    z[8,7,2]  R2919     -2.8702369332313538e-01
    z[8,7,2]  R2920     -0.175094336271286
    z[8,7,2]  R2921     6.2799490988254547e-02
    z[8,7,2]  R2922     2.5760421156883240e-01
    z[8,7,2]  R2923     -8.3633601665496826e-02
    z[8,7,2]  R2924     -1.8221169710159302e-01
    z[8,7,2]  R2925     1.1443043500185013e-01
    z[8,7,2]  R2926     -7.1232281625270844e-03
    z[8,7,2]  R2927     4.2429044842720032e-01
    z[8,7,2]  R2928     2.5737419724464417e-01
    z[8,7,2]  R2929     0.021140206605196
    z[8,7,2]  R2930     1.1720012128353119e-01
    z[8,7,2]  R2931     1.7755547165870667e-01
    z[8,7,2]  R2932     -2.3838618397712708e-01
    z[8,7,2]  R2933     0.489644855260849
    z[8,7,2]  R2934     -6.5385311841964722e-01
    z[8,7,2]  R2935     4.6000808477401733e-01
    z[8,7,2]  R2936     -0.362640917301178
    z[8,7,2]  R2937     -2.2667229175567627e-01
    z[8,7,2]  R2938     -3.2671579718589783e-01
    z[8,7,2]  R2939     -6.1208885908126831e-01
    z[8,7,2]  R2940     4.4338649511337280e-01
    z[8,7,2]  R2941     -2.5458136200904846e-01
    z[8,7,2]  R2942     4.2926692962646484e-01
    z[8,7,2]  R2943     -2.9571041464805603e-01
    z[8,7,2]  R2944     -5.3677827119827271e-01
    z[8,7,2]  R2945     -4.1452956199645996e-01
    z[8,7,2]  R2946     2.5877401232719421e-01
    z[8,7,2]  R2947     1.3095535337924957e-01
    z[8,7,2]  R2948     3.1691205501556396e-01
    z[8,7,3]  R68       1
    z[8,7,3]  R77       -1
    z[8,7,3]  R2835     -1
    z[8,7,3]  R2836     1
    z[8,7,3]  R2843     7.0460617542266846e-01
    z[8,7,3]  R2844     6.3385230302810669e-01
    z[8,7,3]  R2845     5.1752287149429321e-01
    z[8,7,3]  R2846     0.691716730594635
    z[8,7,3]  R2847     -2.8274807333946228e-01
    z[8,7,3]  R2848     2.2858205437660217e-01
    z[8,7,3]  R2849     -9.3946717679500580e-02
    z[8,7,3]  R2850     -9.8623782396316528e-02
    z[8,7,3]  R2851     1.6305133700370789e-02
    z[8,7,3]  R2852     2.3331997916102409e-02
    z[8,7,3]  R2853     6.5564163029193878e-02
    z[8,7,3]  R2854     5.2176183462142944e-01
    z[8,7,3]  R2855     4.3301886320114136e-01
    z[8,7,3]  R2856     -7.2795635461807251e-01
    z[8,7,3]  R2857     1.0284223407506943e-01
    z[8,7,3]  R2858     5.7892650365829468e-01
    z[8,7,3]  R2859     1.1072061210870743e-01
    z[8,7,3]  R2860     4.8190414905548096e-01
    z[8,7,3]  R2861     5.4360177367925644e-02
    z[8,7,3]  R2862     -6.8826384842395782e-02
    z[8,7,3]  R2863     -8.1118786334991455e-01
    z[8,7,3]  R2864     0.0860656350851059
    z[8,7,3]  R2865     -0.528769314289093
    z[8,7,3]  R2866     -4.9167567491531372e-01
    z[8,7,3]  R2867     -6.5119296312332153e-01
    z[8,7,3]  R2868     -7.0396721363067627e-01
    z[8,7,3]  R2869     -3.1340688467025757e-01
    z[8,7,3]  R2870     -6.6030627489089966e-01
    z[8,7,3]  R2871     -4.8219156265258789e-01
    z[8,7,3]  R2872     -5.1669472455978394e-01
    z[8,7,3]  R2873     -0.783909022808075
    z[8,7,3]  R2874     6.4680272340774536e-01
    z[8,7,3]  R2875     1.1100284755229950e-02
    z[8,7,3]  R2876     -1.9375425577163696e-01
    z[8,7,3]  R2877     4.3256103992462158e-02
    z[8,7,3]  R2878     6.3257914781570435e-01
    z[8,7,3]  R2879     -4.0427660942077637e-01
    z[8,7,3]  R2880     2.4229690432548523e-01
    z[8,7,3]  R2881     3.9681177586317062e-02
    z[8,7,3]  R2882     -7.1501910686492920e-01
    z[8,7,3]  R2883     -7.5669950246810913e-01
    z[8,7,3]  R2884     4.7563002444803715e-03
    z[8,7,3]  R2885     8.6002998054027557e-02
    z[8,7,3]  R2886     -1.5803065896034241e-01
    z[8,7,3]  R2887     -5.2056068181991577e-01
    z[8,7,3]  R2888     -8.8108986616134644e-02
    z[8,7,3]  R2889     -1.6161488369107246e-02
    z[8,7,3]  R2890     -3.6090412735939026e-01
    z[8,7,3]  R2891     2.4224698543548584e-01
    z[8,7,3]  R2892     2.5279900431632996e-01
    z[8,7,3]  R2893     3.5884881019592285e-01
    z[8,7,3]  R2894     1.4230453968048096e-01
    z[8,7,3]  R2895     -1.0548471659421921e-01
    z[8,7,3]  R2896     9.3076996505260468e-02
    z[8,7,3]  R2897     1.9540201127529144e-01
    z[8,7,3]  R2898     -3.2591944932937622e-01
    z[8,7,3]  R2899     1.2794514000415802e-01
    z[8,7,3]  R2900     -3.7251997739076614e-02
    z[8,7,3]  R2901     -2.0874477922916412e-01
    z[8,7,3]  R2902     -4.8169005662202835e-02
    z[8,7,3]  R2903     -5.8753520250320435e-01
    z[8,7,3]  R2904     8.5866108536720276e-02
    z[8,7,3]  R2905     3.1356829404830933e-01
    z[8,7,3]  R2906     3.1444475054740906e-01
    z[8,7,3]  R2907     -4.0305379033088684e-01
    z[8,7,3]  R2908     1.4074213802814484e-01
    z[8,7,3]  R2909     -0.36433145403862
    z[8,7,3]  R2910     -1.5327471494674683e-01
    z[8,7,3]  R2911     6.5086834132671356e-02
    z[8,7,3]  R2912     -1.3650661706924438e-01
    z[8,7,3]  R2913     5.3470355272293091e-01
    z[8,7,3]  R2914     -1.8591515719890594e-01
    z[8,7,3]  R2915     -3.2681983709335327e-01
    z[8,7,3]  R2916     -1.1359921097755432e-01
    z[8,7,3]  R2917     1.7740766704082489e-01
    z[8,7,3]  R2918     -2.6093408465385437e-01
    z[8,7,3]  R2919     -2.4626623094081879e-01
    z[8,7,3]  R2920     1.6839888691902161e-01
    z[8,7,3]  R2921     1.1186099052429199e-01
    z[8,7,3]  R2922     2.2514252364635468e-01
    z[8,7,3]  R2923     2.1107150614261627e-01
    z[8,7,3]  R2924     1.2576033174991608e-01
    z[8,7,3]  R2925     3.3855074644088745e-01
    z[8,7,3]  R2926     6.2545055150985718e-01
    z[8,7,3]  R2927     -2.8825110197067261e-01
    z[8,7,3]  R2928     -6.9849081337451935e-02
    z[8,7,3]  R2929     -2.2724264860153198e-01
    z[8,7,3]  R2930     -4.1251521557569504e-02
    z[8,7,3]  R2931     -1.6425649821758270e-01
    z[8,7,3]  R2932     1.4775149524211884e-01
    z[8,7,3]  R2933     -2.7906140685081482e-01
    z[8,7,3]  R2934     -1.4813390374183655e-01
    z[8,7,3]  R2935     -4.4711455702781677e-03
    z[8,7,3]  R2936     1.3549655675888062e-01
    z[8,7,3]  R2937     -6.8883955478668213e-02
    z[8,7,3]  R2938     -2.3259213566780090e-01
    z[8,7,3]  R2939     1.3596434891223907e-01
    z[8,7,3]  R2940     3.0119559168815613e-01
    z[8,7,3]  R2941     4.7901353240013123e-01
    z[8,7,3]  R2942     -1.2442321516573429e-02
    z[8,7,3]  R2943     -4.5735651254653931e-01
    z[8,7,3]  R2944     -1.4352932572364807e-01
    z[8,7,3]  R2945     -7.3164153099060059e-01
    z[8,7,3]  R2946     -4.7864401340484619e-01
    z[8,7,3]  R2947     0.517343282699585
    z[8,7,3]  R2948     3.3343502879142761e-01
    z[8,7,4]  R69       1
    z[8,7,4]  R78       -1
    z[8,7,4]  R2837     -1
    z[8,7,4]  R2838     1
    z[8,7,4]  R2843     6.0182854533195496e-02
    z[8,7,4]  R2844     0.334433376789093
    z[8,7,4]  R2845     3.5058698058128357e-01
    z[8,7,4]  R2846     -1.5981499850749969e-01
    z[8,7,4]  R2847     4.5273166894912720e-01
    z[8,7,4]  R2848     7.1975603699684143e-02
    z[8,7,4]  R2849     2.0932009816169739e-01
    z[8,7,4]  R2850     4.3899127840995789e-01
    z[8,7,4]  R2851     4.7448903322219849e-01
    z[8,7,4]  R2852     1.0534477978944778e-01
    z[8,7,4]  R2853     -2.8116098046302795e-01
    z[8,7,4]  R2854     -3.7564691901206970e-01
    z[8,7,4]  R2855     -2.3733133077621460e-01
    z[8,7,4]  R2856     4.0176185965538025e-01
    z[8,7,4]  R2857     -3.4186564385890961e-02
    z[8,7,4]  R2858     -2.3181053996086121e-01
    z[8,7,4]  R2859     -1.7737166583538055e-01
    z[8,7,4]  R2860     1.1563534289598465e-01
    z[8,7,4]  R2861     -0.551505982875824
    z[8,7,4]  R2862     3.9585113525390625e-01
    z[8,7,4]  R2863     1.0906083509325981e-02
    z[8,7,4]  R2864     -3.6826786398887634e-01
    z[8,7,4]  R2865     -6.5377938747406006e-01
    z[8,7,4]  R2866     -7.1659630537033081e-01
    z[8,7,4]  R2867     -5.6170392036437988e-01
    z[8,7,4]  R2868     -6.2472081184387207e-01
    z[8,7,4]  R2869     -0.252750426530838
    z[8,7,4]  R2870     -6.1852902173995972e-01
    z[8,7,4]  R2871     -7.0063984394073486e-01
    z[8,7,4]  R2872     -6.9972926378250122e-01
    z[8,7,4]  R2873     2.1617035567760468e-01
    z[8,7,4]  R2874     -1.0089616477489471e-01
    z[8,7,4]  R2875     3.2417541742324829e-01
    z[8,7,4]  R2876     -2.3014199733734131e-01
    z[8,7,4]  R2877     -3.6255308985710144e-01
    z[8,7,4]  R2878     1.5050463378429413e-01
    z[8,7,4]  R2879     2.3566101491451263e-01
    z[8,7,4]  R2880     2.0459690690040588e-01
    z[8,7,4]  R2881     -4.9369612336158752e-01
    z[8,7,4]  R2882     1.3406861573457718e-02
    z[8,7,4]  R2883     7.9505115747451782e-02
    z[8,7,4]  R2884     -4.9428895115852356e-01
    z[8,7,4]  R2885     -0.0761650800704956
    z[8,7,4]  R2886     -2.6672041416168213e-01
    z[8,7,4]  R2887     3.6464941501617432e-01
    z[8,7,4]  R2888     -2.1595989167690277e-01
    z[8,7,4]  R2889     -6.0959827899932861e-01
    z[8,7,4]  R2890     3.5240563750267029e-01
    z[8,7,4]  R2891     1.9147807359695435e-01
    z[8,7,4]  R2892     -9.4949059188365936e-02
    z[8,7,4]  R2893     -4.2940896749496460e-01
    z[8,7,4]  R2894     2.9315361380577087e-01
    z[8,7,4]  R2895     -0.0841350331902504
    z[8,7,4]  R2896     1.3752470910549164e-01
    z[8,7,4]  R2897     1.0821728408336639e-01
    z[8,7,4]  R2898     -3.8458526134490967e-02
    z[8,7,4]  R2899     7.3545169830322266e-01
    z[8,7,4]  R2900     -2.6146358251571655e-01
    z[8,7,4]  R2901     2.3412831127643585e-02
    z[8,7,4]  R2902     4.8646613955497742e-02
    z[8,7,4]  R2903     1.9688895344734192e-01
    z[8,7,4]  R2904     -2.6365187764167786e-01
    z[8,7,4]  R2905     1.6216847300529480e-01
    z[8,7,4]  R2906     1.0183297097682953e-01
    z[8,7,4]  R2907     3.6613830924034119e-01
    z[8,7,4]  R2908     2.5276171043515205e-02
    z[8,7,4]  R2909     3.9034810662269592e-01
    z[8,7,4]  R2910     -5.8465617895126343e-01
    z[8,7,4]  R2911     -5.4090458154678345e-01
    z[8,7,4]  R2912     -2.1702301502227783e-01
    z[8,7,4]  R2913     -2.1139633655548096e-01
    z[8,7,4]  R2914     -5.1421147584915161e-01
    z[8,7,4]  R2915     3.8064935803413391e-01
    z[8,7,4]  R2916     2.8179755806922913e-01
    z[8,7,4]  R2917     1.6003543511033058e-02
    z[8,7,4]  R2918     -2.0782912150025368e-02
    z[8,7,4]  R2919     2.2558422386646271e-01
    z[8,7,4]  R2920     -1.8514131009578705e-01
    z[8,7,4]  R2921     2.2753329575061798e-01
    z[8,7,4]  R2922     5.2067141979932785e-02
    z[8,7,4]  R2923     1.9864018261432648e-01
    z[8,7,4]  R2924     1.1640612035989761e-01
    z[8,7,4]  R2925     2.6952770352363586e-01
    z[8,7,4]  R2926     -7.7194280922412872e-02
    z[8,7,4]  R2927     1.9731834530830383e-01
    z[8,7,4]  R2928     2.3781789839267731e-01
    z[8,7,4]  R2929     4.3728187680244446e-01
    z[8,7,4]  R2930     2.4609817564487457e-01
    z[8,7,4]  R2931     -2.6951423287391663e-01
    z[8,7,4]  R2932     -1.8707261979579926e-01
    z[8,7,4]  R2933     -4.1319724172353745e-02
    z[8,7,4]  R2934     -1.4623653143644333e-02
    z[8,7,4]  R2935     -7.5215756893157959e-01
    z[8,7,4]  R2936     -8.8260918855667114e-01
    z[8,7,4]  R2937     -5.8108150959014893e-01
    z[8,7,4]  R2938     3.1479981541633606e-01
    z[8,7,4]  R2939     2.9891505837440491e-01
    z[8,7,4]  R2940     3.9248377084732056e-01
    z[8,7,4]  R2941     4.9551013112068176e-01
    z[8,7,4]  R2942     1.4640846848487854e-01
    z[8,7,4]  R2943     1.4568759500980377e-01
    z[8,7,4]  R2944     3.9291998744010925e-01
    z[8,7,4]  R2945     8.3928229287266731e-03
    z[8,7,4]  R2946     5.3994381427764893e-01
    z[8,7,4]  R2947     3.2386413216590881e-01
    z[8,7,4]  R2948     2.9771456122398376e-01
    z[8,7,5]  R70       1
    z[8,7,5]  R79       -1
    z[8,7,5]  R2839     -1
    z[8,7,5]  R2840     1
    z[8,7,5]  R2843     -4.0111333131790161e-02
    z[8,7,5]  R2844     -2.9458436369895935e-01
    z[8,7,5]  R2845     -1.7900609970092773e-01
    z[8,7,5]  R2846     -2.3825907707214355e-01
    z[8,7,5]  R2847     1.9674451649188995e-01
    z[8,7,5]  R2848     -1.5321678481996059e-02
    z[8,7,5]  R2849     1.6504010185599327e-02
    z[8,7,5]  R2850     -5.1086336374282837e-02
    z[8,7,5]  R2851     -2.1501930430531502e-02
    z[8,7,5]  R2852     -2.1900095045566559e-01
    z[8,7,5]  R2853     -3.8801664113998413e-01
    z[8,7,5]  R2854     2.5432538986206055e-01
    z[8,7,5]  R2855     7.7942825853824615e-02
    z[8,7,5]  R2856     4.9140501767396927e-02
    z[8,7,5]  R2857     7.6111115515232086e-02
    z[8,7,5]  R2858     2.5701296329498291e-01
    z[8,7,5]  R2859     -8.5745364427566528e-02
    z[8,7,5]  R2860     -1.9198076426982880e-01
    z[8,7,5]  R2861     -9.8238639533519745e-02
    z[8,7,5]  R2862     -1.8779900670051575e-01
    z[8,7,5]  R2863     9.1455176472663879e-02
    z[8,7,5]  R2864     5.8820914477109909e-02
    z[8,7,5]  R2865     3.6578190326690674e-01
    z[8,7,5]  R2866     3.0248314142227173e-01
    z[8,7,5]  R2867     3.5836723446846008e-01
    z[8,7,5]  R2868     2.0174258947372437e-01
    z[8,7,5]  R2869     2.4466985464096069e-01
    z[8,7,5]  R2870     1.2938182055950165e-01
    z[8,7,5]  R2871     0.203104168176651
    z[8,7,5]  R2872     1.5726454555988312e-01
    z[8,7,5]  R2873     2.4988044798374176e-01
    z[8,7,5]  R2874     -1.2344833463430405e-01
    z[8,7,5]  R2875     1.9207081198692322e-01
    z[8,7,5]  R2876     1.0046100616455078e-01
    z[8,7,5]  R2877     -9.2327609658241272e-02
    z[8,7,5]  R2878     -1.4799048006534576e-01
    z[8,7,5]  R2879     4.6228629350662231e-01
    z[8,7,5]  R2880     -4.0209221839904785e-01
    z[8,7,5]  R2881     2.8853037953376770e-01
    z[8,7,5]  R2882     3.7438431382179260e-01
    z[8,7,5]  R2883     3.8681104779243469e-01
    z[8,7,5]  R2884     -3.5120215266942978e-02
    z[8,7,5]  R2885     1.3741073012351990e-01
    z[8,7,5]  R2886     2.6251502335071564e-02
    z[8,7,5]  R2887     -3.3485063910484314e-01
    z[8,7,5]  R2888     5.3847837448120117e-01
    z[8,7,5]  R2889     6.3186037540435791e-01
    z[8,7,5]  R2890     3.7381444126367569e-02
    z[8,7,5]  R2891     9.3511477112770081e-02
    z[8,7,5]  R2892     0.371217280626297
    z[8,7,5]  R2893     3.6413182970136404e-03
    z[8,7,5]  R2894     -2.0216912031173706e-01
    z[8,7,5]  R2895     1.0431414842605591e-01
    z[8,7,5]  R2896     1.1590618640184402e-02
    z[8,7,5]  R2897     -7.2658024728298187e-02
    z[8,7,5]  R2898     -6.2452876567840576e-01
    z[8,7,5]  R2899     3.4534335136413574e-01
    z[8,7,5]  R2900     -1.0845420509576797e-01
    z[8,7,5]  R2901     -6.4834314584732056e-01
    z[8,7,5]  R2902     -4.9363338947296143e-01
    z[8,7,5]  R2903     0.472953200340271
    z[8,7,5]  R2904     7.3955051600933075e-02
    z[8,7,5]  R2905     5.4328376054763794e-01
    z[8,7,5]  R2906     3.9821276068687439e-01
    z[8,7,5]  R2907     -1.3570861518383026e-01
    z[8,7,5]  R2908     -2.8387421369552612e-01
    z[8,7,5]  R2909     1.7517729103565216e-01
    z[8,7,5]  R2910     5.7705128192901611e-01
    z[8,7,5]  R2911     4.4803205132484436e-01
    z[8,7,5]  R2912     -4.0736470371484756e-02
    z[8,7,5]  R2913     -3.5944998264312744e-02
    z[8,7,5]  R2914     6.0712260007858276e-01
    z[8,7,5]  R2915     2.9833678156137466e-02
    z[8,7,5]  R2916     -2.2303852438926697e-01
    z[8,7,5]  R2917     -4.6621689200401306e-01
    z[8,7,5]  R2918     7.1863436698913574e-01
    z[8,7,5]  R2919     -3.0003547668457031e-01
    z[8,7,5]  R2920     -4.7163897752761841e-01
    z[8,7,5]  R2921     1.7729481682181358e-02
    z[8,7,5]  R2922     -9.3078408390283585e-03
    z[8,7,5]  R2923     -1.5223556756973267e-01
    z[8,7,5]  R2924     -2.9553923010826111e-01
    z[8,7,5]  R2925     -8.2567328214645386e-01
    z[8,7,5]  R2926     -5.8892178535461426e-01
    z[8,7,5]  R2927     0.0102920550853014
    z[8,7,5]  R2928     -1.5354523062705994e-01
    z[8,7,5]  R2929     -7.4437719583511353e-01
    z[8,7,5]  R2930     -6.2923544645309448e-01
    z[8,7,5]  R2931     1.0003616334870458e-03
    z[8,7,5]  R2932     -7.8459191322326660e-01
    z[8,7,5]  R2933     3.2752317190170288e-01
    z[8,7,5]  R2934     2.9305151104927063e-01
    z[8,7,5]  R2935     0.25819131731987
    z[8,7,5]  R2936     1.6984629631042480e-01
    z[8,7,5]  R2937     1.3491080701351166e-01
    z[8,7,5]  R2938     1.9046208262443542e-01
    z[8,7,5]  R2939     7.5718492269515991e-02
    z[8,7,5]  R2940     1.3869504630565643e-01
    z[8,7,5]  R2941     6.6094011999666691e-03
    z[8,7,5]  R2942     -1.0102125257253647e-01
    z[8,7,5]  R2943     5.5727428197860718e-01
    z[8,7,5]  R2944     4.5685586333274841e-01
    z[8,7,5]  R2945     -1.7816029489040375e-01
    z[8,7,5]  R2946     4.1981360316276550e-01
    z[8,7,5]  R2947     -6.5648332238197327e-03
    z[8,7,5]  R2948     -2.5988611578941345e-01
    z[8,7,6]  R71       1
    z[8,7,6]  R80       -1
    z[8,7,6]  R2841     -1
    z[8,7,6]  R2842     1
    z[8,7,6]  R2843     -1.7198163270950317e-01
    z[8,7,6]  R2844     9.7616732120513916e-02
    z[8,7,6]  R2845     8.6575500667095184e-02
    z[8,7,6]  R2846     2.6357337832450867e-01
    z[8,7,6]  R2847     9.2977419495582581e-02
    z[8,7,6]  R2848     1.7765671014785767e-01
    z[8,7,6]  R2849     0.538210928440094
    z[8,7,6]  R2850     -9.9790245294570923e-02
    z[8,7,6]  R2851     0.267120897769928
    z[8,7,6]  R2852     -7.2021287679672241e-01
    z[8,7,6]  R2853     1.5352459251880646e-01
    z[8,7,6]  R2854     0.329188734292984
    z[8,7,6]  R2855     2.3916792869567871e-01
    z[8,7,6]  R2856     -1.8713575601577759e-01
    z[8,7,6]  R2857     4.9038669466972351e-01
    z[8,7,6]  R2858     -2.7009156346321106e-01
    z[8,7,6]  R2859     5.6678575277328491e-01
    z[8,7,6]  R2860     3.7452098727226257e-01
    z[8,7,6]  R2861     1.6239304840564728e-01
    z[8,7,6]  R2862     3.7542721629142761e-01
    z[8,7,6]  R2863     -5.5112581700086594e-02
    z[8,7,6]  R2864     -4.4175809621810913e-01
    z[8,7,6]  R2865     2.0904199779033661e-01
    z[8,7,6]  R2866     -3.4600594639778137e-01
    z[8,7,6]  R2867     1.0638792812824249e-01
    z[8,7,6]  R2868     5.7504154741764069e-02
    z[8,7,6]  R2869     7.3766849935054779e-02
    z[8,7,6]  R2870     3.7288421392440796e-01
    z[8,7,6]  R2871     -3.0995625257492065e-01
    z[8,7,6]  R2872     -2.8730648756027222e-01
    z[8,7,6]  R2873     -3.0975034832954407e-01
    z[8,7,6]  R2874     2.0896416902542114e-01
    z[8,7,6]  R2875     1.2505804002285004e-01
    z[8,7,6]  R2876     -5.4767656326293945e-01
    z[8,7,6]  R2877     -5.5913275480270386e-01
    z[8,7,6]  R2878     -2.9187005758285522e-01
    z[8,7,6]  R2879     5.7579171657562256e-01
    z[8,7,6]  R2880     -4.8718109726905823e-01
    z[8,7,6]  R2881     -5.5757766962051392e-01
    z[8,7,6]  R2882     1.5979956090450287e-01
    z[8,7,6]  R2883     1.1773577332496643e-01
    z[8,7,6]  R2884     -1.1788261681795120e-01
    z[8,7,6]  R2885     3.7980252504348755e-01
    z[8,7,6]  R2886     -1.0959913581609726e-01
    z[8,7,6]  R2887     -1.5310059487819672e-01
    z[8,7,6]  R2888     -7.4085518717765808e-02
    z[8,7,6]  R2889     -1.8072827160358429e-01
    z[8,7,6]  R2890     -4.6383801102638245e-01
    z[8,7,6]  R2891     1.4695416390895844e-01
    z[8,7,6]  R2892     2.5241279974579811e-02
    z[8,7,6]  R2893     -2.5018927454948425e-01
    z[8,7,6]  R2894     -3.3541226387023926e-01
    z[8,7,6]  R2895     3.1361293792724609e-01
    z[8,7,6]  R2896     2.8857663273811340e-01
    z[8,7,6]  R2897     -2.0775970816612244e-01
    z[8,7,6]  R2898     4.2690834403038025e-01
    z[8,7,6]  R2899     -2.1375331282615662e-01
    z[8,7,6]  R2900     1.6016711294651031e-01
    z[8,7,6]  R2901     8.2306535914540291e-03
    z[8,7,6]  R2902     1.4425319433212280e-01
    z[8,7,6]  R2903     5.8335000276565552e-01
    z[8,7,6]  R2904     -2.3129422962665558e-01
    z[8,7,6]  R2905     1.6793212294578552e-01
    z[8,7,6]  R2906     -3.8830515742301941e-01
    z[8,7,6]  R2907     -3.7465396523475647e-01
    z[8,7,6]  R2908     5.2417159080505371e-02
    z[8,7,6]  R2909     -0.200520858168602
    z[8,7,6]  R2910     2.5251591205596924e-01
    z[8,7,6]  R2911     -0.011157201603055
    z[8,7,6]  R2912     4.9335334450006485e-02
    z[8,7,6]  R2913     -4.9009706825017929e-02
    z[8,7,6]  R2914     1.0897734016180038e-01
    z[8,7,6]  R2915     -2.9252591729164124e-01
    z[8,7,6]  R2916     9.0420506894588470e-02
    z[8,7,6]  R2917     -2.0941365510225296e-02
    z[8,7,6]  R2918     -4.7655689716339111e-01
    z[8,7,6]  R2919     -3.7927865982055664e-01
    z[8,7,6]  R2920     0.0328315831720829
    z[8,7,6]  R2921     -1.6944380104541779e-01
    z[8,7,6]  R2922     -7.0934578776359558e-02
    z[8,7,6]  R2923     1.1940453946590424e-01
    z[8,7,6]  R2924     4.5191212557256222e-03
    z[8,7,6]  R2925     7.9175412654876709e-02
    z[8,7,6]  R2926     8.9159548282623291e-02
    z[8,7,6]  R2927     6.0453094542026520e-02
    z[8,7,6]  R2928     -2.6525512337684631e-01
    z[8,7,6]  R2929     -3.7803087383508682e-02
    z[8,7,6]  R2930     -2.7614429593086243e-01
    z[8,7,6]  R2931     8.7367840111255646e-02
    z[8,7,6]  R2932     -2.1105292439460754e-01
    z[8,7,6]  R2933     6.7723888158798218e-01
    z[8,7,6]  R2934     3.8104796409606934e-01
    z[8,7,6]  R2935     5.6091502308845520e-02
    z[8,7,6]  R2936     -1.9220207631587982e-01
    z[8,7,6]  R2937     -4.3303820490837097e-01
    z[8,7,6]  R2938     2.5996601581573486e-01
    z[8,7,6]  R2939     -2.8459662571549416e-02
    z[8,7,6]  R2940     -3.0651116743683815e-02
    z[8,7,6]  R2941     1.5808257460594177e-01
    z[8,7,6]  R2942     -6.1019110679626465e-01
    z[8,7,6]  R2943     -0.0468759723007679
    z[8,7,6]  R2944     -1.3311263173818588e-02
    z[8,7,6]  R2945     -2.4402081966400146e-01
    z[8,7,6]  R2946     -2.1688601374626160e-01
    z[8,7,6]  R2947     -4.9238704144954681e-02
    z[8,7,6]  R2948     -4.8392537236213684e-01
    length[0]  OBJ       1
    length[1]  OBJ       1
    length[2]  OBJ       1
    length[3]  OBJ       1
    length[4]  OBJ       1
    length[5]  OBJ       1
    length[6]  OBJ       1
    length[7]  OBJ       1
    length[8]  OBJ       1
    delta[0,0]  R2        1
    delta[0,1]  R3        1
    delta[0,2]  R4        1
    delta[0,3]  R5        1
    delta[0,4]  R6        1
    delta[0,5]  R7        1
    delta[0,6]  R8        1
    delta[1,0]  R11       1
    delta[1,1]  R12       1
    delta[1,2]  R13       1
    delta[1,3]  R14       1
    delta[1,4]  R15       1
    delta[1,5]  R16       1
    delta[1,6]  R17       1
    delta[2,0]  R20       1
    delta[2,1]  R21       1
    delta[2,2]  R22       1
    delta[2,3]  R23       1
    delta[2,4]  R24       1
    delta[2,5]  R25       1
    delta[2,6]  R26       1
    delta[3,0]  R29       1
    delta[3,1]  R30       1
    delta[3,2]  R31       1
    delta[3,3]  R32       1
    delta[3,4]  R33       1
    delta[3,5]  R34       1
    delta[3,6]  R35       1
    delta[4,0]  R38       1
    delta[4,1]  R39       1
    delta[4,2]  R40       1
    delta[4,3]  R41       1
    delta[4,4]  R42       1
    delta[4,5]  R43       1
    delta[4,6]  R44       1
    delta[5,0]  R47       1
    delta[5,1]  R48       1
    delta[5,2]  R49       1
    delta[5,3]  R50       1
    delta[5,4]  R51       1
    delta[5,5]  R52       1
    delta[5,6]  R53       1
    delta[6,0]  R56       1
    delta[6,1]  R57       1
    delta[6,2]  R58       1
    delta[6,3]  R59       1
    delta[6,4]  R60       1
    delta[6,5]  R61       1
    delta[6,6]  R62       1
    delta[7,0]  R65       1
    delta[7,1]  R66       1
    delta[7,2]  R67       1
    delta[7,3]  R68       1
    delta[7,4]  R69       1
    delta[7,5]  R70       1
    delta[7,6]  R71       1
    delta[8,0]  R74       1
    delta[8,1]  R75       1
    delta[8,2]  R76       1
    delta[8,3]  R77       1
    delta[8,4]  R78       1
    delta[8,5]  R79       1
    delta[8,6]  R80       1
RHS
    RHS1      R1        1
    RHS1      R10       1
    RHS1      R19       1
    RHS1      R28       1
    RHS1      R37       1
    RHS1      R46       1
    RHS1      R55       1
    RHS1      R64       1
    RHS1      R73       1
    RHS1      R81       1
    RHS1      R82       -1
BOUNDS
 BV BND1      phi[0,1]
 BV BND1      phi[1,0]
 BV BND1      phi[0,6]
 BV BND1      phi[6,0]
 BV BND1      phi[9,0]
 BV BND1      phi[1,2]
 BV BND1      phi[2,1]
 BV BND1      phi[2,3]
 BV BND1      phi[3,2]
 BV BND1      phi[2,8]
 BV BND1      phi[8,2]
 BV BND1      phi[3,4]
 BV BND1      phi[4,3]
 BV BND1      phi[3,8]
 BV BND1      phi[8,3]
 BV BND1      phi[4,5]
 BV BND1      phi[5,4]
 BV BND1      phi[5,10]
 BV BND1      phi[6,7]
 BV BND1      phi[7,6]
 BV BND1      phi[9,6]
 BV BND1      phi[7,8]
 BV BND1      phi[8,7]
 FR BND1      z[0,1,0]
 FR BND1      z[0,1,1]
 FR BND1      z[0,1,2]
 FR BND1      z[0,1,3]
 FR BND1      z[0,1,4]
 FR BND1      z[0,1,5]
 FR BND1      z[0,1,6]
 FR BND1      z[1,0,0]
 FR BND1      z[1,0,1]
 FR BND1      z[1,0,2]
 FR BND1      z[1,0,3]
 FR BND1      z[1,0,4]
 FR BND1      z[1,0,5]
 FR BND1      z[1,0,6]
 FR BND1      z[0,6,0]
 FR BND1      z[0,6,1]
 FR BND1      z[0,6,2]
 FR BND1      z[0,6,3]
 FR BND1      z[0,6,4]
 FR BND1      z[0,6,5]
 FR BND1      z[0,6,6]
 FR BND1      z[6,0,0]
 FR BND1      z[6,0,1]
 FR BND1      z[6,0,2]
 FR BND1      z[6,0,3]
 FR BND1      z[6,0,4]
 FR BND1      z[6,0,5]
 FR BND1      z[6,0,6]
 FR BND1      z[1,2,0]
 FR BND1      z[1,2,1]
 FR BND1      z[1,2,2]
 FR BND1      z[1,2,3]
 FR BND1      z[1,2,4]
 FR BND1      z[1,2,5]
 FR BND1      z[1,2,6]
 FR BND1      z[2,1,0]
 FR BND1      z[2,1,1]
 FR BND1      z[2,1,2]
 FR BND1      z[2,1,3]
 FR BND1      z[2,1,4]
 FR BND1      z[2,1,5]
 FR BND1      z[2,1,6]
 FR BND1      z[2,3,0]
 FR BND1      z[2,3,1]
 FR BND1      z[2,3,2]
 FR BND1      z[2,3,3]
 FR BND1      z[2,3,4]
 FR BND1      z[2,3,5]
 FR BND1      z[2,3,6]
 FR BND1      z[3,2,0]
 FR BND1      z[3,2,1]
 FR BND1      z[3,2,2]
 FR BND1      z[3,2,3]
 FR BND1      z[3,2,4]
 FR BND1      z[3,2,5]
 FR BND1      z[3,2,6]
 FR BND1      z[2,8,0]
 FR BND1      z[2,8,1]
 FR BND1      z[2,8,2]
 FR BND1      z[2,8,3]
 FR BND1      z[2,8,4]
 FR BND1      z[2,8,5]
 FR BND1      z[2,8,6]
 FR BND1      z[8,2,0]
 FR BND1      z[8,2,1]
 FR BND1      z[8,2,2]
 FR BND1      z[8,2,3]
 FR BND1      z[8,2,4]
 FR BND1      z[8,2,5]
 FR BND1      z[8,2,6]
 FR BND1      z[3,4,0]
 FR BND1      z[3,4,1]
 FR BND1      z[3,4,2]
 FR BND1      z[3,4,3]
 FR BND1      z[3,4,4]
 FR BND1      z[3,4,5]
 FR BND1      z[3,4,6]
 FR BND1      z[4,3,0]
 FR BND1      z[4,3,1]
 FR BND1      z[4,3,2]
 FR BND1      z[4,3,3]
 FR BND1      z[4,3,4]
 FR BND1      z[4,3,5]
 FR BND1      z[4,3,6]
 FR BND1      z[3,8,0]
 FR BND1      z[3,8,1]
 FR BND1      z[3,8,2]
 FR BND1      z[3,8,3]
 FR BND1      z[3,8,4]
 FR BND1      z[3,8,5]
 FR BND1      z[3,8,6]
 FR BND1      z[8,3,0]
 FR BND1      z[8,3,1]
 FR BND1      z[8,3,2]
 FR BND1      z[8,3,3]
 FR BND1      z[8,3,4]
 FR BND1      z[8,3,5]
 FR BND1      z[8,3,6]
 FR BND1      z[4,5,0]
 FR BND1      z[4,5,1]
 FR BND1      z[4,5,2]
 FR BND1      z[4,5,3]
 FR BND1      z[4,5,4]
 FR BND1      z[4,5,5]
 FR BND1      z[4,5,6]
 FR BND1      z[5,4,0]
 FR BND1      z[5,4,1]
 FR BND1      z[5,4,2]
 FR BND1      z[5,4,3]
 FR BND1      z[5,4,4]
 FR BND1      z[5,4,5]
 FR BND1      z[5,4,6]
 FR BND1      z[6,7,0]
 FR BND1      z[6,7,1]
 FR BND1      z[6,7,2]
 FR BND1      z[6,7,3]
 FR BND1      z[6,7,4]
 FR BND1      z[6,7,5]
 FR BND1      z[6,7,6]
 FR BND1      z[7,6,0]
 FR BND1      z[7,6,1]
 FR BND1      z[7,6,2]
 FR BND1      z[7,6,3]
 FR BND1      z[7,6,4]
 FR BND1      z[7,6,5]
 FR BND1      z[7,6,6]
 FR BND1      z[7,8,0]
 FR BND1      z[7,8,1]
 FR BND1      z[7,8,2]
 FR BND1      z[7,8,3]
 FR BND1      z[7,8,4]
 FR BND1      z[7,8,5]
 FR BND1      z[7,8,6]
 FR BND1      z[8,7,0]
 FR BND1      z[8,7,1]
 FR BND1      z[8,7,2]
 FR BND1      z[8,7,3]
 FR BND1      z[8,7,4]
 FR BND1      z[8,7,5]
 FR BND1      z[8,7,6]
 FR BND1      delta[0,0]
 FR BND1      delta[0,1]
 FR BND1      delta[0,2]
 FR BND1      delta[0,3]
 FR BND1      delta[0,4]
 FR BND1      delta[0,5]
 FR BND1      delta[0,6]
 FR BND1      delta[1,0]
 FR BND1      delta[1,1]
 FR BND1      delta[1,2]
 FR BND1      delta[1,3]
 FR BND1      delta[1,4]
 FR BND1      delta[1,5]
 FR BND1      delta[1,6]
 FR BND1      delta[2,0]
 FR BND1      delta[2,1]
 FR BND1      delta[2,2]
 FR BND1      delta[2,3]
 FR BND1      delta[2,4]
 FR BND1      delta[2,5]
 FR BND1      delta[2,6]
 FR BND1      delta[3,0]
 FR BND1      delta[3,1]
 FR BND1      delta[3,2]
 FR BND1      delta[3,3]
 FR BND1      delta[3,4]
 FR BND1      delta[3,5]
 FR BND1      delta[3,6]
 FR BND1      delta[4,0]
 FR BND1      delta[4,1]
 FR BND1      delta[4,2]
 FR BND1      delta[4,3]
 FR BND1      delta[4,4]
 FR BND1      delta[4,5]
 FR BND1      delta[4,6]
 FR BND1      delta[5,0]
 FR BND1      delta[5,1]
 FR BND1      delta[5,2]
 FR BND1      delta[5,3]
 FR BND1      delta[5,4]
 FR BND1      delta[5,5]
 FR BND1      delta[5,6]
 FR BND1      delta[6,0]
 FR BND1      delta[6,1]
 FR BND1      delta[6,2]
 FR BND1      delta[6,3]
 FR BND1      delta[6,4]
 FR BND1      delta[6,5]
 FR BND1      delta[6,6]
 FR BND1      delta[7,0]
 FR BND1      delta[7,1]
 FR BND1      delta[7,2]
 FR BND1      delta[7,3]
 FR BND1      delta[7,4]
 FR BND1      delta[7,5]
 FR BND1      delta[7,6]
 FR BND1      delta[8,0]
 FR BND1      delta[8,1]
 FR BND1      delta[8,2]
 FR BND1      delta[8,3]
 FR BND1      delta[8,4]
 FR BND1      delta[8,5]
 FR BND1      delta[8,6]
QCMATRIX   qc0     
    length[0]  length[0]  -1
    delta[0,0]  delta[0,0]  1
    delta[0,1]  delta[0,1]  1
    delta[0,2]  delta[0,2]  1
    delta[0,3]  delta[0,3]  1
    delta[0,4]  delta[0,4]  1
    delta[0,5]  delta[0,5]  1
    delta[0,6]  delta[0,6]  1
QCMATRIX   qc1     
    length[1]  length[1]  -1
    delta[1,0]  delta[1,0]  1
    delta[1,1]  delta[1,1]  1
    delta[1,2]  delta[1,2]  1
    delta[1,3]  delta[1,3]  1
    delta[1,4]  delta[1,4]  1
    delta[1,5]  delta[1,5]  1
    delta[1,6]  delta[1,6]  1
QCMATRIX   qc2     
    length[2]  length[2]  -1
    delta[2,0]  delta[2,0]  1
    delta[2,1]  delta[2,1]  1
    delta[2,2]  delta[2,2]  1
    delta[2,3]  delta[2,3]  1
    delta[2,4]  delta[2,4]  1
    delta[2,5]  delta[2,5]  1
    delta[2,6]  delta[2,6]  1
QCMATRIX   qc3     
    length[3]  length[3]  -1
    delta[3,0]  delta[3,0]  1
    delta[3,1]  delta[3,1]  1
    delta[3,2]  delta[3,2]  1
    delta[3,3]  delta[3,3]  1
    delta[3,4]  delta[3,4]  1
    delta[3,5]  delta[3,5]  1
    delta[3,6]  delta[3,6]  1
QCMATRIX   qc4     
    length[4]  length[4]  -1
    delta[4,0]  delta[4,0]  1
    delta[4,1]  delta[4,1]  1
    delta[4,2]  delta[4,2]  1
    delta[4,3]  delta[4,3]  1
    delta[4,4]  delta[4,4]  1
    delta[4,5]  delta[4,5]  1
    delta[4,6]  delta[4,6]  1
QCMATRIX   qc5     
    length[5]  length[5]  -1
    delta[5,0]  delta[5,0]  1
    delta[5,1]  delta[5,1]  1
    delta[5,2]  delta[5,2]  1
    delta[5,3]  delta[5,3]  1
    delta[5,4]  delta[5,4]  1
    delta[5,5]  delta[5,5]  1
    delta[5,6]  delta[5,6]  1
QCMATRIX   qc6     
    length[6]  length[6]  -1
    delta[6,0]  delta[6,0]  1
    delta[6,1]  delta[6,1]  1
    delta[6,2]  delta[6,2]  1
    delta[6,3]  delta[6,3]  1
    delta[6,4]  delta[6,4]  1
    delta[6,5]  delta[6,5]  1
    delta[6,6]  delta[6,6]  1
QCMATRIX   qc7     
    length[7]  length[7]  -1
    delta[7,0]  delta[7,0]  1
    delta[7,1]  delta[7,1]  1
    delta[7,2]  delta[7,2]  1
    delta[7,3]  delta[7,3]  1
    delta[7,4]  delta[7,4]  1
    delta[7,5]  delta[7,5]  1
    delta[7,6]  delta[7,6]  1
QCMATRIX   qc8     
    length[8]  length[8]  -1
    delta[8,0]  delta[8,0]  1
    delta[8,1]  delta[8,1]  1
    delta[8,2]  delta[8,2]  1
    delta[8,3]  delta[8,3]  1
    delta[8,4]  delta[8,4]  1
    delta[8,5]  delta[8,5]  1
    delta[8,6]  delta[8,6]  1
ENDATA
