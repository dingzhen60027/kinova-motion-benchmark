NAME LGCS_GCS_Eq5_5_projected
ROWS
 N  OBJ
 E  R0      
 L  R1      
 E  R2      
 E  R3      
 E  R4      
 E  R5      
 E  R6      
 E  R7      
 E  R8      
 E  R9      
 L  R10     
 E  R11     
 E  R12     
 E  R13     
 E  R14     
 E  R15     
 E  R16     
 E  R17     
 E  R18     
 L  R19     
 E  R20     
 E  R21     
 E  R22     
 E  R23     
 E  R24     
 E  R25     
 E  R26     
 E  R27     
 L  R28     
 E  R29     
 E  R30     
 E  R31     
 E  R32     
 E  R33     
 E  R34     
 E  R35     
 E  R36     
 L  R37     
 E  R38     
 E  R39     
 E  R40     
 E  R41     
 E  R42     
 E  R43     
 E  R44     
 E  R45     
 L  R46     
 E  R47     
 E  R48     
 E  R49     
 E  R50     
 E  R51     
 E  R52     
 E  R53     
 E  R54     
 L  R55     
 E  R56     
 E  R57     
 E  R58     
 E  R59     
 E  R60     
 E  R61     
 E  R62     
 E  R63     
 L  R64     
 E  R65     
 E  R66     
 E  R67     
 E  R68     
 E  R69     
 E  R70     
 E  R71     
 E  R72     
 L  R73     
 E  R74     
 E  R75     
 E  R76     
 E  R77     
 E  R78     
 E  R79     
 E  R80     
 E  R81     
 L  R82     
 E  R83     
 E  R84     
 E  R85     
 E  R86     
 E  R87     
 E  R88     
 E  R89     
 E  R90     
 L  R91     
 E  R92     
 E  R93     
 E  R94     
 E  R95     
 E  R96     
 E  R97     
 E  R98     
 E  R99     
 E  R100    
 L  R101    
 L  R102    
 L  R103    
 L  R104    
 L  R105    
 L  R106    
 L  R107    
 L  R108    
 L  R109    
 L  R110    
 L  R111    
 L  R112    
 L  R113    
 L  R114    
 L  R115    
 L  R116    
 L  R117    
 L  R118    
 L  R119    
 L  R120    
 L  R121    
 L  R122    
 L  R123    
 L  R124    
 L  R125    
 L  R126    
 L  R127    
 L  R128    
 L  R129    
 L  R130    
 L  R131    
 L  R132    
 L  R133    
 L  R134    
 L  R135    
 L  R136    
 L  R137    
 L  R138    
 L  R139    
 L  R140    
 L  R141    
 L  R142    
 L  R143    
 L  R144    
 L  R145    
 L  R146    
 L  R147    
 L  R148    
 L  R149    
 L  R150    
 L  R151    
 L  R152    
 L  R153    
 L  R154    
 L  R155    
 L  R156    
 L  R157    
 L  R158    
 L  R159    
 L  R160    
 L  R161    
 L  R162    
 L  R163    
 L  R164    
 L  R165    
 L  R166    
 L  R167    
 L  R168    
 L  R169    
 L  R170    
 L  R171    
 L  R172    
 L  R173    
 L  R174    
 L  R175    
 L  R176    
 L  R177    
 L  R178    
 L  R179    
 L  R180    
 L  R181    
 L  R182    
 L  R183    
 L  R184    
 L  R185    
 L  R186    
 L  R187    
 L  R188    
 L  R189    
 L  R190    
 L  R191    
 L  R192    
 L  R193    
 L  R194    
 L  R195    
 L  R196    
 L  R197    
 L  R198    
 L  R199    
 L  R200    
 L  R201    
 L  R202    
 L  R203    
 L  R204    
 L  R205    
 L  R206    
 L  R207    
 L  R208    
 L  R209    
 L  R210    
 L  R211    
 L  R212    
 L  R213    
 L  R214    
 L  R215    
 L  R216    
 L  R217    
 L  R218    
 L  R219    
 L  R220    
 L  R221    
 L  R222    
 L  R223    
 L  R224    
 L  R225    
 L  R226    
 L  R227    
 L  R228    
 L  R229    
 L  R230    
 L  R231    
 L  R232    
 L  R233    
 L  R234    
 L  R235    
 L  R236    
 L  R237    
 L  R238    
 L  R239    
 L  R240    
 L  R241    
 L  R242    
 L  R243    
 L  R244    
 L  R245    
 L  R246    
 L  R247    
 L  R248    
 L  R249    
 L  R250    
 L  R251    
 L  R252    
 L  R253    
 L  R254    
 L  R255    
 L  R256    
 L  R257    
 L  R258    
 L  R259    
 L  R260    
 L  R261    
 L  R262    
 L  R263    
 L  R264    
 L  R265    
 L  R266    
 L  R267    
 L  R268    
 L  R269    
 L  R270    
 L  R271    
 L  R272    
 L  R273    
 L  R274    
 L  R275    
 L  R276    
 L  R277    
 L  R278    
 L  R279    
 L  R280    
 L  R281    
 L  R282    
 L  R283    
 L  R284    
 L  R285    
 L  R286    
 L  R287    
 L  R288    
 L  R289    
 L  R290    
 L  R291    
 L  R292    
 L  R293    
 L  R294    
 L  R295    
 L  R296    
 L  R297    
 L  R298    
 L  R299    
 L  R300    
 L  R301    
 L  R302    
 L  R303    
 L  R304    
 L  R305    
 L  R306    
 L  R307    
 L  R308    
 L  R309    
 L  R310    
 L  R311    
 L  R312    
 L  R313    
 L  R314    
 L  R315    
 L  R316    
 L  R317    
 L  R318    
 L  R319    
 L  R320    
 L  R321    
 L  R322    
 L  R323    
 L  R324    
 L  R325    
 L  R326    
 L  R327    
 L  R328    
 L  R329    
 L  R330    
 L  R331    
 L  R332    
 L  R333    
 L  R334    
 L  R335    
 L  R336    
 L  R337    
 L  R338    
 L  R339    
 L  R340    
 L  R341    
 L  R342    
 L  R343    
 L  R344    
 L  R345    
 L  R346    
 L  R347    
 L  R348    
 L  R349    
 L  R350    
 L  R351    
 L  R352    
 L  R353    
 L  R354    
 L  R355    
 L  R356    
 L  R357    
 L  R358    
 L  R359    
 L  R360    
 L  R361    
 L  R362    
 L  R363    
 L  R364    
 L  R365    
 L  R366    
 L  R367    
 L  R368    
 L  R369    
 L  R370    
 L  R371    
 L  R372    
 L  R373    
 L  R374    
 L  R375    
 L  R376    
 L  R377    
 L  R378    
 L  R379    
 L  R380    
 L  R381    
 L  R382    
 L  R383    
 L  R384    
 L  R385    
 L  R386    
 L  R387    
 L  R388    
 L  R389    
 L  R390    
 L  R391    
 L  R392    
 L  R393    
 L  R394    
 L  R395    
 L  R396    
 L  R397    
 L  R398    
 L  R399    
 L  R400    
 L  R401    
 L  R402    
 L  R403    
 L  R404    
 L  R405    
 L  R406    
 L  R407    
 L  R408    
 L  R409    
 L  R410    
 L  R411    
 L  R412    
 L  R413    
 L  R414    
 L  R415    
 L  R416    
 L  R417    
 L  R418    
 L  R419    
 L  R420    
 L  R421    
 L  R422    
 L  R423    
 L  R424    
 L  R425    
 L  R426    
 L  R427    
 L  R428    
 L  R429    
 L  R430    
 L  R431    
 L  R432    
 L  R433    
 L  R434    
 L  R435    
 L  R436    
 L  R437    
 L  R438    
 L  R439    
 L  R440    
 L  R441    
 L  R442    
 L  R443    
 L  R444    
 L  R445    
 L  R446    
 L  R447    
 L  R448    
 L  R449    
 L  R450    
 L  R451    
 L  R452    
 L  R453    
 L  R454    
 L  R455    
 L  R456    
 L  R457    
 L  R458    
 L  R459    
 L  R460    
 L  R461    
 L  R462    
 L  R463    
 L  R464    
 L  R465    
 L  R466    
 L  R467    
 L  R468    
 L  R469    
 L  R470    
 L  R471    
 L  R472    
 L  R473    
 L  R474    
 L  R475    
 L  R476    
 L  R477    
 L  R478    
 L  R479    
 L  R480    
 L  R481    
 L  R482    
 L  R483    
 L  R484    
 L  R485    
 L  R486    
 L  R487    
 L  R488    
 L  R489    
 L  R490    
 L  R491    
 L  R492    
 L  R493    
 L  R494    
 L  R495    
 L  R496    
 L  R497    
 L  R498    
 L  R499    
 L  R500    
 L  R501    
 L  R502    
 L  R503    
 L  R504    
 L  R505    
 L  R506    
 L  R507    
 L  R508    
 L  R509    
 L  R510    
 L  R511    
 L  R512    
 L  R513    
 L  R514    
 L  R515    
 L  R516    
 L  R517    
 L  R518    
 L  R519    
 L  R520    
 L  R521    
 L  R522    
 L  R523    
 L  R524    
 L  R525    
 L  R526    
 L  R527    
 L  R528    
 L  R529    
 L  R530    
 L  R531    
 L  R532    
 L  R533    
 L  R534    
 L  R535    
 L  R536    
 L  R537    
 L  R538    
 L  R539    
 L  R540    
 L  R541    
 L  R542    
 L  R543    
 L  R544    
 L  R545    
 L  R546    
 L  R547    
 L  R548    
 L  R549    
 L  R550    
 L  R551    
 L  R552    
 L  R553    
 L  R554    
 L  R555    
 L  R556    
 L  R557    
 L  R558    
 L  R559    
 L  R560    
 L  R561    
 L  R562    
 L  R563    
 L  R564    
 L  R565    
 L  R566    
 L  R567    
 L  R568    
 L  R569    
 L  R570    
 L  R571    
 L  R572    
 L  R573    
 L  R574    
 L  R575    
 L  R576    
 L  R577    
 L  R578    
 L  R579    
 L  R580    
 L  R581    
 L  R582    
 L  R583    
 L  R584    
 L  R585    
 L  R586    
 L  R587    
 L  R588    
 L  R589    
 L  R590    
 L  R591    
 L  R592    
 L  R593    
 L  R594    
 L  R595    
 L  R596    
 L  R597    
 L  R598    
 L  R599    
 L  R600    
 L  R601    
 L  R602    
 L  R603    
 L  R604    
 L  R605    
 L  R606    
 L  R607    
 L  R608    
 L  R609    
 L  R610    
 L  R611    
 L  R612    
 L  R613    
 L  R614    
 L  R615    
 L  R616    
 L  R617    
 L  R618    
 L  R619    
 L  R620    
 L  R621    
 L  R622    
 L  R623    
 L  R624    
 L  R625    
 L  R626    
 L  R627    
 L  R628    
 L  R629    
 L  R630    
 L  R631    
 L  R632    
 L  R633    
 L  R634    
 L  R635    
 L  R636    
 L  R637    
 L  R638    
 L  R639    
 L  R640    
 L  R641    
 L  R642    
 L  R643    
 L  R644    
 L  R645    
 L  R646    
 L  R647    
 L  R648    
 L  R649    
 L  R650    
 L  R651    
 L  R652    
 L  R653    
 L  R654    
 L  R655    
 L  R656    
 L  R657    
 L  R658    
 L  R659    
 L  R660    
 L  R661    
 L  R662    
 L  R663    
 L  R664    
 L  R665    
 L  R666    
 L  R667    
 L  R668    
 L  R669    
 L  R670    
 L  R671    
 L  R672    
 L  R673    
 L  R674    
 L  R675    
 L  R676    
 L  R677    
 L  R678    
 L  R679    
 L  R680    
 L  R681    
 L  R682    
 L  R683    
 L  R684    
 L  R685    
 L  R686    
 L  R687    
 L  R688    
 L  R689    
 L  R690    
 L  R691    
 L  R692    
 L  R693    
 L  R694    
 L  R695    
 L  R696    
 L  R697    
 L  R698    
 L  R699    
 L  R700    
 L  R701    
 L  R702    
 L  R703    
 L  R704    
 L  R705    
 L  R706    
 L  R707    
 L  R708    
 L  R709    
 L  R710    
 L  R711    
 L  R712    
 L  R713    
 L  R714    
 L  R715    
 L  R716    
 L  R717    
 L  R718    
 L  R719    
 L  R720    
 L  R721    
 L  R722    
 L  R723    
 L  R724    
 L  R725    
 L  R726    
 L  R727    
 L  R728    
 L  R729    
 L  R730    
 L  R731    
 L  R732    
 L  R733    
 L  R734    
 L  R735    
 L  R736    
 L  R737    
 L  R738    
 L  R739    
 L  R740    
 L  R741    
 L  R742    
 L  R743    
 L  R744    
 L  R745    
 L  R746    
 L  R747    
 L  R748    
 L  R749    
 L  R750    
 L  R751    
 L  R752    
 L  R753    
 L  R754    
 L  R755    
 L  R756    
 L  R757    
 L  R758    
 L  R759    
 L  R760    
 L  R761    
 L  R762    
 L  R763    
 L  R764    
 L  R765    
 L  R766    
 L  R767    
 L  R768    
 L  R769    
 L  R770    
 L  R771    
 L  R772    
 L  R773    
 L  R774    
 L  R775    
 L  R776    
 L  R777    
 L  R778    
 L  R779    
 L  R780    
 L  R781    
 L  R782    
 L  R783    
 L  R784    
 L  R785    
 L  R786    
 L  R787    
 L  R788    
 L  R789    
 L  R790    
 L  R791    
 L  R792    
 L  R793    
 L  R794    
 L  R795    
 L  R796    
 L  R797    
 L  R798    
 L  R799    
 L  R800    
 L  R801    
 L  R802    
 L  R803    
 L  R804    
 L  R805    
 L  R806    
 L  R807    
 L  R808    
 L  R809    
 L  R810    
 L  R811    
 L  R812    
 L  R813    
 L  R814    
 L  R815    
 L  R816    
 L  R817    
 L  R818    
 L  R819    
 L  R820    
 L  R821    
 L  R822    
 L  R823    
 L  R824    
 L  R825    
 L  R826    
 L  R827    
 L  R828    
 L  R829    
 L  R830    
 L  R831    
 L  R832    
 L  R833    
 L  R834    
 L  R835    
 L  R836    
 L  R837    
 L  R838    
 L  R839    
 L  R840    
 L  R841    
 L  R842    
 L  R843    
 L  R844    
 L  R845    
 L  R846    
 L  R847    
 L  R848    
 L  R849    
 L  R850    
 L  R851    
 L  R852    
 L  R853    
 L  R854    
 L  R855    
 L  R856    
 L  R857    
 L  R858    
 L  R859    
 L  R860    
 L  R861    
 L  R862    
 L  R863    
 L  R864    
 L  R865    
 L  R866    
 L  R867    
 L  R868    
 L  R869    
 L  R870    
 L  R871    
 L  R872    
 L  R873    
 L  R874    
 L  R875    
 L  R876    
 L  R877    
 L  R878    
 L  R879    
 L  R880    
 L  R881    
 L  R882    
 L  R883    
 L  R884    
 L  R885    
 L  R886    
 L  R887    
 L  R888    
 L  R889    
 L  R890    
 L  R891    
 L  R892    
 L  R893    
 L  R894    
 L  R895    
 L  R896    
 L  R897    
 L  R898    
 L  R899    
 L  R900    
 L  R901    
 L  R902    
 L  R903    
 L  R904    
 L  R905    
 L  R906    
 L  R907    
 L  R908    
 L  R909    
 L  R910    
 L  R911    
 L  R912    
 L  R913    
 L  R914    
 L  R915    
 L  R916    
 L  R917    
 L  R918    
 L  R919    
 L  R920    
 L  R921    
 L  R922    
 L  R923    
 L  R924    
 L  R925    
 L  R926    
 L  R927    
 L  R928    
 L  R929    
 L  R930    
 L  R931    
 L  R932    
 L  R933    
 L  R934    
 L  R935    
 L  R936    
 L  R937    
 L  R938    
 L  R939    
 L  R940    
 L  R941    
 L  R942    
 L  R943    
 L  R944    
 L  R945    
 L  R946    
 L  R947    
 L  R948    
 L  R949    
 L  R950    
 L  R951    
 L  R952    
 L  R953    
 L  R954    
 L  R955    
 L  R956    
 L  R957    
 L  R958    
 L  R959    
 L  R960    
 L  R961    
 L  R962    
 L  R963    
 L  R964    
 L  R965    
 L  R966    
 L  R967    
 L  R968    
 L  R969    
 L  R970    
 L  R971    
 L  R972    
 L  R973    
 L  R974    
 L  R975    
 L  R976    
 L  R977    
 L  R978    
 L  R979    
 L  R980    
 L  R981    
 L  R982    
 L  R983    
 L  R984    
 L  R985    
 L  R986    
 L  R987    
 L  R988    
 L  R989    
 L  R990    
 L  R991    
 L  R992    
 L  R993    
 L  R994    
 L  R995    
 L  R996    
 L  R997    
 L  R998    
 L  R999    
 L  R1000   
 L  R1001   
 L  R1002   
 L  R1003   
 L  R1004   
 L  R1005   
 L  R1006   
 L  R1007   
 L  R1008   
 L  R1009   
 L  R1010   
 L  R1011   
 L  R1012   
 L  R1013   
 L  R1014   
 L  R1015   
 L  R1016   
 L  R1017   
 L  R1018   
 L  R1019   
 L  R1020   
 L  R1021   
 L  R1022   
 L  R1023   
 L  R1024   
 L  R1025   
 L  R1026   
 L  R1027   
 L  R1028   
 L  R1029   
 L  R1030   
 L  R1031   
 L  R1032   
 L  R1033   
 L  R1034   
 L  R1035   
 L  R1036   
 L  R1037   
 L  R1038   
 L  R1039   
 L  R1040   
 L  R1041   
 L  R1042   
 L  R1043   
 L  R1044   
 L  R1045   
 L  R1046   
 L  R1047   
 L  R1048   
 L  R1049   
 L  R1050   
 L  R1051   
 L  R1052   
 L  R1053   
 L  R1054   
 L  R1055   
 L  R1056   
 L  R1057   
 L  R1058   
 L  R1059   
 L  R1060   
 L  R1061   
 L  R1062   
 L  R1063   
 L  R1064   
 L  R1065   
 L  R1066   
 L  R1067   
 L  R1068   
 L  R1069   
 L  R1070   
 L  R1071   
 L  R1072   
 L  R1073   
 L  R1074   
 L  R1075   
 L  R1076   
 L  R1077   
 L  R1078   
 L  R1079   
 L  R1080   
 L  R1081   
 L  R1082   
 L  R1083   
 L  R1084   
 L  R1085   
 L  R1086   
 L  R1087   
 L  R1088   
 L  R1089   
 L  R1090   
 L  R1091   
 L  R1092   
 L  R1093   
 L  R1094   
 L  R1095   
 L  R1096   
 L  R1097   
 L  R1098   
 L  R1099   
 L  R1100   
 L  R1101   
 L  R1102   
 L  R1103   
 L  R1104   
 L  R1105   
 L  R1106   
 L  R1107   
 L  R1108   
 L  R1109   
 L  R1110   
 L  R1111   
 L  R1112   
 L  R1113   
 L  R1114   
 L  R1115   
 L  R1116   
 L  R1117   
 L  R1118   
 L  R1119   
 L  R1120   
 L  R1121   
 L  R1122   
 L  R1123   
 L  R1124   
 L  R1125   
 L  R1126   
 L  R1127   
 L  R1128   
 L  R1129   
 L  R1130   
 L  R1131   
 L  R1132   
 L  R1133   
 L  R1134   
 L  R1135   
 L  R1136   
 L  R1137   
 L  R1138   
 L  R1139   
 L  R1140   
 L  R1141   
 L  R1142   
 L  R1143   
 L  R1144   
 L  R1145   
 L  R1146   
 L  R1147   
 L  R1148   
 L  R1149   
 L  R1150   
 L  R1151   
 L  R1152   
 L  R1153   
 L  R1154   
 L  R1155   
 L  R1156   
 L  R1157   
 L  R1158   
 L  R1159   
 L  R1160   
 L  R1161   
 L  R1162   
 L  R1163   
 L  R1164   
 L  R1165   
 L  R1166   
 L  R1167   
 L  R1168   
 L  R1169   
 L  R1170   
 L  R1171   
 L  R1172   
 L  R1173   
 L  R1174   
 L  R1175   
 L  R1176   
 L  R1177   
 L  R1178   
 L  R1179   
 L  R1180   
 L  R1181   
 L  R1182   
 L  R1183   
 L  R1184   
 L  R1185   
 L  R1186   
 L  R1187   
 L  R1188   
 L  R1189   
 L  R1190   
 L  R1191   
 L  R1192   
 L  R1193   
 L  R1194   
 L  R1195   
 L  R1196   
 L  R1197   
 L  R1198   
 L  R1199   
 L  R1200   
 L  R1201   
 L  R1202   
 L  R1203   
 L  R1204   
 L  R1205   
 L  R1206   
 L  R1207   
 L  R1208   
 L  R1209   
 L  R1210   
 L  R1211   
 L  R1212   
 L  R1213   
 L  R1214   
 L  R1215   
 L  R1216   
 L  R1217   
 L  R1218   
 L  R1219   
 L  R1220   
 L  R1221   
 L  R1222   
 L  R1223   
 L  R1224   
 L  R1225   
 L  R1226   
 L  R1227   
 L  R1228   
 L  R1229   
 L  R1230   
 L  R1231   
 L  R1232   
 L  R1233   
 L  R1234   
 L  R1235   
 L  R1236   
 L  R1237   
 L  R1238   
 L  R1239   
 L  R1240   
 L  R1241   
 L  R1242   
 L  R1243   
 L  R1244   
 L  R1245   
 L  R1246   
 L  R1247   
 L  R1248   
 L  R1249   
 L  R1250   
 L  R1251   
 L  R1252   
 L  R1253   
 L  R1254   
 L  R1255   
 L  R1256   
 L  R1257   
 L  R1258   
 L  R1259   
 L  R1260   
 L  R1261   
 L  R1262   
 L  R1263   
 L  R1264   
 L  R1265   
 L  R1266   
 L  R1267   
 L  R1268   
 L  R1269   
 L  R1270   
 L  R1271   
 L  R1272   
 L  R1273   
 L  R1274   
 L  R1275   
 L  R1276   
 L  R1277   
 L  R1278   
 L  R1279   
 L  R1280   
 L  R1281   
 L  R1282   
 L  R1283   
 L  R1284   
 L  R1285   
 L  R1286   
 L  R1287   
 L  R1288   
 L  R1289   
 L  R1290   
 L  R1291   
 L  R1292   
 L  R1293   
 L  R1294   
 L  R1295   
 L  R1296   
 L  R1297   
 L  R1298   
 L  R1299   
 L  R1300   
 L  R1301   
 L  R1302   
 L  R1303   
 L  R1304   
 L  R1305   
 L  R1306   
 L  R1307   
 L  R1308   
 L  R1309   
 L  R1310   
 L  R1311   
 L  R1312   
 L  R1313   
 L  R1314   
 L  R1315   
 L  R1316   
 L  R1317   
 L  R1318   
 L  R1319   
 L  R1320   
 L  R1321   
 L  R1322   
 L  R1323   
 L  R1324   
 L  R1325   
 L  R1326   
 L  R1327   
 L  R1328   
 L  R1329   
 L  R1330   
 L  R1331   
 L  R1332   
 L  R1333   
 L  R1334   
 L  R1335   
 L  R1336   
 L  R1337   
 L  R1338   
 L  R1339   
 L  R1340   
 L  R1341   
 L  R1342   
 L  R1343   
 L  R1344   
 L  R1345   
 L  R1346   
 L  R1347   
 L  R1348   
 L  R1349   
 L  R1350   
 L  R1351   
 L  R1352   
 L  R1353   
 L  R1354   
 L  R1355   
 L  R1356   
 L  R1357   
 L  R1358   
 L  R1359   
 L  R1360   
 L  R1361   
 L  R1362   
 L  R1363   
 L  R1364   
 L  R1365   
 L  R1366   
 L  R1367   
 L  R1368   
 L  R1369   
 L  R1370   
 L  R1371   
 L  R1372   
 L  R1373   
 L  R1374   
 L  R1375   
 L  R1376   
 L  R1377   
 L  R1378   
 L  R1379   
 L  R1380   
 L  R1381   
 L  R1382   
 L  R1383   
 L  R1384   
 L  R1385   
 L  R1386   
 L  R1387   
 L  R1388   
 L  R1389   
 L  R1390   
 L  R1391   
 L  R1392   
 L  R1393   
 L  R1394   
 L  R1395   
 L  R1396   
 L  R1397   
 L  R1398   
 L  R1399   
 L  R1400   
 L  R1401   
 L  R1402   
 L  R1403   
 L  R1404   
 L  R1405   
 L  R1406   
 L  R1407   
 L  R1408   
 L  R1409   
 L  R1410   
 L  R1411   
 L  R1412   
 L  R1413   
 L  R1414   
 L  R1415   
 L  R1416   
 L  R1417   
 L  R1418   
 L  R1419   
 L  R1420   
 L  R1421   
 L  R1422   
 L  R1423   
 L  R1424   
 L  R1425   
 L  R1426   
 L  R1427   
 L  R1428   
 L  R1429   
 L  R1430   
 L  R1431   
 L  R1432   
 L  R1433   
 L  R1434   
 L  R1435   
 L  R1436   
 L  R1437   
 L  R1438   
 L  R1439   
 L  R1440   
 L  R1441   
 L  R1442   
 L  R1443   
 L  R1444   
 L  R1445   
 L  R1446   
 L  R1447   
 L  R1448   
 L  R1449   
 L  R1450   
 L  R1451   
 L  R1452   
 L  R1453   
 L  R1454   
 L  R1455   
 L  R1456   
 L  R1457   
 L  R1458   
 L  R1459   
 L  R1460   
 L  R1461   
 L  R1462   
 L  R1463   
 L  R1464   
 L  R1465   
 L  R1466   
 L  R1467   
 L  R1468   
 L  R1469   
 L  R1470   
 L  R1471   
 L  R1472   
 L  R1473   
 L  R1474   
 L  R1475   
 L  R1476   
 L  R1477   
 L  R1478   
 L  R1479   
 L  R1480   
 L  R1481   
 L  R1482   
 L  R1483   
 L  R1484   
 L  R1485   
 L  R1486   
 L  R1487   
 L  R1488   
 L  R1489   
 L  R1490   
 L  R1491   
 L  R1492   
 L  R1493   
 L  R1494   
 L  R1495   
 L  R1496   
 L  R1497   
 L  R1498   
 L  R1499   
 L  R1500   
 L  R1501   
 L  R1502   
 L  R1503   
 L  R1504   
 L  R1505   
 L  R1506   
 L  R1507   
 L  R1508   
 L  R1509   
 L  R1510   
 L  R1511   
 L  R1512   
 L  R1513   
 L  R1514   
 L  R1515   
 L  R1516   
 L  R1517   
 L  R1518   
 L  R1519   
 L  R1520   
 L  R1521   
 L  R1522   
 L  R1523   
 L  R1524   
 L  R1525   
 L  R1526   
 L  R1527   
 L  R1528   
 L  R1529   
 L  R1530   
 L  R1531   
 L  R1532   
 L  R1533   
 L  R1534   
 L  R1535   
 L  R1536   
 L  R1537   
 L  R1538   
 L  R1539   
 L  R1540   
 L  R1541   
 L  R1542   
 L  R1543   
 L  R1544   
 L  R1545   
 L  R1546   
 L  R1547   
 L  R1548   
 L  R1549   
 L  R1550   
 L  R1551   
 L  R1552   
 L  R1553   
 L  R1554   
 L  R1555   
 L  R1556   
 L  R1557   
 L  R1558   
 L  R1559   
 L  R1560   
 L  R1561   
 L  R1562   
 L  R1563   
 L  R1564   
 L  R1565   
 L  R1566   
 L  R1567   
 L  R1568   
 L  R1569   
 L  R1570   
 L  R1571   
 L  R1572   
 L  R1573   
 L  R1574   
 L  R1575   
 L  R1576   
 L  R1577   
 L  R1578   
 L  R1579   
 L  R1580   
 L  R1581   
 L  R1582   
 L  R1583   
 L  R1584   
 L  R1585   
 L  R1586   
 L  R1587   
 L  R1588   
 L  R1589   
 L  R1590   
 L  R1591   
 L  R1592   
 L  R1593   
 L  R1594   
 L  R1595   
 L  R1596   
 L  R1597   
 L  R1598   
 L  R1599   
 L  R1600   
 L  R1601   
 L  R1602   
 L  R1603   
 L  R1604   
 L  R1605   
 L  R1606   
 L  R1607   
 L  R1608   
 L  R1609   
 L  R1610   
 L  R1611   
 L  R1612   
 L  R1613   
 L  R1614   
 L  R1615   
 L  R1616   
 L  R1617   
 L  R1618   
 L  R1619   
 L  R1620   
 L  R1621   
 L  R1622   
 L  R1623   
 L  R1624   
 L  R1625   
 L  R1626   
 L  R1627   
 L  R1628   
 L  R1629   
 L  R1630   
 L  R1631   
 L  R1632   
 L  R1633   
 L  R1634   
 L  R1635   
 L  R1636   
 L  R1637   
 L  R1638   
 L  R1639   
 L  R1640   
 L  R1641   
 L  R1642   
 L  R1643   
 L  R1644   
 L  R1645   
 L  R1646   
 L  R1647   
 L  R1648   
 L  R1649   
 L  R1650   
 L  R1651   
 L  R1652   
 L  R1653   
 L  R1654   
 L  R1655   
 L  R1656   
 L  R1657   
 L  R1658   
 L  R1659   
 L  R1660   
 L  R1661   
 L  R1662   
 L  R1663   
 L  R1664   
 L  R1665   
 L  R1666   
 L  R1667   
 L  R1668   
 L  R1669   
 L  R1670   
 L  R1671   
 L  R1672   
 L  R1673   
 L  R1674   
 L  R1675   
 L  R1676   
 L  R1677   
 L  R1678   
 L  R1679   
 L  R1680   
 L  R1681   
 L  R1682   
 L  R1683   
 L  R1684   
 L  R1685   
 L  R1686   
 L  R1687   
 L  R1688   
 L  R1689   
 L  R1690   
 L  R1691   
 L  R1692   
 L  R1693   
 L  R1694   
 L  R1695   
 L  R1696   
 L  R1697   
 L  R1698   
 L  R1699   
 L  R1700   
 L  R1701   
 L  R1702   
 L  R1703   
 L  R1704   
 L  R1705   
 L  R1706   
 L  R1707   
 L  R1708   
 L  R1709   
 L  R1710   
 L  R1711   
 L  R1712   
 L  R1713   
 L  R1714   
 L  R1715   
 L  R1716   
 L  R1717   
 L  R1718   
 L  R1719   
 L  R1720   
 L  R1721   
 L  R1722   
 L  R1723   
 L  R1724   
 L  R1725   
 L  R1726   
 L  R1727   
 L  R1728   
 L  R1729   
 L  R1730   
 L  R1731   
 L  R1732   
 L  R1733   
 L  R1734   
 L  R1735   
 L  R1736   
 L  R1737   
 L  R1738   
 L  R1739   
 L  R1740   
 L  R1741   
 L  R1742   
 L  R1743   
 L  R1744   
 L  R1745   
 L  R1746   
 L  R1747   
 L  R1748   
 L  R1749   
 L  R1750   
 L  R1751   
 L  R1752   
 L  R1753   
 L  R1754   
 L  R1755   
 L  R1756   
 L  R1757   
 L  R1758   
 L  R1759   
 L  R1760   
 L  R1761   
 L  R1762   
 L  R1763   
 L  R1764   
 L  R1765   
 L  R1766   
 L  R1767   
 L  R1768   
 L  R1769   
 L  R1770   
 L  R1771   
 L  R1772   
 L  R1773   
 L  R1774   
 L  R1775   
 L  R1776   
 L  R1777   
 L  R1778   
 L  R1779   
 L  R1780   
 L  R1781   
 L  R1782   
 L  R1783   
 L  R1784   
 L  R1785   
 L  R1786   
 L  R1787   
 L  R1788   
 L  R1789   
 L  R1790   
 L  R1791   
 L  R1792   
 L  R1793   
 L  R1794   
 L  R1795   
 L  R1796   
 L  R1797   
 L  R1798   
 L  R1799   
 L  R1800   
 L  R1801   
 L  R1802   
 L  R1803   
 L  R1804   
 L  R1805   
 L  R1806   
 L  R1807   
 L  R1808   
 L  R1809   
 L  R1810   
 L  R1811   
 L  R1812   
 L  R1813   
 L  R1814   
 L  R1815   
 L  R1816   
 L  R1817   
 L  R1818   
 L  R1819   
 L  R1820   
 L  R1821   
 L  R1822   
 L  R1823   
 L  R1824   
 L  R1825   
 L  R1826   
 L  R1827   
 L  R1828   
 L  R1829   
 L  R1830   
 L  R1831   
 L  R1832   
 L  R1833   
 L  R1834   
 L  R1835   
 L  R1836   
 L  R1837   
 L  R1838   
 L  R1839   
 L  R1840   
 L  R1841   
 L  R1842   
 L  R1843   
 L  R1844   
 L  R1845   
 L  R1846   
 L  R1847   
 L  R1848   
 L  R1849   
 L  R1850   
 L  R1851   
 L  R1852   
 L  R1853   
 L  R1854   
 L  R1855   
 L  R1856   
 L  R1857   
 L  R1858   
 L  R1859   
 L  R1860   
 L  R1861   
 L  R1862   
 L  R1863   
 L  R1864   
 L  R1865   
 L  R1866   
 L  R1867   
 L  R1868   
 L  R1869   
 L  R1870   
 L  R1871   
 L  R1872   
 L  R1873   
 L  R1874   
 L  R1875   
 L  R1876   
 L  R1877   
 L  R1878   
 L  R1879   
 L  R1880   
 L  R1881   
 L  R1882   
 L  R1883   
 L  R1884   
 L  R1885   
 L  R1886   
 L  R1887   
 L  R1888   
 L  R1889   
 L  R1890   
 L  R1891   
 L  R1892   
 L  R1893   
 L  R1894   
 L  R1895   
 L  R1896   
 L  R1897   
 L  R1898   
 L  R1899   
 L  R1900   
 L  R1901   
 L  R1902   
 L  R1903   
 L  R1904   
 L  R1905   
 L  R1906   
 L  R1907   
 L  R1908   
 L  R1909   
 L  R1910   
 L  R1911   
 L  R1912   
 L  R1913   
 L  R1914   
 L  R1915   
 L  R1916   
 L  R1917   
 L  R1918   
 L  R1919   
 L  R1920   
 L  R1921   
 L  R1922   
 L  R1923   
 L  R1924   
 L  R1925   
 L  R1926   
 L  R1927   
 L  R1928   
 L  R1929   
 L  R1930   
 L  R1931   
 L  R1932   
 L  R1933   
 L  R1934   
 L  R1935   
 L  R1936   
 L  R1937   
 L  R1938   
 L  R1939   
 L  R1940   
 L  R1941   
 L  R1942   
 L  R1943   
 L  R1944   
 L  R1945   
 L  R1946   
 L  R1947   
 L  R1948   
 L  R1949   
 L  R1950   
 L  R1951   
 L  R1952   
 L  R1953   
 L  R1954   
 L  R1955   
 L  R1956   
 L  R1957   
 L  R1958   
 L  R1959   
 L  R1960   
 L  R1961   
 L  R1962   
 L  R1963   
 L  R1964   
 L  R1965   
 L  R1966   
 L  R1967   
 L  R1968   
 L  R1969   
 L  R1970   
 L  R1971   
 L  R1972   
 L  R1973   
 L  R1974   
 L  R1975   
 L  R1976   
 L  R1977   
 L  R1978   
 L  R1979   
 L  R1980   
 L  R1981   
 L  R1982   
 L  R1983   
 L  R1984   
 L  R1985   
 L  R1986   
 L  R1987   
 L  R1988   
 L  R1989   
 L  R1990   
 L  R1991   
 L  R1992   
 L  R1993   
 L  R1994   
 L  R1995   
 L  R1996   
 L  R1997   
 L  R1998   
 L  R1999   
 L  R2000   
 L  R2001   
 L  R2002   
 L  R2003   
 L  R2004   
 L  R2005   
 L  R2006   
 L  R2007   
 L  R2008   
 L  R2009   
 L  R2010   
 L  R2011   
 L  R2012   
 L  R2013   
 L  R2014   
 L  R2015   
 L  R2016   
 L  R2017   
 L  R2018   
 L  R2019   
 L  R2020   
 L  R2021   
 L  R2022   
 L  R2023   
 L  R2024   
 L  R2025   
 L  R2026   
 L  R2027   
 L  R2028   
 L  R2029   
 L  R2030   
 L  R2031   
 L  R2032   
 L  R2033   
 L  R2034   
 L  R2035   
 L  R2036   
 L  R2037   
 L  R2038   
 L  R2039   
 L  R2040   
 L  R2041   
 L  R2042   
 L  R2043   
 L  R2044   
 L  R2045   
 L  R2046   
 L  R2047   
 L  R2048   
 L  R2049   
 L  R2050   
 L  R2051   
 L  R2052   
 L  R2053   
 L  R2054   
 L  R2055   
 L  R2056   
 L  R2057   
 L  R2058   
 L  R2059   
 L  R2060   
 L  R2061   
 L  R2062   
 L  R2063   
 L  R2064   
 L  R2065   
 L  R2066   
 L  R2067   
 L  R2068   
 L  R2069   
 L  R2070   
 L  R2071   
 L  R2072   
 L  R2073   
 L  R2074   
 L  R2075   
 L  R2076   
 L  R2077   
 L  R2078   
 L  R2079   
 L  R2080   
 L  R2081   
 L  R2082   
 L  R2083   
 L  R2084   
 L  R2085   
 L  R2086   
 L  R2087   
 L  R2088   
 L  R2089   
 L  R2090   
 L  R2091   
 L  R2092   
 L  R2093   
 L  R2094   
 L  R2095   
 L  R2096   
 L  R2097   
 L  R2098   
 L  R2099   
 L  R2100   
 L  R2101   
 L  R2102   
 L  R2103   
 L  R2104   
 L  R2105   
 L  R2106   
 L  R2107   
 L  R2108   
 L  R2109   
 L  R2110   
 L  R2111   
 L  R2112   
 L  R2113   
 L  R2114   
 L  R2115   
 L  R2116   
 L  R2117   
 L  R2118   
 L  R2119   
 L  R2120   
 L  R2121   
 L  R2122   
 L  R2123   
 L  R2124   
 L  R2125   
 L  R2126   
 L  R2127   
 L  R2128   
 L  R2129   
 L  R2130   
 L  R2131   
 L  R2132   
 L  R2133   
 L  R2134   
 L  R2135   
 L  R2136   
 L  R2137   
 L  R2138   
 L  R2139   
 L  R2140   
 L  R2141   
 L  R2142   
 L  R2143   
 L  R2144   
 L  R2145   
 L  R2146   
 L  R2147   
 L  R2148   
 L  R2149   
 L  R2150   
 L  R2151   
 L  R2152   
 L  R2153   
 L  R2154   
 L  R2155   
 L  R2156   
 L  R2157   
 L  R2158   
 L  R2159   
 L  R2160   
 L  R2161   
 L  R2162   
 L  R2163   
 L  R2164   
 L  R2165   
 L  R2166   
 L  R2167   
 L  R2168   
 L  R2169   
 L  R2170   
 L  R2171   
 L  R2172   
 L  R2173   
 L  R2174   
 L  R2175   
 L  R2176   
 L  R2177   
 L  R2178   
 L  R2179   
 L  R2180   
 L  R2181   
 L  R2182   
 L  R2183   
 L  R2184   
 L  R2185   
 L  R2186   
 L  R2187   
 L  R2188   
 L  R2189   
 L  R2190   
 L  R2191   
 L  R2192   
 L  R2193   
 L  R2194   
 L  R2195   
 L  R2196   
 L  R2197   
 L  R2198   
 L  R2199   
 L  R2200   
 L  R2201   
 L  R2202   
 L  R2203   
 L  R2204   
 L  R2205   
 L  R2206   
 L  R2207   
 L  R2208   
 L  R2209   
 L  R2210   
 L  R2211   
 L  R2212   
 L  R2213   
 L  R2214   
 L  R2215   
 L  R2216   
 L  R2217   
 L  R2218   
 L  R2219   
 L  R2220   
 L  R2221   
 L  R2222   
 L  R2223   
 L  R2224   
 L  R2225   
 L  R2226   
 L  R2227   
 L  R2228   
 L  R2229   
 L  R2230   
 L  R2231   
 L  R2232   
 L  R2233   
 L  R2234   
 L  R2235   
 L  R2236   
 L  R2237   
 L  R2238   
 L  R2239   
 L  R2240   
 L  R2241   
 L  R2242   
 L  R2243   
 L  R2244   
 L  R2245   
 L  R2246   
 L  R2247   
 L  R2248   
 L  R2249   
 L  R2250   
 L  R2251   
 L  R2252   
 L  R2253   
 L  R2254   
 L  R2255   
 L  R2256   
 L  R2257   
 L  R2258   
 L  R2259   
 L  R2260   
 L  R2261   
 L  R2262   
 L  R2263   
 L  R2264   
 L  R2265   
 L  R2266   
 L  R2267   
 L  R2268   
 L  R2269   
 L  R2270   
 L  R2271   
 L  R2272   
 L  R2273   
 L  R2274   
 L  R2275   
 L  R2276   
 L  R2277   
 L  R2278   
 L  R2279   
 L  R2280   
 L  R2281   
 L  R2282   
 L  R2283   
 L  R2284   
 L  R2285   
 L  R2286   
 L  R2287   
 L  R2288   
 L  R2289   
 L  R2290   
 L  R2291   
 L  R2292   
 L  R2293   
 L  R2294   
 L  R2295   
 L  R2296   
 L  R2297   
 L  R2298   
 L  R2299   
 L  R2300   
 L  R2301   
 L  R2302   
 L  R2303   
 L  R2304   
 L  R2305   
 L  R2306   
 L  R2307   
 L  R2308   
 L  R2309   
 L  R2310   
 L  R2311   
 L  R2312   
 L  R2313   
 L  R2314   
 L  R2315   
 L  R2316   
 L  R2317   
 L  R2318   
 L  R2319   
 L  R2320   
 L  R2321   
 L  R2322   
 L  R2323   
 L  R2324   
 L  R2325   
 L  R2326   
 L  R2327   
 L  R2328   
 L  R2329   
 L  R2330   
 L  R2331   
 L  R2332   
 L  R2333   
 L  R2334   
 L  R2335   
 L  R2336   
 L  R2337   
 L  R2338   
 L  R2339   
 L  R2340   
 L  R2341   
 L  R2342   
 L  R2343   
 L  R2344   
 L  R2345   
 L  R2346   
 L  R2347   
 L  R2348   
 L  R2349   
 L  R2350   
 L  R2351   
 L  R2352   
 L  R2353   
 L  R2354   
 L  R2355   
 L  R2356   
 L  R2357   
 L  R2358   
 L  R2359   
 L  R2360   
 L  R2361   
 L  R2362   
 L  R2363   
 L  R2364   
 L  R2365   
 L  R2366   
 L  R2367   
 L  R2368   
 L  R2369   
 L  R2370   
 L  R2371   
 L  R2372   
 L  R2373   
 L  R2374   
 L  R2375   
 L  R2376   
 L  R2377   
 L  R2378   
 L  R2379   
 L  R2380   
 L  R2381   
 L  R2382   
 L  R2383   
 L  R2384   
 L  R2385   
 L  R2386   
 L  R2387   
 L  R2388   
 L  R2389   
 L  R2390   
 L  R2391   
 L  R2392   
 L  R2393   
 L  R2394   
 L  R2395   
 L  R2396   
 L  R2397   
 L  R2398   
 L  R2399   
 L  R2400   
 L  R2401   
 L  R2402   
 L  R2403   
 L  R2404   
 L  R2405   
 L  R2406   
 L  R2407   
 L  R2408   
 L  R2409   
 L  R2410   
 L  R2411   
 L  R2412   
 L  R2413   
 L  R2414   
 L  R2415   
 L  R2416   
 L  R2417   
 L  R2418   
 L  R2419   
 L  R2420   
 L  R2421   
 L  R2422   
 L  R2423   
 L  R2424   
 L  R2425   
 L  R2426   
 L  R2427   
 L  R2428   
 L  R2429   
 L  R2430   
 L  R2431   
 L  R2432   
 L  R2433   
 L  R2434   
 L  R2435   
 L  R2436   
 L  R2437   
 L  R2438   
 L  R2439   
 L  R2440   
 L  R2441   
 L  R2442   
 L  R2443   
 L  R2444   
 L  R2445   
 L  R2446   
 L  R2447   
 L  R2448   
 L  R2449   
 L  R2450   
 L  R2451   
 L  R2452   
 L  R2453   
 L  R2454   
 L  R2455   
 L  R2456   
 L  R2457   
 L  R2458   
 L  R2459   
 L  R2460   
 L  R2461   
 L  R2462   
 L  R2463   
 L  R2464   
 L  R2465   
 L  R2466   
 L  R2467   
 L  R2468   
 L  R2469   
 L  R2470   
 L  R2471   
 L  R2472   
 L  R2473   
 L  R2474   
 L  R2475   
 L  R2476   
 L  R2477   
 L  R2478   
 L  R2479   
 L  R2480   
 L  R2481   
 L  R2482   
 L  R2483   
 L  R2484   
 L  R2485   
 L  R2486   
 L  R2487   
 L  R2488   
 L  R2489   
 L  R2490   
 L  R2491   
 L  R2492   
 L  R2493   
 L  R2494   
 L  R2495   
 L  R2496   
 L  R2497   
 L  R2498   
 L  R2499   
 L  R2500   
 L  R2501   
 L  R2502   
 L  R2503   
 L  R2504   
 L  R2505   
 L  R2506   
 L  R2507   
 L  R2508   
 L  R2509   
 L  R2510   
 L  R2511   
 L  R2512   
 L  R2513   
 L  R2514   
 L  R2515   
 L  R2516   
 L  R2517   
 L  R2518   
 L  R2519   
 L  R2520   
 L  R2521   
 L  R2522   
 L  R2523   
 L  R2524   
 L  R2525   
 L  R2526   
 L  R2527   
 L  R2528   
 L  R2529   
 L  R2530   
 L  R2531   
 L  R2532   
 L  R2533   
 L  R2534   
 L  R2535   
 L  R2536   
 L  R2537   
 L  R2538   
 L  R2539   
 L  R2540   
 L  R2541   
 L  R2542   
 L  R2543   
 L  R2544   
 L  R2545   
 L  R2546   
 L  R2547   
 L  R2548   
 L  R2549   
 L  R2550   
 L  R2551   
 L  R2552   
 L  R2553   
 L  R2554   
 L  R2555   
 L  R2556   
 L  R2557   
 L  R2558   
 L  R2559   
 L  R2560   
 L  R2561   
 L  R2562   
 L  R2563   
 L  R2564   
 L  R2565   
 L  R2566   
 L  R2567   
 L  R2568   
 L  R2569   
 L  R2570   
 L  R2571   
 L  R2572   
 L  R2573   
 L  R2574   
 L  R2575   
 L  R2576   
 L  R2577   
 L  R2578   
 L  R2579   
 L  R2580   
 L  R2581   
 L  R2582   
 L  R2583   
 L  R2584   
 L  R2585   
 L  R2586   
 L  R2587   
 L  R2588   
 L  R2589   
 L  R2590   
 L  R2591   
 L  R2592   
 L  R2593   
 L  R2594   
 L  R2595   
 L  R2596   
 L  R2597   
 L  R2598   
 L  R2599   
 L  R2600   
 L  R2601   
 L  R2602   
 L  R2603   
 L  R2604   
 L  R2605   
 L  R2606   
 L  R2607   
 L  R2608   
 L  R2609   
 L  R2610   
 L  R2611   
 L  R2612   
 L  R2613   
 L  R2614   
 L  R2615   
 L  R2616   
 L  R2617   
 L  R2618   
 L  R2619   
 L  R2620   
 L  R2621   
 L  R2622   
 L  R2623   
 L  R2624   
 L  R2625   
 L  R2626   
 L  R2627   
 L  R2628   
 L  R2629   
 L  R2630   
 L  R2631   
 L  R2632   
 L  R2633   
 L  R2634   
 L  R2635   
 L  R2636   
 L  R2637   
 L  R2638   
 L  R2639   
 L  R2640   
 L  R2641   
 L  R2642   
 L  R2643   
 L  R2644   
 L  R2645   
 L  R2646   
 L  R2647   
 L  R2648   
 L  R2649   
 L  R2650   
 L  R2651   
 L  R2652   
 L  R2653   
 L  R2654   
 L  R2655   
 L  R2656   
 L  R2657   
 L  R2658   
 L  R2659   
 L  R2660   
 L  R2661   
 L  R2662   
 L  R2663   
 L  R2664   
 L  R2665   
 L  R2666   
 L  R2667   
 L  R2668   
 L  R2669   
 L  R2670   
 L  R2671   
 L  R2672   
 L  R2673   
 L  R2674   
 L  R2675   
 L  R2676   
 L  R2677   
 L  R2678   
 L  R2679   
 L  R2680   
 L  R2681   
 L  R2682   
 L  R2683   
 L  R2684   
 L  R2685   
 L  R2686   
 L  R2687   
 L  R2688   
 L  R2689   
 L  R2690   
 L  R2691   
 L  R2692   
 L  R2693   
 L  R2694   
 L  R2695   
 L  R2696   
 L  R2697   
 L  R2698   
 L  R2699   
 L  R2700   
 L  R2701   
 L  R2702   
 L  R2703   
 L  R2704   
 L  R2705   
 L  R2706   
 L  R2707   
 L  R2708   
 L  R2709   
 L  R2710   
 L  R2711   
 L  R2712   
 L  R2713   
 L  R2714   
 L  R2715   
 L  R2716   
 L  R2717   
 L  R2718   
 L  R2719   
 L  R2720   
 L  R2721   
 L  R2722   
 L  R2723   
 L  R2724   
 L  R2725   
 L  R2726   
 L  R2727   
 L  R2728   
 L  R2729   
 L  R2730   
 L  R2731   
 L  R2732   
 L  R2733   
 L  R2734   
 L  R2735   
 L  R2736   
 L  R2737   
 L  R2738   
 L  R2739   
 L  R2740   
 L  R2741   
 L  R2742   
 L  R2743   
 L  R2744   
 L  R2745   
 L  R2746   
 L  R2747   
 L  R2748   
 L  R2749   
 L  R2750   
 L  R2751   
 L  R2752   
 L  R2753   
 L  R2754   
 L  R2755   
 L  R2756   
 L  R2757   
 L  R2758   
 L  R2759   
 L  R2760   
 L  R2761   
 L  R2762   
 L  R2763   
 L  R2764   
 L  R2765   
 L  R2766   
 L  R2767   
 L  R2768   
 L  R2769   
 L  R2770   
 L  R2771   
 L  R2772   
 L  R2773   
 L  R2774   
 L  R2775   
 L  R2776   
 L  R2777   
 L  R2778   
 L  R2779   
 L  R2780   
 L  R2781   
 L  R2782   
 L  R2783   
 L  R2784   
 L  R2785   
 L  R2786   
 L  R2787   
 L  R2788   
 L  R2789   
 L  R2790   
 L  R2791   
 L  R2792   
 L  R2793   
 L  R2794   
 L  R2795   
 L  R2796   
 L  R2797   
 L  R2798   
 L  R2799   
 L  R2800   
 L  R2801   
 L  R2802   
 L  R2803   
 L  R2804   
 L  R2805   
 L  R2806   
 L  R2807   
 L  R2808   
 L  R2809   
 L  R2810   
 L  R2811   
 L  R2812   
 L  R2813   
 L  R2814   
 L  R2815   
 L  R2816   
 L  R2817   
 L  R2818   
 L  R2819   
 L  R2820   
 L  R2821   
 L  R2822   
 L  R2823   
 L  R2824   
 L  R2825   
 L  R2826   
 L  R2827   
 L  R2828   
 L  R2829   
 L  R2830   
 L  R2831   
 L  R2832   
 L  R2833   
 L  R2834   
 L  R2835   
 L  R2836   
 L  R2837   
 L  R2838   
 L  R2839   
 L  R2840   
 L  R2841   
 L  R2842   
 L  R2843   
 L  R2844   
 L  R2845   
 L  R2846   
 L  R2847   
 L  R2848   
 L  R2849   
 L  R2850   
 L  R2851   
 L  R2852   
 L  R2853   
 L  R2854   
 L  R2855   
 L  R2856   
 L  R2857   
 L  R2858   
 L  R2859   
 L  R2860   
 L  R2861   
 L  R2862   
 L  R2863   
 L  R2864   
 L  R2865   
 L  R2866   
 L  R2867   
 L  R2868   
 L  R2869   
 L  R2870   
 L  R2871   
 L  R2872   
 L  R2873   
 L  R2874   
 L  R2875   
 L  R2876   
 L  R2877   
 L  R2878   
 L  R2879   
 L  R2880   
 L  R2881   
 L  R2882   
 L  R2883   
 L  R2884   
 L  R2885   
 L  R2886   
 L  R2887   
 L  R2888   
 L  R2889   
 L  R2890   
 L  R2891   
 L  R2892   
 L  R2893   
 L  R2894   
 L  R2895   
 L  R2896   
 L  R2897   
 L  R2898   
 L  R2899   
 L  R2900   
 L  R2901   
 L  R2902   
 L  R2903   
 L  R2904   
 L  R2905   
 L  R2906   
 L  R2907   
 L  R2908   
 L  R2909   
 L  R2910   
 L  R2911   
 L  R2912   
 L  R2913   
 L  R2914   
 L  R2915   
 L  R2916   
 L  R2917   
 L  R2918   
 L  R2919   
 L  R2920   
 L  R2921   
 L  R2922   
 L  R2923   
 L  R2924   
 L  R2925   
 L  R2926   
 L  R2927   
 L  R2928   
 L  R2929   
 L  R2930   
 L  R2931   
 L  R2932   
 L  R2933   
 L  R2934   
 L  R2935   
 L  R2936   
 L  qc0     
 L  qc1     
 L  qc2     
 L  qc3     
 L  qc4     
 L  qc5     
 L  qc6     
 L  qc7     
 L  qc8     
 L  qc9     
 L  qc10    
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    phi[0,1]  R0        1
    phi[0,1]  R1        1
    phi[0,1]  R9        -1
    phi[0,1]  R101      -3.0999999046325684e+00
    phi[0,1]  R102      -3.0999999046325684e+00
    phi[0,1]  R103      -2.2400000095367432e+00
    phi[0,1]  R104      -2.2400000095367432e+00
    phi[0,1]  R105      -3.0999999046325684e+00
    phi[0,1]  R106      -3.0999999046325684e+00
    phi[0,1]  R107      -2.5699999332427979e+00
    phi[0,1]  R108      -2.5699999332427979e+00
    phi[0,1]  R109      -3.0999999046325684e+00
    phi[0,1]  R110      -3.0999999046325684e+00
    phi[0,1]  R111      -2.0899999141693115e+00
    phi[0,1]  R112      -2.0899999141693115e+00
    phi[0,1]  R113      -3.0999999046325684e+00
    phi[0,1]  R114      -3.0999999046325684e+00
    phi[0,1]  R115      6.1420863866806030e-01
    phi[0,1]  R116      2.3601818084716797e-01
    phi[0,1]  R117      -0.829688549041748
    phi[0,1]  R118      3.6119353771209717e-01
    phi[0,1]  R119      2.18823504447937
    phi[0,1]  R120      1.4160277843475342e+00
    phi[0,1]  R121      2.4606387615203857e+00
    phi[0,1]  R122      -4.0803134441375732e-01
    phi[0,1]  R123      -3.2883840799331665e-01
    phi[0,1]  R124      7.9813510179519653e-01
    phi[0,1]  R125      -2.3884730339050293e+00
    phi[0,1]  R126      -1.2303519248962402e+00
    phi[0,1]  R127      -1.0051811933517456e+00
    phi[0,1]  R128      -3.0394535064697266e+00
    phi[0,1]  R129      7.4292242527008057e-01
    phi[0,1]  R130      -5.0445932149887085e-01
    phi[0,1]  R131      5.2356988191604614e-01
    phi[0,1]  R132      4.1371476650238037e-01
    phi[0,1]  R133      -3.4451186656951904e+00
    phi[0,1]  R134      -9.3637472391128540e-01
    phi[0,1]  R135      1.3489143848419189e+00
    phi[0,1]  R136      1.2764499187469482e+00
    phi[0,1]  R137      2.2126228809356689e+00
    phi[0,1]  R138      7.7408677898347378e-03
    phi[0,1]  R139      -1.7040338516235352e+00
    phi[0,1]  R140      -1.2025427818298340e+00
    phi[0,1]  R141      -1.5311525762081146e-01
    phi[0,1]  R142      -3.8064828515052795e-01
    phi[0,1]  R143      4.6384176611900330e-01
    phi[0,1]  R144      -8.1952917575836182e-01
    phi[0,1]  R145      0.769594669342041
    phi[0,1]  R146      -1.9393916428089142e-01
    phi[0,1]  R147      1.2135676145553589e+00
    phi[0,1]  R148      1.6299352645874023e+00
    phi[0,1]  R149      2.0010981559753418e+00
    phi[0,1]  R150      3.4677308797836304e-01
    phi[0,1]  R151      -2.4178989231586456e-01
    phi[0,1]  R152      8.3364170789718628e-01
    phi[0,1]  R153      -2.0763878822326660e+00
    phi[0,1]  R154      2.0803032815456390e-01
    phi[0,1]  R155      -9.2347878217697144e-01
    phi[0,1]  R156      -3.4373199939727783e-01
    phi[0,1]  R157      -2.4745929241180420e+00
    phi[0,1]  R158      -1.1387202739715576e+00
    phi[0,1]  R159      -0.0653628557920456
    phi[0,1]  R160      -1.2615528106689453e+00
    phi[0,1]  R161      -4.4821199774742126e-01
    phi[0,1]  R162      1.4887821674346924e+00
    phi[0,1]  R163      -9.0812504291534424e-01
    phi[0,1]  R164      1.2436661869287491e-01
    phi[0,1]  R165      -5.7258868217468262e-01
    phi[0,1]  R166      -2.2813397645950317e-01
    phi[0,1]  R167      5.6813216209411621e-01
    phi[0,1]  R168      5.0398790836334229e-01
    phi[0,1]  R169      -1.3110557794570923e+00
    phi[0,1]  R170      2.2024348378181458e-01
    phi[0,1]  R171      -7.6936548948287964e-01
    phi[0,1]  R172      0.564054548740387
    phi[0,1]  R173      -2.9329255223274231e-01
    phi[0,1]  R174      8.5796231031417847e-01
    phi[0,1]  R175      5.3206443786621094e-01
    phi[0,1]  R176      -2.3512044548988342e-01
    phi[0,1]  R177      -0.583536684513092
    phi[0,1]  R178      1.6479954719543457e+00
    phi[0,1]  R179      2.2364013195037842e+00
    phi[0,1]  R180      7.8413039445877075e-01
    phi[0,1]  R181      4.5980289578437805e-02
    phi[0,1]  R182      -2.6858317852020264e+00
    phi[0,1]  R183      -3.1658583879470825e-01
    phi[0,1]  R184      -6.5313440561294556e-01
    phi[1,0]  R0        -1
    phi[1,0]  R9        1
    phi[1,0]  R10       1
    phi[1,0]  R185      -3.0999999046325684e+00
    phi[1,0]  R186      -3.0999999046325684e+00
    phi[1,0]  R187      -2.2400000095367432e+00
    phi[1,0]  R188      -2.2400000095367432e+00
    phi[1,0]  R189      -3.0999999046325684e+00
    phi[1,0]  R190      -3.0999999046325684e+00
    phi[1,0]  R191      -2.5699999332427979e+00
    phi[1,0]  R192      -2.5699999332427979e+00
    phi[1,0]  R193      -3.0999999046325684e+00
    phi[1,0]  R194      -3.0999999046325684e+00
    phi[1,0]  R195      -2.0899999141693115e+00
    phi[1,0]  R196      -2.0899999141693115e+00
    phi[1,0]  R197      -3.0999999046325684e+00
    phi[1,0]  R198      -3.0999999046325684e+00
    phi[1,0]  R199      0.769594669342041
    phi[1,0]  R200      -1.9393916428089142e-01
    phi[1,0]  R201      1.2135676145553589e+00
    phi[1,0]  R202      1.6299352645874023e+00
    phi[1,0]  R203      2.0010981559753418e+00
    phi[1,0]  R204      3.4677308797836304e-01
    phi[1,0]  R205      -2.4178989231586456e-01
    phi[1,0]  R206      8.3364170789718628e-01
    phi[1,0]  R207      -2.0763878822326660e+00
    phi[1,0]  R208      2.0803032815456390e-01
    phi[1,0]  R209      -9.2347878217697144e-01
    phi[1,0]  R210      -3.4373199939727783e-01
    phi[1,0]  R211      -2.4745929241180420e+00
    phi[1,0]  R212      -1.1387202739715576e+00
    phi[1,0]  R213      -0.0653628557920456
    phi[1,0]  R214      -1.2615528106689453e+00
    phi[1,0]  R215      -4.4821199774742126e-01
    phi[1,0]  R216      1.4887821674346924e+00
    phi[1,0]  R217      -9.0812504291534424e-01
    phi[1,0]  R218      1.2436661869287491e-01
    phi[1,0]  R219      -5.7258868217468262e-01
    phi[1,0]  R220      -2.2813397645950317e-01
    phi[1,0]  R221      5.6813216209411621e-01
    phi[1,0]  R222      5.0398790836334229e-01
    phi[1,0]  R223      -1.3110557794570923e+00
    phi[1,0]  R224      2.2024348378181458e-01
    phi[1,0]  R225      -7.6936548948287964e-01
    phi[1,0]  R226      0.564054548740387
    phi[1,0]  R227      -2.9329255223274231e-01
    phi[1,0]  R228      8.5796231031417847e-01
    phi[1,0]  R229      5.3206443786621094e-01
    phi[1,0]  R230      -2.3512044548988342e-01
    phi[1,0]  R231      -0.583536684513092
    phi[1,0]  R232      1.6479954719543457e+00
    phi[1,0]  R233      2.2364013195037842e+00
    phi[1,0]  R234      7.8413039445877075e-01
    phi[1,0]  R235      4.5980289578437805e-02
    phi[1,0]  R236      -2.6858317852020264e+00
    phi[1,0]  R237      -3.1658583879470825e-01
    phi[1,0]  R238      -6.5313440561294556e-01
    phi[1,0]  R239      6.1420863866806030e-01
    phi[1,0]  R240      2.3601818084716797e-01
    phi[1,0]  R241      -0.829688549041748
    phi[1,0]  R242      3.6119353771209717e-01
    phi[1,0]  R243      2.18823504447937
    phi[1,0]  R244      1.4160277843475342e+00
    phi[1,0]  R245      2.4606387615203857e+00
    phi[1,0]  R246      -4.0803134441375732e-01
    phi[1,0]  R247      -3.2883840799331665e-01
    phi[1,0]  R248      7.9813510179519653e-01
    phi[1,0]  R249      -2.3884730339050293e+00
    phi[1,0]  R250      -1.2303519248962402e+00
    phi[1,0]  R251      -1.0051811933517456e+00
    phi[1,0]  R252      -3.0394535064697266e+00
    phi[1,0]  R253      7.4292242527008057e-01
    phi[1,0]  R254      -5.0445932149887085e-01
    phi[1,0]  R255      5.2356988191604614e-01
    phi[1,0]  R256      4.1371476650238037e-01
    phi[1,0]  R257      -3.4451186656951904e+00
    phi[1,0]  R258      -9.3637472391128540e-01
    phi[1,0]  R259      1.3489143848419189e+00
    phi[1,0]  R260      1.2764499187469482e+00
    phi[1,0]  R261      2.2126228809356689e+00
    phi[1,0]  R262      7.7408677898347378e-03
    phi[1,0]  R263      -1.7040338516235352e+00
    phi[1,0]  R264      -1.2025427818298340e+00
    phi[1,0]  R265      -1.5311525762081146e-01
    phi[1,0]  R266      -3.8064828515052795e-01
    phi[1,0]  R267      4.6384176611900330e-01
    phi[1,0]  R268      -8.1952917575836182e-01
    phi[0,6]  R0        1
    phi[0,6]  R1        1
    phi[0,6]  R54       -1
    phi[0,6]  R269      -3.0999999046325684e+00
    phi[0,6]  R270      -3.0999999046325684e+00
    phi[0,6]  R271      -2.2400000095367432e+00
    phi[0,6]  R272      -2.2400000095367432e+00
    phi[0,6]  R273      -3.0999999046325684e+00
    phi[0,6]  R274      -3.0999999046325684e+00
    phi[0,6]  R275      -2.5699999332427979e+00
    phi[0,6]  R276      -2.5699999332427979e+00
    phi[0,6]  R277      -3.0999999046325684e+00
    phi[0,6]  R278      -3.0999999046325684e+00
    phi[0,6]  R279      -2.0899999141693115e+00
    phi[0,6]  R280      -2.0899999141693115e+00
    phi[0,6]  R281      -3.0999999046325684e+00
    phi[0,6]  R282      -3.0999999046325684e+00
    phi[0,6]  R283      6.1420863866806030e-01
    phi[0,6]  R284      2.3601818084716797e-01
    phi[0,6]  R285      -0.829688549041748
    phi[0,6]  R286      3.6119353771209717e-01
    phi[0,6]  R287      2.18823504447937
    phi[0,6]  R288      1.4160277843475342e+00
    phi[0,6]  R289      2.4606387615203857e+00
    phi[0,6]  R290      -4.0803134441375732e-01
    phi[0,6]  R291      -3.2883840799331665e-01
    phi[0,6]  R292      7.9813510179519653e-01
    phi[0,6]  R293      -2.3884730339050293e+00
    phi[0,6]  R294      -1.2303519248962402e+00
    phi[0,6]  R295      -1.0051811933517456e+00
    phi[0,6]  R296      -3.0394535064697266e+00
    phi[0,6]  R297      7.4292242527008057e-01
    phi[0,6]  R298      -5.0445932149887085e-01
    phi[0,6]  R299      5.2356988191604614e-01
    phi[0,6]  R300      4.1371476650238037e-01
    phi[0,6]  R301      -3.4451186656951904e+00
    phi[0,6]  R302      -9.3637472391128540e-01
    phi[0,6]  R303      1.3489143848419189e+00
    phi[0,6]  R304      1.2764499187469482e+00
    phi[0,6]  R305      2.2126228809356689e+00
    phi[0,6]  R306      7.7408677898347378e-03
    phi[0,6]  R307      -1.7040338516235352e+00
    phi[0,6]  R308      -1.2025427818298340e+00
    phi[0,6]  R309      -1.5311525762081146e-01
    phi[0,6]  R310      -3.8064828515052795e-01
    phi[0,6]  R311      4.6384176611900330e-01
    phi[0,6]  R312      -8.1952917575836182e-01
    phi[0,6]  R313      -1.2000774145126343e+00
    phi[0,6]  R314      7.6394744217395782e-02
    phi[0,6]  R315      -3.2834053039550781e-01
    phi[0,6]  R316      4.7135055065155029e-01
    phi[0,6]  R317      -1.6203496456146240e+00
    phi[0,6]  R318      -1.1345604658126831e+00
    phi[0,6]  R319      -5.8417338132858276e-01
    phi[0,6]  R320      -1.6086968183517456e+00
    phi[0,6]  R321      -1.7797340154647827e+00
    phi[0,6]  R322      -8.2175695896148682e-01
    phi[0,6]  R323      9.2191642522811890e-01
    phi[0,6]  R324      1.1151922941207886e+00
    phi[0,6]  R325      1.1291612386703491e+00
    phi[0,6]  R326      1.8498758971691132e-01
    phi[0,6]  R327      -0.0330149382352829
    phi[0,6]  R328      2.2549942135810852e-01
    phi[0,6]  R329      7.5888383388519287e-01
    phi[0,6]  R330      0.5791015625
    phi[0,6]  R331      1.5948952734470367e-01
    phi[0,6]  R332      7.7515608072280884e-01
    phi[0,6]  R333      -1.3829548358917236e+00
    phi[0,6]  R334      6.3957124948501587e-01
    phi[0,6]  R335      0.272148996591568
    phi[0,6]  R336      -5.6983256340026855e-01
    phi[0,6]  R337      -0.798306405544281
    phi[0,6]  R338      -2.5867865085601807e+00
    phi[0,6]  R339      2.6694774627685547e-01
    phi[0,6]  R340      -1.5693485736846924e+00
    phi[0,6]  R341      -1.2245109081268311e+00
    phi[0,6]  R342      -1.2315701246261597e+00
    phi[0,6]  R343      -8.1658661365509033e-01
    phi[0,6]  R344      -1.6453791856765747e+00
    phi[0,6]  R345      5.2375149726867676e-01
    phi[0,6]  R346      3.4715652465820312e-02
    phi[0,6]  R347      -0.393656462430954
    phi[0,6]  R348      -0.837851345539093
    phi[0,6]  R349      -1.2642073631286621e+00
    phi[0,6]  R350      -0.572843074798584
    phi[6,0]  R0        -1
    phi[6,0]  R54       1
    phi[6,0]  R55       1
    phi[6,0]  R351      -3.0999999046325684e+00
    phi[6,0]  R352      -3.0999999046325684e+00
    phi[6,0]  R353      -2.2400000095367432e+00
    phi[6,0]  R354      -2.2400000095367432e+00
    phi[6,0]  R355      -3.0999999046325684e+00
    phi[6,0]  R356      -3.0999999046325684e+00
    phi[6,0]  R357      -2.5699999332427979e+00
    phi[6,0]  R358      -2.5699999332427979e+00
    phi[6,0]  R359      -3.0999999046325684e+00
    phi[6,0]  R360      -3.0999999046325684e+00
    phi[6,0]  R361      -2.0899999141693115e+00
    phi[6,0]  R362      -2.0899999141693115e+00
    phi[6,0]  R363      -3.0999999046325684e+00
    phi[6,0]  R364      -3.0999999046325684e+00
    phi[6,0]  R365      -1.2000774145126343e+00
    phi[6,0]  R366      7.6394744217395782e-02
    phi[6,0]  R367      -3.2834053039550781e-01
    phi[6,0]  R368      4.7135055065155029e-01
    phi[6,0]  R369      -1.6203496456146240e+00
    phi[6,0]  R370      -1.1345604658126831e+00
    phi[6,0]  R371      -5.8417338132858276e-01
    phi[6,0]  R372      -1.6086968183517456e+00
    phi[6,0]  R373      -1.7797340154647827e+00
    phi[6,0]  R374      -8.2175695896148682e-01
    phi[6,0]  R375      9.2191642522811890e-01
    phi[6,0]  R376      1.1151922941207886e+00
    phi[6,0]  R377      1.1291612386703491e+00
    phi[6,0]  R378      1.8498758971691132e-01
    phi[6,0]  R379      -0.0330149382352829
    phi[6,0]  R380      2.2549942135810852e-01
    phi[6,0]  R381      7.5888383388519287e-01
    phi[6,0]  R382      0.5791015625
    phi[6,0]  R383      1.5948952734470367e-01
    phi[6,0]  R384      7.7515608072280884e-01
    phi[6,0]  R385      -1.3829548358917236e+00
    phi[6,0]  R386      6.3957124948501587e-01
    phi[6,0]  R387      0.272148996591568
    phi[6,0]  R388      -5.6983256340026855e-01
    phi[6,0]  R389      -0.798306405544281
    phi[6,0]  R390      -2.5867865085601807e+00
    phi[6,0]  R391      2.6694774627685547e-01
    phi[6,0]  R392      -1.5693485736846924e+00
    phi[6,0]  R393      -1.2245109081268311e+00
    phi[6,0]  R394      -1.2315701246261597e+00
    phi[6,0]  R395      -8.1658661365509033e-01
    phi[6,0]  R396      -1.6453791856765747e+00
    phi[6,0]  R397      5.2375149726867676e-01
    phi[6,0]  R398      3.4715652465820312e-02
    phi[6,0]  R399      -0.393656462430954
    phi[6,0]  R400      -0.837851345539093
    phi[6,0]  R401      -1.2642073631286621e+00
    phi[6,0]  R402      -0.572843074798584
    phi[6,0]  R403      6.1420863866806030e-01
    phi[6,0]  R404      2.3601818084716797e-01
    phi[6,0]  R405      -0.829688549041748
    phi[6,0]  R406      3.6119353771209717e-01
    phi[6,0]  R407      2.18823504447937
    phi[6,0]  R408      1.4160277843475342e+00
    phi[6,0]  R409      2.4606387615203857e+00
    phi[6,0]  R410      -4.0803134441375732e-01
    phi[6,0]  R411      -3.2883840799331665e-01
    phi[6,0]  R412      7.9813510179519653e-01
    phi[6,0]  R413      -2.3884730339050293e+00
    phi[6,0]  R414      -1.2303519248962402e+00
    phi[6,0]  R415      -1.0051811933517456e+00
    phi[6,0]  R416      -3.0394535064697266e+00
    phi[6,0]  R417      7.4292242527008057e-01
    phi[6,0]  R418      -5.0445932149887085e-01
    phi[6,0]  R419      5.2356988191604614e-01
    phi[6,0]  R420      4.1371476650238037e-01
    phi[6,0]  R421      -3.4451186656951904e+00
    phi[6,0]  R422      -9.3637472391128540e-01
    phi[6,0]  R423      1.3489143848419189e+00
    phi[6,0]  R424      1.2764499187469482e+00
    phi[6,0]  R425      2.2126228809356689e+00
    phi[6,0]  R426      7.7408677898347378e-03
    phi[6,0]  R427      -1.7040338516235352e+00
    phi[6,0]  R428      -1.2025427818298340e+00
    phi[6,0]  R429      -1.5311525762081146e-01
    phi[6,0]  R430      -3.8064828515052795e-01
    phi[6,0]  R431      4.6384176611900330e-01
    phi[6,0]  R432      -8.1952917575836182e-01
    phi[11,0]  R0        -1
    phi[11,0]  R2        2.7757293638096860e+00
    phi[11,0]  R3        -4.2087214755069824e-01
    phi[11,0]  R4        -2.2105519287514750e+00
    phi[11,0]  R5        1.3268337862095705e+00
    phi[11,0]  R6        -8.1658334906098728e-01
    phi[11,0]  R7        1.1729114418291071e+00
    phi[11,0]  R8        -2.8594992390950651e+00
    phi[11,0]  R99       1
    phi[11,0]  R433      -5.8757292684422548e+00
    phi[11,0]  R434      -3.2427054082288231e-01
    phi[11,0]  R435      -1.8191278619860449e+00
    phi[11,0]  R436      -2.6608721570874412e+00
    phi[11,0]  R437      -8.8944797588109337e-01
    phi[11,0]  R438      -5.3105518333840429e+00
    phi[11,0]  R439      -3.8968337194523683e+00
    phi[11,0]  R440      -1.2431661470332274e+00
    phi[11,0]  R441      -2.2834165555715811e+00
    phi[11,0]  R442      -3.9165832536935556e+00
    phi[11,0]  R443      -3.2629113559984186e+00
    phi[11,0]  R444      -9.1708847234020441e-01
    phi[11,0]  R445      -2.4050066553750327e-01
    phi[11,0]  R446      -5.9594991437276335e+00
    phi[11,0]  R447      -8.8146496175789624e-02
    phi[11,0]  R448      -1.3847132176504817e-01
    phi[11,0]  R449      -2.0332741659384945e-01
    phi[11,0]  R450      -1.5806549139574921e-01
    phi[11,0]  R451      -1.7759340308406024e-01
    phi[11,0]  R452      -1.8076198262001464e-01
    phi[11,0]  R453      -2.0218838532696637e-01
    phi[11,0]  R454      -2.3629864909076481e-01
    phi[11,0]  R455      -2.1659726117092237e-01
    phi[11,0]  R456      -1.4262060669105061e+00
    phi[11,0]  R457      -2.1432627688318995e-02
    phi[11,0]  R458      -3.5538448530469280e-02
    phi[11,0]  R459      -3.1403927442269719e-01
    phi[11,0]  R460      -3.5374966680475195e-01
    phi[11,0]  R461      -3.6605612692347744e-01
    phi[11,0]  R462      -3.6946478372869018e-01
    phi[11,0]  R463      -3.7322766868375357e-01
    phi[11,0]  R464      -3.7567020926197037e-01
    phi[11,0]  R465      -3.8160962654556307e-01
    phi[11,0]  R466      -3.9429049368361024e-01
    phi[11,0]  R467      -1.0411176734651750e-01
    phi[11,0]  R468      -1.4300739904635207e-01
    phi[11,0]  R469      -1.4595036778992920e-01
    phi[11,0]  R470      -1.8198085069622616e-01
    phi[11,0]  R471      -1.9429114187862462e-01
    phi[11,0]  R472      -2.0477005975716711e-01
    phi[11,0]  R473      -2.7842731562071471e-01
    phi[11,0]  R474      -2.8598409042829376e-01
    phi[11,0]  R475      -2.8843207487773581e-01
    phi[11,0]  R476      -2.9914895475073933e-01
    phi[1,2]  R9        1
    phi[1,2]  R10       1
    phi[1,2]  R18       -1
    phi[1,2]  R477      -3.0999999046325684e+00
    phi[1,2]  R478      -3.0999999046325684e+00
    phi[1,2]  R479      -2.2400000095367432e+00
    phi[1,2]  R480      -2.2400000095367432e+00
    phi[1,2]  R481      -3.0999999046325684e+00
    phi[1,2]  R482      -3.0999999046325684e+00
    phi[1,2]  R483      -2.5699999332427979e+00
    phi[1,2]  R484      -2.5699999332427979e+00
    phi[1,2]  R485      -3.0999999046325684e+00
    phi[1,2]  R486      -3.0999999046325684e+00
    phi[1,2]  R487      -2.0899999141693115e+00
    phi[1,2]  R488      -2.0899999141693115e+00
    phi[1,2]  R489      -3.0999999046325684e+00
    phi[1,2]  R490      -3.0999999046325684e+00
    phi[1,2]  R491      0.769594669342041
    phi[1,2]  R492      -1.9393916428089142e-01
    phi[1,2]  R493      1.2135676145553589e+00
    phi[1,2]  R494      1.6299352645874023e+00
    phi[1,2]  R495      2.0010981559753418e+00
    phi[1,2]  R496      3.4677308797836304e-01
    phi[1,2]  R497      -2.4178989231586456e-01
    phi[1,2]  R498      8.3364170789718628e-01
    phi[1,2]  R499      -2.0763878822326660e+00
    phi[1,2]  R500      2.0803032815456390e-01
    phi[1,2]  R501      -9.2347878217697144e-01
    phi[1,2]  R502      -3.4373199939727783e-01
    phi[1,2]  R503      -2.4745929241180420e+00
    phi[1,2]  R504      -1.1387202739715576e+00
    phi[1,2]  R505      -0.0653628557920456
    phi[1,2]  R506      -1.2615528106689453e+00
    phi[1,2]  R507      -4.4821199774742126e-01
    phi[1,2]  R508      1.4887821674346924e+00
    phi[1,2]  R509      -9.0812504291534424e-01
    phi[1,2]  R510      1.2436661869287491e-01
    phi[1,2]  R511      -5.7258868217468262e-01
    phi[1,2]  R512      -2.2813397645950317e-01
    phi[1,2]  R513      5.6813216209411621e-01
    phi[1,2]  R514      5.0398790836334229e-01
    phi[1,2]  R515      -1.3110557794570923e+00
    phi[1,2]  R516      2.2024348378181458e-01
    phi[1,2]  R517      -7.6936548948287964e-01
    phi[1,2]  R518      0.564054548740387
    phi[1,2]  R519      -2.9329255223274231e-01
    phi[1,2]  R520      8.5796231031417847e-01
    phi[1,2]  R521      5.3206443786621094e-01
    phi[1,2]  R522      -2.3512044548988342e-01
    phi[1,2]  R523      -0.583536684513092
    phi[1,2]  R524      1.6479954719543457e+00
    phi[1,2]  R525      2.2364013195037842e+00
    phi[1,2]  R526      7.8413039445877075e-01
    phi[1,2]  R527      4.5980289578437805e-02
    phi[1,2]  R528      -2.6858317852020264e+00
    phi[1,2]  R529      -3.1658583879470825e-01
    phi[1,2]  R530      -6.5313440561294556e-01
    phi[1,2]  R531      1.2310545353614410e+00
    phi[1,2]  R532      -4.2660751938819885e-01
    phi[1,2]  R533      -5.1529717445373535e-01
    phi[1,2]  R534      -7.8608697652816772e-01
    phi[1,2]  R535      5.4082566499710083e-01
    phi[1,2]  R536      3.0825096368789673e-01
    phi[1,2]  R537      6.1212128400802612e-01
    phi[1,2]  R538      -1.9281940162181854e-01
    phi[1,2]  R539      5.3257030248641968e-01
    phi[1,2]  R540      -1.4011867046356201e+00
    phi[1,2]  R541      -6.8209671974182129e-01
    phi[1,2]  R542      1.0432378053665161e+00
    phi[1,2]  R543      -3.5536005496978760e+00
    phi[1,2]  R544      -3.3736197948455811e+00
    phi[1,2]  R545      -4.3890887498855591e-01
    phi[1,2]  R546      -3.3417677879333496e-01
    phi[1,2]  R547      -6.6067975759506226e-01
    phi[1,2]  R548      -7.5779926776885986e-01
    phi[1,2]  R549      -1.0152648687362671e+00
    phi[1,2]  R550      -3.7297254800796509e-01
    phi[1,2]  R551      -1.0013577938079834e+00
    phi[1,2]  R552      2.7658793330192566e-01
    phi[1,2]  R553      -2.8884370326995850e+00
    phi[1,2]  R554      -2.7002401351928711e+00
    phi[1,2]  R555      -2.8892793655395508e+00
    phi[1,2]  R556      -2.2187216281890869e+00
    phi[2,1]  R9        -1
    phi[2,1]  R18       1
    phi[2,1]  R19       1
    phi[2,1]  R557      -3.0999999046325684e+00
    phi[2,1]  R558      -3.0999999046325684e+00
    phi[2,1]  R559      -2.2400000095367432e+00
    phi[2,1]  R560      -2.2400000095367432e+00
    phi[2,1]  R561      -3.0999999046325684e+00
    phi[2,1]  R562      -3.0999999046325684e+00
    phi[2,1]  R563      -2.5699999332427979e+00
    phi[2,1]  R564      -2.5699999332427979e+00
    phi[2,1]  R565      -3.0999999046325684e+00
    phi[2,1]  R566      -3.0999999046325684e+00
    phi[2,1]  R567      -2.0899999141693115e+00
    phi[2,1]  R568      -2.0899999141693115e+00
    phi[2,1]  R569      -3.0999999046325684e+00
    phi[2,1]  R570      -3.0999999046325684e+00
    phi[2,1]  R571      1.2310545353614410e+00
    phi[2,1]  R572      -4.2660751938819885e-01
    phi[2,1]  R573      -5.1529717445373535e-01
    phi[2,1]  R574      -7.8608697652816772e-01
    phi[2,1]  R575      5.4082566499710083e-01
    phi[2,1]  R576      3.0825096368789673e-01
    phi[2,1]  R577      6.1212128400802612e-01
    phi[2,1]  R578      -1.9281940162181854e-01
    phi[2,1]  R579      5.3257030248641968e-01
    phi[2,1]  R580      -1.4011867046356201e+00
    phi[2,1]  R581      -6.8209671974182129e-01
    phi[2,1]  R582      1.0432378053665161e+00
    phi[2,1]  R583      -3.5536005496978760e+00
    phi[2,1]  R584      -3.3736197948455811e+00
    phi[2,1]  R585      -4.3890887498855591e-01
    phi[2,1]  R586      -3.3417677879333496e-01
    phi[2,1]  R587      -6.6067975759506226e-01
    phi[2,1]  R588      -7.5779926776885986e-01
    phi[2,1]  R589      -1.0152648687362671e+00
    phi[2,1]  R590      -3.7297254800796509e-01
    phi[2,1]  R591      -1.0013577938079834e+00
    phi[2,1]  R592      2.7658793330192566e-01
    phi[2,1]  R593      -2.8884370326995850e+00
    phi[2,1]  R594      -2.7002401351928711e+00
    phi[2,1]  R595      -2.8892793655395508e+00
    phi[2,1]  R596      -2.2187216281890869e+00
    phi[2,1]  R597      0.769594669342041
    phi[2,1]  R598      -1.9393916428089142e-01
    phi[2,1]  R599      1.2135676145553589e+00
    phi[2,1]  R600      1.6299352645874023e+00
    phi[2,1]  R601      2.0010981559753418e+00
    phi[2,1]  R602      3.4677308797836304e-01
    phi[2,1]  R603      -2.4178989231586456e-01
    phi[2,1]  R604      8.3364170789718628e-01
    phi[2,1]  R605      -2.0763878822326660e+00
    phi[2,1]  R606      2.0803032815456390e-01
    phi[2,1]  R607      -9.2347878217697144e-01
    phi[2,1]  R608      -3.4373199939727783e-01
    phi[2,1]  R609      -2.4745929241180420e+00
    phi[2,1]  R610      -1.1387202739715576e+00
    phi[2,1]  R611      -0.0653628557920456
    phi[2,1]  R612      -1.2615528106689453e+00
    phi[2,1]  R613      -4.4821199774742126e-01
    phi[2,1]  R614      1.4887821674346924e+00
    phi[2,1]  R615      -9.0812504291534424e-01
    phi[2,1]  R616      1.2436661869287491e-01
    phi[2,1]  R617      -5.7258868217468262e-01
    phi[2,1]  R618      -2.2813397645950317e-01
    phi[2,1]  R619      5.6813216209411621e-01
    phi[2,1]  R620      5.0398790836334229e-01
    phi[2,1]  R621      -1.3110557794570923e+00
    phi[2,1]  R622      2.2024348378181458e-01
    phi[2,1]  R623      -7.6936548948287964e-01
    phi[2,1]  R624      0.564054548740387
    phi[2,1]  R625      -2.9329255223274231e-01
    phi[2,1]  R626      8.5796231031417847e-01
    phi[2,1]  R627      5.3206443786621094e-01
    phi[2,1]  R628      -2.3512044548988342e-01
    phi[2,1]  R629      -0.583536684513092
    phi[2,1]  R630      1.6479954719543457e+00
    phi[2,1]  R631      2.2364013195037842e+00
    phi[2,1]  R632      7.8413039445877075e-01
    phi[2,1]  R633      4.5980289578437805e-02
    phi[2,1]  R634      -2.6858317852020264e+00
    phi[2,1]  R635      -3.1658583879470825e-01
    phi[2,1]  R636      -6.5313440561294556e-01
    phi[1,6]  R9        1
    phi[1,6]  R10       1
    phi[1,6]  R54       -1
    phi[1,6]  R637      -3.0999999046325684e+00
    phi[1,6]  R638      -3.0999999046325684e+00
    phi[1,6]  R639      -2.2400000095367432e+00
    phi[1,6]  R640      -2.2400000095367432e+00
    phi[1,6]  R641      -3.0999999046325684e+00
    phi[1,6]  R642      -3.0999999046325684e+00
    phi[1,6]  R643      -2.5699999332427979e+00
    phi[1,6]  R644      -2.5699999332427979e+00
    phi[1,6]  R645      -3.0999999046325684e+00
    phi[1,6]  R646      -3.0999999046325684e+00
    phi[1,6]  R647      -2.0899999141693115e+00
    phi[1,6]  R648      -2.0899999141693115e+00
    phi[1,6]  R649      -3.0999999046325684e+00
    phi[1,6]  R650      -3.0999999046325684e+00
    phi[1,6]  R651      0.769594669342041
    phi[1,6]  R652      -1.9393916428089142e-01
    phi[1,6]  R653      1.2135676145553589e+00
    phi[1,6]  R654      1.6299352645874023e+00
    phi[1,6]  R655      2.0010981559753418e+00
    phi[1,6]  R656      3.4677308797836304e-01
    phi[1,6]  R657      -2.4178989231586456e-01
    phi[1,6]  R658      8.3364170789718628e-01
    phi[1,6]  R659      -2.0763878822326660e+00
    phi[1,6]  R660      2.0803032815456390e-01
    phi[1,6]  R661      -9.2347878217697144e-01
    phi[1,6]  R662      -3.4373199939727783e-01
    phi[1,6]  R663      -2.4745929241180420e+00
    phi[1,6]  R664      -1.1387202739715576e+00
    phi[1,6]  R665      -0.0653628557920456
    phi[1,6]  R666      -1.2615528106689453e+00
    phi[1,6]  R667      -4.4821199774742126e-01
    phi[1,6]  R668      1.4887821674346924e+00
    phi[1,6]  R669      -9.0812504291534424e-01
    phi[1,6]  R670      1.2436661869287491e-01
    phi[1,6]  R671      -5.7258868217468262e-01
    phi[1,6]  R672      -2.2813397645950317e-01
    phi[1,6]  R673      5.6813216209411621e-01
    phi[1,6]  R674      5.0398790836334229e-01
    phi[1,6]  R675      -1.3110557794570923e+00
    phi[1,6]  R676      2.2024348378181458e-01
    phi[1,6]  R677      -7.6936548948287964e-01
    phi[1,6]  R678      0.564054548740387
    phi[1,6]  R679      -2.9329255223274231e-01
    phi[1,6]  R680      8.5796231031417847e-01
    phi[1,6]  R681      5.3206443786621094e-01
    phi[1,6]  R682      -2.3512044548988342e-01
    phi[1,6]  R683      -0.583536684513092
    phi[1,6]  R684      1.6479954719543457e+00
    phi[1,6]  R685      2.2364013195037842e+00
    phi[1,6]  R686      7.8413039445877075e-01
    phi[1,6]  R687      4.5980289578437805e-02
    phi[1,6]  R688      -2.6858317852020264e+00
    phi[1,6]  R689      -3.1658583879470825e-01
    phi[1,6]  R690      -6.5313440561294556e-01
    phi[1,6]  R691      -1.2000774145126343e+00
    phi[1,6]  R692      7.6394744217395782e-02
    phi[1,6]  R693      -3.2834053039550781e-01
    phi[1,6]  R694      4.7135055065155029e-01
    phi[1,6]  R695      -1.6203496456146240e+00
    phi[1,6]  R696      -1.1345604658126831e+00
    phi[1,6]  R697      -5.8417338132858276e-01
    phi[1,6]  R698      -1.6086968183517456e+00
    phi[1,6]  R699      -1.7797340154647827e+00
    phi[1,6]  R700      -8.2175695896148682e-01
    phi[1,6]  R701      9.2191642522811890e-01
    phi[1,6]  R702      1.1151922941207886e+00
    phi[1,6]  R703      1.1291612386703491e+00
    phi[1,6]  R704      1.8498758971691132e-01
    phi[1,6]  R705      -0.0330149382352829
    phi[1,6]  R706      2.2549942135810852e-01
    phi[1,6]  R707      7.5888383388519287e-01
    phi[1,6]  R708      0.5791015625
    phi[1,6]  R709      1.5948952734470367e-01
    phi[1,6]  R710      7.7515608072280884e-01
    phi[1,6]  R711      -1.3829548358917236e+00
    phi[1,6]  R712      6.3957124948501587e-01
    phi[1,6]  R713      0.272148996591568
    phi[1,6]  R714      -5.6983256340026855e-01
    phi[1,6]  R715      -0.798306405544281
    phi[1,6]  R716      -2.5867865085601807e+00
    phi[1,6]  R717      2.6694774627685547e-01
    phi[1,6]  R718      -1.5693485736846924e+00
    phi[1,6]  R719      -1.2245109081268311e+00
    phi[1,6]  R720      -1.2315701246261597e+00
    phi[1,6]  R721      -8.1658661365509033e-01
    phi[1,6]  R722      -1.6453791856765747e+00
    phi[1,6]  R723      5.2375149726867676e-01
    phi[1,6]  R724      3.4715652465820312e-02
    phi[1,6]  R725      -0.393656462430954
    phi[1,6]  R726      -0.837851345539093
    phi[1,6]  R727      -1.2642073631286621e+00
    phi[1,6]  R728      -0.572843074798584
    phi[6,1]  R9        -1
    phi[6,1]  R54       1
    phi[6,1]  R55       1
    phi[6,1]  R729      -3.0999999046325684e+00
    phi[6,1]  R730      -3.0999999046325684e+00
    phi[6,1]  R731      -2.2400000095367432e+00
    phi[6,1]  R732      -2.2400000095367432e+00
    phi[6,1]  R733      -3.0999999046325684e+00
    phi[6,1]  R734      -3.0999999046325684e+00
    phi[6,1]  R735      -2.5699999332427979e+00
    phi[6,1]  R736      -2.5699999332427979e+00
    phi[6,1]  R737      -3.0999999046325684e+00
    phi[6,1]  R738      -3.0999999046325684e+00
    phi[6,1]  R739      -2.0899999141693115e+00
    phi[6,1]  R740      -2.0899999141693115e+00
    phi[6,1]  R741      -3.0999999046325684e+00
    phi[6,1]  R742      -3.0999999046325684e+00
    phi[6,1]  R743      -1.2000774145126343e+00
    phi[6,1]  R744      7.6394744217395782e-02
    phi[6,1]  R745      -3.2834053039550781e-01
    phi[6,1]  R746      4.7135055065155029e-01
    phi[6,1]  R747      -1.6203496456146240e+00
    phi[6,1]  R748      -1.1345604658126831e+00
    phi[6,1]  R749      -5.8417338132858276e-01
    phi[6,1]  R750      -1.6086968183517456e+00
    phi[6,1]  R751      -1.7797340154647827e+00
    phi[6,1]  R752      -8.2175695896148682e-01
    phi[6,1]  R753      9.2191642522811890e-01
    phi[6,1]  R754      1.1151922941207886e+00
    phi[6,1]  R755      1.1291612386703491e+00
    phi[6,1]  R756      1.8498758971691132e-01
    phi[6,1]  R757      -0.0330149382352829
    phi[6,1]  R758      2.2549942135810852e-01
    phi[6,1]  R759      7.5888383388519287e-01
    phi[6,1]  R760      0.5791015625
    phi[6,1]  R761      1.5948952734470367e-01
    phi[6,1]  R762      7.7515608072280884e-01
    phi[6,1]  R763      -1.3829548358917236e+00
    phi[6,1]  R764      6.3957124948501587e-01
    phi[6,1]  R765      0.272148996591568
    phi[6,1]  R766      -5.6983256340026855e-01
    phi[6,1]  R767      -0.798306405544281
    phi[6,1]  R768      -2.5867865085601807e+00
    phi[6,1]  R769      2.6694774627685547e-01
    phi[6,1]  R770      -1.5693485736846924e+00
    phi[6,1]  R771      -1.2245109081268311e+00
    phi[6,1]  R772      -1.2315701246261597e+00
    phi[6,1]  R773      -8.1658661365509033e-01
    phi[6,1]  R774      -1.6453791856765747e+00
    phi[6,1]  R775      5.2375149726867676e-01
    phi[6,1]  R776      3.4715652465820312e-02
    phi[6,1]  R777      -0.393656462430954
    phi[6,1]  R778      -0.837851345539093
    phi[6,1]  R779      -1.2642073631286621e+00
    phi[6,1]  R780      -0.572843074798584
    phi[6,1]  R781      0.769594669342041
    phi[6,1]  R782      -1.9393916428089142e-01
    phi[6,1]  R783      1.2135676145553589e+00
    phi[6,1]  R784      1.6299352645874023e+00
    phi[6,1]  R785      2.0010981559753418e+00
    phi[6,1]  R786      3.4677308797836304e-01
    phi[6,1]  R787      -2.4178989231586456e-01
    phi[6,1]  R788      8.3364170789718628e-01
    phi[6,1]  R789      -2.0763878822326660e+00
    phi[6,1]  R790      2.0803032815456390e-01
    phi[6,1]  R791      -9.2347878217697144e-01
    phi[6,1]  R792      -3.4373199939727783e-01
    phi[6,1]  R793      -2.4745929241180420e+00
    phi[6,1]  R794      -1.1387202739715576e+00
    phi[6,1]  R795      -0.0653628557920456
    phi[6,1]  R796      -1.2615528106689453e+00
    phi[6,1]  R797      -4.4821199774742126e-01
    phi[6,1]  R798      1.4887821674346924e+00
    phi[6,1]  R799      -9.0812504291534424e-01
    phi[6,1]  R800      1.2436661869287491e-01
    phi[6,1]  R801      -5.7258868217468262e-01
    phi[6,1]  R802      -2.2813397645950317e-01
    phi[6,1]  R803      5.6813216209411621e-01
    phi[6,1]  R804      5.0398790836334229e-01
    phi[6,1]  R805      -1.3110557794570923e+00
    phi[6,1]  R806      2.2024348378181458e-01
    phi[6,1]  R807      -7.6936548948287964e-01
    phi[6,1]  R808      0.564054548740387
    phi[6,1]  R809      -2.9329255223274231e-01
    phi[6,1]  R810      8.5796231031417847e-01
    phi[6,1]  R811      5.3206443786621094e-01
    phi[6,1]  R812      -2.3512044548988342e-01
    phi[6,1]  R813      -0.583536684513092
    phi[6,1]  R814      1.6479954719543457e+00
    phi[6,1]  R815      2.2364013195037842e+00
    phi[6,1]  R816      7.8413039445877075e-01
    phi[6,1]  R817      4.5980289578437805e-02
    phi[6,1]  R818      -2.6858317852020264e+00
    phi[6,1]  R819      -3.1658583879470825e-01
    phi[6,1]  R820      -6.5313440561294556e-01
    phi[2,3]  R18       1
    phi[2,3]  R19       1
    phi[2,3]  R27       -1
    phi[2,3]  R821      -3.0999999046325684e+00
    phi[2,3]  R822      -3.0999999046325684e+00
    phi[2,3]  R823      -2.2400000095367432e+00
    phi[2,3]  R824      -2.2400000095367432e+00
    phi[2,3]  R825      -3.0999999046325684e+00
    phi[2,3]  R826      -3.0999999046325684e+00
    phi[2,3]  R827      -2.5699999332427979e+00
    phi[2,3]  R828      -2.5699999332427979e+00
    phi[2,3]  R829      -3.0999999046325684e+00
    phi[2,3]  R830      -3.0999999046325684e+00
    phi[2,3]  R831      -2.0899999141693115e+00
    phi[2,3]  R832      -2.0899999141693115e+00
    phi[2,3]  R833      -3.0999999046325684e+00
    phi[2,3]  R834      -3.0999999046325684e+00
    phi[2,3]  R835      1.2310545353614410e+00
    phi[2,3]  R836      -4.2660751938819885e-01
    phi[2,3]  R837      -5.1529717445373535e-01
    phi[2,3]  R838      -7.8608697652816772e-01
    phi[2,3]  R839      5.4082566499710083e-01
    phi[2,3]  R840      3.0825096368789673e-01
    phi[2,3]  R841      6.1212128400802612e-01
    phi[2,3]  R842      -1.9281940162181854e-01
    phi[2,3]  R843      5.3257030248641968e-01
    phi[2,3]  R844      -1.4011867046356201e+00
    phi[2,3]  R845      -6.8209671974182129e-01
    phi[2,3]  R846      1.0432378053665161e+00
    phi[2,3]  R847      -3.5536005496978760e+00
    phi[2,3]  R848      -3.3736197948455811e+00
    phi[2,3]  R849      -4.3890887498855591e-01
    phi[2,3]  R850      -3.3417677879333496e-01
    phi[2,3]  R851      -6.6067975759506226e-01
    phi[2,3]  R852      -7.5779926776885986e-01
    phi[2,3]  R853      -1.0152648687362671e+00
    phi[2,3]  R854      -3.7297254800796509e-01
    phi[2,3]  R855      -1.0013577938079834e+00
    phi[2,3]  R856      2.7658793330192566e-01
    phi[2,3]  R857      -2.8884370326995850e+00
    phi[2,3]  R858      -2.7002401351928711e+00
    phi[2,3]  R859      -2.8892793655395508e+00
    phi[2,3]  R860      -2.2187216281890869e+00
    phi[2,3]  R861      1.1245168447494507e+00
    phi[2,3]  R862      1.3705422878265381e+00
    phi[2,3]  R863      6.1865699291229248e-01
    phi[2,3]  R864      3.5505667328834534e-01
    phi[2,3]  R865      1.7609401941299438e+00
    phi[2,3]  R866      7.0966565608978271e-01
    phi[2,3]  R867      -4.1283674538135529e-02
    phi[2,3]  R868      1.2079639434814453e+00
    phi[2,3]  R869      1.1907115578651428e-02
    phi[2,3]  R870      9.8042297363281250e-01
    phi[2,3]  R871      -2.5868151187896729e+00
    phi[2,3]  R872      -2.3902928829193115e+00
    phi[2,3]  R873      -3.2469089031219482e+00
    phi[2,3]  R874      -2.2661252021789551e+00
    phi[2,3]  R875      -3.2714066505432129e+00
    phi[2,3]  R876      -3.7843976020812988e+00
    phi[2,3]  R877      -1.2156298160552979e+00
    phi[2,3]  R878      -3.1105821132659912e+00
    phi[2,3]  R879      -1.8295704126358032e+00
    phi[2,3]  R880      -1.1534672975540161e+00
    phi[2,3]  R881      -1.4061951637268066e+00
    phi[2,3]  R882      -2.3750448226928711e+00
    phi[2,3]  R883      -3.1225843429565430e+00
    phi[2,3]  R884      -2.1250400543212891e+00
    phi[2,3]  R885      -2.4099812507629395e+00
    phi[2,3]  R886      -2.0018105506896973e+00
    phi[2,3]  R887      -1.4014385938644409e+00
    phi[2,3]  R888      -1.8076063394546509e+00
    phi[2,3]  R889      -1.0753300189971924e+00
    phi[2,3]  R890      -1.9774589538574219e+00
    phi[2,3]  R891      -2.0257556438446045e+00
    phi[2,3]  R892      -1.3788100481033325e+00
    phi[2,3]  R893      -4.4246658682823181e-01
    phi[2,3]  R894      -2.1912325918674469e-01
    phi[2,3]  R895      0.733794093132019
    phi[2,3]  R896      1.0688645839691162e+00
    phi[2,3]  R897      1.1749680042266846e+00
    phi[2,3]  R898      -1.5750349760055542e+00
    phi[3,2]  R18       -1
    phi[3,2]  R27       1
    phi[3,2]  R28       1
    phi[3,2]  R899      -3.0999999046325684e+00
    phi[3,2]  R900      -3.0999999046325684e+00
    phi[3,2]  R901      -2.2400000095367432e+00
    phi[3,2]  R902      -2.2400000095367432e+00
    phi[3,2]  R903      -3.0999999046325684e+00
    phi[3,2]  R904      -3.0999999046325684e+00
    phi[3,2]  R905      -2.5699999332427979e+00
    phi[3,2]  R906      -2.5699999332427979e+00
    phi[3,2]  R907      -3.0999999046325684e+00
    phi[3,2]  R908      -3.0999999046325684e+00
    phi[3,2]  R909      -2.0899999141693115e+00
    phi[3,2]  R910      -2.0899999141693115e+00
    phi[3,2]  R911      -3.0999999046325684e+00
    phi[3,2]  R912      -3.0999999046325684e+00
    phi[3,2]  R913      1.1245168447494507e+00
    phi[3,2]  R914      1.3705422878265381e+00
    phi[3,2]  R915      6.1865699291229248e-01
    phi[3,2]  R916      3.5505667328834534e-01
    phi[3,2]  R917      1.7609401941299438e+00
    phi[3,2]  R918      7.0966565608978271e-01
    phi[3,2]  R919      -4.1283674538135529e-02
    phi[3,2]  R920      1.2079639434814453e+00
    phi[3,2]  R921      1.1907115578651428e-02
    phi[3,2]  R922      9.8042297363281250e-01
    phi[3,2]  R923      -2.5868151187896729e+00
    phi[3,2]  R924      -2.3902928829193115e+00
    phi[3,2]  R925      -3.2469089031219482e+00
    phi[3,2]  R926      -2.2661252021789551e+00
    phi[3,2]  R927      -3.2714066505432129e+00
    phi[3,2]  R928      -3.7843976020812988e+00
    phi[3,2]  R929      -1.2156298160552979e+00
    phi[3,2]  R930      -3.1105821132659912e+00
    phi[3,2]  R931      -1.8295704126358032e+00
    phi[3,2]  R932      -1.1534672975540161e+00
    phi[3,2]  R933      -1.4061951637268066e+00
    phi[3,2]  R934      -2.3750448226928711e+00
    phi[3,2]  R935      -3.1225843429565430e+00
    phi[3,2]  R936      -2.1250400543212891e+00
    phi[3,2]  R937      -2.4099812507629395e+00
    phi[3,2]  R938      -2.0018105506896973e+00
    phi[3,2]  R939      -1.4014385938644409e+00
    phi[3,2]  R940      -1.8076063394546509e+00
    phi[3,2]  R941      -1.0753300189971924e+00
    phi[3,2]  R942      -1.9774589538574219e+00
    phi[3,2]  R943      -2.0257556438446045e+00
    phi[3,2]  R944      -1.3788100481033325e+00
    phi[3,2]  R945      -4.4246658682823181e-01
    phi[3,2]  R946      -2.1912325918674469e-01
    phi[3,2]  R947      0.733794093132019
    phi[3,2]  R948      1.0688645839691162e+00
    phi[3,2]  R949      1.1749680042266846e+00
    phi[3,2]  R950      -1.5750349760055542e+00
    phi[3,2]  R951      1.2310545353614410e+00
    phi[3,2]  R952      -4.2660751938819885e-01
    phi[3,2]  R953      -5.1529717445373535e-01
    phi[3,2]  R954      -7.8608697652816772e-01
    phi[3,2]  R955      5.4082566499710083e-01
    phi[3,2]  R956      3.0825096368789673e-01
    phi[3,2]  R957      6.1212128400802612e-01
    phi[3,2]  R958      -1.9281940162181854e-01
    phi[3,2]  R959      5.3257030248641968e-01
    phi[3,2]  R960      -1.4011867046356201e+00
    phi[3,2]  R961      -6.8209671974182129e-01
    phi[3,2]  R962      1.0432378053665161e+00
    phi[3,2]  R963      -3.5536005496978760e+00
    phi[3,2]  R964      -3.3736197948455811e+00
    phi[3,2]  R965      -4.3890887498855591e-01
    phi[3,2]  R966      -3.3417677879333496e-01
    phi[3,2]  R967      -6.6067975759506226e-01
    phi[3,2]  R968      -7.5779926776885986e-01
    phi[3,2]  R969      -1.0152648687362671e+00
    phi[3,2]  R970      -3.7297254800796509e-01
    phi[3,2]  R971      -1.0013577938079834e+00
    phi[3,2]  R972      2.7658793330192566e-01
    phi[3,2]  R973      -2.8884370326995850e+00
    phi[3,2]  R974      -2.7002401351928711e+00
    phi[3,2]  R975      -2.8892793655395508e+00
    phi[3,2]  R976      -2.2187216281890869e+00
    phi[3,4]  R27       1
    phi[3,4]  R28       1
    phi[3,4]  R36       -1
    phi[3,4]  R977      -3.0999999046325684e+00
    phi[3,4]  R978      -3.0999999046325684e+00
    phi[3,4]  R979      -2.2400000095367432e+00
    phi[3,4]  R980      -2.2400000095367432e+00
    phi[3,4]  R981      -3.0999999046325684e+00
    phi[3,4]  R982      -3.0999999046325684e+00
    phi[3,4]  R983      -2.5699999332427979e+00
    phi[3,4]  R984      -2.5699999332427979e+00
    phi[3,4]  R985      -3.0999999046325684e+00
    phi[3,4]  R986      -3.0999999046325684e+00
    phi[3,4]  R987      -2.0899999141693115e+00
    phi[3,4]  R988      -2.0899999141693115e+00
    phi[3,4]  R989      -3.0999999046325684e+00
    phi[3,4]  R990      -3.0999999046325684e+00
    phi[3,4]  R991      1.1245168447494507e+00
    phi[3,4]  R992      1.3705422878265381e+00
    phi[3,4]  R993      6.1865699291229248e-01
    phi[3,4]  R994      3.5505667328834534e-01
    phi[3,4]  R995      1.7609401941299438e+00
    phi[3,4]  R996      7.0966565608978271e-01
    phi[3,4]  R997      -4.1283674538135529e-02
    phi[3,4]  R998      1.2079639434814453e+00
    phi[3,4]  R999      1.1907115578651428e-02
    phi[3,4]  R1000     9.8042297363281250e-01
    phi[3,4]  R1001     -2.5868151187896729e+00
    phi[3,4]  R1002     -2.3902928829193115e+00
    phi[3,4]  R1003     -3.2469089031219482e+00
    phi[3,4]  R1004     -2.2661252021789551e+00
    phi[3,4]  R1005     -3.2714066505432129e+00
    phi[3,4]  R1006     -3.7843976020812988e+00
    phi[3,4]  R1007     -1.2156298160552979e+00
    phi[3,4]  R1008     -3.1105821132659912e+00
    phi[3,4]  R1009     -1.8295704126358032e+00
    phi[3,4]  R1010     -1.1534672975540161e+00
    phi[3,4]  R1011     -1.4061951637268066e+00
    phi[3,4]  R1012     -2.3750448226928711e+00
    phi[3,4]  R1013     -3.1225843429565430e+00
    phi[3,4]  R1014     -2.1250400543212891e+00
    phi[3,4]  R1015     -2.4099812507629395e+00
    phi[3,4]  R1016     -2.0018105506896973e+00
    phi[3,4]  R1017     -1.4014385938644409e+00
    phi[3,4]  R1018     -1.8076063394546509e+00
    phi[3,4]  R1019     -1.0753300189971924e+00
    phi[3,4]  R1020     -1.9774589538574219e+00
    phi[3,4]  R1021     -2.0257556438446045e+00
    phi[3,4]  R1022     -1.3788100481033325e+00
    phi[3,4]  R1023     -4.4246658682823181e-01
    phi[3,4]  R1024     -2.1912325918674469e-01
    phi[3,4]  R1025     0.733794093132019
    phi[3,4]  R1026     1.0688645839691162e+00
    phi[3,4]  R1027     1.1749680042266846e+00
    phi[3,4]  R1028     -1.5750349760055542e+00
    phi[3,4]  R1029     1.9018359184265137e+00
    phi[3,4]  R1030     3.0847003459930420e+00
    phi[3,4]  R1031     1.8388348817825317e+00
    phi[3,4]  R1032     1.3834429979324341e+00
    phi[3,4]  R1033     -1.2618395686149597e-01
    phi[3,4]  R1034     1.5433218479156494e+00
    phi[3,4]  R1035     1.5392067432403564e+00
    phi[3,4]  R1036     8.6729669570922852e-01
    phi[3,4]  R1037     1.4790722131729126e+00
    phi[3,4]  R1038     1.6708310842514038e+00
    phi[3,4]  R1039     -2.4661645889282227e+00
    phi[3,4]  R1040     -1.3489416837692261e+00
    phi[3,4]  R1041     -1.4103877544403076e+00
    phi[3,4]  R1042     -1.6669409275054932e+00
    phi[3,4]  R1043     -2.0319066047668457e+00
    phi[3,4]  R1044     -1.4539289474487305e+00
    phi[3,4]  R1045     -1.0019844770431519e+00
    phi[3,4]  R1046     -2.5765342712402344e+00
    phi[3,4]  R1047     -1.0681210756301880e+00
    phi[3,4]  R1048     9.2929857969284058e-01
    phi[3,4]  R1049     -1.6385555267333984e+00
    phi[3,4]  R1050     -2.8422701358795166e+00
    phi[3,4]  R1051     6.6069555282592773e-01
    phi[3,4]  R1052     1.3726069927215576e+00
    phi[3,4]  R1053     1.1591323465108871e-01
    phi[3,4]  R1054     1.9424885511398315e+00
    phi[3,4]  R1055     1.6223173141479492e+00
    phi[3,4]  R1056     2.0892393589019775e+00
    phi[3,4]  R1057     1.3054805994033813e-01
    phi[3,4]  R1058     3.6953002214431763e-01
    phi[3,4]  R1059     -1.0339752435684204e+00
    phi[3,4]  R1060     -1.9395371675491333e+00
    phi[3,4]  R1061     -3.0857594013214111e+00
    phi[3,4]  R1062     -7.6785135269165039e-01
    phi[3,4]  R1063     -2.8854753971099854e+00
    phi[3,4]  R1064     1.34197199344635
    phi[3,4]  R1065     1.6343970298767090e+00
    phi[3,4]  R1066     1.5368472337722778e+00
    phi[3,4]  R1067     7.0690184831619263e-01
    phi[3,4]  R1068     2.0608010292053223e+00
    phi[3,4]  R1069     1.8067771196365356e+00
    phi[3,4]  R1070     5.6711488962173462e-01
    phi[3,4]  R1071     2.4242296814918518e-01
    phi[3,4]  R1072     1.2731055021286011e+00
    phi[3,4]  R1073     1.6448679566383362e-01
    phi[3,4]  R1074     9.7318768501281738e-01
    phi[3,4]  R1075     1.2423642873764038e+00
    phi[3,4]  R1076     1.5575797557830811e+00
    phi[3,4]  R1077     1.3661350011825562e+00
    phi[3,4]  R1078     -2.7541634440422058e-01
    phi[4,3]  R27       -1
    phi[4,3]  R36       1
    phi[4,3]  R37       1
    phi[4,3]  R1079     -3.0999999046325684e+00
    phi[4,3]  R1080     -3.0999999046325684e+00
    phi[4,3]  R1081     -2.2400000095367432e+00
    phi[4,3]  R1082     -2.2400000095367432e+00
    phi[4,3]  R1083     -3.0999999046325684e+00
    phi[4,3]  R1084     -3.0999999046325684e+00
    phi[4,3]  R1085     -2.5699999332427979e+00
    phi[4,3]  R1086     -2.5699999332427979e+00
    phi[4,3]  R1087     -3.0999999046325684e+00
    phi[4,3]  R1088     -3.0999999046325684e+00
    phi[4,3]  R1089     -2.0899999141693115e+00
    phi[4,3]  R1090     -2.0899999141693115e+00
    phi[4,3]  R1091     -3.0999999046325684e+00
    phi[4,3]  R1092     -3.0999999046325684e+00
    phi[4,3]  R1093     1.9018359184265137e+00
    phi[4,3]  R1094     3.0847003459930420e+00
    phi[4,3]  R1095     1.8388348817825317e+00
    phi[4,3]  R1096     1.3834429979324341e+00
    phi[4,3]  R1097     -1.2618395686149597e-01
    phi[4,3]  R1098     1.5433218479156494e+00
    phi[4,3]  R1099     1.5392067432403564e+00
    phi[4,3]  R1100     8.6729669570922852e-01
    phi[4,3]  R1101     1.4790722131729126e+00
    phi[4,3]  R1102     1.6708310842514038e+00
    phi[4,3]  R1103     -2.4661645889282227e+00
    phi[4,3]  R1104     -1.3489416837692261e+00
    phi[4,3]  R1105     -1.4103877544403076e+00
    phi[4,3]  R1106     -1.6669409275054932e+00
    phi[4,3]  R1107     -2.0319066047668457e+00
    phi[4,3]  R1108     -1.4539289474487305e+00
    phi[4,3]  R1109     -1.0019844770431519e+00
    phi[4,3]  R1110     -2.5765342712402344e+00
    phi[4,3]  R1111     -1.0681210756301880e+00
    phi[4,3]  R1112     9.2929857969284058e-01
    phi[4,3]  R1113     -1.6385555267333984e+00
    phi[4,3]  R1114     -2.8422701358795166e+00
    phi[4,3]  R1115     6.6069555282592773e-01
    phi[4,3]  R1116     1.3726069927215576e+00
    phi[4,3]  R1117     1.1591323465108871e-01
    phi[4,3]  R1118     1.9424885511398315e+00
    phi[4,3]  R1119     1.6223173141479492e+00
    phi[4,3]  R1120     2.0892393589019775e+00
    phi[4,3]  R1121     1.3054805994033813e-01
    phi[4,3]  R1122     3.6953002214431763e-01
    phi[4,3]  R1123     -1.0339752435684204e+00
    phi[4,3]  R1124     -1.9395371675491333e+00
    phi[4,3]  R1125     -3.0857594013214111e+00
    phi[4,3]  R1126     -7.6785135269165039e-01
    phi[4,3]  R1127     -2.8854753971099854e+00
    phi[4,3]  R1128     1.34197199344635
    phi[4,3]  R1129     1.6343970298767090e+00
    phi[4,3]  R1130     1.5368472337722778e+00
    phi[4,3]  R1131     7.0690184831619263e-01
    phi[4,3]  R1132     2.0608010292053223e+00
    phi[4,3]  R1133     1.8067771196365356e+00
    phi[4,3]  R1134     5.6711488962173462e-01
    phi[4,3]  R1135     2.4242296814918518e-01
    phi[4,3]  R1136     1.2731055021286011e+00
    phi[4,3]  R1137     1.6448679566383362e-01
    phi[4,3]  R1138     9.7318768501281738e-01
    phi[4,3]  R1139     1.2423642873764038e+00
    phi[4,3]  R1140     1.5575797557830811e+00
    phi[4,3]  R1141     1.3661350011825562e+00
    phi[4,3]  R1142     -2.7541634440422058e-01
    phi[4,3]  R1143     1.1245168447494507e+00
    phi[4,3]  R1144     1.3705422878265381e+00
    phi[4,3]  R1145     6.1865699291229248e-01
    phi[4,3]  R1146     3.5505667328834534e-01
    phi[4,3]  R1147     1.7609401941299438e+00
    phi[4,3]  R1148     7.0966565608978271e-01
    phi[4,3]  R1149     -4.1283674538135529e-02
    phi[4,3]  R1150     1.2079639434814453e+00
    phi[4,3]  R1151     1.1907115578651428e-02
    phi[4,3]  R1152     9.8042297363281250e-01
    phi[4,3]  R1153     -2.5868151187896729e+00
    phi[4,3]  R1154     -2.3902928829193115e+00
    phi[4,3]  R1155     -3.2469089031219482e+00
    phi[4,3]  R1156     -2.2661252021789551e+00
    phi[4,3]  R1157     -3.2714066505432129e+00
    phi[4,3]  R1158     -3.7843976020812988e+00
    phi[4,3]  R1159     -1.2156298160552979e+00
    phi[4,3]  R1160     -3.1105821132659912e+00
    phi[4,3]  R1161     -1.8295704126358032e+00
    phi[4,3]  R1162     -1.1534672975540161e+00
    phi[4,3]  R1163     -1.4061951637268066e+00
    phi[4,3]  R1164     -2.3750448226928711e+00
    phi[4,3]  R1165     -3.1225843429565430e+00
    phi[4,3]  R1166     -2.1250400543212891e+00
    phi[4,3]  R1167     -2.4099812507629395e+00
    phi[4,3]  R1168     -2.0018105506896973e+00
    phi[4,3]  R1169     -1.4014385938644409e+00
    phi[4,3]  R1170     -1.8076063394546509e+00
    phi[4,3]  R1171     -1.0753300189971924e+00
    phi[4,3]  R1172     -1.9774589538574219e+00
    phi[4,3]  R1173     -2.0257556438446045e+00
    phi[4,3]  R1174     -1.3788100481033325e+00
    phi[4,3]  R1175     -4.4246658682823181e-01
    phi[4,3]  R1176     -2.1912325918674469e-01
    phi[4,3]  R1177     0.733794093132019
    phi[4,3]  R1178     1.0688645839691162e+00
    phi[4,3]  R1179     1.1749680042266846e+00
    phi[4,3]  R1180     -1.5750349760055542e+00
    phi[3,10]  R27       1
    phi[3,10]  R28       1
    phi[3,10]  R90       -1
    phi[3,10]  R1181     -3.0999999046325684e+00
    phi[3,10]  R1182     -3.0999999046325684e+00
    phi[3,10]  R1183     -2.2400000095367432e+00
    phi[3,10]  R1184     -2.2400000095367432e+00
    phi[3,10]  R1185     -3.0999999046325684e+00
    phi[3,10]  R1186     -3.0999999046325684e+00
    phi[3,10]  R1187     -2.5699999332427979e+00
    phi[3,10]  R1188     -2.5699999332427979e+00
    phi[3,10]  R1189     -3.0999999046325684e+00
    phi[3,10]  R1190     -3.0999999046325684e+00
    phi[3,10]  R1191     -2.0899999141693115e+00
    phi[3,10]  R1192     -2.0899999141693115e+00
    phi[3,10]  R1193     -3.0999999046325684e+00
    phi[3,10]  R1194     -3.0999999046325684e+00
    phi[3,10]  R1195     1.1245168447494507e+00
    phi[3,10]  R1196     1.3705422878265381e+00
    phi[3,10]  R1197     6.1865699291229248e-01
    phi[3,10]  R1198     3.5505667328834534e-01
    phi[3,10]  R1199     1.7609401941299438e+00
    phi[3,10]  R1200     7.0966565608978271e-01
    phi[3,10]  R1201     -4.1283674538135529e-02
    phi[3,10]  R1202     1.2079639434814453e+00
    phi[3,10]  R1203     1.1907115578651428e-02
    phi[3,10]  R1204     9.8042297363281250e-01
    phi[3,10]  R1205     -2.5868151187896729e+00
    phi[3,10]  R1206     -2.3902928829193115e+00
    phi[3,10]  R1207     -3.2469089031219482e+00
    phi[3,10]  R1208     -2.2661252021789551e+00
    phi[3,10]  R1209     -3.2714066505432129e+00
    phi[3,10]  R1210     -3.7843976020812988e+00
    phi[3,10]  R1211     -1.2156298160552979e+00
    phi[3,10]  R1212     -3.1105821132659912e+00
    phi[3,10]  R1213     -1.8295704126358032e+00
    phi[3,10]  R1214     -1.1534672975540161e+00
    phi[3,10]  R1215     -1.4061951637268066e+00
    phi[3,10]  R1216     -2.3750448226928711e+00
    phi[3,10]  R1217     -3.1225843429565430e+00
    phi[3,10]  R1218     -2.1250400543212891e+00
    phi[3,10]  R1219     -2.4099812507629395e+00
    phi[3,10]  R1220     -2.0018105506896973e+00
    phi[3,10]  R1221     -1.4014385938644409e+00
    phi[3,10]  R1222     -1.8076063394546509e+00
    phi[3,10]  R1223     -1.0753300189971924e+00
    phi[3,10]  R1224     -1.9774589538574219e+00
    phi[3,10]  R1225     -2.0257556438446045e+00
    phi[3,10]  R1226     -1.3788100481033325e+00
    phi[3,10]  R1227     -4.4246658682823181e-01
    phi[3,10]  R1228     -2.1912325918674469e-01
    phi[3,10]  R1229     0.733794093132019
    phi[3,10]  R1230     1.0688645839691162e+00
    phi[3,10]  R1231     1.1749680042266846e+00
    phi[3,10]  R1232     -1.5750349760055542e+00
    phi[3,10]  R1233     1.6034849882125854e+00
    phi[3,10]  R1234     1.8111655712127686e+00
    phi[3,10]  R1235     1.7019549608230591e+00
    phi[3,10]  R1236     9.8893636465072632e-01
    phi[3,10]  R1237     1.6807801723480225e+00
    phi[3,10]  R1238     1.5854493379592896e+00
    phi[3,10]  R1239     0.998877763748169
    phi[3,10]  R1240     1.8693864345550537e+00
    phi[3,10]  R1241     1.9732274115085602e-01
    phi[3,10]  R1242     1.1268581151962280e+00
    phi[3,10]  R1243     -2.33562970161438
    phi[3,10]  R1244     -2.3505096435546875e+00
    phi[3,10]  R1245     -1.5073122978210449e+00
    phi[3,10]  R1246     -7.0644193887710571e-01
    phi[3,10]  R1247     8.0909393727779388e-02
    phi[3,10]  R1248     -5.9340596199035645e-01
    phi[3,10]  R1249     -7.7890384197235107e-01
    phi[3,10]  R1250     -2.1858930587768555e+00
    phi[3,10]  R1251     -5.7323282957077026e-01
    phi[3,10]  R1252     -2.1939802169799805e+00
    phi[3,10]  R1253     -2.0164949893951416e+00
    phi[3,10]  R1254     -1.2315652370452881e+00
    phi[3,10]  R1255     -1.5021522045135498e+00
    phi[3,10]  R1256     -1.6575220823287964e+00
    phi[3,10]  R1257     -1.1053600311279297e+00
    phi[3,10]  R1258     9.0017179027199745e-03
    phi[3,10]  R1259     -1.3707969188690186e+00
    phi[3,10]  R1260     -2.5933270454406738e+00
    phi[3,10]  R1261     -1.6544564068317413e-01
    phi[3,10]  R1262     -8.1910967826843262e-01
    phi[3,10]  R1263     -9.7236263751983643e-01
    phi[3,10]  R1264     -2.1291913986206055e+00
    phi[3,10]  R1265     -2.7167298793792725e+00
    phi[3,10]  R1266     -1.7763613462448120e+00
    phi[3,10]  R1267     -2.5446350574493408e+00
    phi[3,10]  R1268     -1.8559244871139526e+00
    phi[3,10]  R1269     0.992651641368866
    phi[3,10]  R1270     1.4628553390502930e-01
    phi[3,10]  R1271     -1.0963987112045288e+00
    phi[3,10]  R1272     -2.83156681060791
    phi[10,3]  R27       -1
    phi[10,3]  R90       1
    phi[10,3]  R91       1
    phi[10,3]  R1273     -3.0999999046325684e+00
    phi[10,3]  R1274     -3.0999999046325684e+00
    phi[10,3]  R1275     -2.2400000095367432e+00
    phi[10,3]  R1276     -2.2400000095367432e+00
    phi[10,3]  R1277     -3.0999999046325684e+00
    phi[10,3]  R1278     -3.0999999046325684e+00
    phi[10,3]  R1279     -2.5699999332427979e+00
    phi[10,3]  R1280     -2.5699999332427979e+00
    phi[10,3]  R1281     -3.0999999046325684e+00
    phi[10,3]  R1282     -3.0999999046325684e+00
    phi[10,3]  R1283     -2.0899999141693115e+00
    phi[10,3]  R1284     -2.0899999141693115e+00
    phi[10,3]  R1285     -3.0999999046325684e+00
    phi[10,3]  R1286     -3.0999999046325684e+00
    phi[10,3]  R1287     1.6034849882125854e+00
    phi[10,3]  R1288     1.8111655712127686e+00
    phi[10,3]  R1289     1.7019549608230591e+00
    phi[10,3]  R1290     9.8893636465072632e-01
    phi[10,3]  R1291     1.6807801723480225e+00
    phi[10,3]  R1292     1.5854493379592896e+00
    phi[10,3]  R1293     0.998877763748169
    phi[10,3]  R1294     1.8693864345550537e+00
    phi[10,3]  R1295     1.9732274115085602e-01
    phi[10,3]  R1296     1.1268581151962280e+00
    phi[10,3]  R1297     -2.33562970161438
    phi[10,3]  R1298     -2.3505096435546875e+00
    phi[10,3]  R1299     -1.5073122978210449e+00
    phi[10,3]  R1300     -7.0644193887710571e-01
    phi[10,3]  R1301     8.0909393727779388e-02
    phi[10,3]  R1302     -5.9340596199035645e-01
    phi[10,3]  R1303     -7.7890384197235107e-01
    phi[10,3]  R1304     -2.1858930587768555e+00
    phi[10,3]  R1305     -5.7323282957077026e-01
    phi[10,3]  R1306     -2.1939802169799805e+00
    phi[10,3]  R1307     -2.0164949893951416e+00
    phi[10,3]  R1308     -1.2315652370452881e+00
    phi[10,3]  R1309     -1.5021522045135498e+00
    phi[10,3]  R1310     -1.6575220823287964e+00
    phi[10,3]  R1311     -1.1053600311279297e+00
    phi[10,3]  R1312     9.0017179027199745e-03
    phi[10,3]  R1313     -1.3707969188690186e+00
    phi[10,3]  R1314     -2.5933270454406738e+00
    phi[10,3]  R1315     -1.6544564068317413e-01
    phi[10,3]  R1316     -8.1910967826843262e-01
    phi[10,3]  R1317     -9.7236263751983643e-01
    phi[10,3]  R1318     -2.1291913986206055e+00
    phi[10,3]  R1319     -2.7167298793792725e+00
    phi[10,3]  R1320     -1.7763613462448120e+00
    phi[10,3]  R1321     -2.5446350574493408e+00
    phi[10,3]  R1322     -1.8559244871139526e+00
    phi[10,3]  R1323     0.992651641368866
    phi[10,3]  R1324     1.4628553390502930e-01
    phi[10,3]  R1325     -1.0963987112045288e+00
    phi[10,3]  R1326     -2.83156681060791
    phi[10,3]  R1327     1.1245168447494507e+00
    phi[10,3]  R1328     1.3705422878265381e+00
    phi[10,3]  R1329     6.1865699291229248e-01
    phi[10,3]  R1330     3.5505667328834534e-01
    phi[10,3]  R1331     1.7609401941299438e+00
    phi[10,3]  R1332     7.0966565608978271e-01
    phi[10,3]  R1333     -4.1283674538135529e-02
    phi[10,3]  R1334     1.2079639434814453e+00
    phi[10,3]  R1335     1.1907115578651428e-02
    phi[10,3]  R1336     9.8042297363281250e-01
    phi[10,3]  R1337     -2.5868151187896729e+00
    phi[10,3]  R1338     -2.3902928829193115e+00
    phi[10,3]  R1339     -3.2469089031219482e+00
    phi[10,3]  R1340     -2.2661252021789551e+00
    phi[10,3]  R1341     -3.2714066505432129e+00
    phi[10,3]  R1342     -3.7843976020812988e+00
    phi[10,3]  R1343     -1.2156298160552979e+00
    phi[10,3]  R1344     -3.1105821132659912e+00
    phi[10,3]  R1345     -1.8295704126358032e+00
    phi[10,3]  R1346     -1.1534672975540161e+00
    phi[10,3]  R1347     -1.4061951637268066e+00
    phi[10,3]  R1348     -2.3750448226928711e+00
    phi[10,3]  R1349     -3.1225843429565430e+00
    phi[10,3]  R1350     -2.1250400543212891e+00
    phi[10,3]  R1351     -2.4099812507629395e+00
    phi[10,3]  R1352     -2.0018105506896973e+00
    phi[10,3]  R1353     -1.4014385938644409e+00
    phi[10,3]  R1354     -1.8076063394546509e+00
    phi[10,3]  R1355     -1.0753300189971924e+00
    phi[10,3]  R1356     -1.9774589538574219e+00
    phi[10,3]  R1357     -2.0257556438446045e+00
    phi[10,3]  R1358     -1.3788100481033325e+00
    phi[10,3]  R1359     -4.4246658682823181e-01
    phi[10,3]  R1360     -2.1912325918674469e-01
    phi[10,3]  R1361     0.733794093132019
    phi[10,3]  R1362     1.0688645839691162e+00
    phi[10,3]  R1363     1.1749680042266846e+00
    phi[10,3]  R1364     -1.5750349760055542e+00
    phi[4,5]  R36       1
    phi[4,5]  R37       1
    phi[4,5]  R45       -1
    phi[4,5]  R1365     -3.0999999046325684e+00
    phi[4,5]  R1366     -3.0999999046325684e+00
    phi[4,5]  R1367     -2.2400000095367432e+00
    phi[4,5]  R1368     -2.2400000095367432e+00
    phi[4,5]  R1369     -3.0999999046325684e+00
    phi[4,5]  R1370     -3.0999999046325684e+00
    phi[4,5]  R1371     -2.5699999332427979e+00
    phi[4,5]  R1372     -2.5699999332427979e+00
    phi[4,5]  R1373     -3.0999999046325684e+00
    phi[4,5]  R1374     -3.0999999046325684e+00
    phi[4,5]  R1375     -2.0899999141693115e+00
    phi[4,5]  R1376     -2.0899999141693115e+00
    phi[4,5]  R1377     -3.0999999046325684e+00
    phi[4,5]  R1378     -3.0999999046325684e+00
    phi[4,5]  R1379     1.9018359184265137e+00
    phi[4,5]  R1380     3.0847003459930420e+00
    phi[4,5]  R1381     1.8388348817825317e+00
    phi[4,5]  R1382     1.3834429979324341e+00
    phi[4,5]  R1383     -1.2618395686149597e-01
    phi[4,5]  R1384     1.5433218479156494e+00
    phi[4,5]  R1385     1.5392067432403564e+00
    phi[4,5]  R1386     8.6729669570922852e-01
    phi[4,5]  R1387     1.4790722131729126e+00
    phi[4,5]  R1388     1.6708310842514038e+00
    phi[4,5]  R1389     -2.4661645889282227e+00
    phi[4,5]  R1390     -1.3489416837692261e+00
    phi[4,5]  R1391     -1.4103877544403076e+00
    phi[4,5]  R1392     -1.6669409275054932e+00
    phi[4,5]  R1393     -2.0319066047668457e+00
    phi[4,5]  R1394     -1.4539289474487305e+00
    phi[4,5]  R1395     -1.0019844770431519e+00
    phi[4,5]  R1396     -2.5765342712402344e+00
    phi[4,5]  R1397     -1.0681210756301880e+00
    phi[4,5]  R1398     9.2929857969284058e-01
    phi[4,5]  R1399     -1.6385555267333984e+00
    phi[4,5]  R1400     -2.8422701358795166e+00
    phi[4,5]  R1401     6.6069555282592773e-01
    phi[4,5]  R1402     1.3726069927215576e+00
    phi[4,5]  R1403     1.1591323465108871e-01
    phi[4,5]  R1404     1.9424885511398315e+00
    phi[4,5]  R1405     1.6223173141479492e+00
    phi[4,5]  R1406     2.0892393589019775e+00
    phi[4,5]  R1407     1.3054805994033813e-01
    phi[4,5]  R1408     3.6953002214431763e-01
    phi[4,5]  R1409     -1.0339752435684204e+00
    phi[4,5]  R1410     -1.9395371675491333e+00
    phi[4,5]  R1411     -3.0857594013214111e+00
    phi[4,5]  R1412     -7.6785135269165039e-01
    phi[4,5]  R1413     -2.8854753971099854e+00
    phi[4,5]  R1414     1.34197199344635
    phi[4,5]  R1415     1.6343970298767090e+00
    phi[4,5]  R1416     1.5368472337722778e+00
    phi[4,5]  R1417     7.0690184831619263e-01
    phi[4,5]  R1418     2.0608010292053223e+00
    phi[4,5]  R1419     1.8067771196365356e+00
    phi[4,5]  R1420     5.6711488962173462e-01
    phi[4,5]  R1421     2.4242296814918518e-01
    phi[4,5]  R1422     1.2731055021286011e+00
    phi[4,5]  R1423     1.6448679566383362e-01
    phi[4,5]  R1424     9.7318768501281738e-01
    phi[4,5]  R1425     1.2423642873764038e+00
    phi[4,5]  R1426     1.5575797557830811e+00
    phi[4,5]  R1427     1.3661350011825562e+00
    phi[4,5]  R1428     -2.7541634440422058e-01
    phi[4,5]  R1429     1.8534917831420898e+00
    phi[4,5]  R1430     1.6593371629714966e+00
    phi[4,5]  R1431     2.8860206604003906e+00
    phi[4,5]  R1432     1.4197844266891479e+00
    phi[4,5]  R1433     2.0377359390258789e+00
    phi[4,5]  R1434     6.7152154445648193e-01
    phi[4,5]  R1435     1.4975548982620239e+00
    phi[4,5]  R1436     1.3778889179229736e-01
    phi[4,5]  R1437     1.5425974130630493e+00
    phi[4,5]  R1438     1.4541543722152710e+00
    phi[4,5]  R1439     -3.0960981845855713e+00
    phi[4,5]  R1440     -2.1827669143676758e+00
    phi[4,5]  R1441     -8.0048608779907227e-01
    phi[4,5]  R1442     -1.3571000099182129e+00
    phi[4,5]  R1443     2.4038039147853851e-01
    phi[4,5]  R1444     -2.0418312549591064e+00
    phi[4,5]  R1445     -2.6407992839813232e+00
    phi[4,5]  R1446     2.6973348855972290e-01
    phi[4,5]  R1447     -0.722158670425415
    phi[4,5]  R1448     -1.4484599828720093e+00
    phi[4,5]  R1449     -2.4795104563236237e-01
    phi[4,5]  R1450     -1.8732820749282837e+00
    phi[4,5]  R1451     -2.4469952583312988e+00
    phi[4,5]  R1452     1.4724074304103851e-01
    phi[4,5]  R1453     -1.7001783847808838e+00
    phi[4,5]  R1454     -3.3636403083801270e-01
    phi[4,5]  R1455     -1.5076889991760254e+00
    phi[4,5]  R1456     -3.7944760918617249e-01
    phi[4,5]  R1457     5.8496010303497314e-01
    phi[4,5]  R1458     -3.7074224948883057e+00
    phi[4,5]  R1459     -1.6275030374526978e+00
    phi[4,5]  R1460     -2.0633904933929443e+00
    phi[4,5]  R1461     5.7452422380447388e-01
    phi[4,5]  R1462     -1.7635847330093384e+00
    phi[4,5]  R1463     -2.6194429397583008e+00
    phi[4,5]  R1464     -1.4235118627548218e+00
    phi[4,5]  R1465     -6.7739951610565186e-01
    phi[4,5]  R1466     -3.8163475990295410e+00
    phi[4,5]  R1467     1.2651060819625854e+00
    phi[4,5]  R1468     -2.9751892089843750e+00
    phi[4,5]  R1469     -2.4501986503601074e+00
    phi[4,5]  R1470     1.1450688838958740e+00
    phi[4,5]  R1471     -1.6549209356307983e+00
    phi[4,5]  R1472     -8.5084551572799683e-01
    phi[4,5]  R1473     -2.1219222545623779e+00
    phi[4,5]  R1474     1.4005815982818604e+00
    phi[4,5]  R1475     3.3646366000175476e-01
    phi[4,5]  R1476     -1.7390252351760864e+00
    phi[4,5]  R1477     -5.9953290224075317e-01
    phi[4,5]  R1478     -6.2929445505142212e-01
    phi[4,5]  R1479     -3.1908670067787170e-01
    phi[4,5]  R1480     -8.8155007362365723e-01
    phi[4,5]  R1481     -1.6440087556838989e+00
    phi[4,5]  R1482     5.8588665723800659e-01
    phi[4,5]  R1483     -1.5716205835342407e+00
    phi[4,5]  R1484     1.7947614192962646e-01
    phi[4,5]  R1485     1.2271775007247925e+00
    phi[4,5]  R1486     1.1366326808929443e+00
    phi[4,5]  R1487     -2.2286663055419922e+00
    phi[4,5]  R1488     -1.5743334293365479e+00
    phi[4,5]  R1489     -2.5062568187713623e+00
    phi[4,5]  R1490     -7.1013665199279785e-01
    phi[4,5]  R1491     -6.4006870985031128e-01
    phi[4,5]  R1492     0.265857070684433
    phi[4,5]  R1493     -2.4915981292724609e+00
    phi[4,5]  R1494     -1.2369996309280396e+00
    phi[4,5]  R1495     2.6607219129800797e-02
    phi[4,5]  R1496     -2.8346905708312988e+00
    phi[4,5]  R1497     -1.2430933862924576e-01
    phi[4,5]  R1498     -2.1551117897033691e+00
    phi[5,4]  R36       -1
    phi[5,4]  R45       1
    phi[5,4]  R46       1
    phi[5,4]  R1499     -3.0999999046325684e+00
    phi[5,4]  R1500     -3.0999999046325684e+00
    phi[5,4]  R1501     -2.2400000095367432e+00
    phi[5,4]  R1502     -2.2400000095367432e+00
    phi[5,4]  R1503     -3.0999999046325684e+00
    phi[5,4]  R1504     -3.0999999046325684e+00
    phi[5,4]  R1505     -2.5699999332427979e+00
    phi[5,4]  R1506     -2.5699999332427979e+00
    phi[5,4]  R1507     -3.0999999046325684e+00
    phi[5,4]  R1508     -3.0999999046325684e+00
    phi[5,4]  R1509     -2.0899999141693115e+00
    phi[5,4]  R1510     -2.0899999141693115e+00
    phi[5,4]  R1511     -3.0999999046325684e+00
    phi[5,4]  R1512     -3.0999999046325684e+00
    phi[5,4]  R1513     1.8534917831420898e+00
    phi[5,4]  R1514     1.6593371629714966e+00
    phi[5,4]  R1515     2.8860206604003906e+00
    phi[5,4]  R1516     1.4197844266891479e+00
    phi[5,4]  R1517     2.0377359390258789e+00
    phi[5,4]  R1518     6.7152154445648193e-01
    phi[5,4]  R1519     1.4975548982620239e+00
    phi[5,4]  R1520     1.3778889179229736e-01
    phi[5,4]  R1521     1.5425974130630493e+00
    phi[5,4]  R1522     1.4541543722152710e+00
    phi[5,4]  R1523     -3.0960981845855713e+00
    phi[5,4]  R1524     -2.1827669143676758e+00
    phi[5,4]  R1525     -8.0048608779907227e-01
    phi[5,4]  R1526     -1.3571000099182129e+00
    phi[5,4]  R1527     2.4038039147853851e-01
    phi[5,4]  R1528     -2.0418312549591064e+00
    phi[5,4]  R1529     -2.6407992839813232e+00
    phi[5,4]  R1530     2.6973348855972290e-01
    phi[5,4]  R1531     -0.722158670425415
    phi[5,4]  R1532     -1.4484599828720093e+00
    phi[5,4]  R1533     -2.4795104563236237e-01
    phi[5,4]  R1534     -1.8732820749282837e+00
    phi[5,4]  R1535     -2.4469952583312988e+00
    phi[5,4]  R1536     1.4724074304103851e-01
    phi[5,4]  R1537     -1.7001783847808838e+00
    phi[5,4]  R1538     -3.3636403083801270e-01
    phi[5,4]  R1539     -1.5076889991760254e+00
    phi[5,4]  R1540     -3.7944760918617249e-01
    phi[5,4]  R1541     5.8496010303497314e-01
    phi[5,4]  R1542     -3.7074224948883057e+00
    phi[5,4]  R1543     -1.6275030374526978e+00
    phi[5,4]  R1544     -2.0633904933929443e+00
    phi[5,4]  R1545     5.7452422380447388e-01
    phi[5,4]  R1546     -1.7635847330093384e+00
    phi[5,4]  R1547     -2.6194429397583008e+00
    phi[5,4]  R1548     -1.4235118627548218e+00
    phi[5,4]  R1549     -6.7739951610565186e-01
    phi[5,4]  R1550     -3.8163475990295410e+00
    phi[5,4]  R1551     1.2651060819625854e+00
    phi[5,4]  R1552     -2.9751892089843750e+00
    phi[5,4]  R1553     -2.4501986503601074e+00
    phi[5,4]  R1554     1.1450688838958740e+00
    phi[5,4]  R1555     -1.6549209356307983e+00
    phi[5,4]  R1556     -8.5084551572799683e-01
    phi[5,4]  R1557     -2.1219222545623779e+00
    phi[5,4]  R1558     1.4005815982818604e+00
    phi[5,4]  R1559     3.3646366000175476e-01
    phi[5,4]  R1560     -1.7390252351760864e+00
    phi[5,4]  R1561     -5.9953290224075317e-01
    phi[5,4]  R1562     -6.2929445505142212e-01
    phi[5,4]  R1563     -3.1908670067787170e-01
    phi[5,4]  R1564     -8.8155007362365723e-01
    phi[5,4]  R1565     -1.6440087556838989e+00
    phi[5,4]  R1566     5.8588665723800659e-01
    phi[5,4]  R1567     -1.5716205835342407e+00
    phi[5,4]  R1568     1.7947614192962646e-01
    phi[5,4]  R1569     1.2271775007247925e+00
    phi[5,4]  R1570     1.1366326808929443e+00
    phi[5,4]  R1571     -2.2286663055419922e+00
    phi[5,4]  R1572     -1.5743334293365479e+00
    phi[5,4]  R1573     -2.5062568187713623e+00
    phi[5,4]  R1574     -7.1013665199279785e-01
    phi[5,4]  R1575     -6.4006870985031128e-01
    phi[5,4]  R1576     0.265857070684433
    phi[5,4]  R1577     -2.4915981292724609e+00
    phi[5,4]  R1578     -1.2369996309280396e+00
    phi[5,4]  R1579     2.6607219129800797e-02
    phi[5,4]  R1580     -2.8346905708312988e+00
    phi[5,4]  R1581     -1.2430933862924576e-01
    phi[5,4]  R1582     -2.1551117897033691e+00
    phi[5,4]  R1583     1.9018359184265137e+00
    phi[5,4]  R1584     3.0847003459930420e+00
    phi[5,4]  R1585     1.8388348817825317e+00
    phi[5,4]  R1586     1.3834429979324341e+00
    phi[5,4]  R1587     -1.2618395686149597e-01
    phi[5,4]  R1588     1.5433218479156494e+00
    phi[5,4]  R1589     1.5392067432403564e+00
    phi[5,4]  R1590     8.6729669570922852e-01
    phi[5,4]  R1591     1.4790722131729126e+00
    phi[5,4]  R1592     1.6708310842514038e+00
    phi[5,4]  R1593     -2.4661645889282227e+00
    phi[5,4]  R1594     -1.3489416837692261e+00
    phi[5,4]  R1595     -1.4103877544403076e+00
    phi[5,4]  R1596     -1.6669409275054932e+00
    phi[5,4]  R1597     -2.0319066047668457e+00
    phi[5,4]  R1598     -1.4539289474487305e+00
    phi[5,4]  R1599     -1.0019844770431519e+00
    phi[5,4]  R1600     -2.5765342712402344e+00
    phi[5,4]  R1601     -1.0681210756301880e+00
    phi[5,4]  R1602     9.2929857969284058e-01
    phi[5,4]  R1603     -1.6385555267333984e+00
    phi[5,4]  R1604     -2.8422701358795166e+00
    phi[5,4]  R1605     6.6069555282592773e-01
    phi[5,4]  R1606     1.3726069927215576e+00
    phi[5,4]  R1607     1.1591323465108871e-01
    phi[5,4]  R1608     1.9424885511398315e+00
    phi[5,4]  R1609     1.6223173141479492e+00
    phi[5,4]  R1610     2.0892393589019775e+00
    phi[5,4]  R1611     1.3054805994033813e-01
    phi[5,4]  R1612     3.6953002214431763e-01
    phi[5,4]  R1613     -1.0339752435684204e+00
    phi[5,4]  R1614     -1.9395371675491333e+00
    phi[5,4]  R1615     -3.0857594013214111e+00
    phi[5,4]  R1616     -7.6785135269165039e-01
    phi[5,4]  R1617     -2.8854753971099854e+00
    phi[5,4]  R1618     1.34197199344635
    phi[5,4]  R1619     1.6343970298767090e+00
    phi[5,4]  R1620     1.5368472337722778e+00
    phi[5,4]  R1621     7.0690184831619263e-01
    phi[5,4]  R1622     2.0608010292053223e+00
    phi[5,4]  R1623     1.8067771196365356e+00
    phi[5,4]  R1624     5.6711488962173462e-01
    phi[5,4]  R1625     2.4242296814918518e-01
    phi[5,4]  R1626     1.2731055021286011e+00
    phi[5,4]  R1627     1.6448679566383362e-01
    phi[5,4]  R1628     9.7318768501281738e-01
    phi[5,4]  R1629     1.2423642873764038e+00
    phi[5,4]  R1630     1.5575797557830811e+00
    phi[5,4]  R1631     1.3661350011825562e+00
    phi[5,4]  R1632     -2.7541634440422058e-01
    phi[4,10]  R36       1
    phi[4,10]  R37       1
    phi[4,10]  R90       -1
    phi[4,10]  R1633     -3.0999999046325684e+00
    phi[4,10]  R1634     -3.0999999046325684e+00
    phi[4,10]  R1635     -2.2400000095367432e+00
    phi[4,10]  R1636     -2.2400000095367432e+00
    phi[4,10]  R1637     -3.0999999046325684e+00
    phi[4,10]  R1638     -3.0999999046325684e+00
    phi[4,10]  R1639     -2.5699999332427979e+00
    phi[4,10]  R1640     -2.5699999332427979e+00
    phi[4,10]  R1641     -3.0999999046325684e+00
    phi[4,10]  R1642     -3.0999999046325684e+00
    phi[4,10]  R1643     -2.0899999141693115e+00
    phi[4,10]  R1644     -2.0899999141693115e+00
    phi[4,10]  R1645     -3.0999999046325684e+00
    phi[4,10]  R1646     -3.0999999046325684e+00
    phi[4,10]  R1647     1.9018359184265137e+00
    phi[4,10]  R1648     3.0847003459930420e+00
    phi[4,10]  R1649     1.8388348817825317e+00
    phi[4,10]  R1650     1.3834429979324341e+00
    phi[4,10]  R1651     -1.2618395686149597e-01
    phi[4,10]  R1652     1.5433218479156494e+00
    phi[4,10]  R1653     1.5392067432403564e+00
    phi[4,10]  R1654     8.6729669570922852e-01
    phi[4,10]  R1655     1.4790722131729126e+00
    phi[4,10]  R1656     1.6708310842514038e+00
    phi[4,10]  R1657     -2.4661645889282227e+00
    phi[4,10]  R1658     -1.3489416837692261e+00
    phi[4,10]  R1659     -1.4103877544403076e+00
    phi[4,10]  R1660     -1.6669409275054932e+00
    phi[4,10]  R1661     -2.0319066047668457e+00
    phi[4,10]  R1662     -1.4539289474487305e+00
    phi[4,10]  R1663     -1.0019844770431519e+00
    phi[4,10]  R1664     -2.5765342712402344e+00
    phi[4,10]  R1665     -1.0681210756301880e+00
    phi[4,10]  R1666     9.2929857969284058e-01
    phi[4,10]  R1667     -1.6385555267333984e+00
    phi[4,10]  R1668     -2.8422701358795166e+00
    phi[4,10]  R1669     6.6069555282592773e-01
    phi[4,10]  R1670     1.3726069927215576e+00
    phi[4,10]  R1671     1.1591323465108871e-01
    phi[4,10]  R1672     1.9424885511398315e+00
    phi[4,10]  R1673     1.6223173141479492e+00
    phi[4,10]  R1674     2.0892393589019775e+00
    phi[4,10]  R1675     1.3054805994033813e-01
    phi[4,10]  R1676     3.6953002214431763e-01
    phi[4,10]  R1677     -1.0339752435684204e+00
    phi[4,10]  R1678     -1.9395371675491333e+00
    phi[4,10]  R1679     -3.0857594013214111e+00
    phi[4,10]  R1680     -7.6785135269165039e-01
    phi[4,10]  R1681     -2.8854753971099854e+00
    phi[4,10]  R1682     1.34197199344635
    phi[4,10]  R1683     1.6343970298767090e+00
    phi[4,10]  R1684     1.5368472337722778e+00
    phi[4,10]  R1685     7.0690184831619263e-01
    phi[4,10]  R1686     2.0608010292053223e+00
    phi[4,10]  R1687     1.8067771196365356e+00
    phi[4,10]  R1688     5.6711488962173462e-01
    phi[4,10]  R1689     2.4242296814918518e-01
    phi[4,10]  R1690     1.2731055021286011e+00
    phi[4,10]  R1691     1.6448679566383362e-01
    phi[4,10]  R1692     9.7318768501281738e-01
    phi[4,10]  R1693     1.2423642873764038e+00
    phi[4,10]  R1694     1.5575797557830811e+00
    phi[4,10]  R1695     1.3661350011825562e+00
    phi[4,10]  R1696     -2.7541634440422058e-01
    phi[4,10]  R1697     1.6034849882125854e+00
    phi[4,10]  R1698     1.8111655712127686e+00
    phi[4,10]  R1699     1.7019549608230591e+00
    phi[4,10]  R1700     9.8893636465072632e-01
    phi[4,10]  R1701     1.6807801723480225e+00
    phi[4,10]  R1702     1.5854493379592896e+00
    phi[4,10]  R1703     0.998877763748169
    phi[4,10]  R1704     1.8693864345550537e+00
    phi[4,10]  R1705     1.9732274115085602e-01
    phi[4,10]  R1706     1.1268581151962280e+00
    phi[4,10]  R1707     -2.33562970161438
    phi[4,10]  R1708     -2.3505096435546875e+00
    phi[4,10]  R1709     -1.5073122978210449e+00
    phi[4,10]  R1710     -7.0644193887710571e-01
    phi[4,10]  R1711     8.0909393727779388e-02
    phi[4,10]  R1712     -5.9340596199035645e-01
    phi[4,10]  R1713     -7.7890384197235107e-01
    phi[4,10]  R1714     -2.1858930587768555e+00
    phi[4,10]  R1715     -5.7323282957077026e-01
    phi[4,10]  R1716     -2.1939802169799805e+00
    phi[4,10]  R1717     -2.0164949893951416e+00
    phi[4,10]  R1718     -1.2315652370452881e+00
    phi[4,10]  R1719     -1.5021522045135498e+00
    phi[4,10]  R1720     -1.6575220823287964e+00
    phi[4,10]  R1721     -1.1053600311279297e+00
    phi[4,10]  R1722     9.0017179027199745e-03
    phi[4,10]  R1723     -1.3707969188690186e+00
    phi[4,10]  R1724     -2.5933270454406738e+00
    phi[4,10]  R1725     -1.6544564068317413e-01
    phi[4,10]  R1726     -8.1910967826843262e-01
    phi[4,10]  R1727     -9.7236263751983643e-01
    phi[4,10]  R1728     -2.1291913986206055e+00
    phi[4,10]  R1729     -2.7167298793792725e+00
    phi[4,10]  R1730     -1.7763613462448120e+00
    phi[4,10]  R1731     -2.5446350574493408e+00
    phi[4,10]  R1732     -1.8559244871139526e+00
    phi[4,10]  R1733     0.992651641368866
    phi[4,10]  R1734     1.4628553390502930e-01
    phi[4,10]  R1735     -1.0963987112045288e+00
    phi[4,10]  R1736     -2.83156681060791
    phi[10,4]  R36       -1
    phi[10,4]  R90       1
    phi[10,4]  R91       1
    phi[10,4]  R1737     -3.0999999046325684e+00
    phi[10,4]  R1738     -3.0999999046325684e+00
    phi[10,4]  R1739     -2.2400000095367432e+00
    phi[10,4]  R1740     -2.2400000095367432e+00
    phi[10,4]  R1741     -3.0999999046325684e+00
    phi[10,4]  R1742     -3.0999999046325684e+00
    phi[10,4]  R1743     -2.5699999332427979e+00
    phi[10,4]  R1744     -2.5699999332427979e+00
    phi[10,4]  R1745     -3.0999999046325684e+00
    phi[10,4]  R1746     -3.0999999046325684e+00
    phi[10,4]  R1747     -2.0899999141693115e+00
    phi[10,4]  R1748     -2.0899999141693115e+00
    phi[10,4]  R1749     -3.0999999046325684e+00
    phi[10,4]  R1750     -3.0999999046325684e+00
    phi[10,4]  R1751     1.6034849882125854e+00
    phi[10,4]  R1752     1.8111655712127686e+00
    phi[10,4]  R1753     1.7019549608230591e+00
    phi[10,4]  R1754     9.8893636465072632e-01
    phi[10,4]  R1755     1.6807801723480225e+00
    phi[10,4]  R1756     1.5854493379592896e+00
    phi[10,4]  R1757     0.998877763748169
    phi[10,4]  R1758     1.8693864345550537e+00
    phi[10,4]  R1759     1.9732274115085602e-01
    phi[10,4]  R1760     1.1268581151962280e+00
    phi[10,4]  R1761     -2.33562970161438
    phi[10,4]  R1762     -2.3505096435546875e+00
    phi[10,4]  R1763     -1.5073122978210449e+00
    phi[10,4]  R1764     -7.0644193887710571e-01
    phi[10,4]  R1765     8.0909393727779388e-02
    phi[10,4]  R1766     -5.9340596199035645e-01
    phi[10,4]  R1767     -7.7890384197235107e-01
    phi[10,4]  R1768     -2.1858930587768555e+00
    phi[10,4]  R1769     -5.7323282957077026e-01
    phi[10,4]  R1770     -2.1939802169799805e+00
    phi[10,4]  R1771     -2.0164949893951416e+00
    phi[10,4]  R1772     -1.2315652370452881e+00
    phi[10,4]  R1773     -1.5021522045135498e+00
    phi[10,4]  R1774     -1.6575220823287964e+00
    phi[10,4]  R1775     -1.1053600311279297e+00
    phi[10,4]  R1776     9.0017179027199745e-03
    phi[10,4]  R1777     -1.3707969188690186e+00
    phi[10,4]  R1778     -2.5933270454406738e+00
    phi[10,4]  R1779     -1.6544564068317413e-01
    phi[10,4]  R1780     -8.1910967826843262e-01
    phi[10,4]  R1781     -9.7236263751983643e-01
    phi[10,4]  R1782     -2.1291913986206055e+00
    phi[10,4]  R1783     -2.7167298793792725e+00
    phi[10,4]  R1784     -1.7763613462448120e+00
    phi[10,4]  R1785     -2.5446350574493408e+00
    phi[10,4]  R1786     -1.8559244871139526e+00
    phi[10,4]  R1787     0.992651641368866
    phi[10,4]  R1788     1.4628553390502930e-01
    phi[10,4]  R1789     -1.0963987112045288e+00
    phi[10,4]  R1790     -2.83156681060791
    phi[10,4]  R1791     1.9018359184265137e+00
    phi[10,4]  R1792     3.0847003459930420e+00
    phi[10,4]  R1793     1.8388348817825317e+00
    phi[10,4]  R1794     1.3834429979324341e+00
    phi[10,4]  R1795     -1.2618395686149597e-01
    phi[10,4]  R1796     1.5433218479156494e+00
    phi[10,4]  R1797     1.5392067432403564e+00
    phi[10,4]  R1798     8.6729669570922852e-01
    phi[10,4]  R1799     1.4790722131729126e+00
    phi[10,4]  R1800     1.6708310842514038e+00
    phi[10,4]  R1801     -2.4661645889282227e+00
    phi[10,4]  R1802     -1.3489416837692261e+00
    phi[10,4]  R1803     -1.4103877544403076e+00
    phi[10,4]  R1804     -1.6669409275054932e+00
    phi[10,4]  R1805     -2.0319066047668457e+00
    phi[10,4]  R1806     -1.4539289474487305e+00
    phi[10,4]  R1807     -1.0019844770431519e+00
    phi[10,4]  R1808     -2.5765342712402344e+00
    phi[10,4]  R1809     -1.0681210756301880e+00
    phi[10,4]  R1810     9.2929857969284058e-01
    phi[10,4]  R1811     -1.6385555267333984e+00
    phi[10,4]  R1812     -2.8422701358795166e+00
    phi[10,4]  R1813     6.6069555282592773e-01
    phi[10,4]  R1814     1.3726069927215576e+00
    phi[10,4]  R1815     1.1591323465108871e-01
    phi[10,4]  R1816     1.9424885511398315e+00
    phi[10,4]  R1817     1.6223173141479492e+00
    phi[10,4]  R1818     2.0892393589019775e+00
    phi[10,4]  R1819     1.3054805994033813e-01
    phi[10,4]  R1820     3.6953002214431763e-01
    phi[10,4]  R1821     -1.0339752435684204e+00
    phi[10,4]  R1822     -1.9395371675491333e+00
    phi[10,4]  R1823     -3.0857594013214111e+00
    phi[10,4]  R1824     -7.6785135269165039e-01
    phi[10,4]  R1825     -2.8854753971099854e+00
    phi[10,4]  R1826     1.34197199344635
    phi[10,4]  R1827     1.6343970298767090e+00
    phi[10,4]  R1828     1.5368472337722778e+00
    phi[10,4]  R1829     7.0690184831619263e-01
    phi[10,4]  R1830     2.0608010292053223e+00
    phi[10,4]  R1831     1.8067771196365356e+00
    phi[10,4]  R1832     5.6711488962173462e-01
    phi[10,4]  R1833     2.4242296814918518e-01
    phi[10,4]  R1834     1.2731055021286011e+00
    phi[10,4]  R1835     1.6448679566383362e-01
    phi[10,4]  R1836     9.7318768501281738e-01
    phi[10,4]  R1837     1.2423642873764038e+00
    phi[10,4]  R1838     1.5575797557830811e+00
    phi[10,4]  R1839     1.3661350011825562e+00
    phi[10,4]  R1840     -2.7541634440422058e-01
    phi[5,12]  R45       1
    phi[5,12]  R46       1
    phi[5,12]  R47       0.594286663972273
    phi[5,12]  R48       1.7580781415680127e+00
    phi[5,12]  R49       -2.7585883808964806e+00
    phi[5,12]  R50       2.2769091433021611e+00
    phi[5,12]  R51       1.5184055778061114e+00
    phi[5,12]  R52       2.0625829748038265e+00
    phi[5,12]  R53       2.8494869019149016e+00
    phi[5,12]  R100      -1
    phi[5,12]  R1841     -2.5057132406602953e+00
    phi[5,12]  R1842     -3.6942865686048414e+00
    phi[5,12]  R1843     -4.8192186796873049e-01
    phi[5,12]  R1844     -3.9980781511047558e+00
    phi[5,12]  R1845     -5.8585882855290485e+00
    phi[5,12]  R1846     -3.4141152373608774e-01
    phi[5,12]  R1847     -2.9309078994063675e-01
    phi[5,12]  R1848     -4.8469090765449589e+00
    phi[5,12]  R1849     -1.5815943268264570e+00
    phi[5,12]  R1850     -4.61840548243868
    phi[5,12]  R1851     -2.7416939365485060e-02
    phi[5,12]  R1852     -4.1525828889731375e+00
    phi[5,12]  R1853     -2.5051300271766674e-01
    phi[5,12]  R1854     -5.94948680654747
    phi[5,12]  R1855     -3.3900031035921208e-02
    phi[5,12]  R1856     -5.5183062762086843e-02
    phi[5,12]  R1857     -8.8198767470238693e-02
    phi[5,12]  R1858     -5.5558032246327449e-01
    phi[5,12]  R1859     -8.7046317014658126e-01
    phi[5,12]  R1860     -6.0408055019217466e-01
    phi[5,12]  R1861     -8.7150895261568717e-01
    phi[5,12]  R1862     -1.3782822638949073e+00
    phi[5,12]  R1863     -1.0946367239201362e+00
    phi[5,12]  R1864     -1.5329148998238553e+00
    phi[5,12]  R1865     -8.8047123115895687e-02
    phi[5,12]  R1866     -1.0045295411533184e-01
    phi[5,12]  R1867     -2.4839911602821219e-01
    phi[5,12]  R1868     -2.6100551607105782e-01
    phi[5,12]  R1869     -2.6187593477831084e-01
    phi[5,12]  R1870     -6.7699150731847890e-01
    phi[5,12]  R1871     -3.8881192708862589e-01
    phi[5,12]  R1872     -4.2522811807196137e-01
    phi[5,12]  R1873     -2.8794287679741065e-01
    phi[5,12]  R1874     -2.9030280789642360e-01
    phi[5,12]  R1875     -2.1147524706032667e-01
    phi[5,12]  R1876     -0.641206686644991
    phi[5,12]  R1877     -0.254007752599271
    phi[5,12]  R1878     -0.662562995229603
    phi[5,12]  R1879     -4.8151610710173509e-01
    phi[5,12]  R1880     -1.2276055536645
    phi[5,12]  R1881     -2.8535342049879464e-01
    phi[5,12]  R1882     -5.7658696535411635e-01
    phi[5,12]  R1883     -3.0706846401551635e-01
    phi[5,12]  R1884     -3.1671833614787470e-01
    phi[5,12]  R1885     -2.2692710661601345e-01
    phi[5,12]  R1886     -2.3946827398410520e-01
    phi[5,12]  R1887     -2.4709160925315665e-01
    phi[5,12]  R1888     -2.4930234322092337e-01
    phi[5,12]  R1889     -2.5260014369706152e-01
    phi[5,12]  R1890     -2.5449676937600141e-01
    phi[5,12]  R1891     -0.553406528961744
    phi[5,12]  R1892     -2.5684272051145651e-01
    phi[5,12]  R1893     -7.9250132727189460e-01
    phi[5,12]  R1894     -6.3092956565008018e-01
    phi[5,12]  R1895     -2.6574134103045743e-01
    phi[5,12]  R1896     -6.6616489430769721e-01
    phi[5,12]  R1897     -7.7475302026839743e-01
    phi[5,12]  R1898     -2.7967592233039640e-01
    phi[5,12]  R1899     -3.0511435554731925e-01
    phi[5,12]  R1900     -8.3277470197687986e-01
    phi[5,12]  R1901     -3.2989111274152894e-01
    phi[5,12]  R1902     -3.4520801785804078e-01
    phi[5,12]  R1903     -1.02399044210465
    phi[5,12]  R1904     -3.6628240336261936e-01
    phi[5,12]  R1905     -2.3905128122140051e-01
    phi[5,12]  R1906     -9.2564618536405430e-01
    phi[5,12]  R1907     -5.3884893664110178e-01
    phi[5,12]  R1908     -9.8092680352975448e-01
    phi[5,12]  R1909     -2.7183362037697179e-01
    phi[5,12]  R1910     -1.1215442313220971e+00
    phi[5,12]  R1911     -2.8425775903189709e-01
    phi[5,12]  R1912     -4.3976820159606822e-01
    phi[5,12]  R1913     -3.0974437518131137e-01
    phi[5,12]  R1914     -3.3069167767131091e-01
    phi[5,12]  R1915     -2.4634769434346859e-01
    phi[5,12]  R1916     -5.3819288466575432e-01
    phi[5,12]  R1917     -5.5551767668109453e-01
    phi[5,12]  R1918     -2.8524631577323223e-01
    phi[5,12]  R1919     -2.9931213449667737e-01
    phi[5,12]  R1920     -4.1298255176646326e-01
    phi[5,12]  R1921     -4.2451538728695604e-01
    phi[5,12]  R1922     -4.3720422668775250e-01
    phi[5,12]  R1923     -4.3892606576564241e-01
    phi[5,12]  R1924     -4.5512302992362930e-01
    phi[6,7]  R54       1
    phi[6,7]  R55       1
    phi[6,7]  R63       -1
    phi[6,7]  R1925     -3.0999999046325684e+00
    phi[6,7]  R1926     -3.0999999046325684e+00
    phi[6,7]  R1927     -2.2400000095367432e+00
    phi[6,7]  R1928     -2.2400000095367432e+00
    phi[6,7]  R1929     -3.0999999046325684e+00
    phi[6,7]  R1930     -3.0999999046325684e+00
    phi[6,7]  R1931     -2.5699999332427979e+00
    phi[6,7]  R1932     -2.5699999332427979e+00
    phi[6,7]  R1933     -3.0999999046325684e+00
    phi[6,7]  R1934     -3.0999999046325684e+00
    phi[6,7]  R1935     -2.0899999141693115e+00
    phi[6,7]  R1936     -2.0899999141693115e+00
    phi[6,7]  R1937     -3.0999999046325684e+00
    phi[6,7]  R1938     -3.0999999046325684e+00
    phi[6,7]  R1939     -1.2000774145126343e+00
    phi[6,7]  R1940     7.6394744217395782e-02
    phi[6,7]  R1941     -3.2834053039550781e-01
    phi[6,7]  R1942     4.7135055065155029e-01
    phi[6,7]  R1943     -1.6203496456146240e+00
    phi[6,7]  R1944     -1.1345604658126831e+00
    phi[6,7]  R1945     -5.8417338132858276e-01
    phi[6,7]  R1946     -1.6086968183517456e+00
    phi[6,7]  R1947     -1.7797340154647827e+00
    phi[6,7]  R1948     -8.2175695896148682e-01
    phi[6,7]  R1949     9.2191642522811890e-01
    phi[6,7]  R1950     1.1151922941207886e+00
    phi[6,7]  R1951     1.1291612386703491e+00
    phi[6,7]  R1952     1.8498758971691132e-01
    phi[6,7]  R1953     -0.0330149382352829
    phi[6,7]  R1954     2.2549942135810852e-01
    phi[6,7]  R1955     7.5888383388519287e-01
    phi[6,7]  R1956     0.5791015625
    phi[6,7]  R1957     1.5948952734470367e-01
    phi[6,7]  R1958     7.7515608072280884e-01
    phi[6,7]  R1959     -1.3829548358917236e+00
    phi[6,7]  R1960     6.3957124948501587e-01
    phi[6,7]  R1961     0.272148996591568
    phi[6,7]  R1962     -5.6983256340026855e-01
    phi[6,7]  R1963     -0.798306405544281
    phi[6,7]  R1964     -2.5867865085601807e+00
    phi[6,7]  R1965     2.6694774627685547e-01
    phi[6,7]  R1966     -1.5693485736846924e+00
    phi[6,7]  R1967     -1.2245109081268311e+00
    phi[6,7]  R1968     -1.2315701246261597e+00
    phi[6,7]  R1969     -8.1658661365509033e-01
    phi[6,7]  R1970     -1.6453791856765747e+00
    phi[6,7]  R1971     5.2375149726867676e-01
    phi[6,7]  R1972     3.4715652465820312e-02
    phi[6,7]  R1973     -0.393656462430954
    phi[6,7]  R1974     -0.837851345539093
    phi[6,7]  R1975     -1.2642073631286621e+00
    phi[6,7]  R1976     -0.572843074798584
    phi[6,7]  R1977     4.2364948987960815e-01
    phi[6,7]  R1978     -3.8453230261802673e-01
    phi[6,7]  R1979     -1.2215181589126587e+00
    phi[6,7]  R1980     1.5707360208034515e-01
    phi[6,7]  R1981     -1.0264184474945068e+00
    phi[6,7]  R1982     5.3985029458999634e-01
    phi[6,7]  R1983     -6.1535704135894775e-01
    phi[6,7]  R1984     5.2428901195526123e-01
    phi[6,7]  R1985     1.0632052421569824e+00
    phi[6,7]  R1986     -6.5804082155227661e-01
    phi[6,7]  R1987     -3.0586624145507812e+00
    phi[6,7]  R1988     -2.5212714672088623e+00
    phi[6,7]  R1989     -3.0600461959838867e+00
    phi[6,7]  R1990     -1.8275665044784546e+00
    phi[6,7]  R1991     -2.4257009029388428e+00
    phi[6,7]  R1992     6.6994361579418182e-02
    phi[6,7]  R1993     1.3297199010849
    phi[6,7]  R1994     1.0391119718551636e+00
    phi[6,7]  R1995     1.1114176511764526e+00
    phi[6,7]  R1996     1.3253356218338013e+00
    phi[6,7]  R1997     -1.9897577762603760e+00
    phi[6,7]  R1998     -1.6480305194854736e+00
    phi[6,7]  R1999     -1.0025595426559448e+00
    phi[6,7]  R2000     -2.8095018863677979e+00
    phi[6,7]  R2001     -7.3099076747894287e-01
    phi[6,7]  R2002     -1.0610187053680420e+00
    phi[6,7]  R2003     -7.1564149856567383e-01
    phi[6,7]  R2004     -1.5913853645324707e+00
    phi[6,7]  R2005     -1.8651438951492310e+00
    phi[6,7]  R2006     0.989293098449707
    phi[6,7]  R2007     1.0135178565979004e+00
    phi[6,7]  R2008     1.7636487483978271e+00
    phi[6,7]  R2009     2.2916059494018555e+00
    phi[6,7]  R2010     8.1502735614776611e-01
    phi[6,7]  R2011     9.0552233159542084e-02
    phi[6,7]  R2012     7.2761738300323486e-01
    phi[6,7]  R2013     2.2124354839324951e+00
    phi[6,7]  R2014     8.9156115055084229e-01
    phi[6,7]  R2015     2.4291269779205322e+00
    phi[6,7]  R2016     2.0131780207157135e-01
    phi[6,7]  R2017     -1.0066032409667969e+00
    phi[6,7]  R2018     -2.0531275272369385e+00
    phi[6,7]  R2019     -1.4035929441452026e+00
    phi[6,7]  R2020     -2.0500953197479248e+00
    phi[6,7]  R2021     4.4978418946266174e-01
    phi[6,7]  R2022     8.0054181814193726e-01
    phi[6,7]  R2023     1.2404733896255493e-01
    phi[6,7]  R2024     8.1575363874435425e-01
    phi[6,7]  R2025     1.8236947059631348e+00
    phi[6,7]  R2026     1.5999240875244141e+00
    phi[6,7]  R2027     -1.9433431625366211e+00
    phi[6,7]  R2028     9.4747650623321533e-01
    phi[6,7]  R2029     2.6720494031906128e-01
    phi[6,7]  R2030     1.9926275014877319e+00
    phi[6,7]  R2031     2.5615136623382568e+00
    phi[6,7]  R2032     2.8621056675910950e-01
    phi[7,6]  R54       -1
    phi[7,6]  R63       1
    phi[7,6]  R64       1
    phi[7,6]  R2033     -3.0999999046325684e+00
    phi[7,6]  R2034     -3.0999999046325684e+00
    phi[7,6]  R2035     -2.2400000095367432e+00
    phi[7,6]  R2036     -2.2400000095367432e+00
    phi[7,6]  R2037     -3.0999999046325684e+00
    phi[7,6]  R2038     -3.0999999046325684e+00
    phi[7,6]  R2039     -2.5699999332427979e+00
    phi[7,6]  R2040     -2.5699999332427979e+00
    phi[7,6]  R2041     -3.0999999046325684e+00
    phi[7,6]  R2042     -3.0999999046325684e+00
    phi[7,6]  R2043     -2.0899999141693115e+00
    phi[7,6]  R2044     -2.0899999141693115e+00
    phi[7,6]  R2045     -3.0999999046325684e+00
    phi[7,6]  R2046     -3.0999999046325684e+00
    phi[7,6]  R2047     4.2364948987960815e-01
    phi[7,6]  R2048     -3.8453230261802673e-01
    phi[7,6]  R2049     -1.2215181589126587e+00
    phi[7,6]  R2050     1.5707360208034515e-01
    phi[7,6]  R2051     -1.0264184474945068e+00
    phi[7,6]  R2052     5.3985029458999634e-01
    phi[7,6]  R2053     -6.1535704135894775e-01
    phi[7,6]  R2054     5.2428901195526123e-01
    phi[7,6]  R2055     1.0632052421569824e+00
    phi[7,6]  R2056     -6.5804082155227661e-01
    phi[7,6]  R2057     -3.0586624145507812e+00
    phi[7,6]  R2058     -2.5212714672088623e+00
    phi[7,6]  R2059     -3.0600461959838867e+00
    phi[7,6]  R2060     -1.8275665044784546e+00
    phi[7,6]  R2061     -2.4257009029388428e+00
    phi[7,6]  R2062     6.6994361579418182e-02
    phi[7,6]  R2063     1.3297199010849
    phi[7,6]  R2064     1.0391119718551636e+00
    phi[7,6]  R2065     1.1114176511764526e+00
    phi[7,6]  R2066     1.3253356218338013e+00
    phi[7,6]  R2067     -1.9897577762603760e+00
    phi[7,6]  R2068     -1.6480305194854736e+00
    phi[7,6]  R2069     -1.0025595426559448e+00
    phi[7,6]  R2070     -2.8095018863677979e+00
    phi[7,6]  R2071     -7.3099076747894287e-01
    phi[7,6]  R2072     -1.0610187053680420e+00
    phi[7,6]  R2073     -7.1564149856567383e-01
    phi[7,6]  R2074     -1.5913853645324707e+00
    phi[7,6]  R2075     -1.8651438951492310e+00
    phi[7,6]  R2076     0.989293098449707
    phi[7,6]  R2077     1.0135178565979004e+00
    phi[7,6]  R2078     1.7636487483978271e+00
    phi[7,6]  R2079     2.2916059494018555e+00
    phi[7,6]  R2080     8.1502735614776611e-01
    phi[7,6]  R2081     9.0552233159542084e-02
    phi[7,6]  R2082     7.2761738300323486e-01
    phi[7,6]  R2083     2.2124354839324951e+00
    phi[7,6]  R2084     8.9156115055084229e-01
    phi[7,6]  R2085     2.4291269779205322e+00
    phi[7,6]  R2086     2.0131780207157135e-01
    phi[7,6]  R2087     -1.0066032409667969e+00
    phi[7,6]  R2088     -2.0531275272369385e+00
    phi[7,6]  R2089     -1.4035929441452026e+00
    phi[7,6]  R2090     -2.0500953197479248e+00
    phi[7,6]  R2091     4.4978418946266174e-01
    phi[7,6]  R2092     8.0054181814193726e-01
    phi[7,6]  R2093     1.2404733896255493e-01
    phi[7,6]  R2094     8.1575363874435425e-01
    phi[7,6]  R2095     1.8236947059631348e+00
    phi[7,6]  R2096     1.5999240875244141e+00
    phi[7,6]  R2097     -1.9433431625366211e+00
    phi[7,6]  R2098     9.4747650623321533e-01
    phi[7,6]  R2099     2.6720494031906128e-01
    phi[7,6]  R2100     1.9926275014877319e+00
    phi[7,6]  R2101     2.5615136623382568e+00
    phi[7,6]  R2102     2.8621056675910950e-01
    phi[7,6]  R2103     -1.2000774145126343e+00
    phi[7,6]  R2104     7.6394744217395782e-02
    phi[7,6]  R2105     -3.2834053039550781e-01
    phi[7,6]  R2106     4.7135055065155029e-01
    phi[7,6]  R2107     -1.6203496456146240e+00
    phi[7,6]  R2108     -1.1345604658126831e+00
    phi[7,6]  R2109     -5.8417338132858276e-01
    phi[7,6]  R2110     -1.6086968183517456e+00
    phi[7,6]  R2111     -1.7797340154647827e+00
    phi[7,6]  R2112     -8.2175695896148682e-01
    phi[7,6]  R2113     9.2191642522811890e-01
    phi[7,6]  R2114     1.1151922941207886e+00
    phi[7,6]  R2115     1.1291612386703491e+00
    phi[7,6]  R2116     1.8498758971691132e-01
    phi[7,6]  R2117     -0.0330149382352829
    phi[7,6]  R2118     2.2549942135810852e-01
    phi[7,6]  R2119     7.5888383388519287e-01
    phi[7,6]  R2120     0.5791015625
    phi[7,6]  R2121     1.5948952734470367e-01
    phi[7,6]  R2122     7.7515608072280884e-01
    phi[7,6]  R2123     -1.3829548358917236e+00
    phi[7,6]  R2124     6.3957124948501587e-01
    phi[7,6]  R2125     0.272148996591568
    phi[7,6]  R2126     -5.6983256340026855e-01
    phi[7,6]  R2127     -0.798306405544281
    phi[7,6]  R2128     -2.5867865085601807e+00
    phi[7,6]  R2129     2.6694774627685547e-01
    phi[7,6]  R2130     -1.5693485736846924e+00
    phi[7,6]  R2131     -1.2245109081268311e+00
    phi[7,6]  R2132     -1.2315701246261597e+00
    phi[7,6]  R2133     -8.1658661365509033e-01
    phi[7,6]  R2134     -1.6453791856765747e+00
    phi[7,6]  R2135     5.2375149726867676e-01
    phi[7,6]  R2136     3.4715652465820312e-02
    phi[7,6]  R2137     -0.393656462430954
    phi[7,6]  R2138     -0.837851345539093
    phi[7,6]  R2139     -1.2642073631286621e+00
    phi[7,6]  R2140     -0.572843074798584
    phi[7,8]  R63       1
    phi[7,8]  R64       1
    phi[7,8]  R72       -1
    phi[7,8]  R2141     -3.0999999046325684e+00
    phi[7,8]  R2142     -3.0999999046325684e+00
    phi[7,8]  R2143     -2.2400000095367432e+00
    phi[7,8]  R2144     -2.2400000095367432e+00
    phi[7,8]  R2145     -3.0999999046325684e+00
    phi[7,8]  R2146     -3.0999999046325684e+00
    phi[7,8]  R2147     -2.5699999332427979e+00
    phi[7,8]  R2148     -2.5699999332427979e+00
    phi[7,8]  R2149     -3.0999999046325684e+00
    phi[7,8]  R2150     -3.0999999046325684e+00
    phi[7,8]  R2151     -2.0899999141693115e+00
    phi[7,8]  R2152     -2.0899999141693115e+00
    phi[7,8]  R2153     -3.0999999046325684e+00
    phi[7,8]  R2154     -3.0999999046325684e+00
    phi[7,8]  R2155     4.2364948987960815e-01
    phi[7,8]  R2156     -3.8453230261802673e-01
    phi[7,8]  R2157     -1.2215181589126587e+00
    phi[7,8]  R2158     1.5707360208034515e-01
    phi[7,8]  R2159     -1.0264184474945068e+00
    phi[7,8]  R2160     5.3985029458999634e-01
    phi[7,8]  R2161     -6.1535704135894775e-01
    phi[7,8]  R2162     5.2428901195526123e-01
    phi[7,8]  R2163     1.0632052421569824e+00
    phi[7,8]  R2164     -6.5804082155227661e-01
    phi[7,8]  R2165     -3.0586624145507812e+00
    phi[7,8]  R2166     -2.5212714672088623e+00
    phi[7,8]  R2167     -3.0600461959838867e+00
    phi[7,8]  R2168     -1.8275665044784546e+00
    phi[7,8]  R2169     -2.4257009029388428e+00
    phi[7,8]  R2170     6.6994361579418182e-02
    phi[7,8]  R2171     1.3297199010849
    phi[7,8]  R2172     1.0391119718551636e+00
    phi[7,8]  R2173     1.1114176511764526e+00
    phi[7,8]  R2174     1.3253356218338013e+00
    phi[7,8]  R2175     -1.9897577762603760e+00
    phi[7,8]  R2176     -1.6480305194854736e+00
    phi[7,8]  R2177     -1.0025595426559448e+00
    phi[7,8]  R2178     -2.8095018863677979e+00
    phi[7,8]  R2179     -7.3099076747894287e-01
    phi[7,8]  R2180     -1.0610187053680420e+00
    phi[7,8]  R2181     -7.1564149856567383e-01
    phi[7,8]  R2182     -1.5913853645324707e+00
    phi[7,8]  R2183     -1.8651438951492310e+00
    phi[7,8]  R2184     0.989293098449707
    phi[7,8]  R2185     1.0135178565979004e+00
    phi[7,8]  R2186     1.7636487483978271e+00
    phi[7,8]  R2187     2.2916059494018555e+00
    phi[7,8]  R2188     8.1502735614776611e-01
    phi[7,8]  R2189     9.0552233159542084e-02
    phi[7,8]  R2190     7.2761738300323486e-01
    phi[7,8]  R2191     2.2124354839324951e+00
    phi[7,8]  R2192     8.9156115055084229e-01
    phi[7,8]  R2193     2.4291269779205322e+00
    phi[7,8]  R2194     2.0131780207157135e-01
    phi[7,8]  R2195     -1.0066032409667969e+00
    phi[7,8]  R2196     -2.0531275272369385e+00
    phi[7,8]  R2197     -1.4035929441452026e+00
    phi[7,8]  R2198     -2.0500953197479248e+00
    phi[7,8]  R2199     4.4978418946266174e-01
    phi[7,8]  R2200     8.0054181814193726e-01
    phi[7,8]  R2201     1.2404733896255493e-01
    phi[7,8]  R2202     8.1575363874435425e-01
    phi[7,8]  R2203     1.8236947059631348e+00
    phi[7,8]  R2204     1.5999240875244141e+00
    phi[7,8]  R2205     -1.9433431625366211e+00
    phi[7,8]  R2206     9.4747650623321533e-01
    phi[7,8]  R2207     2.6720494031906128e-01
    phi[7,8]  R2208     1.9926275014877319e+00
    phi[7,8]  R2209     2.5615136623382568e+00
    phi[7,8]  R2210     2.8621056675910950e-01
    phi[7,8]  R2211     1.9104861021041870e+00
    phi[7,8]  R2212     1.2972999811172485e+00
    phi[7,8]  R2213     1.4011027812957764e+00
    phi[7,8]  R2214     1.9408745765686035e+00
    phi[7,8]  R2215     1.1844093799591064e+00
    phi[7,8]  R2216     2.1629805564880371e+00
    phi[7,8]  R2217     2.3864185810089111e+00
    phi[7,8]  R2218     2.3387956619262695e+00
    phi[7,8]  R2219     2.1478676795959473e+00
    phi[7,8]  R2220     7.5916498899459839e-01
    phi[7,8]  R2221     -1.1690975427627563e+00
    phi[7,8]  R2222     -1.5339069366455078e+00
    phi[7,8]  R2223     -3.1076467037200928e+00
    phi[7,8]  R2224     1.7045229673385620e-01
    phi[7,8]  R2225     3.0203115940093994e-01
    phi[7,8]  R2226     -9.4317689538002014e-02
    phi[7,8]  R2227     3.5076677799224854e-02
    phi[7,8]  R2228     -1.5258601903915405e+00
    phi[7,8]  R2229     5.4047244787216187e-01
    phi[7,8]  R2230     -8.9192336797714233e-01
    phi[7,8]  R2231     -2.3142201900482178e+00
    phi[7,8]  R2232     -9.5805382728576660e-01
    phi[7,8]  R2233     -1.6332137584686279e+00
    phi[7,8]  R2234     -1.6407982110977173e+00
    phi[7,8]  R2235     -1.8855262994766235e+00
    phi[7,8]  R2236     -3.4521019458770752e-01
    phi[7,8]  R2237     -1.7276036739349365e+00
    phi[7,8]  R2238     -6.8979871273040771e-01
    phi[7,8]  R2239     -1.8979138135910034e+00
    phi[7,8]  R2240     -1.6546614170074463e+00
    phi[7,8]  R2241     -6.8853902816772461e-01
    phi[7,8]  R2242     1.1091622114181519e+00
    phi[7,8]  R2243     1.6452105045318604e+00
    phi[7,8]  R2244     8.9940857887268066e-01
    phi[7,8]  R2245     5.6285655498504639e-01
    phi[7,8]  R2246     9.4707079231739044e-02
    phi[7,8]  R2247     0.763882040977478
    phi[7,8]  R2248     4.8118868470191956e-01
    phi[7,8]  R2249     1.4307234287261963e+00
    phi[7,8]  R2250     1.2968244552612305e+00
    phi[7,8]  R2251     1.5958026647567749e+00
    phi[7,8]  R2252     8.5172605514526367e-01
    phi[7,8]  R2253     7.4018108844757080e-01
    phi[7,8]  R2254     7.2108995914459229e-01
    phi[7,8]  R2255     8.3887743949890137e-01
    phi[7,8]  R2256     1.5919963121414185e+00
    phi[7,8]  R2257     -1.9614520072937012e+00
    phi[7,8]  R2258     -5.6612402200698853e-01
    phi[7,8]  R2259     -1.5254091024398804e+00
    phi[7,8]  R2260     -1.98341703414917
    phi[7,8]  R2261     -3.6444935202598572e-01
    phi[7,8]  R2262     -1.8875350952148438e+00
    phi[7,8]  R2263     -1.8343496322631836e+00
    phi[7,8]  R2264     -9.6041357517242432e-01
    phi[7,8]  R2265     -1.1572604179382324e+00
    phi[7,8]  R2266     -1.5116691589355469e+00
    phi[7,8]  R2267     -9.7787374258041382e-01
    phi[7,8]  R2268     -1.7108029127120972e+00
    phi[7,8]  R2269     6.0640156269073486e-01
    phi[7,8]  R2270     -2.7840778827667236e+00
    phi[8,7]  R63       -1
    phi[8,7]  R72       1
    phi[8,7]  R73       1
    phi[8,7]  R2271     -3.0999999046325684e+00
    phi[8,7]  R2272     -3.0999999046325684e+00
    phi[8,7]  R2273     -2.2400000095367432e+00
    phi[8,7]  R2274     -2.2400000095367432e+00
    phi[8,7]  R2275     -3.0999999046325684e+00
    phi[8,7]  R2276     -3.0999999046325684e+00
    phi[8,7]  R2277     -2.5699999332427979e+00
    phi[8,7]  R2278     -2.5699999332427979e+00
    phi[8,7]  R2279     -3.0999999046325684e+00
    phi[8,7]  R2280     -3.0999999046325684e+00
    phi[8,7]  R2281     -2.0899999141693115e+00
    phi[8,7]  R2282     -2.0899999141693115e+00
    phi[8,7]  R2283     -3.0999999046325684e+00
    phi[8,7]  R2284     -3.0999999046325684e+00
    phi[8,7]  R2285     1.9104861021041870e+00
    phi[8,7]  R2286     1.2972999811172485e+00
    phi[8,7]  R2287     1.4011027812957764e+00
    phi[8,7]  R2288     1.9408745765686035e+00
    phi[8,7]  R2289     1.1844093799591064e+00
    phi[8,7]  R2290     2.1629805564880371e+00
    phi[8,7]  R2291     2.3864185810089111e+00
    phi[8,7]  R2292     2.3387956619262695e+00
    phi[8,7]  R2293     2.1478676795959473e+00
    phi[8,7]  R2294     7.5916498899459839e-01
    phi[8,7]  R2295     -1.1690975427627563e+00
    phi[8,7]  R2296     -1.5339069366455078e+00
    phi[8,7]  R2297     -3.1076467037200928e+00
    phi[8,7]  R2298     1.7045229673385620e-01
    phi[8,7]  R2299     3.0203115940093994e-01
    phi[8,7]  R2300     -9.4317689538002014e-02
    phi[8,7]  R2301     3.5076677799224854e-02
    phi[8,7]  R2302     -1.5258601903915405e+00
    phi[8,7]  R2303     5.4047244787216187e-01
    phi[8,7]  R2304     -8.9192336797714233e-01
    phi[8,7]  R2305     -2.3142201900482178e+00
    phi[8,7]  R2306     -9.5805382728576660e-01
    phi[8,7]  R2307     -1.6332137584686279e+00
    phi[8,7]  R2308     -1.6407982110977173e+00
    phi[8,7]  R2309     -1.8855262994766235e+00
    phi[8,7]  R2310     -3.4521019458770752e-01
    phi[8,7]  R2311     -1.7276036739349365e+00
    phi[8,7]  R2312     -6.8979871273040771e-01
    phi[8,7]  R2313     -1.8979138135910034e+00
    phi[8,7]  R2314     -1.6546614170074463e+00
    phi[8,7]  R2315     -6.8853902816772461e-01
    phi[8,7]  R2316     1.1091622114181519e+00
    phi[8,7]  R2317     1.6452105045318604e+00
    phi[8,7]  R2318     8.9940857887268066e-01
    phi[8,7]  R2319     5.6285655498504639e-01
    phi[8,7]  R2320     9.4707079231739044e-02
    phi[8,7]  R2321     0.763882040977478
    phi[8,7]  R2322     4.8118868470191956e-01
    phi[8,7]  R2323     1.4307234287261963e+00
    phi[8,7]  R2324     1.2968244552612305e+00
    phi[8,7]  R2325     1.5958026647567749e+00
    phi[8,7]  R2326     8.5172605514526367e-01
    phi[8,7]  R2327     7.4018108844757080e-01
    phi[8,7]  R2328     7.2108995914459229e-01
    phi[8,7]  R2329     8.3887743949890137e-01
    phi[8,7]  R2330     1.5919963121414185e+00
    phi[8,7]  R2331     -1.9614520072937012e+00
    phi[8,7]  R2332     -5.6612402200698853e-01
    phi[8,7]  R2333     -1.5254091024398804e+00
    phi[8,7]  R2334     -1.98341703414917
    phi[8,7]  R2335     -3.6444935202598572e-01
    phi[8,7]  R2336     -1.8875350952148438e+00
    phi[8,7]  R2337     -1.8343496322631836e+00
    phi[8,7]  R2338     -9.6041357517242432e-01
    phi[8,7]  R2339     -1.1572604179382324e+00
    phi[8,7]  R2340     -1.5116691589355469e+00
    phi[8,7]  R2341     -9.7787374258041382e-01
    phi[8,7]  R2342     -1.7108029127120972e+00
    phi[8,7]  R2343     6.0640156269073486e-01
    phi[8,7]  R2344     -2.7840778827667236e+00
    phi[8,7]  R2345     4.2364948987960815e-01
    phi[8,7]  R2346     -3.8453230261802673e-01
    phi[8,7]  R2347     -1.2215181589126587e+00
    phi[8,7]  R2348     1.5707360208034515e-01
    phi[8,7]  R2349     -1.0264184474945068e+00
    phi[8,7]  R2350     5.3985029458999634e-01
    phi[8,7]  R2351     -6.1535704135894775e-01
    phi[8,7]  R2352     5.2428901195526123e-01
    phi[8,7]  R2353     1.0632052421569824e+00
    phi[8,7]  R2354     -6.5804082155227661e-01
    phi[8,7]  R2355     -3.0586624145507812e+00
    phi[8,7]  R2356     -2.5212714672088623e+00
    phi[8,7]  R2357     -3.0600461959838867e+00
    phi[8,7]  R2358     -1.8275665044784546e+00
    phi[8,7]  R2359     -2.4257009029388428e+00
    phi[8,7]  R2360     6.6994361579418182e-02
    phi[8,7]  R2361     1.3297199010849
    phi[8,7]  R2362     1.0391119718551636e+00
    phi[8,7]  R2363     1.1114176511764526e+00
    phi[8,7]  R2364     1.3253356218338013e+00
    phi[8,7]  R2365     -1.9897577762603760e+00
    phi[8,7]  R2366     -1.6480305194854736e+00
    phi[8,7]  R2367     -1.0025595426559448e+00
    phi[8,7]  R2368     -2.8095018863677979e+00
    phi[8,7]  R2369     -7.3099076747894287e-01
    phi[8,7]  R2370     -1.0610187053680420e+00
    phi[8,7]  R2371     -7.1564149856567383e-01
    phi[8,7]  R2372     -1.5913853645324707e+00
    phi[8,7]  R2373     -1.8651438951492310e+00
    phi[8,7]  R2374     0.989293098449707
    phi[8,7]  R2375     1.0135178565979004e+00
    phi[8,7]  R2376     1.7636487483978271e+00
    phi[8,7]  R2377     2.2916059494018555e+00
    phi[8,7]  R2378     8.1502735614776611e-01
    phi[8,7]  R2379     9.0552233159542084e-02
    phi[8,7]  R2380     7.2761738300323486e-01
    phi[8,7]  R2381     2.2124354839324951e+00
    phi[8,7]  R2382     8.9156115055084229e-01
    phi[8,7]  R2383     2.4291269779205322e+00
    phi[8,7]  R2384     2.0131780207157135e-01
    phi[8,7]  R2385     -1.0066032409667969e+00
    phi[8,7]  R2386     -2.0531275272369385e+00
    phi[8,7]  R2387     -1.4035929441452026e+00
    phi[8,7]  R2388     -2.0500953197479248e+00
    phi[8,7]  R2389     4.4978418946266174e-01
    phi[8,7]  R2390     8.0054181814193726e-01
    phi[8,7]  R2391     1.2404733896255493e-01
    phi[8,7]  R2392     8.1575363874435425e-01
    phi[8,7]  R2393     1.8236947059631348e+00
    phi[8,7]  R2394     1.5999240875244141e+00
    phi[8,7]  R2395     -1.9433431625366211e+00
    phi[8,7]  R2396     9.4747650623321533e-01
    phi[8,7]  R2397     2.6720494031906128e-01
    phi[8,7]  R2398     1.9926275014877319e+00
    phi[8,7]  R2399     2.5615136623382568e+00
    phi[8,7]  R2400     2.8621056675910950e-01
    phi[8,9]  R72       1
    phi[8,9]  R73       1
    phi[8,9]  R81       -1
    phi[8,9]  R2401     -3.0999999046325684e+00
    phi[8,9]  R2402     -3.0999999046325684e+00
    phi[8,9]  R2403     -2.2400000095367432e+00
    phi[8,9]  R2404     -2.2400000095367432e+00
    phi[8,9]  R2405     -3.0999999046325684e+00
    phi[8,9]  R2406     -3.0999999046325684e+00
    phi[8,9]  R2407     -2.5699999332427979e+00
    phi[8,9]  R2408     -2.5699999332427979e+00
    phi[8,9]  R2409     -3.0999999046325684e+00
    phi[8,9]  R2410     -3.0999999046325684e+00
    phi[8,9]  R2411     -2.0899999141693115e+00
    phi[8,9]  R2412     -2.0899999141693115e+00
    phi[8,9]  R2413     -3.0999999046325684e+00
    phi[8,9]  R2414     -3.0999999046325684e+00
    phi[8,9]  R2415     1.9104861021041870e+00
    phi[8,9]  R2416     1.2972999811172485e+00
    phi[8,9]  R2417     1.4011027812957764e+00
    phi[8,9]  R2418     1.9408745765686035e+00
    phi[8,9]  R2419     1.1844093799591064e+00
    phi[8,9]  R2420     2.1629805564880371e+00
    phi[8,9]  R2421     2.3864185810089111e+00
    phi[8,9]  R2422     2.3387956619262695e+00
    phi[8,9]  R2423     2.1478676795959473e+00
    phi[8,9]  R2424     7.5916498899459839e-01
    phi[8,9]  R2425     -1.1690975427627563e+00
    phi[8,9]  R2426     -1.5339069366455078e+00
    phi[8,9]  R2427     -3.1076467037200928e+00
    phi[8,9]  R2428     1.7045229673385620e-01
    phi[8,9]  R2429     3.0203115940093994e-01
    phi[8,9]  R2430     -9.4317689538002014e-02
    phi[8,9]  R2431     3.5076677799224854e-02
    phi[8,9]  R2432     -1.5258601903915405e+00
    phi[8,9]  R2433     5.4047244787216187e-01
    phi[8,9]  R2434     -8.9192336797714233e-01
    phi[8,9]  R2435     -2.3142201900482178e+00
    phi[8,9]  R2436     -9.5805382728576660e-01
    phi[8,9]  R2437     -1.6332137584686279e+00
    phi[8,9]  R2438     -1.6407982110977173e+00
    phi[8,9]  R2439     -1.8855262994766235e+00
    phi[8,9]  R2440     -3.4521019458770752e-01
    phi[8,9]  R2441     -1.7276036739349365e+00
    phi[8,9]  R2442     -6.8979871273040771e-01
    phi[8,9]  R2443     -1.8979138135910034e+00
    phi[8,9]  R2444     -1.6546614170074463e+00
    phi[8,9]  R2445     -6.8853902816772461e-01
    phi[8,9]  R2446     1.1091622114181519e+00
    phi[8,9]  R2447     1.6452105045318604e+00
    phi[8,9]  R2448     8.9940857887268066e-01
    phi[8,9]  R2449     5.6285655498504639e-01
    phi[8,9]  R2450     9.4707079231739044e-02
    phi[8,9]  R2451     0.763882040977478
    phi[8,9]  R2452     4.8118868470191956e-01
    phi[8,9]  R2453     1.4307234287261963e+00
    phi[8,9]  R2454     1.2968244552612305e+00
    phi[8,9]  R2455     1.5958026647567749e+00
    phi[8,9]  R2456     8.5172605514526367e-01
    phi[8,9]  R2457     7.4018108844757080e-01
    phi[8,9]  R2458     7.2108995914459229e-01
    phi[8,9]  R2459     8.3887743949890137e-01
    phi[8,9]  R2460     1.5919963121414185e+00
    phi[8,9]  R2461     -1.9614520072937012e+00
    phi[8,9]  R2462     -5.6612402200698853e-01
    phi[8,9]  R2463     -1.5254091024398804e+00
    phi[8,9]  R2464     -1.98341703414917
    phi[8,9]  R2465     -3.6444935202598572e-01
    phi[8,9]  R2466     -1.8875350952148438e+00
    phi[8,9]  R2467     -1.8343496322631836e+00
    phi[8,9]  R2468     -9.6041357517242432e-01
    phi[8,9]  R2469     -1.1572604179382324e+00
    phi[8,9]  R2470     -1.5116691589355469e+00
    phi[8,9]  R2471     -9.7787374258041382e-01
    phi[8,9]  R2472     -1.7108029127120972e+00
    phi[8,9]  R2473     6.0640156269073486e-01
    phi[8,9]  R2474     -2.7840778827667236e+00
    phi[8,9]  R2475     2.4218852519989014e+00
    phi[8,9]  R2476     2.5220637321472168e+00
    phi[8,9]  R2477     1.1131941080093384e+00
    phi[8,9]  R2478     1.1744493246078491e+00
    phi[8,9]  R2479     1.5912538766860962e+00
    phi[8,9]  R2480     3.7973856925964355e-01
    phi[8,9]  R2481     1.0533407926559448e+00
    phi[8,9]  R2482     8.3485513925552368e-01
    phi[8,9]  R2483     1.8986371755599976e+00
    phi[8,9]  R2484     1.0723375082015991e+00
    phi[8,9]  R2485     -1.9360895156860352e+00
    phi[8,9]  R2486     -1.6320511102676392e+00
    phi[8,9]  R2487     -6.2603634595870972e-01
    phi[8,9]  R2488     -2.3469505310058594e+00
    phi[8,9]  R2489     -2.6450660228729248e+00
    phi[8,9]  R2490     -1.2432404756546021e+00
    phi[8,9]  R2491     -0.0943642258644104
    phi[8,9]  R2492     -1.6005312204360962e+00
    phi[8,9]  R2493     -3.1433632373809814e+00
    phi[8,9]  R2494     -9.0487170219421387e-01
    phi[8,9]  R2495     -1.3507587909698486e+00
    phi[8,9]  R2496     6.6155597567558289e-02
    phi[8,9]  R2497     -1.2569071054458618e+00
    phi[8,9]  R2498     -1.3669568300247192e+00
    phi[8,9]  R2499     2.4265724420547485e-01
    phi[8,9]  R2500     -4.9694901704788208e-01
    phi[8,9]  R2501     -1.8981307744979858e+00
    phi[8,9]  R2502     -2.0296809673309326e+00
    phi[8,9]  R2503     -2.8213090896606445e+00
    phi[8,9]  R2504     -3.2015388011932373e+00
    phi[8,9]  R2505     -2.2484495639801025e+00
    phi[8,9]  R2506     -2.9155349731445312e+00
    phi[8,9]  R2507     -1.7014821767807007e+00
    phi[8,9]  R2508     -3.5287301540374756e+00
    phi[8,9]  R2509     3.9704111218452454e-01
    phi[8,9]  R2510     0.804252028465271
    phi[8,9]  R2511     -2.3220794200897217e+00
    phi[8,9]  R2512     -2.1902496814727783e+00
    phi[8,9]  R2513     -1.9956426620483398e+00
    phi[8,9]  R2514     -1.2976610660552979e+00
    phi[8,9]  R2515     1.8850080668926239e-01
    phi[8,9]  R2516     6.0126709938049316e-01
    phi[8,9]  R2517     -2.1008732318878174e+00
    phi[8,9]  R2518     -1.6881601810455322e+00
    phi[8,9]  R2519     1.7028914391994476e-01
    phi[8,9]  R2520     -1.6472191810607910e+00
    phi[8,9]  R2521     -2.7769701480865479e+00
    phi[8,9]  R2522     -4.6070331335067749e-01
    phi[8,9]  R2523     9.9179029464721680e-01
    phi[8,9]  R2524     2.6099207997322083e-01
    phi[8,9]  R2525     -7.5447416305541992e-01
    phi[8,9]  R2526     -2.1522960662841797e+00
    phi[8,9]  R2527     5.0816005468368530e-01
    phi[8,9]  R2528     -4.5597091317176819e-01
    phi[8,9]  R2529     -2.5024855136871338e-01
    phi[8,9]  R2530     -4.2132011055946350e-01
    phi[8,9]  R2531     -4.0459485054016113e+00
    phi[8,9]  R2532     -9.2263534665107727e-02
    phi[8,9]  R2533     -8.2612276077270508e-01
    phi[8,9]  R2534     -7.3497682809829712e-01
    phi[8,9]  R2535     -2.2695848941802979e+00
    phi[8,9]  R2536     4.2320442199707031e-01
    phi[8,9]  R2537     0.848375678062439
    phi[8,9]  R2538     -8.9207589626312256e-01
    phi[8,9]  R2539     2.1412587165832520e-01
    phi[8,9]  R2540     -2.34710955619812
    phi[8,9]  R2541     -1.2710800170898438e+00
    phi[8,9]  R2542     -1.1452230215072632e+00
    phi[8,9]  R2543     -3.3187613487243652e+00
    phi[8,9]  R2544     -1.8820099830627441e+00
    phi[9,8]  R72       -1
    phi[9,8]  R81       1
    phi[9,8]  R82       1
    phi[9,8]  R2545     -3.0999999046325684e+00
    phi[9,8]  R2546     -3.0999999046325684e+00
    phi[9,8]  R2547     -2.2400000095367432e+00
    phi[9,8]  R2548     -2.2400000095367432e+00
    phi[9,8]  R2549     -3.0999999046325684e+00
    phi[9,8]  R2550     -3.0999999046325684e+00
    phi[9,8]  R2551     -2.5699999332427979e+00
    phi[9,8]  R2552     -2.5699999332427979e+00
    phi[9,8]  R2553     -3.0999999046325684e+00
    phi[9,8]  R2554     -3.0999999046325684e+00
    phi[9,8]  R2555     -2.0899999141693115e+00
    phi[9,8]  R2556     -2.0899999141693115e+00
    phi[9,8]  R2557     -3.0999999046325684e+00
    phi[9,8]  R2558     -3.0999999046325684e+00
    phi[9,8]  R2559     2.4218852519989014e+00
    phi[9,8]  R2560     2.5220637321472168e+00
    phi[9,8]  R2561     1.1131941080093384e+00
    phi[9,8]  R2562     1.1744493246078491e+00
    phi[9,8]  R2563     1.5912538766860962e+00
    phi[9,8]  R2564     3.7973856925964355e-01
    phi[9,8]  R2565     1.0533407926559448e+00
    phi[9,8]  R2566     8.3485513925552368e-01
    phi[9,8]  R2567     1.8986371755599976e+00
    phi[9,8]  R2568     1.0723375082015991e+00
    phi[9,8]  R2569     -1.9360895156860352e+00
    phi[9,8]  R2570     -1.6320511102676392e+00
    phi[9,8]  R2571     -6.2603634595870972e-01
    phi[9,8]  R2572     -2.3469505310058594e+00
    phi[9,8]  R2573     -2.6450660228729248e+00
    phi[9,8]  R2574     -1.2432404756546021e+00
    phi[9,8]  R2575     -0.0943642258644104
    phi[9,8]  R2576     -1.6005312204360962e+00
    phi[9,8]  R2577     -3.1433632373809814e+00
    phi[9,8]  R2578     -9.0487170219421387e-01
    phi[9,8]  R2579     -1.3507587909698486e+00
    phi[9,8]  R2580     6.6155597567558289e-02
    phi[9,8]  R2581     -1.2569071054458618e+00
    phi[9,8]  R2582     -1.3669568300247192e+00
    phi[9,8]  R2583     2.4265724420547485e-01
    phi[9,8]  R2584     -4.9694901704788208e-01
    phi[9,8]  R2585     -1.8981307744979858e+00
    phi[9,8]  R2586     -2.0296809673309326e+00
    phi[9,8]  R2587     -2.8213090896606445e+00
    phi[9,8]  R2588     -3.2015388011932373e+00
    phi[9,8]  R2589     -2.2484495639801025e+00
    phi[9,8]  R2590     -2.9155349731445312e+00
    phi[9,8]  R2591     -1.7014821767807007e+00
    phi[9,8]  R2592     -3.5287301540374756e+00
    phi[9,8]  R2593     3.9704111218452454e-01
    phi[9,8]  R2594     0.804252028465271
    phi[9,8]  R2595     -2.3220794200897217e+00
    phi[9,8]  R2596     -2.1902496814727783e+00
    phi[9,8]  R2597     -1.9956426620483398e+00
    phi[9,8]  R2598     -1.2976610660552979e+00
    phi[9,8]  R2599     1.8850080668926239e-01
    phi[9,8]  R2600     6.0126709938049316e-01
    phi[9,8]  R2601     -2.1008732318878174e+00
    phi[9,8]  R2602     -1.6881601810455322e+00
    phi[9,8]  R2603     1.7028914391994476e-01
    phi[9,8]  R2604     -1.6472191810607910e+00
    phi[9,8]  R2605     -2.7769701480865479e+00
    phi[9,8]  R2606     -4.6070331335067749e-01
    phi[9,8]  R2607     9.9179029464721680e-01
    phi[9,8]  R2608     2.6099207997322083e-01
    phi[9,8]  R2609     -7.5447416305541992e-01
    phi[9,8]  R2610     -2.1522960662841797e+00
    phi[9,8]  R2611     5.0816005468368530e-01
    phi[9,8]  R2612     -4.5597091317176819e-01
    phi[9,8]  R2613     -2.5024855136871338e-01
    phi[9,8]  R2614     -4.2132011055946350e-01
    phi[9,8]  R2615     -4.0459485054016113e+00
    phi[9,8]  R2616     -9.2263534665107727e-02
    phi[9,8]  R2617     -8.2612276077270508e-01
    phi[9,8]  R2618     -7.3497682809829712e-01
    phi[9,8]  R2619     -2.2695848941802979e+00
    phi[9,8]  R2620     4.2320442199707031e-01
    phi[9,8]  R2621     0.848375678062439
    phi[9,8]  R2622     -8.9207589626312256e-01
    phi[9,8]  R2623     2.1412587165832520e-01
    phi[9,8]  R2624     -2.34710955619812
    phi[9,8]  R2625     -1.2710800170898438e+00
    phi[9,8]  R2626     -1.1452230215072632e+00
    phi[9,8]  R2627     -3.3187613487243652e+00
    phi[9,8]  R2628     -1.8820099830627441e+00
    phi[9,8]  R2629     1.9104861021041870e+00
    phi[9,8]  R2630     1.2972999811172485e+00
    phi[9,8]  R2631     1.4011027812957764e+00
    phi[9,8]  R2632     1.9408745765686035e+00
    phi[9,8]  R2633     1.1844093799591064e+00
    phi[9,8]  R2634     2.1629805564880371e+00
    phi[9,8]  R2635     2.3864185810089111e+00
    phi[9,8]  R2636     2.3387956619262695e+00
    phi[9,8]  R2637     2.1478676795959473e+00
    phi[9,8]  R2638     7.5916498899459839e-01
    phi[9,8]  R2639     -1.1690975427627563e+00
    phi[9,8]  R2640     -1.5339069366455078e+00
    phi[9,8]  R2641     -3.1076467037200928e+00
    phi[9,8]  R2642     1.7045229673385620e-01
    phi[9,8]  R2643     3.0203115940093994e-01
    phi[9,8]  R2644     -9.4317689538002014e-02
    phi[9,8]  R2645     3.5076677799224854e-02
    phi[9,8]  R2646     -1.5258601903915405e+00
    phi[9,8]  R2647     5.4047244787216187e-01
    phi[9,8]  R2648     -8.9192336797714233e-01
    phi[9,8]  R2649     -2.3142201900482178e+00
    phi[9,8]  R2650     -9.5805382728576660e-01
    phi[9,8]  R2651     -1.6332137584686279e+00
    phi[9,8]  R2652     -1.6407982110977173e+00
    phi[9,8]  R2653     -1.8855262994766235e+00
    phi[9,8]  R2654     -3.4521019458770752e-01
    phi[9,8]  R2655     -1.7276036739349365e+00
    phi[9,8]  R2656     -6.8979871273040771e-01
    phi[9,8]  R2657     -1.8979138135910034e+00
    phi[9,8]  R2658     -1.6546614170074463e+00
    phi[9,8]  R2659     -6.8853902816772461e-01
    phi[9,8]  R2660     1.1091622114181519e+00
    phi[9,8]  R2661     1.6452105045318604e+00
    phi[9,8]  R2662     8.9940857887268066e-01
    phi[9,8]  R2663     5.6285655498504639e-01
    phi[9,8]  R2664     9.4707079231739044e-02
    phi[9,8]  R2665     0.763882040977478
    phi[9,8]  R2666     4.8118868470191956e-01
    phi[9,8]  R2667     1.4307234287261963e+00
    phi[9,8]  R2668     1.2968244552612305e+00
    phi[9,8]  R2669     1.5958026647567749e+00
    phi[9,8]  R2670     8.5172605514526367e-01
    phi[9,8]  R2671     7.4018108844757080e-01
    phi[9,8]  R2672     7.2108995914459229e-01
    phi[9,8]  R2673     8.3887743949890137e-01
    phi[9,8]  R2674     1.5919963121414185e+00
    phi[9,8]  R2675     -1.9614520072937012e+00
    phi[9,8]  R2676     -5.6612402200698853e-01
    phi[9,8]  R2677     -1.5254091024398804e+00
    phi[9,8]  R2678     -1.98341703414917
    phi[9,8]  R2679     -3.6444935202598572e-01
    phi[9,8]  R2680     -1.8875350952148438e+00
    phi[9,8]  R2681     -1.8343496322631836e+00
    phi[9,8]  R2682     -9.6041357517242432e-01
    phi[9,8]  R2683     -1.1572604179382324e+00
    phi[9,8]  R2684     -1.5116691589355469e+00
    phi[9,8]  R2685     -9.7787374258041382e-01
    phi[9,8]  R2686     -1.7108029127120972e+00
    phi[9,8]  R2687     6.0640156269073486e-01
    phi[9,8]  R2688     -2.7840778827667236e+00
    phi[9,10]  R81       1
    phi[9,10]  R82       1
    phi[9,10]  R90       -1
    phi[9,10]  R2689     -3.0999999046325684e+00
    phi[9,10]  R2690     -3.0999999046325684e+00
    phi[9,10]  R2691     -2.2400000095367432e+00
    phi[9,10]  R2692     -2.2400000095367432e+00
    phi[9,10]  R2693     -3.0999999046325684e+00
    phi[9,10]  R2694     -3.0999999046325684e+00
    phi[9,10]  R2695     -2.5699999332427979e+00
    phi[9,10]  R2696     -2.5699999332427979e+00
    phi[9,10]  R2697     -3.0999999046325684e+00
    phi[9,10]  R2698     -3.0999999046325684e+00
    phi[9,10]  R2699     -2.0899999141693115e+00
    phi[9,10]  R2700     -2.0899999141693115e+00
    phi[9,10]  R2701     -3.0999999046325684e+00
    phi[9,10]  R2702     -3.0999999046325684e+00
    phi[9,10]  R2703     2.4218852519989014e+00
    phi[9,10]  R2704     2.5220637321472168e+00
    phi[9,10]  R2705     1.1131941080093384e+00
    phi[9,10]  R2706     1.1744493246078491e+00
    phi[9,10]  R2707     1.5912538766860962e+00
    phi[9,10]  R2708     3.7973856925964355e-01
    phi[9,10]  R2709     1.0533407926559448e+00
    phi[9,10]  R2710     8.3485513925552368e-01
    phi[9,10]  R2711     1.8986371755599976e+00
    phi[9,10]  R2712     1.0723375082015991e+00
    phi[9,10]  R2713     -1.9360895156860352e+00
    phi[9,10]  R2714     -1.6320511102676392e+00
    phi[9,10]  R2715     -6.2603634595870972e-01
    phi[9,10]  R2716     -2.3469505310058594e+00
    phi[9,10]  R2717     -2.6450660228729248e+00
    phi[9,10]  R2718     -1.2432404756546021e+00
    phi[9,10]  R2719     -0.0943642258644104
    phi[9,10]  R2720     -1.6005312204360962e+00
    phi[9,10]  R2721     -3.1433632373809814e+00
    phi[9,10]  R2722     -9.0487170219421387e-01
    phi[9,10]  R2723     -1.3507587909698486e+00
    phi[9,10]  R2724     6.6155597567558289e-02
    phi[9,10]  R2725     -1.2569071054458618e+00
    phi[9,10]  R2726     -1.3669568300247192e+00
    phi[9,10]  R2727     2.4265724420547485e-01
    phi[9,10]  R2728     -4.9694901704788208e-01
    phi[9,10]  R2729     -1.8981307744979858e+00
    phi[9,10]  R2730     -2.0296809673309326e+00
    phi[9,10]  R2731     -2.8213090896606445e+00
    phi[9,10]  R2732     -3.2015388011932373e+00
    phi[9,10]  R2733     -2.2484495639801025e+00
    phi[9,10]  R2734     -2.9155349731445312e+00
    phi[9,10]  R2735     -1.7014821767807007e+00
    phi[9,10]  R2736     -3.5287301540374756e+00
    phi[9,10]  R2737     3.9704111218452454e-01
    phi[9,10]  R2738     0.804252028465271
    phi[9,10]  R2739     -2.3220794200897217e+00
    phi[9,10]  R2740     -2.1902496814727783e+00
    phi[9,10]  R2741     -1.9956426620483398e+00
    phi[9,10]  R2742     -1.2976610660552979e+00
    phi[9,10]  R2743     1.8850080668926239e-01
    phi[9,10]  R2744     6.0126709938049316e-01
    phi[9,10]  R2745     -2.1008732318878174e+00
    phi[9,10]  R2746     -1.6881601810455322e+00
    phi[9,10]  R2747     1.7028914391994476e-01
    phi[9,10]  R2748     -1.6472191810607910e+00
    phi[9,10]  R2749     -2.7769701480865479e+00
    phi[9,10]  R2750     -4.6070331335067749e-01
    phi[9,10]  R2751     9.9179029464721680e-01
    phi[9,10]  R2752     2.6099207997322083e-01
    phi[9,10]  R2753     -7.5447416305541992e-01
    phi[9,10]  R2754     -2.1522960662841797e+00
    phi[9,10]  R2755     5.0816005468368530e-01
    phi[9,10]  R2756     -4.5597091317176819e-01
    phi[9,10]  R2757     -2.5024855136871338e-01
    phi[9,10]  R2758     -4.2132011055946350e-01
    phi[9,10]  R2759     -4.0459485054016113e+00
    phi[9,10]  R2760     -9.2263534665107727e-02
    phi[9,10]  R2761     -8.2612276077270508e-01
    phi[9,10]  R2762     -7.3497682809829712e-01
    phi[9,10]  R2763     -2.2695848941802979e+00
    phi[9,10]  R2764     4.2320442199707031e-01
    phi[9,10]  R2765     0.848375678062439
    phi[9,10]  R2766     -8.9207589626312256e-01
    phi[9,10]  R2767     2.1412587165832520e-01
    phi[9,10]  R2768     -2.34710955619812
    phi[9,10]  R2769     -1.2710800170898438e+00
    phi[9,10]  R2770     -1.1452230215072632e+00
    phi[9,10]  R2771     -3.3187613487243652e+00
    phi[9,10]  R2772     -1.8820099830627441e+00
    phi[9,10]  R2773     1.6034849882125854e+00
    phi[9,10]  R2774     1.8111655712127686e+00
    phi[9,10]  R2775     1.7019549608230591e+00
    phi[9,10]  R2776     9.8893636465072632e-01
    phi[9,10]  R2777     1.6807801723480225e+00
    phi[9,10]  R2778     1.5854493379592896e+00
    phi[9,10]  R2779     0.998877763748169
    phi[9,10]  R2780     1.8693864345550537e+00
    phi[9,10]  R2781     1.9732274115085602e-01
    phi[9,10]  R2782     1.1268581151962280e+00
    phi[9,10]  R2783     -2.33562970161438
    phi[9,10]  R2784     -2.3505096435546875e+00
    phi[9,10]  R2785     -1.5073122978210449e+00
    phi[9,10]  R2786     -7.0644193887710571e-01
    phi[9,10]  R2787     8.0909393727779388e-02
    phi[9,10]  R2788     -5.9340596199035645e-01
    phi[9,10]  R2789     -7.7890384197235107e-01
    phi[9,10]  R2790     -2.1858930587768555e+00
    phi[9,10]  R2791     -5.7323282957077026e-01
    phi[9,10]  R2792     -2.1939802169799805e+00
    phi[9,10]  R2793     -2.0164949893951416e+00
    phi[9,10]  R2794     -1.2315652370452881e+00
    phi[9,10]  R2795     -1.5021522045135498e+00
    phi[9,10]  R2796     -1.6575220823287964e+00
    phi[9,10]  R2797     -1.1053600311279297e+00
    phi[9,10]  R2798     9.0017179027199745e-03
    phi[9,10]  R2799     -1.3707969188690186e+00
    phi[9,10]  R2800     -2.5933270454406738e+00
    phi[9,10]  R2801     -1.6544564068317413e-01
    phi[9,10]  R2802     -8.1910967826843262e-01
    phi[9,10]  R2803     -9.7236263751983643e-01
    phi[9,10]  R2804     -2.1291913986206055e+00
    phi[9,10]  R2805     -2.7167298793792725e+00
    phi[9,10]  R2806     -1.7763613462448120e+00
    phi[9,10]  R2807     -2.5446350574493408e+00
    phi[9,10]  R2808     -1.8559244871139526e+00
    phi[9,10]  R2809     0.992651641368866
    phi[9,10]  R2810     1.4628553390502930e-01
    phi[9,10]  R2811     -1.0963987112045288e+00
    phi[9,10]  R2812     -2.83156681060791
    phi[10,9]  R81       -1
    phi[10,9]  R90       1
    phi[10,9]  R91       1
    phi[10,9]  R2813     -3.0999999046325684e+00
    phi[10,9]  R2814     -3.0999999046325684e+00
    phi[10,9]  R2815     -2.2400000095367432e+00
    phi[10,9]  R2816     -2.2400000095367432e+00
    phi[10,9]  R2817     -3.0999999046325684e+00
    phi[10,9]  R2818     -3.0999999046325684e+00
    phi[10,9]  R2819     -2.5699999332427979e+00
    phi[10,9]  R2820     -2.5699999332427979e+00
    phi[10,9]  R2821     -3.0999999046325684e+00
    phi[10,9]  R2822     -3.0999999046325684e+00
    phi[10,9]  R2823     -2.0899999141693115e+00
    phi[10,9]  R2824     -2.0899999141693115e+00
    phi[10,9]  R2825     -3.0999999046325684e+00
    phi[10,9]  R2826     -3.0999999046325684e+00
    phi[10,9]  R2827     1.6034849882125854e+00
    phi[10,9]  R2828     1.8111655712127686e+00
    phi[10,9]  R2829     1.7019549608230591e+00
    phi[10,9]  R2830     9.8893636465072632e-01
    phi[10,9]  R2831     1.6807801723480225e+00
    phi[10,9]  R2832     1.5854493379592896e+00
    phi[10,9]  R2833     0.998877763748169
    phi[10,9]  R2834     1.8693864345550537e+00
    phi[10,9]  R2835     1.9732274115085602e-01
    phi[10,9]  R2836     1.1268581151962280e+00
    phi[10,9]  R2837     -2.33562970161438
    phi[10,9]  R2838     -2.3505096435546875e+00
    phi[10,9]  R2839     -1.5073122978210449e+00
    phi[10,9]  R2840     -7.0644193887710571e-01
    phi[10,9]  R2841     8.0909393727779388e-02
    phi[10,9]  R2842     -5.9340596199035645e-01
    phi[10,9]  R2843     -7.7890384197235107e-01
    phi[10,9]  R2844     -2.1858930587768555e+00
    phi[10,9]  R2845     -5.7323282957077026e-01
    phi[10,9]  R2846     -2.1939802169799805e+00
    phi[10,9]  R2847     -2.0164949893951416e+00
    phi[10,9]  R2848     -1.2315652370452881e+00
    phi[10,9]  R2849     -1.5021522045135498e+00
    phi[10,9]  R2850     -1.6575220823287964e+00
    phi[10,9]  R2851     -1.1053600311279297e+00
    phi[10,9]  R2852     9.0017179027199745e-03
    phi[10,9]  R2853     -1.3707969188690186e+00
    phi[10,9]  R2854     -2.5933270454406738e+00
    phi[10,9]  R2855     -1.6544564068317413e-01
    phi[10,9]  R2856     -8.1910967826843262e-01
    phi[10,9]  R2857     -9.7236263751983643e-01
    phi[10,9]  R2858     -2.1291913986206055e+00
    phi[10,9]  R2859     -2.7167298793792725e+00
    phi[10,9]  R2860     -1.7763613462448120e+00
    phi[10,9]  R2861     -2.5446350574493408e+00
    phi[10,9]  R2862     -1.8559244871139526e+00
    phi[10,9]  R2863     0.992651641368866
    phi[10,9]  R2864     1.4628553390502930e-01
    phi[10,9]  R2865     -1.0963987112045288e+00
    phi[10,9]  R2866     -2.83156681060791
    phi[10,9]  R2867     2.4218852519989014e+00
    phi[10,9]  R2868     2.5220637321472168e+00
    phi[10,9]  R2869     1.1131941080093384e+00
    phi[10,9]  R2870     1.1744493246078491e+00
    phi[10,9]  R2871     1.5912538766860962e+00
    phi[10,9]  R2872     3.7973856925964355e-01
    phi[10,9]  R2873     1.0533407926559448e+00
    phi[10,9]  R2874     8.3485513925552368e-01
    phi[10,9]  R2875     1.8986371755599976e+00
    phi[10,9]  R2876     1.0723375082015991e+00
    phi[10,9]  R2877     -1.9360895156860352e+00
    phi[10,9]  R2878     -1.6320511102676392e+00
    phi[10,9]  R2879     -6.2603634595870972e-01
    phi[10,9]  R2880     -2.3469505310058594e+00
    phi[10,9]  R2881     -2.6450660228729248e+00
    phi[10,9]  R2882     -1.2432404756546021e+00
    phi[10,9]  R2883     -0.0943642258644104
    phi[10,9]  R2884     -1.6005312204360962e+00
    phi[10,9]  R2885     -3.1433632373809814e+00
    phi[10,9]  R2886     -9.0487170219421387e-01
    phi[10,9]  R2887     -1.3507587909698486e+00
    phi[10,9]  R2888     6.6155597567558289e-02
    phi[10,9]  R2889     -1.2569071054458618e+00
    phi[10,9]  R2890     -1.3669568300247192e+00
    phi[10,9]  R2891     2.4265724420547485e-01
    phi[10,9]  R2892     -4.9694901704788208e-01
    phi[10,9]  R2893     -1.8981307744979858e+00
    phi[10,9]  R2894     -2.0296809673309326e+00
    phi[10,9]  R2895     -2.8213090896606445e+00
    phi[10,9]  R2896     -3.2015388011932373e+00
    phi[10,9]  R2897     -2.2484495639801025e+00
    phi[10,9]  R2898     -2.9155349731445312e+00
    phi[10,9]  R2899     -1.7014821767807007e+00
    phi[10,9]  R2900     -3.5287301540374756e+00
    phi[10,9]  R2901     3.9704111218452454e-01
    phi[10,9]  R2902     0.804252028465271
    phi[10,9]  R2903     -2.3220794200897217e+00
    phi[10,9]  R2904     -2.1902496814727783e+00
    phi[10,9]  R2905     -1.9956426620483398e+00
    phi[10,9]  R2906     -1.2976610660552979e+00
    phi[10,9]  R2907     1.8850080668926239e-01
    phi[10,9]  R2908     6.0126709938049316e-01
    phi[10,9]  R2909     -2.1008732318878174e+00
    phi[10,9]  R2910     -1.6881601810455322e+00
    phi[10,9]  R2911     1.7028914391994476e-01
    phi[10,9]  R2912     -1.6472191810607910e+00
    phi[10,9]  R2913     -2.7769701480865479e+00
    phi[10,9]  R2914     -4.6070331335067749e-01
    phi[10,9]  R2915     9.9179029464721680e-01
    phi[10,9]  R2916     2.6099207997322083e-01
    phi[10,9]  R2917     -7.5447416305541992e-01
    phi[10,9]  R2918     -2.1522960662841797e+00
    phi[10,9]  R2919     5.0816005468368530e-01
    phi[10,9]  R2920     -4.5597091317176819e-01
    phi[10,9]  R2921     -2.5024855136871338e-01
    phi[10,9]  R2922     -4.2132011055946350e-01
    phi[10,9]  R2923     -4.0459485054016113e+00
    phi[10,9]  R2924     -9.2263534665107727e-02
    phi[10,9]  R2925     -8.2612276077270508e-01
    phi[10,9]  R2926     -7.3497682809829712e-01
    phi[10,9]  R2927     -2.2695848941802979e+00
    phi[10,9]  R2928     4.2320442199707031e-01
    phi[10,9]  R2929     0.848375678062439
    phi[10,9]  R2930     -8.9207589626312256e-01
    phi[10,9]  R2931     2.1412587165832520e-01
    phi[10,9]  R2932     -2.34710955619812
    phi[10,9]  R2933     -1.2710800170898438e+00
    phi[10,9]  R2934     -1.1452230215072632e+00
    phi[10,9]  R2935     -3.3187613487243652e+00
    phi[10,9]  R2936     -1.8820099830627441e+00
    MARKER    'MARKER'                 'INTEND'
    z[0,1,0]  R2        -1
    z[0,1,0]  R11       1
    z[0,1,0]  R101      -1
    z[0,1,0]  R102      1
    z[0,1,0]  R115      1.9165323674678802e-01
    z[0,1,0]  R116      -2.0771542191505432e-01
    z[0,1,0]  R117      -1.8366922438144684e-01
    z[0,1,0]  R118      1.3788939453661442e-02
    z[0,1,0]  R119      -2.4287530779838562e-01
    z[0,1,0]  R120      -4.4390112161636353e-01
    z[0,1,0]  R121      -6.6154795885086060e-01
    z[0,1,0]  R122      1.5986666083335876e-02
    z[0,1,0]  R123      9.4537409022450447e-03
    z[0,1,0]  R124      -0.223195418715477
    z[0,1,0]  R125      8.3576333522796631e-01
    z[0,1,0]  R126      1.0334073752164841e-01
    z[0,1,0]  R127      -5.6743121147155762e-01
    z[0,1,0]  R128      -2.2021780908107758e-01
    z[0,1,0]  R129      -5.8450883626937866e-01
    z[0,1,0]  R130      -1.2453515082597733e-01
    z[0,1,0]  R131      -6.3074070215225220e-01
    z[0,1,0]  R132      -0.783804178237915
    z[0,1,0]  R133      -1.2360622733831406e-01
    z[0,1,0]  R134      3.5977676510810852e-01
    z[0,1,0]  R135      2.6436656713485718e-01
    z[0,1,0]  R136      -2.7187108993530273e-01
    z[0,1,0]  R137      -2.3713806271553040e-01
    z[0,1,0]  R138      1.0651174187660217e-01
    z[0,1,0]  R139      2.8235900402069092e-01
    z[0,1,0]  R140      5.9322103857994080e-02
    z[0,1,0]  R141      -6.4567542076110840e-01
    z[0,1,0]  R142      -7.4250477552413940e-01
    z[0,1,0]  R143      -7.2795683145523071e-01
    z[0,1,0]  R144      -5.8998668193817139e-01
    z[0,1,0]  R145      6.9864052347838879e-03
    z[0,1,0]  R146      1.5159071981906891e-01
    z[0,1,0]  R147      -4.3520724773406982e-01
    z[0,1,0]  R148      -3.1087413430213928e-01
    z[0,1,0]  R149      -1.4469125866889954e-01
    z[0,1,0]  R150      -4.7290101647377014e-01
    z[0,1,0]  R151      -5.1100796461105347e-01
    z[0,1,0]  R152      1.3841454684734344e-01
    z[0,1,0]  R153      4.0108391642570496e-01
    z[0,1,0]  R154      1.1373510956764221e-01
    z[0,1,0]  R155      -2.6660263538360596e-01
    z[0,1,0]  R156      -2.3148806393146515e-01
    z[0,1,0]  R157      1.3688498735427856e-01
    z[0,1,0]  R158      7.5992047786712646e-02
    z[0,1,0]  R159      -1.2372570484876633e-01
    z[0,1,0]  R160      -0.128860741853714
    z[0,1,0]  R161      -2.0290514826774597e-01
    z[0,1,0]  R162      -5.3697037696838379e-01
    z[0,1,0]  R163      -1.1369368992745876e-02
    z[0,1,0]  R164      -5.5578452348709106e-01
    z[0,1,0]  R165      0.322528600692749
    z[0,1,0]  R166      1.2251260876655579e-01
    z[0,1,0]  R167      1.1202982813119888e-01
    z[0,1,0]  R168      -0.079043909907341
    z[0,1,0]  R169      1.2563639879226685e-01
    z[0,1,0]  R170      4.3147706985473633e-01
    z[0,1,0]  R171      2.5280410051345825e-01
    z[0,1,0]  R172      4.7436505556106567e-03
    z[0,1,0]  R173      2.2293041646480560e-01
    z[0,1,0]  R174      -0.0975753590464592
    z[0,1,0]  R175      -2.9630562663078308e-01
    z[0,1,0]  R176      -1.5747289359569550e-01
    z[0,1,0]  R177      3.2779577374458313e-01
    z[0,1,0]  R178      -1.8186327815055847e-01
    z[0,1,0]  R179      -2.7668768167495728e-01
    z[0,1,0]  R180      -8.4725864231586456e-02
    z[0,1,0]  R181      2.0847450196743011e-01
    z[0,1,0]  R182      2.8710582852363586e-01
    z[0,1,0]  R183      3.1074506044387817e-01
    z[0,1,0]  R184      3.2126989960670471e-01
    z[0,1,1]  R3        -1
    z[0,1,1]  R12       1
    z[0,1,1]  R103      -1
    z[0,1,1]  R104      1
    z[0,1,1]  R115      -5.8158874511718750e-01
    z[0,1,1]  R116      -7.3835515975952148e-01
    z[0,1,1]  R117      -7.1612530946731567e-01
    z[0,1,1]  R118      9.3383622169494629e-01
    z[0,1,1]  R119      8.0530482530593872e-01
    z[0,1,1]  R120      0.835724413394928
    z[0,1,1]  R121      6.9833201169967651e-01
    z[0,1,1]  R122      -4.9010995030403137e-01
    z[0,1,1]  R123      -5.0764805078506470e-01
    z[0,1,1]  R124      -4.7747588157653809e-01
    z[0,1,1]  R125      -5.9382695704698563e-02
    z[0,1,1]  R126      -4.2601615190505981e-01
    z[0,1,1]  R127      -9.5300465822219849e-02
    z[0,1,1]  R128      1.5859314799308777e-01
    z[0,1,1]  R129      -5.0843423232436180e-03
    z[0,1,1]  R130      1.3745523989200592e-01
    z[0,1,1]  R131      2.2321771085262299e-01
    z[0,1,1]  R132      -3.4024711698293686e-02
    z[0,1,1]  R133      -6.1245895922183990e-02
    z[0,1,1]  R134      3.0732190608978271e-01
    z[0,1,1]  R135      2.5657543540000916e-01
    z[0,1,1]  R136      -9.9763527512550354e-02
    z[0,1,1]  R137      -2.2777697443962097e-01
    z[0,1,1]  R138      1.9558179192245007e-03
    z[0,1,1]  R139      -1.8395036458969116e-01
    z[0,1,1]  R140      1.3640265166759491e-01
    z[0,1,1]  R141      1.4648780226707458e-01
    z[0,1,1]  R142      1.5298567712306976e-01
    z[0,1,1]  R143      2.3878830671310425e-01
    z[0,1,1]  R144      2.1811890602111816e-01
    z[0,1,1]  R145      -2.1872717142105103e-01
    z[0,1,1]  R146      0.0711594671010971
    z[0,1,1]  R147      -4.4952562451362610e-01
    z[0,1,1]  R148      3.8730540871620178e-01
    z[0,1,1]  R149      5.3261183202266693e-02
    z[0,1,1]  R150      2.1477538347244263e-01
    z[0,1,1]  R151      -2.2816047072410583e-01
    z[0,1,1]  R152      3.4862717986106873e-01
    z[0,1,1]  R153      3.0483883619308472e-01
    z[0,1,1]  R154      -0.564039409160614
    z[0,1,1]  R155      -7.6693505048751831e-01
    z[0,1,1]  R156      -6.9930177927017212e-01
    z[0,1,1]  R157      -7.0424813032150269e-01
    z[0,1,1]  R158      -7.2674477100372314e-01
    z[0,1,1]  R159      -6.5514838695526123e-01
    z[0,1,1]  R160      -6.4812636375427246e-01
    z[0,1,1]  R161      -6.4683514833450317e-01
    z[0,1,1]  R162      -0.296928733587265
    z[0,1,1]  R163      -6.0688656568527222e-01
    z[0,1,1]  R164      -3.0988302826881409e-01
    z[0,1,1]  R165      8.4352749586105347e-01
    z[0,1,1]  R166      8.8191956281661987e-01
    z[0,1,1]  R167      9.0987449884414673e-01
    z[0,1,1]  R168      0.946040689945221
    z[0,1,1]  R169      7.7698063850402832e-01
    z[0,1,1]  R170      0.773720383644104
    z[0,1,1]  R171      8.2341051101684570e-01
    z[0,1,1]  R172      8.2002300024032593e-01
    z[0,1,1]  R173      7.7736425399780273e-01
    z[0,1,1]  R174      7.9500550031661987e-01
    z[0,1,1]  R175      -8.6459028720855713e-01
    z[0,1,1]  R176      -7.6453024148941040e-01
    z[0,1,1]  R177      -6.3956683874130249e-01
    z[0,1,1]  R178      -4.3450099229812622e-01
    z[0,1,1]  R179      -3.3394771814346313e-01
    z[0,1,1]  R180      -4.9412319064140320e-01
    z[0,1,1]  R181      8.4681063890457153e-01
    z[0,1,1]  R182      -5.7036370038986206e-01
    z[0,1,1]  R183      6.7065447568893433e-01
    z[0,1,1]  R184      5.8970105648040771e-01
    z[0,1,2]  R4        -1
    z[0,1,2]  R13       1
    z[0,1,2]  R105      -1
    z[0,1,2]  R106      1
    z[0,1,2]  R115      7.2244971990585327e-01
    z[0,1,2]  R116      1.5150021016597748e-01
    z[0,1,2]  R117      -1.7540346086025238e-01
    z[0,1,2]  R118      2.8545374050736427e-02
    z[0,1,2]  R119      4.9569058418273926e-01
    z[0,1,2]  R120      -1.1234133690595627e-01
    z[0,1,2]  R121      2.0229579508304596e-01
    z[0,1,2]  R122      -1.1553539335727692e-01
    z[0,1,2]  R123      -5.2026614546775818e-02
    z[0,1,2]  R124      2.7767020463943481e-01
    z[0,1,2]  R125      -3.6162726581096649e-02
    z[0,1,2]  R126      -6.8504661321640015e-02
    z[0,1,2]  R127      -5.1189231872558594e-01
    z[0,1,2]  R128      -4.5494395494461060e-01
    z[0,1,2]  R129      -7.4862414039671421e-03
    z[0,1,2]  R130      4.7607842087745667e-01
    z[0,1,2]  R131      8.7533473968505859e-02
    z[0,1,2]  R132      -5.5326402187347412e-01
    z[0,1,2]  R133      -5.6598037481307983e-01
    z[0,1,2]  R134      1.8595691770315170e-02
    z[0,1,2]  R135      9.1309905052185059e-01
    z[0,1,2]  R136      4.2580866813659668e-01
    z[0,1,2]  R137      6.6707265377044678e-01
    z[0,1,2]  R138      4.1050103306770325e-01
    z[0,1,2]  R139      -4.7099899500608444e-02
    z[0,1,2]  R140      0.516718864440918
    z[0,1,2]  R141      -6.4277899265289307e-01
    z[0,1,2]  R142      -2.4310082197189331e-01
    z[0,1,2]  R143      -3.3278200030326843e-01
    z[0,1,2]  R144      -2.9201608896255493e-01
    z[0,1,2]  R145      7.5789797306060791e-01
    z[0,1,2]  R146      1.6683810949325562e-01
    z[0,1,2]  R147      4.7264236211776733e-01
    z[0,1,2]  R148      6.4159828424453735e-01
    z[0,1,2]  R149      7.1890002489089966e-01
    z[0,1,2]  R150      7.1373388171195984e-02
    z[0,1,2]  R151      0.0696830004453659
    z[0,1,2]  R152      6.6323804855346680e-01
    z[0,1,2]  R153      -1.9777624309062958e-01
    z[0,1,2]  R154      3.2200655341148376e-01
    z[0,1,2]  R155      -4.4560018181800842e-01
    z[0,1,2]  R156      -1.9278754293918610e-01
    z[0,1,2]  R157      -5.2620077133178711e-01
    z[0,1,2]  R158      -2.5206919759511948e-02
    z[0,1,2]  R159      -0.000703649187926203
    z[0,1,2]  R160      -1.8737143278121948e-01
    z[0,1,2]  R161      -1.7838209867477417e-02
    z[0,1,2]  R162      3.4494474530220032e-01
    z[0,1,2]  R163      5.3917411714792252e-02
    z[0,1,2]  R164      -1.9586580991744995e-01
    z[0,1,2]  R165      -7.7291406691074371e-02
    z[0,1,2]  R166      -1.2138006836175919e-01
    z[0,1,2]  R167      1.0292125493288040e-01
    z[0,1,2]  R168      -1.0032343864440918e-01
    z[0,1,2]  R169      -6.0871934890747070e-01
    z[0,1,2]  R170      4.1946947574615479e-01
    z[0,1,2]  R171      -1.2614218890666962e-01
    z[0,1,2]  R172      -8.2723297178745270e-02
    z[0,1,2]  R173      1.5332648158073425e-01
    z[0,1,2]  R174      1.0726466029882431e-01
    z[0,1,2]  R175      2.6444083452224731e-01
    z[0,1,2]  R176      4.4059496372938156e-02
    z[0,1,2]  R177      3.7639924883842468e-01
    z[0,1,2]  R178      5.7339799404144287e-01
    z[0,1,2]  R179      6.9558018445968628e-01
    z[0,1,2]  R180      1.8632547557353973e-01
    z[0,1,2]  R181      7.9054161906242371e-02
    z[0,1,2]  R182      -5.0351446866989136e-01
    z[0,1,2]  R183      3.1220319867134094e-01
    z[0,1,2]  R184      -1.2036138027906418e-01
    z[0,1,3]  R5        -1
    z[0,1,3]  R14       1
    z[0,1,3]  R107      -1
    z[0,1,3]  R108      1
    z[0,1,3]  R115      -1.8758429586887360e-01
    z[0,1,3]  R116      -8.2432955503463745e-02
    z[0,1,3]  R117      -5.0195151567459106e-01
    z[0,1,3]  R118      -1.7365214228630066e-01
    z[0,1,3]  R119      -1.5692830085754395e-01
    z[0,1,3]  R120      -2.6885411143302917e-01
    z[0,1,3]  R121      -6.5963692963123322e-02
    z[0,1,3]  R122      -4.0872827172279358e-01
    z[0,1,3]  R123      5.3997492790222168e-01
    z[0,1,3]  R124      4.5336952805519104e-01
    z[0,1,3]  R125      4.9107950925827026e-01
    z[0,1,3]  R126      5.2864813804626465e-01
    z[0,1,3]  R127      0.318837970495224
    z[0,1,3]  R128      4.9835193157196045e-01
    z[0,1,3]  R129      1.2492348253726959e-01
    z[0,1,3]  R130      0.495672345161438
    z[0,1,3]  R131      4.1341197490692139e-01
    z[0,1,3]  R132      1.5499453246593475e-01
    z[0,1,3]  R133      3.4000892192125320e-02
    z[0,1,3]  R134      -7.6862221956253052e-01
    z[0,1,3]  R135      -8.8680043816566467e-02
    z[0,1,3]  R136      2.4924033880233765e-01
    z[0,1,3]  R137      3.3963090181350708e-01
    z[0,1,3]  R138      -2.4220287799835205e-01
    z[0,1,3]  R139      -5.2661311626434326e-01
    z[0,1,3]  R140      2.9343172907829285e-01
    z[0,1,3]  R141      2.3093126714229584e-01
    z[0,1,3]  R142      0.24466472864151
    z[0,1,3]  R143      3.4001526236534119e-01
    z[0,1,3]  R144      2.7249908447265625e-01
    z[0,1,3]  R145      -4.5455229282379150e-01
    z[0,1,3]  R146      -5.6906771659851074e-01
    z[0,1,3]  R147      -3.2695877552032471e-01
    z[0,1,3]  R148      -2.5724312663078308e-01
    z[0,1,3]  R149      -2.0146018266677856e-01
    z[0,1,3]  R150      -4.9880608916282654e-01
    z[0,1,3]  R151      -6.2742674350738525e-01
    z[0,1,3]  R152      -0.527021050453186
    z[0,1,3]  R153      -4.4537079334259033e-01
    z[0,1,3]  R154      -3.8205111026763916e-01
    z[0,1,3]  R155      1.2880785763263702e-01
    z[0,1,3]  R156      5.7528215646743774e-01
    z[0,1,3]  R157      3.2055887579917908e-01
    z[0,1,3]  R158      3.7288346886634827e-01
    z[0,1,3]  R159      3.8196507096290588e-01
    z[0,1,3]  R160      1.0356844961643219e-01
    z[0,1,3]  R161      0.500627875328064
    z[0,1,3]  R162      3.7581780552864075e-01
    z[0,1,3]  R163      5.4066902399063110e-01
    z[0,1,3]  R164      3.5347390174865723e-01
    z[0,1,3]  R165      -1.6295136511325836e-01
    z[0,1,3]  R166      3.6049813032150269e-02
    z[0,1,3]  R167      1.4913326501846313e-01
    z[0,1,3]  R168      2.0327532291412354e-01
    z[0,1,3]  R169      -1.2226550839841366e-02
    z[0,1,3]  R170      2.1289777010679245e-02
    z[0,1,3]  R171      -7.7048338949680328e-02
    z[0,1,3]  R172      2.5974312424659729e-01
    z[0,1,3]  R173      2.9298624396324158e-01
    z[0,1,3]  R174      4.4194224476814270e-01
    z[0,1,3]  R175      3.9107095450162888e-02
    z[0,1,3]  R176      1.5430690348148346e-01
    z[0,1,3]  R177      -2.2678783535957336e-01
    z[0,1,3]  R178      2.3870329558849335e-01
    z[0,1,3]  R179      3.9376735687255859e-01
    z[0,1,3]  R180      1.3581918179988861e-01
    z[0,1,3]  R181      1.6972009837627411e-01
    z[0,1,3]  R182      -4.7885257005691528e-01
    z[0,1,3]  R183      -5.0333078950643539e-02
    z[0,1,3]  R184      -3.7363627552986145e-01
    z[0,1,4]  R6        -1
    z[0,1,4]  R15       1
    z[0,1,4]  R109      -1
    z[0,1,4]  R110      1
    z[0,1,4]  R115      -7.0433989167213440e-02
    z[0,1,4]  R116      -2.8365742415189743e-02
    z[0,1,4]  R117      1.2010759115219116e-01
    z[0,1,4]  R118      2.2773268818855286e-01
    z[0,1,4]  R119      1.4585069380700588e-02
    z[0,1,4]  R120      -9.9609516561031342e-02
    z[0,1,4]  R121      1.4132109284400940e-01
    z[0,1,4]  R122      -7.0909923315048218e-01
    z[0,1,4]  R123      -3.0072498321533203e-01
    z[0,1,4]  R124      3.2754909992218018e-01
    z[0,1,4]  R125      1.2776434421539307e-01
    z[0,1,4]  R126      6.3823598623275757e-01
    z[0,1,4]  R127      -3.7490129470825195e-01
    z[0,1,4]  R128      -4.6920531988143921e-01
    z[0,1,4]  R129      -3.2951205968856812e-01
    z[0,1,4]  R130      -5.2944153547286987e-01
    z[0,1,4]  R131      -4.5718041062355042e-01
    z[0,1,4]  R132      8.6935520172119141e-02
    z[0,1,4]  R133      -3.2235914468765259e-01
    z[0,1,4]  R134      -4.1027587652206421e-01
    z[0,1,4]  R135      1.3956440985202789e-01
    z[0,1,4]  R136      3.7994533777236938e-01
    z[0,1,4]  R137      -2.7711486816406250e-01
    z[0,1,4]  R138      5.1074278354644775e-01
    z[0,1,4]  R139      4.3438565731048584e-01
    z[0,1,4]  R140      -2.5611367821693420e-01
    z[0,1,4]  R141      -1.3350901007652283e-01
    z[0,1,4]  R142      -1.4437295496463776e-01
    z[0,1,4]  R143      -3.2478895783424377e-01
    z[0,1,4]  R144      -4.9241924285888672e-01
    z[0,1,4]  R145      3.3072546124458313e-01
    z[0,1,4]  R146      -3.4881818294525146e-01
    z[0,1,4]  R147      -8.8620446622371674e-02
    z[0,1,4]  R148      1.4680328965187073e-01
    z[0,1,4]  R149      -4.4236642122268677e-01
    z[0,1,4]  R150      3.0451798439025879e-01
    z[0,1,4]  R151      5.1750338077545166e-01
    z[0,1,4]  R152      -1.9711346924304962e-01
    z[0,1,4]  R153      6.8620347976684570e-01
    z[0,1,4]  R154      -6.2515747547149658e-01
    z[0,1,4]  R155      1.4192202687263489e-01
    z[0,1,4]  R156      -2.8104245662689209e-02
    z[0,1,4]  R157      1.6148015856742859e-01
    z[0,1,4]  R158      5.4073834419250488e-01
    z[0,1,4]  R159      2.0981565117835999e-01
    z[0,1,4]  R160      5.7631433010101318e-01
    z[0,1,4]  R161      5.0944042205810547e-01
    z[0,1,4]  R162      1.2366279214620590e-01
    z[0,1,4]  R163      2.4005118012428284e-01
    z[0,1,4]  R164      3.2895141839981079e-01
    z[0,1,4]  R165      -9.9299162626266479e-02
    z[0,1,4]  R166      -1.8979972600936890e-01
    z[0,1,4]  R167      -1.4772635698318481e-01
    z[0,1,4]  R168      -1.7982470989227295e-01
    z[0,1,4]  R169      -2.7890071272850037e-02
    z[0,1,4]  R170      -3.4348908811807632e-02
    z[0,1,4]  R171      1.8405571579933167e-01
    z[0,1,4]  R172      -2.1979516744613647e-01
    z[0,1,4]  R173      2.4768868088722229e-01
    z[0,1,4]  R174      2.5145342946052551e-01
    z[0,1,4]  R175      2.6255629956722260e-02
    z[0,1,4]  R176      4.3436667323112488e-01
    z[0,1,4]  R177      3.3053183555603027e-01
    z[0,1,4]  R178      -1.3813333213329315e-01
    z[0,1,4]  R179      -9.9543467164039612e-02
    z[0,1,4]  R180      -3.5761246085166931e-01
    z[0,1,4]  R181      2.8522366285324097e-01
    z[0,1,4]  R182      1.7460164427757263e-01
    z[0,1,4]  R183      5.2828025817871094e-01
    z[0,1,4]  R184      -0.600789487361908
    z[0,1,5]  R7        -1
    z[0,1,5]  R16       1
    z[0,1,5]  R111      -1
    z[0,1,5]  R112      1
    z[0,1,5]  R115      2.5082537531852722e-01
    z[0,1,5]  R116      -5.2510648965835571e-01
    z[0,1,5]  R117      0.197031632065773
    z[0,1,5]  R118      -1.3328030705451965e-01
    z[0,1,5]  R119      0.13209268450737
    z[0,1,5]  R120      9.2718534171581268e-02
    z[0,1,5]  R121      -6.8306297063827515e-02
    z[0,1,5]  R122      1.8461950123310089e-01
    z[0,1,5]  R123      -5.6739258766174316e-01
    z[0,1,5]  R124      -4.6257704496383667e-01
    z[0,1,5]  R125      -1.0151280462741852e-01
    z[0,1,5]  R126      3.4106135368347168e-01
    z[0,1,5]  R127      4.0404829382896423e-01
    z[0,1,5]  R128      4.0645658969879150e-01
    z[0,1,5]  R129      0.683262825012207
    z[0,1,5]  R130      -3.3823895454406738e-01
    z[0,1,5]  R131      3.9669805765151978e-01
    z[0,1,5]  R132      -1.9837960600852966e-01
    z[0,1,5]  R133      6.4588451385498047e-01
    z[0,1,5]  R134      5.3155146539211273e-02
    z[0,1,5]  R135      3.1064342707395554e-02
    z[0,1,5]  R136      -6.4315783977508545e-01
    z[0,1,5]  R137      -4.8138278722763062e-01
    z[0,1,5]  R138      -4.1208752989768982e-01
    z[0,1,5]  R139      -0.163218691945076
    z[0,1,5]  R140      -3.6639320850372314e-01
    z[0,1,5]  R141      2.4201080203056335e-01
    z[0,1,5]  R142      4.7869670391082764e-01
    z[0,1,5]  R143      2.5227880477905273e-01
    z[0,1,5]  R144      4.3468517065048218e-01
    z[0,1,5]  R145      -2.3038573563098907e-01
    z[0,1,5]  R146      -6.5410476922988892e-01
    z[0,1,5]  R147      -4.6232935786247253e-01
    z[0,1,5]  R148      -4.6229395270347595e-01
    z[0,1,5]  R149      -4.3729913234710693e-01
    z[0,1,5]  R150      -4.0501350164413452e-01
    z[0,1,5]  R151      -1.4188054203987122e-01
    z[0,1,5]  R152      0.218091681599617
    z[0,1,5]  R153      -1.7230643332004547e-01
    z[0,1,5]  R154      1.6776913404464722e-01
    z[0,1,5]  R155      -3.0619594454765320e-01
    z[0,1,5]  R156      -2.8887179493904114e-01
    z[0,1,5]  R157      -5.6227338500320911e-03
    z[0,1,5]  R158      5.9849033132195473e-03
    z[0,1,5]  R159      -1.1563264578580856e-01
    z[0,1,5]  R160      2.4274872243404388e-01
    z[0,1,5]  R161      -9.8129369318485260e-02
    z[0,1,5]  R162      4.8437666893005371e-01
    z[0,1,5]  R163      3.0878007411956787e-01
    z[0,1,5]  R164      1.9394531846046448e-01
    z[0,1,5]  R165      -3.2390362024307251e-01
    z[0,1,5]  R166      3.6178052425384521e-01
    z[0,1,5]  R167      -3.2388812303543091e-01
    z[0,1,5]  R168      1.9500320777297020e-02
    z[0,1,5]  R169      2.6371777057647705e-02
    z[0,1,5]  R170      1.2408478558063507e-01
    z[0,1,5]  R171      4.4811934232711792e-01
    z[0,1,5]  R172      -1.1433947831392288e-01
    z[0,1,5]  R173      1.9704459607601166e-01
    z[0,1,5]  R174      4.3167270720005035e-02
    z[0,1,5]  R175      6.1495050787925720e-02
    z[0,1,5]  R176      2.4743005633354187e-01
    z[0,1,5]  R177      -3.8357576727867126e-01
    z[0,1,5]  R178      -6.0128504037857056e-01
    z[0,1,5]  R179      -1.4546290040016174e-01
    z[0,1,5]  R180      -2.5385549664497375e-01
    z[0,1,5]  R181      6.0403876006603241e-02
    z[0,1,5]  R182      2.8038170933723450e-01
    z[0,1,5]  R183      1.4665973186492920e-01
    z[0,1,5]  R184      1.8386904895305634e-01
    z[0,1,6]  R8        -1
    z[0,1,6]  R17       1
    z[0,1,6]  R113      -1
    z[0,1,6]  R114      1
    z[0,1,6]  R115      -5.2762636914849281e-03
    z[0,1,6]  R116      -3.2464897632598877e-01
    z[0,1,6]  R117      -3.4272608160972595e-01
    z[0,1,6]  R118      -1.6481541097164154e-01
    z[0,1,6]  R119      6.7073807120323181e-02
    z[0,1,6]  R120      3.3085864037275314e-02
    z[0,1,6]  R121      -6.9097883999347687e-02
    z[0,1,6]  R122      2.0548319816589355e-01
    z[0,1,6]  R123      1.8855926394462585e-01
    z[0,1,6]  R124      3.4393292665481567e-01
    z[0,1,6]  R125      1.6993522644042969e-01
    z[0,1,6]  R126      1.0680131381377578e-03
    z[0,1,6]  R127      3.7976048886775970e-02
    z[0,1,6]  R128      -2.9268273711204529e-01
    z[0,1,6]  R129      2.5929796695709229e-01
    z[0,1,6]  R130      -3.1391298770904541e-01
    z[0,1,6]  R131      8.5936456918716431e-02
    z[0,1,6]  R132      -8.6352258920669556e-02
    z[0,1,6]  R133      -3.7201926112174988e-01
    z[0,1,6]  R134      -1.1762705445289612e-01
    z[0,1,6]  R135      -4.7139741480350494e-02
    z[0,1,6]  R136      -3.3865770697593689e-01
    z[0,1,6]  R137      1.5174341201782227e-01
    z[0,1,6]  R138      -0.57515549659729
    z[0,1,6]  R139      -6.2575131654739380e-01
    z[0,1,6]  R140      -6.5187150239944458e-01
    z[0,1,6]  R141      1.3695454597473145e-01
    z[0,1,6]  R142      -2.3733739554882050e-01
    z[0,1,6]  R143      0.132560595870018
    z[0,1,6]  R144      -1.1568370461463928e-01
    z[0,1,6]  R145      9.2874079942703247e-02
    z[0,1,6]  R146      -2.6600062847137451e-01
    z[0,1,6]  R147      -2.3796321451663971e-01
    z[0,1,6]  R148      -2.0065556466579437e-01
    z[0,1,6]  R149      1.7862161993980408e-01
    z[0,1,6]  R150      4.6858021616935730e-01
    z[0,1,6]  R151      -1.8807673826813698e-02
    z[0,1,6]  R152      -2.3504647612571716e-01
    z[0,1,6]  R153      -9.0385437011718750e-02
    z[0,1,6]  R154      0.0174432210624218
    z[0,1,6]  R155      1.0809668898582458e-01
    z[0,1,6]  R156      7.0972159504890442e-02
    z[0,1,6]  R157      -2.8203630447387695e-01
    z[0,1,6]  R158      1.8427161872386932e-01
    z[0,1,6]  R159      5.9344846010208130e-01
    z[0,1,6]  R160      -3.5556644201278687e-01
    z[0,1,6]  R161      -1.4257748425006866e-01
    z[0,1,6]  R162      -3.3668524026870728e-01
    z[0,1,6]  R163      -4.2820525169372559e-01
    z[0,1,6]  R164      -5.3473824262619019e-01
    z[0,1,6]  R165      -1.9270603358745575e-01
    z[0,1,6]  R166      -1.5577773749828339e-01
    z[0,1,6]  R167      -4.2021432891488075e-03
    z[0,1,6]  R168      -1.2106308341026306e-01
    z[0,1,6]  R169      9.1403447091579437e-02
    z[0,1,6]  R170      0.148995041847229
    z[0,1,6]  R171      3.9363037794828415e-02
    z[0,1,6]  R172      4.3800309300422668e-01
    z[0,1,6]  R173      -3.6943295598030090e-01
    z[0,1,6]  R174      0.294167160987854
    z[0,1,6]  R175      -2.9792159795761108e-01
    z[0,1,6]  R176      3.3918708562850952e-01
    z[0,1,6]  R177      1.8442739546298981e-01
    z[0,1,6]  R178      1.0837730765342712e-01
    z[0,1,6]  R179      3.7678909301757812e-01
    z[0,1,6]  R180      7.0934516191482544e-01
    z[0,1,6]  R181      3.4553521871566772e-01
    z[0,1,6]  R182      1.8147693946957588e-02
    z[0,1,6]  R183      -2.3036184906959534e-01
    z[0,1,6]  R184      1.3844203203916550e-02
    z[1,0,0]  R2        1
    z[1,0,0]  R11       -1
    z[1,0,0]  R185      -1
    z[1,0,0]  R186      1
    z[1,0,0]  R199      6.9864052347838879e-03
    z[1,0,0]  R200      1.5159071981906891e-01
    z[1,0,0]  R201      -4.3520724773406982e-01
    z[1,0,0]  R202      -3.1087413430213928e-01
    z[1,0,0]  R203      -1.4469125866889954e-01
    z[1,0,0]  R204      -4.7290101647377014e-01
    z[1,0,0]  R205      -5.1100796461105347e-01
    z[1,0,0]  R206      1.3841454684734344e-01
    z[1,0,0]  R207      4.0108391642570496e-01
    z[1,0,0]  R208      1.1373510956764221e-01
    z[1,0,0]  R209      -2.6660263538360596e-01
    z[1,0,0]  R210      -2.3148806393146515e-01
    z[1,0,0]  R211      1.3688498735427856e-01
    z[1,0,0]  R212      7.5992047786712646e-02
    z[1,0,0]  R213      -1.2372570484876633e-01
    z[1,0,0]  R214      -0.128860741853714
    z[1,0,0]  R215      -2.0290514826774597e-01
    z[1,0,0]  R216      -5.3697037696838379e-01
    z[1,0,0]  R217      -1.1369368992745876e-02
    z[1,0,0]  R218      -5.5578452348709106e-01
    z[1,0,0]  R219      0.322528600692749
    z[1,0,0]  R220      1.2251260876655579e-01
    z[1,0,0]  R221      1.1202982813119888e-01
    z[1,0,0]  R222      -0.079043909907341
    z[1,0,0]  R223      1.2563639879226685e-01
    z[1,0,0]  R224      4.3147706985473633e-01
    z[1,0,0]  R225      2.5280410051345825e-01
    z[1,0,0]  R226      4.7436505556106567e-03
    z[1,0,0]  R227      2.2293041646480560e-01
    z[1,0,0]  R228      -0.0975753590464592
    z[1,0,0]  R229      -2.9630562663078308e-01
    z[1,0,0]  R230      -1.5747289359569550e-01
    z[1,0,0]  R231      3.2779577374458313e-01
    z[1,0,0]  R232      -1.8186327815055847e-01
    z[1,0,0]  R233      -2.7668768167495728e-01
    z[1,0,0]  R234      -8.4725864231586456e-02
    z[1,0,0]  R235      2.0847450196743011e-01
    z[1,0,0]  R236      2.8710582852363586e-01
    z[1,0,0]  R237      3.1074506044387817e-01
    z[1,0,0]  R238      3.2126989960670471e-01
    z[1,0,0]  R239      1.9165323674678802e-01
    z[1,0,0]  R240      -2.0771542191505432e-01
    z[1,0,0]  R241      -1.8366922438144684e-01
    z[1,0,0]  R242      1.3788939453661442e-02
    z[1,0,0]  R243      -2.4287530779838562e-01
    z[1,0,0]  R244      -4.4390112161636353e-01
    z[1,0,0]  R245      -6.6154795885086060e-01
    z[1,0,0]  R246      1.5986666083335876e-02
    z[1,0,0]  R247      9.4537409022450447e-03
    z[1,0,0]  R248      -0.223195418715477
    z[1,0,0]  R249      8.3576333522796631e-01
    z[1,0,0]  R250      1.0334073752164841e-01
    z[1,0,0]  R251      -5.6743121147155762e-01
    z[1,0,0]  R252      -2.2021780908107758e-01
    z[1,0,0]  R253      -5.8450883626937866e-01
    z[1,0,0]  R254      -1.2453515082597733e-01
    z[1,0,0]  R255      -6.3074070215225220e-01
    z[1,0,0]  R256      -0.783804178237915
    z[1,0,0]  R257      -1.2360622733831406e-01
    z[1,0,0]  R258      3.5977676510810852e-01
    z[1,0,0]  R259      2.6436656713485718e-01
    z[1,0,0]  R260      -2.7187108993530273e-01
    z[1,0,0]  R261      -2.3713806271553040e-01
    z[1,0,0]  R262      1.0651174187660217e-01
    z[1,0,0]  R263      2.8235900402069092e-01
    z[1,0,0]  R264      5.9322103857994080e-02
    z[1,0,0]  R265      -6.4567542076110840e-01
    z[1,0,0]  R266      -7.4250477552413940e-01
    z[1,0,0]  R267      -7.2795683145523071e-01
    z[1,0,0]  R268      -5.8998668193817139e-01
    z[1,0,1]  R3        1
    z[1,0,1]  R12       -1
    z[1,0,1]  R187      -1
    z[1,0,1]  R188      1
    z[1,0,1]  R199      -2.1872717142105103e-01
    z[1,0,1]  R200      0.0711594671010971
    z[1,0,1]  R201      -4.4952562451362610e-01
    z[1,0,1]  R202      3.8730540871620178e-01
    z[1,0,1]  R203      5.3261183202266693e-02
    z[1,0,1]  R204      2.1477538347244263e-01
    z[1,0,1]  R205      -2.2816047072410583e-01
    z[1,0,1]  R206      3.4862717986106873e-01
    z[1,0,1]  R207      3.0483883619308472e-01
    z[1,0,1]  R208      -0.564039409160614
    z[1,0,1]  R209      -7.6693505048751831e-01
    z[1,0,1]  R210      -6.9930177927017212e-01
    z[1,0,1]  R211      -7.0424813032150269e-01
    z[1,0,1]  R212      -7.2674477100372314e-01
    z[1,0,1]  R213      -6.5514838695526123e-01
    z[1,0,1]  R214      -6.4812636375427246e-01
    z[1,0,1]  R215      -6.4683514833450317e-01
    z[1,0,1]  R216      -0.296928733587265
    z[1,0,1]  R217      -6.0688656568527222e-01
    z[1,0,1]  R218      -3.0988302826881409e-01
    z[1,0,1]  R219      8.4352749586105347e-01
    z[1,0,1]  R220      8.8191956281661987e-01
    z[1,0,1]  R221      9.0987449884414673e-01
    z[1,0,1]  R222      0.946040689945221
    z[1,0,1]  R223      7.7698063850402832e-01
    z[1,0,1]  R224      0.773720383644104
    z[1,0,1]  R225      8.2341051101684570e-01
    z[1,0,1]  R226      8.2002300024032593e-01
    z[1,0,1]  R227      7.7736425399780273e-01
    z[1,0,1]  R228      7.9500550031661987e-01
    z[1,0,1]  R229      -8.6459028720855713e-01
    z[1,0,1]  R230      -7.6453024148941040e-01
    z[1,0,1]  R231      -6.3956683874130249e-01
    z[1,0,1]  R232      -4.3450099229812622e-01
    z[1,0,1]  R233      -3.3394771814346313e-01
    z[1,0,1]  R234      -4.9412319064140320e-01
    z[1,0,1]  R235      8.4681063890457153e-01
    z[1,0,1]  R236      -5.7036370038986206e-01
    z[1,0,1]  R237      6.7065447568893433e-01
    z[1,0,1]  R238      5.8970105648040771e-01
    z[1,0,1]  R239      -5.8158874511718750e-01
    z[1,0,1]  R240      -7.3835515975952148e-01
    z[1,0,1]  R241      -7.1612530946731567e-01
    z[1,0,1]  R242      9.3383622169494629e-01
    z[1,0,1]  R243      8.0530482530593872e-01
    z[1,0,1]  R244      0.835724413394928
    z[1,0,1]  R245      6.9833201169967651e-01
    z[1,0,1]  R246      -4.9010995030403137e-01
    z[1,0,1]  R247      -5.0764805078506470e-01
    z[1,0,1]  R248      -4.7747588157653809e-01
    z[1,0,1]  R249      -5.9382695704698563e-02
    z[1,0,1]  R250      -4.2601615190505981e-01
    z[1,0,1]  R251      -9.5300465822219849e-02
    z[1,0,1]  R252      1.5859314799308777e-01
    z[1,0,1]  R253      -5.0843423232436180e-03
    z[1,0,1]  R254      1.3745523989200592e-01
    z[1,0,1]  R255      2.2321771085262299e-01
    z[1,0,1]  R256      -3.4024711698293686e-02
    z[1,0,1]  R257      -6.1245895922183990e-02
    z[1,0,1]  R258      3.0732190608978271e-01
    z[1,0,1]  R259      2.5657543540000916e-01
    z[1,0,1]  R260      -9.9763527512550354e-02
    z[1,0,1]  R261      -2.2777697443962097e-01
    z[1,0,1]  R262      1.9558179192245007e-03
    z[1,0,1]  R263      -1.8395036458969116e-01
    z[1,0,1]  R264      1.3640265166759491e-01
    z[1,0,1]  R265      1.4648780226707458e-01
    z[1,0,1]  R266      1.5298567712306976e-01
    z[1,0,1]  R267      2.3878830671310425e-01
    z[1,0,1]  R268      2.1811890602111816e-01
    z[1,0,2]  R4        1
    z[1,0,2]  R13       -1
    z[1,0,2]  R189      -1
    z[1,0,2]  R190      1
    z[1,0,2]  R199      7.5789797306060791e-01
    z[1,0,2]  R200      1.6683810949325562e-01
    z[1,0,2]  R201      4.7264236211776733e-01
    z[1,0,2]  R202      6.4159828424453735e-01
    z[1,0,2]  R203      7.1890002489089966e-01
    z[1,0,2]  R204      7.1373388171195984e-02
    z[1,0,2]  R205      0.0696830004453659
    z[1,0,2]  R206      6.6323804855346680e-01
    z[1,0,2]  R207      -1.9777624309062958e-01
    z[1,0,2]  R208      3.2200655341148376e-01
    z[1,0,2]  R209      -4.4560018181800842e-01
    z[1,0,2]  R210      -1.9278754293918610e-01
    z[1,0,2]  R211      -5.2620077133178711e-01
    z[1,0,2]  R212      -2.5206919759511948e-02
    z[1,0,2]  R213      -0.000703649187926203
    z[1,0,2]  R214      -1.8737143278121948e-01
    z[1,0,2]  R215      -1.7838209867477417e-02
    z[1,0,2]  R216      3.4494474530220032e-01
    z[1,0,2]  R217      5.3917411714792252e-02
    z[1,0,2]  R218      -1.9586580991744995e-01
    z[1,0,2]  R219      -7.7291406691074371e-02
    z[1,0,2]  R220      -1.2138006836175919e-01
    z[1,0,2]  R221      1.0292125493288040e-01
    z[1,0,2]  R222      -1.0032343864440918e-01
    z[1,0,2]  R223      -6.0871934890747070e-01
    z[1,0,2]  R224      4.1946947574615479e-01
    z[1,0,2]  R225      -1.2614218890666962e-01
    z[1,0,2]  R226      -8.2723297178745270e-02
    z[1,0,2]  R227      1.5332648158073425e-01
    z[1,0,2]  R228      1.0726466029882431e-01
    z[1,0,2]  R229      2.6444083452224731e-01
    z[1,0,2]  R230      4.4059496372938156e-02
    z[1,0,2]  R231      3.7639924883842468e-01
    z[1,0,2]  R232      5.7339799404144287e-01
    z[1,0,2]  R233      6.9558018445968628e-01
    z[1,0,2]  R234      1.8632547557353973e-01
    z[1,0,2]  R235      7.9054161906242371e-02
    z[1,0,2]  R236      -5.0351446866989136e-01
    z[1,0,2]  R237      3.1220319867134094e-01
    z[1,0,2]  R238      -1.2036138027906418e-01
    z[1,0,2]  R239      7.2244971990585327e-01
    z[1,0,2]  R240      1.5150021016597748e-01
    z[1,0,2]  R241      -1.7540346086025238e-01
    z[1,0,2]  R242      2.8545374050736427e-02
    z[1,0,2]  R243      4.9569058418273926e-01
    z[1,0,2]  R244      -1.1234133690595627e-01
    z[1,0,2]  R245      2.0229579508304596e-01
    z[1,0,2]  R246      -1.1553539335727692e-01
    z[1,0,2]  R247      -5.2026614546775818e-02
    z[1,0,2]  R248      2.7767020463943481e-01
    z[1,0,2]  R249      -3.6162726581096649e-02
    z[1,0,2]  R250      -6.8504661321640015e-02
    z[1,0,2]  R251      -5.1189231872558594e-01
    z[1,0,2]  R252      -4.5494395494461060e-01
    z[1,0,2]  R253      -7.4862414039671421e-03
    z[1,0,2]  R254      4.7607842087745667e-01
    z[1,0,2]  R255      8.7533473968505859e-02
    z[1,0,2]  R256      -5.5326402187347412e-01
    z[1,0,2]  R257      -5.6598037481307983e-01
    z[1,0,2]  R258      1.8595691770315170e-02
    z[1,0,2]  R259      9.1309905052185059e-01
    z[1,0,2]  R260      4.2580866813659668e-01
    z[1,0,2]  R261      6.6707265377044678e-01
    z[1,0,2]  R262      4.1050103306770325e-01
    z[1,0,2]  R263      -4.7099899500608444e-02
    z[1,0,2]  R264      0.516718864440918
    z[1,0,2]  R265      -6.4277899265289307e-01
    z[1,0,2]  R266      -2.4310082197189331e-01
    z[1,0,2]  R267      -3.3278200030326843e-01
    z[1,0,2]  R268      -2.9201608896255493e-01
    z[1,0,3]  R5        1
    z[1,0,3]  R14       -1
    z[1,0,3]  R191      -1
    z[1,0,3]  R192      1
    z[1,0,3]  R199      -4.5455229282379150e-01
    z[1,0,3]  R200      -5.6906771659851074e-01
    z[1,0,3]  R201      -3.2695877552032471e-01
    z[1,0,3]  R202      -2.5724312663078308e-01
    z[1,0,3]  R203      -2.0146018266677856e-01
    z[1,0,3]  R204      -4.9880608916282654e-01
    z[1,0,3]  R205      -6.2742674350738525e-01
    z[1,0,3]  R206      -0.527021050453186
    z[1,0,3]  R207      -4.4537079334259033e-01
    z[1,0,3]  R208      -3.8205111026763916e-01
    z[1,0,3]  R209      1.2880785763263702e-01
    z[1,0,3]  R210      5.7528215646743774e-01
    z[1,0,3]  R211      3.2055887579917908e-01
    z[1,0,3]  R212      3.7288346886634827e-01
    z[1,0,3]  R213      3.8196507096290588e-01
    z[1,0,3]  R214      1.0356844961643219e-01
    z[1,0,3]  R215      0.500627875328064
    z[1,0,3]  R216      3.7581780552864075e-01
    z[1,0,3]  R217      5.4066902399063110e-01
    z[1,0,3]  R218      3.5347390174865723e-01
    z[1,0,3]  R219      -1.6295136511325836e-01
    z[1,0,3]  R220      3.6049813032150269e-02
    z[1,0,3]  R221      1.4913326501846313e-01
    z[1,0,3]  R222      2.0327532291412354e-01
    z[1,0,3]  R223      -1.2226550839841366e-02
    z[1,0,3]  R224      2.1289777010679245e-02
    z[1,0,3]  R225      -7.7048338949680328e-02
    z[1,0,3]  R226      2.5974312424659729e-01
    z[1,0,3]  R227      2.9298624396324158e-01
    z[1,0,3]  R228      4.4194224476814270e-01
    z[1,0,3]  R229      3.9107095450162888e-02
    z[1,0,3]  R230      1.5430690348148346e-01
    z[1,0,3]  R231      -2.2678783535957336e-01
    z[1,0,3]  R232      2.3870329558849335e-01
    z[1,0,3]  R233      3.9376735687255859e-01
    z[1,0,3]  R234      1.3581918179988861e-01
    z[1,0,3]  R235      1.6972009837627411e-01
    z[1,0,3]  R236      -4.7885257005691528e-01
    z[1,0,3]  R237      -5.0333078950643539e-02
    z[1,0,3]  R238      -3.7363627552986145e-01
    z[1,0,3]  R239      -1.8758429586887360e-01
    z[1,0,3]  R240      -8.2432955503463745e-02
    z[1,0,3]  R241      -5.0195151567459106e-01
    z[1,0,3]  R242      -1.7365214228630066e-01
    z[1,0,3]  R243      -1.5692830085754395e-01
    z[1,0,3]  R244      -2.6885411143302917e-01
    z[1,0,3]  R245      -6.5963692963123322e-02
    z[1,0,3]  R246      -4.0872827172279358e-01
    z[1,0,3]  R247      5.3997492790222168e-01
    z[1,0,3]  R248      4.5336952805519104e-01
    z[1,0,3]  R249      4.9107950925827026e-01
    z[1,0,3]  R250      5.2864813804626465e-01
    z[1,0,3]  R251      0.318837970495224
    z[1,0,3]  R252      4.9835193157196045e-01
    z[1,0,3]  R253      1.2492348253726959e-01
    z[1,0,3]  R254      0.495672345161438
    z[1,0,3]  R255      4.1341197490692139e-01
    z[1,0,3]  R256      1.5499453246593475e-01
    z[1,0,3]  R257      3.4000892192125320e-02
    z[1,0,3]  R258      -7.6862221956253052e-01
    z[1,0,3]  R259      -8.8680043816566467e-02
    z[1,0,3]  R260      2.4924033880233765e-01
    z[1,0,3]  R261      3.3963090181350708e-01
    z[1,0,3]  R262      -2.4220287799835205e-01
    z[1,0,3]  R263      -5.2661311626434326e-01
    z[1,0,3]  R264      2.9343172907829285e-01
    z[1,0,3]  R265      2.3093126714229584e-01
    z[1,0,3]  R266      0.24466472864151
    z[1,0,3]  R267      3.4001526236534119e-01
    z[1,0,3]  R268      2.7249908447265625e-01
    z[1,0,4]  R6        1
    z[1,0,4]  R15       -1
    z[1,0,4]  R193      -1
    z[1,0,4]  R194      1
    z[1,0,4]  R199      3.3072546124458313e-01
    z[1,0,4]  R200      -3.4881818294525146e-01
    z[1,0,4]  R201      -8.8620446622371674e-02
    z[1,0,4]  R202      1.4680328965187073e-01
    z[1,0,4]  R203      -4.4236642122268677e-01
    z[1,0,4]  R204      3.0451798439025879e-01
    z[1,0,4]  R205      5.1750338077545166e-01
    z[1,0,4]  R206      -1.9711346924304962e-01
    z[1,0,4]  R207      6.8620347976684570e-01
    z[1,0,4]  R208      -6.2515747547149658e-01
    z[1,0,4]  R209      1.4192202687263489e-01
    z[1,0,4]  R210      -2.8104245662689209e-02
    z[1,0,4]  R211      1.6148015856742859e-01
    z[1,0,4]  R212      5.4073834419250488e-01
    z[1,0,4]  R213      2.0981565117835999e-01
    z[1,0,4]  R214      5.7631433010101318e-01
    z[1,0,4]  R215      5.0944042205810547e-01
    z[1,0,4]  R216      1.2366279214620590e-01
    z[1,0,4]  R217      2.4005118012428284e-01
    z[1,0,4]  R218      3.2895141839981079e-01
    z[1,0,4]  R219      -9.9299162626266479e-02
    z[1,0,4]  R220      -1.8979972600936890e-01
    z[1,0,4]  R221      -1.4772635698318481e-01
    z[1,0,4]  R222      -1.7982470989227295e-01
    z[1,0,4]  R223      -2.7890071272850037e-02
    z[1,0,4]  R224      -3.4348908811807632e-02
    z[1,0,4]  R225      1.8405571579933167e-01
    z[1,0,4]  R226      -2.1979516744613647e-01
    z[1,0,4]  R227      2.4768868088722229e-01
    z[1,0,4]  R228      2.5145342946052551e-01
    z[1,0,4]  R229      2.6255629956722260e-02
    z[1,0,4]  R230      4.3436667323112488e-01
    z[1,0,4]  R231      3.3053183555603027e-01
    z[1,0,4]  R232      -1.3813333213329315e-01
    z[1,0,4]  R233      -9.9543467164039612e-02
    z[1,0,4]  R234      -3.5761246085166931e-01
    z[1,0,4]  R235      2.8522366285324097e-01
    z[1,0,4]  R236      1.7460164427757263e-01
    z[1,0,4]  R237      5.2828025817871094e-01
    z[1,0,4]  R238      -0.600789487361908
    z[1,0,4]  R239      -7.0433989167213440e-02
    z[1,0,4]  R240      -2.8365742415189743e-02
    z[1,0,4]  R241      1.2010759115219116e-01
    z[1,0,4]  R242      2.2773268818855286e-01
    z[1,0,4]  R243      1.4585069380700588e-02
    z[1,0,4]  R244      -9.9609516561031342e-02
    z[1,0,4]  R245      1.4132109284400940e-01
    z[1,0,4]  R246      -7.0909923315048218e-01
    z[1,0,4]  R247      -3.0072498321533203e-01
    z[1,0,4]  R248      3.2754909992218018e-01
    z[1,0,4]  R249      1.2776434421539307e-01
    z[1,0,4]  R250      6.3823598623275757e-01
    z[1,0,4]  R251      -3.7490129470825195e-01
    z[1,0,4]  R252      -4.6920531988143921e-01
    z[1,0,4]  R253      -3.2951205968856812e-01
    z[1,0,4]  R254      -5.2944153547286987e-01
    z[1,0,4]  R255      -4.5718041062355042e-01
    z[1,0,4]  R256      8.6935520172119141e-02
    z[1,0,4]  R257      -3.2235914468765259e-01
    z[1,0,4]  R258      -4.1027587652206421e-01
    z[1,0,4]  R259      1.3956440985202789e-01
    z[1,0,4]  R260      3.7994533777236938e-01
    z[1,0,4]  R261      -2.7711486816406250e-01
    z[1,0,4]  R262      5.1074278354644775e-01
    z[1,0,4]  R263      4.3438565731048584e-01
    z[1,0,4]  R264      -2.5611367821693420e-01
    z[1,0,4]  R265      -1.3350901007652283e-01
    z[1,0,4]  R266      -1.4437295496463776e-01
    z[1,0,4]  R267      -3.2478895783424377e-01
    z[1,0,4]  R268      -4.9241924285888672e-01
    z[1,0,5]  R7        1
    z[1,0,5]  R16       -1
    z[1,0,5]  R195      -1
    z[1,0,5]  R196      1
    z[1,0,5]  R199      -2.3038573563098907e-01
    z[1,0,5]  R200      -6.5410476922988892e-01
    z[1,0,5]  R201      -4.6232935786247253e-01
    z[1,0,5]  R202      -4.6229395270347595e-01
    z[1,0,5]  R203      -4.3729913234710693e-01
    z[1,0,5]  R204      -4.0501350164413452e-01
    z[1,0,5]  R205      -1.4188054203987122e-01
    z[1,0,5]  R206      0.218091681599617
    z[1,0,5]  R207      -1.7230643332004547e-01
    z[1,0,5]  R208      1.6776913404464722e-01
    z[1,0,5]  R209      -3.0619594454765320e-01
    z[1,0,5]  R210      -2.8887179493904114e-01
    z[1,0,5]  R211      -5.6227338500320911e-03
    z[1,0,5]  R212      5.9849033132195473e-03
    z[1,0,5]  R213      -1.1563264578580856e-01
    z[1,0,5]  R214      2.4274872243404388e-01
    z[1,0,5]  R215      -9.8129369318485260e-02
    z[1,0,5]  R216      4.8437666893005371e-01
    z[1,0,5]  R217      3.0878007411956787e-01
    z[1,0,5]  R218      1.9394531846046448e-01
    z[1,0,5]  R219      -3.2390362024307251e-01
    z[1,0,5]  R220      3.6178052425384521e-01
    z[1,0,5]  R221      -3.2388812303543091e-01
    z[1,0,5]  R222      1.9500320777297020e-02
    z[1,0,5]  R223      2.6371777057647705e-02
    z[1,0,5]  R224      1.2408478558063507e-01
    z[1,0,5]  R225      4.4811934232711792e-01
    z[1,0,5]  R226      -1.1433947831392288e-01
    z[1,0,5]  R227      1.9704459607601166e-01
    z[1,0,5]  R228      4.3167270720005035e-02
    z[1,0,5]  R229      6.1495050787925720e-02
    z[1,0,5]  R230      2.4743005633354187e-01
    z[1,0,5]  R231      -3.8357576727867126e-01
    z[1,0,5]  R232      -6.0128504037857056e-01
    z[1,0,5]  R233      -1.4546290040016174e-01
    z[1,0,5]  R234      -2.5385549664497375e-01
    z[1,0,5]  R235      6.0403876006603241e-02
    z[1,0,5]  R236      2.8038170933723450e-01
    z[1,0,5]  R237      1.4665973186492920e-01
    z[1,0,5]  R238      1.8386904895305634e-01
    z[1,0,5]  R239      2.5082537531852722e-01
    z[1,0,5]  R240      -5.2510648965835571e-01
    z[1,0,5]  R241      0.197031632065773
    z[1,0,5]  R242      -1.3328030705451965e-01
    z[1,0,5]  R243      0.13209268450737
    z[1,0,5]  R244      9.2718534171581268e-02
    z[1,0,5]  R245      -6.8306297063827515e-02
    z[1,0,5]  R246      1.8461950123310089e-01
    z[1,0,5]  R247      -5.6739258766174316e-01
    z[1,0,5]  R248      -4.6257704496383667e-01
    z[1,0,5]  R249      -1.0151280462741852e-01
    z[1,0,5]  R250      3.4106135368347168e-01
    z[1,0,5]  R251      4.0404829382896423e-01
    z[1,0,5]  R252      4.0645658969879150e-01
    z[1,0,5]  R253      0.683262825012207
    z[1,0,5]  R254      -3.3823895454406738e-01
    z[1,0,5]  R255      3.9669805765151978e-01
    z[1,0,5]  R256      -1.9837960600852966e-01
    z[1,0,5]  R257      6.4588451385498047e-01
    z[1,0,5]  R258      5.3155146539211273e-02
    z[1,0,5]  R259      3.1064342707395554e-02
    z[1,0,5]  R260      -6.4315783977508545e-01
    z[1,0,5]  R261      -4.8138278722763062e-01
    z[1,0,5]  R262      -4.1208752989768982e-01
    z[1,0,5]  R263      -0.163218691945076
    z[1,0,5]  R264      -3.6639320850372314e-01
    z[1,0,5]  R265      2.4201080203056335e-01
    z[1,0,5]  R266      4.7869670391082764e-01
    z[1,0,5]  R267      2.5227880477905273e-01
    z[1,0,5]  R268      4.3468517065048218e-01
    z[1,0,6]  R8        1
    z[1,0,6]  R17       -1
    z[1,0,6]  R197      -1
    z[1,0,6]  R198      1
    z[1,0,6]  R199      9.2874079942703247e-02
    z[1,0,6]  R200      -2.6600062847137451e-01
    z[1,0,6]  R201      -2.3796321451663971e-01
    z[1,0,6]  R202      -2.0065556466579437e-01
    z[1,0,6]  R203      1.7862161993980408e-01
    z[1,0,6]  R204      4.6858021616935730e-01
    z[1,0,6]  R205      -1.8807673826813698e-02
    z[1,0,6]  R206      -2.3504647612571716e-01
    z[1,0,6]  R207      -9.0385437011718750e-02
    z[1,0,6]  R208      0.0174432210624218
    z[1,0,6]  R209      1.0809668898582458e-01
    z[1,0,6]  R210      7.0972159504890442e-02
    z[1,0,6]  R211      -2.8203630447387695e-01
    z[1,0,6]  R212      1.8427161872386932e-01
    z[1,0,6]  R213      5.9344846010208130e-01
    z[1,0,6]  R214      -3.5556644201278687e-01
    z[1,0,6]  R215      -1.4257748425006866e-01
    z[1,0,6]  R216      -3.3668524026870728e-01
    z[1,0,6]  R217      -4.2820525169372559e-01
    z[1,0,6]  R218      -5.3473824262619019e-01
    z[1,0,6]  R219      -1.9270603358745575e-01
    z[1,0,6]  R220      -1.5577773749828339e-01
    z[1,0,6]  R221      -4.2021432891488075e-03
    z[1,0,6]  R222      -1.2106308341026306e-01
    z[1,0,6]  R223      9.1403447091579437e-02
    z[1,0,6]  R224      0.148995041847229
    z[1,0,6]  R225      3.9363037794828415e-02
    z[1,0,6]  R226      4.3800309300422668e-01
    z[1,0,6]  R227      -3.6943295598030090e-01
    z[1,0,6]  R228      0.294167160987854
    z[1,0,6]  R229      -2.9792159795761108e-01
    z[1,0,6]  R230      3.3918708562850952e-01
    z[1,0,6]  R231      1.8442739546298981e-01
    z[1,0,6]  R232      1.0837730765342712e-01
    z[1,0,6]  R233      3.7678909301757812e-01
    z[1,0,6]  R234      7.0934516191482544e-01
    z[1,0,6]  R235      3.4553521871566772e-01
    z[1,0,6]  R236      1.8147693946957588e-02
    z[1,0,6]  R237      -2.3036184906959534e-01
    z[1,0,6]  R238      1.3844203203916550e-02
    z[1,0,6]  R239      -5.2762636914849281e-03
    z[1,0,6]  R240      -3.2464897632598877e-01
    z[1,0,6]  R241      -3.4272608160972595e-01
    z[1,0,6]  R242      -1.6481541097164154e-01
    z[1,0,6]  R243      6.7073807120323181e-02
    z[1,0,6]  R244      3.3085864037275314e-02
    z[1,0,6]  R245      -6.9097883999347687e-02
    z[1,0,6]  R246      2.0548319816589355e-01
    z[1,0,6]  R247      1.8855926394462585e-01
    z[1,0,6]  R248      3.4393292665481567e-01
    z[1,0,6]  R249      1.6993522644042969e-01
    z[1,0,6]  R250      1.0680131381377578e-03
    z[1,0,6]  R251      3.7976048886775970e-02
    z[1,0,6]  R252      -2.9268273711204529e-01
    z[1,0,6]  R253      2.5929796695709229e-01
    z[1,0,6]  R254      -3.1391298770904541e-01
    z[1,0,6]  R255      8.5936456918716431e-02
    z[1,0,6]  R256      -8.6352258920669556e-02
    z[1,0,6]  R257      -3.7201926112174988e-01
    z[1,0,6]  R258      -1.1762705445289612e-01
    z[1,0,6]  R259      -4.7139741480350494e-02
    z[1,0,6]  R260      -3.3865770697593689e-01
    z[1,0,6]  R261      1.5174341201782227e-01
    z[1,0,6]  R262      -0.57515549659729
    z[1,0,6]  R263      -6.2575131654739380e-01
    z[1,0,6]  R264      -6.5187150239944458e-01
    z[1,0,6]  R265      1.3695454597473145e-01
    z[1,0,6]  R266      -2.3733739554882050e-01
    z[1,0,6]  R267      0.132560595870018
    z[1,0,6]  R268      -1.1568370461463928e-01
    z[0,6,0]  R2        -1
    z[0,6,0]  R56       1
    z[0,6,0]  R269      -1
    z[0,6,0]  R270      1
    z[0,6,0]  R283      1.9165323674678802e-01
    z[0,6,0]  R284      -2.0771542191505432e-01
    z[0,6,0]  R285      -1.8366922438144684e-01
    z[0,6,0]  R286      1.3788939453661442e-02
    z[0,6,0]  R287      -2.4287530779838562e-01
    z[0,6,0]  R288      -4.4390112161636353e-01
    z[0,6,0]  R289      -6.6154795885086060e-01
    z[0,6,0]  R290      1.5986666083335876e-02
    z[0,6,0]  R291      9.4537409022450447e-03
    z[0,6,0]  R292      -0.223195418715477
    z[0,6,0]  R293      8.3576333522796631e-01
    z[0,6,0]  R294      1.0334073752164841e-01
    z[0,6,0]  R295      -5.6743121147155762e-01
    z[0,6,0]  R296      -2.2021780908107758e-01
    z[0,6,0]  R297      -5.8450883626937866e-01
    z[0,6,0]  R298      -1.2453515082597733e-01
    z[0,6,0]  R299      -6.3074070215225220e-01
    z[0,6,0]  R300      -0.783804178237915
    z[0,6,0]  R301      -1.2360622733831406e-01
    z[0,6,0]  R302      3.5977676510810852e-01
    z[0,6,0]  R303      2.6436656713485718e-01
    z[0,6,0]  R304      -2.7187108993530273e-01
    z[0,6,0]  R305      -2.3713806271553040e-01
    z[0,6,0]  R306      1.0651174187660217e-01
    z[0,6,0]  R307      2.8235900402069092e-01
    z[0,6,0]  R308      5.9322103857994080e-02
    z[0,6,0]  R309      -6.4567542076110840e-01
    z[0,6,0]  R310      -7.4250477552413940e-01
    z[0,6,0]  R311      -7.2795683145523071e-01
    z[0,6,0]  R312      -5.8998668193817139e-01
    z[0,6,0]  R313      7.8719757497310638e-02
    z[0,6,0]  R314      -2.2840353846549988e-01
    z[0,6,0]  R315      1.3082465529441833e-01
    z[0,6,0]  R316      1.0154388844966888e-01
    z[0,6,0]  R317      1.2037665396928787e-01
    z[0,6,0]  R318      0.0824347734451294
    z[0,6,0]  R319      1.9508653879165649e-01
    z[0,6,0]  R320      2.8252487536519766e-03
    z[0,6,0]  R321      2.1544551849365234e-01
    z[0,6,0]  R322      4.5590769499540329e-02
    z[0,6,0]  R323      -0.0512348935008049
    z[0,6,0]  R324      -1.2200195342302322e-01
    z[0,6,0]  R325      -2.1726453304290771e-01
    z[0,6,0]  R326      -3.8343787193298340e-02
    z[0,6,0]  R327      1.0439215600490570e-01
    z[0,6,0]  R328      -7.3072470724582672e-02
    z[0,6,0]  R329      4.4909365475177765e-02
    z[0,6,0]  R330      -1.7582283914089203e-01
    z[0,6,0]  R331      -8.9845836162567139e-02
    z[0,6,0]  R332      3.3339053392410278e-02
    z[0,6,0]  R333      2.1200221776962280e-01
    z[0,6,0]  R334      -4.7757747769355774e-01
    z[0,6,0]  R335      -4.9179589748382568e-01
    z[0,6,0]  R336      2.4503467977046967e-01
    z[0,6,0]  R337      2.7563998103141785e-01
    z[0,6,0]  R338      7.6668816804885864e-01
    z[0,6,0]  R339      1.8436676263809204e-01
    z[0,6,0]  R340      5.9189713001251221e-01
    z[0,6,0]  R341      0.696549654006958
    z[0,6,0]  R342      6.2079501152038574e-01
    z[0,6,0]  R343      -1.2762364745140076e-01
    z[0,6,0]  R344      1.1209373921155930e-01
    z[0,6,0]  R345      3.8395129144191742e-02
    z[0,6,0]  R346      -7.3095254600048065e-02
    z[0,6,0]  R347      4.0898665785789490e-01
    z[0,6,0]  R348      2.8859421610832214e-01
    z[0,6,0]  R349      7.1428376436233521e-01
    z[0,6,0]  R350      4.9701672792434692e-01
    z[0,6,1]  R3        -1
    z[0,6,1]  R57       1
    z[0,6,1]  R271      -1
    z[0,6,1]  R272      1
    z[0,6,1]  R283      -5.8158874511718750e-01
    z[0,6,1]  R284      -7.3835515975952148e-01
    z[0,6,1]  R285      -7.1612530946731567e-01
    z[0,6,1]  R286      9.3383622169494629e-01
    z[0,6,1]  R287      8.0530482530593872e-01
    z[0,6,1]  R288      0.835724413394928
    z[0,6,1]  R289      6.9833201169967651e-01
    z[0,6,1]  R290      -4.9010995030403137e-01
    z[0,6,1]  R291      -5.0764805078506470e-01
    z[0,6,1]  R292      -4.7747588157653809e-01
    z[0,6,1]  R293      -5.9382695704698563e-02
    z[0,6,1]  R294      -4.2601615190505981e-01
    z[0,6,1]  R295      -9.5300465822219849e-02
    z[0,6,1]  R296      1.5859314799308777e-01
    z[0,6,1]  R297      -5.0843423232436180e-03
    z[0,6,1]  R298      1.3745523989200592e-01
    z[0,6,1]  R299      2.2321771085262299e-01
    z[0,6,1]  R300      -3.4024711698293686e-02
    z[0,6,1]  R301      -6.1245895922183990e-02
    z[0,6,1]  R302      3.0732190608978271e-01
    z[0,6,1]  R303      2.5657543540000916e-01
    z[0,6,1]  R304      -9.9763527512550354e-02
    z[0,6,1]  R305      -2.2777697443962097e-01
    z[0,6,1]  R306      1.9558179192245007e-03
    z[0,6,1]  R307      -1.8395036458969116e-01
    z[0,6,1]  R308      1.3640265166759491e-01
    z[0,6,1]  R309      1.4648780226707458e-01
    z[0,6,1]  R310      1.5298567712306976e-01
    z[0,6,1]  R311      2.3878830671310425e-01
    z[0,6,1]  R312      2.1811890602111816e-01
    z[0,6,1]  R313      -0.714492917060852
    z[0,6,1]  R314      -0.766794741153717
    z[0,6,1]  R315      -5.3733867406845093e-01
    z[0,6,1]  R316      -5.0333178043365479e-01
    z[0,6,1]  R317      -5.2201277017593384e-01
    z[0,6,1]  R318      -5.6424331665039062e-01
    z[0,6,1]  R319      -4.1130667924880981e-01
    z[0,6,1]  R320      -4.8473531007766724e-01
    z[0,6,1]  R321      -3.9754891395568848e-01
    z[0,6,1]  R322      -4.9129721522331238e-01
    z[0,6,1]  R323      8.9774513244628906e-01
    z[0,6,1]  R324      8.4161835908889771e-01
    z[0,6,1]  R325      9.2137068510055542e-01
    z[0,6,1]  R326      9.0582871437072754e-01
    z[0,6,1]  R327      8.6860394477844238e-01
    z[0,6,1]  R328      8.5018402338027954e-01
    z[0,6,1]  R329      8.3546936511993408e-01
    z[0,6,1]  R330      0.864683210849762
    z[0,6,1]  R331      0.888593316078186
    z[0,6,1]  R332      0.855954110622406
    z[0,6,1]  R333      -6.3495159149169922e-01
    z[0,6,1]  R334      -6.0940831899642944e-01
    z[0,6,1]  R335      -6.0587811470031738e-01
    z[0,6,1]  R336      -6.5649712085723877e-01
    z[0,6,1]  R337      7.5388967990875244e-01
    z[0,6,1]  R338      -5.9504695236682892e-02
    z[0,6,1]  R339      6.7608863115310669e-01
    z[0,6,1]  R340      4.4767209887504578e-01
    z[0,6,1]  R341      5.8056843280792236e-01
    z[0,6,1]  R342      4.1099786758422852e-01
    z[0,6,1]  R343      -0.734729528427124
    z[0,6,1]  R344      -4.5898100733757019e-01
    z[0,6,1]  R345      9.5731109380722046e-01
    z[0,6,1]  R346      8.5355150699615479e-01
    z[0,6,1]  R347      7.0696151256561279e-01
    z[0,6,1]  R348      6.4644461870193481e-01
    z[0,6,1]  R349      5.7346242666244507e-01
    z[0,6,1]  R350      5.3231346607208252e-01
    z[0,6,2]  R4        -1
    z[0,6,2]  R58       1
    z[0,6,2]  R273      -1
    z[0,6,2]  R274      1
    z[0,6,2]  R283      7.2244971990585327e-01
    z[0,6,2]  R284      1.5150021016597748e-01
    z[0,6,2]  R285      -1.7540346086025238e-01
    z[0,6,2]  R286      2.8545374050736427e-02
    z[0,6,2]  R287      4.9569058418273926e-01
    z[0,6,2]  R288      -1.1234133690595627e-01
    z[0,6,2]  R289      2.0229579508304596e-01
    z[0,6,2]  R290      -1.1553539335727692e-01
    z[0,6,2]  R291      -5.2026614546775818e-02
    z[0,6,2]  R292      2.7767020463943481e-01
    z[0,6,2]  R293      -3.6162726581096649e-02
    z[0,6,2]  R294      -6.8504661321640015e-02
    z[0,6,2]  R295      -5.1189231872558594e-01
    z[0,6,2]  R296      -4.5494395494461060e-01
    z[0,6,2]  R297      -7.4862414039671421e-03
    z[0,6,2]  R298      4.7607842087745667e-01
    z[0,6,2]  R299      8.7533473968505859e-02
    z[0,6,2]  R300      -5.5326402187347412e-01
    z[0,6,2]  R301      -5.6598037481307983e-01
    z[0,6,2]  R302      1.8595691770315170e-02
    z[0,6,2]  R303      9.1309905052185059e-01
    z[0,6,2]  R304      4.2580866813659668e-01
    z[0,6,2]  R305      6.6707265377044678e-01
    z[0,6,2]  R306      4.1050103306770325e-01
    z[0,6,2]  R307      -4.7099899500608444e-02
    z[0,6,2]  R308      0.516718864440918
    z[0,6,2]  R309      -6.4277899265289307e-01
    z[0,6,2]  R310      -2.4310082197189331e-01
    z[0,6,2]  R311      -3.3278200030326843e-01
    z[0,6,2]  R312      -2.9201608896255493e-01
    z[0,6,2]  R313      6.1780065298080444e-03
    z[0,6,2]  R314      8.0064445734024048e-02
    z[0,6,2]  R315      2.7129095792770386e-01
    z[0,6,2]  R316      5.1973092555999756e-01
    z[0,6,2]  R317      -3.9048162102699280e-01
    z[0,6,2]  R318      -3.5271200537681580e-01
    z[0,6,2]  R319      5.1109284162521362e-01
    z[0,6,2]  R320      -6.6421443223953247e-01
    z[0,6,2]  R321      -2.9589393734931946e-01
    z[0,6,2]  R322      3.9483693242073059e-01
    z[0,6,2]  R323      3.2043972611427307e-01
    z[0,6,2]  R324      3.9753416180610657e-01
    z[0,6,2]  R325      1.2810868024826050e-01
    z[0,6,2]  R326      -1.6346798837184906e-01
    z[0,6,2]  R327      5.8403205126523972e-02
    z[0,6,2]  R328      -3.0593705177307129e-01
    z[0,6,2]  R329      2.2055111825466156e-01
    z[0,6,2]  R330      -1.0309773683547974e-01
    z[0,6,2]  R331      -2.7790832519531250e-01
    z[0,6,2]  R332      3.0476909875869751e-01
    z[0,6,2]  R333      4.0077927405945957e-04
    z[0,6,2]  R334      4.0916711091995239e-02
    z[0,6,2]  R335      -2.0590171217918396e-01
    z[0,6,2]  R336      4.6840527653694153e-01
    z[0,6,2]  R337      -2.1393741667270660e-01
    z[0,6,2]  R338      -1.8920238316059113e-01
    z[0,6,2]  R339      1.3858684897422791e-01
    z[0,6,2]  R340      8.5976555943489075e-02
    z[0,6,2]  R341      1.5089520812034607e-01
    z[0,6,2]  R342      1.0470622032880783e-01
    z[0,6,2]  R343      -3.7842476367950439e-01
    z[0,6,2]  R344      -2.8487798571586609e-01
    z[0,6,2]  R345      -2.5255424901843071e-02
    z[0,6,2]  R346      -2.4526433646678925e-01
    z[0,6,2]  R347      2.4254019558429718e-01
    z[0,6,2]  R348      -2.1440829336643219e-01
    z[0,6,2]  R349      2.0959307253360748e-01
    z[0,6,2]  R350      2.2036673128604889e-01
    z[0,6,3]  R5        -1
    z[0,6,3]  R59       1
    z[0,6,3]  R275      -1
    z[0,6,3]  R276      1
    z[0,6,3]  R283      -1.8758429586887360e-01
    z[0,6,3]  R284      -8.2432955503463745e-02
    z[0,6,3]  R285      -5.0195151567459106e-01
    z[0,6,3]  R286      -1.7365214228630066e-01
    z[0,6,3]  R287      -1.5692830085754395e-01
    z[0,6,3]  R288      -2.6885411143302917e-01
    z[0,6,3]  R289      -6.5963692963123322e-02
    z[0,6,3]  R290      -4.0872827172279358e-01
    z[0,6,3]  R291      5.3997492790222168e-01
    z[0,6,3]  R292      4.5336952805519104e-01
    z[0,6,3]  R293      4.9107950925827026e-01
    z[0,6,3]  R294      5.2864813804626465e-01
    z[0,6,3]  R295      0.318837970495224
    z[0,6,3]  R296      4.9835193157196045e-01
    z[0,6,3]  R297      1.2492348253726959e-01
    z[0,6,3]  R298      0.495672345161438
    z[0,6,3]  R299      4.1341197490692139e-01
    z[0,6,3]  R300      1.5499453246593475e-01
    z[0,6,3]  R301      3.4000892192125320e-02
    z[0,6,3]  R302      -7.6862221956253052e-01
    z[0,6,3]  R303      -8.8680043816566467e-02
    z[0,6,3]  R304      2.4924033880233765e-01
    z[0,6,3]  R305      3.3963090181350708e-01
    z[0,6,3]  R306      -2.4220287799835205e-01
    z[0,6,3]  R307      -5.2661311626434326e-01
    z[0,6,3]  R308      2.9343172907829285e-01
    z[0,6,3]  R309      2.3093126714229584e-01
    z[0,6,3]  R310      0.24466472864151
    z[0,6,3]  R311      3.4001526236534119e-01
    z[0,6,3]  R312      2.7249908447265625e-01
    z[0,6,3]  R313      3.3091518282890320e-01
    z[0,6,3]  R314      -2.2827278077602386e-01
    z[0,6,3]  R315      -2.8170111775398254e-01
    z[0,6,3]  R316      -5.0733107328414917e-01
    z[0,6,3]  R317      6.6642665863037109e-01
    z[0,6,3]  R318      -5.4064452648162842e-01
    z[0,6,3]  R319      3.9117965102195740e-01
    z[0,6,3]  R320      -0.279350608587265
    z[0,6,3]  R321      -3.5979685187339783e-01
    z[0,6,3]  R322      7.2067701816558838e-01
    z[0,6,3]  R323      2.5874990224838257e-01
    z[0,6,3]  R324      2.4203525483608246e-01
    z[0,6,3]  R325      -1.8975268304347992e-01
    z[0,6,3]  R326      -1.5461277961730957e-01
    z[0,6,3]  R327      -3.5554841160774231e-02
    z[0,6,3]  R328      -1.0980086028575897e-01
    z[0,6,3]  R329      8.6332093924283981e-03
    z[0,6,3]  R330      4.7490164637565613e-02
    z[0,6,3]  R331      2.8536167740821838e-01
    z[0,6,3]  R332      2.3685184121131897e-01
    z[0,6,3]  R333      2.6239043474197388e-01
    z[0,6,3]  R334      -2.1712154150009155e-01
    z[0,6,3]  R335      1.7849530279636383e-01
    z[0,6,3]  R336      3.1665435433387756e-01
    z[0,6,3]  R337      -2.5579133629798889e-01
    z[0,6,3]  R338      1.0500301420688629e-01
    z[0,6,3]  R339      4.6437028795480728e-02
    z[0,6,3]  R340      -4.8745346069335938e-01
    z[0,6,3]  R341      -2.7795964479446411e-01
    z[0,6,3]  R342      -5.9017390012741089e-01
    z[0,6,3]  R343      -1.5690918266773224e-01
    z[0,6,3]  R344      3.5372716188430786e-01
    z[0,6,3]  R345      -7.4609339237213135e-02
    z[0,6,3]  R346      -3.0010592937469482e-01
    z[0,6,3]  R347      -1.9031988084316254e-01
    z[0,6,3]  R348      -5.6362503767013550e-01
    z[0,6,3]  R349      -0.260911226272583
    z[0,6,3]  R350      -5.5483013391494751e-01
    z[0,6,4]  R6        -1
    z[0,6,4]  R60       1
    z[0,6,4]  R277      -1
    z[0,6,4]  R278      1
    z[0,6,4]  R283      -7.0433989167213440e-02
    z[0,6,4]  R284      -2.8365742415189743e-02
    z[0,6,4]  R285      1.2010759115219116e-01
    z[0,6,4]  R286      2.2773268818855286e-01
    z[0,6,4]  R287      1.4585069380700588e-02
    z[0,6,4]  R288      -9.9609516561031342e-02
    z[0,6,4]  R289      1.4132109284400940e-01
    z[0,6,4]  R290      -7.0909923315048218e-01
    z[0,6,4]  R291      -3.0072498321533203e-01
    z[0,6,4]  R292      3.2754909992218018e-01
    z[0,6,4]  R293      1.2776434421539307e-01
    z[0,6,4]  R294      6.3823598623275757e-01
    z[0,6,4]  R295      -3.7490129470825195e-01
    z[0,6,4]  R296      -4.6920531988143921e-01
    z[0,6,4]  R297      -3.2951205968856812e-01
    z[0,6,4]  R298      -5.2944153547286987e-01
    z[0,6,4]  R299      -4.5718041062355042e-01
    z[0,6,4]  R300      8.6935520172119141e-02
    z[0,6,4]  R301      -3.2235914468765259e-01
    z[0,6,4]  R302      -4.1027587652206421e-01
    z[0,6,4]  R303      1.3956440985202789e-01
    z[0,6,4]  R304      3.7994533777236938e-01
    z[0,6,4]  R305      -2.7711486816406250e-01
    z[0,6,4]  R306      5.1074278354644775e-01
    z[0,6,4]  R307      4.3438565731048584e-01
    z[0,6,4]  R308      -2.5611367821693420e-01
    z[0,6,4]  R309      -1.3350901007652283e-01
    z[0,6,4]  R310      -1.4437295496463776e-01
    z[0,6,4]  R311      -3.2478895783424377e-01
    z[0,6,4]  R312      -4.9241924285888672e-01
    z[0,6,4]  R313      3.1219854950904846e-01
    z[0,6,4]  R314      -5.9438440948724747e-02
    z[0,6,4]  R315      -7.0988601446151733e-01
    z[0,6,4]  R316      -2.6318114995956421e-01
    z[0,6,4]  R317      -1.6919200122356415e-01
    z[0,6,4]  R318      -3.7650740146636963e-01
    z[0,6,4]  R319      -2.1941165626049042e-01
    z[0,6,4]  R320      -2.4052104353904724e-01
    z[0,6,4]  R321      4.3770986795425415e-01
    z[0,6,4]  R322      1.5775993466377258e-01
    z[0,6,4]  R323      -1.2614172697067261e-01
    z[0,6,4]  R324      2.4360871315002441e-01
    z[0,6,4]  R325      7.9051433131098747e-03
    z[0,6,4]  R326      1.9794492423534393e-01
    z[0,6,4]  R327      3.7752953171730042e-01
    z[0,6,4]  R328      -3.6943656206130981e-01
    z[0,6,4]  R329      -2.7956220507621765e-01
    z[0,6,4]  R330      -2.5055420398712158e-01
    z[0,6,4]  R331      -4.9570269882678986e-02
    z[0,6,4]  R332      2.6393425464630127e-01
    z[0,6,4]  R333      6.4228612184524536e-01
    z[0,6,4]  R334      5.7015073299407959e-01
    z[0,6,4]  R335      2.4942095577716827e-01
    z[0,6,4]  R336      2.1850416064262390e-01
    z[0,6,4]  R337      1.6406890749931335e-01
    z[0,6,4]  R338      -4.2165097594261169e-01
    z[0,6,4]  R339      -4.4154065847396851e-01
    z[0,6,4]  R340      7.8501164913177490e-02
    z[0,6,4]  R341      -1.6236285865306854e-01
    z[0,6,4]  R342      -1.1570196598768234e-02
    z[0,6,4]  R343      -3.2835006713867188e-01
    z[0,6,4]  R344      5.7537955045700073e-01
    z[0,6,4]  R345      -1.9492319226264954e-01
    z[0,6,4]  R346      -1.7925573885440826e-01
    z[0,6,4]  R347      -1.6380502283573151e-01
    z[0,6,4]  R348      -0.260452002286911
    z[0,6,4]  R349      6.8050853908061981e-02
    z[0,6,4]  R350      -9.8680742084980011e-02
    z[0,6,5]  R7        -1
    z[0,6,5]  R61       1
    z[0,6,5]  R279      -1
    z[0,6,5]  R280      1
    z[0,6,5]  R283      2.5082537531852722e-01
    z[0,6,5]  R284      -5.2510648965835571e-01
    z[0,6,5]  R285      0.197031632065773
    z[0,6,5]  R286      -1.3328030705451965e-01
    z[0,6,5]  R287      0.13209268450737
    z[0,6,5]  R288      9.2718534171581268e-02
    z[0,6,5]  R289      -6.8306297063827515e-02
    z[0,6,5]  R290      1.8461950123310089e-01
    z[0,6,5]  R291      -5.6739258766174316e-01
    z[0,6,5]  R292      -4.6257704496383667e-01
    z[0,6,5]  R293      -1.0151280462741852e-01
    z[0,6,5]  R294      3.4106135368347168e-01
    z[0,6,5]  R295      4.0404829382896423e-01
    z[0,6,5]  R296      4.0645658969879150e-01
    z[0,6,5]  R297      0.683262825012207
    z[0,6,5]  R298      -3.3823895454406738e-01
    z[0,6,5]  R299      3.9669805765151978e-01
    z[0,6,5]  R300      -1.9837960600852966e-01
    z[0,6,5]  R301      6.4588451385498047e-01
    z[0,6,5]  R302      5.3155146539211273e-02
    z[0,6,5]  R303      3.1064342707395554e-02
    z[0,6,5]  R304      -6.4315783977508545e-01
    z[0,6,5]  R305      -4.8138278722763062e-01
    z[0,6,5]  R306      -4.1208752989768982e-01
    z[0,6,5]  R307      -0.163218691945076
    z[0,6,5]  R308      -3.6639320850372314e-01
    z[0,6,5]  R309      2.4201080203056335e-01
    z[0,6,5]  R310      4.7869670391082764e-01
    z[0,6,5]  R311      2.5227880477905273e-01
    z[0,6,5]  R312      4.3468517065048218e-01
    z[0,6,5]  R313      2.9710179567337036e-01
    z[0,6,5]  R314      -3.4951677918434143e-01
    z[0,6,5]  R315      1.6739878058433533e-01
    z[0,6,5]  R316      3.6380210518836975e-01
    z[0,6,5]  R317      2.5592729449272156e-01
    z[0,6,5]  R318      -1.4988232869654894e-03
    z[0,6,5]  R319      5.1170504093170166e-01
    z[0,6,5]  R320      -3.2616552710533142e-01
    z[0,6,5]  R321      -3.5955232381820679e-01
    z[0,6,5]  R322      -1.5198934078216553e-01
    z[0,6,5]  R323      4.1818149387836456e-02
    z[0,6,5]  R324      2.6045233011245728e-02
    z[0,6,5]  R325      -6.7827187478542328e-02
    z[0,6,5]  R326      1.7519944906234741e-01
    z[0,6,5]  R327      -0.0880071297287941
    z[0,6,5]  R328      -3.4801412373781204e-02
    z[0,6,5]  R329      -9.7975112497806549e-02
    z[0,6,5]  R330      2.3809593915939331e-01
    z[0,6,5]  R331      3.3612795174121857e-02
    z[0,6,5]  R332      -5.7271972298622131e-02
    z[0,6,5]  R333      9.1047652065753937e-02
    z[0,6,5]  R334      -4.4316451996564865e-02
    z[0,6,5]  R335      3.4391567111015320e-01
    z[0,6,5]  R336      1.9005237519741058e-01
    z[0,6,5]  R337      -4.4324430823326111e-01
    z[0,6,5]  R338      -3.4918987751007080e-01
    z[0,6,5]  R339      5.1142746210098267e-01
    z[0,6,5]  R340      4.1684547066688538e-01
    z[0,6,5]  R341      1.1127652972936630e-01
    z[0,6,5]  R342      -5.0437271595001221e-02
    z[0,6,5]  R343      2.2210228443145752e-01
    z[0,6,5]  R344      -4.8537328839302063e-01
    z[0,6,5]  R345      1.0913676023483276e-01
    z[0,6,5]  R346      -4.3426580727100372e-02
    z[0,6,5]  R347      3.6192888021469116e-01
    z[0,6,5]  R348      -2.4011881649494171e-01
    z[0,6,5]  R349      -2.0933395624160767e-01
    z[0,6,5]  R350      2.4340030550956726e-01
    z[0,6,6]  R8        -1
    z[0,6,6]  R62       1
    z[0,6,6]  R281      -1
    z[0,6,6]  R282      1
    z[0,6,6]  R283      -5.2762636914849281e-03
    z[0,6,6]  R284      -3.2464897632598877e-01
    z[0,6,6]  R285      -3.4272608160972595e-01
    z[0,6,6]  R286      -1.6481541097164154e-01
    z[0,6,6]  R287      6.7073807120323181e-02
    z[0,6,6]  R288      3.3085864037275314e-02
    z[0,6,6]  R289      -6.9097883999347687e-02
    z[0,6,6]  R290      2.0548319816589355e-01
    z[0,6,6]  R291      1.8855926394462585e-01
    z[0,6,6]  R292      3.4393292665481567e-01
    z[0,6,6]  R293      1.6993522644042969e-01
    z[0,6,6]  R294      1.0680131381377578e-03
    z[0,6,6]  R295      3.7976048886775970e-02
    z[0,6,6]  R296      -2.9268273711204529e-01
    z[0,6,6]  R297      2.5929796695709229e-01
    z[0,6,6]  R298      -3.1391298770904541e-01
    z[0,6,6]  R299      8.5936456918716431e-02
    z[0,6,6]  R300      -8.6352258920669556e-02
    z[0,6,6]  R301      -3.7201926112174988e-01
    z[0,6,6]  R302      -1.1762705445289612e-01
    z[0,6,6]  R303      -4.7139741480350494e-02
    z[0,6,6]  R304      -3.3865770697593689e-01
    z[0,6,6]  R305      1.5174341201782227e-01
    z[0,6,6]  R306      -0.57515549659729
    z[0,6,6]  R307      -6.2575131654739380e-01
    z[0,6,6]  R308      -6.5187150239944458e-01
    z[0,6,6]  R309      1.3695454597473145e-01
    z[0,6,6]  R310      -2.3733739554882050e-01
    z[0,6,6]  R311      0.132560595870018
    z[0,6,6]  R312      -1.1568370461463928e-01
    z[0,6,6]  R313      4.3361580371856689e-01
    z[0,6,6]  R314      -4.1909894347190857e-01
    z[0,6,6]  R315      -9.6110187470912933e-02
    z[0,6,6]  R316      -8.4997788071632385e-02
    z[0,6,6]  R317      1.4928846061229706e-01
    z[0,6,6]  R318      3.4113296866416931e-01
    z[0,6,6]  R319      2.6181507110595703e-01
    z[0,6,6]  R320      2.8560775518417358e-01
    z[0,6,6]  R321      5.0760549306869507e-01
    z[0,6,6]  R322      -1.8244978785514832e-01
    z[0,6,6]  R323      -0.064302958548069
    z[0,6,6]  R324      1.2488375417888165e-02
    z[0,6,6]  R325      2.1631282567977905e-01
    z[0,6,6]  R326      2.3979188501834869e-01
    z[0,6,6]  R327      -2.8227767348289490e-01
    z[0,6,6]  R328      1.6881720721721649e-01
    z[0,6,6]  R329      -4.0435448288917542e-01
    z[0,6,6]  R330      -2.9842558503150940e-01
    z[0,6,6]  R331      2.0019564032554626e-01
    z[0,6,6]  R332      -2.1049199998378754e-01
    z[0,6,6]  R333      2.4944262206554413e-01
    z[0,6,6]  R334      1.5712873637676239e-01
    z[0,6,6]  R335      3.6919301748275757e-01
    z[0,6,6]  R336      -3.2470297813415527e-01
    z[0,6,6]  R337      1.4522561430931091e-01
    z[0,6,6]  R338      -2.4920284748077393e-01
    z[0,6,6]  R339      1.7616525292396545e-01
    z[0,6,6]  R340      -1.5595553815364838e-01
    z[0,6,6]  R341      1.9744274020195007e-01
    z[0,6,6]  R342      2.8939232230186462e-01
    z[0,6,6]  R343      3.4484165906906128e-01
    z[0,6,6]  R344      -6.2001351267099380e-02
    z[0,6,6]  R345      1.6115553677082062e-01
    z[0,6,6]  R346      -2.8612977266311646e-01
    z[0,6,6]  R347      -2.8295481204986572e-01
    z[0,6,6]  R348      -9.8420321941375732e-02
    z[0,6,6]  R349      -2.1999720484018326e-02
    z[0,6,6]  R350      2.1032616496086121e-01
    z[6,0,0]  R2        1
    z[6,0,0]  R56       -1
    z[6,0,0]  R351      -1
    z[6,0,0]  R352      1
    z[6,0,0]  R365      7.8719757497310638e-02
    z[6,0,0]  R366      -2.2840353846549988e-01
    z[6,0,0]  R367      1.3082465529441833e-01
    z[6,0,0]  R368      1.0154388844966888e-01
    z[6,0,0]  R369      1.2037665396928787e-01
    z[6,0,0]  R370      0.0824347734451294
    z[6,0,0]  R371      1.9508653879165649e-01
    z[6,0,0]  R372      2.8252487536519766e-03
    z[6,0,0]  R373      2.1544551849365234e-01
    z[6,0,0]  R374      4.5590769499540329e-02
    z[6,0,0]  R375      -0.0512348935008049
    z[6,0,0]  R376      -1.2200195342302322e-01
    z[6,0,0]  R377      -2.1726453304290771e-01
    z[6,0,0]  R378      -3.8343787193298340e-02
    z[6,0,0]  R379      1.0439215600490570e-01
    z[6,0,0]  R380      -7.3072470724582672e-02
    z[6,0,0]  R381      4.4909365475177765e-02
    z[6,0,0]  R382      -1.7582283914089203e-01
    z[6,0,0]  R383      -8.9845836162567139e-02
    z[6,0,0]  R384      3.3339053392410278e-02
    z[6,0,0]  R385      2.1200221776962280e-01
    z[6,0,0]  R386      -4.7757747769355774e-01
    z[6,0,0]  R387      -4.9179589748382568e-01
    z[6,0,0]  R388      2.4503467977046967e-01
    z[6,0,0]  R389      2.7563998103141785e-01
    z[6,0,0]  R390      7.6668816804885864e-01
    z[6,0,0]  R391      1.8436676263809204e-01
    z[6,0,0]  R392      5.9189713001251221e-01
    z[6,0,0]  R393      0.696549654006958
    z[6,0,0]  R394      6.2079501152038574e-01
    z[6,0,0]  R395      -1.2762364745140076e-01
    z[6,0,0]  R396      1.1209373921155930e-01
    z[6,0,0]  R397      3.8395129144191742e-02
    z[6,0,0]  R398      -7.3095254600048065e-02
    z[6,0,0]  R399      4.0898665785789490e-01
    z[6,0,0]  R400      2.8859421610832214e-01
    z[6,0,0]  R401      7.1428376436233521e-01
    z[6,0,0]  R402      4.9701672792434692e-01
    z[6,0,0]  R403      1.9165323674678802e-01
    z[6,0,0]  R404      -2.0771542191505432e-01
    z[6,0,0]  R405      -1.8366922438144684e-01
    z[6,0,0]  R406      1.3788939453661442e-02
    z[6,0,0]  R407      -2.4287530779838562e-01
    z[6,0,0]  R408      -4.4390112161636353e-01
    z[6,0,0]  R409      -6.6154795885086060e-01
    z[6,0,0]  R410      1.5986666083335876e-02
    z[6,0,0]  R411      9.4537409022450447e-03
    z[6,0,0]  R412      -0.223195418715477
    z[6,0,0]  R413      8.3576333522796631e-01
    z[6,0,0]  R414      1.0334073752164841e-01
    z[6,0,0]  R415      -5.6743121147155762e-01
    z[6,0,0]  R416      -2.2021780908107758e-01
    z[6,0,0]  R417      -5.8450883626937866e-01
    z[6,0,0]  R418      -1.2453515082597733e-01
    z[6,0,0]  R419      -6.3074070215225220e-01
    z[6,0,0]  R420      -0.783804178237915
    z[6,0,0]  R421      -1.2360622733831406e-01
    z[6,0,0]  R422      3.5977676510810852e-01
    z[6,0,0]  R423      2.6436656713485718e-01
    z[6,0,0]  R424      -2.7187108993530273e-01
    z[6,0,0]  R425      -2.3713806271553040e-01
    z[6,0,0]  R426      1.0651174187660217e-01
    z[6,0,0]  R427      2.8235900402069092e-01
    z[6,0,0]  R428      5.9322103857994080e-02
    z[6,0,0]  R429      -6.4567542076110840e-01
    z[6,0,0]  R430      -7.4250477552413940e-01
    z[6,0,0]  R431      -7.2795683145523071e-01
    z[6,0,0]  R432      -5.8998668193817139e-01
    z[6,0,1]  R3        1
    z[6,0,1]  R57       -1
    z[6,0,1]  R353      -1
    z[6,0,1]  R354      1
    z[6,0,1]  R365      -0.714492917060852
    z[6,0,1]  R366      -0.766794741153717
    z[6,0,1]  R367      -5.3733867406845093e-01
    z[6,0,1]  R368      -5.0333178043365479e-01
    z[6,0,1]  R369      -5.2201277017593384e-01
    z[6,0,1]  R370      -5.6424331665039062e-01
    z[6,0,1]  R371      -4.1130667924880981e-01
    z[6,0,1]  R372      -4.8473531007766724e-01
    z[6,0,1]  R373      -3.9754891395568848e-01
    z[6,0,1]  R374      -4.9129721522331238e-01
    z[6,0,1]  R375      8.9774513244628906e-01
    z[6,0,1]  R376      8.4161835908889771e-01
    z[6,0,1]  R377      9.2137068510055542e-01
    z[6,0,1]  R378      9.0582871437072754e-01
    z[6,0,1]  R379      8.6860394477844238e-01
    z[6,0,1]  R380      8.5018402338027954e-01
    z[6,0,1]  R381      8.3546936511993408e-01
    z[6,0,1]  R382      0.864683210849762
    z[6,0,1]  R383      0.888593316078186
    z[6,0,1]  R384      0.855954110622406
    z[6,0,1]  R385      -6.3495159149169922e-01
    z[6,0,1]  R386      -6.0940831899642944e-01
    z[6,0,1]  R387      -6.0587811470031738e-01
    z[6,0,1]  R388      -6.5649712085723877e-01
    z[6,0,1]  R389      7.5388967990875244e-01
    z[6,0,1]  R390      -5.9504695236682892e-02
    z[6,0,1]  R391      6.7608863115310669e-01
    z[6,0,1]  R392      4.4767209887504578e-01
    z[6,0,1]  R393      5.8056843280792236e-01
    z[6,0,1]  R394      4.1099786758422852e-01
    z[6,0,1]  R395      -0.734729528427124
    z[6,0,1]  R396      -4.5898100733757019e-01
    z[6,0,1]  R397      9.5731109380722046e-01
    z[6,0,1]  R398      8.5355150699615479e-01
    z[6,0,1]  R399      7.0696151256561279e-01
    z[6,0,1]  R400      6.4644461870193481e-01
    z[6,0,1]  R401      5.7346242666244507e-01
    z[6,0,1]  R402      5.3231346607208252e-01
    z[6,0,1]  R403      -5.8158874511718750e-01
    z[6,0,1]  R404      -7.3835515975952148e-01
    z[6,0,1]  R405      -7.1612530946731567e-01
    z[6,0,1]  R406      9.3383622169494629e-01
    z[6,0,1]  R407      8.0530482530593872e-01
    z[6,0,1]  R408      0.835724413394928
    z[6,0,1]  R409      6.9833201169967651e-01
    z[6,0,1]  R410      -4.9010995030403137e-01
    z[6,0,1]  R411      -5.0764805078506470e-01
    z[6,0,1]  R412      -4.7747588157653809e-01
    z[6,0,1]  R413      -5.9382695704698563e-02
    z[6,0,1]  R414      -4.2601615190505981e-01
    z[6,0,1]  R415      -9.5300465822219849e-02
    z[6,0,1]  R416      1.5859314799308777e-01
    z[6,0,1]  R417      -5.0843423232436180e-03
    z[6,0,1]  R418      1.3745523989200592e-01
    z[6,0,1]  R419      2.2321771085262299e-01
    z[6,0,1]  R420      -3.4024711698293686e-02
    z[6,0,1]  R421      -6.1245895922183990e-02
    z[6,0,1]  R422      3.0732190608978271e-01
    z[6,0,1]  R423      2.5657543540000916e-01
    z[6,0,1]  R424      -9.9763527512550354e-02
    z[6,0,1]  R425      -2.2777697443962097e-01
    z[6,0,1]  R426      1.9558179192245007e-03
    z[6,0,1]  R427      -1.8395036458969116e-01
    z[6,0,1]  R428      1.3640265166759491e-01
    z[6,0,1]  R429      1.4648780226707458e-01
    z[6,0,1]  R430      1.5298567712306976e-01
    z[6,0,1]  R431      2.3878830671310425e-01
    z[6,0,1]  R432      2.1811890602111816e-01
    z[6,0,2]  R4        1
    z[6,0,2]  R58       -1
    z[6,0,2]  R355      -1
    z[6,0,2]  R356      1
    z[6,0,2]  R365      6.1780065298080444e-03
    z[6,0,2]  R366      8.0064445734024048e-02
    z[6,0,2]  R367      2.7129095792770386e-01
    z[6,0,2]  R368      5.1973092555999756e-01
    z[6,0,2]  R369      -3.9048162102699280e-01
    z[6,0,2]  R370      -3.5271200537681580e-01
    z[6,0,2]  R371      5.1109284162521362e-01
    z[6,0,2]  R372      -6.6421443223953247e-01
    z[6,0,2]  R373      -2.9589393734931946e-01
    z[6,0,2]  R374      3.9483693242073059e-01
    z[6,0,2]  R375      3.2043972611427307e-01
    z[6,0,2]  R376      3.9753416180610657e-01
    z[6,0,2]  R377      1.2810868024826050e-01
    z[6,0,2]  R378      -1.6346798837184906e-01
    z[6,0,2]  R379      5.8403205126523972e-02
    z[6,0,2]  R380      -3.0593705177307129e-01
    z[6,0,2]  R381      2.2055111825466156e-01
    z[6,0,2]  R382      -1.0309773683547974e-01
    z[6,0,2]  R383      -2.7790832519531250e-01
    z[6,0,2]  R384      3.0476909875869751e-01
    z[6,0,2]  R385      4.0077927405945957e-04
    z[6,0,2]  R386      4.0916711091995239e-02
    z[6,0,2]  R387      -2.0590171217918396e-01
    z[6,0,2]  R388      4.6840527653694153e-01
    z[6,0,2]  R389      -2.1393741667270660e-01
    z[6,0,2]  R390      -1.8920238316059113e-01
    z[6,0,2]  R391      1.3858684897422791e-01
    z[6,0,2]  R392      8.5976555943489075e-02
    z[6,0,2]  R393      1.5089520812034607e-01
    z[6,0,2]  R394      1.0470622032880783e-01
    z[6,0,2]  R395      -3.7842476367950439e-01
    z[6,0,2]  R396      -2.8487798571586609e-01
    z[6,0,2]  R397      -2.5255424901843071e-02
    z[6,0,2]  R398      -2.4526433646678925e-01
    z[6,0,2]  R399      2.4254019558429718e-01
    z[6,0,2]  R400      -2.1440829336643219e-01
    z[6,0,2]  R401      2.0959307253360748e-01
    z[6,0,2]  R402      2.2036673128604889e-01
    z[6,0,2]  R403      7.2244971990585327e-01
    z[6,0,2]  R404      1.5150021016597748e-01
    z[6,0,2]  R405      -1.7540346086025238e-01
    z[6,0,2]  R406      2.8545374050736427e-02
    z[6,0,2]  R407      4.9569058418273926e-01
    z[6,0,2]  R408      -1.1234133690595627e-01
    z[6,0,2]  R409      2.0229579508304596e-01
    z[6,0,2]  R410      -1.1553539335727692e-01
    z[6,0,2]  R411      -5.2026614546775818e-02
    z[6,0,2]  R412      2.7767020463943481e-01
    z[6,0,2]  R413      -3.6162726581096649e-02
    z[6,0,2]  R414      -6.8504661321640015e-02
    z[6,0,2]  R415      -5.1189231872558594e-01
    z[6,0,2]  R416      -4.5494395494461060e-01
    z[6,0,2]  R417      -7.4862414039671421e-03
    z[6,0,2]  R418      4.7607842087745667e-01
    z[6,0,2]  R419      8.7533473968505859e-02
    z[6,0,2]  R420      -5.5326402187347412e-01
    z[6,0,2]  R421      -5.6598037481307983e-01
    z[6,0,2]  R422      1.8595691770315170e-02
    z[6,0,2]  R423      9.1309905052185059e-01
    z[6,0,2]  R424      4.2580866813659668e-01
    z[6,0,2]  R425      6.6707265377044678e-01
    z[6,0,2]  R426      4.1050103306770325e-01
    z[6,0,2]  R427      -4.7099899500608444e-02
    z[6,0,2]  R428      0.516718864440918
    z[6,0,2]  R429      -6.4277899265289307e-01
    z[6,0,2]  R430      -2.4310082197189331e-01
    z[6,0,2]  R431      -3.3278200030326843e-01
    z[6,0,2]  R432      -2.9201608896255493e-01
    z[6,0,3]  R5        1
    z[6,0,3]  R59       -1
    z[6,0,3]  R357      -1
    z[6,0,3]  R358      1
    z[6,0,3]  R365      3.3091518282890320e-01
    z[6,0,3]  R366      -2.2827278077602386e-01
    z[6,0,3]  R367      -2.8170111775398254e-01
    z[6,0,3]  R368      -5.0733107328414917e-01
    z[6,0,3]  R369      6.6642665863037109e-01
    z[6,0,3]  R370      -5.4064452648162842e-01
    z[6,0,3]  R371      3.9117965102195740e-01
    z[6,0,3]  R372      -0.279350608587265
    z[6,0,3]  R373      -3.5979685187339783e-01
    z[6,0,3]  R374      7.2067701816558838e-01
    z[6,0,3]  R375      2.5874990224838257e-01
    z[6,0,3]  R376      2.4203525483608246e-01
    z[6,0,3]  R377      -1.8975268304347992e-01
    z[6,0,3]  R378      -1.5461277961730957e-01
    z[6,0,3]  R379      -3.5554841160774231e-02
    z[6,0,3]  R380      -1.0980086028575897e-01
    z[6,0,3]  R381      8.6332093924283981e-03
    z[6,0,3]  R382      4.7490164637565613e-02
    z[6,0,3]  R383      2.8536167740821838e-01
    z[6,0,3]  R384      2.3685184121131897e-01
    z[6,0,3]  R385      2.6239043474197388e-01
    z[6,0,3]  R386      -2.1712154150009155e-01
    z[6,0,3]  R387      1.7849530279636383e-01
    z[6,0,3]  R388      3.1665435433387756e-01
    z[6,0,3]  R389      -2.5579133629798889e-01
    z[6,0,3]  R390      1.0500301420688629e-01
    z[6,0,3]  R391      4.6437028795480728e-02
    z[6,0,3]  R392      -4.8745346069335938e-01
    z[6,0,3]  R393      -2.7795964479446411e-01
    z[6,0,3]  R394      -5.9017390012741089e-01
    z[6,0,3]  R395      -1.5690918266773224e-01
    z[6,0,3]  R396      3.5372716188430786e-01
    z[6,0,3]  R397      -7.4609339237213135e-02
    z[6,0,3]  R398      -3.0010592937469482e-01
    z[6,0,3]  R399      -1.9031988084316254e-01
    z[6,0,3]  R400      -5.6362503767013550e-01
    z[6,0,3]  R401      -0.260911226272583
    z[6,0,3]  R402      -5.5483013391494751e-01
    z[6,0,3]  R403      -1.8758429586887360e-01
    z[6,0,3]  R404      -8.2432955503463745e-02
    z[6,0,3]  R405      -5.0195151567459106e-01
    z[6,0,3]  R406      -1.7365214228630066e-01
    z[6,0,3]  R407      -1.5692830085754395e-01
    z[6,0,3]  R408      -2.6885411143302917e-01
    z[6,0,3]  R409      -6.5963692963123322e-02
    z[6,0,3]  R410      -4.0872827172279358e-01
    z[6,0,3]  R411      5.3997492790222168e-01
    z[6,0,3]  R412      4.5336952805519104e-01
    z[6,0,3]  R413      4.9107950925827026e-01
    z[6,0,3]  R414      5.2864813804626465e-01
    z[6,0,3]  R415      0.318837970495224
    z[6,0,3]  R416      4.9835193157196045e-01
    z[6,0,3]  R417      1.2492348253726959e-01
    z[6,0,3]  R418      0.495672345161438
    z[6,0,3]  R419      4.1341197490692139e-01
    z[6,0,3]  R420      1.5499453246593475e-01
    z[6,0,3]  R421      3.4000892192125320e-02
    z[6,0,3]  R422      -7.6862221956253052e-01
    z[6,0,3]  R423      -8.8680043816566467e-02
    z[6,0,3]  R424      2.4924033880233765e-01
    z[6,0,3]  R425      3.3963090181350708e-01
    z[6,0,3]  R426      -2.4220287799835205e-01
    z[6,0,3]  R427      -5.2661311626434326e-01
    z[6,0,3]  R428      2.9343172907829285e-01
    z[6,0,3]  R429      2.3093126714229584e-01
    z[6,0,3]  R430      0.24466472864151
    z[6,0,3]  R431      3.4001526236534119e-01
    z[6,0,3]  R432      2.7249908447265625e-01
    z[6,0,4]  R6        1
    z[6,0,4]  R60       -1
    z[6,0,4]  R359      -1
    z[6,0,4]  R360      1
    z[6,0,4]  R365      3.1219854950904846e-01
    z[6,0,4]  R366      -5.9438440948724747e-02
    z[6,0,4]  R367      -7.0988601446151733e-01
    z[6,0,4]  R368      -2.6318114995956421e-01
    z[6,0,4]  R369      -1.6919200122356415e-01
    z[6,0,4]  R370      -3.7650740146636963e-01
    z[6,0,4]  R371      -2.1941165626049042e-01
    z[6,0,4]  R372      -2.4052104353904724e-01
    z[6,0,4]  R373      4.3770986795425415e-01
    z[6,0,4]  R374      1.5775993466377258e-01
    z[6,0,4]  R375      -1.2614172697067261e-01
    z[6,0,4]  R376      2.4360871315002441e-01
    z[6,0,4]  R377      7.9051433131098747e-03
    z[6,0,4]  R378      1.9794492423534393e-01
    z[6,0,4]  R379      3.7752953171730042e-01
    z[6,0,4]  R380      -3.6943656206130981e-01
    z[6,0,4]  R381      -2.7956220507621765e-01
    z[6,0,4]  R382      -2.5055420398712158e-01
    z[6,0,4]  R383      -4.9570269882678986e-02
    z[6,0,4]  R384      2.6393425464630127e-01
    z[6,0,4]  R385      6.4228612184524536e-01
    z[6,0,4]  R386      5.7015073299407959e-01
    z[6,0,4]  R387      2.4942095577716827e-01
    z[6,0,4]  R388      2.1850416064262390e-01
    z[6,0,4]  R389      1.6406890749931335e-01
    z[6,0,4]  R390      -4.2165097594261169e-01
    z[6,0,4]  R391      -4.4154065847396851e-01
    z[6,0,4]  R392      7.8501164913177490e-02
    z[6,0,4]  R393      -1.6236285865306854e-01
    z[6,0,4]  R394      -1.1570196598768234e-02
    z[6,0,4]  R395      -3.2835006713867188e-01
    z[6,0,4]  R396      5.7537955045700073e-01
    z[6,0,4]  R397      -1.9492319226264954e-01
    z[6,0,4]  R398      -1.7925573885440826e-01
    z[6,0,4]  R399      -1.6380502283573151e-01
    z[6,0,4]  R400      -0.260452002286911
    z[6,0,4]  R401      6.8050853908061981e-02
    z[6,0,4]  R402      -9.8680742084980011e-02
    z[6,0,4]  R403      -7.0433989167213440e-02
    z[6,0,4]  R404      -2.8365742415189743e-02
    z[6,0,4]  R405      1.2010759115219116e-01
    z[6,0,4]  R406      2.2773268818855286e-01
    z[6,0,4]  R407      1.4585069380700588e-02
    z[6,0,4]  R408      -9.9609516561031342e-02
    z[6,0,4]  R409      1.4132109284400940e-01
    z[6,0,4]  R410      -7.0909923315048218e-01
    z[6,0,4]  R411      -3.0072498321533203e-01
    z[6,0,4]  R412      3.2754909992218018e-01
    z[6,0,4]  R413      1.2776434421539307e-01
    z[6,0,4]  R414      6.3823598623275757e-01
    z[6,0,4]  R415      -3.7490129470825195e-01
    z[6,0,4]  R416      -4.6920531988143921e-01
    z[6,0,4]  R417      -3.2951205968856812e-01
    z[6,0,4]  R418      -5.2944153547286987e-01
    z[6,0,4]  R419      -4.5718041062355042e-01
    z[6,0,4]  R420      8.6935520172119141e-02
    z[6,0,4]  R421      -3.2235914468765259e-01
    z[6,0,4]  R422      -4.1027587652206421e-01
    z[6,0,4]  R423      1.3956440985202789e-01
    z[6,0,4]  R424      3.7994533777236938e-01
    z[6,0,4]  R425      -2.7711486816406250e-01
    z[6,0,4]  R426      5.1074278354644775e-01
    z[6,0,4]  R427      4.3438565731048584e-01
    z[6,0,4]  R428      -2.5611367821693420e-01
    z[6,0,4]  R429      -1.3350901007652283e-01
    z[6,0,4]  R430      -1.4437295496463776e-01
    z[6,0,4]  R431      -3.2478895783424377e-01
    z[6,0,4]  R432      -4.9241924285888672e-01
    z[6,0,5]  R7        1
    z[6,0,5]  R61       -1
    z[6,0,5]  R361      -1
    z[6,0,5]  R362      1
    z[6,0,5]  R365      2.9710179567337036e-01
    z[6,0,5]  R366      -3.4951677918434143e-01
    z[6,0,5]  R367      1.6739878058433533e-01
    z[6,0,5]  R368      3.6380210518836975e-01
    z[6,0,5]  R369      2.5592729449272156e-01
    z[6,0,5]  R370      -1.4988232869654894e-03
    z[6,0,5]  R371      5.1170504093170166e-01
    z[6,0,5]  R372      -3.2616552710533142e-01
    z[6,0,5]  R373      -3.5955232381820679e-01
    z[6,0,5]  R374      -1.5198934078216553e-01
    z[6,0,5]  R375      4.1818149387836456e-02
    z[6,0,5]  R376      2.6045233011245728e-02
    z[6,0,5]  R377      -6.7827187478542328e-02
    z[6,0,5]  R378      1.7519944906234741e-01
    z[6,0,5]  R379      -0.0880071297287941
    z[6,0,5]  R380      -3.4801412373781204e-02
    z[6,0,5]  R381      -9.7975112497806549e-02
    z[6,0,5]  R382      2.3809593915939331e-01
    z[6,0,5]  R383      3.3612795174121857e-02
    z[6,0,5]  R384      -5.7271972298622131e-02
    z[6,0,5]  R385      9.1047652065753937e-02
    z[6,0,5]  R386      -4.4316451996564865e-02
    z[6,0,5]  R387      3.4391567111015320e-01
    z[6,0,5]  R388      1.9005237519741058e-01
    z[6,0,5]  R389      -4.4324430823326111e-01
    z[6,0,5]  R390      -3.4918987751007080e-01
    z[6,0,5]  R391      5.1142746210098267e-01
    z[6,0,5]  R392      4.1684547066688538e-01
    z[6,0,5]  R393      1.1127652972936630e-01
    z[6,0,5]  R394      -5.0437271595001221e-02
    z[6,0,5]  R395      2.2210228443145752e-01
    z[6,0,5]  R396      -4.8537328839302063e-01
    z[6,0,5]  R397      1.0913676023483276e-01
    z[6,0,5]  R398      -4.3426580727100372e-02
    z[6,0,5]  R399      3.6192888021469116e-01
    z[6,0,5]  R400      -2.4011881649494171e-01
    z[6,0,5]  R401      -2.0933395624160767e-01
    z[6,0,5]  R402      2.4340030550956726e-01
    z[6,0,5]  R403      2.5082537531852722e-01
    z[6,0,5]  R404      -5.2510648965835571e-01
    z[6,0,5]  R405      0.197031632065773
    z[6,0,5]  R406      -1.3328030705451965e-01
    z[6,0,5]  R407      0.13209268450737
    z[6,0,5]  R408      9.2718534171581268e-02
    z[6,0,5]  R409      -6.8306297063827515e-02
    z[6,0,5]  R410      1.8461950123310089e-01
    z[6,0,5]  R411      -5.6739258766174316e-01
    z[6,0,5]  R412      -4.6257704496383667e-01
    z[6,0,5]  R413      -1.0151280462741852e-01
    z[6,0,5]  R414      3.4106135368347168e-01
    z[6,0,5]  R415      4.0404829382896423e-01
    z[6,0,5]  R416      4.0645658969879150e-01
    z[6,0,5]  R417      0.683262825012207
    z[6,0,5]  R418      -3.3823895454406738e-01
    z[6,0,5]  R419      3.9669805765151978e-01
    z[6,0,5]  R420      -1.9837960600852966e-01
    z[6,0,5]  R421      6.4588451385498047e-01
    z[6,0,5]  R422      5.3155146539211273e-02
    z[6,0,5]  R423      3.1064342707395554e-02
    z[6,0,5]  R424      -6.4315783977508545e-01
    z[6,0,5]  R425      -4.8138278722763062e-01
    z[6,0,5]  R426      -4.1208752989768982e-01
    z[6,0,5]  R427      -0.163218691945076
    z[6,0,5]  R428      -3.6639320850372314e-01
    z[6,0,5]  R429      2.4201080203056335e-01
    z[6,0,5]  R430      4.7869670391082764e-01
    z[6,0,5]  R431      2.5227880477905273e-01
    z[6,0,5]  R432      4.3468517065048218e-01
    z[6,0,6]  R8        1
    z[6,0,6]  R62       -1
    z[6,0,6]  R363      -1
    z[6,0,6]  R364      1
    z[6,0,6]  R365      4.3361580371856689e-01
    z[6,0,6]  R366      -4.1909894347190857e-01
    z[6,0,6]  R367      -9.6110187470912933e-02
    z[6,0,6]  R368      -8.4997788071632385e-02
    z[6,0,6]  R369      1.4928846061229706e-01
    z[6,0,6]  R370      3.4113296866416931e-01
    z[6,0,6]  R371      2.6181507110595703e-01
    z[6,0,6]  R372      2.8560775518417358e-01
    z[6,0,6]  R373      5.0760549306869507e-01
    z[6,0,6]  R374      -1.8244978785514832e-01
    z[6,0,6]  R375      -0.064302958548069
    z[6,0,6]  R376      1.2488375417888165e-02
    z[6,0,6]  R377      2.1631282567977905e-01
    z[6,0,6]  R378      2.3979188501834869e-01
    z[6,0,6]  R379      -2.8227767348289490e-01
    z[6,0,6]  R380      1.6881720721721649e-01
    z[6,0,6]  R381      -4.0435448288917542e-01
    z[6,0,6]  R382      -2.9842558503150940e-01
    z[6,0,6]  R383      2.0019564032554626e-01
    z[6,0,6]  R384      -2.1049199998378754e-01
    z[6,0,6]  R385      2.4944262206554413e-01
    z[6,0,6]  R386      1.5712873637676239e-01
    z[6,0,6]  R387      3.6919301748275757e-01
    z[6,0,6]  R388      -3.2470297813415527e-01
    z[6,0,6]  R389      1.4522561430931091e-01
    z[6,0,6]  R390      -2.4920284748077393e-01
    z[6,0,6]  R391      1.7616525292396545e-01
    z[6,0,6]  R392      -1.5595553815364838e-01
    z[6,0,6]  R393      1.9744274020195007e-01
    z[6,0,6]  R394      2.8939232230186462e-01
    z[6,0,6]  R395      3.4484165906906128e-01
    z[6,0,6]  R396      -6.2001351267099380e-02
    z[6,0,6]  R397      1.6115553677082062e-01
    z[6,0,6]  R398      -2.8612977266311646e-01
    z[6,0,6]  R399      -2.8295481204986572e-01
    z[6,0,6]  R400      -9.8420321941375732e-02
    z[6,0,6]  R401      -2.1999720484018326e-02
    z[6,0,6]  R402      2.1032616496086121e-01
    z[6,0,6]  R403      -5.2762636914849281e-03
    z[6,0,6]  R404      -3.2464897632598877e-01
    z[6,0,6]  R405      -3.4272608160972595e-01
    z[6,0,6]  R406      -1.6481541097164154e-01
    z[6,0,6]  R407      6.7073807120323181e-02
    z[6,0,6]  R408      3.3085864037275314e-02
    z[6,0,6]  R409      -6.9097883999347687e-02
    z[6,0,6]  R410      2.0548319816589355e-01
    z[6,0,6]  R411      1.8855926394462585e-01
    z[6,0,6]  R412      3.4393292665481567e-01
    z[6,0,6]  R413      1.6993522644042969e-01
    z[6,0,6]  R414      1.0680131381377578e-03
    z[6,0,6]  R415      3.7976048886775970e-02
    z[6,0,6]  R416      -2.9268273711204529e-01
    z[6,0,6]  R417      2.5929796695709229e-01
    z[6,0,6]  R418      -3.1391298770904541e-01
    z[6,0,6]  R419      8.5936456918716431e-02
    z[6,0,6]  R420      -8.6352258920669556e-02
    z[6,0,6]  R421      -3.7201926112174988e-01
    z[6,0,6]  R422      -1.1762705445289612e-01
    z[6,0,6]  R423      -4.7139741480350494e-02
    z[6,0,6]  R424      -3.3865770697593689e-01
    z[6,0,6]  R425      1.5174341201782227e-01
    z[6,0,6]  R426      -0.57515549659729
    z[6,0,6]  R427      -6.2575131654739380e-01
    z[6,0,6]  R428      -6.5187150239944458e-01
    z[6,0,6]  R429      1.3695454597473145e-01
    z[6,0,6]  R430      -2.3733739554882050e-01
    z[6,0,6]  R431      0.132560595870018
    z[6,0,6]  R432      -1.1568370461463928e-01
    z[1,2,0]  R11       -1
    z[1,2,0]  R20       1
    z[1,2,0]  R477      -1
    z[1,2,0]  R478      1
    z[1,2,0]  R491      6.9864052347838879e-03
    z[1,2,0]  R492      1.5159071981906891e-01
    z[1,2,0]  R493      -4.3520724773406982e-01
    z[1,2,0]  R494      -3.1087413430213928e-01
    z[1,2,0]  R495      -1.4469125866889954e-01
    z[1,2,0]  R496      -4.7290101647377014e-01
    z[1,2,0]  R497      -5.1100796461105347e-01
    z[1,2,0]  R498      1.3841454684734344e-01
    z[1,2,0]  R499      4.0108391642570496e-01
    z[1,2,0]  R500      1.1373510956764221e-01
    z[1,2,0]  R501      -2.6660263538360596e-01
    z[1,2,0]  R502      -2.3148806393146515e-01
    z[1,2,0]  R503      1.3688498735427856e-01
    z[1,2,0]  R504      7.5992047786712646e-02
    z[1,2,0]  R505      -1.2372570484876633e-01
    z[1,2,0]  R506      -0.128860741853714
    z[1,2,0]  R507      -2.0290514826774597e-01
    z[1,2,0]  R508      -5.3697037696838379e-01
    z[1,2,0]  R509      -1.1369368992745876e-02
    z[1,2,0]  R510      -5.5578452348709106e-01
    z[1,2,0]  R511      0.322528600692749
    z[1,2,0]  R512      1.2251260876655579e-01
    z[1,2,0]  R513      1.1202982813119888e-01
    z[1,2,0]  R514      -0.079043909907341
    z[1,2,0]  R515      1.2563639879226685e-01
    z[1,2,0]  R516      4.3147706985473633e-01
    z[1,2,0]  R517      2.5280410051345825e-01
    z[1,2,0]  R518      4.7436505556106567e-03
    z[1,2,0]  R519      2.2293041646480560e-01
    z[1,2,0]  R520      -0.0975753590464592
    z[1,2,0]  R521      -2.9630562663078308e-01
    z[1,2,0]  R522      -1.5747289359569550e-01
    z[1,2,0]  R523      3.2779577374458313e-01
    z[1,2,0]  R524      -1.8186327815055847e-01
    z[1,2,0]  R525      -2.7668768167495728e-01
    z[1,2,0]  R526      -8.4725864231586456e-02
    z[1,2,0]  R527      2.0847450196743011e-01
    z[1,2,0]  R528      2.8710582852363586e-01
    z[1,2,0]  R529      3.1074506044387817e-01
    z[1,2,0]  R530      3.2126989960670471e-01
    z[1,2,0]  R531      -5.1831060647964478e-01
    z[1,2,0]  R532      3.4386706352233887e-01
    z[1,2,0]  R533      -1.6055357456207275e-01
    z[1,2,0]  R534      -3.1579840183258057e-01
    z[1,2,0]  R535      -5.1425721496343613e-02
    z[1,2,0]  R536      3.0115556716918945e-01
    z[1,2,0]  R537      1.2531785666942596e-01
    z[1,2,0]  R538      4.2257830500602722e-02
    z[1,2,0]  R539      3.7992015480995178e-01
    z[1,2,0]  R540      5.2165144681930542e-01
    z[1,2,0]  R541      4.7604960203170776e-01
    z[1,2,0]  R542      3.3365431427955627e-01
    z[1,2,0]  R543      2.1986183524131775e-01
    z[1,2,0]  R544      5.3151583671569824e-01
    z[1,2,0]  R545      7.1910239756107330e-02
    z[1,2,0]  R546      -5.5746231228113174e-02
    z[1,2,0]  R547      1.4154396951198578e-01
    z[1,2,0]  R548      -1.1921548098325729e-01
    z[1,2,0]  R549      -1.4973938465118408e-02
    z[1,2,0]  R550      -4.2232591658830643e-02
    z[1,2,0]  R551      1.4951783418655396e-01
    z[1,2,0]  R552      -2.3622293770313263e-01
    z[1,2,0]  R553      1.8643289804458618e-01
    z[1,2,0]  R554      2.2332927212119102e-02
    z[1,2,0]  R555      3.0346214771270752e-01
    z[1,2,0]  R556      -2.4205325543880463e-01
    z[1,2,1]  R12       -1
    z[1,2,1]  R21       1
    z[1,2,1]  R479      -1
    z[1,2,1]  R480      1
    z[1,2,1]  R491      -2.1872717142105103e-01
    z[1,2,1]  R492      0.0711594671010971
    z[1,2,1]  R493      -4.4952562451362610e-01
    z[1,2,1]  R494      3.8730540871620178e-01
    z[1,2,1]  R495      5.3261183202266693e-02
    z[1,2,1]  R496      2.1477538347244263e-01
    z[1,2,1]  R497      -2.2816047072410583e-01
    z[1,2,1]  R498      3.4862717986106873e-01
    z[1,2,1]  R499      3.0483883619308472e-01
    z[1,2,1]  R500      -0.564039409160614
    z[1,2,1]  R501      -7.6693505048751831e-01
    z[1,2,1]  R502      -6.9930177927017212e-01
    z[1,2,1]  R503      -7.0424813032150269e-01
    z[1,2,1]  R504      -7.2674477100372314e-01
    z[1,2,1]  R505      -6.5514838695526123e-01
    z[1,2,1]  R506      -6.4812636375427246e-01
    z[1,2,1]  R507      -6.4683514833450317e-01
    z[1,2,1]  R508      -0.296928733587265
    z[1,2,1]  R509      -6.0688656568527222e-01
    z[1,2,1]  R510      -3.0988302826881409e-01
    z[1,2,1]  R511      8.4352749586105347e-01
    z[1,2,1]  R512      8.8191956281661987e-01
    z[1,2,1]  R513      9.0987449884414673e-01
    z[1,2,1]  R514      0.946040689945221
    z[1,2,1]  R515      7.7698063850402832e-01
    z[1,2,1]  R516      0.773720383644104
    z[1,2,1]  R517      8.2341051101684570e-01
    z[1,2,1]  R518      8.2002300024032593e-01
    z[1,2,1]  R519      7.7736425399780273e-01
    z[1,2,1]  R520      7.9500550031661987e-01
    z[1,2,1]  R521      -8.6459028720855713e-01
    z[1,2,1]  R522      -7.6453024148941040e-01
    z[1,2,1]  R523      -6.3956683874130249e-01
    z[1,2,1]  R524      -4.3450099229812622e-01
    z[1,2,1]  R525      -3.3394771814346313e-01
    z[1,2,1]  R526      -4.9412319064140320e-01
    z[1,2,1]  R527      8.4681063890457153e-01
    z[1,2,1]  R528      -5.7036370038986206e-01
    z[1,2,1]  R529      6.7065447568893433e-01
    z[1,2,1]  R530      5.8970105648040771e-01
    z[1,2,1]  R531      4.4127404689788818e-01
    z[1,2,1]  R532      5.5638778209686279e-01
    z[1,2,1]  R533      -5.3512406349182129e-01
    z[1,2,1]  R534      -0.449727326631546
    z[1,2,1]  R535      -5.2998477220535278e-01
    z[1,2,1]  R536      -2.3548798263072968e-01
    z[1,2,1]  R537      -6.8755798041820526e-02
    z[1,2,1]  R538      -3.0945608019828796e-01
    z[1,2,1]  R539      -3.0317991971969604e-01
    z[1,2,1]  R540      -4.0468877553939819e-01
    z[1,2,1]  R541      7.5076855719089508e-02
    z[1,2,1]  R542      -4.0912812948226929e-01
    z[1,2,1]  R543      -3.5781404376029968e-01
    z[1,2,1]  R544      -1.2643989920616150e-01
    z[1,2,1]  R545      6.2416708469390869e-01
    z[1,2,1]  R546      6.1151504516601562e-01
    z[1,2,1]  R547      6.1467844247817993e-01
    z[1,2,1]  R548      6.0014915466308594e-01
    z[1,2,1]  R549      6.0448038578033447e-01
    z[1,2,1]  R550      5.8867859840393066e-01
    z[1,2,1]  R551      6.3629478216171265e-01
    z[1,2,1]  R552      0.555555522441864
    z[1,2,1]  R553      -4.4533852487802505e-02
    z[1,2,1]  R554      -2.2310809791088104e-01
    z[1,2,1]  R555      -1.3412791490554810e-01
    z[1,2,1]  R556      -0.0782335102558136
    z[1,2,2]  R13       -1
    z[1,2,2]  R22       1
    z[1,2,2]  R481      -1
    z[1,2,2]  R482      1
    z[1,2,2]  R491      7.5789797306060791e-01
    z[1,2,2]  R492      1.6683810949325562e-01
    z[1,2,2]  R493      4.7264236211776733e-01
    z[1,2,2]  R494      6.4159828424453735e-01
    z[1,2,2]  R495      7.1890002489089966e-01
    z[1,2,2]  R496      7.1373388171195984e-02
    z[1,2,2]  R497      0.0696830004453659
    z[1,2,2]  R498      6.6323804855346680e-01
    z[1,2,2]  R499      -1.9777624309062958e-01
    z[1,2,2]  R500      3.2200655341148376e-01
    z[1,2,2]  R501      -4.4560018181800842e-01
    z[1,2,2]  R502      -1.9278754293918610e-01
    z[1,2,2]  R503      -5.2620077133178711e-01
    z[1,2,2]  R504      -2.5206919759511948e-02
    z[1,2,2]  R505      -0.000703649187926203
    z[1,2,2]  R506      -1.8737143278121948e-01
    z[1,2,2]  R507      -1.7838209867477417e-02
    z[1,2,2]  R508      3.4494474530220032e-01
    z[1,2,2]  R509      5.3917411714792252e-02
    z[1,2,2]  R510      -1.9586580991744995e-01
    z[1,2,2]  R511      -7.7291406691074371e-02
    z[1,2,2]  R512      -1.2138006836175919e-01
    z[1,2,2]  R513      1.0292125493288040e-01
    z[1,2,2]  R514      -1.0032343864440918e-01
    z[1,2,2]  R515      -6.0871934890747070e-01
    z[1,2,2]  R516      4.1946947574615479e-01
    z[1,2,2]  R517      -1.2614218890666962e-01
    z[1,2,2]  R518      -8.2723297178745270e-02
    z[1,2,2]  R519      1.5332648158073425e-01
    z[1,2,2]  R520      1.0726466029882431e-01
    z[1,2,2]  R521      2.6444083452224731e-01
    z[1,2,2]  R522      4.4059496372938156e-02
    z[1,2,2]  R523      3.7639924883842468e-01
    z[1,2,2]  R524      5.7339799404144287e-01
    z[1,2,2]  R525      6.9558018445968628e-01
    z[1,2,2]  R526      1.8632547557353973e-01
    z[1,2,2]  R527      7.9054161906242371e-02
    z[1,2,2]  R528      -5.0351446866989136e-01
    z[1,2,2]  R529      3.1220319867134094e-01
    z[1,2,2]  R530      -1.2036138027906418e-01
    z[1,2,2]  R531      3.1402048468589783e-01
    z[1,2,2]  R532      1.5289390087127686e-01
    z[1,2,2]  R533      8.9429974555969238e-02
    z[1,2,2]  R534      -3.0457723140716553e-01
    z[1,2,2]  R535      2.4313895404338837e-01
    z[1,2,2]  R536      3.5214146971702576e-01
    z[1,2,2]  R537      0.198577880859375
    z[1,2,2]  R538      -2.6125302910804749e-01
    z[1,2,2]  R539      7.1913385391235352e-01
    z[1,2,2]  R540      -1.0600367933511734e-01
    z[1,2,2]  R541      -1.3923546671867371e-01
    z[1,2,2]  R542      7.0893031358718872e-01
    z[1,2,2]  R543      -4.0393617749214172e-01
    z[1,2,2]  R544      -2.6510453224182129e-01
    z[1,2,2]  R545      -2.4793711304664612e-01
    z[1,2,2]  R546      -1.9527323544025421e-01
    z[1,2,2]  R547      -2.3801873624324799e-01
    z[1,2,2]  R548      -4.2611122131347656e-01
    z[1,2,2]  R549      -4.0763118863105774e-01
    z[1,2,2]  R550      -2.6661166548728943e-01
    z[1,2,2]  R551      -3.6592435836791992e-01
    z[1,2,2]  R552      -1.8245643377304077e-01
    z[1,2,2]  R553      -8.1135082244873047e-01
    z[1,2,2]  R554      -0.775295615196228
    z[1,2,2]  R555      -7.3469394445419312e-01
    z[1,2,2]  R556      -7.4209457635879517e-01
    z[1,2,3]  R14       -1
    z[1,2,3]  R23       1
    z[1,2,3]  R483      -1
    z[1,2,3]  R484      1
    z[1,2,3]  R491      -4.5455229282379150e-01
    z[1,2,3]  R492      -5.6906771659851074e-01
    z[1,2,3]  R493      -3.2695877552032471e-01
    z[1,2,3]  R494      -2.5724312663078308e-01
    z[1,2,3]  R495      -2.0146018266677856e-01
    z[1,2,3]  R496      -4.9880608916282654e-01
    z[1,2,3]  R497      -6.2742674350738525e-01
    z[1,2,3]  R498      -0.527021050453186
    z[1,2,3]  R499      -4.4537079334259033e-01
    z[1,2,3]  R500      -3.8205111026763916e-01
    z[1,2,3]  R501      1.2880785763263702e-01
    z[1,2,3]  R502      5.7528215646743774e-01
    z[1,2,3]  R503      3.2055887579917908e-01
    z[1,2,3]  R504      3.7288346886634827e-01
    z[1,2,3]  R505      3.8196507096290588e-01
    z[1,2,3]  R506      1.0356844961643219e-01
    z[1,2,3]  R507      0.500627875328064
    z[1,2,3]  R508      3.7581780552864075e-01
    z[1,2,3]  R509      5.4066902399063110e-01
    z[1,2,3]  R510      3.5347390174865723e-01
    z[1,2,3]  R511      -1.6295136511325836e-01
    z[1,2,3]  R512      3.6049813032150269e-02
    z[1,2,3]  R513      1.4913326501846313e-01
    z[1,2,3]  R514      2.0327532291412354e-01
    z[1,2,3]  R515      -1.2226550839841366e-02
    z[1,2,3]  R516      2.1289777010679245e-02
    z[1,2,3]  R517      -7.7048338949680328e-02
    z[1,2,3]  R518      2.5974312424659729e-01
    z[1,2,3]  R519      2.9298624396324158e-01
    z[1,2,3]  R520      4.4194224476814270e-01
    z[1,2,3]  R521      3.9107095450162888e-02
    z[1,2,3]  R522      1.5430690348148346e-01
    z[1,2,3]  R523      -2.2678783535957336e-01
    z[1,2,3]  R524      2.3870329558849335e-01
    z[1,2,3]  R525      3.9376735687255859e-01
    z[1,2,3]  R526      1.3581918179988861e-01
    z[1,2,3]  R527      1.6972009837627411e-01
    z[1,2,3]  R528      -4.7885257005691528e-01
    z[1,2,3]  R529      -5.0333078950643539e-02
    z[1,2,3]  R530      -3.7363627552986145e-01
    z[1,2,3]  R531      -5.5583792924880981e-01
    z[1,2,3]  R532      -0.0460672564804554
    z[1,2,3]  R533      -2.7368506789207458e-01
    z[1,2,3]  R534      -2.0565721392631531e-01
    z[1,2,3]  R535      -8.2955203950405121e-02
    z[1,2,3]  R536      -2.9273739457130432e-01
    z[1,2,3]  R537      9.0377324819564819e-01
    z[1,2,3]  R538      8.3545857667922974e-01
    z[1,2,3]  R539      4.4935768842697144e-01
    z[1,2,3]  R540      2.7733248472213745e-01
    z[1,2,3]  R541      -1.2220747023820877e-01
    z[1,2,3]  R542      -5.6970175355672836e-02
    z[1,2,3]  R543      -3.3664211630821228e-01
    z[1,2,3]  R544      7.3629550635814667e-02
    z[1,2,3]  R545      0.557930588722229
    z[1,2,3]  R546      0.551186740398407
    z[1,2,3]  R547      3.8179707527160645e-01
    z[1,2,3]  R548      3.4594398736953735e-01
    z[1,2,3]  R549      3.0154392123222351e-01
    z[1,2,3]  R550      3.5131609439849854e-01
    z[1,2,3]  R551      3.1221404671669006e-01
    z[1,2,3]  R552      4.9124187231063843e-01
    z[1,2,3]  R553      1.1037503182888031e-01
    z[1,2,3]  R554      -7.1076013147830963e-02
    z[1,2,3]  R555      1.7651884257793427e-01
    z[1,2,3]  R556      1.7760708928108215e-02
    z[1,2,4]  R15       -1
    z[1,2,4]  R24       1
    z[1,2,4]  R485      -1
    z[1,2,4]  R486      1
    z[1,2,4]  R491      3.3072546124458313e-01
    z[1,2,4]  R492      -3.4881818294525146e-01
    z[1,2,4]  R493      -8.8620446622371674e-02
    z[1,2,4]  R494      1.4680328965187073e-01
    z[1,2,4]  R495      -4.4236642122268677e-01
    z[1,2,4]  R496      3.0451798439025879e-01
    z[1,2,4]  R497      5.1750338077545166e-01
    z[1,2,4]  R498      -1.9711346924304962e-01
    z[1,2,4]  R499      6.8620347976684570e-01
    z[1,2,4]  R500      -6.2515747547149658e-01
    z[1,2,4]  R501      1.4192202687263489e-01
    z[1,2,4]  R502      -2.8104245662689209e-02
    z[1,2,4]  R503      1.6148015856742859e-01
    z[1,2,4]  R504      5.4073834419250488e-01
    z[1,2,4]  R505      2.0981565117835999e-01
    z[1,2,4]  R506      5.7631433010101318e-01
    z[1,2,4]  R507      5.0944042205810547e-01
    z[1,2,4]  R508      1.2366279214620590e-01
    z[1,2,4]  R509      2.4005118012428284e-01
    z[1,2,4]  R510      3.2895141839981079e-01
    z[1,2,4]  R511      -9.9299162626266479e-02
    z[1,2,4]  R512      -1.8979972600936890e-01
    z[1,2,4]  R513      -1.4772635698318481e-01
    z[1,2,4]  R514      -1.7982470989227295e-01
    z[1,2,4]  R515      -2.7890071272850037e-02
    z[1,2,4]  R516      -3.4348908811807632e-02
    z[1,2,4]  R517      1.8405571579933167e-01
    z[1,2,4]  R518      -2.1979516744613647e-01
    z[1,2,4]  R519      2.4768868088722229e-01
    z[1,2,4]  R520      2.5145342946052551e-01
    z[1,2,4]  R521      2.6255629956722260e-02
    z[1,2,4]  R522      4.3436667323112488e-01
    z[1,2,4]  R523      3.3053183555603027e-01
    z[1,2,4]  R524      -1.3813333213329315e-01
    z[1,2,4]  R525      -9.9543467164039612e-02
    z[1,2,4]  R526      -3.5761246085166931e-01
    z[1,2,4]  R527      2.8522366285324097e-01
    z[1,2,4]  R528      1.7460164427757263e-01
    z[1,2,4]  R529      5.2828025817871094e-01
    z[1,2,4]  R530      -0.600789487361908
    z[1,2,4]  R531      -2.0685656368732452e-01
    z[1,2,4]  R532      0.564935028553009
    z[1,2,4]  R533      6.2383162975311279e-01
    z[1,2,4]  R534      3.1513506174087524e-01
    z[1,2,4]  R535      -1.8688105046749115e-01
    z[1,2,4]  R536      -4.5573839545249939e-01
    z[1,2,4]  R537      -3.6735687404870987e-02
    z[1,2,4]  R538      -1.6383193433284760e-01
    z[1,2,4]  R539      2.4072615429759026e-02
    z[1,2,4]  R540      -3.0005145072937012e-01
    z[1,2,4]  R541      -6.2298113107681274e-01
    z[1,2,4]  R542      -4.2758038640022278e-01
    z[1,2,4]  R543      -5.1841910928487778e-02
    z[1,2,4]  R544      3.7198910117149353e-01
    z[1,2,4]  R545      -2.3699709773063660e-01
    z[1,2,4]  R546      -2.8858028352260590e-02
    z[1,2,4]  R547      -0.290322870016098
    z[1,2,4]  R548      -1.6673433780670166e-01
    z[1,2,4]  R549      -1.1193389445543289e-01
    z[1,2,4]  R550      -3.5640573501586914e-01
    z[1,2,4]  R551      -2.8274014592170715e-01
    z[1,2,4]  R552      -3.7602904438972473e-01
    z[1,2,4]  R553      4.6913042664527893e-02
    z[1,2,4]  R554      -1.1471226811408997e-01
    z[1,2,4]  R555      6.2326043844223022e-02
    z[1,2,4]  R556      3.9983157068490982e-02
    z[1,2,5]  R16       -1
    z[1,2,5]  R25       1
    z[1,2,5]  R487      -1
    z[1,2,5]  R488      1
    z[1,2,5]  R491      -2.3038573563098907e-01
    z[1,2,5]  R492      -6.5410476922988892e-01
    z[1,2,5]  R493      -4.6232935786247253e-01
    z[1,2,5]  R494      -4.6229395270347595e-01
    z[1,2,5]  R495      -4.3729913234710693e-01
    z[1,2,5]  R496      -4.0501350164413452e-01
    z[1,2,5]  R497      -1.4188054203987122e-01
    z[1,2,5]  R498      0.218091681599617
    z[1,2,5]  R499      -1.7230643332004547e-01
    z[1,2,5]  R500      1.6776913404464722e-01
    z[1,2,5]  R501      -3.0619594454765320e-01
    z[1,2,5]  R502      -2.8887179493904114e-01
    z[1,2,5]  R503      -5.6227338500320911e-03
    z[1,2,5]  R504      5.9849033132195473e-03
    z[1,2,5]  R505      -1.1563264578580856e-01
    z[1,2,5]  R506      2.4274872243404388e-01
    z[1,2,5]  R507      -9.8129369318485260e-02
    z[1,2,5]  R508      4.8437666893005371e-01
    z[1,2,5]  R509      3.0878007411956787e-01
    z[1,2,5]  R510      1.9394531846046448e-01
    z[1,2,5]  R511      -3.2390362024307251e-01
    z[1,2,5]  R512      3.6178052425384521e-01
    z[1,2,5]  R513      -3.2388812303543091e-01
    z[1,2,5]  R514      1.9500320777297020e-02
    z[1,2,5]  R515      2.6371777057647705e-02
    z[1,2,5]  R516      1.2408478558063507e-01
    z[1,2,5]  R517      4.4811934232711792e-01
    z[1,2,5]  R518      -1.1433947831392288e-01
    z[1,2,5]  R519      1.9704459607601166e-01
    z[1,2,5]  R520      4.3167270720005035e-02
    z[1,2,5]  R521      6.1495050787925720e-02
    z[1,2,5]  R522      2.4743005633354187e-01
    z[1,2,5]  R523      -3.8357576727867126e-01
    z[1,2,5]  R524      -6.0128504037857056e-01
    z[1,2,5]  R525      -1.4546290040016174e-01
    z[1,2,5]  R526      -2.5385549664497375e-01
    z[1,2,5]  R527      6.0403876006603241e-02
    z[1,2,5]  R528      2.8038170933723450e-01
    z[1,2,5]  R529      1.4665973186492920e-01
    z[1,2,5]  R530      1.8386904895305634e-01
    z[1,2,5]  R531      5.6148413568735123e-02
    z[1,2,5]  R532      -3.9422157406806946e-01
    z[1,2,5]  R533      -9.2523522675037384e-02
    z[1,2,5]  R534      -6.8087595701217651e-01
    z[1,2,5]  R535      -6.5322220325469971e-01
    z[1,2,5]  R536      -1.2974390387535095e-01
    z[1,2,5]  R537      1.0559809952974319e-01
    z[1,2,5]  R538      2.2686554118990898e-02
    z[1,2,5]  R539      -1.3774999976158142e-01
    z[1,2,5]  R540      5.6754392385482788e-01
    z[1,2,5]  R541      -5.3466308116912842e-01
    z[1,2,5]  R542      1.4480036497116089e-01
    z[1,2,5]  R543      5.1891487836837769e-01
    z[1,2,5]  R544      6.8477618694305420e-01
    z[1,2,5]  R545      4.1568911075592041e-01
    z[1,2,5]  R546      5.2264976501464844e-01
    z[1,2,5]  R547      5.3903043270111084e-01
    z[1,2,5]  R548      4.7658559679985046e-01
    z[1,2,5]  R549      5.8064532279968262e-01
    z[1,2,5]  R550      3.8943758606910706e-01
    z[1,2,5]  R551      5.0531727075576782e-01
    z[1,2,5]  R552      1.6401119530200958e-01
    z[1,2,5]  R553      5.0206100940704346e-01
    z[1,2,5]  R554      5.5847585201263428e-01
    z[1,2,5]  R555      4.9424162507057190e-01
    z[1,2,5]  R556      6.1668062210083008e-01
    z[1,2,6]  R17       -1
    z[1,2,6]  R26       1
    z[1,2,6]  R489      -1
    z[1,2,6]  R490      1
    z[1,2,6]  R491      9.2874079942703247e-02
    z[1,2,6]  R492      -2.6600062847137451e-01
    z[1,2,6]  R493      -2.3796321451663971e-01
    z[1,2,6]  R494      -2.0065556466579437e-01
    z[1,2,6]  R495      1.7862161993980408e-01
    z[1,2,6]  R496      4.6858021616935730e-01
    z[1,2,6]  R497      -1.8807673826813698e-02
    z[1,2,6]  R498      -2.3504647612571716e-01
    z[1,2,6]  R499      -9.0385437011718750e-02
    z[1,2,6]  R500      0.0174432210624218
    z[1,2,6]  R501      1.0809668898582458e-01
    z[1,2,6]  R502      7.0972159504890442e-02
    z[1,2,6]  R503      -2.8203630447387695e-01
    z[1,2,6]  R504      1.8427161872386932e-01
    z[1,2,6]  R505      5.9344846010208130e-01
    z[1,2,6]  R506      -3.5556644201278687e-01
    z[1,2,6]  R507      -1.4257748425006866e-01
    z[1,2,6]  R508      -3.3668524026870728e-01
    z[1,2,6]  R509      -4.2820525169372559e-01
    z[1,2,6]  R510      -5.3473824262619019e-01
    z[1,2,6]  R511      -1.9270603358745575e-01
    z[1,2,6]  R512      -1.5577773749828339e-01
    z[1,2,6]  R513      -4.2021432891488075e-03
    z[1,2,6]  R514      -1.2106308341026306e-01
    z[1,2,6]  R515      9.1403447091579437e-02
    z[1,2,6]  R516      0.148995041847229
    z[1,2,6]  R517      3.9363037794828415e-02
    z[1,2,6]  R518      4.3800309300422668e-01
    z[1,2,6]  R519      -3.6943295598030090e-01
    z[1,2,6]  R520      0.294167160987854
    z[1,2,6]  R521      -2.9792159795761108e-01
    z[1,2,6]  R522      3.3918708562850952e-01
    z[1,2,6]  R523      1.8442739546298981e-01
    z[1,2,6]  R524      1.0837730765342712e-01
    z[1,2,6]  R525      3.7678909301757812e-01
    z[1,2,6]  R526      7.0934516191482544e-01
    z[1,2,6]  R527      3.4553521871566772e-01
    z[1,2,6]  R528      1.8147693946957588e-02
    z[1,2,6]  R529      -2.3036184906959534e-01
    z[1,2,6]  R530      1.3844203203916550e-02
    z[1,2,6]  R531      -2.8831312060356140e-01
    z[1,2,6]  R532      2.6856502890586853e-01
    z[1,2,6]  R533      4.5523303747177124e-01
    z[1,2,6]  R534      -7.2286748327314854e-03
    z[1,2,6]  R535      4.3456846475601196e-01
    z[1,2,6]  R536      6.4778155088424683e-01
    z[1,2,6]  R537      -0.33290895819664
    z[1,2,6]  R538      -3.2992663979530334e-01
    z[1,2,6]  R539      -1.5846803784370422e-01
    z[1,2,6]  R540      2.5262561440467834e-01
    z[1,2,6]  R541      -2.4382162094116211e-01
    z[1,2,6]  R542      1.0802300274372101e-01
    z[1,2,6]  R543      -5.2457344532012939e-01
    z[1,2,6]  R544      -1.3604341447353363e-01
    z[1,2,6]  R545      -5.9329345822334290e-02
    z[1,2,6]  R546      -8.3711788058280945e-02
    z[1,2,6]  R547      1.5771028399467468e-01
    z[1,2,6]  R548      2.6348903775215149e-01
    z[1,2,6]  R549      1.6615954041481018e-01
    z[1,2,6]  R550      4.2247197031974792e-01
    z[1,2,6]  R551      7.8150548040866852e-02
    z[1,2,6]  R552      4.3891948461532593e-01
    z[1,2,6]  R553      1.9626709818840027e-01
    z[1,2,6]  R554      1.3614273071289062e-01
    z[1,2,6]  R555      2.6613363623619080e-01
    z[1,2,6]  R556      4.8746760934591293e-02
    z[2,1,0]  R11       1
    z[2,1,0]  R20       -1
    z[2,1,0]  R557      -1
    z[2,1,0]  R558      1
    z[2,1,0]  R571      -5.1831060647964478e-01
    z[2,1,0]  R572      3.4386706352233887e-01
    z[2,1,0]  R573      -1.6055357456207275e-01
    z[2,1,0]  R574      -3.1579840183258057e-01
    z[2,1,0]  R575      -5.1425721496343613e-02
    z[2,1,0]  R576      3.0115556716918945e-01
    z[2,1,0]  R577      1.2531785666942596e-01
    z[2,1,0]  R578      4.2257830500602722e-02
    z[2,1,0]  R579      3.7992015480995178e-01
    z[2,1,0]  R580      5.2165144681930542e-01
    z[2,1,0]  R581      4.7604960203170776e-01
    z[2,1,0]  R582      3.3365431427955627e-01
    z[2,1,0]  R583      2.1986183524131775e-01
    z[2,1,0]  R584      5.3151583671569824e-01
    z[2,1,0]  R585      7.1910239756107330e-02
    z[2,1,0]  R586      -5.5746231228113174e-02
    z[2,1,0]  R587      1.4154396951198578e-01
    z[2,1,0]  R588      -1.1921548098325729e-01
    z[2,1,0]  R589      -1.4973938465118408e-02
    z[2,1,0]  R590      -4.2232591658830643e-02
    z[2,1,0]  R591      1.4951783418655396e-01
    z[2,1,0]  R592      -2.3622293770313263e-01
    z[2,1,0]  R593      1.8643289804458618e-01
    z[2,1,0]  R594      2.2332927212119102e-02
    z[2,1,0]  R595      3.0346214771270752e-01
    z[2,1,0]  R596      -2.4205325543880463e-01
    z[2,1,0]  R597      6.9864052347838879e-03
    z[2,1,0]  R598      1.5159071981906891e-01
    z[2,1,0]  R599      -4.3520724773406982e-01
    z[2,1,0]  R600      -3.1087413430213928e-01
    z[2,1,0]  R601      -1.4469125866889954e-01
    z[2,1,0]  R602      -4.7290101647377014e-01
    z[2,1,0]  R603      -5.1100796461105347e-01
    z[2,1,0]  R604      1.3841454684734344e-01
    z[2,1,0]  R605      4.0108391642570496e-01
    z[2,1,0]  R606      1.1373510956764221e-01
    z[2,1,0]  R607      -2.6660263538360596e-01
    z[2,1,0]  R608      -2.3148806393146515e-01
    z[2,1,0]  R609      1.3688498735427856e-01
    z[2,1,0]  R610      7.5992047786712646e-02
    z[2,1,0]  R611      -1.2372570484876633e-01
    z[2,1,0]  R612      -0.128860741853714
    z[2,1,0]  R613      -2.0290514826774597e-01
    z[2,1,0]  R614      -5.3697037696838379e-01
    z[2,1,0]  R615      -1.1369368992745876e-02
    z[2,1,0]  R616      -5.5578452348709106e-01
    z[2,1,0]  R617      0.322528600692749
    z[2,1,0]  R618      1.2251260876655579e-01
    z[2,1,0]  R619      1.1202982813119888e-01
    z[2,1,0]  R620      -0.079043909907341
    z[2,1,0]  R621      1.2563639879226685e-01
    z[2,1,0]  R622      4.3147706985473633e-01
    z[2,1,0]  R623      2.5280410051345825e-01
    z[2,1,0]  R624      4.7436505556106567e-03
    z[2,1,0]  R625      2.2293041646480560e-01
    z[2,1,0]  R626      -0.0975753590464592
    z[2,1,0]  R627      -2.9630562663078308e-01
    z[2,1,0]  R628      -1.5747289359569550e-01
    z[2,1,0]  R629      3.2779577374458313e-01
    z[2,1,0]  R630      -1.8186327815055847e-01
    z[2,1,0]  R631      -2.7668768167495728e-01
    z[2,1,0]  R632      -8.4725864231586456e-02
    z[2,1,0]  R633      2.0847450196743011e-01
    z[2,1,0]  R634      2.8710582852363586e-01
    z[2,1,0]  R635      3.1074506044387817e-01
    z[2,1,0]  R636      3.2126989960670471e-01
    z[2,1,1]  R12       1
    z[2,1,1]  R21       -1
    z[2,1,1]  R559      -1
    z[2,1,1]  R560      1
    z[2,1,1]  R571      4.4127404689788818e-01
    z[2,1,1]  R572      5.5638778209686279e-01
    z[2,1,1]  R573      -5.3512406349182129e-01
    z[2,1,1]  R574      -0.449727326631546
    z[2,1,1]  R575      -5.2998477220535278e-01
    z[2,1,1]  R576      -2.3548798263072968e-01
    z[2,1,1]  R577      -6.8755798041820526e-02
    z[2,1,1]  R578      -3.0945608019828796e-01
    z[2,1,1]  R579      -3.0317991971969604e-01
    z[2,1,1]  R580      -4.0468877553939819e-01
    z[2,1,1]  R581      7.5076855719089508e-02
    z[2,1,1]  R582      -4.0912812948226929e-01
    z[2,1,1]  R583      -3.5781404376029968e-01
    z[2,1,1]  R584      -1.2643989920616150e-01
    z[2,1,1]  R585      6.2416708469390869e-01
    z[2,1,1]  R586      6.1151504516601562e-01
    z[2,1,1]  R587      6.1467844247817993e-01
    z[2,1,1]  R588      6.0014915466308594e-01
    z[2,1,1]  R589      6.0448038578033447e-01
    z[2,1,1]  R590      5.8867859840393066e-01
    z[2,1,1]  R591      6.3629478216171265e-01
    z[2,1,1]  R592      0.555555522441864
    z[2,1,1]  R593      -4.4533852487802505e-02
    z[2,1,1]  R594      -2.2310809791088104e-01
    z[2,1,1]  R595      -1.3412791490554810e-01
    z[2,1,1]  R596      -0.0782335102558136
    z[2,1,1]  R597      -2.1872717142105103e-01
    z[2,1,1]  R598      0.0711594671010971
    z[2,1,1]  R599      -4.4952562451362610e-01
    z[2,1,1]  R600      3.8730540871620178e-01
    z[2,1,1]  R601      5.3261183202266693e-02
    z[2,1,1]  R602      2.1477538347244263e-01
    z[2,1,1]  R603      -2.2816047072410583e-01
    z[2,1,1]  R604      3.4862717986106873e-01
    z[2,1,1]  R605      3.0483883619308472e-01
    z[2,1,1]  R606      -0.564039409160614
    z[2,1,1]  R607      -7.6693505048751831e-01
    z[2,1,1]  R608      -6.9930177927017212e-01
    z[2,1,1]  R609      -7.0424813032150269e-01
    z[2,1,1]  R610      -7.2674477100372314e-01
    z[2,1,1]  R611      -6.5514838695526123e-01
    z[2,1,1]  R612      -6.4812636375427246e-01
    z[2,1,1]  R613      -6.4683514833450317e-01
    z[2,1,1]  R614      -0.296928733587265
    z[2,1,1]  R615      -6.0688656568527222e-01
    z[2,1,1]  R616      -3.0988302826881409e-01
    z[2,1,1]  R617      8.4352749586105347e-01
    z[2,1,1]  R618      8.8191956281661987e-01
    z[2,1,1]  R619      9.0987449884414673e-01
    z[2,1,1]  R620      0.946040689945221
    z[2,1,1]  R621      7.7698063850402832e-01
    z[2,1,1]  R622      0.773720383644104
    z[2,1,1]  R623      8.2341051101684570e-01
    z[2,1,1]  R624      8.2002300024032593e-01
    z[2,1,1]  R625      7.7736425399780273e-01
    z[2,1,1]  R626      7.9500550031661987e-01
    z[2,1,1]  R627      -8.6459028720855713e-01
    z[2,1,1]  R628      -7.6453024148941040e-01
    z[2,1,1]  R629      -6.3956683874130249e-01
    z[2,1,1]  R630      -4.3450099229812622e-01
    z[2,1,1]  R631      -3.3394771814346313e-01
    z[2,1,1]  R632      -4.9412319064140320e-01
    z[2,1,1]  R633      8.4681063890457153e-01
    z[2,1,1]  R634      -5.7036370038986206e-01
    z[2,1,1]  R635      6.7065447568893433e-01
    z[2,1,1]  R636      5.8970105648040771e-01
    z[2,1,2]  R13       1
    z[2,1,2]  R22       -1
    z[2,1,2]  R561      -1
    z[2,1,2]  R562      1
    z[2,1,2]  R571      3.1402048468589783e-01
    z[2,1,2]  R572      1.5289390087127686e-01
    z[2,1,2]  R573      8.9429974555969238e-02
    z[2,1,2]  R574      -3.0457723140716553e-01
    z[2,1,2]  R575      2.4313895404338837e-01
    z[2,1,2]  R576      3.5214146971702576e-01
    z[2,1,2]  R577      0.198577880859375
    z[2,1,2]  R578      -2.6125302910804749e-01
    z[2,1,2]  R579      7.1913385391235352e-01
    z[2,1,2]  R580      -1.0600367933511734e-01
    z[2,1,2]  R581      -1.3923546671867371e-01
    z[2,1,2]  R582      7.0893031358718872e-01
    z[2,1,2]  R583      -4.0393617749214172e-01
    z[2,1,2]  R584      -2.6510453224182129e-01
    z[2,1,2]  R585      -2.4793711304664612e-01
    z[2,1,2]  R586      -1.9527323544025421e-01
    z[2,1,2]  R587      -2.3801873624324799e-01
    z[2,1,2]  R588      -4.2611122131347656e-01
    z[2,1,2]  R589      -4.0763118863105774e-01
    z[2,1,2]  R590      -2.6661166548728943e-01
    z[2,1,2]  R591      -3.6592435836791992e-01
    z[2,1,2]  R592      -1.8245643377304077e-01
    z[2,1,2]  R593      -8.1135082244873047e-01
    z[2,1,2]  R594      -0.775295615196228
    z[2,1,2]  R595      -7.3469394445419312e-01
    z[2,1,2]  R596      -7.4209457635879517e-01
    z[2,1,2]  R597      7.5789797306060791e-01
    z[2,1,2]  R598      1.6683810949325562e-01
    z[2,1,2]  R599      4.7264236211776733e-01
    z[2,1,2]  R600      6.4159828424453735e-01
    z[2,1,2]  R601      7.1890002489089966e-01
    z[2,1,2]  R602      7.1373388171195984e-02
    z[2,1,2]  R603      0.0696830004453659
    z[2,1,2]  R604      6.6323804855346680e-01
    z[2,1,2]  R605      -1.9777624309062958e-01
    z[2,1,2]  R606      3.2200655341148376e-01
    z[2,1,2]  R607      -4.4560018181800842e-01
    z[2,1,2]  R608      -1.9278754293918610e-01
    z[2,1,2]  R609      -5.2620077133178711e-01
    z[2,1,2]  R610      -2.5206919759511948e-02
    z[2,1,2]  R611      -0.000703649187926203
    z[2,1,2]  R612      -1.8737143278121948e-01
    z[2,1,2]  R613      -1.7838209867477417e-02
    z[2,1,2]  R614      3.4494474530220032e-01
    z[2,1,2]  R615      5.3917411714792252e-02
    z[2,1,2]  R616      -1.9586580991744995e-01
    z[2,1,2]  R617      -7.7291406691074371e-02
    z[2,1,2]  R618      -1.2138006836175919e-01
    z[2,1,2]  R619      1.0292125493288040e-01
    z[2,1,2]  R620      -1.0032343864440918e-01
    z[2,1,2]  R621      -6.0871934890747070e-01
    z[2,1,2]  R622      4.1946947574615479e-01
    z[2,1,2]  R623      -1.2614218890666962e-01
    z[2,1,2]  R624      -8.2723297178745270e-02
    z[2,1,2]  R625      1.5332648158073425e-01
    z[2,1,2]  R626      1.0726466029882431e-01
    z[2,1,2]  R627      2.6444083452224731e-01
    z[2,1,2]  R628      4.4059496372938156e-02
    z[2,1,2]  R629      3.7639924883842468e-01
    z[2,1,2]  R630      5.7339799404144287e-01
    z[2,1,2]  R631      6.9558018445968628e-01
    z[2,1,2]  R632      1.8632547557353973e-01
    z[2,1,2]  R633      7.9054161906242371e-02
    z[2,1,2]  R634      -5.0351446866989136e-01
    z[2,1,2]  R635      3.1220319867134094e-01
    z[2,1,2]  R636      -1.2036138027906418e-01
    z[2,1,3]  R14       1
    z[2,1,3]  R23       -1
    z[2,1,3]  R563      -1
    z[2,1,3]  R564      1
    z[2,1,3]  R571      -5.5583792924880981e-01
    z[2,1,3]  R572      -0.0460672564804554
    z[2,1,3]  R573      -2.7368506789207458e-01
    z[2,1,3]  R574      -2.0565721392631531e-01
    z[2,1,3]  R575      -8.2955203950405121e-02
    z[2,1,3]  R576      -2.9273739457130432e-01
    z[2,1,3]  R577      9.0377324819564819e-01
    z[2,1,3]  R578      8.3545857667922974e-01
    z[2,1,3]  R579      4.4935768842697144e-01
    z[2,1,3]  R580      2.7733248472213745e-01
    z[2,1,3]  R581      -1.2220747023820877e-01
    z[2,1,3]  R582      -5.6970175355672836e-02
    z[2,1,3]  R583      -3.3664211630821228e-01
    z[2,1,3]  R584      7.3629550635814667e-02
    z[2,1,3]  R585      0.557930588722229
    z[2,1,3]  R586      0.551186740398407
    z[2,1,3]  R587      3.8179707527160645e-01
    z[2,1,3]  R588      3.4594398736953735e-01
    z[2,1,3]  R589      3.0154392123222351e-01
    z[2,1,3]  R590      3.5131609439849854e-01
    z[2,1,3]  R591      3.1221404671669006e-01
    z[2,1,3]  R592      4.9124187231063843e-01
    z[2,1,3]  R593      1.1037503182888031e-01
    z[2,1,3]  R594      -7.1076013147830963e-02
    z[2,1,3]  R595      1.7651884257793427e-01
    z[2,1,3]  R596      1.7760708928108215e-02
    z[2,1,3]  R597      -4.5455229282379150e-01
    z[2,1,3]  R598      -5.6906771659851074e-01
    z[2,1,3]  R599      -3.2695877552032471e-01
    z[2,1,3]  R600      -2.5724312663078308e-01
    z[2,1,3]  R601      -2.0146018266677856e-01
    z[2,1,3]  R602      -4.9880608916282654e-01
    z[2,1,3]  R603      -6.2742674350738525e-01
    z[2,1,3]  R604      -0.527021050453186
    z[2,1,3]  R605      -4.4537079334259033e-01
    z[2,1,3]  R606      -3.8205111026763916e-01
    z[2,1,3]  R607      1.2880785763263702e-01
    z[2,1,3]  R608      5.7528215646743774e-01
    z[2,1,3]  R609      3.2055887579917908e-01
    z[2,1,3]  R610      3.7288346886634827e-01
    z[2,1,3]  R611      3.8196507096290588e-01
    z[2,1,3]  R612      1.0356844961643219e-01
    z[2,1,3]  R613      0.500627875328064
    z[2,1,3]  R614      3.7581780552864075e-01
    z[2,1,3]  R615      5.4066902399063110e-01
    z[2,1,3]  R616      3.5347390174865723e-01
    z[2,1,3]  R617      -1.6295136511325836e-01
    z[2,1,3]  R618      3.6049813032150269e-02
    z[2,1,3]  R619      1.4913326501846313e-01
    z[2,1,3]  R620      2.0327532291412354e-01
    z[2,1,3]  R621      -1.2226550839841366e-02
    z[2,1,3]  R622      2.1289777010679245e-02
    z[2,1,3]  R623      -7.7048338949680328e-02
    z[2,1,3]  R624      2.5974312424659729e-01
    z[2,1,3]  R625      2.9298624396324158e-01
    z[2,1,3]  R626      4.4194224476814270e-01
    z[2,1,3]  R627      3.9107095450162888e-02
    z[2,1,3]  R628      1.5430690348148346e-01
    z[2,1,3]  R629      -2.2678783535957336e-01
    z[2,1,3]  R630      2.3870329558849335e-01
    z[2,1,3]  R631      3.9376735687255859e-01
    z[2,1,3]  R632      1.3581918179988861e-01
    z[2,1,3]  R633      1.6972009837627411e-01
    z[2,1,3]  R634      -4.7885257005691528e-01
    z[2,1,3]  R635      -5.0333078950643539e-02
    z[2,1,3]  R636      -3.7363627552986145e-01
    z[2,1,4]  R15       1
    z[2,1,4]  R24       -1
    z[2,1,4]  R565      -1
    z[2,1,4]  R566      1
    z[2,1,4]  R571      -2.0685656368732452e-01
    z[2,1,4]  R572      0.564935028553009
    z[2,1,4]  R573      6.2383162975311279e-01
    z[2,1,4]  R574      3.1513506174087524e-01
    z[2,1,4]  R575      -1.8688105046749115e-01
    z[2,1,4]  R576      -4.5573839545249939e-01
    z[2,1,4]  R577      -3.6735687404870987e-02
    z[2,1,4]  R578      -1.6383193433284760e-01
    z[2,1,4]  R579      2.4072615429759026e-02
    z[2,1,4]  R580      -3.0005145072937012e-01
    z[2,1,4]  R581      -6.2298113107681274e-01
    z[2,1,4]  R582      -4.2758038640022278e-01
    z[2,1,4]  R583      -5.1841910928487778e-02
    z[2,1,4]  R584      3.7198910117149353e-01
    z[2,1,4]  R585      -2.3699709773063660e-01
    z[2,1,4]  R586      -2.8858028352260590e-02
    z[2,1,4]  R587      -0.290322870016098
    z[2,1,4]  R588      -1.6673433780670166e-01
    z[2,1,4]  R589      -1.1193389445543289e-01
    z[2,1,4]  R590      -3.5640573501586914e-01
    z[2,1,4]  R591      -2.8274014592170715e-01
    z[2,1,4]  R592      -3.7602904438972473e-01
    z[2,1,4]  R593      4.6913042664527893e-02
    z[2,1,4]  R594      -1.1471226811408997e-01
    z[2,1,4]  R595      6.2326043844223022e-02
    z[2,1,4]  R596      3.9983157068490982e-02
    z[2,1,4]  R597      3.3072546124458313e-01
    z[2,1,4]  R598      -3.4881818294525146e-01
    z[2,1,4]  R599      -8.8620446622371674e-02
    z[2,1,4]  R600      1.4680328965187073e-01
    z[2,1,4]  R601      -4.4236642122268677e-01
    z[2,1,4]  R602      3.0451798439025879e-01
    z[2,1,4]  R603      5.1750338077545166e-01
    z[2,1,4]  R604      -1.9711346924304962e-01
    z[2,1,4]  R605      6.8620347976684570e-01
    z[2,1,4]  R606      -6.2515747547149658e-01
    z[2,1,4]  R607      1.4192202687263489e-01
    z[2,1,4]  R608      -2.8104245662689209e-02
    z[2,1,4]  R609      1.6148015856742859e-01
    z[2,1,4]  R610      5.4073834419250488e-01
    z[2,1,4]  R611      2.0981565117835999e-01
    z[2,1,4]  R612      5.7631433010101318e-01
    z[2,1,4]  R613      5.0944042205810547e-01
    z[2,1,4]  R614      1.2366279214620590e-01
    z[2,1,4]  R615      2.4005118012428284e-01
    z[2,1,4]  R616      3.2895141839981079e-01
    z[2,1,4]  R617      -9.9299162626266479e-02
    z[2,1,4]  R618      -1.8979972600936890e-01
    z[2,1,4]  R619      -1.4772635698318481e-01
    z[2,1,4]  R620      -1.7982470989227295e-01
    z[2,1,4]  R621      -2.7890071272850037e-02
    z[2,1,4]  R622      -3.4348908811807632e-02
    z[2,1,4]  R623      1.8405571579933167e-01
    z[2,1,4]  R624      -2.1979516744613647e-01
    z[2,1,4]  R625      2.4768868088722229e-01
    z[2,1,4]  R626      2.5145342946052551e-01
    z[2,1,4]  R627      2.6255629956722260e-02
    z[2,1,4]  R628      4.3436667323112488e-01
    z[2,1,4]  R629      3.3053183555603027e-01
    z[2,1,4]  R630      -1.3813333213329315e-01
    z[2,1,4]  R631      -9.9543467164039612e-02
    z[2,1,4]  R632      -3.5761246085166931e-01
    z[2,1,4]  R633      2.8522366285324097e-01
    z[2,1,4]  R634      1.7460164427757263e-01
    z[2,1,4]  R635      5.2828025817871094e-01
    z[2,1,4]  R636      -0.600789487361908
    z[2,1,5]  R16       1
    z[2,1,5]  R25       -1
    z[2,1,5]  R567      -1
    z[2,1,5]  R568      1
    z[2,1,5]  R571      5.6148413568735123e-02
    z[2,1,5]  R572      -3.9422157406806946e-01
    z[2,1,5]  R573      -9.2523522675037384e-02
    z[2,1,5]  R574      -6.8087595701217651e-01
    z[2,1,5]  R575      -6.5322220325469971e-01
    z[2,1,5]  R576      -1.2974390387535095e-01
    z[2,1,5]  R577      1.0559809952974319e-01
    z[2,1,5]  R578      2.2686554118990898e-02
    z[2,1,5]  R579      -1.3774999976158142e-01
    z[2,1,5]  R580      5.6754392385482788e-01
    z[2,1,5]  R581      -5.3466308116912842e-01
    z[2,1,5]  R582      1.4480036497116089e-01
    z[2,1,5]  R583      5.1891487836837769e-01
    z[2,1,5]  R584      6.8477618694305420e-01
    z[2,1,5]  R585      4.1568911075592041e-01
    z[2,1,5]  R586      5.2264976501464844e-01
    z[2,1,5]  R587      5.3903043270111084e-01
    z[2,1,5]  R588      4.7658559679985046e-01
    z[2,1,5]  R589      5.8064532279968262e-01
    z[2,1,5]  R590      3.8943758606910706e-01
    z[2,1,5]  R591      5.0531727075576782e-01
    z[2,1,5]  R592      1.6401119530200958e-01
    z[2,1,5]  R593      5.0206100940704346e-01
    z[2,1,5]  R594      5.5847585201263428e-01
    z[2,1,5]  R595      4.9424162507057190e-01
    z[2,1,5]  R596      6.1668062210083008e-01
    z[2,1,5]  R597      -2.3038573563098907e-01
    z[2,1,5]  R598      -6.5410476922988892e-01
    z[2,1,5]  R599      -4.6232935786247253e-01
    z[2,1,5]  R600      -4.6229395270347595e-01
    z[2,1,5]  R601      -4.3729913234710693e-01
    z[2,1,5]  R602      -4.0501350164413452e-01
    z[2,1,5]  R603      -1.4188054203987122e-01
    z[2,1,5]  R604      0.218091681599617
    z[2,1,5]  R605      -1.7230643332004547e-01
    z[2,1,5]  R606      1.6776913404464722e-01
    z[2,1,5]  R607      -3.0619594454765320e-01
    z[2,1,5]  R608      -2.8887179493904114e-01
    z[2,1,5]  R609      -5.6227338500320911e-03
    z[2,1,5]  R610      5.9849033132195473e-03
    z[2,1,5]  R611      -1.1563264578580856e-01
    z[2,1,5]  R612      2.4274872243404388e-01
    z[2,1,5]  R613      -9.8129369318485260e-02
    z[2,1,5]  R614      4.8437666893005371e-01
    z[2,1,5]  R615      3.0878007411956787e-01
    z[2,1,5]  R616      1.9394531846046448e-01
    z[2,1,5]  R617      -3.2390362024307251e-01
    z[2,1,5]  R618      3.6178052425384521e-01
    z[2,1,5]  R619      -3.2388812303543091e-01
    z[2,1,5]  R620      1.9500320777297020e-02
    z[2,1,5]  R621      2.6371777057647705e-02
    z[2,1,5]  R622      1.2408478558063507e-01
    z[2,1,5]  R623      4.4811934232711792e-01
    z[2,1,5]  R624      -1.1433947831392288e-01
    z[2,1,5]  R625      1.9704459607601166e-01
    z[2,1,5]  R626      4.3167270720005035e-02
    z[2,1,5]  R627      6.1495050787925720e-02
    z[2,1,5]  R628      2.4743005633354187e-01
    z[2,1,5]  R629      -3.8357576727867126e-01
    z[2,1,5]  R630      -6.0128504037857056e-01
    z[2,1,5]  R631      -1.4546290040016174e-01
    z[2,1,5]  R632      -2.5385549664497375e-01
    z[2,1,5]  R633      6.0403876006603241e-02
    z[2,1,5]  R634      2.8038170933723450e-01
    z[2,1,5]  R635      1.4665973186492920e-01
    z[2,1,5]  R636      1.8386904895305634e-01
    z[2,1,6]  R17       1
    z[2,1,6]  R26       -1
    z[2,1,6]  R569      -1
    z[2,1,6]  R570      1
    z[2,1,6]  R571      -2.8831312060356140e-01
    z[2,1,6]  R572      2.6856502890586853e-01
    z[2,1,6]  R573      4.5523303747177124e-01
    z[2,1,6]  R574      -7.2286748327314854e-03
    z[2,1,6]  R575      4.3456846475601196e-01
    z[2,1,6]  R576      6.4778155088424683e-01
    z[2,1,6]  R577      -0.33290895819664
    z[2,1,6]  R578      -3.2992663979530334e-01
    z[2,1,6]  R579      -1.5846803784370422e-01
    z[2,1,6]  R580      2.5262561440467834e-01
    z[2,1,6]  R581      -2.4382162094116211e-01
    z[2,1,6]  R582      1.0802300274372101e-01
    z[2,1,6]  R583      -5.2457344532012939e-01
    z[2,1,6]  R584      -1.3604341447353363e-01
    z[2,1,6]  R585      -5.9329345822334290e-02
    z[2,1,6]  R586      -8.3711788058280945e-02
    z[2,1,6]  R587      1.5771028399467468e-01
    z[2,1,6]  R588      2.6348903775215149e-01
    z[2,1,6]  R589      1.6615954041481018e-01
    z[2,1,6]  R590      4.2247197031974792e-01
    z[2,1,6]  R591      7.8150548040866852e-02
    z[2,1,6]  R592      4.3891948461532593e-01
    z[2,1,6]  R593      1.9626709818840027e-01
    z[2,1,6]  R594      1.3614273071289062e-01
    z[2,1,6]  R595      2.6613363623619080e-01
    z[2,1,6]  R596      4.8746760934591293e-02
    z[2,1,6]  R597      9.2874079942703247e-02
    z[2,1,6]  R598      -2.6600062847137451e-01
    z[2,1,6]  R599      -2.3796321451663971e-01
    z[2,1,6]  R600      -2.0065556466579437e-01
    z[2,1,6]  R601      1.7862161993980408e-01
    z[2,1,6]  R602      4.6858021616935730e-01
    z[2,1,6]  R603      -1.8807673826813698e-02
    z[2,1,6]  R604      -2.3504647612571716e-01
    z[2,1,6]  R605      -9.0385437011718750e-02
    z[2,1,6]  R606      0.0174432210624218
    z[2,1,6]  R607      1.0809668898582458e-01
    z[2,1,6]  R608      7.0972159504890442e-02
    z[2,1,6]  R609      -2.8203630447387695e-01
    z[2,1,6]  R610      1.8427161872386932e-01
    z[2,1,6]  R611      5.9344846010208130e-01
    z[2,1,6]  R612      -3.5556644201278687e-01
    z[2,1,6]  R613      -1.4257748425006866e-01
    z[2,1,6]  R614      -3.3668524026870728e-01
    z[2,1,6]  R615      -4.2820525169372559e-01
    z[2,1,6]  R616      -5.3473824262619019e-01
    z[2,1,6]  R617      -1.9270603358745575e-01
    z[2,1,6]  R618      -1.5577773749828339e-01
    z[2,1,6]  R619      -4.2021432891488075e-03
    z[2,1,6]  R620      -1.2106308341026306e-01
    z[2,1,6]  R621      9.1403447091579437e-02
    z[2,1,6]  R622      0.148995041847229
    z[2,1,6]  R623      3.9363037794828415e-02
    z[2,1,6]  R624      4.3800309300422668e-01
    z[2,1,6]  R625      -3.6943295598030090e-01
    z[2,1,6]  R626      0.294167160987854
    z[2,1,6]  R627      -2.9792159795761108e-01
    z[2,1,6]  R628      3.3918708562850952e-01
    z[2,1,6]  R629      1.8442739546298981e-01
    z[2,1,6]  R630      1.0837730765342712e-01
    z[2,1,6]  R631      3.7678909301757812e-01
    z[2,1,6]  R632      7.0934516191482544e-01
    z[2,1,6]  R633      3.4553521871566772e-01
    z[2,1,6]  R634      1.8147693946957588e-02
    z[2,1,6]  R635      -2.3036184906959534e-01
    z[2,1,6]  R636      1.3844203203916550e-02
    z[1,6,0]  R11       -1
    z[1,6,0]  R56       1
    z[1,6,0]  R637      -1
    z[1,6,0]  R638      1
    z[1,6,0]  R651      6.9864052347838879e-03
    z[1,6,0]  R652      1.5159071981906891e-01
    z[1,6,0]  R653      -4.3520724773406982e-01
    z[1,6,0]  R654      -3.1087413430213928e-01
    z[1,6,0]  R655      -1.4469125866889954e-01
    z[1,6,0]  R656      -4.7290101647377014e-01
    z[1,6,0]  R657      -5.1100796461105347e-01
    z[1,6,0]  R658      1.3841454684734344e-01
    z[1,6,0]  R659      4.0108391642570496e-01
    z[1,6,0]  R660      1.1373510956764221e-01
    z[1,6,0]  R661      -2.6660263538360596e-01
    z[1,6,0]  R662      -2.3148806393146515e-01
    z[1,6,0]  R663      1.3688498735427856e-01
    z[1,6,0]  R664      7.5992047786712646e-02
    z[1,6,0]  R665      -1.2372570484876633e-01
    z[1,6,0]  R666      -0.128860741853714
    z[1,6,0]  R667      -2.0290514826774597e-01
    z[1,6,0]  R668      -5.3697037696838379e-01
    z[1,6,0]  R669      -1.1369368992745876e-02
    z[1,6,0]  R670      -5.5578452348709106e-01
    z[1,6,0]  R671      0.322528600692749
    z[1,6,0]  R672      1.2251260876655579e-01
    z[1,6,0]  R673      1.1202982813119888e-01
    z[1,6,0]  R674      -0.079043909907341
    z[1,6,0]  R675      1.2563639879226685e-01
    z[1,6,0]  R676      4.3147706985473633e-01
    z[1,6,0]  R677      2.5280410051345825e-01
    z[1,6,0]  R678      4.7436505556106567e-03
    z[1,6,0]  R679      2.2293041646480560e-01
    z[1,6,0]  R680      -0.0975753590464592
    z[1,6,0]  R681      -2.9630562663078308e-01
    z[1,6,0]  R682      -1.5747289359569550e-01
    z[1,6,0]  R683      3.2779577374458313e-01
    z[1,6,0]  R684      -1.8186327815055847e-01
    z[1,6,0]  R685      -2.7668768167495728e-01
    z[1,6,0]  R686      -8.4725864231586456e-02
    z[1,6,0]  R687      2.0847450196743011e-01
    z[1,6,0]  R688      2.8710582852363586e-01
    z[1,6,0]  R689      3.1074506044387817e-01
    z[1,6,0]  R690      3.2126989960670471e-01
    z[1,6,0]  R691      7.8719757497310638e-02
    z[1,6,0]  R692      -2.2840353846549988e-01
    z[1,6,0]  R693      1.3082465529441833e-01
    z[1,6,0]  R694      1.0154388844966888e-01
    z[1,6,0]  R695      1.2037665396928787e-01
    z[1,6,0]  R696      0.0824347734451294
    z[1,6,0]  R697      1.9508653879165649e-01
    z[1,6,0]  R698      2.8252487536519766e-03
    z[1,6,0]  R699      2.1544551849365234e-01
    z[1,6,0]  R700      4.5590769499540329e-02
    z[1,6,0]  R701      -0.0512348935008049
    z[1,6,0]  R702      -1.2200195342302322e-01
    z[1,6,0]  R703      -2.1726453304290771e-01
    z[1,6,0]  R704      -3.8343787193298340e-02
    z[1,6,0]  R705      1.0439215600490570e-01
    z[1,6,0]  R706      -7.3072470724582672e-02
    z[1,6,0]  R707      4.4909365475177765e-02
    z[1,6,0]  R708      -1.7582283914089203e-01
    z[1,6,0]  R709      -8.9845836162567139e-02
    z[1,6,0]  R710      3.3339053392410278e-02
    z[1,6,0]  R711      2.1200221776962280e-01
    z[1,6,0]  R712      -4.7757747769355774e-01
    z[1,6,0]  R713      -4.9179589748382568e-01
    z[1,6,0]  R714      2.4503467977046967e-01
    z[1,6,0]  R715      2.7563998103141785e-01
    z[1,6,0]  R716      7.6668816804885864e-01
    z[1,6,0]  R717      1.8436676263809204e-01
    z[1,6,0]  R718      5.9189713001251221e-01
    z[1,6,0]  R719      0.696549654006958
    z[1,6,0]  R720      6.2079501152038574e-01
    z[1,6,0]  R721      -1.2762364745140076e-01
    z[1,6,0]  R722      1.1209373921155930e-01
    z[1,6,0]  R723      3.8395129144191742e-02
    z[1,6,0]  R724      -7.3095254600048065e-02
    z[1,6,0]  R725      4.0898665785789490e-01
    z[1,6,0]  R726      2.8859421610832214e-01
    z[1,6,0]  R727      7.1428376436233521e-01
    z[1,6,0]  R728      4.9701672792434692e-01
    z[1,6,1]  R12       -1
    z[1,6,1]  R57       1
    z[1,6,1]  R639      -1
    z[1,6,1]  R640      1
    z[1,6,1]  R651      -2.1872717142105103e-01
    z[1,6,1]  R652      0.0711594671010971
    z[1,6,1]  R653      -4.4952562451362610e-01
    z[1,6,1]  R654      3.8730540871620178e-01
    z[1,6,1]  R655      5.3261183202266693e-02
    z[1,6,1]  R656      2.1477538347244263e-01
    z[1,6,1]  R657      -2.2816047072410583e-01
    z[1,6,1]  R658      3.4862717986106873e-01
    z[1,6,1]  R659      3.0483883619308472e-01
    z[1,6,1]  R660      -0.564039409160614
    z[1,6,1]  R661      -7.6693505048751831e-01
    z[1,6,1]  R662      -6.9930177927017212e-01
    z[1,6,1]  R663      -7.0424813032150269e-01
    z[1,6,1]  R664      -7.2674477100372314e-01
    z[1,6,1]  R665      -6.5514838695526123e-01
    z[1,6,1]  R666      -6.4812636375427246e-01
    z[1,6,1]  R667      -6.4683514833450317e-01
    z[1,6,1]  R668      -0.296928733587265
    z[1,6,1]  R669      -6.0688656568527222e-01
    z[1,6,1]  R670      -3.0988302826881409e-01
    z[1,6,1]  R671      8.4352749586105347e-01
    z[1,6,1]  R672      8.8191956281661987e-01
    z[1,6,1]  R673      9.0987449884414673e-01
    z[1,6,1]  R674      0.946040689945221
    z[1,6,1]  R675      7.7698063850402832e-01
    z[1,6,1]  R676      0.773720383644104
    z[1,6,1]  R677      8.2341051101684570e-01
    z[1,6,1]  R678      8.2002300024032593e-01
    z[1,6,1]  R679      7.7736425399780273e-01
    z[1,6,1]  R680      7.9500550031661987e-01
    z[1,6,1]  R681      -8.6459028720855713e-01
    z[1,6,1]  R682      -7.6453024148941040e-01
    z[1,6,1]  R683      -6.3956683874130249e-01
    z[1,6,1]  R684      -4.3450099229812622e-01
    z[1,6,1]  R685      -3.3394771814346313e-01
    z[1,6,1]  R686      -4.9412319064140320e-01
    z[1,6,1]  R687      8.4681063890457153e-01
    z[1,6,1]  R688      -5.7036370038986206e-01
    z[1,6,1]  R689      6.7065447568893433e-01
    z[1,6,1]  R690      5.8970105648040771e-01
    z[1,6,1]  R691      -0.714492917060852
    z[1,6,1]  R692      -0.766794741153717
    z[1,6,1]  R693      -5.3733867406845093e-01
    z[1,6,1]  R694      -5.0333178043365479e-01
    z[1,6,1]  R695      -5.2201277017593384e-01
    z[1,6,1]  R696      -5.6424331665039062e-01
    z[1,6,1]  R697      -4.1130667924880981e-01
    z[1,6,1]  R698      -4.8473531007766724e-01
    z[1,6,1]  R699      -3.9754891395568848e-01
    z[1,6,1]  R700      -4.9129721522331238e-01
    z[1,6,1]  R701      8.9774513244628906e-01
    z[1,6,1]  R702      8.4161835908889771e-01
    z[1,6,1]  R703      9.2137068510055542e-01
    z[1,6,1]  R704      9.0582871437072754e-01
    z[1,6,1]  R705      8.6860394477844238e-01
    z[1,6,1]  R706      8.5018402338027954e-01
    z[1,6,1]  R707      8.3546936511993408e-01
    z[1,6,1]  R708      0.864683210849762
    z[1,6,1]  R709      0.888593316078186
    z[1,6,1]  R710      0.855954110622406
    z[1,6,1]  R711      -6.3495159149169922e-01
    z[1,6,1]  R712      -6.0940831899642944e-01
    z[1,6,1]  R713      -6.0587811470031738e-01
    z[1,6,1]  R714      -6.5649712085723877e-01
    z[1,6,1]  R715      7.5388967990875244e-01
    z[1,6,1]  R716      -5.9504695236682892e-02
    z[1,6,1]  R717      6.7608863115310669e-01
    z[1,6,1]  R718      4.4767209887504578e-01
    z[1,6,1]  R719      5.8056843280792236e-01
    z[1,6,1]  R720      4.1099786758422852e-01
    z[1,6,1]  R721      -0.734729528427124
    z[1,6,1]  R722      -4.5898100733757019e-01
    z[1,6,1]  R723      9.5731109380722046e-01
    z[1,6,1]  R724      8.5355150699615479e-01
    z[1,6,1]  R725      7.0696151256561279e-01
    z[1,6,1]  R726      6.4644461870193481e-01
    z[1,6,1]  R727      5.7346242666244507e-01
    z[1,6,1]  R728      5.3231346607208252e-01
    z[1,6,2]  R13       -1
    z[1,6,2]  R58       1
    z[1,6,2]  R641      -1
    z[1,6,2]  R642      1
    z[1,6,2]  R651      7.5789797306060791e-01
    z[1,6,2]  R652      1.6683810949325562e-01
    z[1,6,2]  R653      4.7264236211776733e-01
    z[1,6,2]  R654      6.4159828424453735e-01
    z[1,6,2]  R655      7.1890002489089966e-01
    z[1,6,2]  R656      7.1373388171195984e-02
    z[1,6,2]  R657      0.0696830004453659
    z[1,6,2]  R658      6.6323804855346680e-01
    z[1,6,2]  R659      -1.9777624309062958e-01
    z[1,6,2]  R660      3.2200655341148376e-01
    z[1,6,2]  R661      -4.4560018181800842e-01
    z[1,6,2]  R662      -1.9278754293918610e-01
    z[1,6,2]  R663      -5.2620077133178711e-01
    z[1,6,2]  R664      -2.5206919759511948e-02
    z[1,6,2]  R665      -0.000703649187926203
    z[1,6,2]  R666      -1.8737143278121948e-01
    z[1,6,2]  R667      -1.7838209867477417e-02
    z[1,6,2]  R668      3.4494474530220032e-01
    z[1,6,2]  R669      5.3917411714792252e-02
    z[1,6,2]  R670      -1.9586580991744995e-01
    z[1,6,2]  R671      -7.7291406691074371e-02
    z[1,6,2]  R672      -1.2138006836175919e-01
    z[1,6,2]  R673      1.0292125493288040e-01
    z[1,6,2]  R674      -1.0032343864440918e-01
    z[1,6,2]  R675      -6.0871934890747070e-01
    z[1,6,2]  R676      4.1946947574615479e-01
    z[1,6,2]  R677      -1.2614218890666962e-01
    z[1,6,2]  R678      -8.2723297178745270e-02
    z[1,6,2]  R679      1.5332648158073425e-01
    z[1,6,2]  R680      1.0726466029882431e-01
    z[1,6,2]  R681      2.6444083452224731e-01
    z[1,6,2]  R682      4.4059496372938156e-02
    z[1,6,2]  R683      3.7639924883842468e-01
    z[1,6,2]  R684      5.7339799404144287e-01
    z[1,6,2]  R685      6.9558018445968628e-01
    z[1,6,2]  R686      1.8632547557353973e-01
    z[1,6,2]  R687      7.9054161906242371e-02
    z[1,6,2]  R688      -5.0351446866989136e-01
    z[1,6,2]  R689      3.1220319867134094e-01
    z[1,6,2]  R690      -1.2036138027906418e-01
    z[1,6,2]  R691      6.1780065298080444e-03
    z[1,6,2]  R692      8.0064445734024048e-02
    z[1,6,2]  R693      2.7129095792770386e-01
    z[1,6,2]  R694      5.1973092555999756e-01
    z[1,6,2]  R695      -3.9048162102699280e-01
    z[1,6,2]  R696      -3.5271200537681580e-01
    z[1,6,2]  R697      5.1109284162521362e-01
    z[1,6,2]  R698      -6.6421443223953247e-01
    z[1,6,2]  R699      -2.9589393734931946e-01
    z[1,6,2]  R700      3.9483693242073059e-01
    z[1,6,2]  R701      3.2043972611427307e-01
    z[1,6,2]  R702      3.9753416180610657e-01
    z[1,6,2]  R703      1.2810868024826050e-01
    z[1,6,2]  R704      -1.6346798837184906e-01
    z[1,6,2]  R705      5.8403205126523972e-02
    z[1,6,2]  R706      -3.0593705177307129e-01
    z[1,6,2]  R707      2.2055111825466156e-01
    z[1,6,2]  R708      -1.0309773683547974e-01
    z[1,6,2]  R709      -2.7790832519531250e-01
    z[1,6,2]  R710      3.0476909875869751e-01
    z[1,6,2]  R711      4.0077927405945957e-04
    z[1,6,2]  R712      4.0916711091995239e-02
    z[1,6,2]  R713      -2.0590171217918396e-01
    z[1,6,2]  R714      4.6840527653694153e-01
    z[1,6,2]  R715      -2.1393741667270660e-01
    z[1,6,2]  R716      -1.8920238316059113e-01
    z[1,6,2]  R717      1.3858684897422791e-01
    z[1,6,2]  R718      8.5976555943489075e-02
    z[1,6,2]  R719      1.5089520812034607e-01
    z[1,6,2]  R720      1.0470622032880783e-01
    z[1,6,2]  R721      -3.7842476367950439e-01
    z[1,6,2]  R722      -2.8487798571586609e-01
    z[1,6,2]  R723      -2.5255424901843071e-02
    z[1,6,2]  R724      -2.4526433646678925e-01
    z[1,6,2]  R725      2.4254019558429718e-01
    z[1,6,2]  R726      -2.1440829336643219e-01
    z[1,6,2]  R727      2.0959307253360748e-01
    z[1,6,2]  R728      2.2036673128604889e-01
    z[1,6,3]  R14       -1
    z[1,6,3]  R59       1
    z[1,6,3]  R643      -1
    z[1,6,3]  R644      1
    z[1,6,3]  R651      -4.5455229282379150e-01
    z[1,6,3]  R652      -5.6906771659851074e-01
    z[1,6,3]  R653      -3.2695877552032471e-01
    z[1,6,3]  R654      -2.5724312663078308e-01
    z[1,6,3]  R655      -2.0146018266677856e-01
    z[1,6,3]  R656      -4.9880608916282654e-01
    z[1,6,3]  R657      -6.2742674350738525e-01
    z[1,6,3]  R658      -0.527021050453186
    z[1,6,3]  R659      -4.4537079334259033e-01
    z[1,6,3]  R660      -3.8205111026763916e-01
    z[1,6,3]  R661      1.2880785763263702e-01
    z[1,6,3]  R662      5.7528215646743774e-01
    z[1,6,3]  R663      3.2055887579917908e-01
    z[1,6,3]  R664      3.7288346886634827e-01
    z[1,6,3]  R665      3.8196507096290588e-01
    z[1,6,3]  R666      1.0356844961643219e-01
    z[1,6,3]  R667      0.500627875328064
    z[1,6,3]  R668      3.7581780552864075e-01
    z[1,6,3]  R669      5.4066902399063110e-01
    z[1,6,3]  R670      3.5347390174865723e-01
    z[1,6,3]  R671      -1.6295136511325836e-01
    z[1,6,3]  R672      3.6049813032150269e-02
    z[1,6,3]  R673      1.4913326501846313e-01
    z[1,6,3]  R674      2.0327532291412354e-01
    z[1,6,3]  R675      -1.2226550839841366e-02
    z[1,6,3]  R676      2.1289777010679245e-02
    z[1,6,3]  R677      -7.7048338949680328e-02
    z[1,6,3]  R678      2.5974312424659729e-01
    z[1,6,3]  R679      2.9298624396324158e-01
    z[1,6,3]  R680      4.4194224476814270e-01
    z[1,6,3]  R681      3.9107095450162888e-02
    z[1,6,3]  R682      1.5430690348148346e-01
    z[1,6,3]  R683      -2.2678783535957336e-01
    z[1,6,3]  R684      2.3870329558849335e-01
    z[1,6,3]  R685      3.9376735687255859e-01
    z[1,6,3]  R686      1.3581918179988861e-01
    z[1,6,3]  R687      1.6972009837627411e-01
    z[1,6,3]  R688      -4.7885257005691528e-01
    z[1,6,3]  R689      -5.0333078950643539e-02
    z[1,6,3]  R690      -3.7363627552986145e-01
    z[1,6,3]  R691      3.3091518282890320e-01
    z[1,6,3]  R692      -2.2827278077602386e-01
    z[1,6,3]  R693      -2.8170111775398254e-01
    z[1,6,3]  R694      -5.0733107328414917e-01
    z[1,6,3]  R695      6.6642665863037109e-01
    z[1,6,3]  R696      -5.4064452648162842e-01
    z[1,6,3]  R697      3.9117965102195740e-01
    z[1,6,3]  R698      -0.279350608587265
    z[1,6,3]  R699      -3.5979685187339783e-01
    z[1,6,3]  R700      7.2067701816558838e-01
    z[1,6,3]  R701      2.5874990224838257e-01
    z[1,6,3]  R702      2.4203525483608246e-01
    z[1,6,3]  R703      -1.8975268304347992e-01
    z[1,6,3]  R704      -1.5461277961730957e-01
    z[1,6,3]  R705      -3.5554841160774231e-02
    z[1,6,3]  R706      -1.0980086028575897e-01
    z[1,6,3]  R707      8.6332093924283981e-03
    z[1,6,3]  R708      4.7490164637565613e-02
    z[1,6,3]  R709      2.8536167740821838e-01
    z[1,6,3]  R710      2.3685184121131897e-01
    z[1,6,3]  R711      2.6239043474197388e-01
    z[1,6,3]  R712      -2.1712154150009155e-01
    z[1,6,3]  R713      1.7849530279636383e-01
    z[1,6,3]  R714      3.1665435433387756e-01
    z[1,6,3]  R715      -2.5579133629798889e-01
    z[1,6,3]  R716      1.0500301420688629e-01
    z[1,6,3]  R717      4.6437028795480728e-02
    z[1,6,3]  R718      -4.8745346069335938e-01
    z[1,6,3]  R719      -2.7795964479446411e-01
    z[1,6,3]  R720      -5.9017390012741089e-01
    z[1,6,3]  R721      -1.5690918266773224e-01
    z[1,6,3]  R722      3.5372716188430786e-01
    z[1,6,3]  R723      -7.4609339237213135e-02
    z[1,6,3]  R724      -3.0010592937469482e-01
    z[1,6,3]  R725      -1.9031988084316254e-01
    z[1,6,3]  R726      -5.6362503767013550e-01
    z[1,6,3]  R727      -0.260911226272583
    z[1,6,3]  R728      -5.5483013391494751e-01
    z[1,6,4]  R15       -1
    z[1,6,4]  R60       1
    z[1,6,4]  R645      -1
    z[1,6,4]  R646      1
    z[1,6,4]  R651      3.3072546124458313e-01
    z[1,6,4]  R652      -3.4881818294525146e-01
    z[1,6,4]  R653      -8.8620446622371674e-02
    z[1,6,4]  R654      1.4680328965187073e-01
    z[1,6,4]  R655      -4.4236642122268677e-01
    z[1,6,4]  R656      3.0451798439025879e-01
    z[1,6,4]  R657      5.1750338077545166e-01
    z[1,6,4]  R658      -1.9711346924304962e-01
    z[1,6,4]  R659      6.8620347976684570e-01
    z[1,6,4]  R660      -6.2515747547149658e-01
    z[1,6,4]  R661      1.4192202687263489e-01
    z[1,6,4]  R662      -2.8104245662689209e-02
    z[1,6,4]  R663      1.6148015856742859e-01
    z[1,6,4]  R664      5.4073834419250488e-01
    z[1,6,4]  R665      2.0981565117835999e-01
    z[1,6,4]  R666      5.7631433010101318e-01
    z[1,6,4]  R667      5.0944042205810547e-01
    z[1,6,4]  R668      1.2366279214620590e-01
    z[1,6,4]  R669      2.4005118012428284e-01
    z[1,6,4]  R670      3.2895141839981079e-01
    z[1,6,4]  R671      -9.9299162626266479e-02
    z[1,6,4]  R672      -1.8979972600936890e-01
    z[1,6,4]  R673      -1.4772635698318481e-01
    z[1,6,4]  R674      -1.7982470989227295e-01
    z[1,6,4]  R675      -2.7890071272850037e-02
    z[1,6,4]  R676      -3.4348908811807632e-02
    z[1,6,4]  R677      1.8405571579933167e-01
    z[1,6,4]  R678      -2.1979516744613647e-01
    z[1,6,4]  R679      2.4768868088722229e-01
    z[1,6,4]  R680      2.5145342946052551e-01
    z[1,6,4]  R681      2.6255629956722260e-02
    z[1,6,4]  R682      4.3436667323112488e-01
    z[1,6,4]  R683      3.3053183555603027e-01
    z[1,6,4]  R684      -1.3813333213329315e-01
    z[1,6,4]  R685      -9.9543467164039612e-02
    z[1,6,4]  R686      -3.5761246085166931e-01
    z[1,6,4]  R687      2.8522366285324097e-01
    z[1,6,4]  R688      1.7460164427757263e-01
    z[1,6,4]  R689      5.2828025817871094e-01
    z[1,6,4]  R690      -0.600789487361908
    z[1,6,4]  R691      3.1219854950904846e-01
    z[1,6,4]  R692      -5.9438440948724747e-02
    z[1,6,4]  R693      -7.0988601446151733e-01
    z[1,6,4]  R694      -2.6318114995956421e-01
    z[1,6,4]  R695      -1.6919200122356415e-01
    z[1,6,4]  R696      -3.7650740146636963e-01
    z[1,6,4]  R697      -2.1941165626049042e-01
    z[1,6,4]  R698      -2.4052104353904724e-01
    z[1,6,4]  R699      4.3770986795425415e-01
    z[1,6,4]  R700      1.5775993466377258e-01
    z[1,6,4]  R701      -1.2614172697067261e-01
    z[1,6,4]  R702      2.4360871315002441e-01
    z[1,6,4]  R703      7.9051433131098747e-03
    z[1,6,4]  R704      1.9794492423534393e-01
    z[1,6,4]  R705      3.7752953171730042e-01
    z[1,6,4]  R706      -3.6943656206130981e-01
    z[1,6,4]  R707      -2.7956220507621765e-01
    z[1,6,4]  R708      -2.5055420398712158e-01
    z[1,6,4]  R709      -4.9570269882678986e-02
    z[1,6,4]  R710      2.6393425464630127e-01
    z[1,6,4]  R711      6.4228612184524536e-01
    z[1,6,4]  R712      5.7015073299407959e-01
    z[1,6,4]  R713      2.4942095577716827e-01
    z[1,6,4]  R714      2.1850416064262390e-01
    z[1,6,4]  R715      1.6406890749931335e-01
    z[1,6,4]  R716      -4.2165097594261169e-01
    z[1,6,4]  R717      -4.4154065847396851e-01
    z[1,6,4]  R718      7.8501164913177490e-02
    z[1,6,4]  R719      -1.6236285865306854e-01
    z[1,6,4]  R720      -1.1570196598768234e-02
    z[1,6,4]  R721      -3.2835006713867188e-01
    z[1,6,4]  R722      5.7537955045700073e-01
    z[1,6,4]  R723      -1.9492319226264954e-01
    z[1,6,4]  R724      -1.7925573885440826e-01
    z[1,6,4]  R725      -1.6380502283573151e-01
    z[1,6,4]  R726      -0.260452002286911
    z[1,6,4]  R727      6.8050853908061981e-02
    z[1,6,4]  R728      -9.8680742084980011e-02
    z[1,6,5]  R16       -1
    z[1,6,5]  R61       1
    z[1,6,5]  R647      -1
    z[1,6,5]  R648      1
    z[1,6,5]  R651      -2.3038573563098907e-01
    z[1,6,5]  R652      -6.5410476922988892e-01
    z[1,6,5]  R653      -4.6232935786247253e-01
    z[1,6,5]  R654      -4.6229395270347595e-01
    z[1,6,5]  R655      -4.3729913234710693e-01
    z[1,6,5]  R656      -4.0501350164413452e-01
    z[1,6,5]  R657      -1.4188054203987122e-01
    z[1,6,5]  R658      0.218091681599617
    z[1,6,5]  R659      -1.7230643332004547e-01
    z[1,6,5]  R660      1.6776913404464722e-01
    z[1,6,5]  R661      -3.0619594454765320e-01
    z[1,6,5]  R662      -2.8887179493904114e-01
    z[1,6,5]  R663      -5.6227338500320911e-03
    z[1,6,5]  R664      5.9849033132195473e-03
    z[1,6,5]  R665      -1.1563264578580856e-01
    z[1,6,5]  R666      2.4274872243404388e-01
    z[1,6,5]  R667      -9.8129369318485260e-02
    z[1,6,5]  R668      4.8437666893005371e-01
    z[1,6,5]  R669      3.0878007411956787e-01
    z[1,6,5]  R670      1.9394531846046448e-01
    z[1,6,5]  R671      -3.2390362024307251e-01
    z[1,6,5]  R672      3.6178052425384521e-01
    z[1,6,5]  R673      -3.2388812303543091e-01
    z[1,6,5]  R674      1.9500320777297020e-02
    z[1,6,5]  R675      2.6371777057647705e-02
    z[1,6,5]  R676      1.2408478558063507e-01
    z[1,6,5]  R677      4.4811934232711792e-01
    z[1,6,5]  R678      -1.1433947831392288e-01
    z[1,6,5]  R679      1.9704459607601166e-01
    z[1,6,5]  R680      4.3167270720005035e-02
    z[1,6,5]  R681      6.1495050787925720e-02
    z[1,6,5]  R682      2.4743005633354187e-01
    z[1,6,5]  R683      -3.8357576727867126e-01
    z[1,6,5]  R684      -6.0128504037857056e-01
    z[1,6,5]  R685      -1.4546290040016174e-01
    z[1,6,5]  R686      -2.5385549664497375e-01
    z[1,6,5]  R687      6.0403876006603241e-02
    z[1,6,5]  R688      2.8038170933723450e-01
    z[1,6,5]  R689      1.4665973186492920e-01
    z[1,6,5]  R690      1.8386904895305634e-01
    z[1,6,5]  R691      2.9710179567337036e-01
    z[1,6,5]  R692      -3.4951677918434143e-01
    z[1,6,5]  R693      1.6739878058433533e-01
    z[1,6,5]  R694      3.6380210518836975e-01
    z[1,6,5]  R695      2.5592729449272156e-01
    z[1,6,5]  R696      -1.4988232869654894e-03
    z[1,6,5]  R697      5.1170504093170166e-01
    z[1,6,5]  R698      -3.2616552710533142e-01
    z[1,6,5]  R699      -3.5955232381820679e-01
    z[1,6,5]  R700      -1.5198934078216553e-01
    z[1,6,5]  R701      4.1818149387836456e-02
    z[1,6,5]  R702      2.6045233011245728e-02
    z[1,6,5]  R703      -6.7827187478542328e-02
    z[1,6,5]  R704      1.7519944906234741e-01
    z[1,6,5]  R705      -0.0880071297287941
    z[1,6,5]  R706      -3.4801412373781204e-02
    z[1,6,5]  R707      -9.7975112497806549e-02
    z[1,6,5]  R708      2.3809593915939331e-01
    z[1,6,5]  R709      3.3612795174121857e-02
    z[1,6,5]  R710      -5.7271972298622131e-02
    z[1,6,5]  R711      9.1047652065753937e-02
    z[1,6,5]  R712      -4.4316451996564865e-02
    z[1,6,5]  R713      3.4391567111015320e-01
    z[1,6,5]  R714      1.9005237519741058e-01
    z[1,6,5]  R715      -4.4324430823326111e-01
    z[1,6,5]  R716      -3.4918987751007080e-01
    z[1,6,5]  R717      5.1142746210098267e-01
    z[1,6,5]  R718      4.1684547066688538e-01
    z[1,6,5]  R719      1.1127652972936630e-01
    z[1,6,5]  R720      -5.0437271595001221e-02
    z[1,6,5]  R721      2.2210228443145752e-01
    z[1,6,5]  R722      -4.8537328839302063e-01
    z[1,6,5]  R723      1.0913676023483276e-01
    z[1,6,5]  R724      -4.3426580727100372e-02
    z[1,6,5]  R725      3.6192888021469116e-01
    z[1,6,5]  R726      -2.4011881649494171e-01
    z[1,6,5]  R727      -2.0933395624160767e-01
    z[1,6,5]  R728      2.4340030550956726e-01
    z[1,6,6]  R17       -1
    z[1,6,6]  R62       1
    z[1,6,6]  R649      -1
    z[1,6,6]  R650      1
    z[1,6,6]  R651      9.2874079942703247e-02
    z[1,6,6]  R652      -2.6600062847137451e-01
    z[1,6,6]  R653      -2.3796321451663971e-01
    z[1,6,6]  R654      -2.0065556466579437e-01
    z[1,6,6]  R655      1.7862161993980408e-01
    z[1,6,6]  R656      4.6858021616935730e-01
    z[1,6,6]  R657      -1.8807673826813698e-02
    z[1,6,6]  R658      -2.3504647612571716e-01
    z[1,6,6]  R659      -9.0385437011718750e-02
    z[1,6,6]  R660      0.0174432210624218
    z[1,6,6]  R661      1.0809668898582458e-01
    z[1,6,6]  R662      7.0972159504890442e-02
    z[1,6,6]  R663      -2.8203630447387695e-01
    z[1,6,6]  R664      1.8427161872386932e-01
    z[1,6,6]  R665      5.9344846010208130e-01
    z[1,6,6]  R666      -3.5556644201278687e-01
    z[1,6,6]  R667      -1.4257748425006866e-01
    z[1,6,6]  R668      -3.3668524026870728e-01
    z[1,6,6]  R669      -4.2820525169372559e-01
    z[1,6,6]  R670      -5.3473824262619019e-01
    z[1,6,6]  R671      -1.9270603358745575e-01
    z[1,6,6]  R672      -1.5577773749828339e-01
    z[1,6,6]  R673      -4.2021432891488075e-03
    z[1,6,6]  R674      -1.2106308341026306e-01
    z[1,6,6]  R675      9.1403447091579437e-02
    z[1,6,6]  R676      0.148995041847229
    z[1,6,6]  R677      3.9363037794828415e-02
    z[1,6,6]  R678      4.3800309300422668e-01
    z[1,6,6]  R679      -3.6943295598030090e-01
    z[1,6,6]  R680      0.294167160987854
    z[1,6,6]  R681      -2.9792159795761108e-01
    z[1,6,6]  R682      3.3918708562850952e-01
    z[1,6,6]  R683      1.8442739546298981e-01
    z[1,6,6]  R684      1.0837730765342712e-01
    z[1,6,6]  R685      3.7678909301757812e-01
    z[1,6,6]  R686      7.0934516191482544e-01
    z[1,6,6]  R687      3.4553521871566772e-01
    z[1,6,6]  R688      1.8147693946957588e-02
    z[1,6,6]  R689      -2.3036184906959534e-01
    z[1,6,6]  R690      1.3844203203916550e-02
    z[1,6,6]  R691      4.3361580371856689e-01
    z[1,6,6]  R692      -4.1909894347190857e-01
    z[1,6,6]  R693      -9.6110187470912933e-02
    z[1,6,6]  R694      -8.4997788071632385e-02
    z[1,6,6]  R695      1.4928846061229706e-01
    z[1,6,6]  R696      3.4113296866416931e-01
    z[1,6,6]  R697      2.6181507110595703e-01
    z[1,6,6]  R698      2.8560775518417358e-01
    z[1,6,6]  R699      5.0760549306869507e-01
    z[1,6,6]  R700      -1.8244978785514832e-01
    z[1,6,6]  R701      -0.064302958548069
    z[1,6,6]  R702      1.2488375417888165e-02
    z[1,6,6]  R703      2.1631282567977905e-01
    z[1,6,6]  R704      2.3979188501834869e-01
    z[1,6,6]  R705      -2.8227767348289490e-01
    z[1,6,6]  R706      1.6881720721721649e-01
    z[1,6,6]  R707      -4.0435448288917542e-01
    z[1,6,6]  R708      -2.9842558503150940e-01
    z[1,6,6]  R709      2.0019564032554626e-01
    z[1,6,6]  R710      -2.1049199998378754e-01
    z[1,6,6]  R711      2.4944262206554413e-01
    z[1,6,6]  R712      1.5712873637676239e-01
    z[1,6,6]  R713      3.6919301748275757e-01
    z[1,6,6]  R714      -3.2470297813415527e-01
    z[1,6,6]  R715      1.4522561430931091e-01
    z[1,6,6]  R716      -2.4920284748077393e-01
    z[1,6,6]  R717      1.7616525292396545e-01
    z[1,6,6]  R718      -1.5595553815364838e-01
    z[1,6,6]  R719      1.9744274020195007e-01
    z[1,6,6]  R720      2.8939232230186462e-01
    z[1,6,6]  R721      3.4484165906906128e-01
    z[1,6,6]  R722      -6.2001351267099380e-02
    z[1,6,6]  R723      1.6115553677082062e-01
    z[1,6,6]  R724      -2.8612977266311646e-01
    z[1,6,6]  R725      -2.8295481204986572e-01
    z[1,6,6]  R726      -9.8420321941375732e-02
    z[1,6,6]  R727      -2.1999720484018326e-02
    z[1,6,6]  R728      2.1032616496086121e-01
    z[6,1,0]  R11       1
    z[6,1,0]  R56       -1
    z[6,1,0]  R729      -1
    z[6,1,0]  R730      1
    z[6,1,0]  R743      7.8719757497310638e-02
    z[6,1,0]  R744      -2.2840353846549988e-01
    z[6,1,0]  R745      1.3082465529441833e-01
    z[6,1,0]  R746      1.0154388844966888e-01
    z[6,1,0]  R747      1.2037665396928787e-01
    z[6,1,0]  R748      0.0824347734451294
    z[6,1,0]  R749      1.9508653879165649e-01
    z[6,1,0]  R750      2.8252487536519766e-03
    z[6,1,0]  R751      2.1544551849365234e-01
    z[6,1,0]  R752      4.5590769499540329e-02
    z[6,1,0]  R753      -0.0512348935008049
    z[6,1,0]  R754      -1.2200195342302322e-01
    z[6,1,0]  R755      -2.1726453304290771e-01
    z[6,1,0]  R756      -3.8343787193298340e-02
    z[6,1,0]  R757      1.0439215600490570e-01
    z[6,1,0]  R758      -7.3072470724582672e-02
    z[6,1,0]  R759      4.4909365475177765e-02
    z[6,1,0]  R760      -1.7582283914089203e-01
    z[6,1,0]  R761      -8.9845836162567139e-02
    z[6,1,0]  R762      3.3339053392410278e-02
    z[6,1,0]  R763      2.1200221776962280e-01
    z[6,1,0]  R764      -4.7757747769355774e-01
    z[6,1,0]  R765      -4.9179589748382568e-01
    z[6,1,0]  R766      2.4503467977046967e-01
    z[6,1,0]  R767      2.7563998103141785e-01
    z[6,1,0]  R768      7.6668816804885864e-01
    z[6,1,0]  R769      1.8436676263809204e-01
    z[6,1,0]  R770      5.9189713001251221e-01
    z[6,1,0]  R771      0.696549654006958
    z[6,1,0]  R772      6.2079501152038574e-01
    z[6,1,0]  R773      -1.2762364745140076e-01
    z[6,1,0]  R774      1.1209373921155930e-01
    z[6,1,0]  R775      3.8395129144191742e-02
    z[6,1,0]  R776      -7.3095254600048065e-02
    z[6,1,0]  R777      4.0898665785789490e-01
    z[6,1,0]  R778      2.8859421610832214e-01
    z[6,1,0]  R779      7.1428376436233521e-01
    z[6,1,0]  R780      4.9701672792434692e-01
    z[6,1,0]  R781      6.9864052347838879e-03
    z[6,1,0]  R782      1.5159071981906891e-01
    z[6,1,0]  R783      -4.3520724773406982e-01
    z[6,1,0]  R784      -3.1087413430213928e-01
    z[6,1,0]  R785      -1.4469125866889954e-01
    z[6,1,0]  R786      -4.7290101647377014e-01
    z[6,1,0]  R787      -5.1100796461105347e-01
    z[6,1,0]  R788      1.3841454684734344e-01
    z[6,1,0]  R789      4.0108391642570496e-01
    z[6,1,0]  R790      1.1373510956764221e-01
    z[6,1,0]  R791      -2.6660263538360596e-01
    z[6,1,0]  R792      -2.3148806393146515e-01
    z[6,1,0]  R793      1.3688498735427856e-01
    z[6,1,0]  R794      7.5992047786712646e-02
    z[6,1,0]  R795      -1.2372570484876633e-01
    z[6,1,0]  R796      -0.128860741853714
    z[6,1,0]  R797      -2.0290514826774597e-01
    z[6,1,0]  R798      -5.3697037696838379e-01
    z[6,1,0]  R799      -1.1369368992745876e-02
    z[6,1,0]  R800      -5.5578452348709106e-01
    z[6,1,0]  R801      0.322528600692749
    z[6,1,0]  R802      1.2251260876655579e-01
    z[6,1,0]  R803      1.1202982813119888e-01
    z[6,1,0]  R804      -0.079043909907341
    z[6,1,0]  R805      1.2563639879226685e-01
    z[6,1,0]  R806      4.3147706985473633e-01
    z[6,1,0]  R807      2.5280410051345825e-01
    z[6,1,0]  R808      4.7436505556106567e-03
    z[6,1,0]  R809      2.2293041646480560e-01
    z[6,1,0]  R810      -0.0975753590464592
    z[6,1,0]  R811      -2.9630562663078308e-01
    z[6,1,0]  R812      -1.5747289359569550e-01
    z[6,1,0]  R813      3.2779577374458313e-01
    z[6,1,0]  R814      -1.8186327815055847e-01
    z[6,1,0]  R815      -2.7668768167495728e-01
    z[6,1,0]  R816      -8.4725864231586456e-02
    z[6,1,0]  R817      2.0847450196743011e-01
    z[6,1,0]  R818      2.8710582852363586e-01
    z[6,1,0]  R819      3.1074506044387817e-01
    z[6,1,0]  R820      3.2126989960670471e-01
    z[6,1,1]  R12       1
    z[6,1,1]  R57       -1
    z[6,1,1]  R731      -1
    z[6,1,1]  R732      1
    z[6,1,1]  R743      -0.714492917060852
    z[6,1,1]  R744      -0.766794741153717
    z[6,1,1]  R745      -5.3733867406845093e-01
    z[6,1,1]  R746      -5.0333178043365479e-01
    z[6,1,1]  R747      -5.2201277017593384e-01
    z[6,1,1]  R748      -5.6424331665039062e-01
    z[6,1,1]  R749      -4.1130667924880981e-01
    z[6,1,1]  R750      -4.8473531007766724e-01
    z[6,1,1]  R751      -3.9754891395568848e-01
    z[6,1,1]  R752      -4.9129721522331238e-01
    z[6,1,1]  R753      8.9774513244628906e-01
    z[6,1,1]  R754      8.4161835908889771e-01
    z[6,1,1]  R755      9.2137068510055542e-01
    z[6,1,1]  R756      9.0582871437072754e-01
    z[6,1,1]  R757      8.6860394477844238e-01
    z[6,1,1]  R758      8.5018402338027954e-01
    z[6,1,1]  R759      8.3546936511993408e-01
    z[6,1,1]  R760      0.864683210849762
    z[6,1,1]  R761      0.888593316078186
    z[6,1,1]  R762      0.855954110622406
    z[6,1,1]  R763      -6.3495159149169922e-01
    z[6,1,1]  R764      -6.0940831899642944e-01
    z[6,1,1]  R765      -6.0587811470031738e-01
    z[6,1,1]  R766      -6.5649712085723877e-01
    z[6,1,1]  R767      7.5388967990875244e-01
    z[6,1,1]  R768      -5.9504695236682892e-02
    z[6,1,1]  R769      6.7608863115310669e-01
    z[6,1,1]  R770      4.4767209887504578e-01
    z[6,1,1]  R771      5.8056843280792236e-01
    z[6,1,1]  R772      4.1099786758422852e-01
    z[6,1,1]  R773      -0.734729528427124
    z[6,1,1]  R774      -4.5898100733757019e-01
    z[6,1,1]  R775      9.5731109380722046e-01
    z[6,1,1]  R776      8.5355150699615479e-01
    z[6,1,1]  R777      7.0696151256561279e-01
    z[6,1,1]  R778      6.4644461870193481e-01
    z[6,1,1]  R779      5.7346242666244507e-01
    z[6,1,1]  R780      5.3231346607208252e-01
    z[6,1,1]  R781      -2.1872717142105103e-01
    z[6,1,1]  R782      0.0711594671010971
    z[6,1,1]  R783      -4.4952562451362610e-01
    z[6,1,1]  R784      3.8730540871620178e-01
    z[6,1,1]  R785      5.3261183202266693e-02
    z[6,1,1]  R786      2.1477538347244263e-01
    z[6,1,1]  R787      -2.2816047072410583e-01
    z[6,1,1]  R788      3.4862717986106873e-01
    z[6,1,1]  R789      3.0483883619308472e-01
    z[6,1,1]  R790      -0.564039409160614
    z[6,1,1]  R791      -7.6693505048751831e-01
    z[6,1,1]  R792      -6.9930177927017212e-01
    z[6,1,1]  R793      -7.0424813032150269e-01
    z[6,1,1]  R794      -7.2674477100372314e-01
    z[6,1,1]  R795      -6.5514838695526123e-01
    z[6,1,1]  R796      -6.4812636375427246e-01
    z[6,1,1]  R797      -6.4683514833450317e-01
    z[6,1,1]  R798      -0.296928733587265
    z[6,1,1]  R799      -6.0688656568527222e-01
    z[6,1,1]  R800      -3.0988302826881409e-01
    z[6,1,1]  R801      8.4352749586105347e-01
    z[6,1,1]  R802      8.8191956281661987e-01
    z[6,1,1]  R803      9.0987449884414673e-01
    z[6,1,1]  R804      0.946040689945221
    z[6,1,1]  R805      7.7698063850402832e-01
    z[6,1,1]  R806      0.773720383644104
    z[6,1,1]  R807      8.2341051101684570e-01
    z[6,1,1]  R808      8.2002300024032593e-01
    z[6,1,1]  R809      7.7736425399780273e-01
    z[6,1,1]  R810      7.9500550031661987e-01
    z[6,1,1]  R811      -8.6459028720855713e-01
    z[6,1,1]  R812      -7.6453024148941040e-01
    z[6,1,1]  R813      -6.3956683874130249e-01
    z[6,1,1]  R814      -4.3450099229812622e-01
    z[6,1,1]  R815      -3.3394771814346313e-01
    z[6,1,1]  R816      -4.9412319064140320e-01
    z[6,1,1]  R817      8.4681063890457153e-01
    z[6,1,1]  R818      -5.7036370038986206e-01
    z[6,1,1]  R819      6.7065447568893433e-01
    z[6,1,1]  R820      5.8970105648040771e-01
    z[6,1,2]  R13       1
    z[6,1,2]  R58       -1
    z[6,1,2]  R733      -1
    z[6,1,2]  R734      1
    z[6,1,2]  R743      6.1780065298080444e-03
    z[6,1,2]  R744      8.0064445734024048e-02
    z[6,1,2]  R745      2.7129095792770386e-01
    z[6,1,2]  R746      5.1973092555999756e-01
    z[6,1,2]  R747      -3.9048162102699280e-01
    z[6,1,2]  R748      -3.5271200537681580e-01
    z[6,1,2]  R749      5.1109284162521362e-01
    z[6,1,2]  R750      -6.6421443223953247e-01
    z[6,1,2]  R751      -2.9589393734931946e-01
    z[6,1,2]  R752      3.9483693242073059e-01
    z[6,1,2]  R753      3.2043972611427307e-01
    z[6,1,2]  R754      3.9753416180610657e-01
    z[6,1,2]  R755      1.2810868024826050e-01
    z[6,1,2]  R756      -1.6346798837184906e-01
    z[6,1,2]  R757      5.8403205126523972e-02
    z[6,1,2]  R758      -3.0593705177307129e-01
    z[6,1,2]  R759      2.2055111825466156e-01
    z[6,1,2]  R760      -1.0309773683547974e-01
    z[6,1,2]  R761      -2.7790832519531250e-01
    z[6,1,2]  R762      3.0476909875869751e-01
    z[6,1,2]  R763      4.0077927405945957e-04
    z[6,1,2]  R764      4.0916711091995239e-02
    z[6,1,2]  R765      -2.0590171217918396e-01
    z[6,1,2]  R766      4.6840527653694153e-01
    z[6,1,2]  R767      -2.1393741667270660e-01
    z[6,1,2]  R768      -1.8920238316059113e-01
    z[6,1,2]  R769      1.3858684897422791e-01
    z[6,1,2]  R770      8.5976555943489075e-02
    z[6,1,2]  R771      1.5089520812034607e-01
    z[6,1,2]  R772      1.0470622032880783e-01
    z[6,1,2]  R773      -3.7842476367950439e-01
    z[6,1,2]  R774      -2.8487798571586609e-01
    z[6,1,2]  R775      -2.5255424901843071e-02
    z[6,1,2]  R776      -2.4526433646678925e-01
    z[6,1,2]  R777      2.4254019558429718e-01
    z[6,1,2]  R778      -2.1440829336643219e-01
    z[6,1,2]  R779      2.0959307253360748e-01
    z[6,1,2]  R780      2.2036673128604889e-01
    z[6,1,2]  R781      7.5789797306060791e-01
    z[6,1,2]  R782      1.6683810949325562e-01
    z[6,1,2]  R783      4.7264236211776733e-01
    z[6,1,2]  R784      6.4159828424453735e-01
    z[6,1,2]  R785      7.1890002489089966e-01
    z[6,1,2]  R786      7.1373388171195984e-02
    z[6,1,2]  R787      0.0696830004453659
    z[6,1,2]  R788      6.6323804855346680e-01
    z[6,1,2]  R789      -1.9777624309062958e-01
    z[6,1,2]  R790      3.2200655341148376e-01
    z[6,1,2]  R791      -4.4560018181800842e-01
    z[6,1,2]  R792      -1.9278754293918610e-01
    z[6,1,2]  R793      -5.2620077133178711e-01
    z[6,1,2]  R794      -2.5206919759511948e-02
    z[6,1,2]  R795      -0.000703649187926203
    z[6,1,2]  R796      -1.8737143278121948e-01
    z[6,1,2]  R797      -1.7838209867477417e-02
    z[6,1,2]  R798      3.4494474530220032e-01
    z[6,1,2]  R799      5.3917411714792252e-02
    z[6,1,2]  R800      -1.9586580991744995e-01
    z[6,1,2]  R801      -7.7291406691074371e-02
    z[6,1,2]  R802      -1.2138006836175919e-01
    z[6,1,2]  R803      1.0292125493288040e-01
    z[6,1,2]  R804      -1.0032343864440918e-01
    z[6,1,2]  R805      -6.0871934890747070e-01
    z[6,1,2]  R806      4.1946947574615479e-01
    z[6,1,2]  R807      -1.2614218890666962e-01
    z[6,1,2]  R808      -8.2723297178745270e-02
    z[6,1,2]  R809      1.5332648158073425e-01
    z[6,1,2]  R810      1.0726466029882431e-01
    z[6,1,2]  R811      2.6444083452224731e-01
    z[6,1,2]  R812      4.4059496372938156e-02
    z[6,1,2]  R813      3.7639924883842468e-01
    z[6,1,2]  R814      5.7339799404144287e-01
    z[6,1,2]  R815      6.9558018445968628e-01
    z[6,1,2]  R816      1.8632547557353973e-01
    z[6,1,2]  R817      7.9054161906242371e-02
    z[6,1,2]  R818      -5.0351446866989136e-01
    z[6,1,2]  R819      3.1220319867134094e-01
    z[6,1,2]  R820      -1.2036138027906418e-01
    z[6,1,3]  R14       1
    z[6,1,3]  R59       -1
    z[6,1,3]  R735      -1
    z[6,1,3]  R736      1
    z[6,1,3]  R743      3.3091518282890320e-01
    z[6,1,3]  R744      -2.2827278077602386e-01
    z[6,1,3]  R745      -2.8170111775398254e-01
    z[6,1,3]  R746      -5.0733107328414917e-01
    z[6,1,3]  R747      6.6642665863037109e-01
    z[6,1,3]  R748      -5.4064452648162842e-01
    z[6,1,3]  R749      3.9117965102195740e-01
    z[6,1,3]  R750      -0.279350608587265
    z[6,1,3]  R751      -3.5979685187339783e-01
    z[6,1,3]  R752      7.2067701816558838e-01
    z[6,1,3]  R753      2.5874990224838257e-01
    z[6,1,3]  R754      2.4203525483608246e-01
    z[6,1,3]  R755      -1.8975268304347992e-01
    z[6,1,3]  R756      -1.5461277961730957e-01
    z[6,1,3]  R757      -3.5554841160774231e-02
    z[6,1,3]  R758      -1.0980086028575897e-01
    z[6,1,3]  R759      8.6332093924283981e-03
    z[6,1,3]  R760      4.7490164637565613e-02
    z[6,1,3]  R761      2.8536167740821838e-01
    z[6,1,3]  R762      2.3685184121131897e-01
    z[6,1,3]  R763      2.6239043474197388e-01
    z[6,1,3]  R764      -2.1712154150009155e-01
    z[6,1,3]  R765      1.7849530279636383e-01
    z[6,1,3]  R766      3.1665435433387756e-01
    z[6,1,3]  R767      -2.5579133629798889e-01
    z[6,1,3]  R768      1.0500301420688629e-01
    z[6,1,3]  R769      4.6437028795480728e-02
    z[6,1,3]  R770      -4.8745346069335938e-01
    z[6,1,3]  R771      -2.7795964479446411e-01
    z[6,1,3]  R772      -5.9017390012741089e-01
    z[6,1,3]  R773      -1.5690918266773224e-01
    z[6,1,3]  R774      3.5372716188430786e-01
    z[6,1,3]  R775      -7.4609339237213135e-02
    z[6,1,3]  R776      -3.0010592937469482e-01
    z[6,1,3]  R777      -1.9031988084316254e-01
    z[6,1,3]  R778      -5.6362503767013550e-01
    z[6,1,3]  R779      -0.260911226272583
    z[6,1,3]  R780      -5.5483013391494751e-01
    z[6,1,3]  R781      -4.5455229282379150e-01
    z[6,1,3]  R782      -5.6906771659851074e-01
    z[6,1,3]  R783      -3.2695877552032471e-01
    z[6,1,3]  R784      -2.5724312663078308e-01
    z[6,1,3]  R785      -2.0146018266677856e-01
    z[6,1,3]  R786      -4.9880608916282654e-01
    z[6,1,3]  R787      -6.2742674350738525e-01
    z[6,1,3]  R788      -0.527021050453186
    z[6,1,3]  R789      -4.4537079334259033e-01
    z[6,1,3]  R790      -3.8205111026763916e-01
    z[6,1,3]  R791      1.2880785763263702e-01
    z[6,1,3]  R792      5.7528215646743774e-01
    z[6,1,3]  R793      3.2055887579917908e-01
    z[6,1,3]  R794      3.7288346886634827e-01
    z[6,1,3]  R795      3.8196507096290588e-01
    z[6,1,3]  R796      1.0356844961643219e-01
    z[6,1,3]  R797      0.500627875328064
    z[6,1,3]  R798      3.7581780552864075e-01
    z[6,1,3]  R799      5.4066902399063110e-01
    z[6,1,3]  R800      3.5347390174865723e-01
    z[6,1,3]  R801      -1.6295136511325836e-01
    z[6,1,3]  R802      3.6049813032150269e-02
    z[6,1,3]  R803      1.4913326501846313e-01
    z[6,1,3]  R804      2.0327532291412354e-01
    z[6,1,3]  R805      -1.2226550839841366e-02
    z[6,1,3]  R806      2.1289777010679245e-02
    z[6,1,3]  R807      -7.7048338949680328e-02
    z[6,1,3]  R808      2.5974312424659729e-01
    z[6,1,3]  R809      2.9298624396324158e-01
    z[6,1,3]  R810      4.4194224476814270e-01
    z[6,1,3]  R811      3.9107095450162888e-02
    z[6,1,3]  R812      1.5430690348148346e-01
    z[6,1,3]  R813      -2.2678783535957336e-01
    z[6,1,3]  R814      2.3870329558849335e-01
    z[6,1,3]  R815      3.9376735687255859e-01
    z[6,1,3]  R816      1.3581918179988861e-01
    z[6,1,3]  R817      1.6972009837627411e-01
    z[6,1,3]  R818      -4.7885257005691528e-01
    z[6,1,3]  R819      -5.0333078950643539e-02
    z[6,1,3]  R820      -3.7363627552986145e-01
    z[6,1,4]  R15       1
    z[6,1,4]  R60       -1
    z[6,1,4]  R737      -1
    z[6,1,4]  R738      1
    z[6,1,4]  R743      3.1219854950904846e-01
    z[6,1,4]  R744      -5.9438440948724747e-02
    z[6,1,4]  R745      -7.0988601446151733e-01
    z[6,1,4]  R746      -2.6318114995956421e-01
    z[6,1,4]  R747      -1.6919200122356415e-01
    z[6,1,4]  R748      -3.7650740146636963e-01
    z[6,1,4]  R749      -2.1941165626049042e-01
    z[6,1,4]  R750      -2.4052104353904724e-01
    z[6,1,4]  R751      4.3770986795425415e-01
    z[6,1,4]  R752      1.5775993466377258e-01
    z[6,1,4]  R753      -1.2614172697067261e-01
    z[6,1,4]  R754      2.4360871315002441e-01
    z[6,1,4]  R755      7.9051433131098747e-03
    z[6,1,4]  R756      1.9794492423534393e-01
    z[6,1,4]  R757      3.7752953171730042e-01
    z[6,1,4]  R758      -3.6943656206130981e-01
    z[6,1,4]  R759      -2.7956220507621765e-01
    z[6,1,4]  R760      -2.5055420398712158e-01
    z[6,1,4]  R761      -4.9570269882678986e-02
    z[6,1,4]  R762      2.6393425464630127e-01
    z[6,1,4]  R763      6.4228612184524536e-01
    z[6,1,4]  R764      5.7015073299407959e-01
    z[6,1,4]  R765      2.4942095577716827e-01
    z[6,1,4]  R766      2.1850416064262390e-01
    z[6,1,4]  R767      1.6406890749931335e-01
    z[6,1,4]  R768      -4.2165097594261169e-01
    z[6,1,4]  R769      -4.4154065847396851e-01
    z[6,1,4]  R770      7.8501164913177490e-02
    z[6,1,4]  R771      -1.6236285865306854e-01
    z[6,1,4]  R772      -1.1570196598768234e-02
    z[6,1,4]  R773      -3.2835006713867188e-01
    z[6,1,4]  R774      5.7537955045700073e-01
    z[6,1,4]  R775      -1.9492319226264954e-01
    z[6,1,4]  R776      -1.7925573885440826e-01
    z[6,1,4]  R777      -1.6380502283573151e-01
    z[6,1,4]  R778      -0.260452002286911
    z[6,1,4]  R779      6.8050853908061981e-02
    z[6,1,4]  R780      -9.8680742084980011e-02
    z[6,1,4]  R781      3.3072546124458313e-01
    z[6,1,4]  R782      -3.4881818294525146e-01
    z[6,1,4]  R783      -8.8620446622371674e-02
    z[6,1,4]  R784      1.4680328965187073e-01
    z[6,1,4]  R785      -4.4236642122268677e-01
    z[6,1,4]  R786      3.0451798439025879e-01
    z[6,1,4]  R787      5.1750338077545166e-01
    z[6,1,4]  R788      -1.9711346924304962e-01
    z[6,1,4]  R789      6.8620347976684570e-01
    z[6,1,4]  R790      -6.2515747547149658e-01
    z[6,1,4]  R791      1.4192202687263489e-01
    z[6,1,4]  R792      -2.8104245662689209e-02
    z[6,1,4]  R793      1.6148015856742859e-01
    z[6,1,4]  R794      5.4073834419250488e-01
    z[6,1,4]  R795      2.0981565117835999e-01
    z[6,1,4]  R796      5.7631433010101318e-01
    z[6,1,4]  R797      5.0944042205810547e-01
    z[6,1,4]  R798      1.2366279214620590e-01
    z[6,1,4]  R799      2.4005118012428284e-01
    z[6,1,4]  R800      3.2895141839981079e-01
    z[6,1,4]  R801      -9.9299162626266479e-02
    z[6,1,4]  R802      -1.8979972600936890e-01
    z[6,1,4]  R803      -1.4772635698318481e-01
    z[6,1,4]  R804      -1.7982470989227295e-01
    z[6,1,4]  R805      -2.7890071272850037e-02
    z[6,1,4]  R806      -3.4348908811807632e-02
    z[6,1,4]  R807      1.8405571579933167e-01
    z[6,1,4]  R808      -2.1979516744613647e-01
    z[6,1,4]  R809      2.4768868088722229e-01
    z[6,1,4]  R810      2.5145342946052551e-01
    z[6,1,4]  R811      2.6255629956722260e-02
    z[6,1,4]  R812      4.3436667323112488e-01
    z[6,1,4]  R813      3.3053183555603027e-01
    z[6,1,4]  R814      -1.3813333213329315e-01
    z[6,1,4]  R815      -9.9543467164039612e-02
    z[6,1,4]  R816      -3.5761246085166931e-01
    z[6,1,4]  R817      2.8522366285324097e-01
    z[6,1,4]  R818      1.7460164427757263e-01
    z[6,1,4]  R819      5.2828025817871094e-01
    z[6,1,4]  R820      -0.600789487361908
    z[6,1,5]  R16       1
    z[6,1,5]  R61       -1
    z[6,1,5]  R739      -1
    z[6,1,5]  R740      1
    z[6,1,5]  R743      2.9710179567337036e-01
    z[6,1,5]  R744      -3.4951677918434143e-01
    z[6,1,5]  R745      1.6739878058433533e-01
    z[6,1,5]  R746      3.6380210518836975e-01
    z[6,1,5]  R747      2.5592729449272156e-01
    z[6,1,5]  R748      -1.4988232869654894e-03
    z[6,1,5]  R749      5.1170504093170166e-01
    z[6,1,5]  R750      -3.2616552710533142e-01
    z[6,1,5]  R751      -3.5955232381820679e-01
    z[6,1,5]  R752      -1.5198934078216553e-01
    z[6,1,5]  R753      4.1818149387836456e-02
    z[6,1,5]  R754      2.6045233011245728e-02
    z[6,1,5]  R755      -6.7827187478542328e-02
    z[6,1,5]  R756      1.7519944906234741e-01
    z[6,1,5]  R757      -0.0880071297287941
    z[6,1,5]  R758      -3.4801412373781204e-02
    z[6,1,5]  R759      -9.7975112497806549e-02
    z[6,1,5]  R760      2.3809593915939331e-01
    z[6,1,5]  R761      3.3612795174121857e-02
    z[6,1,5]  R762      -5.7271972298622131e-02
    z[6,1,5]  R763      9.1047652065753937e-02
    z[6,1,5]  R764      -4.4316451996564865e-02
    z[6,1,5]  R765      3.4391567111015320e-01
    z[6,1,5]  R766      1.9005237519741058e-01
    z[6,1,5]  R767      -4.4324430823326111e-01
    z[6,1,5]  R768      -3.4918987751007080e-01
    z[6,1,5]  R769      5.1142746210098267e-01
    z[6,1,5]  R770      4.1684547066688538e-01
    z[6,1,5]  R771      1.1127652972936630e-01
    z[6,1,5]  R772      -5.0437271595001221e-02
    z[6,1,5]  R773      2.2210228443145752e-01
    z[6,1,5]  R774      -4.8537328839302063e-01
    z[6,1,5]  R775      1.0913676023483276e-01
    z[6,1,5]  R776      -4.3426580727100372e-02
    z[6,1,5]  R777      3.6192888021469116e-01
    z[6,1,5]  R778      -2.4011881649494171e-01
    z[6,1,5]  R779      -2.0933395624160767e-01
    z[6,1,5]  R780      2.4340030550956726e-01
    z[6,1,5]  R781      -2.3038573563098907e-01
    z[6,1,5]  R782      -6.5410476922988892e-01
    z[6,1,5]  R783      -4.6232935786247253e-01
    z[6,1,5]  R784      -4.6229395270347595e-01
    z[6,1,5]  R785      -4.3729913234710693e-01
    z[6,1,5]  R786      -4.0501350164413452e-01
    z[6,1,5]  R787      -1.4188054203987122e-01
    z[6,1,5]  R788      0.218091681599617
    z[6,1,5]  R789      -1.7230643332004547e-01
    z[6,1,5]  R790      1.6776913404464722e-01
    z[6,1,5]  R791      -3.0619594454765320e-01
    z[6,1,5]  R792      -2.8887179493904114e-01
    z[6,1,5]  R793      -5.6227338500320911e-03
    z[6,1,5]  R794      5.9849033132195473e-03
    z[6,1,5]  R795      -1.1563264578580856e-01
    z[6,1,5]  R796      2.4274872243404388e-01
    z[6,1,5]  R797      -9.8129369318485260e-02
    z[6,1,5]  R798      4.8437666893005371e-01
    z[6,1,5]  R799      3.0878007411956787e-01
    z[6,1,5]  R800      1.9394531846046448e-01
    z[6,1,5]  R801      -3.2390362024307251e-01
    z[6,1,5]  R802      3.6178052425384521e-01
    z[6,1,5]  R803      -3.2388812303543091e-01
    z[6,1,5]  R804      1.9500320777297020e-02
    z[6,1,5]  R805      2.6371777057647705e-02
    z[6,1,5]  R806      1.2408478558063507e-01
    z[6,1,5]  R807      4.4811934232711792e-01
    z[6,1,5]  R808      -1.1433947831392288e-01
    z[6,1,5]  R809      1.9704459607601166e-01
    z[6,1,5]  R810      4.3167270720005035e-02
    z[6,1,5]  R811      6.1495050787925720e-02
    z[6,1,5]  R812      2.4743005633354187e-01
    z[6,1,5]  R813      -3.8357576727867126e-01
    z[6,1,5]  R814      -6.0128504037857056e-01
    z[6,1,5]  R815      -1.4546290040016174e-01
    z[6,1,5]  R816      -2.5385549664497375e-01
    z[6,1,5]  R817      6.0403876006603241e-02
    z[6,1,5]  R818      2.8038170933723450e-01
    z[6,1,5]  R819      1.4665973186492920e-01
    z[6,1,5]  R820      1.8386904895305634e-01
    z[6,1,6]  R17       1
    z[6,1,6]  R62       -1
    z[6,1,6]  R741      -1
    z[6,1,6]  R742      1
    z[6,1,6]  R743      4.3361580371856689e-01
    z[6,1,6]  R744      -4.1909894347190857e-01
    z[6,1,6]  R745      -9.6110187470912933e-02
    z[6,1,6]  R746      -8.4997788071632385e-02
    z[6,1,6]  R747      1.4928846061229706e-01
    z[6,1,6]  R748      3.4113296866416931e-01
    z[6,1,6]  R749      2.6181507110595703e-01
    z[6,1,6]  R750      2.8560775518417358e-01
    z[6,1,6]  R751      5.0760549306869507e-01
    z[6,1,6]  R752      -1.8244978785514832e-01
    z[6,1,6]  R753      -0.064302958548069
    z[6,1,6]  R754      1.2488375417888165e-02
    z[6,1,6]  R755      2.1631282567977905e-01
    z[6,1,6]  R756      2.3979188501834869e-01
    z[6,1,6]  R757      -2.8227767348289490e-01
    z[6,1,6]  R758      1.6881720721721649e-01
    z[6,1,6]  R759      -4.0435448288917542e-01
    z[6,1,6]  R760      -2.9842558503150940e-01
    z[6,1,6]  R761      2.0019564032554626e-01
    z[6,1,6]  R762      -2.1049199998378754e-01
    z[6,1,6]  R763      2.4944262206554413e-01
    z[6,1,6]  R764      1.5712873637676239e-01
    z[6,1,6]  R765      3.6919301748275757e-01
    z[6,1,6]  R766      -3.2470297813415527e-01
    z[6,1,6]  R767      1.4522561430931091e-01
    z[6,1,6]  R768      -2.4920284748077393e-01
    z[6,1,6]  R769      1.7616525292396545e-01
    z[6,1,6]  R770      -1.5595553815364838e-01
    z[6,1,6]  R771      1.9744274020195007e-01
    z[6,1,6]  R772      2.8939232230186462e-01
    z[6,1,6]  R773      3.4484165906906128e-01
    z[6,1,6]  R774      -6.2001351267099380e-02
    z[6,1,6]  R775      1.6115553677082062e-01
    z[6,1,6]  R776      -2.8612977266311646e-01
    z[6,1,6]  R777      -2.8295481204986572e-01
    z[6,1,6]  R778      -9.8420321941375732e-02
    z[6,1,6]  R779      -2.1999720484018326e-02
    z[6,1,6]  R780      2.1032616496086121e-01
    z[6,1,6]  R781      9.2874079942703247e-02
    z[6,1,6]  R782      -2.6600062847137451e-01
    z[6,1,6]  R783      -2.3796321451663971e-01
    z[6,1,6]  R784      -2.0065556466579437e-01
    z[6,1,6]  R785      1.7862161993980408e-01
    z[6,1,6]  R786      4.6858021616935730e-01
    z[6,1,6]  R787      -1.8807673826813698e-02
    z[6,1,6]  R788      -2.3504647612571716e-01
    z[6,1,6]  R789      -9.0385437011718750e-02
    z[6,1,6]  R790      0.0174432210624218
    z[6,1,6]  R791      1.0809668898582458e-01
    z[6,1,6]  R792      7.0972159504890442e-02
    z[6,1,6]  R793      -2.8203630447387695e-01
    z[6,1,6]  R794      1.8427161872386932e-01
    z[6,1,6]  R795      5.9344846010208130e-01
    z[6,1,6]  R796      -3.5556644201278687e-01
    z[6,1,6]  R797      -1.4257748425006866e-01
    z[6,1,6]  R798      -3.3668524026870728e-01
    z[6,1,6]  R799      -4.2820525169372559e-01
    z[6,1,6]  R800      -5.3473824262619019e-01
    z[6,1,6]  R801      -1.9270603358745575e-01
    z[6,1,6]  R802      -1.5577773749828339e-01
    z[6,1,6]  R803      -4.2021432891488075e-03
    z[6,1,6]  R804      -1.2106308341026306e-01
    z[6,1,6]  R805      9.1403447091579437e-02
    z[6,1,6]  R806      0.148995041847229
    z[6,1,6]  R807      3.9363037794828415e-02
    z[6,1,6]  R808      4.3800309300422668e-01
    z[6,1,6]  R809      -3.6943295598030090e-01
    z[6,1,6]  R810      0.294167160987854
    z[6,1,6]  R811      -2.9792159795761108e-01
    z[6,1,6]  R812      3.3918708562850952e-01
    z[6,1,6]  R813      1.8442739546298981e-01
    z[6,1,6]  R814      1.0837730765342712e-01
    z[6,1,6]  R815      3.7678909301757812e-01
    z[6,1,6]  R816      7.0934516191482544e-01
    z[6,1,6]  R817      3.4553521871566772e-01
    z[6,1,6]  R818      1.8147693946957588e-02
    z[6,1,6]  R819      -2.3036184906959534e-01
    z[6,1,6]  R820      1.3844203203916550e-02
    z[2,3,0]  R20       -1
    z[2,3,0]  R29       1
    z[2,3,0]  R821      -1
    z[2,3,0]  R822      1
    z[2,3,0]  R835      -5.1831060647964478e-01
    z[2,3,0]  R836      3.4386706352233887e-01
    z[2,3,0]  R837      -1.6055357456207275e-01
    z[2,3,0]  R838      -3.1579840183258057e-01
    z[2,3,0]  R839      -5.1425721496343613e-02
    z[2,3,0]  R840      3.0115556716918945e-01
    z[2,3,0]  R841      1.2531785666942596e-01
    z[2,3,0]  R842      4.2257830500602722e-02
    z[2,3,0]  R843      3.7992015480995178e-01
    z[2,3,0]  R844      5.2165144681930542e-01
    z[2,3,0]  R845      4.7604960203170776e-01
    z[2,3,0]  R846      3.3365431427955627e-01
    z[2,3,0]  R847      2.1986183524131775e-01
    z[2,3,0]  R848      5.3151583671569824e-01
    z[2,3,0]  R849      7.1910239756107330e-02
    z[2,3,0]  R850      -5.5746231228113174e-02
    z[2,3,0]  R851      1.4154396951198578e-01
    z[2,3,0]  R852      -1.1921548098325729e-01
    z[2,3,0]  R853      -1.4973938465118408e-02
    z[2,3,0]  R854      -4.2232591658830643e-02
    z[2,3,0]  R855      1.4951783418655396e-01
    z[2,3,0]  R856      -2.3622293770313263e-01
    z[2,3,0]  R857      1.8643289804458618e-01
    z[2,3,0]  R858      2.2332927212119102e-02
    z[2,3,0]  R859      3.0346214771270752e-01
    z[2,3,0]  R860      -2.4205325543880463e-01
    z[2,3,0]  R861      -6.5310436487197876e-01
    z[2,3,0]  R862      -7.3012202978134155e-01
    z[2,3,0]  R863      -8.1839954853057861e-01
    z[2,3,0]  R864      -7.1401822566986084e-01
    z[2,3,0]  R865      0.153198704123497
    z[2,3,0]  R866      -6.0081088542938232e-01
    z[2,3,0]  R867      7.1688795089721680e-01
    z[2,3,0]  R868      2.3340252041816711e-01
    z[2,3,0]  R869      4.9905306100845337e-01
    z[2,3,0]  R870      2.5812390446662903e-01
    z[2,3,0]  R871      2.7214249968528748e-01
    z[2,3,0]  R872      0.531776487827301
    z[2,3,0]  R873      5.4017448425292969e-01
    z[2,3,0]  R874      3.8133546710014343e-01
    z[2,3,0]  R875      5.2057379484176636e-01
    z[2,3,0]  R876      5.9864956140518188e-01
    z[2,3,0]  R877      0.365446001291275
    z[2,3,0]  R878      5.5695241689682007e-01
    z[2,3,0]  R879      2.8284192085266113e-01
    z[2,3,0]  R880      1.7235065996646881e-01
    z[2,3,0]  R881      -4.2859369516372681e-01
    z[2,3,0]  R882      5.8471912145614624e-01
    z[2,3,0]  R883      0.627866804599762
    z[2,3,0]  R884      6.2033843994140625e-01
    z[2,3,0]  R885      5.3637397289276123e-01
    z[2,3,0]  R886      5.6048560142517090e-01
    z[2,3,0]  R887      5.8017802238464355e-01
    z[2,3,0]  R888      6.1862134933471680e-01
    z[2,3,0]  R889      3.5152587294578552e-01
    z[2,3,0]  R890      6.4129203557968140e-01
    z[2,3,0]  R891      4.6803352236747742e-01
    z[2,3,0]  R892      5.8159804344177246e-01
    z[2,3,0]  R893      4.9010065197944641e-01
    z[2,3,0]  R894      2.0241326093673706e-01
    z[2,3,0]  R895      -0.188896045088768
    z[2,3,0]  R896      -9.8122563213109970e-03
    z[2,3,0]  R897      0.0203165952116251
    z[2,3,0]  R898      3.1710234284400940e-01
    z[2,3,1]  R21       -1
    z[2,3,1]  R30       1
    z[2,3,1]  R823      -1
    z[2,3,1]  R824      1
    z[2,3,1]  R835      4.4127404689788818e-01
    z[2,3,1]  R836      5.5638778209686279e-01
    z[2,3,1]  R837      -5.3512406349182129e-01
    z[2,3,1]  R838      -0.449727326631546
    z[2,3,1]  R839      -5.2998477220535278e-01
    z[2,3,1]  R840      -2.3548798263072968e-01
    z[2,3,1]  R841      -6.8755798041820526e-02
    z[2,3,1]  R842      -3.0945608019828796e-01
    z[2,3,1]  R843      -3.0317991971969604e-01
    z[2,3,1]  R844      -4.0468877553939819e-01
    z[2,3,1]  R845      7.5076855719089508e-02
    z[2,3,1]  R846      -4.0912812948226929e-01
    z[2,3,1]  R847      -3.5781404376029968e-01
    z[2,3,1]  R848      -1.2643989920616150e-01
    z[2,3,1]  R849      6.2416708469390869e-01
    z[2,3,1]  R850      6.1151504516601562e-01
    z[2,3,1]  R851      6.1467844247817993e-01
    z[2,3,1]  R852      6.0014915466308594e-01
    z[2,3,1]  R853      6.0448038578033447e-01
    z[2,3,1]  R854      5.8867859840393066e-01
    z[2,3,1]  R855      6.3629478216171265e-01
    z[2,3,1]  R856      0.555555522441864
    z[2,3,1]  R857      -4.4533852487802505e-02
    z[2,3,1]  R858      -2.2310809791088104e-01
    z[2,3,1]  R859      -1.3412791490554810e-01
    z[2,3,1]  R860      -0.0782335102558136
    z[2,3,1]  R861      5.8178991079330444e-01
    z[2,3,1]  R862      4.7476023435592651e-01
    z[2,3,1]  R863      -2.7540719509124756e-01
    z[2,3,1]  R864      -2.4982862174510956e-01
    z[2,3,1]  R865      6.0271453857421875e-01
    z[2,3,1]  R866      1.2983238697052002e-01
    z[2,3,1]  R867      -7.5340755283832550e-02
    z[2,3,1]  R868      4.8387479782104492e-01
    z[2,3,1]  R869      3.0697804689407349e-01
    z[2,3,1]  R870      5.3865957260131836e-01
    z[2,3,1]  R871      -5.1415318250656128e-01
    z[2,3,1]  R872      -7.2146528959274292e-01
    z[2,3,1]  R873      -6.8546158075332642e-01
    z[2,3,1]  R874      -7.5014483928680420e-01
    z[2,3,1]  R875      -6.3469791412353516e-01
    z[2,3,1]  R876      -5.6650543212890625e-01
    z[2,3,1]  R877      -8.0281686782836914e-01
    z[2,3,1]  R878      -6.2422585487365723e-01
    z[2,3,1]  R879      -6.1908406019210815e-01
    z[2,3,1]  R880      -2.0034465193748474e-01
    z[2,3,1]  R881      -3.3841341733932495e-01
    z[2,3,1]  R882      -7.0923173427581787e-01
    z[2,3,1]  R883      -6.5544891357421875e-01
    z[2,3,1]  R884      -6.6866677999496460e-01
    z[2,3,1]  R885      -7.2253215312957764e-01
    z[2,3,1]  R886      -0.651892900466919
    z[2,3,1]  R887      -6.3286352157592773e-01
    z[2,3,1]  R888      -5.8157765865325928e-01
    z[2,3,1]  R889      -0.886976957321167
    z[2,3,1]  R890      -5.1137030124664307e-01
    z[2,3,1]  R891      -7.9289269447326660e-01
    z[2,3,1]  R892      -6.3307863473892212e-01
    z[2,3,1]  R893      -2.2521585226058960e-01
    z[2,3,1]  R894      -4.0167921781539917e-01
    z[2,3,1]  R895      -2.7031752467155457e-01
    z[2,3,1]  R896      -5.2839994430541992e-01
    z[2,3,1]  R897      -5.1613306999206543e-01
    z[2,3,1]  R898      6.9041180610656738e-01
    z[2,3,2]  R22       -1
    z[2,3,2]  R31       1
    z[2,3,2]  R825      -1
    z[2,3,2]  R826      1
    z[2,3,2]  R835      3.1402048468589783e-01
    z[2,3,2]  R836      1.5289390087127686e-01
    z[2,3,2]  R837      8.9429974555969238e-02
    z[2,3,2]  R838      -3.0457723140716553e-01
    z[2,3,2]  R839      2.4313895404338837e-01
    z[2,3,2]  R840      3.5214146971702576e-01
    z[2,3,2]  R841      0.198577880859375
    z[2,3,2]  R842      -2.6125302910804749e-01
    z[2,3,2]  R843      7.1913385391235352e-01
    z[2,3,2]  R844      -1.0600367933511734e-01
    z[2,3,2]  R845      -1.3923546671867371e-01
    z[2,3,2]  R846      7.0893031358718872e-01
    z[2,3,2]  R847      -4.0393617749214172e-01
    z[2,3,2]  R848      -2.6510453224182129e-01
    z[2,3,2]  R849      -2.4793711304664612e-01
    z[2,3,2]  R850      -1.9527323544025421e-01
    z[2,3,2]  R851      -2.3801873624324799e-01
    z[2,3,2]  R852      -4.2611122131347656e-01
    z[2,3,2]  R853      -4.0763118863105774e-01
    z[2,3,2]  R854      -2.6661166548728943e-01
    z[2,3,2]  R855      -3.6592435836791992e-01
    z[2,3,2]  R856      -1.8245643377304077e-01
    z[2,3,2]  R857      -8.1135082244873047e-01
    z[2,3,2]  R858      -0.775295615196228
    z[2,3,2]  R859      -7.3469394445419312e-01
    z[2,3,2]  R860      -7.4209457635879517e-01
    z[2,3,2]  R861      -2.0417949557304382e-01
    z[2,3,2]  R862      -3.4446725249290466e-01
    z[2,3,2]  R863      -3.3685794472694397e-01
    z[2,3,2]  R864      -1.9678533077239990e-02
    z[2,3,2]  R865      0.06800577044487
    z[2,3,2]  R866      1.6934520006179810e-01
    z[2,3,2]  R867      3.1749528646469116e-01
    z[2,3,2]  R868      -1.9265535473823547e-01
    z[2,3,2]  R869      -0.0784771665930748
    z[2,3,2]  R870      -4.8448212444782257e-02
    z[2,3,2]  R871      2.8500853106379509e-02
    z[2,3,2]  R872      -1.5785014629364014e-01
    z[2,3,2]  R873      -1.7656792700290680e-01
    z[2,3,2]  R874      0.0232391320168972
    z[2,3,2]  R875      -1.0151895135641098e-01
    z[2,3,2]  R876      -2.4404411017894745e-01
    z[2,3,2]  R877      -2.2070296108722687e-01
    z[2,3,2]  R878      -4.8843196034431458e-01
    z[2,3,2]  R879      -2.0805369317531586e-01
    z[2,3,2]  R880      4.2685028165578842e-02
    z[2,3,2]  R881      -1.9409951567649841e-01
    z[2,3,2]  R882      -2.8021706268191338e-02
    z[2,3,2]  R883      5.2486073225736618e-02
    z[2,3,2]  R884      -7.9806774854660034e-02
    z[2,3,2]  R885      -3.1840169429779053e-01
    z[2,3,2]  R886      3.2039615511894226e-01
    z[2,3,2]  R887      1.9184727966785431e-01
    z[2,3,2]  R888      -3.2531636953353882e-01
    z[2,3,2]  R889      1.9793011248111725e-01
    z[2,3,2]  R890      1.3564078509807587e-01
    z[2,3,2]  R891      2.3570168018341064e-01
    z[2,3,2]  R892      1.5581017732620239e-01
    z[2,3,2]  R893      1.4989016950130463e-01
    z[2,3,2]  R894      -8.5404375568032265e-03
    z[2,3,2]  R895      -1.2486571818590164e-01
    z[2,3,2]  R896      -1.6090908646583557e-01
    z[2,3,2]  R897      -5.5259462445974350e-02
    z[2,3,2]  R898      2.4271681904792786e-01
    z[2,3,3]  R23       -1
    z[2,3,3]  R32       1
    z[2,3,3]  R827      -1
    z[2,3,3]  R828      1
    z[2,3,3]  R835      -5.5583792924880981e-01
    z[2,3,3]  R836      -0.0460672564804554
    z[2,3,3]  R837      -2.7368506789207458e-01
    z[2,3,3]  R838      -2.0565721392631531e-01
    z[2,3,3]  R839      -8.2955203950405121e-02
    z[2,3,3]  R840      -2.9273739457130432e-01
    z[2,3,3]  R841      9.0377324819564819e-01
    z[2,3,3]  R842      8.3545857667922974e-01
    z[2,3,3]  R843      4.4935768842697144e-01
    z[2,3,3]  R844      2.7733248472213745e-01
    z[2,3,3]  R845      -1.2220747023820877e-01
    z[2,3,3]  R846      -5.6970175355672836e-02
    z[2,3,3]  R847      -3.3664211630821228e-01
    z[2,3,3]  R848      7.3629550635814667e-02
    z[2,3,3]  R849      0.557930588722229
    z[2,3,3]  R850      0.551186740398407
    z[2,3,3]  R851      3.8179707527160645e-01
    z[2,3,3]  R852      3.4594398736953735e-01
    z[2,3,3]  R853      3.0154392123222351e-01
    z[2,3,3]  R854      3.5131609439849854e-01
    z[2,3,3]  R855      3.1221404671669006e-01
    z[2,3,3]  R856      4.9124187231063843e-01
    z[2,3,3]  R857      1.1037503182888031e-01
    z[2,3,3]  R858      -7.1076013147830963e-02
    z[2,3,3]  R859      1.7651884257793427e-01
    z[2,3,3]  R860      1.7760708928108215e-02
    z[2,3,3]  R861      -2.9196754097938538e-01
    z[2,3,3]  R862      -7.9768812283873558e-03
    z[2,3,3]  R863      6.8975519388914108e-03
    z[2,3,3]  R864      -0.17877297103405
    z[2,3,3]  R865      6.6534203290939331e-01
    z[2,3,3]  R866      0.0673535093665123
    z[2,3,3]  R867      3.7388241291046143e-01
    z[2,3,3]  R868      4.7781109809875488e-01
    z[2,3,3]  R869      -1.6770860552787781e-01
    z[2,3,3]  R870      -2.5062268972396851e-01
    z[2,3,3]  R871      -7.1692460775375366e-01
    z[2,3,3]  R872      1.8741454184055328e-01
    z[2,3,3]  R873      -2.8977379202842712e-01
    z[2,3,3]  R874      -8.4911346435546875e-02
    z[2,3,3]  R875      -3.3067530393600464e-01
    z[2,3,3]  R876      -1.3843837380409241e-01
    z[2,3,3]  R877      -2.8861805796623230e-02
    z[2,3,3]  R878      -2.5015437975525856e-02
    z[2,3,3]  R879      5.0772500038146973e-01
    z[2,3,3]  R880      6.3338494300842285e-01
    z[2,3,3]  R881      -7.0545035600662231e-01
    z[2,3,3]  R882      -1.1263841390609741e-01
    z[2,3,3]  R883      -1.8007743358612061e-01
    z[2,3,3]  R884      2.5668722391128540e-01
    z[2,3,3]  R885      -1.8313533067703247e-01
    z[2,3,3]  R886      -2.5241750478744507e-01
    z[2,3,3]  R887      -2.4784231185913086e-01
    z[2,3,3]  R888      3.5779255628585815e-01
    z[2,3,3]  R889      0.0634353756904602
    z[2,3,3]  R890      -2.4863202869892120e-01
    z[2,3,3]  R891      -4.5533329248428345e-02
    z[2,3,3]  R892      -6.9684617221355438e-02
    z[2,3,3]  R893      0.764371395111084
    z[2,3,3]  R894      0.745017409324646
    z[2,3,3]  R895      -4.9989512562751770e-01
    z[2,3,3]  R896      7.1240496635437012e-01
    z[2,3,3]  R897      6.2345904111862183e-01
    z[2,3,3]  R898      -2.2300015389919281e-01
    z[2,3,4]  R24       -1
    z[2,3,4]  R33       1
    z[2,3,4]  R829      -1
    z[2,3,4]  R830      1
    z[2,3,4]  R835      -2.0685656368732452e-01
    z[2,3,4]  R836      0.564935028553009
    z[2,3,4]  R837      6.2383162975311279e-01
    z[2,3,4]  R838      3.1513506174087524e-01
    z[2,3,4]  R839      -1.8688105046749115e-01
    z[2,3,4]  R840      -4.5573839545249939e-01
    z[2,3,4]  R841      -3.6735687404870987e-02
    z[2,3,4]  R842      -1.6383193433284760e-01
    z[2,3,4]  R843      2.4072615429759026e-02
    z[2,3,4]  R844      -3.0005145072937012e-01
    z[2,3,4]  R845      -6.2298113107681274e-01
    z[2,3,4]  R846      -4.2758038640022278e-01
    z[2,3,4]  R847      -5.1841910928487778e-02
    z[2,3,4]  R848      3.7198910117149353e-01
    z[2,3,4]  R849      -2.3699709773063660e-01
    z[2,3,4]  R850      -2.8858028352260590e-02
    z[2,3,4]  R851      -0.290322870016098
    z[2,3,4]  R852      -1.6673433780670166e-01
    z[2,3,4]  R853      -1.1193389445543289e-01
    z[2,3,4]  R854      -3.5640573501586914e-01
    z[2,3,4]  R855      -2.8274014592170715e-01
    z[2,3,4]  R856      -3.7602904438972473e-01
    z[2,3,4]  R857      4.6913042664527893e-02
    z[2,3,4]  R858      -1.1471226811408997e-01
    z[2,3,4]  R859      6.2326043844223022e-02
    z[2,3,4]  R860      3.9983157068490982e-02
    z[2,3,4]  R861      2.2628886997699738e-01
    z[2,3,4]  R862      -2.6916259527206421e-01
    z[2,3,4]  R863      2.8445419669151306e-01
    z[2,3,4]  R864      -1.6582595184445381e-02
    z[2,3,4]  R865      6.2523297965526581e-03
    z[2,3,4]  R866      4.3712127208709717e-01
    z[2,3,4]  R867      7.6559692621231079e-02
    z[2,3,4]  R868      -6.3483619689941406e-01
    z[2,3,4]  R869      -7.7163302898406982e-01
    z[2,3,4]  R870      -5.2388721704483032e-01
    z[2,3,4]  R871      2.4067023769021034e-03
    z[2,3,4]  R872      0.0366709902882576
    z[2,3,4]  R873      4.2248047888278961e-02
    z[2,3,4]  R874      -7.0286847651004791e-02
    z[2,3,4]  R875      2.3987520486116409e-02
    z[2,3,4]  R876      4.4759169220924377e-01
    z[2,3,4]  R877      -3.4284293651580811e-01
    z[2,3,4]  R878      8.7679319083690643e-02
    z[2,3,4]  R879      8.8047936558723450e-02
    z[2,3,4]  R880      1.4458252489566803e-01
    z[2,3,4]  R881      6.2738835811614990e-02
    z[2,3,4]  R882      2.5824561715126038e-01
    z[2,3,4]  R883      3.1630176305770874e-01
    z[2,3,4]  R884      1.7364698648452759e-01
    z[2,3,4]  R885      -1.5740180015563965e-01
    z[2,3,4]  R886      2.8242337703704834e-01
    z[2,3,4]  R887      -0.374988853931427
    z[2,3,4]  R888      -1.2066390365362167e-01
    z[2,3,4]  R889      7.7609471976757050e-02
    z[2,3,4]  R890      2.2041009366512299e-01
    z[2,3,4]  R891      4.9515865743160248e-02
    z[2,3,4]  R892      1.8371193110942841e-01
    z[2,3,4]  R893      -9.0807870030403137e-02
    z[2,3,4]  R894      0.341768354177475
    z[2,3,4]  R895      -5.2788305282592773e-01
    z[2,3,4]  R896      -2.6208034157752991e-01
    z[2,3,4]  R897      -4.8843666911125183e-01
    z[2,3,4]  R898      1.4653810858726501e-01
    z[2,3,5]  R25       -1
    z[2,3,5]  R34       1
    z[2,3,5]  R831      -1
    z[2,3,5]  R832      1
    z[2,3,5]  R835      5.6148413568735123e-02
    z[2,3,5]  R836      -3.9422157406806946e-01
    z[2,3,5]  R837      -9.2523522675037384e-02
    z[2,3,5]  R838      -6.8087595701217651e-01
    z[2,3,5]  R839      -6.5322220325469971e-01
    z[2,3,5]  R840      -1.2974390387535095e-01
    z[2,3,5]  R841      1.0559809952974319e-01
    z[2,3,5]  R842      2.2686554118990898e-02
    z[2,3,5]  R843      -1.3774999976158142e-01
    z[2,3,5]  R844      5.6754392385482788e-01
    z[2,3,5]  R845      -5.3466308116912842e-01
    z[2,3,5]  R846      1.4480036497116089e-01
    z[2,3,5]  R847      5.1891487836837769e-01
    z[2,3,5]  R848      6.8477618694305420e-01
    z[2,3,5]  R849      4.1568911075592041e-01
    z[2,3,5]  R850      5.2264976501464844e-01
    z[2,3,5]  R851      5.3903043270111084e-01
    z[2,3,5]  R852      4.7658559679985046e-01
    z[2,3,5]  R853      5.8064532279968262e-01
    z[2,3,5]  R854      3.8943758606910706e-01
    z[2,3,5]  R855      5.0531727075576782e-01
    z[2,3,5]  R856      1.6401119530200958e-01
    z[2,3,5]  R857      5.0206100940704346e-01
    z[2,3,5]  R858      5.5847585201263428e-01
    z[2,3,5]  R859      4.9424162507057190e-01
    z[2,3,5]  R860      6.1668062210083008e-01
    z[2,3,5]  R861      -6.0272864997386932e-02
    z[2,3,5]  R862      5.2378200925886631e-03
    z[2,3,5]  R863      -2.4463790655136108e-01
    z[2,3,5]  R864      5.4991978406906128e-01
    z[2,3,5]  R865      7.6349325478076935e-02
    z[2,3,5]  R866      6.2419414520263672e-01
    z[2,3,5]  R867      9.5532253384590149e-02
    z[2,3,5]  R868      -2.0367403328418732e-01
    z[2,3,5]  R869      -1.3126057386398315e-01
    z[2,3,5]  R870      -9.7383596003055573e-03
    z[2,3,5]  R871      -2.2481042146682739e-01
    z[2,3,5]  R872      -2.5774425268173218e-01
    z[2,3,5]  R873      -1.6966257989406586e-01
    z[2,3,5]  R874      -0.244800865650177
    z[2,3,5]  R875      3.4857827425003052e-01
    z[2,3,5]  R876      -1.6361238434910774e-02
    z[2,3,5]  R877      -1.2094871699810028e-01
    z[2,3,5]  R878      2.1043597161769867e-01
    z[2,3,5]  R879      3.9162391424179077e-01
    z[2,3,5]  R880      -1.0682401806116104e-01
    z[2,3,5]  R881      -1.7073659598827362e-01
    z[2,3,5]  R882      1.2148747593164444e-01
    z[2,3,5]  R883      1.3128049671649933e-01
    z[2,3,5]  R884      2.2975887358188629e-01
    z[2,3,5]  R885      5.1292762160301208e-02
    z[2,3,5]  R886      5.4597463458776474e-02
    z[2,3,5]  R887      1.5197399258613586e-01
    z[2,3,5]  R888      -1.5045249462127686e-01
    z[2,3,5]  R889      1.0198665410280228e-01
    z[2,3,5]  R890      -3.8891077041625977e-01
    z[2,3,5]  R891      1.7021405696868896e-01
    z[2,3,5]  R892      -0.256853312253952
    z[2,3,5]  R893      2.6179185137152672e-02
    z[2,3,5]  R894      -3.5139527916908264e-01
    z[2,3,5]  R895      1.7495891451835632e-01
    z[2,3,5]  R896      -1.4328850805759430e-01
    z[2,3,5]  R897      2.0163874328136444e-01
    z[2,3,5]  R898      1.7113395035266876e-01
    z[2,3,6]  R26       -1
    z[2,3,6]  R35       1
    z[2,3,6]  R833      -1
    z[2,3,6]  R834      1
    z[2,3,6]  R835      -2.8831312060356140e-01
    z[2,3,6]  R836      2.6856502890586853e-01
    z[2,3,6]  R837      4.5523303747177124e-01
    z[2,3,6]  R838      -7.2286748327314854e-03
    z[2,3,6]  R839      4.3456846475601196e-01
    z[2,3,6]  R840      6.4778155088424683e-01
    z[2,3,6]  R841      -0.33290895819664
    z[2,3,6]  R842      -3.2992663979530334e-01
    z[2,3,6]  R843      -1.5846803784370422e-01
    z[2,3,6]  R844      2.5262561440467834e-01
    z[2,3,6]  R845      -2.4382162094116211e-01
    z[2,3,6]  R846      1.0802300274372101e-01
    z[2,3,6]  R847      -5.2457344532012939e-01
    z[2,3,6]  R848      -1.3604341447353363e-01
    z[2,3,6]  R849      -5.9329345822334290e-02
    z[2,3,6]  R850      -8.3711788058280945e-02
    z[2,3,6]  R851      1.5771028399467468e-01
    z[2,3,6]  R852      2.6348903775215149e-01
    z[2,3,6]  R853      1.6615954041481018e-01
    z[2,3,6]  R854      4.2247197031974792e-01
    z[2,3,6]  R855      7.8150548040866852e-02
    z[2,3,6]  R856      4.3891948461532593e-01
    z[2,3,6]  R857      1.9626709818840027e-01
    z[2,3,6]  R858      1.3614273071289062e-01
    z[2,3,6]  R859      2.6613363623619080e-01
    z[2,3,6]  R860      4.8746760934591293e-02
    z[2,3,6]  R861      2.3065450787544250e-01
    z[2,3,6]  R862      -2.2433733940124512e-01
    z[2,3,6]  R863      9.5027135685086250e-03
    z[2,3,6]  R864      -3.0451586842536926e-01
    z[2,3,6]  R865      4.0011522173881531e-01
    z[2,3,6]  R866      -9.0896666049957275e-02
    z[2,3,6]  R867      4.7414788603782654e-01
    z[2,3,6]  R868      3.8322679698467255e-02
    z[2,3,6]  R869      9.8887398838996887e-02
    z[2,3,6]  R870      5.5091398954391479e-01
    z[2,3,6]  R871      -3.1023567914962769e-01
    z[2,3,6]  R872      -2.6245719194412231e-01
    z[2,3,6]  R873      -3.0436590313911438e-01
    z[2,3,6]  R874      -4.6823951601982117e-01
    z[2,3,6]  R875      -2.9056310653686523e-01
    z[2,3,6]  R876      -2.0337577164173126e-01
    z[2,3,6]  R877      2.0055323839187622e-01
    z[2,3,6]  R878      9.4782322645187378e-02
    z[2,3,6]  R879      -2.7302485704421997e-01
    z[2,3,6]  R880      -7.0345097780227661e-01
    z[2,3,6]  R881      -0.365187406539917
    z[2,3,6]  R882      2.4529822170734406e-01
    z[2,3,6]  R883      -1.5396726131439209e-01
    z[2,3,6]  R884      1.1342352628707886e-01
    z[2,3,6]  R885      1.6710974276065826e-01
    z[2,3,6]  R886      1.0853295773267746e-01
    z[2,3,6]  R887      0.0305503997951746
    z[2,3,6]  R888      8.9628294110298157e-02
    z[2,3,6]  R889      1.7342561483383179e-01
    z[2,3,6]  R890      2.1724744141101837e-01
    z[2,3,6]  R891      -2.5142121315002441e-01
    z[2,3,6]  R892      3.6345383524894714e-01
    z[2,3,6]  R893      -3.0564209818840027e-01
    z[2,3,6]  R894      4.7692552208900452e-02
    z[2,3,6]  R895      5.6257343292236328e-01
    z[2,3,6]  R896      0.313156396150589
    z[2,3,6]  R897      2.4942032992839813e-01
    z[2,3,6]  R898      -5.1320254802703857e-01
    z[3,2,0]  R20       1
    z[3,2,0]  R29       -1
    z[3,2,0]  R899      -1
    z[3,2,0]  R900      1
    z[3,2,0]  R913      -6.5310436487197876e-01
    z[3,2,0]  R914      -7.3012202978134155e-01
    z[3,2,0]  R915      -8.1839954853057861e-01
    z[3,2,0]  R916      -7.1401822566986084e-01
    z[3,2,0]  R917      0.153198704123497
    z[3,2,0]  R918      -6.0081088542938232e-01
    z[3,2,0]  R919      7.1688795089721680e-01
    z[3,2,0]  R920      2.3340252041816711e-01
    z[3,2,0]  R921      4.9905306100845337e-01
    z[3,2,0]  R922      2.5812390446662903e-01
    z[3,2,0]  R923      2.7214249968528748e-01
    z[3,2,0]  R924      0.531776487827301
    z[3,2,0]  R925      5.4017448425292969e-01
    z[3,2,0]  R926      3.8133546710014343e-01
    z[3,2,0]  R927      5.2057379484176636e-01
    z[3,2,0]  R928      5.9864956140518188e-01
    z[3,2,0]  R929      0.365446001291275
    z[3,2,0]  R930      5.5695241689682007e-01
    z[3,2,0]  R931      2.8284192085266113e-01
    z[3,2,0]  R932      1.7235065996646881e-01
    z[3,2,0]  R933      -4.2859369516372681e-01
    z[3,2,0]  R934      5.8471912145614624e-01
    z[3,2,0]  R935      0.627866804599762
    z[3,2,0]  R936      6.2033843994140625e-01
    z[3,2,0]  R937      5.3637397289276123e-01
    z[3,2,0]  R938      5.6048560142517090e-01
    z[3,2,0]  R939      5.8017802238464355e-01
    z[3,2,0]  R940      6.1862134933471680e-01
    z[3,2,0]  R941      3.5152587294578552e-01
    z[3,2,0]  R942      6.4129203557968140e-01
    z[3,2,0]  R943      4.6803352236747742e-01
    z[3,2,0]  R944      5.8159804344177246e-01
    z[3,2,0]  R945      4.9010065197944641e-01
    z[3,2,0]  R946      2.0241326093673706e-01
    z[3,2,0]  R947      -0.188896045088768
    z[3,2,0]  R948      -9.8122563213109970e-03
    z[3,2,0]  R949      0.0203165952116251
    z[3,2,0]  R950      3.1710234284400940e-01
    z[3,2,0]  R951      -5.1831060647964478e-01
    z[3,2,0]  R952      3.4386706352233887e-01
    z[3,2,0]  R953      -1.6055357456207275e-01
    z[3,2,0]  R954      -3.1579840183258057e-01
    z[3,2,0]  R955      -5.1425721496343613e-02
    z[3,2,0]  R956      3.0115556716918945e-01
    z[3,2,0]  R957      1.2531785666942596e-01
    z[3,2,0]  R958      4.2257830500602722e-02
    z[3,2,0]  R959      3.7992015480995178e-01
    z[3,2,0]  R960      5.2165144681930542e-01
    z[3,2,0]  R961      4.7604960203170776e-01
    z[3,2,0]  R962      3.3365431427955627e-01
    z[3,2,0]  R963      2.1986183524131775e-01
    z[3,2,0]  R964      5.3151583671569824e-01
    z[3,2,0]  R965      7.1910239756107330e-02
    z[3,2,0]  R966      -5.5746231228113174e-02
    z[3,2,0]  R967      1.4154396951198578e-01
    z[3,2,0]  R968      -1.1921548098325729e-01
    z[3,2,0]  R969      -1.4973938465118408e-02
    z[3,2,0]  R970      -4.2232591658830643e-02
    z[3,2,0]  R971      1.4951783418655396e-01
    z[3,2,0]  R972      -2.3622293770313263e-01
    z[3,2,0]  R973      1.8643289804458618e-01
    z[3,2,0]  R974      2.2332927212119102e-02
    z[3,2,0]  R975      3.0346214771270752e-01
    z[3,2,0]  R976      -2.4205325543880463e-01
    z[3,2,1]  R21       1
    z[3,2,1]  R30       -1
    z[3,2,1]  R901      -1
    z[3,2,1]  R902      1
    z[3,2,1]  R913      5.8178991079330444e-01
    z[3,2,1]  R914      4.7476023435592651e-01
    z[3,2,1]  R915      -2.7540719509124756e-01
    z[3,2,1]  R916      -2.4982862174510956e-01
    z[3,2,1]  R917      6.0271453857421875e-01
    z[3,2,1]  R918      1.2983238697052002e-01
    z[3,2,1]  R919      -7.5340755283832550e-02
    z[3,2,1]  R920      4.8387479782104492e-01
    z[3,2,1]  R921      3.0697804689407349e-01
    z[3,2,1]  R922      5.3865957260131836e-01
    z[3,2,1]  R923      -5.1415318250656128e-01
    z[3,2,1]  R924      -7.2146528959274292e-01
    z[3,2,1]  R925      -6.8546158075332642e-01
    z[3,2,1]  R926      -7.5014483928680420e-01
    z[3,2,1]  R927      -6.3469791412353516e-01
    z[3,2,1]  R928      -5.6650543212890625e-01
    z[3,2,1]  R929      -8.0281686782836914e-01
    z[3,2,1]  R930      -6.2422585487365723e-01
    z[3,2,1]  R931      -6.1908406019210815e-01
    z[3,2,1]  R932      -2.0034465193748474e-01
    z[3,2,1]  R933      -3.3841341733932495e-01
    z[3,2,1]  R934      -7.0923173427581787e-01
    z[3,2,1]  R935      -6.5544891357421875e-01
    z[3,2,1]  R936      -6.6866677999496460e-01
    z[3,2,1]  R937      -7.2253215312957764e-01
    z[3,2,1]  R938      -0.651892900466919
    z[3,2,1]  R939      -6.3286352157592773e-01
    z[3,2,1]  R940      -5.8157765865325928e-01
    z[3,2,1]  R941      -0.886976957321167
    z[3,2,1]  R942      -5.1137030124664307e-01
    z[3,2,1]  R943      -7.9289269447326660e-01
    z[3,2,1]  R944      -6.3307863473892212e-01
    z[3,2,1]  R945      -2.2521585226058960e-01
    z[3,2,1]  R946      -4.0167921781539917e-01
    z[3,2,1]  R947      -2.7031752467155457e-01
    z[3,2,1]  R948      -5.2839994430541992e-01
    z[3,2,1]  R949      -5.1613306999206543e-01
    z[3,2,1]  R950      6.9041180610656738e-01
    z[3,2,1]  R951      4.4127404689788818e-01
    z[3,2,1]  R952      5.5638778209686279e-01
    z[3,2,1]  R953      -5.3512406349182129e-01
    z[3,2,1]  R954      -0.449727326631546
    z[3,2,1]  R955      -5.2998477220535278e-01
    z[3,2,1]  R956      -2.3548798263072968e-01
    z[3,2,1]  R957      -6.8755798041820526e-02
    z[3,2,1]  R958      -3.0945608019828796e-01
    z[3,2,1]  R959      -3.0317991971969604e-01
    z[3,2,1]  R960      -4.0468877553939819e-01
    z[3,2,1]  R961      7.5076855719089508e-02
    z[3,2,1]  R962      -4.0912812948226929e-01
    z[3,2,1]  R963      -3.5781404376029968e-01
    z[3,2,1]  R964      -1.2643989920616150e-01
    z[3,2,1]  R965      6.2416708469390869e-01
    z[3,2,1]  R966      6.1151504516601562e-01
    z[3,2,1]  R967      6.1467844247817993e-01
    z[3,2,1]  R968      6.0014915466308594e-01
    z[3,2,1]  R969      6.0448038578033447e-01
    z[3,2,1]  R970      5.8867859840393066e-01
    z[3,2,1]  R971      6.3629478216171265e-01
    z[3,2,1]  R972      0.555555522441864
    z[3,2,1]  R973      -4.4533852487802505e-02
    z[3,2,1]  R974      -2.2310809791088104e-01
    z[3,2,1]  R975      -1.3412791490554810e-01
    z[3,2,1]  R976      -0.0782335102558136
    z[3,2,2]  R22       1
    z[3,2,2]  R31       -1
    z[3,2,2]  R903      -1
    z[3,2,2]  R904      1
    z[3,2,2]  R913      -2.0417949557304382e-01
    z[3,2,2]  R914      -3.4446725249290466e-01
    z[3,2,2]  R915      -3.3685794472694397e-01
    z[3,2,2]  R916      -1.9678533077239990e-02
    z[3,2,2]  R917      0.06800577044487
    z[3,2,2]  R918      1.6934520006179810e-01
    z[3,2,2]  R919      3.1749528646469116e-01
    z[3,2,2]  R920      -1.9265535473823547e-01
    z[3,2,2]  R921      -0.0784771665930748
    z[3,2,2]  R922      -4.8448212444782257e-02
    z[3,2,2]  R923      2.8500853106379509e-02
    z[3,2,2]  R924      -1.5785014629364014e-01
    z[3,2,2]  R925      -1.7656792700290680e-01
    z[3,2,2]  R926      0.0232391320168972
    z[3,2,2]  R927      -1.0151895135641098e-01
    z[3,2,2]  R928      -2.4404411017894745e-01
    z[3,2,2]  R929      -2.2070296108722687e-01
    z[3,2,2]  R930      -4.8843196034431458e-01
    z[3,2,2]  R931      -2.0805369317531586e-01
    z[3,2,2]  R932      4.2685028165578842e-02
    z[3,2,2]  R933      -1.9409951567649841e-01
    z[3,2,2]  R934      -2.8021706268191338e-02
    z[3,2,2]  R935      5.2486073225736618e-02
    z[3,2,2]  R936      -7.9806774854660034e-02
    z[3,2,2]  R937      -3.1840169429779053e-01
    z[3,2,2]  R938      3.2039615511894226e-01
    z[3,2,2]  R939      1.9184727966785431e-01
    z[3,2,2]  R940      -3.2531636953353882e-01
    z[3,2,2]  R941      1.9793011248111725e-01
    z[3,2,2]  R942      1.3564078509807587e-01
    z[3,2,2]  R943      2.3570168018341064e-01
    z[3,2,2]  R944      1.5581017732620239e-01
    z[3,2,2]  R945      1.4989016950130463e-01
    z[3,2,2]  R946      -8.5404375568032265e-03
    z[3,2,2]  R947      -1.2486571818590164e-01
    z[3,2,2]  R948      -1.6090908646583557e-01
    z[3,2,2]  R949      -5.5259462445974350e-02
    z[3,2,2]  R950      2.4271681904792786e-01
    z[3,2,2]  R951      3.1402048468589783e-01
    z[3,2,2]  R952      1.5289390087127686e-01
    z[3,2,2]  R953      8.9429974555969238e-02
    z[3,2,2]  R954      -3.0457723140716553e-01
    z[3,2,2]  R955      2.4313895404338837e-01
    z[3,2,2]  R956      3.5214146971702576e-01
    z[3,2,2]  R957      0.198577880859375
    z[3,2,2]  R958      -2.6125302910804749e-01
    z[3,2,2]  R959      7.1913385391235352e-01
    z[3,2,2]  R960      -1.0600367933511734e-01
    z[3,2,2]  R961      -1.3923546671867371e-01
    z[3,2,2]  R962      7.0893031358718872e-01
    z[3,2,2]  R963      -4.0393617749214172e-01
    z[3,2,2]  R964      -2.6510453224182129e-01
    z[3,2,2]  R965      -2.4793711304664612e-01
    z[3,2,2]  R966      -1.9527323544025421e-01
    z[3,2,2]  R967      -2.3801873624324799e-01
    z[3,2,2]  R968      -4.2611122131347656e-01
    z[3,2,2]  R969      -4.0763118863105774e-01
    z[3,2,2]  R970      -2.6661166548728943e-01
    z[3,2,2]  R971      -3.6592435836791992e-01
    z[3,2,2]  R972      -1.8245643377304077e-01
    z[3,2,2]  R973      -8.1135082244873047e-01
    z[3,2,2]  R974      -0.775295615196228
    z[3,2,2]  R975      -7.3469394445419312e-01
    z[3,2,2]  R976      -7.4209457635879517e-01
    z[3,2,3]  R23       1
    z[3,2,3]  R32       -1
    z[3,2,3]  R905      -1
    z[3,2,3]  R906      1
    z[3,2,3]  R913      -2.9196754097938538e-01
    z[3,2,3]  R914      -7.9768812283873558e-03
    z[3,2,3]  R915      6.8975519388914108e-03
    z[3,2,3]  R916      -0.17877297103405
    z[3,2,3]  R917      6.6534203290939331e-01
    z[3,2,3]  R918      0.0673535093665123
    z[3,2,3]  R919      3.7388241291046143e-01
    z[3,2,3]  R920      4.7781109809875488e-01
    z[3,2,3]  R921      -1.6770860552787781e-01
    z[3,2,3]  R922      -2.5062268972396851e-01
    z[3,2,3]  R923      -7.1692460775375366e-01
    z[3,2,3]  R924      1.8741454184055328e-01
    z[3,2,3]  R925      -2.8977379202842712e-01
    z[3,2,3]  R926      -8.4911346435546875e-02
    z[3,2,3]  R927      -3.3067530393600464e-01
    z[3,2,3]  R928      -1.3843837380409241e-01
    z[3,2,3]  R929      -2.8861805796623230e-02
    z[3,2,3]  R930      -2.5015437975525856e-02
    z[3,2,3]  R931      5.0772500038146973e-01
    z[3,2,3]  R932      6.3338494300842285e-01
    z[3,2,3]  R933      -7.0545035600662231e-01
    z[3,2,3]  R934      -1.1263841390609741e-01
    z[3,2,3]  R935      -1.8007743358612061e-01
    z[3,2,3]  R936      2.5668722391128540e-01
    z[3,2,3]  R937      -1.8313533067703247e-01
    z[3,2,3]  R938      -2.5241750478744507e-01
    z[3,2,3]  R939      -2.4784231185913086e-01
    z[3,2,3]  R940      3.5779255628585815e-01
    z[3,2,3]  R941      0.0634353756904602
    z[3,2,3]  R942      -2.4863202869892120e-01
    z[3,2,3]  R943      -4.5533329248428345e-02
    z[3,2,3]  R944      -6.9684617221355438e-02
    z[3,2,3]  R945      0.764371395111084
    z[3,2,3]  R946      0.745017409324646
    z[3,2,3]  R947      -4.9989512562751770e-01
    z[3,2,3]  R948      7.1240496635437012e-01
    z[3,2,3]  R949      6.2345904111862183e-01
    z[3,2,3]  R950      -2.2300015389919281e-01
    z[3,2,3]  R951      -5.5583792924880981e-01
    z[3,2,3]  R952      -0.0460672564804554
    z[3,2,3]  R953      -2.7368506789207458e-01
    z[3,2,3]  R954      -2.0565721392631531e-01
    z[3,2,3]  R955      -8.2955203950405121e-02
    z[3,2,3]  R956      -2.9273739457130432e-01
    z[3,2,3]  R957      9.0377324819564819e-01
    z[3,2,3]  R958      8.3545857667922974e-01
    z[3,2,3]  R959      4.4935768842697144e-01
    z[3,2,3]  R960      2.7733248472213745e-01
    z[3,2,3]  R961      -1.2220747023820877e-01
    z[3,2,3]  R962      -5.6970175355672836e-02
    z[3,2,3]  R963      -3.3664211630821228e-01
    z[3,2,3]  R964      7.3629550635814667e-02
    z[3,2,3]  R965      0.557930588722229
    z[3,2,3]  R966      0.551186740398407
    z[3,2,3]  R967      3.8179707527160645e-01
    z[3,2,3]  R968      3.4594398736953735e-01
    z[3,2,3]  R969      3.0154392123222351e-01
    z[3,2,3]  R970      3.5131609439849854e-01
    z[3,2,3]  R971      3.1221404671669006e-01
    z[3,2,3]  R972      4.9124187231063843e-01
    z[3,2,3]  R973      1.1037503182888031e-01
    z[3,2,3]  R974      -7.1076013147830963e-02
    z[3,2,3]  R975      1.7651884257793427e-01
    z[3,2,3]  R976      1.7760708928108215e-02
    z[3,2,4]  R24       1
    z[3,2,4]  R33       -1
    z[3,2,4]  R907      -1
    z[3,2,4]  R908      1
    z[3,2,4]  R913      2.2628886997699738e-01
    z[3,2,4]  R914      -2.6916259527206421e-01
    z[3,2,4]  R915      2.8445419669151306e-01
    z[3,2,4]  R916      -1.6582595184445381e-02
    z[3,2,4]  R917      6.2523297965526581e-03
    z[3,2,4]  R918      4.3712127208709717e-01
    z[3,2,4]  R919      7.6559692621231079e-02
    z[3,2,4]  R920      -6.3483619689941406e-01
    z[3,2,4]  R921      -7.7163302898406982e-01
    z[3,2,4]  R922      -5.2388721704483032e-01
    z[3,2,4]  R923      2.4067023769021034e-03
    z[3,2,4]  R924      0.0366709902882576
    z[3,2,4]  R925      4.2248047888278961e-02
    z[3,2,4]  R926      -7.0286847651004791e-02
    z[3,2,4]  R927      2.3987520486116409e-02
    z[3,2,4]  R928      4.4759169220924377e-01
    z[3,2,4]  R929      -3.4284293651580811e-01
    z[3,2,4]  R930      8.7679319083690643e-02
    z[3,2,4]  R931      8.8047936558723450e-02
    z[3,2,4]  R932      1.4458252489566803e-01
    z[3,2,4]  R933      6.2738835811614990e-02
    z[3,2,4]  R934      2.5824561715126038e-01
    z[3,2,4]  R935      3.1630176305770874e-01
    z[3,2,4]  R936      1.7364698648452759e-01
    z[3,2,4]  R937      -1.5740180015563965e-01
    z[3,2,4]  R938      2.8242337703704834e-01
    z[3,2,4]  R939      -0.374988853931427
    z[3,2,4]  R940      -1.2066390365362167e-01
    z[3,2,4]  R941      7.7609471976757050e-02
    z[3,2,4]  R942      2.2041009366512299e-01
    z[3,2,4]  R943      4.9515865743160248e-02
    z[3,2,4]  R944      1.8371193110942841e-01
    z[3,2,4]  R945      -9.0807870030403137e-02
    z[3,2,4]  R946      0.341768354177475
    z[3,2,4]  R947      -5.2788305282592773e-01
    z[3,2,4]  R948      -2.6208034157752991e-01
    z[3,2,4]  R949      -4.8843666911125183e-01
    z[3,2,4]  R950      1.4653810858726501e-01
    z[3,2,4]  R951      -2.0685656368732452e-01
    z[3,2,4]  R952      0.564935028553009
    z[3,2,4]  R953      6.2383162975311279e-01
    z[3,2,4]  R954      3.1513506174087524e-01
    z[3,2,4]  R955      -1.8688105046749115e-01
    z[3,2,4]  R956      -4.5573839545249939e-01
    z[3,2,4]  R957      -3.6735687404870987e-02
    z[3,2,4]  R958      -1.6383193433284760e-01
    z[3,2,4]  R959      2.4072615429759026e-02
    z[3,2,4]  R960      -3.0005145072937012e-01
    z[3,2,4]  R961      -6.2298113107681274e-01
    z[3,2,4]  R962      -4.2758038640022278e-01
    z[3,2,4]  R963      -5.1841910928487778e-02
    z[3,2,4]  R964      3.7198910117149353e-01
    z[3,2,4]  R965      -2.3699709773063660e-01
    z[3,2,4]  R966      -2.8858028352260590e-02
    z[3,2,4]  R967      -0.290322870016098
    z[3,2,4]  R968      -1.6673433780670166e-01
    z[3,2,4]  R969      -1.1193389445543289e-01
    z[3,2,4]  R970      -3.5640573501586914e-01
    z[3,2,4]  R971      -2.8274014592170715e-01
    z[3,2,4]  R972      -3.7602904438972473e-01
    z[3,2,4]  R973      4.6913042664527893e-02
    z[3,2,4]  R974      -1.1471226811408997e-01
    z[3,2,4]  R975      6.2326043844223022e-02
    z[3,2,4]  R976      3.9983157068490982e-02
    z[3,2,5]  R25       1
    z[3,2,5]  R34       -1
    z[3,2,5]  R909      -1
    z[3,2,5]  R910      1
    z[3,2,5]  R913      -6.0272864997386932e-02
    z[3,2,5]  R914      5.2378200925886631e-03
    z[3,2,5]  R915      -2.4463790655136108e-01
    z[3,2,5]  R916      5.4991978406906128e-01
    z[3,2,5]  R917      7.6349325478076935e-02
    z[3,2,5]  R918      6.2419414520263672e-01
    z[3,2,5]  R919      9.5532253384590149e-02
    z[3,2,5]  R920      -2.0367403328418732e-01
    z[3,2,5]  R921      -1.3126057386398315e-01
    z[3,2,5]  R922      -9.7383596003055573e-03
    z[3,2,5]  R923      -2.2481042146682739e-01
    z[3,2,5]  R924      -2.5774425268173218e-01
    z[3,2,5]  R925      -1.6966257989406586e-01
    z[3,2,5]  R926      -0.244800865650177
    z[3,2,5]  R927      3.4857827425003052e-01
    z[3,2,5]  R928      -1.6361238434910774e-02
    z[3,2,5]  R929      -1.2094871699810028e-01
    z[3,2,5]  R930      2.1043597161769867e-01
    z[3,2,5]  R931      3.9162391424179077e-01
    z[3,2,5]  R932      -1.0682401806116104e-01
    z[3,2,5]  R933      -1.7073659598827362e-01
    z[3,2,5]  R934      1.2148747593164444e-01
    z[3,2,5]  R935      1.3128049671649933e-01
    z[3,2,5]  R936      2.2975887358188629e-01
    z[3,2,5]  R937      5.1292762160301208e-02
    z[3,2,5]  R938      5.4597463458776474e-02
    z[3,2,5]  R939      1.5197399258613586e-01
    z[3,2,5]  R940      -1.5045249462127686e-01
    z[3,2,5]  R941      1.0198665410280228e-01
    z[3,2,5]  R942      -3.8891077041625977e-01
    z[3,2,5]  R943      1.7021405696868896e-01
    z[3,2,5]  R944      -0.256853312253952
    z[3,2,5]  R945      2.6179185137152672e-02
    z[3,2,5]  R946      -3.5139527916908264e-01
    z[3,2,5]  R947      1.7495891451835632e-01
    z[3,2,5]  R948      -1.4328850805759430e-01
    z[3,2,5]  R949      2.0163874328136444e-01
    z[3,2,5]  R950      1.7113395035266876e-01
    z[3,2,5]  R951      5.6148413568735123e-02
    z[3,2,5]  R952      -3.9422157406806946e-01
    z[3,2,5]  R953      -9.2523522675037384e-02
    z[3,2,5]  R954      -6.8087595701217651e-01
    z[3,2,5]  R955      -6.5322220325469971e-01
    z[3,2,5]  R956      -1.2974390387535095e-01
    z[3,2,5]  R957      1.0559809952974319e-01
    z[3,2,5]  R958      2.2686554118990898e-02
    z[3,2,5]  R959      -1.3774999976158142e-01
    z[3,2,5]  R960      5.6754392385482788e-01
    z[3,2,5]  R961      -5.3466308116912842e-01
    z[3,2,5]  R962      1.4480036497116089e-01
    z[3,2,5]  R963      5.1891487836837769e-01
    z[3,2,5]  R964      6.8477618694305420e-01
    z[3,2,5]  R965      4.1568911075592041e-01
    z[3,2,5]  R966      5.2264976501464844e-01
    z[3,2,5]  R967      5.3903043270111084e-01
    z[3,2,5]  R968      4.7658559679985046e-01
    z[3,2,5]  R969      5.8064532279968262e-01
    z[3,2,5]  R970      3.8943758606910706e-01
    z[3,2,5]  R971      5.0531727075576782e-01
    z[3,2,5]  R972      1.6401119530200958e-01
    z[3,2,5]  R973      5.0206100940704346e-01
    z[3,2,5]  R974      5.5847585201263428e-01
    z[3,2,5]  R975      4.9424162507057190e-01
    z[3,2,5]  R976      6.1668062210083008e-01
    z[3,2,6]  R26       1
    z[3,2,6]  R35       -1
    z[3,2,6]  R911      -1
    z[3,2,6]  R912      1
    z[3,2,6]  R913      2.3065450787544250e-01
    z[3,2,6]  R914      -2.2433733940124512e-01
    z[3,2,6]  R915      9.5027135685086250e-03
    z[3,2,6]  R916      -3.0451586842536926e-01
    z[3,2,6]  R917      4.0011522173881531e-01
    z[3,2,6]  R918      -9.0896666049957275e-02
    z[3,2,6]  R919      4.7414788603782654e-01
    z[3,2,6]  R920      3.8322679698467255e-02
    z[3,2,6]  R921      9.8887398838996887e-02
    z[3,2,6]  R922      5.5091398954391479e-01
    z[3,2,6]  R923      -3.1023567914962769e-01
    z[3,2,6]  R924      -2.6245719194412231e-01
    z[3,2,6]  R925      -3.0436590313911438e-01
    z[3,2,6]  R926      -4.6823951601982117e-01
    z[3,2,6]  R927      -2.9056310653686523e-01
    z[3,2,6]  R928      -2.0337577164173126e-01
    z[3,2,6]  R929      2.0055323839187622e-01
    z[3,2,6]  R930      9.4782322645187378e-02
    z[3,2,6]  R931      -2.7302485704421997e-01
    z[3,2,6]  R932      -7.0345097780227661e-01
    z[3,2,6]  R933      -0.365187406539917
    z[3,2,6]  R934      2.4529822170734406e-01
    z[3,2,6]  R935      -1.5396726131439209e-01
    z[3,2,6]  R936      1.1342352628707886e-01
    z[3,2,6]  R937      1.6710974276065826e-01
    z[3,2,6]  R938      1.0853295773267746e-01
    z[3,2,6]  R939      0.0305503997951746
    z[3,2,6]  R940      8.9628294110298157e-02
    z[3,2,6]  R941      1.7342561483383179e-01
    z[3,2,6]  R942      2.1724744141101837e-01
    z[3,2,6]  R943      -2.5142121315002441e-01
    z[3,2,6]  R944      3.6345383524894714e-01
    z[3,2,6]  R945      -3.0564209818840027e-01
    z[3,2,6]  R946      4.7692552208900452e-02
    z[3,2,6]  R947      5.6257343292236328e-01
    z[3,2,6]  R948      0.313156396150589
    z[3,2,6]  R949      2.4942032992839813e-01
    z[3,2,6]  R950      -5.1320254802703857e-01
    z[3,2,6]  R951      -2.8831312060356140e-01
    z[3,2,6]  R952      2.6856502890586853e-01
    z[3,2,6]  R953      4.5523303747177124e-01
    z[3,2,6]  R954      -7.2286748327314854e-03
    z[3,2,6]  R955      4.3456846475601196e-01
    z[3,2,6]  R956      6.4778155088424683e-01
    z[3,2,6]  R957      -0.33290895819664
    z[3,2,6]  R958      -3.2992663979530334e-01
    z[3,2,6]  R959      -1.5846803784370422e-01
    z[3,2,6]  R960      2.5262561440467834e-01
    z[3,2,6]  R961      -2.4382162094116211e-01
    z[3,2,6]  R962      1.0802300274372101e-01
    z[3,2,6]  R963      -5.2457344532012939e-01
    z[3,2,6]  R964      -1.3604341447353363e-01
    z[3,2,6]  R965      -5.9329345822334290e-02
    z[3,2,6]  R966      -8.3711788058280945e-02
    z[3,2,6]  R967      1.5771028399467468e-01
    z[3,2,6]  R968      2.6348903775215149e-01
    z[3,2,6]  R969      1.6615954041481018e-01
    z[3,2,6]  R970      4.2247197031974792e-01
    z[3,2,6]  R971      7.8150548040866852e-02
    z[3,2,6]  R972      4.3891948461532593e-01
    z[3,2,6]  R973      1.9626709818840027e-01
    z[3,2,6]  R974      1.3614273071289062e-01
    z[3,2,6]  R975      2.6613363623619080e-01
    z[3,2,6]  R976      4.8746760934591293e-02
    z[3,4,0]  R29       -1
    z[3,4,0]  R38       1
    z[3,4,0]  R977      -1
    z[3,4,0]  R978      1
    z[3,4,0]  R991      -6.5310436487197876e-01
    z[3,4,0]  R992      -7.3012202978134155e-01
    z[3,4,0]  R993      -8.1839954853057861e-01
    z[3,4,0]  R994      -7.1401822566986084e-01
    z[3,4,0]  R995      0.153198704123497
    z[3,4,0]  R996      -6.0081088542938232e-01
    z[3,4,0]  R997      7.1688795089721680e-01
    z[3,4,0]  R998      2.3340252041816711e-01
    z[3,4,0]  R999      4.9905306100845337e-01
    z[3,4,0]  R1000     2.5812390446662903e-01
    z[3,4,0]  R1001     2.7214249968528748e-01
    z[3,4,0]  R1002     0.531776487827301
    z[3,4,0]  R1003     5.4017448425292969e-01
    z[3,4,0]  R1004     3.8133546710014343e-01
    z[3,4,0]  R1005     5.2057379484176636e-01
    z[3,4,0]  R1006     5.9864956140518188e-01
    z[3,4,0]  R1007     0.365446001291275
    z[3,4,0]  R1008     5.5695241689682007e-01
    z[3,4,0]  R1009     2.8284192085266113e-01
    z[3,4,0]  R1010     1.7235065996646881e-01
    z[3,4,0]  R1011     -4.2859369516372681e-01
    z[3,4,0]  R1012     5.8471912145614624e-01
    z[3,4,0]  R1013     0.627866804599762
    z[3,4,0]  R1014     6.2033843994140625e-01
    z[3,4,0]  R1015     5.3637397289276123e-01
    z[3,4,0]  R1016     5.6048560142517090e-01
    z[3,4,0]  R1017     5.8017802238464355e-01
    z[3,4,0]  R1018     6.1862134933471680e-01
    z[3,4,0]  R1019     3.5152587294578552e-01
    z[3,4,0]  R1020     6.4129203557968140e-01
    z[3,4,0]  R1021     4.6803352236747742e-01
    z[3,4,0]  R1022     5.8159804344177246e-01
    z[3,4,0]  R1023     4.9010065197944641e-01
    z[3,4,0]  R1024     2.0241326093673706e-01
    z[3,4,0]  R1025     -0.188896045088768
    z[3,4,0]  R1026     -9.8122563213109970e-03
    z[3,4,0]  R1027     0.0203165952116251
    z[3,4,0]  R1028     3.1710234284400940e-01
    z[3,4,0]  R1029     4.1285350918769836e-01
    z[3,4,0]  R1030     3.8448178768157959e-01
    z[3,4,0]  R1031     1.1995550245046616e-01
    z[3,4,0]  R1032     2.0959652960300446e-01
    z[3,4,0]  R1033     6.0748201608657837e-01
    z[3,4,0]  R1034     4.7497734427452087e-01
    z[3,4,0]  R1035     2.8818449378013611e-01
    z[3,4,0]  R1036     -6.7278486490249634e-01
    z[3,4,0]  R1037     3.0296313762664795e-01
    z[3,4,0]  R1038     2.9295399785041809e-01
    z[3,4,0]  R1039     5.3371459245681763e-01
    z[3,4,0]  R1040     -3.9458143711090088e-01
    z[3,4,0]  R1041     -2.5424867868423462e-01
    z[3,4,0]  R1042     -1.4888504147529602e-01
    z[3,4,0]  R1043     3.2396411895751953e-01
    z[3,4,0]  R1044     1.2609507143497467e-01
    z[3,4,0]  R1045     -1.9771598279476166e-01
    z[3,4,0]  R1046     -1.7129307985305786e-01
    z[3,4,0]  R1047     2.2557590901851654e-01
    z[3,4,0]  R1048     -1.8372812867164612e-01
    z[3,4,0]  R1049     -1.3125183992087841e-02
    z[3,4,0]  R1050     -2.5624418631196022e-02
    z[3,4,0]  R1051     -1.9810365140438080e-01
    z[3,4,0]  R1052     -2.2849960252642632e-02
    z[3,4,0]  R1053     -2.4032703042030334e-01
    z[3,4,0]  R1054     -1.7159251868724823e-01
    z[3,4,0]  R1055     3.7596255540847778e-01
    z[3,4,0]  R1056     -2.3235681653022766e-01
    z[3,4,0]  R1057     -6.6991263628005981e-01
    z[3,4,0]  R1058     3.5354757308959961e-01
    z[3,4,0]  R1059     1.0167054831981659e-01
    z[3,4,0]  R1060     -2.4417449533939362e-01
    z[3,4,0]  R1061     -1.4748911559581757e-01
    z[3,4,0]  R1062     3.1215512752532959e-01
    z[3,4,0]  R1063     -3.8002294301986694e-01
    z[3,4,0]  R1064     0.0915653184056282
    z[3,4,0]  R1065     0.378814697265625
    z[3,4,0]  R1066     8.8293008506298065e-02
    z[3,4,0]  R1067     2.1603241562843323e-01
    z[3,4,0]  R1068     6.5152287483215332e-02
    z[3,4,0]  R1069     9.1169491410255432e-02
    z[3,4,0]  R1070     3.4985087811946869e-02
    z[3,4,0]  R1071     1.2196503579616547e-01
    z[3,4,0]  R1072     2.8525349497795105e-01
    z[3,4,0]  R1073     5.8857542276382446e-01
    z[3,4,0]  R1074     1.6893598437309265e-01
    z[3,4,0]  R1075     0.0400143563747406
    z[3,4,0]  R1076     4.2162124067544937e-02
    z[3,4,0]  R1077     -2.4480982124805450e-01
    z[3,4,0]  R1078     2.9493844509124756e-01
    z[3,4,1]  R30       -1
    z[3,4,1]  R39       1
    z[3,4,1]  R979      -1
    z[3,4,1]  R980      1
    z[3,4,1]  R991      5.8178991079330444e-01
    z[3,4,1]  R992      4.7476023435592651e-01
    z[3,4,1]  R993      -2.7540719509124756e-01
    z[3,4,1]  R994      -2.4982862174510956e-01
    z[3,4,1]  R995      6.0271453857421875e-01
    z[3,4,1]  R996      1.2983238697052002e-01
    z[3,4,1]  R997      -7.5340755283832550e-02
    z[3,4,1]  R998      4.8387479782104492e-01
    z[3,4,1]  R999      3.0697804689407349e-01
    z[3,4,1]  R1000     5.3865957260131836e-01
    z[3,4,1]  R1001     -5.1415318250656128e-01
    z[3,4,1]  R1002     -7.2146528959274292e-01
    z[3,4,1]  R1003     -6.8546158075332642e-01
    z[3,4,1]  R1004     -7.5014483928680420e-01
    z[3,4,1]  R1005     -6.3469791412353516e-01
    z[3,4,1]  R1006     -5.6650543212890625e-01
    z[3,4,1]  R1007     -8.0281686782836914e-01
    z[3,4,1]  R1008     -6.2422585487365723e-01
    z[3,4,1]  R1009     -6.1908406019210815e-01
    z[3,4,1]  R1010     -2.0034465193748474e-01
    z[3,4,1]  R1011     -3.3841341733932495e-01
    z[3,4,1]  R1012     -7.0923173427581787e-01
    z[3,4,1]  R1013     -6.5544891357421875e-01
    z[3,4,1]  R1014     -6.6866677999496460e-01
    z[3,4,1]  R1015     -7.2253215312957764e-01
    z[3,4,1]  R1016     -0.651892900466919
    z[3,4,1]  R1017     -6.3286352157592773e-01
    z[3,4,1]  R1018     -5.8157765865325928e-01
    z[3,4,1]  R1019     -0.886976957321167
    z[3,4,1]  R1020     -5.1137030124664307e-01
    z[3,4,1]  R1021     -7.9289269447326660e-01
    z[3,4,1]  R1022     -6.3307863473892212e-01
    z[3,4,1]  R1023     -2.2521585226058960e-01
    z[3,4,1]  R1024     -4.0167921781539917e-01
    z[3,4,1]  R1025     -2.7031752467155457e-01
    z[3,4,1]  R1026     -5.2839994430541992e-01
    z[3,4,1]  R1027     -5.1613306999206543e-01
    z[3,4,1]  R1028     6.9041180610656738e-01
    z[3,4,1]  R1029     -1.3202236592769623e-01
    z[3,4,1]  R1030     -4.5940056443214417e-02
    z[3,4,1]  R1031     -2.1939606964588165e-01
    z[3,4,1]  R1032     -1.8394032120704651e-01
    z[3,4,1]  R1033     1.7205059528350830e-02
    z[3,4,1]  R1034     7.5912439823150635e-01
    z[3,4,1]  R1035     7.2721993923187256e-01
    z[3,4,1]  R1036     4.0057358145713806e-01
    z[3,4,1]  R1037     4.7810387611389160e-01
    z[3,4,1]  R1038     5.6894439458847046e-01
    z[3,4,1]  R1039     -7.0877462625503540e-01
    z[3,4,1]  R1040     -3.9808529615402222e-01
    z[3,4,1]  R1041     -3.3675214648246765e-01
    z[3,4,1]  R1042     1.7925186082720757e-02
    z[3,4,1]  R1043     3.5206070542335510e-01
    z[3,4,1]  R1044     0.50312739610672
    z[3,4,1]  R1045     -4.9591645598411560e-01
    z[3,4,1]  R1046     0.0933518260717392
    z[3,4,1]  R1047     -2.0143432915210724e-01
    z[3,4,1]  R1048     -3.7276116013526917e-01
    z[3,4,1]  R1049     2.4780307710170746e-01
    z[3,4,1]  R1050     1.5220613777637482e-01
    z[3,4,1]  R1051     9.0704351663589478e-01
    z[3,4,1]  R1052     8.8989388942718506e-01
    z[3,4,1]  R1053     9.1480612754821777e-01
    z[3,4,1]  R1054     8.9418798685073853e-01
    z[3,4,1]  R1055     6.1804932355880737e-01
    z[3,4,1]  R1056     7.0757466554641724e-01
    z[3,4,1]  R1057     1.1783520132303238e-01
    z[3,4,1]  R1058     7.5609618425369263e-01
    z[3,4,1]  R1059     -2.7142059803009033e-01
    z[3,4,1]  R1060     2.2567722201347351e-01
    z[3,4,1]  R1061     1.3701331615447998e-01
    z[3,4,1]  R1062     3.0623498558998108e-01
    z[3,4,1]  R1063     1.4621399343013763e-01
    z[3,4,1]  R1064     9.1681569814682007e-01
    z[3,4,1]  R1065     0.743359386920929
    z[3,4,1]  R1066     7.9641348123550415e-01
    z[3,4,1]  R1067     7.5286239385604858e-01
    z[3,4,1]  R1068     5.7476663589477539e-01
    z[3,4,1]  R1069     6.2243533134460449e-01
    z[3,4,1]  R1070     8.3571928739547729e-01
    z[3,4,1]  R1071     8.1072479486465454e-01
    z[3,4,1]  R1072     6.7430537939071655e-01
    z[3,4,1]  R1073     6.6398453712463379e-01
    z[3,4,1]  R1074     3.8164768368005753e-02
    z[3,4,1]  R1075     -1.4380897395312786e-02
    z[3,4,1]  R1076     -1.4331623911857605e-02
    z[3,4,1]  R1077     1.4161263406276703e-01
    z[3,4,1]  R1078     7.4459767341613770e-01
    z[3,4,2]  R31       -1
    z[3,4,2]  R40       1
    z[3,4,2]  R981      -1
    z[3,4,2]  R982      1
    z[3,4,2]  R991      -2.0417949557304382e-01
    z[3,4,2]  R992      -3.4446725249290466e-01
    z[3,4,2]  R993      -3.3685794472694397e-01
    z[3,4,2]  R994      -1.9678533077239990e-02
    z[3,4,2]  R995      0.06800577044487
    z[3,4,2]  R996      1.6934520006179810e-01
    z[3,4,2]  R997      3.1749528646469116e-01
    z[3,4,2]  R998      -1.9265535473823547e-01
    z[3,4,2]  R999      -0.0784771665930748
    z[3,4,2]  R1000     -4.8448212444782257e-02
    z[3,4,2]  R1001     2.8500853106379509e-02
    z[3,4,2]  R1002     -1.5785014629364014e-01
    z[3,4,2]  R1003     -1.7656792700290680e-01
    z[3,4,2]  R1004     0.0232391320168972
    z[3,4,2]  R1005     -1.0151895135641098e-01
    z[3,4,2]  R1006     -2.4404411017894745e-01
    z[3,4,2]  R1007     -2.2070296108722687e-01
    z[3,4,2]  R1008     -4.8843196034431458e-01
    z[3,4,2]  R1009     -2.0805369317531586e-01
    z[3,4,2]  R1010     4.2685028165578842e-02
    z[3,4,2]  R1011     -1.9409951567649841e-01
    z[3,4,2]  R1012     -2.8021706268191338e-02
    z[3,4,2]  R1013     5.2486073225736618e-02
    z[3,4,2]  R1014     -7.9806774854660034e-02
    z[3,4,2]  R1015     -3.1840169429779053e-01
    z[3,4,2]  R1016     3.2039615511894226e-01
    z[3,4,2]  R1017     1.9184727966785431e-01
    z[3,4,2]  R1018     -3.2531636953353882e-01
    z[3,4,2]  R1019     1.9793011248111725e-01
    z[3,4,2]  R1020     1.3564078509807587e-01
    z[3,4,2]  R1021     2.3570168018341064e-01
    z[3,4,2]  R1022     1.5581017732620239e-01
    z[3,4,2]  R1023     1.4989016950130463e-01
    z[3,4,2]  R1024     -8.5404375568032265e-03
    z[3,4,2]  R1025     -1.2486571818590164e-01
    z[3,4,2]  R1026     -1.6090908646583557e-01
    z[3,4,2]  R1027     -5.5259462445974350e-02
    z[3,4,2]  R1028     2.4271681904792786e-01
    z[3,4,2]  R1029     -4.7414809465408325e-01
    z[3,4,2]  R1030     -8.2871162891387939e-01
    z[3,4,2]  R1031     1.4623082242906094e-02
    z[3,4,2]  R1032     -5.7248926162719727e-01
    z[3,4,2]  R1033     -3.7738669663667679e-02
    z[3,4,2]  R1034     -2.4280330538749695e-01
    z[3,4,2]  R1035     3.7362776696681976e-02
    z[3,4,2]  R1036     9.4783097505569458e-02
    z[3,4,2]  R1037     -1.2289097905158997e-01
    z[3,4,2]  R1038     -1.7647363245487213e-01
    z[3,4,2]  R1039     4.1203033924102783e-01
    z[3,4,2]  R1040     2.3994788527488708e-01
    z[3,4,2]  R1041     1.6720631718635559e-01
    z[3,4,2]  R1042     1.2837819755077362e-01
    z[3,4,2]  R1043     4.0040275454521179e-01
    z[3,4,2]  R1044     1.3345356285572052e-01
    z[3,4,2]  R1045     -3.3194657415151596e-02
    z[3,4,2]  R1046     2.5313520431518555e-01
    z[3,4,2]  R1047     -4.1206502914428711e-01
    z[3,4,2]  R1048     -1.8811488151550293e-01
    z[3,4,2]  R1049     7.2802215814590454e-01
    z[3,4,2]  R1050     0.571914792060852
    z[3,4,2]  R1051     1.5345154702663422e-01
    z[3,4,2]  R1052     -2.9085204005241394e-01
    z[3,4,2]  R1053     6.4979223534464836e-03
    z[3,4,2]  R1054     -3.2424005866050720e-01
    z[3,4,2]  R1055     -5.5171851068735123e-02
    z[3,4,2]  R1056     -1.0804910957813263e-01
    z[3,4,2]  R1057     -2.4583692848682404e-01
    z[3,4,2]  R1058     -1.6915802657604218e-01
    z[3,4,2]  R1059     -1.6012535989284515e-01
    z[3,4,2]  R1060     8.7762826681137085e-01
    z[3,4,2]  R1061     4.9203032255172729e-01
    z[3,4,2]  R1062     5.3925096988677979e-01
    z[3,4,2]  R1063     8.7598901987075806e-01
    z[3,4,2]  R1064     -3.3536902070045471e-01
    z[3,4,2]  R1065     -5.1727157086133957e-02
    z[3,4,2]  R1066     -9.1836132109165192e-02
    z[3,4,2]  R1067     5.6509021669626236e-02
    z[3,4,2]  R1068     1.4021563343703747e-02
    z[3,4,2]  R1069     -4.2121402919292450e-02
    z[3,4,2]  R1070     6.2648139894008636e-02
    z[3,4,2]  R1071     0.0945080816745758
    z[3,4,2]  R1072     -1.9648608565330505e-01
    z[3,4,2]  R1073     1.4892233535647392e-02
    z[3,4,2]  R1074     1.6314502060413361e-01
    z[3,4,2]  R1075     3.1280573457479477e-02
    z[3,4,2]  R1076     -7.9890981316566467e-02
    z[3,4,2]  R1077     2.4777954444289207e-02
    z[3,4,2]  R1078     -0.0759509950876236
    z[3,4,3]  R32       -1
    z[3,4,3]  R41       1
    z[3,4,3]  R983      -1
    z[3,4,3]  R984      1
    z[3,4,3]  R991      -2.9196754097938538e-01
    z[3,4,3]  R992      -7.9768812283873558e-03
    z[3,4,3]  R993      6.8975519388914108e-03
    z[3,4,3]  R994      -0.17877297103405
    z[3,4,3]  R995      6.6534203290939331e-01
    z[3,4,3]  R996      0.0673535093665123
    z[3,4,3]  R997      3.7388241291046143e-01
    z[3,4,3]  R998      4.7781109809875488e-01
    z[3,4,3]  R999      -1.6770860552787781e-01
    z[3,4,3]  R1000     -2.5062268972396851e-01
    z[3,4,3]  R1001     -7.1692460775375366e-01
    z[3,4,3]  R1002     1.8741454184055328e-01
    z[3,4,3]  R1003     -2.8977379202842712e-01
    z[3,4,3]  R1004     -8.4911346435546875e-02
    z[3,4,3]  R1005     -3.3067530393600464e-01
    z[3,4,3]  R1006     -1.3843837380409241e-01
    z[3,4,3]  R1007     -2.8861805796623230e-02
    z[3,4,3]  R1008     -2.5015437975525856e-02
    z[3,4,3]  R1009     5.0772500038146973e-01
    z[3,4,3]  R1010     6.3338494300842285e-01
    z[3,4,3]  R1011     -7.0545035600662231e-01
    z[3,4,3]  R1012     -1.1263841390609741e-01
    z[3,4,3]  R1013     -1.8007743358612061e-01
    z[3,4,3]  R1014     2.5668722391128540e-01
    z[3,4,3]  R1015     -1.8313533067703247e-01
    z[3,4,3]  R1016     -2.5241750478744507e-01
    z[3,4,3]  R1017     -2.4784231185913086e-01
    z[3,4,3]  R1018     3.5779255628585815e-01
    z[3,4,3]  R1019     0.0634353756904602
    z[3,4,3]  R1020     -2.4863202869892120e-01
    z[3,4,3]  R1021     -4.5533329248428345e-02
    z[3,4,3]  R1022     -6.9684617221355438e-02
    z[3,4,3]  R1023     0.764371395111084
    z[3,4,3]  R1024     0.745017409324646
    z[3,4,3]  R1025     -4.9989512562751770e-01
    z[3,4,3]  R1026     7.1240496635437012e-01
    z[3,4,3]  R1027     6.2345904111862183e-01
    z[3,4,3]  R1028     -2.2300015389919281e-01
    z[3,4,3]  R1029     9.4759769737720490e-02
    z[3,4,3]  R1030     9.6813887357711792e-02
    z[3,4,3]  R1031     8.2054913043975830e-02
    z[3,4,3]  R1032     -2.0222092047333717e-02
    z[3,4,3]  R1033     -1.4055344462394714e-01
    z[3,4,3]  R1034     1.3506911695003510e-01
    z[3,4,3]  R1035     1.6846060752868652e-01
    z[3,4,3]  R1036     -2.1175147965550423e-02
    z[3,4,3]  R1037     4.6630653738975525e-01
    z[3,4,3]  R1038     0.623343288898468
    z[3,4,3]  R1039     -1.3740181922912598e-01
    z[3,4,3]  R1040     -2.2141449153423309e-01
    z[3,4,3]  R1041     1.3829699158668518e-01
    z[3,4,3]  R1042     -7.6564550399780273e-01
    z[3,4,3]  R1043     1.7201645672321320e-01
    z[3,4,3]  R1044     -6.3344007730484009e-01
    z[3,4,3]  R1045     -0.415695458650589
    z[3,4,3]  R1046     3.7936963140964508e-02
    z[3,4,3]  R1047     -5.5727396160364151e-02
    z[3,4,3]  R1048     8.7636536359786987e-01
    z[3,4,3]  R1049     -4.5097228884696960e-01
    z[3,4,3]  R1050     2.6321390271186829e-01
    z[3,4,3]  R1051     5.3094297647476196e-02
    z[3,4,3]  R1052     1.1101468652486801e-01
    z[3,4,3]  R1053     2.6173036545515060e-02
    z[3,4,3]  R1054     9.6922911703586578e-02
    z[3,4,3]  R1055     3.5951477289199829e-01
    z[3,4,3]  R1056     4.6084529161453247e-01
    z[3,4,3]  R1057     2.0157489180564880e-01
    z[3,4,3]  R1058     1.5019841492176056e-01
    z[3,4,3]  R1059     -4.6264287829399109e-01
    z[3,4,3]  R1060     -1.3778880238533020e-03
    z[3,4,3]  R1061     4.8098187893629074e-02
    z[3,4,3]  R1062     -5.7226948440074921e-02
    z[3,4,3]  R1063     -9.2000365257263184e-02
    z[3,4,3]  R1064     4.1226636618375778e-02
    z[3,4,3]  R1065     3.9620363712310791e-01
    z[3,4,3]  R1066     -4.6701491810381413e-03
    z[3,4,3]  R1067     2.9443684220314026e-01
    z[3,4,3]  R1068     6.2322062253952026e-01
    z[3,4,3]  R1069     4.3258953094482422e-01
    z[3,4,3]  R1070     4.1657385230064392e-01
    z[3,4,3]  R1071     -7.4566014111042023e-02
    z[3,4,3]  R1072     4.5363315939903259e-01
    z[3,4,3]  R1073     -1.3361506164073944e-01
    z[3,4,3]  R1074     7.1216380596160889e-01
    z[3,4,3]  R1075     0.600469172000885
    z[3,4,3]  R1076     7.9959535598754883e-01
    z[3,4,3]  R1077     7.2746020555496216e-01
    z[3,4,3]  R1078     2.0860774442553520e-02
    z[3,4,4]  R33       -1
    z[3,4,4]  R42       1
    z[3,4,4]  R985      -1
    z[3,4,4]  R986      1
    z[3,4,4]  R991      2.2628886997699738e-01
    z[3,4,4]  R992      -2.6916259527206421e-01
    z[3,4,4]  R993      2.8445419669151306e-01
    z[3,4,4]  R994      -1.6582595184445381e-02
    z[3,4,4]  R995      6.2523297965526581e-03
    z[3,4,4]  R996      4.3712127208709717e-01
    z[3,4,4]  R997      7.6559692621231079e-02
    z[3,4,4]  R998      -6.3483619689941406e-01
    z[3,4,4]  R999      -7.7163302898406982e-01
    z[3,4,4]  R1000     -5.2388721704483032e-01
    z[3,4,4]  R1001     2.4067023769021034e-03
    z[3,4,4]  R1002     0.0366709902882576
    z[3,4,4]  R1003     4.2248047888278961e-02
    z[3,4,4]  R1004     -7.0286847651004791e-02
    z[3,4,4]  R1005     2.3987520486116409e-02
    z[3,4,4]  R1006     4.4759169220924377e-01
    z[3,4,4]  R1007     -3.4284293651580811e-01
    z[3,4,4]  R1008     8.7679319083690643e-02
    z[3,4,4]  R1009     8.8047936558723450e-02
    z[3,4,4]  R1010     1.4458252489566803e-01
    z[3,4,4]  R1011     6.2738835811614990e-02
    z[3,4,4]  R1012     2.5824561715126038e-01
    z[3,4,4]  R1013     3.1630176305770874e-01
    z[3,4,4]  R1014     1.7364698648452759e-01
    z[3,4,4]  R1015     -1.5740180015563965e-01
    z[3,4,4]  R1016     2.8242337703704834e-01
    z[3,4,4]  R1017     -0.374988853931427
    z[3,4,4]  R1018     -1.2066390365362167e-01
    z[3,4,4]  R1019     7.7609471976757050e-02
    z[3,4,4]  R1020     2.2041009366512299e-01
    z[3,4,4]  R1021     4.9515865743160248e-02
    z[3,4,4]  R1022     1.8371193110942841e-01
    z[3,4,4]  R1023     -9.0807870030403137e-02
    z[3,4,4]  R1024     0.341768354177475
    z[3,4,4]  R1025     -5.2788305282592773e-01
    z[3,4,4]  R1026     -2.6208034157752991e-01
    z[3,4,4]  R1027     -4.8843666911125183e-01
    z[3,4,4]  R1028     1.4653810858726501e-01
    z[3,4,4]  R1029     -6.7960780858993530e-01
    z[3,4,4]  R1030     -1.3993211090564728e-01
    z[3,4,4]  R1031     -2.9488596320152283e-01
    z[3,4,4]  R1032     7.0823854207992554e-01
    z[3,4,4]  R1033     6.7547351121902466e-01
    z[3,4,4]  R1034     2.6978189125657082e-02
    z[3,4,4]  R1035     -1.2629888951778412e-01
    z[3,4,4]  R1036     -4.1531139612197876e-01
    z[3,4,4]  R1037     1.1978959292173386e-01
    z[3,4,4]  R1038     1.2435131520032883e-01
    z[3,4,4]  R1039     4.9273487180471420e-02
    z[3,4,4]  R1040     1.8249136209487915e-01
    z[3,4,4]  R1041     5.3202575445175171e-01
    z[3,4,4]  R1042     5.2533334493637085e-01
    z[3,4,4]  R1043     9.3137837946414948e-02
    z[3,4,4]  R1044     8.3275333046913147e-02
    z[3,4,4]  R1045     1.3587783277034760e-01
    z[3,4,4]  R1046     5.7541990280151367e-01
    z[3,4,4]  R1047     1.7288066446781158e-01
    z[3,4,4]  R1048     -1.4637543819844723e-02
    z[3,4,4]  R1049     -5.5954560637474060e-02
    z[3,4,4]  R1050     -3.6770024895668030e-01
    z[3,4,4]  R1051     -1.8873862922191620e-01
    z[3,4,4]  R1052     2.2558660805225372e-01
    z[3,4,4]  R1053     -8.2657516002655029e-02
    z[3,4,4]  R1054     -9.6800431609153748e-02
    z[3,4,4]  R1055     -1.6078034043312073e-01
    z[3,4,4]  R1056     -1.9464877247810364e-01
    z[3,4,4]  R1057     -4.1220435500144958e-01
    z[3,4,4]  R1058     2.9235166311264038e-01
    z[3,4,4]  R1059     8.0781751871109009e-01
    z[3,4,4]  R1060     1.1478152871131897e-01
    z[3,4,4]  R1061     4.2002722620964050e-01
    z[3,4,4]  R1062     4.8885148763656616e-01
    z[3,4,4]  R1063     -1.6488823294639587e-01
    z[3,4,4]  R1064     1.3348235189914703e-01
    z[3,4,4]  R1065     -1.6731470823287964e-01
    z[3,4,4]  R1066     1.3335452415049076e-02
    z[3,4,4]  R1067     2.2520011663436890e-01
    z[3,4,4]  R1068     -7.5253896415233612e-02
    z[3,4,4]  R1069     3.9314761757850647e-02
    z[3,4,4]  R1070     1.0867656767368317e-01
    z[3,4,4]  R1071     -2.3046325147151947e-01
    z[3,4,4]  R1072     -1.1870503425598145e-01
    z[3,4,4]  R1073     -1.5901979058980942e-02
    z[3,4,4]  R1074     7.6755732297897339e-02
    z[3,4,4]  R1075     9.0735845267772675e-02
    z[3,4,4]  R1076     -0.0392913781106472
    z[3,4,4]  R1077     6.7949362099170685e-02
    z[3,4,4]  R1078     -4.0598297119140625e-01
    z[3,4,5]  R34       -1
    z[3,4,5]  R43       1
    z[3,4,5]  R987      -1
    z[3,4,5]  R988      1
    z[3,4,5]  R991      -6.0272864997386932e-02
    z[3,4,5]  R992      5.2378200925886631e-03
    z[3,4,5]  R993      -2.4463790655136108e-01
    z[3,4,5]  R994      5.4991978406906128e-01
    z[3,4,5]  R995      7.6349325478076935e-02
    z[3,4,5]  R996      6.2419414520263672e-01
    z[3,4,5]  R997      9.5532253384590149e-02
    z[3,4,5]  R998      -2.0367403328418732e-01
    z[3,4,5]  R999      -1.3126057386398315e-01
    z[3,4,5]  R1000     -9.7383596003055573e-03
    z[3,4,5]  R1001     -2.2481042146682739e-01
    z[3,4,5]  R1002     -2.5774425268173218e-01
    z[3,4,5]  R1003     -1.6966257989406586e-01
    z[3,4,5]  R1004     -0.244800865650177
    z[3,4,5]  R1005     3.4857827425003052e-01
    z[3,4,5]  R1006     -1.6361238434910774e-02
    z[3,4,5]  R1007     -1.2094871699810028e-01
    z[3,4,5]  R1008     2.1043597161769867e-01
    z[3,4,5]  R1009     3.9162391424179077e-01
    z[3,4,5]  R1010     -1.0682401806116104e-01
    z[3,4,5]  R1011     -1.7073659598827362e-01
    z[3,4,5]  R1012     1.2148747593164444e-01
    z[3,4,5]  R1013     1.3128049671649933e-01
    z[3,4,5]  R1014     2.2975887358188629e-01
    z[3,4,5]  R1015     5.1292762160301208e-02
    z[3,4,5]  R1016     5.4597463458776474e-02
    z[3,4,5]  R1017     1.5197399258613586e-01
    z[3,4,5]  R1018     -1.5045249462127686e-01
    z[3,4,5]  R1019     1.0198665410280228e-01
    z[3,4,5]  R1020     -3.8891077041625977e-01
    z[3,4,5]  R1021     1.7021405696868896e-01
    z[3,4,5]  R1022     -0.256853312253952
    z[3,4,5]  R1023     2.6179185137152672e-02
    z[3,4,5]  R1024     -3.5139527916908264e-01
    z[3,4,5]  R1025     1.7495891451835632e-01
    z[3,4,5]  R1026     -1.4328850805759430e-01
    z[3,4,5]  R1027     2.0163874328136444e-01
    z[3,4,5]  R1028     1.7113395035266876e-01
    z[3,4,5]  R1029     0.0559404082596302
    z[3,4,5]  R1030     2.8066992759704590e-01
    z[3,4,5]  R1031     8.0574375391006470e-01
    z[3,4,5]  R1032     2.9041644930839539e-01
    z[3,4,5]  R1033     -1.9368024542927742e-02
    z[3,4,5]  R1034     1.7122475430369377e-02
    z[3,4,5]  R1035     5.5484312772750854e-01
    z[3,4,5]  R1036     1.7156814038753510e-01
    z[3,4,5]  R1037     6.0017108917236328e-01
    z[3,4,5]  R1038     3.5948729515075684e-01
    z[3,4,5]  R1039     -1.2933203834109008e-04
    z[3,4,5]  R1040     -5.3700095415115356e-01
    z[3,4,5]  R1041     -6.5760958194732666e-01
    z[3,4,5]  R1042     -2.5490492582321167e-01
    z[3,4,5]  R1043     -7.4669677019119263e-01
    z[3,4,5]  R1044     -0.489662230014801
    z[3,4,5]  R1045     -5.2383244037628174e-01
    z[3,4,5]  R1046     -4.6987172961235046e-01
    z[3,4,5]  R1047     -8.0954384803771973e-01
    z[3,4,5]  R1048     -6.7603783681988716e-03
    z[3,4,5]  R1049     3.9236697554588318e-01
    z[3,4,5]  R1050     -4.5929306745529175e-01
    z[3,4,5]  R1051     2.7570620179176331e-01
    z[3,4,5]  R1052     1.7076404392719269e-01
    z[3,4,5]  R1053     2.8928220272064209e-02
    z[3,4,5]  R1054     2.1675245463848114e-01
    z[3,4,5]  R1055     5.6372302770614624e-01
    z[3,4,5]  R1056     4.2820256948471069e-01
    z[3,4,5]  R1057     -4.8932361602783203e-01
    z[3,4,5]  R1058     1.4396293461322784e-01
    z[3,4,5]  R1059     -1.4416243135929108e-01
    z[3,4,5]  R1060     -0.0305878184735775
    z[3,4,5]  R1061     -3.7809950113296509e-01
    z[3,4,5]  R1062     1.3094292581081390e-01
    z[3,4,5]  R1063     -1.4991295337677002e-01
    z[3,4,5]  R1064     7.3057748377323151e-02
    z[3,4,5]  R1065     2.5748360157012939e-01
    z[3,4,5]  R1066     5.9070986509323120e-01
    z[3,4,5]  R1067     4.3190208077430725e-01
    z[3,4,5]  R1068     4.8718398809432983e-01
    z[3,4,5]  R1069     0.637184202671051
    z[3,4,5]  R1070     1.9008395075798035e-01
    z[3,4,5]  R1071     4.2423000931739807e-01
    z[3,4,5]  R1072     3.0134943127632141e-01
    z[3,4,5]  R1073     4.0979641675949097e-01
    z[3,4,5]  R1074     6.4152711629867554e-01
    z[3,4,5]  R1075     7.5302320718765259e-01
    z[3,4,5]  R1076     5.5047595500946045e-01
    z[3,4,5]  R1077     5.6913548707962036e-01
    z[3,4,5]  R1078     -3.3383011817932129e-02
    z[3,4,6]  R35       -1
    z[3,4,6]  R44       1
    z[3,4,6]  R989      -1
    z[3,4,6]  R990      1
    z[3,4,6]  R991      2.3065450787544250e-01
    z[3,4,6]  R992      -2.2433733940124512e-01
    z[3,4,6]  R993      9.5027135685086250e-03
    z[3,4,6]  R994      -3.0451586842536926e-01
    z[3,4,6]  R995      4.0011522173881531e-01
    z[3,4,6]  R996      -9.0896666049957275e-02
    z[3,4,6]  R997      4.7414788603782654e-01
    z[3,4,6]  R998      3.8322679698467255e-02
    z[3,4,6]  R999      9.8887398838996887e-02
    z[3,4,6]  R1000     5.5091398954391479e-01
    z[3,4,6]  R1001     -3.1023567914962769e-01
    z[3,4,6]  R1002     -2.6245719194412231e-01
    z[3,4,6]  R1003     -3.0436590313911438e-01
    z[3,4,6]  R1004     -4.6823951601982117e-01
    z[3,4,6]  R1005     -2.9056310653686523e-01
    z[3,4,6]  R1006     -2.0337577164173126e-01
    z[3,4,6]  R1007     2.0055323839187622e-01
    z[3,4,6]  R1008     9.4782322645187378e-02
    z[3,4,6]  R1009     -2.7302485704421997e-01
    z[3,4,6]  R1010     -7.0345097780227661e-01
    z[3,4,6]  R1011     -0.365187406539917
    z[3,4,6]  R1012     2.4529822170734406e-01
    z[3,4,6]  R1013     -1.5396726131439209e-01
    z[3,4,6]  R1014     1.1342352628707886e-01
    z[3,4,6]  R1015     1.6710974276065826e-01
    z[3,4,6]  R1016     1.0853295773267746e-01
    z[3,4,6]  R1017     0.0305503997951746
    z[3,4,6]  R1018     8.9628294110298157e-02
    z[3,4,6]  R1019     1.7342561483383179e-01
    z[3,4,6]  R1020     2.1724744141101837e-01
    z[3,4,6]  R1021     -2.5142121315002441e-01
    z[3,4,6]  R1022     3.6345383524894714e-01
    z[3,4,6]  R1023     -3.0564209818840027e-01
    z[3,4,6]  R1024     4.7692552208900452e-02
    z[3,4,6]  R1025     5.6257343292236328e-01
    z[3,4,6]  R1026     0.313156396150589
    z[3,4,6]  R1027     2.4942032992839813e-01
    z[3,4,6]  R1028     -5.1320254802703857e-01
    z[3,4,6]  R1029     3.3664533495903015e-01
    z[3,4,6]  R1030     2.3573417961597443e-01
    z[3,4,6]  R1031     4.4084972143173218e-01
    z[3,4,6]  R1032     -9.0215429663658142e-02
    z[3,4,6]  R1033     3.9096099138259888e-01
    z[3,4,6]  R1034     3.4627810120582581e-01
    z[3,4,6]  R1035     1.8580521643161774e-01
    z[3,4,6]  R1036     4.1898670792579651e-01
    z[3,4,6]  R1037     -2.6931622624397278e-01
    z[3,4,6]  R1038     -1.6151136159896851e-01
    z[3,4,6]  R1039     -1.4734691381454468e-01
    z[3,4,6]  R1040     5.0750488042831421e-01
    z[3,4,6]  R1041     2.4365903437137604e-01
    z[3,4,6]  R1042     1.8402788043022156e-01
    z[3,4,6]  R1043     1.2230180203914642e-01
    z[3,4,6]  R1044     2.5534853339195251e-01
    z[3,4,6]  R1045     4.9820411205291748e-01
    z[3,4,6]  R1046     -5.8697527647018433e-01
    z[3,4,6]  R1047     -2.2447204589843750e-01
    z[3,4,6]  R1048     -1.5371930599212646e-01
    z[3,4,6]  R1049     2.1896651387214661e-01
    z[3,4,6]  R1050     -4.8337876796722412e-01
    z[3,4,6]  R1051     -4.9422928132116795e-03
    z[3,4,6]  R1052     -1.7492248117923737e-01
    z[3,4,6]  R1053     -0.311410129070282
    z[3,4,6]  R1054     -1.0314693674445152e-02
    z[3,4,6]  R1055     -2.7174046263098717e-02
    z[3,4,6]  R1056     7.0586074143648148e-03
    z[3,4,6]  R1057     1.6405366361141205e-01
    z[3,4,6]  R1058     -3.8203904032707214e-01
    z[3,4,6]  R1059     -5.4438419640064240e-02
    z[3,4,6]  R1060     3.2419890165328979e-01
    z[3,4,6]  R1061     -6.2903493642807007e-01
    z[3,4,6]  R1062     5.0851851701736450e-01
    z[3,4,6]  R1063     -9.3386769294738770e-02
    z[3,4,6]  R1064     -1.1720818281173706e-01
    z[3,4,6]  R1065     2.2354254126548767e-01
    z[3,4,6]  R1066     -1.8927467986941338e-02
    z[3,4,6]  R1067     -2.4369551241397858e-01
    z[3,4,6]  R1068     1.8381108343601227e-01
    z[3,4,6]  R1069     -8.8346116244792938e-02
    z[3,4,6]  R1070     -2.7376693487167358e-01
    z[3,4,6]  R1071     -2.8332561254501343e-01
    z[3,4,6]  R1072     -3.3860078454017639e-01
    z[3,4,6]  R1073     -0.162612646818161
    z[3,4,6]  R1074     -1.3697418570518494e-01
    z[3,4,6]  R1075     -2.4773661792278290e-01
    z[3,4,6]  R1076     -2.1843566000461578e-01
    z[3,4,6]  R1077     -2.4833329021930695e-01
    z[3,4,6]  R1078     -4.3179315328598022e-01
    z[4,3,0]  R29       1
    z[4,3,0]  R38       -1
    z[4,3,0]  R1079     -1
    z[4,3,0]  R1080     1
    z[4,3,0]  R1093     4.1285350918769836e-01
    z[4,3,0]  R1094     3.8448178768157959e-01
    z[4,3,0]  R1095     1.1995550245046616e-01
    z[4,3,0]  R1096     2.0959652960300446e-01
    z[4,3,0]  R1097     6.0748201608657837e-01
    z[4,3,0]  R1098     4.7497734427452087e-01
    z[4,3,0]  R1099     2.8818449378013611e-01
    z[4,3,0]  R1100     -6.7278486490249634e-01
    z[4,3,0]  R1101     3.0296313762664795e-01
    z[4,3,0]  R1102     2.9295399785041809e-01
    z[4,3,0]  R1103     5.3371459245681763e-01
    z[4,3,0]  R1104     -3.9458143711090088e-01
    z[4,3,0]  R1105     -2.5424867868423462e-01
    z[4,3,0]  R1106     -1.4888504147529602e-01
    z[4,3,0]  R1107     3.2396411895751953e-01
    z[4,3,0]  R1108     1.2609507143497467e-01
    z[4,3,0]  R1109     -1.9771598279476166e-01
    z[4,3,0]  R1110     -1.7129307985305786e-01
    z[4,3,0]  R1111     2.2557590901851654e-01
    z[4,3,0]  R1112     -1.8372812867164612e-01
    z[4,3,0]  R1113     -1.3125183992087841e-02
    z[4,3,0]  R1114     -2.5624418631196022e-02
    z[4,3,0]  R1115     -1.9810365140438080e-01
    z[4,3,0]  R1116     -2.2849960252642632e-02
    z[4,3,0]  R1117     -2.4032703042030334e-01
    z[4,3,0]  R1118     -1.7159251868724823e-01
    z[4,3,0]  R1119     3.7596255540847778e-01
    z[4,3,0]  R1120     -2.3235681653022766e-01
    z[4,3,0]  R1121     -6.6991263628005981e-01
    z[4,3,0]  R1122     3.5354757308959961e-01
    z[4,3,0]  R1123     1.0167054831981659e-01
    z[4,3,0]  R1124     -2.4417449533939362e-01
    z[4,3,0]  R1125     -1.4748911559581757e-01
    z[4,3,0]  R1126     3.1215512752532959e-01
    z[4,3,0]  R1127     -3.8002294301986694e-01
    z[4,3,0]  R1128     0.0915653184056282
    z[4,3,0]  R1129     0.378814697265625
    z[4,3,0]  R1130     8.8293008506298065e-02
    z[4,3,0]  R1131     2.1603241562843323e-01
    z[4,3,0]  R1132     6.5152287483215332e-02
    z[4,3,0]  R1133     9.1169491410255432e-02
    z[4,3,0]  R1134     3.4985087811946869e-02
    z[4,3,0]  R1135     1.2196503579616547e-01
    z[4,3,0]  R1136     2.8525349497795105e-01
    z[4,3,0]  R1137     5.8857542276382446e-01
    z[4,3,0]  R1138     1.6893598437309265e-01
    z[4,3,0]  R1139     0.0400143563747406
    z[4,3,0]  R1140     4.2162124067544937e-02
    z[4,3,0]  R1141     -2.4480982124805450e-01
    z[4,3,0]  R1142     2.9493844509124756e-01
    z[4,3,0]  R1143     -6.5310436487197876e-01
    z[4,3,0]  R1144     -7.3012202978134155e-01
    z[4,3,0]  R1145     -8.1839954853057861e-01
    z[4,3,0]  R1146     -7.1401822566986084e-01
    z[4,3,0]  R1147     0.153198704123497
    z[4,3,0]  R1148     -6.0081088542938232e-01
    z[4,3,0]  R1149     7.1688795089721680e-01
    z[4,3,0]  R1150     2.3340252041816711e-01
    z[4,3,0]  R1151     4.9905306100845337e-01
    z[4,3,0]  R1152     2.5812390446662903e-01
    z[4,3,0]  R1153     2.7214249968528748e-01
    z[4,3,0]  R1154     0.531776487827301
    z[4,3,0]  R1155     5.4017448425292969e-01
    z[4,3,0]  R1156     3.8133546710014343e-01
    z[4,3,0]  R1157     5.2057379484176636e-01
    z[4,3,0]  R1158     5.9864956140518188e-01
    z[4,3,0]  R1159     0.365446001291275
    z[4,3,0]  R1160     5.5695241689682007e-01
    z[4,3,0]  R1161     2.8284192085266113e-01
    z[4,3,0]  R1162     1.7235065996646881e-01
    z[4,3,0]  R1163     -4.2859369516372681e-01
    z[4,3,0]  R1164     5.8471912145614624e-01
    z[4,3,0]  R1165     0.627866804599762
    z[4,3,0]  R1166     6.2033843994140625e-01
    z[4,3,0]  R1167     5.3637397289276123e-01
    z[4,3,0]  R1168     5.6048560142517090e-01
    z[4,3,0]  R1169     5.8017802238464355e-01
    z[4,3,0]  R1170     6.1862134933471680e-01
    z[4,3,0]  R1171     3.5152587294578552e-01
    z[4,3,0]  R1172     6.4129203557968140e-01
    z[4,3,0]  R1173     4.6803352236747742e-01
    z[4,3,0]  R1174     5.8159804344177246e-01
    z[4,3,0]  R1175     4.9010065197944641e-01
    z[4,3,0]  R1176     2.0241326093673706e-01
    z[4,3,0]  R1177     -0.188896045088768
    z[4,3,0]  R1178     -9.8122563213109970e-03
    z[4,3,0]  R1179     0.0203165952116251
    z[4,3,0]  R1180     3.1710234284400940e-01
    z[4,3,1]  R30       1
    z[4,3,1]  R39       -1
    z[4,3,1]  R1081     -1
    z[4,3,1]  R1082     1
    z[4,3,1]  R1093     -1.3202236592769623e-01
    z[4,3,1]  R1094     -4.5940056443214417e-02
    z[4,3,1]  R1095     -2.1939606964588165e-01
    z[4,3,1]  R1096     -1.8394032120704651e-01
    z[4,3,1]  R1097     1.7205059528350830e-02
    z[4,3,1]  R1098     7.5912439823150635e-01
    z[4,3,1]  R1099     7.2721993923187256e-01
    z[4,3,1]  R1100     4.0057358145713806e-01
    z[4,3,1]  R1101     4.7810387611389160e-01
    z[4,3,1]  R1102     5.6894439458847046e-01
    z[4,3,1]  R1103     -7.0877462625503540e-01
    z[4,3,1]  R1104     -3.9808529615402222e-01
    z[4,3,1]  R1105     -3.3675214648246765e-01
    z[4,3,1]  R1106     1.7925186082720757e-02
    z[4,3,1]  R1107     3.5206070542335510e-01
    z[4,3,1]  R1108     0.50312739610672
    z[4,3,1]  R1109     -4.9591645598411560e-01
    z[4,3,1]  R1110     0.0933518260717392
    z[4,3,1]  R1111     -2.0143432915210724e-01
    z[4,3,1]  R1112     -3.7276116013526917e-01
    z[4,3,1]  R1113     2.4780307710170746e-01
    z[4,3,1]  R1114     1.5220613777637482e-01
    z[4,3,1]  R1115     9.0704351663589478e-01
    z[4,3,1]  R1116     8.8989388942718506e-01
    z[4,3,1]  R1117     9.1480612754821777e-01
    z[4,3,1]  R1118     8.9418798685073853e-01
    z[4,3,1]  R1119     6.1804932355880737e-01
    z[4,3,1]  R1120     7.0757466554641724e-01
    z[4,3,1]  R1121     1.1783520132303238e-01
    z[4,3,1]  R1122     7.5609618425369263e-01
    z[4,3,1]  R1123     -2.7142059803009033e-01
    z[4,3,1]  R1124     2.2567722201347351e-01
    z[4,3,1]  R1125     1.3701331615447998e-01
    z[4,3,1]  R1126     3.0623498558998108e-01
    z[4,3,1]  R1127     1.4621399343013763e-01
    z[4,3,1]  R1128     9.1681569814682007e-01
    z[4,3,1]  R1129     0.743359386920929
    z[4,3,1]  R1130     7.9641348123550415e-01
    z[4,3,1]  R1131     7.5286239385604858e-01
    z[4,3,1]  R1132     5.7476663589477539e-01
    z[4,3,1]  R1133     6.2243533134460449e-01
    z[4,3,1]  R1134     8.3571928739547729e-01
    z[4,3,1]  R1135     8.1072479486465454e-01
    z[4,3,1]  R1136     6.7430537939071655e-01
    z[4,3,1]  R1137     6.6398453712463379e-01
    z[4,3,1]  R1138     3.8164768368005753e-02
    z[4,3,1]  R1139     -1.4380897395312786e-02
    z[4,3,1]  R1140     -1.4331623911857605e-02
    z[4,3,1]  R1141     1.4161263406276703e-01
    z[4,3,1]  R1142     7.4459767341613770e-01
    z[4,3,1]  R1143     5.8178991079330444e-01
    z[4,3,1]  R1144     4.7476023435592651e-01
    z[4,3,1]  R1145     -2.7540719509124756e-01
    z[4,3,1]  R1146     -2.4982862174510956e-01
    z[4,3,1]  R1147     6.0271453857421875e-01
    z[4,3,1]  R1148     1.2983238697052002e-01
    z[4,3,1]  R1149     -7.5340755283832550e-02
    z[4,3,1]  R1150     4.8387479782104492e-01
    z[4,3,1]  R1151     3.0697804689407349e-01
    z[4,3,1]  R1152     5.3865957260131836e-01
    z[4,3,1]  R1153     -5.1415318250656128e-01
    z[4,3,1]  R1154     -7.2146528959274292e-01
    z[4,3,1]  R1155     -6.8546158075332642e-01
    z[4,3,1]  R1156     -7.5014483928680420e-01
    z[4,3,1]  R1157     -6.3469791412353516e-01
    z[4,3,1]  R1158     -5.6650543212890625e-01
    z[4,3,1]  R1159     -8.0281686782836914e-01
    z[4,3,1]  R1160     -6.2422585487365723e-01
    z[4,3,1]  R1161     -6.1908406019210815e-01
    z[4,3,1]  R1162     -2.0034465193748474e-01
    z[4,3,1]  R1163     -3.3841341733932495e-01
    z[4,3,1]  R1164     -7.0923173427581787e-01
    z[4,3,1]  R1165     -6.5544891357421875e-01
    z[4,3,1]  R1166     -6.6866677999496460e-01
    z[4,3,1]  R1167     -7.2253215312957764e-01
    z[4,3,1]  R1168     -0.651892900466919
    z[4,3,1]  R1169     -6.3286352157592773e-01
    z[4,3,1]  R1170     -5.8157765865325928e-01
    z[4,3,1]  R1171     -0.886976957321167
    z[4,3,1]  R1172     -5.1137030124664307e-01
    z[4,3,1]  R1173     -7.9289269447326660e-01
    z[4,3,1]  R1174     -6.3307863473892212e-01
    z[4,3,1]  R1175     -2.2521585226058960e-01
    z[4,3,1]  R1176     -4.0167921781539917e-01
    z[4,3,1]  R1177     -2.7031752467155457e-01
    z[4,3,1]  R1178     -5.2839994430541992e-01
    z[4,3,1]  R1179     -5.1613306999206543e-01
    z[4,3,1]  R1180     6.9041180610656738e-01
    z[4,3,2]  R31       1
    z[4,3,2]  R40       -1
    z[4,3,2]  R1083     -1
    z[4,3,2]  R1084     1
    z[4,3,2]  R1093     -4.7414809465408325e-01
    z[4,3,2]  R1094     -8.2871162891387939e-01
    z[4,3,2]  R1095     1.4623082242906094e-02
    z[4,3,2]  R1096     -5.7248926162719727e-01
    z[4,3,2]  R1097     -3.7738669663667679e-02
    z[4,3,2]  R1098     -2.4280330538749695e-01
    z[4,3,2]  R1099     3.7362776696681976e-02
    z[4,3,2]  R1100     9.4783097505569458e-02
    z[4,3,2]  R1101     -1.2289097905158997e-01
    z[4,3,2]  R1102     -1.7647363245487213e-01
    z[4,3,2]  R1103     4.1203033924102783e-01
    z[4,3,2]  R1104     2.3994788527488708e-01
    z[4,3,2]  R1105     1.6720631718635559e-01
    z[4,3,2]  R1106     1.2837819755077362e-01
    z[4,3,2]  R1107     4.0040275454521179e-01
    z[4,3,2]  R1108     1.3345356285572052e-01
    z[4,3,2]  R1109     -3.3194657415151596e-02
    z[4,3,2]  R1110     2.5313520431518555e-01
    z[4,3,2]  R1111     -4.1206502914428711e-01
    z[4,3,2]  R1112     -1.8811488151550293e-01
    z[4,3,2]  R1113     7.2802215814590454e-01
    z[4,3,2]  R1114     0.571914792060852
    z[4,3,2]  R1115     1.5345154702663422e-01
    z[4,3,2]  R1116     -2.9085204005241394e-01
    z[4,3,2]  R1117     6.4979223534464836e-03
    z[4,3,2]  R1118     -3.2424005866050720e-01
    z[4,3,2]  R1119     -5.5171851068735123e-02
    z[4,3,2]  R1120     -1.0804910957813263e-01
    z[4,3,2]  R1121     -2.4583692848682404e-01
    z[4,3,2]  R1122     -1.6915802657604218e-01
    z[4,3,2]  R1123     -1.6012535989284515e-01
    z[4,3,2]  R1124     8.7762826681137085e-01
    z[4,3,2]  R1125     4.9203032255172729e-01
    z[4,3,2]  R1126     5.3925096988677979e-01
    z[4,3,2]  R1127     8.7598901987075806e-01
    z[4,3,2]  R1128     -3.3536902070045471e-01
    z[4,3,2]  R1129     -5.1727157086133957e-02
    z[4,3,2]  R1130     -9.1836132109165192e-02
    z[4,3,2]  R1131     5.6509021669626236e-02
    z[4,3,2]  R1132     1.4021563343703747e-02
    z[4,3,2]  R1133     -4.2121402919292450e-02
    z[4,3,2]  R1134     6.2648139894008636e-02
    z[4,3,2]  R1135     0.0945080816745758
    z[4,3,2]  R1136     -1.9648608565330505e-01
    z[4,3,2]  R1137     1.4892233535647392e-02
    z[4,3,2]  R1138     1.6314502060413361e-01
    z[4,3,2]  R1139     3.1280573457479477e-02
    z[4,3,2]  R1140     -7.9890981316566467e-02
    z[4,3,2]  R1141     2.4777954444289207e-02
    z[4,3,2]  R1142     -0.0759509950876236
    z[4,3,2]  R1143     -2.0417949557304382e-01
    z[4,3,2]  R1144     -3.4446725249290466e-01
    z[4,3,2]  R1145     -3.3685794472694397e-01
    z[4,3,2]  R1146     -1.9678533077239990e-02
    z[4,3,2]  R1147     0.06800577044487
    z[4,3,2]  R1148     1.6934520006179810e-01
    z[4,3,2]  R1149     3.1749528646469116e-01
    z[4,3,2]  R1150     -1.9265535473823547e-01
    z[4,3,2]  R1151     -0.0784771665930748
    z[4,3,2]  R1152     -4.8448212444782257e-02
    z[4,3,2]  R1153     2.8500853106379509e-02
    z[4,3,2]  R1154     -1.5785014629364014e-01
    z[4,3,2]  R1155     -1.7656792700290680e-01
    z[4,3,2]  R1156     0.0232391320168972
    z[4,3,2]  R1157     -1.0151895135641098e-01
    z[4,3,2]  R1158     -2.4404411017894745e-01
    z[4,3,2]  R1159     -2.2070296108722687e-01
    z[4,3,2]  R1160     -4.8843196034431458e-01
    z[4,3,2]  R1161     -2.0805369317531586e-01
    z[4,3,2]  R1162     4.2685028165578842e-02
    z[4,3,2]  R1163     -1.9409951567649841e-01
    z[4,3,2]  R1164     -2.8021706268191338e-02
    z[4,3,2]  R1165     5.2486073225736618e-02
    z[4,3,2]  R1166     -7.9806774854660034e-02
    z[4,3,2]  R1167     -3.1840169429779053e-01
    z[4,3,2]  R1168     3.2039615511894226e-01
    z[4,3,2]  R1169     1.9184727966785431e-01
    z[4,3,2]  R1170     -3.2531636953353882e-01
    z[4,3,2]  R1171     1.9793011248111725e-01
    z[4,3,2]  R1172     1.3564078509807587e-01
    z[4,3,2]  R1173     2.3570168018341064e-01
    z[4,3,2]  R1174     1.5581017732620239e-01
    z[4,3,2]  R1175     1.4989016950130463e-01
    z[4,3,2]  R1176     -8.5404375568032265e-03
    z[4,3,2]  R1177     -1.2486571818590164e-01
    z[4,3,2]  R1178     -1.6090908646583557e-01
    z[4,3,2]  R1179     -5.5259462445974350e-02
    z[4,3,2]  R1180     2.4271681904792786e-01
    z[4,3,3]  R32       1
    z[4,3,3]  R41       -1
    z[4,3,3]  R1085     -1
    z[4,3,3]  R1086     1
    z[4,3,3]  R1093     9.4759769737720490e-02
    z[4,3,3]  R1094     9.6813887357711792e-02
    z[4,3,3]  R1095     8.2054913043975830e-02
    z[4,3,3]  R1096     -2.0222092047333717e-02
    z[4,3,3]  R1097     -1.4055344462394714e-01
    z[4,3,3]  R1098     1.3506911695003510e-01
    z[4,3,3]  R1099     1.6846060752868652e-01
    z[4,3,3]  R1100     -2.1175147965550423e-02
    z[4,3,3]  R1101     4.6630653738975525e-01
    z[4,3,3]  R1102     0.623343288898468
    z[4,3,3]  R1103     -1.3740181922912598e-01
    z[4,3,3]  R1104     -2.2141449153423309e-01
    z[4,3,3]  R1105     1.3829699158668518e-01
    z[4,3,3]  R1106     -7.6564550399780273e-01
    z[4,3,3]  R1107     1.7201645672321320e-01
    z[4,3,3]  R1108     -6.3344007730484009e-01
    z[4,3,3]  R1109     -0.415695458650589
    z[4,3,3]  R1110     3.7936963140964508e-02
    z[4,3,3]  R1111     -5.5727396160364151e-02
    z[4,3,3]  R1112     8.7636536359786987e-01
    z[4,3,3]  R1113     -4.5097228884696960e-01
    z[4,3,3]  R1114     2.6321390271186829e-01
    z[4,3,3]  R1115     5.3094297647476196e-02
    z[4,3,3]  R1116     1.1101468652486801e-01
    z[4,3,3]  R1117     2.6173036545515060e-02
    z[4,3,3]  R1118     9.6922911703586578e-02
    z[4,3,3]  R1119     3.5951477289199829e-01
    z[4,3,3]  R1120     4.6084529161453247e-01
    z[4,3,3]  R1121     2.0157489180564880e-01
    z[4,3,3]  R1122     1.5019841492176056e-01
    z[4,3,3]  R1123     -4.6264287829399109e-01
    z[4,3,3]  R1124     -1.3778880238533020e-03
    z[4,3,3]  R1125     4.8098187893629074e-02
    z[4,3,3]  R1126     -5.7226948440074921e-02
    z[4,3,3]  R1127     -9.2000365257263184e-02
    z[4,3,3]  R1128     4.1226636618375778e-02
    z[4,3,3]  R1129     3.9620363712310791e-01
    z[4,3,3]  R1130     -4.6701491810381413e-03
    z[4,3,3]  R1131     2.9443684220314026e-01
    z[4,3,3]  R1132     6.2322062253952026e-01
    z[4,3,3]  R1133     4.3258953094482422e-01
    z[4,3,3]  R1134     4.1657385230064392e-01
    z[4,3,3]  R1135     -7.4566014111042023e-02
    z[4,3,3]  R1136     4.5363315939903259e-01
    z[4,3,3]  R1137     -1.3361506164073944e-01
    z[4,3,3]  R1138     7.1216380596160889e-01
    z[4,3,3]  R1139     0.600469172000885
    z[4,3,3]  R1140     7.9959535598754883e-01
    z[4,3,3]  R1141     7.2746020555496216e-01
    z[4,3,3]  R1142     2.0860774442553520e-02
    z[4,3,3]  R1143     -2.9196754097938538e-01
    z[4,3,3]  R1144     -7.9768812283873558e-03
    z[4,3,3]  R1145     6.8975519388914108e-03
    z[4,3,3]  R1146     -0.17877297103405
    z[4,3,3]  R1147     6.6534203290939331e-01
    z[4,3,3]  R1148     0.0673535093665123
    z[4,3,3]  R1149     3.7388241291046143e-01
    z[4,3,3]  R1150     4.7781109809875488e-01
    z[4,3,3]  R1151     -1.6770860552787781e-01
    z[4,3,3]  R1152     -2.5062268972396851e-01
    z[4,3,3]  R1153     -7.1692460775375366e-01
    z[4,3,3]  R1154     1.8741454184055328e-01
    z[4,3,3]  R1155     -2.8977379202842712e-01
    z[4,3,3]  R1156     -8.4911346435546875e-02
    z[4,3,3]  R1157     -3.3067530393600464e-01
    z[4,3,3]  R1158     -1.3843837380409241e-01
    z[4,3,3]  R1159     -2.8861805796623230e-02
    z[4,3,3]  R1160     -2.5015437975525856e-02
    z[4,3,3]  R1161     5.0772500038146973e-01
    z[4,3,3]  R1162     6.3338494300842285e-01
    z[4,3,3]  R1163     -7.0545035600662231e-01
    z[4,3,3]  R1164     -1.1263841390609741e-01
    z[4,3,3]  R1165     -1.8007743358612061e-01
    z[4,3,3]  R1166     2.5668722391128540e-01
    z[4,3,3]  R1167     -1.8313533067703247e-01
    z[4,3,3]  R1168     -2.5241750478744507e-01
    z[4,3,3]  R1169     -2.4784231185913086e-01
    z[4,3,3]  R1170     3.5779255628585815e-01
    z[4,3,3]  R1171     0.0634353756904602
    z[4,3,3]  R1172     -2.4863202869892120e-01
    z[4,3,3]  R1173     -4.5533329248428345e-02
    z[4,3,3]  R1174     -6.9684617221355438e-02
    z[4,3,3]  R1175     0.764371395111084
    z[4,3,3]  R1176     0.745017409324646
    z[4,3,3]  R1177     -4.9989512562751770e-01
    z[4,3,3]  R1178     7.1240496635437012e-01
    z[4,3,3]  R1179     6.2345904111862183e-01
    z[4,3,3]  R1180     -2.2300015389919281e-01
    z[4,3,4]  R33       1
    z[4,3,4]  R42       -1
    z[4,3,4]  R1087     -1
    z[4,3,4]  R1088     1
    z[4,3,4]  R1093     -6.7960780858993530e-01
    z[4,3,4]  R1094     -1.3993211090564728e-01
    z[4,3,4]  R1095     -2.9488596320152283e-01
    z[4,3,4]  R1096     7.0823854207992554e-01
    z[4,3,4]  R1097     6.7547351121902466e-01
    z[4,3,4]  R1098     2.6978189125657082e-02
    z[4,3,4]  R1099     -1.2629888951778412e-01
    z[4,3,4]  R1100     -4.1531139612197876e-01
    z[4,3,4]  R1101     1.1978959292173386e-01
    z[4,3,4]  R1102     1.2435131520032883e-01
    z[4,3,4]  R1103     4.9273487180471420e-02
    z[4,3,4]  R1104     1.8249136209487915e-01
    z[4,3,4]  R1105     5.3202575445175171e-01
    z[4,3,4]  R1106     5.2533334493637085e-01
    z[4,3,4]  R1107     9.3137837946414948e-02
    z[4,3,4]  R1108     8.3275333046913147e-02
    z[4,3,4]  R1109     1.3587783277034760e-01
    z[4,3,4]  R1110     5.7541990280151367e-01
    z[4,3,4]  R1111     1.7288066446781158e-01
    z[4,3,4]  R1112     -1.4637543819844723e-02
    z[4,3,4]  R1113     -5.5954560637474060e-02
    z[4,3,4]  R1114     -3.6770024895668030e-01
    z[4,3,4]  R1115     -1.8873862922191620e-01
    z[4,3,4]  R1116     2.2558660805225372e-01
    z[4,3,4]  R1117     -8.2657516002655029e-02
    z[4,3,4]  R1118     -9.6800431609153748e-02
    z[4,3,4]  R1119     -1.6078034043312073e-01
    z[4,3,4]  R1120     -1.9464877247810364e-01
    z[4,3,4]  R1121     -4.1220435500144958e-01
    z[4,3,4]  R1122     2.9235166311264038e-01
    z[4,3,4]  R1123     8.0781751871109009e-01
    z[4,3,4]  R1124     1.1478152871131897e-01
    z[4,3,4]  R1125     4.2002722620964050e-01
    z[4,3,4]  R1126     4.8885148763656616e-01
    z[4,3,4]  R1127     -1.6488823294639587e-01
    z[4,3,4]  R1128     1.3348235189914703e-01
    z[4,3,4]  R1129     -1.6731470823287964e-01
    z[4,3,4]  R1130     1.3335452415049076e-02
    z[4,3,4]  R1131     2.2520011663436890e-01
    z[4,3,4]  R1132     -7.5253896415233612e-02
    z[4,3,4]  R1133     3.9314761757850647e-02
    z[4,3,4]  R1134     1.0867656767368317e-01
    z[4,3,4]  R1135     -2.3046325147151947e-01
    z[4,3,4]  R1136     -1.1870503425598145e-01
    z[4,3,4]  R1137     -1.5901979058980942e-02
    z[4,3,4]  R1138     7.6755732297897339e-02
    z[4,3,4]  R1139     9.0735845267772675e-02
    z[4,3,4]  R1140     -0.0392913781106472
    z[4,3,4]  R1141     6.7949362099170685e-02
    z[4,3,4]  R1142     -4.0598297119140625e-01
    z[4,3,4]  R1143     2.2628886997699738e-01
    z[4,3,4]  R1144     -2.6916259527206421e-01
    z[4,3,4]  R1145     2.8445419669151306e-01
    z[4,3,4]  R1146     -1.6582595184445381e-02
    z[4,3,4]  R1147     6.2523297965526581e-03
    z[4,3,4]  R1148     4.3712127208709717e-01
    z[4,3,4]  R1149     7.6559692621231079e-02
    z[4,3,4]  R1150     -6.3483619689941406e-01
    z[4,3,4]  R1151     -7.7163302898406982e-01
    z[4,3,4]  R1152     -5.2388721704483032e-01
    z[4,3,4]  R1153     2.4067023769021034e-03
    z[4,3,4]  R1154     0.0366709902882576
    z[4,3,4]  R1155     4.2248047888278961e-02
    z[4,3,4]  R1156     -7.0286847651004791e-02
    z[4,3,4]  R1157     2.3987520486116409e-02
    z[4,3,4]  R1158     4.4759169220924377e-01
    z[4,3,4]  R1159     -3.4284293651580811e-01
    z[4,3,4]  R1160     8.7679319083690643e-02
    z[4,3,4]  R1161     8.8047936558723450e-02
    z[4,3,4]  R1162     1.4458252489566803e-01
    z[4,3,4]  R1163     6.2738835811614990e-02
    z[4,3,4]  R1164     2.5824561715126038e-01
    z[4,3,4]  R1165     3.1630176305770874e-01
    z[4,3,4]  R1166     1.7364698648452759e-01
    z[4,3,4]  R1167     -1.5740180015563965e-01
    z[4,3,4]  R1168     2.8242337703704834e-01
    z[4,3,4]  R1169     -0.374988853931427
    z[4,3,4]  R1170     -1.2066390365362167e-01
    z[4,3,4]  R1171     7.7609471976757050e-02
    z[4,3,4]  R1172     2.2041009366512299e-01
    z[4,3,4]  R1173     4.9515865743160248e-02
    z[4,3,4]  R1174     1.8371193110942841e-01
    z[4,3,4]  R1175     -9.0807870030403137e-02
    z[4,3,4]  R1176     0.341768354177475
    z[4,3,4]  R1177     -5.2788305282592773e-01
    z[4,3,4]  R1178     -2.6208034157752991e-01
    z[4,3,4]  R1179     -4.8843666911125183e-01
    z[4,3,4]  R1180     1.4653810858726501e-01
    z[4,3,5]  R34       1
    z[4,3,5]  R43       -1
    z[4,3,5]  R1089     -1
    z[4,3,5]  R1090     1
    z[4,3,5]  R1093     0.0559404082596302
    z[4,3,5]  R1094     2.8066992759704590e-01
    z[4,3,5]  R1095     8.0574375391006470e-01
    z[4,3,5]  R1096     2.9041644930839539e-01
    z[4,3,5]  R1097     -1.9368024542927742e-02
    z[4,3,5]  R1098     1.7122475430369377e-02
    z[4,3,5]  R1099     5.5484312772750854e-01
    z[4,3,5]  R1100     1.7156814038753510e-01
    z[4,3,5]  R1101     6.0017108917236328e-01
    z[4,3,5]  R1102     3.5948729515075684e-01
    z[4,3,5]  R1103     -1.2933203834109008e-04
    z[4,3,5]  R1104     -5.3700095415115356e-01
    z[4,3,5]  R1105     -6.5760958194732666e-01
    z[4,3,5]  R1106     -2.5490492582321167e-01
    z[4,3,5]  R1107     -7.4669677019119263e-01
    z[4,3,5]  R1108     -0.489662230014801
    z[4,3,5]  R1109     -5.2383244037628174e-01
    z[4,3,5]  R1110     -4.6987172961235046e-01
    z[4,3,5]  R1111     -8.0954384803771973e-01
    z[4,3,5]  R1112     -6.7603783681988716e-03
    z[4,3,5]  R1113     3.9236697554588318e-01
    z[4,3,5]  R1114     -4.5929306745529175e-01
    z[4,3,5]  R1115     2.7570620179176331e-01
    z[4,3,5]  R1116     1.7076404392719269e-01
    z[4,3,5]  R1117     2.8928220272064209e-02
    z[4,3,5]  R1118     2.1675245463848114e-01
    z[4,3,5]  R1119     5.6372302770614624e-01
    z[4,3,5]  R1120     4.2820256948471069e-01
    z[4,3,5]  R1121     -4.8932361602783203e-01
    z[4,3,5]  R1122     1.4396293461322784e-01
    z[4,3,5]  R1123     -1.4416243135929108e-01
    z[4,3,5]  R1124     -0.0305878184735775
    z[4,3,5]  R1125     -3.7809950113296509e-01
    z[4,3,5]  R1126     1.3094292581081390e-01
    z[4,3,5]  R1127     -1.4991295337677002e-01
    z[4,3,5]  R1128     7.3057748377323151e-02
    z[4,3,5]  R1129     2.5748360157012939e-01
    z[4,3,5]  R1130     5.9070986509323120e-01
    z[4,3,5]  R1131     4.3190208077430725e-01
    z[4,3,5]  R1132     4.8718398809432983e-01
    z[4,3,5]  R1133     0.637184202671051
    z[4,3,5]  R1134     1.9008395075798035e-01
    z[4,3,5]  R1135     4.2423000931739807e-01
    z[4,3,5]  R1136     3.0134943127632141e-01
    z[4,3,5]  R1137     4.0979641675949097e-01
    z[4,3,5]  R1138     6.4152711629867554e-01
    z[4,3,5]  R1139     7.5302320718765259e-01
    z[4,3,5]  R1140     5.5047595500946045e-01
    z[4,3,5]  R1141     5.6913548707962036e-01
    z[4,3,5]  R1142     -3.3383011817932129e-02
    z[4,3,5]  R1143     -6.0272864997386932e-02
    z[4,3,5]  R1144     5.2378200925886631e-03
    z[4,3,5]  R1145     -2.4463790655136108e-01
    z[4,3,5]  R1146     5.4991978406906128e-01
    z[4,3,5]  R1147     7.6349325478076935e-02
    z[4,3,5]  R1148     6.2419414520263672e-01
    z[4,3,5]  R1149     9.5532253384590149e-02
    z[4,3,5]  R1150     -2.0367403328418732e-01
    z[4,3,5]  R1151     -1.3126057386398315e-01
    z[4,3,5]  R1152     -9.7383596003055573e-03
    z[4,3,5]  R1153     -2.2481042146682739e-01
    z[4,3,5]  R1154     -2.5774425268173218e-01
    z[4,3,5]  R1155     -1.6966257989406586e-01
    z[4,3,5]  R1156     -0.244800865650177
    z[4,3,5]  R1157     3.4857827425003052e-01
    z[4,3,5]  R1158     -1.6361238434910774e-02
    z[4,3,5]  R1159     -1.2094871699810028e-01
    z[4,3,5]  R1160     2.1043597161769867e-01
    z[4,3,5]  R1161     3.9162391424179077e-01
    z[4,3,5]  R1162     -1.0682401806116104e-01
    z[4,3,5]  R1163     -1.7073659598827362e-01
    z[4,3,5]  R1164     1.2148747593164444e-01
    z[4,3,5]  R1165     1.3128049671649933e-01
    z[4,3,5]  R1166     2.2975887358188629e-01
    z[4,3,5]  R1167     5.1292762160301208e-02
    z[4,3,5]  R1168     5.4597463458776474e-02
    z[4,3,5]  R1169     1.5197399258613586e-01
    z[4,3,5]  R1170     -1.5045249462127686e-01
    z[4,3,5]  R1171     1.0198665410280228e-01
    z[4,3,5]  R1172     -3.8891077041625977e-01
    z[4,3,5]  R1173     1.7021405696868896e-01
    z[4,3,5]  R1174     -0.256853312253952
    z[4,3,5]  R1175     2.6179185137152672e-02
    z[4,3,5]  R1176     -3.5139527916908264e-01
    z[4,3,5]  R1177     1.7495891451835632e-01
    z[4,3,5]  R1178     -1.4328850805759430e-01
    z[4,3,5]  R1179     2.0163874328136444e-01
    z[4,3,5]  R1180     1.7113395035266876e-01
    z[4,3,6]  R35       1
    z[4,3,6]  R44       -1
    z[4,3,6]  R1091     -1
    z[4,3,6]  R1092     1
    z[4,3,6]  R1093     3.3664533495903015e-01
    z[4,3,6]  R1094     2.3573417961597443e-01
    z[4,3,6]  R1095     4.4084972143173218e-01
    z[4,3,6]  R1096     -9.0215429663658142e-02
    z[4,3,6]  R1097     3.9096099138259888e-01
    z[4,3,6]  R1098     3.4627810120582581e-01
    z[4,3,6]  R1099     1.8580521643161774e-01
    z[4,3,6]  R1100     4.1898670792579651e-01
    z[4,3,6]  R1101     -2.6931622624397278e-01
    z[4,3,6]  R1102     -1.6151136159896851e-01
    z[4,3,6]  R1103     -1.4734691381454468e-01
    z[4,3,6]  R1104     5.0750488042831421e-01
    z[4,3,6]  R1105     2.4365903437137604e-01
    z[4,3,6]  R1106     1.8402788043022156e-01
    z[4,3,6]  R1107     1.2230180203914642e-01
    z[4,3,6]  R1108     2.5534853339195251e-01
    z[4,3,6]  R1109     4.9820411205291748e-01
    z[4,3,6]  R1110     -5.8697527647018433e-01
    z[4,3,6]  R1111     -2.2447204589843750e-01
    z[4,3,6]  R1112     -1.5371930599212646e-01
    z[4,3,6]  R1113     2.1896651387214661e-01
    z[4,3,6]  R1114     -4.8337876796722412e-01
    z[4,3,6]  R1115     -4.9422928132116795e-03
    z[4,3,6]  R1116     -1.7492248117923737e-01
    z[4,3,6]  R1117     -0.311410129070282
    z[4,3,6]  R1118     -1.0314693674445152e-02
    z[4,3,6]  R1119     -2.7174046263098717e-02
    z[4,3,6]  R1120     7.0586074143648148e-03
    z[4,3,6]  R1121     1.6405366361141205e-01
    z[4,3,6]  R1122     -3.8203904032707214e-01
    z[4,3,6]  R1123     -5.4438419640064240e-02
    z[4,3,6]  R1124     3.2419890165328979e-01
    z[4,3,6]  R1125     -6.2903493642807007e-01
    z[4,3,6]  R1126     5.0851851701736450e-01
    z[4,3,6]  R1127     -9.3386769294738770e-02
    z[4,3,6]  R1128     -1.1720818281173706e-01
    z[4,3,6]  R1129     2.2354254126548767e-01
    z[4,3,6]  R1130     -1.8927467986941338e-02
    z[4,3,6]  R1131     -2.4369551241397858e-01
    z[4,3,6]  R1132     1.8381108343601227e-01
    z[4,3,6]  R1133     -8.8346116244792938e-02
    z[4,3,6]  R1134     -2.7376693487167358e-01
    z[4,3,6]  R1135     -2.8332561254501343e-01
    z[4,3,6]  R1136     -3.3860078454017639e-01
    z[4,3,6]  R1137     -0.162612646818161
    z[4,3,6]  R1138     -1.3697418570518494e-01
    z[4,3,6]  R1139     -2.4773661792278290e-01
    z[4,3,6]  R1140     -2.1843566000461578e-01
    z[4,3,6]  R1141     -2.4833329021930695e-01
    z[4,3,6]  R1142     -4.3179315328598022e-01
    z[4,3,6]  R1143     2.3065450787544250e-01
    z[4,3,6]  R1144     -2.2433733940124512e-01
    z[4,3,6]  R1145     9.5027135685086250e-03
    z[4,3,6]  R1146     -3.0451586842536926e-01
    z[4,3,6]  R1147     4.0011522173881531e-01
    z[4,3,6]  R1148     -9.0896666049957275e-02
    z[4,3,6]  R1149     4.7414788603782654e-01
    z[4,3,6]  R1150     3.8322679698467255e-02
    z[4,3,6]  R1151     9.8887398838996887e-02
    z[4,3,6]  R1152     5.5091398954391479e-01
    z[4,3,6]  R1153     -3.1023567914962769e-01
    z[4,3,6]  R1154     -2.6245719194412231e-01
    z[4,3,6]  R1155     -3.0436590313911438e-01
    z[4,3,6]  R1156     -4.6823951601982117e-01
    z[4,3,6]  R1157     -2.9056310653686523e-01
    z[4,3,6]  R1158     -2.0337577164173126e-01
    z[4,3,6]  R1159     2.0055323839187622e-01
    z[4,3,6]  R1160     9.4782322645187378e-02
    z[4,3,6]  R1161     -2.7302485704421997e-01
    z[4,3,6]  R1162     -7.0345097780227661e-01
    z[4,3,6]  R1163     -0.365187406539917
    z[4,3,6]  R1164     2.4529822170734406e-01
    z[4,3,6]  R1165     -1.5396726131439209e-01
    z[4,3,6]  R1166     1.1342352628707886e-01
    z[4,3,6]  R1167     1.6710974276065826e-01
    z[4,3,6]  R1168     1.0853295773267746e-01
    z[4,3,6]  R1169     0.0305503997951746
    z[4,3,6]  R1170     8.9628294110298157e-02
    z[4,3,6]  R1171     1.7342561483383179e-01
    z[4,3,6]  R1172     2.1724744141101837e-01
    z[4,3,6]  R1173     -2.5142121315002441e-01
    z[4,3,6]  R1174     3.6345383524894714e-01
    z[4,3,6]  R1175     -3.0564209818840027e-01
    z[4,3,6]  R1176     4.7692552208900452e-02
    z[4,3,6]  R1177     5.6257343292236328e-01
    z[4,3,6]  R1178     0.313156396150589
    z[4,3,6]  R1179     2.4942032992839813e-01
    z[4,3,6]  R1180     -5.1320254802703857e-01
    z[3,10,0]  R29       -1
    z[3,10,0]  R92       1
    z[3,10,0]  R1181     -1
    z[3,10,0]  R1182     1
    z[3,10,0]  R1195     -6.5310436487197876e-01
    z[3,10,0]  R1196     -7.3012202978134155e-01
    z[3,10,0]  R1197     -8.1839954853057861e-01
    z[3,10,0]  R1198     -7.1401822566986084e-01
    z[3,10,0]  R1199     0.153198704123497
    z[3,10,0]  R1200     -6.0081088542938232e-01
    z[3,10,0]  R1201     7.1688795089721680e-01
    z[3,10,0]  R1202     2.3340252041816711e-01
    z[3,10,0]  R1203     4.9905306100845337e-01
    z[3,10,0]  R1204     2.5812390446662903e-01
    z[3,10,0]  R1205     2.7214249968528748e-01
    z[3,10,0]  R1206     0.531776487827301
    z[3,10,0]  R1207     5.4017448425292969e-01
    z[3,10,0]  R1208     3.8133546710014343e-01
    z[3,10,0]  R1209     5.2057379484176636e-01
    z[3,10,0]  R1210     5.9864956140518188e-01
    z[3,10,0]  R1211     0.365446001291275
    z[3,10,0]  R1212     5.5695241689682007e-01
    z[3,10,0]  R1213     2.8284192085266113e-01
    z[3,10,0]  R1214     1.7235065996646881e-01
    z[3,10,0]  R1215     -4.2859369516372681e-01
    z[3,10,0]  R1216     5.8471912145614624e-01
    z[3,10,0]  R1217     0.627866804599762
    z[3,10,0]  R1218     6.2033843994140625e-01
    z[3,10,0]  R1219     5.3637397289276123e-01
    z[3,10,0]  R1220     5.6048560142517090e-01
    z[3,10,0]  R1221     5.8017802238464355e-01
    z[3,10,0]  R1222     6.1862134933471680e-01
    z[3,10,0]  R1223     3.5152587294578552e-01
    z[3,10,0]  R1224     6.4129203557968140e-01
    z[3,10,0]  R1225     4.6803352236747742e-01
    z[3,10,0]  R1226     5.8159804344177246e-01
    z[3,10,0]  R1227     4.9010065197944641e-01
    z[3,10,0]  R1228     2.0241326093673706e-01
    z[3,10,0]  R1229     -0.188896045088768
    z[3,10,0]  R1230     -9.8122563213109970e-03
    z[3,10,0]  R1231     0.0203165952116251
    z[3,10,0]  R1232     3.1710234284400940e-01
    z[3,10,0]  R1233     -3.9636448025703430e-01
    z[3,10,0]  R1234     -2.1843071281909943e-01
    z[3,10,0]  R1235     -5.5052655935287476e-01
    z[3,10,0]  R1236     -5.1393687725067139e-02
    z[3,10,0]  R1237     -1.1332868784666061e-01
    z[3,10,0]  R1238     -1.8592710793018341e-01
    z[3,10,0]  R1239     3.6510050296783447e-01
    z[3,10,0]  R1240     2.6070839166641235e-01
    z[3,10,0]  R1241     -1.9142383709549904e-02
    z[3,10,0]  R1242     -4.2343366146087646e-01
    z[3,10,0]  R1243     4.0896305441856384e-01
    z[3,10,0]  R1244     -9.6639342606067657e-02
    z[3,10,0]  R1245     -4.7348892688751221e-01
    z[3,10,0]  R1246     -1.7088831961154938e-01
    z[3,10,0]  R1247     -1.2774877250194550e-02
    z[3,10,0]  R1248     2.2630387544631958e-01
    z[3,10,0]  R1249     1.8719108402729034e-01
    z[3,10,0]  R1250     -3.3848896622657776e-01
    z[3,10,0]  R1251     6.2727910280227661e-01
    z[3,10,0]  R1252     -3.6651602387428284e-01
    z[3,10,0]  R1253     -9.5985263586044312e-02
    z[3,10,0]  R1254     1.1450875550508499e-01
    z[3,10,0]  R1255     1.0657140612602234e-01
    z[3,10,0]  R1256     2.9993700981140137e-01
    z[3,10,0]  R1257     -3.0955451726913452e-01
    z[3,10,0]  R1258     -5.6630626320838928e-02
    z[3,10,0]  R1259     2.1666556596755981e-02
    z[3,10,0]  R1260     4.6906974911689758e-01
    z[3,10,0]  R1261     -7.2263628244400024e-01
    z[3,10,0]  R1262     -3.6497896909713745e-01
    z[3,10,0]  R1263     -1.9985330104827881e-01
    z[3,10,0]  R1264     -3.8029614835977554e-02
    z[3,10,0]  R1265     -2.6851644739508629e-02
    z[3,10,0]  R1266     1.5648564696311951e-01
    z[3,10,0]  R1267     5.9689271450042725e-01
    z[3,10,0]  R1268     2.2789795696735382e-01
    z[3,10,0]  R1269     -2.8174072504043579e-01
    z[3,10,0]  R1270     6.2675297260284424e-01
    z[3,10,0]  R1271     -3.2631557434797287e-02
    z[3,10,0]  R1272     5.2217852324247360e-02
    z[3,10,1]  R30       -1
    z[3,10,1]  R93       1
    z[3,10,1]  R1183     -1
    z[3,10,1]  R1184     1
    z[3,10,1]  R1195     5.8178991079330444e-01
    z[3,10,1]  R1196     4.7476023435592651e-01
    z[3,10,1]  R1197     -2.7540719509124756e-01
    z[3,10,1]  R1198     -2.4982862174510956e-01
    z[3,10,1]  R1199     6.0271453857421875e-01
    z[3,10,1]  R1200     1.2983238697052002e-01
    z[3,10,1]  R1201     -7.5340755283832550e-02
    z[3,10,1]  R1202     4.8387479782104492e-01
    z[3,10,1]  R1203     3.0697804689407349e-01
    z[3,10,1]  R1204     5.3865957260131836e-01
    z[3,10,1]  R1205     -5.1415318250656128e-01
    z[3,10,1]  R1206     -7.2146528959274292e-01
    z[3,10,1]  R1207     -6.8546158075332642e-01
    z[3,10,1]  R1208     -7.5014483928680420e-01
    z[3,10,1]  R1209     -6.3469791412353516e-01
    z[3,10,1]  R1210     -5.6650543212890625e-01
    z[3,10,1]  R1211     -8.0281686782836914e-01
    z[3,10,1]  R1212     -6.2422585487365723e-01
    z[3,10,1]  R1213     -6.1908406019210815e-01
    z[3,10,1]  R1214     -2.0034465193748474e-01
    z[3,10,1]  R1215     -3.3841341733932495e-01
    z[3,10,1]  R1216     -7.0923173427581787e-01
    z[3,10,1]  R1217     -6.5544891357421875e-01
    z[3,10,1]  R1218     -6.6866677999496460e-01
    z[3,10,1]  R1219     -7.2253215312957764e-01
    z[3,10,1]  R1220     -0.651892900466919
    z[3,10,1]  R1221     -6.3286352157592773e-01
    z[3,10,1]  R1222     -5.8157765865325928e-01
    z[3,10,1]  R1223     -0.886976957321167
    z[3,10,1]  R1224     -5.1137030124664307e-01
    z[3,10,1]  R1225     -7.9289269447326660e-01
    z[3,10,1]  R1226     -6.3307863473892212e-01
    z[3,10,1]  R1227     -2.2521585226058960e-01
    z[3,10,1]  R1228     -4.0167921781539917e-01
    z[3,10,1]  R1229     -2.7031752467155457e-01
    z[3,10,1]  R1230     -5.2839994430541992e-01
    z[3,10,1]  R1231     -5.1613306999206543e-01
    z[3,10,1]  R1232     6.9041180610656738e-01
    z[3,10,1]  R1233     -1.0856962949037552e-01
    z[3,10,1]  R1234     1.5542726218700409e-01
    z[3,10,1]  R1235     -1.1899171397089958e-02
    z[3,10,1]  R1236     -7.4997544288635254e-02
    z[3,10,1]  R1237     4.1021695733070374e-01
    z[3,10,1]  R1238     -3.9665222167968750e-02
    z[3,10,1]  R1239     4.5404410362243652e-01
    z[3,10,1]  R1240     4.4423744082450867e-01
    z[3,10,1]  R1241     2.4021776020526886e-01
    z[3,10,1]  R1242     4.6866810321807861e-01
    z[3,10,1]  R1243     1.7533724009990692e-01
    z[3,10,1]  R1244     1.4846704900264740e-01
    z[3,10,1]  R1245     -2.9659056663513184e-01
    z[3,10,1]  R1246     -4.6645447611808777e-01
    z[3,10,1]  R1247     -7.6093202829360962e-01
    z[3,10,1]  R1248     -7.7744621038436890e-01
    z[3,10,1]  R1249     -9.4802898168563843e-01
    z[3,10,1]  R1250     -3.0477842688560486e-01
    z[3,10,1]  R1251     -1.8231703341007233e-01
    z[3,10,1]  R1252     0.0208007600158453
    z[3,10,1]  R1253     -0.379312664270401
    z[3,10,1]  R1254     6.0360127687454224e-01
    z[3,10,1]  R1255     -1.1329365521669388e-01
    z[3,10,1]  R1256     -3.0436906218528748e-01
    z[3,10,1]  R1257     2.7989361435174942e-02
    z[3,10,1]  R1258     0.67806077003479
    z[3,10,1]  R1259     1.3304229080677032e-01
    z[3,10,1]  R1260     -5.4952919483184814e-01
    z[3,10,1]  R1261     5.9685826301574707e-01
    z[3,10,1]  R1262     7.9292759299278259e-02
    z[3,10,1]  R1263     -6.0732532292604446e-02
    z[3,10,1]  R1264     -1.7408357560634613e-01
    z[3,10,1]  R1265     2.4137814342975616e-01
    z[3,10,1]  R1266     -3.1413719058036804e-02
    z[3,10,1]  R1267     -2.7527580037713051e-02
    z[3,10,1]  R1268     8.8575951755046844e-02
    z[3,10,1]  R1269     -5.5882513523101807e-01
    z[3,10,1]  R1270     0.430237740278244
    z[3,10,1]  R1271     -6.8249548785388470e-03
    z[3,10,1]  R1272     -2.4141646921634674e-01
    z[3,10,2]  R31       -1
    z[3,10,2]  R94       1
    z[3,10,2]  R1185     -1
    z[3,10,2]  R1186     1
    z[3,10,2]  R1195     -2.0417949557304382e-01
    z[3,10,2]  R1196     -3.4446725249290466e-01
    z[3,10,2]  R1197     -3.3685794472694397e-01
    z[3,10,2]  R1198     -1.9678533077239990e-02
    z[3,10,2]  R1199     0.06800577044487
    z[3,10,2]  R1200     1.6934520006179810e-01
    z[3,10,2]  R1201     3.1749528646469116e-01
    z[3,10,2]  R1202     -1.9265535473823547e-01
    z[3,10,2]  R1203     -0.0784771665930748
    z[3,10,2]  R1204     -4.8448212444782257e-02
    z[3,10,2]  R1205     2.8500853106379509e-02
    z[3,10,2]  R1206     -1.5785014629364014e-01
    z[3,10,2]  R1207     -1.7656792700290680e-01
    z[3,10,2]  R1208     0.0232391320168972
    z[3,10,2]  R1209     -1.0151895135641098e-01
    z[3,10,2]  R1210     -2.4404411017894745e-01
    z[3,10,2]  R1211     -2.2070296108722687e-01
    z[3,10,2]  R1212     -4.8843196034431458e-01
    z[3,10,2]  R1213     -2.0805369317531586e-01
    z[3,10,2]  R1214     4.2685028165578842e-02
    z[3,10,2]  R1215     -1.9409951567649841e-01
    z[3,10,2]  R1216     -2.8021706268191338e-02
    z[3,10,2]  R1217     5.2486073225736618e-02
    z[3,10,2]  R1218     -7.9806774854660034e-02
    z[3,10,2]  R1219     -3.1840169429779053e-01
    z[3,10,2]  R1220     3.2039615511894226e-01
    z[3,10,2]  R1221     1.9184727966785431e-01
    z[3,10,2]  R1222     -3.2531636953353882e-01
    z[3,10,2]  R1223     1.9793011248111725e-01
    z[3,10,2]  R1224     1.3564078509807587e-01
    z[3,10,2]  R1225     2.3570168018341064e-01
    z[3,10,2]  R1226     1.5581017732620239e-01
    z[3,10,2]  R1227     1.4989016950130463e-01
    z[3,10,2]  R1228     -8.5404375568032265e-03
    z[3,10,2]  R1229     -1.2486571818590164e-01
    z[3,10,2]  R1230     -1.6090908646583557e-01
    z[3,10,2]  R1231     -5.5259462445974350e-02
    z[3,10,2]  R1232     2.4271681904792786e-01
    z[3,10,2]  R1233     -2.9010385274887085e-01
    z[3,10,2]  R1234     -2.3738962411880493e-01
    z[3,10,2]  R1235     -2.5479811429977417e-01
    z[3,10,2]  R1236     -5.6889832019805908e-01
    z[3,10,2]  R1237     -2.5653791427612305e-01
    z[3,10,2]  R1238     -5.0786983966827393e-01
    z[3,10,2]  R1239     2.6203829050064087e-01
    z[3,10,2]  R1240     5.5182456970214844e-02
    z[3,10,2]  R1241     -6.7197734117507935e-01
    z[3,10,2]  R1242     6.0794495046138763e-02
    z[3,10,2]  R1243     2.9034504666924477e-02
    z[3,10,2]  R1244     1.1902976036071777e-01
    z[3,10,2]  R1245     1.1844386905431747e-01
    z[3,10,2]  R1246     -1.0425622761249542e-01
    z[3,10,2]  R1247     8.9256383478641510e-02
    z[3,10,2]  R1248     2.5807061791419983e-01
    z[3,10,2]  R1249     -0.00564618781208992
    z[3,10,2]  R1250     -7.6905570924282074e-02
    z[3,10,2]  R1251     1.9678516313433647e-02
    z[3,10,2]  R1252     1.1538688093423843e-01
    z[3,10,2]  R1253     -2.1094707772135735e-02
    z[3,10,2]  R1254     4.1736122965812683e-01
    z[3,10,2]  R1255     7.0153094828128815e-02
    z[3,10,2]  R1256     -3.8802798837423325e-02
    z[3,10,2]  R1257     1.8816716969013214e-01
    z[3,10,2]  R1258     2.3320975899696350e-01
    z[3,10,2]  R1259     -4.6710226684808731e-02
    z[3,10,2]  R1260     7.3537260293960571e-02
    z[3,10,2]  R1261     -3.7699963431805372e-03
    z[3,10,2]  R1262     -8.2393847405910492e-02
    z[3,10,2]  R1263     -7.5839266180992126e-02
    z[3,10,2]  R1264     2.0828737318515778e-01
    z[3,10,2]  R1265     1.2249260395765305e-01
    z[3,10,2]  R1266     -1.1270281672477722e-01
    z[3,10,2]  R1267     -2.6481010019779205e-02
    z[3,10,2]  R1268     -2.3649835586547852e-01
    z[3,10,2]  R1269     -4.7293606400489807e-01
    z[3,10,2]  R1270     -1.7638376355171204e-01
    z[3,10,2]  R1271     -2.5224119424819946e-01
    z[3,10,2]  R1272     2.0095808804035187e-01
    z[3,10,3]  R32       -1
    z[3,10,3]  R95       1
    z[3,10,3]  R1187     -1
    z[3,10,3]  R1188     1
    z[3,10,3]  R1195     -2.9196754097938538e-01
    z[3,10,3]  R1196     -7.9768812283873558e-03
    z[3,10,3]  R1197     6.8975519388914108e-03
    z[3,10,3]  R1198     -0.17877297103405
    z[3,10,3]  R1199     6.6534203290939331e-01
    z[3,10,3]  R1200     0.0673535093665123
    z[3,10,3]  R1201     3.7388241291046143e-01
    z[3,10,3]  R1202     4.7781109809875488e-01
    z[3,10,3]  R1203     -1.6770860552787781e-01
    z[3,10,3]  R1204     -2.5062268972396851e-01
    z[3,10,3]  R1205     -7.1692460775375366e-01
    z[3,10,3]  R1206     1.8741454184055328e-01
    z[3,10,3]  R1207     -2.8977379202842712e-01
    z[3,10,3]  R1208     -8.4911346435546875e-02
    z[3,10,3]  R1209     -3.3067530393600464e-01
    z[3,10,3]  R1210     -1.3843837380409241e-01
    z[3,10,3]  R1211     -2.8861805796623230e-02
    z[3,10,3]  R1212     -2.5015437975525856e-02
    z[3,10,3]  R1213     5.0772500038146973e-01
    z[3,10,3]  R1214     6.3338494300842285e-01
    z[3,10,3]  R1215     -7.0545035600662231e-01
    z[3,10,3]  R1216     -1.1263841390609741e-01
    z[3,10,3]  R1217     -1.8007743358612061e-01
    z[3,10,3]  R1218     2.5668722391128540e-01
    z[3,10,3]  R1219     -1.8313533067703247e-01
    z[3,10,3]  R1220     -2.5241750478744507e-01
    z[3,10,3]  R1221     -2.4784231185913086e-01
    z[3,10,3]  R1222     3.5779255628585815e-01
    z[3,10,3]  R1223     0.0634353756904602
    z[3,10,3]  R1224     -2.4863202869892120e-01
    z[3,10,3]  R1225     -4.5533329248428345e-02
    z[3,10,3]  R1226     -6.9684617221355438e-02
    z[3,10,3]  R1227     0.764371395111084
    z[3,10,3]  R1228     0.745017409324646
    z[3,10,3]  R1229     -4.9989512562751770e-01
    z[3,10,3]  R1230     7.1240496635437012e-01
    z[3,10,3]  R1231     6.2345904111862183e-01
    z[3,10,3]  R1232     -2.2300015389919281e-01
    z[3,10,3]  R1233     0.681239128112793
    z[3,10,3]  R1234     0.60472571849823
    z[3,10,3]  R1235     6.0739618539810181e-01
    z[3,10,3]  R1236     5.0476962327957153e-01
    z[3,10,3]  R1237     7.8265631198883057e-01
    z[3,10,3]  R1238     7.2275739908218384e-01
    z[3,10,3]  R1239     2.7796402573585510e-01
    z[3,10,3]  R1240     3.9726930856704712e-01
    z[3,10,3]  R1241     1.5290898084640503e-01
    z[3,10,3]  R1242     4.6916228532791138e-01
    z[3,10,3]  R1243     -5.4265791177749634e-01
    z[3,10,3]  R1244     -2.4831391870975494e-01
    z[3,10,3]  R1245     -5.9818738698959351e-01
    z[3,10,3]  R1246     -3.9339289069175720e-01
    z[3,10,3]  R1247     -0.0786762535572052
    z[3,10,3]  R1248     3.8056049495935440e-02
    z[3,10,3]  R1249     -2.0746810361742973e-02
    z[3,10,3]  R1250     -8.0624771118164062e-01
    z[3,10,3]  R1251     0.659960150718689
    z[3,10,3]  R1252     -8.2981234788894653e-01
    z[3,10,3]  R1253     -7.2701941244304180e-03
    z[3,10,3]  R1254     -3.7577623128890991e-01
    z[3,10,3]  R1255     -4.4316515326499939e-02
    z[3,10,3]  R1256     1.3924965262413025e-01
    z[3,10,3]  R1257     -2.1064251661300659e-01
    z[3,10,3]  R1258     3.6444085836410522e-01
    z[3,10,3]  R1259     2.8647786378860474e-01
    z[3,10,3]  R1260     -6.1262732744216919e-01
    z[3,10,3]  R1261     -1.9766797125339508e-01
    z[3,10,3]  R1262     -5.6900459527969360e-01
    z[3,10,3]  R1263     2.1127900481224060e-01
    z[3,10,3]  R1264     -9.1145741939544678e-01
    z[3,10,3]  R1265     -8.0859714746475220e-01
    z[3,10,3]  R1266     -7.2537130117416382e-01
    z[3,10,3]  R1267     -5.8372038602828979e-01
    z[3,10,3]  R1268     -4.6204555034637451e-01
    z[3,10,3]  R1269     2.8942093253135681e-01
    z[3,10,3]  R1270     5.1352846622467041e-01
    z[3,10,3]  R1271     -0.468342125415802
    z[3,10,3]  R1272     -5.5705946683883667e-01
    z[3,10,4]  R33       -1
    z[3,10,4]  R96       1
    z[3,10,4]  R1189     -1
    z[3,10,4]  R1190     1
    z[3,10,4]  R1195     2.2628886997699738e-01
    z[3,10,4]  R1196     -2.6916259527206421e-01
    z[3,10,4]  R1197     2.8445419669151306e-01
    z[3,10,4]  R1198     -1.6582595184445381e-02
    z[3,10,4]  R1199     6.2523297965526581e-03
    z[3,10,4]  R1200     4.3712127208709717e-01
    z[3,10,4]  R1201     7.6559692621231079e-02
    z[3,10,4]  R1202     -6.3483619689941406e-01
    z[3,10,4]  R1203     -7.7163302898406982e-01
    z[3,10,4]  R1204     -5.2388721704483032e-01
    z[3,10,4]  R1205     2.4067023769021034e-03
    z[3,10,4]  R1206     0.0366709902882576
    z[3,10,4]  R1207     4.2248047888278961e-02
    z[3,10,4]  R1208     -7.0286847651004791e-02
    z[3,10,4]  R1209     2.3987520486116409e-02
    z[3,10,4]  R1210     4.4759169220924377e-01
    z[3,10,4]  R1211     -3.4284293651580811e-01
    z[3,10,4]  R1212     8.7679319083690643e-02
    z[3,10,4]  R1213     8.8047936558723450e-02
    z[3,10,4]  R1214     1.4458252489566803e-01
    z[3,10,4]  R1215     6.2738835811614990e-02
    z[3,10,4]  R1216     2.5824561715126038e-01
    z[3,10,4]  R1217     3.1630176305770874e-01
    z[3,10,4]  R1218     1.7364698648452759e-01
    z[3,10,4]  R1219     -1.5740180015563965e-01
    z[3,10,4]  R1220     2.8242337703704834e-01
    z[3,10,4]  R1221     -0.374988853931427
    z[3,10,4]  R1222     -1.2066390365362167e-01
    z[3,10,4]  R1223     7.7609471976757050e-02
    z[3,10,4]  R1224     2.2041009366512299e-01
    z[3,10,4]  R1225     4.9515865743160248e-02
    z[3,10,4]  R1226     1.8371193110942841e-01
    z[3,10,4]  R1227     -9.0807870030403137e-02
    z[3,10,4]  R1228     0.341768354177475
    z[3,10,4]  R1229     -5.2788305282592773e-01
    z[3,10,4]  R1230     -2.6208034157752991e-01
    z[3,10,4]  R1231     -4.8843666911125183e-01
    z[3,10,4]  R1232     1.4653810858726501e-01
    z[3,10,4]  R1233     -0.373605340719223
    z[3,10,4]  R1234     -4.2356446385383606e-01
    z[3,10,4]  R1235     -0.398029625415802
    z[3,10,4]  R1236     -4.5387169718742371e-01
    z[3,10,4]  R1237     -2.6355615258216858e-01
    z[3,10,4]  R1238     -2.7197670936584473e-01
    z[3,10,4]  R1239     -2.3760432004928589e-01
    z[3,10,4]  R1240     2.5522655248641968e-01
    z[3,10,4]  R1241     -5.6038123369216919e-01
    z[3,10,4]  R1242     -3.9787578582763672e-01
    z[3,10,4]  R1243     2.4450273811817169e-01
    z[3,10,4]  R1244     0.608993411064148
    z[3,10,4]  R1245     5.3822201490402222e-01
    z[3,10,4]  R1246     7.5127941370010376e-01
    z[3,10,4]  R1247     9.2514185234904289e-03
    z[3,10,4]  R1248     -2.5473731756210327e-01
    z[3,10,4]  R1249     -1.2457814998924732e-02
    z[3,10,4]  R1250     1.0844941437244415e-01
    z[3,10,4]  R1251     -2.1772688627243042e-01
    z[3,10,4]  R1252     1.3864155113697052e-01
    z[3,10,4]  R1253     -7.7451360225677490e-01
    z[3,10,4]  R1254     1.9043922424316406e-02
    z[3,10,4]  R1255     -9.7413694858551025e-01
    z[3,10,4]  R1256     -8.8898915052413940e-01
    z[3,10,4]  R1257     -6.9305545091629028e-01
    z[3,10,4]  R1258     -3.1474456191062927e-01
    z[3,10,4]  R1259     -6.7333787679672241e-01
    z[3,10,4]  R1260     2.5464621186256409e-01
    z[3,10,4]  R1261     -2.3097757995128632e-01
    z[3,10,4]  R1262     6.5534484386444092e-01
    z[3,10,4]  R1263     -8.8822716474533081e-01
    z[3,10,4]  R1264     2.6076236367225647e-01
    z[3,10,4]  R1265     5.9483081102371216e-02
    z[3,10,4]  R1266     6.3341581821441650e-01
    z[3,10,4]  R1267     3.4353023767471313e-01
    z[3,10,4]  R1268     5.9049171209335327e-01
    z[3,10,4]  R1269     3.7947988510131836e-01
    z[3,10,4]  R1270     4.8621911555528641e-02
    z[3,10,4]  R1271     7.9095101356506348e-01
    z[3,10,4]  R1272     1.3062059879302979e-01
    z[3,10,5]  R34       -1
    z[3,10,5]  R97       1
    z[3,10,5]  R1191     -1
    z[3,10,5]  R1192     1
    z[3,10,5]  R1195     -6.0272864997386932e-02
    z[3,10,5]  R1196     5.2378200925886631e-03
    z[3,10,5]  R1197     -2.4463790655136108e-01
    z[3,10,5]  R1198     5.4991978406906128e-01
    z[3,10,5]  R1199     7.6349325478076935e-02
    z[3,10,5]  R1200     6.2419414520263672e-01
    z[3,10,5]  R1201     9.5532253384590149e-02
    z[3,10,5]  R1202     -2.0367403328418732e-01
    z[3,10,5]  R1203     -1.3126057386398315e-01
    z[3,10,5]  R1204     -9.7383596003055573e-03
    z[3,10,5]  R1205     -2.2481042146682739e-01
    z[3,10,5]  R1206     -2.5774425268173218e-01
    z[3,10,5]  R1207     -1.6966257989406586e-01
    z[3,10,5]  R1208     -0.244800865650177
    z[3,10,5]  R1209     3.4857827425003052e-01
    z[3,10,5]  R1210     -1.6361238434910774e-02
    z[3,10,5]  R1211     -1.2094871699810028e-01
    z[3,10,5]  R1212     2.1043597161769867e-01
    z[3,10,5]  R1213     3.9162391424179077e-01
    z[3,10,5]  R1214     -1.0682401806116104e-01
    z[3,10,5]  R1215     -1.7073659598827362e-01
    z[3,10,5]  R1216     1.2148747593164444e-01
    z[3,10,5]  R1217     1.3128049671649933e-01
    z[3,10,5]  R1218     2.2975887358188629e-01
    z[3,10,5]  R1219     5.1292762160301208e-02
    z[3,10,5]  R1220     5.4597463458776474e-02
    z[3,10,5]  R1221     1.5197399258613586e-01
    z[3,10,5]  R1222     -1.5045249462127686e-01
    z[3,10,5]  R1223     1.0198665410280228e-01
    z[3,10,5]  R1224     -3.8891077041625977e-01
    z[3,10,5]  R1225     1.7021405696868896e-01
    z[3,10,5]  R1226     -0.256853312253952
    z[3,10,5]  R1227     2.6179185137152672e-02
    z[3,10,5]  R1228     -3.5139527916908264e-01
    z[3,10,5]  R1229     1.7495891451835632e-01
    z[3,10,5]  R1230     -1.4328850805759430e-01
    z[3,10,5]  R1231     2.0163874328136444e-01
    z[3,10,5]  R1232     1.7113395035266876e-01
    z[3,10,5]  R1233     2.1554559469223022e-01
    z[3,10,5]  R1234     0.526763379573822
    z[3,10,5]  R1235     2.4247248470783234e-01
    z[3,10,5]  R1236     4.0691789984703064e-01
    z[3,10,5]  R1237     8.9430719614028931e-02
    z[3,10,5]  R1238     2.4368791282176971e-01
    z[3,10,5]  R1239     6.6027349233627319e-01
    z[3,10,5]  R1240     6.5822386741638184e-01
    z[3,10,5]  R1241     3.9039081335067749e-01
    z[3,10,5]  R1242     -5.4581277072429657e-03
    z[3,10,5]  R1243     -1.6746070981025696e-01
    z[3,10,5]  R1244     -3.0789282917976379e-01
    z[3,10,5]  R1245     6.6035546362400055e-02
    z[3,10,5]  R1246     -7.0266634225845337e-02
    z[3,10,5]  R1247     6.1950433254241943e-01
    z[3,10,5]  R1248     4.0019720792770386e-01
    z[3,10,5]  R1249     2.5226727128028870e-01
    z[3,10,5]  R1250     -2.4337185919284821e-01
    z[3,10,5]  R1251     -2.9784369468688965e-01
    z[3,10,5]  R1252     -3.6523076891899109e-01
    z[3,10,5]  R1253     -4.7111743688583374e-01
    z[3,10,5]  R1254     -2.3197950422763824e-01
    z[3,10,5]  R1255     9.6717111766338348e-02
    z[3,10,5]  R1256     -7.5587600469589233e-02
    z[3,10,5]  R1257     3.7458430975675583e-02
    z[3,10,5]  R1258     -3.5075005888938904e-01
    z[3,10,5]  R1259     -5.9254580736160278e-01
    z[3,10,5]  R1260     -1.3819037377834320e-01
    z[3,10,5]  R1261     -1.7041382193565369e-01
    z[3,10,5]  R1262     -0.178700253367424
    z[3,10,5]  R1263     -3.0035126209259033e-01
    z[3,10,5]  R1264     0.00954553671181202
    z[3,10,5]  R1265     -0.50865638256073
    z[3,10,5]  R1266     -1.3811635971069336e-01
    z[3,10,5]  R1267     -2.9512956738471985e-01
    z[3,10,5]  R1268     -5.0582069158554077e-01
    z[3,10,5]  R1269     2.9561811685562134e-01
    z[3,10,5]  R1270     -2.2971833124756813e-02
    z[3,10,5]  R1271     -2.9978886246681213e-01
    z[3,10,5]  R1272     -0.70634526014328
    z[3,10,6]  R35       -1
    z[3,10,6]  R98       1
    z[3,10,6]  R1193     -1
    z[3,10,6]  R1194     1
    z[3,10,6]  R1195     2.3065450787544250e-01
    z[3,10,6]  R1196     -2.2433733940124512e-01
    z[3,10,6]  R1197     9.5027135685086250e-03
    z[3,10,6]  R1198     -3.0451586842536926e-01
    z[3,10,6]  R1199     4.0011522173881531e-01
    z[3,10,6]  R1200     -9.0896666049957275e-02
    z[3,10,6]  R1201     4.7414788603782654e-01
    z[3,10,6]  R1202     3.8322679698467255e-02
    z[3,10,6]  R1203     9.8887398838996887e-02
    z[3,10,6]  R1204     5.5091398954391479e-01
    z[3,10,6]  R1205     -3.1023567914962769e-01
    z[3,10,6]  R1206     -2.6245719194412231e-01
    z[3,10,6]  R1207     -3.0436590313911438e-01
    z[3,10,6]  R1208     -4.6823951601982117e-01
    z[3,10,6]  R1209     -2.9056310653686523e-01
    z[3,10,6]  R1210     -2.0337577164173126e-01
    z[3,10,6]  R1211     2.0055323839187622e-01
    z[3,10,6]  R1212     9.4782322645187378e-02
    z[3,10,6]  R1213     -2.7302485704421997e-01
    z[3,10,6]  R1214     -7.0345097780227661e-01
    z[3,10,6]  R1215     -0.365187406539917
    z[3,10,6]  R1216     2.4529822170734406e-01
    z[3,10,6]  R1217     -1.5396726131439209e-01
    z[3,10,6]  R1218     1.1342352628707886e-01
    z[3,10,6]  R1219     1.6710974276065826e-01
    z[3,10,6]  R1220     1.0853295773267746e-01
    z[3,10,6]  R1221     0.0305503997951746
    z[3,10,6]  R1222     8.9628294110298157e-02
    z[3,10,6]  R1223     1.7342561483383179e-01
    z[3,10,6]  R1224     2.1724744141101837e-01
    z[3,10,6]  R1225     -2.5142121315002441e-01
    z[3,10,6]  R1226     3.6345383524894714e-01
    z[3,10,6]  R1227     -3.0564209818840027e-01
    z[3,10,6]  R1228     4.7692552208900452e-02
    z[3,10,6]  R1229     5.6257343292236328e-01
    z[3,10,6]  R1230     0.313156396150589
    z[3,10,6]  R1231     2.4942032992839813e-01
    z[3,10,6]  R1232     -5.1320254802703857e-01
    z[3,10,6]  R1233     3.1115907430648804e-01
    z[3,10,6]  R1234     2.2180373966693878e-01
    z[3,10,6]  R1235     -2.1379025280475616e-01
    z[3,10,6]  R1236     -2.0424191653728485e-01
    z[3,10,6]  R1237     2.5111040472984314e-01
    z[3,10,6]  R1238     -2.2403696179389954e-01
    z[3,10,6]  R1239     1.4899879693984985e-01
    z[3,10,6]  R1240     2.7462151646614075e-01
    z[3,10,6]  R1241     2.3706594482064247e-02
    z[3,10,6]  R1242     4.6787819266319275e-01
    z[3,10,6]  R1243     -6.4719456434249878e-01
    z[3,10,6]  R1244     -6.5354377031326294e-01
    z[3,10,6]  R1245     -1.4812734723091125e-01
    z[3,10,6]  R1246     0.135025292634964
    z[3,10,6]  R1247     1.5096846222877502e-01
    z[3,10,6]  R1248     2.2642095386981964e-01
    z[3,10,6]  R1249     -4.4093031436204910e-02
    z[3,10,6]  R1250     -2.5611397624015808e-01
    z[3,10,6]  R1251     -3.5083033144474030e-02
    z[3,10,6]  R1252     1.0351660847663879e-01
    z[3,10,6]  R1253     0.156805619597435
    z[3,10,6]  R1254     5.0296908617019653e-01
    z[3,10,6]  R1255     -1.0307624936103821e-01
    z[3,10,6]  R1256     2.2044481709599495e-02
    z[3,10,6]  R1257     5.8471059799194336e-01
    z[3,10,6]  R1258     3.5739752650260925e-01
    z[3,10,6]  R1259     -3.0509757995605469e-01
    z[3,10,6]  R1260     -1.1545576900243759e-01
    z[3,10,6]  R1261     -0.00886712409555912
    z[3,10,6]  R1262     2.6179659366607666e-01
    z[3,10,6]  R1263     1.6377250850200653e-01
    z[3,10,6]  R1264     1.6131460666656494e-01
    z[3,10,6]  R1265     -0.0995606854557991
    z[3,10,6]  R1266     -1.2396887689828873e-01
    z[3,10,6]  R1267     -3.1050941348075867e-01
    z[3,10,6]  R1268     -2.5741836428642273e-01
    z[3,10,6]  R1269     -2.6364496350288391e-01
    z[3,10,6]  R1270     -0.352649450302124
    z[3,10,6]  R1271     -2.1015355363488197e-02
    z[3,10,6]  R1272     2.6889881491661072e-01
    z[10,3,0]  R29       1
    z[10,3,0]  R92       -1
    z[10,3,0]  R1273     -1
    z[10,3,0]  R1274     1
    z[10,3,0]  R1287     -3.9636448025703430e-01
    z[10,3,0]  R1288     -2.1843071281909943e-01
    z[10,3,0]  R1289     -5.5052655935287476e-01
    z[10,3,0]  R1290     -5.1393687725067139e-02
    z[10,3,0]  R1291     -1.1332868784666061e-01
    z[10,3,0]  R1292     -1.8592710793018341e-01
    z[10,3,0]  R1293     3.6510050296783447e-01
    z[10,3,0]  R1294     2.6070839166641235e-01
    z[10,3,0]  R1295     -1.9142383709549904e-02
    z[10,3,0]  R1296     -4.2343366146087646e-01
    z[10,3,0]  R1297     4.0896305441856384e-01
    z[10,3,0]  R1298     -9.6639342606067657e-02
    z[10,3,0]  R1299     -4.7348892688751221e-01
    z[10,3,0]  R1300     -1.7088831961154938e-01
    z[10,3,0]  R1301     -1.2774877250194550e-02
    z[10,3,0]  R1302     2.2630387544631958e-01
    z[10,3,0]  R1303     1.8719108402729034e-01
    z[10,3,0]  R1304     -3.3848896622657776e-01
    z[10,3,0]  R1305     6.2727910280227661e-01
    z[10,3,0]  R1306     -3.6651602387428284e-01
    z[10,3,0]  R1307     -9.5985263586044312e-02
    z[10,3,0]  R1308     1.1450875550508499e-01
    z[10,3,0]  R1309     1.0657140612602234e-01
    z[10,3,0]  R1310     2.9993700981140137e-01
    z[10,3,0]  R1311     -3.0955451726913452e-01
    z[10,3,0]  R1312     -5.6630626320838928e-02
    z[10,3,0]  R1313     2.1666556596755981e-02
    z[10,3,0]  R1314     4.6906974911689758e-01
    z[10,3,0]  R1315     -7.2263628244400024e-01
    z[10,3,0]  R1316     -3.6497896909713745e-01
    z[10,3,0]  R1317     -1.9985330104827881e-01
    z[10,3,0]  R1318     -3.8029614835977554e-02
    z[10,3,0]  R1319     -2.6851644739508629e-02
    z[10,3,0]  R1320     1.5648564696311951e-01
    z[10,3,0]  R1321     5.9689271450042725e-01
    z[10,3,0]  R1322     2.2789795696735382e-01
    z[10,3,0]  R1323     -2.8174072504043579e-01
    z[10,3,0]  R1324     6.2675297260284424e-01
    z[10,3,0]  R1325     -3.2631557434797287e-02
    z[10,3,0]  R1326     5.2217852324247360e-02
    z[10,3,0]  R1327     -6.5310436487197876e-01
    z[10,3,0]  R1328     -7.3012202978134155e-01
    z[10,3,0]  R1329     -8.1839954853057861e-01
    z[10,3,0]  R1330     -7.1401822566986084e-01
    z[10,3,0]  R1331     0.153198704123497
    z[10,3,0]  R1332     -6.0081088542938232e-01
    z[10,3,0]  R1333     7.1688795089721680e-01
    z[10,3,0]  R1334     2.3340252041816711e-01
    z[10,3,0]  R1335     4.9905306100845337e-01
    z[10,3,0]  R1336     2.5812390446662903e-01
    z[10,3,0]  R1337     2.7214249968528748e-01
    z[10,3,0]  R1338     0.531776487827301
    z[10,3,0]  R1339     5.4017448425292969e-01
    z[10,3,0]  R1340     3.8133546710014343e-01
    z[10,3,0]  R1341     5.2057379484176636e-01
    z[10,3,0]  R1342     5.9864956140518188e-01
    z[10,3,0]  R1343     0.365446001291275
    z[10,3,0]  R1344     5.5695241689682007e-01
    z[10,3,0]  R1345     2.8284192085266113e-01
    z[10,3,0]  R1346     1.7235065996646881e-01
    z[10,3,0]  R1347     -4.2859369516372681e-01
    z[10,3,0]  R1348     5.8471912145614624e-01
    z[10,3,0]  R1349     0.627866804599762
    z[10,3,0]  R1350     6.2033843994140625e-01
    z[10,3,0]  R1351     5.3637397289276123e-01
    z[10,3,0]  R1352     5.6048560142517090e-01
    z[10,3,0]  R1353     5.8017802238464355e-01
    z[10,3,0]  R1354     6.1862134933471680e-01
    z[10,3,0]  R1355     3.5152587294578552e-01
    z[10,3,0]  R1356     6.4129203557968140e-01
    z[10,3,0]  R1357     4.6803352236747742e-01
    z[10,3,0]  R1358     5.8159804344177246e-01
    z[10,3,0]  R1359     4.9010065197944641e-01
    z[10,3,0]  R1360     2.0241326093673706e-01
    z[10,3,0]  R1361     -0.188896045088768
    z[10,3,0]  R1362     -9.8122563213109970e-03
    z[10,3,0]  R1363     0.0203165952116251
    z[10,3,0]  R1364     3.1710234284400940e-01
    z[10,3,1]  R30       1
    z[10,3,1]  R93       -1
    z[10,3,1]  R1275     -1
    z[10,3,1]  R1276     1
    z[10,3,1]  R1287     -1.0856962949037552e-01
    z[10,3,1]  R1288     1.5542726218700409e-01
    z[10,3,1]  R1289     -1.1899171397089958e-02
    z[10,3,1]  R1290     -7.4997544288635254e-02
    z[10,3,1]  R1291     4.1021695733070374e-01
    z[10,3,1]  R1292     -3.9665222167968750e-02
    z[10,3,1]  R1293     4.5404410362243652e-01
    z[10,3,1]  R1294     4.4423744082450867e-01
    z[10,3,1]  R1295     2.4021776020526886e-01
    z[10,3,1]  R1296     4.6866810321807861e-01
    z[10,3,1]  R1297     1.7533724009990692e-01
    z[10,3,1]  R1298     1.4846704900264740e-01
    z[10,3,1]  R1299     -2.9659056663513184e-01
    z[10,3,1]  R1300     -4.6645447611808777e-01
    z[10,3,1]  R1301     -7.6093202829360962e-01
    z[10,3,1]  R1302     -7.7744621038436890e-01
    z[10,3,1]  R1303     -9.4802898168563843e-01
    z[10,3,1]  R1304     -3.0477842688560486e-01
    z[10,3,1]  R1305     -1.8231703341007233e-01
    z[10,3,1]  R1306     0.0208007600158453
    z[10,3,1]  R1307     -0.379312664270401
    z[10,3,1]  R1308     6.0360127687454224e-01
    z[10,3,1]  R1309     -1.1329365521669388e-01
    z[10,3,1]  R1310     -3.0436906218528748e-01
    z[10,3,1]  R1311     2.7989361435174942e-02
    z[10,3,1]  R1312     0.67806077003479
    z[10,3,1]  R1313     1.3304229080677032e-01
    z[10,3,1]  R1314     -5.4952919483184814e-01
    z[10,3,1]  R1315     5.9685826301574707e-01
    z[10,3,1]  R1316     7.9292759299278259e-02
    z[10,3,1]  R1317     -6.0732532292604446e-02
    z[10,3,1]  R1318     -1.7408357560634613e-01
    z[10,3,1]  R1319     2.4137814342975616e-01
    z[10,3,1]  R1320     -3.1413719058036804e-02
    z[10,3,1]  R1321     -2.7527580037713051e-02
    z[10,3,1]  R1322     8.8575951755046844e-02
    z[10,3,1]  R1323     -5.5882513523101807e-01
    z[10,3,1]  R1324     0.430237740278244
    z[10,3,1]  R1325     -6.8249548785388470e-03
    z[10,3,1]  R1326     -2.4141646921634674e-01
    z[10,3,1]  R1327     5.8178991079330444e-01
    z[10,3,1]  R1328     4.7476023435592651e-01
    z[10,3,1]  R1329     -2.7540719509124756e-01
    z[10,3,1]  R1330     -2.4982862174510956e-01
    z[10,3,1]  R1331     6.0271453857421875e-01
    z[10,3,1]  R1332     1.2983238697052002e-01
    z[10,3,1]  R1333     -7.5340755283832550e-02
    z[10,3,1]  R1334     4.8387479782104492e-01
    z[10,3,1]  R1335     3.0697804689407349e-01
    z[10,3,1]  R1336     5.3865957260131836e-01
    z[10,3,1]  R1337     -5.1415318250656128e-01
    z[10,3,1]  R1338     -7.2146528959274292e-01
    z[10,3,1]  R1339     -6.8546158075332642e-01
    z[10,3,1]  R1340     -7.5014483928680420e-01
    z[10,3,1]  R1341     -6.3469791412353516e-01
    z[10,3,1]  R1342     -5.6650543212890625e-01
    z[10,3,1]  R1343     -8.0281686782836914e-01
    z[10,3,1]  R1344     -6.2422585487365723e-01
    z[10,3,1]  R1345     -6.1908406019210815e-01
    z[10,3,1]  R1346     -2.0034465193748474e-01
    z[10,3,1]  R1347     -3.3841341733932495e-01
    z[10,3,1]  R1348     -7.0923173427581787e-01
    z[10,3,1]  R1349     -6.5544891357421875e-01
    z[10,3,1]  R1350     -6.6866677999496460e-01
    z[10,3,1]  R1351     -7.2253215312957764e-01
    z[10,3,1]  R1352     -0.651892900466919
    z[10,3,1]  R1353     -6.3286352157592773e-01
    z[10,3,1]  R1354     -5.8157765865325928e-01
    z[10,3,1]  R1355     -0.886976957321167
    z[10,3,1]  R1356     -5.1137030124664307e-01
    z[10,3,1]  R1357     -7.9289269447326660e-01
    z[10,3,1]  R1358     -6.3307863473892212e-01
    z[10,3,1]  R1359     -2.2521585226058960e-01
    z[10,3,1]  R1360     -4.0167921781539917e-01
    z[10,3,1]  R1361     -2.7031752467155457e-01
    z[10,3,1]  R1362     -5.2839994430541992e-01
    z[10,3,1]  R1363     -5.1613306999206543e-01
    z[10,3,1]  R1364     6.9041180610656738e-01
    z[10,3,2]  R31       1
    z[10,3,2]  R94       -1
    z[10,3,2]  R1277     -1
    z[10,3,2]  R1278     1
    z[10,3,2]  R1287     -2.9010385274887085e-01
    z[10,3,2]  R1288     -2.3738962411880493e-01
    z[10,3,2]  R1289     -2.5479811429977417e-01
    z[10,3,2]  R1290     -5.6889832019805908e-01
    z[10,3,2]  R1291     -2.5653791427612305e-01
    z[10,3,2]  R1292     -5.0786983966827393e-01
    z[10,3,2]  R1293     2.6203829050064087e-01
    z[10,3,2]  R1294     5.5182456970214844e-02
    z[10,3,2]  R1295     -6.7197734117507935e-01
    z[10,3,2]  R1296     6.0794495046138763e-02
    z[10,3,2]  R1297     2.9034504666924477e-02
    z[10,3,2]  R1298     1.1902976036071777e-01
    z[10,3,2]  R1299     1.1844386905431747e-01
    z[10,3,2]  R1300     -1.0425622761249542e-01
    z[10,3,2]  R1301     8.9256383478641510e-02
    z[10,3,2]  R1302     2.5807061791419983e-01
    z[10,3,2]  R1303     -0.00564618781208992
    z[10,3,2]  R1304     -7.6905570924282074e-02
    z[10,3,2]  R1305     1.9678516313433647e-02
    z[10,3,2]  R1306     1.1538688093423843e-01
    z[10,3,2]  R1307     -2.1094707772135735e-02
    z[10,3,2]  R1308     4.1736122965812683e-01
    z[10,3,2]  R1309     7.0153094828128815e-02
    z[10,3,2]  R1310     -3.8802798837423325e-02
    z[10,3,2]  R1311     1.8816716969013214e-01
    z[10,3,2]  R1312     2.3320975899696350e-01
    z[10,3,2]  R1313     -4.6710226684808731e-02
    z[10,3,2]  R1314     7.3537260293960571e-02
    z[10,3,2]  R1315     -3.7699963431805372e-03
    z[10,3,2]  R1316     -8.2393847405910492e-02
    z[10,3,2]  R1317     -7.5839266180992126e-02
    z[10,3,2]  R1318     2.0828737318515778e-01
    z[10,3,2]  R1319     1.2249260395765305e-01
    z[10,3,2]  R1320     -1.1270281672477722e-01
    z[10,3,2]  R1321     -2.6481010019779205e-02
    z[10,3,2]  R1322     -2.3649835586547852e-01
    z[10,3,2]  R1323     -4.7293606400489807e-01
    z[10,3,2]  R1324     -1.7638376355171204e-01
    z[10,3,2]  R1325     -2.5224119424819946e-01
    z[10,3,2]  R1326     2.0095808804035187e-01
    z[10,3,2]  R1327     -2.0417949557304382e-01
    z[10,3,2]  R1328     -3.4446725249290466e-01
    z[10,3,2]  R1329     -3.3685794472694397e-01
    z[10,3,2]  R1330     -1.9678533077239990e-02
    z[10,3,2]  R1331     0.06800577044487
    z[10,3,2]  R1332     1.6934520006179810e-01
    z[10,3,2]  R1333     3.1749528646469116e-01
    z[10,3,2]  R1334     -1.9265535473823547e-01
    z[10,3,2]  R1335     -0.0784771665930748
    z[10,3,2]  R1336     -4.8448212444782257e-02
    z[10,3,2]  R1337     2.8500853106379509e-02
    z[10,3,2]  R1338     -1.5785014629364014e-01
    z[10,3,2]  R1339     -1.7656792700290680e-01
    z[10,3,2]  R1340     0.0232391320168972
    z[10,3,2]  R1341     -1.0151895135641098e-01
    z[10,3,2]  R1342     -2.4404411017894745e-01
    z[10,3,2]  R1343     -2.2070296108722687e-01
    z[10,3,2]  R1344     -4.8843196034431458e-01
    z[10,3,2]  R1345     -2.0805369317531586e-01
    z[10,3,2]  R1346     4.2685028165578842e-02
    z[10,3,2]  R1347     -1.9409951567649841e-01
    z[10,3,2]  R1348     -2.8021706268191338e-02
    z[10,3,2]  R1349     5.2486073225736618e-02
    z[10,3,2]  R1350     -7.9806774854660034e-02
    z[10,3,2]  R1351     -3.1840169429779053e-01
    z[10,3,2]  R1352     3.2039615511894226e-01
    z[10,3,2]  R1353     1.9184727966785431e-01
    z[10,3,2]  R1354     -3.2531636953353882e-01
    z[10,3,2]  R1355     1.9793011248111725e-01
    z[10,3,2]  R1356     1.3564078509807587e-01
    z[10,3,2]  R1357     2.3570168018341064e-01
    z[10,3,2]  R1358     1.5581017732620239e-01
    z[10,3,2]  R1359     1.4989016950130463e-01
    z[10,3,2]  R1360     -8.5404375568032265e-03
    z[10,3,2]  R1361     -1.2486571818590164e-01
    z[10,3,2]  R1362     -1.6090908646583557e-01
    z[10,3,2]  R1363     -5.5259462445974350e-02
    z[10,3,2]  R1364     2.4271681904792786e-01
    z[10,3,3]  R32       1
    z[10,3,3]  R95       -1
    z[10,3,3]  R1279     -1
    z[10,3,3]  R1280     1
    z[10,3,3]  R1287     0.681239128112793
    z[10,3,3]  R1288     0.60472571849823
    z[10,3,3]  R1289     6.0739618539810181e-01
    z[10,3,3]  R1290     5.0476962327957153e-01
    z[10,3,3]  R1291     7.8265631198883057e-01
    z[10,3,3]  R1292     7.2275739908218384e-01
    z[10,3,3]  R1293     2.7796402573585510e-01
    z[10,3,3]  R1294     3.9726930856704712e-01
    z[10,3,3]  R1295     1.5290898084640503e-01
    z[10,3,3]  R1296     4.6916228532791138e-01
    z[10,3,3]  R1297     -5.4265791177749634e-01
    z[10,3,3]  R1298     -2.4831391870975494e-01
    z[10,3,3]  R1299     -5.9818738698959351e-01
    z[10,3,3]  R1300     -3.9339289069175720e-01
    z[10,3,3]  R1301     -0.0786762535572052
    z[10,3,3]  R1302     3.8056049495935440e-02
    z[10,3,3]  R1303     -2.0746810361742973e-02
    z[10,3,3]  R1304     -8.0624771118164062e-01
    z[10,3,3]  R1305     0.659960150718689
    z[10,3,3]  R1306     -8.2981234788894653e-01
    z[10,3,3]  R1307     -7.2701941244304180e-03
    z[10,3,3]  R1308     -3.7577623128890991e-01
    z[10,3,3]  R1309     -4.4316515326499939e-02
    z[10,3,3]  R1310     1.3924965262413025e-01
    z[10,3,3]  R1311     -2.1064251661300659e-01
    z[10,3,3]  R1312     3.6444085836410522e-01
    z[10,3,3]  R1313     2.8647786378860474e-01
    z[10,3,3]  R1314     -6.1262732744216919e-01
    z[10,3,3]  R1315     -1.9766797125339508e-01
    z[10,3,3]  R1316     -5.6900459527969360e-01
    z[10,3,3]  R1317     2.1127900481224060e-01
    z[10,3,3]  R1318     -9.1145741939544678e-01
    z[10,3,3]  R1319     -8.0859714746475220e-01
    z[10,3,3]  R1320     -7.2537130117416382e-01
    z[10,3,3]  R1321     -5.8372038602828979e-01
    z[10,3,3]  R1322     -4.6204555034637451e-01
    z[10,3,3]  R1323     2.8942093253135681e-01
    z[10,3,3]  R1324     5.1352846622467041e-01
    z[10,3,3]  R1325     -0.468342125415802
    z[10,3,3]  R1326     -5.5705946683883667e-01
    z[10,3,3]  R1327     -2.9196754097938538e-01
    z[10,3,3]  R1328     -7.9768812283873558e-03
    z[10,3,3]  R1329     6.8975519388914108e-03
    z[10,3,3]  R1330     -0.17877297103405
    z[10,3,3]  R1331     6.6534203290939331e-01
    z[10,3,3]  R1332     0.0673535093665123
    z[10,3,3]  R1333     3.7388241291046143e-01
    z[10,3,3]  R1334     4.7781109809875488e-01
    z[10,3,3]  R1335     -1.6770860552787781e-01
    z[10,3,3]  R1336     -2.5062268972396851e-01
    z[10,3,3]  R1337     -7.1692460775375366e-01
    z[10,3,3]  R1338     1.8741454184055328e-01
    z[10,3,3]  R1339     -2.8977379202842712e-01
    z[10,3,3]  R1340     -8.4911346435546875e-02
    z[10,3,3]  R1341     -3.3067530393600464e-01
    z[10,3,3]  R1342     -1.3843837380409241e-01
    z[10,3,3]  R1343     -2.8861805796623230e-02
    z[10,3,3]  R1344     -2.5015437975525856e-02
    z[10,3,3]  R1345     5.0772500038146973e-01
    z[10,3,3]  R1346     6.3338494300842285e-01
    z[10,3,3]  R1347     -7.0545035600662231e-01
    z[10,3,3]  R1348     -1.1263841390609741e-01
    z[10,3,3]  R1349     -1.8007743358612061e-01
    z[10,3,3]  R1350     2.5668722391128540e-01
    z[10,3,3]  R1351     -1.8313533067703247e-01
    z[10,3,3]  R1352     -2.5241750478744507e-01
    z[10,3,3]  R1353     -2.4784231185913086e-01
    z[10,3,3]  R1354     3.5779255628585815e-01
    z[10,3,3]  R1355     0.0634353756904602
    z[10,3,3]  R1356     -2.4863202869892120e-01
    z[10,3,3]  R1357     -4.5533329248428345e-02
    z[10,3,3]  R1358     -6.9684617221355438e-02
    z[10,3,3]  R1359     0.764371395111084
    z[10,3,3]  R1360     0.745017409324646
    z[10,3,3]  R1361     -4.9989512562751770e-01
    z[10,3,3]  R1362     7.1240496635437012e-01
    z[10,3,3]  R1363     6.2345904111862183e-01
    z[10,3,3]  R1364     -2.2300015389919281e-01
    z[10,3,4]  R33       1
    z[10,3,4]  R96       -1
    z[10,3,4]  R1281     -1
    z[10,3,4]  R1282     1
    z[10,3,4]  R1287     -0.373605340719223
    z[10,3,4]  R1288     -4.2356446385383606e-01
    z[10,3,4]  R1289     -0.398029625415802
    z[10,3,4]  R1290     -4.5387169718742371e-01
    z[10,3,4]  R1291     -2.6355615258216858e-01
    z[10,3,4]  R1292     -2.7197670936584473e-01
    z[10,3,4]  R1293     -2.3760432004928589e-01
    z[10,3,4]  R1294     2.5522655248641968e-01
    z[10,3,4]  R1295     -5.6038123369216919e-01
    z[10,3,4]  R1296     -3.9787578582763672e-01
    z[10,3,4]  R1297     2.4450273811817169e-01
    z[10,3,4]  R1298     0.608993411064148
    z[10,3,4]  R1299     5.3822201490402222e-01
    z[10,3,4]  R1300     7.5127941370010376e-01
    z[10,3,4]  R1301     9.2514185234904289e-03
    z[10,3,4]  R1302     -2.5473731756210327e-01
    z[10,3,4]  R1303     -1.2457814998924732e-02
    z[10,3,4]  R1304     1.0844941437244415e-01
    z[10,3,4]  R1305     -2.1772688627243042e-01
    z[10,3,4]  R1306     1.3864155113697052e-01
    z[10,3,4]  R1307     -7.7451360225677490e-01
    z[10,3,4]  R1308     1.9043922424316406e-02
    z[10,3,4]  R1309     -9.7413694858551025e-01
    z[10,3,4]  R1310     -8.8898915052413940e-01
    z[10,3,4]  R1311     -6.9305545091629028e-01
    z[10,3,4]  R1312     -3.1474456191062927e-01
    z[10,3,4]  R1313     -6.7333787679672241e-01
    z[10,3,4]  R1314     2.5464621186256409e-01
    z[10,3,4]  R1315     -2.3097757995128632e-01
    z[10,3,4]  R1316     6.5534484386444092e-01
    z[10,3,4]  R1317     -8.8822716474533081e-01
    z[10,3,4]  R1318     2.6076236367225647e-01
    z[10,3,4]  R1319     5.9483081102371216e-02
    z[10,3,4]  R1320     6.3341581821441650e-01
    z[10,3,4]  R1321     3.4353023767471313e-01
    z[10,3,4]  R1322     5.9049171209335327e-01
    z[10,3,4]  R1323     3.7947988510131836e-01
    z[10,3,4]  R1324     4.8621911555528641e-02
    z[10,3,4]  R1325     7.9095101356506348e-01
    z[10,3,4]  R1326     1.3062059879302979e-01
    z[10,3,4]  R1327     2.2628886997699738e-01
    z[10,3,4]  R1328     -2.6916259527206421e-01
    z[10,3,4]  R1329     2.8445419669151306e-01
    z[10,3,4]  R1330     -1.6582595184445381e-02
    z[10,3,4]  R1331     6.2523297965526581e-03
    z[10,3,4]  R1332     4.3712127208709717e-01
    z[10,3,4]  R1333     7.6559692621231079e-02
    z[10,3,4]  R1334     -6.3483619689941406e-01
    z[10,3,4]  R1335     -7.7163302898406982e-01
    z[10,3,4]  R1336     -5.2388721704483032e-01
    z[10,3,4]  R1337     2.4067023769021034e-03
    z[10,3,4]  R1338     0.0366709902882576
    z[10,3,4]  R1339     4.2248047888278961e-02
    z[10,3,4]  R1340     -7.0286847651004791e-02
    z[10,3,4]  R1341     2.3987520486116409e-02
    z[10,3,4]  R1342     4.4759169220924377e-01
    z[10,3,4]  R1343     -3.4284293651580811e-01
    z[10,3,4]  R1344     8.7679319083690643e-02
    z[10,3,4]  R1345     8.8047936558723450e-02
    z[10,3,4]  R1346     1.4458252489566803e-01
    z[10,3,4]  R1347     6.2738835811614990e-02
    z[10,3,4]  R1348     2.5824561715126038e-01
    z[10,3,4]  R1349     3.1630176305770874e-01
    z[10,3,4]  R1350     1.7364698648452759e-01
    z[10,3,4]  R1351     -1.5740180015563965e-01
    z[10,3,4]  R1352     2.8242337703704834e-01
    z[10,3,4]  R1353     -0.374988853931427
    z[10,3,4]  R1354     -1.2066390365362167e-01
    z[10,3,4]  R1355     7.7609471976757050e-02
    z[10,3,4]  R1356     2.2041009366512299e-01
    z[10,3,4]  R1357     4.9515865743160248e-02
    z[10,3,4]  R1358     1.8371193110942841e-01
    z[10,3,4]  R1359     -9.0807870030403137e-02
    z[10,3,4]  R1360     0.341768354177475
    z[10,3,4]  R1361     -5.2788305282592773e-01
    z[10,3,4]  R1362     -2.6208034157752991e-01
    z[10,3,4]  R1363     -4.8843666911125183e-01
    z[10,3,4]  R1364     1.4653810858726501e-01
    z[10,3,5]  R34       1
    z[10,3,5]  R97       -1
    z[10,3,5]  R1283     -1
    z[10,3,5]  R1284     1
    z[10,3,5]  R1287     2.1554559469223022e-01
    z[10,3,5]  R1288     0.526763379573822
    z[10,3,5]  R1289     2.4247248470783234e-01
    z[10,3,5]  R1290     4.0691789984703064e-01
    z[10,3,5]  R1291     8.9430719614028931e-02
    z[10,3,5]  R1292     2.4368791282176971e-01
    z[10,3,5]  R1293     6.6027349233627319e-01
    z[10,3,5]  R1294     6.5822386741638184e-01
    z[10,3,5]  R1295     3.9039081335067749e-01
    z[10,3,5]  R1296     -5.4581277072429657e-03
    z[10,3,5]  R1297     -1.6746070981025696e-01
    z[10,3,5]  R1298     -3.0789282917976379e-01
    z[10,3,5]  R1299     6.6035546362400055e-02
    z[10,3,5]  R1300     -7.0266634225845337e-02
    z[10,3,5]  R1301     6.1950433254241943e-01
    z[10,3,5]  R1302     4.0019720792770386e-01
    z[10,3,5]  R1303     2.5226727128028870e-01
    z[10,3,5]  R1304     -2.4337185919284821e-01
    z[10,3,5]  R1305     -2.9784369468688965e-01
    z[10,3,5]  R1306     -3.6523076891899109e-01
    z[10,3,5]  R1307     -4.7111743688583374e-01
    z[10,3,5]  R1308     -2.3197950422763824e-01
    z[10,3,5]  R1309     9.6717111766338348e-02
    z[10,3,5]  R1310     -7.5587600469589233e-02
    z[10,3,5]  R1311     3.7458430975675583e-02
    z[10,3,5]  R1312     -3.5075005888938904e-01
    z[10,3,5]  R1313     -5.9254580736160278e-01
    z[10,3,5]  R1314     -1.3819037377834320e-01
    z[10,3,5]  R1315     -1.7041382193565369e-01
    z[10,3,5]  R1316     -0.178700253367424
    z[10,3,5]  R1317     -3.0035126209259033e-01
    z[10,3,5]  R1318     0.00954553671181202
    z[10,3,5]  R1319     -0.50865638256073
    z[10,3,5]  R1320     -1.3811635971069336e-01
    z[10,3,5]  R1321     -2.9512956738471985e-01
    z[10,3,5]  R1322     -5.0582069158554077e-01
    z[10,3,5]  R1323     2.9561811685562134e-01
    z[10,3,5]  R1324     -2.2971833124756813e-02
    z[10,3,5]  R1325     -2.9978886246681213e-01
    z[10,3,5]  R1326     -0.70634526014328
    z[10,3,5]  R1327     -6.0272864997386932e-02
    z[10,3,5]  R1328     5.2378200925886631e-03
    z[10,3,5]  R1329     -2.4463790655136108e-01
    z[10,3,5]  R1330     5.4991978406906128e-01
    z[10,3,5]  R1331     7.6349325478076935e-02
    z[10,3,5]  R1332     6.2419414520263672e-01
    z[10,3,5]  R1333     9.5532253384590149e-02
    z[10,3,5]  R1334     -2.0367403328418732e-01
    z[10,3,5]  R1335     -1.3126057386398315e-01
    z[10,3,5]  R1336     -9.7383596003055573e-03
    z[10,3,5]  R1337     -2.2481042146682739e-01
    z[10,3,5]  R1338     -2.5774425268173218e-01
    z[10,3,5]  R1339     -1.6966257989406586e-01
    z[10,3,5]  R1340     -0.244800865650177
    z[10,3,5]  R1341     3.4857827425003052e-01
    z[10,3,5]  R1342     -1.6361238434910774e-02
    z[10,3,5]  R1343     -1.2094871699810028e-01
    z[10,3,5]  R1344     2.1043597161769867e-01
    z[10,3,5]  R1345     3.9162391424179077e-01
    z[10,3,5]  R1346     -1.0682401806116104e-01
    z[10,3,5]  R1347     -1.7073659598827362e-01
    z[10,3,5]  R1348     1.2148747593164444e-01
    z[10,3,5]  R1349     1.3128049671649933e-01
    z[10,3,5]  R1350     2.2975887358188629e-01
    z[10,3,5]  R1351     5.1292762160301208e-02
    z[10,3,5]  R1352     5.4597463458776474e-02
    z[10,3,5]  R1353     1.5197399258613586e-01
    z[10,3,5]  R1354     -1.5045249462127686e-01
    z[10,3,5]  R1355     1.0198665410280228e-01
    z[10,3,5]  R1356     -3.8891077041625977e-01
    z[10,3,5]  R1357     1.7021405696868896e-01
    z[10,3,5]  R1358     -0.256853312253952
    z[10,3,5]  R1359     2.6179185137152672e-02
    z[10,3,5]  R1360     -3.5139527916908264e-01
    z[10,3,5]  R1361     1.7495891451835632e-01
    z[10,3,5]  R1362     -1.4328850805759430e-01
    z[10,3,5]  R1363     2.0163874328136444e-01
    z[10,3,5]  R1364     1.7113395035266876e-01
    z[10,3,6]  R35       1
    z[10,3,6]  R98       -1
    z[10,3,6]  R1285     -1
    z[10,3,6]  R1286     1
    z[10,3,6]  R1287     3.1115907430648804e-01
    z[10,3,6]  R1288     2.2180373966693878e-01
    z[10,3,6]  R1289     -2.1379025280475616e-01
    z[10,3,6]  R1290     -2.0424191653728485e-01
    z[10,3,6]  R1291     2.5111040472984314e-01
    z[10,3,6]  R1292     -2.2403696179389954e-01
    z[10,3,6]  R1293     1.4899879693984985e-01
    z[10,3,6]  R1294     2.7462151646614075e-01
    z[10,3,6]  R1295     2.3706594482064247e-02
    z[10,3,6]  R1296     4.6787819266319275e-01
    z[10,3,6]  R1297     -6.4719456434249878e-01
    z[10,3,6]  R1298     -6.5354377031326294e-01
    z[10,3,6]  R1299     -1.4812734723091125e-01
    z[10,3,6]  R1300     0.135025292634964
    z[10,3,6]  R1301     1.5096846222877502e-01
    z[10,3,6]  R1302     2.2642095386981964e-01
    z[10,3,6]  R1303     -4.4093031436204910e-02
    z[10,3,6]  R1304     -2.5611397624015808e-01
    z[10,3,6]  R1305     -3.5083033144474030e-02
    z[10,3,6]  R1306     1.0351660847663879e-01
    z[10,3,6]  R1307     0.156805619597435
    z[10,3,6]  R1308     5.0296908617019653e-01
    z[10,3,6]  R1309     -1.0307624936103821e-01
    z[10,3,6]  R1310     2.2044481709599495e-02
    z[10,3,6]  R1311     5.8471059799194336e-01
    z[10,3,6]  R1312     3.5739752650260925e-01
    z[10,3,6]  R1313     -3.0509757995605469e-01
    z[10,3,6]  R1314     -1.1545576900243759e-01
    z[10,3,6]  R1315     -0.00886712409555912
    z[10,3,6]  R1316     2.6179659366607666e-01
    z[10,3,6]  R1317     1.6377250850200653e-01
    z[10,3,6]  R1318     1.6131460666656494e-01
    z[10,3,6]  R1319     -0.0995606854557991
    z[10,3,6]  R1320     -1.2396887689828873e-01
    z[10,3,6]  R1321     -3.1050941348075867e-01
    z[10,3,6]  R1322     -2.5741836428642273e-01
    z[10,3,6]  R1323     -2.6364496350288391e-01
    z[10,3,6]  R1324     -0.352649450302124
    z[10,3,6]  R1325     -2.1015355363488197e-02
    z[10,3,6]  R1326     2.6889881491661072e-01
    z[10,3,6]  R1327     2.3065450787544250e-01
    z[10,3,6]  R1328     -2.2433733940124512e-01
    z[10,3,6]  R1329     9.5027135685086250e-03
    z[10,3,6]  R1330     -3.0451586842536926e-01
    z[10,3,6]  R1331     4.0011522173881531e-01
    z[10,3,6]  R1332     -9.0896666049957275e-02
    z[10,3,6]  R1333     4.7414788603782654e-01
    z[10,3,6]  R1334     3.8322679698467255e-02
    z[10,3,6]  R1335     9.8887398838996887e-02
    z[10,3,6]  R1336     5.5091398954391479e-01
    z[10,3,6]  R1337     -3.1023567914962769e-01
    z[10,3,6]  R1338     -2.6245719194412231e-01
    z[10,3,6]  R1339     -3.0436590313911438e-01
    z[10,3,6]  R1340     -4.6823951601982117e-01
    z[10,3,6]  R1341     -2.9056310653686523e-01
    z[10,3,6]  R1342     -2.0337577164173126e-01
    z[10,3,6]  R1343     2.0055323839187622e-01
    z[10,3,6]  R1344     9.4782322645187378e-02
    z[10,3,6]  R1345     -2.7302485704421997e-01
    z[10,3,6]  R1346     -7.0345097780227661e-01
    z[10,3,6]  R1347     -0.365187406539917
    z[10,3,6]  R1348     2.4529822170734406e-01
    z[10,3,6]  R1349     -1.5396726131439209e-01
    z[10,3,6]  R1350     1.1342352628707886e-01
    z[10,3,6]  R1351     1.6710974276065826e-01
    z[10,3,6]  R1352     1.0853295773267746e-01
    z[10,3,6]  R1353     0.0305503997951746
    z[10,3,6]  R1354     8.9628294110298157e-02
    z[10,3,6]  R1355     1.7342561483383179e-01
    z[10,3,6]  R1356     2.1724744141101837e-01
    z[10,3,6]  R1357     -2.5142121315002441e-01
    z[10,3,6]  R1358     3.6345383524894714e-01
    z[10,3,6]  R1359     -3.0564209818840027e-01
    z[10,3,6]  R1360     4.7692552208900452e-02
    z[10,3,6]  R1361     5.6257343292236328e-01
    z[10,3,6]  R1362     0.313156396150589
    z[10,3,6]  R1363     2.4942032992839813e-01
    z[10,3,6]  R1364     -5.1320254802703857e-01
    z[4,5,0]  R38       -1
    z[4,5,0]  R47       1
    z[4,5,0]  R1365     -1
    z[4,5,0]  R1366     1
    z[4,5,0]  R1379     4.1285350918769836e-01
    z[4,5,0]  R1380     3.8448178768157959e-01
    z[4,5,0]  R1381     1.1995550245046616e-01
    z[4,5,0]  R1382     2.0959652960300446e-01
    z[4,5,0]  R1383     6.0748201608657837e-01
    z[4,5,0]  R1384     4.7497734427452087e-01
    z[4,5,0]  R1385     2.8818449378013611e-01
    z[4,5,0]  R1386     -6.7278486490249634e-01
    z[4,5,0]  R1387     3.0296313762664795e-01
    z[4,5,0]  R1388     2.9295399785041809e-01
    z[4,5,0]  R1389     5.3371459245681763e-01
    z[4,5,0]  R1390     -3.9458143711090088e-01
    z[4,5,0]  R1391     -2.5424867868423462e-01
    z[4,5,0]  R1392     -1.4888504147529602e-01
    z[4,5,0]  R1393     3.2396411895751953e-01
    z[4,5,0]  R1394     1.2609507143497467e-01
    z[4,5,0]  R1395     -1.9771598279476166e-01
    z[4,5,0]  R1396     -1.7129307985305786e-01
    z[4,5,0]  R1397     2.2557590901851654e-01
    z[4,5,0]  R1398     -1.8372812867164612e-01
    z[4,5,0]  R1399     -1.3125183992087841e-02
    z[4,5,0]  R1400     -2.5624418631196022e-02
    z[4,5,0]  R1401     -1.9810365140438080e-01
    z[4,5,0]  R1402     -2.2849960252642632e-02
    z[4,5,0]  R1403     -2.4032703042030334e-01
    z[4,5,0]  R1404     -1.7159251868724823e-01
    z[4,5,0]  R1405     3.7596255540847778e-01
    z[4,5,0]  R1406     -2.3235681653022766e-01
    z[4,5,0]  R1407     -6.6991263628005981e-01
    z[4,5,0]  R1408     3.5354757308959961e-01
    z[4,5,0]  R1409     1.0167054831981659e-01
    z[4,5,0]  R1410     -2.4417449533939362e-01
    z[4,5,0]  R1411     -1.4748911559581757e-01
    z[4,5,0]  R1412     3.1215512752532959e-01
    z[4,5,0]  R1413     -3.8002294301986694e-01
    z[4,5,0]  R1414     0.0915653184056282
    z[4,5,0]  R1415     0.378814697265625
    z[4,5,0]  R1416     8.8293008506298065e-02
    z[4,5,0]  R1417     2.1603241562843323e-01
    z[4,5,0]  R1418     6.5152287483215332e-02
    z[4,5,0]  R1419     9.1169491410255432e-02
    z[4,5,0]  R1420     3.4985087811946869e-02
    z[4,5,0]  R1421     1.2196503579616547e-01
    z[4,5,0]  R1422     2.8525349497795105e-01
    z[4,5,0]  R1423     5.8857542276382446e-01
    z[4,5,0]  R1424     1.6893598437309265e-01
    z[4,5,0]  R1425     0.0400143563747406
    z[4,5,0]  R1426     4.2162124067544937e-02
    z[4,5,0]  R1427     -2.4480982124805450e-01
    z[4,5,0]  R1428     2.9493844509124756e-01
    z[4,5,0]  R1429     -3.3743920922279358e-01
    z[4,5,0]  R1430     -3.9628058671951294e-01
    z[4,5,0]  R1431     -2.5938609242439270e-01
    z[4,5,0]  R1432     -7.0217663049697876e-01
    z[4,5,0]  R1433     1.2838077545166016e-01
    z[4,5,0]  R1434     -6.8766087293624878e-01
    z[4,5,0]  R1435     -6.2176191806793213e-01
    z[4,5,0]  R1436     -5.6789475679397583e-01
    z[4,5,0]  R1437     -5.5205643177032471e-01
    z[4,5,0]  R1438     -4.6555015444755554e-01
    z[4,5,0]  R1439     4.2362403869628906e-01
    z[4,5,0]  R1440     -4.2511679232120514e-02
    z[4,5,0]  R1441     -8.1512147188186646e-01
    z[4,5,0]  R1442     -8.2804781198501587e-01
    z[4,5,0]  R1443     3.6391592025756836e-01
    z[4,5,0]  R1444     1.6448323428630829e-01
    z[4,5,0]  R1445     -6.7578339576721191e-01
    z[4,5,0]  R1446     -8.0015367269515991e-01
    z[4,5,0]  R1447     -3.6248150467872620e-01
    z[4,5,0]  R1448     -4.2786660790443420e-01
    z[4,5,0]  R1449     -9.4797289371490479e-01
    z[4,5,0]  R1450     3.8133431226015091e-02
    z[4,5,0]  R1451     3.2570844888687134e-01
    z[4,5,0]  R1452     1.1368932574987411e-01
    z[4,5,0]  R1453     4.2324790358543396e-01
    z[4,5,0]  R1454     -2.3786160349845886e-01
    z[4,5,0]  R1455     3.6844301223754883e-01
    z[4,5,0]  R1456     1.7988924682140350e-01
    z[4,5,0]  R1457     9.4721651077270508e-01
    z[4,5,0]  R1458     -6.5063394606113434e-02
    z[4,5,0]  R1459     -8.9545083045959473e-01
    z[4,5,0]  R1460     -4.6452856063842773e-01
    z[4,5,0]  R1461     -2.5964316725730896e-01
    z[4,5,0]  R1462     3.2282780855894089e-02
    z[4,5,0]  R1463     1.1634923284873366e-03
    z[4,5,0]  R1464     -4.2717915773391724e-01
    z[4,5,0]  R1465     -4.1456633806228638e-01
    z[4,5,0]  R1466     -2.3483836650848389e-01
    z[4,5,0]  R1467     -5.1700823009014130e-02
    z[4,5,0]  R1468     -1.9251120090484619e-01
    z[4,5,0]  R1469     2.7965842746198177e-03
    z[4,5,0]  R1470     -7.3569685220718384e-01
    z[4,5,0]  R1471     -7.1991771459579468e-01
    z[4,5,0]  R1472     -1.1196802370250225e-02
    z[4,5,0]  R1473     1.8641702830791473e-02
    z[4,5,0]  R1474     3.2393163442611694e-01
    z[4,5,0]  R1475     1.2809348106384277e-01
    z[4,5,0]  R1476     -8.0648861825466156e-02
    z[4,5,0]  R1477     2.4385492503643036e-01
    z[4,5,0]  R1478     3.1293833255767822e-01
    z[4,5,0]  R1479     6.7229464650154114e-02
    z[4,5,0]  R1480     3.0927827581763268e-02
    z[4,5,0]  R1481     -1.4215697348117828e-01
    z[4,5,0]  R1482     4.0148791670799255e-01
    z[4,5,0]  R1483     -2.9185411334037781e-01
    z[4,5,0]  R1484     -7.1345096826553345e-01
    z[4,5,0]  R1485     2.7783590555191040e-01
    z[4,5,0]  R1486     2.9050892591476440e-01
    z[4,5,0]  R1487     -1.9888277351856232e-01
    z[4,5,0]  R1488     1.0181367397308350e-01
    z[4,5,0]  R1489     -5.8129608631134033e-02
    z[4,5,0]  R1490     -7.6956844329833984e-01
    z[4,5,0]  R1491     1.4780323207378387e-01
    z[4,5,0]  R1492     2.8837344050407410e-01
    z[4,5,0]  R1493     2.4439045786857605e-01
    z[4,5,0]  R1494     1.2387710809707642e-01
    z[4,5,0]  R1495     6.7090421915054321e-01
    z[4,5,0]  R1496     4.0743890404701233e-01
    z[4,5,0]  R1497     2.7006670832633972e-01
    z[4,5,0]  R1498     1.7758893966674805e-01
    z[4,5,1]  R39       -1
    z[4,5,1]  R48       1
    z[4,5,1]  R1367     -1
    z[4,5,1]  R1368     1
    z[4,5,1]  R1379     -1.3202236592769623e-01
    z[4,5,1]  R1380     -4.5940056443214417e-02
    z[4,5,1]  R1381     -2.1939606964588165e-01
    z[4,5,1]  R1382     -1.8394032120704651e-01
    z[4,5,1]  R1383     1.7205059528350830e-02
    z[4,5,1]  R1384     7.5912439823150635e-01
    z[4,5,1]  R1385     7.2721993923187256e-01
    z[4,5,1]  R1386     4.0057358145713806e-01
    z[4,5,1]  R1387     4.7810387611389160e-01
    z[4,5,1]  R1388     5.6894439458847046e-01
    z[4,5,1]  R1389     -7.0877462625503540e-01
    z[4,5,1]  R1390     -3.9808529615402222e-01
    z[4,5,1]  R1391     -3.3675214648246765e-01
    z[4,5,1]  R1392     1.7925186082720757e-02
    z[4,5,1]  R1393     3.5206070542335510e-01
    z[4,5,1]  R1394     0.50312739610672
    z[4,5,1]  R1395     -4.9591645598411560e-01
    z[4,5,1]  R1396     0.0933518260717392
    z[4,5,1]  R1397     -2.0143432915210724e-01
    z[4,5,1]  R1398     -3.7276116013526917e-01
    z[4,5,1]  R1399     2.4780307710170746e-01
    z[4,5,1]  R1400     1.5220613777637482e-01
    z[4,5,1]  R1401     9.0704351663589478e-01
    z[4,5,1]  R1402     8.8989388942718506e-01
    z[4,5,1]  R1403     9.1480612754821777e-01
    z[4,5,1]  R1404     8.9418798685073853e-01
    z[4,5,1]  R1405     6.1804932355880737e-01
    z[4,5,1]  R1406     7.0757466554641724e-01
    z[4,5,1]  R1407     1.1783520132303238e-01
    z[4,5,1]  R1408     7.5609618425369263e-01
    z[4,5,1]  R1409     -2.7142059803009033e-01
    z[4,5,1]  R1410     2.2567722201347351e-01
    z[4,5,1]  R1411     1.3701331615447998e-01
    z[4,5,1]  R1412     3.0623498558998108e-01
    z[4,5,1]  R1413     1.4621399343013763e-01
    z[4,5,1]  R1414     9.1681569814682007e-01
    z[4,5,1]  R1415     0.743359386920929
    z[4,5,1]  R1416     7.9641348123550415e-01
    z[4,5,1]  R1417     7.5286239385604858e-01
    z[4,5,1]  R1418     5.7476663589477539e-01
    z[4,5,1]  R1419     6.2243533134460449e-01
    z[4,5,1]  R1420     8.3571928739547729e-01
    z[4,5,1]  R1421     8.1072479486465454e-01
    z[4,5,1]  R1422     6.7430537939071655e-01
    z[4,5,1]  R1423     6.6398453712463379e-01
    z[4,5,1]  R1424     3.8164768368005753e-02
    z[4,5,1]  R1425     -1.4380897395312786e-02
    z[4,5,1]  R1426     -1.4331623911857605e-02
    z[4,5,1]  R1427     1.4161263406276703e-01
    z[4,5,1]  R1428     7.4459767341613770e-01
    z[4,5,1]  R1429     5.0013720989227295e-02
    z[4,5,1]  R1430     7.7343881130218506e-01
    z[4,5,1]  R1431     -7.6145604252815247e-02
    z[4,5,1]  R1432     1.2796878814697266e-01
    z[4,5,1]  R1433     3.0080916360020638e-02
    z[4,5,1]  R1434     -1.0028189420700073e-01
    z[4,5,1]  R1435     -0.0374673455953598
    z[4,5,1]  R1436     6.3147753477096558e-02
    z[4,5,1]  R1437     5.0335365533828735e-01
    z[4,5,1]  R1438     -4.1611157357692719e-02
    z[4,5,1]  R1439     -1.5959550440311432e-01
    z[4,5,1]  R1440     -2.9155075550079346e-01
    z[4,5,1]  R1441     1.6240240633487701e-01
    z[4,5,1]  R1442     1.1980239301919937e-01
    z[4,5,1]  R1443     -3.6802086979150772e-02
    z[4,5,1]  R1444     -4.5254769921302795e-01
    z[4,5,1]  R1445     2.1470628678798676e-01
    z[4,5,1]  R1446     -2.1832898259162903e-01
    z[4,5,1]  R1447     -1.3647566735744476e-01
    z[4,5,1]  R1448     2.1910087764263153e-01
    z[4,5,1]  R1449     1.7176677286624908e-01
    z[4,5,1]  R1450     -2.2571478784084320e-01
    z[4,5,1]  R1451     1.2229388207197189e-01
    z[4,5,1]  R1452     -1.4601200819015503e-01
    z[4,5,1]  R1453     0.363082617521286
    z[4,5,1]  R1454     1.4118406176567078e-01
    z[4,5,1]  R1455     9.6902884542942047e-02
    z[4,5,1]  R1456     0.703339695930481
    z[4,5,1]  R1457     2.9212915897369385e-01
    z[4,5,1]  R1458     -2.2574503719806671e-01
    z[4,5,1]  R1459     -0.0618734285235405
    z[4,5,1]  R1460     1.9577708095312119e-02
    z[4,5,1]  R1461     7.5356088578701019e-02
    z[4,5,1]  R1462     -3.6300602555274963e-01
    z[4,5,1]  R1463     -1.1443398892879486e-01
    z[4,5,1]  R1464     2.0309317111968994e-01
    z[4,5,1]  R1465     1.4620343223214149e-02
    z[4,5,1]  R1466     -0.1455088108778
    z[4,5,1]  R1467     4.6544772386550903e-01
    z[4,5,1]  R1468     1.9206671416759491e-01
    z[4,5,1]  R1469     -1.3569761812686920e-01
    z[4,5,1]  R1470     1.1002972722053528e-01
    z[4,5,1]  R1471     3.6919426172971725e-02
    z[4,5,1]  R1472     3.5758984088897705e-01
    z[4,5,1]  R1473     -1.9179159402847290e-01
    z[4,5,1]  R1474     9.9849283695220947e-02
    z[4,5,1]  R1475     1.9320188090205193e-02
    z[4,5,1]  R1476     -9.6033227443695068e-01
    z[4,5,1]  R1477     3.3115339279174805e-01
    z[4,5,1]  R1478     -8.9774757623672485e-01
    z[4,5,1]  R1479     -0.127201110124588
    z[4,5,1]  R1480     -1.4737728238105774e-01
    z[4,5,1]  R1481     -1.1822173744440079e-01
    z[4,5,1]  R1482     2.2839525341987610e-01
    z[4,5,1]  R1483     -3.2719787955284119e-01
    z[4,5,1]  R1484     3.3691179007291794e-02
    z[4,5,1]  R1485     5.0151222944259644e-01
    z[4,5,1]  R1486     4.6746385097503662e-01
    z[4,5,1]  R1487     3.5555484890937805e-01
    z[4,5,1]  R1488     1.8494389951229095e-01
    z[4,5,1]  R1489     2.5290858745574951e-01
    z[4,5,1]  R1490     9.5955148339271545e-02
    z[4,5,1]  R1491     3.8058131933212280e-02
    z[4,5,1]  R1492     1.9257250428199768e-01
    z[4,5,1]  R1493     3.2504150271415710e-01
    z[4,5,1]  R1494     -0.42623171210289
    z[4,5,1]  R1495     2.7800679206848145e-01
    z[4,5,1]  R1496     -8.0501812696456909e-01
    z[4,5,1]  R1497     -5.4595386981964111e-01
    z[4,5,1]  R1498     -7.9230827093124390e-01
    z[4,5,2]  R40       -1
    z[4,5,2]  R49       1
    z[4,5,2]  R1369     -1
    z[4,5,2]  R1370     1
    z[4,5,2]  R1379     -4.7414809465408325e-01
    z[4,5,2]  R1380     -8.2871162891387939e-01
    z[4,5,2]  R1381     1.4623082242906094e-02
    z[4,5,2]  R1382     -5.7248926162719727e-01
    z[4,5,2]  R1383     -3.7738669663667679e-02
    z[4,5,2]  R1384     -2.4280330538749695e-01
    z[4,5,2]  R1385     3.7362776696681976e-02
    z[4,5,2]  R1386     9.4783097505569458e-02
    z[4,5,2]  R1387     -1.2289097905158997e-01
    z[4,5,2]  R1388     -1.7647363245487213e-01
    z[4,5,2]  R1389     4.1203033924102783e-01
    z[4,5,2]  R1390     2.3994788527488708e-01
    z[4,5,2]  R1391     1.6720631718635559e-01
    z[4,5,2]  R1392     1.2837819755077362e-01
    z[4,5,2]  R1393     4.0040275454521179e-01
    z[4,5,2]  R1394     1.3345356285572052e-01
    z[4,5,2]  R1395     -3.3194657415151596e-02
    z[4,5,2]  R1396     2.5313520431518555e-01
    z[4,5,2]  R1397     -4.1206502914428711e-01
    z[4,5,2]  R1398     -1.8811488151550293e-01
    z[4,5,2]  R1399     7.2802215814590454e-01
    z[4,5,2]  R1400     0.571914792060852
    z[4,5,2]  R1401     1.5345154702663422e-01
    z[4,5,2]  R1402     -2.9085204005241394e-01
    z[4,5,2]  R1403     6.4979223534464836e-03
    z[4,5,2]  R1404     -3.2424005866050720e-01
    z[4,5,2]  R1405     -5.5171851068735123e-02
    z[4,5,2]  R1406     -1.0804910957813263e-01
    z[4,5,2]  R1407     -2.4583692848682404e-01
    z[4,5,2]  R1408     -1.6915802657604218e-01
    z[4,5,2]  R1409     -1.6012535989284515e-01
    z[4,5,2]  R1410     8.7762826681137085e-01
    z[4,5,2]  R1411     4.9203032255172729e-01
    z[4,5,2]  R1412     5.3925096988677979e-01
    z[4,5,2]  R1413     8.7598901987075806e-01
    z[4,5,2]  R1414     -3.3536902070045471e-01
    z[4,5,2]  R1415     -5.1727157086133957e-02
    z[4,5,2]  R1416     -9.1836132109165192e-02
    z[4,5,2]  R1417     5.6509021669626236e-02
    z[4,5,2]  R1418     1.4021563343703747e-02
    z[4,5,2]  R1419     -4.2121402919292450e-02
    z[4,5,2]  R1420     6.2648139894008636e-02
    z[4,5,2]  R1421     0.0945080816745758
    z[4,5,2]  R1422     -1.9648608565330505e-01
    z[4,5,2]  R1423     1.4892233535647392e-02
    z[4,5,2]  R1424     1.6314502060413361e-01
    z[4,5,2]  R1425     3.1280573457479477e-02
    z[4,5,2]  R1426     -7.9890981316566467e-02
    z[4,5,2]  R1427     2.4777954444289207e-02
    z[4,5,2]  R1428     -0.0759509950876236
    z[4,5,2]  R1429     -2.7480663266032934e-03
    z[4,5,2]  R1430     -1.8025057017803192e-01
    z[4,5,2]  R1431     -1.5111367404460907e-01
    z[4,5,2]  R1432     -6.2531381845474243e-01
    z[4,5,2]  R1433     -0.576040506362915
    z[4,5,2]  R1434     6.9555006921291351e-02
    z[4,5,2]  R1435     -2.6764407753944397e-01
    z[4,5,2]  R1436     8.3748415112495422e-02
    z[4,5,2]  R1437     -2.9789095744490623e-02
    z[4,5,2]  R1438     -4.6795919537544250e-01
    z[4,5,2]  R1439     2.8300043940544128e-01
    z[4,5,2]  R1440     1.9899943470954895e-01
    z[4,5,2]  R1441     -5.6615364737808704e-03
    z[4,5,2]  R1442     2.6696342229843140e-01
    z[4,5,2]  R1443     -0.378528356552124
    z[4,5,2]  R1444     2.0347647368907928e-01
    z[4,5,2]  R1445     0.451111763715744
    z[4,5,2]  R1446     -0.369780033826828
    z[4,5,2]  R1447     -6.7180544137954712e-01
    z[4,5,2]  R1448     2.8006893396377563e-01
    z[4,5,2]  R1449     7.3733977973461151e-02
    z[4,5,2]  R1450     -4.0530607104301453e-01
    z[4,5,2]  R1451     2.0929652452468872e-01
    z[4,5,2]  R1452     -4.7107699513435364e-01
    z[4,5,2]  R1453     -1.9881846010684967e-01
    z[4,5,2]  R1454     -4.2531794309616089e-01
    z[4,5,2]  R1455     -1.2713733315467834e-01
    z[4,5,2]  R1456     -3.9311133325099945e-02
    z[4,5,2]  R1457     7.7751971781253815e-02
    z[4,5,2]  R1458     -1.7520049214363098e-01
    z[4,5,2]  R1459     -2.6556059718132019e-01
    z[4,5,2]  R1460     8.8238745927810669e-02
    z[4,5,2]  R1461     -5.9851235151290894e-01
    z[4,5,2]  R1462     -1.8945337831974030e-01
    z[4,5,2]  R1463     -2.8400018811225891e-01
    z[4,5,2]  R1464     -4.8823755979537964e-01
    z[4,5,2]  R1465     -4.7088220715522766e-01
    z[4,5,2]  R1466     1.6361738741397858e-01
    z[4,5,2]  R1467     -3.5027843713760376e-01
    z[4,5,2]  R1468     3.4251760691404343e-02
    z[4,5,2]  R1469     -9.2639058828353882e-02
    z[4,5,2]  R1470     -6.0383662581443787e-02
    z[4,5,2]  R1471     -7.6555326581001282e-02
    z[4,5,2]  R1472     3.3232295513153076e-01
    z[4,5,2]  R1473     3.7315258383750916e-01
    z[4,5,2]  R1474     -6.9189921021461487e-02
    z[4,5,2]  R1475     -2.5692909955978394e-02
    z[4,5,2]  R1476     1.8732752650976181e-02
    z[4,5,2]  R1477     1.2506689876317978e-02
    z[4,5,2]  R1478     -1.4842711389064789e-01
    z[4,5,2]  R1479     -3.4748205542564392e-01
    z[4,5,2]  R1480     1.3803166337311268e-02
    z[4,5,2]  R1481     2.2150658071041107e-01
    z[4,5,2]  R1482     -2.1676330268383026e-01
    z[4,5,2]  R1483     -2.4882483482360840e-01
    z[4,5,2]  R1484     -2.5127208232879639e-01
    z[4,5,2]  R1485     -3.1067386269569397e-01
    z[4,5,2]  R1486     -8.3406358957290649e-02
    z[4,5,2]  R1487     8.8219016790390015e-02
    z[4,5,2]  R1488     9.0795040130615234e-02
    z[4,5,2]  R1489     2.4200503528118134e-01
    z[4,5,2]  R1490     2.7575361728668213e-01
    z[4,5,2]  R1491     1.8716080486774445e-01
    z[4,5,2]  R1492     -1.4385522902011871e-01
    z[4,5,2]  R1493     1.4106544852256775e-01
    z[4,5,2]  R1494     -7.1391791105270386e-01
    z[4,5,2]  R1495     -1.9359122216701508e-01
    z[4,5,2]  R1496     -5.2252197638154030e-03
    z[4,5,2]  R1497     -6.7500865459442139e-01
    z[4,5,2]  R1498     -3.7807437777519226e-01
    z[4,5,3]  R41       -1
    z[4,5,3]  R50       1
    z[4,5,3]  R1371     -1
    z[4,5,3]  R1372     1
    z[4,5,3]  R1379     9.4759769737720490e-02
    z[4,5,3]  R1380     9.6813887357711792e-02
    z[4,5,3]  R1381     8.2054913043975830e-02
    z[4,5,3]  R1382     -2.0222092047333717e-02
    z[4,5,3]  R1383     -1.4055344462394714e-01
    z[4,5,3]  R1384     1.3506911695003510e-01
    z[4,5,3]  R1385     1.6846060752868652e-01
    z[4,5,3]  R1386     -2.1175147965550423e-02
    z[4,5,3]  R1387     4.6630653738975525e-01
    z[4,5,3]  R1388     0.623343288898468
    z[4,5,3]  R1389     -1.3740181922912598e-01
    z[4,5,3]  R1390     -2.2141449153423309e-01
    z[4,5,3]  R1391     1.3829699158668518e-01
    z[4,5,3]  R1392     -7.6564550399780273e-01
    z[4,5,3]  R1393     1.7201645672321320e-01
    z[4,5,3]  R1394     -6.3344007730484009e-01
    z[4,5,3]  R1395     -0.415695458650589
    z[4,5,3]  R1396     3.7936963140964508e-02
    z[4,5,3]  R1397     -5.5727396160364151e-02
    z[4,5,3]  R1398     8.7636536359786987e-01
    z[4,5,3]  R1399     -4.5097228884696960e-01
    z[4,5,3]  R1400     2.6321390271186829e-01
    z[4,5,3]  R1401     5.3094297647476196e-02
    z[4,5,3]  R1402     1.1101468652486801e-01
    z[4,5,3]  R1403     2.6173036545515060e-02
    z[4,5,3]  R1404     9.6922911703586578e-02
    z[4,5,3]  R1405     3.5951477289199829e-01
    z[4,5,3]  R1406     4.6084529161453247e-01
    z[4,5,3]  R1407     2.0157489180564880e-01
    z[4,5,3]  R1408     1.5019841492176056e-01
    z[4,5,3]  R1409     -4.6264287829399109e-01
    z[4,5,3]  R1410     -1.3778880238533020e-03
    z[4,5,3]  R1411     4.8098187893629074e-02
    z[4,5,3]  R1412     -5.7226948440074921e-02
    z[4,5,3]  R1413     -9.2000365257263184e-02
    z[4,5,3]  R1414     4.1226636618375778e-02
    z[4,5,3]  R1415     3.9620363712310791e-01
    z[4,5,3]  R1416     -4.6701491810381413e-03
    z[4,5,3]  R1417     2.9443684220314026e-01
    z[4,5,3]  R1418     6.2322062253952026e-01
    z[4,5,3]  R1419     4.3258953094482422e-01
    z[4,5,3]  R1420     4.1657385230064392e-01
    z[4,5,3]  R1421     -7.4566014111042023e-02
    z[4,5,3]  R1422     4.5363315939903259e-01
    z[4,5,3]  R1423     -1.3361506164073944e-01
    z[4,5,3]  R1424     7.1216380596160889e-01
    z[4,5,3]  R1425     0.600469172000885
    z[4,5,3]  R1426     7.9959535598754883e-01
    z[4,5,3]  R1427     7.2746020555496216e-01
    z[4,5,3]  R1428     2.0860774442553520e-02
    z[4,5,3]  R1429     8.4794139862060547e-01
    z[4,5,3]  R1430     3.2732598483562469e-02
    z[4,5,3]  R1431     1.2854616343975067e-01
    z[4,5,3]  R1432     2.5573524832725525e-01
    z[4,5,3]  R1433     -0.0929994285106659
    z[4,5,3]  R1434     3.8197305798530579e-01
    z[4,5,3]  R1435     2.6172673702239990e-01
    z[4,5,3]  R1436     -2.3769235238432884e-02
    z[4,5,3]  R1437     1.7954589426517487e-01
    z[4,5,3]  R1438     6.2927208840847015e-02
    z[4,5,3]  R1439     -1.4314524829387665e-01
    z[4,5,3]  R1440     -3.7112697958946228e-01
    z[4,5,3]  R1441     -2.5143089890480042e-01
    z[4,5,3]  R1442     -3.7390291690826416e-01
    z[4,5,3]  R1443     -6.7231279611587524e-01
    z[4,5,3]  R1444     -4.8959153890609741e-01
    z[4,5,3]  R1445     -4.8098337650299072e-01
    z[4,5,3]  R1446     3.2516199350357056e-01
    z[4,5,3]  R1447     -4.0193176269531250e-01
    z[4,5,3]  R1448     -5.7705879211425781e-01
    z[4,5,3]  R1449     1.5771088004112244e-01
    z[4,5,3]  R1450     -5.3457766771316528e-01
    z[4,5,3]  R1451     -8.1588435173034668e-01
    z[4,5,3]  R1452     -1.3636319339275360e-01
    z[4,5,3]  R1453     -6.7196983098983765e-01
    z[4,5,3]  R1454     -6.3788032531738281e-01
    z[4,5,3]  R1455     -9.1128838062286377e-01
    z[4,5,3]  R1456     -0.515089750289917
    z[4,5,3]  R1457     -6.3510864973068237e-02
    z[4,5,3]  R1458     -8.2945835590362549e-01
    z[4,5,3]  R1459     -2.5645342469215393e-01
    z[4,5,3]  R1460     -7.6517832279205322e-01
    z[4,5,3]  R1461     -4.1942179203033447e-01
    z[4,5,3]  R1462     -8.5967427492141724e-01
    z[4,5,3]  R1463     -0.651572048664093
    z[4,5,3]  R1464     -5.7658779621124268e-01
    z[4,5,3]  R1465     -0.748293399810791
    z[4,5,3]  R1466     -6.7190760374069214e-01
    z[4,5,3]  R1467     -5.7095140218734741e-01
    z[4,5,3]  R1468     -7.0784342288970947e-01
    z[4,5,3]  R1469     -9.8207664489746094e-01
    z[4,5,3]  R1470     4.7516539692878723e-01
    z[4,5,3]  R1471     -1.6965904831886292e-01
    z[4,5,3]  R1472     -4.7302126884460449e-01
    z[4,5,3]  R1473     -2.3581373691558838e-01
    z[4,5,3]  R1474     -0.278064489364624
    z[4,5,3]  R1475     -1.0975673794746399e-02
    z[4,5,3]  R1476     1.6037112474441528e-01
    z[4,5,3]  R1477     -1.0819870978593826e-01
    z[4,5,3]  R1478     2.4428753554821014e-01
    z[4,5,3]  R1479     -0.629863440990448
    z[4,5,3]  R1480     -0.517500638961792
    z[4,5,3]  R1481     -3.1145122647285461e-01
    z[4,5,3]  R1482     -3.9131855964660645e-01
    z[4,5,3]  R1483     -2.0772920548915863e-01
    z[4,5,3]  R1484     -3.0627167224884033e-01
    z[4,5,3]  R1485     -3.7720578908920288e-01
    z[4,5,3]  R1486     -3.2554894685745239e-01
    z[4,5,3]  R1487     -0.820368766784668
    z[4,5,3]  R1488     -7.8444075584411621e-01
    z[4,5,3]  R1489     -8.9112937450408936e-01
    z[4,5,3]  R1490     2.3417022824287415e-01
    z[4,5,3]  R1491     -7.4661165475845337e-01
    z[4,5,3]  R1492     -1.1544159799814224e-01
    z[4,5,3]  R1493     -8.4097707271575928e-01
    z[4,5,3]  R1494     -3.4149774909019470e-01
    z[4,5,3]  R1495     -2.0160059630870819e-01
    z[4,5,3]  R1496     -2.0965600013732910e-01
    z[4,5,3]  R1497     2.4074146151542664e-01
    z[4,5,3]  R1498     -9.7188048064708710e-02
    z[4,5,4]  R42       -1
    z[4,5,4]  R51       1
    z[4,5,4]  R1373     -1
    z[4,5,4]  R1374     1
    z[4,5,4]  R1379     -6.7960780858993530e-01
    z[4,5,4]  R1380     -1.3993211090564728e-01
    z[4,5,4]  R1381     -2.9488596320152283e-01
    z[4,5,4]  R1382     7.0823854207992554e-01
    z[4,5,4]  R1383     6.7547351121902466e-01
    z[4,5,4]  R1384     2.6978189125657082e-02
    z[4,5,4]  R1385     -1.2629888951778412e-01
    z[4,5,4]  R1386     -4.1531139612197876e-01
    z[4,5,4]  R1387     1.1978959292173386e-01
    z[4,5,4]  R1388     1.2435131520032883e-01
    z[4,5,4]  R1389     4.9273487180471420e-02
    z[4,5,4]  R1390     1.8249136209487915e-01
    z[4,5,4]  R1391     5.3202575445175171e-01
    z[4,5,4]  R1392     5.2533334493637085e-01
    z[4,5,4]  R1393     9.3137837946414948e-02
    z[4,5,4]  R1394     8.3275333046913147e-02
    z[4,5,4]  R1395     1.3587783277034760e-01
    z[4,5,4]  R1396     5.7541990280151367e-01
    z[4,5,4]  R1397     1.7288066446781158e-01
    z[4,5,4]  R1398     -1.4637543819844723e-02
    z[4,5,4]  R1399     -5.5954560637474060e-02
    z[4,5,4]  R1400     -3.6770024895668030e-01
    z[4,5,4]  R1401     -1.8873862922191620e-01
    z[4,5,4]  R1402     2.2558660805225372e-01
    z[4,5,4]  R1403     -8.2657516002655029e-02
    z[4,5,4]  R1404     -9.6800431609153748e-02
    z[4,5,4]  R1405     -1.6078034043312073e-01
    z[4,5,4]  R1406     -1.9464877247810364e-01
    z[4,5,4]  R1407     -4.1220435500144958e-01
    z[4,5,4]  R1408     2.9235166311264038e-01
    z[4,5,4]  R1409     8.0781751871109009e-01
    z[4,5,4]  R1410     1.1478152871131897e-01
    z[4,5,4]  R1411     4.2002722620964050e-01
    z[4,5,4]  R1412     4.8885148763656616e-01
    z[4,5,4]  R1413     -1.6488823294639587e-01
    z[4,5,4]  R1414     1.3348235189914703e-01
    z[4,5,4]  R1415     -1.6731470823287964e-01
    z[4,5,4]  R1416     1.3335452415049076e-02
    z[4,5,4]  R1417     2.2520011663436890e-01
    z[4,5,4]  R1418     -7.5253896415233612e-02
    z[4,5,4]  R1419     3.9314761757850647e-02
    z[4,5,4]  R1420     1.0867656767368317e-01
    z[4,5,4]  R1421     -2.3046325147151947e-01
    z[4,5,4]  R1422     -1.1870503425598145e-01
    z[4,5,4]  R1423     -1.5901979058980942e-02
    z[4,5,4]  R1424     7.6755732297897339e-02
    z[4,5,4]  R1425     9.0735845267772675e-02
    z[4,5,4]  R1426     -0.0392913781106472
    z[4,5,4]  R1427     6.7949362099170685e-02
    z[4,5,4]  R1428     -4.0598297119140625e-01
    z[4,5,4]  R1429     -3.4905603528022766e-01
    z[4,5,4]  R1430     -4.0481212735176086e-01
    z[4,5,4]  R1431     -1.5143294632434845e-01
    z[4,5,4]  R1432     -1.7119763791561127e-01
    z[4,5,4]  R1433     6.0256570577621460e-01
    z[4,5,4]  R1434     5.0337827205657959e-01
    z[4,5,4]  R1435     5.8340936899185181e-01
    z[4,5,4]  R1436     6.5137690305709839e-01
    z[4,5,4]  R1437     6.0403895378112793e-01
    z[4,5,4]  R1438     2.7985429763793945e-01
    z[4,5,4]  R1439     -8.0465364456176758e-01
    z[4,5,4]  R1440     -7.1471405029296875e-01
    z[4,5,4]  R1441     0.266798734664917
    z[4,5,4]  R1442     1.6667881608009338e-01
    z[4,5,4]  R1443     1.0656679421663284e-01
    z[4,5,4]  R1444     6.8941771984100342e-01
    z[4,5,4]  R1445     9.8088867962360382e-02
    z[4,5,4]  R1446     1.4819258451461792e-01
    z[4,5,4]  R1447     7.3480650782585144e-02
    z[4,5,4]  R1448     3.9599311351776123e-01
    z[4,5,4]  R1449     -1.5154494345188141e-01
    z[4,5,4]  R1450     5.3375542163848877e-01
    z[4,5,4]  R1451     3.1585705280303955e-01
    z[4,5,4]  R1452     6.6348546743392944e-01
    z[4,5,4]  R1453     1.8702732026576996e-01
    z[4,5,4]  R1454     5.3000879287719727e-01
    z[4,5,4]  R1455     -3.7306804209947586e-02
    z[4,5,4]  R1456     3.6943724751472473e-01
    z[4,5,4]  R1457     5.9650752693414688e-02
    z[4,5,4]  R1458     -0.0385153628885746
    z[4,5,4]  R1459     -5.6886758655309677e-02
    z[4,5,4]  R1460     2.7707213163375854e-01
    z[4,5,4]  R1461     1.3641911745071411e-01
    z[4,5,4]  R1462     1.2633895874023438e-01
    z[4,5,4]  R1463     3.1312310695648193e-01
    z[4,5,4]  R1464     2.9254177585244179e-02
    z[4,5,4]  R1465     1.2450111657381058e-01
    z[4,5,4]  R1466     4.0761077404022217e-01
    z[4,5,4]  R1467     3.9535003900527954e-01
    z[4,5,4]  R1468     4.6522179245948792e-01
    z[4,5,4]  R1469     5.6966792792081833e-02
    z[4,5,4]  R1470     4.3650454282760620e-01
    z[4,5,4]  R1471     -2.4670800194144249e-02
    z[4,5,4]  R1472     0.501748263835907
    z[4,5,4]  R1473     6.9103544950485229e-01
    z[4,5,4]  R1474     0.691504955291748
    z[4,5,4]  R1475     6.1777377128601074e-01
    z[4,5,4]  R1476     1.9605021178722382e-01
    z[4,5,4]  R1477     0.828144371509552
    z[4,5,4]  R1478     1.1928584426641464e-01
    z[4,5,4]  R1479     2.9502838850021362e-01
    z[4,5,4]  R1480     8.2690107822418213e-01
    z[4,5,4]  R1481     7.9405295848846436e-01
    z[4,5,4]  R1482     7.4105972051620483e-01
    z[4,5,4]  R1483     4.9315702915191650e-01
    z[4,5,4]  R1484     4.9408420920372009e-01
    z[4,5,4]  R1485     2.1096305549144745e-01
    z[4,5,4]  R1486     4.5030426979064941e-01
    z[4,5,4]  R1487     -2.6139688491821289e-01
    z[4,5,4]  R1488     -3.6400434374809265e-01
    z[4,5,4]  R1489     0.222420796751976
    z[4,5,4]  R1490     4.9646505713462830e-01
    z[4,5,4]  R1491     4.2365917563438416e-01
    z[4,5,4]  R1492     5.3762644529342651e-01
    z[4,5,4]  R1493     -1.4177824556827545e-01
    z[4,5,4]  R1494     -2.9641222953796387e-01
    z[4,5,4]  R1495     -4.6315023303031921e-01
    z[4,5,4]  R1496     4.2114172130823135e-02
    z[4,5,4]  R1497     -1.2323540449142456e-01
    z[4,5,4]  R1498     -1.3724432885646820e-01
    z[4,5,5]  R43       -1
    z[4,5,5]  R52       1
    z[4,5,5]  R1375     -1
    z[4,5,5]  R1376     1
    z[4,5,5]  R1379     0.0559404082596302
    z[4,5,5]  R1380     2.8066992759704590e-01
    z[4,5,5]  R1381     8.0574375391006470e-01
    z[4,5,5]  R1382     2.9041644930839539e-01
    z[4,5,5]  R1383     -1.9368024542927742e-02
    z[4,5,5]  R1384     1.7122475430369377e-02
    z[4,5,5]  R1385     5.5484312772750854e-01
    z[4,5,5]  R1386     1.7156814038753510e-01
    z[4,5,5]  R1387     6.0017108917236328e-01
    z[4,5,5]  R1388     3.5948729515075684e-01
    z[4,5,5]  R1389     -1.2933203834109008e-04
    z[4,5,5]  R1390     -5.3700095415115356e-01
    z[4,5,5]  R1391     -6.5760958194732666e-01
    z[4,5,5]  R1392     -2.5490492582321167e-01
    z[4,5,5]  R1393     -7.4669677019119263e-01
    z[4,5,5]  R1394     -0.489662230014801
    z[4,5,5]  R1395     -5.2383244037628174e-01
    z[4,5,5]  R1396     -4.6987172961235046e-01
    z[4,5,5]  R1397     -8.0954384803771973e-01
    z[4,5,5]  R1398     -6.7603783681988716e-03
    z[4,5,5]  R1399     3.9236697554588318e-01
    z[4,5,5]  R1400     -4.5929306745529175e-01
    z[4,5,5]  R1401     2.7570620179176331e-01
    z[4,5,5]  R1402     1.7076404392719269e-01
    z[4,5,5]  R1403     2.8928220272064209e-02
    z[4,5,5]  R1404     2.1675245463848114e-01
    z[4,5,5]  R1405     5.6372302770614624e-01
    z[4,5,5]  R1406     4.2820256948471069e-01
    z[4,5,5]  R1407     -4.8932361602783203e-01
    z[4,5,5]  R1408     1.4396293461322784e-01
    z[4,5,5]  R1409     -1.4416243135929108e-01
    z[4,5,5]  R1410     -0.0305878184735775
    z[4,5,5]  R1411     -3.7809950113296509e-01
    z[4,5,5]  R1412     1.3094292581081390e-01
    z[4,5,5]  R1413     -1.4991295337677002e-01
    z[4,5,5]  R1414     7.3057748377323151e-02
    z[4,5,5]  R1415     2.5748360157012939e-01
    z[4,5,5]  R1416     5.9070986509323120e-01
    z[4,5,5]  R1417     4.3190208077430725e-01
    z[4,5,5]  R1418     4.8718398809432983e-01
    z[4,5,5]  R1419     0.637184202671051
    z[4,5,5]  R1420     1.9008395075798035e-01
    z[4,5,5]  R1421     4.2423000931739807e-01
    z[4,5,5]  R1422     3.0134943127632141e-01
    z[4,5,5]  R1423     4.0979641675949097e-01
    z[4,5,5]  R1424     6.4152711629867554e-01
    z[4,5,5]  R1425     7.5302320718765259e-01
    z[4,5,5]  R1426     5.5047595500946045e-01
    z[4,5,5]  R1427     5.6913548707962036e-01
    z[4,5,5]  R1428     -3.3383011817932129e-02
    z[4,5,5]  R1429     1.9612286984920502e-01
    z[4,5,5]  R1430     0.00659114308655262
    z[4,5,5]  R1431     6.7923456430435181e-02
    z[4,5,5]  R1432     6.9166854023933411e-02
    z[4,5,5]  R1433     -3.3183541893959045e-01
    z[4,5,5]  R1434     -1.8486261367797852e-01
    z[4,5,5]  R1435     -1.6372244060039520e-01
    z[4,5,5]  R1436     4.9148839712142944e-01
    z[4,5,5]  R1437     4.2542457580566406e-02
    z[4,5,5]  R1438     6.9280147552490234e-01
    z[4,5,5]  R1439     -1.6861215233802795e-02
    z[4,5,5]  R1440     4.7413975000381470e-01
    z[4,5,5]  R1441     -3.6903324723243713e-01
    z[4,5,5]  R1442     -7.3834314942359924e-02
    z[4,5,5]  R1443     -2.6967558264732361e-01
    z[4,5,5]  R1444     -9.3652546405792236e-02
    z[4,5,5]  R1445     1.7964974045753479e-01
    z[4,5,5]  R1446     -2.1820570528507233e-01
    z[4,5,5]  R1447     -4.8119717836380005e-01
    z[4,5,5]  R1448     -3.2736396789550781e-01
    z[4,5,5]  R1449     1.3610869646072388e-01
    z[4,5,5]  R1450     -3.5619491338729858e-01
    z[4,5,5]  R1451     -2.6136147975921631e-01
    z[4,5,5]  R1452     -5.3270250558853149e-01
    z[4,5,5]  R1453     -1.9811446964740753e-01
    z[4,5,5]  R1454     2.2314096987247467e-01
    z[4,5,5]  R1455     -2.6403328403830528e-02
    z[4,5,5]  R1456     -2.6129683852195740e-01
    z[4,5,5]  R1457     -3.2052453607320786e-02
    z[4,5,5]  R1458     -0.0769997164607048
    z[4,5,5]  R1459     -1.4895573258399963e-01
    z[4,5,5]  R1460     -2.7609825134277344e-01
    z[4,5,5]  R1461     -5.0527429580688477e-01
    z[4,5,5]  R1462     -1.5097571909427643e-01
    z[4,5,5]  R1463     -5.5129927396774292e-01
    z[4,5,5]  R1464     -4.1880735754966736e-01
    z[4,5,5]  R1465     -7.0386335253715515e-02
    z[4,5,5]  R1466     -4.0573894977569580e-01
    z[4,5,5]  R1467     -8.1521391868591309e-02
    z[4,5,5]  R1468     -1.8544414639472961e-01
    z[4,5,5]  R1469     -6.6456802189350128e-02
    z[4,5,5]  R1470     -1.0414634644985199e-01
    z[4,5,5]  R1471     4.8507860302925110e-01
    z[4,5,5]  R1472     -4.2671182751655579e-01
    z[4,5,5]  R1473     -5.3692048788070679e-01
    z[4,5,5]  R1474     -1.4991647005081177e-01
    z[4,5,5]  R1475     -6.9139486551284790e-01
    z[4,5,5]  R1476     -2.0259751006960869e-02
    z[4,5,5]  R1477     -2.3795737326145172e-01
    z[4,5,5]  R1478     -1.3097479008138180e-02
    z[4,5,5]  R1479     -4.7311460971832275e-01
    z[4,5,5]  R1480     -7.5560718774795532e-02
    z[4,5,5]  R1481     -4.2994603514671326e-01
    z[4,5,5]  R1482     -1.3929808139801025e-01
    z[4,5,5]  R1483     -6.7659783363342285e-01
    z[4,5,5]  R1484     2.6908889412879944e-01
    z[4,5,5]  R1485     -4.7908765077590942e-01
    z[4,5,5]  R1486     -4.2305770516395569e-01
    z[4,5,5]  R1487     2.4900914728641510e-01
    z[4,5,5]  R1488     4.4625878334045410e-01
    z[4,5,5]  R1489     -0.173871248960495
    z[4,5,5]  R1490     -1.3910108804702759e-01
    z[4,5,5]  R1491     2.2220280021429062e-02
    z[4,5,5]  R1492     -7.1852356195449829e-01
    z[4,5,5]  R1493     1.5703302621841431e-01
    z[4,5,5]  R1494     -2.0799359306693077e-02
    z[4,5,5]  R1495     3.7278345227241516e-01
    z[4,5,5]  R1496     0.0987817645072937
    z[4,5,5]  R1497     -1.6199807822704315e-01
    z[4,5,5]  R1498     6.4389050006866455e-02
    z[4,5,6]  R44       -1
    z[4,5,6]  R53       1
    z[4,5,6]  R1377     -1
    z[4,5,6]  R1378     1
    z[4,5,6]  R1379     3.3664533495903015e-01
    z[4,5,6]  R1380     2.3573417961597443e-01
    z[4,5,6]  R1381     4.4084972143173218e-01
    z[4,5,6]  R1382     -9.0215429663658142e-02
    z[4,5,6]  R1383     3.9096099138259888e-01
    z[4,5,6]  R1384     3.4627810120582581e-01
    z[4,5,6]  R1385     1.8580521643161774e-01
    z[4,5,6]  R1386     4.1898670792579651e-01
    z[4,5,6]  R1387     -2.6931622624397278e-01
    z[4,5,6]  R1388     -1.6151136159896851e-01
    z[4,5,6]  R1389     -1.4734691381454468e-01
    z[4,5,6]  R1390     5.0750488042831421e-01
    z[4,5,6]  R1391     2.4365903437137604e-01
    z[4,5,6]  R1392     1.8402788043022156e-01
    z[4,5,6]  R1393     1.2230180203914642e-01
    z[4,5,6]  R1394     2.5534853339195251e-01
    z[4,5,6]  R1395     4.9820411205291748e-01
    z[4,5,6]  R1396     -5.8697527647018433e-01
    z[4,5,6]  R1397     -2.2447204589843750e-01
    z[4,5,6]  R1398     -1.5371930599212646e-01
    z[4,5,6]  R1399     2.1896651387214661e-01
    z[4,5,6]  R1400     -4.8337876796722412e-01
    z[4,5,6]  R1401     -4.9422928132116795e-03
    z[4,5,6]  R1402     -1.7492248117923737e-01
    z[4,5,6]  R1403     -0.311410129070282
    z[4,5,6]  R1404     -1.0314693674445152e-02
    z[4,5,6]  R1405     -2.7174046263098717e-02
    z[4,5,6]  R1406     7.0586074143648148e-03
    z[4,5,6]  R1407     1.6405366361141205e-01
    z[4,5,6]  R1408     -3.8203904032707214e-01
    z[4,5,6]  R1409     -5.4438419640064240e-02
    z[4,5,6]  R1410     3.2419890165328979e-01
    z[4,5,6]  R1411     -6.2903493642807007e-01
    z[4,5,6]  R1412     5.0851851701736450e-01
    z[4,5,6]  R1413     -9.3386769294738770e-02
    z[4,5,6]  R1414     -1.1720818281173706e-01
    z[4,5,6]  R1415     2.2354254126548767e-01
    z[4,5,6]  R1416     -1.8927467986941338e-02
    z[4,5,6]  R1417     -2.4369551241397858e-01
    z[4,5,6]  R1418     1.8381108343601227e-01
    z[4,5,6]  R1419     -8.8346116244792938e-02
    z[4,5,6]  R1420     -2.7376693487167358e-01
    z[4,5,6]  R1421     -2.8332561254501343e-01
    z[4,5,6]  R1422     -3.3860078454017639e-01
    z[4,5,6]  R1423     -0.162612646818161
    z[4,5,6]  R1424     -1.3697418570518494e-01
    z[4,5,6]  R1425     -2.4773661792278290e-01
    z[4,5,6]  R1426     -2.1843566000461578e-01
    z[4,5,6]  R1427     -2.4833329021930695e-01
    z[4,5,6]  R1428     -4.3179315328598022e-01
    z[4,5,6]  R1429     6.5703772008419037e-02
    z[4,5,6]  R1430     2.1743091940879822e-01
    z[4,5,6]  R1431     9.2737030982971191e-01
    z[4,5,6]  R1432     -7.8275352716445923e-03
    z[4,5,6]  R1433     4.1102525591850281e-01
    z[4,5,6]  R1434     2.8064385056495667e-01
    z[4,5,6]  R1435     3.2357770204544067e-01
    z[4,5,6]  R1436     8.7393354624509811e-03
    z[4,5,6]  R1437     2.0511406660079956e-01
    z[4,5,6]  R1438     0.0171315036714077
    z[4,5,6]  R1439     -2.1619510650634766e-01
    z[4,5,6]  R1440     -1.5170331113040447e-02
    z[4,5,6]  R1441     1.9643297791481018e-01
    z[4,5,6]  R1442     2.3596172034740448e-01
    z[4,5,6]  R1443     4.3225142359733582e-01
    z[4,5,6]  R1444     5.4549470543861389e-02
    z[4,5,6]  R1445     -1.4309340715408325e-01
    z[4,5,6]  R1446     6.6458913497626781e-03
    z[4,5,6]  R1447     -1.2633812613785267e-02
    z[4,5,6]  R1448     3.0579692125320435e-01
    z[4,5,6]  R1449     6.5246829763054848e-03
    z[4,5,6]  R1450     -2.9288670420646667e-01
    z[4,5,6]  R1451     -3.7556152790784836e-02
    z[4,5,6]  R1452     3.5523016005754471e-02
    z[4,5,6]  R1453     -3.5175466537475586e-01
    z[4,5,6]  R1454     -7.0717915892601013e-02
    z[4,5,6]  R1455     7.8487113118171692e-02
    z[4,5,6]  R1456     -0.0364740788936615
    z[4,5,6]  R1457     0.0526956282556057
    z[4,5,6]  R1458     -0.467650830745697
    z[4,5,6]  R1459     -1.8062326312065125e-01
    z[4,5,6]  R1460     1.9377009570598602e-01
    z[4,5,6]  R1461     3.4476491808891296e-01
    z[4,5,6]  R1462     2.3129351437091827e-01
    z[4,5,6]  R1463     -2.8235504031181335e-01
    z[4,5,6]  R1464     -1.7083956301212311e-01
    z[4,5,6]  R1465     1.6060256958007812e-01
    z[4,5,6]  R1466     -0.338640034198761
    z[4,5,6]  R1467     4.1116610169410706e-01
    z[4,5,6]  R1468     -4.1594886779785156e-01
    z[4,5,6]  R1469     2.9327373951673508e-02
    z[4,5,6]  R1470     1.2582798302173615e-01
    z[4,5,6]  R1471     -4.5803987979888916e-01
    z[4,5,6]  R1472     0.322462797164917
    z[4,5,6]  R1473     4.6945296227931976e-02
    z[4,5,6]  R1474     5.4985213279724121e-01
    z[4,5,6]  R1475     3.5038122534751892e-01
    z[4,5,6]  R1476     -7.9635508358478546e-02
    z[4,5,6]  R1477     -2.7669841051101685e-01
    z[4,5,6]  R1478     3.3492948859930038e-03
    z[4,5,6]  R1479     3.8852179050445557e-01
    z[4,5,6]  R1480     1.4089383184909821e-01
    z[4,5,6]  R1481     0.0661388486623764
    z[4,5,6]  R1482     1.3398852944374084e-01
    z[4,5,6]  R1483     -4.1340950876474380e-02
    z[4,5,6]  R1484     1.2800240516662598e-01
    z[4,5,6]  R1485     3.9807024598121643e-01
    z[4,5,6]  R1486     4.4987958669662476e-01
    z[4,5,6]  R1487     -1.5134380757808685e-01
    z[4,5,6]  R1488     1.3873670250177383e-02
    z[4,5,6]  R1489     1.6675025224685669e-02
    z[4,5,6]  R1490     -4.3066538870334625e-02
    z[4,5,6]  R1491     4.5195898413658142e-01
    z[4,5,6]  R1492     2.0104023814201355e-01
    z[4,5,6]  R1493     -2.5043779611587524e-01
    z[4,5,6]  R1494     -0.29730224609375
    z[4,5,6]  R1495     -2.0249387621879578e-01
    z[4,5,6]  R1496     -3.6114418506622314e-01
    z[4,5,6]  R1497     -2.7198314666748047e-01
    z[4,5,6]  R1498     -4.0662270784378052e-01
    z[5,4,0]  R38       1
    z[5,4,0]  R47       -1
    z[5,4,0]  R1499     -1
    z[5,4,0]  R1500     1
    z[5,4,0]  R1513     -3.3743920922279358e-01
    z[5,4,0]  R1514     -3.9628058671951294e-01
    z[5,4,0]  R1515     -2.5938609242439270e-01
    z[5,4,0]  R1516     -7.0217663049697876e-01
    z[5,4,0]  R1517     1.2838077545166016e-01
    z[5,4,0]  R1518     -6.8766087293624878e-01
    z[5,4,0]  R1519     -6.2176191806793213e-01
    z[5,4,0]  R1520     -5.6789475679397583e-01
    z[5,4,0]  R1521     -5.5205643177032471e-01
    z[5,4,0]  R1522     -4.6555015444755554e-01
    z[5,4,0]  R1523     4.2362403869628906e-01
    z[5,4,0]  R1524     -4.2511679232120514e-02
    z[5,4,0]  R1525     -8.1512147188186646e-01
    z[5,4,0]  R1526     -8.2804781198501587e-01
    z[5,4,0]  R1527     3.6391592025756836e-01
    z[5,4,0]  R1528     1.6448323428630829e-01
    z[5,4,0]  R1529     -6.7578339576721191e-01
    z[5,4,0]  R1530     -8.0015367269515991e-01
    z[5,4,0]  R1531     -3.6248150467872620e-01
    z[5,4,0]  R1532     -4.2786660790443420e-01
    z[5,4,0]  R1533     -9.4797289371490479e-01
    z[5,4,0]  R1534     3.8133431226015091e-02
    z[5,4,0]  R1535     3.2570844888687134e-01
    z[5,4,0]  R1536     1.1368932574987411e-01
    z[5,4,0]  R1537     4.2324790358543396e-01
    z[5,4,0]  R1538     -2.3786160349845886e-01
    z[5,4,0]  R1539     3.6844301223754883e-01
    z[5,4,0]  R1540     1.7988924682140350e-01
    z[5,4,0]  R1541     9.4721651077270508e-01
    z[5,4,0]  R1542     -6.5063394606113434e-02
    z[5,4,0]  R1543     -8.9545083045959473e-01
    z[5,4,0]  R1544     -4.6452856063842773e-01
    z[5,4,0]  R1545     -2.5964316725730896e-01
    z[5,4,0]  R1546     3.2282780855894089e-02
    z[5,4,0]  R1547     1.1634923284873366e-03
    z[5,4,0]  R1548     -4.2717915773391724e-01
    z[5,4,0]  R1549     -4.1456633806228638e-01
    z[5,4,0]  R1550     -2.3483836650848389e-01
    z[5,4,0]  R1551     -5.1700823009014130e-02
    z[5,4,0]  R1552     -1.9251120090484619e-01
    z[5,4,0]  R1553     2.7965842746198177e-03
    z[5,4,0]  R1554     -7.3569685220718384e-01
    z[5,4,0]  R1555     -7.1991771459579468e-01
    z[5,4,0]  R1556     -1.1196802370250225e-02
    z[5,4,0]  R1557     1.8641702830791473e-02
    z[5,4,0]  R1558     3.2393163442611694e-01
    z[5,4,0]  R1559     1.2809348106384277e-01
    z[5,4,0]  R1560     -8.0648861825466156e-02
    z[5,4,0]  R1561     2.4385492503643036e-01
    z[5,4,0]  R1562     3.1293833255767822e-01
    z[5,4,0]  R1563     6.7229464650154114e-02
    z[5,4,0]  R1564     3.0927827581763268e-02
    z[5,4,0]  R1565     -1.4215697348117828e-01
    z[5,4,0]  R1566     4.0148791670799255e-01
    z[5,4,0]  R1567     -2.9185411334037781e-01
    z[5,4,0]  R1568     -7.1345096826553345e-01
    z[5,4,0]  R1569     2.7783590555191040e-01
    z[5,4,0]  R1570     2.9050892591476440e-01
    z[5,4,0]  R1571     -1.9888277351856232e-01
    z[5,4,0]  R1572     1.0181367397308350e-01
    z[5,4,0]  R1573     -5.8129608631134033e-02
    z[5,4,0]  R1574     -7.6956844329833984e-01
    z[5,4,0]  R1575     1.4780323207378387e-01
    z[5,4,0]  R1576     2.8837344050407410e-01
    z[5,4,0]  R1577     2.4439045786857605e-01
    z[5,4,0]  R1578     1.2387710809707642e-01
    z[5,4,0]  R1579     6.7090421915054321e-01
    z[5,4,0]  R1580     4.0743890404701233e-01
    z[5,4,0]  R1581     2.7006670832633972e-01
    z[5,4,0]  R1582     1.7758893966674805e-01
    z[5,4,0]  R1583     4.1285350918769836e-01
    z[5,4,0]  R1584     3.8448178768157959e-01
    z[5,4,0]  R1585     1.1995550245046616e-01
    z[5,4,0]  R1586     2.0959652960300446e-01
    z[5,4,0]  R1587     6.0748201608657837e-01
    z[5,4,0]  R1588     4.7497734427452087e-01
    z[5,4,0]  R1589     2.8818449378013611e-01
    z[5,4,0]  R1590     -6.7278486490249634e-01
    z[5,4,0]  R1591     3.0296313762664795e-01
    z[5,4,0]  R1592     2.9295399785041809e-01
    z[5,4,0]  R1593     5.3371459245681763e-01
    z[5,4,0]  R1594     -3.9458143711090088e-01
    z[5,4,0]  R1595     -2.5424867868423462e-01
    z[5,4,0]  R1596     -1.4888504147529602e-01
    z[5,4,0]  R1597     3.2396411895751953e-01
    z[5,4,0]  R1598     1.2609507143497467e-01
    z[5,4,0]  R1599     -1.9771598279476166e-01
    z[5,4,0]  R1600     -1.7129307985305786e-01
    z[5,4,0]  R1601     2.2557590901851654e-01
    z[5,4,0]  R1602     -1.8372812867164612e-01
    z[5,4,0]  R1603     -1.3125183992087841e-02
    z[5,4,0]  R1604     -2.5624418631196022e-02
    z[5,4,0]  R1605     -1.9810365140438080e-01
    z[5,4,0]  R1606     -2.2849960252642632e-02
    z[5,4,0]  R1607     -2.4032703042030334e-01
    z[5,4,0]  R1608     -1.7159251868724823e-01
    z[5,4,0]  R1609     3.7596255540847778e-01
    z[5,4,0]  R1610     -2.3235681653022766e-01
    z[5,4,0]  R1611     -6.6991263628005981e-01
    z[5,4,0]  R1612     3.5354757308959961e-01
    z[5,4,0]  R1613     1.0167054831981659e-01
    z[5,4,0]  R1614     -2.4417449533939362e-01
    z[5,4,0]  R1615     -1.4748911559581757e-01
    z[5,4,0]  R1616     3.1215512752532959e-01
    z[5,4,0]  R1617     -3.8002294301986694e-01
    z[5,4,0]  R1618     0.0915653184056282
    z[5,4,0]  R1619     0.378814697265625
    z[5,4,0]  R1620     8.8293008506298065e-02
    z[5,4,0]  R1621     2.1603241562843323e-01
    z[5,4,0]  R1622     6.5152287483215332e-02
    z[5,4,0]  R1623     9.1169491410255432e-02
    z[5,4,0]  R1624     3.4985087811946869e-02
    z[5,4,0]  R1625     1.2196503579616547e-01
    z[5,4,0]  R1626     2.8525349497795105e-01
    z[5,4,0]  R1627     5.8857542276382446e-01
    z[5,4,0]  R1628     1.6893598437309265e-01
    z[5,4,0]  R1629     0.0400143563747406
    z[5,4,0]  R1630     4.2162124067544937e-02
    z[5,4,0]  R1631     -2.4480982124805450e-01
    z[5,4,0]  R1632     2.9493844509124756e-01
    z[5,4,1]  R39       1
    z[5,4,1]  R48       -1
    z[5,4,1]  R1501     -1
    z[5,4,1]  R1502     1
    z[5,4,1]  R1513     5.0013720989227295e-02
    z[5,4,1]  R1514     7.7343881130218506e-01
    z[5,4,1]  R1515     -7.6145604252815247e-02
    z[5,4,1]  R1516     1.2796878814697266e-01
    z[5,4,1]  R1517     3.0080916360020638e-02
    z[5,4,1]  R1518     -1.0028189420700073e-01
    z[5,4,1]  R1519     -0.0374673455953598
    z[5,4,1]  R1520     6.3147753477096558e-02
    z[5,4,1]  R1521     5.0335365533828735e-01
    z[5,4,1]  R1522     -4.1611157357692719e-02
    z[5,4,1]  R1523     -1.5959550440311432e-01
    z[5,4,1]  R1524     -2.9155075550079346e-01
    z[5,4,1]  R1525     1.6240240633487701e-01
    z[5,4,1]  R1526     1.1980239301919937e-01
    z[5,4,1]  R1527     -3.6802086979150772e-02
    z[5,4,1]  R1528     -4.5254769921302795e-01
    z[5,4,1]  R1529     2.1470628678798676e-01
    z[5,4,1]  R1530     -2.1832898259162903e-01
    z[5,4,1]  R1531     -1.3647566735744476e-01
    z[5,4,1]  R1532     2.1910087764263153e-01
    z[5,4,1]  R1533     1.7176677286624908e-01
    z[5,4,1]  R1534     -2.2571478784084320e-01
    z[5,4,1]  R1535     1.2229388207197189e-01
    z[5,4,1]  R1536     -1.4601200819015503e-01
    z[5,4,1]  R1537     0.363082617521286
    z[5,4,1]  R1538     1.4118406176567078e-01
    z[5,4,1]  R1539     9.6902884542942047e-02
    z[5,4,1]  R1540     0.703339695930481
    z[5,4,1]  R1541     2.9212915897369385e-01
    z[5,4,1]  R1542     -2.2574503719806671e-01
    z[5,4,1]  R1543     -0.0618734285235405
    z[5,4,1]  R1544     1.9577708095312119e-02
    z[5,4,1]  R1545     7.5356088578701019e-02
    z[5,4,1]  R1546     -3.6300602555274963e-01
    z[5,4,1]  R1547     -1.1443398892879486e-01
    z[5,4,1]  R1548     2.0309317111968994e-01
    z[5,4,1]  R1549     1.4620343223214149e-02
    z[5,4,1]  R1550     -0.1455088108778
    z[5,4,1]  R1551     4.6544772386550903e-01
    z[5,4,1]  R1552     1.9206671416759491e-01
    z[5,4,1]  R1553     -1.3569761812686920e-01
    z[5,4,1]  R1554     1.1002972722053528e-01
    z[5,4,1]  R1555     3.6919426172971725e-02
    z[5,4,1]  R1556     3.5758984088897705e-01
    z[5,4,1]  R1557     -1.9179159402847290e-01
    z[5,4,1]  R1558     9.9849283695220947e-02
    z[5,4,1]  R1559     1.9320188090205193e-02
    z[5,4,1]  R1560     -9.6033227443695068e-01
    z[5,4,1]  R1561     3.3115339279174805e-01
    z[5,4,1]  R1562     -8.9774757623672485e-01
    z[5,4,1]  R1563     -0.127201110124588
    z[5,4,1]  R1564     -1.4737728238105774e-01
    z[5,4,1]  R1565     -1.1822173744440079e-01
    z[5,4,1]  R1566     2.2839525341987610e-01
    z[5,4,1]  R1567     -3.2719787955284119e-01
    z[5,4,1]  R1568     3.3691179007291794e-02
    z[5,4,1]  R1569     5.0151222944259644e-01
    z[5,4,1]  R1570     4.6746385097503662e-01
    z[5,4,1]  R1571     3.5555484890937805e-01
    z[5,4,1]  R1572     1.8494389951229095e-01
    z[5,4,1]  R1573     2.5290858745574951e-01
    z[5,4,1]  R1574     9.5955148339271545e-02
    z[5,4,1]  R1575     3.8058131933212280e-02
    z[5,4,1]  R1576     1.9257250428199768e-01
    z[5,4,1]  R1577     3.2504150271415710e-01
    z[5,4,1]  R1578     -0.42623171210289
    z[5,4,1]  R1579     2.7800679206848145e-01
    z[5,4,1]  R1580     -8.0501812696456909e-01
    z[5,4,1]  R1581     -5.4595386981964111e-01
    z[5,4,1]  R1582     -7.9230827093124390e-01
    z[5,4,1]  R1583     -1.3202236592769623e-01
    z[5,4,1]  R1584     -4.5940056443214417e-02
    z[5,4,1]  R1585     -2.1939606964588165e-01
    z[5,4,1]  R1586     -1.8394032120704651e-01
    z[5,4,1]  R1587     1.7205059528350830e-02
    z[5,4,1]  R1588     7.5912439823150635e-01
    z[5,4,1]  R1589     7.2721993923187256e-01
    z[5,4,1]  R1590     4.0057358145713806e-01
    z[5,4,1]  R1591     4.7810387611389160e-01
    z[5,4,1]  R1592     5.6894439458847046e-01
    z[5,4,1]  R1593     -7.0877462625503540e-01
    z[5,4,1]  R1594     -3.9808529615402222e-01
    z[5,4,1]  R1595     -3.3675214648246765e-01
    z[5,4,1]  R1596     1.7925186082720757e-02
    z[5,4,1]  R1597     3.5206070542335510e-01
    z[5,4,1]  R1598     0.50312739610672
    z[5,4,1]  R1599     -4.9591645598411560e-01
    z[5,4,1]  R1600     0.0933518260717392
    z[5,4,1]  R1601     -2.0143432915210724e-01
    z[5,4,1]  R1602     -3.7276116013526917e-01
    z[5,4,1]  R1603     2.4780307710170746e-01
    z[5,4,1]  R1604     1.5220613777637482e-01
    z[5,4,1]  R1605     9.0704351663589478e-01
    z[5,4,1]  R1606     8.8989388942718506e-01
    z[5,4,1]  R1607     9.1480612754821777e-01
    z[5,4,1]  R1608     8.9418798685073853e-01
    z[5,4,1]  R1609     6.1804932355880737e-01
    z[5,4,1]  R1610     7.0757466554641724e-01
    z[5,4,1]  R1611     1.1783520132303238e-01
    z[5,4,1]  R1612     7.5609618425369263e-01
    z[5,4,1]  R1613     -2.7142059803009033e-01
    z[5,4,1]  R1614     2.2567722201347351e-01
    z[5,4,1]  R1615     1.3701331615447998e-01
    z[5,4,1]  R1616     3.0623498558998108e-01
    z[5,4,1]  R1617     1.4621399343013763e-01
    z[5,4,1]  R1618     9.1681569814682007e-01
    z[5,4,1]  R1619     0.743359386920929
    z[5,4,1]  R1620     7.9641348123550415e-01
    z[5,4,1]  R1621     7.5286239385604858e-01
    z[5,4,1]  R1622     5.7476663589477539e-01
    z[5,4,1]  R1623     6.2243533134460449e-01
    z[5,4,1]  R1624     8.3571928739547729e-01
    z[5,4,1]  R1625     8.1072479486465454e-01
    z[5,4,1]  R1626     6.7430537939071655e-01
    z[5,4,1]  R1627     6.6398453712463379e-01
    z[5,4,1]  R1628     3.8164768368005753e-02
    z[5,4,1]  R1629     -1.4380897395312786e-02
    z[5,4,1]  R1630     -1.4331623911857605e-02
    z[5,4,1]  R1631     1.4161263406276703e-01
    z[5,4,1]  R1632     7.4459767341613770e-01
    z[5,4,2]  R40       1
    z[5,4,2]  R49       -1
    z[5,4,2]  R1503     -1
    z[5,4,2]  R1504     1
    z[5,4,2]  R1513     -2.7480663266032934e-03
    z[5,4,2]  R1514     -1.8025057017803192e-01
    z[5,4,2]  R1515     -1.5111367404460907e-01
    z[5,4,2]  R1516     -6.2531381845474243e-01
    z[5,4,2]  R1517     -0.576040506362915
    z[5,4,2]  R1518     6.9555006921291351e-02
    z[5,4,2]  R1519     -2.6764407753944397e-01
    z[5,4,2]  R1520     8.3748415112495422e-02
    z[5,4,2]  R1521     -2.9789095744490623e-02
    z[5,4,2]  R1522     -4.6795919537544250e-01
    z[5,4,2]  R1523     2.8300043940544128e-01
    z[5,4,2]  R1524     1.9899943470954895e-01
    z[5,4,2]  R1525     -5.6615364737808704e-03
    z[5,4,2]  R1526     2.6696342229843140e-01
    z[5,4,2]  R1527     -0.378528356552124
    z[5,4,2]  R1528     2.0347647368907928e-01
    z[5,4,2]  R1529     0.451111763715744
    z[5,4,2]  R1530     -0.369780033826828
    z[5,4,2]  R1531     -6.7180544137954712e-01
    z[5,4,2]  R1532     2.8006893396377563e-01
    z[5,4,2]  R1533     7.3733977973461151e-02
    z[5,4,2]  R1534     -4.0530607104301453e-01
    z[5,4,2]  R1535     2.0929652452468872e-01
    z[5,4,2]  R1536     -4.7107699513435364e-01
    z[5,4,2]  R1537     -1.9881846010684967e-01
    z[5,4,2]  R1538     -4.2531794309616089e-01
    z[5,4,2]  R1539     -1.2713733315467834e-01
    z[5,4,2]  R1540     -3.9311133325099945e-02
    z[5,4,2]  R1541     7.7751971781253815e-02
    z[5,4,2]  R1542     -1.7520049214363098e-01
    z[5,4,2]  R1543     -2.6556059718132019e-01
    z[5,4,2]  R1544     8.8238745927810669e-02
    z[5,4,2]  R1545     -5.9851235151290894e-01
    z[5,4,2]  R1546     -1.8945337831974030e-01
    z[5,4,2]  R1547     -2.8400018811225891e-01
    z[5,4,2]  R1548     -4.8823755979537964e-01
    z[5,4,2]  R1549     -4.7088220715522766e-01
    z[5,4,2]  R1550     1.6361738741397858e-01
    z[5,4,2]  R1551     -3.5027843713760376e-01
    z[5,4,2]  R1552     3.4251760691404343e-02
    z[5,4,2]  R1553     -9.2639058828353882e-02
    z[5,4,2]  R1554     -6.0383662581443787e-02
    z[5,4,2]  R1555     -7.6555326581001282e-02
    z[5,4,2]  R1556     3.3232295513153076e-01
    z[5,4,2]  R1557     3.7315258383750916e-01
    z[5,4,2]  R1558     -6.9189921021461487e-02
    z[5,4,2]  R1559     -2.5692909955978394e-02
    z[5,4,2]  R1560     1.8732752650976181e-02
    z[5,4,2]  R1561     1.2506689876317978e-02
    z[5,4,2]  R1562     -1.4842711389064789e-01
    z[5,4,2]  R1563     -3.4748205542564392e-01
    z[5,4,2]  R1564     1.3803166337311268e-02
    z[5,4,2]  R1565     2.2150658071041107e-01
    z[5,4,2]  R1566     -2.1676330268383026e-01
    z[5,4,2]  R1567     -2.4882483482360840e-01
    z[5,4,2]  R1568     -2.5127208232879639e-01
    z[5,4,2]  R1569     -3.1067386269569397e-01
    z[5,4,2]  R1570     -8.3406358957290649e-02
    z[5,4,2]  R1571     8.8219016790390015e-02
    z[5,4,2]  R1572     9.0795040130615234e-02
    z[5,4,2]  R1573     2.4200503528118134e-01
    z[5,4,2]  R1574     2.7575361728668213e-01
    z[5,4,2]  R1575     1.8716080486774445e-01
    z[5,4,2]  R1576     -1.4385522902011871e-01
    z[5,4,2]  R1577     1.4106544852256775e-01
    z[5,4,2]  R1578     -7.1391791105270386e-01
    z[5,4,2]  R1579     -1.9359122216701508e-01
    z[5,4,2]  R1580     -5.2252197638154030e-03
    z[5,4,2]  R1581     -6.7500865459442139e-01
    z[5,4,2]  R1582     -3.7807437777519226e-01
    z[5,4,2]  R1583     -4.7414809465408325e-01
    z[5,4,2]  R1584     -8.2871162891387939e-01
    z[5,4,2]  R1585     1.4623082242906094e-02
    z[5,4,2]  R1586     -5.7248926162719727e-01
    z[5,4,2]  R1587     -3.7738669663667679e-02
    z[5,4,2]  R1588     -2.4280330538749695e-01
    z[5,4,2]  R1589     3.7362776696681976e-02
    z[5,4,2]  R1590     9.4783097505569458e-02
    z[5,4,2]  R1591     -1.2289097905158997e-01
    z[5,4,2]  R1592     -1.7647363245487213e-01
    z[5,4,2]  R1593     4.1203033924102783e-01
    z[5,4,2]  R1594     2.3994788527488708e-01
    z[5,4,2]  R1595     1.6720631718635559e-01
    z[5,4,2]  R1596     1.2837819755077362e-01
    z[5,4,2]  R1597     4.0040275454521179e-01
    z[5,4,2]  R1598     1.3345356285572052e-01
    z[5,4,2]  R1599     -3.3194657415151596e-02
    z[5,4,2]  R1600     2.5313520431518555e-01
    z[5,4,2]  R1601     -4.1206502914428711e-01
    z[5,4,2]  R1602     -1.8811488151550293e-01
    z[5,4,2]  R1603     7.2802215814590454e-01
    z[5,4,2]  R1604     0.571914792060852
    z[5,4,2]  R1605     1.5345154702663422e-01
    z[5,4,2]  R1606     -2.9085204005241394e-01
    z[5,4,2]  R1607     6.4979223534464836e-03
    z[5,4,2]  R1608     -3.2424005866050720e-01
    z[5,4,2]  R1609     -5.5171851068735123e-02
    z[5,4,2]  R1610     -1.0804910957813263e-01
    z[5,4,2]  R1611     -2.4583692848682404e-01
    z[5,4,2]  R1612     -1.6915802657604218e-01
    z[5,4,2]  R1613     -1.6012535989284515e-01
    z[5,4,2]  R1614     8.7762826681137085e-01
    z[5,4,2]  R1615     4.9203032255172729e-01
    z[5,4,2]  R1616     5.3925096988677979e-01
    z[5,4,2]  R1617     8.7598901987075806e-01
    z[5,4,2]  R1618     -3.3536902070045471e-01
    z[5,4,2]  R1619     -5.1727157086133957e-02
    z[5,4,2]  R1620     -9.1836132109165192e-02
    z[5,4,2]  R1621     5.6509021669626236e-02
    z[5,4,2]  R1622     1.4021563343703747e-02
    z[5,4,2]  R1623     -4.2121402919292450e-02
    z[5,4,2]  R1624     6.2648139894008636e-02
    z[5,4,2]  R1625     0.0945080816745758
    z[5,4,2]  R1626     -1.9648608565330505e-01
    z[5,4,2]  R1627     1.4892233535647392e-02
    z[5,4,2]  R1628     1.6314502060413361e-01
    z[5,4,2]  R1629     3.1280573457479477e-02
    z[5,4,2]  R1630     -7.9890981316566467e-02
    z[5,4,2]  R1631     2.4777954444289207e-02
    z[5,4,2]  R1632     -0.0759509950876236
    z[5,4,3]  R41       1
    z[5,4,3]  R50       -1
    z[5,4,3]  R1505     -1
    z[5,4,3]  R1506     1
    z[5,4,3]  R1513     8.4794139862060547e-01
    z[5,4,3]  R1514     3.2732598483562469e-02
    z[5,4,3]  R1515     1.2854616343975067e-01
    z[5,4,3]  R1516     2.5573524832725525e-01
    z[5,4,3]  R1517     -0.0929994285106659
    z[5,4,3]  R1518     3.8197305798530579e-01
    z[5,4,3]  R1519     2.6172673702239990e-01
    z[5,4,3]  R1520     -2.3769235238432884e-02
    z[5,4,3]  R1521     1.7954589426517487e-01
    z[5,4,3]  R1522     6.2927208840847015e-02
    z[5,4,3]  R1523     -1.4314524829387665e-01
    z[5,4,3]  R1524     -3.7112697958946228e-01
    z[5,4,3]  R1525     -2.5143089890480042e-01
    z[5,4,3]  R1526     -3.7390291690826416e-01
    z[5,4,3]  R1527     -6.7231279611587524e-01
    z[5,4,3]  R1528     -4.8959153890609741e-01
    z[5,4,3]  R1529     -4.8098337650299072e-01
    z[5,4,3]  R1530     3.2516199350357056e-01
    z[5,4,3]  R1531     -4.0193176269531250e-01
    z[5,4,3]  R1532     -5.7705879211425781e-01
    z[5,4,3]  R1533     1.5771088004112244e-01
    z[5,4,3]  R1534     -5.3457766771316528e-01
    z[5,4,3]  R1535     -8.1588435173034668e-01
    z[5,4,3]  R1536     -1.3636319339275360e-01
    z[5,4,3]  R1537     -6.7196983098983765e-01
    z[5,4,3]  R1538     -6.3788032531738281e-01
    z[5,4,3]  R1539     -9.1128838062286377e-01
    z[5,4,3]  R1540     -0.515089750289917
    z[5,4,3]  R1541     -6.3510864973068237e-02
    z[5,4,3]  R1542     -8.2945835590362549e-01
    z[5,4,3]  R1543     -2.5645342469215393e-01
    z[5,4,3]  R1544     -7.6517832279205322e-01
    z[5,4,3]  R1545     -4.1942179203033447e-01
    z[5,4,3]  R1546     -8.5967427492141724e-01
    z[5,4,3]  R1547     -0.651572048664093
    z[5,4,3]  R1548     -5.7658779621124268e-01
    z[5,4,3]  R1549     -0.748293399810791
    z[5,4,3]  R1550     -6.7190760374069214e-01
    z[5,4,3]  R1551     -5.7095140218734741e-01
    z[5,4,3]  R1552     -7.0784342288970947e-01
    z[5,4,3]  R1553     -9.8207664489746094e-01
    z[5,4,3]  R1554     4.7516539692878723e-01
    z[5,4,3]  R1555     -1.6965904831886292e-01
    z[5,4,3]  R1556     -4.7302126884460449e-01
    z[5,4,3]  R1557     -2.3581373691558838e-01
    z[5,4,3]  R1558     -0.278064489364624
    z[5,4,3]  R1559     -1.0975673794746399e-02
    z[5,4,3]  R1560     1.6037112474441528e-01
    z[5,4,3]  R1561     -1.0819870978593826e-01
    z[5,4,3]  R1562     2.4428753554821014e-01
    z[5,4,3]  R1563     -0.629863440990448
    z[5,4,3]  R1564     -0.517500638961792
    z[5,4,3]  R1565     -3.1145122647285461e-01
    z[5,4,3]  R1566     -3.9131855964660645e-01
    z[5,4,3]  R1567     -2.0772920548915863e-01
    z[5,4,3]  R1568     -3.0627167224884033e-01
    z[5,4,3]  R1569     -3.7720578908920288e-01
    z[5,4,3]  R1570     -3.2554894685745239e-01
    z[5,4,3]  R1571     -0.820368766784668
    z[5,4,3]  R1572     -7.8444075584411621e-01
    z[5,4,3]  R1573     -8.9112937450408936e-01
    z[5,4,3]  R1574     2.3417022824287415e-01
    z[5,4,3]  R1575     -7.4661165475845337e-01
    z[5,4,3]  R1576     -1.1544159799814224e-01
    z[5,4,3]  R1577     -8.4097707271575928e-01
    z[5,4,3]  R1578     -3.4149774909019470e-01
    z[5,4,3]  R1579     -2.0160059630870819e-01
    z[5,4,3]  R1580     -2.0965600013732910e-01
    z[5,4,3]  R1581     2.4074146151542664e-01
    z[5,4,3]  R1582     -9.7188048064708710e-02
    z[5,4,3]  R1583     9.4759769737720490e-02
    z[5,4,3]  R1584     9.6813887357711792e-02
    z[5,4,3]  R1585     8.2054913043975830e-02
    z[5,4,3]  R1586     -2.0222092047333717e-02
    z[5,4,3]  R1587     -1.4055344462394714e-01
    z[5,4,3]  R1588     1.3506911695003510e-01
    z[5,4,3]  R1589     1.6846060752868652e-01
    z[5,4,3]  R1590     -2.1175147965550423e-02
    z[5,4,3]  R1591     4.6630653738975525e-01
    z[5,4,3]  R1592     0.623343288898468
    z[5,4,3]  R1593     -1.3740181922912598e-01
    z[5,4,3]  R1594     -2.2141449153423309e-01
    z[5,4,3]  R1595     1.3829699158668518e-01
    z[5,4,3]  R1596     -7.6564550399780273e-01
    z[5,4,3]  R1597     1.7201645672321320e-01
    z[5,4,3]  R1598     -6.3344007730484009e-01
    z[5,4,3]  R1599     -0.415695458650589
    z[5,4,3]  R1600     3.7936963140964508e-02
    z[5,4,3]  R1601     -5.5727396160364151e-02
    z[5,4,3]  R1602     8.7636536359786987e-01
    z[5,4,3]  R1603     -4.5097228884696960e-01
    z[5,4,3]  R1604     2.6321390271186829e-01
    z[5,4,3]  R1605     5.3094297647476196e-02
    z[5,4,3]  R1606     1.1101468652486801e-01
    z[5,4,3]  R1607     2.6173036545515060e-02
    z[5,4,3]  R1608     9.6922911703586578e-02
    z[5,4,3]  R1609     3.5951477289199829e-01
    z[5,4,3]  R1610     4.6084529161453247e-01
    z[5,4,3]  R1611     2.0157489180564880e-01
    z[5,4,3]  R1612     1.5019841492176056e-01
    z[5,4,3]  R1613     -4.6264287829399109e-01
    z[5,4,3]  R1614     -1.3778880238533020e-03
    z[5,4,3]  R1615     4.8098187893629074e-02
    z[5,4,3]  R1616     -5.7226948440074921e-02
    z[5,4,3]  R1617     -9.2000365257263184e-02
    z[5,4,3]  R1618     4.1226636618375778e-02
    z[5,4,3]  R1619     3.9620363712310791e-01
    z[5,4,3]  R1620     -4.6701491810381413e-03
    z[5,4,3]  R1621     2.9443684220314026e-01
    z[5,4,3]  R1622     6.2322062253952026e-01
    z[5,4,3]  R1623     4.3258953094482422e-01
    z[5,4,3]  R1624     4.1657385230064392e-01
    z[5,4,3]  R1625     -7.4566014111042023e-02
    z[5,4,3]  R1626     4.5363315939903259e-01
    z[5,4,3]  R1627     -1.3361506164073944e-01
    z[5,4,3]  R1628     7.1216380596160889e-01
    z[5,4,3]  R1629     0.600469172000885
    z[5,4,3]  R1630     7.9959535598754883e-01
    z[5,4,3]  R1631     7.2746020555496216e-01
    z[5,4,3]  R1632     2.0860774442553520e-02
    z[5,4,4]  R42       1
    z[5,4,4]  R51       -1
    z[5,4,4]  R1507     -1
    z[5,4,4]  R1508     1
    z[5,4,4]  R1513     -3.4905603528022766e-01
    z[5,4,4]  R1514     -4.0481212735176086e-01
    z[5,4,4]  R1515     -1.5143294632434845e-01
    z[5,4,4]  R1516     -1.7119763791561127e-01
    z[5,4,4]  R1517     6.0256570577621460e-01
    z[5,4,4]  R1518     5.0337827205657959e-01
    z[5,4,4]  R1519     5.8340936899185181e-01
    z[5,4,4]  R1520     6.5137690305709839e-01
    z[5,4,4]  R1521     6.0403895378112793e-01
    z[5,4,4]  R1522     2.7985429763793945e-01
    z[5,4,4]  R1523     -8.0465364456176758e-01
    z[5,4,4]  R1524     -7.1471405029296875e-01
    z[5,4,4]  R1525     0.266798734664917
    z[5,4,4]  R1526     1.6667881608009338e-01
    z[5,4,4]  R1527     1.0656679421663284e-01
    z[5,4,4]  R1528     6.8941771984100342e-01
    z[5,4,4]  R1529     9.8088867962360382e-02
    z[5,4,4]  R1530     1.4819258451461792e-01
    z[5,4,4]  R1531     7.3480650782585144e-02
    z[5,4,4]  R1532     3.9599311351776123e-01
    z[5,4,4]  R1533     -1.5154494345188141e-01
    z[5,4,4]  R1534     5.3375542163848877e-01
    z[5,4,4]  R1535     3.1585705280303955e-01
    z[5,4,4]  R1536     6.6348546743392944e-01
    z[5,4,4]  R1537     1.8702732026576996e-01
    z[5,4,4]  R1538     5.3000879287719727e-01
    z[5,4,4]  R1539     -3.7306804209947586e-02
    z[5,4,4]  R1540     3.6943724751472473e-01
    z[5,4,4]  R1541     5.9650752693414688e-02
    z[5,4,4]  R1542     -0.0385153628885746
    z[5,4,4]  R1543     -5.6886758655309677e-02
    z[5,4,4]  R1544     2.7707213163375854e-01
    z[5,4,4]  R1545     1.3641911745071411e-01
    z[5,4,4]  R1546     1.2633895874023438e-01
    z[5,4,4]  R1547     3.1312310695648193e-01
    z[5,4,4]  R1548     2.9254177585244179e-02
    z[5,4,4]  R1549     1.2450111657381058e-01
    z[5,4,4]  R1550     4.0761077404022217e-01
    z[5,4,4]  R1551     3.9535003900527954e-01
    z[5,4,4]  R1552     4.6522179245948792e-01
    z[5,4,4]  R1553     5.6966792792081833e-02
    z[5,4,4]  R1554     4.3650454282760620e-01
    z[5,4,4]  R1555     -2.4670800194144249e-02
    z[5,4,4]  R1556     0.501748263835907
    z[5,4,4]  R1557     6.9103544950485229e-01
    z[5,4,4]  R1558     0.691504955291748
    z[5,4,4]  R1559     6.1777377128601074e-01
    z[5,4,4]  R1560     1.9605021178722382e-01
    z[5,4,4]  R1561     0.828144371509552
    z[5,4,4]  R1562     1.1928584426641464e-01
    z[5,4,4]  R1563     2.9502838850021362e-01
    z[5,4,4]  R1564     8.2690107822418213e-01
    z[5,4,4]  R1565     7.9405295848846436e-01
    z[5,4,4]  R1566     7.4105972051620483e-01
    z[5,4,4]  R1567     4.9315702915191650e-01
    z[5,4,4]  R1568     4.9408420920372009e-01
    z[5,4,4]  R1569     2.1096305549144745e-01
    z[5,4,4]  R1570     4.5030426979064941e-01
    z[5,4,4]  R1571     -2.6139688491821289e-01
    z[5,4,4]  R1572     -3.6400434374809265e-01
    z[5,4,4]  R1573     0.222420796751976
    z[5,4,4]  R1574     4.9646505713462830e-01
    z[5,4,4]  R1575     4.2365917563438416e-01
    z[5,4,4]  R1576     5.3762644529342651e-01
    z[5,4,4]  R1577     -1.4177824556827545e-01
    z[5,4,4]  R1578     -2.9641222953796387e-01
    z[5,4,4]  R1579     -4.6315023303031921e-01
    z[5,4,4]  R1580     4.2114172130823135e-02
    z[5,4,4]  R1581     -1.2323540449142456e-01
    z[5,4,4]  R1582     -1.3724432885646820e-01
    z[5,4,4]  R1583     -6.7960780858993530e-01
    z[5,4,4]  R1584     -1.3993211090564728e-01
    z[5,4,4]  R1585     -2.9488596320152283e-01
    z[5,4,4]  R1586     7.0823854207992554e-01
    z[5,4,4]  R1587     6.7547351121902466e-01
    z[5,4,4]  R1588     2.6978189125657082e-02
    z[5,4,4]  R1589     -1.2629888951778412e-01
    z[5,4,4]  R1590     -4.1531139612197876e-01
    z[5,4,4]  R1591     1.1978959292173386e-01
    z[5,4,4]  R1592     1.2435131520032883e-01
    z[5,4,4]  R1593     4.9273487180471420e-02
    z[5,4,4]  R1594     1.8249136209487915e-01
    z[5,4,4]  R1595     5.3202575445175171e-01
    z[5,4,4]  R1596     5.2533334493637085e-01
    z[5,4,4]  R1597     9.3137837946414948e-02
    z[5,4,4]  R1598     8.3275333046913147e-02
    z[5,4,4]  R1599     1.3587783277034760e-01
    z[5,4,4]  R1600     5.7541990280151367e-01
    z[5,4,4]  R1601     1.7288066446781158e-01
    z[5,4,4]  R1602     -1.4637543819844723e-02
    z[5,4,4]  R1603     -5.5954560637474060e-02
    z[5,4,4]  R1604     -3.6770024895668030e-01
    z[5,4,4]  R1605     -1.8873862922191620e-01
    z[5,4,4]  R1606     2.2558660805225372e-01
    z[5,4,4]  R1607     -8.2657516002655029e-02
    z[5,4,4]  R1608     -9.6800431609153748e-02
    z[5,4,4]  R1609     -1.6078034043312073e-01
    z[5,4,4]  R1610     -1.9464877247810364e-01
    z[5,4,4]  R1611     -4.1220435500144958e-01
    z[5,4,4]  R1612     2.9235166311264038e-01
    z[5,4,4]  R1613     8.0781751871109009e-01
    z[5,4,4]  R1614     1.1478152871131897e-01
    z[5,4,4]  R1615     4.2002722620964050e-01
    z[5,4,4]  R1616     4.8885148763656616e-01
    z[5,4,4]  R1617     -1.6488823294639587e-01
    z[5,4,4]  R1618     1.3348235189914703e-01
    z[5,4,4]  R1619     -1.6731470823287964e-01
    z[5,4,4]  R1620     1.3335452415049076e-02
    z[5,4,4]  R1621     2.2520011663436890e-01
    z[5,4,4]  R1622     -7.5253896415233612e-02
    z[5,4,4]  R1623     3.9314761757850647e-02
    z[5,4,4]  R1624     1.0867656767368317e-01
    z[5,4,4]  R1625     -2.3046325147151947e-01
    z[5,4,4]  R1626     -1.1870503425598145e-01
    z[5,4,4]  R1627     -1.5901979058980942e-02
    z[5,4,4]  R1628     7.6755732297897339e-02
    z[5,4,4]  R1629     9.0735845267772675e-02
    z[5,4,4]  R1630     -0.0392913781106472
    z[5,4,4]  R1631     6.7949362099170685e-02
    z[5,4,4]  R1632     -4.0598297119140625e-01
    z[5,4,5]  R43       1
    z[5,4,5]  R52       -1
    z[5,4,5]  R1509     -1
    z[5,4,5]  R1510     1
    z[5,4,5]  R1513     1.9612286984920502e-01
    z[5,4,5]  R1514     0.00659114308655262
    z[5,4,5]  R1515     6.7923456430435181e-02
    z[5,4,5]  R1516     6.9166854023933411e-02
    z[5,4,5]  R1517     -3.3183541893959045e-01
    z[5,4,5]  R1518     -1.8486261367797852e-01
    z[5,4,5]  R1519     -1.6372244060039520e-01
    z[5,4,5]  R1520     4.9148839712142944e-01
    z[5,4,5]  R1521     4.2542457580566406e-02
    z[5,4,5]  R1522     6.9280147552490234e-01
    z[5,4,5]  R1523     -1.6861215233802795e-02
    z[5,4,5]  R1524     4.7413975000381470e-01
    z[5,4,5]  R1525     -3.6903324723243713e-01
    z[5,4,5]  R1526     -7.3834314942359924e-02
    z[5,4,5]  R1527     -2.6967558264732361e-01
    z[5,4,5]  R1528     -9.3652546405792236e-02
    z[5,4,5]  R1529     1.7964974045753479e-01
    z[5,4,5]  R1530     -2.1820570528507233e-01
    z[5,4,5]  R1531     -4.8119717836380005e-01
    z[5,4,5]  R1532     -3.2736396789550781e-01
    z[5,4,5]  R1533     1.3610869646072388e-01
    z[5,4,5]  R1534     -3.5619491338729858e-01
    z[5,4,5]  R1535     -2.6136147975921631e-01
    z[5,4,5]  R1536     -5.3270250558853149e-01
    z[5,4,5]  R1537     -1.9811446964740753e-01
    z[5,4,5]  R1538     2.2314096987247467e-01
    z[5,4,5]  R1539     -2.6403328403830528e-02
    z[5,4,5]  R1540     -2.6129683852195740e-01
    z[5,4,5]  R1541     -3.2052453607320786e-02
    z[5,4,5]  R1542     -0.0769997164607048
    z[5,4,5]  R1543     -1.4895573258399963e-01
    z[5,4,5]  R1544     -2.7609825134277344e-01
    z[5,4,5]  R1545     -5.0527429580688477e-01
    z[5,4,5]  R1546     -1.5097571909427643e-01
    z[5,4,5]  R1547     -5.5129927396774292e-01
    z[5,4,5]  R1548     -4.1880735754966736e-01
    z[5,4,5]  R1549     -7.0386335253715515e-02
    z[5,4,5]  R1550     -4.0573894977569580e-01
    z[5,4,5]  R1551     -8.1521391868591309e-02
    z[5,4,5]  R1552     -1.8544414639472961e-01
    z[5,4,5]  R1553     -6.6456802189350128e-02
    z[5,4,5]  R1554     -1.0414634644985199e-01
    z[5,4,5]  R1555     4.8507860302925110e-01
    z[5,4,5]  R1556     -4.2671182751655579e-01
    z[5,4,5]  R1557     -5.3692048788070679e-01
    z[5,4,5]  R1558     -1.4991647005081177e-01
    z[5,4,5]  R1559     -6.9139486551284790e-01
    z[5,4,5]  R1560     -2.0259751006960869e-02
    z[5,4,5]  R1561     -2.3795737326145172e-01
    z[5,4,5]  R1562     -1.3097479008138180e-02
    z[5,4,5]  R1563     -4.7311460971832275e-01
    z[5,4,5]  R1564     -7.5560718774795532e-02
    z[5,4,5]  R1565     -4.2994603514671326e-01
    z[5,4,5]  R1566     -1.3929808139801025e-01
    z[5,4,5]  R1567     -6.7659783363342285e-01
    z[5,4,5]  R1568     2.6908889412879944e-01
    z[5,4,5]  R1569     -4.7908765077590942e-01
    z[5,4,5]  R1570     -4.2305770516395569e-01
    z[5,4,5]  R1571     2.4900914728641510e-01
    z[5,4,5]  R1572     4.4625878334045410e-01
    z[5,4,5]  R1573     -0.173871248960495
    z[5,4,5]  R1574     -1.3910108804702759e-01
    z[5,4,5]  R1575     2.2220280021429062e-02
    z[5,4,5]  R1576     -7.1852356195449829e-01
    z[5,4,5]  R1577     1.5703302621841431e-01
    z[5,4,5]  R1578     -2.0799359306693077e-02
    z[5,4,5]  R1579     3.7278345227241516e-01
    z[5,4,5]  R1580     0.0987817645072937
    z[5,4,5]  R1581     -1.6199807822704315e-01
    z[5,4,5]  R1582     6.4389050006866455e-02
    z[5,4,5]  R1583     0.0559404082596302
    z[5,4,5]  R1584     2.8066992759704590e-01
    z[5,4,5]  R1585     8.0574375391006470e-01
    z[5,4,5]  R1586     2.9041644930839539e-01
    z[5,4,5]  R1587     -1.9368024542927742e-02
    z[5,4,5]  R1588     1.7122475430369377e-02
    z[5,4,5]  R1589     5.5484312772750854e-01
    z[5,4,5]  R1590     1.7156814038753510e-01
    z[5,4,5]  R1591     6.0017108917236328e-01
    z[5,4,5]  R1592     3.5948729515075684e-01
    z[5,4,5]  R1593     -1.2933203834109008e-04
    z[5,4,5]  R1594     -5.3700095415115356e-01
    z[5,4,5]  R1595     -6.5760958194732666e-01
    z[5,4,5]  R1596     -2.5490492582321167e-01
    z[5,4,5]  R1597     -7.4669677019119263e-01
    z[5,4,5]  R1598     -0.489662230014801
    z[5,4,5]  R1599     -5.2383244037628174e-01
    z[5,4,5]  R1600     -4.6987172961235046e-01
    z[5,4,5]  R1601     -8.0954384803771973e-01
    z[5,4,5]  R1602     -6.7603783681988716e-03
    z[5,4,5]  R1603     3.9236697554588318e-01
    z[5,4,5]  R1604     -4.5929306745529175e-01
    z[5,4,5]  R1605     2.7570620179176331e-01
    z[5,4,5]  R1606     1.7076404392719269e-01
    z[5,4,5]  R1607     2.8928220272064209e-02
    z[5,4,5]  R1608     2.1675245463848114e-01
    z[5,4,5]  R1609     5.6372302770614624e-01
    z[5,4,5]  R1610     4.2820256948471069e-01
    z[5,4,5]  R1611     -4.8932361602783203e-01
    z[5,4,5]  R1612     1.4396293461322784e-01
    z[5,4,5]  R1613     -1.4416243135929108e-01
    z[5,4,5]  R1614     -0.0305878184735775
    z[5,4,5]  R1615     -3.7809950113296509e-01
    z[5,4,5]  R1616     1.3094292581081390e-01
    z[5,4,5]  R1617     -1.4991295337677002e-01
    z[5,4,5]  R1618     7.3057748377323151e-02
    z[5,4,5]  R1619     2.5748360157012939e-01
    z[5,4,5]  R1620     5.9070986509323120e-01
    z[5,4,5]  R1621     4.3190208077430725e-01
    z[5,4,5]  R1622     4.8718398809432983e-01
    z[5,4,5]  R1623     0.637184202671051
    z[5,4,5]  R1624     1.9008395075798035e-01
    z[5,4,5]  R1625     4.2423000931739807e-01
    z[5,4,5]  R1626     3.0134943127632141e-01
    z[5,4,5]  R1627     4.0979641675949097e-01
    z[5,4,5]  R1628     6.4152711629867554e-01
    z[5,4,5]  R1629     7.5302320718765259e-01
    z[5,4,5]  R1630     5.5047595500946045e-01
    z[5,4,5]  R1631     5.6913548707962036e-01
    z[5,4,5]  R1632     -3.3383011817932129e-02
    z[5,4,6]  R44       1
    z[5,4,6]  R53       -1
    z[5,4,6]  R1511     -1
    z[5,4,6]  R1512     1
    z[5,4,6]  R1513     6.5703772008419037e-02
    z[5,4,6]  R1514     2.1743091940879822e-01
    z[5,4,6]  R1515     9.2737030982971191e-01
    z[5,4,6]  R1516     -7.8275352716445923e-03
    z[5,4,6]  R1517     4.1102525591850281e-01
    z[5,4,6]  R1518     2.8064385056495667e-01
    z[5,4,6]  R1519     3.2357770204544067e-01
    z[5,4,6]  R1520     8.7393354624509811e-03
    z[5,4,6]  R1521     2.0511406660079956e-01
    z[5,4,6]  R1522     0.0171315036714077
    z[5,4,6]  R1523     -2.1619510650634766e-01
    z[5,4,6]  R1524     -1.5170331113040447e-02
    z[5,4,6]  R1525     1.9643297791481018e-01
    z[5,4,6]  R1526     2.3596172034740448e-01
    z[5,4,6]  R1527     4.3225142359733582e-01
    z[5,4,6]  R1528     5.4549470543861389e-02
    z[5,4,6]  R1529     -1.4309340715408325e-01
    z[5,4,6]  R1530     6.6458913497626781e-03
    z[5,4,6]  R1531     -1.2633812613785267e-02
    z[5,4,6]  R1532     3.0579692125320435e-01
    z[5,4,6]  R1533     6.5246829763054848e-03
    z[5,4,6]  R1534     -2.9288670420646667e-01
    z[5,4,6]  R1535     -3.7556152790784836e-02
    z[5,4,6]  R1536     3.5523016005754471e-02
    z[5,4,6]  R1537     -3.5175466537475586e-01
    z[5,4,6]  R1538     -7.0717915892601013e-02
    z[5,4,6]  R1539     7.8487113118171692e-02
    z[5,4,6]  R1540     -0.0364740788936615
    z[5,4,6]  R1541     0.0526956282556057
    z[5,4,6]  R1542     -0.467650830745697
    z[5,4,6]  R1543     -1.8062326312065125e-01
    z[5,4,6]  R1544     1.9377009570598602e-01
    z[5,4,6]  R1545     3.4476491808891296e-01
    z[5,4,6]  R1546     2.3129351437091827e-01
    z[5,4,6]  R1547     -2.8235504031181335e-01
    z[5,4,6]  R1548     -1.7083956301212311e-01
    z[5,4,6]  R1549     1.6060256958007812e-01
    z[5,4,6]  R1550     -0.338640034198761
    z[5,4,6]  R1551     4.1116610169410706e-01
    z[5,4,6]  R1552     -4.1594886779785156e-01
    z[5,4,6]  R1553     2.9327373951673508e-02
    z[5,4,6]  R1554     1.2582798302173615e-01
    z[5,4,6]  R1555     -4.5803987979888916e-01
    z[5,4,6]  R1556     0.322462797164917
    z[5,4,6]  R1557     4.6945296227931976e-02
    z[5,4,6]  R1558     5.4985213279724121e-01
    z[5,4,6]  R1559     3.5038122534751892e-01
    z[5,4,6]  R1560     -7.9635508358478546e-02
    z[5,4,6]  R1561     -2.7669841051101685e-01
    z[5,4,6]  R1562     3.3492948859930038e-03
    z[5,4,6]  R1563     3.8852179050445557e-01
    z[5,4,6]  R1564     1.4089383184909821e-01
    z[5,4,6]  R1565     0.0661388486623764
    z[5,4,6]  R1566     1.3398852944374084e-01
    z[5,4,6]  R1567     -4.1340950876474380e-02
    z[5,4,6]  R1568     1.2800240516662598e-01
    z[5,4,6]  R1569     3.9807024598121643e-01
    z[5,4,6]  R1570     4.4987958669662476e-01
    z[5,4,6]  R1571     -1.5134380757808685e-01
    z[5,4,6]  R1572     1.3873670250177383e-02
    z[5,4,6]  R1573     1.6675025224685669e-02
    z[5,4,6]  R1574     -4.3066538870334625e-02
    z[5,4,6]  R1575     4.5195898413658142e-01
    z[5,4,6]  R1576     2.0104023814201355e-01
    z[5,4,6]  R1577     -2.5043779611587524e-01
    z[5,4,6]  R1578     -0.29730224609375
    z[5,4,6]  R1579     -2.0249387621879578e-01
    z[5,4,6]  R1580     -3.6114418506622314e-01
    z[5,4,6]  R1581     -2.7198314666748047e-01
    z[5,4,6]  R1582     -4.0662270784378052e-01
    z[5,4,6]  R1583     3.3664533495903015e-01
    z[5,4,6]  R1584     2.3573417961597443e-01
    z[5,4,6]  R1585     4.4084972143173218e-01
    z[5,4,6]  R1586     -9.0215429663658142e-02
    z[5,4,6]  R1587     3.9096099138259888e-01
    z[5,4,6]  R1588     3.4627810120582581e-01
    z[5,4,6]  R1589     1.8580521643161774e-01
    z[5,4,6]  R1590     4.1898670792579651e-01
    z[5,4,6]  R1591     -2.6931622624397278e-01
    z[5,4,6]  R1592     -1.6151136159896851e-01
    z[5,4,6]  R1593     -1.4734691381454468e-01
    z[5,4,6]  R1594     5.0750488042831421e-01
    z[5,4,6]  R1595     2.4365903437137604e-01
    z[5,4,6]  R1596     1.8402788043022156e-01
    z[5,4,6]  R1597     1.2230180203914642e-01
    z[5,4,6]  R1598     2.5534853339195251e-01
    z[5,4,6]  R1599     4.9820411205291748e-01
    z[5,4,6]  R1600     -5.8697527647018433e-01
    z[5,4,6]  R1601     -2.2447204589843750e-01
    z[5,4,6]  R1602     -1.5371930599212646e-01
    z[5,4,6]  R1603     2.1896651387214661e-01
    z[5,4,6]  R1604     -4.8337876796722412e-01
    z[5,4,6]  R1605     -4.9422928132116795e-03
    z[5,4,6]  R1606     -1.7492248117923737e-01
    z[5,4,6]  R1607     -0.311410129070282
    z[5,4,6]  R1608     -1.0314693674445152e-02
    z[5,4,6]  R1609     -2.7174046263098717e-02
    z[5,4,6]  R1610     7.0586074143648148e-03
    z[5,4,6]  R1611     1.6405366361141205e-01
    z[5,4,6]  R1612     -3.8203904032707214e-01
    z[5,4,6]  R1613     -5.4438419640064240e-02
    z[5,4,6]  R1614     3.2419890165328979e-01
    z[5,4,6]  R1615     -6.2903493642807007e-01
    z[5,4,6]  R1616     5.0851851701736450e-01
    z[5,4,6]  R1617     -9.3386769294738770e-02
    z[5,4,6]  R1618     -1.1720818281173706e-01
    z[5,4,6]  R1619     2.2354254126548767e-01
    z[5,4,6]  R1620     -1.8927467986941338e-02
    z[5,4,6]  R1621     -2.4369551241397858e-01
    z[5,4,6]  R1622     1.8381108343601227e-01
    z[5,4,6]  R1623     -8.8346116244792938e-02
    z[5,4,6]  R1624     -2.7376693487167358e-01
    z[5,4,6]  R1625     -2.8332561254501343e-01
    z[5,4,6]  R1626     -3.3860078454017639e-01
    z[5,4,6]  R1627     -0.162612646818161
    z[5,4,6]  R1628     -1.3697418570518494e-01
    z[5,4,6]  R1629     -2.4773661792278290e-01
    z[5,4,6]  R1630     -2.1843566000461578e-01
    z[5,4,6]  R1631     -2.4833329021930695e-01
    z[5,4,6]  R1632     -4.3179315328598022e-01
    z[4,10,0]  R38       -1
    z[4,10,0]  R92       1
    z[4,10,0]  R1633     -1
    z[4,10,0]  R1634     1
    z[4,10,0]  R1647     4.1285350918769836e-01
    z[4,10,0]  R1648     3.8448178768157959e-01
    z[4,10,0]  R1649     1.1995550245046616e-01
    z[4,10,0]  R1650     2.0959652960300446e-01
    z[4,10,0]  R1651     6.0748201608657837e-01
    z[4,10,0]  R1652     4.7497734427452087e-01
    z[4,10,0]  R1653     2.8818449378013611e-01
    z[4,10,0]  R1654     -6.7278486490249634e-01
    z[4,10,0]  R1655     3.0296313762664795e-01
    z[4,10,0]  R1656     2.9295399785041809e-01
    z[4,10,0]  R1657     5.3371459245681763e-01
    z[4,10,0]  R1658     -3.9458143711090088e-01
    z[4,10,0]  R1659     -2.5424867868423462e-01
    z[4,10,0]  R1660     -1.4888504147529602e-01
    z[4,10,0]  R1661     3.2396411895751953e-01
    z[4,10,0]  R1662     1.2609507143497467e-01
    z[4,10,0]  R1663     -1.9771598279476166e-01
    z[4,10,0]  R1664     -1.7129307985305786e-01
    z[4,10,0]  R1665     2.2557590901851654e-01
    z[4,10,0]  R1666     -1.8372812867164612e-01
    z[4,10,0]  R1667     -1.3125183992087841e-02
    z[4,10,0]  R1668     -2.5624418631196022e-02
    z[4,10,0]  R1669     -1.9810365140438080e-01
    z[4,10,0]  R1670     -2.2849960252642632e-02
    z[4,10,0]  R1671     -2.4032703042030334e-01
    z[4,10,0]  R1672     -1.7159251868724823e-01
    z[4,10,0]  R1673     3.7596255540847778e-01
    z[4,10,0]  R1674     -2.3235681653022766e-01
    z[4,10,0]  R1675     -6.6991263628005981e-01
    z[4,10,0]  R1676     3.5354757308959961e-01
    z[4,10,0]  R1677     1.0167054831981659e-01
    z[4,10,0]  R1678     -2.4417449533939362e-01
    z[4,10,0]  R1679     -1.4748911559581757e-01
    z[4,10,0]  R1680     3.1215512752532959e-01
    z[4,10,0]  R1681     -3.8002294301986694e-01
    z[4,10,0]  R1682     0.0915653184056282
    z[4,10,0]  R1683     0.378814697265625
    z[4,10,0]  R1684     8.8293008506298065e-02
    z[4,10,0]  R1685     2.1603241562843323e-01
    z[4,10,0]  R1686     6.5152287483215332e-02
    z[4,10,0]  R1687     9.1169491410255432e-02
    z[4,10,0]  R1688     3.4985087811946869e-02
    z[4,10,0]  R1689     1.2196503579616547e-01
    z[4,10,0]  R1690     2.8525349497795105e-01
    z[4,10,0]  R1691     5.8857542276382446e-01
    z[4,10,0]  R1692     1.6893598437309265e-01
    z[4,10,0]  R1693     0.0400143563747406
    z[4,10,0]  R1694     4.2162124067544937e-02
    z[4,10,0]  R1695     -2.4480982124805450e-01
    z[4,10,0]  R1696     2.9493844509124756e-01
    z[4,10,0]  R1697     -3.9636448025703430e-01
    z[4,10,0]  R1698     -2.1843071281909943e-01
    z[4,10,0]  R1699     -5.5052655935287476e-01
    z[4,10,0]  R1700     -5.1393687725067139e-02
    z[4,10,0]  R1701     -1.1332868784666061e-01
    z[4,10,0]  R1702     -1.8592710793018341e-01
    z[4,10,0]  R1703     3.6510050296783447e-01
    z[4,10,0]  R1704     2.6070839166641235e-01
    z[4,10,0]  R1705     -1.9142383709549904e-02
    z[4,10,0]  R1706     -4.2343366146087646e-01
    z[4,10,0]  R1707     4.0896305441856384e-01
    z[4,10,0]  R1708     -9.6639342606067657e-02
    z[4,10,0]  R1709     -4.7348892688751221e-01
    z[4,10,0]  R1710     -1.7088831961154938e-01
    z[4,10,0]  R1711     -1.2774877250194550e-02
    z[4,10,0]  R1712     2.2630387544631958e-01
    z[4,10,0]  R1713     1.8719108402729034e-01
    z[4,10,0]  R1714     -3.3848896622657776e-01
    z[4,10,0]  R1715     6.2727910280227661e-01
    z[4,10,0]  R1716     -3.6651602387428284e-01
    z[4,10,0]  R1717     -9.5985263586044312e-02
    z[4,10,0]  R1718     1.1450875550508499e-01
    z[4,10,0]  R1719     1.0657140612602234e-01
    z[4,10,0]  R1720     2.9993700981140137e-01
    z[4,10,0]  R1721     -3.0955451726913452e-01
    z[4,10,0]  R1722     -5.6630626320838928e-02
    z[4,10,0]  R1723     2.1666556596755981e-02
    z[4,10,0]  R1724     4.6906974911689758e-01
    z[4,10,0]  R1725     -7.2263628244400024e-01
    z[4,10,0]  R1726     -3.6497896909713745e-01
    z[4,10,0]  R1727     -1.9985330104827881e-01
    z[4,10,0]  R1728     -3.8029614835977554e-02
    z[4,10,0]  R1729     -2.6851644739508629e-02
    z[4,10,0]  R1730     1.5648564696311951e-01
    z[4,10,0]  R1731     5.9689271450042725e-01
    z[4,10,0]  R1732     2.2789795696735382e-01
    z[4,10,0]  R1733     -2.8174072504043579e-01
    z[4,10,0]  R1734     6.2675297260284424e-01
    z[4,10,0]  R1735     -3.2631557434797287e-02
    z[4,10,0]  R1736     5.2217852324247360e-02
    z[4,10,1]  R39       -1
    z[4,10,1]  R93       1
    z[4,10,1]  R1635     -1
    z[4,10,1]  R1636     1
    z[4,10,1]  R1647     -1.3202236592769623e-01
    z[4,10,1]  R1648     -4.5940056443214417e-02
    z[4,10,1]  R1649     -2.1939606964588165e-01
    z[4,10,1]  R1650     -1.8394032120704651e-01
    z[4,10,1]  R1651     1.7205059528350830e-02
    z[4,10,1]  R1652     7.5912439823150635e-01
    z[4,10,1]  R1653     7.2721993923187256e-01
    z[4,10,1]  R1654     4.0057358145713806e-01
    z[4,10,1]  R1655     4.7810387611389160e-01
    z[4,10,1]  R1656     5.6894439458847046e-01
    z[4,10,1]  R1657     -7.0877462625503540e-01
    z[4,10,1]  R1658     -3.9808529615402222e-01
    z[4,10,1]  R1659     -3.3675214648246765e-01
    z[4,10,1]  R1660     1.7925186082720757e-02
    z[4,10,1]  R1661     3.5206070542335510e-01
    z[4,10,1]  R1662     0.50312739610672
    z[4,10,1]  R1663     -4.9591645598411560e-01
    z[4,10,1]  R1664     0.0933518260717392
    z[4,10,1]  R1665     -2.0143432915210724e-01
    z[4,10,1]  R1666     -3.7276116013526917e-01
    z[4,10,1]  R1667     2.4780307710170746e-01
    z[4,10,1]  R1668     1.5220613777637482e-01
    z[4,10,1]  R1669     9.0704351663589478e-01
    z[4,10,1]  R1670     8.8989388942718506e-01
    z[4,10,1]  R1671     9.1480612754821777e-01
    z[4,10,1]  R1672     8.9418798685073853e-01
    z[4,10,1]  R1673     6.1804932355880737e-01
    z[4,10,1]  R1674     7.0757466554641724e-01
    z[4,10,1]  R1675     1.1783520132303238e-01
    z[4,10,1]  R1676     7.5609618425369263e-01
    z[4,10,1]  R1677     -2.7142059803009033e-01
    z[4,10,1]  R1678     2.2567722201347351e-01
    z[4,10,1]  R1679     1.3701331615447998e-01
    z[4,10,1]  R1680     3.0623498558998108e-01
    z[4,10,1]  R1681     1.4621399343013763e-01
    z[4,10,1]  R1682     9.1681569814682007e-01
    z[4,10,1]  R1683     0.743359386920929
    z[4,10,1]  R1684     7.9641348123550415e-01
    z[4,10,1]  R1685     7.5286239385604858e-01
    z[4,10,1]  R1686     5.7476663589477539e-01
    z[4,10,1]  R1687     6.2243533134460449e-01
    z[4,10,1]  R1688     8.3571928739547729e-01
    z[4,10,1]  R1689     8.1072479486465454e-01
    z[4,10,1]  R1690     6.7430537939071655e-01
    z[4,10,1]  R1691     6.6398453712463379e-01
    z[4,10,1]  R1692     3.8164768368005753e-02
    z[4,10,1]  R1693     -1.4380897395312786e-02
    z[4,10,1]  R1694     -1.4331623911857605e-02
    z[4,10,1]  R1695     1.4161263406276703e-01
    z[4,10,1]  R1696     7.4459767341613770e-01
    z[4,10,1]  R1697     -1.0856962949037552e-01
    z[4,10,1]  R1698     1.5542726218700409e-01
    z[4,10,1]  R1699     -1.1899171397089958e-02
    z[4,10,1]  R1700     -7.4997544288635254e-02
    z[4,10,1]  R1701     4.1021695733070374e-01
    z[4,10,1]  R1702     -3.9665222167968750e-02
    z[4,10,1]  R1703     4.5404410362243652e-01
    z[4,10,1]  R1704     4.4423744082450867e-01
    z[4,10,1]  R1705     2.4021776020526886e-01
    z[4,10,1]  R1706     4.6866810321807861e-01
    z[4,10,1]  R1707     1.7533724009990692e-01
    z[4,10,1]  R1708     1.4846704900264740e-01
    z[4,10,1]  R1709     -2.9659056663513184e-01
    z[4,10,1]  R1710     -4.6645447611808777e-01
    z[4,10,1]  R1711     -7.6093202829360962e-01
    z[4,10,1]  R1712     -7.7744621038436890e-01
    z[4,10,1]  R1713     -9.4802898168563843e-01
    z[4,10,1]  R1714     -3.0477842688560486e-01
    z[4,10,1]  R1715     -1.8231703341007233e-01
    z[4,10,1]  R1716     0.0208007600158453
    z[4,10,1]  R1717     -0.379312664270401
    z[4,10,1]  R1718     6.0360127687454224e-01
    z[4,10,1]  R1719     -1.1329365521669388e-01
    z[4,10,1]  R1720     -3.0436906218528748e-01
    z[4,10,1]  R1721     2.7989361435174942e-02
    z[4,10,1]  R1722     0.67806077003479
    z[4,10,1]  R1723     1.3304229080677032e-01
    z[4,10,1]  R1724     -5.4952919483184814e-01
    z[4,10,1]  R1725     5.9685826301574707e-01
    z[4,10,1]  R1726     7.9292759299278259e-02
    z[4,10,1]  R1727     -6.0732532292604446e-02
    z[4,10,1]  R1728     -1.7408357560634613e-01
    z[4,10,1]  R1729     2.4137814342975616e-01
    z[4,10,1]  R1730     -3.1413719058036804e-02
    z[4,10,1]  R1731     -2.7527580037713051e-02
    z[4,10,1]  R1732     8.8575951755046844e-02
    z[4,10,1]  R1733     -5.5882513523101807e-01
    z[4,10,1]  R1734     0.430237740278244
    z[4,10,1]  R1735     -6.8249548785388470e-03
    z[4,10,1]  R1736     -2.4141646921634674e-01
    z[4,10,2]  R40       -1
    z[4,10,2]  R94       1
    z[4,10,2]  R1637     -1
    z[4,10,2]  R1638     1
    z[4,10,2]  R1647     -4.7414809465408325e-01
    z[4,10,2]  R1648     -8.2871162891387939e-01
    z[4,10,2]  R1649     1.4623082242906094e-02
    z[4,10,2]  R1650     -5.7248926162719727e-01
    z[4,10,2]  R1651     -3.7738669663667679e-02
    z[4,10,2]  R1652     -2.4280330538749695e-01
    z[4,10,2]  R1653     3.7362776696681976e-02
    z[4,10,2]  R1654     9.4783097505569458e-02
    z[4,10,2]  R1655     -1.2289097905158997e-01
    z[4,10,2]  R1656     -1.7647363245487213e-01
    z[4,10,2]  R1657     4.1203033924102783e-01
    z[4,10,2]  R1658     2.3994788527488708e-01
    z[4,10,2]  R1659     1.6720631718635559e-01
    z[4,10,2]  R1660     1.2837819755077362e-01
    z[4,10,2]  R1661     4.0040275454521179e-01
    z[4,10,2]  R1662     1.3345356285572052e-01
    z[4,10,2]  R1663     -3.3194657415151596e-02
    z[4,10,2]  R1664     2.5313520431518555e-01
    z[4,10,2]  R1665     -4.1206502914428711e-01
    z[4,10,2]  R1666     -1.8811488151550293e-01
    z[4,10,2]  R1667     7.2802215814590454e-01
    z[4,10,2]  R1668     0.571914792060852
    z[4,10,2]  R1669     1.5345154702663422e-01
    z[4,10,2]  R1670     -2.9085204005241394e-01
    z[4,10,2]  R1671     6.4979223534464836e-03
    z[4,10,2]  R1672     -3.2424005866050720e-01
    z[4,10,2]  R1673     -5.5171851068735123e-02
    z[4,10,2]  R1674     -1.0804910957813263e-01
    z[4,10,2]  R1675     -2.4583692848682404e-01
    z[4,10,2]  R1676     -1.6915802657604218e-01
    z[4,10,2]  R1677     -1.6012535989284515e-01
    z[4,10,2]  R1678     8.7762826681137085e-01
    z[4,10,2]  R1679     4.9203032255172729e-01
    z[4,10,2]  R1680     5.3925096988677979e-01
    z[4,10,2]  R1681     8.7598901987075806e-01
    z[4,10,2]  R1682     -3.3536902070045471e-01
    z[4,10,2]  R1683     -5.1727157086133957e-02
    z[4,10,2]  R1684     -9.1836132109165192e-02
    z[4,10,2]  R1685     5.6509021669626236e-02
    z[4,10,2]  R1686     1.4021563343703747e-02
    z[4,10,2]  R1687     -4.2121402919292450e-02
    z[4,10,2]  R1688     6.2648139894008636e-02
    z[4,10,2]  R1689     0.0945080816745758
    z[4,10,2]  R1690     -1.9648608565330505e-01
    z[4,10,2]  R1691     1.4892233535647392e-02
    z[4,10,2]  R1692     1.6314502060413361e-01
    z[4,10,2]  R1693     3.1280573457479477e-02
    z[4,10,2]  R1694     -7.9890981316566467e-02
    z[4,10,2]  R1695     2.4777954444289207e-02
    z[4,10,2]  R1696     -0.0759509950876236
    z[4,10,2]  R1697     -2.9010385274887085e-01
    z[4,10,2]  R1698     -2.3738962411880493e-01
    z[4,10,2]  R1699     -2.5479811429977417e-01
    z[4,10,2]  R1700     -5.6889832019805908e-01
    z[4,10,2]  R1701     -2.5653791427612305e-01
    z[4,10,2]  R1702     -5.0786983966827393e-01
    z[4,10,2]  R1703     2.6203829050064087e-01
    z[4,10,2]  R1704     5.5182456970214844e-02
    z[4,10,2]  R1705     -6.7197734117507935e-01
    z[4,10,2]  R1706     6.0794495046138763e-02
    z[4,10,2]  R1707     2.9034504666924477e-02
    z[4,10,2]  R1708     1.1902976036071777e-01
    z[4,10,2]  R1709     1.1844386905431747e-01
    z[4,10,2]  R1710     -1.0425622761249542e-01
    z[4,10,2]  R1711     8.9256383478641510e-02
    z[4,10,2]  R1712     2.5807061791419983e-01
    z[4,10,2]  R1713     -0.00564618781208992
    z[4,10,2]  R1714     -7.6905570924282074e-02
    z[4,10,2]  R1715     1.9678516313433647e-02
    z[4,10,2]  R1716     1.1538688093423843e-01
    z[4,10,2]  R1717     -2.1094707772135735e-02
    z[4,10,2]  R1718     4.1736122965812683e-01
    z[4,10,2]  R1719     7.0153094828128815e-02
    z[4,10,2]  R1720     -3.8802798837423325e-02
    z[4,10,2]  R1721     1.8816716969013214e-01
    z[4,10,2]  R1722     2.3320975899696350e-01
    z[4,10,2]  R1723     -4.6710226684808731e-02
    z[4,10,2]  R1724     7.3537260293960571e-02
    z[4,10,2]  R1725     -3.7699963431805372e-03
    z[4,10,2]  R1726     -8.2393847405910492e-02
    z[4,10,2]  R1727     -7.5839266180992126e-02
    z[4,10,2]  R1728     2.0828737318515778e-01
    z[4,10,2]  R1729     1.2249260395765305e-01
    z[4,10,2]  R1730     -1.1270281672477722e-01
    z[4,10,2]  R1731     -2.6481010019779205e-02
    z[4,10,2]  R1732     -2.3649835586547852e-01
    z[4,10,2]  R1733     -4.7293606400489807e-01
    z[4,10,2]  R1734     -1.7638376355171204e-01
    z[4,10,2]  R1735     -2.5224119424819946e-01
    z[4,10,2]  R1736     2.0095808804035187e-01
    z[4,10,3]  R41       -1
    z[4,10,3]  R95       1
    z[4,10,3]  R1639     -1
    z[4,10,3]  R1640     1
    z[4,10,3]  R1647     9.4759769737720490e-02
    z[4,10,3]  R1648     9.6813887357711792e-02
    z[4,10,3]  R1649     8.2054913043975830e-02
    z[4,10,3]  R1650     -2.0222092047333717e-02
    z[4,10,3]  R1651     -1.4055344462394714e-01
    z[4,10,3]  R1652     1.3506911695003510e-01
    z[4,10,3]  R1653     1.6846060752868652e-01
    z[4,10,3]  R1654     -2.1175147965550423e-02
    z[4,10,3]  R1655     4.6630653738975525e-01
    z[4,10,3]  R1656     0.623343288898468
    z[4,10,3]  R1657     -1.3740181922912598e-01
    z[4,10,3]  R1658     -2.2141449153423309e-01
    z[4,10,3]  R1659     1.3829699158668518e-01
    z[4,10,3]  R1660     -7.6564550399780273e-01
    z[4,10,3]  R1661     1.7201645672321320e-01
    z[4,10,3]  R1662     -6.3344007730484009e-01
    z[4,10,3]  R1663     -0.415695458650589
    z[4,10,3]  R1664     3.7936963140964508e-02
    z[4,10,3]  R1665     -5.5727396160364151e-02
    z[4,10,3]  R1666     8.7636536359786987e-01
    z[4,10,3]  R1667     -4.5097228884696960e-01
    z[4,10,3]  R1668     2.6321390271186829e-01
    z[4,10,3]  R1669     5.3094297647476196e-02
    z[4,10,3]  R1670     1.1101468652486801e-01
    z[4,10,3]  R1671     2.6173036545515060e-02
    z[4,10,3]  R1672     9.6922911703586578e-02
    z[4,10,3]  R1673     3.5951477289199829e-01
    z[4,10,3]  R1674     4.6084529161453247e-01
    z[4,10,3]  R1675     2.0157489180564880e-01
    z[4,10,3]  R1676     1.5019841492176056e-01
    z[4,10,3]  R1677     -4.6264287829399109e-01
    z[4,10,3]  R1678     -1.3778880238533020e-03
    z[4,10,3]  R1679     4.8098187893629074e-02
    z[4,10,3]  R1680     -5.7226948440074921e-02
    z[4,10,3]  R1681     -9.2000365257263184e-02
    z[4,10,3]  R1682     4.1226636618375778e-02
    z[4,10,3]  R1683     3.9620363712310791e-01
    z[4,10,3]  R1684     -4.6701491810381413e-03
    z[4,10,3]  R1685     2.9443684220314026e-01
    z[4,10,3]  R1686     6.2322062253952026e-01
    z[4,10,3]  R1687     4.3258953094482422e-01
    z[4,10,3]  R1688     4.1657385230064392e-01
    z[4,10,3]  R1689     -7.4566014111042023e-02
    z[4,10,3]  R1690     4.5363315939903259e-01
    z[4,10,3]  R1691     -1.3361506164073944e-01
    z[4,10,3]  R1692     7.1216380596160889e-01
    z[4,10,3]  R1693     0.600469172000885
    z[4,10,3]  R1694     7.9959535598754883e-01
    z[4,10,3]  R1695     7.2746020555496216e-01
    z[4,10,3]  R1696     2.0860774442553520e-02
    z[4,10,3]  R1697     0.681239128112793
    z[4,10,3]  R1698     0.60472571849823
    z[4,10,3]  R1699     6.0739618539810181e-01
    z[4,10,3]  R1700     5.0476962327957153e-01
    z[4,10,3]  R1701     7.8265631198883057e-01
    z[4,10,3]  R1702     7.2275739908218384e-01
    z[4,10,3]  R1703     2.7796402573585510e-01
    z[4,10,3]  R1704     3.9726930856704712e-01
    z[4,10,3]  R1705     1.5290898084640503e-01
    z[4,10,3]  R1706     4.6916228532791138e-01
    z[4,10,3]  R1707     -5.4265791177749634e-01
    z[4,10,3]  R1708     -2.4831391870975494e-01
    z[4,10,3]  R1709     -5.9818738698959351e-01
    z[4,10,3]  R1710     -3.9339289069175720e-01
    z[4,10,3]  R1711     -0.0786762535572052
    z[4,10,3]  R1712     3.8056049495935440e-02
    z[4,10,3]  R1713     -2.0746810361742973e-02
    z[4,10,3]  R1714     -8.0624771118164062e-01
    z[4,10,3]  R1715     0.659960150718689
    z[4,10,3]  R1716     -8.2981234788894653e-01
    z[4,10,3]  R1717     -7.2701941244304180e-03
    z[4,10,3]  R1718     -3.7577623128890991e-01
    z[4,10,3]  R1719     -4.4316515326499939e-02
    z[4,10,3]  R1720     1.3924965262413025e-01
    z[4,10,3]  R1721     -2.1064251661300659e-01
    z[4,10,3]  R1722     3.6444085836410522e-01
    z[4,10,3]  R1723     2.8647786378860474e-01
    z[4,10,3]  R1724     -6.1262732744216919e-01
    z[4,10,3]  R1725     -1.9766797125339508e-01
    z[4,10,3]  R1726     -5.6900459527969360e-01
    z[4,10,3]  R1727     2.1127900481224060e-01
    z[4,10,3]  R1728     -9.1145741939544678e-01
    z[4,10,3]  R1729     -8.0859714746475220e-01
    z[4,10,3]  R1730     -7.2537130117416382e-01
    z[4,10,3]  R1731     -5.8372038602828979e-01
    z[4,10,3]  R1732     -4.6204555034637451e-01
    z[4,10,3]  R1733     2.8942093253135681e-01
    z[4,10,3]  R1734     5.1352846622467041e-01
    z[4,10,3]  R1735     -0.468342125415802
    z[4,10,3]  R1736     -5.5705946683883667e-01
    z[4,10,4]  R42       -1
    z[4,10,4]  R96       1
    z[4,10,4]  R1641     -1
    z[4,10,4]  R1642     1
    z[4,10,4]  R1647     -6.7960780858993530e-01
    z[4,10,4]  R1648     -1.3993211090564728e-01
    z[4,10,4]  R1649     -2.9488596320152283e-01
    z[4,10,4]  R1650     7.0823854207992554e-01
    z[4,10,4]  R1651     6.7547351121902466e-01
    z[4,10,4]  R1652     2.6978189125657082e-02
    z[4,10,4]  R1653     -1.2629888951778412e-01
    z[4,10,4]  R1654     -4.1531139612197876e-01
    z[4,10,4]  R1655     1.1978959292173386e-01
    z[4,10,4]  R1656     1.2435131520032883e-01
    z[4,10,4]  R1657     4.9273487180471420e-02
    z[4,10,4]  R1658     1.8249136209487915e-01
    z[4,10,4]  R1659     5.3202575445175171e-01
    z[4,10,4]  R1660     5.2533334493637085e-01
    z[4,10,4]  R1661     9.3137837946414948e-02
    z[4,10,4]  R1662     8.3275333046913147e-02
    z[4,10,4]  R1663     1.3587783277034760e-01
    z[4,10,4]  R1664     5.7541990280151367e-01
    z[4,10,4]  R1665     1.7288066446781158e-01
    z[4,10,4]  R1666     -1.4637543819844723e-02
    z[4,10,4]  R1667     -5.5954560637474060e-02
    z[4,10,4]  R1668     -3.6770024895668030e-01
    z[4,10,4]  R1669     -1.8873862922191620e-01
    z[4,10,4]  R1670     2.2558660805225372e-01
    z[4,10,4]  R1671     -8.2657516002655029e-02
    z[4,10,4]  R1672     -9.6800431609153748e-02
    z[4,10,4]  R1673     -1.6078034043312073e-01
    z[4,10,4]  R1674     -1.9464877247810364e-01
    z[4,10,4]  R1675     -4.1220435500144958e-01
    z[4,10,4]  R1676     2.9235166311264038e-01
    z[4,10,4]  R1677     8.0781751871109009e-01
    z[4,10,4]  R1678     1.1478152871131897e-01
    z[4,10,4]  R1679     4.2002722620964050e-01
    z[4,10,4]  R1680     4.8885148763656616e-01
    z[4,10,4]  R1681     -1.6488823294639587e-01
    z[4,10,4]  R1682     1.3348235189914703e-01
    z[4,10,4]  R1683     -1.6731470823287964e-01
    z[4,10,4]  R1684     1.3335452415049076e-02
    z[4,10,4]  R1685     2.2520011663436890e-01
    z[4,10,4]  R1686     -7.5253896415233612e-02
    z[4,10,4]  R1687     3.9314761757850647e-02
    z[4,10,4]  R1688     1.0867656767368317e-01
    z[4,10,4]  R1689     -2.3046325147151947e-01
    z[4,10,4]  R1690     -1.1870503425598145e-01
    z[4,10,4]  R1691     -1.5901979058980942e-02
    z[4,10,4]  R1692     7.6755732297897339e-02
    z[4,10,4]  R1693     9.0735845267772675e-02
    z[4,10,4]  R1694     -0.0392913781106472
    z[4,10,4]  R1695     6.7949362099170685e-02
    z[4,10,4]  R1696     -4.0598297119140625e-01
    z[4,10,4]  R1697     -0.373605340719223
    z[4,10,4]  R1698     -4.2356446385383606e-01
    z[4,10,4]  R1699     -0.398029625415802
    z[4,10,4]  R1700     -4.5387169718742371e-01
    z[4,10,4]  R1701     -2.6355615258216858e-01
    z[4,10,4]  R1702     -2.7197670936584473e-01
    z[4,10,4]  R1703     -2.3760432004928589e-01
    z[4,10,4]  R1704     2.5522655248641968e-01
    z[4,10,4]  R1705     -5.6038123369216919e-01
    z[4,10,4]  R1706     -3.9787578582763672e-01
    z[4,10,4]  R1707     2.4450273811817169e-01
    z[4,10,4]  R1708     0.608993411064148
    z[4,10,4]  R1709     5.3822201490402222e-01
    z[4,10,4]  R1710     7.5127941370010376e-01
    z[4,10,4]  R1711     9.2514185234904289e-03
    z[4,10,4]  R1712     -2.5473731756210327e-01
    z[4,10,4]  R1713     -1.2457814998924732e-02
    z[4,10,4]  R1714     1.0844941437244415e-01
    z[4,10,4]  R1715     -2.1772688627243042e-01
    z[4,10,4]  R1716     1.3864155113697052e-01
    z[4,10,4]  R1717     -7.7451360225677490e-01
    z[4,10,4]  R1718     1.9043922424316406e-02
    z[4,10,4]  R1719     -9.7413694858551025e-01
    z[4,10,4]  R1720     -8.8898915052413940e-01
    z[4,10,4]  R1721     -6.9305545091629028e-01
    z[4,10,4]  R1722     -3.1474456191062927e-01
    z[4,10,4]  R1723     -6.7333787679672241e-01
    z[4,10,4]  R1724     2.5464621186256409e-01
    z[4,10,4]  R1725     -2.3097757995128632e-01
    z[4,10,4]  R1726     6.5534484386444092e-01
    z[4,10,4]  R1727     -8.8822716474533081e-01
    z[4,10,4]  R1728     2.6076236367225647e-01
    z[4,10,4]  R1729     5.9483081102371216e-02
    z[4,10,4]  R1730     6.3341581821441650e-01
    z[4,10,4]  R1731     3.4353023767471313e-01
    z[4,10,4]  R1732     5.9049171209335327e-01
    z[4,10,4]  R1733     3.7947988510131836e-01
    z[4,10,4]  R1734     4.8621911555528641e-02
    z[4,10,4]  R1735     7.9095101356506348e-01
    z[4,10,4]  R1736     1.3062059879302979e-01
    z[4,10,5]  R43       -1
    z[4,10,5]  R97       1
    z[4,10,5]  R1643     -1
    z[4,10,5]  R1644     1
    z[4,10,5]  R1647     0.0559404082596302
    z[4,10,5]  R1648     2.8066992759704590e-01
    z[4,10,5]  R1649     8.0574375391006470e-01
    z[4,10,5]  R1650     2.9041644930839539e-01
    z[4,10,5]  R1651     -1.9368024542927742e-02
    z[4,10,5]  R1652     1.7122475430369377e-02
    z[4,10,5]  R1653     5.5484312772750854e-01
    z[4,10,5]  R1654     1.7156814038753510e-01
    z[4,10,5]  R1655     6.0017108917236328e-01
    z[4,10,5]  R1656     3.5948729515075684e-01
    z[4,10,5]  R1657     -1.2933203834109008e-04
    z[4,10,5]  R1658     -5.3700095415115356e-01
    z[4,10,5]  R1659     -6.5760958194732666e-01
    z[4,10,5]  R1660     -2.5490492582321167e-01
    z[4,10,5]  R1661     -7.4669677019119263e-01
    z[4,10,5]  R1662     -0.489662230014801
    z[4,10,5]  R1663     -5.2383244037628174e-01
    z[4,10,5]  R1664     -4.6987172961235046e-01
    z[4,10,5]  R1665     -8.0954384803771973e-01
    z[4,10,5]  R1666     -6.7603783681988716e-03
    z[4,10,5]  R1667     3.9236697554588318e-01
    z[4,10,5]  R1668     -4.5929306745529175e-01
    z[4,10,5]  R1669     2.7570620179176331e-01
    z[4,10,5]  R1670     1.7076404392719269e-01
    z[4,10,5]  R1671     2.8928220272064209e-02
    z[4,10,5]  R1672     2.1675245463848114e-01
    z[4,10,5]  R1673     5.6372302770614624e-01
    z[4,10,5]  R1674     4.2820256948471069e-01
    z[4,10,5]  R1675     -4.8932361602783203e-01
    z[4,10,5]  R1676     1.4396293461322784e-01
    z[4,10,5]  R1677     -1.4416243135929108e-01
    z[4,10,5]  R1678     -0.0305878184735775
    z[4,10,5]  R1679     -3.7809950113296509e-01
    z[4,10,5]  R1680     1.3094292581081390e-01
    z[4,10,5]  R1681     -1.4991295337677002e-01
    z[4,10,5]  R1682     7.3057748377323151e-02
    z[4,10,5]  R1683     2.5748360157012939e-01
    z[4,10,5]  R1684     5.9070986509323120e-01
    z[4,10,5]  R1685     4.3190208077430725e-01
    z[4,10,5]  R1686     4.8718398809432983e-01
    z[4,10,5]  R1687     0.637184202671051
    z[4,10,5]  R1688     1.9008395075798035e-01
    z[4,10,5]  R1689     4.2423000931739807e-01
    z[4,10,5]  R1690     3.0134943127632141e-01
    z[4,10,5]  R1691     4.0979641675949097e-01
    z[4,10,5]  R1692     6.4152711629867554e-01
    z[4,10,5]  R1693     7.5302320718765259e-01
    z[4,10,5]  R1694     5.5047595500946045e-01
    z[4,10,5]  R1695     5.6913548707962036e-01
    z[4,10,5]  R1696     -3.3383011817932129e-02
    z[4,10,5]  R1697     2.1554559469223022e-01
    z[4,10,5]  R1698     0.526763379573822
    z[4,10,5]  R1699     2.4247248470783234e-01
    z[4,10,5]  R1700     4.0691789984703064e-01
    z[4,10,5]  R1701     8.9430719614028931e-02
    z[4,10,5]  R1702     2.4368791282176971e-01
    z[4,10,5]  R1703     6.6027349233627319e-01
    z[4,10,5]  R1704     6.5822386741638184e-01
    z[4,10,5]  R1705     3.9039081335067749e-01
    z[4,10,5]  R1706     -5.4581277072429657e-03
    z[4,10,5]  R1707     -1.6746070981025696e-01
    z[4,10,5]  R1708     -3.0789282917976379e-01
    z[4,10,5]  R1709     6.6035546362400055e-02
    z[4,10,5]  R1710     -7.0266634225845337e-02
    z[4,10,5]  R1711     6.1950433254241943e-01
    z[4,10,5]  R1712     4.0019720792770386e-01
    z[4,10,5]  R1713     2.5226727128028870e-01
    z[4,10,5]  R1714     -2.4337185919284821e-01
    z[4,10,5]  R1715     -2.9784369468688965e-01
    z[4,10,5]  R1716     -3.6523076891899109e-01
    z[4,10,5]  R1717     -4.7111743688583374e-01
    z[4,10,5]  R1718     -2.3197950422763824e-01
    z[4,10,5]  R1719     9.6717111766338348e-02
    z[4,10,5]  R1720     -7.5587600469589233e-02
    z[4,10,5]  R1721     3.7458430975675583e-02
    z[4,10,5]  R1722     -3.5075005888938904e-01
    z[4,10,5]  R1723     -5.9254580736160278e-01
    z[4,10,5]  R1724     -1.3819037377834320e-01
    z[4,10,5]  R1725     -1.7041382193565369e-01
    z[4,10,5]  R1726     -0.178700253367424
    z[4,10,5]  R1727     -3.0035126209259033e-01
    z[4,10,5]  R1728     0.00954553671181202
    z[4,10,5]  R1729     -0.50865638256073
    z[4,10,5]  R1730     -1.3811635971069336e-01
    z[4,10,5]  R1731     -2.9512956738471985e-01
    z[4,10,5]  R1732     -5.0582069158554077e-01
    z[4,10,5]  R1733     2.9561811685562134e-01
    z[4,10,5]  R1734     -2.2971833124756813e-02
    z[4,10,5]  R1735     -2.9978886246681213e-01
    z[4,10,5]  R1736     -0.70634526014328
    z[4,10,6]  R44       -1
    z[4,10,6]  R98       1
    z[4,10,6]  R1645     -1
    z[4,10,6]  R1646     1
    z[4,10,6]  R1647     3.3664533495903015e-01
    z[4,10,6]  R1648     2.3573417961597443e-01
    z[4,10,6]  R1649     4.4084972143173218e-01
    z[4,10,6]  R1650     -9.0215429663658142e-02
    z[4,10,6]  R1651     3.9096099138259888e-01
    z[4,10,6]  R1652     3.4627810120582581e-01
    z[4,10,6]  R1653     1.8580521643161774e-01
    z[4,10,6]  R1654     4.1898670792579651e-01
    z[4,10,6]  R1655     -2.6931622624397278e-01
    z[4,10,6]  R1656     -1.6151136159896851e-01
    z[4,10,6]  R1657     -1.4734691381454468e-01
    z[4,10,6]  R1658     5.0750488042831421e-01
    z[4,10,6]  R1659     2.4365903437137604e-01
    z[4,10,6]  R1660     1.8402788043022156e-01
    z[4,10,6]  R1661     1.2230180203914642e-01
    z[4,10,6]  R1662     2.5534853339195251e-01
    z[4,10,6]  R1663     4.9820411205291748e-01
    z[4,10,6]  R1664     -5.8697527647018433e-01
    z[4,10,6]  R1665     -2.2447204589843750e-01
    z[4,10,6]  R1666     -1.5371930599212646e-01
    z[4,10,6]  R1667     2.1896651387214661e-01
    z[4,10,6]  R1668     -4.8337876796722412e-01
    z[4,10,6]  R1669     -4.9422928132116795e-03
    z[4,10,6]  R1670     -1.7492248117923737e-01
    z[4,10,6]  R1671     -0.311410129070282
    z[4,10,6]  R1672     -1.0314693674445152e-02
    z[4,10,6]  R1673     -2.7174046263098717e-02
    z[4,10,6]  R1674     7.0586074143648148e-03
    z[4,10,6]  R1675     1.6405366361141205e-01
    z[4,10,6]  R1676     -3.8203904032707214e-01
    z[4,10,6]  R1677     -5.4438419640064240e-02
    z[4,10,6]  R1678     3.2419890165328979e-01
    z[4,10,6]  R1679     -6.2903493642807007e-01
    z[4,10,6]  R1680     5.0851851701736450e-01
    z[4,10,6]  R1681     -9.3386769294738770e-02
    z[4,10,6]  R1682     -1.1720818281173706e-01
    z[4,10,6]  R1683     2.2354254126548767e-01
    z[4,10,6]  R1684     -1.8927467986941338e-02
    z[4,10,6]  R1685     -2.4369551241397858e-01
    z[4,10,6]  R1686     1.8381108343601227e-01
    z[4,10,6]  R1687     -8.8346116244792938e-02
    z[4,10,6]  R1688     -2.7376693487167358e-01
    z[4,10,6]  R1689     -2.8332561254501343e-01
    z[4,10,6]  R1690     -3.3860078454017639e-01
    z[4,10,6]  R1691     -0.162612646818161
    z[4,10,6]  R1692     -1.3697418570518494e-01
    z[4,10,6]  R1693     -2.4773661792278290e-01
    z[4,10,6]  R1694     -2.1843566000461578e-01
    z[4,10,6]  R1695     -2.4833329021930695e-01
    z[4,10,6]  R1696     -4.3179315328598022e-01
    z[4,10,6]  R1697     3.1115907430648804e-01
    z[4,10,6]  R1698     2.2180373966693878e-01
    z[4,10,6]  R1699     -2.1379025280475616e-01
    z[4,10,6]  R1700     -2.0424191653728485e-01
    z[4,10,6]  R1701     2.5111040472984314e-01
    z[4,10,6]  R1702     -2.2403696179389954e-01
    z[4,10,6]  R1703     1.4899879693984985e-01
    z[4,10,6]  R1704     2.7462151646614075e-01
    z[4,10,6]  R1705     2.3706594482064247e-02
    z[4,10,6]  R1706     4.6787819266319275e-01
    z[4,10,6]  R1707     -6.4719456434249878e-01
    z[4,10,6]  R1708     -6.5354377031326294e-01
    z[4,10,6]  R1709     -1.4812734723091125e-01
    z[4,10,6]  R1710     0.135025292634964
    z[4,10,6]  R1711     1.5096846222877502e-01
    z[4,10,6]  R1712     2.2642095386981964e-01
    z[4,10,6]  R1713     -4.4093031436204910e-02
    z[4,10,6]  R1714     -2.5611397624015808e-01
    z[4,10,6]  R1715     -3.5083033144474030e-02
    z[4,10,6]  R1716     1.0351660847663879e-01
    z[4,10,6]  R1717     0.156805619597435
    z[4,10,6]  R1718     5.0296908617019653e-01
    z[4,10,6]  R1719     -1.0307624936103821e-01
    z[4,10,6]  R1720     2.2044481709599495e-02
    z[4,10,6]  R1721     5.8471059799194336e-01
    z[4,10,6]  R1722     3.5739752650260925e-01
    z[4,10,6]  R1723     -3.0509757995605469e-01
    z[4,10,6]  R1724     -1.1545576900243759e-01
    z[4,10,6]  R1725     -0.00886712409555912
    z[4,10,6]  R1726     2.6179659366607666e-01
    z[4,10,6]  R1727     1.6377250850200653e-01
    z[4,10,6]  R1728     1.6131460666656494e-01
    z[4,10,6]  R1729     -0.0995606854557991
    z[4,10,6]  R1730     -1.2396887689828873e-01
    z[4,10,6]  R1731     -3.1050941348075867e-01
    z[4,10,6]  R1732     -2.5741836428642273e-01
    z[4,10,6]  R1733     -2.6364496350288391e-01
    z[4,10,6]  R1734     -0.352649450302124
    z[4,10,6]  R1735     -2.1015355363488197e-02
    z[4,10,6]  R1736     2.6889881491661072e-01
    z[10,4,0]  R38       1
    z[10,4,0]  R92       -1
    z[10,4,0]  R1737     -1
    z[10,4,0]  R1738     1
    z[10,4,0]  R1751     -3.9636448025703430e-01
    z[10,4,0]  R1752     -2.1843071281909943e-01
    z[10,4,0]  R1753     -5.5052655935287476e-01
    z[10,4,0]  R1754     -5.1393687725067139e-02
    z[10,4,0]  R1755     -1.1332868784666061e-01
    z[10,4,0]  R1756     -1.8592710793018341e-01
    z[10,4,0]  R1757     3.6510050296783447e-01
    z[10,4,0]  R1758     2.6070839166641235e-01
    z[10,4,0]  R1759     -1.9142383709549904e-02
    z[10,4,0]  R1760     -4.2343366146087646e-01
    z[10,4,0]  R1761     4.0896305441856384e-01
    z[10,4,0]  R1762     -9.6639342606067657e-02
    z[10,4,0]  R1763     -4.7348892688751221e-01
    z[10,4,0]  R1764     -1.7088831961154938e-01
    z[10,4,0]  R1765     -1.2774877250194550e-02
    z[10,4,0]  R1766     2.2630387544631958e-01
    z[10,4,0]  R1767     1.8719108402729034e-01
    z[10,4,0]  R1768     -3.3848896622657776e-01
    z[10,4,0]  R1769     6.2727910280227661e-01
    z[10,4,0]  R1770     -3.6651602387428284e-01
    z[10,4,0]  R1771     -9.5985263586044312e-02
    z[10,4,0]  R1772     1.1450875550508499e-01
    z[10,4,0]  R1773     1.0657140612602234e-01
    z[10,4,0]  R1774     2.9993700981140137e-01
    z[10,4,0]  R1775     -3.0955451726913452e-01
    z[10,4,0]  R1776     -5.6630626320838928e-02
    z[10,4,0]  R1777     2.1666556596755981e-02
    z[10,4,0]  R1778     4.6906974911689758e-01
    z[10,4,0]  R1779     -7.2263628244400024e-01
    z[10,4,0]  R1780     -3.6497896909713745e-01
    z[10,4,0]  R1781     -1.9985330104827881e-01
    z[10,4,0]  R1782     -3.8029614835977554e-02
    z[10,4,0]  R1783     -2.6851644739508629e-02
    z[10,4,0]  R1784     1.5648564696311951e-01
    z[10,4,0]  R1785     5.9689271450042725e-01
    z[10,4,0]  R1786     2.2789795696735382e-01
    z[10,4,0]  R1787     -2.8174072504043579e-01
    z[10,4,0]  R1788     6.2675297260284424e-01
    z[10,4,0]  R1789     -3.2631557434797287e-02
    z[10,4,0]  R1790     5.2217852324247360e-02
    z[10,4,0]  R1791     4.1285350918769836e-01
    z[10,4,0]  R1792     3.8448178768157959e-01
    z[10,4,0]  R1793     1.1995550245046616e-01
    z[10,4,0]  R1794     2.0959652960300446e-01
    z[10,4,0]  R1795     6.0748201608657837e-01
    z[10,4,0]  R1796     4.7497734427452087e-01
    z[10,4,0]  R1797     2.8818449378013611e-01
    z[10,4,0]  R1798     -6.7278486490249634e-01
    z[10,4,0]  R1799     3.0296313762664795e-01
    z[10,4,0]  R1800     2.9295399785041809e-01
    z[10,4,0]  R1801     5.3371459245681763e-01
    z[10,4,0]  R1802     -3.9458143711090088e-01
    z[10,4,0]  R1803     -2.5424867868423462e-01
    z[10,4,0]  R1804     -1.4888504147529602e-01
    z[10,4,0]  R1805     3.2396411895751953e-01
    z[10,4,0]  R1806     1.2609507143497467e-01
    z[10,4,0]  R1807     -1.9771598279476166e-01
    z[10,4,0]  R1808     -1.7129307985305786e-01
    z[10,4,0]  R1809     2.2557590901851654e-01
    z[10,4,0]  R1810     -1.8372812867164612e-01
    z[10,4,0]  R1811     -1.3125183992087841e-02
    z[10,4,0]  R1812     -2.5624418631196022e-02
    z[10,4,0]  R1813     -1.9810365140438080e-01
    z[10,4,0]  R1814     -2.2849960252642632e-02
    z[10,4,0]  R1815     -2.4032703042030334e-01
    z[10,4,0]  R1816     -1.7159251868724823e-01
    z[10,4,0]  R1817     3.7596255540847778e-01
    z[10,4,0]  R1818     -2.3235681653022766e-01
    z[10,4,0]  R1819     -6.6991263628005981e-01
    z[10,4,0]  R1820     3.5354757308959961e-01
    z[10,4,0]  R1821     1.0167054831981659e-01
    z[10,4,0]  R1822     -2.4417449533939362e-01
    z[10,4,0]  R1823     -1.4748911559581757e-01
    z[10,4,0]  R1824     3.1215512752532959e-01
    z[10,4,0]  R1825     -3.8002294301986694e-01
    z[10,4,0]  R1826     0.0915653184056282
    z[10,4,0]  R1827     0.378814697265625
    z[10,4,0]  R1828     8.8293008506298065e-02
    z[10,4,0]  R1829     2.1603241562843323e-01
    z[10,4,0]  R1830     6.5152287483215332e-02
    z[10,4,0]  R1831     9.1169491410255432e-02
    z[10,4,0]  R1832     3.4985087811946869e-02
    z[10,4,0]  R1833     1.2196503579616547e-01
    z[10,4,0]  R1834     2.8525349497795105e-01
    z[10,4,0]  R1835     5.8857542276382446e-01
    z[10,4,0]  R1836     1.6893598437309265e-01
    z[10,4,0]  R1837     0.0400143563747406
    z[10,4,0]  R1838     4.2162124067544937e-02
    z[10,4,0]  R1839     -2.4480982124805450e-01
    z[10,4,0]  R1840     2.9493844509124756e-01
    z[10,4,1]  R39       1
    z[10,4,1]  R93       -1
    z[10,4,1]  R1739     -1
    z[10,4,1]  R1740     1
    z[10,4,1]  R1751     -1.0856962949037552e-01
    z[10,4,1]  R1752     1.5542726218700409e-01
    z[10,4,1]  R1753     -1.1899171397089958e-02
    z[10,4,1]  R1754     -7.4997544288635254e-02
    z[10,4,1]  R1755     4.1021695733070374e-01
    z[10,4,1]  R1756     -3.9665222167968750e-02
    z[10,4,1]  R1757     4.5404410362243652e-01
    z[10,4,1]  R1758     4.4423744082450867e-01
    z[10,4,1]  R1759     2.4021776020526886e-01
    z[10,4,1]  R1760     4.6866810321807861e-01
    z[10,4,1]  R1761     1.7533724009990692e-01
    z[10,4,1]  R1762     1.4846704900264740e-01
    z[10,4,1]  R1763     -2.9659056663513184e-01
    z[10,4,1]  R1764     -4.6645447611808777e-01
    z[10,4,1]  R1765     -7.6093202829360962e-01
    z[10,4,1]  R1766     -7.7744621038436890e-01
    z[10,4,1]  R1767     -9.4802898168563843e-01
    z[10,4,1]  R1768     -3.0477842688560486e-01
    z[10,4,1]  R1769     -1.8231703341007233e-01
    z[10,4,1]  R1770     0.0208007600158453
    z[10,4,1]  R1771     -0.379312664270401
    z[10,4,1]  R1772     6.0360127687454224e-01
    z[10,4,1]  R1773     -1.1329365521669388e-01
    z[10,4,1]  R1774     -3.0436906218528748e-01
    z[10,4,1]  R1775     2.7989361435174942e-02
    z[10,4,1]  R1776     0.67806077003479
    z[10,4,1]  R1777     1.3304229080677032e-01
    z[10,4,1]  R1778     -5.4952919483184814e-01
    z[10,4,1]  R1779     5.9685826301574707e-01
    z[10,4,1]  R1780     7.9292759299278259e-02
    z[10,4,1]  R1781     -6.0732532292604446e-02
    z[10,4,1]  R1782     -1.7408357560634613e-01
    z[10,4,1]  R1783     2.4137814342975616e-01
    z[10,4,1]  R1784     -3.1413719058036804e-02
    z[10,4,1]  R1785     -2.7527580037713051e-02
    z[10,4,1]  R1786     8.8575951755046844e-02
    z[10,4,1]  R1787     -5.5882513523101807e-01
    z[10,4,1]  R1788     0.430237740278244
    z[10,4,1]  R1789     -6.8249548785388470e-03
    z[10,4,1]  R1790     -2.4141646921634674e-01
    z[10,4,1]  R1791     -1.3202236592769623e-01
    z[10,4,1]  R1792     -4.5940056443214417e-02
    z[10,4,1]  R1793     -2.1939606964588165e-01
    z[10,4,1]  R1794     -1.8394032120704651e-01
    z[10,4,1]  R1795     1.7205059528350830e-02
    z[10,4,1]  R1796     7.5912439823150635e-01
    z[10,4,1]  R1797     7.2721993923187256e-01
    z[10,4,1]  R1798     4.0057358145713806e-01
    z[10,4,1]  R1799     4.7810387611389160e-01
    z[10,4,1]  R1800     5.6894439458847046e-01
    z[10,4,1]  R1801     -7.0877462625503540e-01
    z[10,4,1]  R1802     -3.9808529615402222e-01
    z[10,4,1]  R1803     -3.3675214648246765e-01
    z[10,4,1]  R1804     1.7925186082720757e-02
    z[10,4,1]  R1805     3.5206070542335510e-01
    z[10,4,1]  R1806     0.50312739610672
    z[10,4,1]  R1807     -4.9591645598411560e-01
    z[10,4,1]  R1808     0.0933518260717392
    z[10,4,1]  R1809     -2.0143432915210724e-01
    z[10,4,1]  R1810     -3.7276116013526917e-01
    z[10,4,1]  R1811     2.4780307710170746e-01
    z[10,4,1]  R1812     1.5220613777637482e-01
    z[10,4,1]  R1813     9.0704351663589478e-01
    z[10,4,1]  R1814     8.8989388942718506e-01
    z[10,4,1]  R1815     9.1480612754821777e-01
    z[10,4,1]  R1816     8.9418798685073853e-01
    z[10,4,1]  R1817     6.1804932355880737e-01
    z[10,4,1]  R1818     7.0757466554641724e-01
    z[10,4,1]  R1819     1.1783520132303238e-01
    z[10,4,1]  R1820     7.5609618425369263e-01
    z[10,4,1]  R1821     -2.7142059803009033e-01
    z[10,4,1]  R1822     2.2567722201347351e-01
    z[10,4,1]  R1823     1.3701331615447998e-01
    z[10,4,1]  R1824     3.0623498558998108e-01
    z[10,4,1]  R1825     1.4621399343013763e-01
    z[10,4,1]  R1826     9.1681569814682007e-01
    z[10,4,1]  R1827     0.743359386920929
    z[10,4,1]  R1828     7.9641348123550415e-01
    z[10,4,1]  R1829     7.5286239385604858e-01
    z[10,4,1]  R1830     5.7476663589477539e-01
    z[10,4,1]  R1831     6.2243533134460449e-01
    z[10,4,1]  R1832     8.3571928739547729e-01
    z[10,4,1]  R1833     8.1072479486465454e-01
    z[10,4,1]  R1834     6.7430537939071655e-01
    z[10,4,1]  R1835     6.6398453712463379e-01
    z[10,4,1]  R1836     3.8164768368005753e-02
    z[10,4,1]  R1837     -1.4380897395312786e-02
    z[10,4,1]  R1838     -1.4331623911857605e-02
    z[10,4,1]  R1839     1.4161263406276703e-01
    z[10,4,1]  R1840     7.4459767341613770e-01
    z[10,4,2]  R40       1
    z[10,4,2]  R94       -1
    z[10,4,2]  R1741     -1
    z[10,4,2]  R1742     1
    z[10,4,2]  R1751     -2.9010385274887085e-01
    z[10,4,2]  R1752     -2.3738962411880493e-01
    z[10,4,2]  R1753     -2.5479811429977417e-01
    z[10,4,2]  R1754     -5.6889832019805908e-01
    z[10,4,2]  R1755     -2.5653791427612305e-01
    z[10,4,2]  R1756     -5.0786983966827393e-01
    z[10,4,2]  R1757     2.6203829050064087e-01
    z[10,4,2]  R1758     5.5182456970214844e-02
    z[10,4,2]  R1759     -6.7197734117507935e-01
    z[10,4,2]  R1760     6.0794495046138763e-02
    z[10,4,2]  R1761     2.9034504666924477e-02
    z[10,4,2]  R1762     1.1902976036071777e-01
    z[10,4,2]  R1763     1.1844386905431747e-01
    z[10,4,2]  R1764     -1.0425622761249542e-01
    z[10,4,2]  R1765     8.9256383478641510e-02
    z[10,4,2]  R1766     2.5807061791419983e-01
    z[10,4,2]  R1767     -0.00564618781208992
    z[10,4,2]  R1768     -7.6905570924282074e-02
    z[10,4,2]  R1769     1.9678516313433647e-02
    z[10,4,2]  R1770     1.1538688093423843e-01
    z[10,4,2]  R1771     -2.1094707772135735e-02
    z[10,4,2]  R1772     4.1736122965812683e-01
    z[10,4,2]  R1773     7.0153094828128815e-02
    z[10,4,2]  R1774     -3.8802798837423325e-02
    z[10,4,2]  R1775     1.8816716969013214e-01
    z[10,4,2]  R1776     2.3320975899696350e-01
    z[10,4,2]  R1777     -4.6710226684808731e-02
    z[10,4,2]  R1778     7.3537260293960571e-02
    z[10,4,2]  R1779     -3.7699963431805372e-03
    z[10,4,2]  R1780     -8.2393847405910492e-02
    z[10,4,2]  R1781     -7.5839266180992126e-02
    z[10,4,2]  R1782     2.0828737318515778e-01
    z[10,4,2]  R1783     1.2249260395765305e-01
    z[10,4,2]  R1784     -1.1270281672477722e-01
    z[10,4,2]  R1785     -2.6481010019779205e-02
    z[10,4,2]  R1786     -2.3649835586547852e-01
    z[10,4,2]  R1787     -4.7293606400489807e-01
    z[10,4,2]  R1788     -1.7638376355171204e-01
    z[10,4,2]  R1789     -2.5224119424819946e-01
    z[10,4,2]  R1790     2.0095808804035187e-01
    z[10,4,2]  R1791     -4.7414809465408325e-01
    z[10,4,2]  R1792     -8.2871162891387939e-01
    z[10,4,2]  R1793     1.4623082242906094e-02
    z[10,4,2]  R1794     -5.7248926162719727e-01
    z[10,4,2]  R1795     -3.7738669663667679e-02
    z[10,4,2]  R1796     -2.4280330538749695e-01
    z[10,4,2]  R1797     3.7362776696681976e-02
    z[10,4,2]  R1798     9.4783097505569458e-02
    z[10,4,2]  R1799     -1.2289097905158997e-01
    z[10,4,2]  R1800     -1.7647363245487213e-01
    z[10,4,2]  R1801     4.1203033924102783e-01
    z[10,4,2]  R1802     2.3994788527488708e-01
    z[10,4,2]  R1803     1.6720631718635559e-01
    z[10,4,2]  R1804     1.2837819755077362e-01
    z[10,4,2]  R1805     4.0040275454521179e-01
    z[10,4,2]  R1806     1.3345356285572052e-01
    z[10,4,2]  R1807     -3.3194657415151596e-02
    z[10,4,2]  R1808     2.5313520431518555e-01
    z[10,4,2]  R1809     -4.1206502914428711e-01
    z[10,4,2]  R1810     -1.8811488151550293e-01
    z[10,4,2]  R1811     7.2802215814590454e-01
    z[10,4,2]  R1812     0.571914792060852
    z[10,4,2]  R1813     1.5345154702663422e-01
    z[10,4,2]  R1814     -2.9085204005241394e-01
    z[10,4,2]  R1815     6.4979223534464836e-03
    z[10,4,2]  R1816     -3.2424005866050720e-01
    z[10,4,2]  R1817     -5.5171851068735123e-02
    z[10,4,2]  R1818     -1.0804910957813263e-01
    z[10,4,2]  R1819     -2.4583692848682404e-01
    z[10,4,2]  R1820     -1.6915802657604218e-01
    z[10,4,2]  R1821     -1.6012535989284515e-01
    z[10,4,2]  R1822     8.7762826681137085e-01
    z[10,4,2]  R1823     4.9203032255172729e-01
    z[10,4,2]  R1824     5.3925096988677979e-01
    z[10,4,2]  R1825     8.7598901987075806e-01
    z[10,4,2]  R1826     -3.3536902070045471e-01
    z[10,4,2]  R1827     -5.1727157086133957e-02
    z[10,4,2]  R1828     -9.1836132109165192e-02
    z[10,4,2]  R1829     5.6509021669626236e-02
    z[10,4,2]  R1830     1.4021563343703747e-02
    z[10,4,2]  R1831     -4.2121402919292450e-02
    z[10,4,2]  R1832     6.2648139894008636e-02
    z[10,4,2]  R1833     0.0945080816745758
    z[10,4,2]  R1834     -1.9648608565330505e-01
    z[10,4,2]  R1835     1.4892233535647392e-02
    z[10,4,2]  R1836     1.6314502060413361e-01
    z[10,4,2]  R1837     3.1280573457479477e-02
    z[10,4,2]  R1838     -7.9890981316566467e-02
    z[10,4,2]  R1839     2.4777954444289207e-02
    z[10,4,2]  R1840     -0.0759509950876236
    z[10,4,3]  R41       1
    z[10,4,3]  R95       -1
    z[10,4,3]  R1743     -1
    z[10,4,3]  R1744     1
    z[10,4,3]  R1751     0.681239128112793
    z[10,4,3]  R1752     0.60472571849823
    z[10,4,3]  R1753     6.0739618539810181e-01
    z[10,4,3]  R1754     5.0476962327957153e-01
    z[10,4,3]  R1755     7.8265631198883057e-01
    z[10,4,3]  R1756     7.2275739908218384e-01
    z[10,4,3]  R1757     2.7796402573585510e-01
    z[10,4,3]  R1758     3.9726930856704712e-01
    z[10,4,3]  R1759     1.5290898084640503e-01
    z[10,4,3]  R1760     4.6916228532791138e-01
    z[10,4,3]  R1761     -5.4265791177749634e-01
    z[10,4,3]  R1762     -2.4831391870975494e-01
    z[10,4,3]  R1763     -5.9818738698959351e-01
    z[10,4,3]  R1764     -3.9339289069175720e-01
    z[10,4,3]  R1765     -0.0786762535572052
    z[10,4,3]  R1766     3.8056049495935440e-02
    z[10,4,3]  R1767     -2.0746810361742973e-02
    z[10,4,3]  R1768     -8.0624771118164062e-01
    z[10,4,3]  R1769     0.659960150718689
    z[10,4,3]  R1770     -8.2981234788894653e-01
    z[10,4,3]  R1771     -7.2701941244304180e-03
    z[10,4,3]  R1772     -3.7577623128890991e-01
    z[10,4,3]  R1773     -4.4316515326499939e-02
    z[10,4,3]  R1774     1.3924965262413025e-01
    z[10,4,3]  R1775     -2.1064251661300659e-01
    z[10,4,3]  R1776     3.6444085836410522e-01
    z[10,4,3]  R1777     2.8647786378860474e-01
    z[10,4,3]  R1778     -6.1262732744216919e-01
    z[10,4,3]  R1779     -1.9766797125339508e-01
    z[10,4,3]  R1780     -5.6900459527969360e-01
    z[10,4,3]  R1781     2.1127900481224060e-01
    z[10,4,3]  R1782     -9.1145741939544678e-01
    z[10,4,3]  R1783     -8.0859714746475220e-01
    z[10,4,3]  R1784     -7.2537130117416382e-01
    z[10,4,3]  R1785     -5.8372038602828979e-01
    z[10,4,3]  R1786     -4.6204555034637451e-01
    z[10,4,3]  R1787     2.8942093253135681e-01
    z[10,4,3]  R1788     5.1352846622467041e-01
    z[10,4,3]  R1789     -0.468342125415802
    z[10,4,3]  R1790     -5.5705946683883667e-01
    z[10,4,3]  R1791     9.4759769737720490e-02
    z[10,4,3]  R1792     9.6813887357711792e-02
    z[10,4,3]  R1793     8.2054913043975830e-02
    z[10,4,3]  R1794     -2.0222092047333717e-02
    z[10,4,3]  R1795     -1.4055344462394714e-01
    z[10,4,3]  R1796     1.3506911695003510e-01
    z[10,4,3]  R1797     1.6846060752868652e-01
    z[10,4,3]  R1798     -2.1175147965550423e-02
    z[10,4,3]  R1799     4.6630653738975525e-01
    z[10,4,3]  R1800     0.623343288898468
    z[10,4,3]  R1801     -1.3740181922912598e-01
    z[10,4,3]  R1802     -2.2141449153423309e-01
    z[10,4,3]  R1803     1.3829699158668518e-01
    z[10,4,3]  R1804     -7.6564550399780273e-01
    z[10,4,3]  R1805     1.7201645672321320e-01
    z[10,4,3]  R1806     -6.3344007730484009e-01
    z[10,4,3]  R1807     -0.415695458650589
    z[10,4,3]  R1808     3.7936963140964508e-02
    z[10,4,3]  R1809     -5.5727396160364151e-02
    z[10,4,3]  R1810     8.7636536359786987e-01
    z[10,4,3]  R1811     -4.5097228884696960e-01
    z[10,4,3]  R1812     2.6321390271186829e-01
    z[10,4,3]  R1813     5.3094297647476196e-02
    z[10,4,3]  R1814     1.1101468652486801e-01
    z[10,4,3]  R1815     2.6173036545515060e-02
    z[10,4,3]  R1816     9.6922911703586578e-02
    z[10,4,3]  R1817     3.5951477289199829e-01
    z[10,4,3]  R1818     4.6084529161453247e-01
    z[10,4,3]  R1819     2.0157489180564880e-01
    z[10,4,3]  R1820     1.5019841492176056e-01
    z[10,4,3]  R1821     -4.6264287829399109e-01
    z[10,4,3]  R1822     -1.3778880238533020e-03
    z[10,4,3]  R1823     4.8098187893629074e-02
    z[10,4,3]  R1824     -5.7226948440074921e-02
    z[10,4,3]  R1825     -9.2000365257263184e-02
    z[10,4,3]  R1826     4.1226636618375778e-02
    z[10,4,3]  R1827     3.9620363712310791e-01
    z[10,4,3]  R1828     -4.6701491810381413e-03
    z[10,4,3]  R1829     2.9443684220314026e-01
    z[10,4,3]  R1830     6.2322062253952026e-01
    z[10,4,3]  R1831     4.3258953094482422e-01
    z[10,4,3]  R1832     4.1657385230064392e-01
    z[10,4,3]  R1833     -7.4566014111042023e-02
    z[10,4,3]  R1834     4.5363315939903259e-01
    z[10,4,3]  R1835     -1.3361506164073944e-01
    z[10,4,3]  R1836     7.1216380596160889e-01
    z[10,4,3]  R1837     0.600469172000885
    z[10,4,3]  R1838     7.9959535598754883e-01
    z[10,4,3]  R1839     7.2746020555496216e-01
    z[10,4,3]  R1840     2.0860774442553520e-02
    z[10,4,4]  R42       1
    z[10,4,4]  R96       -1
    z[10,4,4]  R1745     -1
    z[10,4,4]  R1746     1
    z[10,4,4]  R1751     -0.373605340719223
    z[10,4,4]  R1752     -4.2356446385383606e-01
    z[10,4,4]  R1753     -0.398029625415802
    z[10,4,4]  R1754     -4.5387169718742371e-01
    z[10,4,4]  R1755     -2.6355615258216858e-01
    z[10,4,4]  R1756     -2.7197670936584473e-01
    z[10,4,4]  R1757     -2.3760432004928589e-01
    z[10,4,4]  R1758     2.5522655248641968e-01
    z[10,4,4]  R1759     -5.6038123369216919e-01
    z[10,4,4]  R1760     -3.9787578582763672e-01
    z[10,4,4]  R1761     2.4450273811817169e-01
    z[10,4,4]  R1762     0.608993411064148
    z[10,4,4]  R1763     5.3822201490402222e-01
    z[10,4,4]  R1764     7.5127941370010376e-01
    z[10,4,4]  R1765     9.2514185234904289e-03
    z[10,4,4]  R1766     -2.5473731756210327e-01
    z[10,4,4]  R1767     -1.2457814998924732e-02
    z[10,4,4]  R1768     1.0844941437244415e-01
    z[10,4,4]  R1769     -2.1772688627243042e-01
    z[10,4,4]  R1770     1.3864155113697052e-01
    z[10,4,4]  R1771     -7.7451360225677490e-01
    z[10,4,4]  R1772     1.9043922424316406e-02
    z[10,4,4]  R1773     -9.7413694858551025e-01
    z[10,4,4]  R1774     -8.8898915052413940e-01
    z[10,4,4]  R1775     -6.9305545091629028e-01
    z[10,4,4]  R1776     -3.1474456191062927e-01
    z[10,4,4]  R1777     -6.7333787679672241e-01
    z[10,4,4]  R1778     2.5464621186256409e-01
    z[10,4,4]  R1779     -2.3097757995128632e-01
    z[10,4,4]  R1780     6.5534484386444092e-01
    z[10,4,4]  R1781     -8.8822716474533081e-01
    z[10,4,4]  R1782     2.6076236367225647e-01
    z[10,4,4]  R1783     5.9483081102371216e-02
    z[10,4,4]  R1784     6.3341581821441650e-01
    z[10,4,4]  R1785     3.4353023767471313e-01
    z[10,4,4]  R1786     5.9049171209335327e-01
    z[10,4,4]  R1787     3.7947988510131836e-01
    z[10,4,4]  R1788     4.8621911555528641e-02
    z[10,4,4]  R1789     7.9095101356506348e-01
    z[10,4,4]  R1790     1.3062059879302979e-01
    z[10,4,4]  R1791     -6.7960780858993530e-01
    z[10,4,4]  R1792     -1.3993211090564728e-01
    z[10,4,4]  R1793     -2.9488596320152283e-01
    z[10,4,4]  R1794     7.0823854207992554e-01
    z[10,4,4]  R1795     6.7547351121902466e-01
    z[10,4,4]  R1796     2.6978189125657082e-02
    z[10,4,4]  R1797     -1.2629888951778412e-01
    z[10,4,4]  R1798     -4.1531139612197876e-01
    z[10,4,4]  R1799     1.1978959292173386e-01
    z[10,4,4]  R1800     1.2435131520032883e-01
    z[10,4,4]  R1801     4.9273487180471420e-02
    z[10,4,4]  R1802     1.8249136209487915e-01
    z[10,4,4]  R1803     5.3202575445175171e-01
    z[10,4,4]  R1804     5.2533334493637085e-01
    z[10,4,4]  R1805     9.3137837946414948e-02
    z[10,4,4]  R1806     8.3275333046913147e-02
    z[10,4,4]  R1807     1.3587783277034760e-01
    z[10,4,4]  R1808     5.7541990280151367e-01
    z[10,4,4]  R1809     1.7288066446781158e-01
    z[10,4,4]  R1810     -1.4637543819844723e-02
    z[10,4,4]  R1811     -5.5954560637474060e-02
    z[10,4,4]  R1812     -3.6770024895668030e-01
    z[10,4,4]  R1813     -1.8873862922191620e-01
    z[10,4,4]  R1814     2.2558660805225372e-01
    z[10,4,4]  R1815     -8.2657516002655029e-02
    z[10,4,4]  R1816     -9.6800431609153748e-02
    z[10,4,4]  R1817     -1.6078034043312073e-01
    z[10,4,4]  R1818     -1.9464877247810364e-01
    z[10,4,4]  R1819     -4.1220435500144958e-01
    z[10,4,4]  R1820     2.9235166311264038e-01
    z[10,4,4]  R1821     8.0781751871109009e-01
    z[10,4,4]  R1822     1.1478152871131897e-01
    z[10,4,4]  R1823     4.2002722620964050e-01
    z[10,4,4]  R1824     4.8885148763656616e-01
    z[10,4,4]  R1825     -1.6488823294639587e-01
    z[10,4,4]  R1826     1.3348235189914703e-01
    z[10,4,4]  R1827     -1.6731470823287964e-01
    z[10,4,4]  R1828     1.3335452415049076e-02
    z[10,4,4]  R1829     2.2520011663436890e-01
    z[10,4,4]  R1830     -7.5253896415233612e-02
    z[10,4,4]  R1831     3.9314761757850647e-02
    z[10,4,4]  R1832     1.0867656767368317e-01
    z[10,4,4]  R1833     -2.3046325147151947e-01
    z[10,4,4]  R1834     -1.1870503425598145e-01
    z[10,4,4]  R1835     -1.5901979058980942e-02
    z[10,4,4]  R1836     7.6755732297897339e-02
    z[10,4,4]  R1837     9.0735845267772675e-02
    z[10,4,4]  R1838     -0.0392913781106472
    z[10,4,4]  R1839     6.7949362099170685e-02
    z[10,4,4]  R1840     -4.0598297119140625e-01
    z[10,4,5]  R43       1
    z[10,4,5]  R97       -1
    z[10,4,5]  R1747     -1
    z[10,4,5]  R1748     1
    z[10,4,5]  R1751     2.1554559469223022e-01
    z[10,4,5]  R1752     0.526763379573822
    z[10,4,5]  R1753     2.4247248470783234e-01
    z[10,4,5]  R1754     4.0691789984703064e-01
    z[10,4,5]  R1755     8.9430719614028931e-02
    z[10,4,5]  R1756     2.4368791282176971e-01
    z[10,4,5]  R1757     6.6027349233627319e-01
    z[10,4,5]  R1758     6.5822386741638184e-01
    z[10,4,5]  R1759     3.9039081335067749e-01
    z[10,4,5]  R1760     -5.4581277072429657e-03
    z[10,4,5]  R1761     -1.6746070981025696e-01
    z[10,4,5]  R1762     -3.0789282917976379e-01
    z[10,4,5]  R1763     6.6035546362400055e-02
    z[10,4,5]  R1764     -7.0266634225845337e-02
    z[10,4,5]  R1765     6.1950433254241943e-01
    z[10,4,5]  R1766     4.0019720792770386e-01
    z[10,4,5]  R1767     2.5226727128028870e-01
    z[10,4,5]  R1768     -2.4337185919284821e-01
    z[10,4,5]  R1769     -2.9784369468688965e-01
    z[10,4,5]  R1770     -3.6523076891899109e-01
    z[10,4,5]  R1771     -4.7111743688583374e-01
    z[10,4,5]  R1772     -2.3197950422763824e-01
    z[10,4,5]  R1773     9.6717111766338348e-02
    z[10,4,5]  R1774     -7.5587600469589233e-02
    z[10,4,5]  R1775     3.7458430975675583e-02
    z[10,4,5]  R1776     -3.5075005888938904e-01
    z[10,4,5]  R1777     -5.9254580736160278e-01
    z[10,4,5]  R1778     -1.3819037377834320e-01
    z[10,4,5]  R1779     -1.7041382193565369e-01
    z[10,4,5]  R1780     -0.178700253367424
    z[10,4,5]  R1781     -3.0035126209259033e-01
    z[10,4,5]  R1782     0.00954553671181202
    z[10,4,5]  R1783     -0.50865638256073
    z[10,4,5]  R1784     -1.3811635971069336e-01
    z[10,4,5]  R1785     -2.9512956738471985e-01
    z[10,4,5]  R1786     -5.0582069158554077e-01
    z[10,4,5]  R1787     2.9561811685562134e-01
    z[10,4,5]  R1788     -2.2971833124756813e-02
    z[10,4,5]  R1789     -2.9978886246681213e-01
    z[10,4,5]  R1790     -0.70634526014328
    z[10,4,5]  R1791     0.0559404082596302
    z[10,4,5]  R1792     2.8066992759704590e-01
    z[10,4,5]  R1793     8.0574375391006470e-01
    z[10,4,5]  R1794     2.9041644930839539e-01
    z[10,4,5]  R1795     -1.9368024542927742e-02
    z[10,4,5]  R1796     1.7122475430369377e-02
    z[10,4,5]  R1797     5.5484312772750854e-01
    z[10,4,5]  R1798     1.7156814038753510e-01
    z[10,4,5]  R1799     6.0017108917236328e-01
    z[10,4,5]  R1800     3.5948729515075684e-01
    z[10,4,5]  R1801     -1.2933203834109008e-04
    z[10,4,5]  R1802     -5.3700095415115356e-01
    z[10,4,5]  R1803     -6.5760958194732666e-01
    z[10,4,5]  R1804     -2.5490492582321167e-01
    z[10,4,5]  R1805     -7.4669677019119263e-01
    z[10,4,5]  R1806     -0.489662230014801
    z[10,4,5]  R1807     -5.2383244037628174e-01
    z[10,4,5]  R1808     -4.6987172961235046e-01
    z[10,4,5]  R1809     -8.0954384803771973e-01
    z[10,4,5]  R1810     -6.7603783681988716e-03
    z[10,4,5]  R1811     3.9236697554588318e-01
    z[10,4,5]  R1812     -4.5929306745529175e-01
    z[10,4,5]  R1813     2.7570620179176331e-01
    z[10,4,5]  R1814     1.7076404392719269e-01
    z[10,4,5]  R1815     2.8928220272064209e-02
    z[10,4,5]  R1816     2.1675245463848114e-01
    z[10,4,5]  R1817     5.6372302770614624e-01
    z[10,4,5]  R1818     4.2820256948471069e-01
    z[10,4,5]  R1819     -4.8932361602783203e-01
    z[10,4,5]  R1820     1.4396293461322784e-01
    z[10,4,5]  R1821     -1.4416243135929108e-01
    z[10,4,5]  R1822     -0.0305878184735775
    z[10,4,5]  R1823     -3.7809950113296509e-01
    z[10,4,5]  R1824     1.3094292581081390e-01
    z[10,4,5]  R1825     -1.4991295337677002e-01
    z[10,4,5]  R1826     7.3057748377323151e-02
    z[10,4,5]  R1827     2.5748360157012939e-01
    z[10,4,5]  R1828     5.9070986509323120e-01
    z[10,4,5]  R1829     4.3190208077430725e-01
    z[10,4,5]  R1830     4.8718398809432983e-01
    z[10,4,5]  R1831     0.637184202671051
    z[10,4,5]  R1832     1.9008395075798035e-01
    z[10,4,5]  R1833     4.2423000931739807e-01
    z[10,4,5]  R1834     3.0134943127632141e-01
    z[10,4,5]  R1835     4.0979641675949097e-01
    z[10,4,5]  R1836     6.4152711629867554e-01
    z[10,4,5]  R1837     7.5302320718765259e-01
    z[10,4,5]  R1838     5.5047595500946045e-01
    z[10,4,5]  R1839     5.6913548707962036e-01
    z[10,4,5]  R1840     -3.3383011817932129e-02
    z[10,4,6]  R44       1
    z[10,4,6]  R98       -1
    z[10,4,6]  R1749     -1
    z[10,4,6]  R1750     1
    z[10,4,6]  R1751     3.1115907430648804e-01
    z[10,4,6]  R1752     2.2180373966693878e-01
    z[10,4,6]  R1753     -2.1379025280475616e-01
    z[10,4,6]  R1754     -2.0424191653728485e-01
    z[10,4,6]  R1755     2.5111040472984314e-01
    z[10,4,6]  R1756     -2.2403696179389954e-01
    z[10,4,6]  R1757     1.4899879693984985e-01
    z[10,4,6]  R1758     2.7462151646614075e-01
    z[10,4,6]  R1759     2.3706594482064247e-02
    z[10,4,6]  R1760     4.6787819266319275e-01
    z[10,4,6]  R1761     -6.4719456434249878e-01
    z[10,4,6]  R1762     -6.5354377031326294e-01
    z[10,4,6]  R1763     -1.4812734723091125e-01
    z[10,4,6]  R1764     0.135025292634964
    z[10,4,6]  R1765     1.5096846222877502e-01
    z[10,4,6]  R1766     2.2642095386981964e-01
    z[10,4,6]  R1767     -4.4093031436204910e-02
    z[10,4,6]  R1768     -2.5611397624015808e-01
    z[10,4,6]  R1769     -3.5083033144474030e-02
    z[10,4,6]  R1770     1.0351660847663879e-01
    z[10,4,6]  R1771     0.156805619597435
    z[10,4,6]  R1772     5.0296908617019653e-01
    z[10,4,6]  R1773     -1.0307624936103821e-01
    z[10,4,6]  R1774     2.2044481709599495e-02
    z[10,4,6]  R1775     5.8471059799194336e-01
    z[10,4,6]  R1776     3.5739752650260925e-01
    z[10,4,6]  R1777     -3.0509757995605469e-01
    z[10,4,6]  R1778     -1.1545576900243759e-01
    z[10,4,6]  R1779     -0.00886712409555912
    z[10,4,6]  R1780     2.6179659366607666e-01
    z[10,4,6]  R1781     1.6377250850200653e-01
    z[10,4,6]  R1782     1.6131460666656494e-01
    z[10,4,6]  R1783     -0.0995606854557991
    z[10,4,6]  R1784     -1.2396887689828873e-01
    z[10,4,6]  R1785     -3.1050941348075867e-01
    z[10,4,6]  R1786     -2.5741836428642273e-01
    z[10,4,6]  R1787     -2.6364496350288391e-01
    z[10,4,6]  R1788     -0.352649450302124
    z[10,4,6]  R1789     -2.1015355363488197e-02
    z[10,4,6]  R1790     2.6889881491661072e-01
    z[10,4,6]  R1791     3.3664533495903015e-01
    z[10,4,6]  R1792     2.3573417961597443e-01
    z[10,4,6]  R1793     4.4084972143173218e-01
    z[10,4,6]  R1794     -9.0215429663658142e-02
    z[10,4,6]  R1795     3.9096099138259888e-01
    z[10,4,6]  R1796     3.4627810120582581e-01
    z[10,4,6]  R1797     1.8580521643161774e-01
    z[10,4,6]  R1798     4.1898670792579651e-01
    z[10,4,6]  R1799     -2.6931622624397278e-01
    z[10,4,6]  R1800     -1.6151136159896851e-01
    z[10,4,6]  R1801     -1.4734691381454468e-01
    z[10,4,6]  R1802     5.0750488042831421e-01
    z[10,4,6]  R1803     2.4365903437137604e-01
    z[10,4,6]  R1804     1.8402788043022156e-01
    z[10,4,6]  R1805     1.2230180203914642e-01
    z[10,4,6]  R1806     2.5534853339195251e-01
    z[10,4,6]  R1807     4.9820411205291748e-01
    z[10,4,6]  R1808     -5.8697527647018433e-01
    z[10,4,6]  R1809     -2.2447204589843750e-01
    z[10,4,6]  R1810     -1.5371930599212646e-01
    z[10,4,6]  R1811     2.1896651387214661e-01
    z[10,4,6]  R1812     -4.8337876796722412e-01
    z[10,4,6]  R1813     -4.9422928132116795e-03
    z[10,4,6]  R1814     -1.7492248117923737e-01
    z[10,4,6]  R1815     -0.311410129070282
    z[10,4,6]  R1816     -1.0314693674445152e-02
    z[10,4,6]  R1817     -2.7174046263098717e-02
    z[10,4,6]  R1818     7.0586074143648148e-03
    z[10,4,6]  R1819     1.6405366361141205e-01
    z[10,4,6]  R1820     -3.8203904032707214e-01
    z[10,4,6]  R1821     -5.4438419640064240e-02
    z[10,4,6]  R1822     3.2419890165328979e-01
    z[10,4,6]  R1823     -6.2903493642807007e-01
    z[10,4,6]  R1824     5.0851851701736450e-01
    z[10,4,6]  R1825     -9.3386769294738770e-02
    z[10,4,6]  R1826     -1.1720818281173706e-01
    z[10,4,6]  R1827     2.2354254126548767e-01
    z[10,4,6]  R1828     -1.8927467986941338e-02
    z[10,4,6]  R1829     -2.4369551241397858e-01
    z[10,4,6]  R1830     1.8381108343601227e-01
    z[10,4,6]  R1831     -8.8346116244792938e-02
    z[10,4,6]  R1832     -2.7376693487167358e-01
    z[10,4,6]  R1833     -2.8332561254501343e-01
    z[10,4,6]  R1834     -3.3860078454017639e-01
    z[10,4,6]  R1835     -0.162612646818161
    z[10,4,6]  R1836     -1.3697418570518494e-01
    z[10,4,6]  R1837     -2.4773661792278290e-01
    z[10,4,6]  R1838     -2.1843566000461578e-01
    z[10,4,6]  R1839     -2.4833329021930695e-01
    z[10,4,6]  R1840     -4.3179315328598022e-01
    z[6,7,0]  R56       -1
    z[6,7,0]  R65       1
    z[6,7,0]  R1925     -1
    z[6,7,0]  R1926     1
    z[6,7,0]  R1939     7.8719757497310638e-02
    z[6,7,0]  R1940     -2.2840353846549988e-01
    z[6,7,0]  R1941     1.3082465529441833e-01
    z[6,7,0]  R1942     1.0154388844966888e-01
    z[6,7,0]  R1943     1.2037665396928787e-01
    z[6,7,0]  R1944     0.0824347734451294
    z[6,7,0]  R1945     1.9508653879165649e-01
    z[6,7,0]  R1946     2.8252487536519766e-03
    z[6,7,0]  R1947     2.1544551849365234e-01
    z[6,7,0]  R1948     4.5590769499540329e-02
    z[6,7,0]  R1949     -0.0512348935008049
    z[6,7,0]  R1950     -1.2200195342302322e-01
    z[6,7,0]  R1951     -2.1726453304290771e-01
    z[6,7,0]  R1952     -3.8343787193298340e-02
    z[6,7,0]  R1953     1.0439215600490570e-01
    z[6,7,0]  R1954     -7.3072470724582672e-02
    z[6,7,0]  R1955     4.4909365475177765e-02
    z[6,7,0]  R1956     -1.7582283914089203e-01
    z[6,7,0]  R1957     -8.9845836162567139e-02
    z[6,7,0]  R1958     3.3339053392410278e-02
    z[6,7,0]  R1959     2.1200221776962280e-01
    z[6,7,0]  R1960     -4.7757747769355774e-01
    z[6,7,0]  R1961     -4.9179589748382568e-01
    z[6,7,0]  R1962     2.4503467977046967e-01
    z[6,7,0]  R1963     2.7563998103141785e-01
    z[6,7,0]  R1964     7.6668816804885864e-01
    z[6,7,0]  R1965     1.8436676263809204e-01
    z[6,7,0]  R1966     5.9189713001251221e-01
    z[6,7,0]  R1967     0.696549654006958
    z[6,7,0]  R1968     6.2079501152038574e-01
    z[6,7,0]  R1969     -1.2762364745140076e-01
    z[6,7,0]  R1970     1.1209373921155930e-01
    z[6,7,0]  R1971     3.8395129144191742e-02
    z[6,7,0]  R1972     -7.3095254600048065e-02
    z[6,7,0]  R1973     4.0898665785789490e-01
    z[6,7,0]  R1974     2.8859421610832214e-01
    z[6,7,0]  R1975     7.1428376436233521e-01
    z[6,7,0]  R1976     4.9701672792434692e-01
    z[6,7,0]  R1977     1.5107576549053192e-01
    z[6,7,0]  R1978     1.9000087678432465e-01
    z[6,7,0]  R1979     2.4899569153785706e-01
    z[6,7,0]  R1980     1.8969222903251648e-01
    z[6,7,0]  R1981     7.6405808329582214e-02
    z[6,7,0]  R1982     2.0453310012817383e-01
    z[6,7,0]  R1983     2.9127034544944763e-01
    z[6,7,0]  R1984     -5.3835548460483551e-03
    z[6,7,0]  R1985     0.0112368268892169
    z[6,7,0]  R1986     1.9862614572048187e-01
    z[6,7,0]  R1987     6.4337074756622314e-01
    z[6,7,0]  R1988     5.5937623977661133e-01
    z[6,7,0]  R1989     5.6334191560745239e-01
    z[6,7,0]  R1990     4.1311725974082947e-01
    z[6,7,0]  R1991     5.8645331859588623e-01
    z[6,7,0]  R1992     -2.0132945477962494e-01
    z[6,7,0]  R1993     -3.8083148002624512e-01
    z[6,7,0]  R1994     -5.1675987243652344e-01
    z[6,7,0]  R1995     -9.3736845254898071e-01
    z[6,7,0]  R1996     -9.4241410493850708e-01
    z[6,7,0]  R1997     6.3418996334075928e-01
    z[6,7,0]  R1998     3.3805477619171143e-01
    z[6,7,0]  R1999     7.0690816640853882e-01
    z[6,7,0]  R2000     0.77171391248703
    z[6,7,0]  R2001     0.097800612449646
    z[6,7,0]  R2002     1.4096279442310333e-01
    z[6,7,0]  R2003     2.3734317719936371e-01
    z[6,7,0]  R2004     4.0585020184516907e-01
    z[6,7,0]  R2005     3.3952784538269043e-01
    z[6,7,0]  R2006     -0.0949232280254364
    z[6,7,0]  R2007     -4.1349551081657410e-01
    z[6,7,0]  R2008     -3.4606429934501648e-01
    z[6,7,0]  R2009     -3.3707737922668457e-01
    z[6,7,0]  R2010     -1.8754664063453674e-01
    z[6,7,0]  R2011     1.0538776963949203e-01
    z[6,7,0]  R2012     -2.3383601009845734e-01
    z[6,7,0]  R2013     -5.1879596710205078e-01
    z[6,7,0]  R2014     -2.7531775832176208e-01
    z[6,7,0]  R2015     -5.7779371738433838e-01
    z[6,7,0]  R2016     -1.0655597597360611e-01
    z[6,7,0]  R2017     2.6284253597259521e-01
    z[6,7,0]  R2018     0.26040118932724
    z[6,7,0]  R2019     1.4025020599365234e-01
    z[6,7,0]  R2020     2.2039799392223358e-01
    z[6,7,0]  R2021     -1.2962000072002411e-01
    z[6,7,0]  R2022     -1.1158938705921173e-01
    z[6,7,0]  R2023     4.7225572168827057e-02
    z[6,7,0]  R2024     -1.7873022705316544e-02
    z[6,7,0]  R2025     -2.9024323821067810e-01
    z[6,7,0]  R2026     -5.0971823930740356e-01
    z[6,7,0]  R2027     2.9222929477691650e-01
    z[6,7,0]  R2028     8.4249682724475861e-02
    z[6,7,0]  R2029     1.5272390842437744e-01
    z[6,7,0]  R2030     -5.0775593519210815e-01
    z[6,7,0]  R2031     -7.0655876398086548e-01
    z[6,7,0]  R2032     -4.1153064370155334e-01
    z[6,7,1]  R57       -1
    z[6,7,1]  R66       1
    z[6,7,1]  R1927     -1
    z[6,7,1]  R1928     1
    z[6,7,1]  R1939     -0.714492917060852
    z[6,7,1]  R1940     -0.766794741153717
    z[6,7,1]  R1941     -5.3733867406845093e-01
    z[6,7,1]  R1942     -5.0333178043365479e-01
    z[6,7,1]  R1943     -5.2201277017593384e-01
    z[6,7,1]  R1944     -5.6424331665039062e-01
    z[6,7,1]  R1945     -4.1130667924880981e-01
    z[6,7,1]  R1946     -4.8473531007766724e-01
    z[6,7,1]  R1947     -3.9754891395568848e-01
    z[6,7,1]  R1948     -4.9129721522331238e-01
    z[6,7,1]  R1949     8.9774513244628906e-01
    z[6,7,1]  R1950     8.4161835908889771e-01
    z[6,7,1]  R1951     9.2137068510055542e-01
    z[6,7,1]  R1952     9.0582871437072754e-01
    z[6,7,1]  R1953     8.6860394477844238e-01
    z[6,7,1]  R1954     8.5018402338027954e-01
    z[6,7,1]  R1955     8.3546936511993408e-01
    z[6,7,1]  R1956     0.864683210849762
    z[6,7,1]  R1957     0.888593316078186
    z[6,7,1]  R1958     0.855954110622406
    z[6,7,1]  R1959     -6.3495159149169922e-01
    z[6,7,1]  R1960     -6.0940831899642944e-01
    z[6,7,1]  R1961     -6.0587811470031738e-01
    z[6,7,1]  R1962     -6.5649712085723877e-01
    z[6,7,1]  R1963     7.5388967990875244e-01
    z[6,7,1]  R1964     -5.9504695236682892e-02
    z[6,7,1]  R1965     6.7608863115310669e-01
    z[6,7,1]  R1966     4.4767209887504578e-01
    z[6,7,1]  R1967     5.8056843280792236e-01
    z[6,7,1]  R1968     4.1099786758422852e-01
    z[6,7,1]  R1969     -0.734729528427124
    z[6,7,1]  R1970     -4.5898100733757019e-01
    z[6,7,1]  R1971     9.5731109380722046e-01
    z[6,7,1]  R1972     8.5355150699615479e-01
    z[6,7,1]  R1973     7.0696151256561279e-01
    z[6,7,1]  R1974     6.4644461870193481e-01
    z[6,7,1]  R1975     5.7346242666244507e-01
    z[6,7,1]  R1976     5.3231346607208252e-01
    z[6,7,1]  R1977     -0.483767032623291
    z[6,7,1]  R1978     -0.433219313621521
    z[6,7,1]  R1979     -3.7000021338462830e-01
    z[6,7,1]  R1980     -4.3177920579910278e-01
    z[6,7,1]  R1981     -5.0468832254409790e-01
    z[6,7,1]  R1982     -3.3606818318367004e-01
    z[6,7,1]  R1983     -2.2872298955917358e-01
    z[6,7,1]  R1984     8.6079066991806030e-01
    z[6,7,1]  R1985     0.921334445476532
    z[6,7,1]  R1986     -2.2989258170127869e-01
    z[6,7,1]  R1987     -6.9852188229560852e-02
    z[6,7,1]  R1988     -8.2686953246593475e-02
    z[6,7,1]  R1989     -1.4327128231525421e-01
    z[6,7,1]  R1990     -6.7116126418113708e-02
    z[6,7,1]  R1991     -8.6113018915057182e-04
    z[6,7,1]  R1992     6.7343002557754517e-01
    z[6,7,1]  R1993     5.8207976818084717e-01
    z[6,7,1]  R1994     6.3580900430679321e-01
    z[6,7,1]  R1995     5.4047949612140656e-02
    z[6,7,1]  R1996     4.9451023340225220e-02
    z[6,7,1]  R1997     -7.0346224308013916e-01
    z[6,7,1]  R1998     -5.1667302846908569e-01
    z[6,7,1]  R1999     -2.2671933472156525e-01
    z[6,7,1]  R2000     -1.6377186775207520e-01
    z[6,7,1]  R2001     -5.9961438179016113e-01
    z[6,7,1]  R2002     -4.7854939103126526e-01
    z[6,7,1]  R2003     -3.2761031389236450e-01
    z[6,7,1]  R2004     -2.9142358899116516e-01
    z[6,7,1]  R2005     -2.5573647022247314e-01
    z[6,7,1]  R2006     5.7698541879653931e-01
    z[6,7,1]  R2007     6.5377980470657349e-01
    z[6,7,1]  R2008     6.3390594720840454e-01
    z[6,7,1]  R2009     6.7765879631042480e-01
    z[6,7,1]  R2010     7.2343409061431885e-01
    z[6,7,1]  R2011     6.4129769802093506e-01
    z[6,7,1]  R2012     8.2109671831130981e-01
    z[6,7,1]  R2013     7.9056274890899658e-01
    z[6,7,1]  R2014     4.8545023798942566e-01
    z[6,7,1]  R2015     5.5226039886474609e-01
    z[6,7,1]  R2016     7.0540577173233032e-01
    z[6,7,1]  R2017     -7.0736521482467651e-01
    z[6,7,1]  R2018     -5.4311233758926392e-01
    z[6,7,1]  R2019     -6.0203611850738525e-01
    z[6,7,1]  R2020     -5.6805652379989624e-01
    z[6,7,1]  R2021     7.8660231828689575e-01
    z[6,7,1]  R2022     6.4276885986328125e-01
    z[6,7,1]  R2023     6.0280239582061768e-01
    z[6,7,1]  R2024     8.1228846311569214e-01
    z[6,7,1]  R2025     0.805886447429657
    z[6,7,1]  R2026     6.9819837808609009e-01
    z[6,7,1]  R2027     -6.7314684391021729e-01
    z[6,7,1]  R2028     8.0872654914855957e-01
    z[6,7,1]  R2029     8.1183636188507080e-01
    z[6,7,1]  R2030     5.8985030651092529e-01
    z[6,7,1]  R2031     4.3527165055274963e-01
    z[6,7,1]  R2032     5.8477109670639038e-01
    z[6,7,2]  R58       -1
    z[6,7,2]  R67       1
    z[6,7,2]  R1929     -1
    z[6,7,2]  R1930     1
    z[6,7,2]  R1939     6.1780065298080444e-03
    z[6,7,2]  R1940     8.0064445734024048e-02
    z[6,7,2]  R1941     2.7129095792770386e-01
    z[6,7,2]  R1942     5.1973092555999756e-01
    z[6,7,2]  R1943     -3.9048162102699280e-01
    z[6,7,2]  R1944     -3.5271200537681580e-01
    z[6,7,2]  R1945     5.1109284162521362e-01
    z[6,7,2]  R1946     -6.6421443223953247e-01
    z[6,7,2]  R1947     -2.9589393734931946e-01
    z[6,7,2]  R1948     3.9483693242073059e-01
    z[6,7,2]  R1949     3.2043972611427307e-01
    z[6,7,2]  R1950     3.9753416180610657e-01
    z[6,7,2]  R1951     1.2810868024826050e-01
    z[6,7,2]  R1952     -1.6346798837184906e-01
    z[6,7,2]  R1953     5.8403205126523972e-02
    z[6,7,2]  R1954     -3.0593705177307129e-01
    z[6,7,2]  R1955     2.2055111825466156e-01
    z[6,7,2]  R1956     -1.0309773683547974e-01
    z[6,7,2]  R1957     -2.7790832519531250e-01
    z[6,7,2]  R1958     3.0476909875869751e-01
    z[6,7,2]  R1959     4.0077927405945957e-04
    z[6,7,2]  R1960     4.0916711091995239e-02
    z[6,7,2]  R1961     -2.0590171217918396e-01
    z[6,7,2]  R1962     4.6840527653694153e-01
    z[6,7,2]  R1963     -2.1393741667270660e-01
    z[6,7,2]  R1964     -1.8920238316059113e-01
    z[6,7,2]  R1965     1.3858684897422791e-01
    z[6,7,2]  R1966     8.5976555943489075e-02
    z[6,7,2]  R1967     1.5089520812034607e-01
    z[6,7,2]  R1968     1.0470622032880783e-01
    z[6,7,2]  R1969     -3.7842476367950439e-01
    z[6,7,2]  R1970     -2.8487798571586609e-01
    z[6,7,2]  R1971     -2.5255424901843071e-02
    z[6,7,2]  R1972     -2.4526433646678925e-01
    z[6,7,2]  R1973     2.4254019558429718e-01
    z[6,7,2]  R1974     -2.1440829336643219e-01
    z[6,7,2]  R1975     2.0959307253360748e-01
    z[6,7,2]  R1976     2.2036673128604889e-01
    z[6,7,2]  R1977     7.4862468242645264e-01
    z[6,7,2]  R1978     4.5391109585762024e-01
    z[6,7,2]  R1979     4.2123979330062866e-01
    z[6,7,2]  R1980     -9.6825070679187775e-02
    z[6,7,2]  R1981     1.4415211975574493e-01
    z[6,7,2]  R1982     0.199151411652565
    z[6,7,2]  R1983     1.7901813983917236e-01
    z[6,7,2]  R1984     3.8354527950286865e-01
    z[6,7,2]  R1985     1.2844632565975189e-01
    z[6,7,2]  R1986     3.9112526178359985e-01
    z[6,7,2]  R1987     -3.3422163128852844e-01
    z[6,7,2]  R1988     -1.7012690007686615e-01
    z[6,7,2]  R1989     -5.6111729145050049e-01
    z[6,7,2]  R1990     -0.808626651763916
    z[6,7,2]  R1991     -6.7720323801040649e-01
    z[6,7,2]  R1992     -1.4237721264362335e-01
    z[6,7,2]  R1993     1.2527535855770111e-01
    z[6,7,2]  R1994     1.9976699259132147e-03
    z[6,7,2]  R1995     -1.3049748539924622e-01
    z[6,7,2]  R1996     4.6185430139303207e-02
    z[6,7,2]  R1997     -3.9144292473793030e-02
    z[6,7,2]  R1998     -4.1362863779067993e-01
    z[6,7,2]  R1999     3.1486144661903381e-01
    z[6,7,2]  R2000     -2.1168076992034912e-01
    z[6,7,2]  R2001     4.6035799384117126e-01
    z[6,7,2]  R2002     4.0834966301918030e-01
    z[6,7,2]  R2003     -5.7198524475097656e-01
    z[6,7,2]  R2004     -3.8558465242385864e-01
    z[6,7,2]  R2005     -4.9281004071235657e-01
    z[6,7,2]  R2006     7.1240466833114624e-01
    z[6,7,2]  R2007     2.7471417188644409e-01
    z[6,7,2]  R2008     2.7431827783584595e-01
    z[6,7,2]  R2009     5.3992801904678345e-01
    z[6,7,2]  R2010     5.5345781147480011e-02
    z[6,7,2]  R2011     3.6369696259498596e-01
    z[6,7,2]  R2012     -1.2399200350046158e-01
    z[6,7,2]  R2013     -4.8644639551639557e-02
    z[6,7,2]  R2014     4.3958729505538940e-01
    z[6,7,2]  R2015     4.8620536923408508e-01
    z[6,7,2]  R2016     -8.3687163889408112e-02
    z[6,7,2]  R2017     5.4461705684661865e-01
    z[6,7,2]  R2018     1.1568053066730499e-01
    z[6,7,2]  R2019     -1.1416072398424149e-01
    z[6,7,2]  R2020     3.1054908037185669e-01
    z[6,7,2]  R2021     2.8160366415977478e-01
    z[6,7,2]  R2022     6.1467081308364868e-01
    z[6,7,2]  R2023     4.8983544111251831e-01
    z[6,7,2]  R2024     1.0121591389179230e-02
    z[6,7,2]  R2025     2.4785617366433144e-02
    z[6,7,2]  R2026     -1.4779375493526459e-01
    z[6,7,2]  R2027     -7.1148402988910675e-02
    z[6,7,2]  R2028     4.7006741166114807e-01
    z[6,7,2]  R2029     0.357892245054245
    z[6,7,2]  R2030     5.1053434610366821e-01
    z[6,7,2]  R2031     5.2023524045944214e-01
    z[6,7,2]  R2032     -0.0372295156121254
    z[6,7,3]  R59       -1
    z[6,7,3]  R68       1
    z[6,7,3]  R1931     -1
    z[6,7,3]  R1932     1
    z[6,7,3]  R1939     3.3091518282890320e-01
    z[6,7,3]  R1940     -2.2827278077602386e-01
    z[6,7,3]  R1941     -2.8170111775398254e-01
    z[6,7,3]  R1942     -5.0733107328414917e-01
    z[6,7,3]  R1943     6.6642665863037109e-01
    z[6,7,3]  R1944     -5.4064452648162842e-01
    z[6,7,3]  R1945     3.9117965102195740e-01
    z[6,7,3]  R1946     -0.279350608587265
    z[6,7,3]  R1947     -3.5979685187339783e-01
    z[6,7,3]  R1948     7.2067701816558838e-01
    z[6,7,3]  R1949     2.5874990224838257e-01
    z[6,7,3]  R1950     2.4203525483608246e-01
    z[6,7,3]  R1951     -1.8975268304347992e-01
    z[6,7,3]  R1952     -1.5461277961730957e-01
    z[6,7,3]  R1953     -3.5554841160774231e-02
    z[6,7,3]  R1954     -1.0980086028575897e-01
    z[6,7,3]  R1955     8.6332093924283981e-03
    z[6,7,3]  R1956     4.7490164637565613e-02
    z[6,7,3]  R1957     2.8536167740821838e-01
    z[6,7,3]  R1958     2.3685184121131897e-01
    z[6,7,3]  R1959     2.6239043474197388e-01
    z[6,7,3]  R1960     -2.1712154150009155e-01
    z[6,7,3]  R1961     1.7849530279636383e-01
    z[6,7,3]  R1962     3.1665435433387756e-01
    z[6,7,3]  R1963     -2.5579133629798889e-01
    z[6,7,3]  R1964     1.0500301420688629e-01
    z[6,7,3]  R1965     4.6437028795480728e-02
    z[6,7,3]  R1966     -4.8745346069335938e-01
    z[6,7,3]  R1967     -2.7795964479446411e-01
    z[6,7,3]  R1968     -5.9017390012741089e-01
    z[6,7,3]  R1969     -1.5690918266773224e-01
    z[6,7,3]  R1970     3.5372716188430786e-01
    z[6,7,3]  R1971     -7.4609339237213135e-02
    z[6,7,3]  R1972     -3.0010592937469482e-01
    z[6,7,3]  R1973     -1.9031988084316254e-01
    z[6,7,3]  R1974     -5.6362503767013550e-01
    z[6,7,3]  R1975     -0.260911226272583
    z[6,7,3]  R1976     -5.5483013391494751e-01
    z[6,7,3]  R1977     -3.2232973724603653e-02
    z[6,7,3]  R1978     -7.0278668403625488e-01
    z[6,7,3]  R1979     7.0133650302886963e-01
    z[6,7,3]  R1980     -4.8466470837593079e-01
    z[6,7,3]  R1981     3.5204750299453735e-01
    z[6,7,3]  R1982     -6.8171066045761108e-01
    z[6,7,3]  R1983     5.0931614637374878e-01
    z[6,7,3]  R1984     -4.4291362166404724e-02
    z[6,7,3]  R1985     -1.8455622717738152e-02
    z[6,7,3]  R1986     -1.4436677098274231e-01
    z[6,7,3]  R1987     -1.8831750378012657e-02
    z[6,7,3]  R1988     2.1138250827789307e-02
    z[6,7,3]  R1989     7.7364087104797363e-02
    z[6,7,3]  R1990     1.9364996254444122e-01
    z[6,7,3]  R1991     2.1951900422573090e-01
    z[6,7,3]  R1992     -1.9554218649864197e-01
    z[6,7,3]  R1993     8.4854386746883392e-02
    z[6,7,3]  R1994     4.9137137830257416e-02
    z[6,7,3]  R1995     -2.8785604238510132e-01
    z[6,7,3]  R1996     -2.2913314402103424e-01
    z[6,7,3]  R1997     8.4756435826420784e-03
    z[6,7,3]  R1998     7.5632624328136444e-02
    z[6,7,3]  R1999     -2.8737723827362061e-01
    z[6,7,3]  R2000     3.9898529648780823e-01
    z[6,7,3]  R2001     3.8776386529207230e-02
    z[6,7,3]  R2002     -2.2496329620480537e-02
    z[6,7,3]  R2003     1.2387485057115555e-01
    z[6,7,3]  R2004     -5.4098880290985107e-01
    z[6,7,3]  R2005     4.7856390476226807e-01
    z[6,7,3]  R2006     8.6956232786178589e-02
    z[6,7,3]  R2007     -2.1382060647010803e-01
    z[6,7,3]  R2008     4.3871462345123291e-01
    z[6,7,3]  R2009     -9.7884587943553925e-02
    z[6,7,3]  R2010     4.0203514695167542e-01
    z[6,7,3]  R2011     4.2656800150871277e-01
    z[6,7,3]  R2012     1.7222790420055389e-01
    z[6,7,3]  R2013     -2.5081360340118408e-01
    z[6,7,3]  R2014     6.9391858577728271e-01
    z[6,7,3]  R2015     -2.2699804604053497e-01
    z[6,7,3]  R2016     0.654820442199707
    z[6,7,3]  R2017     -2.8070241212844849e-01
    z[6,7,3]  R2018     0.0955732986330986
    z[6,7,3]  R2019     3.8018837571144104e-01
    z[6,7,3]  R2020     2.4246200919151306e-01
    z[6,7,3]  R2021     4.7367489337921143e-01
    z[6,7,3]  R2022     8.7103784084320068e-02
    z[6,7,3]  R2023     5.8222156763076782e-01
    z[6,7,3]  R2024     2.7179878950119019e-01
    z[6,7,3]  R2025     6.3187349587678909e-03
    z[6,7,3]  R2026     -2.4007922410964966e-01
    z[6,7,3]  R2027     1.7896729707717896e-01
    z[6,7,3]  R2028     1.1246153712272644e-01
    z[6,7,3]  R2029     0.343535453081131
    z[6,7,3]  R2030     -8.0852784216403961e-02
    z[6,7,3]  R2031     2.1543757990002632e-02
    z[6,7,3]  R2032     0.622757077217102
    z[6,7,4]  R60       -1
    z[6,7,4]  R69       1
    z[6,7,4]  R1933     -1
    z[6,7,4]  R1934     1
    z[6,7,4]  R1939     3.1219854950904846e-01
    z[6,7,4]  R1940     -5.9438440948724747e-02
    z[6,7,4]  R1941     -7.0988601446151733e-01
    z[6,7,4]  R1942     -2.6318114995956421e-01
    z[6,7,4]  R1943     -1.6919200122356415e-01
    z[6,7,4]  R1944     -3.7650740146636963e-01
    z[6,7,4]  R1945     -2.1941165626049042e-01
    z[6,7,4]  R1946     -2.4052104353904724e-01
    z[6,7,4]  R1947     4.3770986795425415e-01
    z[6,7,4]  R1948     1.5775993466377258e-01
    z[6,7,4]  R1949     -1.2614172697067261e-01
    z[6,7,4]  R1950     2.4360871315002441e-01
    z[6,7,4]  R1951     7.9051433131098747e-03
    z[6,7,4]  R1952     1.9794492423534393e-01
    z[6,7,4]  R1953     3.7752953171730042e-01
    z[6,7,4]  R1954     -3.6943656206130981e-01
    z[6,7,4]  R1955     -2.7956220507621765e-01
    z[6,7,4]  R1956     -2.5055420398712158e-01
    z[6,7,4]  R1957     -4.9570269882678986e-02
    z[6,7,4]  R1958     2.6393425464630127e-01
    z[6,7,4]  R1959     6.4228612184524536e-01
    z[6,7,4]  R1960     5.7015073299407959e-01
    z[6,7,4]  R1961     2.4942095577716827e-01
    z[6,7,4]  R1962     2.1850416064262390e-01
    z[6,7,4]  R1963     1.6406890749931335e-01
    z[6,7,4]  R1964     -4.2165097594261169e-01
    z[6,7,4]  R1965     -4.4154065847396851e-01
    z[6,7,4]  R1966     7.8501164913177490e-02
    z[6,7,4]  R1967     -1.6236285865306854e-01
    z[6,7,4]  R1968     -1.1570196598768234e-02
    z[6,7,4]  R1969     -3.2835006713867188e-01
    z[6,7,4]  R1970     5.7537955045700073e-01
    z[6,7,4]  R1971     -1.9492319226264954e-01
    z[6,7,4]  R1972     -1.7925573885440826e-01
    z[6,7,4]  R1973     -1.6380502283573151e-01
    z[6,7,4]  R1974     -0.260452002286911
    z[6,7,4]  R1975     6.8050853908061981e-02
    z[6,7,4]  R1976     -9.8680742084980011e-02
    z[6,7,4]  R1977     8.9499615132808685e-02
    z[6,7,4]  R1978     4.7331336885690689e-02
    z[6,7,4]  R1979     3.2973381876945496e-01
    z[6,7,4]  R1980     -3.3574157953262329e-01
    z[6,7,4]  R1981     -4.2432984709739685e-01
    z[6,7,4]  R1982     3.9872664213180542e-01
    z[6,7,4]  R1983     -5.3129500150680542e-01
    z[6,7,4]  R1984     -1.2451307475566864e-01
    z[6,7,4]  R1985     -2.4385261535644531e-01
    z[6,7,4]  R1986     5.1127278804779053e-01
    z[6,7,4]  R1987     -9.7215771675109863e-03
    z[6,7,4]  R1988     -3.6113986372947693e-01
    z[6,7,4]  R1989     -3.7307681050151587e-03
    z[6,7,4]  R1990     3.2739689946174622e-01
    z[6,7,4]  R1991     1.6731344163417816e-01
    z[6,7,4]  R1992     -4.4316089153289795e-01
    z[6,7,4]  R1993     -6.4428359270095825e-01
    z[6,7,4]  R1994     -4.4806912541389465e-01
    z[6,7,4]  R1995     4.5098461210727692e-02
    z[6,7,4]  R1996     -2.2722931206226349e-01
    z[6,7,4]  R1997     8.8432833552360535e-02
    z[6,7,4]  R1998     0.465313196182251
    z[6,7,4]  R1999     1.2860104441642761e-01
    z[6,7,4]  R2000     -3.3516031503677368e-01
    z[6,7,4]  R2001     -6.3609242439270020e-01
    z[6,7,4]  R2002     0.596617579460144
    z[6,7,4]  R2003     -1.7998097836971283e-01
    z[6,7,4]  R2004     -4.9788096547126770e-01
    z[6,7,4]  R2005     -5.6146466732025146e-01
    z[6,7,4]  R2006     1.4679694175720215e-01
    z[6,7,4]  R2007     -6.3950762152671814e-02
    z[6,7,4]  R2008     2.4879693984985352e-01
    z[6,7,4]  R2009     1.5833935141563416e-01
    z[6,7,4]  R2010     5.1392215490341187e-01
    z[6,7,4]  R2011     -3.7641230225563049e-01
    z[6,7,4]  R2012     0.379869282245636
    z[6,7,4]  R2013     9.6967279911041260e-02
    z[6,7,4]  R2014     1.0076423641294241e-03
    z[6,7,4]  R2015     2.0542123913764954e-01
    z[6,7,4]  R2016     -5.4098106920719147e-02
    z[6,7,4]  R2017     -2.7587391436100006e-02
    z[6,7,4]  R2018     -3.4771472215652466e-01
    z[6,7,4]  R2019     -3.8345164060592651e-01
    z[6,7,4]  R2020     3.8322802633047104e-02
    z[6,7,4]  R2021     -1.1859432607889175e-01
    z[6,7,4]  R2022     3.4360870718955994e-01
    z[6,7,4]  R2023     8.2579381763935089e-02
    z[6,7,4]  R2024     3.4066599607467651e-01
    z[6,7,4]  R2025     3.4818691015243530e-01
    z[6,7,4]  R2026     -3.2962700724601746e-01
    z[6,7,4]  R2027     -4.4653964042663574e-01
    z[6,7,4]  R2028     0.174747034907341
    z[6,7,4]  R2029     2.2072552144527435e-01
    z[6,7,4]  R2030     -6.0214113444089890e-02
    z[6,7,4]  R2031     8.6433209478855133e-02
    z[6,7,4]  R2032     -1.4656464755535126e-01
    z[6,7,5]  R61       -1
    z[6,7,5]  R70       1
    z[6,7,5]  R1935     -1
    z[6,7,5]  R1936     1
    z[6,7,5]  R1939     2.9710179567337036e-01
    z[6,7,5]  R1940     -3.4951677918434143e-01
    z[6,7,5]  R1941     1.6739878058433533e-01
    z[6,7,5]  R1942     3.6380210518836975e-01
    z[6,7,5]  R1943     2.5592729449272156e-01
    z[6,7,5]  R1944     -1.4988232869654894e-03
    z[6,7,5]  R1945     5.1170504093170166e-01
    z[6,7,5]  R1946     -3.2616552710533142e-01
    z[6,7,5]  R1947     -3.5955232381820679e-01
    z[6,7,5]  R1948     -1.5198934078216553e-01
    z[6,7,5]  R1949     4.1818149387836456e-02
    z[6,7,5]  R1950     2.6045233011245728e-02
    z[6,7,5]  R1951     -6.7827187478542328e-02
    z[6,7,5]  R1952     1.7519944906234741e-01
    z[6,7,5]  R1953     -0.0880071297287941
    z[6,7,5]  R1954     -3.4801412373781204e-02
    z[6,7,5]  R1955     -9.7975112497806549e-02
    z[6,7,5]  R1956     2.3809593915939331e-01
    z[6,7,5]  R1957     3.3612795174121857e-02
    z[6,7,5]  R1958     -5.7271972298622131e-02
    z[6,7,5]  R1959     9.1047652065753937e-02
    z[6,7,5]  R1960     -4.4316451996564865e-02
    z[6,7,5]  R1961     3.4391567111015320e-01
    z[6,7,5]  R1962     1.9005237519741058e-01
    z[6,7,5]  R1963     -4.4324430823326111e-01
    z[6,7,5]  R1964     -3.4918987751007080e-01
    z[6,7,5]  R1965     5.1142746210098267e-01
    z[6,7,5]  R1966     4.1684547066688538e-01
    z[6,7,5]  R1967     1.1127652972936630e-01
    z[6,7,5]  R1968     -5.0437271595001221e-02
    z[6,7,5]  R1969     2.2210228443145752e-01
    z[6,7,5]  R1970     -4.8537328839302063e-01
    z[6,7,5]  R1971     1.0913676023483276e-01
    z[6,7,5]  R1972     -4.3426580727100372e-02
    z[6,7,5]  R1973     3.6192888021469116e-01
    z[6,7,5]  R1974     -2.4011881649494171e-01
    z[6,7,5]  R1975     -2.0933395624160767e-01
    z[6,7,5]  R1976     2.4340030550956726e-01
    z[6,7,5]  R1977     2.5110411643981934e-01
    z[6,7,5]  R1978     -1.0927030444145203e-01
    z[6,7,5]  R1979     0.0615973100066185
    z[6,7,5]  R1980     6.1962729692459106e-01
    z[6,7,5]  R1981     4.3426585197448730e-01
    z[6,7,5]  R1982     3.0216521024703979e-01
    z[6,7,5]  R1983     3.0502077937126160e-01
    z[6,7,5]  R1984     -9.4746068120002747e-02
    z[6,7,5]  R1985     9.1737724840641022e-02
    z[6,7,5]  R1986     2.5821238756179810e-01
    z[6,7,5]  R1987     -4.9469181895256042e-01
    z[6,7,5]  R1988     -7.1768736839294434e-01
    z[6,7,5]  R1989     -4.4325152039527893e-01
    z[6,7,5]  R1990     1.5520103275775909e-01
    z[6,7,5]  R1991     -3.0298948287963867e-01
    z[6,7,5]  R1992     -4.3303561210632324e-01
    z[6,7,5]  R1993     -6.8086847662925720e-02
    z[6,7,5]  R1994     -4.3712366372346878e-02
    z[6,7,5]  R1995     -8.8271975517272949e-02
    z[6,7,5]  R1996     2.4261020123958588e-02
    z[6,7,5]  R1997     -8.1317991018295288e-02
    z[6,7,5]  R1998     3.1873297691345215e-01
    z[6,7,5]  R1999     0.493461012840271
    z[6,7,5]  R2000     0.0917491689324379
    z[6,7,5]  R2001     0.0384628064930439
    z[6,7,5]  R2002     -2.5385764241218567e-01
    z[6,7,5]  R2003     6.6737681627273560e-01
    z[6,7,5]  R2004     3.6219995468854904e-02
    z[6,7,5]  R2005     1.7828892171382904e-01
    z[6,7,5]  R2006     1.6482140123844147e-01
    z[6,7,5]  R2007     -4.6848282217979431e-01
    z[6,7,5]  R2008     2.8239700198173523e-01
    z[6,7,5]  R2009     2.3493885993957520e-01
    z[6,7,5]  R2010     -5.5758815258741379e-02
    z[6,7,5]  R2011     2.7847331762313843e-01
    z[6,7,5]  R2012     -0.278018981218338
    z[6,7,5]  R2013     1.0319099575281143e-01
    z[6,7,5]  R2014     1.1388929933309555e-01
    z[6,7,5]  R2015     -6.6204950213432312e-02
    z[6,7,5]  R2016     2.0312872529029846e-01
    z[6,7,5]  R2017     -1.8792280554771423e-01
    z[6,7,5]  R2018     -5.0165127962827682e-02
    z[6,7,5]  R2019     4.0426683425903320e-01
    z[6,7,5]  R2020     -3.4717744588851929e-01
    z[6,7,5]  R2021     -2.1615166962146759e-01
    z[6,7,5]  R2022     -2.1370968222618103e-01
    z[6,7,5]  R2023     9.8391756415367126e-02
    z[6,7,5]  R2024     3.8102051615715027e-01
    z[6,7,5]  R2025     8.0623924732208252e-02
    z[6,7,5]  R2026     1.5236005187034607e-01
    z[6,7,5]  R2027     1.7441053688526154e-01
    z[6,7,5]  R2028     -4.6163287013769150e-02
    z[6,7,5]  R2029     9.7324825823307037e-02
    z[6,7,5]  R2030     -2.6789653301239014e-01
    z[6,7,5]  R2031     1.7962953448295593e-01
    z[6,7,5]  R2032     -1.7342975735664368e-01
    z[6,7,6]  R62       -1
    z[6,7,6]  R71       1
    z[6,7,6]  R1937     -1
    z[6,7,6]  R1938     1
    z[6,7,6]  R1939     4.3361580371856689e-01
    z[6,7,6]  R1940     -4.1909894347190857e-01
    z[6,7,6]  R1941     -9.6110187470912933e-02
    z[6,7,6]  R1942     -8.4997788071632385e-02
    z[6,7,6]  R1943     1.4928846061229706e-01
    z[6,7,6]  R1944     3.4113296866416931e-01
    z[6,7,6]  R1945     2.6181507110595703e-01
    z[6,7,6]  R1946     2.8560775518417358e-01
    z[6,7,6]  R1947     5.0760549306869507e-01
    z[6,7,6]  R1948     -1.8244978785514832e-01
    z[6,7,6]  R1949     -0.064302958548069
    z[6,7,6]  R1950     1.2488375417888165e-02
    z[6,7,6]  R1951     2.1631282567977905e-01
    z[6,7,6]  R1952     2.3979188501834869e-01
    z[6,7,6]  R1953     -2.8227767348289490e-01
    z[6,7,6]  R1954     1.6881720721721649e-01
    z[6,7,6]  R1955     -4.0435448288917542e-01
    z[6,7,6]  R1956     -2.9842558503150940e-01
    z[6,7,6]  R1957     2.0019564032554626e-01
    z[6,7,6]  R1958     -2.1049199998378754e-01
    z[6,7,6]  R1959     2.4944262206554413e-01
    z[6,7,6]  R1960     1.5712873637676239e-01
    z[6,7,6]  R1961     3.6919301748275757e-01
    z[6,7,6]  R1962     -3.2470297813415527e-01
    z[6,7,6]  R1963     1.4522561430931091e-01
    z[6,7,6]  R1964     -2.4920284748077393e-01
    z[6,7,6]  R1965     1.7616525292396545e-01
    z[6,7,6]  R1966     -1.5595553815364838e-01
    z[6,7,6]  R1967     1.9744274020195007e-01
    z[6,7,6]  R1968     2.8939232230186462e-01
    z[6,7,6]  R1969     3.4484165906906128e-01
    z[6,7,6]  R1970     -6.2001351267099380e-02
    z[6,7,6]  R1971     1.6115553677082062e-01
    z[6,7,6]  R1972     -2.8612977266311646e-01
    z[6,7,6]  R1973     -2.8295481204986572e-01
    z[6,7,6]  R1974     -9.8420321941375732e-02
    z[6,7,6]  R1975     -2.1999720484018326e-02
    z[6,7,6]  R1976     2.1032616496086121e-01
    z[6,7,6]  R1977     -3.3257222175598145e-01
    z[6,7,6]  R1978     2.4919089674949646e-01
    z[6,7,6]  R1979     1.3880443572998047e-01
    z[6,7,6]  R1980     -1.9143719971179962e-01
    z[6,7,6]  R1981     4.7549134492874146e-01
    z[6,7,6]  R1982     -0.300910085439682
    z[6,7,6]  R1983     -4.4281458854675293e-01
    z[6,7,6]  R1984     2.9233753681182861e-01
    z[6,7,6]  R1985     -2.5748351216316223e-01
    z[6,7,6]  R1986     6.3702660799026489e-01
    z[6,7,6]  R1987     4.7362601757049561e-01
    z[6,7,6]  R1988     -0.0733075812458992
    z[6,7,6]  R1989     3.8052010536193848e-01
    z[6,7,6]  R1990     4.6648353338241577e-02
    z[6,7,6]  R1991     -1.7170476913452148e-01
    z[6,7,6]  R1992     2.5206971168518066e-01
    z[6,7,6]  R1993     -2.7114412188529968e-01
    z[6,7,6]  R1994     3.5158342123031616e-01
    z[6,7,6]  R1995     -9.3288779258728027e-02
    z[6,7,6]  R1996     5.0532564520835876e-02
    z[6,7,6]  R1997     -2.9479971528053284e-01
    z[6,7,6]  R1998     3.5192602872848511e-01
    z[6,7,6]  R1999     8.4343627095222473e-02
    z[6,7,6]  R2000     2.2997410595417023e-01
    z[6,7,6]  R2001     1.0663776844739914e-01
    z[6,7,6]  R2002     4.0431201457977295e-01
    z[6,7,6]  R2003     -1.2665948271751404e-01
    z[6,7,6]  R2004     2.4457333981990814e-01
    z[6,7,6]  R2005     -2.0126027986407280e-02
    z[6,7,6]  R2006     3.0705055594444275e-01
    z[6,7,6]  R2007     2.3841249942779541e-01
    z[6,7,6]  R2008     -2.6274269819259644e-01
    z[6,7,6]  R2009     -2.1397694945335388e-01
    z[6,7,6]  R2010     -9.7718074917793274e-02
    z[6,7,6]  R2011     2.1014584600925446e-01
    z[6,7,6]  R2012     -6.7001514136791229e-02
    z[6,7,6]  R2013     -1.4330537617206573e-01
    z[6,7,6]  R2014     -2.8399093076586723e-02
    z[6,7,6]  R2015     -1.6327325999736786e-01
    z[6,7,6]  R2016     1.0520142316818237e-01
    z[6,7,6]  R2017     1.3809648156166077e-01
    z[6,7,6]  R2018     7.0091497898101807e-01
    z[6,7,6]  R2019     3.8709127902984619e-01
    z[6,7,6]  R2020     5.9288042783737183e-01
    z[6,7,6]  R2021     -7.7191629679873586e-04
    z[6,7,6]  R2022     1.5890252590179443e-01
    z[6,7,6]  R2023     1.9742861390113831e-01
    z[6,7,6]  R2024     6.8271338939666748e-02
    z[6,7,6]  R2025     -3.7137228250503540e-01
    z[6,7,6]  R2026     2.0336598157882690e-01
    z[6,7,6]  R2027     4.4109782576560974e-01
    z[6,7,6]  R2028     -2.6941576600074768e-01
    z[6,7,6]  R2029     1.1533229053020477e-01
    z[6,7,6]  R2030     -2.2734068334102631e-01
    z[6,7,6]  R2031     -2.1608080714941025e-02
    z[6,7,6]  R2032     2.1889238059520721e-01
    z[7,6,0]  R56       1
    z[7,6,0]  R65       -1
    z[7,6,0]  R2033     -1
    z[7,6,0]  R2034     1
    z[7,6,0]  R2047     1.5107576549053192e-01
    z[7,6,0]  R2048     1.9000087678432465e-01
    z[7,6,0]  R2049     2.4899569153785706e-01
    z[7,6,0]  R2050     1.8969222903251648e-01
    z[7,6,0]  R2051     7.6405808329582214e-02
    z[7,6,0]  R2052     2.0453310012817383e-01
    z[7,6,0]  R2053     2.9127034544944763e-01
    z[7,6,0]  R2054     -5.3835548460483551e-03
    z[7,6,0]  R2055     0.0112368268892169
    z[7,6,0]  R2056     1.9862614572048187e-01
    z[7,6,0]  R2057     6.4337074756622314e-01
    z[7,6,0]  R2058     5.5937623977661133e-01
    z[7,6,0]  R2059     5.6334191560745239e-01
    z[7,6,0]  R2060     4.1311725974082947e-01
    z[7,6,0]  R2061     5.8645331859588623e-01
    z[7,6,0]  R2062     -2.0132945477962494e-01
    z[7,6,0]  R2063     -3.8083148002624512e-01
    z[7,6,0]  R2064     -5.1675987243652344e-01
    z[7,6,0]  R2065     -9.3736845254898071e-01
    z[7,6,0]  R2066     -9.4241410493850708e-01
    z[7,6,0]  R2067     6.3418996334075928e-01
    z[7,6,0]  R2068     3.3805477619171143e-01
    z[7,6,0]  R2069     7.0690816640853882e-01
    z[7,6,0]  R2070     0.77171391248703
    z[7,6,0]  R2071     0.097800612449646
    z[7,6,0]  R2072     1.4096279442310333e-01
    z[7,6,0]  R2073     2.3734317719936371e-01
    z[7,6,0]  R2074     4.0585020184516907e-01
    z[7,6,0]  R2075     3.3952784538269043e-01
    z[7,6,0]  R2076     -0.0949232280254364
    z[7,6,0]  R2077     -4.1349551081657410e-01
    z[7,6,0]  R2078     -3.4606429934501648e-01
    z[7,6,0]  R2079     -3.3707737922668457e-01
    z[7,6,0]  R2080     -1.8754664063453674e-01
    z[7,6,0]  R2081     1.0538776963949203e-01
    z[7,6,0]  R2082     -2.3383601009845734e-01
    z[7,6,0]  R2083     -5.1879596710205078e-01
    z[7,6,0]  R2084     -2.7531775832176208e-01
    z[7,6,0]  R2085     -5.7779371738433838e-01
    z[7,6,0]  R2086     -1.0655597597360611e-01
    z[7,6,0]  R2087     2.6284253597259521e-01
    z[7,6,0]  R2088     0.26040118932724
    z[7,6,0]  R2089     1.4025020599365234e-01
    z[7,6,0]  R2090     2.2039799392223358e-01
    z[7,6,0]  R2091     -1.2962000072002411e-01
    z[7,6,0]  R2092     -1.1158938705921173e-01
    z[7,6,0]  R2093     4.7225572168827057e-02
    z[7,6,0]  R2094     -1.7873022705316544e-02
    z[7,6,0]  R2095     -2.9024323821067810e-01
    z[7,6,0]  R2096     -5.0971823930740356e-01
    z[7,6,0]  R2097     2.9222929477691650e-01
    z[7,6,0]  R2098     8.4249682724475861e-02
    z[7,6,0]  R2099     1.5272390842437744e-01
    z[7,6,0]  R2100     -5.0775593519210815e-01
    z[7,6,0]  R2101     -7.0655876398086548e-01
    z[7,6,0]  R2102     -4.1153064370155334e-01
    z[7,6,0]  R2103     7.8719757497310638e-02
    z[7,6,0]  R2104     -2.2840353846549988e-01
    z[7,6,0]  R2105     1.3082465529441833e-01
    z[7,6,0]  R2106     1.0154388844966888e-01
    z[7,6,0]  R2107     1.2037665396928787e-01
    z[7,6,0]  R2108     0.0824347734451294
    z[7,6,0]  R2109     1.9508653879165649e-01
    z[7,6,0]  R2110     2.8252487536519766e-03
    z[7,6,0]  R2111     2.1544551849365234e-01
    z[7,6,0]  R2112     4.5590769499540329e-02
    z[7,6,0]  R2113     -0.0512348935008049
    z[7,6,0]  R2114     -1.2200195342302322e-01
    z[7,6,0]  R2115     -2.1726453304290771e-01
    z[7,6,0]  R2116     -3.8343787193298340e-02
    z[7,6,0]  R2117     1.0439215600490570e-01
    z[7,6,0]  R2118     -7.3072470724582672e-02
    z[7,6,0]  R2119     4.4909365475177765e-02
    z[7,6,0]  R2120     -1.7582283914089203e-01
    z[7,6,0]  R2121     -8.9845836162567139e-02
    z[7,6,0]  R2122     3.3339053392410278e-02
    z[7,6,0]  R2123     2.1200221776962280e-01
    z[7,6,0]  R2124     -4.7757747769355774e-01
    z[7,6,0]  R2125     -4.9179589748382568e-01
    z[7,6,0]  R2126     2.4503467977046967e-01
    z[7,6,0]  R2127     2.7563998103141785e-01
    z[7,6,0]  R2128     7.6668816804885864e-01
    z[7,6,0]  R2129     1.8436676263809204e-01
    z[7,6,0]  R2130     5.9189713001251221e-01
    z[7,6,0]  R2131     0.696549654006958
    z[7,6,0]  R2132     6.2079501152038574e-01
    z[7,6,0]  R2133     -1.2762364745140076e-01
    z[7,6,0]  R2134     1.1209373921155930e-01
    z[7,6,0]  R2135     3.8395129144191742e-02
    z[7,6,0]  R2136     -7.3095254600048065e-02
    z[7,6,0]  R2137     4.0898665785789490e-01
    z[7,6,0]  R2138     2.8859421610832214e-01
    z[7,6,0]  R2139     7.1428376436233521e-01
    z[7,6,0]  R2140     4.9701672792434692e-01
    z[7,6,1]  R57       1
    z[7,6,1]  R66       -1
    z[7,6,1]  R2035     -1
    z[7,6,1]  R2036     1
    z[7,6,1]  R2047     -0.483767032623291
    z[7,6,1]  R2048     -0.433219313621521
    z[7,6,1]  R2049     -3.7000021338462830e-01
    z[7,6,1]  R2050     -4.3177920579910278e-01
    z[7,6,1]  R2051     -5.0468832254409790e-01
    z[7,6,1]  R2052     -3.3606818318367004e-01
    z[7,6,1]  R2053     -2.2872298955917358e-01
    z[7,6,1]  R2054     8.6079066991806030e-01
    z[7,6,1]  R2055     0.921334445476532
    z[7,6,1]  R2056     -2.2989258170127869e-01
    z[7,6,1]  R2057     -6.9852188229560852e-02
    z[7,6,1]  R2058     -8.2686953246593475e-02
    z[7,6,1]  R2059     -1.4327128231525421e-01
    z[7,6,1]  R2060     -6.7116126418113708e-02
    z[7,6,1]  R2061     -8.6113018915057182e-04
    z[7,6,1]  R2062     6.7343002557754517e-01
    z[7,6,1]  R2063     5.8207976818084717e-01
    z[7,6,1]  R2064     6.3580900430679321e-01
    z[7,6,1]  R2065     5.4047949612140656e-02
    z[7,6,1]  R2066     4.9451023340225220e-02
    z[7,6,1]  R2067     -7.0346224308013916e-01
    z[7,6,1]  R2068     -5.1667302846908569e-01
    z[7,6,1]  R2069     -2.2671933472156525e-01
    z[7,6,1]  R2070     -1.6377186775207520e-01
    z[7,6,1]  R2071     -5.9961438179016113e-01
    z[7,6,1]  R2072     -4.7854939103126526e-01
    z[7,6,1]  R2073     -3.2761031389236450e-01
    z[7,6,1]  R2074     -2.9142358899116516e-01
    z[7,6,1]  R2075     -2.5573647022247314e-01
    z[7,6,1]  R2076     5.7698541879653931e-01
    z[7,6,1]  R2077     6.5377980470657349e-01
    z[7,6,1]  R2078     6.3390594720840454e-01
    z[7,6,1]  R2079     6.7765879631042480e-01
    z[7,6,1]  R2080     7.2343409061431885e-01
    z[7,6,1]  R2081     6.4129769802093506e-01
    z[7,6,1]  R2082     8.2109671831130981e-01
    z[7,6,1]  R2083     7.9056274890899658e-01
    z[7,6,1]  R2084     4.8545023798942566e-01
    z[7,6,1]  R2085     5.5226039886474609e-01
    z[7,6,1]  R2086     7.0540577173233032e-01
    z[7,6,1]  R2087     -7.0736521482467651e-01
    z[7,6,1]  R2088     -5.4311233758926392e-01
    z[7,6,1]  R2089     -6.0203611850738525e-01
    z[7,6,1]  R2090     -5.6805652379989624e-01
    z[7,6,1]  R2091     7.8660231828689575e-01
    z[7,6,1]  R2092     6.4276885986328125e-01
    z[7,6,1]  R2093     6.0280239582061768e-01
    z[7,6,1]  R2094     8.1228846311569214e-01
    z[7,6,1]  R2095     0.805886447429657
    z[7,6,1]  R2096     6.9819837808609009e-01
    z[7,6,1]  R2097     -6.7314684391021729e-01
    z[7,6,1]  R2098     8.0872654914855957e-01
    z[7,6,1]  R2099     8.1183636188507080e-01
    z[7,6,1]  R2100     5.8985030651092529e-01
    z[7,6,1]  R2101     4.3527165055274963e-01
    z[7,6,1]  R2102     5.8477109670639038e-01
    z[7,6,1]  R2103     -0.714492917060852
    z[7,6,1]  R2104     -0.766794741153717
    z[7,6,1]  R2105     -5.3733867406845093e-01
    z[7,6,1]  R2106     -5.0333178043365479e-01
    z[7,6,1]  R2107     -5.2201277017593384e-01
    z[7,6,1]  R2108     -5.6424331665039062e-01
    z[7,6,1]  R2109     -4.1130667924880981e-01
    z[7,6,1]  R2110     -4.8473531007766724e-01
    z[7,6,1]  R2111     -3.9754891395568848e-01
    z[7,6,1]  R2112     -4.9129721522331238e-01
    z[7,6,1]  R2113     8.9774513244628906e-01
    z[7,6,1]  R2114     8.4161835908889771e-01
    z[7,6,1]  R2115     9.2137068510055542e-01
    z[7,6,1]  R2116     9.0582871437072754e-01
    z[7,6,1]  R2117     8.6860394477844238e-01
    z[7,6,1]  R2118     8.5018402338027954e-01
    z[7,6,1]  R2119     8.3546936511993408e-01
    z[7,6,1]  R2120     0.864683210849762
    z[7,6,1]  R2121     0.888593316078186
    z[7,6,1]  R2122     0.855954110622406
    z[7,6,1]  R2123     -6.3495159149169922e-01
    z[7,6,1]  R2124     -6.0940831899642944e-01
    z[7,6,1]  R2125     -6.0587811470031738e-01
    z[7,6,1]  R2126     -6.5649712085723877e-01
    z[7,6,1]  R2127     7.5388967990875244e-01
    z[7,6,1]  R2128     -5.9504695236682892e-02
    z[7,6,1]  R2129     6.7608863115310669e-01
    z[7,6,1]  R2130     4.4767209887504578e-01
    z[7,6,1]  R2131     5.8056843280792236e-01
    z[7,6,1]  R2132     4.1099786758422852e-01
    z[7,6,1]  R2133     -0.734729528427124
    z[7,6,1]  R2134     -4.5898100733757019e-01
    z[7,6,1]  R2135     9.5731109380722046e-01
    z[7,6,1]  R2136     8.5355150699615479e-01
    z[7,6,1]  R2137     7.0696151256561279e-01
    z[7,6,1]  R2138     6.4644461870193481e-01
    z[7,6,1]  R2139     5.7346242666244507e-01
    z[7,6,1]  R2140     5.3231346607208252e-01
    z[7,6,2]  R58       1
    z[7,6,2]  R67       -1
    z[7,6,2]  R2037     -1
    z[7,6,2]  R2038     1
    z[7,6,2]  R2047     7.4862468242645264e-01
    z[7,6,2]  R2048     4.5391109585762024e-01
    z[7,6,2]  R2049     4.2123979330062866e-01
    z[7,6,2]  R2050     -9.6825070679187775e-02
    z[7,6,2]  R2051     1.4415211975574493e-01
    z[7,6,2]  R2052     0.199151411652565
    z[7,6,2]  R2053     1.7901813983917236e-01
    z[7,6,2]  R2054     3.8354527950286865e-01
    z[7,6,2]  R2055     1.2844632565975189e-01
    z[7,6,2]  R2056     3.9112526178359985e-01
    z[7,6,2]  R2057     -3.3422163128852844e-01
    z[7,6,2]  R2058     -1.7012690007686615e-01
    z[7,6,2]  R2059     -5.6111729145050049e-01
    z[7,6,2]  R2060     -0.808626651763916
    z[7,6,2]  R2061     -6.7720323801040649e-01
    z[7,6,2]  R2062     -1.4237721264362335e-01
    z[7,6,2]  R2063     1.2527535855770111e-01
    z[7,6,2]  R2064     1.9976699259132147e-03
    z[7,6,2]  R2065     -1.3049748539924622e-01
    z[7,6,2]  R2066     4.6185430139303207e-02
    z[7,6,2]  R2067     -3.9144292473793030e-02
    z[7,6,2]  R2068     -4.1362863779067993e-01
    z[7,6,2]  R2069     3.1486144661903381e-01
    z[7,6,2]  R2070     -2.1168076992034912e-01
    z[7,6,2]  R2071     4.6035799384117126e-01
    z[7,6,2]  R2072     4.0834966301918030e-01
    z[7,6,2]  R2073     -5.7198524475097656e-01
    z[7,6,2]  R2074     -3.8558465242385864e-01
    z[7,6,2]  R2075     -4.9281004071235657e-01
    z[7,6,2]  R2076     7.1240466833114624e-01
    z[7,6,2]  R2077     2.7471417188644409e-01
    z[7,6,2]  R2078     2.7431827783584595e-01
    z[7,6,2]  R2079     5.3992801904678345e-01
    z[7,6,2]  R2080     5.5345781147480011e-02
    z[7,6,2]  R2081     3.6369696259498596e-01
    z[7,6,2]  R2082     -1.2399200350046158e-01
    z[7,6,2]  R2083     -4.8644639551639557e-02
    z[7,6,2]  R2084     4.3958729505538940e-01
    z[7,6,2]  R2085     4.8620536923408508e-01
    z[7,6,2]  R2086     -8.3687163889408112e-02
    z[7,6,2]  R2087     5.4461705684661865e-01
    z[7,6,2]  R2088     1.1568053066730499e-01
    z[7,6,2]  R2089     -1.1416072398424149e-01
    z[7,6,2]  R2090     3.1054908037185669e-01
    z[7,6,2]  R2091     2.8160366415977478e-01
    z[7,6,2]  R2092     6.1467081308364868e-01
    z[7,6,2]  R2093     4.8983544111251831e-01
    z[7,6,2]  R2094     1.0121591389179230e-02
    z[7,6,2]  R2095     2.4785617366433144e-02
    z[7,6,2]  R2096     -1.4779375493526459e-01
    z[7,6,2]  R2097     -7.1148402988910675e-02
    z[7,6,2]  R2098     4.7006741166114807e-01
    z[7,6,2]  R2099     0.357892245054245
    z[7,6,2]  R2100     5.1053434610366821e-01
    z[7,6,2]  R2101     5.2023524045944214e-01
    z[7,6,2]  R2102     -0.0372295156121254
    z[7,6,2]  R2103     6.1780065298080444e-03
    z[7,6,2]  R2104     8.0064445734024048e-02
    z[7,6,2]  R2105     2.7129095792770386e-01
    z[7,6,2]  R2106     5.1973092555999756e-01
    z[7,6,2]  R2107     -3.9048162102699280e-01
    z[7,6,2]  R2108     -3.5271200537681580e-01
    z[7,6,2]  R2109     5.1109284162521362e-01
    z[7,6,2]  R2110     -6.6421443223953247e-01
    z[7,6,2]  R2111     -2.9589393734931946e-01
    z[7,6,2]  R2112     3.9483693242073059e-01
    z[7,6,2]  R2113     3.2043972611427307e-01
    z[7,6,2]  R2114     3.9753416180610657e-01
    z[7,6,2]  R2115     1.2810868024826050e-01
    z[7,6,2]  R2116     -1.6346798837184906e-01
    z[7,6,2]  R2117     5.8403205126523972e-02
    z[7,6,2]  R2118     -3.0593705177307129e-01
    z[7,6,2]  R2119     2.2055111825466156e-01
    z[7,6,2]  R2120     -1.0309773683547974e-01
    z[7,6,2]  R2121     -2.7790832519531250e-01
    z[7,6,2]  R2122     3.0476909875869751e-01
    z[7,6,2]  R2123     4.0077927405945957e-04
    z[7,6,2]  R2124     4.0916711091995239e-02
    z[7,6,2]  R2125     -2.0590171217918396e-01
    z[7,6,2]  R2126     4.6840527653694153e-01
    z[7,6,2]  R2127     -2.1393741667270660e-01
    z[7,6,2]  R2128     -1.8920238316059113e-01
    z[7,6,2]  R2129     1.3858684897422791e-01
    z[7,6,2]  R2130     8.5976555943489075e-02
    z[7,6,2]  R2131     1.5089520812034607e-01
    z[7,6,2]  R2132     1.0470622032880783e-01
    z[7,6,2]  R2133     -3.7842476367950439e-01
    z[7,6,2]  R2134     -2.8487798571586609e-01
    z[7,6,2]  R2135     -2.5255424901843071e-02
    z[7,6,2]  R2136     -2.4526433646678925e-01
    z[7,6,2]  R2137     2.4254019558429718e-01
    z[7,6,2]  R2138     -2.1440829336643219e-01
    z[7,6,2]  R2139     2.0959307253360748e-01
    z[7,6,2]  R2140     2.2036673128604889e-01
    z[7,6,3]  R59       1
    z[7,6,3]  R68       -1
    z[7,6,3]  R2039     -1
    z[7,6,3]  R2040     1
    z[7,6,3]  R2047     -3.2232973724603653e-02
    z[7,6,3]  R2048     -7.0278668403625488e-01
    z[7,6,3]  R2049     7.0133650302886963e-01
    z[7,6,3]  R2050     -4.8466470837593079e-01
    z[7,6,3]  R2051     3.5204750299453735e-01
    z[7,6,3]  R2052     -6.8171066045761108e-01
    z[7,6,3]  R2053     5.0931614637374878e-01
    z[7,6,3]  R2054     -4.4291362166404724e-02
    z[7,6,3]  R2055     -1.8455622717738152e-02
    z[7,6,3]  R2056     -1.4436677098274231e-01
    z[7,6,3]  R2057     -1.8831750378012657e-02
    z[7,6,3]  R2058     2.1138250827789307e-02
    z[7,6,3]  R2059     7.7364087104797363e-02
    z[7,6,3]  R2060     1.9364996254444122e-01
    z[7,6,3]  R2061     2.1951900422573090e-01
    z[7,6,3]  R2062     -1.9554218649864197e-01
    z[7,6,3]  R2063     8.4854386746883392e-02
    z[7,6,3]  R2064     4.9137137830257416e-02
    z[7,6,3]  R2065     -2.8785604238510132e-01
    z[7,6,3]  R2066     -2.2913314402103424e-01
    z[7,6,3]  R2067     8.4756435826420784e-03
    z[7,6,3]  R2068     7.5632624328136444e-02
    z[7,6,3]  R2069     -2.8737723827362061e-01
    z[7,6,3]  R2070     3.9898529648780823e-01
    z[7,6,3]  R2071     3.8776386529207230e-02
    z[7,6,3]  R2072     -2.2496329620480537e-02
    z[7,6,3]  R2073     1.2387485057115555e-01
    z[7,6,3]  R2074     -5.4098880290985107e-01
    z[7,6,3]  R2075     4.7856390476226807e-01
    z[7,6,3]  R2076     8.6956232786178589e-02
    z[7,6,3]  R2077     -2.1382060647010803e-01
    z[7,6,3]  R2078     4.3871462345123291e-01
    z[7,6,3]  R2079     -9.7884587943553925e-02
    z[7,6,3]  R2080     4.0203514695167542e-01
    z[7,6,3]  R2081     4.2656800150871277e-01
    z[7,6,3]  R2082     1.7222790420055389e-01
    z[7,6,3]  R2083     -2.5081360340118408e-01
    z[7,6,3]  R2084     6.9391858577728271e-01
    z[7,6,3]  R2085     -2.2699804604053497e-01
    z[7,6,3]  R2086     0.654820442199707
    z[7,6,3]  R2087     -2.8070241212844849e-01
    z[7,6,3]  R2088     0.0955732986330986
    z[7,6,3]  R2089     3.8018837571144104e-01
    z[7,6,3]  R2090     2.4246200919151306e-01
    z[7,6,3]  R2091     4.7367489337921143e-01
    z[7,6,3]  R2092     8.7103784084320068e-02
    z[7,6,3]  R2093     5.8222156763076782e-01
    z[7,6,3]  R2094     2.7179878950119019e-01
    z[7,6,3]  R2095     6.3187349587678909e-03
    z[7,6,3]  R2096     -2.4007922410964966e-01
    z[7,6,3]  R2097     1.7896729707717896e-01
    z[7,6,3]  R2098     1.1246153712272644e-01
    z[7,6,3]  R2099     0.343535453081131
    z[7,6,3]  R2100     -8.0852784216403961e-02
    z[7,6,3]  R2101     2.1543757990002632e-02
    z[7,6,3]  R2102     0.622757077217102
    z[7,6,3]  R2103     3.3091518282890320e-01
    z[7,6,3]  R2104     -2.2827278077602386e-01
    z[7,6,3]  R2105     -2.8170111775398254e-01
    z[7,6,3]  R2106     -5.0733107328414917e-01
    z[7,6,3]  R2107     6.6642665863037109e-01
    z[7,6,3]  R2108     -5.4064452648162842e-01
    z[7,6,3]  R2109     3.9117965102195740e-01
    z[7,6,3]  R2110     -0.279350608587265
    z[7,6,3]  R2111     -3.5979685187339783e-01
    z[7,6,3]  R2112     7.2067701816558838e-01
    z[7,6,3]  R2113     2.5874990224838257e-01
    z[7,6,3]  R2114     2.4203525483608246e-01
    z[7,6,3]  R2115     -1.8975268304347992e-01
    z[7,6,3]  R2116     -1.5461277961730957e-01
    z[7,6,3]  R2117     -3.5554841160774231e-02
    z[7,6,3]  R2118     -1.0980086028575897e-01
    z[7,6,3]  R2119     8.6332093924283981e-03
    z[7,6,3]  R2120     4.7490164637565613e-02
    z[7,6,3]  R2121     2.8536167740821838e-01
    z[7,6,3]  R2122     2.3685184121131897e-01
    z[7,6,3]  R2123     2.6239043474197388e-01
    z[7,6,3]  R2124     -2.1712154150009155e-01
    z[7,6,3]  R2125     1.7849530279636383e-01
    z[7,6,3]  R2126     3.1665435433387756e-01
    z[7,6,3]  R2127     -2.5579133629798889e-01
    z[7,6,3]  R2128     1.0500301420688629e-01
    z[7,6,3]  R2129     4.6437028795480728e-02
    z[7,6,3]  R2130     -4.8745346069335938e-01
    z[7,6,3]  R2131     -2.7795964479446411e-01
    z[7,6,3]  R2132     -5.9017390012741089e-01
    z[7,6,3]  R2133     -1.5690918266773224e-01
    z[7,6,3]  R2134     3.5372716188430786e-01
    z[7,6,3]  R2135     -7.4609339237213135e-02
    z[7,6,3]  R2136     -3.0010592937469482e-01
    z[7,6,3]  R2137     -1.9031988084316254e-01
    z[7,6,3]  R2138     -5.6362503767013550e-01
    z[7,6,3]  R2139     -0.260911226272583
    z[7,6,3]  R2140     -5.5483013391494751e-01
    z[7,6,4]  R60       1
    z[7,6,4]  R69       -1
    z[7,6,4]  R2041     -1
    z[7,6,4]  R2042     1
    z[7,6,4]  R2047     8.9499615132808685e-02
    z[7,6,4]  R2048     4.7331336885690689e-02
    z[7,6,4]  R2049     3.2973381876945496e-01
    z[7,6,4]  R2050     -3.3574157953262329e-01
    z[7,6,4]  R2051     -4.2432984709739685e-01
    z[7,6,4]  R2052     3.9872664213180542e-01
    z[7,6,4]  R2053     -5.3129500150680542e-01
    z[7,6,4]  R2054     -1.2451307475566864e-01
    z[7,6,4]  R2055     -2.4385261535644531e-01
    z[7,6,4]  R2056     5.1127278804779053e-01
    z[7,6,4]  R2057     -9.7215771675109863e-03
    z[7,6,4]  R2058     -3.6113986372947693e-01
    z[7,6,4]  R2059     -3.7307681050151587e-03
    z[7,6,4]  R2060     3.2739689946174622e-01
    z[7,6,4]  R2061     1.6731344163417816e-01
    z[7,6,4]  R2062     -4.4316089153289795e-01
    z[7,6,4]  R2063     -6.4428359270095825e-01
    z[7,6,4]  R2064     -4.4806912541389465e-01
    z[7,6,4]  R2065     4.5098461210727692e-02
    z[7,6,4]  R2066     -2.2722931206226349e-01
    z[7,6,4]  R2067     8.8432833552360535e-02
    z[7,6,4]  R2068     0.465313196182251
    z[7,6,4]  R2069     1.2860104441642761e-01
    z[7,6,4]  R2070     -3.3516031503677368e-01
    z[7,6,4]  R2071     -6.3609242439270020e-01
    z[7,6,4]  R2072     0.596617579460144
    z[7,6,4]  R2073     -1.7998097836971283e-01
    z[7,6,4]  R2074     -4.9788096547126770e-01
    z[7,6,4]  R2075     -5.6146466732025146e-01
    z[7,6,4]  R2076     1.4679694175720215e-01
    z[7,6,4]  R2077     -6.3950762152671814e-02
    z[7,6,4]  R2078     2.4879693984985352e-01
    z[7,6,4]  R2079     1.5833935141563416e-01
    z[7,6,4]  R2080     5.1392215490341187e-01
    z[7,6,4]  R2081     -3.7641230225563049e-01
    z[7,6,4]  R2082     0.379869282245636
    z[7,6,4]  R2083     9.6967279911041260e-02
    z[7,6,4]  R2084     1.0076423641294241e-03
    z[7,6,4]  R2085     2.0542123913764954e-01
    z[7,6,4]  R2086     -5.4098106920719147e-02
    z[7,6,4]  R2087     -2.7587391436100006e-02
    z[7,6,4]  R2088     -3.4771472215652466e-01
    z[7,6,4]  R2089     -3.8345164060592651e-01
    z[7,6,4]  R2090     3.8322802633047104e-02
    z[7,6,4]  R2091     -1.1859432607889175e-01
    z[7,6,4]  R2092     3.4360870718955994e-01
    z[7,6,4]  R2093     8.2579381763935089e-02
    z[7,6,4]  R2094     3.4066599607467651e-01
    z[7,6,4]  R2095     3.4818691015243530e-01
    z[7,6,4]  R2096     -3.2962700724601746e-01
    z[7,6,4]  R2097     -4.4653964042663574e-01
    z[7,6,4]  R2098     0.174747034907341
    z[7,6,4]  R2099     2.2072552144527435e-01
    z[7,6,4]  R2100     -6.0214113444089890e-02
    z[7,6,4]  R2101     8.6433209478855133e-02
    z[7,6,4]  R2102     -1.4656464755535126e-01
    z[7,6,4]  R2103     3.1219854950904846e-01
    z[7,6,4]  R2104     -5.9438440948724747e-02
    z[7,6,4]  R2105     -7.0988601446151733e-01
    z[7,6,4]  R2106     -2.6318114995956421e-01
    z[7,6,4]  R2107     -1.6919200122356415e-01
    z[7,6,4]  R2108     -3.7650740146636963e-01
    z[7,6,4]  R2109     -2.1941165626049042e-01
    z[7,6,4]  R2110     -2.4052104353904724e-01
    z[7,6,4]  R2111     4.3770986795425415e-01
    z[7,6,4]  R2112     1.5775993466377258e-01
    z[7,6,4]  R2113     -1.2614172697067261e-01
    z[7,6,4]  R2114     2.4360871315002441e-01
    z[7,6,4]  R2115     7.9051433131098747e-03
    z[7,6,4]  R2116     1.9794492423534393e-01
    z[7,6,4]  R2117     3.7752953171730042e-01
    z[7,6,4]  R2118     -3.6943656206130981e-01
    z[7,6,4]  R2119     -2.7956220507621765e-01
    z[7,6,4]  R2120     -2.5055420398712158e-01
    z[7,6,4]  R2121     -4.9570269882678986e-02
    z[7,6,4]  R2122     2.6393425464630127e-01
    z[7,6,4]  R2123     6.4228612184524536e-01
    z[7,6,4]  R2124     5.7015073299407959e-01
    z[7,6,4]  R2125     2.4942095577716827e-01
    z[7,6,4]  R2126     2.1850416064262390e-01
    z[7,6,4]  R2127     1.6406890749931335e-01
    z[7,6,4]  R2128     -4.2165097594261169e-01
    z[7,6,4]  R2129     -4.4154065847396851e-01
    z[7,6,4]  R2130     7.8501164913177490e-02
    z[7,6,4]  R2131     -1.6236285865306854e-01
    z[7,6,4]  R2132     -1.1570196598768234e-02
    z[7,6,4]  R2133     -3.2835006713867188e-01
    z[7,6,4]  R2134     5.7537955045700073e-01
    z[7,6,4]  R2135     -1.9492319226264954e-01
    z[7,6,4]  R2136     -1.7925573885440826e-01
    z[7,6,4]  R2137     -1.6380502283573151e-01
    z[7,6,4]  R2138     -0.260452002286911
    z[7,6,4]  R2139     6.8050853908061981e-02
    z[7,6,4]  R2140     -9.8680742084980011e-02
    z[7,6,5]  R61       1
    z[7,6,5]  R70       -1
    z[7,6,5]  R2043     -1
    z[7,6,5]  R2044     1
    z[7,6,5]  R2047     2.5110411643981934e-01
    z[7,6,5]  R2048     -1.0927030444145203e-01
    z[7,6,5]  R2049     0.0615973100066185
    z[7,6,5]  R2050     6.1962729692459106e-01
    z[7,6,5]  R2051     4.3426585197448730e-01
    z[7,6,5]  R2052     3.0216521024703979e-01
    z[7,6,5]  R2053     3.0502077937126160e-01
    z[7,6,5]  R2054     -9.4746068120002747e-02
    z[7,6,5]  R2055     9.1737724840641022e-02
    z[7,6,5]  R2056     2.5821238756179810e-01
    z[7,6,5]  R2057     -4.9469181895256042e-01
    z[7,6,5]  R2058     -7.1768736839294434e-01
    z[7,6,5]  R2059     -4.4325152039527893e-01
    z[7,6,5]  R2060     1.5520103275775909e-01
    z[7,6,5]  R2061     -3.0298948287963867e-01
    z[7,6,5]  R2062     -4.3303561210632324e-01
    z[7,6,5]  R2063     -6.8086847662925720e-02
    z[7,6,5]  R2064     -4.3712366372346878e-02
    z[7,6,5]  R2065     -8.8271975517272949e-02
    z[7,6,5]  R2066     2.4261020123958588e-02
    z[7,6,5]  R2067     -8.1317991018295288e-02
    z[7,6,5]  R2068     3.1873297691345215e-01
    z[7,6,5]  R2069     0.493461012840271
    z[7,6,5]  R2070     0.0917491689324379
    z[7,6,5]  R2071     0.0384628064930439
    z[7,6,5]  R2072     -2.5385764241218567e-01
    z[7,6,5]  R2073     6.6737681627273560e-01
    z[7,6,5]  R2074     3.6219995468854904e-02
    z[7,6,5]  R2075     1.7828892171382904e-01
    z[7,6,5]  R2076     1.6482140123844147e-01
    z[7,6,5]  R2077     -4.6848282217979431e-01
    z[7,6,5]  R2078     2.8239700198173523e-01
    z[7,6,5]  R2079     2.3493885993957520e-01
    z[7,6,5]  R2080     -5.5758815258741379e-02
    z[7,6,5]  R2081     2.7847331762313843e-01
    z[7,6,5]  R2082     -0.278018981218338
    z[7,6,5]  R2083     1.0319099575281143e-01
    z[7,6,5]  R2084     1.1388929933309555e-01
    z[7,6,5]  R2085     -6.6204950213432312e-02
    z[7,6,5]  R2086     2.0312872529029846e-01
    z[7,6,5]  R2087     -1.8792280554771423e-01
    z[7,6,5]  R2088     -5.0165127962827682e-02
    z[7,6,5]  R2089     4.0426683425903320e-01
    z[7,6,5]  R2090     -3.4717744588851929e-01
    z[7,6,5]  R2091     -2.1615166962146759e-01
    z[7,6,5]  R2092     -2.1370968222618103e-01
    z[7,6,5]  R2093     9.8391756415367126e-02
    z[7,6,5]  R2094     3.8102051615715027e-01
    z[7,6,5]  R2095     8.0623924732208252e-02
    z[7,6,5]  R2096     1.5236005187034607e-01
    z[7,6,5]  R2097     1.7441053688526154e-01
    z[7,6,5]  R2098     -4.6163287013769150e-02
    z[7,6,5]  R2099     9.7324825823307037e-02
    z[7,6,5]  R2100     -2.6789653301239014e-01
    z[7,6,5]  R2101     1.7962953448295593e-01
    z[7,6,5]  R2102     -1.7342975735664368e-01
    z[7,6,5]  R2103     2.9710179567337036e-01
    z[7,6,5]  R2104     -3.4951677918434143e-01
    z[7,6,5]  R2105     1.6739878058433533e-01
    z[7,6,5]  R2106     3.6380210518836975e-01
    z[7,6,5]  R2107     2.5592729449272156e-01
    z[7,6,5]  R2108     -1.4988232869654894e-03
    z[7,6,5]  R2109     5.1170504093170166e-01
    z[7,6,5]  R2110     -3.2616552710533142e-01
    z[7,6,5]  R2111     -3.5955232381820679e-01
    z[7,6,5]  R2112     -1.5198934078216553e-01
    z[7,6,5]  R2113     4.1818149387836456e-02
    z[7,6,5]  R2114     2.6045233011245728e-02
    z[7,6,5]  R2115     -6.7827187478542328e-02
    z[7,6,5]  R2116     1.7519944906234741e-01
    z[7,6,5]  R2117     -0.0880071297287941
    z[7,6,5]  R2118     -3.4801412373781204e-02
    z[7,6,5]  R2119     -9.7975112497806549e-02
    z[7,6,5]  R2120     2.3809593915939331e-01
    z[7,6,5]  R2121     3.3612795174121857e-02
    z[7,6,5]  R2122     -5.7271972298622131e-02
    z[7,6,5]  R2123     9.1047652065753937e-02
    z[7,6,5]  R2124     -4.4316451996564865e-02
    z[7,6,5]  R2125     3.4391567111015320e-01
    z[7,6,5]  R2126     1.9005237519741058e-01
    z[7,6,5]  R2127     -4.4324430823326111e-01
    z[7,6,5]  R2128     -3.4918987751007080e-01
    z[7,6,5]  R2129     5.1142746210098267e-01
    z[7,6,5]  R2130     4.1684547066688538e-01
    z[7,6,5]  R2131     1.1127652972936630e-01
    z[7,6,5]  R2132     -5.0437271595001221e-02
    z[7,6,5]  R2133     2.2210228443145752e-01
    z[7,6,5]  R2134     -4.8537328839302063e-01
    z[7,6,5]  R2135     1.0913676023483276e-01
    z[7,6,5]  R2136     -4.3426580727100372e-02
    z[7,6,5]  R2137     3.6192888021469116e-01
    z[7,6,5]  R2138     -2.4011881649494171e-01
    z[7,6,5]  R2139     -2.0933395624160767e-01
    z[7,6,5]  R2140     2.4340030550956726e-01
    z[7,6,6]  R62       1
    z[7,6,6]  R71       -1
    z[7,6,6]  R2045     -1
    z[7,6,6]  R2046     1
    z[7,6,6]  R2047     -3.3257222175598145e-01
    z[7,6,6]  R2048     2.4919089674949646e-01
    z[7,6,6]  R2049     1.3880443572998047e-01
    z[7,6,6]  R2050     -1.9143719971179962e-01
    z[7,6,6]  R2051     4.7549134492874146e-01
    z[7,6,6]  R2052     -0.300910085439682
    z[7,6,6]  R2053     -4.4281458854675293e-01
    z[7,6,6]  R2054     2.9233753681182861e-01
    z[7,6,6]  R2055     -2.5748351216316223e-01
    z[7,6,6]  R2056     6.3702660799026489e-01
    z[7,6,6]  R2057     4.7362601757049561e-01
    z[7,6,6]  R2058     -0.0733075812458992
    z[7,6,6]  R2059     3.8052010536193848e-01
    z[7,6,6]  R2060     4.6648353338241577e-02
    z[7,6,6]  R2061     -1.7170476913452148e-01
    z[7,6,6]  R2062     2.5206971168518066e-01
    z[7,6,6]  R2063     -2.7114412188529968e-01
    z[7,6,6]  R2064     3.5158342123031616e-01
    z[7,6,6]  R2065     -9.3288779258728027e-02
    z[7,6,6]  R2066     5.0532564520835876e-02
    z[7,6,6]  R2067     -2.9479971528053284e-01
    z[7,6,6]  R2068     3.5192602872848511e-01
    z[7,6,6]  R2069     8.4343627095222473e-02
    z[7,6,6]  R2070     2.2997410595417023e-01
    z[7,6,6]  R2071     1.0663776844739914e-01
    z[7,6,6]  R2072     4.0431201457977295e-01
    z[7,6,6]  R2073     -1.2665948271751404e-01
    z[7,6,6]  R2074     2.4457333981990814e-01
    z[7,6,6]  R2075     -2.0126027986407280e-02
    z[7,6,6]  R2076     3.0705055594444275e-01
    z[7,6,6]  R2077     2.3841249942779541e-01
    z[7,6,6]  R2078     -2.6274269819259644e-01
    z[7,6,6]  R2079     -2.1397694945335388e-01
    z[7,6,6]  R2080     -9.7718074917793274e-02
    z[7,6,6]  R2081     2.1014584600925446e-01
    z[7,6,6]  R2082     -6.7001514136791229e-02
    z[7,6,6]  R2083     -1.4330537617206573e-01
    z[7,6,6]  R2084     -2.8399093076586723e-02
    z[7,6,6]  R2085     -1.6327325999736786e-01
    z[7,6,6]  R2086     1.0520142316818237e-01
    z[7,6,6]  R2087     1.3809648156166077e-01
    z[7,6,6]  R2088     7.0091497898101807e-01
    z[7,6,6]  R2089     3.8709127902984619e-01
    z[7,6,6]  R2090     5.9288042783737183e-01
    z[7,6,6]  R2091     -7.7191629679873586e-04
    z[7,6,6]  R2092     1.5890252590179443e-01
    z[7,6,6]  R2093     1.9742861390113831e-01
    z[7,6,6]  R2094     6.8271338939666748e-02
    z[7,6,6]  R2095     -3.7137228250503540e-01
    z[7,6,6]  R2096     2.0336598157882690e-01
    z[7,6,6]  R2097     4.4109782576560974e-01
    z[7,6,6]  R2098     -2.6941576600074768e-01
    z[7,6,6]  R2099     1.1533229053020477e-01
    z[7,6,6]  R2100     -2.2734068334102631e-01
    z[7,6,6]  R2101     -2.1608080714941025e-02
    z[7,6,6]  R2102     2.1889238059520721e-01
    z[7,6,6]  R2103     4.3361580371856689e-01
    z[7,6,6]  R2104     -4.1909894347190857e-01
    z[7,6,6]  R2105     -9.6110187470912933e-02
    z[7,6,6]  R2106     -8.4997788071632385e-02
    z[7,6,6]  R2107     1.4928846061229706e-01
    z[7,6,6]  R2108     3.4113296866416931e-01
    z[7,6,6]  R2109     2.6181507110595703e-01
    z[7,6,6]  R2110     2.8560775518417358e-01
    z[7,6,6]  R2111     5.0760549306869507e-01
    z[7,6,6]  R2112     -1.8244978785514832e-01
    z[7,6,6]  R2113     -0.064302958548069
    z[7,6,6]  R2114     1.2488375417888165e-02
    z[7,6,6]  R2115     2.1631282567977905e-01
    z[7,6,6]  R2116     2.3979188501834869e-01
    z[7,6,6]  R2117     -2.8227767348289490e-01
    z[7,6,6]  R2118     1.6881720721721649e-01
    z[7,6,6]  R2119     -4.0435448288917542e-01
    z[7,6,6]  R2120     -2.9842558503150940e-01
    z[7,6,6]  R2121     2.0019564032554626e-01
    z[7,6,6]  R2122     -2.1049199998378754e-01
    z[7,6,6]  R2123     2.4944262206554413e-01
    z[7,6,6]  R2124     1.5712873637676239e-01
    z[7,6,6]  R2125     3.6919301748275757e-01
    z[7,6,6]  R2126     -3.2470297813415527e-01
    z[7,6,6]  R2127     1.4522561430931091e-01
    z[7,6,6]  R2128     -2.4920284748077393e-01
    z[7,6,6]  R2129     1.7616525292396545e-01
    z[7,6,6]  R2130     -1.5595553815364838e-01
    z[7,6,6]  R2131     1.9744274020195007e-01
    z[7,6,6]  R2132     2.8939232230186462e-01
    z[7,6,6]  R2133     3.4484165906906128e-01
    z[7,6,6]  R2134     -6.2001351267099380e-02
    z[7,6,6]  R2135     1.6115553677082062e-01
    z[7,6,6]  R2136     -2.8612977266311646e-01
    z[7,6,6]  R2137     -2.8295481204986572e-01
    z[7,6,6]  R2138     -9.8420321941375732e-02
    z[7,6,6]  R2139     -2.1999720484018326e-02
    z[7,6,6]  R2140     2.1032616496086121e-01
    z[7,8,0]  R65       -1
    z[7,8,0]  R74       1
    z[7,8,0]  R2141     -1
    z[7,8,0]  R2142     1
    z[7,8,0]  R2155     1.5107576549053192e-01
    z[7,8,0]  R2156     1.9000087678432465e-01
    z[7,8,0]  R2157     2.4899569153785706e-01
    z[7,8,0]  R2158     1.8969222903251648e-01
    z[7,8,0]  R2159     7.6405808329582214e-02
    z[7,8,0]  R2160     2.0453310012817383e-01
    z[7,8,0]  R2161     2.9127034544944763e-01
    z[7,8,0]  R2162     -5.3835548460483551e-03
    z[7,8,0]  R2163     0.0112368268892169
    z[7,8,0]  R2164     1.9862614572048187e-01
    z[7,8,0]  R2165     6.4337074756622314e-01
    z[7,8,0]  R2166     5.5937623977661133e-01
    z[7,8,0]  R2167     5.6334191560745239e-01
    z[7,8,0]  R2168     4.1311725974082947e-01
    z[7,8,0]  R2169     5.8645331859588623e-01
    z[7,8,0]  R2170     -2.0132945477962494e-01
    z[7,8,0]  R2171     -3.8083148002624512e-01
    z[7,8,0]  R2172     -5.1675987243652344e-01
    z[7,8,0]  R2173     -9.3736845254898071e-01
    z[7,8,0]  R2174     -9.4241410493850708e-01
    z[7,8,0]  R2175     6.3418996334075928e-01
    z[7,8,0]  R2176     3.3805477619171143e-01
    z[7,8,0]  R2177     7.0690816640853882e-01
    z[7,8,0]  R2178     0.77171391248703
    z[7,8,0]  R2179     0.097800612449646
    z[7,8,0]  R2180     1.4096279442310333e-01
    z[7,8,0]  R2181     2.3734317719936371e-01
    z[7,8,0]  R2182     4.0585020184516907e-01
    z[7,8,0]  R2183     3.3952784538269043e-01
    z[7,8,0]  R2184     -0.0949232280254364
    z[7,8,0]  R2185     -4.1349551081657410e-01
    z[7,8,0]  R2186     -3.4606429934501648e-01
    z[7,8,0]  R2187     -3.3707737922668457e-01
    z[7,8,0]  R2188     -1.8754664063453674e-01
    z[7,8,0]  R2189     1.0538776963949203e-01
    z[7,8,0]  R2190     -2.3383601009845734e-01
    z[7,8,0]  R2191     -5.1879596710205078e-01
    z[7,8,0]  R2192     -2.7531775832176208e-01
    z[7,8,0]  R2193     -5.7779371738433838e-01
    z[7,8,0]  R2194     -1.0655597597360611e-01
    z[7,8,0]  R2195     2.6284253597259521e-01
    z[7,8,0]  R2196     0.26040118932724
    z[7,8,0]  R2197     1.4025020599365234e-01
    z[7,8,0]  R2198     2.2039799392223358e-01
    z[7,8,0]  R2199     -1.2962000072002411e-01
    z[7,8,0]  R2200     -1.1158938705921173e-01
    z[7,8,0]  R2201     4.7225572168827057e-02
    z[7,8,0]  R2202     -1.7873022705316544e-02
    z[7,8,0]  R2203     -2.9024323821067810e-01
    z[7,8,0]  R2204     -5.0971823930740356e-01
    z[7,8,0]  R2205     2.9222929477691650e-01
    z[7,8,0]  R2206     8.4249682724475861e-02
    z[7,8,0]  R2207     1.5272390842437744e-01
    z[7,8,0]  R2208     -5.0775593519210815e-01
    z[7,8,0]  R2209     -7.0655876398086548e-01
    z[7,8,0]  R2210     -4.1153064370155334e-01
    z[7,8,0]  R2211     -8.2706409692764282e-01
    z[7,8,0]  R2212     -9.1056984663009644e-01
    z[7,8,0]  R2213     -0.896411120891571
    z[7,8,0]  R2214     -7.7990359067916870e-01
    z[7,8,0]  R2215     -8.9173072576522827e-01
    z[7,8,0]  R2216     -8.0726486444473267e-01
    z[7,8,0]  R2217     -7.5758165121078491e-01
    z[7,8,0]  R2218     -6.9680100679397583e-01
    z[7,8,0]  R2219     -6.8020689487457275e-01
    z[7,8,0]  R2220     8.8735990226268768e-02
    z[7,8,0]  R2221     4.9224663525819778e-02
    z[7,8,0]  R2222     3.1487852334976196e-01
    z[7,8,0]  R2223     3.5001170635223389e-01
    z[7,8,0]  R2224     3.3615925908088684e-01
    z[7,8,0]  R2225     2.7263092994689941e-01
    z[7,8,0]  R2226     2.4038107693195343e-01
    z[7,8,0]  R2227     3.2954993844032288e-01
    z[7,8,0]  R2228     2.7537909150123596e-01
    z[7,8,0]  R2229     4.1178759932518005e-01
    z[7,8,0]  R2230     0.595511794090271
    z[7,8,0]  R2231     -0.0982019230723381
    z[7,8,0]  R2232     2.6607644557952881e-01
    z[7,8,0]  R2233     1.4676716923713684e-01
    z[7,8,0]  R2234     1.4686042070388794e-01
    z[7,8,0]  R2235     1.1764391511678696e-01
    z[7,8,0]  R2236     -4.9060784280300140e-02
    z[7,8,0]  R2237     -1.3944949209690094e-01
    z[7,8,0]  R2238     -3.4394964575767517e-01
    z[7,8,0]  R2239     -1.0979624092578888e-01
    z[7,8,0]  R2240     1.1869938671588898e-01
    z[7,8,0]  R2241     -2.8038039803504944e-01
    z[7,8,0]  R2242     1.5873451530933380e-01
    z[7,8,0]  R2243     3.6990955471992493e-02
    z[7,8,0]  R2244     1.4406321942806244e-01
    z[7,8,0]  R2245     9.2446029186248779e-02
    z[7,8,0]  R2246     1.0045155882835388e-01
    z[7,8,0]  R2247     2.3465298116207123e-01
    z[7,8,0]  R2248     1.7545820772647858e-01
    z[7,8,0]  R2249     -4.4613018631935120e-02
    z[7,8,0]  R2250     -4.5370548963546753e-02
    z[7,8,0]  R2251     1.1342381127178669e-02
    z[7,8,0]  R2252     0.00920828152447939
    z[7,8,0]  R2253     1.2489434331655502e-01
    z[7,8,0]  R2254     2.1298396587371826e-01
    z[7,8,0]  R2255     7.2609391063451767e-03
    z[7,8,0]  R2256     1.0130155831575394e-02
    z[7,8,0]  R2257     3.2253018021583557e-01
    z[7,8,0]  R2258     6.7334115505218506e-01
    z[7,8,0]  R2259     0.282462477684021
    z[7,8,0]  R2260     3.3619120717048645e-01
    z[7,8,0]  R2261     7.9640835523605347e-01
    z[7,8,0]  R2262     9.1283661127090454e-01
    z[7,8,0]  R2263     8.2904303073883057e-01
    z[7,8,0]  R2264     7.7248513698577881e-01
    z[7,8,0]  R2265     2.1900284290313721e-01
    z[7,8,0]  R2266     7.6090240478515625e-01
    z[7,8,0]  R2267     0.59315025806427
    z[7,8,0]  R2268     5.6900697946548462e-01
    z[7,8,0]  R2269     4.3024361133575439e-01
    z[7,8,0]  R2270     5.2603250741958618e-01
    z[7,8,1]  R66       -1
    z[7,8,1]  R75       1
    z[7,8,1]  R2143     -1
    z[7,8,1]  R2144     1
    z[7,8,1]  R2155     -0.483767032623291
    z[7,8,1]  R2156     -0.433219313621521
    z[7,8,1]  R2157     -3.7000021338462830e-01
    z[7,8,1]  R2158     -4.3177920579910278e-01
    z[7,8,1]  R2159     -5.0468832254409790e-01
    z[7,8,1]  R2160     -3.3606818318367004e-01
    z[7,8,1]  R2161     -2.2872298955917358e-01
    z[7,8,1]  R2162     8.6079066991806030e-01
    z[7,8,1]  R2163     0.921334445476532
    z[7,8,1]  R2164     -2.2989258170127869e-01
    z[7,8,1]  R2165     -6.9852188229560852e-02
    z[7,8,1]  R2166     -8.2686953246593475e-02
    z[7,8,1]  R2167     -1.4327128231525421e-01
    z[7,8,1]  R2168     -6.7116126418113708e-02
    z[7,8,1]  R2169     -8.6113018915057182e-04
    z[7,8,1]  R2170     6.7343002557754517e-01
    z[7,8,1]  R2171     5.8207976818084717e-01
    z[7,8,1]  R2172     6.3580900430679321e-01
    z[7,8,1]  R2173     5.4047949612140656e-02
    z[7,8,1]  R2174     4.9451023340225220e-02
    z[7,8,1]  R2175     -7.0346224308013916e-01
    z[7,8,1]  R2176     -5.1667302846908569e-01
    z[7,8,1]  R2177     -2.2671933472156525e-01
    z[7,8,1]  R2178     -1.6377186775207520e-01
    z[7,8,1]  R2179     -5.9961438179016113e-01
    z[7,8,1]  R2180     -4.7854939103126526e-01
    z[7,8,1]  R2181     -3.2761031389236450e-01
    z[7,8,1]  R2182     -2.9142358899116516e-01
    z[7,8,1]  R2183     -2.5573647022247314e-01
    z[7,8,1]  R2184     5.7698541879653931e-01
    z[7,8,1]  R2185     6.5377980470657349e-01
    z[7,8,1]  R2186     6.3390594720840454e-01
    z[7,8,1]  R2187     6.7765879631042480e-01
    z[7,8,1]  R2188     7.2343409061431885e-01
    z[7,8,1]  R2189     6.4129769802093506e-01
    z[7,8,1]  R2190     8.2109671831130981e-01
    z[7,8,1]  R2191     7.9056274890899658e-01
    z[7,8,1]  R2192     4.8545023798942566e-01
    z[7,8,1]  R2193     5.5226039886474609e-01
    z[7,8,1]  R2194     7.0540577173233032e-01
    z[7,8,1]  R2195     -7.0736521482467651e-01
    z[7,8,1]  R2196     -5.4311233758926392e-01
    z[7,8,1]  R2197     -6.0203611850738525e-01
    z[7,8,1]  R2198     -5.6805652379989624e-01
    z[7,8,1]  R2199     7.8660231828689575e-01
    z[7,8,1]  R2200     6.4276885986328125e-01
    z[7,8,1]  R2201     6.0280239582061768e-01
    z[7,8,1]  R2202     8.1228846311569214e-01
    z[7,8,1]  R2203     0.805886447429657
    z[7,8,1]  R2204     6.9819837808609009e-01
    z[7,8,1]  R2205     -6.7314684391021729e-01
    z[7,8,1]  R2206     8.0872654914855957e-01
    z[7,8,1]  R2207     8.1183636188507080e-01
    z[7,8,1]  R2208     5.8985030651092529e-01
    z[7,8,1]  R2209     4.3527165055274963e-01
    z[7,8,1]  R2210     5.8477109670639038e-01
    z[7,8,1]  R2211     -3.8884587585926056e-02
    z[7,8,1]  R2212     -2.8132705017924309e-02
    z[7,8,1]  R2213     1.3578535616397858e-01
    z[7,8,1]  R2214     -8.7959386408329010e-02
    z[7,8,1]  R2215     0.0275983028113842
    z[7,8,1]  R2216     0.268432080745697
    z[7,8,1]  R2217     4.5238915085792542e-01
    z[7,8,1]  R2218     2.9841421172022820e-02
    z[7,8,1]  R2219     1.1943578720092773e-01
    z[7,8,1]  R2220     -8.0063328146934509e-02
    z[7,8,1]  R2221     -6.2669318914413452e-01
    z[7,8,1]  R2222     -3.9516237378120422e-01
    z[7,8,1]  R2223     -3.8031238317489624e-01
    z[7,8,1]  R2224     7.9426276683807373e-01
    z[7,8,1]  R2225     8.2045537233352661e-01
    z[7,8,1]  R2226     8.8006341457366943e-01
    z[7,8,1]  R2227     8.8734275102615356e-01
    z[7,8,1]  R2228     -3.7226536870002747e-01
    z[7,8,1]  R2229     8.6910420656204224e-01
    z[7,8,1]  R2230     -2.3682117462158203e-01
    z[7,8,1]  R2231     -9.3146163225173950e-01
    z[7,8,1]  R2232     -7.6777690649032593e-01
    z[7,8,1]  R2233     -9.0915805101394653e-01
    z[7,8,1]  R2234     -8.3823961019515991e-01
    z[7,8,1]  R2235     -0.82839035987854
    z[7,8,1]  R2236     -0.780409038066864
    z[7,8,1]  R2237     -7.5964945554733276e-01
    z[7,8,1]  R2238     -8.2713586091995239e-01
    z[7,8,1]  R2239     -6.8862271308898926e-01
    z[7,8,1]  R2240     -7.0851981639862061e-01
    z[7,8,1]  R2241     -8.1212782859802246e-01
    z[7,8,1]  R2242     8.8121265172958374e-01
    z[7,8,1]  R2243     8.4028065204620361e-01
    z[7,8,1]  R2244     7.6849848031997681e-01
    z[7,8,1]  R2245     8.1701892614364624e-01
    z[7,8,1]  R2246     7.8537470102310181e-01
    z[7,8,1]  R2247     0.756335437297821
    z[7,8,1]  R2248     6.2838083505630493e-01
    z[7,8,1]  R2249     4.9951234459877014e-01
    z[7,8,1]  R2250     5.2126449346542358e-01
    z[7,8,1]  R2251     8.6326146125793457e-01
    z[7,8,1]  R2252     9.1128599643707275e-01
    z[7,8,1]  R2253     8.3672732114791870e-01
    z[7,8,1]  R2254     8.1179004907608032e-01
    z[7,8,1]  R2255     7.5844889879226685e-01
    z[7,8,1]  R2256     5.5628603696823120e-01
    z[7,8,1]  R2257     4.1705000400543213e-01
    z[7,8,1]  R2258     6.1076825857162476e-01
    z[7,8,1]  R2259     3.4541657567024231e-01
    z[7,8,1]  R2260     3.7452796101570129e-01
    z[7,8,1]  R2261     4.6728920936584473e-01
    z[7,8,1]  R2262     1.5661269426345825e-01
    z[7,8,1]  R2263     2.0572523772716522e-01
    z[7,8,1]  R2264     1.5655416250228882e-01
    z[7,8,1]  R2265     4.1292944550514221e-01
    z[7,8,1]  R2266     1.3044695556163788e-01
    z[7,8,1]  R2267     2.1109478175640106e-01
    z[7,8,1]  R2268     1.3563109934329987e-01
    z[7,8,1]  R2269     5.2235114574432373e-01
    z[7,8,1]  R2270     3.5238561034202576e-01
    z[7,8,2]  R67       -1
    z[7,8,2]  R76       1
    z[7,8,2]  R2145     -1
    z[7,8,2]  R2146     1
    z[7,8,2]  R2155     7.4862468242645264e-01
    z[7,8,2]  R2156     4.5391109585762024e-01
    z[7,8,2]  R2157     4.2123979330062866e-01
    z[7,8,2]  R2158     -9.6825070679187775e-02
    z[7,8,2]  R2159     1.4415211975574493e-01
    z[7,8,2]  R2160     0.199151411652565
    z[7,8,2]  R2161     1.7901813983917236e-01
    z[7,8,2]  R2162     3.8354527950286865e-01
    z[7,8,2]  R2163     1.2844632565975189e-01
    z[7,8,2]  R2164     3.9112526178359985e-01
    z[7,8,2]  R2165     -3.3422163128852844e-01
    z[7,8,2]  R2166     -1.7012690007686615e-01
    z[7,8,2]  R2167     -5.6111729145050049e-01
    z[7,8,2]  R2168     -0.808626651763916
    z[7,8,2]  R2169     -6.7720323801040649e-01
    z[7,8,2]  R2170     -1.4237721264362335e-01
    z[7,8,2]  R2171     1.2527535855770111e-01
    z[7,8,2]  R2172     1.9976699259132147e-03
    z[7,8,2]  R2173     -1.3049748539924622e-01
    z[7,8,2]  R2174     4.6185430139303207e-02
    z[7,8,2]  R2175     -3.9144292473793030e-02
    z[7,8,2]  R2176     -4.1362863779067993e-01
    z[7,8,2]  R2177     3.1486144661903381e-01
    z[7,8,2]  R2178     -2.1168076992034912e-01
    z[7,8,2]  R2179     4.6035799384117126e-01
    z[7,8,2]  R2180     4.0834966301918030e-01
    z[7,8,2]  R2181     -5.7198524475097656e-01
    z[7,8,2]  R2182     -3.8558465242385864e-01
    z[7,8,2]  R2183     -4.9281004071235657e-01
    z[7,8,2]  R2184     7.1240466833114624e-01
    z[7,8,2]  R2185     2.7471417188644409e-01
    z[7,8,2]  R2186     2.7431827783584595e-01
    z[7,8,2]  R2187     5.3992801904678345e-01
    z[7,8,2]  R2188     5.5345781147480011e-02
    z[7,8,2]  R2189     3.6369696259498596e-01
    z[7,8,2]  R2190     -1.2399200350046158e-01
    z[7,8,2]  R2191     -4.8644639551639557e-02
    z[7,8,2]  R2192     4.3958729505538940e-01
    z[7,8,2]  R2193     4.8620536923408508e-01
    z[7,8,2]  R2194     -8.3687163889408112e-02
    z[7,8,2]  R2195     5.4461705684661865e-01
    z[7,8,2]  R2196     1.1568053066730499e-01
    z[7,8,2]  R2197     -1.1416072398424149e-01
    z[7,8,2]  R2198     3.1054908037185669e-01
    z[7,8,2]  R2199     2.8160366415977478e-01
    z[7,8,2]  R2200     6.1467081308364868e-01
    z[7,8,2]  R2201     4.8983544111251831e-01
    z[7,8,2]  R2202     1.0121591389179230e-02
    z[7,8,2]  R2203     2.4785617366433144e-02
    z[7,8,2]  R2204     -1.4779375493526459e-01
    z[7,8,2]  R2205     -7.1148402988910675e-02
    z[7,8,2]  R2206     4.7006741166114807e-01
    z[7,8,2]  R2207     0.357892245054245
    z[7,8,2]  R2208     5.1053434610366821e-01
    z[7,8,2]  R2209     5.2023524045944214e-01
    z[7,8,2]  R2210     -0.0372295156121254
    z[7,8,2]  R2211     3.7001019716262817e-01
    z[7,8,2]  R2212     3.9191324263811111e-02
    z[7,8,2]  R2213     -2.3739559948444366e-01
    z[7,8,2]  R2214     4.1689342260360718e-01
    z[7,8,2]  R2215     -2.1192955970764160e-01
    z[7,8,2]  R2216     1.5318708121776581e-01
    z[7,8,2]  R2217     1.5639486908912659e-01
    z[7,8,2]  R2218     2.1300381422042847e-01
    z[7,8,2]  R2219     1.4234852790832520e-01
    z[7,8,2]  R2220     6.1447417736053467e-01
    z[7,8,2]  R2221     1.1584693938493729e-01
    z[7,8,2]  R2222     1.3109819591045380e-01
    z[7,8,2]  R2223     -3.8024783134460449e-01
    z[7,8,2]  R2224     9.7751110792160034e-02
    z[7,8,2]  R2225     1.6658306121826172e-02
    z[7,8,2]  R2226     -2.3500657081604004e-01
    z[7,8,2]  R2227     -1.1313124746084213e-01
    z[7,8,2]  R2228     -4.1775825619697571e-01
    z[7,8,2]  R2229     1.2241696566343307e-01
    z[7,8,2]  R2230     5.8064609766006470e-01
    z[7,8,2]  R2231     -2.0666979253292084e-01
    z[7,8,2]  R2232     5.3458905220031738e-01
    z[7,8,2]  R2233     -7.9022668302059174e-02
    z[7,8,2]  R2234     1.7064422369003296e-01
    z[7,8,2]  R2235     2.0214636623859406e-01
    z[7,8,2]  R2236     4.2698092758655548e-02
    z[7,8,2]  R2237     1.4063432812690735e-01
    z[7,8,2]  R2238     1.5370629727840424e-01
    z[7,8,2]  R2239     1.9401220977306366e-01
    z[7,8,2]  R2240     -1.7959360778331757e-01
    z[7,8,2]  R2241     3.1395298242568970e-01
    z[7,8,2]  R2242     2.0556405186653137e-01
    z[7,8,2]  R2243     1.3141946494579315e-01
    z[7,8,2]  R2244     2.8139057755470276e-01
    z[7,8,2]  R2245     0.167667955160141
    z[7,8,2]  R2246     1.5895701944828033e-01
    z[7,8,2]  R2247     -2.1128481626510620e-01
    z[7,8,2]  R2248     6.4380693435668945e-01
    z[7,8,2]  R2249     5.9099775552749634e-01
    z[7,8,2]  R2250     3.2522940635681152e-01
    z[7,8,2]  R2251     2.4921227991580963e-01
    z[7,8,2]  R2252     0.164270281791687
    z[7,8,2]  R2253     3.9745372533798218e-01
    z[7,8,2]  R2254     3.2791949808597565e-02
    z[7,8,2]  R2255     3.8916710019111633e-01
    z[7,8,2]  R2256     5.2506572008132935e-01
    z[7,8,2]  R2257     -0.507003664970398
    z[7,8,2]  R2258     5.9127245098352432e-02
    z[7,8,2]  R2259     -6.3768506050109863e-01
    z[7,8,2]  R2260     -7.6838845014572144e-01
    z[7,8,2]  R2261     2.1167370676994324e-01
    z[7,8,2]  R2262     -7.1744740009307861e-02
    z[7,8,2]  R2263     -3.2376566529273987e-01
    z[7,8,2]  R2264     -9.3596793711185455e-02
    z[7,8,2]  R2265     -7.3147827386856079e-01
    z[7,8,2]  R2266     -2.4297079443931580e-01
    z[7,8,2]  R2267     -1.1006604135036469e-01
    z[7,8,2]  R2268     -3.8526695966720581e-01
    z[7,8,2]  R2269     4.7550402581691742e-02
    z[7,8,2]  R2270     -6.1102062463760376e-01
    z[7,8,3]  R68       -1
    z[7,8,3]  R77       1
    z[7,8,3]  R2147     -1
    z[7,8,3]  R2148     1
    z[7,8,3]  R2155     -3.2232973724603653e-02
    z[7,8,3]  R2156     -7.0278668403625488e-01
    z[7,8,3]  R2157     7.0133650302886963e-01
    z[7,8,3]  R2158     -4.8466470837593079e-01
    z[7,8,3]  R2159     3.5204750299453735e-01
    z[7,8,3]  R2160     -6.8171066045761108e-01
    z[7,8,3]  R2161     5.0931614637374878e-01
    z[7,8,3]  R2162     -4.4291362166404724e-02
    z[7,8,3]  R2163     -1.8455622717738152e-02
    z[7,8,3]  R2164     -1.4436677098274231e-01
    z[7,8,3]  R2165     -1.8831750378012657e-02
    z[7,8,3]  R2166     2.1138250827789307e-02
    z[7,8,3]  R2167     7.7364087104797363e-02
    z[7,8,3]  R2168     1.9364996254444122e-01
    z[7,8,3]  R2169     2.1951900422573090e-01
    z[7,8,3]  R2170     -1.9554218649864197e-01
    z[7,8,3]  R2171     8.4854386746883392e-02
    z[7,8,3]  R2172     4.9137137830257416e-02
    z[7,8,3]  R2173     -2.8785604238510132e-01
    z[7,8,3]  R2174     -2.2913314402103424e-01
    z[7,8,3]  R2175     8.4756435826420784e-03
    z[7,8,3]  R2176     7.5632624328136444e-02
    z[7,8,3]  R2177     -2.8737723827362061e-01
    z[7,8,3]  R2178     3.9898529648780823e-01
    z[7,8,3]  R2179     3.8776386529207230e-02
    z[7,8,3]  R2180     -2.2496329620480537e-02
    z[7,8,3]  R2181     1.2387485057115555e-01
    z[7,8,3]  R2182     -5.4098880290985107e-01
    z[7,8,3]  R2183     4.7856390476226807e-01
    z[7,8,3]  R2184     8.6956232786178589e-02
    z[7,8,3]  R2185     -2.1382060647010803e-01
    z[7,8,3]  R2186     4.3871462345123291e-01
    z[7,8,3]  R2187     -9.7884587943553925e-02
    z[7,8,3]  R2188     4.0203514695167542e-01
    z[7,8,3]  R2189     4.2656800150871277e-01
    z[7,8,3]  R2190     1.7222790420055389e-01
    z[7,8,3]  R2191     -2.5081360340118408e-01
    z[7,8,3]  R2192     6.9391858577728271e-01
    z[7,8,3]  R2193     -2.2699804604053497e-01
    z[7,8,3]  R2194     0.654820442199707
    z[7,8,3]  R2195     -2.8070241212844849e-01
    z[7,8,3]  R2196     0.0955732986330986
    z[7,8,3]  R2197     3.8018837571144104e-01
    z[7,8,3]  R2198     2.4246200919151306e-01
    z[7,8,3]  R2199     4.7367489337921143e-01
    z[7,8,3]  R2200     8.7103784084320068e-02
    z[7,8,3]  R2201     5.8222156763076782e-01
    z[7,8,3]  R2202     2.7179878950119019e-01
    z[7,8,3]  R2203     6.3187349587678909e-03
    z[7,8,3]  R2204     -2.4007922410964966e-01
    z[7,8,3]  R2205     1.7896729707717896e-01
    z[7,8,3]  R2206     1.1246153712272644e-01
    z[7,8,3]  R2207     0.343535453081131
    z[7,8,3]  R2208     -8.0852784216403961e-02
    z[7,8,3]  R2209     2.1543757990002632e-02
    z[7,8,3]  R2210     0.622757077217102
    z[7,8,3]  R2211     -3.6201027035713196e-01
    z[7,8,3]  R2212     -1.9956721365451813e-01
    z[7,8,3]  R2213     -2.0567707717418671e-01
    z[7,8,3]  R2214     -2.7525684237480164e-01
    z[7,8,3]  R2215     -3.0886083841323853e-01
    z[7,8,3]  R2216     -4.4544646143913269e-01
    z[7,8,3]  R2217     -3.0745381116867065e-01
    z[7,8,3]  R2218     -3.5966235399246216e-01
    z[7,8,3]  R2219     -1.7459464073181152e-01
    z[7,8,3]  R2220     1.3583010435104370e-01
    z[7,8,3]  R2221     -1.4307460188865662e-01
    z[7,8,3]  R2222     1.9094523787498474e-01
    z[7,8,3]  R2223     4.9552959203720093e-01
    z[7,8,3]  R2224     2.7962881326675415e-01
    z[7,8,3]  R2225     1.2235908955335617e-01
    z[7,8,3]  R2226     2.0566809177398682e-01
    z[7,8,3]  R2227     4.3316021561622620e-02
    z[7,8,3]  R2228     1.7639221623539925e-02
    z[7,8,3]  R2229     1.0946667194366455e-01
    z[7,8,3]  R2230     1.6150042647495866e-03
    z[7,8,3]  R2231     1.3374246656894684e-01
    z[7,8,3]  R2232     1.2629568576812744e-01
    z[7,8,3]  R2233     6.2102116644382477e-02
    z[7,8,3]  R2234     2.9491135478019714e-01
    z[7,8,3]  R2235     -2.6322089135646820e-02
    z[7,8,3]  R2236     7.1578072383999825e-03
    z[7,8,3]  R2237     2.1872717142105103e-01
    z[7,8,3]  R2238     -1.8175978958606720e-01
    z[7,8,3]  R2239     8.2140177488327026e-02
    z[7,8,3]  R2240     3.0320054292678833e-01
    z[7,8,3]  R2241     -8.5072226822376251e-02
    z[7,8,3]  R2242     -2.5293228030204773e-01
    z[7,8,3]  R2243     -7.7289357781410217e-02
    z[7,8,3]  R2244     2.6788532733917236e-01
    z[7,8,3]  R2245     4.0922960638999939e-01
    z[7,8,3]  R2246     1.0151887685060501e-01
    z[7,8,3]  R2247     -1.5011383593082428e-01
    z[7,8,3]  R2248     -3.7447098642587662e-02
    z[7,8,3]  R2249     3.4785076975822449e-01
    z[7,8,3]  R2250     5.0983697175979614e-01
    z[7,8,3]  R2251     -5.5340811610221863e-02
    z[7,8,3]  R2252     3.6104840040206909e-01
    z[7,8,3]  R2253     -1.1791817843914032e-01
    z[7,8,3]  R2254     -5.0834685564041138e-02
    z[7,8,3]  R2255     2.8743815422058105e-01
    z[7,8,3]  R2256     3.1195366382598877e-01
    z[7,8,3]  R2257     2.6422295719385147e-02
    z[7,8,3]  R2258     1.8366459012031555e-01
    z[7,8,3]  R2259     -3.5316757857799530e-02
    z[7,8,3]  R2260     1.1731790006160736e-01
    z[7,8,3]  R2261     2.8474060818552971e-02
    z[7,8,3]  R2262     3.2537961006164551e-01
    z[7,8,3]  R2263     2.8847834467887878e-01
    z[7,8,3]  R2264     2.3252607882022858e-01
    z[7,8,3]  R2265     2.4392794072628021e-01
    z[7,8,3]  R2266     2.9981240630149841e-01
    z[7,8,3]  R2267     5.4551732540130615e-01
    z[7,8,3]  R2268     5.8316290378570557e-01
    z[7,8,3]  R2269     4.9375861883163452e-02
    z[7,8,3]  R2270     -1.1125106364488602e-01
    z[7,8,4]  R69       -1
    z[7,8,4]  R78       1
    z[7,8,4]  R2149     -1
    z[7,8,4]  R2150     1
    z[7,8,4]  R2155     8.9499615132808685e-02
    z[7,8,4]  R2156     4.7331336885690689e-02
    z[7,8,4]  R2157     3.2973381876945496e-01
    z[7,8,4]  R2158     -3.3574157953262329e-01
    z[7,8,4]  R2159     -4.2432984709739685e-01
    z[7,8,4]  R2160     3.9872664213180542e-01
    z[7,8,4]  R2161     -5.3129500150680542e-01
    z[7,8,4]  R2162     -1.2451307475566864e-01
    z[7,8,4]  R2163     -2.4385261535644531e-01
    z[7,8,4]  R2164     5.1127278804779053e-01
    z[7,8,4]  R2165     -9.7215771675109863e-03
    z[7,8,4]  R2166     -3.6113986372947693e-01
    z[7,8,4]  R2167     -3.7307681050151587e-03
    z[7,8,4]  R2168     3.2739689946174622e-01
    z[7,8,4]  R2169     1.6731344163417816e-01
    z[7,8,4]  R2170     -4.4316089153289795e-01
    z[7,8,4]  R2171     -6.4428359270095825e-01
    z[7,8,4]  R2172     -4.4806912541389465e-01
    z[7,8,4]  R2173     4.5098461210727692e-02
    z[7,8,4]  R2174     -2.2722931206226349e-01
    z[7,8,4]  R2175     8.8432833552360535e-02
    z[7,8,4]  R2176     0.465313196182251
    z[7,8,4]  R2177     1.2860104441642761e-01
    z[7,8,4]  R2178     -3.3516031503677368e-01
    z[7,8,4]  R2179     -6.3609242439270020e-01
    z[7,8,4]  R2180     0.596617579460144
    z[7,8,4]  R2181     -1.7998097836971283e-01
    z[7,8,4]  R2182     -4.9788096547126770e-01
    z[7,8,4]  R2183     -5.6146466732025146e-01
    z[7,8,4]  R2184     1.4679694175720215e-01
    z[7,8,4]  R2185     -6.3950762152671814e-02
    z[7,8,4]  R2186     2.4879693984985352e-01
    z[7,8,4]  R2187     1.5833935141563416e-01
    z[7,8,4]  R2188     5.1392215490341187e-01
    z[7,8,4]  R2189     -3.7641230225563049e-01
    z[7,8,4]  R2190     0.379869282245636
    z[7,8,4]  R2191     9.6967279911041260e-02
    z[7,8,4]  R2192     1.0076423641294241e-03
    z[7,8,4]  R2193     2.0542123913764954e-01
    z[7,8,4]  R2194     -5.4098106920719147e-02
    z[7,8,4]  R2195     -2.7587391436100006e-02
    z[7,8,4]  R2196     -3.4771472215652466e-01
    z[7,8,4]  R2197     -3.8345164060592651e-01
    z[7,8,4]  R2198     3.8322802633047104e-02
    z[7,8,4]  R2199     -1.1859432607889175e-01
    z[7,8,4]  R2200     3.4360870718955994e-01
    z[7,8,4]  R2201     8.2579381763935089e-02
    z[7,8,4]  R2202     3.4066599607467651e-01
    z[7,8,4]  R2203     3.4818691015243530e-01
    z[7,8,4]  R2204     -3.2962700724601746e-01
    z[7,8,4]  R2205     -4.4653964042663574e-01
    z[7,8,4]  R2206     0.174747034907341
    z[7,8,4]  R2207     2.2072552144527435e-01
    z[7,8,4]  R2208     -6.0214113444089890e-02
    z[7,8,4]  R2209     8.6433209478855133e-02
    z[7,8,4]  R2210     -1.4656464755535126e-01
    z[7,8,4]  R2211     -2.6778010651469231e-02
    z[7,8,4]  R2212     3.5860094428062439e-01
    z[7,8,4]  R2213     1.4356791973114014e-01
    z[7,8,4]  R2214     3.2136055827140808e-01
    z[7,8,4]  R2215     -1.8034203350543976e-01
    z[7,8,4]  R2216     -1.2024753540754318e-01
    z[7,8,4]  R2217     2.7214720845222473e-01
    z[7,8,4]  R2218     2.1005927026271820e-01
    z[7,8,4]  R2219     2.6687526702880859e-01
    z[7,8,4]  R2220     7.2965443134307861e-01
    z[7,8,4]  R2221     -1.6865578293800354e-01
    z[7,8,4]  R2222     -3.6632204055786133e-01
    z[7,8,4]  R2223     2.3348139226436615e-01
    z[7,8,4]  R2224     -4.0672543644905090e-01
    z[7,8,4]  R2225     -4.8116365075111389e-01
    z[7,8,4]  R2226     -0.247926726937294
    z[7,8,4]  R2227     -2.0793950557708740e-01
    z[7,8,4]  R2228     -6.5966004133224487e-01
    z[7,8,4]  R2229     -2.0656064152717590e-01
    z[7,8,4]  R2230     -4.3522661924362183e-01
    z[7,8,4]  R2231     -1.4672678709030151e-01
    z[7,8,4]  R2232     1.9172701239585876e-01
    z[7,8,4]  R2233     -2.9065984487533569e-01
    z[7,8,4]  R2234     2.9688683152198792e-01
    z[7,8,4]  R2235     -3.5755434632301331e-01
    z[7,8,4]  R2236     2.1523140370845795e-01
    z[7,8,4]  R2237     4.4117426872253418e-01
    z[7,8,4]  R2238     -2.3671607673168182e-01
    z[7,8,4]  R2239     -3.1154295802116394e-01
    z[7,8,4]  R2240     5.4660546779632568e-01
    z[7,8,4]  R2241     1.2484390288591385e-01
    z[7,8,4]  R2242     -2.5522604584693909e-01
    z[7,8,4]  R2243     -3.5293996334075928e-01
    z[7,8,4]  R2244     1.3313040137290955e-01
    z[7,8,4]  R2245     3.5217371582984924e-01
    z[7,8,4]  R2246     4.2907809838652611e-03
    z[7,8,4]  R2247     -8.5193395614624023e-02
    z[7,8,4]  R2248     7.0026978850364685e-02
    z[7,8,4]  R2249     -2.9524338245391846e-01
    z[7,8,4]  R2250     -2.0597729086875916e-01
    z[7,8,4]  R2251     -3.7422144412994385e-01
    z[7,8,4]  R2252     0.00995348859578371
    z[7,8,4]  R2253     -1.3390763103961945e-01
    z[7,8,4]  R2254     -1.8794330954551697e-01
    z[7,8,4]  R2255     6.8049073219299316e-02
    z[7,8,4]  R2256     -7.9455800354480743e-02
    z[7,8,4]  R2257     -5.9384912252426147e-01
    z[7,8,4]  R2258     3.2085731625556946e-01
    z[7,8,4]  R2259     -6.0262900590896606e-01
    z[7,8,4]  R2260     -2.5845566391944885e-01
    z[7,8,4]  R2261     -1.5084058046340942e-01
    z[7,8,4]  R2262     1.3414281606674194e-01
    z[7,8,4]  R2263     -7.6363407075405121e-02
    z[7,8,4]  R2264     4.0686614811420441e-02
    z[7,8,4]  R2265     0.0765153020620346
    z[7,8,4]  R2266     -1.4057447016239166e-01
    z[7,8,4]  R2267     1.5660363435745239e-01
    z[7,8,4]  R2268     -1.1249816417694092e-01
    z[7,8,4]  R2269     7.6486356556415558e-02
    z[7,8,4]  R2270     4.5740908384323120e-01
    z[7,8,5]  R70       -1
    z[7,8,5]  R79       1
    z[7,8,5]  R2151     -1
    z[7,8,5]  R2152     1
    z[7,8,5]  R2155     2.5110411643981934e-01
    z[7,8,5]  R2156     -1.0927030444145203e-01
    z[7,8,5]  R2157     0.0615973100066185
    z[7,8,5]  R2158     6.1962729692459106e-01
    z[7,8,5]  R2159     4.3426585197448730e-01
    z[7,8,5]  R2160     3.0216521024703979e-01
    z[7,8,5]  R2161     3.0502077937126160e-01
    z[7,8,5]  R2162     -9.4746068120002747e-02
    z[7,8,5]  R2163     9.1737724840641022e-02
    z[7,8,5]  R2164     2.5821238756179810e-01
    z[7,8,5]  R2165     -4.9469181895256042e-01
    z[7,8,5]  R2166     -7.1768736839294434e-01
    z[7,8,5]  R2167     -4.4325152039527893e-01
    z[7,8,5]  R2168     1.5520103275775909e-01
    z[7,8,5]  R2169     -3.0298948287963867e-01
    z[7,8,5]  R2170     -4.3303561210632324e-01
    z[7,8,5]  R2171     -6.8086847662925720e-02
    z[7,8,5]  R2172     -4.3712366372346878e-02
    z[7,8,5]  R2173     -8.8271975517272949e-02
    z[7,8,5]  R2174     2.4261020123958588e-02
    z[7,8,5]  R2175     -8.1317991018295288e-02
    z[7,8,5]  R2176     3.1873297691345215e-01
    z[7,8,5]  R2177     0.493461012840271
    z[7,8,5]  R2178     0.0917491689324379
    z[7,8,5]  R2179     0.0384628064930439
    z[7,8,5]  R2180     -2.5385764241218567e-01
    z[7,8,5]  R2181     6.6737681627273560e-01
    z[7,8,5]  R2182     3.6219995468854904e-02
    z[7,8,5]  R2183     1.7828892171382904e-01
    z[7,8,5]  R2184     1.6482140123844147e-01
    z[7,8,5]  R2185     -4.6848282217979431e-01
    z[7,8,5]  R2186     2.8239700198173523e-01
    z[7,8,5]  R2187     2.3493885993957520e-01
    z[7,8,5]  R2188     -5.5758815258741379e-02
    z[7,8,5]  R2189     2.7847331762313843e-01
    z[7,8,5]  R2190     -0.278018981218338
    z[7,8,5]  R2191     1.0319099575281143e-01
    z[7,8,5]  R2192     1.1388929933309555e-01
    z[7,8,5]  R2193     -6.6204950213432312e-02
    z[7,8,5]  R2194     2.0312872529029846e-01
    z[7,8,5]  R2195     -1.8792280554771423e-01
    z[7,8,5]  R2196     -5.0165127962827682e-02
    z[7,8,5]  R2197     4.0426683425903320e-01
    z[7,8,5]  R2198     -3.4717744588851929e-01
    z[7,8,5]  R2199     -2.1615166962146759e-01
    z[7,8,5]  R2200     -2.1370968222618103e-01
    z[7,8,5]  R2201     9.8391756415367126e-02
    z[7,8,5]  R2202     3.8102051615715027e-01
    z[7,8,5]  R2203     8.0623924732208252e-02
    z[7,8,5]  R2204     1.5236005187034607e-01
    z[7,8,5]  R2205     1.7441053688526154e-01
    z[7,8,5]  R2206     -4.6163287013769150e-02
    z[7,8,5]  R2207     9.7324825823307037e-02
    z[7,8,5]  R2208     -2.6789653301239014e-01
    z[7,8,5]  R2209     1.7962953448295593e-01
    z[7,8,5]  R2210     -1.7342975735664368e-01
    z[7,8,5]  R2211     1.9142253696918488e-01
    z[7,8,5]  R2212     -8.3000678569078445e-03
    z[7,8,5]  R2213     2.2672009468078613e-01
    z[7,8,5]  R2214     1.7032565176486969e-01
    z[7,8,5]  R2215     1.7105570435523987e-01
    z[7,8,5]  R2216     1.1228091269731522e-01
    z[7,8,5]  R2217     1.4679941534996033e-01
    z[7,8,5]  R2218     3.5912382602691650e-01
    z[7,8,5]  R2219     6.0152035951614380e-01
    z[7,8,5]  R2220     2.2390134632587433e-01
    z[7,8,5]  R2221     -3.1453219056129456e-01
    z[7,8,5]  R2222     2.8494027256965637e-01
    z[7,8,5]  R2223     -2.5033742189407349e-01
    z[7,8,5]  R2224     -0.0385163351893425
    z[7,8,5]  R2225     3.2776869833469391e-02
    z[7,8,5]  R2226     -8.3212591707706451e-02
    z[7,8,5]  R2227     -3.6018621176481247e-02
    z[7,8,5]  R2228     4.1902983188629150e-01
    z[7,8,5]  R2229     0.0738268494606018
    z[7,8,5]  R2230     1.2479127198457718e-01
    z[7,8,5]  R2231     -1.9711649417877197e-01
    z[7,8,5]  R2232     3.1322799623012543e-02
    z[7,8,5]  R2233     1.9233305752277374e-01
    z[7,8,5]  R2234     9.2855080962181091e-02
    z[7,8,5]  R2235     -3.3176234364509583e-01
    z[7,8,5]  R2236     3.1827205419540405e-01
    z[7,8,5]  R2237     -3.6571016907691956e-01
    z[7,8,5]  R2238     -0.0894322618842125
    z[7,8,5]  R2239     -2.6702433824539185e-01
    z[7,8,5]  R2240     -6.9068334996700287e-03
    z[7,8,5]  R2241     -2.2181174159049988e-01
    z[7,8,5]  R2242     -6.7543298006057739e-02
    z[7,8,5]  R2243     3.3199369907379150e-01
    z[7,8,5]  R2244     2.7365097403526306e-01
    z[7,8,5]  R2245     -4.5686885714530945e-02
    z[7,8,5]  R2246     -5.0309556722640991e-01
    z[7,8,5]  R2247     1.7004017531871796e-01
    z[7,8,5]  R2248     -3.9104998111724854e-01
    z[7,8,5]  R2249     4.3170547485351562e-01
    z[7,8,5]  R2250     3.9537000656127930e-01
    z[7,8,5]  R2251     1.9739224016666412e-01
    z[7,8,5]  R2252     -1.0161225683987141e-02
    z[7,8,5]  R2253     -2.2046926617622375e-01
    z[7,8,5]  R2254     -1.1617458611726761e-01
    z[7,8,5]  R2255     -2.7370089292526245e-01
    z[7,8,5]  R2256     2.6169112324714661e-01
    z[7,8,5]  R2257     -3.1920078396797180e-01
    z[7,8,5]  R2258     -0.0718526765704155
    z[7,8,5]  R2259     -3.7679579108953476e-02
    z[7,8,5]  R2260     -1.6701023280620575e-01
    z[7,8,5]  R2261     1.8614935874938965e-01
    z[7,8,5]  R2262     9.3117326498031616e-02
    z[7,8,5]  R2263     2.7580955624580383e-01
    z[7,8,5]  R2264     5.5818080902099609e-01
    z[7,8,5]  R2265     3.9974045753479004e-01
    z[7,8,5]  R2266     2.8213381767272949e-01
    z[7,8,5]  R2267     5.1896089315414429e-01
    z[7,8,5]  R2268     3.3511513471603394e-01
    z[7,8,5]  R2269     7.2859209775924683e-01
    z[7,8,5]  R2270     1.1801747605204582e-02
    z[7,8,6]  R71       -1
    z[7,8,6]  R80       1
    z[7,8,6]  R2153     -1
    z[7,8,6]  R2154     1
    z[7,8,6]  R2155     -3.3257222175598145e-01
    z[7,8,6]  R2156     2.4919089674949646e-01
    z[7,8,6]  R2157     1.3880443572998047e-01
    z[7,8,6]  R2158     -1.9143719971179962e-01
    z[7,8,6]  R2159     4.7549134492874146e-01
    z[7,8,6]  R2160     -0.300910085439682
    z[7,8,6]  R2161     -4.4281458854675293e-01
    z[7,8,6]  R2162     2.9233753681182861e-01
    z[7,8,6]  R2163     -2.5748351216316223e-01
    z[7,8,6]  R2164     6.3702660799026489e-01
    z[7,8,6]  R2165     4.7362601757049561e-01
    z[7,8,6]  R2166     -0.0733075812458992
    z[7,8,6]  R2167     3.8052010536193848e-01
    z[7,8,6]  R2168     4.6648353338241577e-02
    z[7,8,6]  R2169     -1.7170476913452148e-01
    z[7,8,6]  R2170     2.5206971168518066e-01
    z[7,8,6]  R2171     -2.7114412188529968e-01
    z[7,8,6]  R2172     3.5158342123031616e-01
    z[7,8,6]  R2173     -9.3288779258728027e-02
    z[7,8,6]  R2174     5.0532564520835876e-02
    z[7,8,6]  R2175     -2.9479971528053284e-01
    z[7,8,6]  R2176     3.5192602872848511e-01
    z[7,8,6]  R2177     8.4343627095222473e-02
    z[7,8,6]  R2178     2.2997410595417023e-01
    z[7,8,6]  R2179     1.0663776844739914e-01
    z[7,8,6]  R2180     4.0431201457977295e-01
    z[7,8,6]  R2181     -1.2665948271751404e-01
    z[7,8,6]  R2182     2.4457333981990814e-01
    z[7,8,6]  R2183     -2.0126027986407280e-02
    z[7,8,6]  R2184     3.0705055594444275e-01
    z[7,8,6]  R2185     2.3841249942779541e-01
    z[7,8,6]  R2186     -2.6274269819259644e-01
    z[7,8,6]  R2187     -2.1397694945335388e-01
    z[7,8,6]  R2188     -9.7718074917793274e-02
    z[7,8,6]  R2189     2.1014584600925446e-01
    z[7,8,6]  R2190     -6.7001514136791229e-02
    z[7,8,6]  R2191     -1.4330537617206573e-01
    z[7,8,6]  R2192     -2.8399093076586723e-02
    z[7,8,6]  R2193     -1.6327325999736786e-01
    z[7,8,6]  R2194     1.0520142316818237e-01
    z[7,8,6]  R2195     1.3809648156166077e-01
    z[7,8,6]  R2196     7.0091497898101807e-01
    z[7,8,6]  R2197     3.8709127902984619e-01
    z[7,8,6]  R2198     5.9288042783737183e-01
    z[7,8,6]  R2199     -7.7191629679873586e-04
    z[7,8,6]  R2200     1.5890252590179443e-01
    z[7,8,6]  R2201     1.9742861390113831e-01
    z[7,8,6]  R2202     6.8271338939666748e-02
    z[7,8,6]  R2203     -3.7137228250503540e-01
    z[7,8,6]  R2204     2.0336598157882690e-01
    z[7,8,6]  R2205     4.4109782576560974e-01
    z[7,8,6]  R2206     -2.6941576600074768e-01
    z[7,8,6]  R2207     1.1533229053020477e-01
    z[7,8,6]  R2208     -2.2734068334102631e-01
    z[7,8,6]  R2209     -2.1608080714941025e-02
    z[7,8,6]  R2210     2.1889238059520721e-01
    z[7,8,6]  R2211     9.5573388040065765e-02
    z[7,8,6]  R2212     -0.00667816074565053
    z[7,8,6]  R2213     8.5651800036430359e-02
    z[7,8,6]  R2214     -4.6514865010976791e-02
    z[7,8,6]  R2215     4.4298145920038223e-02
    z[7,8,6]  R2216     -1.6526412963867188e-01
    z[7,8,6]  R2217     -8.2540504634380341e-02
    z[7,8,6]  R2218     -4.0713074803352356e-01
    z[7,8,6]  R2219     1.9813652336597443e-01
    z[7,8,6]  R2220     0.0846172571182251
    z[7,8,6]  R2221     -6.6600787639617920e-01
    z[7,8,6]  R2222     6.8968725204467773e-01
    z[7,8,6]  R2223     4.7490417957305908e-01
    z[7,8,6]  R2224     -3.8561765104532242e-02
    z[7,8,6]  R2225     0.0684349462389946
    z[7,8,6]  R2226     4.2259924113750458e-02
    z[7,8,6]  R2227     2.1167999505996704e-01
    z[7,8,6]  R2228     -3.7862819153815508e-03
    z[7,8,6]  R2229     -1.4978150138631463e-03
    z[7,8,6]  R2230     2.1710345149040222e-01
    z[7,8,6]  R2231     4.1864126920700073e-02
    z[7,8,6]  R2232     -1.5669718384742737e-02
    z[7,8,6]  R2233     -1.4252914488315582e-01
    z[7,8,6]  R2234     2.5085920095443726e-01
    z[7,8,6]  R2235     -1.4304542541503906e-01
    z[7,8,6]  R2236     -4.8893624544143677e-01
    z[7,8,6]  R2237     8.6534790694713593e-02
    z[7,8,6]  R2238     -2.7721837162971497e-01
    z[7,8,6]  R2239     5.4862993955612183e-01
    z[7,8,6]  R2240     -2.4678014218807220e-01
    z[7,8,6]  R2241     -3.0206772685050964e-01
    z[7,8,6]  R2242     -1.4944548904895782e-01
    z[7,8,6]  R2243     -1.8581999838352203e-01
    z[7,8,6]  R2244     3.8092538714408875e-01
    z[7,8,6]  R2245     4.7314144670963287e-02
    z[7,8,6]  R2246     -2.9051521420478821e-01
    z[7,8,6]  R2247     -5.1917988061904907e-01
    z[7,8,6]  R2248     -2.5268509984016418e-02
    z[7,8,6]  R2249     6.8412572145462036e-02
    z[7,8,6]  R2250     -4.0220993757247925e-01
    z[7,8,6]  R2251     -1.0235381871461868e-01
    z[7,8,6]  R2252     1.0922455042600632e-01
    z[7,8,6]  R2253     2.1418869495391846e-01
    z[7,8,6]  R2254     -4.9310860037803650e-01
    z[7,8,6]  R2255     -3.3329862356185913e-01
    z[7,8,6]  R2256     -4.9258375167846680e-01
    z[7,8,6]  R2257     9.8725304007530212e-02
    z[7,8,6]  R2258     -1.6802644729614258e-01
    z[7,8,6]  R2259     -1.6861614584922791e-01
    z[7,8,6]  R2260     -0.218696728348732
    z[7,8,6]  R2261     -2.1060292422771454e-01
    z[7,8,6]  R2262     -6.7212447524070740e-02
    z[7,8,6]  R2263     -2.0458398386836052e-02
    z[7,8,6]  R2264     -5.2033051848411560e-02
    z[7,8,6]  R2265     1.4600904285907745e-01
    z[7,8,6]  R2266     -3.9462402462959290e-01
    z[7,8,6]  R2267     0.00793476216495037
    z[7,8,6]  R2268     -2.1063642203807831e-01
    z[7,8,6]  R2269     2.5378491729497910e-02
    z[7,8,6]  R2270     6.3474170863628387e-02
    z[8,7,0]  R65       1
    z[8,7,0]  R74       -1
    z[8,7,0]  R2271     -1
    z[8,7,0]  R2272     1
    z[8,7,0]  R2285     -8.2706409692764282e-01
    z[8,7,0]  R2286     -9.1056984663009644e-01
    z[8,7,0]  R2287     -0.896411120891571
    z[8,7,0]  R2288     -7.7990359067916870e-01
    z[8,7,0]  R2289     -8.9173072576522827e-01
    z[8,7,0]  R2290     -8.0726486444473267e-01
    z[8,7,0]  R2291     -7.5758165121078491e-01
    z[8,7,0]  R2292     -6.9680100679397583e-01
    z[8,7,0]  R2293     -6.8020689487457275e-01
    z[8,7,0]  R2294     8.8735990226268768e-02
    z[8,7,0]  R2295     4.9224663525819778e-02
    z[8,7,0]  R2296     3.1487852334976196e-01
    z[8,7,0]  R2297     3.5001170635223389e-01
    z[8,7,0]  R2298     3.3615925908088684e-01
    z[8,7,0]  R2299     2.7263092994689941e-01
    z[8,7,0]  R2300     2.4038107693195343e-01
    z[8,7,0]  R2301     3.2954993844032288e-01
    z[8,7,0]  R2302     2.7537909150123596e-01
    z[8,7,0]  R2303     4.1178759932518005e-01
    z[8,7,0]  R2304     0.595511794090271
    z[8,7,0]  R2305     -0.0982019230723381
    z[8,7,0]  R2306     2.6607644557952881e-01
    z[8,7,0]  R2307     1.4676716923713684e-01
    z[8,7,0]  R2308     1.4686042070388794e-01
    z[8,7,0]  R2309     1.1764391511678696e-01
    z[8,7,0]  R2310     -4.9060784280300140e-02
    z[8,7,0]  R2311     -1.3944949209690094e-01
    z[8,7,0]  R2312     -3.4394964575767517e-01
    z[8,7,0]  R2313     -1.0979624092578888e-01
    z[8,7,0]  R2314     1.1869938671588898e-01
    z[8,7,0]  R2315     -2.8038039803504944e-01
    z[8,7,0]  R2316     1.5873451530933380e-01
    z[8,7,0]  R2317     3.6990955471992493e-02
    z[8,7,0]  R2318     1.4406321942806244e-01
    z[8,7,0]  R2319     9.2446029186248779e-02
    z[8,7,0]  R2320     1.0045155882835388e-01
    z[8,7,0]  R2321     2.3465298116207123e-01
    z[8,7,0]  R2322     1.7545820772647858e-01
    z[8,7,0]  R2323     -4.4613018631935120e-02
    z[8,7,0]  R2324     -4.5370548963546753e-02
    z[8,7,0]  R2325     1.1342381127178669e-02
    z[8,7,0]  R2326     0.00920828152447939
    z[8,7,0]  R2327     1.2489434331655502e-01
    z[8,7,0]  R2328     2.1298396587371826e-01
    z[8,7,0]  R2329     7.2609391063451767e-03
    z[8,7,0]  R2330     1.0130155831575394e-02
    z[8,7,0]  R2331     3.2253018021583557e-01
    z[8,7,0]  R2332     6.7334115505218506e-01
    z[8,7,0]  R2333     0.282462477684021
    z[8,7,0]  R2334     3.3619120717048645e-01
    z[8,7,0]  R2335     7.9640835523605347e-01
    z[8,7,0]  R2336     9.1283661127090454e-01
    z[8,7,0]  R2337     8.2904303073883057e-01
    z[8,7,0]  R2338     7.7248513698577881e-01
    z[8,7,0]  R2339     2.1900284290313721e-01
    z[8,7,0]  R2340     7.6090240478515625e-01
    z[8,7,0]  R2341     0.59315025806427
    z[8,7,0]  R2342     5.6900697946548462e-01
    z[8,7,0]  R2343     4.3024361133575439e-01
    z[8,7,0]  R2344     5.2603250741958618e-01
    z[8,7,0]  R2345     1.5107576549053192e-01
    z[8,7,0]  R2346     1.9000087678432465e-01
    z[8,7,0]  R2347     2.4899569153785706e-01
    z[8,7,0]  R2348     1.8969222903251648e-01
    z[8,7,0]  R2349     7.6405808329582214e-02
    z[8,7,0]  R2350     2.0453310012817383e-01
    z[8,7,0]  R2351     2.9127034544944763e-01
    z[8,7,0]  R2352     -5.3835548460483551e-03
    z[8,7,0]  R2353     0.0112368268892169
    z[8,7,0]  R2354     1.9862614572048187e-01
    z[8,7,0]  R2355     6.4337074756622314e-01
    z[8,7,0]  R2356     5.5937623977661133e-01
    z[8,7,0]  R2357     5.6334191560745239e-01
    z[8,7,0]  R2358     4.1311725974082947e-01
    z[8,7,0]  R2359     5.8645331859588623e-01
    z[8,7,0]  R2360     -2.0132945477962494e-01
    z[8,7,0]  R2361     -3.8083148002624512e-01
    z[8,7,0]  R2362     -5.1675987243652344e-01
    z[8,7,0]  R2363     -9.3736845254898071e-01
    z[8,7,0]  R2364     -9.4241410493850708e-01
    z[8,7,0]  R2365     6.3418996334075928e-01
    z[8,7,0]  R2366     3.3805477619171143e-01
    z[8,7,0]  R2367     7.0690816640853882e-01
    z[8,7,0]  R2368     0.77171391248703
    z[8,7,0]  R2369     0.097800612449646
    z[8,7,0]  R2370     1.4096279442310333e-01
    z[8,7,0]  R2371     2.3734317719936371e-01
    z[8,7,0]  R2372     4.0585020184516907e-01
    z[8,7,0]  R2373     3.3952784538269043e-01
    z[8,7,0]  R2374     -0.0949232280254364
    z[8,7,0]  R2375     -4.1349551081657410e-01
    z[8,7,0]  R2376     -3.4606429934501648e-01
    z[8,7,0]  R2377     -3.3707737922668457e-01
    z[8,7,0]  R2378     -1.8754664063453674e-01
    z[8,7,0]  R2379     1.0538776963949203e-01
    z[8,7,0]  R2380     -2.3383601009845734e-01
    z[8,7,0]  R2381     -5.1879596710205078e-01
    z[8,7,0]  R2382     -2.7531775832176208e-01
    z[8,7,0]  R2383     -5.7779371738433838e-01
    z[8,7,0]  R2384     -1.0655597597360611e-01
    z[8,7,0]  R2385     2.6284253597259521e-01
    z[8,7,0]  R2386     0.26040118932724
    z[8,7,0]  R2387     1.4025020599365234e-01
    z[8,7,0]  R2388     2.2039799392223358e-01
    z[8,7,0]  R2389     -1.2962000072002411e-01
    z[8,7,0]  R2390     -1.1158938705921173e-01
    z[8,7,0]  R2391     4.7225572168827057e-02
    z[8,7,0]  R2392     -1.7873022705316544e-02
    z[8,7,0]  R2393     -2.9024323821067810e-01
    z[8,7,0]  R2394     -5.0971823930740356e-01
    z[8,7,0]  R2395     2.9222929477691650e-01
    z[8,7,0]  R2396     8.4249682724475861e-02
    z[8,7,0]  R2397     1.5272390842437744e-01
    z[8,7,0]  R2398     -5.0775593519210815e-01
    z[8,7,0]  R2399     -7.0655876398086548e-01
    z[8,7,0]  R2400     -4.1153064370155334e-01
    z[8,7,1]  R66       1
    z[8,7,1]  R75       -1
    z[8,7,1]  R2273     -1
    z[8,7,1]  R2274     1
    z[8,7,1]  R2285     -3.8884587585926056e-02
    z[8,7,1]  R2286     -2.8132705017924309e-02
    z[8,7,1]  R2287     1.3578535616397858e-01
    z[8,7,1]  R2288     -8.7959386408329010e-02
    z[8,7,1]  R2289     0.0275983028113842
    z[8,7,1]  R2290     0.268432080745697
    z[8,7,1]  R2291     4.5238915085792542e-01
    z[8,7,1]  R2292     2.9841421172022820e-02
    z[8,7,1]  R2293     1.1943578720092773e-01
    z[8,7,1]  R2294     -8.0063328146934509e-02
    z[8,7,1]  R2295     -6.2669318914413452e-01
    z[8,7,1]  R2296     -3.9516237378120422e-01
    z[8,7,1]  R2297     -3.8031238317489624e-01
    z[8,7,1]  R2298     7.9426276683807373e-01
    z[8,7,1]  R2299     8.2045537233352661e-01
    z[8,7,1]  R2300     8.8006341457366943e-01
    z[8,7,1]  R2301     8.8734275102615356e-01
    z[8,7,1]  R2302     -3.7226536870002747e-01
    z[8,7,1]  R2303     8.6910420656204224e-01
    z[8,7,1]  R2304     -2.3682117462158203e-01
    z[8,7,1]  R2305     -9.3146163225173950e-01
    z[8,7,1]  R2306     -7.6777690649032593e-01
    z[8,7,1]  R2307     -9.0915805101394653e-01
    z[8,7,1]  R2308     -8.3823961019515991e-01
    z[8,7,1]  R2309     -0.82839035987854
    z[8,7,1]  R2310     -0.780409038066864
    z[8,7,1]  R2311     -7.5964945554733276e-01
    z[8,7,1]  R2312     -8.2713586091995239e-01
    z[8,7,1]  R2313     -6.8862271308898926e-01
    z[8,7,1]  R2314     -7.0851981639862061e-01
    z[8,7,1]  R2315     -8.1212782859802246e-01
    z[8,7,1]  R2316     8.8121265172958374e-01
    z[8,7,1]  R2317     8.4028065204620361e-01
    z[8,7,1]  R2318     7.6849848031997681e-01
    z[8,7,1]  R2319     8.1701892614364624e-01
    z[8,7,1]  R2320     7.8537470102310181e-01
    z[8,7,1]  R2321     0.756335437297821
    z[8,7,1]  R2322     6.2838083505630493e-01
    z[8,7,1]  R2323     4.9951234459877014e-01
    z[8,7,1]  R2324     5.2126449346542358e-01
    z[8,7,1]  R2325     8.6326146125793457e-01
    z[8,7,1]  R2326     9.1128599643707275e-01
    z[8,7,1]  R2327     8.3672732114791870e-01
    z[8,7,1]  R2328     8.1179004907608032e-01
    z[8,7,1]  R2329     7.5844889879226685e-01
    z[8,7,1]  R2330     5.5628603696823120e-01
    z[8,7,1]  R2331     4.1705000400543213e-01
    z[8,7,1]  R2332     6.1076825857162476e-01
    z[8,7,1]  R2333     3.4541657567024231e-01
    z[8,7,1]  R2334     3.7452796101570129e-01
    z[8,7,1]  R2335     4.6728920936584473e-01
    z[8,7,1]  R2336     1.5661269426345825e-01
    z[8,7,1]  R2337     2.0572523772716522e-01
    z[8,7,1]  R2338     1.5655416250228882e-01
    z[8,7,1]  R2339     4.1292944550514221e-01
    z[8,7,1]  R2340     1.3044695556163788e-01
    z[8,7,1]  R2341     2.1109478175640106e-01
    z[8,7,1]  R2342     1.3563109934329987e-01
    z[8,7,1]  R2343     5.2235114574432373e-01
    z[8,7,1]  R2344     3.5238561034202576e-01
    z[8,7,1]  R2345     -0.483767032623291
    z[8,7,1]  R2346     -0.433219313621521
    z[8,7,1]  R2347     -3.7000021338462830e-01
    z[8,7,1]  R2348     -4.3177920579910278e-01
    z[8,7,1]  R2349     -5.0468832254409790e-01
    z[8,7,1]  R2350     -3.3606818318367004e-01
    z[8,7,1]  R2351     -2.2872298955917358e-01
    z[8,7,1]  R2352     8.6079066991806030e-01
    z[8,7,1]  R2353     0.921334445476532
    z[8,7,1]  R2354     -2.2989258170127869e-01
    z[8,7,1]  R2355     -6.9852188229560852e-02
    z[8,7,1]  R2356     -8.2686953246593475e-02
    z[8,7,1]  R2357     -1.4327128231525421e-01
    z[8,7,1]  R2358     -6.7116126418113708e-02
    z[8,7,1]  R2359     -8.6113018915057182e-04
    z[8,7,1]  R2360     6.7343002557754517e-01
    z[8,7,1]  R2361     5.8207976818084717e-01
    z[8,7,1]  R2362     6.3580900430679321e-01
    z[8,7,1]  R2363     5.4047949612140656e-02
    z[8,7,1]  R2364     4.9451023340225220e-02
    z[8,7,1]  R2365     -7.0346224308013916e-01
    z[8,7,1]  R2366     -5.1667302846908569e-01
    z[8,7,1]  R2367     -2.2671933472156525e-01
    z[8,7,1]  R2368     -1.6377186775207520e-01
    z[8,7,1]  R2369     -5.9961438179016113e-01
    z[8,7,1]  R2370     -4.7854939103126526e-01
    z[8,7,1]  R2371     -3.2761031389236450e-01
    z[8,7,1]  R2372     -2.9142358899116516e-01
    z[8,7,1]  R2373     -2.5573647022247314e-01
    z[8,7,1]  R2374     5.7698541879653931e-01
    z[8,7,1]  R2375     6.5377980470657349e-01
    z[8,7,1]  R2376     6.3390594720840454e-01
    z[8,7,1]  R2377     6.7765879631042480e-01
    z[8,7,1]  R2378     7.2343409061431885e-01
    z[8,7,1]  R2379     6.4129769802093506e-01
    z[8,7,1]  R2380     8.2109671831130981e-01
    z[8,7,1]  R2381     7.9056274890899658e-01
    z[8,7,1]  R2382     4.8545023798942566e-01
    z[8,7,1]  R2383     5.5226039886474609e-01
    z[8,7,1]  R2384     7.0540577173233032e-01
    z[8,7,1]  R2385     -7.0736521482467651e-01
    z[8,7,1]  R2386     -5.4311233758926392e-01
    z[8,7,1]  R2387     -6.0203611850738525e-01
    z[8,7,1]  R2388     -5.6805652379989624e-01
    z[8,7,1]  R2389     7.8660231828689575e-01
    z[8,7,1]  R2390     6.4276885986328125e-01
    z[8,7,1]  R2391     6.0280239582061768e-01
    z[8,7,1]  R2392     8.1228846311569214e-01
    z[8,7,1]  R2393     0.805886447429657
    z[8,7,1]  R2394     6.9819837808609009e-01
    z[8,7,1]  R2395     -6.7314684391021729e-01
    z[8,7,1]  R2396     8.0872654914855957e-01
    z[8,7,1]  R2397     8.1183636188507080e-01
    z[8,7,1]  R2398     5.8985030651092529e-01
    z[8,7,1]  R2399     4.3527165055274963e-01
    z[8,7,1]  R2400     5.8477109670639038e-01
    z[8,7,2]  R67       1
    z[8,7,2]  R76       -1
    z[8,7,2]  R2275     -1
    z[8,7,2]  R2276     1
    z[8,7,2]  R2285     3.7001019716262817e-01
    z[8,7,2]  R2286     3.9191324263811111e-02
    z[8,7,2]  R2287     -2.3739559948444366e-01
    z[8,7,2]  R2288     4.1689342260360718e-01
    z[8,7,2]  R2289     -2.1192955970764160e-01
    z[8,7,2]  R2290     1.5318708121776581e-01
    z[8,7,2]  R2291     1.5639486908912659e-01
    z[8,7,2]  R2292     2.1300381422042847e-01
    z[8,7,2]  R2293     1.4234852790832520e-01
    z[8,7,2]  R2294     6.1447417736053467e-01
    z[8,7,2]  R2295     1.1584693938493729e-01
    z[8,7,2]  R2296     1.3109819591045380e-01
    z[8,7,2]  R2297     -3.8024783134460449e-01
    z[8,7,2]  R2298     9.7751110792160034e-02
    z[8,7,2]  R2299     1.6658306121826172e-02
    z[8,7,2]  R2300     -2.3500657081604004e-01
    z[8,7,2]  R2301     -1.1313124746084213e-01
    z[8,7,2]  R2302     -4.1775825619697571e-01
    z[8,7,2]  R2303     1.2241696566343307e-01
    z[8,7,2]  R2304     5.8064609766006470e-01
    z[8,7,2]  R2305     -2.0666979253292084e-01
    z[8,7,2]  R2306     5.3458905220031738e-01
    z[8,7,2]  R2307     -7.9022668302059174e-02
    z[8,7,2]  R2308     1.7064422369003296e-01
    z[8,7,2]  R2309     2.0214636623859406e-01
    z[8,7,2]  R2310     4.2698092758655548e-02
    z[8,7,2]  R2311     1.4063432812690735e-01
    z[8,7,2]  R2312     1.5370629727840424e-01
    z[8,7,2]  R2313     1.9401220977306366e-01
    z[8,7,2]  R2314     -1.7959360778331757e-01
    z[8,7,2]  R2315     3.1395298242568970e-01
    z[8,7,2]  R2316     2.0556405186653137e-01
    z[8,7,2]  R2317     1.3141946494579315e-01
    z[8,7,2]  R2318     2.8139057755470276e-01
    z[8,7,2]  R2319     0.167667955160141
    z[8,7,2]  R2320     1.5895701944828033e-01
    z[8,7,2]  R2321     -2.1128481626510620e-01
    z[8,7,2]  R2322     6.4380693435668945e-01
    z[8,7,2]  R2323     5.9099775552749634e-01
    z[8,7,2]  R2324     3.2522940635681152e-01
    z[8,7,2]  R2325     2.4921227991580963e-01
    z[8,7,2]  R2326     0.164270281791687
    z[8,7,2]  R2327     3.9745372533798218e-01
    z[8,7,2]  R2328     3.2791949808597565e-02
    z[8,7,2]  R2329     3.8916710019111633e-01
    z[8,7,2]  R2330     5.2506572008132935e-01
    z[8,7,2]  R2331     -0.507003664970398
    z[8,7,2]  R2332     5.9127245098352432e-02
    z[8,7,2]  R2333     -6.3768506050109863e-01
    z[8,7,2]  R2334     -7.6838845014572144e-01
    z[8,7,2]  R2335     2.1167370676994324e-01
    z[8,7,2]  R2336     -7.1744740009307861e-02
    z[8,7,2]  R2337     -3.2376566529273987e-01
    z[8,7,2]  R2338     -9.3596793711185455e-02
    z[8,7,2]  R2339     -7.3147827386856079e-01
    z[8,7,2]  R2340     -2.4297079443931580e-01
    z[8,7,2]  R2341     -1.1006604135036469e-01
    z[8,7,2]  R2342     -3.8526695966720581e-01
    z[8,7,2]  R2343     4.7550402581691742e-02
    z[8,7,2]  R2344     -6.1102062463760376e-01
    z[8,7,2]  R2345     7.4862468242645264e-01
    z[8,7,2]  R2346     4.5391109585762024e-01
    z[8,7,2]  R2347     4.2123979330062866e-01
    z[8,7,2]  R2348     -9.6825070679187775e-02
    z[8,7,2]  R2349     1.4415211975574493e-01
    z[8,7,2]  R2350     0.199151411652565
    z[8,7,2]  R2351     1.7901813983917236e-01
    z[8,7,2]  R2352     3.8354527950286865e-01
    z[8,7,2]  R2353     1.2844632565975189e-01
    z[8,7,2]  R2354     3.9112526178359985e-01
    z[8,7,2]  R2355     -3.3422163128852844e-01
    z[8,7,2]  R2356     -1.7012690007686615e-01
    z[8,7,2]  R2357     -5.6111729145050049e-01
    z[8,7,2]  R2358     -0.808626651763916
    z[8,7,2]  R2359     -6.7720323801040649e-01
    z[8,7,2]  R2360     -1.4237721264362335e-01
    z[8,7,2]  R2361     1.2527535855770111e-01
    z[8,7,2]  R2362     1.9976699259132147e-03
    z[8,7,2]  R2363     -1.3049748539924622e-01
    z[8,7,2]  R2364     4.6185430139303207e-02
    z[8,7,2]  R2365     -3.9144292473793030e-02
    z[8,7,2]  R2366     -4.1362863779067993e-01
    z[8,7,2]  R2367     3.1486144661903381e-01
    z[8,7,2]  R2368     -2.1168076992034912e-01
    z[8,7,2]  R2369     4.6035799384117126e-01
    z[8,7,2]  R2370     4.0834966301918030e-01
    z[8,7,2]  R2371     -5.7198524475097656e-01
    z[8,7,2]  R2372     -3.8558465242385864e-01
    z[8,7,2]  R2373     -4.9281004071235657e-01
    z[8,7,2]  R2374     7.1240466833114624e-01
    z[8,7,2]  R2375     2.7471417188644409e-01
    z[8,7,2]  R2376     2.7431827783584595e-01
    z[8,7,2]  R2377     5.3992801904678345e-01
    z[8,7,2]  R2378     5.5345781147480011e-02
    z[8,7,2]  R2379     3.6369696259498596e-01
    z[8,7,2]  R2380     -1.2399200350046158e-01
    z[8,7,2]  R2381     -4.8644639551639557e-02
    z[8,7,2]  R2382     4.3958729505538940e-01
    z[8,7,2]  R2383     4.8620536923408508e-01
    z[8,7,2]  R2384     -8.3687163889408112e-02
    z[8,7,2]  R2385     5.4461705684661865e-01
    z[8,7,2]  R2386     1.1568053066730499e-01
    z[8,7,2]  R2387     -1.1416072398424149e-01
    z[8,7,2]  R2388     3.1054908037185669e-01
    z[8,7,2]  R2389     2.8160366415977478e-01
    z[8,7,2]  R2390     6.1467081308364868e-01
    z[8,7,2]  R2391     4.8983544111251831e-01
    z[8,7,2]  R2392     1.0121591389179230e-02
    z[8,7,2]  R2393     2.4785617366433144e-02
    z[8,7,2]  R2394     -1.4779375493526459e-01
    z[8,7,2]  R2395     -7.1148402988910675e-02
    z[8,7,2]  R2396     4.7006741166114807e-01
    z[8,7,2]  R2397     0.357892245054245
    z[8,7,2]  R2398     5.1053434610366821e-01
    z[8,7,2]  R2399     5.2023524045944214e-01
    z[8,7,2]  R2400     -0.0372295156121254
    z[8,7,3]  R68       1
    z[8,7,3]  R77       -1
    z[8,7,3]  R2277     -1
    z[8,7,3]  R2278     1
    z[8,7,3]  R2285     -3.6201027035713196e-01
    z[8,7,3]  R2286     -1.9956721365451813e-01
    z[8,7,3]  R2287     -2.0567707717418671e-01
    z[8,7,3]  R2288     -2.7525684237480164e-01
    z[8,7,3]  R2289     -3.0886083841323853e-01
    z[8,7,3]  R2290     -4.4544646143913269e-01
    z[8,7,3]  R2291     -3.0745381116867065e-01
    z[8,7,3]  R2292     -3.5966235399246216e-01
    z[8,7,3]  R2293     -1.7459464073181152e-01
    z[8,7,3]  R2294     1.3583010435104370e-01
    z[8,7,3]  R2295     -1.4307460188865662e-01
    z[8,7,3]  R2296     1.9094523787498474e-01
    z[8,7,3]  R2297     4.9552959203720093e-01
    z[8,7,3]  R2298     2.7962881326675415e-01
    z[8,7,3]  R2299     1.2235908955335617e-01
    z[8,7,3]  R2300     2.0566809177398682e-01
    z[8,7,3]  R2301     4.3316021561622620e-02
    z[8,7,3]  R2302     1.7639221623539925e-02
    z[8,7,3]  R2303     1.0946667194366455e-01
    z[8,7,3]  R2304     1.6150042647495866e-03
    z[8,7,3]  R2305     1.3374246656894684e-01
    z[8,7,3]  R2306     1.2629568576812744e-01
    z[8,7,3]  R2307     6.2102116644382477e-02
    z[8,7,3]  R2308     2.9491135478019714e-01
    z[8,7,3]  R2309     -2.6322089135646820e-02
    z[8,7,3]  R2310     7.1578072383999825e-03
    z[8,7,3]  R2311     2.1872717142105103e-01
    z[8,7,3]  R2312     -1.8175978958606720e-01
    z[8,7,3]  R2313     8.2140177488327026e-02
    z[8,7,3]  R2314     3.0320054292678833e-01
    z[8,7,3]  R2315     -8.5072226822376251e-02
    z[8,7,3]  R2316     -2.5293228030204773e-01
    z[8,7,3]  R2317     -7.7289357781410217e-02
    z[8,7,3]  R2318     2.6788532733917236e-01
    z[8,7,3]  R2319     4.0922960638999939e-01
    z[8,7,3]  R2320     1.0151887685060501e-01
    z[8,7,3]  R2321     -1.5011383593082428e-01
    z[8,7,3]  R2322     -3.7447098642587662e-02
    z[8,7,3]  R2323     3.4785076975822449e-01
    z[8,7,3]  R2324     5.0983697175979614e-01
    z[8,7,3]  R2325     -5.5340811610221863e-02
    z[8,7,3]  R2326     3.6104840040206909e-01
    z[8,7,3]  R2327     -1.1791817843914032e-01
    z[8,7,3]  R2328     -5.0834685564041138e-02
    z[8,7,3]  R2329     2.8743815422058105e-01
    z[8,7,3]  R2330     3.1195366382598877e-01
    z[8,7,3]  R2331     2.6422295719385147e-02
    z[8,7,3]  R2332     1.8366459012031555e-01
    z[8,7,3]  R2333     -3.5316757857799530e-02
    z[8,7,3]  R2334     1.1731790006160736e-01
    z[8,7,3]  R2335     2.8474060818552971e-02
    z[8,7,3]  R2336     3.2537961006164551e-01
    z[8,7,3]  R2337     2.8847834467887878e-01
    z[8,7,3]  R2338     2.3252607882022858e-01
    z[8,7,3]  R2339     2.4392794072628021e-01
    z[8,7,3]  R2340     2.9981240630149841e-01
    z[8,7,3]  R2341     5.4551732540130615e-01
    z[8,7,3]  R2342     5.8316290378570557e-01
    z[8,7,3]  R2343     4.9375861883163452e-02
    z[8,7,3]  R2344     -1.1125106364488602e-01
    z[8,7,3]  R2345     -3.2232973724603653e-02
    z[8,7,3]  R2346     -7.0278668403625488e-01
    z[8,7,3]  R2347     7.0133650302886963e-01
    z[8,7,3]  R2348     -4.8466470837593079e-01
    z[8,7,3]  R2349     3.5204750299453735e-01
    z[8,7,3]  R2350     -6.8171066045761108e-01
    z[8,7,3]  R2351     5.0931614637374878e-01
    z[8,7,3]  R2352     -4.4291362166404724e-02
    z[8,7,3]  R2353     -1.8455622717738152e-02
    z[8,7,3]  R2354     -1.4436677098274231e-01
    z[8,7,3]  R2355     -1.8831750378012657e-02
    z[8,7,3]  R2356     2.1138250827789307e-02
    z[8,7,3]  R2357     7.7364087104797363e-02
    z[8,7,3]  R2358     1.9364996254444122e-01
    z[8,7,3]  R2359     2.1951900422573090e-01
    z[8,7,3]  R2360     -1.9554218649864197e-01
    z[8,7,3]  R2361     8.4854386746883392e-02
    z[8,7,3]  R2362     4.9137137830257416e-02
    z[8,7,3]  R2363     -2.8785604238510132e-01
    z[8,7,3]  R2364     -2.2913314402103424e-01
    z[8,7,3]  R2365     8.4756435826420784e-03
    z[8,7,3]  R2366     7.5632624328136444e-02
    z[8,7,3]  R2367     -2.8737723827362061e-01
    z[8,7,3]  R2368     3.9898529648780823e-01
    z[8,7,3]  R2369     3.8776386529207230e-02
    z[8,7,3]  R2370     -2.2496329620480537e-02
    z[8,7,3]  R2371     1.2387485057115555e-01
    z[8,7,3]  R2372     -5.4098880290985107e-01
    z[8,7,3]  R2373     4.7856390476226807e-01
    z[8,7,3]  R2374     8.6956232786178589e-02
    z[8,7,3]  R2375     -2.1382060647010803e-01
    z[8,7,3]  R2376     4.3871462345123291e-01
    z[8,7,3]  R2377     -9.7884587943553925e-02
    z[8,7,3]  R2378     4.0203514695167542e-01
    z[8,7,3]  R2379     4.2656800150871277e-01
    z[8,7,3]  R2380     1.7222790420055389e-01
    z[8,7,3]  R2381     -2.5081360340118408e-01
    z[8,7,3]  R2382     6.9391858577728271e-01
    z[8,7,3]  R2383     -2.2699804604053497e-01
    z[8,7,3]  R2384     0.654820442199707
    z[8,7,3]  R2385     -2.8070241212844849e-01
    z[8,7,3]  R2386     0.0955732986330986
    z[8,7,3]  R2387     3.8018837571144104e-01
    z[8,7,3]  R2388     2.4246200919151306e-01
    z[8,7,3]  R2389     4.7367489337921143e-01
    z[8,7,3]  R2390     8.7103784084320068e-02
    z[8,7,3]  R2391     5.8222156763076782e-01
    z[8,7,3]  R2392     2.7179878950119019e-01
    z[8,7,3]  R2393     6.3187349587678909e-03
    z[8,7,3]  R2394     -2.4007922410964966e-01
    z[8,7,3]  R2395     1.7896729707717896e-01
    z[8,7,3]  R2396     1.1246153712272644e-01
    z[8,7,3]  R2397     0.343535453081131
    z[8,7,3]  R2398     -8.0852784216403961e-02
    z[8,7,3]  R2399     2.1543757990002632e-02
    z[8,7,3]  R2400     0.622757077217102
    z[8,7,4]  R69       1
    z[8,7,4]  R78       -1
    z[8,7,4]  R2279     -1
    z[8,7,4]  R2280     1
    z[8,7,4]  R2285     -2.6778010651469231e-02
    z[8,7,4]  R2286     3.5860094428062439e-01
    z[8,7,4]  R2287     1.4356791973114014e-01
    z[8,7,4]  R2288     3.2136055827140808e-01
    z[8,7,4]  R2289     -1.8034203350543976e-01
    z[8,7,4]  R2290     -1.2024753540754318e-01
    z[8,7,4]  R2291     2.7214720845222473e-01
    z[8,7,4]  R2292     2.1005927026271820e-01
    z[8,7,4]  R2293     2.6687526702880859e-01
    z[8,7,4]  R2294     7.2965443134307861e-01
    z[8,7,4]  R2295     -1.6865578293800354e-01
    z[8,7,4]  R2296     -3.6632204055786133e-01
    z[8,7,4]  R2297     2.3348139226436615e-01
    z[8,7,4]  R2298     -4.0672543644905090e-01
    z[8,7,4]  R2299     -4.8116365075111389e-01
    z[8,7,4]  R2300     -0.247926726937294
    z[8,7,4]  R2301     -2.0793950557708740e-01
    z[8,7,4]  R2302     -6.5966004133224487e-01
    z[8,7,4]  R2303     -2.0656064152717590e-01
    z[8,7,4]  R2304     -4.3522661924362183e-01
    z[8,7,4]  R2305     -1.4672678709030151e-01
    z[8,7,4]  R2306     1.9172701239585876e-01
    z[8,7,4]  R2307     -2.9065984487533569e-01
    z[8,7,4]  R2308     2.9688683152198792e-01
    z[8,7,4]  R2309     -3.5755434632301331e-01
    z[8,7,4]  R2310     2.1523140370845795e-01
    z[8,7,4]  R2311     4.4117426872253418e-01
    z[8,7,4]  R2312     -2.3671607673168182e-01
    z[8,7,4]  R2313     -3.1154295802116394e-01
    z[8,7,4]  R2314     5.4660546779632568e-01
    z[8,7,4]  R2315     1.2484390288591385e-01
    z[8,7,4]  R2316     -2.5522604584693909e-01
    z[8,7,4]  R2317     -3.5293996334075928e-01
    z[8,7,4]  R2318     1.3313040137290955e-01
    z[8,7,4]  R2319     3.5217371582984924e-01
    z[8,7,4]  R2320     4.2907809838652611e-03
    z[8,7,4]  R2321     -8.5193395614624023e-02
    z[8,7,4]  R2322     7.0026978850364685e-02
    z[8,7,4]  R2323     -2.9524338245391846e-01
    z[8,7,4]  R2324     -2.0597729086875916e-01
    z[8,7,4]  R2325     -3.7422144412994385e-01
    z[8,7,4]  R2326     0.00995348859578371
    z[8,7,4]  R2327     -1.3390763103961945e-01
    z[8,7,4]  R2328     -1.8794330954551697e-01
    z[8,7,4]  R2329     6.8049073219299316e-02
    z[8,7,4]  R2330     -7.9455800354480743e-02
    z[8,7,4]  R2331     -5.9384912252426147e-01
    z[8,7,4]  R2332     3.2085731625556946e-01
    z[8,7,4]  R2333     -6.0262900590896606e-01
    z[8,7,4]  R2334     -2.5845566391944885e-01
    z[8,7,4]  R2335     -1.5084058046340942e-01
    z[8,7,4]  R2336     1.3414281606674194e-01
    z[8,7,4]  R2337     -7.6363407075405121e-02
    z[8,7,4]  R2338     4.0686614811420441e-02
    z[8,7,4]  R2339     0.0765153020620346
    z[8,7,4]  R2340     -1.4057447016239166e-01
    z[8,7,4]  R2341     1.5660363435745239e-01
    z[8,7,4]  R2342     -1.1249816417694092e-01
    z[8,7,4]  R2343     7.6486356556415558e-02
    z[8,7,4]  R2344     4.5740908384323120e-01
    z[8,7,4]  R2345     8.9499615132808685e-02
    z[8,7,4]  R2346     4.7331336885690689e-02
    z[8,7,4]  R2347     3.2973381876945496e-01
    z[8,7,4]  R2348     -3.3574157953262329e-01
    z[8,7,4]  R2349     -4.2432984709739685e-01
    z[8,7,4]  R2350     3.9872664213180542e-01
    z[8,7,4]  R2351     -5.3129500150680542e-01
    z[8,7,4]  R2352     -1.2451307475566864e-01
    z[8,7,4]  R2353     -2.4385261535644531e-01
    z[8,7,4]  R2354     5.1127278804779053e-01
    z[8,7,4]  R2355     -9.7215771675109863e-03
    z[8,7,4]  R2356     -3.6113986372947693e-01
    z[8,7,4]  R2357     -3.7307681050151587e-03
    z[8,7,4]  R2358     3.2739689946174622e-01
    z[8,7,4]  R2359     1.6731344163417816e-01
    z[8,7,4]  R2360     -4.4316089153289795e-01
    z[8,7,4]  R2361     -6.4428359270095825e-01
    z[8,7,4]  R2362     -4.4806912541389465e-01
    z[8,7,4]  R2363     4.5098461210727692e-02
    z[8,7,4]  R2364     -2.2722931206226349e-01
    z[8,7,4]  R2365     8.8432833552360535e-02
    z[8,7,4]  R2366     0.465313196182251
    z[8,7,4]  R2367     1.2860104441642761e-01
    z[8,7,4]  R2368     -3.3516031503677368e-01
    z[8,7,4]  R2369     -6.3609242439270020e-01
    z[8,7,4]  R2370     0.596617579460144
    z[8,7,4]  R2371     -1.7998097836971283e-01
    z[8,7,4]  R2372     -4.9788096547126770e-01
    z[8,7,4]  R2373     -5.6146466732025146e-01
    z[8,7,4]  R2374     1.4679694175720215e-01
    z[8,7,4]  R2375     -6.3950762152671814e-02
    z[8,7,4]  R2376     2.4879693984985352e-01
    z[8,7,4]  R2377     1.5833935141563416e-01
    z[8,7,4]  R2378     5.1392215490341187e-01
    z[8,7,4]  R2379     -3.7641230225563049e-01
    z[8,7,4]  R2380     0.379869282245636
    z[8,7,4]  R2381     9.6967279911041260e-02
    z[8,7,4]  R2382     1.0076423641294241e-03
    z[8,7,4]  R2383     2.0542123913764954e-01
    z[8,7,4]  R2384     -5.4098106920719147e-02
    z[8,7,4]  R2385     -2.7587391436100006e-02
    z[8,7,4]  R2386     -3.4771472215652466e-01
    z[8,7,4]  R2387     -3.8345164060592651e-01
    z[8,7,4]  R2388     3.8322802633047104e-02
    z[8,7,4]  R2389     -1.1859432607889175e-01
    z[8,7,4]  R2390     3.4360870718955994e-01
    z[8,7,4]  R2391     8.2579381763935089e-02
    z[8,7,4]  R2392     3.4066599607467651e-01
    z[8,7,4]  R2393     3.4818691015243530e-01
    z[8,7,4]  R2394     -3.2962700724601746e-01
    z[8,7,4]  R2395     -4.4653964042663574e-01
    z[8,7,4]  R2396     0.174747034907341
    z[8,7,4]  R2397     2.2072552144527435e-01
    z[8,7,4]  R2398     -6.0214113444089890e-02
    z[8,7,4]  R2399     8.6433209478855133e-02
    z[8,7,4]  R2400     -1.4656464755535126e-01
    z[8,7,5]  R70       1
    z[8,7,5]  R79       -1
    z[8,7,5]  R2281     -1
    z[8,7,5]  R2282     1
    z[8,7,5]  R2285     1.9142253696918488e-01
    z[8,7,5]  R2286     -8.3000678569078445e-03
    z[8,7,5]  R2287     2.2672009468078613e-01
    z[8,7,5]  R2288     1.7032565176486969e-01
    z[8,7,5]  R2289     1.7105570435523987e-01
    z[8,7,5]  R2290     1.1228091269731522e-01
    z[8,7,5]  R2291     1.4679941534996033e-01
    z[8,7,5]  R2292     3.5912382602691650e-01
    z[8,7,5]  R2293     6.0152035951614380e-01
    z[8,7,5]  R2294     2.2390134632587433e-01
    z[8,7,5]  R2295     -3.1453219056129456e-01
    z[8,7,5]  R2296     2.8494027256965637e-01
    z[8,7,5]  R2297     -2.5033742189407349e-01
    z[8,7,5]  R2298     -0.0385163351893425
    z[8,7,5]  R2299     3.2776869833469391e-02
    z[8,7,5]  R2300     -8.3212591707706451e-02
    z[8,7,5]  R2301     -3.6018621176481247e-02
    z[8,7,5]  R2302     4.1902983188629150e-01
    z[8,7,5]  R2303     0.0738268494606018
    z[8,7,5]  R2304     1.2479127198457718e-01
    z[8,7,5]  R2305     -1.9711649417877197e-01
    z[8,7,5]  R2306     3.1322799623012543e-02
    z[8,7,5]  R2307     1.9233305752277374e-01
    z[8,7,5]  R2308     9.2855080962181091e-02
    z[8,7,5]  R2309     -3.3176234364509583e-01
    z[8,7,5]  R2310     3.1827205419540405e-01
    z[8,7,5]  R2311     -3.6571016907691956e-01
    z[8,7,5]  R2312     -0.0894322618842125
    z[8,7,5]  R2313     -2.6702433824539185e-01
    z[8,7,5]  R2314     -6.9068334996700287e-03
    z[8,7,5]  R2315     -2.2181174159049988e-01
    z[8,7,5]  R2316     -6.7543298006057739e-02
    z[8,7,5]  R2317     3.3199369907379150e-01
    z[8,7,5]  R2318     2.7365097403526306e-01
    z[8,7,5]  R2319     -4.5686885714530945e-02
    z[8,7,5]  R2320     -5.0309556722640991e-01
    z[8,7,5]  R2321     1.7004017531871796e-01
    z[8,7,5]  R2322     -3.9104998111724854e-01
    z[8,7,5]  R2323     4.3170547485351562e-01
    z[8,7,5]  R2324     3.9537000656127930e-01
    z[8,7,5]  R2325     1.9739224016666412e-01
    z[8,7,5]  R2326     -1.0161225683987141e-02
    z[8,7,5]  R2327     -2.2046926617622375e-01
    z[8,7,5]  R2328     -1.1617458611726761e-01
    z[8,7,5]  R2329     -2.7370089292526245e-01
    z[8,7,5]  R2330     2.6169112324714661e-01
    z[8,7,5]  R2331     -3.1920078396797180e-01
    z[8,7,5]  R2332     -0.0718526765704155
    z[8,7,5]  R2333     -3.7679579108953476e-02
    z[8,7,5]  R2334     -1.6701023280620575e-01
    z[8,7,5]  R2335     1.8614935874938965e-01
    z[8,7,5]  R2336     9.3117326498031616e-02
    z[8,7,5]  R2337     2.7580955624580383e-01
    z[8,7,5]  R2338     5.5818080902099609e-01
    z[8,7,5]  R2339     3.9974045753479004e-01
    z[8,7,5]  R2340     2.8213381767272949e-01
    z[8,7,5]  R2341     5.1896089315414429e-01
    z[8,7,5]  R2342     3.3511513471603394e-01
    z[8,7,5]  R2343     7.2859209775924683e-01
    z[8,7,5]  R2344     1.1801747605204582e-02
    z[8,7,5]  R2345     2.5110411643981934e-01
    z[8,7,5]  R2346     -1.0927030444145203e-01
    z[8,7,5]  R2347     0.0615973100066185
    z[8,7,5]  R2348     6.1962729692459106e-01
    z[8,7,5]  R2349     4.3426585197448730e-01
    z[8,7,5]  R2350     3.0216521024703979e-01
    z[8,7,5]  R2351     3.0502077937126160e-01
    z[8,7,5]  R2352     -9.4746068120002747e-02
    z[8,7,5]  R2353     9.1737724840641022e-02
    z[8,7,5]  R2354     2.5821238756179810e-01
    z[8,7,5]  R2355     -4.9469181895256042e-01
    z[8,7,5]  R2356     -7.1768736839294434e-01
    z[8,7,5]  R2357     -4.4325152039527893e-01
    z[8,7,5]  R2358     1.5520103275775909e-01
    z[8,7,5]  R2359     -3.0298948287963867e-01
    z[8,7,5]  R2360     -4.3303561210632324e-01
    z[8,7,5]  R2361     -6.8086847662925720e-02
    z[8,7,5]  R2362     -4.3712366372346878e-02
    z[8,7,5]  R2363     -8.8271975517272949e-02
    z[8,7,5]  R2364     2.4261020123958588e-02
    z[8,7,5]  R2365     -8.1317991018295288e-02
    z[8,7,5]  R2366     3.1873297691345215e-01
    z[8,7,5]  R2367     0.493461012840271
    z[8,7,5]  R2368     0.0917491689324379
    z[8,7,5]  R2369     0.0384628064930439
    z[8,7,5]  R2370     -2.5385764241218567e-01
    z[8,7,5]  R2371     6.6737681627273560e-01
    z[8,7,5]  R2372     3.6219995468854904e-02
    z[8,7,5]  R2373     1.7828892171382904e-01
    z[8,7,5]  R2374     1.6482140123844147e-01
    z[8,7,5]  R2375     -4.6848282217979431e-01
    z[8,7,5]  R2376     2.8239700198173523e-01
    z[8,7,5]  R2377     2.3493885993957520e-01
    z[8,7,5]  R2378     -5.5758815258741379e-02
    z[8,7,5]  R2379     2.7847331762313843e-01
    z[8,7,5]  R2380     -0.278018981218338
    z[8,7,5]  R2381     1.0319099575281143e-01
    z[8,7,5]  R2382     1.1388929933309555e-01
    z[8,7,5]  R2383     -6.6204950213432312e-02
    z[8,7,5]  R2384     2.0312872529029846e-01
    z[8,7,5]  R2385     -1.8792280554771423e-01
    z[8,7,5]  R2386     -5.0165127962827682e-02
    z[8,7,5]  R2387     4.0426683425903320e-01
    z[8,7,5]  R2388     -3.4717744588851929e-01
    z[8,7,5]  R2389     -2.1615166962146759e-01
    z[8,7,5]  R2390     -2.1370968222618103e-01
    z[8,7,5]  R2391     9.8391756415367126e-02
    z[8,7,5]  R2392     3.8102051615715027e-01
    z[8,7,5]  R2393     8.0623924732208252e-02
    z[8,7,5]  R2394     1.5236005187034607e-01
    z[8,7,5]  R2395     1.7441053688526154e-01
    z[8,7,5]  R2396     -4.6163287013769150e-02
    z[8,7,5]  R2397     9.7324825823307037e-02
    z[8,7,5]  R2398     -2.6789653301239014e-01
    z[8,7,5]  R2399     1.7962953448295593e-01
    z[8,7,5]  R2400     -1.7342975735664368e-01
    z[8,7,6]  R71       1
    z[8,7,6]  R80       -1
    z[8,7,6]  R2283     -1
    z[8,7,6]  R2284     1
    z[8,7,6]  R2285     9.5573388040065765e-02
    z[8,7,6]  R2286     -0.00667816074565053
    z[8,7,6]  R2287     8.5651800036430359e-02
    z[8,7,6]  R2288     -4.6514865010976791e-02
    z[8,7,6]  R2289     4.4298145920038223e-02
    z[8,7,6]  R2290     -1.6526412963867188e-01
    z[8,7,6]  R2291     -8.2540504634380341e-02
    z[8,7,6]  R2292     -4.0713074803352356e-01
    z[8,7,6]  R2293     1.9813652336597443e-01
    z[8,7,6]  R2294     0.0846172571182251
    z[8,7,6]  R2295     -6.6600787639617920e-01
    z[8,7,6]  R2296     6.8968725204467773e-01
    z[8,7,6]  R2297     4.7490417957305908e-01
    z[8,7,6]  R2298     -3.8561765104532242e-02
    z[8,7,6]  R2299     0.0684349462389946
    z[8,7,6]  R2300     4.2259924113750458e-02
    z[8,7,6]  R2301     2.1167999505996704e-01
    z[8,7,6]  R2302     -3.7862819153815508e-03
    z[8,7,6]  R2303     -1.4978150138631463e-03
    z[8,7,6]  R2304     2.1710345149040222e-01
    z[8,7,6]  R2305     4.1864126920700073e-02
    z[8,7,6]  R2306     -1.5669718384742737e-02
    z[8,7,6]  R2307     -1.4252914488315582e-01
    z[8,7,6]  R2308     2.5085920095443726e-01
    z[8,7,6]  R2309     -1.4304542541503906e-01
    z[8,7,6]  R2310     -4.8893624544143677e-01
    z[8,7,6]  R2311     8.6534790694713593e-02
    z[8,7,6]  R2312     -2.7721837162971497e-01
    z[8,7,6]  R2313     5.4862993955612183e-01
    z[8,7,6]  R2314     -2.4678014218807220e-01
    z[8,7,6]  R2315     -3.0206772685050964e-01
    z[8,7,6]  R2316     -1.4944548904895782e-01
    z[8,7,6]  R2317     -1.8581999838352203e-01
    z[8,7,6]  R2318     3.8092538714408875e-01
    z[8,7,6]  R2319     4.7314144670963287e-02
    z[8,7,6]  R2320     -2.9051521420478821e-01
    z[8,7,6]  R2321     -5.1917988061904907e-01
    z[8,7,6]  R2322     -2.5268509984016418e-02
    z[8,7,6]  R2323     6.8412572145462036e-02
    z[8,7,6]  R2324     -4.0220993757247925e-01
    z[8,7,6]  R2325     -1.0235381871461868e-01
    z[8,7,6]  R2326     1.0922455042600632e-01
    z[8,7,6]  R2327     2.1418869495391846e-01
    z[8,7,6]  R2328     -4.9310860037803650e-01
    z[8,7,6]  R2329     -3.3329862356185913e-01
    z[8,7,6]  R2330     -4.9258375167846680e-01
    z[8,7,6]  R2331     9.8725304007530212e-02
    z[8,7,6]  R2332     -1.6802644729614258e-01
    z[8,7,6]  R2333     -1.6861614584922791e-01
    z[8,7,6]  R2334     -0.218696728348732
    z[8,7,6]  R2335     -2.1060292422771454e-01
    z[8,7,6]  R2336     -6.7212447524070740e-02
    z[8,7,6]  R2337     -2.0458398386836052e-02
    z[8,7,6]  R2338     -5.2033051848411560e-02
    z[8,7,6]  R2339     1.4600904285907745e-01
    z[8,7,6]  R2340     -3.9462402462959290e-01
    z[8,7,6]  R2341     0.00793476216495037
    z[8,7,6]  R2342     -2.1063642203807831e-01
    z[8,7,6]  R2343     2.5378491729497910e-02
    z[8,7,6]  R2344     6.3474170863628387e-02
    z[8,7,6]  R2345     -3.3257222175598145e-01
    z[8,7,6]  R2346     2.4919089674949646e-01
    z[8,7,6]  R2347     1.3880443572998047e-01
    z[8,7,6]  R2348     -1.9143719971179962e-01
    z[8,7,6]  R2349     4.7549134492874146e-01
    z[8,7,6]  R2350     -0.300910085439682
    z[8,7,6]  R2351     -4.4281458854675293e-01
    z[8,7,6]  R2352     2.9233753681182861e-01
    z[8,7,6]  R2353     -2.5748351216316223e-01
    z[8,7,6]  R2354     6.3702660799026489e-01
    z[8,7,6]  R2355     4.7362601757049561e-01
    z[8,7,6]  R2356     -0.0733075812458992
    z[8,7,6]  R2357     3.8052010536193848e-01
    z[8,7,6]  R2358     4.6648353338241577e-02
    z[8,7,6]  R2359     -1.7170476913452148e-01
    z[8,7,6]  R2360     2.5206971168518066e-01
    z[8,7,6]  R2361     -2.7114412188529968e-01
    z[8,7,6]  R2362     3.5158342123031616e-01
    z[8,7,6]  R2363     -9.3288779258728027e-02
    z[8,7,6]  R2364     5.0532564520835876e-02
    z[8,7,6]  R2365     -2.9479971528053284e-01
    z[8,7,6]  R2366     3.5192602872848511e-01
    z[8,7,6]  R2367     8.4343627095222473e-02
    z[8,7,6]  R2368     2.2997410595417023e-01
    z[8,7,6]  R2369     1.0663776844739914e-01
    z[8,7,6]  R2370     4.0431201457977295e-01
    z[8,7,6]  R2371     -1.2665948271751404e-01
    z[8,7,6]  R2372     2.4457333981990814e-01
    z[8,7,6]  R2373     -2.0126027986407280e-02
    z[8,7,6]  R2374     3.0705055594444275e-01
    z[8,7,6]  R2375     2.3841249942779541e-01
    z[8,7,6]  R2376     -2.6274269819259644e-01
    z[8,7,6]  R2377     -2.1397694945335388e-01
    z[8,7,6]  R2378     -9.7718074917793274e-02
    z[8,7,6]  R2379     2.1014584600925446e-01
    z[8,7,6]  R2380     -6.7001514136791229e-02
    z[8,7,6]  R2381     -1.4330537617206573e-01
    z[8,7,6]  R2382     -2.8399093076586723e-02
    z[8,7,6]  R2383     -1.6327325999736786e-01
    z[8,7,6]  R2384     1.0520142316818237e-01
    z[8,7,6]  R2385     1.3809648156166077e-01
    z[8,7,6]  R2386     7.0091497898101807e-01
    z[8,7,6]  R2387     3.8709127902984619e-01
    z[8,7,6]  R2388     5.9288042783737183e-01
    z[8,7,6]  R2389     -7.7191629679873586e-04
    z[8,7,6]  R2390     1.5890252590179443e-01
    z[8,7,6]  R2391     1.9742861390113831e-01
    z[8,7,6]  R2392     6.8271338939666748e-02
    z[8,7,6]  R2393     -3.7137228250503540e-01
    z[8,7,6]  R2394     2.0336598157882690e-01
    z[8,7,6]  R2395     4.4109782576560974e-01
    z[8,7,6]  R2396     -2.6941576600074768e-01
    z[8,7,6]  R2397     1.1533229053020477e-01
    z[8,7,6]  R2398     -2.2734068334102631e-01
    z[8,7,6]  R2399     -2.1608080714941025e-02
    z[8,7,6]  R2400     2.1889238059520721e-01
    z[8,9,0]  R74       -1
    z[8,9,0]  R83       1
    z[8,9,0]  R2401     -1
    z[8,9,0]  R2402     1
    z[8,9,0]  R2415     -8.2706409692764282e-01
    z[8,9,0]  R2416     -9.1056984663009644e-01
    z[8,9,0]  R2417     -0.896411120891571
    z[8,9,0]  R2418     -7.7990359067916870e-01
    z[8,9,0]  R2419     -8.9173072576522827e-01
    z[8,9,0]  R2420     -8.0726486444473267e-01
    z[8,9,0]  R2421     -7.5758165121078491e-01
    z[8,9,0]  R2422     -6.9680100679397583e-01
    z[8,9,0]  R2423     -6.8020689487457275e-01
    z[8,9,0]  R2424     8.8735990226268768e-02
    z[8,9,0]  R2425     4.9224663525819778e-02
    z[8,9,0]  R2426     3.1487852334976196e-01
    z[8,9,0]  R2427     3.5001170635223389e-01
    z[8,9,0]  R2428     3.3615925908088684e-01
    z[8,9,0]  R2429     2.7263092994689941e-01
    z[8,9,0]  R2430     2.4038107693195343e-01
    z[8,9,0]  R2431     3.2954993844032288e-01
    z[8,9,0]  R2432     2.7537909150123596e-01
    z[8,9,0]  R2433     4.1178759932518005e-01
    z[8,9,0]  R2434     0.595511794090271
    z[8,9,0]  R2435     -0.0982019230723381
    z[8,9,0]  R2436     2.6607644557952881e-01
    z[8,9,0]  R2437     1.4676716923713684e-01
    z[8,9,0]  R2438     1.4686042070388794e-01
    z[8,9,0]  R2439     1.1764391511678696e-01
    z[8,9,0]  R2440     -4.9060784280300140e-02
    z[8,9,0]  R2441     -1.3944949209690094e-01
    z[8,9,0]  R2442     -3.4394964575767517e-01
    z[8,9,0]  R2443     -1.0979624092578888e-01
    z[8,9,0]  R2444     1.1869938671588898e-01
    z[8,9,0]  R2445     -2.8038039803504944e-01
    z[8,9,0]  R2446     1.5873451530933380e-01
    z[8,9,0]  R2447     3.6990955471992493e-02
    z[8,9,0]  R2448     1.4406321942806244e-01
    z[8,9,0]  R2449     9.2446029186248779e-02
    z[8,9,0]  R2450     1.0045155882835388e-01
    z[8,9,0]  R2451     2.3465298116207123e-01
    z[8,9,0]  R2452     1.7545820772647858e-01
    z[8,9,0]  R2453     -4.4613018631935120e-02
    z[8,9,0]  R2454     -4.5370548963546753e-02
    z[8,9,0]  R2455     1.1342381127178669e-02
    z[8,9,0]  R2456     0.00920828152447939
    z[8,9,0]  R2457     1.2489434331655502e-01
    z[8,9,0]  R2458     2.1298396587371826e-01
    z[8,9,0]  R2459     7.2609391063451767e-03
    z[8,9,0]  R2460     1.0130155831575394e-02
    z[8,9,0]  R2461     3.2253018021583557e-01
    z[8,9,0]  R2462     6.7334115505218506e-01
    z[8,9,0]  R2463     0.282462477684021
    z[8,9,0]  R2464     3.3619120717048645e-01
    z[8,9,0]  R2465     7.9640835523605347e-01
    z[8,9,0]  R2466     9.1283661127090454e-01
    z[8,9,0]  R2467     8.2904303073883057e-01
    z[8,9,0]  R2468     7.7248513698577881e-01
    z[8,9,0]  R2469     2.1900284290313721e-01
    z[8,9,0]  R2470     7.6090240478515625e-01
    z[8,9,0]  R2471     0.59315025806427
    z[8,9,0]  R2472     5.6900697946548462e-01
    z[8,9,0]  R2473     4.3024361133575439e-01
    z[8,9,0]  R2474     5.2603250741958618e-01
    z[8,9,0]  R2475     -4.1501635313034058e-01
    z[8,9,0]  R2476     -6.1638349294662476e-01
    z[8,9,0]  R2477     -1.2898580729961395e-01
    z[8,9,0]  R2478     -1.0595534741878510e-01
    z[8,9,0]  R2479     -2.1235486865043640e-01
    z[8,9,0]  R2480     -3.5595887899398804e-01
    z[8,9,0]  R2481     -4.8017153143882751e-01
    z[8,9,0]  R2482     -3.4229013323783875e-01
    z[8,9,0]  R2483     -3.6051180958747864e-01
    z[8,9,0]  R2484     1.0068622976541519e-01
    z[8,9,0]  R2485     -6.2879495322704315e-02
    z[8,9,0]  R2486     2.3196329176425934e-01
    z[8,9,0]  R2487     -1.3041956722736359e-01
    z[8,9,0]  R2488     0.473922997713089
    z[8,9,0]  R2489     4.8206233978271484e-01
    z[8,9,0]  R2490     4.1645923256874084e-01
    z[8,9,0]  R2491     2.4854870140552521e-01
    z[8,9,0]  R2492     5.7460528612136841e-01
    z[8,9,0]  R2493     -0.0876041129231453
    z[8,9,0]  R2494     -7.3631328344345093e-01
    z[8,9,0]  R2495     2.2810553014278412e-01
    z[8,9,0]  R2496     1.8212832510471344e-01
    z[8,9,0]  R2497     5.9286877512931824e-02
    z[8,9,0]  R2498     5.3127199411392212e-01
    z[8,9,0]  R2499     -1.2675017118453979e-01
    z[8,9,0]  R2500     -3.8847783207893372e-01
    z[8,9,0]  R2501     -2.9837992787361145e-01
    z[8,9,0]  R2502     2.4467872083187103e-01
    z[8,9,0]  R2503     2.3737061023712158e-01
    z[8,9,0]  R2504     7.8550964593887329e-02
    z[8,9,0]  R2505     -2.1258579194545746e-01
    z[8,9,0]  R2506     4.4759336113929749e-01
    z[8,9,0]  R2507     2.6186940073966980e-01
    z[8,9,0]  R2508     1.5955546498298645e-01
    z[8,9,0]  R2509     -2.0481684803962708e-01
    z[8,9,0]  R2510     -0.731015682220459
    z[8,9,0]  R2511     -8.7707176804542542e-02
    z[8,9,0]  R2512     -3.4270800650119781e-02
    z[8,9,0]  R2513     1.9785304367542267e-01
    z[8,9,0]  R2514     6.9680482149124146e-02
    z[8,9,0]  R2515     -2.8917935490608215e-01
    z[8,9,0]  R2516     -3.6127030849456787e-02
    z[8,9,0]  R2517     3.6400923132896423e-01
    z[8,9,0]  R2518     -0.0682537704706192
    z[8,9,0]  R2519     -2.4083405733108521e-01
    z[8,9,0]  R2520     6.7271322011947632e-01
    z[8,9,0]  R2521     2.8718367218971252e-01
    z[8,9,0]  R2522     3.4148886799812317e-01
    z[8,9,0]  R2523     -2.5947546958923340e-01
    z[8,9,0]  R2524     -7.9348587989807129e-01
    z[8,9,0]  R2525     -1.9329544901847839e-01
    z[8,9,0]  R2526     5.1389408111572266e-01
    z[8,9,0]  R2527     6.2059406191110611e-02
    z[8,9,0]  R2528     5.0344061106443405e-02
    z[8,9,0]  R2529     -3.3465296030044556e-02
    z[8,9,0]  R2530     -4.9066618084907532e-01
    z[8,9,0]  R2531     5.8313506841659546e-01
    z[8,9,0]  R2532     -7.7286720275878906e-01
    z[8,9,0]  R2533     -0.721823513507843
    z[8,9,0]  R2534     -6.4657241106033325e-01
    z[8,9,0]  R2535     2.1939818561077118e-01
    z[8,9,0]  R2536     2.8270853683352470e-02
    z[8,9,0]  R2537     -5.1187032461166382e-01
    z[8,9,0]  R2538     -1.3031905889511108e-01
    z[8,9,0]  R2539     -7.7040952444076538e-01
    z[8,9,0]  R2540     1.8976368010044098e-01
    z[8,9,0]  R2541     0.847102701663971
    z[8,9,0]  R2542     8.4951055049896240e-01
    z[8,9,0]  R2543     3.1519749760627747e-01
    z[8,9,0]  R2544     9.7910448908805847e-02
    z[8,9,1]  R75       -1
    z[8,9,1]  R84       1
    z[8,9,1]  R2403     -1
    z[8,9,1]  R2404     1
    z[8,9,1]  R2415     -3.8884587585926056e-02
    z[8,9,1]  R2416     -2.8132705017924309e-02
    z[8,9,1]  R2417     1.3578535616397858e-01
    z[8,9,1]  R2418     -8.7959386408329010e-02
    z[8,9,1]  R2419     0.0275983028113842
    z[8,9,1]  R2420     0.268432080745697
    z[8,9,1]  R2421     4.5238915085792542e-01
    z[8,9,1]  R2422     2.9841421172022820e-02
    z[8,9,1]  R2423     1.1943578720092773e-01
    z[8,9,1]  R2424     -8.0063328146934509e-02
    z[8,9,1]  R2425     -6.2669318914413452e-01
    z[8,9,1]  R2426     -3.9516237378120422e-01
    z[8,9,1]  R2427     -3.8031238317489624e-01
    z[8,9,1]  R2428     7.9426276683807373e-01
    z[8,9,1]  R2429     8.2045537233352661e-01
    z[8,9,1]  R2430     8.8006341457366943e-01
    z[8,9,1]  R2431     8.8734275102615356e-01
    z[8,9,1]  R2432     -3.7226536870002747e-01
    z[8,9,1]  R2433     8.6910420656204224e-01
    z[8,9,1]  R2434     -2.3682117462158203e-01
    z[8,9,1]  R2435     -9.3146163225173950e-01
    z[8,9,1]  R2436     -7.6777690649032593e-01
    z[8,9,1]  R2437     -9.0915805101394653e-01
    z[8,9,1]  R2438     -8.3823961019515991e-01
    z[8,9,1]  R2439     -0.82839035987854
    z[8,9,1]  R2440     -0.780409038066864
    z[8,9,1]  R2441     -7.5964945554733276e-01
    z[8,9,1]  R2442     -8.2713586091995239e-01
    z[8,9,1]  R2443     -6.8862271308898926e-01
    z[8,9,1]  R2444     -7.0851981639862061e-01
    z[8,9,1]  R2445     -8.1212782859802246e-01
    z[8,9,1]  R2446     8.8121265172958374e-01
    z[8,9,1]  R2447     8.4028065204620361e-01
    z[8,9,1]  R2448     7.6849848031997681e-01
    z[8,9,1]  R2449     8.1701892614364624e-01
    z[8,9,1]  R2450     7.8537470102310181e-01
    z[8,9,1]  R2451     0.756335437297821
    z[8,9,1]  R2452     6.2838083505630493e-01
    z[8,9,1]  R2453     4.9951234459877014e-01
    z[8,9,1]  R2454     5.2126449346542358e-01
    z[8,9,1]  R2455     8.6326146125793457e-01
    z[8,9,1]  R2456     9.1128599643707275e-01
    z[8,9,1]  R2457     8.3672732114791870e-01
    z[8,9,1]  R2458     8.1179004907608032e-01
    z[8,9,1]  R2459     7.5844889879226685e-01
    z[8,9,1]  R2460     5.5628603696823120e-01
    z[8,9,1]  R2461     4.1705000400543213e-01
    z[8,9,1]  R2462     6.1076825857162476e-01
    z[8,9,1]  R2463     3.4541657567024231e-01
    z[8,9,1]  R2464     3.7452796101570129e-01
    z[8,9,1]  R2465     4.6728920936584473e-01
    z[8,9,1]  R2466     1.5661269426345825e-01
    z[8,9,1]  R2467     2.0572523772716522e-01
    z[8,9,1]  R2468     1.5655416250228882e-01
    z[8,9,1]  R2469     4.1292944550514221e-01
    z[8,9,1]  R2470     1.3044695556163788e-01
    z[8,9,1]  R2471     2.1109478175640106e-01
    z[8,9,1]  R2472     1.3563109934329987e-01
    z[8,9,1]  R2473     5.2235114574432373e-01
    z[8,9,1]  R2474     3.5238561034202576e-01
    z[8,9,1]  R2475     -8.0737462267279625e-03
    z[8,9,1]  R2476     1.4230413734912872e-01
    z[8,9,1]  R2477     2.2624358534812927e-02
    z[8,9,1]  R2478     2.3977272212505341e-01
    z[8,9,1]  R2479     0.528877854347229
    z[8,9,1]  R2480     -4.0463000535964966e-01
    z[8,9,1]  R2481     2.2134327888488770e-01
    z[8,9,1]  R2482     3.5330925136804581e-02
    z[8,9,1]  R2483     7.0831492543220520e-02
    z[8,9,1]  R2484     -7.0181339979171753e-02
    z[8,9,1]  R2485     -7.0611411333084106e-01
    z[8,9,1]  R2486     -7.0038020610809326e-01
    z[8,9,1]  R2487     -5.3251928091049194e-01
    z[8,9,1]  R2488     -5.2856034040451050e-01
    z[8,9,1]  R2489     -6.2404000759124756e-01
    z[8,9,1]  R2490     -6.9835889339447021e-01
    z[8,9,1]  R2491     -4.2886650562286377e-01
    z[8,9,1]  R2492     -6.2193077802658081e-01
    z[8,9,1]  R2493     -5.5906790494918823e-01
    z[8,9,1]  R2494     -2.4140434339642525e-02
    z[8,9,1]  R2495     -7.4764102697372437e-01
    z[8,9,1]  R2496     -6.5758311748504639e-01
    z[8,9,1]  R2497     -6.6996800899505615e-01
    z[8,9,1]  R2498     -6.4960908889770508e-01
    z[8,9,1]  R2499     -6.0257738828659058e-01
    z[8,9,1]  R2500     -7.6623803377151489e-01
    z[8,9,1]  R2501     -7.8444540500640869e-01
    z[8,9,1]  R2502     -4.3566080927848816e-01
    z[8,9,1]  R2503     -5.9862571954727173e-01
    z[8,9,1]  R2504     -5.6945592164993286e-01
    z[8,9,1]  R2505     -9.3129861354827881e-01
    z[8,9,1]  R2506     -7.7635931968688965e-01
    z[8,9,1]  R2507     -6.7822271585464478e-01
    z[8,9,1]  R2508     -6.6880780458450317e-01
    z[8,9,1]  R2509     -4.9056935310363770e-01
    z[8,9,1]  R2510     1.4509424567222595e-01
    z[8,9,1]  R2511     5.1353760063648224e-02
    z[8,9,1]  R2512     6.5615244209766388e-02
    z[8,9,1]  R2513     3.6510124802589417e-01
    z[8,9,1]  R2514     2.5187534093856812e-01
    z[8,9,1]  R2515     -5.2829945087432861e-01
    z[8,9,1]  R2516     -5.9183764457702637e-01
    z[8,9,1]  R2517     -6.8946105241775513e-01
    z[8,9,1]  R2518     -5.8173561096191406e-01
    z[8,9,1]  R2519     -4.5227476954460144e-01
    z[8,9,1]  R2520     -5.3008455038070679e-01
    z[8,9,1]  R2521     -6.2674248218536377e-01
    z[8,9,1]  R2522     -1.7841532826423645e-01
    z[8,9,1]  R2523     -7.3125049471855164e-02
    z[8,9,1]  R2524     2.7809736132621765e-01
    z[8,9,1]  R2525     -8.5583233833312988e-01
    z[8,9,1]  R2526     -6.5710622072219849e-01
    z[8,9,1]  R2527     -4.3961033225059509e-01
    z[8,9,1]  R2528     -3.8813760876655579e-01
    z[8,9,1]  R2529     -4.3275612592697144e-01
    z[8,9,1]  R2530     -6.7361706495285034e-01
    z[8,9,1]  R2531     -5.6662166118621826e-01
    z[8,9,1]  R2532     -3.2149741053581238e-01
    z[8,9,1]  R2533     -1.5396389365196228e-01
    z[8,9,1]  R2534     -8.5054852068424225e-02
    z[8,9,1]  R2535     -8.5403424501419067e-01
    z[8,9,1]  R2536     -4.9898526072502136e-01
    z[8,9,1]  R2537     -3.9110168814659119e-01
    z[8,9,1]  R2538     -7.5024962425231934e-01
    z[8,9,1]  R2539     -2.7281123399734497e-01
    z[8,9,1]  R2540     4.3152235448360443e-02
    z[8,9,1]  R2541     5.2607440948486328e-01
    z[8,9,1]  R2542     5.0985753536224365e-01
    z[8,9,1]  R2543     5.1093775779008865e-02
    z[8,9,1]  R2544     5.5250930786132812e-01
    z[8,9,2]  R76       -1
    z[8,9,2]  R85       1
    z[8,9,2]  R2405     -1
    z[8,9,2]  R2406     1
    z[8,9,2]  R2415     3.7001019716262817e-01
    z[8,9,2]  R2416     3.9191324263811111e-02
    z[8,9,2]  R2417     -2.3739559948444366e-01
    z[8,9,2]  R2418     4.1689342260360718e-01
    z[8,9,2]  R2419     -2.1192955970764160e-01
    z[8,9,2]  R2420     1.5318708121776581e-01
    z[8,9,2]  R2421     1.5639486908912659e-01
    z[8,9,2]  R2422     2.1300381422042847e-01
    z[8,9,2]  R2423     1.4234852790832520e-01
    z[8,9,2]  R2424     6.1447417736053467e-01
    z[8,9,2]  R2425     1.1584693938493729e-01
    z[8,9,2]  R2426     1.3109819591045380e-01
    z[8,9,2]  R2427     -3.8024783134460449e-01
    z[8,9,2]  R2428     9.7751110792160034e-02
    z[8,9,2]  R2429     1.6658306121826172e-02
    z[8,9,2]  R2430     -2.3500657081604004e-01
    z[8,9,2]  R2431     -1.1313124746084213e-01
    z[8,9,2]  R2432     -4.1775825619697571e-01
    z[8,9,2]  R2433     1.2241696566343307e-01
    z[8,9,2]  R2434     5.8064609766006470e-01
    z[8,9,2]  R2435     -2.0666979253292084e-01
    z[8,9,2]  R2436     5.3458905220031738e-01
    z[8,9,2]  R2437     -7.9022668302059174e-02
    z[8,9,2]  R2438     1.7064422369003296e-01
    z[8,9,2]  R2439     2.0214636623859406e-01
    z[8,9,2]  R2440     4.2698092758655548e-02
    z[8,9,2]  R2441     1.4063432812690735e-01
    z[8,9,2]  R2442     1.5370629727840424e-01
    z[8,9,2]  R2443     1.9401220977306366e-01
    z[8,9,2]  R2444     -1.7959360778331757e-01
    z[8,9,2]  R2445     3.1395298242568970e-01
    z[8,9,2]  R2446     2.0556405186653137e-01
    z[8,9,2]  R2447     1.3141946494579315e-01
    z[8,9,2]  R2448     2.8139057755470276e-01
    z[8,9,2]  R2449     0.167667955160141
    z[8,9,2]  R2450     1.5895701944828033e-01
    z[8,9,2]  R2451     -2.1128481626510620e-01
    z[8,9,2]  R2452     6.4380693435668945e-01
    z[8,9,2]  R2453     5.9099775552749634e-01
    z[8,9,2]  R2454     3.2522940635681152e-01
    z[8,9,2]  R2455     2.4921227991580963e-01
    z[8,9,2]  R2456     0.164270281791687
    z[8,9,2]  R2457     3.9745372533798218e-01
    z[8,9,2]  R2458     3.2791949808597565e-02
    z[8,9,2]  R2459     3.8916710019111633e-01
    z[8,9,2]  R2460     5.2506572008132935e-01
    z[8,9,2]  R2461     -0.507003664970398
    z[8,9,2]  R2462     5.9127245098352432e-02
    z[8,9,2]  R2463     -6.3768506050109863e-01
    z[8,9,2]  R2464     -7.6838845014572144e-01
    z[8,9,2]  R2465     2.1167370676994324e-01
    z[8,9,2]  R2466     -7.1744740009307861e-02
    z[8,9,2]  R2467     -3.2376566529273987e-01
    z[8,9,2]  R2468     -9.3596793711185455e-02
    z[8,9,2]  R2469     -7.3147827386856079e-01
    z[8,9,2]  R2470     -2.4297079443931580e-01
    z[8,9,2]  R2471     -1.1006604135036469e-01
    z[8,9,2]  R2472     -3.8526695966720581e-01
    z[8,9,2]  R2473     4.7550402581691742e-02
    z[8,9,2]  R2474     -6.1102062463760376e-01
    z[8,9,2]  R2475     1.0386286303400993e-03
    z[8,9,2]  R2476     -4.5047495514154434e-02
    z[8,9,2]  R2477     -3.8759005069732666e-01
    z[8,9,2]  R2478     -1.3593223690986633e-01
    z[8,9,2]  R2479     -2.0350408554077148e-01
    z[8,9,2]  R2480     1.3394263386726379e-01
    z[8,9,2]  R2481     3.4943490754812956e-03
    z[8,9,2]  R2482     -1.4786422252655029e-01
    z[8,9,2]  R2483     -2.1904994547367096e-01
    z[8,9,2]  R2484     7.6188242435455322e-01
    z[8,9,2]  R2485     2.6483091711997986e-01
    z[8,9,2]  R2486     1.2022143602371216e-01
    z[8,9,2]  R2487     2.6209217309951782e-01
    z[8,9,2]  R2488     5.0239282846450806e-01
    z[8,9,2]  R2489     7.1645148098468781e-02
    z[8,9,2]  R2490     4.8133295774459839e-01
    z[8,9,2]  R2491     5.5973953008651733e-01
    z[8,9,2]  R2492     4.6483024954795837e-01
    z[8,9,2]  R2493     -2.7340808510780334e-01
    z[8,9,2]  R2494     -3.8282856345176697e-01
    z[8,9,2]  R2495     5.0953525304794312e-01
    z[8,9,2]  R2496     4.2274218797683716e-01
    z[8,9,2]  R2497     4.0736341476440430e-01
    z[8,9,2]  R2498     4.7930145263671875e-01
    z[8,9,2]  R2499     0.506238579750061
    z[8,9,2]  R2500     -0.0528477281332016
    z[8,9,2]  R2501     1.1037375032901764e-01
    z[8,9,2]  R2502     -5.6048955768346786e-02
    z[8,9,2]  R2503     -1.8911965191364288e-01
    z[8,9,2]  R2504     -6.1571896076202393e-01
    z[8,9,2]  R2505     -1.0740020871162415e-01
    z[8,9,2]  R2506     -3.3411350846290588e-01
    z[8,9,2]  R2507     -3.0589619278907776e-01
    z[8,9,2]  R2508     -6.4837050437927246e-01
    z[8,9,2]  R2509     5.5570787191390991e-01
    z[8,9,2]  R2510     1.3312242925167084e-01
    z[8,9,2]  R2511     -1.6032233834266663e-02
    z[8,9,2]  R2512     -2.3102298378944397e-01
    z[8,9,2]  R2513     -1.2256371974945068e-01
    z[8,9,2]  R2514     1.2075113505125046e-01
    z[8,9,2]  R2515     -2.2346045076847076e-01
    z[8,9,2]  R2516     0.60540372133255
    z[8,9,2]  R2517     2.0606490969657898e-01
    z[8,9,2]  R2518     -3.6067304015159607e-01
    z[8,9,2]  R2519     6.7916673421859741e-01
    z[8,9,2]  R2520     1.0233601182699203e-01
    z[8,9,2]  R2521     -4.0065848827362061e-01
    z[8,9,2]  R2522     5.6349843740463257e-01
    z[8,9,2]  R2523     4.7895425558090210e-01
    z[8,9,2]  R2524     -2.0525640249252319e-01
    z[8,9,2]  R2525     1.1915708333253860e-01
    z[8,9,2]  R2526     -2.4162931367754936e-02
    z[8,9,2]  R2527     6.9115614891052246e-01
    z[8,9,2]  R2528     2.3771961033344269e-01
    z[8,9,2]  R2529     5.9727275371551514e-01
    z[8,9,2]  R2530     3.7660089135169983e-01
    z[8,9,2]  R2531     -8.1534683704376221e-02
    z[8,9,2]  R2532     1.6884498298168182e-01
    z[8,9,2]  R2533     0.0457034595310688
    z[8,9,2]  R2534     -6.0023766756057739e-01
    z[8,9,2]  R2535     2.0172378420829773e-01
    z[8,9,2]  R2536     7.1617412567138672e-01
    z[8,9,2]  R2537     4.1023689508438110e-01
    z[8,9,2]  R2538     2.5607201457023621e-01
    z[8,9,2]  R2539     5.2217740565538406e-02
    z[8,9,2]  R2540     8.9033029973506927e-02
    z[8,9,2]  R2541     -6.4803071320056915e-02
    z[8,9,2]  R2542     8.8083133101463318e-02
    z[8,9,2]  R2543     -2.4576622247695923e-01
    z[8,9,2]  R2544     6.7231643199920654e-01
    z[8,9,3]  R77       -1
    z[8,9,3]  R86       1
    z[8,9,3]  R2407     -1
    z[8,9,3]  R2408     1
    z[8,9,3]  R2415     -3.6201027035713196e-01
    z[8,9,3]  R2416     -1.9956721365451813e-01
    z[8,9,3]  R2417     -2.0567707717418671e-01
    z[8,9,3]  R2418     -2.7525684237480164e-01
    z[8,9,3]  R2419     -3.0886083841323853e-01
    z[8,9,3]  R2420     -4.4544646143913269e-01
    z[8,9,3]  R2421     -3.0745381116867065e-01
    z[8,9,3]  R2422     -3.5966235399246216e-01
    z[8,9,3]  R2423     -1.7459464073181152e-01
    z[8,9,3]  R2424     1.3583010435104370e-01
    z[8,9,3]  R2425     -1.4307460188865662e-01
    z[8,9,3]  R2426     1.9094523787498474e-01
    z[8,9,3]  R2427     4.9552959203720093e-01
    z[8,9,3]  R2428     2.7962881326675415e-01
    z[8,9,3]  R2429     1.2235908955335617e-01
    z[8,9,3]  R2430     2.0566809177398682e-01
    z[8,9,3]  R2431     4.3316021561622620e-02
    z[8,9,3]  R2432     1.7639221623539925e-02
    z[8,9,3]  R2433     1.0946667194366455e-01
    z[8,9,3]  R2434     1.6150042647495866e-03
    z[8,9,3]  R2435     1.3374246656894684e-01
    z[8,9,3]  R2436     1.2629568576812744e-01
    z[8,9,3]  R2437     6.2102116644382477e-02
    z[8,9,3]  R2438     2.9491135478019714e-01
    z[8,9,3]  R2439     -2.6322089135646820e-02
    z[8,9,3]  R2440     7.1578072383999825e-03
    z[8,9,3]  R2441     2.1872717142105103e-01
    z[8,9,3]  R2442     -1.8175978958606720e-01
    z[8,9,3]  R2443     8.2140177488327026e-02
    z[8,9,3]  R2444     3.0320054292678833e-01
    z[8,9,3]  R2445     -8.5072226822376251e-02
    z[8,9,3]  R2446     -2.5293228030204773e-01
    z[8,9,3]  R2447     -7.7289357781410217e-02
    z[8,9,3]  R2448     2.6788532733917236e-01
    z[8,9,3]  R2449     4.0922960638999939e-01
    z[8,9,3]  R2450     1.0151887685060501e-01
    z[8,9,3]  R2451     -1.5011383593082428e-01
    z[8,9,3]  R2452     -3.7447098642587662e-02
    z[8,9,3]  R2453     3.4785076975822449e-01
    z[8,9,3]  R2454     5.0983697175979614e-01
    z[8,9,3]  R2455     -5.5340811610221863e-02
    z[8,9,3]  R2456     3.6104840040206909e-01
    z[8,9,3]  R2457     -1.1791817843914032e-01
    z[8,9,3]  R2458     -5.0834685564041138e-02
    z[8,9,3]  R2459     2.8743815422058105e-01
    z[8,9,3]  R2460     3.1195366382598877e-01
    z[8,9,3]  R2461     2.6422295719385147e-02
    z[8,9,3]  R2462     1.8366459012031555e-01
    z[8,9,3]  R2463     -3.5316757857799530e-02
    z[8,9,3]  R2464     1.1731790006160736e-01
    z[8,9,3]  R2465     2.8474060818552971e-02
    z[8,9,3]  R2466     3.2537961006164551e-01
    z[8,9,3]  R2467     2.8847834467887878e-01
    z[8,9,3]  R2468     2.3252607882022858e-01
    z[8,9,3]  R2469     2.4392794072628021e-01
    z[8,9,3]  R2470     2.9981240630149841e-01
    z[8,9,3]  R2471     5.4551732540130615e-01
    z[8,9,3]  R2472     5.8316290378570557e-01
    z[8,9,3]  R2473     4.9375861883163452e-02
    z[8,9,3]  R2474     -1.1125106364488602e-01
    z[8,9,3]  R2475     0.630595862865448
    z[8,9,3]  R2476     3.2040849328041077e-01
    z[8,9,3]  R2477     4.2054033279418945e-01
    z[8,9,3]  R2478     2.8039768338203430e-01
    z[8,9,3]  R2479     6.8141895532608032e-01
    z[8,9,3]  R2480     0.524479329586029
    z[8,9,3]  R2481     5.2910721302032471e-01
    z[8,9,3]  R2482     6.7841708660125732e-01
    z[8,9,3]  R2483     2.3260892927646637e-01
    z[8,9,3]  R2484     3.1640842556953430e-01
    z[8,9,3]  R2485     -0.0922887921333313
    z[8,9,3]  R2486     -8.1799037754535675e-02
    z[8,9,3]  R2487     -1.5462781488895416e-01
    z[8,9,3]  R2488     -1.4706438779830933e-01
    z[8,9,3]  R2489     -2.7036878466606140e-01
    z[8,9,3]  R2490     -5.1282446831464767e-02
    z[8,9,3]  R2491     -1.6719731688499451e-01
    z[8,9,3]  R2492     4.5264132320880890e-02
    z[8,9,3]  R2493     -3.4057107567787170e-01
    z[8,9,3]  R2494     -4.3049478530883789e-01
    z[8,9,3]  R2495     -3.1722940504550934e-02
    z[8,9,3]  R2496     2.6191183924674988e-01
    z[8,9,3]  R2497     2.0088051259517670e-01
    z[8,9,3]  R2498     -1.5801148116588593e-01
    z[8,9,3]  R2499     3.7539863586425781e-01
    z[8,9,3]  R2500     -2.1942764520645142e-01
    z[8,9,3]  R2501     -4.3343058228492737e-01
    z[8,9,3]  R2502     6.8287503719329834e-01
    z[8,9,3]  R2503     -7.0812559127807617e-01
    z[8,9,3]  R2504     -3.3075016736984253e-01
    z[8,9,3]  R2505     -1.3071247935295105e-01
    z[8,9,3]  R2506     2.7870687842369080e-01
    z[8,9,3]  R2507     5.4167336225509644e-01
    z[8,9,3]  R2508     1.5987187623977661e-01
    z[8,9,3]  R2509     -1.5942801535129547e-01
    z[8,9,3]  R2510     2.6197269558906555e-01
    z[8,9,3]  R2511     -6.6071957349777222e-01
    z[8,9,3]  R2512     -5.8773660659790039e-01
    z[8,9,3]  R2513     -5.7532048225402832e-01
    z[8,9,3]  R2514     -5.9662473201751709e-01
    z[8,9,3]  R2515     -2.4122324585914612e-01
    z[8,9,3]  R2516     0.0994042381644249
    z[8,9,3]  R2517     -2.5547316670417786e-01
    z[8,9,3]  R2518     6.9014841318130493e-01
    z[8,9,3]  R2519     1.4085161685943604e-01
    z[8,9,3]  R2520     2.4849760532379150e-01
    z[8,9,3]  R2521     2.2239649295806885e-01
    z[8,9,3]  R2522     -2.5498563051223755e-01
    z[8,9,3]  R2523     -2.6442768052220345e-02
    z[8,9,3]  R2524     -1.3136214017868042e-01
    z[8,9,3]  R2525     8.0912478268146515e-02
    z[8,9,3]  R2526     1.8270447850227356e-01
    z[8,9,3]  R2527     5.7935353368520737e-02
    z[8,9,3]  R2528     0.816985547542572
    z[8,9,3]  R2529     -1.5790291130542755e-01
    z[8,9,3]  R2530     -2.7754920721054077e-01
    z[8,9,3]  R2531     -2.4088135361671448e-01
    z[8,9,3]  R2532     5.4302625358104706e-02
    z[8,9,3]  R2533     -1.5420977771282196e-01
    z[8,9,3]  R2534     -1.8729925155639648e-01
    z[8,9,3]  R2535     -1.7744068801403046e-01
    z[8,9,3]  R2536     9.2129111289978027e-02
    z[8,9,3]  R2537     1.0381588339805603e-01
    z[8,9,3]  R2538     -4.5471572875976562e-01
    z[8,9,3]  R2539     -5.7463750243186951e-02
    z[8,9,3]  R2540     -7.5366806983947754e-01
    z[8,9,3]  R2541     -1.6991352662444115e-02
    z[8,9,3]  R2542     7.7977791428565979e-02
    z[8,9,3]  R2543     -0.704690158367157
    z[8,9,3]  R2544     -2.0809842646121979e-01
    z[8,9,4]  R78       -1
    z[8,9,4]  R87       1
    z[8,9,4]  R2409     -1
    z[8,9,4]  R2410     1
    z[8,9,4]  R2415     -2.6778010651469231e-02
    z[8,9,4]  R2416     3.5860094428062439e-01
    z[8,9,4]  R2417     1.4356791973114014e-01
    z[8,9,4]  R2418     3.2136055827140808e-01
    z[8,9,4]  R2419     -1.8034203350543976e-01
    z[8,9,4]  R2420     -1.2024753540754318e-01
    z[8,9,4]  R2421     2.7214720845222473e-01
    z[8,9,4]  R2422     2.1005927026271820e-01
    z[8,9,4]  R2423     2.6687526702880859e-01
    z[8,9,4]  R2424     7.2965443134307861e-01
    z[8,9,4]  R2425     -1.6865578293800354e-01
    z[8,9,4]  R2426     -3.6632204055786133e-01
    z[8,9,4]  R2427     2.3348139226436615e-01
    z[8,9,4]  R2428     -4.0672543644905090e-01
    z[8,9,4]  R2429     -4.8116365075111389e-01
    z[8,9,4]  R2430     -0.247926726937294
    z[8,9,4]  R2431     -2.0793950557708740e-01
    z[8,9,4]  R2432     -6.5966004133224487e-01
    z[8,9,4]  R2433     -2.0656064152717590e-01
    z[8,9,4]  R2434     -4.3522661924362183e-01
    z[8,9,4]  R2435     -1.4672678709030151e-01
    z[8,9,4]  R2436     1.9172701239585876e-01
    z[8,9,4]  R2437     -2.9065984487533569e-01
    z[8,9,4]  R2438     2.9688683152198792e-01
    z[8,9,4]  R2439     -3.5755434632301331e-01
    z[8,9,4]  R2440     2.1523140370845795e-01
    z[8,9,4]  R2441     4.4117426872253418e-01
    z[8,9,4]  R2442     -2.3671607673168182e-01
    z[8,9,4]  R2443     -3.1154295802116394e-01
    z[8,9,4]  R2444     5.4660546779632568e-01
    z[8,9,4]  R2445     1.2484390288591385e-01
    z[8,9,4]  R2446     -2.5522604584693909e-01
    z[8,9,4]  R2447     -3.5293996334075928e-01
    z[8,9,4]  R2448     1.3313040137290955e-01
    z[8,9,4]  R2449     3.5217371582984924e-01
    z[8,9,4]  R2450     4.2907809838652611e-03
    z[8,9,4]  R2451     -8.5193395614624023e-02
    z[8,9,4]  R2452     7.0026978850364685e-02
    z[8,9,4]  R2453     -2.9524338245391846e-01
    z[8,9,4]  R2454     -2.0597729086875916e-01
    z[8,9,4]  R2455     -3.7422144412994385e-01
    z[8,9,4]  R2456     0.00995348859578371
    z[8,9,4]  R2457     -1.3390763103961945e-01
    z[8,9,4]  R2458     -1.8794330954551697e-01
    z[8,9,4]  R2459     6.8049073219299316e-02
    z[8,9,4]  R2460     -7.9455800354480743e-02
    z[8,9,4]  R2461     -5.9384912252426147e-01
    z[8,9,4]  R2462     3.2085731625556946e-01
    z[8,9,4]  R2463     -6.0262900590896606e-01
    z[8,9,4]  R2464     -2.5845566391944885e-01
    z[8,9,4]  R2465     -1.5084058046340942e-01
    z[8,9,4]  R2466     1.3414281606674194e-01
    z[8,9,4]  R2467     -7.6363407075405121e-02
    z[8,9,4]  R2468     4.0686614811420441e-02
    z[8,9,4]  R2469     0.0765153020620346
    z[8,9,4]  R2470     -1.4057447016239166e-01
    z[8,9,4]  R2471     1.5660363435745239e-01
    z[8,9,4]  R2472     -1.1249816417694092e-01
    z[8,9,4]  R2473     7.6486356556415558e-02
    z[8,9,4]  R2474     4.5740908384323120e-01
    z[8,9,4]  R2475     -2.3744067549705505e-01
    z[8,9,4]  R2476     0.0827716812491417
    z[8,9,4]  R2477     -5.7877349853515625e-01
    z[8,9,4]  R2478     -4.7462841868400574e-01
    z[8,9,4]  R2479     -3.8081204891204834e-01
    z[8,9,4]  R2480     -0.628445029258728
    z[8,9,4]  R2481     -4.8358172178268433e-01
    z[8,9,4]  R2482     -5.2478021383285522e-01
    z[8,9,4]  R2483     3.8961541652679443e-01
    z[8,9,4]  R2484     5.0594240427017212e-01
    z[8,9,4]  R2485     2.4471342563629150e-01
    z[8,9,4]  R2486     -2.8229910880327225e-02
    z[8,9,4]  R2487     5.2011376619338989e-01
    z[8,9,4]  R2488     -9.4679847359657288e-02
    z[8,9,4]  R2489     3.9547699689865112e-01
    z[8,9,4]  R2490     9.6088767051696777e-02
    z[8,9,4]  R2491     4.8031383752822876e-01
    z[8,9,4]  R2492     -1.4868909120559692e-01
    z[8,9,4]  R2493     3.5853621363639832e-01
    z[8,9,4]  R2494     1.0054794698953629e-01
    z[8,9,4]  R2495     -2.9966783523559570e-01
    z[8,9,4]  R2496     0.308178573846817
    z[8,9,4]  R2497     0.501348614692688
    z[8,9,4]  R2498     4.1890364140272141e-02
    z[8,9,4]  R2499     1.7075219750404358e-01
    z[8,9,4]  R2500     3.2352928072214127e-02
    z[8,9,4]  R2501     -2.3997258394956589e-02
    z[8,9,4]  R2502     3.6097481846809387e-01
    z[8,9,4]  R2503     -1.7721448838710785e-01
    z[8,9,4]  R2504     4.0443789958953857e-01
    z[8,9,4]  R2505     1.4199002087116241e-01
    z[8,9,4]  R2506     -8.5988417267799377e-02
    z[8,9,4]  R2507     -8.8775508105754852e-02
    z[8,9,4]  R2508     3.4498311579227448e-02
    z[8,9,4]  R2509     5.0465297698974609e-01
    z[8,9,4]  R2510     3.7336525321006775e-01
    z[8,9,4]  R2511     3.6075541377067566e-01
    z[8,9,4]  R2512     4.2704832553863525e-01
    z[8,9,4]  R2513     4.9841120839118958e-01
    z[8,9,4]  R2514     6.9261372089385986e-01
    z[8,9,4]  R2515     -0.00996506679803133
    z[8,9,4]  R2516     3.2574638724327087e-01
    z[8,9,4]  R2517     0.284542053937912
    z[8,9,4]  R2518     1.0995614528656006e-01
    z[8,9,4]  R2519     4.5094323158264160e-01
    z[8,9,4]  R2520     -2.1217282116413116e-01
    z[8,9,4]  R2521     0.539861261844635
    z[8,9,4]  R2522     6.7160254716873169e-01
    z[8,9,4]  R2523     8.1771403551101685e-01
    z[8,9,4]  R2524     0.30640709400177
    z[8,9,4]  R2525     -3.5012137889862061e-01
    z[8,9,4]  R2526     -5.1747161149978638e-01
    z[8,9,4]  R2527     2.7940675616264343e-01
    z[8,9,4]  R2528     2.8810921311378479e-01
    z[8,9,4]  R2529     6.4422529935836792e-01
    z[8,9,4]  R2530     2.4196559190750122e-01
    z[8,9,4]  R2531     7.9599432647228241e-02
    z[8,9,4]  R2532     1.9483956694602966e-01
    z[8,9,4]  R2533     -1.6300510615110397e-03
    z[8,9,4]  R2534     -1.1140790581703186e-01
    z[8,9,4]  R2535     1.9025810062885284e-01
    z[8,9,4]  R2536     2.1849417686462402e-01
    z[8,9,4]  R2537     6.2847083806991577e-01
    z[8,9,4]  R2538     2.0253662765026093e-01
    z[8,9,4]  R2539     4.2726555466651917e-01
    z[8,9,4]  R2540     4.5717346668243408e-01
    z[8,9,4]  R2541     -0.00543689401820302
    z[8,9,4]  R2542     1.8286738544702530e-02
    z[8,9,4]  R2543     2.8732625767588615e-02
    z[8,9,4]  R2544     -3.3437472581863403e-01
    z[8,9,5]  R79       -1
    z[8,9,5]  R88       1
    z[8,9,5]  R2411     -1
    z[8,9,5]  R2412     1
    z[8,9,5]  R2415     1.9142253696918488e-01
    z[8,9,5]  R2416     -8.3000678569078445e-03
    z[8,9,5]  R2417     2.2672009468078613e-01
    z[8,9,5]  R2418     1.7032565176486969e-01
    z[8,9,5]  R2419     1.7105570435523987e-01
    z[8,9,5]  R2420     1.1228091269731522e-01
    z[8,9,5]  R2421     1.4679941534996033e-01
    z[8,9,5]  R2422     3.5912382602691650e-01
    z[8,9,5]  R2423     6.0152035951614380e-01
    z[8,9,5]  R2424     2.2390134632587433e-01
    z[8,9,5]  R2425     -3.1453219056129456e-01
    z[8,9,5]  R2426     2.8494027256965637e-01
    z[8,9,5]  R2427     -2.5033742189407349e-01
    z[8,9,5]  R2428     -0.0385163351893425
    z[8,9,5]  R2429     3.2776869833469391e-02
    z[8,9,5]  R2430     -8.3212591707706451e-02
    z[8,9,5]  R2431     -3.6018621176481247e-02
    z[8,9,5]  R2432     4.1902983188629150e-01
    z[8,9,5]  R2433     0.0738268494606018
    z[8,9,5]  R2434     1.2479127198457718e-01
    z[8,9,5]  R2435     -1.9711649417877197e-01
    z[8,9,5]  R2436     3.1322799623012543e-02
    z[8,9,5]  R2437     1.9233305752277374e-01
    z[8,9,5]  R2438     9.2855080962181091e-02
    z[8,9,5]  R2439     -3.3176234364509583e-01
    z[8,9,5]  R2440     3.1827205419540405e-01
    z[8,9,5]  R2441     -3.6571016907691956e-01
    z[8,9,5]  R2442     -0.0894322618842125
    z[8,9,5]  R2443     -2.6702433824539185e-01
    z[8,9,5]  R2444     -6.9068334996700287e-03
    z[8,9,5]  R2445     -2.2181174159049988e-01
    z[8,9,5]  R2446     -6.7543298006057739e-02
    z[8,9,5]  R2447     3.3199369907379150e-01
    z[8,9,5]  R2448     2.7365097403526306e-01
    z[8,9,5]  R2449     -4.5686885714530945e-02
    z[8,9,5]  R2450     -5.0309556722640991e-01
    z[8,9,5]  R2451     1.7004017531871796e-01
    z[8,9,5]  R2452     -3.9104998111724854e-01
    z[8,9,5]  R2453     4.3170547485351562e-01
    z[8,9,5]  R2454     3.9537000656127930e-01
    z[8,9,5]  R2455     1.9739224016666412e-01
    z[8,9,5]  R2456     -1.0161225683987141e-02
    z[8,9,5]  R2457     -2.2046926617622375e-01
    z[8,9,5]  R2458     -1.1617458611726761e-01
    z[8,9,5]  R2459     -2.7370089292526245e-01
    z[8,9,5]  R2460     2.6169112324714661e-01
    z[8,9,5]  R2461     -3.1920078396797180e-01
    z[8,9,5]  R2462     -0.0718526765704155
    z[8,9,5]  R2463     -3.7679579108953476e-02
    z[8,9,5]  R2464     -1.6701023280620575e-01
    z[8,9,5]  R2465     1.8614935874938965e-01
    z[8,9,5]  R2466     9.3117326498031616e-02
    z[8,9,5]  R2467     2.7580955624580383e-01
    z[8,9,5]  R2468     5.5818080902099609e-01
    z[8,9,5]  R2469     3.9974045753479004e-01
    z[8,9,5]  R2470     2.8213381767272949e-01
    z[8,9,5]  R2471     5.1896089315414429e-01
    z[8,9,5]  R2472     3.3511513471603394e-01
    z[8,9,5]  R2473     7.2859209775924683e-01
    z[8,9,5]  R2474     1.1801747605204582e-02
    z[8,9,5]  R2475     6.0959124565124512e-01
    z[8,9,5]  R2476     6.8604147434234619e-01
    z[8,9,5]  R2477     5.3980922698974609e-01
    z[8,9,5]  R2478     6.4250773191452026e-01
    z[8,9,5]  R2479     1.0501185804605484e-01
    z[8,9,5]  R2480     -0.0551178939640522
    z[8,9,5]  R2481     -4.7281570732593536e-02
    z[8,9,5]  R2482     -1.8524868786334991e-01
    z[8,9,5]  R2483     4.8076584935188293e-01
    z[8,9,5]  R2484     1.7615149915218353e-01
    z[8,9,5]  R2485     -3.2450765371322632e-02
    z[8,9,5]  R2486     -2.6499629020690918e-01
    z[8,9,5]  R2487     -2.2803871333599091e-01
    z[8,9,5]  R2488     -4.5225575566291809e-01
    z[8,9,5]  R2489     -2.0371034741401672e-01
    z[8,9,5]  R2490     1.9490176811814308e-02
    z[8,9,5]  R2491     4.2251139879226685e-01
    z[8,9,5]  R2492     -7.7622950077056885e-02
    z[8,9,5]  R2493     -5.9538954496383667e-01
    z[8,9,5]  R2494     -3.1654247641563416e-01
    z[8,9,5]  R2495     -2.1380858495831490e-02
    z[8,9,5]  R2496     3.6986616253852844e-01
    z[8,9,5]  R2497     -2.9593309760093689e-01
    z[8,9,5]  R2498     1.3574530184268951e-01
    z[8,9,5]  R2499     -1.8741288781166077e-01
    z[8,9,5]  R2500     1.8684232234954834e-01
    z[8,9,5]  R2501     -3.0348542332649231e-01
    z[8,9,5]  R2502     -2.4751265347003937e-01
    z[8,9,5]  R2503     -0.0328182727098465
    z[8,9,5]  R2504     -8.9843444526195526e-02
    z[8,9,5]  R2505     -1.9645778834819794e-01
    z[8,9,5]  R2506     -1.1482248082756996e-03
    z[8,9,5]  R2507     3.2897189259529114e-02
    z[8,9,5]  R2508     -1.6976065933704376e-01
    z[8,9,5]  R2509     3.4776532649993896e-01
    z[8,9,5]  R2510     -4.6710196137428284e-01
    z[8,9,5]  R2511     -5.9684950113296509e-01
    z[8,9,5]  R2512     -0.605772852897644
    z[8,9,5]  R2513     -4.8108381032943726e-01
    z[8,9,5]  R2514     -1.9799204170703888e-01
    z[8,9,5]  R2515     6.4184987545013428e-01
    z[8,9,5]  R2516     3.9485642313957214e-01
    z[8,9,5]  R2517     3.1156671047210693e-01
    z[8,9,5]  R2518     -1.9592662155628204e-01
    z[8,9,5]  R2519     -2.3011548817157745e-01
    z[8,9,5]  R2520     1.0768519714474678e-02
    z[8,9,5]  R2521     -9.4771005213260651e-02
    z[8,9,5]  R2522     1.3257928192615509e-01
    z[8,9,5]  R2523     1.5410327911376953e-01
    z[8,9,5]  R2524     -3.1746536493301392e-01
    z[8,9,5]  R2525     -2.8857348486781120e-02
    z[8,9,5]  R2526     3.4091625362634659e-02
    z[8,9,5]  R2527     4.4156581163406372e-01
    z[8,9,5]  R2528     -1.4573523402214050e-01
    z[8,9,5]  R2529     -5.5646669119596481e-02
    z[8,9,5]  R2530     3.8169354200363159e-02
    z[8,9,5]  R2531     -3.1596621870994568e-01
    z[8,9,5]  R2532     -4.7881278395652771e-01
    z[8,9,5]  R2533     -5.1543056964874268e-01
    z[8,9,5]  R2534     -2.6525703072547913e-01
    z[8,9,5]  R2535     1.2550760805606842e-01
    z[8,9,5]  R2536     3.5498419404029846e-01
    z[8,9,5]  R2537     8.3474688231945038e-02
    z[8,9,5]  R2538     3.2502165436744690e-01
    z[8,9,5]  R2539     -3.1508678197860718e-01
    z[8,9,5]  R2540     -3.2217675447463989e-01
    z[8,9,5]  R2541     2.5536064058542252e-02
    z[8,9,5]  R2542     -4.1888780891895294e-02
    z[8,9,5]  R2543     -5.7469010353088379e-01
    z[8,9,5]  R2544     -1.2234982103109360e-01
    z[8,9,6]  R80       -1
    z[8,9,6]  R89       1
    z[8,9,6]  R2413     -1
    z[8,9,6]  R2414     1
    z[8,9,6]  R2415     9.5573388040065765e-02
    z[8,9,6]  R2416     -0.00667816074565053
    z[8,9,6]  R2417     8.5651800036430359e-02
    z[8,9,6]  R2418     -4.6514865010976791e-02
    z[8,9,6]  R2419     4.4298145920038223e-02
    z[8,9,6]  R2420     -1.6526412963867188e-01
    z[8,9,6]  R2421     -8.2540504634380341e-02
    z[8,9,6]  R2422     -4.0713074803352356e-01
    z[8,9,6]  R2423     1.9813652336597443e-01
    z[8,9,6]  R2424     0.0846172571182251
    z[8,9,6]  R2425     -6.6600787639617920e-01
    z[8,9,6]  R2426     6.8968725204467773e-01
    z[8,9,6]  R2427     4.7490417957305908e-01
    z[8,9,6]  R2428     -3.8561765104532242e-02
    z[8,9,6]  R2429     0.0684349462389946
    z[8,9,6]  R2430     4.2259924113750458e-02
    z[8,9,6]  R2431     2.1167999505996704e-01
    z[8,9,6]  R2432     -3.7862819153815508e-03
    z[8,9,6]  R2433     -1.4978150138631463e-03
    z[8,9,6]  R2434     2.1710345149040222e-01
    z[8,9,6]  R2435     4.1864126920700073e-02
    z[8,9,6]  R2436     -1.5669718384742737e-02
    z[8,9,6]  R2437     -1.4252914488315582e-01
    z[8,9,6]  R2438     2.5085920095443726e-01
    z[8,9,6]  R2439     -1.4304542541503906e-01
    z[8,9,6]  R2440     -4.8893624544143677e-01
    z[8,9,6]  R2441     8.6534790694713593e-02
    z[8,9,6]  R2442     -2.7721837162971497e-01
    z[8,9,6]  R2443     5.4862993955612183e-01
    z[8,9,6]  R2444     -2.4678014218807220e-01
    z[8,9,6]  R2445     -3.0206772685050964e-01
    z[8,9,6]  R2446     -1.4944548904895782e-01
    z[8,9,6]  R2447     -1.8581999838352203e-01
    z[8,9,6]  R2448     3.8092538714408875e-01
    z[8,9,6]  R2449     4.7314144670963287e-02
    z[8,9,6]  R2450     -2.9051521420478821e-01
    z[8,9,6]  R2451     -5.1917988061904907e-01
    z[8,9,6]  R2452     -2.5268509984016418e-02
    z[8,9,6]  R2453     6.8412572145462036e-02
    z[8,9,6]  R2454     -4.0220993757247925e-01
    z[8,9,6]  R2455     -1.0235381871461868e-01
    z[8,9,6]  R2456     1.0922455042600632e-01
    z[8,9,6]  R2457     2.1418869495391846e-01
    z[8,9,6]  R2458     -4.9310860037803650e-01
    z[8,9,6]  R2459     -3.3329862356185913e-01
    z[8,9,6]  R2460     -4.9258375167846680e-01
    z[8,9,6]  R2461     9.8725304007530212e-02
    z[8,9,6]  R2462     -1.6802644729614258e-01
    z[8,9,6]  R2463     -1.6861614584922791e-01
    z[8,9,6]  R2464     -0.218696728348732
    z[8,9,6]  R2465     -2.1060292422771454e-01
    z[8,9,6]  R2466     -6.7212447524070740e-02
    z[8,9,6]  R2467     -2.0458398386836052e-02
    z[8,9,6]  R2468     -5.2033051848411560e-02
    z[8,9,6]  R2469     1.4600904285907745e-01
    z[8,9,6]  R2470     -3.9462402462959290e-01
    z[8,9,6]  R2471     0.00793476216495037
    z[8,9,6]  R2472     -2.1063642203807831e-01
    z[8,9,6]  R2473     2.5378491729497910e-02
    z[8,9,6]  R2474     6.3474170863628387e-02
    z[8,9,6]  R2475     -4.5436579734086990e-02
    z[8,9,6]  R2476     1.3276310265064240e-01
    z[8,9,6]  R2477     -1.7145794630050659e-01
    z[8,9,6]  R2478     4.4282466173171997e-01
    z[8,9,6]  R2479     1.1576970666646957e-01
    z[8,9,6]  R2480     1.3626264035701752e-01
    z[8,9,6]  R2481     4.5209395885467529e-01
    z[8,9,6]  R2482     -2.9960680007934570e-01
    z[8,9,6]  R2483     -6.1643189191818237e-01
    z[8,9,6]  R2484     1.3172204792499542e-01
    z[8,9,6]  R2485     5.9821295738220215e-01
    z[8,9,6]  R2486     -6.0290664434432983e-01
    z[8,9,6]  R2487     -5.3319036960601807e-01
    z[8,9,6]  R2488     9.2168338596820831e-02
    z[8,9,6]  R2489     -3.1946465373039246e-01
    z[8,9,6]  R2490     -3.0811068415641785e-01
    z[8,9,6]  R2491     -6.1776839196681976e-02
    z[8,9,6]  R2492     -1.9178394973278046e-01
    z[8,9,6]  R2493     -0.0774015337228775
    z[8,9,6]  R2494     1.2274991720914841e-01
    z[8,9,6]  R2495     1.9521857798099518e-01
    z[8,9,6]  R2496     -2.3522333800792694e-01
    z[8,9,6]  R2497     -4.9021661281585693e-02
    z[8,9,6]  R2498     -1.4449508488178253e-01
    z[8,9,6]  R2499     -3.9919081330299377e-01
    z[8,9,6]  R2500     -4.1840910911560059e-01
    z[8,9,6]  R2501     -0.0537693053483963
    z[8,9,6]  R2502     2.9884251952171326e-01
    z[8,9,6]  R2503     -1.2494862079620361e-01
    z[8,9,6]  R2504     -9.6965618431568146e-02
    z[8,9,6]  R2505     -1.0616531595587730e-02
    z[8,9,6]  R2506     -1.4885148033499718e-02
    z[8,9,6]  R2507     -2.7475917339324951e-01
    z[8,9,6]  R2508     2.2646412253379822e-01
    z[8,9,6]  R2509     8.6878068745136261e-02
    z[8,9,6]  R2510     2.5030277669429779e-02
    z[8,9,6]  R2511     2.5785481929779053e-01
    z[8,9,6]  R2512     -2.1536734700202942e-01
    z[8,9,6]  R2513     4.1040789335966110e-02
    z[8,9,6]  R2514     0.205540731549263
    z[8,9,6]  R2515     -0.342171311378479
    z[8,9,6]  R2516     -1.0002993047237396e-01
    z[8,9,6]  R2517     3.2614961266517639e-01
    z[8,9,6]  R2518     7.5960271060466766e-03
    z[8,9,6]  R2519     -6.0785752721130848e-03
    z[8,9,6]  R2520     -3.8614797592163086e-01
    z[8,9,6]  R2521     -1.1958386749029160e-01
    z[8,9,6]  R2522     -1.9437422975897789e-02
    z[8,9,6]  R2523     -6.9461479783058167e-02
    z[8,9,6]  R2524     1.9744911789894104e-01
    z[8,9,6]  R2525     -2.9330024123191833e-01
    z[8,9,6]  R2526     -3.4934807568788528e-02
    z[8,9,6]  R2527     2.2088389098644257e-01
    z[8,9,6]  R2528     1.3635644316673279e-01
    z[8,9,6]  R2529     -1.0868085175752640e-01
    z[8,9,6]  R2530     1.6315829753875732e-01
    z[8,9,6]  R2531     4.0994000434875488e-01
    z[8,9,6]  R2532     2.5183673948049545e-02
    z[8,9,6]  R2533     4.0462979674339294e-01
    z[8,9,6]  R2534     -3.1075802445411682e-01
    z[8,9,6]  R2535     3.1362724304199219e-01
    z[8,9,6]  R2536     2.3466531932353973e-01
    z[8,9,6]  R2537     -6.3345089554786682e-02
    z[8,9,6]  R2538     -3.3809497952461243e-02
    z[8,9,6]  R2539     -2.1018752455711365e-01
    z[8,9,6]  R2540     2.7088707685470581e-01
    z[8,9,6]  R2541     -2.2203331813216209e-02
    z[8,9,6]  R2542     4.9485091120004654e-02
    z[8,9,6]  R2543     9.9782370030879974e-02
    z[8,9,6]  R2544     -2.5111085176467896e-01
    z[9,8,0]  R74       1
    z[9,8,0]  R83       -1
    z[9,8,0]  R2545     -1
    z[9,8,0]  R2546     1
    z[9,8,0]  R2559     -4.1501635313034058e-01
    z[9,8,0]  R2560     -6.1638349294662476e-01
    z[9,8,0]  R2561     -1.2898580729961395e-01
    z[9,8,0]  R2562     -1.0595534741878510e-01
    z[9,8,0]  R2563     -2.1235486865043640e-01
    z[9,8,0]  R2564     -3.5595887899398804e-01
    z[9,8,0]  R2565     -4.8017153143882751e-01
    z[9,8,0]  R2566     -3.4229013323783875e-01
    z[9,8,0]  R2567     -3.6051180958747864e-01
    z[9,8,0]  R2568     1.0068622976541519e-01
    z[9,8,0]  R2569     -6.2879495322704315e-02
    z[9,8,0]  R2570     2.3196329176425934e-01
    z[9,8,0]  R2571     -1.3041956722736359e-01
    z[9,8,0]  R2572     0.473922997713089
    z[9,8,0]  R2573     4.8206233978271484e-01
    z[9,8,0]  R2574     4.1645923256874084e-01
    z[9,8,0]  R2575     2.4854870140552521e-01
    z[9,8,0]  R2576     5.7460528612136841e-01
    z[9,8,0]  R2577     -0.0876041129231453
    z[9,8,0]  R2578     -7.3631328344345093e-01
    z[9,8,0]  R2579     2.2810553014278412e-01
    z[9,8,0]  R2580     1.8212832510471344e-01
    z[9,8,0]  R2581     5.9286877512931824e-02
    z[9,8,0]  R2582     5.3127199411392212e-01
    z[9,8,0]  R2583     -1.2675017118453979e-01
    z[9,8,0]  R2584     -3.8847783207893372e-01
    z[9,8,0]  R2585     -2.9837992787361145e-01
    z[9,8,0]  R2586     2.4467872083187103e-01
    z[9,8,0]  R2587     2.3737061023712158e-01
    z[9,8,0]  R2588     7.8550964593887329e-02
    z[9,8,0]  R2589     -2.1258579194545746e-01
    z[9,8,0]  R2590     4.4759336113929749e-01
    z[9,8,0]  R2591     2.6186940073966980e-01
    z[9,8,0]  R2592     1.5955546498298645e-01
    z[9,8,0]  R2593     -2.0481684803962708e-01
    z[9,8,0]  R2594     -0.731015682220459
    z[9,8,0]  R2595     -8.7707176804542542e-02
    z[9,8,0]  R2596     -3.4270800650119781e-02
    z[9,8,0]  R2597     1.9785304367542267e-01
    z[9,8,0]  R2598     6.9680482149124146e-02
    z[9,8,0]  R2599     -2.8917935490608215e-01
    z[9,8,0]  R2600     -3.6127030849456787e-02
    z[9,8,0]  R2601     3.6400923132896423e-01
    z[9,8,0]  R2602     -0.0682537704706192
    z[9,8,0]  R2603     -2.4083405733108521e-01
    z[9,8,0]  R2604     6.7271322011947632e-01
    z[9,8,0]  R2605     2.8718367218971252e-01
    z[9,8,0]  R2606     3.4148886799812317e-01
    z[9,8,0]  R2607     -2.5947546958923340e-01
    z[9,8,0]  R2608     -7.9348587989807129e-01
    z[9,8,0]  R2609     -1.9329544901847839e-01
    z[9,8,0]  R2610     5.1389408111572266e-01
    z[9,8,0]  R2611     6.2059406191110611e-02
    z[9,8,0]  R2612     5.0344061106443405e-02
    z[9,8,0]  R2613     -3.3465296030044556e-02
    z[9,8,0]  R2614     -4.9066618084907532e-01
    z[9,8,0]  R2615     5.8313506841659546e-01
    z[9,8,0]  R2616     -7.7286720275878906e-01
    z[9,8,0]  R2617     -0.721823513507843
    z[9,8,0]  R2618     -6.4657241106033325e-01
    z[9,8,0]  R2619     2.1939818561077118e-01
    z[9,8,0]  R2620     2.8270853683352470e-02
    z[9,8,0]  R2621     -5.1187032461166382e-01
    z[9,8,0]  R2622     -1.3031905889511108e-01
    z[9,8,0]  R2623     -7.7040952444076538e-01
    z[9,8,0]  R2624     1.8976368010044098e-01
    z[9,8,0]  R2625     0.847102701663971
    z[9,8,0]  R2626     8.4951055049896240e-01
    z[9,8,0]  R2627     3.1519749760627747e-01
    z[9,8,0]  R2628     9.7910448908805847e-02
    z[9,8,0]  R2629     -8.2706409692764282e-01
    z[9,8,0]  R2630     -9.1056984663009644e-01
    z[9,8,0]  R2631     -0.896411120891571
    z[9,8,0]  R2632     -7.7990359067916870e-01
    z[9,8,0]  R2633     -8.9173072576522827e-01
    z[9,8,0]  R2634     -8.0726486444473267e-01
    z[9,8,0]  R2635     -7.5758165121078491e-01
    z[9,8,0]  R2636     -6.9680100679397583e-01
    z[9,8,0]  R2637     -6.8020689487457275e-01
    z[9,8,0]  R2638     8.8735990226268768e-02
    z[9,8,0]  R2639     4.9224663525819778e-02
    z[9,8,0]  R2640     3.1487852334976196e-01
    z[9,8,0]  R2641     3.5001170635223389e-01
    z[9,8,0]  R2642     3.3615925908088684e-01
    z[9,8,0]  R2643     2.7263092994689941e-01
    z[9,8,0]  R2644     2.4038107693195343e-01
    z[9,8,0]  R2645     3.2954993844032288e-01
    z[9,8,0]  R2646     2.7537909150123596e-01
    z[9,8,0]  R2647     4.1178759932518005e-01
    z[9,8,0]  R2648     0.595511794090271
    z[9,8,0]  R2649     -0.0982019230723381
    z[9,8,0]  R2650     2.6607644557952881e-01
    z[9,8,0]  R2651     1.4676716923713684e-01
    z[9,8,0]  R2652     1.4686042070388794e-01
    z[9,8,0]  R2653     1.1764391511678696e-01
    z[9,8,0]  R2654     -4.9060784280300140e-02
    z[9,8,0]  R2655     -1.3944949209690094e-01
    z[9,8,0]  R2656     -3.4394964575767517e-01
    z[9,8,0]  R2657     -1.0979624092578888e-01
    z[9,8,0]  R2658     1.1869938671588898e-01
    z[9,8,0]  R2659     -2.8038039803504944e-01
    z[9,8,0]  R2660     1.5873451530933380e-01
    z[9,8,0]  R2661     3.6990955471992493e-02
    z[9,8,0]  R2662     1.4406321942806244e-01
    z[9,8,0]  R2663     9.2446029186248779e-02
    z[9,8,0]  R2664     1.0045155882835388e-01
    z[9,8,0]  R2665     2.3465298116207123e-01
    z[9,8,0]  R2666     1.7545820772647858e-01
    z[9,8,0]  R2667     -4.4613018631935120e-02
    z[9,8,0]  R2668     -4.5370548963546753e-02
    z[9,8,0]  R2669     1.1342381127178669e-02
    z[9,8,0]  R2670     0.00920828152447939
    z[9,8,0]  R2671     1.2489434331655502e-01
    z[9,8,0]  R2672     2.1298396587371826e-01
    z[9,8,0]  R2673     7.2609391063451767e-03
    z[9,8,0]  R2674     1.0130155831575394e-02
    z[9,8,0]  R2675     3.2253018021583557e-01
    z[9,8,0]  R2676     6.7334115505218506e-01
    z[9,8,0]  R2677     0.282462477684021
    z[9,8,0]  R2678     3.3619120717048645e-01
    z[9,8,0]  R2679     7.9640835523605347e-01
    z[9,8,0]  R2680     9.1283661127090454e-01
    z[9,8,0]  R2681     8.2904303073883057e-01
    z[9,8,0]  R2682     7.7248513698577881e-01
    z[9,8,0]  R2683     2.1900284290313721e-01
    z[9,8,0]  R2684     7.6090240478515625e-01
    z[9,8,0]  R2685     0.59315025806427
    z[9,8,0]  R2686     5.6900697946548462e-01
    z[9,8,0]  R2687     4.3024361133575439e-01
    z[9,8,0]  R2688     5.2603250741958618e-01
    z[9,8,1]  R75       1
    z[9,8,1]  R84       -1
    z[9,8,1]  R2547     -1
    z[9,8,1]  R2548     1
    z[9,8,1]  R2559     -8.0737462267279625e-03
    z[9,8,1]  R2560     1.4230413734912872e-01
    z[9,8,1]  R2561     2.2624358534812927e-02
    z[9,8,1]  R2562     2.3977272212505341e-01
    z[9,8,1]  R2563     0.528877854347229
    z[9,8,1]  R2564     -4.0463000535964966e-01
    z[9,8,1]  R2565     2.2134327888488770e-01
    z[9,8,1]  R2566     3.5330925136804581e-02
    z[9,8,1]  R2567     7.0831492543220520e-02
    z[9,8,1]  R2568     -7.0181339979171753e-02
    z[9,8,1]  R2569     -7.0611411333084106e-01
    z[9,8,1]  R2570     -7.0038020610809326e-01
    z[9,8,1]  R2571     -5.3251928091049194e-01
    z[9,8,1]  R2572     -5.2856034040451050e-01
    z[9,8,1]  R2573     -6.2404000759124756e-01
    z[9,8,1]  R2574     -6.9835889339447021e-01
    z[9,8,1]  R2575     -4.2886650562286377e-01
    z[9,8,1]  R2576     -6.2193077802658081e-01
    z[9,8,1]  R2577     -5.5906790494918823e-01
    z[9,8,1]  R2578     -2.4140434339642525e-02
    z[9,8,1]  R2579     -7.4764102697372437e-01
    z[9,8,1]  R2580     -6.5758311748504639e-01
    z[9,8,1]  R2581     -6.6996800899505615e-01
    z[9,8,1]  R2582     -6.4960908889770508e-01
    z[9,8,1]  R2583     -6.0257738828659058e-01
    z[9,8,1]  R2584     -7.6623803377151489e-01
    z[9,8,1]  R2585     -7.8444540500640869e-01
    z[9,8,1]  R2586     -4.3566080927848816e-01
    z[9,8,1]  R2587     -5.9862571954727173e-01
    z[9,8,1]  R2588     -5.6945592164993286e-01
    z[9,8,1]  R2589     -9.3129861354827881e-01
    z[9,8,1]  R2590     -7.7635931968688965e-01
    z[9,8,1]  R2591     -6.7822271585464478e-01
    z[9,8,1]  R2592     -6.6880780458450317e-01
    z[9,8,1]  R2593     -4.9056935310363770e-01
    z[9,8,1]  R2594     1.4509424567222595e-01
    z[9,8,1]  R2595     5.1353760063648224e-02
    z[9,8,1]  R2596     6.5615244209766388e-02
    z[9,8,1]  R2597     3.6510124802589417e-01
    z[9,8,1]  R2598     2.5187534093856812e-01
    z[9,8,1]  R2599     -5.2829945087432861e-01
    z[9,8,1]  R2600     -5.9183764457702637e-01
    z[9,8,1]  R2601     -6.8946105241775513e-01
    z[9,8,1]  R2602     -5.8173561096191406e-01
    z[9,8,1]  R2603     -4.5227476954460144e-01
    z[9,8,1]  R2604     -5.3008455038070679e-01
    z[9,8,1]  R2605     -6.2674248218536377e-01
    z[9,8,1]  R2606     -1.7841532826423645e-01
    z[9,8,1]  R2607     -7.3125049471855164e-02
    z[9,8,1]  R2608     2.7809736132621765e-01
    z[9,8,1]  R2609     -8.5583233833312988e-01
    z[9,8,1]  R2610     -6.5710622072219849e-01
    z[9,8,1]  R2611     -4.3961033225059509e-01
    z[9,8,1]  R2612     -3.8813760876655579e-01
    z[9,8,1]  R2613     -4.3275612592697144e-01
    z[9,8,1]  R2614     -6.7361706495285034e-01
    z[9,8,1]  R2615     -5.6662166118621826e-01
    z[9,8,1]  R2616     -3.2149741053581238e-01
    z[9,8,1]  R2617     -1.5396389365196228e-01
    z[9,8,1]  R2618     -8.5054852068424225e-02
    z[9,8,1]  R2619     -8.5403424501419067e-01
    z[9,8,1]  R2620     -4.9898526072502136e-01
    z[9,8,1]  R2621     -3.9110168814659119e-01
    z[9,8,1]  R2622     -7.5024962425231934e-01
    z[9,8,1]  R2623     -2.7281123399734497e-01
    z[9,8,1]  R2624     4.3152235448360443e-02
    z[9,8,1]  R2625     5.2607440948486328e-01
    z[9,8,1]  R2626     5.0985753536224365e-01
    z[9,8,1]  R2627     5.1093775779008865e-02
    z[9,8,1]  R2628     5.5250930786132812e-01
    z[9,8,1]  R2629     -3.8884587585926056e-02
    z[9,8,1]  R2630     -2.8132705017924309e-02
    z[9,8,1]  R2631     1.3578535616397858e-01
    z[9,8,1]  R2632     -8.7959386408329010e-02
    z[9,8,1]  R2633     0.0275983028113842
    z[9,8,1]  R2634     0.268432080745697
    z[9,8,1]  R2635     4.5238915085792542e-01
    z[9,8,1]  R2636     2.9841421172022820e-02
    z[9,8,1]  R2637     1.1943578720092773e-01
    z[9,8,1]  R2638     -8.0063328146934509e-02
    z[9,8,1]  R2639     -6.2669318914413452e-01
    z[9,8,1]  R2640     -3.9516237378120422e-01
    z[9,8,1]  R2641     -3.8031238317489624e-01
    z[9,8,1]  R2642     7.9426276683807373e-01
    z[9,8,1]  R2643     8.2045537233352661e-01
    z[9,8,1]  R2644     8.8006341457366943e-01
    z[9,8,1]  R2645     8.8734275102615356e-01
    z[9,8,1]  R2646     -3.7226536870002747e-01
    z[9,8,1]  R2647     8.6910420656204224e-01
    z[9,8,1]  R2648     -2.3682117462158203e-01
    z[9,8,1]  R2649     -9.3146163225173950e-01
    z[9,8,1]  R2650     -7.6777690649032593e-01
    z[9,8,1]  R2651     -9.0915805101394653e-01
    z[9,8,1]  R2652     -8.3823961019515991e-01
    z[9,8,1]  R2653     -0.82839035987854
    z[9,8,1]  R2654     -0.780409038066864
    z[9,8,1]  R2655     -7.5964945554733276e-01
    z[9,8,1]  R2656     -8.2713586091995239e-01
    z[9,8,1]  R2657     -6.8862271308898926e-01
    z[9,8,1]  R2658     -7.0851981639862061e-01
    z[9,8,1]  R2659     -8.1212782859802246e-01
    z[9,8,1]  R2660     8.8121265172958374e-01
    z[9,8,1]  R2661     8.4028065204620361e-01
    z[9,8,1]  R2662     7.6849848031997681e-01
    z[9,8,1]  R2663     8.1701892614364624e-01
    z[9,8,1]  R2664     7.8537470102310181e-01
    z[9,8,1]  R2665     0.756335437297821
    z[9,8,1]  R2666     6.2838083505630493e-01
    z[9,8,1]  R2667     4.9951234459877014e-01
    z[9,8,1]  R2668     5.2126449346542358e-01
    z[9,8,1]  R2669     8.6326146125793457e-01
    z[9,8,1]  R2670     9.1128599643707275e-01
    z[9,8,1]  R2671     8.3672732114791870e-01
    z[9,8,1]  R2672     8.1179004907608032e-01
    z[9,8,1]  R2673     7.5844889879226685e-01
    z[9,8,1]  R2674     5.5628603696823120e-01
    z[9,8,1]  R2675     4.1705000400543213e-01
    z[9,8,1]  R2676     6.1076825857162476e-01
    z[9,8,1]  R2677     3.4541657567024231e-01
    z[9,8,1]  R2678     3.7452796101570129e-01
    z[9,8,1]  R2679     4.6728920936584473e-01
    z[9,8,1]  R2680     1.5661269426345825e-01
    z[9,8,1]  R2681     2.0572523772716522e-01
    z[9,8,1]  R2682     1.5655416250228882e-01
    z[9,8,1]  R2683     4.1292944550514221e-01
    z[9,8,1]  R2684     1.3044695556163788e-01
    z[9,8,1]  R2685     2.1109478175640106e-01
    z[9,8,1]  R2686     1.3563109934329987e-01
    z[9,8,1]  R2687     5.2235114574432373e-01
    z[9,8,1]  R2688     3.5238561034202576e-01
    z[9,8,2]  R76       1
    z[9,8,2]  R85       -1
    z[9,8,2]  R2549     -1
    z[9,8,2]  R2550     1
    z[9,8,2]  R2559     1.0386286303400993e-03
    z[9,8,2]  R2560     -4.5047495514154434e-02
    z[9,8,2]  R2561     -3.8759005069732666e-01
    z[9,8,2]  R2562     -1.3593223690986633e-01
    z[9,8,2]  R2563     -2.0350408554077148e-01
    z[9,8,2]  R2564     1.3394263386726379e-01
    z[9,8,2]  R2565     3.4943490754812956e-03
    z[9,8,2]  R2566     -1.4786422252655029e-01
    z[9,8,2]  R2567     -2.1904994547367096e-01
    z[9,8,2]  R2568     7.6188242435455322e-01
    z[9,8,2]  R2569     2.6483091711997986e-01
    z[9,8,2]  R2570     1.2022143602371216e-01
    z[9,8,2]  R2571     2.6209217309951782e-01
    z[9,8,2]  R2572     5.0239282846450806e-01
    z[9,8,2]  R2573     7.1645148098468781e-02
    z[9,8,2]  R2574     4.8133295774459839e-01
    z[9,8,2]  R2575     5.5973953008651733e-01
    z[9,8,2]  R2576     4.6483024954795837e-01
    z[9,8,2]  R2577     -2.7340808510780334e-01
    z[9,8,2]  R2578     -3.8282856345176697e-01
    z[9,8,2]  R2579     5.0953525304794312e-01
    z[9,8,2]  R2580     4.2274218797683716e-01
    z[9,8,2]  R2581     4.0736341476440430e-01
    z[9,8,2]  R2582     4.7930145263671875e-01
    z[9,8,2]  R2583     0.506238579750061
    z[9,8,2]  R2584     -0.0528477281332016
    z[9,8,2]  R2585     1.1037375032901764e-01
    z[9,8,2]  R2586     -5.6048955768346786e-02
    z[9,8,2]  R2587     -1.8911965191364288e-01
    z[9,8,2]  R2588     -6.1571896076202393e-01
    z[9,8,2]  R2589     -1.0740020871162415e-01
    z[9,8,2]  R2590     -3.3411350846290588e-01
    z[9,8,2]  R2591     -3.0589619278907776e-01
    z[9,8,2]  R2592     -6.4837050437927246e-01
    z[9,8,2]  R2593     5.5570787191390991e-01
    z[9,8,2]  R2594     1.3312242925167084e-01
    z[9,8,2]  R2595     -1.6032233834266663e-02
    z[9,8,2]  R2596     -2.3102298378944397e-01
    z[9,8,2]  R2597     -1.2256371974945068e-01
    z[9,8,2]  R2598     1.2075113505125046e-01
    z[9,8,2]  R2599     -2.2346045076847076e-01
    z[9,8,2]  R2600     0.60540372133255
    z[9,8,2]  R2601     2.0606490969657898e-01
    z[9,8,2]  R2602     -3.6067304015159607e-01
    z[9,8,2]  R2603     6.7916673421859741e-01
    z[9,8,2]  R2604     1.0233601182699203e-01
    z[9,8,2]  R2605     -4.0065848827362061e-01
    z[9,8,2]  R2606     5.6349843740463257e-01
    z[9,8,2]  R2607     4.7895425558090210e-01
    z[9,8,2]  R2608     -2.0525640249252319e-01
    z[9,8,2]  R2609     1.1915708333253860e-01
    z[9,8,2]  R2610     -2.4162931367754936e-02
    z[9,8,2]  R2611     6.9115614891052246e-01
    z[9,8,2]  R2612     2.3771961033344269e-01
    z[9,8,2]  R2613     5.9727275371551514e-01
    z[9,8,2]  R2614     3.7660089135169983e-01
    z[9,8,2]  R2615     -8.1534683704376221e-02
    z[9,8,2]  R2616     1.6884498298168182e-01
    z[9,8,2]  R2617     0.0457034595310688
    z[9,8,2]  R2618     -6.0023766756057739e-01
    z[9,8,2]  R2619     2.0172378420829773e-01
    z[9,8,2]  R2620     7.1617412567138672e-01
    z[9,8,2]  R2621     4.1023689508438110e-01
    z[9,8,2]  R2622     2.5607201457023621e-01
    z[9,8,2]  R2623     5.2217740565538406e-02
    z[9,8,2]  R2624     8.9033029973506927e-02
    z[9,8,2]  R2625     -6.4803071320056915e-02
    z[9,8,2]  R2626     8.8083133101463318e-02
    z[9,8,2]  R2627     -2.4576622247695923e-01
    z[9,8,2]  R2628     6.7231643199920654e-01
    z[9,8,2]  R2629     3.7001019716262817e-01
    z[9,8,2]  R2630     3.9191324263811111e-02
    z[9,8,2]  R2631     -2.3739559948444366e-01
    z[9,8,2]  R2632     4.1689342260360718e-01
    z[9,8,2]  R2633     -2.1192955970764160e-01
    z[9,8,2]  R2634     1.5318708121776581e-01
    z[9,8,2]  R2635     1.5639486908912659e-01
    z[9,8,2]  R2636     2.1300381422042847e-01
    z[9,8,2]  R2637     1.4234852790832520e-01
    z[9,8,2]  R2638     6.1447417736053467e-01
    z[9,8,2]  R2639     1.1584693938493729e-01
    z[9,8,2]  R2640     1.3109819591045380e-01
    z[9,8,2]  R2641     -3.8024783134460449e-01
    z[9,8,2]  R2642     9.7751110792160034e-02
    z[9,8,2]  R2643     1.6658306121826172e-02
    z[9,8,2]  R2644     -2.3500657081604004e-01
    z[9,8,2]  R2645     -1.1313124746084213e-01
    z[9,8,2]  R2646     -4.1775825619697571e-01
    z[9,8,2]  R2647     1.2241696566343307e-01
    z[9,8,2]  R2648     5.8064609766006470e-01
    z[9,8,2]  R2649     -2.0666979253292084e-01
    z[9,8,2]  R2650     5.3458905220031738e-01
    z[9,8,2]  R2651     -7.9022668302059174e-02
    z[9,8,2]  R2652     1.7064422369003296e-01
    z[9,8,2]  R2653     2.0214636623859406e-01
    z[9,8,2]  R2654     4.2698092758655548e-02
    z[9,8,2]  R2655     1.4063432812690735e-01
    z[9,8,2]  R2656     1.5370629727840424e-01
    z[9,8,2]  R2657     1.9401220977306366e-01
    z[9,8,2]  R2658     -1.7959360778331757e-01
    z[9,8,2]  R2659     3.1395298242568970e-01
    z[9,8,2]  R2660     2.0556405186653137e-01
    z[9,8,2]  R2661     1.3141946494579315e-01
    z[9,8,2]  R2662     2.8139057755470276e-01
    z[9,8,2]  R2663     0.167667955160141
    z[9,8,2]  R2664     1.5895701944828033e-01
    z[9,8,2]  R2665     -2.1128481626510620e-01
    z[9,8,2]  R2666     6.4380693435668945e-01
    z[9,8,2]  R2667     5.9099775552749634e-01
    z[9,8,2]  R2668     3.2522940635681152e-01
    z[9,8,2]  R2669     2.4921227991580963e-01
    z[9,8,2]  R2670     0.164270281791687
    z[9,8,2]  R2671     3.9745372533798218e-01
    z[9,8,2]  R2672     3.2791949808597565e-02
    z[9,8,2]  R2673     3.8916710019111633e-01
    z[9,8,2]  R2674     5.2506572008132935e-01
    z[9,8,2]  R2675     -0.507003664970398
    z[9,8,2]  R2676     5.9127245098352432e-02
    z[9,8,2]  R2677     -6.3768506050109863e-01
    z[9,8,2]  R2678     -7.6838845014572144e-01
    z[9,8,2]  R2679     2.1167370676994324e-01
    z[9,8,2]  R2680     -7.1744740009307861e-02
    z[9,8,2]  R2681     -3.2376566529273987e-01
    z[9,8,2]  R2682     -9.3596793711185455e-02
    z[9,8,2]  R2683     -7.3147827386856079e-01
    z[9,8,2]  R2684     -2.4297079443931580e-01
    z[9,8,2]  R2685     -1.1006604135036469e-01
    z[9,8,2]  R2686     -3.8526695966720581e-01
    z[9,8,2]  R2687     4.7550402581691742e-02
    z[9,8,2]  R2688     -6.1102062463760376e-01
    z[9,8,3]  R77       1
    z[9,8,3]  R86       -1
    z[9,8,3]  R2551     -1
    z[9,8,3]  R2552     1
    z[9,8,3]  R2559     0.630595862865448
    z[9,8,3]  R2560     3.2040849328041077e-01
    z[9,8,3]  R2561     4.2054033279418945e-01
    z[9,8,3]  R2562     2.8039768338203430e-01
    z[9,8,3]  R2563     6.8141895532608032e-01
    z[9,8,3]  R2564     0.524479329586029
    z[9,8,3]  R2565     5.2910721302032471e-01
    z[9,8,3]  R2566     6.7841708660125732e-01
    z[9,8,3]  R2567     2.3260892927646637e-01
    z[9,8,3]  R2568     3.1640842556953430e-01
    z[9,8,3]  R2569     -0.0922887921333313
    z[9,8,3]  R2570     -8.1799037754535675e-02
    z[9,8,3]  R2571     -1.5462781488895416e-01
    z[9,8,3]  R2572     -1.4706438779830933e-01
    z[9,8,3]  R2573     -2.7036878466606140e-01
    z[9,8,3]  R2574     -5.1282446831464767e-02
    z[9,8,3]  R2575     -1.6719731688499451e-01
    z[9,8,3]  R2576     4.5264132320880890e-02
    z[9,8,3]  R2577     -3.4057107567787170e-01
    z[9,8,3]  R2578     -4.3049478530883789e-01
    z[9,8,3]  R2579     -3.1722940504550934e-02
    z[9,8,3]  R2580     2.6191183924674988e-01
    z[9,8,3]  R2581     2.0088051259517670e-01
    z[9,8,3]  R2582     -1.5801148116588593e-01
    z[9,8,3]  R2583     3.7539863586425781e-01
    z[9,8,3]  R2584     -2.1942764520645142e-01
    z[9,8,3]  R2585     -4.3343058228492737e-01
    z[9,8,3]  R2586     6.8287503719329834e-01
    z[9,8,3]  R2587     -7.0812559127807617e-01
    z[9,8,3]  R2588     -3.3075016736984253e-01
    z[9,8,3]  R2589     -1.3071247935295105e-01
    z[9,8,3]  R2590     2.7870687842369080e-01
    z[9,8,3]  R2591     5.4167336225509644e-01
    z[9,8,3]  R2592     1.5987187623977661e-01
    z[9,8,3]  R2593     -1.5942801535129547e-01
    z[9,8,3]  R2594     2.6197269558906555e-01
    z[9,8,3]  R2595     -6.6071957349777222e-01
    z[9,8,3]  R2596     -5.8773660659790039e-01
    z[9,8,3]  R2597     -5.7532048225402832e-01
    z[9,8,3]  R2598     -5.9662473201751709e-01
    z[9,8,3]  R2599     -2.4122324585914612e-01
    z[9,8,3]  R2600     0.0994042381644249
    z[9,8,3]  R2601     -2.5547316670417786e-01
    z[9,8,3]  R2602     6.9014841318130493e-01
    z[9,8,3]  R2603     1.4085161685943604e-01
    z[9,8,3]  R2604     2.4849760532379150e-01
    z[9,8,3]  R2605     2.2239649295806885e-01
    z[9,8,3]  R2606     -2.5498563051223755e-01
    z[9,8,3]  R2607     -2.6442768052220345e-02
    z[9,8,3]  R2608     -1.3136214017868042e-01
    z[9,8,3]  R2609     8.0912478268146515e-02
    z[9,8,3]  R2610     1.8270447850227356e-01
    z[9,8,3]  R2611     5.7935353368520737e-02
    z[9,8,3]  R2612     0.816985547542572
    z[9,8,3]  R2613     -1.5790291130542755e-01
    z[9,8,3]  R2614     -2.7754920721054077e-01
    z[9,8,3]  R2615     -2.4088135361671448e-01
    z[9,8,3]  R2616     5.4302625358104706e-02
    z[9,8,3]  R2617     -1.5420977771282196e-01
    z[9,8,3]  R2618     -1.8729925155639648e-01
    z[9,8,3]  R2619     -1.7744068801403046e-01
    z[9,8,3]  R2620     9.2129111289978027e-02
    z[9,8,3]  R2621     1.0381588339805603e-01
    z[9,8,3]  R2622     -4.5471572875976562e-01
    z[9,8,3]  R2623     -5.7463750243186951e-02
    z[9,8,3]  R2624     -7.5366806983947754e-01
    z[9,8,3]  R2625     -1.6991352662444115e-02
    z[9,8,3]  R2626     7.7977791428565979e-02
    z[9,8,3]  R2627     -0.704690158367157
    z[9,8,3]  R2628     -2.0809842646121979e-01
    z[9,8,3]  R2629     -3.6201027035713196e-01
    z[9,8,3]  R2630     -1.9956721365451813e-01
    z[9,8,3]  R2631     -2.0567707717418671e-01
    z[9,8,3]  R2632     -2.7525684237480164e-01
    z[9,8,3]  R2633     -3.0886083841323853e-01
    z[9,8,3]  R2634     -4.4544646143913269e-01
    z[9,8,3]  R2635     -3.0745381116867065e-01
    z[9,8,3]  R2636     -3.5966235399246216e-01
    z[9,8,3]  R2637     -1.7459464073181152e-01
    z[9,8,3]  R2638     1.3583010435104370e-01
    z[9,8,3]  R2639     -1.4307460188865662e-01
    z[9,8,3]  R2640     1.9094523787498474e-01
    z[9,8,3]  R2641     4.9552959203720093e-01
    z[9,8,3]  R2642     2.7962881326675415e-01
    z[9,8,3]  R2643     1.2235908955335617e-01
    z[9,8,3]  R2644     2.0566809177398682e-01
    z[9,8,3]  R2645     4.3316021561622620e-02
    z[9,8,3]  R2646     1.7639221623539925e-02
    z[9,8,3]  R2647     1.0946667194366455e-01
    z[9,8,3]  R2648     1.6150042647495866e-03
    z[9,8,3]  R2649     1.3374246656894684e-01
    z[9,8,3]  R2650     1.2629568576812744e-01
    z[9,8,3]  R2651     6.2102116644382477e-02
    z[9,8,3]  R2652     2.9491135478019714e-01
    z[9,8,3]  R2653     -2.6322089135646820e-02
    z[9,8,3]  R2654     7.1578072383999825e-03
    z[9,8,3]  R2655     2.1872717142105103e-01
    z[9,8,3]  R2656     -1.8175978958606720e-01
    z[9,8,3]  R2657     8.2140177488327026e-02
    z[9,8,3]  R2658     3.0320054292678833e-01
    z[9,8,3]  R2659     -8.5072226822376251e-02
    z[9,8,3]  R2660     -2.5293228030204773e-01
    z[9,8,3]  R2661     -7.7289357781410217e-02
    z[9,8,3]  R2662     2.6788532733917236e-01
    z[9,8,3]  R2663     4.0922960638999939e-01
    z[9,8,3]  R2664     1.0151887685060501e-01
    z[9,8,3]  R2665     -1.5011383593082428e-01
    z[9,8,3]  R2666     -3.7447098642587662e-02
    z[9,8,3]  R2667     3.4785076975822449e-01
    z[9,8,3]  R2668     5.0983697175979614e-01
    z[9,8,3]  R2669     -5.5340811610221863e-02
    z[9,8,3]  R2670     3.6104840040206909e-01
    z[9,8,3]  R2671     -1.1791817843914032e-01
    z[9,8,3]  R2672     -5.0834685564041138e-02
    z[9,8,3]  R2673     2.8743815422058105e-01
    z[9,8,3]  R2674     3.1195366382598877e-01
    z[9,8,3]  R2675     2.6422295719385147e-02
    z[9,8,3]  R2676     1.8366459012031555e-01
    z[9,8,3]  R2677     -3.5316757857799530e-02
    z[9,8,3]  R2678     1.1731790006160736e-01
    z[9,8,3]  R2679     2.8474060818552971e-02
    z[9,8,3]  R2680     3.2537961006164551e-01
    z[9,8,3]  R2681     2.8847834467887878e-01
    z[9,8,3]  R2682     2.3252607882022858e-01
    z[9,8,3]  R2683     2.4392794072628021e-01
    z[9,8,3]  R2684     2.9981240630149841e-01
    z[9,8,3]  R2685     5.4551732540130615e-01
    z[9,8,3]  R2686     5.8316290378570557e-01
    z[9,8,3]  R2687     4.9375861883163452e-02
    z[9,8,3]  R2688     -1.1125106364488602e-01
    z[9,8,4]  R78       1
    z[9,8,4]  R87       -1
    z[9,8,4]  R2553     -1
    z[9,8,4]  R2554     1
    z[9,8,4]  R2559     -2.3744067549705505e-01
    z[9,8,4]  R2560     0.0827716812491417
    z[9,8,4]  R2561     -5.7877349853515625e-01
    z[9,8,4]  R2562     -4.7462841868400574e-01
    z[9,8,4]  R2563     -3.8081204891204834e-01
    z[9,8,4]  R2564     -0.628445029258728
    z[9,8,4]  R2565     -4.8358172178268433e-01
    z[9,8,4]  R2566     -5.2478021383285522e-01
    z[9,8,4]  R2567     3.8961541652679443e-01
    z[9,8,4]  R2568     5.0594240427017212e-01
    z[9,8,4]  R2569     2.4471342563629150e-01
    z[9,8,4]  R2570     -2.8229910880327225e-02
    z[9,8,4]  R2571     5.2011376619338989e-01
    z[9,8,4]  R2572     -9.4679847359657288e-02
    z[9,8,4]  R2573     3.9547699689865112e-01
    z[9,8,4]  R2574     9.6088767051696777e-02
    z[9,8,4]  R2575     4.8031383752822876e-01
    z[9,8,4]  R2576     -1.4868909120559692e-01
    z[9,8,4]  R2577     3.5853621363639832e-01
    z[9,8,4]  R2578     1.0054794698953629e-01
    z[9,8,4]  R2579     -2.9966783523559570e-01
    z[9,8,4]  R2580     0.308178573846817
    z[9,8,4]  R2581     0.501348614692688
    z[9,8,4]  R2582     4.1890364140272141e-02
    z[9,8,4]  R2583     1.7075219750404358e-01
    z[9,8,4]  R2584     3.2352928072214127e-02
    z[9,8,4]  R2585     -2.3997258394956589e-02
    z[9,8,4]  R2586     3.6097481846809387e-01
    z[9,8,4]  R2587     -1.7721448838710785e-01
    z[9,8,4]  R2588     4.0443789958953857e-01
    z[9,8,4]  R2589     1.4199002087116241e-01
    z[9,8,4]  R2590     -8.5988417267799377e-02
    z[9,8,4]  R2591     -8.8775508105754852e-02
    z[9,8,4]  R2592     3.4498311579227448e-02
    z[9,8,4]  R2593     5.0465297698974609e-01
    z[9,8,4]  R2594     3.7336525321006775e-01
    z[9,8,4]  R2595     3.6075541377067566e-01
    z[9,8,4]  R2596     4.2704832553863525e-01
    z[9,8,4]  R2597     4.9841120839118958e-01
    z[9,8,4]  R2598     6.9261372089385986e-01
    z[9,8,4]  R2599     -0.00996506679803133
    z[9,8,4]  R2600     3.2574638724327087e-01
    z[9,8,4]  R2601     0.284542053937912
    z[9,8,4]  R2602     1.0995614528656006e-01
    z[9,8,4]  R2603     4.5094323158264160e-01
    z[9,8,4]  R2604     -2.1217282116413116e-01
    z[9,8,4]  R2605     0.539861261844635
    z[9,8,4]  R2606     6.7160254716873169e-01
    z[9,8,4]  R2607     8.1771403551101685e-01
    z[9,8,4]  R2608     0.30640709400177
    z[9,8,4]  R2609     -3.5012137889862061e-01
    z[9,8,4]  R2610     -5.1747161149978638e-01
    z[9,8,4]  R2611     2.7940675616264343e-01
    z[9,8,4]  R2612     2.8810921311378479e-01
    z[9,8,4]  R2613     6.4422529935836792e-01
    z[9,8,4]  R2614     2.4196559190750122e-01
    z[9,8,4]  R2615     7.9599432647228241e-02
    z[9,8,4]  R2616     1.9483956694602966e-01
    z[9,8,4]  R2617     -1.6300510615110397e-03
    z[9,8,4]  R2618     -1.1140790581703186e-01
    z[9,8,4]  R2619     1.9025810062885284e-01
    z[9,8,4]  R2620     2.1849417686462402e-01
    z[9,8,4]  R2621     6.2847083806991577e-01
    z[9,8,4]  R2622     2.0253662765026093e-01
    z[9,8,4]  R2623     4.2726555466651917e-01
    z[9,8,4]  R2624     4.5717346668243408e-01
    z[9,8,4]  R2625     -0.00543689401820302
    z[9,8,4]  R2626     1.8286738544702530e-02
    z[9,8,4]  R2627     2.8732625767588615e-02
    z[9,8,4]  R2628     -3.3437472581863403e-01
    z[9,8,4]  R2629     -2.6778010651469231e-02
    z[9,8,4]  R2630     3.5860094428062439e-01
    z[9,8,4]  R2631     1.4356791973114014e-01
    z[9,8,4]  R2632     3.2136055827140808e-01
    z[9,8,4]  R2633     -1.8034203350543976e-01
    z[9,8,4]  R2634     -1.2024753540754318e-01
    z[9,8,4]  R2635     2.7214720845222473e-01
    z[9,8,4]  R2636     2.1005927026271820e-01
    z[9,8,4]  R2637     2.6687526702880859e-01
    z[9,8,4]  R2638     7.2965443134307861e-01
    z[9,8,4]  R2639     -1.6865578293800354e-01
    z[9,8,4]  R2640     -3.6632204055786133e-01
    z[9,8,4]  R2641     2.3348139226436615e-01
    z[9,8,4]  R2642     -4.0672543644905090e-01
    z[9,8,4]  R2643     -4.8116365075111389e-01
    z[9,8,4]  R2644     -0.247926726937294
    z[9,8,4]  R2645     -2.0793950557708740e-01
    z[9,8,4]  R2646     -6.5966004133224487e-01
    z[9,8,4]  R2647     -2.0656064152717590e-01
    z[9,8,4]  R2648     -4.3522661924362183e-01
    z[9,8,4]  R2649     -1.4672678709030151e-01
    z[9,8,4]  R2650     1.9172701239585876e-01
    z[9,8,4]  R2651     -2.9065984487533569e-01
    z[9,8,4]  R2652     2.9688683152198792e-01
    z[9,8,4]  R2653     -3.5755434632301331e-01
    z[9,8,4]  R2654     2.1523140370845795e-01
    z[9,8,4]  R2655     4.4117426872253418e-01
    z[9,8,4]  R2656     -2.3671607673168182e-01
    z[9,8,4]  R2657     -3.1154295802116394e-01
    z[9,8,4]  R2658     5.4660546779632568e-01
    z[9,8,4]  R2659     1.2484390288591385e-01
    z[9,8,4]  R2660     -2.5522604584693909e-01
    z[9,8,4]  R2661     -3.5293996334075928e-01
    z[9,8,4]  R2662     1.3313040137290955e-01
    z[9,8,4]  R2663     3.5217371582984924e-01
    z[9,8,4]  R2664     4.2907809838652611e-03
    z[9,8,4]  R2665     -8.5193395614624023e-02
    z[9,8,4]  R2666     7.0026978850364685e-02
    z[9,8,4]  R2667     -2.9524338245391846e-01
    z[9,8,4]  R2668     -2.0597729086875916e-01
    z[9,8,4]  R2669     -3.7422144412994385e-01
    z[9,8,4]  R2670     0.00995348859578371
    z[9,8,4]  R2671     -1.3390763103961945e-01
    z[9,8,4]  R2672     -1.8794330954551697e-01
    z[9,8,4]  R2673     6.8049073219299316e-02
    z[9,8,4]  R2674     -7.9455800354480743e-02
    z[9,8,4]  R2675     -5.9384912252426147e-01
    z[9,8,4]  R2676     3.2085731625556946e-01
    z[9,8,4]  R2677     -6.0262900590896606e-01
    z[9,8,4]  R2678     -2.5845566391944885e-01
    z[9,8,4]  R2679     -1.5084058046340942e-01
    z[9,8,4]  R2680     1.3414281606674194e-01
    z[9,8,4]  R2681     -7.6363407075405121e-02
    z[9,8,4]  R2682     4.0686614811420441e-02
    z[9,8,4]  R2683     0.0765153020620346
    z[9,8,4]  R2684     -1.4057447016239166e-01
    z[9,8,4]  R2685     1.5660363435745239e-01
    z[9,8,4]  R2686     -1.1249816417694092e-01
    z[9,8,4]  R2687     7.6486356556415558e-02
    z[9,8,4]  R2688     4.5740908384323120e-01
    z[9,8,5]  R79       1
    z[9,8,5]  R88       -1
    z[9,8,5]  R2555     -1
    z[9,8,5]  R2556     1
    z[9,8,5]  R2559     6.0959124565124512e-01
    z[9,8,5]  R2560     6.8604147434234619e-01
    z[9,8,5]  R2561     5.3980922698974609e-01
    z[9,8,5]  R2562     6.4250773191452026e-01
    z[9,8,5]  R2563     1.0501185804605484e-01
    z[9,8,5]  R2564     -0.0551178939640522
    z[9,8,5]  R2565     -4.7281570732593536e-02
    z[9,8,5]  R2566     -1.8524868786334991e-01
    z[9,8,5]  R2567     4.8076584935188293e-01
    z[9,8,5]  R2568     1.7615149915218353e-01
    z[9,8,5]  R2569     -3.2450765371322632e-02
    z[9,8,5]  R2570     -2.6499629020690918e-01
    z[9,8,5]  R2571     -2.2803871333599091e-01
    z[9,8,5]  R2572     -4.5225575566291809e-01
    z[9,8,5]  R2573     -2.0371034741401672e-01
    z[9,8,5]  R2574     1.9490176811814308e-02
    z[9,8,5]  R2575     4.2251139879226685e-01
    z[9,8,5]  R2576     -7.7622950077056885e-02
    z[9,8,5]  R2577     -5.9538954496383667e-01
    z[9,8,5]  R2578     -3.1654247641563416e-01
    z[9,8,5]  R2579     -2.1380858495831490e-02
    z[9,8,5]  R2580     3.6986616253852844e-01
    z[9,8,5]  R2581     -2.9593309760093689e-01
    z[9,8,5]  R2582     1.3574530184268951e-01
    z[9,8,5]  R2583     -1.8741288781166077e-01
    z[9,8,5]  R2584     1.8684232234954834e-01
    z[9,8,5]  R2585     -3.0348542332649231e-01
    z[9,8,5]  R2586     -2.4751265347003937e-01
    z[9,8,5]  R2587     -0.0328182727098465
    z[9,8,5]  R2588     -8.9843444526195526e-02
    z[9,8,5]  R2589     -1.9645778834819794e-01
    z[9,8,5]  R2590     -1.1482248082756996e-03
    z[9,8,5]  R2591     3.2897189259529114e-02
    z[9,8,5]  R2592     -1.6976065933704376e-01
    z[9,8,5]  R2593     3.4776532649993896e-01
    z[9,8,5]  R2594     -4.6710196137428284e-01
    z[9,8,5]  R2595     -5.9684950113296509e-01
    z[9,8,5]  R2596     -0.605772852897644
    z[9,8,5]  R2597     -4.8108381032943726e-01
    z[9,8,5]  R2598     -1.9799204170703888e-01
    z[9,8,5]  R2599     6.4184987545013428e-01
    z[9,8,5]  R2600     3.9485642313957214e-01
    z[9,8,5]  R2601     3.1156671047210693e-01
    z[9,8,5]  R2602     -1.9592662155628204e-01
    z[9,8,5]  R2603     -2.3011548817157745e-01
    z[9,8,5]  R2604     1.0768519714474678e-02
    z[9,8,5]  R2605     -9.4771005213260651e-02
    z[9,8,5]  R2606     1.3257928192615509e-01
    z[9,8,5]  R2607     1.5410327911376953e-01
    z[9,8,5]  R2608     -3.1746536493301392e-01
    z[9,8,5]  R2609     -2.8857348486781120e-02
    z[9,8,5]  R2610     3.4091625362634659e-02
    z[9,8,5]  R2611     4.4156581163406372e-01
    z[9,8,5]  R2612     -1.4573523402214050e-01
    z[9,8,5]  R2613     -5.5646669119596481e-02
    z[9,8,5]  R2614     3.8169354200363159e-02
    z[9,8,5]  R2615     -3.1596621870994568e-01
    z[9,8,5]  R2616     -4.7881278395652771e-01
    z[9,8,5]  R2617     -5.1543056964874268e-01
    z[9,8,5]  R2618     -2.6525703072547913e-01
    z[9,8,5]  R2619     1.2550760805606842e-01
    z[9,8,5]  R2620     3.5498419404029846e-01
    z[9,8,5]  R2621     8.3474688231945038e-02
    z[9,8,5]  R2622     3.2502165436744690e-01
    z[9,8,5]  R2623     -3.1508678197860718e-01
    z[9,8,5]  R2624     -3.2217675447463989e-01
    z[9,8,5]  R2625     2.5536064058542252e-02
    z[9,8,5]  R2626     -4.1888780891895294e-02
    z[9,8,5]  R2627     -5.7469010353088379e-01
    z[9,8,5]  R2628     -1.2234982103109360e-01
    z[9,8,5]  R2629     1.9142253696918488e-01
    z[9,8,5]  R2630     -8.3000678569078445e-03
    z[9,8,5]  R2631     2.2672009468078613e-01
    z[9,8,5]  R2632     1.7032565176486969e-01
    z[9,8,5]  R2633     1.7105570435523987e-01
    z[9,8,5]  R2634     1.1228091269731522e-01
    z[9,8,5]  R2635     1.4679941534996033e-01
    z[9,8,5]  R2636     3.5912382602691650e-01
    z[9,8,5]  R2637     6.0152035951614380e-01
    z[9,8,5]  R2638     2.2390134632587433e-01
    z[9,8,5]  R2639     -3.1453219056129456e-01
    z[9,8,5]  R2640     2.8494027256965637e-01
    z[9,8,5]  R2641     -2.5033742189407349e-01
    z[9,8,5]  R2642     -0.0385163351893425
    z[9,8,5]  R2643     3.2776869833469391e-02
    z[9,8,5]  R2644     -8.3212591707706451e-02
    z[9,8,5]  R2645     -3.6018621176481247e-02
    z[9,8,5]  R2646     4.1902983188629150e-01
    z[9,8,5]  R2647     0.0738268494606018
    z[9,8,5]  R2648     1.2479127198457718e-01
    z[9,8,5]  R2649     -1.9711649417877197e-01
    z[9,8,5]  R2650     3.1322799623012543e-02
    z[9,8,5]  R2651     1.9233305752277374e-01
    z[9,8,5]  R2652     9.2855080962181091e-02
    z[9,8,5]  R2653     -3.3176234364509583e-01
    z[9,8,5]  R2654     3.1827205419540405e-01
    z[9,8,5]  R2655     -3.6571016907691956e-01
    z[9,8,5]  R2656     -0.0894322618842125
    z[9,8,5]  R2657     -2.6702433824539185e-01
    z[9,8,5]  R2658     -6.9068334996700287e-03
    z[9,8,5]  R2659     -2.2181174159049988e-01
    z[9,8,5]  R2660     -6.7543298006057739e-02
    z[9,8,5]  R2661     3.3199369907379150e-01
    z[9,8,5]  R2662     2.7365097403526306e-01
    z[9,8,5]  R2663     -4.5686885714530945e-02
    z[9,8,5]  R2664     -5.0309556722640991e-01
    z[9,8,5]  R2665     1.7004017531871796e-01
    z[9,8,5]  R2666     -3.9104998111724854e-01
    z[9,8,5]  R2667     4.3170547485351562e-01
    z[9,8,5]  R2668     3.9537000656127930e-01
    z[9,8,5]  R2669     1.9739224016666412e-01
    z[9,8,5]  R2670     -1.0161225683987141e-02
    z[9,8,5]  R2671     -2.2046926617622375e-01
    z[9,8,5]  R2672     -1.1617458611726761e-01
    z[9,8,5]  R2673     -2.7370089292526245e-01
    z[9,8,5]  R2674     2.6169112324714661e-01
    z[9,8,5]  R2675     -3.1920078396797180e-01
    z[9,8,5]  R2676     -0.0718526765704155
    z[9,8,5]  R2677     -3.7679579108953476e-02
    z[9,8,5]  R2678     -1.6701023280620575e-01
    z[9,8,5]  R2679     1.8614935874938965e-01
    z[9,8,5]  R2680     9.3117326498031616e-02
    z[9,8,5]  R2681     2.7580955624580383e-01
    z[9,8,5]  R2682     5.5818080902099609e-01
    z[9,8,5]  R2683     3.9974045753479004e-01
    z[9,8,5]  R2684     2.8213381767272949e-01
    z[9,8,5]  R2685     5.1896089315414429e-01
    z[9,8,5]  R2686     3.3511513471603394e-01
    z[9,8,5]  R2687     7.2859209775924683e-01
    z[9,8,5]  R2688     1.1801747605204582e-02
    z[9,8,6]  R80       1
    z[9,8,6]  R89       -1
    z[9,8,6]  R2557     -1
    z[9,8,6]  R2558     1
    z[9,8,6]  R2559     -4.5436579734086990e-02
    z[9,8,6]  R2560     1.3276310265064240e-01
    z[9,8,6]  R2561     -1.7145794630050659e-01
    z[9,8,6]  R2562     4.4282466173171997e-01
    z[9,8,6]  R2563     1.1576970666646957e-01
    z[9,8,6]  R2564     1.3626264035701752e-01
    z[9,8,6]  R2565     4.5209395885467529e-01
    z[9,8,6]  R2566     -2.9960680007934570e-01
    z[9,8,6]  R2567     -6.1643189191818237e-01
    z[9,8,6]  R2568     1.3172204792499542e-01
    z[9,8,6]  R2569     5.9821295738220215e-01
    z[9,8,6]  R2570     -6.0290664434432983e-01
    z[9,8,6]  R2571     -5.3319036960601807e-01
    z[9,8,6]  R2572     9.2168338596820831e-02
    z[9,8,6]  R2573     -3.1946465373039246e-01
    z[9,8,6]  R2574     -3.0811068415641785e-01
    z[9,8,6]  R2575     -6.1776839196681976e-02
    z[9,8,6]  R2576     -1.9178394973278046e-01
    z[9,8,6]  R2577     -0.0774015337228775
    z[9,8,6]  R2578     1.2274991720914841e-01
    z[9,8,6]  R2579     1.9521857798099518e-01
    z[9,8,6]  R2580     -2.3522333800792694e-01
    z[9,8,6]  R2581     -4.9021661281585693e-02
    z[9,8,6]  R2582     -1.4449508488178253e-01
    z[9,8,6]  R2583     -3.9919081330299377e-01
    z[9,8,6]  R2584     -4.1840910911560059e-01
    z[9,8,6]  R2585     -0.0537693053483963
    z[9,8,6]  R2586     2.9884251952171326e-01
    z[9,8,6]  R2587     -1.2494862079620361e-01
    z[9,8,6]  R2588     -9.6965618431568146e-02
    z[9,8,6]  R2589     -1.0616531595587730e-02
    z[9,8,6]  R2590     -1.4885148033499718e-02
    z[9,8,6]  R2591     -2.7475917339324951e-01
    z[9,8,6]  R2592     2.2646412253379822e-01
    z[9,8,6]  R2593     8.6878068745136261e-02
    z[9,8,6]  R2594     2.5030277669429779e-02
    z[9,8,6]  R2595     2.5785481929779053e-01
    z[9,8,6]  R2596     -2.1536734700202942e-01
    z[9,8,6]  R2597     4.1040789335966110e-02
    z[9,8,6]  R2598     0.205540731549263
    z[9,8,6]  R2599     -0.342171311378479
    z[9,8,6]  R2600     -1.0002993047237396e-01
    z[9,8,6]  R2601     3.2614961266517639e-01
    z[9,8,6]  R2602     7.5960271060466766e-03
    z[9,8,6]  R2603     -6.0785752721130848e-03
    z[9,8,6]  R2604     -3.8614797592163086e-01
    z[9,8,6]  R2605     -1.1958386749029160e-01
    z[9,8,6]  R2606     -1.9437422975897789e-02
    z[9,8,6]  R2607     -6.9461479783058167e-02
    z[9,8,6]  R2608     1.9744911789894104e-01
    z[9,8,6]  R2609     -2.9330024123191833e-01
    z[9,8,6]  R2610     -3.4934807568788528e-02
    z[9,8,6]  R2611     2.2088389098644257e-01
    z[9,8,6]  R2612     1.3635644316673279e-01
    z[9,8,6]  R2613     -1.0868085175752640e-01
    z[9,8,6]  R2614     1.6315829753875732e-01
    z[9,8,6]  R2615     4.0994000434875488e-01
    z[9,8,6]  R2616     2.5183673948049545e-02
    z[9,8,6]  R2617     4.0462979674339294e-01
    z[9,8,6]  R2618     -3.1075802445411682e-01
    z[9,8,6]  R2619     3.1362724304199219e-01
    z[9,8,6]  R2620     2.3466531932353973e-01
    z[9,8,6]  R2621     -6.3345089554786682e-02
    z[9,8,6]  R2622     -3.3809497952461243e-02
    z[9,8,6]  R2623     -2.1018752455711365e-01
    z[9,8,6]  R2624     2.7088707685470581e-01
    z[9,8,6]  R2625     -2.2203331813216209e-02
    z[9,8,6]  R2626     4.9485091120004654e-02
    z[9,8,6]  R2627     9.9782370030879974e-02
    z[9,8,6]  R2628     -2.5111085176467896e-01
    z[9,8,6]  R2629     9.5573388040065765e-02
    z[9,8,6]  R2630     -0.00667816074565053
    z[9,8,6]  R2631     8.5651800036430359e-02
    z[9,8,6]  R2632     -4.6514865010976791e-02
    z[9,8,6]  R2633     4.4298145920038223e-02
    z[9,8,6]  R2634     -1.6526412963867188e-01
    z[9,8,6]  R2635     -8.2540504634380341e-02
    z[9,8,6]  R2636     -4.0713074803352356e-01
    z[9,8,6]  R2637     1.9813652336597443e-01
    z[9,8,6]  R2638     0.0846172571182251
    z[9,8,6]  R2639     -6.6600787639617920e-01
    z[9,8,6]  R2640     6.8968725204467773e-01
    z[9,8,6]  R2641     4.7490417957305908e-01
    z[9,8,6]  R2642     -3.8561765104532242e-02
    z[9,8,6]  R2643     0.0684349462389946
    z[9,8,6]  R2644     4.2259924113750458e-02
    z[9,8,6]  R2645     2.1167999505996704e-01
    z[9,8,6]  R2646     -3.7862819153815508e-03
    z[9,8,6]  R2647     -1.4978150138631463e-03
    z[9,8,6]  R2648     2.1710345149040222e-01
    z[9,8,6]  R2649     4.1864126920700073e-02
    z[9,8,6]  R2650     -1.5669718384742737e-02
    z[9,8,6]  R2651     -1.4252914488315582e-01
    z[9,8,6]  R2652     2.5085920095443726e-01
    z[9,8,6]  R2653     -1.4304542541503906e-01
    z[9,8,6]  R2654     -4.8893624544143677e-01
    z[9,8,6]  R2655     8.6534790694713593e-02
    z[9,8,6]  R2656     -2.7721837162971497e-01
    z[9,8,6]  R2657     5.4862993955612183e-01
    z[9,8,6]  R2658     -2.4678014218807220e-01
    z[9,8,6]  R2659     -3.0206772685050964e-01
    z[9,8,6]  R2660     -1.4944548904895782e-01
    z[9,8,6]  R2661     -1.8581999838352203e-01
    z[9,8,6]  R2662     3.8092538714408875e-01
    z[9,8,6]  R2663     4.7314144670963287e-02
    z[9,8,6]  R2664     -2.9051521420478821e-01
    z[9,8,6]  R2665     -5.1917988061904907e-01
    z[9,8,6]  R2666     -2.5268509984016418e-02
    z[9,8,6]  R2667     6.8412572145462036e-02
    z[9,8,6]  R2668     -4.0220993757247925e-01
    z[9,8,6]  R2669     -1.0235381871461868e-01
    z[9,8,6]  R2670     1.0922455042600632e-01
    z[9,8,6]  R2671     2.1418869495391846e-01
    z[9,8,6]  R2672     -4.9310860037803650e-01
    z[9,8,6]  R2673     -3.3329862356185913e-01
    z[9,8,6]  R2674     -4.9258375167846680e-01
    z[9,8,6]  R2675     9.8725304007530212e-02
    z[9,8,6]  R2676     -1.6802644729614258e-01
    z[9,8,6]  R2677     -1.6861614584922791e-01
    z[9,8,6]  R2678     -0.218696728348732
    z[9,8,6]  R2679     -2.1060292422771454e-01
    z[9,8,6]  R2680     -6.7212447524070740e-02
    z[9,8,6]  R2681     -2.0458398386836052e-02
    z[9,8,6]  R2682     -5.2033051848411560e-02
    z[9,8,6]  R2683     1.4600904285907745e-01
    z[9,8,6]  R2684     -3.9462402462959290e-01
    z[9,8,6]  R2685     0.00793476216495037
    z[9,8,6]  R2686     -2.1063642203807831e-01
    z[9,8,6]  R2687     2.5378491729497910e-02
    z[9,8,6]  R2688     6.3474170863628387e-02
    z[9,10,0]  R83       -1
    z[9,10,0]  R92       1
    z[9,10,0]  R2689     -1
    z[9,10,0]  R2690     1
    z[9,10,0]  R2703     -4.1501635313034058e-01
    z[9,10,0]  R2704     -6.1638349294662476e-01
    z[9,10,0]  R2705     -1.2898580729961395e-01
    z[9,10,0]  R2706     -1.0595534741878510e-01
    z[9,10,0]  R2707     -2.1235486865043640e-01
    z[9,10,0]  R2708     -3.5595887899398804e-01
    z[9,10,0]  R2709     -4.8017153143882751e-01
    z[9,10,0]  R2710     -3.4229013323783875e-01
    z[9,10,0]  R2711     -3.6051180958747864e-01
    z[9,10,0]  R2712     1.0068622976541519e-01
    z[9,10,0]  R2713     -6.2879495322704315e-02
    z[9,10,0]  R2714     2.3196329176425934e-01
    z[9,10,0]  R2715     -1.3041956722736359e-01
    z[9,10,0]  R2716     0.473922997713089
    z[9,10,0]  R2717     4.8206233978271484e-01
    z[9,10,0]  R2718     4.1645923256874084e-01
    z[9,10,0]  R2719     2.4854870140552521e-01
    z[9,10,0]  R2720     5.7460528612136841e-01
    z[9,10,0]  R2721     -0.0876041129231453
    z[9,10,0]  R2722     -7.3631328344345093e-01
    z[9,10,0]  R2723     2.2810553014278412e-01
    z[9,10,0]  R2724     1.8212832510471344e-01
    z[9,10,0]  R2725     5.9286877512931824e-02
    z[9,10,0]  R2726     5.3127199411392212e-01
    z[9,10,0]  R2727     -1.2675017118453979e-01
    z[9,10,0]  R2728     -3.8847783207893372e-01
    z[9,10,0]  R2729     -2.9837992787361145e-01
    z[9,10,0]  R2730     2.4467872083187103e-01
    z[9,10,0]  R2731     2.3737061023712158e-01
    z[9,10,0]  R2732     7.8550964593887329e-02
    z[9,10,0]  R2733     -2.1258579194545746e-01
    z[9,10,0]  R2734     4.4759336113929749e-01
    z[9,10,0]  R2735     2.6186940073966980e-01
    z[9,10,0]  R2736     1.5955546498298645e-01
    z[9,10,0]  R2737     -2.0481684803962708e-01
    z[9,10,0]  R2738     -0.731015682220459
    z[9,10,0]  R2739     -8.7707176804542542e-02
    z[9,10,0]  R2740     -3.4270800650119781e-02
    z[9,10,0]  R2741     1.9785304367542267e-01
    z[9,10,0]  R2742     6.9680482149124146e-02
    z[9,10,0]  R2743     -2.8917935490608215e-01
    z[9,10,0]  R2744     -3.6127030849456787e-02
    z[9,10,0]  R2745     3.6400923132896423e-01
    z[9,10,0]  R2746     -0.0682537704706192
    z[9,10,0]  R2747     -2.4083405733108521e-01
    z[9,10,0]  R2748     6.7271322011947632e-01
    z[9,10,0]  R2749     2.8718367218971252e-01
    z[9,10,0]  R2750     3.4148886799812317e-01
    z[9,10,0]  R2751     -2.5947546958923340e-01
    z[9,10,0]  R2752     -7.9348587989807129e-01
    z[9,10,0]  R2753     -1.9329544901847839e-01
    z[9,10,0]  R2754     5.1389408111572266e-01
    z[9,10,0]  R2755     6.2059406191110611e-02
    z[9,10,0]  R2756     5.0344061106443405e-02
    z[9,10,0]  R2757     -3.3465296030044556e-02
    z[9,10,0]  R2758     -4.9066618084907532e-01
    z[9,10,0]  R2759     5.8313506841659546e-01
    z[9,10,0]  R2760     -7.7286720275878906e-01
    z[9,10,0]  R2761     -0.721823513507843
    z[9,10,0]  R2762     -6.4657241106033325e-01
    z[9,10,0]  R2763     2.1939818561077118e-01
    z[9,10,0]  R2764     2.8270853683352470e-02
    z[9,10,0]  R2765     -5.1187032461166382e-01
    z[9,10,0]  R2766     -1.3031905889511108e-01
    z[9,10,0]  R2767     -7.7040952444076538e-01
    z[9,10,0]  R2768     1.8976368010044098e-01
    z[9,10,0]  R2769     0.847102701663971
    z[9,10,0]  R2770     8.4951055049896240e-01
    z[9,10,0]  R2771     3.1519749760627747e-01
    z[9,10,0]  R2772     9.7910448908805847e-02
    z[9,10,0]  R2773     -3.9636448025703430e-01
    z[9,10,0]  R2774     -2.1843071281909943e-01
    z[9,10,0]  R2775     -5.5052655935287476e-01
    z[9,10,0]  R2776     -5.1393687725067139e-02
    z[9,10,0]  R2777     -1.1332868784666061e-01
    z[9,10,0]  R2778     -1.8592710793018341e-01
    z[9,10,0]  R2779     3.6510050296783447e-01
    z[9,10,0]  R2780     2.6070839166641235e-01
    z[9,10,0]  R2781     -1.9142383709549904e-02
    z[9,10,0]  R2782     -4.2343366146087646e-01
    z[9,10,0]  R2783     4.0896305441856384e-01
    z[9,10,0]  R2784     -9.6639342606067657e-02
    z[9,10,0]  R2785     -4.7348892688751221e-01
    z[9,10,0]  R2786     -1.7088831961154938e-01
    z[9,10,0]  R2787     -1.2774877250194550e-02
    z[9,10,0]  R2788     2.2630387544631958e-01
    z[9,10,0]  R2789     1.8719108402729034e-01
    z[9,10,0]  R2790     -3.3848896622657776e-01
    z[9,10,0]  R2791     6.2727910280227661e-01
    z[9,10,0]  R2792     -3.6651602387428284e-01
    z[9,10,0]  R2793     -9.5985263586044312e-02
    z[9,10,0]  R2794     1.1450875550508499e-01
    z[9,10,0]  R2795     1.0657140612602234e-01
    z[9,10,0]  R2796     2.9993700981140137e-01
    z[9,10,0]  R2797     -3.0955451726913452e-01
    z[9,10,0]  R2798     -5.6630626320838928e-02
    z[9,10,0]  R2799     2.1666556596755981e-02
    z[9,10,0]  R2800     4.6906974911689758e-01
    z[9,10,0]  R2801     -7.2263628244400024e-01
    z[9,10,0]  R2802     -3.6497896909713745e-01
    z[9,10,0]  R2803     -1.9985330104827881e-01
    z[9,10,0]  R2804     -3.8029614835977554e-02
    z[9,10,0]  R2805     -2.6851644739508629e-02
    z[9,10,0]  R2806     1.5648564696311951e-01
    z[9,10,0]  R2807     5.9689271450042725e-01
    z[9,10,0]  R2808     2.2789795696735382e-01
    z[9,10,0]  R2809     -2.8174072504043579e-01
    z[9,10,0]  R2810     6.2675297260284424e-01
    z[9,10,0]  R2811     -3.2631557434797287e-02
    z[9,10,0]  R2812     5.2217852324247360e-02
    z[9,10,1]  R84       -1
    z[9,10,1]  R93       1
    z[9,10,1]  R2691     -1
    z[9,10,1]  R2692     1
    z[9,10,1]  R2703     -8.0737462267279625e-03
    z[9,10,1]  R2704     1.4230413734912872e-01
    z[9,10,1]  R2705     2.2624358534812927e-02
    z[9,10,1]  R2706     2.3977272212505341e-01
    z[9,10,1]  R2707     0.528877854347229
    z[9,10,1]  R2708     -4.0463000535964966e-01
    z[9,10,1]  R2709     2.2134327888488770e-01
    z[9,10,1]  R2710     3.5330925136804581e-02
    z[9,10,1]  R2711     7.0831492543220520e-02
    z[9,10,1]  R2712     -7.0181339979171753e-02
    z[9,10,1]  R2713     -7.0611411333084106e-01
    z[9,10,1]  R2714     -7.0038020610809326e-01
    z[9,10,1]  R2715     -5.3251928091049194e-01
    z[9,10,1]  R2716     -5.2856034040451050e-01
    z[9,10,1]  R2717     -6.2404000759124756e-01
    z[9,10,1]  R2718     -6.9835889339447021e-01
    z[9,10,1]  R2719     -4.2886650562286377e-01
    z[9,10,1]  R2720     -6.2193077802658081e-01
    z[9,10,1]  R2721     -5.5906790494918823e-01
    z[9,10,1]  R2722     -2.4140434339642525e-02
    z[9,10,1]  R2723     -7.4764102697372437e-01
    z[9,10,1]  R2724     -6.5758311748504639e-01
    z[9,10,1]  R2725     -6.6996800899505615e-01
    z[9,10,1]  R2726     -6.4960908889770508e-01
    z[9,10,1]  R2727     -6.0257738828659058e-01
    z[9,10,1]  R2728     -7.6623803377151489e-01
    z[9,10,1]  R2729     -7.8444540500640869e-01
    z[9,10,1]  R2730     -4.3566080927848816e-01
    z[9,10,1]  R2731     -5.9862571954727173e-01
    z[9,10,1]  R2732     -5.6945592164993286e-01
    z[9,10,1]  R2733     -9.3129861354827881e-01
    z[9,10,1]  R2734     -7.7635931968688965e-01
    z[9,10,1]  R2735     -6.7822271585464478e-01
    z[9,10,1]  R2736     -6.6880780458450317e-01
    z[9,10,1]  R2737     -4.9056935310363770e-01
    z[9,10,1]  R2738     1.4509424567222595e-01
    z[9,10,1]  R2739     5.1353760063648224e-02
    z[9,10,1]  R2740     6.5615244209766388e-02
    z[9,10,1]  R2741     3.6510124802589417e-01
    z[9,10,1]  R2742     2.5187534093856812e-01
    z[9,10,1]  R2743     -5.2829945087432861e-01
    z[9,10,1]  R2744     -5.9183764457702637e-01
    z[9,10,1]  R2745     -6.8946105241775513e-01
    z[9,10,1]  R2746     -5.8173561096191406e-01
    z[9,10,1]  R2747     -4.5227476954460144e-01
    z[9,10,1]  R2748     -5.3008455038070679e-01
    z[9,10,1]  R2749     -6.2674248218536377e-01
    z[9,10,1]  R2750     -1.7841532826423645e-01
    z[9,10,1]  R2751     -7.3125049471855164e-02
    z[9,10,1]  R2752     2.7809736132621765e-01
    z[9,10,1]  R2753     -8.5583233833312988e-01
    z[9,10,1]  R2754     -6.5710622072219849e-01
    z[9,10,1]  R2755     -4.3961033225059509e-01
    z[9,10,1]  R2756     -3.8813760876655579e-01
    z[9,10,1]  R2757     -4.3275612592697144e-01
    z[9,10,1]  R2758     -6.7361706495285034e-01
    z[9,10,1]  R2759     -5.6662166118621826e-01
    z[9,10,1]  R2760     -3.2149741053581238e-01
    z[9,10,1]  R2761     -1.5396389365196228e-01
    z[9,10,1]  R2762     -8.5054852068424225e-02
    z[9,10,1]  R2763     -8.5403424501419067e-01
    z[9,10,1]  R2764     -4.9898526072502136e-01
    z[9,10,1]  R2765     -3.9110168814659119e-01
    z[9,10,1]  R2766     -7.5024962425231934e-01
    z[9,10,1]  R2767     -2.7281123399734497e-01
    z[9,10,1]  R2768     4.3152235448360443e-02
    z[9,10,1]  R2769     5.2607440948486328e-01
    z[9,10,1]  R2770     5.0985753536224365e-01
    z[9,10,1]  R2771     5.1093775779008865e-02
    z[9,10,1]  R2772     5.5250930786132812e-01
    z[9,10,1]  R2773     -1.0856962949037552e-01
    z[9,10,1]  R2774     1.5542726218700409e-01
    z[9,10,1]  R2775     -1.1899171397089958e-02
    z[9,10,1]  R2776     -7.4997544288635254e-02
    z[9,10,1]  R2777     4.1021695733070374e-01
    z[9,10,1]  R2778     -3.9665222167968750e-02
    z[9,10,1]  R2779     4.5404410362243652e-01
    z[9,10,1]  R2780     4.4423744082450867e-01
    z[9,10,1]  R2781     2.4021776020526886e-01
    z[9,10,1]  R2782     4.6866810321807861e-01
    z[9,10,1]  R2783     1.7533724009990692e-01
    z[9,10,1]  R2784     1.4846704900264740e-01
    z[9,10,1]  R2785     -2.9659056663513184e-01
    z[9,10,1]  R2786     -4.6645447611808777e-01
    z[9,10,1]  R2787     -7.6093202829360962e-01
    z[9,10,1]  R2788     -7.7744621038436890e-01
    z[9,10,1]  R2789     -9.4802898168563843e-01
    z[9,10,1]  R2790     -3.0477842688560486e-01
    z[9,10,1]  R2791     -1.8231703341007233e-01
    z[9,10,1]  R2792     0.0208007600158453
    z[9,10,1]  R2793     -0.379312664270401
    z[9,10,1]  R2794     6.0360127687454224e-01
    z[9,10,1]  R2795     -1.1329365521669388e-01
    z[9,10,1]  R2796     -3.0436906218528748e-01
    z[9,10,1]  R2797     2.7989361435174942e-02
    z[9,10,1]  R2798     0.67806077003479
    z[9,10,1]  R2799     1.3304229080677032e-01
    z[9,10,1]  R2800     -5.4952919483184814e-01
    z[9,10,1]  R2801     5.9685826301574707e-01
    z[9,10,1]  R2802     7.9292759299278259e-02
    z[9,10,1]  R2803     -6.0732532292604446e-02
    z[9,10,1]  R2804     -1.7408357560634613e-01
    z[9,10,1]  R2805     2.4137814342975616e-01
    z[9,10,1]  R2806     -3.1413719058036804e-02
    z[9,10,1]  R2807     -2.7527580037713051e-02
    z[9,10,1]  R2808     8.8575951755046844e-02
    z[9,10,1]  R2809     -5.5882513523101807e-01
    z[9,10,1]  R2810     0.430237740278244
    z[9,10,1]  R2811     -6.8249548785388470e-03
    z[9,10,1]  R2812     -2.4141646921634674e-01
    z[9,10,2]  R85       -1
    z[9,10,2]  R94       1
    z[9,10,2]  R2693     -1
    z[9,10,2]  R2694     1
    z[9,10,2]  R2703     1.0386286303400993e-03
    z[9,10,2]  R2704     -4.5047495514154434e-02
    z[9,10,2]  R2705     -3.8759005069732666e-01
    z[9,10,2]  R2706     -1.3593223690986633e-01
    z[9,10,2]  R2707     -2.0350408554077148e-01
    z[9,10,2]  R2708     1.3394263386726379e-01
    z[9,10,2]  R2709     3.4943490754812956e-03
    z[9,10,2]  R2710     -1.4786422252655029e-01
    z[9,10,2]  R2711     -2.1904994547367096e-01
    z[9,10,2]  R2712     7.6188242435455322e-01
    z[9,10,2]  R2713     2.6483091711997986e-01
    z[9,10,2]  R2714     1.2022143602371216e-01
    z[9,10,2]  R2715     2.6209217309951782e-01
    z[9,10,2]  R2716     5.0239282846450806e-01
    z[9,10,2]  R2717     7.1645148098468781e-02
    z[9,10,2]  R2718     4.8133295774459839e-01
    z[9,10,2]  R2719     5.5973953008651733e-01
    z[9,10,2]  R2720     4.6483024954795837e-01
    z[9,10,2]  R2721     -2.7340808510780334e-01
    z[9,10,2]  R2722     -3.8282856345176697e-01
    z[9,10,2]  R2723     5.0953525304794312e-01
    z[9,10,2]  R2724     4.2274218797683716e-01
    z[9,10,2]  R2725     4.0736341476440430e-01
    z[9,10,2]  R2726     4.7930145263671875e-01
    z[9,10,2]  R2727     0.506238579750061
    z[9,10,2]  R2728     -0.0528477281332016
    z[9,10,2]  R2729     1.1037375032901764e-01
    z[9,10,2]  R2730     -5.6048955768346786e-02
    z[9,10,2]  R2731     -1.8911965191364288e-01
    z[9,10,2]  R2732     -6.1571896076202393e-01
    z[9,10,2]  R2733     -1.0740020871162415e-01
    z[9,10,2]  R2734     -3.3411350846290588e-01
    z[9,10,2]  R2735     -3.0589619278907776e-01
    z[9,10,2]  R2736     -6.4837050437927246e-01
    z[9,10,2]  R2737     5.5570787191390991e-01
    z[9,10,2]  R2738     1.3312242925167084e-01
    z[9,10,2]  R2739     -1.6032233834266663e-02
    z[9,10,2]  R2740     -2.3102298378944397e-01
    z[9,10,2]  R2741     -1.2256371974945068e-01
    z[9,10,2]  R2742     1.2075113505125046e-01
    z[9,10,2]  R2743     -2.2346045076847076e-01
    z[9,10,2]  R2744     0.60540372133255
    z[9,10,2]  R2745     2.0606490969657898e-01
    z[9,10,2]  R2746     -3.6067304015159607e-01
    z[9,10,2]  R2747     6.7916673421859741e-01
    z[9,10,2]  R2748     1.0233601182699203e-01
    z[9,10,2]  R2749     -4.0065848827362061e-01
    z[9,10,2]  R2750     5.6349843740463257e-01
    z[9,10,2]  R2751     4.7895425558090210e-01
    z[9,10,2]  R2752     -2.0525640249252319e-01
    z[9,10,2]  R2753     1.1915708333253860e-01
    z[9,10,2]  R2754     -2.4162931367754936e-02
    z[9,10,2]  R2755     6.9115614891052246e-01
    z[9,10,2]  R2756     2.3771961033344269e-01
    z[9,10,2]  R2757     5.9727275371551514e-01
    z[9,10,2]  R2758     3.7660089135169983e-01
    z[9,10,2]  R2759     -8.1534683704376221e-02
    z[9,10,2]  R2760     1.6884498298168182e-01
    z[9,10,2]  R2761     0.0457034595310688
    z[9,10,2]  R2762     -6.0023766756057739e-01
    z[9,10,2]  R2763     2.0172378420829773e-01
    z[9,10,2]  R2764     7.1617412567138672e-01
    z[9,10,2]  R2765     4.1023689508438110e-01
    z[9,10,2]  R2766     2.5607201457023621e-01
    z[9,10,2]  R2767     5.2217740565538406e-02
    z[9,10,2]  R2768     8.9033029973506927e-02
    z[9,10,2]  R2769     -6.4803071320056915e-02
    z[9,10,2]  R2770     8.8083133101463318e-02
    z[9,10,2]  R2771     -2.4576622247695923e-01
    z[9,10,2]  R2772     6.7231643199920654e-01
    z[9,10,2]  R2773     -2.9010385274887085e-01
    z[9,10,2]  R2774     -2.3738962411880493e-01
    z[9,10,2]  R2775     -2.5479811429977417e-01
    z[9,10,2]  R2776     -5.6889832019805908e-01
    z[9,10,2]  R2777     -2.5653791427612305e-01
    z[9,10,2]  R2778     -5.0786983966827393e-01
    z[9,10,2]  R2779     2.6203829050064087e-01
    z[9,10,2]  R2780     5.5182456970214844e-02
    z[9,10,2]  R2781     -6.7197734117507935e-01
    z[9,10,2]  R2782     6.0794495046138763e-02
    z[9,10,2]  R2783     2.9034504666924477e-02
    z[9,10,2]  R2784     1.1902976036071777e-01
    z[9,10,2]  R2785     1.1844386905431747e-01
    z[9,10,2]  R2786     -1.0425622761249542e-01
    z[9,10,2]  R2787     8.9256383478641510e-02
    z[9,10,2]  R2788     2.5807061791419983e-01
    z[9,10,2]  R2789     -0.00564618781208992
    z[9,10,2]  R2790     -7.6905570924282074e-02
    z[9,10,2]  R2791     1.9678516313433647e-02
    z[9,10,2]  R2792     1.1538688093423843e-01
    z[9,10,2]  R2793     -2.1094707772135735e-02
    z[9,10,2]  R2794     4.1736122965812683e-01
    z[9,10,2]  R2795     7.0153094828128815e-02
    z[9,10,2]  R2796     -3.8802798837423325e-02
    z[9,10,2]  R2797     1.8816716969013214e-01
    z[9,10,2]  R2798     2.3320975899696350e-01
    z[9,10,2]  R2799     -4.6710226684808731e-02
    z[9,10,2]  R2800     7.3537260293960571e-02
    z[9,10,2]  R2801     -3.7699963431805372e-03
    z[9,10,2]  R2802     -8.2393847405910492e-02
    z[9,10,2]  R2803     -7.5839266180992126e-02
    z[9,10,2]  R2804     2.0828737318515778e-01
    z[9,10,2]  R2805     1.2249260395765305e-01
    z[9,10,2]  R2806     -1.1270281672477722e-01
    z[9,10,2]  R2807     -2.6481010019779205e-02
    z[9,10,2]  R2808     -2.3649835586547852e-01
    z[9,10,2]  R2809     -4.7293606400489807e-01
    z[9,10,2]  R2810     -1.7638376355171204e-01
    z[9,10,2]  R2811     -2.5224119424819946e-01
    z[9,10,2]  R2812     2.0095808804035187e-01
    z[9,10,3]  R86       -1
    z[9,10,3]  R95       1
    z[9,10,3]  R2695     -1
    z[9,10,3]  R2696     1
    z[9,10,3]  R2703     0.630595862865448
    z[9,10,3]  R2704     3.2040849328041077e-01
    z[9,10,3]  R2705     4.2054033279418945e-01
    z[9,10,3]  R2706     2.8039768338203430e-01
    z[9,10,3]  R2707     6.8141895532608032e-01
    z[9,10,3]  R2708     0.524479329586029
    z[9,10,3]  R2709     5.2910721302032471e-01
    z[9,10,3]  R2710     6.7841708660125732e-01
    z[9,10,3]  R2711     2.3260892927646637e-01
    z[9,10,3]  R2712     3.1640842556953430e-01
    z[9,10,3]  R2713     -0.0922887921333313
    z[9,10,3]  R2714     -8.1799037754535675e-02
    z[9,10,3]  R2715     -1.5462781488895416e-01
    z[9,10,3]  R2716     -1.4706438779830933e-01
    z[9,10,3]  R2717     -2.7036878466606140e-01
    z[9,10,3]  R2718     -5.1282446831464767e-02
    z[9,10,3]  R2719     -1.6719731688499451e-01
    z[9,10,3]  R2720     4.5264132320880890e-02
    z[9,10,3]  R2721     -3.4057107567787170e-01
    z[9,10,3]  R2722     -4.3049478530883789e-01
    z[9,10,3]  R2723     -3.1722940504550934e-02
    z[9,10,3]  R2724     2.6191183924674988e-01
    z[9,10,3]  R2725     2.0088051259517670e-01
    z[9,10,3]  R2726     -1.5801148116588593e-01
    z[9,10,3]  R2727     3.7539863586425781e-01
    z[9,10,3]  R2728     -2.1942764520645142e-01
    z[9,10,3]  R2729     -4.3343058228492737e-01
    z[9,10,3]  R2730     6.8287503719329834e-01
    z[9,10,3]  R2731     -7.0812559127807617e-01
    z[9,10,3]  R2732     -3.3075016736984253e-01
    z[9,10,3]  R2733     -1.3071247935295105e-01
    z[9,10,3]  R2734     2.7870687842369080e-01
    z[9,10,3]  R2735     5.4167336225509644e-01
    z[9,10,3]  R2736     1.5987187623977661e-01
    z[9,10,3]  R2737     -1.5942801535129547e-01
    z[9,10,3]  R2738     2.6197269558906555e-01
    z[9,10,3]  R2739     -6.6071957349777222e-01
    z[9,10,3]  R2740     -5.8773660659790039e-01
    z[9,10,3]  R2741     -5.7532048225402832e-01
    z[9,10,3]  R2742     -5.9662473201751709e-01
    z[9,10,3]  R2743     -2.4122324585914612e-01
    z[9,10,3]  R2744     0.0994042381644249
    z[9,10,3]  R2745     -2.5547316670417786e-01
    z[9,10,3]  R2746     6.9014841318130493e-01
    z[9,10,3]  R2747     1.4085161685943604e-01
    z[9,10,3]  R2748     2.4849760532379150e-01
    z[9,10,3]  R2749     2.2239649295806885e-01
    z[9,10,3]  R2750     -2.5498563051223755e-01
    z[9,10,3]  R2751     -2.6442768052220345e-02
    z[9,10,3]  R2752     -1.3136214017868042e-01
    z[9,10,3]  R2753     8.0912478268146515e-02
    z[9,10,3]  R2754     1.8270447850227356e-01
    z[9,10,3]  R2755     5.7935353368520737e-02
    z[9,10,3]  R2756     0.816985547542572
    z[9,10,3]  R2757     -1.5790291130542755e-01
    z[9,10,3]  R2758     -2.7754920721054077e-01
    z[9,10,3]  R2759     -2.4088135361671448e-01
    z[9,10,3]  R2760     5.4302625358104706e-02
    z[9,10,3]  R2761     -1.5420977771282196e-01
    z[9,10,3]  R2762     -1.8729925155639648e-01
    z[9,10,3]  R2763     -1.7744068801403046e-01
    z[9,10,3]  R2764     9.2129111289978027e-02
    z[9,10,3]  R2765     1.0381588339805603e-01
    z[9,10,3]  R2766     -4.5471572875976562e-01
    z[9,10,3]  R2767     -5.7463750243186951e-02
    z[9,10,3]  R2768     -7.5366806983947754e-01
    z[9,10,3]  R2769     -1.6991352662444115e-02
    z[9,10,3]  R2770     7.7977791428565979e-02
    z[9,10,3]  R2771     -0.704690158367157
    z[9,10,3]  R2772     -2.0809842646121979e-01
    z[9,10,3]  R2773     0.681239128112793
    z[9,10,3]  R2774     0.60472571849823
    z[9,10,3]  R2775     6.0739618539810181e-01
    z[9,10,3]  R2776     5.0476962327957153e-01
    z[9,10,3]  R2777     7.8265631198883057e-01
    z[9,10,3]  R2778     7.2275739908218384e-01
    z[9,10,3]  R2779     2.7796402573585510e-01
    z[9,10,3]  R2780     3.9726930856704712e-01
    z[9,10,3]  R2781     1.5290898084640503e-01
    z[9,10,3]  R2782     4.6916228532791138e-01
    z[9,10,3]  R2783     -5.4265791177749634e-01
    z[9,10,3]  R2784     -2.4831391870975494e-01
    z[9,10,3]  R2785     -5.9818738698959351e-01
    z[9,10,3]  R2786     -3.9339289069175720e-01
    z[9,10,3]  R2787     -0.0786762535572052
    z[9,10,3]  R2788     3.8056049495935440e-02
    z[9,10,3]  R2789     -2.0746810361742973e-02
    z[9,10,3]  R2790     -8.0624771118164062e-01
    z[9,10,3]  R2791     0.659960150718689
    z[9,10,3]  R2792     -8.2981234788894653e-01
    z[9,10,3]  R2793     -7.2701941244304180e-03
    z[9,10,3]  R2794     -3.7577623128890991e-01
    z[9,10,3]  R2795     -4.4316515326499939e-02
    z[9,10,3]  R2796     1.3924965262413025e-01
    z[9,10,3]  R2797     -2.1064251661300659e-01
    z[9,10,3]  R2798     3.6444085836410522e-01
    z[9,10,3]  R2799     2.8647786378860474e-01
    z[9,10,3]  R2800     -6.1262732744216919e-01
    z[9,10,3]  R2801     -1.9766797125339508e-01
    z[9,10,3]  R2802     -5.6900459527969360e-01
    z[9,10,3]  R2803     2.1127900481224060e-01
    z[9,10,3]  R2804     -9.1145741939544678e-01
    z[9,10,3]  R2805     -8.0859714746475220e-01
    z[9,10,3]  R2806     -7.2537130117416382e-01
    z[9,10,3]  R2807     -5.8372038602828979e-01
    z[9,10,3]  R2808     -4.6204555034637451e-01
    z[9,10,3]  R2809     2.8942093253135681e-01
    z[9,10,3]  R2810     5.1352846622467041e-01
    z[9,10,3]  R2811     -0.468342125415802
    z[9,10,3]  R2812     -5.5705946683883667e-01
    z[9,10,4]  R87       -1
    z[9,10,4]  R96       1
    z[9,10,4]  R2697     -1
    z[9,10,4]  R2698     1
    z[9,10,4]  R2703     -2.3744067549705505e-01
    z[9,10,4]  R2704     0.0827716812491417
    z[9,10,4]  R2705     -5.7877349853515625e-01
    z[9,10,4]  R2706     -4.7462841868400574e-01
    z[9,10,4]  R2707     -3.8081204891204834e-01
    z[9,10,4]  R2708     -0.628445029258728
    z[9,10,4]  R2709     -4.8358172178268433e-01
    z[9,10,4]  R2710     -5.2478021383285522e-01
    z[9,10,4]  R2711     3.8961541652679443e-01
    z[9,10,4]  R2712     5.0594240427017212e-01
    z[9,10,4]  R2713     2.4471342563629150e-01
    z[9,10,4]  R2714     -2.8229910880327225e-02
    z[9,10,4]  R2715     5.2011376619338989e-01
    z[9,10,4]  R2716     -9.4679847359657288e-02
    z[9,10,4]  R2717     3.9547699689865112e-01
    z[9,10,4]  R2718     9.6088767051696777e-02
    z[9,10,4]  R2719     4.8031383752822876e-01
    z[9,10,4]  R2720     -1.4868909120559692e-01
    z[9,10,4]  R2721     3.5853621363639832e-01
    z[9,10,4]  R2722     1.0054794698953629e-01
    z[9,10,4]  R2723     -2.9966783523559570e-01
    z[9,10,4]  R2724     0.308178573846817
    z[9,10,4]  R2725     0.501348614692688
    z[9,10,4]  R2726     4.1890364140272141e-02
    z[9,10,4]  R2727     1.7075219750404358e-01
    z[9,10,4]  R2728     3.2352928072214127e-02
    z[9,10,4]  R2729     -2.3997258394956589e-02
    z[9,10,4]  R2730     3.6097481846809387e-01
    z[9,10,4]  R2731     -1.7721448838710785e-01
    z[9,10,4]  R2732     4.0443789958953857e-01
    z[9,10,4]  R2733     1.4199002087116241e-01
    z[9,10,4]  R2734     -8.5988417267799377e-02
    z[9,10,4]  R2735     -8.8775508105754852e-02
    z[9,10,4]  R2736     3.4498311579227448e-02
    z[9,10,4]  R2737     5.0465297698974609e-01
    z[9,10,4]  R2738     3.7336525321006775e-01
    z[9,10,4]  R2739     3.6075541377067566e-01
    z[9,10,4]  R2740     4.2704832553863525e-01
    z[9,10,4]  R2741     4.9841120839118958e-01
    z[9,10,4]  R2742     6.9261372089385986e-01
    z[9,10,4]  R2743     -0.00996506679803133
    z[9,10,4]  R2744     3.2574638724327087e-01
    z[9,10,4]  R2745     0.284542053937912
    z[9,10,4]  R2746     1.0995614528656006e-01
    z[9,10,4]  R2747     4.5094323158264160e-01
    z[9,10,4]  R2748     -2.1217282116413116e-01
    z[9,10,4]  R2749     0.539861261844635
    z[9,10,4]  R2750     6.7160254716873169e-01
    z[9,10,4]  R2751     8.1771403551101685e-01
    z[9,10,4]  R2752     0.30640709400177
    z[9,10,4]  R2753     -3.5012137889862061e-01
    z[9,10,4]  R2754     -5.1747161149978638e-01
    z[9,10,4]  R2755     2.7940675616264343e-01
    z[9,10,4]  R2756     2.8810921311378479e-01
    z[9,10,4]  R2757     6.4422529935836792e-01
    z[9,10,4]  R2758     2.4196559190750122e-01
    z[9,10,4]  R2759     7.9599432647228241e-02
    z[9,10,4]  R2760     1.9483956694602966e-01
    z[9,10,4]  R2761     -1.6300510615110397e-03
    z[9,10,4]  R2762     -1.1140790581703186e-01
    z[9,10,4]  R2763     1.9025810062885284e-01
    z[9,10,4]  R2764     2.1849417686462402e-01
    z[9,10,4]  R2765     6.2847083806991577e-01
    z[9,10,4]  R2766     2.0253662765026093e-01
    z[9,10,4]  R2767     4.2726555466651917e-01
    z[9,10,4]  R2768     4.5717346668243408e-01
    z[9,10,4]  R2769     -0.00543689401820302
    z[9,10,4]  R2770     1.8286738544702530e-02
    z[9,10,4]  R2771     2.8732625767588615e-02
    z[9,10,4]  R2772     -3.3437472581863403e-01
    z[9,10,4]  R2773     -0.373605340719223
    z[9,10,4]  R2774     -4.2356446385383606e-01
    z[9,10,4]  R2775     -0.398029625415802
    z[9,10,4]  R2776     -4.5387169718742371e-01
    z[9,10,4]  R2777     -2.6355615258216858e-01
    z[9,10,4]  R2778     -2.7197670936584473e-01
    z[9,10,4]  R2779     -2.3760432004928589e-01
    z[9,10,4]  R2780     2.5522655248641968e-01
    z[9,10,4]  R2781     -5.6038123369216919e-01
    z[9,10,4]  R2782     -3.9787578582763672e-01
    z[9,10,4]  R2783     2.4450273811817169e-01
    z[9,10,4]  R2784     0.608993411064148
    z[9,10,4]  R2785     5.3822201490402222e-01
    z[9,10,4]  R2786     7.5127941370010376e-01
    z[9,10,4]  R2787     9.2514185234904289e-03
    z[9,10,4]  R2788     -2.5473731756210327e-01
    z[9,10,4]  R2789     -1.2457814998924732e-02
    z[9,10,4]  R2790     1.0844941437244415e-01
    z[9,10,4]  R2791     -2.1772688627243042e-01
    z[9,10,4]  R2792     1.3864155113697052e-01
    z[9,10,4]  R2793     -7.7451360225677490e-01
    z[9,10,4]  R2794     1.9043922424316406e-02
    z[9,10,4]  R2795     -9.7413694858551025e-01
    z[9,10,4]  R2796     -8.8898915052413940e-01
    z[9,10,4]  R2797     -6.9305545091629028e-01
    z[9,10,4]  R2798     -3.1474456191062927e-01
    z[9,10,4]  R2799     -6.7333787679672241e-01
    z[9,10,4]  R2800     2.5464621186256409e-01
    z[9,10,4]  R2801     -2.3097757995128632e-01
    z[9,10,4]  R2802     6.5534484386444092e-01
    z[9,10,4]  R2803     -8.8822716474533081e-01
    z[9,10,4]  R2804     2.6076236367225647e-01
    z[9,10,4]  R2805     5.9483081102371216e-02
    z[9,10,4]  R2806     6.3341581821441650e-01
    z[9,10,4]  R2807     3.4353023767471313e-01
    z[9,10,4]  R2808     5.9049171209335327e-01
    z[9,10,4]  R2809     3.7947988510131836e-01
    z[9,10,4]  R2810     4.8621911555528641e-02
    z[9,10,4]  R2811     7.9095101356506348e-01
    z[9,10,4]  R2812     1.3062059879302979e-01
    z[9,10,5]  R88       -1
    z[9,10,5]  R97       1
    z[9,10,5]  R2699     -1
    z[9,10,5]  R2700     1
    z[9,10,5]  R2703     6.0959124565124512e-01
    z[9,10,5]  R2704     6.8604147434234619e-01
    z[9,10,5]  R2705     5.3980922698974609e-01
    z[9,10,5]  R2706     6.4250773191452026e-01
    z[9,10,5]  R2707     1.0501185804605484e-01
    z[9,10,5]  R2708     -0.0551178939640522
    z[9,10,5]  R2709     -4.7281570732593536e-02
    z[9,10,5]  R2710     -1.8524868786334991e-01
    z[9,10,5]  R2711     4.8076584935188293e-01
    z[9,10,5]  R2712     1.7615149915218353e-01
    z[9,10,5]  R2713     -3.2450765371322632e-02
    z[9,10,5]  R2714     -2.6499629020690918e-01
    z[9,10,5]  R2715     -2.2803871333599091e-01
    z[9,10,5]  R2716     -4.5225575566291809e-01
    z[9,10,5]  R2717     -2.0371034741401672e-01
    z[9,10,5]  R2718     1.9490176811814308e-02
    z[9,10,5]  R2719     4.2251139879226685e-01
    z[9,10,5]  R2720     -7.7622950077056885e-02
    z[9,10,5]  R2721     -5.9538954496383667e-01
    z[9,10,5]  R2722     -3.1654247641563416e-01
    z[9,10,5]  R2723     -2.1380858495831490e-02
    z[9,10,5]  R2724     3.6986616253852844e-01
    z[9,10,5]  R2725     -2.9593309760093689e-01
    z[9,10,5]  R2726     1.3574530184268951e-01
    z[9,10,5]  R2727     -1.8741288781166077e-01
    z[9,10,5]  R2728     1.8684232234954834e-01
    z[9,10,5]  R2729     -3.0348542332649231e-01
    z[9,10,5]  R2730     -2.4751265347003937e-01
    z[9,10,5]  R2731     -0.0328182727098465
    z[9,10,5]  R2732     -8.9843444526195526e-02
    z[9,10,5]  R2733     -1.9645778834819794e-01
    z[9,10,5]  R2734     -1.1482248082756996e-03
    z[9,10,5]  R2735     3.2897189259529114e-02
    z[9,10,5]  R2736     -1.6976065933704376e-01
    z[9,10,5]  R2737     3.4776532649993896e-01
    z[9,10,5]  R2738     -4.6710196137428284e-01
    z[9,10,5]  R2739     -5.9684950113296509e-01
    z[9,10,5]  R2740     -0.605772852897644
    z[9,10,5]  R2741     -4.8108381032943726e-01
    z[9,10,5]  R2742     -1.9799204170703888e-01
    z[9,10,5]  R2743     6.4184987545013428e-01
    z[9,10,5]  R2744     3.9485642313957214e-01
    z[9,10,5]  R2745     3.1156671047210693e-01
    z[9,10,5]  R2746     -1.9592662155628204e-01
    z[9,10,5]  R2747     -2.3011548817157745e-01
    z[9,10,5]  R2748     1.0768519714474678e-02
    z[9,10,5]  R2749     -9.4771005213260651e-02
    z[9,10,5]  R2750     1.3257928192615509e-01
    z[9,10,5]  R2751     1.5410327911376953e-01
    z[9,10,5]  R2752     -3.1746536493301392e-01
    z[9,10,5]  R2753     -2.8857348486781120e-02
    z[9,10,5]  R2754     3.4091625362634659e-02
    z[9,10,5]  R2755     4.4156581163406372e-01
    z[9,10,5]  R2756     -1.4573523402214050e-01
    z[9,10,5]  R2757     -5.5646669119596481e-02
    z[9,10,5]  R2758     3.8169354200363159e-02
    z[9,10,5]  R2759     -3.1596621870994568e-01
    z[9,10,5]  R2760     -4.7881278395652771e-01
    z[9,10,5]  R2761     -5.1543056964874268e-01
    z[9,10,5]  R2762     -2.6525703072547913e-01
    z[9,10,5]  R2763     1.2550760805606842e-01
    z[9,10,5]  R2764     3.5498419404029846e-01
    z[9,10,5]  R2765     8.3474688231945038e-02
    z[9,10,5]  R2766     3.2502165436744690e-01
    z[9,10,5]  R2767     -3.1508678197860718e-01
    z[9,10,5]  R2768     -3.2217675447463989e-01
    z[9,10,5]  R2769     2.5536064058542252e-02
    z[9,10,5]  R2770     -4.1888780891895294e-02
    z[9,10,5]  R2771     -5.7469010353088379e-01
    z[9,10,5]  R2772     -1.2234982103109360e-01
    z[9,10,5]  R2773     2.1554559469223022e-01
    z[9,10,5]  R2774     0.526763379573822
    z[9,10,5]  R2775     2.4247248470783234e-01
    z[9,10,5]  R2776     4.0691789984703064e-01
    z[9,10,5]  R2777     8.9430719614028931e-02
    z[9,10,5]  R2778     2.4368791282176971e-01
    z[9,10,5]  R2779     6.6027349233627319e-01
    z[9,10,5]  R2780     6.5822386741638184e-01
    z[9,10,5]  R2781     3.9039081335067749e-01
    z[9,10,5]  R2782     -5.4581277072429657e-03
    z[9,10,5]  R2783     -1.6746070981025696e-01
    z[9,10,5]  R2784     -3.0789282917976379e-01
    z[9,10,5]  R2785     6.6035546362400055e-02
    z[9,10,5]  R2786     -7.0266634225845337e-02
    z[9,10,5]  R2787     6.1950433254241943e-01
    z[9,10,5]  R2788     4.0019720792770386e-01
    z[9,10,5]  R2789     2.5226727128028870e-01
    z[9,10,5]  R2790     -2.4337185919284821e-01
    z[9,10,5]  R2791     -2.9784369468688965e-01
    z[9,10,5]  R2792     -3.6523076891899109e-01
    z[9,10,5]  R2793     -4.7111743688583374e-01
    z[9,10,5]  R2794     -2.3197950422763824e-01
    z[9,10,5]  R2795     9.6717111766338348e-02
    z[9,10,5]  R2796     -7.5587600469589233e-02
    z[9,10,5]  R2797     3.7458430975675583e-02
    z[9,10,5]  R2798     -3.5075005888938904e-01
    z[9,10,5]  R2799     -5.9254580736160278e-01
    z[9,10,5]  R2800     -1.3819037377834320e-01
    z[9,10,5]  R2801     -1.7041382193565369e-01
    z[9,10,5]  R2802     -0.178700253367424
    z[9,10,5]  R2803     -3.0035126209259033e-01
    z[9,10,5]  R2804     0.00954553671181202
    z[9,10,5]  R2805     -0.50865638256073
    z[9,10,5]  R2806     -1.3811635971069336e-01
    z[9,10,5]  R2807     -2.9512956738471985e-01
    z[9,10,5]  R2808     -5.0582069158554077e-01
    z[9,10,5]  R2809     2.9561811685562134e-01
    z[9,10,5]  R2810     -2.2971833124756813e-02
    z[9,10,5]  R2811     -2.9978886246681213e-01
    z[9,10,5]  R2812     -0.70634526014328
    z[9,10,6]  R89       -1
    z[9,10,6]  R98       1
    z[9,10,6]  R2701     -1
    z[9,10,6]  R2702     1
    z[9,10,6]  R2703     -4.5436579734086990e-02
    z[9,10,6]  R2704     1.3276310265064240e-01
    z[9,10,6]  R2705     -1.7145794630050659e-01
    z[9,10,6]  R2706     4.4282466173171997e-01
    z[9,10,6]  R2707     1.1576970666646957e-01
    z[9,10,6]  R2708     1.3626264035701752e-01
    z[9,10,6]  R2709     4.5209395885467529e-01
    z[9,10,6]  R2710     -2.9960680007934570e-01
    z[9,10,6]  R2711     -6.1643189191818237e-01
    z[9,10,6]  R2712     1.3172204792499542e-01
    z[9,10,6]  R2713     5.9821295738220215e-01
    z[9,10,6]  R2714     -6.0290664434432983e-01
    z[9,10,6]  R2715     -5.3319036960601807e-01
    z[9,10,6]  R2716     9.2168338596820831e-02
    z[9,10,6]  R2717     -3.1946465373039246e-01
    z[9,10,6]  R2718     -3.0811068415641785e-01
    z[9,10,6]  R2719     -6.1776839196681976e-02
    z[9,10,6]  R2720     -1.9178394973278046e-01
    z[9,10,6]  R2721     -0.0774015337228775
    z[9,10,6]  R2722     1.2274991720914841e-01
    z[9,10,6]  R2723     1.9521857798099518e-01
    z[9,10,6]  R2724     -2.3522333800792694e-01
    z[9,10,6]  R2725     -4.9021661281585693e-02
    z[9,10,6]  R2726     -1.4449508488178253e-01
    z[9,10,6]  R2727     -3.9919081330299377e-01
    z[9,10,6]  R2728     -4.1840910911560059e-01
    z[9,10,6]  R2729     -0.0537693053483963
    z[9,10,6]  R2730     2.9884251952171326e-01
    z[9,10,6]  R2731     -1.2494862079620361e-01
    z[9,10,6]  R2732     -9.6965618431568146e-02
    z[9,10,6]  R2733     -1.0616531595587730e-02
    z[9,10,6]  R2734     -1.4885148033499718e-02
    z[9,10,6]  R2735     -2.7475917339324951e-01
    z[9,10,6]  R2736     2.2646412253379822e-01
    z[9,10,6]  R2737     8.6878068745136261e-02
    z[9,10,6]  R2738     2.5030277669429779e-02
    z[9,10,6]  R2739     2.5785481929779053e-01
    z[9,10,6]  R2740     -2.1536734700202942e-01
    z[9,10,6]  R2741     4.1040789335966110e-02
    z[9,10,6]  R2742     0.205540731549263
    z[9,10,6]  R2743     -0.342171311378479
    z[9,10,6]  R2744     -1.0002993047237396e-01
    z[9,10,6]  R2745     3.2614961266517639e-01
    z[9,10,6]  R2746     7.5960271060466766e-03
    z[9,10,6]  R2747     -6.0785752721130848e-03
    z[9,10,6]  R2748     -3.8614797592163086e-01
    z[9,10,6]  R2749     -1.1958386749029160e-01
    z[9,10,6]  R2750     -1.9437422975897789e-02
    z[9,10,6]  R2751     -6.9461479783058167e-02
    z[9,10,6]  R2752     1.9744911789894104e-01
    z[9,10,6]  R2753     -2.9330024123191833e-01
    z[9,10,6]  R2754     -3.4934807568788528e-02
    z[9,10,6]  R2755     2.2088389098644257e-01
    z[9,10,6]  R2756     1.3635644316673279e-01
    z[9,10,6]  R2757     -1.0868085175752640e-01
    z[9,10,6]  R2758     1.6315829753875732e-01
    z[9,10,6]  R2759     4.0994000434875488e-01
    z[9,10,6]  R2760     2.5183673948049545e-02
    z[9,10,6]  R2761     4.0462979674339294e-01
    z[9,10,6]  R2762     -3.1075802445411682e-01
    z[9,10,6]  R2763     3.1362724304199219e-01
    z[9,10,6]  R2764     2.3466531932353973e-01
    z[9,10,6]  R2765     -6.3345089554786682e-02
    z[9,10,6]  R2766     -3.3809497952461243e-02
    z[9,10,6]  R2767     -2.1018752455711365e-01
    z[9,10,6]  R2768     2.7088707685470581e-01
    z[9,10,6]  R2769     -2.2203331813216209e-02
    z[9,10,6]  R2770     4.9485091120004654e-02
    z[9,10,6]  R2771     9.9782370030879974e-02
    z[9,10,6]  R2772     -2.5111085176467896e-01
    z[9,10,6]  R2773     3.1115907430648804e-01
    z[9,10,6]  R2774     2.2180373966693878e-01
    z[9,10,6]  R2775     -2.1379025280475616e-01
    z[9,10,6]  R2776     -2.0424191653728485e-01
    z[9,10,6]  R2777     2.5111040472984314e-01
    z[9,10,6]  R2778     -2.2403696179389954e-01
    z[9,10,6]  R2779     1.4899879693984985e-01
    z[9,10,6]  R2780     2.7462151646614075e-01
    z[9,10,6]  R2781     2.3706594482064247e-02
    z[9,10,6]  R2782     4.6787819266319275e-01
    z[9,10,6]  R2783     -6.4719456434249878e-01
    z[9,10,6]  R2784     -6.5354377031326294e-01
    z[9,10,6]  R2785     -1.4812734723091125e-01
    z[9,10,6]  R2786     0.135025292634964
    z[9,10,6]  R2787     1.5096846222877502e-01
    z[9,10,6]  R2788     2.2642095386981964e-01
    z[9,10,6]  R2789     -4.4093031436204910e-02
    z[9,10,6]  R2790     -2.5611397624015808e-01
    z[9,10,6]  R2791     -3.5083033144474030e-02
    z[9,10,6]  R2792     1.0351660847663879e-01
    z[9,10,6]  R2793     0.156805619597435
    z[9,10,6]  R2794     5.0296908617019653e-01
    z[9,10,6]  R2795     -1.0307624936103821e-01
    z[9,10,6]  R2796     2.2044481709599495e-02
    z[9,10,6]  R2797     5.8471059799194336e-01
    z[9,10,6]  R2798     3.5739752650260925e-01
    z[9,10,6]  R2799     -3.0509757995605469e-01
    z[9,10,6]  R2800     -1.1545576900243759e-01
    z[9,10,6]  R2801     -0.00886712409555912
    z[9,10,6]  R2802     2.6179659366607666e-01
    z[9,10,6]  R2803     1.6377250850200653e-01
    z[9,10,6]  R2804     1.6131460666656494e-01
    z[9,10,6]  R2805     -0.0995606854557991
    z[9,10,6]  R2806     -1.2396887689828873e-01
    z[9,10,6]  R2807     -3.1050941348075867e-01
    z[9,10,6]  R2808     -2.5741836428642273e-01
    z[9,10,6]  R2809     -2.6364496350288391e-01
    z[9,10,6]  R2810     -0.352649450302124
    z[9,10,6]  R2811     -2.1015355363488197e-02
    z[9,10,6]  R2812     2.6889881491661072e-01
    z[10,9,0]  R83       1
    z[10,9,0]  R92       -1
    z[10,9,0]  R2813     -1
    z[10,9,0]  R2814     1
    z[10,9,0]  R2827     -3.9636448025703430e-01
    z[10,9,0]  R2828     -2.1843071281909943e-01
    z[10,9,0]  R2829     -5.5052655935287476e-01
    z[10,9,0]  R2830     -5.1393687725067139e-02
    z[10,9,0]  R2831     -1.1332868784666061e-01
    z[10,9,0]  R2832     -1.8592710793018341e-01
    z[10,9,0]  R2833     3.6510050296783447e-01
    z[10,9,0]  R2834     2.6070839166641235e-01
    z[10,9,0]  R2835     -1.9142383709549904e-02
    z[10,9,0]  R2836     -4.2343366146087646e-01
    z[10,9,0]  R2837     4.0896305441856384e-01
    z[10,9,0]  R2838     -9.6639342606067657e-02
    z[10,9,0]  R2839     -4.7348892688751221e-01
    z[10,9,0]  R2840     -1.7088831961154938e-01
    z[10,9,0]  R2841     -1.2774877250194550e-02
    z[10,9,0]  R2842     2.2630387544631958e-01
    z[10,9,0]  R2843     1.8719108402729034e-01
    z[10,9,0]  R2844     -3.3848896622657776e-01
    z[10,9,0]  R2845     6.2727910280227661e-01
    z[10,9,0]  R2846     -3.6651602387428284e-01
    z[10,9,0]  R2847     -9.5985263586044312e-02
    z[10,9,0]  R2848     1.1450875550508499e-01
    z[10,9,0]  R2849     1.0657140612602234e-01
    z[10,9,0]  R2850     2.9993700981140137e-01
    z[10,9,0]  R2851     -3.0955451726913452e-01
    z[10,9,0]  R2852     -5.6630626320838928e-02
    z[10,9,0]  R2853     2.1666556596755981e-02
    z[10,9,0]  R2854     4.6906974911689758e-01
    z[10,9,0]  R2855     -7.2263628244400024e-01
    z[10,9,0]  R2856     -3.6497896909713745e-01
    z[10,9,0]  R2857     -1.9985330104827881e-01
    z[10,9,0]  R2858     -3.8029614835977554e-02
    z[10,9,0]  R2859     -2.6851644739508629e-02
    z[10,9,0]  R2860     1.5648564696311951e-01
    z[10,9,0]  R2861     5.9689271450042725e-01
    z[10,9,0]  R2862     2.2789795696735382e-01
    z[10,9,0]  R2863     -2.8174072504043579e-01
    z[10,9,0]  R2864     6.2675297260284424e-01
    z[10,9,0]  R2865     -3.2631557434797287e-02
    z[10,9,0]  R2866     5.2217852324247360e-02
    z[10,9,0]  R2867     -4.1501635313034058e-01
    z[10,9,0]  R2868     -6.1638349294662476e-01
    z[10,9,0]  R2869     -1.2898580729961395e-01
    z[10,9,0]  R2870     -1.0595534741878510e-01
    z[10,9,0]  R2871     -2.1235486865043640e-01
    z[10,9,0]  R2872     -3.5595887899398804e-01
    z[10,9,0]  R2873     -4.8017153143882751e-01
    z[10,9,0]  R2874     -3.4229013323783875e-01
    z[10,9,0]  R2875     -3.6051180958747864e-01
    z[10,9,0]  R2876     1.0068622976541519e-01
    z[10,9,0]  R2877     -6.2879495322704315e-02
    z[10,9,0]  R2878     2.3196329176425934e-01
    z[10,9,0]  R2879     -1.3041956722736359e-01
    z[10,9,0]  R2880     0.473922997713089
    z[10,9,0]  R2881     4.8206233978271484e-01
    z[10,9,0]  R2882     4.1645923256874084e-01
    z[10,9,0]  R2883     2.4854870140552521e-01
    z[10,9,0]  R2884     5.7460528612136841e-01
    z[10,9,0]  R2885     -0.0876041129231453
    z[10,9,0]  R2886     -7.3631328344345093e-01
    z[10,9,0]  R2887     2.2810553014278412e-01
    z[10,9,0]  R2888     1.8212832510471344e-01
    z[10,9,0]  R2889     5.9286877512931824e-02
    z[10,9,0]  R2890     5.3127199411392212e-01
    z[10,9,0]  R2891     -1.2675017118453979e-01
    z[10,9,0]  R2892     -3.8847783207893372e-01
    z[10,9,0]  R2893     -2.9837992787361145e-01
    z[10,9,0]  R2894     2.4467872083187103e-01
    z[10,9,0]  R2895     2.3737061023712158e-01
    z[10,9,0]  R2896     7.8550964593887329e-02
    z[10,9,0]  R2897     -2.1258579194545746e-01
    z[10,9,0]  R2898     4.4759336113929749e-01
    z[10,9,0]  R2899     2.6186940073966980e-01
    z[10,9,0]  R2900     1.5955546498298645e-01
    z[10,9,0]  R2901     -2.0481684803962708e-01
    z[10,9,0]  R2902     -0.731015682220459
    z[10,9,0]  R2903     -8.7707176804542542e-02
    z[10,9,0]  R2904     -3.4270800650119781e-02
    z[10,9,0]  R2905     1.9785304367542267e-01
    z[10,9,0]  R2906     6.9680482149124146e-02
    z[10,9,0]  R2907     -2.8917935490608215e-01
    z[10,9,0]  R2908     -3.6127030849456787e-02
    z[10,9,0]  R2909     3.6400923132896423e-01
    z[10,9,0]  R2910     -0.0682537704706192
    z[10,9,0]  R2911     -2.4083405733108521e-01
    z[10,9,0]  R2912     6.7271322011947632e-01
    z[10,9,0]  R2913     2.8718367218971252e-01
    z[10,9,0]  R2914     3.4148886799812317e-01
    z[10,9,0]  R2915     -2.5947546958923340e-01
    z[10,9,0]  R2916     -7.9348587989807129e-01
    z[10,9,0]  R2917     -1.9329544901847839e-01
    z[10,9,0]  R2918     5.1389408111572266e-01
    z[10,9,0]  R2919     6.2059406191110611e-02
    z[10,9,0]  R2920     5.0344061106443405e-02
    z[10,9,0]  R2921     -3.3465296030044556e-02
    z[10,9,0]  R2922     -4.9066618084907532e-01
    z[10,9,0]  R2923     5.8313506841659546e-01
    z[10,9,0]  R2924     -7.7286720275878906e-01
    z[10,9,0]  R2925     -0.721823513507843
    z[10,9,0]  R2926     -6.4657241106033325e-01
    z[10,9,0]  R2927     2.1939818561077118e-01
    z[10,9,0]  R2928     2.8270853683352470e-02
    z[10,9,0]  R2929     -5.1187032461166382e-01
    z[10,9,0]  R2930     -1.3031905889511108e-01
    z[10,9,0]  R2931     -7.7040952444076538e-01
    z[10,9,0]  R2932     1.8976368010044098e-01
    z[10,9,0]  R2933     0.847102701663971
    z[10,9,0]  R2934     8.4951055049896240e-01
    z[10,9,0]  R2935     3.1519749760627747e-01
    z[10,9,0]  R2936     9.7910448908805847e-02
    z[10,9,1]  R84       1
    z[10,9,1]  R93       -1
    z[10,9,1]  R2815     -1
    z[10,9,1]  R2816     1
    z[10,9,1]  R2827     -1.0856962949037552e-01
    z[10,9,1]  R2828     1.5542726218700409e-01
    z[10,9,1]  R2829     -1.1899171397089958e-02
    z[10,9,1]  R2830     -7.4997544288635254e-02
    z[10,9,1]  R2831     4.1021695733070374e-01
    z[10,9,1]  R2832     -3.9665222167968750e-02
    z[10,9,1]  R2833     4.5404410362243652e-01
    z[10,9,1]  R2834     4.4423744082450867e-01
    z[10,9,1]  R2835     2.4021776020526886e-01
    z[10,9,1]  R2836     4.6866810321807861e-01
    z[10,9,1]  R2837     1.7533724009990692e-01
    z[10,9,1]  R2838     1.4846704900264740e-01
    z[10,9,1]  R2839     -2.9659056663513184e-01
    z[10,9,1]  R2840     -4.6645447611808777e-01
    z[10,9,1]  R2841     -7.6093202829360962e-01
    z[10,9,1]  R2842     -7.7744621038436890e-01
    z[10,9,1]  R2843     -9.4802898168563843e-01
    z[10,9,1]  R2844     -3.0477842688560486e-01
    z[10,9,1]  R2845     -1.8231703341007233e-01
    z[10,9,1]  R2846     0.0208007600158453
    z[10,9,1]  R2847     -0.379312664270401
    z[10,9,1]  R2848     6.0360127687454224e-01
    z[10,9,1]  R2849     -1.1329365521669388e-01
    z[10,9,1]  R2850     -3.0436906218528748e-01
    z[10,9,1]  R2851     2.7989361435174942e-02
    z[10,9,1]  R2852     0.67806077003479
    z[10,9,1]  R2853     1.3304229080677032e-01
    z[10,9,1]  R2854     -5.4952919483184814e-01
    z[10,9,1]  R2855     5.9685826301574707e-01
    z[10,9,1]  R2856     7.9292759299278259e-02
    z[10,9,1]  R2857     -6.0732532292604446e-02
    z[10,9,1]  R2858     -1.7408357560634613e-01
    z[10,9,1]  R2859     2.4137814342975616e-01
    z[10,9,1]  R2860     -3.1413719058036804e-02
    z[10,9,1]  R2861     -2.7527580037713051e-02
    z[10,9,1]  R2862     8.8575951755046844e-02
    z[10,9,1]  R2863     -5.5882513523101807e-01
    z[10,9,1]  R2864     0.430237740278244
    z[10,9,1]  R2865     -6.8249548785388470e-03
    z[10,9,1]  R2866     -2.4141646921634674e-01
    z[10,9,1]  R2867     -8.0737462267279625e-03
    z[10,9,1]  R2868     1.4230413734912872e-01
    z[10,9,1]  R2869     2.2624358534812927e-02
    z[10,9,1]  R2870     2.3977272212505341e-01
    z[10,9,1]  R2871     0.528877854347229
    z[10,9,1]  R2872     -4.0463000535964966e-01
    z[10,9,1]  R2873     2.2134327888488770e-01
    z[10,9,1]  R2874     3.5330925136804581e-02
    z[10,9,1]  R2875     7.0831492543220520e-02
    z[10,9,1]  R2876     -7.0181339979171753e-02
    z[10,9,1]  R2877     -7.0611411333084106e-01
    z[10,9,1]  R2878     -7.0038020610809326e-01
    z[10,9,1]  R2879     -5.3251928091049194e-01
    z[10,9,1]  R2880     -5.2856034040451050e-01
    z[10,9,1]  R2881     -6.2404000759124756e-01
    z[10,9,1]  R2882     -6.9835889339447021e-01
    z[10,9,1]  R2883     -4.2886650562286377e-01
    z[10,9,1]  R2884     -6.2193077802658081e-01
    z[10,9,1]  R2885     -5.5906790494918823e-01
    z[10,9,1]  R2886     -2.4140434339642525e-02
    z[10,9,1]  R2887     -7.4764102697372437e-01
    z[10,9,1]  R2888     -6.5758311748504639e-01
    z[10,9,1]  R2889     -6.6996800899505615e-01
    z[10,9,1]  R2890     -6.4960908889770508e-01
    z[10,9,1]  R2891     -6.0257738828659058e-01
    z[10,9,1]  R2892     -7.6623803377151489e-01
    z[10,9,1]  R2893     -7.8444540500640869e-01
    z[10,9,1]  R2894     -4.3566080927848816e-01
    z[10,9,1]  R2895     -5.9862571954727173e-01
    z[10,9,1]  R2896     -5.6945592164993286e-01
    z[10,9,1]  R2897     -9.3129861354827881e-01
    z[10,9,1]  R2898     -7.7635931968688965e-01
    z[10,9,1]  R2899     -6.7822271585464478e-01
    z[10,9,1]  R2900     -6.6880780458450317e-01
    z[10,9,1]  R2901     -4.9056935310363770e-01
    z[10,9,1]  R2902     1.4509424567222595e-01
    z[10,9,1]  R2903     5.1353760063648224e-02
    z[10,9,1]  R2904     6.5615244209766388e-02
    z[10,9,1]  R2905     3.6510124802589417e-01
    z[10,9,1]  R2906     2.5187534093856812e-01
    z[10,9,1]  R2907     -5.2829945087432861e-01
    z[10,9,1]  R2908     -5.9183764457702637e-01
    z[10,9,1]  R2909     -6.8946105241775513e-01
    z[10,9,1]  R2910     -5.8173561096191406e-01
    z[10,9,1]  R2911     -4.5227476954460144e-01
    z[10,9,1]  R2912     -5.3008455038070679e-01
    z[10,9,1]  R2913     -6.2674248218536377e-01
    z[10,9,1]  R2914     -1.7841532826423645e-01
    z[10,9,1]  R2915     -7.3125049471855164e-02
    z[10,9,1]  R2916     2.7809736132621765e-01
    z[10,9,1]  R2917     -8.5583233833312988e-01
    z[10,9,1]  R2918     -6.5710622072219849e-01
    z[10,9,1]  R2919     -4.3961033225059509e-01
    z[10,9,1]  R2920     -3.8813760876655579e-01
    z[10,9,1]  R2921     -4.3275612592697144e-01
    z[10,9,1]  R2922     -6.7361706495285034e-01
    z[10,9,1]  R2923     -5.6662166118621826e-01
    z[10,9,1]  R2924     -3.2149741053581238e-01
    z[10,9,1]  R2925     -1.5396389365196228e-01
    z[10,9,1]  R2926     -8.5054852068424225e-02
    z[10,9,1]  R2927     -8.5403424501419067e-01
    z[10,9,1]  R2928     -4.9898526072502136e-01
    z[10,9,1]  R2929     -3.9110168814659119e-01
    z[10,9,1]  R2930     -7.5024962425231934e-01
    z[10,9,1]  R2931     -2.7281123399734497e-01
    z[10,9,1]  R2932     4.3152235448360443e-02
    z[10,9,1]  R2933     5.2607440948486328e-01
    z[10,9,1]  R2934     5.0985753536224365e-01
    z[10,9,1]  R2935     5.1093775779008865e-02
    z[10,9,1]  R2936     5.5250930786132812e-01
    z[10,9,2]  R85       1
    z[10,9,2]  R94       -1
    z[10,9,2]  R2817     -1
    z[10,9,2]  R2818     1
    z[10,9,2]  R2827     -2.9010385274887085e-01
    z[10,9,2]  R2828     -2.3738962411880493e-01
    z[10,9,2]  R2829     -2.5479811429977417e-01
    z[10,9,2]  R2830     -5.6889832019805908e-01
    z[10,9,2]  R2831     -2.5653791427612305e-01
    z[10,9,2]  R2832     -5.0786983966827393e-01
    z[10,9,2]  R2833     2.6203829050064087e-01
    z[10,9,2]  R2834     5.5182456970214844e-02
    z[10,9,2]  R2835     -6.7197734117507935e-01
    z[10,9,2]  R2836     6.0794495046138763e-02
    z[10,9,2]  R2837     2.9034504666924477e-02
    z[10,9,2]  R2838     1.1902976036071777e-01
    z[10,9,2]  R2839     1.1844386905431747e-01
    z[10,9,2]  R2840     -1.0425622761249542e-01
    z[10,9,2]  R2841     8.9256383478641510e-02
    z[10,9,2]  R2842     2.5807061791419983e-01
    z[10,9,2]  R2843     -0.00564618781208992
    z[10,9,2]  R2844     -7.6905570924282074e-02
    z[10,9,2]  R2845     1.9678516313433647e-02
    z[10,9,2]  R2846     1.1538688093423843e-01
    z[10,9,2]  R2847     -2.1094707772135735e-02
    z[10,9,2]  R2848     4.1736122965812683e-01
    z[10,9,2]  R2849     7.0153094828128815e-02
    z[10,9,2]  R2850     -3.8802798837423325e-02
    z[10,9,2]  R2851     1.8816716969013214e-01
    z[10,9,2]  R2852     2.3320975899696350e-01
    z[10,9,2]  R2853     -4.6710226684808731e-02
    z[10,9,2]  R2854     7.3537260293960571e-02
    z[10,9,2]  R2855     -3.7699963431805372e-03
    z[10,9,2]  R2856     -8.2393847405910492e-02
    z[10,9,2]  R2857     -7.5839266180992126e-02
    z[10,9,2]  R2858     2.0828737318515778e-01
    z[10,9,2]  R2859     1.2249260395765305e-01
    z[10,9,2]  R2860     -1.1270281672477722e-01
    z[10,9,2]  R2861     -2.6481010019779205e-02
    z[10,9,2]  R2862     -2.3649835586547852e-01
    z[10,9,2]  R2863     -4.7293606400489807e-01
    z[10,9,2]  R2864     -1.7638376355171204e-01
    z[10,9,2]  R2865     -2.5224119424819946e-01
    z[10,9,2]  R2866     2.0095808804035187e-01
    z[10,9,2]  R2867     1.0386286303400993e-03
    z[10,9,2]  R2868     -4.5047495514154434e-02
    z[10,9,2]  R2869     -3.8759005069732666e-01
    z[10,9,2]  R2870     -1.3593223690986633e-01
    z[10,9,2]  R2871     -2.0350408554077148e-01
    z[10,9,2]  R2872     1.3394263386726379e-01
    z[10,9,2]  R2873     3.4943490754812956e-03
    z[10,9,2]  R2874     -1.4786422252655029e-01
    z[10,9,2]  R2875     -2.1904994547367096e-01
    z[10,9,2]  R2876     7.6188242435455322e-01
    z[10,9,2]  R2877     2.6483091711997986e-01
    z[10,9,2]  R2878     1.2022143602371216e-01
    z[10,9,2]  R2879     2.6209217309951782e-01
    z[10,9,2]  R2880     5.0239282846450806e-01
    z[10,9,2]  R2881     7.1645148098468781e-02
    z[10,9,2]  R2882     4.8133295774459839e-01
    z[10,9,2]  R2883     5.5973953008651733e-01
    z[10,9,2]  R2884     4.6483024954795837e-01
    z[10,9,2]  R2885     -2.7340808510780334e-01
    z[10,9,2]  R2886     -3.8282856345176697e-01
    z[10,9,2]  R2887     5.0953525304794312e-01
    z[10,9,2]  R2888     4.2274218797683716e-01
    z[10,9,2]  R2889     4.0736341476440430e-01
    z[10,9,2]  R2890     4.7930145263671875e-01
    z[10,9,2]  R2891     0.506238579750061
    z[10,9,2]  R2892     -0.0528477281332016
    z[10,9,2]  R2893     1.1037375032901764e-01
    z[10,9,2]  R2894     -5.6048955768346786e-02
    z[10,9,2]  R2895     -1.8911965191364288e-01
    z[10,9,2]  R2896     -6.1571896076202393e-01
    z[10,9,2]  R2897     -1.0740020871162415e-01
    z[10,9,2]  R2898     -3.3411350846290588e-01
    z[10,9,2]  R2899     -3.0589619278907776e-01
    z[10,9,2]  R2900     -6.4837050437927246e-01
    z[10,9,2]  R2901     5.5570787191390991e-01
    z[10,9,2]  R2902     1.3312242925167084e-01
    z[10,9,2]  R2903     -1.6032233834266663e-02
    z[10,9,2]  R2904     -2.3102298378944397e-01
    z[10,9,2]  R2905     -1.2256371974945068e-01
    z[10,9,2]  R2906     1.2075113505125046e-01
    z[10,9,2]  R2907     -2.2346045076847076e-01
    z[10,9,2]  R2908     0.60540372133255
    z[10,9,2]  R2909     2.0606490969657898e-01
    z[10,9,2]  R2910     -3.6067304015159607e-01
    z[10,9,2]  R2911     6.7916673421859741e-01
    z[10,9,2]  R2912     1.0233601182699203e-01
    z[10,9,2]  R2913     -4.0065848827362061e-01
    z[10,9,2]  R2914     5.6349843740463257e-01
    z[10,9,2]  R2915     4.7895425558090210e-01
    z[10,9,2]  R2916     -2.0525640249252319e-01
    z[10,9,2]  R2917     1.1915708333253860e-01
    z[10,9,2]  R2918     -2.4162931367754936e-02
    z[10,9,2]  R2919     6.9115614891052246e-01
    z[10,9,2]  R2920     2.3771961033344269e-01
    z[10,9,2]  R2921     5.9727275371551514e-01
    z[10,9,2]  R2922     3.7660089135169983e-01
    z[10,9,2]  R2923     -8.1534683704376221e-02
    z[10,9,2]  R2924     1.6884498298168182e-01
    z[10,9,2]  R2925     0.0457034595310688
    z[10,9,2]  R2926     -6.0023766756057739e-01
    z[10,9,2]  R2927     2.0172378420829773e-01
    z[10,9,2]  R2928     7.1617412567138672e-01
    z[10,9,2]  R2929     4.1023689508438110e-01
    z[10,9,2]  R2930     2.5607201457023621e-01
    z[10,9,2]  R2931     5.2217740565538406e-02
    z[10,9,2]  R2932     8.9033029973506927e-02
    z[10,9,2]  R2933     -6.4803071320056915e-02
    z[10,9,2]  R2934     8.8083133101463318e-02
    z[10,9,2]  R2935     -2.4576622247695923e-01
    z[10,9,2]  R2936     6.7231643199920654e-01
    z[10,9,3]  R86       1
    z[10,9,3]  R95       -1
    z[10,9,3]  R2819     -1
    z[10,9,3]  R2820     1
    z[10,9,3]  R2827     0.681239128112793
    z[10,9,3]  R2828     0.60472571849823
    z[10,9,3]  R2829     6.0739618539810181e-01
    z[10,9,3]  R2830     5.0476962327957153e-01
    z[10,9,3]  R2831     7.8265631198883057e-01
    z[10,9,3]  R2832     7.2275739908218384e-01
    z[10,9,3]  R2833     2.7796402573585510e-01
    z[10,9,3]  R2834     3.9726930856704712e-01
    z[10,9,3]  R2835     1.5290898084640503e-01
    z[10,9,3]  R2836     4.6916228532791138e-01
    z[10,9,3]  R2837     -5.4265791177749634e-01
    z[10,9,3]  R2838     -2.4831391870975494e-01
    z[10,9,3]  R2839     -5.9818738698959351e-01
    z[10,9,3]  R2840     -3.9339289069175720e-01
    z[10,9,3]  R2841     -0.0786762535572052
    z[10,9,3]  R2842     3.8056049495935440e-02
    z[10,9,3]  R2843     -2.0746810361742973e-02
    z[10,9,3]  R2844     -8.0624771118164062e-01
    z[10,9,3]  R2845     0.659960150718689
    z[10,9,3]  R2846     -8.2981234788894653e-01
    z[10,9,3]  R2847     -7.2701941244304180e-03
    z[10,9,3]  R2848     -3.7577623128890991e-01
    z[10,9,3]  R2849     -4.4316515326499939e-02
    z[10,9,3]  R2850     1.3924965262413025e-01
    z[10,9,3]  R2851     -2.1064251661300659e-01
    z[10,9,3]  R2852     3.6444085836410522e-01
    z[10,9,3]  R2853     2.8647786378860474e-01
    z[10,9,3]  R2854     -6.1262732744216919e-01
    z[10,9,3]  R2855     -1.9766797125339508e-01
    z[10,9,3]  R2856     -5.6900459527969360e-01
    z[10,9,3]  R2857     2.1127900481224060e-01
    z[10,9,3]  R2858     -9.1145741939544678e-01
    z[10,9,3]  R2859     -8.0859714746475220e-01
    z[10,9,3]  R2860     -7.2537130117416382e-01
    z[10,9,3]  R2861     -5.8372038602828979e-01
    z[10,9,3]  R2862     -4.6204555034637451e-01
    z[10,9,3]  R2863     2.8942093253135681e-01
    z[10,9,3]  R2864     5.1352846622467041e-01
    z[10,9,3]  R2865     -0.468342125415802
    z[10,9,3]  R2866     -5.5705946683883667e-01
    z[10,9,3]  R2867     0.630595862865448
    z[10,9,3]  R2868     3.2040849328041077e-01
    z[10,9,3]  R2869     4.2054033279418945e-01
    z[10,9,3]  R2870     2.8039768338203430e-01
    z[10,9,3]  R2871     6.8141895532608032e-01
    z[10,9,3]  R2872     0.524479329586029
    z[10,9,3]  R2873     5.2910721302032471e-01
    z[10,9,3]  R2874     6.7841708660125732e-01
    z[10,9,3]  R2875     2.3260892927646637e-01
    z[10,9,3]  R2876     3.1640842556953430e-01
    z[10,9,3]  R2877     -0.0922887921333313
    z[10,9,3]  R2878     -8.1799037754535675e-02
    z[10,9,3]  R2879     -1.5462781488895416e-01
    z[10,9,3]  R2880     -1.4706438779830933e-01
    z[10,9,3]  R2881     -2.7036878466606140e-01
    z[10,9,3]  R2882     -5.1282446831464767e-02
    z[10,9,3]  R2883     -1.6719731688499451e-01
    z[10,9,3]  R2884     4.5264132320880890e-02
    z[10,9,3]  R2885     -3.4057107567787170e-01
    z[10,9,3]  R2886     -4.3049478530883789e-01
    z[10,9,3]  R2887     -3.1722940504550934e-02
    z[10,9,3]  R2888     2.6191183924674988e-01
    z[10,9,3]  R2889     2.0088051259517670e-01
    z[10,9,3]  R2890     -1.5801148116588593e-01
    z[10,9,3]  R2891     3.7539863586425781e-01
    z[10,9,3]  R2892     -2.1942764520645142e-01
    z[10,9,3]  R2893     -4.3343058228492737e-01
    z[10,9,3]  R2894     6.8287503719329834e-01
    z[10,9,3]  R2895     -7.0812559127807617e-01
    z[10,9,3]  R2896     -3.3075016736984253e-01
    z[10,9,3]  R2897     -1.3071247935295105e-01
    z[10,9,3]  R2898     2.7870687842369080e-01
    z[10,9,3]  R2899     5.4167336225509644e-01
    z[10,9,3]  R2900     1.5987187623977661e-01
    z[10,9,3]  R2901     -1.5942801535129547e-01
    z[10,9,3]  R2902     2.6197269558906555e-01
    z[10,9,3]  R2903     -6.6071957349777222e-01
    z[10,9,3]  R2904     -5.8773660659790039e-01
    z[10,9,3]  R2905     -5.7532048225402832e-01
    z[10,9,3]  R2906     -5.9662473201751709e-01
    z[10,9,3]  R2907     -2.4122324585914612e-01
    z[10,9,3]  R2908     0.0994042381644249
    z[10,9,3]  R2909     -2.5547316670417786e-01
    z[10,9,3]  R2910     6.9014841318130493e-01
    z[10,9,3]  R2911     1.4085161685943604e-01
    z[10,9,3]  R2912     2.4849760532379150e-01
    z[10,9,3]  R2913     2.2239649295806885e-01
    z[10,9,3]  R2914     -2.5498563051223755e-01
    z[10,9,3]  R2915     -2.6442768052220345e-02
    z[10,9,3]  R2916     -1.3136214017868042e-01
    z[10,9,3]  R2917     8.0912478268146515e-02
    z[10,9,3]  R2918     1.8270447850227356e-01
    z[10,9,3]  R2919     5.7935353368520737e-02
    z[10,9,3]  R2920     0.816985547542572
    z[10,9,3]  R2921     -1.5790291130542755e-01
    z[10,9,3]  R2922     -2.7754920721054077e-01
    z[10,9,3]  R2923     -2.4088135361671448e-01
    z[10,9,3]  R2924     5.4302625358104706e-02
    z[10,9,3]  R2925     -1.5420977771282196e-01
    z[10,9,3]  R2926     -1.8729925155639648e-01
    z[10,9,3]  R2927     -1.7744068801403046e-01
    z[10,9,3]  R2928     9.2129111289978027e-02
    z[10,9,3]  R2929     1.0381588339805603e-01
    z[10,9,3]  R2930     -4.5471572875976562e-01
    z[10,9,3]  R2931     -5.7463750243186951e-02
    z[10,9,3]  R2932     -7.5366806983947754e-01
    z[10,9,3]  R2933     -1.6991352662444115e-02
    z[10,9,3]  R2934     7.7977791428565979e-02
    z[10,9,3]  R2935     -0.704690158367157
    z[10,9,3]  R2936     -2.0809842646121979e-01
    z[10,9,4]  R87       1
    z[10,9,4]  R96       -1
    z[10,9,4]  R2821     -1
    z[10,9,4]  R2822     1
    z[10,9,4]  R2827     -0.373605340719223
    z[10,9,4]  R2828     -4.2356446385383606e-01
    z[10,9,4]  R2829     -0.398029625415802
    z[10,9,4]  R2830     -4.5387169718742371e-01
    z[10,9,4]  R2831     -2.6355615258216858e-01
    z[10,9,4]  R2832     -2.7197670936584473e-01
    z[10,9,4]  R2833     -2.3760432004928589e-01
    z[10,9,4]  R2834     2.5522655248641968e-01
    z[10,9,4]  R2835     -5.6038123369216919e-01
    z[10,9,4]  R2836     -3.9787578582763672e-01
    z[10,9,4]  R2837     2.4450273811817169e-01
    z[10,9,4]  R2838     0.608993411064148
    z[10,9,4]  R2839     5.3822201490402222e-01
    z[10,9,4]  R2840     7.5127941370010376e-01
    z[10,9,4]  R2841     9.2514185234904289e-03
    z[10,9,4]  R2842     -2.5473731756210327e-01
    z[10,9,4]  R2843     -1.2457814998924732e-02
    z[10,9,4]  R2844     1.0844941437244415e-01
    z[10,9,4]  R2845     -2.1772688627243042e-01
    z[10,9,4]  R2846     1.3864155113697052e-01
    z[10,9,4]  R2847     -7.7451360225677490e-01
    z[10,9,4]  R2848     1.9043922424316406e-02
    z[10,9,4]  R2849     -9.7413694858551025e-01
    z[10,9,4]  R2850     -8.8898915052413940e-01
    z[10,9,4]  R2851     -6.9305545091629028e-01
    z[10,9,4]  R2852     -3.1474456191062927e-01
    z[10,9,4]  R2853     -6.7333787679672241e-01
    z[10,9,4]  R2854     2.5464621186256409e-01
    z[10,9,4]  R2855     -2.3097757995128632e-01
    z[10,9,4]  R2856     6.5534484386444092e-01
    z[10,9,4]  R2857     -8.8822716474533081e-01
    z[10,9,4]  R2858     2.6076236367225647e-01
    z[10,9,4]  R2859     5.9483081102371216e-02
    z[10,9,4]  R2860     6.3341581821441650e-01
    z[10,9,4]  R2861     3.4353023767471313e-01
    z[10,9,4]  R2862     5.9049171209335327e-01
    z[10,9,4]  R2863     3.7947988510131836e-01
    z[10,9,4]  R2864     4.8621911555528641e-02
    z[10,9,4]  R2865     7.9095101356506348e-01
    z[10,9,4]  R2866     1.3062059879302979e-01
    z[10,9,4]  R2867     -2.3744067549705505e-01
    z[10,9,4]  R2868     0.0827716812491417
    z[10,9,4]  R2869     -5.7877349853515625e-01
    z[10,9,4]  R2870     -4.7462841868400574e-01
    z[10,9,4]  R2871     -3.8081204891204834e-01
    z[10,9,4]  R2872     -0.628445029258728
    z[10,9,4]  R2873     -4.8358172178268433e-01
    z[10,9,4]  R2874     -5.2478021383285522e-01
    z[10,9,4]  R2875     3.8961541652679443e-01
    z[10,9,4]  R2876     5.0594240427017212e-01
    z[10,9,4]  R2877     2.4471342563629150e-01
    z[10,9,4]  R2878     -2.8229910880327225e-02
    z[10,9,4]  R2879     5.2011376619338989e-01
    z[10,9,4]  R2880     -9.4679847359657288e-02
    z[10,9,4]  R2881     3.9547699689865112e-01
    z[10,9,4]  R2882     9.6088767051696777e-02
    z[10,9,4]  R2883     4.8031383752822876e-01
    z[10,9,4]  R2884     -1.4868909120559692e-01
    z[10,9,4]  R2885     3.5853621363639832e-01
    z[10,9,4]  R2886     1.0054794698953629e-01
    z[10,9,4]  R2887     -2.9966783523559570e-01
    z[10,9,4]  R2888     0.308178573846817
    z[10,9,4]  R2889     0.501348614692688
    z[10,9,4]  R2890     4.1890364140272141e-02
    z[10,9,4]  R2891     1.7075219750404358e-01
    z[10,9,4]  R2892     3.2352928072214127e-02
    z[10,9,4]  R2893     -2.3997258394956589e-02
    z[10,9,4]  R2894     3.6097481846809387e-01
    z[10,9,4]  R2895     -1.7721448838710785e-01
    z[10,9,4]  R2896     4.0443789958953857e-01
    z[10,9,4]  R2897     1.4199002087116241e-01
    z[10,9,4]  R2898     -8.5988417267799377e-02
    z[10,9,4]  R2899     -8.8775508105754852e-02
    z[10,9,4]  R2900     3.4498311579227448e-02
    z[10,9,4]  R2901     5.0465297698974609e-01
    z[10,9,4]  R2902     3.7336525321006775e-01
    z[10,9,4]  R2903     3.6075541377067566e-01
    z[10,9,4]  R2904     4.2704832553863525e-01
    z[10,9,4]  R2905     4.9841120839118958e-01
    z[10,9,4]  R2906     6.9261372089385986e-01
    z[10,9,4]  R2907     -0.00996506679803133
    z[10,9,4]  R2908     3.2574638724327087e-01
    z[10,9,4]  R2909     0.284542053937912
    z[10,9,4]  R2910     1.0995614528656006e-01
    z[10,9,4]  R2911     4.5094323158264160e-01
    z[10,9,4]  R2912     -2.1217282116413116e-01
    z[10,9,4]  R2913     0.539861261844635
    z[10,9,4]  R2914     6.7160254716873169e-01
    z[10,9,4]  R2915     8.1771403551101685e-01
    z[10,9,4]  R2916     0.30640709400177
    z[10,9,4]  R2917     -3.5012137889862061e-01
    z[10,9,4]  R2918     -5.1747161149978638e-01
    z[10,9,4]  R2919     2.7940675616264343e-01
    z[10,9,4]  R2920     2.8810921311378479e-01
    z[10,9,4]  R2921     6.4422529935836792e-01
    z[10,9,4]  R2922     2.4196559190750122e-01
    z[10,9,4]  R2923     7.9599432647228241e-02
    z[10,9,4]  R2924     1.9483956694602966e-01
    z[10,9,4]  R2925     -1.6300510615110397e-03
    z[10,9,4]  R2926     -1.1140790581703186e-01
    z[10,9,4]  R2927     1.9025810062885284e-01
    z[10,9,4]  R2928     2.1849417686462402e-01
    z[10,9,4]  R2929     6.2847083806991577e-01
    z[10,9,4]  R2930     2.0253662765026093e-01
    z[10,9,4]  R2931     4.2726555466651917e-01
    z[10,9,4]  R2932     4.5717346668243408e-01
    z[10,9,4]  R2933     -0.00543689401820302
    z[10,9,4]  R2934     1.8286738544702530e-02
    z[10,9,4]  R2935     2.8732625767588615e-02
    z[10,9,4]  R2936     -3.3437472581863403e-01
    z[10,9,5]  R88       1
    z[10,9,5]  R97       -1
    z[10,9,5]  R2823     -1
    z[10,9,5]  R2824     1
    z[10,9,5]  R2827     2.1554559469223022e-01
    z[10,9,5]  R2828     0.526763379573822
    z[10,9,5]  R2829     2.4247248470783234e-01
    z[10,9,5]  R2830     4.0691789984703064e-01
    z[10,9,5]  R2831     8.9430719614028931e-02
    z[10,9,5]  R2832     2.4368791282176971e-01
    z[10,9,5]  R2833     6.6027349233627319e-01
    z[10,9,5]  R2834     6.5822386741638184e-01
    z[10,9,5]  R2835     3.9039081335067749e-01
    z[10,9,5]  R2836     -5.4581277072429657e-03
    z[10,9,5]  R2837     -1.6746070981025696e-01
    z[10,9,5]  R2838     -3.0789282917976379e-01
    z[10,9,5]  R2839     6.6035546362400055e-02
    z[10,9,5]  R2840     -7.0266634225845337e-02
    z[10,9,5]  R2841     6.1950433254241943e-01
    z[10,9,5]  R2842     4.0019720792770386e-01
    z[10,9,5]  R2843     2.5226727128028870e-01
    z[10,9,5]  R2844     -2.4337185919284821e-01
    z[10,9,5]  R2845     -2.9784369468688965e-01
    z[10,9,5]  R2846     -3.6523076891899109e-01
    z[10,9,5]  R2847     -4.7111743688583374e-01
    z[10,9,5]  R2848     -2.3197950422763824e-01
    z[10,9,5]  R2849     9.6717111766338348e-02
    z[10,9,5]  R2850     -7.5587600469589233e-02
    z[10,9,5]  R2851     3.7458430975675583e-02
    z[10,9,5]  R2852     -3.5075005888938904e-01
    z[10,9,5]  R2853     -5.9254580736160278e-01
    z[10,9,5]  R2854     -1.3819037377834320e-01
    z[10,9,5]  R2855     -1.7041382193565369e-01
    z[10,9,5]  R2856     -0.178700253367424
    z[10,9,5]  R2857     -3.0035126209259033e-01
    z[10,9,5]  R2858     0.00954553671181202
    z[10,9,5]  R2859     -0.50865638256073
    z[10,9,5]  R2860     -1.3811635971069336e-01
    z[10,9,5]  R2861     -2.9512956738471985e-01
    z[10,9,5]  R2862     -5.0582069158554077e-01
    z[10,9,5]  R2863     2.9561811685562134e-01
    z[10,9,5]  R2864     -2.2971833124756813e-02
    z[10,9,5]  R2865     -2.9978886246681213e-01
    z[10,9,5]  R2866     -0.70634526014328
    z[10,9,5]  R2867     6.0959124565124512e-01
    z[10,9,5]  R2868     6.8604147434234619e-01
    z[10,9,5]  R2869     5.3980922698974609e-01
    z[10,9,5]  R2870     6.4250773191452026e-01
    z[10,9,5]  R2871     1.0501185804605484e-01
    z[10,9,5]  R2872     -0.0551178939640522
    z[10,9,5]  R2873     -4.7281570732593536e-02
    z[10,9,5]  R2874     -1.8524868786334991e-01
    z[10,9,5]  R2875     4.8076584935188293e-01
    z[10,9,5]  R2876     1.7615149915218353e-01
    z[10,9,5]  R2877     -3.2450765371322632e-02
    z[10,9,5]  R2878     -2.6499629020690918e-01
    z[10,9,5]  R2879     -2.2803871333599091e-01
    z[10,9,5]  R2880     -4.5225575566291809e-01
    z[10,9,5]  R2881     -2.0371034741401672e-01
    z[10,9,5]  R2882     1.9490176811814308e-02
    z[10,9,5]  R2883     4.2251139879226685e-01
    z[10,9,5]  R2884     -7.7622950077056885e-02
    z[10,9,5]  R2885     -5.9538954496383667e-01
    z[10,9,5]  R2886     -3.1654247641563416e-01
    z[10,9,5]  R2887     -2.1380858495831490e-02
    z[10,9,5]  R2888     3.6986616253852844e-01
    z[10,9,5]  R2889     -2.9593309760093689e-01
    z[10,9,5]  R2890     1.3574530184268951e-01
    z[10,9,5]  R2891     -1.8741288781166077e-01
    z[10,9,5]  R2892     1.8684232234954834e-01
    z[10,9,5]  R2893     -3.0348542332649231e-01
    z[10,9,5]  R2894     -2.4751265347003937e-01
    z[10,9,5]  R2895     -0.0328182727098465
    z[10,9,5]  R2896     -8.9843444526195526e-02
    z[10,9,5]  R2897     -1.9645778834819794e-01
    z[10,9,5]  R2898     -1.1482248082756996e-03
    z[10,9,5]  R2899     3.2897189259529114e-02
    z[10,9,5]  R2900     -1.6976065933704376e-01
    z[10,9,5]  R2901     3.4776532649993896e-01
    z[10,9,5]  R2902     -4.6710196137428284e-01
    z[10,9,5]  R2903     -5.9684950113296509e-01
    z[10,9,5]  R2904     -0.605772852897644
    z[10,9,5]  R2905     -4.8108381032943726e-01
    z[10,9,5]  R2906     -1.9799204170703888e-01
    z[10,9,5]  R2907     6.4184987545013428e-01
    z[10,9,5]  R2908     3.9485642313957214e-01
    z[10,9,5]  R2909     3.1156671047210693e-01
    z[10,9,5]  R2910     -1.9592662155628204e-01
    z[10,9,5]  R2911     -2.3011548817157745e-01
    z[10,9,5]  R2912     1.0768519714474678e-02
    z[10,9,5]  R2913     -9.4771005213260651e-02
    z[10,9,5]  R2914     1.3257928192615509e-01
    z[10,9,5]  R2915     1.5410327911376953e-01
    z[10,9,5]  R2916     -3.1746536493301392e-01
    z[10,9,5]  R2917     -2.8857348486781120e-02
    z[10,9,5]  R2918     3.4091625362634659e-02
    z[10,9,5]  R2919     4.4156581163406372e-01
    z[10,9,5]  R2920     -1.4573523402214050e-01
    z[10,9,5]  R2921     -5.5646669119596481e-02
    z[10,9,5]  R2922     3.8169354200363159e-02
    z[10,9,5]  R2923     -3.1596621870994568e-01
    z[10,9,5]  R2924     -4.7881278395652771e-01
    z[10,9,5]  R2925     -5.1543056964874268e-01
    z[10,9,5]  R2926     -2.6525703072547913e-01
    z[10,9,5]  R2927     1.2550760805606842e-01
    z[10,9,5]  R2928     3.5498419404029846e-01
    z[10,9,5]  R2929     8.3474688231945038e-02
    z[10,9,5]  R2930     3.2502165436744690e-01
    z[10,9,5]  R2931     -3.1508678197860718e-01
    z[10,9,5]  R2932     -3.2217675447463989e-01
    z[10,9,5]  R2933     2.5536064058542252e-02
    z[10,9,5]  R2934     -4.1888780891895294e-02
    z[10,9,5]  R2935     -5.7469010353088379e-01
    z[10,9,5]  R2936     -1.2234982103109360e-01
    z[10,9,6]  R89       1
    z[10,9,6]  R98       -1
    z[10,9,6]  R2825     -1
    z[10,9,6]  R2826     1
    z[10,9,6]  R2827     3.1115907430648804e-01
    z[10,9,6]  R2828     2.2180373966693878e-01
    z[10,9,6]  R2829     -2.1379025280475616e-01
    z[10,9,6]  R2830     -2.0424191653728485e-01
    z[10,9,6]  R2831     2.5111040472984314e-01
    z[10,9,6]  R2832     -2.2403696179389954e-01
    z[10,9,6]  R2833     1.4899879693984985e-01
    z[10,9,6]  R2834     2.7462151646614075e-01
    z[10,9,6]  R2835     2.3706594482064247e-02
    z[10,9,6]  R2836     4.6787819266319275e-01
    z[10,9,6]  R2837     -6.4719456434249878e-01
    z[10,9,6]  R2838     -6.5354377031326294e-01
    z[10,9,6]  R2839     -1.4812734723091125e-01
    z[10,9,6]  R2840     0.135025292634964
    z[10,9,6]  R2841     1.5096846222877502e-01
    z[10,9,6]  R2842     2.2642095386981964e-01
    z[10,9,6]  R2843     -4.4093031436204910e-02
    z[10,9,6]  R2844     -2.5611397624015808e-01
    z[10,9,6]  R2845     -3.5083033144474030e-02
    z[10,9,6]  R2846     1.0351660847663879e-01
    z[10,9,6]  R2847     0.156805619597435
    z[10,9,6]  R2848     5.0296908617019653e-01
    z[10,9,6]  R2849     -1.0307624936103821e-01
    z[10,9,6]  R2850     2.2044481709599495e-02
    z[10,9,6]  R2851     5.8471059799194336e-01
    z[10,9,6]  R2852     3.5739752650260925e-01
    z[10,9,6]  R2853     -3.0509757995605469e-01
    z[10,9,6]  R2854     -1.1545576900243759e-01
    z[10,9,6]  R2855     -0.00886712409555912
    z[10,9,6]  R2856     2.6179659366607666e-01
    z[10,9,6]  R2857     1.6377250850200653e-01
    z[10,9,6]  R2858     1.6131460666656494e-01
    z[10,9,6]  R2859     -0.0995606854557991
    z[10,9,6]  R2860     -1.2396887689828873e-01
    z[10,9,6]  R2861     -3.1050941348075867e-01
    z[10,9,6]  R2862     -2.5741836428642273e-01
    z[10,9,6]  R2863     -2.6364496350288391e-01
    z[10,9,6]  R2864     -0.352649450302124
    z[10,9,6]  R2865     -2.1015355363488197e-02
    z[10,9,6]  R2866     2.6889881491661072e-01
    z[10,9,6]  R2867     -4.5436579734086990e-02
    z[10,9,6]  R2868     1.3276310265064240e-01
    z[10,9,6]  R2869     -1.7145794630050659e-01
    z[10,9,6]  R2870     4.4282466173171997e-01
    z[10,9,6]  R2871     1.1576970666646957e-01
    z[10,9,6]  R2872     1.3626264035701752e-01
    z[10,9,6]  R2873     4.5209395885467529e-01
    z[10,9,6]  R2874     -2.9960680007934570e-01
    z[10,9,6]  R2875     -6.1643189191818237e-01
    z[10,9,6]  R2876     1.3172204792499542e-01
    z[10,9,6]  R2877     5.9821295738220215e-01
    z[10,9,6]  R2878     -6.0290664434432983e-01
    z[10,9,6]  R2879     -5.3319036960601807e-01
    z[10,9,6]  R2880     9.2168338596820831e-02
    z[10,9,6]  R2881     -3.1946465373039246e-01
    z[10,9,6]  R2882     -3.0811068415641785e-01
    z[10,9,6]  R2883     -6.1776839196681976e-02
    z[10,9,6]  R2884     -1.9178394973278046e-01
    z[10,9,6]  R2885     -0.0774015337228775
    z[10,9,6]  R2886     1.2274991720914841e-01
    z[10,9,6]  R2887     1.9521857798099518e-01
    z[10,9,6]  R2888     -2.3522333800792694e-01
    z[10,9,6]  R2889     -4.9021661281585693e-02
    z[10,9,6]  R2890     -1.4449508488178253e-01
    z[10,9,6]  R2891     -3.9919081330299377e-01
    z[10,9,6]  R2892     -4.1840910911560059e-01
    z[10,9,6]  R2893     -0.0537693053483963
    z[10,9,6]  R2894     2.9884251952171326e-01
    z[10,9,6]  R2895     -1.2494862079620361e-01
    z[10,9,6]  R2896     -9.6965618431568146e-02
    z[10,9,6]  R2897     -1.0616531595587730e-02
    z[10,9,6]  R2898     -1.4885148033499718e-02
    z[10,9,6]  R2899     -2.7475917339324951e-01
    z[10,9,6]  R2900     2.2646412253379822e-01
    z[10,9,6]  R2901     8.6878068745136261e-02
    z[10,9,6]  R2902     2.5030277669429779e-02
    z[10,9,6]  R2903     2.5785481929779053e-01
    z[10,9,6]  R2904     -2.1536734700202942e-01
    z[10,9,6]  R2905     4.1040789335966110e-02
    z[10,9,6]  R2906     0.205540731549263
    z[10,9,6]  R2907     -0.342171311378479
    z[10,9,6]  R2908     -1.0002993047237396e-01
    z[10,9,6]  R2909     3.2614961266517639e-01
    z[10,9,6]  R2910     7.5960271060466766e-03
    z[10,9,6]  R2911     -6.0785752721130848e-03
    z[10,9,6]  R2912     -3.8614797592163086e-01
    z[10,9,6]  R2913     -1.1958386749029160e-01
    z[10,9,6]  R2914     -1.9437422975897789e-02
    z[10,9,6]  R2915     -6.9461479783058167e-02
    z[10,9,6]  R2916     1.9744911789894104e-01
    z[10,9,6]  R2917     -2.9330024123191833e-01
    z[10,9,6]  R2918     -3.4934807568788528e-02
    z[10,9,6]  R2919     2.2088389098644257e-01
    z[10,9,6]  R2920     1.3635644316673279e-01
    z[10,9,6]  R2921     -1.0868085175752640e-01
    z[10,9,6]  R2922     1.6315829753875732e-01
    z[10,9,6]  R2923     4.0994000434875488e-01
    z[10,9,6]  R2924     2.5183673948049545e-02
    z[10,9,6]  R2925     4.0462979674339294e-01
    z[10,9,6]  R2926     -3.1075802445411682e-01
    z[10,9,6]  R2927     3.1362724304199219e-01
    z[10,9,6]  R2928     2.3466531932353973e-01
    z[10,9,6]  R2929     -6.3345089554786682e-02
    z[10,9,6]  R2930     -3.3809497952461243e-02
    z[10,9,6]  R2931     -2.1018752455711365e-01
    z[10,9,6]  R2932     2.7088707685470581e-01
    z[10,9,6]  R2933     -2.2203331813216209e-02
    z[10,9,6]  R2934     4.9485091120004654e-02
    z[10,9,6]  R2935     9.9782370030879974e-02
    z[10,9,6]  R2936     -2.5111085176467896e-01
    length[0]  OBJ       1
    length[1]  OBJ       1
    length[2]  OBJ       1
    length[3]  OBJ       1
    length[4]  OBJ       1
    length[5]  OBJ       1
    length[6]  OBJ       1
    length[7]  OBJ       1
    length[8]  OBJ       1
    length[9]  OBJ       1
    length[10]  OBJ       1
    delta[0,0]  R2        1
    delta[0,1]  R3        1
    delta[0,2]  R4        1
    delta[0,3]  R5        1
    delta[0,4]  R6        1
    delta[0,5]  R7        1
    delta[0,6]  R8        1
    delta[1,0]  R11       1
    delta[1,1]  R12       1
    delta[1,2]  R13       1
    delta[1,3]  R14       1
    delta[1,4]  R15       1
    delta[1,5]  R16       1
    delta[1,6]  R17       1
    delta[2,0]  R20       1
    delta[2,1]  R21       1
    delta[2,2]  R22       1
    delta[2,3]  R23       1
    delta[2,4]  R24       1
    delta[2,5]  R25       1
    delta[2,6]  R26       1
    delta[3,0]  R29       1
    delta[3,1]  R30       1
    delta[3,2]  R31       1
    delta[3,3]  R32       1
    delta[3,4]  R33       1
    delta[3,5]  R34       1
    delta[3,6]  R35       1
    delta[4,0]  R38       1
    delta[4,1]  R39       1
    delta[4,2]  R40       1
    delta[4,3]  R41       1
    delta[4,4]  R42       1
    delta[4,5]  R43       1
    delta[4,6]  R44       1
    delta[5,0]  R47       1
    delta[5,1]  R48       1
    delta[5,2]  R49       1
    delta[5,3]  R50       1
    delta[5,4]  R51       1
    delta[5,5]  R52       1
    delta[5,6]  R53       1
    delta[6,0]  R56       1
    delta[6,1]  R57       1
    delta[6,2]  R58       1
    delta[6,3]  R59       1
    delta[6,4]  R60       1
    delta[6,5]  R61       1
    delta[6,6]  R62       1
    delta[7,0]  R65       1
    delta[7,1]  R66       1
    delta[7,2]  R67       1
    delta[7,3]  R68       1
    delta[7,4]  R69       1
    delta[7,5]  R70       1
    delta[7,6]  R71       1
    delta[8,0]  R74       1
    delta[8,1]  R75       1
    delta[8,2]  R76       1
    delta[8,3]  R77       1
    delta[8,4]  R78       1
    delta[8,5]  R79       1
    delta[8,6]  R80       1
    delta[9,0]  R83       1
    delta[9,1]  R84       1
    delta[9,2]  R85       1
    delta[9,3]  R86       1
    delta[9,4]  R87       1
    delta[9,5]  R88       1
    delta[9,6]  R89       1
    delta[10,0]  R92       1
    delta[10,1]  R93       1
    delta[10,2]  R94       1
    delta[10,3]  R95       1
    delta[10,4]  R96       1
    delta[10,5]  R97       1
    delta[10,6]  R98       1
RHS
    RHS1      R1        1
    RHS1      R10       1
    RHS1      R19       1
    RHS1      R28       1
    RHS1      R37       1
    RHS1      R46       1
    RHS1      R55       1
    RHS1      R64       1
    RHS1      R73       1
    RHS1      R82       1
    RHS1      R91       1
    RHS1      R99       1
    RHS1      R100      -1
BOUNDS
 BV BND1      phi[0,1]
 BV BND1      phi[1,0]
 BV BND1      phi[0,6]
 BV BND1      phi[6,0]
 BV BND1      phi[11,0]
 BV BND1      phi[1,2]
 BV BND1      phi[2,1]
 BV BND1      phi[1,6]
 BV BND1      phi[6,1]
 BV BND1      phi[2,3]
 BV BND1      phi[3,2]
 BV BND1      phi[3,4]
 BV BND1      phi[4,3]
 BV BND1      phi[3,10]
 BV BND1      phi[10,3]
 BV BND1      phi[4,5]
 BV BND1      phi[5,4]
 BV BND1      phi[4,10]
 BV BND1      phi[10,4]
 BV BND1      phi[5,12]
 BV BND1      phi[6,7]
 BV BND1      phi[7,6]
 BV BND1      phi[7,8]
 BV BND1      phi[8,7]
 BV BND1      phi[8,9]
 BV BND1      phi[9,8]
 BV BND1      phi[9,10]
 BV BND1      phi[10,9]
 FR BND1      z[0,1,0]
 FR BND1      z[0,1,1]
 FR BND1      z[0,1,2]
 FR BND1      z[0,1,3]
 FR BND1      z[0,1,4]
 FR BND1      z[0,1,5]
 FR BND1      z[0,1,6]
 FR BND1      z[1,0,0]
 FR BND1      z[1,0,1]
 FR BND1      z[1,0,2]
 FR BND1      z[1,0,3]
 FR BND1      z[1,0,4]
 FR BND1      z[1,0,5]
 FR BND1      z[1,0,6]
 FR BND1      z[0,6,0]
 FR BND1      z[0,6,1]
 FR BND1      z[0,6,2]
 FR BND1      z[0,6,3]
 FR BND1      z[0,6,4]
 FR BND1      z[0,6,5]
 FR BND1      z[0,6,6]
 FR BND1      z[6,0,0]
 FR BND1      z[6,0,1]
 FR BND1      z[6,0,2]
 FR BND1      z[6,0,3]
 FR BND1      z[6,0,4]
 FR BND1      z[6,0,5]
 FR BND1      z[6,0,6]
 FR BND1      z[1,2,0]
 FR BND1      z[1,2,1]
 FR BND1      z[1,2,2]
 FR BND1      z[1,2,3]
 FR BND1      z[1,2,4]
 FR BND1      z[1,2,5]
 FR BND1      z[1,2,6]
 FR BND1      z[2,1,0]
 FR BND1      z[2,1,1]
 FR BND1      z[2,1,2]
 FR BND1      z[2,1,3]
 FR BND1      z[2,1,4]
 FR BND1      z[2,1,5]
 FR BND1      z[2,1,6]
 FR BND1      z[1,6,0]
 FR BND1      z[1,6,1]
 FR BND1      z[1,6,2]
 FR BND1      z[1,6,3]
 FR BND1      z[1,6,4]
 FR BND1      z[1,6,5]
 FR BND1      z[1,6,6]
 FR BND1      z[6,1,0]
 FR BND1      z[6,1,1]
 FR BND1      z[6,1,2]
 FR BND1      z[6,1,3]
 FR BND1      z[6,1,4]
 FR BND1      z[6,1,5]
 FR BND1      z[6,1,6]
 FR BND1      z[2,3,0]
 FR BND1      z[2,3,1]
 FR BND1      z[2,3,2]
 FR BND1      z[2,3,3]
 FR BND1      z[2,3,4]
 FR BND1      z[2,3,5]
 FR BND1      z[2,3,6]
 FR BND1      z[3,2,0]
 FR BND1      z[3,2,1]
 FR BND1      z[3,2,2]
 FR BND1      z[3,2,3]
 FR BND1      z[3,2,4]
 FR BND1      z[3,2,5]
 FR BND1      z[3,2,6]
 FR BND1      z[3,4,0]
 FR BND1      z[3,4,1]
 FR BND1      z[3,4,2]
 FR BND1      z[3,4,3]
 FR BND1      z[3,4,4]
 FR BND1      z[3,4,5]
 FR BND1      z[3,4,6]
 FR BND1      z[4,3,0]
 FR BND1      z[4,3,1]
 FR BND1      z[4,3,2]
 FR BND1      z[4,3,3]
 FR BND1      z[4,3,4]
 FR BND1      z[4,3,5]
 FR BND1      z[4,3,6]
 FR BND1      z[3,10,0]
 FR BND1      z[3,10,1]
 FR BND1      z[3,10,2]
 FR BND1      z[3,10,3]
 FR BND1      z[3,10,4]
 FR BND1      z[3,10,5]
 FR BND1      z[3,10,6]
 FR BND1      z[10,3,0]
 FR BND1      z[10,3,1]
 FR BND1      z[10,3,2]
 FR BND1      z[10,3,3]
 FR BND1      z[10,3,4]
 FR BND1      z[10,3,5]
 FR BND1      z[10,3,6]
 FR BND1      z[4,5,0]
 FR BND1      z[4,5,1]
 FR BND1      z[4,5,2]
 FR BND1      z[4,5,3]
 FR BND1      z[4,5,4]
 FR BND1      z[4,5,5]
 FR BND1      z[4,5,6]
 FR BND1      z[5,4,0]
 FR BND1      z[5,4,1]
 FR BND1      z[5,4,2]
 FR BND1      z[5,4,3]
 FR BND1      z[5,4,4]
 FR BND1      z[5,4,5]
 FR BND1      z[5,4,6]
 FR BND1      z[4,10,0]
 FR BND1      z[4,10,1]
 FR BND1      z[4,10,2]
 FR BND1      z[4,10,3]
 FR BND1      z[4,10,4]
 FR BND1      z[4,10,5]
 FR BND1      z[4,10,6]
 FR BND1      z[10,4,0]
 FR BND1      z[10,4,1]
 FR BND1      z[10,4,2]
 FR BND1      z[10,4,3]
 FR BND1      z[10,4,4]
 FR BND1      z[10,4,5]
 FR BND1      z[10,4,6]
 FR BND1      z[6,7,0]
 FR BND1      z[6,7,1]
 FR BND1      z[6,7,2]
 FR BND1      z[6,7,3]
 FR BND1      z[6,7,4]
 FR BND1      z[6,7,5]
 FR BND1      z[6,7,6]
 FR BND1      z[7,6,0]
 FR BND1      z[7,6,1]
 FR BND1      z[7,6,2]
 FR BND1      z[7,6,3]
 FR BND1      z[7,6,4]
 FR BND1      z[7,6,5]
 FR BND1      z[7,6,6]
 FR BND1      z[7,8,0]
 FR BND1      z[7,8,1]
 FR BND1      z[7,8,2]
 FR BND1      z[7,8,3]
 FR BND1      z[7,8,4]
 FR BND1      z[7,8,5]
 FR BND1      z[7,8,6]
 FR BND1      z[8,7,0]
 FR BND1      z[8,7,1]
 FR BND1      z[8,7,2]
 FR BND1      z[8,7,3]
 FR BND1      z[8,7,4]
 FR BND1      z[8,7,5]
 FR BND1      z[8,7,6]
 FR BND1      z[8,9,0]
 FR BND1      z[8,9,1]
 FR BND1      z[8,9,2]
 FR BND1      z[8,9,3]
 FR BND1      z[8,9,4]
 FR BND1      z[8,9,5]
 FR BND1      z[8,9,6]
 FR BND1      z[9,8,0]
 FR BND1      z[9,8,1]
 FR BND1      z[9,8,2]
 FR BND1      z[9,8,3]
 FR BND1      z[9,8,4]
 FR BND1      z[9,8,5]
 FR BND1      z[9,8,6]
 FR BND1      z[9,10,0]
 FR BND1      z[9,10,1]
 FR BND1      z[9,10,2]
 FR BND1      z[9,10,3]
 FR BND1      z[9,10,4]
 FR BND1      z[9,10,5]
 FR BND1      z[9,10,6]
 FR BND1      z[10,9,0]
 FR BND1      z[10,9,1]
 FR BND1      z[10,9,2]
 FR BND1      z[10,9,3]
 FR BND1      z[10,9,4]
 FR BND1      z[10,9,5]
 FR BND1      z[10,9,6]
 FR BND1      delta[0,0]
 FR BND1      delta[0,1]
 FR BND1      delta[0,2]
 FR BND1      delta[0,3]
 FR BND1      delta[0,4]
 FR BND1      delta[0,5]
 FR BND1      delta[0,6]
 FR BND1      delta[1,0]
 FR BND1      delta[1,1]
 FR BND1      delta[1,2]
 FR BND1      delta[1,3]
 FR BND1      delta[1,4]
 FR BND1      delta[1,5]
 FR BND1      delta[1,6]
 FR BND1      delta[2,0]
 FR BND1      delta[2,1]
 FR BND1      delta[2,2]
 FR BND1      delta[2,3]
 FR BND1      delta[2,4]
 FR BND1      delta[2,5]
 FR BND1      delta[2,6]
 FR BND1      delta[3,0]
 FR BND1      delta[3,1]
 FR BND1      delta[3,2]
 FR BND1      delta[3,3]
 FR BND1      delta[3,4]
 FR BND1      delta[3,5]
 FR BND1      delta[3,6]
 FR BND1      delta[4,0]
 FR BND1      delta[4,1]
 FR BND1      delta[4,2]
 FR BND1      delta[4,3]
 FR BND1      delta[4,4]
 FR BND1      delta[4,5]
 FR BND1      delta[4,6]
 FR BND1      delta[5,0]
 FR BND1      delta[5,1]
 FR BND1      delta[5,2]
 FR BND1      delta[5,3]
 FR BND1      delta[5,4]
 FR BND1      delta[5,5]
 FR BND1      delta[5,6]
 FR BND1      delta[6,0]
 FR BND1      delta[6,1]
 FR BND1      delta[6,2]
 FR BND1      delta[6,3]
 FR BND1      delta[6,4]
 FR BND1      delta[6,5]
 FR BND1      delta[6,6]
 FR BND1      delta[7,0]
 FR BND1      delta[7,1]
 FR BND1      delta[7,2]
 FR BND1      delta[7,3]
 FR BND1      delta[7,4]
 FR BND1      delta[7,5]
 FR BND1      delta[7,6]
 FR BND1      delta[8,0]
 FR BND1      delta[8,1]
 FR BND1      delta[8,2]
 FR BND1      delta[8,3]
 FR BND1      delta[8,4]
 FR BND1      delta[8,5]
 FR BND1      delta[8,6]
 FR BND1      delta[9,0]
 FR BND1      delta[9,1]
 FR BND1      delta[9,2]
 FR BND1      delta[9,3]
 FR BND1      delta[9,4]
 FR BND1      delta[9,5]
 FR BND1      delta[9,6]
 FR BND1      delta[10,0]
 FR BND1      delta[10,1]
 FR BND1      delta[10,2]
 FR BND1      delta[10,3]
 FR BND1      delta[10,4]
 FR BND1      delta[10,5]
 FR BND1      delta[10,6]
QCMATRIX   qc0     
    length[0]  length[0]  -1
    delta[0,0]  delta[0,0]  1
    delta[0,1]  delta[0,1]  1
    delta[0,2]  delta[0,2]  1
    delta[0,3]  delta[0,3]  1
    delta[0,4]  delta[0,4]  1
    delta[0,5]  delta[0,5]  1
    delta[0,6]  delta[0,6]  1
QCMATRIX   qc1     
    length[1]  length[1]  -1
    delta[1,0]  delta[1,0]  1
    delta[1,1]  delta[1,1]  1
    delta[1,2]  delta[1,2]  1
    delta[1,3]  delta[1,3]  1
    delta[1,4]  delta[1,4]  1
    delta[1,5]  delta[1,5]  1
    delta[1,6]  delta[1,6]  1
QCMATRIX   qc2     
    length[2]  length[2]  -1
    delta[2,0]  delta[2,0]  1
    delta[2,1]  delta[2,1]  1
    delta[2,2]  delta[2,2]  1
    delta[2,3]  delta[2,3]  1
    delta[2,4]  delta[2,4]  1
    delta[2,5]  delta[2,5]  1
    delta[2,6]  delta[2,6]  1
QCMATRIX   qc3     
    length[3]  length[3]  -1
    delta[3,0]  delta[3,0]  1
    delta[3,1]  delta[3,1]  1
    delta[3,2]  delta[3,2]  1
    delta[3,3]  delta[3,3]  1
    delta[3,4]  delta[3,4]  1
    delta[3,5]  delta[3,5]  1
    delta[3,6]  delta[3,6]  1
QCMATRIX   qc4     
    length[4]  length[4]  -1
    delta[4,0]  delta[4,0]  1
    delta[4,1]  delta[4,1]  1
    delta[4,2]  delta[4,2]  1
    delta[4,3]  delta[4,3]  1
    delta[4,4]  delta[4,4]  1
    delta[4,5]  delta[4,5]  1
    delta[4,6]  delta[4,6]  1
QCMATRIX   qc5     
    length[5]  length[5]  -1
    delta[5,0]  delta[5,0]  1
    delta[5,1]  delta[5,1]  1
    delta[5,2]  delta[5,2]  1
    delta[5,3]  delta[5,3]  1
    delta[5,4]  delta[5,4]  1
    delta[5,5]  delta[5,5]  1
    delta[5,6]  delta[5,6]  1
QCMATRIX   qc6     
    length[6]  length[6]  -1
    delta[6,0]  delta[6,0]  1
    delta[6,1]  delta[6,1]  1
    delta[6,2]  delta[6,2]  1
    delta[6,3]  delta[6,3]  1
    delta[6,4]  delta[6,4]  1
    delta[6,5]  delta[6,5]  1
    delta[6,6]  delta[6,6]  1
QCMATRIX   qc7     
    length[7]  length[7]  -1
    delta[7,0]  delta[7,0]  1
    delta[7,1]  delta[7,1]  1
    delta[7,2]  delta[7,2]  1
    delta[7,3]  delta[7,3]  1
    delta[7,4]  delta[7,4]  1
    delta[7,5]  delta[7,5]  1
    delta[7,6]  delta[7,6]  1
QCMATRIX   qc8     
    length[8]  length[8]  -1
    delta[8,0]  delta[8,0]  1
    delta[8,1]  delta[8,1]  1
    delta[8,2]  delta[8,2]  1
    delta[8,3]  delta[8,3]  1
    delta[8,4]  delta[8,4]  1
    delta[8,5]  delta[8,5]  1
    delta[8,6]  delta[8,6]  1
QCMATRIX   qc9     
    length[9]  length[9]  -1
    delta[9,0]  delta[9,0]  1
    delta[9,1]  delta[9,1]  1
    delta[9,2]  delta[9,2]  1
    delta[9,3]  delta[9,3]  1
    delta[9,4]  delta[9,4]  1
    delta[9,5]  delta[9,5]  1
    delta[9,6]  delta[9,6]  1
QCMATRIX   qc10    
    length[10]  length[10]  -1
    delta[10,0]  delta[10,0]  1
    delta[10,1]  delta[10,1]  1
    delta[10,2]  delta[10,2]  1
    delta[10,3]  delta[10,3]  1
    delta[10,4]  delta[10,4]  1
    delta[10,5]  delta[10,5]  1
    delta[10,6]  delta[10,6]  1
ENDATA
