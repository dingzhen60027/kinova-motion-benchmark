NAME LGCS_GCS_Eq5_5_projected
ROWS
 N  OBJ
 E  R0      
 L  R1      
 E  R2      
 E  R3      
 E  R4      
 E  R5      
 E  R6      
 E  R7      
 E  R8      
 E  R9      
 L  R10     
 E  R11     
 E  R12     
 E  R13     
 E  R14     
 E  R15     
 E  R16     
 E  R17     
 E  R18     
 L  R19     
 E  R20     
 E  R21     
 E  R22     
 E  R23     
 E  R24     
 E  R25     
 E  R26     
 E  R27     
 L  R28     
 E  R29     
 E  R30     
 E  R31     
 E  R32     
 E  R33     
 E  R34     
 E  R35     
 E  R36     
 L  R37     
 E  R38     
 E  R39     
 E  R40     
 E  R41     
 E  R42     
 E  R43     
 E  R44     
 E  R45     
 L  R46     
 E  R47     
 E  R48     
 E  R49     
 E  R50     
 E  R51     
 E  R52     
 E  R53     
 E  R54     
 L  R55     
 E  R56     
 E  R57     
 E  R58     
 E  R59     
 E  R60     
 E  R61     
 E  R62     
 E  R63     
 L  R64     
 E  R65     
 E  R66     
 E  R67     
 E  R68     
 E  R69     
 E  R70     
 E  R71     
 E  R72     
 L  R73     
 E  R74     
 E  R75     
 E  R76     
 E  R77     
 E  R78     
 E  R79     
 E  R80     
 E  R81     
 E  R82     
 L  R83     
 L  R84     
 L  R85     
 L  R86     
 L  R87     
 L  R88     
 L  R89     
 L  R90     
 L  R91     
 L  R92     
 L  R93     
 L  R94     
 L  R95     
 L  R96     
 L  R97     
 L  R98     
 L  R99     
 L  R100    
 L  R101    
 L  R102    
 L  R103    
 L  R104    
 L  R105    
 L  R106    
 L  R107    
 L  R108    
 L  R109    
 L  R110    
 L  R111    
 L  R112    
 L  R113    
 L  R114    
 L  R115    
 L  R116    
 L  R117    
 L  R118    
 L  R119    
 L  R120    
 L  R121    
 L  R122    
 L  R123    
 L  R124    
 L  R125    
 L  R126    
 L  R127    
 L  R128    
 L  R129    
 L  R130    
 L  R131    
 L  R132    
 L  R133    
 L  R134    
 L  R135    
 L  R136    
 L  R137    
 L  R138    
 L  R139    
 L  R140    
 L  R141    
 L  R142    
 L  R143    
 L  R144    
 L  R145    
 L  R146    
 L  R147    
 L  R148    
 L  R149    
 L  R150    
 L  R151    
 L  R152    
 L  R153    
 L  R154    
 L  R155    
 L  R156    
 L  R157    
 L  R158    
 L  R159    
 L  R160    
 L  R161    
 L  R162    
 L  R163    
 L  R164    
 L  R165    
 L  R166    
 L  R167    
 L  R168    
 L  R169    
 L  R170    
 L  R171    
 L  R172    
 L  R173    
 L  R174    
 L  R175    
 L  R176    
 L  R177    
 L  R178    
 L  R179    
 L  R180    
 L  R181    
 L  R182    
 L  R183    
 L  R184    
 L  R185    
 L  R186    
 L  R187    
 L  R188    
 L  R189    
 L  R190    
 L  R191    
 L  R192    
 L  R193    
 L  R194    
 L  R195    
 L  R196    
 L  R197    
 L  R198    
 L  R199    
 L  R200    
 L  R201    
 L  R202    
 L  R203    
 L  R204    
 L  R205    
 L  R206    
 L  R207    
 L  R208    
 L  R209    
 L  R210    
 L  R211    
 L  R212    
 L  R213    
 L  R214    
 L  R215    
 L  R216    
 L  R217    
 L  R218    
 L  R219    
 L  R220    
 L  R221    
 L  R222    
 L  R223    
 L  R224    
 L  R225    
 L  R226    
 L  R227    
 L  R228    
 L  R229    
 L  R230    
 L  R231    
 L  R232    
 L  R233    
 L  R234    
 L  R235    
 L  R236    
 L  R237    
 L  R238    
 L  R239    
 L  R240    
 L  R241    
 L  R242    
 L  R243    
 L  R244    
 L  R245    
 L  R246    
 L  R247    
 L  R248    
 L  R249    
 L  R250    
 L  R251    
 L  R252    
 L  R253    
 L  R254    
 L  R255    
 L  R256    
 L  R257    
 L  R258    
 L  R259    
 L  R260    
 L  R261    
 L  R262    
 L  R263    
 L  R264    
 L  R265    
 L  R266    
 L  R267    
 L  R268    
 L  R269    
 L  R270    
 L  R271    
 L  R272    
 L  R273    
 L  R274    
 L  R275    
 L  R276    
 L  R277    
 L  R278    
 L  R279    
 L  R280    
 L  R281    
 L  R282    
 L  R283    
 L  R284    
 L  R285    
 L  R286    
 L  R287    
 L  R288    
 L  R289    
 L  R290    
 L  R291    
 L  R292    
 L  R293    
 L  R294    
 L  R295    
 L  R296    
 L  R297    
 L  R298    
 L  R299    
 L  R300    
 L  R301    
 L  R302    
 L  R303    
 L  R304    
 L  R305    
 L  R306    
 L  R307    
 L  R308    
 L  R309    
 L  R310    
 L  R311    
 L  R312    
 L  R313    
 L  R314    
 L  R315    
 L  R316    
 L  R317    
 L  R318    
 L  R319    
 L  R320    
 L  R321    
 L  R322    
 L  R323    
 L  R324    
 L  R325    
 L  R326    
 L  R327    
 L  R328    
 L  R329    
 L  R330    
 L  R331    
 L  R332    
 L  R333    
 L  R334    
 L  R335    
 L  R336    
 L  R337    
 L  R338    
 L  R339    
 L  R340    
 L  R341    
 L  R342    
 L  R343    
 L  R344    
 L  R345    
 L  R346    
 L  R347    
 L  R348    
 L  R349    
 L  R350    
 L  R351    
 L  R352    
 L  R353    
 L  R354    
 L  R355    
 L  R356    
 L  R357    
 L  R358    
 L  R359    
 L  R360    
 L  R361    
 L  R362    
 L  R363    
 L  R364    
 L  R365    
 L  R366    
 L  R367    
 L  R368    
 L  R369    
 L  R370    
 L  R371    
 L  R372    
 L  R373    
 L  R374    
 L  R375    
 L  R376    
 L  R377    
 L  R378    
 L  R379    
 L  R380    
 L  R381    
 L  R382    
 L  R383    
 L  R384    
 L  R385    
 L  R386    
 L  R387    
 L  R388    
 L  R389    
 L  R390    
 L  R391    
 L  R392    
 L  R393    
 L  R394    
 L  R395    
 L  R396    
 L  R397    
 L  R398    
 L  R399    
 L  R400    
 L  R401    
 L  R402    
 L  R403    
 L  R404    
 L  R405    
 L  R406    
 L  R407    
 L  R408    
 L  R409    
 L  R410    
 L  R411    
 L  R412    
 L  R413    
 L  R414    
 L  R415    
 L  R416    
 L  R417    
 L  R418    
 L  R419    
 L  R420    
 L  R421    
 L  R422    
 L  R423    
 L  R424    
 L  R425    
 L  R426    
 L  R427    
 L  R428    
 L  R429    
 L  R430    
 L  R431    
 L  R432    
 L  R433    
 L  R434    
 L  R435    
 L  R436    
 L  R437    
 L  R438    
 L  R439    
 L  R440    
 L  R441    
 L  R442    
 L  R443    
 L  R444    
 L  R445    
 L  R446    
 L  R447    
 L  R448    
 L  R449    
 L  R450    
 L  R451    
 L  R452    
 L  R453    
 L  R454    
 L  R455    
 L  R456    
 L  R457    
 L  R458    
 L  R459    
 L  R460    
 L  R461    
 L  R462    
 L  R463    
 L  R464    
 L  R465    
 L  R466    
 L  R467    
 L  R468    
 L  R469    
 L  R470    
 L  R471    
 L  R472    
 L  R473    
 L  R474    
 L  R475    
 L  R476    
 L  R477    
 L  R478    
 L  R479    
 L  R480    
 L  R481    
 L  R482    
 L  R483    
 L  R484    
 L  R485    
 L  R486    
 L  R487    
 L  R488    
 L  R489    
 L  R490    
 L  R491    
 L  R492    
 L  R493    
 L  R494    
 L  R495    
 L  R496    
 L  R497    
 L  R498    
 L  R499    
 L  R500    
 L  R501    
 L  R502    
 L  R503    
 L  R504    
 L  R505    
 L  R506    
 L  R507    
 L  R508    
 L  R509    
 L  R510    
 L  R511    
 L  R512    
 L  R513    
 L  R514    
 L  R515    
 L  R516    
 L  R517    
 L  R518    
 L  R519    
 L  R520    
 L  R521    
 L  R522    
 L  R523    
 L  R524    
 L  R525    
 L  R526    
 L  R527    
 L  R528    
 L  R529    
 L  R530    
 L  R531    
 L  R532    
 L  R533    
 L  R534    
 L  R535    
 L  R536    
 L  R537    
 L  R538    
 L  R539    
 L  R540    
 L  R541    
 L  R542    
 L  R543    
 L  R544    
 L  R545    
 L  R546    
 L  R547    
 L  R548    
 L  R549    
 L  R550    
 L  R551    
 L  R552    
 L  R553    
 L  R554    
 L  R555    
 L  R556    
 L  R557    
 L  R558    
 L  R559    
 L  R560    
 L  R561    
 L  R562    
 L  R563    
 L  R564    
 L  R565    
 L  R566    
 L  R567    
 L  R568    
 L  R569    
 L  R570    
 L  R571    
 L  R572    
 L  R573    
 L  R574    
 L  R575    
 L  R576    
 L  R577    
 L  R578    
 L  R579    
 L  R580    
 L  R581    
 L  R582    
 L  R583    
 L  R584    
 L  R585    
 L  R586    
 L  R587    
 L  R588    
 L  R589    
 L  R590    
 L  R591    
 L  R592    
 L  R593    
 L  R594    
 L  R595    
 L  R596    
 L  R597    
 L  R598    
 L  R599    
 L  R600    
 L  R601    
 L  R602    
 L  R603    
 L  R604    
 L  R605    
 L  R606    
 L  R607    
 L  R608    
 L  R609    
 L  R610    
 L  R611    
 L  R612    
 L  R613    
 L  R614    
 L  R615    
 L  R616    
 L  R617    
 L  R618    
 L  R619    
 L  R620    
 L  R621    
 L  R622    
 L  R623    
 L  R624    
 L  R625    
 L  R626    
 L  R627    
 L  R628    
 L  R629    
 L  R630    
 L  R631    
 L  R632    
 L  R633    
 L  R634    
 L  R635    
 L  R636    
 L  R637    
 L  R638    
 L  R639    
 L  R640    
 L  R641    
 L  R642    
 L  R643    
 L  R644    
 L  R645    
 L  R646    
 L  R647    
 L  R648    
 L  R649    
 L  R650    
 L  R651    
 L  R652    
 L  R653    
 L  R654    
 L  R655    
 L  R656    
 L  R657    
 L  R658    
 L  R659    
 L  R660    
 L  R661    
 L  R662    
 L  R663    
 L  R664    
 L  R665    
 L  R666    
 L  R667    
 L  R668    
 L  R669    
 L  R670    
 L  R671    
 L  R672    
 L  R673    
 L  R674    
 L  R675    
 L  R676    
 L  R677    
 L  R678    
 L  R679    
 L  R680    
 L  R681    
 L  R682    
 L  R683    
 L  R684    
 L  R685    
 L  R686    
 L  R687    
 L  R688    
 L  R689    
 L  R690    
 L  R691    
 L  R692    
 L  R693    
 L  R694    
 L  R695    
 L  R696    
 L  R697    
 L  R698    
 L  R699    
 L  R700    
 L  R701    
 L  R702    
 L  R703    
 L  R704    
 L  R705    
 L  R706    
 L  R707    
 L  R708    
 L  R709    
 L  R710    
 L  R711    
 L  R712    
 L  R713    
 L  R714    
 L  R715    
 L  R716    
 L  R717    
 L  R718    
 L  R719    
 L  R720    
 L  R721    
 L  R722    
 L  R723    
 L  R724    
 L  R725    
 L  R726    
 L  R727    
 L  R728    
 L  R729    
 L  R730    
 L  R731    
 L  R732    
 L  R733    
 L  R734    
 L  R735    
 L  R736    
 L  R737    
 L  R738    
 L  R739    
 L  R740    
 L  R741    
 L  R742    
 L  R743    
 L  R744    
 L  R745    
 L  R746    
 L  R747    
 L  R748    
 L  R749    
 L  R750    
 L  R751    
 L  R752    
 L  R753    
 L  R754    
 L  R755    
 L  R756    
 L  R757    
 L  R758    
 L  R759    
 L  R760    
 L  R761    
 L  R762    
 L  R763    
 L  R764    
 L  R765    
 L  R766    
 L  R767    
 L  R768    
 L  R769    
 L  R770    
 L  R771    
 L  R772    
 L  R773    
 L  R774    
 L  R775    
 L  R776    
 L  R777    
 L  R778    
 L  R779    
 L  R780    
 L  R781    
 L  R782    
 L  R783    
 L  R784    
 L  R785    
 L  R786    
 L  R787    
 L  R788    
 L  R789    
 L  R790    
 L  R791    
 L  R792    
 L  R793    
 L  R794    
 L  R795    
 L  R796    
 L  R797    
 L  R798    
 L  R799    
 L  R800    
 L  R801    
 L  R802    
 L  R803    
 L  R804    
 L  R805    
 L  R806    
 L  R807    
 L  R808    
 L  R809    
 L  R810    
 L  R811    
 L  R812    
 L  R813    
 L  R814    
 L  R815    
 L  R816    
 L  R817    
 L  R818    
 L  R819    
 L  R820    
 L  R821    
 L  R822    
 L  R823    
 L  R824    
 L  R825    
 L  R826    
 L  R827    
 L  R828    
 L  R829    
 L  R830    
 L  R831    
 L  R832    
 L  R833    
 L  R834    
 L  R835    
 L  R836    
 L  R837    
 L  R838    
 L  R839    
 L  R840    
 L  R841    
 L  R842    
 L  R843    
 L  R844    
 L  R845    
 L  R846    
 L  R847    
 L  R848    
 L  R849    
 L  R850    
 L  R851    
 L  R852    
 L  R853    
 L  R854    
 L  R855    
 L  R856    
 L  R857    
 L  R858    
 L  R859    
 L  R860    
 L  R861    
 L  R862    
 L  R863    
 L  R864    
 L  R865    
 L  R866    
 L  R867    
 L  R868    
 L  R869    
 L  R870    
 L  R871    
 L  R872    
 L  R873    
 L  R874    
 L  R875    
 L  R876    
 L  R877    
 L  R878    
 L  R879    
 L  R880    
 L  R881    
 L  R882    
 L  R883    
 L  R884    
 L  R885    
 L  R886    
 L  R887    
 L  R888    
 L  R889    
 L  R890    
 L  R891    
 L  R892    
 L  R893    
 L  R894    
 L  R895    
 L  R896    
 L  R897    
 L  R898    
 L  R899    
 L  R900    
 L  R901    
 L  R902    
 L  R903    
 L  R904    
 L  R905    
 L  R906    
 L  R907    
 L  R908    
 L  R909    
 L  R910    
 L  R911    
 L  R912    
 L  R913    
 L  R914    
 L  R915    
 L  R916    
 L  R917    
 L  R918    
 L  R919    
 L  R920    
 L  R921    
 L  R922    
 L  R923    
 L  R924    
 L  R925    
 L  R926    
 L  R927    
 L  R928    
 L  R929    
 L  R930    
 L  R931    
 L  R932    
 L  R933    
 L  R934    
 L  R935    
 L  R936    
 L  R937    
 L  R938    
 L  R939    
 L  R940    
 L  R941    
 L  R942    
 L  R943    
 L  R944    
 L  R945    
 L  R946    
 L  R947    
 L  R948    
 L  R949    
 L  R950    
 L  R951    
 L  R952    
 L  R953    
 L  R954    
 L  R955    
 L  R956    
 L  R957    
 L  R958    
 L  R959    
 L  R960    
 L  R961    
 L  R962    
 L  R963    
 L  R964    
 L  R965    
 L  R966    
 L  R967    
 L  R968    
 L  R969    
 L  R970    
 L  R971    
 L  R972    
 L  R973    
 L  R974    
 L  R975    
 L  R976    
 L  R977    
 L  R978    
 L  R979    
 L  R980    
 L  R981    
 L  R982    
 L  R983    
 L  R984    
 L  R985    
 L  R986    
 L  R987    
 L  R988    
 L  R989    
 L  R990    
 L  R991    
 L  R992    
 L  R993    
 L  R994    
 L  R995    
 L  R996    
 L  R997    
 L  R998    
 L  R999    
 L  R1000   
 L  R1001   
 L  R1002   
 L  R1003   
 L  R1004   
 L  R1005   
 L  R1006   
 L  R1007   
 L  R1008   
 L  R1009   
 L  R1010   
 L  R1011   
 L  R1012   
 L  R1013   
 L  R1014   
 L  R1015   
 L  R1016   
 L  R1017   
 L  R1018   
 L  R1019   
 L  R1020   
 L  R1021   
 L  R1022   
 L  R1023   
 L  R1024   
 L  R1025   
 L  R1026   
 L  R1027   
 L  R1028   
 L  R1029   
 L  R1030   
 L  R1031   
 L  R1032   
 L  R1033   
 L  R1034   
 L  R1035   
 L  R1036   
 L  R1037   
 L  R1038   
 L  R1039   
 L  R1040   
 L  R1041   
 L  R1042   
 L  R1043   
 L  R1044   
 L  R1045   
 L  R1046   
 L  R1047   
 L  R1048   
 L  R1049   
 L  R1050   
 L  R1051   
 L  R1052   
 L  R1053   
 L  R1054   
 L  R1055   
 L  R1056   
 L  R1057   
 L  R1058   
 L  R1059   
 L  R1060   
 L  R1061   
 L  R1062   
 L  R1063   
 L  R1064   
 L  R1065   
 L  R1066   
 L  R1067   
 L  R1068   
 L  R1069   
 L  R1070   
 L  R1071   
 L  R1072   
 L  R1073   
 L  R1074   
 L  R1075   
 L  R1076   
 L  R1077   
 L  R1078   
 L  R1079   
 L  R1080   
 L  R1081   
 L  R1082   
 L  R1083   
 L  R1084   
 L  R1085   
 L  R1086   
 L  R1087   
 L  R1088   
 L  R1089   
 L  R1090   
 L  R1091   
 L  R1092   
 L  R1093   
 L  R1094   
 L  R1095   
 L  R1096   
 L  R1097   
 L  R1098   
 L  R1099   
 L  R1100   
 L  R1101   
 L  R1102   
 L  R1103   
 L  R1104   
 L  R1105   
 L  R1106   
 L  R1107   
 L  R1108   
 L  R1109   
 L  R1110   
 L  R1111   
 L  R1112   
 L  R1113   
 L  R1114   
 L  R1115   
 L  R1116   
 L  R1117   
 L  R1118   
 L  R1119   
 L  R1120   
 L  R1121   
 L  R1122   
 L  R1123   
 L  R1124   
 L  R1125   
 L  R1126   
 L  R1127   
 L  R1128   
 L  R1129   
 L  R1130   
 L  R1131   
 L  R1132   
 L  R1133   
 L  R1134   
 L  R1135   
 L  R1136   
 L  R1137   
 L  R1138   
 L  R1139   
 L  R1140   
 L  R1141   
 L  R1142   
 L  R1143   
 L  R1144   
 L  R1145   
 L  R1146   
 L  R1147   
 L  R1148   
 L  R1149   
 L  R1150   
 L  R1151   
 L  R1152   
 L  R1153   
 L  R1154   
 L  R1155   
 L  R1156   
 L  R1157   
 L  R1158   
 L  R1159   
 L  R1160   
 L  R1161   
 L  R1162   
 L  R1163   
 L  R1164   
 L  R1165   
 L  R1166   
 L  R1167   
 L  R1168   
 L  R1169   
 L  R1170   
 L  R1171   
 L  R1172   
 L  R1173   
 L  R1174   
 L  R1175   
 L  R1176   
 L  R1177   
 L  R1178   
 L  R1179   
 L  R1180   
 L  R1181   
 L  R1182   
 L  R1183   
 L  R1184   
 L  R1185   
 L  R1186   
 L  R1187   
 L  R1188   
 L  R1189   
 L  R1190   
 L  R1191   
 L  R1192   
 L  R1193   
 L  R1194   
 L  R1195   
 L  R1196   
 L  R1197   
 L  R1198   
 L  R1199   
 L  R1200   
 L  R1201   
 L  R1202   
 L  R1203   
 L  R1204   
 L  R1205   
 L  R1206   
 L  R1207   
 L  R1208   
 L  R1209   
 L  R1210   
 L  R1211   
 L  R1212   
 L  R1213   
 L  R1214   
 L  R1215   
 L  R1216   
 L  R1217   
 L  R1218   
 L  R1219   
 L  R1220   
 L  R1221   
 L  R1222   
 L  R1223   
 L  R1224   
 L  R1225   
 L  R1226   
 L  R1227   
 L  R1228   
 L  R1229   
 L  R1230   
 L  R1231   
 L  R1232   
 L  R1233   
 L  R1234   
 L  R1235   
 L  R1236   
 L  R1237   
 L  R1238   
 L  R1239   
 L  R1240   
 L  R1241   
 L  R1242   
 L  R1243   
 L  R1244   
 L  R1245   
 L  R1246   
 L  R1247   
 L  R1248   
 L  R1249   
 L  R1250   
 L  R1251   
 L  R1252   
 L  R1253   
 L  R1254   
 L  R1255   
 L  R1256   
 L  R1257   
 L  R1258   
 L  R1259   
 L  R1260   
 L  R1261   
 L  R1262   
 L  R1263   
 L  R1264   
 L  R1265   
 L  R1266   
 L  R1267   
 L  R1268   
 L  R1269   
 L  R1270   
 L  R1271   
 L  R1272   
 L  R1273   
 L  R1274   
 L  R1275   
 L  R1276   
 L  R1277   
 L  R1278   
 L  R1279   
 L  R1280   
 L  R1281   
 L  R1282   
 L  R1283   
 L  R1284   
 L  R1285   
 L  R1286   
 L  R1287   
 L  R1288   
 L  R1289   
 L  R1290   
 L  R1291   
 L  R1292   
 L  R1293   
 L  R1294   
 L  R1295   
 L  R1296   
 L  R1297   
 L  R1298   
 L  R1299   
 L  R1300   
 L  R1301   
 L  R1302   
 L  R1303   
 L  R1304   
 L  R1305   
 L  R1306   
 L  R1307   
 L  R1308   
 L  R1309   
 L  R1310   
 L  R1311   
 L  R1312   
 L  R1313   
 L  R1314   
 L  R1315   
 L  R1316   
 L  R1317   
 L  R1318   
 L  R1319   
 L  R1320   
 L  R1321   
 L  R1322   
 L  R1323   
 L  R1324   
 L  R1325   
 L  R1326   
 L  R1327   
 L  R1328   
 L  R1329   
 L  R1330   
 L  R1331   
 L  R1332   
 L  R1333   
 L  R1334   
 L  R1335   
 L  R1336   
 L  R1337   
 L  R1338   
 L  R1339   
 L  R1340   
 L  R1341   
 L  R1342   
 L  R1343   
 L  R1344   
 L  R1345   
 L  R1346   
 L  R1347   
 L  R1348   
 L  R1349   
 L  R1350   
 L  R1351   
 L  R1352   
 L  R1353   
 L  R1354   
 L  R1355   
 L  R1356   
 L  R1357   
 L  R1358   
 L  R1359   
 L  R1360   
 L  R1361   
 L  R1362   
 L  R1363   
 L  R1364   
 L  R1365   
 L  R1366   
 L  R1367   
 L  R1368   
 L  R1369   
 L  R1370   
 L  R1371   
 L  R1372   
 L  R1373   
 L  R1374   
 L  R1375   
 L  R1376   
 L  R1377   
 L  R1378   
 L  R1379   
 L  R1380   
 L  R1381   
 L  R1382   
 L  R1383   
 L  R1384   
 L  R1385   
 L  R1386   
 L  R1387   
 L  R1388   
 L  R1389   
 L  R1390   
 L  R1391   
 L  R1392   
 L  R1393   
 L  R1394   
 L  R1395   
 L  R1396   
 L  R1397   
 L  R1398   
 L  R1399   
 L  R1400   
 L  R1401   
 L  R1402   
 L  R1403   
 L  R1404   
 L  R1405   
 L  R1406   
 L  R1407   
 L  R1408   
 L  R1409   
 L  R1410   
 L  R1411   
 L  R1412   
 L  R1413   
 L  R1414   
 L  R1415   
 L  R1416   
 L  R1417   
 L  R1418   
 L  R1419   
 L  R1420   
 L  R1421   
 L  R1422   
 L  R1423   
 L  R1424   
 L  R1425   
 L  R1426   
 L  R1427   
 L  R1428   
 L  R1429   
 L  R1430   
 L  R1431   
 L  R1432   
 L  R1433   
 L  R1434   
 L  R1435   
 L  R1436   
 L  R1437   
 L  R1438   
 L  R1439   
 L  R1440   
 L  R1441   
 L  R1442   
 L  R1443   
 L  R1444   
 L  R1445   
 L  R1446   
 L  R1447   
 L  R1448   
 L  R1449   
 L  R1450   
 L  R1451   
 L  R1452   
 L  R1453   
 L  R1454   
 L  R1455   
 L  R1456   
 L  R1457   
 L  R1458   
 L  R1459   
 L  R1460   
 L  R1461   
 L  R1462   
 L  R1463   
 L  R1464   
 L  R1465   
 L  R1466   
 L  R1467   
 L  R1468   
 L  R1469   
 L  R1470   
 L  R1471   
 L  R1472   
 L  R1473   
 L  R1474   
 L  R1475   
 L  R1476   
 L  R1477   
 L  R1478   
 L  R1479   
 L  R1480   
 L  R1481   
 L  R1482   
 L  R1483   
 L  R1484   
 L  R1485   
 L  R1486   
 L  R1487   
 L  R1488   
 L  R1489   
 L  R1490   
 L  R1491   
 L  R1492   
 L  R1493   
 L  R1494   
 L  R1495   
 L  R1496   
 L  R1497   
 L  R1498   
 L  R1499   
 L  R1500   
 L  R1501   
 L  R1502   
 L  R1503   
 L  R1504   
 L  R1505   
 L  R1506   
 L  R1507   
 L  R1508   
 L  R1509   
 L  R1510   
 L  R1511   
 L  R1512   
 L  R1513   
 L  R1514   
 L  R1515   
 L  R1516   
 L  R1517   
 L  R1518   
 L  R1519   
 L  R1520   
 L  R1521   
 L  R1522   
 L  R1523   
 L  R1524   
 L  R1525   
 L  R1526   
 L  R1527   
 L  R1528   
 L  R1529   
 L  R1530   
 L  R1531   
 L  R1532   
 L  R1533   
 L  R1534   
 L  R1535   
 L  R1536   
 L  R1537   
 L  R1538   
 L  R1539   
 L  R1540   
 L  R1541   
 L  R1542   
 L  R1543   
 L  R1544   
 L  R1545   
 L  R1546   
 L  R1547   
 L  R1548   
 L  R1549   
 L  R1550   
 L  R1551   
 L  R1552   
 L  R1553   
 L  R1554   
 L  R1555   
 L  R1556   
 L  R1557   
 L  R1558   
 L  R1559   
 L  R1560   
 L  R1561   
 L  R1562   
 L  R1563   
 L  R1564   
 L  R1565   
 L  R1566   
 L  R1567   
 L  R1568   
 L  R1569   
 L  R1570   
 L  R1571   
 L  R1572   
 L  R1573   
 L  R1574   
 L  R1575   
 L  R1576   
 L  R1577   
 L  R1578   
 L  R1579   
 L  R1580   
 L  R1581   
 L  R1582   
 L  R1583   
 L  R1584   
 L  R1585   
 L  R1586   
 L  R1587   
 L  R1588   
 L  R1589   
 L  R1590   
 L  R1591   
 L  R1592   
 L  R1593   
 L  R1594   
 L  R1595   
 L  R1596   
 L  R1597   
 L  R1598   
 L  R1599   
 L  R1600   
 L  R1601   
 L  R1602   
 L  R1603   
 L  R1604   
 L  R1605   
 L  R1606   
 L  R1607   
 L  R1608   
 L  R1609   
 L  R1610   
 L  R1611   
 L  R1612   
 L  R1613   
 L  R1614   
 L  R1615   
 L  R1616   
 L  R1617   
 L  R1618   
 L  R1619   
 L  R1620   
 L  R1621   
 L  R1622   
 L  R1623   
 L  R1624   
 L  R1625   
 L  R1626   
 L  R1627   
 L  R1628   
 L  R1629   
 L  R1630   
 L  R1631   
 L  R1632   
 L  R1633   
 L  R1634   
 L  R1635   
 L  R1636   
 L  R1637   
 L  R1638   
 L  R1639   
 L  R1640   
 L  R1641   
 L  R1642   
 L  R1643   
 L  R1644   
 L  R1645   
 L  R1646   
 L  R1647   
 L  R1648   
 L  R1649   
 L  R1650   
 L  R1651   
 L  R1652   
 L  R1653   
 L  R1654   
 L  R1655   
 L  R1656   
 L  R1657   
 L  R1658   
 L  R1659   
 L  R1660   
 L  R1661   
 L  R1662   
 L  R1663   
 L  R1664   
 L  R1665   
 L  R1666   
 L  R1667   
 L  R1668   
 L  R1669   
 L  R1670   
 L  R1671   
 L  R1672   
 L  R1673   
 L  R1674   
 L  R1675   
 L  R1676   
 L  R1677   
 L  R1678   
 L  R1679   
 L  R1680   
 L  R1681   
 L  R1682   
 L  R1683   
 L  R1684   
 L  R1685   
 L  R1686   
 L  R1687   
 L  R1688   
 L  R1689   
 L  R1690   
 L  R1691   
 L  R1692   
 L  R1693   
 L  R1694   
 L  R1695   
 L  R1696   
 L  R1697   
 L  R1698   
 L  R1699   
 L  R1700   
 L  R1701   
 L  R1702   
 L  R1703   
 L  R1704   
 L  R1705   
 L  R1706   
 L  R1707   
 L  R1708   
 L  R1709   
 L  R1710   
 L  R1711   
 L  R1712   
 L  R1713   
 L  R1714   
 L  R1715   
 L  R1716   
 L  R1717   
 L  R1718   
 L  R1719   
 L  R1720   
 L  R1721   
 L  R1722   
 L  R1723   
 L  R1724   
 L  R1725   
 L  R1726   
 L  R1727   
 L  R1728   
 L  R1729   
 L  R1730   
 L  R1731   
 L  R1732   
 L  R1733   
 L  R1734   
 L  R1735   
 L  R1736   
 L  R1737   
 L  R1738   
 L  R1739   
 L  R1740   
 L  R1741   
 L  R1742   
 L  R1743   
 L  R1744   
 L  R1745   
 L  R1746   
 L  R1747   
 L  R1748   
 L  R1749   
 L  R1750   
 L  R1751   
 L  R1752   
 L  R1753   
 L  R1754   
 L  R1755   
 L  R1756   
 L  R1757   
 L  R1758   
 L  R1759   
 L  R1760   
 L  R1761   
 L  R1762   
 L  R1763   
 L  R1764   
 L  R1765   
 L  R1766   
 L  R1767   
 L  R1768   
 L  R1769   
 L  R1770   
 L  R1771   
 L  R1772   
 L  R1773   
 L  R1774   
 L  R1775   
 L  R1776   
 L  R1777   
 L  R1778   
 L  R1779   
 L  R1780   
 L  R1781   
 L  R1782   
 L  R1783   
 L  R1784   
 L  R1785   
 L  R1786   
 L  R1787   
 L  R1788   
 L  R1789   
 L  R1790   
 L  R1791   
 L  R1792   
 L  R1793   
 L  R1794   
 L  R1795   
 L  R1796   
 L  R1797   
 L  R1798   
 L  R1799   
 L  R1800   
 L  R1801   
 L  R1802   
 L  R1803   
 L  R1804   
 L  R1805   
 L  R1806   
 L  R1807   
 L  R1808   
 L  R1809   
 L  R1810   
 L  R1811   
 L  R1812   
 L  R1813   
 L  R1814   
 L  R1815   
 L  R1816   
 L  R1817   
 L  R1818   
 L  R1819   
 L  R1820   
 L  R1821   
 L  R1822   
 L  R1823   
 L  R1824   
 L  R1825   
 L  R1826   
 L  R1827   
 L  R1828   
 L  R1829   
 L  R1830   
 L  R1831   
 L  R1832   
 L  R1833   
 L  R1834   
 L  R1835   
 L  R1836   
 L  R1837   
 L  R1838   
 L  R1839   
 L  R1840   
 L  R1841   
 L  R1842   
 L  R1843   
 L  R1844   
 L  R1845   
 L  R1846   
 L  R1847   
 L  R1848   
 L  R1849   
 L  R1850   
 L  R1851   
 L  R1852   
 L  R1853   
 L  R1854   
 L  R1855   
 L  R1856   
 L  R1857   
 L  R1858   
 L  R1859   
 L  R1860   
 L  R1861   
 L  R1862   
 L  R1863   
 L  R1864   
 L  R1865   
 L  R1866   
 L  R1867   
 L  R1868   
 L  R1869   
 L  R1870   
 L  R1871   
 L  R1872   
 L  R1873   
 L  R1874   
 L  R1875   
 L  R1876   
 L  R1877   
 L  R1878   
 L  R1879   
 L  R1880   
 L  R1881   
 L  R1882   
 L  R1883   
 L  R1884   
 L  R1885   
 L  R1886   
 L  R1887   
 L  R1888   
 L  R1889   
 L  R1890   
 L  R1891   
 L  R1892   
 L  R1893   
 L  R1894   
 L  R1895   
 L  R1896   
 L  R1897   
 L  R1898   
 L  R1899   
 L  R1900   
 L  R1901   
 L  R1902   
 L  R1903   
 L  R1904   
 L  R1905   
 L  R1906   
 L  R1907   
 L  R1908   
 L  R1909   
 L  R1910   
 L  R1911   
 L  R1912   
 L  R1913   
 L  R1914   
 L  R1915   
 L  R1916   
 L  R1917   
 L  R1918   
 L  R1919   
 L  R1920   
 L  R1921   
 L  R1922   
 L  R1923   
 L  R1924   
 L  R1925   
 L  R1926   
 L  R1927   
 L  R1928   
 L  R1929   
 L  R1930   
 L  R1931   
 L  R1932   
 L  R1933   
 L  R1934   
 L  R1935   
 L  R1936   
 L  R1937   
 L  R1938   
 L  R1939   
 L  R1940   
 L  R1941   
 L  R1942   
 L  R1943   
 L  R1944   
 L  R1945   
 L  R1946   
 L  R1947   
 L  R1948   
 L  R1949   
 L  R1950   
 L  R1951   
 L  R1952   
 L  R1953   
 L  R1954   
 L  R1955   
 L  R1956   
 L  R1957   
 L  R1958   
 L  R1959   
 L  R1960   
 L  R1961   
 L  R1962   
 L  R1963   
 L  R1964   
 L  R1965   
 L  R1966   
 L  R1967   
 L  R1968   
 L  R1969   
 L  R1970   
 L  R1971   
 L  R1972   
 L  R1973   
 L  R1974   
 L  R1975   
 L  R1976   
 L  R1977   
 L  R1978   
 L  R1979   
 L  R1980   
 L  R1981   
 L  R1982   
 L  R1983   
 L  R1984   
 L  R1985   
 L  R1986   
 L  R1987   
 L  R1988   
 L  R1989   
 L  R1990   
 L  R1991   
 L  R1992   
 L  R1993   
 L  R1994   
 L  R1995   
 L  R1996   
 L  R1997   
 L  R1998   
 L  R1999   
 L  R2000   
 L  R2001   
 L  R2002   
 L  R2003   
 L  R2004   
 L  R2005   
 L  R2006   
 L  R2007   
 L  R2008   
 L  R2009   
 L  R2010   
 L  R2011   
 L  R2012   
 L  R2013   
 L  R2014   
 L  R2015   
 L  R2016   
 L  R2017   
 L  R2018   
 L  R2019   
 L  R2020   
 L  R2021   
 L  R2022   
 L  R2023   
 L  R2024   
 L  R2025   
 L  R2026   
 L  R2027   
 L  R2028   
 L  R2029   
 L  R2030   
 L  R2031   
 L  R2032   
 L  R2033   
 L  R2034   
 L  R2035   
 L  R2036   
 L  R2037   
 L  R2038   
 L  R2039   
 L  R2040   
 L  R2041   
 L  R2042   
 L  R2043   
 L  R2044   
 L  R2045   
 L  R2046   
 L  R2047   
 L  R2048   
 L  R2049   
 L  R2050   
 L  R2051   
 L  R2052   
 L  R2053   
 L  R2054   
 L  R2055   
 L  R2056   
 L  R2057   
 L  R2058   
 L  R2059   
 L  R2060   
 L  R2061   
 L  R2062   
 L  R2063   
 L  R2064   
 L  R2065   
 L  R2066   
 L  R2067   
 L  R2068   
 L  R2069   
 L  R2070   
 L  R2071   
 L  R2072   
 L  R2073   
 L  R2074   
 L  R2075   
 L  R2076   
 L  R2077   
 L  R2078   
 L  R2079   
 L  R2080   
 L  R2081   
 L  R2082   
 L  R2083   
 L  R2084   
 L  R2085   
 L  R2086   
 L  R2087   
 L  R2088   
 L  R2089   
 L  R2090   
 L  R2091   
 L  R2092   
 L  R2093   
 L  R2094   
 L  R2095   
 L  R2096   
 L  R2097   
 L  R2098   
 L  R2099   
 L  R2100   
 L  R2101   
 L  R2102   
 L  R2103   
 L  R2104   
 L  R2105   
 L  R2106   
 L  R2107   
 L  R2108   
 L  R2109   
 L  R2110   
 L  R2111   
 L  R2112   
 L  R2113   
 L  R2114   
 L  R2115   
 L  R2116   
 L  R2117   
 L  R2118   
 L  R2119   
 L  R2120   
 L  R2121   
 L  R2122   
 L  R2123   
 L  R2124   
 L  R2125   
 L  R2126   
 L  R2127   
 L  R2128   
 L  R2129   
 L  R2130   
 L  R2131   
 L  R2132   
 L  R2133   
 L  R2134   
 L  R2135   
 L  R2136   
 L  R2137   
 L  R2138   
 L  R2139   
 L  R2140   
 L  R2141   
 L  R2142   
 L  R2143   
 L  R2144   
 L  R2145   
 L  R2146   
 L  R2147   
 L  R2148   
 L  R2149   
 L  R2150   
 L  R2151   
 L  R2152   
 L  R2153   
 L  R2154   
 L  R2155   
 L  R2156   
 L  R2157   
 L  R2158   
 L  R2159   
 L  R2160   
 L  R2161   
 L  R2162   
 L  R2163   
 L  R2164   
 L  R2165   
 L  R2166   
 L  R2167   
 L  R2168   
 L  R2169   
 L  R2170   
 L  R2171   
 L  R2172   
 L  R2173   
 L  R2174   
 L  R2175   
 L  R2176   
 L  R2177   
 L  R2178   
 L  R2179   
 L  R2180   
 L  R2181   
 L  R2182   
 L  R2183   
 L  R2184   
 L  R2185   
 L  R2186   
 L  R2187   
 L  R2188   
 L  R2189   
 L  R2190   
 L  R2191   
 L  R2192   
 L  R2193   
 L  R2194   
 L  R2195   
 L  R2196   
 L  R2197   
 L  R2198   
 L  R2199   
 L  R2200   
 L  R2201   
 L  R2202   
 L  R2203   
 L  R2204   
 L  R2205   
 L  R2206   
 L  R2207   
 L  R2208   
 L  R2209   
 L  R2210   
 L  R2211   
 L  R2212   
 L  R2213   
 L  R2214   
 L  R2215   
 L  R2216   
 L  R2217   
 L  R2218   
 L  R2219   
 L  R2220   
 L  R2221   
 L  R2222   
 L  R2223   
 L  R2224   
 L  R2225   
 L  R2226   
 L  R2227   
 L  R2228   
 L  R2229   
 L  R2230   
 L  R2231   
 L  R2232   
 L  R2233   
 L  R2234   
 L  R2235   
 L  R2236   
 L  R2237   
 L  R2238   
 L  R2239   
 L  R2240   
 L  R2241   
 L  R2242   
 L  R2243   
 L  R2244   
 L  R2245   
 L  R2246   
 L  R2247   
 L  R2248   
 L  R2249   
 L  R2250   
 L  R2251   
 L  R2252   
 L  R2253   
 L  R2254   
 L  R2255   
 L  R2256   
 L  R2257   
 L  R2258   
 L  R2259   
 L  R2260   
 L  R2261   
 L  R2262   
 L  R2263   
 L  R2264   
 L  R2265   
 L  R2266   
 L  R2267   
 L  R2268   
 L  R2269   
 L  R2270   
 L  R2271   
 L  R2272   
 L  R2273   
 L  R2274   
 L  R2275   
 L  R2276   
 L  R2277   
 L  R2278   
 L  R2279   
 L  R2280   
 L  R2281   
 L  R2282   
 L  R2283   
 L  R2284   
 L  R2285   
 L  R2286   
 L  R2287   
 L  R2288   
 L  R2289   
 L  R2290   
 L  R2291   
 L  R2292   
 L  R2293   
 L  R2294   
 L  R2295   
 L  R2296   
 L  R2297   
 L  R2298   
 L  R2299   
 L  R2300   
 L  R2301   
 L  R2302   
 L  R2303   
 L  R2304   
 L  R2305   
 L  R2306   
 L  R2307   
 L  R2308   
 L  R2309   
 L  R2310   
 L  R2311   
 L  R2312   
 L  R2313   
 L  R2314   
 L  R2315   
 L  R2316   
 L  R2317   
 L  R2318   
 L  R2319   
 L  R2320   
 L  R2321   
 L  R2322   
 L  R2323   
 L  R2324   
 L  R2325   
 L  R2326   
 L  R2327   
 L  R2328   
 L  R2329   
 L  R2330   
 L  R2331   
 L  R2332   
 L  R2333   
 L  R2334   
 L  R2335   
 L  R2336   
 L  R2337   
 L  R2338   
 L  R2339   
 L  R2340   
 L  R2341   
 L  R2342   
 L  R2343   
 L  R2344   
 L  R2345   
 L  R2346   
 L  R2347   
 L  R2348   
 L  R2349   
 L  R2350   
 L  R2351   
 L  R2352   
 L  R2353   
 L  R2354   
 L  R2355   
 L  R2356   
 L  R2357   
 L  R2358   
 L  R2359   
 L  R2360   
 L  R2361   
 L  R2362   
 L  R2363   
 L  R2364   
 L  R2365   
 L  R2366   
 L  R2367   
 L  R2368   
 L  R2369   
 L  R2370   
 L  R2371   
 L  R2372   
 L  R2373   
 L  R2374   
 L  R2375   
 L  R2376   
 L  R2377   
 L  R2378   
 L  R2379   
 L  R2380   
 L  R2381   
 L  R2382   
 L  R2383   
 L  R2384   
 L  R2385   
 L  R2386   
 L  R2387   
 L  R2388   
 L  R2389   
 L  R2390   
 L  R2391   
 L  R2392   
 L  R2393   
 L  R2394   
 L  R2395   
 L  R2396   
 L  R2397   
 L  R2398   
 L  R2399   
 L  R2400   
 L  R2401   
 L  R2402   
 L  R2403   
 L  R2404   
 L  R2405   
 L  R2406   
 L  R2407   
 L  R2408   
 L  R2409   
 L  R2410   
 L  R2411   
 L  R2412   
 L  R2413   
 L  R2414   
 L  R2415   
 L  R2416   
 L  R2417   
 L  R2418   
 L  R2419   
 L  R2420   
 L  R2421   
 L  R2422   
 L  R2423   
 L  R2424   
 L  R2425   
 L  R2426   
 L  R2427   
 L  R2428   
 L  R2429   
 L  R2430   
 L  R2431   
 L  R2432   
 L  R2433   
 L  R2434   
 L  R2435   
 L  R2436   
 L  R2437   
 L  R2438   
 L  R2439   
 L  R2440   
 L  R2441   
 L  R2442   
 L  R2443   
 L  R2444   
 L  R2445   
 L  R2446   
 L  R2447   
 L  R2448   
 L  R2449   
 L  R2450   
 L  R2451   
 L  R2452   
 L  R2453   
 L  R2454   
 L  R2455   
 L  R2456   
 L  R2457   
 L  R2458   
 L  R2459   
 L  R2460   
 L  R2461   
 L  R2462   
 L  R2463   
 L  R2464   
 L  R2465   
 L  R2466   
 L  R2467   
 L  R2468   
 L  R2469   
 L  R2470   
 L  R2471   
 L  R2472   
 L  R2473   
 L  R2474   
 L  R2475   
 L  R2476   
 L  R2477   
 L  R2478   
 L  R2479   
 L  R2480   
 L  R2481   
 L  R2482   
 L  R2483   
 L  R2484   
 L  R2485   
 L  R2486   
 L  R2487   
 L  R2488   
 L  R2489   
 L  R2490   
 L  R2491   
 L  R2492   
 L  R2493   
 L  R2494   
 L  R2495   
 L  R2496   
 L  R2497   
 L  R2498   
 L  R2499   
 L  R2500   
 L  R2501   
 L  R2502   
 L  R2503   
 L  R2504   
 L  R2505   
 L  R2506   
 L  R2507   
 L  R2508   
 L  R2509   
 L  R2510   
 L  R2511   
 L  R2512   
 L  R2513   
 L  R2514   
 L  R2515   
 L  R2516   
 L  R2517   
 L  R2518   
 L  R2519   
 L  R2520   
 L  R2521   
 L  R2522   
 L  R2523   
 L  R2524   
 L  R2525   
 L  R2526   
 L  R2527   
 L  R2528   
 L  R2529   
 L  R2530   
 L  R2531   
 L  R2532   
 L  R2533   
 L  R2534   
 L  R2535   
 L  R2536   
 L  R2537   
 L  R2538   
 L  R2539   
 L  R2540   
 L  R2541   
 L  R2542   
 L  R2543   
 L  R2544   
 L  R2545   
 L  R2546   
 L  R2547   
 L  R2548   
 L  R2549   
 L  R2550   
 L  R2551   
 L  R2552   
 L  R2553   
 L  R2554   
 L  R2555   
 L  R2556   
 L  R2557   
 L  R2558   
 L  R2559   
 L  R2560   
 L  R2561   
 L  R2562   
 L  R2563   
 L  R2564   
 L  R2565   
 L  R2566   
 L  R2567   
 L  R2568   
 L  R2569   
 L  R2570   
 L  R2571   
 L  R2572   
 L  R2573   
 L  R2574   
 L  R2575   
 L  R2576   
 L  R2577   
 L  R2578   
 L  R2579   
 L  R2580   
 L  R2581   
 L  R2582   
 L  R2583   
 L  R2584   
 L  R2585   
 L  R2586   
 L  R2587   
 L  R2588   
 L  R2589   
 L  R2590   
 L  R2591   
 L  R2592   
 L  qc0     
 L  qc1     
 L  qc2     
 L  qc3     
 L  qc4     
 L  qc5     
 L  qc6     
 L  qc7     
 L  qc8     
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    phi[0,1]  R0        1
    phi[0,1]  R1        1
    phi[0,1]  R9        -1
    phi[0,1]  R83       -3.0999999046325684e+00
    phi[0,1]  R84       -3.0999999046325684e+00
    phi[0,1]  R85       -2.2400000095367432e+00
    phi[0,1]  R86       -2.2400000095367432e+00
    phi[0,1]  R87       -3.0999999046325684e+00
    phi[0,1]  R88       -3.0999999046325684e+00
    phi[0,1]  R89       -2.5699999332427979e+00
    phi[0,1]  R90       -2.5699999332427979e+00
    phi[0,1]  R91       -3.0999999046325684e+00
    phi[0,1]  R92       -3.0999999046325684e+00
    phi[0,1]  R93       -2.0899999141693115e+00
    phi[0,1]  R94       -2.0899999141693115e+00
    phi[0,1]  R95       -3.0999999046325684e+00
    phi[0,1]  R96       -3.0999999046325684e+00
    phi[0,1]  R97       -0.4240702688694
    phi[0,1]  R98       6.6153579950332642e-01
    phi[0,1]  R99       -1.3491789996623993e-01
    phi[0,1]  R100      2.9384616017341614e-01
    phi[0,1]  R101      -3.9372497797012329e-01
    phi[0,1]  R102      -2.6731973886489868e-01
    phi[0,1]  R103      2.9273882508277893e-01
    phi[0,1]  R104      -7.8403866291046143e-01
    phi[0,1]  R105      4.0521270036697388e-01
    phi[0,1]  R106      -3.5998225212097168e-01
    phi[0,1]  R107      -2.0863642692565918e+00
    phi[0,1]  R108      -1.6222096681594849e+00
    phi[0,1]  R109      -2.3564805984497070e+00
    phi[0,1]  R110      -4.2049026489257812e+00
    phi[0,1]  R111      -1.0847880840301514e+00
    phi[0,1]  R112      -2.17056941986084
    phi[0,1]  R113      -2.2468962669372559e+00
    phi[0,1]  R114      -2.3884806632995605e+00
    phi[0,1]  R115      -1.2970192432403564e+00
    phi[0,1]  R116      -2.4647698402404785e+00
    phi[0,1]  R117      -2.5107848644256592e+00
    phi[0,1]  R118      -0.690426230430603
    phi[0,1]  R119      -9.9119603633880615e-01
    phi[0,1]  R120      -1.9318851828575134e-01
    phi[0,1]  R121      -2.2163357734680176e+00
    phi[0,1]  R122      -1.7683160305023193e+00
    phi[0,1]  R123      4.8776909708976746e-02
    phi[0,1]  R124      5.8209180831909180e-01
    phi[0,1]  R125      -2.6602504253387451e+00
    phi[0,1]  R126      2.3497502505779266e-01
    phi[0,1]  R127      -3.2753286361694336e+00
    phi[0,1]  R128      2.0645561814308167e-01
    phi[0,1]  R129      6.4001697301864624e-01
    phi[0,1]  R130      -1.4461884498596191e+00
    phi[0,1]  R131      -5.9192639589309692e-01
    phi[0,1]  R132      -1.1475696563720703e+00
    phi[0,1]  R133      1.2728528678417206e-01
    phi[0,1]  R134      -2.7334959506988525e+00
    phi[0,1]  R135      -3.0091910362243652e+00
    phi[0,1]  R136      -2.9272246360778809e-01
    phi[0,1]  R137      -1.3343344628810883e-01
    phi[0,1]  R138      -3.4742107391357422e+00
    phi[0,1]  R139      -2.2067341804504395e+00
    phi[0,1]  R140      -1.2132862806320190e+00
    phi[0,1]  R141      -2.1193292140960693e+00
    phi[0,1]  R142      -1.1394171714782715e+00
    phi[0,1]  R143      -4.3886408209800720e-02
    phi[0,1]  R144      -3.4070520401000977e+00
    phi[0,1]  R145      -1.3779661655426025e+00
    phi[0,1]  R146      -7.5067740678787231e-01
    phi[0,1]  R147      -3.4303982257843018e+00
    phi[0,1]  R148      -0.0756235346198082
    phi[0,1]  R149      -2.4023869037628174e+00
    phi[0,1]  R150      -1.7044686079025269e+00
    phi[0,1]  R151      -3.1332224607467651e-01
    phi[0,1]  R152      3.2559120655059814e-01
    phi[0,1]  R153      0.0648997351527214
    phi[0,1]  R154      -1.6494381427764893e-01
    phi[0,1]  R155      -1.0343431234359741e+00
    phi[0,1]  R156      -7.6765781641006470e-01
    phi[0,1]  R157      -2.9577488899230957e+00
    phi[0,1]  R158      -1.5295355319976807e+00
    phi[0,1]  R159      -5.6525832414627075e-01
    phi[0,1]  R160      -1.3763512670993805e-01
    phi[0,1]  R161      -5.5512273311614990e-01
    phi[0,1]  R162      -1.0128374099731445e+00
    phi[0,1]  R163      -8.2837420701980591e-01
    phi[0,1]  R164      -4.6307936310768127e-01
    phi[0,1]  R165      -7.3481388390064240e-02
    phi[0,1]  R166      5.5564498901367188e-01
    phi[0,1]  R167      -1.0861157178878784e+00
    phi[0,1]  R168      1.1526048183441162e+00
    phi[0,1]  R169      -1.2355302572250366e+00
    phi[0,1]  R170      2.5177463889122009e-01
    phi[0,1]  R171      -1.8156976997852325e-01
    phi[0,1]  R172      -7.2904616594314575e-01
    phi[0,1]  R173      2.0473327487707138e-02
    phi[0,1]  R174      -2.4310295283794403e-01
    phi[0,1]  R175      1.1453621089458466e-01
    phi[0,1]  R176      2.0463159680366516e-01
    phi[0,1]  R177      8.9171510934829712e-01
    phi[0,1]  R178      -9.3918049335479736e-01
    phi[0,1]  R179      -8.7406319379806519e-01
    phi[0,1]  R180      -1.0129086971282959e+00
    phi[0,1]  R181      8.1086955964565277e-02
    phi[0,1]  R182      -5.9381479024887085e-01
    phi[0,1]  R183      -1.0927327871322632e+00
    phi[0,1]  R184      -6.7967575788497925e-01
    phi[0,1]  R185      -9.7839570045471191e-01
    phi[0,1]  R186      -2.0007036626338959e-01
    phi[0,1]  R187      -6.2148696184158325e-01
    phi[0,1]  R188      -3.5633218288421631e-01
    phi[1,0]  R0        -1
    phi[1,0]  R9        1
    phi[1,0]  R10       1
    phi[1,0]  R189      -3.0999999046325684e+00
    phi[1,0]  R190      -3.0999999046325684e+00
    phi[1,0]  R191      -2.2400000095367432e+00
    phi[1,0]  R192      -2.2400000095367432e+00
    phi[1,0]  R193      -3.0999999046325684e+00
    phi[1,0]  R194      -3.0999999046325684e+00
    phi[1,0]  R195      -2.5699999332427979e+00
    phi[1,0]  R196      -2.5699999332427979e+00
    phi[1,0]  R197      -3.0999999046325684e+00
    phi[1,0]  R198      -3.0999999046325684e+00
    phi[1,0]  R199      -2.0899999141693115e+00
    phi[1,0]  R200      -2.0899999141693115e+00
    phi[1,0]  R201      -3.0999999046325684e+00
    phi[1,0]  R202      -3.0999999046325684e+00
    phi[1,0]  R203      -1.0861157178878784e+00
    phi[1,0]  R204      1.1526048183441162e+00
    phi[1,0]  R205      -1.2355302572250366e+00
    phi[1,0]  R206      2.5177463889122009e-01
    phi[1,0]  R207      -1.8156976997852325e-01
    phi[1,0]  R208      -7.2904616594314575e-01
    phi[1,0]  R209      2.0473327487707138e-02
    phi[1,0]  R210      -2.4310295283794403e-01
    phi[1,0]  R211      1.1453621089458466e-01
    phi[1,0]  R212      2.0463159680366516e-01
    phi[1,0]  R213      8.9171510934829712e-01
    phi[1,0]  R214      -9.3918049335479736e-01
    phi[1,0]  R215      -8.7406319379806519e-01
    phi[1,0]  R216      -1.0129086971282959e+00
    phi[1,0]  R217      8.1086955964565277e-02
    phi[1,0]  R218      -5.9381479024887085e-01
    phi[1,0]  R219      -1.0927327871322632e+00
    phi[1,0]  R220      -6.7967575788497925e-01
    phi[1,0]  R221      -9.7839570045471191e-01
    phi[1,0]  R222      -2.0007036626338959e-01
    phi[1,0]  R223      -6.2148696184158325e-01
    phi[1,0]  R224      -3.5633218288421631e-01
    phi[1,0]  R225      -0.4240702688694
    phi[1,0]  R226      6.6153579950332642e-01
    phi[1,0]  R227      -1.3491789996623993e-01
    phi[1,0]  R228      2.9384616017341614e-01
    phi[1,0]  R229      -3.9372497797012329e-01
    phi[1,0]  R230      -2.6731973886489868e-01
    phi[1,0]  R231      2.9273882508277893e-01
    phi[1,0]  R232      -7.8403866291046143e-01
    phi[1,0]  R233      4.0521270036697388e-01
    phi[1,0]  R234      -3.5998225212097168e-01
    phi[1,0]  R235      -2.0863642692565918e+00
    phi[1,0]  R236      -1.6222096681594849e+00
    phi[1,0]  R237      -2.3564805984497070e+00
    phi[1,0]  R238      -4.2049026489257812e+00
    phi[1,0]  R239      -1.0847880840301514e+00
    phi[1,0]  R240      -2.17056941986084
    phi[1,0]  R241      -2.2468962669372559e+00
    phi[1,0]  R242      -2.3884806632995605e+00
    phi[1,0]  R243      -1.2970192432403564e+00
    phi[1,0]  R244      -2.4647698402404785e+00
    phi[1,0]  R245      -2.5107848644256592e+00
    phi[1,0]  R246      -0.690426230430603
    phi[1,0]  R247      -9.9119603633880615e-01
    phi[1,0]  R248      -1.9318851828575134e-01
    phi[1,0]  R249      -2.2163357734680176e+00
    phi[1,0]  R250      -1.7683160305023193e+00
    phi[1,0]  R251      4.8776909708976746e-02
    phi[1,0]  R252      5.8209180831909180e-01
    phi[1,0]  R253      -2.6602504253387451e+00
    phi[1,0]  R254      2.3497502505779266e-01
    phi[1,0]  R255      -3.2753286361694336e+00
    phi[1,0]  R256      2.0645561814308167e-01
    phi[1,0]  R257      6.4001697301864624e-01
    phi[1,0]  R258      -1.4461884498596191e+00
    phi[1,0]  R259      -5.9192639589309692e-01
    phi[1,0]  R260      -1.1475696563720703e+00
    phi[1,0]  R261      1.2728528678417206e-01
    phi[1,0]  R262      -2.7334959506988525e+00
    phi[1,0]  R263      -3.0091910362243652e+00
    phi[1,0]  R264      -2.9272246360778809e-01
    phi[1,0]  R265      -1.3343344628810883e-01
    phi[1,0]  R266      -3.4742107391357422e+00
    phi[1,0]  R267      -2.2067341804504395e+00
    phi[1,0]  R268      -1.2132862806320190e+00
    phi[1,0]  R269      -2.1193292140960693e+00
    phi[1,0]  R270      -1.1394171714782715e+00
    phi[1,0]  R271      -4.3886408209800720e-02
    phi[1,0]  R272      -3.4070520401000977e+00
    phi[1,0]  R273      -1.3779661655426025e+00
    phi[1,0]  R274      -7.5067740678787231e-01
    phi[1,0]  R275      -3.4303982257843018e+00
    phi[1,0]  R276      -0.0756235346198082
    phi[1,0]  R277      -2.4023869037628174e+00
    phi[1,0]  R278      -1.7044686079025269e+00
    phi[1,0]  R279      -3.1332224607467651e-01
    phi[1,0]  R280      3.2559120655059814e-01
    phi[1,0]  R281      0.0648997351527214
    phi[1,0]  R282      -1.6494381427764893e-01
    phi[1,0]  R283      -1.0343431234359741e+00
    phi[1,0]  R284      -7.6765781641006470e-01
    phi[1,0]  R285      -2.9577488899230957e+00
    phi[1,0]  R286      -1.5295355319976807e+00
    phi[1,0]  R287      -5.6525832414627075e-01
    phi[1,0]  R288      -1.3763512670993805e-01
    phi[1,0]  R289      -5.5512273311614990e-01
    phi[1,0]  R290      -1.0128374099731445e+00
    phi[1,0]  R291      -8.2837420701980591e-01
    phi[1,0]  R292      -4.6307936310768127e-01
    phi[1,0]  R293      -7.3481388390064240e-02
    phi[1,0]  R294      5.5564498901367188e-01
    phi[0,5]  R0        1
    phi[0,5]  R1        1
    phi[0,5]  R45       -1
    phi[0,5]  R295      -3.0999999046325684e+00
    phi[0,5]  R296      -3.0999999046325684e+00
    phi[0,5]  R297      -2.2400000095367432e+00
    phi[0,5]  R298      -2.2400000095367432e+00
    phi[0,5]  R299      -3.0999999046325684e+00
    phi[0,5]  R300      -3.0999999046325684e+00
    phi[0,5]  R301      -2.5699999332427979e+00
    phi[0,5]  R302      -2.5699999332427979e+00
    phi[0,5]  R303      -3.0999999046325684e+00
    phi[0,5]  R304      -3.0999999046325684e+00
    phi[0,5]  R305      -2.0899999141693115e+00
    phi[0,5]  R306      -2.0899999141693115e+00
    phi[0,5]  R307      -3.0999999046325684e+00
    phi[0,5]  R308      -3.0999999046325684e+00
    phi[0,5]  R309      -0.4240702688694
    phi[0,5]  R310      6.6153579950332642e-01
    phi[0,5]  R311      -1.3491789996623993e-01
    phi[0,5]  R312      2.9384616017341614e-01
    phi[0,5]  R313      -3.9372497797012329e-01
    phi[0,5]  R314      -2.6731973886489868e-01
    phi[0,5]  R315      2.9273882508277893e-01
    phi[0,5]  R316      -7.8403866291046143e-01
    phi[0,5]  R317      4.0521270036697388e-01
    phi[0,5]  R318      -3.5998225212097168e-01
    phi[0,5]  R319      -2.0863642692565918e+00
    phi[0,5]  R320      -1.6222096681594849e+00
    phi[0,5]  R321      -2.3564805984497070e+00
    phi[0,5]  R322      -4.2049026489257812e+00
    phi[0,5]  R323      -1.0847880840301514e+00
    phi[0,5]  R324      -2.17056941986084
    phi[0,5]  R325      -2.2468962669372559e+00
    phi[0,5]  R326      -2.3884806632995605e+00
    phi[0,5]  R327      -1.2970192432403564e+00
    phi[0,5]  R328      -2.4647698402404785e+00
    phi[0,5]  R329      -2.5107848644256592e+00
    phi[0,5]  R330      -0.690426230430603
    phi[0,5]  R331      -9.9119603633880615e-01
    phi[0,5]  R332      -1.9318851828575134e-01
    phi[0,5]  R333      -2.2163357734680176e+00
    phi[0,5]  R334      -1.7683160305023193e+00
    phi[0,5]  R335      4.8776909708976746e-02
    phi[0,5]  R336      5.8209180831909180e-01
    phi[0,5]  R337      -2.6602504253387451e+00
    phi[0,5]  R338      2.3497502505779266e-01
    phi[0,5]  R339      -3.2753286361694336e+00
    phi[0,5]  R340      2.0645561814308167e-01
    phi[0,5]  R341      6.4001697301864624e-01
    phi[0,5]  R342      -1.4461884498596191e+00
    phi[0,5]  R343      -5.9192639589309692e-01
    phi[0,5]  R344      -1.1475696563720703e+00
    phi[0,5]  R345      1.2728528678417206e-01
    phi[0,5]  R346      -2.7334959506988525e+00
    phi[0,5]  R347      -3.0091910362243652e+00
    phi[0,5]  R348      -2.9272246360778809e-01
    phi[0,5]  R349      -1.3343344628810883e-01
    phi[0,5]  R350      -3.4742107391357422e+00
    phi[0,5]  R351      -2.2067341804504395e+00
    phi[0,5]  R352      -1.2132862806320190e+00
    phi[0,5]  R353      -2.1193292140960693e+00
    phi[0,5]  R354      -1.1394171714782715e+00
    phi[0,5]  R355      -4.3886408209800720e-02
    phi[0,5]  R356      -3.4070520401000977e+00
    phi[0,5]  R357      -1.3779661655426025e+00
    phi[0,5]  R358      -7.5067740678787231e-01
    phi[0,5]  R359      -3.4303982257843018e+00
    phi[0,5]  R360      -0.0756235346198082
    phi[0,5]  R361      -2.4023869037628174e+00
    phi[0,5]  R362      -1.7044686079025269e+00
    phi[0,5]  R363      -3.1332224607467651e-01
    phi[0,5]  R364      3.2559120655059814e-01
    phi[0,5]  R365      0.0648997351527214
    phi[0,5]  R366      -1.6494381427764893e-01
    phi[0,5]  R367      -1.0343431234359741e+00
    phi[0,5]  R368      -7.6765781641006470e-01
    phi[0,5]  R369      -2.9577488899230957e+00
    phi[0,5]  R370      -1.5295355319976807e+00
    phi[0,5]  R371      -5.6525832414627075e-01
    phi[0,5]  R372      -1.3763512670993805e-01
    phi[0,5]  R373      -5.5512273311614990e-01
    phi[0,5]  R374      -1.0128374099731445e+00
    phi[0,5]  R375      -8.2837420701980591e-01
    phi[0,5]  R376      -4.6307936310768127e-01
    phi[0,5]  R377      -7.3481388390064240e-02
    phi[0,5]  R378      5.5564498901367188e-01
    phi[0,5]  R379      1.2125108242034912e+00
    phi[0,5]  R380      9.9890762567520142e-01
    phi[0,5]  R381      9.7437423467636108e-01
    phi[0,5]  R382      6.5576332807540894e-01
    phi[0,5]  R383      3.9197501540184021e-01
    phi[0,5]  R384      2.8208884596824646e-01
    phi[0,5]  R385      0.0126736955717206
    phi[0,5]  R386      -3.0393150448799133e-01
    phi[0,5]  R387      8.6660206317901611e-01
    phi[0,5]  R388      3.8977745175361633e-01
    phi[0,5]  R389      -2.1395599842071533e+00
    phi[0,5]  R390      -2.1722893714904785e+00
    phi[0,5]  R391      -1.9291379451751709e+00
    phi[0,5]  R392      -2.0921773910522461e+00
    phi[0,5]  R393      -2.0158741474151611e+00
    phi[0,5]  R394      -1.4781172275543213e+00
    phi[0,5]  R395      -1.4330282211303711e+00
    phi[0,5]  R396      -1.8183500766754150e+00
    phi[0,5]  R397      -3.2681903243064880e-01
    phi[0,5]  R398      -3.5767412185668945e-01
    phi[0,5]  R399      -2.1543724536895752e+00
    phi[0,5]  R400      -3.5427243709564209e+00
    phi[0,5]  R401      -2.2052223682403564e+00
    phi[0,5]  R402      -1.1267335414886475e+00
    phi[0,5]  R403      -1.4125297963619232e-01
    phi[0,5]  R404      0.0756712406873703
    phi[0,5]  R405      -3.2745990753173828e+00
    phi[0,5]  R406      -6.2932336330413818e-01
    phi[0,5]  R407      -1.0634574890136719e+00
    phi[0,5]  R408      -2.7822425365448
    phi[0,5]  R409      -3.4566419124603271e+00
    phi[0,5]  R410      -2.7836849689483643e+00
    phi[0,5]  R411      -4.7147005796432495e-01
    phi[0,5]  R412      0.595619261264801
    phi[0,5]  R413      -2.5354957580566406e+00
    phi[0,5]  R414      -2.5732421875
    phi[0,5]  R415      -9.6966528892517090e-01
    phi[0,5]  R416      -2.8140428066253662e+00
    phi[0,5]  R417      -2.6507823467254639e+00
    phi[0,5]  R418      2.0488311350345612e-01
    phi[0,5]  R419      -2.4206931591033936e+00
    phi[0,5]  R420      -8.7608367204666138e-01
    phi[0,5]  R421      -1.6060967445373535e+00
    phi[0,5]  R422      -3.2308812141418457e+00
    phi[0,5]  R423      -2.9620583057403564e+00
    phi[0,5]  R424      -3.5245752334594727e+00
    phi[0,5]  R425      -1.4354897737503052e+00
    phi[0,5]  R426      -8.6167180538177490e-01
    phi[0,5]  R427      -9.7583532333374023e-01
    phi[0,5]  R428      -9.5061224699020386e-01
    phi[0,5]  R429      -2.1341443061828613e+00
    phi[0,5]  R430      -3.0988757610321045e+00
    phi[0,5]  R431      -2.2457747459411621e+00
    phi[0,5]  R432      -2.9366893768310547e+00
    phi[0,5]  R433      -1.7260627746582031e+00
    phi[0,5]  R434      -4.4440007209777832e-01
    phi[0,5]  R435      -2.5723896026611328e+00
    phi[0,5]  R436      1.1159946918487549e+00
    phi[0,5]  R437      -3.6518317461013794e-01
    phi[0,5]  R438      5.7520985603332520e-01
    phi[0,5]  R439      8.6210870742797852e-01
    phi[0,5]  R440      -1.4903119802474976e+00
    phi[0,5]  R441      8.9394539594650269e-01
    phi[0,5]  R442      3.5091492533683777e-01
    phi[0,5]  R443      -4.9056446552276611e-01
    phi[0,5]  R444      1.4721024036407471e-01
    phi[0,5]  R445      9.3350701034069061e-02
    phi[0,5]  R446      -1.8771171569824219e-01
    phi[0,5]  R447      2.3729684948921204e-01
    phi[0,5]  R448      -6.5057724714279175e-01
    phi[0,5]  R449      -3.6815056204795837e-01
    phi[0,5]  R450      -2.7272257804870605e+00
    phi[0,5]  R451      -2.5189876556396484e+00
    phi[0,5]  R452      -1.6673209667205811e+00
    phi[0,5]  R453      -1.9247124195098877e+00
    phi[0,5]  R454      -1.3213683366775513e+00
    phi[0,5]  R455      -6.4024627208709717e-01
    phi[0,5]  R456      1.2808494567871094e+00
    phi[0,5]  R457      -1.5049009323120117e+00
    phi[0,5]  R458      8.5438799858093262e-01
    phi[5,0]  R0        -1
    phi[5,0]  R45       1
    phi[5,0]  R46       1
    phi[5,0]  R459      -3.0999999046325684e+00
    phi[5,0]  R460      -3.0999999046325684e+00
    phi[5,0]  R461      -2.2400000095367432e+00
    phi[5,0]  R462      -2.2400000095367432e+00
    phi[5,0]  R463      -3.0999999046325684e+00
    phi[5,0]  R464      -3.0999999046325684e+00
    phi[5,0]  R465      -2.5699999332427979e+00
    phi[5,0]  R466      -2.5699999332427979e+00
    phi[5,0]  R467      -3.0999999046325684e+00
    phi[5,0]  R468      -3.0999999046325684e+00
    phi[5,0]  R469      -2.0899999141693115e+00
    phi[5,0]  R470      -2.0899999141693115e+00
    phi[5,0]  R471      -3.0999999046325684e+00
    phi[5,0]  R472      -3.0999999046325684e+00
    phi[5,0]  R473      1.2125108242034912e+00
    phi[5,0]  R474      9.9890762567520142e-01
    phi[5,0]  R475      9.7437423467636108e-01
    phi[5,0]  R476      6.5576332807540894e-01
    phi[5,0]  R477      3.9197501540184021e-01
    phi[5,0]  R478      2.8208884596824646e-01
    phi[5,0]  R479      0.0126736955717206
    phi[5,0]  R480      -3.0393150448799133e-01
    phi[5,0]  R481      8.6660206317901611e-01
    phi[5,0]  R482      3.8977745175361633e-01
    phi[5,0]  R483      -2.1395599842071533e+00
    phi[5,0]  R484      -2.1722893714904785e+00
    phi[5,0]  R485      -1.9291379451751709e+00
    phi[5,0]  R486      -2.0921773910522461e+00
    phi[5,0]  R487      -2.0158741474151611e+00
    phi[5,0]  R488      -1.4781172275543213e+00
    phi[5,0]  R489      -1.4330282211303711e+00
    phi[5,0]  R490      -1.8183500766754150e+00
    phi[5,0]  R491      -3.2681903243064880e-01
    phi[5,0]  R492      -3.5767412185668945e-01
    phi[5,0]  R493      -2.1543724536895752e+00
    phi[5,0]  R494      -3.5427243709564209e+00
    phi[5,0]  R495      -2.2052223682403564e+00
    phi[5,0]  R496      -1.1267335414886475e+00
    phi[5,0]  R497      -1.4125297963619232e-01
    phi[5,0]  R498      0.0756712406873703
    phi[5,0]  R499      -3.2745990753173828e+00
    phi[5,0]  R500      -6.2932336330413818e-01
    phi[5,0]  R501      -1.0634574890136719e+00
    phi[5,0]  R502      -2.7822425365448
    phi[5,0]  R503      -3.4566419124603271e+00
    phi[5,0]  R504      -2.7836849689483643e+00
    phi[5,0]  R505      -4.7147005796432495e-01
    phi[5,0]  R506      0.595619261264801
    phi[5,0]  R507      -2.5354957580566406e+00
    phi[5,0]  R508      -2.5732421875
    phi[5,0]  R509      -9.6966528892517090e-01
    phi[5,0]  R510      -2.8140428066253662e+00
    phi[5,0]  R511      -2.6507823467254639e+00
    phi[5,0]  R512      2.0488311350345612e-01
    phi[5,0]  R513      -2.4206931591033936e+00
    phi[5,0]  R514      -8.7608367204666138e-01
    phi[5,0]  R515      -1.6060967445373535e+00
    phi[5,0]  R516      -3.2308812141418457e+00
    phi[5,0]  R517      -2.9620583057403564e+00
    phi[5,0]  R518      -3.5245752334594727e+00
    phi[5,0]  R519      -1.4354897737503052e+00
    phi[5,0]  R520      -8.6167180538177490e-01
    phi[5,0]  R521      -9.7583532333374023e-01
    phi[5,0]  R522      -9.5061224699020386e-01
    phi[5,0]  R523      -2.1341443061828613e+00
    phi[5,0]  R524      -3.0988757610321045e+00
    phi[5,0]  R525      -2.2457747459411621e+00
    phi[5,0]  R526      -2.9366893768310547e+00
    phi[5,0]  R527      -1.7260627746582031e+00
    phi[5,0]  R528      -4.4440007209777832e-01
    phi[5,0]  R529      -2.5723896026611328e+00
    phi[5,0]  R530      1.1159946918487549e+00
    phi[5,0]  R531      -3.6518317461013794e-01
    phi[5,0]  R532      5.7520985603332520e-01
    phi[5,0]  R533      8.6210870742797852e-01
    phi[5,0]  R534      -1.4903119802474976e+00
    phi[5,0]  R535      8.9394539594650269e-01
    phi[5,0]  R536      3.5091492533683777e-01
    phi[5,0]  R537      -4.9056446552276611e-01
    phi[5,0]  R538      1.4721024036407471e-01
    phi[5,0]  R539      9.3350701034069061e-02
    phi[5,0]  R540      -1.8771171569824219e-01
    phi[5,0]  R541      2.3729684948921204e-01
    phi[5,0]  R542      -6.5057724714279175e-01
    phi[5,0]  R543      -3.6815056204795837e-01
    phi[5,0]  R544      -2.7272257804870605e+00
    phi[5,0]  R545      -2.5189876556396484e+00
    phi[5,0]  R546      -1.6673209667205811e+00
    phi[5,0]  R547      -1.9247124195098877e+00
    phi[5,0]  R548      -1.3213683366775513e+00
    phi[5,0]  R549      -6.4024627208709717e-01
    phi[5,0]  R550      1.2808494567871094e+00
    phi[5,0]  R551      -1.5049009323120117e+00
    phi[5,0]  R552      8.5438799858093262e-01
    phi[5,0]  R553      -0.4240702688694
    phi[5,0]  R554      6.6153579950332642e-01
    phi[5,0]  R555      -1.3491789996623993e-01
    phi[5,0]  R556      2.9384616017341614e-01
    phi[5,0]  R557      -3.9372497797012329e-01
    phi[5,0]  R558      -2.6731973886489868e-01
    phi[5,0]  R559      2.9273882508277893e-01
    phi[5,0]  R560      -7.8403866291046143e-01
    phi[5,0]  R561      4.0521270036697388e-01
    phi[5,0]  R562      -3.5998225212097168e-01
    phi[5,0]  R563      -2.0863642692565918e+00
    phi[5,0]  R564      -1.6222096681594849e+00
    phi[5,0]  R565      -2.3564805984497070e+00
    phi[5,0]  R566      -4.2049026489257812e+00
    phi[5,0]  R567      -1.0847880840301514e+00
    phi[5,0]  R568      -2.17056941986084
    phi[5,0]  R569      -2.2468962669372559e+00
    phi[5,0]  R570      -2.3884806632995605e+00
    phi[5,0]  R571      -1.2970192432403564e+00
    phi[5,0]  R572      -2.4647698402404785e+00
    phi[5,0]  R573      -2.5107848644256592e+00
    phi[5,0]  R574      -0.690426230430603
    phi[5,0]  R575      -9.9119603633880615e-01
    phi[5,0]  R576      -1.9318851828575134e-01
    phi[5,0]  R577      -2.2163357734680176e+00
    phi[5,0]  R578      -1.7683160305023193e+00
    phi[5,0]  R579      4.8776909708976746e-02
    phi[5,0]  R580      5.8209180831909180e-01
    phi[5,0]  R581      -2.6602504253387451e+00
    phi[5,0]  R582      2.3497502505779266e-01
    phi[5,0]  R583      -3.2753286361694336e+00
    phi[5,0]  R584      2.0645561814308167e-01
    phi[5,0]  R585      6.4001697301864624e-01
    phi[5,0]  R586      -1.4461884498596191e+00
    phi[5,0]  R587      -5.9192639589309692e-01
    phi[5,0]  R588      -1.1475696563720703e+00
    phi[5,0]  R589      1.2728528678417206e-01
    phi[5,0]  R590      -2.7334959506988525e+00
    phi[5,0]  R591      -3.0091910362243652e+00
    phi[5,0]  R592      -2.9272246360778809e-01
    phi[5,0]  R593      -1.3343344628810883e-01
    phi[5,0]  R594      -3.4742107391357422e+00
    phi[5,0]  R595      -2.2067341804504395e+00
    phi[5,0]  R596      -1.2132862806320190e+00
    phi[5,0]  R597      -2.1193292140960693e+00
    phi[5,0]  R598      -1.1394171714782715e+00
    phi[5,0]  R599      -4.3886408209800720e-02
    phi[5,0]  R600      -3.4070520401000977e+00
    phi[5,0]  R601      -1.3779661655426025e+00
    phi[5,0]  R602      -7.5067740678787231e-01
    phi[5,0]  R603      -3.4303982257843018e+00
    phi[5,0]  R604      -0.0756235346198082
    phi[5,0]  R605      -2.4023869037628174e+00
    phi[5,0]  R606      -1.7044686079025269e+00
    phi[5,0]  R607      -3.1332224607467651e-01
    phi[5,0]  R608      3.2559120655059814e-01
    phi[5,0]  R609      0.0648997351527214
    phi[5,0]  R610      -1.6494381427764893e-01
    phi[5,0]  R611      -1.0343431234359741e+00
    phi[5,0]  R612      -7.6765781641006470e-01
    phi[5,0]  R613      -2.9577488899230957e+00
    phi[5,0]  R614      -1.5295355319976807e+00
    phi[5,0]  R615      -5.6525832414627075e-01
    phi[5,0]  R616      -1.3763512670993805e-01
    phi[5,0]  R617      -5.5512273311614990e-01
    phi[5,0]  R618      -1.0128374099731445e+00
    phi[5,0]  R619      -8.2837420701980591e-01
    phi[5,0]  R620      -4.6307936310768127e-01
    phi[5,0]  R621      -7.3481388390064240e-02
    phi[5,0]  R622      5.5564498901367188e-01
    phi[0,6]  R0        1
    phi[0,6]  R1        1
    phi[0,6]  R54       -1
    phi[0,6]  R623      -3.0999999046325684e+00
    phi[0,6]  R624      -3.0999999046325684e+00
    phi[0,6]  R625      -2.2400000095367432e+00
    phi[0,6]  R626      -2.2400000095367432e+00
    phi[0,6]  R627      -3.0999999046325684e+00
    phi[0,6]  R628      -3.0999999046325684e+00
    phi[0,6]  R629      -2.5699999332427979e+00
    phi[0,6]  R630      -2.5699999332427979e+00
    phi[0,6]  R631      -3.0999999046325684e+00
    phi[0,6]  R632      -3.0999999046325684e+00
    phi[0,6]  R633      -2.0899999141693115e+00
    phi[0,6]  R634      -2.0899999141693115e+00
    phi[0,6]  R635      -3.0999999046325684e+00
    phi[0,6]  R636      -3.0999999046325684e+00
    phi[0,6]  R637      -0.4240702688694
    phi[0,6]  R638      6.6153579950332642e-01
    phi[0,6]  R639      -1.3491789996623993e-01
    phi[0,6]  R640      2.9384616017341614e-01
    phi[0,6]  R641      -3.9372497797012329e-01
    phi[0,6]  R642      -2.6731973886489868e-01
    phi[0,6]  R643      2.9273882508277893e-01
    phi[0,6]  R644      -7.8403866291046143e-01
    phi[0,6]  R645      4.0521270036697388e-01
    phi[0,6]  R646      -3.5998225212097168e-01
    phi[0,6]  R647      -2.0863642692565918e+00
    phi[0,6]  R648      -1.6222096681594849e+00
    phi[0,6]  R649      -2.3564805984497070e+00
    phi[0,6]  R650      -4.2049026489257812e+00
    phi[0,6]  R651      -1.0847880840301514e+00
    phi[0,6]  R652      -2.17056941986084
    phi[0,6]  R653      -2.2468962669372559e+00
    phi[0,6]  R654      -2.3884806632995605e+00
    phi[0,6]  R655      -1.2970192432403564e+00
    phi[0,6]  R656      -2.4647698402404785e+00
    phi[0,6]  R657      -2.5107848644256592e+00
    phi[0,6]  R658      -0.690426230430603
    phi[0,6]  R659      -9.9119603633880615e-01
    phi[0,6]  R660      -1.9318851828575134e-01
    phi[0,6]  R661      -2.2163357734680176e+00
    phi[0,6]  R662      -1.7683160305023193e+00
    phi[0,6]  R663      4.8776909708976746e-02
    phi[0,6]  R664      5.8209180831909180e-01
    phi[0,6]  R665      -2.6602504253387451e+00
    phi[0,6]  R666      2.3497502505779266e-01
    phi[0,6]  R667      -3.2753286361694336e+00
    phi[0,6]  R668      2.0645561814308167e-01
    phi[0,6]  R669      6.4001697301864624e-01
    phi[0,6]  R670      -1.4461884498596191e+00
    phi[0,6]  R671      -5.9192639589309692e-01
    phi[0,6]  R672      -1.1475696563720703e+00
    phi[0,6]  R673      1.2728528678417206e-01
    phi[0,6]  R674      -2.7334959506988525e+00
    phi[0,6]  R675      -3.0091910362243652e+00
    phi[0,6]  R676      -2.9272246360778809e-01
    phi[0,6]  R677      -1.3343344628810883e-01
    phi[0,6]  R678      -3.4742107391357422e+00
    phi[0,6]  R679      -2.2067341804504395e+00
    phi[0,6]  R680      -1.2132862806320190e+00
    phi[0,6]  R681      -2.1193292140960693e+00
    phi[0,6]  R682      -1.1394171714782715e+00
    phi[0,6]  R683      -4.3886408209800720e-02
    phi[0,6]  R684      -3.4070520401000977e+00
    phi[0,6]  R685      -1.3779661655426025e+00
    phi[0,6]  R686      -7.5067740678787231e-01
    phi[0,6]  R687      -3.4303982257843018e+00
    phi[0,6]  R688      -0.0756235346198082
    phi[0,6]  R689      -2.4023869037628174e+00
    phi[0,6]  R690      -1.7044686079025269e+00
    phi[0,6]  R691      -3.1332224607467651e-01
    phi[0,6]  R692      3.2559120655059814e-01
    phi[0,6]  R693      0.0648997351527214
    phi[0,6]  R694      -1.6494381427764893e-01
    phi[0,6]  R695      -1.0343431234359741e+00
    phi[0,6]  R696      -7.6765781641006470e-01
    phi[0,6]  R697      -2.9577488899230957e+00
    phi[0,6]  R698      -1.5295355319976807e+00
    phi[0,6]  R699      -5.6525832414627075e-01
    phi[0,6]  R700      -1.3763512670993805e-01
    phi[0,6]  R701      -5.5512273311614990e-01
    phi[0,6]  R702      -1.0128374099731445e+00
    phi[0,6]  R703      -8.2837420701980591e-01
    phi[0,6]  R704      -4.6307936310768127e-01
    phi[0,6]  R705      -7.3481388390064240e-02
    phi[0,6]  R706      5.5564498901367188e-01
    phi[0,6]  R707      -1.4293605089187622e-01
    phi[0,6]  R708      0.553049623966217
    phi[0,6]  R709      1.1266770362854004e+00
    phi[0,6]  R710      1.6760075092315674e-01
    phi[0,6]  R711      4.6413907408714294e-01
    phi[0,6]  R712      -1.8053968250751495e-01
    phi[0,6]  R713      4.1994491219520569e-01
    phi[0,6]  R714      6.4365035295486450e-01
    phi[0,6]  R715      -1.9188141822814941e-01
    phi[0,6]  R716      -6.5301024913787842e-01
    phi[0,6]  R717      -1.2399380207061768e+00
    phi[0,6]  R718      -1.0212239027023315e+00
    phi[0,6]  R719      -9.9627912044525146e-01
    phi[0,6]  R720      -2.9817917943000793e-01
    phi[0,6]  R721      -1.1890790462493896e+00
    phi[0,6]  R722      -1.0353883504867554e+00
    phi[0,6]  R723      -1.6944911479949951e+00
    phi[0,6]  R724      -2.5192213058471680e-01
    phi[0,6]  R725      -1.2882683277130127e+00
    phi[0,6]  R726      2.0499148964881897e-01
    phi[0,6]  R727      -1.97946035861969
    phi[0,6]  R728      -1.1973530054092407e+00
    phi[0,6]  R729      -1.9490445852279663e+00
    phi[0,6]  R730      -1.8847961425781250e+00
    phi[0,6]  R731      -1.6401908397674561e+00
    phi[0,6]  R732      -4.8259460926055908e-01
    phi[0,6]  R733      -1.9464302062988281e+00
    phi[0,6]  R734      -6.6192144155502319e-01
    phi[0,6]  R735      -1.6733224391937256e+00
    phi[0,6]  R736      -2.5008649826049805e+00
    phi[0,6]  R737      5.6668169796466827e-02
    phi[0,6]  R738      -2.6952922344207764e+00
    phi[0,6]  R739      -1.7582894563674927e+00
    phi[0,6]  R740      -3.5733222961425781e-01
    phi[0,6]  R741      -2.2754781246185303e+00
    phi[0,6]  R742      -1.9918773174285889e+00
    phi[0,6]  R743      -1.9334779679775238e-01
    phi[0,6]  R744      -2.2467851638793945e+00
    phi[0,6]  R745      -1.6339864730834961e+00
    phi[0,6]  R746      -1.4262858629226685e+00
    phi[0,6]  R747      -1.5026762485504150e+00
    phi[0,6]  R748      -2.2523403167724609e+00
    phi[0,6]  R749      -1.2047789096832275e+00
    phi[0,6]  R750      5.5270552635192871e-01
    phi[0,6]  R751      -2.3119783401489258e+00
    phi[0,6]  R752      -2.9652902483940125e-01
    phi[0,6]  R753      -2.08590030670166
    phi[0,6]  R754      -1.1205933094024658e+00
    phi[0,6]  R755      -1.2098271846771240e+00
    phi[0,6]  R756      -8.8161420822143555e-01
    phi[0,6]  R757      3.8365300744771957e-02
    phi[0,6]  R758      -8.0986231565475464e-01
    phi[0,6]  R759      -1.8443859815597534e+00
    phi[0,6]  R760      -1.0792300701141357e+00
    phi[0,6]  R761      -7.9451024532318115e-01
    phi[0,6]  R762      -1.9502327442169189e+00
    phi[0,6]  R763      -5.6438320875167847e-01
    phi[0,6]  R764      1.3592110574245453e-01
    phi[0,6]  R765      -4.2466154694557190e-01
    phi[0,6]  R766      -1.8536425828933716e+00
    phi[6,0]  R0        -1
    phi[6,0]  R54       1
    phi[6,0]  R55       1
    phi[6,0]  R767      -3.0999999046325684e+00
    phi[6,0]  R768      -3.0999999046325684e+00
    phi[6,0]  R769      -2.2400000095367432e+00
    phi[6,0]  R770      -2.2400000095367432e+00
    phi[6,0]  R771      -3.0999999046325684e+00
    phi[6,0]  R772      -3.0999999046325684e+00
    phi[6,0]  R773      -2.5699999332427979e+00
    phi[6,0]  R774      -2.5699999332427979e+00
    phi[6,0]  R775      -3.0999999046325684e+00
    phi[6,0]  R776      -3.0999999046325684e+00
    phi[6,0]  R777      -2.0899999141693115e+00
    phi[6,0]  R778      -2.0899999141693115e+00
    phi[6,0]  R779      -3.0999999046325684e+00
    phi[6,0]  R780      -3.0999999046325684e+00
    phi[6,0]  R781      -1.4293605089187622e-01
    phi[6,0]  R782      0.553049623966217
    phi[6,0]  R783      1.1266770362854004e+00
    phi[6,0]  R784      1.6760075092315674e-01
    phi[6,0]  R785      4.6413907408714294e-01
    phi[6,0]  R786      -1.8053968250751495e-01
    phi[6,0]  R787      4.1994491219520569e-01
    phi[6,0]  R788      6.4365035295486450e-01
    phi[6,0]  R789      -1.9188141822814941e-01
    phi[6,0]  R790      -6.5301024913787842e-01
    phi[6,0]  R791      -1.2399380207061768e+00
    phi[6,0]  R792      -1.0212239027023315e+00
    phi[6,0]  R793      -9.9627912044525146e-01
    phi[6,0]  R794      -2.9817917943000793e-01
    phi[6,0]  R795      -1.1890790462493896e+00
    phi[6,0]  R796      -1.0353883504867554e+00
    phi[6,0]  R797      -1.6944911479949951e+00
    phi[6,0]  R798      -2.5192213058471680e-01
    phi[6,0]  R799      -1.2882683277130127e+00
    phi[6,0]  R800      2.0499148964881897e-01
    phi[6,0]  R801      -1.97946035861969
    phi[6,0]  R802      -1.1973530054092407e+00
    phi[6,0]  R803      -1.9490445852279663e+00
    phi[6,0]  R804      -1.8847961425781250e+00
    phi[6,0]  R805      -1.6401908397674561e+00
    phi[6,0]  R806      -4.8259460926055908e-01
    phi[6,0]  R807      -1.9464302062988281e+00
    phi[6,0]  R808      -6.6192144155502319e-01
    phi[6,0]  R809      -1.6733224391937256e+00
    phi[6,0]  R810      -2.5008649826049805e+00
    phi[6,0]  R811      5.6668169796466827e-02
    phi[6,0]  R812      -2.6952922344207764e+00
    phi[6,0]  R813      -1.7582894563674927e+00
    phi[6,0]  R814      -3.5733222961425781e-01
    phi[6,0]  R815      -2.2754781246185303e+00
    phi[6,0]  R816      -1.9918773174285889e+00
    phi[6,0]  R817      -1.9334779679775238e-01
    phi[6,0]  R818      -2.2467851638793945e+00
    phi[6,0]  R819      -1.6339864730834961e+00
    phi[6,0]  R820      -1.4262858629226685e+00
    phi[6,0]  R821      -1.5026762485504150e+00
    phi[6,0]  R822      -2.2523403167724609e+00
    phi[6,0]  R823      -1.2047789096832275e+00
    phi[6,0]  R824      5.5270552635192871e-01
    phi[6,0]  R825      -2.3119783401489258e+00
    phi[6,0]  R826      -2.9652902483940125e-01
    phi[6,0]  R827      -2.08590030670166
    phi[6,0]  R828      -1.1205933094024658e+00
    phi[6,0]  R829      -1.2098271846771240e+00
    phi[6,0]  R830      -8.8161420822143555e-01
    phi[6,0]  R831      3.8365300744771957e-02
    phi[6,0]  R832      -8.0986231565475464e-01
    phi[6,0]  R833      -1.8443859815597534e+00
    phi[6,0]  R834      -1.0792300701141357e+00
    phi[6,0]  R835      -7.9451024532318115e-01
    phi[6,0]  R836      -1.9502327442169189e+00
    phi[6,0]  R837      -5.6438320875167847e-01
    phi[6,0]  R838      1.3592110574245453e-01
    phi[6,0]  R839      -4.2466154694557190e-01
    phi[6,0]  R840      -1.8536425828933716e+00
    phi[6,0]  R841      -0.4240702688694
    phi[6,0]  R842      6.6153579950332642e-01
    phi[6,0]  R843      -1.3491789996623993e-01
    phi[6,0]  R844      2.9384616017341614e-01
    phi[6,0]  R845      -3.9372497797012329e-01
    phi[6,0]  R846      -2.6731973886489868e-01
    phi[6,0]  R847      2.9273882508277893e-01
    phi[6,0]  R848      -7.8403866291046143e-01
    phi[6,0]  R849      4.0521270036697388e-01
    phi[6,0]  R850      -3.5998225212097168e-01
    phi[6,0]  R851      -2.0863642692565918e+00
    phi[6,0]  R852      -1.6222096681594849e+00
    phi[6,0]  R853      -2.3564805984497070e+00
    phi[6,0]  R854      -4.2049026489257812e+00
    phi[6,0]  R855      -1.0847880840301514e+00
    phi[6,0]  R856      -2.17056941986084
    phi[6,0]  R857      -2.2468962669372559e+00
    phi[6,0]  R858      -2.3884806632995605e+00
    phi[6,0]  R859      -1.2970192432403564e+00
    phi[6,0]  R860      -2.4647698402404785e+00
    phi[6,0]  R861      -2.5107848644256592e+00
    phi[6,0]  R862      -0.690426230430603
    phi[6,0]  R863      -9.9119603633880615e-01
    phi[6,0]  R864      -1.9318851828575134e-01
    phi[6,0]  R865      -2.2163357734680176e+00
    phi[6,0]  R866      -1.7683160305023193e+00
    phi[6,0]  R867      4.8776909708976746e-02
    phi[6,0]  R868      5.8209180831909180e-01
    phi[6,0]  R869      -2.6602504253387451e+00
    phi[6,0]  R870      2.3497502505779266e-01
    phi[6,0]  R871      -3.2753286361694336e+00
    phi[6,0]  R872      2.0645561814308167e-01
    phi[6,0]  R873      6.4001697301864624e-01
    phi[6,0]  R874      -1.4461884498596191e+00
    phi[6,0]  R875      -5.9192639589309692e-01
    phi[6,0]  R876      -1.1475696563720703e+00
    phi[6,0]  R877      1.2728528678417206e-01
    phi[6,0]  R878      -2.7334959506988525e+00
    phi[6,0]  R879      -3.0091910362243652e+00
    phi[6,0]  R880      -2.9272246360778809e-01
    phi[6,0]  R881      -1.3343344628810883e-01
    phi[6,0]  R882      -3.4742107391357422e+00
    phi[6,0]  R883      -2.2067341804504395e+00
    phi[6,0]  R884      -1.2132862806320190e+00
    phi[6,0]  R885      -2.1193292140960693e+00
    phi[6,0]  R886      -1.1394171714782715e+00
    phi[6,0]  R887      -4.3886408209800720e-02
    phi[6,0]  R888      -3.4070520401000977e+00
    phi[6,0]  R889      -1.3779661655426025e+00
    phi[6,0]  R890      -7.5067740678787231e-01
    phi[6,0]  R891      -3.4303982257843018e+00
    phi[6,0]  R892      -0.0756235346198082
    phi[6,0]  R893      -2.4023869037628174e+00
    phi[6,0]  R894      -1.7044686079025269e+00
    phi[6,0]  R895      -3.1332224607467651e-01
    phi[6,0]  R896      3.2559120655059814e-01
    phi[6,0]  R897      0.0648997351527214
    phi[6,0]  R898      -1.6494381427764893e-01
    phi[6,0]  R899      -1.0343431234359741e+00
    phi[6,0]  R900      -7.6765781641006470e-01
    phi[6,0]  R901      -2.9577488899230957e+00
    phi[6,0]  R902      -1.5295355319976807e+00
    phi[6,0]  R903      -5.6525832414627075e-01
    phi[6,0]  R904      -1.3763512670993805e-01
    phi[6,0]  R905      -5.5512273311614990e-01
    phi[6,0]  R906      -1.0128374099731445e+00
    phi[6,0]  R907      -8.2837420701980591e-01
    phi[6,0]  R908      -4.6307936310768127e-01
    phi[6,0]  R909      -7.3481388390064240e-02
    phi[6,0]  R910      5.5564498901367188e-01
    phi[9,0]  R0        -1
    phi[9,0]  R2        8.9151355193732673e-01
    phi[9,0]  R3        -1.9177123578251334e+00
    phi[9,0]  R4        2.1322907731828433e-01
    phi[9,0]  R5        1.9859976103431927e+00
    phi[9,0]  R6        2.9217173991106464e+00
    phi[9,0]  R7        -1.4770704335377525e+00
    phi[9,0]  R8        -1.6903897965958561e+00
    phi[9,0]  R81       1
    phi[9,0]  R911      -3.9915134565698951e+00
    phi[9,0]  R912      -2.2084863526952416e+00
    phi[9,0]  R913      -3.2228765171160978e-01
    phi[9,0]  R914      -4.1577123673618761e+00
    phi[9,0]  R915      -3.3132289819508527e+00
    phi[9,0]  R916      -2.8867708273142840e+00
    phi[9,0]  R917      -4.55599754358599
    phi[9,0]  R918      -5.8400232289960519e-01
    phi[9,0]  R919      -6.0217173037432143e+00
    phi[9,0]  R920      -1.7828250552192193e-01
    phi[9,0]  R921      -0.612929480631559
    phi[9,0]  R922      -3.5670703477070642e+00
    phi[9,0]  R923      -1.4096101080367123e+00
    phi[9,0]  R924      -4.7903897012284240e+00
    phi[9,0]  R925      -2.9041525901512111e-01
    phi[9,0]  R926      -3.5679519387067682e-01
    phi[9,0]  R927      -3.6952953301992120e-01
    phi[9,0]  R928      -0.369819497275762
    phi[9,0]  R929      -3.8092958796726617e-01
    phi[9,0]  R930      -4.0722988497611584e-01
    phi[9,0]  R931      -4.2130031243787980e-01
    phi[9,0]  R932      -9.5518178360296890e-01
    phi[9,0]  R933      -0.440747537782995
    phi[9,0]  R934      -1.8065469703502954e+00
    phi[9,0]  R935      -2.3990631331463330e-01
    phi[9,0]  R936      -2.4420190406272502e-01
    phi[9,0]  R937      -2.5418566274610388e-01
    phi[9,0]  R938      -2.6491669347912428e-01
    phi[9,0]  R939      -2.8624718758320422e-01
    phi[9,0]  R940      -3.2379489153807750e-01
    phi[9,0]  R941      -3.2395376141846333e-01
    phi[9,0]  R942      -3.3288287325309573e-01
    phi[9,0]  R943      -3.4148908401911682e-01
    phi[9,0]  R944      -3.4226259172558660e-01
    phi[9,0]  R945      -2.3117846080172022e-01
    phi[9,0]  R946      -2.3526524949110611e-01
    phi[9,0]  R947      -2.3996632214047042e-01
    phi[9,0]  R948      -2.5191616479626378e-01
    phi[9,0]  R949      -2.6382349724317633e-01
    phi[9,0]  R950      -2.6432527759961078e-01
    phi[9,0]  R951      -2.6780787894052843e-01
    phi[9,0]  R952      -2.6934256765981324e-01
    phi[9,0]  R953      -2.7804596524797276e-01
    phi[9,0]  R954      -2.8140672540249290e-01
    phi[9,0]  R955      -2.0543773823318734e-01
    phi[9,0]  R956      -2.4916293144223356e-01
    phi[9,0]  R957      -2.8891064844738190e-01
    phi[9,0]  R958      -2.9360662685247574e-01
    phi[9,0]  R959      -3.1157451710568851e-01
    phi[9,0]  R960      -3.2482826937676879e-01
    phi[9,0]  R961      -3.4605764561985741e-01
    phi[9,0]  R962      -3.5983605072841529e-01
    phi[9,0]  R963      -3.8179680795753335e-01
    phi[9,0]  R964      -4.1318400417010537e-01
    phi[9,0]  R965      -2.3321743575794385e-01
    phi[9,0]  R966      -2.4875021059051372e-01
    phi[9,0]  R967      -2.4911975038279022e-01
    phi[9,0]  R968      -2.5345930560646834e-01
    phi[9,0]  R969      -2.6112578282581511e-01
    phi[9,0]  R970      -2.6268333245957876e-01
    phi[9,0]  R971      -2.7921388594087732e-01
    phi[9,0]  R972      -0.293966320752137
    phi[9,0]  R973      -3.0267073080930573e-01
    phi[9,0]  R974      -3.0801221719686622e-01
    phi[9,0]  R975      -1.9593996125566937e-01
    phi[9,0]  R976      -2.2529110956409520e-01
    phi[9,0]  R977      -2.8153307853968945e-01
    phi[9,0]  R978      -2.8653504982711464e-01
    phi[9,0]  R979      -2.9075785535395704e-01
    phi[9,0]  R980      -0.300367111410599
    phi[9,0]  R981      -3.2343266919624797e-01
    phi[9,0]  R982      -3.3648839703517452e-01
    phi[9,0]  R983      -0.355994628947756
    phi[9,0]  R984      -3.6933266590434533e-01
    phi[9,0]  R985      -2.2017913174119164e-01
    phi[9,0]  R986      -2.5318653984700057e-01
    phi[9,0]  R987      -3.5119287872369254e-01
    phi[9,0]  R988      -3.8580540727085882e-01
    phi[9,0]  R989      -0.398090779817337
    phi[9,0]  R990      -5.4034550693003469e-01
    phi[9,0]  R991      -5.9226732559293294e-01
    phi[9,0]  R992      -6.3100700247942054e-01
    phi[9,0]  R993      -1.8206371038928690e+00
    phi[9,0]  R994      -2.3611031091401911e+00
    phi[1,2]  R9        1
    phi[1,2]  R10       1
    phi[1,2]  R18       -1
    phi[1,2]  R995      -3.0999999046325684e+00
    phi[1,2]  R996      -3.0999999046325684e+00
    phi[1,2]  R997      -2.2400000095367432e+00
    phi[1,2]  R998      -2.2400000095367432e+00
    phi[1,2]  R999      -3.0999999046325684e+00
    phi[1,2]  R1000     -3.0999999046325684e+00
    phi[1,2]  R1001     -2.5699999332427979e+00
    phi[1,2]  R1002     -2.5699999332427979e+00
    phi[1,2]  R1003     -3.0999999046325684e+00
    phi[1,2]  R1004     -3.0999999046325684e+00
    phi[1,2]  R1005     -2.0899999141693115e+00
    phi[1,2]  R1006     -2.0899999141693115e+00
    phi[1,2]  R1007     -3.0999999046325684e+00
    phi[1,2]  R1008     -3.0999999046325684e+00
    phi[1,2]  R1009     -1.0861157178878784e+00
    phi[1,2]  R1010     1.1526048183441162e+00
    phi[1,2]  R1011     -1.2355302572250366e+00
    phi[1,2]  R1012     2.5177463889122009e-01
    phi[1,2]  R1013     -1.8156976997852325e-01
    phi[1,2]  R1014     -7.2904616594314575e-01
    phi[1,2]  R1015     2.0473327487707138e-02
    phi[1,2]  R1016     -2.4310295283794403e-01
    phi[1,2]  R1017     1.1453621089458466e-01
    phi[1,2]  R1018     2.0463159680366516e-01
    phi[1,2]  R1019     8.9171510934829712e-01
    phi[1,2]  R1020     -9.3918049335479736e-01
    phi[1,2]  R1021     -8.7406319379806519e-01
    phi[1,2]  R1022     -1.0129086971282959e+00
    phi[1,2]  R1023     8.1086955964565277e-02
    phi[1,2]  R1024     -5.9381479024887085e-01
    phi[1,2]  R1025     -1.0927327871322632e+00
    phi[1,2]  R1026     -6.7967575788497925e-01
    phi[1,2]  R1027     -9.7839570045471191e-01
    phi[1,2]  R1028     -2.0007036626338959e-01
    phi[1,2]  R1029     -6.2148696184158325e-01
    phi[1,2]  R1030     -3.5633218288421631e-01
    phi[1,2]  R1031     1.1227352619171143e+00
    phi[1,2]  R1032     8.6756157875061035e-01
    phi[1,2]  R1033     1.7590918540954590e+00
    phi[1,2]  R1034     2.7642126083374023e+00
    phi[1,2]  R1035     -1.7790344953536987e+00
    phi[1,2]  R1036     1.1252429485321045e+00
    phi[1,2]  R1037     8.4551459550857544e-01
    phi[1,2]  R1038     2.2083255648612976e-01
    phi[1,2]  R1039     1.9584376811981201e+00
    phi[1,2]  R1040     -1.4738112688064575e+00
    phi[1,2]  R1041     -1.9687662124633789e+00
    phi[1,2]  R1042     -1.9069193601608276e+00
    phi[1,2]  R1043     -1.8763945102691650e+00
    phi[1,2]  R1044     5.7516723871231079e-01
    phi[1,2]  R1045     -4.1261205077171326e-01
    phi[1,2]  R1046     0.599185585975647
    phi[1,2]  R1047     1.1655040979385376e+00
    phi[1,2]  R1048     4.9231982231140137e-01
    phi[1,2]  R1049     -7.1306413412094116e-01
    phi[1,2]  R1050     4.5464530587196350e-01
    phi[1,2]  R1051     6.4646083116531372e-01
    phi[1,2]  R1052     2.8830516338348389e-01
    phi[1,2]  R1053     1.7553439140319824e+00
    phi[1,2]  R1054     2.6030619144439697e+00
    phi[1,2]  R1055     -1.5083756446838379e+00
    phi[1,2]  R1056     5.2758622169494629e-01
    phi[1,2]  R1057     1.2106776237487793e-01
    phi[1,2]  R1058     -1.7083486318588257e+00
    phi[1,2]  R1059     -1.0965545177459717e+00
    phi[1,2]  R1060     -1.7704814672470093e-01
    phi[2,1]  R9        -1
    phi[2,1]  R18       1
    phi[2,1]  R19       1
    phi[2,1]  R1061     -3.0999999046325684e+00
    phi[2,1]  R1062     -3.0999999046325684e+00
    phi[2,1]  R1063     -2.2400000095367432e+00
    phi[2,1]  R1064     -2.2400000095367432e+00
    phi[2,1]  R1065     -3.0999999046325684e+00
    phi[2,1]  R1066     -3.0999999046325684e+00
    phi[2,1]  R1067     -2.5699999332427979e+00
    phi[2,1]  R1068     -2.5699999332427979e+00
    phi[2,1]  R1069     -3.0999999046325684e+00
    phi[2,1]  R1070     -3.0999999046325684e+00
    phi[2,1]  R1071     -2.0899999141693115e+00
    phi[2,1]  R1072     -2.0899999141693115e+00
    phi[2,1]  R1073     -3.0999999046325684e+00
    phi[2,1]  R1074     -3.0999999046325684e+00
    phi[2,1]  R1075     1.1227352619171143e+00
    phi[2,1]  R1076     8.6756157875061035e-01
    phi[2,1]  R1077     1.7590918540954590e+00
    phi[2,1]  R1078     2.7642126083374023e+00
    phi[2,1]  R1079     -1.7790344953536987e+00
    phi[2,1]  R1080     1.1252429485321045e+00
    phi[2,1]  R1081     8.4551459550857544e-01
    phi[2,1]  R1082     2.2083255648612976e-01
    phi[2,1]  R1083     1.9584376811981201e+00
    phi[2,1]  R1084     -1.4738112688064575e+00
    phi[2,1]  R1085     -1.9687662124633789e+00
    phi[2,1]  R1086     -1.9069193601608276e+00
    phi[2,1]  R1087     -1.8763945102691650e+00
    phi[2,1]  R1088     5.7516723871231079e-01
    phi[2,1]  R1089     -4.1261205077171326e-01
    phi[2,1]  R1090     0.599185585975647
    phi[2,1]  R1091     1.1655040979385376e+00
    phi[2,1]  R1092     4.9231982231140137e-01
    phi[2,1]  R1093     -7.1306413412094116e-01
    phi[2,1]  R1094     4.5464530587196350e-01
    phi[2,1]  R1095     6.4646083116531372e-01
    phi[2,1]  R1096     2.8830516338348389e-01
    phi[2,1]  R1097     1.7553439140319824e+00
    phi[2,1]  R1098     2.6030619144439697e+00
    phi[2,1]  R1099     -1.5083756446838379e+00
    phi[2,1]  R1100     5.2758622169494629e-01
    phi[2,1]  R1101     1.2106776237487793e-01
    phi[2,1]  R1102     -1.7083486318588257e+00
    phi[2,1]  R1103     -1.0965545177459717e+00
    phi[2,1]  R1104     -1.7704814672470093e-01
    phi[2,1]  R1105     -1.0861157178878784e+00
    phi[2,1]  R1106     1.1526048183441162e+00
    phi[2,1]  R1107     -1.2355302572250366e+00
    phi[2,1]  R1108     2.5177463889122009e-01
    phi[2,1]  R1109     -1.8156976997852325e-01
    phi[2,1]  R1110     -7.2904616594314575e-01
    phi[2,1]  R1111     2.0473327487707138e-02
    phi[2,1]  R1112     -2.4310295283794403e-01
    phi[2,1]  R1113     1.1453621089458466e-01
    phi[2,1]  R1114     2.0463159680366516e-01
    phi[2,1]  R1115     8.9171510934829712e-01
    phi[2,1]  R1116     -9.3918049335479736e-01
    phi[2,1]  R1117     -8.7406319379806519e-01
    phi[2,1]  R1118     -1.0129086971282959e+00
    phi[2,1]  R1119     8.1086955964565277e-02
    phi[2,1]  R1120     -5.9381479024887085e-01
    phi[2,1]  R1121     -1.0927327871322632e+00
    phi[2,1]  R1122     -6.7967575788497925e-01
    phi[2,1]  R1123     -9.7839570045471191e-01
    phi[2,1]  R1124     -2.0007036626338959e-01
    phi[2,1]  R1125     -6.2148696184158325e-01
    phi[2,1]  R1126     -3.5633218288421631e-01
    phi[1,6]  R9        1
    phi[1,6]  R10       1
    phi[1,6]  R54       -1
    phi[1,6]  R1127     -3.0999999046325684e+00
    phi[1,6]  R1128     -3.0999999046325684e+00
    phi[1,6]  R1129     -2.2400000095367432e+00
    phi[1,6]  R1130     -2.2400000095367432e+00
    phi[1,6]  R1131     -3.0999999046325684e+00
    phi[1,6]  R1132     -3.0999999046325684e+00
    phi[1,6]  R1133     -2.5699999332427979e+00
    phi[1,6]  R1134     -2.5699999332427979e+00
    phi[1,6]  R1135     -3.0999999046325684e+00
    phi[1,6]  R1136     -3.0999999046325684e+00
    phi[1,6]  R1137     -2.0899999141693115e+00
    phi[1,6]  R1138     -2.0899999141693115e+00
    phi[1,6]  R1139     -3.0999999046325684e+00
    phi[1,6]  R1140     -3.0999999046325684e+00
    phi[1,6]  R1141     -1.0861157178878784e+00
    phi[1,6]  R1142     1.1526048183441162e+00
    phi[1,6]  R1143     -1.2355302572250366e+00
    phi[1,6]  R1144     2.5177463889122009e-01
    phi[1,6]  R1145     -1.8156976997852325e-01
    phi[1,6]  R1146     -7.2904616594314575e-01
    phi[1,6]  R1147     2.0473327487707138e-02
    phi[1,6]  R1148     -2.4310295283794403e-01
    phi[1,6]  R1149     1.1453621089458466e-01
    phi[1,6]  R1150     2.0463159680366516e-01
    phi[1,6]  R1151     8.9171510934829712e-01
    phi[1,6]  R1152     -9.3918049335479736e-01
    phi[1,6]  R1153     -8.7406319379806519e-01
    phi[1,6]  R1154     -1.0129086971282959e+00
    phi[1,6]  R1155     8.1086955964565277e-02
    phi[1,6]  R1156     -5.9381479024887085e-01
    phi[1,6]  R1157     -1.0927327871322632e+00
    phi[1,6]  R1158     -6.7967575788497925e-01
    phi[1,6]  R1159     -9.7839570045471191e-01
    phi[1,6]  R1160     -2.0007036626338959e-01
    phi[1,6]  R1161     -6.2148696184158325e-01
    phi[1,6]  R1162     -3.5633218288421631e-01
    phi[1,6]  R1163     -1.4293605089187622e-01
    phi[1,6]  R1164     0.553049623966217
    phi[1,6]  R1165     1.1266770362854004e+00
    phi[1,6]  R1166     1.6760075092315674e-01
    phi[1,6]  R1167     4.6413907408714294e-01
    phi[1,6]  R1168     -1.8053968250751495e-01
    phi[1,6]  R1169     4.1994491219520569e-01
    phi[1,6]  R1170     6.4365035295486450e-01
    phi[1,6]  R1171     -1.9188141822814941e-01
    phi[1,6]  R1172     -6.5301024913787842e-01
    phi[1,6]  R1173     -1.2399380207061768e+00
    phi[1,6]  R1174     -1.0212239027023315e+00
    phi[1,6]  R1175     -9.9627912044525146e-01
    phi[1,6]  R1176     -2.9817917943000793e-01
    phi[1,6]  R1177     -1.1890790462493896e+00
    phi[1,6]  R1178     -1.0353883504867554e+00
    phi[1,6]  R1179     -1.6944911479949951e+00
    phi[1,6]  R1180     -2.5192213058471680e-01
    phi[1,6]  R1181     -1.2882683277130127e+00
    phi[1,6]  R1182     2.0499148964881897e-01
    phi[1,6]  R1183     -1.97946035861969
    phi[1,6]  R1184     -1.1973530054092407e+00
    phi[1,6]  R1185     -1.9490445852279663e+00
    phi[1,6]  R1186     -1.8847961425781250e+00
    phi[1,6]  R1187     -1.6401908397674561e+00
    phi[1,6]  R1188     -4.8259460926055908e-01
    phi[1,6]  R1189     -1.9464302062988281e+00
    phi[1,6]  R1190     -6.6192144155502319e-01
    phi[1,6]  R1191     -1.6733224391937256e+00
    phi[1,6]  R1192     -2.5008649826049805e+00
    phi[1,6]  R1193     5.6668169796466827e-02
    phi[1,6]  R1194     -2.6952922344207764e+00
    phi[1,6]  R1195     -1.7582894563674927e+00
    phi[1,6]  R1196     -3.5733222961425781e-01
    phi[1,6]  R1197     -2.2754781246185303e+00
    phi[1,6]  R1198     -1.9918773174285889e+00
    phi[1,6]  R1199     -1.9334779679775238e-01
    phi[1,6]  R1200     -2.2467851638793945e+00
    phi[1,6]  R1201     -1.6339864730834961e+00
    phi[1,6]  R1202     -1.4262858629226685e+00
    phi[1,6]  R1203     -1.5026762485504150e+00
    phi[1,6]  R1204     -2.2523403167724609e+00
    phi[1,6]  R1205     -1.2047789096832275e+00
    phi[1,6]  R1206     5.5270552635192871e-01
    phi[1,6]  R1207     -2.3119783401489258e+00
    phi[1,6]  R1208     -2.9652902483940125e-01
    phi[1,6]  R1209     -2.08590030670166
    phi[1,6]  R1210     -1.1205933094024658e+00
    phi[1,6]  R1211     -1.2098271846771240e+00
    phi[1,6]  R1212     -8.8161420822143555e-01
    phi[1,6]  R1213     3.8365300744771957e-02
    phi[1,6]  R1214     -8.0986231565475464e-01
    phi[1,6]  R1215     -1.8443859815597534e+00
    phi[1,6]  R1216     -1.0792300701141357e+00
    phi[1,6]  R1217     -7.9451024532318115e-01
    phi[1,6]  R1218     -1.9502327442169189e+00
    phi[1,6]  R1219     -5.6438320875167847e-01
    phi[1,6]  R1220     1.3592110574245453e-01
    phi[1,6]  R1221     -4.2466154694557190e-01
    phi[1,6]  R1222     -1.8536425828933716e+00
    phi[6,1]  R9        -1
    phi[6,1]  R54       1
    phi[6,1]  R55       1
    phi[6,1]  R1223     -3.0999999046325684e+00
    phi[6,1]  R1224     -3.0999999046325684e+00
    phi[6,1]  R1225     -2.2400000095367432e+00
    phi[6,1]  R1226     -2.2400000095367432e+00
    phi[6,1]  R1227     -3.0999999046325684e+00
    phi[6,1]  R1228     -3.0999999046325684e+00
    phi[6,1]  R1229     -2.5699999332427979e+00
    phi[6,1]  R1230     -2.5699999332427979e+00
    phi[6,1]  R1231     -3.0999999046325684e+00
    phi[6,1]  R1232     -3.0999999046325684e+00
    phi[6,1]  R1233     -2.0899999141693115e+00
    phi[6,1]  R1234     -2.0899999141693115e+00
    phi[6,1]  R1235     -3.0999999046325684e+00
    phi[6,1]  R1236     -3.0999999046325684e+00
    phi[6,1]  R1237     -1.4293605089187622e-01
    phi[6,1]  R1238     0.553049623966217
    phi[6,1]  R1239     1.1266770362854004e+00
    phi[6,1]  R1240     1.6760075092315674e-01
    phi[6,1]  R1241     4.6413907408714294e-01
    phi[6,1]  R1242     -1.8053968250751495e-01
    phi[6,1]  R1243     4.1994491219520569e-01
    phi[6,1]  R1244     6.4365035295486450e-01
    phi[6,1]  R1245     -1.9188141822814941e-01
    phi[6,1]  R1246     -6.5301024913787842e-01
    phi[6,1]  R1247     -1.2399380207061768e+00
    phi[6,1]  R1248     -1.0212239027023315e+00
    phi[6,1]  R1249     -9.9627912044525146e-01
    phi[6,1]  R1250     -2.9817917943000793e-01
    phi[6,1]  R1251     -1.1890790462493896e+00
    phi[6,1]  R1252     -1.0353883504867554e+00
    phi[6,1]  R1253     -1.6944911479949951e+00
    phi[6,1]  R1254     -2.5192213058471680e-01
    phi[6,1]  R1255     -1.2882683277130127e+00
    phi[6,1]  R1256     2.0499148964881897e-01
    phi[6,1]  R1257     -1.97946035861969
    phi[6,1]  R1258     -1.1973530054092407e+00
    phi[6,1]  R1259     -1.9490445852279663e+00
    phi[6,1]  R1260     -1.8847961425781250e+00
    phi[6,1]  R1261     -1.6401908397674561e+00
    phi[6,1]  R1262     -4.8259460926055908e-01
    phi[6,1]  R1263     -1.9464302062988281e+00
    phi[6,1]  R1264     -6.6192144155502319e-01
    phi[6,1]  R1265     -1.6733224391937256e+00
    phi[6,1]  R1266     -2.5008649826049805e+00
    phi[6,1]  R1267     5.6668169796466827e-02
    phi[6,1]  R1268     -2.6952922344207764e+00
    phi[6,1]  R1269     -1.7582894563674927e+00
    phi[6,1]  R1270     -3.5733222961425781e-01
    phi[6,1]  R1271     -2.2754781246185303e+00
    phi[6,1]  R1272     -1.9918773174285889e+00
    phi[6,1]  R1273     -1.9334779679775238e-01
    phi[6,1]  R1274     -2.2467851638793945e+00
    phi[6,1]  R1275     -1.6339864730834961e+00
    phi[6,1]  R1276     -1.4262858629226685e+00
    phi[6,1]  R1277     -1.5026762485504150e+00
    phi[6,1]  R1278     -2.2523403167724609e+00
    phi[6,1]  R1279     -1.2047789096832275e+00
    phi[6,1]  R1280     5.5270552635192871e-01
    phi[6,1]  R1281     -2.3119783401489258e+00
    phi[6,1]  R1282     -2.9652902483940125e-01
    phi[6,1]  R1283     -2.08590030670166
    phi[6,1]  R1284     -1.1205933094024658e+00
    phi[6,1]  R1285     -1.2098271846771240e+00
    phi[6,1]  R1286     -8.8161420822143555e-01
    phi[6,1]  R1287     3.8365300744771957e-02
    phi[6,1]  R1288     -8.0986231565475464e-01
    phi[6,1]  R1289     -1.8443859815597534e+00
    phi[6,1]  R1290     -1.0792300701141357e+00
    phi[6,1]  R1291     -7.9451024532318115e-01
    phi[6,1]  R1292     -1.9502327442169189e+00
    phi[6,1]  R1293     -5.6438320875167847e-01
    phi[6,1]  R1294     1.3592110574245453e-01
    phi[6,1]  R1295     -4.2466154694557190e-01
    phi[6,1]  R1296     -1.8536425828933716e+00
    phi[6,1]  R1297     -1.0861157178878784e+00
    phi[6,1]  R1298     1.1526048183441162e+00
    phi[6,1]  R1299     -1.2355302572250366e+00
    phi[6,1]  R1300     2.5177463889122009e-01
    phi[6,1]  R1301     -1.8156976997852325e-01
    phi[6,1]  R1302     -7.2904616594314575e-01
    phi[6,1]  R1303     2.0473327487707138e-02
    phi[6,1]  R1304     -2.4310295283794403e-01
    phi[6,1]  R1305     1.1453621089458466e-01
    phi[6,1]  R1306     2.0463159680366516e-01
    phi[6,1]  R1307     8.9171510934829712e-01
    phi[6,1]  R1308     -9.3918049335479736e-01
    phi[6,1]  R1309     -8.7406319379806519e-01
    phi[6,1]  R1310     -1.0129086971282959e+00
    phi[6,1]  R1311     8.1086955964565277e-02
    phi[6,1]  R1312     -5.9381479024887085e-01
    phi[6,1]  R1313     -1.0927327871322632e+00
    phi[6,1]  R1314     -6.7967575788497925e-01
    phi[6,1]  R1315     -9.7839570045471191e-01
    phi[6,1]  R1316     -2.0007036626338959e-01
    phi[6,1]  R1317     -6.2148696184158325e-01
    phi[6,1]  R1318     -3.5633218288421631e-01
    phi[2,3]  R18       1
    phi[2,3]  R19       1
    phi[2,3]  R27       -1
    phi[2,3]  R1319     -3.0999999046325684e+00
    phi[2,3]  R1320     -3.0999999046325684e+00
    phi[2,3]  R1321     -2.2400000095367432e+00
    phi[2,3]  R1322     -2.2400000095367432e+00
    phi[2,3]  R1323     -3.0999999046325684e+00
    phi[2,3]  R1324     -3.0999999046325684e+00
    phi[2,3]  R1325     -2.5699999332427979e+00
    phi[2,3]  R1326     -2.5699999332427979e+00
    phi[2,3]  R1327     -3.0999999046325684e+00
    phi[2,3]  R1328     -3.0999999046325684e+00
    phi[2,3]  R1329     -2.0899999141693115e+00
    phi[2,3]  R1330     -2.0899999141693115e+00
    phi[2,3]  R1331     -3.0999999046325684e+00
    phi[2,3]  R1332     -3.0999999046325684e+00
    phi[2,3]  R1333     1.1227352619171143e+00
    phi[2,3]  R1334     8.6756157875061035e-01
    phi[2,3]  R1335     1.7590918540954590e+00
    phi[2,3]  R1336     2.7642126083374023e+00
    phi[2,3]  R1337     -1.7790344953536987e+00
    phi[2,3]  R1338     1.1252429485321045e+00
    phi[2,3]  R1339     8.4551459550857544e-01
    phi[2,3]  R1340     2.2083255648612976e-01
    phi[2,3]  R1341     1.9584376811981201e+00
    phi[2,3]  R1342     -1.4738112688064575e+00
    phi[2,3]  R1343     -1.9687662124633789e+00
    phi[2,3]  R1344     -1.9069193601608276e+00
    phi[2,3]  R1345     -1.8763945102691650e+00
    phi[2,3]  R1346     5.7516723871231079e-01
    phi[2,3]  R1347     -4.1261205077171326e-01
    phi[2,3]  R1348     0.599185585975647
    phi[2,3]  R1349     1.1655040979385376e+00
    phi[2,3]  R1350     4.9231982231140137e-01
    phi[2,3]  R1351     -7.1306413412094116e-01
    phi[2,3]  R1352     4.5464530587196350e-01
    phi[2,3]  R1353     6.4646083116531372e-01
    phi[2,3]  R1354     2.8830516338348389e-01
    phi[2,3]  R1355     1.7553439140319824e+00
    phi[2,3]  R1356     2.6030619144439697e+00
    phi[2,3]  R1357     -1.5083756446838379e+00
    phi[2,3]  R1358     5.2758622169494629e-01
    phi[2,3]  R1359     1.2106776237487793e-01
    phi[2,3]  R1360     -1.7083486318588257e+00
    phi[2,3]  R1361     -1.0965545177459717e+00
    phi[2,3]  R1362     -1.7704814672470093e-01
    phi[2,3]  R1363     -2.2919051647186279e+00
    phi[2,3]  R1364     2.8019049763679504e-01
    phi[2,3]  R1365     5.5485385656356812e-01
    phi[2,3]  R1366     5.0509524345397949e-01
    phi[2,3]  R1367     3.0478453636169434e+00
    phi[2,3]  R1368     -1.6207207441329956e+00
    phi[2,3]  R1369     -7.1157000958919525e-02
    phi[2,3]  R1370     1.3561111688613892e+00
    phi[2,3]  R1371     2.4797843396663666e-01
    phi[2,3]  R1372     2.0526831150054932e+00
    phi[2,3]  R1373     -1.3260893523693085e-02
    phi[2,3]  R1374     -5.4202312231063843e-01
    phi[2,3]  R1375     7.7936178445816040e-01
    phi[2,3]  R1376     1.8592391014099121e+00
    phi[2,3]  R1377     8.5531163215637207e-01
    phi[2,3]  R1378     5.7445728778839111e-01
    phi[2,3]  R1379     6.9828122854232788e-01
    phi[2,3]  R1380     -2.0163628458976746e-01
    phi[2,3]  R1381     -0.560814380645752
    phi[2,3]  R1382     -1.1204876899719238e+00
    phi[2,3]  R1383     2.1449632644653320e+00
    phi[2,3]  R1384     2.1319551467895508e+00
    phi[2,3]  R1385     1.6265467405319214e+00
    phi[2,3]  R1386     1.7932230234146118e+00
    phi[2,3]  R1387     2.0228438377380371e+00
    phi[2,3]  R1388     -1.4155236482620239e+00
    phi[3,2]  R18       -1
    phi[3,2]  R27       1
    phi[3,2]  R28       1
    phi[3,2]  R1389     -3.0999999046325684e+00
    phi[3,2]  R1390     -3.0999999046325684e+00
    phi[3,2]  R1391     -2.2400000095367432e+00
    phi[3,2]  R1392     -2.2400000095367432e+00
    phi[3,2]  R1393     -3.0999999046325684e+00
    phi[3,2]  R1394     -3.0999999046325684e+00
    phi[3,2]  R1395     -2.5699999332427979e+00
    phi[3,2]  R1396     -2.5699999332427979e+00
    phi[3,2]  R1397     -3.0999999046325684e+00
    phi[3,2]  R1398     -3.0999999046325684e+00
    phi[3,2]  R1399     -2.0899999141693115e+00
    phi[3,2]  R1400     -2.0899999141693115e+00
    phi[3,2]  R1401     -3.0999999046325684e+00
    phi[3,2]  R1402     -3.0999999046325684e+00
    phi[3,2]  R1403     -2.2919051647186279e+00
    phi[3,2]  R1404     2.8019049763679504e-01
    phi[3,2]  R1405     5.5485385656356812e-01
    phi[3,2]  R1406     5.0509524345397949e-01
    phi[3,2]  R1407     3.0478453636169434e+00
    phi[3,2]  R1408     -1.6207207441329956e+00
    phi[3,2]  R1409     -7.1157000958919525e-02
    phi[3,2]  R1410     1.3561111688613892e+00
    phi[3,2]  R1411     2.4797843396663666e-01
    phi[3,2]  R1412     2.0526831150054932e+00
    phi[3,2]  R1413     -1.3260893523693085e-02
    phi[3,2]  R1414     -5.4202312231063843e-01
    phi[3,2]  R1415     7.7936178445816040e-01
    phi[3,2]  R1416     1.8592391014099121e+00
    phi[3,2]  R1417     8.5531163215637207e-01
    phi[3,2]  R1418     5.7445728778839111e-01
    phi[3,2]  R1419     6.9828122854232788e-01
    phi[3,2]  R1420     -2.0163628458976746e-01
    phi[3,2]  R1421     -0.560814380645752
    phi[3,2]  R1422     -1.1204876899719238e+00
    phi[3,2]  R1423     2.1449632644653320e+00
    phi[3,2]  R1424     2.1319551467895508e+00
    phi[3,2]  R1425     1.6265467405319214e+00
    phi[3,2]  R1426     1.7932230234146118e+00
    phi[3,2]  R1427     2.0228438377380371e+00
    phi[3,2]  R1428     -1.4155236482620239e+00
    phi[3,2]  R1429     1.1227352619171143e+00
    phi[3,2]  R1430     8.6756157875061035e-01
    phi[3,2]  R1431     1.7590918540954590e+00
    phi[3,2]  R1432     2.7642126083374023e+00
    phi[3,2]  R1433     -1.7790344953536987e+00
    phi[3,2]  R1434     1.1252429485321045e+00
    phi[3,2]  R1435     8.4551459550857544e-01
    phi[3,2]  R1436     2.2083255648612976e-01
    phi[3,2]  R1437     1.9584376811981201e+00
    phi[3,2]  R1438     -1.4738112688064575e+00
    phi[3,2]  R1439     -1.9687662124633789e+00
    phi[3,2]  R1440     -1.9069193601608276e+00
    phi[3,2]  R1441     -1.8763945102691650e+00
    phi[3,2]  R1442     5.7516723871231079e-01
    phi[3,2]  R1443     -4.1261205077171326e-01
    phi[3,2]  R1444     0.599185585975647
    phi[3,2]  R1445     1.1655040979385376e+00
    phi[3,2]  R1446     4.9231982231140137e-01
    phi[3,2]  R1447     -7.1306413412094116e-01
    phi[3,2]  R1448     4.5464530587196350e-01
    phi[3,2]  R1449     6.4646083116531372e-01
    phi[3,2]  R1450     2.8830516338348389e-01
    phi[3,2]  R1451     1.7553439140319824e+00
    phi[3,2]  R1452     2.6030619144439697e+00
    phi[3,2]  R1453     -1.5083756446838379e+00
    phi[3,2]  R1454     5.2758622169494629e-01
    phi[3,2]  R1455     1.2106776237487793e-01
    phi[3,2]  R1456     -1.7083486318588257e+00
    phi[3,2]  R1457     -1.0965545177459717e+00
    phi[3,2]  R1458     -1.7704814672470093e-01
    phi[3,4]  R27       1
    phi[3,4]  R28       1
    phi[3,4]  R36       -1
    phi[3,4]  R1459     -3.0999999046325684e+00
    phi[3,4]  R1460     -3.0999999046325684e+00
    phi[3,4]  R1461     -2.2400000095367432e+00
    phi[3,4]  R1462     -2.2400000095367432e+00
    phi[3,4]  R1463     -3.0999999046325684e+00
    phi[3,4]  R1464     -3.0999999046325684e+00
    phi[3,4]  R1465     -2.5699999332427979e+00
    phi[3,4]  R1466     -2.5699999332427979e+00
    phi[3,4]  R1467     -3.0999999046325684e+00
    phi[3,4]  R1468     -3.0999999046325684e+00
    phi[3,4]  R1469     -2.0899999141693115e+00
    phi[3,4]  R1470     -2.0899999141693115e+00
    phi[3,4]  R1471     -3.0999999046325684e+00
    phi[3,4]  R1472     -3.0999999046325684e+00
    phi[3,4]  R1473     -2.2919051647186279e+00
    phi[3,4]  R1474     2.8019049763679504e-01
    phi[3,4]  R1475     5.5485385656356812e-01
    phi[3,4]  R1476     5.0509524345397949e-01
    phi[3,4]  R1477     3.0478453636169434e+00
    phi[3,4]  R1478     -1.6207207441329956e+00
    phi[3,4]  R1479     -7.1157000958919525e-02
    phi[3,4]  R1480     1.3561111688613892e+00
    phi[3,4]  R1481     2.4797843396663666e-01
    phi[3,4]  R1482     2.0526831150054932e+00
    phi[3,4]  R1483     -1.3260893523693085e-02
    phi[3,4]  R1484     -5.4202312231063843e-01
    phi[3,4]  R1485     7.7936178445816040e-01
    phi[3,4]  R1486     1.8592391014099121e+00
    phi[3,4]  R1487     8.5531163215637207e-01
    phi[3,4]  R1488     5.7445728778839111e-01
    phi[3,4]  R1489     6.9828122854232788e-01
    phi[3,4]  R1490     -2.0163628458976746e-01
    phi[3,4]  R1491     -0.560814380645752
    phi[3,4]  R1492     -1.1204876899719238e+00
    phi[3,4]  R1493     2.1449632644653320e+00
    phi[3,4]  R1494     2.1319551467895508e+00
    phi[3,4]  R1495     1.6265467405319214e+00
    phi[3,4]  R1496     1.7932230234146118e+00
    phi[3,4]  R1497     2.0228438377380371e+00
    phi[3,4]  R1498     -1.4155236482620239e+00
    phi[3,4]  R1499     1.3593208789825439e+00
    phi[3,4]  R1500     1.7307834625244141e+00
    phi[3,4]  R1501     2.3619551658630371e+00
    phi[3,4]  R1502     -9.6278053522109985e-01
    phi[3,4]  R1503     2.0238623619079590e+00
    phi[3,4]  R1504     1.8889181613922119e+00
    phi[3,4]  R1505     6.3224303722381592e-01
    phi[3,4]  R1506     2.1580741405487061e+00
    phi[3,4]  R1507     -1.5428357124328613e+00
    phi[3,4]  R1508     -5.0664299726486206e-01
    phi[3,4]  R1509     -9.9752390384674072e-01
    phi[3,4]  R1510     -7.1942903101444244e-02
    phi[3,4]  R1511     -5.3048843145370483e-01
    phi[3,4]  R1512     7.9014116525650024e-01
    phi[3,4]  R1513     -1.0745170116424561e+00
    phi[3,4]  R1514     -1.5496337413787842e+00
    phi[3,4]  R1515     -1.2659522294998169e+00
    phi[3,4]  R1516     -1.4863169193267822e+00
    phi[3,4]  R1517     3.0115339159965515e-01
    phi[3,4]  R1518     -2.1831299364566803e-01
    phi[3,4]  R1519     -0.547369122505188
    phi[3,4]  R1520     -3.1156084537506104e+00
    phi[3,4]  R1521     1.1127747297286987e+00
    phi[3,4]  R1522     1.4261164665222168e+00
    phi[3,4]  R1523     -6.6498422622680664e-01
    phi[3,4]  R1524     -1.1705715656280518e+00
    phi[4,3]  R27       -1
    phi[4,3]  R36       1
    phi[4,3]  R37       1
    phi[4,3]  R1525     -3.0999999046325684e+00
    phi[4,3]  R1526     -3.0999999046325684e+00
    phi[4,3]  R1527     -2.2400000095367432e+00
    phi[4,3]  R1528     -2.2400000095367432e+00
    phi[4,3]  R1529     -3.0999999046325684e+00
    phi[4,3]  R1530     -3.0999999046325684e+00
    phi[4,3]  R1531     -2.5699999332427979e+00
    phi[4,3]  R1532     -2.5699999332427979e+00
    phi[4,3]  R1533     -3.0999999046325684e+00
    phi[4,3]  R1534     -3.0999999046325684e+00
    phi[4,3]  R1535     -2.0899999141693115e+00
    phi[4,3]  R1536     -2.0899999141693115e+00
    phi[4,3]  R1537     -3.0999999046325684e+00
    phi[4,3]  R1538     -3.0999999046325684e+00
    phi[4,3]  R1539     1.3593208789825439e+00
    phi[4,3]  R1540     1.7307834625244141e+00
    phi[4,3]  R1541     2.3619551658630371e+00
    phi[4,3]  R1542     -9.6278053522109985e-01
    phi[4,3]  R1543     2.0238623619079590e+00
    phi[4,3]  R1544     1.8889181613922119e+00
    phi[4,3]  R1545     6.3224303722381592e-01
    phi[4,3]  R1546     2.1580741405487061e+00
    phi[4,3]  R1547     -1.5428357124328613e+00
    phi[4,3]  R1548     -5.0664299726486206e-01
    phi[4,3]  R1549     -9.9752390384674072e-01
    phi[4,3]  R1550     -7.1942903101444244e-02
    phi[4,3]  R1551     -5.3048843145370483e-01
    phi[4,3]  R1552     7.9014116525650024e-01
    phi[4,3]  R1553     -1.0745170116424561e+00
    phi[4,3]  R1554     -1.5496337413787842e+00
    phi[4,3]  R1555     -1.2659522294998169e+00
    phi[4,3]  R1556     -1.4863169193267822e+00
    phi[4,3]  R1557     3.0115339159965515e-01
    phi[4,3]  R1558     -2.1831299364566803e-01
    phi[4,3]  R1559     -0.547369122505188
    phi[4,3]  R1560     -3.1156084537506104e+00
    phi[4,3]  R1561     1.1127747297286987e+00
    phi[4,3]  R1562     1.4261164665222168e+00
    phi[4,3]  R1563     -6.6498422622680664e-01
    phi[4,3]  R1564     -1.1705715656280518e+00
    phi[4,3]  R1565     -2.2919051647186279e+00
    phi[4,3]  R1566     2.8019049763679504e-01
    phi[4,3]  R1567     5.5485385656356812e-01
    phi[4,3]  R1568     5.0509524345397949e-01
    phi[4,3]  R1569     3.0478453636169434e+00
    phi[4,3]  R1570     -1.6207207441329956e+00
    phi[4,3]  R1571     -7.1157000958919525e-02
    phi[4,3]  R1572     1.3561111688613892e+00
    phi[4,3]  R1573     2.4797843396663666e-01
    phi[4,3]  R1574     2.0526831150054932e+00
    phi[4,3]  R1575     -1.3260893523693085e-02
    phi[4,3]  R1576     -5.4202312231063843e-01
    phi[4,3]  R1577     7.7936178445816040e-01
    phi[4,3]  R1578     1.8592391014099121e+00
    phi[4,3]  R1579     8.5531163215637207e-01
    phi[4,3]  R1580     5.7445728778839111e-01
    phi[4,3]  R1581     6.9828122854232788e-01
    phi[4,3]  R1582     -2.0163628458976746e-01
    phi[4,3]  R1583     -0.560814380645752
    phi[4,3]  R1584     -1.1204876899719238e+00
    phi[4,3]  R1585     2.1449632644653320e+00
    phi[4,3]  R1586     2.1319551467895508e+00
    phi[4,3]  R1587     1.6265467405319214e+00
    phi[4,3]  R1588     1.7932230234146118e+00
    phi[4,3]  R1589     2.0228438377380371e+00
    phi[4,3]  R1590     -1.4155236482620239e+00
    phi[4,8]  R36       1
    phi[4,8]  R37       1
    phi[4,8]  R72       -1
    phi[4,8]  R1591     -3.0999999046325684e+00
    phi[4,8]  R1592     -3.0999999046325684e+00
    phi[4,8]  R1593     -2.2400000095367432e+00
    phi[4,8]  R1594     -2.2400000095367432e+00
    phi[4,8]  R1595     -3.0999999046325684e+00
    phi[4,8]  R1596     -3.0999999046325684e+00
    phi[4,8]  R1597     -2.5699999332427979e+00
    phi[4,8]  R1598     -2.5699999332427979e+00
    phi[4,8]  R1599     -3.0999999046325684e+00
    phi[4,8]  R1600     -3.0999999046325684e+00
    phi[4,8]  R1601     -2.0899999141693115e+00
    phi[4,8]  R1602     -2.0899999141693115e+00
    phi[4,8]  R1603     -3.0999999046325684e+00
    phi[4,8]  R1604     -3.0999999046325684e+00
    phi[4,8]  R1605     1.3593208789825439e+00
    phi[4,8]  R1606     1.7307834625244141e+00
    phi[4,8]  R1607     2.3619551658630371e+00
    phi[4,8]  R1608     -9.6278053522109985e-01
    phi[4,8]  R1609     2.0238623619079590e+00
    phi[4,8]  R1610     1.8889181613922119e+00
    phi[4,8]  R1611     6.3224303722381592e-01
    phi[4,8]  R1612     2.1580741405487061e+00
    phi[4,8]  R1613     -1.5428357124328613e+00
    phi[4,8]  R1614     -5.0664299726486206e-01
    phi[4,8]  R1615     -9.9752390384674072e-01
    phi[4,8]  R1616     -7.1942903101444244e-02
    phi[4,8]  R1617     -5.3048843145370483e-01
    phi[4,8]  R1618     7.9014116525650024e-01
    phi[4,8]  R1619     -1.0745170116424561e+00
    phi[4,8]  R1620     -1.5496337413787842e+00
    phi[4,8]  R1621     -1.2659522294998169e+00
    phi[4,8]  R1622     -1.4863169193267822e+00
    phi[4,8]  R1623     3.0115339159965515e-01
    phi[4,8]  R1624     -2.1831299364566803e-01
    phi[4,8]  R1625     -0.547369122505188
    phi[4,8]  R1626     -3.1156084537506104e+00
    phi[4,8]  R1627     1.1127747297286987e+00
    phi[4,8]  R1628     1.4261164665222168e+00
    phi[4,8]  R1629     -6.6498422622680664e-01
    phi[4,8]  R1630     -1.1705715656280518e+00
    phi[4,8]  R1631     1.4948843717575073e+00
    phi[4,8]  R1632     2.5692541599273682e+00
    phi[4,8]  R1633     1.2411298751831055e+00
    phi[4,8]  R1634     1.3812897205352783e+00
    phi[4,8]  R1635     1.4594970941543579e+00
    phi[4,8]  R1636     1.3877192735671997e+00
    phi[4,8]  R1637     1.4981322288513184e+00
    phi[4,8]  R1638     -1.1706575155258179e+00
    phi[4,8]  R1639     -7.7520543336868286e-01
    phi[4,8]  R1640     -2.1378141641616821e-01
    phi[4,8]  R1641     -2.2091298103332520e+00
    phi[4,8]  R1642     -2.4698002338409424e+00
    phi[4,8]  R1643     -1.6824862957000732e+00
    phi[4,8]  R1644     -1.1279288530349731e+00
    phi[4,8]  R1645     -7.8519582748413086e-01
    phi[4,8]  R1646     -7.4534124135971069e-01
    phi[4,8]  R1647     -1.0448693037033081e+00
    phi[4,8]  R1648     -1.1448354721069336e+00
    phi[8,4]  R36       -1
    phi[8,4]  R72       1
    phi[8,4]  R73       1
    phi[8,4]  R1649     -3.0999999046325684e+00
    phi[8,4]  R1650     -3.0999999046325684e+00
    phi[8,4]  R1651     -2.2400000095367432e+00
    phi[8,4]  R1652     -2.2400000095367432e+00
    phi[8,4]  R1653     -3.0999999046325684e+00
    phi[8,4]  R1654     -3.0999999046325684e+00
    phi[8,4]  R1655     -2.5699999332427979e+00
    phi[8,4]  R1656     -2.5699999332427979e+00
    phi[8,4]  R1657     -3.0999999046325684e+00
    phi[8,4]  R1658     -3.0999999046325684e+00
    phi[8,4]  R1659     -2.0899999141693115e+00
    phi[8,4]  R1660     -2.0899999141693115e+00
    phi[8,4]  R1661     -3.0999999046325684e+00
    phi[8,4]  R1662     -3.0999999046325684e+00
    phi[8,4]  R1663     1.4948843717575073e+00
    phi[8,4]  R1664     2.5692541599273682e+00
    phi[8,4]  R1665     1.2411298751831055e+00
    phi[8,4]  R1666     1.3812897205352783e+00
    phi[8,4]  R1667     1.4594970941543579e+00
    phi[8,4]  R1668     1.3877192735671997e+00
    phi[8,4]  R1669     1.4981322288513184e+00
    phi[8,4]  R1670     -1.1706575155258179e+00
    phi[8,4]  R1671     -7.7520543336868286e-01
    phi[8,4]  R1672     -2.1378141641616821e-01
    phi[8,4]  R1673     -2.2091298103332520e+00
    phi[8,4]  R1674     -2.4698002338409424e+00
    phi[8,4]  R1675     -1.6824862957000732e+00
    phi[8,4]  R1676     -1.1279288530349731e+00
    phi[8,4]  R1677     -7.8519582748413086e-01
    phi[8,4]  R1678     -7.4534124135971069e-01
    phi[8,4]  R1679     -1.0448693037033081e+00
    phi[8,4]  R1680     -1.1448354721069336e+00
    phi[8,4]  R1681     1.3593208789825439e+00
    phi[8,4]  R1682     1.7307834625244141e+00
    phi[8,4]  R1683     2.3619551658630371e+00
    phi[8,4]  R1684     -9.6278053522109985e-01
    phi[8,4]  R1685     2.0238623619079590e+00
    phi[8,4]  R1686     1.8889181613922119e+00
    phi[8,4]  R1687     6.3224303722381592e-01
    phi[8,4]  R1688     2.1580741405487061e+00
    phi[8,4]  R1689     -1.5428357124328613e+00
    phi[8,4]  R1690     -5.0664299726486206e-01
    phi[8,4]  R1691     -9.9752390384674072e-01
    phi[8,4]  R1692     -7.1942903101444244e-02
    phi[8,4]  R1693     -5.3048843145370483e-01
    phi[8,4]  R1694     7.9014116525650024e-01
    phi[8,4]  R1695     -1.0745170116424561e+00
    phi[8,4]  R1696     -1.5496337413787842e+00
    phi[8,4]  R1697     -1.2659522294998169e+00
    phi[8,4]  R1698     -1.4863169193267822e+00
    phi[8,4]  R1699     3.0115339159965515e-01
    phi[8,4]  R1700     -2.1831299364566803e-01
    phi[8,4]  R1701     -0.547369122505188
    phi[8,4]  R1702     -3.1156084537506104e+00
    phi[8,4]  R1703     1.1127747297286987e+00
    phi[8,4]  R1704     1.4261164665222168e+00
    phi[8,4]  R1705     -6.6498422622680664e-01
    phi[8,4]  R1706     -1.1705715656280518e+00
    phi[4,10]  R36       1
    phi[4,10]  R37       1
    phi[4,10]  R38       2.2015075818676695e+00
    phi[4,10]  R39       1.2555005905551371e+00
    phi[4,10]  R40       -2.3962911148857420e+00
    phi[4,10]  R41       -2.5093355321458106e+00
    phi[4,10]  R42       1.1050770722541126e+00
    phi[4,10]  R43       -3.3966445622447283e-01
    phi[4,10]  R44       1.0601281308923380e+00
    phi[4,10]  R82       -1
    phi[4,10]  R1707     -8.9849232276489888e-01
    phi[4,10]  R1708     -5.3015074865002383e+00
    phi[4,10]  R1709     -9.8449941898160609e-01
    phi[4,10]  R1710     -3.49550060009188
    phi[4,10]  R1711     -5.49629101951831
    phi[4,10]  R1712     -7.0370878974682638e-01
    phi[4,10]  R1713     -5.0793354653886080e+00
    phi[4,10]  R1714     -6.0664401096987230e-02
    phi[4,10]  R1715     -1.9949228323784558e+00
    phi[4,10]  R1716     -4.2050769768866809e+00
    phi[4,10]  R1717     -2.4296643703937844e+00
    phi[4,10]  R1718     -1.7503354579448387e+00
    phi[4,10]  R1719     -2.0398717737402303e+00
    phi[4,10]  R1720     -4.1601280355249060e+00
    phi[4,10]  R1721     -1.8164014549717056e-02
    phi[4,10]  R1722     -3.2907233468699060e-02
    phi[4,10]  R1723     -4.0067471014097578e-02
    phi[4,10]  R1724     -4.9475822441213846e-02
    phi[4,10]  R1725     -5.8801936059704296e-02
    phi[4,10]  R1726     -5.9727793178694366e-02
    phi[4,10]  R1727     -6.5610706614187553e-02
    phi[4,10]  R1728     -7.3077944130645278e-02
    phi[4,10]  R1729     -8.0178318054473952e-02
    phi[4,10]  R1730     -7.7081406054424972e-01
    phi[4,10]  R1731     -4.0323166083608641e-02
    phi[4,10]  R1732     -4.3675590024857619e-01
    phi[4,10]  R1733     -0.490077811251467
    phi[4,10]  R1734     -0.537271910255487
    phi[4,10]  R1735     -5.7417164655751751e-01
    phi[4,10]  R1736     -5.7816775237296536e-01
    phi[4,10]  R1737     -0.586662721641888
    phi[4,10]  R1738     -0.619463010096089
    phi[4,10]  R1739     -1.0490171967458666e+00
    phi[4,10]  R1740     -1.0678227560467772e+00
    phi[4,10]  R1741     -8.4583231863112285e-02
    phi[4,10]  R1742     -1.8630403454833111e-01
    phi[4,10]  R1743     -2.1886310885963223e-01
    phi[4,10]  R1744     -2.4513151727928228e-01
    phi[4,10]  R1745     -4.3646892479632254e-01
    phi[4,10]  R1746     -5.4420461806270370e-01
    phi[5,6]  R45       1
    phi[5,6]  R46       1
    phi[5,6]  R54       -1
    phi[5,6]  R1747     -3.0999999046325684e+00
    phi[5,6]  R1748     -3.0999999046325684e+00
    phi[5,6]  R1749     -2.2400000095367432e+00
    phi[5,6]  R1750     -2.2400000095367432e+00
    phi[5,6]  R1751     -3.0999999046325684e+00
    phi[5,6]  R1752     -3.0999999046325684e+00
    phi[5,6]  R1753     -2.5699999332427979e+00
    phi[5,6]  R1754     -2.5699999332427979e+00
    phi[5,6]  R1755     -3.0999999046325684e+00
    phi[5,6]  R1756     -3.0999999046325684e+00
    phi[5,6]  R1757     -2.0899999141693115e+00
    phi[5,6]  R1758     -2.0899999141693115e+00
    phi[5,6]  R1759     -3.0999999046325684e+00
    phi[5,6]  R1760     -3.0999999046325684e+00
    phi[5,6]  R1761     1.2125108242034912e+00
    phi[5,6]  R1762     9.9890762567520142e-01
    phi[5,6]  R1763     9.7437423467636108e-01
    phi[5,6]  R1764     6.5576332807540894e-01
    phi[5,6]  R1765     3.9197501540184021e-01
    phi[5,6]  R1766     2.8208884596824646e-01
    phi[5,6]  R1767     0.0126736955717206
    phi[5,6]  R1768     -3.0393150448799133e-01
    phi[5,6]  R1769     8.6660206317901611e-01
    phi[5,6]  R1770     3.8977745175361633e-01
    phi[5,6]  R1771     -2.1395599842071533e+00
    phi[5,6]  R1772     -2.1722893714904785e+00
    phi[5,6]  R1773     -1.9291379451751709e+00
    phi[5,6]  R1774     -2.0921773910522461e+00
    phi[5,6]  R1775     -2.0158741474151611e+00
    phi[5,6]  R1776     -1.4781172275543213e+00
    phi[5,6]  R1777     -1.4330282211303711e+00
    phi[5,6]  R1778     -1.8183500766754150e+00
    phi[5,6]  R1779     -3.2681903243064880e-01
    phi[5,6]  R1780     -3.5767412185668945e-01
    phi[5,6]  R1781     -2.1543724536895752e+00
    phi[5,6]  R1782     -3.5427243709564209e+00
    phi[5,6]  R1783     -2.2052223682403564e+00
    phi[5,6]  R1784     -1.1267335414886475e+00
    phi[5,6]  R1785     -1.4125297963619232e-01
    phi[5,6]  R1786     0.0756712406873703
    phi[5,6]  R1787     -3.2745990753173828e+00
    phi[5,6]  R1788     -6.2932336330413818e-01
    phi[5,6]  R1789     -1.0634574890136719e+00
    phi[5,6]  R1790     -2.7822425365448
    phi[5,6]  R1791     -3.4566419124603271e+00
    phi[5,6]  R1792     -2.7836849689483643e+00
    phi[5,6]  R1793     -4.7147005796432495e-01
    phi[5,6]  R1794     0.595619261264801
    phi[5,6]  R1795     -2.5354957580566406e+00
    phi[5,6]  R1796     -2.5732421875
    phi[5,6]  R1797     -9.6966528892517090e-01
    phi[5,6]  R1798     -2.8140428066253662e+00
    phi[5,6]  R1799     -2.6507823467254639e+00
    phi[5,6]  R1800     2.0488311350345612e-01
    phi[5,6]  R1801     -2.4206931591033936e+00
    phi[5,6]  R1802     -8.7608367204666138e-01
    phi[5,6]  R1803     -1.6060967445373535e+00
    phi[5,6]  R1804     -3.2308812141418457e+00
    phi[5,6]  R1805     -2.9620583057403564e+00
    phi[5,6]  R1806     -3.5245752334594727e+00
    phi[5,6]  R1807     -1.4354897737503052e+00
    phi[5,6]  R1808     -8.6167180538177490e-01
    phi[5,6]  R1809     -9.7583532333374023e-01
    phi[5,6]  R1810     -9.5061224699020386e-01
    phi[5,6]  R1811     -2.1341443061828613e+00
    phi[5,6]  R1812     -3.0988757610321045e+00
    phi[5,6]  R1813     -2.2457747459411621e+00
    phi[5,6]  R1814     -2.9366893768310547e+00
    phi[5,6]  R1815     -1.7260627746582031e+00
    phi[5,6]  R1816     -4.4440007209777832e-01
    phi[5,6]  R1817     -2.5723896026611328e+00
    phi[5,6]  R1818     1.1159946918487549e+00
    phi[5,6]  R1819     -3.6518317461013794e-01
    phi[5,6]  R1820     5.7520985603332520e-01
    phi[5,6]  R1821     8.6210870742797852e-01
    phi[5,6]  R1822     -1.4903119802474976e+00
    phi[5,6]  R1823     8.9394539594650269e-01
    phi[5,6]  R1824     3.5091492533683777e-01
    phi[5,6]  R1825     -4.9056446552276611e-01
    phi[5,6]  R1826     1.4721024036407471e-01
    phi[5,6]  R1827     9.3350701034069061e-02
    phi[5,6]  R1828     -1.8771171569824219e-01
    phi[5,6]  R1829     2.3729684948921204e-01
    phi[5,6]  R1830     -6.5057724714279175e-01
    phi[5,6]  R1831     -3.6815056204795837e-01
    phi[5,6]  R1832     -2.7272257804870605e+00
    phi[5,6]  R1833     -2.5189876556396484e+00
    phi[5,6]  R1834     -1.6673209667205811e+00
    phi[5,6]  R1835     -1.9247124195098877e+00
    phi[5,6]  R1836     -1.3213683366775513e+00
    phi[5,6]  R1837     -6.4024627208709717e-01
    phi[5,6]  R1838     1.2808494567871094e+00
    phi[5,6]  R1839     -1.5049009323120117e+00
    phi[5,6]  R1840     8.5438799858093262e-01
    phi[5,6]  R1841     -1.4293605089187622e-01
    phi[5,6]  R1842     0.553049623966217
    phi[5,6]  R1843     1.1266770362854004e+00
    phi[5,6]  R1844     1.6760075092315674e-01
    phi[5,6]  R1845     4.6413907408714294e-01
    phi[5,6]  R1846     -1.8053968250751495e-01
    phi[5,6]  R1847     4.1994491219520569e-01
    phi[5,6]  R1848     6.4365035295486450e-01
    phi[5,6]  R1849     -1.9188141822814941e-01
    phi[5,6]  R1850     -6.5301024913787842e-01
    phi[5,6]  R1851     -1.2399380207061768e+00
    phi[5,6]  R1852     -1.0212239027023315e+00
    phi[5,6]  R1853     -9.9627912044525146e-01
    phi[5,6]  R1854     -2.9817917943000793e-01
    phi[5,6]  R1855     -1.1890790462493896e+00
    phi[5,6]  R1856     -1.0353883504867554e+00
    phi[5,6]  R1857     -1.6944911479949951e+00
    phi[5,6]  R1858     -2.5192213058471680e-01
    phi[5,6]  R1859     -1.2882683277130127e+00
    phi[5,6]  R1860     2.0499148964881897e-01
    phi[5,6]  R1861     -1.97946035861969
    phi[5,6]  R1862     -1.1973530054092407e+00
    phi[5,6]  R1863     -1.9490445852279663e+00
    phi[5,6]  R1864     -1.8847961425781250e+00
    phi[5,6]  R1865     -1.6401908397674561e+00
    phi[5,6]  R1866     -4.8259460926055908e-01
    phi[5,6]  R1867     -1.9464302062988281e+00
    phi[5,6]  R1868     -6.6192144155502319e-01
    phi[5,6]  R1869     -1.6733224391937256e+00
    phi[5,6]  R1870     -2.5008649826049805e+00
    phi[5,6]  R1871     5.6668169796466827e-02
    phi[5,6]  R1872     -2.6952922344207764e+00
    phi[5,6]  R1873     -1.7582894563674927e+00
    phi[5,6]  R1874     -3.5733222961425781e-01
    phi[5,6]  R1875     -2.2754781246185303e+00
    phi[5,6]  R1876     -1.9918773174285889e+00
    phi[5,6]  R1877     -1.9334779679775238e-01
    phi[5,6]  R1878     -2.2467851638793945e+00
    phi[5,6]  R1879     -1.6339864730834961e+00
    phi[5,6]  R1880     -1.4262858629226685e+00
    phi[5,6]  R1881     -1.5026762485504150e+00
    phi[5,6]  R1882     -2.2523403167724609e+00
    phi[5,6]  R1883     -1.2047789096832275e+00
    phi[5,6]  R1884     5.5270552635192871e-01
    phi[5,6]  R1885     -2.3119783401489258e+00
    phi[5,6]  R1886     -2.9652902483940125e-01
    phi[5,6]  R1887     -2.08590030670166
    phi[5,6]  R1888     -1.1205933094024658e+00
    phi[5,6]  R1889     -1.2098271846771240e+00
    phi[5,6]  R1890     -8.8161420822143555e-01
    phi[5,6]  R1891     3.8365300744771957e-02
    phi[5,6]  R1892     -8.0986231565475464e-01
    phi[5,6]  R1893     -1.8443859815597534e+00
    phi[5,6]  R1894     -1.0792300701141357e+00
    phi[5,6]  R1895     -7.9451024532318115e-01
    phi[5,6]  R1896     -1.9502327442169189e+00
    phi[5,6]  R1897     -5.6438320875167847e-01
    phi[5,6]  R1898     1.3592110574245453e-01
    phi[5,6]  R1899     -4.2466154694557190e-01
    phi[5,6]  R1900     -1.8536425828933716e+00
    phi[6,5]  R45       -1
    phi[6,5]  R54       1
    phi[6,5]  R55       1
    phi[6,5]  R1901     -3.0999999046325684e+00
    phi[6,5]  R1902     -3.0999999046325684e+00
    phi[6,5]  R1903     -2.2400000095367432e+00
    phi[6,5]  R1904     -2.2400000095367432e+00
    phi[6,5]  R1905     -3.0999999046325684e+00
    phi[6,5]  R1906     -3.0999999046325684e+00
    phi[6,5]  R1907     -2.5699999332427979e+00
    phi[6,5]  R1908     -2.5699999332427979e+00
    phi[6,5]  R1909     -3.0999999046325684e+00
    phi[6,5]  R1910     -3.0999999046325684e+00
    phi[6,5]  R1911     -2.0899999141693115e+00
    phi[6,5]  R1912     -2.0899999141693115e+00
    phi[6,5]  R1913     -3.0999999046325684e+00
    phi[6,5]  R1914     -3.0999999046325684e+00
    phi[6,5]  R1915     -1.4293605089187622e-01
    phi[6,5]  R1916     0.553049623966217
    phi[6,5]  R1917     1.1266770362854004e+00
    phi[6,5]  R1918     1.6760075092315674e-01
    phi[6,5]  R1919     4.6413907408714294e-01
    phi[6,5]  R1920     -1.8053968250751495e-01
    phi[6,5]  R1921     4.1994491219520569e-01
    phi[6,5]  R1922     6.4365035295486450e-01
    phi[6,5]  R1923     -1.9188141822814941e-01
    phi[6,5]  R1924     -6.5301024913787842e-01
    phi[6,5]  R1925     -1.2399380207061768e+00
    phi[6,5]  R1926     -1.0212239027023315e+00
    phi[6,5]  R1927     -9.9627912044525146e-01
    phi[6,5]  R1928     -2.9817917943000793e-01
    phi[6,5]  R1929     -1.1890790462493896e+00
    phi[6,5]  R1930     -1.0353883504867554e+00
    phi[6,5]  R1931     -1.6944911479949951e+00
    phi[6,5]  R1932     -2.5192213058471680e-01
    phi[6,5]  R1933     -1.2882683277130127e+00
    phi[6,5]  R1934     2.0499148964881897e-01
    phi[6,5]  R1935     -1.97946035861969
    phi[6,5]  R1936     -1.1973530054092407e+00
    phi[6,5]  R1937     -1.9490445852279663e+00
    phi[6,5]  R1938     -1.8847961425781250e+00
    phi[6,5]  R1939     -1.6401908397674561e+00
    phi[6,5]  R1940     -4.8259460926055908e-01
    phi[6,5]  R1941     -1.9464302062988281e+00
    phi[6,5]  R1942     -6.6192144155502319e-01
    phi[6,5]  R1943     -1.6733224391937256e+00
    phi[6,5]  R1944     -2.5008649826049805e+00
    phi[6,5]  R1945     5.6668169796466827e-02
    phi[6,5]  R1946     -2.6952922344207764e+00
    phi[6,5]  R1947     -1.7582894563674927e+00
    phi[6,5]  R1948     -3.5733222961425781e-01
    phi[6,5]  R1949     -2.2754781246185303e+00
    phi[6,5]  R1950     -1.9918773174285889e+00
    phi[6,5]  R1951     -1.9334779679775238e-01
    phi[6,5]  R1952     -2.2467851638793945e+00
    phi[6,5]  R1953     -1.6339864730834961e+00
    phi[6,5]  R1954     -1.4262858629226685e+00
    phi[6,5]  R1955     -1.5026762485504150e+00
    phi[6,5]  R1956     -2.2523403167724609e+00
    phi[6,5]  R1957     -1.2047789096832275e+00
    phi[6,5]  R1958     5.5270552635192871e-01
    phi[6,5]  R1959     -2.3119783401489258e+00
    phi[6,5]  R1960     -2.9652902483940125e-01
    phi[6,5]  R1961     -2.08590030670166
    phi[6,5]  R1962     -1.1205933094024658e+00
    phi[6,5]  R1963     -1.2098271846771240e+00
    phi[6,5]  R1964     -8.8161420822143555e-01
    phi[6,5]  R1965     3.8365300744771957e-02
    phi[6,5]  R1966     -8.0986231565475464e-01
    phi[6,5]  R1967     -1.8443859815597534e+00
    phi[6,5]  R1968     -1.0792300701141357e+00
    phi[6,5]  R1969     -7.9451024532318115e-01
    phi[6,5]  R1970     -1.9502327442169189e+00
    phi[6,5]  R1971     -5.6438320875167847e-01
    phi[6,5]  R1972     1.3592110574245453e-01
    phi[6,5]  R1973     -4.2466154694557190e-01
    phi[6,5]  R1974     -1.8536425828933716e+00
    phi[6,5]  R1975     1.2125108242034912e+00
    phi[6,5]  R1976     9.9890762567520142e-01
    phi[6,5]  R1977     9.7437423467636108e-01
    phi[6,5]  R1978     6.5576332807540894e-01
    phi[6,5]  R1979     3.9197501540184021e-01
    phi[6,5]  R1980     2.8208884596824646e-01
    phi[6,5]  R1981     0.0126736955717206
    phi[6,5]  R1982     -3.0393150448799133e-01
    phi[6,5]  R1983     8.6660206317901611e-01
    phi[6,5]  R1984     3.8977745175361633e-01
    phi[6,5]  R1985     -2.1395599842071533e+00
    phi[6,5]  R1986     -2.1722893714904785e+00
    phi[6,5]  R1987     -1.9291379451751709e+00
    phi[6,5]  R1988     -2.0921773910522461e+00
    phi[6,5]  R1989     -2.0158741474151611e+00
    phi[6,5]  R1990     -1.4781172275543213e+00
    phi[6,5]  R1991     -1.4330282211303711e+00
    phi[6,5]  R1992     -1.8183500766754150e+00
    phi[6,5]  R1993     -3.2681903243064880e-01
    phi[6,5]  R1994     -3.5767412185668945e-01
    phi[6,5]  R1995     -2.1543724536895752e+00
    phi[6,5]  R1996     -3.5427243709564209e+00
    phi[6,5]  R1997     -2.2052223682403564e+00
    phi[6,5]  R1998     -1.1267335414886475e+00
    phi[6,5]  R1999     -1.4125297963619232e-01
    phi[6,5]  R2000     0.0756712406873703
    phi[6,5]  R2001     -3.2745990753173828e+00
    phi[6,5]  R2002     -6.2932336330413818e-01
    phi[6,5]  R2003     -1.0634574890136719e+00
    phi[6,5]  R2004     -2.7822425365448
    phi[6,5]  R2005     -3.4566419124603271e+00
    phi[6,5]  R2006     -2.7836849689483643e+00
    phi[6,5]  R2007     -4.7147005796432495e-01
    phi[6,5]  R2008     0.595619261264801
    phi[6,5]  R2009     -2.5354957580566406e+00
    phi[6,5]  R2010     -2.5732421875
    phi[6,5]  R2011     -9.6966528892517090e-01
    phi[6,5]  R2012     -2.8140428066253662e+00
    phi[6,5]  R2013     -2.6507823467254639e+00
    phi[6,5]  R2014     2.0488311350345612e-01
    phi[6,5]  R2015     -2.4206931591033936e+00
    phi[6,5]  R2016     -8.7608367204666138e-01
    phi[6,5]  R2017     -1.6060967445373535e+00
    phi[6,5]  R2018     -3.2308812141418457e+00
    phi[6,5]  R2019     -2.9620583057403564e+00
    phi[6,5]  R2020     -3.5245752334594727e+00
    phi[6,5]  R2021     -1.4354897737503052e+00
    phi[6,5]  R2022     -8.6167180538177490e-01
    phi[6,5]  R2023     -9.7583532333374023e-01
    phi[6,5]  R2024     -9.5061224699020386e-01
    phi[6,5]  R2025     -2.1341443061828613e+00
    phi[6,5]  R2026     -3.0988757610321045e+00
    phi[6,5]  R2027     -2.2457747459411621e+00
    phi[6,5]  R2028     -2.9366893768310547e+00
    phi[6,5]  R2029     -1.7260627746582031e+00
    phi[6,5]  R2030     -4.4440007209777832e-01
    phi[6,5]  R2031     -2.5723896026611328e+00
    phi[6,5]  R2032     1.1159946918487549e+00
    phi[6,5]  R2033     -3.6518317461013794e-01
    phi[6,5]  R2034     5.7520985603332520e-01
    phi[6,5]  R2035     8.6210870742797852e-01
    phi[6,5]  R2036     -1.4903119802474976e+00
    phi[6,5]  R2037     8.9394539594650269e-01
    phi[6,5]  R2038     3.5091492533683777e-01
    phi[6,5]  R2039     -4.9056446552276611e-01
    phi[6,5]  R2040     1.4721024036407471e-01
    phi[6,5]  R2041     9.3350701034069061e-02
    phi[6,5]  R2042     -1.8771171569824219e-01
    phi[6,5]  R2043     2.3729684948921204e-01
    phi[6,5]  R2044     -6.5057724714279175e-01
    phi[6,5]  R2045     -3.6815056204795837e-01
    phi[6,5]  R2046     -2.7272257804870605e+00
    phi[6,5]  R2047     -2.5189876556396484e+00
    phi[6,5]  R2048     -1.6673209667205811e+00
    phi[6,5]  R2049     -1.9247124195098877e+00
    phi[6,5]  R2050     -1.3213683366775513e+00
    phi[6,5]  R2051     -6.4024627208709717e-01
    phi[6,5]  R2052     1.2808494567871094e+00
    phi[6,5]  R2053     -1.5049009323120117e+00
    phi[6,5]  R2054     8.5438799858093262e-01
    phi[9,5]  R45       -1
    phi[9,5]  R47       8.9151355193732673e-01
    phi[9,5]  R48       -1.9177123578251334e+00
    phi[9,5]  R49       2.1322907731828433e-01
    phi[9,5]  R50       1.9859976103431927e+00
    phi[9,5]  R51       2.9217173991106464e+00
    phi[9,5]  R52       -1.4770704335377525e+00
    phi[9,5]  R53       -1.6903897965958561e+00
    phi[9,5]  R81       1
    phi[9,5]  R2055     -3.9915134565698951e+00
    phi[9,5]  R2056     -2.2084863526952416e+00
    phi[9,5]  R2057     -3.2228765171160978e-01
    phi[9,5]  R2058     -4.1577123673618761e+00
    phi[9,5]  R2059     -3.3132289819508527e+00
    phi[9,5]  R2060     -2.8867708273142840e+00
    phi[9,5]  R2061     -4.55599754358599
    phi[9,5]  R2062     -5.8400232289960519e-01
    phi[9,5]  R2063     -6.0217173037432143e+00
    phi[9,5]  R2064     -1.7828250552192193e-01
    phi[9,5]  R2065     -0.612929480631559
    phi[9,5]  R2066     -3.5670703477070642e+00
    phi[9,5]  R2067     -1.4096101080367123e+00
    phi[9,5]  R2068     -4.7903897012284240e+00
    phi[9,5]  R2069     -3.3148394843607787e-01
    phi[9,5]  R2070     -3.3599487185372956e-01
    phi[9,5]  R2071     -3.3686637756749138e-01
    phi[9,5]  R2072     -1.1712391168945118e+00
    phi[9,5]  R2073     -4.0551943838138127e-01
    phi[9,5]  R2074     -8.8921356138260288e-01
    phi[9,5]  R2075     -1.0423078430427042e+00
    phi[9,5]  R2076     -5.2746216434240611e-01
    phi[9,5]  R2077     -1.1237553208489970e+00
    phi[9,5]  R2078     -1.2826927859243298e+00
    phi[9,5]  R2079     -2.5910961959128476e-01
    phi[9,5]  R2080     -2.6859742003983822e-01
    phi[9,5]  R2081     -3.0166446144872294e-01
    phi[9,5]  R2082     -3.1385412388625045e-01
    phi[9,5]  R2083     -3.2376334190357392e-01
    phi[9,5]  R2084     -3.4080401846964259e-01
    phi[9,5]  R2085     -3.5706883718001792e-01
    phi[9,5]  R2086     -3.8899154908898526e-01
    phi[9,5]  R2087     -3.9934523591500670e-01
    phi[9,5]  R2088     -4.7299378991342839e-01
    phi[9,5]  R2089     -2.4712815488067363e-01
    phi[9,5]  R2090     -2.6075901880315744e-01
    phi[9,5]  R2091     -2.6366330664219695e-01
    phi[9,5]  R2092     -2.8881732220281331e-01
    phi[9,5]  R2093     -2.9189843587401609e-01
    phi[9,5]  R2094     -2.9365703190793313e-01
    phi[9,5]  R2095     -3.0301431687542735e-01
    phi[9,5]  R2096     -3.0845006046085655e-01
    phi[9,5]  R2097     -3.2395557614574888e-01
    phi[9,5]  R2098     -3.3064094777642028e-01
    phi[9,5]  R2099     -2.4157837064045795e-01
    phi[9,5]  R2100     -2.4531607615521933e-01
    phi[9,5]  R2101     -2.5968898189484907e-01
    phi[9,5]  R2102     -2.6235357989568830e-01
    phi[9,5]  R2103     -2.6389422343535029e-01
    phi[9,5]  R2104     -2.8517244397245278e-01
    phi[9,5]  R2105     -2.8898485505492122e-01
    phi[9,5]  R2106     -3.0631050694836315e-01
    phi[9,5]  R2107     -3.1052656589444450e-01
    phi[9,5]  R2108     -3.1139410459177785e-01
    phi[9,5]  R2109     -2.3904654846170237e-01
    phi[9,5]  R2110     -2.4978959063987971e-01
    phi[9,5]  R2111     -2.5246130349772877e-01
    phi[9,5]  R2112     -2.5967589069060759e-01
    phi[9,5]  R2113     -2.7434148101552935e-01
    phi[9,5]  R2114     -2.8601994122972796e-01
    phi[9,5]  R2115     -2.9079914259495321e-01
    phi[9,5]  R2116     -3.0442922127885608e-01
    phi[9,5]  R2117     -3.1332543199917928e-01
    phi[9,5]  R2118     -3.2484145756172089e-01
    phi[9,5]  R2119     -1.8824231120585666e-01
    phi[9,5]  R2120     -2.0882520389953019e-01
    phi[9,5]  R2121     -2.4462832555576952e-01
    phi[9,5]  R2122     -2.6085881204943595e-01
    phi[9,5]  R2123     -2.9332414454421785e-01
    phi[9,5]  R2124     -2.9343545128523363e-01
    phi[9,5]  R2125     -2.9650912682379449e-01
    phi[9,5]  R2126     -3.1613123130992737e-01
    phi[9,5]  R2127     -0.362487416021921
    phi[9,5]  R2128     -3.7561797838678956e-01
    phi[9,5]  R2129     -3.2129971086682518e-01
    phi[9,5]  R2130     -3.4649385694155588e-01
    phi[9,5]  R2131     -3.6410569578366991e-01
    phi[9,5]  R2132     -4.4250043882293777e-01
    phi[9,5]  R2133     -1.0958387822300606e+00
    phi[9,5]  R2134     -4.5244150483570722e-01
    phi[9,5]  R2135     -4.5565987425395704e-01
    phi[9,5]  R2136     -4.6193125839181970e-01
    phi[9,5]  R2137     -4.6618648154427156e-01
    phi[9,5]  R2138     -4.7269190423151003e-01
    phi[9,5]  R2139     -0.25452854278365
    phi[9,5]  R2140     -2.5839363014689232e-01
    phi[9,5]  R2141     -2.7764449323028950e-01
    phi[9,5]  R2142     -2.9672289643016181e-01
    phi[9,5]  R2143     -3.0126080875209116e-01
    phi[9,5]  R2144     -3.1254724333600481e-01
    phi[9,5]  R2145     -3.1476137149402406e-01
    phi[9,5]  R2146     -0.318571966719881
    phi[9,5]  R2147     -3.3524183764440152e-01
    phi[9,5]  R2148     -3.3851985025304243e-01
    phi[6,7]  R54       1
    phi[6,7]  R55       1
    phi[6,7]  R63       -1
    phi[6,7]  R2149     -3.0999999046325684e+00
    phi[6,7]  R2150     -3.0999999046325684e+00
    phi[6,7]  R2151     -2.2400000095367432e+00
    phi[6,7]  R2152     -2.2400000095367432e+00
    phi[6,7]  R2153     -3.0999999046325684e+00
    phi[6,7]  R2154     -3.0999999046325684e+00
    phi[6,7]  R2155     -2.5699999332427979e+00
    phi[6,7]  R2156     -2.5699999332427979e+00
    phi[6,7]  R2157     -3.0999999046325684e+00
    phi[6,7]  R2158     -3.0999999046325684e+00
    phi[6,7]  R2159     -2.0899999141693115e+00
    phi[6,7]  R2160     -2.0899999141693115e+00
    phi[6,7]  R2161     -3.0999999046325684e+00
    phi[6,7]  R2162     -3.0999999046325684e+00
    phi[6,7]  R2163     -1.4293605089187622e-01
    phi[6,7]  R2164     0.553049623966217
    phi[6,7]  R2165     1.1266770362854004e+00
    phi[6,7]  R2166     1.6760075092315674e-01
    phi[6,7]  R2167     4.6413907408714294e-01
    phi[6,7]  R2168     -1.8053968250751495e-01
    phi[6,7]  R2169     4.1994491219520569e-01
    phi[6,7]  R2170     6.4365035295486450e-01
    phi[6,7]  R2171     -1.9188141822814941e-01
    phi[6,7]  R2172     -6.5301024913787842e-01
    phi[6,7]  R2173     -1.2399380207061768e+00
    phi[6,7]  R2174     -1.0212239027023315e+00
    phi[6,7]  R2175     -9.9627912044525146e-01
    phi[6,7]  R2176     -2.9817917943000793e-01
    phi[6,7]  R2177     -1.1890790462493896e+00
    phi[6,7]  R2178     -1.0353883504867554e+00
    phi[6,7]  R2179     -1.6944911479949951e+00
    phi[6,7]  R2180     -2.5192213058471680e-01
    phi[6,7]  R2181     -1.2882683277130127e+00
    phi[6,7]  R2182     2.0499148964881897e-01
    phi[6,7]  R2183     -1.97946035861969
    phi[6,7]  R2184     -1.1973530054092407e+00
    phi[6,7]  R2185     -1.9490445852279663e+00
    phi[6,7]  R2186     -1.8847961425781250e+00
    phi[6,7]  R2187     -1.6401908397674561e+00
    phi[6,7]  R2188     -4.8259460926055908e-01
    phi[6,7]  R2189     -1.9464302062988281e+00
    phi[6,7]  R2190     -6.6192144155502319e-01
    phi[6,7]  R2191     -1.6733224391937256e+00
    phi[6,7]  R2192     -2.5008649826049805e+00
    phi[6,7]  R2193     5.6668169796466827e-02
    phi[6,7]  R2194     -2.6952922344207764e+00
    phi[6,7]  R2195     -1.7582894563674927e+00
    phi[6,7]  R2196     -3.5733222961425781e-01
    phi[6,7]  R2197     -2.2754781246185303e+00
    phi[6,7]  R2198     -1.9918773174285889e+00
    phi[6,7]  R2199     -1.9334779679775238e-01
    phi[6,7]  R2200     -2.2467851638793945e+00
    phi[6,7]  R2201     -1.6339864730834961e+00
    phi[6,7]  R2202     -1.4262858629226685e+00
    phi[6,7]  R2203     -1.5026762485504150e+00
    phi[6,7]  R2204     -2.2523403167724609e+00
    phi[6,7]  R2205     -1.2047789096832275e+00
    phi[6,7]  R2206     5.5270552635192871e-01
    phi[6,7]  R2207     -2.3119783401489258e+00
    phi[6,7]  R2208     -2.9652902483940125e-01
    phi[6,7]  R2209     -2.08590030670166
    phi[6,7]  R2210     -1.1205933094024658e+00
    phi[6,7]  R2211     -1.2098271846771240e+00
    phi[6,7]  R2212     -8.8161420822143555e-01
    phi[6,7]  R2213     3.8365300744771957e-02
    phi[6,7]  R2214     -8.0986231565475464e-01
    phi[6,7]  R2215     -1.8443859815597534e+00
    phi[6,7]  R2216     -1.0792300701141357e+00
    phi[6,7]  R2217     -7.9451024532318115e-01
    phi[6,7]  R2218     -1.9502327442169189e+00
    phi[6,7]  R2219     -5.6438320875167847e-01
    phi[6,7]  R2220     1.3592110574245453e-01
    phi[6,7]  R2221     -4.2466154694557190e-01
    phi[6,7]  R2222     -1.8536425828933716e+00
    phi[6,7]  R2223     2.3669340610504150e+00
    phi[6,7]  R2224     2.4439461231231689e+00
    phi[6,7]  R2225     6.1196142435073853e-01
    phi[6,7]  R2226     1.8750554323196411e+00
    phi[6,7]  R2227     2.0208237171173096e+00
    phi[6,7]  R2228     1.7374224662780762e+00
    phi[6,7]  R2229     2.0247740745544434e+00
    phi[6,7]  R2230     2.5428273677825928e+00
    phi[6,7]  R2231     1.6661462783813477e+00
    phi[6,7]  R2232     4.4815289974212646e-01
    phi[6,7]  R2233     4.2888522148132324e-02
    phi[6,7]  R2234     -1.2493376731872559e+00
    phi[6,7]  R2235     -5.1478540897369385e-01
    phi[6,7]  R2236     -3.2334128022193909e-01
    phi[6,7]  R2237     -2.7164316177368164e-01
    phi[6,7]  R2238     -4.7594380378723145e-01
    phi[6,7]  R2239     -3.0129078030586243e-01
    phi[6,7]  R2240     -0.578376293182373
    phi[6,7]  R2241     -2.4969993159174919e-02
    phi[6,7]  R2242     1.1803740635514259e-02
    phi[6,7]  R2243     -1.9001425504684448e+00
    phi[6,7]  R2244     -2.6127200126647949e+00
    phi[6,7]  R2245     -2.7495787143707275e+00
    phi[6,7]  R2246     -1.7910457849502563e+00
    phi[6,7]  R2247     -2.2600023746490479e+00
    phi[6,7]  R2248     -1.2984979152679443e+00
    phi[6,7]  R2249     -1.6983900070190430e+00
    phi[6,7]  R2250     -1.4165360927581787e+00
    phi[6,7]  R2251     -0.401524156332016
    phi[6,7]  R2252     -2.7484686374664307e+00
    phi[6,7]  R2253     1.0922209173440933e-01
    phi[6,7]  R2254     -5.1007527112960815e-01
    phi[6,7]  R2255     -1.1758953332901
    phi[6,7]  R2256     -1.3210350275039673e+00
    phi[6,7]  R2257     -2.4638223648071289e+00
    phi[6,7]  R2258     -1.9018605947494507e+00
    phi[6,7]  R2259     -1.1938767433166504e+00
    phi[6,7]  R2260     -2.2466106414794922e+00
    phi[6,7]  R2261     -2.1679165363311768e+00
    phi[6,7]  R2262     -2.4357869625091553e+00
    phi[6,7]  R2263     -1.2956511974334717e+00
    phi[6,7]  R2264     -2.4122781753540039e+00
    phi[6,7]  R2265     -6.5476131439208984e-01
    phi[6,7]  R2266     -1.9200632572174072e+00
    phi[6,7]  R2267     -1.7166398763656616e+00
    phi[6,7]  R2268     -1.4825946092605591e+00
    phi[6,7]  R2269     -2.4798967838287354e+00
    phi[6,7]  R2270     -1.8017432689666748e+00
    phi[6,7]  R2271     -1.8332495689392090e+00
    phi[6,7]  R2272     -1.9975116252899170e+00
    phi[7,6]  R54       -1
    phi[7,6]  R63       1
    phi[7,6]  R64       1
    phi[7,6]  R2273     -3.0999999046325684e+00
    phi[7,6]  R2274     -3.0999999046325684e+00
    phi[7,6]  R2275     -2.2400000095367432e+00
    phi[7,6]  R2276     -2.2400000095367432e+00
    phi[7,6]  R2277     -3.0999999046325684e+00
    phi[7,6]  R2278     -3.0999999046325684e+00
    phi[7,6]  R2279     -2.5699999332427979e+00
    phi[7,6]  R2280     -2.5699999332427979e+00
    phi[7,6]  R2281     -3.0999999046325684e+00
    phi[7,6]  R2282     -3.0999999046325684e+00
    phi[7,6]  R2283     -2.0899999141693115e+00
    phi[7,6]  R2284     -2.0899999141693115e+00
    phi[7,6]  R2285     -3.0999999046325684e+00
    phi[7,6]  R2286     -3.0999999046325684e+00
    phi[7,6]  R2287     2.3669340610504150e+00
    phi[7,6]  R2288     2.4439461231231689e+00
    phi[7,6]  R2289     6.1196142435073853e-01
    phi[7,6]  R2290     1.8750554323196411e+00
    phi[7,6]  R2291     2.0208237171173096e+00
    phi[7,6]  R2292     1.7374224662780762e+00
    phi[7,6]  R2293     2.0247740745544434e+00
    phi[7,6]  R2294     2.5428273677825928e+00
    phi[7,6]  R2295     1.6661462783813477e+00
    phi[7,6]  R2296     4.4815289974212646e-01
    phi[7,6]  R2297     4.2888522148132324e-02
    phi[7,6]  R2298     -1.2493376731872559e+00
    phi[7,6]  R2299     -5.1478540897369385e-01
    phi[7,6]  R2300     -3.2334128022193909e-01
    phi[7,6]  R2301     -2.7164316177368164e-01
    phi[7,6]  R2302     -4.7594380378723145e-01
    phi[7,6]  R2303     -3.0129078030586243e-01
    phi[7,6]  R2304     -0.578376293182373
    phi[7,6]  R2305     -2.4969993159174919e-02
    phi[7,6]  R2306     1.1803740635514259e-02
    phi[7,6]  R2307     -1.9001425504684448e+00
    phi[7,6]  R2308     -2.6127200126647949e+00
    phi[7,6]  R2309     -2.7495787143707275e+00
    phi[7,6]  R2310     -1.7910457849502563e+00
    phi[7,6]  R2311     -2.2600023746490479e+00
    phi[7,6]  R2312     -1.2984979152679443e+00
    phi[7,6]  R2313     -1.6983900070190430e+00
    phi[7,6]  R2314     -1.4165360927581787e+00
    phi[7,6]  R2315     -0.401524156332016
    phi[7,6]  R2316     -2.7484686374664307e+00
    phi[7,6]  R2317     1.0922209173440933e-01
    phi[7,6]  R2318     -5.1007527112960815e-01
    phi[7,6]  R2319     -1.1758953332901
    phi[7,6]  R2320     -1.3210350275039673e+00
    phi[7,6]  R2321     -2.4638223648071289e+00
    phi[7,6]  R2322     -1.9018605947494507e+00
    phi[7,6]  R2323     -1.1938767433166504e+00
    phi[7,6]  R2324     -2.2466106414794922e+00
    phi[7,6]  R2325     -2.1679165363311768e+00
    phi[7,6]  R2326     -2.4357869625091553e+00
    phi[7,6]  R2327     -1.2956511974334717e+00
    phi[7,6]  R2328     -2.4122781753540039e+00
    phi[7,6]  R2329     -6.5476131439208984e-01
    phi[7,6]  R2330     -1.9200632572174072e+00
    phi[7,6]  R2331     -1.7166398763656616e+00
    phi[7,6]  R2332     -1.4825946092605591e+00
    phi[7,6]  R2333     -2.4798967838287354e+00
    phi[7,6]  R2334     -1.8017432689666748e+00
    phi[7,6]  R2335     -1.8332495689392090e+00
    phi[7,6]  R2336     -1.9975116252899170e+00
    phi[7,6]  R2337     -1.4293605089187622e-01
    phi[7,6]  R2338     0.553049623966217
    phi[7,6]  R2339     1.1266770362854004e+00
    phi[7,6]  R2340     1.6760075092315674e-01
    phi[7,6]  R2341     4.6413907408714294e-01
    phi[7,6]  R2342     -1.8053968250751495e-01
    phi[7,6]  R2343     4.1994491219520569e-01
    phi[7,6]  R2344     6.4365035295486450e-01
    phi[7,6]  R2345     -1.9188141822814941e-01
    phi[7,6]  R2346     -6.5301024913787842e-01
    phi[7,6]  R2347     -1.2399380207061768e+00
    phi[7,6]  R2348     -1.0212239027023315e+00
    phi[7,6]  R2349     -9.9627912044525146e-01
    phi[7,6]  R2350     -2.9817917943000793e-01
    phi[7,6]  R2351     -1.1890790462493896e+00
    phi[7,6]  R2352     -1.0353883504867554e+00
    phi[7,6]  R2353     -1.6944911479949951e+00
    phi[7,6]  R2354     -2.5192213058471680e-01
    phi[7,6]  R2355     -1.2882683277130127e+00
    phi[7,6]  R2356     2.0499148964881897e-01
    phi[7,6]  R2357     -1.97946035861969
    phi[7,6]  R2358     -1.1973530054092407e+00
    phi[7,6]  R2359     -1.9490445852279663e+00
    phi[7,6]  R2360     -1.8847961425781250e+00
    phi[7,6]  R2361     -1.6401908397674561e+00
    phi[7,6]  R2362     -4.8259460926055908e-01
    phi[7,6]  R2363     -1.9464302062988281e+00
    phi[7,6]  R2364     -6.6192144155502319e-01
    phi[7,6]  R2365     -1.6733224391937256e+00
    phi[7,6]  R2366     -2.5008649826049805e+00
    phi[7,6]  R2367     5.6668169796466827e-02
    phi[7,6]  R2368     -2.6952922344207764e+00
    phi[7,6]  R2369     -1.7582894563674927e+00
    phi[7,6]  R2370     -3.5733222961425781e-01
    phi[7,6]  R2371     -2.2754781246185303e+00
    phi[7,6]  R2372     -1.9918773174285889e+00
    phi[7,6]  R2373     -1.9334779679775238e-01
    phi[7,6]  R2374     -2.2467851638793945e+00
    phi[7,6]  R2375     -1.6339864730834961e+00
    phi[7,6]  R2376     -1.4262858629226685e+00
    phi[7,6]  R2377     -1.5026762485504150e+00
    phi[7,6]  R2378     -2.2523403167724609e+00
    phi[7,6]  R2379     -1.2047789096832275e+00
    phi[7,6]  R2380     5.5270552635192871e-01
    phi[7,6]  R2381     -2.3119783401489258e+00
    phi[7,6]  R2382     -2.9652902483940125e-01
    phi[7,6]  R2383     -2.08590030670166
    phi[7,6]  R2384     -1.1205933094024658e+00
    phi[7,6]  R2385     -1.2098271846771240e+00
    phi[7,6]  R2386     -8.8161420822143555e-01
    phi[7,6]  R2387     3.8365300744771957e-02
    phi[7,6]  R2388     -8.0986231565475464e-01
    phi[7,6]  R2389     -1.8443859815597534e+00
    phi[7,6]  R2390     -1.0792300701141357e+00
    phi[7,6]  R2391     -7.9451024532318115e-01
    phi[7,6]  R2392     -1.9502327442169189e+00
    phi[7,6]  R2393     -5.6438320875167847e-01
    phi[7,6]  R2394     1.3592110574245453e-01
    phi[7,6]  R2395     -4.2466154694557190e-01
    phi[7,6]  R2396     -1.8536425828933716e+00
    phi[7,8]  R63       1
    phi[7,8]  R64       1
    phi[7,8]  R72       -1
    phi[7,8]  R2397     -3.0999999046325684e+00
    phi[7,8]  R2398     -3.0999999046325684e+00
    phi[7,8]  R2399     -2.2400000095367432e+00
    phi[7,8]  R2400     -2.2400000095367432e+00
    phi[7,8]  R2401     -3.0999999046325684e+00
    phi[7,8]  R2402     -3.0999999046325684e+00
    phi[7,8]  R2403     -2.5699999332427979e+00
    phi[7,8]  R2404     -2.5699999332427979e+00
    phi[7,8]  R2405     -3.0999999046325684e+00
    phi[7,8]  R2406     -3.0999999046325684e+00
    phi[7,8]  R2407     -2.0899999141693115e+00
    phi[7,8]  R2408     -2.0899999141693115e+00
    phi[7,8]  R2409     -3.0999999046325684e+00
    phi[7,8]  R2410     -3.0999999046325684e+00
    phi[7,8]  R2411     2.3669340610504150e+00
    phi[7,8]  R2412     2.4439461231231689e+00
    phi[7,8]  R2413     6.1196142435073853e-01
    phi[7,8]  R2414     1.8750554323196411e+00
    phi[7,8]  R2415     2.0208237171173096e+00
    phi[7,8]  R2416     1.7374224662780762e+00
    phi[7,8]  R2417     2.0247740745544434e+00
    phi[7,8]  R2418     2.5428273677825928e+00
    phi[7,8]  R2419     1.6661462783813477e+00
    phi[7,8]  R2420     4.4815289974212646e-01
    phi[7,8]  R2421     4.2888522148132324e-02
    phi[7,8]  R2422     -1.2493376731872559e+00
    phi[7,8]  R2423     -5.1478540897369385e-01
    phi[7,8]  R2424     -3.2334128022193909e-01
    phi[7,8]  R2425     -2.7164316177368164e-01
    phi[7,8]  R2426     -4.7594380378723145e-01
    phi[7,8]  R2427     -3.0129078030586243e-01
    phi[7,8]  R2428     -0.578376293182373
    phi[7,8]  R2429     -2.4969993159174919e-02
    phi[7,8]  R2430     1.1803740635514259e-02
    phi[7,8]  R2431     -1.9001425504684448e+00
    phi[7,8]  R2432     -2.6127200126647949e+00
    phi[7,8]  R2433     -2.7495787143707275e+00
    phi[7,8]  R2434     -1.7910457849502563e+00
    phi[7,8]  R2435     -2.2600023746490479e+00
    phi[7,8]  R2436     -1.2984979152679443e+00
    phi[7,8]  R2437     -1.6983900070190430e+00
    phi[7,8]  R2438     -1.4165360927581787e+00
    phi[7,8]  R2439     -0.401524156332016
    phi[7,8]  R2440     -2.7484686374664307e+00
    phi[7,8]  R2441     1.0922209173440933e-01
    phi[7,8]  R2442     -5.1007527112960815e-01
    phi[7,8]  R2443     -1.1758953332901
    phi[7,8]  R2444     -1.3210350275039673e+00
    phi[7,8]  R2445     -2.4638223648071289e+00
    phi[7,8]  R2446     -1.9018605947494507e+00
    phi[7,8]  R2447     -1.1938767433166504e+00
    phi[7,8]  R2448     -2.2466106414794922e+00
    phi[7,8]  R2449     -2.1679165363311768e+00
    phi[7,8]  R2450     -2.4357869625091553e+00
    phi[7,8]  R2451     -1.2956511974334717e+00
    phi[7,8]  R2452     -2.4122781753540039e+00
    phi[7,8]  R2453     -6.5476131439208984e-01
    phi[7,8]  R2454     -1.9200632572174072e+00
    phi[7,8]  R2455     -1.7166398763656616e+00
    phi[7,8]  R2456     -1.4825946092605591e+00
    phi[7,8]  R2457     -2.4798967838287354e+00
    phi[7,8]  R2458     -1.8017432689666748e+00
    phi[7,8]  R2459     -1.8332495689392090e+00
    phi[7,8]  R2460     -1.9975116252899170e+00
    phi[7,8]  R2461     1.4948843717575073e+00
    phi[7,8]  R2462     2.5692541599273682e+00
    phi[7,8]  R2463     1.2411298751831055e+00
    phi[7,8]  R2464     1.3812897205352783e+00
    phi[7,8]  R2465     1.4594970941543579e+00
    phi[7,8]  R2466     1.3877192735671997e+00
    phi[7,8]  R2467     1.4981322288513184e+00
    phi[7,8]  R2468     -1.1706575155258179e+00
    phi[7,8]  R2469     -7.7520543336868286e-01
    phi[7,8]  R2470     -2.1378141641616821e-01
    phi[7,8]  R2471     -2.2091298103332520e+00
    phi[7,8]  R2472     -2.4698002338409424e+00
    phi[7,8]  R2473     -1.6824862957000732e+00
    phi[7,8]  R2474     -1.1279288530349731e+00
    phi[7,8]  R2475     -7.8519582748413086e-01
    phi[7,8]  R2476     -7.4534124135971069e-01
    phi[7,8]  R2477     -1.0448693037033081e+00
    phi[7,8]  R2478     -1.1448354721069336e+00
    phi[8,7]  R63       -1
    phi[8,7]  R72       1
    phi[8,7]  R73       1
    phi[8,7]  R2479     -3.0999999046325684e+00
    phi[8,7]  R2480     -3.0999999046325684e+00
    phi[8,7]  R2481     -2.2400000095367432e+00
    phi[8,7]  R2482     -2.2400000095367432e+00
    phi[8,7]  R2483     -3.0999999046325684e+00
    phi[8,7]  R2484     -3.0999999046325684e+00
    phi[8,7]  R2485     -2.5699999332427979e+00
    phi[8,7]  R2486     -2.5699999332427979e+00
    phi[8,7]  R2487     -3.0999999046325684e+00
    phi[8,7]  R2488     -3.0999999046325684e+00
    phi[8,7]  R2489     -2.0899999141693115e+00
    phi[8,7]  R2490     -2.0899999141693115e+00
    phi[8,7]  R2491     -3.0999999046325684e+00
    phi[8,7]  R2492     -3.0999999046325684e+00
    phi[8,7]  R2493     1.4948843717575073e+00
    phi[8,7]  R2494     2.5692541599273682e+00
    phi[8,7]  R2495     1.2411298751831055e+00
    phi[8,7]  R2496     1.3812897205352783e+00
    phi[8,7]  R2497     1.4594970941543579e+00
    phi[8,7]  R2498     1.3877192735671997e+00
    phi[8,7]  R2499     1.4981322288513184e+00
    phi[8,7]  R2500     -1.1706575155258179e+00
    phi[8,7]  R2501     -7.7520543336868286e-01
    phi[8,7]  R2502     -2.1378141641616821e-01
    phi[8,7]  R2503     -2.2091298103332520e+00
    phi[8,7]  R2504     -2.4698002338409424e+00
    phi[8,7]  R2505     -1.6824862957000732e+00
    phi[8,7]  R2506     -1.1279288530349731e+00
    phi[8,7]  R2507     -7.8519582748413086e-01
    phi[8,7]  R2508     -7.4534124135971069e-01
    phi[8,7]  R2509     -1.0448693037033081e+00
    phi[8,7]  R2510     -1.1448354721069336e+00
    phi[8,7]  R2511     2.3669340610504150e+00
    phi[8,7]  R2512     2.4439461231231689e+00
    phi[8,7]  R2513     6.1196142435073853e-01
    phi[8,7]  R2514     1.8750554323196411e+00
    phi[8,7]  R2515     2.0208237171173096e+00
    phi[8,7]  R2516     1.7374224662780762e+00
    phi[8,7]  R2517     2.0247740745544434e+00
    phi[8,7]  R2518     2.5428273677825928e+00
    phi[8,7]  R2519     1.6661462783813477e+00
    phi[8,7]  R2520     4.4815289974212646e-01
    phi[8,7]  R2521     4.2888522148132324e-02
    phi[8,7]  R2522     -1.2493376731872559e+00
    phi[8,7]  R2523     -5.1478540897369385e-01
    phi[8,7]  R2524     -3.2334128022193909e-01
    phi[8,7]  R2525     -2.7164316177368164e-01
    phi[8,7]  R2526     -4.7594380378723145e-01
    phi[8,7]  R2527     -3.0129078030586243e-01
    phi[8,7]  R2528     -0.578376293182373
    phi[8,7]  R2529     -2.4969993159174919e-02
    phi[8,7]  R2530     1.1803740635514259e-02
    phi[8,7]  R2531     -1.9001425504684448e+00
    phi[8,7]  R2532     -2.6127200126647949e+00
    phi[8,7]  R2533     -2.7495787143707275e+00
    phi[8,7]  R2534     -1.7910457849502563e+00
    phi[8,7]  R2535     -2.2600023746490479e+00
    phi[8,7]  R2536     -1.2984979152679443e+00
    phi[8,7]  R2537     -1.6983900070190430e+00
    phi[8,7]  R2538     -1.4165360927581787e+00
    phi[8,7]  R2539     -0.401524156332016
    phi[8,7]  R2540     -2.7484686374664307e+00
    phi[8,7]  R2541     1.0922209173440933e-01
    phi[8,7]  R2542     -5.1007527112960815e-01
    phi[8,7]  R2543     -1.1758953332901
    phi[8,7]  R2544     -1.3210350275039673e+00
    phi[8,7]  R2545     -2.4638223648071289e+00
    phi[8,7]  R2546     -1.9018605947494507e+00
    phi[8,7]  R2547     -1.1938767433166504e+00
    phi[8,7]  R2548     -2.2466106414794922e+00
    phi[8,7]  R2549     -2.1679165363311768e+00
    phi[8,7]  R2550     -2.4357869625091553e+00
    phi[8,7]  R2551     -1.2956511974334717e+00
    phi[8,7]  R2552     -2.4122781753540039e+00
    phi[8,7]  R2553     -6.5476131439208984e-01
    phi[8,7]  R2554     -1.9200632572174072e+00
    phi[8,7]  R2555     -1.7166398763656616e+00
    phi[8,7]  R2556     -1.4825946092605591e+00
    phi[8,7]  R2557     -2.4798967838287354e+00
    phi[8,7]  R2558     -1.8017432689666748e+00
    phi[8,7]  R2559     -1.8332495689392090e+00
    phi[8,7]  R2560     -1.9975116252899170e+00
    phi[8,10]  R72       1
    phi[8,10]  R73       1
    phi[8,10]  R74       2.2015075818676695e+00
    phi[8,10]  R75       1.2555005905551371e+00
    phi[8,10]  R76       -2.3962911148857420e+00
    phi[8,10]  R77       -2.5093355321458106e+00
    phi[8,10]  R78       1.1050770722541126e+00
    phi[8,10]  R79       -3.3966445622447283e-01
    phi[8,10]  R80       1.0601281308923380e+00
    phi[8,10]  R82       -1
    phi[8,10]  R2561     -8.9849232276489888e-01
    phi[8,10]  R2562     -5.3015074865002383e+00
    phi[8,10]  R2563     -9.8449941898160609e-01
    phi[8,10]  R2564     -3.49550060009188
    phi[8,10]  R2565     -5.49629101951831
    phi[8,10]  R2566     -7.0370878974682638e-01
    phi[8,10]  R2567     -5.0793354653886080e+00
    phi[8,10]  R2568     -6.0664401096987230e-02
    phi[8,10]  R2569     -1.9949228323784558e+00
    phi[8,10]  R2570     -4.2050769768866809e+00
    phi[8,10]  R2571     -2.4296643703937844e+00
    phi[8,10]  R2572     -1.7503354579448387e+00
    phi[8,10]  R2573     -2.0398717737402303e+00
    phi[8,10]  R2574     -4.1601280355249060e+00
    phi[8,10]  R2575     -1.7279342739002557e-02
    phi[8,10]  R2576     -1.7306414932866332e-02
    phi[8,10]  R2577     -2.0802115017443112e-02
    phi[8,10]  R2578     -3.3305925709755435e-02
    phi[8,10]  R2579     -3.4720700475297406e-02
    phi[8,10]  R2580     -3.7576910820842357e-02
    phi[8,10]  R2581     -1.3912973860201672e-01
    phi[8,10]  R2582     -3.0613278997098536e-01
    phi[8,10]  R2583     -2.4497167072800963e+00
    phi[8,10]  R2584     -7.7279177554398087e-02
    phi[8,10]  R2585     -1.0522581434595457e-01
    phi[8,10]  R2586     -1.1188780102747176e-01
    phi[8,10]  R2587     -1.1641007248859325e-01
    phi[8,10]  R2588     -8.5364676745772017e-01
    phi[8,10]  R2589     -9.8695812032278663e-01
    phi[8,10]  R2590     -1.6926062791039123e+00
    phi[8,10]  R2591     -2.5957001278147991e+00
    phi[8,10]  R2592     -3.7409277447185705e+00
    MARKER    'MARKER'                 'INTEND'
    z[0,1,0]  R2        -1
    z[0,1,0]  R11       1
    z[0,1,0]  R83       -1
    z[0,1,0]  R84       1
    z[0,1,0]  R97       -3.6848965287208557e-01
    z[0,1,0]  R98       7.4506118893623352e-02
    z[0,1,0]  R99       -4.3569985032081604e-01
    z[0,1,0]  R100      5.7732496410608292e-02
    z[0,1,0]  R101      -1.1502807587385178e-01
    z[0,1,0]  R102      -2.4476386606693268e-01
    z[0,1,0]  R103      2.2146110236644745e-01
    z[0,1,0]  R104      6.8804420530796051e-02
    z[0,1,0]  R105      -5.7788819074630737e-02
    z[0,1,0]  R106      1.6723388433456421e-01
    z[0,1,0]  R107      -2.5952938199043274e-01
    z[0,1,0]  R108      -4.5666435360908508e-01
    z[0,1,0]  R109      -2.4800752103328705e-01
    z[0,1,0]  R110      3.2661882042884827e-01
    z[0,1,0]  R111      -3.2229042053222656e-01
    z[0,1,0]  R112      4.2880225181579590e-01
    z[0,1,0]  R113      0.649897575378418
    z[0,1,0]  R114      4.7318503260612488e-01
    z[0,1,0]  R115      -9.9350020289421082e-02
    z[0,1,0]  R116      6.8418934941291809e-02
    z[0,1,0]  R117      -1.8654868006706238e-01
    z[0,1,0]  R118      8.1839069724082947e-02
    z[0,1,0]  R119      -1.3905237615108490e-01
    z[0,1,0]  R120      -3.1382462382316589e-01
    z[0,1,0]  R121      2.4938400089740753e-01
    z[0,1,0]  R122      3.9992492645978928e-02
    z[0,1,0]  R123      -6.3366031646728516e-01
    z[0,1,0]  R124      -1.3271619379520416e-01
    z[0,1,0]  R125      2.2186957299709320e-01
    z[0,1,0]  R126      -3.6631923913955688e-01
    z[0,1,0]  R127      -3.2499887049198151e-02
    z[0,1,0]  R128      -3.2112231850624084e-01
    z[0,1,0]  R129      -1.4242365024983883e-02
    z[0,1,0]  R130      -6.5282315015792847e-01
    z[0,1,0]  R131      -6.7952924966812134e-01
    z[0,1,0]  R132      2.6820677518844604e-01
    z[0,1,0]  R133      -5.1666241884231567e-01
    z[0,1,0]  R134      2.6198202371597290e-01
    z[0,1,0]  R135      6.4260315895080566e-01
    z[0,1,0]  R136      -6.7581719160079956e-01
    z[0,1,0]  R137      -1.8442372977733612e-01
    z[0,1,0]  R138      -3.3599093556404114e-01
    z[0,1,0]  R139      0.606364369392395
    z[0,1,0]  R140      7.7782802283763885e-02
    z[0,1,0]  R141      2.6149311661720276e-01
    z[0,1,0]  R142      2.3175060749053955e-01
    z[0,1,0]  R143      -2.5962504744529724e-01
    z[0,1,0]  R144      5.3548002243041992e-01
    z[0,1,0]  R145      2.5886717438697815e-01
    z[0,1,0]  R146      2.9464939236640930e-01
    z[0,1,0]  R147      2.6722711324691772e-01
    z[0,1,0]  R148      -2.3365625739097595e-01
    z[0,1,0]  R149      0.0499470978975296
    z[0,1,0]  R150      5.3919935226440430e-01
    z[0,1,0]  R151      -4.9655294418334961e-01
    z[0,1,0]  R152      2.09329737117514e-05
    z[0,1,0]  R153      -2.3614892363548279e-01
    z[0,1,0]  R154      -1.4662164449691772e-01
    z[0,1,0]  R155      -8.0243217945098877e-01
    z[0,1,0]  R156      -8.3219474554061890e-01
    z[0,1,0]  R157      -0.347666472196579
    z[0,1,0]  R158      -6.2047320604324341e-01
    z[0,1,0]  R159      -8.2506549358367920e-01
    z[0,1,0]  R160      1.6997131705284119e-01
    z[0,1,0]  R161      -3.8668278604745865e-02
    z[0,1,0]  R162      8.1161573529243469e-02
    z[0,1,0]  R163      -2.1208256483078003e-01
    z[0,1,0]  R164      2.9422247409820557e-01
    z[0,1,0]  R165      -3.4678983688354492e-01
    z[0,1,0]  R166      -8.5808329284191132e-02
    z[0,1,0]  R167      4.3224486708641052e-01
    z[0,1,0]  R168      3.6659610271453857e-01
    z[0,1,0]  R169      -8.1483668088912964e-01
    z[0,1,0]  R170      -4.7504967451095581e-01
    z[0,1,0]  R171      9.9776171147823334e-02
    z[0,1,0]  R172      -2.4727405607700348e-01
    z[0,1,0]  R173      -0.917407214641571
    z[0,1,0]  R174      6.2808997929096222e-02
    z[0,1,0]  R175      -0.308746337890625
    z[0,1,0]  R176      -4.8761337995529175e-01
    z[0,1,0]  R177      0.397777795791626
    z[0,1,0]  R178      -4.1439205408096313e-01
    z[0,1,0]  R179      1.4232541620731354e-01
    z[0,1,0]  R180      -5.3590681403875351e-02
    z[0,1,0]  R181      -2.6490634679794312e-01
    z[0,1,0]  R182      -4.6500900387763977e-01
    z[0,1,0]  R183      3.4500789642333984e-01
    z[0,1,0]  R184      5.8319758623838425e-02
    z[0,1,0]  R185      3.2757607102394104e-01
    z[0,1,0]  R186      -4.6450477838516235e-01
    z[0,1,0]  R187      -3.8021394610404968e-01
    z[0,1,0]  R188      -4.2508924007415771e-01
    z[0,1,1]  R3        -1
    z[0,1,1]  R12       1
    z[0,1,1]  R85       -1
    z[0,1,1]  R86       1
    z[0,1,1]  R97       -2.2264370322227478e-01
    z[0,1,1]  R98       -2.1294246613979340e-01
    z[0,1,1]  R99       -1.3836251199245453e-01
    z[0,1,1]  R100      -0.435705304145813
    z[0,1,1]  R101      -2.0301729440689087e-01
    z[0,1,1]  R102      -3.1558337807655334e-01
    z[0,1,1]  R103      -2.7847656607627869e-01
    z[0,1,1]  R104      7.6416528224945068e-01
    z[0,1,1]  R105      -7.8548008203506470e-01
    z[0,1,1]  R106      8.0665594339370728e-01
    z[0,1,1]  R107      -3.3685964345932007e-01
    z[0,1,1]  R108      2.7346780896186829e-01
    z[0,1,1]  R109      2.7014365792274475e-01
    z[0,1,1]  R110      -3.3656972646713257e-01
    z[0,1,1]  R111      -8.8725142180919647e-02
    z[0,1,1]  R112      2.8172996640205383e-01
    z[0,1,1]  R113      3.6521452665328979e-01
    z[0,1,1]  R114      2.9680988192558289e-01
    z[0,1,1]  R115      4.8430547118186951e-01
    z[0,1,1]  R116      -5.7254844903945923e-01
    z[0,1,1]  R117      -7.4589270353317261e-01
    z[0,1,1]  R118      -7.4100983142852783e-01
    z[0,1,1]  R119      -7.2726887464523315e-01
    z[0,1,1]  R120      -6.7125785350799561e-01
    z[0,1,1]  R121      1.5988697111606598e-01
    z[0,1,1]  R122      1.8887175619602203e-01
    z[0,1,1]  R123      -5.4959356784820557e-01
    z[0,1,1]  R124      -6.7379742860794067e-01
    z[0,1,1]  R125      -6.6956084966659546e-01
    z[0,1,1]  R126      -3.9947167038917542e-01
    z[0,1,1]  R127      -5.3852275013923645e-02
    z[0,1,1]  R128      -4.7587621212005615e-01
    z[0,1,1]  R129      -6.2989002466201782e-01
    z[0,1,1]  R130      -6.2229627370834351e-01
    z[0,1,1]  R131      -4.0601894259452820e-01
    z[0,1,1]  R132      7.7640879154205322e-01
    z[0,1,1]  R133      -6.0742509365081787e-01
    z[0,1,1]  R134      -5.3855621814727783e-01
    z[0,1,1]  R135      -4.3175691366195679e-01
    z[0,1,1]  R136      -4.1912712156772614e-02
    z[0,1,1]  R137      -0.726190984249115
    z[0,1,1]  R138      -1.2535278499126434e-01
    z[0,1,1]  R139      -1.4139276742935181e-01
    z[0,1,1]  R140      1.7624922096729279e-01
    z[0,1,1]  R141      -6.6605895757675171e-01
    z[0,1,1]  R142      -6.7663162946701050e-01
    z[0,1,1]  R143      -4.1021513938903809e-01
    z[0,1,1]  R144      2.2009445726871490e-01
    z[0,1,1]  R145      -5.6356501579284668e-01
    z[0,1,1]  R146      -5.3775697946548462e-01
    z[0,1,1]  R147      -8.9600396156311035e-01
    z[0,1,1]  R148      -7.5159054994583130e-01
    z[0,1,1]  R149      -0.684525728225708
    z[0,1,1]  R150      3.8078734278678894e-01
    z[0,1,1]  R151      -6.9227421283721924e-01
    z[0,1,1]  R152      -2.9972484707832336e-01
    z[0,1,1]  R153      -0.756924569606781
    z[0,1,1]  R154      -3.3998182415962219e-01
    z[0,1,1]  R155      1.1340260505676270e-01
    z[0,1,1]  R156      1.5856340527534485e-01
    z[0,1,1]  R157      1.1163343489170074e-01
    z[0,1,1]  R158      -6.9189441204071045e-01
    z[0,1,1]  R159      -1.9321131706237793e-01
    z[0,1,1]  R160      -6.3497972488403320e-01
    z[0,1,1]  R161      -5.7006675004959106e-01
    z[0,1,1]  R162      5.4780155420303345e-01
    z[0,1,1]  R163      6.3868921995162964e-01
    z[0,1,1]  R164      4.1757425665855408e-01
    z[0,1,1]  R165      4.2315801978111267e-01
    z[0,1,1]  R166      6.0656005144119263e-01
    z[0,1,1]  R167      -2.4835999310016632e-01
    z[0,1,1]  R168      1.8533114343881607e-02
    z[0,1,1]  R169      -1.2853796780109406e-01
    z[0,1,1]  R170      7.6763892173767090e-01
    z[0,1,1]  R171      8.7351602315902710e-01
    z[0,1,1]  R172      0.82350754737854
    z[0,1,1]  R173      1.2437266111373901e-01
    z[0,1,1]  R174      6.2831938266754150e-01
    z[0,1,1]  R175      -4.4275969266891479e-01
    z[0,1,1]  R176      -3.4939491748809814e-01
    z[0,1,1]  R177      -2.6593357324600220e-02
    z[0,1,1]  R178      1.8808719515800476e-01
    z[0,1,1]  R179      -4.7432509064674377e-01
    z[0,1,1]  R180      -6.5710681676864624e-01
    z[0,1,1]  R181      -1.7128066718578339e-01
    z[0,1,1]  R182      5.2137100696563721e-01
    z[0,1,1]  R183      6.6814243793487549e-01
    z[0,1,1]  R184      7.3001396656036377e-01
    z[0,1,1]  R185      7.4190747737884521e-01
    z[0,1,1]  R186      -7.3118019104003906e-01
    z[0,1,1]  R187      -0.425414115190506
    z[0,1,1]  R188      -3.8223680853843689e-01
    z[0,1,2]  R4        -1
    z[0,1,2]  R13       1
    z[0,1,2]  R87       -1
    z[0,1,2]  R88       1
    z[0,1,2]  R97       2.7154350280761719e-01
    z[0,1,2]  R98       4.4143462181091309e-01
    z[0,1,2]  R99       8.3131664991378784e-01
    z[0,1,2]  R100      4.6449339389801025e-01
    z[0,1,2]  R101      8.4280174970626831e-01
    z[0,1,2]  R102      -4.2990061640739441e-01
    z[0,1,2]  R103      6.5445041656494141e-01
    z[0,1,2]  R104      0.463827520608902
    z[0,1,2]  R105      -1.3543221354484558e-01
    z[0,1,2]  R106      -1.3307537138462067e-01
    z[0,1,2]  R107      1.4464181661605835e-01
    z[0,1,2]  R108      2.6798495650291443e-01
    z[0,1,2]  R109      -2.5691960006952286e-02
    z[0,1,2]  R110      7.8006774187088013e-02
    z[0,1,2]  R111      -6.5830785036087036e-01
    z[0,1,2]  R112      1.6097073256969452e-01
    z[0,1,2]  R113      -1.6943724453449249e-01
    z[0,1,2]  R114      1.9703787565231323e-01
    z[0,1,2]  R115      -5.5116581916809082e-01
    z[0,1,2]  R116      -5.4144448041915894e-01
    z[0,1,2]  R117      1.9915345311164856e-01
    z[0,1,2]  R118      1.0369341075420380e-01
    z[0,1,2]  R119      9.9111318588256836e-02
    z[0,1,2]  R120      3.8619977235794067e-01
    z[0,1,2]  R121      -4.6538066864013672e-01
    z[0,1,2]  R122      -1.0131541639566422e-01
    z[0,1,2]  R123      4.2116996645927429e-01
    z[0,1,2]  R124      2.6482033729553223e-01
    z[0,1,2]  R125      -3.6697569489479065e-01
    z[0,1,2]  R126      1.5854367613792419e-01
    z[0,1,2]  R127      2.5470137596130371e-01
    z[0,1,2]  R128      1.0269098728895187e-01
    z[0,1,2]  R129      1.8841113150119781e-01
    z[0,1,2]  R130      -2.0193751156330109e-01
    z[0,1,2]  R131      0.0861692801117897
    z[0,1,2]  R132      -3.4506402909755707e-02
    z[0,1,2]  R133      -1.8633969128131866e-01
    z[0,1,2]  R134      -4.5117273926734924e-01
    z[0,1,2]  R135      5.2752655744552612e-01
    z[0,1,2]  R136      8.5915029048919678e-02
    z[0,1,2]  R137      3.6486014723777771e-01
    z[0,1,2]  R138      -6.0144379734992981e-02
    z[0,1,2]  R139      1.9117403775453568e-02
    z[0,1,2]  R140      -4.5376253128051758e-01
    z[0,1,2]  R141      1.4187838137149811e-01
    z[0,1,2]  R142      -3.0472939833998680e-02
    z[0,1,2]  R143      5.4875838756561279e-01
    z[0,1,2]  R144      9.6292868256568909e-02
    z[0,1,2]  R145      3.1461793184280396e-01
    z[0,1,2]  R146      5.6821137666702271e-01
    z[0,1,2]  R147      -4.0757302194833755e-02
    z[0,1,2]  R148      3.8455966114997864e-01
    z[0,1,2]  R149      -0.590084969997406
    z[0,1,2]  R150      2.5851535797119141e-01
    z[0,1,2]  R151      -0.374023973941803
    z[0,1,2]  R152      7.3741018772125244e-01
    z[0,1,2]  R153      -1.3904018700122833e-01
    z[0,1,2]  R154      7.4900567531585693e-01
    z[0,1,2]  R155      -1.7675158381462097e-01
    z[0,1,2]  R156      1.3139372691512108e-02
    z[0,1,2]  R157      -0.291920006275177
    z[0,1,2]  R158      6.5194942057132721e-02
    z[0,1,2]  R159      -2.0398974418640137e-01
    z[0,1,2]  R160      -0.514629065990448
    z[0,1,2]  R161      0.0444374643266201
    z[0,1,2]  R162      3.4484487771987915e-01
    z[0,1,2]  R163      5.0325065851211548e-01
    z[0,1,2]  R164      -6.8468250334262848e-02
    z[0,1,2]  R165      5.2718663215637207e-01
    z[0,1,2]  R166      1.9963055849075317e-01
    z[0,1,2]  R167      -0.229964017868042
    z[0,1,2]  R168      4.0561392903327942e-01
    z[0,1,2]  R169      3.0907127261161804e-01
    z[0,1,2]  R170      1.8937484920024872e-01
    z[0,1,2]  R171      -1.0655014961957932e-01
    z[0,1,2]  R172      9.2627935111522675e-02
    z[0,1,2]  R173      1.9605781137943268e-01
    z[0,1,2]  R174      -2.5864368304610252e-02
    z[0,1,2]  R175      -3.6831769347190857e-01
    z[0,1,2]  R176      -4.0486955642700195e-01
    z[0,1,2]  R177      -4.6876770257949829e-01
    z[0,1,2]  R178      -4.8648950457572937e-01
    z[0,1,2]  R179      5.8708250522613525e-01
    z[0,1,2]  R180      -2.1480685472488403e-01
    z[0,1,2]  R181      6.2088185548782349e-01
    z[0,1,2]  R182      6.2677621841430664e-01
    z[0,1,2]  R183      2.1633145213127136e-01
    z[0,1,2]  R184      0.319040983915329
    z[0,1,2]  R185      2.1228766441345215e-01
    z[0,1,2]  R186      -0.082750104367733
    z[0,1,2]  R187      -3.0480343848466873e-02
    z[0,1,2]  R188      -3.5850539803504944e-01
    z[0,1,3]  R5        -1
    z[0,1,3]  R14       1
    z[0,1,3]  R89       -1
    z[0,1,3]  R90       1
    z[0,1,3]  R97       -7.0720982551574707e-01
    z[0,1,3]  R98       -6.9758069515228271e-01
    z[0,1,3]  R99       -2.4126936495304108e-01
    z[0,1,3]  R100      -3.0696383118629456e-01
    z[0,1,3]  R101      -2.0187194645404816e-01
    z[0,1,3]  R102      -6.9268339872360229e-01
    z[0,1,3]  R103      -3.5274004936218262e-01
    z[0,1,3]  R104      3.8146394491195679e-01
    z[0,1,3]  R105      -4.5888921618461609e-01
    z[0,1,3]  R106      4.2126268148422241e-01
    z[0,1,3]  R107      6.2814855575561523e-01
    z[0,1,3]  R108      5.5779051780700684e-01
    z[0,1,3]  R109      5.6700974702835083e-01
    z[0,1,3]  R110      3.4470441937446594e-01
    z[0,1,3]  R111      4.9914455413818359e-01
    z[0,1,3]  R112      4.1553494334220886e-01
    z[0,1,3]  R113      3.6966013908386230e-01
    z[0,1,3]  R114      9.6126310527324677e-02
    z[0,1,3]  R115      5.7133400440216064e-01
    z[0,1,3]  R116      5.9475088119506836e-01
    z[0,1,3]  R117      -7.6354585587978363e-02
    z[0,1,3]  R118      1.8178611993789673e-01
    z[0,1,3]  R119      -4.2014512419700623e-01
    z[0,1,3]  R120      -4.1211771965026855e-01
    z[0,1,3]  R121      6.1982864141464233e-01
    z[0,1,3]  R122      1.6295839846134186e-01
    z[0,1,3]  R123      -1.9765029847621918e-01
    z[0,1,3]  R124      -5.0161361694335938e-01
    z[0,1,3]  R125      -2.3411202430725098e-01
    z[0,1,3]  R126      -6.1734235286712646e-01
    z[0,1,3]  R127      8.9579766988754272e-01
    z[0,1,3]  R128      -7.7933639287948608e-01
    z[0,1,3]  R129      -5.9990060329437256e-01
    z[0,1,3]  R130      8.5244961082935333e-02
    z[0,1,3]  R131      -3.2611685991287231e-01
    z[0,1,3]  R132      4.1469329595565796e-01
    z[0,1,3]  R133      1.8109214305877686e-01
    z[0,1,3]  R134      4.6539118885993958e-01
    z[0,1,3]  R135      1.2050674110651016e-01
    z[0,1,3]  R136      3.9610946178436279e-01
    z[0,1,3]  R137      -3.0852460861206055e-01
    z[0,1,3]  R138      3.4933799505233765e-01
    z[0,1,3]  R139      6.2043029069900513e-01
    z[0,1,3]  R140      7.1201616525650024e-01
    z[0,1,3]  R141      -3.2935658097267151e-01
    z[0,1,3]  R142      4.9749910831451416e-01
    z[0,1,3]  R143      -0.595457911491394
    z[0,1,3]  R144      4.0302717685699463e-01
    z[0,1,3]  R145      1.9613612443208694e-02
    z[0,1,3]  R146      2.4057655036449432e-01
    z[0,1,3]  R147      2.6396757364273071e-01
    z[0,1,3]  R148      -1.8983669579029083e-01
    z[0,1,3]  R149      -5.6722037494182587e-02
    z[0,1,3]  R150      6.0487186908721924e-01
    z[0,1,3]  R151      -1.7714852094650269e-01
    z[0,1,3]  R152      -5.5686396360397339e-01
    z[0,1,3]  R153      1.9345837831497192e-01
    z[0,1,3]  R154      -2.0902976393699646e-01
    z[0,1,3]  R155      4.4478651881217957e-01
    z[0,1,3]  R156      3.3601793646812439e-01
    z[0,1,3]  R157      0.655640721321106
    z[0,1,3]  R158      -2.3139376938343048e-01
    z[0,1,3]  R159      2.8733009099960327e-01
    z[0,1,3]  R160      -1.0046269744634628e-01
    z[0,1,3]  R161      -3.3963614702224731e-01
    z[0,1,3]  R162      6.7690014839172363e-01
    z[0,1,3]  R163      2.1949785947799683e-01
    z[0,1,3]  R164      4.9358087778091431e-01
    z[0,1,3]  R165      4.3031710386276245e-01
    z[0,1,3]  R166      7.8850097954273224e-02
    z[0,1,3]  R167      -2.4189765751361847e-01
    z[0,1,3]  R168      -3.3917987346649170e-01
    z[0,1,3]  R169      4.2526509612798691e-02
    z[0,1,3]  R170      2.8479378670454025e-02
    z[0,1,3]  R171      1.1749300360679626e-01
    z[0,1,3]  R172      2.9178312420845032e-01
    z[0,1,3]  R173      5.5899225175380707e-02
    z[0,1,3]  R174      3.2622328400611877e-01
    z[0,1,3]  R175      -4.3790200352668762e-01
    z[0,1,3]  R176      -0.609557569026947
    z[0,1,3]  R177      1.0702575743198395e-01
    z[0,1,3]  R178      6.5374052524566650e-01
    z[0,1,3]  R179      2.7324968576431274e-01
    z[0,1,3]  R180      3.3977967500686646e-01
    z[0,1,3]  R181      -3.3968049287796021e-01
    z[0,1,3]  R182      3.1409987807273865e-01
    z[0,1,3]  R183      5.9229767322540283e-01
    z[0,1,3]  R184      4.7588908672332764e-01
    z[0,1,3]  R185      2.2977969050407410e-01
    z[0,1,3]  R186      -4.4816818833351135e-01
    z[0,1,3]  R187      -4.3633216619491577e-01
    z[0,1,3]  R188      -4.2344403266906738e-01
    z[0,1,4]  R6        -1
    z[0,1,4]  R15       1
    z[0,1,4]  R91       -1
    z[0,1,4]  R92       1
    z[0,1,4]  R97       1.2259913235902786e-01
    z[0,1,4]  R98       2.6392656564712524e-01
    z[0,1,4]  R99       4.6463202685117722e-02
    z[0,1,4]  R100      -3.5254594683647156e-01
    z[0,1,4]  R101      -2.4449007213115692e-01
    z[0,1,4]  R102      2.8654780983924866e-01
    z[0,1,4]  R103      -5.7972751557826996e-02
    z[0,1,4]  R104      -4.0461938828229904e-02
    z[0,1,4]  R105      -2.2709010541439056e-01
    z[0,1,4]  R106      -0.331691712141037
    z[0,1,4]  R107      9.4646655023097992e-02
    z[0,1,4]  R108      -4.7965649515390396e-02
    z[0,1,4]  R109      5.3363703191280365e-02
    z[0,1,4]  R110      1.8360137939453125e-01
    z[0,1,4]  R111      -1.9633080065250397e-01
    z[0,1,4]  R112      -1.4350116252899170e-01
    z[0,1,4]  R113      5.9857752174139023e-02
    z[0,1,4]  R114      1.1935921013355255e-01
    z[0,1,4]  R115      7.4213206768035889e-02
    z[0,1,4]  R116      6.1546668410301208e-02
    z[0,1,4]  R117      -6.4590275287628174e-02
    z[0,1,4]  R118      -3.2296633720397949e-01
    z[0,1,4]  R119      -1.5243685804307461e-02
    z[0,1,4]  R120      3.8030825555324554e-02
    z[0,1,4]  R121      3.1678044795989990e-01
    z[0,1,4]  R122      -7.3413648642599583e-03
    z[0,1,4]  R123      -2.7928823605179787e-02
    z[0,1,4]  R124      -2.2214733064174652e-01
    z[0,1,4]  R125      2.4055325984954834e-01
    z[0,1,4]  R126      7.1519844233989716e-02
    z[0,1,4]  R127      1.5579383075237274e-01
    z[0,1,4]  R128      1.6558946669101715e-01
    z[0,1,4]  R129      -3.2959397882223129e-02
    z[0,1,4]  R130      1.9690386950969696e-01
    z[0,1,4]  R131      6.4184583723545074e-02
    z[0,1,4]  R132      2.3151208460330963e-01
    z[0,1,4]  R133      -1.0148895531892776e-01
    z[0,1,4]  R134      2.3119370639324188e-01
    z[0,1,4]  R135      3.2638299465179443e-01
    z[0,1,4]  R136      1.8954484164714813e-01
    z[0,1,4]  R137      -2.1056285500526428e-01
    z[0,1,4]  R138      2.6625737547874451e-01
    z[0,1,4]  R139      -2.0119942724704742e-01
    z[0,1,4]  R140      -3.2164674997329712e-01
    z[0,1,4]  R141      4.9756950139999390e-01
    z[0,1,4]  R142      -4.0620166063308716e-01
    z[0,1,4]  R143      -0.129534512758255
    z[0,1,4]  R144      2.8277760744094849e-01
    z[0,1,4]  R145      1.3353681564331055e-01
    z[0,1,4]  R146      -4.8810219764709473e-01
    z[0,1,4]  R147      2.2378638386726379e-01
    z[0,1,4]  R148      -7.5205512344837189e-02
    z[0,1,4]  R149      8.6364768445491791e-02
    z[0,1,4]  R150      1.6309115290641785e-01
    z[0,1,4]  R151      -2.0140078663825989e-01
    z[0,1,4]  R152      1.1269237147644162e-03
    z[0,1,4]  R153      -5.0101685523986816e-01
    z[0,1,4]  R154      -2.0102441310882568e-01
    z[0,1,4]  R155      2.6743793487548828e-01
    z[0,1,4]  R156      3.7970918416976929e-01
    z[0,1,4]  R157      4.4239366054534912e-01
    z[0,1,4]  R158      2.2575096786022186e-01
    z[0,1,4]  R159      9.5553815364837646e-02
    z[0,1,4]  R160      -5.1294457912445068e-01
    z[0,1,4]  R161      -4.4900581240653992e-01
    z[0,1,4]  R162      7.5459964573383331e-02
    z[0,1,4]  R163      4.7838100790977478e-01
    z[0,1,4]  R164      2.4804225564002991e-01
    z[0,1,4]  R165      -2.0714102685451508e-01
    z[0,1,4]  R166      -0.0595281757414341
    z[0,1,4]  R167      6.7818784713745117e-01
    z[0,1,4]  R168      -7.3060697317123413e-01
    z[0,1,4]  R169      4.3386703729629517e-01
    z[0,1,4]  R170      1.1272528767585754e-01
    z[0,1,4]  R171      1.1800088733434677e-01
    z[0,1,4]  R172      3.5040014982223511e-01
    z[0,1,4]  R173      -0.262971967458725
    z[0,1,4]  R174      1.3726362586021423e-01
    z[0,1,4]  R175      -9.2204205691814423e-02
    z[0,1,4]  R176      -1.9371549785137177e-01
    z[0,1,4]  R177      3.5541161894798279e-02
    z[0,1,4]  R178      -2.0237004756927490e-01
    z[0,1,4]  R179      1.2165561318397522e-01
    z[0,1,4]  R180      -3.6070284247398376e-01
    z[0,1,4]  R181      4.1045939922332764e-01
    z[0,1,4]  R182      1.6668954864144325e-02
    z[0,1,4]  R183      1.4215713739395142e-01
    z[0,1,4]  R184      4.3430402874946594e-02
    z[0,1,4]  R185      6.3840463757514954e-02
    z[0,1,4]  R186      -1.2974040210247040e-01
    z[0,1,4]  R187      -8.1952154636383057e-02
    z[0,1,4]  R188      -1.8370974063873291e-01
    z[0,1,5]  R7        -1
    z[0,1,5]  R16       1
    z[0,1,5]  R93       -1
    z[0,1,5]  R94       1
    z[0,1,5]  R97       -1.9956852495670319e-01
    z[0,1,5]  R98       2.0951206982135773e-01
    z[0,1,5]  R99       -1.6466975212097168e-01
    z[0,1,5]  R100      -4.5666342973709106e-01
    z[0,1,5]  R101      -2.9176460579037666e-02
    z[0,1,5]  R102      1.9770933687686920e-01
    z[0,1,5]  R103      5.5945134162902832e-01
    z[0,1,5]  R104      -1.6124244034290314e-01
    z[0,1,5]  R105      1.6466896235942841e-01
    z[0,1,5]  R106      -1.2085715681314468e-01
    z[0,1,5]  R107      -4.3522989749908447e-01
    z[0,1,5]  R108      -4.2333969473838806e-01
    z[0,1,5]  R109      -2.8290903568267822e-01
    z[0,1,5]  R110      -5.5686312913894653e-01
    z[0,1,5]  R111      -4.0836516022682190e-01
    z[0,1,5]  R112      -3.2412597537040710e-01
    z[0,1,5]  R113      -3.8572993874549866e-01
    z[0,1,5]  R114      -7.1814113855361938e-01
    z[0,1,5]  R115      -2.9740974307060242e-01
    z[0,1,5]  R116      5.8317895978689194e-02
    z[0,1,5]  R117      -4.8274996876716614e-01
    z[0,1,5]  R118      5.1724809408187866e-01
    z[0,1,5]  R119      -4.6995180845260620e-01
    z[0,1,5]  R120      3.5755565762519836e-01
    z[0,1,5]  R121      -3.3992937207221985e-01
    z[0,1,5]  R122      -9.5896673202514648e-01
    z[0,1,5]  R123      0.281389981508255
    z[0,1,5]  R124      -1.3235056400299072e-01
    z[0,1,5]  R125      -5.0508117675781250e-01
    z[0,1,5]  R126      -4.1683351993560791e-01
    z[0,1,5]  R127      -1.5273775160312653e-01
    z[0,1,5]  R128      1.3021574914455414e-01
    z[0,1,5]  R129      4.3204712867736816e-01
    z[0,1,5]  R130      -1.8467260897159576e-01
    z[0,1,5]  R131      1.7204004526138306e-01
    z[0,1,5]  R132      -3.0417588353157043e-01
    z[0,1,5]  R133      3.4708064794540405e-01
    z[0,1,5]  R134      3.9442703127861023e-01
    z[0,1,5]  R135      2.9866768047213554e-02
    z[0,1,5]  R136      -2.0194509997963905e-02
    z[0,1,5]  R137      -2.4880267679691315e-01
    z[0,1,5]  R138      -6.2224805355072021e-01
    z[0,1,5]  R139      -4.2498525977134705e-01
    z[0,1,5]  R140      -2.0908093452453613e-01
    z[0,1,5]  R141      -5.1655232906341553e-02
    z[0,1,5]  R142      -2.6204457506537437e-02
    z[0,1,5]  R143      -2.5494593381881714e-01
    z[0,1,5]  R144      -3.1170985102653503e-01
    z[0,1,5]  R145      -2.5660762190818787e-01
    z[0,1,5]  R146      -4.5631803572177887e-02
    z[0,1,5]  R147      -6.5560504794120789e-02
    z[0,1,5]  R148      4.0770357847213745e-01
    z[0,1,5]  R149      -0.0376245491206646
    z[0,1,5]  R150      -2.2379907965660095e-01
    z[0,1,5]  R151      1.3422715663909912e-01
    z[0,1,5]  R152      2.3163928091526031e-01
    z[0,1,5]  R153      7.7741943299770355e-02
    z[0,1,5]  R154      3.0385997891426086e-01
    z[0,1,5]  R155      1.6005125641822815e-01
    z[0,1,5]  R156      5.8769159018993378e-02
    z[0,1,5]  R157      -3.8271471858024597e-01
    z[0,1,5]  R158      -5.6668068282306194e-03
    z[0,1,5]  R159      -2.1352672576904297e-01
    z[0,1,5]  R160      -1.6919773817062378e-01
    z[0,1,5]  R161      -4.8728186637163162e-02
    z[0,1,5]  R162      0.297302782535553
    z[0,1,5]  R163      8.2587942481040955e-02
    z[0,1,5]  R164      6.0453391075134277e-01
    z[0,1,5]  R165      3.1147131323814392e-01
    z[0,1,5]  R166      5.0482434034347534e-01
    z[0,1,5]  R167      -7.3558405041694641e-02
    z[0,1,5]  R168      2.1748398244380951e-01
    z[0,1,5]  R169      1.1583929508924484e-01
    z[0,1,5]  R170      3.4561118483543396e-01
    z[0,1,5]  R171      3.9490637183189392e-01
    z[0,1,5]  R172      1.4406548440456390e-01
    z[0,1,5]  R173      -0.0522085502743721
    z[0,1,5]  R174      -2.1412852406501770e-01
    z[0,1,5]  R175      -2.4928821623325348e-01
    z[0,1,5]  R176      6.8778353743255138e-03
    z[0,1,5]  R177      3.2511085271835327e-01
    z[0,1,5]  R178      -2.6931858062744141e-01
    z[0,1,5]  R179      -5.1344615221023560e-01
    z[0,1,5]  R180      -5.2290058135986328e-01
    z[0,1,5]  R181      5.3218550980091095e-02
    z[0,1,5]  R182      -1.3850098848342896e-01
    z[0,1,5]  R183      -6.3376188278198242e-02
    z[0,1,5]  R184      -3.0528476834297180e-01
    z[0,1,5]  R185      -4.8538818955421448e-01
    z[0,1,5]  R186      -1.2154900282621384e-01
    z[0,1,5]  R187      -6.7240279912948608e-01
    z[0,1,5]  R188      -5.2716493606567383e-01
    z[0,1,6]  R8        -1
    z[0,1,6]  R17       1
    z[0,1,6]  R95       -1
    z[0,1,6]  R96       1
    z[0,1,6]  R97       -4.3116754293441772e-01
    z[0,1,6]  R98       3.9251565933227539e-01
    z[0,1,6]  R99       1.1157218366861343e-01
    z[0,1,6]  R100      4.0498995780944824e-01
    z[0,1,6]  R101      -3.6586725711822510e-01
    z[0,1,6]  R102      -2.3382523655891418e-01
    z[0,1,6]  R103      -6.5789207816123962e-02
    z[0,1,6]  R104      -1.5175785124301910e-01
    z[0,1,6]  R105      0.268466979265213
    z[0,1,6]  R106      3.9267953485250473e-02
    z[0,1,6]  R107      4.5309510827064514e-01
    z[0,1,6]  R108      -3.9014050364494324e-01
    z[0,1,6]  R109      -6.7857891321182251e-01
    z[0,1,6]  R110      -5.5796837806701660e-01
    z[0,1,6]  R111      -2.0839789882302284e-02
    z[0,1,6]  R112      -0.642281711101532
    z[0,1,6]  R113      -3.5570108890533447e-01
    z[0,1,6]  R114      -3.3160585165023804e-01
    z[0,1,6]  R115      -1.7723254859447479e-01
    z[0,1,6]  R116      1.1587673425674438e-01
    z[0,1,6]  R117      -3.5515061020851135e-01
    z[0,1,6]  R118      -1.6898328065872192e-01
    z[0,1,6]  R119      2.1050535142421722e-01
    z[0,1,6]  R120      -5.1412478089332581e-02
    z[0,1,6]  R121      3.0915224552154541e-01
    z[0,1,6]  R122      -7.8972905874252319e-02
    z[0,1,6]  R123      3.3543251920491457e-03
    z[0,1,6]  R124      3.7385997176170349e-01
    z[0,1,6]  R125      3.1316413078457117e-03
    z[0,1,6]  R126      3.4802260994911194e-01
    z[0,1,6]  R127      -2.8481009602546692e-01
    z[0,1,6]  R128      -9.0197168290615082e-02
    z[0,1,6]  R129      1.4108563959598541e-01
    z[0,1,6]  R130      2.5622019171714783e-01
    z[0,1,6]  R131      -4.7528293728828430e-01
    z[0,1,6]  R132      -7.7281542122364044e-02
    z[0,1,6]  R133      4.0720129013061523e-01
    z[0,1,6]  R134      -1.1024359613656998e-01
    z[0,1,6]  R135      2.0571835339069366e-02
    z[0,1,6]  R136      5.8386242389678955e-01
    z[0,1,6]  R137      3.2262188196182251e-01
    z[0,1,6]  R138      -0.536336362361908
    z[0,1,6]  R139      7.7055029571056366e-02
    z[0,1,6]  R140      -3.2069790363311768e-01
    z[0,1,6]  R141      3.3036038279533386e-01
    z[0,1,6]  R142      2.7265515923500061e-01
    z[0,1,6]  R143      -1.6381666064262390e-01
    z[0,1,6]  R144      -5.6212997436523438e-01
    z[0,1,6]  R145      6.5752077102661133e-01
    z[0,1,6]  R146      5.4147444665431976e-02
    z[0,1,6]  R147      -6.9317850284278393e-03
    z[0,1,6]  R148      1.5720768272876740e-01
    z[0,1,6]  R149      -4.1065523028373718e-01
    z[0,1,6]  R150      2.3426532745361328e-01
    z[0,1,6]  R151      -2.1056310832500458e-01
    z[0,1,6]  R152      -5.1340326666831970e-02
    z[0,1,6]  R153      2.3974737524986267e-01
    z[0,1,6]  R154      -3.5421723127365112e-01
    z[0,1,6]  R155      -1.3048692047595978e-01
    z[0,1,6]  R156      1.4695557951927185e-01
    z[0,1,6]  R157      -9.6959307789802551e-02
    z[0,1,6]  R158      -1.6584932804107666e-01
    z[0,1,6]  R159      3.2100099325180054e-01
    z[0,1,6]  R160      3.5137336701154709e-02
    z[0,1,6]  R161      -5.9348177909851074e-01
    z[0,1,6]  R162      -1.4876598119735718e-01
    z[0,1,6]  R163      9.9936850368976593e-02
    z[0,1,6]  R164      2.5252452492713928e-01
    z[0,1,6]  R165      3.1249606609344482e-01
    z[0,1,6]  R166      5.6591600179672241e-01
    z[0,1,6]  R167      -4.1801211237907410e-01
    z[0,1,6]  R168      -6.7914955317974091e-02
    z[0,1,6]  R169      1.4326995611190796e-01
    z[0,1,6]  R170      1.2739814817905426e-01
    z[0,1,6]  R171      -1.7883436381816864e-01
    z[0,1,6]  R172      -1.5309639275074005e-01
    z[0,1,6]  R173      1.7161594331264496e-01
    z[0,1,6]  R174      6.5535253286361694e-01
    z[0,1,6]  R175      0.557294487953186
    z[0,1,6]  R176      2.5904360413551331e-01
    z[0,1,6]  R177      0.709159791469574
    z[0,1,6]  R178      -1.2396611273288727e-01
    z[0,1,6]  R179      2.3874849081039429e-01
    z[0,1,6]  R180      -1.4659132808446884e-02
    z[0,1,6]  R181      4.7780883312225342e-01
    z[0,1,6]  R182      -3.1167024746537209e-02
    z[0,1,6]  R183      -1.1275658756494522e-01
    z[0,1,6]  R184      2.0083774626255035e-01
    z[0,1,6]  R185      -6.8739682435989380e-02
    z[0,1,6]  R186      1.0149707645177841e-01
    z[0,1,6]  R187      0.15589639544487
    z[0,1,6]  R188      2.3175662755966187e-01
    z[1,0,0]  R2        1
    z[1,0,0]  R11       -1
    z[1,0,0]  R189      -1
    z[1,0,0]  R190      1
    z[1,0,0]  R203      4.3224486708641052e-01
    z[1,0,0]  R204      3.6659610271453857e-01
    z[1,0,0]  R205      -8.1483668088912964e-01
    z[1,0,0]  R206      -4.7504967451095581e-01
    z[1,0,0]  R207      9.9776171147823334e-02
    z[1,0,0]  R208      -2.4727405607700348e-01
    z[1,0,0]  R209      -0.917407214641571
    z[1,0,0]  R210      6.2808997929096222e-02
    z[1,0,0]  R211      -0.308746337890625
    z[1,0,0]  R212      -4.8761337995529175e-01
    z[1,0,0]  R213      0.397777795791626
    z[1,0,0]  R214      -4.1439205408096313e-01
    z[1,0,0]  R215      1.4232541620731354e-01
    z[1,0,0]  R216      -5.3590681403875351e-02
    z[1,0,0]  R217      -2.6490634679794312e-01
    z[1,0,0]  R218      -4.6500900387763977e-01
    z[1,0,0]  R219      3.4500789642333984e-01
    z[1,0,0]  R220      5.8319758623838425e-02
    z[1,0,0]  R221      3.2757607102394104e-01
    z[1,0,0]  R222      -4.6450477838516235e-01
    z[1,0,0]  R223      -3.8021394610404968e-01
    z[1,0,0]  R224      -4.2508924007415771e-01
    z[1,0,0]  R225      -3.6848965287208557e-01
    z[1,0,0]  R226      7.4506118893623352e-02
    z[1,0,0]  R227      -4.3569985032081604e-01
    z[1,0,0]  R228      5.7732496410608292e-02
    z[1,0,0]  R229      -1.1502807587385178e-01
    z[1,0,0]  R230      -2.4476386606693268e-01
    z[1,0,0]  R231      2.2146110236644745e-01
    z[1,0,0]  R232      6.8804420530796051e-02
    z[1,0,0]  R233      -5.7788819074630737e-02
    z[1,0,0]  R234      1.6723388433456421e-01
    z[1,0,0]  R235      -2.5952938199043274e-01
    z[1,0,0]  R236      -4.5666435360908508e-01
    z[1,0,0]  R237      -2.4800752103328705e-01
    z[1,0,0]  R238      3.2661882042884827e-01
    z[1,0,0]  R239      -3.2229042053222656e-01
    z[1,0,0]  R240      4.2880225181579590e-01
    z[1,0,0]  R241      0.649897575378418
    z[1,0,0]  R242      4.7318503260612488e-01
    z[1,0,0]  R243      -9.9350020289421082e-02
    z[1,0,0]  R244      6.8418934941291809e-02
    z[1,0,0]  R245      -1.8654868006706238e-01
    z[1,0,0]  R246      8.1839069724082947e-02
    z[1,0,0]  R247      -1.3905237615108490e-01
    z[1,0,0]  R248      -3.1382462382316589e-01
    z[1,0,0]  R249      2.4938400089740753e-01
    z[1,0,0]  R250      3.9992492645978928e-02
    z[1,0,0]  R251      -6.3366031646728516e-01
    z[1,0,0]  R252      -1.3271619379520416e-01
    z[1,0,0]  R253      2.2186957299709320e-01
    z[1,0,0]  R254      -3.6631923913955688e-01
    z[1,0,0]  R255      -3.2499887049198151e-02
    z[1,0,0]  R256      -3.2112231850624084e-01
    z[1,0,0]  R257      -1.4242365024983883e-02
    z[1,0,0]  R258      -6.5282315015792847e-01
    z[1,0,0]  R259      -6.7952924966812134e-01
    z[1,0,0]  R260      2.6820677518844604e-01
    z[1,0,0]  R261      -5.1666241884231567e-01
    z[1,0,0]  R262      2.6198202371597290e-01
    z[1,0,0]  R263      6.4260315895080566e-01
    z[1,0,0]  R264      -6.7581719160079956e-01
    z[1,0,0]  R265      -1.8442372977733612e-01
    z[1,0,0]  R266      -3.3599093556404114e-01
    z[1,0,0]  R267      0.606364369392395
    z[1,0,0]  R268      7.7782802283763885e-02
    z[1,0,0]  R269      2.6149311661720276e-01
    z[1,0,0]  R270      2.3175060749053955e-01
    z[1,0,0]  R271      -2.5962504744529724e-01
    z[1,0,0]  R272      5.3548002243041992e-01
    z[1,0,0]  R273      2.5886717438697815e-01
    z[1,0,0]  R274      2.9464939236640930e-01
    z[1,0,0]  R275      2.6722711324691772e-01
    z[1,0,0]  R276      -2.3365625739097595e-01
    z[1,0,0]  R277      0.0499470978975296
    z[1,0,0]  R278      5.3919935226440430e-01
    z[1,0,0]  R279      -4.9655294418334961e-01
    z[1,0,0]  R280      2.09329737117514e-05
    z[1,0,0]  R281      -2.3614892363548279e-01
    z[1,0,0]  R282      -1.4662164449691772e-01
    z[1,0,0]  R283      -8.0243217945098877e-01
    z[1,0,0]  R284      -8.3219474554061890e-01
    z[1,0,0]  R285      -0.347666472196579
    z[1,0,0]  R286      -6.2047320604324341e-01
    z[1,0,0]  R287      -8.2506549358367920e-01
    z[1,0,0]  R288      1.6997131705284119e-01
    z[1,0,0]  R289      -3.8668278604745865e-02
    z[1,0,0]  R290      8.1161573529243469e-02
    z[1,0,0]  R291      -2.1208256483078003e-01
    z[1,0,0]  R292      2.9422247409820557e-01
    z[1,0,0]  R293      -3.4678983688354492e-01
    z[1,0,0]  R294      -8.5808329284191132e-02
    z[1,0,1]  R3        1
    z[1,0,1]  R12       -1
    z[1,0,1]  R191      -1
    z[1,0,1]  R192      1
    z[1,0,1]  R203      -2.4835999310016632e-01
    z[1,0,1]  R204      1.8533114343881607e-02
    z[1,0,1]  R205      -1.2853796780109406e-01
    z[1,0,1]  R206      7.6763892173767090e-01
    z[1,0,1]  R207      8.7351602315902710e-01
    z[1,0,1]  R208      0.82350754737854
    z[1,0,1]  R209      1.2437266111373901e-01
    z[1,0,1]  R210      6.2831938266754150e-01
    z[1,0,1]  R211      -4.4275969266891479e-01
    z[1,0,1]  R212      -3.4939491748809814e-01
    z[1,0,1]  R213      -2.6593357324600220e-02
    z[1,0,1]  R214      1.8808719515800476e-01
    z[1,0,1]  R215      -4.7432509064674377e-01
    z[1,0,1]  R216      -6.5710681676864624e-01
    z[1,0,1]  R217      -1.7128066718578339e-01
    z[1,0,1]  R218      5.2137100696563721e-01
    z[1,0,1]  R219      6.6814243793487549e-01
    z[1,0,1]  R220      7.3001396656036377e-01
    z[1,0,1]  R221      7.4190747737884521e-01
    z[1,0,1]  R222      -7.3118019104003906e-01
    z[1,0,1]  R223      -0.425414115190506
    z[1,0,1]  R224      -3.8223680853843689e-01
    z[1,0,1]  R225      -2.2264370322227478e-01
    z[1,0,1]  R226      -2.1294246613979340e-01
    z[1,0,1]  R227      -1.3836251199245453e-01
    z[1,0,1]  R228      -0.435705304145813
    z[1,0,1]  R229      -2.0301729440689087e-01
    z[1,0,1]  R230      -3.1558337807655334e-01
    z[1,0,1]  R231      -2.7847656607627869e-01
    z[1,0,1]  R232      7.6416528224945068e-01
    z[1,0,1]  R233      -7.8548008203506470e-01
    z[1,0,1]  R234      8.0665594339370728e-01
    z[1,0,1]  R235      -3.3685964345932007e-01
    z[1,0,1]  R236      2.7346780896186829e-01
    z[1,0,1]  R237      2.7014365792274475e-01
    z[1,0,1]  R238      -3.3656972646713257e-01
    z[1,0,1]  R239      -8.8725142180919647e-02
    z[1,0,1]  R240      2.8172996640205383e-01
    z[1,0,1]  R241      3.6521452665328979e-01
    z[1,0,1]  R242      2.9680988192558289e-01
    z[1,0,1]  R243      4.8430547118186951e-01
    z[1,0,1]  R244      -5.7254844903945923e-01
    z[1,0,1]  R245      -7.4589270353317261e-01
    z[1,0,1]  R246      -7.4100983142852783e-01
    z[1,0,1]  R247      -7.2726887464523315e-01
    z[1,0,1]  R248      -6.7125785350799561e-01
    z[1,0,1]  R249      1.5988697111606598e-01
    z[1,0,1]  R250      1.8887175619602203e-01
    z[1,0,1]  R251      -5.4959356784820557e-01
    z[1,0,1]  R252      -6.7379742860794067e-01
    z[1,0,1]  R253      -6.6956084966659546e-01
    z[1,0,1]  R254      -3.9947167038917542e-01
    z[1,0,1]  R255      -5.3852275013923645e-02
    z[1,0,1]  R256      -4.7587621212005615e-01
    z[1,0,1]  R257      -6.2989002466201782e-01
    z[1,0,1]  R258      -6.2229627370834351e-01
    z[1,0,1]  R259      -4.0601894259452820e-01
    z[1,0,1]  R260      7.7640879154205322e-01
    z[1,0,1]  R261      -6.0742509365081787e-01
    z[1,0,1]  R262      -5.3855621814727783e-01
    z[1,0,1]  R263      -4.3175691366195679e-01
    z[1,0,1]  R264      -4.1912712156772614e-02
    z[1,0,1]  R265      -0.726190984249115
    z[1,0,1]  R266      -1.2535278499126434e-01
    z[1,0,1]  R267      -1.4139276742935181e-01
    z[1,0,1]  R268      1.7624922096729279e-01
    z[1,0,1]  R269      -6.6605895757675171e-01
    z[1,0,1]  R270      -6.7663162946701050e-01
    z[1,0,1]  R271      -4.1021513938903809e-01
    z[1,0,1]  R272      2.2009445726871490e-01
    z[1,0,1]  R273      -5.6356501579284668e-01
    z[1,0,1]  R274      -5.3775697946548462e-01
    z[1,0,1]  R275      -8.9600396156311035e-01
    z[1,0,1]  R276      -7.5159054994583130e-01
    z[1,0,1]  R277      -0.684525728225708
    z[1,0,1]  R278      3.8078734278678894e-01
    z[1,0,1]  R279      -6.9227421283721924e-01
    z[1,0,1]  R280      -2.9972484707832336e-01
    z[1,0,1]  R281      -0.756924569606781
    z[1,0,1]  R282      -3.3998182415962219e-01
    z[1,0,1]  R283      1.1340260505676270e-01
    z[1,0,1]  R284      1.5856340527534485e-01
    z[1,0,1]  R285      1.1163343489170074e-01
    z[1,0,1]  R286      -6.9189441204071045e-01
    z[1,0,1]  R287      -1.9321131706237793e-01
    z[1,0,1]  R288      -6.3497972488403320e-01
    z[1,0,1]  R289      -5.7006675004959106e-01
    z[1,0,1]  R290      5.4780155420303345e-01
    z[1,0,1]  R291      6.3868921995162964e-01
    z[1,0,1]  R292      4.1757425665855408e-01
    z[1,0,1]  R293      4.2315801978111267e-01
    z[1,0,1]  R294      6.0656005144119263e-01
    z[1,0,2]  R4        1
    z[1,0,2]  R13       -1
    z[1,0,2]  R193      -1
    z[1,0,2]  R194      1
    z[1,0,2]  R203      -0.229964017868042
    z[1,0,2]  R204      4.0561392903327942e-01
    z[1,0,2]  R205      3.0907127261161804e-01
    z[1,0,2]  R206      1.8937484920024872e-01
    z[1,0,2]  R207      -1.0655014961957932e-01
    z[1,0,2]  R208      9.2627935111522675e-02
    z[1,0,2]  R209      1.9605781137943268e-01
    z[1,0,2]  R210      -2.5864368304610252e-02
    z[1,0,2]  R211      -3.6831769347190857e-01
    z[1,0,2]  R212      -4.0486955642700195e-01
    z[1,0,2]  R213      -4.6876770257949829e-01
    z[1,0,2]  R214      -4.8648950457572937e-01
    z[1,0,2]  R215      5.8708250522613525e-01
    z[1,0,2]  R216      -2.1480685472488403e-01
    z[1,0,2]  R217      6.2088185548782349e-01
    z[1,0,2]  R218      6.2677621841430664e-01
    z[1,0,2]  R219      2.1633145213127136e-01
    z[1,0,2]  R220      0.319040983915329
    z[1,0,2]  R221      2.1228766441345215e-01
    z[1,0,2]  R222      -0.082750104367733
    z[1,0,2]  R223      -3.0480343848466873e-02
    z[1,0,2]  R224      -3.5850539803504944e-01
    z[1,0,2]  R225      2.7154350280761719e-01
    z[1,0,2]  R226      4.4143462181091309e-01
    z[1,0,2]  R227      8.3131664991378784e-01
    z[1,0,2]  R228      4.6449339389801025e-01
    z[1,0,2]  R229      8.4280174970626831e-01
    z[1,0,2]  R230      -4.2990061640739441e-01
    z[1,0,2]  R231      6.5445041656494141e-01
    z[1,0,2]  R232      0.463827520608902
    z[1,0,2]  R233      -1.3543221354484558e-01
    z[1,0,2]  R234      -1.3307537138462067e-01
    z[1,0,2]  R235      1.4464181661605835e-01
    z[1,0,2]  R236      2.6798495650291443e-01
    z[1,0,2]  R237      -2.5691960006952286e-02
    z[1,0,2]  R238      7.8006774187088013e-02
    z[1,0,2]  R239      -6.5830785036087036e-01
    z[1,0,2]  R240      1.6097073256969452e-01
    z[1,0,2]  R241      -1.6943724453449249e-01
    z[1,0,2]  R242      1.9703787565231323e-01
    z[1,0,2]  R243      -5.5116581916809082e-01
    z[1,0,2]  R244      -5.4144448041915894e-01
    z[1,0,2]  R245      1.9915345311164856e-01
    z[1,0,2]  R246      1.0369341075420380e-01
    z[1,0,2]  R247      9.9111318588256836e-02
    z[1,0,2]  R248      3.8619977235794067e-01
    z[1,0,2]  R249      -4.6538066864013672e-01
    z[1,0,2]  R250      -1.0131541639566422e-01
    z[1,0,2]  R251      4.2116996645927429e-01
    z[1,0,2]  R252      2.6482033729553223e-01
    z[1,0,2]  R253      -3.6697569489479065e-01
    z[1,0,2]  R254      1.5854367613792419e-01
    z[1,0,2]  R255      2.5470137596130371e-01
    z[1,0,2]  R256      1.0269098728895187e-01
    z[1,0,2]  R257      1.8841113150119781e-01
    z[1,0,2]  R258      -2.0193751156330109e-01
    z[1,0,2]  R259      0.0861692801117897
    z[1,0,2]  R260      -3.4506402909755707e-02
    z[1,0,2]  R261      -1.8633969128131866e-01
    z[1,0,2]  R262      -4.5117273926734924e-01
    z[1,0,2]  R263      5.2752655744552612e-01
    z[1,0,2]  R264      8.5915029048919678e-02
    z[1,0,2]  R265      3.6486014723777771e-01
    z[1,0,2]  R266      -6.0144379734992981e-02
    z[1,0,2]  R267      1.9117403775453568e-02
    z[1,0,2]  R268      -4.5376253128051758e-01
    z[1,0,2]  R269      1.4187838137149811e-01
    z[1,0,2]  R270      -3.0472939833998680e-02
    z[1,0,2]  R271      5.4875838756561279e-01
    z[1,0,2]  R272      9.6292868256568909e-02
    z[1,0,2]  R273      3.1461793184280396e-01
    z[1,0,2]  R274      5.6821137666702271e-01
    z[1,0,2]  R275      -4.0757302194833755e-02
    z[1,0,2]  R276      3.8455966114997864e-01
    z[1,0,2]  R277      -0.590084969997406
    z[1,0,2]  R278      2.5851535797119141e-01
    z[1,0,2]  R279      -0.374023973941803
    z[1,0,2]  R280      7.3741018772125244e-01
    z[1,0,2]  R281      -1.3904018700122833e-01
    z[1,0,2]  R282      7.4900567531585693e-01
    z[1,0,2]  R283      -1.7675158381462097e-01
    z[1,0,2]  R284      1.3139372691512108e-02
    z[1,0,2]  R285      -0.291920006275177
    z[1,0,2]  R286      6.5194942057132721e-02
    z[1,0,2]  R287      -2.0398974418640137e-01
    z[1,0,2]  R288      -0.514629065990448
    z[1,0,2]  R289      0.0444374643266201
    z[1,0,2]  R290      3.4484487771987915e-01
    z[1,0,2]  R291      5.0325065851211548e-01
    z[1,0,2]  R292      -6.8468250334262848e-02
    z[1,0,2]  R293      5.2718663215637207e-01
    z[1,0,2]  R294      1.9963055849075317e-01
    z[1,0,3]  R5        1
    z[1,0,3]  R14       -1
    z[1,0,3]  R195      -1
    z[1,0,3]  R196      1
    z[1,0,3]  R203      -2.4189765751361847e-01
    z[1,0,3]  R204      -3.3917987346649170e-01
    z[1,0,3]  R205      4.2526509612798691e-02
    z[1,0,3]  R206      2.8479378670454025e-02
    z[1,0,3]  R207      1.1749300360679626e-01
    z[1,0,3]  R208      2.9178312420845032e-01
    z[1,0,3]  R209      5.5899225175380707e-02
    z[1,0,3]  R210      3.2622328400611877e-01
    z[1,0,3]  R211      -4.3790200352668762e-01
    z[1,0,3]  R212      -0.609557569026947
    z[1,0,3]  R213      1.0702575743198395e-01
    z[1,0,3]  R214      6.5374052524566650e-01
    z[1,0,3]  R215      2.7324968576431274e-01
    z[1,0,3]  R216      3.3977967500686646e-01
    z[1,0,3]  R217      -3.3968049287796021e-01
    z[1,0,3]  R218      3.1409987807273865e-01
    z[1,0,3]  R219      5.9229767322540283e-01
    z[1,0,3]  R220      4.7588908672332764e-01
    z[1,0,3]  R221      2.2977969050407410e-01
    z[1,0,3]  R222      -4.4816818833351135e-01
    z[1,0,3]  R223      -4.3633216619491577e-01
    z[1,0,3]  R224      -4.2344403266906738e-01
    z[1,0,3]  R225      -7.0720982551574707e-01
    z[1,0,3]  R226      -6.9758069515228271e-01
    z[1,0,3]  R227      -2.4126936495304108e-01
    z[1,0,3]  R228      -3.0696383118629456e-01
    z[1,0,3]  R229      -2.0187194645404816e-01
    z[1,0,3]  R230      -6.9268339872360229e-01
    z[1,0,3]  R231      -3.5274004936218262e-01
    z[1,0,3]  R232      3.8146394491195679e-01
    z[1,0,3]  R233      -4.5888921618461609e-01
    z[1,0,3]  R234      4.2126268148422241e-01
    z[1,0,3]  R235      6.2814855575561523e-01
    z[1,0,3]  R236      5.5779051780700684e-01
    z[1,0,3]  R237      5.6700974702835083e-01
    z[1,0,3]  R238      3.4470441937446594e-01
    z[1,0,3]  R239      4.9914455413818359e-01
    z[1,0,3]  R240      4.1553494334220886e-01
    z[1,0,3]  R241      3.6966013908386230e-01
    z[1,0,3]  R242      9.6126310527324677e-02
    z[1,0,3]  R243      5.7133400440216064e-01
    z[1,0,3]  R244      5.9475088119506836e-01
    z[1,0,3]  R245      -7.6354585587978363e-02
    z[1,0,3]  R246      1.8178611993789673e-01
    z[1,0,3]  R247      -4.2014512419700623e-01
    z[1,0,3]  R248      -4.1211771965026855e-01
    z[1,0,3]  R249      6.1982864141464233e-01
    z[1,0,3]  R250      1.6295839846134186e-01
    z[1,0,3]  R251      -1.9765029847621918e-01
    z[1,0,3]  R252      -5.0161361694335938e-01
    z[1,0,3]  R253      -2.3411202430725098e-01
    z[1,0,3]  R254      -6.1734235286712646e-01
    z[1,0,3]  R255      8.9579766988754272e-01
    z[1,0,3]  R256      -7.7933639287948608e-01
    z[1,0,3]  R257      -5.9990060329437256e-01
    z[1,0,3]  R258      8.5244961082935333e-02
    z[1,0,3]  R259      -3.2611685991287231e-01
    z[1,0,3]  R260      4.1469329595565796e-01
    z[1,0,3]  R261      1.8109214305877686e-01
    z[1,0,3]  R262      4.6539118885993958e-01
    z[1,0,3]  R263      1.2050674110651016e-01
    z[1,0,3]  R264      3.9610946178436279e-01
    z[1,0,3]  R265      -3.0852460861206055e-01
    z[1,0,3]  R266      3.4933799505233765e-01
    z[1,0,3]  R267      6.2043029069900513e-01
    z[1,0,3]  R268      7.1201616525650024e-01
    z[1,0,3]  R269      -3.2935658097267151e-01
    z[1,0,3]  R270      4.9749910831451416e-01
    z[1,0,3]  R271      -0.595457911491394
    z[1,0,3]  R272      4.0302717685699463e-01
    z[1,0,3]  R273      1.9613612443208694e-02
    z[1,0,3]  R274      2.4057655036449432e-01
    z[1,0,3]  R275      2.6396757364273071e-01
    z[1,0,3]  R276      -1.8983669579029083e-01
    z[1,0,3]  R277      -5.6722037494182587e-02
    z[1,0,3]  R278      6.0487186908721924e-01
    z[1,0,3]  R279      -1.7714852094650269e-01
    z[1,0,3]  R280      -5.5686396360397339e-01
    z[1,0,3]  R281      1.9345837831497192e-01
    z[1,0,3]  R282      -2.0902976393699646e-01
    z[1,0,3]  R283      4.4478651881217957e-01
    z[1,0,3]  R284      3.3601793646812439e-01
    z[1,0,3]  R285      0.655640721321106
    z[1,0,3]  R286      -2.3139376938343048e-01
    z[1,0,3]  R287      2.8733009099960327e-01
    z[1,0,3]  R288      -1.0046269744634628e-01
    z[1,0,3]  R289      -3.3963614702224731e-01
    z[1,0,3]  R290      6.7690014839172363e-01
    z[1,0,3]  R291      2.1949785947799683e-01
    z[1,0,3]  R292      4.9358087778091431e-01
    z[1,0,3]  R293      4.3031710386276245e-01
    z[1,0,3]  R294      7.8850097954273224e-02
    z[1,0,4]  R6        1
    z[1,0,4]  R15       -1
    z[1,0,4]  R197      -1
    z[1,0,4]  R198      1
    z[1,0,4]  R203      6.7818784713745117e-01
    z[1,0,4]  R204      -7.3060697317123413e-01
    z[1,0,4]  R205      4.3386703729629517e-01
    z[1,0,4]  R206      1.1272528767585754e-01
    z[1,0,4]  R207      1.1800088733434677e-01
    z[1,0,4]  R208      3.5040014982223511e-01
    z[1,0,4]  R209      -0.262971967458725
    z[1,0,4]  R210      1.3726362586021423e-01
    z[1,0,4]  R211      -9.2204205691814423e-02
    z[1,0,4]  R212      -1.9371549785137177e-01
    z[1,0,4]  R213      3.5541161894798279e-02
    z[1,0,4]  R214      -2.0237004756927490e-01
    z[1,0,4]  R215      1.2165561318397522e-01
    z[1,0,4]  R216      -3.6070284247398376e-01
    z[1,0,4]  R217      4.1045939922332764e-01
    z[1,0,4]  R218      1.6668954864144325e-02
    z[1,0,4]  R219      1.4215713739395142e-01
    z[1,0,4]  R220      4.3430402874946594e-02
    z[1,0,4]  R221      6.3840463757514954e-02
    z[1,0,4]  R222      -1.2974040210247040e-01
    z[1,0,4]  R223      -8.1952154636383057e-02
    z[1,0,4]  R224      -1.8370974063873291e-01
    z[1,0,4]  R225      1.2259913235902786e-01
    z[1,0,4]  R226      2.6392656564712524e-01
    z[1,0,4]  R227      4.6463202685117722e-02
    z[1,0,4]  R228      -3.5254594683647156e-01
    z[1,0,4]  R229      -2.4449007213115692e-01
    z[1,0,4]  R230      2.8654780983924866e-01
    z[1,0,4]  R231      -5.7972751557826996e-02
    z[1,0,4]  R232      -4.0461938828229904e-02
    z[1,0,4]  R233      -2.2709010541439056e-01
    z[1,0,4]  R234      -0.331691712141037
    z[1,0,4]  R235      9.4646655023097992e-02
    z[1,0,4]  R236      -4.7965649515390396e-02
    z[1,0,4]  R237      5.3363703191280365e-02
    z[1,0,4]  R238      1.8360137939453125e-01
    z[1,0,4]  R239      -1.9633080065250397e-01
    z[1,0,4]  R240      -1.4350116252899170e-01
    z[1,0,4]  R241      5.9857752174139023e-02
    z[1,0,4]  R242      1.1935921013355255e-01
    z[1,0,4]  R243      7.4213206768035889e-02
    z[1,0,4]  R244      6.1546668410301208e-02
    z[1,0,4]  R245      -6.4590275287628174e-02
    z[1,0,4]  R246      -3.2296633720397949e-01
    z[1,0,4]  R247      -1.5243685804307461e-02
    z[1,0,4]  R248      3.8030825555324554e-02
    z[1,0,4]  R249      3.1678044795989990e-01
    z[1,0,4]  R250      -7.3413648642599583e-03
    z[1,0,4]  R251      -2.7928823605179787e-02
    z[1,0,4]  R252      -2.2214733064174652e-01
    z[1,0,4]  R253      2.4055325984954834e-01
    z[1,0,4]  R254      7.1519844233989716e-02
    z[1,0,4]  R255      1.5579383075237274e-01
    z[1,0,4]  R256      1.6558946669101715e-01
    z[1,0,4]  R257      -3.2959397882223129e-02
    z[1,0,4]  R258      1.9690386950969696e-01
    z[1,0,4]  R259      6.4184583723545074e-02
    z[1,0,4]  R260      2.3151208460330963e-01
    z[1,0,4]  R261      -1.0148895531892776e-01
    z[1,0,4]  R262      2.3119370639324188e-01
    z[1,0,4]  R263      3.2638299465179443e-01
    z[1,0,4]  R264      1.8954484164714813e-01
    z[1,0,4]  R265      -2.1056285500526428e-01
    z[1,0,4]  R266      2.6625737547874451e-01
    z[1,0,4]  R267      -2.0119942724704742e-01
    z[1,0,4]  R268      -3.2164674997329712e-01
    z[1,0,4]  R269      4.9756950139999390e-01
    z[1,0,4]  R270      -4.0620166063308716e-01
    z[1,0,4]  R271      -0.129534512758255
    z[1,0,4]  R272      2.8277760744094849e-01
    z[1,0,4]  R273      1.3353681564331055e-01
    z[1,0,4]  R274      -4.8810219764709473e-01
    z[1,0,4]  R275      2.2378638386726379e-01
    z[1,0,4]  R276      -7.5205512344837189e-02
    z[1,0,4]  R277      8.6364768445491791e-02
    z[1,0,4]  R278      1.6309115290641785e-01
    z[1,0,4]  R279      -2.0140078663825989e-01
    z[1,0,4]  R280      1.1269237147644162e-03
    z[1,0,4]  R281      -5.0101685523986816e-01
    z[1,0,4]  R282      -2.0102441310882568e-01
    z[1,0,4]  R283      2.6743793487548828e-01
    z[1,0,4]  R284      3.7970918416976929e-01
    z[1,0,4]  R285      4.4239366054534912e-01
    z[1,0,4]  R286      2.2575096786022186e-01
    z[1,0,4]  R287      9.5553815364837646e-02
    z[1,0,4]  R288      -5.1294457912445068e-01
    z[1,0,4]  R289      -4.4900581240653992e-01
    z[1,0,4]  R290      7.5459964573383331e-02
    z[1,0,4]  R291      4.7838100790977478e-01
    z[1,0,4]  R292      2.4804225564002991e-01
    z[1,0,4]  R293      -2.0714102685451508e-01
    z[1,0,4]  R294      -0.0595281757414341
    z[1,0,5]  R7        1
    z[1,0,5]  R16       -1
    z[1,0,5]  R199      -1
    z[1,0,5]  R200      1
    z[1,0,5]  R203      -7.3558405041694641e-02
    z[1,0,5]  R204      2.1748398244380951e-01
    z[1,0,5]  R205      1.1583929508924484e-01
    z[1,0,5]  R206      3.4561118483543396e-01
    z[1,0,5]  R207      3.9490637183189392e-01
    z[1,0,5]  R208      1.4406548440456390e-01
    z[1,0,5]  R209      -0.0522085502743721
    z[1,0,5]  R210      -2.1412852406501770e-01
    z[1,0,5]  R211      -2.4928821623325348e-01
    z[1,0,5]  R212      6.8778353743255138e-03
    z[1,0,5]  R213      3.2511085271835327e-01
    z[1,0,5]  R214      -2.6931858062744141e-01
    z[1,0,5]  R215      -5.1344615221023560e-01
    z[1,0,5]  R216      -5.2290058135986328e-01
    z[1,0,5]  R217      5.3218550980091095e-02
    z[1,0,5]  R218      -1.3850098848342896e-01
    z[1,0,5]  R219      -6.3376188278198242e-02
    z[1,0,5]  R220      -3.0528476834297180e-01
    z[1,0,5]  R221      -4.8538818955421448e-01
    z[1,0,5]  R222      -1.2154900282621384e-01
    z[1,0,5]  R223      -6.7240279912948608e-01
    z[1,0,5]  R224      -5.2716493606567383e-01
    z[1,0,5]  R225      -1.9956852495670319e-01
    z[1,0,5]  R226      2.0951206982135773e-01
    z[1,0,5]  R227      -1.6466975212097168e-01
    z[1,0,5]  R228      -4.5666342973709106e-01
    z[1,0,5]  R229      -2.9176460579037666e-02
    z[1,0,5]  R230      1.9770933687686920e-01
    z[1,0,5]  R231      5.5945134162902832e-01
    z[1,0,5]  R232      -1.6124244034290314e-01
    z[1,0,5]  R233      1.6466896235942841e-01
    z[1,0,5]  R234      -1.2085715681314468e-01
    z[1,0,5]  R235      -4.3522989749908447e-01
    z[1,0,5]  R236      -4.2333969473838806e-01
    z[1,0,5]  R237      -2.8290903568267822e-01
    z[1,0,5]  R238      -5.5686312913894653e-01
    z[1,0,5]  R239      -4.0836516022682190e-01
    z[1,0,5]  R240      -3.2412597537040710e-01
    z[1,0,5]  R241      -3.8572993874549866e-01
    z[1,0,5]  R242      -7.1814113855361938e-01
    z[1,0,5]  R243      -2.9740974307060242e-01
    z[1,0,5]  R244      5.8317895978689194e-02
    z[1,0,5]  R245      -4.8274996876716614e-01
    z[1,0,5]  R246      5.1724809408187866e-01
    z[1,0,5]  R247      -4.6995180845260620e-01
    z[1,0,5]  R248      3.5755565762519836e-01
    z[1,0,5]  R249      -3.3992937207221985e-01
    z[1,0,5]  R250      -9.5896673202514648e-01
    z[1,0,5]  R251      0.281389981508255
    z[1,0,5]  R252      -1.3235056400299072e-01
    z[1,0,5]  R253      -5.0508117675781250e-01
    z[1,0,5]  R254      -4.1683351993560791e-01
    z[1,0,5]  R255      -1.5273775160312653e-01
    z[1,0,5]  R256      1.3021574914455414e-01
    z[1,0,5]  R257      4.3204712867736816e-01
    z[1,0,5]  R258      -1.8467260897159576e-01
    z[1,0,5]  R259      1.7204004526138306e-01
    z[1,0,5]  R260      -3.0417588353157043e-01
    z[1,0,5]  R261      3.4708064794540405e-01
    z[1,0,5]  R262      3.9442703127861023e-01
    z[1,0,5]  R263      2.9866768047213554e-02
    z[1,0,5]  R264      -2.0194509997963905e-02
    z[1,0,5]  R265      -2.4880267679691315e-01
    z[1,0,5]  R266      -6.2224805355072021e-01
    z[1,0,5]  R267      -4.2498525977134705e-01
    z[1,0,5]  R268      -2.0908093452453613e-01
    z[1,0,5]  R269      -5.1655232906341553e-02
    z[1,0,5]  R270      -2.6204457506537437e-02
    z[1,0,5]  R271      -2.5494593381881714e-01
    z[1,0,5]  R272      -3.1170985102653503e-01
    z[1,0,5]  R273      -2.5660762190818787e-01
    z[1,0,5]  R274      -4.5631803572177887e-02
    z[1,0,5]  R275      -6.5560504794120789e-02
    z[1,0,5]  R276      4.0770357847213745e-01
    z[1,0,5]  R277      -0.0376245491206646
    z[1,0,5]  R278      -2.2379907965660095e-01
    z[1,0,5]  R279      1.3422715663909912e-01
    z[1,0,5]  R280      2.3163928091526031e-01
    z[1,0,5]  R281      7.7741943299770355e-02
    z[1,0,5]  R282      3.0385997891426086e-01
    z[1,0,5]  R283      1.6005125641822815e-01
    z[1,0,5]  R284      5.8769159018993378e-02
    z[1,0,5]  R285      -3.8271471858024597e-01
    z[1,0,5]  R286      -5.6668068282306194e-03
    z[1,0,5]  R287      -2.1352672576904297e-01
    z[1,0,5]  R288      -1.6919773817062378e-01
    z[1,0,5]  R289      -4.8728186637163162e-02
    z[1,0,5]  R290      0.297302782535553
    z[1,0,5]  R291      8.2587942481040955e-02
    z[1,0,5]  R292      6.0453391075134277e-01
    z[1,0,5]  R293      3.1147131323814392e-01
    z[1,0,5]  R294      5.0482434034347534e-01
    z[1,0,6]  R8        1
    z[1,0,6]  R17       -1
    z[1,0,6]  R201      -1
    z[1,0,6]  R202      1
    z[1,0,6]  R203      -4.1801211237907410e-01
    z[1,0,6]  R204      -6.7914955317974091e-02
    z[1,0,6]  R205      1.4326995611190796e-01
    z[1,0,6]  R206      1.2739814817905426e-01
    z[1,0,6]  R207      -1.7883436381816864e-01
    z[1,0,6]  R208      -1.5309639275074005e-01
    z[1,0,6]  R209      1.7161594331264496e-01
    z[1,0,6]  R210      6.5535253286361694e-01
    z[1,0,6]  R211      0.557294487953186
    z[1,0,6]  R212      2.5904360413551331e-01
    z[1,0,6]  R213      0.709159791469574
    z[1,0,6]  R214      -1.2396611273288727e-01
    z[1,0,6]  R215      2.3874849081039429e-01
    z[1,0,6]  R216      -1.4659132808446884e-02
    z[1,0,6]  R217      4.7780883312225342e-01
    z[1,0,6]  R218      -3.1167024746537209e-02
    z[1,0,6]  R219      -1.1275658756494522e-01
    z[1,0,6]  R220      2.0083774626255035e-01
    z[1,0,6]  R221      -6.8739682435989380e-02
    z[1,0,6]  R222      1.0149707645177841e-01
    z[1,0,6]  R223      0.15589639544487
    z[1,0,6]  R224      2.3175662755966187e-01
    z[1,0,6]  R225      -4.3116754293441772e-01
    z[1,0,6]  R226      3.9251565933227539e-01
    z[1,0,6]  R227      1.1157218366861343e-01
    z[1,0,6]  R228      4.0498995780944824e-01
    z[1,0,6]  R229      -3.6586725711822510e-01
    z[1,0,6]  R230      -2.3382523655891418e-01
    z[1,0,6]  R231      -6.5789207816123962e-02
    z[1,0,6]  R232      -1.5175785124301910e-01
    z[1,0,6]  R233      0.268466979265213
    z[1,0,6]  R234      3.9267953485250473e-02
    z[1,0,6]  R235      4.5309510827064514e-01
    z[1,0,6]  R236      -3.9014050364494324e-01
    z[1,0,6]  R237      -6.7857891321182251e-01
    z[1,0,6]  R238      -5.5796837806701660e-01
    z[1,0,6]  R239      -2.0839789882302284e-02
    z[1,0,6]  R240      -0.642281711101532
    z[1,0,6]  R241      -3.5570108890533447e-01
    z[1,0,6]  R242      -3.3160585165023804e-01
    z[1,0,6]  R243      -1.7723254859447479e-01
    z[1,0,6]  R244      1.1587673425674438e-01
    z[1,0,6]  R245      -3.5515061020851135e-01
    z[1,0,6]  R246      -1.6898328065872192e-01
    z[1,0,6]  R247      2.1050535142421722e-01
    z[1,0,6]  R248      -5.1412478089332581e-02
    z[1,0,6]  R249      3.0915224552154541e-01
    z[1,0,6]  R250      -7.8972905874252319e-02
    z[1,0,6]  R251      3.3543251920491457e-03
    z[1,0,6]  R252      3.7385997176170349e-01
    z[1,0,6]  R253      3.1316413078457117e-03
    z[1,0,6]  R254      3.4802260994911194e-01
    z[1,0,6]  R255      -2.8481009602546692e-01
    z[1,0,6]  R256      -9.0197168290615082e-02
    z[1,0,6]  R257      1.4108563959598541e-01
    z[1,0,6]  R258      2.5622019171714783e-01
    z[1,0,6]  R259      -4.7528293728828430e-01
    z[1,0,6]  R260      -7.7281542122364044e-02
    z[1,0,6]  R261      4.0720129013061523e-01
    z[1,0,6]  R262      -1.1024359613656998e-01
    z[1,0,6]  R263      2.0571835339069366e-02
    z[1,0,6]  R264      5.8386242389678955e-01
    z[1,0,6]  R265      3.2262188196182251e-01
    z[1,0,6]  R266      -0.536336362361908
    z[1,0,6]  R267      7.7055029571056366e-02
    z[1,0,6]  R268      -3.2069790363311768e-01
    z[1,0,6]  R269      3.3036038279533386e-01
    z[1,0,6]  R270      2.7265515923500061e-01
    z[1,0,6]  R271      -1.6381666064262390e-01
    z[1,0,6]  R272      -5.6212997436523438e-01
    z[1,0,6]  R273      6.5752077102661133e-01
    z[1,0,6]  R274      5.4147444665431976e-02
    z[1,0,6]  R275      -6.9317850284278393e-03
    z[1,0,6]  R276      1.5720768272876740e-01
    z[1,0,6]  R277      -4.1065523028373718e-01
    z[1,0,6]  R278      2.3426532745361328e-01
    z[1,0,6]  R279      -2.1056310832500458e-01
    z[1,0,6]  R280      -5.1340326666831970e-02
    z[1,0,6]  R281      2.3974737524986267e-01
    z[1,0,6]  R282      -3.5421723127365112e-01
    z[1,0,6]  R283      -1.3048692047595978e-01
    z[1,0,6]  R284      1.4695557951927185e-01
    z[1,0,6]  R285      -9.6959307789802551e-02
    z[1,0,6]  R286      -1.6584932804107666e-01
    z[1,0,6]  R287      3.2100099325180054e-01
    z[1,0,6]  R288      3.5137336701154709e-02
    z[1,0,6]  R289      -5.9348177909851074e-01
    z[1,0,6]  R290      -1.4876598119735718e-01
    z[1,0,6]  R291      9.9936850368976593e-02
    z[1,0,6]  R292      2.5252452492713928e-01
    z[1,0,6]  R293      3.1249606609344482e-01
    z[1,0,6]  R294      5.6591600179672241e-01
    z[0,5,0]  R2        -1
    z[0,5,0]  R47       1
    z[0,5,0]  R295      -1
    z[0,5,0]  R296      1
    z[0,5,0]  R309      -3.6848965287208557e-01
    z[0,5,0]  R310      7.4506118893623352e-02
    z[0,5,0]  R311      -4.3569985032081604e-01
    z[0,5,0]  R312      5.7732496410608292e-02
    z[0,5,0]  R313      -1.1502807587385178e-01
    z[0,5,0]  R314      -2.4476386606693268e-01
    z[0,5,0]  R315      2.2146110236644745e-01
    z[0,5,0]  R316      6.8804420530796051e-02
    z[0,5,0]  R317      -5.7788819074630737e-02
    z[0,5,0]  R318      1.6723388433456421e-01
    z[0,5,0]  R319      -2.5952938199043274e-01
    z[0,5,0]  R320      -4.5666435360908508e-01
    z[0,5,0]  R321      -2.4800752103328705e-01
    z[0,5,0]  R322      3.2661882042884827e-01
    z[0,5,0]  R323      -3.2229042053222656e-01
    z[0,5,0]  R324      4.2880225181579590e-01
    z[0,5,0]  R325      0.649897575378418
    z[0,5,0]  R326      4.7318503260612488e-01
    z[0,5,0]  R327      -9.9350020289421082e-02
    z[0,5,0]  R328      6.8418934941291809e-02
    z[0,5,0]  R329      -1.8654868006706238e-01
    z[0,5,0]  R330      8.1839069724082947e-02
    z[0,5,0]  R331      -1.3905237615108490e-01
    z[0,5,0]  R332      -3.1382462382316589e-01
    z[0,5,0]  R333      2.4938400089740753e-01
    z[0,5,0]  R334      3.9992492645978928e-02
    z[0,5,0]  R335      -6.3366031646728516e-01
    z[0,5,0]  R336      -1.3271619379520416e-01
    z[0,5,0]  R337      2.2186957299709320e-01
    z[0,5,0]  R338      -3.6631923913955688e-01
    z[0,5,0]  R339      -3.2499887049198151e-02
    z[0,5,0]  R340      -3.2112231850624084e-01
    z[0,5,0]  R341      -1.4242365024983883e-02
    z[0,5,0]  R342      -6.5282315015792847e-01
    z[0,5,0]  R343      -6.7952924966812134e-01
    z[0,5,0]  R344      2.6820677518844604e-01
    z[0,5,0]  R345      -5.1666241884231567e-01
    z[0,5,0]  R346      2.6198202371597290e-01
    z[0,5,0]  R347      6.4260315895080566e-01
    z[0,5,0]  R348      -6.7581719160079956e-01
    z[0,5,0]  R349      -1.8442372977733612e-01
    z[0,5,0]  R350      -3.3599093556404114e-01
    z[0,5,0]  R351      0.606364369392395
    z[0,5,0]  R352      7.7782802283763885e-02
    z[0,5,0]  R353      2.6149311661720276e-01
    z[0,5,0]  R354      2.3175060749053955e-01
    z[0,5,0]  R355      -2.5962504744529724e-01
    z[0,5,0]  R356      5.3548002243041992e-01
    z[0,5,0]  R357      2.5886717438697815e-01
    z[0,5,0]  R358      2.9464939236640930e-01
    z[0,5,0]  R359      2.6722711324691772e-01
    z[0,5,0]  R360      -2.3365625739097595e-01
    z[0,5,0]  R361      0.0499470978975296
    z[0,5,0]  R362      5.3919935226440430e-01
    z[0,5,0]  R363      -4.9655294418334961e-01
    z[0,5,0]  R364      2.09329737117514e-05
    z[0,5,0]  R365      -2.3614892363548279e-01
    z[0,5,0]  R366      -1.4662164449691772e-01
    z[0,5,0]  R367      -8.0243217945098877e-01
    z[0,5,0]  R368      -8.3219474554061890e-01
    z[0,5,0]  R369      -0.347666472196579
    z[0,5,0]  R370      -6.2047320604324341e-01
    z[0,5,0]  R371      -8.2506549358367920e-01
    z[0,5,0]  R372      1.6997131705284119e-01
    z[0,5,0]  R373      -3.8668278604745865e-02
    z[0,5,0]  R374      8.1161573529243469e-02
    z[0,5,0]  R375      -2.1208256483078003e-01
    z[0,5,0]  R376      2.9422247409820557e-01
    z[0,5,0]  R377      -3.4678983688354492e-01
    z[0,5,0]  R378      -8.5808329284191132e-02
    z[0,5,0]  R379      -4.1581445932388306e-01
    z[0,5,0]  R380      -7.1382147073745728e-01
    z[0,5,0]  R381      -4.4117593765258789e-01
    z[0,5,0]  R382      3.0876708030700684e-01
    z[0,5,0]  R383      -0.468372106552124
    z[0,5,0]  R384      3.7482929229736328e-01
    z[0,5,0]  R385      3.0678293108940125e-01
    z[0,5,0]  R386      2.1084308624267578e-01
    z[0,5,0]  R387      -1.6066245734691620e-01
    z[0,5,0]  R388      -1.2283680588006973e-01
    z[0,5,0]  R389      1.3883158564567566e-01
    z[0,5,0]  R390      2.9173580929636955e-02
    z[0,5,0]  R391      4.5376399159431458e-01
    z[0,5,0]  R392      2.4065634608268738e-01
    z[0,5,0]  R393      7.0959097146987915e-01
    z[0,5,0]  R394      -6.0118097066879272e-01
    z[0,5,0]  R395      -4.8264107108116150e-01
    z[0,5,0]  R396      0.0402534045279026
    z[0,5,0]  R397      6.0055327415466309e-01
    z[0,5,0]  R398      -8.7000322341918945e-01
    z[0,5,0]  R399      -1.6710819303989410e-01
    z[0,5,0]  R400      5.1962143182754517e-01
    z[0,5,0]  R401      2.4668073654174805e-01
    z[0,5,0]  R402      2.4670842289924622e-01
    z[0,5,0]  R403      1.4420443773269653e-01
    z[0,5,0]  R404      -5.6685519218444824e-01
    z[0,5,0]  R405      -1.6137033700942993e-01
    z[0,5,0]  R406      -6.2655562162399292e-01
    z[0,5,0]  R407      2.0319147035479546e-02
    z[0,5,0]  R408      -4.3238359689712524e-01
    z[0,5,0]  R409      1.7326253652572632e-01
    z[0,5,0]  R410      0.472392737865448
    z[0,5,0]  R411      2.1025046706199646e-01
    z[0,5,0]  R412      -1.4568910002708435e-01
    z[0,5,0]  R413      -2.6236453652381897e-01
    z[0,5,0]  R414      -2.3091338574886322e-01
    z[0,5,0]  R415      2.8852918744087219e-01
    z[0,5,0]  R416      -5.0840634107589722e-01
    z[0,5,0]  R417      5.3634464740753174e-01
    z[0,5,0]  R418      -1.7589415609836578e-01
    z[0,5,0]  R419      2.1643792092800140e-01
    z[0,5,0]  R420      3.8719531893730164e-01
    z[0,5,0]  R421      -3.2949864864349365e-01
    z[0,5,0]  R422      3.3848136663436890e-01
    z[0,5,0]  R423      -3.5411331057548523e-01
    z[0,5,0]  R424      -0.465248167514801
    z[0,5,0]  R425      2.3825326561927795e-01
    z[0,5,0]  R426      5.5241864919662476e-01
    z[0,5,0]  R427      -0.437234103679657
    z[0,5,0]  R428      -5.3801500797271729e-01
    z[0,5,0]  R429      3.4132543206214905e-01
    z[0,5,0]  R430      -2.3048569262027740e-01
    z[0,5,0]  R431      0.0930616706609726
    z[0,5,0]  R432      2.5502392649650574e-01
    z[0,5,0]  R433      -1.9639667868614197e-01
    z[0,5,0]  R434      -3.8214358687400818e-01
    z[0,5,0]  R435      -5.0560951232910156e-01
    z[0,5,0]  R436      -3.2939481735229492e-01
    z[0,5,0]  R437      -3.9098620414733887e-01
    z[0,5,0]  R438      -3.3695119619369507e-01
    z[0,5,0]  R439      -3.5032325983047485e-01
    z[0,5,0]  R440      -4.1307485103607178e-01
    z[0,5,0]  R441      -3.8969355821609497e-01
    z[0,5,0]  R442      3.5542088747024536e-01
    z[0,5,0]  R443      5.8741962909698486e-01
    z[0,5,0]  R444      -9.3581545352935791e-01
    z[0,5,0]  R445      2.1107417345046997e-01
    z[0,5,0]  R446      -9.1353046894073486e-01
    z[0,5,0]  R447      1.0356234014034271e-01
    z[0,5,0]  R448      2.6287612318992615e-01
    z[0,5,0]  R449      -3.2082059979438782e-01
    z[0,5,0]  R450      3.8107904791831970e-01
    z[0,5,0]  R451      -1.7919836938381195e-01
    z[0,5,0]  R452      1.4544046483933926e-02
    z[0,5,0]  R453      3.7239700555801392e-01
    z[0,5,0]  R454      -5.5211794376373291e-01
    z[0,5,0]  R455      -6.5027683973312378e-01
    z[0,5,0]  R456      -4.2978027462959290e-01
    z[0,5,0]  R457      -2.2500525414943695e-01
    z[0,5,0]  R458      -4.1538852453231812e-01
    z[0,5,1]  R3        -1
    z[0,5,1]  R48       1
    z[0,5,1]  R297      -1
    z[0,5,1]  R298      1
    z[0,5,1]  R309      -2.2264370322227478e-01
    z[0,5,1]  R310      -2.1294246613979340e-01
    z[0,5,1]  R311      -1.3836251199245453e-01
    z[0,5,1]  R312      -0.435705304145813
    z[0,5,1]  R313      -2.0301729440689087e-01
    z[0,5,1]  R314      -3.1558337807655334e-01
    z[0,5,1]  R315      -2.7847656607627869e-01
    z[0,5,1]  R316      7.6416528224945068e-01
    z[0,5,1]  R317      -7.8548008203506470e-01
    z[0,5,1]  R318      8.0665594339370728e-01
    z[0,5,1]  R319      -3.3685964345932007e-01
    z[0,5,1]  R320      2.7346780896186829e-01
    z[0,5,1]  R321      2.7014365792274475e-01
    z[0,5,1]  R322      -3.3656972646713257e-01
    z[0,5,1]  R323      -8.8725142180919647e-02
    z[0,5,1]  R324      2.8172996640205383e-01
    z[0,5,1]  R325      3.6521452665328979e-01
    z[0,5,1]  R326      2.9680988192558289e-01
    z[0,5,1]  R327      4.8430547118186951e-01
    z[0,5,1]  R328      -5.7254844903945923e-01
    z[0,5,1]  R329      -7.4589270353317261e-01
    z[0,5,1]  R330      -7.4100983142852783e-01
    z[0,5,1]  R331      -7.2726887464523315e-01
    z[0,5,1]  R332      -6.7125785350799561e-01
    z[0,5,1]  R333      1.5988697111606598e-01
    z[0,5,1]  R334      1.8887175619602203e-01
    z[0,5,1]  R335      -5.4959356784820557e-01
    z[0,5,1]  R336      -6.7379742860794067e-01
    z[0,5,1]  R337      -6.6956084966659546e-01
    z[0,5,1]  R338      -3.9947167038917542e-01
    z[0,5,1]  R339      -5.3852275013923645e-02
    z[0,5,1]  R340      -4.7587621212005615e-01
    z[0,5,1]  R341      -6.2989002466201782e-01
    z[0,5,1]  R342      -6.2229627370834351e-01
    z[0,5,1]  R343      -4.0601894259452820e-01
    z[0,5,1]  R344      7.7640879154205322e-01
    z[0,5,1]  R345      -6.0742509365081787e-01
    z[0,5,1]  R346      -5.3855621814727783e-01
    z[0,5,1]  R347      -4.3175691366195679e-01
    z[0,5,1]  R348      -4.1912712156772614e-02
    z[0,5,1]  R349      -0.726190984249115
    z[0,5,1]  R350      -1.2535278499126434e-01
    z[0,5,1]  R351      -1.4139276742935181e-01
    z[0,5,1]  R352      1.7624922096729279e-01
    z[0,5,1]  R353      -6.6605895757675171e-01
    z[0,5,1]  R354      -6.7663162946701050e-01
    z[0,5,1]  R355      -4.1021513938903809e-01
    z[0,5,1]  R356      2.2009445726871490e-01
    z[0,5,1]  R357      -5.6356501579284668e-01
    z[0,5,1]  R358      -5.3775697946548462e-01
    z[0,5,1]  R359      -8.9600396156311035e-01
    z[0,5,1]  R360      -7.5159054994583130e-01
    z[0,5,1]  R361      -0.684525728225708
    z[0,5,1]  R362      3.8078734278678894e-01
    z[0,5,1]  R363      -6.9227421283721924e-01
    z[0,5,1]  R364      -2.9972484707832336e-01
    z[0,5,1]  R365      -0.756924569606781
    z[0,5,1]  R366      -3.3998182415962219e-01
    z[0,5,1]  R367      1.1340260505676270e-01
    z[0,5,1]  R368      1.5856340527534485e-01
    z[0,5,1]  R369      1.1163343489170074e-01
    z[0,5,1]  R370      -6.9189441204071045e-01
    z[0,5,1]  R371      -1.9321131706237793e-01
    z[0,5,1]  R372      -6.3497972488403320e-01
    z[0,5,1]  R373      -5.7006675004959106e-01
    z[0,5,1]  R374      5.4780155420303345e-01
    z[0,5,1]  R375      6.3868921995162964e-01
    z[0,5,1]  R376      4.1757425665855408e-01
    z[0,5,1]  R377      4.2315801978111267e-01
    z[0,5,1]  R378      6.0656005144119263e-01
    z[0,5,1]  R379      5.9958990663290024e-02
    z[0,5,1]  R380      -5.2166921086609364e-03
    z[0,5,1]  R381      -4.1477791965007782e-02
    z[0,5,1]  R382      7.3133128881454468e-01
    z[0,5,1]  R383      -0.0706862360239029
    z[0,5,1]  R384      6.9081479310989380e-01
    z[0,5,1]  R385      6.9255203008651733e-01
    z[0,5,1]  R386      7.9167377948760986e-01
    z[0,5,1]  R387      6.6974085569381714e-01
    z[0,5,1]  R388      8.5541135072708130e-01
    z[0,5,1]  R389      2.6883864402770996e-01
    z[0,5,1]  R390      -1.3114847242832184e-01
    z[0,5,1]  R391      2.3110222816467285e-01
    z[0,5,1]  R392      -1.0313341766595840e-01
    z[0,5,1]  R393      3.4971255064010620e-01
    z[0,5,1]  R394      2.2228454053401947e-01
    z[0,5,1]  R395      1.7723912000656128e-01
    z[0,5,1]  R396      1.1129811406135559e-01
    z[0,5,1]  R397      -4.2762002348899841e-01
    z[0,5,1]  R398      -2.9504433274269104e-01
    z[0,5,1]  R399      -1.4158391952514648e-01
    z[0,5,1]  R400      -0.139053076505661
    z[0,5,1]  R401      -6.5932208299636841e-01
    z[0,5,1]  R402      -5.9185934066772461e-01
    z[0,5,1]  R403      -0.632899284362793
    z[0,5,1]  R404      -6.1066597700119019e-01
    z[0,5,1]  R405      5.5079009383916855e-02
    z[0,5,1]  R406      -6.1779773235321045e-01
    z[0,5,1]  R407      -5.3355228900909424e-01
    z[0,5,1]  R408      -1.7407085001468658e-01
    z[0,5,1]  R409      3.0003988742828369e-01
    z[0,5,1]  R410      -7.3637050390243530e-01
    z[0,5,1]  R411      -6.3921970129013062e-01
    z[0,5,1]  R412      -7.4083238840103149e-01
    z[0,5,1]  R413      3.7029862403869629e-01
    z[0,5,1]  R414      -0.419521301984787
    z[0,5,1]  R415      -7.4704664945602417e-01
    z[0,5,1]  R416      4.4451199471950531e-02
    z[0,5,1]  R417      -5.7193356752395630e-01
    z[0,5,1]  R418      -7.1301937103271484e-01
    z[0,5,1]  R419      -7.0517992973327637e-01
    z[0,5,1]  R420      -7.2905343770980835e-01
    z[0,5,1]  R421      5.4468762874603271e-01
    z[0,5,1]  R422      -7.1067941188812256e-01
    z[0,5,1]  R423      -6.4033544063568115e-01
    z[0,5,1]  R424      -2.7156734466552734e-01
    z[0,5,1]  R425      -6.5268623828887939e-01
    z[0,5,1]  R426      -6.1438292264938354e-01
    z[0,5,1]  R427      -5.6438845396041870e-01
    z[0,5,1]  R428      -5.1818257570266724e-01
    z[0,5,1]  R429      -9.1968756914138794e-01
    z[0,5,1]  R430      9.4391658902168274e-02
    z[0,5,1]  R431      1.7546078190207481e-02
    z[0,5,1]  R432      -1.4050704240798950e-01
    z[0,5,1]  R433      3.2863533496856689e-01
    z[0,5,1]  R434      -7.3782926797866821e-01
    z[0,5,1]  R435      1.0161117464303970e-01
    z[0,5,1]  R436      -3.3437675237655640e-01
    z[0,5,1]  R437      -4.8662039637565613e-01
    z[0,5,1]  R438      -9.6070962026715279e-03
    z[0,5,1]  R439      -4.6856346726417542e-01
    z[0,5,1]  R440      -0.628913938999176
    z[0,5,1]  R441      4.7408949583768845e-02
    z[0,5,1]  R442      5.6012964248657227e-01
    z[0,5,1]  R443      6.2852632999420166e-01
    z[0,5,1]  R444      1.2805540859699249e-01
    z[0,5,1]  R445      7.2681987285614014e-01
    z[0,5,1]  R446      -7.2500887326896191e-03
    z[0,5,1]  R447      6.6576778888702393e-01
    z[0,5,1]  R448      1.2854360044002533e-01
    z[0,5,1]  R449      -7.1572464704513550e-01
    z[0,5,1]  R450      -7.2007365524768829e-02
    z[0,5,1]  R451      -5.9405052661895752e-01
    z[0,5,1]  R452      6.4080238342285156e-01
    z[0,5,1]  R453      0.0572831854224205
    z[0,5,1]  R454      -5.4361337423324585e-01
    z[0,5,1]  R455      -0.56270432472229
    z[0,5,1]  R456      -1.3700662553310394e-01
    z[0,5,1]  R457      -0.588896632194519
    z[0,5,1]  R458      -1.1941631138324738e-01
    z[0,5,2]  R4        -1
    z[0,5,2]  R49       1
    z[0,5,2]  R299      -1
    z[0,5,2]  R300      1
    z[0,5,2]  R309      2.7154350280761719e-01
    z[0,5,2]  R310      4.4143462181091309e-01
    z[0,5,2]  R311      8.3131664991378784e-01
    z[0,5,2]  R312      4.6449339389801025e-01
    z[0,5,2]  R313      8.4280174970626831e-01
    z[0,5,2]  R314      -4.2990061640739441e-01
    z[0,5,2]  R315      6.5445041656494141e-01
    z[0,5,2]  R316      0.463827520608902
    z[0,5,2]  R317      -1.3543221354484558e-01
    z[0,5,2]  R318      -1.3307537138462067e-01
    z[0,5,2]  R319      1.4464181661605835e-01
    z[0,5,2]  R320      2.6798495650291443e-01
    z[0,5,2]  R321      -2.5691960006952286e-02
    z[0,5,2]  R322      7.8006774187088013e-02
    z[0,5,2]  R323      -6.5830785036087036e-01
    z[0,5,2]  R324      1.6097073256969452e-01
    z[0,5,2]  R325      -1.6943724453449249e-01
    z[0,5,2]  R326      1.9703787565231323e-01
    z[0,5,2]  R327      -5.5116581916809082e-01
    z[0,5,2]  R328      -5.4144448041915894e-01
    z[0,5,2]  R329      1.9915345311164856e-01
    z[0,5,2]  R330      1.0369341075420380e-01
    z[0,5,2]  R331      9.9111318588256836e-02
    z[0,5,2]  R332      3.8619977235794067e-01
    z[0,5,2]  R333      -4.6538066864013672e-01
    z[0,5,2]  R334      -1.0131541639566422e-01
    z[0,5,2]  R335      4.2116996645927429e-01
    z[0,5,2]  R336      2.6482033729553223e-01
    z[0,5,2]  R337      -3.6697569489479065e-01
    z[0,5,2]  R338      1.5854367613792419e-01
    z[0,5,2]  R339      2.5470137596130371e-01
    z[0,5,2]  R340      1.0269098728895187e-01
    z[0,5,2]  R341      1.8841113150119781e-01
    z[0,5,2]  R342      -2.0193751156330109e-01
    z[0,5,2]  R343      0.0861692801117897
    z[0,5,2]  R344      -3.4506402909755707e-02
    z[0,5,2]  R345      -1.8633969128131866e-01
    z[0,5,2]  R346      -4.5117273926734924e-01
    z[0,5,2]  R347      5.2752655744552612e-01
    z[0,5,2]  R348      8.5915029048919678e-02
    z[0,5,2]  R349      3.6486014723777771e-01
    z[0,5,2]  R350      -6.0144379734992981e-02
    z[0,5,2]  R351      1.9117403775453568e-02
    z[0,5,2]  R352      -4.5376253128051758e-01
    z[0,5,2]  R353      1.4187838137149811e-01
    z[0,5,2]  R354      -3.0472939833998680e-02
    z[0,5,2]  R355      5.4875838756561279e-01
    z[0,5,2]  R356      9.6292868256568909e-02
    z[0,5,2]  R357      3.1461793184280396e-01
    z[0,5,2]  R358      5.6821137666702271e-01
    z[0,5,2]  R359      -4.0757302194833755e-02
    z[0,5,2]  R360      3.8455966114997864e-01
    z[0,5,2]  R361      -0.590084969997406
    z[0,5,2]  R362      2.5851535797119141e-01
    z[0,5,2]  R363      -0.374023973941803
    z[0,5,2]  R364      7.3741018772125244e-01
    z[0,5,2]  R365      -1.3904018700122833e-01
    z[0,5,2]  R366      7.4900567531585693e-01
    z[0,5,2]  R367      -1.7675158381462097e-01
    z[0,5,2]  R368      1.3139372691512108e-02
    z[0,5,2]  R369      -0.291920006275177
    z[0,5,2]  R370      6.5194942057132721e-02
    z[0,5,2]  R371      -2.0398974418640137e-01
    z[0,5,2]  R372      -0.514629065990448
    z[0,5,2]  R373      0.0444374643266201
    z[0,5,2]  R374      3.4484487771987915e-01
    z[0,5,2]  R375      5.0325065851211548e-01
    z[0,5,2]  R376      -6.8468250334262848e-02
    z[0,5,2]  R377      5.2718663215637207e-01
    z[0,5,2]  R378      1.9963055849075317e-01
    z[0,5,2]  R379      5.5815988779067993e-01
    z[0,5,2]  R380      2.2595489025115967e-01
    z[0,5,2]  R381      2.2538958489894867e-01
    z[0,5,2]  R382      1.6700945794582367e-01
    z[0,5,2]  R383      8.1221228837966919e-01
    z[0,5,2]  R384      4.5618122816085815e-01
    z[0,5,2]  R385      1.2502519786357880e-01
    z[0,5,2]  R386      4.0478205680847168e-01
    z[0,5,2]  R387      5.3620833158493042e-01
    z[0,5,2]  R388      3.9113810658454895e-01
    z[0,5,2]  R389      4.7829464077949524e-01
    z[0,5,2]  R390      4.1106197237968445e-01
    z[0,5,2]  R391      -4.9869006872177124e-01
    z[0,5,2]  R392      -7.2007972002029419e-01
    z[0,5,2]  R393      -1.7156164348125458e-01
    z[0,5,2]  R394      -4.4149711728096008e-01
    z[0,5,2]  R395      2.8669720888137817e-01
    z[0,5,2]  R396      -2.1144950389862061e-01
    z[0,5,2]  R397      4.6509110927581787e-01
    z[0,5,2]  R398      1.4532390236854553e-01
    z[0,5,2]  R399      -2.3328140377998352e-01
    z[0,5,2]  R400      -1.0717423260211945e-01
    z[0,5,2]  R401      1.3992665708065033e-01
    z[0,5,2]  R402      2.9441145062446594e-01
    z[0,5,2]  R403      -2.7040395140647888e-01
    z[0,5,2]  R404      1.5309794247150421e-01
    z[0,5,2]  R405      7.6245918869972229e-02
    z[0,5,2]  R406      -4.4432663917541504e-01
    z[0,5,2]  R407      1.7600879073143005e-01
    z[0,5,2]  R408      -2.4465925991535187e-01
    z[0,5,2]  R409      -2.3060524463653564e-01
    z[0,5,2]  R410      -1.9868843257427216e-01
    z[0,5,2]  R411      5.8883899450302124e-01
    z[0,5,2]  R412      -2.7977502346038818e-01
    z[0,5,2]  R413      6.0295041650533676e-02
    z[0,5,2]  R414      -5.6695544719696045e-01
    z[0,5,2]  R415      -3.8297054171562195e-01
    z[0,5,2]  R416      3.1879439949989319e-01
    z[0,5,2]  R417      1.5251060947775841e-02
    z[0,5,2]  R418      -7.6868377625942230e-02
    z[0,5,2]  R419      4.2163223028182983e-01
    z[0,5,2]  R420      -5.6556697934865952e-02
    z[0,5,2]  R421      -2.1222374925855547e-04
    z[0,5,2]  R422      -3.3787724375724792e-01
    z[0,5,2]  R423      6.0927208513021469e-02
    z[0,5,2]  R424      -9.9846169352531433e-02
    z[0,5,2]  R425      -1.7482639849185944e-01
    z[0,5,2]  R426      -3.3913305401802063e-01
    z[0,5,2]  R427      4.5557226985692978e-02
    z[0,5,2]  R428      4.0963280200958252e-01
    z[0,5,2]  R429      9.2758618295192719e-02
    z[0,5,2]  R430      1.0184465348720551e-01
    z[0,5,2]  R431      1.7514440417289734e-01
    z[0,5,2]  R432      2.0122143626213074e-01
    z[0,5,2]  R433      5.0607389211654663e-01
    z[0,5,2]  R434      -3.5405641794204712e-01
    z[0,5,2]  R435      2.0912717282772064e-01
    z[0,5,2]  R436      1.5767259895801544e-01
    z[0,5,2]  R437      8.4160633385181427e-02
    z[0,5,2]  R438      4.6334043145179749e-01
    z[0,5,2]  R439      2.3736357688903809e-01
    z[0,5,2]  R440      3.1158637255430222e-02
    z[0,5,2]  R441      6.0849428176879883e-01
    z[0,5,2]  R442      1.4234395325183868e-01
    z[0,5,2]  R443      4.0318641066551208e-01
    z[0,5,2]  R444      1.1819498240947723e-01
    z[0,5,2]  R445      2.4166959524154663e-01
    z[0,5,2]  R446      3.1032716855406761e-02
    z[0,5,2]  R447      2.0859509706497192e-01
    z[0,5,2]  R448      0.599233090877533
    z[0,5,2]  R449      -2.5074759125709534e-01
    z[0,5,2]  R450      -3.3579967916011810e-02
    z[0,5,2]  R451      6.2019848823547363e-01
    z[0,5,2]  R452      1.2159148603677750e-01
    z[0,5,2]  R453      -1.8446686863899231e-01
    z[0,5,2]  R454      3.5102772712707520e-01
    z[0,5,2]  R455      3.5609204322099686e-02
    z[0,5,2]  R456      5.5760347843170166e-01
    z[0,5,2]  R457      -6.0046225786209106e-01
    z[0,5,2]  R458      4.1237625479698181e-01
    z[0,5,3]  R5        -1
    z[0,5,3]  R50       1
    z[0,5,3]  R301      -1
    z[0,5,3]  R302      1
    z[0,5,3]  R309      -7.0720982551574707e-01
    z[0,5,3]  R310      -6.9758069515228271e-01
    z[0,5,3]  R311      -2.4126936495304108e-01
    z[0,5,3]  R312      -3.0696383118629456e-01
    z[0,5,3]  R313      -2.0187194645404816e-01
    z[0,5,3]  R314      -6.9268339872360229e-01
    z[0,5,3]  R315      -3.5274004936218262e-01
    z[0,5,3]  R316      3.8146394491195679e-01
    z[0,5,3]  R317      -4.5888921618461609e-01
    z[0,5,3]  R318      4.2126268148422241e-01
    z[0,5,3]  R319      6.2814855575561523e-01
    z[0,5,3]  R320      5.5779051780700684e-01
    z[0,5,3]  R321      5.6700974702835083e-01
    z[0,5,3]  R322      3.4470441937446594e-01
    z[0,5,3]  R323      4.9914455413818359e-01
    z[0,5,3]  R324      4.1553494334220886e-01
    z[0,5,3]  R325      3.6966013908386230e-01
    z[0,5,3]  R326      9.6126310527324677e-02
    z[0,5,3]  R327      5.7133400440216064e-01
    z[0,5,3]  R328      5.9475088119506836e-01
    z[0,5,3]  R329      -7.6354585587978363e-02
    z[0,5,3]  R330      1.8178611993789673e-01
    z[0,5,3]  R331      -4.2014512419700623e-01
    z[0,5,3]  R332      -4.1211771965026855e-01
    z[0,5,3]  R333      6.1982864141464233e-01
    z[0,5,3]  R334      1.6295839846134186e-01
    z[0,5,3]  R335      -1.9765029847621918e-01
    z[0,5,3]  R336      -5.0161361694335938e-01
    z[0,5,3]  R337      -2.3411202430725098e-01
    z[0,5,3]  R338      -6.1734235286712646e-01
    z[0,5,3]  R339      8.9579766988754272e-01
    z[0,5,3]  R340      -7.7933639287948608e-01
    z[0,5,3]  R341      -5.9990060329437256e-01
    z[0,5,3]  R342      8.5244961082935333e-02
    z[0,5,3]  R343      -3.2611685991287231e-01
    z[0,5,3]  R344      4.1469329595565796e-01
    z[0,5,3]  R345      1.8109214305877686e-01
    z[0,5,3]  R346      4.6539118885993958e-01
    z[0,5,3]  R347      1.2050674110651016e-01
    z[0,5,3]  R348      3.9610946178436279e-01
    z[0,5,3]  R349      -3.0852460861206055e-01
    z[0,5,3]  R350      3.4933799505233765e-01
    z[0,5,3]  R351      6.2043029069900513e-01
    z[0,5,3]  R352      7.1201616525650024e-01
    z[0,5,3]  R353      -3.2935658097267151e-01
    z[0,5,3]  R354      4.9749910831451416e-01
    z[0,5,3]  R355      -0.595457911491394
    z[0,5,3]  R356      4.0302717685699463e-01
    z[0,5,3]  R357      1.9613612443208694e-02
    z[0,5,3]  R358      2.4057655036449432e-01
    z[0,5,3]  R359      2.6396757364273071e-01
    z[0,5,3]  R360      -1.8983669579029083e-01
    z[0,5,3]  R361      -5.6722037494182587e-02
    z[0,5,3]  R362      6.0487186908721924e-01
    z[0,5,3]  R363      -1.7714852094650269e-01
    z[0,5,3]  R364      -5.5686396360397339e-01
    z[0,5,3]  R365      1.9345837831497192e-01
    z[0,5,3]  R366      -2.0902976393699646e-01
    z[0,5,3]  R367      4.4478651881217957e-01
    z[0,5,3]  R368      3.3601793646812439e-01
    z[0,5,3]  R369      0.655640721321106
    z[0,5,3]  R370      -2.3139376938343048e-01
    z[0,5,3]  R371      2.8733009099960327e-01
    z[0,5,3]  R372      -1.0046269744634628e-01
    z[0,5,3]  R373      -3.3963614702224731e-01
    z[0,5,3]  R374      6.7690014839172363e-01
    z[0,5,3]  R375      2.1949785947799683e-01
    z[0,5,3]  R376      4.9358087778091431e-01
    z[0,5,3]  R377      4.3031710386276245e-01
    z[0,5,3]  R378      7.8850097954273224e-02
    z[0,5,3]  R379      -6.5109741687774658e-01
    z[0,5,3]  R380      -6.2717002630233765e-01
    z[0,5,3]  R381      -7.7808088064193726e-01
    z[0,5,3]  R382      1.4964616298675537e-01
    z[0,5,3]  R383      -2.8170493245124817e-01
    z[0,5,3]  R384      -2.2198049724102020e-01
    z[0,5,3]  R385      8.4494002163410187e-02
    z[0,5,3]  R386      -1.6668562591075897e-01
    z[0,5,3]  R387      -4.2440012097358704e-02
    z[0,5,3]  R388      5.8643206954002380e-02
    z[0,5,3]  R389      2.6806342601776123e-01
    z[0,5,3]  R390      7.3074257373809814e-01
    z[0,5,3]  R391      4.5107737183570862e-01
    z[0,5,3]  R392      4.0506976842880249e-01
    z[0,5,3]  R393      3.5198843479156494e-01
    z[0,5,3]  R394      0.509611189365387
    z[0,5,3]  R395      4.0571564435958862e-01
    z[0,5,3]  R396      3.1033343076705933e-01
    z[0,5,3]  R397      2.2961201146245003e-02
    z[0,5,3]  R398      3.0198348686099052e-02
    z[0,5,3]  R399      4.6960216760635376e-01
    z[0,5,3]  R400      3.3206886053085327e-01
    z[0,5,3]  R401      1.2452097237110138e-01
    z[0,5,3]  R402      -3.0271539092063904e-01
    z[0,5,3]  R403      -6.3038282096385956e-02
    z[0,5,3]  R404      8.8862545788288116e-02
    z[0,5,3]  R405      1.9767074286937714e-01
    z[0,5,3]  R406      7.8074708580970764e-02
    z[0,5,3]  R407      -7.4829542636871338e-01
    z[0,5,3]  R408      2.4469788372516632e-01
    z[0,5,3]  R409      5.1538795232772827e-01
    z[0,5,3]  R410      1.0687772929668427e-01
    z[0,5,3]  R411      -4.7982245683670044e-02
    z[0,5,3]  R412      -3.9214301109313965e-01
    z[0,5,3]  R413      4.2069315910339355e-01
    z[0,5,3]  R414      5.0914257764816284e-01
    z[0,5,3]  R415      2.0109629631042480e-01
    z[0,5,3]  R416      2.7164161205291748e-01
    z[0,5,3]  R417      -0.347178190946579
    z[0,5,3]  R418      -4.3560093641281128e-01
    z[0,5,3]  R419      2.8857287764549255e-01
    z[0,5,3]  R420      1.5668129920959473e-01
    z[0,5,3]  R421      4.3472734093666077e-01
    z[0,5,3]  R422      -2.9675019904971123e-02
    z[0,5,3]  R423      2.3451203107833862e-01
    z[0,5,3]  R424      6.3514953851699829e-01
    z[0,5,3]  R425      1.2547163665294647e-01
    z[0,5,3]  R426      -1.6502922773361206e-01
    z[0,5,3]  R427      -2.4309846758842468e-01
    z[0,5,3]  R428      1.9159168004989624e-01
    z[0,5,3]  R429      -1.4149367809295654e-01
    z[0,5,3]  R430      5.6732130050659180e-01
    z[0,5,3]  R431      9.2289096117019653e-01
    z[0,5,3]  R432      9.2001551389694214e-01
    z[0,5,3]  R433      5.1745635271072388e-01
    z[0,5,3]  R434      -4.8330705612897873e-02
    z[0,5,3]  R435      3.7941941618919373e-01
    z[0,5,3]  R436      -0.863492488861084
    z[0,5,3]  R437      -5.3829592466354370e-01
    z[0,5,3]  R438      -6.1950671672821045e-01
    z[0,5,3]  R439      -7.3992156982421875e-01
    z[0,5,3]  R440      4.6827623248100281e-01
    z[0,5,3]  R441      -6.1597061157226562e-01
    z[0,5,3]  R442      -1.3543231785297394e-01
    z[0,5,3]  R443      2.1678598225116730e-01
    z[0,5,3]  R444      1.0164123773574829e-01
    z[0,5,3]  R445      -0.0944051444530487
    z[0,5,3]  R446      -3.6431051790714264e-02
    z[0,5,3]  R447      3.6285273730754852e-02
    z[0,5,3]  R448      4.0914192795753479e-01
    z[0,5,3]  R449      2.6608530431985855e-02
    z[0,5,3]  R450      2.8290608525276184e-01
    z[0,5,3]  R451      3.6883381009101868e-01
    z[0,5,3]  R452      6.7364257574081421e-01
    z[0,5,3]  R453      3.0480548739433289e-01
    z[0,5,3]  R454      1.1650307476520538e-01
    z[0,5,3]  R455      1.1999174207448959e-01
    z[0,5,3]  R456      -6.6445344686508179e-01
    z[0,5,3]  R457      1.1093888431787491e-02
    z[0,5,3]  R458      -6.6328942775726318e-01
    z[0,5,4]  R6        -1
    z[0,5,4]  R51       1
    z[0,5,4]  R303      -1
    z[0,5,4]  R304      1
    z[0,5,4]  R309      1.2259913235902786e-01
    z[0,5,4]  R310      2.6392656564712524e-01
    z[0,5,4]  R311      4.6463202685117722e-02
    z[0,5,4]  R312      -3.5254594683647156e-01
    z[0,5,4]  R313      -2.4449007213115692e-01
    z[0,5,4]  R314      2.8654780983924866e-01
    z[0,5,4]  R315      -5.7972751557826996e-02
    z[0,5,4]  R316      -4.0461938828229904e-02
    z[0,5,4]  R317      -2.2709010541439056e-01
    z[0,5,4]  R318      -0.331691712141037
    z[0,5,4]  R319      9.4646655023097992e-02
    z[0,5,4]  R320      -4.7965649515390396e-02
    z[0,5,4]  R321      5.3363703191280365e-02
    z[0,5,4]  R322      1.8360137939453125e-01
    z[0,5,4]  R323      -1.9633080065250397e-01
    z[0,5,4]  R324      -1.4350116252899170e-01
    z[0,5,4]  R325      5.9857752174139023e-02
    z[0,5,4]  R326      1.1935921013355255e-01
    z[0,5,4]  R327      7.4213206768035889e-02
    z[0,5,4]  R328      6.1546668410301208e-02
    z[0,5,4]  R329      -6.4590275287628174e-02
    z[0,5,4]  R330      -3.2296633720397949e-01
    z[0,5,4]  R331      -1.5243685804307461e-02
    z[0,5,4]  R332      3.8030825555324554e-02
    z[0,5,4]  R333      3.1678044795989990e-01
    z[0,5,4]  R334      -7.3413648642599583e-03
    z[0,5,4]  R335      -2.7928823605179787e-02
    z[0,5,4]  R336      -2.2214733064174652e-01
    z[0,5,4]  R337      2.4055325984954834e-01
    z[0,5,4]  R338      7.1519844233989716e-02
    z[0,5,4]  R339      1.5579383075237274e-01
    z[0,5,4]  R340      1.6558946669101715e-01
    z[0,5,4]  R341      -3.2959397882223129e-02
    z[0,5,4]  R342      1.9690386950969696e-01
    z[0,5,4]  R343      6.4184583723545074e-02
    z[0,5,4]  R344      2.3151208460330963e-01
    z[0,5,4]  R345      -1.0148895531892776e-01
    z[0,5,4]  R346      2.3119370639324188e-01
    z[0,5,4]  R347      3.2638299465179443e-01
    z[0,5,4]  R348      1.8954484164714813e-01
    z[0,5,4]  R349      -2.1056285500526428e-01
    z[0,5,4]  R350      2.6625737547874451e-01
    z[0,5,4]  R351      -2.0119942724704742e-01
    z[0,5,4]  R352      -3.2164674997329712e-01
    z[0,5,4]  R353      4.9756950139999390e-01
    z[0,5,4]  R354      -4.0620166063308716e-01
    z[0,5,4]  R355      -0.129534512758255
    z[0,5,4]  R356      2.8277760744094849e-01
    z[0,5,4]  R357      1.3353681564331055e-01
    z[0,5,4]  R358      -4.8810219764709473e-01
    z[0,5,4]  R359      2.2378638386726379e-01
    z[0,5,4]  R360      -7.5205512344837189e-02
    z[0,5,4]  R361      8.6364768445491791e-02
    z[0,5,4]  R362      1.6309115290641785e-01
    z[0,5,4]  R363      -2.0140078663825989e-01
    z[0,5,4]  R364      1.1269237147644162e-03
    z[0,5,4]  R365      -5.0101685523986816e-01
    z[0,5,4]  R366      -2.0102441310882568e-01
    z[0,5,4]  R367      2.6743793487548828e-01
    z[0,5,4]  R368      3.7970918416976929e-01
    z[0,5,4]  R369      4.4239366054534912e-01
    z[0,5,4]  R370      2.2575096786022186e-01
    z[0,5,4]  R371      9.5553815364837646e-02
    z[0,5,4]  R372      -5.1294457912445068e-01
    z[0,5,4]  R373      -4.4900581240653992e-01
    z[0,5,4]  R374      7.5459964573383331e-02
    z[0,5,4]  R375      4.7838100790977478e-01
    z[0,5,4]  R376      2.4804225564002991e-01
    z[0,5,4]  R377      -2.0714102685451508e-01
    z[0,5,4]  R378      -0.0595281757414341
    z[0,5,4]  R379      3.5494975745677948e-02
    z[0,5,4]  R380      3.9642862975597382e-03
    z[0,5,4]  R381      -0.091993547976017
    z[0,5,4]  R382      -9.1157844290137291e-03
    z[0,5,4]  R383      -3.5667590796947479e-02
    z[0,5,4]  R384      2.1434406936168671e-01
    z[0,5,4]  R385      0.334311306476593
    z[0,5,4]  R386      2.6511928439140320e-01
    z[0,5,4]  R387      -2.0978540182113647e-01
    z[0,5,4]  R388      -1.8253475427627563e-01
    z[0,5,4]  R389      7.7206425368785858e-02
    z[0,5,4]  R390      5.9892702847719193e-02
    z[0,5,4]  R391      -1.0336165875196457e-01
    z[0,5,4]  R392      8.4578081965446472e-02
    z[0,5,4]  R393      9.1192595660686493e-02
    z[0,5,4]  R394      1.7118583619594574e-01
    z[0,5,4]  R395      -1.6608101129531860e-01
    z[0,5,4]  R396      -2.7674525976181030e-01
    z[0,5,4]  R397      -1.9405819475650787e-01
    z[0,5,4]  R398      7.9633817076683044e-02
    z[0,5,4]  R399      0.0679209977388382
    z[0,5,4]  R400      1.0429047048091888e-01
    z[0,5,4]  R401      -2.2596006095409393e-01
    z[0,5,4]  R402      1.8353813886642456e-01
    z[0,5,4]  R403      -4.0670579671859741e-01
    z[0,5,4]  R404      -2.8136115521192551e-02
    z[0,5,4]  R405      2.4890285730361938e-01
    z[0,5,4]  R406      -1.1637928336858749e-01
    z[0,5,4]  R407      1.4769001305103302e-01
    z[0,5,4]  R408      8.6736559867858887e-02
    z[0,5,4]  R409      5.2736252546310425e-01
    z[0,5,4]  R410      3.4467944502830505e-01
    z[0,5,4]  R411      -9.3032978475093842e-02
    z[0,5,4]  R412      -1.4599943161010742e-01
    z[0,5,4]  R413      2.4246694147586823e-01
    z[0,5,4]  R414      -5.3987614810466766e-02
    z[0,5,4]  R415      -4.0561595559120178e-01
    z[0,5,4]  R416      4.7643250226974487e-01
    z[0,5,4]  R417      1.1399107426404953e-01
    z[0,5,4]  R418      -3.6978834867477417e-01
    z[0,5,4]  R419      7.7476361766457558e-03
    z[0,5,4]  R420      -1.7588908970355988e-01
    z[0,5,4]  R421      1.7745584249496460e-01
    z[0,5,4]  R422      2.0051756501197815e-01
    z[0,5,4]  R423      -1.5259747393429279e-02
    z[0,5,4]  R424      3.9132067561149597e-01
    z[0,5,4]  R425      -3.0765104293823242e-01
    z[0,5,4]  R426      -3.7825030088424683e-01
    z[0,5,4]  R427      4.5621815323829651e-01
    z[0,5,4]  R428      -3.1934878230094910e-01
    z[0,5,4]  R429      3.3947516232728958e-02
    z[0,5,4]  R430      1.4159974455833435e-01
    z[0,5,4]  R431      -1.8256385624408722e-01
    z[0,5,4]  R432      8.2530558109283447e-02
    z[0,5,4]  R433      2.2407043725252151e-02
    z[0,5,4]  R434      -1.9012410938739777e-01
    z[0,5,4]  R435      5.4631102085113525e-01
    z[0,5,4]  R436      5.9076272882521152e-03
    z[0,5,4]  R437      2.1291528642177582e-01
    z[0,5,4]  R438      -1.3926008343696594e-01
    z[0,5,4]  R439      -0.0978035256266594
    z[0,5,4]  R440      -3.0345961451530457e-01
    z[0,5,4]  R441      -0.0781460627913475
    z[0,5,4]  R442      4.1999399662017822e-01
    z[0,5,4]  R443      -5.8338645845651627e-02
    z[0,5,4]  R444      1.0958840698003769e-01
    z[0,5,4]  R445      4.8430660367012024e-01
    z[0,5,4]  R446      0.261323481798172
    z[0,5,4]  R447      2.9446640610694885e-01
    z[0,5,4]  R448      1.5138788521289825e-01
    z[0,5,4]  R449      -4.8259207606315613e-01
    z[0,5,4]  R450      2.0322456955909729e-01
    z[0,5,4]  R451      -2.0986037328839302e-02
    z[0,5,4]  R452      2.3399895429611206e-01
    z[0,5,4]  R453      -2.8322216868400574e-01
    z[0,5,4]  R454      1.1421643942594528e-01
    z[0,5,4]  R455      -1.4713747799396515e-01
    z[0,5,4]  R456      1.1014923220500350e-03
    z[0,5,4]  R457      1.5322542190551758e-01
    z[0,5,4]  R458      -1.8408633768558502e-01
    z[0,5,5]  R7        -1
    z[0,5,5]  R52       1
    z[0,5,5]  R305      -1
    z[0,5,5]  R306      1
    z[0,5,5]  R309      -1.9956852495670319e-01
    z[0,5,5]  R310      2.0951206982135773e-01
    z[0,5,5]  R311      -1.6466975212097168e-01
    z[0,5,5]  R312      -4.5666342973709106e-01
    z[0,5,5]  R313      -2.9176460579037666e-02
    z[0,5,5]  R314      1.9770933687686920e-01
    z[0,5,5]  R315      5.5945134162902832e-01
    z[0,5,5]  R316      -1.6124244034290314e-01
    z[0,5,5]  R317      1.6466896235942841e-01
    z[0,5,5]  R318      -1.2085715681314468e-01
    z[0,5,5]  R319      -4.3522989749908447e-01
    z[0,5,5]  R320      -4.2333969473838806e-01
    z[0,5,5]  R321      -2.8290903568267822e-01
    z[0,5,5]  R322      -5.5686312913894653e-01
    z[0,5,5]  R323      -4.0836516022682190e-01
    z[0,5,5]  R324      -3.2412597537040710e-01
    z[0,5,5]  R325      -3.8572993874549866e-01
    z[0,5,5]  R326      -7.1814113855361938e-01
    z[0,5,5]  R327      -2.9740974307060242e-01
    z[0,5,5]  R328      5.8317895978689194e-02
    z[0,5,5]  R329      -4.8274996876716614e-01
    z[0,5,5]  R330      5.1724809408187866e-01
    z[0,5,5]  R331      -4.6995180845260620e-01
    z[0,5,5]  R332      3.5755565762519836e-01
    z[0,5,5]  R333      -3.3992937207221985e-01
    z[0,5,5]  R334      -9.5896673202514648e-01
    z[0,5,5]  R335      0.281389981508255
    z[0,5,5]  R336      -1.3235056400299072e-01
    z[0,5,5]  R337      -5.0508117675781250e-01
    z[0,5,5]  R338      -4.1683351993560791e-01
    z[0,5,5]  R339      -1.5273775160312653e-01
    z[0,5,5]  R340      1.3021574914455414e-01
    z[0,5,5]  R341      4.3204712867736816e-01
    z[0,5,5]  R342      -1.8467260897159576e-01
    z[0,5,5]  R343      1.7204004526138306e-01
    z[0,5,5]  R344      -3.0417588353157043e-01
    z[0,5,5]  R345      3.4708064794540405e-01
    z[0,5,5]  R346      3.9442703127861023e-01
    z[0,5,5]  R347      2.9866768047213554e-02
    z[0,5,5]  R348      -2.0194509997963905e-02
    z[0,5,5]  R349      -2.4880267679691315e-01
    z[0,5,5]  R350      -6.2224805355072021e-01
    z[0,5,5]  R351      -4.2498525977134705e-01
    z[0,5,5]  R352      -2.0908093452453613e-01
    z[0,5,5]  R353      -5.1655232906341553e-02
    z[0,5,5]  R354      -2.6204457506537437e-02
    z[0,5,5]  R355      -2.5494593381881714e-01
    z[0,5,5]  R356      -3.1170985102653503e-01
    z[0,5,5]  R357      -2.5660762190818787e-01
    z[0,5,5]  R358      -4.5631803572177887e-02
    z[0,5,5]  R359      -6.5560504794120789e-02
    z[0,5,5]  R360      4.0770357847213745e-01
    z[0,5,5]  R361      -0.0376245491206646
    z[0,5,5]  R362      -2.2379907965660095e-01
    z[0,5,5]  R363      1.3422715663909912e-01
    z[0,5,5]  R364      2.3163928091526031e-01
    z[0,5,5]  R365      7.7741943299770355e-02
    z[0,5,5]  R366      3.0385997891426086e-01
    z[0,5,5]  R367      1.6005125641822815e-01
    z[0,5,5]  R368      5.8769159018993378e-02
    z[0,5,5]  R369      -3.8271471858024597e-01
    z[0,5,5]  R370      -5.6668068282306194e-03
    z[0,5,5]  R371      -2.1352672576904297e-01
    z[0,5,5]  R372      -1.6919773817062378e-01
    z[0,5,5]  R373      -4.8728186637163162e-02
    z[0,5,5]  R374      0.297302782535553
    z[0,5,5]  R375      8.2587942481040955e-02
    z[0,5,5]  R376      6.0453391075134277e-01
    z[0,5,5]  R377      3.1147131323814392e-01
    z[0,5,5]  R378      5.0482434034347534e-01
    z[0,5,5]  R379      2.1825125813484192e-01
    z[0,5,5]  R380      -1.6139014065265656e-01
    z[0,5,5]  R381      -1.1417536437511444e-01
    z[0,5,5]  R382      5.5422621965408325e-01
    z[0,5,5]  R383      -1.3392789661884308e-01
    z[0,5,5]  R384      -7.7547687105834484e-03
    z[0,5,5]  R385      2.3872756958007812e-01
    z[0,5,5]  R386      -1.4714235067367554e-01
    z[0,5,5]  R387      3.2425004243850708e-01
    z[0,5,5]  R388      0.00981933530420065
    z[0,5,5]  R389      -7.5578755140304565e-01
    z[0,5,5]  R390      -3.6837142705917358e-01
    z[0,5,5]  R391      -3.8060164451599121e-01
    z[0,5,5]  R392      -4.7244527935981750e-01
    z[0,5,5]  R393      -4.5457679033279419e-01
    z[0,5,5]  R394      -2.8590077161788940e-01
    z[0,5,5]  R395      -5.7144075632095337e-01
    z[0,5,5]  R396      -3.1042066216468811e-01
    z[0,5,5]  R397      3.2131791114807129e-01
    z[0,5,5]  R398      -1.9068498909473419e-01
    z[0,5,5]  R399      -7.7682763338088989e-01
    z[0,5,5]  R400      -6.6140621900558472e-01
    z[0,5,5]  R401      1.5085159242153168e-01
    z[0,5,5]  R402      -2.7786001563072205e-01
    z[0,5,5]  R403      4.7036954760551453e-01
    z[0,5,5]  R404      2.8375312685966492e-01
    z[0,5,5]  R405      -5.8317315578460693e-01
    z[0,5,5]  R406      -6.2162160873413086e-02
    z[0,5,5]  R407      -1.9050613045692444e-01
    z[0,5,5]  R408      -5.0837069749832153e-01
    z[0,5,5]  R409      -4.6687945723533630e-01
    z[0,5,5]  R410      2.4668979644775391e-01
    z[0,5,5]  R411      3.4272089600563049e-01
    z[0,5,5]  R412      1.4843259751796722e-01
    z[0,5,5]  R413      -4.1661235690116882e-01
    z[0,5,5]  R414      -3.3581340312957764e-01
    z[0,5,5]  R415      -4.1864910599542782e-05
    z[0,5,5]  R416      -5.6735342741012573e-01
    z[0,5,5]  R417      -2.8519338369369507e-01
    z[0,5,5]  R418      -3.2680696249008179e-01
    z[0,5,5]  R419      -3.1746879220008850e-01
    z[0,5,5]  R420      2.8315432369709015e-02
    z[0,5,5]  R421      -5.2213990688323975e-01
    z[0,5,5]  R422      -4.6418279409408569e-01
    z[0,5,5]  R423      -5.5919522047042847e-01
    z[0,5,5]  R424      -8.5035160183906555e-02
    z[0,5,5]  R425      -5.5289936065673828e-01
    z[0,5,5]  R426      -8.4765315055847168e-02
    z[0,5,5]  R427      7.0585653185844421e-02
    z[0,5,5]  R428      -3.6760583519935608e-01
    z[0,5,5]  R429      5.3840130567550659e-02
    z[0,5,5]  R430      -5.3950971364974976e-01
    z[0,5,5]  R431      -1.6871818900108337e-01
    z[0,5,5]  R432      8.8136322796344757e-02
    z[0,5,5]  R433      -0.560045599937439
    z[0,5,5]  R434      -2.2227661311626434e-01
    z[0,5,5]  R435      -4.8511779308319092e-01
    z[0,5,5]  R436      0.0947168618440628
    z[0,5,5]  R437      4.3137103319168091e-01
    z[0,5,5]  R438      -0.514052152633667
    z[0,5,5]  R439      -1.3797669112682343e-01
    z[0,5,5]  R440      -3.2306542992591858e-01
    z[0,5,5]  R441      -2.9790589213371277e-01
    z[0,5,5]  R442      5.7864511013031006e-01
    z[0,5,5]  R443      -5.6701570749282837e-02
    z[0,5,5]  R444      2.1980141103267670e-01
    z[0,5,5]  R445      3.4816437959671021e-01
    z[0,5,5]  R446      -1.7437775433063507e-01
    z[0,5,5]  R447      6.0073465108871460e-01
    z[0,5,5]  R448      5.6616044044494629e-01
    z[0,5,5]  R449      4.0612876415252686e-02
    z[0,5,5]  R450      -8.2353627681732178e-01
    z[0,5,5]  R451      3.7596080452203751e-02
    z[0,5,5]  R452      -8.9968152344226837e-02
    z[0,5,5]  R453      -7.2813975811004639e-01
    z[0,5,5]  R454      4.2458567023277283e-01
    z[0,5,5]  R455      0.352770060300827
    z[0,5,5]  R456      -4.4315110892057419e-02
    z[0,5,5]  R457      3.7983334064483643e-01
    z[0,5,5]  R458      -4.0564981102943420e-01
    z[0,5,6]  R8        -1
    z[0,5,6]  R53       1
    z[0,5,6]  R307      -1
    z[0,5,6]  R308      1
    z[0,5,6]  R309      -4.3116754293441772e-01
    z[0,5,6]  R310      3.9251565933227539e-01
    z[0,5,6]  R311      1.1157218366861343e-01
    z[0,5,6]  R312      4.0498995780944824e-01
    z[0,5,6]  R313      -3.6586725711822510e-01
    z[0,5,6]  R314      -2.3382523655891418e-01
    z[0,5,6]  R315      -6.5789207816123962e-02
    z[0,5,6]  R316      -1.5175785124301910e-01
    z[0,5,6]  R317      0.268466979265213
    z[0,5,6]  R318      3.9267953485250473e-02
    z[0,5,6]  R319      4.5309510827064514e-01
    z[0,5,6]  R320      -3.9014050364494324e-01
    z[0,5,6]  R321      -6.7857891321182251e-01
    z[0,5,6]  R322      -5.5796837806701660e-01
    z[0,5,6]  R323      -2.0839789882302284e-02
    z[0,5,6]  R324      -0.642281711101532
    z[0,5,6]  R325      -3.5570108890533447e-01
    z[0,5,6]  R326      -3.3160585165023804e-01
    z[0,5,6]  R327      -1.7723254859447479e-01
    z[0,5,6]  R328      1.1587673425674438e-01
    z[0,5,6]  R329      -3.5515061020851135e-01
    z[0,5,6]  R330      -1.6898328065872192e-01
    z[0,5,6]  R331      2.1050535142421722e-01
    z[0,5,6]  R332      -5.1412478089332581e-02
    z[0,5,6]  R333      3.0915224552154541e-01
    z[0,5,6]  R334      -7.8972905874252319e-02
    z[0,5,6]  R335      3.3543251920491457e-03
    z[0,5,6]  R336      3.7385997176170349e-01
    z[0,5,6]  R337      3.1316413078457117e-03
    z[0,5,6]  R338      3.4802260994911194e-01
    z[0,5,6]  R339      -2.8481009602546692e-01
    z[0,5,6]  R340      -9.0197168290615082e-02
    z[0,5,6]  R341      1.4108563959598541e-01
    z[0,5,6]  R342      2.5622019171714783e-01
    z[0,5,6]  R343      -4.7528293728828430e-01
    z[0,5,6]  R344      -7.7281542122364044e-02
    z[0,5,6]  R345      4.0720129013061523e-01
    z[0,5,6]  R346      -1.1024359613656998e-01
    z[0,5,6]  R347      2.0571835339069366e-02
    z[0,5,6]  R348      5.8386242389678955e-01
    z[0,5,6]  R349      3.2262188196182251e-01
    z[0,5,6]  R350      -0.536336362361908
    z[0,5,6]  R351      7.7055029571056366e-02
    z[0,5,6]  R352      -3.2069790363311768e-01
    z[0,5,6]  R353      3.3036038279533386e-01
    z[0,5,6]  R354      2.7265515923500061e-01
    z[0,5,6]  R355      -1.6381666064262390e-01
    z[0,5,6]  R356      -5.6212997436523438e-01
    z[0,5,6]  R357      6.5752077102661133e-01
    z[0,5,6]  R358      5.4147444665431976e-02
    z[0,5,6]  R359      -6.9317850284278393e-03
    z[0,5,6]  R360      1.5720768272876740e-01
    z[0,5,6]  R361      -4.1065523028373718e-01
    z[0,5,6]  R362      2.3426532745361328e-01
    z[0,5,6]  R363      -2.1056310832500458e-01
    z[0,5,6]  R364      -5.1340326666831970e-02
    z[0,5,6]  R365      2.3974737524986267e-01
    z[0,5,6]  R366      -3.5421723127365112e-01
    z[0,5,6]  R367      -1.3048692047595978e-01
    z[0,5,6]  R368      1.4695557951927185e-01
    z[0,5,6]  R369      -9.6959307789802551e-02
    z[0,5,6]  R370      -1.6584932804107666e-01
    z[0,5,6]  R371      3.2100099325180054e-01
    z[0,5,6]  R372      3.5137336701154709e-02
    z[0,5,6]  R373      -5.9348177909851074e-01
    z[0,5,6]  R374      -1.4876598119735718e-01
    z[0,5,6]  R375      9.9936850368976593e-02
    z[0,5,6]  R376      2.5252452492713928e-01
    z[0,5,6]  R377      3.1249606609344482e-01
    z[0,5,6]  R378      5.6591600179672241e-01
    z[0,5,6]  R379      -1.9783705472946167e-01
    z[0,5,6]  R380      -1.4131994545459747e-01
    z[0,5,6]  R381      -3.5487228631973267e-01
    z[0,5,6]  R382      1.1082220077514648e-01
    z[0,5,6]  R383      1.3181723654270172e-01
    z[0,5,6]  R384      2.8088742494583130e-01
    z[0,5,6]  R385      4.8448985815048218e-01
    z[0,5,6]  R386      -2.1266406774520874e-01
    z[0,5,6]  R387      -2.9523962736129761e-01
    z[0,5,6]  R388      -2.5167265534400940e-01
    z[0,5,6]  R389      -1.7507728934288025e-01
    z[0,5,6]  R390      3.7377485632896423e-01
    z[0,5,6]  R391      -3.6467275023460388e-01
    z[0,5,6]  R392      1.3599184155464172e-01
    z[0,5,6]  R393      -0.0767880454659462
    z[0,5,6]  R394      -1.5330973267555237e-01
    z[0,5,6]  R395      -3.6703673005104065e-01
    z[0,5,6]  R396      -8.1977176666259766e-01
    z[0,5,6]  R397      3.1422293186187744e-01
    z[0,5,6]  R398      3.0217525362968445e-01
    z[0,5,6]  R399      2.6269397139549255e-01
    z[0,5,6]  R400      -3.7492290139198303e-01
    z[0,5,6]  R401      -6.2892287969589233e-01
    z[0,5,6]  R402      0.547385036945343
    z[0,5,6]  R403      -0.338960736989975
    z[0,5,6]  R404      4.3945336341857910e-01
    z[0,5,6]  R405      -7.2387516498565674e-01
    z[0,5,6]  R406      6.9454722106456757e-02
    z[0,5,6]  R407      -2.5666895508766174e-01
    z[0,5,6]  R408      -6.3011479377746582e-01
    z[0,5,6]  R409      -2.5507858395576477e-01
    z[0,5,6]  R410      0.0635906234383583
    z[0,5,6]  R411      2.6841476559638977e-01
    z[0,5,6]  R412      3.9312040805816650e-01
    z[0,5,6]  R413      -6.1730813980102539e-01
    z[0,5,6]  R414      -2.7263706922531128e-01
    z[0,5,6]  R415      8.3916023373603821e-02
    z[0,5,6]  R416      -1.2349230051040649e-01
    z[0,5,6]  R417      -4.1247045993804932e-01
    z[0,5,6]  R418      1.4649763703346252e-01
    z[0,5,6]  R419      3.0656388401985168e-01
    z[0,5,6]  R420      5.0899362564086914e-01
    z[0,5,6]  R421      -3.1880617141723633e-01
    z[0,5,6]  R422      -0.0982373058795929
    z[0,5,6]  R423      -3.0485075712203979e-01
    z[0,5,6]  R424      -3.6884722113609314e-01
    z[0,5,6]  R425      2.6567247509956360e-01
    z[0,5,6]  R426      -1.5768018364906311e-01
    z[0,5,6]  R427      4.6476048231124878e-01
    z[0,5,6]  R428      -2.0062988623976707e-02
    z[0,5,6]  R429      -0.0706803947687149
    z[0,5,6]  R430      -5.4278868436813354e-01
    z[0,5,6]  R431      -2.1640880405902863e-01
    z[0,5,6]  R432      -1.1714392900466919e-01
    z[0,5,6]  R433      -1.2410532683134079e-01
    z[0,5,6]  R434      3.1036806106567383e-01
    z[0,5,6]  R435      1.1200872063636780e-01
    z[0,5,6]  R436      -1.4323492534458637e-02
    z[0,5,6]  R437      -2.8648027777671814e-01
    z[0,5,6]  R438      -6.5235637128353119e-02
    z[0,5,6]  R439      1.5903894603252411e-01
    z[0,5,6]  R440      1.3085895776748657e-01
    z[0,5,6]  R441      -3.6762490868568420e-02
    z[0,5,6]  R442      1.0050827264785767e-01
    z[0,5,6]  R443      2.0909073948860168e-01
    z[0,5,6]  R444      -1.5240733325481415e-01
    z[0,5,6]  R445      6.3973955810070038e-02
    z[0,5,6]  R446      2.5381425023078918e-01
    z[0,5,6]  R447      -2.3153199255466461e-01
    z[0,5,6]  R448      2.1080653369426727e-01
    z[0,5,6]  R449      -2.9442432522773743e-01
    z[0,5,6]  R450      2.2117432951927185e-01
    z[0,5,6]  R451      -3.0406171083450317e-01
    z[0,5,6]  R452      -2.4027535319328308e-01
    z[0,5,6]  R453      -3.4742251038551331e-01
    z[0,5,6]  R454      -0.263701468706131
    z[0,5,6]  R455      -3.1423202157020569e-01
    z[0,5,6]  R456      2.0526324212551117e-01
    z[0,5,6]  R457      -2.7229386568069458e-01
    z[0,5,6]  R458      -6.8887092173099518e-02
    z[5,0,0]  R2        1
    z[5,0,0]  R47       -1
    z[5,0,0]  R459      -1
    z[5,0,0]  R460      1
    z[5,0,0]  R473      -4.1581445932388306e-01
    z[5,0,0]  R474      -7.1382147073745728e-01
    z[5,0,0]  R475      -4.4117593765258789e-01
    z[5,0,0]  R476      3.0876708030700684e-01
    z[5,0,0]  R477      -0.468372106552124
    z[5,0,0]  R478      3.7482929229736328e-01
    z[5,0,0]  R479      3.0678293108940125e-01
    z[5,0,0]  R480      2.1084308624267578e-01
    z[5,0,0]  R481      -1.6066245734691620e-01
    z[5,0,0]  R482      -1.2283680588006973e-01
    z[5,0,0]  R483      1.3883158564567566e-01
    z[5,0,0]  R484      2.9173580929636955e-02
    z[5,0,0]  R485      4.5376399159431458e-01
    z[5,0,0]  R486      2.4065634608268738e-01
    z[5,0,0]  R487      7.0959097146987915e-01
    z[5,0,0]  R488      -6.0118097066879272e-01
    z[5,0,0]  R489      -4.8264107108116150e-01
    z[5,0,0]  R490      0.0402534045279026
    z[5,0,0]  R491      6.0055327415466309e-01
    z[5,0,0]  R492      -8.7000322341918945e-01
    z[5,0,0]  R493      -1.6710819303989410e-01
    z[5,0,0]  R494      5.1962143182754517e-01
    z[5,0,0]  R495      2.4668073654174805e-01
    z[5,0,0]  R496      2.4670842289924622e-01
    z[5,0,0]  R497      1.4420443773269653e-01
    z[5,0,0]  R498      -5.6685519218444824e-01
    z[5,0,0]  R499      -1.6137033700942993e-01
    z[5,0,0]  R500      -6.2655562162399292e-01
    z[5,0,0]  R501      2.0319147035479546e-02
    z[5,0,0]  R502      -4.3238359689712524e-01
    z[5,0,0]  R503      1.7326253652572632e-01
    z[5,0,0]  R504      0.472392737865448
    z[5,0,0]  R505      2.1025046706199646e-01
    z[5,0,0]  R506      -1.4568910002708435e-01
    z[5,0,0]  R507      -2.6236453652381897e-01
    z[5,0,0]  R508      -2.3091338574886322e-01
    z[5,0,0]  R509      2.8852918744087219e-01
    z[5,0,0]  R510      -5.0840634107589722e-01
    z[5,0,0]  R511      5.3634464740753174e-01
    z[5,0,0]  R512      -1.7589415609836578e-01
    z[5,0,0]  R513      2.1643792092800140e-01
    z[5,0,0]  R514      3.8719531893730164e-01
    z[5,0,0]  R515      -3.2949864864349365e-01
    z[5,0,0]  R516      3.3848136663436890e-01
    z[5,0,0]  R517      -3.5411331057548523e-01
    z[5,0,0]  R518      -0.465248167514801
    z[5,0,0]  R519      2.3825326561927795e-01
    z[5,0,0]  R520      5.5241864919662476e-01
    z[5,0,0]  R521      -0.437234103679657
    z[5,0,0]  R522      -5.3801500797271729e-01
    z[5,0,0]  R523      3.4132543206214905e-01
    z[5,0,0]  R524      -2.3048569262027740e-01
    z[5,0,0]  R525      0.0930616706609726
    z[5,0,0]  R526      2.5502392649650574e-01
    z[5,0,0]  R527      -1.9639667868614197e-01
    z[5,0,0]  R528      -3.8214358687400818e-01
    z[5,0,0]  R529      -5.0560951232910156e-01
    z[5,0,0]  R530      -3.2939481735229492e-01
    z[5,0,0]  R531      -3.9098620414733887e-01
    z[5,0,0]  R532      -3.3695119619369507e-01
    z[5,0,0]  R533      -3.5032325983047485e-01
    z[5,0,0]  R534      -4.1307485103607178e-01
    z[5,0,0]  R535      -3.8969355821609497e-01
    z[5,0,0]  R536      3.5542088747024536e-01
    z[5,0,0]  R537      5.8741962909698486e-01
    z[5,0,0]  R538      -9.3581545352935791e-01
    z[5,0,0]  R539      2.1107417345046997e-01
    z[5,0,0]  R540      -9.1353046894073486e-01
    z[5,0,0]  R541      1.0356234014034271e-01
    z[5,0,0]  R542      2.6287612318992615e-01
    z[5,0,0]  R543      -3.2082059979438782e-01
    z[5,0,0]  R544      3.8107904791831970e-01
    z[5,0,0]  R545      -1.7919836938381195e-01
    z[5,0,0]  R546      1.4544046483933926e-02
    z[5,0,0]  R547      3.7239700555801392e-01
    z[5,0,0]  R548      -5.5211794376373291e-01
    z[5,0,0]  R549      -6.5027683973312378e-01
    z[5,0,0]  R550      -4.2978027462959290e-01
    z[5,0,0]  R551      -2.2500525414943695e-01
    z[5,0,0]  R552      -4.1538852453231812e-01
    z[5,0,0]  R553      -3.6848965287208557e-01
    z[5,0,0]  R554      7.4506118893623352e-02
    z[5,0,0]  R555      -4.3569985032081604e-01
    z[5,0,0]  R556      5.7732496410608292e-02
    z[5,0,0]  R557      -1.1502807587385178e-01
    z[5,0,0]  R558      -2.4476386606693268e-01
    z[5,0,0]  R559      2.2146110236644745e-01
    z[5,0,0]  R560      6.8804420530796051e-02
    z[5,0,0]  R561      -5.7788819074630737e-02
    z[5,0,0]  R562      1.6723388433456421e-01
    z[5,0,0]  R563      -2.5952938199043274e-01
    z[5,0,0]  R564      -4.5666435360908508e-01
    z[5,0,0]  R565      -2.4800752103328705e-01
    z[5,0,0]  R566      3.2661882042884827e-01
    z[5,0,0]  R567      -3.2229042053222656e-01
    z[5,0,0]  R568      4.2880225181579590e-01
    z[5,0,0]  R569      0.649897575378418
    z[5,0,0]  R570      4.7318503260612488e-01
    z[5,0,0]  R571      -9.9350020289421082e-02
    z[5,0,0]  R572      6.8418934941291809e-02
    z[5,0,0]  R573      -1.8654868006706238e-01
    z[5,0,0]  R574      8.1839069724082947e-02
    z[5,0,0]  R575      -1.3905237615108490e-01
    z[5,0,0]  R576      -3.1382462382316589e-01
    z[5,0,0]  R577      2.4938400089740753e-01
    z[5,0,0]  R578      3.9992492645978928e-02
    z[5,0,0]  R579      -6.3366031646728516e-01
    z[5,0,0]  R580      -1.3271619379520416e-01
    z[5,0,0]  R581      2.2186957299709320e-01
    z[5,0,0]  R582      -3.6631923913955688e-01
    z[5,0,0]  R583      -3.2499887049198151e-02
    z[5,0,0]  R584      -3.2112231850624084e-01
    z[5,0,0]  R585      -1.4242365024983883e-02
    z[5,0,0]  R586      -6.5282315015792847e-01
    z[5,0,0]  R587      -6.7952924966812134e-01
    z[5,0,0]  R588      2.6820677518844604e-01
    z[5,0,0]  R589      -5.1666241884231567e-01
    z[5,0,0]  R590      2.6198202371597290e-01
    z[5,0,0]  R591      6.4260315895080566e-01
    z[5,0,0]  R592      -6.7581719160079956e-01
    z[5,0,0]  R593      -1.8442372977733612e-01
    z[5,0,0]  R594      -3.3599093556404114e-01
    z[5,0,0]  R595      0.606364369392395
    z[5,0,0]  R596      7.7782802283763885e-02
    z[5,0,0]  R597      2.6149311661720276e-01
    z[5,0,0]  R598      2.3175060749053955e-01
    z[5,0,0]  R599      -2.5962504744529724e-01
    z[5,0,0]  R600      5.3548002243041992e-01
    z[5,0,0]  R601      2.5886717438697815e-01
    z[5,0,0]  R602      2.9464939236640930e-01
    z[5,0,0]  R603      2.6722711324691772e-01
    z[5,0,0]  R604      -2.3365625739097595e-01
    z[5,0,0]  R605      0.0499470978975296
    z[5,0,0]  R606      5.3919935226440430e-01
    z[5,0,0]  R607      -4.9655294418334961e-01
    z[5,0,0]  R608      2.09329737117514e-05
    z[5,0,0]  R609      -2.3614892363548279e-01
    z[5,0,0]  R610      -1.4662164449691772e-01
    z[5,0,0]  R611      -8.0243217945098877e-01
    z[5,0,0]  R612      -8.3219474554061890e-01
    z[5,0,0]  R613      -0.347666472196579
    z[5,0,0]  R614      -6.2047320604324341e-01
    z[5,0,0]  R615      -8.2506549358367920e-01
    z[5,0,0]  R616      1.6997131705284119e-01
    z[5,0,0]  R617      -3.8668278604745865e-02
    z[5,0,0]  R618      8.1161573529243469e-02
    z[5,0,0]  R619      -2.1208256483078003e-01
    z[5,0,0]  R620      2.9422247409820557e-01
    z[5,0,0]  R621      -3.4678983688354492e-01
    z[5,0,0]  R622      -8.5808329284191132e-02
    z[5,0,1]  R3        1
    z[5,0,1]  R48       -1
    z[5,0,1]  R461      -1
    z[5,0,1]  R462      1
    z[5,0,1]  R473      5.9958990663290024e-02
    z[5,0,1]  R474      -5.2166921086609364e-03
    z[5,0,1]  R475      -4.1477791965007782e-02
    z[5,0,1]  R476      7.3133128881454468e-01
    z[5,0,1]  R477      -0.0706862360239029
    z[5,0,1]  R478      6.9081479310989380e-01
    z[5,0,1]  R479      6.9255203008651733e-01
    z[5,0,1]  R480      7.9167377948760986e-01
    z[5,0,1]  R481      6.6974085569381714e-01
    z[5,0,1]  R482      8.5541135072708130e-01
    z[5,0,1]  R483      2.6883864402770996e-01
    z[5,0,1]  R484      -1.3114847242832184e-01
    z[5,0,1]  R485      2.3110222816467285e-01
    z[5,0,1]  R486      -1.0313341766595840e-01
    z[5,0,1]  R487      3.4971255064010620e-01
    z[5,0,1]  R488      2.2228454053401947e-01
    z[5,0,1]  R489      1.7723912000656128e-01
    z[5,0,1]  R490      1.1129811406135559e-01
    z[5,0,1]  R491      -4.2762002348899841e-01
    z[5,0,1]  R492      -2.9504433274269104e-01
    z[5,0,1]  R493      -1.4158391952514648e-01
    z[5,0,1]  R494      -0.139053076505661
    z[5,0,1]  R495      -6.5932208299636841e-01
    z[5,0,1]  R496      -5.9185934066772461e-01
    z[5,0,1]  R497      -0.632899284362793
    z[5,0,1]  R498      -6.1066597700119019e-01
    z[5,0,1]  R499      5.5079009383916855e-02
    z[5,0,1]  R500      -6.1779773235321045e-01
    z[5,0,1]  R501      -5.3355228900909424e-01
    z[5,0,1]  R502      -1.7407085001468658e-01
    z[5,0,1]  R503      3.0003988742828369e-01
    z[5,0,1]  R504      -7.3637050390243530e-01
    z[5,0,1]  R505      -6.3921970129013062e-01
    z[5,0,1]  R506      -7.4083238840103149e-01
    z[5,0,1]  R507      3.7029862403869629e-01
    z[5,0,1]  R508      -0.419521301984787
    z[5,0,1]  R509      -7.4704664945602417e-01
    z[5,0,1]  R510      4.4451199471950531e-02
    z[5,0,1]  R511      -5.7193356752395630e-01
    z[5,0,1]  R512      -7.1301937103271484e-01
    z[5,0,1]  R513      -7.0517992973327637e-01
    z[5,0,1]  R514      -7.2905343770980835e-01
    z[5,0,1]  R515      5.4468762874603271e-01
    z[5,0,1]  R516      -7.1067941188812256e-01
    z[5,0,1]  R517      -6.4033544063568115e-01
    z[5,0,1]  R518      -2.7156734466552734e-01
    z[5,0,1]  R519      -6.5268623828887939e-01
    z[5,0,1]  R520      -6.1438292264938354e-01
    z[5,0,1]  R521      -5.6438845396041870e-01
    z[5,0,1]  R522      -5.1818257570266724e-01
    z[5,0,1]  R523      -9.1968756914138794e-01
    z[5,0,1]  R524      9.4391658902168274e-02
    z[5,0,1]  R525      1.7546078190207481e-02
    z[5,0,1]  R526      -1.4050704240798950e-01
    z[5,0,1]  R527      3.2863533496856689e-01
    z[5,0,1]  R528      -7.3782926797866821e-01
    z[5,0,1]  R529      1.0161117464303970e-01
    z[5,0,1]  R530      -3.3437675237655640e-01
    z[5,0,1]  R531      -4.8662039637565613e-01
    z[5,0,1]  R532      -9.6070962026715279e-03
    z[5,0,1]  R533      -4.6856346726417542e-01
    z[5,0,1]  R534      -0.628913938999176
    z[5,0,1]  R535      4.7408949583768845e-02
    z[5,0,1]  R536      5.6012964248657227e-01
    z[5,0,1]  R537      6.2852632999420166e-01
    z[5,0,1]  R538      1.2805540859699249e-01
    z[5,0,1]  R539      7.2681987285614014e-01
    z[5,0,1]  R540      -7.2500887326896191e-03
    z[5,0,1]  R541      6.6576778888702393e-01
    z[5,0,1]  R542      1.2854360044002533e-01
    z[5,0,1]  R543      -7.1572464704513550e-01
    z[5,0,1]  R544      -7.2007365524768829e-02
    z[5,0,1]  R545      -5.9405052661895752e-01
    z[5,0,1]  R546      6.4080238342285156e-01
    z[5,0,1]  R547      0.0572831854224205
    z[5,0,1]  R548      -5.4361337423324585e-01
    z[5,0,1]  R549      -0.56270432472229
    z[5,0,1]  R550      -1.3700662553310394e-01
    z[5,0,1]  R551      -0.588896632194519
    z[5,0,1]  R552      -1.1941631138324738e-01
    z[5,0,1]  R553      -2.2264370322227478e-01
    z[5,0,1]  R554      -2.1294246613979340e-01
    z[5,0,1]  R555      -1.3836251199245453e-01
    z[5,0,1]  R556      -0.435705304145813
    z[5,0,1]  R557      -2.0301729440689087e-01
    z[5,0,1]  R558      -3.1558337807655334e-01
    z[5,0,1]  R559      -2.7847656607627869e-01
    z[5,0,1]  R560      7.6416528224945068e-01
    z[5,0,1]  R561      -7.8548008203506470e-01
    z[5,0,1]  R562      8.0665594339370728e-01
    z[5,0,1]  R563      -3.3685964345932007e-01
    z[5,0,1]  R564      2.7346780896186829e-01
    z[5,0,1]  R565      2.7014365792274475e-01
    z[5,0,1]  R566      -3.3656972646713257e-01
    z[5,0,1]  R567      -8.8725142180919647e-02
    z[5,0,1]  R568      2.8172996640205383e-01
    z[5,0,1]  R569      3.6521452665328979e-01
    z[5,0,1]  R570      2.9680988192558289e-01
    z[5,0,1]  R571      4.8430547118186951e-01
    z[5,0,1]  R572      -5.7254844903945923e-01
    z[5,0,1]  R573      -7.4589270353317261e-01
    z[5,0,1]  R574      -7.4100983142852783e-01
    z[5,0,1]  R575      -7.2726887464523315e-01
    z[5,0,1]  R576      -6.7125785350799561e-01
    z[5,0,1]  R577      1.5988697111606598e-01
    z[5,0,1]  R578      1.8887175619602203e-01
    z[5,0,1]  R579      -5.4959356784820557e-01
    z[5,0,1]  R580      -6.7379742860794067e-01
    z[5,0,1]  R581      -6.6956084966659546e-01
    z[5,0,1]  R582      -3.9947167038917542e-01
    z[5,0,1]  R583      -5.3852275013923645e-02
    z[5,0,1]  R584      -4.7587621212005615e-01
    z[5,0,1]  R585      -6.2989002466201782e-01
    z[5,0,1]  R586      -6.2229627370834351e-01
    z[5,0,1]  R587      -4.0601894259452820e-01
    z[5,0,1]  R588      7.7640879154205322e-01
    z[5,0,1]  R589      -6.0742509365081787e-01
    z[5,0,1]  R590      -5.3855621814727783e-01
    z[5,0,1]  R591      -4.3175691366195679e-01
    z[5,0,1]  R592      -4.1912712156772614e-02
    z[5,0,1]  R593      -0.726190984249115
    z[5,0,1]  R594      -1.2535278499126434e-01
    z[5,0,1]  R595      -1.4139276742935181e-01
    z[5,0,1]  R596      1.7624922096729279e-01
    z[5,0,1]  R597      -6.6605895757675171e-01
    z[5,0,1]  R598      -6.7663162946701050e-01
    z[5,0,1]  R599      -4.1021513938903809e-01
    z[5,0,1]  R600      2.2009445726871490e-01
    z[5,0,1]  R601      -5.6356501579284668e-01
    z[5,0,1]  R602      -5.3775697946548462e-01
    z[5,0,1]  R603      -8.9600396156311035e-01
    z[5,0,1]  R604      -7.5159054994583130e-01
    z[5,0,1]  R605      -0.684525728225708
    z[5,0,1]  R606      3.8078734278678894e-01
    z[5,0,1]  R607      -6.9227421283721924e-01
    z[5,0,1]  R608      -2.9972484707832336e-01
    z[5,0,1]  R609      -0.756924569606781
    z[5,0,1]  R610      -3.3998182415962219e-01
    z[5,0,1]  R611      1.1340260505676270e-01
    z[5,0,1]  R612      1.5856340527534485e-01
    z[5,0,1]  R613      1.1163343489170074e-01
    z[5,0,1]  R614      -6.9189441204071045e-01
    z[5,0,1]  R615      -1.9321131706237793e-01
    z[5,0,1]  R616      -6.3497972488403320e-01
    z[5,0,1]  R617      -5.7006675004959106e-01
    z[5,0,1]  R618      5.4780155420303345e-01
    z[5,0,1]  R619      6.3868921995162964e-01
    z[5,0,1]  R620      4.1757425665855408e-01
    z[5,0,1]  R621      4.2315801978111267e-01
    z[5,0,1]  R622      6.0656005144119263e-01
    z[5,0,2]  R4        1
    z[5,0,2]  R49       -1
    z[5,0,2]  R463      -1
    z[5,0,2]  R464      1
    z[5,0,2]  R473      5.5815988779067993e-01
    z[5,0,2]  R474      2.2595489025115967e-01
    z[5,0,2]  R475      2.2538958489894867e-01
    z[5,0,2]  R476      1.6700945794582367e-01
    z[5,0,2]  R477      8.1221228837966919e-01
    z[5,0,2]  R478      4.5618122816085815e-01
    z[5,0,2]  R479      1.2502519786357880e-01
    z[5,0,2]  R480      4.0478205680847168e-01
    z[5,0,2]  R481      5.3620833158493042e-01
    z[5,0,2]  R482      3.9113810658454895e-01
    z[5,0,2]  R483      4.7829464077949524e-01
    z[5,0,2]  R484      4.1106197237968445e-01
    z[5,0,2]  R485      -4.9869006872177124e-01
    z[5,0,2]  R486      -7.2007972002029419e-01
    z[5,0,2]  R487      -1.7156164348125458e-01
    z[5,0,2]  R488      -4.4149711728096008e-01
    z[5,0,2]  R489      2.8669720888137817e-01
    z[5,0,2]  R490      -2.1144950389862061e-01
    z[5,0,2]  R491      4.6509110927581787e-01
    z[5,0,2]  R492      1.4532390236854553e-01
    z[5,0,2]  R493      -2.3328140377998352e-01
    z[5,0,2]  R494      -1.0717423260211945e-01
    z[5,0,2]  R495      1.3992665708065033e-01
    z[5,0,2]  R496      2.9441145062446594e-01
    z[5,0,2]  R497      -2.7040395140647888e-01
    z[5,0,2]  R498      1.5309794247150421e-01
    z[5,0,2]  R499      7.6245918869972229e-02
    z[5,0,2]  R500      -4.4432663917541504e-01
    z[5,0,2]  R501      1.7600879073143005e-01
    z[5,0,2]  R502      -2.4465925991535187e-01
    z[5,0,2]  R503      -2.3060524463653564e-01
    z[5,0,2]  R504      -1.9868843257427216e-01
    z[5,0,2]  R505      5.8883899450302124e-01
    z[5,0,2]  R506      -2.7977502346038818e-01
    z[5,0,2]  R507      6.0295041650533676e-02
    z[5,0,2]  R508      -5.6695544719696045e-01
    z[5,0,2]  R509      -3.8297054171562195e-01
    z[5,0,2]  R510      3.1879439949989319e-01
    z[5,0,2]  R511      1.5251060947775841e-02
    z[5,0,2]  R512      -7.6868377625942230e-02
    z[5,0,2]  R513      4.2163223028182983e-01
    z[5,0,2]  R514      -5.6556697934865952e-02
    z[5,0,2]  R515      -2.1222374925855547e-04
    z[5,0,2]  R516      -3.3787724375724792e-01
    z[5,0,2]  R517      6.0927208513021469e-02
    z[5,0,2]  R518      -9.9846169352531433e-02
    z[5,0,2]  R519      -1.7482639849185944e-01
    z[5,0,2]  R520      -3.3913305401802063e-01
    z[5,0,2]  R521      4.5557226985692978e-02
    z[5,0,2]  R522      4.0963280200958252e-01
    z[5,0,2]  R523      9.2758618295192719e-02
    z[5,0,2]  R524      1.0184465348720551e-01
    z[5,0,2]  R525      1.7514440417289734e-01
    z[5,0,2]  R526      2.0122143626213074e-01
    z[5,0,2]  R527      5.0607389211654663e-01
    z[5,0,2]  R528      -3.5405641794204712e-01
    z[5,0,2]  R529      2.0912717282772064e-01
    z[5,0,2]  R530      1.5767259895801544e-01
    z[5,0,2]  R531      8.4160633385181427e-02
    z[5,0,2]  R532      4.6334043145179749e-01
    z[5,0,2]  R533      2.3736357688903809e-01
    z[5,0,2]  R534      3.1158637255430222e-02
    z[5,0,2]  R535      6.0849428176879883e-01
    z[5,0,2]  R536      1.4234395325183868e-01
    z[5,0,2]  R537      4.0318641066551208e-01
    z[5,0,2]  R538      1.1819498240947723e-01
    z[5,0,2]  R539      2.4166959524154663e-01
    z[5,0,2]  R540      3.1032716855406761e-02
    z[5,0,2]  R541      2.0859509706497192e-01
    z[5,0,2]  R542      0.599233090877533
    z[5,0,2]  R543      -2.5074759125709534e-01
    z[5,0,2]  R544      -3.3579967916011810e-02
    z[5,0,2]  R545      6.2019848823547363e-01
    z[5,0,2]  R546      1.2159148603677750e-01
    z[5,0,2]  R547      -1.8446686863899231e-01
    z[5,0,2]  R548      3.5102772712707520e-01
    z[5,0,2]  R549      3.5609204322099686e-02
    z[5,0,2]  R550      5.5760347843170166e-01
    z[5,0,2]  R551      -6.0046225786209106e-01
    z[5,0,2]  R552      4.1237625479698181e-01
    z[5,0,2]  R553      2.7154350280761719e-01
    z[5,0,2]  R554      4.4143462181091309e-01
    z[5,0,2]  R555      8.3131664991378784e-01
    z[5,0,2]  R556      4.6449339389801025e-01
    z[5,0,2]  R557      8.4280174970626831e-01
    z[5,0,2]  R558      -4.2990061640739441e-01
    z[5,0,2]  R559      6.5445041656494141e-01
    z[5,0,2]  R560      0.463827520608902
    z[5,0,2]  R561      -1.3543221354484558e-01
    z[5,0,2]  R562      -1.3307537138462067e-01
    z[5,0,2]  R563      1.4464181661605835e-01
    z[5,0,2]  R564      2.6798495650291443e-01
    z[5,0,2]  R565      -2.5691960006952286e-02
    z[5,0,2]  R566      7.8006774187088013e-02
    z[5,0,2]  R567      -6.5830785036087036e-01
    z[5,0,2]  R568      1.6097073256969452e-01
    z[5,0,2]  R569      -1.6943724453449249e-01
    z[5,0,2]  R570      1.9703787565231323e-01
    z[5,0,2]  R571      -5.5116581916809082e-01
    z[5,0,2]  R572      -5.4144448041915894e-01
    z[5,0,2]  R573      1.9915345311164856e-01
    z[5,0,2]  R574      1.0369341075420380e-01
    z[5,0,2]  R575      9.9111318588256836e-02
    z[5,0,2]  R576      3.8619977235794067e-01
    z[5,0,2]  R577      -4.6538066864013672e-01
    z[5,0,2]  R578      -1.0131541639566422e-01
    z[5,0,2]  R579      4.2116996645927429e-01
    z[5,0,2]  R580      2.6482033729553223e-01
    z[5,0,2]  R581      -3.6697569489479065e-01
    z[5,0,2]  R582      1.5854367613792419e-01
    z[5,0,2]  R583      2.5470137596130371e-01
    z[5,0,2]  R584      1.0269098728895187e-01
    z[5,0,2]  R585      1.8841113150119781e-01
    z[5,0,2]  R586      -2.0193751156330109e-01
    z[5,0,2]  R587      0.0861692801117897
    z[5,0,2]  R588      -3.4506402909755707e-02
    z[5,0,2]  R589      -1.8633969128131866e-01
    z[5,0,2]  R590      -4.5117273926734924e-01
    z[5,0,2]  R591      5.2752655744552612e-01
    z[5,0,2]  R592      8.5915029048919678e-02
    z[5,0,2]  R593      3.6486014723777771e-01
    z[5,0,2]  R594      -6.0144379734992981e-02
    z[5,0,2]  R595      1.9117403775453568e-02
    z[5,0,2]  R596      -4.5376253128051758e-01
    z[5,0,2]  R597      1.4187838137149811e-01
    z[5,0,2]  R598      -3.0472939833998680e-02
    z[5,0,2]  R599      5.4875838756561279e-01
    z[5,0,2]  R600      9.6292868256568909e-02
    z[5,0,2]  R601      3.1461793184280396e-01
    z[5,0,2]  R602      5.6821137666702271e-01
    z[5,0,2]  R603      -4.0757302194833755e-02
    z[5,0,2]  R604      3.8455966114997864e-01
    z[5,0,2]  R605      -0.590084969997406
    z[5,0,2]  R606      2.5851535797119141e-01
    z[5,0,2]  R607      -0.374023973941803
    z[5,0,2]  R608      7.3741018772125244e-01
    z[5,0,2]  R609      -1.3904018700122833e-01
    z[5,0,2]  R610      7.4900567531585693e-01
    z[5,0,2]  R611      -1.7675158381462097e-01
    z[5,0,2]  R612      1.3139372691512108e-02
    z[5,0,2]  R613      -0.291920006275177
    z[5,0,2]  R614      6.5194942057132721e-02
    z[5,0,2]  R615      -2.0398974418640137e-01
    z[5,0,2]  R616      -0.514629065990448
    z[5,0,2]  R617      0.0444374643266201
    z[5,0,2]  R618      3.4484487771987915e-01
    z[5,0,2]  R619      5.0325065851211548e-01
    z[5,0,2]  R620      -6.8468250334262848e-02
    z[5,0,2]  R621      5.2718663215637207e-01
    z[5,0,2]  R622      1.9963055849075317e-01
    z[5,0,3]  R5        1
    z[5,0,3]  R50       -1
    z[5,0,3]  R465      -1
    z[5,0,3]  R466      1
    z[5,0,3]  R473      -6.5109741687774658e-01
    z[5,0,3]  R474      -6.2717002630233765e-01
    z[5,0,3]  R475      -7.7808088064193726e-01
    z[5,0,3]  R476      1.4964616298675537e-01
    z[5,0,3]  R477      -2.8170493245124817e-01
    z[5,0,3]  R478      -2.2198049724102020e-01
    z[5,0,3]  R479      8.4494002163410187e-02
    z[5,0,3]  R480      -1.6668562591075897e-01
    z[5,0,3]  R481      -4.2440012097358704e-02
    z[5,0,3]  R482      5.8643206954002380e-02
    z[5,0,3]  R483      2.6806342601776123e-01
    z[5,0,3]  R484      7.3074257373809814e-01
    z[5,0,3]  R485      4.5107737183570862e-01
    z[5,0,3]  R486      4.0506976842880249e-01
    z[5,0,3]  R487      3.5198843479156494e-01
    z[5,0,3]  R488      0.509611189365387
    z[5,0,3]  R489      4.0571564435958862e-01
    z[5,0,3]  R490      3.1033343076705933e-01
    z[5,0,3]  R491      2.2961201146245003e-02
    z[5,0,3]  R492      3.0198348686099052e-02
    z[5,0,3]  R493      4.6960216760635376e-01
    z[5,0,3]  R494      3.3206886053085327e-01
    z[5,0,3]  R495      1.2452097237110138e-01
    z[5,0,3]  R496      -3.0271539092063904e-01
    z[5,0,3]  R497      -6.3038282096385956e-02
    z[5,0,3]  R498      8.8862545788288116e-02
    z[5,0,3]  R499      1.9767074286937714e-01
    z[5,0,3]  R500      7.8074708580970764e-02
    z[5,0,3]  R501      -7.4829542636871338e-01
    z[5,0,3]  R502      2.4469788372516632e-01
    z[5,0,3]  R503      5.1538795232772827e-01
    z[5,0,3]  R504      1.0687772929668427e-01
    z[5,0,3]  R505      -4.7982245683670044e-02
    z[5,0,3]  R506      -3.9214301109313965e-01
    z[5,0,3]  R507      4.2069315910339355e-01
    z[5,0,3]  R508      5.0914257764816284e-01
    z[5,0,3]  R509      2.0109629631042480e-01
    z[5,0,3]  R510      2.7164161205291748e-01
    z[5,0,3]  R511      -0.347178190946579
    z[5,0,3]  R512      -4.3560093641281128e-01
    z[5,0,3]  R513      2.8857287764549255e-01
    z[5,0,3]  R514      1.5668129920959473e-01
    z[5,0,3]  R515      4.3472734093666077e-01
    z[5,0,3]  R516      -2.9675019904971123e-02
    z[5,0,3]  R517      2.3451203107833862e-01
    z[5,0,3]  R518      6.3514953851699829e-01
    z[5,0,3]  R519      1.2547163665294647e-01
    z[5,0,3]  R520      -1.6502922773361206e-01
    z[5,0,3]  R521      -2.4309846758842468e-01
    z[5,0,3]  R522      1.9159168004989624e-01
    z[5,0,3]  R523      -1.4149367809295654e-01
    z[5,0,3]  R524      5.6732130050659180e-01
    z[5,0,3]  R525      9.2289096117019653e-01
    z[5,0,3]  R526      9.2001551389694214e-01
    z[5,0,3]  R527      5.1745635271072388e-01
    z[5,0,3]  R528      -4.8330705612897873e-02
    z[5,0,3]  R529      3.7941941618919373e-01
    z[5,0,3]  R530      -0.863492488861084
    z[5,0,3]  R531      -5.3829592466354370e-01
    z[5,0,3]  R532      -6.1950671672821045e-01
    z[5,0,3]  R533      -7.3992156982421875e-01
    z[5,0,3]  R534      4.6827623248100281e-01
    z[5,0,3]  R535      -6.1597061157226562e-01
    z[5,0,3]  R536      -1.3543231785297394e-01
    z[5,0,3]  R537      2.1678598225116730e-01
    z[5,0,3]  R538      1.0164123773574829e-01
    z[5,0,3]  R539      -0.0944051444530487
    z[5,0,3]  R540      -3.6431051790714264e-02
    z[5,0,3]  R541      3.6285273730754852e-02
    z[5,0,3]  R542      4.0914192795753479e-01
    z[5,0,3]  R543      2.6608530431985855e-02
    z[5,0,3]  R544      2.8290608525276184e-01
    z[5,0,3]  R545      3.6883381009101868e-01
    z[5,0,3]  R546      6.7364257574081421e-01
    z[5,0,3]  R547      3.0480548739433289e-01
    z[5,0,3]  R548      1.1650307476520538e-01
    z[5,0,3]  R549      1.1999174207448959e-01
    z[5,0,3]  R550      -6.6445344686508179e-01
    z[5,0,3]  R551      1.1093888431787491e-02
    z[5,0,3]  R552      -6.6328942775726318e-01
    z[5,0,3]  R553      -7.0720982551574707e-01
    z[5,0,3]  R554      -6.9758069515228271e-01
    z[5,0,3]  R555      -2.4126936495304108e-01
    z[5,0,3]  R556      -3.0696383118629456e-01
    z[5,0,3]  R557      -2.0187194645404816e-01
    z[5,0,3]  R558      -6.9268339872360229e-01
    z[5,0,3]  R559      -3.5274004936218262e-01
    z[5,0,3]  R560      3.8146394491195679e-01
    z[5,0,3]  R561      -4.5888921618461609e-01
    z[5,0,3]  R562      4.2126268148422241e-01
    z[5,0,3]  R563      6.2814855575561523e-01
    z[5,0,3]  R564      5.5779051780700684e-01
    z[5,0,3]  R565      5.6700974702835083e-01
    z[5,0,3]  R566      3.4470441937446594e-01
    z[5,0,3]  R567      4.9914455413818359e-01
    z[5,0,3]  R568      4.1553494334220886e-01
    z[5,0,3]  R569      3.6966013908386230e-01
    z[5,0,3]  R570      9.6126310527324677e-02
    z[5,0,3]  R571      5.7133400440216064e-01
    z[5,0,3]  R572      5.9475088119506836e-01
    z[5,0,3]  R573      -7.6354585587978363e-02
    z[5,0,3]  R574      1.8178611993789673e-01
    z[5,0,3]  R575      -4.2014512419700623e-01
    z[5,0,3]  R576      -4.1211771965026855e-01
    z[5,0,3]  R577      6.1982864141464233e-01
    z[5,0,3]  R578      1.6295839846134186e-01
    z[5,0,3]  R579      -1.9765029847621918e-01
    z[5,0,3]  R580      -5.0161361694335938e-01
    z[5,0,3]  R581      -2.3411202430725098e-01
    z[5,0,3]  R582      -6.1734235286712646e-01
    z[5,0,3]  R583      8.9579766988754272e-01
    z[5,0,3]  R584      -7.7933639287948608e-01
    z[5,0,3]  R585      -5.9990060329437256e-01
    z[5,0,3]  R586      8.5244961082935333e-02
    z[5,0,3]  R587      -3.2611685991287231e-01
    z[5,0,3]  R588      4.1469329595565796e-01
    z[5,0,3]  R589      1.8109214305877686e-01
    z[5,0,3]  R590      4.6539118885993958e-01
    z[5,0,3]  R591      1.2050674110651016e-01
    z[5,0,3]  R592      3.9610946178436279e-01
    z[5,0,3]  R593      -3.0852460861206055e-01
    z[5,0,3]  R594      3.4933799505233765e-01
    z[5,0,3]  R595      6.2043029069900513e-01
    z[5,0,3]  R596      7.1201616525650024e-01
    z[5,0,3]  R597      -3.2935658097267151e-01
    z[5,0,3]  R598      4.9749910831451416e-01
    z[5,0,3]  R599      -0.595457911491394
    z[5,0,3]  R600      4.0302717685699463e-01
    z[5,0,3]  R601      1.9613612443208694e-02
    z[5,0,3]  R602      2.4057655036449432e-01
    z[5,0,3]  R603      2.6396757364273071e-01
    z[5,0,3]  R604      -1.8983669579029083e-01
    z[5,0,3]  R605      -5.6722037494182587e-02
    z[5,0,3]  R606      6.0487186908721924e-01
    z[5,0,3]  R607      -1.7714852094650269e-01
    z[5,0,3]  R608      -5.5686396360397339e-01
    z[5,0,3]  R609      1.9345837831497192e-01
    z[5,0,3]  R610      -2.0902976393699646e-01
    z[5,0,3]  R611      4.4478651881217957e-01
    z[5,0,3]  R612      3.3601793646812439e-01
    z[5,0,3]  R613      0.655640721321106
    z[5,0,3]  R614      -2.3139376938343048e-01
    z[5,0,3]  R615      2.8733009099960327e-01
    z[5,0,3]  R616      -1.0046269744634628e-01
    z[5,0,3]  R617      -3.3963614702224731e-01
    z[5,0,3]  R618      6.7690014839172363e-01
    z[5,0,3]  R619      2.1949785947799683e-01
    z[5,0,3]  R620      4.9358087778091431e-01
    z[5,0,3]  R621      4.3031710386276245e-01
    z[5,0,3]  R622      7.8850097954273224e-02
    z[5,0,4]  R6        1
    z[5,0,4]  R51       -1
    z[5,0,4]  R467      -1
    z[5,0,4]  R468      1
    z[5,0,4]  R473      3.5494975745677948e-02
    z[5,0,4]  R474      3.9642862975597382e-03
    z[5,0,4]  R475      -0.091993547976017
    z[5,0,4]  R476      -9.1157844290137291e-03
    z[5,0,4]  R477      -3.5667590796947479e-02
    z[5,0,4]  R478      2.1434406936168671e-01
    z[5,0,4]  R479      0.334311306476593
    z[5,0,4]  R480      2.6511928439140320e-01
    z[5,0,4]  R481      -2.0978540182113647e-01
    z[5,0,4]  R482      -1.8253475427627563e-01
    z[5,0,4]  R483      7.7206425368785858e-02
    z[5,0,4]  R484      5.9892702847719193e-02
    z[5,0,4]  R485      -1.0336165875196457e-01
    z[5,0,4]  R486      8.4578081965446472e-02
    z[5,0,4]  R487      9.1192595660686493e-02
    z[5,0,4]  R488      1.7118583619594574e-01
    z[5,0,4]  R489      -1.6608101129531860e-01
    z[5,0,4]  R490      -2.7674525976181030e-01
    z[5,0,4]  R491      -1.9405819475650787e-01
    z[5,0,4]  R492      7.9633817076683044e-02
    z[5,0,4]  R493      0.0679209977388382
    z[5,0,4]  R494      1.0429047048091888e-01
    z[5,0,4]  R495      -2.2596006095409393e-01
    z[5,0,4]  R496      1.8353813886642456e-01
    z[5,0,4]  R497      -4.0670579671859741e-01
    z[5,0,4]  R498      -2.8136115521192551e-02
    z[5,0,4]  R499      2.4890285730361938e-01
    z[5,0,4]  R500      -1.1637928336858749e-01
    z[5,0,4]  R501      1.4769001305103302e-01
    z[5,0,4]  R502      8.6736559867858887e-02
    z[5,0,4]  R503      5.2736252546310425e-01
    z[5,0,4]  R504      3.4467944502830505e-01
    z[5,0,4]  R505      -9.3032978475093842e-02
    z[5,0,4]  R506      -1.4599943161010742e-01
    z[5,0,4]  R507      2.4246694147586823e-01
    z[5,0,4]  R508      -5.3987614810466766e-02
    z[5,0,4]  R509      -4.0561595559120178e-01
    z[5,0,4]  R510      4.7643250226974487e-01
    z[5,0,4]  R511      1.1399107426404953e-01
    z[5,0,4]  R512      -3.6978834867477417e-01
    z[5,0,4]  R513      7.7476361766457558e-03
    z[5,0,4]  R514      -1.7588908970355988e-01
    z[5,0,4]  R515      1.7745584249496460e-01
    z[5,0,4]  R516      2.0051756501197815e-01
    z[5,0,4]  R517      -1.5259747393429279e-02
    z[5,0,4]  R518      3.9132067561149597e-01
    z[5,0,4]  R519      -3.0765104293823242e-01
    z[5,0,4]  R520      -3.7825030088424683e-01
    z[5,0,4]  R521      4.5621815323829651e-01
    z[5,0,4]  R522      -3.1934878230094910e-01
    z[5,0,4]  R523      3.3947516232728958e-02
    z[5,0,4]  R524      1.4159974455833435e-01
    z[5,0,4]  R525      -1.8256385624408722e-01
    z[5,0,4]  R526      8.2530558109283447e-02
    z[5,0,4]  R527      2.2407043725252151e-02
    z[5,0,4]  R528      -1.9012410938739777e-01
    z[5,0,4]  R529      5.4631102085113525e-01
    z[5,0,4]  R530      5.9076272882521152e-03
    z[5,0,4]  R531      2.1291528642177582e-01
    z[5,0,4]  R532      -1.3926008343696594e-01
    z[5,0,4]  R533      -0.0978035256266594
    z[5,0,4]  R534      -3.0345961451530457e-01
    z[5,0,4]  R535      -0.0781460627913475
    z[5,0,4]  R536      4.1999399662017822e-01
    z[5,0,4]  R537      -5.8338645845651627e-02
    z[5,0,4]  R538      1.0958840698003769e-01
    z[5,0,4]  R539      4.8430660367012024e-01
    z[5,0,4]  R540      0.261323481798172
    z[5,0,4]  R541      2.9446640610694885e-01
    z[5,0,4]  R542      1.5138788521289825e-01
    z[5,0,4]  R543      -4.8259207606315613e-01
    z[5,0,4]  R544      2.0322456955909729e-01
    z[5,0,4]  R545      -2.0986037328839302e-02
    z[5,0,4]  R546      2.3399895429611206e-01
    z[5,0,4]  R547      -2.8322216868400574e-01
    z[5,0,4]  R548      1.1421643942594528e-01
    z[5,0,4]  R549      -1.4713747799396515e-01
    z[5,0,4]  R550      1.1014923220500350e-03
    z[5,0,4]  R551      1.5322542190551758e-01
    z[5,0,4]  R552      -1.8408633768558502e-01
    z[5,0,4]  R553      1.2259913235902786e-01
    z[5,0,4]  R554      2.6392656564712524e-01
    z[5,0,4]  R555      4.6463202685117722e-02
    z[5,0,4]  R556      -3.5254594683647156e-01
    z[5,0,4]  R557      -2.4449007213115692e-01
    z[5,0,4]  R558      2.8654780983924866e-01
    z[5,0,4]  R559      -5.7972751557826996e-02
    z[5,0,4]  R560      -4.0461938828229904e-02
    z[5,0,4]  R561      -2.2709010541439056e-01
    z[5,0,4]  R562      -0.331691712141037
    z[5,0,4]  R563      9.4646655023097992e-02
    z[5,0,4]  R564      -4.7965649515390396e-02
    z[5,0,4]  R565      5.3363703191280365e-02
    z[5,0,4]  R566      1.8360137939453125e-01
    z[5,0,4]  R567      -1.9633080065250397e-01
    z[5,0,4]  R568      -1.4350116252899170e-01
    z[5,0,4]  R569      5.9857752174139023e-02
    z[5,0,4]  R570      1.1935921013355255e-01
    z[5,0,4]  R571      7.4213206768035889e-02
    z[5,0,4]  R572      6.1546668410301208e-02
    z[5,0,4]  R573      -6.4590275287628174e-02
    z[5,0,4]  R574      -3.2296633720397949e-01
    z[5,0,4]  R575      -1.5243685804307461e-02
    z[5,0,4]  R576      3.8030825555324554e-02
    z[5,0,4]  R577      3.1678044795989990e-01
    z[5,0,4]  R578      -7.3413648642599583e-03
    z[5,0,4]  R579      -2.7928823605179787e-02
    z[5,0,4]  R580      -2.2214733064174652e-01
    z[5,0,4]  R581      2.4055325984954834e-01
    z[5,0,4]  R582      7.1519844233989716e-02
    z[5,0,4]  R583      1.5579383075237274e-01
    z[5,0,4]  R584      1.6558946669101715e-01
    z[5,0,4]  R585      -3.2959397882223129e-02
    z[5,0,4]  R586      1.9690386950969696e-01
    z[5,0,4]  R587      6.4184583723545074e-02
    z[5,0,4]  R588      2.3151208460330963e-01
    z[5,0,4]  R589      -1.0148895531892776e-01
    z[5,0,4]  R590      2.3119370639324188e-01
    z[5,0,4]  R591      3.2638299465179443e-01
    z[5,0,4]  R592      1.8954484164714813e-01
    z[5,0,4]  R593      -2.1056285500526428e-01
    z[5,0,4]  R594      2.6625737547874451e-01
    z[5,0,4]  R595      -2.0119942724704742e-01
    z[5,0,4]  R596      -3.2164674997329712e-01
    z[5,0,4]  R597      4.9756950139999390e-01
    z[5,0,4]  R598      -4.0620166063308716e-01
    z[5,0,4]  R599      -0.129534512758255
    z[5,0,4]  R600      2.8277760744094849e-01
    z[5,0,4]  R601      1.3353681564331055e-01
    z[5,0,4]  R602      -4.8810219764709473e-01
    z[5,0,4]  R603      2.2378638386726379e-01
    z[5,0,4]  R604      -7.5205512344837189e-02
    z[5,0,4]  R605      8.6364768445491791e-02
    z[5,0,4]  R606      1.6309115290641785e-01
    z[5,0,4]  R607      -2.0140078663825989e-01
    z[5,0,4]  R608      1.1269237147644162e-03
    z[5,0,4]  R609      -5.0101685523986816e-01
    z[5,0,4]  R610      -2.0102441310882568e-01
    z[5,0,4]  R611      2.6743793487548828e-01
    z[5,0,4]  R612      3.7970918416976929e-01
    z[5,0,4]  R613      4.4239366054534912e-01
    z[5,0,4]  R614      2.2575096786022186e-01
    z[5,0,4]  R615      9.5553815364837646e-02
    z[5,0,4]  R616      -5.1294457912445068e-01
    z[5,0,4]  R617      -4.4900581240653992e-01
    z[5,0,4]  R618      7.5459964573383331e-02
    z[5,0,4]  R619      4.7838100790977478e-01
    z[5,0,4]  R620      2.4804225564002991e-01
    z[5,0,4]  R621      -2.0714102685451508e-01
    z[5,0,4]  R622      -0.0595281757414341
    z[5,0,5]  R7        1
    z[5,0,5]  R52       -1
    z[5,0,5]  R469      -1
    z[5,0,5]  R470      1
    z[5,0,5]  R473      2.1825125813484192e-01
    z[5,0,5]  R474      -1.6139014065265656e-01
    z[5,0,5]  R475      -1.1417536437511444e-01
    z[5,0,5]  R476      5.5422621965408325e-01
    z[5,0,5]  R477      -1.3392789661884308e-01
    z[5,0,5]  R478      -7.7547687105834484e-03
    z[5,0,5]  R479      2.3872756958007812e-01
    z[5,0,5]  R480      -1.4714235067367554e-01
    z[5,0,5]  R481      3.2425004243850708e-01
    z[5,0,5]  R482      0.00981933530420065
    z[5,0,5]  R483      -7.5578755140304565e-01
    z[5,0,5]  R484      -3.6837142705917358e-01
    z[5,0,5]  R485      -3.8060164451599121e-01
    z[5,0,5]  R486      -4.7244527935981750e-01
    z[5,0,5]  R487      -4.5457679033279419e-01
    z[5,0,5]  R488      -2.8590077161788940e-01
    z[5,0,5]  R489      -5.7144075632095337e-01
    z[5,0,5]  R490      -3.1042066216468811e-01
    z[5,0,5]  R491      3.2131791114807129e-01
    z[5,0,5]  R492      -1.9068498909473419e-01
    z[5,0,5]  R493      -7.7682763338088989e-01
    z[5,0,5]  R494      -6.6140621900558472e-01
    z[5,0,5]  R495      1.5085159242153168e-01
    z[5,0,5]  R496      -2.7786001563072205e-01
    z[5,0,5]  R497      4.7036954760551453e-01
    z[5,0,5]  R498      2.8375312685966492e-01
    z[5,0,5]  R499      -5.8317315578460693e-01
    z[5,0,5]  R500      -6.2162160873413086e-02
    z[5,0,5]  R501      -1.9050613045692444e-01
    z[5,0,5]  R502      -5.0837069749832153e-01
    z[5,0,5]  R503      -4.6687945723533630e-01
    z[5,0,5]  R504      2.4668979644775391e-01
    z[5,0,5]  R505      3.4272089600563049e-01
    z[5,0,5]  R506      1.4843259751796722e-01
    z[5,0,5]  R507      -4.1661235690116882e-01
    z[5,0,5]  R508      -3.3581340312957764e-01
    z[5,0,5]  R509      -4.1864910599542782e-05
    z[5,0,5]  R510      -5.6735342741012573e-01
    z[5,0,5]  R511      -2.8519338369369507e-01
    z[5,0,5]  R512      -3.2680696249008179e-01
    z[5,0,5]  R513      -3.1746879220008850e-01
    z[5,0,5]  R514      2.8315432369709015e-02
    z[5,0,5]  R515      -5.2213990688323975e-01
    z[5,0,5]  R516      -4.6418279409408569e-01
    z[5,0,5]  R517      -5.5919522047042847e-01
    z[5,0,5]  R518      -8.5035160183906555e-02
    z[5,0,5]  R519      -5.5289936065673828e-01
    z[5,0,5]  R520      -8.4765315055847168e-02
    z[5,0,5]  R521      7.0585653185844421e-02
    z[5,0,5]  R522      -3.6760583519935608e-01
    z[5,0,5]  R523      5.3840130567550659e-02
    z[5,0,5]  R524      -5.3950971364974976e-01
    z[5,0,5]  R525      -1.6871818900108337e-01
    z[5,0,5]  R526      8.8136322796344757e-02
    z[5,0,5]  R527      -0.560045599937439
    z[5,0,5]  R528      -2.2227661311626434e-01
    z[5,0,5]  R529      -4.8511779308319092e-01
    z[5,0,5]  R530      0.0947168618440628
    z[5,0,5]  R531      4.3137103319168091e-01
    z[5,0,5]  R532      -0.514052152633667
    z[5,0,5]  R533      -1.3797669112682343e-01
    z[5,0,5]  R534      -3.2306542992591858e-01
    z[5,0,5]  R535      -2.9790589213371277e-01
    z[5,0,5]  R536      5.7864511013031006e-01
    z[5,0,5]  R537      -5.6701570749282837e-02
    z[5,0,5]  R538      2.1980141103267670e-01
    z[5,0,5]  R539      3.4816437959671021e-01
    z[5,0,5]  R540      -1.7437775433063507e-01
    z[5,0,5]  R541      6.0073465108871460e-01
    z[5,0,5]  R542      5.6616044044494629e-01
    z[5,0,5]  R543      4.0612876415252686e-02
    z[5,0,5]  R544      -8.2353627681732178e-01
    z[5,0,5]  R545      3.7596080452203751e-02
    z[5,0,5]  R546      -8.9968152344226837e-02
    z[5,0,5]  R547      -7.2813975811004639e-01
    z[5,0,5]  R548      4.2458567023277283e-01
    z[5,0,5]  R549      0.352770060300827
    z[5,0,5]  R550      -4.4315110892057419e-02
    z[5,0,5]  R551      3.7983334064483643e-01
    z[5,0,5]  R552      -4.0564981102943420e-01
    z[5,0,5]  R553      -1.9956852495670319e-01
    z[5,0,5]  R554      2.0951206982135773e-01
    z[5,0,5]  R555      -1.6466975212097168e-01
    z[5,0,5]  R556      -4.5666342973709106e-01
    z[5,0,5]  R557      -2.9176460579037666e-02
    z[5,0,5]  R558      1.9770933687686920e-01
    z[5,0,5]  R559      5.5945134162902832e-01
    z[5,0,5]  R560      -1.6124244034290314e-01
    z[5,0,5]  R561      1.6466896235942841e-01
    z[5,0,5]  R562      -1.2085715681314468e-01
    z[5,0,5]  R563      -4.3522989749908447e-01
    z[5,0,5]  R564      -4.2333969473838806e-01
    z[5,0,5]  R565      -2.8290903568267822e-01
    z[5,0,5]  R566      -5.5686312913894653e-01
    z[5,0,5]  R567      -4.0836516022682190e-01
    z[5,0,5]  R568      -3.2412597537040710e-01
    z[5,0,5]  R569      -3.8572993874549866e-01
    z[5,0,5]  R570      -7.1814113855361938e-01
    z[5,0,5]  R571      -2.9740974307060242e-01
    z[5,0,5]  R572      5.8317895978689194e-02
    z[5,0,5]  R573      -4.8274996876716614e-01
    z[5,0,5]  R574      5.1724809408187866e-01
    z[5,0,5]  R575      -4.6995180845260620e-01
    z[5,0,5]  R576      3.5755565762519836e-01
    z[5,0,5]  R577      -3.3992937207221985e-01
    z[5,0,5]  R578      -9.5896673202514648e-01
    z[5,0,5]  R579      0.281389981508255
    z[5,0,5]  R580      -1.3235056400299072e-01
    z[5,0,5]  R581      -5.0508117675781250e-01
    z[5,0,5]  R582      -4.1683351993560791e-01
    z[5,0,5]  R583      -1.5273775160312653e-01
    z[5,0,5]  R584      1.3021574914455414e-01
    z[5,0,5]  R585      4.3204712867736816e-01
    z[5,0,5]  R586      -1.8467260897159576e-01
    z[5,0,5]  R587      1.7204004526138306e-01
    z[5,0,5]  R588      -3.0417588353157043e-01
    z[5,0,5]  R589      3.4708064794540405e-01
    z[5,0,5]  R590      3.9442703127861023e-01
    z[5,0,5]  R591      2.9866768047213554e-02
    z[5,0,5]  R592      -2.0194509997963905e-02
    z[5,0,5]  R593      -2.4880267679691315e-01
    z[5,0,5]  R594      -6.2224805355072021e-01
    z[5,0,5]  R595      -4.2498525977134705e-01
    z[5,0,5]  R596      -2.0908093452453613e-01
    z[5,0,5]  R597      -5.1655232906341553e-02
    z[5,0,5]  R598      -2.6204457506537437e-02
    z[5,0,5]  R599      -2.5494593381881714e-01
    z[5,0,5]  R600      -3.1170985102653503e-01
    z[5,0,5]  R601      -2.5660762190818787e-01
    z[5,0,5]  R602      -4.5631803572177887e-02
    z[5,0,5]  R603      -6.5560504794120789e-02
    z[5,0,5]  R604      4.0770357847213745e-01
    z[5,0,5]  R605      -0.0376245491206646
    z[5,0,5]  R606      -2.2379907965660095e-01
    z[5,0,5]  R607      1.3422715663909912e-01
    z[5,0,5]  R608      2.3163928091526031e-01
    z[5,0,5]  R609      7.7741943299770355e-02
    z[5,0,5]  R610      3.0385997891426086e-01
    z[5,0,5]  R611      1.6005125641822815e-01
    z[5,0,5]  R612      5.8769159018993378e-02
    z[5,0,5]  R613      -3.8271471858024597e-01
    z[5,0,5]  R614      -5.6668068282306194e-03
    z[5,0,5]  R615      -2.1352672576904297e-01
    z[5,0,5]  R616      -1.6919773817062378e-01
    z[5,0,5]  R617      -4.8728186637163162e-02
    z[5,0,5]  R618      0.297302782535553
    z[5,0,5]  R619      8.2587942481040955e-02
    z[5,0,5]  R620      6.0453391075134277e-01
    z[5,0,5]  R621      3.1147131323814392e-01
    z[5,0,5]  R622      5.0482434034347534e-01
    z[5,0,6]  R8        1
    z[5,0,6]  R53       -1
    z[5,0,6]  R471      -1
    z[5,0,6]  R472      1
    z[5,0,6]  R473      -1.9783705472946167e-01
    z[5,0,6]  R474      -1.4131994545459747e-01
    z[5,0,6]  R475      -3.5487228631973267e-01
    z[5,0,6]  R476      1.1082220077514648e-01
    z[5,0,6]  R477      1.3181723654270172e-01
    z[5,0,6]  R478      2.8088742494583130e-01
    z[5,0,6]  R479      4.8448985815048218e-01
    z[5,0,6]  R480      -2.1266406774520874e-01
    z[5,0,6]  R481      -2.9523962736129761e-01
    z[5,0,6]  R482      -2.5167265534400940e-01
    z[5,0,6]  R483      -1.7507728934288025e-01
    z[5,0,6]  R484      3.7377485632896423e-01
    z[5,0,6]  R485      -3.6467275023460388e-01
    z[5,0,6]  R486      1.3599184155464172e-01
    z[5,0,6]  R487      -0.0767880454659462
    z[5,0,6]  R488      -1.5330973267555237e-01
    z[5,0,6]  R489      -3.6703673005104065e-01
    z[5,0,6]  R490      -8.1977176666259766e-01
    z[5,0,6]  R491      3.1422293186187744e-01
    z[5,0,6]  R492      3.0217525362968445e-01
    z[5,0,6]  R493      2.6269397139549255e-01
    z[5,0,6]  R494      -3.7492290139198303e-01
    z[5,0,6]  R495      -6.2892287969589233e-01
    z[5,0,6]  R496      0.547385036945343
    z[5,0,6]  R497      -0.338960736989975
    z[5,0,6]  R498      4.3945336341857910e-01
    z[5,0,6]  R499      -7.2387516498565674e-01
    z[5,0,6]  R500      6.9454722106456757e-02
    z[5,0,6]  R501      -2.5666895508766174e-01
    z[5,0,6]  R502      -6.3011479377746582e-01
    z[5,0,6]  R503      -2.5507858395576477e-01
    z[5,0,6]  R504      0.0635906234383583
    z[5,0,6]  R505      2.6841476559638977e-01
    z[5,0,6]  R506      3.9312040805816650e-01
    z[5,0,6]  R507      -6.1730813980102539e-01
    z[5,0,6]  R508      -2.7263706922531128e-01
    z[5,0,6]  R509      8.3916023373603821e-02
    z[5,0,6]  R510      -1.2349230051040649e-01
    z[5,0,6]  R511      -4.1247045993804932e-01
    z[5,0,6]  R512      1.4649763703346252e-01
    z[5,0,6]  R513      3.0656388401985168e-01
    z[5,0,6]  R514      5.0899362564086914e-01
    z[5,0,6]  R515      -3.1880617141723633e-01
    z[5,0,6]  R516      -0.0982373058795929
    z[5,0,6]  R517      -3.0485075712203979e-01
    z[5,0,6]  R518      -3.6884722113609314e-01
    z[5,0,6]  R519      2.6567247509956360e-01
    z[5,0,6]  R520      -1.5768018364906311e-01
    z[5,0,6]  R521      4.6476048231124878e-01
    z[5,0,6]  R522      -2.0062988623976707e-02
    z[5,0,6]  R523      -0.0706803947687149
    z[5,0,6]  R524      -5.4278868436813354e-01
    z[5,0,6]  R525      -2.1640880405902863e-01
    z[5,0,6]  R526      -1.1714392900466919e-01
    z[5,0,6]  R527      -1.2410532683134079e-01
    z[5,0,6]  R528      3.1036806106567383e-01
    z[5,0,6]  R529      1.1200872063636780e-01
    z[5,0,6]  R530      -1.4323492534458637e-02
    z[5,0,6]  R531      -2.8648027777671814e-01
    z[5,0,6]  R532      -6.5235637128353119e-02
    z[5,0,6]  R533      1.5903894603252411e-01
    z[5,0,6]  R534      1.3085895776748657e-01
    z[5,0,6]  R535      -3.6762490868568420e-02
    z[5,0,6]  R536      1.0050827264785767e-01
    z[5,0,6]  R537      2.0909073948860168e-01
    z[5,0,6]  R538      -1.5240733325481415e-01
    z[5,0,6]  R539      6.3973955810070038e-02
    z[5,0,6]  R540      2.5381425023078918e-01
    z[5,0,6]  R541      -2.3153199255466461e-01
    z[5,0,6]  R542      2.1080653369426727e-01
    z[5,0,6]  R543      -2.9442432522773743e-01
    z[5,0,6]  R544      2.2117432951927185e-01
    z[5,0,6]  R545      -3.0406171083450317e-01
    z[5,0,6]  R546      -2.4027535319328308e-01
    z[5,0,6]  R547      -3.4742251038551331e-01
    z[5,0,6]  R548      -0.263701468706131
    z[5,0,6]  R549      -3.1423202157020569e-01
    z[5,0,6]  R550      2.0526324212551117e-01
    z[5,0,6]  R551      -2.7229386568069458e-01
    z[5,0,6]  R552      -6.8887092173099518e-02
    z[5,0,6]  R553      -4.3116754293441772e-01
    z[5,0,6]  R554      3.9251565933227539e-01
    z[5,0,6]  R555      1.1157218366861343e-01
    z[5,0,6]  R556      4.0498995780944824e-01
    z[5,0,6]  R557      -3.6586725711822510e-01
    z[5,0,6]  R558      -2.3382523655891418e-01
    z[5,0,6]  R559      -6.5789207816123962e-02
    z[5,0,6]  R560      -1.5175785124301910e-01
    z[5,0,6]  R561      0.268466979265213
    z[5,0,6]  R562      3.9267953485250473e-02
    z[5,0,6]  R563      4.5309510827064514e-01
    z[5,0,6]  R564      -3.9014050364494324e-01
    z[5,0,6]  R565      -6.7857891321182251e-01
    z[5,0,6]  R566      -5.5796837806701660e-01
    z[5,0,6]  R567      -2.0839789882302284e-02
    z[5,0,6]  R568      -0.642281711101532
    z[5,0,6]  R569      -3.5570108890533447e-01
    z[5,0,6]  R570      -3.3160585165023804e-01
    z[5,0,6]  R571      -1.7723254859447479e-01
    z[5,0,6]  R572      1.1587673425674438e-01
    z[5,0,6]  R573      -3.5515061020851135e-01
    z[5,0,6]  R574      -1.6898328065872192e-01
    z[5,0,6]  R575      2.1050535142421722e-01
    z[5,0,6]  R576      -5.1412478089332581e-02
    z[5,0,6]  R577      3.0915224552154541e-01
    z[5,0,6]  R578      -7.8972905874252319e-02
    z[5,0,6]  R579      3.3543251920491457e-03
    z[5,0,6]  R580      3.7385997176170349e-01
    z[5,0,6]  R581      3.1316413078457117e-03
    z[5,0,6]  R582      3.4802260994911194e-01
    z[5,0,6]  R583      -2.8481009602546692e-01
    z[5,0,6]  R584      -9.0197168290615082e-02
    z[5,0,6]  R585      1.4108563959598541e-01
    z[5,0,6]  R586      2.5622019171714783e-01
    z[5,0,6]  R587      -4.7528293728828430e-01
    z[5,0,6]  R588      -7.7281542122364044e-02
    z[5,0,6]  R589      4.0720129013061523e-01
    z[5,0,6]  R590      -1.1024359613656998e-01
    z[5,0,6]  R591      2.0571835339069366e-02
    z[5,0,6]  R592      5.8386242389678955e-01
    z[5,0,6]  R593      3.2262188196182251e-01
    z[5,0,6]  R594      -0.536336362361908
    z[5,0,6]  R595      7.7055029571056366e-02
    z[5,0,6]  R596      -3.2069790363311768e-01
    z[5,0,6]  R597      3.3036038279533386e-01
    z[5,0,6]  R598      2.7265515923500061e-01
    z[5,0,6]  R599      -1.6381666064262390e-01
    z[5,0,6]  R600      -5.6212997436523438e-01
    z[5,0,6]  R601      6.5752077102661133e-01
    z[5,0,6]  R602      5.4147444665431976e-02
    z[5,0,6]  R603      -6.9317850284278393e-03
    z[5,0,6]  R604      1.5720768272876740e-01
    z[5,0,6]  R605      -4.1065523028373718e-01
    z[5,0,6]  R606      2.3426532745361328e-01
    z[5,0,6]  R607      -2.1056310832500458e-01
    z[5,0,6]  R608      -5.1340326666831970e-02
    z[5,0,6]  R609      2.3974737524986267e-01
    z[5,0,6]  R610      -3.5421723127365112e-01
    z[5,0,6]  R611      -1.3048692047595978e-01
    z[5,0,6]  R612      1.4695557951927185e-01
    z[5,0,6]  R613      -9.6959307789802551e-02
    z[5,0,6]  R614      -1.6584932804107666e-01
    z[5,0,6]  R615      3.2100099325180054e-01
    z[5,0,6]  R616      3.5137336701154709e-02
    z[5,0,6]  R617      -5.9348177909851074e-01
    z[5,0,6]  R618      -1.4876598119735718e-01
    z[5,0,6]  R619      9.9936850368976593e-02
    z[5,0,6]  R620      2.5252452492713928e-01
    z[5,0,6]  R621      3.1249606609344482e-01
    z[5,0,6]  R622      5.6591600179672241e-01
    z[0,6,0]  R2        -1
    z[0,6,0]  R56       1
    z[0,6,0]  R623      -1
    z[0,6,0]  R624      1
    z[0,6,0]  R637      -3.6848965287208557e-01
    z[0,6,0]  R638      7.4506118893623352e-02
    z[0,6,0]  R639      -4.3569985032081604e-01
    z[0,6,0]  R640      5.7732496410608292e-02
    z[0,6,0]  R641      -1.1502807587385178e-01
    z[0,6,0]  R642      -2.4476386606693268e-01
    z[0,6,0]  R643      2.2146110236644745e-01
    z[0,6,0]  R644      6.8804420530796051e-02
    z[0,6,0]  R645      -5.7788819074630737e-02
    z[0,6,0]  R646      1.6723388433456421e-01
    z[0,6,0]  R647      -2.5952938199043274e-01
    z[0,6,0]  R648      -4.5666435360908508e-01
    z[0,6,0]  R649      -2.4800752103328705e-01
    z[0,6,0]  R650      3.2661882042884827e-01
    z[0,6,0]  R651      -3.2229042053222656e-01
    z[0,6,0]  R652      4.2880225181579590e-01
    z[0,6,0]  R653      0.649897575378418
    z[0,6,0]  R654      4.7318503260612488e-01
    z[0,6,0]  R655      -9.9350020289421082e-02
    z[0,6,0]  R656      6.8418934941291809e-02
    z[0,6,0]  R657      -1.8654868006706238e-01
    z[0,6,0]  R658      8.1839069724082947e-02
    z[0,6,0]  R659      -1.3905237615108490e-01
    z[0,6,0]  R660      -3.1382462382316589e-01
    z[0,6,0]  R661      2.4938400089740753e-01
    z[0,6,0]  R662      3.9992492645978928e-02
    z[0,6,0]  R663      -6.3366031646728516e-01
    z[0,6,0]  R664      -1.3271619379520416e-01
    z[0,6,0]  R665      2.2186957299709320e-01
    z[0,6,0]  R666      -3.6631923913955688e-01
    z[0,6,0]  R667      -3.2499887049198151e-02
    z[0,6,0]  R668      -3.2112231850624084e-01
    z[0,6,0]  R669      -1.4242365024983883e-02
    z[0,6,0]  R670      -6.5282315015792847e-01
    z[0,6,0]  R671      -6.7952924966812134e-01
    z[0,6,0]  R672      2.6820677518844604e-01
    z[0,6,0]  R673      -5.1666241884231567e-01
    z[0,6,0]  R674      2.6198202371597290e-01
    z[0,6,0]  R675      6.4260315895080566e-01
    z[0,6,0]  R676      -6.7581719160079956e-01
    z[0,6,0]  R677      -1.8442372977733612e-01
    z[0,6,0]  R678      -3.3599093556404114e-01
    z[0,6,0]  R679      0.606364369392395
    z[0,6,0]  R680      7.7782802283763885e-02
    z[0,6,0]  R681      2.6149311661720276e-01
    z[0,6,0]  R682      2.3175060749053955e-01
    z[0,6,0]  R683      -2.5962504744529724e-01
    z[0,6,0]  R684      5.3548002243041992e-01
    z[0,6,0]  R685      2.5886717438697815e-01
    z[0,6,0]  R686      2.9464939236640930e-01
    z[0,6,0]  R687      2.6722711324691772e-01
    z[0,6,0]  R688      -2.3365625739097595e-01
    z[0,6,0]  R689      0.0499470978975296
    z[0,6,0]  R690      5.3919935226440430e-01
    z[0,6,0]  R691      -4.9655294418334961e-01
    z[0,6,0]  R692      2.09329737117514e-05
    z[0,6,0]  R693      -2.3614892363548279e-01
    z[0,6,0]  R694      -1.4662164449691772e-01
    z[0,6,0]  R695      -8.0243217945098877e-01
    z[0,6,0]  R696      -8.3219474554061890e-01
    z[0,6,0]  R697      -0.347666472196579
    z[0,6,0]  R698      -6.2047320604324341e-01
    z[0,6,0]  R699      -8.2506549358367920e-01
    z[0,6,0]  R700      1.6997131705284119e-01
    z[0,6,0]  R701      -3.8668278604745865e-02
    z[0,6,0]  R702      8.1161573529243469e-02
    z[0,6,0]  R703      -2.1208256483078003e-01
    z[0,6,0]  R704      2.9422247409820557e-01
    z[0,6,0]  R705      -3.4678983688354492e-01
    z[0,6,0]  R706      -8.5808329284191132e-02
    z[0,6,0]  R707      7.6203301548957825e-02
    z[0,6,0]  R708      3.6446052789688110e-01
    z[0,6,0]  R709      3.8955527544021606e-01
    z[0,6,0]  R710      3.9998903870582581e-01
    z[0,6,0]  R711      3.8935866951942444e-01
    z[0,6,0]  R712      3.3282566070556641e-01
    z[0,6,0]  R713      -2.6747867465019226e-01
    z[0,6,0]  R714      -1.6391228139400482e-01
    z[0,6,0]  R715      -1.1296674609184265e-01
    z[0,6,0]  R716      -1.7853356897830963e-01
    z[0,6,0]  R717      -1.9356290996074677e-01
    z[0,6,0]  R718      -3.5254049301147461e-01
    z[0,6,0]  R719      -4.9616798758506775e-01
    z[0,6,0]  R720      -2.5847837328910828e-01
    z[0,6,0]  R721      -3.2877001166343689e-01
    z[0,6,0]  R722      -1.1551152169704437e-01
    z[0,6,0]  R723      -5.9576874971389771e-01
    z[0,6,0]  R724      1.4361375570297241e-01
    z[0,6,0]  R725      -3.2022818922996521e-01
    z[0,6,0]  R726      -1.5970276296138763e-01
    z[0,6,0]  R727      -7.2928392887115479e-01
    z[0,6,0]  R728      -1.5947078168392181e-01
    z[0,6,0]  R729      5.3713631629943848e-01
    z[0,6,0]  R730      1.6378110647201538e-01
    z[0,6,0]  R731      5.4045879840850830e-01
    z[0,6,0]  R732      4.9611806869506836e-02
    z[0,6,0]  R733      5.7317632436752319e-01
    z[0,6,0]  R734      -1.4737339317798615e-01
    z[0,6,0]  R735      0.0769510343670845
    z[0,6,0]  R736      6.4041984081268311e-01
    z[0,6,0]  R737      4.6904885768890381e-01
    z[0,6,0]  R738      -8.2839828729629517e-01
    z[0,6,0]  R739      -4.4422608613967896e-01
    z[0,6,0]  R740      -8.6739659309387207e-05
    z[0,6,0]  R741      5.7017225027084351e-01
    z[0,6,0]  R742      -5.3395098447799683e-01
    z[0,6,0]  R743      2.4247437715530396e-01
    z[0,6,0]  R744      7.3009556531906128e-01
    z[0,6,0]  R745      5.3689581155776978e-01
    z[0,6,0]  R746      6.2699037790298462e-01
    z[0,6,0]  R747      -4.0640029311180115e-01
    z[0,6,0]  R748      -6.3726031780242920e-01
    z[0,6,0]  R749      2.9142358899116516e-01
    z[0,6,0]  R750      2.7225577831268311e-01
    z[0,6,0]  R751      -4.4346490502357483e-01
    z[0,6,0]  R752      4.4495406746864319e-01
    z[0,6,0]  R753      -9.7905941307544708e-02
    z[0,6,0]  R754      -5.1565051078796387e-01
    z[0,6,0]  R755      -0.0890880599617958
    z[0,6,0]  R756      2.0761384069919586e-01
    z[0,6,0]  R757      -1.7567798495292664e-01
    z[0,6,0]  R758      -1.4688614010810852e-01
    z[0,6,0]  R759      -4.5699721574783325e-01
    z[0,6,0]  R760      1.1366516351699829e-01
    z[0,6,0]  R761      0.268271267414093
    z[0,6,0]  R762      5.0068873167037964e-01
    z[0,6,0]  R763      6.4537554979324341e-01
    z[0,6,0]  R764      -4.0659990161657333e-02
    z[0,6,0]  R765      -9.2636190354824066e-02
    z[0,6,0]  R766      -3.9719808101654053e-01
    z[0,6,1]  R3        -1
    z[0,6,1]  R57       1
    z[0,6,1]  R625      -1
    z[0,6,1]  R626      1
    z[0,6,1]  R637      -2.2264370322227478e-01
    z[0,6,1]  R638      -2.1294246613979340e-01
    z[0,6,1]  R639      -1.3836251199245453e-01
    z[0,6,1]  R640      -0.435705304145813
    z[0,6,1]  R641      -2.0301729440689087e-01
    z[0,6,1]  R642      -3.1558337807655334e-01
    z[0,6,1]  R643      -2.7847656607627869e-01
    z[0,6,1]  R644      7.6416528224945068e-01
    z[0,6,1]  R645      -7.8548008203506470e-01
    z[0,6,1]  R646      8.0665594339370728e-01
    z[0,6,1]  R647      -3.3685964345932007e-01
    z[0,6,1]  R648      2.7346780896186829e-01
    z[0,6,1]  R649      2.7014365792274475e-01
    z[0,6,1]  R650      -3.3656972646713257e-01
    z[0,6,1]  R651      -8.8725142180919647e-02
    z[0,6,1]  R652      2.8172996640205383e-01
    z[0,6,1]  R653      3.6521452665328979e-01
    z[0,6,1]  R654      2.9680988192558289e-01
    z[0,6,1]  R655      4.8430547118186951e-01
    z[0,6,1]  R656      -5.7254844903945923e-01
    z[0,6,1]  R657      -7.4589270353317261e-01
    z[0,6,1]  R658      -7.4100983142852783e-01
    z[0,6,1]  R659      -7.2726887464523315e-01
    z[0,6,1]  R660      -6.7125785350799561e-01
    z[0,6,1]  R661      1.5988697111606598e-01
    z[0,6,1]  R662      1.8887175619602203e-01
    z[0,6,1]  R663      -5.4959356784820557e-01
    z[0,6,1]  R664      -6.7379742860794067e-01
    z[0,6,1]  R665      -6.6956084966659546e-01
    z[0,6,1]  R666      -3.9947167038917542e-01
    z[0,6,1]  R667      -5.3852275013923645e-02
    z[0,6,1]  R668      -4.7587621212005615e-01
    z[0,6,1]  R669      -6.2989002466201782e-01
    z[0,6,1]  R670      -6.2229627370834351e-01
    z[0,6,1]  R671      -4.0601894259452820e-01
    z[0,6,1]  R672      7.7640879154205322e-01
    z[0,6,1]  R673      -6.0742509365081787e-01
    z[0,6,1]  R674      -5.3855621814727783e-01
    z[0,6,1]  R675      -4.3175691366195679e-01
    z[0,6,1]  R676      -4.1912712156772614e-02
    z[0,6,1]  R677      -0.726190984249115
    z[0,6,1]  R678      -1.2535278499126434e-01
    z[0,6,1]  R679      -1.4139276742935181e-01
    z[0,6,1]  R680      1.7624922096729279e-01
    z[0,6,1]  R681      -6.6605895757675171e-01
    z[0,6,1]  R682      -6.7663162946701050e-01
    z[0,6,1]  R683      -4.1021513938903809e-01
    z[0,6,1]  R684      2.2009445726871490e-01
    z[0,6,1]  R685      -5.6356501579284668e-01
    z[0,6,1]  R686      -5.3775697946548462e-01
    z[0,6,1]  R687      -8.9600396156311035e-01
    z[0,6,1]  R688      -7.5159054994583130e-01
    z[0,6,1]  R689      -0.684525728225708
    z[0,6,1]  R690      3.8078734278678894e-01
    z[0,6,1]  R691      -6.9227421283721924e-01
    z[0,6,1]  R692      -2.9972484707832336e-01
    z[0,6,1]  R693      -0.756924569606781
    z[0,6,1]  R694      -3.3998182415962219e-01
    z[0,6,1]  R695      1.1340260505676270e-01
    z[0,6,1]  R696      1.5856340527534485e-01
    z[0,6,1]  R697      1.1163343489170074e-01
    z[0,6,1]  R698      -6.9189441204071045e-01
    z[0,6,1]  R699      -1.9321131706237793e-01
    z[0,6,1]  R700      -6.3497972488403320e-01
    z[0,6,1]  R701      -5.7006675004959106e-01
    z[0,6,1]  R702      5.4780155420303345e-01
    z[0,6,1]  R703      6.3868921995162964e-01
    z[0,6,1]  R704      4.1757425665855408e-01
    z[0,6,1]  R705      4.2315801978111267e-01
    z[0,6,1]  R706      6.0656005144119263e-01
    z[0,6,1]  R707      6.1162346601486206e-01
    z[0,6,1]  R708      6.8455594778060913e-01
    z[0,6,1]  R709      5.9001648426055908e-01
    z[0,6,1]  R710      4.4077399373054504e-01
    z[0,6,1]  R711      5.4034572839736938e-01
    z[0,6,1]  R712      8.1180453300476074e-01
    z[0,6,1]  R713      3.6116382479667664e-01
    z[0,6,1]  R714      3.5026282072067261e-01
    z[0,6,1]  R715      3.2761648297309875e-01
    z[0,6,1]  R716      4.8268094658851624e-01
    z[0,6,1]  R717      -9.0482914447784424e-01
    z[0,6,1]  R718      -8.5679125785827637e-01
    z[0,6,1]  R719      -0.746425211429596
    z[0,6,1]  R720      -8.7104260921478271e-01
    z[0,6,1]  R721      -8.7729436159133911e-01
    z[0,6,1]  R722      -6.8070882558822632e-01
    z[0,6,1]  R723      -6.4351511001586914e-01
    z[0,6,1]  R724      -5.6441736221313477e-01
    z[0,6,1]  R725      -6.4501452445983887e-01
    z[0,6,1]  R726      -6.6356188058853149e-01
    z[0,6,1]  R727      5.0011169910430908e-01
    z[0,6,1]  R728      -4.6965089440345764e-01
    z[0,6,1]  R729      -1.2971398234367371e-01
    z[0,6,1]  R730      0.0066000921651721
    z[0,6,1]  R731      -2.2840197384357452e-01
    z[0,6,1]  R732      -2.7539052069187164e-02
    z[0,6,1]  R733      -2.3782984912395477e-01
    z[0,6,1]  R734      5.2312824875116348e-02
    z[0,6,1]  R735      6.6013656556606293e-02
    z[0,6,1]  R736      -2.9741770029067993e-01
    z[0,6,1]  R737      1.8457408249378204e-01
    z[0,6,1]  R738      7.5507219880819321e-03
    z[0,6,1]  R739      2.5539350509643555e-01
    z[0,6,1]  R740      -5.0007468461990356e-01
    z[0,6,1]  R741      3.8062937557697296e-02
    z[0,6,1]  R742      4.4514108449220657e-02
    z[0,6,1]  R743      5.1867380738258362e-02
    z[0,6,1]  R744      -1.7568904161453247e-01
    z[0,6,1]  R745      -8.0612100660800934e-02
    z[0,6,1]  R746      -1.5621571242809296e-01
    z[0,6,1]  R747      -7.9453057050704956e-01
    z[0,6,1]  R748      1.1819142103195190e-01
    z[0,6,1]  R749      5.6701959110796452e-03
    z[0,6,1]  R750      0.311960905790329
    z[0,6,1]  R751      -7.0481783151626587e-01
    z[0,6,1]  R752      -2.2319043055176735e-02
    z[0,6,1]  R753      2.4448089301586151e-01
    z[0,6,1]  R754      -7.0130831003189087e-01
    z[0,6,1]  R755      6.2961626052856445e-01
    z[0,6,1]  R756      -5.6727476418018341e-02
    z[0,6,1]  R757      3.1559771299362183e-01
    z[0,6,1]  R758      -3.6972990632057190e-01
    z[0,6,1]  R759      -8.2249885797500610e-01
    z[0,6,1]  R760      2.7130961418151855e-01
    z[0,6,1]  R761      1.1103488504886627e-01
    z[0,6,1]  R762      -2.3097580671310425e-01
    z[0,6,1]  R763      1.4612478017807007e-01
    z[0,6,1]  R764      -7.4920791387557983e-01
    z[0,6,1]  R765      -5.8395504951477051e-01
    z[0,6,1]  R766      -5.6713259220123291e-01
    z[0,6,2]  R4        -1
    z[0,6,2]  R58       1
    z[0,6,2]  R627      -1
    z[0,6,2]  R628      1
    z[0,6,2]  R637      2.7154350280761719e-01
    z[0,6,2]  R638      4.4143462181091309e-01
    z[0,6,2]  R639      8.3131664991378784e-01
    z[0,6,2]  R640      4.6449339389801025e-01
    z[0,6,2]  R641      8.4280174970626831e-01
    z[0,6,2]  R642      -4.2990061640739441e-01
    z[0,6,2]  R643      6.5445041656494141e-01
    z[0,6,2]  R644      0.463827520608902
    z[0,6,2]  R645      -1.3543221354484558e-01
    z[0,6,2]  R646      -1.3307537138462067e-01
    z[0,6,2]  R647      1.4464181661605835e-01
    z[0,6,2]  R648      2.6798495650291443e-01
    z[0,6,2]  R649      -2.5691960006952286e-02
    z[0,6,2]  R650      7.8006774187088013e-02
    z[0,6,2]  R651      -6.5830785036087036e-01
    z[0,6,2]  R652      1.6097073256969452e-01
    z[0,6,2]  R653      -1.6943724453449249e-01
    z[0,6,2]  R654      1.9703787565231323e-01
    z[0,6,2]  R655      -5.5116581916809082e-01
    z[0,6,2]  R656      -5.4144448041915894e-01
    z[0,6,2]  R657      1.9915345311164856e-01
    z[0,6,2]  R658      1.0369341075420380e-01
    z[0,6,2]  R659      9.9111318588256836e-02
    z[0,6,2]  R660      3.8619977235794067e-01
    z[0,6,2]  R661      -4.6538066864013672e-01
    z[0,6,2]  R662      -1.0131541639566422e-01
    z[0,6,2]  R663      4.2116996645927429e-01
    z[0,6,2]  R664      2.6482033729553223e-01
    z[0,6,2]  R665      -3.6697569489479065e-01
    z[0,6,2]  R666      1.5854367613792419e-01
    z[0,6,2]  R667      2.5470137596130371e-01
    z[0,6,2]  R668      1.0269098728895187e-01
    z[0,6,2]  R669      1.8841113150119781e-01
    z[0,6,2]  R670      -2.0193751156330109e-01
    z[0,6,2]  R671      0.0861692801117897
    z[0,6,2]  R672      -3.4506402909755707e-02
    z[0,6,2]  R673      -1.8633969128131866e-01
    z[0,6,2]  R674      -4.5117273926734924e-01
    z[0,6,2]  R675      5.2752655744552612e-01
    z[0,6,2]  R676      8.5915029048919678e-02
    z[0,6,2]  R677      3.6486014723777771e-01
    z[0,6,2]  R678      -6.0144379734992981e-02
    z[0,6,2]  R679      1.9117403775453568e-02
    z[0,6,2]  R680      -4.5376253128051758e-01
    z[0,6,2]  R681      1.4187838137149811e-01
    z[0,6,2]  R682      -3.0472939833998680e-02
    z[0,6,2]  R683      5.4875838756561279e-01
    z[0,6,2]  R684      9.6292868256568909e-02
    z[0,6,2]  R685      3.1461793184280396e-01
    z[0,6,2]  R686      5.6821137666702271e-01
    z[0,6,2]  R687      -4.0757302194833755e-02
    z[0,6,2]  R688      3.8455966114997864e-01
    z[0,6,2]  R689      -0.590084969997406
    z[0,6,2]  R690      2.5851535797119141e-01
    z[0,6,2]  R691      -0.374023973941803
    z[0,6,2]  R692      7.3741018772125244e-01
    z[0,6,2]  R693      -1.3904018700122833e-01
    z[0,6,2]  R694      7.4900567531585693e-01
    z[0,6,2]  R695      -1.7675158381462097e-01
    z[0,6,2]  R696      1.3139372691512108e-02
    z[0,6,2]  R697      -0.291920006275177
    z[0,6,2]  R698      6.5194942057132721e-02
    z[0,6,2]  R699      -2.0398974418640137e-01
    z[0,6,2]  R700      -0.514629065990448
    z[0,6,2]  R701      0.0444374643266201
    z[0,6,2]  R702      3.4484487771987915e-01
    z[0,6,2]  R703      5.0325065851211548e-01
    z[0,6,2]  R704      -6.8468250334262848e-02
    z[0,6,2]  R705      5.2718663215637207e-01
    z[0,6,2]  R706      1.9963055849075317e-01
    z[0,6,2]  R707      6.5307760238647461e-01
    z[0,6,2]  R708      4.8185011744499207e-01
    z[0,6,2]  R709      5.3949570655822754e-01
    z[0,6,2]  R710      5.0236654281616211e-01
    z[0,6,2]  R711      4.2099103331565857e-01
    z[0,6,2]  R712      3.7018394470214844e-01
    z[0,6,2]  R713      -5.2113026380538940e-01
    z[0,6,2]  R714      -4.8376509547233582e-01
    z[0,6,2]  R715      -7.8418493270874023e-01
    z[0,6,2]  R716      -8.1867128610610962e-01
    z[0,6,2]  R717      1.8444927036762238e-01
    z[0,6,2]  R718      -1.3395757414400578e-02
    z[0,6,2]  R719      1.6011258959770203e-01
    z[0,6,2]  R720      -4.8764474689960480e-02
    z[0,6,2]  R721      -2.2412322461605072e-01
    z[0,6,2]  R722      6.8242150545120239e-01
    z[0,6,2]  R723      -2.8009975329041481e-02
    z[0,6,2]  R724      5.6274402141571045e-01
    z[0,6,2]  R725      6.0653007030487061e-01
    z[0,6,2]  R726      -2.1084873378276825e-01
    z[0,6,2]  R727      -1.5013836324214935e-01
    z[0,6,2]  R728      8.1123101711273193e-01
    z[0,6,2]  R729      -6.7830908298492432e-01
    z[0,6,2]  R730      5.9358769655227661e-01
    z[0,6,2]  R731      -7.2841954231262207e-01
    z[0,6,2]  R732      4.0486451983451843e-01
    z[0,6,2]  R733      -6.5329098701477051e-01
    z[0,6,2]  R734      4.2163950204849243e-01
    z[0,6,2]  R735      1.7427203059196472e-01
    z[0,6,2]  R736      -5.5641597509384155e-01
    z[0,6,2]  R737      0.533997118473053
    z[0,6,2]  R738      -9.4141222536563873e-02
    z[0,6,2]  R739      -3.4328576922416687e-01
    z[0,6,2]  R740      7.7171623706817627e-01
    z[0,6,2]  R741      -6.3166123628616333e-01
    z[0,6,2]  R742      -4.6719151735305786e-01
    z[0,6,2]  R743      7.1479961276054382e-02
    z[0,6,2]  R744      1.4302076399326324e-01
    z[0,6,2]  R745      3.5709220916032791e-02
    z[0,6,2]  R746      -6.6773869097232819e-02
    z[0,6,2]  R747      3.0150640010833740e-01
    z[0,6,2]  R748      5.7649750262498856e-02
    z[0,6,2]  R749      2.9062870144844055e-01
    z[0,6,2]  R750      -1.0436808317899704e-01
    z[0,6,2]  R751      -1.2822796404361725e-01
    z[0,6,2]  R752      1.3974268734455109e-01
    z[0,6,2]  R753      3.3458107709884644e-01
    z[0,6,2]  R754      -2.1774242818355560e-01
    z[0,6,2]  R755      -1.1213681101799011e-01
    z[0,6,2]  R756      -7.5407058000564575e-01
    z[0,6,2]  R757      -5.7629472017288208e-01
    z[0,6,2]  R758      8.7407833337783813e-01
    z[0,6,2]  R759      -3.0261540785431862e-02
    z[0,6,2]  R760      2.0813831686973572e-01
    z[0,6,2]  R761      -9.4895833730697632e-01
    z[0,6,2]  R762      -0.669061005115509
    z[0,6,2]  R763      -1.8745658919215202e-02
    z[0,6,2]  R764      1.6331587731838226e-01
    z[0,6,2]  R765      3.9022177457809448e-02
    z[0,6,2]  R766      -1.0737180709838867e-01
    z[0,6,3]  R5        -1
    z[0,6,3]  R59       1
    z[0,6,3]  R629      -1
    z[0,6,3]  R630      1
    z[0,6,3]  R637      -7.0720982551574707e-01
    z[0,6,3]  R638      -6.9758069515228271e-01
    z[0,6,3]  R639      -2.4126936495304108e-01
    z[0,6,3]  R640      -3.0696383118629456e-01
    z[0,6,3]  R641      -2.0187194645404816e-01
    z[0,6,3]  R642      -6.9268339872360229e-01
    z[0,6,3]  R643      -3.5274004936218262e-01
    z[0,6,3]  R644      3.8146394491195679e-01
    z[0,6,3]  R645      -4.5888921618461609e-01
    z[0,6,3]  R646      4.2126268148422241e-01
    z[0,6,3]  R647      6.2814855575561523e-01
    z[0,6,3]  R648      5.5779051780700684e-01
    z[0,6,3]  R649      5.6700974702835083e-01
    z[0,6,3]  R650      3.4470441937446594e-01
    z[0,6,3]  R651      4.9914455413818359e-01
    z[0,6,3]  R652      4.1553494334220886e-01
    z[0,6,3]  R653      3.6966013908386230e-01
    z[0,6,3]  R654      9.6126310527324677e-02
    z[0,6,3]  R655      5.7133400440216064e-01
    z[0,6,3]  R656      5.9475088119506836e-01
    z[0,6,3]  R657      -7.6354585587978363e-02
    z[0,6,3]  R658      1.8178611993789673e-01
    z[0,6,3]  R659      -4.2014512419700623e-01
    z[0,6,3]  R660      -4.1211771965026855e-01
    z[0,6,3]  R661      6.1982864141464233e-01
    z[0,6,3]  R662      1.6295839846134186e-01
    z[0,6,3]  R663      -1.9765029847621918e-01
    z[0,6,3]  R664      -5.0161361694335938e-01
    z[0,6,3]  R665      -2.3411202430725098e-01
    z[0,6,3]  R666      -6.1734235286712646e-01
    z[0,6,3]  R667      8.9579766988754272e-01
    z[0,6,3]  R668      -7.7933639287948608e-01
    z[0,6,3]  R669      -5.9990060329437256e-01
    z[0,6,3]  R670      8.5244961082935333e-02
    z[0,6,3]  R671      -3.2611685991287231e-01
    z[0,6,3]  R672      4.1469329595565796e-01
    z[0,6,3]  R673      1.8109214305877686e-01
    z[0,6,3]  R674      4.6539118885993958e-01
    z[0,6,3]  R675      1.2050674110651016e-01
    z[0,6,3]  R676      3.9610946178436279e-01
    z[0,6,3]  R677      -3.0852460861206055e-01
    z[0,6,3]  R678      3.4933799505233765e-01
    z[0,6,3]  R679      6.2043029069900513e-01
    z[0,6,3]  R680      7.1201616525650024e-01
    z[0,6,3]  R681      -3.2935658097267151e-01
    z[0,6,3]  R682      4.9749910831451416e-01
    z[0,6,3]  R683      -0.595457911491394
    z[0,6,3]  R684      4.0302717685699463e-01
    z[0,6,3]  R685      1.9613612443208694e-02
    z[0,6,3]  R686      2.4057655036449432e-01
    z[0,6,3]  R687      2.6396757364273071e-01
    z[0,6,3]  R688      -1.8983669579029083e-01
    z[0,6,3]  R689      -5.6722037494182587e-02
    z[0,6,3]  R690      6.0487186908721924e-01
    z[0,6,3]  R691      -1.7714852094650269e-01
    z[0,6,3]  R692      -5.5686396360397339e-01
    z[0,6,3]  R693      1.9345837831497192e-01
    z[0,6,3]  R694      -2.0902976393699646e-01
    z[0,6,3]  R695      4.4478651881217957e-01
    z[0,6,3]  R696      3.3601793646812439e-01
    z[0,6,3]  R697      0.655640721321106
    z[0,6,3]  R698      -2.3139376938343048e-01
    z[0,6,3]  R699      2.8733009099960327e-01
    z[0,6,3]  R700      -1.0046269744634628e-01
    z[0,6,3]  R701      -3.3963614702224731e-01
    z[0,6,3]  R702      6.7690014839172363e-01
    z[0,6,3]  R703      2.1949785947799683e-01
    z[0,6,3]  R704      4.9358087778091431e-01
    z[0,6,3]  R705      4.3031710386276245e-01
    z[0,6,3]  R706      7.8850097954273224e-02
    z[0,6,3]  R707      -1.7735873162746429e-01
    z[0,6,3]  R708      -7.2166711091995239e-02
    z[0,6,3]  R709      -3.6421704292297363e-01
    z[0,6,3]  R710      -1.6406776383519173e-02
    z[0,6,3]  R711      -3.6862000823020935e-02
    z[0,6,3]  R712      7.6529145240783691e-02
    z[0,6,3]  R713      -5.0604915618896484e-01
    z[0,6,3]  R714      -2.8454324603080750e-01
    z[0,6,3]  R715      1.4922952651977539e-01
    z[0,6,3]  R716      2.3323077708482742e-02
    z[0,6,3]  R717      2.2303119301795959e-01
    z[0,6,3]  R718      3.0072297900915146e-02
    z[0,6,3]  R719      -1.5407598018646240e-01
    z[0,6,3]  R720      -1.4522799849510193e-01
    z[0,6,3]  R721      -5.2057329565286636e-02
    z[0,6,3]  R722      4.7645575250498950e-04
    z[0,6,3]  R723      -1.5810810029506683e-02
    z[0,6,3]  R724      1.1137538403272629e-01
    z[0,6,3]  R725      -1.4453551173210144e-01
    z[0,6,3]  R726      -6.6462743282318115e-01
    z[0,6,3]  R727      -1.1206272989511490e-01
    z[0,6,3]  R728      2.1960420906543732e-01
    z[0,6,3]  R729      2.1484570205211639e-01
    z[0,6,3]  R730      6.5667057037353516e-01
    z[0,6,3]  R731      2.0240142941474915e-01
    z[0,6,3]  R732      4.0234780311584473e-01
    z[0,6,3]  R733      -3.4329872578382492e-02
    z[0,6,3]  R734      2.8709346055984497e-01
    z[0,6,3]  R735      8.9333295822143555e-01
    z[0,6,3]  R736      2.7548578381538391e-01
    z[0,6,3]  R737      -1.5493296086788177e-01
    z[0,6,3]  R738      3.1071117520332336e-01
    z[0,6,3]  R739      4.4686415791511536e-01
    z[0,6,3]  R740      -1.8663607537746429e-01
    z[0,6,3]  R741      3.4587290883064270e-01
    z[0,6,3]  R742      1.8540048599243164e-01
    z[0,6,3]  R743      4.5564615726470947e-01
    z[0,6,3]  R744      3.4619012475013733e-01
    z[0,6,3]  R745      6.1684612184762955e-02
    z[0,6,3]  R746      2.7708551287651062e-01
    z[0,6,3]  R747      2.7882652357220650e-02
    z[0,6,3]  R748      2.9548335075378418e-01
    z[0,6,3]  R749      6.4322352409362793e-01
    z[0,6,3]  R750      0.0772358700633049
    z[0,6,3]  R751      4.0807634592056274e-01
    z[0,6,3]  R752      4.4087588787078857e-01
    z[0,6,3]  R753      8.4481775760650635e-01
    z[0,6,3]  R754      -1.0306950658559799e-01
    z[0,6,3]  R755      5.0641906261444092e-01
    z[0,6,3]  R756      2.6382520794868469e-01
    z[0,6,3]  R757      -3.1905156373977661e-01
    z[0,6,3]  R758      -1.2970322370529175e-01
    z[0,6,3]  R759      2.6195693016052246e-01
    z[0,6,3]  R760      0.744918942451477
    z[0,6,3]  R761      1.3488547876477242e-02
    z[0,6,3]  R762      1.7731359601020813e-01
    z[0,6,3]  R763      4.5670741796493530e-01
    z[0,6,3]  R764      -0.512614369392395
    z[0,6,3]  R765      -4.7568336129188538e-01
    z[0,6,3]  R766      3.3361083269119263e-01
    z[0,6,4]  R6        -1
    z[0,6,4]  R60       1
    z[0,6,4]  R631      -1
    z[0,6,4]  R632      1
    z[0,6,4]  R637      1.2259913235902786e-01
    z[0,6,4]  R638      2.6392656564712524e-01
    z[0,6,4]  R639      4.6463202685117722e-02
    z[0,6,4]  R640      -3.5254594683647156e-01
    z[0,6,4]  R641      -2.4449007213115692e-01
    z[0,6,4]  R642      2.8654780983924866e-01
    z[0,6,4]  R643      -5.7972751557826996e-02
    z[0,6,4]  R644      -4.0461938828229904e-02
    z[0,6,4]  R645      -2.2709010541439056e-01
    z[0,6,4]  R646      -0.331691712141037
    z[0,6,4]  R647      9.4646655023097992e-02
    z[0,6,4]  R648      -4.7965649515390396e-02
    z[0,6,4]  R649      5.3363703191280365e-02
    z[0,6,4]  R650      1.8360137939453125e-01
    z[0,6,4]  R651      -1.9633080065250397e-01
    z[0,6,4]  R652      -1.4350116252899170e-01
    z[0,6,4]  R653      5.9857752174139023e-02
    z[0,6,4]  R654      1.1935921013355255e-01
    z[0,6,4]  R655      7.4213206768035889e-02
    z[0,6,4]  R656      6.1546668410301208e-02
    z[0,6,4]  R657      -6.4590275287628174e-02
    z[0,6,4]  R658      -3.2296633720397949e-01
    z[0,6,4]  R659      -1.5243685804307461e-02
    z[0,6,4]  R660      3.8030825555324554e-02
    z[0,6,4]  R661      3.1678044795989990e-01
    z[0,6,4]  R662      -7.3413648642599583e-03
    z[0,6,4]  R663      -2.7928823605179787e-02
    z[0,6,4]  R664      -2.2214733064174652e-01
    z[0,6,4]  R665      2.4055325984954834e-01
    z[0,6,4]  R666      7.1519844233989716e-02
    z[0,6,4]  R667      1.5579383075237274e-01
    z[0,6,4]  R668      1.6558946669101715e-01
    z[0,6,4]  R669      -3.2959397882223129e-02
    z[0,6,4]  R670      1.9690386950969696e-01
    z[0,6,4]  R671      6.4184583723545074e-02
    z[0,6,4]  R672      2.3151208460330963e-01
    z[0,6,4]  R673      -1.0148895531892776e-01
    z[0,6,4]  R674      2.3119370639324188e-01
    z[0,6,4]  R675      3.2638299465179443e-01
    z[0,6,4]  R676      1.8954484164714813e-01
    z[0,6,4]  R677      -2.1056285500526428e-01
    z[0,6,4]  R678      2.6625737547874451e-01
    z[0,6,4]  R679      -2.0119942724704742e-01
    z[0,6,4]  R680      -3.2164674997329712e-01
    z[0,6,4]  R681      4.9756950139999390e-01
    z[0,6,4]  R682      -4.0620166063308716e-01
    z[0,6,4]  R683      -0.129534512758255
    z[0,6,4]  R684      2.8277760744094849e-01
    z[0,6,4]  R685      1.3353681564331055e-01
    z[0,6,4]  R686      -4.8810219764709473e-01
    z[0,6,4]  R687      2.2378638386726379e-01
    z[0,6,4]  R688      -7.5205512344837189e-02
    z[0,6,4]  R689      8.6364768445491791e-02
    z[0,6,4]  R690      1.6309115290641785e-01
    z[0,6,4]  R691      -2.0140078663825989e-01
    z[0,6,4]  R692      1.1269237147644162e-03
    z[0,6,4]  R693      -5.0101685523986816e-01
    z[0,6,4]  R694      -2.0102441310882568e-01
    z[0,6,4]  R695      2.6743793487548828e-01
    z[0,6,4]  R696      3.7970918416976929e-01
    z[0,6,4]  R697      4.4239366054534912e-01
    z[0,6,4]  R698      2.2575096786022186e-01
    z[0,6,4]  R699      9.5553815364837646e-02
    z[0,6,4]  R700      -5.1294457912445068e-01
    z[0,6,4]  R701      -4.4900581240653992e-01
    z[0,6,4]  R702      7.5459964573383331e-02
    z[0,6,4]  R703      4.7838100790977478e-01
    z[0,6,4]  R704      2.4804225564002991e-01
    z[0,6,4]  R705      -2.0714102685451508e-01
    z[0,6,4]  R706      -0.0595281757414341
    z[0,6,4]  R707      3.0931377410888672e-01
    z[0,6,4]  R708      -1.0533689707517624e-01
    z[0,6,4]  R709      -3.9524812251329422e-02
    z[0,6,4]  R710      -4.2555180191993713e-01
    z[0,6,4]  R711      1.2045098841190338e-01
    z[0,6,4]  R712      1.0959753394126892e-01
    z[0,6,4]  R713      -5.9787888079881668e-02
    z[0,6,4]  R714      3.0749875307083130e-01
    z[0,6,4]  R715      5.5037878453731537e-02
    z[0,6,4]  R716      -1.9136065244674683e-01
    z[0,6,4]  R717      -2.1240387856960297e-01
    z[0,6,4]  R718      -1.2740857899188995e-01
    z[0,6,4]  R719      2.3785457015037537e-01
    z[0,6,4]  R720      -3.0441511422395706e-02
    z[0,6,4]  R721      -1.1305811256170273e-01
    z[0,6,4]  R722      -1.8227986991405487e-01
    z[0,6,4]  R723      4.3938314914703369e-01
    z[0,6,4]  R724      -3.6281594634056091e-01
    z[0,6,4]  R725      1.8025094270706177e-01
    z[0,6,4]  R726      -7.6935626566410065e-02
    z[0,6,4]  R727      3.2748109102249146e-01
    z[0,6,4]  R728      1.4197234809398651e-01
    z[0,6,4]  R729      -9.6101216971874237e-02
    z[0,6,4]  R730      -1.2907008826732635e-01
    z[0,6,4]  R731      -1.4035013318061829e-01
    z[0,6,4]  R732      -1.7884099856019020e-02
    z[0,6,4]  R733      3.0120092630386353e-01
    z[0,6,4]  R734      4.3370419740676880e-01
    z[0,6,4]  R735      -6.7534692585468292e-02
    z[0,6,4]  R736      6.7070230841636658e-02
    z[0,6,4]  R737      -4.2729938030242920e-01
    z[0,6,4]  R738      3.8238272070884705e-01
    z[0,6,4]  R739      1.5390522778034210e-01
    z[0,6,4]  R740      -2.1807695925235748e-01
    z[0,6,4]  R741      3.8307970762252808e-01
    z[0,6,4]  R742      5.5730640888214111e-01
    z[0,6,4]  R743      -1.3726758956909180e-01
    z[0,6,4]  R744      3.5945403575897217e-01
    z[0,6,4]  R745      5.9789609909057617e-01
    z[0,6,4]  R746      3.2487982511520386e-01
    z[0,6,4]  R747      1.8357923254370689e-02
    z[0,6,4]  R748      1.6997136175632477e-02
    z[0,6,4]  R749      2.2530054673552513e-02
    z[0,6,4]  R750      7.1387737989425659e-02
    z[0,6,4]  R751      5.3474036976695061e-03
    z[0,6,4]  R752      -3.0325773358345032e-01
    z[0,6,4]  R753      2.4515953660011292e-01
    z[0,6,4]  R754      3.9190939068794250e-01
    z[0,6,4]  R755      4.7103419899940491e-01
    z[0,6,4]  R756      3.1757593154907227e-02
    z[0,6,4]  R757      5.3931981325149536e-01
    z[0,6,4]  R758      8.1775300204753876e-02
    z[0,6,4]  R759      2.9924826696515083e-02
    z[0,6,4]  R760      4.9881532788276672e-02
    z[0,6,4]  R761      7.0591926574707031e-02
    z[0,6,4]  R762      3.9975631237030029e-01
    z[0,6,4]  R763      -3.8714587688446045e-01
    z[0,6,4]  R764      -3.4964978694915771e-01
    z[0,6,4]  R765      -3.7415459752082825e-01
    z[0,6,4]  R766      3.8348725438117981e-01
    z[0,6,5]  R7        -1
    z[0,6,5]  R61       1
    z[0,6,5]  R633      -1
    z[0,6,5]  R634      1
    z[0,6,5]  R637      -1.9956852495670319e-01
    z[0,6,5]  R638      2.0951206982135773e-01
    z[0,6,5]  R639      -1.6466975212097168e-01
    z[0,6,5]  R640      -4.5666342973709106e-01
    z[0,6,5]  R641      -2.9176460579037666e-02
    z[0,6,5]  R642      1.9770933687686920e-01
    z[0,6,5]  R643      5.5945134162902832e-01
    z[0,6,5]  R644      -1.6124244034290314e-01
    z[0,6,5]  R645      1.6466896235942841e-01
    z[0,6,5]  R646      -1.2085715681314468e-01
    z[0,6,5]  R647      -4.3522989749908447e-01
    z[0,6,5]  R648      -4.2333969473838806e-01
    z[0,6,5]  R649      -2.8290903568267822e-01
    z[0,6,5]  R650      -5.5686312913894653e-01
    z[0,6,5]  R651      -4.0836516022682190e-01
    z[0,6,5]  R652      -3.2412597537040710e-01
    z[0,6,5]  R653      -3.8572993874549866e-01
    z[0,6,5]  R654      -7.1814113855361938e-01
    z[0,6,5]  R655      -2.9740974307060242e-01
    z[0,6,5]  R656      5.8317895978689194e-02
    z[0,6,5]  R657      -4.8274996876716614e-01
    z[0,6,5]  R658      5.1724809408187866e-01
    z[0,6,5]  R659      -4.6995180845260620e-01
    z[0,6,5]  R660      3.5755565762519836e-01
    z[0,6,5]  R661      -3.3992937207221985e-01
    z[0,6,5]  R662      -9.5896673202514648e-01
    z[0,6,5]  R663      0.281389981508255
    z[0,6,5]  R664      -1.3235056400299072e-01
    z[0,6,5]  R665      -5.0508117675781250e-01
    z[0,6,5]  R666      -4.1683351993560791e-01
    z[0,6,5]  R667      -1.5273775160312653e-01
    z[0,6,5]  R668      1.3021574914455414e-01
    z[0,6,5]  R669      4.3204712867736816e-01
    z[0,6,5]  R670      -1.8467260897159576e-01
    z[0,6,5]  R671      1.7204004526138306e-01
    z[0,6,5]  R672      -3.0417588353157043e-01
    z[0,6,5]  R673      3.4708064794540405e-01
    z[0,6,5]  R674      3.9442703127861023e-01
    z[0,6,5]  R675      2.9866768047213554e-02
    z[0,6,5]  R676      -2.0194509997963905e-02
    z[0,6,5]  R677      -2.4880267679691315e-01
    z[0,6,5]  R678      -6.2224805355072021e-01
    z[0,6,5]  R679      -4.2498525977134705e-01
    z[0,6,5]  R680      -2.0908093452453613e-01
    z[0,6,5]  R681      -5.1655232906341553e-02
    z[0,6,5]  R682      -2.6204457506537437e-02
    z[0,6,5]  R683      -2.5494593381881714e-01
    z[0,6,5]  R684      -3.1170985102653503e-01
    z[0,6,5]  R685      -2.5660762190818787e-01
    z[0,6,5]  R686      -4.5631803572177887e-02
    z[0,6,5]  R687      -6.5560504794120789e-02
    z[0,6,5]  R688      4.0770357847213745e-01
    z[0,6,5]  R689      -0.0376245491206646
    z[0,6,5]  R690      -2.2379907965660095e-01
    z[0,6,5]  R691      1.3422715663909912e-01
    z[0,6,5]  R692      2.3163928091526031e-01
    z[0,6,5]  R693      7.7741943299770355e-02
    z[0,6,5]  R694      3.0385997891426086e-01
    z[0,6,5]  R695      1.6005125641822815e-01
    z[0,6,5]  R696      5.8769159018993378e-02
    z[0,6,5]  R697      -3.8271471858024597e-01
    z[0,6,5]  R698      -5.6668068282306194e-03
    z[0,6,5]  R699      -2.1352672576904297e-01
    z[0,6,5]  R700      -1.6919773817062378e-01
    z[0,6,5]  R701      -4.8728186637163162e-02
    z[0,6,5]  R702      0.297302782535553
    z[0,6,5]  R703      8.2587942481040955e-02
    z[0,6,5]  R704      6.0453391075134277e-01
    z[0,6,5]  R705      3.1147131323814392e-01
    z[0,6,5]  R706      5.0482434034347534e-01
    z[0,6,5]  R707      -1.4910748600959778e-01
    z[0,6,5]  R708      2.3642964661121368e-01
    z[0,6,5]  R709      2.6192072033882141e-01
    z[0,6,5]  R710      -2.4893982335925102e-02
    z[0,6,5]  R711      1.1403822153806686e-01
    z[0,6,5]  R712      -2.0856025815010071e-01
    z[0,6,5]  R713      4.7178804874420166e-01
    z[0,6,5]  R714      6.6391664743423462e-01
    z[0,6,5]  R715      3.8924831151962280e-01
    z[0,6,5]  R716      1.2152110785245895e-01
    z[0,6,5]  R717      2.1437183022499084e-02
    z[0,6,5]  R718      1.3909088075160980e-01
    z[0,6,5]  R719      1.1812205612659454e-01
    z[0,6,5]  R720      3.7348988652229309e-01
    z[0,6,5]  R721      -2.3512698709964752e-01
    z[0,6,5]  R722      -4.9178179353475571e-02
    z[0,6,5]  R723      -1.8666283786296844e-01
    z[0,6,5]  R724      4.4221282005310059e-01
    z[0,6,5]  R725      -2.4498255550861359e-01
    z[0,6,5]  R726      -1.5540733933448792e-01
    z[0,6,5]  R727      -1.5384857356548309e-01
    z[0,6,5]  R728      1.3855701684951782e-01
    z[0,6,5]  R729      -2.4059610068798065e-01
    z[0,6,5]  R730      -2.6186150312423706e-01
    z[0,6,5]  R731      -2.3836867511272430e-01
    z[0,6,5]  R732      7.9744279384613037e-01
    z[0,6,5]  R733      -2.9433470964431763e-01
    z[0,6,5]  R734      7.2514837980270386e-01
    z[0,6,5]  R735      3.7951439619064331e-01
    z[0,6,5]  R736      -3.2458725571632385e-01
    z[0,6,5]  R737      -4.4477206468582153e-01
    z[0,6,5]  R738      -8.5610244423151016e-03
    z[0,6,5]  R739      4.2908897995948792e-01
    z[0,6,5]  R740      0.0865989699959755
    z[0,6,5]  R741      -6.7275352776050568e-02
    z[0,6,5]  R742      -3.2819861173629761e-01
    z[0,6,5]  R743      7.9767984151840210e-01
    z[0,6,5]  R744      3.5359352827072144e-01
    z[0,6,5]  R745      5.2157509326934814e-01
    z[0,6,5]  R746      6.2777698040008545e-01
    z[0,6,5]  R747      -1.5226955711841583e-01
    z[0,6,5]  R748      2.4852935969829559e-01
    z[0,6,5]  R749      6.4453983306884766e-01
    z[0,6,5]  R750      8.9482986927032471e-01
    z[0,6,5]  R751      -2.9989114403724670e-01
    z[0,6,5]  R752      6.8360632658004761e-01
    z[0,6,5]  R753      2.0597076416015625e-01
    z[0,6,5]  R754      5.3643468767404556e-02
    z[0,6,5]  R755      3.2350286841392517e-01
    z[0,6,5]  R756      7.4796602129936218e-02
    z[0,6,5]  R757      -8.3849526941776276e-02
    z[0,6,5]  R758      -1.0466530919075012e-01
    z[0,6,5]  R759      -1.0526506602764130e-01
    z[0,6,5]  R760      5.5378687381744385e-01
    z[0,6,5]  R761      -4.9198679625988007e-02
    z[0,6,5]  R762      2.0749524235725403e-01
    z[0,6,5]  R763      4.2804643511772156e-01
    z[0,6,5]  R764      3.4910753369331360e-02
    z[0,6,5]  R765      -3.4486436843872070e-01
    z[0,6,5]  R766      -1.7774419859051704e-02
    z[0,6,6]  R8        -1
    z[0,6,6]  R62       1
    z[0,6,6]  R635      -1
    z[0,6,6]  R636      1
    z[0,6,6]  R637      -4.3116754293441772e-01
    z[0,6,6]  R638      3.9251565933227539e-01
    z[0,6,6]  R639      1.1157218366861343e-01
    z[0,6,6]  R640      4.0498995780944824e-01
    z[0,6,6]  R641      -3.6586725711822510e-01
    z[0,6,6]  R642      -2.3382523655891418e-01
    z[0,6,6]  R643      -6.5789207816123962e-02
    z[0,6,6]  R644      -1.5175785124301910e-01
    z[0,6,6]  R645      0.268466979265213
    z[0,6,6]  R646      3.9267953485250473e-02
    z[0,6,6]  R647      4.5309510827064514e-01
    z[0,6,6]  R648      -3.9014050364494324e-01
    z[0,6,6]  R649      -6.7857891321182251e-01
    z[0,6,6]  R650      -5.5796837806701660e-01
    z[0,6,6]  R651      -2.0839789882302284e-02
    z[0,6,6]  R652      -0.642281711101532
    z[0,6,6]  R653      -3.5570108890533447e-01
    z[0,6,6]  R654      -3.3160585165023804e-01
    z[0,6,6]  R655      -1.7723254859447479e-01
    z[0,6,6]  R656      1.1587673425674438e-01
    z[0,6,6]  R657      -3.5515061020851135e-01
    z[0,6,6]  R658      -1.6898328065872192e-01
    z[0,6,6]  R659      2.1050535142421722e-01
    z[0,6,6]  R660      -5.1412478089332581e-02
    z[0,6,6]  R661      3.0915224552154541e-01
    z[0,6,6]  R662      -7.8972905874252319e-02
    z[0,6,6]  R663      3.3543251920491457e-03
    z[0,6,6]  R664      3.7385997176170349e-01
    z[0,6,6]  R665      3.1316413078457117e-03
    z[0,6,6]  R666      3.4802260994911194e-01
    z[0,6,6]  R667      -2.8481009602546692e-01
    z[0,6,6]  R668      -9.0197168290615082e-02
    z[0,6,6]  R669      1.4108563959598541e-01
    z[0,6,6]  R670      2.5622019171714783e-01
    z[0,6,6]  R671      -4.7528293728828430e-01
    z[0,6,6]  R672      -7.7281542122364044e-02
    z[0,6,6]  R673      4.0720129013061523e-01
    z[0,6,6]  R674      -1.1024359613656998e-01
    z[0,6,6]  R675      2.0571835339069366e-02
    z[0,6,6]  R676      5.8386242389678955e-01
    z[0,6,6]  R677      3.2262188196182251e-01
    z[0,6,6]  R678      -0.536336362361908
    z[0,6,6]  R679      7.7055029571056366e-02
    z[0,6,6]  R680      -3.2069790363311768e-01
    z[0,6,6]  R681      3.3036038279533386e-01
    z[0,6,6]  R682      2.7265515923500061e-01
    z[0,6,6]  R683      -1.6381666064262390e-01
    z[0,6,6]  R684      -5.6212997436523438e-01
    z[0,6,6]  R685      6.5752077102661133e-01
    z[0,6,6]  R686      5.4147444665431976e-02
    z[0,6,6]  R687      -6.9317850284278393e-03
    z[0,6,6]  R688      1.5720768272876740e-01
    z[0,6,6]  R689      -4.1065523028373718e-01
    z[0,6,6]  R690      2.3426532745361328e-01
    z[0,6,6]  R691      -2.1056310832500458e-01
    z[0,6,6]  R692      -5.1340326666831970e-02
    z[0,6,6]  R693      2.3974737524986267e-01
    z[0,6,6]  R694      -3.5421723127365112e-01
    z[0,6,6]  R695      -1.3048692047595978e-01
    z[0,6,6]  R696      1.4695557951927185e-01
    z[0,6,6]  R697      -9.6959307789802551e-02
    z[0,6,6]  R698      -1.6584932804107666e-01
    z[0,6,6]  R699      3.2100099325180054e-01
    z[0,6,6]  R700      3.5137336701154709e-02
    z[0,6,6]  R701      -5.9348177909851074e-01
    z[0,6,6]  R702      -1.4876598119735718e-01
    z[0,6,6]  R703      9.9936850368976593e-02
    z[0,6,6]  R704      2.5252452492713928e-01
    z[0,6,6]  R705      3.1249606609344482e-01
    z[0,6,6]  R706      5.6591600179672241e-01
    z[0,6,6]  R707      -2.1032159030437469e-01
    z[0,6,6]  R708      -3.0687007308006287e-01
    z[0,6,6]  R709      -7.9074859619140625e-02
    z[0,6,6]  R710      -0.459751695394516
    z[0,6,6]  R711      5.9187906980514526e-01
    z[0,6,6]  R712      1.7832185328006744e-01
    z[0,6,6]  R713      -2.1022546291351318e-01
    z[0,6,6]  R714      1.0699690319597721e-02
    z[0,6,6]  R715      -2.9689574241638184e-01
    z[0,6,6]  R716      1.1398231983184814e-01
    z[0,6,6]  R717      1.2032502889633179e-01
    z[0,6,6]  R718      -3.2397669553756714e-01
    z[0,6,6]  R719      -2.7706235647201538e-01
    z[0,6,6]  R720      1.0287478566169739e-01
    z[0,6,6]  R721      3.5452261567115784e-02
    z[0,6,6]  R722      -1.4815139770507812e-01
    z[0,6,6]  R723      -4.4864334166049957e-02
    z[0,6,6]  R724      6.7343883216381073e-02
    z[0,6,6]  R725      -1.1576295830309391e-02
    z[0,6,6]  R726      1.3387800753116608e-01
    z[0,6,6]  R727      2.2807975113391876e-01
    z[0,6,6]  R728      9.1220222413539886e-02
    z[0,6,6]  R729      -3.4824568033218384e-01
    z[0,6,6]  R730      3.2301548123359680e-01
    z[0,6,6]  R731      0.0875079482793808
    z[0,6,6]  R732      -1.8640391528606415e-01
    z[0,6,6]  R733      0.0978948324918747
    z[0,6,6]  R734      3.7448275834321976e-02
    z[0,6,6]  R735      1.1275637149810791e-01
    z[0,6,6]  R736      -7.7837914228439331e-02
    z[0,6,6]  R737      2.3740540444850922e-01
    z[0,6,6]  R738      0.249008908867836
    z[0,6,6]  R739      4.6054357290267944e-01
    z[0,6,6]  R740      -2.5394740700721741e-01
    z[0,6,6]  R741      5.9621725231409073e-02
    z[0,6,6]  R742      -2.0486259460449219e-01
    z[0,6,6]  R743      2.6581510901451111e-01
    z[0,6,6]  R744      -2.0385244488716125e-01
    z[0,6,6]  R745      -2.6578944921493530e-01
    z[0,6,6]  R746      3.9920575916767120e-02
    z[0,6,6]  R747      -2.9724302887916565e-01
    z[0,6,6]  R748      -6.5363639593124390e-01
    z[0,6,6]  R749      -0.0299916360527277
    z[0,6,6]  R750      7.6696924865245819e-02
    z[0,6,6]  R751      -1.8340897560119629e-01
    z[0,6,6]  R752      1.6833055019378662e-01
    z[0,6,6]  R753      -4.9545396119356155e-02
    z[0,6,6]  R754      1.6663007438182831e-01
    z[0,6,6]  R755      -9.1901179403066635e-03
    z[0,6,6]  R756      0.555742084980011
    z[0,6,6]  R757      3.7111893296241760e-01
    z[0,6,6]  R758      -2.0795795321464539e-01
    z[0,6,6]  R759      -1.8203240633010864e-01
    z[0,6,6]  R760      0.0779573991894722
    z[0,6,6]  R761      8.7144345045089722e-02
    z[0,6,6]  R762      -1.1840105056762695e-01
    z[0,6,6]  R763      1.4177146553993225e-01
    z[0,6,6]  R764      -1.5528991818428040e-01
    z[0,6,6]  R765      -4.0459185838699341e-01
    z[0,6,6]  R766      5.0039076805114746e-01
    z[6,0,0]  R2        1
    z[6,0,0]  R56       -1
    z[6,0,0]  R767      -1
    z[6,0,0]  R768      1
    z[6,0,0]  R781      7.6203301548957825e-02
    z[6,0,0]  R782      3.6446052789688110e-01
    z[6,0,0]  R783      3.8955527544021606e-01
    z[6,0,0]  R784      3.9998903870582581e-01
    z[6,0,0]  R785      3.8935866951942444e-01
    z[6,0,0]  R786      3.3282566070556641e-01
    z[6,0,0]  R787      -2.6747867465019226e-01
    z[6,0,0]  R788      -1.6391228139400482e-01
    z[6,0,0]  R789      -1.1296674609184265e-01
    z[6,0,0]  R790      -1.7853356897830963e-01
    z[6,0,0]  R791      -1.9356290996074677e-01
    z[6,0,0]  R792      -3.5254049301147461e-01
    z[6,0,0]  R793      -4.9616798758506775e-01
    z[6,0,0]  R794      -2.5847837328910828e-01
    z[6,0,0]  R795      -3.2877001166343689e-01
    z[6,0,0]  R796      -1.1551152169704437e-01
    z[6,0,0]  R797      -5.9576874971389771e-01
    z[6,0,0]  R798      1.4361375570297241e-01
    z[6,0,0]  R799      -3.2022818922996521e-01
    z[6,0,0]  R800      -1.5970276296138763e-01
    z[6,0,0]  R801      -7.2928392887115479e-01
    z[6,0,0]  R802      -1.5947078168392181e-01
    z[6,0,0]  R803      5.3713631629943848e-01
    z[6,0,0]  R804      1.6378110647201538e-01
    z[6,0,0]  R805      5.4045879840850830e-01
    z[6,0,0]  R806      4.9611806869506836e-02
    z[6,0,0]  R807      5.7317632436752319e-01
    z[6,0,0]  R808      -1.4737339317798615e-01
    z[6,0,0]  R809      0.0769510343670845
    z[6,0,0]  R810      6.4041984081268311e-01
    z[6,0,0]  R811      4.6904885768890381e-01
    z[6,0,0]  R812      -8.2839828729629517e-01
    z[6,0,0]  R813      -4.4422608613967896e-01
    z[6,0,0]  R814      -8.6739659309387207e-05
    z[6,0,0]  R815      5.7017225027084351e-01
    z[6,0,0]  R816      -5.3395098447799683e-01
    z[6,0,0]  R817      2.4247437715530396e-01
    z[6,0,0]  R818      7.3009556531906128e-01
    z[6,0,0]  R819      5.3689581155776978e-01
    z[6,0,0]  R820      6.2699037790298462e-01
    z[6,0,0]  R821      -4.0640029311180115e-01
    z[6,0,0]  R822      -6.3726031780242920e-01
    z[6,0,0]  R823      2.9142358899116516e-01
    z[6,0,0]  R824      2.7225577831268311e-01
    z[6,0,0]  R825      -4.4346490502357483e-01
    z[6,0,0]  R826      4.4495406746864319e-01
    z[6,0,0]  R827      -9.7905941307544708e-02
    z[6,0,0]  R828      -5.1565051078796387e-01
    z[6,0,0]  R829      -0.0890880599617958
    z[6,0,0]  R830      2.0761384069919586e-01
    z[6,0,0]  R831      -1.7567798495292664e-01
    z[6,0,0]  R832      -1.4688614010810852e-01
    z[6,0,0]  R833      -4.5699721574783325e-01
    z[6,0,0]  R834      1.1366516351699829e-01
    z[6,0,0]  R835      0.268271267414093
    z[6,0,0]  R836      5.0068873167037964e-01
    z[6,0,0]  R837      6.4537554979324341e-01
    z[6,0,0]  R838      -4.0659990161657333e-02
    z[6,0,0]  R839      -9.2636190354824066e-02
    z[6,0,0]  R840      -3.9719808101654053e-01
    z[6,0,0]  R841      -3.6848965287208557e-01
    z[6,0,0]  R842      7.4506118893623352e-02
    z[6,0,0]  R843      -4.3569985032081604e-01
    z[6,0,0]  R844      5.7732496410608292e-02
    z[6,0,0]  R845      -1.1502807587385178e-01
    z[6,0,0]  R846      -2.4476386606693268e-01
    z[6,0,0]  R847      2.2146110236644745e-01
    z[6,0,0]  R848      6.8804420530796051e-02
    z[6,0,0]  R849      -5.7788819074630737e-02
    z[6,0,0]  R850      1.6723388433456421e-01
    z[6,0,0]  R851      -2.5952938199043274e-01
    z[6,0,0]  R852      -4.5666435360908508e-01
    z[6,0,0]  R853      -2.4800752103328705e-01
    z[6,0,0]  R854      3.2661882042884827e-01
    z[6,0,0]  R855      -3.2229042053222656e-01
    z[6,0,0]  R856      4.2880225181579590e-01
    z[6,0,0]  R857      0.649897575378418
    z[6,0,0]  R858      4.7318503260612488e-01
    z[6,0,0]  R859      -9.9350020289421082e-02
    z[6,0,0]  R860      6.8418934941291809e-02
    z[6,0,0]  R861      -1.8654868006706238e-01
    z[6,0,0]  R862      8.1839069724082947e-02
    z[6,0,0]  R863      -1.3905237615108490e-01
    z[6,0,0]  R864      -3.1382462382316589e-01
    z[6,0,0]  R865      2.4938400089740753e-01
    z[6,0,0]  R866      3.9992492645978928e-02
    z[6,0,0]  R867      -6.3366031646728516e-01
    z[6,0,0]  R868      -1.3271619379520416e-01
    z[6,0,0]  R869      2.2186957299709320e-01
    z[6,0,0]  R870      -3.6631923913955688e-01
    z[6,0,0]  R871      -3.2499887049198151e-02
    z[6,0,0]  R872      -3.2112231850624084e-01
    z[6,0,0]  R873      -1.4242365024983883e-02
    z[6,0,0]  R874      -6.5282315015792847e-01
    z[6,0,0]  R875      -6.7952924966812134e-01
    z[6,0,0]  R876      2.6820677518844604e-01
    z[6,0,0]  R877      -5.1666241884231567e-01
    z[6,0,0]  R878      2.6198202371597290e-01
    z[6,0,0]  R879      6.4260315895080566e-01
    z[6,0,0]  R880      -6.7581719160079956e-01
    z[6,0,0]  R881      -1.8442372977733612e-01
    z[6,0,0]  R882      -3.3599093556404114e-01
    z[6,0,0]  R883      0.606364369392395
    z[6,0,0]  R884      7.7782802283763885e-02
    z[6,0,0]  R885      2.6149311661720276e-01
    z[6,0,0]  R886      2.3175060749053955e-01
    z[6,0,0]  R887      -2.5962504744529724e-01
    z[6,0,0]  R888      5.3548002243041992e-01
    z[6,0,0]  R889      2.5886717438697815e-01
    z[6,0,0]  R890      2.9464939236640930e-01
    z[6,0,0]  R891      2.6722711324691772e-01
    z[6,0,0]  R892      -2.3365625739097595e-01
    z[6,0,0]  R893      0.0499470978975296
    z[6,0,0]  R894      5.3919935226440430e-01
    z[6,0,0]  R895      -4.9655294418334961e-01
    z[6,0,0]  R896      2.09329737117514e-05
    z[6,0,0]  R897      -2.3614892363548279e-01
    z[6,0,0]  R898      -1.4662164449691772e-01
    z[6,0,0]  R899      -8.0243217945098877e-01
    z[6,0,0]  R900      -8.3219474554061890e-01
    z[6,0,0]  R901      -0.347666472196579
    z[6,0,0]  R902      -6.2047320604324341e-01
    z[6,0,0]  R903      -8.2506549358367920e-01
    z[6,0,0]  R904      1.6997131705284119e-01
    z[6,0,0]  R905      -3.8668278604745865e-02
    z[6,0,0]  R906      8.1161573529243469e-02
    z[6,0,0]  R907      -2.1208256483078003e-01
    z[6,0,0]  R908      2.9422247409820557e-01
    z[6,0,0]  R909      -3.4678983688354492e-01
    z[6,0,0]  R910      -8.5808329284191132e-02
    z[6,0,1]  R3        1
    z[6,0,1]  R57       -1
    z[6,0,1]  R769      -1
    z[6,0,1]  R770      1
    z[6,0,1]  R781      6.1162346601486206e-01
    z[6,0,1]  R782      6.8455594778060913e-01
    z[6,0,1]  R783      5.9001648426055908e-01
    z[6,0,1]  R784      4.4077399373054504e-01
    z[6,0,1]  R785      5.4034572839736938e-01
    z[6,0,1]  R786      8.1180453300476074e-01
    z[6,0,1]  R787      3.6116382479667664e-01
    z[6,0,1]  R788      3.5026282072067261e-01
    z[6,0,1]  R789      3.2761648297309875e-01
    z[6,0,1]  R790      4.8268094658851624e-01
    z[6,0,1]  R791      -9.0482914447784424e-01
    z[6,0,1]  R792      -8.5679125785827637e-01
    z[6,0,1]  R793      -0.746425211429596
    z[6,0,1]  R794      -8.7104260921478271e-01
    z[6,0,1]  R795      -8.7729436159133911e-01
    z[6,0,1]  R796      -6.8070882558822632e-01
    z[6,0,1]  R797      -6.4351511001586914e-01
    z[6,0,1]  R798      -5.6441736221313477e-01
    z[6,0,1]  R799      -6.4501452445983887e-01
    z[6,0,1]  R800      -6.6356188058853149e-01
    z[6,0,1]  R801      5.0011169910430908e-01
    z[6,0,1]  R802      -4.6965089440345764e-01
    z[6,0,1]  R803      -1.2971398234367371e-01
    z[6,0,1]  R804      0.0066000921651721
    z[6,0,1]  R805      -2.2840197384357452e-01
    z[6,0,1]  R806      -2.7539052069187164e-02
    z[6,0,1]  R807      -2.3782984912395477e-01
    z[6,0,1]  R808      5.2312824875116348e-02
    z[6,0,1]  R809      6.6013656556606293e-02
    z[6,0,1]  R810      -2.9741770029067993e-01
    z[6,0,1]  R811      1.8457408249378204e-01
    z[6,0,1]  R812      7.5507219880819321e-03
    z[6,0,1]  R813      2.5539350509643555e-01
    z[6,0,1]  R814      -5.0007468461990356e-01
    z[6,0,1]  R815      3.8062937557697296e-02
    z[6,0,1]  R816      4.4514108449220657e-02
    z[6,0,1]  R817      5.1867380738258362e-02
    z[6,0,1]  R818      -1.7568904161453247e-01
    z[6,0,1]  R819      -8.0612100660800934e-02
    z[6,0,1]  R820      -1.5621571242809296e-01
    z[6,0,1]  R821      -7.9453057050704956e-01
    z[6,0,1]  R822      1.1819142103195190e-01
    z[6,0,1]  R823      5.6701959110796452e-03
    z[6,0,1]  R824      0.311960905790329
    z[6,0,1]  R825      -7.0481783151626587e-01
    z[6,0,1]  R826      -2.2319043055176735e-02
    z[6,0,1]  R827      2.4448089301586151e-01
    z[6,0,1]  R828      -7.0130831003189087e-01
    z[6,0,1]  R829      6.2961626052856445e-01
    z[6,0,1]  R830      -5.6727476418018341e-02
    z[6,0,1]  R831      3.1559771299362183e-01
    z[6,0,1]  R832      -3.6972990632057190e-01
    z[6,0,1]  R833      -8.2249885797500610e-01
    z[6,0,1]  R834      2.7130961418151855e-01
    z[6,0,1]  R835      1.1103488504886627e-01
    z[6,0,1]  R836      -2.3097580671310425e-01
    z[6,0,1]  R837      1.4612478017807007e-01
    z[6,0,1]  R838      -7.4920791387557983e-01
    z[6,0,1]  R839      -5.8395504951477051e-01
    z[6,0,1]  R840      -5.6713259220123291e-01
    z[6,0,1]  R841      -2.2264370322227478e-01
    z[6,0,1]  R842      -2.1294246613979340e-01
    z[6,0,1]  R843      -1.3836251199245453e-01
    z[6,0,1]  R844      -0.435705304145813
    z[6,0,1]  R845      -2.0301729440689087e-01
    z[6,0,1]  R846      -3.1558337807655334e-01
    z[6,0,1]  R847      -2.7847656607627869e-01
    z[6,0,1]  R848      7.6416528224945068e-01
    z[6,0,1]  R849      -7.8548008203506470e-01
    z[6,0,1]  R850      8.0665594339370728e-01
    z[6,0,1]  R851      -3.3685964345932007e-01
    z[6,0,1]  R852      2.7346780896186829e-01
    z[6,0,1]  R853      2.7014365792274475e-01
    z[6,0,1]  R854      -3.3656972646713257e-01
    z[6,0,1]  R855      -8.8725142180919647e-02
    z[6,0,1]  R856      2.8172996640205383e-01
    z[6,0,1]  R857      3.6521452665328979e-01
    z[6,0,1]  R858      2.9680988192558289e-01
    z[6,0,1]  R859      4.8430547118186951e-01
    z[6,0,1]  R860      -5.7254844903945923e-01
    z[6,0,1]  R861      -7.4589270353317261e-01
    z[6,0,1]  R862      -7.4100983142852783e-01
    z[6,0,1]  R863      -7.2726887464523315e-01
    z[6,0,1]  R864      -6.7125785350799561e-01
    z[6,0,1]  R865      1.5988697111606598e-01
    z[6,0,1]  R866      1.8887175619602203e-01
    z[6,0,1]  R867      -5.4959356784820557e-01
    z[6,0,1]  R868      -6.7379742860794067e-01
    z[6,0,1]  R869      -6.6956084966659546e-01
    z[6,0,1]  R870      -3.9947167038917542e-01
    z[6,0,1]  R871      -5.3852275013923645e-02
    z[6,0,1]  R872      -4.7587621212005615e-01
    z[6,0,1]  R873      -6.2989002466201782e-01
    z[6,0,1]  R874      -6.2229627370834351e-01
    z[6,0,1]  R875      -4.0601894259452820e-01
    z[6,0,1]  R876      7.7640879154205322e-01
    z[6,0,1]  R877      -6.0742509365081787e-01
    z[6,0,1]  R878      -5.3855621814727783e-01
    z[6,0,1]  R879      -4.3175691366195679e-01
    z[6,0,1]  R880      -4.1912712156772614e-02
    z[6,0,1]  R881      -0.726190984249115
    z[6,0,1]  R882      -1.2535278499126434e-01
    z[6,0,1]  R883      -1.4139276742935181e-01
    z[6,0,1]  R884      1.7624922096729279e-01
    z[6,0,1]  R885      -6.6605895757675171e-01
    z[6,0,1]  R886      -6.7663162946701050e-01
    z[6,0,1]  R887      -4.1021513938903809e-01
    z[6,0,1]  R888      2.2009445726871490e-01
    z[6,0,1]  R889      -5.6356501579284668e-01
    z[6,0,1]  R890      -5.3775697946548462e-01
    z[6,0,1]  R891      -8.9600396156311035e-01
    z[6,0,1]  R892      -7.5159054994583130e-01
    z[6,0,1]  R893      -0.684525728225708
    z[6,0,1]  R894      3.8078734278678894e-01
    z[6,0,1]  R895      -6.9227421283721924e-01
    z[6,0,1]  R896      -2.9972484707832336e-01
    z[6,0,1]  R897      -0.756924569606781
    z[6,0,1]  R898      -3.3998182415962219e-01
    z[6,0,1]  R899      1.1340260505676270e-01
    z[6,0,1]  R900      1.5856340527534485e-01
    z[6,0,1]  R901      1.1163343489170074e-01
    z[6,0,1]  R902      -6.9189441204071045e-01
    z[6,0,1]  R903      -1.9321131706237793e-01
    z[6,0,1]  R904      -6.3497972488403320e-01
    z[6,0,1]  R905      -5.7006675004959106e-01
    z[6,0,1]  R906      5.4780155420303345e-01
    z[6,0,1]  R907      6.3868921995162964e-01
    z[6,0,1]  R908      4.1757425665855408e-01
    z[6,0,1]  R909      4.2315801978111267e-01
    z[6,0,1]  R910      6.0656005144119263e-01
    z[6,0,2]  R4        1
    z[6,0,2]  R58       -1
    z[6,0,2]  R771      -1
    z[6,0,2]  R772      1
    z[6,0,2]  R781      6.5307760238647461e-01
    z[6,0,2]  R782      4.8185011744499207e-01
    z[6,0,2]  R783      5.3949570655822754e-01
    z[6,0,2]  R784      5.0236654281616211e-01
    z[6,0,2]  R785      4.2099103331565857e-01
    z[6,0,2]  R786      3.7018394470214844e-01
    z[6,0,2]  R787      -5.2113026380538940e-01
    z[6,0,2]  R788      -4.8376509547233582e-01
    z[6,0,2]  R789      -7.8418493270874023e-01
    z[6,0,2]  R790      -8.1867128610610962e-01
    z[6,0,2]  R791      1.8444927036762238e-01
    z[6,0,2]  R792      -1.3395757414400578e-02
    z[6,0,2]  R793      1.6011258959770203e-01
    z[6,0,2]  R794      -4.8764474689960480e-02
    z[6,0,2]  R795      -2.2412322461605072e-01
    z[6,0,2]  R796      6.8242150545120239e-01
    z[6,0,2]  R797      -2.8009975329041481e-02
    z[6,0,2]  R798      5.6274402141571045e-01
    z[6,0,2]  R799      6.0653007030487061e-01
    z[6,0,2]  R800      -2.1084873378276825e-01
    z[6,0,2]  R801      -1.5013836324214935e-01
    z[6,0,2]  R802      8.1123101711273193e-01
    z[6,0,2]  R803      -6.7830908298492432e-01
    z[6,0,2]  R804      5.9358769655227661e-01
    z[6,0,2]  R805      -7.2841954231262207e-01
    z[6,0,2]  R806      4.0486451983451843e-01
    z[6,0,2]  R807      -6.5329098701477051e-01
    z[6,0,2]  R808      4.2163950204849243e-01
    z[6,0,2]  R809      1.7427203059196472e-01
    z[6,0,2]  R810      -5.5641597509384155e-01
    z[6,0,2]  R811      0.533997118473053
    z[6,0,2]  R812      -9.4141222536563873e-02
    z[6,0,2]  R813      -3.4328576922416687e-01
    z[6,0,2]  R814      7.7171623706817627e-01
    z[6,0,2]  R815      -6.3166123628616333e-01
    z[6,0,2]  R816      -4.6719151735305786e-01
    z[6,0,2]  R817      7.1479961276054382e-02
    z[6,0,2]  R818      1.4302076399326324e-01
    z[6,0,2]  R819      3.5709220916032791e-02
    z[6,0,2]  R820      -6.6773869097232819e-02
    z[6,0,2]  R821      3.0150640010833740e-01
    z[6,0,2]  R822      5.7649750262498856e-02
    z[6,0,2]  R823      2.9062870144844055e-01
    z[6,0,2]  R824      -1.0436808317899704e-01
    z[6,0,2]  R825      -1.2822796404361725e-01
    z[6,0,2]  R826      1.3974268734455109e-01
    z[6,0,2]  R827      3.3458107709884644e-01
    z[6,0,2]  R828      -2.1774242818355560e-01
    z[6,0,2]  R829      -1.1213681101799011e-01
    z[6,0,2]  R830      -7.5407058000564575e-01
    z[6,0,2]  R831      -5.7629472017288208e-01
    z[6,0,2]  R832      8.7407833337783813e-01
    z[6,0,2]  R833      -3.0261540785431862e-02
    z[6,0,2]  R834      2.0813831686973572e-01
    z[6,0,2]  R835      -9.4895833730697632e-01
    z[6,0,2]  R836      -0.669061005115509
    z[6,0,2]  R837      -1.8745658919215202e-02
    z[6,0,2]  R838      1.6331587731838226e-01
    z[6,0,2]  R839      3.9022177457809448e-02
    z[6,0,2]  R840      -1.0737180709838867e-01
    z[6,0,2]  R841      2.7154350280761719e-01
    z[6,0,2]  R842      4.4143462181091309e-01
    z[6,0,2]  R843      8.3131664991378784e-01
    z[6,0,2]  R844      4.6449339389801025e-01
    z[6,0,2]  R845      8.4280174970626831e-01
    z[6,0,2]  R846      -4.2990061640739441e-01
    z[6,0,2]  R847      6.5445041656494141e-01
    z[6,0,2]  R848      0.463827520608902
    z[6,0,2]  R849      -1.3543221354484558e-01
    z[6,0,2]  R850      -1.3307537138462067e-01
    z[6,0,2]  R851      1.4464181661605835e-01
    z[6,0,2]  R852      2.6798495650291443e-01
    z[6,0,2]  R853      -2.5691960006952286e-02
    z[6,0,2]  R854      7.8006774187088013e-02
    z[6,0,2]  R855      -6.5830785036087036e-01
    z[6,0,2]  R856      1.6097073256969452e-01
    z[6,0,2]  R857      -1.6943724453449249e-01
    z[6,0,2]  R858      1.9703787565231323e-01
    z[6,0,2]  R859      -5.5116581916809082e-01
    z[6,0,2]  R860      -5.4144448041915894e-01
    z[6,0,2]  R861      1.9915345311164856e-01
    z[6,0,2]  R862      1.0369341075420380e-01
    z[6,0,2]  R863      9.9111318588256836e-02
    z[6,0,2]  R864      3.8619977235794067e-01
    z[6,0,2]  R865      -4.6538066864013672e-01
    z[6,0,2]  R866      -1.0131541639566422e-01
    z[6,0,2]  R867      4.2116996645927429e-01
    z[6,0,2]  R868      2.6482033729553223e-01
    z[6,0,2]  R869      -3.6697569489479065e-01
    z[6,0,2]  R870      1.5854367613792419e-01
    z[6,0,2]  R871      2.5470137596130371e-01
    z[6,0,2]  R872      1.0269098728895187e-01
    z[6,0,2]  R873      1.8841113150119781e-01
    z[6,0,2]  R874      -2.0193751156330109e-01
    z[6,0,2]  R875      0.0861692801117897
    z[6,0,2]  R876      -3.4506402909755707e-02
    z[6,0,2]  R877      -1.8633969128131866e-01
    z[6,0,2]  R878      -4.5117273926734924e-01
    z[6,0,2]  R879      5.2752655744552612e-01
    z[6,0,2]  R880      8.5915029048919678e-02
    z[6,0,2]  R881      3.6486014723777771e-01
    z[6,0,2]  R882      -6.0144379734992981e-02
    z[6,0,2]  R883      1.9117403775453568e-02
    z[6,0,2]  R884      -4.5376253128051758e-01
    z[6,0,2]  R885      1.4187838137149811e-01
    z[6,0,2]  R886      -3.0472939833998680e-02
    z[6,0,2]  R887      5.4875838756561279e-01
    z[6,0,2]  R888      9.6292868256568909e-02
    z[6,0,2]  R889      3.1461793184280396e-01
    z[6,0,2]  R890      5.6821137666702271e-01
    z[6,0,2]  R891      -4.0757302194833755e-02
    z[6,0,2]  R892      3.8455966114997864e-01
    z[6,0,2]  R893      -0.590084969997406
    z[6,0,2]  R894      2.5851535797119141e-01
    z[6,0,2]  R895      -0.374023973941803
    z[6,0,2]  R896      7.3741018772125244e-01
    z[6,0,2]  R897      -1.3904018700122833e-01
    z[6,0,2]  R898      7.4900567531585693e-01
    z[6,0,2]  R899      -1.7675158381462097e-01
    z[6,0,2]  R900      1.3139372691512108e-02
    z[6,0,2]  R901      -0.291920006275177
    z[6,0,2]  R902      6.5194942057132721e-02
    z[6,0,2]  R903      -2.0398974418640137e-01
    z[6,0,2]  R904      -0.514629065990448
    z[6,0,2]  R905      0.0444374643266201
    z[6,0,2]  R906      3.4484487771987915e-01
    z[6,0,2]  R907      5.0325065851211548e-01
    z[6,0,2]  R908      -6.8468250334262848e-02
    z[6,0,2]  R909      5.2718663215637207e-01
    z[6,0,2]  R910      1.9963055849075317e-01
    z[6,0,3]  R5        1
    z[6,0,3]  R59       -1
    z[6,0,3]  R773      -1
    z[6,0,3]  R774      1
    z[6,0,3]  R781      -1.7735873162746429e-01
    z[6,0,3]  R782      -7.2166711091995239e-02
    z[6,0,3]  R783      -3.6421704292297363e-01
    z[6,0,3]  R784      -1.6406776383519173e-02
    z[6,0,3]  R785      -3.6862000823020935e-02
    z[6,0,3]  R786      7.6529145240783691e-02
    z[6,0,3]  R787      -5.0604915618896484e-01
    z[6,0,3]  R788      -2.8454324603080750e-01
    z[6,0,3]  R789      1.4922952651977539e-01
    z[6,0,3]  R790      2.3323077708482742e-02
    z[6,0,3]  R791      2.2303119301795959e-01
    z[6,0,3]  R792      3.0072297900915146e-02
    z[6,0,3]  R793      -1.5407598018646240e-01
    z[6,0,3]  R794      -1.4522799849510193e-01
    z[6,0,3]  R795      -5.2057329565286636e-02
    z[6,0,3]  R796      4.7645575250498950e-04
    z[6,0,3]  R797      -1.5810810029506683e-02
    z[6,0,3]  R798      1.1137538403272629e-01
    z[6,0,3]  R799      -1.4453551173210144e-01
    z[6,0,3]  R800      -6.6462743282318115e-01
    z[6,0,3]  R801      -1.1206272989511490e-01
    z[6,0,3]  R802      2.1960420906543732e-01
    z[6,0,3]  R803      2.1484570205211639e-01
    z[6,0,3]  R804      6.5667057037353516e-01
    z[6,0,3]  R805      2.0240142941474915e-01
    z[6,0,3]  R806      4.0234780311584473e-01
    z[6,0,3]  R807      -3.4329872578382492e-02
    z[6,0,3]  R808      2.8709346055984497e-01
    z[6,0,3]  R809      8.9333295822143555e-01
    z[6,0,3]  R810      2.7548578381538391e-01
    z[6,0,3]  R811      -1.5493296086788177e-01
    z[6,0,3]  R812      3.1071117520332336e-01
    z[6,0,3]  R813      4.4686415791511536e-01
    z[6,0,3]  R814      -1.8663607537746429e-01
    z[6,0,3]  R815      3.4587290883064270e-01
    z[6,0,3]  R816      1.8540048599243164e-01
    z[6,0,3]  R817      4.5564615726470947e-01
    z[6,0,3]  R818      3.4619012475013733e-01
    z[6,0,3]  R819      6.1684612184762955e-02
    z[6,0,3]  R820      2.7708551287651062e-01
    z[6,0,3]  R821      2.7882652357220650e-02
    z[6,0,3]  R822      2.9548335075378418e-01
    z[6,0,3]  R823      6.4322352409362793e-01
    z[6,0,3]  R824      0.0772358700633049
    z[6,0,3]  R825      4.0807634592056274e-01
    z[6,0,3]  R826      4.4087588787078857e-01
    z[6,0,3]  R827      8.4481775760650635e-01
    z[6,0,3]  R828      -1.0306950658559799e-01
    z[6,0,3]  R829      5.0641906261444092e-01
    z[6,0,3]  R830      2.6382520794868469e-01
    z[6,0,3]  R831      -3.1905156373977661e-01
    z[6,0,3]  R832      -1.2970322370529175e-01
    z[6,0,3]  R833      2.6195693016052246e-01
    z[6,0,3]  R834      0.744918942451477
    z[6,0,3]  R835      1.3488547876477242e-02
    z[6,0,3]  R836      1.7731359601020813e-01
    z[6,0,3]  R837      4.5670741796493530e-01
    z[6,0,3]  R838      -0.512614369392395
    z[6,0,3]  R839      -4.7568336129188538e-01
    z[6,0,3]  R840      3.3361083269119263e-01
    z[6,0,3]  R841      -7.0720982551574707e-01
    z[6,0,3]  R842      -6.9758069515228271e-01
    z[6,0,3]  R843      -2.4126936495304108e-01
    z[6,0,3]  R844      -3.0696383118629456e-01
    z[6,0,3]  R845      -2.0187194645404816e-01
    z[6,0,3]  R846      -6.9268339872360229e-01
    z[6,0,3]  R847      -3.5274004936218262e-01
    z[6,0,3]  R848      3.8146394491195679e-01
    z[6,0,3]  R849      -4.5888921618461609e-01
    z[6,0,3]  R850      4.2126268148422241e-01
    z[6,0,3]  R851      6.2814855575561523e-01
    z[6,0,3]  R852      5.5779051780700684e-01
    z[6,0,3]  R853      5.6700974702835083e-01
    z[6,0,3]  R854      3.4470441937446594e-01
    z[6,0,3]  R855      4.9914455413818359e-01
    z[6,0,3]  R856      4.1553494334220886e-01
    z[6,0,3]  R857      3.6966013908386230e-01
    z[6,0,3]  R858      9.6126310527324677e-02
    z[6,0,3]  R859      5.7133400440216064e-01
    z[6,0,3]  R860      5.9475088119506836e-01
    z[6,0,3]  R861      -7.6354585587978363e-02
    z[6,0,3]  R862      1.8178611993789673e-01
    z[6,0,3]  R863      -4.2014512419700623e-01
    z[6,0,3]  R864      -4.1211771965026855e-01
    z[6,0,3]  R865      6.1982864141464233e-01
    z[6,0,3]  R866      1.6295839846134186e-01
    z[6,0,3]  R867      -1.9765029847621918e-01
    z[6,0,3]  R868      -5.0161361694335938e-01
    z[6,0,3]  R869      -2.3411202430725098e-01
    z[6,0,3]  R870      -6.1734235286712646e-01
    z[6,0,3]  R871      8.9579766988754272e-01
    z[6,0,3]  R872      -7.7933639287948608e-01
    z[6,0,3]  R873      -5.9990060329437256e-01
    z[6,0,3]  R874      8.5244961082935333e-02
    z[6,0,3]  R875      -3.2611685991287231e-01
    z[6,0,3]  R876      4.1469329595565796e-01
    z[6,0,3]  R877      1.8109214305877686e-01
    z[6,0,3]  R878      4.6539118885993958e-01
    z[6,0,3]  R879      1.2050674110651016e-01
    z[6,0,3]  R880      3.9610946178436279e-01
    z[6,0,3]  R881      -3.0852460861206055e-01
    z[6,0,3]  R882      3.4933799505233765e-01
    z[6,0,3]  R883      6.2043029069900513e-01
    z[6,0,3]  R884      7.1201616525650024e-01
    z[6,0,3]  R885      -3.2935658097267151e-01
    z[6,0,3]  R886      4.9749910831451416e-01
    z[6,0,3]  R887      -0.595457911491394
    z[6,0,3]  R888      4.0302717685699463e-01
    z[6,0,3]  R889      1.9613612443208694e-02
    z[6,0,3]  R890      2.4057655036449432e-01
    z[6,0,3]  R891      2.6396757364273071e-01
    z[6,0,3]  R892      -1.8983669579029083e-01
    z[6,0,3]  R893      -5.6722037494182587e-02
    z[6,0,3]  R894      6.0487186908721924e-01
    z[6,0,3]  R895      -1.7714852094650269e-01
    z[6,0,3]  R896      -5.5686396360397339e-01
    z[6,0,3]  R897      1.9345837831497192e-01
    z[6,0,3]  R898      -2.0902976393699646e-01
    z[6,0,3]  R899      4.4478651881217957e-01
    z[6,0,3]  R900      3.3601793646812439e-01
    z[6,0,3]  R901      0.655640721321106
    z[6,0,3]  R902      -2.3139376938343048e-01
    z[6,0,3]  R903      2.8733009099960327e-01
    z[6,0,3]  R904      -1.0046269744634628e-01
    z[6,0,3]  R905      -3.3963614702224731e-01
    z[6,0,3]  R906      6.7690014839172363e-01
    z[6,0,3]  R907      2.1949785947799683e-01
    z[6,0,3]  R908      4.9358087778091431e-01
    z[6,0,3]  R909      4.3031710386276245e-01
    z[6,0,3]  R910      7.8850097954273224e-02
    z[6,0,4]  R6        1
    z[6,0,4]  R60       -1
    z[6,0,4]  R775      -1
    z[6,0,4]  R776      1
    z[6,0,4]  R781      3.0931377410888672e-01
    z[6,0,4]  R782      -1.0533689707517624e-01
    z[6,0,4]  R783      -3.9524812251329422e-02
    z[6,0,4]  R784      -4.2555180191993713e-01
    z[6,0,4]  R785      1.2045098841190338e-01
    z[6,0,4]  R786      1.0959753394126892e-01
    z[6,0,4]  R787      -5.9787888079881668e-02
    z[6,0,4]  R788      3.0749875307083130e-01
    z[6,0,4]  R789      5.5037878453731537e-02
    z[6,0,4]  R790      -1.9136065244674683e-01
    z[6,0,4]  R791      -2.1240387856960297e-01
    z[6,0,4]  R792      -1.2740857899188995e-01
    z[6,0,4]  R793      2.3785457015037537e-01
    z[6,0,4]  R794      -3.0441511422395706e-02
    z[6,0,4]  R795      -1.1305811256170273e-01
    z[6,0,4]  R796      -1.8227986991405487e-01
    z[6,0,4]  R797      4.3938314914703369e-01
    z[6,0,4]  R798      -3.6281594634056091e-01
    z[6,0,4]  R799      1.8025094270706177e-01
    z[6,0,4]  R800      -7.6935626566410065e-02
    z[6,0,4]  R801      3.2748109102249146e-01
    z[6,0,4]  R802      1.4197234809398651e-01
    z[6,0,4]  R803      -9.6101216971874237e-02
    z[6,0,4]  R804      -1.2907008826732635e-01
    z[6,0,4]  R805      -1.4035013318061829e-01
    z[6,0,4]  R806      -1.7884099856019020e-02
    z[6,0,4]  R807      3.0120092630386353e-01
    z[6,0,4]  R808      4.3370419740676880e-01
    z[6,0,4]  R809      -6.7534692585468292e-02
    z[6,0,4]  R810      6.7070230841636658e-02
    z[6,0,4]  R811      -4.2729938030242920e-01
    z[6,0,4]  R812      3.8238272070884705e-01
    z[6,0,4]  R813      1.5390522778034210e-01
    z[6,0,4]  R814      -2.1807695925235748e-01
    z[6,0,4]  R815      3.8307970762252808e-01
    z[6,0,4]  R816      5.5730640888214111e-01
    z[6,0,4]  R817      -1.3726758956909180e-01
    z[6,0,4]  R818      3.5945403575897217e-01
    z[6,0,4]  R819      5.9789609909057617e-01
    z[6,0,4]  R820      3.2487982511520386e-01
    z[6,0,4]  R821      1.8357923254370689e-02
    z[6,0,4]  R822      1.6997136175632477e-02
    z[6,0,4]  R823      2.2530054673552513e-02
    z[6,0,4]  R824      7.1387737989425659e-02
    z[6,0,4]  R825      5.3474036976695061e-03
    z[6,0,4]  R826      -3.0325773358345032e-01
    z[6,0,4]  R827      2.4515953660011292e-01
    z[6,0,4]  R828      3.9190939068794250e-01
    z[6,0,4]  R829      4.7103419899940491e-01
    z[6,0,4]  R830      3.1757593154907227e-02
    z[6,0,4]  R831      5.3931981325149536e-01
    z[6,0,4]  R832      8.1775300204753876e-02
    z[6,0,4]  R833      2.9924826696515083e-02
    z[6,0,4]  R834      4.9881532788276672e-02
    z[6,0,4]  R835      7.0591926574707031e-02
    z[6,0,4]  R836      3.9975631237030029e-01
    z[6,0,4]  R837      -3.8714587688446045e-01
    z[6,0,4]  R838      -3.4964978694915771e-01
    z[6,0,4]  R839      -3.7415459752082825e-01
    z[6,0,4]  R840      3.8348725438117981e-01
    z[6,0,4]  R841      1.2259913235902786e-01
    z[6,0,4]  R842      2.6392656564712524e-01
    z[6,0,4]  R843      4.6463202685117722e-02
    z[6,0,4]  R844      -3.5254594683647156e-01
    z[6,0,4]  R845      -2.4449007213115692e-01
    z[6,0,4]  R846      2.8654780983924866e-01
    z[6,0,4]  R847      -5.7972751557826996e-02
    z[6,0,4]  R848      -4.0461938828229904e-02
    z[6,0,4]  R849      -2.2709010541439056e-01
    z[6,0,4]  R850      -0.331691712141037
    z[6,0,4]  R851      9.4646655023097992e-02
    z[6,0,4]  R852      -4.7965649515390396e-02
    z[6,0,4]  R853      5.3363703191280365e-02
    z[6,0,4]  R854      1.8360137939453125e-01
    z[6,0,4]  R855      -1.9633080065250397e-01
    z[6,0,4]  R856      -1.4350116252899170e-01
    z[6,0,4]  R857      5.9857752174139023e-02
    z[6,0,4]  R858      1.1935921013355255e-01
    z[6,0,4]  R859      7.4213206768035889e-02
    z[6,0,4]  R860      6.1546668410301208e-02
    z[6,0,4]  R861      -6.4590275287628174e-02
    z[6,0,4]  R862      -3.2296633720397949e-01
    z[6,0,4]  R863      -1.5243685804307461e-02
    z[6,0,4]  R864      3.8030825555324554e-02
    z[6,0,4]  R865      3.1678044795989990e-01
    z[6,0,4]  R866      -7.3413648642599583e-03
    z[6,0,4]  R867      -2.7928823605179787e-02
    z[6,0,4]  R868      -2.2214733064174652e-01
    z[6,0,4]  R869      2.4055325984954834e-01
    z[6,0,4]  R870      7.1519844233989716e-02
    z[6,0,4]  R871      1.5579383075237274e-01
    z[6,0,4]  R872      1.6558946669101715e-01
    z[6,0,4]  R873      -3.2959397882223129e-02
    z[6,0,4]  R874      1.9690386950969696e-01
    z[6,0,4]  R875      6.4184583723545074e-02
    z[6,0,4]  R876      2.3151208460330963e-01
    z[6,0,4]  R877      -1.0148895531892776e-01
    z[6,0,4]  R878      2.3119370639324188e-01
    z[6,0,4]  R879      3.2638299465179443e-01
    z[6,0,4]  R880      1.8954484164714813e-01
    z[6,0,4]  R881      -2.1056285500526428e-01
    z[6,0,4]  R882      2.6625737547874451e-01
    z[6,0,4]  R883      -2.0119942724704742e-01
    z[6,0,4]  R884      -3.2164674997329712e-01
    z[6,0,4]  R885      4.9756950139999390e-01
    z[6,0,4]  R886      -4.0620166063308716e-01
    z[6,0,4]  R887      -0.129534512758255
    z[6,0,4]  R888      2.8277760744094849e-01
    z[6,0,4]  R889      1.3353681564331055e-01
    z[6,0,4]  R890      -4.8810219764709473e-01
    z[6,0,4]  R891      2.2378638386726379e-01
    z[6,0,4]  R892      -7.5205512344837189e-02
    z[6,0,4]  R893      8.6364768445491791e-02
    z[6,0,4]  R894      1.6309115290641785e-01
    z[6,0,4]  R895      -2.0140078663825989e-01
    z[6,0,4]  R896      1.1269237147644162e-03
    z[6,0,4]  R897      -5.0101685523986816e-01
    z[6,0,4]  R898      -2.0102441310882568e-01
    z[6,0,4]  R899      2.6743793487548828e-01
    z[6,0,4]  R900      3.7970918416976929e-01
    z[6,0,4]  R901      4.4239366054534912e-01
    z[6,0,4]  R902      2.2575096786022186e-01
    z[6,0,4]  R903      9.5553815364837646e-02
    z[6,0,4]  R904      -5.1294457912445068e-01
    z[6,0,4]  R905      -4.4900581240653992e-01
    z[6,0,4]  R906      7.5459964573383331e-02
    z[6,0,4]  R907      4.7838100790977478e-01
    z[6,0,4]  R908      2.4804225564002991e-01
    z[6,0,4]  R909      -2.0714102685451508e-01
    z[6,0,4]  R910      -0.0595281757414341
    z[6,0,5]  R7        1
    z[6,0,5]  R61       -1
    z[6,0,5]  R777      -1
    z[6,0,5]  R778      1
    z[6,0,5]  R781      -1.4910748600959778e-01
    z[6,0,5]  R782      2.3642964661121368e-01
    z[6,0,5]  R783      2.6192072033882141e-01
    z[6,0,5]  R784      -2.4893982335925102e-02
    z[6,0,5]  R785      1.1403822153806686e-01
    z[6,0,5]  R786      -2.0856025815010071e-01
    z[6,0,5]  R787      4.7178804874420166e-01
    z[6,0,5]  R788      6.6391664743423462e-01
    z[6,0,5]  R789      3.8924831151962280e-01
    z[6,0,5]  R790      1.2152110785245895e-01
    z[6,0,5]  R791      2.1437183022499084e-02
    z[6,0,5]  R792      1.3909088075160980e-01
    z[6,0,5]  R793      1.1812205612659454e-01
    z[6,0,5]  R794      3.7348988652229309e-01
    z[6,0,5]  R795      -2.3512698709964752e-01
    z[6,0,5]  R796      -4.9178179353475571e-02
    z[6,0,5]  R797      -1.8666283786296844e-01
    z[6,0,5]  R798      4.4221282005310059e-01
    z[6,0,5]  R799      -2.4498255550861359e-01
    z[6,0,5]  R800      -1.5540733933448792e-01
    z[6,0,5]  R801      -1.5384857356548309e-01
    z[6,0,5]  R802      1.3855701684951782e-01
    z[6,0,5]  R803      -2.4059610068798065e-01
    z[6,0,5]  R804      -2.6186150312423706e-01
    z[6,0,5]  R805      -2.3836867511272430e-01
    z[6,0,5]  R806      7.9744279384613037e-01
    z[6,0,5]  R807      -2.9433470964431763e-01
    z[6,0,5]  R808      7.2514837980270386e-01
    z[6,0,5]  R809      3.7951439619064331e-01
    z[6,0,5]  R810      -3.2458725571632385e-01
    z[6,0,5]  R811      -4.4477206468582153e-01
    z[6,0,5]  R812      -8.5610244423151016e-03
    z[6,0,5]  R813      4.2908897995948792e-01
    z[6,0,5]  R814      0.0865989699959755
    z[6,0,5]  R815      -6.7275352776050568e-02
    z[6,0,5]  R816      -3.2819861173629761e-01
    z[6,0,5]  R817      7.9767984151840210e-01
    z[6,0,5]  R818      3.5359352827072144e-01
    z[6,0,5]  R819      5.2157509326934814e-01
    z[6,0,5]  R820      6.2777698040008545e-01
    z[6,0,5]  R821      -1.5226955711841583e-01
    z[6,0,5]  R822      2.4852935969829559e-01
    z[6,0,5]  R823      6.4453983306884766e-01
    z[6,0,5]  R824      8.9482986927032471e-01
    z[6,0,5]  R825      -2.9989114403724670e-01
    z[6,0,5]  R826      6.8360632658004761e-01
    z[6,0,5]  R827      2.0597076416015625e-01
    z[6,0,5]  R828      5.3643468767404556e-02
    z[6,0,5]  R829      3.2350286841392517e-01
    z[6,0,5]  R830      7.4796602129936218e-02
    z[6,0,5]  R831      -8.3849526941776276e-02
    z[6,0,5]  R832      -1.0466530919075012e-01
    z[6,0,5]  R833      -1.0526506602764130e-01
    z[6,0,5]  R834      5.5378687381744385e-01
    z[6,0,5]  R835      -4.9198679625988007e-02
    z[6,0,5]  R836      2.0749524235725403e-01
    z[6,0,5]  R837      4.2804643511772156e-01
    z[6,0,5]  R838      3.4910753369331360e-02
    z[6,0,5]  R839      -3.4486436843872070e-01
    z[6,0,5]  R840      -1.7774419859051704e-02
    z[6,0,5]  R841      -1.9956852495670319e-01
    z[6,0,5]  R842      2.0951206982135773e-01
    z[6,0,5]  R843      -1.6466975212097168e-01
    z[6,0,5]  R844      -4.5666342973709106e-01
    z[6,0,5]  R845      -2.9176460579037666e-02
    z[6,0,5]  R846      1.9770933687686920e-01
    z[6,0,5]  R847      5.5945134162902832e-01
    z[6,0,5]  R848      -1.6124244034290314e-01
    z[6,0,5]  R849      1.6466896235942841e-01
    z[6,0,5]  R850      -1.2085715681314468e-01
    z[6,0,5]  R851      -4.3522989749908447e-01
    z[6,0,5]  R852      -4.2333969473838806e-01
    z[6,0,5]  R853      -2.8290903568267822e-01
    z[6,0,5]  R854      -5.5686312913894653e-01
    z[6,0,5]  R855      -4.0836516022682190e-01
    z[6,0,5]  R856      -3.2412597537040710e-01
    z[6,0,5]  R857      -3.8572993874549866e-01
    z[6,0,5]  R858      -7.1814113855361938e-01
    z[6,0,5]  R859      -2.9740974307060242e-01
    z[6,0,5]  R860      5.8317895978689194e-02
    z[6,0,5]  R861      -4.8274996876716614e-01
    z[6,0,5]  R862      5.1724809408187866e-01
    z[6,0,5]  R863      -4.6995180845260620e-01
    z[6,0,5]  R864      3.5755565762519836e-01
    z[6,0,5]  R865      -3.3992937207221985e-01
    z[6,0,5]  R866      -9.5896673202514648e-01
    z[6,0,5]  R867      0.281389981508255
    z[6,0,5]  R868      -1.3235056400299072e-01
    z[6,0,5]  R869      -5.0508117675781250e-01
    z[6,0,5]  R870      -4.1683351993560791e-01
    z[6,0,5]  R871      -1.5273775160312653e-01
    z[6,0,5]  R872      1.3021574914455414e-01
    z[6,0,5]  R873      4.3204712867736816e-01
    z[6,0,5]  R874      -1.8467260897159576e-01
    z[6,0,5]  R875      1.7204004526138306e-01
    z[6,0,5]  R876      -3.0417588353157043e-01
    z[6,0,5]  R877      3.4708064794540405e-01
    z[6,0,5]  R878      3.9442703127861023e-01
    z[6,0,5]  R879      2.9866768047213554e-02
    z[6,0,5]  R880      -2.0194509997963905e-02
    z[6,0,5]  R881      -2.4880267679691315e-01
    z[6,0,5]  R882      -6.2224805355072021e-01
    z[6,0,5]  R883      -4.2498525977134705e-01
    z[6,0,5]  R884      -2.0908093452453613e-01
    z[6,0,5]  R885      -5.1655232906341553e-02
    z[6,0,5]  R886      -2.6204457506537437e-02
    z[6,0,5]  R887      -2.5494593381881714e-01
    z[6,0,5]  R888      -3.1170985102653503e-01
    z[6,0,5]  R889      -2.5660762190818787e-01
    z[6,0,5]  R890      -4.5631803572177887e-02
    z[6,0,5]  R891      -6.5560504794120789e-02
    z[6,0,5]  R892      4.0770357847213745e-01
    z[6,0,5]  R893      -0.0376245491206646
    z[6,0,5]  R894      -2.2379907965660095e-01
    z[6,0,5]  R895      1.3422715663909912e-01
    z[6,0,5]  R896      2.3163928091526031e-01
    z[6,0,5]  R897      7.7741943299770355e-02
    z[6,0,5]  R898      3.0385997891426086e-01
    z[6,0,5]  R899      1.6005125641822815e-01
    z[6,0,5]  R900      5.8769159018993378e-02
    z[6,0,5]  R901      -3.8271471858024597e-01
    z[6,0,5]  R902      -5.6668068282306194e-03
    z[6,0,5]  R903      -2.1352672576904297e-01
    z[6,0,5]  R904      -1.6919773817062378e-01
    z[6,0,5]  R905      -4.8728186637163162e-02
    z[6,0,5]  R906      0.297302782535553
    z[6,0,5]  R907      8.2587942481040955e-02
    z[6,0,5]  R908      6.0453391075134277e-01
    z[6,0,5]  R909      3.1147131323814392e-01
    z[6,0,5]  R910      5.0482434034347534e-01
    z[6,0,6]  R8        1
    z[6,0,6]  R62       -1
    z[6,0,6]  R779      -1
    z[6,0,6]  R780      1
    z[6,0,6]  R781      -2.1032159030437469e-01
    z[6,0,6]  R782      -3.0687007308006287e-01
    z[6,0,6]  R783      -7.9074859619140625e-02
    z[6,0,6]  R784      -0.459751695394516
    z[6,0,6]  R785      5.9187906980514526e-01
    z[6,0,6]  R786      1.7832185328006744e-01
    z[6,0,6]  R787      -2.1022546291351318e-01
    z[6,0,6]  R788      1.0699690319597721e-02
    z[6,0,6]  R789      -2.9689574241638184e-01
    z[6,0,6]  R790      1.1398231983184814e-01
    z[6,0,6]  R791      1.2032502889633179e-01
    z[6,0,6]  R792      -3.2397669553756714e-01
    z[6,0,6]  R793      -2.7706235647201538e-01
    z[6,0,6]  R794      1.0287478566169739e-01
    z[6,0,6]  R795      3.5452261567115784e-02
    z[6,0,6]  R796      -1.4815139770507812e-01
    z[6,0,6]  R797      -4.4864334166049957e-02
    z[6,0,6]  R798      6.7343883216381073e-02
    z[6,0,6]  R799      -1.1576295830309391e-02
    z[6,0,6]  R800      1.3387800753116608e-01
    z[6,0,6]  R801      2.2807975113391876e-01
    z[6,0,6]  R802      9.1220222413539886e-02
    z[6,0,6]  R803      -3.4824568033218384e-01
    z[6,0,6]  R804      3.2301548123359680e-01
    z[6,0,6]  R805      0.0875079482793808
    z[6,0,6]  R806      -1.8640391528606415e-01
    z[6,0,6]  R807      0.0978948324918747
    z[6,0,6]  R808      3.7448275834321976e-02
    z[6,0,6]  R809      1.1275637149810791e-01
    z[6,0,6]  R810      -7.7837914228439331e-02
    z[6,0,6]  R811      2.3740540444850922e-01
    z[6,0,6]  R812      0.249008908867836
    z[6,0,6]  R813      4.6054357290267944e-01
    z[6,0,6]  R814      -2.5394740700721741e-01
    z[6,0,6]  R815      5.9621725231409073e-02
    z[6,0,6]  R816      -2.0486259460449219e-01
    z[6,0,6]  R817      2.6581510901451111e-01
    z[6,0,6]  R818      -2.0385244488716125e-01
    z[6,0,6]  R819      -2.6578944921493530e-01
    z[6,0,6]  R820      3.9920575916767120e-02
    z[6,0,6]  R821      -2.9724302887916565e-01
    z[6,0,6]  R822      -6.5363639593124390e-01
    z[6,0,6]  R823      -0.0299916360527277
    z[6,0,6]  R824      7.6696924865245819e-02
    z[6,0,6]  R825      -1.8340897560119629e-01
    z[6,0,6]  R826      1.6833055019378662e-01
    z[6,0,6]  R827      -4.9545396119356155e-02
    z[6,0,6]  R828      1.6663007438182831e-01
    z[6,0,6]  R829      -9.1901179403066635e-03
    z[6,0,6]  R830      0.555742084980011
    z[6,0,6]  R831      3.7111893296241760e-01
    z[6,0,6]  R832      -2.0795795321464539e-01
    z[6,0,6]  R833      -1.8203240633010864e-01
    z[6,0,6]  R834      0.0779573991894722
    z[6,0,6]  R835      8.7144345045089722e-02
    z[6,0,6]  R836      -1.1840105056762695e-01
    z[6,0,6]  R837      1.4177146553993225e-01
    z[6,0,6]  R838      -1.5528991818428040e-01
    z[6,0,6]  R839      -4.0459185838699341e-01
    z[6,0,6]  R840      5.0039076805114746e-01
    z[6,0,6]  R841      -4.3116754293441772e-01
    z[6,0,6]  R842      3.9251565933227539e-01
    z[6,0,6]  R843      1.1157218366861343e-01
    z[6,0,6]  R844      4.0498995780944824e-01
    z[6,0,6]  R845      -3.6586725711822510e-01
    z[6,0,6]  R846      -2.3382523655891418e-01
    z[6,0,6]  R847      -6.5789207816123962e-02
    z[6,0,6]  R848      -1.5175785124301910e-01
    z[6,0,6]  R849      0.268466979265213
    z[6,0,6]  R850      3.9267953485250473e-02
    z[6,0,6]  R851      4.5309510827064514e-01
    z[6,0,6]  R852      -3.9014050364494324e-01
    z[6,0,6]  R853      -6.7857891321182251e-01
    z[6,0,6]  R854      -5.5796837806701660e-01
    z[6,0,6]  R855      -2.0839789882302284e-02
    z[6,0,6]  R856      -0.642281711101532
    z[6,0,6]  R857      -3.5570108890533447e-01
    z[6,0,6]  R858      -3.3160585165023804e-01
    z[6,0,6]  R859      -1.7723254859447479e-01
    z[6,0,6]  R860      1.1587673425674438e-01
    z[6,0,6]  R861      -3.5515061020851135e-01
    z[6,0,6]  R862      -1.6898328065872192e-01
    z[6,0,6]  R863      2.1050535142421722e-01
    z[6,0,6]  R864      -5.1412478089332581e-02
    z[6,0,6]  R865      3.0915224552154541e-01
    z[6,0,6]  R866      -7.8972905874252319e-02
    z[6,0,6]  R867      3.3543251920491457e-03
    z[6,0,6]  R868      3.7385997176170349e-01
    z[6,0,6]  R869      3.1316413078457117e-03
    z[6,0,6]  R870      3.4802260994911194e-01
    z[6,0,6]  R871      -2.8481009602546692e-01
    z[6,0,6]  R872      -9.0197168290615082e-02
    z[6,0,6]  R873      1.4108563959598541e-01
    z[6,0,6]  R874      2.5622019171714783e-01
    z[6,0,6]  R875      -4.7528293728828430e-01
    z[6,0,6]  R876      -7.7281542122364044e-02
    z[6,0,6]  R877      4.0720129013061523e-01
    z[6,0,6]  R878      -1.1024359613656998e-01
    z[6,0,6]  R879      2.0571835339069366e-02
    z[6,0,6]  R880      5.8386242389678955e-01
    z[6,0,6]  R881      3.2262188196182251e-01
    z[6,0,6]  R882      -0.536336362361908
    z[6,0,6]  R883      7.7055029571056366e-02
    z[6,0,6]  R884      -3.2069790363311768e-01
    z[6,0,6]  R885      3.3036038279533386e-01
    z[6,0,6]  R886      2.7265515923500061e-01
    z[6,0,6]  R887      -1.6381666064262390e-01
    z[6,0,6]  R888      -5.6212997436523438e-01
    z[6,0,6]  R889      6.5752077102661133e-01
    z[6,0,6]  R890      5.4147444665431976e-02
    z[6,0,6]  R891      -6.9317850284278393e-03
    z[6,0,6]  R892      1.5720768272876740e-01
    z[6,0,6]  R893      -4.1065523028373718e-01
    z[6,0,6]  R894      2.3426532745361328e-01
    z[6,0,6]  R895      -2.1056310832500458e-01
    z[6,0,6]  R896      -5.1340326666831970e-02
    z[6,0,6]  R897      2.3974737524986267e-01
    z[6,0,6]  R898      -3.5421723127365112e-01
    z[6,0,6]  R899      -1.3048692047595978e-01
    z[6,0,6]  R900      1.4695557951927185e-01
    z[6,0,6]  R901      -9.6959307789802551e-02
    z[6,0,6]  R902      -1.6584932804107666e-01
    z[6,0,6]  R903      3.2100099325180054e-01
    z[6,0,6]  R904      3.5137336701154709e-02
    z[6,0,6]  R905      -5.9348177909851074e-01
    z[6,0,6]  R906      -1.4876598119735718e-01
    z[6,0,6]  R907      9.9936850368976593e-02
    z[6,0,6]  R908      2.5252452492713928e-01
    z[6,0,6]  R909      3.1249606609344482e-01
    z[6,0,6]  R910      5.6591600179672241e-01
    z[1,2,0]  R11       -1
    z[1,2,0]  R20       1
    z[1,2,0]  R995      -1
    z[1,2,0]  R996      1
    z[1,2,0]  R1009     4.3224486708641052e-01
    z[1,2,0]  R1010     3.6659610271453857e-01
    z[1,2,0]  R1011     -8.1483668088912964e-01
    z[1,2,0]  R1012     -4.7504967451095581e-01
    z[1,2,0]  R1013     9.9776171147823334e-02
    z[1,2,0]  R1014     -2.4727405607700348e-01
    z[1,2,0]  R1015     -0.917407214641571
    z[1,2,0]  R1016     6.2808997929096222e-02
    z[1,2,0]  R1017     -0.308746337890625
    z[1,2,0]  R1018     -4.8761337995529175e-01
    z[1,2,0]  R1019     0.397777795791626
    z[1,2,0]  R1020     -4.1439205408096313e-01
    z[1,2,0]  R1021     1.4232541620731354e-01
    z[1,2,0]  R1022     -5.3590681403875351e-02
    z[1,2,0]  R1023     -2.6490634679794312e-01
    z[1,2,0]  R1024     -4.6500900387763977e-01
    z[1,2,0]  R1025     3.4500789642333984e-01
    z[1,2,0]  R1026     5.8319758623838425e-02
    z[1,2,0]  R1027     3.2757607102394104e-01
    z[1,2,0]  R1028     -4.6450477838516235e-01
    z[1,2,0]  R1029     -3.8021394610404968e-01
    z[1,2,0]  R1030     -4.2508924007415771e-01
    z[1,2,0]  R1031     7.9560470581054688e-01
    z[1,2,0]  R1032     5.8747023344039917e-02
    z[1,2,0]  R1033     5.6420296430587769e-02
    z[1,2,0]  R1034     1.6659533977508545e-01
    z[1,2,0]  R1035     -5.6979233026504517e-01
    z[1,2,0]  R1036     -5.0615012645721436e-01
    z[1,2,0]  R1037     3.0126988887786865e-01
    z[1,2,0]  R1038     -0.757485568523407
    z[1,2,0]  R1039     -4.4783648848533630e-01
    z[1,2,0]  R1040     -7.9233306646347046e-01
    z[1,2,0]  R1041     4.7181427478790283e-01
    z[1,2,0]  R1042     3.2298198342323303e-01
    z[1,2,0]  R1043     1.8034714460372925e-01
    z[1,2,0]  R1044     -1.2563885748386383e-01
    z[1,2,0]  R1045     -5.5225425958633423e-01
    z[1,2,0]  R1046     -7.3657369613647461e-01
    z[1,2,0]  R1047     -3.4009787440299988e-01
    z[1,2,0]  R1048     -5.2417492866516113e-01
    z[1,2,0]  R1049     -8.5611319541931152e-01
    z[1,2,0]  R1050     4.8100566864013672e-01
    z[1,2,0]  R1051     7.7067714929580688e-01
    z[1,2,0]  R1052     -6.2109786272048950e-01
    z[1,2,0]  R1053     -5.5576455593109131e-01
    z[1,2,0]  R1054     -5.1919281482696533e-01
    z[1,2,0]  R1055     -7.3657137155532837e-01
    z[1,2,0]  R1056     -8.4333992004394531e-01
    z[1,2,0]  R1057     -9.6286928653717041e-01
    z[1,2,0]  R1058     -2.5694388151168823e-01
    z[1,2,0]  R1059     -2.8820779919624329e-01
    z[1,2,0]  R1060     -2.2038878500461578e-01
    z[1,2,1]  R12       -1
    z[1,2,1]  R21       1
    z[1,2,1]  R997      -1
    z[1,2,1]  R998      1
    z[1,2,1]  R1009     -2.4835999310016632e-01
    z[1,2,1]  R1010     1.8533114343881607e-02
    z[1,2,1]  R1011     -1.2853796780109406e-01
    z[1,2,1]  R1012     7.6763892173767090e-01
    z[1,2,1]  R1013     8.7351602315902710e-01
    z[1,2,1]  R1014     0.82350754737854
    z[1,2,1]  R1015     1.2437266111373901e-01
    z[1,2,1]  R1016     6.2831938266754150e-01
    z[1,2,1]  R1017     -4.4275969266891479e-01
    z[1,2,1]  R1018     -3.4939491748809814e-01
    z[1,2,1]  R1019     -2.6593357324600220e-02
    z[1,2,1]  R1020     1.8808719515800476e-01
    z[1,2,1]  R1021     -4.7432509064674377e-01
    z[1,2,1]  R1022     -6.5710681676864624e-01
    z[1,2,1]  R1023     -1.7128066718578339e-01
    z[1,2,1]  R1024     5.2137100696563721e-01
    z[1,2,1]  R1025     6.6814243793487549e-01
    z[1,2,1]  R1026     7.3001396656036377e-01
    z[1,2,1]  R1027     7.4190747737884521e-01
    z[1,2,1]  R1028     -7.3118019104003906e-01
    z[1,2,1]  R1029     -0.425414115190506
    z[1,2,1]  R1030     -3.8223680853843689e-01
    z[1,2,1]  R1031     -7.3858700692653656e-02
    z[1,2,1]  R1032     -3.8317173719406128e-02
    z[1,2,1]  R1033     2.3945713415741920e-02
    z[1,2,1]  R1034     -1.5448449552059174e-01
    z[1,2,1]  R1035     -5.7244252413511276e-02
    z[1,2,1]  R1036     -1.3700307905673981e-01
    z[1,2,1]  R1037     -2.0833842456340790e-01
    z[1,2,1]  R1038     0.222439244389534
    z[1,2,1]  R1039     4.7171473503112793e-02
    z[1,2,1]  R1040     1.6972686350345612e-01
    z[1,2,1]  R1041     -2.8667894005775452e-01
    z[1,2,1]  R1042     -6.6695541143417358e-02
    z[1,2,1]  R1043     -3.8933500647544861e-01
    z[1,2,1]  R1044     2.0199991762638092e-01
    z[1,2,1]  R1045     6.2614865601062775e-02
    z[1,2,1]  R1046     4.7358462214469910e-01
    z[1,2,1]  R1047     -4.4518062472343445e-01
    z[1,2,1]  R1048     -4.8974168300628662e-01
    z[1,2,1]  R1049     -3.4183260798454285e-01
    z[1,2,1]  R1050     6.5887284278869629e-01
    z[1,2,1]  R1051     -2.7084159851074219e-01
    z[1,2,1]  R1052     -4.2878395318984985e-01
    z[1,2,1]  R1053     1.6294892132282257e-01
    z[1,2,1]  R1054     2.1301576867699623e-02
    z[1,2,1]  R1055     -1.3453175313770771e-02
    z[1,2,1]  R1056     7.6238766312599182e-02
    z[1,2,1]  R1057     2.9677538201212883e-02
    z[1,2,1]  R1058     5.0362879037857056e-01
    z[1,2,1]  R1059     4.3031796813011169e-01
    z[1,2,1]  R1060     5.1262778043746948e-01
    z[1,2,2]  R13       -1
    z[1,2,2]  R22       1
    z[1,2,2]  R999      -1
    z[1,2,2]  R1000     1
    z[1,2,2]  R1009     -0.229964017868042
    z[1,2,2]  R1010     4.0561392903327942e-01
    z[1,2,2]  R1011     3.0907127261161804e-01
    z[1,2,2]  R1012     1.8937484920024872e-01
    z[1,2,2]  R1013     -1.0655014961957932e-01
    z[1,2,2]  R1014     9.2627935111522675e-02
    z[1,2,2]  R1015     1.9605781137943268e-01
    z[1,2,2]  R1016     -2.5864368304610252e-02
    z[1,2,2]  R1017     -3.6831769347190857e-01
    z[1,2,2]  R1018     -4.0486955642700195e-01
    z[1,2,2]  R1019     -4.6876770257949829e-01
    z[1,2,2]  R1020     -4.8648950457572937e-01
    z[1,2,2]  R1021     5.8708250522613525e-01
    z[1,2,2]  R1022     -2.1480685472488403e-01
    z[1,2,2]  R1023     6.2088185548782349e-01
    z[1,2,2]  R1024     6.2677621841430664e-01
    z[1,2,2]  R1025     2.1633145213127136e-01
    z[1,2,2]  R1026     0.319040983915329
    z[1,2,2]  R1027     2.1228766441345215e-01
    z[1,2,2]  R1028     -0.082750104367733
    z[1,2,2]  R1029     -3.0480343848466873e-02
    z[1,2,2]  R1030     -3.5850539803504944e-01
    z[1,2,2]  R1031     -1.2870597839355469e-01
    z[1,2,2]  R1032     -4.4760158658027649e-01
    z[1,2,2]  R1033     -5.9536278247833252e-01
    z[1,2,2]  R1034     -3.5079661011695862e-01
    z[1,2,2]  R1035     3.7425386905670166e-01
    z[1,2,2]  R1036     1.7334254086017609e-01
    z[1,2,2]  R1037     2.9048182070255280e-02
    z[1,2,2]  R1038     -1.3645115494728088e-01
    z[1,2,2]  R1039     -4.7360304743051529e-02
    z[1,2,2]  R1040     1.5023660659790039e-01
    z[1,2,2]  R1041     -8.4910027682781219e-02
    z[1,2,2]  R1042     -1.9578267633914948e-01
    z[1,2,2]  R1043     4.5277169346809387e-01
    z[1,2,2]  R1044     -1.5360449254512787e-01
    z[1,2,2]  R1045     -1.9595074653625488e-01
    z[1,2,2]  R1046     -2.1869741380214691e-01
    z[1,2,2]  R1047     5.1681622862815857e-02
    z[1,2,2]  R1048     3.1329271197319031e-01
    z[1,2,2]  R1049     1.3080114126205444e-01
    z[1,2,2]  R1050     -1.6545876860618591e-01
    z[1,2,2]  R1051     1.9249762594699860e-01
    z[1,2,2]  R1052     1.5486666560173035e-01
    z[1,2,2]  R1053     -3.9002892374992371e-01
    z[1,2,2]  R1054     -1.8877764046192169e-01
    z[1,2,2]  R1055     3.6347694694995880e-02
    z[1,2,2]  R1056     5.9024445712566376e-02
    z[1,2,2]  R1057     -1.6600438952445984e-01
    z[1,2,2]  R1058     -1.6646376252174377e-01
    z[1,2,2]  R1059     -3.0023169517517090e-01
    z[1,2,2]  R1060     -3.7327682971954346e-01
    z[1,2,3]  R14       -1
    z[1,2,3]  R23       1
    z[1,2,3]  R1001     -1
    z[1,2,3]  R1002     1
    z[1,2,3]  R1009     -2.4189765751361847e-01
    z[1,2,3]  R1010     -3.3917987346649170e-01
    z[1,2,3]  R1011     4.2526509612798691e-02
    z[1,2,3]  R1012     2.8479378670454025e-02
    z[1,2,3]  R1013     1.1749300360679626e-01
    z[1,2,3]  R1014     2.9178312420845032e-01
    z[1,2,3]  R1015     5.5899225175380707e-02
    z[1,2,3]  R1016     3.2622328400611877e-01
    z[1,2,3]  R1017     -4.3790200352668762e-01
    z[1,2,3]  R1018     -0.609557569026947
    z[1,2,3]  R1019     1.0702575743198395e-01
    z[1,2,3]  R1020     6.5374052524566650e-01
    z[1,2,3]  R1021     2.7324968576431274e-01
    z[1,2,3]  R1022     3.3977967500686646e-01
    z[1,2,3]  R1023     -3.3968049287796021e-01
    z[1,2,3]  R1024     3.1409987807273865e-01
    z[1,2,3]  R1025     5.9229767322540283e-01
    z[1,2,3]  R1026     4.7588908672332764e-01
    z[1,2,3]  R1027     2.2977969050407410e-01
    z[1,2,3]  R1028     -4.4816818833351135e-01
    z[1,2,3]  R1029     -4.3633216619491577e-01
    z[1,2,3]  R1030     -4.2344403266906738e-01
    z[1,2,3]  R1031     -5.2323424816131592e-01
    z[1,2,3]  R1032     -8.4122993052005768e-02
    z[1,2,3]  R1033     -3.7513166666030884e-02
    z[1,2,3]  R1034     -2.8162273764610291e-01
    z[1,2,3]  R1035     -4.2607815703377128e-04
    z[1,2,3]  R1036     -2.4124450981616974e-01
    z[1,2,3]  R1037     -4.5462879538536072e-01
    z[1,2,3]  R1038     2.3012081161141396e-02
    z[1,2,3]  R1039     -8.7575650215148926e-01
    z[1,2,3]  R1040     -1.4310289174318314e-02
    z[1,2,3]  R1041     6.3929539918899536e-01
    z[1,2,3]  R1042     7.0096129179000854e-01
    z[1,2,3]  R1043     1.2679651379585266e-01
    z[1,2,3]  R1044     -3.0616298317909241e-01
    z[1,2,3]  R1045     3.8901904225349426e-01
    z[1,2,3]  R1046     -0.313040167093277
    z[1,2,3]  R1047     -6.9512730836868286e-01
    z[1,2,3]  R1048     -6.0983955860137939e-01
    z[1,2,3]  R1049     -2.2480836510658264e-01
    z[1,2,3]  R1050     8.6680993437767029e-02
    z[1,2,3]  R1051     -0.0981922596693039
    z[1,2,3]  R1052     -3.5993191599845886e-01
    z[1,2,3]  R1053     -0.293952614068985
    z[1,2,3]  R1054     -6.3237422704696655e-01
    z[1,2,3]  R1055     7.5537204742431641e-02
    z[1,2,3]  R1056     -1.4321139454841614e-01
    z[1,2,3]  R1057     -1.1148868501186371e-01
    z[1,2,3]  R1058     6.1996006965637207e-01
    z[1,2,3]  R1059     5.4018056392669678e-01
    z[1,2,3]  R1060     0.558257520198822
    z[1,2,4]  R15       -1
    z[1,2,4]  R24       1
    z[1,2,4]  R1003     -1
    z[1,2,4]  R1004     1
    z[1,2,4]  R1009     6.7818784713745117e-01
    z[1,2,4]  R1010     -7.3060697317123413e-01
    z[1,2,4]  R1011     4.3386703729629517e-01
    z[1,2,4]  R1012     1.1272528767585754e-01
    z[1,2,4]  R1013     1.1800088733434677e-01
    z[1,2,4]  R1014     3.5040014982223511e-01
    z[1,2,4]  R1015     -0.262971967458725
    z[1,2,4]  R1016     1.3726362586021423e-01
    z[1,2,4]  R1017     -9.2204205691814423e-02
    z[1,2,4]  R1018     -1.9371549785137177e-01
    z[1,2,4]  R1019     3.5541161894798279e-02
    z[1,2,4]  R1020     -2.0237004756927490e-01
    z[1,2,4]  R1021     1.2165561318397522e-01
    z[1,2,4]  R1022     -3.6070284247398376e-01
    z[1,2,4]  R1023     4.1045939922332764e-01
    z[1,2,4]  R1024     1.6668954864144325e-02
    z[1,2,4]  R1025     1.4215713739395142e-01
    z[1,2,4]  R1026     4.3430402874946594e-02
    z[1,2,4]  R1027     6.3840463757514954e-02
    z[1,2,4]  R1028     -1.2974040210247040e-01
    z[1,2,4]  R1029     -8.1952154636383057e-02
    z[1,2,4]  R1030     -1.8370974063873291e-01
    z[1,2,4]  R1031     2.6254183053970337e-01
    z[1,2,4]  R1032     -8.6453789472579956e-01
    z[1,2,4]  R1033     -5.0706136226654053e-01
    z[1,2,4]  R1034     -4.1331490874290466e-01
    z[1,2,4]  R1035     6.6439354419708252e-01
    z[1,2,4]  R1036     3.9260542392730713e-01
    z[1,2,4]  R1037     1.9915367662906647e-01
    z[1,2,4]  R1038     -1.9344860315322876e-01
    z[1,2,4]  R1039     -0.140597403049469
    z[1,2,4]  R1040     -2.5817906856536865e-01
    z[1,2,4]  R1041     -1.9860602915287018e-01
    z[1,2,4]  R1042     1.4874619245529175e-01
    z[1,2,4]  R1043     -1.6657146811485291e-01
    z[1,2,4]  R1044     3.2928335666656494e-01
    z[1,2,4]  R1045     3.4375011920928955e-01
    z[1,2,4]  R1046     1.2376535683870316e-02
    z[1,2,4]  R1047     -3.5774958133697510e-01
    z[1,2,4]  R1048     3.2629944384098053e-02
    z[1,2,4]  R1049     -0.175101175904274
    z[1,2,4]  R1050     2.4518145248293877e-02
    z[1,2,4]  R1051     -1.8213038146495819e-01
    z[1,2,4]  R1052     1.6555699706077576e-01
    z[1,2,4]  R1053     -0.0345456637442112
    z[1,2,4]  R1054     -1.6101695597171783e-02
    z[1,2,4]  R1055     0.273774117231369
    z[1,2,4]  R1056     0.355630487203598
    z[1,2,4]  R1057     -1.2609335780143738e-01
    z[1,2,4]  R1058     3.4994874149560928e-02
    z[1,2,4]  R1059     -2.8484666347503662e-01
    z[1,2,4]  R1060     -1.2254709750413895e-01
    z[1,2,5]  R16       -1
    z[1,2,5]  R25       1
    z[1,2,5]  R1005     -1
    z[1,2,5]  R1006     1
    z[1,2,5]  R1009     -7.3558405041694641e-02
    z[1,2,5]  R1010     2.1748398244380951e-01
    z[1,2,5]  R1011     1.1583929508924484e-01
    z[1,2,5]  R1012     3.4561118483543396e-01
    z[1,2,5]  R1013     3.9490637183189392e-01
    z[1,2,5]  R1014     1.4406548440456390e-01
    z[1,2,5]  R1015     -0.0522085502743721
    z[1,2,5]  R1016     -2.1412852406501770e-01
    z[1,2,5]  R1017     -2.4928821623325348e-01
    z[1,2,5]  R1018     6.8778353743255138e-03
    z[1,2,5]  R1019     3.2511085271835327e-01
    z[1,2,5]  R1020     -2.6931858062744141e-01
    z[1,2,5]  R1021     -5.1344615221023560e-01
    z[1,2,5]  R1022     -5.2290058135986328e-01
    z[1,2,5]  R1023     5.3218550980091095e-02
    z[1,2,5]  R1024     -1.3850098848342896e-01
    z[1,2,5]  R1025     -6.3376188278198242e-02
    z[1,2,5]  R1026     -3.0528476834297180e-01
    z[1,2,5]  R1027     -4.8538818955421448e-01
    z[1,2,5]  R1028     -1.2154900282621384e-01
    z[1,2,5]  R1029     -6.7240279912948608e-01
    z[1,2,5]  R1030     -5.2716493606567383e-01
    z[1,2,5]  R1031     2.2383647039532661e-02
    z[1,2,5]  R1032     1.7699062824249268e-01
    z[1,2,5]  R1033     -6.1907207965850830e-01
    z[1,2,5]  R1034     -5.1594501733779907e-01
    z[1,2,5]  R1035     -5.6261856108903885e-02
    z[1,2,5]  R1036     -2.1048752963542938e-01
    z[1,2,5]  R1037     -7.3773866891860962e-01
    z[1,2,5]  R1038     4.4551637768745422e-01
    z[1,2,5]  R1039     -6.9373883306980133e-02
    z[1,2,5]  R1040     3.4781849384307861e-01
    z[1,2,5]  R1041     -2.7797597646713257e-01
    z[1,2,5]  R1042     5.0542235374450684e-01
    z[1,2,5]  R1043     0.752040445804596
    z[1,2,5]  R1044     -0.677208662033081
    z[1,2,5]  R1045     -6.1743950843811035e-01
    z[1,2,5]  R1046     1.2394061684608459e-01
    z[1,2,5]  R1047     -2.2177100181579590e-01
    z[1,2,5]  R1048     -1.1052309721708298e-01
    z[1,2,5]  R1049     8.9796259999275208e-02
    z[1,2,5]  R1050     5.0441777706146240e-01
    z[1,2,5]  R1051     2.2709850966930389e-01
    z[1,2,5]  R1052     -4.9671435356140137e-01
    z[1,2,5]  R1053     -6.4993208646774292e-01
    z[1,2,5]  R1054     -4.6593353152275085e-01
    z[1,2,5]  R1055     -2.5010520219802856e-01
    z[1,2,5]  R1056     -0.0868993028998375
    z[1,2,5]  R1057     -7.3190785944461823e-02
    z[1,2,5]  R1058     5.1488876342773438e-01
    z[1,2,5]  R1059     5.1804476976394653e-01
    z[1,2,5]  R1060     2.9414954781532288e-01
    z[1,2,6]  R17       -1
    z[1,2,6]  R26       1
    z[1,2,6]  R1007     -1
    z[1,2,6]  R1008     1
    z[1,2,6]  R1009     -4.1801211237907410e-01
    z[1,2,6]  R1010     -6.7914955317974091e-02
    z[1,2,6]  R1011     1.4326995611190796e-01
    z[1,2,6]  R1012     1.2739814817905426e-01
    z[1,2,6]  R1013     -1.7883436381816864e-01
    z[1,2,6]  R1014     -1.5309639275074005e-01
    z[1,2,6]  R1015     1.7161594331264496e-01
    z[1,2,6]  R1016     6.5535253286361694e-01
    z[1,2,6]  R1017     0.557294487953186
    z[1,2,6]  R1018     2.5904360413551331e-01
    z[1,2,6]  R1019     0.709159791469574
    z[1,2,6]  R1020     -1.2396611273288727e-01
    z[1,2,6]  R1021     2.3874849081039429e-01
    z[1,2,6]  R1022     -1.4659132808446884e-02
    z[1,2,6]  R1023     4.7780883312225342e-01
    z[1,2,6]  R1024     -3.1167024746537209e-02
    z[1,2,6]  R1025     -1.1275658756494522e-01
    z[1,2,6]  R1026     2.0083774626255035e-01
    z[1,2,6]  R1027     -6.8739682435989380e-02
    z[1,2,6]  R1028     1.0149707645177841e-01
    z[1,2,6]  R1029     0.15589639544487
    z[1,2,6]  R1030     2.3175662755966187e-01
    z[1,2,6]  R1031     4.2301423847675323e-02
    z[1,2,6]  R1032     -9.4368137419223785e-02
    z[1,2,6]  R1033     4.2013907805085182e-03
    z[1,2,6]  R1034     5.5586183071136475e-01
    z[1,2,6]  R1035     -2.9565081000328064e-01
    z[1,2,6]  R1036     6.6208136081695557e-01
    z[1,2,6]  R1037     -2.7272674441337585e-01
    z[1,2,6]  R1038     3.4882771968841553e-01
    z[1,2,6]  R1039     -5.8689262717962265e-02
    z[1,2,6]  R1040     -3.6467951536178589e-01
    z[1,2,6]  R1041     -4.0321603417396545e-01
    z[1,2,6]  R1042     2.8979256749153137e-01
    z[1,2,6]  R1043     3.8762498646974564e-02
    z[1,2,6]  R1044     -5.0896149873733521e-01
    z[1,2,6]  R1045     4.4344786554574966e-02
    z[1,2,6]  R1046     -2.6802939176559448e-01
    z[1,2,6]  R1047     -1.5201157331466675e-01
    z[1,2,6]  R1048     4.5354485511779785e-02
    z[1,2,6]  R1049     -2.0940189063549042e-01
    z[1,2,6]  R1050     2.1116709709167480e-01
    z[1,2,6]  R1051     4.4861918687820435e-01
    z[1,2,6]  R1052     -5.2085243165493011e-02
    z[1,2,6]  R1053     -4.9371570348739624e-02
    z[1,2,6]  R1054     2.7766451239585876e-01
    z[1,2,6]  R1055     -5.5924034118652344e-01
    z[1,2,6]  R1056     3.5347905755043030e-01
    z[1,2,6]  R1057     -1.0372241586446762e-01
    z[1,2,6]  R1058     -4.4070154428482056e-02
    z[1,2,6]  R1059     1.7904048785567284e-02
    z[1,2,6]  R1060     3.6893460154533386e-01
    z[2,1,0]  R11       1
    z[2,1,0]  R20       -1
    z[2,1,0]  R1061     -1
    z[2,1,0]  R1062     1
    z[2,1,0]  R1075     7.9560470581054688e-01
    z[2,1,0]  R1076     5.8747023344039917e-02
    z[2,1,0]  R1077     5.6420296430587769e-02
    z[2,1,0]  R1078     1.6659533977508545e-01
    z[2,1,0]  R1079     -5.6979233026504517e-01
    z[2,1,0]  R1080     -5.0615012645721436e-01
    z[2,1,0]  R1081     3.0126988887786865e-01
    z[2,1,0]  R1082     -0.757485568523407
    z[2,1,0]  R1083     -4.4783648848533630e-01
    z[2,1,0]  R1084     -7.9233306646347046e-01
    z[2,1,0]  R1085     4.7181427478790283e-01
    z[2,1,0]  R1086     3.2298198342323303e-01
    z[2,1,0]  R1087     1.8034714460372925e-01
    z[2,1,0]  R1088     -1.2563885748386383e-01
    z[2,1,0]  R1089     -5.5225425958633423e-01
    z[2,1,0]  R1090     -7.3657369613647461e-01
    z[2,1,0]  R1091     -3.4009787440299988e-01
    z[2,1,0]  R1092     -5.2417492866516113e-01
    z[2,1,0]  R1093     -8.5611319541931152e-01
    z[2,1,0]  R1094     4.8100566864013672e-01
    z[2,1,0]  R1095     7.7067714929580688e-01
    z[2,1,0]  R1096     -6.2109786272048950e-01
    z[2,1,0]  R1097     -5.5576455593109131e-01
    z[2,1,0]  R1098     -5.1919281482696533e-01
    z[2,1,0]  R1099     -7.3657137155532837e-01
    z[2,1,0]  R1100     -8.4333992004394531e-01
    z[2,1,0]  R1101     -9.6286928653717041e-01
    z[2,1,0]  R1102     -2.5694388151168823e-01
    z[2,1,0]  R1103     -2.8820779919624329e-01
    z[2,1,0]  R1104     -2.2038878500461578e-01
    z[2,1,0]  R1105     4.3224486708641052e-01
    z[2,1,0]  R1106     3.6659610271453857e-01
    z[2,1,0]  R1107     -8.1483668088912964e-01
    z[2,1,0]  R1108     -4.7504967451095581e-01
    z[2,1,0]  R1109     9.9776171147823334e-02
    z[2,1,0]  R1110     -2.4727405607700348e-01
    z[2,1,0]  R1111     -0.917407214641571
    z[2,1,0]  R1112     6.2808997929096222e-02
    z[2,1,0]  R1113     -0.308746337890625
    z[2,1,0]  R1114     -4.8761337995529175e-01
    z[2,1,0]  R1115     0.397777795791626
    z[2,1,0]  R1116     -4.1439205408096313e-01
    z[2,1,0]  R1117     1.4232541620731354e-01
    z[2,1,0]  R1118     -5.3590681403875351e-02
    z[2,1,0]  R1119     -2.6490634679794312e-01
    z[2,1,0]  R1120     -4.6500900387763977e-01
    z[2,1,0]  R1121     3.4500789642333984e-01
    z[2,1,0]  R1122     5.8319758623838425e-02
    z[2,1,0]  R1123     3.2757607102394104e-01
    z[2,1,0]  R1124     -4.6450477838516235e-01
    z[2,1,0]  R1125     -3.8021394610404968e-01
    z[2,1,0]  R1126     -4.2508924007415771e-01
    z[2,1,1]  R12       1
    z[2,1,1]  R21       -1
    z[2,1,1]  R1063     -1
    z[2,1,1]  R1064     1
    z[2,1,1]  R1075     -7.3858700692653656e-02
    z[2,1,1]  R1076     -3.8317173719406128e-02
    z[2,1,1]  R1077     2.3945713415741920e-02
    z[2,1,1]  R1078     -1.5448449552059174e-01
    z[2,1,1]  R1079     -5.7244252413511276e-02
    z[2,1,1]  R1080     -1.3700307905673981e-01
    z[2,1,1]  R1081     -2.0833842456340790e-01
    z[2,1,1]  R1082     0.222439244389534
    z[2,1,1]  R1083     4.7171473503112793e-02
    z[2,1,1]  R1084     1.6972686350345612e-01
    z[2,1,1]  R1085     -2.8667894005775452e-01
    z[2,1,1]  R1086     -6.6695541143417358e-02
    z[2,1,1]  R1087     -3.8933500647544861e-01
    z[2,1,1]  R1088     2.0199991762638092e-01
    z[2,1,1]  R1089     6.2614865601062775e-02
    z[2,1,1]  R1090     4.7358462214469910e-01
    z[2,1,1]  R1091     -4.4518062472343445e-01
    z[2,1,1]  R1092     -4.8974168300628662e-01
    z[2,1,1]  R1093     -3.4183260798454285e-01
    z[2,1,1]  R1094     6.5887284278869629e-01
    z[2,1,1]  R1095     -2.7084159851074219e-01
    z[2,1,1]  R1096     -4.2878395318984985e-01
    z[2,1,1]  R1097     1.6294892132282257e-01
    z[2,1,1]  R1098     2.1301576867699623e-02
    z[2,1,1]  R1099     -1.3453175313770771e-02
    z[2,1,1]  R1100     7.6238766312599182e-02
    z[2,1,1]  R1101     2.9677538201212883e-02
    z[2,1,1]  R1102     5.0362879037857056e-01
    z[2,1,1]  R1103     4.3031796813011169e-01
    z[2,1,1]  R1104     5.1262778043746948e-01
    z[2,1,1]  R1105     -2.4835999310016632e-01
    z[2,1,1]  R1106     1.8533114343881607e-02
    z[2,1,1]  R1107     -1.2853796780109406e-01
    z[2,1,1]  R1108     7.6763892173767090e-01
    z[2,1,1]  R1109     8.7351602315902710e-01
    z[2,1,1]  R1110     0.82350754737854
    z[2,1,1]  R1111     1.2437266111373901e-01
    z[2,1,1]  R1112     6.2831938266754150e-01
    z[2,1,1]  R1113     -4.4275969266891479e-01
    z[2,1,1]  R1114     -3.4939491748809814e-01
    z[2,1,1]  R1115     -2.6593357324600220e-02
    z[2,1,1]  R1116     1.8808719515800476e-01
    z[2,1,1]  R1117     -4.7432509064674377e-01
    z[2,1,1]  R1118     -6.5710681676864624e-01
    z[2,1,1]  R1119     -1.7128066718578339e-01
    z[2,1,1]  R1120     5.2137100696563721e-01
    z[2,1,1]  R1121     6.6814243793487549e-01
    z[2,1,1]  R1122     7.3001396656036377e-01
    z[2,1,1]  R1123     7.4190747737884521e-01
    z[2,1,1]  R1124     -7.3118019104003906e-01
    z[2,1,1]  R1125     -0.425414115190506
    z[2,1,1]  R1126     -3.8223680853843689e-01
    z[2,1,2]  R13       1
    z[2,1,2]  R22       -1
    z[2,1,2]  R1065     -1
    z[2,1,2]  R1066     1
    z[2,1,2]  R1075     -1.2870597839355469e-01
    z[2,1,2]  R1076     -4.4760158658027649e-01
    z[2,1,2]  R1077     -5.9536278247833252e-01
    z[2,1,2]  R1078     -3.5079661011695862e-01
    z[2,1,2]  R1079     3.7425386905670166e-01
    z[2,1,2]  R1080     1.7334254086017609e-01
    z[2,1,2]  R1081     2.9048182070255280e-02
    z[2,1,2]  R1082     -1.3645115494728088e-01
    z[2,1,2]  R1083     -4.7360304743051529e-02
    z[2,1,2]  R1084     1.5023660659790039e-01
    z[2,1,2]  R1085     -8.4910027682781219e-02
    z[2,1,2]  R1086     -1.9578267633914948e-01
    z[2,1,2]  R1087     4.5277169346809387e-01
    z[2,1,2]  R1088     -1.5360449254512787e-01
    z[2,1,2]  R1089     -1.9595074653625488e-01
    z[2,1,2]  R1090     -2.1869741380214691e-01
    z[2,1,2]  R1091     5.1681622862815857e-02
    z[2,1,2]  R1092     3.1329271197319031e-01
    z[2,1,2]  R1093     1.3080114126205444e-01
    z[2,1,2]  R1094     -1.6545876860618591e-01
    z[2,1,2]  R1095     1.9249762594699860e-01
    z[2,1,2]  R1096     1.5486666560173035e-01
    z[2,1,2]  R1097     -3.9002892374992371e-01
    z[2,1,2]  R1098     -1.8877764046192169e-01
    z[2,1,2]  R1099     3.6347694694995880e-02
    z[2,1,2]  R1100     5.9024445712566376e-02
    z[2,1,2]  R1101     -1.6600438952445984e-01
    z[2,1,2]  R1102     -1.6646376252174377e-01
    z[2,1,2]  R1103     -3.0023169517517090e-01
    z[2,1,2]  R1104     -3.7327682971954346e-01
    z[2,1,2]  R1105     -0.229964017868042
    z[2,1,2]  R1106     4.0561392903327942e-01
    z[2,1,2]  R1107     3.0907127261161804e-01
    z[2,1,2]  R1108     1.8937484920024872e-01
    z[2,1,2]  R1109     -1.0655014961957932e-01
    z[2,1,2]  R1110     9.2627935111522675e-02
    z[2,1,2]  R1111     1.9605781137943268e-01
    z[2,1,2]  R1112     -2.5864368304610252e-02
    z[2,1,2]  R1113     -3.6831769347190857e-01
    z[2,1,2]  R1114     -4.0486955642700195e-01
    z[2,1,2]  R1115     -4.6876770257949829e-01
    z[2,1,2]  R1116     -4.8648950457572937e-01
    z[2,1,2]  R1117     5.8708250522613525e-01
    z[2,1,2]  R1118     -2.1480685472488403e-01
    z[2,1,2]  R1119     6.2088185548782349e-01
    z[2,1,2]  R1120     6.2677621841430664e-01
    z[2,1,2]  R1121     2.1633145213127136e-01
    z[2,1,2]  R1122     0.319040983915329
    z[2,1,2]  R1123     2.1228766441345215e-01
    z[2,1,2]  R1124     -0.082750104367733
    z[2,1,2]  R1125     -3.0480343848466873e-02
    z[2,1,2]  R1126     -3.5850539803504944e-01
    z[2,1,3]  R14       1
    z[2,1,3]  R23       -1
    z[2,1,3]  R1067     -1
    z[2,1,3]  R1068     1
    z[2,1,3]  R1075     -5.2323424816131592e-01
    z[2,1,3]  R1076     -8.4122993052005768e-02
    z[2,1,3]  R1077     -3.7513166666030884e-02
    z[2,1,3]  R1078     -2.8162273764610291e-01
    z[2,1,3]  R1079     -4.2607815703377128e-04
    z[2,1,3]  R1080     -2.4124450981616974e-01
    z[2,1,3]  R1081     -4.5462879538536072e-01
    z[2,1,3]  R1082     2.3012081161141396e-02
    z[2,1,3]  R1083     -8.7575650215148926e-01
    z[2,1,3]  R1084     -1.4310289174318314e-02
    z[2,1,3]  R1085     6.3929539918899536e-01
    z[2,1,3]  R1086     7.0096129179000854e-01
    z[2,1,3]  R1087     1.2679651379585266e-01
    z[2,1,3]  R1088     -3.0616298317909241e-01
    z[2,1,3]  R1089     3.8901904225349426e-01
    z[2,1,3]  R1090     -0.313040167093277
    z[2,1,3]  R1091     -6.9512730836868286e-01
    z[2,1,3]  R1092     -6.0983955860137939e-01
    z[2,1,3]  R1093     -2.2480836510658264e-01
    z[2,1,3]  R1094     8.6680993437767029e-02
    z[2,1,3]  R1095     -0.0981922596693039
    z[2,1,3]  R1096     -3.5993191599845886e-01
    z[2,1,3]  R1097     -0.293952614068985
    z[2,1,3]  R1098     -6.3237422704696655e-01
    z[2,1,3]  R1099     7.5537204742431641e-02
    z[2,1,3]  R1100     -1.4321139454841614e-01
    z[2,1,3]  R1101     -1.1148868501186371e-01
    z[2,1,3]  R1102     6.1996006965637207e-01
    z[2,1,3]  R1103     5.4018056392669678e-01
    z[2,1,3]  R1104     0.558257520198822
    z[2,1,3]  R1105     -2.4189765751361847e-01
    z[2,1,3]  R1106     -3.3917987346649170e-01
    z[2,1,3]  R1107     4.2526509612798691e-02
    z[2,1,3]  R1108     2.8479378670454025e-02
    z[2,1,3]  R1109     1.1749300360679626e-01
    z[2,1,3]  R1110     2.9178312420845032e-01
    z[2,1,3]  R1111     5.5899225175380707e-02
    z[2,1,3]  R1112     3.2622328400611877e-01
    z[2,1,3]  R1113     -4.3790200352668762e-01
    z[2,1,3]  R1114     -0.609557569026947
    z[2,1,3]  R1115     1.0702575743198395e-01
    z[2,1,3]  R1116     6.5374052524566650e-01
    z[2,1,3]  R1117     2.7324968576431274e-01
    z[2,1,3]  R1118     3.3977967500686646e-01
    z[2,1,3]  R1119     -3.3968049287796021e-01
    z[2,1,3]  R1120     3.1409987807273865e-01
    z[2,1,3]  R1121     5.9229767322540283e-01
    z[2,1,3]  R1122     4.7588908672332764e-01
    z[2,1,3]  R1123     2.2977969050407410e-01
    z[2,1,3]  R1124     -4.4816818833351135e-01
    z[2,1,3]  R1125     -4.3633216619491577e-01
    z[2,1,3]  R1126     -4.2344403266906738e-01
    z[2,1,4]  R15       1
    z[2,1,4]  R24       -1
    z[2,1,4]  R1069     -1
    z[2,1,4]  R1070     1
    z[2,1,4]  R1075     2.6254183053970337e-01
    z[2,1,4]  R1076     -8.6453789472579956e-01
    z[2,1,4]  R1077     -5.0706136226654053e-01
    z[2,1,4]  R1078     -4.1331490874290466e-01
    z[2,1,4]  R1079     6.6439354419708252e-01
    z[2,1,4]  R1080     3.9260542392730713e-01
    z[2,1,4]  R1081     1.9915367662906647e-01
    z[2,1,4]  R1082     -1.9344860315322876e-01
    z[2,1,4]  R1083     -0.140597403049469
    z[2,1,4]  R1084     -2.5817906856536865e-01
    z[2,1,4]  R1085     -1.9860602915287018e-01
    z[2,1,4]  R1086     1.4874619245529175e-01
    z[2,1,4]  R1087     -1.6657146811485291e-01
    z[2,1,4]  R1088     3.2928335666656494e-01
    z[2,1,4]  R1089     3.4375011920928955e-01
    z[2,1,4]  R1090     1.2376535683870316e-02
    z[2,1,4]  R1091     -3.5774958133697510e-01
    z[2,1,4]  R1092     3.2629944384098053e-02
    z[2,1,4]  R1093     -0.175101175904274
    z[2,1,4]  R1094     2.4518145248293877e-02
    z[2,1,4]  R1095     -1.8213038146495819e-01
    z[2,1,4]  R1096     1.6555699706077576e-01
    z[2,1,4]  R1097     -0.0345456637442112
    z[2,1,4]  R1098     -1.6101695597171783e-02
    z[2,1,4]  R1099     0.273774117231369
    z[2,1,4]  R1100     0.355630487203598
    z[2,1,4]  R1101     -1.2609335780143738e-01
    z[2,1,4]  R1102     3.4994874149560928e-02
    z[2,1,4]  R1103     -2.8484666347503662e-01
    z[2,1,4]  R1104     -1.2254709750413895e-01
    z[2,1,4]  R1105     6.7818784713745117e-01
    z[2,1,4]  R1106     -7.3060697317123413e-01
    z[2,1,4]  R1107     4.3386703729629517e-01
    z[2,1,4]  R1108     1.1272528767585754e-01
    z[2,1,4]  R1109     1.1800088733434677e-01
    z[2,1,4]  R1110     3.5040014982223511e-01
    z[2,1,4]  R1111     -0.262971967458725
    z[2,1,4]  R1112     1.3726362586021423e-01
    z[2,1,4]  R1113     -9.2204205691814423e-02
    z[2,1,4]  R1114     -1.9371549785137177e-01
    z[2,1,4]  R1115     3.5541161894798279e-02
    z[2,1,4]  R1116     -2.0237004756927490e-01
    z[2,1,4]  R1117     1.2165561318397522e-01
    z[2,1,4]  R1118     -3.6070284247398376e-01
    z[2,1,4]  R1119     4.1045939922332764e-01
    z[2,1,4]  R1120     1.6668954864144325e-02
    z[2,1,4]  R1121     1.4215713739395142e-01
    z[2,1,4]  R1122     4.3430402874946594e-02
    z[2,1,4]  R1123     6.3840463757514954e-02
    z[2,1,4]  R1124     -1.2974040210247040e-01
    z[2,1,4]  R1125     -8.1952154636383057e-02
    z[2,1,4]  R1126     -1.8370974063873291e-01
    z[2,1,5]  R16       1
    z[2,1,5]  R25       -1
    z[2,1,5]  R1071     -1
    z[2,1,5]  R1072     1
    z[2,1,5]  R1075     2.2383647039532661e-02
    z[2,1,5]  R1076     1.7699062824249268e-01
    z[2,1,5]  R1077     -6.1907207965850830e-01
    z[2,1,5]  R1078     -5.1594501733779907e-01
    z[2,1,5]  R1079     -5.6261856108903885e-02
    z[2,1,5]  R1080     -2.1048752963542938e-01
    z[2,1,5]  R1081     -7.3773866891860962e-01
    z[2,1,5]  R1082     4.4551637768745422e-01
    z[2,1,5]  R1083     -6.9373883306980133e-02
    z[2,1,5]  R1084     3.4781849384307861e-01
    z[2,1,5]  R1085     -2.7797597646713257e-01
    z[2,1,5]  R1086     5.0542235374450684e-01
    z[2,1,5]  R1087     0.752040445804596
    z[2,1,5]  R1088     -0.677208662033081
    z[2,1,5]  R1089     -6.1743950843811035e-01
    z[2,1,5]  R1090     1.2394061684608459e-01
    z[2,1,5]  R1091     -2.2177100181579590e-01
    z[2,1,5]  R1092     -1.1052309721708298e-01
    z[2,1,5]  R1093     8.9796259999275208e-02
    z[2,1,5]  R1094     5.0441777706146240e-01
    z[2,1,5]  R1095     2.2709850966930389e-01
    z[2,1,5]  R1096     -4.9671435356140137e-01
    z[2,1,5]  R1097     -6.4993208646774292e-01
    z[2,1,5]  R1098     -4.6593353152275085e-01
    z[2,1,5]  R1099     -2.5010520219802856e-01
    z[2,1,5]  R1100     -0.0868993028998375
    z[2,1,5]  R1101     -7.3190785944461823e-02
    z[2,1,5]  R1102     5.1488876342773438e-01
    z[2,1,5]  R1103     5.1804476976394653e-01
    z[2,1,5]  R1104     2.9414954781532288e-01
    z[2,1,5]  R1105     -7.3558405041694641e-02
    z[2,1,5]  R1106     2.1748398244380951e-01
    z[2,1,5]  R1107     1.1583929508924484e-01
    z[2,1,5]  R1108     3.4561118483543396e-01
    z[2,1,5]  R1109     3.9490637183189392e-01
    z[2,1,5]  R1110     1.4406548440456390e-01
    z[2,1,5]  R1111     -0.0522085502743721
    z[2,1,5]  R1112     -2.1412852406501770e-01
    z[2,1,5]  R1113     -2.4928821623325348e-01
    z[2,1,5]  R1114     6.8778353743255138e-03
    z[2,1,5]  R1115     3.2511085271835327e-01
    z[2,1,5]  R1116     -2.6931858062744141e-01
    z[2,1,5]  R1117     -5.1344615221023560e-01
    z[2,1,5]  R1118     -5.2290058135986328e-01
    z[2,1,5]  R1119     5.3218550980091095e-02
    z[2,1,5]  R1120     -1.3850098848342896e-01
    z[2,1,5]  R1121     -6.3376188278198242e-02
    z[2,1,5]  R1122     -3.0528476834297180e-01
    z[2,1,5]  R1123     -4.8538818955421448e-01
    z[2,1,5]  R1124     -1.2154900282621384e-01
    z[2,1,5]  R1125     -6.7240279912948608e-01
    z[2,1,5]  R1126     -5.2716493606567383e-01
    z[2,1,6]  R17       1
    z[2,1,6]  R26       -1
    z[2,1,6]  R1073     -1
    z[2,1,6]  R1074     1
    z[2,1,6]  R1075     4.2301423847675323e-02
    z[2,1,6]  R1076     -9.4368137419223785e-02
    z[2,1,6]  R1077     4.2013907805085182e-03
    z[2,1,6]  R1078     5.5586183071136475e-01
    z[2,1,6]  R1079     -2.9565081000328064e-01
    z[2,1,6]  R1080     6.6208136081695557e-01
    z[2,1,6]  R1081     -2.7272674441337585e-01
    z[2,1,6]  R1082     3.4882771968841553e-01
    z[2,1,6]  R1083     -5.8689262717962265e-02
    z[2,1,6]  R1084     -3.6467951536178589e-01
    z[2,1,6]  R1085     -4.0321603417396545e-01
    z[2,1,6]  R1086     2.8979256749153137e-01
    z[2,1,6]  R1087     3.8762498646974564e-02
    z[2,1,6]  R1088     -5.0896149873733521e-01
    z[2,1,6]  R1089     4.4344786554574966e-02
    z[2,1,6]  R1090     -2.6802939176559448e-01
    z[2,1,6]  R1091     -1.5201157331466675e-01
    z[2,1,6]  R1092     4.5354485511779785e-02
    z[2,1,6]  R1093     -2.0940189063549042e-01
    z[2,1,6]  R1094     2.1116709709167480e-01
    z[2,1,6]  R1095     4.4861918687820435e-01
    z[2,1,6]  R1096     -5.2085243165493011e-02
    z[2,1,6]  R1097     -4.9371570348739624e-02
    z[2,1,6]  R1098     2.7766451239585876e-01
    z[2,1,6]  R1099     -5.5924034118652344e-01
    z[2,1,6]  R1100     3.5347905755043030e-01
    z[2,1,6]  R1101     -1.0372241586446762e-01
    z[2,1,6]  R1102     -4.4070154428482056e-02
    z[2,1,6]  R1103     1.7904048785567284e-02
    z[2,1,6]  R1104     3.6893460154533386e-01
    z[2,1,6]  R1105     -4.1801211237907410e-01
    z[2,1,6]  R1106     -6.7914955317974091e-02
    z[2,1,6]  R1107     1.4326995611190796e-01
    z[2,1,6]  R1108     1.2739814817905426e-01
    z[2,1,6]  R1109     -1.7883436381816864e-01
    z[2,1,6]  R1110     -1.5309639275074005e-01
    z[2,1,6]  R1111     1.7161594331264496e-01
    z[2,1,6]  R1112     6.5535253286361694e-01
    z[2,1,6]  R1113     0.557294487953186
    z[2,1,6]  R1114     2.5904360413551331e-01
    z[2,1,6]  R1115     0.709159791469574
    z[2,1,6]  R1116     -1.2396611273288727e-01
    z[2,1,6]  R1117     2.3874849081039429e-01
    z[2,1,6]  R1118     -1.4659132808446884e-02
    z[2,1,6]  R1119     4.7780883312225342e-01
    z[2,1,6]  R1120     -3.1167024746537209e-02
    z[2,1,6]  R1121     -1.1275658756494522e-01
    z[2,1,6]  R1122     2.0083774626255035e-01
    z[2,1,6]  R1123     -6.8739682435989380e-02
    z[2,1,6]  R1124     1.0149707645177841e-01
    z[2,1,6]  R1125     0.15589639544487
    z[2,1,6]  R1126     2.3175662755966187e-01
    z[1,6,0]  R11       -1
    z[1,6,0]  R56       1
    z[1,6,0]  R1127     -1
    z[1,6,0]  R1128     1
    z[1,6,0]  R1141     4.3224486708641052e-01
    z[1,6,0]  R1142     3.6659610271453857e-01
    z[1,6,0]  R1143     -8.1483668088912964e-01
    z[1,6,0]  R1144     -4.7504967451095581e-01
    z[1,6,0]  R1145     9.9776171147823334e-02
    z[1,6,0]  R1146     -2.4727405607700348e-01
    z[1,6,0]  R1147     -0.917407214641571
    z[1,6,0]  R1148     6.2808997929096222e-02
    z[1,6,0]  R1149     -0.308746337890625
    z[1,6,0]  R1150     -4.8761337995529175e-01
    z[1,6,0]  R1151     0.397777795791626
    z[1,6,0]  R1152     -4.1439205408096313e-01
    z[1,6,0]  R1153     1.4232541620731354e-01
    z[1,6,0]  R1154     -5.3590681403875351e-02
    z[1,6,0]  R1155     -2.6490634679794312e-01
    z[1,6,0]  R1156     -4.6500900387763977e-01
    z[1,6,0]  R1157     3.4500789642333984e-01
    z[1,6,0]  R1158     5.8319758623838425e-02
    z[1,6,0]  R1159     3.2757607102394104e-01
    z[1,6,0]  R1160     -4.6450477838516235e-01
    z[1,6,0]  R1161     -3.8021394610404968e-01
    z[1,6,0]  R1162     -4.2508924007415771e-01
    z[1,6,0]  R1163     7.6203301548957825e-02
    z[1,6,0]  R1164     3.6446052789688110e-01
    z[1,6,0]  R1165     3.8955527544021606e-01
    z[1,6,0]  R1166     3.9998903870582581e-01
    z[1,6,0]  R1167     3.8935866951942444e-01
    z[1,6,0]  R1168     3.3282566070556641e-01
    z[1,6,0]  R1169     -2.6747867465019226e-01
    z[1,6,0]  R1170     -1.6391228139400482e-01
    z[1,6,0]  R1171     -1.1296674609184265e-01
    z[1,6,0]  R1172     -1.7853356897830963e-01
    z[1,6,0]  R1173     -1.9356290996074677e-01
    z[1,6,0]  R1174     -3.5254049301147461e-01
    z[1,6,0]  R1175     -4.9616798758506775e-01
    z[1,6,0]  R1176     -2.5847837328910828e-01
    z[1,6,0]  R1177     -3.2877001166343689e-01
    z[1,6,0]  R1178     -1.1551152169704437e-01
    z[1,6,0]  R1179     -5.9576874971389771e-01
    z[1,6,0]  R1180     1.4361375570297241e-01
    z[1,6,0]  R1181     -3.2022818922996521e-01
    z[1,6,0]  R1182     -1.5970276296138763e-01
    z[1,6,0]  R1183     -7.2928392887115479e-01
    z[1,6,0]  R1184     -1.5947078168392181e-01
    z[1,6,0]  R1185     5.3713631629943848e-01
    z[1,6,0]  R1186     1.6378110647201538e-01
    z[1,6,0]  R1187     5.4045879840850830e-01
    z[1,6,0]  R1188     4.9611806869506836e-02
    z[1,6,0]  R1189     5.7317632436752319e-01
    z[1,6,0]  R1190     -1.4737339317798615e-01
    z[1,6,0]  R1191     0.0769510343670845
    z[1,6,0]  R1192     6.4041984081268311e-01
    z[1,6,0]  R1193     4.6904885768890381e-01
    z[1,6,0]  R1194     -8.2839828729629517e-01
    z[1,6,0]  R1195     -4.4422608613967896e-01
    z[1,6,0]  R1196     -8.6739659309387207e-05
    z[1,6,0]  R1197     5.7017225027084351e-01
    z[1,6,0]  R1198     -5.3395098447799683e-01
    z[1,6,0]  R1199     2.4247437715530396e-01
    z[1,6,0]  R1200     7.3009556531906128e-01
    z[1,6,0]  R1201     5.3689581155776978e-01
    z[1,6,0]  R1202     6.2699037790298462e-01
    z[1,6,0]  R1203     -4.0640029311180115e-01
    z[1,6,0]  R1204     -6.3726031780242920e-01
    z[1,6,0]  R1205     2.9142358899116516e-01
    z[1,6,0]  R1206     2.7225577831268311e-01
    z[1,6,0]  R1207     -4.4346490502357483e-01
    z[1,6,0]  R1208     4.4495406746864319e-01
    z[1,6,0]  R1209     -9.7905941307544708e-02
    z[1,6,0]  R1210     -5.1565051078796387e-01
    z[1,6,0]  R1211     -0.0890880599617958
    z[1,6,0]  R1212     2.0761384069919586e-01
    z[1,6,0]  R1213     -1.7567798495292664e-01
    z[1,6,0]  R1214     -1.4688614010810852e-01
    z[1,6,0]  R1215     -4.5699721574783325e-01
    z[1,6,0]  R1216     1.1366516351699829e-01
    z[1,6,0]  R1217     0.268271267414093
    z[1,6,0]  R1218     5.0068873167037964e-01
    z[1,6,0]  R1219     6.4537554979324341e-01
    z[1,6,0]  R1220     -4.0659990161657333e-02
    z[1,6,0]  R1221     -9.2636190354824066e-02
    z[1,6,0]  R1222     -3.9719808101654053e-01
    z[1,6,1]  R12       -1
    z[1,6,1]  R57       1
    z[1,6,1]  R1129     -1
    z[1,6,1]  R1130     1
    z[1,6,1]  R1141     -2.4835999310016632e-01
    z[1,6,1]  R1142     1.8533114343881607e-02
    z[1,6,1]  R1143     -1.2853796780109406e-01
    z[1,6,1]  R1144     7.6763892173767090e-01
    z[1,6,1]  R1145     8.7351602315902710e-01
    z[1,6,1]  R1146     0.82350754737854
    z[1,6,1]  R1147     1.2437266111373901e-01
    z[1,6,1]  R1148     6.2831938266754150e-01
    z[1,6,1]  R1149     -4.4275969266891479e-01
    z[1,6,1]  R1150     -3.4939491748809814e-01
    z[1,6,1]  R1151     -2.6593357324600220e-02
    z[1,6,1]  R1152     1.8808719515800476e-01
    z[1,6,1]  R1153     -4.7432509064674377e-01
    z[1,6,1]  R1154     -6.5710681676864624e-01
    z[1,6,1]  R1155     -1.7128066718578339e-01
    z[1,6,1]  R1156     5.2137100696563721e-01
    z[1,6,1]  R1157     6.6814243793487549e-01
    z[1,6,1]  R1158     7.3001396656036377e-01
    z[1,6,1]  R1159     7.4190747737884521e-01
    z[1,6,1]  R1160     -7.3118019104003906e-01
    z[1,6,1]  R1161     -0.425414115190506
    z[1,6,1]  R1162     -3.8223680853843689e-01
    z[1,6,1]  R1163     6.1162346601486206e-01
    z[1,6,1]  R1164     6.8455594778060913e-01
    z[1,6,1]  R1165     5.9001648426055908e-01
    z[1,6,1]  R1166     4.4077399373054504e-01
    z[1,6,1]  R1167     5.4034572839736938e-01
    z[1,6,1]  R1168     8.1180453300476074e-01
    z[1,6,1]  R1169     3.6116382479667664e-01
    z[1,6,1]  R1170     3.5026282072067261e-01
    z[1,6,1]  R1171     3.2761648297309875e-01
    z[1,6,1]  R1172     4.8268094658851624e-01
    z[1,6,1]  R1173     -9.0482914447784424e-01
    z[1,6,1]  R1174     -8.5679125785827637e-01
    z[1,6,1]  R1175     -0.746425211429596
    z[1,6,1]  R1176     -8.7104260921478271e-01
    z[1,6,1]  R1177     -8.7729436159133911e-01
    z[1,6,1]  R1178     -6.8070882558822632e-01
    z[1,6,1]  R1179     -6.4351511001586914e-01
    z[1,6,1]  R1180     -5.6441736221313477e-01
    z[1,6,1]  R1181     -6.4501452445983887e-01
    z[1,6,1]  R1182     -6.6356188058853149e-01
    z[1,6,1]  R1183     5.0011169910430908e-01
    z[1,6,1]  R1184     -4.6965089440345764e-01
    z[1,6,1]  R1185     -1.2971398234367371e-01
    z[1,6,1]  R1186     0.0066000921651721
    z[1,6,1]  R1187     -2.2840197384357452e-01
    z[1,6,1]  R1188     -2.7539052069187164e-02
    z[1,6,1]  R1189     -2.3782984912395477e-01
    z[1,6,1]  R1190     5.2312824875116348e-02
    z[1,6,1]  R1191     6.6013656556606293e-02
    z[1,6,1]  R1192     -2.9741770029067993e-01
    z[1,6,1]  R1193     1.8457408249378204e-01
    z[1,6,1]  R1194     7.5507219880819321e-03
    z[1,6,1]  R1195     2.5539350509643555e-01
    z[1,6,1]  R1196     -5.0007468461990356e-01
    z[1,6,1]  R1197     3.8062937557697296e-02
    z[1,6,1]  R1198     4.4514108449220657e-02
    z[1,6,1]  R1199     5.1867380738258362e-02
    z[1,6,1]  R1200     -1.7568904161453247e-01
    z[1,6,1]  R1201     -8.0612100660800934e-02
    z[1,6,1]  R1202     -1.5621571242809296e-01
    z[1,6,1]  R1203     -7.9453057050704956e-01
    z[1,6,1]  R1204     1.1819142103195190e-01
    z[1,6,1]  R1205     5.6701959110796452e-03
    z[1,6,1]  R1206     0.311960905790329
    z[1,6,1]  R1207     -7.0481783151626587e-01
    z[1,6,1]  R1208     -2.2319043055176735e-02
    z[1,6,1]  R1209     2.4448089301586151e-01
    z[1,6,1]  R1210     -7.0130831003189087e-01
    z[1,6,1]  R1211     6.2961626052856445e-01
    z[1,6,1]  R1212     -5.6727476418018341e-02
    z[1,6,1]  R1213     3.1559771299362183e-01
    z[1,6,1]  R1214     -3.6972990632057190e-01
    z[1,6,1]  R1215     -8.2249885797500610e-01
    z[1,6,1]  R1216     2.7130961418151855e-01
    z[1,6,1]  R1217     1.1103488504886627e-01
    z[1,6,1]  R1218     -2.3097580671310425e-01
    z[1,6,1]  R1219     1.4612478017807007e-01
    z[1,6,1]  R1220     -7.4920791387557983e-01
    z[1,6,1]  R1221     -5.8395504951477051e-01
    z[1,6,1]  R1222     -5.6713259220123291e-01
    z[1,6,2]  R13       -1
    z[1,6,2]  R58       1
    z[1,6,2]  R1131     -1
    z[1,6,2]  R1132     1
    z[1,6,2]  R1141     -0.229964017868042
    z[1,6,2]  R1142     4.0561392903327942e-01
    z[1,6,2]  R1143     3.0907127261161804e-01
    z[1,6,2]  R1144     1.8937484920024872e-01
    z[1,6,2]  R1145     -1.0655014961957932e-01
    z[1,6,2]  R1146     9.2627935111522675e-02
    z[1,6,2]  R1147     1.9605781137943268e-01
    z[1,6,2]  R1148     -2.5864368304610252e-02
    z[1,6,2]  R1149     -3.6831769347190857e-01
    z[1,6,2]  R1150     -4.0486955642700195e-01
    z[1,6,2]  R1151     -4.6876770257949829e-01
    z[1,6,2]  R1152     -4.8648950457572937e-01
    z[1,6,2]  R1153     5.8708250522613525e-01
    z[1,6,2]  R1154     -2.1480685472488403e-01
    z[1,6,2]  R1155     6.2088185548782349e-01
    z[1,6,2]  R1156     6.2677621841430664e-01
    z[1,6,2]  R1157     2.1633145213127136e-01
    z[1,6,2]  R1158     0.319040983915329
    z[1,6,2]  R1159     2.1228766441345215e-01
    z[1,6,2]  R1160     -0.082750104367733
    z[1,6,2]  R1161     -3.0480343848466873e-02
    z[1,6,2]  R1162     -3.5850539803504944e-01
    z[1,6,2]  R1163     6.5307760238647461e-01
    z[1,6,2]  R1164     4.8185011744499207e-01
    z[1,6,2]  R1165     5.3949570655822754e-01
    z[1,6,2]  R1166     5.0236654281616211e-01
    z[1,6,2]  R1167     4.2099103331565857e-01
    z[1,6,2]  R1168     3.7018394470214844e-01
    z[1,6,2]  R1169     -5.2113026380538940e-01
    z[1,6,2]  R1170     -4.8376509547233582e-01
    z[1,6,2]  R1171     -7.8418493270874023e-01
    z[1,6,2]  R1172     -8.1867128610610962e-01
    z[1,6,2]  R1173     1.8444927036762238e-01
    z[1,6,2]  R1174     -1.3395757414400578e-02
    z[1,6,2]  R1175     1.6011258959770203e-01
    z[1,6,2]  R1176     -4.8764474689960480e-02
    z[1,6,2]  R1177     -2.2412322461605072e-01
    z[1,6,2]  R1178     6.8242150545120239e-01
    z[1,6,2]  R1179     -2.8009975329041481e-02
    z[1,6,2]  R1180     5.6274402141571045e-01
    z[1,6,2]  R1181     6.0653007030487061e-01
    z[1,6,2]  R1182     -2.1084873378276825e-01
    z[1,6,2]  R1183     -1.5013836324214935e-01
    z[1,6,2]  R1184     8.1123101711273193e-01
    z[1,6,2]  R1185     -6.7830908298492432e-01
    z[1,6,2]  R1186     5.9358769655227661e-01
    z[1,6,2]  R1187     -7.2841954231262207e-01
    z[1,6,2]  R1188     4.0486451983451843e-01
    z[1,6,2]  R1189     -6.5329098701477051e-01
    z[1,6,2]  R1190     4.2163950204849243e-01
    z[1,6,2]  R1191     1.7427203059196472e-01
    z[1,6,2]  R1192     -5.5641597509384155e-01
    z[1,6,2]  R1193     0.533997118473053
    z[1,6,2]  R1194     -9.4141222536563873e-02
    z[1,6,2]  R1195     -3.4328576922416687e-01
    z[1,6,2]  R1196     7.7171623706817627e-01
    z[1,6,2]  R1197     -6.3166123628616333e-01
    z[1,6,2]  R1198     -4.6719151735305786e-01
    z[1,6,2]  R1199     7.1479961276054382e-02
    z[1,6,2]  R1200     1.4302076399326324e-01
    z[1,6,2]  R1201     3.5709220916032791e-02
    z[1,6,2]  R1202     -6.6773869097232819e-02
    z[1,6,2]  R1203     3.0150640010833740e-01
    z[1,6,2]  R1204     5.7649750262498856e-02
    z[1,6,2]  R1205     2.9062870144844055e-01
    z[1,6,2]  R1206     -1.0436808317899704e-01
    z[1,6,2]  R1207     -1.2822796404361725e-01
    z[1,6,2]  R1208     1.3974268734455109e-01
    z[1,6,2]  R1209     3.3458107709884644e-01
    z[1,6,2]  R1210     -2.1774242818355560e-01
    z[1,6,2]  R1211     -1.1213681101799011e-01
    z[1,6,2]  R1212     -7.5407058000564575e-01
    z[1,6,2]  R1213     -5.7629472017288208e-01
    z[1,6,2]  R1214     8.7407833337783813e-01
    z[1,6,2]  R1215     -3.0261540785431862e-02
    z[1,6,2]  R1216     2.0813831686973572e-01
    z[1,6,2]  R1217     -9.4895833730697632e-01
    z[1,6,2]  R1218     -0.669061005115509
    z[1,6,2]  R1219     -1.8745658919215202e-02
    z[1,6,2]  R1220     1.6331587731838226e-01
    z[1,6,2]  R1221     3.9022177457809448e-02
    z[1,6,2]  R1222     -1.0737180709838867e-01
    z[1,6,3]  R14       -1
    z[1,6,3]  R59       1
    z[1,6,3]  R1133     -1
    z[1,6,3]  R1134     1
    z[1,6,3]  R1141     -2.4189765751361847e-01
    z[1,6,3]  R1142     -3.3917987346649170e-01
    z[1,6,3]  R1143     4.2526509612798691e-02
    z[1,6,3]  R1144     2.8479378670454025e-02
    z[1,6,3]  R1145     1.1749300360679626e-01
    z[1,6,3]  R1146     2.9178312420845032e-01
    z[1,6,3]  R1147     5.5899225175380707e-02
    z[1,6,3]  R1148     3.2622328400611877e-01
    z[1,6,3]  R1149     -4.3790200352668762e-01
    z[1,6,3]  R1150     -0.609557569026947
    z[1,6,3]  R1151     1.0702575743198395e-01
    z[1,6,3]  R1152     6.5374052524566650e-01
    z[1,6,3]  R1153     2.7324968576431274e-01
    z[1,6,3]  R1154     3.3977967500686646e-01
    z[1,6,3]  R1155     -3.3968049287796021e-01
    z[1,6,3]  R1156     3.1409987807273865e-01
    z[1,6,3]  R1157     5.9229767322540283e-01
    z[1,6,3]  R1158     4.7588908672332764e-01
    z[1,6,3]  R1159     2.2977969050407410e-01
    z[1,6,3]  R1160     -4.4816818833351135e-01
    z[1,6,3]  R1161     -4.3633216619491577e-01
    z[1,6,3]  R1162     -4.2344403266906738e-01
    z[1,6,3]  R1163     -1.7735873162746429e-01
    z[1,6,3]  R1164     -7.2166711091995239e-02
    z[1,6,3]  R1165     -3.6421704292297363e-01
    z[1,6,3]  R1166     -1.6406776383519173e-02
    z[1,6,3]  R1167     -3.6862000823020935e-02
    z[1,6,3]  R1168     7.6529145240783691e-02
    z[1,6,3]  R1169     -5.0604915618896484e-01
    z[1,6,3]  R1170     -2.8454324603080750e-01
    z[1,6,3]  R1171     1.4922952651977539e-01
    z[1,6,3]  R1172     2.3323077708482742e-02
    z[1,6,3]  R1173     2.2303119301795959e-01
    z[1,6,3]  R1174     3.0072297900915146e-02
    z[1,6,3]  R1175     -1.5407598018646240e-01
    z[1,6,3]  R1176     -1.4522799849510193e-01
    z[1,6,3]  R1177     -5.2057329565286636e-02
    z[1,6,3]  R1178     4.7645575250498950e-04
    z[1,6,3]  R1179     -1.5810810029506683e-02
    z[1,6,3]  R1180     1.1137538403272629e-01
    z[1,6,3]  R1181     -1.4453551173210144e-01
    z[1,6,3]  R1182     -6.6462743282318115e-01
    z[1,6,3]  R1183     -1.1206272989511490e-01
    z[1,6,3]  R1184     2.1960420906543732e-01
    z[1,6,3]  R1185     2.1484570205211639e-01
    z[1,6,3]  R1186     6.5667057037353516e-01
    z[1,6,3]  R1187     2.0240142941474915e-01
    z[1,6,3]  R1188     4.0234780311584473e-01
    z[1,6,3]  R1189     -3.4329872578382492e-02
    z[1,6,3]  R1190     2.8709346055984497e-01
    z[1,6,3]  R1191     8.9333295822143555e-01
    z[1,6,3]  R1192     2.7548578381538391e-01
    z[1,6,3]  R1193     -1.5493296086788177e-01
    z[1,6,3]  R1194     3.1071117520332336e-01
    z[1,6,3]  R1195     4.4686415791511536e-01
    z[1,6,3]  R1196     -1.8663607537746429e-01
    z[1,6,3]  R1197     3.4587290883064270e-01
    z[1,6,3]  R1198     1.8540048599243164e-01
    z[1,6,3]  R1199     4.5564615726470947e-01
    z[1,6,3]  R1200     3.4619012475013733e-01
    z[1,6,3]  R1201     6.1684612184762955e-02
    z[1,6,3]  R1202     2.7708551287651062e-01
    z[1,6,3]  R1203     2.7882652357220650e-02
    z[1,6,3]  R1204     2.9548335075378418e-01
    z[1,6,3]  R1205     6.4322352409362793e-01
    z[1,6,3]  R1206     0.0772358700633049
    z[1,6,3]  R1207     4.0807634592056274e-01
    z[1,6,3]  R1208     4.4087588787078857e-01
    z[1,6,3]  R1209     8.4481775760650635e-01
    z[1,6,3]  R1210     -1.0306950658559799e-01
    z[1,6,3]  R1211     5.0641906261444092e-01
    z[1,6,3]  R1212     2.6382520794868469e-01
    z[1,6,3]  R1213     -3.1905156373977661e-01
    z[1,6,3]  R1214     -1.2970322370529175e-01
    z[1,6,3]  R1215     2.6195693016052246e-01
    z[1,6,3]  R1216     0.744918942451477
    z[1,6,3]  R1217     1.3488547876477242e-02
    z[1,6,3]  R1218     1.7731359601020813e-01
    z[1,6,3]  R1219     4.5670741796493530e-01
    z[1,6,3]  R1220     -0.512614369392395
    z[1,6,3]  R1221     -4.7568336129188538e-01
    z[1,6,3]  R1222     3.3361083269119263e-01
    z[1,6,4]  R15       -1
    z[1,6,4]  R60       1
    z[1,6,4]  R1135     -1
    z[1,6,4]  R1136     1
    z[1,6,4]  R1141     6.7818784713745117e-01
    z[1,6,4]  R1142     -7.3060697317123413e-01
    z[1,6,4]  R1143     4.3386703729629517e-01
    z[1,6,4]  R1144     1.1272528767585754e-01
    z[1,6,4]  R1145     1.1800088733434677e-01
    z[1,6,4]  R1146     3.5040014982223511e-01
    z[1,6,4]  R1147     -0.262971967458725
    z[1,6,4]  R1148     1.3726362586021423e-01
    z[1,6,4]  R1149     -9.2204205691814423e-02
    z[1,6,4]  R1150     -1.9371549785137177e-01
    z[1,6,4]  R1151     3.5541161894798279e-02
    z[1,6,4]  R1152     -2.0237004756927490e-01
    z[1,6,4]  R1153     1.2165561318397522e-01
    z[1,6,4]  R1154     -3.6070284247398376e-01
    z[1,6,4]  R1155     4.1045939922332764e-01
    z[1,6,4]  R1156     1.6668954864144325e-02
    z[1,6,4]  R1157     1.4215713739395142e-01
    z[1,6,4]  R1158     4.3430402874946594e-02
    z[1,6,4]  R1159     6.3840463757514954e-02
    z[1,6,4]  R1160     -1.2974040210247040e-01
    z[1,6,4]  R1161     -8.1952154636383057e-02
    z[1,6,4]  R1162     -1.8370974063873291e-01
    z[1,6,4]  R1163     3.0931377410888672e-01
    z[1,6,4]  R1164     -1.0533689707517624e-01
    z[1,6,4]  R1165     -3.9524812251329422e-02
    z[1,6,4]  R1166     -4.2555180191993713e-01
    z[1,6,4]  R1167     1.2045098841190338e-01
    z[1,6,4]  R1168     1.0959753394126892e-01
    z[1,6,4]  R1169     -5.9787888079881668e-02
    z[1,6,4]  R1170     3.0749875307083130e-01
    z[1,6,4]  R1171     5.5037878453731537e-02
    z[1,6,4]  R1172     -1.9136065244674683e-01
    z[1,6,4]  R1173     -2.1240387856960297e-01
    z[1,6,4]  R1174     -1.2740857899188995e-01
    z[1,6,4]  R1175     2.3785457015037537e-01
    z[1,6,4]  R1176     -3.0441511422395706e-02
    z[1,6,4]  R1177     -1.1305811256170273e-01
    z[1,6,4]  R1178     -1.8227986991405487e-01
    z[1,6,4]  R1179     4.3938314914703369e-01
    z[1,6,4]  R1180     -3.6281594634056091e-01
    z[1,6,4]  R1181     1.8025094270706177e-01
    z[1,6,4]  R1182     -7.6935626566410065e-02
    z[1,6,4]  R1183     3.2748109102249146e-01
    z[1,6,4]  R1184     1.4197234809398651e-01
    z[1,6,4]  R1185     -9.6101216971874237e-02
    z[1,6,4]  R1186     -1.2907008826732635e-01
    z[1,6,4]  R1187     -1.4035013318061829e-01
    z[1,6,4]  R1188     -1.7884099856019020e-02
    z[1,6,4]  R1189     3.0120092630386353e-01
    z[1,6,4]  R1190     4.3370419740676880e-01
    z[1,6,4]  R1191     -6.7534692585468292e-02
    z[1,6,4]  R1192     6.7070230841636658e-02
    z[1,6,4]  R1193     -4.2729938030242920e-01
    z[1,6,4]  R1194     3.8238272070884705e-01
    z[1,6,4]  R1195     1.5390522778034210e-01
    z[1,6,4]  R1196     -2.1807695925235748e-01
    z[1,6,4]  R1197     3.8307970762252808e-01
    z[1,6,4]  R1198     5.5730640888214111e-01
    z[1,6,4]  R1199     -1.3726758956909180e-01
    z[1,6,4]  R1200     3.5945403575897217e-01
    z[1,6,4]  R1201     5.9789609909057617e-01
    z[1,6,4]  R1202     3.2487982511520386e-01
    z[1,6,4]  R1203     1.8357923254370689e-02
    z[1,6,4]  R1204     1.6997136175632477e-02
    z[1,6,4]  R1205     2.2530054673552513e-02
    z[1,6,4]  R1206     7.1387737989425659e-02
    z[1,6,4]  R1207     5.3474036976695061e-03
    z[1,6,4]  R1208     -3.0325773358345032e-01
    z[1,6,4]  R1209     2.4515953660011292e-01
    z[1,6,4]  R1210     3.9190939068794250e-01
    z[1,6,4]  R1211     4.7103419899940491e-01
    z[1,6,4]  R1212     3.1757593154907227e-02
    z[1,6,4]  R1213     5.3931981325149536e-01
    z[1,6,4]  R1214     8.1775300204753876e-02
    z[1,6,4]  R1215     2.9924826696515083e-02
    z[1,6,4]  R1216     4.9881532788276672e-02
    z[1,6,4]  R1217     7.0591926574707031e-02
    z[1,6,4]  R1218     3.9975631237030029e-01
    z[1,6,4]  R1219     -3.8714587688446045e-01
    z[1,6,4]  R1220     -3.4964978694915771e-01
    z[1,6,4]  R1221     -3.7415459752082825e-01
    z[1,6,4]  R1222     3.8348725438117981e-01
    z[1,6,5]  R16       -1
    z[1,6,5]  R61       1
    z[1,6,5]  R1137     -1
    z[1,6,5]  R1138     1
    z[1,6,5]  R1141     -7.3558405041694641e-02
    z[1,6,5]  R1142     2.1748398244380951e-01
    z[1,6,5]  R1143     1.1583929508924484e-01
    z[1,6,5]  R1144     3.4561118483543396e-01
    z[1,6,5]  R1145     3.9490637183189392e-01
    z[1,6,5]  R1146     1.4406548440456390e-01
    z[1,6,5]  R1147     -0.0522085502743721
    z[1,6,5]  R1148     -2.1412852406501770e-01
    z[1,6,5]  R1149     -2.4928821623325348e-01
    z[1,6,5]  R1150     6.8778353743255138e-03
    z[1,6,5]  R1151     3.2511085271835327e-01
    z[1,6,5]  R1152     -2.6931858062744141e-01
    z[1,6,5]  R1153     -5.1344615221023560e-01
    z[1,6,5]  R1154     -5.2290058135986328e-01
    z[1,6,5]  R1155     5.3218550980091095e-02
    z[1,6,5]  R1156     -1.3850098848342896e-01
    z[1,6,5]  R1157     -6.3376188278198242e-02
    z[1,6,5]  R1158     -3.0528476834297180e-01
    z[1,6,5]  R1159     -4.8538818955421448e-01
    z[1,6,5]  R1160     -1.2154900282621384e-01
    z[1,6,5]  R1161     -6.7240279912948608e-01
    z[1,6,5]  R1162     -5.2716493606567383e-01
    z[1,6,5]  R1163     -1.4910748600959778e-01
    z[1,6,5]  R1164     2.3642964661121368e-01
    z[1,6,5]  R1165     2.6192072033882141e-01
    z[1,6,5]  R1166     -2.4893982335925102e-02
    z[1,6,5]  R1167     1.1403822153806686e-01
    z[1,6,5]  R1168     -2.0856025815010071e-01
    z[1,6,5]  R1169     4.7178804874420166e-01
    z[1,6,5]  R1170     6.6391664743423462e-01
    z[1,6,5]  R1171     3.8924831151962280e-01
    z[1,6,5]  R1172     1.2152110785245895e-01
    z[1,6,5]  R1173     2.1437183022499084e-02
    z[1,6,5]  R1174     1.3909088075160980e-01
    z[1,6,5]  R1175     1.1812205612659454e-01
    z[1,6,5]  R1176     3.7348988652229309e-01
    z[1,6,5]  R1177     -2.3512698709964752e-01
    z[1,6,5]  R1178     -4.9178179353475571e-02
    z[1,6,5]  R1179     -1.8666283786296844e-01
    z[1,6,5]  R1180     4.4221282005310059e-01
    z[1,6,5]  R1181     -2.4498255550861359e-01
    z[1,6,5]  R1182     -1.5540733933448792e-01
    z[1,6,5]  R1183     -1.5384857356548309e-01
    z[1,6,5]  R1184     1.3855701684951782e-01
    z[1,6,5]  R1185     -2.4059610068798065e-01
    z[1,6,5]  R1186     -2.6186150312423706e-01
    z[1,6,5]  R1187     -2.3836867511272430e-01
    z[1,6,5]  R1188     7.9744279384613037e-01
    z[1,6,5]  R1189     -2.9433470964431763e-01
    z[1,6,5]  R1190     7.2514837980270386e-01
    z[1,6,5]  R1191     3.7951439619064331e-01
    z[1,6,5]  R1192     -3.2458725571632385e-01
    z[1,6,5]  R1193     -4.4477206468582153e-01
    z[1,6,5]  R1194     -8.5610244423151016e-03
    z[1,6,5]  R1195     4.2908897995948792e-01
    z[1,6,5]  R1196     0.0865989699959755
    z[1,6,5]  R1197     -6.7275352776050568e-02
    z[1,6,5]  R1198     -3.2819861173629761e-01
    z[1,6,5]  R1199     7.9767984151840210e-01
    z[1,6,5]  R1200     3.5359352827072144e-01
    z[1,6,5]  R1201     5.2157509326934814e-01
    z[1,6,5]  R1202     6.2777698040008545e-01
    z[1,6,5]  R1203     -1.5226955711841583e-01
    z[1,6,5]  R1204     2.4852935969829559e-01
    z[1,6,5]  R1205     6.4453983306884766e-01
    z[1,6,5]  R1206     8.9482986927032471e-01
    z[1,6,5]  R1207     -2.9989114403724670e-01
    z[1,6,5]  R1208     6.8360632658004761e-01
    z[1,6,5]  R1209     2.0597076416015625e-01
    z[1,6,5]  R1210     5.3643468767404556e-02
    z[1,6,5]  R1211     3.2350286841392517e-01
    z[1,6,5]  R1212     7.4796602129936218e-02
    z[1,6,5]  R1213     -8.3849526941776276e-02
    z[1,6,5]  R1214     -1.0466530919075012e-01
    z[1,6,5]  R1215     -1.0526506602764130e-01
    z[1,6,5]  R1216     5.5378687381744385e-01
    z[1,6,5]  R1217     -4.9198679625988007e-02
    z[1,6,5]  R1218     2.0749524235725403e-01
    z[1,6,5]  R1219     4.2804643511772156e-01
    z[1,6,5]  R1220     3.4910753369331360e-02
    z[1,6,5]  R1221     -3.4486436843872070e-01
    z[1,6,5]  R1222     -1.7774419859051704e-02
    z[1,6,6]  R17       -1
    z[1,6,6]  R62       1
    z[1,6,6]  R1139     -1
    z[1,6,6]  R1140     1
    z[1,6,6]  R1141     -4.1801211237907410e-01
    z[1,6,6]  R1142     -6.7914955317974091e-02
    z[1,6,6]  R1143     1.4326995611190796e-01
    z[1,6,6]  R1144     1.2739814817905426e-01
    z[1,6,6]  R1145     -1.7883436381816864e-01
    z[1,6,6]  R1146     -1.5309639275074005e-01
    z[1,6,6]  R1147     1.7161594331264496e-01
    z[1,6,6]  R1148     6.5535253286361694e-01
    z[1,6,6]  R1149     0.557294487953186
    z[1,6,6]  R1150     2.5904360413551331e-01
    z[1,6,6]  R1151     0.709159791469574
    z[1,6,6]  R1152     -1.2396611273288727e-01
    z[1,6,6]  R1153     2.3874849081039429e-01
    z[1,6,6]  R1154     -1.4659132808446884e-02
    z[1,6,6]  R1155     4.7780883312225342e-01
    z[1,6,6]  R1156     -3.1167024746537209e-02
    z[1,6,6]  R1157     -1.1275658756494522e-01
    z[1,6,6]  R1158     2.0083774626255035e-01
    z[1,6,6]  R1159     -6.8739682435989380e-02
    z[1,6,6]  R1160     1.0149707645177841e-01
    z[1,6,6]  R1161     0.15589639544487
    z[1,6,6]  R1162     2.3175662755966187e-01
    z[1,6,6]  R1163     -2.1032159030437469e-01
    z[1,6,6]  R1164     -3.0687007308006287e-01
    z[1,6,6]  R1165     -7.9074859619140625e-02
    z[1,6,6]  R1166     -0.459751695394516
    z[1,6,6]  R1167     5.9187906980514526e-01
    z[1,6,6]  R1168     1.7832185328006744e-01
    z[1,6,6]  R1169     -2.1022546291351318e-01
    z[1,6,6]  R1170     1.0699690319597721e-02
    z[1,6,6]  R1171     -2.9689574241638184e-01
    z[1,6,6]  R1172     1.1398231983184814e-01
    z[1,6,6]  R1173     1.2032502889633179e-01
    z[1,6,6]  R1174     -3.2397669553756714e-01
    z[1,6,6]  R1175     -2.7706235647201538e-01
    z[1,6,6]  R1176     1.0287478566169739e-01
    z[1,6,6]  R1177     3.5452261567115784e-02
    z[1,6,6]  R1178     -1.4815139770507812e-01
    z[1,6,6]  R1179     -4.4864334166049957e-02
    z[1,6,6]  R1180     6.7343883216381073e-02
    z[1,6,6]  R1181     -1.1576295830309391e-02
    z[1,6,6]  R1182     1.3387800753116608e-01
    z[1,6,6]  R1183     2.2807975113391876e-01
    z[1,6,6]  R1184     9.1220222413539886e-02
    z[1,6,6]  R1185     -3.4824568033218384e-01
    z[1,6,6]  R1186     3.2301548123359680e-01
    z[1,6,6]  R1187     0.0875079482793808
    z[1,6,6]  R1188     -1.8640391528606415e-01
    z[1,6,6]  R1189     0.0978948324918747
    z[1,6,6]  R1190     3.7448275834321976e-02
    z[1,6,6]  R1191     1.1275637149810791e-01
    z[1,6,6]  R1192     -7.7837914228439331e-02
    z[1,6,6]  R1193     2.3740540444850922e-01
    z[1,6,6]  R1194     0.249008908867836
    z[1,6,6]  R1195     4.6054357290267944e-01
    z[1,6,6]  R1196     -2.5394740700721741e-01
    z[1,6,6]  R1197     5.9621725231409073e-02
    z[1,6,6]  R1198     -2.0486259460449219e-01
    z[1,6,6]  R1199     2.6581510901451111e-01
    z[1,6,6]  R1200     -2.0385244488716125e-01
    z[1,6,6]  R1201     -2.6578944921493530e-01
    z[1,6,6]  R1202     3.9920575916767120e-02
    z[1,6,6]  R1203     -2.9724302887916565e-01
    z[1,6,6]  R1204     -6.5363639593124390e-01
    z[1,6,6]  R1205     -0.0299916360527277
    z[1,6,6]  R1206     7.6696924865245819e-02
    z[1,6,6]  R1207     -1.8340897560119629e-01
    z[1,6,6]  R1208     1.6833055019378662e-01
    z[1,6,6]  R1209     -4.9545396119356155e-02
    z[1,6,6]  R1210     1.6663007438182831e-01
    z[1,6,6]  R1211     -9.1901179403066635e-03
    z[1,6,6]  R1212     0.555742084980011
    z[1,6,6]  R1213     3.7111893296241760e-01
    z[1,6,6]  R1214     -2.0795795321464539e-01
    z[1,6,6]  R1215     -1.8203240633010864e-01
    z[1,6,6]  R1216     0.0779573991894722
    z[1,6,6]  R1217     8.7144345045089722e-02
    z[1,6,6]  R1218     -1.1840105056762695e-01
    z[1,6,6]  R1219     1.4177146553993225e-01
    z[1,6,6]  R1220     -1.5528991818428040e-01
    z[1,6,6]  R1221     -4.0459185838699341e-01
    z[1,6,6]  R1222     5.0039076805114746e-01
    z[6,1,0]  R11       1
    z[6,1,0]  R56       -1
    z[6,1,0]  R1223     -1
    z[6,1,0]  R1224     1
    z[6,1,0]  R1237     7.6203301548957825e-02
    z[6,1,0]  R1238     3.6446052789688110e-01
    z[6,1,0]  R1239     3.8955527544021606e-01
    z[6,1,0]  R1240     3.9998903870582581e-01
    z[6,1,0]  R1241     3.8935866951942444e-01
    z[6,1,0]  R1242     3.3282566070556641e-01
    z[6,1,0]  R1243     -2.6747867465019226e-01
    z[6,1,0]  R1244     -1.6391228139400482e-01
    z[6,1,0]  R1245     -1.1296674609184265e-01
    z[6,1,0]  R1246     -1.7853356897830963e-01
    z[6,1,0]  R1247     -1.9356290996074677e-01
    z[6,1,0]  R1248     -3.5254049301147461e-01
    z[6,1,0]  R1249     -4.9616798758506775e-01
    z[6,1,0]  R1250     -2.5847837328910828e-01
    z[6,1,0]  R1251     -3.2877001166343689e-01
    z[6,1,0]  R1252     -1.1551152169704437e-01
    z[6,1,0]  R1253     -5.9576874971389771e-01
    z[6,1,0]  R1254     1.4361375570297241e-01
    z[6,1,0]  R1255     -3.2022818922996521e-01
    z[6,1,0]  R1256     -1.5970276296138763e-01
    z[6,1,0]  R1257     -7.2928392887115479e-01
    z[6,1,0]  R1258     -1.5947078168392181e-01
    z[6,1,0]  R1259     5.3713631629943848e-01
    z[6,1,0]  R1260     1.6378110647201538e-01
    z[6,1,0]  R1261     5.4045879840850830e-01
    z[6,1,0]  R1262     4.9611806869506836e-02
    z[6,1,0]  R1263     5.7317632436752319e-01
    z[6,1,0]  R1264     -1.4737339317798615e-01
    z[6,1,0]  R1265     0.0769510343670845
    z[6,1,0]  R1266     6.4041984081268311e-01
    z[6,1,0]  R1267     4.6904885768890381e-01
    z[6,1,0]  R1268     -8.2839828729629517e-01
    z[6,1,0]  R1269     -4.4422608613967896e-01
    z[6,1,0]  R1270     -8.6739659309387207e-05
    z[6,1,0]  R1271     5.7017225027084351e-01
    z[6,1,0]  R1272     -5.3395098447799683e-01
    z[6,1,0]  R1273     2.4247437715530396e-01
    z[6,1,0]  R1274     7.3009556531906128e-01
    z[6,1,0]  R1275     5.3689581155776978e-01
    z[6,1,0]  R1276     6.2699037790298462e-01
    z[6,1,0]  R1277     -4.0640029311180115e-01
    z[6,1,0]  R1278     -6.3726031780242920e-01
    z[6,1,0]  R1279     2.9142358899116516e-01
    z[6,1,0]  R1280     2.7225577831268311e-01
    z[6,1,0]  R1281     -4.4346490502357483e-01
    z[6,1,0]  R1282     4.4495406746864319e-01
    z[6,1,0]  R1283     -9.7905941307544708e-02
    z[6,1,0]  R1284     -5.1565051078796387e-01
    z[6,1,0]  R1285     -0.0890880599617958
    z[6,1,0]  R1286     2.0761384069919586e-01
    z[6,1,0]  R1287     -1.7567798495292664e-01
    z[6,1,0]  R1288     -1.4688614010810852e-01
    z[6,1,0]  R1289     -4.5699721574783325e-01
    z[6,1,0]  R1290     1.1366516351699829e-01
    z[6,1,0]  R1291     0.268271267414093
    z[6,1,0]  R1292     5.0068873167037964e-01
    z[6,1,0]  R1293     6.4537554979324341e-01
    z[6,1,0]  R1294     -4.0659990161657333e-02
    z[6,1,0]  R1295     -9.2636190354824066e-02
    z[6,1,0]  R1296     -3.9719808101654053e-01
    z[6,1,0]  R1297     4.3224486708641052e-01
    z[6,1,0]  R1298     3.6659610271453857e-01
    z[6,1,0]  R1299     -8.1483668088912964e-01
    z[6,1,0]  R1300     -4.7504967451095581e-01
    z[6,1,0]  R1301     9.9776171147823334e-02
    z[6,1,0]  R1302     -2.4727405607700348e-01
    z[6,1,0]  R1303     -0.917407214641571
    z[6,1,0]  R1304     6.2808997929096222e-02
    z[6,1,0]  R1305     -0.308746337890625
    z[6,1,0]  R1306     -4.8761337995529175e-01
    z[6,1,0]  R1307     0.397777795791626
    z[6,1,0]  R1308     -4.1439205408096313e-01
    z[6,1,0]  R1309     1.4232541620731354e-01
    z[6,1,0]  R1310     -5.3590681403875351e-02
    z[6,1,0]  R1311     -2.6490634679794312e-01
    z[6,1,0]  R1312     -4.6500900387763977e-01
    z[6,1,0]  R1313     3.4500789642333984e-01
    z[6,1,0]  R1314     5.8319758623838425e-02
    z[6,1,0]  R1315     3.2757607102394104e-01
    z[6,1,0]  R1316     -4.6450477838516235e-01
    z[6,1,0]  R1317     -3.8021394610404968e-01
    z[6,1,0]  R1318     -4.2508924007415771e-01
    z[6,1,1]  R12       1
    z[6,1,1]  R57       -1
    z[6,1,1]  R1225     -1
    z[6,1,1]  R1226     1
    z[6,1,1]  R1237     6.1162346601486206e-01
    z[6,1,1]  R1238     6.8455594778060913e-01
    z[6,1,1]  R1239     5.9001648426055908e-01
    z[6,1,1]  R1240     4.4077399373054504e-01
    z[6,1,1]  R1241     5.4034572839736938e-01
    z[6,1,1]  R1242     8.1180453300476074e-01
    z[6,1,1]  R1243     3.6116382479667664e-01
    z[6,1,1]  R1244     3.5026282072067261e-01
    z[6,1,1]  R1245     3.2761648297309875e-01
    z[6,1,1]  R1246     4.8268094658851624e-01
    z[6,1,1]  R1247     -9.0482914447784424e-01
    z[6,1,1]  R1248     -8.5679125785827637e-01
    z[6,1,1]  R1249     -0.746425211429596
    z[6,1,1]  R1250     -8.7104260921478271e-01
    z[6,1,1]  R1251     -8.7729436159133911e-01
    z[6,1,1]  R1252     -6.8070882558822632e-01
    z[6,1,1]  R1253     -6.4351511001586914e-01
    z[6,1,1]  R1254     -5.6441736221313477e-01
    z[6,1,1]  R1255     -6.4501452445983887e-01
    z[6,1,1]  R1256     -6.6356188058853149e-01
    z[6,1,1]  R1257     5.0011169910430908e-01
    z[6,1,1]  R1258     -4.6965089440345764e-01
    z[6,1,1]  R1259     -1.2971398234367371e-01
    z[6,1,1]  R1260     0.0066000921651721
    z[6,1,1]  R1261     -2.2840197384357452e-01
    z[6,1,1]  R1262     -2.7539052069187164e-02
    z[6,1,1]  R1263     -2.3782984912395477e-01
    z[6,1,1]  R1264     5.2312824875116348e-02
    z[6,1,1]  R1265     6.6013656556606293e-02
    z[6,1,1]  R1266     -2.9741770029067993e-01
    z[6,1,1]  R1267     1.8457408249378204e-01
    z[6,1,1]  R1268     7.5507219880819321e-03
    z[6,1,1]  R1269     2.5539350509643555e-01
    z[6,1,1]  R1270     -5.0007468461990356e-01
    z[6,1,1]  R1271     3.8062937557697296e-02
    z[6,1,1]  R1272     4.4514108449220657e-02
    z[6,1,1]  R1273     5.1867380738258362e-02
    z[6,1,1]  R1274     -1.7568904161453247e-01
    z[6,1,1]  R1275     -8.0612100660800934e-02
    z[6,1,1]  R1276     -1.5621571242809296e-01
    z[6,1,1]  R1277     -7.9453057050704956e-01
    z[6,1,1]  R1278     1.1819142103195190e-01
    z[6,1,1]  R1279     5.6701959110796452e-03
    z[6,1,1]  R1280     0.311960905790329
    z[6,1,1]  R1281     -7.0481783151626587e-01
    z[6,1,1]  R1282     -2.2319043055176735e-02
    z[6,1,1]  R1283     2.4448089301586151e-01
    z[6,1,1]  R1284     -7.0130831003189087e-01
    z[6,1,1]  R1285     6.2961626052856445e-01
    z[6,1,1]  R1286     -5.6727476418018341e-02
    z[6,1,1]  R1287     3.1559771299362183e-01
    z[6,1,1]  R1288     -3.6972990632057190e-01
    z[6,1,1]  R1289     -8.2249885797500610e-01
    z[6,1,1]  R1290     2.7130961418151855e-01
    z[6,1,1]  R1291     1.1103488504886627e-01
    z[6,1,1]  R1292     -2.3097580671310425e-01
    z[6,1,1]  R1293     1.4612478017807007e-01
    z[6,1,1]  R1294     -7.4920791387557983e-01
    z[6,1,1]  R1295     -5.8395504951477051e-01
    z[6,1,1]  R1296     -5.6713259220123291e-01
    z[6,1,1]  R1297     -2.4835999310016632e-01
    z[6,1,1]  R1298     1.8533114343881607e-02
    z[6,1,1]  R1299     -1.2853796780109406e-01
    z[6,1,1]  R1300     7.6763892173767090e-01
    z[6,1,1]  R1301     8.7351602315902710e-01
    z[6,1,1]  R1302     0.82350754737854
    z[6,1,1]  R1303     1.2437266111373901e-01
    z[6,1,1]  R1304     6.2831938266754150e-01
    z[6,1,1]  R1305     -4.4275969266891479e-01
    z[6,1,1]  R1306     -3.4939491748809814e-01
    z[6,1,1]  R1307     -2.6593357324600220e-02
    z[6,1,1]  R1308     1.8808719515800476e-01
    z[6,1,1]  R1309     -4.7432509064674377e-01
    z[6,1,1]  R1310     -6.5710681676864624e-01
    z[6,1,1]  R1311     -1.7128066718578339e-01
    z[6,1,1]  R1312     5.2137100696563721e-01
    z[6,1,1]  R1313     6.6814243793487549e-01
    z[6,1,1]  R1314     7.3001396656036377e-01
    z[6,1,1]  R1315     7.4190747737884521e-01
    z[6,1,1]  R1316     -7.3118019104003906e-01
    z[6,1,1]  R1317     -0.425414115190506
    z[6,1,1]  R1318     -3.8223680853843689e-01
    z[6,1,2]  R13       1
    z[6,1,2]  R58       -1
    z[6,1,2]  R1227     -1
    z[6,1,2]  R1228     1
    z[6,1,2]  R1237     6.5307760238647461e-01
    z[6,1,2]  R1238     4.8185011744499207e-01
    z[6,1,2]  R1239     5.3949570655822754e-01
    z[6,1,2]  R1240     5.0236654281616211e-01
    z[6,1,2]  R1241     4.2099103331565857e-01
    z[6,1,2]  R1242     3.7018394470214844e-01
    z[6,1,2]  R1243     -5.2113026380538940e-01
    z[6,1,2]  R1244     -4.8376509547233582e-01
    z[6,1,2]  R1245     -7.8418493270874023e-01
    z[6,1,2]  R1246     -8.1867128610610962e-01
    z[6,1,2]  R1247     1.8444927036762238e-01
    z[6,1,2]  R1248     -1.3395757414400578e-02
    z[6,1,2]  R1249     1.6011258959770203e-01
    z[6,1,2]  R1250     -4.8764474689960480e-02
    z[6,1,2]  R1251     -2.2412322461605072e-01
    z[6,1,2]  R1252     6.8242150545120239e-01
    z[6,1,2]  R1253     -2.8009975329041481e-02
    z[6,1,2]  R1254     5.6274402141571045e-01
    z[6,1,2]  R1255     6.0653007030487061e-01
    z[6,1,2]  R1256     -2.1084873378276825e-01
    z[6,1,2]  R1257     -1.5013836324214935e-01
    z[6,1,2]  R1258     8.1123101711273193e-01
    z[6,1,2]  R1259     -6.7830908298492432e-01
    z[6,1,2]  R1260     5.9358769655227661e-01
    z[6,1,2]  R1261     -7.2841954231262207e-01
    z[6,1,2]  R1262     4.0486451983451843e-01
    z[6,1,2]  R1263     -6.5329098701477051e-01
    z[6,1,2]  R1264     4.2163950204849243e-01
    z[6,1,2]  R1265     1.7427203059196472e-01
    z[6,1,2]  R1266     -5.5641597509384155e-01
    z[6,1,2]  R1267     0.533997118473053
    z[6,1,2]  R1268     -9.4141222536563873e-02
    z[6,1,2]  R1269     -3.4328576922416687e-01
    z[6,1,2]  R1270     7.7171623706817627e-01
    z[6,1,2]  R1271     -6.3166123628616333e-01
    z[6,1,2]  R1272     -4.6719151735305786e-01
    z[6,1,2]  R1273     7.1479961276054382e-02
    z[6,1,2]  R1274     1.4302076399326324e-01
    z[6,1,2]  R1275     3.5709220916032791e-02
    z[6,1,2]  R1276     -6.6773869097232819e-02
    z[6,1,2]  R1277     3.0150640010833740e-01
    z[6,1,2]  R1278     5.7649750262498856e-02
    z[6,1,2]  R1279     2.9062870144844055e-01
    z[6,1,2]  R1280     -1.0436808317899704e-01
    z[6,1,2]  R1281     -1.2822796404361725e-01
    z[6,1,2]  R1282     1.3974268734455109e-01
    z[6,1,2]  R1283     3.3458107709884644e-01
    z[6,1,2]  R1284     -2.1774242818355560e-01
    z[6,1,2]  R1285     -1.1213681101799011e-01
    z[6,1,2]  R1286     -7.5407058000564575e-01
    z[6,1,2]  R1287     -5.7629472017288208e-01
    z[6,1,2]  R1288     8.7407833337783813e-01
    z[6,1,2]  R1289     -3.0261540785431862e-02
    z[6,1,2]  R1290     2.0813831686973572e-01
    z[6,1,2]  R1291     -9.4895833730697632e-01
    z[6,1,2]  R1292     -0.669061005115509
    z[6,1,2]  R1293     -1.8745658919215202e-02
    z[6,1,2]  R1294     1.6331587731838226e-01
    z[6,1,2]  R1295     3.9022177457809448e-02
    z[6,1,2]  R1296     -1.0737180709838867e-01
    z[6,1,2]  R1297     -0.229964017868042
    z[6,1,2]  R1298     4.0561392903327942e-01
    z[6,1,2]  R1299     3.0907127261161804e-01
    z[6,1,2]  R1300     1.8937484920024872e-01
    z[6,1,2]  R1301     -1.0655014961957932e-01
    z[6,1,2]  R1302     9.2627935111522675e-02
    z[6,1,2]  R1303     1.9605781137943268e-01
    z[6,1,2]  R1304     -2.5864368304610252e-02
    z[6,1,2]  R1305     -3.6831769347190857e-01
    z[6,1,2]  R1306     -4.0486955642700195e-01
    z[6,1,2]  R1307     -4.6876770257949829e-01
    z[6,1,2]  R1308     -4.8648950457572937e-01
    z[6,1,2]  R1309     5.8708250522613525e-01
    z[6,1,2]  R1310     -2.1480685472488403e-01
    z[6,1,2]  R1311     6.2088185548782349e-01
    z[6,1,2]  R1312     6.2677621841430664e-01
    z[6,1,2]  R1313     2.1633145213127136e-01
    z[6,1,2]  R1314     0.319040983915329
    z[6,1,2]  R1315     2.1228766441345215e-01
    z[6,1,2]  R1316     -0.082750104367733
    z[6,1,2]  R1317     -3.0480343848466873e-02
    z[6,1,2]  R1318     -3.5850539803504944e-01
    z[6,1,3]  R14       1
    z[6,1,3]  R59       -1
    z[6,1,3]  R1229     -1
    z[6,1,3]  R1230     1
    z[6,1,3]  R1237     -1.7735873162746429e-01
    z[6,1,3]  R1238     -7.2166711091995239e-02
    z[6,1,3]  R1239     -3.6421704292297363e-01
    z[6,1,3]  R1240     -1.6406776383519173e-02
    z[6,1,3]  R1241     -3.6862000823020935e-02
    z[6,1,3]  R1242     7.6529145240783691e-02
    z[6,1,3]  R1243     -5.0604915618896484e-01
    z[6,1,3]  R1244     -2.8454324603080750e-01
    z[6,1,3]  R1245     1.4922952651977539e-01
    z[6,1,3]  R1246     2.3323077708482742e-02
    z[6,1,3]  R1247     2.2303119301795959e-01
    z[6,1,3]  R1248     3.0072297900915146e-02
    z[6,1,3]  R1249     -1.5407598018646240e-01
    z[6,1,3]  R1250     -1.4522799849510193e-01
    z[6,1,3]  R1251     -5.2057329565286636e-02
    z[6,1,3]  R1252     4.7645575250498950e-04
    z[6,1,3]  R1253     -1.5810810029506683e-02
    z[6,1,3]  R1254     1.1137538403272629e-01
    z[6,1,3]  R1255     -1.4453551173210144e-01
    z[6,1,3]  R1256     -6.6462743282318115e-01
    z[6,1,3]  R1257     -1.1206272989511490e-01
    z[6,1,3]  R1258     2.1960420906543732e-01
    z[6,1,3]  R1259     2.1484570205211639e-01
    z[6,1,3]  R1260     6.5667057037353516e-01
    z[6,1,3]  R1261     2.0240142941474915e-01
    z[6,1,3]  R1262     4.0234780311584473e-01
    z[6,1,3]  R1263     -3.4329872578382492e-02
    z[6,1,3]  R1264     2.8709346055984497e-01
    z[6,1,3]  R1265     8.9333295822143555e-01
    z[6,1,3]  R1266     2.7548578381538391e-01
    z[6,1,3]  R1267     -1.5493296086788177e-01
    z[6,1,3]  R1268     3.1071117520332336e-01
    z[6,1,3]  R1269     4.4686415791511536e-01
    z[6,1,3]  R1270     -1.8663607537746429e-01
    z[6,1,3]  R1271     3.4587290883064270e-01
    z[6,1,3]  R1272     1.8540048599243164e-01
    z[6,1,3]  R1273     4.5564615726470947e-01
    z[6,1,3]  R1274     3.4619012475013733e-01
    z[6,1,3]  R1275     6.1684612184762955e-02
    z[6,1,3]  R1276     2.7708551287651062e-01
    z[6,1,3]  R1277     2.7882652357220650e-02
    z[6,1,3]  R1278     2.9548335075378418e-01
    z[6,1,3]  R1279     6.4322352409362793e-01
    z[6,1,3]  R1280     0.0772358700633049
    z[6,1,3]  R1281     4.0807634592056274e-01
    z[6,1,3]  R1282     4.4087588787078857e-01
    z[6,1,3]  R1283     8.4481775760650635e-01
    z[6,1,3]  R1284     -1.0306950658559799e-01
    z[6,1,3]  R1285     5.0641906261444092e-01
    z[6,1,3]  R1286     2.6382520794868469e-01
    z[6,1,3]  R1287     -3.1905156373977661e-01
    z[6,1,3]  R1288     -1.2970322370529175e-01
    z[6,1,3]  R1289     2.6195693016052246e-01
    z[6,1,3]  R1290     0.744918942451477
    z[6,1,3]  R1291     1.3488547876477242e-02
    z[6,1,3]  R1292     1.7731359601020813e-01
    z[6,1,3]  R1293     4.5670741796493530e-01
    z[6,1,3]  R1294     -0.512614369392395
    z[6,1,3]  R1295     -4.7568336129188538e-01
    z[6,1,3]  R1296     3.3361083269119263e-01
    z[6,1,3]  R1297     -2.4189765751361847e-01
    z[6,1,3]  R1298     -3.3917987346649170e-01
    z[6,1,3]  R1299     4.2526509612798691e-02
    z[6,1,3]  R1300     2.8479378670454025e-02
    z[6,1,3]  R1301     1.1749300360679626e-01
    z[6,1,3]  R1302     2.9178312420845032e-01
    z[6,1,3]  R1303     5.5899225175380707e-02
    z[6,1,3]  R1304     3.2622328400611877e-01
    z[6,1,3]  R1305     -4.3790200352668762e-01
    z[6,1,3]  R1306     -0.609557569026947
    z[6,1,3]  R1307     1.0702575743198395e-01
    z[6,1,3]  R1308     6.5374052524566650e-01
    z[6,1,3]  R1309     2.7324968576431274e-01
    z[6,1,3]  R1310     3.3977967500686646e-01
    z[6,1,3]  R1311     -3.3968049287796021e-01
    z[6,1,3]  R1312     3.1409987807273865e-01
    z[6,1,3]  R1313     5.9229767322540283e-01
    z[6,1,3]  R1314     4.7588908672332764e-01
    z[6,1,3]  R1315     2.2977969050407410e-01
    z[6,1,3]  R1316     -4.4816818833351135e-01
    z[6,1,3]  R1317     -4.3633216619491577e-01
    z[6,1,3]  R1318     -4.2344403266906738e-01
    z[6,1,4]  R15       1
    z[6,1,4]  R60       -1
    z[6,1,4]  R1231     -1
    z[6,1,4]  R1232     1
    z[6,1,4]  R1237     3.0931377410888672e-01
    z[6,1,4]  R1238     -1.0533689707517624e-01
    z[6,1,4]  R1239     -3.9524812251329422e-02
    z[6,1,4]  R1240     -4.2555180191993713e-01
    z[6,1,4]  R1241     1.2045098841190338e-01
    z[6,1,4]  R1242     1.0959753394126892e-01
    z[6,1,4]  R1243     -5.9787888079881668e-02
    z[6,1,4]  R1244     3.0749875307083130e-01
    z[6,1,4]  R1245     5.5037878453731537e-02
    z[6,1,4]  R1246     -1.9136065244674683e-01
    z[6,1,4]  R1247     -2.1240387856960297e-01
    z[6,1,4]  R1248     -1.2740857899188995e-01
    z[6,1,4]  R1249     2.3785457015037537e-01
    z[6,1,4]  R1250     -3.0441511422395706e-02
    z[6,1,4]  R1251     -1.1305811256170273e-01
    z[6,1,4]  R1252     -1.8227986991405487e-01
    z[6,1,4]  R1253     4.3938314914703369e-01
    z[6,1,4]  R1254     -3.6281594634056091e-01
    z[6,1,4]  R1255     1.8025094270706177e-01
    z[6,1,4]  R1256     -7.6935626566410065e-02
    z[6,1,4]  R1257     3.2748109102249146e-01
    z[6,1,4]  R1258     1.4197234809398651e-01
    z[6,1,4]  R1259     -9.6101216971874237e-02
    z[6,1,4]  R1260     -1.2907008826732635e-01
    z[6,1,4]  R1261     -1.4035013318061829e-01
    z[6,1,4]  R1262     -1.7884099856019020e-02
    z[6,1,4]  R1263     3.0120092630386353e-01
    z[6,1,4]  R1264     4.3370419740676880e-01
    z[6,1,4]  R1265     -6.7534692585468292e-02
    z[6,1,4]  R1266     6.7070230841636658e-02
    z[6,1,4]  R1267     -4.2729938030242920e-01
    z[6,1,4]  R1268     3.8238272070884705e-01
    z[6,1,4]  R1269     1.5390522778034210e-01
    z[6,1,4]  R1270     -2.1807695925235748e-01
    z[6,1,4]  R1271     3.8307970762252808e-01
    z[6,1,4]  R1272     5.5730640888214111e-01
    z[6,1,4]  R1273     -1.3726758956909180e-01
    z[6,1,4]  R1274     3.5945403575897217e-01
    z[6,1,4]  R1275     5.9789609909057617e-01
    z[6,1,4]  R1276     3.2487982511520386e-01
    z[6,1,4]  R1277     1.8357923254370689e-02
    z[6,1,4]  R1278     1.6997136175632477e-02
    z[6,1,4]  R1279     2.2530054673552513e-02
    z[6,1,4]  R1280     7.1387737989425659e-02
    z[6,1,4]  R1281     5.3474036976695061e-03
    z[6,1,4]  R1282     -3.0325773358345032e-01
    z[6,1,4]  R1283     2.4515953660011292e-01
    z[6,1,4]  R1284     3.9190939068794250e-01
    z[6,1,4]  R1285     4.7103419899940491e-01
    z[6,1,4]  R1286     3.1757593154907227e-02
    z[6,1,4]  R1287     5.3931981325149536e-01
    z[6,1,4]  R1288     8.1775300204753876e-02
    z[6,1,4]  R1289     2.9924826696515083e-02
    z[6,1,4]  R1290     4.9881532788276672e-02
    z[6,1,4]  R1291     7.0591926574707031e-02
    z[6,1,4]  R1292     3.9975631237030029e-01
    z[6,1,4]  R1293     -3.8714587688446045e-01
    z[6,1,4]  R1294     -3.4964978694915771e-01
    z[6,1,4]  R1295     -3.7415459752082825e-01
    z[6,1,4]  R1296     3.8348725438117981e-01
    z[6,1,4]  R1297     6.7818784713745117e-01
    z[6,1,4]  R1298     -7.3060697317123413e-01
    z[6,1,4]  R1299     4.3386703729629517e-01
    z[6,1,4]  R1300     1.1272528767585754e-01
    z[6,1,4]  R1301     1.1800088733434677e-01
    z[6,1,4]  R1302     3.5040014982223511e-01
    z[6,1,4]  R1303     -0.262971967458725
    z[6,1,4]  R1304     1.3726362586021423e-01
    z[6,1,4]  R1305     -9.2204205691814423e-02
    z[6,1,4]  R1306     -1.9371549785137177e-01
    z[6,1,4]  R1307     3.5541161894798279e-02
    z[6,1,4]  R1308     -2.0237004756927490e-01
    z[6,1,4]  R1309     1.2165561318397522e-01
    z[6,1,4]  R1310     -3.6070284247398376e-01
    z[6,1,4]  R1311     4.1045939922332764e-01
    z[6,1,4]  R1312     1.6668954864144325e-02
    z[6,1,4]  R1313     1.4215713739395142e-01
    z[6,1,4]  R1314     4.3430402874946594e-02
    z[6,1,4]  R1315     6.3840463757514954e-02
    z[6,1,4]  R1316     -1.2974040210247040e-01
    z[6,1,4]  R1317     -8.1952154636383057e-02
    z[6,1,4]  R1318     -1.8370974063873291e-01
    z[6,1,5]  R16       1
    z[6,1,5]  R61       -1
    z[6,1,5]  R1233     -1
    z[6,1,5]  R1234     1
    z[6,1,5]  R1237     -1.4910748600959778e-01
    z[6,1,5]  R1238     2.3642964661121368e-01
    z[6,1,5]  R1239     2.6192072033882141e-01
    z[6,1,5]  R1240     -2.4893982335925102e-02
    z[6,1,5]  R1241     1.1403822153806686e-01
    z[6,1,5]  R1242     -2.0856025815010071e-01
    z[6,1,5]  R1243     4.7178804874420166e-01
    z[6,1,5]  R1244     6.6391664743423462e-01
    z[6,1,5]  R1245     3.8924831151962280e-01
    z[6,1,5]  R1246     1.2152110785245895e-01
    z[6,1,5]  R1247     2.1437183022499084e-02
    z[6,1,5]  R1248     1.3909088075160980e-01
    z[6,1,5]  R1249     1.1812205612659454e-01
    z[6,1,5]  R1250     3.7348988652229309e-01
    z[6,1,5]  R1251     -2.3512698709964752e-01
    z[6,1,5]  R1252     -4.9178179353475571e-02
    z[6,1,5]  R1253     -1.8666283786296844e-01
    z[6,1,5]  R1254     4.4221282005310059e-01
    z[6,1,5]  R1255     -2.4498255550861359e-01
    z[6,1,5]  R1256     -1.5540733933448792e-01
    z[6,1,5]  R1257     -1.5384857356548309e-01
    z[6,1,5]  R1258     1.3855701684951782e-01
    z[6,1,5]  R1259     -2.4059610068798065e-01
    z[6,1,5]  R1260     -2.6186150312423706e-01
    z[6,1,5]  R1261     -2.3836867511272430e-01
    z[6,1,5]  R1262     7.9744279384613037e-01
    z[6,1,5]  R1263     -2.9433470964431763e-01
    z[6,1,5]  R1264     7.2514837980270386e-01
    z[6,1,5]  R1265     3.7951439619064331e-01
    z[6,1,5]  R1266     -3.2458725571632385e-01
    z[6,1,5]  R1267     -4.4477206468582153e-01
    z[6,1,5]  R1268     -8.5610244423151016e-03
    z[6,1,5]  R1269     4.2908897995948792e-01
    z[6,1,5]  R1270     0.0865989699959755
    z[6,1,5]  R1271     -6.7275352776050568e-02
    z[6,1,5]  R1272     -3.2819861173629761e-01
    z[6,1,5]  R1273     7.9767984151840210e-01
    z[6,1,5]  R1274     3.5359352827072144e-01
    z[6,1,5]  R1275     5.2157509326934814e-01
    z[6,1,5]  R1276     6.2777698040008545e-01
    z[6,1,5]  R1277     -1.5226955711841583e-01
    z[6,1,5]  R1278     2.4852935969829559e-01
    z[6,1,5]  R1279     6.4453983306884766e-01
    z[6,1,5]  R1280     8.9482986927032471e-01
    z[6,1,5]  R1281     -2.9989114403724670e-01
    z[6,1,5]  R1282     6.8360632658004761e-01
    z[6,1,5]  R1283     2.0597076416015625e-01
    z[6,1,5]  R1284     5.3643468767404556e-02
    z[6,1,5]  R1285     3.2350286841392517e-01
    z[6,1,5]  R1286     7.4796602129936218e-02
    z[6,1,5]  R1287     -8.3849526941776276e-02
    z[6,1,5]  R1288     -1.0466530919075012e-01
    z[6,1,5]  R1289     -1.0526506602764130e-01
    z[6,1,5]  R1290     5.5378687381744385e-01
    z[6,1,5]  R1291     -4.9198679625988007e-02
    z[6,1,5]  R1292     2.0749524235725403e-01
    z[6,1,5]  R1293     4.2804643511772156e-01
    z[6,1,5]  R1294     3.4910753369331360e-02
    z[6,1,5]  R1295     -3.4486436843872070e-01
    z[6,1,5]  R1296     -1.7774419859051704e-02
    z[6,1,5]  R1297     -7.3558405041694641e-02
    z[6,1,5]  R1298     2.1748398244380951e-01
    z[6,1,5]  R1299     1.1583929508924484e-01
    z[6,1,5]  R1300     3.4561118483543396e-01
    z[6,1,5]  R1301     3.9490637183189392e-01
    z[6,1,5]  R1302     1.4406548440456390e-01
    z[6,1,5]  R1303     -0.0522085502743721
    z[6,1,5]  R1304     -2.1412852406501770e-01
    z[6,1,5]  R1305     -2.4928821623325348e-01
    z[6,1,5]  R1306     6.8778353743255138e-03
    z[6,1,5]  R1307     3.2511085271835327e-01
    z[6,1,5]  R1308     -2.6931858062744141e-01
    z[6,1,5]  R1309     -5.1344615221023560e-01
    z[6,1,5]  R1310     -5.2290058135986328e-01
    z[6,1,5]  R1311     5.3218550980091095e-02
    z[6,1,5]  R1312     -1.3850098848342896e-01
    z[6,1,5]  R1313     -6.3376188278198242e-02
    z[6,1,5]  R1314     -3.0528476834297180e-01
    z[6,1,5]  R1315     -4.8538818955421448e-01
    z[6,1,5]  R1316     -1.2154900282621384e-01
    z[6,1,5]  R1317     -6.7240279912948608e-01
    z[6,1,5]  R1318     -5.2716493606567383e-01
    z[6,1,6]  R17       1
    z[6,1,6]  R62       -1
    z[6,1,6]  R1235     -1
    z[6,1,6]  R1236     1
    z[6,1,6]  R1237     -2.1032159030437469e-01
    z[6,1,6]  R1238     -3.0687007308006287e-01
    z[6,1,6]  R1239     -7.9074859619140625e-02
    z[6,1,6]  R1240     -0.459751695394516
    z[6,1,6]  R1241     5.9187906980514526e-01
    z[6,1,6]  R1242     1.7832185328006744e-01
    z[6,1,6]  R1243     -2.1022546291351318e-01
    z[6,1,6]  R1244     1.0699690319597721e-02
    z[6,1,6]  R1245     -2.9689574241638184e-01
    z[6,1,6]  R1246     1.1398231983184814e-01
    z[6,1,6]  R1247     1.2032502889633179e-01
    z[6,1,6]  R1248     -3.2397669553756714e-01
    z[6,1,6]  R1249     -2.7706235647201538e-01
    z[6,1,6]  R1250     1.0287478566169739e-01
    z[6,1,6]  R1251     3.5452261567115784e-02
    z[6,1,6]  R1252     -1.4815139770507812e-01
    z[6,1,6]  R1253     -4.4864334166049957e-02
    z[6,1,6]  R1254     6.7343883216381073e-02
    z[6,1,6]  R1255     -1.1576295830309391e-02
    z[6,1,6]  R1256     1.3387800753116608e-01
    z[6,1,6]  R1257     2.2807975113391876e-01
    z[6,1,6]  R1258     9.1220222413539886e-02
    z[6,1,6]  R1259     -3.4824568033218384e-01
    z[6,1,6]  R1260     3.2301548123359680e-01
    z[6,1,6]  R1261     0.0875079482793808
    z[6,1,6]  R1262     -1.8640391528606415e-01
    z[6,1,6]  R1263     0.0978948324918747
    z[6,1,6]  R1264     3.7448275834321976e-02
    z[6,1,6]  R1265     1.1275637149810791e-01
    z[6,1,6]  R1266     -7.7837914228439331e-02
    z[6,1,6]  R1267     2.3740540444850922e-01
    z[6,1,6]  R1268     0.249008908867836
    z[6,1,6]  R1269     4.6054357290267944e-01
    z[6,1,6]  R1270     -2.5394740700721741e-01
    z[6,1,6]  R1271     5.9621725231409073e-02
    z[6,1,6]  R1272     -2.0486259460449219e-01
    z[6,1,6]  R1273     2.6581510901451111e-01
    z[6,1,6]  R1274     -2.0385244488716125e-01
    z[6,1,6]  R1275     -2.6578944921493530e-01
    z[6,1,6]  R1276     3.9920575916767120e-02
    z[6,1,6]  R1277     -2.9724302887916565e-01
    z[6,1,6]  R1278     -6.5363639593124390e-01
    z[6,1,6]  R1279     -0.0299916360527277
    z[6,1,6]  R1280     7.6696924865245819e-02
    z[6,1,6]  R1281     -1.8340897560119629e-01
    z[6,1,6]  R1282     1.6833055019378662e-01
    z[6,1,6]  R1283     -4.9545396119356155e-02
    z[6,1,6]  R1284     1.6663007438182831e-01
    z[6,1,6]  R1285     -9.1901179403066635e-03
    z[6,1,6]  R1286     0.555742084980011
    z[6,1,6]  R1287     3.7111893296241760e-01
    z[6,1,6]  R1288     -2.0795795321464539e-01
    z[6,1,6]  R1289     -1.8203240633010864e-01
    z[6,1,6]  R1290     0.0779573991894722
    z[6,1,6]  R1291     8.7144345045089722e-02
    z[6,1,6]  R1292     -1.1840105056762695e-01
    z[6,1,6]  R1293     1.4177146553993225e-01
    z[6,1,6]  R1294     -1.5528991818428040e-01
    z[6,1,6]  R1295     -4.0459185838699341e-01
    z[6,1,6]  R1296     5.0039076805114746e-01
    z[6,1,6]  R1297     -4.1801211237907410e-01
    z[6,1,6]  R1298     -6.7914955317974091e-02
    z[6,1,6]  R1299     1.4326995611190796e-01
    z[6,1,6]  R1300     1.2739814817905426e-01
    z[6,1,6]  R1301     -1.7883436381816864e-01
    z[6,1,6]  R1302     -1.5309639275074005e-01
    z[6,1,6]  R1303     1.7161594331264496e-01
    z[6,1,6]  R1304     6.5535253286361694e-01
    z[6,1,6]  R1305     0.557294487953186
    z[6,1,6]  R1306     2.5904360413551331e-01
    z[6,1,6]  R1307     0.709159791469574
    z[6,1,6]  R1308     -1.2396611273288727e-01
    z[6,1,6]  R1309     2.3874849081039429e-01
    z[6,1,6]  R1310     -1.4659132808446884e-02
    z[6,1,6]  R1311     4.7780883312225342e-01
    z[6,1,6]  R1312     -3.1167024746537209e-02
    z[6,1,6]  R1313     -1.1275658756494522e-01
    z[6,1,6]  R1314     2.0083774626255035e-01
    z[6,1,6]  R1315     -6.8739682435989380e-02
    z[6,1,6]  R1316     1.0149707645177841e-01
    z[6,1,6]  R1317     0.15589639544487
    z[6,1,6]  R1318     2.3175662755966187e-01
    z[2,3,0]  R20       -1
    z[2,3,0]  R29       1
    z[2,3,0]  R1319     -1
    z[2,3,0]  R1320     1
    z[2,3,0]  R1333     7.9560470581054688e-01
    z[2,3,0]  R1334     5.8747023344039917e-02
    z[2,3,0]  R1335     5.6420296430587769e-02
    z[2,3,0]  R1336     1.6659533977508545e-01
    z[2,3,0]  R1337     -5.6979233026504517e-01
    z[2,3,0]  R1338     -5.0615012645721436e-01
    z[2,3,0]  R1339     3.0126988887786865e-01
    z[2,3,0]  R1340     -0.757485568523407
    z[2,3,0]  R1341     -4.4783648848533630e-01
    z[2,3,0]  R1342     -7.9233306646347046e-01
    z[2,3,0]  R1343     4.7181427478790283e-01
    z[2,3,0]  R1344     3.2298198342323303e-01
    z[2,3,0]  R1345     1.8034714460372925e-01
    z[2,3,0]  R1346     -1.2563885748386383e-01
    z[2,3,0]  R1347     -5.5225425958633423e-01
    z[2,3,0]  R1348     -7.3657369613647461e-01
    z[2,3,0]  R1349     -3.4009787440299988e-01
    z[2,3,0]  R1350     -5.2417492866516113e-01
    z[2,3,0]  R1351     -8.5611319541931152e-01
    z[2,3,0]  R1352     4.8100566864013672e-01
    z[2,3,0]  R1353     7.7067714929580688e-01
    z[2,3,0]  R1354     -6.2109786272048950e-01
    z[2,3,0]  R1355     -5.5576455593109131e-01
    z[2,3,0]  R1356     -5.1919281482696533e-01
    z[2,3,0]  R1357     -7.3657137155532837e-01
    z[2,3,0]  R1358     -8.4333992004394531e-01
    z[2,3,0]  R1359     -9.6286928653717041e-01
    z[2,3,0]  R1360     -2.5694388151168823e-01
    z[2,3,0]  R1361     -2.8820779919624329e-01
    z[2,3,0]  R1362     -2.2038878500461578e-01
    z[2,3,0]  R1363     -2.3541234433650970e-01
    z[2,3,0]  R1364     -8.0517984926700592e-02
    z[2,3,0]  R1365     2.6847013831138611e-01
    z[2,3,0]  R1366     2.6393353939056396e-01
    z[2,3,0]  R1367     6.3928119838237762e-02
    z[2,3,0]  R1368     -5.6637847423553467e-01
    z[2,3,0]  R1369     -5.0411611795425415e-01
    z[2,3,0]  R1370     -7.6096475124359131e-02
    z[2,3,0]  R1371     -2.7538996934890747e-01
    z[2,3,0]  R1372     4.7545573115348816e-01
    z[2,3,0]  R1373     3.2412421703338623e-01
    z[2,3,0]  R1374     2.7132308483123779e-01
    z[2,3,0]  R1375     1.7998892068862915e-01
    z[2,3,0]  R1376     7.7423632144927979e-02
    z[2,3,0]  R1377     -3.3353021740913391e-01
    z[2,3,0]  R1378     -4.9217906594276428e-01
    z[2,3,0]  R1379     -2.2187931463122368e-02
    z[2,3,0]  R1380     0.0697609931230545
    z[2,3,0]  R1381     -6.5131855010986328e-01
    z[2,3,0]  R1382     1.1820772290229797e-01
    z[2,3,0]  R1383     3.6660384386777878e-02
    z[2,3,0]  R1384     -0.0338493250310421
    z[2,3,0]  R1385     1.1628911644220352e-01
    z[2,3,0]  R1386     -2.0690436661243439e-01
    z[2,3,0]  R1387     -2.4235163629055023e-01
    z[2,3,0]  R1388     4.6989387273788452e-01
    z[2,3,1]  R21       -1
    z[2,3,1]  R30       1
    z[2,3,1]  R1321     -1
    z[2,3,1]  R1322     1
    z[2,3,1]  R1333     -7.3858700692653656e-02
    z[2,3,1]  R1334     -3.8317173719406128e-02
    z[2,3,1]  R1335     2.3945713415741920e-02
    z[2,3,1]  R1336     -1.5448449552059174e-01
    z[2,3,1]  R1337     -5.7244252413511276e-02
    z[2,3,1]  R1338     -1.3700307905673981e-01
    z[2,3,1]  R1339     -2.0833842456340790e-01
    z[2,3,1]  R1340     0.222439244389534
    z[2,3,1]  R1341     4.7171473503112793e-02
    z[2,3,1]  R1342     1.6972686350345612e-01
    z[2,3,1]  R1343     -2.8667894005775452e-01
    z[2,3,1]  R1344     -6.6695541143417358e-02
    z[2,3,1]  R1345     -3.8933500647544861e-01
    z[2,3,1]  R1346     2.0199991762638092e-01
    z[2,3,1]  R1347     6.2614865601062775e-02
    z[2,3,1]  R1348     4.7358462214469910e-01
    z[2,3,1]  R1349     -4.4518062472343445e-01
    z[2,3,1]  R1350     -4.8974168300628662e-01
    z[2,3,1]  R1351     -3.4183260798454285e-01
    z[2,3,1]  R1352     6.5887284278869629e-01
    z[2,3,1]  R1353     -2.7084159851074219e-01
    z[2,3,1]  R1354     -4.2878395318984985e-01
    z[2,3,1]  R1355     1.6294892132282257e-01
    z[2,3,1]  R1356     2.1301576867699623e-02
    z[2,3,1]  R1357     -1.3453175313770771e-02
    z[2,3,1]  R1358     7.6238766312599182e-02
    z[2,3,1]  R1359     2.9677538201212883e-02
    z[2,3,1]  R1360     5.0362879037857056e-01
    z[2,3,1]  R1361     4.3031796813011169e-01
    z[2,3,1]  R1362     5.1262778043746948e-01
    z[2,3,1]  R1363     -5.3518807888031006e-01
    z[2,3,1]  R1364     0.665718674659729
    z[2,3,1]  R1365     -3.5662621259689331e-01
    z[2,3,1]  R1366     -3.2246306538581848e-01
    z[2,3,1]  R1367     -6.8566538393497467e-02
    z[2,3,1]  R1368     5.1457428932189941e-01
    z[2,3,1]  R1369     -1.5980145335197449e-01
    z[2,3,1]  R1370     -2.7870175242424011e-01
    z[2,3,1]  R1371     -2.4183160066604614e-01
    z[2,3,1]  R1372     -2.1686235070228577e-01
    z[2,3,1]  R1373     -5.2685849368572235e-03
    z[2,3,1]  R1374     -1.6416175663471222e-01
    z[2,3,1]  R1375     2.2952027618885040e-01
    z[2,3,1]  R1376     1.0863044112920761e-01
    z[2,3,1]  R1377     4.8980158567428589e-01
    z[2,3,1]  R1378     9.6555024385452271e-02
    z[2,3,1]  R1379     2.2454442083835602e-01
    z[2,3,1]  R1380     -3.2898661494255066e-01
    z[2,3,1]  R1381     5.5664104223251343e-01
    z[2,3,1]  R1382     0.609885036945343
    z[2,3,1]  R1383     1.7638674378395081e-01
    z[2,3,1]  R1384     1.6489903628826141e-01
    z[2,3,1]  R1385     -3.9971753954887390e-01
    z[2,3,1]  R1386     1.2495411187410355e-01
    z[2,3,1]  R1387     -1.6009691357612610e-01
    z[2,3,1]  R1388     -6.5439990721642971e-03
    z[2,3,2]  R22       -1
    z[2,3,2]  R31       1
    z[2,3,2]  R1323     -1
    z[2,3,2]  R1324     1
    z[2,3,2]  R1333     -1.2870597839355469e-01
    z[2,3,2]  R1334     -4.4760158658027649e-01
    z[2,3,2]  R1335     -5.9536278247833252e-01
    z[2,3,2]  R1336     -3.5079661011695862e-01
    z[2,3,2]  R1337     3.7425386905670166e-01
    z[2,3,2]  R1338     1.7334254086017609e-01
    z[2,3,2]  R1339     2.9048182070255280e-02
    z[2,3,2]  R1340     -1.3645115494728088e-01
    z[2,3,2]  R1341     -4.7360304743051529e-02
    z[2,3,2]  R1342     1.5023660659790039e-01
    z[2,3,2]  R1343     -8.4910027682781219e-02
    z[2,3,2]  R1344     -1.9578267633914948e-01
    z[2,3,2]  R1345     4.5277169346809387e-01
    z[2,3,2]  R1346     -1.5360449254512787e-01
    z[2,3,2]  R1347     -1.9595074653625488e-01
    z[2,3,2]  R1348     -2.1869741380214691e-01
    z[2,3,2]  R1349     5.1681622862815857e-02
    z[2,3,2]  R1350     3.1329271197319031e-01
    z[2,3,2]  R1351     1.3080114126205444e-01
    z[2,3,2]  R1352     -1.6545876860618591e-01
    z[2,3,2]  R1353     1.9249762594699860e-01
    z[2,3,2]  R1354     1.5486666560173035e-01
    z[2,3,2]  R1355     -3.9002892374992371e-01
    z[2,3,2]  R1356     -1.8877764046192169e-01
    z[2,3,2]  R1357     3.6347694694995880e-02
    z[2,3,2]  R1358     5.9024445712566376e-02
    z[2,3,2]  R1359     -1.6600438952445984e-01
    z[2,3,2]  R1360     -1.6646376252174377e-01
    z[2,3,2]  R1361     -3.0023169517517090e-01
    z[2,3,2]  R1362     -3.7327682971954346e-01
    z[2,3,2]  R1363     5.0342607498168945e-01
    z[2,3,2]  R1364     4.3642970919609070e-01
    z[2,3,2]  R1365     2.5048130750656128e-01
    z[2,3,2]  R1366     0.26313316822052
    z[2,3,2]  R1367     -3.0203810334205627e-01
    z[2,3,2]  R1368     4.2014184594154358e-01
    z[2,3,2]  R1369     1.8997415900230408e-01
    z[2,3,2]  R1370     3.5871645808219910e-01
    z[2,3,2]  R1371     2.9343169927597046e-01
    z[2,3,2]  R1372     1.3043051958084106e-01
    z[2,3,2]  R1373     -2.4072973430156708e-01
    z[2,3,2]  R1374     7.9957824945449829e-01
    z[2,3,2]  R1375     3.5708725452423096e-01
    z[2,3,2]  R1376     5.7379074394702911e-02
    z[2,3,2]  R1377     1.2958325445652008e-01
    z[2,3,2]  R1378     -5.0165700912475586e-01
    z[2,3,2]  R1379     -5.2870267629623413e-01
    z[2,3,2]  R1380     -4.6639800071716309e-01
    z[2,3,2]  R1381     1.6157804429531097e-01
    z[2,3,2]  R1382     3.8656568527221680e-01
    z[2,3,2]  R1383     1.0254673659801483e-01
    z[2,3,2]  R1384     -1.1017834395170212e-01
    z[2,3,2]  R1385     -1.5246063470840454e-01
    z[2,3,2]  R1386     -4.0270906686782837e-01
    z[2,3,2]  R1387     -2.1196620166301727e-01
    z[2,3,2]  R1388     2.9062929749488831e-01
    z[2,3,3]  R23       -1
    z[2,3,3]  R32       1
    z[2,3,3]  R1325     -1
    z[2,3,3]  R1326     1
    z[2,3,3]  R1333     -5.2323424816131592e-01
    z[2,3,3]  R1334     -8.4122993052005768e-02
    z[2,3,3]  R1335     -3.7513166666030884e-02
    z[2,3,3]  R1336     -2.8162273764610291e-01
    z[2,3,3]  R1337     -4.2607815703377128e-04
    z[2,3,3]  R1338     -2.4124450981616974e-01
    z[2,3,3]  R1339     -4.5462879538536072e-01
    z[2,3,3]  R1340     2.3012081161141396e-02
    z[2,3,3]  R1341     -8.7575650215148926e-01
    z[2,3,3]  R1342     -1.4310289174318314e-02
    z[2,3,3]  R1343     6.3929539918899536e-01
    z[2,3,3]  R1344     7.0096129179000854e-01
    z[2,3,3]  R1345     1.2679651379585266e-01
    z[2,3,3]  R1346     -3.0616298317909241e-01
    z[2,3,3]  R1347     3.8901904225349426e-01
    z[2,3,3]  R1348     -0.313040167093277
    z[2,3,3]  R1349     -6.9512730836868286e-01
    z[2,3,3]  R1350     -6.0983955860137939e-01
    z[2,3,3]  R1351     -2.2480836510658264e-01
    z[2,3,3]  R1352     8.6680993437767029e-02
    z[2,3,3]  R1353     -0.0981922596693039
    z[2,3,3]  R1354     -3.5993191599845886e-01
    z[2,3,3]  R1355     -0.293952614068985
    z[2,3,3]  R1356     -6.3237422704696655e-01
    z[2,3,3]  R1357     7.5537204742431641e-02
    z[2,3,3]  R1358     -1.4321139454841614e-01
    z[2,3,3]  R1359     -1.1148868501186371e-01
    z[2,3,3]  R1360     6.1996006965637207e-01
    z[2,3,3]  R1361     5.4018056392669678e-01
    z[2,3,3]  R1362     0.558257520198822
    z[2,3,3]  R1363     -1.6607847809791565e-01
    z[2,3,3]  R1364     -7.1758113801479340e-02
    z[2,3,3]  R1365     -2.3046146333217621e-01
    z[2,3,3]  R1366     -2.4620571732521057e-01
    z[2,3,3]  R1367     -8.8653391599655151e-01
    z[2,3,3]  R1368     -9.4564436003565788e-03
    z[2,3,3]  R1369     -3.7868365645408630e-02
    z[2,3,3]  R1370     -0.748662531375885
    z[2,3,3]  R1371     -2.1758293733000755e-02
    z[2,3,3]  R1372     -0.66502445936203
    z[2,3,3]  R1373     -1.3171463273465633e-02
    z[2,3,3]  R1374     -2.3284131661057472e-02
    z[2,3,3]  R1375     -6.4744746685028076e-01
    z[2,3,3]  R1376     -4.7600138187408447e-01
    z[2,3,3]  R1377     -4.6752920746803284e-01
    z[2,3,3]  R1378     -0.412071168422699
    z[2,3,3]  R1379     -2.7305266261100769e-01
    z[2,3,3]  R1380     -8.8371664285659790e-02
    z[2,3,3]  R1381     5.7958986610174179e-02
    z[2,3,3]  R1382     3.7165310233831406e-02
    z[2,3,3]  R1383     -6.9262951612472534e-01
    z[2,3,3]  R1384     -0.74200040102005
    z[2,3,3]  R1385     -8.2896560430526733e-01
    z[2,3,3]  R1386     -7.2565674781799316e-01
    z[2,3,3]  R1387     -5.4050511121749878e-01
    z[2,3,3]  R1388     4.4363576918840408e-02
    z[2,3,4]  R24       -1
    z[2,3,4]  R33       1
    z[2,3,4]  R1327     -1
    z[2,3,4]  R1328     1
    z[2,3,4]  R1333     2.6254183053970337e-01
    z[2,3,4]  R1334     -8.6453789472579956e-01
    z[2,3,4]  R1335     -5.0706136226654053e-01
    z[2,3,4]  R1336     -4.1331490874290466e-01
    z[2,3,4]  R1337     6.6439354419708252e-01
    z[2,3,4]  R1338     3.9260542392730713e-01
    z[2,3,4]  R1339     1.9915367662906647e-01
    z[2,3,4]  R1340     -1.9344860315322876e-01
    z[2,3,4]  R1341     -0.140597403049469
    z[2,3,4]  R1342     -2.5817906856536865e-01
    z[2,3,4]  R1343     -1.9860602915287018e-01
    z[2,3,4]  R1344     1.4874619245529175e-01
    z[2,3,4]  R1345     -1.6657146811485291e-01
    z[2,3,4]  R1346     3.2928335666656494e-01
    z[2,3,4]  R1347     3.4375011920928955e-01
    z[2,3,4]  R1348     1.2376535683870316e-02
    z[2,3,4]  R1349     -3.5774958133697510e-01
    z[2,3,4]  R1350     3.2629944384098053e-02
    z[2,3,4]  R1351     -0.175101175904274
    z[2,3,4]  R1352     2.4518145248293877e-02
    z[2,3,4]  R1353     -1.8213038146495819e-01
    z[2,3,4]  R1354     1.6555699706077576e-01
    z[2,3,4]  R1355     -0.0345456637442112
    z[2,3,4]  R1356     -1.6101695597171783e-02
    z[2,3,4]  R1357     0.273774117231369
    z[2,3,4]  R1358     0.355630487203598
    z[2,3,4]  R1359     -1.2609335780143738e-01
    z[2,3,4]  R1360     3.4994874149560928e-02
    z[2,3,4]  R1361     -2.8484666347503662e-01
    z[2,3,4]  R1362     -1.2254709750413895e-01
    z[2,3,4]  R1363     9.9035926163196564e-02
    z[2,3,4]  R1364     3.4862745553255081e-02
    z[2,3,4]  R1365     6.2686067819595337e-01
    z[2,3,4]  R1366     6.0690099000930786e-01
    z[2,3,4]  R1367     3.8100779056549072e-02
    z[2,3,4]  R1368     2.2171612083911896e-01
    z[2,3,4]  R1369     6.2509000301361084e-01
    z[2,3,4]  R1370     7.4580878019332886e-02
    z[2,3,4]  R1371     0.299792617559433
    z[2,3,4]  R1372     -2.7081465721130371e-01
    z[2,3,4]  R1373     -6.0668393969535828e-02
    z[2,3,4]  R1374     -1.4194424450397491e-01
    z[2,3,4]  R1375     -4.0741127729415894e-01
    z[2,3,4]  R1376     -1.7171686887741089e-01
    z[2,3,4]  R1377     -5.7436585426330566e-02
    z[2,3,4]  R1378     2.5881797075271606e-01
    z[2,3,4]  R1379     -1.7024882137775421e-01
    z[2,3,4]  R1380     2.5677356868982315e-02
    z[2,3,4]  R1381     3.9488363265991211e-01
    z[2,3,4]  R1382     -4.7740012407302856e-01
    z[2,3,4]  R1383     -1.6823992133140564e-01
    z[2,3,4]  R1384     -1.4347487688064575e-01
    z[2,3,4]  R1385     -7.1847997605800629e-02
    z[2,3,4]  R1386     1.9285351037979126e-02
    z[2,3,4]  R1387     2.1364890038967133e-01
    z[2,3,4]  R1388     4.3469950556755066e-01
    z[2,3,5]  R25       -1
    z[2,3,5]  R34       1
    z[2,3,5]  R1329     -1
    z[2,3,5]  R1330     1
    z[2,3,5]  R1333     2.2383647039532661e-02
    z[2,3,5]  R1334     1.7699062824249268e-01
    z[2,3,5]  R1335     -6.1907207965850830e-01
    z[2,3,5]  R1336     -5.1594501733779907e-01
    z[2,3,5]  R1337     -5.6261856108903885e-02
    z[2,3,5]  R1338     -2.1048752963542938e-01
    z[2,3,5]  R1339     -7.3773866891860962e-01
    z[2,3,5]  R1340     4.4551637768745422e-01
    z[2,3,5]  R1341     -6.9373883306980133e-02
    z[2,3,5]  R1342     3.4781849384307861e-01
    z[2,3,5]  R1343     -2.7797597646713257e-01
    z[2,3,5]  R1344     5.0542235374450684e-01
    z[2,3,5]  R1345     0.752040445804596
    z[2,3,5]  R1346     -0.677208662033081
    z[2,3,5]  R1347     -6.1743950843811035e-01
    z[2,3,5]  R1348     1.2394061684608459e-01
    z[2,3,5]  R1349     -2.2177100181579590e-01
    z[2,3,5]  R1350     -1.1052309721708298e-01
    z[2,3,5]  R1351     8.9796259999275208e-02
    z[2,3,5]  R1352     5.0441777706146240e-01
    z[2,3,5]  R1353     2.2709850966930389e-01
    z[2,3,5]  R1354     -4.9671435356140137e-01
    z[2,3,5]  R1355     -6.4993208646774292e-01
    z[2,3,5]  R1356     -4.6593353152275085e-01
    z[2,3,5]  R1357     -2.5010520219802856e-01
    z[2,3,5]  R1358     -0.0868993028998375
    z[2,3,5]  R1359     -7.3190785944461823e-02
    z[2,3,5]  R1360     5.1488876342773438e-01
    z[2,3,5]  R1361     5.1804476976394653e-01
    z[2,3,5]  R1362     2.9414954781532288e-01
    z[2,3,5]  R1363     2.7460098266601562e-01
    z[2,3,5]  R1364     0.307396799325943
    z[2,3,5]  R1365     -1.7871169745922089e-01
    z[2,3,5]  R1366     -4.6242877840995789e-01
    z[2,3,5]  R1367     -2.9271274805068970e-01
    z[2,3,5]  R1368     3.7816751003265381e-01
    z[2,3,5]  R1369     -3.8217449188232422e-01
    z[2,3,5]  R1370     -4.3603867292404175e-01
    z[2,3,5]  R1371     -6.6913217306137085e-01
    z[2,3,5]  R1372     -3.1062766909599304e-01
    z[2,3,5]  R1373     9.1158735752105713e-01
    z[2,3,5]  R1374     -3.5587523132562637e-02
    z[2,3,5]  R1375     -3.2809466123580933e-01
    z[2,3,5]  R1376     -0.838761031627655
    z[2,3,5]  R1377     -5.8943623304367065e-01
    z[2,3,5]  R1378     -1.5290953218936920e-01
    z[2,3,5]  R1379     -4.7993558645248413e-01
    z[2,3,5]  R1380     -6.2001097202301025e-01
    z[2,3,5]  R1381     2.7896678447723389e-01
    z[2,3,5]  R1382     2.2241432219743729e-02
    z[2,3,5]  R1383     -6.6822886466979980e-01
    z[2,3,5]  R1384     -5.9451836347579956e-01
    z[2,3,5]  R1385     -2.1620970964431763e-01
    z[2,3,5]  R1386     -2.7883225679397583e-01
    z[2,3,5]  R1387     -0.7156942486763
    z[2,3,5]  R1388     -5.4125857353210449e-01
    z[2,3,6]  R26       -1
    z[2,3,6]  R35       1
    z[2,3,6]  R1331     -1
    z[2,3,6]  R1332     1
    z[2,3,6]  R1333     4.2301423847675323e-02
    z[2,3,6]  R1334     -9.4368137419223785e-02
    z[2,3,6]  R1335     4.2013907805085182e-03
    z[2,3,6]  R1336     5.5586183071136475e-01
    z[2,3,6]  R1337     -2.9565081000328064e-01
    z[2,3,6]  R1338     6.6208136081695557e-01
    z[2,3,6]  R1339     -2.7272674441337585e-01
    z[2,3,6]  R1340     3.4882771968841553e-01
    z[2,3,6]  R1341     -5.8689262717962265e-02
    z[2,3,6]  R1342     -3.6467951536178589e-01
    z[2,3,6]  R1343     -4.0321603417396545e-01
    z[2,3,6]  R1344     2.8979256749153137e-01
    z[2,3,6]  R1345     3.8762498646974564e-02
    z[2,3,6]  R1346     -5.0896149873733521e-01
    z[2,3,6]  R1347     4.4344786554574966e-02
    z[2,3,6]  R1348     -2.6802939176559448e-01
    z[2,3,6]  R1349     -1.5201157331466675e-01
    z[2,3,6]  R1350     4.5354485511779785e-02
    z[2,3,6]  R1351     -2.0940189063549042e-01
    z[2,3,6]  R1352     2.1116709709167480e-01
    z[2,3,6]  R1353     4.4861918687820435e-01
    z[2,3,6]  R1354     -5.2085243165493011e-02
    z[2,3,6]  R1355     -4.9371570348739624e-02
    z[2,3,6]  R1356     2.7766451239585876e-01
    z[2,3,6]  R1357     -5.5924034118652344e-01
    z[2,3,6]  R1358     3.5347905755043030e-01
    z[2,3,6]  R1359     -1.0372241586446762e-01
    z[2,3,6]  R1360     -4.4070154428482056e-02
    z[2,3,6]  R1361     1.7904048785567284e-02
    z[2,3,6]  R1362     3.6893460154533386e-01
    z[2,3,6]  R1363     -5.4029715061187744e-01
    z[2,3,6]  R1364     5.0892752408981323e-01
    z[2,3,6]  R1365     5.0989812612533569e-01
    z[2,3,6]  R1366     3.3812901377677917e-01
    z[2,3,6]  R1367     1.6404265165328979e-01
    z[2,3,6]  R1368     -2.1366210281848907e-01
    z[2,3,6]  R1369     3.8211420178413391e-01
    z[2,3,6]  R1370     1.7795966565608978e-01
    z[2,3,6]  R1371     4.9141505360603333e-01
    z[2,3,6]  R1372     3.1275054812431335e-01
    z[2,3,6]  R1373     4.6036388725042343e-02
    z[2,3,6]  R1374     4.8800882697105408e-01
    z[2,3,6]  R1375     -3.0756288766860962e-01
    z[2,3,6]  R1376     1.3902756571769714e-01
    z[2,3,6]  R1377     -2.5048464536666870e-01
    z[2,3,6]  R1378     -4.8642212152481079e-01
    z[2,3,6]  R1379     -5.7937937974929810e-01
    z[2,3,6]  R1380     -5.2582472562789917e-01
    z[2,3,6]  R1381     5.2083160728216171e-02
    z[2,3,6]  R1382     -4.8461061716079712e-01
    z[2,3,6]  R1383     4.9575917422771454e-02
    z[2,3,6]  R1384     -0.186873197555542
    z[2,3,6]  R1385     -2.5370374321937561e-01
    z[2,3,6]  R1386     -4.1797772049903870e-01
    z[2,3,6]  R1387     1.4385780692100525e-01
    z[2,3,6]  R1388     -4.5912835001945496e-01
    z[3,2,0]  R20       1
    z[3,2,0]  R29       -1
    z[3,2,0]  R1389     -1
    z[3,2,0]  R1390     1
    z[3,2,0]  R1403     -2.3541234433650970e-01
    z[3,2,0]  R1404     -8.0517984926700592e-02
    z[3,2,0]  R1405     2.6847013831138611e-01
    z[3,2,0]  R1406     2.6393353939056396e-01
    z[3,2,0]  R1407     6.3928119838237762e-02
    z[3,2,0]  R1408     -5.6637847423553467e-01
    z[3,2,0]  R1409     -5.0411611795425415e-01
    z[3,2,0]  R1410     -7.6096475124359131e-02
    z[3,2,0]  R1411     -2.7538996934890747e-01
    z[3,2,0]  R1412     4.7545573115348816e-01
    z[3,2,0]  R1413     3.2412421703338623e-01
    z[3,2,0]  R1414     2.7132308483123779e-01
    z[3,2,0]  R1415     1.7998892068862915e-01
    z[3,2,0]  R1416     7.7423632144927979e-02
    z[3,2,0]  R1417     -3.3353021740913391e-01
    z[3,2,0]  R1418     -4.9217906594276428e-01
    z[3,2,0]  R1419     -2.2187931463122368e-02
    z[3,2,0]  R1420     0.0697609931230545
    z[3,2,0]  R1421     -6.5131855010986328e-01
    z[3,2,0]  R1422     1.1820772290229797e-01
    z[3,2,0]  R1423     3.6660384386777878e-02
    z[3,2,0]  R1424     -0.0338493250310421
    z[3,2,0]  R1425     1.1628911644220352e-01
    z[3,2,0]  R1426     -2.0690436661243439e-01
    z[3,2,0]  R1427     -2.4235163629055023e-01
    z[3,2,0]  R1428     4.6989387273788452e-01
    z[3,2,0]  R1429     7.9560470581054688e-01
    z[3,2,0]  R1430     5.8747023344039917e-02
    z[3,2,0]  R1431     5.6420296430587769e-02
    z[3,2,0]  R1432     1.6659533977508545e-01
    z[3,2,0]  R1433     -5.6979233026504517e-01
    z[3,2,0]  R1434     -5.0615012645721436e-01
    z[3,2,0]  R1435     3.0126988887786865e-01
    z[3,2,0]  R1436     -0.757485568523407
    z[3,2,0]  R1437     -4.4783648848533630e-01
    z[3,2,0]  R1438     -7.9233306646347046e-01
    z[3,2,0]  R1439     4.7181427478790283e-01
    z[3,2,0]  R1440     3.2298198342323303e-01
    z[3,2,0]  R1441     1.8034714460372925e-01
    z[3,2,0]  R1442     -1.2563885748386383e-01
    z[3,2,0]  R1443     -5.5225425958633423e-01
    z[3,2,0]  R1444     -7.3657369613647461e-01
    z[3,2,0]  R1445     -3.4009787440299988e-01
    z[3,2,0]  R1446     -5.2417492866516113e-01
    z[3,2,0]  R1447     -8.5611319541931152e-01
    z[3,2,0]  R1448     4.8100566864013672e-01
    z[3,2,0]  R1449     7.7067714929580688e-01
    z[3,2,0]  R1450     -6.2109786272048950e-01
    z[3,2,0]  R1451     -5.5576455593109131e-01
    z[3,2,0]  R1452     -5.1919281482696533e-01
    z[3,2,0]  R1453     -7.3657137155532837e-01
    z[3,2,0]  R1454     -8.4333992004394531e-01
    z[3,2,0]  R1455     -9.6286928653717041e-01
    z[3,2,0]  R1456     -2.5694388151168823e-01
    z[3,2,0]  R1457     -2.8820779919624329e-01
    z[3,2,0]  R1458     -2.2038878500461578e-01
    z[3,2,1]  R21       1
    z[3,2,1]  R30       -1
    z[3,2,1]  R1391     -1
    z[3,2,1]  R1392     1
    z[3,2,1]  R1403     -5.3518807888031006e-01
    z[3,2,1]  R1404     0.665718674659729
    z[3,2,1]  R1405     -3.5662621259689331e-01
    z[3,2,1]  R1406     -3.2246306538581848e-01
    z[3,2,1]  R1407     -6.8566538393497467e-02
    z[3,2,1]  R1408     5.1457428932189941e-01
    z[3,2,1]  R1409     -1.5980145335197449e-01
    z[3,2,1]  R1410     -2.7870175242424011e-01
    z[3,2,1]  R1411     -2.4183160066604614e-01
    z[3,2,1]  R1412     -2.1686235070228577e-01
    z[3,2,1]  R1413     -5.2685849368572235e-03
    z[3,2,1]  R1414     -1.6416175663471222e-01
    z[3,2,1]  R1415     2.2952027618885040e-01
    z[3,2,1]  R1416     1.0863044112920761e-01
    z[3,2,1]  R1417     4.8980158567428589e-01
    z[3,2,1]  R1418     9.6555024385452271e-02
    z[3,2,1]  R1419     2.2454442083835602e-01
    z[3,2,1]  R1420     -3.2898661494255066e-01
    z[3,2,1]  R1421     5.5664104223251343e-01
    z[3,2,1]  R1422     0.609885036945343
    z[3,2,1]  R1423     1.7638674378395081e-01
    z[3,2,1]  R1424     1.6489903628826141e-01
    z[3,2,1]  R1425     -3.9971753954887390e-01
    z[3,2,1]  R1426     1.2495411187410355e-01
    z[3,2,1]  R1427     -1.6009691357612610e-01
    z[3,2,1]  R1428     -6.5439990721642971e-03
    z[3,2,1]  R1429     -7.3858700692653656e-02
    z[3,2,1]  R1430     -3.8317173719406128e-02
    z[3,2,1]  R1431     2.3945713415741920e-02
    z[3,2,1]  R1432     -1.5448449552059174e-01
    z[3,2,1]  R1433     -5.7244252413511276e-02
    z[3,2,1]  R1434     -1.3700307905673981e-01
    z[3,2,1]  R1435     -2.0833842456340790e-01
    z[3,2,1]  R1436     0.222439244389534
    z[3,2,1]  R1437     4.7171473503112793e-02
    z[3,2,1]  R1438     1.6972686350345612e-01
    z[3,2,1]  R1439     -2.8667894005775452e-01
    z[3,2,1]  R1440     -6.6695541143417358e-02
    z[3,2,1]  R1441     -3.8933500647544861e-01
    z[3,2,1]  R1442     2.0199991762638092e-01
    z[3,2,1]  R1443     6.2614865601062775e-02
    z[3,2,1]  R1444     4.7358462214469910e-01
    z[3,2,1]  R1445     -4.4518062472343445e-01
    z[3,2,1]  R1446     -4.8974168300628662e-01
    z[3,2,1]  R1447     -3.4183260798454285e-01
    z[3,2,1]  R1448     6.5887284278869629e-01
    z[3,2,1]  R1449     -2.7084159851074219e-01
    z[3,2,1]  R1450     -4.2878395318984985e-01
    z[3,2,1]  R1451     1.6294892132282257e-01
    z[3,2,1]  R1452     2.1301576867699623e-02
    z[3,2,1]  R1453     -1.3453175313770771e-02
    z[3,2,1]  R1454     7.6238766312599182e-02
    z[3,2,1]  R1455     2.9677538201212883e-02
    z[3,2,1]  R1456     5.0362879037857056e-01
    z[3,2,1]  R1457     4.3031796813011169e-01
    z[3,2,1]  R1458     5.1262778043746948e-01
    z[3,2,2]  R22       1
    z[3,2,2]  R31       -1
    z[3,2,2]  R1393     -1
    z[3,2,2]  R1394     1
    z[3,2,2]  R1403     5.0342607498168945e-01
    z[3,2,2]  R1404     4.3642970919609070e-01
    z[3,2,2]  R1405     2.5048130750656128e-01
    z[3,2,2]  R1406     0.26313316822052
    z[3,2,2]  R1407     -3.0203810334205627e-01
    z[3,2,2]  R1408     4.2014184594154358e-01
    z[3,2,2]  R1409     1.8997415900230408e-01
    z[3,2,2]  R1410     3.5871645808219910e-01
    z[3,2,2]  R1411     2.9343169927597046e-01
    z[3,2,2]  R1412     1.3043051958084106e-01
    z[3,2,2]  R1413     -2.4072973430156708e-01
    z[3,2,2]  R1414     7.9957824945449829e-01
    z[3,2,2]  R1415     3.5708725452423096e-01
    z[3,2,2]  R1416     5.7379074394702911e-02
    z[3,2,2]  R1417     1.2958325445652008e-01
    z[3,2,2]  R1418     -5.0165700912475586e-01
    z[3,2,2]  R1419     -5.2870267629623413e-01
    z[3,2,2]  R1420     -4.6639800071716309e-01
    z[3,2,2]  R1421     1.6157804429531097e-01
    z[3,2,2]  R1422     3.8656568527221680e-01
    z[3,2,2]  R1423     1.0254673659801483e-01
    z[3,2,2]  R1424     -1.1017834395170212e-01
    z[3,2,2]  R1425     -1.5246063470840454e-01
    z[3,2,2]  R1426     -4.0270906686782837e-01
    z[3,2,2]  R1427     -2.1196620166301727e-01
    z[3,2,2]  R1428     2.9062929749488831e-01
    z[3,2,2]  R1429     -1.2870597839355469e-01
    z[3,2,2]  R1430     -4.4760158658027649e-01
    z[3,2,2]  R1431     -5.9536278247833252e-01
    z[3,2,2]  R1432     -3.5079661011695862e-01
    z[3,2,2]  R1433     3.7425386905670166e-01
    z[3,2,2]  R1434     1.7334254086017609e-01
    z[3,2,2]  R1435     2.9048182070255280e-02
    z[3,2,2]  R1436     -1.3645115494728088e-01
    z[3,2,2]  R1437     -4.7360304743051529e-02
    z[3,2,2]  R1438     1.5023660659790039e-01
    z[3,2,2]  R1439     -8.4910027682781219e-02
    z[3,2,2]  R1440     -1.9578267633914948e-01
    z[3,2,2]  R1441     4.5277169346809387e-01
    z[3,2,2]  R1442     -1.5360449254512787e-01
    z[3,2,2]  R1443     -1.9595074653625488e-01
    z[3,2,2]  R1444     -2.1869741380214691e-01
    z[3,2,2]  R1445     5.1681622862815857e-02
    z[3,2,2]  R1446     3.1329271197319031e-01
    z[3,2,2]  R1447     1.3080114126205444e-01
    z[3,2,2]  R1448     -1.6545876860618591e-01
    z[3,2,2]  R1449     1.9249762594699860e-01
    z[3,2,2]  R1450     1.5486666560173035e-01
    z[3,2,2]  R1451     -3.9002892374992371e-01
    z[3,2,2]  R1452     -1.8877764046192169e-01
    z[3,2,2]  R1453     3.6347694694995880e-02
    z[3,2,2]  R1454     5.9024445712566376e-02
    z[3,2,2]  R1455     -1.6600438952445984e-01
    z[3,2,2]  R1456     -1.6646376252174377e-01
    z[3,2,2]  R1457     -3.0023169517517090e-01
    z[3,2,2]  R1458     -3.7327682971954346e-01
    z[3,2,3]  R23       1
    z[3,2,3]  R32       -1
    z[3,2,3]  R1395     -1
    z[3,2,3]  R1396     1
    z[3,2,3]  R1403     -1.6607847809791565e-01
    z[3,2,3]  R1404     -7.1758113801479340e-02
    z[3,2,3]  R1405     -2.3046146333217621e-01
    z[3,2,3]  R1406     -2.4620571732521057e-01
    z[3,2,3]  R1407     -8.8653391599655151e-01
    z[3,2,3]  R1408     -9.4564436003565788e-03
    z[3,2,3]  R1409     -3.7868365645408630e-02
    z[3,2,3]  R1410     -0.748662531375885
    z[3,2,3]  R1411     -2.1758293733000755e-02
    z[3,2,3]  R1412     -0.66502445936203
    z[3,2,3]  R1413     -1.3171463273465633e-02
    z[3,2,3]  R1414     -2.3284131661057472e-02
    z[3,2,3]  R1415     -6.4744746685028076e-01
    z[3,2,3]  R1416     -4.7600138187408447e-01
    z[3,2,3]  R1417     -4.6752920746803284e-01
    z[3,2,3]  R1418     -0.412071168422699
    z[3,2,3]  R1419     -2.7305266261100769e-01
    z[3,2,3]  R1420     -8.8371664285659790e-02
    z[3,2,3]  R1421     5.7958986610174179e-02
    z[3,2,3]  R1422     3.7165310233831406e-02
    z[3,2,3]  R1423     -6.9262951612472534e-01
    z[3,2,3]  R1424     -0.74200040102005
    z[3,2,3]  R1425     -8.2896560430526733e-01
    z[3,2,3]  R1426     -7.2565674781799316e-01
    z[3,2,3]  R1427     -5.4050511121749878e-01
    z[3,2,3]  R1428     4.4363576918840408e-02
    z[3,2,3]  R1429     -5.2323424816131592e-01
    z[3,2,3]  R1430     -8.4122993052005768e-02
    z[3,2,3]  R1431     -3.7513166666030884e-02
    z[3,2,3]  R1432     -2.8162273764610291e-01
    z[3,2,3]  R1433     -4.2607815703377128e-04
    z[3,2,3]  R1434     -2.4124450981616974e-01
    z[3,2,3]  R1435     -4.5462879538536072e-01
    z[3,2,3]  R1436     2.3012081161141396e-02
    z[3,2,3]  R1437     -8.7575650215148926e-01
    z[3,2,3]  R1438     -1.4310289174318314e-02
    z[3,2,3]  R1439     6.3929539918899536e-01
    z[3,2,3]  R1440     7.0096129179000854e-01
    z[3,2,3]  R1441     1.2679651379585266e-01
    z[3,2,3]  R1442     -3.0616298317909241e-01
    z[3,2,3]  R1443     3.8901904225349426e-01
    z[3,2,3]  R1444     -0.313040167093277
    z[3,2,3]  R1445     -6.9512730836868286e-01
    z[3,2,3]  R1446     -6.0983955860137939e-01
    z[3,2,3]  R1447     -2.2480836510658264e-01
    z[3,2,3]  R1448     8.6680993437767029e-02
    z[3,2,3]  R1449     -0.0981922596693039
    z[3,2,3]  R1450     -3.5993191599845886e-01
    z[3,2,3]  R1451     -0.293952614068985
    z[3,2,3]  R1452     -6.3237422704696655e-01
    z[3,2,3]  R1453     7.5537204742431641e-02
    z[3,2,3]  R1454     -1.4321139454841614e-01
    z[3,2,3]  R1455     -1.1148868501186371e-01
    z[3,2,3]  R1456     6.1996006965637207e-01
    z[3,2,3]  R1457     5.4018056392669678e-01
    z[3,2,3]  R1458     0.558257520198822
    z[3,2,4]  R24       1
    z[3,2,4]  R33       -1
    z[3,2,4]  R1397     -1
    z[3,2,4]  R1398     1
    z[3,2,4]  R1403     9.9035926163196564e-02
    z[3,2,4]  R1404     3.4862745553255081e-02
    z[3,2,4]  R1405     6.2686067819595337e-01
    z[3,2,4]  R1406     6.0690099000930786e-01
    z[3,2,4]  R1407     3.8100779056549072e-02
    z[3,2,4]  R1408     2.2171612083911896e-01
    z[3,2,4]  R1409     6.2509000301361084e-01
    z[3,2,4]  R1410     7.4580878019332886e-02
    z[3,2,4]  R1411     0.299792617559433
    z[3,2,4]  R1412     -2.7081465721130371e-01
    z[3,2,4]  R1413     -6.0668393969535828e-02
    z[3,2,4]  R1414     -1.4194424450397491e-01
    z[3,2,4]  R1415     -4.0741127729415894e-01
    z[3,2,4]  R1416     -1.7171686887741089e-01
    z[3,2,4]  R1417     -5.7436585426330566e-02
    z[3,2,4]  R1418     2.5881797075271606e-01
    z[3,2,4]  R1419     -1.7024882137775421e-01
    z[3,2,4]  R1420     2.5677356868982315e-02
    z[3,2,4]  R1421     3.9488363265991211e-01
    z[3,2,4]  R1422     -4.7740012407302856e-01
    z[3,2,4]  R1423     -1.6823992133140564e-01
    z[3,2,4]  R1424     -1.4347487688064575e-01
    z[3,2,4]  R1425     -7.1847997605800629e-02
    z[3,2,4]  R1426     1.9285351037979126e-02
    z[3,2,4]  R1427     2.1364890038967133e-01
    z[3,2,4]  R1428     4.3469950556755066e-01
    z[3,2,4]  R1429     2.6254183053970337e-01
    z[3,2,4]  R1430     -8.6453789472579956e-01
    z[3,2,4]  R1431     -5.0706136226654053e-01
    z[3,2,4]  R1432     -4.1331490874290466e-01
    z[3,2,4]  R1433     6.6439354419708252e-01
    z[3,2,4]  R1434     3.9260542392730713e-01
    z[3,2,4]  R1435     1.9915367662906647e-01
    z[3,2,4]  R1436     -1.9344860315322876e-01
    z[3,2,4]  R1437     -0.140597403049469
    z[3,2,4]  R1438     -2.5817906856536865e-01
    z[3,2,4]  R1439     -1.9860602915287018e-01
    z[3,2,4]  R1440     1.4874619245529175e-01
    z[3,2,4]  R1441     -1.6657146811485291e-01
    z[3,2,4]  R1442     3.2928335666656494e-01
    z[3,2,4]  R1443     3.4375011920928955e-01
    z[3,2,4]  R1444     1.2376535683870316e-02
    z[3,2,4]  R1445     -3.5774958133697510e-01
    z[3,2,4]  R1446     3.2629944384098053e-02
    z[3,2,4]  R1447     -0.175101175904274
    z[3,2,4]  R1448     2.4518145248293877e-02
    z[3,2,4]  R1449     -1.8213038146495819e-01
    z[3,2,4]  R1450     1.6555699706077576e-01
    z[3,2,4]  R1451     -0.0345456637442112
    z[3,2,4]  R1452     -1.6101695597171783e-02
    z[3,2,4]  R1453     0.273774117231369
    z[3,2,4]  R1454     0.355630487203598
    z[3,2,4]  R1455     -1.2609335780143738e-01
    z[3,2,4]  R1456     3.4994874149560928e-02
    z[3,2,4]  R1457     -2.8484666347503662e-01
    z[3,2,4]  R1458     -1.2254709750413895e-01
    z[3,2,5]  R25       1
    z[3,2,5]  R34       -1
    z[3,2,5]  R1399     -1
    z[3,2,5]  R1400     1
    z[3,2,5]  R1403     2.7460098266601562e-01
    z[3,2,5]  R1404     0.307396799325943
    z[3,2,5]  R1405     -1.7871169745922089e-01
    z[3,2,5]  R1406     -4.6242877840995789e-01
    z[3,2,5]  R1407     -2.9271274805068970e-01
    z[3,2,5]  R1408     3.7816751003265381e-01
    z[3,2,5]  R1409     -3.8217449188232422e-01
    z[3,2,5]  R1410     -4.3603867292404175e-01
    z[3,2,5]  R1411     -6.6913217306137085e-01
    z[3,2,5]  R1412     -3.1062766909599304e-01
    z[3,2,5]  R1413     9.1158735752105713e-01
    z[3,2,5]  R1414     -3.5587523132562637e-02
    z[3,2,5]  R1415     -3.2809466123580933e-01
    z[3,2,5]  R1416     -0.838761031627655
    z[3,2,5]  R1417     -5.8943623304367065e-01
    z[3,2,5]  R1418     -1.5290953218936920e-01
    z[3,2,5]  R1419     -4.7993558645248413e-01
    z[3,2,5]  R1420     -6.2001097202301025e-01
    z[3,2,5]  R1421     2.7896678447723389e-01
    z[3,2,5]  R1422     2.2241432219743729e-02
    z[3,2,5]  R1423     -6.6822886466979980e-01
    z[3,2,5]  R1424     -5.9451836347579956e-01
    z[3,2,5]  R1425     -2.1620970964431763e-01
    z[3,2,5]  R1426     -2.7883225679397583e-01
    z[3,2,5]  R1427     -0.7156942486763
    z[3,2,5]  R1428     -5.4125857353210449e-01
    z[3,2,5]  R1429     2.2383647039532661e-02
    z[3,2,5]  R1430     1.7699062824249268e-01
    z[3,2,5]  R1431     -6.1907207965850830e-01
    z[3,2,5]  R1432     -5.1594501733779907e-01
    z[3,2,5]  R1433     -5.6261856108903885e-02
    z[3,2,5]  R1434     -2.1048752963542938e-01
    z[3,2,5]  R1435     -7.3773866891860962e-01
    z[3,2,5]  R1436     4.4551637768745422e-01
    z[3,2,5]  R1437     -6.9373883306980133e-02
    z[3,2,5]  R1438     3.4781849384307861e-01
    z[3,2,5]  R1439     -2.7797597646713257e-01
    z[3,2,5]  R1440     5.0542235374450684e-01
    z[3,2,5]  R1441     0.752040445804596
    z[3,2,5]  R1442     -0.677208662033081
    z[3,2,5]  R1443     -6.1743950843811035e-01
    z[3,2,5]  R1444     1.2394061684608459e-01
    z[3,2,5]  R1445     -2.2177100181579590e-01
    z[3,2,5]  R1446     -1.1052309721708298e-01
    z[3,2,5]  R1447     8.9796259999275208e-02
    z[3,2,5]  R1448     5.0441777706146240e-01
    z[3,2,5]  R1449     2.2709850966930389e-01
    z[3,2,5]  R1450     -4.9671435356140137e-01
    z[3,2,5]  R1451     -6.4993208646774292e-01
    z[3,2,5]  R1452     -4.6593353152275085e-01
    z[3,2,5]  R1453     -2.5010520219802856e-01
    z[3,2,5]  R1454     -0.0868993028998375
    z[3,2,5]  R1455     -7.3190785944461823e-02
    z[3,2,5]  R1456     5.1488876342773438e-01
    z[3,2,5]  R1457     5.1804476976394653e-01
    z[3,2,5]  R1458     2.9414954781532288e-01
    z[3,2,6]  R26       1
    z[3,2,6]  R35       -1
    z[3,2,6]  R1401     -1
    z[3,2,6]  R1402     1
    z[3,2,6]  R1403     -5.4029715061187744e-01
    z[3,2,6]  R1404     5.0892752408981323e-01
    z[3,2,6]  R1405     5.0989812612533569e-01
    z[3,2,6]  R1406     3.3812901377677917e-01
    z[3,2,6]  R1407     1.6404265165328979e-01
    z[3,2,6]  R1408     -2.1366210281848907e-01
    z[3,2,6]  R1409     3.8211420178413391e-01
    z[3,2,6]  R1410     1.7795966565608978e-01
    z[3,2,6]  R1411     4.9141505360603333e-01
    z[3,2,6]  R1412     3.1275054812431335e-01
    z[3,2,6]  R1413     4.6036388725042343e-02
    z[3,2,6]  R1414     4.8800882697105408e-01
    z[3,2,6]  R1415     -3.0756288766860962e-01
    z[3,2,6]  R1416     1.3902756571769714e-01
    z[3,2,6]  R1417     -2.5048464536666870e-01
    z[3,2,6]  R1418     -4.8642212152481079e-01
    z[3,2,6]  R1419     -5.7937937974929810e-01
    z[3,2,6]  R1420     -5.2582472562789917e-01
    z[3,2,6]  R1421     5.2083160728216171e-02
    z[3,2,6]  R1422     -4.8461061716079712e-01
    z[3,2,6]  R1423     4.9575917422771454e-02
    z[3,2,6]  R1424     -0.186873197555542
    z[3,2,6]  R1425     -2.5370374321937561e-01
    z[3,2,6]  R1426     -4.1797772049903870e-01
    z[3,2,6]  R1427     1.4385780692100525e-01
    z[3,2,6]  R1428     -4.5912835001945496e-01
    z[3,2,6]  R1429     4.2301423847675323e-02
    z[3,2,6]  R1430     -9.4368137419223785e-02
    z[3,2,6]  R1431     4.2013907805085182e-03
    z[3,2,6]  R1432     5.5586183071136475e-01
    z[3,2,6]  R1433     -2.9565081000328064e-01
    z[3,2,6]  R1434     6.6208136081695557e-01
    z[3,2,6]  R1435     -2.7272674441337585e-01
    z[3,2,6]  R1436     3.4882771968841553e-01
    z[3,2,6]  R1437     -5.8689262717962265e-02
    z[3,2,6]  R1438     -3.6467951536178589e-01
    z[3,2,6]  R1439     -4.0321603417396545e-01
    z[3,2,6]  R1440     2.8979256749153137e-01
    z[3,2,6]  R1441     3.8762498646974564e-02
    z[3,2,6]  R1442     -5.0896149873733521e-01
    z[3,2,6]  R1443     4.4344786554574966e-02
    z[3,2,6]  R1444     -2.6802939176559448e-01
    z[3,2,6]  R1445     -1.5201157331466675e-01
    z[3,2,6]  R1446     4.5354485511779785e-02
    z[3,2,6]  R1447     -2.0940189063549042e-01
    z[3,2,6]  R1448     2.1116709709167480e-01
    z[3,2,6]  R1449     4.4861918687820435e-01
    z[3,2,6]  R1450     -5.2085243165493011e-02
    z[3,2,6]  R1451     -4.9371570348739624e-02
    z[3,2,6]  R1452     2.7766451239585876e-01
    z[3,2,6]  R1453     -5.5924034118652344e-01
    z[3,2,6]  R1454     3.5347905755043030e-01
    z[3,2,6]  R1455     -1.0372241586446762e-01
    z[3,2,6]  R1456     -4.4070154428482056e-02
    z[3,2,6]  R1457     1.7904048785567284e-02
    z[3,2,6]  R1458     3.6893460154533386e-01
    z[3,4,0]  R29       -1
    z[3,4,0]  R38       1
    z[3,4,0]  R1459     -1
    z[3,4,0]  R1460     1
    z[3,4,0]  R1473     -2.3541234433650970e-01
    z[3,4,0]  R1474     -8.0517984926700592e-02
    z[3,4,0]  R1475     2.6847013831138611e-01
    z[3,4,0]  R1476     2.6393353939056396e-01
    z[3,4,0]  R1477     6.3928119838237762e-02
    z[3,4,0]  R1478     -5.6637847423553467e-01
    z[3,4,0]  R1479     -5.0411611795425415e-01
    z[3,4,0]  R1480     -7.6096475124359131e-02
    z[3,4,0]  R1481     -2.7538996934890747e-01
    z[3,4,0]  R1482     4.7545573115348816e-01
    z[3,4,0]  R1483     3.2412421703338623e-01
    z[3,4,0]  R1484     2.7132308483123779e-01
    z[3,4,0]  R1485     1.7998892068862915e-01
    z[3,4,0]  R1486     7.7423632144927979e-02
    z[3,4,0]  R1487     -3.3353021740913391e-01
    z[3,4,0]  R1488     -4.9217906594276428e-01
    z[3,4,0]  R1489     -2.2187931463122368e-02
    z[3,4,0]  R1490     0.0697609931230545
    z[3,4,0]  R1491     -6.5131855010986328e-01
    z[3,4,0]  R1492     1.1820772290229797e-01
    z[3,4,0]  R1493     3.6660384386777878e-02
    z[3,4,0]  R1494     -0.0338493250310421
    z[3,4,0]  R1495     1.1628911644220352e-01
    z[3,4,0]  R1496     -2.0690436661243439e-01
    z[3,4,0]  R1497     -2.4235163629055023e-01
    z[3,4,0]  R1498     4.6989387273788452e-01
    z[3,4,0]  R1499     6.0462176799774170e-01
    z[3,4,0]  R1500     2.9137367010116577e-01
    z[3,4,0]  R1501     5.6002104282379150e-01
    z[3,4,0]  R1502     3.1382495164871216e-01
    z[3,4,0]  R1503     2.9768326878547668e-01
    z[3,4,0]  R1504     -0.141557976603508
    z[3,4,0]  R1505     -2.0994892716407776e-01
    z[3,4,0]  R1506     -1.0216555744409561e-01
    z[3,4,0]  R1507     -2.7833974361419678e-01
    z[3,4,0]  R1508     -6.1229479312896729e-01
    z[3,4,0]  R1509     -4.3129128217697144e-01
    z[3,4,0]  R1510     2.6894053816795349e-01
    z[3,4,0]  R1511     0.0671851858496666
    z[3,4,0]  R1512     -4.3774917721748352e-01
    z[3,4,0]  R1513     -5.8658456802368164e-01
    z[3,4,0]  R1514     -5.5617743730545044e-01
    z[3,4,0]  R1515     -5.1447862386703491e-01
    z[3,4,0]  R1516     -4.6854338049888611e-01
    z[3,4,0]  R1517     1.3010308146476746e-01
    z[3,4,0]  R1518     2.8996556997299194e-01
    z[3,4,0]  R1519     5.7000595331192017e-01
    z[3,4,0]  R1520     -4.8165583610534668e-01
    z[3,4,0]  R1521     1.5405304729938507e-01
    z[3,4,0]  R1522     -2.4634206295013428e-01
    z[3,4,0]  R1523     -3.0574074387550354e-01
    z[3,4,0]  R1524     -0.622085690498352
    z[3,4,1]  R30       -1
    z[3,4,1]  R39       1
    z[3,4,1]  R1461     -1
    z[3,4,1]  R1462     1
    z[3,4,1]  R1473     -5.3518807888031006e-01
    z[3,4,1]  R1474     0.665718674659729
    z[3,4,1]  R1475     -3.5662621259689331e-01
    z[3,4,1]  R1476     -3.2246306538581848e-01
    z[3,4,1]  R1477     -6.8566538393497467e-02
    z[3,4,1]  R1478     5.1457428932189941e-01
    z[3,4,1]  R1479     -1.5980145335197449e-01
    z[3,4,1]  R1480     -2.7870175242424011e-01
    z[3,4,1]  R1481     -2.4183160066604614e-01
    z[3,4,1]  R1482     -2.1686235070228577e-01
    z[3,4,1]  R1483     -5.2685849368572235e-03
    z[3,4,1]  R1484     -1.6416175663471222e-01
    z[3,4,1]  R1485     2.2952027618885040e-01
    z[3,4,1]  R1486     1.0863044112920761e-01
    z[3,4,1]  R1487     4.8980158567428589e-01
    z[3,4,1]  R1488     9.6555024385452271e-02
    z[3,4,1]  R1489     2.2454442083835602e-01
    z[3,4,1]  R1490     -3.2898661494255066e-01
    z[3,4,1]  R1491     5.5664104223251343e-01
    z[3,4,1]  R1492     0.609885036945343
    z[3,4,1]  R1493     1.7638674378395081e-01
    z[3,4,1]  R1494     1.6489903628826141e-01
    z[3,4,1]  R1495     -3.9971753954887390e-01
    z[3,4,1]  R1496     1.2495411187410355e-01
    z[3,4,1]  R1497     -1.6009691357612610e-01
    z[3,4,1]  R1498     -6.5439990721642971e-03
    z[3,4,1]  R1499     -0.427695631980896
    z[3,4,1]  R1500     -3.7351474165916443e-01
    z[3,4,1]  R1501     -2.6733905076980591e-01
    z[3,4,1]  R1502     -2.1657115221023560e-01
    z[3,4,1]  R1503     -1.5072849392890930e-01
    z[3,4,1]  R1504     6.8602615594863892e-01
    z[3,4,1]  R1505     1.0551681369543076e-01
    z[3,4,1]  R1506     1.0882353782653809e-01
    z[3,4,1]  R1507     -0.342375248670578
    z[3,4,1]  R1508     4.9433064460754395e-01
    z[3,4,1]  R1509     -6.7132681608200073e-01
    z[3,4,1]  R1510     0.82118821144104
    z[3,4,1]  R1511     7.0289772748947144e-01
    z[3,4,1]  R1512     7.2166818380355835e-01
    z[3,4,1]  R1513     6.0886752605438232e-01
    z[3,4,1]  R1514     6.5920859575271606e-01
    z[3,4,1]  R1515     6.2887781858444214e-01
    z[3,4,1]  R1516     6.0926729440689087e-01
    z[3,4,1]  R1517     4.8369586467742920e-01
    z[3,4,1]  R1518     3.7400382757186890e-01
    z[3,4,1]  R1519     -1.2066167593002319e-01
    z[3,4,1]  R1520     1.7116256058216095e-01
    z[3,4,1]  R1521     7.6513302326202393e-01
    z[3,4,1]  R1522     5.2339071035385132e-01
    z[3,4,1]  R1523     0.455557644367218
    z[3,4,1]  R1524     6.0648965835571289e-01
    z[3,4,2]  R31       -1
    z[3,4,2]  R40       1
    z[3,4,2]  R1463     -1
    z[3,4,2]  R1464     1
    z[3,4,2]  R1473     5.0342607498168945e-01
    z[3,4,2]  R1474     4.3642970919609070e-01
    z[3,4,2]  R1475     2.5048130750656128e-01
    z[3,4,2]  R1476     0.26313316822052
    z[3,4,2]  R1477     -3.0203810334205627e-01
    z[3,4,2]  R1478     4.2014184594154358e-01
    z[3,4,2]  R1479     1.8997415900230408e-01
    z[3,4,2]  R1480     3.5871645808219910e-01
    z[3,4,2]  R1481     2.9343169927597046e-01
    z[3,4,2]  R1482     1.3043051958084106e-01
    z[3,4,2]  R1483     -2.4072973430156708e-01
    z[3,4,2]  R1484     7.9957824945449829e-01
    z[3,4,2]  R1485     3.5708725452423096e-01
    z[3,4,2]  R1486     5.7379074394702911e-02
    z[3,4,2]  R1487     1.2958325445652008e-01
    z[3,4,2]  R1488     -5.0165700912475586e-01
    z[3,4,2]  R1489     -5.2870267629623413e-01
    z[3,4,2]  R1490     -4.6639800071716309e-01
    z[3,4,2]  R1491     1.6157804429531097e-01
    z[3,4,2]  R1492     3.8656568527221680e-01
    z[3,4,2]  R1493     1.0254673659801483e-01
    z[3,4,2]  R1494     -1.1017834395170212e-01
    z[3,4,2]  R1495     -1.5246063470840454e-01
    z[3,4,2]  R1496     -4.0270906686782837e-01
    z[3,4,2]  R1497     -2.1196620166301727e-01
    z[3,4,2]  R1498     2.9062929749488831e-01
    z[3,4,2]  R1499     2.7030757069587708e-01
    z[3,4,2]  R1500     9.6585564315319061e-02
    z[3,4,2]  R1501     -1.9237211346626282e-01
    z[3,4,2]  R1502     2.0158283412456512e-01
    z[3,4,2]  R1503     1.0820751637220383e-01
    z[3,4,2]  R1504     1.0771740972995758e-01
    z[3,4,2]  R1505     1.6107057034969330e-01
    z[3,4,2]  R1506     7.2462931275367737e-03
    z[3,4,2]  R1507     -3.8359690457582474e-02
    z[3,4,2]  R1508     -1.4830297231674194e-01
    z[3,4,2]  R1509     -2.0888724923133850e-01
    z[3,4,2]  R1510     4.2630749940872192e-01
    z[3,4,2]  R1511     0.534913182258606
    z[3,4,2]  R1512     -3.7196657061576843e-01
    z[3,4,2]  R1513     -1.1329184472560883e-01
    z[3,4,2]  R1514     2.6715528219938278e-02
    z[3,4,2]  R1515     1.4443910121917725e-01
    z[3,4,2]  R1516     9.2906527221202850e-02
    z[3,4,2]  R1517     4.7078814357519150e-02
    z[3,4,2]  R1518     2.7288424968719482e-01
    z[3,4,2]  R1519     5.6478178501129150e-01
    z[3,4,2]  R1520     8.2377445697784424e-01
    z[3,4,2]  R1521     1.4372408390045166e-01
    z[3,4,2]  R1522     -4.4087201356887817e-01
    z[3,4,2]  R1523     3.5574379563331604e-01
    z[3,4,2]  R1524     -1.5888983383774757e-02
    z[3,4,3]  R32       -1
    z[3,4,3]  R41       1
    z[3,4,3]  R1465     -1
    z[3,4,3]  R1466     1
    z[3,4,3]  R1473     -1.6607847809791565e-01
    z[3,4,3]  R1474     -7.1758113801479340e-02
    z[3,4,3]  R1475     -2.3046146333217621e-01
    z[3,4,3]  R1476     -2.4620571732521057e-01
    z[3,4,3]  R1477     -8.8653391599655151e-01
    z[3,4,3]  R1478     -9.4564436003565788e-03
    z[3,4,3]  R1479     -3.7868365645408630e-02
    z[3,4,3]  R1480     -0.748662531375885
    z[3,4,3]  R1481     -2.1758293733000755e-02
    z[3,4,3]  R1482     -0.66502445936203
    z[3,4,3]  R1483     -1.3171463273465633e-02
    z[3,4,3]  R1484     -2.3284131661057472e-02
    z[3,4,3]  R1485     -6.4744746685028076e-01
    z[3,4,3]  R1486     -4.7600138187408447e-01
    z[3,4,3]  R1487     -4.6752920746803284e-01
    z[3,4,3]  R1488     -0.412071168422699
    z[3,4,3]  R1489     -2.7305266261100769e-01
    z[3,4,3]  R1490     -8.8371664285659790e-02
    z[3,4,3]  R1491     5.7958986610174179e-02
    z[3,4,3]  R1492     3.7165310233831406e-02
    z[3,4,3]  R1493     -6.9262951612472534e-01
    z[3,4,3]  R1494     -0.74200040102005
    z[3,4,3]  R1495     -8.2896560430526733e-01
    z[3,4,3]  R1496     -7.2565674781799316e-01
    z[3,4,3]  R1497     -5.4050511121749878e-01
    z[3,4,3]  R1498     4.4363576918840408e-02
    z[3,4,3]  R1499     -4.8889175057411194e-01
    z[3,4,3]  R1500     -7.8584265708923340e-01
    z[3,4,3]  R1501     -1.9428165256977081e-01
    z[3,4,3]  R1502     -1.0201204568147659e-01
    z[3,4,3]  R1503     -0.417267382144928
    z[3,4,3]  R1504     -4.6351003646850586e-01
    z[3,4,3]  R1505     -3.3292523026466370e-01
    z[3,4,3]  R1506     -0.37607541680336
    z[3,4,3]  R1507     -3.0490785837173462e-01
    z[3,4,3]  R1508     -0.0989907830953598
    z[3,4,3]  R1509     6.0548400506377220e-03
    z[3,4,3]  R1510     -0.00725465826690197
    z[3,4,3]  R1511     -0.219582200050354
    z[3,4,3]  R1512     -2.7254137396812439e-01
    z[3,4,3]  R1513     4.3601036071777344e-02
    z[3,4,3]  R1514     6.6809900104999542e-02
    z[3,4,3]  R1515     -7.9151391983032227e-02
    z[3,4,3]  R1516     -6.2500024214386940e-03
    z[3,4,3]  R1517     -0.00627180514857173
    z[3,4,3]  R1518     0.0092415576800704
    z[3,4,3]  R1519     2.8565520048141479e-01
    z[3,4,3]  R1520     -2.5335285812616348e-02
    z[3,4,3]  R1521     -2.9324862360954285e-01
    z[3,4,3]  R1522     -2.7659258246421814e-01
    z[3,4,3]  R1523     -4.1543912887573242e-01
    z[3,4,3]  R1524     -7.1238003671169281e-02
    z[3,4,4]  R33       -1
    z[3,4,4]  R42       1
    z[3,4,4]  R1467     -1
    z[3,4,4]  R1468     1
    z[3,4,4]  R1473     9.9035926163196564e-02
    z[3,4,4]  R1474     3.4862745553255081e-02
    z[3,4,4]  R1475     6.2686067819595337e-01
    z[3,4,4]  R1476     6.0690099000930786e-01
    z[3,4,4]  R1477     3.8100779056549072e-02
    z[3,4,4]  R1478     2.2171612083911896e-01
    z[3,4,4]  R1479     6.2509000301361084e-01
    z[3,4,4]  R1480     7.4580878019332886e-02
    z[3,4,4]  R1481     0.299792617559433
    z[3,4,4]  R1482     -2.7081465721130371e-01
    z[3,4,4]  R1483     -6.0668393969535828e-02
    z[3,4,4]  R1484     -1.4194424450397491e-01
    z[3,4,4]  R1485     -4.0741127729415894e-01
    z[3,4,4]  R1486     -1.7171686887741089e-01
    z[3,4,4]  R1487     -5.7436585426330566e-02
    z[3,4,4]  R1488     2.5881797075271606e-01
    z[3,4,4]  R1489     -1.7024882137775421e-01
    z[3,4,4]  R1490     2.5677356868982315e-02
    z[3,4,4]  R1491     3.9488363265991211e-01
    z[3,4,4]  R1492     -4.7740012407302856e-01
    z[3,4,4]  R1493     -1.6823992133140564e-01
    z[3,4,4]  R1494     -1.4347487688064575e-01
    z[3,4,4]  R1495     -7.1847997605800629e-02
    z[3,4,4]  R1496     1.9285351037979126e-02
    z[3,4,4]  R1497     2.1364890038967133e-01
    z[3,4,4]  R1498     4.3469950556755066e-01
    z[3,4,4]  R1499     -3.5046611446887255e-03
    z[3,4,4]  R1500     1.1596713215112686e-01
    z[3,4,4]  R1501     1.9420546293258667e-01
    z[3,4,4]  R1502     -3.9147242903709412e-01
    z[3,4,4]  R1503     2.0783146843314171e-02
    z[3,4,4]  R1504     1.0750199854373932e-01
    z[3,4,4]  R1505     -2.6204988360404968e-01
    z[3,4,4]  R1506     5.3113603591918945e-01
    z[3,4,4]  R1507     -7.2880500555038452e-01
    z[3,4,4]  R1508     4.5618328452110291e-01
    z[3,4,4]  R1509     4.2399752140045166e-01
    z[3,4,4]  R1510     -2.5723323225975037e-01
    z[3,4,4]  R1511     -1.2136476114392281e-02
    z[3,4,4]  R1512     -1.1006093025207520e-01
    z[3,4,4]  R1513     -2.2480301558971405e-01
    z[3,4,4]  R1514     -2.0080648362636566e-01
    z[3,4,4]  R1515     4.7277133911848068e-02
    z[3,4,4]  R1516     2.2855195403099060e-01
    z[3,4,4]  R1517     7.8527766466140747e-01
    z[3,4,4]  R1518     6.7890977859497070e-01
    z[3,4,4]  R1519     4.8681598901748657e-01
    z[3,4,4]  R1520     -2.9550949111580849e-02
    z[3,4,4]  R1521     -4.9882560968399048e-01
    z[3,4,4]  R1522     -4.8221078515052795e-01
    z[3,4,4]  R1523     6.5729096531867981e-02
    z[3,4,4]  R1524     -5.9800289571285248e-02
    z[3,4,5]  R34       -1
    z[3,4,5]  R43       1
    z[3,4,5]  R1469     -1
    z[3,4,5]  R1470     1
    z[3,4,5]  R1473     2.7460098266601562e-01
    z[3,4,5]  R1474     0.307396799325943
    z[3,4,5]  R1475     -1.7871169745922089e-01
    z[3,4,5]  R1476     -4.6242877840995789e-01
    z[3,4,5]  R1477     -2.9271274805068970e-01
    z[3,4,5]  R1478     3.7816751003265381e-01
    z[3,4,5]  R1479     -3.8217449188232422e-01
    z[3,4,5]  R1480     -4.3603867292404175e-01
    z[3,4,5]  R1481     -6.6913217306137085e-01
    z[3,4,5]  R1482     -3.1062766909599304e-01
    z[3,4,5]  R1483     9.1158735752105713e-01
    z[3,4,5]  R1484     -3.5587523132562637e-02
    z[3,4,5]  R1485     -3.2809466123580933e-01
    z[3,4,5]  R1486     -0.838761031627655
    z[3,4,5]  R1487     -5.8943623304367065e-01
    z[3,4,5]  R1488     -1.5290953218936920e-01
    z[3,4,5]  R1489     -4.7993558645248413e-01
    z[3,4,5]  R1490     -6.2001097202301025e-01
    z[3,4,5]  R1491     2.7896678447723389e-01
    z[3,4,5]  R1492     2.2241432219743729e-02
    z[3,4,5]  R1493     -6.6822886466979980e-01
    z[3,4,5]  R1494     -5.9451836347579956e-01
    z[3,4,5]  R1495     -2.1620970964431763e-01
    z[3,4,5]  R1496     -2.7883225679397583e-01
    z[3,4,5]  R1497     -0.7156942486763
    z[3,4,5]  R1498     -5.4125857353210449e-01
    z[3,4,5]  R1499     -3.5775479674339294e-01
    z[3,4,5]  R1500     -1.8148759007453918e-01
    z[3,4,5]  R1501     -7.0211440324783325e-01
    z[3,4,5]  R1502     -3.2426446676254272e-01
    z[3,4,5]  R1503     1.8139944970607758e-01
    z[3,4,5]  R1504     -4.8105177283287048e-01
    z[3,4,5]  R1505     -5.8350992202758789e-01
    z[3,4,5]  R1506     -3.8507875800132751e-01
    z[3,4,5]  R1507     0.141758531332016
    z[3,4,5]  R1508     3.7513709068298340e-01
    z[3,4,5]  R1509     3.7390294671058655e-01
    z[3,4,5]  R1510     5.7006757706403732e-02
    z[3,4,5]  R1511     3.6030483245849609e-01
    z[3,4,5]  R1512     -2.1258337795734406e-01
    z[3,4,5]  R1513     4.0506568551063538e-01
    z[3,4,5]  R1514     4.5777502655982971e-01
    z[3,4,5]  R1515     5.5498993396759033e-01
    z[3,4,5]  R1516     2.8004467487335205e-01
    z[3,4,5]  R1517     3.0015367269515991e-01
    z[3,4,5]  R1518     4.6198898553848267e-01
    z[3,4,5]  R1519     0.150673970580101
    z[3,4,5]  R1520     2.3514720797538757e-01
    z[3,4,5]  R1521     -0.124564990401268
    z[3,4,5]  R1522     -3.4364455938339233e-01
    z[3,4,5]  R1523     6.0427474975585938e-01
    z[3,4,5]  R1524     4.8606848716735840e-01
    z[3,4,6]  R35       -1
    z[3,4,6]  R44       1
    z[3,4,6]  R1471     -1
    z[3,4,6]  R1472     1
    z[3,4,6]  R1473     -5.4029715061187744e-01
    z[3,4,6]  R1474     5.0892752408981323e-01
    z[3,4,6]  R1475     5.0989812612533569e-01
    z[3,4,6]  R1476     3.3812901377677917e-01
    z[3,4,6]  R1477     1.6404265165328979e-01
    z[3,4,6]  R1478     -2.1366210281848907e-01
    z[3,4,6]  R1479     3.8211420178413391e-01
    z[3,4,6]  R1480     1.7795966565608978e-01
    z[3,4,6]  R1481     4.9141505360603333e-01
    z[3,4,6]  R1482     3.1275054812431335e-01
    z[3,4,6]  R1483     4.6036388725042343e-02
    z[3,4,6]  R1484     4.8800882697105408e-01
    z[3,4,6]  R1485     -3.0756288766860962e-01
    z[3,4,6]  R1486     1.3902756571769714e-01
    z[3,4,6]  R1487     -2.5048464536666870e-01
    z[3,4,6]  R1488     -4.8642212152481079e-01
    z[3,4,6]  R1489     -5.7937937974929810e-01
    z[3,4,6]  R1490     -5.2582472562789917e-01
    z[3,4,6]  R1491     5.2083160728216171e-02
    z[3,4,6]  R1492     -4.8461061716079712e-01
    z[3,4,6]  R1493     4.9575917422771454e-02
    z[3,4,6]  R1494     -0.186873197555542
    z[3,4,6]  R1495     -2.5370374321937561e-01
    z[3,4,6]  R1496     -4.1797772049903870e-01
    z[3,4,6]  R1497     1.4385780692100525e-01
    z[3,4,6]  R1498     -4.5912835001945496e-01
    z[3,4,6]  R1499     -1.0689639300107956e-01
    z[3,4,6]  R1500     -3.1988203525543213e-01
    z[3,4,6]  R1501     9.7331300377845764e-02
    z[3,4,6]  R1502     -7.3835670948028564e-01
    z[3,4,6]  R1503     8.1823396682739258e-01
    z[3,4,6]  R1504     1.9979335367679596e-01
    z[3,4,6]  R1505     6.3154637813568115e-01
    z[3,4,6]  R1506     6.3705819845199585e-01
    z[3,4,6]  R1507     -3.9951688051223755e-01
    z[3,4,6]  R1508     1.0409250855445862e-02
    z[3,4,6]  R1509     7.7651664614677429e-03
    z[3,4,6]  R1510     4.5951329171657562e-02
    z[3,4,6]  R1511     -1.9262865185737610e-01
    z[3,4,6]  R1512     -1.3276958465576172e-01
    z[3,4,6]  R1513     2.3632231354713440e-01
    z[3,4,6]  R1514     3.2438777387142181e-02
    z[3,4,6]  R1515     -0.0494762621819973
    z[3,4,6]  R1516     -5.1954674720764160e-01
    z[3,4,6]  R1517     -2.0025607943534851e-01
    z[3,4,6]  R1518     -1.6473460197448730e-01
    z[3,4,6]  R1519     1.6251062974333763e-02
    z[3,4,6]  R1520     -5.7421583682298660e-02
    z[3,4,6]  R1521     1.4086969196796417e-01
    z[3,4,6]  R1522     2.0949308574199677e-01
    z[3,4,6]  R1523     -1.7429323494434357e-01
    z[3,4,6]  R1524     -3.7158469203859568e-03
    z[4,3,0]  R29       1
    z[4,3,0]  R38       -1
    z[4,3,0]  R1525     -1
    z[4,3,0]  R1526     1
    z[4,3,0]  R1539     6.0462176799774170e-01
    z[4,3,0]  R1540     2.9137367010116577e-01
    z[4,3,0]  R1541     5.6002104282379150e-01
    z[4,3,0]  R1542     3.1382495164871216e-01
    z[4,3,0]  R1543     2.9768326878547668e-01
    z[4,3,0]  R1544     -0.141557976603508
    z[4,3,0]  R1545     -2.0994892716407776e-01
    z[4,3,0]  R1546     -1.0216555744409561e-01
    z[4,3,0]  R1547     -2.7833974361419678e-01
    z[4,3,0]  R1548     -6.1229479312896729e-01
    z[4,3,0]  R1549     -4.3129128217697144e-01
    z[4,3,0]  R1550     2.6894053816795349e-01
    z[4,3,0]  R1551     0.0671851858496666
    z[4,3,0]  R1552     -4.3774917721748352e-01
    z[4,3,0]  R1553     -5.8658456802368164e-01
    z[4,3,0]  R1554     -5.5617743730545044e-01
    z[4,3,0]  R1555     -5.1447862386703491e-01
    z[4,3,0]  R1556     -4.6854338049888611e-01
    z[4,3,0]  R1557     1.3010308146476746e-01
    z[4,3,0]  R1558     2.8996556997299194e-01
    z[4,3,0]  R1559     5.7000595331192017e-01
    z[4,3,0]  R1560     -4.8165583610534668e-01
    z[4,3,0]  R1561     1.5405304729938507e-01
    z[4,3,0]  R1562     -2.4634206295013428e-01
    z[4,3,0]  R1563     -3.0574074387550354e-01
    z[4,3,0]  R1564     -0.622085690498352
    z[4,3,0]  R1565     -2.3541234433650970e-01
    z[4,3,0]  R1566     -8.0517984926700592e-02
    z[4,3,0]  R1567     2.6847013831138611e-01
    z[4,3,0]  R1568     2.6393353939056396e-01
    z[4,3,0]  R1569     6.3928119838237762e-02
    z[4,3,0]  R1570     -5.6637847423553467e-01
    z[4,3,0]  R1571     -5.0411611795425415e-01
    z[4,3,0]  R1572     -7.6096475124359131e-02
    z[4,3,0]  R1573     -2.7538996934890747e-01
    z[4,3,0]  R1574     4.7545573115348816e-01
    z[4,3,0]  R1575     3.2412421703338623e-01
    z[4,3,0]  R1576     2.7132308483123779e-01
    z[4,3,0]  R1577     1.7998892068862915e-01
    z[4,3,0]  R1578     7.7423632144927979e-02
    z[4,3,0]  R1579     -3.3353021740913391e-01
    z[4,3,0]  R1580     -4.9217906594276428e-01
    z[4,3,0]  R1581     -2.2187931463122368e-02
    z[4,3,0]  R1582     0.0697609931230545
    z[4,3,0]  R1583     -6.5131855010986328e-01
    z[4,3,0]  R1584     1.1820772290229797e-01
    z[4,3,0]  R1585     3.6660384386777878e-02
    z[4,3,0]  R1586     -0.0338493250310421
    z[4,3,0]  R1587     1.1628911644220352e-01
    z[4,3,0]  R1588     -2.0690436661243439e-01
    z[4,3,0]  R1589     -2.4235163629055023e-01
    z[4,3,0]  R1590     4.6989387273788452e-01
    z[4,3,1]  R30       1
    z[4,3,1]  R39       -1
    z[4,3,1]  R1527     -1
    z[4,3,1]  R1528     1
    z[4,3,1]  R1539     -0.427695631980896
    z[4,3,1]  R1540     -3.7351474165916443e-01
    z[4,3,1]  R1541     -2.6733905076980591e-01
    z[4,3,1]  R1542     -2.1657115221023560e-01
    z[4,3,1]  R1543     -1.5072849392890930e-01
    z[4,3,1]  R1544     6.8602615594863892e-01
    z[4,3,1]  R1545     1.0551681369543076e-01
    z[4,3,1]  R1546     1.0882353782653809e-01
    z[4,3,1]  R1547     -0.342375248670578
    z[4,3,1]  R1548     4.9433064460754395e-01
    z[4,3,1]  R1549     -6.7132681608200073e-01
    z[4,3,1]  R1550     0.82118821144104
    z[4,3,1]  R1551     7.0289772748947144e-01
    z[4,3,1]  R1552     7.2166818380355835e-01
    z[4,3,1]  R1553     6.0886752605438232e-01
    z[4,3,1]  R1554     6.5920859575271606e-01
    z[4,3,1]  R1555     6.2887781858444214e-01
    z[4,3,1]  R1556     6.0926729440689087e-01
    z[4,3,1]  R1557     4.8369586467742920e-01
    z[4,3,1]  R1558     3.7400382757186890e-01
    z[4,3,1]  R1559     -1.2066167593002319e-01
    z[4,3,1]  R1560     1.7116256058216095e-01
    z[4,3,1]  R1561     7.6513302326202393e-01
    z[4,3,1]  R1562     5.2339071035385132e-01
    z[4,3,1]  R1563     0.455557644367218
    z[4,3,1]  R1564     6.0648965835571289e-01
    z[4,3,1]  R1565     -5.3518807888031006e-01
    z[4,3,1]  R1566     0.665718674659729
    z[4,3,1]  R1567     -3.5662621259689331e-01
    z[4,3,1]  R1568     -3.2246306538581848e-01
    z[4,3,1]  R1569     -6.8566538393497467e-02
    z[4,3,1]  R1570     5.1457428932189941e-01
    z[4,3,1]  R1571     -1.5980145335197449e-01
    z[4,3,1]  R1572     -2.7870175242424011e-01
    z[4,3,1]  R1573     -2.4183160066604614e-01
    z[4,3,1]  R1574     -2.1686235070228577e-01
    z[4,3,1]  R1575     -5.2685849368572235e-03
    z[4,3,1]  R1576     -1.6416175663471222e-01
    z[4,3,1]  R1577     2.2952027618885040e-01
    z[4,3,1]  R1578     1.0863044112920761e-01
    z[4,3,1]  R1579     4.8980158567428589e-01
    z[4,3,1]  R1580     9.6555024385452271e-02
    z[4,3,1]  R1581     2.2454442083835602e-01
    z[4,3,1]  R1582     -3.2898661494255066e-01
    z[4,3,1]  R1583     5.5664104223251343e-01
    z[4,3,1]  R1584     0.609885036945343
    z[4,3,1]  R1585     1.7638674378395081e-01
    z[4,3,1]  R1586     1.6489903628826141e-01
    z[4,3,1]  R1587     -3.9971753954887390e-01
    z[4,3,1]  R1588     1.2495411187410355e-01
    z[4,3,1]  R1589     -1.6009691357612610e-01
    z[4,3,1]  R1590     -6.5439990721642971e-03
    z[4,3,2]  R31       1
    z[4,3,2]  R40       -1
    z[4,3,2]  R1529     -1
    z[4,3,2]  R1530     1
    z[4,3,2]  R1539     2.7030757069587708e-01
    z[4,3,2]  R1540     9.6585564315319061e-02
    z[4,3,2]  R1541     -1.9237211346626282e-01
    z[4,3,2]  R1542     2.0158283412456512e-01
    z[4,3,2]  R1543     1.0820751637220383e-01
    z[4,3,2]  R1544     1.0771740972995758e-01
    z[4,3,2]  R1545     1.6107057034969330e-01
    z[4,3,2]  R1546     7.2462931275367737e-03
    z[4,3,2]  R1547     -3.8359690457582474e-02
    z[4,3,2]  R1548     -1.4830297231674194e-01
    z[4,3,2]  R1549     -2.0888724923133850e-01
    z[4,3,2]  R1550     4.2630749940872192e-01
    z[4,3,2]  R1551     0.534913182258606
    z[4,3,2]  R1552     -3.7196657061576843e-01
    z[4,3,2]  R1553     -1.1329184472560883e-01
    z[4,3,2]  R1554     2.6715528219938278e-02
    z[4,3,2]  R1555     1.4443910121917725e-01
    z[4,3,2]  R1556     9.2906527221202850e-02
    z[4,3,2]  R1557     4.7078814357519150e-02
    z[4,3,2]  R1558     2.7288424968719482e-01
    z[4,3,2]  R1559     5.6478178501129150e-01
    z[4,3,2]  R1560     8.2377445697784424e-01
    z[4,3,2]  R1561     1.4372408390045166e-01
    z[4,3,2]  R1562     -4.4087201356887817e-01
    z[4,3,2]  R1563     3.5574379563331604e-01
    z[4,3,2]  R1564     -1.5888983383774757e-02
    z[4,3,2]  R1565     5.0342607498168945e-01
    z[4,3,2]  R1566     4.3642970919609070e-01
    z[4,3,2]  R1567     2.5048130750656128e-01
    z[4,3,2]  R1568     0.26313316822052
    z[4,3,2]  R1569     -3.0203810334205627e-01
    z[4,3,2]  R1570     4.2014184594154358e-01
    z[4,3,2]  R1571     1.8997415900230408e-01
    z[4,3,2]  R1572     3.5871645808219910e-01
    z[4,3,2]  R1573     2.9343169927597046e-01
    z[4,3,2]  R1574     1.3043051958084106e-01
    z[4,3,2]  R1575     -2.4072973430156708e-01
    z[4,3,2]  R1576     7.9957824945449829e-01
    z[4,3,2]  R1577     3.5708725452423096e-01
    z[4,3,2]  R1578     5.7379074394702911e-02
    z[4,3,2]  R1579     1.2958325445652008e-01
    z[4,3,2]  R1580     -5.0165700912475586e-01
    z[4,3,2]  R1581     -5.2870267629623413e-01
    z[4,3,2]  R1582     -4.6639800071716309e-01
    z[4,3,2]  R1583     1.6157804429531097e-01
    z[4,3,2]  R1584     3.8656568527221680e-01
    z[4,3,2]  R1585     1.0254673659801483e-01
    z[4,3,2]  R1586     -1.1017834395170212e-01
    z[4,3,2]  R1587     -1.5246063470840454e-01
    z[4,3,2]  R1588     -4.0270906686782837e-01
    z[4,3,2]  R1589     -2.1196620166301727e-01
    z[4,3,2]  R1590     2.9062929749488831e-01
    z[4,3,3]  R32       1
    z[4,3,3]  R41       -1
    z[4,3,3]  R1531     -1
    z[4,3,3]  R1532     1
    z[4,3,3]  R1539     -4.8889175057411194e-01
    z[4,3,3]  R1540     -7.8584265708923340e-01
    z[4,3,3]  R1541     -1.9428165256977081e-01
    z[4,3,3]  R1542     -1.0201204568147659e-01
    z[4,3,3]  R1543     -0.417267382144928
    z[4,3,3]  R1544     -4.6351003646850586e-01
    z[4,3,3]  R1545     -3.3292523026466370e-01
    z[4,3,3]  R1546     -0.37607541680336
    z[4,3,3]  R1547     -3.0490785837173462e-01
    z[4,3,3]  R1548     -0.0989907830953598
    z[4,3,3]  R1549     6.0548400506377220e-03
    z[4,3,3]  R1550     -0.00725465826690197
    z[4,3,3]  R1551     -0.219582200050354
    z[4,3,3]  R1552     -2.7254137396812439e-01
    z[4,3,3]  R1553     4.3601036071777344e-02
    z[4,3,3]  R1554     6.6809900104999542e-02
    z[4,3,3]  R1555     -7.9151391983032227e-02
    z[4,3,3]  R1556     -6.2500024214386940e-03
    z[4,3,3]  R1557     -0.00627180514857173
    z[4,3,3]  R1558     0.0092415576800704
    z[4,3,3]  R1559     2.8565520048141479e-01
    z[4,3,3]  R1560     -2.5335285812616348e-02
    z[4,3,3]  R1561     -2.9324862360954285e-01
    z[4,3,3]  R1562     -2.7659258246421814e-01
    z[4,3,3]  R1563     -4.1543912887573242e-01
    z[4,3,3]  R1564     -7.1238003671169281e-02
    z[4,3,3]  R1565     -1.6607847809791565e-01
    z[4,3,3]  R1566     -7.1758113801479340e-02
    z[4,3,3]  R1567     -2.3046146333217621e-01
    z[4,3,3]  R1568     -2.4620571732521057e-01
    z[4,3,3]  R1569     -8.8653391599655151e-01
    z[4,3,3]  R1570     -9.4564436003565788e-03
    z[4,3,3]  R1571     -3.7868365645408630e-02
    z[4,3,3]  R1572     -0.748662531375885
    z[4,3,3]  R1573     -2.1758293733000755e-02
    z[4,3,3]  R1574     -0.66502445936203
    z[4,3,3]  R1575     -1.3171463273465633e-02
    z[4,3,3]  R1576     -2.3284131661057472e-02
    z[4,3,3]  R1577     -6.4744746685028076e-01
    z[4,3,3]  R1578     -4.7600138187408447e-01
    z[4,3,3]  R1579     -4.6752920746803284e-01
    z[4,3,3]  R1580     -0.412071168422699
    z[4,3,3]  R1581     -2.7305266261100769e-01
    z[4,3,3]  R1582     -8.8371664285659790e-02
    z[4,3,3]  R1583     5.7958986610174179e-02
    z[4,3,3]  R1584     3.7165310233831406e-02
    z[4,3,3]  R1585     -6.9262951612472534e-01
    z[4,3,3]  R1586     -0.74200040102005
    z[4,3,3]  R1587     -8.2896560430526733e-01
    z[4,3,3]  R1588     -7.2565674781799316e-01
    z[4,3,3]  R1589     -5.4050511121749878e-01
    z[4,3,3]  R1590     4.4363576918840408e-02
    z[4,3,4]  R33       1
    z[4,3,4]  R42       -1
    z[4,3,4]  R1533     -1
    z[4,3,4]  R1534     1
    z[4,3,4]  R1539     -3.5046611446887255e-03
    z[4,3,4]  R1540     1.1596713215112686e-01
    z[4,3,4]  R1541     1.9420546293258667e-01
    z[4,3,4]  R1542     -3.9147242903709412e-01
    z[4,3,4]  R1543     2.0783146843314171e-02
    z[4,3,4]  R1544     1.0750199854373932e-01
    z[4,3,4]  R1545     -2.6204988360404968e-01
    z[4,3,4]  R1546     5.3113603591918945e-01
    z[4,3,4]  R1547     -7.2880500555038452e-01
    z[4,3,4]  R1548     4.5618328452110291e-01
    z[4,3,4]  R1549     4.2399752140045166e-01
    z[4,3,4]  R1550     -2.5723323225975037e-01
    z[4,3,4]  R1551     -1.2136476114392281e-02
    z[4,3,4]  R1552     -1.1006093025207520e-01
    z[4,3,4]  R1553     -2.2480301558971405e-01
    z[4,3,4]  R1554     -2.0080648362636566e-01
    z[4,3,4]  R1555     4.7277133911848068e-02
    z[4,3,4]  R1556     2.2855195403099060e-01
    z[4,3,4]  R1557     7.8527766466140747e-01
    z[4,3,4]  R1558     6.7890977859497070e-01
    z[4,3,4]  R1559     4.8681598901748657e-01
    z[4,3,4]  R1560     -2.9550949111580849e-02
    z[4,3,4]  R1561     -4.9882560968399048e-01
    z[4,3,4]  R1562     -4.8221078515052795e-01
    z[4,3,4]  R1563     6.5729096531867981e-02
    z[4,3,4]  R1564     -5.9800289571285248e-02
    z[4,3,4]  R1565     9.9035926163196564e-02
    z[4,3,4]  R1566     3.4862745553255081e-02
    z[4,3,4]  R1567     6.2686067819595337e-01
    z[4,3,4]  R1568     6.0690099000930786e-01
    z[4,3,4]  R1569     3.8100779056549072e-02
    z[4,3,4]  R1570     2.2171612083911896e-01
    z[4,3,4]  R1571     6.2509000301361084e-01
    z[4,3,4]  R1572     7.4580878019332886e-02
    z[4,3,4]  R1573     0.299792617559433
    z[4,3,4]  R1574     -2.7081465721130371e-01
    z[4,3,4]  R1575     -6.0668393969535828e-02
    z[4,3,4]  R1576     -1.4194424450397491e-01
    z[4,3,4]  R1577     -4.0741127729415894e-01
    z[4,3,4]  R1578     -1.7171686887741089e-01
    z[4,3,4]  R1579     -5.7436585426330566e-02
    z[4,3,4]  R1580     2.5881797075271606e-01
    z[4,3,4]  R1581     -1.7024882137775421e-01
    z[4,3,4]  R1582     2.5677356868982315e-02
    z[4,3,4]  R1583     3.9488363265991211e-01
    z[4,3,4]  R1584     -4.7740012407302856e-01
    z[4,3,4]  R1585     -1.6823992133140564e-01
    z[4,3,4]  R1586     -1.4347487688064575e-01
    z[4,3,4]  R1587     -7.1847997605800629e-02
    z[4,3,4]  R1588     1.9285351037979126e-02
    z[4,3,4]  R1589     2.1364890038967133e-01
    z[4,3,4]  R1590     4.3469950556755066e-01
    z[4,3,5]  R34       1
    z[4,3,5]  R43       -1
    z[4,3,5]  R1535     -1
    z[4,3,5]  R1536     1
    z[4,3,5]  R1539     -3.5775479674339294e-01
    z[4,3,5]  R1540     -1.8148759007453918e-01
    z[4,3,5]  R1541     -7.0211440324783325e-01
    z[4,3,5]  R1542     -3.2426446676254272e-01
    z[4,3,5]  R1543     1.8139944970607758e-01
    z[4,3,5]  R1544     -4.8105177283287048e-01
    z[4,3,5]  R1545     -5.8350992202758789e-01
    z[4,3,5]  R1546     -3.8507875800132751e-01
    z[4,3,5]  R1547     0.141758531332016
    z[4,3,5]  R1548     3.7513709068298340e-01
    z[4,3,5]  R1549     3.7390294671058655e-01
    z[4,3,5]  R1550     5.7006757706403732e-02
    z[4,3,5]  R1551     3.6030483245849609e-01
    z[4,3,5]  R1552     -2.1258337795734406e-01
    z[4,3,5]  R1553     4.0506568551063538e-01
    z[4,3,5]  R1554     4.5777502655982971e-01
    z[4,3,5]  R1555     5.5498993396759033e-01
    z[4,3,5]  R1556     2.8004467487335205e-01
    z[4,3,5]  R1557     3.0015367269515991e-01
    z[4,3,5]  R1558     4.6198898553848267e-01
    z[4,3,5]  R1559     0.150673970580101
    z[4,3,5]  R1560     2.3514720797538757e-01
    z[4,3,5]  R1561     -0.124564990401268
    z[4,3,5]  R1562     -3.4364455938339233e-01
    z[4,3,5]  R1563     6.0427474975585938e-01
    z[4,3,5]  R1564     4.8606848716735840e-01
    z[4,3,5]  R1565     2.7460098266601562e-01
    z[4,3,5]  R1566     0.307396799325943
    z[4,3,5]  R1567     -1.7871169745922089e-01
    z[4,3,5]  R1568     -4.6242877840995789e-01
    z[4,3,5]  R1569     -2.9271274805068970e-01
    z[4,3,5]  R1570     3.7816751003265381e-01
    z[4,3,5]  R1571     -3.8217449188232422e-01
    z[4,3,5]  R1572     -4.3603867292404175e-01
    z[4,3,5]  R1573     -6.6913217306137085e-01
    z[4,3,5]  R1574     -3.1062766909599304e-01
    z[4,3,5]  R1575     9.1158735752105713e-01
    z[4,3,5]  R1576     -3.5587523132562637e-02
    z[4,3,5]  R1577     -3.2809466123580933e-01
    z[4,3,5]  R1578     -0.838761031627655
    z[4,3,5]  R1579     -5.8943623304367065e-01
    z[4,3,5]  R1580     -1.5290953218936920e-01
    z[4,3,5]  R1581     -4.7993558645248413e-01
    z[4,3,5]  R1582     -6.2001097202301025e-01
    z[4,3,5]  R1583     2.7896678447723389e-01
    z[4,3,5]  R1584     2.2241432219743729e-02
    z[4,3,5]  R1585     -6.6822886466979980e-01
    z[4,3,5]  R1586     -5.9451836347579956e-01
    z[4,3,5]  R1587     -2.1620970964431763e-01
    z[4,3,5]  R1588     -2.7883225679397583e-01
    z[4,3,5]  R1589     -0.7156942486763
    z[4,3,5]  R1590     -5.4125857353210449e-01
    z[4,3,6]  R35       1
    z[4,3,6]  R44       -1
    z[4,3,6]  R1537     -1
    z[4,3,6]  R1538     1
    z[4,3,6]  R1539     -1.0689639300107956e-01
    z[4,3,6]  R1540     -3.1988203525543213e-01
    z[4,3,6]  R1541     9.7331300377845764e-02
    z[4,3,6]  R1542     -7.3835670948028564e-01
    z[4,3,6]  R1543     8.1823396682739258e-01
    z[4,3,6]  R1544     1.9979335367679596e-01
    z[4,3,6]  R1545     6.3154637813568115e-01
    z[4,3,6]  R1546     6.3705819845199585e-01
    z[4,3,6]  R1547     -3.9951688051223755e-01
    z[4,3,6]  R1548     1.0409250855445862e-02
    z[4,3,6]  R1549     7.7651664614677429e-03
    z[4,3,6]  R1550     4.5951329171657562e-02
    z[4,3,6]  R1551     -1.9262865185737610e-01
    z[4,3,6]  R1552     -1.3276958465576172e-01
    z[4,3,6]  R1553     2.3632231354713440e-01
    z[4,3,6]  R1554     3.2438777387142181e-02
    z[4,3,6]  R1555     -0.0494762621819973
    z[4,3,6]  R1556     -5.1954674720764160e-01
    z[4,3,6]  R1557     -2.0025607943534851e-01
    z[4,3,6]  R1558     -1.6473460197448730e-01
    z[4,3,6]  R1559     1.6251062974333763e-02
    z[4,3,6]  R1560     -5.7421583682298660e-02
    z[4,3,6]  R1561     1.4086969196796417e-01
    z[4,3,6]  R1562     2.0949308574199677e-01
    z[4,3,6]  R1563     -1.7429323494434357e-01
    z[4,3,6]  R1564     -3.7158469203859568e-03
    z[4,3,6]  R1565     -5.4029715061187744e-01
    z[4,3,6]  R1566     5.0892752408981323e-01
    z[4,3,6]  R1567     5.0989812612533569e-01
    z[4,3,6]  R1568     3.3812901377677917e-01
    z[4,3,6]  R1569     1.6404265165328979e-01
    z[4,3,6]  R1570     -2.1366210281848907e-01
    z[4,3,6]  R1571     3.8211420178413391e-01
    z[4,3,6]  R1572     1.7795966565608978e-01
    z[4,3,6]  R1573     4.9141505360603333e-01
    z[4,3,6]  R1574     3.1275054812431335e-01
    z[4,3,6]  R1575     4.6036388725042343e-02
    z[4,3,6]  R1576     4.8800882697105408e-01
    z[4,3,6]  R1577     -3.0756288766860962e-01
    z[4,3,6]  R1578     1.3902756571769714e-01
    z[4,3,6]  R1579     -2.5048464536666870e-01
    z[4,3,6]  R1580     -4.8642212152481079e-01
    z[4,3,6]  R1581     -5.7937937974929810e-01
    z[4,3,6]  R1582     -5.2582472562789917e-01
    z[4,3,6]  R1583     5.2083160728216171e-02
    z[4,3,6]  R1584     -4.8461061716079712e-01
    z[4,3,6]  R1585     4.9575917422771454e-02
    z[4,3,6]  R1586     -0.186873197555542
    z[4,3,6]  R1587     -2.5370374321937561e-01
    z[4,3,6]  R1588     -4.1797772049903870e-01
    z[4,3,6]  R1589     1.4385780692100525e-01
    z[4,3,6]  R1590     -4.5912835001945496e-01
    z[4,8,0]  R38       -1
    z[4,8,0]  R74       1
    z[4,8,0]  R1591     -1
    z[4,8,0]  R1592     1
    z[4,8,0]  R1605     6.0462176799774170e-01
    z[4,8,0]  R1606     2.9137367010116577e-01
    z[4,8,0]  R1607     5.6002104282379150e-01
    z[4,8,0]  R1608     3.1382495164871216e-01
    z[4,8,0]  R1609     2.9768326878547668e-01
    z[4,8,0]  R1610     -0.141557976603508
    z[4,8,0]  R1611     -2.0994892716407776e-01
    z[4,8,0]  R1612     -1.0216555744409561e-01
    z[4,8,0]  R1613     -2.7833974361419678e-01
    z[4,8,0]  R1614     -6.1229479312896729e-01
    z[4,8,0]  R1615     -4.3129128217697144e-01
    z[4,8,0]  R1616     2.6894053816795349e-01
    z[4,8,0]  R1617     0.0671851858496666
    z[4,8,0]  R1618     -4.3774917721748352e-01
    z[4,8,0]  R1619     -5.8658456802368164e-01
    z[4,8,0]  R1620     -5.5617743730545044e-01
    z[4,8,0]  R1621     -5.1447862386703491e-01
    z[4,8,0]  R1622     -4.6854338049888611e-01
    z[4,8,0]  R1623     1.3010308146476746e-01
    z[4,8,0]  R1624     2.8996556997299194e-01
    z[4,8,0]  R1625     5.7000595331192017e-01
    z[4,8,0]  R1626     -4.8165583610534668e-01
    z[4,8,0]  R1627     1.5405304729938507e-01
    z[4,8,0]  R1628     -2.4634206295013428e-01
    z[4,8,0]  R1629     -3.0574074387550354e-01
    z[4,8,0]  R1630     -0.622085690498352
    z[4,8,0]  R1631     -1.5072417259216309e-01
    z[4,8,0]  R1632     6.6199767589569092e-01
    z[4,8,0]  R1633     -7.2658807039260864e-02
    z[4,8,0]  R1634     5.0864481925964355e-01
    z[4,8,0]  R1635     2.6525846123695374e-01
    z[4,8,0]  R1636     4.7638800740242004e-01
    z[4,8,0]  R1637     2.1989306807518005e-01
    z[4,8,0]  R1638     -3.5427814722061157e-01
    z[4,8,0]  R1639     -2.0952154695987701e-01
    z[4,8,0]  R1640     -5.5590067058801651e-03
    z[4,8,0]  R1641     -9.3253576755523682e-01
    z[4,8,0]  R1642     -9.0112978219985962e-01
    z[4,8,0]  R1643     -8.7758165597915649e-01
    z[4,8,0]  R1644     1.7205205559730530e-01
    z[4,8,0]  R1645     3.8720494508743286e-01
    z[4,8,0]  R1646     3.7908968329429626e-01
    z[4,8,0]  R1647     2.0732177793979645e-01
    z[4,8,0]  R1648     -6.1520463787019253e-03
    z[4,8,1]  R39       -1
    z[4,8,1]  R75       1
    z[4,8,1]  R1593     -1
    z[4,8,1]  R1594     1
    z[4,8,1]  R1605     -0.427695631980896
    z[4,8,1]  R1606     -3.7351474165916443e-01
    z[4,8,1]  R1607     -2.6733905076980591e-01
    z[4,8,1]  R1608     -2.1657115221023560e-01
    z[4,8,1]  R1609     -1.5072849392890930e-01
    z[4,8,1]  R1610     6.8602615594863892e-01
    z[4,8,1]  R1611     1.0551681369543076e-01
    z[4,8,1]  R1612     1.0882353782653809e-01
    z[4,8,1]  R1613     -0.342375248670578
    z[4,8,1]  R1614     4.9433064460754395e-01
    z[4,8,1]  R1615     -6.7132681608200073e-01
    z[4,8,1]  R1616     0.82118821144104
    z[4,8,1]  R1617     7.0289772748947144e-01
    z[4,8,1]  R1618     7.2166818380355835e-01
    z[4,8,1]  R1619     6.0886752605438232e-01
    z[4,8,1]  R1620     6.5920859575271606e-01
    z[4,8,1]  R1621     6.2887781858444214e-01
    z[4,8,1]  R1622     6.0926729440689087e-01
    z[4,8,1]  R1623     4.8369586467742920e-01
    z[4,8,1]  R1624     3.7400382757186890e-01
    z[4,8,1]  R1625     -1.2066167593002319e-01
    z[4,8,1]  R1626     1.7116256058216095e-01
    z[4,8,1]  R1627     7.6513302326202393e-01
    z[4,8,1]  R1628     5.2339071035385132e-01
    z[4,8,1]  R1629     0.455557644367218
    z[4,8,1]  R1630     6.0648965835571289e-01
    z[4,8,1]  R1631     4.8109039664268494e-02
    z[4,8,1]  R1632     3.3454573154449463e-01
    z[4,8,1]  R1633     -2.9857018589973450e-01
    z[4,8,1]  R1634     -3.3517763018608093e-01
    z[4,8,1]  R1635     -2.6409623026847839e-01
    z[4,8,1]  R1636     -2.1585391461849213e-01
    z[4,8,1]  R1637     8.9994736015796661e-02
    z[4,8,1]  R1638     4.0385362505912781e-01
    z[4,8,1]  R1639     -8.3998240530490875e-02
    z[4,8,1]  R1640     -3.7127882242202759e-02
    z[4,8,1]  R1641     -2.1206183731555939e-01
    z[4,8,1]  R1642     -1.3824828900396824e-02
    z[4,8,1]  R1643     9.6397131681442261e-02
    z[4,8,1]  R1644     -7.7029550075531006e-01
    z[4,8,1]  R1645     -2.8874117136001587e-01
    z[4,8,1]  R1646     -1.6220785677433014e-01
    z[4,8,1]  R1647     1.3882428407669067e-01
    z[4,8,1]  R1648     0.546604573726654
    z[4,8,2]  R40       -1
    z[4,8,2]  R76       1
    z[4,8,2]  R1595     -1
    z[4,8,2]  R1596     1
    z[4,8,2]  R1605     2.7030757069587708e-01
    z[4,8,2]  R1606     9.6585564315319061e-02
    z[4,8,2]  R1607     -1.9237211346626282e-01
    z[4,8,2]  R1608     2.0158283412456512e-01
    z[4,8,2]  R1609     1.0820751637220383e-01
    z[4,8,2]  R1610     1.0771740972995758e-01
    z[4,8,2]  R1611     1.6107057034969330e-01
    z[4,8,2]  R1612     7.2462931275367737e-03
    z[4,8,2]  R1613     -3.8359690457582474e-02
    z[4,8,2]  R1614     -1.4830297231674194e-01
    z[4,8,2]  R1615     -2.0888724923133850e-01
    z[4,8,2]  R1616     4.2630749940872192e-01
    z[4,8,2]  R1617     0.534913182258606
    z[4,8,2]  R1618     -3.7196657061576843e-01
    z[4,8,2]  R1619     -1.1329184472560883e-01
    z[4,8,2]  R1620     2.6715528219938278e-02
    z[4,8,2]  R1621     1.4443910121917725e-01
    z[4,8,2]  R1622     9.2906527221202850e-02
    z[4,8,2]  R1623     4.7078814357519150e-02
    z[4,8,2]  R1624     2.7288424968719482e-01
    z[4,8,2]  R1625     5.6478178501129150e-01
    z[4,8,2]  R1626     8.2377445697784424e-01
    z[4,8,2]  R1627     1.4372408390045166e-01
    z[4,8,2]  R1628     -4.4087201356887817e-01
    z[4,8,2]  R1629     3.5574379563331604e-01
    z[4,8,2]  R1630     -1.5888983383774757e-02
    z[4,8,2]  R1631     -2.5834247469902039e-01
    z[4,8,2]  R1632     1.3997702300548553e-01
    z[4,8,2]  R1633     2.3916728794574738e-01
    z[4,8,2]  R1634     -3.2332172989845276e-01
    z[4,8,2]  R1635     1.4474992454051971e-01
    z[4,8,2]  R1636     8.2499951124191284e-02
    z[4,8,2]  R1637     3.6355210468173027e-03
    z[4,8,2]  R1638     3.0835175514221191e-01
    z[4,8,2]  R1639     -0.819757878780365
    z[4,8,2]  R1640     -0.00738651305437088
    z[4,8,2]  R1641     -1.0767484456300735e-01
    z[4,8,2]  R1642     -3.7795655429363251e-02
    z[4,8,2]  R1643     8.5781373083591461e-02
    z[4,8,2]  R1644     -3.0338302254676819e-01
    z[4,8,2]  R1645     -2.7365781366825104e-02
    z[4,8,2]  R1646     -2.1361067891120911e-01
    z[4,8,2]  R1647     -1.2696257233619690e-01
    z[4,8,2]  R1648     -5.8996188640594482e-01
    z[4,8,3]  R41       -1
    z[4,8,3]  R77       1
    z[4,8,3]  R1597     -1
    z[4,8,3]  R1598     1
    z[4,8,3]  R1605     -4.8889175057411194e-01
    z[4,8,3]  R1606     -7.8584265708923340e-01
    z[4,8,3]  R1607     -1.9428165256977081e-01
    z[4,8,3]  R1608     -1.0201204568147659e-01
    z[4,8,3]  R1609     -0.417267382144928
    z[4,8,3]  R1610     -4.6351003646850586e-01
    z[4,8,3]  R1611     -3.3292523026466370e-01
    z[4,8,3]  R1612     -0.37607541680336
    z[4,8,3]  R1613     -3.0490785837173462e-01
    z[4,8,3]  R1614     -0.0989907830953598
    z[4,8,3]  R1615     6.0548400506377220e-03
    z[4,8,3]  R1616     -0.00725465826690197
    z[4,8,3]  R1617     -0.219582200050354
    z[4,8,3]  R1618     -2.7254137396812439e-01
    z[4,8,3]  R1619     4.3601036071777344e-02
    z[4,8,3]  R1620     6.6809900104999542e-02
    z[4,8,3]  R1621     -7.9151391983032227e-02
    z[4,8,3]  R1622     -6.2500024214386940e-03
    z[4,8,3]  R1623     -0.00627180514857173
    z[4,8,3]  R1624     0.0092415576800704
    z[4,8,3]  R1625     2.8565520048141479e-01
    z[4,8,3]  R1626     -2.5335285812616348e-02
    z[4,8,3]  R1627     -2.9324862360954285e-01
    z[4,8,3]  R1628     -2.7659258246421814e-01
    z[4,8,3]  R1629     -4.1543912887573242e-01
    z[4,8,3]  R1630     -7.1238003671169281e-02
    z[4,8,3]  R1631     -7.6885324716567993e-01
    z[4,8,3]  R1632     -5.7068192958831787e-01
    z[4,8,3]  R1633     -0.821049153804779
    z[4,8,3]  R1634     -7.8540176153182983e-02
    z[4,8,3]  R1635     -5.6368821859359741e-01
    z[4,8,3]  R1636     -3.5935062170028687e-01
    z[4,8,3]  R1637     -2.0003998279571533e-01
    z[4,8,3]  R1638     7.6669089496135712e-02
    z[4,8,3]  R1639     1.6064124181866646e-02
    z[4,8,3]  R1640     1.5017512440681458e-01
    z[4,8,3]  R1641     1.1551170796155930e-01
    z[4,8,3]  R1642     1.5412843227386475e-01
    z[4,8,3]  R1643     -5.8783199638128281e-02
    z[4,8,3]  R1644     1.8461252748966217e-01
    z[4,8,3]  R1645     1.6735152900218964e-01
    z[4,8,3]  R1646     2.1953256428241730e-01
    z[4,8,3]  R1647     1.6128091514110565e-01
    z[4,8,3]  R1648     1.0005152225494385e-01
    z[4,8,4]  R42       -1
    z[4,8,4]  R78       1
    z[4,8,4]  R1599     -1
    z[4,8,4]  R1600     1
    z[4,8,4]  R1605     -3.5046611446887255e-03
    z[4,8,4]  R1606     1.1596713215112686e-01
    z[4,8,4]  R1607     1.9420546293258667e-01
    z[4,8,4]  R1608     -3.9147242903709412e-01
    z[4,8,4]  R1609     2.0783146843314171e-02
    z[4,8,4]  R1610     1.0750199854373932e-01
    z[4,8,4]  R1611     -2.6204988360404968e-01
    z[4,8,4]  R1612     5.3113603591918945e-01
    z[4,8,4]  R1613     -7.2880500555038452e-01
    z[4,8,4]  R1614     4.5618328452110291e-01
    z[4,8,4]  R1615     4.2399752140045166e-01
    z[4,8,4]  R1616     -2.5723323225975037e-01
    z[4,8,4]  R1617     -1.2136476114392281e-02
    z[4,8,4]  R1618     -1.1006093025207520e-01
    z[4,8,4]  R1619     -2.2480301558971405e-01
    z[4,8,4]  R1620     -2.0080648362636566e-01
    z[4,8,4]  R1621     4.7277133911848068e-02
    z[4,8,4]  R1622     2.2855195403099060e-01
    z[4,8,4]  R1623     7.8527766466140747e-01
    z[4,8,4]  R1624     6.7890977859497070e-01
    z[4,8,4]  R1625     4.8681598901748657e-01
    z[4,8,4]  R1626     -2.9550949111580849e-02
    z[4,8,4]  R1627     -4.9882560968399048e-01
    z[4,8,4]  R1628     -4.8221078515052795e-01
    z[4,8,4]  R1629     6.5729096531867981e-02
    z[4,8,4]  R1630     -5.9800289571285248e-02
    z[4,8,4]  R1631     -4.7893619537353516e-01
    z[4,8,4]  R1632     -3.2204318046569824e-01
    z[4,8,4]  R1633     -1.1985452473163605e-01
    z[4,8,4]  R1634     3.0569615960121155e-01
    z[4,8,4]  R1635     2.8516548871994019e-01
    z[4,8,4]  R1636     4.9322074651718140e-01
    z[4,8,4]  R1637     8.5074788331985474e-01
    z[4,8,4]  R1638     -4.2093902826309204e-02
    z[4,8,4]  R1639     2.4484671652317047e-01
    z[4,8,4]  R1640     -1.6202388331294060e-02
    z[4,8,4]  R1641     1.9603946805000305e-01
    z[4,8,4]  R1642     1.0144042782485485e-02
    z[4,8,4]  R1643     3.8448280096054077e-01
    z[4,8,4]  R1644     0.0856412723660469
    z[4,8,4]  R1645     1.8914036452770233e-01
    z[4,8,4]  R1646     1.9557043910026550e-01
    z[4,8,4]  R1647     3.2393044233322144e-01
    z[4,8,4]  R1648     1.2204378843307495e-01
    z[4,8,5]  R43       -1
    z[4,8,5]  R79       1
    z[4,8,5]  R1601     -1
    z[4,8,5]  R1602     1
    z[4,8,5]  R1605     -3.5775479674339294e-01
    z[4,8,5]  R1606     -1.8148759007453918e-01
    z[4,8,5]  R1607     -7.0211440324783325e-01
    z[4,8,5]  R1608     -3.2426446676254272e-01
    z[4,8,5]  R1609     1.8139944970607758e-01
    z[4,8,5]  R1610     -4.8105177283287048e-01
    z[4,8,5]  R1611     -5.8350992202758789e-01
    z[4,8,5]  R1612     -3.8507875800132751e-01
    z[4,8,5]  R1613     0.141758531332016
    z[4,8,5]  R1614     3.7513709068298340e-01
    z[4,8,5]  R1615     3.7390294671058655e-01
    z[4,8,5]  R1616     5.7006757706403732e-02
    z[4,8,5]  R1617     3.6030483245849609e-01
    z[4,8,5]  R1618     -2.1258337795734406e-01
    z[4,8,5]  R1619     4.0506568551063538e-01
    z[4,8,5]  R1620     4.5777502655982971e-01
    z[4,8,5]  R1621     5.5498993396759033e-01
    z[4,8,5]  R1622     2.8004467487335205e-01
    z[4,8,5]  R1623     3.0015367269515991e-01
    z[4,8,5]  R1624     4.6198898553848267e-01
    z[4,8,5]  R1625     0.150673970580101
    z[4,8,5]  R1626     2.3514720797538757e-01
    z[4,8,5]  R1627     -0.124564990401268
    z[4,8,5]  R1628     -3.4364455938339233e-01
    z[4,8,5]  R1629     6.0427474975585938e-01
    z[4,8,5]  R1630     4.8606848716735840e-01
    z[4,8,5]  R1631     -1.3279798626899719e-01
    z[4,8,5]  R1632     1.5413187444210052e-02
    z[4,8,5]  R1633     -7.6223835349082947e-02
    z[4,8,5]  R1634     -1.9351997971534729e-01
    z[4,8,5]  R1635     -0.581364095211029
    z[4,8,5]  R1636     0.388720840215683
    z[4,8,5]  R1637     -1.1550952494144440e-01
    z[4,8,5]  R1638     -7.7131915092468262e-01
    z[4,8,5]  R1639     4.2888391017913818e-01
    z[4,8,5]  R1640     -9.8720449209213257e-01
    z[4,8,5]  R1641     -1.4730840921401978e-01
    z[4,8,5]  R1642     3.9859893918037415e-01
    z[4,8,5]  R1643     2.4619343876838684e-01
    z[4,8,5]  R1644     4.8062625527381897e-01
    z[4,8,5]  R1645     8.2773292064666748e-01
    z[4,8,5]  R1646     7.4844104051589966e-01
    z[4,8,5]  R1647     0.447476863861084
    z[4,8,5]  R1648     -6.6538691520690918e-02
    z[4,8,6]  R44       -1
    z[4,8,6]  R80       1
    z[4,8,6]  R1603     -1
    z[4,8,6]  R1604     1
    z[4,8,6]  R1605     -1.0689639300107956e-01
    z[4,8,6]  R1606     -3.1988203525543213e-01
    z[4,8,6]  R1607     9.7331300377845764e-02
    z[4,8,6]  R1608     -7.3835670948028564e-01
    z[4,8,6]  R1609     8.1823396682739258e-01
    z[4,8,6]  R1610     1.9979335367679596e-01
    z[4,8,6]  R1611     6.3154637813568115e-01
    z[4,8,6]  R1612     6.3705819845199585e-01
    z[4,8,6]  R1613     -3.9951688051223755e-01
    z[4,8,6]  R1614     1.0409250855445862e-02
    z[4,8,6]  R1615     7.7651664614677429e-03
    z[4,8,6]  R1616     4.5951329171657562e-02
    z[4,8,6]  R1617     -1.9262865185737610e-01
    z[4,8,6]  R1618     -1.3276958465576172e-01
    z[4,8,6]  R1619     2.3632231354713440e-01
    z[4,8,6]  R1620     3.2438777387142181e-02
    z[4,8,6]  R1621     -0.0494762621819973
    z[4,8,6]  R1622     -5.1954674720764160e-01
    z[4,8,6]  R1623     -2.0025607943534851e-01
    z[4,8,6]  R1624     -1.6473460197448730e-01
    z[4,8,6]  R1625     1.6251062974333763e-02
    z[4,8,6]  R1626     -5.7421583682298660e-02
    z[4,8,6]  R1627     1.4086969196796417e-01
    z[4,8,6]  R1628     2.0949308574199677e-01
    z[4,8,6]  R1629     -1.7429323494434357e-01
    z[4,8,6]  R1630     -3.7158469203859568e-03
    z[4,8,6]  R1631     -2.6471960544586182e-01
    z[4,8,6]  R1632     -2.4849440902471542e-02
    z[4,8,6]  R1633     3.9252853393554688e-01
    z[4,8,6]  R1634     -6.2235909700393677e-01
    z[4,8,6]  R1635     -3.1920313835144043e-01
    z[4,8,6]  R1636     -4.4289040565490723e-01
    z[4,8,6]  R1637     -4.0792697668075562e-01
    z[4,8,6]  R1638     1.1715488135814667e-01
    z[4,8,6]  R1639     1.8136323988437653e-01
    z[4,8,6]  R1640     -3.3886294811964035e-02
    z[4,8,6]  R1641     -1.8405759707093239e-02
    z[4,8,6]  R1642     6.0048587620258331e-02
    z[4,8,6]  R1643     -3.6136958748102188e-02
    z[4,8,6]  R1644     1.1217761784791946e-01
    z[4,8,6]  R1645     1.3049735128879547e-01
    z[4,8,6]  R1646     0.371138334274292
    z[4,8,6]  R1647     0.768406093120575
    z[4,8,6]  R1648     0.569032609462738
    z[8,4,0]  R38       1
    z[8,4,0]  R74       -1
    z[8,4,0]  R1649     -1
    z[8,4,0]  R1650     1
    z[8,4,0]  R1663     -1.5072417259216309e-01
    z[8,4,0]  R1664     6.6199767589569092e-01
    z[8,4,0]  R1665     -7.2658807039260864e-02
    z[8,4,0]  R1666     5.0864481925964355e-01
    z[8,4,0]  R1667     2.6525846123695374e-01
    z[8,4,0]  R1668     4.7638800740242004e-01
    z[8,4,0]  R1669     2.1989306807518005e-01
    z[8,4,0]  R1670     -3.5427814722061157e-01
    z[8,4,0]  R1671     -2.0952154695987701e-01
    z[8,4,0]  R1672     -5.5590067058801651e-03
    z[8,4,0]  R1673     -9.3253576755523682e-01
    z[8,4,0]  R1674     -9.0112978219985962e-01
    z[8,4,0]  R1675     -8.7758165597915649e-01
    z[8,4,0]  R1676     1.7205205559730530e-01
    z[8,4,0]  R1677     3.8720494508743286e-01
    z[8,4,0]  R1678     3.7908968329429626e-01
    z[8,4,0]  R1679     2.0732177793979645e-01
    z[8,4,0]  R1680     -6.1520463787019253e-03
    z[8,4,0]  R1681     6.0462176799774170e-01
    z[8,4,0]  R1682     2.9137367010116577e-01
    z[8,4,0]  R1683     5.6002104282379150e-01
    z[8,4,0]  R1684     3.1382495164871216e-01
    z[8,4,0]  R1685     2.9768326878547668e-01
    z[8,4,0]  R1686     -0.141557976603508
    z[8,4,0]  R1687     -2.0994892716407776e-01
    z[8,4,0]  R1688     -1.0216555744409561e-01
    z[8,4,0]  R1689     -2.7833974361419678e-01
    z[8,4,0]  R1690     -6.1229479312896729e-01
    z[8,4,0]  R1691     -4.3129128217697144e-01
    z[8,4,0]  R1692     2.6894053816795349e-01
    z[8,4,0]  R1693     0.0671851858496666
    z[8,4,0]  R1694     -4.3774917721748352e-01
    z[8,4,0]  R1695     -5.8658456802368164e-01
    z[8,4,0]  R1696     -5.5617743730545044e-01
    z[8,4,0]  R1697     -5.1447862386703491e-01
    z[8,4,0]  R1698     -4.6854338049888611e-01
    z[8,4,0]  R1699     1.3010308146476746e-01
    z[8,4,0]  R1700     2.8996556997299194e-01
    z[8,4,0]  R1701     5.7000595331192017e-01
    z[8,4,0]  R1702     -4.8165583610534668e-01
    z[8,4,0]  R1703     1.5405304729938507e-01
    z[8,4,0]  R1704     -2.4634206295013428e-01
    z[8,4,0]  R1705     -3.0574074387550354e-01
    z[8,4,0]  R1706     -0.622085690498352
    z[8,4,1]  R39       1
    z[8,4,1]  R75       -1
    z[8,4,1]  R1651     -1
    z[8,4,1]  R1652     1
    z[8,4,1]  R1663     4.8109039664268494e-02
    z[8,4,1]  R1664     3.3454573154449463e-01
    z[8,4,1]  R1665     -2.9857018589973450e-01
    z[8,4,1]  R1666     -3.3517763018608093e-01
    z[8,4,1]  R1667     -2.6409623026847839e-01
    z[8,4,1]  R1668     -2.1585391461849213e-01
    z[8,4,1]  R1669     8.9994736015796661e-02
    z[8,4,1]  R1670     4.0385362505912781e-01
    z[8,4,1]  R1671     -8.3998240530490875e-02
    z[8,4,1]  R1672     -3.7127882242202759e-02
    z[8,4,1]  R1673     -2.1206183731555939e-01
    z[8,4,1]  R1674     -1.3824828900396824e-02
    z[8,4,1]  R1675     9.6397131681442261e-02
    z[8,4,1]  R1676     -7.7029550075531006e-01
    z[8,4,1]  R1677     -2.8874117136001587e-01
    z[8,4,1]  R1678     -1.6220785677433014e-01
    z[8,4,1]  R1679     1.3882428407669067e-01
    z[8,4,1]  R1680     0.546604573726654
    z[8,4,1]  R1681     -0.427695631980896
    z[8,4,1]  R1682     -3.7351474165916443e-01
    z[8,4,1]  R1683     -2.6733905076980591e-01
    z[8,4,1]  R1684     -2.1657115221023560e-01
    z[8,4,1]  R1685     -1.5072849392890930e-01
    z[8,4,1]  R1686     6.8602615594863892e-01
    z[8,4,1]  R1687     1.0551681369543076e-01
    z[8,4,1]  R1688     1.0882353782653809e-01
    z[8,4,1]  R1689     -0.342375248670578
    z[8,4,1]  R1690     4.9433064460754395e-01
    z[8,4,1]  R1691     -6.7132681608200073e-01
    z[8,4,1]  R1692     0.82118821144104
    z[8,4,1]  R1693     7.0289772748947144e-01
    z[8,4,1]  R1694     7.2166818380355835e-01
    z[8,4,1]  R1695     6.0886752605438232e-01
    z[8,4,1]  R1696     6.5920859575271606e-01
    z[8,4,1]  R1697     6.2887781858444214e-01
    z[8,4,1]  R1698     6.0926729440689087e-01
    z[8,4,1]  R1699     4.8369586467742920e-01
    z[8,4,1]  R1700     3.7400382757186890e-01
    z[8,4,1]  R1701     -1.2066167593002319e-01
    z[8,4,1]  R1702     1.7116256058216095e-01
    z[8,4,1]  R1703     7.6513302326202393e-01
    z[8,4,1]  R1704     5.2339071035385132e-01
    z[8,4,1]  R1705     0.455557644367218
    z[8,4,1]  R1706     6.0648965835571289e-01
    z[8,4,2]  R40       1
    z[8,4,2]  R76       -1
    z[8,4,2]  R1653     -1
    z[8,4,2]  R1654     1
    z[8,4,2]  R1663     -2.5834247469902039e-01
    z[8,4,2]  R1664     1.3997702300548553e-01
    z[8,4,2]  R1665     2.3916728794574738e-01
    z[8,4,2]  R1666     -3.2332172989845276e-01
    z[8,4,2]  R1667     1.4474992454051971e-01
    z[8,4,2]  R1668     8.2499951124191284e-02
    z[8,4,2]  R1669     3.6355210468173027e-03
    z[8,4,2]  R1670     3.0835175514221191e-01
    z[8,4,2]  R1671     -0.819757878780365
    z[8,4,2]  R1672     -0.00738651305437088
    z[8,4,2]  R1673     -1.0767484456300735e-01
    z[8,4,2]  R1674     -3.7795655429363251e-02
    z[8,4,2]  R1675     8.5781373083591461e-02
    z[8,4,2]  R1676     -3.0338302254676819e-01
    z[8,4,2]  R1677     -2.7365781366825104e-02
    z[8,4,2]  R1678     -2.1361067891120911e-01
    z[8,4,2]  R1679     -1.2696257233619690e-01
    z[8,4,2]  R1680     -5.8996188640594482e-01
    z[8,4,2]  R1681     2.7030757069587708e-01
    z[8,4,2]  R1682     9.6585564315319061e-02
    z[8,4,2]  R1683     -1.9237211346626282e-01
    z[8,4,2]  R1684     2.0158283412456512e-01
    z[8,4,2]  R1685     1.0820751637220383e-01
    z[8,4,2]  R1686     1.0771740972995758e-01
    z[8,4,2]  R1687     1.6107057034969330e-01
    z[8,4,2]  R1688     7.2462931275367737e-03
    z[8,4,2]  R1689     -3.8359690457582474e-02
    z[8,4,2]  R1690     -1.4830297231674194e-01
    z[8,4,2]  R1691     -2.0888724923133850e-01
    z[8,4,2]  R1692     4.2630749940872192e-01
    z[8,4,2]  R1693     0.534913182258606
    z[8,4,2]  R1694     -3.7196657061576843e-01
    z[8,4,2]  R1695     -1.1329184472560883e-01
    z[8,4,2]  R1696     2.6715528219938278e-02
    z[8,4,2]  R1697     1.4443910121917725e-01
    z[8,4,2]  R1698     9.2906527221202850e-02
    z[8,4,2]  R1699     4.7078814357519150e-02
    z[8,4,2]  R1700     2.7288424968719482e-01
    z[8,4,2]  R1701     5.6478178501129150e-01
    z[8,4,2]  R1702     8.2377445697784424e-01
    z[8,4,2]  R1703     1.4372408390045166e-01
    z[8,4,2]  R1704     -4.4087201356887817e-01
    z[8,4,2]  R1705     3.5574379563331604e-01
    z[8,4,2]  R1706     -1.5888983383774757e-02
    z[8,4,3]  R41       1
    z[8,4,3]  R77       -1
    z[8,4,3]  R1655     -1
    z[8,4,3]  R1656     1
    z[8,4,3]  R1663     -7.6885324716567993e-01
    z[8,4,3]  R1664     -5.7068192958831787e-01
    z[8,4,3]  R1665     -0.821049153804779
    z[8,4,3]  R1666     -7.8540176153182983e-02
    z[8,4,3]  R1667     -5.6368821859359741e-01
    z[8,4,3]  R1668     -3.5935062170028687e-01
    z[8,4,3]  R1669     -2.0003998279571533e-01
    z[8,4,3]  R1670     7.6669089496135712e-02
    z[8,4,3]  R1671     1.6064124181866646e-02
    z[8,4,3]  R1672     1.5017512440681458e-01
    z[8,4,3]  R1673     1.1551170796155930e-01
    z[8,4,3]  R1674     1.5412843227386475e-01
    z[8,4,3]  R1675     -5.8783199638128281e-02
    z[8,4,3]  R1676     1.8461252748966217e-01
    z[8,4,3]  R1677     1.6735152900218964e-01
    z[8,4,3]  R1678     2.1953256428241730e-01
    z[8,4,3]  R1679     1.6128091514110565e-01
    z[8,4,3]  R1680     1.0005152225494385e-01
    z[8,4,3]  R1681     -4.8889175057411194e-01
    z[8,4,3]  R1682     -7.8584265708923340e-01
    z[8,4,3]  R1683     -1.9428165256977081e-01
    z[8,4,3]  R1684     -1.0201204568147659e-01
    z[8,4,3]  R1685     -0.417267382144928
    z[8,4,3]  R1686     -4.6351003646850586e-01
    z[8,4,3]  R1687     -3.3292523026466370e-01
    z[8,4,3]  R1688     -0.37607541680336
    z[8,4,3]  R1689     -3.0490785837173462e-01
    z[8,4,3]  R1690     -0.0989907830953598
    z[8,4,3]  R1691     6.0548400506377220e-03
    z[8,4,3]  R1692     -0.00725465826690197
    z[8,4,3]  R1693     -0.219582200050354
    z[8,4,3]  R1694     -2.7254137396812439e-01
    z[8,4,3]  R1695     4.3601036071777344e-02
    z[8,4,3]  R1696     6.6809900104999542e-02
    z[8,4,3]  R1697     -7.9151391983032227e-02
    z[8,4,3]  R1698     -6.2500024214386940e-03
    z[8,4,3]  R1699     -0.00627180514857173
    z[8,4,3]  R1700     0.0092415576800704
    z[8,4,3]  R1701     2.8565520048141479e-01
    z[8,4,3]  R1702     -2.5335285812616348e-02
    z[8,4,3]  R1703     -2.9324862360954285e-01
    z[8,4,3]  R1704     -2.7659258246421814e-01
    z[8,4,3]  R1705     -4.1543912887573242e-01
    z[8,4,3]  R1706     -7.1238003671169281e-02
    z[8,4,4]  R42       1
    z[8,4,4]  R78       -1
    z[8,4,4]  R1657     -1
    z[8,4,4]  R1658     1
    z[8,4,4]  R1663     -4.7893619537353516e-01
    z[8,4,4]  R1664     -3.2204318046569824e-01
    z[8,4,4]  R1665     -1.1985452473163605e-01
    z[8,4,4]  R1666     3.0569615960121155e-01
    z[8,4,4]  R1667     2.8516548871994019e-01
    z[8,4,4]  R1668     4.9322074651718140e-01
    z[8,4,4]  R1669     8.5074788331985474e-01
    z[8,4,4]  R1670     -4.2093902826309204e-02
    z[8,4,4]  R1671     2.4484671652317047e-01
    z[8,4,4]  R1672     -1.6202388331294060e-02
    z[8,4,4]  R1673     1.9603946805000305e-01
    z[8,4,4]  R1674     1.0144042782485485e-02
    z[8,4,4]  R1675     3.8448280096054077e-01
    z[8,4,4]  R1676     0.0856412723660469
    z[8,4,4]  R1677     1.8914036452770233e-01
    z[8,4,4]  R1678     1.9557043910026550e-01
    z[8,4,4]  R1679     3.2393044233322144e-01
    z[8,4,4]  R1680     1.2204378843307495e-01
    z[8,4,4]  R1681     -3.5046611446887255e-03
    z[8,4,4]  R1682     1.1596713215112686e-01
    z[8,4,4]  R1683     1.9420546293258667e-01
    z[8,4,4]  R1684     -3.9147242903709412e-01
    z[8,4,4]  R1685     2.0783146843314171e-02
    z[8,4,4]  R1686     1.0750199854373932e-01
    z[8,4,4]  R1687     -2.6204988360404968e-01
    z[8,4,4]  R1688     5.3113603591918945e-01
    z[8,4,4]  R1689     -7.2880500555038452e-01
    z[8,4,4]  R1690     4.5618328452110291e-01
    z[8,4,4]  R1691     4.2399752140045166e-01
    z[8,4,4]  R1692     -2.5723323225975037e-01
    z[8,4,4]  R1693     -1.2136476114392281e-02
    z[8,4,4]  R1694     -1.1006093025207520e-01
    z[8,4,4]  R1695     -2.2480301558971405e-01
    z[8,4,4]  R1696     -2.0080648362636566e-01
    z[8,4,4]  R1697     4.7277133911848068e-02
    z[8,4,4]  R1698     2.2855195403099060e-01
    z[8,4,4]  R1699     7.8527766466140747e-01
    z[8,4,4]  R1700     6.7890977859497070e-01
    z[8,4,4]  R1701     4.8681598901748657e-01
    z[8,4,4]  R1702     -2.9550949111580849e-02
    z[8,4,4]  R1703     -4.9882560968399048e-01
    z[8,4,4]  R1704     -4.8221078515052795e-01
    z[8,4,4]  R1705     6.5729096531867981e-02
    z[8,4,4]  R1706     -5.9800289571285248e-02
    z[8,4,5]  R43       1
    z[8,4,5]  R79       -1
    z[8,4,5]  R1659     -1
    z[8,4,5]  R1660     1
    z[8,4,5]  R1663     -1.3279798626899719e-01
    z[8,4,5]  R1664     1.5413187444210052e-02
    z[8,4,5]  R1665     -7.6223835349082947e-02
    z[8,4,5]  R1666     -1.9351997971534729e-01
    z[8,4,5]  R1667     -0.581364095211029
    z[8,4,5]  R1668     0.388720840215683
    z[8,4,5]  R1669     -1.1550952494144440e-01
    z[8,4,5]  R1670     -7.7131915092468262e-01
    z[8,4,5]  R1671     4.2888391017913818e-01
    z[8,4,5]  R1672     -9.8720449209213257e-01
    z[8,4,5]  R1673     -1.4730840921401978e-01
    z[8,4,5]  R1674     3.9859893918037415e-01
    z[8,4,5]  R1675     2.4619343876838684e-01
    z[8,4,5]  R1676     4.8062625527381897e-01
    z[8,4,5]  R1677     8.2773292064666748e-01
    z[8,4,5]  R1678     7.4844104051589966e-01
    z[8,4,5]  R1679     0.447476863861084
    z[8,4,5]  R1680     -6.6538691520690918e-02
    z[8,4,5]  R1681     -3.5775479674339294e-01
    z[8,4,5]  R1682     -1.8148759007453918e-01
    z[8,4,5]  R1683     -7.0211440324783325e-01
    z[8,4,5]  R1684     -3.2426446676254272e-01
    z[8,4,5]  R1685     1.8139944970607758e-01
    z[8,4,5]  R1686     -4.8105177283287048e-01
    z[8,4,5]  R1687     -5.8350992202758789e-01
    z[8,4,5]  R1688     -3.8507875800132751e-01
    z[8,4,5]  R1689     0.141758531332016
    z[8,4,5]  R1690     3.7513709068298340e-01
    z[8,4,5]  R1691     3.7390294671058655e-01
    z[8,4,5]  R1692     5.7006757706403732e-02
    z[8,4,5]  R1693     3.6030483245849609e-01
    z[8,4,5]  R1694     -2.1258337795734406e-01
    z[8,4,5]  R1695     4.0506568551063538e-01
    z[8,4,5]  R1696     4.5777502655982971e-01
    z[8,4,5]  R1697     5.5498993396759033e-01
    z[8,4,5]  R1698     2.8004467487335205e-01
    z[8,4,5]  R1699     3.0015367269515991e-01
    z[8,4,5]  R1700     4.6198898553848267e-01
    z[8,4,5]  R1701     0.150673970580101
    z[8,4,5]  R1702     2.3514720797538757e-01
    z[8,4,5]  R1703     -0.124564990401268
    z[8,4,5]  R1704     -3.4364455938339233e-01
    z[8,4,5]  R1705     6.0427474975585938e-01
    z[8,4,5]  R1706     4.8606848716735840e-01
    z[8,4,6]  R44       1
    z[8,4,6]  R80       -1
    z[8,4,6]  R1661     -1
    z[8,4,6]  R1662     1
    z[8,4,6]  R1663     -2.6471960544586182e-01
    z[8,4,6]  R1664     -2.4849440902471542e-02
    z[8,4,6]  R1665     3.9252853393554688e-01
    z[8,4,6]  R1666     -6.2235909700393677e-01
    z[8,4,6]  R1667     -3.1920313835144043e-01
    z[8,4,6]  R1668     -4.4289040565490723e-01
    z[8,4,6]  R1669     -4.0792697668075562e-01
    z[8,4,6]  R1670     1.1715488135814667e-01
    z[8,4,6]  R1671     1.8136323988437653e-01
    z[8,4,6]  R1672     -3.3886294811964035e-02
    z[8,4,6]  R1673     -1.8405759707093239e-02
    z[8,4,6]  R1674     6.0048587620258331e-02
    z[8,4,6]  R1675     -3.6136958748102188e-02
    z[8,4,6]  R1676     1.1217761784791946e-01
    z[8,4,6]  R1677     1.3049735128879547e-01
    z[8,4,6]  R1678     0.371138334274292
    z[8,4,6]  R1679     0.768406093120575
    z[8,4,6]  R1680     0.569032609462738
    z[8,4,6]  R1681     -1.0689639300107956e-01
    z[8,4,6]  R1682     -3.1988203525543213e-01
    z[8,4,6]  R1683     9.7331300377845764e-02
    z[8,4,6]  R1684     -7.3835670948028564e-01
    z[8,4,6]  R1685     8.1823396682739258e-01
    z[8,4,6]  R1686     1.9979335367679596e-01
    z[8,4,6]  R1687     6.3154637813568115e-01
    z[8,4,6]  R1688     6.3705819845199585e-01
    z[8,4,6]  R1689     -3.9951688051223755e-01
    z[8,4,6]  R1690     1.0409250855445862e-02
    z[8,4,6]  R1691     7.7651664614677429e-03
    z[8,4,6]  R1692     4.5951329171657562e-02
    z[8,4,6]  R1693     -1.9262865185737610e-01
    z[8,4,6]  R1694     -1.3276958465576172e-01
    z[8,4,6]  R1695     2.3632231354713440e-01
    z[8,4,6]  R1696     3.2438777387142181e-02
    z[8,4,6]  R1697     -0.0494762621819973
    z[8,4,6]  R1698     -5.1954674720764160e-01
    z[8,4,6]  R1699     -2.0025607943534851e-01
    z[8,4,6]  R1700     -1.6473460197448730e-01
    z[8,4,6]  R1701     1.6251062974333763e-02
    z[8,4,6]  R1702     -5.7421583682298660e-02
    z[8,4,6]  R1703     1.4086969196796417e-01
    z[8,4,6]  R1704     2.0949308574199677e-01
    z[8,4,6]  R1705     -1.7429323494434357e-01
    z[8,4,6]  R1706     -3.7158469203859568e-03
    z[5,6,0]  R47       -1
    z[5,6,0]  R56       1
    z[5,6,0]  R1747     -1
    z[5,6,0]  R1748     1
    z[5,6,0]  R1761     -4.1581445932388306e-01
    z[5,6,0]  R1762     -7.1382147073745728e-01
    z[5,6,0]  R1763     -4.4117593765258789e-01
    z[5,6,0]  R1764     3.0876708030700684e-01
    z[5,6,0]  R1765     -0.468372106552124
    z[5,6,0]  R1766     3.7482929229736328e-01
    z[5,6,0]  R1767     3.0678293108940125e-01
    z[5,6,0]  R1768     2.1084308624267578e-01
    z[5,6,0]  R1769     -1.6066245734691620e-01
    z[5,6,0]  R1770     -1.2283680588006973e-01
    z[5,6,0]  R1771     1.3883158564567566e-01
    z[5,6,0]  R1772     2.9173580929636955e-02
    z[5,6,0]  R1773     4.5376399159431458e-01
    z[5,6,0]  R1774     2.4065634608268738e-01
    z[5,6,0]  R1775     7.0959097146987915e-01
    z[5,6,0]  R1776     -6.0118097066879272e-01
    z[5,6,0]  R1777     -4.8264107108116150e-01
    z[5,6,0]  R1778     0.0402534045279026
    z[5,6,0]  R1779     6.0055327415466309e-01
    z[5,6,0]  R1780     -8.7000322341918945e-01
    z[5,6,0]  R1781     -1.6710819303989410e-01
    z[5,6,0]  R1782     5.1962143182754517e-01
    z[5,6,0]  R1783     2.4668073654174805e-01
    z[5,6,0]  R1784     2.4670842289924622e-01
    z[5,6,0]  R1785     1.4420443773269653e-01
    z[5,6,0]  R1786     -5.6685519218444824e-01
    z[5,6,0]  R1787     -1.6137033700942993e-01
    z[5,6,0]  R1788     -6.2655562162399292e-01
    z[5,6,0]  R1789     2.0319147035479546e-02
    z[5,6,0]  R1790     -4.3238359689712524e-01
    z[5,6,0]  R1791     1.7326253652572632e-01
    z[5,6,0]  R1792     0.472392737865448
    z[5,6,0]  R1793     2.1025046706199646e-01
    z[5,6,0]  R1794     -1.4568910002708435e-01
    z[5,6,0]  R1795     -2.6236453652381897e-01
    z[5,6,0]  R1796     -2.3091338574886322e-01
    z[5,6,0]  R1797     2.8852918744087219e-01
    z[5,6,0]  R1798     -5.0840634107589722e-01
    z[5,6,0]  R1799     5.3634464740753174e-01
    z[5,6,0]  R1800     -1.7589415609836578e-01
    z[5,6,0]  R1801     2.1643792092800140e-01
    z[5,6,0]  R1802     3.8719531893730164e-01
    z[5,6,0]  R1803     -3.2949864864349365e-01
    z[5,6,0]  R1804     3.3848136663436890e-01
    z[5,6,0]  R1805     -3.5411331057548523e-01
    z[5,6,0]  R1806     -0.465248167514801
    z[5,6,0]  R1807     2.3825326561927795e-01
    z[5,6,0]  R1808     5.5241864919662476e-01
    z[5,6,0]  R1809     -0.437234103679657
    z[5,6,0]  R1810     -5.3801500797271729e-01
    z[5,6,0]  R1811     3.4132543206214905e-01
    z[5,6,0]  R1812     -2.3048569262027740e-01
    z[5,6,0]  R1813     0.0930616706609726
    z[5,6,0]  R1814     2.5502392649650574e-01
    z[5,6,0]  R1815     -1.9639667868614197e-01
    z[5,6,0]  R1816     -3.8214358687400818e-01
    z[5,6,0]  R1817     -5.0560951232910156e-01
    z[5,6,0]  R1818     -3.2939481735229492e-01
    z[5,6,0]  R1819     -3.9098620414733887e-01
    z[5,6,0]  R1820     -3.3695119619369507e-01
    z[5,6,0]  R1821     -3.5032325983047485e-01
    z[5,6,0]  R1822     -4.1307485103607178e-01
    z[5,6,0]  R1823     -3.8969355821609497e-01
    z[5,6,0]  R1824     3.5542088747024536e-01
    z[5,6,0]  R1825     5.8741962909698486e-01
    z[5,6,0]  R1826     -9.3581545352935791e-01
    z[5,6,0]  R1827     2.1107417345046997e-01
    z[5,6,0]  R1828     -9.1353046894073486e-01
    z[5,6,0]  R1829     1.0356234014034271e-01
    z[5,6,0]  R1830     2.6287612318992615e-01
    z[5,6,0]  R1831     -3.2082059979438782e-01
    z[5,6,0]  R1832     3.8107904791831970e-01
    z[5,6,0]  R1833     -1.7919836938381195e-01
    z[5,6,0]  R1834     1.4544046483933926e-02
    z[5,6,0]  R1835     3.7239700555801392e-01
    z[5,6,0]  R1836     -5.5211794376373291e-01
    z[5,6,0]  R1837     -6.5027683973312378e-01
    z[5,6,0]  R1838     -4.2978027462959290e-01
    z[5,6,0]  R1839     -2.2500525414943695e-01
    z[5,6,0]  R1840     -4.1538852453231812e-01
    z[5,6,0]  R1841     7.6203301548957825e-02
    z[5,6,0]  R1842     3.6446052789688110e-01
    z[5,6,0]  R1843     3.8955527544021606e-01
    z[5,6,0]  R1844     3.9998903870582581e-01
    z[5,6,0]  R1845     3.8935866951942444e-01
    z[5,6,0]  R1846     3.3282566070556641e-01
    z[5,6,0]  R1847     -2.6747867465019226e-01
    z[5,6,0]  R1848     -1.6391228139400482e-01
    z[5,6,0]  R1849     -1.1296674609184265e-01
    z[5,6,0]  R1850     -1.7853356897830963e-01
    z[5,6,0]  R1851     -1.9356290996074677e-01
    z[5,6,0]  R1852     -3.5254049301147461e-01
    z[5,6,0]  R1853     -4.9616798758506775e-01
    z[5,6,0]  R1854     -2.5847837328910828e-01
    z[5,6,0]  R1855     -3.2877001166343689e-01
    z[5,6,0]  R1856     -1.1551152169704437e-01
    z[5,6,0]  R1857     -5.9576874971389771e-01
    z[5,6,0]  R1858     1.4361375570297241e-01
    z[5,6,0]  R1859     -3.2022818922996521e-01
    z[5,6,0]  R1860     -1.5970276296138763e-01
    z[5,6,0]  R1861     -7.2928392887115479e-01
    z[5,6,0]  R1862     -1.5947078168392181e-01
    z[5,6,0]  R1863     5.3713631629943848e-01
    z[5,6,0]  R1864     1.6378110647201538e-01
    z[5,6,0]  R1865     5.4045879840850830e-01
    z[5,6,0]  R1866     4.9611806869506836e-02
    z[5,6,0]  R1867     5.7317632436752319e-01
    z[5,6,0]  R1868     -1.4737339317798615e-01
    z[5,6,0]  R1869     0.0769510343670845
    z[5,6,0]  R1870     6.4041984081268311e-01
    z[5,6,0]  R1871     4.6904885768890381e-01
    z[5,6,0]  R1872     -8.2839828729629517e-01
    z[5,6,0]  R1873     -4.4422608613967896e-01
    z[5,6,0]  R1874     -8.6739659309387207e-05
    z[5,6,0]  R1875     5.7017225027084351e-01
    z[5,6,0]  R1876     -5.3395098447799683e-01
    z[5,6,0]  R1877     2.4247437715530396e-01
    z[5,6,0]  R1878     7.3009556531906128e-01
    z[5,6,0]  R1879     5.3689581155776978e-01
    z[5,6,0]  R1880     6.2699037790298462e-01
    z[5,6,0]  R1881     -4.0640029311180115e-01
    z[5,6,0]  R1882     -6.3726031780242920e-01
    z[5,6,0]  R1883     2.9142358899116516e-01
    z[5,6,0]  R1884     2.7225577831268311e-01
    z[5,6,0]  R1885     -4.4346490502357483e-01
    z[5,6,0]  R1886     4.4495406746864319e-01
    z[5,6,0]  R1887     -9.7905941307544708e-02
    z[5,6,0]  R1888     -5.1565051078796387e-01
    z[5,6,0]  R1889     -0.0890880599617958
    z[5,6,0]  R1890     2.0761384069919586e-01
    z[5,6,0]  R1891     -1.7567798495292664e-01
    z[5,6,0]  R1892     -1.4688614010810852e-01
    z[5,6,0]  R1893     -4.5699721574783325e-01
    z[5,6,0]  R1894     1.1366516351699829e-01
    z[5,6,0]  R1895     0.268271267414093
    z[5,6,0]  R1896     5.0068873167037964e-01
    z[5,6,0]  R1897     6.4537554979324341e-01
    z[5,6,0]  R1898     -4.0659990161657333e-02
    z[5,6,0]  R1899     -9.2636190354824066e-02
    z[5,6,0]  R1900     -3.9719808101654053e-01
    z[5,6,1]  R48       -1
    z[5,6,1]  R57       1
    z[5,6,1]  R1749     -1
    z[5,6,1]  R1750     1
    z[5,6,1]  R1761     5.9958990663290024e-02
    z[5,6,1]  R1762     -5.2166921086609364e-03
    z[5,6,1]  R1763     -4.1477791965007782e-02
    z[5,6,1]  R1764     7.3133128881454468e-01
    z[5,6,1]  R1765     -0.0706862360239029
    z[5,6,1]  R1766     6.9081479310989380e-01
    z[5,6,1]  R1767     6.9255203008651733e-01
    z[5,6,1]  R1768     7.9167377948760986e-01
    z[5,6,1]  R1769     6.6974085569381714e-01
    z[5,6,1]  R1770     8.5541135072708130e-01
    z[5,6,1]  R1771     2.6883864402770996e-01
    z[5,6,1]  R1772     -1.3114847242832184e-01
    z[5,6,1]  R1773     2.3110222816467285e-01
    z[5,6,1]  R1774     -1.0313341766595840e-01
    z[5,6,1]  R1775     3.4971255064010620e-01
    z[5,6,1]  R1776     2.2228454053401947e-01
    z[5,6,1]  R1777     1.7723912000656128e-01
    z[5,6,1]  R1778     1.1129811406135559e-01
    z[5,6,1]  R1779     -4.2762002348899841e-01
    z[5,6,1]  R1780     -2.9504433274269104e-01
    z[5,6,1]  R1781     -1.4158391952514648e-01
    z[5,6,1]  R1782     -0.139053076505661
    z[5,6,1]  R1783     -6.5932208299636841e-01
    z[5,6,1]  R1784     -5.9185934066772461e-01
    z[5,6,1]  R1785     -0.632899284362793
    z[5,6,1]  R1786     -6.1066597700119019e-01
    z[5,6,1]  R1787     5.5079009383916855e-02
    z[5,6,1]  R1788     -6.1779773235321045e-01
    z[5,6,1]  R1789     -5.3355228900909424e-01
    z[5,6,1]  R1790     -1.7407085001468658e-01
    z[5,6,1]  R1791     3.0003988742828369e-01
    z[5,6,1]  R1792     -7.3637050390243530e-01
    z[5,6,1]  R1793     -6.3921970129013062e-01
    z[5,6,1]  R1794     -7.4083238840103149e-01
    z[5,6,1]  R1795     3.7029862403869629e-01
    z[5,6,1]  R1796     -0.419521301984787
    z[5,6,1]  R1797     -7.4704664945602417e-01
    z[5,6,1]  R1798     4.4451199471950531e-02
    z[5,6,1]  R1799     -5.7193356752395630e-01
    z[5,6,1]  R1800     -7.1301937103271484e-01
    z[5,6,1]  R1801     -7.0517992973327637e-01
    z[5,6,1]  R1802     -7.2905343770980835e-01
    z[5,6,1]  R1803     5.4468762874603271e-01
    z[5,6,1]  R1804     -7.1067941188812256e-01
    z[5,6,1]  R1805     -6.4033544063568115e-01
    z[5,6,1]  R1806     -2.7156734466552734e-01
    z[5,6,1]  R1807     -6.5268623828887939e-01
    z[5,6,1]  R1808     -6.1438292264938354e-01
    z[5,6,1]  R1809     -5.6438845396041870e-01
    z[5,6,1]  R1810     -5.1818257570266724e-01
    z[5,6,1]  R1811     -9.1968756914138794e-01
    z[5,6,1]  R1812     9.4391658902168274e-02
    z[5,6,1]  R1813     1.7546078190207481e-02
    z[5,6,1]  R1814     -1.4050704240798950e-01
    z[5,6,1]  R1815     3.2863533496856689e-01
    z[5,6,1]  R1816     -7.3782926797866821e-01
    z[5,6,1]  R1817     1.0161117464303970e-01
    z[5,6,1]  R1818     -3.3437675237655640e-01
    z[5,6,1]  R1819     -4.8662039637565613e-01
    z[5,6,1]  R1820     -9.6070962026715279e-03
    z[5,6,1]  R1821     -4.6856346726417542e-01
    z[5,6,1]  R1822     -0.628913938999176
    z[5,6,1]  R1823     4.7408949583768845e-02
    z[5,6,1]  R1824     5.6012964248657227e-01
    z[5,6,1]  R1825     6.2852632999420166e-01
    z[5,6,1]  R1826     1.2805540859699249e-01
    z[5,6,1]  R1827     7.2681987285614014e-01
    z[5,6,1]  R1828     -7.2500887326896191e-03
    z[5,6,1]  R1829     6.6576778888702393e-01
    z[5,6,1]  R1830     1.2854360044002533e-01
    z[5,6,1]  R1831     -7.1572464704513550e-01
    z[5,6,1]  R1832     -7.2007365524768829e-02
    z[5,6,1]  R1833     -5.9405052661895752e-01
    z[5,6,1]  R1834     6.4080238342285156e-01
    z[5,6,1]  R1835     0.0572831854224205
    z[5,6,1]  R1836     -5.4361337423324585e-01
    z[5,6,1]  R1837     -0.56270432472229
    z[5,6,1]  R1838     -1.3700662553310394e-01
    z[5,6,1]  R1839     -0.588896632194519
    z[5,6,1]  R1840     -1.1941631138324738e-01
    z[5,6,1]  R1841     6.1162346601486206e-01
    z[5,6,1]  R1842     6.8455594778060913e-01
    z[5,6,1]  R1843     5.9001648426055908e-01
    z[5,6,1]  R1844     4.4077399373054504e-01
    z[5,6,1]  R1845     5.4034572839736938e-01
    z[5,6,1]  R1846     8.1180453300476074e-01
    z[5,6,1]  R1847     3.6116382479667664e-01
    z[5,6,1]  R1848     3.5026282072067261e-01
    z[5,6,1]  R1849     3.2761648297309875e-01
    z[5,6,1]  R1850     4.8268094658851624e-01
    z[5,6,1]  R1851     -9.0482914447784424e-01
    z[5,6,1]  R1852     -8.5679125785827637e-01
    z[5,6,1]  R1853     -0.746425211429596
    z[5,6,1]  R1854     -8.7104260921478271e-01
    z[5,6,1]  R1855     -8.7729436159133911e-01
    z[5,6,1]  R1856     -6.8070882558822632e-01
    z[5,6,1]  R1857     -6.4351511001586914e-01
    z[5,6,1]  R1858     -5.6441736221313477e-01
    z[5,6,1]  R1859     -6.4501452445983887e-01
    z[5,6,1]  R1860     -6.6356188058853149e-01
    z[5,6,1]  R1861     5.0011169910430908e-01
    z[5,6,1]  R1862     -4.6965089440345764e-01
    z[5,6,1]  R1863     -1.2971398234367371e-01
    z[5,6,1]  R1864     0.0066000921651721
    z[5,6,1]  R1865     -2.2840197384357452e-01
    z[5,6,1]  R1866     -2.7539052069187164e-02
    z[5,6,1]  R1867     -2.3782984912395477e-01
    z[5,6,1]  R1868     5.2312824875116348e-02
    z[5,6,1]  R1869     6.6013656556606293e-02
    z[5,6,1]  R1870     -2.9741770029067993e-01
    z[5,6,1]  R1871     1.8457408249378204e-01
    z[5,6,1]  R1872     7.5507219880819321e-03
    z[5,6,1]  R1873     2.5539350509643555e-01
    z[5,6,1]  R1874     -5.0007468461990356e-01
    z[5,6,1]  R1875     3.8062937557697296e-02
    z[5,6,1]  R1876     4.4514108449220657e-02
    z[5,6,1]  R1877     5.1867380738258362e-02
    z[5,6,1]  R1878     -1.7568904161453247e-01
    z[5,6,1]  R1879     -8.0612100660800934e-02
    z[5,6,1]  R1880     -1.5621571242809296e-01
    z[5,6,1]  R1881     -7.9453057050704956e-01
    z[5,6,1]  R1882     1.1819142103195190e-01
    z[5,6,1]  R1883     5.6701959110796452e-03
    z[5,6,1]  R1884     0.311960905790329
    z[5,6,1]  R1885     -7.0481783151626587e-01
    z[5,6,1]  R1886     -2.2319043055176735e-02
    z[5,6,1]  R1887     2.4448089301586151e-01
    z[5,6,1]  R1888     -7.0130831003189087e-01
    z[5,6,1]  R1889     6.2961626052856445e-01
    z[5,6,1]  R1890     -5.6727476418018341e-02
    z[5,6,1]  R1891     3.1559771299362183e-01
    z[5,6,1]  R1892     -3.6972990632057190e-01
    z[5,6,1]  R1893     -8.2249885797500610e-01
    z[5,6,1]  R1894     2.7130961418151855e-01
    z[5,6,1]  R1895     1.1103488504886627e-01
    z[5,6,1]  R1896     -2.3097580671310425e-01
    z[5,6,1]  R1897     1.4612478017807007e-01
    z[5,6,1]  R1898     -7.4920791387557983e-01
    z[5,6,1]  R1899     -5.8395504951477051e-01
    z[5,6,1]  R1900     -5.6713259220123291e-01
    z[5,6,2]  R49       -1
    z[5,6,2]  R58       1
    z[5,6,2]  R1751     -1
    z[5,6,2]  R1752     1
    z[5,6,2]  R1761     5.5815988779067993e-01
    z[5,6,2]  R1762     2.2595489025115967e-01
    z[5,6,2]  R1763     2.2538958489894867e-01
    z[5,6,2]  R1764     1.6700945794582367e-01
    z[5,6,2]  R1765     8.1221228837966919e-01
    z[5,6,2]  R1766     4.5618122816085815e-01
    z[5,6,2]  R1767     1.2502519786357880e-01
    z[5,6,2]  R1768     4.0478205680847168e-01
    z[5,6,2]  R1769     5.3620833158493042e-01
    z[5,6,2]  R1770     3.9113810658454895e-01
    z[5,6,2]  R1771     4.7829464077949524e-01
    z[5,6,2]  R1772     4.1106197237968445e-01
    z[5,6,2]  R1773     -4.9869006872177124e-01
    z[5,6,2]  R1774     -7.2007972002029419e-01
    z[5,6,2]  R1775     -1.7156164348125458e-01
    z[5,6,2]  R1776     -4.4149711728096008e-01
    z[5,6,2]  R1777     2.8669720888137817e-01
    z[5,6,2]  R1778     -2.1144950389862061e-01
    z[5,6,2]  R1779     4.6509110927581787e-01
    z[5,6,2]  R1780     1.4532390236854553e-01
    z[5,6,2]  R1781     -2.3328140377998352e-01
    z[5,6,2]  R1782     -1.0717423260211945e-01
    z[5,6,2]  R1783     1.3992665708065033e-01
    z[5,6,2]  R1784     2.9441145062446594e-01
    z[5,6,2]  R1785     -2.7040395140647888e-01
    z[5,6,2]  R1786     1.5309794247150421e-01
    z[5,6,2]  R1787     7.6245918869972229e-02
    z[5,6,2]  R1788     -4.4432663917541504e-01
    z[5,6,2]  R1789     1.7600879073143005e-01
    z[5,6,2]  R1790     -2.4465925991535187e-01
    z[5,6,2]  R1791     -2.3060524463653564e-01
    z[5,6,2]  R1792     -1.9868843257427216e-01
    z[5,6,2]  R1793     5.8883899450302124e-01
    z[5,6,2]  R1794     -2.7977502346038818e-01
    z[5,6,2]  R1795     6.0295041650533676e-02
    z[5,6,2]  R1796     -5.6695544719696045e-01
    z[5,6,2]  R1797     -3.8297054171562195e-01
    z[5,6,2]  R1798     3.1879439949989319e-01
    z[5,6,2]  R1799     1.5251060947775841e-02
    z[5,6,2]  R1800     -7.6868377625942230e-02
    z[5,6,2]  R1801     4.2163223028182983e-01
    z[5,6,2]  R1802     -5.6556697934865952e-02
    z[5,6,2]  R1803     -2.1222374925855547e-04
    z[5,6,2]  R1804     -3.3787724375724792e-01
    z[5,6,2]  R1805     6.0927208513021469e-02
    z[5,6,2]  R1806     -9.9846169352531433e-02
    z[5,6,2]  R1807     -1.7482639849185944e-01
    z[5,6,2]  R1808     -3.3913305401802063e-01
    z[5,6,2]  R1809     4.5557226985692978e-02
    z[5,6,2]  R1810     4.0963280200958252e-01
    z[5,6,2]  R1811     9.2758618295192719e-02
    z[5,6,2]  R1812     1.0184465348720551e-01
    z[5,6,2]  R1813     1.7514440417289734e-01
    z[5,6,2]  R1814     2.0122143626213074e-01
    z[5,6,2]  R1815     5.0607389211654663e-01
    z[5,6,2]  R1816     -3.5405641794204712e-01
    z[5,6,2]  R1817     2.0912717282772064e-01
    z[5,6,2]  R1818     1.5767259895801544e-01
    z[5,6,2]  R1819     8.4160633385181427e-02
    z[5,6,2]  R1820     4.6334043145179749e-01
    z[5,6,2]  R1821     2.3736357688903809e-01
    z[5,6,2]  R1822     3.1158637255430222e-02
    z[5,6,2]  R1823     6.0849428176879883e-01
    z[5,6,2]  R1824     1.4234395325183868e-01
    z[5,6,2]  R1825     4.0318641066551208e-01
    z[5,6,2]  R1826     1.1819498240947723e-01
    z[5,6,2]  R1827     2.4166959524154663e-01
    z[5,6,2]  R1828     3.1032716855406761e-02
    z[5,6,2]  R1829     2.0859509706497192e-01
    z[5,6,2]  R1830     0.599233090877533
    z[5,6,2]  R1831     -2.5074759125709534e-01
    z[5,6,2]  R1832     -3.3579967916011810e-02
    z[5,6,2]  R1833     6.2019848823547363e-01
    z[5,6,2]  R1834     1.2159148603677750e-01
    z[5,6,2]  R1835     -1.8446686863899231e-01
    z[5,6,2]  R1836     3.5102772712707520e-01
    z[5,6,2]  R1837     3.5609204322099686e-02
    z[5,6,2]  R1838     5.5760347843170166e-01
    z[5,6,2]  R1839     -6.0046225786209106e-01
    z[5,6,2]  R1840     4.1237625479698181e-01
    z[5,6,2]  R1841     6.5307760238647461e-01
    z[5,6,2]  R1842     4.8185011744499207e-01
    z[5,6,2]  R1843     5.3949570655822754e-01
    z[5,6,2]  R1844     5.0236654281616211e-01
    z[5,6,2]  R1845     4.2099103331565857e-01
    z[5,6,2]  R1846     3.7018394470214844e-01
    z[5,6,2]  R1847     -5.2113026380538940e-01
    z[5,6,2]  R1848     -4.8376509547233582e-01
    z[5,6,2]  R1849     -7.8418493270874023e-01
    z[5,6,2]  R1850     -8.1867128610610962e-01
    z[5,6,2]  R1851     1.8444927036762238e-01
    z[5,6,2]  R1852     -1.3395757414400578e-02
    z[5,6,2]  R1853     1.6011258959770203e-01
    z[5,6,2]  R1854     -4.8764474689960480e-02
    z[5,6,2]  R1855     -2.2412322461605072e-01
    z[5,6,2]  R1856     6.8242150545120239e-01
    z[5,6,2]  R1857     -2.8009975329041481e-02
    z[5,6,2]  R1858     5.6274402141571045e-01
    z[5,6,2]  R1859     6.0653007030487061e-01
    z[5,6,2]  R1860     -2.1084873378276825e-01
    z[5,6,2]  R1861     -1.5013836324214935e-01
    z[5,6,2]  R1862     8.1123101711273193e-01
    z[5,6,2]  R1863     -6.7830908298492432e-01
    z[5,6,2]  R1864     5.9358769655227661e-01
    z[5,6,2]  R1865     -7.2841954231262207e-01
    z[5,6,2]  R1866     4.0486451983451843e-01
    z[5,6,2]  R1867     -6.5329098701477051e-01
    z[5,6,2]  R1868     4.2163950204849243e-01
    z[5,6,2]  R1869     1.7427203059196472e-01
    z[5,6,2]  R1870     -5.5641597509384155e-01
    z[5,6,2]  R1871     0.533997118473053
    z[5,6,2]  R1872     -9.4141222536563873e-02
    z[5,6,2]  R1873     -3.4328576922416687e-01
    z[5,6,2]  R1874     7.7171623706817627e-01
    z[5,6,2]  R1875     -6.3166123628616333e-01
    z[5,6,2]  R1876     -4.6719151735305786e-01
    z[5,6,2]  R1877     7.1479961276054382e-02
    z[5,6,2]  R1878     1.4302076399326324e-01
    z[5,6,2]  R1879     3.5709220916032791e-02
    z[5,6,2]  R1880     -6.6773869097232819e-02
    z[5,6,2]  R1881     3.0150640010833740e-01
    z[5,6,2]  R1882     5.7649750262498856e-02
    z[5,6,2]  R1883     2.9062870144844055e-01
    z[5,6,2]  R1884     -1.0436808317899704e-01
    z[5,6,2]  R1885     -1.2822796404361725e-01
    z[5,6,2]  R1886     1.3974268734455109e-01
    z[5,6,2]  R1887     3.3458107709884644e-01
    z[5,6,2]  R1888     -2.1774242818355560e-01
    z[5,6,2]  R1889     -1.1213681101799011e-01
    z[5,6,2]  R1890     -7.5407058000564575e-01
    z[5,6,2]  R1891     -5.7629472017288208e-01
    z[5,6,2]  R1892     8.7407833337783813e-01
    z[5,6,2]  R1893     -3.0261540785431862e-02
    z[5,6,2]  R1894     2.0813831686973572e-01
    z[5,6,2]  R1895     -9.4895833730697632e-01
    z[5,6,2]  R1896     -0.669061005115509
    z[5,6,2]  R1897     -1.8745658919215202e-02
    z[5,6,2]  R1898     1.6331587731838226e-01
    z[5,6,2]  R1899     3.9022177457809448e-02
    z[5,6,2]  R1900     -1.0737180709838867e-01
    z[5,6,3]  R50       -1
    z[5,6,3]  R59       1
    z[5,6,3]  R1753     -1
    z[5,6,3]  R1754     1
    z[5,6,3]  R1761     -6.5109741687774658e-01
    z[5,6,3]  R1762     -6.2717002630233765e-01
    z[5,6,3]  R1763     -7.7808088064193726e-01
    z[5,6,3]  R1764     1.4964616298675537e-01
    z[5,6,3]  R1765     -2.8170493245124817e-01
    z[5,6,3]  R1766     -2.2198049724102020e-01
    z[5,6,3]  R1767     8.4494002163410187e-02
    z[5,6,3]  R1768     -1.6668562591075897e-01
    z[5,6,3]  R1769     -4.2440012097358704e-02
    z[5,6,3]  R1770     5.8643206954002380e-02
    z[5,6,3]  R1771     2.6806342601776123e-01
    z[5,6,3]  R1772     7.3074257373809814e-01
    z[5,6,3]  R1773     4.5107737183570862e-01
    z[5,6,3]  R1774     4.0506976842880249e-01
    z[5,6,3]  R1775     3.5198843479156494e-01
    z[5,6,3]  R1776     0.509611189365387
    z[5,6,3]  R1777     4.0571564435958862e-01
    z[5,6,3]  R1778     3.1033343076705933e-01
    z[5,6,3]  R1779     2.2961201146245003e-02
    z[5,6,3]  R1780     3.0198348686099052e-02
    z[5,6,3]  R1781     4.6960216760635376e-01
    z[5,6,3]  R1782     3.3206886053085327e-01
    z[5,6,3]  R1783     1.2452097237110138e-01
    z[5,6,3]  R1784     -3.0271539092063904e-01
    z[5,6,3]  R1785     -6.3038282096385956e-02
    z[5,6,3]  R1786     8.8862545788288116e-02
    z[5,6,3]  R1787     1.9767074286937714e-01
    z[5,6,3]  R1788     7.8074708580970764e-02
    z[5,6,3]  R1789     -7.4829542636871338e-01
    z[5,6,3]  R1790     2.4469788372516632e-01
    z[5,6,3]  R1791     5.1538795232772827e-01
    z[5,6,3]  R1792     1.0687772929668427e-01
    z[5,6,3]  R1793     -4.7982245683670044e-02
    z[5,6,3]  R1794     -3.9214301109313965e-01
    z[5,6,3]  R1795     4.2069315910339355e-01
    z[5,6,3]  R1796     5.0914257764816284e-01
    z[5,6,3]  R1797     2.0109629631042480e-01
    z[5,6,3]  R1798     2.7164161205291748e-01
    z[5,6,3]  R1799     -0.347178190946579
    z[5,6,3]  R1800     -4.3560093641281128e-01
    z[5,6,3]  R1801     2.8857287764549255e-01
    z[5,6,3]  R1802     1.5668129920959473e-01
    z[5,6,3]  R1803     4.3472734093666077e-01
    z[5,6,3]  R1804     -2.9675019904971123e-02
    z[5,6,3]  R1805     2.3451203107833862e-01
    z[5,6,3]  R1806     6.3514953851699829e-01
    z[5,6,3]  R1807     1.2547163665294647e-01
    z[5,6,3]  R1808     -1.6502922773361206e-01
    z[5,6,3]  R1809     -2.4309846758842468e-01
    z[5,6,3]  R1810     1.9159168004989624e-01
    z[5,6,3]  R1811     -1.4149367809295654e-01
    z[5,6,3]  R1812     5.6732130050659180e-01
    z[5,6,3]  R1813     9.2289096117019653e-01
    z[5,6,3]  R1814     9.2001551389694214e-01
    z[5,6,3]  R1815     5.1745635271072388e-01
    z[5,6,3]  R1816     -4.8330705612897873e-02
    z[5,6,3]  R1817     3.7941941618919373e-01
    z[5,6,3]  R1818     -0.863492488861084
    z[5,6,3]  R1819     -5.3829592466354370e-01
    z[5,6,3]  R1820     -6.1950671672821045e-01
    z[5,6,3]  R1821     -7.3992156982421875e-01
    z[5,6,3]  R1822     4.6827623248100281e-01
    z[5,6,3]  R1823     -6.1597061157226562e-01
    z[5,6,3]  R1824     -1.3543231785297394e-01
    z[5,6,3]  R1825     2.1678598225116730e-01
    z[5,6,3]  R1826     1.0164123773574829e-01
    z[5,6,3]  R1827     -0.0944051444530487
    z[5,6,3]  R1828     -3.6431051790714264e-02
    z[5,6,3]  R1829     3.6285273730754852e-02
    z[5,6,3]  R1830     4.0914192795753479e-01
    z[5,6,3]  R1831     2.6608530431985855e-02
    z[5,6,3]  R1832     2.8290608525276184e-01
    z[5,6,3]  R1833     3.6883381009101868e-01
    z[5,6,3]  R1834     6.7364257574081421e-01
    z[5,6,3]  R1835     3.0480548739433289e-01
    z[5,6,3]  R1836     1.1650307476520538e-01
    z[5,6,3]  R1837     1.1999174207448959e-01
    z[5,6,3]  R1838     -6.6445344686508179e-01
    z[5,6,3]  R1839     1.1093888431787491e-02
    z[5,6,3]  R1840     -6.6328942775726318e-01
    z[5,6,3]  R1841     -1.7735873162746429e-01
    z[5,6,3]  R1842     -7.2166711091995239e-02
    z[5,6,3]  R1843     -3.6421704292297363e-01
    z[5,6,3]  R1844     -1.6406776383519173e-02
    z[5,6,3]  R1845     -3.6862000823020935e-02
    z[5,6,3]  R1846     7.6529145240783691e-02
    z[5,6,3]  R1847     -5.0604915618896484e-01
    z[5,6,3]  R1848     -2.8454324603080750e-01
    z[5,6,3]  R1849     1.4922952651977539e-01
    z[5,6,3]  R1850     2.3323077708482742e-02
    z[5,6,3]  R1851     2.2303119301795959e-01
    z[5,6,3]  R1852     3.0072297900915146e-02
    z[5,6,3]  R1853     -1.5407598018646240e-01
    z[5,6,3]  R1854     -1.4522799849510193e-01
    z[5,6,3]  R1855     -5.2057329565286636e-02
    z[5,6,3]  R1856     4.7645575250498950e-04
    z[5,6,3]  R1857     -1.5810810029506683e-02
    z[5,6,3]  R1858     1.1137538403272629e-01
    z[5,6,3]  R1859     -1.4453551173210144e-01
    z[5,6,3]  R1860     -6.6462743282318115e-01
    z[5,6,3]  R1861     -1.1206272989511490e-01
    z[5,6,3]  R1862     2.1960420906543732e-01
    z[5,6,3]  R1863     2.1484570205211639e-01
    z[5,6,3]  R1864     6.5667057037353516e-01
    z[5,6,3]  R1865     2.0240142941474915e-01
    z[5,6,3]  R1866     4.0234780311584473e-01
    z[5,6,3]  R1867     -3.4329872578382492e-02
    z[5,6,3]  R1868     2.8709346055984497e-01
    z[5,6,3]  R1869     8.9333295822143555e-01
    z[5,6,3]  R1870     2.7548578381538391e-01
    z[5,6,3]  R1871     -1.5493296086788177e-01
    z[5,6,3]  R1872     3.1071117520332336e-01
    z[5,6,3]  R1873     4.4686415791511536e-01
    z[5,6,3]  R1874     -1.8663607537746429e-01
    z[5,6,3]  R1875     3.4587290883064270e-01
    z[5,6,3]  R1876     1.8540048599243164e-01
    z[5,6,3]  R1877     4.5564615726470947e-01
    z[5,6,3]  R1878     3.4619012475013733e-01
    z[5,6,3]  R1879     6.1684612184762955e-02
    z[5,6,3]  R1880     2.7708551287651062e-01
    z[5,6,3]  R1881     2.7882652357220650e-02
    z[5,6,3]  R1882     2.9548335075378418e-01
    z[5,6,3]  R1883     6.4322352409362793e-01
    z[5,6,3]  R1884     0.0772358700633049
    z[5,6,3]  R1885     4.0807634592056274e-01
    z[5,6,3]  R1886     4.4087588787078857e-01
    z[5,6,3]  R1887     8.4481775760650635e-01
    z[5,6,3]  R1888     -1.0306950658559799e-01
    z[5,6,3]  R1889     5.0641906261444092e-01
    z[5,6,3]  R1890     2.6382520794868469e-01
    z[5,6,3]  R1891     -3.1905156373977661e-01
    z[5,6,3]  R1892     -1.2970322370529175e-01
    z[5,6,3]  R1893     2.6195693016052246e-01
    z[5,6,3]  R1894     0.744918942451477
    z[5,6,3]  R1895     1.3488547876477242e-02
    z[5,6,3]  R1896     1.7731359601020813e-01
    z[5,6,3]  R1897     4.5670741796493530e-01
    z[5,6,3]  R1898     -0.512614369392395
    z[5,6,3]  R1899     -4.7568336129188538e-01
    z[5,6,3]  R1900     3.3361083269119263e-01
    z[5,6,4]  R51       -1
    z[5,6,4]  R60       1
    z[5,6,4]  R1755     -1
    z[5,6,4]  R1756     1
    z[5,6,4]  R1761     3.5494975745677948e-02
    z[5,6,4]  R1762     3.9642862975597382e-03
    z[5,6,4]  R1763     -0.091993547976017
    z[5,6,4]  R1764     -9.1157844290137291e-03
    z[5,6,4]  R1765     -3.5667590796947479e-02
    z[5,6,4]  R1766     2.1434406936168671e-01
    z[5,6,4]  R1767     0.334311306476593
    z[5,6,4]  R1768     2.6511928439140320e-01
    z[5,6,4]  R1769     -2.0978540182113647e-01
    z[5,6,4]  R1770     -1.8253475427627563e-01
    z[5,6,4]  R1771     7.7206425368785858e-02
    z[5,6,4]  R1772     5.9892702847719193e-02
    z[5,6,4]  R1773     -1.0336165875196457e-01
    z[5,6,4]  R1774     8.4578081965446472e-02
    z[5,6,4]  R1775     9.1192595660686493e-02
    z[5,6,4]  R1776     1.7118583619594574e-01
    z[5,6,4]  R1777     -1.6608101129531860e-01
    z[5,6,4]  R1778     -2.7674525976181030e-01
    z[5,6,4]  R1779     -1.9405819475650787e-01
    z[5,6,4]  R1780     7.9633817076683044e-02
    z[5,6,4]  R1781     0.0679209977388382
    z[5,6,4]  R1782     1.0429047048091888e-01
    z[5,6,4]  R1783     -2.2596006095409393e-01
    z[5,6,4]  R1784     1.8353813886642456e-01
    z[5,6,4]  R1785     -4.0670579671859741e-01
    z[5,6,4]  R1786     -2.8136115521192551e-02
    z[5,6,4]  R1787     2.4890285730361938e-01
    z[5,6,4]  R1788     -1.1637928336858749e-01
    z[5,6,4]  R1789     1.4769001305103302e-01
    z[5,6,4]  R1790     8.6736559867858887e-02
    z[5,6,4]  R1791     5.2736252546310425e-01
    z[5,6,4]  R1792     3.4467944502830505e-01
    z[5,6,4]  R1793     -9.3032978475093842e-02
    z[5,6,4]  R1794     -1.4599943161010742e-01
    z[5,6,4]  R1795     2.4246694147586823e-01
    z[5,6,4]  R1796     -5.3987614810466766e-02
    z[5,6,4]  R1797     -4.0561595559120178e-01
    z[5,6,4]  R1798     4.7643250226974487e-01
    z[5,6,4]  R1799     1.1399107426404953e-01
    z[5,6,4]  R1800     -3.6978834867477417e-01
    z[5,6,4]  R1801     7.7476361766457558e-03
    z[5,6,4]  R1802     -1.7588908970355988e-01
    z[5,6,4]  R1803     1.7745584249496460e-01
    z[5,6,4]  R1804     2.0051756501197815e-01
    z[5,6,4]  R1805     -1.5259747393429279e-02
    z[5,6,4]  R1806     3.9132067561149597e-01
    z[5,6,4]  R1807     -3.0765104293823242e-01
    z[5,6,4]  R1808     -3.7825030088424683e-01
    z[5,6,4]  R1809     4.5621815323829651e-01
    z[5,6,4]  R1810     -3.1934878230094910e-01
    z[5,6,4]  R1811     3.3947516232728958e-02
    z[5,6,4]  R1812     1.4159974455833435e-01
    z[5,6,4]  R1813     -1.8256385624408722e-01
    z[5,6,4]  R1814     8.2530558109283447e-02
    z[5,6,4]  R1815     2.2407043725252151e-02
    z[5,6,4]  R1816     -1.9012410938739777e-01
    z[5,6,4]  R1817     5.4631102085113525e-01
    z[5,6,4]  R1818     5.9076272882521152e-03
    z[5,6,4]  R1819     2.1291528642177582e-01
    z[5,6,4]  R1820     -1.3926008343696594e-01
    z[5,6,4]  R1821     -0.0978035256266594
    z[5,6,4]  R1822     -3.0345961451530457e-01
    z[5,6,4]  R1823     -0.0781460627913475
    z[5,6,4]  R1824     4.1999399662017822e-01
    z[5,6,4]  R1825     -5.8338645845651627e-02
    z[5,6,4]  R1826     1.0958840698003769e-01
    z[5,6,4]  R1827     4.8430660367012024e-01
    z[5,6,4]  R1828     0.261323481798172
    z[5,6,4]  R1829     2.9446640610694885e-01
    z[5,6,4]  R1830     1.5138788521289825e-01
    z[5,6,4]  R1831     -4.8259207606315613e-01
    z[5,6,4]  R1832     2.0322456955909729e-01
    z[5,6,4]  R1833     -2.0986037328839302e-02
    z[5,6,4]  R1834     2.3399895429611206e-01
    z[5,6,4]  R1835     -2.8322216868400574e-01
    z[5,6,4]  R1836     1.1421643942594528e-01
    z[5,6,4]  R1837     -1.4713747799396515e-01
    z[5,6,4]  R1838     1.1014923220500350e-03
    z[5,6,4]  R1839     1.5322542190551758e-01
    z[5,6,4]  R1840     -1.8408633768558502e-01
    z[5,6,4]  R1841     3.0931377410888672e-01
    z[5,6,4]  R1842     -1.0533689707517624e-01
    z[5,6,4]  R1843     -3.9524812251329422e-02
    z[5,6,4]  R1844     -4.2555180191993713e-01
    z[5,6,4]  R1845     1.2045098841190338e-01
    z[5,6,4]  R1846     1.0959753394126892e-01
    z[5,6,4]  R1847     -5.9787888079881668e-02
    z[5,6,4]  R1848     3.0749875307083130e-01
    z[5,6,4]  R1849     5.5037878453731537e-02
    z[5,6,4]  R1850     -1.9136065244674683e-01
    z[5,6,4]  R1851     -2.1240387856960297e-01
    z[5,6,4]  R1852     -1.2740857899188995e-01
    z[5,6,4]  R1853     2.3785457015037537e-01
    z[5,6,4]  R1854     -3.0441511422395706e-02
    z[5,6,4]  R1855     -1.1305811256170273e-01
    z[5,6,4]  R1856     -1.8227986991405487e-01
    z[5,6,4]  R1857     4.3938314914703369e-01
    z[5,6,4]  R1858     -3.6281594634056091e-01
    z[5,6,4]  R1859     1.8025094270706177e-01
    z[5,6,4]  R1860     -7.6935626566410065e-02
    z[5,6,4]  R1861     3.2748109102249146e-01
    z[5,6,4]  R1862     1.4197234809398651e-01
    z[5,6,4]  R1863     -9.6101216971874237e-02
    z[5,6,4]  R1864     -1.2907008826732635e-01
    z[5,6,4]  R1865     -1.4035013318061829e-01
    z[5,6,4]  R1866     -1.7884099856019020e-02
    z[5,6,4]  R1867     3.0120092630386353e-01
    z[5,6,4]  R1868     4.3370419740676880e-01
    z[5,6,4]  R1869     -6.7534692585468292e-02
    z[5,6,4]  R1870     6.7070230841636658e-02
    z[5,6,4]  R1871     -4.2729938030242920e-01
    z[5,6,4]  R1872     3.8238272070884705e-01
    z[5,6,4]  R1873     1.5390522778034210e-01
    z[5,6,4]  R1874     -2.1807695925235748e-01
    z[5,6,4]  R1875     3.8307970762252808e-01
    z[5,6,4]  R1876     5.5730640888214111e-01
    z[5,6,4]  R1877     -1.3726758956909180e-01
    z[5,6,4]  R1878     3.5945403575897217e-01
    z[5,6,4]  R1879     5.9789609909057617e-01
    z[5,6,4]  R1880     3.2487982511520386e-01
    z[5,6,4]  R1881     1.8357923254370689e-02
    z[5,6,4]  R1882     1.6997136175632477e-02
    z[5,6,4]  R1883     2.2530054673552513e-02
    z[5,6,4]  R1884     7.1387737989425659e-02
    z[5,6,4]  R1885     5.3474036976695061e-03
    z[5,6,4]  R1886     -3.0325773358345032e-01
    z[5,6,4]  R1887     2.4515953660011292e-01
    z[5,6,4]  R1888     3.9190939068794250e-01
    z[5,6,4]  R1889     4.7103419899940491e-01
    z[5,6,4]  R1890     3.1757593154907227e-02
    z[5,6,4]  R1891     5.3931981325149536e-01
    z[5,6,4]  R1892     8.1775300204753876e-02
    z[5,6,4]  R1893     2.9924826696515083e-02
    z[5,6,4]  R1894     4.9881532788276672e-02
    z[5,6,4]  R1895     7.0591926574707031e-02
    z[5,6,4]  R1896     3.9975631237030029e-01
    z[5,6,4]  R1897     -3.8714587688446045e-01
    z[5,6,4]  R1898     -3.4964978694915771e-01
    z[5,6,4]  R1899     -3.7415459752082825e-01
    z[5,6,4]  R1900     3.8348725438117981e-01
    z[5,6,5]  R52       -1
    z[5,6,5]  R61       1
    z[5,6,5]  R1757     -1
    z[5,6,5]  R1758     1
    z[5,6,5]  R1761     2.1825125813484192e-01
    z[5,6,5]  R1762     -1.6139014065265656e-01
    z[5,6,5]  R1763     -1.1417536437511444e-01
    z[5,6,5]  R1764     5.5422621965408325e-01
    z[5,6,5]  R1765     -1.3392789661884308e-01
    z[5,6,5]  R1766     -7.7547687105834484e-03
    z[5,6,5]  R1767     2.3872756958007812e-01
    z[5,6,5]  R1768     -1.4714235067367554e-01
    z[5,6,5]  R1769     3.2425004243850708e-01
    z[5,6,5]  R1770     0.00981933530420065
    z[5,6,5]  R1771     -7.5578755140304565e-01
    z[5,6,5]  R1772     -3.6837142705917358e-01
    z[5,6,5]  R1773     -3.8060164451599121e-01
    z[5,6,5]  R1774     -4.7244527935981750e-01
    z[5,6,5]  R1775     -4.5457679033279419e-01
    z[5,6,5]  R1776     -2.8590077161788940e-01
    z[5,6,5]  R1777     -5.7144075632095337e-01
    z[5,6,5]  R1778     -3.1042066216468811e-01
    z[5,6,5]  R1779     3.2131791114807129e-01
    z[5,6,5]  R1780     -1.9068498909473419e-01
    z[5,6,5]  R1781     -7.7682763338088989e-01
    z[5,6,5]  R1782     -6.6140621900558472e-01
    z[5,6,5]  R1783     1.5085159242153168e-01
    z[5,6,5]  R1784     -2.7786001563072205e-01
    z[5,6,5]  R1785     4.7036954760551453e-01
    z[5,6,5]  R1786     2.8375312685966492e-01
    z[5,6,5]  R1787     -5.8317315578460693e-01
    z[5,6,5]  R1788     -6.2162160873413086e-02
    z[5,6,5]  R1789     -1.9050613045692444e-01
    z[5,6,5]  R1790     -5.0837069749832153e-01
    z[5,6,5]  R1791     -4.6687945723533630e-01
    z[5,6,5]  R1792     2.4668979644775391e-01
    z[5,6,5]  R1793     3.4272089600563049e-01
    z[5,6,5]  R1794     1.4843259751796722e-01
    z[5,6,5]  R1795     -4.1661235690116882e-01
    z[5,6,5]  R1796     -3.3581340312957764e-01
    z[5,6,5]  R1797     -4.1864910599542782e-05
    z[5,6,5]  R1798     -5.6735342741012573e-01
    z[5,6,5]  R1799     -2.8519338369369507e-01
    z[5,6,5]  R1800     -3.2680696249008179e-01
    z[5,6,5]  R1801     -3.1746879220008850e-01
    z[5,6,5]  R1802     2.8315432369709015e-02
    z[5,6,5]  R1803     -5.2213990688323975e-01
    z[5,6,5]  R1804     -4.6418279409408569e-01
    z[5,6,5]  R1805     -5.5919522047042847e-01
    z[5,6,5]  R1806     -8.5035160183906555e-02
    z[5,6,5]  R1807     -5.5289936065673828e-01
    z[5,6,5]  R1808     -8.4765315055847168e-02
    z[5,6,5]  R1809     7.0585653185844421e-02
    z[5,6,5]  R1810     -3.6760583519935608e-01
    z[5,6,5]  R1811     5.3840130567550659e-02
    z[5,6,5]  R1812     -5.3950971364974976e-01
    z[5,6,5]  R1813     -1.6871818900108337e-01
    z[5,6,5]  R1814     8.8136322796344757e-02
    z[5,6,5]  R1815     -0.560045599937439
    z[5,6,5]  R1816     -2.2227661311626434e-01
    z[5,6,5]  R1817     -4.8511779308319092e-01
    z[5,6,5]  R1818     0.0947168618440628
    z[5,6,5]  R1819     4.3137103319168091e-01
    z[5,6,5]  R1820     -0.514052152633667
    z[5,6,5]  R1821     -1.3797669112682343e-01
    z[5,6,5]  R1822     -3.2306542992591858e-01
    z[5,6,5]  R1823     -2.9790589213371277e-01
    z[5,6,5]  R1824     5.7864511013031006e-01
    z[5,6,5]  R1825     -5.6701570749282837e-02
    z[5,6,5]  R1826     2.1980141103267670e-01
    z[5,6,5]  R1827     3.4816437959671021e-01
    z[5,6,5]  R1828     -1.7437775433063507e-01
    z[5,6,5]  R1829     6.0073465108871460e-01
    z[5,6,5]  R1830     5.6616044044494629e-01
    z[5,6,5]  R1831     4.0612876415252686e-02
    z[5,6,5]  R1832     -8.2353627681732178e-01
    z[5,6,5]  R1833     3.7596080452203751e-02
    z[5,6,5]  R1834     -8.9968152344226837e-02
    z[5,6,5]  R1835     -7.2813975811004639e-01
    z[5,6,5]  R1836     4.2458567023277283e-01
    z[5,6,5]  R1837     0.352770060300827
    z[5,6,5]  R1838     -4.4315110892057419e-02
    z[5,6,5]  R1839     3.7983334064483643e-01
    z[5,6,5]  R1840     -4.0564981102943420e-01
    z[5,6,5]  R1841     -1.4910748600959778e-01
    z[5,6,5]  R1842     2.3642964661121368e-01
    z[5,6,5]  R1843     2.6192072033882141e-01
    z[5,6,5]  R1844     -2.4893982335925102e-02
    z[5,6,5]  R1845     1.1403822153806686e-01
    z[5,6,5]  R1846     -2.0856025815010071e-01
    z[5,6,5]  R1847     4.7178804874420166e-01
    z[5,6,5]  R1848     6.6391664743423462e-01
    z[5,6,5]  R1849     3.8924831151962280e-01
    z[5,6,5]  R1850     1.2152110785245895e-01
    z[5,6,5]  R1851     2.1437183022499084e-02
    z[5,6,5]  R1852     1.3909088075160980e-01
    z[5,6,5]  R1853     1.1812205612659454e-01
    z[5,6,5]  R1854     3.7348988652229309e-01
    z[5,6,5]  R1855     -2.3512698709964752e-01
    z[5,6,5]  R1856     -4.9178179353475571e-02
    z[5,6,5]  R1857     -1.8666283786296844e-01
    z[5,6,5]  R1858     4.4221282005310059e-01
    z[5,6,5]  R1859     -2.4498255550861359e-01
    z[5,6,5]  R1860     -1.5540733933448792e-01
    z[5,6,5]  R1861     -1.5384857356548309e-01
    z[5,6,5]  R1862     1.3855701684951782e-01
    z[5,6,5]  R1863     -2.4059610068798065e-01
    z[5,6,5]  R1864     -2.6186150312423706e-01
    z[5,6,5]  R1865     -2.3836867511272430e-01
    z[5,6,5]  R1866     7.9744279384613037e-01
    z[5,6,5]  R1867     -2.9433470964431763e-01
    z[5,6,5]  R1868     7.2514837980270386e-01
    z[5,6,5]  R1869     3.7951439619064331e-01
    z[5,6,5]  R1870     -3.2458725571632385e-01
    z[5,6,5]  R1871     -4.4477206468582153e-01
    z[5,6,5]  R1872     -8.5610244423151016e-03
    z[5,6,5]  R1873     4.2908897995948792e-01
    z[5,6,5]  R1874     0.0865989699959755
    z[5,6,5]  R1875     -6.7275352776050568e-02
    z[5,6,5]  R1876     -3.2819861173629761e-01
    z[5,6,5]  R1877     7.9767984151840210e-01
    z[5,6,5]  R1878     3.5359352827072144e-01
    z[5,6,5]  R1879     5.2157509326934814e-01
    z[5,6,5]  R1880     6.2777698040008545e-01
    z[5,6,5]  R1881     -1.5226955711841583e-01
    z[5,6,5]  R1882     2.4852935969829559e-01
    z[5,6,5]  R1883     6.4453983306884766e-01
    z[5,6,5]  R1884     8.9482986927032471e-01
    z[5,6,5]  R1885     -2.9989114403724670e-01
    z[5,6,5]  R1886     6.8360632658004761e-01
    z[5,6,5]  R1887     2.0597076416015625e-01
    z[5,6,5]  R1888     5.3643468767404556e-02
    z[5,6,5]  R1889     3.2350286841392517e-01
    z[5,6,5]  R1890     7.4796602129936218e-02
    z[5,6,5]  R1891     -8.3849526941776276e-02
    z[5,6,5]  R1892     -1.0466530919075012e-01
    z[5,6,5]  R1893     -1.0526506602764130e-01
    z[5,6,5]  R1894     5.5378687381744385e-01
    z[5,6,5]  R1895     -4.9198679625988007e-02
    z[5,6,5]  R1896     2.0749524235725403e-01
    z[5,6,5]  R1897     4.2804643511772156e-01
    z[5,6,5]  R1898     3.4910753369331360e-02
    z[5,6,5]  R1899     -3.4486436843872070e-01
    z[5,6,5]  R1900     -1.7774419859051704e-02
    z[5,6,6]  R53       -1
    z[5,6,6]  R62       1
    z[5,6,6]  R1759     -1
    z[5,6,6]  R1760     1
    z[5,6,6]  R1761     -1.9783705472946167e-01
    z[5,6,6]  R1762     -1.4131994545459747e-01
    z[5,6,6]  R1763     -3.5487228631973267e-01
    z[5,6,6]  R1764     1.1082220077514648e-01
    z[5,6,6]  R1765     1.3181723654270172e-01
    z[5,6,6]  R1766     2.8088742494583130e-01
    z[5,6,6]  R1767     4.8448985815048218e-01
    z[5,6,6]  R1768     -2.1266406774520874e-01
    z[5,6,6]  R1769     -2.9523962736129761e-01
    z[5,6,6]  R1770     -2.5167265534400940e-01
    z[5,6,6]  R1771     -1.7507728934288025e-01
    z[5,6,6]  R1772     3.7377485632896423e-01
    z[5,6,6]  R1773     -3.6467275023460388e-01
    z[5,6,6]  R1774     1.3599184155464172e-01
    z[5,6,6]  R1775     -0.0767880454659462
    z[5,6,6]  R1776     -1.5330973267555237e-01
    z[5,6,6]  R1777     -3.6703673005104065e-01
    z[5,6,6]  R1778     -8.1977176666259766e-01
    z[5,6,6]  R1779     3.1422293186187744e-01
    z[5,6,6]  R1780     3.0217525362968445e-01
    z[5,6,6]  R1781     2.6269397139549255e-01
    z[5,6,6]  R1782     -3.7492290139198303e-01
    z[5,6,6]  R1783     -6.2892287969589233e-01
    z[5,6,6]  R1784     0.547385036945343
    z[5,6,6]  R1785     -0.338960736989975
    z[5,6,6]  R1786     4.3945336341857910e-01
    z[5,6,6]  R1787     -7.2387516498565674e-01
    z[5,6,6]  R1788     6.9454722106456757e-02
    z[5,6,6]  R1789     -2.5666895508766174e-01
    z[5,6,6]  R1790     -6.3011479377746582e-01
    z[5,6,6]  R1791     -2.5507858395576477e-01
    z[5,6,6]  R1792     0.0635906234383583
    z[5,6,6]  R1793     2.6841476559638977e-01
    z[5,6,6]  R1794     3.9312040805816650e-01
    z[5,6,6]  R1795     -6.1730813980102539e-01
    z[5,6,6]  R1796     -2.7263706922531128e-01
    z[5,6,6]  R1797     8.3916023373603821e-02
    z[5,6,6]  R1798     -1.2349230051040649e-01
    z[5,6,6]  R1799     -4.1247045993804932e-01
    z[5,6,6]  R1800     1.4649763703346252e-01
    z[5,6,6]  R1801     3.0656388401985168e-01
    z[5,6,6]  R1802     5.0899362564086914e-01
    z[5,6,6]  R1803     -3.1880617141723633e-01
    z[5,6,6]  R1804     -0.0982373058795929
    z[5,6,6]  R1805     -3.0485075712203979e-01
    z[5,6,6]  R1806     -3.6884722113609314e-01
    z[5,6,6]  R1807     2.6567247509956360e-01
    z[5,6,6]  R1808     -1.5768018364906311e-01
    z[5,6,6]  R1809     4.6476048231124878e-01
    z[5,6,6]  R1810     -2.0062988623976707e-02
    z[5,6,6]  R1811     -0.0706803947687149
    z[5,6,6]  R1812     -5.4278868436813354e-01
    z[5,6,6]  R1813     -2.1640880405902863e-01
    z[5,6,6]  R1814     -1.1714392900466919e-01
    z[5,6,6]  R1815     -1.2410532683134079e-01
    z[5,6,6]  R1816     3.1036806106567383e-01
    z[5,6,6]  R1817     1.1200872063636780e-01
    z[5,6,6]  R1818     -1.4323492534458637e-02
    z[5,6,6]  R1819     -2.8648027777671814e-01
    z[5,6,6]  R1820     -6.5235637128353119e-02
    z[5,6,6]  R1821     1.5903894603252411e-01
    z[5,6,6]  R1822     1.3085895776748657e-01
    z[5,6,6]  R1823     -3.6762490868568420e-02
    z[5,6,6]  R1824     1.0050827264785767e-01
    z[5,6,6]  R1825     2.0909073948860168e-01
    z[5,6,6]  R1826     -1.5240733325481415e-01
    z[5,6,6]  R1827     6.3973955810070038e-02
    z[5,6,6]  R1828     2.5381425023078918e-01
    z[5,6,6]  R1829     -2.3153199255466461e-01
    z[5,6,6]  R1830     2.1080653369426727e-01
    z[5,6,6]  R1831     -2.9442432522773743e-01
    z[5,6,6]  R1832     2.2117432951927185e-01
    z[5,6,6]  R1833     -3.0406171083450317e-01
    z[5,6,6]  R1834     -2.4027535319328308e-01
    z[5,6,6]  R1835     -3.4742251038551331e-01
    z[5,6,6]  R1836     -0.263701468706131
    z[5,6,6]  R1837     -3.1423202157020569e-01
    z[5,6,6]  R1838     2.0526324212551117e-01
    z[5,6,6]  R1839     -2.7229386568069458e-01
    z[5,6,6]  R1840     -6.8887092173099518e-02
    z[5,6,6]  R1841     -2.1032159030437469e-01
    z[5,6,6]  R1842     -3.0687007308006287e-01
    z[5,6,6]  R1843     -7.9074859619140625e-02
    z[5,6,6]  R1844     -0.459751695394516
    z[5,6,6]  R1845     5.9187906980514526e-01
    z[5,6,6]  R1846     1.7832185328006744e-01
    z[5,6,6]  R1847     -2.1022546291351318e-01
    z[5,6,6]  R1848     1.0699690319597721e-02
    z[5,6,6]  R1849     -2.9689574241638184e-01
    z[5,6,6]  R1850     1.1398231983184814e-01
    z[5,6,6]  R1851     1.2032502889633179e-01
    z[5,6,6]  R1852     -3.2397669553756714e-01
    z[5,6,6]  R1853     -2.7706235647201538e-01
    z[5,6,6]  R1854     1.0287478566169739e-01
    z[5,6,6]  R1855     3.5452261567115784e-02
    z[5,6,6]  R1856     -1.4815139770507812e-01
    z[5,6,6]  R1857     -4.4864334166049957e-02
    z[5,6,6]  R1858     6.7343883216381073e-02
    z[5,6,6]  R1859     -1.1576295830309391e-02
    z[5,6,6]  R1860     1.3387800753116608e-01
    z[5,6,6]  R1861     2.2807975113391876e-01
    z[5,6,6]  R1862     9.1220222413539886e-02
    z[5,6,6]  R1863     -3.4824568033218384e-01
    z[5,6,6]  R1864     3.2301548123359680e-01
    z[5,6,6]  R1865     0.0875079482793808
    z[5,6,6]  R1866     -1.8640391528606415e-01
    z[5,6,6]  R1867     0.0978948324918747
    z[5,6,6]  R1868     3.7448275834321976e-02
    z[5,6,6]  R1869     1.1275637149810791e-01
    z[5,6,6]  R1870     -7.7837914228439331e-02
    z[5,6,6]  R1871     2.3740540444850922e-01
    z[5,6,6]  R1872     0.249008908867836
    z[5,6,6]  R1873     4.6054357290267944e-01
    z[5,6,6]  R1874     -2.5394740700721741e-01
    z[5,6,6]  R1875     5.9621725231409073e-02
    z[5,6,6]  R1876     -2.0486259460449219e-01
    z[5,6,6]  R1877     2.6581510901451111e-01
    z[5,6,6]  R1878     -2.0385244488716125e-01
    z[5,6,6]  R1879     -2.6578944921493530e-01
    z[5,6,6]  R1880     3.9920575916767120e-02
    z[5,6,6]  R1881     -2.9724302887916565e-01
    z[5,6,6]  R1882     -6.5363639593124390e-01
    z[5,6,6]  R1883     -0.0299916360527277
    z[5,6,6]  R1884     7.6696924865245819e-02
    z[5,6,6]  R1885     -1.8340897560119629e-01
    z[5,6,6]  R1886     1.6833055019378662e-01
    z[5,6,6]  R1887     -4.9545396119356155e-02
    z[5,6,6]  R1888     1.6663007438182831e-01
    z[5,6,6]  R1889     -9.1901179403066635e-03
    z[5,6,6]  R1890     0.555742084980011
    z[5,6,6]  R1891     3.7111893296241760e-01
    z[5,6,6]  R1892     -2.0795795321464539e-01
    z[5,6,6]  R1893     -1.8203240633010864e-01
    z[5,6,6]  R1894     0.0779573991894722
    z[5,6,6]  R1895     8.7144345045089722e-02
    z[5,6,6]  R1896     -1.1840105056762695e-01
    z[5,6,6]  R1897     1.4177146553993225e-01
    z[5,6,6]  R1898     -1.5528991818428040e-01
    z[5,6,6]  R1899     -4.0459185838699341e-01
    z[5,6,6]  R1900     5.0039076805114746e-01
    z[6,5,0]  R47       1
    z[6,5,0]  R56       -1
    z[6,5,0]  R1901     -1
    z[6,5,0]  R1902     1
    z[6,5,0]  R1915     7.6203301548957825e-02
    z[6,5,0]  R1916     3.6446052789688110e-01
    z[6,5,0]  R1917     3.8955527544021606e-01
    z[6,5,0]  R1918     3.9998903870582581e-01
    z[6,5,0]  R1919     3.8935866951942444e-01
    z[6,5,0]  R1920     3.3282566070556641e-01
    z[6,5,0]  R1921     -2.6747867465019226e-01
    z[6,5,0]  R1922     -1.6391228139400482e-01
    z[6,5,0]  R1923     -1.1296674609184265e-01
    z[6,5,0]  R1924     -1.7853356897830963e-01
    z[6,5,0]  R1925     -1.9356290996074677e-01
    z[6,5,0]  R1926     -3.5254049301147461e-01
    z[6,5,0]  R1927     -4.9616798758506775e-01
    z[6,5,0]  R1928     -2.5847837328910828e-01
    z[6,5,0]  R1929     -3.2877001166343689e-01
    z[6,5,0]  R1930     -1.1551152169704437e-01
    z[6,5,0]  R1931     -5.9576874971389771e-01
    z[6,5,0]  R1932     1.4361375570297241e-01
    z[6,5,0]  R1933     -3.2022818922996521e-01
    z[6,5,0]  R1934     -1.5970276296138763e-01
    z[6,5,0]  R1935     -7.2928392887115479e-01
    z[6,5,0]  R1936     -1.5947078168392181e-01
    z[6,5,0]  R1937     5.3713631629943848e-01
    z[6,5,0]  R1938     1.6378110647201538e-01
    z[6,5,0]  R1939     5.4045879840850830e-01
    z[6,5,0]  R1940     4.9611806869506836e-02
    z[6,5,0]  R1941     5.7317632436752319e-01
    z[6,5,0]  R1942     -1.4737339317798615e-01
    z[6,5,0]  R1943     0.0769510343670845
    z[6,5,0]  R1944     6.4041984081268311e-01
    z[6,5,0]  R1945     4.6904885768890381e-01
    z[6,5,0]  R1946     -8.2839828729629517e-01
    z[6,5,0]  R1947     -4.4422608613967896e-01
    z[6,5,0]  R1948     -8.6739659309387207e-05
    z[6,5,0]  R1949     5.7017225027084351e-01
    z[6,5,0]  R1950     -5.3395098447799683e-01
    z[6,5,0]  R1951     2.4247437715530396e-01
    z[6,5,0]  R1952     7.3009556531906128e-01
    z[6,5,0]  R1953     5.3689581155776978e-01
    z[6,5,0]  R1954     6.2699037790298462e-01
    z[6,5,0]  R1955     -4.0640029311180115e-01
    z[6,5,0]  R1956     -6.3726031780242920e-01
    z[6,5,0]  R1957     2.9142358899116516e-01
    z[6,5,0]  R1958     2.7225577831268311e-01
    z[6,5,0]  R1959     -4.4346490502357483e-01
    z[6,5,0]  R1960     4.4495406746864319e-01
    z[6,5,0]  R1961     -9.7905941307544708e-02
    z[6,5,0]  R1962     -5.1565051078796387e-01
    z[6,5,0]  R1963     -0.0890880599617958
    z[6,5,0]  R1964     2.0761384069919586e-01
    z[6,5,0]  R1965     -1.7567798495292664e-01
    z[6,5,0]  R1966     -1.4688614010810852e-01
    z[6,5,0]  R1967     -4.5699721574783325e-01
    z[6,5,0]  R1968     1.1366516351699829e-01
    z[6,5,0]  R1969     0.268271267414093
    z[6,5,0]  R1970     5.0068873167037964e-01
    z[6,5,0]  R1971     6.4537554979324341e-01
    z[6,5,0]  R1972     -4.0659990161657333e-02
    z[6,5,0]  R1973     -9.2636190354824066e-02
    z[6,5,0]  R1974     -3.9719808101654053e-01
    z[6,5,0]  R1975     -4.1581445932388306e-01
    z[6,5,0]  R1976     -7.1382147073745728e-01
    z[6,5,0]  R1977     -4.4117593765258789e-01
    z[6,5,0]  R1978     3.0876708030700684e-01
    z[6,5,0]  R1979     -0.468372106552124
    z[6,5,0]  R1980     3.7482929229736328e-01
    z[6,5,0]  R1981     3.0678293108940125e-01
    z[6,5,0]  R1982     2.1084308624267578e-01
    z[6,5,0]  R1983     -1.6066245734691620e-01
    z[6,5,0]  R1984     -1.2283680588006973e-01
    z[6,5,0]  R1985     1.3883158564567566e-01
    z[6,5,0]  R1986     2.9173580929636955e-02
    z[6,5,0]  R1987     4.5376399159431458e-01
    z[6,5,0]  R1988     2.4065634608268738e-01
    z[6,5,0]  R1989     7.0959097146987915e-01
    z[6,5,0]  R1990     -6.0118097066879272e-01
    z[6,5,0]  R1991     -4.8264107108116150e-01
    z[6,5,0]  R1992     0.0402534045279026
    z[6,5,0]  R1993     6.0055327415466309e-01
    z[6,5,0]  R1994     -8.7000322341918945e-01
    z[6,5,0]  R1995     -1.6710819303989410e-01
    z[6,5,0]  R1996     5.1962143182754517e-01
    z[6,5,0]  R1997     2.4668073654174805e-01
    z[6,5,0]  R1998     2.4670842289924622e-01
    z[6,5,0]  R1999     1.4420443773269653e-01
    z[6,5,0]  R2000     -5.6685519218444824e-01
    z[6,5,0]  R2001     -1.6137033700942993e-01
    z[6,5,0]  R2002     -6.2655562162399292e-01
    z[6,5,0]  R2003     2.0319147035479546e-02
    z[6,5,0]  R2004     -4.3238359689712524e-01
    z[6,5,0]  R2005     1.7326253652572632e-01
    z[6,5,0]  R2006     0.472392737865448
    z[6,5,0]  R2007     2.1025046706199646e-01
    z[6,5,0]  R2008     -1.4568910002708435e-01
    z[6,5,0]  R2009     -2.6236453652381897e-01
    z[6,5,0]  R2010     -2.3091338574886322e-01
    z[6,5,0]  R2011     2.8852918744087219e-01
    z[6,5,0]  R2012     -5.0840634107589722e-01
    z[6,5,0]  R2013     5.3634464740753174e-01
    z[6,5,0]  R2014     -1.7589415609836578e-01
    z[6,5,0]  R2015     2.1643792092800140e-01
    z[6,5,0]  R2016     3.8719531893730164e-01
    z[6,5,0]  R2017     -3.2949864864349365e-01
    z[6,5,0]  R2018     3.3848136663436890e-01
    z[6,5,0]  R2019     -3.5411331057548523e-01
    z[6,5,0]  R2020     -0.465248167514801
    z[6,5,0]  R2021     2.3825326561927795e-01
    z[6,5,0]  R2022     5.5241864919662476e-01
    z[6,5,0]  R2023     -0.437234103679657
    z[6,5,0]  R2024     -5.3801500797271729e-01
    z[6,5,0]  R2025     3.4132543206214905e-01
    z[6,5,0]  R2026     -2.3048569262027740e-01
    z[6,5,0]  R2027     0.0930616706609726
    z[6,5,0]  R2028     2.5502392649650574e-01
    z[6,5,0]  R2029     -1.9639667868614197e-01
    z[6,5,0]  R2030     -3.8214358687400818e-01
    z[6,5,0]  R2031     -5.0560951232910156e-01
    z[6,5,0]  R2032     -3.2939481735229492e-01
    z[6,5,0]  R2033     -3.9098620414733887e-01
    z[6,5,0]  R2034     -3.3695119619369507e-01
    z[6,5,0]  R2035     -3.5032325983047485e-01
    z[6,5,0]  R2036     -4.1307485103607178e-01
    z[6,5,0]  R2037     -3.8969355821609497e-01
    z[6,5,0]  R2038     3.5542088747024536e-01
    z[6,5,0]  R2039     5.8741962909698486e-01
    z[6,5,0]  R2040     -9.3581545352935791e-01
    z[6,5,0]  R2041     2.1107417345046997e-01
    z[6,5,0]  R2042     -9.1353046894073486e-01
    z[6,5,0]  R2043     1.0356234014034271e-01
    z[6,5,0]  R2044     2.6287612318992615e-01
    z[6,5,0]  R2045     -3.2082059979438782e-01
    z[6,5,0]  R2046     3.8107904791831970e-01
    z[6,5,0]  R2047     -1.7919836938381195e-01
    z[6,5,0]  R2048     1.4544046483933926e-02
    z[6,5,0]  R2049     3.7239700555801392e-01
    z[6,5,0]  R2050     -5.5211794376373291e-01
    z[6,5,0]  R2051     -6.5027683973312378e-01
    z[6,5,0]  R2052     -4.2978027462959290e-01
    z[6,5,0]  R2053     -2.2500525414943695e-01
    z[6,5,0]  R2054     -4.1538852453231812e-01
    z[6,5,1]  R48       1
    z[6,5,1]  R57       -1
    z[6,5,1]  R1903     -1
    z[6,5,1]  R1904     1
    z[6,5,1]  R1915     6.1162346601486206e-01
    z[6,5,1]  R1916     6.8455594778060913e-01
    z[6,5,1]  R1917     5.9001648426055908e-01
    z[6,5,1]  R1918     4.4077399373054504e-01
    z[6,5,1]  R1919     5.4034572839736938e-01
    z[6,5,1]  R1920     8.1180453300476074e-01
    z[6,5,1]  R1921     3.6116382479667664e-01
    z[6,5,1]  R1922     3.5026282072067261e-01
    z[6,5,1]  R1923     3.2761648297309875e-01
    z[6,5,1]  R1924     4.8268094658851624e-01
    z[6,5,1]  R1925     -9.0482914447784424e-01
    z[6,5,1]  R1926     -8.5679125785827637e-01
    z[6,5,1]  R1927     -0.746425211429596
    z[6,5,1]  R1928     -8.7104260921478271e-01
    z[6,5,1]  R1929     -8.7729436159133911e-01
    z[6,5,1]  R1930     -6.8070882558822632e-01
    z[6,5,1]  R1931     -6.4351511001586914e-01
    z[6,5,1]  R1932     -5.6441736221313477e-01
    z[6,5,1]  R1933     -6.4501452445983887e-01
    z[6,5,1]  R1934     -6.6356188058853149e-01
    z[6,5,1]  R1935     5.0011169910430908e-01
    z[6,5,1]  R1936     -4.6965089440345764e-01
    z[6,5,1]  R1937     -1.2971398234367371e-01
    z[6,5,1]  R1938     0.0066000921651721
    z[6,5,1]  R1939     -2.2840197384357452e-01
    z[6,5,1]  R1940     -2.7539052069187164e-02
    z[6,5,1]  R1941     -2.3782984912395477e-01
    z[6,5,1]  R1942     5.2312824875116348e-02
    z[6,5,1]  R1943     6.6013656556606293e-02
    z[6,5,1]  R1944     -2.9741770029067993e-01
    z[6,5,1]  R1945     1.8457408249378204e-01
    z[6,5,1]  R1946     7.5507219880819321e-03
    z[6,5,1]  R1947     2.5539350509643555e-01
    z[6,5,1]  R1948     -5.0007468461990356e-01
    z[6,5,1]  R1949     3.8062937557697296e-02
    z[6,5,1]  R1950     4.4514108449220657e-02
    z[6,5,1]  R1951     5.1867380738258362e-02
    z[6,5,1]  R1952     -1.7568904161453247e-01
    z[6,5,1]  R1953     -8.0612100660800934e-02
    z[6,5,1]  R1954     -1.5621571242809296e-01
    z[6,5,1]  R1955     -7.9453057050704956e-01
    z[6,5,1]  R1956     1.1819142103195190e-01
    z[6,5,1]  R1957     5.6701959110796452e-03
    z[6,5,1]  R1958     0.311960905790329
    z[6,5,1]  R1959     -7.0481783151626587e-01
    z[6,5,1]  R1960     -2.2319043055176735e-02
    z[6,5,1]  R1961     2.4448089301586151e-01
    z[6,5,1]  R1962     -7.0130831003189087e-01
    z[6,5,1]  R1963     6.2961626052856445e-01
    z[6,5,1]  R1964     -5.6727476418018341e-02
    z[6,5,1]  R1965     3.1559771299362183e-01
    z[6,5,1]  R1966     -3.6972990632057190e-01
    z[6,5,1]  R1967     -8.2249885797500610e-01
    z[6,5,1]  R1968     2.7130961418151855e-01
    z[6,5,1]  R1969     1.1103488504886627e-01
    z[6,5,1]  R1970     -2.3097580671310425e-01
    z[6,5,1]  R1971     1.4612478017807007e-01
    z[6,5,1]  R1972     -7.4920791387557983e-01
    z[6,5,1]  R1973     -5.8395504951477051e-01
    z[6,5,1]  R1974     -5.6713259220123291e-01
    z[6,5,1]  R1975     5.9958990663290024e-02
    z[6,5,1]  R1976     -5.2166921086609364e-03
    z[6,5,1]  R1977     -4.1477791965007782e-02
    z[6,5,1]  R1978     7.3133128881454468e-01
    z[6,5,1]  R1979     -0.0706862360239029
    z[6,5,1]  R1980     6.9081479310989380e-01
    z[6,5,1]  R1981     6.9255203008651733e-01
    z[6,5,1]  R1982     7.9167377948760986e-01
    z[6,5,1]  R1983     6.6974085569381714e-01
    z[6,5,1]  R1984     8.5541135072708130e-01
    z[6,5,1]  R1985     2.6883864402770996e-01
    z[6,5,1]  R1986     -1.3114847242832184e-01
    z[6,5,1]  R1987     2.3110222816467285e-01
    z[6,5,1]  R1988     -1.0313341766595840e-01
    z[6,5,1]  R1989     3.4971255064010620e-01
    z[6,5,1]  R1990     2.2228454053401947e-01
    z[6,5,1]  R1991     1.7723912000656128e-01
    z[6,5,1]  R1992     1.1129811406135559e-01
    z[6,5,1]  R1993     -4.2762002348899841e-01
    z[6,5,1]  R1994     -2.9504433274269104e-01
    z[6,5,1]  R1995     -1.4158391952514648e-01
    z[6,5,1]  R1996     -0.139053076505661
    z[6,5,1]  R1997     -6.5932208299636841e-01
    z[6,5,1]  R1998     -5.9185934066772461e-01
    z[6,5,1]  R1999     -0.632899284362793
    z[6,5,1]  R2000     -6.1066597700119019e-01
    z[6,5,1]  R2001     5.5079009383916855e-02
    z[6,5,1]  R2002     -6.1779773235321045e-01
    z[6,5,1]  R2003     -5.3355228900909424e-01
    z[6,5,1]  R2004     -1.7407085001468658e-01
    z[6,5,1]  R2005     3.0003988742828369e-01
    z[6,5,1]  R2006     -7.3637050390243530e-01
    z[6,5,1]  R2007     -6.3921970129013062e-01
    z[6,5,1]  R2008     -7.4083238840103149e-01
    z[6,5,1]  R2009     3.7029862403869629e-01
    z[6,5,1]  R2010     -0.419521301984787
    z[6,5,1]  R2011     -7.4704664945602417e-01
    z[6,5,1]  R2012     4.4451199471950531e-02
    z[6,5,1]  R2013     -5.7193356752395630e-01
    z[6,5,1]  R2014     -7.1301937103271484e-01
    z[6,5,1]  R2015     -7.0517992973327637e-01
    z[6,5,1]  R2016     -7.2905343770980835e-01
    z[6,5,1]  R2017     5.4468762874603271e-01
    z[6,5,1]  R2018     -7.1067941188812256e-01
    z[6,5,1]  R2019     -6.4033544063568115e-01
    z[6,5,1]  R2020     -2.7156734466552734e-01
    z[6,5,1]  R2021     -6.5268623828887939e-01
    z[6,5,1]  R2022     -6.1438292264938354e-01
    z[6,5,1]  R2023     -5.6438845396041870e-01
    z[6,5,1]  R2024     -5.1818257570266724e-01
    z[6,5,1]  R2025     -9.1968756914138794e-01
    z[6,5,1]  R2026     9.4391658902168274e-02
    z[6,5,1]  R2027     1.7546078190207481e-02
    z[6,5,1]  R2028     -1.4050704240798950e-01
    z[6,5,1]  R2029     3.2863533496856689e-01
    z[6,5,1]  R2030     -7.3782926797866821e-01
    z[6,5,1]  R2031     1.0161117464303970e-01
    z[6,5,1]  R2032     -3.3437675237655640e-01
    z[6,5,1]  R2033     -4.8662039637565613e-01
    z[6,5,1]  R2034     -9.6070962026715279e-03
    z[6,5,1]  R2035     -4.6856346726417542e-01
    z[6,5,1]  R2036     -0.628913938999176
    z[6,5,1]  R2037     4.7408949583768845e-02
    z[6,5,1]  R2038     5.6012964248657227e-01
    z[6,5,1]  R2039     6.2852632999420166e-01
    z[6,5,1]  R2040     1.2805540859699249e-01
    z[6,5,1]  R2041     7.2681987285614014e-01
    z[6,5,1]  R2042     -7.2500887326896191e-03
    z[6,5,1]  R2043     6.6576778888702393e-01
    z[6,5,1]  R2044     1.2854360044002533e-01
    z[6,5,1]  R2045     -7.1572464704513550e-01
    z[6,5,1]  R2046     -7.2007365524768829e-02
    z[6,5,1]  R2047     -5.9405052661895752e-01
    z[6,5,1]  R2048     6.4080238342285156e-01
    z[6,5,1]  R2049     0.0572831854224205
    z[6,5,1]  R2050     -5.4361337423324585e-01
    z[6,5,1]  R2051     -0.56270432472229
    z[6,5,1]  R2052     -1.3700662553310394e-01
    z[6,5,1]  R2053     -0.588896632194519
    z[6,5,1]  R2054     -1.1941631138324738e-01
    z[6,5,2]  R49       1
    z[6,5,2]  R58       -1
    z[6,5,2]  R1905     -1
    z[6,5,2]  R1906     1
    z[6,5,2]  R1915     6.5307760238647461e-01
    z[6,5,2]  R1916     4.8185011744499207e-01
    z[6,5,2]  R1917     5.3949570655822754e-01
    z[6,5,2]  R1918     5.0236654281616211e-01
    z[6,5,2]  R1919     4.2099103331565857e-01
    z[6,5,2]  R1920     3.7018394470214844e-01
    z[6,5,2]  R1921     -5.2113026380538940e-01
    z[6,5,2]  R1922     -4.8376509547233582e-01
    z[6,5,2]  R1923     -7.8418493270874023e-01
    z[6,5,2]  R1924     -8.1867128610610962e-01
    z[6,5,2]  R1925     1.8444927036762238e-01
    z[6,5,2]  R1926     -1.3395757414400578e-02
    z[6,5,2]  R1927     1.6011258959770203e-01
    z[6,5,2]  R1928     -4.8764474689960480e-02
    z[6,5,2]  R1929     -2.2412322461605072e-01
    z[6,5,2]  R1930     6.8242150545120239e-01
    z[6,5,2]  R1931     -2.8009975329041481e-02
    z[6,5,2]  R1932     5.6274402141571045e-01
    z[6,5,2]  R1933     6.0653007030487061e-01
    z[6,5,2]  R1934     -2.1084873378276825e-01
    z[6,5,2]  R1935     -1.5013836324214935e-01
    z[6,5,2]  R1936     8.1123101711273193e-01
    z[6,5,2]  R1937     -6.7830908298492432e-01
    z[6,5,2]  R1938     5.9358769655227661e-01
    z[6,5,2]  R1939     -7.2841954231262207e-01
    z[6,5,2]  R1940     4.0486451983451843e-01
    z[6,5,2]  R1941     -6.5329098701477051e-01
    z[6,5,2]  R1942     4.2163950204849243e-01
    z[6,5,2]  R1943     1.7427203059196472e-01
    z[6,5,2]  R1944     -5.5641597509384155e-01
    z[6,5,2]  R1945     0.533997118473053
    z[6,5,2]  R1946     -9.4141222536563873e-02
    z[6,5,2]  R1947     -3.4328576922416687e-01
    z[6,5,2]  R1948     7.7171623706817627e-01
    z[6,5,2]  R1949     -6.3166123628616333e-01
    z[6,5,2]  R1950     -4.6719151735305786e-01
    z[6,5,2]  R1951     7.1479961276054382e-02
    z[6,5,2]  R1952     1.4302076399326324e-01
    z[6,5,2]  R1953     3.5709220916032791e-02
    z[6,5,2]  R1954     -6.6773869097232819e-02
    z[6,5,2]  R1955     3.0150640010833740e-01
    z[6,5,2]  R1956     5.7649750262498856e-02
    z[6,5,2]  R1957     2.9062870144844055e-01
    z[6,5,2]  R1958     -1.0436808317899704e-01
    z[6,5,2]  R1959     -1.2822796404361725e-01
    z[6,5,2]  R1960     1.3974268734455109e-01
    z[6,5,2]  R1961     3.3458107709884644e-01
    z[6,5,2]  R1962     -2.1774242818355560e-01
    z[6,5,2]  R1963     -1.1213681101799011e-01
    z[6,5,2]  R1964     -7.5407058000564575e-01
    z[6,5,2]  R1965     -5.7629472017288208e-01
    z[6,5,2]  R1966     8.7407833337783813e-01
    z[6,5,2]  R1967     -3.0261540785431862e-02
    z[6,5,2]  R1968     2.0813831686973572e-01
    z[6,5,2]  R1969     -9.4895833730697632e-01
    z[6,5,2]  R1970     -0.669061005115509
    z[6,5,2]  R1971     -1.8745658919215202e-02
    z[6,5,2]  R1972     1.6331587731838226e-01
    z[6,5,2]  R1973     3.9022177457809448e-02
    z[6,5,2]  R1974     -1.0737180709838867e-01
    z[6,5,2]  R1975     5.5815988779067993e-01
    z[6,5,2]  R1976     2.2595489025115967e-01
    z[6,5,2]  R1977     2.2538958489894867e-01
    z[6,5,2]  R1978     1.6700945794582367e-01
    z[6,5,2]  R1979     8.1221228837966919e-01
    z[6,5,2]  R1980     4.5618122816085815e-01
    z[6,5,2]  R1981     1.2502519786357880e-01
    z[6,5,2]  R1982     4.0478205680847168e-01
    z[6,5,2]  R1983     5.3620833158493042e-01
    z[6,5,2]  R1984     3.9113810658454895e-01
    z[6,5,2]  R1985     4.7829464077949524e-01
    z[6,5,2]  R1986     4.1106197237968445e-01
    z[6,5,2]  R1987     -4.9869006872177124e-01
    z[6,5,2]  R1988     -7.2007972002029419e-01
    z[6,5,2]  R1989     -1.7156164348125458e-01
    z[6,5,2]  R1990     -4.4149711728096008e-01
    z[6,5,2]  R1991     2.8669720888137817e-01
    z[6,5,2]  R1992     -2.1144950389862061e-01
    z[6,5,2]  R1993     4.6509110927581787e-01
    z[6,5,2]  R1994     1.4532390236854553e-01
    z[6,5,2]  R1995     -2.3328140377998352e-01
    z[6,5,2]  R1996     -1.0717423260211945e-01
    z[6,5,2]  R1997     1.3992665708065033e-01
    z[6,5,2]  R1998     2.9441145062446594e-01
    z[6,5,2]  R1999     -2.7040395140647888e-01
    z[6,5,2]  R2000     1.5309794247150421e-01
    z[6,5,2]  R2001     7.6245918869972229e-02
    z[6,5,2]  R2002     -4.4432663917541504e-01
    z[6,5,2]  R2003     1.7600879073143005e-01
    z[6,5,2]  R2004     -2.4465925991535187e-01
    z[6,5,2]  R2005     -2.3060524463653564e-01
    z[6,5,2]  R2006     -1.9868843257427216e-01
    z[6,5,2]  R2007     5.8883899450302124e-01
    z[6,5,2]  R2008     -2.7977502346038818e-01
    z[6,5,2]  R2009     6.0295041650533676e-02
    z[6,5,2]  R2010     -5.6695544719696045e-01
    z[6,5,2]  R2011     -3.8297054171562195e-01
    z[6,5,2]  R2012     3.1879439949989319e-01
    z[6,5,2]  R2013     1.5251060947775841e-02
    z[6,5,2]  R2014     -7.6868377625942230e-02
    z[6,5,2]  R2015     4.2163223028182983e-01
    z[6,5,2]  R2016     -5.6556697934865952e-02
    z[6,5,2]  R2017     -2.1222374925855547e-04
    z[6,5,2]  R2018     -3.3787724375724792e-01
    z[6,5,2]  R2019     6.0927208513021469e-02
    z[6,5,2]  R2020     -9.9846169352531433e-02
    z[6,5,2]  R2021     -1.7482639849185944e-01
    z[6,5,2]  R2022     -3.3913305401802063e-01
    z[6,5,2]  R2023     4.5557226985692978e-02
    z[6,5,2]  R2024     4.0963280200958252e-01
    z[6,5,2]  R2025     9.2758618295192719e-02
    z[6,5,2]  R2026     1.0184465348720551e-01
    z[6,5,2]  R2027     1.7514440417289734e-01
    z[6,5,2]  R2028     2.0122143626213074e-01
    z[6,5,2]  R2029     5.0607389211654663e-01
    z[6,5,2]  R2030     -3.5405641794204712e-01
    z[6,5,2]  R2031     2.0912717282772064e-01
    z[6,5,2]  R2032     1.5767259895801544e-01
    z[6,5,2]  R2033     8.4160633385181427e-02
    z[6,5,2]  R2034     4.6334043145179749e-01
    z[6,5,2]  R2035     2.3736357688903809e-01
    z[6,5,2]  R2036     3.1158637255430222e-02
    z[6,5,2]  R2037     6.0849428176879883e-01
    z[6,5,2]  R2038     1.4234395325183868e-01
    z[6,5,2]  R2039     4.0318641066551208e-01
    z[6,5,2]  R2040     1.1819498240947723e-01
    z[6,5,2]  R2041     2.4166959524154663e-01
    z[6,5,2]  R2042     3.1032716855406761e-02
    z[6,5,2]  R2043     2.0859509706497192e-01
    z[6,5,2]  R2044     0.599233090877533
    z[6,5,2]  R2045     -2.5074759125709534e-01
    z[6,5,2]  R2046     -3.3579967916011810e-02
    z[6,5,2]  R2047     6.2019848823547363e-01
    z[6,5,2]  R2048     1.2159148603677750e-01
    z[6,5,2]  R2049     -1.8446686863899231e-01
    z[6,5,2]  R2050     3.5102772712707520e-01
    z[6,5,2]  R2051     3.5609204322099686e-02
    z[6,5,2]  R2052     5.5760347843170166e-01
    z[6,5,2]  R2053     -6.0046225786209106e-01
    z[6,5,2]  R2054     4.1237625479698181e-01
    z[6,5,3]  R50       1
    z[6,5,3]  R59       -1
    z[6,5,3]  R1907     -1
    z[6,5,3]  R1908     1
    z[6,5,3]  R1915     -1.7735873162746429e-01
    z[6,5,3]  R1916     -7.2166711091995239e-02
    z[6,5,3]  R1917     -3.6421704292297363e-01
    z[6,5,3]  R1918     -1.6406776383519173e-02
    z[6,5,3]  R1919     -3.6862000823020935e-02
    z[6,5,3]  R1920     7.6529145240783691e-02
    z[6,5,3]  R1921     -5.0604915618896484e-01
    z[6,5,3]  R1922     -2.8454324603080750e-01
    z[6,5,3]  R1923     1.4922952651977539e-01
    z[6,5,3]  R1924     2.3323077708482742e-02
    z[6,5,3]  R1925     2.2303119301795959e-01
    z[6,5,3]  R1926     3.0072297900915146e-02
    z[6,5,3]  R1927     -1.5407598018646240e-01
    z[6,5,3]  R1928     -1.4522799849510193e-01
    z[6,5,3]  R1929     -5.2057329565286636e-02
    z[6,5,3]  R1930     4.7645575250498950e-04
    z[6,5,3]  R1931     -1.5810810029506683e-02
    z[6,5,3]  R1932     1.1137538403272629e-01
    z[6,5,3]  R1933     -1.4453551173210144e-01
    z[6,5,3]  R1934     -6.6462743282318115e-01
    z[6,5,3]  R1935     -1.1206272989511490e-01
    z[6,5,3]  R1936     2.1960420906543732e-01
    z[6,5,3]  R1937     2.1484570205211639e-01
    z[6,5,3]  R1938     6.5667057037353516e-01
    z[6,5,3]  R1939     2.0240142941474915e-01
    z[6,5,3]  R1940     4.0234780311584473e-01
    z[6,5,3]  R1941     -3.4329872578382492e-02
    z[6,5,3]  R1942     2.8709346055984497e-01
    z[6,5,3]  R1943     8.9333295822143555e-01
    z[6,5,3]  R1944     2.7548578381538391e-01
    z[6,5,3]  R1945     -1.5493296086788177e-01
    z[6,5,3]  R1946     3.1071117520332336e-01
    z[6,5,3]  R1947     4.4686415791511536e-01
    z[6,5,3]  R1948     -1.8663607537746429e-01
    z[6,5,3]  R1949     3.4587290883064270e-01
    z[6,5,3]  R1950     1.8540048599243164e-01
    z[6,5,3]  R1951     4.5564615726470947e-01
    z[6,5,3]  R1952     3.4619012475013733e-01
    z[6,5,3]  R1953     6.1684612184762955e-02
    z[6,5,3]  R1954     2.7708551287651062e-01
    z[6,5,3]  R1955     2.7882652357220650e-02
    z[6,5,3]  R1956     2.9548335075378418e-01
    z[6,5,3]  R1957     6.4322352409362793e-01
    z[6,5,3]  R1958     0.0772358700633049
    z[6,5,3]  R1959     4.0807634592056274e-01
    z[6,5,3]  R1960     4.4087588787078857e-01
    z[6,5,3]  R1961     8.4481775760650635e-01
    z[6,5,3]  R1962     -1.0306950658559799e-01
    z[6,5,3]  R1963     5.0641906261444092e-01
    z[6,5,3]  R1964     2.6382520794868469e-01
    z[6,5,3]  R1965     -3.1905156373977661e-01
    z[6,5,3]  R1966     -1.2970322370529175e-01
    z[6,5,3]  R1967     2.6195693016052246e-01
    z[6,5,3]  R1968     0.744918942451477
    z[6,5,3]  R1969     1.3488547876477242e-02
    z[6,5,3]  R1970     1.7731359601020813e-01
    z[6,5,3]  R1971     4.5670741796493530e-01
    z[6,5,3]  R1972     -0.512614369392395
    z[6,5,3]  R1973     -4.7568336129188538e-01
    z[6,5,3]  R1974     3.3361083269119263e-01
    z[6,5,3]  R1975     -6.5109741687774658e-01
    z[6,5,3]  R1976     -6.2717002630233765e-01
    z[6,5,3]  R1977     -7.7808088064193726e-01
    z[6,5,3]  R1978     1.4964616298675537e-01
    z[6,5,3]  R1979     -2.8170493245124817e-01
    z[6,5,3]  R1980     -2.2198049724102020e-01
    z[6,5,3]  R1981     8.4494002163410187e-02
    z[6,5,3]  R1982     -1.6668562591075897e-01
    z[6,5,3]  R1983     -4.2440012097358704e-02
    z[6,5,3]  R1984     5.8643206954002380e-02
    z[6,5,3]  R1985     2.6806342601776123e-01
    z[6,5,3]  R1986     7.3074257373809814e-01
    z[6,5,3]  R1987     4.5107737183570862e-01
    z[6,5,3]  R1988     4.0506976842880249e-01
    z[6,5,3]  R1989     3.5198843479156494e-01
    z[6,5,3]  R1990     0.509611189365387
    z[6,5,3]  R1991     4.0571564435958862e-01
    z[6,5,3]  R1992     3.1033343076705933e-01
    z[6,5,3]  R1993     2.2961201146245003e-02
    z[6,5,3]  R1994     3.0198348686099052e-02
    z[6,5,3]  R1995     4.6960216760635376e-01
    z[6,5,3]  R1996     3.3206886053085327e-01
    z[6,5,3]  R1997     1.2452097237110138e-01
    z[6,5,3]  R1998     -3.0271539092063904e-01
    z[6,5,3]  R1999     -6.3038282096385956e-02
    z[6,5,3]  R2000     8.8862545788288116e-02
    z[6,5,3]  R2001     1.9767074286937714e-01
    z[6,5,3]  R2002     7.8074708580970764e-02
    z[6,5,3]  R2003     -7.4829542636871338e-01
    z[6,5,3]  R2004     2.4469788372516632e-01
    z[6,5,3]  R2005     5.1538795232772827e-01
    z[6,5,3]  R2006     1.0687772929668427e-01
    z[6,5,3]  R2007     -4.7982245683670044e-02
    z[6,5,3]  R2008     -3.9214301109313965e-01
    z[6,5,3]  R2009     4.2069315910339355e-01
    z[6,5,3]  R2010     5.0914257764816284e-01
    z[6,5,3]  R2011     2.0109629631042480e-01
    z[6,5,3]  R2012     2.7164161205291748e-01
    z[6,5,3]  R2013     -0.347178190946579
    z[6,5,3]  R2014     -4.3560093641281128e-01
    z[6,5,3]  R2015     2.8857287764549255e-01
    z[6,5,3]  R2016     1.5668129920959473e-01
    z[6,5,3]  R2017     4.3472734093666077e-01
    z[6,5,3]  R2018     -2.9675019904971123e-02
    z[6,5,3]  R2019     2.3451203107833862e-01
    z[6,5,3]  R2020     6.3514953851699829e-01
    z[6,5,3]  R2021     1.2547163665294647e-01
    z[6,5,3]  R2022     -1.6502922773361206e-01
    z[6,5,3]  R2023     -2.4309846758842468e-01
    z[6,5,3]  R2024     1.9159168004989624e-01
    z[6,5,3]  R2025     -1.4149367809295654e-01
    z[6,5,3]  R2026     5.6732130050659180e-01
    z[6,5,3]  R2027     9.2289096117019653e-01
    z[6,5,3]  R2028     9.2001551389694214e-01
    z[6,5,3]  R2029     5.1745635271072388e-01
    z[6,5,3]  R2030     -4.8330705612897873e-02
    z[6,5,3]  R2031     3.7941941618919373e-01
    z[6,5,3]  R2032     -0.863492488861084
    z[6,5,3]  R2033     -5.3829592466354370e-01
    z[6,5,3]  R2034     -6.1950671672821045e-01
    z[6,5,3]  R2035     -7.3992156982421875e-01
    z[6,5,3]  R2036     4.6827623248100281e-01
    z[6,5,3]  R2037     -6.1597061157226562e-01
    z[6,5,3]  R2038     -1.3543231785297394e-01
    z[6,5,3]  R2039     2.1678598225116730e-01
    z[6,5,3]  R2040     1.0164123773574829e-01
    z[6,5,3]  R2041     -0.0944051444530487
    z[6,5,3]  R2042     -3.6431051790714264e-02
    z[6,5,3]  R2043     3.6285273730754852e-02
    z[6,5,3]  R2044     4.0914192795753479e-01
    z[6,5,3]  R2045     2.6608530431985855e-02
    z[6,5,3]  R2046     2.8290608525276184e-01
    z[6,5,3]  R2047     3.6883381009101868e-01
    z[6,5,3]  R2048     6.7364257574081421e-01
    z[6,5,3]  R2049     3.0480548739433289e-01
    z[6,5,3]  R2050     1.1650307476520538e-01
    z[6,5,3]  R2051     1.1999174207448959e-01
    z[6,5,3]  R2052     -6.6445344686508179e-01
    z[6,5,3]  R2053     1.1093888431787491e-02
    z[6,5,3]  R2054     -6.6328942775726318e-01
    z[6,5,4]  R51       1
    z[6,5,4]  R60       -1
    z[6,5,4]  R1909     -1
    z[6,5,4]  R1910     1
    z[6,5,4]  R1915     3.0931377410888672e-01
    z[6,5,4]  R1916     -1.0533689707517624e-01
    z[6,5,4]  R1917     -3.9524812251329422e-02
    z[6,5,4]  R1918     -4.2555180191993713e-01
    z[6,5,4]  R1919     1.2045098841190338e-01
    z[6,5,4]  R1920     1.0959753394126892e-01
    z[6,5,4]  R1921     -5.9787888079881668e-02
    z[6,5,4]  R1922     3.0749875307083130e-01
    z[6,5,4]  R1923     5.5037878453731537e-02
    z[6,5,4]  R1924     -1.9136065244674683e-01
    z[6,5,4]  R1925     -2.1240387856960297e-01
    z[6,5,4]  R1926     -1.2740857899188995e-01
    z[6,5,4]  R1927     2.3785457015037537e-01
    z[6,5,4]  R1928     -3.0441511422395706e-02
    z[6,5,4]  R1929     -1.1305811256170273e-01
    z[6,5,4]  R1930     -1.8227986991405487e-01
    z[6,5,4]  R1931     4.3938314914703369e-01
    z[6,5,4]  R1932     -3.6281594634056091e-01
    z[6,5,4]  R1933     1.8025094270706177e-01
    z[6,5,4]  R1934     -7.6935626566410065e-02
    z[6,5,4]  R1935     3.2748109102249146e-01
    z[6,5,4]  R1936     1.4197234809398651e-01
    z[6,5,4]  R1937     -9.6101216971874237e-02
    z[6,5,4]  R1938     -1.2907008826732635e-01
    z[6,5,4]  R1939     -1.4035013318061829e-01
    z[6,5,4]  R1940     -1.7884099856019020e-02
    z[6,5,4]  R1941     3.0120092630386353e-01
    z[6,5,4]  R1942     4.3370419740676880e-01
    z[6,5,4]  R1943     -6.7534692585468292e-02
    z[6,5,4]  R1944     6.7070230841636658e-02
    z[6,5,4]  R1945     -4.2729938030242920e-01
    z[6,5,4]  R1946     3.8238272070884705e-01
    z[6,5,4]  R1947     1.5390522778034210e-01
    z[6,5,4]  R1948     -2.1807695925235748e-01
    z[6,5,4]  R1949     3.8307970762252808e-01
    z[6,5,4]  R1950     5.5730640888214111e-01
    z[6,5,4]  R1951     -1.3726758956909180e-01
    z[6,5,4]  R1952     3.5945403575897217e-01
    z[6,5,4]  R1953     5.9789609909057617e-01
    z[6,5,4]  R1954     3.2487982511520386e-01
    z[6,5,4]  R1955     1.8357923254370689e-02
    z[6,5,4]  R1956     1.6997136175632477e-02
    z[6,5,4]  R1957     2.2530054673552513e-02
    z[6,5,4]  R1958     7.1387737989425659e-02
    z[6,5,4]  R1959     5.3474036976695061e-03
    z[6,5,4]  R1960     -3.0325773358345032e-01
    z[6,5,4]  R1961     2.4515953660011292e-01
    z[6,5,4]  R1962     3.9190939068794250e-01
    z[6,5,4]  R1963     4.7103419899940491e-01
    z[6,5,4]  R1964     3.1757593154907227e-02
    z[6,5,4]  R1965     5.3931981325149536e-01
    z[6,5,4]  R1966     8.1775300204753876e-02
    z[6,5,4]  R1967     2.9924826696515083e-02
    z[6,5,4]  R1968     4.9881532788276672e-02
    z[6,5,4]  R1969     7.0591926574707031e-02
    z[6,5,4]  R1970     3.9975631237030029e-01
    z[6,5,4]  R1971     -3.8714587688446045e-01
    z[6,5,4]  R1972     -3.4964978694915771e-01
    z[6,5,4]  R1973     -3.7415459752082825e-01
    z[6,5,4]  R1974     3.8348725438117981e-01
    z[6,5,4]  R1975     3.5494975745677948e-02
    z[6,5,4]  R1976     3.9642862975597382e-03
    z[6,5,4]  R1977     -0.091993547976017
    z[6,5,4]  R1978     -9.1157844290137291e-03
    z[6,5,4]  R1979     -3.5667590796947479e-02
    z[6,5,4]  R1980     2.1434406936168671e-01
    z[6,5,4]  R1981     0.334311306476593
    z[6,5,4]  R1982     2.6511928439140320e-01
    z[6,5,4]  R1983     -2.0978540182113647e-01
    z[6,5,4]  R1984     -1.8253475427627563e-01
    z[6,5,4]  R1985     7.7206425368785858e-02
    z[6,5,4]  R1986     5.9892702847719193e-02
    z[6,5,4]  R1987     -1.0336165875196457e-01
    z[6,5,4]  R1988     8.4578081965446472e-02
    z[6,5,4]  R1989     9.1192595660686493e-02
    z[6,5,4]  R1990     1.7118583619594574e-01
    z[6,5,4]  R1991     -1.6608101129531860e-01
    z[6,5,4]  R1992     -2.7674525976181030e-01
    z[6,5,4]  R1993     -1.9405819475650787e-01
    z[6,5,4]  R1994     7.9633817076683044e-02
    z[6,5,4]  R1995     0.0679209977388382
    z[6,5,4]  R1996     1.0429047048091888e-01
    z[6,5,4]  R1997     -2.2596006095409393e-01
    z[6,5,4]  R1998     1.8353813886642456e-01
    z[6,5,4]  R1999     -4.0670579671859741e-01
    z[6,5,4]  R2000     -2.8136115521192551e-02
    z[6,5,4]  R2001     2.4890285730361938e-01
    z[6,5,4]  R2002     -1.1637928336858749e-01
    z[6,5,4]  R2003     1.4769001305103302e-01
    z[6,5,4]  R2004     8.6736559867858887e-02
    z[6,5,4]  R2005     5.2736252546310425e-01
    z[6,5,4]  R2006     3.4467944502830505e-01
    z[6,5,4]  R2007     -9.3032978475093842e-02
    z[6,5,4]  R2008     -1.4599943161010742e-01
    z[6,5,4]  R2009     2.4246694147586823e-01
    z[6,5,4]  R2010     -5.3987614810466766e-02
    z[6,5,4]  R2011     -4.0561595559120178e-01
    z[6,5,4]  R2012     4.7643250226974487e-01
    z[6,5,4]  R2013     1.1399107426404953e-01
    z[6,5,4]  R2014     -3.6978834867477417e-01
    z[6,5,4]  R2015     7.7476361766457558e-03
    z[6,5,4]  R2016     -1.7588908970355988e-01
    z[6,5,4]  R2017     1.7745584249496460e-01
    z[6,5,4]  R2018     2.0051756501197815e-01
    z[6,5,4]  R2019     -1.5259747393429279e-02
    z[6,5,4]  R2020     3.9132067561149597e-01
    z[6,5,4]  R2021     -3.0765104293823242e-01
    z[6,5,4]  R2022     -3.7825030088424683e-01
    z[6,5,4]  R2023     4.5621815323829651e-01
    z[6,5,4]  R2024     -3.1934878230094910e-01
    z[6,5,4]  R2025     3.3947516232728958e-02
    z[6,5,4]  R2026     1.4159974455833435e-01
    z[6,5,4]  R2027     -1.8256385624408722e-01
    z[6,5,4]  R2028     8.2530558109283447e-02
    z[6,5,4]  R2029     2.2407043725252151e-02
    z[6,5,4]  R2030     -1.9012410938739777e-01
    z[6,5,4]  R2031     5.4631102085113525e-01
    z[6,5,4]  R2032     5.9076272882521152e-03
    z[6,5,4]  R2033     2.1291528642177582e-01
    z[6,5,4]  R2034     -1.3926008343696594e-01
    z[6,5,4]  R2035     -0.0978035256266594
    z[6,5,4]  R2036     -3.0345961451530457e-01
    z[6,5,4]  R2037     -0.0781460627913475
    z[6,5,4]  R2038     4.1999399662017822e-01
    z[6,5,4]  R2039     -5.8338645845651627e-02
    z[6,5,4]  R2040     1.0958840698003769e-01
    z[6,5,4]  R2041     4.8430660367012024e-01
    z[6,5,4]  R2042     0.261323481798172
    z[6,5,4]  R2043     2.9446640610694885e-01
    z[6,5,4]  R2044     1.5138788521289825e-01
    z[6,5,4]  R2045     -4.8259207606315613e-01
    z[6,5,4]  R2046     2.0322456955909729e-01
    z[6,5,4]  R2047     -2.0986037328839302e-02
    z[6,5,4]  R2048     2.3399895429611206e-01
    z[6,5,4]  R2049     -2.8322216868400574e-01
    z[6,5,4]  R2050     1.1421643942594528e-01
    z[6,5,4]  R2051     -1.4713747799396515e-01
    z[6,5,4]  R2052     1.1014923220500350e-03
    z[6,5,4]  R2053     1.5322542190551758e-01
    z[6,5,4]  R2054     -1.8408633768558502e-01
    z[6,5,5]  R52       1
    z[6,5,5]  R61       -1
    z[6,5,5]  R1911     -1
    z[6,5,5]  R1912     1
    z[6,5,5]  R1915     -1.4910748600959778e-01
    z[6,5,5]  R1916     2.3642964661121368e-01
    z[6,5,5]  R1917     2.6192072033882141e-01
    z[6,5,5]  R1918     -2.4893982335925102e-02
    z[6,5,5]  R1919     1.1403822153806686e-01
    z[6,5,5]  R1920     -2.0856025815010071e-01
    z[6,5,5]  R1921     4.7178804874420166e-01
    z[6,5,5]  R1922     6.6391664743423462e-01
    z[6,5,5]  R1923     3.8924831151962280e-01
    z[6,5,5]  R1924     1.2152110785245895e-01
    z[6,5,5]  R1925     2.1437183022499084e-02
    z[6,5,5]  R1926     1.3909088075160980e-01
    z[6,5,5]  R1927     1.1812205612659454e-01
    z[6,5,5]  R1928     3.7348988652229309e-01
    z[6,5,5]  R1929     -2.3512698709964752e-01
    z[6,5,5]  R1930     -4.9178179353475571e-02
    z[6,5,5]  R1931     -1.8666283786296844e-01
    z[6,5,5]  R1932     4.4221282005310059e-01
    z[6,5,5]  R1933     -2.4498255550861359e-01
    z[6,5,5]  R1934     -1.5540733933448792e-01
    z[6,5,5]  R1935     -1.5384857356548309e-01
    z[6,5,5]  R1936     1.3855701684951782e-01
    z[6,5,5]  R1937     -2.4059610068798065e-01
    z[6,5,5]  R1938     -2.6186150312423706e-01
    z[6,5,5]  R1939     -2.3836867511272430e-01
    z[6,5,5]  R1940     7.9744279384613037e-01
    z[6,5,5]  R1941     -2.9433470964431763e-01
    z[6,5,5]  R1942     7.2514837980270386e-01
    z[6,5,5]  R1943     3.7951439619064331e-01
    z[6,5,5]  R1944     -3.2458725571632385e-01
    z[6,5,5]  R1945     -4.4477206468582153e-01
    z[6,5,5]  R1946     -8.5610244423151016e-03
    z[6,5,5]  R1947     4.2908897995948792e-01
    z[6,5,5]  R1948     0.0865989699959755
    z[6,5,5]  R1949     -6.7275352776050568e-02
    z[6,5,5]  R1950     -3.2819861173629761e-01
    z[6,5,5]  R1951     7.9767984151840210e-01
    z[6,5,5]  R1952     3.5359352827072144e-01
    z[6,5,5]  R1953     5.2157509326934814e-01
    z[6,5,5]  R1954     6.2777698040008545e-01
    z[6,5,5]  R1955     -1.5226955711841583e-01
    z[6,5,5]  R1956     2.4852935969829559e-01
    z[6,5,5]  R1957     6.4453983306884766e-01
    z[6,5,5]  R1958     8.9482986927032471e-01
    z[6,5,5]  R1959     -2.9989114403724670e-01
    z[6,5,5]  R1960     6.8360632658004761e-01
    z[6,5,5]  R1961     2.0597076416015625e-01
    z[6,5,5]  R1962     5.3643468767404556e-02
    z[6,5,5]  R1963     3.2350286841392517e-01
    z[6,5,5]  R1964     7.4796602129936218e-02
    z[6,5,5]  R1965     -8.3849526941776276e-02
    z[6,5,5]  R1966     -1.0466530919075012e-01
    z[6,5,5]  R1967     -1.0526506602764130e-01
    z[6,5,5]  R1968     5.5378687381744385e-01
    z[6,5,5]  R1969     -4.9198679625988007e-02
    z[6,5,5]  R1970     2.0749524235725403e-01
    z[6,5,5]  R1971     4.2804643511772156e-01
    z[6,5,5]  R1972     3.4910753369331360e-02
    z[6,5,5]  R1973     -3.4486436843872070e-01
    z[6,5,5]  R1974     -1.7774419859051704e-02
    z[6,5,5]  R1975     2.1825125813484192e-01
    z[6,5,5]  R1976     -1.6139014065265656e-01
    z[6,5,5]  R1977     -1.1417536437511444e-01
    z[6,5,5]  R1978     5.5422621965408325e-01
    z[6,5,5]  R1979     -1.3392789661884308e-01
    z[6,5,5]  R1980     -7.7547687105834484e-03
    z[6,5,5]  R1981     2.3872756958007812e-01
    z[6,5,5]  R1982     -1.4714235067367554e-01
    z[6,5,5]  R1983     3.2425004243850708e-01
    z[6,5,5]  R1984     0.00981933530420065
    z[6,5,5]  R1985     -7.5578755140304565e-01
    z[6,5,5]  R1986     -3.6837142705917358e-01
    z[6,5,5]  R1987     -3.8060164451599121e-01
    z[6,5,5]  R1988     -4.7244527935981750e-01
    z[6,5,5]  R1989     -4.5457679033279419e-01
    z[6,5,5]  R1990     -2.8590077161788940e-01
    z[6,5,5]  R1991     -5.7144075632095337e-01
    z[6,5,5]  R1992     -3.1042066216468811e-01
    z[6,5,5]  R1993     3.2131791114807129e-01
    z[6,5,5]  R1994     -1.9068498909473419e-01
    z[6,5,5]  R1995     -7.7682763338088989e-01
    z[6,5,5]  R1996     -6.6140621900558472e-01
    z[6,5,5]  R1997     1.5085159242153168e-01
    z[6,5,5]  R1998     -2.7786001563072205e-01
    z[6,5,5]  R1999     4.7036954760551453e-01
    z[6,5,5]  R2000     2.8375312685966492e-01
    z[6,5,5]  R2001     -5.8317315578460693e-01
    z[6,5,5]  R2002     -6.2162160873413086e-02
    z[6,5,5]  R2003     -1.9050613045692444e-01
    z[6,5,5]  R2004     -5.0837069749832153e-01
    z[6,5,5]  R2005     -4.6687945723533630e-01
    z[6,5,5]  R2006     2.4668979644775391e-01
    z[6,5,5]  R2007     3.4272089600563049e-01
    z[6,5,5]  R2008     1.4843259751796722e-01
    z[6,5,5]  R2009     -4.1661235690116882e-01
    z[6,5,5]  R2010     -3.3581340312957764e-01
    z[6,5,5]  R2011     -4.1864910599542782e-05
    z[6,5,5]  R2012     -5.6735342741012573e-01
    z[6,5,5]  R2013     -2.8519338369369507e-01
    z[6,5,5]  R2014     -3.2680696249008179e-01
    z[6,5,5]  R2015     -3.1746879220008850e-01
    z[6,5,5]  R2016     2.8315432369709015e-02
    z[6,5,5]  R2017     -5.2213990688323975e-01
    z[6,5,5]  R2018     -4.6418279409408569e-01
    z[6,5,5]  R2019     -5.5919522047042847e-01
    z[6,5,5]  R2020     -8.5035160183906555e-02
    z[6,5,5]  R2021     -5.5289936065673828e-01
    z[6,5,5]  R2022     -8.4765315055847168e-02
    z[6,5,5]  R2023     7.0585653185844421e-02
    z[6,5,5]  R2024     -3.6760583519935608e-01
    z[6,5,5]  R2025     5.3840130567550659e-02
    z[6,5,5]  R2026     -5.3950971364974976e-01
    z[6,5,5]  R2027     -1.6871818900108337e-01
    z[6,5,5]  R2028     8.8136322796344757e-02
    z[6,5,5]  R2029     -0.560045599937439
    z[6,5,5]  R2030     -2.2227661311626434e-01
    z[6,5,5]  R2031     -4.8511779308319092e-01
    z[6,5,5]  R2032     0.0947168618440628
    z[6,5,5]  R2033     4.3137103319168091e-01
    z[6,5,5]  R2034     -0.514052152633667
    z[6,5,5]  R2035     -1.3797669112682343e-01
    z[6,5,5]  R2036     -3.2306542992591858e-01
    z[6,5,5]  R2037     -2.9790589213371277e-01
    z[6,5,5]  R2038     5.7864511013031006e-01
    z[6,5,5]  R2039     -5.6701570749282837e-02
    z[6,5,5]  R2040     2.1980141103267670e-01
    z[6,5,5]  R2041     3.4816437959671021e-01
    z[6,5,5]  R2042     -1.7437775433063507e-01
    z[6,5,5]  R2043     6.0073465108871460e-01
    z[6,5,5]  R2044     5.6616044044494629e-01
    z[6,5,5]  R2045     4.0612876415252686e-02
    z[6,5,5]  R2046     -8.2353627681732178e-01
    z[6,5,5]  R2047     3.7596080452203751e-02
    z[6,5,5]  R2048     -8.9968152344226837e-02
    z[6,5,5]  R2049     -7.2813975811004639e-01
    z[6,5,5]  R2050     4.2458567023277283e-01
    z[6,5,5]  R2051     0.352770060300827
    z[6,5,5]  R2052     -4.4315110892057419e-02
    z[6,5,5]  R2053     3.7983334064483643e-01
    z[6,5,5]  R2054     -4.0564981102943420e-01
    z[6,5,6]  R53       1
    z[6,5,6]  R62       -1
    z[6,5,6]  R1913     -1
    z[6,5,6]  R1914     1
    z[6,5,6]  R1915     -2.1032159030437469e-01
    z[6,5,6]  R1916     -3.0687007308006287e-01
    z[6,5,6]  R1917     -7.9074859619140625e-02
    z[6,5,6]  R1918     -0.459751695394516
    z[6,5,6]  R1919     5.9187906980514526e-01
    z[6,5,6]  R1920     1.7832185328006744e-01
    z[6,5,6]  R1921     -2.1022546291351318e-01
    z[6,5,6]  R1922     1.0699690319597721e-02
    z[6,5,6]  R1923     -2.9689574241638184e-01
    z[6,5,6]  R1924     1.1398231983184814e-01
    z[6,5,6]  R1925     1.2032502889633179e-01
    z[6,5,6]  R1926     -3.2397669553756714e-01
    z[6,5,6]  R1927     -2.7706235647201538e-01
    z[6,5,6]  R1928     1.0287478566169739e-01
    z[6,5,6]  R1929     3.5452261567115784e-02
    z[6,5,6]  R1930     -1.4815139770507812e-01
    z[6,5,6]  R1931     -4.4864334166049957e-02
    z[6,5,6]  R1932     6.7343883216381073e-02
    z[6,5,6]  R1933     -1.1576295830309391e-02
    z[6,5,6]  R1934     1.3387800753116608e-01
    z[6,5,6]  R1935     2.2807975113391876e-01
    z[6,5,6]  R1936     9.1220222413539886e-02
    z[6,5,6]  R1937     -3.4824568033218384e-01
    z[6,5,6]  R1938     3.2301548123359680e-01
    z[6,5,6]  R1939     0.0875079482793808
    z[6,5,6]  R1940     -1.8640391528606415e-01
    z[6,5,6]  R1941     0.0978948324918747
    z[6,5,6]  R1942     3.7448275834321976e-02
    z[6,5,6]  R1943     1.1275637149810791e-01
    z[6,5,6]  R1944     -7.7837914228439331e-02
    z[6,5,6]  R1945     2.3740540444850922e-01
    z[6,5,6]  R1946     0.249008908867836
    z[6,5,6]  R1947     4.6054357290267944e-01
    z[6,5,6]  R1948     -2.5394740700721741e-01
    z[6,5,6]  R1949     5.9621725231409073e-02
    z[6,5,6]  R1950     -2.0486259460449219e-01
    z[6,5,6]  R1951     2.6581510901451111e-01
    z[6,5,6]  R1952     -2.0385244488716125e-01
    z[6,5,6]  R1953     -2.6578944921493530e-01
    z[6,5,6]  R1954     3.9920575916767120e-02
    z[6,5,6]  R1955     -2.9724302887916565e-01
    z[6,5,6]  R1956     -6.5363639593124390e-01
    z[6,5,6]  R1957     -0.0299916360527277
    z[6,5,6]  R1958     7.6696924865245819e-02
    z[6,5,6]  R1959     -1.8340897560119629e-01
    z[6,5,6]  R1960     1.6833055019378662e-01
    z[6,5,6]  R1961     -4.9545396119356155e-02
    z[6,5,6]  R1962     1.6663007438182831e-01
    z[6,5,6]  R1963     -9.1901179403066635e-03
    z[6,5,6]  R1964     0.555742084980011
    z[6,5,6]  R1965     3.7111893296241760e-01
    z[6,5,6]  R1966     -2.0795795321464539e-01
    z[6,5,6]  R1967     -1.8203240633010864e-01
    z[6,5,6]  R1968     0.0779573991894722
    z[6,5,6]  R1969     8.7144345045089722e-02
    z[6,5,6]  R1970     -1.1840105056762695e-01
    z[6,5,6]  R1971     1.4177146553993225e-01
    z[6,5,6]  R1972     -1.5528991818428040e-01
    z[6,5,6]  R1973     -4.0459185838699341e-01
    z[6,5,6]  R1974     5.0039076805114746e-01
    z[6,5,6]  R1975     -1.9783705472946167e-01
    z[6,5,6]  R1976     -1.4131994545459747e-01
    z[6,5,6]  R1977     -3.5487228631973267e-01
    z[6,5,6]  R1978     1.1082220077514648e-01
    z[6,5,6]  R1979     1.3181723654270172e-01
    z[6,5,6]  R1980     2.8088742494583130e-01
    z[6,5,6]  R1981     4.8448985815048218e-01
    z[6,5,6]  R1982     -2.1266406774520874e-01
    z[6,5,6]  R1983     -2.9523962736129761e-01
    z[6,5,6]  R1984     -2.5167265534400940e-01
    z[6,5,6]  R1985     -1.7507728934288025e-01
    z[6,5,6]  R1986     3.7377485632896423e-01
    z[6,5,6]  R1987     -3.6467275023460388e-01
    z[6,5,6]  R1988     1.3599184155464172e-01
    z[6,5,6]  R1989     -0.0767880454659462
    z[6,5,6]  R1990     -1.5330973267555237e-01
    z[6,5,6]  R1991     -3.6703673005104065e-01
    z[6,5,6]  R1992     -8.1977176666259766e-01
    z[6,5,6]  R1993     3.1422293186187744e-01
    z[6,5,6]  R1994     3.0217525362968445e-01
    z[6,5,6]  R1995     2.6269397139549255e-01
    z[6,5,6]  R1996     -3.7492290139198303e-01
    z[6,5,6]  R1997     -6.2892287969589233e-01
    z[6,5,6]  R1998     0.547385036945343
    z[6,5,6]  R1999     -0.338960736989975
    z[6,5,6]  R2000     4.3945336341857910e-01
    z[6,5,6]  R2001     -7.2387516498565674e-01
    z[6,5,6]  R2002     6.9454722106456757e-02
    z[6,5,6]  R2003     -2.5666895508766174e-01
    z[6,5,6]  R2004     -6.3011479377746582e-01
    z[6,5,6]  R2005     -2.5507858395576477e-01
    z[6,5,6]  R2006     0.0635906234383583
    z[6,5,6]  R2007     2.6841476559638977e-01
    z[6,5,6]  R2008     3.9312040805816650e-01
    z[6,5,6]  R2009     -6.1730813980102539e-01
    z[6,5,6]  R2010     -2.7263706922531128e-01
    z[6,5,6]  R2011     8.3916023373603821e-02
    z[6,5,6]  R2012     -1.2349230051040649e-01
    z[6,5,6]  R2013     -4.1247045993804932e-01
    z[6,5,6]  R2014     1.4649763703346252e-01
    z[6,5,6]  R2015     3.0656388401985168e-01
    z[6,5,6]  R2016     5.0899362564086914e-01
    z[6,5,6]  R2017     -3.1880617141723633e-01
    z[6,5,6]  R2018     -0.0982373058795929
    z[6,5,6]  R2019     -3.0485075712203979e-01
    z[6,5,6]  R2020     -3.6884722113609314e-01
    z[6,5,6]  R2021     2.6567247509956360e-01
    z[6,5,6]  R2022     -1.5768018364906311e-01
    z[6,5,6]  R2023     4.6476048231124878e-01
    z[6,5,6]  R2024     -2.0062988623976707e-02
    z[6,5,6]  R2025     -0.0706803947687149
    z[6,5,6]  R2026     -5.4278868436813354e-01
    z[6,5,6]  R2027     -2.1640880405902863e-01
    z[6,5,6]  R2028     -1.1714392900466919e-01
    z[6,5,6]  R2029     -1.2410532683134079e-01
    z[6,5,6]  R2030     3.1036806106567383e-01
    z[6,5,6]  R2031     1.1200872063636780e-01
    z[6,5,6]  R2032     -1.4323492534458637e-02
    z[6,5,6]  R2033     -2.8648027777671814e-01
    z[6,5,6]  R2034     -6.5235637128353119e-02
    z[6,5,6]  R2035     1.5903894603252411e-01
    z[6,5,6]  R2036     1.3085895776748657e-01
    z[6,5,6]  R2037     -3.6762490868568420e-02
    z[6,5,6]  R2038     1.0050827264785767e-01
    z[6,5,6]  R2039     2.0909073948860168e-01
    z[6,5,6]  R2040     -1.5240733325481415e-01
    z[6,5,6]  R2041     6.3973955810070038e-02
    z[6,5,6]  R2042     2.5381425023078918e-01
    z[6,5,6]  R2043     -2.3153199255466461e-01
    z[6,5,6]  R2044     2.1080653369426727e-01
    z[6,5,6]  R2045     -2.9442432522773743e-01
    z[6,5,6]  R2046     2.2117432951927185e-01
    z[6,5,6]  R2047     -3.0406171083450317e-01
    z[6,5,6]  R2048     -2.4027535319328308e-01
    z[6,5,6]  R2049     -3.4742251038551331e-01
    z[6,5,6]  R2050     -0.263701468706131
    z[6,5,6]  R2051     -3.1423202157020569e-01
    z[6,5,6]  R2052     2.0526324212551117e-01
    z[6,5,6]  R2053     -2.7229386568069458e-01
    z[6,5,6]  R2054     -6.8887092173099518e-02
    z[6,7,0]  R56       -1
    z[6,7,0]  R65       1
    z[6,7,0]  R2149     -1
    z[6,7,0]  R2150     1
    z[6,7,0]  R2163     7.6203301548957825e-02
    z[6,7,0]  R2164     3.6446052789688110e-01
    z[6,7,0]  R2165     3.8955527544021606e-01
    z[6,7,0]  R2166     3.9998903870582581e-01
    z[6,7,0]  R2167     3.8935866951942444e-01
    z[6,7,0]  R2168     3.3282566070556641e-01
    z[6,7,0]  R2169     -2.6747867465019226e-01
    z[6,7,0]  R2170     -1.6391228139400482e-01
    z[6,7,0]  R2171     -1.1296674609184265e-01
    z[6,7,0]  R2172     -1.7853356897830963e-01
    z[6,7,0]  R2173     -1.9356290996074677e-01
    z[6,7,0]  R2174     -3.5254049301147461e-01
    z[6,7,0]  R2175     -4.9616798758506775e-01
    z[6,7,0]  R2176     -2.5847837328910828e-01
    z[6,7,0]  R2177     -3.2877001166343689e-01
    z[6,7,0]  R2178     -1.1551152169704437e-01
    z[6,7,0]  R2179     -5.9576874971389771e-01
    z[6,7,0]  R2180     1.4361375570297241e-01
    z[6,7,0]  R2181     -3.2022818922996521e-01
    z[6,7,0]  R2182     -1.5970276296138763e-01
    z[6,7,0]  R2183     -7.2928392887115479e-01
    z[6,7,0]  R2184     -1.5947078168392181e-01
    z[6,7,0]  R2185     5.3713631629943848e-01
    z[6,7,0]  R2186     1.6378110647201538e-01
    z[6,7,0]  R2187     5.4045879840850830e-01
    z[6,7,0]  R2188     4.9611806869506836e-02
    z[6,7,0]  R2189     5.7317632436752319e-01
    z[6,7,0]  R2190     -1.4737339317798615e-01
    z[6,7,0]  R2191     0.0769510343670845
    z[6,7,0]  R2192     6.4041984081268311e-01
    z[6,7,0]  R2193     4.6904885768890381e-01
    z[6,7,0]  R2194     -8.2839828729629517e-01
    z[6,7,0]  R2195     -4.4422608613967896e-01
    z[6,7,0]  R2196     -8.6739659309387207e-05
    z[6,7,0]  R2197     5.7017225027084351e-01
    z[6,7,0]  R2198     -5.3395098447799683e-01
    z[6,7,0]  R2199     2.4247437715530396e-01
    z[6,7,0]  R2200     7.3009556531906128e-01
    z[6,7,0]  R2201     5.3689581155776978e-01
    z[6,7,0]  R2202     6.2699037790298462e-01
    z[6,7,0]  R2203     -4.0640029311180115e-01
    z[6,7,0]  R2204     -6.3726031780242920e-01
    z[6,7,0]  R2205     2.9142358899116516e-01
    z[6,7,0]  R2206     2.7225577831268311e-01
    z[6,7,0]  R2207     -4.4346490502357483e-01
    z[6,7,0]  R2208     4.4495406746864319e-01
    z[6,7,0]  R2209     -9.7905941307544708e-02
    z[6,7,0]  R2210     -5.1565051078796387e-01
    z[6,7,0]  R2211     -0.0890880599617958
    z[6,7,0]  R2212     2.0761384069919586e-01
    z[6,7,0]  R2213     -1.7567798495292664e-01
    z[6,7,0]  R2214     -1.4688614010810852e-01
    z[6,7,0]  R2215     -4.5699721574783325e-01
    z[6,7,0]  R2216     1.1366516351699829e-01
    z[6,7,0]  R2217     0.268271267414093
    z[6,7,0]  R2218     5.0068873167037964e-01
    z[6,7,0]  R2219     6.4537554979324341e-01
    z[6,7,0]  R2220     -4.0659990161657333e-02
    z[6,7,0]  R2221     -9.2636190354824066e-02
    z[6,7,0]  R2222     -3.9719808101654053e-01
    z[6,7,0]  R2223     7.8455817699432373e-01
    z[6,7,0]  R2224     0.70531165599823
    z[6,7,0]  R2225     3.6971229314804077e-01
    z[6,7,0]  R2226     7.3623317480087280e-01
    z[6,7,0]  R2227     0.49234738945961
    z[6,7,0]  R2228     7.1037894487380981e-01
    z[6,7,0]  R2229     0.515349805355072
    z[6,7,0]  R2230     8.2537406682968140e-01
    z[6,7,0]  R2231     6.4631688594818115e-01
    z[6,7,0]  R2232     3.6974081397056580e-01
    z[6,7,0]  R2233     -3.3919322490692139e-01
    z[6,7,0]  R2234     -5.5687659978866577e-01
    z[6,7,0]  R2235     -4.2452904582023621e-01
    z[6,7,0]  R2236     -3.1023699045181274e-01
    z[6,7,0]  R2237     -3.8400274515151978e-01
    z[6,7,0]  R2238     -3.4653279185295105e-01
    z[6,7,0]  R2239     -3.0923759937286377e-01
    z[6,7,0]  R2240     -3.6374312639236450e-01
    z[6,7,0]  R2241     -1.9177055358886719e-01
    z[6,7,0]  R2242     -2.4676986038684845e-01
    z[6,7,0]  R2243     -8.8863778114318848e-01
    z[6,7,0]  R2244     -5.6157851219177246e-01
    z[6,7,0]  R2245     -5.9145748615264893e-01
    z[6,7,0]  R2246     -5.4187035560607910e-01
    z[6,7,0]  R2247     -3.8939476013183594e-01
    z[6,7,0]  R2248     -2.0719681680202484e-01
    z[6,7,0]  R2249     -1.3011586666107178e-01
    z[6,7,0]  R2250     -1.2144438177347183e-01
    z[6,7,0]  R2251     -1.5247924625873566e-01
    z[6,7,0]  R2252     -1.5586009621620178e-01
    z[6,7,0]  R2253     5.9141874313354492e-01
    z[6,7,0]  R2254     2.3468628525733948e-01
    z[6,7,0]  R2255     -4.0681409835815430e-01
    z[6,7,0]  R2256     -3.3538538217544556e-01
    z[6,7,0]  R2257     -6.7390900850296021e-01
    z[6,7,0]  R2258     -0.569779634475708
    z[6,7,0]  R2259     -5.4532033205032349e-01
    z[6,7,0]  R2260     -5.2134835720062256e-01
    z[6,7,0]  R2261     -6.3466411828994751e-01
    z[6,7,0]  R2262     -5.6192767620086670e-01
    z[6,7,0]  R2263     -4.1344010829925537e-01
    z[6,7,0]  R2264     -7.8160566091537476e-01
    z[6,7,0]  R2265     -6.5982228517532349e-01
    z[6,7,0]  R2266     -7.6227217912673950e-01
    z[6,7,0]  R2267     -6.7510491609573364e-01
    z[6,7,0]  R2268     -5.1767921447753906e-01
    z[6,7,0]  R2269     -8.0138123035430908e-01
    z[6,7,0]  R2270     -6.2069541215896606e-01
    z[6,7,0]  R2271     -6.9655138254165649e-01
    z[6,7,0]  R2272     -0.433408260345459
    z[6,7,1]  R57       -1
    z[6,7,1]  R66       1
    z[6,7,1]  R2151     -1
    z[6,7,1]  R2152     1
    z[6,7,1]  R2163     6.1162346601486206e-01
    z[6,7,1]  R2164     6.8455594778060913e-01
    z[6,7,1]  R2165     5.9001648426055908e-01
    z[6,7,1]  R2166     4.4077399373054504e-01
    z[6,7,1]  R2167     5.4034572839736938e-01
    z[6,7,1]  R2168     8.1180453300476074e-01
    z[6,7,1]  R2169     3.6116382479667664e-01
    z[6,7,1]  R2170     3.5026282072067261e-01
    z[6,7,1]  R2171     3.2761648297309875e-01
    z[6,7,1]  R2172     4.8268094658851624e-01
    z[6,7,1]  R2173     -9.0482914447784424e-01
    z[6,7,1]  R2174     -8.5679125785827637e-01
    z[6,7,1]  R2175     -0.746425211429596
    z[6,7,1]  R2176     -8.7104260921478271e-01
    z[6,7,1]  R2177     -8.7729436159133911e-01
    z[6,7,1]  R2178     -6.8070882558822632e-01
    z[6,7,1]  R2179     -6.4351511001586914e-01
    z[6,7,1]  R2180     -5.6441736221313477e-01
    z[6,7,1]  R2181     -6.4501452445983887e-01
    z[6,7,1]  R2182     -6.6356188058853149e-01
    z[6,7,1]  R2183     5.0011169910430908e-01
    z[6,7,1]  R2184     -4.6965089440345764e-01
    z[6,7,1]  R2185     -1.2971398234367371e-01
    z[6,7,1]  R2186     0.0066000921651721
    z[6,7,1]  R2187     -2.2840197384357452e-01
    z[6,7,1]  R2188     -2.7539052069187164e-02
    z[6,7,1]  R2189     -2.3782984912395477e-01
    z[6,7,1]  R2190     5.2312824875116348e-02
    z[6,7,1]  R2191     6.6013656556606293e-02
    z[6,7,1]  R2192     -2.9741770029067993e-01
    z[6,7,1]  R2193     1.8457408249378204e-01
    z[6,7,1]  R2194     7.5507219880819321e-03
    z[6,7,1]  R2195     2.5539350509643555e-01
    z[6,7,1]  R2196     -5.0007468461990356e-01
    z[6,7,1]  R2197     3.8062937557697296e-02
    z[6,7,1]  R2198     4.4514108449220657e-02
    z[6,7,1]  R2199     5.1867380738258362e-02
    z[6,7,1]  R2200     -1.7568904161453247e-01
    z[6,7,1]  R2201     -8.0612100660800934e-02
    z[6,7,1]  R2202     -1.5621571242809296e-01
    z[6,7,1]  R2203     -7.9453057050704956e-01
    z[6,7,1]  R2204     1.1819142103195190e-01
    z[6,7,1]  R2205     5.6701959110796452e-03
    z[6,7,1]  R2206     0.311960905790329
    z[6,7,1]  R2207     -7.0481783151626587e-01
    z[6,7,1]  R2208     -2.2319043055176735e-02
    z[6,7,1]  R2209     2.4448089301586151e-01
    z[6,7,1]  R2210     -7.0130831003189087e-01
    z[6,7,1]  R2211     6.2961626052856445e-01
    z[6,7,1]  R2212     -5.6727476418018341e-02
    z[6,7,1]  R2213     3.1559771299362183e-01
    z[6,7,1]  R2214     -3.6972990632057190e-01
    z[6,7,1]  R2215     -8.2249885797500610e-01
    z[6,7,1]  R2216     2.7130961418151855e-01
    z[6,7,1]  R2217     1.1103488504886627e-01
    z[6,7,1]  R2218     -2.3097580671310425e-01
    z[6,7,1]  R2219     1.4612478017807007e-01
    z[6,7,1]  R2220     -7.4920791387557983e-01
    z[6,7,1]  R2221     -5.8395504951477051e-01
    z[6,7,1]  R2222     -5.6713259220123291e-01
    z[6,7,1]  R2223     -3.0705565214157104e-01
    z[6,7,1]  R2224     -2.8862020373344421e-01
    z[6,7,1]  R2225     -3.1428337097167969e-01
    z[6,7,1]  R2226     -5.7933073490858078e-02
    z[6,7,1]  R2227     -3.3610008656978607e-02
    z[6,7,1]  R2228     3.1959274411201477e-01
    z[6,7,1]  R2229     -2.2996846586465836e-02
    z[6,7,1]  R2230     3.3017086982727051e-01
    z[6,7,1]  R2231     0.0704321563243866
    z[6,7,1]  R2232     -3.2320499420166016e-01
    z[6,7,1]  R2233     1.7988961935043335e-01
    z[6,7,1]  R2234     -3.7251827120780945e-01
    z[6,7,1]  R2235     6.1022442579269409e-01
    z[6,7,1]  R2236     2.9575297236442566e-01
    z[6,7,1]  R2237     -5.1894748210906982e-01
    z[6,7,1]  R2238     1.8843944370746613e-01
    z[6,7,1]  R2239     -6.2551331520080566e-01
    z[6,7,1]  R2240     -5.5679893493652344e-01
    z[6,7,1]  R2241     4.7060939669609070e-01
    z[6,7,1]  R2242     5.3601270914077759e-01
    z[6,7,1]  R2243     -3.6965838074684143e-01
    z[6,7,1]  R2244     -2.5221002101898193e-01
    z[6,7,1]  R2245     -3.8059008121490479e-01
    z[6,7,1]  R2246     4.7093963623046875e-01
    z[6,7,1]  R2247     -3.5087156295776367e-01
    z[6,7,1]  R2248     -0.725679874420166
    z[6,7,1]  R2249     0.03917246311903
    z[6,7,1]  R2250     4.3120351433753967e-01
    z[6,7,1]  R2251     -6.8598490953445435e-01
    z[6,7,1]  R2252     2.3749579489231110e-01
    z[6,7,1]  R2253     6.6691756248474121e-02
    z[6,7,1]  R2254     0.272235631942749
    z[6,7,1]  R2255     -7.1559256315231323e-01
    z[6,7,1]  R2256     -6.5290480852127075e-01
    z[6,7,1]  R2257     5.5546283721923828e-01
    z[6,7,1]  R2258     2.8597283363342285e-01
    z[6,7,1]  R2259     5.8290684223175049e-01
    z[6,7,1]  R2260     2.6140677928924561e-01
    z[6,7,1]  R2261     4.1217926144599915e-01
    z[6,7,1]  R2262     1.9708883762359619e-01
    z[6,7,1]  R2263     -5.7503420114517212e-01
    z[6,7,1]  R2264     3.0982846021652222e-01
    z[6,7,1]  R2265     2.4864919483661652e-01
    z[6,7,1]  R2266     3.3790227770805359e-01
    z[6,7,1]  R2267     1.3470821082592010e-01
    z[6,7,1]  R2268     3.2616192102432251e-01
    z[6,7,1]  R2269     4.1547946631908417e-02
    z[6,7,1]  R2270     4.6718251705169678e-01
    z[6,7,1]  R2271     3.5333377122879028e-01
    z[6,7,1]  R2272     1.5919558703899384e-01
    z[6,7,2]  R58       -1
    z[6,7,2]  R67       1
    z[6,7,2]  R2153     -1
    z[6,7,2]  R2154     1
    z[6,7,2]  R2163     6.5307760238647461e-01
    z[6,7,2]  R2164     4.8185011744499207e-01
    z[6,7,2]  R2165     5.3949570655822754e-01
    z[6,7,2]  R2166     5.0236654281616211e-01
    z[6,7,2]  R2167     4.2099103331565857e-01
    z[6,7,2]  R2168     3.7018394470214844e-01
    z[6,7,2]  R2169     -5.2113026380538940e-01
    z[6,7,2]  R2170     -4.8376509547233582e-01
    z[6,7,2]  R2171     -7.8418493270874023e-01
    z[6,7,2]  R2172     -8.1867128610610962e-01
    z[6,7,2]  R2173     1.8444927036762238e-01
    z[6,7,2]  R2174     -1.3395757414400578e-02
    z[6,7,2]  R2175     1.6011258959770203e-01
    z[6,7,2]  R2176     -4.8764474689960480e-02
    z[6,7,2]  R2177     -2.2412322461605072e-01
    z[6,7,2]  R2178     6.8242150545120239e-01
    z[6,7,2]  R2179     -2.8009975329041481e-02
    z[6,7,2]  R2180     5.6274402141571045e-01
    z[6,7,2]  R2181     6.0653007030487061e-01
    z[6,7,2]  R2182     -2.1084873378276825e-01
    z[6,7,2]  R2183     -1.5013836324214935e-01
    z[6,7,2]  R2184     8.1123101711273193e-01
    z[6,7,2]  R2185     -6.7830908298492432e-01
    z[6,7,2]  R2186     5.9358769655227661e-01
    z[6,7,2]  R2187     -7.2841954231262207e-01
    z[6,7,2]  R2188     4.0486451983451843e-01
    z[6,7,2]  R2189     -6.5329098701477051e-01
    z[6,7,2]  R2190     4.2163950204849243e-01
    z[6,7,2]  R2191     1.7427203059196472e-01
    z[6,7,2]  R2192     -5.5641597509384155e-01
    z[6,7,2]  R2193     0.533997118473053
    z[6,7,2]  R2194     -9.4141222536563873e-02
    z[6,7,2]  R2195     -3.4328576922416687e-01
    z[6,7,2]  R2196     7.7171623706817627e-01
    z[6,7,2]  R2197     -6.3166123628616333e-01
    z[6,7,2]  R2198     -4.6719151735305786e-01
    z[6,7,2]  R2199     7.1479961276054382e-02
    z[6,7,2]  R2200     1.4302076399326324e-01
    z[6,7,2]  R2201     3.5709220916032791e-02
    z[6,7,2]  R2202     -6.6773869097232819e-02
    z[6,7,2]  R2203     3.0150640010833740e-01
    z[6,7,2]  R2204     5.7649750262498856e-02
    z[6,7,2]  R2205     2.9062870144844055e-01
    z[6,7,2]  R2206     -1.0436808317899704e-01
    z[6,7,2]  R2207     -1.2822796404361725e-01
    z[6,7,2]  R2208     1.3974268734455109e-01
    z[6,7,2]  R2209     3.3458107709884644e-01
    z[6,7,2]  R2210     -2.1774242818355560e-01
    z[6,7,2]  R2211     -1.1213681101799011e-01
    z[6,7,2]  R2212     -7.5407058000564575e-01
    z[6,7,2]  R2213     -5.7629472017288208e-01
    z[6,7,2]  R2214     8.7407833337783813e-01
    z[6,7,2]  R2215     -3.0261540785431862e-02
    z[6,7,2]  R2216     2.0813831686973572e-01
    z[6,7,2]  R2217     -9.4895833730697632e-01
    z[6,7,2]  R2218     -0.669061005115509
    z[6,7,2]  R2219     -1.8745658919215202e-02
    z[6,7,2]  R2220     1.6331587731838226e-01
    z[6,7,2]  R2221     3.9022177457809448e-02
    z[6,7,2]  R2222     -1.0737180709838867e-01
    z[6,7,2]  R2223     2.0724651217460632e-01
    z[6,7,2]  R2224     1.7899610102176666e-01
    z[6,7,2]  R2225     5.2162384986877441e-01
    z[6,7,2]  R2226     2.8195112943649292e-01
    z[6,7,2]  R2227     4.5889404416084290e-01
    z[6,7,2]  R2228     3.1653431057929993e-01
    z[6,7,2]  R2229     2.6952061057090759e-01
    z[6,7,2]  R2230     1.4117512106895447e-01
    z[6,7,2]  R2231     5.0773864984512329e-01
    z[6,7,2]  R2232     5.8778476715087891e-01
    z[6,7,2]  R2233     -7.6132327318191528e-01
    z[6,7,2]  R2234     -5.3360110521316528e-01
    z[6,7,2]  R2235     -3.5296002030372620e-01
    z[6,7,2]  R2236     -8.2664686441421509e-01
    z[6,7,2]  R2237     -2.3417371511459351e-01
    z[6,7,2]  R2238     -6.4699107408523560e-01
    z[6,7,2]  R2239     -3.6005252599716187e-01
    z[6,7,2]  R2240     -4.4153684377670288e-01
    z[6,7,2]  R2241     -6.7895483970642090e-01
    z[6,7,2]  R2242     -6.8267273902893066e-01
    z[6,7,2]  R2243     1.3164159655570984e-01
    z[6,7,2]  R2244     -1.8416820466518402e-01
    z[6,7,2]  R2245     -4.1128948330879211e-02
    z[6,7,2]  R2246     -2.9217609763145447e-01
    z[6,7,2]  R2247     6.3401895761489868e-01
    z[6,7,2]  R2248     -2.8373596072196960e-01
    z[6,7,2]  R2249     5.9770441055297852e-01
    z[6,7,2]  R2250     7.6240867376327515e-01
    z[6,7,2]  R2251     -5.4313808679580688e-01
    z[6,7,2]  R2252     4.7095847129821777e-01
    z[6,7,2]  R2253     5.4275465011596680e-01
    z[6,7,2]  R2254     5.5356502532958984e-01
    z[6,7,2]  R2255     -1.2465379387140274e-01
    z[6,7,2]  R2256     2.7464056015014648e-01
    z[6,7,2]  R2257     -1.9803625345230103e-01
    z[6,7,2]  R2258     -5.1924180984497070e-01
    z[6,7,2]  R2259     0.0552004911005497
    z[6,7,2]  R2260     -4.9495443701744080e-01
    z[6,7,2]  R2261     -6.0143664479255676e-02
    z[6,7,2]  R2262     -1.7313219606876373e-01
    z[6,7,2]  R2263     3.1601192895323038e-03
    z[6,7,2]  R2264     -0.260611355304718
    z[6,7,2]  R2265     -3.2531660795211792e-01
    z[6,7,2]  R2266     -2.6857241988182068e-02
    z[6,7,2]  R2267     -2.8202858567237854e-01
    z[6,7,2]  R2268     -6.2776988744735718e-01
    z[6,7,2]  R2269     -3.8742101192474365e-01
    z[6,7,2]  R2270     -2.0622909069061279e-01
    z[6,7,2]  R2271     -1.7713381350040436e-01
    z[6,7,2]  R2272     -7.4624830484390259e-01
    z[6,7,3]  R59       -1
    z[6,7,3]  R68       1
    z[6,7,3]  R2155     -1
    z[6,7,3]  R2156     1
    z[6,7,3]  R2163     -1.7735873162746429e-01
    z[6,7,3]  R2164     -7.2166711091995239e-02
    z[6,7,3]  R2165     -3.6421704292297363e-01
    z[6,7,3]  R2166     -1.6406776383519173e-02
    z[6,7,3]  R2167     -3.6862000823020935e-02
    z[6,7,3]  R2168     7.6529145240783691e-02
    z[6,7,3]  R2169     -5.0604915618896484e-01
    z[6,7,3]  R2170     -2.8454324603080750e-01
    z[6,7,3]  R2171     1.4922952651977539e-01
    z[6,7,3]  R2172     2.3323077708482742e-02
    z[6,7,3]  R2173     2.2303119301795959e-01
    z[6,7,3]  R2174     3.0072297900915146e-02
    z[6,7,3]  R2175     -1.5407598018646240e-01
    z[6,7,3]  R2176     -1.4522799849510193e-01
    z[6,7,3]  R2177     -5.2057329565286636e-02
    z[6,7,3]  R2178     4.7645575250498950e-04
    z[6,7,3]  R2179     -1.5810810029506683e-02
    z[6,7,3]  R2180     1.1137538403272629e-01
    z[6,7,3]  R2181     -1.4453551173210144e-01
    z[6,7,3]  R2182     -6.6462743282318115e-01
    z[6,7,3]  R2183     -1.1206272989511490e-01
    z[6,7,3]  R2184     2.1960420906543732e-01
    z[6,7,3]  R2185     2.1484570205211639e-01
    z[6,7,3]  R2186     6.5667057037353516e-01
    z[6,7,3]  R2187     2.0240142941474915e-01
    z[6,7,3]  R2188     4.0234780311584473e-01
    z[6,7,3]  R2189     -3.4329872578382492e-02
    z[6,7,3]  R2190     2.8709346055984497e-01
    z[6,7,3]  R2191     8.9333295822143555e-01
    z[6,7,3]  R2192     2.7548578381538391e-01
    z[6,7,3]  R2193     -1.5493296086788177e-01
    z[6,7,3]  R2194     3.1071117520332336e-01
    z[6,7,3]  R2195     4.4686415791511536e-01
    z[6,7,3]  R2196     -1.8663607537746429e-01
    z[6,7,3]  R2197     3.4587290883064270e-01
    z[6,7,3]  R2198     1.8540048599243164e-01
    z[6,7,3]  R2199     4.5564615726470947e-01
    z[6,7,3]  R2200     3.4619012475013733e-01
    z[6,7,3]  R2201     6.1684612184762955e-02
    z[6,7,3]  R2202     2.7708551287651062e-01
    z[6,7,3]  R2203     2.7882652357220650e-02
    z[6,7,3]  R2204     2.9548335075378418e-01
    z[6,7,3]  R2205     6.4322352409362793e-01
    z[6,7,3]  R2206     0.0772358700633049
    z[6,7,3]  R2207     4.0807634592056274e-01
    z[6,7,3]  R2208     4.4087588787078857e-01
    z[6,7,3]  R2209     8.4481775760650635e-01
    z[6,7,3]  R2210     -1.0306950658559799e-01
    z[6,7,3]  R2211     5.0641906261444092e-01
    z[6,7,3]  R2212     2.6382520794868469e-01
    z[6,7,3]  R2213     -3.1905156373977661e-01
    z[6,7,3]  R2214     -1.2970322370529175e-01
    z[6,7,3]  R2215     2.6195693016052246e-01
    z[6,7,3]  R2216     0.744918942451477
    z[6,7,3]  R2217     1.3488547876477242e-02
    z[6,7,3]  R2218     1.7731359601020813e-01
    z[6,7,3]  R2219     4.5670741796493530e-01
    z[6,7,3]  R2220     -0.512614369392395
    z[6,7,3]  R2221     -4.7568336129188538e-01
    z[6,7,3]  R2222     3.3361083269119263e-01
    z[6,7,3]  R2223     -4.8031413555145264e-01
    z[6,7,3]  R2224     -4.8167547583580017e-01
    z[6,7,3]  R2225     -2.6801425218582153e-01
    z[6,7,3]  R2226     -4.1004654765129089e-01
    z[6,7,3]  R2227     -6.0388511419296265e-01
    z[6,7,3]  R2228     -2.8067409992218018e-01
    z[6,7,3]  R2229     -4.9540349841117859e-01
    z[6,7,3]  R2230     -3.8152632117271423e-01
    z[6,7,3]  R2231     -4.3521329760551453e-01
    z[6,7,3]  R2232     -3.1259214878082275e-01
    z[6,7,3]  R2233     -2.0842069387435913e-01
    z[6,7,3]  R2234     7.6991878449916840e-02
    z[6,7,3]  R2235     -2.0139728486537933e-01
    z[6,7,3]  R2236     -2.1196371316909790e-01
    z[6,7,3]  R2237     -3.4143680334091187e-01
    z[6,7,3]  R2238     5.3754840046167374e-02
    z[6,7,3]  R2239     -4.0010473132133484e-01
    z[6,7,3]  R2240     -2.0684248208999634e-01
    z[6,7,3]  R2241     -1.5529535710811615e-01
    z[6,7,3]  R2242     -0.400115042924881
    z[6,7,3]  R2243     -2.2848808765411377e-01
    z[6,7,3]  R2244     3.6773237586021423e-01
    z[6,7,3]  R2245     4.2737263441085815e-01
    z[6,7,3]  R2246     -6.1520408838987350e-02
    z[6,7,3]  R2247     2.7030378580093384e-01
    z[6,7,3]  R2248     8.7555743753910065e-02
    z[6,7,3]  R2249     3.7424591183662415e-01
    z[6,7,3]  R2250     2.2008639574050903e-01
    z[6,7,3]  R2251     -3.5201869904994965e-02
    z[6,7,3]  R2252     5.2728158235549927e-01
    z[6,7,3]  R2253     1.9264583289623260e-01
    z[6,7,3]  R2254     0.363479882478714
    z[6,7,3]  R2255     -1.4564776420593262e-01
    z[6,7,3]  R2256     2.9199967160820961e-02
    z[6,7,3]  R2257     1.5652735531330109e-01
    z[6,7,3]  R2258     2.9135480523109436e-01
    z[6,7,3]  R2259     -0.456819087266922
    z[6,7,3]  R2260     1.3122244179248810e-01
    z[6,7,3]  R2261     -2.5655302405357361e-01
    z[6,7,3]  R2262     8.1395655870437622e-02
    z[6,7,3]  R2263     7.2092838585376740e-02
    z[6,7,3]  R2264     2.7107727527618408e-01
    z[6,7,3]  R2265     -0.572795033454895
    z[6,7,3]  R2266     -3.0412200838327408e-02
    z[6,7,3]  R2267     8.3591938018798828e-03
    z[6,7,3]  R2268     -6.9421872496604919e-02
    z[6,7,3]  R2269     1.9654719531536102e-01
    z[6,7,3]  R2270     -3.3292144536972046e-01
    z[6,7,3]  R2271     -3.1878107786178589e-01
    z[6,7,3]  R2272     3.1275057792663574e-01
    z[6,7,4]  R60       -1
    z[6,7,4]  R69       1
    z[6,7,4]  R2157     -1
    z[6,7,4]  R2158     1
    z[6,7,4]  R2163     3.0931377410888672e-01
    z[6,7,4]  R2164     -1.0533689707517624e-01
    z[6,7,4]  R2165     -3.9524812251329422e-02
    z[6,7,4]  R2166     -4.2555180191993713e-01
    z[6,7,4]  R2167     1.2045098841190338e-01
    z[6,7,4]  R2168     1.0959753394126892e-01
    z[6,7,4]  R2169     -5.9787888079881668e-02
    z[6,7,4]  R2170     3.0749875307083130e-01
    z[6,7,4]  R2171     5.5037878453731537e-02
    z[6,7,4]  R2172     -1.9136065244674683e-01
    z[6,7,4]  R2173     -2.1240387856960297e-01
    z[6,7,4]  R2174     -1.2740857899188995e-01
    z[6,7,4]  R2175     2.3785457015037537e-01
    z[6,7,4]  R2176     -3.0441511422395706e-02
    z[6,7,4]  R2177     -1.1305811256170273e-01
    z[6,7,4]  R2178     -1.8227986991405487e-01
    z[6,7,4]  R2179     4.3938314914703369e-01
    z[6,7,4]  R2180     -3.6281594634056091e-01
    z[6,7,4]  R2181     1.8025094270706177e-01
    z[6,7,4]  R2182     -7.6935626566410065e-02
    z[6,7,4]  R2183     3.2748109102249146e-01
    z[6,7,4]  R2184     1.4197234809398651e-01
    z[6,7,4]  R2185     -9.6101216971874237e-02
    z[6,7,4]  R2186     -1.2907008826732635e-01
    z[6,7,4]  R2187     -1.4035013318061829e-01
    z[6,7,4]  R2188     -1.7884099856019020e-02
    z[6,7,4]  R2189     3.0120092630386353e-01
    z[6,7,4]  R2190     4.3370419740676880e-01
    z[6,7,4]  R2191     -6.7534692585468292e-02
    z[6,7,4]  R2192     6.7070230841636658e-02
    z[6,7,4]  R2193     -4.2729938030242920e-01
    z[6,7,4]  R2194     3.8238272070884705e-01
    z[6,7,4]  R2195     1.5390522778034210e-01
    z[6,7,4]  R2196     -2.1807695925235748e-01
    z[6,7,4]  R2197     3.8307970762252808e-01
    z[6,7,4]  R2198     5.5730640888214111e-01
    z[6,7,4]  R2199     -1.3726758956909180e-01
    z[6,7,4]  R2200     3.5945403575897217e-01
    z[6,7,4]  R2201     5.9789609909057617e-01
    z[6,7,4]  R2202     3.2487982511520386e-01
    z[6,7,4]  R2203     1.8357923254370689e-02
    z[6,7,4]  R2204     1.6997136175632477e-02
    z[6,7,4]  R2205     2.2530054673552513e-02
    z[6,7,4]  R2206     7.1387737989425659e-02
    z[6,7,4]  R2207     5.3474036976695061e-03
    z[6,7,4]  R2208     -3.0325773358345032e-01
    z[6,7,4]  R2209     2.4515953660011292e-01
    z[6,7,4]  R2210     3.9190939068794250e-01
    z[6,7,4]  R2211     4.7103419899940491e-01
    z[6,7,4]  R2212     3.1757593154907227e-02
    z[6,7,4]  R2213     5.3931981325149536e-01
    z[6,7,4]  R2214     8.1775300204753876e-02
    z[6,7,4]  R2215     2.9924826696515083e-02
    z[6,7,4]  R2216     4.9881532788276672e-02
    z[6,7,4]  R2217     7.0591926574707031e-02
    z[6,7,4]  R2218     3.9975631237030029e-01
    z[6,7,4]  R2219     -3.8714587688446045e-01
    z[6,7,4]  R2220     -3.4964978694915771e-01
    z[6,7,4]  R2221     -3.7415459752082825e-01
    z[6,7,4]  R2222     3.8348725438117981e-01
    z[6,7,4]  R2223     8.7874464690685272e-02
    z[6,7,4]  R2224     3.5320156812667847e-01
    z[6,7,4]  R2225     -3.2460224628448486e-01
    z[6,7,4]  R2226     -4.0323522686958313e-01
    z[6,7,4]  R2227     1.7393016815185547e-01
    z[6,7,4]  R2228     -3.0924916267395020e-01
    z[6,7,4]  R2229     1.0926908254623413e-01
    z[6,7,4]  R2230     8.8773913681507111e-02
    z[6,7,4]  R2231     -2.8755106031894684e-02
    z[6,7,4]  R2232     -1.6142685711383820e-01
    z[6,7,4]  R2233     3.1779095530509949e-01
    z[6,7,4]  R2234     1.5953162312507629e-01
    z[6,7,4]  R2235     4.0994152426719666e-01
    z[6,7,4]  R2236     2.6277068257331848e-01
    z[6,7,4]  R2237     3.6438804864883423e-01
    z[6,7,4]  R2238     3.5763537883758545e-01
    z[6,7,4]  R2239     -3.3435022830963135e-01
    z[6,7,4]  R2240     -1.8709858879446983e-02
    z[6,7,4]  R2241     4.0536764264106750e-01
    z[6,7,4]  R2242     6.1044309288263321e-02
    z[6,7,4]  R2243     2.6593983639031649e-03
    z[6,7,4]  R2244     -1.1096832901239395e-01
    z[6,7,4]  R2245     1.5101220458745956e-02
    z[6,7,4]  R2246     1.2194374948740005e-01
    z[6,7,4]  R2247     4.8820984363555908e-01
    z[6,7,4]  R2248     -4.2239078879356384e-01
    z[6,7,4]  R2249     5.6169879436492920e-01
    z[6,7,4]  R2250     3.9712718129158020e-01
    z[6,7,4]  R2251     3.6685687303543091e-01
    z[6,7,4]  R2252     -4.6688154339790344e-01
    z[6,7,4]  R2253     -3.3766075968742371e-01
    z[6,7,4]  R2254     4.0931606292724609e-01
    z[6,7,4]  R2255     -1.5668226778507233e-01
    z[6,7,4]  R2256     4.1570329666137695e-01
    z[6,7,4]  R2257     -3.7201806902885437e-01
    z[6,7,4]  R2258     -2.8724548220634460e-01
    z[6,7,4]  R2259     -2.8906616568565369e-01
    z[6,7,4]  R2260     -6.1233836412429810e-01
    z[6,7,4]  R2261     -5.2703678607940674e-01
    z[6,7,4]  R2262     3.4525337815284729e-01
    z[6,7,4]  R2263     4.7952342033386230e-01
    z[6,7,4]  R2264     2.0412006974220276e-01
    z[6,7,4]  R2265     1.0598077625036240e-01
    z[6,7,4]  R2266     4.9998083710670471e-01
    z[6,7,4]  R2267     6.3665992021560669e-01
    z[6,7,4]  R2268     -2.5265842676162720e-01
    z[6,7,4]  R2269     -3.5125258564949036e-01
    z[6,7,4]  R2270     6.8694218993186951e-02
    z[6,7,4]  R2271     -3.3508253097534180e-01
    z[6,7,4]  R2272     -2.8536248207092285e-01
    z[6,7,5]  R61       -1
    z[6,7,5]  R70       1
    z[6,7,5]  R2159     -1
    z[6,7,5]  R2160     1
    z[6,7,5]  R2163     -1.4910748600959778e-01
    z[6,7,5]  R2164     2.3642964661121368e-01
    z[6,7,5]  R2165     2.6192072033882141e-01
    z[6,7,5]  R2166     -2.4893982335925102e-02
    z[6,7,5]  R2167     1.1403822153806686e-01
    z[6,7,5]  R2168     -2.0856025815010071e-01
    z[6,7,5]  R2169     4.7178804874420166e-01
    z[6,7,5]  R2170     6.6391664743423462e-01
    z[6,7,5]  R2171     3.8924831151962280e-01
    z[6,7,5]  R2172     1.2152110785245895e-01
    z[6,7,5]  R2173     2.1437183022499084e-02
    z[6,7,5]  R2174     1.3909088075160980e-01
    z[6,7,5]  R2175     1.1812205612659454e-01
    z[6,7,5]  R2176     3.7348988652229309e-01
    z[6,7,5]  R2177     -2.3512698709964752e-01
    z[6,7,5]  R2178     -4.9178179353475571e-02
    z[6,7,5]  R2179     -1.8666283786296844e-01
    z[6,7,5]  R2180     4.4221282005310059e-01
    z[6,7,5]  R2181     -2.4498255550861359e-01
    z[6,7,5]  R2182     -1.5540733933448792e-01
    z[6,7,5]  R2183     -1.5384857356548309e-01
    z[6,7,5]  R2184     1.3855701684951782e-01
    z[6,7,5]  R2185     -2.4059610068798065e-01
    z[6,7,5]  R2186     -2.6186150312423706e-01
    z[6,7,5]  R2187     -2.3836867511272430e-01
    z[6,7,5]  R2188     7.9744279384613037e-01
    z[6,7,5]  R2189     -2.9433470964431763e-01
    z[6,7,5]  R2190     7.2514837980270386e-01
    z[6,7,5]  R2191     3.7951439619064331e-01
    z[6,7,5]  R2192     -3.2458725571632385e-01
    z[6,7,5]  R2193     -4.4477206468582153e-01
    z[6,7,5]  R2194     -8.5610244423151016e-03
    z[6,7,5]  R2195     4.2908897995948792e-01
    z[6,7,5]  R2196     0.0865989699959755
    z[6,7,5]  R2197     -6.7275352776050568e-02
    z[6,7,5]  R2198     -3.2819861173629761e-01
    z[6,7,5]  R2199     7.9767984151840210e-01
    z[6,7,5]  R2200     3.5359352827072144e-01
    z[6,7,5]  R2201     5.2157509326934814e-01
    z[6,7,5]  R2202     6.2777698040008545e-01
    z[6,7,5]  R2203     -1.5226955711841583e-01
    z[6,7,5]  R2204     2.4852935969829559e-01
    z[6,7,5]  R2205     6.4453983306884766e-01
    z[6,7,5]  R2206     8.9482986927032471e-01
    z[6,7,5]  R2207     -2.9989114403724670e-01
    z[6,7,5]  R2208     6.8360632658004761e-01
    z[6,7,5]  R2209     2.0597076416015625e-01
    z[6,7,5]  R2210     5.3643468767404556e-02
    z[6,7,5]  R2211     3.2350286841392517e-01
    z[6,7,5]  R2212     7.4796602129936218e-02
    z[6,7,5]  R2213     -8.3849526941776276e-02
    z[6,7,5]  R2214     -1.0466530919075012e-01
    z[6,7,5]  R2215     -1.0526506602764130e-01
    z[6,7,5]  R2216     5.5378687381744385e-01
    z[6,7,5]  R2217     -4.9198679625988007e-02
    z[6,7,5]  R2218     2.0749524235725403e-01
    z[6,7,5]  R2219     4.2804643511772156e-01
    z[6,7,5]  R2220     3.4910753369331360e-02
    z[6,7,5]  R2221     -3.4486436843872070e-01
    z[6,7,5]  R2222     -1.7774419859051704e-02
    z[6,7,5]  R2223     -8.0768600106239319e-02
    z[6,7,5]  R2224     -1.6285438835620880e-01
    z[6,7,5]  R2225     -2.9461956024169922e-01
    z[6,7,5]  R2226     -2.1792963147163391e-02
    z[6,7,5]  R2227     1.6106051206588745e-01
    z[6,7,5]  R2228     0.0692526325583458
    z[6,7,5]  R2229     5.6930035352706909e-02
    z[6,7,5]  R2230     1.6846823692321777e-01
    z[6,7,5]  R2231     2.3168951272964478e-01
    z[6,7,5]  R2232     -5.8971758931875229e-02
    z[6,7,5]  R2233     3.5116624832153320e-01
    z[6,7,5]  R2234     2.9393658041954041e-01
    z[6,7,5]  R2235     2.3688310384750366e-01
    z[6,7,5]  R2236     -1.3653612695634365e-02
    z[6,7,5]  R2237     5.2769124507904053e-01
    z[6,7,5]  R2238     2.6400020718574524e-01
    z[6,7,5]  R2239     3.3163699507713318e-01
    z[6,7,5]  R2240     5.2961331605911255e-01
    z[6,7,5]  R2241     6.6605731844902039e-02
    z[6,7,5]  R2242     8.5524007678031921e-02
    z[6,7,5]  R2243     6.4090877771377563e-02
    z[6,7,5]  R2244     6.0757702589035034e-01
    z[6,7,5]  R2245     -3.4068447351455688e-01
    z[6,7,5]  R2246     -1.6942915320396423e-01
    z[6,7,5]  R2247     2.3075174540281296e-02
    z[6,7,5]  R2248     -3.7522771954536438e-01
    z[6,7,5]  R2249     -3.6397096514701843e-01
    z[6,7,5]  R2250     -8.1869758665561676e-02
    z[6,7,5]  R2251     -1.8982832133769989e-01
    z[6,7,5]  R2252     -3.0167052149772644e-01
    z[6,7,5]  R2253     -4.3691787123680115e-01
    z[6,7,5]  R2254     -2.5596013665199280e-01
    z[6,7,5]  R2255     -2.6717826724052429e-01
    z[6,7,5]  R2256     -4.5564821362495422e-01
    z[6,7,5]  R2257     1.3876450061798096e-01
    z[6,7,5]  R2258     3.7094980478286743e-01
    z[6,7,5]  R2259     1.8450053036212921e-01
    z[6,7,5]  R2260     -1.0467682778835297e-01
    z[6,7,5]  R2261     -2.1239361166954041e-01
    z[6,7,5]  R2262     -6.9543474912643433e-01
    z[6,7,5]  R2263     3.3586883544921875e-01
    z[6,7,5]  R2264     0.0529618114233017
    z[6,7,5]  R2265     2.0456415414810181e-01
    z[6,7,5]  R2266     -4.4151566922664642e-02
    z[6,7,5]  R2267     -2.0282618701457977e-01
    z[6,7,5]  R2268     4.1765943169593811e-02
    z[6,7,5]  R2269     2.0831583440303802e-01
    z[6,7,5]  R2270     -4.6064084768295288e-01
    z[6,7,5]  R2271     -1.2476217746734619e-01
    z[6,7,5]  R2272     -1.6402420401573181e-01
    z[6,7,6]  R62       -1
    z[6,7,6]  R71       1
    z[6,7,6]  R2161     -1
    z[6,7,6]  R2162     1
    z[6,7,6]  R2163     -2.1032159030437469e-01
    z[6,7,6]  R2164     -3.0687007308006287e-01
    z[6,7,6]  R2165     -7.9074859619140625e-02
    z[6,7,6]  R2166     -0.459751695394516
    z[6,7,6]  R2167     5.9187906980514526e-01
    z[6,7,6]  R2168     1.7832185328006744e-01
    z[6,7,6]  R2169     -2.1022546291351318e-01
    z[6,7,6]  R2170     1.0699690319597721e-02
    z[6,7,6]  R2171     -2.9689574241638184e-01
    z[6,7,6]  R2172     1.1398231983184814e-01
    z[6,7,6]  R2173     1.2032502889633179e-01
    z[6,7,6]  R2174     -3.2397669553756714e-01
    z[6,7,6]  R2175     -2.7706235647201538e-01
    z[6,7,6]  R2176     1.0287478566169739e-01
    z[6,7,6]  R2177     3.5452261567115784e-02
    z[6,7,6]  R2178     -1.4815139770507812e-01
    z[6,7,6]  R2179     -4.4864334166049957e-02
    z[6,7,6]  R2180     6.7343883216381073e-02
    z[6,7,6]  R2181     -1.1576295830309391e-02
    z[6,7,6]  R2182     1.3387800753116608e-01
    z[6,7,6]  R2183     2.2807975113391876e-01
    z[6,7,6]  R2184     9.1220222413539886e-02
    z[6,7,6]  R2185     -3.4824568033218384e-01
    z[6,7,6]  R2186     3.2301548123359680e-01
    z[6,7,6]  R2187     0.0875079482793808
    z[6,7,6]  R2188     -1.8640391528606415e-01
    z[6,7,6]  R2189     0.0978948324918747
    z[6,7,6]  R2190     3.7448275834321976e-02
    z[6,7,6]  R2191     1.1275637149810791e-01
    z[6,7,6]  R2192     -7.7837914228439331e-02
    z[6,7,6]  R2193     2.3740540444850922e-01
    z[6,7,6]  R2194     0.249008908867836
    z[6,7,6]  R2195     4.6054357290267944e-01
    z[6,7,6]  R2196     -2.5394740700721741e-01
    z[6,7,6]  R2197     5.9621725231409073e-02
    z[6,7,6]  R2198     -2.0486259460449219e-01
    z[6,7,6]  R2199     2.6581510901451111e-01
    z[6,7,6]  R2200     -2.0385244488716125e-01
    z[6,7,6]  R2201     -2.6578944921493530e-01
    z[6,7,6]  R2202     3.9920575916767120e-02
    z[6,7,6]  R2203     -2.9724302887916565e-01
    z[6,7,6]  R2204     -6.5363639593124390e-01
    z[6,7,6]  R2205     -0.0299916360527277
    z[6,7,6]  R2206     7.6696924865245819e-02
    z[6,7,6]  R2207     -1.8340897560119629e-01
    z[6,7,6]  R2208     1.6833055019378662e-01
    z[6,7,6]  R2209     -4.9545396119356155e-02
    z[6,7,6]  R2210     1.6663007438182831e-01
    z[6,7,6]  R2211     -9.1901179403066635e-03
    z[6,7,6]  R2212     0.555742084980011
    z[6,7,6]  R2213     3.7111893296241760e-01
    z[6,7,6]  R2214     -2.0795795321464539e-01
    z[6,7,6]  R2215     -1.8203240633010864e-01
    z[6,7,6]  R2216     0.0779573991894722
    z[6,7,6]  R2217     8.7144345045089722e-02
    z[6,7,6]  R2218     -1.1840105056762695e-01
    z[6,7,6]  R2219     1.4177146553993225e-01
    z[6,7,6]  R2220     -1.5528991818428040e-01
    z[6,7,6]  R2221     -4.0459185838699341e-01
    z[6,7,6]  R2222     5.0039076805114746e-01
    z[6,7,6]  R2223     4.7823827713727951e-02
    z[6,7,6]  R2224     -6.2529936432838440e-02
    z[6,7,6]  R2225     -4.7796273231506348e-01
    z[6,7,6]  R2226     -2.0951466262340546e-01
    z[6,7,6]  R2227     -3.5356923937797546e-01
    z[6,7,6]  R2228     -3.3737120032310486e-01
    z[6,7,6]  R2229     -6.3296043872833252e-01
    z[6,7,6]  R2230     -8.9385047554969788e-02
    z[6,7,6]  R2231     2.7495065331459045e-01
    z[6,7,6]  R2232     5.3487294912338257e-01
    z[6,7,6]  R2233     -7.2296082973480225e-02
    z[6,7,6]  R2234     -3.8550171256065369e-01
    z[6,7,6]  R2235     -2.4102674424648285e-01
    z[6,7,6]  R2236     1.3702000677585602e-01
    z[6,7,6]  R2237     2.4131065234541893e-02
    z[6,7,6]  R2238     -4.7467836737632751e-01
    z[6,7,6]  R2239     -4.0130499750375748e-02
    z[6,7,6]  R2240     -1.9770424067974091e-01
    z[6,7,6]  R2241     -2.9647165536880493e-01
    z[6,7,6]  R2242     -1.2091419100761414e-01
    z[6,7,6]  R2243     4.9655269831418991e-03
    z[6,7,6]  R2244     2.6535043120384216e-01
    z[6,7,6]  R2245     4.5243373513221741e-01
    z[6,7,6]  R2246     5.9318149089813232e-01
    z[6,7,6]  R2247     1.0646731406450272e-01
    z[6,7,6]  R2248     -1.5190860629081726e-01
    z[6,7,6]  R2249     1.9037947058677673e-01
    z[6,7,6]  R2250     7.2091028094291687e-02
    z[6,7,6]  R2251     1.9828733801841736e-01
    z[6,7,6]  R2252     3.3240351080894470e-01
    z[6,7,6]  R2253     9.5755398273468018e-02
    z[6,7,6]  R2254     -4.4632163643836975e-01
    z[6,7,6]  R2255     4.3559619784355164e-01
    z[6,7,6]  R2256     0.0672859326004982
    z[6,7,6]  R2257     1.2623533606529236e-01
    z[6,7,6]  R2258     -0.137685626745224
    z[6,7,6]  R2259     1.8307086825370789e-01
    z[6,7,6]  R2260     -1.0838644206523895e-01
    z[6,7,6]  R2261     -1.8706727027893066e-01
    z[6,7,6]  R2262     -7.7225610613822937e-02
    z[6,7,6]  R2263     -3.8787248730659485e-01
    z[6,7,6]  R2264     -3.2745647430419922e-01
    z[6,7,6]  R2265     1.2571661174297333e-01
    z[6,7,6]  R2266     -2.2624506056308746e-01
    z[6,7,6]  R2267     1.6531706787645817e-03
    z[6,7,6]  R2268     4.0141192078590393e-01
    z[6,7,6]  R2269     2.3709567263722420e-02
    z[6,7,6]  R2270     1.6186979413032532e-01
    z[6,7,6]  R2271     -0.359343558549881
    z[6,7,6]  R2272     -1.5420430898666382e-01
    z[7,6,0]  R56       1
    z[7,6,0]  R65       -1
    z[7,6,0]  R2273     -1
    z[7,6,0]  R2274     1
    z[7,6,0]  R2287     7.8455817699432373e-01
    z[7,6,0]  R2288     0.70531165599823
    z[7,6,0]  R2289     3.6971229314804077e-01
    z[7,6,0]  R2290     7.3623317480087280e-01
    z[7,6,0]  R2291     0.49234738945961
    z[7,6,0]  R2292     7.1037894487380981e-01
    z[7,6,0]  R2293     0.515349805355072
    z[7,6,0]  R2294     8.2537406682968140e-01
    z[7,6,0]  R2295     6.4631688594818115e-01
    z[7,6,0]  R2296     3.6974081397056580e-01
    z[7,6,0]  R2297     -3.3919322490692139e-01
    z[7,6,0]  R2298     -5.5687659978866577e-01
    z[7,6,0]  R2299     -4.2452904582023621e-01
    z[7,6,0]  R2300     -3.1023699045181274e-01
    z[7,6,0]  R2301     -3.8400274515151978e-01
    z[7,6,0]  R2302     -3.4653279185295105e-01
    z[7,6,0]  R2303     -3.0923759937286377e-01
    z[7,6,0]  R2304     -3.6374312639236450e-01
    z[7,6,0]  R2305     -1.9177055358886719e-01
    z[7,6,0]  R2306     -2.4676986038684845e-01
    z[7,6,0]  R2307     -8.8863778114318848e-01
    z[7,6,0]  R2308     -5.6157851219177246e-01
    z[7,6,0]  R2309     -5.9145748615264893e-01
    z[7,6,0]  R2310     -5.4187035560607910e-01
    z[7,6,0]  R2311     -3.8939476013183594e-01
    z[7,6,0]  R2312     -2.0719681680202484e-01
    z[7,6,0]  R2313     -1.3011586666107178e-01
    z[7,6,0]  R2314     -1.2144438177347183e-01
    z[7,6,0]  R2315     -1.5247924625873566e-01
    z[7,6,0]  R2316     -1.5586009621620178e-01
    z[7,6,0]  R2317     5.9141874313354492e-01
    z[7,6,0]  R2318     2.3468628525733948e-01
    z[7,6,0]  R2319     -4.0681409835815430e-01
    z[7,6,0]  R2320     -3.3538538217544556e-01
    z[7,6,0]  R2321     -6.7390900850296021e-01
    z[7,6,0]  R2322     -0.569779634475708
    z[7,6,0]  R2323     -5.4532033205032349e-01
    z[7,6,0]  R2324     -5.2134835720062256e-01
    z[7,6,0]  R2325     -6.3466411828994751e-01
    z[7,6,0]  R2326     -5.6192767620086670e-01
    z[7,6,0]  R2327     -4.1344010829925537e-01
    z[7,6,0]  R2328     -7.8160566091537476e-01
    z[7,6,0]  R2329     -6.5982228517532349e-01
    z[7,6,0]  R2330     -7.6227217912673950e-01
    z[7,6,0]  R2331     -6.7510491609573364e-01
    z[7,6,0]  R2332     -5.1767921447753906e-01
    z[7,6,0]  R2333     -8.0138123035430908e-01
    z[7,6,0]  R2334     -6.2069541215896606e-01
    z[7,6,0]  R2335     -6.9655138254165649e-01
    z[7,6,0]  R2336     -0.433408260345459
    z[7,6,0]  R2337     7.6203301548957825e-02
    z[7,6,0]  R2338     3.6446052789688110e-01
    z[7,6,0]  R2339     3.8955527544021606e-01
    z[7,6,0]  R2340     3.9998903870582581e-01
    z[7,6,0]  R2341     3.8935866951942444e-01
    z[7,6,0]  R2342     3.3282566070556641e-01
    z[7,6,0]  R2343     -2.6747867465019226e-01
    z[7,6,0]  R2344     -1.6391228139400482e-01
    z[7,6,0]  R2345     -1.1296674609184265e-01
    z[7,6,0]  R2346     -1.7853356897830963e-01
    z[7,6,0]  R2347     -1.9356290996074677e-01
    z[7,6,0]  R2348     -3.5254049301147461e-01
    z[7,6,0]  R2349     -4.9616798758506775e-01
    z[7,6,0]  R2350     -2.5847837328910828e-01
    z[7,6,0]  R2351     -3.2877001166343689e-01
    z[7,6,0]  R2352     -1.1551152169704437e-01
    z[7,6,0]  R2353     -5.9576874971389771e-01
    z[7,6,0]  R2354     1.4361375570297241e-01
    z[7,6,0]  R2355     -3.2022818922996521e-01
    z[7,6,0]  R2356     -1.5970276296138763e-01
    z[7,6,0]  R2357     -7.2928392887115479e-01
    z[7,6,0]  R2358     -1.5947078168392181e-01
    z[7,6,0]  R2359     5.3713631629943848e-01
    z[7,6,0]  R2360     1.6378110647201538e-01
    z[7,6,0]  R2361     5.4045879840850830e-01
    z[7,6,0]  R2362     4.9611806869506836e-02
    z[7,6,0]  R2363     5.7317632436752319e-01
    z[7,6,0]  R2364     -1.4737339317798615e-01
    z[7,6,0]  R2365     0.0769510343670845
    z[7,6,0]  R2366     6.4041984081268311e-01
    z[7,6,0]  R2367     4.6904885768890381e-01
    z[7,6,0]  R2368     -8.2839828729629517e-01
    z[7,6,0]  R2369     -4.4422608613967896e-01
    z[7,6,0]  R2370     -8.6739659309387207e-05
    z[7,6,0]  R2371     5.7017225027084351e-01
    z[7,6,0]  R2372     -5.3395098447799683e-01
    z[7,6,0]  R2373     2.4247437715530396e-01
    z[7,6,0]  R2374     7.3009556531906128e-01
    z[7,6,0]  R2375     5.3689581155776978e-01
    z[7,6,0]  R2376     6.2699037790298462e-01
    z[7,6,0]  R2377     -4.0640029311180115e-01
    z[7,6,0]  R2378     -6.3726031780242920e-01
    z[7,6,0]  R2379     2.9142358899116516e-01
    z[7,6,0]  R2380     2.7225577831268311e-01
    z[7,6,0]  R2381     -4.4346490502357483e-01
    z[7,6,0]  R2382     4.4495406746864319e-01
    z[7,6,0]  R2383     -9.7905941307544708e-02
    z[7,6,0]  R2384     -5.1565051078796387e-01
    z[7,6,0]  R2385     -0.0890880599617958
    z[7,6,0]  R2386     2.0761384069919586e-01
    z[7,6,0]  R2387     -1.7567798495292664e-01
    z[7,6,0]  R2388     -1.4688614010810852e-01
    z[7,6,0]  R2389     -4.5699721574783325e-01
    z[7,6,0]  R2390     1.1366516351699829e-01
    z[7,6,0]  R2391     0.268271267414093
    z[7,6,0]  R2392     5.0068873167037964e-01
    z[7,6,0]  R2393     6.4537554979324341e-01
    z[7,6,0]  R2394     -4.0659990161657333e-02
    z[7,6,0]  R2395     -9.2636190354824066e-02
    z[7,6,0]  R2396     -3.9719808101654053e-01
    z[7,6,1]  R57       1
    z[7,6,1]  R66       -1
    z[7,6,1]  R2275     -1
    z[7,6,1]  R2276     1
    z[7,6,1]  R2287     -3.0705565214157104e-01
    z[7,6,1]  R2288     -2.8862020373344421e-01
    z[7,6,1]  R2289     -3.1428337097167969e-01
    z[7,6,1]  R2290     -5.7933073490858078e-02
    z[7,6,1]  R2291     -3.3610008656978607e-02
    z[7,6,1]  R2292     3.1959274411201477e-01
    z[7,6,1]  R2293     -2.2996846586465836e-02
    z[7,6,1]  R2294     3.3017086982727051e-01
    z[7,6,1]  R2295     0.0704321563243866
    z[7,6,1]  R2296     -3.2320499420166016e-01
    z[7,6,1]  R2297     1.7988961935043335e-01
    z[7,6,1]  R2298     -3.7251827120780945e-01
    z[7,6,1]  R2299     6.1022442579269409e-01
    z[7,6,1]  R2300     2.9575297236442566e-01
    z[7,6,1]  R2301     -5.1894748210906982e-01
    z[7,6,1]  R2302     1.8843944370746613e-01
    z[7,6,1]  R2303     -6.2551331520080566e-01
    z[7,6,1]  R2304     -5.5679893493652344e-01
    z[7,6,1]  R2305     4.7060939669609070e-01
    z[7,6,1]  R2306     5.3601270914077759e-01
    z[7,6,1]  R2307     -3.6965838074684143e-01
    z[7,6,1]  R2308     -2.5221002101898193e-01
    z[7,6,1]  R2309     -3.8059008121490479e-01
    z[7,6,1]  R2310     4.7093963623046875e-01
    z[7,6,1]  R2311     -3.5087156295776367e-01
    z[7,6,1]  R2312     -0.725679874420166
    z[7,6,1]  R2313     0.03917246311903
    z[7,6,1]  R2314     4.3120351433753967e-01
    z[7,6,1]  R2315     -6.8598490953445435e-01
    z[7,6,1]  R2316     2.3749579489231110e-01
    z[7,6,1]  R2317     6.6691756248474121e-02
    z[7,6,1]  R2318     0.272235631942749
    z[7,6,1]  R2319     -7.1559256315231323e-01
    z[7,6,1]  R2320     -6.5290480852127075e-01
    z[7,6,1]  R2321     5.5546283721923828e-01
    z[7,6,1]  R2322     2.8597283363342285e-01
    z[7,6,1]  R2323     5.8290684223175049e-01
    z[7,6,1]  R2324     2.6140677928924561e-01
    z[7,6,1]  R2325     4.1217926144599915e-01
    z[7,6,1]  R2326     1.9708883762359619e-01
    z[7,6,1]  R2327     -5.7503420114517212e-01
    z[7,6,1]  R2328     3.0982846021652222e-01
    z[7,6,1]  R2329     2.4864919483661652e-01
    z[7,6,1]  R2330     3.3790227770805359e-01
    z[7,6,1]  R2331     1.3470821082592010e-01
    z[7,6,1]  R2332     3.2616192102432251e-01
    z[7,6,1]  R2333     4.1547946631908417e-02
    z[7,6,1]  R2334     4.6718251705169678e-01
    z[7,6,1]  R2335     3.5333377122879028e-01
    z[7,6,1]  R2336     1.5919558703899384e-01
    z[7,6,1]  R2337     6.1162346601486206e-01
    z[7,6,1]  R2338     6.8455594778060913e-01
    z[7,6,1]  R2339     5.9001648426055908e-01
    z[7,6,1]  R2340     4.4077399373054504e-01
    z[7,6,1]  R2341     5.4034572839736938e-01
    z[7,6,1]  R2342     8.1180453300476074e-01
    z[7,6,1]  R2343     3.6116382479667664e-01
    z[7,6,1]  R2344     3.5026282072067261e-01
    z[7,6,1]  R2345     3.2761648297309875e-01
    z[7,6,1]  R2346     4.8268094658851624e-01
    z[7,6,1]  R2347     -9.0482914447784424e-01
    z[7,6,1]  R2348     -8.5679125785827637e-01
    z[7,6,1]  R2349     -0.746425211429596
    z[7,6,1]  R2350     -8.7104260921478271e-01
    z[7,6,1]  R2351     -8.7729436159133911e-01
    z[7,6,1]  R2352     -6.8070882558822632e-01
    z[7,6,1]  R2353     -6.4351511001586914e-01
    z[7,6,1]  R2354     -5.6441736221313477e-01
    z[7,6,1]  R2355     -6.4501452445983887e-01
    z[7,6,1]  R2356     -6.6356188058853149e-01
    z[7,6,1]  R2357     5.0011169910430908e-01
    z[7,6,1]  R2358     -4.6965089440345764e-01
    z[7,6,1]  R2359     -1.2971398234367371e-01
    z[7,6,1]  R2360     0.0066000921651721
    z[7,6,1]  R2361     -2.2840197384357452e-01
    z[7,6,1]  R2362     -2.7539052069187164e-02
    z[7,6,1]  R2363     -2.3782984912395477e-01
    z[7,6,1]  R2364     5.2312824875116348e-02
    z[7,6,1]  R2365     6.6013656556606293e-02
    z[7,6,1]  R2366     -2.9741770029067993e-01
    z[7,6,1]  R2367     1.8457408249378204e-01
    z[7,6,1]  R2368     7.5507219880819321e-03
    z[7,6,1]  R2369     2.5539350509643555e-01
    z[7,6,1]  R2370     -5.0007468461990356e-01
    z[7,6,1]  R2371     3.8062937557697296e-02
    z[7,6,1]  R2372     4.4514108449220657e-02
    z[7,6,1]  R2373     5.1867380738258362e-02
    z[7,6,1]  R2374     -1.7568904161453247e-01
    z[7,6,1]  R2375     -8.0612100660800934e-02
    z[7,6,1]  R2376     -1.5621571242809296e-01
    z[7,6,1]  R2377     -7.9453057050704956e-01
    z[7,6,1]  R2378     1.1819142103195190e-01
    z[7,6,1]  R2379     5.6701959110796452e-03
    z[7,6,1]  R2380     0.311960905790329
    z[7,6,1]  R2381     -7.0481783151626587e-01
    z[7,6,1]  R2382     -2.2319043055176735e-02
    z[7,6,1]  R2383     2.4448089301586151e-01
    z[7,6,1]  R2384     -7.0130831003189087e-01
    z[7,6,1]  R2385     6.2961626052856445e-01
    z[7,6,1]  R2386     -5.6727476418018341e-02
    z[7,6,1]  R2387     3.1559771299362183e-01
    z[7,6,1]  R2388     -3.6972990632057190e-01
    z[7,6,1]  R2389     -8.2249885797500610e-01
    z[7,6,1]  R2390     2.7130961418151855e-01
    z[7,6,1]  R2391     1.1103488504886627e-01
    z[7,6,1]  R2392     -2.3097580671310425e-01
    z[7,6,1]  R2393     1.4612478017807007e-01
    z[7,6,1]  R2394     -7.4920791387557983e-01
    z[7,6,1]  R2395     -5.8395504951477051e-01
    z[7,6,1]  R2396     -5.6713259220123291e-01
    z[7,6,2]  R58       1
    z[7,6,2]  R67       -1
    z[7,6,2]  R2277     -1
    z[7,6,2]  R2278     1
    z[7,6,2]  R2287     2.0724651217460632e-01
    z[7,6,2]  R2288     1.7899610102176666e-01
    z[7,6,2]  R2289     5.2162384986877441e-01
    z[7,6,2]  R2290     2.8195112943649292e-01
    z[7,6,2]  R2291     4.5889404416084290e-01
    z[7,6,2]  R2292     3.1653431057929993e-01
    z[7,6,2]  R2293     2.6952061057090759e-01
    z[7,6,2]  R2294     1.4117512106895447e-01
    z[7,6,2]  R2295     5.0773864984512329e-01
    z[7,6,2]  R2296     5.8778476715087891e-01
    z[7,6,2]  R2297     -7.6132327318191528e-01
    z[7,6,2]  R2298     -5.3360110521316528e-01
    z[7,6,2]  R2299     -3.5296002030372620e-01
    z[7,6,2]  R2300     -8.2664686441421509e-01
    z[7,6,2]  R2301     -2.3417371511459351e-01
    z[7,6,2]  R2302     -6.4699107408523560e-01
    z[7,6,2]  R2303     -3.6005252599716187e-01
    z[7,6,2]  R2304     -4.4153684377670288e-01
    z[7,6,2]  R2305     -6.7895483970642090e-01
    z[7,6,2]  R2306     -6.8267273902893066e-01
    z[7,6,2]  R2307     1.3164159655570984e-01
    z[7,6,2]  R2308     -1.8416820466518402e-01
    z[7,6,2]  R2309     -4.1128948330879211e-02
    z[7,6,2]  R2310     -2.9217609763145447e-01
    z[7,6,2]  R2311     6.3401895761489868e-01
    z[7,6,2]  R2312     -2.8373596072196960e-01
    z[7,6,2]  R2313     5.9770441055297852e-01
    z[7,6,2]  R2314     7.6240867376327515e-01
    z[7,6,2]  R2315     -5.4313808679580688e-01
    z[7,6,2]  R2316     4.7095847129821777e-01
    z[7,6,2]  R2317     5.4275465011596680e-01
    z[7,6,2]  R2318     5.5356502532958984e-01
    z[7,6,2]  R2319     -1.2465379387140274e-01
    z[7,6,2]  R2320     2.7464056015014648e-01
    z[7,6,2]  R2321     -1.9803625345230103e-01
    z[7,6,2]  R2322     -5.1924180984497070e-01
    z[7,6,2]  R2323     0.0552004911005497
    z[7,6,2]  R2324     -4.9495443701744080e-01
    z[7,6,2]  R2325     -6.0143664479255676e-02
    z[7,6,2]  R2326     -1.7313219606876373e-01
    z[7,6,2]  R2327     3.1601192895323038e-03
    z[7,6,2]  R2328     -0.260611355304718
    z[7,6,2]  R2329     -3.2531660795211792e-01
    z[7,6,2]  R2330     -2.6857241988182068e-02
    z[7,6,2]  R2331     -2.8202858567237854e-01
    z[7,6,2]  R2332     -6.2776988744735718e-01
    z[7,6,2]  R2333     -3.8742101192474365e-01
    z[7,6,2]  R2334     -2.0622909069061279e-01
    z[7,6,2]  R2335     -1.7713381350040436e-01
    z[7,6,2]  R2336     -7.4624830484390259e-01
    z[7,6,2]  R2337     6.5307760238647461e-01
    z[7,6,2]  R2338     4.8185011744499207e-01
    z[7,6,2]  R2339     5.3949570655822754e-01
    z[7,6,2]  R2340     5.0236654281616211e-01
    z[7,6,2]  R2341     4.2099103331565857e-01
    z[7,6,2]  R2342     3.7018394470214844e-01
    z[7,6,2]  R2343     -5.2113026380538940e-01
    z[7,6,2]  R2344     -4.8376509547233582e-01
    z[7,6,2]  R2345     -7.8418493270874023e-01
    z[7,6,2]  R2346     -8.1867128610610962e-01
    z[7,6,2]  R2347     1.8444927036762238e-01
    z[7,6,2]  R2348     -1.3395757414400578e-02
    z[7,6,2]  R2349     1.6011258959770203e-01
    z[7,6,2]  R2350     -4.8764474689960480e-02
    z[7,6,2]  R2351     -2.2412322461605072e-01
    z[7,6,2]  R2352     6.8242150545120239e-01
    z[7,6,2]  R2353     -2.8009975329041481e-02
    z[7,6,2]  R2354     5.6274402141571045e-01
    z[7,6,2]  R2355     6.0653007030487061e-01
    z[7,6,2]  R2356     -2.1084873378276825e-01
    z[7,6,2]  R2357     -1.5013836324214935e-01
    z[7,6,2]  R2358     8.1123101711273193e-01
    z[7,6,2]  R2359     -6.7830908298492432e-01
    z[7,6,2]  R2360     5.9358769655227661e-01
    z[7,6,2]  R2361     -7.2841954231262207e-01
    z[7,6,2]  R2362     4.0486451983451843e-01
    z[7,6,2]  R2363     -6.5329098701477051e-01
    z[7,6,2]  R2364     4.2163950204849243e-01
    z[7,6,2]  R2365     1.7427203059196472e-01
    z[7,6,2]  R2366     -5.5641597509384155e-01
    z[7,6,2]  R2367     0.533997118473053
    z[7,6,2]  R2368     -9.4141222536563873e-02
    z[7,6,2]  R2369     -3.4328576922416687e-01
    z[7,6,2]  R2370     7.7171623706817627e-01
    z[7,6,2]  R2371     -6.3166123628616333e-01
    z[7,6,2]  R2372     -4.6719151735305786e-01
    z[7,6,2]  R2373     7.1479961276054382e-02
    z[7,6,2]  R2374     1.4302076399326324e-01
    z[7,6,2]  R2375     3.5709220916032791e-02
    z[7,6,2]  R2376     -6.6773869097232819e-02
    z[7,6,2]  R2377     3.0150640010833740e-01
    z[7,6,2]  R2378     5.7649750262498856e-02
    z[7,6,2]  R2379     2.9062870144844055e-01
    z[7,6,2]  R2380     -1.0436808317899704e-01
    z[7,6,2]  R2381     -1.2822796404361725e-01
    z[7,6,2]  R2382     1.3974268734455109e-01
    z[7,6,2]  R2383     3.3458107709884644e-01
    z[7,6,2]  R2384     -2.1774242818355560e-01
    z[7,6,2]  R2385     -1.1213681101799011e-01
    z[7,6,2]  R2386     -7.5407058000564575e-01
    z[7,6,2]  R2387     -5.7629472017288208e-01
    z[7,6,2]  R2388     8.7407833337783813e-01
    z[7,6,2]  R2389     -3.0261540785431862e-02
    z[7,6,2]  R2390     2.0813831686973572e-01
    z[7,6,2]  R2391     -9.4895833730697632e-01
    z[7,6,2]  R2392     -0.669061005115509
    z[7,6,2]  R2393     -1.8745658919215202e-02
    z[7,6,2]  R2394     1.6331587731838226e-01
    z[7,6,2]  R2395     3.9022177457809448e-02
    z[7,6,2]  R2396     -1.0737180709838867e-01
    z[7,6,3]  R59       1
    z[7,6,3]  R68       -1
    z[7,6,3]  R2279     -1
    z[7,6,3]  R2280     1
    z[7,6,3]  R2287     -4.8031413555145264e-01
    z[7,6,3]  R2288     -4.8167547583580017e-01
    z[7,6,3]  R2289     -2.6801425218582153e-01
    z[7,6,3]  R2290     -4.1004654765129089e-01
    z[7,6,3]  R2291     -6.0388511419296265e-01
    z[7,6,3]  R2292     -2.8067409992218018e-01
    z[7,6,3]  R2293     -4.9540349841117859e-01
    z[7,6,3]  R2294     -3.8152632117271423e-01
    z[7,6,3]  R2295     -4.3521329760551453e-01
    z[7,6,3]  R2296     -3.1259214878082275e-01
    z[7,6,3]  R2297     -2.0842069387435913e-01
    z[7,6,3]  R2298     7.6991878449916840e-02
    z[7,6,3]  R2299     -2.0139728486537933e-01
    z[7,6,3]  R2300     -2.1196371316909790e-01
    z[7,6,3]  R2301     -3.4143680334091187e-01
    z[7,6,3]  R2302     5.3754840046167374e-02
    z[7,6,3]  R2303     -4.0010473132133484e-01
    z[7,6,3]  R2304     -2.0684248208999634e-01
    z[7,6,3]  R2305     -1.5529535710811615e-01
    z[7,6,3]  R2306     -0.400115042924881
    z[7,6,3]  R2307     -2.2848808765411377e-01
    z[7,6,3]  R2308     3.6773237586021423e-01
    z[7,6,3]  R2309     4.2737263441085815e-01
    z[7,6,3]  R2310     -6.1520408838987350e-02
    z[7,6,3]  R2311     2.7030378580093384e-01
    z[7,6,3]  R2312     8.7555743753910065e-02
    z[7,6,3]  R2313     3.7424591183662415e-01
    z[7,6,3]  R2314     2.2008639574050903e-01
    z[7,6,3]  R2315     -3.5201869904994965e-02
    z[7,6,3]  R2316     5.2728158235549927e-01
    z[7,6,3]  R2317     1.9264583289623260e-01
    z[7,6,3]  R2318     0.363479882478714
    z[7,6,3]  R2319     -1.4564776420593262e-01
    z[7,6,3]  R2320     2.9199967160820961e-02
    z[7,6,3]  R2321     1.5652735531330109e-01
    z[7,6,3]  R2322     2.9135480523109436e-01
    z[7,6,3]  R2323     -0.456819087266922
    z[7,6,3]  R2324     1.3122244179248810e-01
    z[7,6,3]  R2325     -2.5655302405357361e-01
    z[7,6,3]  R2326     8.1395655870437622e-02
    z[7,6,3]  R2327     7.2092838585376740e-02
    z[7,6,3]  R2328     2.7107727527618408e-01
    z[7,6,3]  R2329     -0.572795033454895
    z[7,6,3]  R2330     -3.0412200838327408e-02
    z[7,6,3]  R2331     8.3591938018798828e-03
    z[7,6,3]  R2332     -6.9421872496604919e-02
    z[7,6,3]  R2333     1.9654719531536102e-01
    z[7,6,3]  R2334     -3.3292144536972046e-01
    z[7,6,3]  R2335     -3.1878107786178589e-01
    z[7,6,3]  R2336     3.1275057792663574e-01
    z[7,6,3]  R2337     -1.7735873162746429e-01
    z[7,6,3]  R2338     -7.2166711091995239e-02
    z[7,6,3]  R2339     -3.6421704292297363e-01
    z[7,6,3]  R2340     -1.6406776383519173e-02
    z[7,6,3]  R2341     -3.6862000823020935e-02
    z[7,6,3]  R2342     7.6529145240783691e-02
    z[7,6,3]  R2343     -5.0604915618896484e-01
    z[7,6,3]  R2344     -2.8454324603080750e-01
    z[7,6,3]  R2345     1.4922952651977539e-01
    z[7,6,3]  R2346     2.3323077708482742e-02
    z[7,6,3]  R2347     2.2303119301795959e-01
    z[7,6,3]  R2348     3.0072297900915146e-02
    z[7,6,3]  R2349     -1.5407598018646240e-01
    z[7,6,3]  R2350     -1.4522799849510193e-01
    z[7,6,3]  R2351     -5.2057329565286636e-02
    z[7,6,3]  R2352     4.7645575250498950e-04
    z[7,6,3]  R2353     -1.5810810029506683e-02
    z[7,6,3]  R2354     1.1137538403272629e-01
    z[7,6,3]  R2355     -1.4453551173210144e-01
    z[7,6,3]  R2356     -6.6462743282318115e-01
    z[7,6,3]  R2357     -1.1206272989511490e-01
    z[7,6,3]  R2358     2.1960420906543732e-01
    z[7,6,3]  R2359     2.1484570205211639e-01
    z[7,6,3]  R2360     6.5667057037353516e-01
    z[7,6,3]  R2361     2.0240142941474915e-01
    z[7,6,3]  R2362     4.0234780311584473e-01
    z[7,6,3]  R2363     -3.4329872578382492e-02
    z[7,6,3]  R2364     2.8709346055984497e-01
    z[7,6,3]  R2365     8.9333295822143555e-01
    z[7,6,3]  R2366     2.7548578381538391e-01
    z[7,6,3]  R2367     -1.5493296086788177e-01
    z[7,6,3]  R2368     3.1071117520332336e-01
    z[7,6,3]  R2369     4.4686415791511536e-01
    z[7,6,3]  R2370     -1.8663607537746429e-01
    z[7,6,3]  R2371     3.4587290883064270e-01
    z[7,6,3]  R2372     1.8540048599243164e-01
    z[7,6,3]  R2373     4.5564615726470947e-01
    z[7,6,3]  R2374     3.4619012475013733e-01
    z[7,6,3]  R2375     6.1684612184762955e-02
    z[7,6,3]  R2376     2.7708551287651062e-01
    z[7,6,3]  R2377     2.7882652357220650e-02
    z[7,6,3]  R2378     2.9548335075378418e-01
    z[7,6,3]  R2379     6.4322352409362793e-01
    z[7,6,3]  R2380     0.0772358700633049
    z[7,6,3]  R2381     4.0807634592056274e-01
    z[7,6,3]  R2382     4.4087588787078857e-01
    z[7,6,3]  R2383     8.4481775760650635e-01
    z[7,6,3]  R2384     -1.0306950658559799e-01
    z[7,6,3]  R2385     5.0641906261444092e-01
    z[7,6,3]  R2386     2.6382520794868469e-01
    z[7,6,3]  R2387     -3.1905156373977661e-01
    z[7,6,3]  R2388     -1.2970322370529175e-01
    z[7,6,3]  R2389     2.6195693016052246e-01
    z[7,6,3]  R2390     0.744918942451477
    z[7,6,3]  R2391     1.3488547876477242e-02
    z[7,6,3]  R2392     1.7731359601020813e-01
    z[7,6,3]  R2393     4.5670741796493530e-01
    z[7,6,3]  R2394     -0.512614369392395
    z[7,6,3]  R2395     -4.7568336129188538e-01
    z[7,6,3]  R2396     3.3361083269119263e-01
    z[7,6,4]  R60       1
    z[7,6,4]  R69       -1
    z[7,6,4]  R2281     -1
    z[7,6,4]  R2282     1
    z[7,6,4]  R2287     8.7874464690685272e-02
    z[7,6,4]  R2288     3.5320156812667847e-01
    z[7,6,4]  R2289     -3.2460224628448486e-01
    z[7,6,4]  R2290     -4.0323522686958313e-01
    z[7,6,4]  R2291     1.7393016815185547e-01
    z[7,6,4]  R2292     -3.0924916267395020e-01
    z[7,6,4]  R2293     1.0926908254623413e-01
    z[7,6,4]  R2294     8.8773913681507111e-02
    z[7,6,4]  R2295     -2.8755106031894684e-02
    z[7,6,4]  R2296     -1.6142685711383820e-01
    z[7,6,4]  R2297     3.1779095530509949e-01
    z[7,6,4]  R2298     1.5953162312507629e-01
    z[7,6,4]  R2299     4.0994152426719666e-01
    z[7,6,4]  R2300     2.6277068257331848e-01
    z[7,6,4]  R2301     3.6438804864883423e-01
    z[7,6,4]  R2302     3.5763537883758545e-01
    z[7,6,4]  R2303     -3.3435022830963135e-01
    z[7,6,4]  R2304     -1.8709858879446983e-02
    z[7,6,4]  R2305     4.0536764264106750e-01
    z[7,6,4]  R2306     6.1044309288263321e-02
    z[7,6,4]  R2307     2.6593983639031649e-03
    z[7,6,4]  R2308     -1.1096832901239395e-01
    z[7,6,4]  R2309     1.5101220458745956e-02
    z[7,6,4]  R2310     1.2194374948740005e-01
    z[7,6,4]  R2311     4.8820984363555908e-01
    z[7,6,4]  R2312     -4.2239078879356384e-01
    z[7,6,4]  R2313     5.6169879436492920e-01
    z[7,6,4]  R2314     3.9712718129158020e-01
    z[7,6,4]  R2315     3.6685687303543091e-01
    z[7,6,4]  R2316     -4.6688154339790344e-01
    z[7,6,4]  R2317     -3.3766075968742371e-01
    z[7,6,4]  R2318     4.0931606292724609e-01
    z[7,6,4]  R2319     -1.5668226778507233e-01
    z[7,6,4]  R2320     4.1570329666137695e-01
    z[7,6,4]  R2321     -3.7201806902885437e-01
    z[7,6,4]  R2322     -2.8724548220634460e-01
    z[7,6,4]  R2323     -2.8906616568565369e-01
    z[7,6,4]  R2324     -6.1233836412429810e-01
    z[7,6,4]  R2325     -5.2703678607940674e-01
    z[7,6,4]  R2326     3.4525337815284729e-01
    z[7,6,4]  R2327     4.7952342033386230e-01
    z[7,6,4]  R2328     2.0412006974220276e-01
    z[7,6,4]  R2329     1.0598077625036240e-01
    z[7,6,4]  R2330     4.9998083710670471e-01
    z[7,6,4]  R2331     6.3665992021560669e-01
    z[7,6,4]  R2332     -2.5265842676162720e-01
    z[7,6,4]  R2333     -3.5125258564949036e-01
    z[7,6,4]  R2334     6.8694218993186951e-02
    z[7,6,4]  R2335     -3.3508253097534180e-01
    z[7,6,4]  R2336     -2.8536248207092285e-01
    z[7,6,4]  R2337     3.0931377410888672e-01
    z[7,6,4]  R2338     -1.0533689707517624e-01
    z[7,6,4]  R2339     -3.9524812251329422e-02
    z[7,6,4]  R2340     -4.2555180191993713e-01
    z[7,6,4]  R2341     1.2045098841190338e-01
    z[7,6,4]  R2342     1.0959753394126892e-01
    z[7,6,4]  R2343     -5.9787888079881668e-02
    z[7,6,4]  R2344     3.0749875307083130e-01
    z[7,6,4]  R2345     5.5037878453731537e-02
    z[7,6,4]  R2346     -1.9136065244674683e-01
    z[7,6,4]  R2347     -2.1240387856960297e-01
    z[7,6,4]  R2348     -1.2740857899188995e-01
    z[7,6,4]  R2349     2.3785457015037537e-01
    z[7,6,4]  R2350     -3.0441511422395706e-02
    z[7,6,4]  R2351     -1.1305811256170273e-01
    z[7,6,4]  R2352     -1.8227986991405487e-01
    z[7,6,4]  R2353     4.3938314914703369e-01
    z[7,6,4]  R2354     -3.6281594634056091e-01
    z[7,6,4]  R2355     1.8025094270706177e-01
    z[7,6,4]  R2356     -7.6935626566410065e-02
    z[7,6,4]  R2357     3.2748109102249146e-01
    z[7,6,4]  R2358     1.4197234809398651e-01
    z[7,6,4]  R2359     -9.6101216971874237e-02
    z[7,6,4]  R2360     -1.2907008826732635e-01
    z[7,6,4]  R2361     -1.4035013318061829e-01
    z[7,6,4]  R2362     -1.7884099856019020e-02
    z[7,6,4]  R2363     3.0120092630386353e-01
    z[7,6,4]  R2364     4.3370419740676880e-01
    z[7,6,4]  R2365     -6.7534692585468292e-02
    z[7,6,4]  R2366     6.7070230841636658e-02
    z[7,6,4]  R2367     -4.2729938030242920e-01
    z[7,6,4]  R2368     3.8238272070884705e-01
    z[7,6,4]  R2369     1.5390522778034210e-01
    z[7,6,4]  R2370     -2.1807695925235748e-01
    z[7,6,4]  R2371     3.8307970762252808e-01
    z[7,6,4]  R2372     5.5730640888214111e-01
    z[7,6,4]  R2373     -1.3726758956909180e-01
    z[7,6,4]  R2374     3.5945403575897217e-01
    z[7,6,4]  R2375     5.9789609909057617e-01
    z[7,6,4]  R2376     3.2487982511520386e-01
    z[7,6,4]  R2377     1.8357923254370689e-02
    z[7,6,4]  R2378     1.6997136175632477e-02
    z[7,6,4]  R2379     2.2530054673552513e-02
    z[7,6,4]  R2380     7.1387737989425659e-02
    z[7,6,4]  R2381     5.3474036976695061e-03
    z[7,6,4]  R2382     -3.0325773358345032e-01
    z[7,6,4]  R2383     2.4515953660011292e-01
    z[7,6,4]  R2384     3.9190939068794250e-01
    z[7,6,4]  R2385     4.7103419899940491e-01
    z[7,6,4]  R2386     3.1757593154907227e-02
    z[7,6,4]  R2387     5.3931981325149536e-01
    z[7,6,4]  R2388     8.1775300204753876e-02
    z[7,6,4]  R2389     2.9924826696515083e-02
    z[7,6,4]  R2390     4.9881532788276672e-02
    z[7,6,4]  R2391     7.0591926574707031e-02
    z[7,6,4]  R2392     3.9975631237030029e-01
    z[7,6,4]  R2393     -3.8714587688446045e-01
    z[7,6,4]  R2394     -3.4964978694915771e-01
    z[7,6,4]  R2395     -3.7415459752082825e-01
    z[7,6,4]  R2396     3.8348725438117981e-01
    z[7,6,5]  R61       1
    z[7,6,5]  R70       -1
    z[7,6,5]  R2283     -1
    z[7,6,5]  R2284     1
    z[7,6,5]  R2287     -8.0768600106239319e-02
    z[7,6,5]  R2288     -1.6285438835620880e-01
    z[7,6,5]  R2289     -2.9461956024169922e-01
    z[7,6,5]  R2290     -2.1792963147163391e-02
    z[7,6,5]  R2291     1.6106051206588745e-01
    z[7,6,5]  R2292     0.0692526325583458
    z[7,6,5]  R2293     5.6930035352706909e-02
    z[7,6,5]  R2294     1.6846823692321777e-01
    z[7,6,5]  R2295     2.3168951272964478e-01
    z[7,6,5]  R2296     -5.8971758931875229e-02
    z[7,6,5]  R2297     3.5116624832153320e-01
    z[7,6,5]  R2298     2.9393658041954041e-01
    z[7,6,5]  R2299     2.3688310384750366e-01
    z[7,6,5]  R2300     -1.3653612695634365e-02
    z[7,6,5]  R2301     5.2769124507904053e-01
    z[7,6,5]  R2302     2.6400020718574524e-01
    z[7,6,5]  R2303     3.3163699507713318e-01
    z[7,6,5]  R2304     5.2961331605911255e-01
    z[7,6,5]  R2305     6.6605731844902039e-02
    z[7,6,5]  R2306     8.5524007678031921e-02
    z[7,6,5]  R2307     6.4090877771377563e-02
    z[7,6,5]  R2308     6.0757702589035034e-01
    z[7,6,5]  R2309     -3.4068447351455688e-01
    z[7,6,5]  R2310     -1.6942915320396423e-01
    z[7,6,5]  R2311     2.3075174540281296e-02
    z[7,6,5]  R2312     -3.7522771954536438e-01
    z[7,6,5]  R2313     -3.6397096514701843e-01
    z[7,6,5]  R2314     -8.1869758665561676e-02
    z[7,6,5]  R2315     -1.8982832133769989e-01
    z[7,6,5]  R2316     -3.0167052149772644e-01
    z[7,6,5]  R2317     -4.3691787123680115e-01
    z[7,6,5]  R2318     -2.5596013665199280e-01
    z[7,6,5]  R2319     -2.6717826724052429e-01
    z[7,6,5]  R2320     -4.5564821362495422e-01
    z[7,6,5]  R2321     1.3876450061798096e-01
    z[7,6,5]  R2322     3.7094980478286743e-01
    z[7,6,5]  R2323     1.8450053036212921e-01
    z[7,6,5]  R2324     -1.0467682778835297e-01
    z[7,6,5]  R2325     -2.1239361166954041e-01
    z[7,6,5]  R2326     -6.9543474912643433e-01
    z[7,6,5]  R2327     3.3586883544921875e-01
    z[7,6,5]  R2328     0.0529618114233017
    z[7,6,5]  R2329     2.0456415414810181e-01
    z[7,6,5]  R2330     -4.4151566922664642e-02
    z[7,6,5]  R2331     -2.0282618701457977e-01
    z[7,6,5]  R2332     4.1765943169593811e-02
    z[7,6,5]  R2333     2.0831583440303802e-01
    z[7,6,5]  R2334     -4.6064084768295288e-01
    z[7,6,5]  R2335     -1.2476217746734619e-01
    z[7,6,5]  R2336     -1.6402420401573181e-01
    z[7,6,5]  R2337     -1.4910748600959778e-01
    z[7,6,5]  R2338     2.3642964661121368e-01
    z[7,6,5]  R2339     2.6192072033882141e-01
    z[7,6,5]  R2340     -2.4893982335925102e-02
    z[7,6,5]  R2341     1.1403822153806686e-01
    z[7,6,5]  R2342     -2.0856025815010071e-01
    z[7,6,5]  R2343     4.7178804874420166e-01
    z[7,6,5]  R2344     6.6391664743423462e-01
    z[7,6,5]  R2345     3.8924831151962280e-01
    z[7,6,5]  R2346     1.2152110785245895e-01
    z[7,6,5]  R2347     2.1437183022499084e-02
    z[7,6,5]  R2348     1.3909088075160980e-01
    z[7,6,5]  R2349     1.1812205612659454e-01
    z[7,6,5]  R2350     3.7348988652229309e-01
    z[7,6,5]  R2351     -2.3512698709964752e-01
    z[7,6,5]  R2352     -4.9178179353475571e-02
    z[7,6,5]  R2353     -1.8666283786296844e-01
    z[7,6,5]  R2354     4.4221282005310059e-01
    z[7,6,5]  R2355     -2.4498255550861359e-01
    z[7,6,5]  R2356     -1.5540733933448792e-01
    z[7,6,5]  R2357     -1.5384857356548309e-01
    z[7,6,5]  R2358     1.3855701684951782e-01
    z[7,6,5]  R2359     -2.4059610068798065e-01
    z[7,6,5]  R2360     -2.6186150312423706e-01
    z[7,6,5]  R2361     -2.3836867511272430e-01
    z[7,6,5]  R2362     7.9744279384613037e-01
    z[7,6,5]  R2363     -2.9433470964431763e-01
    z[7,6,5]  R2364     7.2514837980270386e-01
    z[7,6,5]  R2365     3.7951439619064331e-01
    z[7,6,5]  R2366     -3.2458725571632385e-01
    z[7,6,5]  R2367     -4.4477206468582153e-01
    z[7,6,5]  R2368     -8.5610244423151016e-03
    z[7,6,5]  R2369     4.2908897995948792e-01
    z[7,6,5]  R2370     0.0865989699959755
    z[7,6,5]  R2371     -6.7275352776050568e-02
    z[7,6,5]  R2372     -3.2819861173629761e-01
    z[7,6,5]  R2373     7.9767984151840210e-01
    z[7,6,5]  R2374     3.5359352827072144e-01
    z[7,6,5]  R2375     5.2157509326934814e-01
    z[7,6,5]  R2376     6.2777698040008545e-01
    z[7,6,5]  R2377     -1.5226955711841583e-01
    z[7,6,5]  R2378     2.4852935969829559e-01
    z[7,6,5]  R2379     6.4453983306884766e-01
    z[7,6,5]  R2380     8.9482986927032471e-01
    z[7,6,5]  R2381     -2.9989114403724670e-01
    z[7,6,5]  R2382     6.8360632658004761e-01
    z[7,6,5]  R2383     2.0597076416015625e-01
    z[7,6,5]  R2384     5.3643468767404556e-02
    z[7,6,5]  R2385     3.2350286841392517e-01
    z[7,6,5]  R2386     7.4796602129936218e-02
    z[7,6,5]  R2387     -8.3849526941776276e-02
    z[7,6,5]  R2388     -1.0466530919075012e-01
    z[7,6,5]  R2389     -1.0526506602764130e-01
    z[7,6,5]  R2390     5.5378687381744385e-01
    z[7,6,5]  R2391     -4.9198679625988007e-02
    z[7,6,5]  R2392     2.0749524235725403e-01
    z[7,6,5]  R2393     4.2804643511772156e-01
    z[7,6,5]  R2394     3.4910753369331360e-02
    z[7,6,5]  R2395     -3.4486436843872070e-01
    z[7,6,5]  R2396     -1.7774419859051704e-02
    z[7,6,6]  R62       1
    z[7,6,6]  R71       -1
    z[7,6,6]  R2285     -1
    z[7,6,6]  R2286     1
    z[7,6,6]  R2287     4.7823827713727951e-02
    z[7,6,6]  R2288     -6.2529936432838440e-02
    z[7,6,6]  R2289     -4.7796273231506348e-01
    z[7,6,6]  R2290     -2.0951466262340546e-01
    z[7,6,6]  R2291     -3.5356923937797546e-01
    z[7,6,6]  R2292     -3.3737120032310486e-01
    z[7,6,6]  R2293     -6.3296043872833252e-01
    z[7,6,6]  R2294     -8.9385047554969788e-02
    z[7,6,6]  R2295     2.7495065331459045e-01
    z[7,6,6]  R2296     5.3487294912338257e-01
    z[7,6,6]  R2297     -7.2296082973480225e-02
    z[7,6,6]  R2298     -3.8550171256065369e-01
    z[7,6,6]  R2299     -2.4102674424648285e-01
    z[7,6,6]  R2300     1.3702000677585602e-01
    z[7,6,6]  R2301     2.4131065234541893e-02
    z[7,6,6]  R2302     -4.7467836737632751e-01
    z[7,6,6]  R2303     -4.0130499750375748e-02
    z[7,6,6]  R2304     -1.9770424067974091e-01
    z[7,6,6]  R2305     -2.9647165536880493e-01
    z[7,6,6]  R2306     -1.2091419100761414e-01
    z[7,6,6]  R2307     4.9655269831418991e-03
    z[7,6,6]  R2308     2.6535043120384216e-01
    z[7,6,6]  R2309     4.5243373513221741e-01
    z[7,6,6]  R2310     5.9318149089813232e-01
    z[7,6,6]  R2311     1.0646731406450272e-01
    z[7,6,6]  R2312     -1.5190860629081726e-01
    z[7,6,6]  R2313     1.9037947058677673e-01
    z[7,6,6]  R2314     7.2091028094291687e-02
    z[7,6,6]  R2315     1.9828733801841736e-01
    z[7,6,6]  R2316     3.3240351080894470e-01
    z[7,6,6]  R2317     9.5755398273468018e-02
    z[7,6,6]  R2318     -4.4632163643836975e-01
    z[7,6,6]  R2319     4.3559619784355164e-01
    z[7,6,6]  R2320     0.0672859326004982
    z[7,6,6]  R2321     1.2623533606529236e-01
    z[7,6,6]  R2322     -0.137685626745224
    z[7,6,6]  R2323     1.8307086825370789e-01
    z[7,6,6]  R2324     -1.0838644206523895e-01
    z[7,6,6]  R2325     -1.8706727027893066e-01
    z[7,6,6]  R2326     -7.7225610613822937e-02
    z[7,6,6]  R2327     -3.8787248730659485e-01
    z[7,6,6]  R2328     -3.2745647430419922e-01
    z[7,6,6]  R2329     1.2571661174297333e-01
    z[7,6,6]  R2330     -2.2624506056308746e-01
    z[7,6,6]  R2331     1.6531706787645817e-03
    z[7,6,6]  R2332     4.0141192078590393e-01
    z[7,6,6]  R2333     2.3709567263722420e-02
    z[7,6,6]  R2334     1.6186979413032532e-01
    z[7,6,6]  R2335     -0.359343558549881
    z[7,6,6]  R2336     -1.5420430898666382e-01
    z[7,6,6]  R2337     -2.1032159030437469e-01
    z[7,6,6]  R2338     -3.0687007308006287e-01
    z[7,6,6]  R2339     -7.9074859619140625e-02
    z[7,6,6]  R2340     -0.459751695394516
    z[7,6,6]  R2341     5.9187906980514526e-01
    z[7,6,6]  R2342     1.7832185328006744e-01
    z[7,6,6]  R2343     -2.1022546291351318e-01
    z[7,6,6]  R2344     1.0699690319597721e-02
    z[7,6,6]  R2345     -2.9689574241638184e-01
    z[7,6,6]  R2346     1.1398231983184814e-01
    z[7,6,6]  R2347     1.2032502889633179e-01
    z[7,6,6]  R2348     -3.2397669553756714e-01
    z[7,6,6]  R2349     -2.7706235647201538e-01
    z[7,6,6]  R2350     1.0287478566169739e-01
    z[7,6,6]  R2351     3.5452261567115784e-02
    z[7,6,6]  R2352     -1.4815139770507812e-01
    z[7,6,6]  R2353     -4.4864334166049957e-02
    z[7,6,6]  R2354     6.7343883216381073e-02
    z[7,6,6]  R2355     -1.1576295830309391e-02
    z[7,6,6]  R2356     1.3387800753116608e-01
    z[7,6,6]  R2357     2.2807975113391876e-01
    z[7,6,6]  R2358     9.1220222413539886e-02
    z[7,6,6]  R2359     -3.4824568033218384e-01
    z[7,6,6]  R2360     3.2301548123359680e-01
    z[7,6,6]  R2361     0.0875079482793808
    z[7,6,6]  R2362     -1.8640391528606415e-01
    z[7,6,6]  R2363     0.0978948324918747
    z[7,6,6]  R2364     3.7448275834321976e-02
    z[7,6,6]  R2365     1.1275637149810791e-01
    z[7,6,6]  R2366     -7.7837914228439331e-02
    z[7,6,6]  R2367     2.3740540444850922e-01
    z[7,6,6]  R2368     0.249008908867836
    z[7,6,6]  R2369     4.6054357290267944e-01
    z[7,6,6]  R2370     -2.5394740700721741e-01
    z[7,6,6]  R2371     5.9621725231409073e-02
    z[7,6,6]  R2372     -2.0486259460449219e-01
    z[7,6,6]  R2373     2.6581510901451111e-01
    z[7,6,6]  R2374     -2.0385244488716125e-01
    z[7,6,6]  R2375     -2.6578944921493530e-01
    z[7,6,6]  R2376     3.9920575916767120e-02
    z[7,6,6]  R2377     -2.9724302887916565e-01
    z[7,6,6]  R2378     -6.5363639593124390e-01
    z[7,6,6]  R2379     -0.0299916360527277
    z[7,6,6]  R2380     7.6696924865245819e-02
    z[7,6,6]  R2381     -1.8340897560119629e-01
    z[7,6,6]  R2382     1.6833055019378662e-01
    z[7,6,6]  R2383     -4.9545396119356155e-02
    z[7,6,6]  R2384     1.6663007438182831e-01
    z[7,6,6]  R2385     -9.1901179403066635e-03
    z[7,6,6]  R2386     0.555742084980011
    z[7,6,6]  R2387     3.7111893296241760e-01
    z[7,6,6]  R2388     -2.0795795321464539e-01
    z[7,6,6]  R2389     -1.8203240633010864e-01
    z[7,6,6]  R2390     0.0779573991894722
    z[7,6,6]  R2391     8.7144345045089722e-02
    z[7,6,6]  R2392     -1.1840105056762695e-01
    z[7,6,6]  R2393     1.4177146553993225e-01
    z[7,6,6]  R2394     -1.5528991818428040e-01
    z[7,6,6]  R2395     -4.0459185838699341e-01
    z[7,6,6]  R2396     5.0039076805114746e-01
    z[7,8,0]  R65       -1
    z[7,8,0]  R74       1
    z[7,8,0]  R2397     -1
    z[7,8,0]  R2398     1
    z[7,8,0]  R2411     7.8455817699432373e-01
    z[7,8,0]  R2412     0.70531165599823
    z[7,8,0]  R2413     3.6971229314804077e-01
    z[7,8,0]  R2414     7.3623317480087280e-01
    z[7,8,0]  R2415     0.49234738945961
    z[7,8,0]  R2416     7.1037894487380981e-01
    z[7,8,0]  R2417     0.515349805355072
    z[7,8,0]  R2418     8.2537406682968140e-01
    z[7,8,0]  R2419     6.4631688594818115e-01
    z[7,8,0]  R2420     3.6974081397056580e-01
    z[7,8,0]  R2421     -3.3919322490692139e-01
    z[7,8,0]  R2422     -5.5687659978866577e-01
    z[7,8,0]  R2423     -4.2452904582023621e-01
    z[7,8,0]  R2424     -3.1023699045181274e-01
    z[7,8,0]  R2425     -3.8400274515151978e-01
    z[7,8,0]  R2426     -3.4653279185295105e-01
    z[7,8,0]  R2427     -3.0923759937286377e-01
    z[7,8,0]  R2428     -3.6374312639236450e-01
    z[7,8,0]  R2429     -1.9177055358886719e-01
    z[7,8,0]  R2430     -2.4676986038684845e-01
    z[7,8,0]  R2431     -8.8863778114318848e-01
    z[7,8,0]  R2432     -5.6157851219177246e-01
    z[7,8,0]  R2433     -5.9145748615264893e-01
    z[7,8,0]  R2434     -5.4187035560607910e-01
    z[7,8,0]  R2435     -3.8939476013183594e-01
    z[7,8,0]  R2436     -2.0719681680202484e-01
    z[7,8,0]  R2437     -1.3011586666107178e-01
    z[7,8,0]  R2438     -1.2144438177347183e-01
    z[7,8,0]  R2439     -1.5247924625873566e-01
    z[7,8,0]  R2440     -1.5586009621620178e-01
    z[7,8,0]  R2441     5.9141874313354492e-01
    z[7,8,0]  R2442     2.3468628525733948e-01
    z[7,8,0]  R2443     -4.0681409835815430e-01
    z[7,8,0]  R2444     -3.3538538217544556e-01
    z[7,8,0]  R2445     -6.7390900850296021e-01
    z[7,8,0]  R2446     -0.569779634475708
    z[7,8,0]  R2447     -5.4532033205032349e-01
    z[7,8,0]  R2448     -5.2134835720062256e-01
    z[7,8,0]  R2449     -6.3466411828994751e-01
    z[7,8,0]  R2450     -5.6192767620086670e-01
    z[7,8,0]  R2451     -4.1344010829925537e-01
    z[7,8,0]  R2452     -7.8160566091537476e-01
    z[7,8,0]  R2453     -6.5982228517532349e-01
    z[7,8,0]  R2454     -7.6227217912673950e-01
    z[7,8,0]  R2455     -6.7510491609573364e-01
    z[7,8,0]  R2456     -5.1767921447753906e-01
    z[7,8,0]  R2457     -8.0138123035430908e-01
    z[7,8,0]  R2458     -6.2069541215896606e-01
    z[7,8,0]  R2459     -6.9655138254165649e-01
    z[7,8,0]  R2460     -0.433408260345459
    z[7,8,0]  R2461     -1.5072417259216309e-01
    z[7,8,0]  R2462     6.6199767589569092e-01
    z[7,8,0]  R2463     -7.2658807039260864e-02
    z[7,8,0]  R2464     5.0864481925964355e-01
    z[7,8,0]  R2465     2.6525846123695374e-01
    z[7,8,0]  R2466     4.7638800740242004e-01
    z[7,8,0]  R2467     2.1989306807518005e-01
    z[7,8,0]  R2468     -3.5427814722061157e-01
    z[7,8,0]  R2469     -2.0952154695987701e-01
    z[7,8,0]  R2470     -5.5590067058801651e-03
    z[7,8,0]  R2471     -9.3253576755523682e-01
    z[7,8,0]  R2472     -9.0112978219985962e-01
    z[7,8,0]  R2473     -8.7758165597915649e-01
    z[7,8,0]  R2474     1.7205205559730530e-01
    z[7,8,0]  R2475     3.8720494508743286e-01
    z[7,8,0]  R2476     3.7908968329429626e-01
    z[7,8,0]  R2477     2.0732177793979645e-01
    z[7,8,0]  R2478     -6.1520463787019253e-03
    z[7,8,1]  R66       -1
    z[7,8,1]  R75       1
    z[7,8,1]  R2399     -1
    z[7,8,1]  R2400     1
    z[7,8,1]  R2411     -3.0705565214157104e-01
    z[7,8,1]  R2412     -2.8862020373344421e-01
    z[7,8,1]  R2413     -3.1428337097167969e-01
    z[7,8,1]  R2414     -5.7933073490858078e-02
    z[7,8,1]  R2415     -3.3610008656978607e-02
    z[7,8,1]  R2416     3.1959274411201477e-01
    z[7,8,1]  R2417     -2.2996846586465836e-02
    z[7,8,1]  R2418     3.3017086982727051e-01
    z[7,8,1]  R2419     0.0704321563243866
    z[7,8,1]  R2420     -3.2320499420166016e-01
    z[7,8,1]  R2421     1.7988961935043335e-01
    z[7,8,1]  R2422     -3.7251827120780945e-01
    z[7,8,1]  R2423     6.1022442579269409e-01
    z[7,8,1]  R2424     2.9575297236442566e-01
    z[7,8,1]  R2425     -5.1894748210906982e-01
    z[7,8,1]  R2426     1.8843944370746613e-01
    z[7,8,1]  R2427     -6.2551331520080566e-01
    z[7,8,1]  R2428     -5.5679893493652344e-01
    z[7,8,1]  R2429     4.7060939669609070e-01
    z[7,8,1]  R2430     5.3601270914077759e-01
    z[7,8,1]  R2431     -3.6965838074684143e-01
    z[7,8,1]  R2432     -2.5221002101898193e-01
    z[7,8,1]  R2433     -3.8059008121490479e-01
    z[7,8,1]  R2434     4.7093963623046875e-01
    z[7,8,1]  R2435     -3.5087156295776367e-01
    z[7,8,1]  R2436     -0.725679874420166
    z[7,8,1]  R2437     0.03917246311903
    z[7,8,1]  R2438     4.3120351433753967e-01
    z[7,8,1]  R2439     -6.8598490953445435e-01
    z[7,8,1]  R2440     2.3749579489231110e-01
    z[7,8,1]  R2441     6.6691756248474121e-02
    z[7,8,1]  R2442     0.272235631942749
    z[7,8,1]  R2443     -7.1559256315231323e-01
    z[7,8,1]  R2444     -6.5290480852127075e-01
    z[7,8,1]  R2445     5.5546283721923828e-01
    z[7,8,1]  R2446     2.8597283363342285e-01
    z[7,8,1]  R2447     5.8290684223175049e-01
    z[7,8,1]  R2448     2.6140677928924561e-01
    z[7,8,1]  R2449     4.1217926144599915e-01
    z[7,8,1]  R2450     1.9708883762359619e-01
    z[7,8,1]  R2451     -5.7503420114517212e-01
    z[7,8,1]  R2452     3.0982846021652222e-01
    z[7,8,1]  R2453     2.4864919483661652e-01
    z[7,8,1]  R2454     3.3790227770805359e-01
    z[7,8,1]  R2455     1.3470821082592010e-01
    z[7,8,1]  R2456     3.2616192102432251e-01
    z[7,8,1]  R2457     4.1547946631908417e-02
    z[7,8,1]  R2458     4.6718251705169678e-01
    z[7,8,1]  R2459     3.5333377122879028e-01
    z[7,8,1]  R2460     1.5919558703899384e-01
    z[7,8,1]  R2461     4.8109039664268494e-02
    z[7,8,1]  R2462     3.3454573154449463e-01
    z[7,8,1]  R2463     -2.9857018589973450e-01
    z[7,8,1]  R2464     -3.3517763018608093e-01
    z[7,8,1]  R2465     -2.6409623026847839e-01
    z[7,8,1]  R2466     -2.1585391461849213e-01
    z[7,8,1]  R2467     8.9994736015796661e-02
    z[7,8,1]  R2468     4.0385362505912781e-01
    z[7,8,1]  R2469     -8.3998240530490875e-02
    z[7,8,1]  R2470     -3.7127882242202759e-02
    z[7,8,1]  R2471     -2.1206183731555939e-01
    z[7,8,1]  R2472     -1.3824828900396824e-02
    z[7,8,1]  R2473     9.6397131681442261e-02
    z[7,8,1]  R2474     -7.7029550075531006e-01
    z[7,8,1]  R2475     -2.8874117136001587e-01
    z[7,8,1]  R2476     -1.6220785677433014e-01
    z[7,8,1]  R2477     1.3882428407669067e-01
    z[7,8,1]  R2478     0.546604573726654
    z[7,8,2]  R67       -1
    z[7,8,2]  R76       1
    z[7,8,2]  R2401     -1
    z[7,8,2]  R2402     1
    z[7,8,2]  R2411     2.0724651217460632e-01
    z[7,8,2]  R2412     1.7899610102176666e-01
    z[7,8,2]  R2413     5.2162384986877441e-01
    z[7,8,2]  R2414     2.8195112943649292e-01
    z[7,8,2]  R2415     4.5889404416084290e-01
    z[7,8,2]  R2416     3.1653431057929993e-01
    z[7,8,2]  R2417     2.6952061057090759e-01
    z[7,8,2]  R2418     1.4117512106895447e-01
    z[7,8,2]  R2419     5.0773864984512329e-01
    z[7,8,2]  R2420     5.8778476715087891e-01
    z[7,8,2]  R2421     -7.6132327318191528e-01
    z[7,8,2]  R2422     -5.3360110521316528e-01
    z[7,8,2]  R2423     -3.5296002030372620e-01
    z[7,8,2]  R2424     -8.2664686441421509e-01
    z[7,8,2]  R2425     -2.3417371511459351e-01
    z[7,8,2]  R2426     -6.4699107408523560e-01
    z[7,8,2]  R2427     -3.6005252599716187e-01
    z[7,8,2]  R2428     -4.4153684377670288e-01
    z[7,8,2]  R2429     -6.7895483970642090e-01
    z[7,8,2]  R2430     -6.8267273902893066e-01
    z[7,8,2]  R2431     1.3164159655570984e-01
    z[7,8,2]  R2432     -1.8416820466518402e-01
    z[7,8,2]  R2433     -4.1128948330879211e-02
    z[7,8,2]  R2434     -2.9217609763145447e-01
    z[7,8,2]  R2435     6.3401895761489868e-01
    z[7,8,2]  R2436     -2.8373596072196960e-01
    z[7,8,2]  R2437     5.9770441055297852e-01
    z[7,8,2]  R2438     7.6240867376327515e-01
    z[7,8,2]  R2439     -5.4313808679580688e-01
    z[7,8,2]  R2440     4.7095847129821777e-01
    z[7,8,2]  R2441     5.4275465011596680e-01
    z[7,8,2]  R2442     5.5356502532958984e-01
    z[7,8,2]  R2443     -1.2465379387140274e-01
    z[7,8,2]  R2444     2.7464056015014648e-01
    z[7,8,2]  R2445     -1.9803625345230103e-01
    z[7,8,2]  R2446     -5.1924180984497070e-01
    z[7,8,2]  R2447     0.0552004911005497
    z[7,8,2]  R2448     -4.9495443701744080e-01
    z[7,8,2]  R2449     -6.0143664479255676e-02
    z[7,8,2]  R2450     -1.7313219606876373e-01
    z[7,8,2]  R2451     3.1601192895323038e-03
    z[7,8,2]  R2452     -0.260611355304718
    z[7,8,2]  R2453     -3.2531660795211792e-01
    z[7,8,2]  R2454     -2.6857241988182068e-02
    z[7,8,2]  R2455     -2.8202858567237854e-01
    z[7,8,2]  R2456     -6.2776988744735718e-01
    z[7,8,2]  R2457     -3.8742101192474365e-01
    z[7,8,2]  R2458     -2.0622909069061279e-01
    z[7,8,2]  R2459     -1.7713381350040436e-01
    z[7,8,2]  R2460     -7.4624830484390259e-01
    z[7,8,2]  R2461     -2.5834247469902039e-01
    z[7,8,2]  R2462     1.3997702300548553e-01
    z[7,8,2]  R2463     2.3916728794574738e-01
    z[7,8,2]  R2464     -3.2332172989845276e-01
    z[7,8,2]  R2465     1.4474992454051971e-01
    z[7,8,2]  R2466     8.2499951124191284e-02
    z[7,8,2]  R2467     3.6355210468173027e-03
    z[7,8,2]  R2468     3.0835175514221191e-01
    z[7,8,2]  R2469     -0.819757878780365
    z[7,8,2]  R2470     -0.00738651305437088
    z[7,8,2]  R2471     -1.0767484456300735e-01
    z[7,8,2]  R2472     -3.7795655429363251e-02
    z[7,8,2]  R2473     8.5781373083591461e-02
    z[7,8,2]  R2474     -3.0338302254676819e-01
    z[7,8,2]  R2475     -2.7365781366825104e-02
    z[7,8,2]  R2476     -2.1361067891120911e-01
    z[7,8,2]  R2477     -1.2696257233619690e-01
    z[7,8,2]  R2478     -5.8996188640594482e-01
    z[7,8,3]  R68       -1
    z[7,8,3]  R77       1
    z[7,8,3]  R2403     -1
    z[7,8,3]  R2404     1
    z[7,8,3]  R2411     -4.8031413555145264e-01
    z[7,8,3]  R2412     -4.8167547583580017e-01
    z[7,8,3]  R2413     -2.6801425218582153e-01
    z[7,8,3]  R2414     -4.1004654765129089e-01
    z[7,8,3]  R2415     -6.0388511419296265e-01
    z[7,8,3]  R2416     -2.8067409992218018e-01
    z[7,8,3]  R2417     -4.9540349841117859e-01
    z[7,8,3]  R2418     -3.8152632117271423e-01
    z[7,8,3]  R2419     -4.3521329760551453e-01
    z[7,8,3]  R2420     -3.1259214878082275e-01
    z[7,8,3]  R2421     -2.0842069387435913e-01
    z[7,8,3]  R2422     7.6991878449916840e-02
    z[7,8,3]  R2423     -2.0139728486537933e-01
    z[7,8,3]  R2424     -2.1196371316909790e-01
    z[7,8,3]  R2425     -3.4143680334091187e-01
    z[7,8,3]  R2426     5.3754840046167374e-02
    z[7,8,3]  R2427     -4.0010473132133484e-01
    z[7,8,3]  R2428     -2.0684248208999634e-01
    z[7,8,3]  R2429     -1.5529535710811615e-01
    z[7,8,3]  R2430     -0.400115042924881
    z[7,8,3]  R2431     -2.2848808765411377e-01
    z[7,8,3]  R2432     3.6773237586021423e-01
    z[7,8,3]  R2433     4.2737263441085815e-01
    z[7,8,3]  R2434     -6.1520408838987350e-02
    z[7,8,3]  R2435     2.7030378580093384e-01
    z[7,8,3]  R2436     8.7555743753910065e-02
    z[7,8,3]  R2437     3.7424591183662415e-01
    z[7,8,3]  R2438     2.2008639574050903e-01
    z[7,8,3]  R2439     -3.5201869904994965e-02
    z[7,8,3]  R2440     5.2728158235549927e-01
    z[7,8,3]  R2441     1.9264583289623260e-01
    z[7,8,3]  R2442     0.363479882478714
    z[7,8,3]  R2443     -1.4564776420593262e-01
    z[7,8,3]  R2444     2.9199967160820961e-02
    z[7,8,3]  R2445     1.5652735531330109e-01
    z[7,8,3]  R2446     2.9135480523109436e-01
    z[7,8,3]  R2447     -0.456819087266922
    z[7,8,3]  R2448     1.3122244179248810e-01
    z[7,8,3]  R2449     -2.5655302405357361e-01
    z[7,8,3]  R2450     8.1395655870437622e-02
    z[7,8,3]  R2451     7.2092838585376740e-02
    z[7,8,3]  R2452     2.7107727527618408e-01
    z[7,8,3]  R2453     -0.572795033454895
    z[7,8,3]  R2454     -3.0412200838327408e-02
    z[7,8,3]  R2455     8.3591938018798828e-03
    z[7,8,3]  R2456     -6.9421872496604919e-02
    z[7,8,3]  R2457     1.9654719531536102e-01
    z[7,8,3]  R2458     -3.3292144536972046e-01
    z[7,8,3]  R2459     -3.1878107786178589e-01
    z[7,8,3]  R2460     3.1275057792663574e-01
    z[7,8,3]  R2461     -7.6885324716567993e-01
    z[7,8,3]  R2462     -5.7068192958831787e-01
    z[7,8,3]  R2463     -0.821049153804779
    z[7,8,3]  R2464     -7.8540176153182983e-02
    z[7,8,3]  R2465     -5.6368821859359741e-01
    z[7,8,3]  R2466     -3.5935062170028687e-01
    z[7,8,3]  R2467     -2.0003998279571533e-01
    z[7,8,3]  R2468     7.6669089496135712e-02
    z[7,8,3]  R2469     1.6064124181866646e-02
    z[7,8,3]  R2470     1.5017512440681458e-01
    z[7,8,3]  R2471     1.1551170796155930e-01
    z[7,8,3]  R2472     1.5412843227386475e-01
    z[7,8,3]  R2473     -5.8783199638128281e-02
    z[7,8,3]  R2474     1.8461252748966217e-01
    z[7,8,3]  R2475     1.6735152900218964e-01
    z[7,8,3]  R2476     2.1953256428241730e-01
    z[7,8,3]  R2477     1.6128091514110565e-01
    z[7,8,3]  R2478     1.0005152225494385e-01
    z[7,8,4]  R69       -1
    z[7,8,4]  R78       1
    z[7,8,4]  R2405     -1
    z[7,8,4]  R2406     1
    z[7,8,4]  R2411     8.7874464690685272e-02
    z[7,8,4]  R2412     3.5320156812667847e-01
    z[7,8,4]  R2413     -3.2460224628448486e-01
    z[7,8,4]  R2414     -4.0323522686958313e-01
    z[7,8,4]  R2415     1.7393016815185547e-01
    z[7,8,4]  R2416     -3.0924916267395020e-01
    z[7,8,4]  R2417     1.0926908254623413e-01
    z[7,8,4]  R2418     8.8773913681507111e-02
    z[7,8,4]  R2419     -2.8755106031894684e-02
    z[7,8,4]  R2420     -1.6142685711383820e-01
    z[7,8,4]  R2421     3.1779095530509949e-01
    z[7,8,4]  R2422     1.5953162312507629e-01
    z[7,8,4]  R2423     4.0994152426719666e-01
    z[7,8,4]  R2424     2.6277068257331848e-01
    z[7,8,4]  R2425     3.6438804864883423e-01
    z[7,8,4]  R2426     3.5763537883758545e-01
    z[7,8,4]  R2427     -3.3435022830963135e-01
    z[7,8,4]  R2428     -1.8709858879446983e-02
    z[7,8,4]  R2429     4.0536764264106750e-01
    z[7,8,4]  R2430     6.1044309288263321e-02
    z[7,8,4]  R2431     2.6593983639031649e-03
    z[7,8,4]  R2432     -1.1096832901239395e-01
    z[7,8,4]  R2433     1.5101220458745956e-02
    z[7,8,4]  R2434     1.2194374948740005e-01
    z[7,8,4]  R2435     4.8820984363555908e-01
    z[7,8,4]  R2436     -4.2239078879356384e-01
    z[7,8,4]  R2437     5.6169879436492920e-01
    z[7,8,4]  R2438     3.9712718129158020e-01
    z[7,8,4]  R2439     3.6685687303543091e-01
    z[7,8,4]  R2440     -4.6688154339790344e-01
    z[7,8,4]  R2441     -3.3766075968742371e-01
    z[7,8,4]  R2442     4.0931606292724609e-01
    z[7,8,4]  R2443     -1.5668226778507233e-01
    z[7,8,4]  R2444     4.1570329666137695e-01
    z[7,8,4]  R2445     -3.7201806902885437e-01
    z[7,8,4]  R2446     -2.8724548220634460e-01
    z[7,8,4]  R2447     -2.8906616568565369e-01
    z[7,8,4]  R2448     -6.1233836412429810e-01
    z[7,8,4]  R2449     -5.2703678607940674e-01
    z[7,8,4]  R2450     3.4525337815284729e-01
    z[7,8,4]  R2451     4.7952342033386230e-01
    z[7,8,4]  R2452     2.0412006974220276e-01
    z[7,8,4]  R2453     1.0598077625036240e-01
    z[7,8,4]  R2454     4.9998083710670471e-01
    z[7,8,4]  R2455     6.3665992021560669e-01
    z[7,8,4]  R2456     -2.5265842676162720e-01
    z[7,8,4]  R2457     -3.5125258564949036e-01
    z[7,8,4]  R2458     6.8694218993186951e-02
    z[7,8,4]  R2459     -3.3508253097534180e-01
    z[7,8,4]  R2460     -2.8536248207092285e-01
    z[7,8,4]  R2461     -4.7893619537353516e-01
    z[7,8,4]  R2462     -3.2204318046569824e-01
    z[7,8,4]  R2463     -1.1985452473163605e-01
    z[7,8,4]  R2464     3.0569615960121155e-01
    z[7,8,4]  R2465     2.8516548871994019e-01
    z[7,8,4]  R2466     4.9322074651718140e-01
    z[7,8,4]  R2467     8.5074788331985474e-01
    z[7,8,4]  R2468     -4.2093902826309204e-02
    z[7,8,4]  R2469     2.4484671652317047e-01
    z[7,8,4]  R2470     -1.6202388331294060e-02
    z[7,8,4]  R2471     1.9603946805000305e-01
    z[7,8,4]  R2472     1.0144042782485485e-02
    z[7,8,4]  R2473     3.8448280096054077e-01
    z[7,8,4]  R2474     0.0856412723660469
    z[7,8,4]  R2475     1.8914036452770233e-01
    z[7,8,4]  R2476     1.9557043910026550e-01
    z[7,8,4]  R2477     3.2393044233322144e-01
    z[7,8,4]  R2478     1.2204378843307495e-01
    z[7,8,5]  R70       -1
    z[7,8,5]  R79       1
    z[7,8,5]  R2407     -1
    z[7,8,5]  R2408     1
    z[7,8,5]  R2411     -8.0768600106239319e-02
    z[7,8,5]  R2412     -1.6285438835620880e-01
    z[7,8,5]  R2413     -2.9461956024169922e-01
    z[7,8,5]  R2414     -2.1792963147163391e-02
    z[7,8,5]  R2415     1.6106051206588745e-01
    z[7,8,5]  R2416     0.0692526325583458
    z[7,8,5]  R2417     5.6930035352706909e-02
    z[7,8,5]  R2418     1.6846823692321777e-01
    z[7,8,5]  R2419     2.3168951272964478e-01
    z[7,8,5]  R2420     -5.8971758931875229e-02
    z[7,8,5]  R2421     3.5116624832153320e-01
    z[7,8,5]  R2422     2.9393658041954041e-01
    z[7,8,5]  R2423     2.3688310384750366e-01
    z[7,8,5]  R2424     -1.3653612695634365e-02
    z[7,8,5]  R2425     5.2769124507904053e-01
    z[7,8,5]  R2426     2.6400020718574524e-01
    z[7,8,5]  R2427     3.3163699507713318e-01
    z[7,8,5]  R2428     5.2961331605911255e-01
    z[7,8,5]  R2429     6.6605731844902039e-02
    z[7,8,5]  R2430     8.5524007678031921e-02
    z[7,8,5]  R2431     6.4090877771377563e-02
    z[7,8,5]  R2432     6.0757702589035034e-01
    z[7,8,5]  R2433     -3.4068447351455688e-01
    z[7,8,5]  R2434     -1.6942915320396423e-01
    z[7,8,5]  R2435     2.3075174540281296e-02
    z[7,8,5]  R2436     -3.7522771954536438e-01
    z[7,8,5]  R2437     -3.6397096514701843e-01
    z[7,8,5]  R2438     -8.1869758665561676e-02
    z[7,8,5]  R2439     -1.8982832133769989e-01
    z[7,8,5]  R2440     -3.0167052149772644e-01
    z[7,8,5]  R2441     -4.3691787123680115e-01
    z[7,8,5]  R2442     -2.5596013665199280e-01
    z[7,8,5]  R2443     -2.6717826724052429e-01
    z[7,8,5]  R2444     -4.5564821362495422e-01
    z[7,8,5]  R2445     1.3876450061798096e-01
    z[7,8,5]  R2446     3.7094980478286743e-01
    z[7,8,5]  R2447     1.8450053036212921e-01
    z[7,8,5]  R2448     -1.0467682778835297e-01
    z[7,8,5]  R2449     -2.1239361166954041e-01
    z[7,8,5]  R2450     -6.9543474912643433e-01
    z[7,8,5]  R2451     3.3586883544921875e-01
    z[7,8,5]  R2452     0.0529618114233017
    z[7,8,5]  R2453     2.0456415414810181e-01
    z[7,8,5]  R2454     -4.4151566922664642e-02
    z[7,8,5]  R2455     -2.0282618701457977e-01
    z[7,8,5]  R2456     4.1765943169593811e-02
    z[7,8,5]  R2457     2.0831583440303802e-01
    z[7,8,5]  R2458     -4.6064084768295288e-01
    z[7,8,5]  R2459     -1.2476217746734619e-01
    z[7,8,5]  R2460     -1.6402420401573181e-01
    z[7,8,5]  R2461     -1.3279798626899719e-01
    z[7,8,5]  R2462     1.5413187444210052e-02
    z[7,8,5]  R2463     -7.6223835349082947e-02
    z[7,8,5]  R2464     -1.9351997971534729e-01
    z[7,8,5]  R2465     -0.581364095211029
    z[7,8,5]  R2466     0.388720840215683
    z[7,8,5]  R2467     -1.1550952494144440e-01
    z[7,8,5]  R2468     -7.7131915092468262e-01
    z[7,8,5]  R2469     4.2888391017913818e-01
    z[7,8,5]  R2470     -9.8720449209213257e-01
    z[7,8,5]  R2471     -1.4730840921401978e-01
    z[7,8,5]  R2472     3.9859893918037415e-01
    z[7,8,5]  R2473     2.4619343876838684e-01
    z[7,8,5]  R2474     4.8062625527381897e-01
    z[7,8,5]  R2475     8.2773292064666748e-01
    z[7,8,5]  R2476     7.4844104051589966e-01
    z[7,8,5]  R2477     0.447476863861084
    z[7,8,5]  R2478     -6.6538691520690918e-02
    z[7,8,6]  R71       -1
    z[7,8,6]  R80       1
    z[7,8,6]  R2409     -1
    z[7,8,6]  R2410     1
    z[7,8,6]  R2411     4.7823827713727951e-02
    z[7,8,6]  R2412     -6.2529936432838440e-02
    z[7,8,6]  R2413     -4.7796273231506348e-01
    z[7,8,6]  R2414     -2.0951466262340546e-01
    z[7,8,6]  R2415     -3.5356923937797546e-01
    z[7,8,6]  R2416     -3.3737120032310486e-01
    z[7,8,6]  R2417     -6.3296043872833252e-01
    z[7,8,6]  R2418     -8.9385047554969788e-02
    z[7,8,6]  R2419     2.7495065331459045e-01
    z[7,8,6]  R2420     5.3487294912338257e-01
    z[7,8,6]  R2421     -7.2296082973480225e-02
    z[7,8,6]  R2422     -3.8550171256065369e-01
    z[7,8,6]  R2423     -2.4102674424648285e-01
    z[7,8,6]  R2424     1.3702000677585602e-01
    z[7,8,6]  R2425     2.4131065234541893e-02
    z[7,8,6]  R2426     -4.7467836737632751e-01
    z[7,8,6]  R2427     -4.0130499750375748e-02
    z[7,8,6]  R2428     -1.9770424067974091e-01
    z[7,8,6]  R2429     -2.9647165536880493e-01
    z[7,8,6]  R2430     -1.2091419100761414e-01
    z[7,8,6]  R2431     4.9655269831418991e-03
    z[7,8,6]  R2432     2.6535043120384216e-01
    z[7,8,6]  R2433     4.5243373513221741e-01
    z[7,8,6]  R2434     5.9318149089813232e-01
    z[7,8,6]  R2435     1.0646731406450272e-01
    z[7,8,6]  R2436     -1.5190860629081726e-01
    z[7,8,6]  R2437     1.9037947058677673e-01
    z[7,8,6]  R2438     7.2091028094291687e-02
    z[7,8,6]  R2439     1.9828733801841736e-01
    z[7,8,6]  R2440     3.3240351080894470e-01
    z[7,8,6]  R2441     9.5755398273468018e-02
    z[7,8,6]  R2442     -4.4632163643836975e-01
    z[7,8,6]  R2443     4.3559619784355164e-01
    z[7,8,6]  R2444     0.0672859326004982
    z[7,8,6]  R2445     1.2623533606529236e-01
    z[7,8,6]  R2446     -0.137685626745224
    z[7,8,6]  R2447     1.8307086825370789e-01
    z[7,8,6]  R2448     -1.0838644206523895e-01
    z[7,8,6]  R2449     -1.8706727027893066e-01
    z[7,8,6]  R2450     -7.7225610613822937e-02
    z[7,8,6]  R2451     -3.8787248730659485e-01
    z[7,8,6]  R2452     -3.2745647430419922e-01
    z[7,8,6]  R2453     1.2571661174297333e-01
    z[7,8,6]  R2454     -2.2624506056308746e-01
    z[7,8,6]  R2455     1.6531706787645817e-03
    z[7,8,6]  R2456     4.0141192078590393e-01
    z[7,8,6]  R2457     2.3709567263722420e-02
    z[7,8,6]  R2458     1.6186979413032532e-01
    z[7,8,6]  R2459     -0.359343558549881
    z[7,8,6]  R2460     -1.5420430898666382e-01
    z[7,8,6]  R2461     -2.6471960544586182e-01
    z[7,8,6]  R2462     -2.4849440902471542e-02
    z[7,8,6]  R2463     3.9252853393554688e-01
    z[7,8,6]  R2464     -6.2235909700393677e-01
    z[7,8,6]  R2465     -3.1920313835144043e-01
    z[7,8,6]  R2466     -4.4289040565490723e-01
    z[7,8,6]  R2467     -4.0792697668075562e-01
    z[7,8,6]  R2468     1.1715488135814667e-01
    z[7,8,6]  R2469     1.8136323988437653e-01
    z[7,8,6]  R2470     -3.3886294811964035e-02
    z[7,8,6]  R2471     -1.8405759707093239e-02
    z[7,8,6]  R2472     6.0048587620258331e-02
    z[7,8,6]  R2473     -3.6136958748102188e-02
    z[7,8,6]  R2474     1.1217761784791946e-01
    z[7,8,6]  R2475     1.3049735128879547e-01
    z[7,8,6]  R2476     0.371138334274292
    z[7,8,6]  R2477     0.768406093120575
    z[7,8,6]  R2478     0.569032609462738
    z[8,7,0]  R65       1
    z[8,7,0]  R74       -1
    z[8,7,0]  R2479     -1
    z[8,7,0]  R2480     1
    z[8,7,0]  R2493     -1.5072417259216309e-01
    z[8,7,0]  R2494     6.6199767589569092e-01
    z[8,7,0]  R2495     -7.2658807039260864e-02
    z[8,7,0]  R2496     5.0864481925964355e-01
    z[8,7,0]  R2497     2.6525846123695374e-01
    z[8,7,0]  R2498     4.7638800740242004e-01
    z[8,7,0]  R2499     2.1989306807518005e-01
    z[8,7,0]  R2500     -3.5427814722061157e-01
    z[8,7,0]  R2501     -2.0952154695987701e-01
    z[8,7,0]  R2502     -5.5590067058801651e-03
    z[8,7,0]  R2503     -9.3253576755523682e-01
    z[8,7,0]  R2504     -9.0112978219985962e-01
    z[8,7,0]  R2505     -8.7758165597915649e-01
    z[8,7,0]  R2506     1.7205205559730530e-01
    z[8,7,0]  R2507     3.8720494508743286e-01
    z[8,7,0]  R2508     3.7908968329429626e-01
    z[8,7,0]  R2509     2.0732177793979645e-01
    z[8,7,0]  R2510     -6.1520463787019253e-03
    z[8,7,0]  R2511     7.8455817699432373e-01
    z[8,7,0]  R2512     0.70531165599823
    z[8,7,0]  R2513     3.6971229314804077e-01
    z[8,7,0]  R2514     7.3623317480087280e-01
    z[8,7,0]  R2515     0.49234738945961
    z[8,7,0]  R2516     7.1037894487380981e-01
    z[8,7,0]  R2517     0.515349805355072
    z[8,7,0]  R2518     8.2537406682968140e-01
    z[8,7,0]  R2519     6.4631688594818115e-01
    z[8,7,0]  R2520     3.6974081397056580e-01
    z[8,7,0]  R2521     -3.3919322490692139e-01
    z[8,7,0]  R2522     -5.5687659978866577e-01
    z[8,7,0]  R2523     -4.2452904582023621e-01
    z[8,7,0]  R2524     -3.1023699045181274e-01
    z[8,7,0]  R2525     -3.8400274515151978e-01
    z[8,7,0]  R2526     -3.4653279185295105e-01
    z[8,7,0]  R2527     -3.0923759937286377e-01
    z[8,7,0]  R2528     -3.6374312639236450e-01
    z[8,7,0]  R2529     -1.9177055358886719e-01
    z[8,7,0]  R2530     -2.4676986038684845e-01
    z[8,7,0]  R2531     -8.8863778114318848e-01
    z[8,7,0]  R2532     -5.6157851219177246e-01
    z[8,7,0]  R2533     -5.9145748615264893e-01
    z[8,7,0]  R2534     -5.4187035560607910e-01
    z[8,7,0]  R2535     -3.8939476013183594e-01
    z[8,7,0]  R2536     -2.0719681680202484e-01
    z[8,7,0]  R2537     -1.3011586666107178e-01
    z[8,7,0]  R2538     -1.2144438177347183e-01
    z[8,7,0]  R2539     -1.5247924625873566e-01
    z[8,7,0]  R2540     -1.5586009621620178e-01
    z[8,7,0]  R2541     5.9141874313354492e-01
    z[8,7,0]  R2542     2.3468628525733948e-01
    z[8,7,0]  R2543     -4.0681409835815430e-01
    z[8,7,0]  R2544     -3.3538538217544556e-01
    z[8,7,0]  R2545     -6.7390900850296021e-01
    z[8,7,0]  R2546     -0.569779634475708
    z[8,7,0]  R2547     -5.4532033205032349e-01
    z[8,7,0]  R2548     -5.2134835720062256e-01
    z[8,7,0]  R2549     -6.3466411828994751e-01
    z[8,7,0]  R2550     -5.6192767620086670e-01
    z[8,7,0]  R2551     -4.1344010829925537e-01
    z[8,7,0]  R2552     -7.8160566091537476e-01
    z[8,7,0]  R2553     -6.5982228517532349e-01
    z[8,7,0]  R2554     -7.6227217912673950e-01
    z[8,7,0]  R2555     -6.7510491609573364e-01
    z[8,7,0]  R2556     -5.1767921447753906e-01
    z[8,7,0]  R2557     -8.0138123035430908e-01
    z[8,7,0]  R2558     -6.2069541215896606e-01
    z[8,7,0]  R2559     -6.9655138254165649e-01
    z[8,7,0]  R2560     -0.433408260345459
    z[8,7,1]  R66       1
    z[8,7,1]  R75       -1
    z[8,7,1]  R2481     -1
    z[8,7,1]  R2482     1
    z[8,7,1]  R2493     4.8109039664268494e-02
    z[8,7,1]  R2494     3.3454573154449463e-01
    z[8,7,1]  R2495     -2.9857018589973450e-01
    z[8,7,1]  R2496     -3.3517763018608093e-01
    z[8,7,1]  R2497     -2.6409623026847839e-01
    z[8,7,1]  R2498     -2.1585391461849213e-01
    z[8,7,1]  R2499     8.9994736015796661e-02
    z[8,7,1]  R2500     4.0385362505912781e-01
    z[8,7,1]  R2501     -8.3998240530490875e-02
    z[8,7,1]  R2502     -3.7127882242202759e-02
    z[8,7,1]  R2503     -2.1206183731555939e-01
    z[8,7,1]  R2504     -1.3824828900396824e-02
    z[8,7,1]  R2505     9.6397131681442261e-02
    z[8,7,1]  R2506     -7.7029550075531006e-01
    z[8,7,1]  R2507     -2.8874117136001587e-01
    z[8,7,1]  R2508     -1.6220785677433014e-01
    z[8,7,1]  R2509     1.3882428407669067e-01
    z[8,7,1]  R2510     0.546604573726654
    z[8,7,1]  R2511     -3.0705565214157104e-01
    z[8,7,1]  R2512     -2.8862020373344421e-01
    z[8,7,1]  R2513     -3.1428337097167969e-01
    z[8,7,1]  R2514     -5.7933073490858078e-02
    z[8,7,1]  R2515     -3.3610008656978607e-02
    z[8,7,1]  R2516     3.1959274411201477e-01
    z[8,7,1]  R2517     -2.2996846586465836e-02
    z[8,7,1]  R2518     3.3017086982727051e-01
    z[8,7,1]  R2519     0.0704321563243866
    z[8,7,1]  R2520     -3.2320499420166016e-01
    z[8,7,1]  R2521     1.7988961935043335e-01
    z[8,7,1]  R2522     -3.7251827120780945e-01
    z[8,7,1]  R2523     6.1022442579269409e-01
    z[8,7,1]  R2524     2.9575297236442566e-01
    z[8,7,1]  R2525     -5.1894748210906982e-01
    z[8,7,1]  R2526     1.8843944370746613e-01
    z[8,7,1]  R2527     -6.2551331520080566e-01
    z[8,7,1]  R2528     -5.5679893493652344e-01
    z[8,7,1]  R2529     4.7060939669609070e-01
    z[8,7,1]  R2530     5.3601270914077759e-01
    z[8,7,1]  R2531     -3.6965838074684143e-01
    z[8,7,1]  R2532     -2.5221002101898193e-01
    z[8,7,1]  R2533     -3.8059008121490479e-01
    z[8,7,1]  R2534     4.7093963623046875e-01
    z[8,7,1]  R2535     -3.5087156295776367e-01
    z[8,7,1]  R2536     -0.725679874420166
    z[8,7,1]  R2537     0.03917246311903
    z[8,7,1]  R2538     4.3120351433753967e-01
    z[8,7,1]  R2539     -6.8598490953445435e-01
    z[8,7,1]  R2540     2.3749579489231110e-01
    z[8,7,1]  R2541     6.6691756248474121e-02
    z[8,7,1]  R2542     0.272235631942749
    z[8,7,1]  R2543     -7.1559256315231323e-01
    z[8,7,1]  R2544     -6.5290480852127075e-01
    z[8,7,1]  R2545     5.5546283721923828e-01
    z[8,7,1]  R2546     2.8597283363342285e-01
    z[8,7,1]  R2547     5.8290684223175049e-01
    z[8,7,1]  R2548     2.6140677928924561e-01
    z[8,7,1]  R2549     4.1217926144599915e-01
    z[8,7,1]  R2550     1.9708883762359619e-01
    z[8,7,1]  R2551     -5.7503420114517212e-01
    z[8,7,1]  R2552     3.0982846021652222e-01
    z[8,7,1]  R2553     2.4864919483661652e-01
    z[8,7,1]  R2554     3.3790227770805359e-01
    z[8,7,1]  R2555     1.3470821082592010e-01
    z[8,7,1]  R2556     3.2616192102432251e-01
    z[8,7,1]  R2557     4.1547946631908417e-02
    z[8,7,1]  R2558     4.6718251705169678e-01
    z[8,7,1]  R2559     3.5333377122879028e-01
    z[8,7,1]  R2560     1.5919558703899384e-01
    z[8,7,2]  R67       1
    z[8,7,2]  R76       -1
    z[8,7,2]  R2483     -1
    z[8,7,2]  R2484     1
    z[8,7,2]  R2493     -2.5834247469902039e-01
    z[8,7,2]  R2494     1.3997702300548553e-01
    z[8,7,2]  R2495     2.3916728794574738e-01
    z[8,7,2]  R2496     -3.2332172989845276e-01
    z[8,7,2]  R2497     1.4474992454051971e-01
    z[8,7,2]  R2498     8.2499951124191284e-02
    z[8,7,2]  R2499     3.6355210468173027e-03
    z[8,7,2]  R2500     3.0835175514221191e-01
    z[8,7,2]  R2501     -0.819757878780365
    z[8,7,2]  R2502     -0.00738651305437088
    z[8,7,2]  R2503     -1.0767484456300735e-01
    z[8,7,2]  R2504     -3.7795655429363251e-02
    z[8,7,2]  R2505     8.5781373083591461e-02
    z[8,7,2]  R2506     -3.0338302254676819e-01
    z[8,7,2]  R2507     -2.7365781366825104e-02
    z[8,7,2]  R2508     -2.1361067891120911e-01
    z[8,7,2]  R2509     -1.2696257233619690e-01
    z[8,7,2]  R2510     -5.8996188640594482e-01
    z[8,7,2]  R2511     2.0724651217460632e-01
    z[8,7,2]  R2512     1.7899610102176666e-01
    z[8,7,2]  R2513     5.2162384986877441e-01
    z[8,7,2]  R2514     2.8195112943649292e-01
    z[8,7,2]  R2515     4.5889404416084290e-01
    z[8,7,2]  R2516     3.1653431057929993e-01
    z[8,7,2]  R2517     2.6952061057090759e-01
    z[8,7,2]  R2518     1.4117512106895447e-01
    z[8,7,2]  R2519     5.0773864984512329e-01
    z[8,7,2]  R2520     5.8778476715087891e-01
    z[8,7,2]  R2521     -7.6132327318191528e-01
    z[8,7,2]  R2522     -5.3360110521316528e-01
    z[8,7,2]  R2523     -3.5296002030372620e-01
    z[8,7,2]  R2524     -8.2664686441421509e-01
    z[8,7,2]  R2525     -2.3417371511459351e-01
    z[8,7,2]  R2526     -6.4699107408523560e-01
    z[8,7,2]  R2527     -3.6005252599716187e-01
    z[8,7,2]  R2528     -4.4153684377670288e-01
    z[8,7,2]  R2529     -6.7895483970642090e-01
    z[8,7,2]  R2530     -6.8267273902893066e-01
    z[8,7,2]  R2531     1.3164159655570984e-01
    z[8,7,2]  R2532     -1.8416820466518402e-01
    z[8,7,2]  R2533     -4.1128948330879211e-02
    z[8,7,2]  R2534     -2.9217609763145447e-01
    z[8,7,2]  R2535     6.3401895761489868e-01
    z[8,7,2]  R2536     -2.8373596072196960e-01
    z[8,7,2]  R2537     5.9770441055297852e-01
    z[8,7,2]  R2538     7.6240867376327515e-01
    z[8,7,2]  R2539     -5.4313808679580688e-01
    z[8,7,2]  R2540     4.7095847129821777e-01
    z[8,7,2]  R2541     5.4275465011596680e-01
    z[8,7,2]  R2542     5.5356502532958984e-01
    z[8,7,2]  R2543     -1.2465379387140274e-01
    z[8,7,2]  R2544     2.7464056015014648e-01
    z[8,7,2]  R2545     -1.9803625345230103e-01
    z[8,7,2]  R2546     -5.1924180984497070e-01
    z[8,7,2]  R2547     0.0552004911005497
    z[8,7,2]  R2548     -4.9495443701744080e-01
    z[8,7,2]  R2549     -6.0143664479255676e-02
    z[8,7,2]  R2550     -1.7313219606876373e-01
    z[8,7,2]  R2551     3.1601192895323038e-03
    z[8,7,2]  R2552     -0.260611355304718
    z[8,7,2]  R2553     -3.2531660795211792e-01
    z[8,7,2]  R2554     -2.6857241988182068e-02
    z[8,7,2]  R2555     -2.8202858567237854e-01
    z[8,7,2]  R2556     -6.2776988744735718e-01
    z[8,7,2]  R2557     -3.8742101192474365e-01
    z[8,7,2]  R2558     -2.0622909069061279e-01
    z[8,7,2]  R2559     -1.7713381350040436e-01
    z[8,7,2]  R2560     -7.4624830484390259e-01
    z[8,7,3]  R68       1
    z[8,7,3]  R77       -1
    z[8,7,3]  R2485     -1
    z[8,7,3]  R2486     1
    z[8,7,3]  R2493     -7.6885324716567993e-01
    z[8,7,3]  R2494     -5.7068192958831787e-01
    z[8,7,3]  R2495     -0.821049153804779
    z[8,7,3]  R2496     -7.8540176153182983e-02
    z[8,7,3]  R2497     -5.6368821859359741e-01
    z[8,7,3]  R2498     -3.5935062170028687e-01
    z[8,7,3]  R2499     -2.0003998279571533e-01
    z[8,7,3]  R2500     7.6669089496135712e-02
    z[8,7,3]  R2501     1.6064124181866646e-02
    z[8,7,3]  R2502     1.5017512440681458e-01
    z[8,7,3]  R2503     1.1551170796155930e-01
    z[8,7,3]  R2504     1.5412843227386475e-01
    z[8,7,3]  R2505     -5.8783199638128281e-02
    z[8,7,3]  R2506     1.8461252748966217e-01
    z[8,7,3]  R2507     1.6735152900218964e-01
    z[8,7,3]  R2508     2.1953256428241730e-01
    z[8,7,3]  R2509     1.6128091514110565e-01
    z[8,7,3]  R2510     1.0005152225494385e-01
    z[8,7,3]  R2511     -4.8031413555145264e-01
    z[8,7,3]  R2512     -4.8167547583580017e-01
    z[8,7,3]  R2513     -2.6801425218582153e-01
    z[8,7,3]  R2514     -4.1004654765129089e-01
    z[8,7,3]  R2515     -6.0388511419296265e-01
    z[8,7,3]  R2516     -2.8067409992218018e-01
    z[8,7,3]  R2517     -4.9540349841117859e-01
    z[8,7,3]  R2518     -3.8152632117271423e-01
    z[8,7,3]  R2519     -4.3521329760551453e-01
    z[8,7,3]  R2520     -3.1259214878082275e-01
    z[8,7,3]  R2521     -2.0842069387435913e-01
    z[8,7,3]  R2522     7.6991878449916840e-02
    z[8,7,3]  R2523     -2.0139728486537933e-01
    z[8,7,3]  R2524     -2.1196371316909790e-01
    z[8,7,3]  R2525     -3.4143680334091187e-01
    z[8,7,3]  R2526     5.3754840046167374e-02
    z[8,7,3]  R2527     -4.0010473132133484e-01
    z[8,7,3]  R2528     -2.0684248208999634e-01
    z[8,7,3]  R2529     -1.5529535710811615e-01
    z[8,7,3]  R2530     -0.400115042924881
    z[8,7,3]  R2531     -2.2848808765411377e-01
    z[8,7,3]  R2532     3.6773237586021423e-01
    z[8,7,3]  R2533     4.2737263441085815e-01
    z[8,7,3]  R2534     -6.1520408838987350e-02
    z[8,7,3]  R2535     2.7030378580093384e-01
    z[8,7,3]  R2536     8.7555743753910065e-02
    z[8,7,3]  R2537     3.7424591183662415e-01
    z[8,7,3]  R2538     2.2008639574050903e-01
    z[8,7,3]  R2539     -3.5201869904994965e-02
    z[8,7,3]  R2540     5.2728158235549927e-01
    z[8,7,3]  R2541     1.9264583289623260e-01
    z[8,7,3]  R2542     0.363479882478714
    z[8,7,3]  R2543     -1.4564776420593262e-01
    z[8,7,3]  R2544     2.9199967160820961e-02
    z[8,7,3]  R2545     1.5652735531330109e-01
    z[8,7,3]  R2546     2.9135480523109436e-01
    z[8,7,3]  R2547     -0.456819087266922
    z[8,7,3]  R2548     1.3122244179248810e-01
    z[8,7,3]  R2549     -2.5655302405357361e-01
    z[8,7,3]  R2550     8.1395655870437622e-02
    z[8,7,3]  R2551     7.2092838585376740e-02
    z[8,7,3]  R2552     2.7107727527618408e-01
    z[8,7,3]  R2553     -0.572795033454895
    z[8,7,3]  R2554     -3.0412200838327408e-02
    z[8,7,3]  R2555     8.3591938018798828e-03
    z[8,7,3]  R2556     -6.9421872496604919e-02
    z[8,7,3]  R2557     1.9654719531536102e-01
    z[8,7,3]  R2558     -3.3292144536972046e-01
    z[8,7,3]  R2559     -3.1878107786178589e-01
    z[8,7,3]  R2560     3.1275057792663574e-01
    z[8,7,4]  R69       1
    z[8,7,4]  R78       -1
    z[8,7,4]  R2487     -1
    z[8,7,4]  R2488     1
    z[8,7,4]  R2493     -4.7893619537353516e-01
    z[8,7,4]  R2494     -3.2204318046569824e-01
    z[8,7,4]  R2495     -1.1985452473163605e-01
    z[8,7,4]  R2496     3.0569615960121155e-01
    z[8,7,4]  R2497     2.8516548871994019e-01
    z[8,7,4]  R2498     4.9322074651718140e-01
    z[8,7,4]  R2499     8.5074788331985474e-01
    z[8,7,4]  R2500     -4.2093902826309204e-02
    z[8,7,4]  R2501     2.4484671652317047e-01
    z[8,7,4]  R2502     -1.6202388331294060e-02
    z[8,7,4]  R2503     1.9603946805000305e-01
    z[8,7,4]  R2504     1.0144042782485485e-02
    z[8,7,4]  R2505     3.8448280096054077e-01
    z[8,7,4]  R2506     0.0856412723660469
    z[8,7,4]  R2507     1.8914036452770233e-01
    z[8,7,4]  R2508     1.9557043910026550e-01
    z[8,7,4]  R2509     3.2393044233322144e-01
    z[8,7,4]  R2510     1.2204378843307495e-01
    z[8,7,4]  R2511     8.7874464690685272e-02
    z[8,7,4]  R2512     3.5320156812667847e-01
    z[8,7,4]  R2513     -3.2460224628448486e-01
    z[8,7,4]  R2514     -4.0323522686958313e-01
    z[8,7,4]  R2515     1.7393016815185547e-01
    z[8,7,4]  R2516     -3.0924916267395020e-01
    z[8,7,4]  R2517     1.0926908254623413e-01
    z[8,7,4]  R2518     8.8773913681507111e-02
    z[8,7,4]  R2519     -2.8755106031894684e-02
    z[8,7,4]  R2520     -1.6142685711383820e-01
    z[8,7,4]  R2521     3.1779095530509949e-01
    z[8,7,4]  R2522     1.5953162312507629e-01
    z[8,7,4]  R2523     4.0994152426719666e-01
    z[8,7,4]  R2524     2.6277068257331848e-01
    z[8,7,4]  R2525     3.6438804864883423e-01
    z[8,7,4]  R2526     3.5763537883758545e-01
    z[8,7,4]  R2527     -3.3435022830963135e-01
    z[8,7,4]  R2528     -1.8709858879446983e-02
    z[8,7,4]  R2529     4.0536764264106750e-01
    z[8,7,4]  R2530     6.1044309288263321e-02
    z[8,7,4]  R2531     2.6593983639031649e-03
    z[8,7,4]  R2532     -1.1096832901239395e-01
    z[8,7,4]  R2533     1.5101220458745956e-02
    z[8,7,4]  R2534     1.2194374948740005e-01
    z[8,7,4]  R2535     4.8820984363555908e-01
    z[8,7,4]  R2536     -4.2239078879356384e-01
    z[8,7,4]  R2537     5.6169879436492920e-01
    z[8,7,4]  R2538     3.9712718129158020e-01
    z[8,7,4]  R2539     3.6685687303543091e-01
    z[8,7,4]  R2540     -4.6688154339790344e-01
    z[8,7,4]  R2541     -3.3766075968742371e-01
    z[8,7,4]  R2542     4.0931606292724609e-01
    z[8,7,4]  R2543     -1.5668226778507233e-01
    z[8,7,4]  R2544     4.1570329666137695e-01
    z[8,7,4]  R2545     -3.7201806902885437e-01
    z[8,7,4]  R2546     -2.8724548220634460e-01
    z[8,7,4]  R2547     -2.8906616568565369e-01
    z[8,7,4]  R2548     -6.1233836412429810e-01
    z[8,7,4]  R2549     -5.2703678607940674e-01
    z[8,7,4]  R2550     3.4525337815284729e-01
    z[8,7,4]  R2551     4.7952342033386230e-01
    z[8,7,4]  R2552     2.0412006974220276e-01
    z[8,7,4]  R2553     1.0598077625036240e-01
    z[8,7,4]  R2554     4.9998083710670471e-01
    z[8,7,4]  R2555     6.3665992021560669e-01
    z[8,7,4]  R2556     -2.5265842676162720e-01
    z[8,7,4]  R2557     -3.5125258564949036e-01
    z[8,7,4]  R2558     6.8694218993186951e-02
    z[8,7,4]  R2559     -3.3508253097534180e-01
    z[8,7,4]  R2560     -2.8536248207092285e-01
    z[8,7,5]  R70       1
    z[8,7,5]  R79       -1
    z[8,7,5]  R2489     -1
    z[8,7,5]  R2490     1
    z[8,7,5]  R2493     -1.3279798626899719e-01
    z[8,7,5]  R2494     1.5413187444210052e-02
    z[8,7,5]  R2495     -7.6223835349082947e-02
    z[8,7,5]  R2496     -1.9351997971534729e-01
    z[8,7,5]  R2497     -0.581364095211029
    z[8,7,5]  R2498     0.388720840215683
    z[8,7,5]  R2499     -1.1550952494144440e-01
    z[8,7,5]  R2500     -7.7131915092468262e-01
    z[8,7,5]  R2501     4.2888391017913818e-01
    z[8,7,5]  R2502     -9.8720449209213257e-01
    z[8,7,5]  R2503     -1.4730840921401978e-01
    z[8,7,5]  R2504     3.9859893918037415e-01
    z[8,7,5]  R2505     2.4619343876838684e-01
    z[8,7,5]  R2506     4.8062625527381897e-01
    z[8,7,5]  R2507     8.2773292064666748e-01
    z[8,7,5]  R2508     7.4844104051589966e-01
    z[8,7,5]  R2509     0.447476863861084
    z[8,7,5]  R2510     -6.6538691520690918e-02
    z[8,7,5]  R2511     -8.0768600106239319e-02
    z[8,7,5]  R2512     -1.6285438835620880e-01
    z[8,7,5]  R2513     -2.9461956024169922e-01
    z[8,7,5]  R2514     -2.1792963147163391e-02
    z[8,7,5]  R2515     1.6106051206588745e-01
    z[8,7,5]  R2516     0.0692526325583458
    z[8,7,5]  R2517     5.6930035352706909e-02
    z[8,7,5]  R2518     1.6846823692321777e-01
    z[8,7,5]  R2519     2.3168951272964478e-01
    z[8,7,5]  R2520     -5.8971758931875229e-02
    z[8,7,5]  R2521     3.5116624832153320e-01
    z[8,7,5]  R2522     2.9393658041954041e-01
    z[8,7,5]  R2523     2.3688310384750366e-01
    z[8,7,5]  R2524     -1.3653612695634365e-02
    z[8,7,5]  R2525     5.2769124507904053e-01
    z[8,7,5]  R2526     2.6400020718574524e-01
    z[8,7,5]  R2527     3.3163699507713318e-01
    z[8,7,5]  R2528     5.2961331605911255e-01
    z[8,7,5]  R2529     6.6605731844902039e-02
    z[8,7,5]  R2530     8.5524007678031921e-02
    z[8,7,5]  R2531     6.4090877771377563e-02
    z[8,7,5]  R2532     6.0757702589035034e-01
    z[8,7,5]  R2533     -3.4068447351455688e-01
    z[8,7,5]  R2534     -1.6942915320396423e-01
    z[8,7,5]  R2535     2.3075174540281296e-02
    z[8,7,5]  R2536     -3.7522771954536438e-01
    z[8,7,5]  R2537     -3.6397096514701843e-01
    z[8,7,5]  R2538     -8.1869758665561676e-02
    z[8,7,5]  R2539     -1.8982832133769989e-01
    z[8,7,5]  R2540     -3.0167052149772644e-01
    z[8,7,5]  R2541     -4.3691787123680115e-01
    z[8,7,5]  R2542     -2.5596013665199280e-01
    z[8,7,5]  R2543     -2.6717826724052429e-01
    z[8,7,5]  R2544     -4.5564821362495422e-01
    z[8,7,5]  R2545     1.3876450061798096e-01
    z[8,7,5]  R2546     3.7094980478286743e-01
    z[8,7,5]  R2547     1.8450053036212921e-01
    z[8,7,5]  R2548     -1.0467682778835297e-01
    z[8,7,5]  R2549     -2.1239361166954041e-01
    z[8,7,5]  R2550     -6.9543474912643433e-01
    z[8,7,5]  R2551     3.3586883544921875e-01
    z[8,7,5]  R2552     0.0529618114233017
    z[8,7,5]  R2553     2.0456415414810181e-01
    z[8,7,5]  R2554     -4.4151566922664642e-02
    z[8,7,5]  R2555     -2.0282618701457977e-01
    z[8,7,5]  R2556     4.1765943169593811e-02
    z[8,7,5]  R2557     2.0831583440303802e-01
    z[8,7,5]  R2558     -4.6064084768295288e-01
    z[8,7,5]  R2559     -1.2476217746734619e-01
    z[8,7,5]  R2560     -1.6402420401573181e-01
    z[8,7,6]  R71       1
    z[8,7,6]  R80       -1
    z[8,7,6]  R2491     -1
    z[8,7,6]  R2492     1
    z[8,7,6]  R2493     -2.6471960544586182e-01
    z[8,7,6]  R2494     -2.4849440902471542e-02
    z[8,7,6]  R2495     3.9252853393554688e-01
    z[8,7,6]  R2496     -6.2235909700393677e-01
    z[8,7,6]  R2497     -3.1920313835144043e-01
    z[8,7,6]  R2498     -4.4289040565490723e-01
    z[8,7,6]  R2499     -4.0792697668075562e-01
    z[8,7,6]  R2500     1.1715488135814667e-01
    z[8,7,6]  R2501     1.8136323988437653e-01
    z[8,7,6]  R2502     -3.3886294811964035e-02
    z[8,7,6]  R2503     -1.8405759707093239e-02
    z[8,7,6]  R2504     6.0048587620258331e-02
    z[8,7,6]  R2505     -3.6136958748102188e-02
    z[8,7,6]  R2506     1.1217761784791946e-01
    z[8,7,6]  R2507     1.3049735128879547e-01
    z[8,7,6]  R2508     0.371138334274292
    z[8,7,6]  R2509     0.768406093120575
    z[8,7,6]  R2510     0.569032609462738
    z[8,7,6]  R2511     4.7823827713727951e-02
    z[8,7,6]  R2512     -6.2529936432838440e-02
    z[8,7,6]  R2513     -4.7796273231506348e-01
    z[8,7,6]  R2514     -2.0951466262340546e-01
    z[8,7,6]  R2515     -3.5356923937797546e-01
    z[8,7,6]  R2516     -3.3737120032310486e-01
    z[8,7,6]  R2517     -6.3296043872833252e-01
    z[8,7,6]  R2518     -8.9385047554969788e-02
    z[8,7,6]  R2519     2.7495065331459045e-01
    z[8,7,6]  R2520     5.3487294912338257e-01
    z[8,7,6]  R2521     -7.2296082973480225e-02
    z[8,7,6]  R2522     -3.8550171256065369e-01
    z[8,7,6]  R2523     -2.4102674424648285e-01
    z[8,7,6]  R2524     1.3702000677585602e-01
    z[8,7,6]  R2525     2.4131065234541893e-02
    z[8,7,6]  R2526     -4.7467836737632751e-01
    z[8,7,6]  R2527     -4.0130499750375748e-02
    z[8,7,6]  R2528     -1.9770424067974091e-01
    z[8,7,6]  R2529     -2.9647165536880493e-01
    z[8,7,6]  R2530     -1.2091419100761414e-01
    z[8,7,6]  R2531     4.9655269831418991e-03
    z[8,7,6]  R2532     2.6535043120384216e-01
    z[8,7,6]  R2533     4.5243373513221741e-01
    z[8,7,6]  R2534     5.9318149089813232e-01
    z[8,7,6]  R2535     1.0646731406450272e-01
    z[8,7,6]  R2536     -1.5190860629081726e-01
    z[8,7,6]  R2537     1.9037947058677673e-01
    z[8,7,6]  R2538     7.2091028094291687e-02
    z[8,7,6]  R2539     1.9828733801841736e-01
    z[8,7,6]  R2540     3.3240351080894470e-01
    z[8,7,6]  R2541     9.5755398273468018e-02
    z[8,7,6]  R2542     -4.4632163643836975e-01
    z[8,7,6]  R2543     4.3559619784355164e-01
    z[8,7,6]  R2544     0.0672859326004982
    z[8,7,6]  R2545     1.2623533606529236e-01
    z[8,7,6]  R2546     -0.137685626745224
    z[8,7,6]  R2547     1.8307086825370789e-01
    z[8,7,6]  R2548     -1.0838644206523895e-01
    z[8,7,6]  R2549     -1.8706727027893066e-01
    z[8,7,6]  R2550     -7.7225610613822937e-02
    z[8,7,6]  R2551     -3.8787248730659485e-01
    z[8,7,6]  R2552     -3.2745647430419922e-01
    z[8,7,6]  R2553     1.2571661174297333e-01
    z[8,7,6]  R2554     -2.2624506056308746e-01
    z[8,7,6]  R2555     1.6531706787645817e-03
    z[8,7,6]  R2556     4.0141192078590393e-01
    z[8,7,6]  R2557     2.3709567263722420e-02
    z[8,7,6]  R2558     1.6186979413032532e-01
    z[8,7,6]  R2559     -0.359343558549881
    z[8,7,6]  R2560     -1.5420430898666382e-01
    length[0]  OBJ       1
    length[1]  OBJ       1
    length[2]  OBJ       1
    length[3]  OBJ       1
    length[4]  OBJ       1
    length[5]  OBJ       1
    length[6]  OBJ       1
    length[7]  OBJ       1
    length[8]  OBJ       1
    delta[0,0]  R2        1
    delta[0,1]  R3        1
    delta[0,2]  R4        1
    delta[0,3]  R5        1
    delta[0,4]  R6        1
    delta[0,5]  R7        1
    delta[0,6]  R8        1
    delta[1,0]  R11       1
    delta[1,1]  R12       1
    delta[1,2]  R13       1
    delta[1,3]  R14       1
    delta[1,4]  R15       1
    delta[1,5]  R16       1
    delta[1,6]  R17       1
    delta[2,0]  R20       1
    delta[2,1]  R21       1
    delta[2,2]  R22       1
    delta[2,3]  R23       1
    delta[2,4]  R24       1
    delta[2,5]  R25       1
    delta[2,6]  R26       1
    delta[3,0]  R29       1
    delta[3,1]  R30       1
    delta[3,2]  R31       1
    delta[3,3]  R32       1
    delta[3,4]  R33       1
    delta[3,5]  R34       1
    delta[3,6]  R35       1
    delta[4,0]  R38       1
    delta[4,1]  R39       1
    delta[4,2]  R40       1
    delta[4,3]  R41       1
    delta[4,4]  R42       1
    delta[4,5]  R43       1
    delta[4,6]  R44       1
    delta[5,0]  R47       1
    delta[5,1]  R48       1
    delta[5,2]  R49       1
    delta[5,3]  R50       1
    delta[5,4]  R51       1
    delta[5,5]  R52       1
    delta[5,6]  R53       1
    delta[6,0]  R56       1
    delta[6,1]  R57       1
    delta[6,2]  R58       1
    delta[6,3]  R59       1
    delta[6,4]  R60       1
    delta[6,5]  R61       1
    delta[6,6]  R62       1
    delta[7,0]  R65       1
    delta[7,1]  R66       1
    delta[7,2]  R67       1
    delta[7,3]  R68       1
    delta[7,4]  R69       1
    delta[7,5]  R70       1
    delta[7,6]  R71       1
    delta[8,0]  R74       1
    delta[8,1]  R75       1
    delta[8,2]  R76       1
    delta[8,3]  R77       1
    delta[8,4]  R78       1
    delta[8,5]  R79       1
    delta[8,6]  R80       1
RHS
    RHS1      R1        1
    RHS1      R10       1
    RHS1      R19       1
    RHS1      R28       1
    RHS1      R37       1
    RHS1      R46       1
    RHS1      R55       1
    RHS1      R64       1
    RHS1      R73       1
    RHS1      R81       1
    RHS1      R82       -1
BOUNDS
 BV BND1      phi[0,1]
 BV BND1      phi[1,0]
 BV BND1      phi[0,5]
 BV BND1      phi[5,0]
 BV BND1      phi[0,6]
 BV BND1      phi[6,0]
 BV BND1      phi[9,0]
 BV BND1      phi[1,2]
 BV BND1      phi[2,1]
 BV BND1      phi[1,6]
 BV BND1      phi[6,1]
 BV BND1      phi[2,3]
 BV BND1      phi[3,2]
 BV BND1      phi[3,4]
 BV BND1      phi[4,3]
 BV BND1      phi[4,8]
 BV BND1      phi[8,4]
 BV BND1      phi[4,10]
 BV BND1      phi[5,6]
 BV BND1      phi[6,5]
 BV BND1      phi[9,5]
 BV BND1      phi[6,7]
 BV BND1      phi[7,6]
 BV BND1      phi[7,8]
 BV BND1      phi[8,7]
 BV BND1      phi[8,10]
 FR BND1      z[0,1,0]
 FR BND1      z[0,1,1]
 FR BND1      z[0,1,2]
 FR BND1      z[0,1,3]
 FR BND1      z[0,1,4]
 FR BND1      z[0,1,5]
 FR BND1      z[0,1,6]
 FR BND1      z[1,0,0]
 FR BND1      z[1,0,1]
 FR BND1      z[1,0,2]
 FR BND1      z[1,0,3]
 FR BND1      z[1,0,4]
 FR BND1      z[1,0,5]
 FR BND1      z[1,0,6]
 FR BND1      z[0,5,0]
 FR BND1      z[0,5,1]
 FR BND1      z[0,5,2]
 FR BND1      z[0,5,3]
 FR BND1      z[0,5,4]
 FR BND1      z[0,5,5]
 FR BND1      z[0,5,6]
 FR BND1      z[5,0,0]
 FR BND1      z[5,0,1]
 FR BND1      z[5,0,2]
 FR BND1      z[5,0,3]
 FR BND1      z[5,0,4]
 FR BND1      z[5,0,5]
 FR BND1      z[5,0,6]
 FR BND1      z[0,6,0]
 FR BND1      z[0,6,1]
 FR BND1      z[0,6,2]
 FR BND1      z[0,6,3]
 FR BND1      z[0,6,4]
 FR BND1      z[0,6,5]
 FR BND1      z[0,6,6]
 FR BND1      z[6,0,0]
 FR BND1      z[6,0,1]
 FR BND1      z[6,0,2]
 FR BND1      z[6,0,3]
 FR BND1      z[6,0,4]
 FR BND1      z[6,0,5]
 FR BND1      z[6,0,6]
 FR BND1      z[1,2,0]
 FR BND1      z[1,2,1]
 FR BND1      z[1,2,2]
 FR BND1      z[1,2,3]
 FR BND1      z[1,2,4]
 FR BND1      z[1,2,5]
 FR BND1      z[1,2,6]
 FR BND1      z[2,1,0]
 FR BND1      z[2,1,1]
 FR BND1      z[2,1,2]
 FR BND1      z[2,1,3]
 FR BND1      z[2,1,4]
 FR BND1      z[2,1,5]
 FR BND1      z[2,1,6]
 FR BND1      z[1,6,0]
 FR BND1      z[1,6,1]
 FR BND1      z[1,6,2]
 FR BND1      z[1,6,3]
 FR BND1      z[1,6,4]
 FR BND1      z[1,6,5]
 FR BND1      z[1,6,6]
 FR BND1      z[6,1,0]
 FR BND1      z[6,1,1]
 FR BND1      z[6,1,2]
 FR BND1      z[6,1,3]
 FR BND1      z[6,1,4]
 FR BND1      z[6,1,5]
 FR BND1      z[6,1,6]
 FR BND1      z[2,3,0]
 FR BND1      z[2,3,1]
 FR BND1      z[2,3,2]
 FR BND1      z[2,3,3]
 FR BND1      z[2,3,4]
 FR BND1      z[2,3,5]
 FR BND1      z[2,3,6]
 FR BND1      z[3,2,0]
 FR BND1      z[3,2,1]
 FR BND1      z[3,2,2]
 FR BND1      z[3,2,3]
 FR BND1      z[3,2,4]
 FR BND1      z[3,2,5]
 FR BND1      z[3,2,6]
 FR BND1      z[3,4,0]
 FR BND1      z[3,4,1]
 FR BND1      z[3,4,2]
 FR BND1      z[3,4,3]
 FR BND1      z[3,4,4]
 FR BND1      z[3,4,5]
 FR BND1      z[3,4,6]
 FR BND1      z[4,3,0]
 FR BND1      z[4,3,1]
 FR BND1      z[4,3,2]
 FR BND1      z[4,3,3]
 FR BND1      z[4,3,4]
 FR BND1      z[4,3,5]
 FR BND1      z[4,3,6]
 FR BND1      z[4,8,0]
 FR BND1      z[4,8,1]
 FR BND1      z[4,8,2]
 FR BND1      z[4,8,3]
 FR BND1      z[4,8,4]
 FR BND1      z[4,8,5]
 FR BND1      z[4,8,6]
 FR BND1      z[8,4,0]
 FR BND1      z[8,4,1]
 FR BND1      z[8,4,2]
 FR BND1      z[8,4,3]
 FR BND1      z[8,4,4]
 FR BND1      z[8,4,5]
 FR BND1      z[8,4,6]
 FR BND1      z[5,6,0]
 FR BND1      z[5,6,1]
 FR BND1      z[5,6,2]
 FR BND1      z[5,6,3]
 FR BND1      z[5,6,4]
 FR BND1      z[5,6,5]
 FR BND1      z[5,6,6]
 FR BND1      z[6,5,0]
 FR BND1      z[6,5,1]
 FR BND1      z[6,5,2]
 FR BND1      z[6,5,3]
 FR BND1      z[6,5,4]
 FR BND1      z[6,5,5]
 FR BND1      z[6,5,6]
 FR BND1      z[6,7,0]
 FR BND1      z[6,7,1]
 FR BND1      z[6,7,2]
 FR BND1      z[6,7,3]
 FR BND1      z[6,7,4]
 FR BND1      z[6,7,5]
 FR BND1      z[6,7,6]
 FR BND1      z[7,6,0]
 FR BND1      z[7,6,1]
 FR BND1      z[7,6,2]
 FR BND1      z[7,6,3]
 FR BND1      z[7,6,4]
 FR BND1      z[7,6,5]
 FR BND1      z[7,6,6]
 FR BND1      z[7,8,0]
 FR BND1      z[7,8,1]
 FR BND1      z[7,8,2]
 FR BND1      z[7,8,3]
 FR BND1      z[7,8,4]
 FR BND1      z[7,8,5]
 FR BND1      z[7,8,6]
 FR BND1      z[8,7,0]
 FR BND1      z[8,7,1]
 FR BND1      z[8,7,2]
 FR BND1      z[8,7,3]
 FR BND1      z[8,7,4]
 FR BND1      z[8,7,5]
 FR BND1      z[8,7,6]
 FR BND1      delta[0,0]
 FR BND1      delta[0,1]
 FR BND1      delta[0,2]
 FR BND1      delta[0,3]
 FR BND1      delta[0,4]
 FR BND1      delta[0,5]
 FR BND1      delta[0,6]
 FR BND1      delta[1,0]
 FR BND1      delta[1,1]
 FR BND1      delta[1,2]
 FR BND1      delta[1,3]
 FR BND1      delta[1,4]
 FR BND1      delta[1,5]
 FR BND1      delta[1,6]
 FR BND1      delta[2,0]
 FR BND1      delta[2,1]
 FR BND1      delta[2,2]
 FR BND1      delta[2,3]
 FR BND1      delta[2,4]
 FR BND1      delta[2,5]
 FR BND1      delta[2,6]
 FR BND1      delta[3,0]
 FR BND1      delta[3,1]
 FR BND1      delta[3,2]
 FR BND1      delta[3,3]
 FR BND1      delta[3,4]
 FR BND1      delta[3,5]
 FR BND1      delta[3,6]
 FR BND1      delta[4,0]
 FR BND1      delta[4,1]
 FR BND1      delta[4,2]
 FR BND1      delta[4,3]
 FR BND1      delta[4,4]
 FR BND1      delta[4,5]
 FR BND1      delta[4,6]
 FR BND1      delta[5,0]
 FR BND1      delta[5,1]
 FR BND1      delta[5,2]
 FR BND1      delta[5,3]
 FR BND1      delta[5,4]
 FR BND1      delta[5,5]
 FR BND1      delta[5,6]
 FR BND1      delta[6,0]
 FR BND1      delta[6,1]
 FR BND1      delta[6,2]
 FR BND1      delta[6,3]
 FR BND1      delta[6,4]
 FR BND1      delta[6,5]
 FR BND1      delta[6,6]
 FR BND1      delta[7,0]
 FR BND1      delta[7,1]
 FR BND1      delta[7,2]
 FR BND1      delta[7,3]
 FR BND1      delta[7,4]
 FR BND1      delta[7,5]
 FR BND1      delta[7,6]
 FR BND1      delta[8,0]
 FR BND1      delta[8,1]
 FR BND1      delta[8,2]
 FR BND1      delta[8,3]
 FR BND1      delta[8,4]
 FR BND1      delta[8,5]
 FR BND1      delta[8,6]
QCMATRIX   qc0     
    length[0]  length[0]  -1
    delta[0,0]  delta[0,0]  1
    delta[0,1]  delta[0,1]  1
    delta[0,2]  delta[0,2]  1
    delta[0,3]  delta[0,3]  1
    delta[0,4]  delta[0,4]  1
    delta[0,5]  delta[0,5]  1
    delta[0,6]  delta[0,6]  1
QCMATRIX   qc1     
    length[1]  length[1]  -1
    delta[1,0]  delta[1,0]  1
    delta[1,1]  delta[1,1]  1
    delta[1,2]  delta[1,2]  1
    delta[1,3]  delta[1,3]  1
    delta[1,4]  delta[1,4]  1
    delta[1,5]  delta[1,5]  1
    delta[1,6]  delta[1,6]  1
QCMATRIX   qc2     
    length[2]  length[2]  -1
    delta[2,0]  delta[2,0]  1
    delta[2,1]  delta[2,1]  1
    delta[2,2]  delta[2,2]  1
    delta[2,3]  delta[2,3]  1
    delta[2,4]  delta[2,4]  1
    delta[2,5]  delta[2,5]  1
    delta[2,6]  delta[2,6]  1
QCMATRIX   qc3     
    length[3]  length[3]  -1
    delta[3,0]  delta[3,0]  1
    delta[3,1]  delta[3,1]  1
    delta[3,2]  delta[3,2]  1
    delta[3,3]  delta[3,3]  1
    delta[3,4]  delta[3,4]  1
    delta[3,5]  delta[3,5]  1
    delta[3,6]  delta[3,6]  1
QCMATRIX   qc4     
    length[4]  length[4]  -1
    delta[4,0]  delta[4,0]  1
    delta[4,1]  delta[4,1]  1
    delta[4,2]  delta[4,2]  1
    delta[4,3]  delta[4,3]  1
    delta[4,4]  delta[4,4]  1
    delta[4,5]  delta[4,5]  1
    delta[4,6]  delta[4,6]  1
QCMATRIX   qc5     
    length[5]  length[5]  -1
    delta[5,0]  delta[5,0]  1
    delta[5,1]  delta[5,1]  1
    delta[5,2]  delta[5,2]  1
    delta[5,3]  delta[5,3]  1
    delta[5,4]  delta[5,4]  1
    delta[5,5]  delta[5,5]  1
    delta[5,6]  delta[5,6]  1
QCMATRIX   qc6     
    length[6]  length[6]  -1
    delta[6,0]  delta[6,0]  1
    delta[6,1]  delta[6,1]  1
    delta[6,2]  delta[6,2]  1
    delta[6,3]  delta[6,3]  1
    delta[6,4]  delta[6,4]  1
    delta[6,5]  delta[6,5]  1
    delta[6,6]  delta[6,6]  1
QCMATRIX   qc7     
    length[7]  length[7]  -1
    delta[7,0]  delta[7,0]  1
    delta[7,1]  delta[7,1]  1
    delta[7,2]  delta[7,2]  1
    delta[7,3]  delta[7,3]  1
    delta[7,4]  delta[7,4]  1
    delta[7,5]  delta[7,5]  1
    delta[7,6]  delta[7,6]  1
QCMATRIX   qc8     
    length[8]  length[8]  -1
    delta[8,0]  delta[8,0]  1
    delta[8,1]  delta[8,1]  1
    delta[8,2]  delta[8,2]  1
    delta[8,3]  delta[8,3]  1
    delta[8,4]  delta[8,4]  1
    delta[8,5]  delta[8,5]  1
    delta[8,6]  delta[8,6]  1
ENDATA
