NAME LGCS_GCS_Eq5_5_projected
ROWS
 N  OBJ
 E  R0      
 L  R1      
 E  R2      
 E  R3      
 E  R4      
 E  R5      
 E  R6      
 E  R7      
 E  R8      
 E  R9      
 L  R10     
 E  R11     
 E  R12     
 E  R13     
 E  R14     
 E  R15     
 E  R16     
 E  R17     
 E  R18     
 L  R19     
 E  R20     
 E  R21     
 E  R22     
 E  R23     
 E  R24     
 E  R25     
 E  R26     
 E  R27     
 L  R28     
 E  R29     
 E  R30     
 E  R31     
 E  R32     
 E  R33     
 E  R34     
 E  R35     
 E  R36     
 L  R37     
 E  R38     
 E  R39     
 E  R40     
 E  R41     
 E  R42     
 E  R43     
 E  R44     
 E  R45     
 L  R46     
 E  R47     
 E  R48     
 E  R49     
 E  R50     
 E  R51     
 E  R52     
 E  R53     
 E  R54     
 L  R55     
 E  R56     
 E  R57     
 E  R58     
 E  R59     
 E  R60     
 E  R61     
 E  R62     
 E  R63     
 E  R64     
 L  R65     
 L  R66     
 L  R67     
 L  R68     
 L  R69     
 L  R70     
 L  R71     
 L  R72     
 L  R73     
 L  R74     
 L  R75     
 L  R76     
 L  R77     
 L  R78     
 L  R79     
 L  R80     
 L  R81     
 L  R82     
 L  R83     
 L  R84     
 L  R85     
 L  R86     
 L  R87     
 L  R88     
 L  R89     
 L  R90     
 L  R91     
 L  R92     
 L  R93     
 L  R94     
 L  R95     
 L  R96     
 L  R97     
 L  R98     
 L  R99     
 L  R100    
 L  R101    
 L  R102    
 L  R103    
 L  R104    
 L  R105    
 L  R106    
 L  R107    
 L  R108    
 L  R109    
 L  R110    
 L  R111    
 L  R112    
 L  R113    
 L  R114    
 L  R115    
 L  R116    
 L  R117    
 L  R118    
 L  R119    
 L  R120    
 L  R121    
 L  R122    
 L  R123    
 L  R124    
 L  R125    
 L  R126    
 L  R127    
 L  R128    
 L  R129    
 L  R130    
 L  R131    
 L  R132    
 L  R133    
 L  R134    
 L  R135    
 L  R136    
 L  R137    
 L  R138    
 L  R139    
 L  R140    
 L  R141    
 L  R142    
 L  R143    
 L  R144    
 L  R145    
 L  R146    
 L  R147    
 L  R148    
 L  R149    
 L  R150    
 L  R151    
 L  R152    
 L  R153    
 L  R154    
 L  R155    
 L  R156    
 L  R157    
 L  R158    
 L  R159    
 L  R160    
 L  R161    
 L  R162    
 L  R163    
 L  R164    
 L  R165    
 L  R166    
 L  R167    
 L  R168    
 L  R169    
 L  R170    
 L  R171    
 L  R172    
 L  R173    
 L  R174    
 L  R175    
 L  R176    
 L  R177    
 L  R178    
 L  R179    
 L  R180    
 L  R181    
 L  R182    
 L  R183    
 L  R184    
 L  R185    
 L  R186    
 L  R187    
 L  R188    
 L  R189    
 L  R190    
 L  R191    
 L  R192    
 L  R193    
 L  R194    
 L  R195    
 L  R196    
 L  R197    
 L  R198    
 L  R199    
 L  R200    
 L  R201    
 L  R202    
 L  R203    
 L  R204    
 L  R205    
 L  R206    
 L  R207    
 L  R208    
 L  R209    
 L  R210    
 L  R211    
 L  R212    
 L  R213    
 L  R214    
 L  R215    
 L  R216    
 L  R217    
 L  R218    
 L  R219    
 L  R220    
 L  R221    
 L  R222    
 L  R223    
 L  R224    
 L  R225    
 L  R226    
 L  R227    
 L  R228    
 L  R229    
 L  R230    
 L  R231    
 L  R232    
 L  R233    
 L  R234    
 L  R235    
 L  R236    
 L  R237    
 L  R238    
 L  R239    
 L  R240    
 L  R241    
 L  R242    
 L  R243    
 L  R244    
 L  R245    
 L  R246    
 L  R247    
 L  R248    
 L  R249    
 L  R250    
 L  R251    
 L  R252    
 L  R253    
 L  R254    
 L  R255    
 L  R256    
 L  R257    
 L  R258    
 L  R259    
 L  R260    
 L  R261    
 L  R262    
 L  R263    
 L  R264    
 L  R265    
 L  R266    
 L  R267    
 L  R268    
 L  R269    
 L  R270    
 L  R271    
 L  R272    
 L  R273    
 L  R274    
 L  R275    
 L  R276    
 L  R277    
 L  R278    
 L  R279    
 L  R280    
 L  R281    
 L  R282    
 L  R283    
 L  R284    
 L  R285    
 L  R286    
 L  R287    
 L  R288    
 L  R289    
 L  R290    
 L  R291    
 L  R292    
 L  R293    
 L  R294    
 L  R295    
 L  R296    
 L  R297    
 L  R298    
 L  R299    
 L  R300    
 L  R301    
 L  R302    
 L  R303    
 L  R304    
 L  R305    
 L  R306    
 L  R307    
 L  R308    
 L  R309    
 L  R310    
 L  R311    
 L  R312    
 L  R313    
 L  R314    
 L  R315    
 L  R316    
 L  R317    
 L  R318    
 L  R319    
 L  R320    
 L  R321    
 L  R322    
 L  R323    
 L  R324    
 L  R325    
 L  R326    
 L  R327    
 L  R328    
 L  R329    
 L  R330    
 L  R331    
 L  R332    
 L  R333    
 L  R334    
 L  R335    
 L  R336    
 L  R337    
 L  R338    
 L  R339    
 L  R340    
 L  R341    
 L  R342    
 L  R343    
 L  R344    
 L  R345    
 L  R346    
 L  R347    
 L  R348    
 L  R349    
 L  R350    
 L  R351    
 L  R352    
 L  R353    
 L  R354    
 L  R355    
 L  R356    
 L  R357    
 L  R358    
 L  R359    
 L  R360    
 L  R361    
 L  R362    
 L  R363    
 L  R364    
 L  R365    
 L  R366    
 L  R367    
 L  R368    
 L  R369    
 L  R370    
 L  R371    
 L  R372    
 L  R373    
 L  R374    
 L  R375    
 L  R376    
 L  R377    
 L  R378    
 L  R379    
 L  R380    
 L  R381    
 L  R382    
 L  R383    
 L  R384    
 L  R385    
 L  R386    
 L  R387    
 L  R388    
 L  R389    
 L  R390    
 L  R391    
 L  R392    
 L  R393    
 L  R394    
 L  R395    
 L  R396    
 L  R397    
 L  R398    
 L  R399    
 L  R400    
 L  R401    
 L  R402    
 L  R403    
 L  R404    
 L  R405    
 L  R406    
 L  R407    
 L  R408    
 L  R409    
 L  R410    
 L  R411    
 L  R412    
 L  R413    
 L  R414    
 L  R415    
 L  R416    
 L  R417    
 L  R418    
 L  R419    
 L  R420    
 L  R421    
 L  R422    
 L  R423    
 L  R424    
 L  R425    
 L  R426    
 L  R427    
 L  R428    
 L  R429    
 L  R430    
 L  R431    
 L  R432    
 L  R433    
 L  R434    
 L  R435    
 L  R436    
 L  R437    
 L  R438    
 L  R439    
 L  R440    
 L  R441    
 L  R442    
 L  R443    
 L  R444    
 L  R445    
 L  R446    
 L  R447    
 L  R448    
 L  R449    
 L  R450    
 L  R451    
 L  R452    
 L  R453    
 L  R454    
 L  R455    
 L  R456    
 L  R457    
 L  R458    
 L  R459    
 L  R460    
 L  R461    
 L  R462    
 L  R463    
 L  R464    
 L  R465    
 L  R466    
 L  R467    
 L  R468    
 L  R469    
 L  R470    
 L  R471    
 L  R472    
 L  R473    
 L  R474    
 L  R475    
 L  R476    
 L  R477    
 L  R478    
 L  R479    
 L  R480    
 L  R481    
 L  R482    
 L  R483    
 L  R484    
 L  R485    
 L  R486    
 L  R487    
 L  R488    
 L  R489    
 L  R490    
 L  R491    
 L  R492    
 L  R493    
 L  R494    
 L  R495    
 L  R496    
 L  R497    
 L  R498    
 L  R499    
 L  R500    
 L  R501    
 L  R502    
 L  R503    
 L  R504    
 L  R505    
 L  R506    
 L  R507    
 L  R508    
 L  R509    
 L  R510    
 L  R511    
 L  R512    
 L  R513    
 L  R514    
 L  R515    
 L  R516    
 L  R517    
 L  R518    
 L  R519    
 L  R520    
 L  R521    
 L  R522    
 L  R523    
 L  R524    
 L  R525    
 L  R526    
 L  R527    
 L  R528    
 L  R529    
 L  R530    
 L  R531    
 L  R532    
 L  R533    
 L  R534    
 L  R535    
 L  R536    
 L  R537    
 L  R538    
 L  R539    
 L  R540    
 L  R541    
 L  R542    
 L  R543    
 L  R544    
 L  R545    
 L  R546    
 L  R547    
 L  R548    
 L  R549    
 L  R550    
 L  R551    
 L  R552    
 L  R553    
 L  R554    
 L  R555    
 L  R556    
 L  R557    
 L  R558    
 L  R559    
 L  R560    
 L  R561    
 L  R562    
 L  R563    
 L  R564    
 L  R565    
 L  R566    
 L  R567    
 L  R568    
 L  R569    
 L  R570    
 L  R571    
 L  R572    
 L  R573    
 L  R574    
 L  R575    
 L  R576    
 L  R577    
 L  R578    
 L  R579    
 L  R580    
 L  R581    
 L  R582    
 L  R583    
 L  R584    
 L  R585    
 L  R586    
 L  R587    
 L  R588    
 L  R589    
 L  R590    
 L  R591    
 L  R592    
 L  R593    
 L  R594    
 L  R595    
 L  R596    
 L  R597    
 L  R598    
 L  R599    
 L  R600    
 L  R601    
 L  R602    
 L  R603    
 L  R604    
 L  R605    
 L  R606    
 L  R607    
 L  R608    
 L  R609    
 L  R610    
 L  R611    
 L  R612    
 L  R613    
 L  R614    
 L  R615    
 L  R616    
 L  R617    
 L  R618    
 L  R619    
 L  R620    
 L  R621    
 L  R622    
 L  R623    
 L  R624    
 L  R625    
 L  R626    
 L  R627    
 L  R628    
 L  R629    
 L  R630    
 L  R631    
 L  R632    
 L  R633    
 L  R634    
 L  R635    
 L  R636    
 L  R637    
 L  R638    
 L  R639    
 L  R640    
 L  R641    
 L  R642    
 L  R643    
 L  R644    
 L  R645    
 L  R646    
 L  R647    
 L  R648    
 L  R649    
 L  R650    
 L  R651    
 L  R652    
 L  R653    
 L  R654    
 L  R655    
 L  R656    
 L  R657    
 L  R658    
 L  R659    
 L  R660    
 L  R661    
 L  R662    
 L  R663    
 L  R664    
 L  R665    
 L  R666    
 L  R667    
 L  R668    
 L  R669    
 L  R670    
 L  R671    
 L  R672    
 L  R673    
 L  R674    
 L  R675    
 L  R676    
 L  R677    
 L  R678    
 L  R679    
 L  R680    
 L  R681    
 L  R682    
 L  R683    
 L  R684    
 L  R685    
 L  R686    
 L  R687    
 L  R688    
 L  R689    
 L  R690    
 L  R691    
 L  R692    
 L  R693    
 L  R694    
 L  R695    
 L  R696    
 L  R697    
 L  R698    
 L  R699    
 L  R700    
 L  R701    
 L  R702    
 L  R703    
 L  R704    
 L  R705    
 L  R706    
 L  R707    
 L  R708    
 L  R709    
 L  R710    
 L  R711    
 L  R712    
 L  R713    
 L  R714    
 L  R715    
 L  R716    
 L  R717    
 L  R718    
 L  R719    
 L  R720    
 L  R721    
 L  R722    
 L  R723    
 L  R724    
 L  R725    
 L  R726    
 L  R727    
 L  R728    
 L  R729    
 L  R730    
 L  R731    
 L  R732    
 L  R733    
 L  R734    
 L  R735    
 L  R736    
 L  R737    
 L  R738    
 L  R739    
 L  R740    
 L  R741    
 L  R742    
 L  R743    
 L  R744    
 L  R745    
 L  R746    
 L  R747    
 L  R748    
 L  R749    
 L  R750    
 L  R751    
 L  R752    
 L  R753    
 L  R754    
 L  R755    
 L  R756    
 L  R757    
 L  R758    
 L  R759    
 L  R760    
 L  R761    
 L  R762    
 L  R763    
 L  R764    
 L  R765    
 L  R766    
 L  R767    
 L  R768    
 L  R769    
 L  R770    
 L  R771    
 L  R772    
 L  R773    
 L  R774    
 L  R775    
 L  R776    
 L  R777    
 L  R778    
 L  R779    
 L  R780    
 L  R781    
 L  R782    
 L  R783    
 L  R784    
 L  R785    
 L  R786    
 L  R787    
 L  R788    
 L  R789    
 L  R790    
 L  R791    
 L  R792    
 L  R793    
 L  R794    
 L  R795    
 L  R796    
 L  R797    
 L  R798    
 L  R799    
 L  R800    
 L  R801    
 L  R802    
 L  R803    
 L  R804    
 L  R805    
 L  R806    
 L  R807    
 L  R808    
 L  R809    
 L  R810    
 L  R811    
 L  R812    
 L  R813    
 L  R814    
 L  R815    
 L  R816    
 L  R817    
 L  R818    
 L  R819    
 L  R820    
 L  R821    
 L  R822    
 L  R823    
 L  R824    
 L  R825    
 L  R826    
 L  R827    
 L  R828    
 L  R829    
 L  R830    
 L  R831    
 L  R832    
 L  R833    
 L  R834    
 L  R835    
 L  R836    
 L  R837    
 L  R838    
 L  R839    
 L  R840    
 L  R841    
 L  R842    
 L  R843    
 L  R844    
 L  R845    
 L  R846    
 L  R847    
 L  R848    
 L  R849    
 L  R850    
 L  R851    
 L  R852    
 L  R853    
 L  R854    
 L  R855    
 L  R856    
 L  R857    
 L  R858    
 L  R859    
 L  R860    
 L  R861    
 L  R862    
 L  R863    
 L  R864    
 L  R865    
 L  R866    
 L  R867    
 L  R868    
 L  R869    
 L  R870    
 L  R871    
 L  R872    
 L  R873    
 L  R874    
 L  R875    
 L  R876    
 L  R877    
 L  R878    
 L  R879    
 L  R880    
 L  R881    
 L  R882    
 L  R883    
 L  R884    
 L  R885    
 L  R886    
 L  R887    
 L  R888    
 L  R889    
 L  R890    
 L  R891    
 L  R892    
 L  R893    
 L  R894    
 L  R895    
 L  R896    
 L  R897    
 L  R898    
 L  R899    
 L  R900    
 L  R901    
 L  R902    
 L  R903    
 L  R904    
 L  R905    
 L  R906    
 L  R907    
 L  R908    
 L  R909    
 L  R910    
 L  R911    
 L  R912    
 L  R913    
 L  R914    
 L  R915    
 L  R916    
 L  R917    
 L  R918    
 L  R919    
 L  R920    
 L  R921    
 L  R922    
 L  R923    
 L  R924    
 L  R925    
 L  R926    
 L  R927    
 L  R928    
 L  R929    
 L  R930    
 L  R931    
 L  R932    
 L  R933    
 L  R934    
 L  R935    
 L  R936    
 L  R937    
 L  R938    
 L  R939    
 L  R940    
 L  R941    
 L  R942    
 L  R943    
 L  R944    
 L  R945    
 L  R946    
 L  R947    
 L  R948    
 L  R949    
 L  R950    
 L  R951    
 L  R952    
 L  R953    
 L  R954    
 L  R955    
 L  R956    
 L  R957    
 L  R958    
 L  R959    
 L  R960    
 L  R961    
 L  R962    
 L  R963    
 L  R964    
 L  R965    
 L  R966    
 L  R967    
 L  R968    
 L  R969    
 L  R970    
 L  R971    
 L  R972    
 L  R973    
 L  R974    
 L  R975    
 L  R976    
 L  R977    
 L  R978    
 L  R979    
 L  R980    
 L  R981    
 L  R982    
 L  R983    
 L  R984    
 L  R985    
 L  R986    
 L  R987    
 L  R988    
 L  R989    
 L  R990    
 L  R991    
 L  R992    
 L  R993    
 L  R994    
 L  R995    
 L  R996    
 L  R997    
 L  R998    
 L  R999    
 L  R1000   
 L  R1001   
 L  R1002   
 L  R1003   
 L  R1004   
 L  R1005   
 L  R1006   
 L  R1007   
 L  R1008   
 L  R1009   
 L  R1010   
 L  R1011   
 L  R1012   
 L  R1013   
 L  R1014   
 L  R1015   
 L  R1016   
 L  R1017   
 L  R1018   
 L  R1019   
 L  R1020   
 L  R1021   
 L  R1022   
 L  R1023   
 L  R1024   
 L  R1025   
 L  R1026   
 L  R1027   
 L  R1028   
 L  R1029   
 L  R1030   
 L  R1031   
 L  R1032   
 L  R1033   
 L  R1034   
 L  R1035   
 L  R1036   
 L  R1037   
 L  R1038   
 L  R1039   
 L  R1040   
 L  R1041   
 L  R1042   
 L  R1043   
 L  R1044   
 L  R1045   
 L  R1046   
 L  R1047   
 L  R1048   
 L  R1049   
 L  R1050   
 L  R1051   
 L  R1052   
 L  R1053   
 L  R1054   
 L  R1055   
 L  R1056   
 L  R1057   
 L  R1058   
 L  R1059   
 L  R1060   
 L  R1061   
 L  R1062   
 L  R1063   
 L  R1064   
 L  R1065   
 L  R1066   
 L  R1067   
 L  R1068   
 L  R1069   
 L  R1070   
 L  R1071   
 L  R1072   
 L  R1073   
 L  R1074   
 L  R1075   
 L  R1076   
 L  R1077   
 L  R1078   
 L  R1079   
 L  R1080   
 L  R1081   
 L  R1082   
 L  R1083   
 L  R1084   
 L  R1085   
 L  R1086   
 L  R1087   
 L  R1088   
 L  R1089   
 L  R1090   
 L  R1091   
 L  R1092   
 L  R1093   
 L  R1094   
 L  R1095   
 L  R1096   
 L  R1097   
 L  R1098   
 L  R1099   
 L  R1100   
 L  R1101   
 L  R1102   
 L  R1103   
 L  R1104   
 L  R1105   
 L  R1106   
 L  R1107   
 L  R1108   
 L  R1109   
 L  R1110   
 L  R1111   
 L  R1112   
 L  R1113   
 L  R1114   
 L  R1115   
 L  R1116   
 L  R1117   
 L  R1118   
 L  R1119   
 L  R1120   
 L  R1121   
 L  R1122   
 L  R1123   
 L  R1124   
 L  R1125   
 L  R1126   
 L  R1127   
 L  R1128   
 L  R1129   
 L  R1130   
 L  R1131   
 L  R1132   
 L  R1133   
 L  R1134   
 L  R1135   
 L  R1136   
 L  R1137   
 L  R1138   
 L  R1139   
 L  R1140   
 L  R1141   
 L  R1142   
 L  R1143   
 L  R1144   
 L  R1145   
 L  R1146   
 L  R1147   
 L  R1148   
 L  R1149   
 L  R1150   
 L  R1151   
 L  R1152   
 L  R1153   
 L  R1154   
 L  R1155   
 L  R1156   
 L  R1157   
 L  R1158   
 L  R1159   
 L  R1160   
 L  R1161   
 L  R1162   
 L  R1163   
 L  R1164   
 L  R1165   
 L  R1166   
 L  R1167   
 L  R1168   
 L  R1169   
 L  R1170   
 L  R1171   
 L  R1172   
 L  R1173   
 L  R1174   
 L  R1175   
 L  R1176   
 L  R1177   
 L  R1178   
 L  R1179   
 L  R1180   
 L  R1181   
 L  R1182   
 L  R1183   
 L  R1184   
 L  R1185   
 L  R1186   
 L  R1187   
 L  R1188   
 L  R1189   
 L  R1190   
 L  R1191   
 L  R1192   
 L  R1193   
 L  R1194   
 L  R1195   
 L  R1196   
 L  R1197   
 L  R1198   
 L  R1199   
 L  R1200   
 L  R1201   
 L  R1202   
 L  R1203   
 L  R1204   
 L  R1205   
 L  R1206   
 L  R1207   
 L  R1208   
 L  R1209   
 L  R1210   
 L  R1211   
 L  R1212   
 L  R1213   
 L  R1214   
 L  R1215   
 L  R1216   
 L  R1217   
 L  R1218   
 L  R1219   
 L  R1220   
 L  R1221   
 L  R1222   
 L  R1223   
 L  R1224   
 L  R1225   
 L  R1226   
 L  R1227   
 L  R1228   
 L  R1229   
 L  R1230   
 L  R1231   
 L  R1232   
 L  R1233   
 L  R1234   
 L  R1235   
 L  R1236   
 L  R1237   
 L  R1238   
 L  R1239   
 L  R1240   
 L  R1241   
 L  R1242   
 L  R1243   
 L  R1244   
 L  R1245   
 L  R1246   
 L  R1247   
 L  R1248   
 L  R1249   
 L  R1250   
 L  R1251   
 L  R1252   
 L  R1253   
 L  R1254   
 L  R1255   
 L  R1256   
 L  R1257   
 L  R1258   
 L  R1259   
 L  R1260   
 L  R1261   
 L  R1262   
 L  R1263   
 L  R1264   
 L  R1265   
 L  R1266   
 L  R1267   
 L  R1268   
 L  R1269   
 L  R1270   
 L  R1271   
 L  R1272   
 L  R1273   
 L  R1274   
 L  R1275   
 L  R1276   
 L  R1277   
 L  R1278   
 L  R1279   
 L  R1280   
 L  R1281   
 L  R1282   
 L  R1283   
 L  R1284   
 L  R1285   
 L  R1286   
 L  R1287   
 L  R1288   
 L  R1289   
 L  R1290   
 L  R1291   
 L  R1292   
 L  R1293   
 L  R1294   
 L  R1295   
 L  R1296   
 L  R1297   
 L  R1298   
 L  R1299   
 L  R1300   
 L  R1301   
 L  R1302   
 L  R1303   
 L  R1304   
 L  R1305   
 L  R1306   
 L  R1307   
 L  R1308   
 L  R1309   
 L  R1310   
 L  R1311   
 L  R1312   
 L  R1313   
 L  R1314   
 L  R1315   
 L  R1316   
 L  R1317   
 L  R1318   
 L  R1319   
 L  R1320   
 L  R1321   
 L  R1322   
 L  R1323   
 L  R1324   
 L  R1325   
 L  R1326   
 L  R1327   
 L  R1328   
 L  R1329   
 L  R1330   
 L  R1331   
 L  R1332   
 L  R1333   
 L  R1334   
 L  R1335   
 L  R1336   
 L  R1337   
 L  R1338   
 L  R1339   
 L  R1340   
 L  R1341   
 L  R1342   
 L  R1343   
 L  R1344   
 L  R1345   
 L  R1346   
 L  R1347   
 L  R1348   
 L  R1349   
 L  R1350   
 L  R1351   
 L  R1352   
 L  R1353   
 L  R1354   
 L  R1355   
 L  R1356   
 L  R1357   
 L  R1358   
 L  R1359   
 L  R1360   
 L  R1361   
 L  R1362   
 L  R1363   
 L  R1364   
 L  R1365   
 L  R1366   
 L  R1367   
 L  R1368   
 L  R1369   
 L  R1370   
 L  R1371   
 L  R1372   
 L  R1373   
 L  R1374   
 L  R1375   
 L  R1376   
 L  R1377   
 L  R1378   
 L  R1379   
 L  R1380   
 L  R1381   
 L  R1382   
 L  R1383   
 L  R1384   
 L  R1385   
 L  R1386   
 L  R1387   
 L  R1388   
 L  R1389   
 L  R1390   
 L  R1391   
 L  R1392   
 L  R1393   
 L  R1394   
 L  R1395   
 L  R1396   
 L  R1397   
 L  R1398   
 L  R1399   
 L  R1400   
 L  R1401   
 L  R1402   
 L  R1403   
 L  R1404   
 L  R1405   
 L  R1406   
 L  R1407   
 L  R1408   
 L  R1409   
 L  R1410   
 L  R1411   
 L  R1412   
 L  R1413   
 L  R1414   
 L  R1415   
 L  R1416   
 L  R1417   
 L  R1418   
 L  R1419   
 L  R1420   
 L  R1421   
 L  R1422   
 L  R1423   
 L  R1424   
 L  R1425   
 L  R1426   
 L  R1427   
 L  R1428   
 L  R1429   
 L  R1430   
 L  R1431   
 L  R1432   
 L  R1433   
 L  R1434   
 L  R1435   
 L  R1436   
 L  R1437   
 L  R1438   
 L  R1439   
 L  R1440   
 L  R1441   
 L  R1442   
 L  R1443   
 L  R1444   
 L  R1445   
 L  R1446   
 L  R1447   
 L  R1448   
 L  R1449   
 L  R1450   
 L  R1451   
 L  R1452   
 L  R1453   
 L  R1454   
 L  R1455   
 L  R1456   
 L  R1457   
 L  R1458   
 L  R1459   
 L  R1460   
 L  R1461   
 L  R1462   
 L  R1463   
 L  R1464   
 L  R1465   
 L  R1466   
 L  R1467   
 L  R1468   
 L  R1469   
 L  R1470   
 L  R1471   
 L  R1472   
 L  R1473   
 L  R1474   
 L  R1475   
 L  R1476   
 L  R1477   
 L  R1478   
 L  R1479   
 L  R1480   
 L  R1481   
 L  R1482   
 L  R1483   
 L  R1484   
 L  R1485   
 L  R1486   
 L  R1487   
 L  R1488   
 L  R1489   
 L  R1490   
 L  R1491   
 L  R1492   
 L  R1493   
 L  R1494   
 L  R1495   
 L  R1496   
 L  R1497   
 L  R1498   
 L  R1499   
 L  R1500   
 L  R1501   
 L  R1502   
 L  R1503   
 L  R1504   
 L  R1505   
 L  R1506   
 L  R1507   
 L  R1508   
 L  R1509   
 L  R1510   
 L  R1511   
 L  R1512   
 L  R1513   
 L  R1514   
 L  R1515   
 L  R1516   
 L  R1517   
 L  R1518   
 L  R1519   
 L  R1520   
 L  R1521   
 L  R1522   
 L  R1523   
 L  R1524   
 L  R1525   
 L  R1526   
 L  R1527   
 L  R1528   
 L  R1529   
 L  R1530   
 L  R1531   
 L  R1532   
 L  R1533   
 L  R1534   
 L  R1535   
 L  R1536   
 L  R1537   
 L  R1538   
 L  R1539   
 L  R1540   
 L  R1541   
 L  R1542   
 L  R1543   
 L  R1544   
 L  R1545   
 L  R1546   
 L  R1547   
 L  R1548   
 L  R1549   
 L  R1550   
 L  R1551   
 L  R1552   
 L  R1553   
 L  R1554   
 L  R1555   
 L  R1556   
 L  R1557   
 L  R1558   
 L  R1559   
 L  R1560   
 L  R1561   
 L  R1562   
 L  R1563   
 L  R1564   
 L  R1565   
 L  R1566   
 L  R1567   
 L  R1568   
 L  R1569   
 L  R1570   
 L  R1571   
 L  R1572   
 L  R1573   
 L  R1574   
 L  R1575   
 L  R1576   
 L  R1577   
 L  R1578   
 L  R1579   
 L  R1580   
 L  R1581   
 L  R1582   
 L  R1583   
 L  R1584   
 L  R1585   
 L  R1586   
 L  R1587   
 L  R1588   
 L  R1589   
 L  R1590   
 L  R1591   
 L  R1592   
 L  R1593   
 L  R1594   
 L  R1595   
 L  R1596   
 L  R1597   
 L  R1598   
 L  R1599   
 L  R1600   
 L  R1601   
 L  R1602   
 L  R1603   
 L  R1604   
 L  R1605   
 L  R1606   
 L  R1607   
 L  R1608   
 L  R1609   
 L  R1610   
 L  R1611   
 L  R1612   
 L  R1613   
 L  R1614   
 L  R1615   
 L  R1616   
 L  R1617   
 L  R1618   
 L  R1619   
 L  R1620   
 L  R1621   
 L  R1622   
 L  R1623   
 L  R1624   
 L  R1625   
 L  R1626   
 L  R1627   
 L  R1628   
 L  R1629   
 L  R1630   
 L  R1631   
 L  R1632   
 L  R1633   
 L  R1634   
 L  R1635   
 L  R1636   
 L  R1637   
 L  R1638   
 L  R1639   
 L  R1640   
 L  R1641   
 L  R1642   
 L  R1643   
 L  R1644   
 L  R1645   
 L  R1646   
 L  R1647   
 L  R1648   
 L  R1649   
 L  R1650   
 L  R1651   
 L  R1652   
 L  R1653   
 L  R1654   
 L  R1655   
 L  R1656   
 L  R1657   
 L  R1658   
 L  R1659   
 L  R1660   
 L  R1661   
 L  R1662   
 L  R1663   
 L  R1664   
 L  R1665   
 L  R1666   
 L  R1667   
 L  R1668   
 L  R1669   
 L  R1670   
 L  R1671   
 L  R1672   
 L  R1673   
 L  R1674   
 L  R1675   
 L  R1676   
 L  R1677   
 L  R1678   
 L  R1679   
 L  R1680   
 L  R1681   
 L  R1682   
 L  R1683   
 L  R1684   
 L  R1685   
 L  R1686   
 L  R1687   
 L  R1688   
 L  R1689   
 L  R1690   
 L  R1691   
 L  R1692   
 L  R1693   
 L  R1694   
 L  R1695   
 L  R1696   
 L  R1697   
 L  R1698   
 L  R1699   
 L  R1700   
 L  R1701   
 L  R1702   
 L  R1703   
 L  R1704   
 L  R1705   
 L  R1706   
 L  R1707   
 L  R1708   
 L  R1709   
 L  R1710   
 L  R1711   
 L  R1712   
 L  R1713   
 L  R1714   
 L  R1715   
 L  R1716   
 L  R1717   
 L  R1718   
 L  R1719   
 L  R1720   
 L  R1721   
 L  R1722   
 L  R1723   
 L  R1724   
 L  R1725   
 L  R1726   
 L  R1727   
 L  R1728   
 L  R1729   
 L  R1730   
 L  R1731   
 L  R1732   
 L  R1733   
 L  R1734   
 L  R1735   
 L  R1736   
 L  R1737   
 L  R1738   
 L  R1739   
 L  R1740   
 L  R1741   
 L  R1742   
 L  R1743   
 L  R1744   
 L  R1745   
 L  R1746   
 L  R1747   
 L  R1748   
 L  R1749   
 L  R1750   
 L  R1751   
 L  R1752   
 L  R1753   
 L  R1754   
 L  R1755   
 L  R1756   
 L  R1757   
 L  R1758   
 L  R1759   
 L  R1760   
 L  R1761   
 L  R1762   
 L  R1763   
 L  R1764   
 L  R1765   
 L  R1766   
 L  R1767   
 L  R1768   
 L  R1769   
 L  R1770   
 L  R1771   
 L  R1772   
 L  R1773   
 L  R1774   
 L  R1775   
 L  R1776   
 L  R1777   
 L  R1778   
 L  R1779   
 L  R1780   
 L  R1781   
 L  R1782   
 L  R1783   
 L  R1784   
 L  R1785   
 L  R1786   
 L  R1787   
 L  R1788   
 L  R1789   
 L  R1790   
 L  R1791   
 L  R1792   
 L  R1793   
 L  R1794   
 L  R1795   
 L  R1796   
 L  R1797   
 L  R1798   
 L  R1799   
 L  R1800   
 L  R1801   
 L  R1802   
 L  R1803   
 L  R1804   
 L  R1805   
 L  R1806   
 L  R1807   
 L  R1808   
 L  R1809   
 L  R1810   
 L  R1811   
 L  R1812   
 L  R1813   
 L  R1814   
 L  R1815   
 L  R1816   
 L  R1817   
 L  R1818   
 L  R1819   
 L  R1820   
 L  R1821   
 L  R1822   
 L  R1823   
 L  R1824   
 L  R1825   
 L  R1826   
 L  R1827   
 L  R1828   
 L  R1829   
 L  R1830   
 L  R1831   
 L  R1832   
 L  R1833   
 L  R1834   
 L  R1835   
 L  R1836   
 L  R1837   
 L  R1838   
 L  R1839   
 L  R1840   
 L  R1841   
 L  R1842   
 L  R1843   
 L  R1844   
 L  R1845   
 L  R1846   
 L  R1847   
 L  R1848   
 L  R1849   
 L  R1850   
 L  R1851   
 L  R1852   
 L  R1853   
 L  R1854   
 L  R1855   
 L  R1856   
 L  R1857   
 L  R1858   
 L  R1859   
 L  R1860   
 L  R1861   
 L  R1862   
 L  R1863   
 L  R1864   
 L  R1865   
 L  R1866   
 L  R1867   
 L  R1868   
 L  R1869   
 L  R1870   
 L  R1871   
 L  R1872   
 L  R1873   
 L  R1874   
 L  R1875   
 L  R1876   
 L  R1877   
 L  R1878   
 L  R1879   
 L  R1880   
 L  R1881   
 L  R1882   
 L  R1883   
 L  R1884   
 L  R1885   
 L  R1886   
 L  R1887   
 L  R1888   
 L  R1889   
 L  R1890   
 L  R1891   
 L  R1892   
 L  R1893   
 L  R1894   
 L  R1895   
 L  R1896   
 L  R1897   
 L  R1898   
 L  R1899   
 L  R1900   
 L  R1901   
 L  R1902   
 L  R1903   
 L  R1904   
 L  R1905   
 L  R1906   
 L  R1907   
 L  R1908   
 L  R1909   
 L  R1910   
 L  R1911   
 L  R1912   
 L  R1913   
 L  R1914   
 L  R1915   
 L  R1916   
 L  R1917   
 L  R1918   
 L  R1919   
 L  R1920   
 L  R1921   
 L  R1922   
 L  R1923   
 L  R1924   
 L  R1925   
 L  R1926   
 L  R1927   
 L  R1928   
 L  R1929   
 L  R1930   
 L  R1931   
 L  R1932   
 L  R1933   
 L  R1934   
 L  R1935   
 L  R1936   
 L  R1937   
 L  R1938   
 L  R1939   
 L  R1940   
 L  R1941   
 L  R1942   
 L  R1943   
 L  R1944   
 L  R1945   
 L  R1946   
 L  R1947   
 L  R1948   
 L  R1949   
 L  R1950   
 L  R1951   
 L  R1952   
 L  R1953   
 L  R1954   
 L  R1955   
 L  R1956   
 L  R1957   
 L  R1958   
 L  R1959   
 L  R1960   
 L  R1961   
 L  R1962   
 L  R1963   
 L  R1964   
 L  R1965   
 L  R1966   
 L  R1967   
 L  R1968   
 L  R1969   
 L  R1970   
 L  R1971   
 L  R1972   
 L  R1973   
 L  R1974   
 L  R1975   
 L  R1976   
 L  R1977   
 L  R1978   
 L  R1979   
 L  R1980   
 L  R1981   
 L  R1982   
 L  R1983   
 L  R1984   
 L  R1985   
 L  R1986   
 L  R1987   
 L  R1988   
 L  R1989   
 L  R1990   
 L  R1991   
 L  R1992   
 L  R1993   
 L  R1994   
 L  R1995   
 L  R1996   
 L  R1997   
 L  R1998   
 L  R1999   
 L  R2000   
 L  R2001   
 L  R2002   
 L  R2003   
 L  R2004   
 L  R2005   
 L  R2006   
 L  R2007   
 L  R2008   
 L  R2009   
 L  R2010   
 L  R2011   
 L  R2012   
 L  R2013   
 L  R2014   
 L  R2015   
 L  R2016   
 L  R2017   
 L  R2018   
 L  R2019   
 L  R2020   
 L  R2021   
 L  R2022   
 L  R2023   
 L  R2024   
 L  R2025   
 L  R2026   
 L  R2027   
 L  R2028   
 L  R2029   
 L  R2030   
 L  R2031   
 L  R2032   
 L  R2033   
 L  R2034   
 L  R2035   
 L  R2036   
 L  R2037   
 L  R2038   
 L  R2039   
 L  R2040   
 L  R2041   
 L  R2042   
 L  R2043   
 L  R2044   
 L  R2045   
 L  R2046   
 L  R2047   
 L  R2048   
 L  R2049   
 L  R2050   
 L  R2051   
 L  R2052   
 L  R2053   
 L  R2054   
 L  R2055   
 L  R2056   
 L  R2057   
 L  R2058   
 L  R2059   
 L  R2060   
 L  R2061   
 L  R2062   
 L  R2063   
 L  R2064   
 L  R2065   
 L  R2066   
 L  R2067   
 L  R2068   
 L  R2069   
 L  R2070   
 L  R2071   
 L  R2072   
 L  R2073   
 L  R2074   
 L  R2075   
 L  R2076   
 L  R2077   
 L  R2078   
 L  R2079   
 L  R2080   
 L  R2081   
 L  R2082   
 L  R2083   
 L  R2084   
 L  R2085   
 L  R2086   
 L  R2087   
 L  R2088   
 L  R2089   
 L  R2090   
 L  R2091   
 L  R2092   
 L  R2093   
 L  R2094   
 L  R2095   
 L  R2096   
 L  R2097   
 L  R2098   
 L  R2099   
 L  R2100   
 L  R2101   
 L  R2102   
 L  R2103   
 L  R2104   
 L  R2105   
 L  R2106   
 L  R2107   
 L  R2108   
 L  R2109   
 L  R2110   
 L  R2111   
 L  R2112   
 L  R2113   
 L  R2114   
 L  R2115   
 L  R2116   
 L  R2117   
 L  R2118   
 L  R2119   
 L  R2120   
 L  R2121   
 L  R2122   
 L  R2123   
 L  R2124   
 L  R2125   
 L  R2126   
 L  R2127   
 L  R2128   
 L  R2129   
 L  R2130   
 L  R2131   
 L  R2132   
 L  R2133   
 L  R2134   
 L  R2135   
 L  R2136   
 L  R2137   
 L  R2138   
 L  R2139   
 L  R2140   
 L  R2141   
 L  R2142   
 L  R2143   
 L  R2144   
 L  R2145   
 L  R2146   
 L  R2147   
 L  R2148   
 L  R2149   
 L  R2150   
 L  R2151   
 L  R2152   
 L  R2153   
 L  R2154   
 L  R2155   
 L  R2156   
 L  R2157   
 L  R2158   
 L  R2159   
 L  R2160   
 L  R2161   
 L  R2162   
 L  R2163   
 L  R2164   
 L  R2165   
 L  R2166   
 L  R2167   
 L  R2168   
 L  R2169   
 L  R2170   
 L  R2171   
 L  R2172   
 L  R2173   
 L  R2174   
 L  R2175   
 L  R2176   
 L  R2177   
 L  R2178   
 L  R2179   
 L  R2180   
 L  R2181   
 L  R2182   
 L  R2183   
 L  R2184   
 L  R2185   
 L  R2186   
 L  R2187   
 L  R2188   
 L  R2189   
 L  R2190   
 L  R2191   
 L  R2192   
 L  R2193   
 L  R2194   
 L  R2195   
 L  R2196   
 L  R2197   
 L  R2198   
 L  R2199   
 L  R2200   
 L  R2201   
 L  R2202   
 L  R2203   
 L  R2204   
 L  R2205   
 L  R2206   
 L  R2207   
 L  R2208   
 L  R2209   
 L  R2210   
 L  R2211   
 L  R2212   
 L  R2213   
 L  R2214   
 L  R2215   
 L  R2216   
 L  R2217   
 L  R2218   
 L  R2219   
 L  R2220   
 L  R2221   
 L  R2222   
 L  R2223   
 L  R2224   
 L  R2225   
 L  R2226   
 L  R2227   
 L  R2228   
 L  R2229   
 L  R2230   
 L  R2231   
 L  R2232   
 L  R2233   
 L  R2234   
 L  R2235   
 L  R2236   
 L  R2237   
 L  R2238   
 L  R2239   
 L  R2240   
 L  R2241   
 L  R2242   
 L  R2243   
 L  R2244   
 L  R2245   
 L  R2246   
 L  R2247   
 L  R2248   
 L  R2249   
 L  R2250   
 L  R2251   
 L  R2252   
 L  R2253   
 L  R2254   
 L  R2255   
 L  R2256   
 L  R2257   
 L  R2258   
 L  R2259   
 L  R2260   
 L  R2261   
 L  R2262   
 L  R2263   
 L  R2264   
 L  R2265   
 L  R2266   
 L  R2267   
 L  R2268   
 L  R2269   
 L  R2270   
 L  R2271   
 L  R2272   
 L  R2273   
 L  R2274   
 L  R2275   
 L  R2276   
 L  R2277   
 L  R2278   
 L  R2279   
 L  R2280   
 L  R2281   
 L  R2282   
 L  R2283   
 L  R2284   
 L  R2285   
 L  R2286   
 L  R2287   
 L  R2288   
 L  R2289   
 L  R2290   
 L  R2291   
 L  R2292   
 L  R2293   
 L  R2294   
 L  R2295   
 L  R2296   
 L  R2297   
 L  R2298   
 L  R2299   
 L  R2300   
 L  R2301   
 L  R2302   
 L  R2303   
 L  R2304   
 L  R2305   
 L  R2306   
 L  R2307   
 L  R2308   
 L  R2309   
 L  R2310   
 L  R2311   
 L  R2312   
 L  R2313   
 L  R2314   
 L  R2315   
 L  R2316   
 L  R2317   
 L  R2318   
 L  R2319   
 L  R2320   
 L  R2321   
 L  R2322   
 L  R2323   
 L  R2324   
 L  R2325   
 L  R2326   
 L  R2327   
 L  R2328   
 L  R2329   
 L  R2330   
 L  R2331   
 L  R2332   
 L  R2333   
 L  R2334   
 L  R2335   
 L  R2336   
 L  R2337   
 L  R2338   
 L  R2339   
 L  R2340   
 L  R2341   
 L  R2342   
 L  R2343   
 L  R2344   
 L  R2345   
 L  R2346   
 L  R2347   
 L  R2348   
 L  R2349   
 L  R2350   
 L  R2351   
 L  R2352   
 L  R2353   
 L  R2354   
 L  R2355   
 L  R2356   
 L  R2357   
 L  R2358   
 L  R2359   
 L  R2360   
 L  R2361   
 L  R2362   
 L  R2363   
 L  R2364   
 L  R2365   
 L  R2366   
 L  R2367   
 L  R2368   
 L  R2369   
 L  R2370   
 L  R2371   
 L  R2372   
 L  R2373   
 L  R2374   
 L  R2375   
 L  R2376   
 L  R2377   
 L  R2378   
 L  R2379   
 L  R2380   
 L  R2381   
 L  R2382   
 L  R2383   
 L  R2384   
 L  R2385   
 L  R2386   
 L  R2387   
 L  R2388   
 L  R2389   
 L  R2390   
 L  R2391   
 L  R2392   
 L  R2393   
 L  R2394   
 L  R2395   
 L  R2396   
 L  R2397   
 L  R2398   
 L  R2399   
 L  R2400   
 L  R2401   
 L  R2402   
 L  R2403   
 L  R2404   
 L  R2405   
 L  R2406   
 L  R2407   
 L  R2408   
 L  R2409   
 L  R2410   
 L  R2411   
 L  R2412   
 L  R2413   
 L  R2414   
 L  R2415   
 L  R2416   
 L  R2417   
 L  R2418   
 L  R2419   
 L  R2420   
 L  R2421   
 L  R2422   
 L  R2423   
 L  R2424   
 L  R2425   
 L  R2426   
 L  R2427   
 L  R2428   
 L  R2429   
 L  R2430   
 L  R2431   
 L  R2432   
 L  R2433   
 L  R2434   
 L  R2435   
 L  R2436   
 L  R2437   
 L  R2438   
 L  R2439   
 L  R2440   
 L  R2441   
 L  R2442   
 L  R2443   
 L  R2444   
 L  R2445   
 L  R2446   
 L  R2447   
 L  R2448   
 L  R2449   
 L  R2450   
 L  R2451   
 L  R2452   
 L  R2453   
 L  R2454   
 L  R2455   
 L  R2456   
 L  R2457   
 L  R2458   
 L  R2459   
 L  R2460   
 L  R2461   
 L  R2462   
 L  R2463   
 L  R2464   
 L  R2465   
 L  R2466   
 L  R2467   
 L  R2468   
 L  R2469   
 L  R2470   
 L  R2471   
 L  R2472   
 L  R2473   
 L  R2474   
 L  R2475   
 L  R2476   
 L  R2477   
 L  R2478   
 L  R2479   
 L  R2480   
 L  R2481   
 L  R2482   
 L  R2483   
 L  R2484   
 L  R2485   
 L  R2486   
 L  R2487   
 L  R2488   
 L  R2489   
 L  R2490   
 L  R2491   
 L  R2492   
 L  R2493   
 L  R2494   
 L  R2495   
 L  R2496   
 L  R2497   
 L  R2498   
 L  R2499   
 L  R2500   
 L  R2501   
 L  R2502   
 L  R2503   
 L  R2504   
 L  R2505   
 L  R2506   
 L  R2507   
 L  R2508   
 L  R2509   
 L  R2510   
 L  R2511   
 L  R2512   
 L  qc0     
 L  qc1     
 L  qc2     
 L  qc3     
 L  qc4     
 L  qc5     
 L  qc6     
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    phi[0,1]  R0        1
    phi[0,1]  R1        1
    phi[0,1]  R9        -1
    phi[0,1]  R65       -3.0999999046325684e+00
    phi[0,1]  R66       -3.0999999046325684e+00
    phi[0,1]  R67       -2.2400000095367432e+00
    phi[0,1]  R68       -2.2400000095367432e+00
    phi[0,1]  R69       -3.0999999046325684e+00
    phi[0,1]  R70       -3.0999999046325684e+00
    phi[0,1]  R71       -2.5699999332427979e+00
    phi[0,1]  R72       -2.5699999332427979e+00
    phi[0,1]  R73       -3.0999999046325684e+00
    phi[0,1]  R74       -3.0999999046325684e+00
    phi[0,1]  R75       -2.0899999141693115e+00
    phi[0,1]  R76       -2.0899999141693115e+00
    phi[0,1]  R77       -3.0999999046325684e+00
    phi[0,1]  R78       -3.0999999046325684e+00
    phi[0,1]  R79       1.1691654920578003e+00
    phi[0,1]  R80       6.3939285278320312e-01
    phi[0,1]  R81       9.4822531938552856e-01
    phi[0,1]  R82       5.2110958099365234e-01
    phi[0,1]  R83       1.0326553583145142e+00
    phi[0,1]  R84       1.1823796033859253e+00
    phi[0,1]  R85       1.0785428285598755e+00
    phi[0,1]  R86       1.2203266620635986e+00
    phi[0,1]  R87       1.2297185659408569e+00
    phi[0,1]  R88       1.4851337671279907e+00
    phi[0,1]  R89       -1.4736955165863037e+00
    phi[0,1]  R90       -2.1335701942443848e+00
    phi[0,1]  R91       -1.7571489810943604e+00
    phi[0,1]  R92       -2.2089893817901611e+00
    phi[0,1]  R93       -1.8819338083267212e+00
    phi[0,1]  R94       -1.4536508321762085e+00
    phi[0,1]  R95       -2.1631021499633789e+00
    phi[0,1]  R96       -1.96341872215271
    phi[0,1]  R97       -1.6787276268005371e+00
    phi[0,1]  R98       -4.63515567779541
    phi[0,1]  R99       -1.4982165098190308e+00
    phi[0,1]  R100      -1.0513086318969727e+00
    phi[0,1]  R101      -1.4054069519042969e+00
    phi[0,1]  R102      -1.7032458782196045e+00
    phi[0,1]  R103      -3.4826068878173828e+00
    phi[0,1]  R104      -6.1507481336593628e-01
    phi[0,1]  R105      -1.5091440677642822e+00
    phi[0,1]  R106      -4.7398188710212708e-01
    phi[0,1]  R107      -1.3527140617370605e+00
    phi[0,1]  R108      -1.27840256690979
    phi[0,1]  R109      -1.00215744972229
    phi[0,1]  R110      -7.1374821662902832e-01
    phi[0,1]  R111      -5.1703453063964844e-02
    phi[0,1]  R112      -2.9921853542327881e+00
    phi[0,1]  R113      -1.5951668024063110e+00
    phi[0,1]  R114      -2.5576024055480957e+00
    phi[0,1]  R115      -3.3277451992034912e+00
    phi[0,1]  R116      -1.5481046438217163e+00
    phi[0,1]  R117      -1.7955756187438965e+00
    phi[0,1]  R118      -2.8969542980194092e+00
    phi[0,1]  R119      -3.0358207225799561e+00
    phi[0,1]  R120      -2.0783517360687256e+00
    phi[0,1]  R121      -9.4535845518112183e-01
    phi[0,1]  R122      -6.9302612543106079e-01
    phi[0,1]  R123      -1.4112701416015625e+00
    phi[0,1]  R124      -0.714901864528656
    phi[0,1]  R125      -4.3908256292343140e-01
    phi[0,1]  R126      -3.1412191390991211e+00
    phi[0,1]  R127      -4.8646691441535950e-01
    phi[0,1]  R128      -4.0691375732421875e-01
    phi[0,1]  R129      6.2556117773056030e-02
    phi[0,1]  R130      9.6740698814392090e-01
    phi[0,1]  R131      7.4404346942901611e-01
    phi[0,1]  R132      4.2306506633758545e-01
    phi[0,1]  R133      0.801608145236969
    phi[0,1]  R134      1.9694203138351440e-01
    phi[0,1]  R135      3.4496402740478516e-01
    phi[0,1]  R136      0.874773383140564
    phi[0,1]  R137      4.6939593553543091e-01
    phi[0,1]  R138      8.6967945098876953e-01
    phi[0,1]  R139      -1.8018673658370972e+00
    phi[0,1]  R140      -1.6787379980087280e+00
    phi[0,1]  R141      -8.1126272678375244e-01
    phi[0,1]  R142      -2.0037531852722168e+00
    phi[0,1]  R143      -2.1069307327270508e+00
    phi[0,1]  R144      -1.2515301704406738e+00
    phi[0,1]  R145      -1.5814245939254761e+00
    phi[0,1]  R146      -2.0014057159423828e+00
    phi[0,1]  R147      -1.8219569921493530e+00
    phi[0,1]  R148      9.0164966881275177e-02
    phi[0,1]  R149      -1.4933149814605713e+00
    phi[0,1]  R150      -2.0219403505325317e-01
    phi[0,1]  R151      -1.9593131542205811e+00
    phi[0,1]  R152      -1.2331484556198120e+00
    phi[0,1]  R153      -8.1905007362365723e-01
    phi[0,1]  R154      -1.9005004167556763e+00
    phi[0,1]  R155      -2.3031768798828125e+00
    phi[0,1]  R156      -2.1969819068908691e+00
    phi[0,1]  R157      4.3382960557937622e-01
    phi[0,1]  R158      -2.0276033878326416e+00
    phi[0,1]  R159      1.2017848342657089e-01
    phi[0,1]  R160      -1.2630753517150879e+00
    phi[0,1]  R161      -1.1359472274780273e+00
    phi[0,1]  R162      -1.9994518756866455e+00
    phi[0,1]  R163      -2.1688213348388672e+00
    phi[0,1]  R164      -2.6111125946044922e+00
    phi[0,1]  R165      -1.5152133703231812e+00
    phi[0,1]  R166      -1.4248226881027222e+00
    phi[0,1]  R167      -2.3244929313659668e+00
    phi[0,1]  R168      -1.2592172622680664e+00
    phi[0,1]  R169      1.2390511482954025e-01
    phi[0,1]  R170      9.3042838573455811e-01
    phi[0,1]  R171      3.2924869656562805e-01
    phi[0,1]  R172      -1.9579730033874512e+00
    phi[0,1]  R173      -1.8124901056289673e+00
    phi[0,1]  R174      -1.1141886711120605e+00
    phi[0,1]  R175      -2.2809672355651855e+00
    phi[0,1]  R176      -2.3023803234100342e+00
    phi[0,1]  R177      -3.0915312767028809e+00
    phi[0,1]  R178      -1.4350209236145020e+00
    phi[0,1]  R179      -0.0541786327958107
    phi[0,1]  R180      -1.8928896188735962e+00
    phi[0,1]  R181      -2.0521986484527588e+00
    phi[0,1]  R182      -9.1291368007659912e-01
    phi[0,1]  R183      -8.6685991287231445e-01
    phi[0,1]  R184      -2.1188676357269287e+00
    phi[0,1]  R185      -2.6802144050598145e+00
    phi[0,1]  R186      -1.5685625076293945e+00
    phi[0,1]  R187      -2.9002516269683838e+00
    phi[0,1]  R188      -2.0382649898529053e+00
    phi[0,1]  R189      -1.8577950000762939e+00
    phi[0,1]  R190      -9.5404225587844849e-01
    phi[0,1]  R191      -1.8620798587799072e+00
    phi[0,1]  R192      -2.3914270401000977e+00
    phi[0,1]  R193      -2.7600278854370117e+00
    phi[0,1]  R194      -2.0670785903930664e+00
    phi[0,1]  R195      -1.9353444576263428e+00
    phi[0,1]  R196      -2.5543472766876221e+00
    phi[0,1]  R197      -2.6044440269470215e-01
    phi[0,1]  R198      -4.7267064452171326e-01
    phi[0,1]  R199      -1.1235343217849731e+00
    phi[0,1]  R200      -1.4717134237289429e+00
    phi[0,1]  R201      -1.7904587984085083e+00
    phi[0,1]  R202      -2.3280544281005859e+00
    phi[0,1]  R203      -2.3715248107910156e+00
    phi[0,1]  R204      -7.3227733373641968e-01
    phi[0,1]  R205      -3.3421175479888916e+00
    phi[0,1]  R206      -1.7074190378189087e+00
    phi[0,1]  R207      -2.9913179874420166e+00
    phi[0,1]  R208      -2.9782578945159912e+00
    phi[0,1]  R209      -1.1243221759796143e+00
    phi[0,1]  R210      -1.2983950376510620e+00
    phi[0,1]  R211      -1.3386058807373047e+00
    phi[0,1]  R212      -2.0038964748382568e+00
    phi[0,1]  R213      -2.7051808834075928e+00
    phi[0,1]  R214      -8.7630116939544678e-01
    phi[0,1]  R215      -2.7382895350456238e-01
    phi[0,1]  R216      -1.5187896490097046e+00
    phi[0,1]  R217      -3.4117621183395386e-01
    phi[0,1]  R218      -7.3416489362716675e-01
    phi[0,1]  R219      -1.1582061052322388e+00
    phi[0,1]  R220      -1.4588338136672974e+00
    phi[0,1]  R221      -1.4751677513122559e+00
    phi[0,1]  R222      -1.6267303228378296e+00
    phi[0,1]  R223      -2.5352110862731934e+00
    phi[0,1]  R224      -2.8484699130058289e-01
    phi[0,1]  R225      -6.8311071395874023e-01
    phi[0,1]  R226      -5.0120645761489868e-01
    phi[0,1]  R227      -1.2715778350830078e+00
    phi[0,1]  R228      -0.700590968132019
    phi[1,0]  R0        -1
    phi[1,0]  R9        1
    phi[1,0]  R10       1
    phi[1,0]  R229      -3.0999999046325684e+00
    phi[1,0]  R230      -3.0999999046325684e+00
    phi[1,0]  R231      -2.2400000095367432e+00
    phi[1,0]  R232      -2.2400000095367432e+00
    phi[1,0]  R233      -3.0999999046325684e+00
    phi[1,0]  R234      -3.0999999046325684e+00
    phi[1,0]  R235      -2.5699999332427979e+00
    phi[1,0]  R236      -2.5699999332427979e+00
    phi[1,0]  R237      -3.0999999046325684e+00
    phi[1,0]  R238      -3.0999999046325684e+00
    phi[1,0]  R239      -2.0899999141693115e+00
    phi[1,0]  R240      -2.0899999141693115e+00
    phi[1,0]  R241      -3.0999999046325684e+00
    phi[1,0]  R242      -3.0999999046325684e+00
    phi[1,0]  R243      6.2556117773056030e-02
    phi[1,0]  R244      9.6740698814392090e-01
    phi[1,0]  R245      7.4404346942901611e-01
    phi[1,0]  R246      4.2306506633758545e-01
    phi[1,0]  R247      0.801608145236969
    phi[1,0]  R248      1.9694203138351440e-01
    phi[1,0]  R249      3.4496402740478516e-01
    phi[1,0]  R250      0.874773383140564
    phi[1,0]  R251      4.6939593553543091e-01
    phi[1,0]  R252      8.6967945098876953e-01
    phi[1,0]  R253      -1.8018673658370972e+00
    phi[1,0]  R254      -1.6787379980087280e+00
    phi[1,0]  R255      -8.1126272678375244e-01
    phi[1,0]  R256      -2.0037531852722168e+00
    phi[1,0]  R257      -2.1069307327270508e+00
    phi[1,0]  R258      -1.2515301704406738e+00
    phi[1,0]  R259      -1.5814245939254761e+00
    phi[1,0]  R260      -2.0014057159423828e+00
    phi[1,0]  R261      -1.8219569921493530e+00
    phi[1,0]  R262      9.0164966881275177e-02
    phi[1,0]  R263      -1.4933149814605713e+00
    phi[1,0]  R264      -2.0219403505325317e-01
    phi[1,0]  R265      -1.9593131542205811e+00
    phi[1,0]  R266      -1.2331484556198120e+00
    phi[1,0]  R267      -8.1905007362365723e-01
    phi[1,0]  R268      -1.9005004167556763e+00
    phi[1,0]  R269      -2.3031768798828125e+00
    phi[1,0]  R270      -2.1969819068908691e+00
    phi[1,0]  R271      4.3382960557937622e-01
    phi[1,0]  R272      -2.0276033878326416e+00
    phi[1,0]  R273      1.2017848342657089e-01
    phi[1,0]  R274      -1.2630753517150879e+00
    phi[1,0]  R275      -1.1359472274780273e+00
    phi[1,0]  R276      -1.9994518756866455e+00
    phi[1,0]  R277      -2.1688213348388672e+00
    phi[1,0]  R278      -2.6111125946044922e+00
    phi[1,0]  R279      -1.5152133703231812e+00
    phi[1,0]  R280      -1.4248226881027222e+00
    phi[1,0]  R281      -2.3244929313659668e+00
    phi[1,0]  R282      -1.2592172622680664e+00
    phi[1,0]  R283      1.2390511482954025e-01
    phi[1,0]  R284      9.3042838573455811e-01
    phi[1,0]  R285      3.2924869656562805e-01
    phi[1,0]  R286      -1.9579730033874512e+00
    phi[1,0]  R287      -1.8124901056289673e+00
    phi[1,0]  R288      -1.1141886711120605e+00
    phi[1,0]  R289      -2.2809672355651855e+00
    phi[1,0]  R290      -2.3023803234100342e+00
    phi[1,0]  R291      -3.0915312767028809e+00
    phi[1,0]  R292      -1.4350209236145020e+00
    phi[1,0]  R293      -0.0541786327958107
    phi[1,0]  R294      -1.8928896188735962e+00
    phi[1,0]  R295      -2.0521986484527588e+00
    phi[1,0]  R296      -9.1291368007659912e-01
    phi[1,0]  R297      -8.6685991287231445e-01
    phi[1,0]  R298      -2.1188676357269287e+00
    phi[1,0]  R299      -2.6802144050598145e+00
    phi[1,0]  R300      -1.5685625076293945e+00
    phi[1,0]  R301      -2.9002516269683838e+00
    phi[1,0]  R302      -2.0382649898529053e+00
    phi[1,0]  R303      -1.8577950000762939e+00
    phi[1,0]  R304      -9.5404225587844849e-01
    phi[1,0]  R305      -1.8620798587799072e+00
    phi[1,0]  R306      -2.3914270401000977e+00
    phi[1,0]  R307      -2.7600278854370117e+00
    phi[1,0]  R308      -2.0670785903930664e+00
    phi[1,0]  R309      -1.9353444576263428e+00
    phi[1,0]  R310      -2.5543472766876221e+00
    phi[1,0]  R311      -2.6044440269470215e-01
    phi[1,0]  R312      -4.7267064452171326e-01
    phi[1,0]  R313      -1.1235343217849731e+00
    phi[1,0]  R314      -1.4717134237289429e+00
    phi[1,0]  R315      -1.7904587984085083e+00
    phi[1,0]  R316      -2.3280544281005859e+00
    phi[1,0]  R317      -2.3715248107910156e+00
    phi[1,0]  R318      -7.3227733373641968e-01
    phi[1,0]  R319      -3.3421175479888916e+00
    phi[1,0]  R320      -1.7074190378189087e+00
    phi[1,0]  R321      -2.9913179874420166e+00
    phi[1,0]  R322      -2.9782578945159912e+00
    phi[1,0]  R323      -1.1243221759796143e+00
    phi[1,0]  R324      -1.2983950376510620e+00
    phi[1,0]  R325      -1.3386058807373047e+00
    phi[1,0]  R326      -2.0038964748382568e+00
    phi[1,0]  R327      -2.7051808834075928e+00
    phi[1,0]  R328      -8.7630116939544678e-01
    phi[1,0]  R329      -2.7382895350456238e-01
    phi[1,0]  R330      -1.5187896490097046e+00
    phi[1,0]  R331      -3.4117621183395386e-01
    phi[1,0]  R332      -7.3416489362716675e-01
    phi[1,0]  R333      -1.1582061052322388e+00
    phi[1,0]  R334      -1.4588338136672974e+00
    phi[1,0]  R335      -1.4751677513122559e+00
    phi[1,0]  R336      -1.6267303228378296e+00
    phi[1,0]  R337      -2.5352110862731934e+00
    phi[1,0]  R338      -2.8484699130058289e-01
    phi[1,0]  R339      -6.8311071395874023e-01
    phi[1,0]  R340      -5.0120645761489868e-01
    phi[1,0]  R341      -1.2715778350830078e+00
    phi[1,0]  R342      -0.700590968132019
    phi[1,0]  R343      1.1691654920578003e+00
    phi[1,0]  R344      6.3939285278320312e-01
    phi[1,0]  R345      9.4822531938552856e-01
    phi[1,0]  R346      5.2110958099365234e-01
    phi[1,0]  R347      1.0326553583145142e+00
    phi[1,0]  R348      1.1823796033859253e+00
    phi[1,0]  R349      1.0785428285598755e+00
    phi[1,0]  R350      1.2203266620635986e+00
    phi[1,0]  R351      1.2297185659408569e+00
    phi[1,0]  R352      1.4851337671279907e+00
    phi[1,0]  R353      -1.4736955165863037e+00
    phi[1,0]  R354      -2.1335701942443848e+00
    phi[1,0]  R355      -1.7571489810943604e+00
    phi[1,0]  R356      -2.2089893817901611e+00
    phi[1,0]  R357      -1.8819338083267212e+00
    phi[1,0]  R358      -1.4536508321762085e+00
    phi[1,0]  R359      -2.1631021499633789e+00
    phi[1,0]  R360      -1.96341872215271
    phi[1,0]  R361      -1.6787276268005371e+00
    phi[1,0]  R362      -4.63515567779541
    phi[1,0]  R363      -1.4982165098190308e+00
    phi[1,0]  R364      -1.0513086318969727e+00
    phi[1,0]  R365      -1.4054069519042969e+00
    phi[1,0]  R366      -1.7032458782196045e+00
    phi[1,0]  R367      -3.4826068878173828e+00
    phi[1,0]  R368      -6.1507481336593628e-01
    phi[1,0]  R369      -1.5091440677642822e+00
    phi[1,0]  R370      -4.7398188710212708e-01
    phi[1,0]  R371      -1.3527140617370605e+00
    phi[1,0]  R372      -1.27840256690979
    phi[1,0]  R373      -1.00215744972229
    phi[1,0]  R374      -7.1374821662902832e-01
    phi[1,0]  R375      -5.1703453063964844e-02
    phi[1,0]  R376      -2.9921853542327881e+00
    phi[1,0]  R377      -1.5951668024063110e+00
    phi[1,0]  R378      -2.5576024055480957e+00
    phi[1,0]  R379      -3.3277451992034912e+00
    phi[1,0]  R380      -1.5481046438217163e+00
    phi[1,0]  R381      -1.7955756187438965e+00
    phi[1,0]  R382      -2.8969542980194092e+00
    phi[1,0]  R383      -3.0358207225799561e+00
    phi[1,0]  R384      -2.0783517360687256e+00
    phi[1,0]  R385      -9.4535845518112183e-01
    phi[1,0]  R386      -6.9302612543106079e-01
    phi[1,0]  R387      -1.4112701416015625e+00
    phi[1,0]  R388      -0.714901864528656
    phi[1,0]  R389      -4.3908256292343140e-01
    phi[1,0]  R390      -3.1412191390991211e+00
    phi[1,0]  R391      -4.8646691441535950e-01
    phi[1,0]  R392      -4.0691375732421875e-01
    phi[0,4]  R0        1
    phi[0,4]  R1        1
    phi[0,4]  R36       -1
    phi[0,4]  R393      -3.0999999046325684e+00
    phi[0,4]  R394      -3.0999999046325684e+00
    phi[0,4]  R395      -2.2400000095367432e+00
    phi[0,4]  R396      -2.2400000095367432e+00
    phi[0,4]  R397      -3.0999999046325684e+00
    phi[0,4]  R398      -3.0999999046325684e+00
    phi[0,4]  R399      -2.5699999332427979e+00
    phi[0,4]  R400      -2.5699999332427979e+00
    phi[0,4]  R401      -3.0999999046325684e+00
    phi[0,4]  R402      -3.0999999046325684e+00
    phi[0,4]  R403      -2.0899999141693115e+00
    phi[0,4]  R404      -2.0899999141693115e+00
    phi[0,4]  R405      -3.0999999046325684e+00
    phi[0,4]  R406      -3.0999999046325684e+00
    phi[0,4]  R407      1.1691654920578003e+00
    phi[0,4]  R408      6.3939285278320312e-01
    phi[0,4]  R409      9.4822531938552856e-01
    phi[0,4]  R410      5.2110958099365234e-01
    phi[0,4]  R411      1.0326553583145142e+00
    phi[0,4]  R412      1.1823796033859253e+00
    phi[0,4]  R413      1.0785428285598755e+00
    phi[0,4]  R414      1.2203266620635986e+00
    phi[0,4]  R415      1.2297185659408569e+00
    phi[0,4]  R416      1.4851337671279907e+00
    phi[0,4]  R417      -1.4736955165863037e+00
    phi[0,4]  R418      -2.1335701942443848e+00
    phi[0,4]  R419      -1.7571489810943604e+00
    phi[0,4]  R420      -2.2089893817901611e+00
    phi[0,4]  R421      -1.8819338083267212e+00
    phi[0,4]  R422      -1.4536508321762085e+00
    phi[0,4]  R423      -2.1631021499633789e+00
    phi[0,4]  R424      -1.96341872215271
    phi[0,4]  R425      -1.6787276268005371e+00
    phi[0,4]  R426      -4.63515567779541
    phi[0,4]  R427      -1.4982165098190308e+00
    phi[0,4]  R428      -1.0513086318969727e+00
    phi[0,4]  R429      -1.4054069519042969e+00
    phi[0,4]  R430      -1.7032458782196045e+00
    phi[0,4]  R431      -3.4826068878173828e+00
    phi[0,4]  R432      -6.1507481336593628e-01
    phi[0,4]  R433      -1.5091440677642822e+00
    phi[0,4]  R434      -4.7398188710212708e-01
    phi[0,4]  R435      -1.3527140617370605e+00
    phi[0,4]  R436      -1.27840256690979
    phi[0,4]  R437      -1.00215744972229
    phi[0,4]  R438      -7.1374821662902832e-01
    phi[0,4]  R439      -5.1703453063964844e-02
    phi[0,4]  R440      -2.9921853542327881e+00
    phi[0,4]  R441      -1.5951668024063110e+00
    phi[0,4]  R442      -2.5576024055480957e+00
    phi[0,4]  R443      -3.3277451992034912e+00
    phi[0,4]  R444      -1.5481046438217163e+00
    phi[0,4]  R445      -1.7955756187438965e+00
    phi[0,4]  R446      -2.8969542980194092e+00
    phi[0,4]  R447      -3.0358207225799561e+00
    phi[0,4]  R448      -2.0783517360687256e+00
    phi[0,4]  R449      -9.4535845518112183e-01
    phi[0,4]  R450      -6.9302612543106079e-01
    phi[0,4]  R451      -1.4112701416015625e+00
    phi[0,4]  R452      -0.714901864528656
    phi[0,4]  R453      -4.3908256292343140e-01
    phi[0,4]  R454      -3.1412191390991211e+00
    phi[0,4]  R455      -4.8646691441535950e-01
    phi[0,4]  R456      -4.0691375732421875e-01
    phi[0,4]  R457      1.3247875869274139e-01
    phi[0,4]  R458      1.8049118518829346e+00
    phi[0,4]  R459      1.5372670888900757e+00
    phi[0,4]  R460      2.00858473777771
    phi[0,4]  R461      2.4449262619018555e+00
    phi[0,4]  R462      2.1936743259429932e+00
    phi[0,4]  R463      -1.7578488588333130e-01
    phi[0,4]  R464      1.1151608228683472e+00
    phi[0,4]  R465      1.8097747564315796e+00
    phi[0,4]  R466      1.9750542640686035e+00
    phi[0,4]  R467      4.0697780251502991e-01
    phi[0,4]  R468      8.2608246803283691e-01
    phi[0,4]  R469      4.4475749135017395e-01
    phi[0,4]  R470      -2.6602727174758911e-01
    phi[0,4]  R471      -3.3808830380439758e-01
    phi[0,4]  R472      2.1538259088993073e-01
    phi[0,4]  R473      1.8396036326885223e-01
    phi[0,4]  R474      -9.4072383642196655e-01
    phi[0,4]  R475      -8.2318294048309326e-01
    phi[0,4]  R476      -3.4311375021934509e-01
    phi[0,4]  R477      -6.9433414936065674e-01
    phi[0,4]  R478      -3.3631348609924316e+00
    phi[0,4]  R479      -1.4225327968597412e+00
    phi[0,4]  R480      -1.9978079795837402e+00
    phi[0,4]  R481      -4.3621838092803955e-01
    phi[0,4]  R482      -1.3292034864425659e+00
    phi[0,4]  R483      -9.2464596033096313e-01
    phi[0,4]  R484      1.1124892234802246e+00
    phi[0,4]  R485      4.5599600672721863e-01
    phi[0,4]  R486      -1.5285264253616333e+00
    phi[0,4]  R487      -8.8444298505783081e-01
    phi[0,4]  R488      -1.6458404064178467e-01
    phi[0,4]  R489      8.7023848295211792e-01
    phi[0,4]  R490      -1.1242572069168091e+00
    phi[0,4]  R491      2.5161948204040527e+00
    phi[0,4]  R492      1.8975294828414917e+00
    phi[0,4]  R493      4.7932329773902893e-01
    phi[0,4]  R494      1.7834924459457397e+00
    phi[0,4]  R495      7.8865534067153931e-01
    phi[0,4]  R496      -1.1206871271133423e+00
    phi[0,4]  R497      8.9766716957092285e-01
    phi[0,4]  R498      -6.6361618041992188e-01
    phi[0,4]  R499      6.5362930297851562e-01
    phi[0,4]  R500      -5.8108299970626831e-01
    phi[0,4]  R501      4.9799549579620361e-01
    phi[0,4]  R502      -2.9428920149803162e-01
    phi[0,4]  R503      -1.8276251554489136e+00
    phi[0,4]  R504      1.9948244094848633e+00
    phi[0,4]  R505      -1.8287563323974609e+00
    phi[0,4]  R506      -2.0374925136566162e+00
    phi[0,4]  R507      -2.23367977142334
    phi[0,4]  R508      -1.9197836518287659e-01
    phi[0,4]  R509      -2.4094719886779785e+00
    phi[0,4]  R510      -2.4291565418243408e+00
    phi[0,4]  R511      -3.0121953487396240e+00
    phi[0,4]  R512      -1.8537623882293701e+00
    phi[0,4]  R513      -2.8621504306793213e+00
    phi[0,4]  R514      -3.2000980377197266e+00
    phi[0,4]  R515      -3.0970048904418945e+00
    phi[4,0]  R0        -1
    phi[4,0]  R36       1
    phi[4,0]  R37       1
    phi[4,0]  R516      -3.0999999046325684e+00
    phi[4,0]  R517      -3.0999999046325684e+00
    phi[4,0]  R518      -2.2400000095367432e+00
    phi[4,0]  R519      -2.2400000095367432e+00
    phi[4,0]  R520      -3.0999999046325684e+00
    phi[4,0]  R521      -3.0999999046325684e+00
    phi[4,0]  R522      -2.5699999332427979e+00
    phi[4,0]  R523      -2.5699999332427979e+00
    phi[4,0]  R524      -3.0999999046325684e+00
    phi[4,0]  R525      -3.0999999046325684e+00
    phi[4,0]  R526      -2.0899999141693115e+00
    phi[4,0]  R527      -2.0899999141693115e+00
    phi[4,0]  R528      -3.0999999046325684e+00
    phi[4,0]  R529      -3.0999999046325684e+00
    phi[4,0]  R530      1.3247875869274139e-01
    phi[4,0]  R531      1.8049118518829346e+00
    phi[4,0]  R532      1.5372670888900757e+00
    phi[4,0]  R533      2.00858473777771
    phi[4,0]  R534      2.4449262619018555e+00
    phi[4,0]  R535      2.1936743259429932e+00
    phi[4,0]  R536      -1.7578488588333130e-01
    phi[4,0]  R537      1.1151608228683472e+00
    phi[4,0]  R538      1.8097747564315796e+00
    phi[4,0]  R539      1.9750542640686035e+00
    phi[4,0]  R540      4.0697780251502991e-01
    phi[4,0]  R541      8.2608246803283691e-01
    phi[4,0]  R542      4.4475749135017395e-01
    phi[4,0]  R543      -2.6602727174758911e-01
    phi[4,0]  R544      -3.3808830380439758e-01
    phi[4,0]  R545      2.1538259088993073e-01
    phi[4,0]  R546      1.8396036326885223e-01
    phi[4,0]  R547      -9.4072383642196655e-01
    phi[4,0]  R548      -8.2318294048309326e-01
    phi[4,0]  R549      -3.4311375021934509e-01
    phi[4,0]  R550      -6.9433414936065674e-01
    phi[4,0]  R551      -3.3631348609924316e+00
    phi[4,0]  R552      -1.4225327968597412e+00
    phi[4,0]  R553      -1.9978079795837402e+00
    phi[4,0]  R554      -4.3621838092803955e-01
    phi[4,0]  R555      -1.3292034864425659e+00
    phi[4,0]  R556      -9.2464596033096313e-01
    phi[4,0]  R557      1.1124892234802246e+00
    phi[4,0]  R558      4.5599600672721863e-01
    phi[4,0]  R559      -1.5285264253616333e+00
    phi[4,0]  R560      -8.8444298505783081e-01
    phi[4,0]  R561      -1.6458404064178467e-01
    phi[4,0]  R562      8.7023848295211792e-01
    phi[4,0]  R563      -1.1242572069168091e+00
    phi[4,0]  R564      2.5161948204040527e+00
    phi[4,0]  R565      1.8975294828414917e+00
    phi[4,0]  R566      4.7932329773902893e-01
    phi[4,0]  R567      1.7834924459457397e+00
    phi[4,0]  R568      7.8865534067153931e-01
    phi[4,0]  R569      -1.1206871271133423e+00
    phi[4,0]  R570      8.9766716957092285e-01
    phi[4,0]  R571      -6.6361618041992188e-01
    phi[4,0]  R572      6.5362930297851562e-01
    phi[4,0]  R573      -5.8108299970626831e-01
    phi[4,0]  R574      4.9799549579620361e-01
    phi[4,0]  R575      -2.9428920149803162e-01
    phi[4,0]  R576      -1.8276251554489136e+00
    phi[4,0]  R577      1.9948244094848633e+00
    phi[4,0]  R578      -1.8287563323974609e+00
    phi[4,0]  R579      -2.0374925136566162e+00
    phi[4,0]  R580      -2.23367977142334
    phi[4,0]  R581      -1.9197836518287659e-01
    phi[4,0]  R582      -2.4094719886779785e+00
    phi[4,0]  R583      -2.4291565418243408e+00
    phi[4,0]  R584      -3.0121953487396240e+00
    phi[4,0]  R585      -1.8537623882293701e+00
    phi[4,0]  R586      -2.8621504306793213e+00
    phi[4,0]  R587      -3.2000980377197266e+00
    phi[4,0]  R588      -3.0970048904418945e+00
    phi[4,0]  R589      1.1691654920578003e+00
    phi[4,0]  R590      6.3939285278320312e-01
    phi[4,0]  R591      9.4822531938552856e-01
    phi[4,0]  R592      5.2110958099365234e-01
    phi[4,0]  R593      1.0326553583145142e+00
    phi[4,0]  R594      1.1823796033859253e+00
    phi[4,0]  R595      1.0785428285598755e+00
    phi[4,0]  R596      1.2203266620635986e+00
    phi[4,0]  R597      1.2297185659408569e+00
    phi[4,0]  R598      1.4851337671279907e+00
    phi[4,0]  R599      -1.4736955165863037e+00
    phi[4,0]  R600      -2.1335701942443848e+00
    phi[4,0]  R601      -1.7571489810943604e+00
    phi[4,0]  R602      -2.2089893817901611e+00
    phi[4,0]  R603      -1.8819338083267212e+00
    phi[4,0]  R604      -1.4536508321762085e+00
    phi[4,0]  R605      -2.1631021499633789e+00
    phi[4,0]  R606      -1.96341872215271
    phi[4,0]  R607      -1.6787276268005371e+00
    phi[4,0]  R608      -4.63515567779541
    phi[4,0]  R609      -1.4982165098190308e+00
    phi[4,0]  R610      -1.0513086318969727e+00
    phi[4,0]  R611      -1.4054069519042969e+00
    phi[4,0]  R612      -1.7032458782196045e+00
    phi[4,0]  R613      -3.4826068878173828e+00
    phi[4,0]  R614      -6.1507481336593628e-01
    phi[4,0]  R615      -1.5091440677642822e+00
    phi[4,0]  R616      -4.7398188710212708e-01
    phi[4,0]  R617      -1.3527140617370605e+00
    phi[4,0]  R618      -1.27840256690979
    phi[4,0]  R619      -1.00215744972229
    phi[4,0]  R620      -7.1374821662902832e-01
    phi[4,0]  R621      -5.1703453063964844e-02
    phi[4,0]  R622      -2.9921853542327881e+00
    phi[4,0]  R623      -1.5951668024063110e+00
    phi[4,0]  R624      -2.5576024055480957e+00
    phi[4,0]  R625      -3.3277451992034912e+00
    phi[4,0]  R626      -1.5481046438217163e+00
    phi[4,0]  R627      -1.7955756187438965e+00
    phi[4,0]  R628      -2.8969542980194092e+00
    phi[4,0]  R629      -3.0358207225799561e+00
    phi[4,0]  R630      -2.0783517360687256e+00
    phi[4,0]  R631      -9.4535845518112183e-01
    phi[4,0]  R632      -6.9302612543106079e-01
    phi[4,0]  R633      -1.4112701416015625e+00
    phi[4,0]  R634      -0.714901864528656
    phi[4,0]  R635      -4.3908256292343140e-01
    phi[4,0]  R636      -3.1412191390991211e+00
    phi[4,0]  R637      -4.8646691441535950e-01
    phi[4,0]  R638      -4.0691375732421875e-01
    phi[7,0]  R0        -1
    phi[7,0]  R2        -2.1426087385655919e+00
    phi[7,0]  R3        -1.7648205800455892e+00
    phi[7,0]  R4        1.6024263208598826e+00
    phi[7,0]  R5        -1.26361326873888
    phi[7,0]  R6        -3.4281727686026064e-01
    phi[7,0]  R7        -1.9477922353880093e+00
    phi[7,0]  R8        -2.3579728613288484e+00
    phi[7,0]  R63       1
    phi[7,0]  R639      -9.5739116606697650e-01
    phi[7,0]  R640      -5.24260864319816
    phi[7,0]  R641      -0.475179429491154
    phi[7,0]  R642      -4.0048205895823319e+00
    phi[7,0]  R643      -4.7024262254924505e+00
    phi[7,0]  R644      -1.4975735837726858e+00
    phi[7,0]  R645      -1.3063866645039179e+00
    phi[7,0]  R646      -3.8336132019816778e+00
    phi[7,0]  R647      -2.7571826277723077e+00
    phi[7,0]  R648      -3.4428171814928290e+00
    phi[7,0]  R649      -1.4220767878130225e-01
    phi[7,0]  R650      -4.0377921495573208e+00
    phi[7,0]  R651      -7.4202704330371994e-01
    phi[7,0]  R652      -5.4579727659614168e+00
    phi[7,0]  R653      -1.4689947982338114e-01
    phi[7,0]  R654      -1.4940925762704282e-01
    phi[7,0]  R655      -0.151764029215937
    phi[7,0]  R656      -1.5608175849167316e-01
    phi[7,0]  R657      -1.5920813170425396e-01
    phi[7,0]  R658      -1.8923082326138529e-01
    phi[7,0]  R659      -1.9528658946387512e-01
    phi[7,0]  R660      -8.3852725318823618e-01
    phi[7,0]  R661      -1.0853810843389509e+00
    phi[7,0]  R662      -5.0660577001834617e-01
    phi[7,0]  R663      -4.9426885848900737e-01
    phi[7,0]  R664      -5.1861719049949628e-01
    phi[7,0]  R665      -0.534159332754065
    phi[7,0]  R666      -5.6832641432910780e-01
    phi[7,0]  R667      -5.8407299193445539e-01
    phi[7,0]  R668      -5.8921010962637343e-01
    phi[7,0]  R669      -5.9540628816726615e-01
    phi[7,0]  R670      -6.0194430520405984e-01
    phi[7,0]  R671      -6.0345861929275246e-01
    phi[7,0]  R672      -6.1384295280571610e-01
    phi[7,0]  R673      -2.2544056200147922e-01
    phi[7,0]  R674      -2.2567563779847866e-01
    phi[7,0]  R675      -2.2747436426989798e-01
    phi[7,0]  R676      -2.3601530249934122e-01
    phi[7,0]  R677      -2.3620216356200263e-01
    phi[7,0]  R678      -2.4368493895589882e-01
    phi[7,0]  R679      -2.4696688308945780e-01
    phi[7,0]  R680      -2.5478443582787336e-01
    phi[7,0]  R681      -2.8989510934371721e-01
    phi[7,0]  R682      -2.9698770243848682e-01
    phi[7,0]  R683      -2.2166042092492377e-01
    phi[7,0]  R684      -2.3347876309222126e-01
    phi[7,0]  R685      -2.4904338748505103e-01
    phi[7,0]  R686      -5.6641108643235949e-01
    phi[7,0]  R687      -0.598794737543076
    phi[7,0]  R688      -0.600362932898237
    phi[7,0]  R689      -6.0771186851353232e-01
    phi[7,0]  R690      -6.0945050796343336e-01
    phi[7,0]  R691      -6.0995676000757171e-01
    phi[7,0]  R692      -0.617328994242786
    phi[7,0]  R693      -5.2841477191241282e-01
    phi[7,0]  R694      -6.1583304459808841e-01
    phi[7,0]  R695      -6.2146398135957126e-01
    phi[7,0]  R696      -6.6877775770370518e-01
    phi[7,0]  R697      -6.8677198916428994e-01
    phi[7,0]  R698      -6.9338380655394327e-01
    phi[7,0]  R699      -7.0697451234951170e-01
    phi[7,0]  R700      -7.1101059480386386e-01
    phi[7,0]  R701      -0.715717655001265
    phi[7,0]  R702      -7.3062854920404208e-01
    phi[1,2]  R9        1
    phi[1,2]  R10       1
    phi[1,2]  R18       -1
    phi[1,2]  R703      -3.0999999046325684e+00
    phi[1,2]  R704      -3.0999999046325684e+00
    phi[1,2]  R705      -2.2400000095367432e+00
    phi[1,2]  R706      -2.2400000095367432e+00
    phi[1,2]  R707      -3.0999999046325684e+00
    phi[1,2]  R708      -3.0999999046325684e+00
    phi[1,2]  R709      -2.5699999332427979e+00
    phi[1,2]  R710      -2.5699999332427979e+00
    phi[1,2]  R711      -3.0999999046325684e+00
    phi[1,2]  R712      -3.0999999046325684e+00
    phi[1,2]  R713      -2.0899999141693115e+00
    phi[1,2]  R714      -2.0899999141693115e+00
    phi[1,2]  R715      -3.0999999046325684e+00
    phi[1,2]  R716      -3.0999999046325684e+00
    phi[1,2]  R717      6.2556117773056030e-02
    phi[1,2]  R718      9.6740698814392090e-01
    phi[1,2]  R719      7.4404346942901611e-01
    phi[1,2]  R720      4.2306506633758545e-01
    phi[1,2]  R721      0.801608145236969
    phi[1,2]  R722      1.9694203138351440e-01
    phi[1,2]  R723      3.4496402740478516e-01
    phi[1,2]  R724      0.874773383140564
    phi[1,2]  R725      4.6939593553543091e-01
    phi[1,2]  R726      8.6967945098876953e-01
    phi[1,2]  R727      -1.8018673658370972e+00
    phi[1,2]  R728      -1.6787379980087280e+00
    phi[1,2]  R729      -8.1126272678375244e-01
    phi[1,2]  R730      -2.0037531852722168e+00
    phi[1,2]  R731      -2.1069307327270508e+00
    phi[1,2]  R732      -1.2515301704406738e+00
    phi[1,2]  R733      -1.5814245939254761e+00
    phi[1,2]  R734      -2.0014057159423828e+00
    phi[1,2]  R735      -1.8219569921493530e+00
    phi[1,2]  R736      9.0164966881275177e-02
    phi[1,2]  R737      -1.4933149814605713e+00
    phi[1,2]  R738      -2.0219403505325317e-01
    phi[1,2]  R739      -1.9593131542205811e+00
    phi[1,2]  R740      -1.2331484556198120e+00
    phi[1,2]  R741      -8.1905007362365723e-01
    phi[1,2]  R742      -1.9005004167556763e+00
    phi[1,2]  R743      -2.3031768798828125e+00
    phi[1,2]  R744      -2.1969819068908691e+00
    phi[1,2]  R745      4.3382960557937622e-01
    phi[1,2]  R746      -2.0276033878326416e+00
    phi[1,2]  R747      1.2017848342657089e-01
    phi[1,2]  R748      -1.2630753517150879e+00
    phi[1,2]  R749      -1.1359472274780273e+00
    phi[1,2]  R750      -1.9994518756866455e+00
    phi[1,2]  R751      -2.1688213348388672e+00
    phi[1,2]  R752      -2.6111125946044922e+00
    phi[1,2]  R753      -1.5152133703231812e+00
    phi[1,2]  R754      -1.4248226881027222e+00
    phi[1,2]  R755      -2.3244929313659668e+00
    phi[1,2]  R756      -1.2592172622680664e+00
    phi[1,2]  R757      1.2390511482954025e-01
    phi[1,2]  R758      9.3042838573455811e-01
    phi[1,2]  R759      3.2924869656562805e-01
    phi[1,2]  R760      -1.9579730033874512e+00
    phi[1,2]  R761      -1.8124901056289673e+00
    phi[1,2]  R762      -1.1141886711120605e+00
    phi[1,2]  R763      -2.2809672355651855e+00
    phi[1,2]  R764      -2.3023803234100342e+00
    phi[1,2]  R765      -3.0915312767028809e+00
    phi[1,2]  R766      -1.4350209236145020e+00
    phi[1,2]  R767      -0.0541786327958107
    phi[1,2]  R768      -1.8928896188735962e+00
    phi[1,2]  R769      -2.0521986484527588e+00
    phi[1,2]  R770      -9.1291368007659912e-01
    phi[1,2]  R771      -8.6685991287231445e-01
    phi[1,2]  R772      -2.1188676357269287e+00
    phi[1,2]  R773      -2.6802144050598145e+00
    phi[1,2]  R774      -1.5685625076293945e+00
    phi[1,2]  R775      -2.9002516269683838e+00
    phi[1,2]  R776      -2.0382649898529053e+00
    phi[1,2]  R777      -1.8577950000762939e+00
    phi[1,2]  R778      -9.5404225587844849e-01
    phi[1,2]  R779      -1.8620798587799072e+00
    phi[1,2]  R780      -2.3914270401000977e+00
    phi[1,2]  R781      -2.7600278854370117e+00
    phi[1,2]  R782      -2.0670785903930664e+00
    phi[1,2]  R783      -1.9353444576263428e+00
    phi[1,2]  R784      -2.5543472766876221e+00
    phi[1,2]  R785      -2.6044440269470215e-01
    phi[1,2]  R786      -4.7267064452171326e-01
    phi[1,2]  R787      -1.1235343217849731e+00
    phi[1,2]  R788      -1.4717134237289429e+00
    phi[1,2]  R789      -1.7904587984085083e+00
    phi[1,2]  R790      -2.3280544281005859e+00
    phi[1,2]  R791      -2.3715248107910156e+00
    phi[1,2]  R792      -7.3227733373641968e-01
    phi[1,2]  R793      -3.3421175479888916e+00
    phi[1,2]  R794      -1.7074190378189087e+00
    phi[1,2]  R795      -2.9913179874420166e+00
    phi[1,2]  R796      -2.9782578945159912e+00
    phi[1,2]  R797      -1.1243221759796143e+00
    phi[1,2]  R798      -1.2983950376510620e+00
    phi[1,2]  R799      -1.3386058807373047e+00
    phi[1,2]  R800      -2.0038964748382568e+00
    phi[1,2]  R801      -2.7051808834075928e+00
    phi[1,2]  R802      -8.7630116939544678e-01
    phi[1,2]  R803      -2.7382895350456238e-01
    phi[1,2]  R804      -1.5187896490097046e+00
    phi[1,2]  R805      -3.4117621183395386e-01
    phi[1,2]  R806      -7.3416489362716675e-01
    phi[1,2]  R807      -1.1582061052322388e+00
    phi[1,2]  R808      -1.4588338136672974e+00
    phi[1,2]  R809      -1.4751677513122559e+00
    phi[1,2]  R810      -1.6267303228378296e+00
    phi[1,2]  R811      -2.5352110862731934e+00
    phi[1,2]  R812      -2.8484699130058289e-01
    phi[1,2]  R813      -6.8311071395874023e-01
    phi[1,2]  R814      -5.0120645761489868e-01
    phi[1,2]  R815      -1.2715778350830078e+00
    phi[1,2]  R816      -0.700590968132019
    phi[1,2]  R817      6.5665221214294434e-01
    phi[1,2]  R818      -3.9350733160972595e-01
    phi[1,2]  R819      5.9350311756134033e-01
    phi[1,2]  R820      3.1907051801681519e-02
    phi[1,2]  R821      9.4231730699539185e-01
    phi[1,2]  R822      -0.0262936819344759
    phi[1,2]  R823      5.3548997640609741e-01
    phi[1,2]  R824      1.0861637592315674e+00
    phi[1,2]  R825      -4.0130129456520081e-01
    phi[1,2]  R826      1.6357865929603577e-01
    phi[1,2]  R827      -1.4103966951370239e-01
    phi[1,2]  R828      7.3740124702453613e-01
    phi[1,2]  R829      -2.2280490398406982e-01
    phi[1,2]  R830      1.6671646386384964e-02
    phi[1,2]  R831      1.2793336063623428e-03
    phi[1,2]  R832      -1.3221390545368195e-01
    phi[1,2]  R833      3.7927973270416260e-01
    phi[1,2]  R834      -0.646546483039856
    phi[1,2]  R835      2.4405905604362488e-01
    phi[1,2]  R836      -5.0043207406997681e-01
    phi[1,2]  R837      -1.0025626420974731e+00
    phi[1,2]  R838      -1.2969179451465607e-01
    phi[1,2]  R839      -6.7729949951171875e-01
    phi[1,2]  R840      -2.2186813354492188e+00
    phi[2,1]  R9        -1
    phi[2,1]  R18       1
    phi[2,1]  R19       1
    phi[2,1]  R841      -3.0999999046325684e+00
    phi[2,1]  R842      -3.0999999046325684e+00
    phi[2,1]  R843      -2.2400000095367432e+00
    phi[2,1]  R844      -2.2400000095367432e+00
    phi[2,1]  R845      -3.0999999046325684e+00
    phi[2,1]  R846      -3.0999999046325684e+00
    phi[2,1]  R847      -2.5699999332427979e+00
    phi[2,1]  R848      -2.5699999332427979e+00
    phi[2,1]  R849      -3.0999999046325684e+00
    phi[2,1]  R850      -3.0999999046325684e+00
    phi[2,1]  R851      -2.0899999141693115e+00
    phi[2,1]  R852      -2.0899999141693115e+00
    phi[2,1]  R853      -3.0999999046325684e+00
    phi[2,1]  R854      -3.0999999046325684e+00
    phi[2,1]  R855      6.5665221214294434e-01
    phi[2,1]  R856      -3.9350733160972595e-01
    phi[2,1]  R857      5.9350311756134033e-01
    phi[2,1]  R858      3.1907051801681519e-02
    phi[2,1]  R859      9.4231730699539185e-01
    phi[2,1]  R860      -0.0262936819344759
    phi[2,1]  R861      5.3548997640609741e-01
    phi[2,1]  R862      1.0861637592315674e+00
    phi[2,1]  R863      -4.0130129456520081e-01
    phi[2,1]  R864      1.6357865929603577e-01
    phi[2,1]  R865      -1.4103966951370239e-01
    phi[2,1]  R866      7.3740124702453613e-01
    phi[2,1]  R867      -2.2280490398406982e-01
    phi[2,1]  R868      1.6671646386384964e-02
    phi[2,1]  R869      1.2793336063623428e-03
    phi[2,1]  R870      -1.3221390545368195e-01
    phi[2,1]  R871      3.7927973270416260e-01
    phi[2,1]  R872      -0.646546483039856
    phi[2,1]  R873      2.4405905604362488e-01
    phi[2,1]  R874      -5.0043207406997681e-01
    phi[2,1]  R875      -1.0025626420974731e+00
    phi[2,1]  R876      -1.2969179451465607e-01
    phi[2,1]  R877      -6.7729949951171875e-01
    phi[2,1]  R878      -2.2186813354492188e+00
    phi[2,1]  R879      6.2556117773056030e-02
    phi[2,1]  R880      9.6740698814392090e-01
    phi[2,1]  R881      7.4404346942901611e-01
    phi[2,1]  R882      4.2306506633758545e-01
    phi[2,1]  R883      0.801608145236969
    phi[2,1]  R884      1.9694203138351440e-01
    phi[2,1]  R885      3.4496402740478516e-01
    phi[2,1]  R886      0.874773383140564
    phi[2,1]  R887      4.6939593553543091e-01
    phi[2,1]  R888      8.6967945098876953e-01
    phi[2,1]  R889      -1.8018673658370972e+00
    phi[2,1]  R890      -1.6787379980087280e+00
    phi[2,1]  R891      -8.1126272678375244e-01
    phi[2,1]  R892      -2.0037531852722168e+00
    phi[2,1]  R893      -2.1069307327270508e+00
    phi[2,1]  R894      -1.2515301704406738e+00
    phi[2,1]  R895      -1.5814245939254761e+00
    phi[2,1]  R896      -2.0014057159423828e+00
    phi[2,1]  R897      -1.8219569921493530e+00
    phi[2,1]  R898      9.0164966881275177e-02
    phi[2,1]  R899      -1.4933149814605713e+00
    phi[2,1]  R900      -2.0219403505325317e-01
    phi[2,1]  R901      -1.9593131542205811e+00
    phi[2,1]  R902      -1.2331484556198120e+00
    phi[2,1]  R903      -8.1905007362365723e-01
    phi[2,1]  R904      -1.9005004167556763e+00
    phi[2,1]  R905      -2.3031768798828125e+00
    phi[2,1]  R906      -2.1969819068908691e+00
    phi[2,1]  R907      4.3382960557937622e-01
    phi[2,1]  R908      -2.0276033878326416e+00
    phi[2,1]  R909      1.2017848342657089e-01
    phi[2,1]  R910      -1.2630753517150879e+00
    phi[2,1]  R911      -1.1359472274780273e+00
    phi[2,1]  R912      -1.9994518756866455e+00
    phi[2,1]  R913      -2.1688213348388672e+00
    phi[2,1]  R914      -2.6111125946044922e+00
    phi[2,1]  R915      -1.5152133703231812e+00
    phi[2,1]  R916      -1.4248226881027222e+00
    phi[2,1]  R917      -2.3244929313659668e+00
    phi[2,1]  R918      -1.2592172622680664e+00
    phi[2,1]  R919      1.2390511482954025e-01
    phi[2,1]  R920      9.3042838573455811e-01
    phi[2,1]  R921      3.2924869656562805e-01
    phi[2,1]  R922      -1.9579730033874512e+00
    phi[2,1]  R923      -1.8124901056289673e+00
    phi[2,1]  R924      -1.1141886711120605e+00
    phi[2,1]  R925      -2.2809672355651855e+00
    phi[2,1]  R926      -2.3023803234100342e+00
    phi[2,1]  R927      -3.0915312767028809e+00
    phi[2,1]  R928      -1.4350209236145020e+00
    phi[2,1]  R929      -0.0541786327958107
    phi[2,1]  R930      -1.8928896188735962e+00
    phi[2,1]  R931      -2.0521986484527588e+00
    phi[2,1]  R932      -9.1291368007659912e-01
    phi[2,1]  R933      -8.6685991287231445e-01
    phi[2,1]  R934      -2.1188676357269287e+00
    phi[2,1]  R935      -2.6802144050598145e+00
    phi[2,1]  R936      -1.5685625076293945e+00
    phi[2,1]  R937      -2.9002516269683838e+00
    phi[2,1]  R938      -2.0382649898529053e+00
    phi[2,1]  R939      -1.8577950000762939e+00
    phi[2,1]  R940      -9.5404225587844849e-01
    phi[2,1]  R941      -1.8620798587799072e+00
    phi[2,1]  R942      -2.3914270401000977e+00
    phi[2,1]  R943      -2.7600278854370117e+00
    phi[2,1]  R944      -2.0670785903930664e+00
    phi[2,1]  R945      -1.9353444576263428e+00
    phi[2,1]  R946      -2.5543472766876221e+00
    phi[2,1]  R947      -2.6044440269470215e-01
    phi[2,1]  R948      -4.7267064452171326e-01
    phi[2,1]  R949      -1.1235343217849731e+00
    phi[2,1]  R950      -1.4717134237289429e+00
    phi[2,1]  R951      -1.7904587984085083e+00
    phi[2,1]  R952      -2.3280544281005859e+00
    phi[2,1]  R953      -2.3715248107910156e+00
    phi[2,1]  R954      -7.3227733373641968e-01
    phi[2,1]  R955      -3.3421175479888916e+00
    phi[2,1]  R956      -1.7074190378189087e+00
    phi[2,1]  R957      -2.9913179874420166e+00
    phi[2,1]  R958      -2.9782578945159912e+00
    phi[2,1]  R959      -1.1243221759796143e+00
    phi[2,1]  R960      -1.2983950376510620e+00
    phi[2,1]  R961      -1.3386058807373047e+00
    phi[2,1]  R962      -2.0038964748382568e+00
    phi[2,1]  R963      -2.7051808834075928e+00
    phi[2,1]  R964      -8.7630116939544678e-01
    phi[2,1]  R965      -2.7382895350456238e-01
    phi[2,1]  R966      -1.5187896490097046e+00
    phi[2,1]  R967      -3.4117621183395386e-01
    phi[2,1]  R968      -7.3416489362716675e-01
    phi[2,1]  R969      -1.1582061052322388e+00
    phi[2,1]  R970      -1.4588338136672974e+00
    phi[2,1]  R971      -1.4751677513122559e+00
    phi[2,1]  R972      -1.6267303228378296e+00
    phi[2,1]  R973      -2.5352110862731934e+00
    phi[2,1]  R974      -2.8484699130058289e-01
    phi[2,1]  R975      -6.8311071395874023e-01
    phi[2,1]  R976      -5.0120645761489868e-01
    phi[2,1]  R977      -1.2715778350830078e+00
    phi[2,1]  R978      -0.700590968132019
    phi[1,4]  R9        1
    phi[1,4]  R10       1
    phi[1,4]  R36       -1
    phi[1,4]  R979      -3.0999999046325684e+00
    phi[1,4]  R980      -3.0999999046325684e+00
    phi[1,4]  R981      -2.2400000095367432e+00
    phi[1,4]  R982      -2.2400000095367432e+00
    phi[1,4]  R983      -3.0999999046325684e+00
    phi[1,4]  R984      -3.0999999046325684e+00
    phi[1,4]  R985      -2.5699999332427979e+00
    phi[1,4]  R986      -2.5699999332427979e+00
    phi[1,4]  R987      -3.0999999046325684e+00
    phi[1,4]  R988      -3.0999999046325684e+00
    phi[1,4]  R989      -2.0899999141693115e+00
    phi[1,4]  R990      -2.0899999141693115e+00
    phi[1,4]  R991      -3.0999999046325684e+00
    phi[1,4]  R992      -3.0999999046325684e+00
    phi[1,4]  R993      6.2556117773056030e-02
    phi[1,4]  R994      9.6740698814392090e-01
    phi[1,4]  R995      7.4404346942901611e-01
    phi[1,4]  R996      4.2306506633758545e-01
    phi[1,4]  R997      0.801608145236969
    phi[1,4]  R998      1.9694203138351440e-01
    phi[1,4]  R999      3.4496402740478516e-01
    phi[1,4]  R1000     0.874773383140564
    phi[1,4]  R1001     4.6939593553543091e-01
    phi[1,4]  R1002     8.6967945098876953e-01
    phi[1,4]  R1003     -1.8018673658370972e+00
    phi[1,4]  R1004     -1.6787379980087280e+00
    phi[1,4]  R1005     -8.1126272678375244e-01
    phi[1,4]  R1006     -2.0037531852722168e+00
    phi[1,4]  R1007     -2.1069307327270508e+00
    phi[1,4]  R1008     -1.2515301704406738e+00
    phi[1,4]  R1009     -1.5814245939254761e+00
    phi[1,4]  R1010     -2.0014057159423828e+00
    phi[1,4]  R1011     -1.8219569921493530e+00
    phi[1,4]  R1012     9.0164966881275177e-02
    phi[1,4]  R1013     -1.4933149814605713e+00
    phi[1,4]  R1014     -2.0219403505325317e-01
    phi[1,4]  R1015     -1.9593131542205811e+00
    phi[1,4]  R1016     -1.2331484556198120e+00
    phi[1,4]  R1017     -8.1905007362365723e-01
    phi[1,4]  R1018     -1.9005004167556763e+00
    phi[1,4]  R1019     -2.3031768798828125e+00
    phi[1,4]  R1020     -2.1969819068908691e+00
    phi[1,4]  R1021     4.3382960557937622e-01
    phi[1,4]  R1022     -2.0276033878326416e+00
    phi[1,4]  R1023     1.2017848342657089e-01
    phi[1,4]  R1024     -1.2630753517150879e+00
    phi[1,4]  R1025     -1.1359472274780273e+00
    phi[1,4]  R1026     -1.9994518756866455e+00
    phi[1,4]  R1027     -2.1688213348388672e+00
    phi[1,4]  R1028     -2.6111125946044922e+00
    phi[1,4]  R1029     -1.5152133703231812e+00
    phi[1,4]  R1030     -1.4248226881027222e+00
    phi[1,4]  R1031     -2.3244929313659668e+00
    phi[1,4]  R1032     -1.2592172622680664e+00
    phi[1,4]  R1033     1.2390511482954025e-01
    phi[1,4]  R1034     9.3042838573455811e-01
    phi[1,4]  R1035     3.2924869656562805e-01
    phi[1,4]  R1036     -1.9579730033874512e+00
    phi[1,4]  R1037     -1.8124901056289673e+00
    phi[1,4]  R1038     -1.1141886711120605e+00
    phi[1,4]  R1039     -2.2809672355651855e+00
    phi[1,4]  R1040     -2.3023803234100342e+00
    phi[1,4]  R1041     -3.0915312767028809e+00
    phi[1,4]  R1042     -1.4350209236145020e+00
    phi[1,4]  R1043     -0.0541786327958107
    phi[1,4]  R1044     -1.8928896188735962e+00
    phi[1,4]  R1045     -2.0521986484527588e+00
    phi[1,4]  R1046     -9.1291368007659912e-01
    phi[1,4]  R1047     -8.6685991287231445e-01
    phi[1,4]  R1048     -2.1188676357269287e+00
    phi[1,4]  R1049     -2.6802144050598145e+00
    phi[1,4]  R1050     -1.5685625076293945e+00
    phi[1,4]  R1051     -2.9002516269683838e+00
    phi[1,4]  R1052     -2.0382649898529053e+00
    phi[1,4]  R1053     -1.8577950000762939e+00
    phi[1,4]  R1054     -9.5404225587844849e-01
    phi[1,4]  R1055     -1.8620798587799072e+00
    phi[1,4]  R1056     -2.3914270401000977e+00
    phi[1,4]  R1057     -2.7600278854370117e+00
    phi[1,4]  R1058     -2.0670785903930664e+00
    phi[1,4]  R1059     -1.9353444576263428e+00
    phi[1,4]  R1060     -2.5543472766876221e+00
    phi[1,4]  R1061     -2.6044440269470215e-01
    phi[1,4]  R1062     -4.7267064452171326e-01
    phi[1,4]  R1063     -1.1235343217849731e+00
    phi[1,4]  R1064     -1.4717134237289429e+00
    phi[1,4]  R1065     -1.7904587984085083e+00
    phi[1,4]  R1066     -2.3280544281005859e+00
    phi[1,4]  R1067     -2.3715248107910156e+00
    phi[1,4]  R1068     -7.3227733373641968e-01
    phi[1,4]  R1069     -3.3421175479888916e+00
    phi[1,4]  R1070     -1.7074190378189087e+00
    phi[1,4]  R1071     -2.9913179874420166e+00
    phi[1,4]  R1072     -2.9782578945159912e+00
    phi[1,4]  R1073     -1.1243221759796143e+00
    phi[1,4]  R1074     -1.2983950376510620e+00
    phi[1,4]  R1075     -1.3386058807373047e+00
    phi[1,4]  R1076     -2.0038964748382568e+00
    phi[1,4]  R1077     -2.7051808834075928e+00
    phi[1,4]  R1078     -8.7630116939544678e-01
    phi[1,4]  R1079     -2.7382895350456238e-01
    phi[1,4]  R1080     -1.5187896490097046e+00
    phi[1,4]  R1081     -3.4117621183395386e-01
    phi[1,4]  R1082     -7.3416489362716675e-01
    phi[1,4]  R1083     -1.1582061052322388e+00
    phi[1,4]  R1084     -1.4588338136672974e+00
    phi[1,4]  R1085     -1.4751677513122559e+00
    phi[1,4]  R1086     -1.6267303228378296e+00
    phi[1,4]  R1087     -2.5352110862731934e+00
    phi[1,4]  R1088     -2.8484699130058289e-01
    phi[1,4]  R1089     -6.8311071395874023e-01
    phi[1,4]  R1090     -5.0120645761489868e-01
    phi[1,4]  R1091     -1.2715778350830078e+00
    phi[1,4]  R1092     -0.700590968132019
    phi[1,4]  R1093     1.3247875869274139e-01
    phi[1,4]  R1094     1.8049118518829346e+00
    phi[1,4]  R1095     1.5372670888900757e+00
    phi[1,4]  R1096     2.00858473777771
    phi[1,4]  R1097     2.4449262619018555e+00
    phi[1,4]  R1098     2.1936743259429932e+00
    phi[1,4]  R1099     -1.7578488588333130e-01
    phi[1,4]  R1100     1.1151608228683472e+00
    phi[1,4]  R1101     1.8097747564315796e+00
    phi[1,4]  R1102     1.9750542640686035e+00
    phi[1,4]  R1103     4.0697780251502991e-01
    phi[1,4]  R1104     8.2608246803283691e-01
    phi[1,4]  R1105     4.4475749135017395e-01
    phi[1,4]  R1106     -2.6602727174758911e-01
    phi[1,4]  R1107     -3.3808830380439758e-01
    phi[1,4]  R1108     2.1538259088993073e-01
    phi[1,4]  R1109     1.8396036326885223e-01
    phi[1,4]  R1110     -9.4072383642196655e-01
    phi[1,4]  R1111     -8.2318294048309326e-01
    phi[1,4]  R1112     -3.4311375021934509e-01
    phi[1,4]  R1113     -6.9433414936065674e-01
    phi[1,4]  R1114     -3.3631348609924316e+00
    phi[1,4]  R1115     -1.4225327968597412e+00
    phi[1,4]  R1116     -1.9978079795837402e+00
    phi[1,4]  R1117     -4.3621838092803955e-01
    phi[1,4]  R1118     -1.3292034864425659e+00
    phi[1,4]  R1119     -9.2464596033096313e-01
    phi[1,4]  R1120     1.1124892234802246e+00
    phi[1,4]  R1121     4.5599600672721863e-01
    phi[1,4]  R1122     -1.5285264253616333e+00
    phi[1,4]  R1123     -8.8444298505783081e-01
    phi[1,4]  R1124     -1.6458404064178467e-01
    phi[1,4]  R1125     8.7023848295211792e-01
    phi[1,4]  R1126     -1.1242572069168091e+00
    phi[1,4]  R1127     2.5161948204040527e+00
    phi[1,4]  R1128     1.8975294828414917e+00
    phi[1,4]  R1129     4.7932329773902893e-01
    phi[1,4]  R1130     1.7834924459457397e+00
    phi[1,4]  R1131     7.8865534067153931e-01
    phi[1,4]  R1132     -1.1206871271133423e+00
    phi[1,4]  R1133     8.9766716957092285e-01
    phi[1,4]  R1134     -6.6361618041992188e-01
    phi[1,4]  R1135     6.5362930297851562e-01
    phi[1,4]  R1136     -5.8108299970626831e-01
    phi[1,4]  R1137     4.9799549579620361e-01
    phi[1,4]  R1138     -2.9428920149803162e-01
    phi[1,4]  R1139     -1.8276251554489136e+00
    phi[1,4]  R1140     1.9948244094848633e+00
    phi[1,4]  R1141     -1.8287563323974609e+00
    phi[1,4]  R1142     -2.0374925136566162e+00
    phi[1,4]  R1143     -2.23367977142334
    phi[1,4]  R1144     -1.9197836518287659e-01
    phi[1,4]  R1145     -2.4094719886779785e+00
    phi[1,4]  R1146     -2.4291565418243408e+00
    phi[1,4]  R1147     -3.0121953487396240e+00
    phi[1,4]  R1148     -1.8537623882293701e+00
    phi[1,4]  R1149     -2.8621504306793213e+00
    phi[1,4]  R1150     -3.2000980377197266e+00
    phi[1,4]  R1151     -3.0970048904418945e+00
    phi[4,1]  R9        -1
    phi[4,1]  R36       1
    phi[4,1]  R37       1
    phi[4,1]  R1152     -3.0999999046325684e+00
    phi[4,1]  R1153     -3.0999999046325684e+00
    phi[4,1]  R1154     -2.2400000095367432e+00
    phi[4,1]  R1155     -2.2400000095367432e+00
    phi[4,1]  R1156     -3.0999999046325684e+00
    phi[4,1]  R1157     -3.0999999046325684e+00
    phi[4,1]  R1158     -2.5699999332427979e+00
    phi[4,1]  R1159     -2.5699999332427979e+00
    phi[4,1]  R1160     -3.0999999046325684e+00
    phi[4,1]  R1161     -3.0999999046325684e+00
    phi[4,1]  R1162     -2.0899999141693115e+00
    phi[4,1]  R1163     -2.0899999141693115e+00
    phi[4,1]  R1164     -3.0999999046325684e+00
    phi[4,1]  R1165     -3.0999999046325684e+00
    phi[4,1]  R1166     1.3247875869274139e-01
    phi[4,1]  R1167     1.8049118518829346e+00
    phi[4,1]  R1168     1.5372670888900757e+00
    phi[4,1]  R1169     2.00858473777771
    phi[4,1]  R1170     2.4449262619018555e+00
    phi[4,1]  R1171     2.1936743259429932e+00
    phi[4,1]  R1172     -1.7578488588333130e-01
    phi[4,1]  R1173     1.1151608228683472e+00
    phi[4,1]  R1174     1.8097747564315796e+00
    phi[4,1]  R1175     1.9750542640686035e+00
    phi[4,1]  R1176     4.0697780251502991e-01
    phi[4,1]  R1177     8.2608246803283691e-01
    phi[4,1]  R1178     4.4475749135017395e-01
    phi[4,1]  R1179     -2.6602727174758911e-01
    phi[4,1]  R1180     -3.3808830380439758e-01
    phi[4,1]  R1181     2.1538259088993073e-01
    phi[4,1]  R1182     1.8396036326885223e-01
    phi[4,1]  R1183     -9.4072383642196655e-01
    phi[4,1]  R1184     -8.2318294048309326e-01
    phi[4,1]  R1185     -3.4311375021934509e-01
    phi[4,1]  R1186     -6.9433414936065674e-01
    phi[4,1]  R1187     -3.3631348609924316e+00
    phi[4,1]  R1188     -1.4225327968597412e+00
    phi[4,1]  R1189     -1.9978079795837402e+00
    phi[4,1]  R1190     -4.3621838092803955e-01
    phi[4,1]  R1191     -1.3292034864425659e+00
    phi[4,1]  R1192     -9.2464596033096313e-01
    phi[4,1]  R1193     1.1124892234802246e+00
    phi[4,1]  R1194     4.5599600672721863e-01
    phi[4,1]  R1195     -1.5285264253616333e+00
    phi[4,1]  R1196     -8.8444298505783081e-01
    phi[4,1]  R1197     -1.6458404064178467e-01
    phi[4,1]  R1198     8.7023848295211792e-01
    phi[4,1]  R1199     -1.1242572069168091e+00
    phi[4,1]  R1200     2.5161948204040527e+00
    phi[4,1]  R1201     1.8975294828414917e+00
    phi[4,1]  R1202     4.7932329773902893e-01
    phi[4,1]  R1203     1.7834924459457397e+00
    phi[4,1]  R1204     7.8865534067153931e-01
    phi[4,1]  R1205     -1.1206871271133423e+00
    phi[4,1]  R1206     8.9766716957092285e-01
    phi[4,1]  R1207     -6.6361618041992188e-01
    phi[4,1]  R1208     6.5362930297851562e-01
    phi[4,1]  R1209     -5.8108299970626831e-01
    phi[4,1]  R1210     4.9799549579620361e-01
    phi[4,1]  R1211     -2.9428920149803162e-01
    phi[4,1]  R1212     -1.8276251554489136e+00
    phi[4,1]  R1213     1.9948244094848633e+00
    phi[4,1]  R1214     -1.8287563323974609e+00
    phi[4,1]  R1215     -2.0374925136566162e+00
    phi[4,1]  R1216     -2.23367977142334
    phi[4,1]  R1217     -1.9197836518287659e-01
    phi[4,1]  R1218     -2.4094719886779785e+00
    phi[4,1]  R1219     -2.4291565418243408e+00
    phi[4,1]  R1220     -3.0121953487396240e+00
    phi[4,1]  R1221     -1.8537623882293701e+00
    phi[4,1]  R1222     -2.8621504306793213e+00
    phi[4,1]  R1223     -3.2000980377197266e+00
    phi[4,1]  R1224     -3.0970048904418945e+00
    phi[4,1]  R1225     6.2556117773056030e-02
    phi[4,1]  R1226     9.6740698814392090e-01
    phi[4,1]  R1227     7.4404346942901611e-01
    phi[4,1]  R1228     4.2306506633758545e-01
    phi[4,1]  R1229     0.801608145236969
    phi[4,1]  R1230     1.9694203138351440e-01
    phi[4,1]  R1231     3.4496402740478516e-01
    phi[4,1]  R1232     0.874773383140564
    phi[4,1]  R1233     4.6939593553543091e-01
    phi[4,1]  R1234     8.6967945098876953e-01
    phi[4,1]  R1235     -1.8018673658370972e+00
    phi[4,1]  R1236     -1.6787379980087280e+00
    phi[4,1]  R1237     -8.1126272678375244e-01
    phi[4,1]  R1238     -2.0037531852722168e+00
    phi[4,1]  R1239     -2.1069307327270508e+00
    phi[4,1]  R1240     -1.2515301704406738e+00
    phi[4,1]  R1241     -1.5814245939254761e+00
    phi[4,1]  R1242     -2.0014057159423828e+00
    phi[4,1]  R1243     -1.8219569921493530e+00
    phi[4,1]  R1244     9.0164966881275177e-02
    phi[4,1]  R1245     -1.4933149814605713e+00
    phi[4,1]  R1246     -2.0219403505325317e-01
    phi[4,1]  R1247     -1.9593131542205811e+00
    phi[4,1]  R1248     -1.2331484556198120e+00
    phi[4,1]  R1249     -8.1905007362365723e-01
    phi[4,1]  R1250     -1.9005004167556763e+00
    phi[4,1]  R1251     -2.3031768798828125e+00
    phi[4,1]  R1252     -2.1969819068908691e+00
    phi[4,1]  R1253     4.3382960557937622e-01
    phi[4,1]  R1254     -2.0276033878326416e+00
    phi[4,1]  R1255     1.2017848342657089e-01
    phi[4,1]  R1256     -1.2630753517150879e+00
    phi[4,1]  R1257     -1.1359472274780273e+00
    phi[4,1]  R1258     -1.9994518756866455e+00
    phi[4,1]  R1259     -2.1688213348388672e+00
    phi[4,1]  R1260     -2.6111125946044922e+00
    phi[4,1]  R1261     -1.5152133703231812e+00
    phi[4,1]  R1262     -1.4248226881027222e+00
    phi[4,1]  R1263     -2.3244929313659668e+00
    phi[4,1]  R1264     -1.2592172622680664e+00
    phi[4,1]  R1265     1.2390511482954025e-01
    phi[4,1]  R1266     9.3042838573455811e-01
    phi[4,1]  R1267     3.2924869656562805e-01
    phi[4,1]  R1268     -1.9579730033874512e+00
    phi[4,1]  R1269     -1.8124901056289673e+00
    phi[4,1]  R1270     -1.1141886711120605e+00
    phi[4,1]  R1271     -2.2809672355651855e+00
    phi[4,1]  R1272     -2.3023803234100342e+00
    phi[4,1]  R1273     -3.0915312767028809e+00
    phi[4,1]  R1274     -1.4350209236145020e+00
    phi[4,1]  R1275     -0.0541786327958107
    phi[4,1]  R1276     -1.8928896188735962e+00
    phi[4,1]  R1277     -2.0521986484527588e+00
    phi[4,1]  R1278     -9.1291368007659912e-01
    phi[4,1]  R1279     -8.6685991287231445e-01
    phi[4,1]  R1280     -2.1188676357269287e+00
    phi[4,1]  R1281     -2.6802144050598145e+00
    phi[4,1]  R1282     -1.5685625076293945e+00
    phi[4,1]  R1283     -2.9002516269683838e+00
    phi[4,1]  R1284     -2.0382649898529053e+00
    phi[4,1]  R1285     -1.8577950000762939e+00
    phi[4,1]  R1286     -9.5404225587844849e-01
    phi[4,1]  R1287     -1.8620798587799072e+00
    phi[4,1]  R1288     -2.3914270401000977e+00
    phi[4,1]  R1289     -2.7600278854370117e+00
    phi[4,1]  R1290     -2.0670785903930664e+00
    phi[4,1]  R1291     -1.9353444576263428e+00
    phi[4,1]  R1292     -2.5543472766876221e+00
    phi[4,1]  R1293     -2.6044440269470215e-01
    phi[4,1]  R1294     -4.7267064452171326e-01
    phi[4,1]  R1295     -1.1235343217849731e+00
    phi[4,1]  R1296     -1.4717134237289429e+00
    phi[4,1]  R1297     -1.7904587984085083e+00
    phi[4,1]  R1298     -2.3280544281005859e+00
    phi[4,1]  R1299     -2.3715248107910156e+00
    phi[4,1]  R1300     -7.3227733373641968e-01
    phi[4,1]  R1301     -3.3421175479888916e+00
    phi[4,1]  R1302     -1.7074190378189087e+00
    phi[4,1]  R1303     -2.9913179874420166e+00
    phi[4,1]  R1304     -2.9782578945159912e+00
    phi[4,1]  R1305     -1.1243221759796143e+00
    phi[4,1]  R1306     -1.2983950376510620e+00
    phi[4,1]  R1307     -1.3386058807373047e+00
    phi[4,1]  R1308     -2.0038964748382568e+00
    phi[4,1]  R1309     -2.7051808834075928e+00
    phi[4,1]  R1310     -8.7630116939544678e-01
    phi[4,1]  R1311     -2.7382895350456238e-01
    phi[4,1]  R1312     -1.5187896490097046e+00
    phi[4,1]  R1313     -3.4117621183395386e-01
    phi[4,1]  R1314     -7.3416489362716675e-01
    phi[4,1]  R1315     -1.1582061052322388e+00
    phi[4,1]  R1316     -1.4588338136672974e+00
    phi[4,1]  R1317     -1.4751677513122559e+00
    phi[4,1]  R1318     -1.6267303228378296e+00
    phi[4,1]  R1319     -2.5352110862731934e+00
    phi[4,1]  R1320     -2.8484699130058289e-01
    phi[4,1]  R1321     -6.8311071395874023e-01
    phi[4,1]  R1322     -5.0120645761489868e-01
    phi[4,1]  R1323     -1.2715778350830078e+00
    phi[4,1]  R1324     -0.700590968132019
    phi[2,3]  R18       1
    phi[2,3]  R19       1
    phi[2,3]  R27       -1
    phi[2,3]  R1325     -3.0999999046325684e+00
    phi[2,3]  R1326     -3.0999999046325684e+00
    phi[2,3]  R1327     -2.2400000095367432e+00
    phi[2,3]  R1328     -2.2400000095367432e+00
    phi[2,3]  R1329     -3.0999999046325684e+00
    phi[2,3]  R1330     -3.0999999046325684e+00
    phi[2,3]  R1331     -2.5699999332427979e+00
    phi[2,3]  R1332     -2.5699999332427979e+00
    phi[2,3]  R1333     -3.0999999046325684e+00
    phi[2,3]  R1334     -3.0999999046325684e+00
    phi[2,3]  R1335     -2.0899999141693115e+00
    phi[2,3]  R1336     -2.0899999141693115e+00
    phi[2,3]  R1337     -3.0999999046325684e+00
    phi[2,3]  R1338     -3.0999999046325684e+00
    phi[2,3]  R1339     6.5665221214294434e-01
    phi[2,3]  R1340     -3.9350733160972595e-01
    phi[2,3]  R1341     5.9350311756134033e-01
    phi[2,3]  R1342     3.1907051801681519e-02
    phi[2,3]  R1343     9.4231730699539185e-01
    phi[2,3]  R1344     -0.0262936819344759
    phi[2,3]  R1345     5.3548997640609741e-01
    phi[2,3]  R1346     1.0861637592315674e+00
    phi[2,3]  R1347     -4.0130129456520081e-01
    phi[2,3]  R1348     1.6357865929603577e-01
    phi[2,3]  R1349     -1.4103966951370239e-01
    phi[2,3]  R1350     7.3740124702453613e-01
    phi[2,3]  R1351     -2.2280490398406982e-01
    phi[2,3]  R1352     1.6671646386384964e-02
    phi[2,3]  R1353     1.2793336063623428e-03
    phi[2,3]  R1354     -1.3221390545368195e-01
    phi[2,3]  R1355     3.7927973270416260e-01
    phi[2,3]  R1356     -0.646546483039856
    phi[2,3]  R1357     2.4405905604362488e-01
    phi[2,3]  R1358     -5.0043207406997681e-01
    phi[2,3]  R1359     -1.0025626420974731e+00
    phi[2,3]  R1360     -1.2969179451465607e-01
    phi[2,3]  R1361     -6.7729949951171875e-01
    phi[2,3]  R1362     -2.2186813354492188e+00
    phi[2,3]  R1363     1.5505811572074890e-01
    phi[2,3]  R1364     -9.0339255332946777e-01
    phi[2,3]  R1365     1.7588694095611572e+00
    phi[2,3]  R1366     1.6818313598632812e+00
    phi[2,3]  R1367     8.3765685558319092e-01
    phi[2,3]  R1368     1.2070022821426392e+00
    phi[2,3]  R1369     1.8968569040298462e+00
    phi[2,3]  R1370     9.5927405357360840e-01
    phi[2,3]  R1371     6.3530933856964111e-01
    phi[2,3]  R1372     1.0913413763046265e+00
    phi[2,3]  R1373     -1.9238452911376953e+00
    phi[2,3]  R1374     -2.9808583259582520e+00
    phi[2,3]  R1375     -3.8795661926269531e+00
    phi[2,3]  R1376     -1.1897940635681152e+00
    phi[2,3]  R1377     -2.7477328777313232e+00
    phi[2,3]  R1378     -1.8996462821960449e+00
    phi[2,3]  R1379     -1.9139270782470703e+00
    phi[2,3]  R1380     -9.8166817426681519e-01
    phi[2,3]  R1381     -2.0804793834686279e+00
    phi[2,3]  R1382     1.7648479342460632e-01
    phi[2,3]  R1383     -2.7848584651947021e+00
    phi[2,3]  R1384     -1.9010753631591797e+00
    phi[2,3]  R1385     -1.1668673753738403e+00
    phi[2,3]  R1386     -1.3968093395233154e+00
    phi[2,3]  R1387     -1.1688163280487061e+00
    phi[2,3]  R1388     2.1711080074310303e+00
    phi[2,3]  R1389     -1.2230124473571777e+00
    phi[2,3]  R1390     -1.7018016576766968e+00
    phi[2,3]  R1391     -1.0363041162490845e+00
    phi[2,3]  R1392     -0.85454261302948
    phi[2,3]  R1393     -7.0511311292648315e-01
    phi[2,3]  R1394     -4.2925572395324707e-01
    phi[2,3]  R1395     1.6677631139755249e+00
    phi[2,3]  R1396     -3.5912892818450928e+00
    phi[2,3]  R1397     -1.5273511409759521e+00
    phi[2,3]  R1398     -2.0221693515777588e+00
    phi[2,3]  R1399     -1.6051329374313354e+00
    phi[2,3]  R1400     -2.5104653835296631e+00
    phi[2,3]  R1401     -8.1802912056446075e-02
    phi[2,3]  R1402     -7.4875503778457642e-02
    phi[3,2]  R18       -1
    phi[3,2]  R27       1
    phi[3,2]  R28       1
    phi[3,2]  R1403     -3.0999999046325684e+00
    phi[3,2]  R1404     -3.0999999046325684e+00
    phi[3,2]  R1405     -2.2400000095367432e+00
    phi[3,2]  R1406     -2.2400000095367432e+00
    phi[3,2]  R1407     -3.0999999046325684e+00
    phi[3,2]  R1408     -3.0999999046325684e+00
    phi[3,2]  R1409     -2.5699999332427979e+00
    phi[3,2]  R1410     -2.5699999332427979e+00
    phi[3,2]  R1411     -3.0999999046325684e+00
    phi[3,2]  R1412     -3.0999999046325684e+00
    phi[3,2]  R1413     -2.0899999141693115e+00
    phi[3,2]  R1414     -2.0899999141693115e+00
    phi[3,2]  R1415     -3.0999999046325684e+00
    phi[3,2]  R1416     -3.0999999046325684e+00
    phi[3,2]  R1417     1.5505811572074890e-01
    phi[3,2]  R1418     -9.0339255332946777e-01
    phi[3,2]  R1419     1.7588694095611572e+00
    phi[3,2]  R1420     1.6818313598632812e+00
    phi[3,2]  R1421     8.3765685558319092e-01
    phi[3,2]  R1422     1.2070022821426392e+00
    phi[3,2]  R1423     1.8968569040298462e+00
    phi[3,2]  R1424     9.5927405357360840e-01
    phi[3,2]  R1425     6.3530933856964111e-01
    phi[3,2]  R1426     1.0913413763046265e+00
    phi[3,2]  R1427     -1.9238452911376953e+00
    phi[3,2]  R1428     -2.9808583259582520e+00
    phi[3,2]  R1429     -3.8795661926269531e+00
    phi[3,2]  R1430     -1.1897940635681152e+00
    phi[3,2]  R1431     -2.7477328777313232e+00
    phi[3,2]  R1432     -1.8996462821960449e+00
    phi[3,2]  R1433     -1.9139270782470703e+00
    phi[3,2]  R1434     -9.8166817426681519e-01
    phi[3,2]  R1435     -2.0804793834686279e+00
    phi[3,2]  R1436     1.7648479342460632e-01
    phi[3,2]  R1437     -2.7848584651947021e+00
    phi[3,2]  R1438     -1.9010753631591797e+00
    phi[3,2]  R1439     -1.1668673753738403e+00
    phi[3,2]  R1440     -1.3968093395233154e+00
    phi[3,2]  R1441     -1.1688163280487061e+00
    phi[3,2]  R1442     2.1711080074310303e+00
    phi[3,2]  R1443     -1.2230124473571777e+00
    phi[3,2]  R1444     -1.7018016576766968e+00
    phi[3,2]  R1445     -1.0363041162490845e+00
    phi[3,2]  R1446     -0.85454261302948
    phi[3,2]  R1447     -7.0511311292648315e-01
    phi[3,2]  R1448     -4.2925572395324707e-01
    phi[3,2]  R1449     1.6677631139755249e+00
    phi[3,2]  R1450     -3.5912892818450928e+00
    phi[3,2]  R1451     -1.5273511409759521e+00
    phi[3,2]  R1452     -2.0221693515777588e+00
    phi[3,2]  R1453     -1.6051329374313354e+00
    phi[3,2]  R1454     -2.5104653835296631e+00
    phi[3,2]  R1455     -8.1802912056446075e-02
    phi[3,2]  R1456     -7.4875503778457642e-02
    phi[3,2]  R1457     6.5665221214294434e-01
    phi[3,2]  R1458     -3.9350733160972595e-01
    phi[3,2]  R1459     5.9350311756134033e-01
    phi[3,2]  R1460     3.1907051801681519e-02
    phi[3,2]  R1461     9.4231730699539185e-01
    phi[3,2]  R1462     -0.0262936819344759
    phi[3,2]  R1463     5.3548997640609741e-01
    phi[3,2]  R1464     1.0861637592315674e+00
    phi[3,2]  R1465     -4.0130129456520081e-01
    phi[3,2]  R1466     1.6357865929603577e-01
    phi[3,2]  R1467     -1.4103966951370239e-01
    phi[3,2]  R1468     7.3740124702453613e-01
    phi[3,2]  R1469     -2.2280490398406982e-01
    phi[3,2]  R1470     1.6671646386384964e-02
    phi[3,2]  R1471     1.2793336063623428e-03
    phi[3,2]  R1472     -1.3221390545368195e-01
    phi[3,2]  R1473     3.7927973270416260e-01
    phi[3,2]  R1474     -0.646546483039856
    phi[3,2]  R1475     2.4405905604362488e-01
    phi[3,2]  R1476     -5.0043207406997681e-01
    phi[3,2]  R1477     -1.0025626420974731e+00
    phi[3,2]  R1478     -1.2969179451465607e-01
    phi[3,2]  R1479     -6.7729949951171875e-01
    phi[3,2]  R1480     -2.2186813354492188e+00
    phi[2,6]  R18       1
    phi[2,6]  R19       1
    phi[2,6]  R54       -1
    phi[2,6]  R1481     -3.0999999046325684e+00
    phi[2,6]  R1482     -3.0999999046325684e+00
    phi[2,6]  R1483     -2.2400000095367432e+00
    phi[2,6]  R1484     -2.2400000095367432e+00
    phi[2,6]  R1485     -3.0999999046325684e+00
    phi[2,6]  R1486     -3.0999999046325684e+00
    phi[2,6]  R1487     -2.5699999332427979e+00
    phi[2,6]  R1488     -2.5699999332427979e+00
    phi[2,6]  R1489     -3.0999999046325684e+00
    phi[2,6]  R1490     -3.0999999046325684e+00
    phi[2,6]  R1491     -2.0899999141693115e+00
    phi[2,6]  R1492     -2.0899999141693115e+00
    phi[2,6]  R1493     -3.0999999046325684e+00
    phi[2,6]  R1494     -3.0999999046325684e+00
    phi[2,6]  R1495     6.5665221214294434e-01
    phi[2,6]  R1496     -3.9350733160972595e-01
    phi[2,6]  R1497     5.9350311756134033e-01
    phi[2,6]  R1498     3.1907051801681519e-02
    phi[2,6]  R1499     9.4231730699539185e-01
    phi[2,6]  R1500     -0.0262936819344759
    phi[2,6]  R1501     5.3548997640609741e-01
    phi[2,6]  R1502     1.0861637592315674e+00
    phi[2,6]  R1503     -4.0130129456520081e-01
    phi[2,6]  R1504     1.6357865929603577e-01
    phi[2,6]  R1505     -1.4103966951370239e-01
    phi[2,6]  R1506     7.3740124702453613e-01
    phi[2,6]  R1507     -2.2280490398406982e-01
    phi[2,6]  R1508     1.6671646386384964e-02
    phi[2,6]  R1509     1.2793336063623428e-03
    phi[2,6]  R1510     -1.3221390545368195e-01
    phi[2,6]  R1511     3.7927973270416260e-01
    phi[2,6]  R1512     -0.646546483039856
    phi[2,6]  R1513     2.4405905604362488e-01
    phi[2,6]  R1514     -5.0043207406997681e-01
    phi[2,6]  R1515     -1.0025626420974731e+00
    phi[2,6]  R1516     -1.2969179451465607e-01
    phi[2,6]  R1517     -6.7729949951171875e-01
    phi[2,6]  R1518     -2.2186813354492188e+00
    phi[2,6]  R1519     -1.2849243879318237e+00
    phi[2,6]  R1520     3.5921385884284973e-01
    phi[2,6]  R1521     1.8061410188674927e+00
    phi[2,6]  R1522     5.8068895339965820e-01
    phi[2,6]  R1523     -1.1297363042831421e+00
    phi[2,6]  R1524     1.3971229791641235e+00
    phi[2,6]  R1525     3.5957634449005127e-01
    phi[2,6]  R1526     -6.3627600669860840e-01
    phi[2,6]  R1527     6.4671212434768677e-01
    phi[2,6]  R1528     5.4972630739212036e-01
    phi[2,6]  R1529     -2.6063793897628784e-01
    phi[2,6]  R1530     -1.5084406137466431e+00
    phi[2,6]  R1531     -1.3934473991394043e+00
    phi[2,6]  R1532     -2.1964488029479980e+00
    phi[2,6]  R1533     -2.0258760452270508e+00
    phi[2,6]  R1534     -1.9127044677734375e+00
    phi[2,6]  R1535     -1.8453401327133179e+00
    phi[2,6]  R1536     -1.6860210895538330e+00
    phi[2,6]  R1537     -8.0275887250900269e-01
    phi[2,6]  R1538     -1.8084867000579834e+00
    phi[2,6]  R1539     -1.4000201225280762e+00
    phi[2,6]  R1540     -2.2909200191497803e+00
    phi[2,6]  R1541     -4.9704611301422119e-01
    phi[2,6]  R1542     -1.8717468976974487e+00
    phi[2,6]  R1543     -1.29019296169281
    phi[2,6]  R1544     -1.2674748897552490e+00
    phi[2,6]  R1545     -1.1447055339813232e+00
    phi[2,6]  R1546     4.5786866545677185e-01
    phi[2,6]  R1547     -3.9652937650680542e-01
    phi[2,6]  R1548     -3.9489609003067017e-01
    phi[2,6]  R1549     -2.1667262911796570e-01
    phi[2,6]  R1550     -1.5726330280303955e+00
    phi[2,6]  R1551     -2.3770773410797119e+00
    phi[2,6]  R1552     -1.8198574781417847e+00
    phi[2,6]  R1553     -1.2846367359161377e+00
    phi[2,6]  R1554     -1.5082405805587769e+00
    phi[2,6]  R1555     -2.7366977930068970e-01
    phi[2,6]  R1556     -6.8498212099075317e-01
    phi[2,6]  R1557     -1.0353078842163086e+00
    phi[2,6]  R1558     2.2949266433715820e-01
    phi[2,6]  R1559     -1.3331376314163208e+00
    phi[2,6]  R1560     -1.5641378164291382e+00
    phi[2,6]  R1561     -1.4404129981994629e+00
    phi[2,6]  R1562     -8.9668321609497070e-01
    phi[2,6]  R1563     -2.0621938705444336e+00
    phi[2,6]  R1564     -9.1890376806259155e-01
    phi[2,6]  R1565     -1.9950447976589203e-01
    phi[2,6]  R1566     1.8967778980731964e-01
    phi[2,6]  R1567     -9.0693074464797974e-01
    phi[2,6]  R1568     -0.672366201877594
    phi[2,6]  R1569     -1.3862019777297974e+00
    phi[2,6]  R1570     -1.4382216334342957e-01
    phi[2,6]  R1571     -1.5012931823730469e+00
    phi[2,6]  R1572     -2.2174069881439209e+00
    phi[2,6]  R1573     3.2886466383934021e-01
    phi[2,6]  R1574     -2.2201623916625977e+00
    phi[2,6]  R1575     -1.2742729187011719e+00
    phi[2,6]  R1576     -2.9954853057861328e+00
    phi[2,6]  R1577     -2.8784589767456055e+00
    phi[6,2]  R18       -1
    phi[6,2]  R54       1
    phi[6,2]  R55       1
    phi[6,2]  R1578     -3.0999999046325684e+00
    phi[6,2]  R1579     -3.0999999046325684e+00
    phi[6,2]  R1580     -2.2400000095367432e+00
    phi[6,2]  R1581     -2.2400000095367432e+00
    phi[6,2]  R1582     -3.0999999046325684e+00
    phi[6,2]  R1583     -3.0999999046325684e+00
    phi[6,2]  R1584     -2.5699999332427979e+00
    phi[6,2]  R1585     -2.5699999332427979e+00
    phi[6,2]  R1586     -3.0999999046325684e+00
    phi[6,2]  R1587     -3.0999999046325684e+00
    phi[6,2]  R1588     -2.0899999141693115e+00
    phi[6,2]  R1589     -2.0899999141693115e+00
    phi[6,2]  R1590     -3.0999999046325684e+00
    phi[6,2]  R1591     -3.0999999046325684e+00
    phi[6,2]  R1592     -1.2849243879318237e+00
    phi[6,2]  R1593     3.5921385884284973e-01
    phi[6,2]  R1594     1.8061410188674927e+00
    phi[6,2]  R1595     5.8068895339965820e-01
    phi[6,2]  R1596     -1.1297363042831421e+00
    phi[6,2]  R1597     1.3971229791641235e+00
    phi[6,2]  R1598     3.5957634449005127e-01
    phi[6,2]  R1599     -6.3627600669860840e-01
    phi[6,2]  R1600     6.4671212434768677e-01
    phi[6,2]  R1601     5.4972630739212036e-01
    phi[6,2]  R1602     -2.6063793897628784e-01
    phi[6,2]  R1603     -1.5084406137466431e+00
    phi[6,2]  R1604     -1.3934473991394043e+00
    phi[6,2]  R1605     -2.1964488029479980e+00
    phi[6,2]  R1606     -2.0258760452270508e+00
    phi[6,2]  R1607     -1.9127044677734375e+00
    phi[6,2]  R1608     -1.8453401327133179e+00
    phi[6,2]  R1609     -1.6860210895538330e+00
    phi[6,2]  R1610     -8.0275887250900269e-01
    phi[6,2]  R1611     -1.8084867000579834e+00
    phi[6,2]  R1612     -1.4000201225280762e+00
    phi[6,2]  R1613     -2.2909200191497803e+00
    phi[6,2]  R1614     -4.9704611301422119e-01
    phi[6,2]  R1615     -1.8717468976974487e+00
    phi[6,2]  R1616     -1.29019296169281
    phi[6,2]  R1617     -1.2674748897552490e+00
    phi[6,2]  R1618     -1.1447055339813232e+00
    phi[6,2]  R1619     4.5786866545677185e-01
    phi[6,2]  R1620     -3.9652937650680542e-01
    phi[6,2]  R1621     -3.9489609003067017e-01
    phi[6,2]  R1622     -2.1667262911796570e-01
    phi[6,2]  R1623     -1.5726330280303955e+00
    phi[6,2]  R1624     -2.3770773410797119e+00
    phi[6,2]  R1625     -1.8198574781417847e+00
    phi[6,2]  R1626     -1.2846367359161377e+00
    phi[6,2]  R1627     -1.5082405805587769e+00
    phi[6,2]  R1628     -2.7366977930068970e-01
    phi[6,2]  R1629     -6.8498212099075317e-01
    phi[6,2]  R1630     -1.0353078842163086e+00
    phi[6,2]  R1631     2.2949266433715820e-01
    phi[6,2]  R1632     -1.3331376314163208e+00
    phi[6,2]  R1633     -1.5641378164291382e+00
    phi[6,2]  R1634     -1.4404129981994629e+00
    phi[6,2]  R1635     -8.9668321609497070e-01
    phi[6,2]  R1636     -2.0621938705444336e+00
    phi[6,2]  R1637     -9.1890376806259155e-01
    phi[6,2]  R1638     -1.9950447976589203e-01
    phi[6,2]  R1639     1.8967778980731964e-01
    phi[6,2]  R1640     -9.0693074464797974e-01
    phi[6,2]  R1641     -0.672366201877594
    phi[6,2]  R1642     -1.3862019777297974e+00
    phi[6,2]  R1643     -1.4382216334342957e-01
    phi[6,2]  R1644     -1.5012931823730469e+00
    phi[6,2]  R1645     -2.2174069881439209e+00
    phi[6,2]  R1646     3.2886466383934021e-01
    phi[6,2]  R1647     -2.2201623916625977e+00
    phi[6,2]  R1648     -1.2742729187011719e+00
    phi[6,2]  R1649     -2.9954853057861328e+00
    phi[6,2]  R1650     -2.8784589767456055e+00
    phi[6,2]  R1651     6.5665221214294434e-01
    phi[6,2]  R1652     -3.9350733160972595e-01
    phi[6,2]  R1653     5.9350311756134033e-01
    phi[6,2]  R1654     3.1907051801681519e-02
    phi[6,2]  R1655     9.4231730699539185e-01
    phi[6,2]  R1656     -0.0262936819344759
    phi[6,2]  R1657     5.3548997640609741e-01
    phi[6,2]  R1658     1.0861637592315674e+00
    phi[6,2]  R1659     -4.0130129456520081e-01
    phi[6,2]  R1660     1.6357865929603577e-01
    phi[6,2]  R1661     -1.4103966951370239e-01
    phi[6,2]  R1662     7.3740124702453613e-01
    phi[6,2]  R1663     -2.2280490398406982e-01
    phi[6,2]  R1664     1.6671646386384964e-02
    phi[6,2]  R1665     1.2793336063623428e-03
    phi[6,2]  R1666     -1.3221390545368195e-01
    phi[6,2]  R1667     3.7927973270416260e-01
    phi[6,2]  R1668     -0.646546483039856
    phi[6,2]  R1669     2.4405905604362488e-01
    phi[6,2]  R1670     -5.0043207406997681e-01
    phi[6,2]  R1671     -1.0025626420974731e+00
    phi[6,2]  R1672     -1.2969179451465607e-01
    phi[6,2]  R1673     -6.7729949951171875e-01
    phi[6,2]  R1674     -2.2186813354492188e+00
    phi[3,6]  R27       1
    phi[3,6]  R28       1
    phi[3,6]  R54       -1
    phi[3,6]  R1675     -3.0999999046325684e+00
    phi[3,6]  R1676     -3.0999999046325684e+00
    phi[3,6]  R1677     -2.2400000095367432e+00
    phi[3,6]  R1678     -2.2400000095367432e+00
    phi[3,6]  R1679     -3.0999999046325684e+00
    phi[3,6]  R1680     -3.0999999046325684e+00
    phi[3,6]  R1681     -2.5699999332427979e+00
    phi[3,6]  R1682     -2.5699999332427979e+00
    phi[3,6]  R1683     -3.0999999046325684e+00
    phi[3,6]  R1684     -3.0999999046325684e+00
    phi[3,6]  R1685     -2.0899999141693115e+00
    phi[3,6]  R1686     -2.0899999141693115e+00
    phi[3,6]  R1687     -3.0999999046325684e+00
    phi[3,6]  R1688     -3.0999999046325684e+00
    phi[3,6]  R1689     1.5505811572074890e-01
    phi[3,6]  R1690     -9.0339255332946777e-01
    phi[3,6]  R1691     1.7588694095611572e+00
    phi[3,6]  R1692     1.6818313598632812e+00
    phi[3,6]  R1693     8.3765685558319092e-01
    phi[3,6]  R1694     1.2070022821426392e+00
    phi[3,6]  R1695     1.8968569040298462e+00
    phi[3,6]  R1696     9.5927405357360840e-01
    phi[3,6]  R1697     6.3530933856964111e-01
    phi[3,6]  R1698     1.0913413763046265e+00
    phi[3,6]  R1699     -1.9238452911376953e+00
    phi[3,6]  R1700     -2.9808583259582520e+00
    phi[3,6]  R1701     -3.8795661926269531e+00
    phi[3,6]  R1702     -1.1897940635681152e+00
    phi[3,6]  R1703     -2.7477328777313232e+00
    phi[3,6]  R1704     -1.8996462821960449e+00
    phi[3,6]  R1705     -1.9139270782470703e+00
    phi[3,6]  R1706     -9.8166817426681519e-01
    phi[3,6]  R1707     -2.0804793834686279e+00
    phi[3,6]  R1708     1.7648479342460632e-01
    phi[3,6]  R1709     -2.7848584651947021e+00
    phi[3,6]  R1710     -1.9010753631591797e+00
    phi[3,6]  R1711     -1.1668673753738403e+00
    phi[3,6]  R1712     -1.3968093395233154e+00
    phi[3,6]  R1713     -1.1688163280487061e+00
    phi[3,6]  R1714     2.1711080074310303e+00
    phi[3,6]  R1715     -1.2230124473571777e+00
    phi[3,6]  R1716     -1.7018016576766968e+00
    phi[3,6]  R1717     -1.0363041162490845e+00
    phi[3,6]  R1718     -0.85454261302948
    phi[3,6]  R1719     -7.0511311292648315e-01
    phi[3,6]  R1720     -4.2925572395324707e-01
    phi[3,6]  R1721     1.6677631139755249e+00
    phi[3,6]  R1722     -3.5912892818450928e+00
    phi[3,6]  R1723     -1.5273511409759521e+00
    phi[3,6]  R1724     -2.0221693515777588e+00
    phi[3,6]  R1725     -1.6051329374313354e+00
    phi[3,6]  R1726     -2.5104653835296631e+00
    phi[3,6]  R1727     -8.1802912056446075e-02
    phi[3,6]  R1728     -7.4875503778457642e-02
    phi[3,6]  R1729     -1.2849243879318237e+00
    phi[3,6]  R1730     3.5921385884284973e-01
    phi[3,6]  R1731     1.8061410188674927e+00
    phi[3,6]  R1732     5.8068895339965820e-01
    phi[3,6]  R1733     -1.1297363042831421e+00
    phi[3,6]  R1734     1.3971229791641235e+00
    phi[3,6]  R1735     3.5957634449005127e-01
    phi[3,6]  R1736     -6.3627600669860840e-01
    phi[3,6]  R1737     6.4671212434768677e-01
    phi[3,6]  R1738     5.4972630739212036e-01
    phi[3,6]  R1739     -2.6063793897628784e-01
    phi[3,6]  R1740     -1.5084406137466431e+00
    phi[3,6]  R1741     -1.3934473991394043e+00
    phi[3,6]  R1742     -2.1964488029479980e+00
    phi[3,6]  R1743     -2.0258760452270508e+00
    phi[3,6]  R1744     -1.9127044677734375e+00
    phi[3,6]  R1745     -1.8453401327133179e+00
    phi[3,6]  R1746     -1.6860210895538330e+00
    phi[3,6]  R1747     -8.0275887250900269e-01
    phi[3,6]  R1748     -1.8084867000579834e+00
    phi[3,6]  R1749     -1.4000201225280762e+00
    phi[3,6]  R1750     -2.2909200191497803e+00
    phi[3,6]  R1751     -4.9704611301422119e-01
    phi[3,6]  R1752     -1.8717468976974487e+00
    phi[3,6]  R1753     -1.29019296169281
    phi[3,6]  R1754     -1.2674748897552490e+00
    phi[3,6]  R1755     -1.1447055339813232e+00
    phi[3,6]  R1756     4.5786866545677185e-01
    phi[3,6]  R1757     -3.9652937650680542e-01
    phi[3,6]  R1758     -3.9489609003067017e-01
    phi[3,6]  R1759     -2.1667262911796570e-01
    phi[3,6]  R1760     -1.5726330280303955e+00
    phi[3,6]  R1761     -2.3770773410797119e+00
    phi[3,6]  R1762     -1.8198574781417847e+00
    phi[3,6]  R1763     -1.2846367359161377e+00
    phi[3,6]  R1764     -1.5082405805587769e+00
    phi[3,6]  R1765     -2.7366977930068970e-01
    phi[3,6]  R1766     -6.8498212099075317e-01
    phi[3,6]  R1767     -1.0353078842163086e+00
    phi[3,6]  R1768     2.2949266433715820e-01
    phi[3,6]  R1769     -1.3331376314163208e+00
    phi[3,6]  R1770     -1.5641378164291382e+00
    phi[3,6]  R1771     -1.4404129981994629e+00
    phi[3,6]  R1772     -8.9668321609497070e-01
    phi[3,6]  R1773     -2.0621938705444336e+00
    phi[3,6]  R1774     -9.1890376806259155e-01
    phi[3,6]  R1775     -1.9950447976589203e-01
    phi[3,6]  R1776     1.8967778980731964e-01
    phi[3,6]  R1777     -9.0693074464797974e-01
    phi[3,6]  R1778     -0.672366201877594
    phi[3,6]  R1779     -1.3862019777297974e+00
    phi[3,6]  R1780     -1.4382216334342957e-01
    phi[3,6]  R1781     -1.5012931823730469e+00
    phi[3,6]  R1782     -2.2174069881439209e+00
    phi[3,6]  R1783     3.2886466383934021e-01
    phi[3,6]  R1784     -2.2201623916625977e+00
    phi[3,6]  R1785     -1.2742729187011719e+00
    phi[3,6]  R1786     -2.9954853057861328e+00
    phi[3,6]  R1787     -2.8784589767456055e+00
    phi[6,3]  R27       -1
    phi[6,3]  R54       1
    phi[6,3]  R55       1
    phi[6,3]  R1788     -3.0999999046325684e+00
    phi[6,3]  R1789     -3.0999999046325684e+00
    phi[6,3]  R1790     -2.2400000095367432e+00
    phi[6,3]  R1791     -2.2400000095367432e+00
    phi[6,3]  R1792     -3.0999999046325684e+00
    phi[6,3]  R1793     -3.0999999046325684e+00
    phi[6,3]  R1794     -2.5699999332427979e+00
    phi[6,3]  R1795     -2.5699999332427979e+00
    phi[6,3]  R1796     -3.0999999046325684e+00
    phi[6,3]  R1797     -3.0999999046325684e+00
    phi[6,3]  R1798     -2.0899999141693115e+00
    phi[6,3]  R1799     -2.0899999141693115e+00
    phi[6,3]  R1800     -3.0999999046325684e+00
    phi[6,3]  R1801     -3.0999999046325684e+00
    phi[6,3]  R1802     -1.2849243879318237e+00
    phi[6,3]  R1803     3.5921385884284973e-01
    phi[6,3]  R1804     1.8061410188674927e+00
    phi[6,3]  R1805     5.8068895339965820e-01
    phi[6,3]  R1806     -1.1297363042831421e+00
    phi[6,3]  R1807     1.3971229791641235e+00
    phi[6,3]  R1808     3.5957634449005127e-01
    phi[6,3]  R1809     -6.3627600669860840e-01
    phi[6,3]  R1810     6.4671212434768677e-01
    phi[6,3]  R1811     5.4972630739212036e-01
    phi[6,3]  R1812     -2.6063793897628784e-01
    phi[6,3]  R1813     -1.5084406137466431e+00
    phi[6,3]  R1814     -1.3934473991394043e+00
    phi[6,3]  R1815     -2.1964488029479980e+00
    phi[6,3]  R1816     -2.0258760452270508e+00
    phi[6,3]  R1817     -1.9127044677734375e+00
    phi[6,3]  R1818     -1.8453401327133179e+00
    phi[6,3]  R1819     -1.6860210895538330e+00
    phi[6,3]  R1820     -8.0275887250900269e-01
    phi[6,3]  R1821     -1.8084867000579834e+00
    phi[6,3]  R1822     -1.4000201225280762e+00
    phi[6,3]  R1823     -2.2909200191497803e+00
    phi[6,3]  R1824     -4.9704611301422119e-01
    phi[6,3]  R1825     -1.8717468976974487e+00
    phi[6,3]  R1826     -1.29019296169281
    phi[6,3]  R1827     -1.2674748897552490e+00
    phi[6,3]  R1828     -1.1447055339813232e+00
    phi[6,3]  R1829     4.5786866545677185e-01
    phi[6,3]  R1830     -3.9652937650680542e-01
    phi[6,3]  R1831     -3.9489609003067017e-01
    phi[6,3]  R1832     -2.1667262911796570e-01
    phi[6,3]  R1833     -1.5726330280303955e+00
    phi[6,3]  R1834     -2.3770773410797119e+00
    phi[6,3]  R1835     -1.8198574781417847e+00
    phi[6,3]  R1836     -1.2846367359161377e+00
    phi[6,3]  R1837     -1.5082405805587769e+00
    phi[6,3]  R1838     -2.7366977930068970e-01
    phi[6,3]  R1839     -6.8498212099075317e-01
    phi[6,3]  R1840     -1.0353078842163086e+00
    phi[6,3]  R1841     2.2949266433715820e-01
    phi[6,3]  R1842     -1.3331376314163208e+00
    phi[6,3]  R1843     -1.5641378164291382e+00
    phi[6,3]  R1844     -1.4404129981994629e+00
    phi[6,3]  R1845     -8.9668321609497070e-01
    phi[6,3]  R1846     -2.0621938705444336e+00
    phi[6,3]  R1847     -9.1890376806259155e-01
    phi[6,3]  R1848     -1.9950447976589203e-01
    phi[6,3]  R1849     1.8967778980731964e-01
    phi[6,3]  R1850     -9.0693074464797974e-01
    phi[6,3]  R1851     -0.672366201877594
    phi[6,3]  R1852     -1.3862019777297974e+00
    phi[6,3]  R1853     -1.4382216334342957e-01
    phi[6,3]  R1854     -1.5012931823730469e+00
    phi[6,3]  R1855     -2.2174069881439209e+00
    phi[6,3]  R1856     3.2886466383934021e-01
    phi[6,3]  R1857     -2.2201623916625977e+00
    phi[6,3]  R1858     -1.2742729187011719e+00
    phi[6,3]  R1859     -2.9954853057861328e+00
    phi[6,3]  R1860     -2.8784589767456055e+00
    phi[6,3]  R1861     1.5505811572074890e-01
    phi[6,3]  R1862     -9.0339255332946777e-01
    phi[6,3]  R1863     1.7588694095611572e+00
    phi[6,3]  R1864     1.6818313598632812e+00
    phi[6,3]  R1865     8.3765685558319092e-01
    phi[6,3]  R1866     1.2070022821426392e+00
    phi[6,3]  R1867     1.8968569040298462e+00
    phi[6,3]  R1868     9.5927405357360840e-01
    phi[6,3]  R1869     6.3530933856964111e-01
    phi[6,3]  R1870     1.0913413763046265e+00
    phi[6,3]  R1871     -1.9238452911376953e+00
    phi[6,3]  R1872     -2.9808583259582520e+00
    phi[6,3]  R1873     -3.8795661926269531e+00
    phi[6,3]  R1874     -1.1897940635681152e+00
    phi[6,3]  R1875     -2.7477328777313232e+00
    phi[6,3]  R1876     -1.8996462821960449e+00
    phi[6,3]  R1877     -1.9139270782470703e+00
    phi[6,3]  R1878     -9.8166817426681519e-01
    phi[6,3]  R1879     -2.0804793834686279e+00
    phi[6,3]  R1880     1.7648479342460632e-01
    phi[6,3]  R1881     -2.7848584651947021e+00
    phi[6,3]  R1882     -1.9010753631591797e+00
    phi[6,3]  R1883     -1.1668673753738403e+00
    phi[6,3]  R1884     -1.3968093395233154e+00
    phi[6,3]  R1885     -1.1688163280487061e+00
    phi[6,3]  R1886     2.1711080074310303e+00
    phi[6,3]  R1887     -1.2230124473571777e+00
    phi[6,3]  R1888     -1.7018016576766968e+00
    phi[6,3]  R1889     -1.0363041162490845e+00
    phi[6,3]  R1890     -0.85454261302948
    phi[6,3]  R1891     -7.0511311292648315e-01
    phi[6,3]  R1892     -4.2925572395324707e-01
    phi[6,3]  R1893     1.6677631139755249e+00
    phi[6,3]  R1894     -3.5912892818450928e+00
    phi[6,3]  R1895     -1.5273511409759521e+00
    phi[6,3]  R1896     -2.0221693515777588e+00
    phi[6,3]  R1897     -1.6051329374313354e+00
    phi[6,3]  R1898     -2.5104653835296631e+00
    phi[6,3]  R1899     -8.1802912056446075e-02
    phi[6,3]  R1900     -7.4875503778457642e-02
    phi[3,8]  R27       1
    phi[3,8]  R28       1
    phi[3,8]  R29       -2.2211699524742232e+00
    phi[3,8]  R30       -3.5163990986908766e-01
    phi[3,8]  R31       5.3930914446124412e-01
    phi[3,8]  R32       1.9497162511291610e+00
    phi[3,8]  R33       2.5253948896895722e+00
    phi[3,8]  R34       1.6398475061762448e+00
    phi[3,8]  R35       -2.3559881904214417e+00
    phi[3,8]  R64       -1
    phi[3,8]  R1901     -5.3211698571067920e+00
    phi[3,8]  R1902     -8.7882995215834514e-01
    phi[3,8]  R1903     -2.5916399194058308e+00
    phi[3,8]  R1904     -1.8883600996676555e+00
    phi[3,8]  R1905     -2.5606907601713242e+00
    phi[3,8]  R1906     -3.6393090490938125e+00
    phi[3,8]  R1907     -6.2028368211363683e-01
    phi[3,8]  R1908     -4.5197161843719584e+00
    phi[3,8]  R1909     -5.7460501494299621e-01
    phi[3,8]  R1910     -5.6253947943221405e+00
    phi[3,8]  R1911     -4.5015240799306677e-01
    phi[3,8]  R1912     -3.7298474203455561e+00
    phi[3,8]  R1913     -5.4559880950540105e+00
    phi[3,8]  R1914     -7.4401171421112666e-01
    phi[3,8]  R1915     -1.0061287449487444e-01
    phi[3,8]  R1916     -1.1913451572392331e-01
    phi[3,8]  R1917     -1.2441994962194780e-01
    phi[3,8]  R1918     -1.6405010417240473e-01
    phi[3,8]  R1919     -1.7476771882089714e-01
    phi[3,8]  R1920     -2.2099369218834775e-01
    phi[3,8]  R1921     -2.2690833623148166e-01
    phi[3,8]  R1922     -2.3493312568868041e-01
    phi[3,8]  R1923     -3.0736724235888169e-01
    phi[3,8]  R1924     -3.1408401389396534e-01
    phi[3,8]  R1925     -3.0344879327365315e-01
    phi[3,8]  R1926     -3.2063730327859030e-01
    phi[3,8]  R1927     -0.33355099436347
    phi[3,8]  R1928     -4.0838630326807990e-01
    phi[3,8]  R1929     -4.8477211449658508e-01
    phi[3,8]  R1930     -5.3140267524927887e-01
    phi[3,8]  R1931     -6.0851077786734464e-01
    phi[3,8]  R1932     -1.0064343637199875e+00
    phi[3,8]  R1933     -7.3101242820957446e-01
    phi[3,8]  R1934     -1.2939130862713817e+00
    phi[3,8]  R1935     -1.7870115172002921e-01
    phi[3,8]  R1936     -2.0128825636136494e-01
    phi[3,8]  R1937     -3.0973053848687226e-01
    phi[3,8]  R1938     -3.4124047417172143e-01
    phi[3,8]  R1939     -3.4548196962154987e-01
    phi[3,8]  R1940     -3.6145027833908472e-01
    phi[3,8]  R1941     -3.6462231805025047e-01
    phi[3,8]  R1942     -4.3119997787861530e-01
    phi[3,8]  R1943     -0.690881510721149
    phi[3,8]  R1944     -5.8291882768648273e-01
    phi[3,8]  R1945     -2.8394573006048518e-01
    phi[3,8]  R1946     -2.9830531899976309e-01
    phi[3,8]  R1947     -3.4546297451622232e-01
    phi[3,8]  R1948     -3.7349076441729334e-01
    phi[3,8]  R1949     -4.1141526535806094e-01
    phi[3,8]  R1950     -6.4597066158527938e-01
    phi[3,8]  R1951     -5.5387957500991414e-01
    phi[3,8]  R1952     -7.4527458109734468e-01
    phi[3,8]  R1953     -1.2786839476680236e+00
    phi[3,8]  R1954     -1.5420203483262782e+00
    phi[4,5]  R36       1
    phi[4,5]  R37       1
    phi[4,5]  R45       -1
    phi[4,5]  R1955     -3.0999999046325684e+00
    phi[4,5]  R1956     -3.0999999046325684e+00
    phi[4,5]  R1957     -2.2400000095367432e+00
    phi[4,5]  R1958     -2.2400000095367432e+00
    phi[4,5]  R1959     -3.0999999046325684e+00
    phi[4,5]  R1960     -3.0999999046325684e+00
    phi[4,5]  R1961     -2.5699999332427979e+00
    phi[4,5]  R1962     -2.5699999332427979e+00
    phi[4,5]  R1963     -3.0999999046325684e+00
    phi[4,5]  R1964     -3.0999999046325684e+00
    phi[4,5]  R1965     -2.0899999141693115e+00
    phi[4,5]  R1966     -2.0899999141693115e+00
    phi[4,5]  R1967     -3.0999999046325684e+00
    phi[4,5]  R1968     -3.0999999046325684e+00
    phi[4,5]  R1969     1.3247875869274139e-01
    phi[4,5]  R1970     1.8049118518829346e+00
    phi[4,5]  R1971     1.5372670888900757e+00
    phi[4,5]  R1972     2.00858473777771
    phi[4,5]  R1973     2.4449262619018555e+00
    phi[4,5]  R1974     2.1936743259429932e+00
    phi[4,5]  R1975     -1.7578488588333130e-01
    phi[4,5]  R1976     1.1151608228683472e+00
    phi[4,5]  R1977     1.8097747564315796e+00
    phi[4,5]  R1978     1.9750542640686035e+00
    phi[4,5]  R1979     4.0697780251502991e-01
    phi[4,5]  R1980     8.2608246803283691e-01
    phi[4,5]  R1981     4.4475749135017395e-01
    phi[4,5]  R1982     -2.6602727174758911e-01
    phi[4,5]  R1983     -3.3808830380439758e-01
    phi[4,5]  R1984     2.1538259088993073e-01
    phi[4,5]  R1985     1.8396036326885223e-01
    phi[4,5]  R1986     -9.4072383642196655e-01
    phi[4,5]  R1987     -8.2318294048309326e-01
    phi[4,5]  R1988     -3.4311375021934509e-01
    phi[4,5]  R1989     -6.9433414936065674e-01
    phi[4,5]  R1990     -3.3631348609924316e+00
    phi[4,5]  R1991     -1.4225327968597412e+00
    phi[4,5]  R1992     -1.9978079795837402e+00
    phi[4,5]  R1993     -4.3621838092803955e-01
    phi[4,5]  R1994     -1.3292034864425659e+00
    phi[4,5]  R1995     -9.2464596033096313e-01
    phi[4,5]  R1996     1.1124892234802246e+00
    phi[4,5]  R1997     4.5599600672721863e-01
    phi[4,5]  R1998     -1.5285264253616333e+00
    phi[4,5]  R1999     -8.8444298505783081e-01
    phi[4,5]  R2000     -1.6458404064178467e-01
    phi[4,5]  R2001     8.7023848295211792e-01
    phi[4,5]  R2002     -1.1242572069168091e+00
    phi[4,5]  R2003     2.5161948204040527e+00
    phi[4,5]  R2004     1.8975294828414917e+00
    phi[4,5]  R2005     4.7932329773902893e-01
    phi[4,5]  R2006     1.7834924459457397e+00
    phi[4,5]  R2007     7.8865534067153931e-01
    phi[4,5]  R2008     -1.1206871271133423e+00
    phi[4,5]  R2009     8.9766716957092285e-01
    phi[4,5]  R2010     -6.6361618041992188e-01
    phi[4,5]  R2011     6.5362930297851562e-01
    phi[4,5]  R2012     -5.8108299970626831e-01
    phi[4,5]  R2013     4.9799549579620361e-01
    phi[4,5]  R2014     -2.9428920149803162e-01
    phi[4,5]  R2015     -1.8276251554489136e+00
    phi[4,5]  R2016     1.9948244094848633e+00
    phi[4,5]  R2017     -1.8287563323974609e+00
    phi[4,5]  R2018     -2.0374925136566162e+00
    phi[4,5]  R2019     -2.23367977142334
    phi[4,5]  R2020     -1.9197836518287659e-01
    phi[4,5]  R2021     -2.4094719886779785e+00
    phi[4,5]  R2022     -2.4291565418243408e+00
    phi[4,5]  R2023     -3.0121953487396240e+00
    phi[4,5]  R2024     -1.8537623882293701e+00
    phi[4,5]  R2025     -2.8621504306793213e+00
    phi[4,5]  R2026     -3.2000980377197266e+00
    phi[4,5]  R2027     -3.0970048904418945e+00
    phi[4,5]  R2028     -1.9138781726360321e-01
    phi[4,5]  R2029     -7.9638713598251343e-01
    phi[4,5]  R2030     -5.4591459035873413e-01
    phi[4,5]  R2031     7.5586569309234619e-01
    phi[4,5]  R2032     8.2031613588333130e-01
    phi[4,5]  R2033     9.4874536991119385e-01
    phi[4,5]  R2034     -5.1385945081710815e-01
    phi[4,5]  R2035     8.0125164985656738e-01
    phi[4,5]  R2036     -4.4690862298011780e-01
    phi[4,5]  R2037     5.4654628038406372e-01
    phi[4,5]  R2038     -1.1048456430435181e+00
    phi[4,5]  R2039     -1.4425760507583618e-01
    phi[4,5]  R2040     -5.8705908060073853e-01
    phi[4,5]  R2041     -4.6788024902343750e-01
    phi[4,5]  R2042     2.4008387327194214e-01
    phi[4,5]  R2043     3.7850901484489441e-02
    phi[4,5]  R2044     -9.5624184608459473e-01
    phi[4,5]  R2045     -2.1634133160114288e-01
    phi[4,5]  R2046     -9.8085802793502808e-01
    phi[4,5]  R2047     -6.4823722839355469e-01
    phi[4,5]  R2048     -1.4195142984390259e+00
    phi[4,5]  R2049     -9.0637809038162231e-01
    phi[4,5]  R2050     -2.4058527946472168e+00
    phi[4,5]  R2051     -8.9648592472076416e-01
    phi[4,5]  R2052     -2.7848532795906067e-01
    phi[4,5]  R2053     -1.1172256469726562e+00
    phi[4,5]  R2054     -1.9629719853401184e-01
    phi[4,5]  R2055     -1.8486450910568237e+00
    phi[4,5]  R2056     -1.9335641860961914e+00
    phi[4,5]  R2057     3.4986160695552826e-02
    phi[5,4]  R36       -1
    phi[5,4]  R45       1
    phi[5,4]  R46       1
    phi[5,4]  R2058     -3.0999999046325684e+00
    phi[5,4]  R2059     -3.0999999046325684e+00
    phi[5,4]  R2060     -2.2400000095367432e+00
    phi[5,4]  R2061     -2.2400000095367432e+00
    phi[5,4]  R2062     -3.0999999046325684e+00
    phi[5,4]  R2063     -3.0999999046325684e+00
    phi[5,4]  R2064     -2.5699999332427979e+00
    phi[5,4]  R2065     -2.5699999332427979e+00
    phi[5,4]  R2066     -3.0999999046325684e+00
    phi[5,4]  R2067     -3.0999999046325684e+00
    phi[5,4]  R2068     -2.0899999141693115e+00
    phi[5,4]  R2069     -2.0899999141693115e+00
    phi[5,4]  R2070     -3.0999999046325684e+00
    phi[5,4]  R2071     -3.0999999046325684e+00
    phi[5,4]  R2072     -1.9138781726360321e-01
    phi[5,4]  R2073     -7.9638713598251343e-01
    phi[5,4]  R2074     -5.4591459035873413e-01
    phi[5,4]  R2075     7.5586569309234619e-01
    phi[5,4]  R2076     8.2031613588333130e-01
    phi[5,4]  R2077     9.4874536991119385e-01
    phi[5,4]  R2078     -5.1385945081710815e-01
    phi[5,4]  R2079     8.0125164985656738e-01
    phi[5,4]  R2080     -4.4690862298011780e-01
    phi[5,4]  R2081     5.4654628038406372e-01
    phi[5,4]  R2082     -1.1048456430435181e+00
    phi[5,4]  R2083     -1.4425760507583618e-01
    phi[5,4]  R2084     -5.8705908060073853e-01
    phi[5,4]  R2085     -4.6788024902343750e-01
    phi[5,4]  R2086     2.4008387327194214e-01
    phi[5,4]  R2087     3.7850901484489441e-02
    phi[5,4]  R2088     -9.5624184608459473e-01
    phi[5,4]  R2089     -2.1634133160114288e-01
    phi[5,4]  R2090     -9.8085802793502808e-01
    phi[5,4]  R2091     -6.4823722839355469e-01
    phi[5,4]  R2092     -1.4195142984390259e+00
    phi[5,4]  R2093     -9.0637809038162231e-01
    phi[5,4]  R2094     -2.4058527946472168e+00
    phi[5,4]  R2095     -8.9648592472076416e-01
    phi[5,4]  R2096     -2.7848532795906067e-01
    phi[5,4]  R2097     -1.1172256469726562e+00
    phi[5,4]  R2098     -1.9629719853401184e-01
    phi[5,4]  R2099     -1.8486450910568237e+00
    phi[5,4]  R2100     -1.9335641860961914e+00
    phi[5,4]  R2101     3.4986160695552826e-02
    phi[5,4]  R2102     1.3247875869274139e-01
    phi[5,4]  R2103     1.8049118518829346e+00
    phi[5,4]  R2104     1.5372670888900757e+00
    phi[5,4]  R2105     2.00858473777771
    phi[5,4]  R2106     2.4449262619018555e+00
    phi[5,4]  R2107     2.1936743259429932e+00
    phi[5,4]  R2108     -1.7578488588333130e-01
    phi[5,4]  R2109     1.1151608228683472e+00
    phi[5,4]  R2110     1.8097747564315796e+00
    phi[5,4]  R2111     1.9750542640686035e+00
    phi[5,4]  R2112     4.0697780251502991e-01
    phi[5,4]  R2113     8.2608246803283691e-01
    phi[5,4]  R2114     4.4475749135017395e-01
    phi[5,4]  R2115     -2.6602727174758911e-01
    phi[5,4]  R2116     -3.3808830380439758e-01
    phi[5,4]  R2117     2.1538259088993073e-01
    phi[5,4]  R2118     1.8396036326885223e-01
    phi[5,4]  R2119     -9.4072383642196655e-01
    phi[5,4]  R2120     -8.2318294048309326e-01
    phi[5,4]  R2121     -3.4311375021934509e-01
    phi[5,4]  R2122     -6.9433414936065674e-01
    phi[5,4]  R2123     -3.3631348609924316e+00
    phi[5,4]  R2124     -1.4225327968597412e+00
    phi[5,4]  R2125     -1.9978079795837402e+00
    phi[5,4]  R2126     -4.3621838092803955e-01
    phi[5,4]  R2127     -1.3292034864425659e+00
    phi[5,4]  R2128     -9.2464596033096313e-01
    phi[5,4]  R2129     1.1124892234802246e+00
    phi[5,4]  R2130     4.5599600672721863e-01
    phi[5,4]  R2131     -1.5285264253616333e+00
    phi[5,4]  R2132     -8.8444298505783081e-01
    phi[5,4]  R2133     -1.6458404064178467e-01
    phi[5,4]  R2134     8.7023848295211792e-01
    phi[5,4]  R2135     -1.1242572069168091e+00
    phi[5,4]  R2136     2.5161948204040527e+00
    phi[5,4]  R2137     1.8975294828414917e+00
    phi[5,4]  R2138     4.7932329773902893e-01
    phi[5,4]  R2139     1.7834924459457397e+00
    phi[5,4]  R2140     7.8865534067153931e-01
    phi[5,4]  R2141     -1.1206871271133423e+00
    phi[5,4]  R2142     8.9766716957092285e-01
    phi[5,4]  R2143     -6.6361618041992188e-01
    phi[5,4]  R2144     6.5362930297851562e-01
    phi[5,4]  R2145     -5.8108299970626831e-01
    phi[5,4]  R2146     4.9799549579620361e-01
    phi[5,4]  R2147     -2.9428920149803162e-01
    phi[5,4]  R2148     -1.8276251554489136e+00
    phi[5,4]  R2149     1.9948244094848633e+00
    phi[5,4]  R2150     -1.8287563323974609e+00
    phi[5,4]  R2151     -2.0374925136566162e+00
    phi[5,4]  R2152     -2.23367977142334
    phi[5,4]  R2153     -1.9197836518287659e-01
    phi[5,4]  R2154     -2.4094719886779785e+00
    phi[5,4]  R2155     -2.4291565418243408e+00
    phi[5,4]  R2156     -3.0121953487396240e+00
    phi[5,4]  R2157     -1.8537623882293701e+00
    phi[5,4]  R2158     -2.8621504306793213e+00
    phi[5,4]  R2159     -3.2000980377197266e+00
    phi[5,4]  R2160     -3.0970048904418945e+00
    phi[7,4]  R36       -1
    phi[7,4]  R38       -2.1426087385655919e+00
    phi[7,4]  R39       -1.7648205800455892e+00
    phi[7,4]  R40       1.6024263208598826e+00
    phi[7,4]  R41       -1.26361326873888
    phi[7,4]  R42       -3.4281727686026064e-01
    phi[7,4]  R43       -1.9477922353880093e+00
    phi[7,4]  R44       -2.3579728613288484e+00
    phi[7,4]  R63       1
    phi[7,4]  R2161     -9.5739116606697650e-01
    phi[7,4]  R2162     -5.24260864319816
    phi[7,4]  R2163     -0.475179429491154
    phi[7,4]  R2164     -4.0048205895823319e+00
    phi[7,4]  R2165     -4.7024262254924505e+00
    phi[7,4]  R2166     -1.4975735837726858e+00
    phi[7,4]  R2167     -1.3063866645039179e+00
    phi[7,4]  R2168     -3.8336132019816778e+00
    phi[7,4]  R2169     -2.7571826277723077e+00
    phi[7,4]  R2170     -3.4428171814928290e+00
    phi[7,4]  R2171     -1.4220767878130225e-01
    phi[7,4]  R2172     -4.0377921495573208e+00
    phi[7,4]  R2173     -7.4202704330371994e-01
    phi[7,4]  R2174     -5.4579727659614168e+00
    phi[7,4]  R2175     -1.6342414422753915e-01
    phi[7,4]  R2176     -1.7119101106842294e-01
    phi[7,4]  R2177     -1.7769237842099006e-01
    phi[7,4]  R2178     -1.8173088282268646e-01
    phi[7,4]  R2179     -1.8398401992388669e-01
    phi[7,4]  R2180     -1.8625714017234207e-01
    phi[7,4]  R2181     -1.9256895043869277e-01
    phi[7,4]  R2182     -1.9574810730651349e-01
    phi[7,4]  R2183     -2.1902593718271124e-01
    phi[7,4]  R2184     -2.2128417220989016e-01
    phi[7,4]  R2185     -5.1470189089716190e-01
    phi[7,4]  R2186     -2.5839670528402836e-01
    phi[7,4]  R2187     -1.0466133332194179e+00
    phi[7,4]  R2188     -3.5937358169984979e-01
    phi[7,4]  R2189     -0.468893122570611
    phi[7,4]  R2190     -5.3011552009559271e-01
    phi[7,4]  R2191     -5.3202959102907077e-01
    phi[7,4]  R2192     -5.4438257661307210e-01
    phi[7,4]  R2193     -5.4866794670300190e-01
    phi[7,4]  R2194     -5.6018375217260785e-01
    phi[7,4]  R2195     -2.4174634306683462e-01
    phi[7,4]  R2196     -2.4803110231525327e-01
    phi[7,4]  R2197     -2.6776924205751618e-01
    phi[7,4]  R2198     -2.7922837524063349e-01
    phi[7,4]  R2199     -2.7964393728479270e-01
    phi[7,4]  R2200     -3.0525481653042541e-01
    phi[7,4]  R2201     -3.0681910870891160e-01
    phi[7,4]  R2202     -3.4061147292930172e-01
    phi[7,4]  R2203     -3.5151799842700404e-01
    phi[7,4]  R2204     -3.5693355591265563e-01
    phi[7,4]  R2205     -2.5110618162268861e-01
    phi[7,4]  R2206     -2.7993730617001156e-01
    phi[7,4]  R2207     -2.8956072009052369e-01
    phi[7,4]  R2208     -3.2434971419778158e-01
    phi[7,4]  R2209     -3.2638835296895330e-01
    phi[7,4]  R2210     -3.2790783476736873e-01
    phi[7,4]  R2211     -3.3601542720074262e-01
    phi[7,4]  R2212     -3.5301901584379669e-01
    phi[7,4]  R2213     -3.5551974899678251e-01
    phi[7,4]  R2214     -3.5590450812357843e-01
    phi[7,4]  R2215     -2.0613674797115422e-01
    phi[7,4]  R2216     -2.3918107080625356e-01
    phi[7,4]  R2217     -2.5414642724758862e-01
    phi[7,4]  R2218     -2.5750706113149591e-01
    phi[7,4]  R2219     -2.7895079687094904e-01
    phi[7,4]  R2220     -2.9171255323933543e-01
    phi[7,4]  R2221     -3.2249250064070778e-01
    phi[7,4]  R2222     -3.9831080351145864e-01
    phi[7,4]  R2223     -5.5421477662691943e-01
    phi[7,4]  R2224     -5.5769321173277819e-01
    phi[7,4]  R2225     -2.5313622494475618e-01
    phi[7,4]  R2226     -2.5425989458222031e-01
    phi[7,4]  R2227     -2.6392858570283062e-01
    phi[7,4]  R2228     -2.9361852292597090e-01
    phi[7,4]  R2229     -3.0663424830407182e-01
    phi[7,4]  R2230     -3.2187420813487466e-01
    phi[7,4]  R2231     -5.9635926645571713e-01
    phi[7,4]  R2232     -6.0265429046033292e-01
    phi[7,4]  R2233     -6.8533587088018111e-01
    phi[5,6]  R45       1
    phi[5,6]  R46       1
    phi[5,6]  R54       -1
    phi[5,6]  R2234     -3.0999999046325684e+00
    phi[5,6]  R2235     -3.0999999046325684e+00
    phi[5,6]  R2236     -2.2400000095367432e+00
    phi[5,6]  R2237     -2.2400000095367432e+00
    phi[5,6]  R2238     -3.0999999046325684e+00
    phi[5,6]  R2239     -3.0999999046325684e+00
    phi[5,6]  R2240     -2.5699999332427979e+00
    phi[5,6]  R2241     -2.5699999332427979e+00
    phi[5,6]  R2242     -3.0999999046325684e+00
    phi[5,6]  R2243     -3.0999999046325684e+00
    phi[5,6]  R2244     -2.0899999141693115e+00
    phi[5,6]  R2245     -2.0899999141693115e+00
    phi[5,6]  R2246     -3.0999999046325684e+00
    phi[5,6]  R2247     -3.0999999046325684e+00
    phi[5,6]  R2248     -1.9138781726360321e-01
    phi[5,6]  R2249     -7.9638713598251343e-01
    phi[5,6]  R2250     -5.4591459035873413e-01
    phi[5,6]  R2251     7.5586569309234619e-01
    phi[5,6]  R2252     8.2031613588333130e-01
    phi[5,6]  R2253     9.4874536991119385e-01
    phi[5,6]  R2254     -5.1385945081710815e-01
    phi[5,6]  R2255     8.0125164985656738e-01
    phi[5,6]  R2256     -4.4690862298011780e-01
    phi[5,6]  R2257     5.4654628038406372e-01
    phi[5,6]  R2258     -1.1048456430435181e+00
    phi[5,6]  R2259     -1.4425760507583618e-01
    phi[5,6]  R2260     -5.8705908060073853e-01
    phi[5,6]  R2261     -4.6788024902343750e-01
    phi[5,6]  R2262     2.4008387327194214e-01
    phi[5,6]  R2263     3.7850901484489441e-02
    phi[5,6]  R2264     -9.5624184608459473e-01
    phi[5,6]  R2265     -2.1634133160114288e-01
    phi[5,6]  R2266     -9.8085802793502808e-01
    phi[5,6]  R2267     -6.4823722839355469e-01
    phi[5,6]  R2268     -1.4195142984390259e+00
    phi[5,6]  R2269     -9.0637809038162231e-01
    phi[5,6]  R2270     -2.4058527946472168e+00
    phi[5,6]  R2271     -8.9648592472076416e-01
    phi[5,6]  R2272     -2.7848532795906067e-01
    phi[5,6]  R2273     -1.1172256469726562e+00
    phi[5,6]  R2274     -1.9629719853401184e-01
    phi[5,6]  R2275     -1.8486450910568237e+00
    phi[5,6]  R2276     -1.9335641860961914e+00
    phi[5,6]  R2277     3.4986160695552826e-02
    phi[5,6]  R2278     -1.2849243879318237e+00
    phi[5,6]  R2279     3.5921385884284973e-01
    phi[5,6]  R2280     1.8061410188674927e+00
    phi[5,6]  R2281     5.8068895339965820e-01
    phi[5,6]  R2282     -1.1297363042831421e+00
    phi[5,6]  R2283     1.3971229791641235e+00
    phi[5,6]  R2284     3.5957634449005127e-01
    phi[5,6]  R2285     -6.3627600669860840e-01
    phi[5,6]  R2286     6.4671212434768677e-01
    phi[5,6]  R2287     5.4972630739212036e-01
    phi[5,6]  R2288     -2.6063793897628784e-01
    phi[5,6]  R2289     -1.5084406137466431e+00
    phi[5,6]  R2290     -1.3934473991394043e+00
    phi[5,6]  R2291     -2.1964488029479980e+00
    phi[5,6]  R2292     -2.0258760452270508e+00
    phi[5,6]  R2293     -1.9127044677734375e+00
    phi[5,6]  R2294     -1.8453401327133179e+00
    phi[5,6]  R2295     -1.6860210895538330e+00
    phi[5,6]  R2296     -8.0275887250900269e-01
    phi[5,6]  R2297     -1.8084867000579834e+00
    phi[5,6]  R2298     -1.4000201225280762e+00
    phi[5,6]  R2299     -2.2909200191497803e+00
    phi[5,6]  R2300     -4.9704611301422119e-01
    phi[5,6]  R2301     -1.8717468976974487e+00
    phi[5,6]  R2302     -1.29019296169281
    phi[5,6]  R2303     -1.2674748897552490e+00
    phi[5,6]  R2304     -1.1447055339813232e+00
    phi[5,6]  R2305     4.5786866545677185e-01
    phi[5,6]  R2306     -3.9652937650680542e-01
    phi[5,6]  R2307     -3.9489609003067017e-01
    phi[5,6]  R2308     -2.1667262911796570e-01
    phi[5,6]  R2309     -1.5726330280303955e+00
    phi[5,6]  R2310     -2.3770773410797119e+00
    phi[5,6]  R2311     -1.8198574781417847e+00
    phi[5,6]  R2312     -1.2846367359161377e+00
    phi[5,6]  R2313     -1.5082405805587769e+00
    phi[5,6]  R2314     -2.7366977930068970e-01
    phi[5,6]  R2315     -6.8498212099075317e-01
    phi[5,6]  R2316     -1.0353078842163086e+00
    phi[5,6]  R2317     2.2949266433715820e-01
    phi[5,6]  R2318     -1.3331376314163208e+00
    phi[5,6]  R2319     -1.5641378164291382e+00
    phi[5,6]  R2320     -1.4404129981994629e+00
    phi[5,6]  R2321     -8.9668321609497070e-01
    phi[5,6]  R2322     -2.0621938705444336e+00
    phi[5,6]  R2323     -9.1890376806259155e-01
    phi[5,6]  R2324     -1.9950447976589203e-01
    phi[5,6]  R2325     1.8967778980731964e-01
    phi[5,6]  R2326     -9.0693074464797974e-01
    phi[5,6]  R2327     -0.672366201877594
    phi[5,6]  R2328     -1.3862019777297974e+00
    phi[5,6]  R2329     -1.4382216334342957e-01
    phi[5,6]  R2330     -1.5012931823730469e+00
    phi[5,6]  R2331     -2.2174069881439209e+00
    phi[5,6]  R2332     3.2886466383934021e-01
    phi[5,6]  R2333     -2.2201623916625977e+00
    phi[5,6]  R2334     -1.2742729187011719e+00
    phi[5,6]  R2335     -2.9954853057861328e+00
    phi[5,6]  R2336     -2.8784589767456055e+00
    phi[6,5]  R45       -1
    phi[6,5]  R54       1
    phi[6,5]  R55       1
    phi[6,5]  R2337     -3.0999999046325684e+00
    phi[6,5]  R2338     -3.0999999046325684e+00
    phi[6,5]  R2339     -2.2400000095367432e+00
    phi[6,5]  R2340     -2.2400000095367432e+00
    phi[6,5]  R2341     -3.0999999046325684e+00
    phi[6,5]  R2342     -3.0999999046325684e+00
    phi[6,5]  R2343     -2.5699999332427979e+00
    phi[6,5]  R2344     -2.5699999332427979e+00
    phi[6,5]  R2345     -3.0999999046325684e+00
    phi[6,5]  R2346     -3.0999999046325684e+00
    phi[6,5]  R2347     -2.0899999141693115e+00
    phi[6,5]  R2348     -2.0899999141693115e+00
    phi[6,5]  R2349     -3.0999999046325684e+00
    phi[6,5]  R2350     -3.0999999046325684e+00
    phi[6,5]  R2351     -1.2849243879318237e+00
    phi[6,5]  R2352     3.5921385884284973e-01
    phi[6,5]  R2353     1.8061410188674927e+00
    phi[6,5]  R2354     5.8068895339965820e-01
    phi[6,5]  R2355     -1.1297363042831421e+00
    phi[6,5]  R2356     1.3971229791641235e+00
    phi[6,5]  R2357     3.5957634449005127e-01
    phi[6,5]  R2358     -6.3627600669860840e-01
    phi[6,5]  R2359     6.4671212434768677e-01
    phi[6,5]  R2360     5.4972630739212036e-01
    phi[6,5]  R2361     -2.6063793897628784e-01
    phi[6,5]  R2362     -1.5084406137466431e+00
    phi[6,5]  R2363     -1.3934473991394043e+00
    phi[6,5]  R2364     -2.1964488029479980e+00
    phi[6,5]  R2365     -2.0258760452270508e+00
    phi[6,5]  R2366     -1.9127044677734375e+00
    phi[6,5]  R2367     -1.8453401327133179e+00
    phi[6,5]  R2368     -1.6860210895538330e+00
    phi[6,5]  R2369     -8.0275887250900269e-01
    phi[6,5]  R2370     -1.8084867000579834e+00
    phi[6,5]  R2371     -1.4000201225280762e+00
    phi[6,5]  R2372     -2.2909200191497803e+00
    phi[6,5]  R2373     -4.9704611301422119e-01
    phi[6,5]  R2374     -1.8717468976974487e+00
    phi[6,5]  R2375     -1.29019296169281
    phi[6,5]  R2376     -1.2674748897552490e+00
    phi[6,5]  R2377     -1.1447055339813232e+00
    phi[6,5]  R2378     4.5786866545677185e-01
    phi[6,5]  R2379     -3.9652937650680542e-01
    phi[6,5]  R2380     -3.9489609003067017e-01
    phi[6,5]  R2381     -2.1667262911796570e-01
    phi[6,5]  R2382     -1.5726330280303955e+00
    phi[6,5]  R2383     -2.3770773410797119e+00
    phi[6,5]  R2384     -1.8198574781417847e+00
    phi[6,5]  R2385     -1.2846367359161377e+00
    phi[6,5]  R2386     -1.5082405805587769e+00
    phi[6,5]  R2387     -2.7366977930068970e-01
    phi[6,5]  R2388     -6.8498212099075317e-01
    phi[6,5]  R2389     -1.0353078842163086e+00
    phi[6,5]  R2390     2.2949266433715820e-01
    phi[6,5]  R2391     -1.3331376314163208e+00
    phi[6,5]  R2392     -1.5641378164291382e+00
    phi[6,5]  R2393     -1.4404129981994629e+00
    phi[6,5]  R2394     -8.9668321609497070e-01
    phi[6,5]  R2395     -2.0621938705444336e+00
    phi[6,5]  R2396     -9.1890376806259155e-01
    phi[6,5]  R2397     -1.9950447976589203e-01
    phi[6,5]  R2398     1.8967778980731964e-01
    phi[6,5]  R2399     -9.0693074464797974e-01
    phi[6,5]  R2400     -0.672366201877594
    phi[6,5]  R2401     -1.3862019777297974e+00
    phi[6,5]  R2402     -1.4382216334342957e-01
    phi[6,5]  R2403     -1.5012931823730469e+00
    phi[6,5]  R2404     -2.2174069881439209e+00
    phi[6,5]  R2405     3.2886466383934021e-01
    phi[6,5]  R2406     -2.2201623916625977e+00
    phi[6,5]  R2407     -1.2742729187011719e+00
    phi[6,5]  R2408     -2.9954853057861328e+00
    phi[6,5]  R2409     -2.8784589767456055e+00
    phi[6,5]  R2410     -1.9138781726360321e-01
    phi[6,5]  R2411     -7.9638713598251343e-01
    phi[6,5]  R2412     -5.4591459035873413e-01
    phi[6,5]  R2413     7.5586569309234619e-01
    phi[6,5]  R2414     8.2031613588333130e-01
    phi[6,5]  R2415     9.4874536991119385e-01
    phi[6,5]  R2416     -5.1385945081710815e-01
    phi[6,5]  R2417     8.0125164985656738e-01
    phi[6,5]  R2418     -4.4690862298011780e-01
    phi[6,5]  R2419     5.4654628038406372e-01
    phi[6,5]  R2420     -1.1048456430435181e+00
    phi[6,5]  R2421     -1.4425760507583618e-01
    phi[6,5]  R2422     -5.8705908060073853e-01
    phi[6,5]  R2423     -4.6788024902343750e-01
    phi[6,5]  R2424     2.4008387327194214e-01
    phi[6,5]  R2425     3.7850901484489441e-02
    phi[6,5]  R2426     -9.5624184608459473e-01
    phi[6,5]  R2427     -2.1634133160114288e-01
    phi[6,5]  R2428     -9.8085802793502808e-01
    phi[6,5]  R2429     -6.4823722839355469e-01
    phi[6,5]  R2430     -1.4195142984390259e+00
    phi[6,5]  R2431     -9.0637809038162231e-01
    phi[6,5]  R2432     -2.4058527946472168e+00
    phi[6,5]  R2433     -8.9648592472076416e-01
    phi[6,5]  R2434     -2.7848532795906067e-01
    phi[6,5]  R2435     -1.1172256469726562e+00
    phi[6,5]  R2436     -1.9629719853401184e-01
    phi[6,5]  R2437     -1.8486450910568237e+00
    phi[6,5]  R2438     -1.9335641860961914e+00
    phi[6,5]  R2439     3.4986160695552826e-02
    phi[6,8]  R54       1
    phi[6,8]  R55       1
    phi[6,8]  R56       -2.2211699524742232e+00
    phi[6,8]  R57       -3.5163990986908766e-01
    phi[6,8]  R58       5.3930914446124412e-01
    phi[6,8]  R59       1.9497162511291610e+00
    phi[6,8]  R60       2.5253948896895722e+00
    phi[6,8]  R61       1.6398475061762448e+00
    phi[6,8]  R62       -2.3559881904214417e+00
    phi[6,8]  R64       -1
    phi[6,8]  R2440     -5.3211698571067920e+00
    phi[6,8]  R2441     -8.7882995215834514e-01
    phi[6,8]  R2442     -2.5916399194058308e+00
    phi[6,8]  R2443     -1.8883600996676555e+00
    phi[6,8]  R2444     -2.5606907601713242e+00
    phi[6,8]  R2445     -3.6393090490938125e+00
    phi[6,8]  R2446     -6.2028368211363683e-01
    phi[6,8]  R2447     -4.5197161843719584e+00
    phi[6,8]  R2448     -5.7460501494299621e-01
    phi[6,8]  R2449     -5.6253947943221405e+00
    phi[6,8]  R2450     -4.5015240799306677e-01
    phi[6,8]  R2451     -3.7298474203455561e+00
    phi[6,8]  R2452     -5.4559880950540105e+00
    phi[6,8]  R2453     -7.4401171421112666e-01
    phi[6,8]  R2454     -1.1462445264802001e-01
    phi[6,8]  R2455     -2.4115533264166178e-01
    phi[6,8]  R2456     -2.5334421258440631e-01
    phi[6,8]  R2457     -2.6343289182371521e-01
    phi[6,8]  R2458     -2.6600029954169524e-01
    phi[6,8]  R2459     -2.7407418872503175e-01
    phi[6,8]  R2460     -2.7648282947983793e-01
    phi[6,8]  R2461     -2.9137571652954652e-01
    phi[6,8]  R2462     -2.9565452625760646e-01
    phi[6,8]  R2463     -2.9782865540441772e-01
    phi[6,8]  R2464     -0.480891042981191
    phi[6,8]  R2465     -6.4985396487353508e-01
    phi[6,8]  R2466     -6.5783050553346878e-01
    phi[6,8]  R2467     -6.8697311061243926e-01
    phi[6,8]  R2468     -7.0042748913594144e-01
    phi[6,8]  R2469     -1.1869080796575149e+00
    phi[6,8]  R2470     -7.0360221372558618e-01
    phi[6,8]  R2471     -1.4707640886485125e+00
    phi[6,8]  R2472     -7.9987916780371893e-01
    phi[6,8]  R2473     -4.3024065320877893e+00
    phi[6,8]  R2474     -6.4579524534829524e-01
    phi[6,8]  R2475     -6.6775730602054328e-01
    phi[6,8]  R2476     -0.709872837063837
    phi[6,8]  R2477     -7.2275380836759506e-01
    phi[6,8]  R2478     -0.731146429003744
    phi[6,8]  R2479     -7.6561238810598753e-01
    phi[6,8]  R2480     -2.3043505185175324e+00
    phi[6,8]  R2481     -8.2496763869208878e-01
    phi[6,8]  R2482     -8.8366510269988086e-01
    phi[6,8]  R2483     -3.06060625686438
    phi[6,8]  R2484     -4.1368180084036971e-01
    phi[6,8]  R2485     -5.4929882085220338e-01
    phi[6,8]  R2486     -6.0641525876785063e-01
    phi[6,8]  R2487     -6.0831346013992738e-01
    phi[6,8]  R2488     -4.9273518611523075e+00
    phi[6,8]  R2489     -3.2367756049669976e+00
    phi[6,8]  R2490     -7.3859767842250612e-01
    phi[6,8]  R2491     -0.941264569587005
    phi[6,8]  R2492     -9.6404623186918548e-01
    phi[6,8]  R2493     -1.0104334787674969e+00
    phi[6,8]  R2494     -5.4548760139186236e-01
    phi[6,8]  R2495     -5.5279176310461819e-01
    phi[6,8]  R2496     -5.6288201250382819e-01
    phi[6,8]  R2497     -5.6733691356457672e-01
    phi[6,8]  R2498     -6.4392904181364607e-01
    phi[6,8]  R2499     -7.0270677585293817e-01
    phi[6,8]  R2500     -0.859266637442831
    phi[6,8]  R2501     -8.6579802646408610e-01
    phi[6,8]  R2502     -9.2152974900110129e-01
    phi[6,8]  R2503     -9.7655288444683919e-01
    phi[6,8]  R2504     -6.9274403927318851e-01
    phi[6,8]  R2505     -2.0418931954594370e+00
    phi[6,8]  R2506     -3.6795212676550570e+00
    phi[6,8]  R2507     -1.0767153477279707e+00
    phi[6,8]  R2508     -1.0919887833496331e+00
    phi[6,8]  R2509     -4.1090898095857007e+00
    phi[6,8]  R2510     -1.6109621865649313e+00
    phi[6,8]  R2511     -1.16975726018921
    phi[6,8]  R2512     -1.1765862273540424e+00
    MARKER    'MARKER'                 'INTEND'
    z[0,1,0]  R2        -1
    z[0,1,0]  R11       1
    z[0,1,0]  R65       -1
    z[0,1,0]  R66       1
    z[0,1,0]  R79       1.6584175825119019e-01
    z[0,1,0]  R80       -0.0663711279630661
    z[0,1,0]  R81       1.1949385702610016e-01
    z[0,1,0]  R82       1.9378165900707245e-01
    z[0,1,0]  R83       4.3577592819929123e-02
    z[0,1,0]  R84       9.0140420198440552e-01
    z[0,1,0]  R85       8.1452596187591553e-01
    z[0,1,0]  R86       8.2104223966598511e-01
    z[0,1,0]  R87       9.7160762548446655e-01
    z[0,1,0]  R88       8.1599676609039307e-01
    z[0,1,0]  R89       1.9828332960605621e-01
    z[0,1,0]  R90       -4.4695755839347839e-01
    z[0,1,0]  R91       1.6230948269367218e-01
    z[0,1,0]  R92       -3.4789907932281494e-01
    z[0,1,0]  R93       -4.4342020153999329e-01
    z[0,1,0]  R94       -8.9742016792297363e-01
    z[0,1,0]  R95       -8.4654372930526733e-01
    z[0,1,0]  R96       -8.3944803476333618e-01
    z[0,1,0]  R97       -7.8399944305419922e-01
    z[0,1,0]  R98       -3.5530397295951843e-01
    z[0,1,0]  R99       -5.4938018321990967e-01
    z[0,1,0]  R100      4.9426622688770294e-02
    z[0,1,0]  R101      -6.1445814371109009e-01
    z[0,1,0]  R102      -4.0386113524436951e-01
    z[0,1,0]  R103      -4.9271425604820251e-01
    z[0,1,0]  R104      1.2376247346401215e-01
    z[0,1,0]  R105      -1.5954676270484924e-01
    z[0,1,0]  R106      4.6899044513702393e-01
    z[0,1,0]  R107      -5.2462047338485718e-01
    z[0,1,0]  R108      -6.4716976881027222e-01
    z[0,1,0]  R109      -2.0606555044651031e-01
    z[0,1,0]  R110      -1.5359888970851898e-01
    z[0,1,0]  R111      4.3930616974830627e-01
    z[0,1,0]  R112      -5.3720917552709579e-02
    z[0,1,0]  R113      -2.1099595725536346e-01
    z[0,1,0]  R114      -3.9522945880889893e-01
    z[0,1,0]  R115      -1.4909274876117706e-01
    z[0,1,0]  R116      -0.791441798210144
    z[0,1,0]  R117      -7.3082339763641357e-01
    z[0,1,0]  R118      -4.1452351212501526e-01
    z[0,1,0]  R119      -2.9931643605232239e-01
    z[0,1,0]  R120      -7.7392721176147461e-01
    z[0,1,0]  R121      -0.832425057888031
    z[0,1,0]  R122      -4.8705756664276123e-01
    z[0,1,0]  R123      -5.5040019750595093e-01
    z[0,1,0]  R124      -4.6058323979377747e-01
    z[0,1,0]  R125      -4.6979156136512756e-01
    z[0,1,0]  R126      -7.4821233749389648e-01
    z[0,1,0]  R127      -0.479658305644989
    z[0,1,0]  R128      -4.6973422169685364e-01
    z[0,1,0]  R129      0.723736584186554
    z[0,1,0]  R130      8.0472415685653687e-01
    z[0,1,0]  R131      6.1697083711624146e-01
    z[0,1,0]  R132      6.5605306625366211e-01
    z[0,1,0]  R133      8.8712280988693237e-01
    z[0,1,0]  R134      8.8229048252105713e-01
    z[0,1,0]  R135      8.9311712980270386e-01
    z[0,1,0]  R136      9.1823190450668335e-01
    z[0,1,0]  R137      8.4810262918472290e-01
    z[0,1,0]  R138      8.6877566576004028e-01
    z[0,1,0]  R139      -2.4355600774288177e-01
    z[0,1,0]  R140      -8.6646175384521484e-01
    z[0,1,0]  R141      -1.7858077585697174e-01
    z[0,1,0]  R142      -3.5714778304100037e-01
    z[0,1,0]  R143      -7.5557577610015869e-01
    z[0,1,0]  R144      -7.6985865831375122e-01
    z[0,1,0]  R145      -7.5257080793380737e-01
    z[0,1,0]  R146      -1.5396592207252979e-02
    z[0,1,0]  R147      -1.4446650445461273e-01
    z[0,1,0]  R148      8.9831940829753876e-02
    z[0,1,0]  R149      -4.6918381005525589e-02
    z[0,1,0]  R150      1.3612688519060612e-02
    z[0,1,0]  R151      -7.2523248195648193e-01
    z[0,1,0]  R152      -2.0390337333083153e-02
    z[0,1,0]  R153      2.3649508133530617e-02
    z[0,1,0]  R154      -7.7637803554534912e-01
    z[0,1,0]  R155      -7.3027008771896362e-01
    z[0,1,0]  R156      -7.8857392072677612e-01
    z[0,1,0]  R157      0.0638904869556427
    z[0,1,0]  R158      -0.730022668838501
    z[0,1,0]  R159      3.2288023829460144e-01
    z[0,1,0]  R160      1.6156212985515594e-01
    z[0,1,0]  R161      2.2361817955970764e-01
    z[0,1,0]  R162      -7.8468585014343262e-01
    z[0,1,0]  R163      -7.9549568891525269e-01
    z[0,1,0]  R164      -8.5130012035369873e-01
    z[0,1,0]  R165      -0.858471155166626
    z[0,1,0]  R166      -8.3502292633056641e-01
    z[0,1,0]  R167      -8.7198764085769653e-01
    z[0,1,0]  R168      -7.3678523302078247e-01
    z[0,1,0]  R169      2.4792306125164032e-01
    z[0,1,0]  R170      3.6198583245277405e-01
    z[0,1,0]  R171      1.3135664165019989e-01
    z[0,1,0]  R172      -8.4073919057846069e-01
    z[0,1,0]  R173      -7.6478409767150879e-01
    z[0,1,0]  R174      -7.9939109086990356e-01
    z[0,1,0]  R175      -7.9929852485656738e-01
    z[0,1,0]  R176      -7.9075801372528076e-01
    z[0,1,0]  R177      -8.4291136264801025e-01
    z[0,1,0]  R178      -4.1825491189956665e-01
    z[0,1,0]  R179      1.5854188799858093e-01
    z[0,1,0]  R180      -9.3071717023849487e-01
    z[0,1,0]  R181      -4.7545678913593292e-02
    z[0,1,0]  R182      -0.812671959400177
    z[0,1,0]  R183      -7.1106845140457153e-01
    z[0,1,0]  R184      -6.4418500661849976e-01
    z[0,1,0]  R185      -8.2161104679107666e-01
    z[0,1,0]  R186      -3.3492672443389893e-01
    z[0,1,0]  R187      -7.1009427309036255e-01
    z[0,1,0]  R188      -8.5085999965667725e-01
    z[0,1,0]  R189      -8.4011381864547729e-01
    z[0,1,0]  R190      -8.2892262935638428e-01
    z[0,1,0]  R191      -6.6660982370376587e-01
    z[0,1,0]  R192      -8.4759056568145752e-01
    z[0,1,0]  R193      -7.2158157825469971e-01
    z[0,1,0]  R194      -8.4859234094619751e-01
    z[0,1,0]  R195      -3.8933184742927551e-01
    z[0,1,0]  R196      -6.2131547927856445e-01
    z[0,1,0]  R197      2.4689945578575134e-01
    z[0,1,0]  R198      1.7999957501888275e-01
    z[0,1,0]  R199      -8.6880499124526978e-01
    z[0,1,0]  R200      -3.5068488121032715e-01
    z[0,1,0]  R201      -7.1212485432624817e-02
    z[0,1,0]  R202      -0.813671350479126
    z[0,1,0]  R203      -8.9947231113910675e-02
    z[0,1,0]  R204      2.4146883189678192e-01
    z[0,1,0]  R205      -6.0453188419342041e-01
    z[0,1,0]  R206      -1.4398542046546936e-01
    z[0,1,0]  R207      -4.0792167186737061e-01
    z[0,1,0]  R208      -2.6940107345581055e-01
    z[0,1,0]  R209      -0.852932870388031
    z[0,1,0]  R210      -3.3950966596603394e-01
    z[0,1,0]  R211      -1.7837733030319214e-01
    z[0,1,0]  R212      -1.7302061617374420e-01
    z[0,1,0]  R213      -5.4825592041015625e-01
    z[0,1,0]  R214      -1.2178809195756912e-01
    z[0,1,0]  R215      2.0942500233650208e-01
    z[0,1,0]  R216      -0.0467689111828804
    z[0,1,0]  R217      2.5784561038017273e-01
    z[0,1,0]  R218      1.8484315276145935e-01
    z[0,1,0]  R219      -2.8594323992729187e-01
    z[0,1,0]  R220      -7.4660068750381470e-01
    z[0,1,0]  R221      -7.9481208324432373e-01
    z[0,1,0]  R222      -1.2942856550216675e-01
    z[0,1,0]  R223      -4.0330997109413147e-01
    z[0,1,0]  R224      1.4957337081432343e-01
    z[0,1,0]  R225      3.4764219075441360e-02
    z[0,1,0]  R226      3.4324326552450657e-03
    z[0,1,0]  R227      1.9561995286494493e-03
    z[0,1,0]  R228      0.251740038394928
    z[0,1,1]  R3        -1
    z[0,1,1]  R12       1
    z[0,1,1]  R67       -1
    z[0,1,1]  R68       1
    z[0,1,1]  R79       -8.0154515802860260e-02
    z[0,1,1]  R80       -1.8110516667366028e-01
    z[0,1,1]  R81       1.2446816544979811e-03
    z[0,1,1]  R82       -2.5708785653114319e-01
    z[0,1,1]  R83       -2.1594421565532684e-01
    z[0,1,1]  R84       -1.6137482225894928e-01
    z[0,1,1]  R85       0.0124838100746274
    z[0,1,1]  R86       -2.2792570292949677e-01
    z[0,1,1]  R87       5.5811285972595215e-02
    z[0,1,1]  R88       -1.4057861268520355e-01
    z[0,1,1]  R89       -5.1473462581634521e-01
    z[0,1,1]  R90       -4.1156825423240662e-01
    z[0,1,1]  R91       -7.2181558609008789e-01
    z[0,1,1]  R92       -5.0044882297515869e-01
    z[0,1,1]  R93       -4.8834976553916931e-01
    z[0,1,1]  R94       3.0170795321464539e-01
    z[0,1,1]  R95       -2.7758213877677917e-01
    z[0,1,1]  R96       8.4900282323360443e-02
    z[0,1,1]  R97       1.8939383327960968e-01
    z[0,1,1]  R98       -4.7070616483688354e-01
    z[0,1,1]  R99       -4.6050909161567688e-01
    z[0,1,1]  R100      -8.8417333364486694e-01
    z[0,1,1]  R101      -2.8729760646820068e-01
    z[0,1,1]  R102      -6.2607473134994507e-01
    z[0,1,1]  R103      -7.9398363828659058e-01
    z[0,1,1]  R104      -9.0427374839782715e-01
    z[0,1,1]  R105      -6.6911959648132324e-01
    z[0,1,1]  R106      -3.4406265616416931e-01
    z[0,1,1]  R107      -5.9844875335693359e-01
    z[0,1,1]  R108      -5.7142537832260132e-01
    z[0,1,1]  R109      -6.6057282686233521e-01
    z[0,1,1]  R110      -1.2760999798774719e-01
    z[0,1,1]  R111      -5.6027692556381226e-01
    z[0,1,1]  R112      -5.0797986984252930e-01
    z[0,1,1]  R113      3.2867971062660217e-01
    z[0,1,1]  R114      8.6333960294723511e-02
    z[0,1,1]  R115      -4.6954333782196045e-01
    z[0,1,1]  R116      2.3565386235713959e-01
    z[0,1,1]  R117      4.2102980613708496e-01
    z[0,1,1]  R118      -1.0445768386125565e-01
    z[0,1,1]  R119      -1.2167669832706451e-01
    z[0,1,1]  R120      2.9350259900093079e-01
    z[0,1,1]  R121      3.5589879751205444e-01
    z[0,1,1]  R122      8.3448427915573120e-01
    z[0,1,1]  R123      7.3100918531417847e-01
    z[0,1,1]  R124      8.1843090057373047e-01
    z[0,1,1]  R125      7.9347169399261475e-01
    z[0,1,1]  R126      1.4243361353874207e-01
    z[0,1,1]  R127      7.6907247304916382e-01
    z[0,1,1]  R128      7.3240584135055542e-01
    z[0,1,1]  R129      -3.3563992381095886e-01
    z[0,1,1]  R130      -2.8114026784896851e-01
    z[0,1,1]  R131      -2.0235392451286316e-01
    z[0,1,1]  R132      -3.9763000607490540e-01
    z[0,1,1]  R133      -1.9126047194004059e-01
    z[0,1,1]  R134      -3.2268315553665161e-01
    z[0,1,1]  R135      -1.1038208752870560e-01
    z[0,1,1]  R136      -1.0242065042257309e-01
    z[0,1,1]  R137      -3.7171953916549683e-01
    z[0,1,1]  R138      -2.7798095345497131e-01
    z[0,1,1]  R139      -7.3880583047866821e-01
    z[0,1,1]  R140      2.8852856159210205e-01
    z[0,1,1]  R141      -6.9745475053787231e-01
    z[0,1,1]  R142      -6.7659026384353638e-01
    z[0,1,1]  R143      1.5621243417263031e-01
    z[0,1,1]  R144      1.3875234127044678e-01
    z[0,1,1]  R145      7.7380046248435974e-02
    z[0,1,1]  R146      -2.4864664673805237e-01
    z[0,1,1]  R147      -7.1995544433593750e-01
    z[0,1,1]  R148      4.3988442420959473e-01
    z[0,1,1]  R149      -8.7624388933181763e-01
    z[0,1,1]  R150      -2.5671776384115219e-02
    z[0,1,1]  R151      3.5382679104804993e-01
    z[0,1,1]  R152      -1.6947848722338676e-02
    z[0,1,1]  R153      -2.8374776244163513e-01
    z[0,1,1]  R154      2.6474717259407043e-01
    z[0,1,1]  R155      3.5049974918365479e-01
    z[0,1,1]  R156      8.2094341516494751e-02
    z[0,1,1]  R157      5.8240371942520142e-01
    z[0,1,1]  R158      2.2649440169334412e-01
    z[0,1,1]  R159      -1.4183451235294342e-01
    z[0,1,1]  R160      -1.4633235335350037e-01
    z[0,1,1]  R161      -2.8569728136062622e-01
    z[0,1,1]  R162      3.9122492074966431e-01
    z[0,1,1]  R163      4.2709720134735107e-01
    z[0,1,1]  R164      2.0969817042350769e-01
    z[0,1,1]  R165      1.8353113532066345e-01
    z[0,1,1]  R166      4.3121472001075745e-01
    z[0,1,1]  R167      4.7087732702493668e-02
    z[0,1,1]  R168      3.2928496599197388e-01
    z[0,1,1]  R169      -4.2966210842132568e-01
    z[0,1,1]  R170      1.4785882830619812e-01
    z[0,1,1]  R171      5.3121572732925415e-01
    z[0,1,1]  R172      3.4137284755706787e-01
    z[0,1,1]  R173      2.1490712463855743e-01
    z[0,1,1]  R174      1.4756475389003754e-01
    z[0,1,1]  R175      -4.8007094860076904e-01
    z[0,1,1]  R176      -4.7991201281547546e-01
    z[0,1,1]  R177      -3.9515095949172974e-01
    z[0,1,1]  R178      -6.2988650798797607e-01
    z[0,1,1]  R179      4.1771256923675537e-01
    z[0,1,1]  R180      1.5441577136516571e-01
    z[0,1,1]  R181      -3.9207491278648376e-01
    z[0,1,1]  R182      1.6048018634319305e-01
    z[0,1,1]  R183      3.0565094947814941e-01
    z[0,1,1]  R184      3.3529585599899292e-01
    z[0,1,1]  R185      -4.1966083645820618e-01
    z[0,1,1]  R186      -2.7800619602203369e-01
    z[0,1,1]  R187      6.7779272794723511e-02
    z[0,1,1]  R188      -3.1335547566413879e-01
    z[0,1,1]  R189      4.0297958254814148e-01
    z[0,1,1]  R190      1.9702941179275513e-01
    z[0,1,1]  R191      4.1896373033523560e-01
    z[0,1,1]  R192      -4.1293808817863464e-01
    z[0,1,1]  R193      -5.4255348443984985e-01
    z[0,1,1]  R194      -3.4744662046432495e-01
    z[0,1,1]  R195      1.5410919487476349e-01
    z[0,1,1]  R196      -5.8917975425720215e-01
    z[0,1,1]  R197      9.3907696008682251e-01
    z[0,1,1]  R198      9.6039682626724243e-01
    z[0,1,1]  R199      1.8808189034461975e-01
    z[0,1,1]  R200      -3.5703826695680618e-02
    z[0,1,1]  R201      -2.1576354280114174e-02
    z[0,1,1]  R202      5.2840482443571091e-02
    z[0,1,1]  R203      -0.669160008430481
    z[0,1,1]  R204      8.5001587867736816e-01
    z[0,1,1]  R205      -4.2836752533912659e-01
    z[0,1,1]  R206      5.4281461238861084e-01
    z[0,1,1]  R207      -4.0056610107421875e-01
    z[0,1,1]  R208      -5.1552116870880127e-01
    z[0,1,1]  R209      2.4238830804824829e-01
    z[0,1,1]  R210      -1.0183142125606537e-01
    z[0,1,1]  R211      -5.1572978496551514e-01
    z[0,1,1]  R212      -7.6958012580871582e-01
    z[0,1,1]  R213      -2.7142700552940369e-01
    z[0,1,1]  R214      8.2527321577072144e-01
    z[0,1,1]  R215      8.8517922163009644e-01
    z[0,1,1]  R216      7.2231113910675049e-01
    z[0,1,1]  R217      0.835231363773346
    z[0,1,1]  R218      8.3807313442230225e-01
    z[0,1,1]  R219      -5.3620919585227966e-02
    z[0,1,1]  R220      2.3409350216388702e-01
    z[0,1,1]  R221      3.8337996602058411e-01
    z[0,1,1]  R222      -8.3246874809265137e-01
    z[0,1,1]  R223      -3.3632597327232361e-01
    z[0,1,1]  R224      0.822594165802002
    z[0,1,1]  R225      7.3138356208801270e-01
    z[0,1,1]  R226      7.8624749183654785e-01
    z[0,1,1]  R227      7.7497494220733643e-01
    z[0,1,1]  R228      7.3773950338363647e-01
    z[0,1,2]  R4        -1
    z[0,1,2]  R13       1
    z[0,1,2]  R69       -1
    z[0,1,2]  R70       1
    z[0,1,2]  R79       -0.506878137588501
    z[0,1,2]  R80       -4.2139717936515808e-01
    z[0,1,2]  R81       -6.9209235906600952e-01
    z[0,1,2]  R82       -8.3501911163330078e-01
    z[0,1,2]  R83       -2.2046999633312225e-01
    z[0,1,2]  R84       -7.1110002696514130e-02
    z[0,1,2]  R85       3.5653421282768250e-01
    z[0,1,2]  R86       8.5008360445499420e-02
    z[0,1,2]  R87       -0.0941428393125534
    z[0,1,2]  R88       1.8917587399482727e-01
    z[0,1,2]  R89       2.1824875473976135e-01
    z[0,1,2]  R90       -2.8268773108720779e-02
    z[0,1,2]  R91       1.5187076292932034e-02
    z[0,1,2]  R92       8.6479753255844116e-02
    z[0,1,2]  R93       4.6523684263229370e-01
    z[0,1,2]  R94       -3.9636015892028809e-02
    z[0,1,2]  R95       -1.7314006388187408e-01
    z[0,1,2]  R96       1.1506627500057220e-01
    z[0,1,2]  R97       3.6588132381439209e-01
    z[0,1,2]  R98       4.2354875802993774e-01
    z[0,1,2]  R99       -0.427571177482605
    z[0,1,2]  R100      -2.0107574760913849e-01
    z[0,1,2]  R101      -3.7276017665863037e-01
    z[0,1,2]  R102      -3.8085898756980896e-01
    z[0,1,2]  R103      -1.2745060026645660e-01
    z[0,1,2]  R104      -4.2258203029632568e-02
    z[0,1,2]  R105      -8.9466765522956848e-02
    z[0,1,2]  R106      -1.2418854981660843e-01
    z[0,1,2]  R107      -4.1712176799774170e-01
    z[0,1,2]  R108      -3.6077263951301575e-01
    z[0,1,2]  R109      -5.7610249519348145e-01
    z[0,1,2]  R110      -5.0727421045303345e-01
    z[0,1,2]  R111      8.7560452520847321e-02
    z[0,1,2]  R112      6.7385137081146240e-01
    z[0,1,2]  R113      -0.0605199821293354
    z[0,1,2]  R114      7.0161208510398865e-02
    z[0,1,2]  R115      5.4754996299743652e-01
    z[0,1,2]  R116      4.1273349523544312e-01
    z[0,1,2]  R117      -4.3047182261943817e-02
    z[0,1,2]  R118      0.261992871761322
    z[0,1,2]  R119      1.4161027036607265e-02
    z[0,1,2]  R120      6.5739743411540985e-02
    z[0,1,2]  R121      4.7190878540277481e-02
    z[0,1,2]  R122      1.5756408870220184e-01
    z[0,1,2]  R123      0.00896039791405201
    z[0,1,2]  R124      2.2195219993591309e-01
    z[0,1,2]  R125      4.6186674386262894e-02
    z[0,1,2]  R126      0.515374481678009
    z[0,1,2]  R127      -5.8893103152513504e-02
    z[0,1,2]  R128      2.9958483576774597e-01
    z[0,1,2]  R129      -1.1853816360235214e-01
    z[0,1,2]  R130      -1.3509753160178661e-02
    z[0,1,2]  R131      -5.8933593332767487e-02
    z[0,1,2]  R132      -5.3258843719959259e-02
    z[0,1,2]  R133      7.5866342522203922e-03
    z[0,1,2]  R134      6.0134965926408768e-02
    z[0,1,2]  R135      2.9740616679191589e-01
    z[0,1,2]  R136      2.6105591654777527e-01
    z[0,1,2]  R137      -2.3807699978351593e-01
    z[0,1,2]  R138      2.2151088714599609e-01
    z[0,1,2]  R139      -1.4257369935512543e-01
    z[0,1,2]  R140      2.1280555427074432e-01
    z[0,1,2]  R141      -5.3871236741542816e-02
    z[0,1,2]  R142      -0.158564493060112
    z[0,1,2]  R143      -7.0406176149845123e-02
    z[0,1,2]  R144      -1.9678844138979912e-02
    z[0,1,2]  R145      -2.5658485293388367e-01
    z[0,1,2]  R146      -3.8320258259773254e-01
    z[0,1,2]  R147      1.7249508202075958e-01
    z[0,1,2]  R148      4.3248921632766724e-01
    z[0,1,2]  R149      -1.2811531126499176e-01
    z[0,1,2]  R150      1.4191722869873047e-01
    z[0,1,2]  R151      -1.0315258055925369e-01
    z[0,1,2]  R152      5.7939875125885010e-01
    z[0,1,2]  R153      4.5659548044204712e-01
    z[0,1,2]  R154      -2.1855439245700836e-01
    z[0,1,2]  R155      -2.0133875310420990e-01
    z[0,1,2]  R156      1.3484379276633263e-02
    z[0,1,2]  R157      2.1422983705997467e-01
    z[0,1,2]  R158      2.9233434796333313e-01
    z[0,1,2]  R159      3.5992351174354553e-01
    z[0,1,2]  R160      -0.679987370967865
    z[0,1,2]  R161      -2.2934034466743469e-01
    z[0,1,2]  R162      -0.0109430942684412
    z[0,1,2]  R163      -1.5799516439437866e-01
    z[0,1,2]  R164      1.1394404806196690e-02
    z[0,1,2]  R165      -2.3620298597961664e-03
    z[0,1,2]  R166      1.6179924830794334e-02
    z[0,1,2]  R167      -0.0656462013721466
    z[0,1,2]  R168      3.4418323636054993e-01
    z[0,1,2]  R169      3.0129194259643555e-01
    z[0,1,2]  R170      2.8884598612785339e-01
    z[0,1,2]  R171      1.9122385978698730e-01
    z[0,1,2]  R172      -2.9208555817604065e-01
    z[0,1,2]  R173      -2.2691851854324341e-01
    z[0,1,2]  R174      6.4044152386486530e-03
    z[0,1,2]  R175      2.0478211343288422e-01
    z[0,1,2]  R176      1.4265184104442596e-01
    z[0,1,2]  R177      2.4560482800006866e-01
    z[0,1,2]  R178      -2.2371813654899597e-01
    z[0,1,2]  R179      6.0382062196731567e-01
    z[0,1,2]  R180      0.0838552713394165
    z[0,1,2]  R181      -3.8139653205871582e-01
    z[0,1,2]  R182      3.2950885593891144e-02
    z[0,1,2]  R183      -7.8959226608276367e-02
    z[0,1,2]  R184      1.7590709030628204e-01
    z[0,1,2]  R185      -2.7172014117240906e-01
    z[0,1,2]  R186      -1.8509723246097565e-01
    z[0,1,2]  R187      3.8466113805770874e-01
    z[0,1,2]  R188      -1.3332429528236389e-01
    z[0,1,2]  R189      3.1154736876487732e-01
    z[0,1,2]  R190      1.9985429942607880e-02
    z[0,1,2]  R191      2.8842157125473022e-01
    z[0,1,2]  R192      -4.1602656245231628e-02
    z[0,1,2]  R193      -1.7169304192066193e-02
    z[0,1,2]  R194      -1.9052948057651520e-01
    z[0,1,2]  R195      -2.5256642699241638e-01
    z[0,1,2]  R196      7.0102256722748280e-03
    z[0,1,2]  R197      -1.6414555907249451e-01
    z[0,1,2]  R198      -3.6084707826375961e-02
    z[0,1,2]  R199      -5.1217749714851379e-02
    z[0,1,2]  R200      -5.1917475461959839e-01
    z[0,1,2]  R201      -5.8295524120330811e-01
    z[0,1,2]  R202      1.7868605256080627e-01
    z[0,1,2]  R203      3.4137687087059021e-01
    z[0,1,2]  R204      -3.3170655369758606e-01
    z[0,1,2]  R205      1.3348698616027832e-01
    z[0,1,2]  R206      -5.5416148900985718e-01
    z[0,1,2]  R207      3.6347416043281555e-01
    z[0,1,2]  R208      -4.5652204751968384e-01
    z[0,1,2]  R209      -7.0415951311588287e-02
    z[0,1,2]  R210      -4.7058498859405518e-01
    z[0,1,2]  R211      -3.4134802222251892e-01
    z[0,1,2]  R212      -1.0316787520423532e-03
    z[0,1,2]  R213      6.6267979145050049e-01
    z[0,1,2]  R214      -1.2245739996433258e-01
    z[0,1,2]  R215      3.1064450740814209e-03
    z[0,1,2]  R216      -1.9768038392066956e-01
    z[0,1,2]  R217      -2.6481890678405762e-01
    z[0,1,2]  R218      -1.8159645795822144e-01
    z[0,1,2]  R219      -4.6260491013526917e-01
    z[0,1,2]  R220      -1.7056234180927277e-01
    z[0,1,2]  R221      -2.9695001244544983e-01
    z[0,1,2]  R222      3.5705637186765671e-02
    z[0,1,2]  R223      5.0237149000167847e-01
    z[0,1,2]  R224      -6.4319007098674774e-02
    z[0,1,2]  R225      1.2722036242485046e-01
    z[0,1,2]  R226      -7.0435716770589352e-03
    z[0,1,2]  R227      -9.3880154192447662e-02
    z[0,1,2]  R228      1.7199160158634186e-01
    z[0,1,3]  R5        -1
    z[0,1,3]  R14       1
    z[0,1,3]  R71       -1
    z[0,1,3]  R72       1
    z[0,1,3]  R79       -1.4083890616893768e-01
    z[0,1,3]  R80       1.3286863267421722e-01
    z[0,1,3]  R81       -3.0317762494087219e-01
    z[0,1,3]  R82       -3.6674609780311584e-01
    z[0,1,3]  R83       -2.2699026390910149e-02
    z[0,1,3]  R84       -3.8814797997474670e-01
    z[0,1,3]  R85       -0.373947411775589
    z[0,1,3]  R86       -2.1999992430210114e-01
    z[0,1,3]  R87       -1.5195679850876331e-02
    z[0,1,3]  R88       -3.1144765019416809e-01
    z[0,1,3]  R89       7.1903622150421143e-01
    z[0,1,3]  R90       2.5185352563858032e-01
    z[0,1,3]  R91       5.0359004735946655e-01
    z[0,1,3]  R92       7.3543775081634521e-01
    z[0,1,3]  R93       4.9513211846351624e-01
    z[0,1,3]  R94       -0.0909363180398941
    z[0,1,3]  R95       1.9417591392993927e-01
    z[0,1,3]  R96       1.8482092022895813e-01
    z[0,1,3]  R97       4.2545256018638611e-01
    z[0,1,3]  R98       -5.0914859771728516e-01
    z[0,1,3]  R99       4.2381274700164795e-01
    z[0,1,3]  R100      3.7916150689125061e-01
    z[0,1,3]  R101      3.7722736597061157e-01
    z[0,1,3]  R102      4.4775003194808960e-01
    z[0,1,3]  R103      -1.9667898304760456e-03
    z[0,1,3]  R104      1.3694278895854950e-01
    z[0,1,3]  R105      6.7721712589263916e-01
    z[0,1,3]  R106      4.9713057279586792e-01
    z[0,1,3]  R107      -2.2889813408255577e-02
    z[0,1,3]  R108      3.0973119661211967e-02
    z[0,1,3]  R109      -8.1840313971042633e-02
    z[0,1,3]  R110      1.0280106961727142e-01
    z[0,1,3]  R111      4.7158437967300415e-01
    z[0,1,3]  R112      -1.5477801859378815e-01
    z[0,1,3]  R113      -8.3408242464065552e-01
    z[0,1,3]  R114      -8.8260644674301147e-01
    z[0,1,3]  R115      -4.9218437075614929e-01
    z[0,1,3]  R116      3.1000250577926636e-01
    z[0,1,3]  R117      2.8603506088256836e-01
    z[0,1,3]  R118      -7.5672513246536255e-01
    z[0,1,3]  R119      -9.1456425189971924e-01
    z[0,1,3]  R120      2.2730968892574310e-01
    z[0,1,3]  R121      2.5798153132200241e-02
    z[0,1,3]  R122      -5.1111515611410141e-02
    z[0,1,3]  R123      1.7404921352863312e-01
    z[0,1,3]  R124      -1.2447923421859741e-01
    z[0,1,3]  R125      -2.0280398428440094e-01
    z[0,1,3]  R126      -9.4996467232704163e-02
    z[0,1,3]  R127      -3.3122873306274414e-01
    z[0,1,3]  R128      -2.6657733321189880e-01
    z[0,1,3]  R129      3.7642562389373779e-01
    z[0,1,3]  R130      2.2613757848739624e-01
    z[0,1,3]  R131      2.8243386745452881e-01
    z[0,1,3]  R132      0.0550660714507103
    z[0,1,3]  R133      -3.1871774792671204e-01
    z[0,1,3]  R134      0.0724758729338646
    z[0,1,3]  R135      -0.0727483481168747
    z[0,1,3]  R136      -1.5462476760149002e-02
    z[0,1,3]  R137      -2.2073060274124146e-01
    z[0,1,3]  R138      6.2123283743858337e-02
    z[0,1,3]  R139      -0.424940824508667
    z[0,1,3]  R140      -1.5746068954467773e-01
    z[0,1,3]  R141      -4.0981835126876831e-01
    z[0,1,3]  R142      -4.5490843057632446e-01
    z[0,1,3]  R143      2.8890269994735718e-01
    z[0,1,3]  R144      -3.9071059226989746e-01
    z[0,1,3]  R145      -0.346769779920578
    z[0,1,3]  R146      3.4356537461280823e-01
    z[0,1,3]  R147      2.8785686939954758e-02
    z[0,1,3]  R148      -4.6313452720642090e-01
    z[0,1,3]  R149      -3.9203029870986938e-01
    z[0,1,3]  R150      -6.5651428699493408e-01
    z[0,1,3]  R151      -2.4493958055973053e-01
    z[0,1,3]  R152      -5.6359034776687622e-01
    z[0,1,3]  R153      -4.9433851242065430e-01
    z[0,1,3]  R154      2.3379026353359222e-01
    z[0,1,3]  R155      3.6727815866470337e-01
    z[0,1,3]  R156      3.2355868816375732e-01
    z[0,1,3]  R157      -5.8226162195205688e-01
    z[0,1,3]  R158      -4.4555738568305969e-01
    z[0,1,3]  R159      -0.281028687953949
    z[0,1,3]  R160      1.4870950579643250e-01
    z[0,1,3]  R161      -0.0558922179043293
    z[0,1,3]  R162      1.5222573280334473e-01
    z[0,1,3]  R163      -1.1127392202615738e-01
    z[0,1,3]  R164      2.6698562502861023e-01
    z[0,1,3]  R165      0.0815851241350174
    z[0,1,3]  R166      2.0858474075794220e-01
    z[0,1,3]  R167      2.5546187162399292e-01
    z[0,1,3]  R168      2.7224791049957275e-01
    z[0,1,3]  R169      -5.8066624402999878e-01
    z[0,1,3]  R170      -2.1184456348419189e-01
    z[0,1,3]  R171      -7.1251779794692993e-01
    z[0,1,3]  R172      -0.0191778764128685
    z[0,1,3]  R173      -3.0335992574691772e-01
    z[0,1,3]  R174      2.6501855254173279e-01
    z[0,1,3]  R175      6.0697649605572224e-03
    z[0,1,3]  R176      1.4614929258823395e-01
    z[0,1,3]  R177      -2.5967705994844437e-02
    z[0,1,3]  R178      -3.8211518526077271e-01
    z[0,1,3]  R179      -5.6091696023941040e-01
    z[0,1,3]  R180      -9.1272346675395966e-02
    z[0,1,3]  R181      3.3846864104270935e-01
    z[0,1,3]  R182      3.7194166332483292e-02
    z[0,1,3]  R183      4.0260624140501022e-02
    z[0,1,3]  R184      -2.9305824637413025e-01
    z[0,1,3]  R185      0.207631453871727
    z[0,1,3]  R186      6.7774903774261475e-01
    z[0,1,3]  R187      -6.9623276591300964e-02
    z[0,1,3]  R188      -2.0771314203739166e-01
    z[0,1,3]  R189      -0.00696546770632267
    z[0,1,3]  R190      7.0355825126171112e-02
    z[0,1,3]  R191      4.4429653882980347e-01
    z[0,1,3]  R192      7.4754811823368073e-02
    z[0,1,3]  R193      1.6481418907642365e-01
    z[0,1,3]  R194      -2.6582974195480347e-01
    z[0,1,3]  R195      8.2485699653625488e-01
    z[0,1,3]  R196      5.0227355957031250e-01
    z[0,1,3]  R197      1.0876694321632385e-01
    z[0,1,3]  R198      1.2753970222547650e-03
    z[0,1,3]  R199      8.4732629358768463e-02
    z[0,1,3]  R200      6.2167018651962280e-01
    z[0,1,3]  R201      5.9127581119537354e-01
    z[0,1,3]  R202      -3.6739131808280945e-01
    z[0,1,3]  R203      2.9516467452049255e-01
    z[0,1,3]  R204      -1.0469325631856918e-01
    z[0,1,3]  R205      -1.3179023563861847e-01
    z[0,1,3]  R206      -4.7945481538772583e-01
    z[0,1,3]  R207      5.8445721864700317e-01
    z[0,1,3]  R208      4.0771072963252664e-04
    z[0,1,3]  R209      0.0796792060136795
    z[0,1,3]  R210      5.8450758457183838e-01
    z[0,1,3]  R211      -6.9646090269088745e-01
    z[0,1,3]  R212      3.2750996947288513e-01
    z[0,1,3]  R213      4.2184704542160034e-01
    z[0,1,3]  R214      -3.8457545638084412e-01
    z[0,1,3]  R215      -3.3123109489679337e-02
    z[0,1,3]  R216      -1.1977288126945496e-01
    z[0,1,3]  R217      -2.5463856291025877e-03
    z[0,1,3]  R218      2.8450268507003784e-01
    z[0,1,3]  R219      5.8854973316192627e-01
    z[0,1,3]  R220      -5.7986426353454590e-01
    z[0,1,3]  R221      -2.5151500478386879e-02
    z[0,1,3]  R222      3.2991883158683777e-01
    z[0,1,3]  R223      6.6927188634872437e-01
    z[0,1,3]  R224      2.9772832989692688e-01
    z[0,1,3]  R225      6.1433595418930054e-01
    z[0,1,3]  R226      4.2071422934532166e-01
    z[0,1,3]  R227      -1.9240427762269974e-02
    z[0,1,3]  R228      0.529548168182373
    z[0,1,4]  R6        -1
    z[0,1,4]  R15       1
    z[0,1,4]  R73       -1
    z[0,1,4]  R74       1
    z[0,1,4]  R79       -6.8540310859680176e-01
    z[0,1,4]  R80       -6.5990060567855835e-01
    z[0,1,4]  R81       -6.2889808416366577e-01
    z[0,1,4]  R82       -2.1133351325988770e-01
    z[0,1,4]  R83       -8.2144963741302490e-01
    z[0,1,4]  R84       -4.4403173960745335e-03
    z[0,1,4]  R85       2.0590825378894806e-01
    z[0,1,4]  R86       2.5579905509948730e-01
    z[0,1,4]  R87       1.1942632496356964e-01
    z[0,1,4]  R88       -5.9767484664916992e-02
    z[0,1,4]  R89       -9.8800763487815857e-02
    z[0,1,4]  R90       0.721690833568573
    z[0,1,4]  R91       2.2953312098979950e-01
    z[0,1,4]  R92       0.0649818480014801
    z[0,1,4]  R93       1.4219713211059570e-01
    z[0,1,4]  R94       2.5511008501052856e-01
    z[0,1,4]  R95       3.0260652303695679e-01
    z[0,1,4]  R96       4.7169774770736694e-01
    z[0,1,4]  R97       -8.0509938299655914e-02
    z[0,1,4]  R98       -2.5258013606071472e-01
    z[0,1,4]  R99       -2.5747594237327576e-01
    z[0,1,4]  R100      1.4884701371192932e-01
    z[0,1,4]  R101      -3.3828923106193542e-01
    z[0,1,4]  R102      1.8099553883075714e-01
    z[0,1,4]  R103      -8.2265391945838928e-02
    z[0,1,4]  R104      8.9658334851264954e-02
    z[0,1,4]  R105      -4.6158339828252792e-02
    z[0,1,4]  R106      -4.5031303167343140e-01
    z[0,1,4]  R107      2.3909020423889160e-01
    z[0,1,4]  R108      2.5913387537002563e-01
    z[0,1,4]  R109      1.4467741549015045e-01
    z[0,1,4]  R110      -5.0215190649032593e-01
    z[0,1,4]  R111      -5.0982785224914551e-01
    z[0,1,4]  R112      0.330519437789917
    z[0,1,4]  R113      3.7079009413719177e-01
    z[0,1,4]  R114      2.2420334815979004e-01
    z[0,1,4]  R115      8.6895991116762161e-03
    z[0,1,4]  R116      1.1299183219671249e-01
    z[0,1,4]  R117      1.9198693335056305e-01
    z[0,1,4]  R118      3.3922556042671204e-01
    z[0,1,4]  R119      1.6213682293891907e-01
    z[0,1,4]  R120      4.4171714782714844e-01
    z[0,1,4]  R121      -1.3314799405634403e-02
    z[0,1,4]  R122      -1.9462814927101135e-01
    z[0,1,4]  R123      -1.4693741500377655e-01
    z[0,1,4]  R124      9.6453763544559479e-02
    z[0,1,4]  R125      -2.9710020869970322e-02
    z[0,1,4]  R126      3.5078969597816467e-01
    z[0,1,4]  R127      -1.6486944258213043e-01
    z[0,1,4]  R128      -0.0299517959356308
    z[0,1,4]  R129      4.2370632290840149e-01
    z[0,1,4]  R130      1.8065446987748146e-02
    z[0,1,4]  R131      3.6739388108253479e-01
    z[0,1,4]  R132      5.8633655309677124e-01
    z[0,1,4]  R133      1.6537471115589142e-01
    z[0,1,4]  R134      1.6097468137741089e-01
    z[0,1,4]  R135      1.7848816514015198e-01
    z[0,1,4]  R136      2.6838836073875427e-01
    z[0,1,4]  R137      1.1645889282226562e-01
    z[0,1,4]  R138      2.9949453473091125e-01
    z[0,1,4]  R139      -1.5863038599491119e-01
    z[0,1,4]  R140      -2.0651364326477051e-01
    z[0,1,4]  R141      -3.7758240103721619e-01
    z[0,1,4]  R142      -8.3849288523197174e-02
    z[0,1,4]  R143      -5.0751942396163940e-01
    z[0,1,4]  R144      -9.4126991927623749e-02
    z[0,1,4]  R145      1.0345663875341415e-01
    z[0,1,4]  R146      -7.7445471286773682e-01
    z[0,1,4]  R147      -4.0884593129158020e-01
    z[0,1,4]  R148      -5.5066245794296265e-01
    z[0,1,4]  R149      -1.9226944446563721e-01
    z[0,1,4]  R150      2.1234290301799774e-01
    z[0,1,4]  R151      -2.9462394118309021e-01
    z[0,1,4]  R152      -4.5862805843353271e-01
    z[0,1,4]  R153      -2.9427188634872437e-01
    z[0,1,4]  R154      0.473821222782135
    z[0,1,4]  R155      1.7656306922435760e-01
    z[0,1,4]  R156      0.512280285358429
    z[0,1,4]  R157      1.8443444371223450e-01
    z[0,1,4]  R158      6.3173137605190277e-02
    z[0,1,4]  R159      -5.9691351652145386e-01
    z[0,1,4]  R160      -5.0122201442718506e-01
    z[0,1,4]  R161      -8.1298923492431641e-01
    z[0,1,4]  R162      4.1157731413841248e-01
    z[0,1,4]  R163      0.13089619576931
    z[0,1,4]  R164      1.8609413504600525e-01
    z[0,1,4]  R165      1.9791173934936523e-01
    z[0,1,4]  R166      -2.6141893118619919e-02
    z[0,1,4]  R167      7.1282177232205868e-03
    z[0,1,4]  R168      -5.2257917821407318e-02
    z[0,1,4]  R169      -3.5380131006240845e-01
    z[0,1,4]  R170      -6.8181025981903076e-01
    z[0,1,4]  R171      -3.4506028890609741e-01
    z[0,1,4]  R172      -1.3816542923450470e-01
    z[0,1,4]  R173      3.3916497230529785e-01
    z[0,1,4]  R174      -7.2195746004581451e-02
    z[0,1,4]  R175      9.0210400521755219e-02
    z[0,1,4]  R176      -2.2630941867828369e-01
    z[0,1,4]  R177      -1.1395063996315002e-01
    z[0,1,4]  R178      2.5320026278495789e-01
    z[0,1,4]  R179      -2.6496413350105286e-01
    z[0,1,4]  R180      1.2268720567226410e-01
    z[0,1,4]  R181      -0.516111433506012
    z[0,1,4]  R182      -7.7362522482872009e-02
    z[0,1,4]  R183      3.6041066050529480e-01
    z[0,1,4]  R184      1.6203403472900391e-02
    z[0,1,4]  R185      3.3967226743698120e-02
    z[0,1,4]  R186      -4.0043359994888306e-01
    z[0,1,4]  R187      2.4488031864166260e-01
    z[0,1,4]  R188      -2.7999168634414673e-01
    z[0,1,4]  R189      1.5323479473590851e-01
    z[0,1,4]  R190      2.2334653884172440e-02
    z[0,1,4]  R191      -1.8812276422977448e-01
    z[0,1,4]  R192      -2.4828863143920898e-01
    z[0,1,4]  R193      -1.6168478131294250e-01
    z[0,1,4]  R194      -1.5106610953807831e-01
    z[0,1,4]  R195      7.6155625283718109e-02
    z[0,1,4]  R196      4.5021429657936096e-02
    z[0,1,4]  R197      1.1790663003921509e-01
    z[0,1,4]  R198      3.5410594195127487e-02
    z[0,1,4]  R199      0.0838705375790596
    z[0,1,4]  R200      -1.5915378928184509e-01
    z[0,1,4]  R201      -5.2755761146545410e-01
    z[0,1,4]  R202      -2.4036690592765808e-01
    z[0,1,4]  R203      -5.0913745164871216e-01
    z[0,1,4]  R204      0.000716552953235805
    z[0,1,4]  R205      5.7074010372161865e-01
    z[0,1,4]  R206      -1.7616911232471466e-01
    z[0,1,4]  R207      4.8988372087478638e-02
    z[0,1,4]  R208      3.4998711943626404e-01
    z[0,1,4]  R209      2.0113010704517365e-01
    z[0,1,4]  R210      -1.8414147198200226e-01
    z[0,1,4]  R211      2.8846734762191772e-01
    z[0,1,4]  R212      -4.8386237025260925e-01
    z[0,1,4]  R213      -4.8561595380306244e-02
    z[0,1,4]  R214      -2.9330602288246155e-01
    z[0,1,4]  R215      -4.0362879633903503e-01
    z[0,1,4]  R216      -3.4878385066986084e-01
    z[0,1,4]  R217      -3.7716156244277954e-01
    z[0,1,4]  R218      -3.8579076528549194e-01
    z[0,1,4]  R219      -3.0203866958618164e-01
    z[0,1,4]  R220      4.6352226287126541e-02
    z[0,1,4]  R221      1.6870559751987457e-01
    z[0,1,4]  R222      -2.5287646055221558e-01
    z[0,1,4]  R223      -1.5198273956775665e-01
    z[0,1,4]  R224      -2.8569018840789795e-01
    z[0,1,4]  R225      -1.9161500036716461e-01
    z[0,1,4]  R226      -2.7352344989776611e-01
    z[0,1,4]  R227      -2.6284396648406982e-01
    z[0,1,4]  R228      -1.8524785339832306e-01
    z[0,1,5]  R7        -1
    z[0,1,5]  R16       1
    z[0,1,5]  R75       -1
    z[0,1,5]  R76       1
    z[0,1,5]  R79       4.6116065979003906e-01
    z[0,1,5]  R80       5.4654383659362793e-01
    z[0,1,5]  R81       1.3602770864963531e-01
    z[0,1,5]  R82       8.8637866079807281e-02
    z[0,1,5]  R83       3.6333236098289490e-01
    z[0,1,5]  R84       7.3513254523277283e-02
    z[0,1,5]  R85       1.3788402080535889e-01
    z[0,1,5]  R86       6.0341589152812958e-02
    z[0,1,5]  R87       -1.3995829224586487e-01
    z[0,1,5]  R88       1.3770771026611328e-01
    z[0,1,5]  R89       -2.8934234380722046e-01
    z[0,1,5]  R90       -2.0392332226037979e-02
    z[0,1,5]  R91       -3.6336994171142578e-01
    z[0,1,5]  R92       -2.1523636579513550e-01
    z[0,1,5]  R93       -4.4337805360555649e-02
    z[0,1,5]  R94       5.9535790234804153e-02
    z[0,1,5]  R95       -1.4216606318950653e-01
    z[0,1,5]  R96       1.1818820238113403e-01
    z[0,1,5]  R97       -2.3110084235668182e-02
    z[0,1,5]  R98       -6.1451215296983719e-02
    z[0,1,5]  R99       -2.3863169550895691e-01
    z[0,1,5]  R100      2.8609130531549454e-03
    z[0,1,5]  R101      -3.4703877568244934e-01
    z[0,1,5]  R102      -8.0513760447502136e-02
    z[0,1,5]  R103      -2.5317358970642090e-01
    z[0,1,5]  R104      -0.0852438285946846
    z[0,1,5]  R105      -1.1414396017789841e-01
    z[0,1,5]  R106      -3.7345707416534424e-01
    z[0,1,5]  R107      -1.8260811269283295e-01
    z[0,1,5]  R108      1.8850685656070709e-01
    z[0,1,5]  R109      -3.1865498423576355e-01
    z[0,1,5]  R110      -6.2541222572326660e-01
    z[0,1,5]  R111      -4.9563441425561905e-02
    z[0,1,5]  R112      2.4108274281024933e-01
    z[0,1,5]  R113      -8.9520506560802460e-02
    z[0,1,5]  R114      -4.5341745018959045e-02
    z[0,1,5]  R115      3.4138467907905579e-01
    z[0,1,5]  R116      1.6713395714759827e-01
    z[0,1,5]  R117      5.1403380930423737e-02
    z[0,1,5]  R118      -1.7885808646678925e-01
    z[0,1,5]  R119      -1.5099354088306427e-01
    z[0,1,5]  R120      -3.3542364835739136e-02
    z[0,1,5]  R121      4.2033061385154724e-01
    z[0,1,5]  R122      -3.2964695245027542e-02
    z[0,1,5]  R123      -2.6514637470245361e-01
    z[0,1,5]  R124      1.6184569895267487e-01
    z[0,1,5]  R125      2.8925737738609314e-01
    z[0,1,5]  R126      -1.4822500944137573e-01
    z[0,1,5]  R127      -0.074454665184021
    z[0,1,5]  R128      1.5261600911617279e-01
    z[0,1,5]  R129      -1.0683242231607437e-02
    z[0,1,5]  R130      4.4384026527404785e-01
    z[0,1,5]  R131      5.6114387512207031e-01
    z[0,1,5]  R132      2.2153569757938385e-01
    z[0,1,5]  R133      0.0785888135433197
    z[0,1,5]  R134      -2.0154097676277161e-01
    z[0,1,5]  R135      -1.4973272383213043e-01
    z[0,1,5]  R136      -2.0013237372040749e-02
    z[0,1,5]  R137      1.4452475309371948e-01
    z[0,1,5]  R138      1.1037625372409821e-01
    z[0,1,5]  R139      1.5011714398860931e-01
    z[0,1,5]  R140      1.9484703242778778e-01
    z[0,1,5]  R141      4.0779468417167664e-01
    z[0,1,5]  R142      -3.6305990815162659e-01
    z[0,1,5]  R143      -1.8814601004123688e-01
    z[0,1,5]  R144      2.2578341886401176e-02
    z[0,1,5]  R145      4.0209281444549561e-01
    z[0,1,5]  R146      -2.2305153310298920e-01
    z[0,1,5]  R147      -3.4657639265060425e-01
    z[0,1,5]  R148      1.3650451600551605e-01
    z[0,1,5]  R149      -1.4910818636417389e-01
    z[0,1,5]  R150      -5.7941582053899765e-02
    z[0,1,5]  R151      -4.3500947952270508e-01
    z[0,1,5]  R152      1.2846945226192474e-01
    z[0,1,5]  R153      -1.9584308564662933e-01
    z[0,1,5]  R154      5.0724223256111145e-03
    z[0,1,5]  R155      -3.4511899948120117e-01
    z[0,1,5]  R156      -5.1498431712388992e-03
    z[0,1,5]  R157      4.2048788070678711e-01
    z[0,1,5]  R158      -0.248139888048172
    z[0,1,5]  R159      -2.2326861321926117e-01
    z[0,1,5]  R160      -1.4089688658714294e-01
    z[0,1,5]  R161      -3.5816648602485657e-01
    z[0,1,5]  R162      -1.9831705838441849e-02
    z[0,1,5]  R163      -2.8302398324012756e-01
    z[0,1,5]  R164      -2.6607608795166016e-01
    z[0,1,5]  R165      -9.3816900625824928e-03
    z[0,1,5]  R166      -0.00913193728774786
    z[0,1,5]  R167      -3.4307509660720825e-01
    z[0,1,5]  R168      1.3647709786891937e-01
    z[0,1,5]  R169      2.2741788998246193e-02
    z[0,1,5]  R170      4.9062767624855042e-01
    z[0,1,5]  R171      4.5953061431646347e-02
    z[0,1,5]  R172      -1.4729671180248260e-01
    z[0,1,5]  R173      -2.3401673138141632e-01
    z[0,1,5]  R174      4.9856898188591003e-01
    z[0,1,5]  R175      2.8222987055778503e-01
    z[0,1,5]  R176      -9.2234506155364215e-05
    z[0,1,5]  R177      -2.2545018792152405e-01
    z[0,1,5]  R178      4.0567898750305176e-01
    z[0,1,5]  R179      -1.1036479473114014e-01
    z[0,1,5]  R180      2.5438693165779114e-01
    z[0,1,5]  R181      -1.0560341179370880e-01
    z[0,1,5]  R182      4.6336323022842407e-01
    z[0,1,5]  R183      4.7741317749023438e-01
    z[0,1,5]  R184      -5.3843200206756592e-01
    z[0,1,5]  R185      -2.3436771705746651e-02
    z[0,1,5]  R186      3.7715956568717957e-01
    z[0,1,5]  R187      -0.510245680809021
    z[0,1,5]  R188      1.1509119719266891e-01
    z[0,1,5]  R189      -6.6956095397472382e-02
    z[0,1,5]  R190      4.1354256868362427e-01
    z[0,1,5]  R191      -0.234359011054039
    z[0,1,5]  R192      1.6112641990184784e-01
    z[0,1,5]  R193      1.0046856850385666e-01
    z[0,1,5]  R194      1.0830528289079666e-01
    z[0,1,5]  R195      1.3350382447242737e-01
    z[0,1,5]  R196      8.2315705716609955e-02
    z[0,1,5]  R197      4.7807514667510986e-02
    z[0,1,5]  R198      -1.8564681708812714e-01
    z[0,1,5]  R199      3.8254481554031372e-01
    z[0,1,5]  R200      4.2950016260147095e-01
    z[0,1,5]  R201      4.4323410838842392e-02
    z[0,1,5]  R202      -3.0888348817825317e-01
    z[0,1,5]  R203      -1.7003257572650909e-01
    z[0,1,5]  R204      -2.1060745418071747e-01
    z[0,1,5]  R205      -2.8826245665550232e-01
    z[0,1,5]  R206      -3.1406667828559875e-01
    z[0,1,5]  R207      -4.2162844538688660e-01
    z[0,1,5]  R208      -2.5881221890449524e-01
    z[0,1,5]  R209      3.3505931496620178e-01
    z[0,1,5]  R210      4.9329307675361633e-01
    z[0,1,5]  R211      1.1204126477241516e-01
    z[0,1,5]  R212      2.9471702873706818e-03
    z[0,1,5]  R213      5.1336448639631271e-02
    z[0,1,5]  R214      -1.6353687644004822e-01
    z[0,1,5]  R215      -3.7536349147558212e-02
    z[0,1,5]  R216      -4.7130686044692993e-01
    z[0,1,5]  R217      1.5334385633468628e-01
    z[0,1,5]  R218      -2.6177048683166504e-02
    z[0,1,5]  R219      5.0096571445465088e-01
    z[0,1,5]  R220      -2.0492132753133774e-02
    z[0,1,5]  R221      2.4650931358337402e-01
    z[0,1,5]  R222      3.1349015235900879e-01
    z[0,1,5]  R223      -1.9713032990694046e-02
    z[0,1,5]  R224      3.5099261999130249e-01
    z[0,1,5]  R225      1.7596293985843658e-01
    z[0,1,5]  R226      0.315409392118454
    z[0,1,5]  R227      -4.4421949982643127e-01
    z[0,1,5]  R228      8.2742515951395035e-03
    z[0,1,6]  R8        -1
    z[0,1,6]  R17       1
    z[0,1,6]  R77       -1
    z[0,1,6]  R78       1
    z[0,1,6]  R79       -8.2849457859992981e-02
    z[0,1,6]  R80       -1.8272195756435394e-01
    z[0,1,6]  R81       2.8193622827529907e-02
    z[0,1,6]  R82       -1.0989258438348770e-01
    z[0,1,6]  R83       3.0912297964096069e-01
    z[0,1,6]  R84       -1.7003765329718590e-02
    z[0,1,6]  R85       8.9599706232547760e-02
    z[0,1,6]  R86       3.8631439208984375e-01
    z[0,1,6]  R87       9.9594242870807648e-02
    z[0,1,6]  R88       3.9882853627204895e-01
    z[0,1,6]  R89       -1.9392198324203491e-01
    z[0,1,6]  R90       -2.1297354996204376e-01
    z[0,1,6]  R91       -1.1866380274295807e-01
    z[0,1,6]  R92       -1.7210614681243896e-01
    z[0,1,6]  R93       2.8479138016700745e-01
    z[0,1,6]  R94       0.158565953373909
    z[0,1,6]  R95       1.6385369002819061e-01
    z[0,1,6]  R96       -6.5212212502956390e-02
    z[0,1,6]  R97       1.6607193648815155e-01
    z[0,1,6]  R98       -3.8209420442581177e-01
    z[0,1,6]  R99       2.0963855087757111e-02
    z[0,1,6]  R100      -9.7138516604900360e-02
    z[0,1,6]  R101      1.5419182181358337e-01
    z[0,1,6]  R102      -2.4525739252567291e-01
    z[0,1,6]  R103      -1.9927522540092468e-01
    z[0,1,6]  R104      3.6211568117141724e-01
    z[0,1,6]  R105      -2.1221902966499329e-01
    z[0,1,6]  R106      -2.3844359815120697e-01
    z[0,1,6]  R107      3.1876003742218018e-01
    z[0,1,6]  R108      1.4437088370323181e-01
    z[0,1,6]  R109      2.4518595635890961e-01
    z[0,1,6]  R110      0.22120301425457
    z[0,1,6]  R111      2.5697039440274239e-02
    z[0,1,6]  R112      -3.0606296658515930e-01
    z[0,1,6]  R113      -5.0941254943609238e-02
    z[0,1,6]  R114      -1.0018956847488880e-02
    z[0,1,6]  R115      -0.314046174287796
    z[0,1,6]  R116      1.0457421094179153e-01
    z[0,1,6]  R117      -4.0676867961883545e-01
    z[0,1,6]  R118      1.7006288468837738e-01
    z[0,1,6]  R119      -0.0994422510266304
    z[0,1,6]  R120      -2.5032436847686768e-01
    z[0,1,6]  R121      2.5631364434957504e-02
    z[0,1,6]  R122      -2.2855636198073626e-03
    z[0,1,6]  R123      -2.0104375481605530e-01
    z[0,1,6]  R124      -1.3333666324615479e-01
    z[0,1,6]  R125      -1.4793017506599426e-01
    z[0,1,6]  R126      1.5221193432807922e-02
    z[0,1,6]  R127      1.8041402101516724e-01
    z[0,1,6]  R128      2.4068281054496765e-01
    z[0,1,6]  R129      1.6781672835350037e-01
    z[0,1,6]  R130      1.5728285908699036e-01
    z[0,1,6]  R131      -0.212831050157547
    z[0,1,6]  R132      1.1290422827005386e-01
    z[0,1,6]  R133      -2.0314763486385345e-01
    z[0,1,6]  R134      -2.0503292977809906e-01
    z[0,1,6]  R135      -2.0527285337448120e-01
    z[0,1,6]  R136      7.4418224394321442e-02
    z[0,1,6]  R137      -5.1902536302804947e-02
    z[0,1,6]  R138      1.1466937512159348e-01
    z[0,1,6]  R139      -3.8242095708847046e-01
    z[0,1,6]  R140      -0.123700812458992
    z[0,1,6]  R141      4.4131819158792496e-02
    z[0,1,6]  R142      2.0914927124977112e-01
    z[0,1,6]  R143      -1.5266370773315430e-01
    z[0,1,6]  R144      4.7503036260604858e-01
    z[0,1,6]  R145      -2.6302579045295715e-01
    z[0,1,6]  R146      -1.5337653458118439e-01
    z[0,1,6]  R147      3.7807431817054749e-01
    z[0,1,6]  R148      2.7391368150711060e-01
    z[0,1,6]  R149      2.6329910382628441e-02
    z[0,1,6]  R150      7.0679372549057007e-01
    z[0,1,6]  R151      4.6605333685874939e-02
    z[0,1,6]  R152      -3.4513169527053833e-01
    z[0,1,6]  R153      5.8406114578247070e-01
    z[0,1,6]  R154      -1.3775852508842945e-02
    z[0,1,6]  R155      -1.3469657301902771e-01
    z[0,1,6]  R156      6.3891232013702393e-02
    z[0,1,6]  R157      2.4693049490451813e-01
    z[0,1,6]  R158      2.5733673572540283e-01
    z[0,1,6]  R159      5.1083713769912720e-01
    z[0,1,6]  R160      4.4374740123748779e-01
    z[0,1,6]  R161      1.5302394330501556e-01
    z[0,1,6]  R162      -1.9526831805706024e-01
    z[0,1,6]  R163      -2.2403992712497711e-01
    z[0,1,6]  R164      -2.3340111970901489e-01
    z[0,1,6]  R165      4.2828115820884705e-01
    z[0,1,6]  R166      2.6880177855491638e-01
    z[0,1,6]  R167      2.2382782399654388e-01
    z[0,1,6]  R168      3.6712527275085449e-01
    z[0,1,6]  R169      4.4752866029739380e-01
    z[0,1,6]  R170      1.1494905501604080e-01
    z[0,1,6]  R171      1.8742652237415314e-01
    z[0,1,6]  R172      -2.2395202517509460e-01
    z[0,1,6]  R173      2.3580574989318848e-01
    z[0,1,6]  R174      1.2304235994815826e-01
    z[0,1,6]  R175      2.9824849218130112e-02
    z[0,1,6]  R176      2.2685025632381439e-01
    z[0,1,6]  R177      -9.2453166842460632e-02
    z[0,1,6]  R178      5.9650313109159470e-02
    z[0,1,6]  R179      0.196893572807312
    z[0,1,6]  R180      -1.2163080275058746e-01
    z[0,1,6]  R181      -5.5359661579132080e-01
    z[0,1,6]  R182      0.301082581281662
    z[0,1,6]  R183      1.8784141540527344e-01
    z[0,1,6]  R184      2.5613343715667725e-01
    z[0,1,6]  R185      -1.7376577854156494e-01
    z[0,1,6]  R186      1.1973126232624054e-01
    z[0,1,6]  R187      1.3432615995407104e-01
    z[0,1,6]  R188      1.5900996327400208e-01
    z[0,1,6]  R189      8.2109540700912476e-02
    z[0,1,6]  R190      3.1177085638046265e-01
    z[0,1,6]  R191      9.5916397869586945e-02
    z[0,1,6]  R192      -1.2706008553504944e-01
    z[0,1,6]  R193      -3.4822601079940796e-01
    z[0,1,6]  R194      1.3286796212196350e-01
    z[0,1,6]  R195      -2.3847262561321259e-01
    z[0,1,6]  R196      -7.5521886348724365e-02
    z[0,1,6]  R197      4.7048706561326981e-02
    z[0,1,6]  R198      -9.0640291571617126e-02
    z[0,1,6]  R199      2.1592923998832703e-01
    z[0,1,6]  R200      9.9643588066101074e-02
    z[0,1,6]  R201      -1.5728241205215454e-01
    z[0,1,6]  R202      1.2270531058311462e-01
    z[0,1,6]  R203      -2.2878400981426239e-01
    z[0,1,6]  R204      2.3199106752872467e-01
    z[0,1,6]  R205      -0.0837583988904953
    z[0,1,6]  R206      -1.3407164812088013e-01
    z[0,1,6]  R207      1.3882575929164886e-01
    z[0,1,6]  R208      -5.1358896493911743e-01
    z[0,1,6]  R209      2.2299818694591522e-01
    z[0,1,6]  R210      1.8443956971168518e-01
    z[0,1,6]  R211      -6.9723889231681824e-02
    z[0,1,6]  R212      -1.9082710146903992e-01
    z[0,1,6]  R213      -6.0413774102926254e-02
    z[0,1,6]  R214      -1.6859705746173859e-01
    z[0,1,6]  R215      8.4657423198223114e-02
    z[0,1,6]  R216      -2.8084853291511536e-01
    z[0,1,6]  R217      -1.8471510848030448e-03
    z[0,1,6]  R218      -5.2542369812726974e-03
    z[0,1,6]  R219      1.1301857233047485e-01
    z[0,1,6]  R220      1.4101485908031464e-01
    z[0,1,6]  R221      -2.0797398686408997e-01
    z[0,1,6]  R222      -1.3379167020320892e-01
    z[0,1,6]  R223      -2.0895868539810181e-02
    z[0,1,6]  R224      -5.8076906949281693e-02
    z[0,1,6]  R225      5.0957348197698593e-02
    z[0,1,6]  R226      1.7451328039169312e-01
    z[0,1,6]  R227      3.5186418890953064e-01
    z[0,1,6]  R228      -2.1904313564300537e-01
    z[1,0,0]  R2        1
    z[1,0,0]  R11       -1
    z[1,0,0]  R229      -1
    z[1,0,0]  R230      1
    z[1,0,0]  R243      0.723736584186554
    z[1,0,0]  R244      8.0472415685653687e-01
    z[1,0,0]  R245      6.1697083711624146e-01
    z[1,0,0]  R246      6.5605306625366211e-01
    z[1,0,0]  R247      8.8712280988693237e-01
    z[1,0,0]  R248      8.8229048252105713e-01
    z[1,0,0]  R249      8.9311712980270386e-01
    z[1,0,0]  R250      9.1823190450668335e-01
    z[1,0,0]  R251      8.4810262918472290e-01
    z[1,0,0]  R252      8.6877566576004028e-01
    z[1,0,0]  R253      -2.4355600774288177e-01
    z[1,0,0]  R254      -8.6646175384521484e-01
    z[1,0,0]  R255      -1.7858077585697174e-01
    z[1,0,0]  R256      -3.5714778304100037e-01
    z[1,0,0]  R257      -7.5557577610015869e-01
    z[1,0,0]  R258      -7.6985865831375122e-01
    z[1,0,0]  R259      -7.5257080793380737e-01
    z[1,0,0]  R260      -1.5396592207252979e-02
    z[1,0,0]  R261      -1.4446650445461273e-01
    z[1,0,0]  R262      8.9831940829753876e-02
    z[1,0,0]  R263      -4.6918381005525589e-02
    z[1,0,0]  R264      1.3612688519060612e-02
    z[1,0,0]  R265      -7.2523248195648193e-01
    z[1,0,0]  R266      -2.0390337333083153e-02
    z[1,0,0]  R267      2.3649508133530617e-02
    z[1,0,0]  R268      -7.7637803554534912e-01
    z[1,0,0]  R269      -7.3027008771896362e-01
    z[1,0,0]  R270      -7.8857392072677612e-01
    z[1,0,0]  R271      0.0638904869556427
    z[1,0,0]  R272      -0.730022668838501
    z[1,0,0]  R273      3.2288023829460144e-01
    z[1,0,0]  R274      1.6156212985515594e-01
    z[1,0,0]  R275      2.2361817955970764e-01
    z[1,0,0]  R276      -7.8468585014343262e-01
    z[1,0,0]  R277      -7.9549568891525269e-01
    z[1,0,0]  R278      -8.5130012035369873e-01
    z[1,0,0]  R279      -0.858471155166626
    z[1,0,0]  R280      -8.3502292633056641e-01
    z[1,0,0]  R281      -8.7198764085769653e-01
    z[1,0,0]  R282      -7.3678523302078247e-01
    z[1,0,0]  R283      2.4792306125164032e-01
    z[1,0,0]  R284      3.6198583245277405e-01
    z[1,0,0]  R285      1.3135664165019989e-01
    z[1,0,0]  R286      -8.4073919057846069e-01
    z[1,0,0]  R287      -7.6478409767150879e-01
    z[1,0,0]  R288      -7.9939109086990356e-01
    z[1,0,0]  R289      -7.9929852485656738e-01
    z[1,0,0]  R290      -7.9075801372528076e-01
    z[1,0,0]  R291      -8.4291136264801025e-01
    z[1,0,0]  R292      -4.1825491189956665e-01
    z[1,0,0]  R293      1.5854188799858093e-01
    z[1,0,0]  R294      -9.3071717023849487e-01
    z[1,0,0]  R295      -4.7545678913593292e-02
    z[1,0,0]  R296      -0.812671959400177
    z[1,0,0]  R297      -7.1106845140457153e-01
    z[1,0,0]  R298      -6.4418500661849976e-01
    z[1,0,0]  R299      -8.2161104679107666e-01
    z[1,0,0]  R300      -3.3492672443389893e-01
    z[1,0,0]  R301      -7.1009427309036255e-01
    z[1,0,0]  R302      -8.5085999965667725e-01
    z[1,0,0]  R303      -8.4011381864547729e-01
    z[1,0,0]  R304      -8.2892262935638428e-01
    z[1,0,0]  R305      -6.6660982370376587e-01
    z[1,0,0]  R306      -8.4759056568145752e-01
    z[1,0,0]  R307      -7.2158157825469971e-01
    z[1,0,0]  R308      -8.4859234094619751e-01
    z[1,0,0]  R309      -3.8933184742927551e-01
    z[1,0,0]  R310      -6.2131547927856445e-01
    z[1,0,0]  R311      2.4689945578575134e-01
    z[1,0,0]  R312      1.7999957501888275e-01
    z[1,0,0]  R313      -8.6880499124526978e-01
    z[1,0,0]  R314      -3.5068488121032715e-01
    z[1,0,0]  R315      -7.1212485432624817e-02
    z[1,0,0]  R316      -0.813671350479126
    z[1,0,0]  R317      -8.9947231113910675e-02
    z[1,0,0]  R318      2.4146883189678192e-01
    z[1,0,0]  R319      -6.0453188419342041e-01
    z[1,0,0]  R320      -1.4398542046546936e-01
    z[1,0,0]  R321      -4.0792167186737061e-01
    z[1,0,0]  R322      -2.6940107345581055e-01
    z[1,0,0]  R323      -0.852932870388031
    z[1,0,0]  R324      -3.3950966596603394e-01
    z[1,0,0]  R325      -1.7837733030319214e-01
    z[1,0,0]  R326      -1.7302061617374420e-01
    z[1,0,0]  R327      -5.4825592041015625e-01
    z[1,0,0]  R328      -1.2178809195756912e-01
    z[1,0,0]  R329      2.0942500233650208e-01
    z[1,0,0]  R330      -0.0467689111828804
    z[1,0,0]  R331      2.5784561038017273e-01
    z[1,0,0]  R332      1.8484315276145935e-01
    z[1,0,0]  R333      -2.8594323992729187e-01
    z[1,0,0]  R334      -7.4660068750381470e-01
    z[1,0,0]  R335      -7.9481208324432373e-01
    z[1,0,0]  R336      -1.2942856550216675e-01
    z[1,0,0]  R337      -4.0330997109413147e-01
    z[1,0,0]  R338      1.4957337081432343e-01
    z[1,0,0]  R339      3.4764219075441360e-02
    z[1,0,0]  R340      3.4324326552450657e-03
    z[1,0,0]  R341      1.9561995286494493e-03
    z[1,0,0]  R342      0.251740038394928
    z[1,0,0]  R343      1.6584175825119019e-01
    z[1,0,0]  R344      -0.0663711279630661
    z[1,0,0]  R345      1.1949385702610016e-01
    z[1,0,0]  R346      1.9378165900707245e-01
    z[1,0,0]  R347      4.3577592819929123e-02
    z[1,0,0]  R348      9.0140420198440552e-01
    z[1,0,0]  R349      8.1452596187591553e-01
    z[1,0,0]  R350      8.2104223966598511e-01
    z[1,0,0]  R351      9.7160762548446655e-01
    z[1,0,0]  R352      8.1599676609039307e-01
    z[1,0,0]  R353      1.9828332960605621e-01
    z[1,0,0]  R354      -4.4695755839347839e-01
    z[1,0,0]  R355      1.6230948269367218e-01
    z[1,0,0]  R356      -3.4789907932281494e-01
    z[1,0,0]  R357      -4.4342020153999329e-01
    z[1,0,0]  R358      -8.9742016792297363e-01
    z[1,0,0]  R359      -8.4654372930526733e-01
    z[1,0,0]  R360      -8.3944803476333618e-01
    z[1,0,0]  R361      -7.8399944305419922e-01
    z[1,0,0]  R362      -3.5530397295951843e-01
    z[1,0,0]  R363      -5.4938018321990967e-01
    z[1,0,0]  R364      4.9426622688770294e-02
    z[1,0,0]  R365      -6.1445814371109009e-01
    z[1,0,0]  R366      -4.0386113524436951e-01
    z[1,0,0]  R367      -4.9271425604820251e-01
    z[1,0,0]  R368      1.2376247346401215e-01
    z[1,0,0]  R369      -1.5954676270484924e-01
    z[1,0,0]  R370      4.6899044513702393e-01
    z[1,0,0]  R371      -5.2462047338485718e-01
    z[1,0,0]  R372      -6.4716976881027222e-01
    z[1,0,0]  R373      -2.0606555044651031e-01
    z[1,0,0]  R374      -1.5359888970851898e-01
    z[1,0,0]  R375      4.3930616974830627e-01
    z[1,0,0]  R376      -5.3720917552709579e-02
    z[1,0,0]  R377      -2.1099595725536346e-01
    z[1,0,0]  R378      -3.9522945880889893e-01
    z[1,0,0]  R379      -1.4909274876117706e-01
    z[1,0,0]  R380      -0.791441798210144
    z[1,0,0]  R381      -7.3082339763641357e-01
    z[1,0,0]  R382      -4.1452351212501526e-01
    z[1,0,0]  R383      -2.9931643605232239e-01
    z[1,0,0]  R384      -7.7392721176147461e-01
    z[1,0,0]  R385      -0.832425057888031
    z[1,0,0]  R386      -4.8705756664276123e-01
    z[1,0,0]  R387      -5.5040019750595093e-01
    z[1,0,0]  R388      -4.6058323979377747e-01
    z[1,0,0]  R389      -4.6979156136512756e-01
    z[1,0,0]  R390      -7.4821233749389648e-01
    z[1,0,0]  R391      -0.479658305644989
    z[1,0,0]  R392      -4.6973422169685364e-01
    z[1,0,1]  R3        1
    z[1,0,1]  R12       -1
    z[1,0,1]  R231      -1
    z[1,0,1]  R232      1
    z[1,0,1]  R243      -3.3563992381095886e-01
    z[1,0,1]  R244      -2.8114026784896851e-01
    z[1,0,1]  R245      -2.0235392451286316e-01
    z[1,0,1]  R246      -3.9763000607490540e-01
    z[1,0,1]  R247      -1.9126047194004059e-01
    z[1,0,1]  R248      -3.2268315553665161e-01
    z[1,0,1]  R249      -1.1038208752870560e-01
    z[1,0,1]  R250      -1.0242065042257309e-01
    z[1,0,1]  R251      -3.7171953916549683e-01
    z[1,0,1]  R252      -2.7798095345497131e-01
    z[1,0,1]  R253      -7.3880583047866821e-01
    z[1,0,1]  R254      2.8852856159210205e-01
    z[1,0,1]  R255      -6.9745475053787231e-01
    z[1,0,1]  R256      -6.7659026384353638e-01
    z[1,0,1]  R257      1.5621243417263031e-01
    z[1,0,1]  R258      1.3875234127044678e-01
    z[1,0,1]  R259      7.7380046248435974e-02
    z[1,0,1]  R260      -2.4864664673805237e-01
    z[1,0,1]  R261      -7.1995544433593750e-01
    z[1,0,1]  R262      4.3988442420959473e-01
    z[1,0,1]  R263      -8.7624388933181763e-01
    z[1,0,1]  R264      -2.5671776384115219e-02
    z[1,0,1]  R265      3.5382679104804993e-01
    z[1,0,1]  R266      -1.6947848722338676e-02
    z[1,0,1]  R267      -2.8374776244163513e-01
    z[1,0,1]  R268      2.6474717259407043e-01
    z[1,0,1]  R269      3.5049974918365479e-01
    z[1,0,1]  R270      8.2094341516494751e-02
    z[1,0,1]  R271      5.8240371942520142e-01
    z[1,0,1]  R272      2.2649440169334412e-01
    z[1,0,1]  R273      -1.4183451235294342e-01
    z[1,0,1]  R274      -1.4633235335350037e-01
    z[1,0,1]  R275      -2.8569728136062622e-01
    z[1,0,1]  R276      3.9122492074966431e-01
    z[1,0,1]  R277      4.2709720134735107e-01
    z[1,0,1]  R278      2.0969817042350769e-01
    z[1,0,1]  R279      1.8353113532066345e-01
    z[1,0,1]  R280      4.3121472001075745e-01
    z[1,0,1]  R281      4.7087732702493668e-02
    z[1,0,1]  R282      3.2928496599197388e-01
    z[1,0,1]  R283      -4.2966210842132568e-01
    z[1,0,1]  R284      1.4785882830619812e-01
    z[1,0,1]  R285      5.3121572732925415e-01
    z[1,0,1]  R286      3.4137284755706787e-01
    z[1,0,1]  R287      2.1490712463855743e-01
    z[1,0,1]  R288      1.4756475389003754e-01
    z[1,0,1]  R289      -4.8007094860076904e-01
    z[1,0,1]  R290      -4.7991201281547546e-01
    z[1,0,1]  R291      -3.9515095949172974e-01
    z[1,0,1]  R292      -6.2988650798797607e-01
    z[1,0,1]  R293      4.1771256923675537e-01
    z[1,0,1]  R294      1.5441577136516571e-01
    z[1,0,1]  R295      -3.9207491278648376e-01
    z[1,0,1]  R296      1.6048018634319305e-01
    z[1,0,1]  R297      3.0565094947814941e-01
    z[1,0,1]  R298      3.3529585599899292e-01
    z[1,0,1]  R299      -4.1966083645820618e-01
    z[1,0,1]  R300      -2.7800619602203369e-01
    z[1,0,1]  R301      6.7779272794723511e-02
    z[1,0,1]  R302      -3.1335547566413879e-01
    z[1,0,1]  R303      4.0297958254814148e-01
    z[1,0,1]  R304      1.9702941179275513e-01
    z[1,0,1]  R305      4.1896373033523560e-01
    z[1,0,1]  R306      -4.1293808817863464e-01
    z[1,0,1]  R307      -5.4255348443984985e-01
    z[1,0,1]  R308      -3.4744662046432495e-01
    z[1,0,1]  R309      1.5410919487476349e-01
    z[1,0,1]  R310      -5.8917975425720215e-01
    z[1,0,1]  R311      9.3907696008682251e-01
    z[1,0,1]  R312      9.6039682626724243e-01
    z[1,0,1]  R313      1.8808189034461975e-01
    z[1,0,1]  R314      -3.5703826695680618e-02
    z[1,0,1]  R315      -2.1576354280114174e-02
    z[1,0,1]  R316      5.2840482443571091e-02
    z[1,0,1]  R317      -0.669160008430481
    z[1,0,1]  R318      8.5001587867736816e-01
    z[1,0,1]  R319      -4.2836752533912659e-01
    z[1,0,1]  R320      5.4281461238861084e-01
    z[1,0,1]  R321      -4.0056610107421875e-01
    z[1,0,1]  R322      -5.1552116870880127e-01
    z[1,0,1]  R323      2.4238830804824829e-01
    z[1,0,1]  R324      -1.0183142125606537e-01
    z[1,0,1]  R325      -5.1572978496551514e-01
    z[1,0,1]  R326      -7.6958012580871582e-01
    z[1,0,1]  R327      -2.7142700552940369e-01
    z[1,0,1]  R328      8.2527321577072144e-01
    z[1,0,1]  R329      8.8517922163009644e-01
    z[1,0,1]  R330      7.2231113910675049e-01
    z[1,0,1]  R331      0.835231363773346
    z[1,0,1]  R332      8.3807313442230225e-01
    z[1,0,1]  R333      -5.3620919585227966e-02
    z[1,0,1]  R334      2.3409350216388702e-01
    z[1,0,1]  R335      3.8337996602058411e-01
    z[1,0,1]  R336      -8.3246874809265137e-01
    z[1,0,1]  R337      -3.3632597327232361e-01
    z[1,0,1]  R338      0.822594165802002
    z[1,0,1]  R339      7.3138356208801270e-01
    z[1,0,1]  R340      7.8624749183654785e-01
    z[1,0,1]  R341      7.7497494220733643e-01
    z[1,0,1]  R342      7.3773950338363647e-01
    z[1,0,1]  R343      -8.0154515802860260e-02
    z[1,0,1]  R344      -1.8110516667366028e-01
    z[1,0,1]  R345      1.2446816544979811e-03
    z[1,0,1]  R346      -2.5708785653114319e-01
    z[1,0,1]  R347      -2.1594421565532684e-01
    z[1,0,1]  R348      -1.6137482225894928e-01
    z[1,0,1]  R349      0.0124838100746274
    z[1,0,1]  R350      -2.2792570292949677e-01
    z[1,0,1]  R351      5.5811285972595215e-02
    z[1,0,1]  R352      -1.4057861268520355e-01
    z[1,0,1]  R353      -5.1473462581634521e-01
    z[1,0,1]  R354      -4.1156825423240662e-01
    z[1,0,1]  R355      -7.2181558609008789e-01
    z[1,0,1]  R356      -5.0044882297515869e-01
    z[1,0,1]  R357      -4.8834976553916931e-01
    z[1,0,1]  R358      3.0170795321464539e-01
    z[1,0,1]  R359      -2.7758213877677917e-01
    z[1,0,1]  R360      8.4900282323360443e-02
    z[1,0,1]  R361      1.8939383327960968e-01
    z[1,0,1]  R362      -4.7070616483688354e-01
    z[1,0,1]  R363      -4.6050909161567688e-01
    z[1,0,1]  R364      -8.8417333364486694e-01
    z[1,0,1]  R365      -2.8729760646820068e-01
    z[1,0,1]  R366      -6.2607473134994507e-01
    z[1,0,1]  R367      -7.9398363828659058e-01
    z[1,0,1]  R368      -9.0427374839782715e-01
    z[1,0,1]  R369      -6.6911959648132324e-01
    z[1,0,1]  R370      -3.4406265616416931e-01
    z[1,0,1]  R371      -5.9844875335693359e-01
    z[1,0,1]  R372      -5.7142537832260132e-01
    z[1,0,1]  R373      -6.6057282686233521e-01
    z[1,0,1]  R374      -1.2760999798774719e-01
    z[1,0,1]  R375      -5.6027692556381226e-01
    z[1,0,1]  R376      -5.0797986984252930e-01
    z[1,0,1]  R377      3.2867971062660217e-01
    z[1,0,1]  R378      8.6333960294723511e-02
    z[1,0,1]  R379      -4.6954333782196045e-01
    z[1,0,1]  R380      2.3565386235713959e-01
    z[1,0,1]  R381      4.2102980613708496e-01
    z[1,0,1]  R382      -1.0445768386125565e-01
    z[1,0,1]  R383      -1.2167669832706451e-01
    z[1,0,1]  R384      2.9350259900093079e-01
    z[1,0,1]  R385      3.5589879751205444e-01
    z[1,0,1]  R386      8.3448427915573120e-01
    z[1,0,1]  R387      7.3100918531417847e-01
    z[1,0,1]  R388      8.1843090057373047e-01
    z[1,0,1]  R389      7.9347169399261475e-01
    z[1,0,1]  R390      1.4243361353874207e-01
    z[1,0,1]  R391      7.6907247304916382e-01
    z[1,0,1]  R392      7.3240584135055542e-01
    z[1,0,2]  R4        1
    z[1,0,2]  R13       -1
    z[1,0,2]  R233      -1
    z[1,0,2]  R234      1
    z[1,0,2]  R243      -1.1853816360235214e-01
    z[1,0,2]  R244      -1.3509753160178661e-02
    z[1,0,2]  R245      -5.8933593332767487e-02
    z[1,0,2]  R246      -5.3258843719959259e-02
    z[1,0,2]  R247      7.5866342522203922e-03
    z[1,0,2]  R248      6.0134965926408768e-02
    z[1,0,2]  R249      2.9740616679191589e-01
    z[1,0,2]  R250      2.6105591654777527e-01
    z[1,0,2]  R251      -2.3807699978351593e-01
    z[1,0,2]  R252      2.2151088714599609e-01
    z[1,0,2]  R253      -1.4257369935512543e-01
    z[1,0,2]  R254      2.1280555427074432e-01
    z[1,0,2]  R255      -5.3871236741542816e-02
    z[1,0,2]  R256      -0.158564493060112
    z[1,0,2]  R257      -7.0406176149845123e-02
    z[1,0,2]  R258      -1.9678844138979912e-02
    z[1,0,2]  R259      -2.5658485293388367e-01
    z[1,0,2]  R260      -3.8320258259773254e-01
    z[1,0,2]  R261      1.7249508202075958e-01
    z[1,0,2]  R262      4.3248921632766724e-01
    z[1,0,2]  R263      -1.2811531126499176e-01
    z[1,0,2]  R264      1.4191722869873047e-01
    z[1,0,2]  R265      -1.0315258055925369e-01
    z[1,0,2]  R266      5.7939875125885010e-01
    z[1,0,2]  R267      4.5659548044204712e-01
    z[1,0,2]  R268      -2.1855439245700836e-01
    z[1,0,2]  R269      -2.0133875310420990e-01
    z[1,0,2]  R270      1.3484379276633263e-02
    z[1,0,2]  R271      2.1422983705997467e-01
    z[1,0,2]  R272      2.9233434796333313e-01
    z[1,0,2]  R273      3.5992351174354553e-01
    z[1,0,2]  R274      -0.679987370967865
    z[1,0,2]  R275      -2.2934034466743469e-01
    z[1,0,2]  R276      -0.0109430942684412
    z[1,0,2]  R277      -1.5799516439437866e-01
    z[1,0,2]  R278      1.1394404806196690e-02
    z[1,0,2]  R279      -2.3620298597961664e-03
    z[1,0,2]  R280      1.6179924830794334e-02
    z[1,0,2]  R281      -0.0656462013721466
    z[1,0,2]  R282      3.4418323636054993e-01
    z[1,0,2]  R283      3.0129194259643555e-01
    z[1,0,2]  R284      2.8884598612785339e-01
    z[1,0,2]  R285      1.9122385978698730e-01
    z[1,0,2]  R286      -2.9208555817604065e-01
    z[1,0,2]  R287      -2.2691851854324341e-01
    z[1,0,2]  R288      6.4044152386486530e-03
    z[1,0,2]  R289      2.0478211343288422e-01
    z[1,0,2]  R290      1.4265184104442596e-01
    z[1,0,2]  R291      2.4560482800006866e-01
    z[1,0,2]  R292      -2.2371813654899597e-01
    z[1,0,2]  R293      6.0382062196731567e-01
    z[1,0,2]  R294      0.0838552713394165
    z[1,0,2]  R295      -3.8139653205871582e-01
    z[1,0,2]  R296      3.2950885593891144e-02
    z[1,0,2]  R297      -7.8959226608276367e-02
    z[1,0,2]  R298      1.7590709030628204e-01
    z[1,0,2]  R299      -2.7172014117240906e-01
    z[1,0,2]  R300      -1.8509723246097565e-01
    z[1,0,2]  R301      3.8466113805770874e-01
    z[1,0,2]  R302      -1.3332429528236389e-01
    z[1,0,2]  R303      3.1154736876487732e-01
    z[1,0,2]  R304      1.9985429942607880e-02
    z[1,0,2]  R305      2.8842157125473022e-01
    z[1,0,2]  R306      -4.1602656245231628e-02
    z[1,0,2]  R307      -1.7169304192066193e-02
    z[1,0,2]  R308      -1.9052948057651520e-01
    z[1,0,2]  R309      -2.5256642699241638e-01
    z[1,0,2]  R310      7.0102256722748280e-03
    z[1,0,2]  R311      -1.6414555907249451e-01
    z[1,0,2]  R312      -3.6084707826375961e-02
    z[1,0,2]  R313      -5.1217749714851379e-02
    z[1,0,2]  R314      -5.1917475461959839e-01
    z[1,0,2]  R315      -5.8295524120330811e-01
    z[1,0,2]  R316      1.7868605256080627e-01
    z[1,0,2]  R317      3.4137687087059021e-01
    z[1,0,2]  R318      -3.3170655369758606e-01
    z[1,0,2]  R319      1.3348698616027832e-01
    z[1,0,2]  R320      -5.5416148900985718e-01
    z[1,0,2]  R321      3.6347416043281555e-01
    z[1,0,2]  R322      -4.5652204751968384e-01
    z[1,0,2]  R323      -7.0415951311588287e-02
    z[1,0,2]  R324      -4.7058498859405518e-01
    z[1,0,2]  R325      -3.4134802222251892e-01
    z[1,0,2]  R326      -1.0316787520423532e-03
    z[1,0,2]  R327      6.6267979145050049e-01
    z[1,0,2]  R328      -1.2245739996433258e-01
    z[1,0,2]  R329      3.1064450740814209e-03
    z[1,0,2]  R330      -1.9768038392066956e-01
    z[1,0,2]  R331      -2.6481890678405762e-01
    z[1,0,2]  R332      -1.8159645795822144e-01
    z[1,0,2]  R333      -4.6260491013526917e-01
    z[1,0,2]  R334      -1.7056234180927277e-01
    z[1,0,2]  R335      -2.9695001244544983e-01
    z[1,0,2]  R336      3.5705637186765671e-02
    z[1,0,2]  R337      5.0237149000167847e-01
    z[1,0,2]  R338      -6.4319007098674774e-02
    z[1,0,2]  R339      1.2722036242485046e-01
    z[1,0,2]  R340      -7.0435716770589352e-03
    z[1,0,2]  R341      -9.3880154192447662e-02
    z[1,0,2]  R342      1.7199160158634186e-01
    z[1,0,2]  R343      -0.506878137588501
    z[1,0,2]  R344      -4.2139717936515808e-01
    z[1,0,2]  R345      -6.9209235906600952e-01
    z[1,0,2]  R346      -8.3501911163330078e-01
    z[1,0,2]  R347      -2.2046999633312225e-01
    z[1,0,2]  R348      -7.1110002696514130e-02
    z[1,0,2]  R349      3.5653421282768250e-01
    z[1,0,2]  R350      8.5008360445499420e-02
    z[1,0,2]  R351      -0.0941428393125534
    z[1,0,2]  R352      1.8917587399482727e-01
    z[1,0,2]  R353      2.1824875473976135e-01
    z[1,0,2]  R354      -2.8268773108720779e-02
    z[1,0,2]  R355      1.5187076292932034e-02
    z[1,0,2]  R356      8.6479753255844116e-02
    z[1,0,2]  R357      4.6523684263229370e-01
    z[1,0,2]  R358      -3.9636015892028809e-02
    z[1,0,2]  R359      -1.7314006388187408e-01
    z[1,0,2]  R360      1.1506627500057220e-01
    z[1,0,2]  R361      3.6588132381439209e-01
    z[1,0,2]  R362      4.2354875802993774e-01
    z[1,0,2]  R363      -0.427571177482605
    z[1,0,2]  R364      -2.0107574760913849e-01
    z[1,0,2]  R365      -3.7276017665863037e-01
    z[1,0,2]  R366      -3.8085898756980896e-01
    z[1,0,2]  R367      -1.2745060026645660e-01
    z[1,0,2]  R368      -4.2258203029632568e-02
    z[1,0,2]  R369      -8.9466765522956848e-02
    z[1,0,2]  R370      -1.2418854981660843e-01
    z[1,0,2]  R371      -4.1712176799774170e-01
    z[1,0,2]  R372      -3.6077263951301575e-01
    z[1,0,2]  R373      -5.7610249519348145e-01
    z[1,0,2]  R374      -5.0727421045303345e-01
    z[1,0,2]  R375      8.7560452520847321e-02
    z[1,0,2]  R376      6.7385137081146240e-01
    z[1,0,2]  R377      -0.0605199821293354
    z[1,0,2]  R378      7.0161208510398865e-02
    z[1,0,2]  R379      5.4754996299743652e-01
    z[1,0,2]  R380      4.1273349523544312e-01
    z[1,0,2]  R381      -4.3047182261943817e-02
    z[1,0,2]  R382      0.261992871761322
    z[1,0,2]  R383      1.4161027036607265e-02
    z[1,0,2]  R384      6.5739743411540985e-02
    z[1,0,2]  R385      4.7190878540277481e-02
    z[1,0,2]  R386      1.5756408870220184e-01
    z[1,0,2]  R387      0.00896039791405201
    z[1,0,2]  R388      2.2195219993591309e-01
    z[1,0,2]  R389      4.6186674386262894e-02
    z[1,0,2]  R390      0.515374481678009
    z[1,0,2]  R391      -5.8893103152513504e-02
    z[1,0,2]  R392      2.9958483576774597e-01
    z[1,0,3]  R5        1
    z[1,0,3]  R14       -1
    z[1,0,3]  R235      -1
    z[1,0,3]  R236      1
    z[1,0,3]  R243      3.7642562389373779e-01
    z[1,0,3]  R244      2.2613757848739624e-01
    z[1,0,3]  R245      2.8243386745452881e-01
    z[1,0,3]  R246      0.0550660714507103
    z[1,0,3]  R247      -3.1871774792671204e-01
    z[1,0,3]  R248      0.0724758729338646
    z[1,0,3]  R249      -0.0727483481168747
    z[1,0,3]  R250      -1.5462476760149002e-02
    z[1,0,3]  R251      -2.2073060274124146e-01
    z[1,0,3]  R252      6.2123283743858337e-02
    z[1,0,3]  R253      -0.424940824508667
    z[1,0,3]  R254      -1.5746068954467773e-01
    z[1,0,3]  R255      -4.0981835126876831e-01
    z[1,0,3]  R256      -4.5490843057632446e-01
    z[1,0,3]  R257      2.8890269994735718e-01
    z[1,0,3]  R258      -3.9071059226989746e-01
    z[1,0,3]  R259      -0.346769779920578
    z[1,0,3]  R260      3.4356537461280823e-01
    z[1,0,3]  R261      2.8785686939954758e-02
    z[1,0,3]  R262      -4.6313452720642090e-01
    z[1,0,3]  R263      -3.9203029870986938e-01
    z[1,0,3]  R264      -6.5651428699493408e-01
    z[1,0,3]  R265      -2.4493958055973053e-01
    z[1,0,3]  R266      -5.6359034776687622e-01
    z[1,0,3]  R267      -4.9433851242065430e-01
    z[1,0,3]  R268      2.3379026353359222e-01
    z[1,0,3]  R269      3.6727815866470337e-01
    z[1,0,3]  R270      3.2355868816375732e-01
    z[1,0,3]  R271      -5.8226162195205688e-01
    z[1,0,3]  R272      -4.4555738568305969e-01
    z[1,0,3]  R273      -0.281028687953949
    z[1,0,3]  R274      1.4870950579643250e-01
    z[1,0,3]  R275      -0.0558922179043293
    z[1,0,3]  R276      1.5222573280334473e-01
    z[1,0,3]  R277      -1.1127392202615738e-01
    z[1,0,3]  R278      2.6698562502861023e-01
    z[1,0,3]  R279      0.0815851241350174
    z[1,0,3]  R280      2.0858474075794220e-01
    z[1,0,3]  R281      2.5546187162399292e-01
    z[1,0,3]  R282      2.7224791049957275e-01
    z[1,0,3]  R283      -5.8066624402999878e-01
    z[1,0,3]  R284      -2.1184456348419189e-01
    z[1,0,3]  R285      -7.1251779794692993e-01
    z[1,0,3]  R286      -0.0191778764128685
    z[1,0,3]  R287      -3.0335992574691772e-01
    z[1,0,3]  R288      2.6501855254173279e-01
    z[1,0,3]  R289      6.0697649605572224e-03
    z[1,0,3]  R290      1.4614929258823395e-01
    z[1,0,3]  R291      -2.5967705994844437e-02
    z[1,0,3]  R292      -3.8211518526077271e-01
    z[1,0,3]  R293      -5.6091696023941040e-01
    z[1,0,3]  R294      -9.1272346675395966e-02
    z[1,0,3]  R295      3.3846864104270935e-01
    z[1,0,3]  R296      3.7194166332483292e-02
    z[1,0,3]  R297      4.0260624140501022e-02
    z[1,0,3]  R298      -2.9305824637413025e-01
    z[1,0,3]  R299      0.207631453871727
    z[1,0,3]  R300      6.7774903774261475e-01
    z[1,0,3]  R301      -6.9623276591300964e-02
    z[1,0,3]  R302      -2.0771314203739166e-01
    z[1,0,3]  R303      -0.00696546770632267
    z[1,0,3]  R304      7.0355825126171112e-02
    z[1,0,3]  R305      4.4429653882980347e-01
    z[1,0,3]  R306      7.4754811823368073e-02
    z[1,0,3]  R307      1.6481418907642365e-01
    z[1,0,3]  R308      -2.6582974195480347e-01
    z[1,0,3]  R309      8.2485699653625488e-01
    z[1,0,3]  R310      5.0227355957031250e-01
    z[1,0,3]  R311      1.0876694321632385e-01
    z[1,0,3]  R312      1.2753970222547650e-03
    z[1,0,3]  R313      8.4732629358768463e-02
    z[1,0,3]  R314      6.2167018651962280e-01
    z[1,0,3]  R315      5.9127581119537354e-01
    z[1,0,3]  R316      -3.6739131808280945e-01
    z[1,0,3]  R317      2.9516467452049255e-01
    z[1,0,3]  R318      -1.0469325631856918e-01
    z[1,0,3]  R319      -1.3179023563861847e-01
    z[1,0,3]  R320      -4.7945481538772583e-01
    z[1,0,3]  R321      5.8445721864700317e-01
    z[1,0,3]  R322      4.0771072963252664e-04
    z[1,0,3]  R323      0.0796792060136795
    z[1,0,3]  R324      5.8450758457183838e-01
    z[1,0,3]  R325      -6.9646090269088745e-01
    z[1,0,3]  R326      3.2750996947288513e-01
    z[1,0,3]  R327      4.2184704542160034e-01
    z[1,0,3]  R328      -3.8457545638084412e-01
    z[1,0,3]  R329      -3.3123109489679337e-02
    z[1,0,3]  R330      -1.1977288126945496e-01
    z[1,0,3]  R331      -2.5463856291025877e-03
    z[1,0,3]  R332      2.8450268507003784e-01
    z[1,0,3]  R333      5.8854973316192627e-01
    z[1,0,3]  R334      -5.7986426353454590e-01
    z[1,0,3]  R335      -2.5151500478386879e-02
    z[1,0,3]  R336      3.2991883158683777e-01
    z[1,0,3]  R337      6.6927188634872437e-01
    z[1,0,3]  R338      2.9772832989692688e-01
    z[1,0,3]  R339      6.1433595418930054e-01
    z[1,0,3]  R340      4.2071422934532166e-01
    z[1,0,3]  R341      -1.9240427762269974e-02
    z[1,0,3]  R342      0.529548168182373
    z[1,0,3]  R343      -1.4083890616893768e-01
    z[1,0,3]  R344      1.3286863267421722e-01
    z[1,0,3]  R345      -3.0317762494087219e-01
    z[1,0,3]  R346      -3.6674609780311584e-01
    z[1,0,3]  R347      -2.2699026390910149e-02
    z[1,0,3]  R348      -3.8814797997474670e-01
    z[1,0,3]  R349      -0.373947411775589
    z[1,0,3]  R350      -2.1999992430210114e-01
    z[1,0,3]  R351      -1.5195679850876331e-02
    z[1,0,3]  R352      -3.1144765019416809e-01
    z[1,0,3]  R353      7.1903622150421143e-01
    z[1,0,3]  R354      2.5185352563858032e-01
    z[1,0,3]  R355      5.0359004735946655e-01
    z[1,0,3]  R356      7.3543775081634521e-01
    z[1,0,3]  R357      4.9513211846351624e-01
    z[1,0,3]  R358      -0.0909363180398941
    z[1,0,3]  R359      1.9417591392993927e-01
    z[1,0,3]  R360      1.8482092022895813e-01
    z[1,0,3]  R361      4.2545256018638611e-01
    z[1,0,3]  R362      -5.0914859771728516e-01
    z[1,0,3]  R363      4.2381274700164795e-01
    z[1,0,3]  R364      3.7916150689125061e-01
    z[1,0,3]  R365      3.7722736597061157e-01
    z[1,0,3]  R366      4.4775003194808960e-01
    z[1,0,3]  R367      -1.9667898304760456e-03
    z[1,0,3]  R368      1.3694278895854950e-01
    z[1,0,3]  R369      6.7721712589263916e-01
    z[1,0,3]  R370      4.9713057279586792e-01
    z[1,0,3]  R371      -2.2889813408255577e-02
    z[1,0,3]  R372      3.0973119661211967e-02
    z[1,0,3]  R373      -8.1840313971042633e-02
    z[1,0,3]  R374      1.0280106961727142e-01
    z[1,0,3]  R375      4.7158437967300415e-01
    z[1,0,3]  R376      -1.5477801859378815e-01
    z[1,0,3]  R377      -8.3408242464065552e-01
    z[1,0,3]  R378      -8.8260644674301147e-01
    z[1,0,3]  R379      -4.9218437075614929e-01
    z[1,0,3]  R380      3.1000250577926636e-01
    z[1,0,3]  R381      2.8603506088256836e-01
    z[1,0,3]  R382      -7.5672513246536255e-01
    z[1,0,3]  R383      -9.1456425189971924e-01
    z[1,0,3]  R384      2.2730968892574310e-01
    z[1,0,3]  R385      2.5798153132200241e-02
    z[1,0,3]  R386      -5.1111515611410141e-02
    z[1,0,3]  R387      1.7404921352863312e-01
    z[1,0,3]  R388      -1.2447923421859741e-01
    z[1,0,3]  R389      -2.0280398428440094e-01
    z[1,0,3]  R390      -9.4996467232704163e-02
    z[1,0,3]  R391      -3.3122873306274414e-01
    z[1,0,3]  R392      -2.6657733321189880e-01
    z[1,0,4]  R6        1
    z[1,0,4]  R15       -1
    z[1,0,4]  R237      -1
    z[1,0,4]  R238      1
    z[1,0,4]  R243      4.2370632290840149e-01
    z[1,0,4]  R244      1.8065446987748146e-02
    z[1,0,4]  R245      3.6739388108253479e-01
    z[1,0,4]  R246      5.8633655309677124e-01
    z[1,0,4]  R247      1.6537471115589142e-01
    z[1,0,4]  R248      1.6097468137741089e-01
    z[1,0,4]  R249      1.7848816514015198e-01
    z[1,0,4]  R250      2.6838836073875427e-01
    z[1,0,4]  R251      1.1645889282226562e-01
    z[1,0,4]  R252      2.9949453473091125e-01
    z[1,0,4]  R253      -1.5863038599491119e-01
    z[1,0,4]  R254      -2.0651364326477051e-01
    z[1,0,4]  R255      -3.7758240103721619e-01
    z[1,0,4]  R256      -8.3849288523197174e-02
    z[1,0,4]  R257      -5.0751942396163940e-01
    z[1,0,4]  R258      -9.4126991927623749e-02
    z[1,0,4]  R259      1.0345663875341415e-01
    z[1,0,4]  R260      -7.7445471286773682e-01
    z[1,0,4]  R261      -4.0884593129158020e-01
    z[1,0,4]  R262      -5.5066245794296265e-01
    z[1,0,4]  R263      -1.9226944446563721e-01
    z[1,0,4]  R264      2.1234290301799774e-01
    z[1,0,4]  R265      -2.9462394118309021e-01
    z[1,0,4]  R266      -4.5862805843353271e-01
    z[1,0,4]  R267      -2.9427188634872437e-01
    z[1,0,4]  R268      0.473821222782135
    z[1,0,4]  R269      1.7656306922435760e-01
    z[1,0,4]  R270      0.512280285358429
    z[1,0,4]  R271      1.8443444371223450e-01
    z[1,0,4]  R272      6.3173137605190277e-02
    z[1,0,4]  R273      -5.9691351652145386e-01
    z[1,0,4]  R274      -5.0122201442718506e-01
    z[1,0,4]  R275      -8.1298923492431641e-01
    z[1,0,4]  R276      4.1157731413841248e-01
    z[1,0,4]  R277      0.13089619576931
    z[1,0,4]  R278      1.8609413504600525e-01
    z[1,0,4]  R279      1.9791173934936523e-01
    z[1,0,4]  R280      -2.6141893118619919e-02
    z[1,0,4]  R281      7.1282177232205868e-03
    z[1,0,4]  R282      -5.2257917821407318e-02
    z[1,0,4]  R283      -3.5380131006240845e-01
    z[1,0,4]  R284      -6.8181025981903076e-01
    z[1,0,4]  R285      -3.4506028890609741e-01
    z[1,0,4]  R286      -1.3816542923450470e-01
    z[1,0,4]  R287      3.3916497230529785e-01
    z[1,0,4]  R288      -7.2195746004581451e-02
    z[1,0,4]  R289      9.0210400521755219e-02
    z[1,0,4]  R290      -2.2630941867828369e-01
    z[1,0,4]  R291      -1.1395063996315002e-01
    z[1,0,4]  R292      2.5320026278495789e-01
    z[1,0,4]  R293      -2.6496413350105286e-01
    z[1,0,4]  R294      1.2268720567226410e-01
    z[1,0,4]  R295      -0.516111433506012
    z[1,0,4]  R296      -7.7362522482872009e-02
    z[1,0,4]  R297      3.6041066050529480e-01
    z[1,0,4]  R298      1.6203403472900391e-02
    z[1,0,4]  R299      3.3967226743698120e-02
    z[1,0,4]  R300      -4.0043359994888306e-01
    z[1,0,4]  R301      2.4488031864166260e-01
    z[1,0,4]  R302      -2.7999168634414673e-01
    z[1,0,4]  R303      1.5323479473590851e-01
    z[1,0,4]  R304      2.2334653884172440e-02
    z[1,0,4]  R305      -1.8812276422977448e-01
    z[1,0,4]  R306      -2.4828863143920898e-01
    z[1,0,4]  R307      -1.6168478131294250e-01
    z[1,0,4]  R308      -1.5106610953807831e-01
    z[1,0,4]  R309      7.6155625283718109e-02
    z[1,0,4]  R310      4.5021429657936096e-02
    z[1,0,4]  R311      1.1790663003921509e-01
    z[1,0,4]  R312      3.5410594195127487e-02
    z[1,0,4]  R313      0.0838705375790596
    z[1,0,4]  R314      -1.5915378928184509e-01
    z[1,0,4]  R315      -5.2755761146545410e-01
    z[1,0,4]  R316      -2.4036690592765808e-01
    z[1,0,4]  R317      -5.0913745164871216e-01
    z[1,0,4]  R318      0.000716552953235805
    z[1,0,4]  R319      5.7074010372161865e-01
    z[1,0,4]  R320      -1.7616911232471466e-01
    z[1,0,4]  R321      4.8988372087478638e-02
    z[1,0,4]  R322      3.4998711943626404e-01
    z[1,0,4]  R323      2.0113010704517365e-01
    z[1,0,4]  R324      -1.8414147198200226e-01
    z[1,0,4]  R325      2.8846734762191772e-01
    z[1,0,4]  R326      -4.8386237025260925e-01
    z[1,0,4]  R327      -4.8561595380306244e-02
    z[1,0,4]  R328      -2.9330602288246155e-01
    z[1,0,4]  R329      -4.0362879633903503e-01
    z[1,0,4]  R330      -3.4878385066986084e-01
    z[1,0,4]  R331      -3.7716156244277954e-01
    z[1,0,4]  R332      -3.8579076528549194e-01
    z[1,0,4]  R333      -3.0203866958618164e-01
    z[1,0,4]  R334      4.6352226287126541e-02
    z[1,0,4]  R335      1.6870559751987457e-01
    z[1,0,4]  R336      -2.5287646055221558e-01
    z[1,0,4]  R337      -1.5198273956775665e-01
    z[1,0,4]  R338      -2.8569018840789795e-01
    z[1,0,4]  R339      -1.9161500036716461e-01
    z[1,0,4]  R340      -2.7352344989776611e-01
    z[1,0,4]  R341      -2.6284396648406982e-01
    z[1,0,4]  R342      -1.8524785339832306e-01
    z[1,0,4]  R343      -6.8540310859680176e-01
    z[1,0,4]  R344      -6.5990060567855835e-01
    z[1,0,4]  R345      -6.2889808416366577e-01
    z[1,0,4]  R346      -2.1133351325988770e-01
    z[1,0,4]  R347      -8.2144963741302490e-01
    z[1,0,4]  R348      -4.4403173960745335e-03
    z[1,0,4]  R349      2.0590825378894806e-01
    z[1,0,4]  R350      2.5579905509948730e-01
    z[1,0,4]  R351      1.1942632496356964e-01
    z[1,0,4]  R352      -5.9767484664916992e-02
    z[1,0,4]  R353      -9.8800763487815857e-02
    z[1,0,4]  R354      0.721690833568573
    z[1,0,4]  R355      2.2953312098979950e-01
    z[1,0,4]  R356      0.0649818480014801
    z[1,0,4]  R357      1.4219713211059570e-01
    z[1,0,4]  R358      2.5511008501052856e-01
    z[1,0,4]  R359      3.0260652303695679e-01
    z[1,0,4]  R360      4.7169774770736694e-01
    z[1,0,4]  R361      -8.0509938299655914e-02
    z[1,0,4]  R362      -2.5258013606071472e-01
    z[1,0,4]  R363      -2.5747594237327576e-01
    z[1,0,4]  R364      1.4884701371192932e-01
    z[1,0,4]  R365      -3.3828923106193542e-01
    z[1,0,4]  R366      1.8099553883075714e-01
    z[1,0,4]  R367      -8.2265391945838928e-02
    z[1,0,4]  R368      8.9658334851264954e-02
    z[1,0,4]  R369      -4.6158339828252792e-02
    z[1,0,4]  R370      -4.5031303167343140e-01
    z[1,0,4]  R371      2.3909020423889160e-01
    z[1,0,4]  R372      2.5913387537002563e-01
    z[1,0,4]  R373      1.4467741549015045e-01
    z[1,0,4]  R374      -5.0215190649032593e-01
    z[1,0,4]  R375      -5.0982785224914551e-01
    z[1,0,4]  R376      0.330519437789917
    z[1,0,4]  R377      3.7079009413719177e-01
    z[1,0,4]  R378      2.2420334815979004e-01
    z[1,0,4]  R379      8.6895991116762161e-03
    z[1,0,4]  R380      1.1299183219671249e-01
    z[1,0,4]  R381      1.9198693335056305e-01
    z[1,0,4]  R382      3.3922556042671204e-01
    z[1,0,4]  R383      1.6213682293891907e-01
    z[1,0,4]  R384      4.4171714782714844e-01
    z[1,0,4]  R385      -1.3314799405634403e-02
    z[1,0,4]  R386      -1.9462814927101135e-01
    z[1,0,4]  R387      -1.4693741500377655e-01
    z[1,0,4]  R388      9.6453763544559479e-02
    z[1,0,4]  R389      -2.9710020869970322e-02
    z[1,0,4]  R390      3.5078969597816467e-01
    z[1,0,4]  R391      -1.6486944258213043e-01
    z[1,0,4]  R392      -0.0299517959356308
    z[1,0,5]  R7        1
    z[1,0,5]  R16       -1
    z[1,0,5]  R239      -1
    z[1,0,5]  R240      1
    z[1,0,5]  R243      -1.0683242231607437e-02
    z[1,0,5]  R244      4.4384026527404785e-01
    z[1,0,5]  R245      5.6114387512207031e-01
    z[1,0,5]  R246      2.2153569757938385e-01
    z[1,0,5]  R247      0.0785888135433197
    z[1,0,5]  R248      -2.0154097676277161e-01
    z[1,0,5]  R249      -1.4973272383213043e-01
    z[1,0,5]  R250      -2.0013237372040749e-02
    z[1,0,5]  R251      1.4452475309371948e-01
    z[1,0,5]  R252      1.1037625372409821e-01
    z[1,0,5]  R253      1.5011714398860931e-01
    z[1,0,5]  R254      1.9484703242778778e-01
    z[1,0,5]  R255      4.0779468417167664e-01
    z[1,0,5]  R256      -3.6305990815162659e-01
    z[1,0,5]  R257      -1.8814601004123688e-01
    z[1,0,5]  R258      2.2578341886401176e-02
    z[1,0,5]  R259      4.0209281444549561e-01
    z[1,0,5]  R260      -2.2305153310298920e-01
    z[1,0,5]  R261      -3.4657639265060425e-01
    z[1,0,5]  R262      1.3650451600551605e-01
    z[1,0,5]  R263      -1.4910818636417389e-01
    z[1,0,5]  R264      -5.7941582053899765e-02
    z[1,0,5]  R265      -4.3500947952270508e-01
    z[1,0,5]  R266      1.2846945226192474e-01
    z[1,0,5]  R267      -1.9584308564662933e-01
    z[1,0,5]  R268      5.0724223256111145e-03
    z[1,0,5]  R269      -3.4511899948120117e-01
    z[1,0,5]  R270      -5.1498431712388992e-03
    z[1,0,5]  R271      4.2048788070678711e-01
    z[1,0,5]  R272      -0.248139888048172
    z[1,0,5]  R273      -2.2326861321926117e-01
    z[1,0,5]  R274      -1.4089688658714294e-01
    z[1,0,5]  R275      -3.5816648602485657e-01
    z[1,0,5]  R276      -1.9831705838441849e-02
    z[1,0,5]  R277      -2.8302398324012756e-01
    z[1,0,5]  R278      -2.6607608795166016e-01
    z[1,0,5]  R279      -9.3816900625824928e-03
    z[1,0,5]  R280      -0.00913193728774786
    z[1,0,5]  R281      -3.4307509660720825e-01
    z[1,0,5]  R282      1.3647709786891937e-01
    z[1,0,5]  R283      2.2741788998246193e-02
    z[1,0,5]  R284      4.9062767624855042e-01
    z[1,0,5]  R285      4.5953061431646347e-02
    z[1,0,5]  R286      -1.4729671180248260e-01
    z[1,0,5]  R287      -2.3401673138141632e-01
    z[1,0,5]  R288      4.9856898188591003e-01
    z[1,0,5]  R289      2.8222987055778503e-01
    z[1,0,5]  R290      -9.2234506155364215e-05
    z[1,0,5]  R291      -2.2545018792152405e-01
    z[1,0,5]  R292      4.0567898750305176e-01
    z[1,0,5]  R293      -1.1036479473114014e-01
    z[1,0,5]  R294      2.5438693165779114e-01
    z[1,0,5]  R295      -1.0560341179370880e-01
    z[1,0,5]  R296      4.6336323022842407e-01
    z[1,0,5]  R297      4.7741317749023438e-01
    z[1,0,5]  R298      -5.3843200206756592e-01
    z[1,0,5]  R299      -2.3436771705746651e-02
    z[1,0,5]  R300      3.7715956568717957e-01
    z[1,0,5]  R301      -0.510245680809021
    z[1,0,5]  R302      1.1509119719266891e-01
    z[1,0,5]  R303      -6.6956095397472382e-02
    z[1,0,5]  R304      4.1354256868362427e-01
    z[1,0,5]  R305      -0.234359011054039
    z[1,0,5]  R306      1.6112641990184784e-01
    z[1,0,5]  R307      1.0046856850385666e-01
    z[1,0,5]  R308      1.0830528289079666e-01
    z[1,0,5]  R309      1.3350382447242737e-01
    z[1,0,5]  R310      8.2315705716609955e-02
    z[1,0,5]  R311      4.7807514667510986e-02
    z[1,0,5]  R312      -1.8564681708812714e-01
    z[1,0,5]  R313      3.8254481554031372e-01
    z[1,0,5]  R314      4.2950016260147095e-01
    z[1,0,5]  R315      4.4323410838842392e-02
    z[1,0,5]  R316      -3.0888348817825317e-01
    z[1,0,5]  R317      -1.7003257572650909e-01
    z[1,0,5]  R318      -2.1060745418071747e-01
    z[1,0,5]  R319      -2.8826245665550232e-01
    z[1,0,5]  R320      -3.1406667828559875e-01
    z[1,0,5]  R321      -4.2162844538688660e-01
    z[1,0,5]  R322      -2.5881221890449524e-01
    z[1,0,5]  R323      3.3505931496620178e-01
    z[1,0,5]  R324      4.9329307675361633e-01
    z[1,0,5]  R325      1.1204126477241516e-01
    z[1,0,5]  R326      2.9471702873706818e-03
    z[1,0,5]  R327      5.1336448639631271e-02
    z[1,0,5]  R328      -1.6353687644004822e-01
    z[1,0,5]  R329      -3.7536349147558212e-02
    z[1,0,5]  R330      -4.7130686044692993e-01
    z[1,0,5]  R331      1.5334385633468628e-01
    z[1,0,5]  R332      -2.6177048683166504e-02
    z[1,0,5]  R333      5.0096571445465088e-01
    z[1,0,5]  R334      -2.0492132753133774e-02
    z[1,0,5]  R335      2.4650931358337402e-01
    z[1,0,5]  R336      3.1349015235900879e-01
    z[1,0,5]  R337      -1.9713032990694046e-02
    z[1,0,5]  R338      3.5099261999130249e-01
    z[1,0,5]  R339      1.7596293985843658e-01
    z[1,0,5]  R340      0.315409392118454
    z[1,0,5]  R341      -4.4421949982643127e-01
    z[1,0,5]  R342      8.2742515951395035e-03
    z[1,0,5]  R343      4.6116065979003906e-01
    z[1,0,5]  R344      5.4654383659362793e-01
    z[1,0,5]  R345      1.3602770864963531e-01
    z[1,0,5]  R346      8.8637866079807281e-02
    z[1,0,5]  R347      3.6333236098289490e-01
    z[1,0,5]  R348      7.3513254523277283e-02
    z[1,0,5]  R349      1.3788402080535889e-01
    z[1,0,5]  R350      6.0341589152812958e-02
    z[1,0,5]  R351      -1.3995829224586487e-01
    z[1,0,5]  R352      1.3770771026611328e-01
    z[1,0,5]  R353      -2.8934234380722046e-01
    z[1,0,5]  R354      -2.0392332226037979e-02
    z[1,0,5]  R355      -3.6336994171142578e-01
    z[1,0,5]  R356      -2.1523636579513550e-01
    z[1,0,5]  R357      -4.4337805360555649e-02
    z[1,0,5]  R358      5.9535790234804153e-02
    z[1,0,5]  R359      -1.4216606318950653e-01
    z[1,0,5]  R360      1.1818820238113403e-01
    z[1,0,5]  R361      -2.3110084235668182e-02
    z[1,0,5]  R362      -6.1451215296983719e-02
    z[1,0,5]  R363      -2.3863169550895691e-01
    z[1,0,5]  R364      2.8609130531549454e-03
    z[1,0,5]  R365      -3.4703877568244934e-01
    z[1,0,5]  R366      -8.0513760447502136e-02
    z[1,0,5]  R367      -2.5317358970642090e-01
    z[1,0,5]  R368      -0.0852438285946846
    z[1,0,5]  R369      -1.1414396017789841e-01
    z[1,0,5]  R370      -3.7345707416534424e-01
    z[1,0,5]  R371      -1.8260811269283295e-01
    z[1,0,5]  R372      1.8850685656070709e-01
    z[1,0,5]  R373      -3.1865498423576355e-01
    z[1,0,5]  R374      -6.2541222572326660e-01
    z[1,0,5]  R375      -4.9563441425561905e-02
    z[1,0,5]  R376      2.4108274281024933e-01
    z[1,0,5]  R377      -8.9520506560802460e-02
    z[1,0,5]  R378      -4.5341745018959045e-02
    z[1,0,5]  R379      3.4138467907905579e-01
    z[1,0,5]  R380      1.6713395714759827e-01
    z[1,0,5]  R381      5.1403380930423737e-02
    z[1,0,5]  R382      -1.7885808646678925e-01
    z[1,0,5]  R383      -1.5099354088306427e-01
    z[1,0,5]  R384      -3.3542364835739136e-02
    z[1,0,5]  R385      4.2033061385154724e-01
    z[1,0,5]  R386      -3.2964695245027542e-02
    z[1,0,5]  R387      -2.6514637470245361e-01
    z[1,0,5]  R388      1.6184569895267487e-01
    z[1,0,5]  R389      2.8925737738609314e-01
    z[1,0,5]  R390      -1.4822500944137573e-01
    z[1,0,5]  R391      -0.074454665184021
    z[1,0,5]  R392      1.5261600911617279e-01
    z[1,0,6]  R8        1
    z[1,0,6]  R17       -1
    z[1,0,6]  R241      -1
    z[1,0,6]  R242      1
    z[1,0,6]  R243      1.6781672835350037e-01
    z[1,0,6]  R244      1.5728285908699036e-01
    z[1,0,6]  R245      -0.212831050157547
    z[1,0,6]  R246      1.1290422827005386e-01
    z[1,0,6]  R247      -2.0314763486385345e-01
    z[1,0,6]  R248      -2.0503292977809906e-01
    z[1,0,6]  R249      -2.0527285337448120e-01
    z[1,0,6]  R250      7.4418224394321442e-02
    z[1,0,6]  R251      -5.1902536302804947e-02
    z[1,0,6]  R252      1.1466937512159348e-01
    z[1,0,6]  R253      -3.8242095708847046e-01
    z[1,0,6]  R254      -0.123700812458992
    z[1,0,6]  R255      4.4131819158792496e-02
    z[1,0,6]  R256      2.0914927124977112e-01
    z[1,0,6]  R257      -1.5266370773315430e-01
    z[1,0,6]  R258      4.7503036260604858e-01
    z[1,0,6]  R259      -2.6302579045295715e-01
    z[1,0,6]  R260      -1.5337653458118439e-01
    z[1,0,6]  R261      3.7807431817054749e-01
    z[1,0,6]  R262      2.7391368150711060e-01
    z[1,0,6]  R263      2.6329910382628441e-02
    z[1,0,6]  R264      7.0679372549057007e-01
    z[1,0,6]  R265      4.6605333685874939e-02
    z[1,0,6]  R266      -3.4513169527053833e-01
    z[1,0,6]  R267      5.8406114578247070e-01
    z[1,0,6]  R268      -1.3775852508842945e-02
    z[1,0,6]  R269      -1.3469657301902771e-01
    z[1,0,6]  R270      6.3891232013702393e-02
    z[1,0,6]  R271      2.4693049490451813e-01
    z[1,0,6]  R272      2.5733673572540283e-01
    z[1,0,6]  R273      5.1083713769912720e-01
    z[1,0,6]  R274      4.4374740123748779e-01
    z[1,0,6]  R275      1.5302394330501556e-01
    z[1,0,6]  R276      -1.9526831805706024e-01
    z[1,0,6]  R277      -2.2403992712497711e-01
    z[1,0,6]  R278      -2.3340111970901489e-01
    z[1,0,6]  R279      4.2828115820884705e-01
    z[1,0,6]  R280      2.6880177855491638e-01
    z[1,0,6]  R281      2.2382782399654388e-01
    z[1,0,6]  R282      3.6712527275085449e-01
    z[1,0,6]  R283      4.4752866029739380e-01
    z[1,0,6]  R284      1.1494905501604080e-01
    z[1,0,6]  R285      1.8742652237415314e-01
    z[1,0,6]  R286      -2.2395202517509460e-01
    z[1,0,6]  R287      2.3580574989318848e-01
    z[1,0,6]  R288      1.2304235994815826e-01
    z[1,0,6]  R289      2.9824849218130112e-02
    z[1,0,6]  R290      2.2685025632381439e-01
    z[1,0,6]  R291      -9.2453166842460632e-02
    z[1,0,6]  R292      5.9650313109159470e-02
    z[1,0,6]  R293      0.196893572807312
    z[1,0,6]  R294      -1.2163080275058746e-01
    z[1,0,6]  R295      -5.5359661579132080e-01
    z[1,0,6]  R296      0.301082581281662
    z[1,0,6]  R297      1.8784141540527344e-01
    z[1,0,6]  R298      2.5613343715667725e-01
    z[1,0,6]  R299      -1.7376577854156494e-01
    z[1,0,6]  R300      1.1973126232624054e-01
    z[1,0,6]  R301      1.3432615995407104e-01
    z[1,0,6]  R302      1.5900996327400208e-01
    z[1,0,6]  R303      8.2109540700912476e-02
    z[1,0,6]  R304      3.1177085638046265e-01
    z[1,0,6]  R305      9.5916397869586945e-02
    z[1,0,6]  R306      -1.2706008553504944e-01
    z[1,0,6]  R307      -3.4822601079940796e-01
    z[1,0,6]  R308      1.3286796212196350e-01
    z[1,0,6]  R309      -2.3847262561321259e-01
    z[1,0,6]  R310      -7.5521886348724365e-02
    z[1,0,6]  R311      4.7048706561326981e-02
    z[1,0,6]  R312      -9.0640291571617126e-02
    z[1,0,6]  R313      2.1592923998832703e-01
    z[1,0,6]  R314      9.9643588066101074e-02
    z[1,0,6]  R315      -1.5728241205215454e-01
    z[1,0,6]  R316      1.2270531058311462e-01
    z[1,0,6]  R317      -2.2878400981426239e-01
    z[1,0,6]  R318      2.3199106752872467e-01
    z[1,0,6]  R319      -0.0837583988904953
    z[1,0,6]  R320      -1.3407164812088013e-01
    z[1,0,6]  R321      1.3882575929164886e-01
    z[1,0,6]  R322      -5.1358896493911743e-01
    z[1,0,6]  R323      2.2299818694591522e-01
    z[1,0,6]  R324      1.8443956971168518e-01
    z[1,0,6]  R325      -6.9723889231681824e-02
    z[1,0,6]  R326      -1.9082710146903992e-01
    z[1,0,6]  R327      -6.0413774102926254e-02
    z[1,0,6]  R328      -1.6859705746173859e-01
    z[1,0,6]  R329      8.4657423198223114e-02
    z[1,0,6]  R330      -2.8084853291511536e-01
    z[1,0,6]  R331      -1.8471510848030448e-03
    z[1,0,6]  R332      -5.2542369812726974e-03
    z[1,0,6]  R333      1.1301857233047485e-01
    z[1,0,6]  R334      1.4101485908031464e-01
    z[1,0,6]  R335      -2.0797398686408997e-01
    z[1,0,6]  R336      -1.3379167020320892e-01
    z[1,0,6]  R337      -2.0895868539810181e-02
    z[1,0,6]  R338      -5.8076906949281693e-02
    z[1,0,6]  R339      5.0957348197698593e-02
    z[1,0,6]  R340      1.7451328039169312e-01
    z[1,0,6]  R341      3.5186418890953064e-01
    z[1,0,6]  R342      -2.1904313564300537e-01
    z[1,0,6]  R343      -8.2849457859992981e-02
    z[1,0,6]  R344      -1.8272195756435394e-01
    z[1,0,6]  R345      2.8193622827529907e-02
    z[1,0,6]  R346      -1.0989258438348770e-01
    z[1,0,6]  R347      3.0912297964096069e-01
    z[1,0,6]  R348      -1.7003765329718590e-02
    z[1,0,6]  R349      8.9599706232547760e-02
    z[1,0,6]  R350      3.8631439208984375e-01
    z[1,0,6]  R351      9.9594242870807648e-02
    z[1,0,6]  R352      3.9882853627204895e-01
    z[1,0,6]  R353      -1.9392198324203491e-01
    z[1,0,6]  R354      -2.1297354996204376e-01
    z[1,0,6]  R355      -1.1866380274295807e-01
    z[1,0,6]  R356      -1.7210614681243896e-01
    z[1,0,6]  R357      2.8479138016700745e-01
    z[1,0,6]  R358      0.158565953373909
    z[1,0,6]  R359      1.6385369002819061e-01
    z[1,0,6]  R360      -6.5212212502956390e-02
    z[1,0,6]  R361      1.6607193648815155e-01
    z[1,0,6]  R362      -3.8209420442581177e-01
    z[1,0,6]  R363      2.0963855087757111e-02
    z[1,0,6]  R364      -9.7138516604900360e-02
    z[1,0,6]  R365      1.5419182181358337e-01
    z[1,0,6]  R366      -2.4525739252567291e-01
    z[1,0,6]  R367      -1.9927522540092468e-01
    z[1,0,6]  R368      3.6211568117141724e-01
    z[1,0,6]  R369      -2.1221902966499329e-01
    z[1,0,6]  R370      -2.3844359815120697e-01
    z[1,0,6]  R371      3.1876003742218018e-01
    z[1,0,6]  R372      1.4437088370323181e-01
    z[1,0,6]  R373      2.4518595635890961e-01
    z[1,0,6]  R374      0.22120301425457
    z[1,0,6]  R375      2.5697039440274239e-02
    z[1,0,6]  R376      -3.0606296658515930e-01
    z[1,0,6]  R377      -5.0941254943609238e-02
    z[1,0,6]  R378      -1.0018956847488880e-02
    z[1,0,6]  R379      -0.314046174287796
    z[1,0,6]  R380      1.0457421094179153e-01
    z[1,0,6]  R381      -4.0676867961883545e-01
    z[1,0,6]  R382      1.7006288468837738e-01
    z[1,0,6]  R383      -0.0994422510266304
    z[1,0,6]  R384      -2.5032436847686768e-01
    z[1,0,6]  R385      2.5631364434957504e-02
    z[1,0,6]  R386      -2.2855636198073626e-03
    z[1,0,6]  R387      -2.0104375481605530e-01
    z[1,0,6]  R388      -1.3333666324615479e-01
    z[1,0,6]  R389      -1.4793017506599426e-01
    z[1,0,6]  R390      1.5221193432807922e-02
    z[1,0,6]  R391      1.8041402101516724e-01
    z[1,0,6]  R392      2.4068281054496765e-01
    z[0,4,0]  R2        -1
    z[0,4,0]  R38       1
    z[0,4,0]  R393      -1
    z[0,4,0]  R394      1
    z[0,4,0]  R407      1.6584175825119019e-01
    z[0,4,0]  R408      -0.0663711279630661
    z[0,4,0]  R409      1.1949385702610016e-01
    z[0,4,0]  R410      1.9378165900707245e-01
    z[0,4,0]  R411      4.3577592819929123e-02
    z[0,4,0]  R412      9.0140420198440552e-01
    z[0,4,0]  R413      8.1452596187591553e-01
    z[0,4,0]  R414      8.2104223966598511e-01
    z[0,4,0]  R415      9.7160762548446655e-01
    z[0,4,0]  R416      8.1599676609039307e-01
    z[0,4,0]  R417      1.9828332960605621e-01
    z[0,4,0]  R418      -4.4695755839347839e-01
    z[0,4,0]  R419      1.6230948269367218e-01
    z[0,4,0]  R420      -3.4789907932281494e-01
    z[0,4,0]  R421      -4.4342020153999329e-01
    z[0,4,0]  R422      -8.9742016792297363e-01
    z[0,4,0]  R423      -8.4654372930526733e-01
    z[0,4,0]  R424      -8.3944803476333618e-01
    z[0,4,0]  R425      -7.8399944305419922e-01
    z[0,4,0]  R426      -3.5530397295951843e-01
    z[0,4,0]  R427      -5.4938018321990967e-01
    z[0,4,0]  R428      4.9426622688770294e-02
    z[0,4,0]  R429      -6.1445814371109009e-01
    z[0,4,0]  R430      -4.0386113524436951e-01
    z[0,4,0]  R431      -4.9271425604820251e-01
    z[0,4,0]  R432      1.2376247346401215e-01
    z[0,4,0]  R433      -1.5954676270484924e-01
    z[0,4,0]  R434      4.6899044513702393e-01
    z[0,4,0]  R435      -5.2462047338485718e-01
    z[0,4,0]  R436      -6.4716976881027222e-01
    z[0,4,0]  R437      -2.0606555044651031e-01
    z[0,4,0]  R438      -1.5359888970851898e-01
    z[0,4,0]  R439      4.3930616974830627e-01
    z[0,4,0]  R440      -5.3720917552709579e-02
    z[0,4,0]  R441      -2.1099595725536346e-01
    z[0,4,0]  R442      -3.9522945880889893e-01
    z[0,4,0]  R443      -1.4909274876117706e-01
    z[0,4,0]  R444      -0.791441798210144
    z[0,4,0]  R445      -7.3082339763641357e-01
    z[0,4,0]  R446      -4.1452351212501526e-01
    z[0,4,0]  R447      -2.9931643605232239e-01
    z[0,4,0]  R448      -7.7392721176147461e-01
    z[0,4,0]  R449      -0.832425057888031
    z[0,4,0]  R450      -4.8705756664276123e-01
    z[0,4,0]  R451      -5.5040019750595093e-01
    z[0,4,0]  R452      -4.6058323979377747e-01
    z[0,4,0]  R453      -4.6979156136512756e-01
    z[0,4,0]  R454      -7.4821233749389648e-01
    z[0,4,0]  R455      -0.479658305644989
    z[0,4,0]  R456      -4.6973422169685364e-01
    z[0,4,0]  R457      -5.7847633957862854e-02
    z[0,4,0]  R458      2.3291967809200287e-01
    z[0,4,0]  R459      1.9032852351665497e-01
    z[0,4,0]  R460      1.0687439143657684e-01
    z[0,4,0]  R461      1.2337212264537811e-01
    z[0,4,0]  R462      -1.5379829704761505e-01
    z[0,4,0]  R463      0.612011730670929
    z[0,4,0]  R464      -2.5405046343803406e-01
    z[0,4,0]  R465      -1.7137020826339722e-01
    z[0,4,0]  R466      5.9136056900024414e-01
    z[0,4,0]  R467      -3.8787201046943665e-01
    z[0,4,0]  R468      -1.7020131647586823e-01
    z[0,4,0]  R469      -1.3619169592857361e-01
    z[0,4,0]  R470      4.5985409617424011e-01
    z[0,4,0]  R471      1.5315456688404083e-01
    z[0,4,0]  R472      3.9971357583999634e-01
    z[0,4,0]  R473      3.3082881569862366e-01
    z[0,4,0]  R474      -1.5886427462100983e-01
    z[0,4,0]  R475      2.4377131462097168e-01
    z[0,4,0]  R476      -9.3194320797920227e-02
    z[0,4,0]  R477      -1.2749305367469788e-01
    z[0,4,0]  R478      -3.3869582414627075e-01
    z[0,4,0]  R479      -3.0979645252227783e-01
    z[0,4,0]  R480      4.6450782567262650e-02
    z[0,4,0]  R481      -5.0778716802597046e-01
    z[0,4,0]  R482      -4.2351409792900085e-01
    z[0,4,0]  R483      -2.8360605239868164e-01
    z[0,4,0]  R484      5.3043287992477417e-01
    z[0,4,0]  R485      5.4679775238037109e-01
    z[0,4,0]  R486      4.1538336873054504e-01
    z[0,4,0]  R487      -3.4991261363029480e-01
    z[0,4,0]  R488      -6.5750330686569214e-02
    z[0,4,0]  R489      6.4677906036376953e-01
    z[0,4,0]  R490      2.2338490188121796e-01
    z[0,4,0]  R491      2.0899084210395813e-01
    z[0,4,0]  R492      5.5733382701873779e-01
    z[0,4,0]  R493      8.4454685449600220e-01
    z[0,4,0]  R494      3.7446701526641846e-01
    z[0,4,0]  R495      7.4645286798477173e-01
    z[0,4,0]  R496      4.8767754435539246e-01
    z[0,4,0]  R497      3.3604595810174942e-02
    z[0,4,0]  R498      5.7812124490737915e-01
    z[0,4,0]  R499      8.7086832523345947e-01
    z[0,4,0]  R500      -2.4377760291099548e-01
    z[0,4,0]  R501      5.2036845684051514e-01
    z[0,4,0]  R502      6.8450921773910522e-01
    z[0,4,0]  R503      -1.7482032999396324e-03
    z[0,4,0]  R504      4.1061496734619141e-01
    z[0,4,0]  R505      -8.1347328424453735e-01
    z[0,4,0]  R506      -7.9426652193069458e-01
    z[0,4,0]  R507      -1.0821318626403809e-01
    z[0,4,0]  R508      -6.9208703935146332e-02
    z[0,4,0]  R509      -3.2698172330856323e-01
    z[0,4,0]  R510      -0.609432578086853
    z[0,4,0]  R511      -6.8806296586990356e-01
    z[0,4,0]  R512      -8.0902999639511108e-01
    z[0,4,0]  R513      -4.1726133227348328e-01
    z[0,4,0]  R514      -3.1601142883300781e-01
    z[0,4,0]  R515      -0.582899808883667
    z[0,4,1]  R3        -1
    z[0,4,1]  R39       1
    z[0,4,1]  R395      -1
    z[0,4,1]  R396      1
    z[0,4,1]  R407      -8.0154515802860260e-02
    z[0,4,1]  R408      -1.8110516667366028e-01
    z[0,4,1]  R409      1.2446816544979811e-03
    z[0,4,1]  R410      -2.5708785653114319e-01
    z[0,4,1]  R411      -2.1594421565532684e-01
    z[0,4,1]  R412      -1.6137482225894928e-01
    z[0,4,1]  R413      0.0124838100746274
    z[0,4,1]  R414      -2.2792570292949677e-01
    z[0,4,1]  R415      5.5811285972595215e-02
    z[0,4,1]  R416      -1.4057861268520355e-01
    z[0,4,1]  R417      -5.1473462581634521e-01
    z[0,4,1]  R418      -4.1156825423240662e-01
    z[0,4,1]  R419      -7.2181558609008789e-01
    z[0,4,1]  R420      -5.0044882297515869e-01
    z[0,4,1]  R421      -4.8834976553916931e-01
    z[0,4,1]  R422      3.0170795321464539e-01
    z[0,4,1]  R423      -2.7758213877677917e-01
    z[0,4,1]  R424      8.4900282323360443e-02
    z[0,4,1]  R425      1.8939383327960968e-01
    z[0,4,1]  R426      -4.7070616483688354e-01
    z[0,4,1]  R427      -4.6050909161567688e-01
    z[0,4,1]  R428      -8.8417333364486694e-01
    z[0,4,1]  R429      -2.8729760646820068e-01
    z[0,4,1]  R430      -6.2607473134994507e-01
    z[0,4,1]  R431      -7.9398363828659058e-01
    z[0,4,1]  R432      -9.0427374839782715e-01
    z[0,4,1]  R433      -6.6911959648132324e-01
    z[0,4,1]  R434      -3.4406265616416931e-01
    z[0,4,1]  R435      -5.9844875335693359e-01
    z[0,4,1]  R436      -5.7142537832260132e-01
    z[0,4,1]  R437      -6.6057282686233521e-01
    z[0,4,1]  R438      -1.2760999798774719e-01
    z[0,4,1]  R439      -5.6027692556381226e-01
    z[0,4,1]  R440      -5.0797986984252930e-01
    z[0,4,1]  R441      3.2867971062660217e-01
    z[0,4,1]  R442      8.6333960294723511e-02
    z[0,4,1]  R443      -4.6954333782196045e-01
    z[0,4,1]  R444      2.3565386235713959e-01
    z[0,4,1]  R445      4.2102980613708496e-01
    z[0,4,1]  R446      -1.0445768386125565e-01
    z[0,4,1]  R447      -1.2167669832706451e-01
    z[0,4,1]  R448      2.9350259900093079e-01
    z[0,4,1]  R449      3.5589879751205444e-01
    z[0,4,1]  R450      8.3448427915573120e-01
    z[0,4,1]  R451      7.3100918531417847e-01
    z[0,4,1]  R452      8.1843090057373047e-01
    z[0,4,1]  R453      7.9347169399261475e-01
    z[0,4,1]  R454      1.4243361353874207e-01
    z[0,4,1]  R455      7.6907247304916382e-01
    z[0,4,1]  R456      7.3240584135055542e-01
    z[0,4,1]  R457      -2.2434207797050476e-01
    z[0,4,1]  R458      -4.1379917412996292e-02
    z[0,4,1]  R459      -4.6656742691993713e-02
    z[0,4,1]  R460      -1.2432451546192169e-01
    z[0,4,1]  R461      -7.1573257446289062e-02
    z[0,4,1]  R462      5.6521035730838776e-02
    z[0,4,1]  R463      -3.6553180217742920e-01
    z[0,4,1]  R464      -8.5622303187847137e-02
    z[0,4,1]  R465      0.0456363670527935
    z[0,4,1]  R466      -2.4456253647804260e-01
    z[0,4,1]  R467      8.4129935503005981e-01
    z[0,4,1]  R468      8.6757284402847290e-01
    z[0,4,1]  R469      8.4425538778305054e-01
    z[0,4,1]  R470      -4.5689931511878967e-01
    z[0,4,1]  R471      -7.9187095165252686e-01
    z[0,4,1]  R472      2.4552106857299805e-01
    z[0,4,1]  R473      -9.0515814721584320e-02
    z[0,4,1]  R474      -3.9412230253219604e-01
    z[0,4,1]  R475      -6.0985791683197021e-01
    z[0,4,1]  R476      -6.7751926183700562e-01
    z[0,4,1]  R477      -6.6503608226776123e-01
    z[0,4,1]  R478      -7.6249647140502930e-01
    z[0,4,1]  R479      -6.5101730823516846e-01
    z[0,4,1]  R480      -7.9949998855590820e-01
    z[0,4,1]  R481      -5.5410587787628174e-01
    z[0,4,1]  R482      -0.576320469379425
    z[0,4,1]  R483      -7.7463120222091675e-01
    z[0,4,1]  R484      2.1554206311702728e-01
    z[0,4,1]  R485      -0.500268816947937
    z[0,4,1]  R486      -6.4946311712265015e-01
    z[0,4,1]  R487      -3.6966410279273987e-01
    z[0,4,1]  R488      -5.5434852838516235e-01
    z[0,4,1]  R489      -5.8023804426193237e-01
    z[0,4,1]  R490      1.1254636943340302e-01
    z[0,4,1]  R491      1.1817237734794617e-01
    z[0,4,1]  R492      -2.1881256997585297e-01
    z[0,4,1]  R493      -8.0024182796478271e-02
    z[0,4,1]  R494      -2.2036722302436829e-01
    z[0,4,1]  R495      3.2096442580223083e-01
    z[0,4,1]  R496      -7.2960913181304932e-01
    z[0,4,1]  R497      -7.2324448823928833e-01
    z[0,4,1]  R498      -5.4733687639236450e-01
    z[0,4,1]  R499      -2.4741439521312714e-01
    z[0,4,1]  R500      -4.4586917757987976e-01
    z[0,4,1]  R501      -5.3672641515731812e-01
    z[0,4,1]  R502      -2.4713842570781708e-01
    z[0,4,1]  R503      -8.9190351963043213e-01
    z[0,4,1]  R504      3.3194816112518311e-01
    z[0,4,1]  R505      3.5491049289703369e-01
    z[0,4,1]  R506      0.244643896818161
    z[0,4,1]  R507      -3.2988885045051575e-01
    z[0,4,1]  R508      -6.9191831350326538e-01
    z[0,4,1]  R509      -8.0293434858322144e-01
    z[0,4,1]  R510      -5.7155334949493408e-01
    z[0,4,1]  R511      -4.9672827124595642e-01
    z[0,4,1]  R512      -2.3610962927341461e-01
    z[0,4,1]  R513      1.0668906569480896e-01
    z[0,4,1]  R514      1.1416645348072052e-01
    z[0,4,1]  R515      2.0661045610904694e-01
    z[0,4,2]  R4        -1
    z[0,4,2]  R40       1
    z[0,4,2]  R397      -1
    z[0,4,2]  R398      1
    z[0,4,2]  R407      -0.506878137588501
    z[0,4,2]  R408      -4.2139717936515808e-01
    z[0,4,2]  R409      -6.9209235906600952e-01
    z[0,4,2]  R410      -8.3501911163330078e-01
    z[0,4,2]  R411      -2.2046999633312225e-01
    z[0,4,2]  R412      -7.1110002696514130e-02
    z[0,4,2]  R413      3.5653421282768250e-01
    z[0,4,2]  R414      8.5008360445499420e-02
    z[0,4,2]  R415      -0.0941428393125534
    z[0,4,2]  R416      1.8917587399482727e-01
    z[0,4,2]  R417      2.1824875473976135e-01
    z[0,4,2]  R418      -2.8268773108720779e-02
    z[0,4,2]  R419      1.5187076292932034e-02
    z[0,4,2]  R420      8.6479753255844116e-02
    z[0,4,2]  R421      4.6523684263229370e-01
    z[0,4,2]  R422      -3.9636015892028809e-02
    z[0,4,2]  R423      -1.7314006388187408e-01
    z[0,4,2]  R424      1.1506627500057220e-01
    z[0,4,2]  R425      3.6588132381439209e-01
    z[0,4,2]  R426      4.2354875802993774e-01
    z[0,4,2]  R427      -0.427571177482605
    z[0,4,2]  R428      -2.0107574760913849e-01
    z[0,4,2]  R429      -3.7276017665863037e-01
    z[0,4,2]  R430      -3.8085898756980896e-01
    z[0,4,2]  R431      -1.2745060026645660e-01
    z[0,4,2]  R432      -4.2258203029632568e-02
    z[0,4,2]  R433      -8.9466765522956848e-02
    z[0,4,2]  R434      -1.2418854981660843e-01
    z[0,4,2]  R435      -4.1712176799774170e-01
    z[0,4,2]  R436      -3.6077263951301575e-01
    z[0,4,2]  R437      -5.7610249519348145e-01
    z[0,4,2]  R438      -5.0727421045303345e-01
    z[0,4,2]  R439      8.7560452520847321e-02
    z[0,4,2]  R440      6.7385137081146240e-01
    z[0,4,2]  R441      -0.0605199821293354
    z[0,4,2]  R442      7.0161208510398865e-02
    z[0,4,2]  R443      5.4754996299743652e-01
    z[0,4,2]  R444      4.1273349523544312e-01
    z[0,4,2]  R445      -4.3047182261943817e-02
    z[0,4,2]  R446      0.261992871761322
    z[0,4,2]  R447      1.4161027036607265e-02
    z[0,4,2]  R448      6.5739743411540985e-02
    z[0,4,2]  R449      4.7190878540277481e-02
    z[0,4,2]  R450      1.5756408870220184e-01
    z[0,4,2]  R451      0.00896039791405201
    z[0,4,2]  R452      2.2195219993591309e-01
    z[0,4,2]  R453      4.6186674386262894e-02
    z[0,4,2]  R454      0.515374481678009
    z[0,4,2]  R455      -5.8893103152513504e-02
    z[0,4,2]  R456      2.9958483576774597e-01
    z[0,4,2]  R457      -5.9244537353515625e-01
    z[0,4,2]  R458      -8.2150202989578247e-01
    z[0,4,2]  R459      -5.4357331991195679e-01
    z[0,4,2]  R460      -3.1353580951690674e-01
    z[0,4,2]  R461      -7.3006719350814819e-01
    z[0,4,2]  R462      -7.2983759641647339e-01
    z[0,4,2]  R463      -2.6255834102630615e-01
    z[0,4,2]  R464      -2.2652576863765717e-01
    z[0,4,2]  R465      -6.6095048189163208e-01
    z[0,4,2]  R466      -6.0441619157791138e-01
    z[0,4,2]  R467      1.1838949285447598e-02
    z[0,4,2]  R468      -8.1899136304855347e-02
    z[0,4,2]  R469      -4.5951315760612488e-01
    z[0,4,2]  R470      6.1652439832687378e-01
    z[0,4,2]  R471      2.8402274474501610e-02
    z[0,4,2]  R472      2.7462553977966309e-01
    z[0,4,2]  R473      4.0592372417449951e-01
    z[0,4,2]  R474      2.7861317619681358e-02
    z[0,4,2]  R475      2.7157512307167053e-01
    z[0,4,2]  R476      1.4036209881305695e-01
    z[0,4,2]  R477      -1.9590763747692108e-01
    z[0,4,2]  R478      -2.3073473572731018e-01
    z[0,4,2]  R479      -3.0537730455398560e-01
    z[0,4,2]  R480      2.0183049142360687e-01
    z[0,4,2]  R481      -2.9556852579116821e-01
    z[0,4,2]  R482      -4.0751591324806213e-01
    z[0,4,2]  R483      -1.1781888455152512e-01
    z[0,4,2]  R484      -6.2708705663681030e-02
    z[0,4,2]  R485      -7.0346496999263763e-02
    z[0,4,2]  R486      3.0369493365287781e-01
    z[0,4,2]  R487      -2.3955148458480835e-01
    z[0,4,2]  R488      -5.7545232772827148e-01
    z[0,4,2]  R489      9.1637238860130310e-02
    z[0,4,2]  R490      -5.8281220495700836e-02
    z[0,4,2]  R491      -2.0295043289661407e-01
    z[0,4,2]  R492      -1.2939724326133728e-01
    z[0,4,2]  R493      5.9550367295742035e-02
    z[0,4,2]  R494      -2.1915417909622192e-01
    z[0,4,2]  R495      -5.4754824377596378e-03
    z[0,4,2]  R496      2.2998669743537903e-01
    z[0,4,2]  R497      -3.3640664815902710e-01
    z[0,4,2]  R498      -2.1699997782707214e-01
    z[0,4,2]  R499      1.5533640980720520e-01
    z[0,4,2]  R500      -6.7132425308227539e-01
    z[0,4,2]  R501      -0.544070839881897
    z[0,4,2]  R502      1.1546090245246887e-01
    z[0,4,2]  R503      2.4799892306327820e-01
    z[0,4,2]  R504      -2.8383618593215942e-01
    z[0,4,2]  R505      7.4420824646949768e-02
    z[0,4,2]  R506      4.0437978506088257e-01
    z[0,4,2]  R507      5.6865561753511429e-02
    z[0,4,2]  R508      -4.4046363234519958e-01
    z[0,4,2]  R509      2.0109033584594727e-01
    z[0,4,2]  R510      -1.4814113080501556e-01
    z[0,4,2]  R511      -2.4655283987522125e-01
    z[0,4,2]  R512      -4.0472263097763062e-01
    z[0,4,2]  R513      7.9461358487606049e-02
    z[0,4,2]  R514      3.3187928795814514e-01
    z[0,4,2]  R515      3.6535346508026123e-01
    z[0,4,3]  R5        -1
    z[0,4,3]  R41       1
    z[0,4,3]  R399      -1
    z[0,4,3]  R400      1
    z[0,4,3]  R407      -1.4083890616893768e-01
    z[0,4,3]  R408      1.3286863267421722e-01
    z[0,4,3]  R409      -3.0317762494087219e-01
    z[0,4,3]  R410      -3.6674609780311584e-01
    z[0,4,3]  R411      -2.2699026390910149e-02
    z[0,4,3]  R412      -3.8814797997474670e-01
    z[0,4,3]  R413      -0.373947411775589
    z[0,4,3]  R414      -2.1999992430210114e-01
    z[0,4,3]  R415      -1.5195679850876331e-02
    z[0,4,3]  R416      -3.1144765019416809e-01
    z[0,4,3]  R417      7.1903622150421143e-01
    z[0,4,3]  R418      2.5185352563858032e-01
    z[0,4,3]  R419      5.0359004735946655e-01
    z[0,4,3]  R420      7.3543775081634521e-01
    z[0,4,3]  R421      4.9513211846351624e-01
    z[0,4,3]  R422      -0.0909363180398941
    z[0,4,3]  R423      1.9417591392993927e-01
    z[0,4,3]  R424      1.8482092022895813e-01
    z[0,4,3]  R425      4.2545256018638611e-01
    z[0,4,3]  R426      -5.0914859771728516e-01
    z[0,4,3]  R427      4.2381274700164795e-01
    z[0,4,3]  R428      3.7916150689125061e-01
    z[0,4,3]  R429      3.7722736597061157e-01
    z[0,4,3]  R430      4.4775003194808960e-01
    z[0,4,3]  R431      -1.9667898304760456e-03
    z[0,4,3]  R432      1.3694278895854950e-01
    z[0,4,3]  R433      6.7721712589263916e-01
    z[0,4,3]  R434      4.9713057279586792e-01
    z[0,4,3]  R435      -2.2889813408255577e-02
    z[0,4,3]  R436      3.0973119661211967e-02
    z[0,4,3]  R437      -8.1840313971042633e-02
    z[0,4,3]  R438      1.0280106961727142e-01
    z[0,4,3]  R439      4.7158437967300415e-01
    z[0,4,3]  R440      -1.5477801859378815e-01
    z[0,4,3]  R441      -8.3408242464065552e-01
    z[0,4,3]  R442      -8.8260644674301147e-01
    z[0,4,3]  R443      -4.9218437075614929e-01
    z[0,4,3]  R444      3.1000250577926636e-01
    z[0,4,3]  R445      2.8603506088256836e-01
    z[0,4,3]  R446      -7.5672513246536255e-01
    z[0,4,3]  R447      -9.1456425189971924e-01
    z[0,4,3]  R448      2.2730968892574310e-01
    z[0,4,3]  R449      2.5798153132200241e-02
    z[0,4,3]  R450      -5.1111515611410141e-02
    z[0,4,3]  R451      1.7404921352863312e-01
    z[0,4,3]  R452      -1.2447923421859741e-01
    z[0,4,3]  R453      -2.0280398428440094e-01
    z[0,4,3]  R454      -9.4996467232704163e-02
    z[0,4,3]  R455      -3.3122873306274414e-01
    z[0,4,3]  R456      -2.6657733321189880e-01
    z[0,4,3]  R457      2.3699685931205750e-01
    z[0,4,3]  R458      1.1154517531394958e-01
    z[0,4,3]  R459      -8.6395636200904846e-02
    z[0,4,3]  R460      1.1555530875921249e-01
    z[0,4,3]  R461      1.3171684741973877e-01
    z[0,4,3]  R462      3.5918179154396057e-01
    z[0,4,3]  R463      -5.3258669376373291e-01
    z[0,4,3]  R464      4.1792401671409607e-01
    z[0,4,3]  R465      -9.7393877804279327e-02
    z[0,4,3]  R466      -2.8344443440437317e-01
    z[0,4,3]  R467      -0.271945595741272
    z[0,4,3]  R468      -1.5372280776500702e-01
    z[0,4,3]  R469      -1.1726742237806320e-01
    z[0,4,3]  R470      1.5897387266159058e-01
    z[0,4,3]  R471      5.3039681911468506e-01
    z[0,4,3]  R472      4.7791481018066406e-01
    z[0,4,3]  R473      4.5172640681266785e-01
    z[0,4,3]  R474      6.5011823177337646e-01
    z[0,4,3]  R475      6.2212830781936646e-01
    z[0,4,3]  R476      -1.4795914292335510e-01
    z[0,4,3]  R477      6.3086384534835815e-01
    z[0,4,3]  R478      -2.1271225810050964e-01
    z[0,4,3]  R479      1.8182241916656494e-01
    z[0,4,3]  R480      4.9371698498725891e-01
    z[0,4,3]  R481      2.0419631898403168e-01
    z[0,4,3]  R482      -2.2921408712863922e-01
    z[0,4,3]  R483      -2.2812442481517792e-01
    z[0,4,3]  R484      -0.72444748878479
    z[0,4,3]  R485      3.3810603618621826e-01
    z[0,4,3]  R486      1.8640232086181641e-01
    z[0,4,3]  R487      -4.8062512278556824e-01
    z[0,4,3]  R488      -0.483710378408432
    z[0,4,3]  R489      5.6191053241491318e-02
    z[0,4,3]  R490      -3.6831229925155640e-01
    z[0,4,3]  R491      1.6339768469333649e-01
    z[0,4,3]  R492      1.0380907356739044e-01
    z[0,4,3]  R493      1.1003208905458450e-01
    z[0,4,3]  R494      6.5903908014297485e-01
    z[0,4,3]  R495      -3.2897201180458069e-01
    z[0,4,3]  R496      -1.5643297135829926e-01
    z[0,4,3]  R497      3.9144212007522583e-01
    z[0,4,3]  R498      -0.00906385201960802
    z[0,4,3]  R499      -4.2518965899944305e-02
    z[0,4,3]  R500      -4.3219098448753357e-01
    z[0,4,3]  R501      2.7163645625114441e-01
    z[0,4,3]  R502      2.2988820075988770e-01
    z[0,4,3]  R503      -6.2464926391839981e-02
    z[0,4,3]  R504      3.9827436208724976e-01
    z[0,4,3]  R505      3.6196565628051758e-01
    z[0,4,3]  R506      3.5333672165870667e-01
    z[0,4,3]  R507      -2.4791575968265533e-01
    z[0,4,3]  R508      -1.5276212990283966e-01
    z[0,4,3]  R509      3.0615553259849548e-01
    z[0,4,3]  R510      2.4574624840170145e-03
    z[0,4,3]  R511      1.8979637324810028e-01
    z[0,4,3]  R512      -1.6697503626346588e-01
    z[0,4,3]  R513      -0.798019289970398
    z[0,4,3]  R514      -8.2056099176406860e-01
    z[0,4,3]  R515      4.1949599981307983e-01
    z[0,4,4]  R6        -1
    z[0,4,4]  R42       1
    z[0,4,4]  R401      -1
    z[0,4,4]  R402      1
    z[0,4,4]  R407      -6.8540310859680176e-01
    z[0,4,4]  R408      -6.5990060567855835e-01
    z[0,4,4]  R409      -6.2889808416366577e-01
    z[0,4,4]  R410      -2.1133351325988770e-01
    z[0,4,4]  R411      -8.2144963741302490e-01
    z[0,4,4]  R412      -4.4403173960745335e-03
    z[0,4,4]  R413      2.0590825378894806e-01
    z[0,4,4]  R414      2.5579905509948730e-01
    z[0,4,4]  R415      1.1942632496356964e-01
    z[0,4,4]  R416      -5.9767484664916992e-02
    z[0,4,4]  R417      -9.8800763487815857e-02
    z[0,4,4]  R418      0.721690833568573
    z[0,4,4]  R419      2.2953312098979950e-01
    z[0,4,4]  R420      0.0649818480014801
    z[0,4,4]  R421      1.4219713211059570e-01
    z[0,4,4]  R422      2.5511008501052856e-01
    z[0,4,4]  R423      3.0260652303695679e-01
    z[0,4,4]  R424      4.7169774770736694e-01
    z[0,4,4]  R425      -8.0509938299655914e-02
    z[0,4,4]  R426      -2.5258013606071472e-01
    z[0,4,4]  R427      -2.5747594237327576e-01
    z[0,4,4]  R428      1.4884701371192932e-01
    z[0,4,4]  R429      -3.3828923106193542e-01
    z[0,4,4]  R430      1.8099553883075714e-01
    z[0,4,4]  R431      -8.2265391945838928e-02
    z[0,4,4]  R432      8.9658334851264954e-02
    z[0,4,4]  R433      -4.6158339828252792e-02
    z[0,4,4]  R434      -4.5031303167343140e-01
    z[0,4,4]  R435      2.3909020423889160e-01
    z[0,4,4]  R436      2.5913387537002563e-01
    z[0,4,4]  R437      1.4467741549015045e-01
    z[0,4,4]  R438      -5.0215190649032593e-01
    z[0,4,4]  R439      -5.0982785224914551e-01
    z[0,4,4]  R440      0.330519437789917
    z[0,4,4]  R441      3.7079009413719177e-01
    z[0,4,4]  R442      2.2420334815979004e-01
    z[0,4,4]  R443      8.6895991116762161e-03
    z[0,4,4]  R444      1.1299183219671249e-01
    z[0,4,4]  R445      1.9198693335056305e-01
    z[0,4,4]  R446      3.3922556042671204e-01
    z[0,4,4]  R447      1.6213682293891907e-01
    z[0,4,4]  R448      4.4171714782714844e-01
    z[0,4,4]  R449      -1.3314799405634403e-02
    z[0,4,4]  R450      -1.9462814927101135e-01
    z[0,4,4]  R451      -1.4693741500377655e-01
    z[0,4,4]  R452      9.6453763544559479e-02
    z[0,4,4]  R453      -2.9710020869970322e-02
    z[0,4,4]  R454      3.5078969597816467e-01
    z[0,4,4]  R455      -1.6486944258213043e-01
    z[0,4,4]  R456      -0.0299517959356308
    z[0,4,4]  R457      -5.9807217121124268e-01
    z[0,4,4]  R458      -4.9848622083663940e-01
    z[0,4,4]  R459      -6.5336924791336060e-01
    z[0,4,4]  R460      -7.2163826227188110e-01
    z[0,4,4]  R461      -3.5952815413475037e-01
    z[0,4,4]  R462      -4.0824940800666809e-01
    z[0,4,4]  R463      3.1452366709709167e-01
    z[0,4,4]  R464      -0.684838056564331
    z[0,4,4]  R465      -4.1711923480033875e-01
    z[0,4,4]  R466      1.0789326392114162e-02
    z[0,4,4]  R467      -1.2407668679952621e-01
    z[0,4,4]  R468      -1.8454334139823914e-01
    z[0,4,4]  R469      1.1577981710433960e-01
    z[0,4,4]  R470      -3.2115232944488525e-01
    z[0,4,4]  R471      -4.9837838858366013e-02
    z[0,4,4]  R472      -3.9657387137413025e-01
    z[0,4,4]  R473      -0.182534858584404
    z[0,4,4]  R474      3.5078135132789612e-01
    z[0,4,4]  R475      5.4858420044183731e-02
    z[0,4,4]  R476      1.3900396227836609e-01
    z[0,4,4]  R477      2.7258116006851196e-01
    z[0,4,4]  R478      4.3921627104282379e-02
    z[0,4,4]  R479      5.8377593755722046e-01
    z[0,4,4]  R480      8.3564937114715576e-02
    z[0,4,4]  R481      1.8081174790859222e-01
    z[0,4,4]  R482      4.6877473592758179e-01
    z[0,4,4]  R483      1.3864706456661224e-01
    z[0,4,4]  R484      -2.5935885310173035e-01
    z[0,4,4]  R485      -4.4898489117622375e-01
    z[0,4,4]  R486      -2.8888520598411560e-01
    z[0,4,4]  R487      -5.4572808742523193e-01
    z[0,4,4]  R488      1.7076827585697174e-02
    z[0,4,4]  R489      -0.0605459026992321
    z[0,4,4]  R490      -8.3162176609039307e-01
    z[0,4,4]  R491      -2.4538438022136688e-01
    z[0,4,4]  R492      -6.3393193483352661e-01
    z[0,4,4]  R493      -4.3460991978645325e-01
    z[0,4,4]  R494      -4.3667531013488770e-01
    z[0,4,4]  R495      -3.4096285700798035e-01
    z[0,4,4]  R496      -3.3043101429939270e-01
    z[0,4,4]  R497      -6.0014687478542328e-02
    z[0,4,4]  R498      -4.6652728319168091e-01
    z[0,4,4]  R499      -3.2168093323707581e-01
    z[0,4,4]  R500      -1.8092378973960876e-01
    z[0,4,4]  R501      1.0825133323669434e-01
    z[0,4,4]  R502      1.2555750086903572e-02
    z[0,4,4]  R503      3.4217610955238342e-01
    z[0,4,4]  R504      -5.0948488712310791e-01
    z[0,4,4]  R505      1.9620832800865173e-01
    z[0,4,4]  R506      1.0042093694210052e-01
    z[0,4,4]  R507      -8.4013324975967407e-01
    z[0,4,4]  R508      4.8353976011276245e-01
    z[0,4,4]  R509      -2.5056087970733643e-01
    z[0,4,4]  R510      -3.0108615756034851e-01
    z[0,4,4]  R511      -3.7153720855712891e-02
    z[0,4,4]  R512      -2.7126485109329224e-01
    z[0,4,4]  R513      3.7175214290618896e-01
    z[0,4,4]  R514      2.4538248777389526e-01
    z[0,4,4]  R515      -6.3851051032543182e-02
    z[0,4,5]  R7        -1
    z[0,4,5]  R43       1
    z[0,4,5]  R403      -1
    z[0,4,5]  R404      1
    z[0,4,5]  R407      4.6116065979003906e-01
    z[0,4,5]  R408      5.4654383659362793e-01
    z[0,4,5]  R409      1.3602770864963531e-01
    z[0,4,5]  R410      8.8637866079807281e-02
    z[0,4,5]  R411      3.6333236098289490e-01
    z[0,4,5]  R412      7.3513254523277283e-02
    z[0,4,5]  R413      1.3788402080535889e-01
    z[0,4,5]  R414      6.0341589152812958e-02
    z[0,4,5]  R415      -1.3995829224586487e-01
    z[0,4,5]  R416      1.3770771026611328e-01
    z[0,4,5]  R417      -2.8934234380722046e-01
    z[0,4,5]  R418      -2.0392332226037979e-02
    z[0,4,5]  R419      -3.6336994171142578e-01
    z[0,4,5]  R420      -2.1523636579513550e-01
    z[0,4,5]  R421      -4.4337805360555649e-02
    z[0,4,5]  R422      5.9535790234804153e-02
    z[0,4,5]  R423      -1.4216606318950653e-01
    z[0,4,5]  R424      1.1818820238113403e-01
    z[0,4,5]  R425      -2.3110084235668182e-02
    z[0,4,5]  R426      -6.1451215296983719e-02
    z[0,4,5]  R427      -2.3863169550895691e-01
    z[0,4,5]  R428      2.8609130531549454e-03
    z[0,4,5]  R429      -3.4703877568244934e-01
    z[0,4,5]  R430      -8.0513760447502136e-02
    z[0,4,5]  R431      -2.5317358970642090e-01
    z[0,4,5]  R432      -0.0852438285946846
    z[0,4,5]  R433      -1.1414396017789841e-01
    z[0,4,5]  R434      -3.7345707416534424e-01
    z[0,4,5]  R435      -1.8260811269283295e-01
    z[0,4,5]  R436      1.8850685656070709e-01
    z[0,4,5]  R437      -3.1865498423576355e-01
    z[0,4,5]  R438      -6.2541222572326660e-01
    z[0,4,5]  R439      -4.9563441425561905e-02
    z[0,4,5]  R440      2.4108274281024933e-01
    z[0,4,5]  R441      -8.9520506560802460e-02
    z[0,4,5]  R442      -4.5341745018959045e-02
    z[0,4,5]  R443      3.4138467907905579e-01
    z[0,4,5]  R444      1.6713395714759827e-01
    z[0,4,5]  R445      5.1403380930423737e-02
    z[0,4,5]  R446      -1.7885808646678925e-01
    z[0,4,5]  R447      -1.5099354088306427e-01
    z[0,4,5]  R448      -3.3542364835739136e-02
    z[0,4,5]  R449      4.2033061385154724e-01
    z[0,4,5]  R450      -3.2964695245027542e-02
    z[0,4,5]  R451      -2.6514637470245361e-01
    z[0,4,5]  R452      1.6184569895267487e-01
    z[0,4,5]  R453      2.8925737738609314e-01
    z[0,4,5]  R454      -1.4822500944137573e-01
    z[0,4,5]  R455      -0.074454665184021
    z[0,4,5]  R456      1.5261600911617279e-01
    z[0,4,5]  R457      2.7588501572608948e-01
    z[0,4,5]  R458      0.0768398642539978
    z[0,4,5]  R459      4.8011988401412964e-01
    z[0,4,5]  R460      4.0588292479515076e-01
    z[0,4,5]  R461      5.3919738531112671e-01
    z[0,4,5]  R462      3.0846032500267029e-01
    z[0,4,5]  R463      -1.7066171392798424e-02
    z[0,4,5]  R464      4.3200677633285522e-01
    z[0,4,5]  R465      7.2658412158489227e-02
    z[0,4,5]  R466      3.8039374351501465e-01
    z[0,4,5]  R467      1.8794685602188110e-01
    z[0,4,5]  R468      3.1153056025505066e-01
    z[0,4,5]  R469      3.4912928938865662e-02
    z[0,4,5]  R470      1.9149954617023468e-01
    z[0,4,5]  R471      -4.0843873284757137e-03
    z[0,4,5]  R472      2.9163593053817749e-01
    z[0,4,5]  R473      5.9292250871658325e-01
    z[0,4,5]  R474      3.4390920400619507e-01
    z[0,4,5]  R475      2.2979740798473358e-01
    z[0,4,5]  R476      2.3302505910396576e-01
    z[0,4,5]  R477      8.0706931650638580e-02
    z[0,4,5]  R478      -5.3153578191995621e-02
    z[0,4,5]  R479      -1.1309825628995895e-01
    z[0,4,5]  R480      -2.2733679413795471e-01
    z[0,4,5]  R481      5.2110069990158081e-01
    z[0,4,5]  R482      2.2259102761745453e-01
    z[0,4,5]  R483      4.0817445516586304e-01
    z[0,4,5]  R484      1.9557489454746246e-01
    z[0,4,5]  R485      -2.4819038808345795e-01
    z[0,4,5]  R486      1.9170695543289185e-01
    z[0,4,5]  R487      3.0538302659988403e-01
    z[0,4,5]  R488      5.1258746534585953e-02
    z[0,4,5]  R489      4.7907531261444092e-01
    z[0,4,5]  R490      -0.314779132604599
    z[0,4,5]  R491      9.0232640504837036e-01
    z[0,4,5]  R492      1.3097949326038361e-01
    z[0,4,5]  R493      -5.8001402765512466e-02
    z[0,4,5]  R494      3.7141764163970947e-01
    z[0,4,5]  R495      1.2606818974018097e-01
    z[0,4,5]  R496      -1.2264557927846909e-01
    z[0,4,5]  R497      1.4420942962169647e-01
    z[0,4,5]  R498      -2.9039919376373291e-01
    z[0,4,5]  R499      1.4926192164421082e-01
    z[0,4,5]  R500      -0.0517929382622242
    z[0,4,5]  R501      -0.0381213054060936
    z[0,4,5]  R502      1.5846368670463562e-01
    z[0,4,5]  R503      1.2515859305858612e-01
    z[0,4,5]  R504      3.9180997014045715e-01
    z[0,4,5]  R505      -1.6171494126319885e-01
    z[0,4,5]  R506      -8.8415652513504028e-02
    z[0,4,5]  R507      -3.2338467240333557e-01
    z[0,4,5]  R508      1.0416987538337708e-01
    z[0,4,5]  R509      -1.7621999979019165e-01
    z[0,4,5]  R510      -3.2661595940589905e-01
    z[0,4,5]  R511      -4.2096513509750366e-01
    z[0,4,5]  R512      -4.1891392320394516e-02
    z[0,4,5]  R513      -1.3399402797222137e-01
    z[0,4,5]  R514      -1.3040751218795776e-01
    z[0,4,5]  R515      -0.0849934071302414
    z[0,4,6]  R8        -1
    z[0,4,6]  R44       1
    z[0,4,6]  R405      -1
    z[0,4,6]  R406      1
    z[0,4,6]  R407      -8.2849457859992981e-02
    z[0,4,6]  R408      -1.8272195756435394e-01
    z[0,4,6]  R409      2.8193622827529907e-02
    z[0,4,6]  R410      -1.0989258438348770e-01
    z[0,4,6]  R411      3.0912297964096069e-01
    z[0,4,6]  R412      -1.7003765329718590e-02
    z[0,4,6]  R413      8.9599706232547760e-02
    z[0,4,6]  R414      3.8631439208984375e-01
    z[0,4,6]  R415      9.9594242870807648e-02
    z[0,4,6]  R416      3.9882853627204895e-01
    z[0,4,6]  R417      -1.9392198324203491e-01
    z[0,4,6]  R418      -2.1297354996204376e-01
    z[0,4,6]  R419      -1.1866380274295807e-01
    z[0,4,6]  R420      -1.7210614681243896e-01
    z[0,4,6]  R421      2.8479138016700745e-01
    z[0,4,6]  R422      0.158565953373909
    z[0,4,6]  R423      1.6385369002819061e-01
    z[0,4,6]  R424      -6.5212212502956390e-02
    z[0,4,6]  R425      1.6607193648815155e-01
    z[0,4,6]  R426      -3.8209420442581177e-01
    z[0,4,6]  R427      2.0963855087757111e-02
    z[0,4,6]  R428      -9.7138516604900360e-02
    z[0,4,6]  R429      1.5419182181358337e-01
    z[0,4,6]  R430      -2.4525739252567291e-01
    z[0,4,6]  R431      -1.9927522540092468e-01
    z[0,4,6]  R432      3.6211568117141724e-01
    z[0,4,6]  R433      -2.1221902966499329e-01
    z[0,4,6]  R434      -2.3844359815120697e-01
    z[0,4,6]  R435      3.1876003742218018e-01
    z[0,4,6]  R436      1.4437088370323181e-01
    z[0,4,6]  R437      2.4518595635890961e-01
    z[0,4,6]  R438      0.22120301425457
    z[0,4,6]  R439      2.5697039440274239e-02
    z[0,4,6]  R440      -3.0606296658515930e-01
    z[0,4,6]  R441      -5.0941254943609238e-02
    z[0,4,6]  R442      -1.0018956847488880e-02
    z[0,4,6]  R443      -0.314046174287796
    z[0,4,6]  R444      1.0457421094179153e-01
    z[0,4,6]  R445      -4.0676867961883545e-01
    z[0,4,6]  R446      1.7006288468837738e-01
    z[0,4,6]  R447      -0.0994422510266304
    z[0,4,6]  R448      -2.5032436847686768e-01
    z[0,4,6]  R449      2.5631364434957504e-02
    z[0,4,6]  R450      -2.2855636198073626e-03
    z[0,4,6]  R451      -2.0104375481605530e-01
    z[0,4,6]  R452      -1.3333666324615479e-01
    z[0,4,6]  R453      -1.4793017506599426e-01
    z[0,4,6]  R454      1.5221193432807922e-02
    z[0,4,6]  R455      1.8041402101516724e-01
    z[0,4,6]  R456      2.4068281054496765e-01
    z[0,4,6]  R457      -3.2459592819213867e-01
    z[0,4,6]  R458      4.8325583338737488e-02
    z[0,4,6]  R459      -3.5433974117040634e-02
    z[0,4,6]  R460      4.1947695612907410e-01
    z[0,4,6]  R461      9.6513405442237854e-02
    z[0,4,6]  R462      2.2284905612468719e-01
    z[0,4,6]  R463      -2.0006555318832397e-01
    z[0,4,6]  R464      2.1568414568901062e-01
    z[0,4,6]  R465      5.8561146259307861e-01
    z[0,4,6]  R466      2.5013424456119537e-03
    z[0,4,6]  R467      1.3021971285343170e-01
    z[0,4,6]  R468      -2.3854376375675201e-01
    z[0,4,6]  R469      -1.7075374722480774e-01
    z[0,4,6]  R470      1.8598724901676178e-01
    z[0,4,6]  R471      2.5466856360435486e-01
    z[0,4,6]  R472      -4.8353332281112671e-01
    z[0,4,6]  R473      -3.5868138074874878e-01
    z[0,4,6]  R474      -3.9329206943511963e-01
    z[0,4,6]  R475      -2.2811383008956909e-01
    z[0,4,6]  R476      6.4580667018890381e-01
    z[0,4,6]  R477      -1.5585084259510040e-01
    z[0,4,6]  R478      -4.4793391227722168e-01
    z[0,4,6]  R479      -1.7386395484209061e-02
    z[0,4,6]  R480      -1.2443863600492477e-01
    z[0,4,6]  R481      4.2697262018918991e-02
    z[0,4,6]  R482      -2.4199962615966797e-02
    z[0,4,6]  R483      2.6031273603439331e-01
    z[0,4,6]  R484      1.9470381736755371e-01
    z[0,4,6]  R485      2.6132947206497192e-01
    z[0,4,6]  R486      -0.398084819316864
    z[0,4,6]  R487      2.4788361787796021e-01
    z[0,4,6]  R488      3.4689265489578247e-01
    z[0,4,6]  R489      -1.6337784007191658e-02
    z[0,4,6]  R490      -8.7756089866161346e-02
    z[0,4,6]  R491      -7.9994276165962219e-03
    z[0,4,6]  R492      4.4153681397438049e-01
    z[0,4,6]  R493      -2.6913493871688843e-01
    z[0,4,6]  R494      -1.4677749946713448e-02
    z[0,4,6]  R495      -3.1525948643684387e-01
    z[0,4,6]  R496      1.6807551681995392e-01
    z[0,4,6]  R497      4.3010881543159485e-01
    z[0,4,6]  R498      -1.3056711852550507e-01
    z[0,4,6]  R499      -1.6935016214847565e-01
    z[0,4,6]  R500      2.6247268915176392e-01
    z[0,4,6]  R501      -2.4118547141551971e-01
    z[0,4,6]  R502      -6.1556601524353027e-01
    z[0,4,6]  R503      7.9690247774124146e-02
    z[0,4,6]  R504      -2.6254606246948242e-01
    z[0,4,6]  R505      -1.0532230883836746e-01
    z[0,4,6]  R506      5.4940257221460342e-02
    z[0,4,6]  R507      6.6073901951313019e-02
    z[0,4,6]  R508      2.3335088789463043e-01
    z[0,4,6]  R509      1.4274649322032928e-01
    z[0,4,6]  R510      2.8746458888053894e-01
    z[0,4,6]  R511      -6.6539153456687927e-02
    z[0,4,6]  R512      1.5067237615585327e-01
    z[0,4,6]  R513      -1.2331873923540115e-01
    z[0,4,6]  R514      -1.6254171729087830e-01
    z[0,4,6]  R515      -5.4477435350418091e-01
    z[4,0,0]  R2        1
    z[4,0,0]  R38       -1
    z[4,0,0]  R516      -1
    z[4,0,0]  R517      1
    z[4,0,0]  R530      -5.7847633957862854e-02
    z[4,0,0]  R531      2.3291967809200287e-01
    z[4,0,0]  R532      1.9032852351665497e-01
    z[4,0,0]  R533      1.0687439143657684e-01
    z[4,0,0]  R534      1.2337212264537811e-01
    z[4,0,0]  R535      -1.5379829704761505e-01
    z[4,0,0]  R536      0.612011730670929
    z[4,0,0]  R537      -2.5405046343803406e-01
    z[4,0,0]  R538      -1.7137020826339722e-01
    z[4,0,0]  R539      5.9136056900024414e-01
    z[4,0,0]  R540      -3.8787201046943665e-01
    z[4,0,0]  R541      -1.7020131647586823e-01
    z[4,0,0]  R542      -1.3619169592857361e-01
    z[4,0,0]  R543      4.5985409617424011e-01
    z[4,0,0]  R544      1.5315456688404083e-01
    z[4,0,0]  R545      3.9971357583999634e-01
    z[4,0,0]  R546      3.3082881569862366e-01
    z[4,0,0]  R547      -1.5886427462100983e-01
    z[4,0,0]  R548      2.4377131462097168e-01
    z[4,0,0]  R549      -9.3194320797920227e-02
    z[4,0,0]  R550      -1.2749305367469788e-01
    z[4,0,0]  R551      -3.3869582414627075e-01
    z[4,0,0]  R552      -3.0979645252227783e-01
    z[4,0,0]  R553      4.6450782567262650e-02
    z[4,0,0]  R554      -5.0778716802597046e-01
    z[4,0,0]  R555      -4.2351409792900085e-01
    z[4,0,0]  R556      -2.8360605239868164e-01
    z[4,0,0]  R557      5.3043287992477417e-01
    z[4,0,0]  R558      5.4679775238037109e-01
    z[4,0,0]  R559      4.1538336873054504e-01
    z[4,0,0]  R560      -3.4991261363029480e-01
    z[4,0,0]  R561      -6.5750330686569214e-02
    z[4,0,0]  R562      6.4677906036376953e-01
    z[4,0,0]  R563      2.2338490188121796e-01
    z[4,0,0]  R564      2.0899084210395813e-01
    z[4,0,0]  R565      5.5733382701873779e-01
    z[4,0,0]  R566      8.4454685449600220e-01
    z[4,0,0]  R567      3.7446701526641846e-01
    z[4,0,0]  R568      7.4645286798477173e-01
    z[4,0,0]  R569      4.8767754435539246e-01
    z[4,0,0]  R570      3.3604595810174942e-02
    z[4,0,0]  R571      5.7812124490737915e-01
    z[4,0,0]  R572      8.7086832523345947e-01
    z[4,0,0]  R573      -2.4377760291099548e-01
    z[4,0,0]  R574      5.2036845684051514e-01
    z[4,0,0]  R575      6.8450921773910522e-01
    z[4,0,0]  R576      -1.7482032999396324e-03
    z[4,0,0]  R577      4.1061496734619141e-01
    z[4,0,0]  R578      -8.1347328424453735e-01
    z[4,0,0]  R579      -7.9426652193069458e-01
    z[4,0,0]  R580      -1.0821318626403809e-01
    z[4,0,0]  R581      -6.9208703935146332e-02
    z[4,0,0]  R582      -3.2698172330856323e-01
    z[4,0,0]  R583      -0.609432578086853
    z[4,0,0]  R584      -6.8806296586990356e-01
    z[4,0,0]  R585      -8.0902999639511108e-01
    z[4,0,0]  R586      -4.1726133227348328e-01
    z[4,0,0]  R587      -3.1601142883300781e-01
    z[4,0,0]  R588      -0.582899808883667
    z[4,0,0]  R589      1.6584175825119019e-01
    z[4,0,0]  R590      -0.0663711279630661
    z[4,0,0]  R591      1.1949385702610016e-01
    z[4,0,0]  R592      1.9378165900707245e-01
    z[4,0,0]  R593      4.3577592819929123e-02
    z[4,0,0]  R594      9.0140420198440552e-01
    z[4,0,0]  R595      8.1452596187591553e-01
    z[4,0,0]  R596      8.2104223966598511e-01
    z[4,0,0]  R597      9.7160762548446655e-01
    z[4,0,0]  R598      8.1599676609039307e-01
    z[4,0,0]  R599      1.9828332960605621e-01
    z[4,0,0]  R600      -4.4695755839347839e-01
    z[4,0,0]  R601      1.6230948269367218e-01
    z[4,0,0]  R602      -3.4789907932281494e-01
    z[4,0,0]  R603      -4.4342020153999329e-01
    z[4,0,0]  R604      -8.9742016792297363e-01
    z[4,0,0]  R605      -8.4654372930526733e-01
    z[4,0,0]  R606      -8.3944803476333618e-01
    z[4,0,0]  R607      -7.8399944305419922e-01
    z[4,0,0]  R608      -3.5530397295951843e-01
    z[4,0,0]  R609      -5.4938018321990967e-01
    z[4,0,0]  R610      4.9426622688770294e-02
    z[4,0,0]  R611      -6.1445814371109009e-01
    z[4,0,0]  R612      -4.0386113524436951e-01
    z[4,0,0]  R613      -4.9271425604820251e-01
    z[4,0,0]  R614      1.2376247346401215e-01
    z[4,0,0]  R615      -1.5954676270484924e-01
    z[4,0,0]  R616      4.6899044513702393e-01
    z[4,0,0]  R617      -5.2462047338485718e-01
    z[4,0,0]  R618      -6.4716976881027222e-01
    z[4,0,0]  R619      -2.0606555044651031e-01
    z[4,0,0]  R620      -1.5359888970851898e-01
    z[4,0,0]  R621      4.3930616974830627e-01
    z[4,0,0]  R622      -5.3720917552709579e-02
    z[4,0,0]  R623      -2.1099595725536346e-01
    z[4,0,0]  R624      -3.9522945880889893e-01
    z[4,0,0]  R625      -1.4909274876117706e-01
    z[4,0,0]  R626      -0.791441798210144
    z[4,0,0]  R627      -7.3082339763641357e-01
    z[4,0,0]  R628      -4.1452351212501526e-01
    z[4,0,0]  R629      -2.9931643605232239e-01
    z[4,0,0]  R630      -7.7392721176147461e-01
    z[4,0,0]  R631      -0.832425057888031
    z[4,0,0]  R632      -4.8705756664276123e-01
    z[4,0,0]  R633      -5.5040019750595093e-01
    z[4,0,0]  R634      -4.6058323979377747e-01
    z[4,0,0]  R635      -4.6979156136512756e-01
    z[4,0,0]  R636      -7.4821233749389648e-01
    z[4,0,0]  R637      -0.479658305644989
    z[4,0,0]  R638      -4.6973422169685364e-01
    z[4,0,1]  R3        1
    z[4,0,1]  R39       -1
    z[4,0,1]  R518      -1
    z[4,0,1]  R519      1
    z[4,0,1]  R530      -2.2434207797050476e-01
    z[4,0,1]  R531      -4.1379917412996292e-02
    z[4,0,1]  R532      -4.6656742691993713e-02
    z[4,0,1]  R533      -1.2432451546192169e-01
    z[4,0,1]  R534      -7.1573257446289062e-02
    z[4,0,1]  R535      5.6521035730838776e-02
    z[4,0,1]  R536      -3.6553180217742920e-01
    z[4,0,1]  R537      -8.5622303187847137e-02
    z[4,0,1]  R538      0.0456363670527935
    z[4,0,1]  R539      -2.4456253647804260e-01
    z[4,0,1]  R540      8.4129935503005981e-01
    z[4,0,1]  R541      8.6757284402847290e-01
    z[4,0,1]  R542      8.4425538778305054e-01
    z[4,0,1]  R543      -4.5689931511878967e-01
    z[4,0,1]  R544      -7.9187095165252686e-01
    z[4,0,1]  R545      2.4552106857299805e-01
    z[4,0,1]  R546      -9.0515814721584320e-02
    z[4,0,1]  R547      -3.9412230253219604e-01
    z[4,0,1]  R548      -6.0985791683197021e-01
    z[4,0,1]  R549      -6.7751926183700562e-01
    z[4,0,1]  R550      -6.6503608226776123e-01
    z[4,0,1]  R551      -7.6249647140502930e-01
    z[4,0,1]  R552      -6.5101730823516846e-01
    z[4,0,1]  R553      -7.9949998855590820e-01
    z[4,0,1]  R554      -5.5410587787628174e-01
    z[4,0,1]  R555      -0.576320469379425
    z[4,0,1]  R556      -7.7463120222091675e-01
    z[4,0,1]  R557      2.1554206311702728e-01
    z[4,0,1]  R558      -0.500268816947937
    z[4,0,1]  R559      -6.4946311712265015e-01
    z[4,0,1]  R560      -3.6966410279273987e-01
    z[4,0,1]  R561      -5.5434852838516235e-01
    z[4,0,1]  R562      -5.8023804426193237e-01
    z[4,0,1]  R563      1.1254636943340302e-01
    z[4,0,1]  R564      1.1817237734794617e-01
    z[4,0,1]  R565      -2.1881256997585297e-01
    z[4,0,1]  R566      -8.0024182796478271e-02
    z[4,0,1]  R567      -2.2036722302436829e-01
    z[4,0,1]  R568      3.2096442580223083e-01
    z[4,0,1]  R569      -7.2960913181304932e-01
    z[4,0,1]  R570      -7.2324448823928833e-01
    z[4,0,1]  R571      -5.4733687639236450e-01
    z[4,0,1]  R572      -2.4741439521312714e-01
    z[4,0,1]  R573      -4.4586917757987976e-01
    z[4,0,1]  R574      -5.3672641515731812e-01
    z[4,0,1]  R575      -2.4713842570781708e-01
    z[4,0,1]  R576      -8.9190351963043213e-01
    z[4,0,1]  R577      3.3194816112518311e-01
    z[4,0,1]  R578      3.5491049289703369e-01
    z[4,0,1]  R579      0.244643896818161
    z[4,0,1]  R580      -3.2988885045051575e-01
    z[4,0,1]  R581      -6.9191831350326538e-01
    z[4,0,1]  R582      -8.0293434858322144e-01
    z[4,0,1]  R583      -5.7155334949493408e-01
    z[4,0,1]  R584      -4.9672827124595642e-01
    z[4,0,1]  R585      -2.3610962927341461e-01
    z[4,0,1]  R586      1.0668906569480896e-01
    z[4,0,1]  R587      1.1416645348072052e-01
    z[4,0,1]  R588      2.0661045610904694e-01
    z[4,0,1]  R589      -8.0154515802860260e-02
    z[4,0,1]  R590      -1.8110516667366028e-01
    z[4,0,1]  R591      1.2446816544979811e-03
    z[4,0,1]  R592      -2.5708785653114319e-01
    z[4,0,1]  R593      -2.1594421565532684e-01
    z[4,0,1]  R594      -1.6137482225894928e-01
    z[4,0,1]  R595      0.0124838100746274
    z[4,0,1]  R596      -2.2792570292949677e-01
    z[4,0,1]  R597      5.5811285972595215e-02
    z[4,0,1]  R598      -1.4057861268520355e-01
    z[4,0,1]  R599      -5.1473462581634521e-01
    z[4,0,1]  R600      -4.1156825423240662e-01
    z[4,0,1]  R601      -7.2181558609008789e-01
    z[4,0,1]  R602      -5.0044882297515869e-01
    z[4,0,1]  R603      -4.8834976553916931e-01
    z[4,0,1]  R604      3.0170795321464539e-01
    z[4,0,1]  R605      -2.7758213877677917e-01
    z[4,0,1]  R606      8.4900282323360443e-02
    z[4,0,1]  R607      1.8939383327960968e-01
    z[4,0,1]  R608      -4.7070616483688354e-01
    z[4,0,1]  R609      -4.6050909161567688e-01
    z[4,0,1]  R610      -8.8417333364486694e-01
    z[4,0,1]  R611      -2.8729760646820068e-01
    z[4,0,1]  R612      -6.2607473134994507e-01
    z[4,0,1]  R613      -7.9398363828659058e-01
    z[4,0,1]  R614      -9.0427374839782715e-01
    z[4,0,1]  R615      -6.6911959648132324e-01
    z[4,0,1]  R616      -3.4406265616416931e-01
    z[4,0,1]  R617      -5.9844875335693359e-01
    z[4,0,1]  R618      -5.7142537832260132e-01
    z[4,0,1]  R619      -6.6057282686233521e-01
    z[4,0,1]  R620      -1.2760999798774719e-01
    z[4,0,1]  R621      -5.6027692556381226e-01
    z[4,0,1]  R622      -5.0797986984252930e-01
    z[4,0,1]  R623      3.2867971062660217e-01
    z[4,0,1]  R624      8.6333960294723511e-02
    z[4,0,1]  R625      -4.6954333782196045e-01
    z[4,0,1]  R626      2.3565386235713959e-01
    z[4,0,1]  R627      4.2102980613708496e-01
    z[4,0,1]  R628      -1.0445768386125565e-01
    z[4,0,1]  R629      -1.2167669832706451e-01
    z[4,0,1]  R630      2.9350259900093079e-01
    z[4,0,1]  R631      3.5589879751205444e-01
    z[4,0,1]  R632      8.3448427915573120e-01
    z[4,0,1]  R633      7.3100918531417847e-01
    z[4,0,1]  R634      8.1843090057373047e-01
    z[4,0,1]  R635      7.9347169399261475e-01
    z[4,0,1]  R636      1.4243361353874207e-01
    z[4,0,1]  R637      7.6907247304916382e-01
    z[4,0,1]  R638      7.3240584135055542e-01
    z[4,0,2]  R4        1
    z[4,0,2]  R40       -1
    z[4,0,2]  R520      -1
    z[4,0,2]  R521      1
    z[4,0,2]  R530      -5.9244537353515625e-01
    z[4,0,2]  R531      -8.2150202989578247e-01
    z[4,0,2]  R532      -5.4357331991195679e-01
    z[4,0,2]  R533      -3.1353580951690674e-01
    z[4,0,2]  R534      -7.3006719350814819e-01
    z[4,0,2]  R535      -7.2983759641647339e-01
    z[4,0,2]  R536      -2.6255834102630615e-01
    z[4,0,2]  R537      -2.2652576863765717e-01
    z[4,0,2]  R538      -6.6095048189163208e-01
    z[4,0,2]  R539      -6.0441619157791138e-01
    z[4,0,2]  R540      1.1838949285447598e-02
    z[4,0,2]  R541      -8.1899136304855347e-02
    z[4,0,2]  R542      -4.5951315760612488e-01
    z[4,0,2]  R543      6.1652439832687378e-01
    z[4,0,2]  R544      2.8402274474501610e-02
    z[4,0,2]  R545      2.7462553977966309e-01
    z[4,0,2]  R546      4.0592372417449951e-01
    z[4,0,2]  R547      2.7861317619681358e-02
    z[4,0,2]  R548      2.7157512307167053e-01
    z[4,0,2]  R549      1.4036209881305695e-01
    z[4,0,2]  R550      -1.9590763747692108e-01
    z[4,0,2]  R551      -2.3073473572731018e-01
    z[4,0,2]  R552      -3.0537730455398560e-01
    z[4,0,2]  R553      2.0183049142360687e-01
    z[4,0,2]  R554      -2.9556852579116821e-01
    z[4,0,2]  R555      -4.0751591324806213e-01
    z[4,0,2]  R556      -1.1781888455152512e-01
    z[4,0,2]  R557      -6.2708705663681030e-02
    z[4,0,2]  R558      -7.0346496999263763e-02
    z[4,0,2]  R559      3.0369493365287781e-01
    z[4,0,2]  R560      -2.3955148458480835e-01
    z[4,0,2]  R561      -5.7545232772827148e-01
    z[4,0,2]  R562      9.1637238860130310e-02
    z[4,0,2]  R563      -5.8281220495700836e-02
    z[4,0,2]  R564      -2.0295043289661407e-01
    z[4,0,2]  R565      -1.2939724326133728e-01
    z[4,0,2]  R566      5.9550367295742035e-02
    z[4,0,2]  R567      -2.1915417909622192e-01
    z[4,0,2]  R568      -5.4754824377596378e-03
    z[4,0,2]  R569      2.2998669743537903e-01
    z[4,0,2]  R570      -3.3640664815902710e-01
    z[4,0,2]  R571      -2.1699997782707214e-01
    z[4,0,2]  R572      1.5533640980720520e-01
    z[4,0,2]  R573      -6.7132425308227539e-01
    z[4,0,2]  R574      -0.544070839881897
    z[4,0,2]  R575      1.1546090245246887e-01
    z[4,0,2]  R576      2.4799892306327820e-01
    z[4,0,2]  R577      -2.8383618593215942e-01
    z[4,0,2]  R578      7.4420824646949768e-02
    z[4,0,2]  R579      4.0437978506088257e-01
    z[4,0,2]  R580      5.6865561753511429e-02
    z[4,0,2]  R581      -4.4046363234519958e-01
    z[4,0,2]  R582      2.0109033584594727e-01
    z[4,0,2]  R583      -1.4814113080501556e-01
    z[4,0,2]  R584      -2.4655283987522125e-01
    z[4,0,2]  R585      -4.0472263097763062e-01
    z[4,0,2]  R586      7.9461358487606049e-02
    z[4,0,2]  R587      3.3187928795814514e-01
    z[4,0,2]  R588      3.6535346508026123e-01
    z[4,0,2]  R589      -0.506878137588501
    z[4,0,2]  R590      -4.2139717936515808e-01
    z[4,0,2]  R591      -6.9209235906600952e-01
    z[4,0,2]  R592      -8.3501911163330078e-01
    z[4,0,2]  R593      -2.2046999633312225e-01
    z[4,0,2]  R594      -7.1110002696514130e-02
    z[4,0,2]  R595      3.5653421282768250e-01
    z[4,0,2]  R596      8.5008360445499420e-02
    z[4,0,2]  R597      -0.0941428393125534
    z[4,0,2]  R598      1.8917587399482727e-01
    z[4,0,2]  R599      2.1824875473976135e-01
    z[4,0,2]  R600      -2.8268773108720779e-02
    z[4,0,2]  R601      1.5187076292932034e-02
    z[4,0,2]  R602      8.6479753255844116e-02
    z[4,0,2]  R603      4.6523684263229370e-01
    z[4,0,2]  R604      -3.9636015892028809e-02
    z[4,0,2]  R605      -1.7314006388187408e-01
    z[4,0,2]  R606      1.1506627500057220e-01
    z[4,0,2]  R607      3.6588132381439209e-01
    z[4,0,2]  R608      4.2354875802993774e-01
    z[4,0,2]  R609      -0.427571177482605
    z[4,0,2]  R610      -2.0107574760913849e-01
    z[4,0,2]  R611      -3.7276017665863037e-01
    z[4,0,2]  R612      -3.8085898756980896e-01
    z[4,0,2]  R613      -1.2745060026645660e-01
    z[4,0,2]  R614      -4.2258203029632568e-02
    z[4,0,2]  R615      -8.9466765522956848e-02
    z[4,0,2]  R616      -1.2418854981660843e-01
    z[4,0,2]  R617      -4.1712176799774170e-01
    z[4,0,2]  R618      -3.6077263951301575e-01
    z[4,0,2]  R619      -5.7610249519348145e-01
    z[4,0,2]  R620      -5.0727421045303345e-01
    z[4,0,2]  R621      8.7560452520847321e-02
    z[4,0,2]  R622      6.7385137081146240e-01
    z[4,0,2]  R623      -0.0605199821293354
    z[4,0,2]  R624      7.0161208510398865e-02
    z[4,0,2]  R625      5.4754996299743652e-01
    z[4,0,2]  R626      4.1273349523544312e-01
    z[4,0,2]  R627      -4.3047182261943817e-02
    z[4,0,2]  R628      0.261992871761322
    z[4,0,2]  R629      1.4161027036607265e-02
    z[4,0,2]  R630      6.5739743411540985e-02
    z[4,0,2]  R631      4.7190878540277481e-02
    z[4,0,2]  R632      1.5756408870220184e-01
    z[4,0,2]  R633      0.00896039791405201
    z[4,0,2]  R634      2.2195219993591309e-01
    z[4,0,2]  R635      4.6186674386262894e-02
    z[4,0,2]  R636      0.515374481678009
    z[4,0,2]  R637      -5.8893103152513504e-02
    z[4,0,2]  R638      2.9958483576774597e-01
    z[4,0,3]  R5        1
    z[4,0,3]  R41       -1
    z[4,0,3]  R522      -1
    z[4,0,3]  R523      1
    z[4,0,3]  R530      2.3699685931205750e-01
    z[4,0,3]  R531      1.1154517531394958e-01
    z[4,0,3]  R532      -8.6395636200904846e-02
    z[4,0,3]  R533      1.1555530875921249e-01
    z[4,0,3]  R534      1.3171684741973877e-01
    z[4,0,3]  R535      3.5918179154396057e-01
    z[4,0,3]  R536      -5.3258669376373291e-01
    z[4,0,3]  R537      4.1792401671409607e-01
    z[4,0,3]  R538      -9.7393877804279327e-02
    z[4,0,3]  R539      -2.8344443440437317e-01
    z[4,0,3]  R540      -0.271945595741272
    z[4,0,3]  R541      -1.5372280776500702e-01
    z[4,0,3]  R542      -1.1726742237806320e-01
    z[4,0,3]  R543      1.5897387266159058e-01
    z[4,0,3]  R544      5.3039681911468506e-01
    z[4,0,3]  R545      4.7791481018066406e-01
    z[4,0,3]  R546      4.5172640681266785e-01
    z[4,0,3]  R547      6.5011823177337646e-01
    z[4,0,3]  R548      6.2212830781936646e-01
    z[4,0,3]  R549      -1.4795914292335510e-01
    z[4,0,3]  R550      6.3086384534835815e-01
    z[4,0,3]  R551      -2.1271225810050964e-01
    z[4,0,3]  R552      1.8182241916656494e-01
    z[4,0,3]  R553      4.9371698498725891e-01
    z[4,0,3]  R554      2.0419631898403168e-01
    z[4,0,3]  R555      -2.2921408712863922e-01
    z[4,0,3]  R556      -2.2812442481517792e-01
    z[4,0,3]  R557      -0.72444748878479
    z[4,0,3]  R558      3.3810603618621826e-01
    z[4,0,3]  R559      1.8640232086181641e-01
    z[4,0,3]  R560      -4.8062512278556824e-01
    z[4,0,3]  R561      -0.483710378408432
    z[4,0,3]  R562      5.6191053241491318e-02
    z[4,0,3]  R563      -3.6831229925155640e-01
    z[4,0,3]  R564      1.6339768469333649e-01
    z[4,0,3]  R565      1.0380907356739044e-01
    z[4,0,3]  R566      1.1003208905458450e-01
    z[4,0,3]  R567      6.5903908014297485e-01
    z[4,0,3]  R568      -3.2897201180458069e-01
    z[4,0,3]  R569      -1.5643297135829926e-01
    z[4,0,3]  R570      3.9144212007522583e-01
    z[4,0,3]  R571      -0.00906385201960802
    z[4,0,3]  R572      -4.2518965899944305e-02
    z[4,0,3]  R573      -4.3219098448753357e-01
    z[4,0,3]  R574      2.7163645625114441e-01
    z[4,0,3]  R575      2.2988820075988770e-01
    z[4,0,3]  R576      -6.2464926391839981e-02
    z[4,0,3]  R577      3.9827436208724976e-01
    z[4,0,3]  R578      3.6196565628051758e-01
    z[4,0,3]  R579      3.5333672165870667e-01
    z[4,0,3]  R580      -2.4791575968265533e-01
    z[4,0,3]  R581      -1.5276212990283966e-01
    z[4,0,3]  R582      3.0615553259849548e-01
    z[4,0,3]  R583      2.4574624840170145e-03
    z[4,0,3]  R584      1.8979637324810028e-01
    z[4,0,3]  R585      -1.6697503626346588e-01
    z[4,0,3]  R586      -0.798019289970398
    z[4,0,3]  R587      -8.2056099176406860e-01
    z[4,0,3]  R588      4.1949599981307983e-01
    z[4,0,3]  R589      -1.4083890616893768e-01
    z[4,0,3]  R590      1.3286863267421722e-01
    z[4,0,3]  R591      -3.0317762494087219e-01
    z[4,0,3]  R592      -3.6674609780311584e-01
    z[4,0,3]  R593      -2.2699026390910149e-02
    z[4,0,3]  R594      -3.8814797997474670e-01
    z[4,0,3]  R595      -0.373947411775589
    z[4,0,3]  R596      -2.1999992430210114e-01
    z[4,0,3]  R597      -1.5195679850876331e-02
    z[4,0,3]  R598      -3.1144765019416809e-01
    z[4,0,3]  R599      7.1903622150421143e-01
    z[4,0,3]  R600      2.5185352563858032e-01
    z[4,0,3]  R601      5.0359004735946655e-01
    z[4,0,3]  R602      7.3543775081634521e-01
    z[4,0,3]  R603      4.9513211846351624e-01
    z[4,0,3]  R604      -0.0909363180398941
    z[4,0,3]  R605      1.9417591392993927e-01
    z[4,0,3]  R606      1.8482092022895813e-01
    z[4,0,3]  R607      4.2545256018638611e-01
    z[4,0,3]  R608      -5.0914859771728516e-01
    z[4,0,3]  R609      4.2381274700164795e-01
    z[4,0,3]  R610      3.7916150689125061e-01
    z[4,0,3]  R611      3.7722736597061157e-01
    z[4,0,3]  R612      4.4775003194808960e-01
    z[4,0,3]  R613      -1.9667898304760456e-03
    z[4,0,3]  R614      1.3694278895854950e-01
    z[4,0,3]  R615      6.7721712589263916e-01
    z[4,0,3]  R616      4.9713057279586792e-01
    z[4,0,3]  R617      -2.2889813408255577e-02
    z[4,0,3]  R618      3.0973119661211967e-02
    z[4,0,3]  R619      -8.1840313971042633e-02
    z[4,0,3]  R620      1.0280106961727142e-01
    z[4,0,3]  R621      4.7158437967300415e-01
    z[4,0,3]  R622      -1.5477801859378815e-01
    z[4,0,3]  R623      -8.3408242464065552e-01
    z[4,0,3]  R624      -8.8260644674301147e-01
    z[4,0,3]  R625      -4.9218437075614929e-01
    z[4,0,3]  R626      3.1000250577926636e-01
    z[4,0,3]  R627      2.8603506088256836e-01
    z[4,0,3]  R628      -7.5672513246536255e-01
    z[4,0,3]  R629      -9.1456425189971924e-01
    z[4,0,3]  R630      2.2730968892574310e-01
    z[4,0,3]  R631      2.5798153132200241e-02
    z[4,0,3]  R632      -5.1111515611410141e-02
    z[4,0,3]  R633      1.7404921352863312e-01
    z[4,0,3]  R634      -1.2447923421859741e-01
    z[4,0,3]  R635      -2.0280398428440094e-01
    z[4,0,3]  R636      -9.4996467232704163e-02
    z[4,0,3]  R637      -3.3122873306274414e-01
    z[4,0,3]  R638      -2.6657733321189880e-01
    z[4,0,4]  R6        1
    z[4,0,4]  R42       -1
    z[4,0,4]  R524      -1
    z[4,0,4]  R525      1
    z[4,0,4]  R530      -5.9807217121124268e-01
    z[4,0,4]  R531      -4.9848622083663940e-01
    z[4,0,4]  R532      -6.5336924791336060e-01
    z[4,0,4]  R533      -7.2163826227188110e-01
    z[4,0,4]  R534      -3.5952815413475037e-01
    z[4,0,4]  R535      -4.0824940800666809e-01
    z[4,0,4]  R536      3.1452366709709167e-01
    z[4,0,4]  R537      -0.684838056564331
    z[4,0,4]  R538      -4.1711923480033875e-01
    z[4,0,4]  R539      1.0789326392114162e-02
    z[4,0,4]  R540      -1.2407668679952621e-01
    z[4,0,4]  R541      -1.8454334139823914e-01
    z[4,0,4]  R542      1.1577981710433960e-01
    z[4,0,4]  R543      -3.2115232944488525e-01
    z[4,0,4]  R544      -4.9837838858366013e-02
    z[4,0,4]  R545      -3.9657387137413025e-01
    z[4,0,4]  R546      -0.182534858584404
    z[4,0,4]  R547      3.5078135132789612e-01
    z[4,0,4]  R548      5.4858420044183731e-02
    z[4,0,4]  R549      1.3900396227836609e-01
    z[4,0,4]  R550      2.7258116006851196e-01
    z[4,0,4]  R551      4.3921627104282379e-02
    z[4,0,4]  R552      5.8377593755722046e-01
    z[4,0,4]  R553      8.3564937114715576e-02
    z[4,0,4]  R554      1.8081174790859222e-01
    z[4,0,4]  R555      4.6877473592758179e-01
    z[4,0,4]  R556      1.3864706456661224e-01
    z[4,0,4]  R557      -2.5935885310173035e-01
    z[4,0,4]  R558      -4.4898489117622375e-01
    z[4,0,4]  R559      -2.8888520598411560e-01
    z[4,0,4]  R560      -5.4572808742523193e-01
    z[4,0,4]  R561      1.7076827585697174e-02
    z[4,0,4]  R562      -0.0605459026992321
    z[4,0,4]  R563      -8.3162176609039307e-01
    z[4,0,4]  R564      -2.4538438022136688e-01
    z[4,0,4]  R565      -6.3393193483352661e-01
    z[4,0,4]  R566      -4.3460991978645325e-01
    z[4,0,4]  R567      -4.3667531013488770e-01
    z[4,0,4]  R568      -3.4096285700798035e-01
    z[4,0,4]  R569      -3.3043101429939270e-01
    z[4,0,4]  R570      -6.0014687478542328e-02
    z[4,0,4]  R571      -4.6652728319168091e-01
    z[4,0,4]  R572      -3.2168093323707581e-01
    z[4,0,4]  R573      -1.8092378973960876e-01
    z[4,0,4]  R574      1.0825133323669434e-01
    z[4,0,4]  R575      1.2555750086903572e-02
    z[4,0,4]  R576      3.4217610955238342e-01
    z[4,0,4]  R577      -5.0948488712310791e-01
    z[4,0,4]  R578      1.9620832800865173e-01
    z[4,0,4]  R579      1.0042093694210052e-01
    z[4,0,4]  R580      -8.4013324975967407e-01
    z[4,0,4]  R581      4.8353976011276245e-01
    z[4,0,4]  R582      -2.5056087970733643e-01
    z[4,0,4]  R583      -3.0108615756034851e-01
    z[4,0,4]  R584      -3.7153720855712891e-02
    z[4,0,4]  R585      -2.7126485109329224e-01
    z[4,0,4]  R586      3.7175214290618896e-01
    z[4,0,4]  R587      2.4538248777389526e-01
    z[4,0,4]  R588      -6.3851051032543182e-02
    z[4,0,4]  R589      -6.8540310859680176e-01
    z[4,0,4]  R590      -6.5990060567855835e-01
    z[4,0,4]  R591      -6.2889808416366577e-01
    z[4,0,4]  R592      -2.1133351325988770e-01
    z[4,0,4]  R593      -8.2144963741302490e-01
    z[4,0,4]  R594      -4.4403173960745335e-03
    z[4,0,4]  R595      2.0590825378894806e-01
    z[4,0,4]  R596      2.5579905509948730e-01
    z[4,0,4]  R597      1.1942632496356964e-01
    z[4,0,4]  R598      -5.9767484664916992e-02
    z[4,0,4]  R599      -9.8800763487815857e-02
    z[4,0,4]  R600      0.721690833568573
    z[4,0,4]  R601      2.2953312098979950e-01
    z[4,0,4]  R602      0.0649818480014801
    z[4,0,4]  R603      1.4219713211059570e-01
    z[4,0,4]  R604      2.5511008501052856e-01
    z[4,0,4]  R605      3.0260652303695679e-01
    z[4,0,4]  R606      4.7169774770736694e-01
    z[4,0,4]  R607      -8.0509938299655914e-02
    z[4,0,4]  R608      -2.5258013606071472e-01
    z[4,0,4]  R609      -2.5747594237327576e-01
    z[4,0,4]  R610      1.4884701371192932e-01
    z[4,0,4]  R611      -3.3828923106193542e-01
    z[4,0,4]  R612      1.8099553883075714e-01
    z[4,0,4]  R613      -8.2265391945838928e-02
    z[4,0,4]  R614      8.9658334851264954e-02
    z[4,0,4]  R615      -4.6158339828252792e-02
    z[4,0,4]  R616      -4.5031303167343140e-01
    z[4,0,4]  R617      2.3909020423889160e-01
    z[4,0,4]  R618      2.5913387537002563e-01
    z[4,0,4]  R619      1.4467741549015045e-01
    z[4,0,4]  R620      -5.0215190649032593e-01
    z[4,0,4]  R621      -5.0982785224914551e-01
    z[4,0,4]  R622      0.330519437789917
    z[4,0,4]  R623      3.7079009413719177e-01
    z[4,0,4]  R624      2.2420334815979004e-01
    z[4,0,4]  R625      8.6895991116762161e-03
    z[4,0,4]  R626      1.1299183219671249e-01
    z[4,0,4]  R627      1.9198693335056305e-01
    z[4,0,4]  R628      3.3922556042671204e-01
    z[4,0,4]  R629      1.6213682293891907e-01
    z[4,0,4]  R630      4.4171714782714844e-01
    z[4,0,4]  R631      -1.3314799405634403e-02
    z[4,0,4]  R632      -1.9462814927101135e-01
    z[4,0,4]  R633      -1.4693741500377655e-01
    z[4,0,4]  R634      9.6453763544559479e-02
    z[4,0,4]  R635      -2.9710020869970322e-02
    z[4,0,4]  R636      3.5078969597816467e-01
    z[4,0,4]  R637      -1.6486944258213043e-01
    z[4,0,4]  R638      -0.0299517959356308
    z[4,0,5]  R7        1
    z[4,0,5]  R43       -1
    z[4,0,5]  R526      -1
    z[4,0,5]  R527      1
    z[4,0,5]  R530      2.7588501572608948e-01
    z[4,0,5]  R531      0.0768398642539978
    z[4,0,5]  R532      4.8011988401412964e-01
    z[4,0,5]  R533      4.0588292479515076e-01
    z[4,0,5]  R534      5.3919738531112671e-01
    z[4,0,5]  R535      3.0846032500267029e-01
    z[4,0,5]  R536      -1.7066171392798424e-02
    z[4,0,5]  R537      4.3200677633285522e-01
    z[4,0,5]  R538      7.2658412158489227e-02
    z[4,0,5]  R539      3.8039374351501465e-01
    z[4,0,5]  R540      1.8794685602188110e-01
    z[4,0,5]  R541      3.1153056025505066e-01
    z[4,0,5]  R542      3.4912928938865662e-02
    z[4,0,5]  R543      1.9149954617023468e-01
    z[4,0,5]  R544      -4.0843873284757137e-03
    z[4,0,5]  R545      2.9163593053817749e-01
    z[4,0,5]  R546      5.9292250871658325e-01
    z[4,0,5]  R547      3.4390920400619507e-01
    z[4,0,5]  R548      2.2979740798473358e-01
    z[4,0,5]  R549      2.3302505910396576e-01
    z[4,0,5]  R550      8.0706931650638580e-02
    z[4,0,5]  R551      -5.3153578191995621e-02
    z[4,0,5]  R552      -1.1309825628995895e-01
    z[4,0,5]  R553      -2.2733679413795471e-01
    z[4,0,5]  R554      5.2110069990158081e-01
    z[4,0,5]  R555      2.2259102761745453e-01
    z[4,0,5]  R556      4.0817445516586304e-01
    z[4,0,5]  R557      1.9557489454746246e-01
    z[4,0,5]  R558      -2.4819038808345795e-01
    z[4,0,5]  R559      1.9170695543289185e-01
    z[4,0,5]  R560      3.0538302659988403e-01
    z[4,0,5]  R561      5.1258746534585953e-02
    z[4,0,5]  R562      4.7907531261444092e-01
    z[4,0,5]  R563      -0.314779132604599
    z[4,0,5]  R564      9.0232640504837036e-01
    z[4,0,5]  R565      1.3097949326038361e-01
    z[4,0,5]  R566      -5.8001402765512466e-02
    z[4,0,5]  R567      3.7141764163970947e-01
    z[4,0,5]  R568      1.2606818974018097e-01
    z[4,0,5]  R569      -1.2264557927846909e-01
    z[4,0,5]  R570      1.4420942962169647e-01
    z[4,0,5]  R571      -2.9039919376373291e-01
    z[4,0,5]  R572      1.4926192164421082e-01
    z[4,0,5]  R573      -0.0517929382622242
    z[4,0,5]  R574      -0.0381213054060936
    z[4,0,5]  R575      1.5846368670463562e-01
    z[4,0,5]  R576      1.2515859305858612e-01
    z[4,0,5]  R577      3.9180997014045715e-01
    z[4,0,5]  R578      -1.6171494126319885e-01
    z[4,0,5]  R579      -8.8415652513504028e-02
    z[4,0,5]  R580      -3.2338467240333557e-01
    z[4,0,5]  R581      1.0416987538337708e-01
    z[4,0,5]  R582      -1.7621999979019165e-01
    z[4,0,5]  R583      -3.2661595940589905e-01
    z[4,0,5]  R584      -4.2096513509750366e-01
    z[4,0,5]  R585      -4.1891392320394516e-02
    z[4,0,5]  R586      -1.3399402797222137e-01
    z[4,0,5]  R587      -1.3040751218795776e-01
    z[4,0,5]  R588      -0.0849934071302414
    z[4,0,5]  R589      4.6116065979003906e-01
    z[4,0,5]  R590      5.4654383659362793e-01
    z[4,0,5]  R591      1.3602770864963531e-01
    z[4,0,5]  R592      8.8637866079807281e-02
    z[4,0,5]  R593      3.6333236098289490e-01
    z[4,0,5]  R594      7.3513254523277283e-02
    z[4,0,5]  R595      1.3788402080535889e-01
    z[4,0,5]  R596      6.0341589152812958e-02
    z[4,0,5]  R597      -1.3995829224586487e-01
    z[4,0,5]  R598      1.3770771026611328e-01
    z[4,0,5]  R599      -2.8934234380722046e-01
    z[4,0,5]  R600      -2.0392332226037979e-02
    z[4,0,5]  R601      -3.6336994171142578e-01
    z[4,0,5]  R602      -2.1523636579513550e-01
    z[4,0,5]  R603      -4.4337805360555649e-02
    z[4,0,5]  R604      5.9535790234804153e-02
    z[4,0,5]  R605      -1.4216606318950653e-01
    z[4,0,5]  R606      1.1818820238113403e-01
    z[4,0,5]  R607      -2.3110084235668182e-02
    z[4,0,5]  R608      -6.1451215296983719e-02
    z[4,0,5]  R609      -2.3863169550895691e-01
    z[4,0,5]  R610      2.8609130531549454e-03
    z[4,0,5]  R611      -3.4703877568244934e-01
    z[4,0,5]  R612      -8.0513760447502136e-02
    z[4,0,5]  R613      -2.5317358970642090e-01
    z[4,0,5]  R614      -0.0852438285946846
    z[4,0,5]  R615      -1.1414396017789841e-01
    z[4,0,5]  R616      -3.7345707416534424e-01
    z[4,0,5]  R617      -1.8260811269283295e-01
    z[4,0,5]  R618      1.8850685656070709e-01
    z[4,0,5]  R619      -3.1865498423576355e-01
    z[4,0,5]  R620      -6.2541222572326660e-01
    z[4,0,5]  R621      -4.9563441425561905e-02
    z[4,0,5]  R622      2.4108274281024933e-01
    z[4,0,5]  R623      -8.9520506560802460e-02
    z[4,0,5]  R624      -4.5341745018959045e-02
    z[4,0,5]  R625      3.4138467907905579e-01
    z[4,0,5]  R626      1.6713395714759827e-01
    z[4,0,5]  R627      5.1403380930423737e-02
    z[4,0,5]  R628      -1.7885808646678925e-01
    z[4,0,5]  R629      -1.5099354088306427e-01
    z[4,0,5]  R630      -3.3542364835739136e-02
    z[4,0,5]  R631      4.2033061385154724e-01
    z[4,0,5]  R632      -3.2964695245027542e-02
    z[4,0,5]  R633      -2.6514637470245361e-01
    z[4,0,5]  R634      1.6184569895267487e-01
    z[4,0,5]  R635      2.8925737738609314e-01
    z[4,0,5]  R636      -1.4822500944137573e-01
    z[4,0,5]  R637      -0.074454665184021
    z[4,0,5]  R638      1.5261600911617279e-01
    z[4,0,6]  R8        1
    z[4,0,6]  R44       -1
    z[4,0,6]  R528      -1
    z[4,0,6]  R529      1
    z[4,0,6]  R530      -3.2459592819213867e-01
    z[4,0,6]  R531      4.8325583338737488e-02
    z[4,0,6]  R532      -3.5433974117040634e-02
    z[4,0,6]  R533      4.1947695612907410e-01
    z[4,0,6]  R534      9.6513405442237854e-02
    z[4,0,6]  R535      2.2284905612468719e-01
    z[4,0,6]  R536      -2.0006555318832397e-01
    z[4,0,6]  R537      2.1568414568901062e-01
    z[4,0,6]  R538      5.8561146259307861e-01
    z[4,0,6]  R539      2.5013424456119537e-03
    z[4,0,6]  R540      1.3021971285343170e-01
    z[4,0,6]  R541      -2.3854376375675201e-01
    z[4,0,6]  R542      -1.7075374722480774e-01
    z[4,0,6]  R543      1.8598724901676178e-01
    z[4,0,6]  R544      2.5466856360435486e-01
    z[4,0,6]  R545      -4.8353332281112671e-01
    z[4,0,6]  R546      -3.5868138074874878e-01
    z[4,0,6]  R547      -3.9329206943511963e-01
    z[4,0,6]  R548      -2.2811383008956909e-01
    z[4,0,6]  R549      6.4580667018890381e-01
    z[4,0,6]  R550      -1.5585084259510040e-01
    z[4,0,6]  R551      -4.4793391227722168e-01
    z[4,0,6]  R552      -1.7386395484209061e-02
    z[4,0,6]  R553      -1.2443863600492477e-01
    z[4,0,6]  R554      4.2697262018918991e-02
    z[4,0,6]  R555      -2.4199962615966797e-02
    z[4,0,6]  R556      2.6031273603439331e-01
    z[4,0,6]  R557      1.9470381736755371e-01
    z[4,0,6]  R558      2.6132947206497192e-01
    z[4,0,6]  R559      -0.398084819316864
    z[4,0,6]  R560      2.4788361787796021e-01
    z[4,0,6]  R561      3.4689265489578247e-01
    z[4,0,6]  R562      -1.6337784007191658e-02
    z[4,0,6]  R563      -8.7756089866161346e-02
    z[4,0,6]  R564      -7.9994276165962219e-03
    z[4,0,6]  R565      4.4153681397438049e-01
    z[4,0,6]  R566      -2.6913493871688843e-01
    z[4,0,6]  R567      -1.4677749946713448e-02
    z[4,0,6]  R568      -3.1525948643684387e-01
    z[4,0,6]  R569      1.6807551681995392e-01
    z[4,0,6]  R570      4.3010881543159485e-01
    z[4,0,6]  R571      -1.3056711852550507e-01
    z[4,0,6]  R572      -1.6935016214847565e-01
    z[4,0,6]  R573      2.6247268915176392e-01
    z[4,0,6]  R574      -2.4118547141551971e-01
    z[4,0,6]  R575      -6.1556601524353027e-01
    z[4,0,6]  R576      7.9690247774124146e-02
    z[4,0,6]  R577      -2.6254606246948242e-01
    z[4,0,6]  R578      -1.0532230883836746e-01
    z[4,0,6]  R579      5.4940257221460342e-02
    z[4,0,6]  R580      6.6073901951313019e-02
    z[4,0,6]  R581      2.3335088789463043e-01
    z[4,0,6]  R582      1.4274649322032928e-01
    z[4,0,6]  R583      2.8746458888053894e-01
    z[4,0,6]  R584      -6.6539153456687927e-02
    z[4,0,6]  R585      1.5067237615585327e-01
    z[4,0,6]  R586      -1.2331873923540115e-01
    z[4,0,6]  R587      -1.6254171729087830e-01
    z[4,0,6]  R588      -5.4477435350418091e-01
    z[4,0,6]  R589      -8.2849457859992981e-02
    z[4,0,6]  R590      -1.8272195756435394e-01
    z[4,0,6]  R591      2.8193622827529907e-02
    z[4,0,6]  R592      -1.0989258438348770e-01
    z[4,0,6]  R593      3.0912297964096069e-01
    z[4,0,6]  R594      -1.7003765329718590e-02
    z[4,0,6]  R595      8.9599706232547760e-02
    z[4,0,6]  R596      3.8631439208984375e-01
    z[4,0,6]  R597      9.9594242870807648e-02
    z[4,0,6]  R598      3.9882853627204895e-01
    z[4,0,6]  R599      -1.9392198324203491e-01
    z[4,0,6]  R600      -2.1297354996204376e-01
    z[4,0,6]  R601      -1.1866380274295807e-01
    z[4,0,6]  R602      -1.7210614681243896e-01
    z[4,0,6]  R603      2.8479138016700745e-01
    z[4,0,6]  R604      0.158565953373909
    z[4,0,6]  R605      1.6385369002819061e-01
    z[4,0,6]  R606      -6.5212212502956390e-02
    z[4,0,6]  R607      1.6607193648815155e-01
    z[4,0,6]  R608      -3.8209420442581177e-01
    z[4,0,6]  R609      2.0963855087757111e-02
    z[4,0,6]  R610      -9.7138516604900360e-02
    z[4,0,6]  R611      1.5419182181358337e-01
    z[4,0,6]  R612      -2.4525739252567291e-01
    z[4,0,6]  R613      -1.9927522540092468e-01
    z[4,0,6]  R614      3.6211568117141724e-01
    z[4,0,6]  R615      -2.1221902966499329e-01
    z[4,0,6]  R616      -2.3844359815120697e-01
    z[4,0,6]  R617      3.1876003742218018e-01
    z[4,0,6]  R618      1.4437088370323181e-01
    z[4,0,6]  R619      2.4518595635890961e-01
    z[4,0,6]  R620      0.22120301425457
    z[4,0,6]  R621      2.5697039440274239e-02
    z[4,0,6]  R622      -3.0606296658515930e-01
    z[4,0,6]  R623      -5.0941254943609238e-02
    z[4,0,6]  R624      -1.0018956847488880e-02
    z[4,0,6]  R625      -0.314046174287796
    z[4,0,6]  R626      1.0457421094179153e-01
    z[4,0,6]  R627      -4.0676867961883545e-01
    z[4,0,6]  R628      1.7006288468837738e-01
    z[4,0,6]  R629      -0.0994422510266304
    z[4,0,6]  R630      -2.5032436847686768e-01
    z[4,0,6]  R631      2.5631364434957504e-02
    z[4,0,6]  R632      -2.2855636198073626e-03
    z[4,0,6]  R633      -2.0104375481605530e-01
    z[4,0,6]  R634      -1.3333666324615479e-01
    z[4,0,6]  R635      -1.4793017506599426e-01
    z[4,0,6]  R636      1.5221193432807922e-02
    z[4,0,6]  R637      1.8041402101516724e-01
    z[4,0,6]  R638      2.4068281054496765e-01
    z[1,2,0]  R11       -1
    z[1,2,0]  R20       1
    z[1,2,0]  R703      -1
    z[1,2,0]  R704      1
    z[1,2,0]  R717      0.723736584186554
    z[1,2,0]  R718      8.0472415685653687e-01
    z[1,2,0]  R719      6.1697083711624146e-01
    z[1,2,0]  R720      6.5605306625366211e-01
    z[1,2,0]  R721      8.8712280988693237e-01
    z[1,2,0]  R722      8.8229048252105713e-01
    z[1,2,0]  R723      8.9311712980270386e-01
    z[1,2,0]  R724      9.1823190450668335e-01
    z[1,2,0]  R725      8.4810262918472290e-01
    z[1,2,0]  R726      8.6877566576004028e-01
    z[1,2,0]  R727      -2.4355600774288177e-01
    z[1,2,0]  R728      -8.6646175384521484e-01
    z[1,2,0]  R729      -1.7858077585697174e-01
    z[1,2,0]  R730      -3.5714778304100037e-01
    z[1,2,0]  R731      -7.5557577610015869e-01
    z[1,2,0]  R732      -7.6985865831375122e-01
    z[1,2,0]  R733      -7.5257080793380737e-01
    z[1,2,0]  R734      -1.5396592207252979e-02
    z[1,2,0]  R735      -1.4446650445461273e-01
    z[1,2,0]  R736      8.9831940829753876e-02
    z[1,2,0]  R737      -4.6918381005525589e-02
    z[1,2,0]  R738      1.3612688519060612e-02
    z[1,2,0]  R739      -7.2523248195648193e-01
    z[1,2,0]  R740      -2.0390337333083153e-02
    z[1,2,0]  R741      2.3649508133530617e-02
    z[1,2,0]  R742      -7.7637803554534912e-01
    z[1,2,0]  R743      -7.3027008771896362e-01
    z[1,2,0]  R744      -7.8857392072677612e-01
    z[1,2,0]  R745      0.0638904869556427
    z[1,2,0]  R746      -0.730022668838501
    z[1,2,0]  R747      3.2288023829460144e-01
    z[1,2,0]  R748      1.6156212985515594e-01
    z[1,2,0]  R749      2.2361817955970764e-01
    z[1,2,0]  R750      -7.8468585014343262e-01
    z[1,2,0]  R751      -7.9549568891525269e-01
    z[1,2,0]  R752      -8.5130012035369873e-01
    z[1,2,0]  R753      -0.858471155166626
    z[1,2,0]  R754      -8.3502292633056641e-01
    z[1,2,0]  R755      -8.7198764085769653e-01
    z[1,2,0]  R756      -7.3678523302078247e-01
    z[1,2,0]  R757      2.4792306125164032e-01
    z[1,2,0]  R758      3.6198583245277405e-01
    z[1,2,0]  R759      1.3135664165019989e-01
    z[1,2,0]  R760      -8.4073919057846069e-01
    z[1,2,0]  R761      -7.6478409767150879e-01
    z[1,2,0]  R762      -7.9939109086990356e-01
    z[1,2,0]  R763      -7.9929852485656738e-01
    z[1,2,0]  R764      -7.9075801372528076e-01
    z[1,2,0]  R765      -8.4291136264801025e-01
    z[1,2,0]  R766      -4.1825491189956665e-01
    z[1,2,0]  R767      1.5854188799858093e-01
    z[1,2,0]  R768      -9.3071717023849487e-01
    z[1,2,0]  R769      -4.7545678913593292e-02
    z[1,2,0]  R770      -0.812671959400177
    z[1,2,0]  R771      -7.1106845140457153e-01
    z[1,2,0]  R772      -6.4418500661849976e-01
    z[1,2,0]  R773      -8.2161104679107666e-01
    z[1,2,0]  R774      -3.3492672443389893e-01
    z[1,2,0]  R775      -7.1009427309036255e-01
    z[1,2,0]  R776      -8.5085999965667725e-01
    z[1,2,0]  R777      -8.4011381864547729e-01
    z[1,2,0]  R778      -8.2892262935638428e-01
    z[1,2,0]  R779      -6.6660982370376587e-01
    z[1,2,0]  R780      -8.4759056568145752e-01
    z[1,2,0]  R781      -7.2158157825469971e-01
    z[1,2,0]  R782      -8.4859234094619751e-01
    z[1,2,0]  R783      -3.8933184742927551e-01
    z[1,2,0]  R784      -6.2131547927856445e-01
    z[1,2,0]  R785      2.4689945578575134e-01
    z[1,2,0]  R786      1.7999957501888275e-01
    z[1,2,0]  R787      -8.6880499124526978e-01
    z[1,2,0]  R788      -3.5068488121032715e-01
    z[1,2,0]  R789      -7.1212485432624817e-02
    z[1,2,0]  R790      -0.813671350479126
    z[1,2,0]  R791      -8.9947231113910675e-02
    z[1,2,0]  R792      2.4146883189678192e-01
    z[1,2,0]  R793      -6.0453188419342041e-01
    z[1,2,0]  R794      -1.4398542046546936e-01
    z[1,2,0]  R795      -4.0792167186737061e-01
    z[1,2,0]  R796      -2.6940107345581055e-01
    z[1,2,0]  R797      -0.852932870388031
    z[1,2,0]  R798      -3.3950966596603394e-01
    z[1,2,0]  R799      -1.7837733030319214e-01
    z[1,2,0]  R800      -1.7302061617374420e-01
    z[1,2,0]  R801      -5.4825592041015625e-01
    z[1,2,0]  R802      -1.2178809195756912e-01
    z[1,2,0]  R803      2.0942500233650208e-01
    z[1,2,0]  R804      -0.0467689111828804
    z[1,2,0]  R805      2.5784561038017273e-01
    z[1,2,0]  R806      1.8484315276145935e-01
    z[1,2,0]  R807      -2.8594323992729187e-01
    z[1,2,0]  R808      -7.4660068750381470e-01
    z[1,2,0]  R809      -7.9481208324432373e-01
    z[1,2,0]  R810      -1.2942856550216675e-01
    z[1,2,0]  R811      -4.0330997109413147e-01
    z[1,2,0]  R812      1.4957337081432343e-01
    z[1,2,0]  R813      3.4764219075441360e-02
    z[1,2,0]  R814      3.4324326552450657e-03
    z[1,2,0]  R815      1.9561995286494493e-03
    z[1,2,0]  R816      0.251740038394928
    z[1,2,0]  R817      -5.9558898210525513e-02
    z[1,2,0]  R818      1.8688710033893585e-01
    z[1,2,0]  R819      4.0684661269187927e-01
    z[1,2,0]  R820      5.0825828313827515e-01
    z[1,2,0]  R821      3.8950565457344055e-01
    z[1,2,0]  R822      3.7066829204559326e-01
    z[1,2,0]  R823      1.5516020357608795e-01
    z[1,2,0]  R824      4.5007619261741638e-01
    z[1,2,0]  R825      3.0709198117256165e-01
    z[1,2,0]  R826      -8.9899547398090363e-02
    z[1,2,0]  R827      -5.0068795680999756e-01
    z[1,2,0]  R828      -1.9401873648166656e-01
    z[1,2,0]  R829      -5.2254962921142578e-01
    z[1,2,0]  R830      -2.0976625382900238e-01
    z[1,2,0]  R831      -3.5914450883865356e-01
    z[1,2,0]  R832      -2.2353176772594452e-01
    z[1,2,0]  R833      -2.3866747319698334e-01
    z[1,2,0]  R834      -5.8838635683059692e-01
    z[1,2,0]  R835      -2.8149381279945374e-01
    z[1,2,0]  R836      -5.7092517614364624e-01
    z[1,2,0]  R837      0.227547287940979
    z[1,2,0]  R838      5.5791920423507690e-01
    z[1,2,0]  R839      4.3100666999816895e-01
    z[1,2,0]  R840      1.3391035795211792e-01
    z[1,2,1]  R12       -1
    z[1,2,1]  R21       1
    z[1,2,1]  R705      -1
    z[1,2,1]  R706      1
    z[1,2,1]  R717      -3.3563992381095886e-01
    z[1,2,1]  R718      -2.8114026784896851e-01
    z[1,2,1]  R719      -2.0235392451286316e-01
    z[1,2,1]  R720      -3.9763000607490540e-01
    z[1,2,1]  R721      -1.9126047194004059e-01
    z[1,2,1]  R722      -3.2268315553665161e-01
    z[1,2,1]  R723      -1.1038208752870560e-01
    z[1,2,1]  R724      -1.0242065042257309e-01
    z[1,2,1]  R725      -3.7171953916549683e-01
    z[1,2,1]  R726      -2.7798095345497131e-01
    z[1,2,1]  R727      -7.3880583047866821e-01
    z[1,2,1]  R728      2.8852856159210205e-01
    z[1,2,1]  R729      -6.9745475053787231e-01
    z[1,2,1]  R730      -6.7659026384353638e-01
    z[1,2,1]  R731      1.5621243417263031e-01
    z[1,2,1]  R732      1.3875234127044678e-01
    z[1,2,1]  R733      7.7380046248435974e-02
    z[1,2,1]  R734      -2.4864664673805237e-01
    z[1,2,1]  R735      -7.1995544433593750e-01
    z[1,2,1]  R736      4.3988442420959473e-01
    z[1,2,1]  R737      -8.7624388933181763e-01
    z[1,2,1]  R738      -2.5671776384115219e-02
    z[1,2,1]  R739      3.5382679104804993e-01
    z[1,2,1]  R740      -1.6947848722338676e-02
    z[1,2,1]  R741      -2.8374776244163513e-01
    z[1,2,1]  R742      2.6474717259407043e-01
    z[1,2,1]  R743      3.5049974918365479e-01
    z[1,2,1]  R744      8.2094341516494751e-02
    z[1,2,1]  R745      5.8240371942520142e-01
    z[1,2,1]  R746      2.2649440169334412e-01
    z[1,2,1]  R747      -1.4183451235294342e-01
    z[1,2,1]  R748      -1.4633235335350037e-01
    z[1,2,1]  R749      -2.8569728136062622e-01
    z[1,2,1]  R750      3.9122492074966431e-01
    z[1,2,1]  R751      4.2709720134735107e-01
    z[1,2,1]  R752      2.0969817042350769e-01
    z[1,2,1]  R753      1.8353113532066345e-01
    z[1,2,1]  R754      4.3121472001075745e-01
    z[1,2,1]  R755      4.7087732702493668e-02
    z[1,2,1]  R756      3.2928496599197388e-01
    z[1,2,1]  R757      -4.2966210842132568e-01
    z[1,2,1]  R758      1.4785882830619812e-01
    z[1,2,1]  R759      5.3121572732925415e-01
    z[1,2,1]  R760      3.4137284755706787e-01
    z[1,2,1]  R761      2.1490712463855743e-01
    z[1,2,1]  R762      1.4756475389003754e-01
    z[1,2,1]  R763      -4.8007094860076904e-01
    z[1,2,1]  R764      -4.7991201281547546e-01
    z[1,2,1]  R765      -3.9515095949172974e-01
    z[1,2,1]  R766      -6.2988650798797607e-01
    z[1,2,1]  R767      4.1771256923675537e-01
    z[1,2,1]  R768      1.5441577136516571e-01
    z[1,2,1]  R769      -3.9207491278648376e-01
    z[1,2,1]  R770      1.6048018634319305e-01
    z[1,2,1]  R771      3.0565094947814941e-01
    z[1,2,1]  R772      3.3529585599899292e-01
    z[1,2,1]  R773      -4.1966083645820618e-01
    z[1,2,1]  R774      -2.7800619602203369e-01
    z[1,2,1]  R775      6.7779272794723511e-02
    z[1,2,1]  R776      -3.1335547566413879e-01
    z[1,2,1]  R777      4.0297958254814148e-01
    z[1,2,1]  R778      1.9702941179275513e-01
    z[1,2,1]  R779      4.1896373033523560e-01
    z[1,2,1]  R780      -4.1293808817863464e-01
    z[1,2,1]  R781      -5.4255348443984985e-01
    z[1,2,1]  R782      -3.4744662046432495e-01
    z[1,2,1]  R783      1.5410919487476349e-01
    z[1,2,1]  R784      -5.8917975425720215e-01
    z[1,2,1]  R785      9.3907696008682251e-01
    z[1,2,1]  R786      9.6039682626724243e-01
    z[1,2,1]  R787      1.8808189034461975e-01
    z[1,2,1]  R788      -3.5703826695680618e-02
    z[1,2,1]  R789      -2.1576354280114174e-02
    z[1,2,1]  R790      5.2840482443571091e-02
    z[1,2,1]  R791      -0.669160008430481
    z[1,2,1]  R792      8.5001587867736816e-01
    z[1,2,1]  R793      -4.2836752533912659e-01
    z[1,2,1]  R794      5.4281461238861084e-01
    z[1,2,1]  R795      -4.0056610107421875e-01
    z[1,2,1]  R796      -5.1552116870880127e-01
    z[1,2,1]  R797      2.4238830804824829e-01
    z[1,2,1]  R798      -1.0183142125606537e-01
    z[1,2,1]  R799      -5.1572978496551514e-01
    z[1,2,1]  R800      -7.6958012580871582e-01
    z[1,2,1]  R801      -2.7142700552940369e-01
    z[1,2,1]  R802      8.2527321577072144e-01
    z[1,2,1]  R803      8.8517922163009644e-01
    z[1,2,1]  R804      7.2231113910675049e-01
    z[1,2,1]  R805      0.835231363773346
    z[1,2,1]  R806      8.3807313442230225e-01
    z[1,2,1]  R807      -5.3620919585227966e-02
    z[1,2,1]  R808      2.3409350216388702e-01
    z[1,2,1]  R809      3.8337996602058411e-01
    z[1,2,1]  R810      -8.3246874809265137e-01
    z[1,2,1]  R811      -3.3632597327232361e-01
    z[1,2,1]  R812      0.822594165802002
    z[1,2,1]  R813      7.3138356208801270e-01
    z[1,2,1]  R814      7.8624749183654785e-01
    z[1,2,1]  R815      7.7497494220733643e-01
    z[1,2,1]  R816      7.3773950338363647e-01
    z[1,2,1]  R817      -5.9290248155593872e-01
    z[1,2,1]  R818      -7.2246640920639038e-01
    z[1,2,1]  R819      -5.1898014545440674e-01
    z[1,2,1]  R820      -5.0235044956207275e-01
    z[1,2,1]  R821      -4.0276399254798889e-01
    z[1,2,1]  R822      -7.1195507049560547e-01
    z[1,2,1]  R823      -5.4251879453659058e-01
    z[1,2,1]  R824      -4.0479367971420288e-01
    z[1,2,1]  R825      -8.8276928663253784e-01
    z[1,2,1]  R826      -5.2685809135437012e-01
    z[1,2,1]  R827      7.9778659343719482e-01
    z[1,2,1]  R828      8.5822361707687378e-01
    z[1,2,1]  R829      0.57748943567276
    z[1,2,1]  R830      7.6454418897628784e-01
    z[1,2,1]  R831      6.0351091623306274e-01
    z[1,2,1]  R832      6.7756199836730957e-01
    z[1,2,1]  R833      7.5941306352615356e-01
    z[1,2,1]  R834      4.8605209589004517e-01
    z[1,2,1]  R835      6.8820118904113770e-01
    z[1,2,1]  R836      4.4714894890785217e-01
    z[1,2,1]  R837      -1.3957631587982178e-01
    z[1,2,1]  R838      1.5866938233375549e-01
    z[1,2,1]  R839      8.7374888360500336e-02
    z[1,2,1]  R840      -5.2000995725393295e-02
    z[1,2,2]  R13       -1
    z[1,2,2]  R22       1
    z[1,2,2]  R707      -1
    z[1,2,2]  R708      1
    z[1,2,2]  R717      -1.1853816360235214e-01
    z[1,2,2]  R718      -1.3509753160178661e-02
    z[1,2,2]  R719      -5.8933593332767487e-02
    z[1,2,2]  R720      -5.3258843719959259e-02
    z[1,2,2]  R721      7.5866342522203922e-03
    z[1,2,2]  R722      6.0134965926408768e-02
    z[1,2,2]  R723      2.9740616679191589e-01
    z[1,2,2]  R724      2.6105591654777527e-01
    z[1,2,2]  R725      -2.3807699978351593e-01
    z[1,2,2]  R726      2.2151088714599609e-01
    z[1,2,2]  R727      -1.4257369935512543e-01
    z[1,2,2]  R728      2.1280555427074432e-01
    z[1,2,2]  R729      -5.3871236741542816e-02
    z[1,2,2]  R730      -0.158564493060112
    z[1,2,2]  R731      -7.0406176149845123e-02
    z[1,2,2]  R732      -1.9678844138979912e-02
    z[1,2,2]  R733      -2.5658485293388367e-01
    z[1,2,2]  R734      -3.8320258259773254e-01
    z[1,2,2]  R735      1.7249508202075958e-01
    z[1,2,2]  R736      4.3248921632766724e-01
    z[1,2,2]  R737      -1.2811531126499176e-01
    z[1,2,2]  R738      1.4191722869873047e-01
    z[1,2,2]  R739      -1.0315258055925369e-01
    z[1,2,2]  R740      5.7939875125885010e-01
    z[1,2,2]  R741      4.5659548044204712e-01
    z[1,2,2]  R742      -2.1855439245700836e-01
    z[1,2,2]  R743      -2.0133875310420990e-01
    z[1,2,2]  R744      1.3484379276633263e-02
    z[1,2,2]  R745      2.1422983705997467e-01
    z[1,2,2]  R746      2.9233434796333313e-01
    z[1,2,2]  R747      3.5992351174354553e-01
    z[1,2,2]  R748      -0.679987370967865
    z[1,2,2]  R749      -2.2934034466743469e-01
    z[1,2,2]  R750      -0.0109430942684412
    z[1,2,2]  R751      -1.5799516439437866e-01
    z[1,2,2]  R752      1.1394404806196690e-02
    z[1,2,2]  R753      -2.3620298597961664e-03
    z[1,2,2]  R754      1.6179924830794334e-02
    z[1,2,2]  R755      -0.0656462013721466
    z[1,2,2]  R756      3.4418323636054993e-01
    z[1,2,2]  R757      3.0129194259643555e-01
    z[1,2,2]  R758      2.8884598612785339e-01
    z[1,2,2]  R759      1.9122385978698730e-01
    z[1,2,2]  R760      -2.9208555817604065e-01
    z[1,2,2]  R761      -2.2691851854324341e-01
    z[1,2,2]  R762      6.4044152386486530e-03
    z[1,2,2]  R763      2.0478211343288422e-01
    z[1,2,2]  R764      1.4265184104442596e-01
    z[1,2,2]  R765      2.4560482800006866e-01
    z[1,2,2]  R766      -2.2371813654899597e-01
    z[1,2,2]  R767      6.0382062196731567e-01
    z[1,2,2]  R768      0.0838552713394165
    z[1,2,2]  R769      -3.8139653205871582e-01
    z[1,2,2]  R770      3.2950885593891144e-02
    z[1,2,2]  R771      -7.8959226608276367e-02
    z[1,2,2]  R772      1.7590709030628204e-01
    z[1,2,2]  R773      -2.7172014117240906e-01
    z[1,2,2]  R774      -1.8509723246097565e-01
    z[1,2,2]  R775      3.8466113805770874e-01
    z[1,2,2]  R776      -1.3332429528236389e-01
    z[1,2,2]  R777      3.1154736876487732e-01
    z[1,2,2]  R778      1.9985429942607880e-02
    z[1,2,2]  R779      2.8842157125473022e-01
    z[1,2,2]  R780      -4.1602656245231628e-02
    z[1,2,2]  R781      -1.7169304192066193e-02
    z[1,2,2]  R782      -1.9052948057651520e-01
    z[1,2,2]  R783      -2.5256642699241638e-01
    z[1,2,2]  R784      7.0102256722748280e-03
    z[1,2,2]  R785      -1.6414555907249451e-01
    z[1,2,2]  R786      -3.6084707826375961e-02
    z[1,2,2]  R787      -5.1217749714851379e-02
    z[1,2,2]  R788      -5.1917475461959839e-01
    z[1,2,2]  R789      -5.8295524120330811e-01
    z[1,2,2]  R790      1.7868605256080627e-01
    z[1,2,2]  R791      3.4137687087059021e-01
    z[1,2,2]  R792      -3.3170655369758606e-01
    z[1,2,2]  R793      1.3348698616027832e-01
    z[1,2,2]  R794      -5.5416148900985718e-01
    z[1,2,2]  R795      3.6347416043281555e-01
    z[1,2,2]  R796      -4.5652204751968384e-01
    z[1,2,2]  R797      -7.0415951311588287e-02
    z[1,2,2]  R798      -4.7058498859405518e-01
    z[1,2,2]  R799      -3.4134802222251892e-01
    z[1,2,2]  R800      -1.0316787520423532e-03
    z[1,2,2]  R801      6.6267979145050049e-01
    z[1,2,2]  R802      -1.2245739996433258e-01
    z[1,2,2]  R803      3.1064450740814209e-03
    z[1,2,2]  R804      -1.9768038392066956e-01
    z[1,2,2]  R805      -2.6481890678405762e-01
    z[1,2,2]  R806      -1.8159645795822144e-01
    z[1,2,2]  R807      -4.6260491013526917e-01
    z[1,2,2]  R808      -1.7056234180927277e-01
    z[1,2,2]  R809      -2.9695001244544983e-01
    z[1,2,2]  R810      3.5705637186765671e-02
    z[1,2,2]  R811      5.0237149000167847e-01
    z[1,2,2]  R812      -6.4319007098674774e-02
    z[1,2,2]  R813      1.2722036242485046e-01
    z[1,2,2]  R814      -7.0435716770589352e-03
    z[1,2,2]  R815      -9.3880154192447662e-02
    z[1,2,2]  R816      1.7199160158634186e-01
    z[1,2,2]  R817      3.5933580994606018e-01
    z[1,2,2]  R818      -3.1633205711841583e-02
    z[1,2,2]  R819      1.9013518467545509e-02
    z[1,2,2]  R820      2.0099420845508575e-01
    z[1,2,2]  R821      5.9181636571884155e-01
    z[1,2,2]  R822      4.8591491580009460e-01
    z[1,2,2]  R823      1.9740661978721619e-01
    z[1,2,2]  R824      3.8579389452934265e-01
    z[1,2,2]  R825      -7.7522508800029755e-02
    z[1,2,2]  R826      7.4727272987365723e-01
    z[1,2,2]  R827      -1.2009497731924057e-01
    z[1,2,2]  R828      7.6472632586956024e-02
    z[1,2,2]  R829      3.2745766639709473e-01
    z[1,2,2]  R830      1.8415714800357819e-01
    z[1,2,2]  R831      -1.2678658962249756e-01
    z[1,2,2]  R832      -4.4335469603538513e-01
    z[1,2,2]  R833      4.9939689040184021e-01
    z[1,2,2]  R834      -1.5145042538642883e-01
    z[1,2,2]  R835      9.8478108644485474e-02
    z[1,2,2]  R836      -5.7115167379379272e-02
    z[1,2,2]  R837      -5.1285862922668457e-01
    z[1,2,2]  R838      -0.381136029958725
    z[1,2,2]  R839      -5.9377545118331909e-01
    z[1,2,2]  R840      -0.43329918384552
    z[1,2,3]  R14       -1
    z[1,2,3]  R23       1
    z[1,2,3]  R709      -1
    z[1,2,3]  R710      1
    z[1,2,3]  R717      3.7642562389373779e-01
    z[1,2,3]  R718      2.2613757848739624e-01
    z[1,2,3]  R719      2.8243386745452881e-01
    z[1,2,3]  R720      0.0550660714507103
    z[1,2,3]  R721      -3.1871774792671204e-01
    z[1,2,3]  R722      0.0724758729338646
    z[1,2,3]  R723      -0.0727483481168747
    z[1,2,3]  R724      -1.5462476760149002e-02
    z[1,2,3]  R725      -2.2073060274124146e-01
    z[1,2,3]  R726      6.2123283743858337e-02
    z[1,2,3]  R727      -0.424940824508667
    z[1,2,3]  R728      -1.5746068954467773e-01
    z[1,2,3]  R729      -4.0981835126876831e-01
    z[1,2,3]  R730      -4.5490843057632446e-01
    z[1,2,3]  R731      2.8890269994735718e-01
    z[1,2,3]  R732      -3.9071059226989746e-01
    z[1,2,3]  R733      -0.346769779920578
    z[1,2,3]  R734      3.4356537461280823e-01
    z[1,2,3]  R735      2.8785686939954758e-02
    z[1,2,3]  R736      -4.6313452720642090e-01
    z[1,2,3]  R737      -3.9203029870986938e-01
    z[1,2,3]  R738      -6.5651428699493408e-01
    z[1,2,3]  R739      -2.4493958055973053e-01
    z[1,2,3]  R740      -5.6359034776687622e-01
    z[1,2,3]  R741      -4.9433851242065430e-01
    z[1,2,3]  R742      2.3379026353359222e-01
    z[1,2,3]  R743      3.6727815866470337e-01
    z[1,2,3]  R744      3.2355868816375732e-01
    z[1,2,3]  R745      -5.8226162195205688e-01
    z[1,2,3]  R746      -4.4555738568305969e-01
    z[1,2,3]  R747      -0.281028687953949
    z[1,2,3]  R748      1.4870950579643250e-01
    z[1,2,3]  R749      -0.0558922179043293
    z[1,2,3]  R750      1.5222573280334473e-01
    z[1,2,3]  R751      -1.1127392202615738e-01
    z[1,2,3]  R752      2.6698562502861023e-01
    z[1,2,3]  R753      0.0815851241350174
    z[1,2,3]  R754      2.0858474075794220e-01
    z[1,2,3]  R755      2.5546187162399292e-01
    z[1,2,3]  R756      2.7224791049957275e-01
    z[1,2,3]  R757      -5.8066624402999878e-01
    z[1,2,3]  R758      -2.1184456348419189e-01
    z[1,2,3]  R759      -7.1251779794692993e-01
    z[1,2,3]  R760      -0.0191778764128685
    z[1,2,3]  R761      -3.0335992574691772e-01
    z[1,2,3]  R762      2.6501855254173279e-01
    z[1,2,3]  R763      6.0697649605572224e-03
    z[1,2,3]  R764      1.4614929258823395e-01
    z[1,2,3]  R765      -2.5967705994844437e-02
    z[1,2,3]  R766      -3.8211518526077271e-01
    z[1,2,3]  R767      -5.6091696023941040e-01
    z[1,2,3]  R768      -9.1272346675395966e-02
    z[1,2,3]  R769      3.3846864104270935e-01
    z[1,2,3]  R770      3.7194166332483292e-02
    z[1,2,3]  R771      4.0260624140501022e-02
    z[1,2,3]  R772      -2.9305824637413025e-01
    z[1,2,3]  R773      0.207631453871727
    z[1,2,3]  R774      6.7774903774261475e-01
    z[1,2,3]  R775      -6.9623276591300964e-02
    z[1,2,3]  R776      -2.0771314203739166e-01
    z[1,2,3]  R777      -0.00696546770632267
    z[1,2,3]  R778      7.0355825126171112e-02
    z[1,2,3]  R779      4.4429653882980347e-01
    z[1,2,3]  R780      7.4754811823368073e-02
    z[1,2,3]  R781      1.6481418907642365e-01
    z[1,2,3]  R782      -2.6582974195480347e-01
    z[1,2,3]  R783      8.2485699653625488e-01
    z[1,2,3]  R784      5.0227355957031250e-01
    z[1,2,3]  R785      1.0876694321632385e-01
    z[1,2,3]  R786      1.2753970222547650e-03
    z[1,2,3]  R787      8.4732629358768463e-02
    z[1,2,3]  R788      6.2167018651962280e-01
    z[1,2,3]  R789      5.9127581119537354e-01
    z[1,2,3]  R790      -3.6739131808280945e-01
    z[1,2,3]  R791      2.9516467452049255e-01
    z[1,2,3]  R792      -1.0469325631856918e-01
    z[1,2,3]  R793      -1.3179023563861847e-01
    z[1,2,3]  R794      -4.7945481538772583e-01
    z[1,2,3]  R795      5.8445721864700317e-01
    z[1,2,3]  R796      4.0771072963252664e-04
    z[1,2,3]  R797      0.0796792060136795
    z[1,2,3]  R798      5.8450758457183838e-01
    z[1,2,3]  R799      -6.9646090269088745e-01
    z[1,2,3]  R800      3.2750996947288513e-01
    z[1,2,3]  R801      4.2184704542160034e-01
    z[1,2,3]  R802      -3.8457545638084412e-01
    z[1,2,3]  R803      -3.3123109489679337e-02
    z[1,2,3]  R804      -1.1977288126945496e-01
    z[1,2,3]  R805      -2.5463856291025877e-03
    z[1,2,3]  R806      2.8450268507003784e-01
    z[1,2,3]  R807      5.8854973316192627e-01
    z[1,2,3]  R808      -5.7986426353454590e-01
    z[1,2,3]  R809      -2.5151500478386879e-02
    z[1,2,3]  R810      3.2991883158683777e-01
    z[1,2,3]  R811      6.6927188634872437e-01
    z[1,2,3]  R812      2.9772832989692688e-01
    z[1,2,3]  R813      6.1433595418930054e-01
    z[1,2,3]  R814      4.2071422934532166e-01
    z[1,2,3]  R815      -1.9240427762269974e-02
    z[1,2,3]  R816      0.529548168182373
    z[1,2,3]  R817      -4.1641983389854431e-01
    z[1,2,3]  R818      -0.581412672996521
    z[1,2,3]  R819      -3.9674839377403259e-01
    z[1,2,3]  R820      -2.2573718428611755e-01
    z[1,2,3]  R821      0.151409313082695
    z[1,2,3]  R822      1.7278465628623962e-01
    z[1,2,3]  R823      -2.1413658559322357e-01
    z[1,2,3]  R824      1.2555651366710663e-01
    z[1,2,3]  R825      1.1373896151781082e-01
    z[1,2,3]  R826      -2.2943688556551933e-02
    z[1,2,3]  R827      9.0139739215373993e-02
    z[1,2,3]  R828      8.0782070755958557e-02
    z[1,2,3]  R829      4.3264187872409821e-02
    z[1,2,3]  R830      2.2799910511821508e-03
    z[1,2,3]  R831      -3.0812883377075195e-01
    z[1,2,3]  R832      -0.0792752057313919
    z[1,2,3]  R833      7.7979043126106262e-02
    z[1,2,3]  R834      -2.6251441240310669e-01
    z[1,2,3]  R835      -4.3058654665946960e-01
    z[1,2,3]  R836      -6.4221984148025513e-01
    z[1,2,3]  R837      6.5747827291488647e-01
    z[1,2,3]  R838      6.9999152421951294e-01
    z[1,2,3]  R839      5.6981217861175537e-01
    z[1,2,3]  R840      2.0941333472728729e-01
    z[1,2,4]  R15       -1
    z[1,2,4]  R24       1
    z[1,2,4]  R711      -1
    z[1,2,4]  R712      1
    z[1,2,4]  R717      4.2370632290840149e-01
    z[1,2,4]  R718      1.8065446987748146e-02
    z[1,2,4]  R719      3.6739388108253479e-01
    z[1,2,4]  R720      5.8633655309677124e-01
    z[1,2,4]  R721      1.6537471115589142e-01
    z[1,2,4]  R722      1.6097468137741089e-01
    z[1,2,4]  R723      1.7848816514015198e-01
    z[1,2,4]  R724      2.6838836073875427e-01
    z[1,2,4]  R725      1.1645889282226562e-01
    z[1,2,4]  R726      2.9949453473091125e-01
    z[1,2,4]  R727      -1.5863038599491119e-01
    z[1,2,4]  R728      -2.0651364326477051e-01
    z[1,2,4]  R729      -3.7758240103721619e-01
    z[1,2,4]  R730      -8.3849288523197174e-02
    z[1,2,4]  R731      -5.0751942396163940e-01
    z[1,2,4]  R732      -9.4126991927623749e-02
    z[1,2,4]  R733      1.0345663875341415e-01
    z[1,2,4]  R734      -7.7445471286773682e-01
    z[1,2,4]  R735      -4.0884593129158020e-01
    z[1,2,4]  R736      -5.5066245794296265e-01
    z[1,2,4]  R737      -1.9226944446563721e-01
    z[1,2,4]  R738      2.1234290301799774e-01
    z[1,2,4]  R739      -2.9462394118309021e-01
    z[1,2,4]  R740      -4.5862805843353271e-01
    z[1,2,4]  R741      -2.9427188634872437e-01
    z[1,2,4]  R742      0.473821222782135
    z[1,2,4]  R743      1.7656306922435760e-01
    z[1,2,4]  R744      0.512280285358429
    z[1,2,4]  R745      1.8443444371223450e-01
    z[1,2,4]  R746      6.3173137605190277e-02
    z[1,2,4]  R747      -5.9691351652145386e-01
    z[1,2,4]  R748      -5.0122201442718506e-01
    z[1,2,4]  R749      -8.1298923492431641e-01
    z[1,2,4]  R750      4.1157731413841248e-01
    z[1,2,4]  R751      0.13089619576931
    z[1,2,4]  R752      1.8609413504600525e-01
    z[1,2,4]  R753      1.9791173934936523e-01
    z[1,2,4]  R754      -2.6141893118619919e-02
    z[1,2,4]  R755      7.1282177232205868e-03
    z[1,2,4]  R756      -5.2257917821407318e-02
    z[1,2,4]  R757      -3.5380131006240845e-01
    z[1,2,4]  R758      -6.8181025981903076e-01
    z[1,2,4]  R759      -3.4506028890609741e-01
    z[1,2,4]  R760      -1.3816542923450470e-01
    z[1,2,4]  R761      3.3916497230529785e-01
    z[1,2,4]  R762      -7.2195746004581451e-02
    z[1,2,4]  R763      9.0210400521755219e-02
    z[1,2,4]  R764      -2.2630941867828369e-01
    z[1,2,4]  R765      -1.1395063996315002e-01
    z[1,2,4]  R766      2.5320026278495789e-01
    z[1,2,4]  R767      -2.6496413350105286e-01
    z[1,2,4]  R768      1.2268720567226410e-01
    z[1,2,4]  R769      -0.516111433506012
    z[1,2,4]  R770      -7.7362522482872009e-02
    z[1,2,4]  R771      3.6041066050529480e-01
    z[1,2,4]  R772      1.6203403472900391e-02
    z[1,2,4]  R773      3.3967226743698120e-02
    z[1,2,4]  R774      -4.0043359994888306e-01
    z[1,2,4]  R775      2.4488031864166260e-01
    z[1,2,4]  R776      -2.7999168634414673e-01
    z[1,2,4]  R777      1.5323479473590851e-01
    z[1,2,4]  R778      2.2334653884172440e-02
    z[1,2,4]  R779      -1.8812276422977448e-01
    z[1,2,4]  R780      -2.4828863143920898e-01
    z[1,2,4]  R781      -1.6168478131294250e-01
    z[1,2,4]  R782      -1.5106610953807831e-01
    z[1,2,4]  R783      7.6155625283718109e-02
    z[1,2,4]  R784      4.5021429657936096e-02
    z[1,2,4]  R785      1.1790663003921509e-01
    z[1,2,4]  R786      3.5410594195127487e-02
    z[1,2,4]  R787      0.0838705375790596
    z[1,2,4]  R788      -1.5915378928184509e-01
    z[1,2,4]  R789      -5.2755761146545410e-01
    z[1,2,4]  R790      -2.4036690592765808e-01
    z[1,2,4]  R791      -5.0913745164871216e-01
    z[1,2,4]  R792      0.000716552953235805
    z[1,2,4]  R793      5.7074010372161865e-01
    z[1,2,4]  R794      -1.7616911232471466e-01
    z[1,2,4]  R795      4.8988372087478638e-02
    z[1,2,4]  R796      3.4998711943626404e-01
    z[1,2,4]  R797      2.0113010704517365e-01
    z[1,2,4]  R798      -1.8414147198200226e-01
    z[1,2,4]  R799      2.8846734762191772e-01
    z[1,2,4]  R800      -4.8386237025260925e-01
    z[1,2,4]  R801      -4.8561595380306244e-02
    z[1,2,4]  R802      -2.9330602288246155e-01
    z[1,2,4]  R803      -4.0362879633903503e-01
    z[1,2,4]  R804      -3.4878385066986084e-01
    z[1,2,4]  R805      -3.7716156244277954e-01
    z[1,2,4]  R806      -3.8579076528549194e-01
    z[1,2,4]  R807      -3.0203866958618164e-01
    z[1,2,4]  R808      4.6352226287126541e-02
    z[1,2,4]  R809      1.6870559751987457e-01
    z[1,2,4]  R810      -2.5287646055221558e-01
    z[1,2,4]  R811      -1.5198273956775665e-01
    z[1,2,4]  R812      -2.8569018840789795e-01
    z[1,2,4]  R813      -1.9161500036716461e-01
    z[1,2,4]  R814      -2.7352344989776611e-01
    z[1,2,4]  R815      -2.6284396648406982e-01
    z[1,2,4]  R816      -1.8524785339832306e-01
    z[1,2,4]  R817      -1.1001219972968102e-03
    z[1,2,4]  R818      2.8186461329460144e-01
    z[1,2,4]  R819      5.1787173748016357e-01
    z[1,2,4]  R820      3.3614826202392578e-01
    z[1,2,4]  R821      4.3787100911140442e-01
    z[1,2,4]  R822      -9.2299081385135651e-02
    z[1,2,4]  R823      4.5325309038162231e-01
    z[1,2,4]  R824      1.7119120061397552e-01
    z[1,2,4]  R825      -0.172170028090477
    z[1,2,4]  R826      1.5981712937355042e-01
    z[1,2,4]  R827      -9.1165617108345032e-02
    z[1,2,4]  R828      3.1064444780349731e-01
    z[1,2,4]  R829      -4.0164259076118469e-01
    z[1,2,4]  R830      -0.0375276580452919
    z[1,2,4]  R831      -2.1597084403038025e-01
    z[1,2,4]  R832      -2.6986721158027649e-01
    z[1,2,4]  R833      2.0343777537345886e-01
    z[1,2,4]  R834      -4.7412395477294922e-01
    z[1,2,4]  R835      2.9025465250015259e-01
    z[1,2,4]  R836      4.0439318865537643e-02
    z[1,2,4]  R837      3.3689764142036438e-01
    z[1,2,4]  R838      5.4812509566545486e-02
    z[1,2,4]  R839      3.5733726620674133e-01
    z[1,2,4]  R840      -3.7407171726226807e-01
    z[1,2,5]  R16       -1
    z[1,2,5]  R25       1
    z[1,2,5]  R713      -1
    z[1,2,5]  R714      1
    z[1,2,5]  R717      -1.0683242231607437e-02
    z[1,2,5]  R718      4.4384026527404785e-01
    z[1,2,5]  R719      5.6114387512207031e-01
    z[1,2,5]  R720      2.2153569757938385e-01
    z[1,2,5]  R721      0.0785888135433197
    z[1,2,5]  R722      -2.0154097676277161e-01
    z[1,2,5]  R723      -1.4973272383213043e-01
    z[1,2,5]  R724      -2.0013237372040749e-02
    z[1,2,5]  R725      1.4452475309371948e-01
    z[1,2,5]  R726      1.1037625372409821e-01
    z[1,2,5]  R727      1.5011714398860931e-01
    z[1,2,5]  R728      1.9484703242778778e-01
    z[1,2,5]  R729      4.0779468417167664e-01
    z[1,2,5]  R730      -3.6305990815162659e-01
    z[1,2,5]  R731      -1.8814601004123688e-01
    z[1,2,5]  R732      2.2578341886401176e-02
    z[1,2,5]  R733      4.0209281444549561e-01
    z[1,2,5]  R734      -2.2305153310298920e-01
    z[1,2,5]  R735      -3.4657639265060425e-01
    z[1,2,5]  R736      1.3650451600551605e-01
    z[1,2,5]  R737      -1.4910818636417389e-01
    z[1,2,5]  R738      -5.7941582053899765e-02
    z[1,2,5]  R739      -4.3500947952270508e-01
    z[1,2,5]  R740      1.2846945226192474e-01
    z[1,2,5]  R741      -1.9584308564662933e-01
    z[1,2,5]  R742      5.0724223256111145e-03
    z[1,2,5]  R743      -3.4511899948120117e-01
    z[1,2,5]  R744      -5.1498431712388992e-03
    z[1,2,5]  R745      4.2048788070678711e-01
    z[1,2,5]  R746      -0.248139888048172
    z[1,2,5]  R747      -2.2326861321926117e-01
    z[1,2,5]  R748      -1.4089688658714294e-01
    z[1,2,5]  R749      -3.5816648602485657e-01
    z[1,2,5]  R750      -1.9831705838441849e-02
    z[1,2,5]  R751      -2.8302398324012756e-01
    z[1,2,5]  R752      -2.6607608795166016e-01
    z[1,2,5]  R753      -9.3816900625824928e-03
    z[1,2,5]  R754      -0.00913193728774786
    z[1,2,5]  R755      -3.4307509660720825e-01
    z[1,2,5]  R756      1.3647709786891937e-01
    z[1,2,5]  R757      2.2741788998246193e-02
    z[1,2,5]  R758      4.9062767624855042e-01
    z[1,2,5]  R759      4.5953061431646347e-02
    z[1,2,5]  R760      -1.4729671180248260e-01
    z[1,2,5]  R761      -2.3401673138141632e-01
    z[1,2,5]  R762      4.9856898188591003e-01
    z[1,2,5]  R763      2.8222987055778503e-01
    z[1,2,5]  R764      -9.2234506155364215e-05
    z[1,2,5]  R765      -2.2545018792152405e-01
    z[1,2,5]  R766      4.0567898750305176e-01
    z[1,2,5]  R767      -1.1036479473114014e-01
    z[1,2,5]  R768      2.5438693165779114e-01
    z[1,2,5]  R769      -1.0560341179370880e-01
    z[1,2,5]  R770      4.6336323022842407e-01
    z[1,2,5]  R771      4.7741317749023438e-01
    z[1,2,5]  R772      -5.3843200206756592e-01
    z[1,2,5]  R773      -2.3436771705746651e-02
    z[1,2,5]  R774      3.7715956568717957e-01
    z[1,2,5]  R775      -0.510245680809021
    z[1,2,5]  R776      1.1509119719266891e-01
    z[1,2,5]  R777      -6.6956095397472382e-02
    z[1,2,5]  R778      4.1354256868362427e-01
    z[1,2,5]  R779      -0.234359011054039
    z[1,2,5]  R780      1.6112641990184784e-01
    z[1,2,5]  R781      1.0046856850385666e-01
    z[1,2,5]  R782      1.0830528289079666e-01
    z[1,2,5]  R783      1.3350382447242737e-01
    z[1,2,5]  R784      8.2315705716609955e-02
    z[1,2,5]  R785      4.7807514667510986e-02
    z[1,2,5]  R786      -1.8564681708812714e-01
    z[1,2,5]  R787      3.8254481554031372e-01
    z[1,2,5]  R788      4.2950016260147095e-01
    z[1,2,5]  R789      4.4323410838842392e-02
    z[1,2,5]  R790      -3.0888348817825317e-01
    z[1,2,5]  R791      -1.7003257572650909e-01
    z[1,2,5]  R792      -2.1060745418071747e-01
    z[1,2,5]  R793      -2.8826245665550232e-01
    z[1,2,5]  R794      -3.1406667828559875e-01
    z[1,2,5]  R795      -4.2162844538688660e-01
    z[1,2,5]  R796      -2.5881221890449524e-01
    z[1,2,5]  R797      3.3505931496620178e-01
    z[1,2,5]  R798      4.9329307675361633e-01
    z[1,2,5]  R799      1.1204126477241516e-01
    z[1,2,5]  R800      2.9471702873706818e-03
    z[1,2,5]  R801      5.1336448639631271e-02
    z[1,2,5]  R802      -1.6353687644004822e-01
    z[1,2,5]  R803      -3.7536349147558212e-02
    z[1,2,5]  R804      -4.7130686044692993e-01
    z[1,2,5]  R805      1.5334385633468628e-01
    z[1,2,5]  R806      -2.6177048683166504e-02
    z[1,2,5]  R807      5.0096571445465088e-01
    z[1,2,5]  R808      -2.0492132753133774e-02
    z[1,2,5]  R809      2.4650931358337402e-01
    z[1,2,5]  R810      3.1349015235900879e-01
    z[1,2,5]  R811      -1.9713032990694046e-02
    z[1,2,5]  R812      3.5099261999130249e-01
    z[1,2,5]  R813      1.7596293985843658e-01
    z[1,2,5]  R814      0.315409392118454
    z[1,2,5]  R815      -4.4421949982643127e-01
    z[1,2,5]  R816      8.2742515951395035e-03
    z[1,2,5]  R817      5.8147519826889038e-01
    z[1,2,5]  R818      -1.3164943456649780e-01
    z[1,2,5]  R819      0.369782954454422
    z[1,2,5]  R820      -1.2190397083759308e-01
    z[1,2,5]  R821      3.2342159748077393e-01
    z[1,2,5]  R822      -5.2841216325759888e-02
    z[1,2,5]  R823      3.4322327375411987e-01
    z[1,2,5]  R824      6.2322318553924561e-01
    z[1,2,5]  R825      8.4276765584945679e-02
    z[1,2,5]  R826      -5.3143654018640518e-02
    z[1,2,5]  R827      1.3258161488920450e-03
    z[1,2,5]  R828      3.2388001680374146e-01
    z[1,2,5]  R829      -8.1217736005783081e-02
    z[1,2,5]  R830      -1.0150302201509476e-01
    z[1,2,5]  R831      2.2486111521720886e-01
    z[1,2,5]  R832      2.5098431110382080e-01
    z[1,2,5]  R833      -5.9654969722032547e-02
    z[1,2,5]  R834      -4.1578780859708786e-02
    z[1,2,5]  R835      7.0019364356994629e-02
    z[1,2,5]  R836      -0.144505113363266
    z[1,2,5]  R837      8.7805442512035370e-02
    z[1,2,5]  R838      6.7401833832263947e-02
    z[1,2,5]  R839      -0.0353923924267292
    z[1,2,5]  R840      -7.2828090190887451e-01
    z[1,2,6]  R17       -1
    z[1,2,6]  R26       1
    z[1,2,6]  R715      -1
    z[1,2,6]  R716      1
    z[1,2,6]  R717      1.6781672835350037e-01
    z[1,2,6]  R718      1.5728285908699036e-01
    z[1,2,6]  R719      -0.212831050157547
    z[1,2,6]  R720      1.1290422827005386e-01
    z[1,2,6]  R721      -2.0314763486385345e-01
    z[1,2,6]  R722      -2.0503292977809906e-01
    z[1,2,6]  R723      -2.0527285337448120e-01
    z[1,2,6]  R724      7.4418224394321442e-02
    z[1,2,6]  R725      -5.1902536302804947e-02
    z[1,2,6]  R726      1.1466937512159348e-01
    z[1,2,6]  R727      -3.8242095708847046e-01
    z[1,2,6]  R728      -0.123700812458992
    z[1,2,6]  R729      4.4131819158792496e-02
    z[1,2,6]  R730      2.0914927124977112e-01
    z[1,2,6]  R731      -1.5266370773315430e-01
    z[1,2,6]  R732      4.7503036260604858e-01
    z[1,2,6]  R733      -2.6302579045295715e-01
    z[1,2,6]  R734      -1.5337653458118439e-01
    z[1,2,6]  R735      3.7807431817054749e-01
    z[1,2,6]  R736      2.7391368150711060e-01
    z[1,2,6]  R737      2.6329910382628441e-02
    z[1,2,6]  R738      7.0679372549057007e-01
    z[1,2,6]  R739      4.6605333685874939e-02
    z[1,2,6]  R740      -3.4513169527053833e-01
    z[1,2,6]  R741      5.8406114578247070e-01
    z[1,2,6]  R742      -1.3775852508842945e-02
    z[1,2,6]  R743      -1.3469657301902771e-01
    z[1,2,6]  R744      6.3891232013702393e-02
    z[1,2,6]  R745      2.4693049490451813e-01
    z[1,2,6]  R746      2.5733673572540283e-01
    z[1,2,6]  R747      5.1083713769912720e-01
    z[1,2,6]  R748      4.4374740123748779e-01
    z[1,2,6]  R749      1.5302394330501556e-01
    z[1,2,6]  R750      -1.9526831805706024e-01
    z[1,2,6]  R751      -2.2403992712497711e-01
    z[1,2,6]  R752      -2.3340111970901489e-01
    z[1,2,6]  R753      4.2828115820884705e-01
    z[1,2,6]  R754      2.6880177855491638e-01
    z[1,2,6]  R755      2.2382782399654388e-01
    z[1,2,6]  R756      3.6712527275085449e-01
    z[1,2,6]  R757      4.4752866029739380e-01
    z[1,2,6]  R758      1.1494905501604080e-01
    z[1,2,6]  R759      1.8742652237415314e-01
    z[1,2,6]  R760      -2.2395202517509460e-01
    z[1,2,6]  R761      2.3580574989318848e-01
    z[1,2,6]  R762      1.2304235994815826e-01
    z[1,2,6]  R763      2.9824849218130112e-02
    z[1,2,6]  R764      2.2685025632381439e-01
    z[1,2,6]  R765      -9.2453166842460632e-02
    z[1,2,6]  R766      5.9650313109159470e-02
    z[1,2,6]  R767      0.196893572807312
    z[1,2,6]  R768      -1.2163080275058746e-01
    z[1,2,6]  R769      -5.5359661579132080e-01
    z[1,2,6]  R770      0.301082581281662
    z[1,2,6]  R771      1.8784141540527344e-01
    z[1,2,6]  R772      2.5613343715667725e-01
    z[1,2,6]  R773      -1.7376577854156494e-01
    z[1,2,6]  R774      1.1973126232624054e-01
    z[1,2,6]  R775      1.3432615995407104e-01
    z[1,2,6]  R776      1.5900996327400208e-01
    z[1,2,6]  R777      8.2109540700912476e-02
    z[1,2,6]  R778      3.1177085638046265e-01
    z[1,2,6]  R779      9.5916397869586945e-02
    z[1,2,6]  R780      -1.2706008553504944e-01
    z[1,2,6]  R781      -3.4822601079940796e-01
    z[1,2,6]  R782      1.3286796212196350e-01
    z[1,2,6]  R783      -2.3847262561321259e-01
    z[1,2,6]  R784      -7.5521886348724365e-02
    z[1,2,6]  R785      4.7048706561326981e-02
    z[1,2,6]  R786      -9.0640291571617126e-02
    z[1,2,6]  R787      2.1592923998832703e-01
    z[1,2,6]  R788      9.9643588066101074e-02
    z[1,2,6]  R789      -1.5728241205215454e-01
    z[1,2,6]  R790      1.2270531058311462e-01
    z[1,2,6]  R791      -2.2878400981426239e-01
    z[1,2,6]  R792      2.3199106752872467e-01
    z[1,2,6]  R793      -0.0837583988904953
    z[1,2,6]  R794      -1.3407164812088013e-01
    z[1,2,6]  R795      1.3882575929164886e-01
    z[1,2,6]  R796      -5.1358896493911743e-01
    z[1,2,6]  R797      2.2299818694591522e-01
    z[1,2,6]  R798      1.8443956971168518e-01
    z[1,2,6]  R799      -6.9723889231681824e-02
    z[1,2,6]  R800      -1.9082710146903992e-01
    z[1,2,6]  R801      -6.0413774102926254e-02
    z[1,2,6]  R802      -1.6859705746173859e-01
    z[1,2,6]  R803      8.4657423198223114e-02
    z[1,2,6]  R804      -2.8084853291511536e-01
    z[1,2,6]  R805      -1.8471510848030448e-03
    z[1,2,6]  R806      -5.2542369812726974e-03
    z[1,2,6]  R807      1.1301857233047485e-01
    z[1,2,6]  R808      1.4101485908031464e-01
    z[1,2,6]  R809      -2.0797398686408997e-01
    z[1,2,6]  R810      -1.3379167020320892e-01
    z[1,2,6]  R811      -2.0895868539810181e-02
    z[1,2,6]  R812      -5.8076906949281693e-02
    z[1,2,6]  R813      5.0957348197698593e-02
    z[1,2,6]  R814      1.7451328039169312e-01
    z[1,2,6]  R815      3.5186418890953064e-01
    z[1,2,6]  R816      -2.1904313564300537e-01
    z[1,2,6]  R817      -6.5398856997489929e-02
    z[1,2,6]  R818      -8.5410483181476593e-02
    z[1,2,6]  R819      -4.9335431307554245e-02
    z[1,2,6]  R820      -5.1971656084060669e-01
    z[1,2,6]  R821      1.2869545817375183e-01
    z[1,2,6]  R822      -2.8008174896240234e-01
    z[1,2,6]  R823      0.523004949092865
    z[1,2,6]  R824      -2.2640366852283478e-01
    z[1,2,6]  R825      2.6593515276908875e-01
    z[1,2,6]  R826      3.5641238093376160e-01
    z[1,2,6]  R827      2.8633415699005127e-01
    z[1,2,6]  R828      1.0971251875162125e-01
    z[1,2,6]  R829      -3.4122490882873535e-01
    z[1,2,6]  R830      -5.7082408666610718e-01
    z[1,2,6]  R831      -5.4641157388687134e-01
    z[1,2,6]  R832      -3.9022284746170044e-01
    z[1,2,6]  R833      -2.5672206282615662e-01
    z[1,2,6]  R834      -3.1493085622787476e-01
    z[1,2,6]  R835      -4.0359282493591309e-01
    z[1,2,6]  R836      -1.8941122293472290e-01
    z[1,2,6]  R837      -3.3500626683235168e-01
    z[1,2,6]  R838      1.4404852688312531e-01
    z[1,2,6]  R839      -2.0026246085762978e-02
    z[1,2,6]  R840      -2.7827879786491394e-01
    z[2,1,0]  R11       1
    z[2,1,0]  R20       -1
    z[2,1,0]  R841      -1
    z[2,1,0]  R842      1
    z[2,1,0]  R855      -5.9558898210525513e-02
    z[2,1,0]  R856      1.8688710033893585e-01
    z[2,1,0]  R857      4.0684661269187927e-01
    z[2,1,0]  R858      5.0825828313827515e-01
    z[2,1,0]  R859      3.8950565457344055e-01
    z[2,1,0]  R860      3.7066829204559326e-01
    z[2,1,0]  R861      1.5516020357608795e-01
    z[2,1,0]  R862      4.5007619261741638e-01
    z[2,1,0]  R863      3.0709198117256165e-01
    z[2,1,0]  R864      -8.9899547398090363e-02
    z[2,1,0]  R865      -5.0068795680999756e-01
    z[2,1,0]  R866      -1.9401873648166656e-01
    z[2,1,0]  R867      -5.2254962921142578e-01
    z[2,1,0]  R868      -2.0976625382900238e-01
    z[2,1,0]  R869      -3.5914450883865356e-01
    z[2,1,0]  R870      -2.2353176772594452e-01
    z[2,1,0]  R871      -2.3866747319698334e-01
    z[2,1,0]  R872      -5.8838635683059692e-01
    z[2,1,0]  R873      -2.8149381279945374e-01
    z[2,1,0]  R874      -5.7092517614364624e-01
    z[2,1,0]  R875      0.227547287940979
    z[2,1,0]  R876      5.5791920423507690e-01
    z[2,1,0]  R877      4.3100666999816895e-01
    z[2,1,0]  R878      1.3391035795211792e-01
    z[2,1,0]  R879      0.723736584186554
    z[2,1,0]  R880      8.0472415685653687e-01
    z[2,1,0]  R881      6.1697083711624146e-01
    z[2,1,0]  R882      6.5605306625366211e-01
    z[2,1,0]  R883      8.8712280988693237e-01
    z[2,1,0]  R884      8.8229048252105713e-01
    z[2,1,0]  R885      8.9311712980270386e-01
    z[2,1,0]  R886      9.1823190450668335e-01
    z[2,1,0]  R887      8.4810262918472290e-01
    z[2,1,0]  R888      8.6877566576004028e-01
    z[2,1,0]  R889      -2.4355600774288177e-01
    z[2,1,0]  R890      -8.6646175384521484e-01
    z[2,1,0]  R891      -1.7858077585697174e-01
    z[2,1,0]  R892      -3.5714778304100037e-01
    z[2,1,0]  R893      -7.5557577610015869e-01
    z[2,1,0]  R894      -7.6985865831375122e-01
    z[2,1,0]  R895      -7.5257080793380737e-01
    z[2,1,0]  R896      -1.5396592207252979e-02
    z[2,1,0]  R897      -1.4446650445461273e-01
    z[2,1,0]  R898      8.9831940829753876e-02
    z[2,1,0]  R899      -4.6918381005525589e-02
    z[2,1,0]  R900      1.3612688519060612e-02
    z[2,1,0]  R901      -7.2523248195648193e-01
    z[2,1,0]  R902      -2.0390337333083153e-02
    z[2,1,0]  R903      2.3649508133530617e-02
    z[2,1,0]  R904      -7.7637803554534912e-01
    z[2,1,0]  R905      -7.3027008771896362e-01
    z[2,1,0]  R906      -7.8857392072677612e-01
    z[2,1,0]  R907      0.0638904869556427
    z[2,1,0]  R908      -0.730022668838501
    z[2,1,0]  R909      3.2288023829460144e-01
    z[2,1,0]  R910      1.6156212985515594e-01
    z[2,1,0]  R911      2.2361817955970764e-01
    z[2,1,0]  R912      -7.8468585014343262e-01
    z[2,1,0]  R913      -7.9549568891525269e-01
    z[2,1,0]  R914      -8.5130012035369873e-01
    z[2,1,0]  R915      -0.858471155166626
    z[2,1,0]  R916      -8.3502292633056641e-01
    z[2,1,0]  R917      -8.7198764085769653e-01
    z[2,1,0]  R918      -7.3678523302078247e-01
    z[2,1,0]  R919      2.4792306125164032e-01
    z[2,1,0]  R920      3.6198583245277405e-01
    z[2,1,0]  R921      1.3135664165019989e-01
    z[2,1,0]  R922      -8.4073919057846069e-01
    z[2,1,0]  R923      -7.6478409767150879e-01
    z[2,1,0]  R924      -7.9939109086990356e-01
    z[2,1,0]  R925      -7.9929852485656738e-01
    z[2,1,0]  R926      -7.9075801372528076e-01
    z[2,1,0]  R927      -8.4291136264801025e-01
    z[2,1,0]  R928      -4.1825491189956665e-01
    z[2,1,0]  R929      1.5854188799858093e-01
    z[2,1,0]  R930      -9.3071717023849487e-01
    z[2,1,0]  R931      -4.7545678913593292e-02
    z[2,1,0]  R932      -0.812671959400177
    z[2,1,0]  R933      -7.1106845140457153e-01
    z[2,1,0]  R934      -6.4418500661849976e-01
    z[2,1,0]  R935      -8.2161104679107666e-01
    z[2,1,0]  R936      -3.3492672443389893e-01
    z[2,1,0]  R937      -7.1009427309036255e-01
    z[2,1,0]  R938      -8.5085999965667725e-01
    z[2,1,0]  R939      -8.4011381864547729e-01
    z[2,1,0]  R940      -8.2892262935638428e-01
    z[2,1,0]  R941      -6.6660982370376587e-01
    z[2,1,0]  R942      -8.4759056568145752e-01
    z[2,1,0]  R943      -7.2158157825469971e-01
    z[2,1,0]  R944      -8.4859234094619751e-01
    z[2,1,0]  R945      -3.8933184742927551e-01
    z[2,1,0]  R946      -6.2131547927856445e-01
    z[2,1,0]  R947      2.4689945578575134e-01
    z[2,1,0]  R948      1.7999957501888275e-01
    z[2,1,0]  R949      -8.6880499124526978e-01
    z[2,1,0]  R950      -3.5068488121032715e-01
    z[2,1,0]  R951      -7.1212485432624817e-02
    z[2,1,0]  R952      -0.813671350479126
    z[2,1,0]  R953      -8.9947231113910675e-02
    z[2,1,0]  R954      2.4146883189678192e-01
    z[2,1,0]  R955      -6.0453188419342041e-01
    z[2,1,0]  R956      -1.4398542046546936e-01
    z[2,1,0]  R957      -4.0792167186737061e-01
    z[2,1,0]  R958      -2.6940107345581055e-01
    z[2,1,0]  R959      -0.852932870388031
    z[2,1,0]  R960      -3.3950966596603394e-01
    z[2,1,0]  R961      -1.7837733030319214e-01
    z[2,1,0]  R962      -1.7302061617374420e-01
    z[2,1,0]  R963      -5.4825592041015625e-01
    z[2,1,0]  R964      -1.2178809195756912e-01
    z[2,1,0]  R965      2.0942500233650208e-01
    z[2,1,0]  R966      -0.0467689111828804
    z[2,1,0]  R967      2.5784561038017273e-01
    z[2,1,0]  R968      1.8484315276145935e-01
    z[2,1,0]  R969      -2.8594323992729187e-01
    z[2,1,0]  R970      -7.4660068750381470e-01
    z[2,1,0]  R971      -7.9481208324432373e-01
    z[2,1,0]  R972      -1.2942856550216675e-01
    z[2,1,0]  R973      -4.0330997109413147e-01
    z[2,1,0]  R974      1.4957337081432343e-01
    z[2,1,0]  R975      3.4764219075441360e-02
    z[2,1,0]  R976      3.4324326552450657e-03
    z[2,1,0]  R977      1.9561995286494493e-03
    z[2,1,0]  R978      0.251740038394928
    z[2,1,1]  R12       1
    z[2,1,1]  R21       -1
    z[2,1,1]  R843      -1
    z[2,1,1]  R844      1
    z[2,1,1]  R855      -5.9290248155593872e-01
    z[2,1,1]  R856      -7.2246640920639038e-01
    z[2,1,1]  R857      -5.1898014545440674e-01
    z[2,1,1]  R858      -5.0235044956207275e-01
    z[2,1,1]  R859      -4.0276399254798889e-01
    z[2,1,1]  R860      -7.1195507049560547e-01
    z[2,1,1]  R861      -5.4251879453659058e-01
    z[2,1,1]  R862      -4.0479367971420288e-01
    z[2,1,1]  R863      -8.8276928663253784e-01
    z[2,1,1]  R864      -5.2685809135437012e-01
    z[2,1,1]  R865      7.9778659343719482e-01
    z[2,1,1]  R866      8.5822361707687378e-01
    z[2,1,1]  R867      0.57748943567276
    z[2,1,1]  R868      7.6454418897628784e-01
    z[2,1,1]  R869      6.0351091623306274e-01
    z[2,1,1]  R870      6.7756199836730957e-01
    z[2,1,1]  R871      7.5941306352615356e-01
    z[2,1,1]  R872      4.8605209589004517e-01
    z[2,1,1]  R873      6.8820118904113770e-01
    z[2,1,1]  R874      4.4714894890785217e-01
    z[2,1,1]  R875      -1.3957631587982178e-01
    z[2,1,1]  R876      1.5866938233375549e-01
    z[2,1,1]  R877      8.7374888360500336e-02
    z[2,1,1]  R878      -5.2000995725393295e-02
    z[2,1,1]  R879      -3.3563992381095886e-01
    z[2,1,1]  R880      -2.8114026784896851e-01
    z[2,1,1]  R881      -2.0235392451286316e-01
    z[2,1,1]  R882      -3.9763000607490540e-01
    z[2,1,1]  R883      -1.9126047194004059e-01
    z[2,1,1]  R884      -3.2268315553665161e-01
    z[2,1,1]  R885      -1.1038208752870560e-01
    z[2,1,1]  R886      -1.0242065042257309e-01
    z[2,1,1]  R887      -3.7171953916549683e-01
    z[2,1,1]  R888      -2.7798095345497131e-01
    z[2,1,1]  R889      -7.3880583047866821e-01
    z[2,1,1]  R890      2.8852856159210205e-01
    z[2,1,1]  R891      -6.9745475053787231e-01
    z[2,1,1]  R892      -6.7659026384353638e-01
    z[2,1,1]  R893      1.5621243417263031e-01
    z[2,1,1]  R894      1.3875234127044678e-01
    z[2,1,1]  R895      7.7380046248435974e-02
    z[2,1,1]  R896      -2.4864664673805237e-01
    z[2,1,1]  R897      -7.1995544433593750e-01
    z[2,1,1]  R898      4.3988442420959473e-01
    z[2,1,1]  R899      -8.7624388933181763e-01
    z[2,1,1]  R900      -2.5671776384115219e-02
    z[2,1,1]  R901      3.5382679104804993e-01
    z[2,1,1]  R902      -1.6947848722338676e-02
    z[2,1,1]  R903      -2.8374776244163513e-01
    z[2,1,1]  R904      2.6474717259407043e-01
    z[2,1,1]  R905      3.5049974918365479e-01
    z[2,1,1]  R906      8.2094341516494751e-02
    z[2,1,1]  R907      5.8240371942520142e-01
    z[2,1,1]  R908      2.2649440169334412e-01
    z[2,1,1]  R909      -1.4183451235294342e-01
    z[2,1,1]  R910      -1.4633235335350037e-01
    z[2,1,1]  R911      -2.8569728136062622e-01
    z[2,1,1]  R912      3.9122492074966431e-01
    z[2,1,1]  R913      4.2709720134735107e-01
    z[2,1,1]  R914      2.0969817042350769e-01
    z[2,1,1]  R915      1.8353113532066345e-01
    z[2,1,1]  R916      4.3121472001075745e-01
    z[2,1,1]  R917      4.7087732702493668e-02
    z[2,1,1]  R918      3.2928496599197388e-01
    z[2,1,1]  R919      -4.2966210842132568e-01
    z[2,1,1]  R920      1.4785882830619812e-01
    z[2,1,1]  R921      5.3121572732925415e-01
    z[2,1,1]  R922      3.4137284755706787e-01
    z[2,1,1]  R923      2.1490712463855743e-01
    z[2,1,1]  R924      1.4756475389003754e-01
    z[2,1,1]  R925      -4.8007094860076904e-01
    z[2,1,1]  R926      -4.7991201281547546e-01
    z[2,1,1]  R927      -3.9515095949172974e-01
    z[2,1,1]  R928      -6.2988650798797607e-01
    z[2,1,1]  R929      4.1771256923675537e-01
    z[2,1,1]  R930      1.5441577136516571e-01
    z[2,1,1]  R931      -3.9207491278648376e-01
    z[2,1,1]  R932      1.6048018634319305e-01
    z[2,1,1]  R933      3.0565094947814941e-01
    z[2,1,1]  R934      3.3529585599899292e-01
    z[2,1,1]  R935      -4.1966083645820618e-01
    z[2,1,1]  R936      -2.7800619602203369e-01
    z[2,1,1]  R937      6.7779272794723511e-02
    z[2,1,1]  R938      -3.1335547566413879e-01
    z[2,1,1]  R939      4.0297958254814148e-01
    z[2,1,1]  R940      1.9702941179275513e-01
    z[2,1,1]  R941      4.1896373033523560e-01
    z[2,1,1]  R942      -4.1293808817863464e-01
    z[2,1,1]  R943      -5.4255348443984985e-01
    z[2,1,1]  R944      -3.4744662046432495e-01
    z[2,1,1]  R945      1.5410919487476349e-01
    z[2,1,1]  R946      -5.8917975425720215e-01
    z[2,1,1]  R947      9.3907696008682251e-01
    z[2,1,1]  R948      9.6039682626724243e-01
    z[2,1,1]  R949      1.8808189034461975e-01
    z[2,1,1]  R950      -3.5703826695680618e-02
    z[2,1,1]  R951      -2.1576354280114174e-02
    z[2,1,1]  R952      5.2840482443571091e-02
    z[2,1,1]  R953      -0.669160008430481
    z[2,1,1]  R954      8.5001587867736816e-01
    z[2,1,1]  R955      -4.2836752533912659e-01
    z[2,1,1]  R956      5.4281461238861084e-01
    z[2,1,1]  R957      -4.0056610107421875e-01
    z[2,1,1]  R958      -5.1552116870880127e-01
    z[2,1,1]  R959      2.4238830804824829e-01
    z[2,1,1]  R960      -1.0183142125606537e-01
    z[2,1,1]  R961      -5.1572978496551514e-01
    z[2,1,1]  R962      -7.6958012580871582e-01
    z[2,1,1]  R963      -2.7142700552940369e-01
    z[2,1,1]  R964      8.2527321577072144e-01
    z[2,1,1]  R965      8.8517922163009644e-01
    z[2,1,1]  R966      7.2231113910675049e-01
    z[2,1,1]  R967      0.835231363773346
    z[2,1,1]  R968      8.3807313442230225e-01
    z[2,1,1]  R969      -5.3620919585227966e-02
    z[2,1,1]  R970      2.3409350216388702e-01
    z[2,1,1]  R971      3.8337996602058411e-01
    z[2,1,1]  R972      -8.3246874809265137e-01
    z[2,1,1]  R973      -3.3632597327232361e-01
    z[2,1,1]  R974      0.822594165802002
    z[2,1,1]  R975      7.3138356208801270e-01
    z[2,1,1]  R976      7.8624749183654785e-01
    z[2,1,1]  R977      7.7497494220733643e-01
    z[2,1,1]  R978      7.3773950338363647e-01
    z[2,1,2]  R13       1
    z[2,1,2]  R22       -1
    z[2,1,2]  R845      -1
    z[2,1,2]  R846      1
    z[2,1,2]  R855      3.5933580994606018e-01
    z[2,1,2]  R856      -3.1633205711841583e-02
    z[2,1,2]  R857      1.9013518467545509e-02
    z[2,1,2]  R858      2.0099420845508575e-01
    z[2,1,2]  R859      5.9181636571884155e-01
    z[2,1,2]  R860      4.8591491580009460e-01
    z[2,1,2]  R861      1.9740661978721619e-01
    z[2,1,2]  R862      3.8579389452934265e-01
    z[2,1,2]  R863      -7.7522508800029755e-02
    z[2,1,2]  R864      7.4727272987365723e-01
    z[2,1,2]  R865      -1.2009497731924057e-01
    z[2,1,2]  R866      7.6472632586956024e-02
    z[2,1,2]  R867      3.2745766639709473e-01
    z[2,1,2]  R868      1.8415714800357819e-01
    z[2,1,2]  R869      -1.2678658962249756e-01
    z[2,1,2]  R870      -4.4335469603538513e-01
    z[2,1,2]  R871      4.9939689040184021e-01
    z[2,1,2]  R872      -1.5145042538642883e-01
    z[2,1,2]  R873      9.8478108644485474e-02
    z[2,1,2]  R874      -5.7115167379379272e-02
    z[2,1,2]  R875      -5.1285862922668457e-01
    z[2,1,2]  R876      -0.381136029958725
    z[2,1,2]  R877      -5.9377545118331909e-01
    z[2,1,2]  R878      -0.43329918384552
    z[2,1,2]  R879      -1.1853816360235214e-01
    z[2,1,2]  R880      -1.3509753160178661e-02
    z[2,1,2]  R881      -5.8933593332767487e-02
    z[2,1,2]  R882      -5.3258843719959259e-02
    z[2,1,2]  R883      7.5866342522203922e-03
    z[2,1,2]  R884      6.0134965926408768e-02
    z[2,1,2]  R885      2.9740616679191589e-01
    z[2,1,2]  R886      2.6105591654777527e-01
    z[2,1,2]  R887      -2.3807699978351593e-01
    z[2,1,2]  R888      2.2151088714599609e-01
    z[2,1,2]  R889      -1.4257369935512543e-01
    z[2,1,2]  R890      2.1280555427074432e-01
    z[2,1,2]  R891      -5.3871236741542816e-02
    z[2,1,2]  R892      -0.158564493060112
    z[2,1,2]  R893      -7.0406176149845123e-02
    z[2,1,2]  R894      -1.9678844138979912e-02
    z[2,1,2]  R895      -2.5658485293388367e-01
    z[2,1,2]  R896      -3.8320258259773254e-01
    z[2,1,2]  R897      1.7249508202075958e-01
    z[2,1,2]  R898      4.3248921632766724e-01
    z[2,1,2]  R899      -1.2811531126499176e-01
    z[2,1,2]  R900      1.4191722869873047e-01
    z[2,1,2]  R901      -1.0315258055925369e-01
    z[2,1,2]  R902      5.7939875125885010e-01
    z[2,1,2]  R903      4.5659548044204712e-01
    z[2,1,2]  R904      -2.1855439245700836e-01
    z[2,1,2]  R905      -2.0133875310420990e-01
    z[2,1,2]  R906      1.3484379276633263e-02
    z[2,1,2]  R907      2.1422983705997467e-01
    z[2,1,2]  R908      2.9233434796333313e-01
    z[2,1,2]  R909      3.5992351174354553e-01
    z[2,1,2]  R910      -0.679987370967865
    z[2,1,2]  R911      -2.2934034466743469e-01
    z[2,1,2]  R912      -0.0109430942684412
    z[2,1,2]  R913      -1.5799516439437866e-01
    z[2,1,2]  R914      1.1394404806196690e-02
    z[2,1,2]  R915      -2.3620298597961664e-03
    z[2,1,2]  R916      1.6179924830794334e-02
    z[2,1,2]  R917      -0.0656462013721466
    z[2,1,2]  R918      3.4418323636054993e-01
    z[2,1,2]  R919      3.0129194259643555e-01
    z[2,1,2]  R920      2.8884598612785339e-01
    z[2,1,2]  R921      1.9122385978698730e-01
    z[2,1,2]  R922      -2.9208555817604065e-01
    z[2,1,2]  R923      -2.2691851854324341e-01
    z[2,1,2]  R924      6.4044152386486530e-03
    z[2,1,2]  R925      2.0478211343288422e-01
    z[2,1,2]  R926      1.4265184104442596e-01
    z[2,1,2]  R927      2.4560482800006866e-01
    z[2,1,2]  R928      -2.2371813654899597e-01
    z[2,1,2]  R929      6.0382062196731567e-01
    z[2,1,2]  R930      0.0838552713394165
    z[2,1,2]  R931      -3.8139653205871582e-01
    z[2,1,2]  R932      3.2950885593891144e-02
    z[2,1,2]  R933      -7.8959226608276367e-02
    z[2,1,2]  R934      1.7590709030628204e-01
    z[2,1,2]  R935      -2.7172014117240906e-01
    z[2,1,2]  R936      -1.8509723246097565e-01
    z[2,1,2]  R937      3.8466113805770874e-01
    z[2,1,2]  R938      -1.3332429528236389e-01
    z[2,1,2]  R939      3.1154736876487732e-01
    z[2,1,2]  R940      1.9985429942607880e-02
    z[2,1,2]  R941      2.8842157125473022e-01
    z[2,1,2]  R942      -4.1602656245231628e-02
    z[2,1,2]  R943      -1.7169304192066193e-02
    z[2,1,2]  R944      -1.9052948057651520e-01
    z[2,1,2]  R945      -2.5256642699241638e-01
    z[2,1,2]  R946      7.0102256722748280e-03
    z[2,1,2]  R947      -1.6414555907249451e-01
    z[2,1,2]  R948      -3.6084707826375961e-02
    z[2,1,2]  R949      -5.1217749714851379e-02
    z[2,1,2]  R950      -5.1917475461959839e-01
    z[2,1,2]  R951      -5.8295524120330811e-01
    z[2,1,2]  R952      1.7868605256080627e-01
    z[2,1,2]  R953      3.4137687087059021e-01
    z[2,1,2]  R954      -3.3170655369758606e-01
    z[2,1,2]  R955      1.3348698616027832e-01
    z[2,1,2]  R956      -5.5416148900985718e-01
    z[2,1,2]  R957      3.6347416043281555e-01
    z[2,1,2]  R958      -4.5652204751968384e-01
    z[2,1,2]  R959      -7.0415951311588287e-02
    z[2,1,2]  R960      -4.7058498859405518e-01
    z[2,1,2]  R961      -3.4134802222251892e-01
    z[2,1,2]  R962      -1.0316787520423532e-03
    z[2,1,2]  R963      6.6267979145050049e-01
    z[2,1,2]  R964      -1.2245739996433258e-01
    z[2,1,2]  R965      3.1064450740814209e-03
    z[2,1,2]  R966      -1.9768038392066956e-01
    z[2,1,2]  R967      -2.6481890678405762e-01
    z[2,1,2]  R968      -1.8159645795822144e-01
    z[2,1,2]  R969      -4.6260491013526917e-01
    z[2,1,2]  R970      -1.7056234180927277e-01
    z[2,1,2]  R971      -2.9695001244544983e-01
    z[2,1,2]  R972      3.5705637186765671e-02
    z[2,1,2]  R973      5.0237149000167847e-01
    z[2,1,2]  R974      -6.4319007098674774e-02
    z[2,1,2]  R975      1.2722036242485046e-01
    z[2,1,2]  R976      -7.0435716770589352e-03
    z[2,1,2]  R977      -9.3880154192447662e-02
    z[2,1,2]  R978      1.7199160158634186e-01
    z[2,1,3]  R14       1
    z[2,1,3]  R23       -1
    z[2,1,3]  R847      -1
    z[2,1,3]  R848      1
    z[2,1,3]  R855      -4.1641983389854431e-01
    z[2,1,3]  R856      -0.581412672996521
    z[2,1,3]  R857      -3.9674839377403259e-01
    z[2,1,3]  R858      -2.2573718428611755e-01
    z[2,1,3]  R859      0.151409313082695
    z[2,1,3]  R860      1.7278465628623962e-01
    z[2,1,3]  R861      -2.1413658559322357e-01
    z[2,1,3]  R862      1.2555651366710663e-01
    z[2,1,3]  R863      1.1373896151781082e-01
    z[2,1,3]  R864      -2.2943688556551933e-02
    z[2,1,3]  R865      9.0139739215373993e-02
    z[2,1,3]  R866      8.0782070755958557e-02
    z[2,1,3]  R867      4.3264187872409821e-02
    z[2,1,3]  R868      2.2799910511821508e-03
    z[2,1,3]  R869      -3.0812883377075195e-01
    z[2,1,3]  R870      -0.0792752057313919
    z[2,1,3]  R871      7.7979043126106262e-02
    z[2,1,3]  R872      -2.6251441240310669e-01
    z[2,1,3]  R873      -4.3058654665946960e-01
    z[2,1,3]  R874      -6.4221984148025513e-01
    z[2,1,3]  R875      6.5747827291488647e-01
    z[2,1,3]  R876      6.9999152421951294e-01
    z[2,1,3]  R877      5.6981217861175537e-01
    z[2,1,3]  R878      2.0941333472728729e-01
    z[2,1,3]  R879      3.7642562389373779e-01
    z[2,1,3]  R880      2.2613757848739624e-01
    z[2,1,3]  R881      2.8243386745452881e-01
    z[2,1,3]  R882      0.0550660714507103
    z[2,1,3]  R883      -3.1871774792671204e-01
    z[2,1,3]  R884      0.0724758729338646
    z[2,1,3]  R885      -0.0727483481168747
    z[2,1,3]  R886      -1.5462476760149002e-02
    z[2,1,3]  R887      -2.2073060274124146e-01
    z[2,1,3]  R888      6.2123283743858337e-02
    z[2,1,3]  R889      -0.424940824508667
    z[2,1,3]  R890      -1.5746068954467773e-01
    z[2,1,3]  R891      -4.0981835126876831e-01
    z[2,1,3]  R892      -4.5490843057632446e-01
    z[2,1,3]  R893      2.8890269994735718e-01
    z[2,1,3]  R894      -3.9071059226989746e-01
    z[2,1,3]  R895      -0.346769779920578
    z[2,1,3]  R896      3.4356537461280823e-01
    z[2,1,3]  R897      2.8785686939954758e-02
    z[2,1,3]  R898      -4.6313452720642090e-01
    z[2,1,3]  R899      -3.9203029870986938e-01
    z[2,1,3]  R900      -6.5651428699493408e-01
    z[2,1,3]  R901      -2.4493958055973053e-01
    z[2,1,3]  R902      -5.6359034776687622e-01
    z[2,1,3]  R903      -4.9433851242065430e-01
    z[2,1,3]  R904      2.3379026353359222e-01
    z[2,1,3]  R905      3.6727815866470337e-01
    z[2,1,3]  R906      3.2355868816375732e-01
    z[2,1,3]  R907      -5.8226162195205688e-01
    z[2,1,3]  R908      -4.4555738568305969e-01
    z[2,1,3]  R909      -0.281028687953949
    z[2,1,3]  R910      1.4870950579643250e-01
    z[2,1,3]  R911      -0.0558922179043293
    z[2,1,3]  R912      1.5222573280334473e-01
    z[2,1,3]  R913      -1.1127392202615738e-01
    z[2,1,3]  R914      2.6698562502861023e-01
    z[2,1,3]  R915      0.0815851241350174
    z[2,1,3]  R916      2.0858474075794220e-01
    z[2,1,3]  R917      2.5546187162399292e-01
    z[2,1,3]  R918      2.7224791049957275e-01
    z[2,1,3]  R919      -5.8066624402999878e-01
    z[2,1,3]  R920      -2.1184456348419189e-01
    z[2,1,3]  R921      -7.1251779794692993e-01
    z[2,1,3]  R922      -0.0191778764128685
    z[2,1,3]  R923      -3.0335992574691772e-01
    z[2,1,3]  R924      2.6501855254173279e-01
    z[2,1,3]  R925      6.0697649605572224e-03
    z[2,1,3]  R926      1.4614929258823395e-01
    z[2,1,3]  R927      -2.5967705994844437e-02
    z[2,1,3]  R928      -3.8211518526077271e-01
    z[2,1,3]  R929      -5.6091696023941040e-01
    z[2,1,3]  R930      -9.1272346675395966e-02
    z[2,1,3]  R931      3.3846864104270935e-01
    z[2,1,3]  R932      3.7194166332483292e-02
    z[2,1,3]  R933      4.0260624140501022e-02
    z[2,1,3]  R934      -2.9305824637413025e-01
    z[2,1,3]  R935      0.207631453871727
    z[2,1,3]  R936      6.7774903774261475e-01
    z[2,1,3]  R937      -6.9623276591300964e-02
    z[2,1,3]  R938      -2.0771314203739166e-01
    z[2,1,3]  R939      -0.00696546770632267
    z[2,1,3]  R940      7.0355825126171112e-02
    z[2,1,3]  R941      4.4429653882980347e-01
    z[2,1,3]  R942      7.4754811823368073e-02
    z[2,1,3]  R943      1.6481418907642365e-01
    z[2,1,3]  R944      -2.6582974195480347e-01
    z[2,1,3]  R945      8.2485699653625488e-01
    z[2,1,3]  R946      5.0227355957031250e-01
    z[2,1,3]  R947      1.0876694321632385e-01
    z[2,1,3]  R948      1.2753970222547650e-03
    z[2,1,3]  R949      8.4732629358768463e-02
    z[2,1,3]  R950      6.2167018651962280e-01
    z[2,1,3]  R951      5.9127581119537354e-01
    z[2,1,3]  R952      -3.6739131808280945e-01
    z[2,1,3]  R953      2.9516467452049255e-01
    z[2,1,3]  R954      -1.0469325631856918e-01
    z[2,1,3]  R955      -1.3179023563861847e-01
    z[2,1,3]  R956      -4.7945481538772583e-01
    z[2,1,3]  R957      5.8445721864700317e-01
    z[2,1,3]  R958      4.0771072963252664e-04
    z[2,1,3]  R959      0.0796792060136795
    z[2,1,3]  R960      5.8450758457183838e-01
    z[2,1,3]  R961      -6.9646090269088745e-01
    z[2,1,3]  R962      3.2750996947288513e-01
    z[2,1,3]  R963      4.2184704542160034e-01
    z[2,1,3]  R964      -3.8457545638084412e-01
    z[2,1,3]  R965      -3.3123109489679337e-02
    z[2,1,3]  R966      -1.1977288126945496e-01
    z[2,1,3]  R967      -2.5463856291025877e-03
    z[2,1,3]  R968      2.8450268507003784e-01
    z[2,1,3]  R969      5.8854973316192627e-01
    z[2,1,3]  R970      -5.7986426353454590e-01
    z[2,1,3]  R971      -2.5151500478386879e-02
    z[2,1,3]  R972      3.2991883158683777e-01
    z[2,1,3]  R973      6.6927188634872437e-01
    z[2,1,3]  R974      2.9772832989692688e-01
    z[2,1,3]  R975      6.1433595418930054e-01
    z[2,1,3]  R976      4.2071422934532166e-01
    z[2,1,3]  R977      -1.9240427762269974e-02
    z[2,1,3]  R978      0.529548168182373
    z[2,1,4]  R15       1
    z[2,1,4]  R24       -1
    z[2,1,4]  R849      -1
    z[2,1,4]  R850      1
    z[2,1,4]  R855      -1.1001219972968102e-03
    z[2,1,4]  R856      2.8186461329460144e-01
    z[2,1,4]  R857      5.1787173748016357e-01
    z[2,1,4]  R858      3.3614826202392578e-01
    z[2,1,4]  R859      4.3787100911140442e-01
    z[2,1,4]  R860      -9.2299081385135651e-02
    z[2,1,4]  R861      4.5325309038162231e-01
    z[2,1,4]  R862      1.7119120061397552e-01
    z[2,1,4]  R863      -0.172170028090477
    z[2,1,4]  R864      1.5981712937355042e-01
    z[2,1,4]  R865      -9.1165617108345032e-02
    z[2,1,4]  R866      3.1064444780349731e-01
    z[2,1,4]  R867      -4.0164259076118469e-01
    z[2,1,4]  R868      -0.0375276580452919
    z[2,1,4]  R869      -2.1597084403038025e-01
    z[2,1,4]  R870      -2.6986721158027649e-01
    z[2,1,4]  R871      2.0343777537345886e-01
    z[2,1,4]  R872      -4.7412395477294922e-01
    z[2,1,4]  R873      2.9025465250015259e-01
    z[2,1,4]  R874      4.0439318865537643e-02
    z[2,1,4]  R875      3.3689764142036438e-01
    z[2,1,4]  R876      5.4812509566545486e-02
    z[2,1,4]  R877      3.5733726620674133e-01
    z[2,1,4]  R878      -3.7407171726226807e-01
    z[2,1,4]  R879      4.2370632290840149e-01
    z[2,1,4]  R880      1.8065446987748146e-02
    z[2,1,4]  R881      3.6739388108253479e-01
    z[2,1,4]  R882      5.8633655309677124e-01
    z[2,1,4]  R883      1.6537471115589142e-01
    z[2,1,4]  R884      1.6097468137741089e-01
    z[2,1,4]  R885      1.7848816514015198e-01
    z[2,1,4]  R886      2.6838836073875427e-01
    z[2,1,4]  R887      1.1645889282226562e-01
    z[2,1,4]  R888      2.9949453473091125e-01
    z[2,1,4]  R889      -1.5863038599491119e-01
    z[2,1,4]  R890      -2.0651364326477051e-01
    z[2,1,4]  R891      -3.7758240103721619e-01
    z[2,1,4]  R892      -8.3849288523197174e-02
    z[2,1,4]  R893      -5.0751942396163940e-01
    z[2,1,4]  R894      -9.4126991927623749e-02
    z[2,1,4]  R895      1.0345663875341415e-01
    z[2,1,4]  R896      -7.7445471286773682e-01
    z[2,1,4]  R897      -4.0884593129158020e-01
    z[2,1,4]  R898      -5.5066245794296265e-01
    z[2,1,4]  R899      -1.9226944446563721e-01
    z[2,1,4]  R900      2.1234290301799774e-01
    z[2,1,4]  R901      -2.9462394118309021e-01
    z[2,1,4]  R902      -4.5862805843353271e-01
    z[2,1,4]  R903      -2.9427188634872437e-01
    z[2,1,4]  R904      0.473821222782135
    z[2,1,4]  R905      1.7656306922435760e-01
    z[2,1,4]  R906      0.512280285358429
    z[2,1,4]  R907      1.8443444371223450e-01
    z[2,1,4]  R908      6.3173137605190277e-02
    z[2,1,4]  R909      -5.9691351652145386e-01
    z[2,1,4]  R910      -5.0122201442718506e-01
    z[2,1,4]  R911      -8.1298923492431641e-01
    z[2,1,4]  R912      4.1157731413841248e-01
    z[2,1,4]  R913      0.13089619576931
    z[2,1,4]  R914      1.8609413504600525e-01
    z[2,1,4]  R915      1.9791173934936523e-01
    z[2,1,4]  R916      -2.6141893118619919e-02
    z[2,1,4]  R917      7.1282177232205868e-03
    z[2,1,4]  R918      -5.2257917821407318e-02
    z[2,1,4]  R919      -3.5380131006240845e-01
    z[2,1,4]  R920      -6.8181025981903076e-01
    z[2,1,4]  R921      -3.4506028890609741e-01
    z[2,1,4]  R922      -1.3816542923450470e-01
    z[2,1,4]  R923      3.3916497230529785e-01
    z[2,1,4]  R924      -7.2195746004581451e-02
    z[2,1,4]  R925      9.0210400521755219e-02
    z[2,1,4]  R926      -2.2630941867828369e-01
    z[2,1,4]  R927      -1.1395063996315002e-01
    z[2,1,4]  R928      2.5320026278495789e-01
    z[2,1,4]  R929      -2.6496413350105286e-01
    z[2,1,4]  R930      1.2268720567226410e-01
    z[2,1,4]  R931      -0.516111433506012
    z[2,1,4]  R932      -7.7362522482872009e-02
    z[2,1,4]  R933      3.6041066050529480e-01
    z[2,1,4]  R934      1.6203403472900391e-02
    z[2,1,4]  R935      3.3967226743698120e-02
    z[2,1,4]  R936      -4.0043359994888306e-01
    z[2,1,4]  R937      2.4488031864166260e-01
    z[2,1,4]  R938      -2.7999168634414673e-01
    z[2,1,4]  R939      1.5323479473590851e-01
    z[2,1,4]  R940      2.2334653884172440e-02
    z[2,1,4]  R941      -1.8812276422977448e-01
    z[2,1,4]  R942      -2.4828863143920898e-01
    z[2,1,4]  R943      -1.6168478131294250e-01
    z[2,1,4]  R944      -1.5106610953807831e-01
    z[2,1,4]  R945      7.6155625283718109e-02
    z[2,1,4]  R946      4.5021429657936096e-02
    z[2,1,4]  R947      1.1790663003921509e-01
    z[2,1,4]  R948      3.5410594195127487e-02
    z[2,1,4]  R949      0.0838705375790596
    z[2,1,4]  R950      -1.5915378928184509e-01
    z[2,1,4]  R951      -5.2755761146545410e-01
    z[2,1,4]  R952      -2.4036690592765808e-01
    z[2,1,4]  R953      -5.0913745164871216e-01
    z[2,1,4]  R954      0.000716552953235805
    z[2,1,4]  R955      5.7074010372161865e-01
    z[2,1,4]  R956      -1.7616911232471466e-01
    z[2,1,4]  R957      4.8988372087478638e-02
    z[2,1,4]  R958      3.4998711943626404e-01
    z[2,1,4]  R959      2.0113010704517365e-01
    z[2,1,4]  R960      -1.8414147198200226e-01
    z[2,1,4]  R961      2.8846734762191772e-01
    z[2,1,4]  R962      -4.8386237025260925e-01
    z[2,1,4]  R963      -4.8561595380306244e-02
    z[2,1,4]  R964      -2.9330602288246155e-01
    z[2,1,4]  R965      -4.0362879633903503e-01
    z[2,1,4]  R966      -3.4878385066986084e-01
    z[2,1,4]  R967      -3.7716156244277954e-01
    z[2,1,4]  R968      -3.8579076528549194e-01
    z[2,1,4]  R969      -3.0203866958618164e-01
    z[2,1,4]  R970      4.6352226287126541e-02
    z[2,1,4]  R971      1.6870559751987457e-01
    z[2,1,4]  R972      -2.5287646055221558e-01
    z[2,1,4]  R973      -1.5198273956775665e-01
    z[2,1,4]  R974      -2.8569018840789795e-01
    z[2,1,4]  R975      -1.9161500036716461e-01
    z[2,1,4]  R976      -2.7352344989776611e-01
    z[2,1,4]  R977      -2.6284396648406982e-01
    z[2,1,4]  R978      -1.8524785339832306e-01
    z[2,1,5]  R16       1
    z[2,1,5]  R25       -1
    z[2,1,5]  R851      -1
    z[2,1,5]  R852      1
    z[2,1,5]  R855      5.8147519826889038e-01
    z[2,1,5]  R856      -1.3164943456649780e-01
    z[2,1,5]  R857      0.369782954454422
    z[2,1,5]  R858      -1.2190397083759308e-01
    z[2,1,5]  R859      3.2342159748077393e-01
    z[2,1,5]  R860      -5.2841216325759888e-02
    z[2,1,5]  R861      3.4322327375411987e-01
    z[2,1,5]  R862      6.2322318553924561e-01
    z[2,1,5]  R863      8.4276765584945679e-02
    z[2,1,5]  R864      -5.3143654018640518e-02
    z[2,1,5]  R865      1.3258161488920450e-03
    z[2,1,5]  R866      3.2388001680374146e-01
    z[2,1,5]  R867      -8.1217736005783081e-02
    z[2,1,5]  R868      -1.0150302201509476e-01
    z[2,1,5]  R869      2.2486111521720886e-01
    z[2,1,5]  R870      2.5098431110382080e-01
    z[2,1,5]  R871      -5.9654969722032547e-02
    z[2,1,5]  R872      -4.1578780859708786e-02
    z[2,1,5]  R873      7.0019364356994629e-02
    z[2,1,5]  R874      -0.144505113363266
    z[2,1,5]  R875      8.7805442512035370e-02
    z[2,1,5]  R876      6.7401833832263947e-02
    z[2,1,5]  R877      -0.0353923924267292
    z[2,1,5]  R878      -7.2828090190887451e-01
    z[2,1,5]  R879      -1.0683242231607437e-02
    z[2,1,5]  R880      4.4384026527404785e-01
    z[2,1,5]  R881      5.6114387512207031e-01
    z[2,1,5]  R882      2.2153569757938385e-01
    z[2,1,5]  R883      0.0785888135433197
    z[2,1,5]  R884      -2.0154097676277161e-01
    z[2,1,5]  R885      -1.4973272383213043e-01
    z[2,1,5]  R886      -2.0013237372040749e-02
    z[2,1,5]  R887      1.4452475309371948e-01
    z[2,1,5]  R888      1.1037625372409821e-01
    z[2,1,5]  R889      1.5011714398860931e-01
    z[2,1,5]  R890      1.9484703242778778e-01
    z[2,1,5]  R891      4.0779468417167664e-01
    z[2,1,5]  R892      -3.6305990815162659e-01
    z[2,1,5]  R893      -1.8814601004123688e-01
    z[2,1,5]  R894      2.2578341886401176e-02
    z[2,1,5]  R895      4.0209281444549561e-01
    z[2,1,5]  R896      -2.2305153310298920e-01
    z[2,1,5]  R897      -3.4657639265060425e-01
    z[2,1,5]  R898      1.3650451600551605e-01
    z[2,1,5]  R899      -1.4910818636417389e-01
    z[2,1,5]  R900      -5.7941582053899765e-02
    z[2,1,5]  R901      -4.3500947952270508e-01
    z[2,1,5]  R902      1.2846945226192474e-01
    z[2,1,5]  R903      -1.9584308564662933e-01
    z[2,1,5]  R904      5.0724223256111145e-03
    z[2,1,5]  R905      -3.4511899948120117e-01
    z[2,1,5]  R906      -5.1498431712388992e-03
    z[2,1,5]  R907      4.2048788070678711e-01
    z[2,1,5]  R908      -0.248139888048172
    z[2,1,5]  R909      -2.2326861321926117e-01
    z[2,1,5]  R910      -1.4089688658714294e-01
    z[2,1,5]  R911      -3.5816648602485657e-01
    z[2,1,5]  R912      -1.9831705838441849e-02
    z[2,1,5]  R913      -2.8302398324012756e-01
    z[2,1,5]  R914      -2.6607608795166016e-01
    z[2,1,5]  R915      -9.3816900625824928e-03
    z[2,1,5]  R916      -0.00913193728774786
    z[2,1,5]  R917      -3.4307509660720825e-01
    z[2,1,5]  R918      1.3647709786891937e-01
    z[2,1,5]  R919      2.2741788998246193e-02
    z[2,1,5]  R920      4.9062767624855042e-01
    z[2,1,5]  R921      4.5953061431646347e-02
    z[2,1,5]  R922      -1.4729671180248260e-01
    z[2,1,5]  R923      -2.3401673138141632e-01
    z[2,1,5]  R924      4.9856898188591003e-01
    z[2,1,5]  R925      2.8222987055778503e-01
    z[2,1,5]  R926      -9.2234506155364215e-05
    z[2,1,5]  R927      -2.2545018792152405e-01
    z[2,1,5]  R928      4.0567898750305176e-01
    z[2,1,5]  R929      -1.1036479473114014e-01
    z[2,1,5]  R930      2.5438693165779114e-01
    z[2,1,5]  R931      -1.0560341179370880e-01
    z[2,1,5]  R932      4.6336323022842407e-01
    z[2,1,5]  R933      4.7741317749023438e-01
    z[2,1,5]  R934      -5.3843200206756592e-01
    z[2,1,5]  R935      -2.3436771705746651e-02
    z[2,1,5]  R936      3.7715956568717957e-01
    z[2,1,5]  R937      -0.510245680809021
    z[2,1,5]  R938      1.1509119719266891e-01
    z[2,1,5]  R939      -6.6956095397472382e-02
    z[2,1,5]  R940      4.1354256868362427e-01
    z[2,1,5]  R941      -0.234359011054039
    z[2,1,5]  R942      1.6112641990184784e-01
    z[2,1,5]  R943      1.0046856850385666e-01
    z[2,1,5]  R944      1.0830528289079666e-01
    z[2,1,5]  R945      1.3350382447242737e-01
    z[2,1,5]  R946      8.2315705716609955e-02
    z[2,1,5]  R947      4.7807514667510986e-02
    z[2,1,5]  R948      -1.8564681708812714e-01
    z[2,1,5]  R949      3.8254481554031372e-01
    z[2,1,5]  R950      4.2950016260147095e-01
    z[2,1,5]  R951      4.4323410838842392e-02
    z[2,1,5]  R952      -3.0888348817825317e-01
    z[2,1,5]  R953      -1.7003257572650909e-01
    z[2,1,5]  R954      -2.1060745418071747e-01
    z[2,1,5]  R955      -2.8826245665550232e-01
    z[2,1,5]  R956      -3.1406667828559875e-01
    z[2,1,5]  R957      -4.2162844538688660e-01
    z[2,1,5]  R958      -2.5881221890449524e-01
    z[2,1,5]  R959      3.3505931496620178e-01
    z[2,1,5]  R960      4.9329307675361633e-01
    z[2,1,5]  R961      1.1204126477241516e-01
    z[2,1,5]  R962      2.9471702873706818e-03
    z[2,1,5]  R963      5.1336448639631271e-02
    z[2,1,5]  R964      -1.6353687644004822e-01
    z[2,1,5]  R965      -3.7536349147558212e-02
    z[2,1,5]  R966      -4.7130686044692993e-01
    z[2,1,5]  R967      1.5334385633468628e-01
    z[2,1,5]  R968      -2.6177048683166504e-02
    z[2,1,5]  R969      5.0096571445465088e-01
    z[2,1,5]  R970      -2.0492132753133774e-02
    z[2,1,5]  R971      2.4650931358337402e-01
    z[2,1,5]  R972      3.1349015235900879e-01
    z[2,1,5]  R973      -1.9713032990694046e-02
    z[2,1,5]  R974      3.5099261999130249e-01
    z[2,1,5]  R975      1.7596293985843658e-01
    z[2,1,5]  R976      0.315409392118454
    z[2,1,5]  R977      -4.4421949982643127e-01
    z[2,1,5]  R978      8.2742515951395035e-03
    z[2,1,6]  R17       1
    z[2,1,6]  R26       -1
    z[2,1,6]  R853      -1
    z[2,1,6]  R854      1
    z[2,1,6]  R855      -6.5398856997489929e-02
    z[2,1,6]  R856      -8.5410483181476593e-02
    z[2,1,6]  R857      -4.9335431307554245e-02
    z[2,1,6]  R858      -5.1971656084060669e-01
    z[2,1,6]  R859      1.2869545817375183e-01
    z[2,1,6]  R860      -2.8008174896240234e-01
    z[2,1,6]  R861      0.523004949092865
    z[2,1,6]  R862      -2.2640366852283478e-01
    z[2,1,6]  R863      2.6593515276908875e-01
    z[2,1,6]  R864      3.5641238093376160e-01
    z[2,1,6]  R865      2.8633415699005127e-01
    z[2,1,6]  R866      1.0971251875162125e-01
    z[2,1,6]  R867      -3.4122490882873535e-01
    z[2,1,6]  R868      -5.7082408666610718e-01
    z[2,1,6]  R869      -5.4641157388687134e-01
    z[2,1,6]  R870      -3.9022284746170044e-01
    z[2,1,6]  R871      -2.5672206282615662e-01
    z[2,1,6]  R872      -3.1493085622787476e-01
    z[2,1,6]  R873      -4.0359282493591309e-01
    z[2,1,6]  R874      -1.8941122293472290e-01
    z[2,1,6]  R875      -3.3500626683235168e-01
    z[2,1,6]  R876      1.4404852688312531e-01
    z[2,1,6]  R877      -2.0026246085762978e-02
    z[2,1,6]  R878      -2.7827879786491394e-01
    z[2,1,6]  R879      1.6781672835350037e-01
    z[2,1,6]  R880      1.5728285908699036e-01
    z[2,1,6]  R881      -0.212831050157547
    z[2,1,6]  R882      1.1290422827005386e-01
    z[2,1,6]  R883      -2.0314763486385345e-01
    z[2,1,6]  R884      -2.0503292977809906e-01
    z[2,1,6]  R885      -2.0527285337448120e-01
    z[2,1,6]  R886      7.4418224394321442e-02
    z[2,1,6]  R887      -5.1902536302804947e-02
    z[2,1,6]  R888      1.1466937512159348e-01
    z[2,1,6]  R889      -3.8242095708847046e-01
    z[2,1,6]  R890      -0.123700812458992
    z[2,1,6]  R891      4.4131819158792496e-02
    z[2,1,6]  R892      2.0914927124977112e-01
    z[2,1,6]  R893      -1.5266370773315430e-01
    z[2,1,6]  R894      4.7503036260604858e-01
    z[2,1,6]  R895      -2.6302579045295715e-01
    z[2,1,6]  R896      -1.5337653458118439e-01
    z[2,1,6]  R897      3.7807431817054749e-01
    z[2,1,6]  R898      2.7391368150711060e-01
    z[2,1,6]  R899      2.6329910382628441e-02
    z[2,1,6]  R900      7.0679372549057007e-01
    z[2,1,6]  R901      4.6605333685874939e-02
    z[2,1,6]  R902      -3.4513169527053833e-01
    z[2,1,6]  R903      5.8406114578247070e-01
    z[2,1,6]  R904      -1.3775852508842945e-02
    z[2,1,6]  R905      -1.3469657301902771e-01
    z[2,1,6]  R906      6.3891232013702393e-02
    z[2,1,6]  R907      2.4693049490451813e-01
    z[2,1,6]  R908      2.5733673572540283e-01
    z[2,1,6]  R909      5.1083713769912720e-01
    z[2,1,6]  R910      4.4374740123748779e-01
    z[2,1,6]  R911      1.5302394330501556e-01
    z[2,1,6]  R912      -1.9526831805706024e-01
    z[2,1,6]  R913      -2.2403992712497711e-01
    z[2,1,6]  R914      -2.3340111970901489e-01
    z[2,1,6]  R915      4.2828115820884705e-01
    z[2,1,6]  R916      2.6880177855491638e-01
    z[2,1,6]  R917      2.2382782399654388e-01
    z[2,1,6]  R918      3.6712527275085449e-01
    z[2,1,6]  R919      4.4752866029739380e-01
    z[2,1,6]  R920      1.1494905501604080e-01
    z[2,1,6]  R921      1.8742652237415314e-01
    z[2,1,6]  R922      -2.2395202517509460e-01
    z[2,1,6]  R923      2.3580574989318848e-01
    z[2,1,6]  R924      1.2304235994815826e-01
    z[2,1,6]  R925      2.9824849218130112e-02
    z[2,1,6]  R926      2.2685025632381439e-01
    z[2,1,6]  R927      -9.2453166842460632e-02
    z[2,1,6]  R928      5.9650313109159470e-02
    z[2,1,6]  R929      0.196893572807312
    z[2,1,6]  R930      -1.2163080275058746e-01
    z[2,1,6]  R931      -5.5359661579132080e-01
    z[2,1,6]  R932      0.301082581281662
    z[2,1,6]  R933      1.8784141540527344e-01
    z[2,1,6]  R934      2.5613343715667725e-01
    z[2,1,6]  R935      -1.7376577854156494e-01
    z[2,1,6]  R936      1.1973126232624054e-01
    z[2,1,6]  R937      1.3432615995407104e-01
    z[2,1,6]  R938      1.5900996327400208e-01
    z[2,1,6]  R939      8.2109540700912476e-02
    z[2,1,6]  R940      3.1177085638046265e-01
    z[2,1,6]  R941      9.5916397869586945e-02
    z[2,1,6]  R942      -1.2706008553504944e-01
    z[2,1,6]  R943      -3.4822601079940796e-01
    z[2,1,6]  R944      1.3286796212196350e-01
    z[2,1,6]  R945      -2.3847262561321259e-01
    z[2,1,6]  R946      -7.5521886348724365e-02
    z[2,1,6]  R947      4.7048706561326981e-02
    z[2,1,6]  R948      -9.0640291571617126e-02
    z[2,1,6]  R949      2.1592923998832703e-01
    z[2,1,6]  R950      9.9643588066101074e-02
    z[2,1,6]  R951      -1.5728241205215454e-01
    z[2,1,6]  R952      1.2270531058311462e-01
    z[2,1,6]  R953      -2.2878400981426239e-01
    z[2,1,6]  R954      2.3199106752872467e-01
    z[2,1,6]  R955      -0.0837583988904953
    z[2,1,6]  R956      -1.3407164812088013e-01
    z[2,1,6]  R957      1.3882575929164886e-01
    z[2,1,6]  R958      -5.1358896493911743e-01
    z[2,1,6]  R959      2.2299818694591522e-01
    z[2,1,6]  R960      1.8443956971168518e-01
    z[2,1,6]  R961      -6.9723889231681824e-02
    z[2,1,6]  R962      -1.9082710146903992e-01
    z[2,1,6]  R963      -6.0413774102926254e-02
    z[2,1,6]  R964      -1.6859705746173859e-01
    z[2,1,6]  R965      8.4657423198223114e-02
    z[2,1,6]  R966      -2.8084853291511536e-01
    z[2,1,6]  R967      -1.8471510848030448e-03
    z[2,1,6]  R968      -5.2542369812726974e-03
    z[2,1,6]  R969      1.1301857233047485e-01
    z[2,1,6]  R970      1.4101485908031464e-01
    z[2,1,6]  R971      -2.0797398686408997e-01
    z[2,1,6]  R972      -1.3379167020320892e-01
    z[2,1,6]  R973      -2.0895868539810181e-02
    z[2,1,6]  R974      -5.8076906949281693e-02
    z[2,1,6]  R975      5.0957348197698593e-02
    z[2,1,6]  R976      1.7451328039169312e-01
    z[2,1,6]  R977      3.5186418890953064e-01
    z[2,1,6]  R978      -2.1904313564300537e-01
    z[1,4,0]  R11       -1
    z[1,4,0]  R38       1
    z[1,4,0]  R979      -1
    z[1,4,0]  R980      1
    z[1,4,0]  R993      0.723736584186554
    z[1,4,0]  R994      8.0472415685653687e-01
    z[1,4,0]  R995      6.1697083711624146e-01
    z[1,4,0]  R996      6.5605306625366211e-01
    z[1,4,0]  R997      8.8712280988693237e-01
    z[1,4,0]  R998      8.8229048252105713e-01
    z[1,4,0]  R999      8.9311712980270386e-01
    z[1,4,0]  R1000     9.1823190450668335e-01
    z[1,4,0]  R1001     8.4810262918472290e-01
    z[1,4,0]  R1002     8.6877566576004028e-01
    z[1,4,0]  R1003     -2.4355600774288177e-01
    z[1,4,0]  R1004     -8.6646175384521484e-01
    z[1,4,0]  R1005     -1.7858077585697174e-01
    z[1,4,0]  R1006     -3.5714778304100037e-01
    z[1,4,0]  R1007     -7.5557577610015869e-01
    z[1,4,0]  R1008     -7.6985865831375122e-01
    z[1,4,0]  R1009     -7.5257080793380737e-01
    z[1,4,0]  R1010     -1.5396592207252979e-02
    z[1,4,0]  R1011     -1.4446650445461273e-01
    z[1,4,0]  R1012     8.9831940829753876e-02
    z[1,4,0]  R1013     -4.6918381005525589e-02
    z[1,4,0]  R1014     1.3612688519060612e-02
    z[1,4,0]  R1015     -7.2523248195648193e-01
    z[1,4,0]  R1016     -2.0390337333083153e-02
    z[1,4,0]  R1017     2.3649508133530617e-02
    z[1,4,0]  R1018     -7.7637803554534912e-01
    z[1,4,0]  R1019     -7.3027008771896362e-01
    z[1,4,0]  R1020     -7.8857392072677612e-01
    z[1,4,0]  R1021     0.0638904869556427
    z[1,4,0]  R1022     -0.730022668838501
    z[1,4,0]  R1023     3.2288023829460144e-01
    z[1,4,0]  R1024     1.6156212985515594e-01
    z[1,4,0]  R1025     2.2361817955970764e-01
    z[1,4,0]  R1026     -7.8468585014343262e-01
    z[1,4,0]  R1027     -7.9549568891525269e-01
    z[1,4,0]  R1028     -8.5130012035369873e-01
    z[1,4,0]  R1029     -0.858471155166626
    z[1,4,0]  R1030     -8.3502292633056641e-01
    z[1,4,0]  R1031     -8.7198764085769653e-01
    z[1,4,0]  R1032     -7.3678523302078247e-01
    z[1,4,0]  R1033     2.4792306125164032e-01
    z[1,4,0]  R1034     3.6198583245277405e-01
    z[1,4,0]  R1035     1.3135664165019989e-01
    z[1,4,0]  R1036     -8.4073919057846069e-01
    z[1,4,0]  R1037     -7.6478409767150879e-01
    z[1,4,0]  R1038     -7.9939109086990356e-01
    z[1,4,0]  R1039     -7.9929852485656738e-01
    z[1,4,0]  R1040     -7.9075801372528076e-01
    z[1,4,0]  R1041     -8.4291136264801025e-01
    z[1,4,0]  R1042     -4.1825491189956665e-01
    z[1,4,0]  R1043     1.5854188799858093e-01
    z[1,4,0]  R1044     -9.3071717023849487e-01
    z[1,4,0]  R1045     -4.7545678913593292e-02
    z[1,4,0]  R1046     -0.812671959400177
    z[1,4,0]  R1047     -7.1106845140457153e-01
    z[1,4,0]  R1048     -6.4418500661849976e-01
    z[1,4,0]  R1049     -8.2161104679107666e-01
    z[1,4,0]  R1050     -3.3492672443389893e-01
    z[1,4,0]  R1051     -7.1009427309036255e-01
    z[1,4,0]  R1052     -8.5085999965667725e-01
    z[1,4,0]  R1053     -8.4011381864547729e-01
    z[1,4,0]  R1054     -8.2892262935638428e-01
    z[1,4,0]  R1055     -6.6660982370376587e-01
    z[1,4,0]  R1056     -8.4759056568145752e-01
    z[1,4,0]  R1057     -7.2158157825469971e-01
    z[1,4,0]  R1058     -8.4859234094619751e-01
    z[1,4,0]  R1059     -3.8933184742927551e-01
    z[1,4,0]  R1060     -6.2131547927856445e-01
    z[1,4,0]  R1061     2.4689945578575134e-01
    z[1,4,0]  R1062     1.7999957501888275e-01
    z[1,4,0]  R1063     -8.6880499124526978e-01
    z[1,4,0]  R1064     -3.5068488121032715e-01
    z[1,4,0]  R1065     -7.1212485432624817e-02
    z[1,4,0]  R1066     -0.813671350479126
    z[1,4,0]  R1067     -8.9947231113910675e-02
    z[1,4,0]  R1068     2.4146883189678192e-01
    z[1,4,0]  R1069     -6.0453188419342041e-01
    z[1,4,0]  R1070     -1.4398542046546936e-01
    z[1,4,0]  R1071     -4.0792167186737061e-01
    z[1,4,0]  R1072     -2.6940107345581055e-01
    z[1,4,0]  R1073     -0.852932870388031
    z[1,4,0]  R1074     -3.3950966596603394e-01
    z[1,4,0]  R1075     -1.7837733030319214e-01
    z[1,4,0]  R1076     -1.7302061617374420e-01
    z[1,4,0]  R1077     -5.4825592041015625e-01
    z[1,4,0]  R1078     -1.2178809195756912e-01
    z[1,4,0]  R1079     2.0942500233650208e-01
    z[1,4,0]  R1080     -0.0467689111828804
    z[1,4,0]  R1081     2.5784561038017273e-01
    z[1,4,0]  R1082     1.8484315276145935e-01
    z[1,4,0]  R1083     -2.8594323992729187e-01
    z[1,4,0]  R1084     -7.4660068750381470e-01
    z[1,4,0]  R1085     -7.9481208324432373e-01
    z[1,4,0]  R1086     -1.2942856550216675e-01
    z[1,4,0]  R1087     -4.0330997109413147e-01
    z[1,4,0]  R1088     1.4957337081432343e-01
    z[1,4,0]  R1089     3.4764219075441360e-02
    z[1,4,0]  R1090     3.4324326552450657e-03
    z[1,4,0]  R1091     1.9561995286494493e-03
    z[1,4,0]  R1092     0.251740038394928
    z[1,4,0]  R1093     -5.7847633957862854e-02
    z[1,4,0]  R1094     2.3291967809200287e-01
    z[1,4,0]  R1095     1.9032852351665497e-01
    z[1,4,0]  R1096     1.0687439143657684e-01
    z[1,4,0]  R1097     1.2337212264537811e-01
    z[1,4,0]  R1098     -1.5379829704761505e-01
    z[1,4,0]  R1099     0.612011730670929
    z[1,4,0]  R1100     -2.5405046343803406e-01
    z[1,4,0]  R1101     -1.7137020826339722e-01
    z[1,4,0]  R1102     5.9136056900024414e-01
    z[1,4,0]  R1103     -3.8787201046943665e-01
    z[1,4,0]  R1104     -1.7020131647586823e-01
    z[1,4,0]  R1105     -1.3619169592857361e-01
    z[1,4,0]  R1106     4.5985409617424011e-01
    z[1,4,0]  R1107     1.5315456688404083e-01
    z[1,4,0]  R1108     3.9971357583999634e-01
    z[1,4,0]  R1109     3.3082881569862366e-01
    z[1,4,0]  R1110     -1.5886427462100983e-01
    z[1,4,0]  R1111     2.4377131462097168e-01
    z[1,4,0]  R1112     -9.3194320797920227e-02
    z[1,4,0]  R1113     -1.2749305367469788e-01
    z[1,4,0]  R1114     -3.3869582414627075e-01
    z[1,4,0]  R1115     -3.0979645252227783e-01
    z[1,4,0]  R1116     4.6450782567262650e-02
    z[1,4,0]  R1117     -5.0778716802597046e-01
    z[1,4,0]  R1118     -4.2351409792900085e-01
    z[1,4,0]  R1119     -2.8360605239868164e-01
    z[1,4,0]  R1120     5.3043287992477417e-01
    z[1,4,0]  R1121     5.4679775238037109e-01
    z[1,4,0]  R1122     4.1538336873054504e-01
    z[1,4,0]  R1123     -3.4991261363029480e-01
    z[1,4,0]  R1124     -6.5750330686569214e-02
    z[1,4,0]  R1125     6.4677906036376953e-01
    z[1,4,0]  R1126     2.2338490188121796e-01
    z[1,4,0]  R1127     2.0899084210395813e-01
    z[1,4,0]  R1128     5.5733382701873779e-01
    z[1,4,0]  R1129     8.4454685449600220e-01
    z[1,4,0]  R1130     3.7446701526641846e-01
    z[1,4,0]  R1131     7.4645286798477173e-01
    z[1,4,0]  R1132     4.8767754435539246e-01
    z[1,4,0]  R1133     3.3604595810174942e-02
    z[1,4,0]  R1134     5.7812124490737915e-01
    z[1,4,0]  R1135     8.7086832523345947e-01
    z[1,4,0]  R1136     -2.4377760291099548e-01
    z[1,4,0]  R1137     5.2036845684051514e-01
    z[1,4,0]  R1138     6.8450921773910522e-01
    z[1,4,0]  R1139     -1.7482032999396324e-03
    z[1,4,0]  R1140     4.1061496734619141e-01
    z[1,4,0]  R1141     -8.1347328424453735e-01
    z[1,4,0]  R1142     -7.9426652193069458e-01
    z[1,4,0]  R1143     -1.0821318626403809e-01
    z[1,4,0]  R1144     -6.9208703935146332e-02
    z[1,4,0]  R1145     -3.2698172330856323e-01
    z[1,4,0]  R1146     -0.609432578086853
    z[1,4,0]  R1147     -6.8806296586990356e-01
    z[1,4,0]  R1148     -8.0902999639511108e-01
    z[1,4,0]  R1149     -4.1726133227348328e-01
    z[1,4,0]  R1150     -3.1601142883300781e-01
    z[1,4,0]  R1151     -0.582899808883667
    z[1,4,1]  R12       -1
    z[1,4,1]  R39       1
    z[1,4,1]  R981      -1
    z[1,4,1]  R982      1
    z[1,4,1]  R993      -3.3563992381095886e-01
    z[1,4,1]  R994      -2.8114026784896851e-01
    z[1,4,1]  R995      -2.0235392451286316e-01
    z[1,4,1]  R996      -3.9763000607490540e-01
    z[1,4,1]  R997      -1.9126047194004059e-01
    z[1,4,1]  R998      -3.2268315553665161e-01
    z[1,4,1]  R999      -1.1038208752870560e-01
    z[1,4,1]  R1000     -1.0242065042257309e-01
    z[1,4,1]  R1001     -3.7171953916549683e-01
    z[1,4,1]  R1002     -2.7798095345497131e-01
    z[1,4,1]  R1003     -7.3880583047866821e-01
    z[1,4,1]  R1004     2.8852856159210205e-01
    z[1,4,1]  R1005     -6.9745475053787231e-01
    z[1,4,1]  R1006     -6.7659026384353638e-01
    z[1,4,1]  R1007     1.5621243417263031e-01
    z[1,4,1]  R1008     1.3875234127044678e-01
    z[1,4,1]  R1009     7.7380046248435974e-02
    z[1,4,1]  R1010     -2.4864664673805237e-01
    z[1,4,1]  R1011     -7.1995544433593750e-01
    z[1,4,1]  R1012     4.3988442420959473e-01
    z[1,4,1]  R1013     -8.7624388933181763e-01
    z[1,4,1]  R1014     -2.5671776384115219e-02
    z[1,4,1]  R1015     3.5382679104804993e-01
    z[1,4,1]  R1016     -1.6947848722338676e-02
    z[1,4,1]  R1017     -2.8374776244163513e-01
    z[1,4,1]  R1018     2.6474717259407043e-01
    z[1,4,1]  R1019     3.5049974918365479e-01
    z[1,4,1]  R1020     8.2094341516494751e-02
    z[1,4,1]  R1021     5.8240371942520142e-01
    z[1,4,1]  R1022     2.2649440169334412e-01
    z[1,4,1]  R1023     -1.4183451235294342e-01
    z[1,4,1]  R1024     -1.4633235335350037e-01
    z[1,4,1]  R1025     -2.8569728136062622e-01
    z[1,4,1]  R1026     3.9122492074966431e-01
    z[1,4,1]  R1027     4.2709720134735107e-01
    z[1,4,1]  R1028     2.0969817042350769e-01
    z[1,4,1]  R1029     1.8353113532066345e-01
    z[1,4,1]  R1030     4.3121472001075745e-01
    z[1,4,1]  R1031     4.7087732702493668e-02
    z[1,4,1]  R1032     3.2928496599197388e-01
    z[1,4,1]  R1033     -4.2966210842132568e-01
    z[1,4,1]  R1034     1.4785882830619812e-01
    z[1,4,1]  R1035     5.3121572732925415e-01
    z[1,4,1]  R1036     3.4137284755706787e-01
    z[1,4,1]  R1037     2.1490712463855743e-01
    z[1,4,1]  R1038     1.4756475389003754e-01
    z[1,4,1]  R1039     -4.8007094860076904e-01
    z[1,4,1]  R1040     -4.7991201281547546e-01
    z[1,4,1]  R1041     -3.9515095949172974e-01
    z[1,4,1]  R1042     -6.2988650798797607e-01
    z[1,4,1]  R1043     4.1771256923675537e-01
    z[1,4,1]  R1044     1.5441577136516571e-01
    z[1,4,1]  R1045     -3.9207491278648376e-01
    z[1,4,1]  R1046     1.6048018634319305e-01
    z[1,4,1]  R1047     3.0565094947814941e-01
    z[1,4,1]  R1048     3.3529585599899292e-01
    z[1,4,1]  R1049     -4.1966083645820618e-01
    z[1,4,1]  R1050     -2.7800619602203369e-01
    z[1,4,1]  R1051     6.7779272794723511e-02
    z[1,4,1]  R1052     -3.1335547566413879e-01
    z[1,4,1]  R1053     4.0297958254814148e-01
    z[1,4,1]  R1054     1.9702941179275513e-01
    z[1,4,1]  R1055     4.1896373033523560e-01
    z[1,4,1]  R1056     -4.1293808817863464e-01
    z[1,4,1]  R1057     -5.4255348443984985e-01
    z[1,4,1]  R1058     -3.4744662046432495e-01
    z[1,4,1]  R1059     1.5410919487476349e-01
    z[1,4,1]  R1060     -5.8917975425720215e-01
    z[1,4,1]  R1061     9.3907696008682251e-01
    z[1,4,1]  R1062     9.6039682626724243e-01
    z[1,4,1]  R1063     1.8808189034461975e-01
    z[1,4,1]  R1064     -3.5703826695680618e-02
    z[1,4,1]  R1065     -2.1576354280114174e-02
    z[1,4,1]  R1066     5.2840482443571091e-02
    z[1,4,1]  R1067     -0.669160008430481
    z[1,4,1]  R1068     8.5001587867736816e-01
    z[1,4,1]  R1069     -4.2836752533912659e-01
    z[1,4,1]  R1070     5.4281461238861084e-01
    z[1,4,1]  R1071     -4.0056610107421875e-01
    z[1,4,1]  R1072     -5.1552116870880127e-01
    z[1,4,1]  R1073     2.4238830804824829e-01
    z[1,4,1]  R1074     -1.0183142125606537e-01
    z[1,4,1]  R1075     -5.1572978496551514e-01
    z[1,4,1]  R1076     -7.6958012580871582e-01
    z[1,4,1]  R1077     -2.7142700552940369e-01
    z[1,4,1]  R1078     8.2527321577072144e-01
    z[1,4,1]  R1079     8.8517922163009644e-01
    z[1,4,1]  R1080     7.2231113910675049e-01
    z[1,4,1]  R1081     0.835231363773346
    z[1,4,1]  R1082     8.3807313442230225e-01
    z[1,4,1]  R1083     -5.3620919585227966e-02
    z[1,4,1]  R1084     2.3409350216388702e-01
    z[1,4,1]  R1085     3.8337996602058411e-01
    z[1,4,1]  R1086     -8.3246874809265137e-01
    z[1,4,1]  R1087     -3.3632597327232361e-01
    z[1,4,1]  R1088     0.822594165802002
    z[1,4,1]  R1089     7.3138356208801270e-01
    z[1,4,1]  R1090     7.8624749183654785e-01
    z[1,4,1]  R1091     7.7497494220733643e-01
    z[1,4,1]  R1092     7.3773950338363647e-01
    z[1,4,1]  R1093     -2.2434207797050476e-01
    z[1,4,1]  R1094     -4.1379917412996292e-02
    z[1,4,1]  R1095     -4.6656742691993713e-02
    z[1,4,1]  R1096     -1.2432451546192169e-01
    z[1,4,1]  R1097     -7.1573257446289062e-02
    z[1,4,1]  R1098     5.6521035730838776e-02
    z[1,4,1]  R1099     -3.6553180217742920e-01
    z[1,4,1]  R1100     -8.5622303187847137e-02
    z[1,4,1]  R1101     0.0456363670527935
    z[1,4,1]  R1102     -2.4456253647804260e-01
    z[1,4,1]  R1103     8.4129935503005981e-01
    z[1,4,1]  R1104     8.6757284402847290e-01
    z[1,4,1]  R1105     8.4425538778305054e-01
    z[1,4,1]  R1106     -4.5689931511878967e-01
    z[1,4,1]  R1107     -7.9187095165252686e-01
    z[1,4,1]  R1108     2.4552106857299805e-01
    z[1,4,1]  R1109     -9.0515814721584320e-02
    z[1,4,1]  R1110     -3.9412230253219604e-01
    z[1,4,1]  R1111     -6.0985791683197021e-01
    z[1,4,1]  R1112     -6.7751926183700562e-01
    z[1,4,1]  R1113     -6.6503608226776123e-01
    z[1,4,1]  R1114     -7.6249647140502930e-01
    z[1,4,1]  R1115     -6.5101730823516846e-01
    z[1,4,1]  R1116     -7.9949998855590820e-01
    z[1,4,1]  R1117     -5.5410587787628174e-01
    z[1,4,1]  R1118     -0.576320469379425
    z[1,4,1]  R1119     -7.7463120222091675e-01
    z[1,4,1]  R1120     2.1554206311702728e-01
    z[1,4,1]  R1121     -0.500268816947937
    z[1,4,1]  R1122     -6.4946311712265015e-01
    z[1,4,1]  R1123     -3.6966410279273987e-01
    z[1,4,1]  R1124     -5.5434852838516235e-01
    z[1,4,1]  R1125     -5.8023804426193237e-01
    z[1,4,1]  R1126     1.1254636943340302e-01
    z[1,4,1]  R1127     1.1817237734794617e-01
    z[1,4,1]  R1128     -2.1881256997585297e-01
    z[1,4,1]  R1129     -8.0024182796478271e-02
    z[1,4,1]  R1130     -2.2036722302436829e-01
    z[1,4,1]  R1131     3.2096442580223083e-01
    z[1,4,1]  R1132     -7.2960913181304932e-01
    z[1,4,1]  R1133     -7.2324448823928833e-01
    z[1,4,1]  R1134     -5.4733687639236450e-01
    z[1,4,1]  R1135     -2.4741439521312714e-01
    z[1,4,1]  R1136     -4.4586917757987976e-01
    z[1,4,1]  R1137     -5.3672641515731812e-01
    z[1,4,1]  R1138     -2.4713842570781708e-01
    z[1,4,1]  R1139     -8.9190351963043213e-01
    z[1,4,1]  R1140     3.3194816112518311e-01
    z[1,4,1]  R1141     3.5491049289703369e-01
    z[1,4,1]  R1142     0.244643896818161
    z[1,4,1]  R1143     -3.2988885045051575e-01
    z[1,4,1]  R1144     -6.9191831350326538e-01
    z[1,4,1]  R1145     -8.0293434858322144e-01
    z[1,4,1]  R1146     -5.7155334949493408e-01
    z[1,4,1]  R1147     -4.9672827124595642e-01
    z[1,4,1]  R1148     -2.3610962927341461e-01
    z[1,4,1]  R1149     1.0668906569480896e-01
    z[1,4,1]  R1150     1.1416645348072052e-01
    z[1,4,1]  R1151     2.0661045610904694e-01
    z[1,4,2]  R13       -1
    z[1,4,2]  R40       1
    z[1,4,2]  R983      -1
    z[1,4,2]  R984      1
    z[1,4,2]  R993      -1.1853816360235214e-01
    z[1,4,2]  R994      -1.3509753160178661e-02
    z[1,4,2]  R995      -5.8933593332767487e-02
    z[1,4,2]  R996      -5.3258843719959259e-02
    z[1,4,2]  R997      7.5866342522203922e-03
    z[1,4,2]  R998      6.0134965926408768e-02
    z[1,4,2]  R999      2.9740616679191589e-01
    z[1,4,2]  R1000     2.6105591654777527e-01
    z[1,4,2]  R1001     -2.3807699978351593e-01
    z[1,4,2]  R1002     2.2151088714599609e-01
    z[1,4,2]  R1003     -1.4257369935512543e-01
    z[1,4,2]  R1004     2.1280555427074432e-01
    z[1,4,2]  R1005     -5.3871236741542816e-02
    z[1,4,2]  R1006     -0.158564493060112
    z[1,4,2]  R1007     -7.0406176149845123e-02
    z[1,4,2]  R1008     -1.9678844138979912e-02
    z[1,4,2]  R1009     -2.5658485293388367e-01
    z[1,4,2]  R1010     -3.8320258259773254e-01
    z[1,4,2]  R1011     1.7249508202075958e-01
    z[1,4,2]  R1012     4.3248921632766724e-01
    z[1,4,2]  R1013     -1.2811531126499176e-01
    z[1,4,2]  R1014     1.4191722869873047e-01
    z[1,4,2]  R1015     -1.0315258055925369e-01
    z[1,4,2]  R1016     5.7939875125885010e-01
    z[1,4,2]  R1017     4.5659548044204712e-01
    z[1,4,2]  R1018     -2.1855439245700836e-01
    z[1,4,2]  R1019     -2.0133875310420990e-01
    z[1,4,2]  R1020     1.3484379276633263e-02
    z[1,4,2]  R1021     2.1422983705997467e-01
    z[1,4,2]  R1022     2.9233434796333313e-01
    z[1,4,2]  R1023     3.5992351174354553e-01
    z[1,4,2]  R1024     -0.679987370967865
    z[1,4,2]  R1025     -2.2934034466743469e-01
    z[1,4,2]  R1026     -0.0109430942684412
    z[1,4,2]  R1027     -1.5799516439437866e-01
    z[1,4,2]  R1028     1.1394404806196690e-02
    z[1,4,2]  R1029     -2.3620298597961664e-03
    z[1,4,2]  R1030     1.6179924830794334e-02
    z[1,4,2]  R1031     -0.0656462013721466
    z[1,4,2]  R1032     3.4418323636054993e-01
    z[1,4,2]  R1033     3.0129194259643555e-01
    z[1,4,2]  R1034     2.8884598612785339e-01
    z[1,4,2]  R1035     1.9122385978698730e-01
    z[1,4,2]  R1036     -2.9208555817604065e-01
    z[1,4,2]  R1037     -2.2691851854324341e-01
    z[1,4,2]  R1038     6.4044152386486530e-03
    z[1,4,2]  R1039     2.0478211343288422e-01
    z[1,4,2]  R1040     1.4265184104442596e-01
    z[1,4,2]  R1041     2.4560482800006866e-01
    z[1,4,2]  R1042     -2.2371813654899597e-01
    z[1,4,2]  R1043     6.0382062196731567e-01
    z[1,4,2]  R1044     0.0838552713394165
    z[1,4,2]  R1045     -3.8139653205871582e-01
    z[1,4,2]  R1046     3.2950885593891144e-02
    z[1,4,2]  R1047     -7.8959226608276367e-02
    z[1,4,2]  R1048     1.7590709030628204e-01
    z[1,4,2]  R1049     -2.7172014117240906e-01
    z[1,4,2]  R1050     -1.8509723246097565e-01
    z[1,4,2]  R1051     3.8466113805770874e-01
    z[1,4,2]  R1052     -1.3332429528236389e-01
    z[1,4,2]  R1053     3.1154736876487732e-01
    z[1,4,2]  R1054     1.9985429942607880e-02
    z[1,4,2]  R1055     2.8842157125473022e-01
    z[1,4,2]  R1056     -4.1602656245231628e-02
    z[1,4,2]  R1057     -1.7169304192066193e-02
    z[1,4,2]  R1058     -1.9052948057651520e-01
    z[1,4,2]  R1059     -2.5256642699241638e-01
    z[1,4,2]  R1060     7.0102256722748280e-03
    z[1,4,2]  R1061     -1.6414555907249451e-01
    z[1,4,2]  R1062     -3.6084707826375961e-02
    z[1,4,2]  R1063     -5.1217749714851379e-02
    z[1,4,2]  R1064     -5.1917475461959839e-01
    z[1,4,2]  R1065     -5.8295524120330811e-01
    z[1,4,2]  R1066     1.7868605256080627e-01
    z[1,4,2]  R1067     3.4137687087059021e-01
    z[1,4,2]  R1068     -3.3170655369758606e-01
    z[1,4,2]  R1069     1.3348698616027832e-01
    z[1,4,2]  R1070     -5.5416148900985718e-01
    z[1,4,2]  R1071     3.6347416043281555e-01
    z[1,4,2]  R1072     -4.5652204751968384e-01
    z[1,4,2]  R1073     -7.0415951311588287e-02
    z[1,4,2]  R1074     -4.7058498859405518e-01
    z[1,4,2]  R1075     -3.4134802222251892e-01
    z[1,4,2]  R1076     -1.0316787520423532e-03
    z[1,4,2]  R1077     6.6267979145050049e-01
    z[1,4,2]  R1078     -1.2245739996433258e-01
    z[1,4,2]  R1079     3.1064450740814209e-03
    z[1,4,2]  R1080     -1.9768038392066956e-01
    z[1,4,2]  R1081     -2.6481890678405762e-01
    z[1,4,2]  R1082     -1.8159645795822144e-01
    z[1,4,2]  R1083     -4.6260491013526917e-01
    z[1,4,2]  R1084     -1.7056234180927277e-01
    z[1,4,2]  R1085     -2.9695001244544983e-01
    z[1,4,2]  R1086     3.5705637186765671e-02
    z[1,4,2]  R1087     5.0237149000167847e-01
    z[1,4,2]  R1088     -6.4319007098674774e-02
    z[1,4,2]  R1089     1.2722036242485046e-01
    z[1,4,2]  R1090     -7.0435716770589352e-03
    z[1,4,2]  R1091     -9.3880154192447662e-02
    z[1,4,2]  R1092     1.7199160158634186e-01
    z[1,4,2]  R1093     -5.9244537353515625e-01
    z[1,4,2]  R1094     -8.2150202989578247e-01
    z[1,4,2]  R1095     -5.4357331991195679e-01
    z[1,4,2]  R1096     -3.1353580951690674e-01
    z[1,4,2]  R1097     -7.3006719350814819e-01
    z[1,4,2]  R1098     -7.2983759641647339e-01
    z[1,4,2]  R1099     -2.6255834102630615e-01
    z[1,4,2]  R1100     -2.2652576863765717e-01
    z[1,4,2]  R1101     -6.6095048189163208e-01
    z[1,4,2]  R1102     -6.0441619157791138e-01
    z[1,4,2]  R1103     1.1838949285447598e-02
    z[1,4,2]  R1104     -8.1899136304855347e-02
    z[1,4,2]  R1105     -4.5951315760612488e-01
    z[1,4,2]  R1106     6.1652439832687378e-01
    z[1,4,2]  R1107     2.8402274474501610e-02
    z[1,4,2]  R1108     2.7462553977966309e-01
    z[1,4,2]  R1109     4.0592372417449951e-01
    z[1,4,2]  R1110     2.7861317619681358e-02
    z[1,4,2]  R1111     2.7157512307167053e-01
    z[1,4,2]  R1112     1.4036209881305695e-01
    z[1,4,2]  R1113     -1.9590763747692108e-01
    z[1,4,2]  R1114     -2.3073473572731018e-01
    z[1,4,2]  R1115     -3.0537730455398560e-01
    z[1,4,2]  R1116     2.0183049142360687e-01
    z[1,4,2]  R1117     -2.9556852579116821e-01
    z[1,4,2]  R1118     -4.0751591324806213e-01
    z[1,4,2]  R1119     -1.1781888455152512e-01
    z[1,4,2]  R1120     -6.2708705663681030e-02
    z[1,4,2]  R1121     -7.0346496999263763e-02
    z[1,4,2]  R1122     3.0369493365287781e-01
    z[1,4,2]  R1123     -2.3955148458480835e-01
    z[1,4,2]  R1124     -5.7545232772827148e-01
    z[1,4,2]  R1125     9.1637238860130310e-02
    z[1,4,2]  R1126     -5.8281220495700836e-02
    z[1,4,2]  R1127     -2.0295043289661407e-01
    z[1,4,2]  R1128     -1.2939724326133728e-01
    z[1,4,2]  R1129     5.9550367295742035e-02
    z[1,4,2]  R1130     -2.1915417909622192e-01
    z[1,4,2]  R1131     -5.4754824377596378e-03
    z[1,4,2]  R1132     2.2998669743537903e-01
    z[1,4,2]  R1133     -3.3640664815902710e-01
    z[1,4,2]  R1134     -2.1699997782707214e-01
    z[1,4,2]  R1135     1.5533640980720520e-01
    z[1,4,2]  R1136     -6.7132425308227539e-01
    z[1,4,2]  R1137     -0.544070839881897
    z[1,4,2]  R1138     1.1546090245246887e-01
    z[1,4,2]  R1139     2.4799892306327820e-01
    z[1,4,2]  R1140     -2.8383618593215942e-01
    z[1,4,2]  R1141     7.4420824646949768e-02
    z[1,4,2]  R1142     4.0437978506088257e-01
    z[1,4,2]  R1143     5.6865561753511429e-02
    z[1,4,2]  R1144     -4.4046363234519958e-01
    z[1,4,2]  R1145     2.0109033584594727e-01
    z[1,4,2]  R1146     -1.4814113080501556e-01
    z[1,4,2]  R1147     -2.4655283987522125e-01
    z[1,4,2]  R1148     -4.0472263097763062e-01
    z[1,4,2]  R1149     7.9461358487606049e-02
    z[1,4,2]  R1150     3.3187928795814514e-01
    z[1,4,2]  R1151     3.6535346508026123e-01
    z[1,4,3]  R14       -1
    z[1,4,3]  R41       1
    z[1,4,3]  R985      -1
    z[1,4,3]  R986      1
    z[1,4,3]  R993      3.7642562389373779e-01
    z[1,4,3]  R994      2.2613757848739624e-01
    z[1,4,3]  R995      2.8243386745452881e-01
    z[1,4,3]  R996      0.0550660714507103
    z[1,4,3]  R997      -3.1871774792671204e-01
    z[1,4,3]  R998      0.0724758729338646
    z[1,4,3]  R999      -0.0727483481168747
    z[1,4,3]  R1000     -1.5462476760149002e-02
    z[1,4,3]  R1001     -2.2073060274124146e-01
    z[1,4,3]  R1002     6.2123283743858337e-02
    z[1,4,3]  R1003     -0.424940824508667
    z[1,4,3]  R1004     -1.5746068954467773e-01
    z[1,4,3]  R1005     -4.0981835126876831e-01
    z[1,4,3]  R1006     -4.5490843057632446e-01
    z[1,4,3]  R1007     2.8890269994735718e-01
    z[1,4,3]  R1008     -3.9071059226989746e-01
    z[1,4,3]  R1009     -0.346769779920578
    z[1,4,3]  R1010     3.4356537461280823e-01
    z[1,4,3]  R1011     2.8785686939954758e-02
    z[1,4,3]  R1012     -4.6313452720642090e-01
    z[1,4,3]  R1013     -3.9203029870986938e-01
    z[1,4,3]  R1014     -6.5651428699493408e-01
    z[1,4,3]  R1015     -2.4493958055973053e-01
    z[1,4,3]  R1016     -5.6359034776687622e-01
    z[1,4,3]  R1017     -4.9433851242065430e-01
    z[1,4,3]  R1018     2.3379026353359222e-01
    z[1,4,3]  R1019     3.6727815866470337e-01
    z[1,4,3]  R1020     3.2355868816375732e-01
    z[1,4,3]  R1021     -5.8226162195205688e-01
    z[1,4,3]  R1022     -4.4555738568305969e-01
    z[1,4,3]  R1023     -0.281028687953949
    z[1,4,3]  R1024     1.4870950579643250e-01
    z[1,4,3]  R1025     -0.0558922179043293
    z[1,4,3]  R1026     1.5222573280334473e-01
    z[1,4,3]  R1027     -1.1127392202615738e-01
    z[1,4,3]  R1028     2.6698562502861023e-01
    z[1,4,3]  R1029     0.0815851241350174
    z[1,4,3]  R1030     2.0858474075794220e-01
    z[1,4,3]  R1031     2.5546187162399292e-01
    z[1,4,3]  R1032     2.7224791049957275e-01
    z[1,4,3]  R1033     -5.8066624402999878e-01
    z[1,4,3]  R1034     -2.1184456348419189e-01
    z[1,4,3]  R1035     -7.1251779794692993e-01
    z[1,4,3]  R1036     -0.0191778764128685
    z[1,4,3]  R1037     -3.0335992574691772e-01
    z[1,4,3]  R1038     2.6501855254173279e-01
    z[1,4,3]  R1039     6.0697649605572224e-03
    z[1,4,3]  R1040     1.4614929258823395e-01
    z[1,4,3]  R1041     -2.5967705994844437e-02
    z[1,4,3]  R1042     -3.8211518526077271e-01
    z[1,4,3]  R1043     -5.6091696023941040e-01
    z[1,4,3]  R1044     -9.1272346675395966e-02
    z[1,4,3]  R1045     3.3846864104270935e-01
    z[1,4,3]  R1046     3.7194166332483292e-02
    z[1,4,3]  R1047     4.0260624140501022e-02
    z[1,4,3]  R1048     -2.9305824637413025e-01
    z[1,4,3]  R1049     0.207631453871727
    z[1,4,3]  R1050     6.7774903774261475e-01
    z[1,4,3]  R1051     -6.9623276591300964e-02
    z[1,4,3]  R1052     -2.0771314203739166e-01
    z[1,4,3]  R1053     -0.00696546770632267
    z[1,4,3]  R1054     7.0355825126171112e-02
    z[1,4,3]  R1055     4.4429653882980347e-01
    z[1,4,3]  R1056     7.4754811823368073e-02
    z[1,4,3]  R1057     1.6481418907642365e-01
    z[1,4,3]  R1058     -2.6582974195480347e-01
    z[1,4,3]  R1059     8.2485699653625488e-01
    z[1,4,3]  R1060     5.0227355957031250e-01
    z[1,4,3]  R1061     1.0876694321632385e-01
    z[1,4,3]  R1062     1.2753970222547650e-03
    z[1,4,3]  R1063     8.4732629358768463e-02
    z[1,4,3]  R1064     6.2167018651962280e-01
    z[1,4,3]  R1065     5.9127581119537354e-01
    z[1,4,3]  R1066     -3.6739131808280945e-01
    z[1,4,3]  R1067     2.9516467452049255e-01
    z[1,4,3]  R1068     -1.0469325631856918e-01
    z[1,4,3]  R1069     -1.3179023563861847e-01
    z[1,4,3]  R1070     -4.7945481538772583e-01
    z[1,4,3]  R1071     5.8445721864700317e-01
    z[1,4,3]  R1072     4.0771072963252664e-04
    z[1,4,3]  R1073     0.0796792060136795
    z[1,4,3]  R1074     5.8450758457183838e-01
    z[1,4,3]  R1075     -6.9646090269088745e-01
    z[1,4,3]  R1076     3.2750996947288513e-01
    z[1,4,3]  R1077     4.2184704542160034e-01
    z[1,4,3]  R1078     -3.8457545638084412e-01
    z[1,4,3]  R1079     -3.3123109489679337e-02
    z[1,4,3]  R1080     -1.1977288126945496e-01
    z[1,4,3]  R1081     -2.5463856291025877e-03
    z[1,4,3]  R1082     2.8450268507003784e-01
    z[1,4,3]  R1083     5.8854973316192627e-01
    z[1,4,3]  R1084     -5.7986426353454590e-01
    z[1,4,3]  R1085     -2.5151500478386879e-02
    z[1,4,3]  R1086     3.2991883158683777e-01
    z[1,4,3]  R1087     6.6927188634872437e-01
    z[1,4,3]  R1088     2.9772832989692688e-01
    z[1,4,3]  R1089     6.1433595418930054e-01
    z[1,4,3]  R1090     4.2071422934532166e-01
    z[1,4,3]  R1091     -1.9240427762269974e-02
    z[1,4,3]  R1092     0.529548168182373
    z[1,4,3]  R1093     2.3699685931205750e-01
    z[1,4,3]  R1094     1.1154517531394958e-01
    z[1,4,3]  R1095     -8.6395636200904846e-02
    z[1,4,3]  R1096     1.1555530875921249e-01
    z[1,4,3]  R1097     1.3171684741973877e-01
    z[1,4,3]  R1098     3.5918179154396057e-01
    z[1,4,3]  R1099     -5.3258669376373291e-01
    z[1,4,3]  R1100     4.1792401671409607e-01
    z[1,4,3]  R1101     -9.7393877804279327e-02
    z[1,4,3]  R1102     -2.8344443440437317e-01
    z[1,4,3]  R1103     -0.271945595741272
    z[1,4,3]  R1104     -1.5372280776500702e-01
    z[1,4,3]  R1105     -1.1726742237806320e-01
    z[1,4,3]  R1106     1.5897387266159058e-01
    z[1,4,3]  R1107     5.3039681911468506e-01
    z[1,4,3]  R1108     4.7791481018066406e-01
    z[1,4,3]  R1109     4.5172640681266785e-01
    z[1,4,3]  R1110     6.5011823177337646e-01
    z[1,4,3]  R1111     6.2212830781936646e-01
    z[1,4,3]  R1112     -1.4795914292335510e-01
    z[1,4,3]  R1113     6.3086384534835815e-01
    z[1,4,3]  R1114     -2.1271225810050964e-01
    z[1,4,3]  R1115     1.8182241916656494e-01
    z[1,4,3]  R1116     4.9371698498725891e-01
    z[1,4,3]  R1117     2.0419631898403168e-01
    z[1,4,3]  R1118     -2.2921408712863922e-01
    z[1,4,3]  R1119     -2.2812442481517792e-01
    z[1,4,3]  R1120     -0.72444748878479
    z[1,4,3]  R1121     3.3810603618621826e-01
    z[1,4,3]  R1122     1.8640232086181641e-01
    z[1,4,3]  R1123     -4.8062512278556824e-01
    z[1,4,3]  R1124     -0.483710378408432
    z[1,4,3]  R1125     5.6191053241491318e-02
    z[1,4,3]  R1126     -3.6831229925155640e-01
    z[1,4,3]  R1127     1.6339768469333649e-01
    z[1,4,3]  R1128     1.0380907356739044e-01
    z[1,4,3]  R1129     1.1003208905458450e-01
    z[1,4,3]  R1130     6.5903908014297485e-01
    z[1,4,3]  R1131     -3.2897201180458069e-01
    z[1,4,3]  R1132     -1.5643297135829926e-01
    z[1,4,3]  R1133     3.9144212007522583e-01
    z[1,4,3]  R1134     -0.00906385201960802
    z[1,4,3]  R1135     -4.2518965899944305e-02
    z[1,4,3]  R1136     -4.3219098448753357e-01
    z[1,4,3]  R1137     2.7163645625114441e-01
    z[1,4,3]  R1138     2.2988820075988770e-01
    z[1,4,3]  R1139     -6.2464926391839981e-02
    z[1,4,3]  R1140     3.9827436208724976e-01
    z[1,4,3]  R1141     3.6196565628051758e-01
    z[1,4,3]  R1142     3.5333672165870667e-01
    z[1,4,3]  R1143     -2.4791575968265533e-01
    z[1,4,3]  R1144     -1.5276212990283966e-01
    z[1,4,3]  R1145     3.0615553259849548e-01
    z[1,4,3]  R1146     2.4574624840170145e-03
    z[1,4,3]  R1147     1.8979637324810028e-01
    z[1,4,3]  R1148     -1.6697503626346588e-01
    z[1,4,3]  R1149     -0.798019289970398
    z[1,4,3]  R1150     -8.2056099176406860e-01
    z[1,4,3]  R1151     4.1949599981307983e-01
    z[1,4,4]  R15       -1
    z[1,4,4]  R42       1
    z[1,4,4]  R987      -1
    z[1,4,4]  R988      1
    z[1,4,4]  R993      4.2370632290840149e-01
    z[1,4,4]  R994      1.8065446987748146e-02
    z[1,4,4]  R995      3.6739388108253479e-01
    z[1,4,4]  R996      5.8633655309677124e-01
    z[1,4,4]  R997      1.6537471115589142e-01
    z[1,4,4]  R998      1.6097468137741089e-01
    z[1,4,4]  R999      1.7848816514015198e-01
    z[1,4,4]  R1000     2.6838836073875427e-01
    z[1,4,4]  R1001     1.1645889282226562e-01
    z[1,4,4]  R1002     2.9949453473091125e-01
    z[1,4,4]  R1003     -1.5863038599491119e-01
    z[1,4,4]  R1004     -2.0651364326477051e-01
    z[1,4,4]  R1005     -3.7758240103721619e-01
    z[1,4,4]  R1006     -8.3849288523197174e-02
    z[1,4,4]  R1007     -5.0751942396163940e-01
    z[1,4,4]  R1008     -9.4126991927623749e-02
    z[1,4,4]  R1009     1.0345663875341415e-01
    z[1,4,4]  R1010     -7.7445471286773682e-01
    z[1,4,4]  R1011     -4.0884593129158020e-01
    z[1,4,4]  R1012     -5.5066245794296265e-01
    z[1,4,4]  R1013     -1.9226944446563721e-01
    z[1,4,4]  R1014     2.1234290301799774e-01
    z[1,4,4]  R1015     -2.9462394118309021e-01
    z[1,4,4]  R1016     -4.5862805843353271e-01
    z[1,4,4]  R1017     -2.9427188634872437e-01
    z[1,4,4]  R1018     0.473821222782135
    z[1,4,4]  R1019     1.7656306922435760e-01
    z[1,4,4]  R1020     0.512280285358429
    z[1,4,4]  R1021     1.8443444371223450e-01
    z[1,4,4]  R1022     6.3173137605190277e-02
    z[1,4,4]  R1023     -5.9691351652145386e-01
    z[1,4,4]  R1024     -5.0122201442718506e-01
    z[1,4,4]  R1025     -8.1298923492431641e-01
    z[1,4,4]  R1026     4.1157731413841248e-01
    z[1,4,4]  R1027     0.13089619576931
    z[1,4,4]  R1028     1.8609413504600525e-01
    z[1,4,4]  R1029     1.9791173934936523e-01
    z[1,4,4]  R1030     -2.6141893118619919e-02
    z[1,4,4]  R1031     7.1282177232205868e-03
    z[1,4,4]  R1032     -5.2257917821407318e-02
    z[1,4,4]  R1033     -3.5380131006240845e-01
    z[1,4,4]  R1034     -6.8181025981903076e-01
    z[1,4,4]  R1035     -3.4506028890609741e-01
    z[1,4,4]  R1036     -1.3816542923450470e-01
    z[1,4,4]  R1037     3.3916497230529785e-01
    z[1,4,4]  R1038     -7.2195746004581451e-02
    z[1,4,4]  R1039     9.0210400521755219e-02
    z[1,4,4]  R1040     -2.2630941867828369e-01
    z[1,4,4]  R1041     -1.1395063996315002e-01
    z[1,4,4]  R1042     2.5320026278495789e-01
    z[1,4,4]  R1043     -2.6496413350105286e-01
    z[1,4,4]  R1044     1.2268720567226410e-01
    z[1,4,4]  R1045     -0.516111433506012
    z[1,4,4]  R1046     -7.7362522482872009e-02
    z[1,4,4]  R1047     3.6041066050529480e-01
    z[1,4,4]  R1048     1.6203403472900391e-02
    z[1,4,4]  R1049     3.3967226743698120e-02
    z[1,4,4]  R1050     -4.0043359994888306e-01
    z[1,4,4]  R1051     2.4488031864166260e-01
    z[1,4,4]  R1052     -2.7999168634414673e-01
    z[1,4,4]  R1053     1.5323479473590851e-01
    z[1,4,4]  R1054     2.2334653884172440e-02
    z[1,4,4]  R1055     -1.8812276422977448e-01
    z[1,4,4]  R1056     -2.4828863143920898e-01
    z[1,4,4]  R1057     -1.6168478131294250e-01
    z[1,4,4]  R1058     -1.5106610953807831e-01
    z[1,4,4]  R1059     7.6155625283718109e-02
    z[1,4,4]  R1060     4.5021429657936096e-02
    z[1,4,4]  R1061     1.1790663003921509e-01
    z[1,4,4]  R1062     3.5410594195127487e-02
    z[1,4,4]  R1063     0.0838705375790596
    z[1,4,4]  R1064     -1.5915378928184509e-01
    z[1,4,4]  R1065     -5.2755761146545410e-01
    z[1,4,4]  R1066     -2.4036690592765808e-01
    z[1,4,4]  R1067     -5.0913745164871216e-01
    z[1,4,4]  R1068     0.000716552953235805
    z[1,4,4]  R1069     5.7074010372161865e-01
    z[1,4,4]  R1070     -1.7616911232471466e-01
    z[1,4,4]  R1071     4.8988372087478638e-02
    z[1,4,4]  R1072     3.4998711943626404e-01
    z[1,4,4]  R1073     2.0113010704517365e-01
    z[1,4,4]  R1074     -1.8414147198200226e-01
    z[1,4,4]  R1075     2.8846734762191772e-01
    z[1,4,4]  R1076     -4.8386237025260925e-01
    z[1,4,4]  R1077     -4.8561595380306244e-02
    z[1,4,4]  R1078     -2.9330602288246155e-01
    z[1,4,4]  R1079     -4.0362879633903503e-01
    z[1,4,4]  R1080     -3.4878385066986084e-01
    z[1,4,4]  R1081     -3.7716156244277954e-01
    z[1,4,4]  R1082     -3.8579076528549194e-01
    z[1,4,4]  R1083     -3.0203866958618164e-01
    z[1,4,4]  R1084     4.6352226287126541e-02
    z[1,4,4]  R1085     1.6870559751987457e-01
    z[1,4,4]  R1086     -2.5287646055221558e-01
    z[1,4,4]  R1087     -1.5198273956775665e-01
    z[1,4,4]  R1088     -2.8569018840789795e-01
    z[1,4,4]  R1089     -1.9161500036716461e-01
    z[1,4,4]  R1090     -2.7352344989776611e-01
    z[1,4,4]  R1091     -2.6284396648406982e-01
    z[1,4,4]  R1092     -1.8524785339832306e-01
    z[1,4,4]  R1093     -5.9807217121124268e-01
    z[1,4,4]  R1094     -4.9848622083663940e-01
    z[1,4,4]  R1095     -6.5336924791336060e-01
    z[1,4,4]  R1096     -7.2163826227188110e-01
    z[1,4,4]  R1097     -3.5952815413475037e-01
    z[1,4,4]  R1098     -4.0824940800666809e-01
    z[1,4,4]  R1099     3.1452366709709167e-01
    z[1,4,4]  R1100     -0.684838056564331
    z[1,4,4]  R1101     -4.1711923480033875e-01
    z[1,4,4]  R1102     1.0789326392114162e-02
    z[1,4,4]  R1103     -1.2407668679952621e-01
    z[1,4,4]  R1104     -1.8454334139823914e-01
    z[1,4,4]  R1105     1.1577981710433960e-01
    z[1,4,4]  R1106     -3.2115232944488525e-01
    z[1,4,4]  R1107     -4.9837838858366013e-02
    z[1,4,4]  R1108     -3.9657387137413025e-01
    z[1,4,4]  R1109     -0.182534858584404
    z[1,4,4]  R1110     3.5078135132789612e-01
    z[1,4,4]  R1111     5.4858420044183731e-02
    z[1,4,4]  R1112     1.3900396227836609e-01
    z[1,4,4]  R1113     2.7258116006851196e-01
    z[1,4,4]  R1114     4.3921627104282379e-02
    z[1,4,4]  R1115     5.8377593755722046e-01
    z[1,4,4]  R1116     8.3564937114715576e-02
    z[1,4,4]  R1117     1.8081174790859222e-01
    z[1,4,4]  R1118     4.6877473592758179e-01
    z[1,4,4]  R1119     1.3864706456661224e-01
    z[1,4,4]  R1120     -2.5935885310173035e-01
    z[1,4,4]  R1121     -4.4898489117622375e-01
    z[1,4,4]  R1122     -2.8888520598411560e-01
    z[1,4,4]  R1123     -5.4572808742523193e-01
    z[1,4,4]  R1124     1.7076827585697174e-02
    z[1,4,4]  R1125     -0.0605459026992321
    z[1,4,4]  R1126     -8.3162176609039307e-01
    z[1,4,4]  R1127     -2.4538438022136688e-01
    z[1,4,4]  R1128     -6.3393193483352661e-01
    z[1,4,4]  R1129     -4.3460991978645325e-01
    z[1,4,4]  R1130     -4.3667531013488770e-01
    z[1,4,4]  R1131     -3.4096285700798035e-01
    z[1,4,4]  R1132     -3.3043101429939270e-01
    z[1,4,4]  R1133     -6.0014687478542328e-02
    z[1,4,4]  R1134     -4.6652728319168091e-01
    z[1,4,4]  R1135     -3.2168093323707581e-01
    z[1,4,4]  R1136     -1.8092378973960876e-01
    z[1,4,4]  R1137     1.0825133323669434e-01
    z[1,4,4]  R1138     1.2555750086903572e-02
    z[1,4,4]  R1139     3.4217610955238342e-01
    z[1,4,4]  R1140     -5.0948488712310791e-01
    z[1,4,4]  R1141     1.9620832800865173e-01
    z[1,4,4]  R1142     1.0042093694210052e-01
    z[1,4,4]  R1143     -8.4013324975967407e-01
    z[1,4,4]  R1144     4.8353976011276245e-01
    z[1,4,4]  R1145     -2.5056087970733643e-01
    z[1,4,4]  R1146     -3.0108615756034851e-01
    z[1,4,4]  R1147     -3.7153720855712891e-02
    z[1,4,4]  R1148     -2.7126485109329224e-01
    z[1,4,4]  R1149     3.7175214290618896e-01
    z[1,4,4]  R1150     2.4538248777389526e-01
    z[1,4,4]  R1151     -6.3851051032543182e-02
    z[1,4,5]  R16       -1
    z[1,4,5]  R43       1
    z[1,4,5]  R989      -1
    z[1,4,5]  R990      1
    z[1,4,5]  R993      -1.0683242231607437e-02
    z[1,4,5]  R994      4.4384026527404785e-01
    z[1,4,5]  R995      5.6114387512207031e-01
    z[1,4,5]  R996      2.2153569757938385e-01
    z[1,4,5]  R997      0.0785888135433197
    z[1,4,5]  R998      -2.0154097676277161e-01
    z[1,4,5]  R999      -1.4973272383213043e-01
    z[1,4,5]  R1000     -2.0013237372040749e-02
    z[1,4,5]  R1001     1.4452475309371948e-01
    z[1,4,5]  R1002     1.1037625372409821e-01
    z[1,4,5]  R1003     1.5011714398860931e-01
    z[1,4,5]  R1004     1.9484703242778778e-01
    z[1,4,5]  R1005     4.0779468417167664e-01
    z[1,4,5]  R1006     -3.6305990815162659e-01
    z[1,4,5]  R1007     -1.8814601004123688e-01
    z[1,4,5]  R1008     2.2578341886401176e-02
    z[1,4,5]  R1009     4.0209281444549561e-01
    z[1,4,5]  R1010     -2.2305153310298920e-01
    z[1,4,5]  R1011     -3.4657639265060425e-01
    z[1,4,5]  R1012     1.3650451600551605e-01
    z[1,4,5]  R1013     -1.4910818636417389e-01
    z[1,4,5]  R1014     -5.7941582053899765e-02
    z[1,4,5]  R1015     -4.3500947952270508e-01
    z[1,4,5]  R1016     1.2846945226192474e-01
    z[1,4,5]  R1017     -1.9584308564662933e-01
    z[1,4,5]  R1018     5.0724223256111145e-03
    z[1,4,5]  R1019     -3.4511899948120117e-01
    z[1,4,5]  R1020     -5.1498431712388992e-03
    z[1,4,5]  R1021     4.2048788070678711e-01
    z[1,4,5]  R1022     -0.248139888048172
    z[1,4,5]  R1023     -2.2326861321926117e-01
    z[1,4,5]  R1024     -1.4089688658714294e-01
    z[1,4,5]  R1025     -3.5816648602485657e-01
    z[1,4,5]  R1026     -1.9831705838441849e-02
    z[1,4,5]  R1027     -2.8302398324012756e-01
    z[1,4,5]  R1028     -2.6607608795166016e-01
    z[1,4,5]  R1029     -9.3816900625824928e-03
    z[1,4,5]  R1030     -0.00913193728774786
    z[1,4,5]  R1031     -3.4307509660720825e-01
    z[1,4,5]  R1032     1.3647709786891937e-01
    z[1,4,5]  R1033     2.2741788998246193e-02
    z[1,4,5]  R1034     4.9062767624855042e-01
    z[1,4,5]  R1035     4.5953061431646347e-02
    z[1,4,5]  R1036     -1.4729671180248260e-01
    z[1,4,5]  R1037     -2.3401673138141632e-01
    z[1,4,5]  R1038     4.9856898188591003e-01
    z[1,4,5]  R1039     2.8222987055778503e-01
    z[1,4,5]  R1040     -9.2234506155364215e-05
    z[1,4,5]  R1041     -2.2545018792152405e-01
    z[1,4,5]  R1042     4.0567898750305176e-01
    z[1,4,5]  R1043     -1.1036479473114014e-01
    z[1,4,5]  R1044     2.5438693165779114e-01
    z[1,4,5]  R1045     -1.0560341179370880e-01
    z[1,4,5]  R1046     4.6336323022842407e-01
    z[1,4,5]  R1047     4.7741317749023438e-01
    z[1,4,5]  R1048     -5.3843200206756592e-01
    z[1,4,5]  R1049     -2.3436771705746651e-02
    z[1,4,5]  R1050     3.7715956568717957e-01
    z[1,4,5]  R1051     -0.510245680809021
    z[1,4,5]  R1052     1.1509119719266891e-01
    z[1,4,5]  R1053     -6.6956095397472382e-02
    z[1,4,5]  R1054     4.1354256868362427e-01
    z[1,4,5]  R1055     -0.234359011054039
    z[1,4,5]  R1056     1.6112641990184784e-01
    z[1,4,5]  R1057     1.0046856850385666e-01
    z[1,4,5]  R1058     1.0830528289079666e-01
    z[1,4,5]  R1059     1.3350382447242737e-01
    z[1,4,5]  R1060     8.2315705716609955e-02
    z[1,4,5]  R1061     4.7807514667510986e-02
    z[1,4,5]  R1062     -1.8564681708812714e-01
    z[1,4,5]  R1063     3.8254481554031372e-01
    z[1,4,5]  R1064     4.2950016260147095e-01
    z[1,4,5]  R1065     4.4323410838842392e-02
    z[1,4,5]  R1066     -3.0888348817825317e-01
    z[1,4,5]  R1067     -1.7003257572650909e-01
    z[1,4,5]  R1068     -2.1060745418071747e-01
    z[1,4,5]  R1069     -2.8826245665550232e-01
    z[1,4,5]  R1070     -3.1406667828559875e-01
    z[1,4,5]  R1071     -4.2162844538688660e-01
    z[1,4,5]  R1072     -2.5881221890449524e-01
    z[1,4,5]  R1073     3.3505931496620178e-01
    z[1,4,5]  R1074     4.9329307675361633e-01
    z[1,4,5]  R1075     1.1204126477241516e-01
    z[1,4,5]  R1076     2.9471702873706818e-03
    z[1,4,5]  R1077     5.1336448639631271e-02
    z[1,4,5]  R1078     -1.6353687644004822e-01
    z[1,4,5]  R1079     -3.7536349147558212e-02
    z[1,4,5]  R1080     -4.7130686044692993e-01
    z[1,4,5]  R1081     1.5334385633468628e-01
    z[1,4,5]  R1082     -2.6177048683166504e-02
    z[1,4,5]  R1083     5.0096571445465088e-01
    z[1,4,5]  R1084     -2.0492132753133774e-02
    z[1,4,5]  R1085     2.4650931358337402e-01
    z[1,4,5]  R1086     3.1349015235900879e-01
    z[1,4,5]  R1087     -1.9713032990694046e-02
    z[1,4,5]  R1088     3.5099261999130249e-01
    z[1,4,5]  R1089     1.7596293985843658e-01
    z[1,4,5]  R1090     0.315409392118454
    z[1,4,5]  R1091     -4.4421949982643127e-01
    z[1,4,5]  R1092     8.2742515951395035e-03
    z[1,4,5]  R1093     2.7588501572608948e-01
    z[1,4,5]  R1094     0.0768398642539978
    z[1,4,5]  R1095     4.8011988401412964e-01
    z[1,4,5]  R1096     4.0588292479515076e-01
    z[1,4,5]  R1097     5.3919738531112671e-01
    z[1,4,5]  R1098     3.0846032500267029e-01
    z[1,4,5]  R1099     -1.7066171392798424e-02
    z[1,4,5]  R1100     4.3200677633285522e-01
    z[1,4,5]  R1101     7.2658412158489227e-02
    z[1,4,5]  R1102     3.8039374351501465e-01
    z[1,4,5]  R1103     1.8794685602188110e-01
    z[1,4,5]  R1104     3.1153056025505066e-01
    z[1,4,5]  R1105     3.4912928938865662e-02
    z[1,4,5]  R1106     1.9149954617023468e-01
    z[1,4,5]  R1107     -4.0843873284757137e-03
    z[1,4,5]  R1108     2.9163593053817749e-01
    z[1,4,5]  R1109     5.9292250871658325e-01
    z[1,4,5]  R1110     3.4390920400619507e-01
    z[1,4,5]  R1111     2.2979740798473358e-01
    z[1,4,5]  R1112     2.3302505910396576e-01
    z[1,4,5]  R1113     8.0706931650638580e-02
    z[1,4,5]  R1114     -5.3153578191995621e-02
    z[1,4,5]  R1115     -1.1309825628995895e-01
    z[1,4,5]  R1116     -2.2733679413795471e-01
    z[1,4,5]  R1117     5.2110069990158081e-01
    z[1,4,5]  R1118     2.2259102761745453e-01
    z[1,4,5]  R1119     4.0817445516586304e-01
    z[1,4,5]  R1120     1.9557489454746246e-01
    z[1,4,5]  R1121     -2.4819038808345795e-01
    z[1,4,5]  R1122     1.9170695543289185e-01
    z[1,4,5]  R1123     3.0538302659988403e-01
    z[1,4,5]  R1124     5.1258746534585953e-02
    z[1,4,5]  R1125     4.7907531261444092e-01
    z[1,4,5]  R1126     -0.314779132604599
    z[1,4,5]  R1127     9.0232640504837036e-01
    z[1,4,5]  R1128     1.3097949326038361e-01
    z[1,4,5]  R1129     -5.8001402765512466e-02
    z[1,4,5]  R1130     3.7141764163970947e-01
    z[1,4,5]  R1131     1.2606818974018097e-01
    z[1,4,5]  R1132     -1.2264557927846909e-01
    z[1,4,5]  R1133     1.4420942962169647e-01
    z[1,4,5]  R1134     -2.9039919376373291e-01
    z[1,4,5]  R1135     1.4926192164421082e-01
    z[1,4,5]  R1136     -0.0517929382622242
    z[1,4,5]  R1137     -0.0381213054060936
    z[1,4,5]  R1138     1.5846368670463562e-01
    z[1,4,5]  R1139     1.2515859305858612e-01
    z[1,4,5]  R1140     3.9180997014045715e-01
    z[1,4,5]  R1141     -1.6171494126319885e-01
    z[1,4,5]  R1142     -8.8415652513504028e-02
    z[1,4,5]  R1143     -3.2338467240333557e-01
    z[1,4,5]  R1144     1.0416987538337708e-01
    z[1,4,5]  R1145     -1.7621999979019165e-01
    z[1,4,5]  R1146     -3.2661595940589905e-01
    z[1,4,5]  R1147     -4.2096513509750366e-01
    z[1,4,5]  R1148     -4.1891392320394516e-02
    z[1,4,5]  R1149     -1.3399402797222137e-01
    z[1,4,5]  R1150     -1.3040751218795776e-01
    z[1,4,5]  R1151     -0.0849934071302414
    z[1,4,6]  R17       -1
    z[1,4,6]  R44       1
    z[1,4,6]  R991      -1
    z[1,4,6]  R992      1
    z[1,4,6]  R993      1.6781672835350037e-01
    z[1,4,6]  R994      1.5728285908699036e-01
    z[1,4,6]  R995      -0.212831050157547
    z[1,4,6]  R996      1.1290422827005386e-01
    z[1,4,6]  R997      -2.0314763486385345e-01
    z[1,4,6]  R998      -2.0503292977809906e-01
    z[1,4,6]  R999      -2.0527285337448120e-01
    z[1,4,6]  R1000     7.4418224394321442e-02
    z[1,4,6]  R1001     -5.1902536302804947e-02
    z[1,4,6]  R1002     1.1466937512159348e-01
    z[1,4,6]  R1003     -3.8242095708847046e-01
    z[1,4,6]  R1004     -0.123700812458992
    z[1,4,6]  R1005     4.4131819158792496e-02
    z[1,4,6]  R1006     2.0914927124977112e-01
    z[1,4,6]  R1007     -1.5266370773315430e-01
    z[1,4,6]  R1008     4.7503036260604858e-01
    z[1,4,6]  R1009     -2.6302579045295715e-01
    z[1,4,6]  R1010     -1.5337653458118439e-01
    z[1,4,6]  R1011     3.7807431817054749e-01
    z[1,4,6]  R1012     2.7391368150711060e-01
    z[1,4,6]  R1013     2.6329910382628441e-02
    z[1,4,6]  R1014     7.0679372549057007e-01
    z[1,4,6]  R1015     4.6605333685874939e-02
    z[1,4,6]  R1016     -3.4513169527053833e-01
    z[1,4,6]  R1017     5.8406114578247070e-01
    z[1,4,6]  R1018     -1.3775852508842945e-02
    z[1,4,6]  R1019     -1.3469657301902771e-01
    z[1,4,6]  R1020     6.3891232013702393e-02
    z[1,4,6]  R1021     2.4693049490451813e-01
    z[1,4,6]  R1022     2.5733673572540283e-01
    z[1,4,6]  R1023     5.1083713769912720e-01
    z[1,4,6]  R1024     4.4374740123748779e-01
    z[1,4,6]  R1025     1.5302394330501556e-01
    z[1,4,6]  R1026     -1.9526831805706024e-01
    z[1,4,6]  R1027     -2.2403992712497711e-01
    z[1,4,6]  R1028     -2.3340111970901489e-01
    z[1,4,6]  R1029     4.2828115820884705e-01
    z[1,4,6]  R1030     2.6880177855491638e-01
    z[1,4,6]  R1031     2.2382782399654388e-01
    z[1,4,6]  R1032     3.6712527275085449e-01
    z[1,4,6]  R1033     4.4752866029739380e-01
    z[1,4,6]  R1034     1.1494905501604080e-01
    z[1,4,6]  R1035     1.8742652237415314e-01
    z[1,4,6]  R1036     -2.2395202517509460e-01
    z[1,4,6]  R1037     2.3580574989318848e-01
    z[1,4,6]  R1038     1.2304235994815826e-01
    z[1,4,6]  R1039     2.9824849218130112e-02
    z[1,4,6]  R1040     2.2685025632381439e-01
    z[1,4,6]  R1041     -9.2453166842460632e-02
    z[1,4,6]  R1042     5.9650313109159470e-02
    z[1,4,6]  R1043     0.196893572807312
    z[1,4,6]  R1044     -1.2163080275058746e-01
    z[1,4,6]  R1045     -5.5359661579132080e-01
    z[1,4,6]  R1046     0.301082581281662
    z[1,4,6]  R1047     1.8784141540527344e-01
    z[1,4,6]  R1048     2.5613343715667725e-01
    z[1,4,6]  R1049     -1.7376577854156494e-01
    z[1,4,6]  R1050     1.1973126232624054e-01
    z[1,4,6]  R1051     1.3432615995407104e-01
    z[1,4,6]  R1052     1.5900996327400208e-01
    z[1,4,6]  R1053     8.2109540700912476e-02
    z[1,4,6]  R1054     3.1177085638046265e-01
    z[1,4,6]  R1055     9.5916397869586945e-02
    z[1,4,6]  R1056     -1.2706008553504944e-01
    z[1,4,6]  R1057     -3.4822601079940796e-01
    z[1,4,6]  R1058     1.3286796212196350e-01
    z[1,4,6]  R1059     -2.3847262561321259e-01
    z[1,4,6]  R1060     -7.5521886348724365e-02
    z[1,4,6]  R1061     4.7048706561326981e-02
    z[1,4,6]  R1062     -9.0640291571617126e-02
    z[1,4,6]  R1063     2.1592923998832703e-01
    z[1,4,6]  R1064     9.9643588066101074e-02
    z[1,4,6]  R1065     -1.5728241205215454e-01
    z[1,4,6]  R1066     1.2270531058311462e-01
    z[1,4,6]  R1067     -2.2878400981426239e-01
    z[1,4,6]  R1068     2.3199106752872467e-01
    z[1,4,6]  R1069     -0.0837583988904953
    z[1,4,6]  R1070     -1.3407164812088013e-01
    z[1,4,6]  R1071     1.3882575929164886e-01
    z[1,4,6]  R1072     -5.1358896493911743e-01
    z[1,4,6]  R1073     2.2299818694591522e-01
    z[1,4,6]  R1074     1.8443956971168518e-01
    z[1,4,6]  R1075     -6.9723889231681824e-02
    z[1,4,6]  R1076     -1.9082710146903992e-01
    z[1,4,6]  R1077     -6.0413774102926254e-02
    z[1,4,6]  R1078     -1.6859705746173859e-01
    z[1,4,6]  R1079     8.4657423198223114e-02
    z[1,4,6]  R1080     -2.8084853291511536e-01
    z[1,4,6]  R1081     -1.8471510848030448e-03
    z[1,4,6]  R1082     -5.2542369812726974e-03
    z[1,4,6]  R1083     1.1301857233047485e-01
    z[1,4,6]  R1084     1.4101485908031464e-01
    z[1,4,6]  R1085     -2.0797398686408997e-01
    z[1,4,6]  R1086     -1.3379167020320892e-01
    z[1,4,6]  R1087     -2.0895868539810181e-02
    z[1,4,6]  R1088     -5.8076906949281693e-02
    z[1,4,6]  R1089     5.0957348197698593e-02
    z[1,4,6]  R1090     1.7451328039169312e-01
    z[1,4,6]  R1091     3.5186418890953064e-01
    z[1,4,6]  R1092     -2.1904313564300537e-01
    z[1,4,6]  R1093     -3.2459592819213867e-01
    z[1,4,6]  R1094     4.8325583338737488e-02
    z[1,4,6]  R1095     -3.5433974117040634e-02
    z[1,4,6]  R1096     4.1947695612907410e-01
    z[1,4,6]  R1097     9.6513405442237854e-02
    z[1,4,6]  R1098     2.2284905612468719e-01
    z[1,4,6]  R1099     -2.0006555318832397e-01
    z[1,4,6]  R1100     2.1568414568901062e-01
    z[1,4,6]  R1101     5.8561146259307861e-01
    z[1,4,6]  R1102     2.5013424456119537e-03
    z[1,4,6]  R1103     1.3021971285343170e-01
    z[1,4,6]  R1104     -2.3854376375675201e-01
    z[1,4,6]  R1105     -1.7075374722480774e-01
    z[1,4,6]  R1106     1.8598724901676178e-01
    z[1,4,6]  R1107     2.5466856360435486e-01
    z[1,4,6]  R1108     -4.8353332281112671e-01
    z[1,4,6]  R1109     -3.5868138074874878e-01
    z[1,4,6]  R1110     -3.9329206943511963e-01
    z[1,4,6]  R1111     -2.2811383008956909e-01
    z[1,4,6]  R1112     6.4580667018890381e-01
    z[1,4,6]  R1113     -1.5585084259510040e-01
    z[1,4,6]  R1114     -4.4793391227722168e-01
    z[1,4,6]  R1115     -1.7386395484209061e-02
    z[1,4,6]  R1116     -1.2443863600492477e-01
    z[1,4,6]  R1117     4.2697262018918991e-02
    z[1,4,6]  R1118     -2.4199962615966797e-02
    z[1,4,6]  R1119     2.6031273603439331e-01
    z[1,4,6]  R1120     1.9470381736755371e-01
    z[1,4,6]  R1121     2.6132947206497192e-01
    z[1,4,6]  R1122     -0.398084819316864
    z[1,4,6]  R1123     2.4788361787796021e-01
    z[1,4,6]  R1124     3.4689265489578247e-01
    z[1,4,6]  R1125     -1.6337784007191658e-02
    z[1,4,6]  R1126     -8.7756089866161346e-02
    z[1,4,6]  R1127     -7.9994276165962219e-03
    z[1,4,6]  R1128     4.4153681397438049e-01
    z[1,4,6]  R1129     -2.6913493871688843e-01
    z[1,4,6]  R1130     -1.4677749946713448e-02
    z[1,4,6]  R1131     -3.1525948643684387e-01
    z[1,4,6]  R1132     1.6807551681995392e-01
    z[1,4,6]  R1133     4.3010881543159485e-01
    z[1,4,6]  R1134     -1.3056711852550507e-01
    z[1,4,6]  R1135     -1.6935016214847565e-01
    z[1,4,6]  R1136     2.6247268915176392e-01
    z[1,4,6]  R1137     -2.4118547141551971e-01
    z[1,4,6]  R1138     -6.1556601524353027e-01
    z[1,4,6]  R1139     7.9690247774124146e-02
    z[1,4,6]  R1140     -2.6254606246948242e-01
    z[1,4,6]  R1141     -1.0532230883836746e-01
    z[1,4,6]  R1142     5.4940257221460342e-02
    z[1,4,6]  R1143     6.6073901951313019e-02
    z[1,4,6]  R1144     2.3335088789463043e-01
    z[1,4,6]  R1145     1.4274649322032928e-01
    z[1,4,6]  R1146     2.8746458888053894e-01
    z[1,4,6]  R1147     -6.6539153456687927e-02
    z[1,4,6]  R1148     1.5067237615585327e-01
    z[1,4,6]  R1149     -1.2331873923540115e-01
    z[1,4,6]  R1150     -1.6254171729087830e-01
    z[1,4,6]  R1151     -5.4477435350418091e-01
    z[4,1,0]  R11       1
    z[4,1,0]  R38       -1
    z[4,1,0]  R1152     -1
    z[4,1,0]  R1153     1
    z[4,1,0]  R1166     -5.7847633957862854e-02
    z[4,1,0]  R1167     2.3291967809200287e-01
    z[4,1,0]  R1168     1.9032852351665497e-01
    z[4,1,0]  R1169     1.0687439143657684e-01
    z[4,1,0]  R1170     1.2337212264537811e-01
    z[4,1,0]  R1171     -1.5379829704761505e-01
    z[4,1,0]  R1172     0.612011730670929
    z[4,1,0]  R1173     -2.5405046343803406e-01
    z[4,1,0]  R1174     -1.7137020826339722e-01
    z[4,1,0]  R1175     5.9136056900024414e-01
    z[4,1,0]  R1176     -3.8787201046943665e-01
    z[4,1,0]  R1177     -1.7020131647586823e-01
    z[4,1,0]  R1178     -1.3619169592857361e-01
    z[4,1,0]  R1179     4.5985409617424011e-01
    z[4,1,0]  R1180     1.5315456688404083e-01
    z[4,1,0]  R1181     3.9971357583999634e-01
    z[4,1,0]  R1182     3.3082881569862366e-01
    z[4,1,0]  R1183     -1.5886427462100983e-01
    z[4,1,0]  R1184     2.4377131462097168e-01
    z[4,1,0]  R1185     -9.3194320797920227e-02
    z[4,1,0]  R1186     -1.2749305367469788e-01
    z[4,1,0]  R1187     -3.3869582414627075e-01
    z[4,1,0]  R1188     -3.0979645252227783e-01
    z[4,1,0]  R1189     4.6450782567262650e-02
    z[4,1,0]  R1190     -5.0778716802597046e-01
    z[4,1,0]  R1191     -4.2351409792900085e-01
    z[4,1,0]  R1192     -2.8360605239868164e-01
    z[4,1,0]  R1193     5.3043287992477417e-01
    z[4,1,0]  R1194     5.4679775238037109e-01
    z[4,1,0]  R1195     4.1538336873054504e-01
    z[4,1,0]  R1196     -3.4991261363029480e-01
    z[4,1,0]  R1197     -6.5750330686569214e-02
    z[4,1,0]  R1198     6.4677906036376953e-01
    z[4,1,0]  R1199     2.2338490188121796e-01
    z[4,1,0]  R1200     2.0899084210395813e-01
    z[4,1,0]  R1201     5.5733382701873779e-01
    z[4,1,0]  R1202     8.4454685449600220e-01
    z[4,1,0]  R1203     3.7446701526641846e-01
    z[4,1,0]  R1204     7.4645286798477173e-01
    z[4,1,0]  R1205     4.8767754435539246e-01
    z[4,1,0]  R1206     3.3604595810174942e-02
    z[4,1,0]  R1207     5.7812124490737915e-01
    z[4,1,0]  R1208     8.7086832523345947e-01
    z[4,1,0]  R1209     -2.4377760291099548e-01
    z[4,1,0]  R1210     5.2036845684051514e-01
    z[4,1,0]  R1211     6.8450921773910522e-01
    z[4,1,0]  R1212     -1.7482032999396324e-03
    z[4,1,0]  R1213     4.1061496734619141e-01
    z[4,1,0]  R1214     -8.1347328424453735e-01
    z[4,1,0]  R1215     -7.9426652193069458e-01
    z[4,1,0]  R1216     -1.0821318626403809e-01
    z[4,1,0]  R1217     -6.9208703935146332e-02
    z[4,1,0]  R1218     -3.2698172330856323e-01
    z[4,1,0]  R1219     -0.609432578086853
    z[4,1,0]  R1220     -6.8806296586990356e-01
    z[4,1,0]  R1221     -8.0902999639511108e-01
    z[4,1,0]  R1222     -4.1726133227348328e-01
    z[4,1,0]  R1223     -3.1601142883300781e-01
    z[4,1,0]  R1224     -0.582899808883667
    z[4,1,0]  R1225     0.723736584186554
    z[4,1,0]  R1226     8.0472415685653687e-01
    z[4,1,0]  R1227     6.1697083711624146e-01
    z[4,1,0]  R1228     6.5605306625366211e-01
    z[4,1,0]  R1229     8.8712280988693237e-01
    z[4,1,0]  R1230     8.8229048252105713e-01
    z[4,1,0]  R1231     8.9311712980270386e-01
    z[4,1,0]  R1232     9.1823190450668335e-01
    z[4,1,0]  R1233     8.4810262918472290e-01
    z[4,1,0]  R1234     8.6877566576004028e-01
    z[4,1,0]  R1235     -2.4355600774288177e-01
    z[4,1,0]  R1236     -8.6646175384521484e-01
    z[4,1,0]  R1237     -1.7858077585697174e-01
    z[4,1,0]  R1238     -3.5714778304100037e-01
    z[4,1,0]  R1239     -7.5557577610015869e-01
    z[4,1,0]  R1240     -7.6985865831375122e-01
    z[4,1,0]  R1241     -7.5257080793380737e-01
    z[4,1,0]  R1242     -1.5396592207252979e-02
    z[4,1,0]  R1243     -1.4446650445461273e-01
    z[4,1,0]  R1244     8.9831940829753876e-02
    z[4,1,0]  R1245     -4.6918381005525589e-02
    z[4,1,0]  R1246     1.3612688519060612e-02
    z[4,1,0]  R1247     -7.2523248195648193e-01
    z[4,1,0]  R1248     -2.0390337333083153e-02
    z[4,1,0]  R1249     2.3649508133530617e-02
    z[4,1,0]  R1250     -7.7637803554534912e-01
    z[4,1,0]  R1251     -7.3027008771896362e-01
    z[4,1,0]  R1252     -7.8857392072677612e-01
    z[4,1,0]  R1253     0.0638904869556427
    z[4,1,0]  R1254     -0.730022668838501
    z[4,1,0]  R1255     3.2288023829460144e-01
    z[4,1,0]  R1256     1.6156212985515594e-01
    z[4,1,0]  R1257     2.2361817955970764e-01
    z[4,1,0]  R1258     -7.8468585014343262e-01
    z[4,1,0]  R1259     -7.9549568891525269e-01
    z[4,1,0]  R1260     -8.5130012035369873e-01
    z[4,1,0]  R1261     -0.858471155166626
    z[4,1,0]  R1262     -8.3502292633056641e-01
    z[4,1,0]  R1263     -8.7198764085769653e-01
    z[4,1,0]  R1264     -7.3678523302078247e-01
    z[4,1,0]  R1265     2.4792306125164032e-01
    z[4,1,0]  R1266     3.6198583245277405e-01
    z[4,1,0]  R1267     1.3135664165019989e-01
    z[4,1,0]  R1268     -8.4073919057846069e-01
    z[4,1,0]  R1269     -7.6478409767150879e-01
    z[4,1,0]  R1270     -7.9939109086990356e-01
    z[4,1,0]  R1271     -7.9929852485656738e-01
    z[4,1,0]  R1272     -7.9075801372528076e-01
    z[4,1,0]  R1273     -8.4291136264801025e-01
    z[4,1,0]  R1274     -4.1825491189956665e-01
    z[4,1,0]  R1275     1.5854188799858093e-01
    z[4,1,0]  R1276     -9.3071717023849487e-01
    z[4,1,0]  R1277     -4.7545678913593292e-02
    z[4,1,0]  R1278     -0.812671959400177
    z[4,1,0]  R1279     -7.1106845140457153e-01
    z[4,1,0]  R1280     -6.4418500661849976e-01
    z[4,1,0]  R1281     -8.2161104679107666e-01
    z[4,1,0]  R1282     -3.3492672443389893e-01
    z[4,1,0]  R1283     -7.1009427309036255e-01
    z[4,1,0]  R1284     -8.5085999965667725e-01
    z[4,1,0]  R1285     -8.4011381864547729e-01
    z[4,1,0]  R1286     -8.2892262935638428e-01
    z[4,1,0]  R1287     -6.6660982370376587e-01
    z[4,1,0]  R1288     -8.4759056568145752e-01
    z[4,1,0]  R1289     -7.2158157825469971e-01
    z[4,1,0]  R1290     -8.4859234094619751e-01
    z[4,1,0]  R1291     -3.8933184742927551e-01
    z[4,1,0]  R1292     -6.2131547927856445e-01
    z[4,1,0]  R1293     2.4689945578575134e-01
    z[4,1,0]  R1294     1.7999957501888275e-01
    z[4,1,0]  R1295     -8.6880499124526978e-01
    z[4,1,0]  R1296     -3.5068488121032715e-01
    z[4,1,0]  R1297     -7.1212485432624817e-02
    z[4,1,0]  R1298     -0.813671350479126
    z[4,1,0]  R1299     -8.9947231113910675e-02
    z[4,1,0]  R1300     2.4146883189678192e-01
    z[4,1,0]  R1301     -6.0453188419342041e-01
    z[4,1,0]  R1302     -1.4398542046546936e-01
    z[4,1,0]  R1303     -4.0792167186737061e-01
    z[4,1,0]  R1304     -2.6940107345581055e-01
    z[4,1,0]  R1305     -0.852932870388031
    z[4,1,0]  R1306     -3.3950966596603394e-01
    z[4,1,0]  R1307     -1.7837733030319214e-01
    z[4,1,0]  R1308     -1.7302061617374420e-01
    z[4,1,0]  R1309     -5.4825592041015625e-01
    z[4,1,0]  R1310     -1.2178809195756912e-01
    z[4,1,0]  R1311     2.0942500233650208e-01
    z[4,1,0]  R1312     -0.0467689111828804
    z[4,1,0]  R1313     2.5784561038017273e-01
    z[4,1,0]  R1314     1.8484315276145935e-01
    z[4,1,0]  R1315     -2.8594323992729187e-01
    z[4,1,0]  R1316     -7.4660068750381470e-01
    z[4,1,0]  R1317     -7.9481208324432373e-01
    z[4,1,0]  R1318     -1.2942856550216675e-01
    z[4,1,0]  R1319     -4.0330997109413147e-01
    z[4,1,0]  R1320     1.4957337081432343e-01
    z[4,1,0]  R1321     3.4764219075441360e-02
    z[4,1,0]  R1322     3.4324326552450657e-03
    z[4,1,0]  R1323     1.9561995286494493e-03
    z[4,1,0]  R1324     0.251740038394928
    z[4,1,1]  R12       1
    z[4,1,1]  R39       -1
    z[4,1,1]  R1154     -1
    z[4,1,1]  R1155     1
    z[4,1,1]  R1166     -2.2434207797050476e-01
    z[4,1,1]  R1167     -4.1379917412996292e-02
    z[4,1,1]  R1168     -4.6656742691993713e-02
    z[4,1,1]  R1169     -1.2432451546192169e-01
    z[4,1,1]  R1170     -7.1573257446289062e-02
    z[4,1,1]  R1171     5.6521035730838776e-02
    z[4,1,1]  R1172     -3.6553180217742920e-01
    z[4,1,1]  R1173     -8.5622303187847137e-02
    z[4,1,1]  R1174     0.0456363670527935
    z[4,1,1]  R1175     -2.4456253647804260e-01
    z[4,1,1]  R1176     8.4129935503005981e-01
    z[4,1,1]  R1177     8.6757284402847290e-01
    z[4,1,1]  R1178     8.4425538778305054e-01
    z[4,1,1]  R1179     -4.5689931511878967e-01
    z[4,1,1]  R1180     -7.9187095165252686e-01
    z[4,1,1]  R1181     2.4552106857299805e-01
    z[4,1,1]  R1182     -9.0515814721584320e-02
    z[4,1,1]  R1183     -3.9412230253219604e-01
    z[4,1,1]  R1184     -6.0985791683197021e-01
    z[4,1,1]  R1185     -6.7751926183700562e-01
    z[4,1,1]  R1186     -6.6503608226776123e-01
    z[4,1,1]  R1187     -7.6249647140502930e-01
    z[4,1,1]  R1188     -6.5101730823516846e-01
    z[4,1,1]  R1189     -7.9949998855590820e-01
    z[4,1,1]  R1190     -5.5410587787628174e-01
    z[4,1,1]  R1191     -0.576320469379425
    z[4,1,1]  R1192     -7.7463120222091675e-01
    z[4,1,1]  R1193     2.1554206311702728e-01
    z[4,1,1]  R1194     -0.500268816947937
    z[4,1,1]  R1195     -6.4946311712265015e-01
    z[4,1,1]  R1196     -3.6966410279273987e-01
    z[4,1,1]  R1197     -5.5434852838516235e-01
    z[4,1,1]  R1198     -5.8023804426193237e-01
    z[4,1,1]  R1199     1.1254636943340302e-01
    z[4,1,1]  R1200     1.1817237734794617e-01
    z[4,1,1]  R1201     -2.1881256997585297e-01
    z[4,1,1]  R1202     -8.0024182796478271e-02
    z[4,1,1]  R1203     -2.2036722302436829e-01
    z[4,1,1]  R1204     3.2096442580223083e-01
    z[4,1,1]  R1205     -7.2960913181304932e-01
    z[4,1,1]  R1206     -7.2324448823928833e-01
    z[4,1,1]  R1207     -5.4733687639236450e-01
    z[4,1,1]  R1208     -2.4741439521312714e-01
    z[4,1,1]  R1209     -4.4586917757987976e-01
    z[4,1,1]  R1210     -5.3672641515731812e-01
    z[4,1,1]  R1211     -2.4713842570781708e-01
    z[4,1,1]  R1212     -8.9190351963043213e-01
    z[4,1,1]  R1213     3.3194816112518311e-01
    z[4,1,1]  R1214     3.5491049289703369e-01
    z[4,1,1]  R1215     0.244643896818161
    z[4,1,1]  R1216     -3.2988885045051575e-01
    z[4,1,1]  R1217     -6.9191831350326538e-01
    z[4,1,1]  R1218     -8.0293434858322144e-01
    z[4,1,1]  R1219     -5.7155334949493408e-01
    z[4,1,1]  R1220     -4.9672827124595642e-01
    z[4,1,1]  R1221     -2.3610962927341461e-01
    z[4,1,1]  R1222     1.0668906569480896e-01
    z[4,1,1]  R1223     1.1416645348072052e-01
    z[4,1,1]  R1224     2.0661045610904694e-01
    z[4,1,1]  R1225     -3.3563992381095886e-01
    z[4,1,1]  R1226     -2.8114026784896851e-01
    z[4,1,1]  R1227     -2.0235392451286316e-01
    z[4,1,1]  R1228     -3.9763000607490540e-01
    z[4,1,1]  R1229     -1.9126047194004059e-01
    z[4,1,1]  R1230     -3.2268315553665161e-01
    z[4,1,1]  R1231     -1.1038208752870560e-01
    z[4,1,1]  R1232     -1.0242065042257309e-01
    z[4,1,1]  R1233     -3.7171953916549683e-01
    z[4,1,1]  R1234     -2.7798095345497131e-01
    z[4,1,1]  R1235     -7.3880583047866821e-01
    z[4,1,1]  R1236     2.8852856159210205e-01
    z[4,1,1]  R1237     -6.9745475053787231e-01
    z[4,1,1]  R1238     -6.7659026384353638e-01
    z[4,1,1]  R1239     1.5621243417263031e-01
    z[4,1,1]  R1240     1.3875234127044678e-01
    z[4,1,1]  R1241     7.7380046248435974e-02
    z[4,1,1]  R1242     -2.4864664673805237e-01
    z[4,1,1]  R1243     -7.1995544433593750e-01
    z[4,1,1]  R1244     4.3988442420959473e-01
    z[4,1,1]  R1245     -8.7624388933181763e-01
    z[4,1,1]  R1246     -2.5671776384115219e-02
    z[4,1,1]  R1247     3.5382679104804993e-01
    z[4,1,1]  R1248     -1.6947848722338676e-02
    z[4,1,1]  R1249     -2.8374776244163513e-01
    z[4,1,1]  R1250     2.6474717259407043e-01
    z[4,1,1]  R1251     3.5049974918365479e-01
    z[4,1,1]  R1252     8.2094341516494751e-02
    z[4,1,1]  R1253     5.8240371942520142e-01
    z[4,1,1]  R1254     2.2649440169334412e-01
    z[4,1,1]  R1255     -1.4183451235294342e-01
    z[4,1,1]  R1256     -1.4633235335350037e-01
    z[4,1,1]  R1257     -2.8569728136062622e-01
    z[4,1,1]  R1258     3.9122492074966431e-01
    z[4,1,1]  R1259     4.2709720134735107e-01
    z[4,1,1]  R1260     2.0969817042350769e-01
    z[4,1,1]  R1261     1.8353113532066345e-01
    z[4,1,1]  R1262     4.3121472001075745e-01
    z[4,1,1]  R1263     4.7087732702493668e-02
    z[4,1,1]  R1264     3.2928496599197388e-01
    z[4,1,1]  R1265     -4.2966210842132568e-01
    z[4,1,1]  R1266     1.4785882830619812e-01
    z[4,1,1]  R1267     5.3121572732925415e-01
    z[4,1,1]  R1268     3.4137284755706787e-01
    z[4,1,1]  R1269     2.1490712463855743e-01
    z[4,1,1]  R1270     1.4756475389003754e-01
    z[4,1,1]  R1271     -4.8007094860076904e-01
    z[4,1,1]  R1272     -4.7991201281547546e-01
    z[4,1,1]  R1273     -3.9515095949172974e-01
    z[4,1,1]  R1274     -6.2988650798797607e-01
    z[4,1,1]  R1275     4.1771256923675537e-01
    z[4,1,1]  R1276     1.5441577136516571e-01
    z[4,1,1]  R1277     -3.9207491278648376e-01
    z[4,1,1]  R1278     1.6048018634319305e-01
    z[4,1,1]  R1279     3.0565094947814941e-01
    z[4,1,1]  R1280     3.3529585599899292e-01
    z[4,1,1]  R1281     -4.1966083645820618e-01
    z[4,1,1]  R1282     -2.7800619602203369e-01
    z[4,1,1]  R1283     6.7779272794723511e-02
    z[4,1,1]  R1284     -3.1335547566413879e-01
    z[4,1,1]  R1285     4.0297958254814148e-01
    z[4,1,1]  R1286     1.9702941179275513e-01
    z[4,1,1]  R1287     4.1896373033523560e-01
    z[4,1,1]  R1288     -4.1293808817863464e-01
    z[4,1,1]  R1289     -5.4255348443984985e-01
    z[4,1,1]  R1290     -3.4744662046432495e-01
    z[4,1,1]  R1291     1.5410919487476349e-01
    z[4,1,1]  R1292     -5.8917975425720215e-01
    z[4,1,1]  R1293     9.3907696008682251e-01
    z[4,1,1]  R1294     9.6039682626724243e-01
    z[4,1,1]  R1295     1.8808189034461975e-01
    z[4,1,1]  R1296     -3.5703826695680618e-02
    z[4,1,1]  R1297     -2.1576354280114174e-02
    z[4,1,1]  R1298     5.2840482443571091e-02
    z[4,1,1]  R1299     -0.669160008430481
    z[4,1,1]  R1300     8.5001587867736816e-01
    z[4,1,1]  R1301     -4.2836752533912659e-01
    z[4,1,1]  R1302     5.4281461238861084e-01
    z[4,1,1]  R1303     -4.0056610107421875e-01
    z[4,1,1]  R1304     -5.1552116870880127e-01
    z[4,1,1]  R1305     2.4238830804824829e-01
    z[4,1,1]  R1306     -1.0183142125606537e-01
    z[4,1,1]  R1307     -5.1572978496551514e-01
    z[4,1,1]  R1308     -7.6958012580871582e-01
    z[4,1,1]  R1309     -2.7142700552940369e-01
    z[4,1,1]  R1310     8.2527321577072144e-01
    z[4,1,1]  R1311     8.8517922163009644e-01
    z[4,1,1]  R1312     7.2231113910675049e-01
    z[4,1,1]  R1313     0.835231363773346
    z[4,1,1]  R1314     8.3807313442230225e-01
    z[4,1,1]  R1315     -5.3620919585227966e-02
    z[4,1,1]  R1316     2.3409350216388702e-01
    z[4,1,1]  R1317     3.8337996602058411e-01
    z[4,1,1]  R1318     -8.3246874809265137e-01
    z[4,1,1]  R1319     -3.3632597327232361e-01
    z[4,1,1]  R1320     0.822594165802002
    z[4,1,1]  R1321     7.3138356208801270e-01
    z[4,1,1]  R1322     7.8624749183654785e-01
    z[4,1,1]  R1323     7.7497494220733643e-01
    z[4,1,1]  R1324     7.3773950338363647e-01
    z[4,1,2]  R13       1
    z[4,1,2]  R40       -1
    z[4,1,2]  R1156     -1
    z[4,1,2]  R1157     1
    z[4,1,2]  R1166     -5.9244537353515625e-01
    z[4,1,2]  R1167     -8.2150202989578247e-01
    z[4,1,2]  R1168     -5.4357331991195679e-01
    z[4,1,2]  R1169     -3.1353580951690674e-01
    z[4,1,2]  R1170     -7.3006719350814819e-01
    z[4,1,2]  R1171     -7.2983759641647339e-01
    z[4,1,2]  R1172     -2.6255834102630615e-01
    z[4,1,2]  R1173     -2.2652576863765717e-01
    z[4,1,2]  R1174     -6.6095048189163208e-01
    z[4,1,2]  R1175     -6.0441619157791138e-01
    z[4,1,2]  R1176     1.1838949285447598e-02
    z[4,1,2]  R1177     -8.1899136304855347e-02
    z[4,1,2]  R1178     -4.5951315760612488e-01
    z[4,1,2]  R1179     6.1652439832687378e-01
    z[4,1,2]  R1180     2.8402274474501610e-02
    z[4,1,2]  R1181     2.7462553977966309e-01
    z[4,1,2]  R1182     4.0592372417449951e-01
    z[4,1,2]  R1183     2.7861317619681358e-02
    z[4,1,2]  R1184     2.7157512307167053e-01
    z[4,1,2]  R1185     1.4036209881305695e-01
    z[4,1,2]  R1186     -1.9590763747692108e-01
    z[4,1,2]  R1187     -2.3073473572731018e-01
    z[4,1,2]  R1188     -3.0537730455398560e-01
    z[4,1,2]  R1189     2.0183049142360687e-01
    z[4,1,2]  R1190     -2.9556852579116821e-01
    z[4,1,2]  R1191     -4.0751591324806213e-01
    z[4,1,2]  R1192     -1.1781888455152512e-01
    z[4,1,2]  R1193     -6.2708705663681030e-02
    z[4,1,2]  R1194     -7.0346496999263763e-02
    z[4,1,2]  R1195     3.0369493365287781e-01
    z[4,1,2]  R1196     -2.3955148458480835e-01
    z[4,1,2]  R1197     -5.7545232772827148e-01
    z[4,1,2]  R1198     9.1637238860130310e-02
    z[4,1,2]  R1199     -5.8281220495700836e-02
    z[4,1,2]  R1200     -2.0295043289661407e-01
    z[4,1,2]  R1201     -1.2939724326133728e-01
    z[4,1,2]  R1202     5.9550367295742035e-02
    z[4,1,2]  R1203     -2.1915417909622192e-01
    z[4,1,2]  R1204     -5.4754824377596378e-03
    z[4,1,2]  R1205     2.2998669743537903e-01
    z[4,1,2]  R1206     -3.3640664815902710e-01
    z[4,1,2]  R1207     -2.1699997782707214e-01
    z[4,1,2]  R1208     1.5533640980720520e-01
    z[4,1,2]  R1209     -6.7132425308227539e-01
    z[4,1,2]  R1210     -0.544070839881897
    z[4,1,2]  R1211     1.1546090245246887e-01
    z[4,1,2]  R1212     2.4799892306327820e-01
    z[4,1,2]  R1213     -2.8383618593215942e-01
    z[4,1,2]  R1214     7.4420824646949768e-02
    z[4,1,2]  R1215     4.0437978506088257e-01
    z[4,1,2]  R1216     5.6865561753511429e-02
    z[4,1,2]  R1217     -4.4046363234519958e-01
    z[4,1,2]  R1218     2.0109033584594727e-01
    z[4,1,2]  R1219     -1.4814113080501556e-01
    z[4,1,2]  R1220     -2.4655283987522125e-01
    z[4,1,2]  R1221     -4.0472263097763062e-01
    z[4,1,2]  R1222     7.9461358487606049e-02
    z[4,1,2]  R1223     3.3187928795814514e-01
    z[4,1,2]  R1224     3.6535346508026123e-01
    z[4,1,2]  R1225     -1.1853816360235214e-01
    z[4,1,2]  R1226     -1.3509753160178661e-02
    z[4,1,2]  R1227     -5.8933593332767487e-02
    z[4,1,2]  R1228     -5.3258843719959259e-02
    z[4,1,2]  R1229     7.5866342522203922e-03
    z[4,1,2]  R1230     6.0134965926408768e-02
    z[4,1,2]  R1231     2.9740616679191589e-01
    z[4,1,2]  R1232     2.6105591654777527e-01
    z[4,1,2]  R1233     -2.3807699978351593e-01
    z[4,1,2]  R1234     2.2151088714599609e-01
    z[4,1,2]  R1235     -1.4257369935512543e-01
    z[4,1,2]  R1236     2.1280555427074432e-01
    z[4,1,2]  R1237     -5.3871236741542816e-02
    z[4,1,2]  R1238     -0.158564493060112
    z[4,1,2]  R1239     -7.0406176149845123e-02
    z[4,1,2]  R1240     -1.9678844138979912e-02
    z[4,1,2]  R1241     -2.5658485293388367e-01
    z[4,1,2]  R1242     -3.8320258259773254e-01
    z[4,1,2]  R1243     1.7249508202075958e-01
    z[4,1,2]  R1244     4.3248921632766724e-01
    z[4,1,2]  R1245     -1.2811531126499176e-01
    z[4,1,2]  R1246     1.4191722869873047e-01
    z[4,1,2]  R1247     -1.0315258055925369e-01
    z[4,1,2]  R1248     5.7939875125885010e-01
    z[4,1,2]  R1249     4.5659548044204712e-01
    z[4,1,2]  R1250     -2.1855439245700836e-01
    z[4,1,2]  R1251     -2.0133875310420990e-01
    z[4,1,2]  R1252     1.3484379276633263e-02
    z[4,1,2]  R1253     2.1422983705997467e-01
    z[4,1,2]  R1254     2.9233434796333313e-01
    z[4,1,2]  R1255     3.5992351174354553e-01
    z[4,1,2]  R1256     -0.679987370967865
    z[4,1,2]  R1257     -2.2934034466743469e-01
    z[4,1,2]  R1258     -0.0109430942684412
    z[4,1,2]  R1259     -1.5799516439437866e-01
    z[4,1,2]  R1260     1.1394404806196690e-02
    z[4,1,2]  R1261     -2.3620298597961664e-03
    z[4,1,2]  R1262     1.6179924830794334e-02
    z[4,1,2]  R1263     -0.0656462013721466
    z[4,1,2]  R1264     3.4418323636054993e-01
    z[4,1,2]  R1265     3.0129194259643555e-01
    z[4,1,2]  R1266     2.8884598612785339e-01
    z[4,1,2]  R1267     1.9122385978698730e-01
    z[4,1,2]  R1268     -2.9208555817604065e-01
    z[4,1,2]  R1269     -2.2691851854324341e-01
    z[4,1,2]  R1270     6.4044152386486530e-03
    z[4,1,2]  R1271     2.0478211343288422e-01
    z[4,1,2]  R1272     1.4265184104442596e-01
    z[4,1,2]  R1273     2.4560482800006866e-01
    z[4,1,2]  R1274     -2.2371813654899597e-01
    z[4,1,2]  R1275     6.0382062196731567e-01
    z[4,1,2]  R1276     0.0838552713394165
    z[4,1,2]  R1277     -3.8139653205871582e-01
    z[4,1,2]  R1278     3.2950885593891144e-02
    z[4,1,2]  R1279     -7.8959226608276367e-02
    z[4,1,2]  R1280     1.7590709030628204e-01
    z[4,1,2]  R1281     -2.7172014117240906e-01
    z[4,1,2]  R1282     -1.8509723246097565e-01
    z[4,1,2]  R1283     3.8466113805770874e-01
    z[4,1,2]  R1284     -1.3332429528236389e-01
    z[4,1,2]  R1285     3.1154736876487732e-01
    z[4,1,2]  R1286     1.9985429942607880e-02
    z[4,1,2]  R1287     2.8842157125473022e-01
    z[4,1,2]  R1288     -4.1602656245231628e-02
    z[4,1,2]  R1289     -1.7169304192066193e-02
    z[4,1,2]  R1290     -1.9052948057651520e-01
    z[4,1,2]  R1291     -2.5256642699241638e-01
    z[4,1,2]  R1292     7.0102256722748280e-03
    z[4,1,2]  R1293     -1.6414555907249451e-01
    z[4,1,2]  R1294     -3.6084707826375961e-02
    z[4,1,2]  R1295     -5.1217749714851379e-02
    z[4,1,2]  R1296     -5.1917475461959839e-01
    z[4,1,2]  R1297     -5.8295524120330811e-01
    z[4,1,2]  R1298     1.7868605256080627e-01
    z[4,1,2]  R1299     3.4137687087059021e-01
    z[4,1,2]  R1300     -3.3170655369758606e-01
    z[4,1,2]  R1301     1.3348698616027832e-01
    z[4,1,2]  R1302     -5.5416148900985718e-01
    z[4,1,2]  R1303     3.6347416043281555e-01
    z[4,1,2]  R1304     -4.5652204751968384e-01
    z[4,1,2]  R1305     -7.0415951311588287e-02
    z[4,1,2]  R1306     -4.7058498859405518e-01
    z[4,1,2]  R1307     -3.4134802222251892e-01
    z[4,1,2]  R1308     -1.0316787520423532e-03
    z[4,1,2]  R1309     6.6267979145050049e-01
    z[4,1,2]  R1310     -1.2245739996433258e-01
    z[4,1,2]  R1311     3.1064450740814209e-03
    z[4,1,2]  R1312     -1.9768038392066956e-01
    z[4,1,2]  R1313     -2.6481890678405762e-01
    z[4,1,2]  R1314     -1.8159645795822144e-01
    z[4,1,2]  R1315     -4.6260491013526917e-01
    z[4,1,2]  R1316     -1.7056234180927277e-01
    z[4,1,2]  R1317     -2.9695001244544983e-01
    z[4,1,2]  R1318     3.5705637186765671e-02
    z[4,1,2]  R1319     5.0237149000167847e-01
    z[4,1,2]  R1320     -6.4319007098674774e-02
    z[4,1,2]  R1321     1.2722036242485046e-01
    z[4,1,2]  R1322     -7.0435716770589352e-03
    z[4,1,2]  R1323     -9.3880154192447662e-02
    z[4,1,2]  R1324     1.7199160158634186e-01
    z[4,1,3]  R14       1
    z[4,1,3]  R41       -1
    z[4,1,3]  R1158     -1
    z[4,1,3]  R1159     1
    z[4,1,3]  R1166     2.3699685931205750e-01
    z[4,1,3]  R1167     1.1154517531394958e-01
    z[4,1,3]  R1168     -8.6395636200904846e-02
    z[4,1,3]  R1169     1.1555530875921249e-01
    z[4,1,3]  R1170     1.3171684741973877e-01
    z[4,1,3]  R1171     3.5918179154396057e-01
    z[4,1,3]  R1172     -5.3258669376373291e-01
    z[4,1,3]  R1173     4.1792401671409607e-01
    z[4,1,3]  R1174     -9.7393877804279327e-02
    z[4,1,3]  R1175     -2.8344443440437317e-01
    z[4,1,3]  R1176     -0.271945595741272
    z[4,1,3]  R1177     -1.5372280776500702e-01
    z[4,1,3]  R1178     -1.1726742237806320e-01
    z[4,1,3]  R1179     1.5897387266159058e-01
    z[4,1,3]  R1180     5.3039681911468506e-01
    z[4,1,3]  R1181     4.7791481018066406e-01
    z[4,1,3]  R1182     4.5172640681266785e-01
    z[4,1,3]  R1183     6.5011823177337646e-01
    z[4,1,3]  R1184     6.2212830781936646e-01
    z[4,1,3]  R1185     -1.4795914292335510e-01
    z[4,1,3]  R1186     6.3086384534835815e-01
    z[4,1,3]  R1187     -2.1271225810050964e-01
    z[4,1,3]  R1188     1.8182241916656494e-01
    z[4,1,3]  R1189     4.9371698498725891e-01
    z[4,1,3]  R1190     2.0419631898403168e-01
    z[4,1,3]  R1191     -2.2921408712863922e-01
    z[4,1,3]  R1192     -2.2812442481517792e-01
    z[4,1,3]  R1193     -0.72444748878479
    z[4,1,3]  R1194     3.3810603618621826e-01
    z[4,1,3]  R1195     1.8640232086181641e-01
    z[4,1,3]  R1196     -4.8062512278556824e-01
    z[4,1,3]  R1197     -0.483710378408432
    z[4,1,3]  R1198     5.6191053241491318e-02
    z[4,1,3]  R1199     -3.6831229925155640e-01
    z[4,1,3]  R1200     1.6339768469333649e-01
    z[4,1,3]  R1201     1.0380907356739044e-01
    z[4,1,3]  R1202     1.1003208905458450e-01
    z[4,1,3]  R1203     6.5903908014297485e-01
    z[4,1,3]  R1204     -3.2897201180458069e-01
    z[4,1,3]  R1205     -1.5643297135829926e-01
    z[4,1,3]  R1206     3.9144212007522583e-01
    z[4,1,3]  R1207     -0.00906385201960802
    z[4,1,3]  R1208     -4.2518965899944305e-02
    z[4,1,3]  R1209     -4.3219098448753357e-01
    z[4,1,3]  R1210     2.7163645625114441e-01
    z[4,1,3]  R1211     2.2988820075988770e-01
    z[4,1,3]  R1212     -6.2464926391839981e-02
    z[4,1,3]  R1213     3.9827436208724976e-01
    z[4,1,3]  R1214     3.6196565628051758e-01
    z[4,1,3]  R1215     3.5333672165870667e-01
    z[4,1,3]  R1216     -2.4791575968265533e-01
    z[4,1,3]  R1217     -1.5276212990283966e-01
    z[4,1,3]  R1218     3.0615553259849548e-01
    z[4,1,3]  R1219     2.4574624840170145e-03
    z[4,1,3]  R1220     1.8979637324810028e-01
    z[4,1,3]  R1221     -1.6697503626346588e-01
    z[4,1,3]  R1222     -0.798019289970398
    z[4,1,3]  R1223     -8.2056099176406860e-01
    z[4,1,3]  R1224     4.1949599981307983e-01
    z[4,1,3]  R1225     3.7642562389373779e-01
    z[4,1,3]  R1226     2.2613757848739624e-01
    z[4,1,3]  R1227     2.8243386745452881e-01
    z[4,1,3]  R1228     0.0550660714507103
    z[4,1,3]  R1229     -3.1871774792671204e-01
    z[4,1,3]  R1230     0.0724758729338646
    z[4,1,3]  R1231     -0.0727483481168747
    z[4,1,3]  R1232     -1.5462476760149002e-02
    z[4,1,3]  R1233     -2.2073060274124146e-01
    z[4,1,3]  R1234     6.2123283743858337e-02
    z[4,1,3]  R1235     -0.424940824508667
    z[4,1,3]  R1236     -1.5746068954467773e-01
    z[4,1,3]  R1237     -4.0981835126876831e-01
    z[4,1,3]  R1238     -4.5490843057632446e-01
    z[4,1,3]  R1239     2.8890269994735718e-01
    z[4,1,3]  R1240     -3.9071059226989746e-01
    z[4,1,3]  R1241     -0.346769779920578
    z[4,1,3]  R1242     3.4356537461280823e-01
    z[4,1,3]  R1243     2.8785686939954758e-02
    z[4,1,3]  R1244     -4.6313452720642090e-01
    z[4,1,3]  R1245     -3.9203029870986938e-01
    z[4,1,3]  R1246     -6.5651428699493408e-01
    z[4,1,3]  R1247     -2.4493958055973053e-01
    z[4,1,3]  R1248     -5.6359034776687622e-01
    z[4,1,3]  R1249     -4.9433851242065430e-01
    z[4,1,3]  R1250     2.3379026353359222e-01
    z[4,1,3]  R1251     3.6727815866470337e-01
    z[4,1,3]  R1252     3.2355868816375732e-01
    z[4,1,3]  R1253     -5.8226162195205688e-01
    z[4,1,3]  R1254     -4.4555738568305969e-01
    z[4,1,3]  R1255     -0.281028687953949
    z[4,1,3]  R1256     1.4870950579643250e-01
    z[4,1,3]  R1257     -0.0558922179043293
    z[4,1,3]  R1258     1.5222573280334473e-01
    z[4,1,3]  R1259     -1.1127392202615738e-01
    z[4,1,3]  R1260     2.6698562502861023e-01
    z[4,1,3]  R1261     0.0815851241350174
    z[4,1,3]  R1262     2.0858474075794220e-01
    z[4,1,3]  R1263     2.5546187162399292e-01
    z[4,1,3]  R1264     2.7224791049957275e-01
    z[4,1,3]  R1265     -5.8066624402999878e-01
    z[4,1,3]  R1266     -2.1184456348419189e-01
    z[4,1,3]  R1267     -7.1251779794692993e-01
    z[4,1,3]  R1268     -0.0191778764128685
    z[4,1,3]  R1269     -3.0335992574691772e-01
    z[4,1,3]  R1270     2.6501855254173279e-01
    z[4,1,3]  R1271     6.0697649605572224e-03
    z[4,1,3]  R1272     1.4614929258823395e-01
    z[4,1,3]  R1273     -2.5967705994844437e-02
    z[4,1,3]  R1274     -3.8211518526077271e-01
    z[4,1,3]  R1275     -5.6091696023941040e-01
    z[4,1,3]  R1276     -9.1272346675395966e-02
    z[4,1,3]  R1277     3.3846864104270935e-01
    z[4,1,3]  R1278     3.7194166332483292e-02
    z[4,1,3]  R1279     4.0260624140501022e-02
    z[4,1,3]  R1280     -2.9305824637413025e-01
    z[4,1,3]  R1281     0.207631453871727
    z[4,1,3]  R1282     6.7774903774261475e-01
    z[4,1,3]  R1283     -6.9623276591300964e-02
    z[4,1,3]  R1284     -2.0771314203739166e-01
    z[4,1,3]  R1285     -0.00696546770632267
    z[4,1,3]  R1286     7.0355825126171112e-02
    z[4,1,3]  R1287     4.4429653882980347e-01
    z[4,1,3]  R1288     7.4754811823368073e-02
    z[4,1,3]  R1289     1.6481418907642365e-01
    z[4,1,3]  R1290     -2.6582974195480347e-01
    z[4,1,3]  R1291     8.2485699653625488e-01
    z[4,1,3]  R1292     5.0227355957031250e-01
    z[4,1,3]  R1293     1.0876694321632385e-01
    z[4,1,3]  R1294     1.2753970222547650e-03
    z[4,1,3]  R1295     8.4732629358768463e-02
    z[4,1,3]  R1296     6.2167018651962280e-01
    z[4,1,3]  R1297     5.9127581119537354e-01
    z[4,1,3]  R1298     -3.6739131808280945e-01
    z[4,1,3]  R1299     2.9516467452049255e-01
    z[4,1,3]  R1300     -1.0469325631856918e-01
    z[4,1,3]  R1301     -1.3179023563861847e-01
    z[4,1,3]  R1302     -4.7945481538772583e-01
    z[4,1,3]  R1303     5.8445721864700317e-01
    z[4,1,3]  R1304     4.0771072963252664e-04
    z[4,1,3]  R1305     0.0796792060136795
    z[4,1,3]  R1306     5.8450758457183838e-01
    z[4,1,3]  R1307     -6.9646090269088745e-01
    z[4,1,3]  R1308     3.2750996947288513e-01
    z[4,1,3]  R1309     4.2184704542160034e-01
    z[4,1,3]  R1310     -3.8457545638084412e-01
    z[4,1,3]  R1311     -3.3123109489679337e-02
    z[4,1,3]  R1312     -1.1977288126945496e-01
    z[4,1,3]  R1313     -2.5463856291025877e-03
    z[4,1,3]  R1314     2.8450268507003784e-01
    z[4,1,3]  R1315     5.8854973316192627e-01
    z[4,1,3]  R1316     -5.7986426353454590e-01
    z[4,1,3]  R1317     -2.5151500478386879e-02
    z[4,1,3]  R1318     3.2991883158683777e-01
    z[4,1,3]  R1319     6.6927188634872437e-01
    z[4,1,3]  R1320     2.9772832989692688e-01
    z[4,1,3]  R1321     6.1433595418930054e-01
    z[4,1,3]  R1322     4.2071422934532166e-01
    z[4,1,3]  R1323     -1.9240427762269974e-02
    z[4,1,3]  R1324     0.529548168182373
    z[4,1,4]  R15       1
    z[4,1,4]  R42       -1
    z[4,1,4]  R1160     -1
    z[4,1,4]  R1161     1
    z[4,1,4]  R1166     -5.9807217121124268e-01
    z[4,1,4]  R1167     -4.9848622083663940e-01
    z[4,1,4]  R1168     -6.5336924791336060e-01
    z[4,1,4]  R1169     -7.2163826227188110e-01
    z[4,1,4]  R1170     -3.5952815413475037e-01
    z[4,1,4]  R1171     -4.0824940800666809e-01
    z[4,1,4]  R1172     3.1452366709709167e-01
    z[4,1,4]  R1173     -0.684838056564331
    z[4,1,4]  R1174     -4.1711923480033875e-01
    z[4,1,4]  R1175     1.0789326392114162e-02
    z[4,1,4]  R1176     -1.2407668679952621e-01
    z[4,1,4]  R1177     -1.8454334139823914e-01
    z[4,1,4]  R1178     1.1577981710433960e-01
    z[4,1,4]  R1179     -3.2115232944488525e-01
    z[4,1,4]  R1180     -4.9837838858366013e-02
    z[4,1,4]  R1181     -3.9657387137413025e-01
    z[4,1,4]  R1182     -0.182534858584404
    z[4,1,4]  R1183     3.5078135132789612e-01
    z[4,1,4]  R1184     5.4858420044183731e-02
    z[4,1,4]  R1185     1.3900396227836609e-01
    z[4,1,4]  R1186     2.7258116006851196e-01
    z[4,1,4]  R1187     4.3921627104282379e-02
    z[4,1,4]  R1188     5.8377593755722046e-01
    z[4,1,4]  R1189     8.3564937114715576e-02
    z[4,1,4]  R1190     1.8081174790859222e-01
    z[4,1,4]  R1191     4.6877473592758179e-01
    z[4,1,4]  R1192     1.3864706456661224e-01
    z[4,1,4]  R1193     -2.5935885310173035e-01
    z[4,1,4]  R1194     -4.4898489117622375e-01
    z[4,1,4]  R1195     -2.8888520598411560e-01
    z[4,1,4]  R1196     -5.4572808742523193e-01
    z[4,1,4]  R1197     1.7076827585697174e-02
    z[4,1,4]  R1198     -0.0605459026992321
    z[4,1,4]  R1199     -8.3162176609039307e-01
    z[4,1,4]  R1200     -2.4538438022136688e-01
    z[4,1,4]  R1201     -6.3393193483352661e-01
    z[4,1,4]  R1202     -4.3460991978645325e-01
    z[4,1,4]  R1203     -4.3667531013488770e-01
    z[4,1,4]  R1204     -3.4096285700798035e-01
    z[4,1,4]  R1205     -3.3043101429939270e-01
    z[4,1,4]  R1206     -6.0014687478542328e-02
    z[4,1,4]  R1207     -4.6652728319168091e-01
    z[4,1,4]  R1208     -3.2168093323707581e-01
    z[4,1,4]  R1209     -1.8092378973960876e-01
    z[4,1,4]  R1210     1.0825133323669434e-01
    z[4,1,4]  R1211     1.2555750086903572e-02
    z[4,1,4]  R1212     3.4217610955238342e-01
    z[4,1,4]  R1213     -5.0948488712310791e-01
    z[4,1,4]  R1214     1.9620832800865173e-01
    z[4,1,4]  R1215     1.0042093694210052e-01
    z[4,1,4]  R1216     -8.4013324975967407e-01
    z[4,1,4]  R1217     4.8353976011276245e-01
    z[4,1,4]  R1218     -2.5056087970733643e-01
    z[4,1,4]  R1219     -3.0108615756034851e-01
    z[4,1,4]  R1220     -3.7153720855712891e-02
    z[4,1,4]  R1221     -2.7126485109329224e-01
    z[4,1,4]  R1222     3.7175214290618896e-01
    z[4,1,4]  R1223     2.4538248777389526e-01
    z[4,1,4]  R1224     -6.3851051032543182e-02
    z[4,1,4]  R1225     4.2370632290840149e-01
    z[4,1,4]  R1226     1.8065446987748146e-02
    z[4,1,4]  R1227     3.6739388108253479e-01
    z[4,1,4]  R1228     5.8633655309677124e-01
    z[4,1,4]  R1229     1.6537471115589142e-01
    z[4,1,4]  R1230     1.6097468137741089e-01
    z[4,1,4]  R1231     1.7848816514015198e-01
    z[4,1,4]  R1232     2.6838836073875427e-01
    z[4,1,4]  R1233     1.1645889282226562e-01
    z[4,1,4]  R1234     2.9949453473091125e-01
    z[4,1,4]  R1235     -1.5863038599491119e-01
    z[4,1,4]  R1236     -2.0651364326477051e-01
    z[4,1,4]  R1237     -3.7758240103721619e-01
    z[4,1,4]  R1238     -8.3849288523197174e-02
    z[4,1,4]  R1239     -5.0751942396163940e-01
    z[4,1,4]  R1240     -9.4126991927623749e-02
    z[4,1,4]  R1241     1.0345663875341415e-01
    z[4,1,4]  R1242     -7.7445471286773682e-01
    z[4,1,4]  R1243     -4.0884593129158020e-01
    z[4,1,4]  R1244     -5.5066245794296265e-01
    z[4,1,4]  R1245     -1.9226944446563721e-01
    z[4,1,4]  R1246     2.1234290301799774e-01
    z[4,1,4]  R1247     -2.9462394118309021e-01
    z[4,1,4]  R1248     -4.5862805843353271e-01
    z[4,1,4]  R1249     -2.9427188634872437e-01
    z[4,1,4]  R1250     0.473821222782135
    z[4,1,4]  R1251     1.7656306922435760e-01
    z[4,1,4]  R1252     0.512280285358429
    z[4,1,4]  R1253     1.8443444371223450e-01
    z[4,1,4]  R1254     6.3173137605190277e-02
    z[4,1,4]  R1255     -5.9691351652145386e-01
    z[4,1,4]  R1256     -5.0122201442718506e-01
    z[4,1,4]  R1257     -8.1298923492431641e-01
    z[4,1,4]  R1258     4.1157731413841248e-01
    z[4,1,4]  R1259     0.13089619576931
    z[4,1,4]  R1260     1.8609413504600525e-01
    z[4,1,4]  R1261     1.9791173934936523e-01
    z[4,1,4]  R1262     -2.6141893118619919e-02
    z[4,1,4]  R1263     7.1282177232205868e-03
    z[4,1,4]  R1264     -5.2257917821407318e-02
    z[4,1,4]  R1265     -3.5380131006240845e-01
    z[4,1,4]  R1266     -6.8181025981903076e-01
    z[4,1,4]  R1267     -3.4506028890609741e-01
    z[4,1,4]  R1268     -1.3816542923450470e-01
    z[4,1,4]  R1269     3.3916497230529785e-01
    z[4,1,4]  R1270     -7.2195746004581451e-02
    z[4,1,4]  R1271     9.0210400521755219e-02
    z[4,1,4]  R1272     -2.2630941867828369e-01
    z[4,1,4]  R1273     -1.1395063996315002e-01
    z[4,1,4]  R1274     2.5320026278495789e-01
    z[4,1,4]  R1275     -2.6496413350105286e-01
    z[4,1,4]  R1276     1.2268720567226410e-01
    z[4,1,4]  R1277     -0.516111433506012
    z[4,1,4]  R1278     -7.7362522482872009e-02
    z[4,1,4]  R1279     3.6041066050529480e-01
    z[4,1,4]  R1280     1.6203403472900391e-02
    z[4,1,4]  R1281     3.3967226743698120e-02
    z[4,1,4]  R1282     -4.0043359994888306e-01
    z[4,1,4]  R1283     2.4488031864166260e-01
    z[4,1,4]  R1284     -2.7999168634414673e-01
    z[4,1,4]  R1285     1.5323479473590851e-01
    z[4,1,4]  R1286     2.2334653884172440e-02
    z[4,1,4]  R1287     -1.8812276422977448e-01
    z[4,1,4]  R1288     -2.4828863143920898e-01
    z[4,1,4]  R1289     -1.6168478131294250e-01
    z[4,1,4]  R1290     -1.5106610953807831e-01
    z[4,1,4]  R1291     7.6155625283718109e-02
    z[4,1,4]  R1292     4.5021429657936096e-02
    z[4,1,4]  R1293     1.1790663003921509e-01
    z[4,1,4]  R1294     3.5410594195127487e-02
    z[4,1,4]  R1295     0.0838705375790596
    z[4,1,4]  R1296     -1.5915378928184509e-01
    z[4,1,4]  R1297     -5.2755761146545410e-01
    z[4,1,4]  R1298     -2.4036690592765808e-01
    z[4,1,4]  R1299     -5.0913745164871216e-01
    z[4,1,4]  R1300     0.000716552953235805
    z[4,1,4]  R1301     5.7074010372161865e-01
    z[4,1,4]  R1302     -1.7616911232471466e-01
    z[4,1,4]  R1303     4.8988372087478638e-02
    z[4,1,4]  R1304     3.4998711943626404e-01
    z[4,1,4]  R1305     2.0113010704517365e-01
    z[4,1,4]  R1306     -1.8414147198200226e-01
    z[4,1,4]  R1307     2.8846734762191772e-01
    z[4,1,4]  R1308     -4.8386237025260925e-01
    z[4,1,4]  R1309     -4.8561595380306244e-02
    z[4,1,4]  R1310     -2.9330602288246155e-01
    z[4,1,4]  R1311     -4.0362879633903503e-01
    z[4,1,4]  R1312     -3.4878385066986084e-01
    z[4,1,4]  R1313     -3.7716156244277954e-01
    z[4,1,4]  R1314     -3.8579076528549194e-01
    z[4,1,4]  R1315     -3.0203866958618164e-01
    z[4,1,4]  R1316     4.6352226287126541e-02
    z[4,1,4]  R1317     1.6870559751987457e-01
    z[4,1,4]  R1318     -2.5287646055221558e-01
    z[4,1,4]  R1319     -1.5198273956775665e-01
    z[4,1,4]  R1320     -2.8569018840789795e-01
    z[4,1,4]  R1321     -1.9161500036716461e-01
    z[4,1,4]  R1322     -2.7352344989776611e-01
    z[4,1,4]  R1323     -2.6284396648406982e-01
    z[4,1,4]  R1324     -1.8524785339832306e-01
    z[4,1,5]  R16       1
    z[4,1,5]  R43       -1
    z[4,1,5]  R1162     -1
    z[4,1,5]  R1163     1
    z[4,1,5]  R1166     2.7588501572608948e-01
    z[4,1,5]  R1167     0.0768398642539978
    z[4,1,5]  R1168     4.8011988401412964e-01
    z[4,1,5]  R1169     4.0588292479515076e-01
    z[4,1,5]  R1170     5.3919738531112671e-01
    z[4,1,5]  R1171     3.0846032500267029e-01
    z[4,1,5]  R1172     -1.7066171392798424e-02
    z[4,1,5]  R1173     4.3200677633285522e-01
    z[4,1,5]  R1174     7.2658412158489227e-02
    z[4,1,5]  R1175     3.8039374351501465e-01
    z[4,1,5]  R1176     1.8794685602188110e-01
    z[4,1,5]  R1177     3.1153056025505066e-01
    z[4,1,5]  R1178     3.4912928938865662e-02
    z[4,1,5]  R1179     1.9149954617023468e-01
    z[4,1,5]  R1180     -4.0843873284757137e-03
    z[4,1,5]  R1181     2.9163593053817749e-01
    z[4,1,5]  R1182     5.9292250871658325e-01
    z[4,1,5]  R1183     3.4390920400619507e-01
    z[4,1,5]  R1184     2.2979740798473358e-01
    z[4,1,5]  R1185     2.3302505910396576e-01
    z[4,1,5]  R1186     8.0706931650638580e-02
    z[4,1,5]  R1187     -5.3153578191995621e-02
    z[4,1,5]  R1188     -1.1309825628995895e-01
    z[4,1,5]  R1189     -2.2733679413795471e-01
    z[4,1,5]  R1190     5.2110069990158081e-01
    z[4,1,5]  R1191     2.2259102761745453e-01
    z[4,1,5]  R1192     4.0817445516586304e-01
    z[4,1,5]  R1193     1.9557489454746246e-01
    z[4,1,5]  R1194     -2.4819038808345795e-01
    z[4,1,5]  R1195     1.9170695543289185e-01
    z[4,1,5]  R1196     3.0538302659988403e-01
    z[4,1,5]  R1197     5.1258746534585953e-02
    z[4,1,5]  R1198     4.7907531261444092e-01
    z[4,1,5]  R1199     -0.314779132604599
    z[4,1,5]  R1200     9.0232640504837036e-01
    z[4,1,5]  R1201     1.3097949326038361e-01
    z[4,1,5]  R1202     -5.8001402765512466e-02
    z[4,1,5]  R1203     3.7141764163970947e-01
    z[4,1,5]  R1204     1.2606818974018097e-01
    z[4,1,5]  R1205     -1.2264557927846909e-01
    z[4,1,5]  R1206     1.4420942962169647e-01
    z[4,1,5]  R1207     -2.9039919376373291e-01
    z[4,1,5]  R1208     1.4926192164421082e-01
    z[4,1,5]  R1209     -0.0517929382622242
    z[4,1,5]  R1210     -0.0381213054060936
    z[4,1,5]  R1211     1.5846368670463562e-01
    z[4,1,5]  R1212     1.2515859305858612e-01
    z[4,1,5]  R1213     3.9180997014045715e-01
    z[4,1,5]  R1214     -1.6171494126319885e-01
    z[4,1,5]  R1215     -8.8415652513504028e-02
    z[4,1,5]  R1216     -3.2338467240333557e-01
    z[4,1,5]  R1217     1.0416987538337708e-01
    z[4,1,5]  R1218     -1.7621999979019165e-01
    z[4,1,5]  R1219     -3.2661595940589905e-01
    z[4,1,5]  R1220     -4.2096513509750366e-01
    z[4,1,5]  R1221     -4.1891392320394516e-02
    z[4,1,5]  R1222     -1.3399402797222137e-01
    z[4,1,5]  R1223     -1.3040751218795776e-01
    z[4,1,5]  R1224     -0.0849934071302414
    z[4,1,5]  R1225     -1.0683242231607437e-02
    z[4,1,5]  R1226     4.4384026527404785e-01
    z[4,1,5]  R1227     5.6114387512207031e-01
    z[4,1,5]  R1228     2.2153569757938385e-01
    z[4,1,5]  R1229     0.0785888135433197
    z[4,1,5]  R1230     -2.0154097676277161e-01
    z[4,1,5]  R1231     -1.4973272383213043e-01
    z[4,1,5]  R1232     -2.0013237372040749e-02
    z[4,1,5]  R1233     1.4452475309371948e-01
    z[4,1,5]  R1234     1.1037625372409821e-01
    z[4,1,5]  R1235     1.5011714398860931e-01
    z[4,1,5]  R1236     1.9484703242778778e-01
    z[4,1,5]  R1237     4.0779468417167664e-01
    z[4,1,5]  R1238     -3.6305990815162659e-01
    z[4,1,5]  R1239     -1.8814601004123688e-01
    z[4,1,5]  R1240     2.2578341886401176e-02
    z[4,1,5]  R1241     4.0209281444549561e-01
    z[4,1,5]  R1242     -2.2305153310298920e-01
    z[4,1,5]  R1243     -3.4657639265060425e-01
    z[4,1,5]  R1244     1.3650451600551605e-01
    z[4,1,5]  R1245     -1.4910818636417389e-01
    z[4,1,5]  R1246     -5.7941582053899765e-02
    z[4,1,5]  R1247     -4.3500947952270508e-01
    z[4,1,5]  R1248     1.2846945226192474e-01
    z[4,1,5]  R1249     -1.9584308564662933e-01
    z[4,1,5]  R1250     5.0724223256111145e-03
    z[4,1,5]  R1251     -3.4511899948120117e-01
    z[4,1,5]  R1252     -5.1498431712388992e-03
    z[4,1,5]  R1253     4.2048788070678711e-01
    z[4,1,5]  R1254     -0.248139888048172
    z[4,1,5]  R1255     -2.2326861321926117e-01
    z[4,1,5]  R1256     -1.4089688658714294e-01
    z[4,1,5]  R1257     -3.5816648602485657e-01
    z[4,1,5]  R1258     -1.9831705838441849e-02
    z[4,1,5]  R1259     -2.8302398324012756e-01
    z[4,1,5]  R1260     -2.6607608795166016e-01
    z[4,1,5]  R1261     -9.3816900625824928e-03
    z[4,1,5]  R1262     -0.00913193728774786
    z[4,1,5]  R1263     -3.4307509660720825e-01
    z[4,1,5]  R1264     1.3647709786891937e-01
    z[4,1,5]  R1265     2.2741788998246193e-02
    z[4,1,5]  R1266     4.9062767624855042e-01
    z[4,1,5]  R1267     4.5953061431646347e-02
    z[4,1,5]  R1268     -1.4729671180248260e-01
    z[4,1,5]  R1269     -2.3401673138141632e-01
    z[4,1,5]  R1270     4.9856898188591003e-01
    z[4,1,5]  R1271     2.8222987055778503e-01
    z[4,1,5]  R1272     -9.2234506155364215e-05
    z[4,1,5]  R1273     -2.2545018792152405e-01
    z[4,1,5]  R1274     4.0567898750305176e-01
    z[4,1,5]  R1275     -1.1036479473114014e-01
    z[4,1,5]  R1276     2.5438693165779114e-01
    z[4,1,5]  R1277     -1.0560341179370880e-01
    z[4,1,5]  R1278     4.6336323022842407e-01
    z[4,1,5]  R1279     4.7741317749023438e-01
    z[4,1,5]  R1280     -5.3843200206756592e-01
    z[4,1,5]  R1281     -2.3436771705746651e-02
    z[4,1,5]  R1282     3.7715956568717957e-01
    z[4,1,5]  R1283     -0.510245680809021
    z[4,1,5]  R1284     1.1509119719266891e-01
    z[4,1,5]  R1285     -6.6956095397472382e-02
    z[4,1,5]  R1286     4.1354256868362427e-01
    z[4,1,5]  R1287     -0.234359011054039
    z[4,1,5]  R1288     1.6112641990184784e-01
    z[4,1,5]  R1289     1.0046856850385666e-01
    z[4,1,5]  R1290     1.0830528289079666e-01
    z[4,1,5]  R1291     1.3350382447242737e-01
    z[4,1,5]  R1292     8.2315705716609955e-02
    z[4,1,5]  R1293     4.7807514667510986e-02
    z[4,1,5]  R1294     -1.8564681708812714e-01
    z[4,1,5]  R1295     3.8254481554031372e-01
    z[4,1,5]  R1296     4.2950016260147095e-01
    z[4,1,5]  R1297     4.4323410838842392e-02
    z[4,1,5]  R1298     -3.0888348817825317e-01
    z[4,1,5]  R1299     -1.7003257572650909e-01
    z[4,1,5]  R1300     -2.1060745418071747e-01
    z[4,1,5]  R1301     -2.8826245665550232e-01
    z[4,1,5]  R1302     -3.1406667828559875e-01
    z[4,1,5]  R1303     -4.2162844538688660e-01
    z[4,1,5]  R1304     -2.5881221890449524e-01
    z[4,1,5]  R1305     3.3505931496620178e-01
    z[4,1,5]  R1306     4.9329307675361633e-01
    z[4,1,5]  R1307     1.1204126477241516e-01
    z[4,1,5]  R1308     2.9471702873706818e-03
    z[4,1,5]  R1309     5.1336448639631271e-02
    z[4,1,5]  R1310     -1.6353687644004822e-01
    z[4,1,5]  R1311     -3.7536349147558212e-02
    z[4,1,5]  R1312     -4.7130686044692993e-01
    z[4,1,5]  R1313     1.5334385633468628e-01
    z[4,1,5]  R1314     -2.6177048683166504e-02
    z[4,1,5]  R1315     5.0096571445465088e-01
    z[4,1,5]  R1316     -2.0492132753133774e-02
    z[4,1,5]  R1317     2.4650931358337402e-01
    z[4,1,5]  R1318     3.1349015235900879e-01
    z[4,1,5]  R1319     -1.9713032990694046e-02
    z[4,1,5]  R1320     3.5099261999130249e-01
    z[4,1,5]  R1321     1.7596293985843658e-01
    z[4,1,5]  R1322     0.315409392118454
    z[4,1,5]  R1323     -4.4421949982643127e-01
    z[4,1,5]  R1324     8.2742515951395035e-03
    z[4,1,6]  R17       1
    z[4,1,6]  R44       -1
    z[4,1,6]  R1164     -1
    z[4,1,6]  R1165     1
    z[4,1,6]  R1166     -3.2459592819213867e-01
    z[4,1,6]  R1167     4.8325583338737488e-02
    z[4,1,6]  R1168     -3.5433974117040634e-02
    z[4,1,6]  R1169     4.1947695612907410e-01
    z[4,1,6]  R1170     9.6513405442237854e-02
    z[4,1,6]  R1171     2.2284905612468719e-01
    z[4,1,6]  R1172     -2.0006555318832397e-01
    z[4,1,6]  R1173     2.1568414568901062e-01
    z[4,1,6]  R1174     5.8561146259307861e-01
    z[4,1,6]  R1175     2.5013424456119537e-03
    z[4,1,6]  R1176     1.3021971285343170e-01
    z[4,1,6]  R1177     -2.3854376375675201e-01
    z[4,1,6]  R1178     -1.7075374722480774e-01
    z[4,1,6]  R1179     1.8598724901676178e-01
    z[4,1,6]  R1180     2.5466856360435486e-01
    z[4,1,6]  R1181     -4.8353332281112671e-01
    z[4,1,6]  R1182     -3.5868138074874878e-01
    z[4,1,6]  R1183     -3.9329206943511963e-01
    z[4,1,6]  R1184     -2.2811383008956909e-01
    z[4,1,6]  R1185     6.4580667018890381e-01
    z[4,1,6]  R1186     -1.5585084259510040e-01
    z[4,1,6]  R1187     -4.4793391227722168e-01
    z[4,1,6]  R1188     -1.7386395484209061e-02
    z[4,1,6]  R1189     -1.2443863600492477e-01
    z[4,1,6]  R1190     4.2697262018918991e-02
    z[4,1,6]  R1191     -2.4199962615966797e-02
    z[4,1,6]  R1192     2.6031273603439331e-01
    z[4,1,6]  R1193     1.9470381736755371e-01
    z[4,1,6]  R1194     2.6132947206497192e-01
    z[4,1,6]  R1195     -0.398084819316864
    z[4,1,6]  R1196     2.4788361787796021e-01
    z[4,1,6]  R1197     3.4689265489578247e-01
    z[4,1,6]  R1198     -1.6337784007191658e-02
    z[4,1,6]  R1199     -8.7756089866161346e-02
    z[4,1,6]  R1200     -7.9994276165962219e-03
    z[4,1,6]  R1201     4.4153681397438049e-01
    z[4,1,6]  R1202     -2.6913493871688843e-01
    z[4,1,6]  R1203     -1.4677749946713448e-02
    z[4,1,6]  R1204     -3.1525948643684387e-01
    z[4,1,6]  R1205     1.6807551681995392e-01
    z[4,1,6]  R1206     4.3010881543159485e-01
    z[4,1,6]  R1207     -1.3056711852550507e-01
    z[4,1,6]  R1208     -1.6935016214847565e-01
    z[4,1,6]  R1209     2.6247268915176392e-01
    z[4,1,6]  R1210     -2.4118547141551971e-01
    z[4,1,6]  R1211     -6.1556601524353027e-01
    z[4,1,6]  R1212     7.9690247774124146e-02
    z[4,1,6]  R1213     -2.6254606246948242e-01
    z[4,1,6]  R1214     -1.0532230883836746e-01
    z[4,1,6]  R1215     5.4940257221460342e-02
    z[4,1,6]  R1216     6.6073901951313019e-02
    z[4,1,6]  R1217     2.3335088789463043e-01
    z[4,1,6]  R1218     1.4274649322032928e-01
    z[4,1,6]  R1219     2.8746458888053894e-01
    z[4,1,6]  R1220     -6.6539153456687927e-02
    z[4,1,6]  R1221     1.5067237615585327e-01
    z[4,1,6]  R1222     -1.2331873923540115e-01
    z[4,1,6]  R1223     -1.6254171729087830e-01
    z[4,1,6]  R1224     -5.4477435350418091e-01
    z[4,1,6]  R1225     1.6781672835350037e-01
    z[4,1,6]  R1226     1.5728285908699036e-01
    z[4,1,6]  R1227     -0.212831050157547
    z[4,1,6]  R1228     1.1290422827005386e-01
    z[4,1,6]  R1229     -2.0314763486385345e-01
    z[4,1,6]  R1230     -2.0503292977809906e-01
    z[4,1,6]  R1231     -2.0527285337448120e-01
    z[4,1,6]  R1232     7.4418224394321442e-02
    z[4,1,6]  R1233     -5.1902536302804947e-02
    z[4,1,6]  R1234     1.1466937512159348e-01
    z[4,1,6]  R1235     -3.8242095708847046e-01
    z[4,1,6]  R1236     -0.123700812458992
    z[4,1,6]  R1237     4.4131819158792496e-02
    z[4,1,6]  R1238     2.0914927124977112e-01
    z[4,1,6]  R1239     -1.5266370773315430e-01
    z[4,1,6]  R1240     4.7503036260604858e-01
    z[4,1,6]  R1241     -2.6302579045295715e-01
    z[4,1,6]  R1242     -1.5337653458118439e-01
    z[4,1,6]  R1243     3.7807431817054749e-01
    z[4,1,6]  R1244     2.7391368150711060e-01
    z[4,1,6]  R1245     2.6329910382628441e-02
    z[4,1,6]  R1246     7.0679372549057007e-01
    z[4,1,6]  R1247     4.6605333685874939e-02
    z[4,1,6]  R1248     -3.4513169527053833e-01
    z[4,1,6]  R1249     5.8406114578247070e-01
    z[4,1,6]  R1250     -1.3775852508842945e-02
    z[4,1,6]  R1251     -1.3469657301902771e-01
    z[4,1,6]  R1252     6.3891232013702393e-02
    z[4,1,6]  R1253     2.4693049490451813e-01
    z[4,1,6]  R1254     2.5733673572540283e-01
    z[4,1,6]  R1255     5.1083713769912720e-01
    z[4,1,6]  R1256     4.4374740123748779e-01
    z[4,1,6]  R1257     1.5302394330501556e-01
    z[4,1,6]  R1258     -1.9526831805706024e-01
    z[4,1,6]  R1259     -2.2403992712497711e-01
    z[4,1,6]  R1260     -2.3340111970901489e-01
    z[4,1,6]  R1261     4.2828115820884705e-01
    z[4,1,6]  R1262     2.6880177855491638e-01
    z[4,1,6]  R1263     2.2382782399654388e-01
    z[4,1,6]  R1264     3.6712527275085449e-01
    z[4,1,6]  R1265     4.4752866029739380e-01
    z[4,1,6]  R1266     1.1494905501604080e-01
    z[4,1,6]  R1267     1.8742652237415314e-01
    z[4,1,6]  R1268     -2.2395202517509460e-01
    z[4,1,6]  R1269     2.3580574989318848e-01
    z[4,1,6]  R1270     1.2304235994815826e-01
    z[4,1,6]  R1271     2.9824849218130112e-02
    z[4,1,6]  R1272     2.2685025632381439e-01
    z[4,1,6]  R1273     -9.2453166842460632e-02
    z[4,1,6]  R1274     5.9650313109159470e-02
    z[4,1,6]  R1275     0.196893572807312
    z[4,1,6]  R1276     -1.2163080275058746e-01
    z[4,1,6]  R1277     -5.5359661579132080e-01
    z[4,1,6]  R1278     0.301082581281662
    z[4,1,6]  R1279     1.8784141540527344e-01
    z[4,1,6]  R1280     2.5613343715667725e-01
    z[4,1,6]  R1281     -1.7376577854156494e-01
    z[4,1,6]  R1282     1.1973126232624054e-01
    z[4,1,6]  R1283     1.3432615995407104e-01
    z[4,1,6]  R1284     1.5900996327400208e-01
    z[4,1,6]  R1285     8.2109540700912476e-02
    z[4,1,6]  R1286     3.1177085638046265e-01
    z[4,1,6]  R1287     9.5916397869586945e-02
    z[4,1,6]  R1288     -1.2706008553504944e-01
    z[4,1,6]  R1289     -3.4822601079940796e-01
    z[4,1,6]  R1290     1.3286796212196350e-01
    z[4,1,6]  R1291     -2.3847262561321259e-01
    z[4,1,6]  R1292     -7.5521886348724365e-02
    z[4,1,6]  R1293     4.7048706561326981e-02
    z[4,1,6]  R1294     -9.0640291571617126e-02
    z[4,1,6]  R1295     2.1592923998832703e-01
    z[4,1,6]  R1296     9.9643588066101074e-02
    z[4,1,6]  R1297     -1.5728241205215454e-01
    z[4,1,6]  R1298     1.2270531058311462e-01
    z[4,1,6]  R1299     -2.2878400981426239e-01
    z[4,1,6]  R1300     2.3199106752872467e-01
    z[4,1,6]  R1301     -0.0837583988904953
    z[4,1,6]  R1302     -1.3407164812088013e-01
    z[4,1,6]  R1303     1.3882575929164886e-01
    z[4,1,6]  R1304     -5.1358896493911743e-01
    z[4,1,6]  R1305     2.2299818694591522e-01
    z[4,1,6]  R1306     1.8443956971168518e-01
    z[4,1,6]  R1307     -6.9723889231681824e-02
    z[4,1,6]  R1308     -1.9082710146903992e-01
    z[4,1,6]  R1309     -6.0413774102926254e-02
    z[4,1,6]  R1310     -1.6859705746173859e-01
    z[4,1,6]  R1311     8.4657423198223114e-02
    z[4,1,6]  R1312     -2.8084853291511536e-01
    z[4,1,6]  R1313     -1.8471510848030448e-03
    z[4,1,6]  R1314     -5.2542369812726974e-03
    z[4,1,6]  R1315     1.1301857233047485e-01
    z[4,1,6]  R1316     1.4101485908031464e-01
    z[4,1,6]  R1317     -2.0797398686408997e-01
    z[4,1,6]  R1318     -1.3379167020320892e-01
    z[4,1,6]  R1319     -2.0895868539810181e-02
    z[4,1,6]  R1320     -5.8076906949281693e-02
    z[4,1,6]  R1321     5.0957348197698593e-02
    z[4,1,6]  R1322     1.7451328039169312e-01
    z[4,1,6]  R1323     3.5186418890953064e-01
    z[4,1,6]  R1324     -2.1904313564300537e-01
    z[2,3,0]  R20       -1
    z[2,3,0]  R29       1
    z[2,3,0]  R1325     -1
    z[2,3,0]  R1326     1
    z[2,3,0]  R1339     -5.9558898210525513e-02
    z[2,3,0]  R1340     1.8688710033893585e-01
    z[2,3,0]  R1341     4.0684661269187927e-01
    z[2,3,0]  R1342     5.0825828313827515e-01
    z[2,3,0]  R1343     3.8950565457344055e-01
    z[2,3,0]  R1344     3.7066829204559326e-01
    z[2,3,0]  R1345     1.5516020357608795e-01
    z[2,3,0]  R1346     4.5007619261741638e-01
    z[2,3,0]  R1347     3.0709198117256165e-01
    z[2,3,0]  R1348     -8.9899547398090363e-02
    z[2,3,0]  R1349     -5.0068795680999756e-01
    z[2,3,0]  R1350     -1.9401873648166656e-01
    z[2,3,0]  R1351     -5.2254962921142578e-01
    z[2,3,0]  R1352     -2.0976625382900238e-01
    z[2,3,0]  R1353     -3.5914450883865356e-01
    z[2,3,0]  R1354     -2.2353176772594452e-01
    z[2,3,0]  R1355     -2.3866747319698334e-01
    z[2,3,0]  R1356     -5.8838635683059692e-01
    z[2,3,0]  R1357     -2.8149381279945374e-01
    z[2,3,0]  R1358     -5.7092517614364624e-01
    z[2,3,0]  R1359     0.227547287940979
    z[2,3,0]  R1360     5.5791920423507690e-01
    z[2,3,0]  R1361     4.3100666999816895e-01
    z[2,3,0]  R1362     1.3391035795211792e-01
    z[2,3,0]  R1363     2.1070216596126556e-01
    z[2,3,0]  R1364     2.3706804215908051e-01
    z[2,3,0]  R1365     -3.3032408356666565e-01
    z[2,3,0]  R1366     -5.0689097493886948e-02
    z[2,3,0]  R1367     9.3185283243656158e-02
    z[2,3,0]  R1368     -3.8340926170349121e-01
    z[2,3,0]  R1369     -3.6293300986289978e-01
    z[2,3,0]  R1370     -1.4409963786602020e-01
    z[2,3,0]  R1371     -2.8153423219919205e-02
    z[2,3,0]  R1372     -1.4287948608398438e-01
    z[2,3,0]  R1373     5.0730270147323608e-01
    z[2,3,0]  R1374     6.8103051185607910e-01
    z[2,3,0]  R1375     3.9166036248207092e-01
    z[2,3,0]  R1376     -4.2965531349182129e-01
    z[2,3,0]  R1377     2.3904596269130707e-01
    z[2,3,0]  R1378     6.1169892549514771e-01
    z[2,3,0]  R1379     -0.323994904756546
    z[2,3,0]  R1380     -0.660135805606842
    z[2,3,0]  R1381     -5.5857664346694946e-01
    z[2,3,0]  R1382     -6.2961035966873169e-01
    z[2,3,0]  R1383     3.1452909111976624e-02
    z[2,3,0]  R1384     7.4064075946807861e-01
    z[2,3,0]  R1385     -1.7483724653720856e-01
    z[2,3,0]  R1386     -1.1822493746876717e-02
    z[2,3,0]  R1387     1.3173650205135345e-01
    z[2,3,0]  R1388     -2.4004104733467102e-01
    z[2,3,0]  R1389     3.2079127430915833e-01
    z[2,3,0]  R1390     0.62704998254776
    z[2,3,0]  R1391     -4.3412479758262634e-01
    z[2,3,0]  R1392     -4.8567795753479004e-01
    z[2,3,0]  R1393     3.8553151488304138e-01
    z[2,3,0]  R1394     2.3259313404560089e-01
    z[2,3,0]  R1395     -4.1952177882194519e-01
    z[2,3,0]  R1396     7.0278279483318329e-02
    z[2,3,0]  R1397     -1.0878144204616547e-01
    z[2,3,0]  R1398     -2.0737315714359283e-01
    z[2,3,0]  R1399     -1.4528167247772217e-01
    z[2,3,0]  R1400     -3.0842933058738708e-01
    z[2,3,0]  R1401     -5.4398483037948608e-01
    z[2,3,0]  R1402     -4.3852820992469788e-01
    z[2,3,1]  R21       -1
    z[2,3,1]  R30       1
    z[2,3,1]  R1327     -1
    z[2,3,1]  R1328     1
    z[2,3,1]  R1339     -5.9290248155593872e-01
    z[2,3,1]  R1340     -7.2246640920639038e-01
    z[2,3,1]  R1341     -5.1898014545440674e-01
    z[2,3,1]  R1342     -5.0235044956207275e-01
    z[2,3,1]  R1343     -4.0276399254798889e-01
    z[2,3,1]  R1344     -7.1195507049560547e-01
    z[2,3,1]  R1345     -5.4251879453659058e-01
    z[2,3,1]  R1346     -4.0479367971420288e-01
    z[2,3,1]  R1347     -8.8276928663253784e-01
    z[2,3,1]  R1348     -5.2685809135437012e-01
    z[2,3,1]  R1349     7.9778659343719482e-01
    z[2,3,1]  R1350     8.5822361707687378e-01
    z[2,3,1]  R1351     0.57748943567276
    z[2,3,1]  R1352     7.6454418897628784e-01
    z[2,3,1]  R1353     6.0351091623306274e-01
    z[2,3,1]  R1354     6.7756199836730957e-01
    z[2,3,1]  R1355     7.5941306352615356e-01
    z[2,3,1]  R1356     4.8605209589004517e-01
    z[2,3,1]  R1357     6.8820118904113770e-01
    z[2,3,1]  R1358     4.4714894890785217e-01
    z[2,3,1]  R1359     -1.3957631587982178e-01
    z[2,3,1]  R1360     1.5866938233375549e-01
    z[2,3,1]  R1361     8.7374888360500336e-02
    z[2,3,1]  R1362     -5.2000995725393295e-02
    z[2,3,1]  R1363     -7.3202508687973022e-01
    z[2,3,1]  R1364     -8.9609622955322266e-01
    z[2,3,1]  R1365     -8.7818670272827148e-01
    z[2,3,1]  R1366     -6.6387432813644409e-01
    z[2,3,1]  R1367     -6.4120382070541382e-01
    z[2,3,1]  R1368     4.5675918459892273e-01
    z[2,3,1]  R1369     3.6966803669929504e-01
    z[2,3,1]  R1370     4.6123948693275452e-01
    z[2,3,1]  R1371     4.6623924374580383e-01
    z[2,3,1]  R1372     0.478381484746933
    z[2,3,1]  R1373     -1.7955128848552704e-01
    z[2,3,1]  R1374     -3.4282706677913666e-02
    z[2,3,1]  R1375     -5.4561026394367218e-02
    z[2,3,1]  R1376     7.4065822362899780e-01
    z[2,3,1]  R1377     8.4010857343673706e-01
    z[2,3,1]  R1378     6.7208075523376465e-01
    z[2,3,1]  R1379     1.6775736585259438e-02
    z[2,3,1]  R1380     2.0863661170005798e-01
    z[2,3,1]  R1381     -1.2913960963487625e-02
    z[2,3,1]  R1382     0.288901686668396
    z[2,3,1]  R1383     -4.1288891434669495e-01
    z[2,3,1]  R1384     -4.0469425916671753e-01
    z[2,3,1]  R1385     8.2116818428039551e-01
    z[2,3,1]  R1386     7.7963519096374512e-01
    z[2,3,1]  R1387     7.3115426301956177e-01
    z[2,3,1]  R1388     9.0361751616001129e-02
    z[2,3,1]  R1389     -2.7667286992073059e-01
    z[2,3,1]  R1390     0.628728449344635
    z[2,3,1]  R1391     -4.3045710772275925e-02
    z[2,3,1]  R1392     -2.8077220544219017e-02
    z[2,3,1]  R1393     -2.6363173127174377e-01
    z[2,3,1]  R1394     7.4782872200012207e-01
    z[2,3,1]  R1395     4.1568708419799805e-01
    z[2,3,1]  R1396     -5.7474941015243530e-02
    z[2,3,1]  R1397     3.9827597141265869e-01
    z[2,3,1]  R1398     -1.1768517643213272e-01
    z[2,3,1]  R1399     -3.6511268466711044e-02
    z[2,3,1]  R1400     2.0624291151762009e-02
    z[2,3,1]  R1401     1.7866080999374390e-01
    z[2,3,1]  R1402     1.8642188608646393e-01
    z[2,3,2]  R22       -1
    z[2,3,2]  R31       1
    z[2,3,2]  R1329     -1
    z[2,3,2]  R1330     1
    z[2,3,2]  R1339     3.5933580994606018e-01
    z[2,3,2]  R1340     -3.1633205711841583e-02
    z[2,3,2]  R1341     1.9013518467545509e-02
    z[2,3,2]  R1342     2.0099420845508575e-01
    z[2,3,2]  R1343     5.9181636571884155e-01
    z[2,3,2]  R1344     4.8591491580009460e-01
    z[2,3,2]  R1345     1.9740661978721619e-01
    z[2,3,2]  R1346     3.8579389452934265e-01
    z[2,3,2]  R1347     -7.7522508800029755e-02
    z[2,3,2]  R1348     7.4727272987365723e-01
    z[2,3,2]  R1349     -1.2009497731924057e-01
    z[2,3,2]  R1350     7.6472632586956024e-02
    z[2,3,2]  R1351     3.2745766639709473e-01
    z[2,3,2]  R1352     1.8415714800357819e-01
    z[2,3,2]  R1353     -1.2678658962249756e-01
    z[2,3,2]  R1354     -4.4335469603538513e-01
    z[2,3,2]  R1355     4.9939689040184021e-01
    z[2,3,2]  R1356     -1.5145042538642883e-01
    z[2,3,2]  R1357     9.8478108644485474e-02
    z[2,3,2]  R1358     -5.7115167379379272e-02
    z[2,3,2]  R1359     -5.1285862922668457e-01
    z[2,3,2]  R1360     -0.381136029958725
    z[2,3,2]  R1361     -5.9377545118331909e-01
    z[2,3,2]  R1362     -0.43329918384552
    z[2,3,2]  R1363     6.1484199762344360e-01
    z[2,3,2]  R1364     -2.5353688001632690e-01
    z[2,3,2]  R1365     4.6989362686872482e-02
    z[2,3,2]  R1366     9.8646752536296844e-02
    z[2,3,2]  R1367     -0.305441290140152
    z[2,3,2]  R1368     -6.2570393085479736e-01
    z[2,3,2]  R1369     -6.9680237770080566e-01
    z[2,3,2]  R1370     -6.4595109224319458e-01
    z[2,3,2]  R1371     -6.7250245809555054e-01
    z[2,3,2]  R1372     -5.6332510709762573e-01
    z[2,3,2]  R1373     -4.0046057105064392e-01
    z[2,3,2]  R1374     4.2531597428023815e-03
    z[2,3,2]  R1375     1.0870019346475601e-01
    z[2,3,2]  R1376     -2.6488453149795532e-01
    z[2,3,2]  R1377     2.9680223669856787e-03
    z[2,3,2]  R1378     -4.3982964009046555e-02
    z[2,3,2]  R1379     3.6153453588485718e-01
    z[2,3,2]  R1380     5.5275034904479980e-01
    z[2,3,2]  R1381     4.6292573213577271e-01
    z[2,3,2]  R1382     5.3264069557189941e-01
    z[2,3,2]  R1383     2.2463642060756683e-01
    z[2,3,2]  R1384     -1.6830703616142273e-01
    z[2,3,2]  R1385     -3.9099535346031189e-01
    z[2,3,2]  R1386     -3.8344052433967590e-01
    z[2,3,2]  R1387     -2.6987469196319580e-01
    z[2,3,2]  R1388     -0.394153892993927
    z[2,3,2]  R1389     -5.5422164499759674e-02
    z[2,3,2]  R1390     -4.2012721300125122e-01
    z[2,3,2]  R1391     4.4082674384117126e-01
    z[2,3,2]  R1392     3.8484206795692444e-01
    z[2,3,2]  R1393     -2.6140862703323364e-01
    z[2,3,2]  R1394     -4.0695735812187195e-01
    z[2,3,2]  R1395     -5.0352096557617188e-01
    z[2,3,2]  R1396     1.1228688061237335e-01
    z[2,3,2]  R1397     -6.3518583774566650e-01
    z[2,3,2]  R1398     3.1060567498207092e-01
    z[2,3,2]  R1399     2.3794180154800415e-01
    z[2,3,2]  R1400     3.5464078187942505e-01
    z[2,3,2]  R1401     5.6184995174407959e-01
    z[2,3,2]  R1402     0.663927435874939
    z[2,3,3]  R23       -1
    z[2,3,3]  R32       1
    z[2,3,3]  R1331     -1
    z[2,3,3]  R1332     1
    z[2,3,3]  R1339     -4.1641983389854431e-01
    z[2,3,3]  R1340     -0.581412672996521
    z[2,3,3]  R1341     -3.9674839377403259e-01
    z[2,3,3]  R1342     -2.2573718428611755e-01
    z[2,3,3]  R1343     0.151409313082695
    z[2,3,3]  R1344     1.7278465628623962e-01
    z[2,3,3]  R1345     -2.1413658559322357e-01
    z[2,3,3]  R1346     1.2555651366710663e-01
    z[2,3,3]  R1347     1.1373896151781082e-01
    z[2,3,3]  R1348     -2.2943688556551933e-02
    z[2,3,3]  R1349     9.0139739215373993e-02
    z[2,3,3]  R1350     8.0782070755958557e-02
    z[2,3,3]  R1351     4.3264187872409821e-02
    z[2,3,3]  R1352     2.2799910511821508e-03
    z[2,3,3]  R1353     -3.0812883377075195e-01
    z[2,3,3]  R1354     -0.0792752057313919
    z[2,3,3]  R1355     7.7979043126106262e-02
    z[2,3,3]  R1356     -2.6251441240310669e-01
    z[2,3,3]  R1357     -4.3058654665946960e-01
    z[2,3,3]  R1358     -6.4221984148025513e-01
    z[2,3,3]  R1359     6.5747827291488647e-01
    z[2,3,3]  R1360     6.9999152421951294e-01
    z[2,3,3]  R1361     5.6981217861175537e-01
    z[2,3,3]  R1362     2.0941333472728729e-01
    z[2,3,3]  R1363     3.5248868167400360e-02
    z[2,3,3]  R1364     3.2933041453361511e-02
    z[2,3,3]  R1365     -1.3289515674114227e-01
    z[2,3,3]  R1366     6.1468955129384995e-02
    z[2,3,3]  R1367     -4.1365999728441238e-02
    z[2,3,3]  R1368     -1.0824655741453171e-01
    z[2,3,3]  R1369     2.5173410773277283e-01
    z[2,3,3]  R1370     0.491875022649765
    z[2,3,3]  R1371     -2.2320429980754852e-01
    z[2,3,3]  R1372     0.630195677280426
    z[2,3,3]  R1373     -3.8113251328468323e-01
    z[2,3,3]  R1374     -7.2333496809005737e-01
    z[2,3,3]  R1375     -2.1607159078121185e-01
    z[2,3,3]  R1376     4.6063192188739777e-02
    z[2,3,3]  R1377     1.5683244168758392e-01
    z[2,3,3]  R1378     2.8763899207115173e-01
    z[2,3,3]  R1379     -5.9141445159912109e-01
    z[2,3,3]  R1380     -3.6886084079742432e-01
    z[2,3,3]  R1381     -3.8016214966773987e-01
    z[2,3,3]  R1382     -3.9001065492630005e-01
    z[2,3,3]  R1383     -0.0961623340845108
    z[2,3,3]  R1384     -2.6174640655517578e-01
    z[2,3,3]  R1385     3.2039511948823929e-02
    z[2,3,3]  R1386     1.8101747334003448e-01
    z[2,3,3]  R1387     7.0701591670513153e-02
    z[2,3,3]  R1388     6.4919614791870117e-01
    z[2,3,3]  R1389     1.1243601888418198e-01
    z[2,3,3]  R1390     1.3497139513492584e-01
    z[2,3,3]  R1391     -5.8058238029479980e-01
    z[2,3,3]  R1392     -6.8739497661590576e-01
    z[2,3,3]  R1393     -2.4818925559520721e-01
    z[2,3,3]  R1394     3.9486980438232422e-01
    z[2,3,3]  R1395     1.2522846460342407e-01
    z[2,3,3]  R1396     -4.3856918811798096e-01
    z[2,3,3]  R1397     -1.0970503836870193e-01
    z[2,3,3]  R1398     -8.2041013240814209e-01
    z[2,3,3]  R1399     -8.6618643999099731e-01
    z[2,3,3]  R1400     -6.7323404550552368e-01
    z[2,3,3]  R1401     -5.3538322448730469e-01
    z[2,3,3]  R1402     -4.3027156591415405e-01
    z[2,3,4]  R24       -1
    z[2,3,4]  R33       1
    z[2,3,4]  R1333     -1
    z[2,3,4]  R1334     1
    z[2,3,4]  R1339     -1.1001219972968102e-03
    z[2,3,4]  R1340     2.8186461329460144e-01
    z[2,3,4]  R1341     5.1787173748016357e-01
    z[2,3,4]  R1342     3.3614826202392578e-01
    z[2,3,4]  R1343     4.3787100911140442e-01
    z[2,3,4]  R1344     -9.2299081385135651e-02
    z[2,3,4]  R1345     4.5325309038162231e-01
    z[2,3,4]  R1346     1.7119120061397552e-01
    z[2,3,4]  R1347     -0.172170028090477
    z[2,3,4]  R1348     1.5981712937355042e-01
    z[2,3,4]  R1349     -9.1165617108345032e-02
    z[2,3,4]  R1350     3.1064444780349731e-01
    z[2,3,4]  R1351     -4.0164259076118469e-01
    z[2,3,4]  R1352     -0.0375276580452919
    z[2,3,4]  R1353     -2.1597084403038025e-01
    z[2,3,4]  R1354     -2.6986721158027649e-01
    z[2,3,4]  R1355     2.0343777537345886e-01
    z[2,3,4]  R1356     -4.7412395477294922e-01
    z[2,3,4]  R1357     2.9025465250015259e-01
    z[2,3,4]  R1358     4.0439318865537643e-02
    z[2,3,4]  R1359     3.3689764142036438e-01
    z[2,3,4]  R1360     5.4812509566545486e-02
    z[2,3,4]  R1361     3.5733726620674133e-01
    z[2,3,4]  R1362     -3.7407171726226807e-01
    z[2,3,4]  R1363     1.4900505542755127e-01
    z[2,3,4]  R1364     7.7285328879952431e-03
    z[2,3,4]  R1365     1.2747122347354889e-01
    z[2,3,4]  R1366     9.0370260179042816e-02
    z[2,3,4]  R1367     -1.8519116938114166e-01
    z[2,3,4]  R1368     4.5506274700164795e-01
    z[2,3,4]  R1369     2.1257656812667847e-01
    z[2,3,4]  R1370     1.7690427601337433e-01
    z[2,3,4]  R1371     4.7693067789077759e-01
    z[2,3,4]  R1372     5.3212434053421021e-02
    z[2,3,4]  R1373     4.0723349899053574e-02
    z[2,3,4]  R1374     7.6723806560039520e-02
    z[2,3,4]  R1375     -7.9503792524337769e-01
    z[2,3,4]  R1376     -4.2350319027900696e-01
    z[2,3,4]  R1377     -2.5479269027709961e-01
    z[2,3,4]  R1378     1.5232549607753754e-01
    z[2,3,4]  R1379     -4.6420025825500488e-01
    z[2,3,4]  R1380     -1.8094724416732788e-01
    z[2,3,4]  R1381     -4.8501467704772949e-01
    z[2,3,4]  R1382     1.4656354486942291e-01
    z[2,3,4]  R1383     -8.4032607078552246e-01
    z[2,3,4]  R1384     -2.1480195224285126e-01
    z[2,3,4]  R1385     -3.5190707445144653e-01
    z[2,3,4]  R1386     -5.5060088634490967e-02
    z[2,3,4]  R1387     3.3071920275688171e-01
    z[2,3,4]  R1388     4.6353048086166382e-01
    z[2,3,4]  R1389     1.7799116671085358e-01
    z[2,3,4]  R1390     1.0846702754497528e-01
    z[2,3,4]  R1391     -2.7862530946731567e-01
    z[2,3,4]  R1392     1.7154007218778133e-03
    z[2,3,4]  R1393     4.6138694882392883e-01
    z[2,3,4]  R1394     1.9123828411102295e-01
    z[2,3,4]  R1395     5.6625676155090332e-01
    z[2,3,4]  R1396     6.7100734449923038e-03
    z[2,3,4]  R1397     -3.0774167180061340e-01
    z[2,3,4]  R1398     -3.5249975323677063e-01
    z[2,3,4]  R1399     -4.7529861330986023e-02
    z[2,3,4]  R1400     -1.0738659650087357e-01
    z[2,3,4]  R1401     2.4396489560604095e-01
    z[2,3,4]  R1402     8.7059317156672478e-03
    z[2,3,5]  R25       -1
    z[2,3,5]  R34       1
    z[2,3,5]  R1335     -1
    z[2,3,5]  R1336     1
    z[2,3,5]  R1339     5.8147519826889038e-01
    z[2,3,5]  R1340     -1.3164943456649780e-01
    z[2,3,5]  R1341     0.369782954454422
    z[2,3,5]  R1342     -1.2190397083759308e-01
    z[2,3,5]  R1343     3.2342159748077393e-01
    z[2,3,5]  R1344     -5.2841216325759888e-02
    z[2,3,5]  R1345     3.4322327375411987e-01
    z[2,3,5]  R1346     6.2322318553924561e-01
    z[2,3,5]  R1347     8.4276765584945679e-02
    z[2,3,5]  R1348     -5.3143654018640518e-02
    z[2,3,5]  R1349     1.3258161488920450e-03
    z[2,3,5]  R1350     3.2388001680374146e-01
    z[2,3,5]  R1351     -8.1217736005783081e-02
    z[2,3,5]  R1352     -1.0150302201509476e-01
    z[2,3,5]  R1353     2.2486111521720886e-01
    z[2,3,5]  R1354     2.5098431110382080e-01
    z[2,3,5]  R1355     -5.9654969722032547e-02
    z[2,3,5]  R1356     -4.1578780859708786e-02
    z[2,3,5]  R1357     7.0019364356994629e-02
    z[2,3,5]  R1358     -0.144505113363266
    z[2,3,5]  R1359     8.7805442512035370e-02
    z[2,3,5]  R1360     6.7401833832263947e-02
    z[2,3,5]  R1361     -0.0353923924267292
    z[2,3,5]  R1362     -7.2828090190887451e-01
    z[2,3,5]  R1363     4.8109255731105804e-03
    z[2,3,5]  R1364     0.0659482404589653
    z[2,3,5]  R1365     4.9900867044925690e-02
    z[2,3,5]  R1366     7.3024815320968628e-01
    z[2,3,5]  R1367     5.9566396474838257e-01
    z[2,3,5]  R1368     1.7350588738918304e-01
    z[2,3,5]  R1369     3.6055192351341248e-01
    z[2,3,5]  R1370     2.2199960052967072e-01
    z[2,3,5]  R1371     8.2227960228919983e-02
    z[2,3,5]  R1372     -9.9870055913925171e-02
    z[2,3,5]  R1373     -4.5442107319831848e-01
    z[2,3,5]  R1374     -5.0220921635627747e-02
    z[2,3,5]  R1375     -3.7199845910072327e-01
    z[2,3,5]  R1376     -0.0775558203458786
    z[2,3,5]  R1377     -2.3853132128715515e-01
    z[2,3,5]  R1378     -6.6592812538146973e-02
    z[2,3,5]  R1379     3.8669112324714661e-01
    z[2,3,5]  R1380     1.0121560655534267e-02
    z[2,3,5]  R1381     -1.6500715911388397e-01
    z[2,3,5]  R1382     2.4496668577194214e-01
    z[2,3,5]  R1383     -2.4761931598186493e-01
    z[2,3,5]  R1384     3.2741222530603409e-02
    z[2,3,5]  R1385     1.2170637398958206e-01
    z[2,3,5]  R1386     -4.5652562379837036e-01
    z[2,3,5]  R1387     -4.9590140581130981e-01
    z[2,3,5]  R1388     -3.4327471256256104e-01
    z[2,3,5]  R1389     -0.851716935634613
    z[2,3,5]  R1390     -5.0868522375822067e-02
    z[2,3,5]  R1391     4.1360217332839966e-01
    z[2,3,5]  R1392     2.5672644376754761e-01
    z[2,3,5]  R1393     -5.8026784658432007e-01
    z[2,3,5]  R1394     -1.6099371016025543e-01
    z[2,3,5]  R1395     -2.3186303675174713e-01
    z[2,3,5]  R1396     -7.6824903488159180e-01
    z[2,3,5]  R1397     -4.3951433897018433e-01
    z[2,3,5]  R1398     2.1920882165431976e-01
    z[2,3,5]  R1399     3.8463580608367920e-01
    z[2,3,5]  R1400     -5.5725741386413574e-01
    z[2,3,5]  R1401     -3.1448632478713989e-02
    z[2,3,5]  R1402     3.2223203778266907e-01
    z[2,3,6]  R26       -1
    z[2,3,6]  R35       1
    z[2,3,6]  R1337     -1
    z[2,3,6]  R1338     1
    z[2,3,6]  R1339     -6.5398856997489929e-02
    z[2,3,6]  R1340     -8.5410483181476593e-02
    z[2,3,6]  R1341     -4.9335431307554245e-02
    z[2,3,6]  R1342     -5.1971656084060669e-01
    z[2,3,6]  R1343     1.2869545817375183e-01
    z[2,3,6]  R1344     -2.8008174896240234e-01
    z[2,3,6]  R1345     0.523004949092865
    z[2,3,6]  R1346     -2.2640366852283478e-01
    z[2,3,6]  R1347     2.6593515276908875e-01
    z[2,3,6]  R1348     3.5641238093376160e-01
    z[2,3,6]  R1349     2.8633415699005127e-01
    z[2,3,6]  R1350     1.0971251875162125e-01
    z[2,3,6]  R1351     -3.4122490882873535e-01
    z[2,3,6]  R1352     -5.7082408666610718e-01
    z[2,3,6]  R1353     -5.4641157388687134e-01
    z[2,3,6]  R1354     -3.9022284746170044e-01
    z[2,3,6]  R1355     -2.5672206282615662e-01
    z[2,3,6]  R1356     -3.1493085622787476e-01
    z[2,3,6]  R1357     -4.0359282493591309e-01
    z[2,3,6]  R1358     -1.8941122293472290e-01
    z[2,3,6]  R1359     -3.3500626683235168e-01
    z[2,3,6]  R1360     1.4404852688312531e-01
    z[2,3,6]  R1361     -2.0026246085762978e-02
    z[2,3,6]  R1362     -2.7827879786491394e-01
    z[2,3,6]  R1363     1.3507449626922607e-01
    z[2,3,6]  R1364     2.6652544736862183e-01
    z[2,3,6]  R1365     -2.8472086787223816e-01
    z[2,3,6]  R1366     4.1985213756561279e-02
    z[2,3,6]  R1367     -3.0993112921714783e-01
    z[2,3,6]  R1368     6.2922559678554535e-02
    z[2,3,6]  R1369     -8.6804866790771484e-02
    z[2,3,6]  R1370     1.6346450150012970e-01
    z[2,3,6]  R1371     -2.1336419880390167e-01
    z[2,3,6]  R1372     -1.5313178300857544e-01
    z[2,3,6]  R1373     -4.4341591000556946e-01
    z[2,3,6]  R1374     -5.8153618127107620e-02
    z[2,3,6]  R1375     -1.2105491012334824e-01
    z[2,3,6]  R1376     9.5740392804145813e-02
    z[2,3,6]  R1377     3.0108624696731567e-01
    z[2,3,6]  R1378     2.4864296615123749e-01
    z[2,3,6]  R1379     2.2193619608879089e-01
    z[2,3,6]  R1380     2.1507178246974945e-01
    z[2,3,6]  R1381     2.5794410705566406e-01
    z[2,3,6]  R1382     5.3128913044929504e-02
    z[2,3,6]  R1383     3.6897215992212296e-02
    z[2,3,6]  R1384     -3.7897691130638123e-01
    z[2,3,6]  R1385     5.0594788044691086e-02
    z[2,3,6]  R1386     2.8071720153093338e-02
    z[2,3,6]  R1387     1.2220699340105057e-01
    z[2,3,6]  R1388     -1.5717579424381256e-01
    z[2,3,6]  R1389     -2.1846961975097656e-01
    z[2,3,6]  R1390     -4.9315180629491806e-02
    z[2,3,6]  R1391     1.7198757827281952e-01
    z[2,3,6]  R1392     2.7713131904602051e-01
    z[2,3,6]  R1393     -3.1991052627563477e-01
    z[2,3,6]  R1394     5.1235571503639221e-02
    z[2,3,6]  R1395     -8.7080515921115875e-02
    z[2,3,6]  R1396     4.4334483146667480e-01
    z[2,3,6]  R1397     -3.5520243644714355e-01
    z[2,3,6]  R1398     -3.5905953496694565e-02
    z[2,3,6]  R1399     1.4304243028163910e-01
    z[2,3,6]  R1400     5.8000016957521439e-02
    z[2,3,6]  R1401     -9.6655987203121185e-02
    z[2,3,6]  R1402     -2.0759889483451843e-01
    z[3,2,0]  R20       1
    z[3,2,0]  R29       -1
    z[3,2,0]  R1403     -1
    z[3,2,0]  R1404     1
    z[3,2,0]  R1417     2.1070216596126556e-01
    z[3,2,0]  R1418     2.3706804215908051e-01
    z[3,2,0]  R1419     -3.3032408356666565e-01
    z[3,2,0]  R1420     -5.0689097493886948e-02
    z[3,2,0]  R1421     9.3185283243656158e-02
    z[3,2,0]  R1422     -3.8340926170349121e-01
    z[3,2,0]  R1423     -3.6293300986289978e-01
    z[3,2,0]  R1424     -1.4409963786602020e-01
    z[3,2,0]  R1425     -2.8153423219919205e-02
    z[3,2,0]  R1426     -1.4287948608398438e-01
    z[3,2,0]  R1427     5.0730270147323608e-01
    z[3,2,0]  R1428     6.8103051185607910e-01
    z[3,2,0]  R1429     3.9166036248207092e-01
    z[3,2,0]  R1430     -4.2965531349182129e-01
    z[3,2,0]  R1431     2.3904596269130707e-01
    z[3,2,0]  R1432     6.1169892549514771e-01
    z[3,2,0]  R1433     -0.323994904756546
    z[3,2,0]  R1434     -0.660135805606842
    z[3,2,0]  R1435     -5.5857664346694946e-01
    z[3,2,0]  R1436     -6.2961035966873169e-01
    z[3,2,0]  R1437     3.1452909111976624e-02
    z[3,2,0]  R1438     7.4064075946807861e-01
    z[3,2,0]  R1439     -1.7483724653720856e-01
    z[3,2,0]  R1440     -1.1822493746876717e-02
    z[3,2,0]  R1441     1.3173650205135345e-01
    z[3,2,0]  R1442     -2.4004104733467102e-01
    z[3,2,0]  R1443     3.2079127430915833e-01
    z[3,2,0]  R1444     0.62704998254776
    z[3,2,0]  R1445     -4.3412479758262634e-01
    z[3,2,0]  R1446     -4.8567795753479004e-01
    z[3,2,0]  R1447     3.8553151488304138e-01
    z[3,2,0]  R1448     2.3259313404560089e-01
    z[3,2,0]  R1449     -4.1952177882194519e-01
    z[3,2,0]  R1450     7.0278279483318329e-02
    z[3,2,0]  R1451     -1.0878144204616547e-01
    z[3,2,0]  R1452     -2.0737315714359283e-01
    z[3,2,0]  R1453     -1.4528167247772217e-01
    z[3,2,0]  R1454     -3.0842933058738708e-01
    z[3,2,0]  R1455     -5.4398483037948608e-01
    z[3,2,0]  R1456     -4.3852820992469788e-01
    z[3,2,0]  R1457     -5.9558898210525513e-02
    z[3,2,0]  R1458     1.8688710033893585e-01
    z[3,2,0]  R1459     4.0684661269187927e-01
    z[3,2,0]  R1460     5.0825828313827515e-01
    z[3,2,0]  R1461     3.8950565457344055e-01
    z[3,2,0]  R1462     3.7066829204559326e-01
    z[3,2,0]  R1463     1.5516020357608795e-01
    z[3,2,0]  R1464     4.5007619261741638e-01
    z[3,2,0]  R1465     3.0709198117256165e-01
    z[3,2,0]  R1466     -8.9899547398090363e-02
    z[3,2,0]  R1467     -5.0068795680999756e-01
    z[3,2,0]  R1468     -1.9401873648166656e-01
    z[3,2,0]  R1469     -5.2254962921142578e-01
    z[3,2,0]  R1470     -2.0976625382900238e-01
    z[3,2,0]  R1471     -3.5914450883865356e-01
    z[3,2,0]  R1472     -2.2353176772594452e-01
    z[3,2,0]  R1473     -2.3866747319698334e-01
    z[3,2,0]  R1474     -5.8838635683059692e-01
    z[3,2,0]  R1475     -2.8149381279945374e-01
    z[3,2,0]  R1476     -5.7092517614364624e-01
    z[3,2,0]  R1477     0.227547287940979
    z[3,2,0]  R1478     5.5791920423507690e-01
    z[3,2,0]  R1479     4.3100666999816895e-01
    z[3,2,0]  R1480     1.3391035795211792e-01
    z[3,2,1]  R21       1
    z[3,2,1]  R30       -1
    z[3,2,1]  R1405     -1
    z[3,2,1]  R1406     1
    z[3,2,1]  R1417     -7.3202508687973022e-01
    z[3,2,1]  R1418     -8.9609622955322266e-01
    z[3,2,1]  R1419     -8.7818670272827148e-01
    z[3,2,1]  R1420     -6.6387432813644409e-01
    z[3,2,1]  R1421     -6.4120382070541382e-01
    z[3,2,1]  R1422     4.5675918459892273e-01
    z[3,2,1]  R1423     3.6966803669929504e-01
    z[3,2,1]  R1424     4.6123948693275452e-01
    z[3,2,1]  R1425     4.6623924374580383e-01
    z[3,2,1]  R1426     0.478381484746933
    z[3,2,1]  R1427     -1.7955128848552704e-01
    z[3,2,1]  R1428     -3.4282706677913666e-02
    z[3,2,1]  R1429     -5.4561026394367218e-02
    z[3,2,1]  R1430     7.4065822362899780e-01
    z[3,2,1]  R1431     8.4010857343673706e-01
    z[3,2,1]  R1432     6.7208075523376465e-01
    z[3,2,1]  R1433     1.6775736585259438e-02
    z[3,2,1]  R1434     2.0863661170005798e-01
    z[3,2,1]  R1435     -1.2913960963487625e-02
    z[3,2,1]  R1436     0.288901686668396
    z[3,2,1]  R1437     -4.1288891434669495e-01
    z[3,2,1]  R1438     -4.0469425916671753e-01
    z[3,2,1]  R1439     8.2116818428039551e-01
    z[3,2,1]  R1440     7.7963519096374512e-01
    z[3,2,1]  R1441     7.3115426301956177e-01
    z[3,2,1]  R1442     9.0361751616001129e-02
    z[3,2,1]  R1443     -2.7667286992073059e-01
    z[3,2,1]  R1444     0.628728449344635
    z[3,2,1]  R1445     -4.3045710772275925e-02
    z[3,2,1]  R1446     -2.8077220544219017e-02
    z[3,2,1]  R1447     -2.6363173127174377e-01
    z[3,2,1]  R1448     7.4782872200012207e-01
    z[3,2,1]  R1449     4.1568708419799805e-01
    z[3,2,1]  R1450     -5.7474941015243530e-02
    z[3,2,1]  R1451     3.9827597141265869e-01
    z[3,2,1]  R1452     -1.1768517643213272e-01
    z[3,2,1]  R1453     -3.6511268466711044e-02
    z[3,2,1]  R1454     2.0624291151762009e-02
    z[3,2,1]  R1455     1.7866080999374390e-01
    z[3,2,1]  R1456     1.8642188608646393e-01
    z[3,2,1]  R1457     -5.9290248155593872e-01
    z[3,2,1]  R1458     -7.2246640920639038e-01
    z[3,2,1]  R1459     -5.1898014545440674e-01
    z[3,2,1]  R1460     -5.0235044956207275e-01
    z[3,2,1]  R1461     -4.0276399254798889e-01
    z[3,2,1]  R1462     -7.1195507049560547e-01
    z[3,2,1]  R1463     -5.4251879453659058e-01
    z[3,2,1]  R1464     -4.0479367971420288e-01
    z[3,2,1]  R1465     -8.8276928663253784e-01
    z[3,2,1]  R1466     -5.2685809135437012e-01
    z[3,2,1]  R1467     7.9778659343719482e-01
    z[3,2,1]  R1468     8.5822361707687378e-01
    z[3,2,1]  R1469     0.57748943567276
    z[3,2,1]  R1470     7.6454418897628784e-01
    z[3,2,1]  R1471     6.0351091623306274e-01
    z[3,2,1]  R1472     6.7756199836730957e-01
    z[3,2,1]  R1473     7.5941306352615356e-01
    z[3,2,1]  R1474     4.8605209589004517e-01
    z[3,2,1]  R1475     6.8820118904113770e-01
    z[3,2,1]  R1476     4.4714894890785217e-01
    z[3,2,1]  R1477     -1.3957631587982178e-01
    z[3,2,1]  R1478     1.5866938233375549e-01
    z[3,2,1]  R1479     8.7374888360500336e-02
    z[3,2,1]  R1480     -5.2000995725393295e-02
    z[3,2,2]  R22       1
    z[3,2,2]  R31       -1
    z[3,2,2]  R1407     -1
    z[3,2,2]  R1408     1
    z[3,2,2]  R1417     6.1484199762344360e-01
    z[3,2,2]  R1418     -2.5353688001632690e-01
    z[3,2,2]  R1419     4.6989362686872482e-02
    z[3,2,2]  R1420     9.8646752536296844e-02
    z[3,2,2]  R1421     -0.305441290140152
    z[3,2,2]  R1422     -6.2570393085479736e-01
    z[3,2,2]  R1423     -6.9680237770080566e-01
    z[3,2,2]  R1424     -6.4595109224319458e-01
    z[3,2,2]  R1425     -6.7250245809555054e-01
    z[3,2,2]  R1426     -5.6332510709762573e-01
    z[3,2,2]  R1427     -4.0046057105064392e-01
    z[3,2,2]  R1428     4.2531597428023815e-03
    z[3,2,2]  R1429     1.0870019346475601e-01
    z[3,2,2]  R1430     -2.6488453149795532e-01
    z[3,2,2]  R1431     2.9680223669856787e-03
    z[3,2,2]  R1432     -4.3982964009046555e-02
    z[3,2,2]  R1433     3.6153453588485718e-01
    z[3,2,2]  R1434     5.5275034904479980e-01
    z[3,2,2]  R1435     4.6292573213577271e-01
    z[3,2,2]  R1436     5.3264069557189941e-01
    z[3,2,2]  R1437     2.2463642060756683e-01
    z[3,2,2]  R1438     -1.6830703616142273e-01
    z[3,2,2]  R1439     -3.9099535346031189e-01
    z[3,2,2]  R1440     -3.8344052433967590e-01
    z[3,2,2]  R1441     -2.6987469196319580e-01
    z[3,2,2]  R1442     -0.394153892993927
    z[3,2,2]  R1443     -5.5422164499759674e-02
    z[3,2,2]  R1444     -4.2012721300125122e-01
    z[3,2,2]  R1445     4.4082674384117126e-01
    z[3,2,2]  R1446     3.8484206795692444e-01
    z[3,2,2]  R1447     -2.6140862703323364e-01
    z[3,2,2]  R1448     -4.0695735812187195e-01
    z[3,2,2]  R1449     -5.0352096557617188e-01
    z[3,2,2]  R1450     1.1228688061237335e-01
    z[3,2,2]  R1451     -6.3518583774566650e-01
    z[3,2,2]  R1452     3.1060567498207092e-01
    z[3,2,2]  R1453     2.3794180154800415e-01
    z[3,2,2]  R1454     3.5464078187942505e-01
    z[3,2,2]  R1455     5.6184995174407959e-01
    z[3,2,2]  R1456     0.663927435874939
    z[3,2,2]  R1457     3.5933580994606018e-01
    z[3,2,2]  R1458     -3.1633205711841583e-02
    z[3,2,2]  R1459     1.9013518467545509e-02
    z[3,2,2]  R1460     2.0099420845508575e-01
    z[3,2,2]  R1461     5.9181636571884155e-01
    z[3,2,2]  R1462     4.8591491580009460e-01
    z[3,2,2]  R1463     1.9740661978721619e-01
    z[3,2,2]  R1464     3.8579389452934265e-01
    z[3,2,2]  R1465     -7.7522508800029755e-02
    z[3,2,2]  R1466     7.4727272987365723e-01
    z[3,2,2]  R1467     -1.2009497731924057e-01
    z[3,2,2]  R1468     7.6472632586956024e-02
    z[3,2,2]  R1469     3.2745766639709473e-01
    z[3,2,2]  R1470     1.8415714800357819e-01
    z[3,2,2]  R1471     -1.2678658962249756e-01
    z[3,2,2]  R1472     -4.4335469603538513e-01
    z[3,2,2]  R1473     4.9939689040184021e-01
    z[3,2,2]  R1474     -1.5145042538642883e-01
    z[3,2,2]  R1475     9.8478108644485474e-02
    z[3,2,2]  R1476     -5.7115167379379272e-02
    z[3,2,2]  R1477     -5.1285862922668457e-01
    z[3,2,2]  R1478     -0.381136029958725
    z[3,2,2]  R1479     -5.9377545118331909e-01
    z[3,2,2]  R1480     -0.43329918384552
    z[3,2,3]  R23       1
    z[3,2,3]  R32       -1
    z[3,2,3]  R1409     -1
    z[3,2,3]  R1410     1
    z[3,2,3]  R1417     3.5248868167400360e-02
    z[3,2,3]  R1418     3.2933041453361511e-02
    z[3,2,3]  R1419     -1.3289515674114227e-01
    z[3,2,3]  R1420     6.1468955129384995e-02
    z[3,2,3]  R1421     -4.1365999728441238e-02
    z[3,2,3]  R1422     -1.0824655741453171e-01
    z[3,2,3]  R1423     2.5173410773277283e-01
    z[3,2,3]  R1424     0.491875022649765
    z[3,2,3]  R1425     -2.2320429980754852e-01
    z[3,2,3]  R1426     0.630195677280426
    z[3,2,3]  R1427     -3.8113251328468323e-01
    z[3,2,3]  R1428     -7.2333496809005737e-01
    z[3,2,3]  R1429     -2.1607159078121185e-01
    z[3,2,3]  R1430     4.6063192188739777e-02
    z[3,2,3]  R1431     1.5683244168758392e-01
    z[3,2,3]  R1432     2.8763899207115173e-01
    z[3,2,3]  R1433     -5.9141445159912109e-01
    z[3,2,3]  R1434     -3.6886084079742432e-01
    z[3,2,3]  R1435     -3.8016214966773987e-01
    z[3,2,3]  R1436     -3.9001065492630005e-01
    z[3,2,3]  R1437     -0.0961623340845108
    z[3,2,3]  R1438     -2.6174640655517578e-01
    z[3,2,3]  R1439     3.2039511948823929e-02
    z[3,2,3]  R1440     1.8101747334003448e-01
    z[3,2,3]  R1441     7.0701591670513153e-02
    z[3,2,3]  R1442     6.4919614791870117e-01
    z[3,2,3]  R1443     1.1243601888418198e-01
    z[3,2,3]  R1444     1.3497139513492584e-01
    z[3,2,3]  R1445     -5.8058238029479980e-01
    z[3,2,3]  R1446     -6.8739497661590576e-01
    z[3,2,3]  R1447     -2.4818925559520721e-01
    z[3,2,3]  R1448     3.9486980438232422e-01
    z[3,2,3]  R1449     1.2522846460342407e-01
    z[3,2,3]  R1450     -4.3856918811798096e-01
    z[3,2,3]  R1451     -1.0970503836870193e-01
    z[3,2,3]  R1452     -8.2041013240814209e-01
    z[3,2,3]  R1453     -8.6618643999099731e-01
    z[3,2,3]  R1454     -6.7323404550552368e-01
    z[3,2,3]  R1455     -5.3538322448730469e-01
    z[3,2,3]  R1456     -4.3027156591415405e-01
    z[3,2,3]  R1457     -4.1641983389854431e-01
    z[3,2,3]  R1458     -0.581412672996521
    z[3,2,3]  R1459     -3.9674839377403259e-01
    z[3,2,3]  R1460     -2.2573718428611755e-01
    z[3,2,3]  R1461     0.151409313082695
    z[3,2,3]  R1462     1.7278465628623962e-01
    z[3,2,3]  R1463     -2.1413658559322357e-01
    z[3,2,3]  R1464     1.2555651366710663e-01
    z[3,2,3]  R1465     1.1373896151781082e-01
    z[3,2,3]  R1466     -2.2943688556551933e-02
    z[3,2,3]  R1467     9.0139739215373993e-02
    z[3,2,3]  R1468     8.0782070755958557e-02
    z[3,2,3]  R1469     4.3264187872409821e-02
    z[3,2,3]  R1470     2.2799910511821508e-03
    z[3,2,3]  R1471     -3.0812883377075195e-01
    z[3,2,3]  R1472     -0.0792752057313919
    z[3,2,3]  R1473     7.7979043126106262e-02
    z[3,2,3]  R1474     -2.6251441240310669e-01
    z[3,2,3]  R1475     -4.3058654665946960e-01
    z[3,2,3]  R1476     -6.4221984148025513e-01
    z[3,2,3]  R1477     6.5747827291488647e-01
    z[3,2,3]  R1478     6.9999152421951294e-01
    z[3,2,3]  R1479     5.6981217861175537e-01
    z[3,2,3]  R1480     2.0941333472728729e-01
    z[3,2,4]  R24       1
    z[3,2,4]  R33       -1
    z[3,2,4]  R1411     -1
    z[3,2,4]  R1412     1
    z[3,2,4]  R1417     1.4900505542755127e-01
    z[3,2,4]  R1418     7.7285328879952431e-03
    z[3,2,4]  R1419     1.2747122347354889e-01
    z[3,2,4]  R1420     9.0370260179042816e-02
    z[3,2,4]  R1421     -1.8519116938114166e-01
    z[3,2,4]  R1422     4.5506274700164795e-01
    z[3,2,4]  R1423     2.1257656812667847e-01
    z[3,2,4]  R1424     1.7690427601337433e-01
    z[3,2,4]  R1425     4.7693067789077759e-01
    z[3,2,4]  R1426     5.3212434053421021e-02
    z[3,2,4]  R1427     4.0723349899053574e-02
    z[3,2,4]  R1428     7.6723806560039520e-02
    z[3,2,4]  R1429     -7.9503792524337769e-01
    z[3,2,4]  R1430     -4.2350319027900696e-01
    z[3,2,4]  R1431     -2.5479269027709961e-01
    z[3,2,4]  R1432     1.5232549607753754e-01
    z[3,2,4]  R1433     -4.6420025825500488e-01
    z[3,2,4]  R1434     -1.8094724416732788e-01
    z[3,2,4]  R1435     -4.8501467704772949e-01
    z[3,2,4]  R1436     1.4656354486942291e-01
    z[3,2,4]  R1437     -8.4032607078552246e-01
    z[3,2,4]  R1438     -2.1480195224285126e-01
    z[3,2,4]  R1439     -3.5190707445144653e-01
    z[3,2,4]  R1440     -5.5060088634490967e-02
    z[3,2,4]  R1441     3.3071920275688171e-01
    z[3,2,4]  R1442     4.6353048086166382e-01
    z[3,2,4]  R1443     1.7799116671085358e-01
    z[3,2,4]  R1444     1.0846702754497528e-01
    z[3,2,4]  R1445     -2.7862530946731567e-01
    z[3,2,4]  R1446     1.7154007218778133e-03
    z[3,2,4]  R1447     4.6138694882392883e-01
    z[3,2,4]  R1448     1.9123828411102295e-01
    z[3,2,4]  R1449     5.6625676155090332e-01
    z[3,2,4]  R1450     6.7100734449923038e-03
    z[3,2,4]  R1451     -3.0774167180061340e-01
    z[3,2,4]  R1452     -3.5249975323677063e-01
    z[3,2,4]  R1453     -4.7529861330986023e-02
    z[3,2,4]  R1454     -1.0738659650087357e-01
    z[3,2,4]  R1455     2.4396489560604095e-01
    z[3,2,4]  R1456     8.7059317156672478e-03
    z[3,2,4]  R1457     -1.1001219972968102e-03
    z[3,2,4]  R1458     2.8186461329460144e-01
    z[3,2,4]  R1459     5.1787173748016357e-01
    z[3,2,4]  R1460     3.3614826202392578e-01
    z[3,2,4]  R1461     4.3787100911140442e-01
    z[3,2,4]  R1462     -9.2299081385135651e-02
    z[3,2,4]  R1463     4.5325309038162231e-01
    z[3,2,4]  R1464     1.7119120061397552e-01
    z[3,2,4]  R1465     -0.172170028090477
    z[3,2,4]  R1466     1.5981712937355042e-01
    z[3,2,4]  R1467     -9.1165617108345032e-02
    z[3,2,4]  R1468     3.1064444780349731e-01
    z[3,2,4]  R1469     -4.0164259076118469e-01
    z[3,2,4]  R1470     -0.0375276580452919
    z[3,2,4]  R1471     -2.1597084403038025e-01
    z[3,2,4]  R1472     -2.6986721158027649e-01
    z[3,2,4]  R1473     2.0343777537345886e-01
    z[3,2,4]  R1474     -4.7412395477294922e-01
    z[3,2,4]  R1475     2.9025465250015259e-01
    z[3,2,4]  R1476     4.0439318865537643e-02
    z[3,2,4]  R1477     3.3689764142036438e-01
    z[3,2,4]  R1478     5.4812509566545486e-02
    z[3,2,4]  R1479     3.5733726620674133e-01
    z[3,2,4]  R1480     -3.7407171726226807e-01
    z[3,2,5]  R25       1
    z[3,2,5]  R34       -1
    z[3,2,5]  R1413     -1
    z[3,2,5]  R1414     1
    z[3,2,5]  R1417     4.8109255731105804e-03
    z[3,2,5]  R1418     0.0659482404589653
    z[3,2,5]  R1419     4.9900867044925690e-02
    z[3,2,5]  R1420     7.3024815320968628e-01
    z[3,2,5]  R1421     5.9566396474838257e-01
    z[3,2,5]  R1422     1.7350588738918304e-01
    z[3,2,5]  R1423     3.6055192351341248e-01
    z[3,2,5]  R1424     2.2199960052967072e-01
    z[3,2,5]  R1425     8.2227960228919983e-02
    z[3,2,5]  R1426     -9.9870055913925171e-02
    z[3,2,5]  R1427     -4.5442107319831848e-01
    z[3,2,5]  R1428     -5.0220921635627747e-02
    z[3,2,5]  R1429     -3.7199845910072327e-01
    z[3,2,5]  R1430     -0.0775558203458786
    z[3,2,5]  R1431     -2.3853132128715515e-01
    z[3,2,5]  R1432     -6.6592812538146973e-02
    z[3,2,5]  R1433     3.8669112324714661e-01
    z[3,2,5]  R1434     1.0121560655534267e-02
    z[3,2,5]  R1435     -1.6500715911388397e-01
    z[3,2,5]  R1436     2.4496668577194214e-01
    z[3,2,5]  R1437     -2.4761931598186493e-01
    z[3,2,5]  R1438     3.2741222530603409e-02
    z[3,2,5]  R1439     1.2170637398958206e-01
    z[3,2,5]  R1440     -4.5652562379837036e-01
    z[3,2,5]  R1441     -4.9590140581130981e-01
    z[3,2,5]  R1442     -3.4327471256256104e-01
    z[3,2,5]  R1443     -0.851716935634613
    z[3,2,5]  R1444     -5.0868522375822067e-02
    z[3,2,5]  R1445     4.1360217332839966e-01
    z[3,2,5]  R1446     2.5672644376754761e-01
    z[3,2,5]  R1447     -5.8026784658432007e-01
    z[3,2,5]  R1448     -1.6099371016025543e-01
    z[3,2,5]  R1449     -2.3186303675174713e-01
    z[3,2,5]  R1450     -7.6824903488159180e-01
    z[3,2,5]  R1451     -4.3951433897018433e-01
    z[3,2,5]  R1452     2.1920882165431976e-01
    z[3,2,5]  R1453     3.8463580608367920e-01
    z[3,2,5]  R1454     -5.5725741386413574e-01
    z[3,2,5]  R1455     -3.1448632478713989e-02
    z[3,2,5]  R1456     3.2223203778266907e-01
    z[3,2,5]  R1457     5.8147519826889038e-01
    z[3,2,5]  R1458     -1.3164943456649780e-01
    z[3,2,5]  R1459     0.369782954454422
    z[3,2,5]  R1460     -1.2190397083759308e-01
    z[3,2,5]  R1461     3.2342159748077393e-01
    z[3,2,5]  R1462     -5.2841216325759888e-02
    z[3,2,5]  R1463     3.4322327375411987e-01
    z[3,2,5]  R1464     6.2322318553924561e-01
    z[3,2,5]  R1465     8.4276765584945679e-02
    z[3,2,5]  R1466     -5.3143654018640518e-02
    z[3,2,5]  R1467     1.3258161488920450e-03
    z[3,2,5]  R1468     3.2388001680374146e-01
    z[3,2,5]  R1469     -8.1217736005783081e-02
    z[3,2,5]  R1470     -1.0150302201509476e-01
    z[3,2,5]  R1471     2.2486111521720886e-01
    z[3,2,5]  R1472     2.5098431110382080e-01
    z[3,2,5]  R1473     -5.9654969722032547e-02
    z[3,2,5]  R1474     -4.1578780859708786e-02
    z[3,2,5]  R1475     7.0019364356994629e-02
    z[3,2,5]  R1476     -0.144505113363266
    z[3,2,5]  R1477     8.7805442512035370e-02
    z[3,2,5]  R1478     6.7401833832263947e-02
    z[3,2,5]  R1479     -0.0353923924267292
    z[3,2,5]  R1480     -7.2828090190887451e-01
    z[3,2,6]  R26       1
    z[3,2,6]  R35       -1
    z[3,2,6]  R1415     -1
    z[3,2,6]  R1416     1
    z[3,2,6]  R1417     1.3507449626922607e-01
    z[3,2,6]  R1418     2.6652544736862183e-01
    z[3,2,6]  R1419     -2.8472086787223816e-01
    z[3,2,6]  R1420     4.1985213756561279e-02
    z[3,2,6]  R1421     -3.0993112921714783e-01
    z[3,2,6]  R1422     6.2922559678554535e-02
    z[3,2,6]  R1423     -8.6804866790771484e-02
    z[3,2,6]  R1424     1.6346450150012970e-01
    z[3,2,6]  R1425     -2.1336419880390167e-01
    z[3,2,6]  R1426     -1.5313178300857544e-01
    z[3,2,6]  R1427     -4.4341591000556946e-01
    z[3,2,6]  R1428     -5.8153618127107620e-02
    z[3,2,6]  R1429     -1.2105491012334824e-01
    z[3,2,6]  R1430     9.5740392804145813e-02
    z[3,2,6]  R1431     3.0108624696731567e-01
    z[3,2,6]  R1432     2.4864296615123749e-01
    z[3,2,6]  R1433     2.2193619608879089e-01
    z[3,2,6]  R1434     2.1507178246974945e-01
    z[3,2,6]  R1435     2.5794410705566406e-01
    z[3,2,6]  R1436     5.3128913044929504e-02
    z[3,2,6]  R1437     3.6897215992212296e-02
    z[3,2,6]  R1438     -3.7897691130638123e-01
    z[3,2,6]  R1439     5.0594788044691086e-02
    z[3,2,6]  R1440     2.8071720153093338e-02
    z[3,2,6]  R1441     1.2220699340105057e-01
    z[3,2,6]  R1442     -1.5717579424381256e-01
    z[3,2,6]  R1443     -2.1846961975097656e-01
    z[3,2,6]  R1444     -4.9315180629491806e-02
    z[3,2,6]  R1445     1.7198757827281952e-01
    z[3,2,6]  R1446     2.7713131904602051e-01
    z[3,2,6]  R1447     -3.1991052627563477e-01
    z[3,2,6]  R1448     5.1235571503639221e-02
    z[3,2,6]  R1449     -8.7080515921115875e-02
    z[3,2,6]  R1450     4.4334483146667480e-01
    z[3,2,6]  R1451     -3.5520243644714355e-01
    z[3,2,6]  R1452     -3.5905953496694565e-02
    z[3,2,6]  R1453     1.4304243028163910e-01
    z[3,2,6]  R1454     5.8000016957521439e-02
    z[3,2,6]  R1455     -9.6655987203121185e-02
    z[3,2,6]  R1456     -2.0759889483451843e-01
    z[3,2,6]  R1457     -6.5398856997489929e-02
    z[3,2,6]  R1458     -8.5410483181476593e-02
    z[3,2,6]  R1459     -4.9335431307554245e-02
    z[3,2,6]  R1460     -5.1971656084060669e-01
    z[3,2,6]  R1461     1.2869545817375183e-01
    z[3,2,6]  R1462     -2.8008174896240234e-01
    z[3,2,6]  R1463     0.523004949092865
    z[3,2,6]  R1464     -2.2640366852283478e-01
    z[3,2,6]  R1465     2.6593515276908875e-01
    z[3,2,6]  R1466     3.5641238093376160e-01
    z[3,2,6]  R1467     2.8633415699005127e-01
    z[3,2,6]  R1468     1.0971251875162125e-01
    z[3,2,6]  R1469     -3.4122490882873535e-01
    z[3,2,6]  R1470     -5.7082408666610718e-01
    z[3,2,6]  R1471     -5.4641157388687134e-01
    z[3,2,6]  R1472     -3.9022284746170044e-01
    z[3,2,6]  R1473     -2.5672206282615662e-01
    z[3,2,6]  R1474     -3.1493085622787476e-01
    z[3,2,6]  R1475     -4.0359282493591309e-01
    z[3,2,6]  R1476     -1.8941122293472290e-01
    z[3,2,6]  R1477     -3.3500626683235168e-01
    z[3,2,6]  R1478     1.4404852688312531e-01
    z[3,2,6]  R1479     -2.0026246085762978e-02
    z[3,2,6]  R1480     -2.7827879786491394e-01
    z[2,6,0]  R20       -1
    z[2,6,0]  R56       1
    z[2,6,0]  R1481     -1
    z[2,6,0]  R1482     1
    z[2,6,0]  R1495     -5.9558898210525513e-02
    z[2,6,0]  R1496     1.8688710033893585e-01
    z[2,6,0]  R1497     4.0684661269187927e-01
    z[2,6,0]  R1498     5.0825828313827515e-01
    z[2,6,0]  R1499     3.8950565457344055e-01
    z[2,6,0]  R1500     3.7066829204559326e-01
    z[2,6,0]  R1501     1.5516020357608795e-01
    z[2,6,0]  R1502     4.5007619261741638e-01
    z[2,6,0]  R1503     3.0709198117256165e-01
    z[2,6,0]  R1504     -8.9899547398090363e-02
    z[2,6,0]  R1505     -5.0068795680999756e-01
    z[2,6,0]  R1506     -1.9401873648166656e-01
    z[2,6,0]  R1507     -5.2254962921142578e-01
    z[2,6,0]  R1508     -2.0976625382900238e-01
    z[2,6,0]  R1509     -3.5914450883865356e-01
    z[2,6,0]  R1510     -2.2353176772594452e-01
    z[2,6,0]  R1511     -2.3866747319698334e-01
    z[2,6,0]  R1512     -5.8838635683059692e-01
    z[2,6,0]  R1513     -2.8149381279945374e-01
    z[2,6,0]  R1514     -5.7092517614364624e-01
    z[2,6,0]  R1515     0.227547287940979
    z[2,6,0]  R1516     5.5791920423507690e-01
    z[2,6,0]  R1517     4.3100666999816895e-01
    z[2,6,0]  R1518     1.3391035795211792e-01
    z[2,6,0]  R1519     2.5043988227844238e-01
    z[2,6,0]  R1520     -1.1739933490753174e-01
    z[2,6,0]  R1521     -6.8089950084686279e-01
    z[2,6,0]  R1522     9.4819717109203339e-02
    z[2,6,0]  R1523     1.9782318174839020e-01
    z[2,6,0]  R1524     -2.4343258142471313e-01
    z[2,6,0]  R1525     -1.6474086046218872e-01
    z[2,6,0]  R1526     1.1158072203397751e-01
    z[2,6,0]  R1527     0.0373874306678772
    z[2,6,0]  R1528     -8.2292415201663971e-02
    z[2,6,0]  R1529     -6.8636733293533325e-01
    z[2,6,0]  R1530     -3.6941394209861755e-01
    z[2,6,0]  R1531     4.2295315861701965e-01
    z[2,6,0]  R1532     1.9365036487579346e-01
    z[2,6,0]  R1533     -4.2744394391775131e-02
    z[2,6,0]  R1534     -4.0544059872627258e-01
    z[2,6,0]  R1535     -0.047398891299963
    z[2,6,0]  R1536     -4.4668549299240112e-01
    z[2,6,0]  R1537     -3.2467502355575562e-01
    z[2,6,0]  R1538     -4.3154659867286682e-01
    z[2,6,0]  R1539     1.2100342661142349e-01
    z[2,6,0]  R1540     2.9956543445587158e-01
    z[2,6,0]  R1541     -2.7906802296638489e-01
    z[2,6,0]  R1542     2.6324215531349182e-01
    z[2,6,0]  R1543     3.7964138388633728e-01
    z[2,6,0]  R1544     8.2014858722686768e-01
    z[2,6,0]  R1545     -5.1732414960861206e-01
    z[2,6,0]  R1546     2.2022904828190804e-02
    z[2,6,0]  R1547     -6.7554646730422974e-01
    z[2,6,0]  R1548     -3.6076098680496216e-01
    z[2,6,0]  R1549     -2.2130471467971802e-01
    z[2,6,0]  R1550     3.9594525098800659e-01
    z[2,6,0]  R1551     5.2152341604232788e-01
    z[2,6,0]  R1552     1.6126877069473267e-01
    z[2,6,0]  R1553     -5.1240515708923340e-01
    z[2,6,0]  R1554     -5.6220752000808716e-01
    z[2,6,0]  R1555     -2.2039239108562469e-01
    z[2,6,0]  R1556     -4.3702054023742676e-01
    z[2,6,0]  R1557     -1.5497425198554993e-01
    z[2,6,0]  R1558     -5.1202714443206787e-01
    z[2,6,0]  R1559     7.3430542834103107e-03
    z[2,6,0]  R1560     2.0170010626316071e-01
    z[2,6,0]  R1561     3.6225342750549316e-01
    z[2,6,0]  R1562     -5.6179058551788330e-01
    z[2,6,0]  R1563     3.4631749987602234e-01
    z[2,6,0]  R1564     -4.1941487789154053e-01
    z[2,6,0]  R1565     -4.7215002775192261e-01
    z[2,6,0]  R1566     -4.0012276172637939e-01
    z[2,6,0]  R1567     2.7824291586875916e-01
    z[2,6,0]  R1568     4.1739797592163086e-01
    z[2,6,0]  R1569     -4.4357064366340637e-01
    z[2,6,0]  R1570     -3.3242177963256836e-01
    z[2,6,0]  R1571     -4.6058263629674911e-02
    z[2,6,0]  R1572     5.9308332204818726e-01
    z[2,6,0]  R1573     8.7423712015151978e-02
    z[2,6,0]  R1574     -2.8697337955236435e-02
    z[2,6,0]  R1575     5.9080682694911957e-02
    z[2,6,0]  R1576     4.8808166384696960e-01
    z[2,6,0]  R1577     5.8220338821411133e-01
    z[2,6,1]  R21       -1
    z[2,6,1]  R57       1
    z[2,6,1]  R1483     -1
    z[2,6,1]  R1484     1
    z[2,6,1]  R1495     -5.9290248155593872e-01
    z[2,6,1]  R1496     -7.2246640920639038e-01
    z[2,6,1]  R1497     -5.1898014545440674e-01
    z[2,6,1]  R1498     -5.0235044956207275e-01
    z[2,6,1]  R1499     -4.0276399254798889e-01
    z[2,6,1]  R1500     -7.1195507049560547e-01
    z[2,6,1]  R1501     -5.4251879453659058e-01
    z[2,6,1]  R1502     -4.0479367971420288e-01
    z[2,6,1]  R1503     -8.8276928663253784e-01
    z[2,6,1]  R1504     -5.2685809135437012e-01
    z[2,6,1]  R1505     7.9778659343719482e-01
    z[2,6,1]  R1506     8.5822361707687378e-01
    z[2,6,1]  R1507     0.57748943567276
    z[2,6,1]  R1508     7.6454418897628784e-01
    z[2,6,1]  R1509     6.0351091623306274e-01
    z[2,6,1]  R1510     6.7756199836730957e-01
    z[2,6,1]  R1511     7.5941306352615356e-01
    z[2,6,1]  R1512     4.8605209589004517e-01
    z[2,6,1]  R1513     6.8820118904113770e-01
    z[2,6,1]  R1514     4.4714894890785217e-01
    z[2,6,1]  R1515     -1.3957631587982178e-01
    z[2,6,1]  R1516     1.5866938233375549e-01
    z[2,6,1]  R1517     8.7374888360500336e-02
    z[2,6,1]  R1518     -5.2000995725393295e-02
    z[2,6,1]  R1519     -9.0008413791656494e-01
    z[2,6,1]  R1520     4.8491966724395752e-01
    z[2,6,1]  R1521     2.7578523755073547e-01
    z[2,6,1]  R1522     4.0412941575050354e-01
    z[2,6,1]  R1523     -8.4182655811309814e-01
    z[2,6,1]  R1524     3.7795212864875793e-01
    z[2,6,1]  R1525     -4.7477439045906067e-01
    z[2,6,1]  R1526     -8.2168734073638916e-01
    z[2,6,1]  R1527     3.5587257146835327e-01
    z[2,6,1]  R1528     5.9452176094055176e-01
    z[2,6,1]  R1529     5.4028725624084473e-01
    z[2,6,1]  R1530     4.3962958455085754e-01
    z[2,6,1]  R1531     1.2242415547370911e-01
    z[2,6,1]  R1532     4.0875086188316345e-01
    z[2,6,1]  R1533     4.1638728976249695e-01
    z[2,6,1]  R1534     4.0337544679641724e-01
    z[2,6,1]  R1535     4.0010768175125122e-01
    z[2,6,1]  R1536     2.9809844493865967e-01
    z[2,6,1]  R1537     3.8250654935836792e-01
    z[2,6,1]  R1538     2.4132257699966431e-01
    z[2,6,1]  R1539     3.0258321762084961e-01
    z[2,6,1]  R1540     3.1962257623672485e-01
    z[2,6,1]  R1541     5.7955151796340942e-01
    z[2,6,1]  R1542     1.7624391615390778e-01
    z[2,6,1]  R1543     2.0100392401218414e-01
    z[2,6,1]  R1544     -7.4481934309005737e-02
    z[2,6,1]  R1545     2.6645469665527344e-01
    z[2,6,1]  R1546     -5.8485662937164307e-01
    z[2,6,1]  R1547     -3.7440571188926697e-01
    z[2,6,1]  R1548     -6.1355471611022949e-01
    z[2,6,1]  R1549     -2.6705756783485413e-01
    z[2,6,1]  R1550     -7.1646170690655708e-03
    z[2,6,1]  R1551     1.0217893868684769e-01
    z[2,6,1]  R1552     4.0572628378868103e-01
    z[2,6,1]  R1553     3.9647969603538513e-01
    z[2,6,1]  R1554     3.8121148943901062e-01
    z[2,6,1]  R1555     3.7789022922515869e-01
    z[2,6,1]  R1556     -5.6038576364517212e-01
    z[2,6,1]  R1557     -5.3539234399795532e-01
    z[2,6,1]  R1558     -5.6757456064224243e-01
    z[2,6,1]  R1559     4.7778841853141785e-01
    z[2,6,1]  R1560     2.7109444141387939e-01
    z[2,6,1]  R1561     3.9177486300468445e-01
    z[2,6,1]  R1562     4.6451058983802795e-01
    z[2,6,1]  R1563     1.6319791972637177e-01
    z[2,6,1]  R1564     4.5668345689773560e-01
    z[2,6,1]  R1565     -6.4762878417968750e-01
    z[2,6,1]  R1566     -5.0727158784866333e-01
    z[2,6,1]  R1567     -5.3213357925415039e-01
    z[2,6,1]  R1568     -5.4442584514617920e-01
    z[2,6,1]  R1569     4.0950211882591248e-01
    z[2,6,1]  R1570     -6.4772331714630127e-01
    z[2,6,1]  R1571     -4.2938083410263062e-01
    z[2,6,1]  R1572     3.2703793048858643e-01
    z[2,6,1]  R1573     -4.7708502411842346e-01
    z[2,6,1]  R1574     -3.7778580188751221e-01
    z[2,6,1]  R1575     -3.9710542559623718e-01
    z[2,6,1]  R1576     3.7884214520454407e-01
    z[2,6,1]  R1577     3.1807422637939453e-01
    z[2,6,2]  R22       -1
    z[2,6,2]  R58       1
    z[2,6,2]  R1485     -1
    z[2,6,2]  R1486     1
    z[2,6,2]  R1495     3.5933580994606018e-01
    z[2,6,2]  R1496     -3.1633205711841583e-02
    z[2,6,2]  R1497     1.9013518467545509e-02
    z[2,6,2]  R1498     2.0099420845508575e-01
    z[2,6,2]  R1499     5.9181636571884155e-01
    z[2,6,2]  R1500     4.8591491580009460e-01
    z[2,6,2]  R1501     1.9740661978721619e-01
    z[2,6,2]  R1502     3.8579389452934265e-01
    z[2,6,2]  R1503     -7.7522508800029755e-02
    z[2,6,2]  R1504     7.4727272987365723e-01
    z[2,6,2]  R1505     -1.2009497731924057e-01
    z[2,6,2]  R1506     7.6472632586956024e-02
    z[2,6,2]  R1507     3.2745766639709473e-01
    z[2,6,2]  R1508     1.8415714800357819e-01
    z[2,6,2]  R1509     -1.2678658962249756e-01
    z[2,6,2]  R1510     -4.4335469603538513e-01
    z[2,6,2]  R1511     4.9939689040184021e-01
    z[2,6,2]  R1512     -1.5145042538642883e-01
    z[2,6,2]  R1513     9.8478108644485474e-02
    z[2,6,2]  R1514     -5.7115167379379272e-02
    z[2,6,2]  R1515     -5.1285862922668457e-01
    z[2,6,2]  R1516     -0.381136029958725
    z[2,6,2]  R1517     -5.9377545118331909e-01
    z[2,6,2]  R1518     -0.43329918384552
    z[2,6,2]  R1519     -2.2932359576225281e-01
    z[2,6,2]  R1520     -6.8683421611785889e-01
    z[2,6,2]  R1521     -5.0153082609176636e-01
    z[2,6,2]  R1522     -6.4585661888122559e-01
    z[2,6,2]  R1523     1.6330896317958832e-01
    z[2,6,2]  R1524     -5.6998163461685181e-01
    z[2,6,2]  R1525     5.9834194183349609e-01
    z[2,6,2]  R1526     -1.1998074501752853e-01
    z[2,6,2]  R1527     -0.644943118095398
    z[2,6,2]  R1528     -4.7349187731742859e-01
    z[2,6,2]  R1529     2.5623485445976257e-01
    z[2,6,2]  R1530     4.7445413470268250e-01
    z[2,6,2]  R1531     -5.6328210048377514e-03
    z[2,6,2]  R1532     1.6692188382148743e-01
    z[2,6,2]  R1533     3.6668628454208374e-01
    z[2,6,2]  R1534     7.6216422021389008e-02
    z[2,6,2]  R1535     2.4714258313179016e-01
    z[2,6,2]  R1536     2.9009503126144409e-01
    z[2,6,2]  R1537     -1.0790310055017471e-01
    z[2,6,2]  R1538     4.0713006258010864e-01
    z[2,6,2]  R1539     2.1538142859935760e-01
    z[2,6,2]  R1540     6.6276490688323975e-01
    z[2,6,2]  R1541     3.0871546268463135e-01
    z[2,6,2]  R1542     2.8660658001899719e-01
    z[2,6,2]  R1543     3.0485492944717407e-01
    z[2,6,2]  R1544     1.6351932287216187e-01
    z[2,6,2]  R1545     6.7355133593082428e-02
    z[2,6,2]  R1546     -5.0796133279800415e-01
    z[2,6,2]  R1547     2.2495531011372805e-03
    z[2,6,2]  R1548     1.5763860195875168e-02
    z[2,6,2]  R1549     1.5075573325157166e-01
    z[2,6,2]  R1550     6.8243521451950073e-01
    z[2,6,2]  R1551     6.0448747873306274e-01
    z[2,6,2]  R1552     2.1318452060222626e-01
    z[2,6,2]  R1553     1.9009378552436829e-01
    z[2,6,2]  R1554     5.0256246328353882e-01
    z[2,6,2]  R1555     4.5426163077354431e-01
    z[2,6,2]  R1556     6.6239468753337860e-02
    z[2,6,2]  R1557     9.6148863434791565e-02
    z[2,6,2]  R1558     -6.8059504032135010e-02
    z[2,6,2]  R1559     6.4776223897933960e-01
    z[2,6,2]  R1560     5.2126592397689819e-01
    z[2,6,2]  R1561     4.7185677289962769e-01
    z[2,6,2]  R1562     7.9380877315998077e-02
    z[2,6,2]  R1563     2.2927826642990112e-01
    z[2,6,2]  R1564     -1.2523406744003296e-01
    z[2,6,2]  R1565     -2.0751677453517914e-02
    z[2,6,2]  R1566     -2.7674663066864014e-01
    z[2,6,2]  R1567     2.1530188620090485e-02
    z[2,6,2]  R1568     -3.0051467474550009e-03
    z[2,6,2]  R1569     -1.7241753637790680e-01
    z[2,6,2]  R1570     -1.3766567409038544e-01
    z[2,6,2]  R1571     4.2141386866569519e-01
    z[2,6,2]  R1572     2.1265690028667450e-01
    z[2,6,2]  R1573     -3.5251066088676453e-01
    z[2,6,2]  R1574     0.394464910030365
    z[2,6,2]  R1575     3.6904075741767883e-01
    z[2,6,2]  R1576     0.0866931602358818
    z[2,6,2]  R1577     -6.8666212260723114e-02
    z[2,6,3]  R23       -1
    z[2,6,3]  R59       1
    z[2,6,3]  R1487     -1
    z[2,6,3]  R1488     1
    z[2,6,3]  R1495     -4.1641983389854431e-01
    z[2,6,3]  R1496     -0.581412672996521
    z[2,6,3]  R1497     -3.9674839377403259e-01
    z[2,6,3]  R1498     -2.2573718428611755e-01
    z[2,6,3]  R1499     0.151409313082695
    z[2,6,3]  R1500     1.7278465628623962e-01
    z[2,6,3]  R1501     -2.1413658559322357e-01
    z[2,6,3]  R1502     1.2555651366710663e-01
    z[2,6,3]  R1503     1.1373896151781082e-01
    z[2,6,3]  R1504     -2.2943688556551933e-02
    z[2,6,3]  R1505     9.0139739215373993e-02
    z[2,6,3]  R1506     8.0782070755958557e-02
    z[2,6,3]  R1507     4.3264187872409821e-02
    z[2,6,3]  R1508     2.2799910511821508e-03
    z[2,6,3]  R1509     -3.0812883377075195e-01
    z[2,6,3]  R1510     -0.0792752057313919
    z[2,6,3]  R1511     7.7979043126106262e-02
    z[2,6,3]  R1512     -2.6251441240310669e-01
    z[2,6,3]  R1513     -4.3058654665946960e-01
    z[2,6,3]  R1514     -6.4221984148025513e-01
    z[2,6,3]  R1515     6.5747827291488647e-01
    z[2,6,3]  R1516     6.9999152421951294e-01
    z[2,6,3]  R1517     5.6981217861175537e-01
    z[2,6,3]  R1518     2.0941333472728729e-01
    z[2,6,3]  R1519     5.1031899638473988e-03
    z[2,6,3]  R1520     -1.4898261427879333e-01
    z[2,6,3]  R1521     -2.8086232021450996e-02
    z[2,6,3]  R1522     5.5436813831329346e-01
    z[2,6,3]  R1523     -3.6988684535026550e-01
    z[2,6,3]  R1524     -1.6029103100299835e-01
    z[2,6,3]  R1525     -2.2525161504745483e-01
    z[2,6,3]  R1526     -4.5653226971626282e-01
    z[2,6,3]  R1527     -2.2042134404182434e-01
    z[2,6,3]  R1528     5.0365632772445679e-01
    z[2,6,3]  R1529     7.7158883213996887e-02
    z[2,6,3]  R1530     -0.557939350605011
    z[2,6,3]  R1531     -3.8787013292312622e-01
    z[2,6,3]  R1532     -7.7670890092849731e-01
    z[2,6,3]  R1533     -7.0972442626953125e-01
    z[2,6,3]  R1534     -3.4640991687774658e-01
    z[2,6,3]  R1535     -7.3124104738235474e-01
    z[2,6,3]  R1536     -5.2422147989273071e-01
    z[2,6,3]  R1537     3.5884547233581543e-01
    z[2,6,3]  R1538     4.0285471081733704e-01
    z[2,6,3]  R1539     -0.759775698184967
    z[2,6,3]  R1540     -5.8142524957656860e-01
    z[2,6,3]  R1541     -4.2721742391586304e-01
    z[2,6,3]  R1542     -5.6639397144317627e-01
    z[2,6,3]  R1543     -7.0367473363876343e-01
    z[2,6,3]  R1544     -1.2777270376682281e-01
    z[2,6,3]  R1545     1.6802865266799927e-01
    z[2,6,3]  R1546     4.2923569679260254e-01
    z[2,6,3]  R1547     1.0206146538257599e-01
    z[2,6,3]  R1548     6.9345241785049438e-01
    z[2,6,3]  R1549     -8.5138714313507080e-01
    z[2,6,3]  R1550     -4.4106084108352661e-01
    z[2,6,3]  R1551     -5.5888414382934570e-01
    z[2,6,3]  R1552     -8.1872475147247314e-01
    z[2,6,3]  R1553     3.7962052226066589e-01
    z[2,6,3]  R1554     -3.3120054006576538e-01
    z[2,6,3]  R1555     -2.5419533252716064e-01
    z[2,6,3]  R1556     4.5828998088836670e-01
    z[2,6,3]  R1557     5.4101234674453735e-01
    z[2,6,3]  R1558     5.4365581274032593e-01
    z[2,6,3]  R1559     -5.8628183603286743e-01
    z[2,6,3]  R1560     -7.3722654581069946e-01
    z[2,6,3]  R1561     -6.0235756635665894e-01
    z[2,6,3]  R1562     -4.5180425047874451e-01
    z[2,6,3]  R1563     -7.7838724851608276e-01
    z[2,6,3]  R1564     1.3046717643737793e-01
    z[2,6,3]  R1565     4.4680750370025635e-01
    z[2,6,3]  R1566     0.547261655330658
    z[2,6,3]  R1567     6.1301314830780029e-01
    z[2,6,3]  R1568     0.675198495388031
    z[2,6,3]  R1569     -2.6835939288139343e-01
    z[2,6,3]  R1570     6.6462028026580811e-01
    z[2,6,3]  R1571     7.6194804906845093e-01
    z[2,6,3]  R1572     5.4782259464263916e-01
    z[2,6,3]  R1573     5.4189068078994751e-01
    z[2,6,3]  R1574     7.3853135108947754e-01
    z[2,6,3]  R1575     7.4501550197601318e-01
    z[2,6,3]  R1576     2.4280984699726105e-01
    z[2,6,3]  R1577     3.2068583369255066e-01
    z[2,6,4]  R24       -1
    z[2,6,4]  R60       1
    z[2,6,4]  R1489     -1
    z[2,6,4]  R1490     1
    z[2,6,4]  R1495     -1.1001219972968102e-03
    z[2,6,4]  R1496     2.8186461329460144e-01
    z[2,6,4]  R1497     5.1787173748016357e-01
    z[2,6,4]  R1498     3.3614826202392578e-01
    z[2,6,4]  R1499     4.3787100911140442e-01
    z[2,6,4]  R1500     -9.2299081385135651e-02
    z[2,6,4]  R1501     4.5325309038162231e-01
    z[2,6,4]  R1502     1.7119120061397552e-01
    z[2,6,4]  R1503     -0.172170028090477
    z[2,6,4]  R1504     1.5981712937355042e-01
    z[2,6,4]  R1505     -9.1165617108345032e-02
    z[2,6,4]  R1506     3.1064444780349731e-01
    z[2,6,4]  R1507     -4.0164259076118469e-01
    z[2,6,4]  R1508     -0.0375276580452919
    z[2,6,4]  R1509     -2.1597084403038025e-01
    z[2,6,4]  R1510     -2.6986721158027649e-01
    z[2,6,4]  R1511     2.0343777537345886e-01
    z[2,6,4]  R1512     -4.7412395477294922e-01
    z[2,6,4]  R1513     2.9025465250015259e-01
    z[2,6,4]  R1514     4.0439318865537643e-02
    z[2,6,4]  R1515     3.3689764142036438e-01
    z[2,6,4]  R1516     5.4812509566545486e-02
    z[2,6,4]  R1517     3.5733726620674133e-01
    z[2,6,4]  R1518     -3.7407171726226807e-01
    z[2,6,4]  R1519     -4.8948537558317184e-02
    z[2,6,4]  R1520     4.3450409173965454e-01
    z[2,6,4]  R1521     3.9758551120758057e-01
    z[2,6,4]  R1522     2.4671699106693268e-01
    z[2,6,4]  R1523     -2.3689439892768860e-01
    z[2,6,4]  R1524     5.3628218173980713e-01
    z[2,6,4]  R1525     4.5758464932441711e-01
    z[2,6,4]  R1526     1.3389259576797485e-01
    z[2,6,4]  R1527     6.1684852838516235e-01
    z[2,6,4]  R1528     -1.2166652828454971e-01
    z[2,6,4]  R1529     -3.7135216593742371e-01
    z[2,6,4]  R1530     -0.354168564081192
    z[2,6,4]  R1531     -2.1554410457611084e-01
    z[2,6,4]  R1532     -9.7739897668361664e-02
    z[2,6,4]  R1533     -8.2521423697471619e-02
    z[2,6,4]  R1534     -4.7443509101867676e-01
    z[2,6,4]  R1535     -3.2872599363327026e-01
    z[2,6,4]  R1536     -9.5027446746826172e-02
    z[2,6,4]  R1537     -6.7304037511348724e-02
    z[2,6,4]  R1538     0.0866825059056282
    z[2,6,4]  R1539     -6.7003101110458374e-02
    z[2,6,4]  R1540     -7.8297823667526245e-02
    z[2,6,4]  R1541     4.3972003459930420e-01
    z[2,6,4]  R1542     3.1733307242393494e-01
    z[2,6,4]  R1543     4.2865127325057983e-01
    z[2,6,4]  R1544     5.1188313961029053e-01
    z[2,6,4]  R1545     0.0507943332195282
    z[2,6,4]  R1546     9.2227414250373840e-02
    z[2,6,4]  R1547     -1.1723274737596512e-01
    z[2,6,4]  R1548     7.0551261305809021e-02
    z[2,6,4]  R1549     2.8297787904739380e-01
    z[2,6,4]  R1550     -4.0528275072574615e-02
    z[2,6,4]  R1551     3.9297146722674370e-03
    z[2,6,4]  R1552     -2.5915073230862617e-02
    z[2,6,4]  R1553     1.1037456989288330e-01
    z[2,6,4]  R1554     -0.0431511253118515
    z[2,6,4]  R1555     -8.1617077812552452e-03
    z[2,6,4]  R1556     -4.2186689376831055e-01
    z[2,6,4]  R1557     -2.3261302709579468e-01
    z[2,6,4]  R1558     -1.6281627118587494e-01
    z[2,6,4]  R1559     8.3653137087821960e-02
    z[2,6,4]  R1560     4.4808998703956604e-02
    z[2,6,4]  R1561     3.5443204641342163e-01
    z[2,6,4]  R1562     -1.3447956740856171e-01
    z[2,6,4]  R1563     1.6174888610839844e-01
    z[2,6,4]  R1564     -1.6961348056793213e-01
    z[2,6,4]  R1565     -2.8872808814048767e-01
    z[2,6,4]  R1566     0.0324304923415184
    z[2,6,4]  R1567     1.1904054135084152e-01
    z[2,6,4]  R1568     1.3996081054210663e-01
    z[2,6,4]  R1569     -6.6272771358489990e-01
    z[2,6,4]  R1570     -2.5161406025290489e-02
    z[2,6,4]  R1571     -1.1635018140077591e-01
    z[2,6,4]  R1572     -1.0016535967588425e-01
    z[2,6,4]  R1573     5.2733731269836426e-01
    z[2,6,4]  R1574     -2.1668742597103119e-01
    z[2,6,4]  R1575     -2.9552593827247620e-01
    z[2,6,4]  R1576     -3.6308676004409790e-01
    z[2,6,4]  R1577     -3.3995696902275085e-01
    z[2,6,5]  R25       -1
    z[2,6,5]  R61       1
    z[2,6,5]  R1491     -1
    z[2,6,5]  R1492     1
    z[2,6,5]  R1495     5.8147519826889038e-01
    z[2,6,5]  R1496     -1.3164943456649780e-01
    z[2,6,5]  R1497     0.369782954454422
    z[2,6,5]  R1498     -1.2190397083759308e-01
    z[2,6,5]  R1499     3.2342159748077393e-01
    z[2,6,5]  R1500     -5.2841216325759888e-02
    z[2,6,5]  R1501     3.4322327375411987e-01
    z[2,6,5]  R1502     6.2322318553924561e-01
    z[2,6,5]  R1503     8.4276765584945679e-02
    z[2,6,5]  R1504     -5.3143654018640518e-02
    z[2,6,5]  R1505     1.3258161488920450e-03
    z[2,6,5]  R1506     3.2388001680374146e-01
    z[2,6,5]  R1507     -8.1217736005783081e-02
    z[2,6,5]  R1508     -1.0150302201509476e-01
    z[2,6,5]  R1509     2.2486111521720886e-01
    z[2,6,5]  R1510     2.5098431110382080e-01
    z[2,6,5]  R1511     -5.9654969722032547e-02
    z[2,6,5]  R1512     -4.1578780859708786e-02
    z[2,6,5]  R1513     7.0019364356994629e-02
    z[2,6,5]  R1514     -0.144505113363266
    z[2,6,5]  R1515     8.7805442512035370e-02
    z[2,6,5]  R1516     6.7401833832263947e-02
    z[2,6,5]  R1517     -0.0353923924267292
    z[2,6,5]  R1518     -7.2828090190887451e-01
    z[2,6,5]  R1519     -4.1539106518030167e-02
    z[2,6,5]  R1520     2.2819447517395020e-01
    z[2,6,5]  R1521     1.7619884014129639e-01
    z[2,6,5]  R1522     1.3112403452396393e-01
    z[2,6,5]  R1523     1.2630765140056610e-01
    z[2,6,5]  R1524     3.9634126424789429e-01
    z[2,6,5]  R1525     -6.1755768954753876e-02
    z[2,6,5]  R1526     -1.6362796723842621e-01
    z[2,6,5]  R1527     -0.00947926752269268
    z[2,6,5]  R1528     3.7716919183731079e-01
    z[2,6,5]  R1529     -1.2126628309488297e-01
    z[2,6,5]  R1530     -8.2264598459005356e-03
    z[2,6,5]  R1531     7.7099567651748657e-01
    z[2,6,5]  R1532     -9.8559595644474030e-02
    z[2,6,5]  R1533     -3.2236614823341370e-01
    z[2,6,5]  R1534     -3.8575440645217896e-01
    z[2,6,5]  R1535     2.7779513597488403e-01
    z[2,6,5]  R1536     -4.8051732778549194e-01
    z[2,6,5]  R1537     -7.7186834812164307e-01
    z[2,6,5]  R1538     -4.4081023335456848e-01
    z[2,6,5]  R1539     4.9419414997100830e-01
    z[2,6,5]  R1540     -9.7955256700515747e-02
    z[2,6,5]  R1541     -0.336814820766449
    z[2,6,5]  R1542     -5.7692015171051025e-01
    z[2,6,5]  R1543     1.9828870892524719e-01
    z[2,6,5]  R1544     0.127718985080719
    z[2,6,5]  R1545     -7.1706116199493408e-01
    z[2,6,5]  R1546     4.2671549320220947e-01
    z[2,6,5]  R1547     -6.1563742160797119e-01
    z[2,6,5]  R1548     -4.0803611278533936e-02
    z[2,6,5]  R1549     2.2335672378540039e-01
    z[2,6,5]  R1550     4.1427803039550781e-01
    z[2,6,5]  R1551     -1.2038338184356689e-01
    z[2,6,5]  R1552     9.2470802366733551e-02
    z[2,6,5]  R1553     3.5213101655244827e-02
    z[2,6,5]  R1554     8.0370604991912842e-02
    z[2,6,5]  R1555     0.667449414730072
    z[2,6,5]  R1556     -2.9559394717216492e-01
    z[2,6,5]  R1557     -5.7194280624389648e-01
    z[2,6,5]  R1558     -3.8481815718114376e-03
    z[2,6,5]  R1559     2.5344986468553543e-02
    z[2,6,5]  R1560     2.5290971994400024e-01
    z[2,6,5]  R1561     -2.8588702902197838e-02
    z[2,6,5]  R1562     -4.4346663355827332e-01
    z[2,6,5]  R1563     -2.3948095738887787e-01
    z[2,6,5]  R1564     -7.2092288732528687e-01
    z[2,6,5]  R1565     -2.1446606516838074e-01
    z[2,6,5]  R1566     -4.3531975150108337e-01
    z[2,6,5]  R1567     -4.8618495464324951e-01
    z[2,6,5]  R1568     -6.1701752245426178e-02
    z[2,6,5]  R1569     1.9499303773045540e-02
    z[2,6,5]  R1570     -8.5549950599670410e-02
    z[2,6,5]  R1571     1.8580843508243561e-01
    z[2,6,5]  R1572     -4.3025019764900208e-01
    z[2,6,5]  R1573     -1.3461917638778687e-01
    z[2,6,5]  R1574     -9.5116794109344482e-02
    z[2,6,5]  R1575     0.000767854624427855
    z[2,6,5]  R1576     -5.7054489850997925e-01
    z[2,6,5]  R1577     -4.8150390386581421e-01
    z[2,6,6]  R26       -1
    z[2,6,6]  R62       1
    z[2,6,6]  R1493     -1
    z[2,6,6]  R1494     1
    z[2,6,6]  R1495     -6.5398856997489929e-02
    z[2,6,6]  R1496     -8.5410483181476593e-02
    z[2,6,6]  R1497     -4.9335431307554245e-02
    z[2,6,6]  R1498     -5.1971656084060669e-01
    z[2,6,6]  R1499     1.2869545817375183e-01
    z[2,6,6]  R1500     -2.8008174896240234e-01
    z[2,6,6]  R1501     0.523004949092865
    z[2,6,6]  R1502     -2.2640366852283478e-01
    z[2,6,6]  R1503     2.6593515276908875e-01
    z[2,6,6]  R1504     3.5641238093376160e-01
    z[2,6,6]  R1505     2.8633415699005127e-01
    z[2,6,6]  R1506     1.0971251875162125e-01
    z[2,6,6]  R1507     -3.4122490882873535e-01
    z[2,6,6]  R1508     -5.7082408666610718e-01
    z[2,6,6]  R1509     -5.4641157388687134e-01
    z[2,6,6]  R1510     -3.9022284746170044e-01
    z[2,6,6]  R1511     -2.5672206282615662e-01
    z[2,6,6]  R1512     -3.1493085622787476e-01
    z[2,6,6]  R1513     -4.0359282493591309e-01
    z[2,6,6]  R1514     -1.8941122293472290e-01
    z[2,6,6]  R1515     -3.3500626683235168e-01
    z[2,6,6]  R1516     1.4404852688312531e-01
    z[2,6,6]  R1517     -2.0026246085762978e-02
    z[2,6,6]  R1518     -2.7827879786491394e-01
    z[2,6,6]  R1519     2.6531422138214111e-01
    z[2,6,6]  R1520     1.2754152715206146e-01
    z[2,6,6]  R1521     1.3739053905010223e-01
    z[2,6,6]  R1522     1.5865311026573181e-01
    z[2,6,6]  R1523     -1.2897776067256927e-01
    z[2,6,6]  R1524     5.1337309181690216e-02
    z[2,6,6]  R1525     3.5426083207130432e-01
    z[2,6,6]  R1526     -2.1180485188961029e-01
    z[2,6,6]  R1527     -1.6379144787788391e-01
    z[2,6,6]  R1528     6.9629065692424774e-02
    z[2,6,6]  R1529     1.1301308125257492e-01
    z[2,6,6]  R1530     -0.0913948118686676
    z[2,6,6]  R1531     -1.2146764993667603e-01
    z[2,6,6]  R1532     -3.8080912828445435e-01
    z[2,6,6]  R1533     -2.7549448609352112e-01
    z[2,6,6]  R1534     -4.1617578268051147e-01
    z[2,6,6]  R1535     -2.3799885809421539e-01
    z[2,6,6]  R1536     -3.3573645353317261e-01
    z[2,6,6]  R1537     -8.6897037923336029e-02
    z[2,6,6]  R1538     -4.7503328323364258e-01
    z[2,6,6]  R1539     -1.4641021192073822e-01
    z[2,6,6]  R1540     -1.2273354083299637e-01
    z[2,6,6]  R1541     4.0288589894771576e-02
    z[2,6,6]  R1542     -2.5131475925445557e-01
    z[2,6,6]  R1543     -6.5688163042068481e-02
    z[2,6,6]  R1544     2.0194327458739281e-02
    z[2,6,6]  R1545     -3.3444055914878845e-01
    z[2,6,6]  R1546     1.5683636069297791e-01
    z[2,6,6]  R1547     1.6815623268485069e-02
    z[2,6,6]  R1548     -7.5065419077873230e-02
    z[2,6,6]  R1549     -4.6393796801567078e-02
    z[2,6,6]  R1550     9.8258063197135925e-02
    z[2,6,6]  R1551     -1.5908671915531158e-01
    z[2,6,6]  R1552     -2.9051387310028076e-01
    z[2,6,6]  R1553     -6.2175148725509644e-01
    z[2,6,6]  R1554     -4.0989780426025391e-01
    z[2,6,6]  R1555     3.0348291993141174e-01
    z[2,6,6]  R1556     1.2335287779569626e-01
    z[2,6,6]  R1557     7.8560203313827515e-02
    z[2,6,6]  R1558     2.9827767610549927e-01
    z[2,6,6]  R1559     0.0264901053160429
    z[2,6,6]  R1560     -6.8063624203205109e-02
    z[2,6,6]  R1561     -5.7983744889497757e-02
    z[2,6,6]  R1562     -2.0843598246574402e-01
    z[2,6,6]  R1563     -3.3385860919952393e-01
    z[2,6,6]  R1564     -1.8527679145336151e-01
    z[2,6,6]  R1565     1.6800068318843842e-01
    z[2,6,6]  R1566     1.2624703347682953e-01
    z[2,6,6]  R1567     1.1233668774366379e-01
    z[2,6,6]  R1568     2.2378845512866974e-01
    z[2,6,6]  R1569     -0.306953102350235
    z[2,6,6]  R1570     3.6419898271560669e-02
    z[2,6,6]  R1571     -0.0854058712720871
    z[2,6,6]  R1572     -2.8591899201273918e-02
    z[2,6,6]  R1573     2.2501243650913239e-01
    z[2,6,6]  R1574     -3.1531330943107605e-01
    z[2,6,6]  R1575     2.4544094502925873e-01
    z[2,6,6]  R1576     -3.0729341506958008e-01
    z[2,6,6]  R1577     -3.2387769222259521e-01
    z[6,2,0]  R20       1
    z[6,2,0]  R56       -1
    z[6,2,0]  R1578     -1
    z[6,2,0]  R1579     1
    z[6,2,0]  R1592     2.5043988227844238e-01
    z[6,2,0]  R1593     -1.1739933490753174e-01
    z[6,2,0]  R1594     -6.8089950084686279e-01
    z[6,2,0]  R1595     9.4819717109203339e-02
    z[6,2,0]  R1596     1.9782318174839020e-01
    z[6,2,0]  R1597     -2.4343258142471313e-01
    z[6,2,0]  R1598     -1.6474086046218872e-01
    z[6,2,0]  R1599     1.1158072203397751e-01
    z[6,2,0]  R1600     0.0373874306678772
    z[6,2,0]  R1601     -8.2292415201663971e-02
    z[6,2,0]  R1602     -6.8636733293533325e-01
    z[6,2,0]  R1603     -3.6941394209861755e-01
    z[6,2,0]  R1604     4.2295315861701965e-01
    z[6,2,0]  R1605     1.9365036487579346e-01
    z[6,2,0]  R1606     -4.2744394391775131e-02
    z[6,2,0]  R1607     -4.0544059872627258e-01
    z[6,2,0]  R1608     -0.047398891299963
    z[6,2,0]  R1609     -4.4668549299240112e-01
    z[6,2,0]  R1610     -3.2467502355575562e-01
    z[6,2,0]  R1611     -4.3154659867286682e-01
    z[6,2,0]  R1612     1.2100342661142349e-01
    z[6,2,0]  R1613     2.9956543445587158e-01
    z[6,2,0]  R1614     -2.7906802296638489e-01
    z[6,2,0]  R1615     2.6324215531349182e-01
    z[6,2,0]  R1616     3.7964138388633728e-01
    z[6,2,0]  R1617     8.2014858722686768e-01
    z[6,2,0]  R1618     -5.1732414960861206e-01
    z[6,2,0]  R1619     2.2022904828190804e-02
    z[6,2,0]  R1620     -6.7554646730422974e-01
    z[6,2,0]  R1621     -3.6076098680496216e-01
    z[6,2,0]  R1622     -2.2130471467971802e-01
    z[6,2,0]  R1623     3.9594525098800659e-01
    z[6,2,0]  R1624     5.2152341604232788e-01
    z[6,2,0]  R1625     1.6126877069473267e-01
    z[6,2,0]  R1626     -5.1240515708923340e-01
    z[6,2,0]  R1627     -5.6220752000808716e-01
    z[6,2,0]  R1628     -2.2039239108562469e-01
    z[6,2,0]  R1629     -4.3702054023742676e-01
    z[6,2,0]  R1630     -1.5497425198554993e-01
    z[6,2,0]  R1631     -5.1202714443206787e-01
    z[6,2,0]  R1632     7.3430542834103107e-03
    z[6,2,0]  R1633     2.0170010626316071e-01
    z[6,2,0]  R1634     3.6225342750549316e-01
    z[6,2,0]  R1635     -5.6179058551788330e-01
    z[6,2,0]  R1636     3.4631749987602234e-01
    z[6,2,0]  R1637     -4.1941487789154053e-01
    z[6,2,0]  R1638     -4.7215002775192261e-01
    z[6,2,0]  R1639     -4.0012276172637939e-01
    z[6,2,0]  R1640     2.7824291586875916e-01
    z[6,2,0]  R1641     4.1739797592163086e-01
    z[6,2,0]  R1642     -4.4357064366340637e-01
    z[6,2,0]  R1643     -3.3242177963256836e-01
    z[6,2,0]  R1644     -4.6058263629674911e-02
    z[6,2,0]  R1645     5.9308332204818726e-01
    z[6,2,0]  R1646     8.7423712015151978e-02
    z[6,2,0]  R1647     -2.8697337955236435e-02
    z[6,2,0]  R1648     5.9080682694911957e-02
    z[6,2,0]  R1649     4.8808166384696960e-01
    z[6,2,0]  R1650     5.8220338821411133e-01
    z[6,2,0]  R1651     -5.9558898210525513e-02
    z[6,2,0]  R1652     1.8688710033893585e-01
    z[6,2,0]  R1653     4.0684661269187927e-01
    z[6,2,0]  R1654     5.0825828313827515e-01
    z[6,2,0]  R1655     3.8950565457344055e-01
    z[6,2,0]  R1656     3.7066829204559326e-01
    z[6,2,0]  R1657     1.5516020357608795e-01
    z[6,2,0]  R1658     4.5007619261741638e-01
    z[6,2,0]  R1659     3.0709198117256165e-01
    z[6,2,0]  R1660     -8.9899547398090363e-02
    z[6,2,0]  R1661     -5.0068795680999756e-01
    z[6,2,0]  R1662     -1.9401873648166656e-01
    z[6,2,0]  R1663     -5.2254962921142578e-01
    z[6,2,0]  R1664     -2.0976625382900238e-01
    z[6,2,0]  R1665     -3.5914450883865356e-01
    z[6,2,0]  R1666     -2.2353176772594452e-01
    z[6,2,0]  R1667     -2.3866747319698334e-01
    z[6,2,0]  R1668     -5.8838635683059692e-01
    z[6,2,0]  R1669     -2.8149381279945374e-01
    z[6,2,0]  R1670     -5.7092517614364624e-01
    z[6,2,0]  R1671     0.227547287940979
    z[6,2,0]  R1672     5.5791920423507690e-01
    z[6,2,0]  R1673     4.3100666999816895e-01
    z[6,2,0]  R1674     1.3391035795211792e-01
    z[6,2,1]  R21       1
    z[6,2,1]  R57       -1
    z[6,2,1]  R1580     -1
    z[6,2,1]  R1581     1
    z[6,2,1]  R1592     -9.0008413791656494e-01
    z[6,2,1]  R1593     4.8491966724395752e-01
    z[6,2,1]  R1594     2.7578523755073547e-01
    z[6,2,1]  R1595     4.0412941575050354e-01
    z[6,2,1]  R1596     -8.4182655811309814e-01
    z[6,2,1]  R1597     3.7795212864875793e-01
    z[6,2,1]  R1598     -4.7477439045906067e-01
    z[6,2,1]  R1599     -8.2168734073638916e-01
    z[6,2,1]  R1600     3.5587257146835327e-01
    z[6,2,1]  R1601     5.9452176094055176e-01
    z[6,2,1]  R1602     5.4028725624084473e-01
    z[6,2,1]  R1603     4.3962958455085754e-01
    z[6,2,1]  R1604     1.2242415547370911e-01
    z[6,2,1]  R1605     4.0875086188316345e-01
    z[6,2,1]  R1606     4.1638728976249695e-01
    z[6,2,1]  R1607     4.0337544679641724e-01
    z[6,2,1]  R1608     4.0010768175125122e-01
    z[6,2,1]  R1609     2.9809844493865967e-01
    z[6,2,1]  R1610     3.8250654935836792e-01
    z[6,2,1]  R1611     2.4132257699966431e-01
    z[6,2,1]  R1612     3.0258321762084961e-01
    z[6,2,1]  R1613     3.1962257623672485e-01
    z[6,2,1]  R1614     5.7955151796340942e-01
    z[6,2,1]  R1615     1.7624391615390778e-01
    z[6,2,1]  R1616     2.0100392401218414e-01
    z[6,2,1]  R1617     -7.4481934309005737e-02
    z[6,2,1]  R1618     2.6645469665527344e-01
    z[6,2,1]  R1619     -5.8485662937164307e-01
    z[6,2,1]  R1620     -3.7440571188926697e-01
    z[6,2,1]  R1621     -6.1355471611022949e-01
    z[6,2,1]  R1622     -2.6705756783485413e-01
    z[6,2,1]  R1623     -7.1646170690655708e-03
    z[6,2,1]  R1624     1.0217893868684769e-01
    z[6,2,1]  R1625     4.0572628378868103e-01
    z[6,2,1]  R1626     3.9647969603538513e-01
    z[6,2,1]  R1627     3.8121148943901062e-01
    z[6,2,1]  R1628     3.7789022922515869e-01
    z[6,2,1]  R1629     -5.6038576364517212e-01
    z[6,2,1]  R1630     -5.3539234399795532e-01
    z[6,2,1]  R1631     -5.6757456064224243e-01
    z[6,2,1]  R1632     4.7778841853141785e-01
    z[6,2,1]  R1633     2.7109444141387939e-01
    z[6,2,1]  R1634     3.9177486300468445e-01
    z[6,2,1]  R1635     4.6451058983802795e-01
    z[6,2,1]  R1636     1.6319791972637177e-01
    z[6,2,1]  R1637     4.5668345689773560e-01
    z[6,2,1]  R1638     -6.4762878417968750e-01
    z[6,2,1]  R1639     -5.0727158784866333e-01
    z[6,2,1]  R1640     -5.3213357925415039e-01
    z[6,2,1]  R1641     -5.4442584514617920e-01
    z[6,2,1]  R1642     4.0950211882591248e-01
    z[6,2,1]  R1643     -6.4772331714630127e-01
    z[6,2,1]  R1644     -4.2938083410263062e-01
    z[6,2,1]  R1645     3.2703793048858643e-01
    z[6,2,1]  R1646     -4.7708502411842346e-01
    z[6,2,1]  R1647     -3.7778580188751221e-01
    z[6,2,1]  R1648     -3.9710542559623718e-01
    z[6,2,1]  R1649     3.7884214520454407e-01
    z[6,2,1]  R1650     3.1807422637939453e-01
    z[6,2,1]  R1651     -5.9290248155593872e-01
    z[6,2,1]  R1652     -7.2246640920639038e-01
    z[6,2,1]  R1653     -5.1898014545440674e-01
    z[6,2,1]  R1654     -5.0235044956207275e-01
    z[6,2,1]  R1655     -4.0276399254798889e-01
    z[6,2,1]  R1656     -7.1195507049560547e-01
    z[6,2,1]  R1657     -5.4251879453659058e-01
    z[6,2,1]  R1658     -4.0479367971420288e-01
    z[6,2,1]  R1659     -8.8276928663253784e-01
    z[6,2,1]  R1660     -5.2685809135437012e-01
    z[6,2,1]  R1661     7.9778659343719482e-01
    z[6,2,1]  R1662     8.5822361707687378e-01
    z[6,2,1]  R1663     0.57748943567276
    z[6,2,1]  R1664     7.6454418897628784e-01
    z[6,2,1]  R1665     6.0351091623306274e-01
    z[6,2,1]  R1666     6.7756199836730957e-01
    z[6,2,1]  R1667     7.5941306352615356e-01
    z[6,2,1]  R1668     4.8605209589004517e-01
    z[6,2,1]  R1669     6.8820118904113770e-01
    z[6,2,1]  R1670     4.4714894890785217e-01
    z[6,2,1]  R1671     -1.3957631587982178e-01
    z[6,2,1]  R1672     1.5866938233375549e-01
    z[6,2,1]  R1673     8.7374888360500336e-02
    z[6,2,1]  R1674     -5.2000995725393295e-02
    z[6,2,2]  R22       1
    z[6,2,2]  R58       -1
    z[6,2,2]  R1582     -1
    z[6,2,2]  R1583     1
    z[6,2,2]  R1592     -2.2932359576225281e-01
    z[6,2,2]  R1593     -6.8683421611785889e-01
    z[6,2,2]  R1594     -5.0153082609176636e-01
    z[6,2,2]  R1595     -6.4585661888122559e-01
    z[6,2,2]  R1596     1.6330896317958832e-01
    z[6,2,2]  R1597     -5.6998163461685181e-01
    z[6,2,2]  R1598     5.9834194183349609e-01
    z[6,2,2]  R1599     -1.1998074501752853e-01
    z[6,2,2]  R1600     -0.644943118095398
    z[6,2,2]  R1601     -4.7349187731742859e-01
    z[6,2,2]  R1602     2.5623485445976257e-01
    z[6,2,2]  R1603     4.7445413470268250e-01
    z[6,2,2]  R1604     -5.6328210048377514e-03
    z[6,2,2]  R1605     1.6692188382148743e-01
    z[6,2,2]  R1606     3.6668628454208374e-01
    z[6,2,2]  R1607     7.6216422021389008e-02
    z[6,2,2]  R1608     2.4714258313179016e-01
    z[6,2,2]  R1609     2.9009503126144409e-01
    z[6,2,2]  R1610     -1.0790310055017471e-01
    z[6,2,2]  R1611     4.0713006258010864e-01
    z[6,2,2]  R1612     2.1538142859935760e-01
    z[6,2,2]  R1613     6.6276490688323975e-01
    z[6,2,2]  R1614     3.0871546268463135e-01
    z[6,2,2]  R1615     2.8660658001899719e-01
    z[6,2,2]  R1616     3.0485492944717407e-01
    z[6,2,2]  R1617     1.6351932287216187e-01
    z[6,2,2]  R1618     6.7355133593082428e-02
    z[6,2,2]  R1619     -5.0796133279800415e-01
    z[6,2,2]  R1620     2.2495531011372805e-03
    z[6,2,2]  R1621     1.5763860195875168e-02
    z[6,2,2]  R1622     1.5075573325157166e-01
    z[6,2,2]  R1623     6.8243521451950073e-01
    z[6,2,2]  R1624     6.0448747873306274e-01
    z[6,2,2]  R1625     2.1318452060222626e-01
    z[6,2,2]  R1626     1.9009378552436829e-01
    z[6,2,2]  R1627     5.0256246328353882e-01
    z[6,2,2]  R1628     4.5426163077354431e-01
    z[6,2,2]  R1629     6.6239468753337860e-02
    z[6,2,2]  R1630     9.6148863434791565e-02
    z[6,2,2]  R1631     -6.8059504032135010e-02
    z[6,2,2]  R1632     6.4776223897933960e-01
    z[6,2,2]  R1633     5.2126592397689819e-01
    z[6,2,2]  R1634     4.7185677289962769e-01
    z[6,2,2]  R1635     7.9380877315998077e-02
    z[6,2,2]  R1636     2.2927826642990112e-01
    z[6,2,2]  R1637     -1.2523406744003296e-01
    z[6,2,2]  R1638     -2.0751677453517914e-02
    z[6,2,2]  R1639     -2.7674663066864014e-01
    z[6,2,2]  R1640     2.1530188620090485e-02
    z[6,2,2]  R1641     -3.0051467474550009e-03
    z[6,2,2]  R1642     -1.7241753637790680e-01
    z[6,2,2]  R1643     -1.3766567409038544e-01
    z[6,2,2]  R1644     4.2141386866569519e-01
    z[6,2,2]  R1645     2.1265690028667450e-01
    z[6,2,2]  R1646     -3.5251066088676453e-01
    z[6,2,2]  R1647     0.394464910030365
    z[6,2,2]  R1648     3.6904075741767883e-01
    z[6,2,2]  R1649     0.0866931602358818
    z[6,2,2]  R1650     -6.8666212260723114e-02
    z[6,2,2]  R1651     3.5933580994606018e-01
    z[6,2,2]  R1652     -3.1633205711841583e-02
    z[6,2,2]  R1653     1.9013518467545509e-02
    z[6,2,2]  R1654     2.0099420845508575e-01
    z[6,2,2]  R1655     5.9181636571884155e-01
    z[6,2,2]  R1656     4.8591491580009460e-01
    z[6,2,2]  R1657     1.9740661978721619e-01
    z[6,2,2]  R1658     3.8579389452934265e-01
    z[6,2,2]  R1659     -7.7522508800029755e-02
    z[6,2,2]  R1660     7.4727272987365723e-01
    z[6,2,2]  R1661     -1.2009497731924057e-01
    z[6,2,2]  R1662     7.6472632586956024e-02
    z[6,2,2]  R1663     3.2745766639709473e-01
    z[6,2,2]  R1664     1.8415714800357819e-01
    z[6,2,2]  R1665     -1.2678658962249756e-01
    z[6,2,2]  R1666     -4.4335469603538513e-01
    z[6,2,2]  R1667     4.9939689040184021e-01
    z[6,2,2]  R1668     -1.5145042538642883e-01
    z[6,2,2]  R1669     9.8478108644485474e-02
    z[6,2,2]  R1670     -5.7115167379379272e-02
    z[6,2,2]  R1671     -5.1285862922668457e-01
    z[6,2,2]  R1672     -0.381136029958725
    z[6,2,2]  R1673     -5.9377545118331909e-01
    z[6,2,2]  R1674     -0.43329918384552
    z[6,2,3]  R23       1
    z[6,2,3]  R59       -1
    z[6,2,3]  R1584     -1
    z[6,2,3]  R1585     1
    z[6,2,3]  R1592     5.1031899638473988e-03
    z[6,2,3]  R1593     -1.4898261427879333e-01
    z[6,2,3]  R1594     -2.8086232021450996e-02
    z[6,2,3]  R1595     5.5436813831329346e-01
    z[6,2,3]  R1596     -3.6988684535026550e-01
    z[6,2,3]  R1597     -1.6029103100299835e-01
    z[6,2,3]  R1598     -2.2525161504745483e-01
    z[6,2,3]  R1599     -4.5653226971626282e-01
    z[6,2,3]  R1600     -2.2042134404182434e-01
    z[6,2,3]  R1601     5.0365632772445679e-01
    z[6,2,3]  R1602     7.7158883213996887e-02
    z[6,2,3]  R1603     -0.557939350605011
    z[6,2,3]  R1604     -3.8787013292312622e-01
    z[6,2,3]  R1605     -7.7670890092849731e-01
    z[6,2,3]  R1606     -7.0972442626953125e-01
    z[6,2,3]  R1607     -3.4640991687774658e-01
    z[6,2,3]  R1608     -7.3124104738235474e-01
    z[6,2,3]  R1609     -5.2422147989273071e-01
    z[6,2,3]  R1610     3.5884547233581543e-01
    z[6,2,3]  R1611     4.0285471081733704e-01
    z[6,2,3]  R1612     -0.759775698184967
    z[6,2,3]  R1613     -5.8142524957656860e-01
    z[6,2,3]  R1614     -4.2721742391586304e-01
    z[6,2,3]  R1615     -5.6639397144317627e-01
    z[6,2,3]  R1616     -7.0367473363876343e-01
    z[6,2,3]  R1617     -1.2777270376682281e-01
    z[6,2,3]  R1618     1.6802865266799927e-01
    z[6,2,3]  R1619     4.2923569679260254e-01
    z[6,2,3]  R1620     1.0206146538257599e-01
    z[6,2,3]  R1621     6.9345241785049438e-01
    z[6,2,3]  R1622     -8.5138714313507080e-01
    z[6,2,3]  R1623     -4.4106084108352661e-01
    z[6,2,3]  R1624     -5.5888414382934570e-01
    z[6,2,3]  R1625     -8.1872475147247314e-01
    z[6,2,3]  R1626     3.7962052226066589e-01
    z[6,2,3]  R1627     -3.3120054006576538e-01
    z[6,2,3]  R1628     -2.5419533252716064e-01
    z[6,2,3]  R1629     4.5828998088836670e-01
    z[6,2,3]  R1630     5.4101234674453735e-01
    z[6,2,3]  R1631     5.4365581274032593e-01
    z[6,2,3]  R1632     -5.8628183603286743e-01
    z[6,2,3]  R1633     -7.3722654581069946e-01
    z[6,2,3]  R1634     -6.0235756635665894e-01
    z[6,2,3]  R1635     -4.5180425047874451e-01
    z[6,2,3]  R1636     -7.7838724851608276e-01
    z[6,2,3]  R1637     1.3046717643737793e-01
    z[6,2,3]  R1638     4.4680750370025635e-01
    z[6,2,3]  R1639     0.547261655330658
    z[6,2,3]  R1640     6.1301314830780029e-01
    z[6,2,3]  R1641     0.675198495388031
    z[6,2,3]  R1642     -2.6835939288139343e-01
    z[6,2,3]  R1643     6.6462028026580811e-01
    z[6,2,3]  R1644     7.6194804906845093e-01
    z[6,2,3]  R1645     5.4782259464263916e-01
    z[6,2,3]  R1646     5.4189068078994751e-01
    z[6,2,3]  R1647     7.3853135108947754e-01
    z[6,2,3]  R1648     7.4501550197601318e-01
    z[6,2,3]  R1649     2.4280984699726105e-01
    z[6,2,3]  R1650     3.2068583369255066e-01
    z[6,2,3]  R1651     -4.1641983389854431e-01
    z[6,2,3]  R1652     -0.581412672996521
    z[6,2,3]  R1653     -3.9674839377403259e-01
    z[6,2,3]  R1654     -2.2573718428611755e-01
    z[6,2,3]  R1655     0.151409313082695
    z[6,2,3]  R1656     1.7278465628623962e-01
    z[6,2,3]  R1657     -2.1413658559322357e-01
    z[6,2,3]  R1658     1.2555651366710663e-01
    z[6,2,3]  R1659     1.1373896151781082e-01
    z[6,2,3]  R1660     -2.2943688556551933e-02
    z[6,2,3]  R1661     9.0139739215373993e-02
    z[6,2,3]  R1662     8.0782070755958557e-02
    z[6,2,3]  R1663     4.3264187872409821e-02
    z[6,2,3]  R1664     2.2799910511821508e-03
    z[6,2,3]  R1665     -3.0812883377075195e-01
    z[6,2,3]  R1666     -0.0792752057313919
    z[6,2,3]  R1667     7.7979043126106262e-02
    z[6,2,3]  R1668     -2.6251441240310669e-01
    z[6,2,3]  R1669     -4.3058654665946960e-01
    z[6,2,3]  R1670     -6.4221984148025513e-01
    z[6,2,3]  R1671     6.5747827291488647e-01
    z[6,2,3]  R1672     6.9999152421951294e-01
    z[6,2,3]  R1673     5.6981217861175537e-01
    z[6,2,3]  R1674     2.0941333472728729e-01
    z[6,2,4]  R24       1
    z[6,2,4]  R60       -1
    z[6,2,4]  R1586     -1
    z[6,2,4]  R1587     1
    z[6,2,4]  R1592     -4.8948537558317184e-02
    z[6,2,4]  R1593     4.3450409173965454e-01
    z[6,2,4]  R1594     3.9758551120758057e-01
    z[6,2,4]  R1595     2.4671699106693268e-01
    z[6,2,4]  R1596     -2.3689439892768860e-01
    z[6,2,4]  R1597     5.3628218173980713e-01
    z[6,2,4]  R1598     4.5758464932441711e-01
    z[6,2,4]  R1599     1.3389259576797485e-01
    z[6,2,4]  R1600     6.1684852838516235e-01
    z[6,2,4]  R1601     -1.2166652828454971e-01
    z[6,2,4]  R1602     -3.7135216593742371e-01
    z[6,2,4]  R1603     -0.354168564081192
    z[6,2,4]  R1604     -2.1554410457611084e-01
    z[6,2,4]  R1605     -9.7739897668361664e-02
    z[6,2,4]  R1606     -8.2521423697471619e-02
    z[6,2,4]  R1607     -4.7443509101867676e-01
    z[6,2,4]  R1608     -3.2872599363327026e-01
    z[6,2,4]  R1609     -9.5027446746826172e-02
    z[6,2,4]  R1610     -6.7304037511348724e-02
    z[6,2,4]  R1611     0.0866825059056282
    z[6,2,4]  R1612     -6.7003101110458374e-02
    z[6,2,4]  R1613     -7.8297823667526245e-02
    z[6,2,4]  R1614     4.3972003459930420e-01
    z[6,2,4]  R1615     3.1733307242393494e-01
    z[6,2,4]  R1616     4.2865127325057983e-01
    z[6,2,4]  R1617     5.1188313961029053e-01
    z[6,2,4]  R1618     0.0507943332195282
    z[6,2,4]  R1619     9.2227414250373840e-02
    z[6,2,4]  R1620     -1.1723274737596512e-01
    z[6,2,4]  R1621     7.0551261305809021e-02
    z[6,2,4]  R1622     2.8297787904739380e-01
    z[6,2,4]  R1623     -4.0528275072574615e-02
    z[6,2,4]  R1624     3.9297146722674370e-03
    z[6,2,4]  R1625     -2.5915073230862617e-02
    z[6,2,4]  R1626     1.1037456989288330e-01
    z[6,2,4]  R1627     -0.0431511253118515
    z[6,2,4]  R1628     -8.1617077812552452e-03
    z[6,2,4]  R1629     -4.2186689376831055e-01
    z[6,2,4]  R1630     -2.3261302709579468e-01
    z[6,2,4]  R1631     -1.6281627118587494e-01
    z[6,2,4]  R1632     8.3653137087821960e-02
    z[6,2,4]  R1633     4.4808998703956604e-02
    z[6,2,4]  R1634     3.5443204641342163e-01
    z[6,2,4]  R1635     -1.3447956740856171e-01
    z[6,2,4]  R1636     1.6174888610839844e-01
    z[6,2,4]  R1637     -1.6961348056793213e-01
    z[6,2,4]  R1638     -2.8872808814048767e-01
    z[6,2,4]  R1639     0.0324304923415184
    z[6,2,4]  R1640     1.1904054135084152e-01
    z[6,2,4]  R1641     1.3996081054210663e-01
    z[6,2,4]  R1642     -6.6272771358489990e-01
    z[6,2,4]  R1643     -2.5161406025290489e-02
    z[6,2,4]  R1644     -1.1635018140077591e-01
    z[6,2,4]  R1645     -1.0016535967588425e-01
    z[6,2,4]  R1646     5.2733731269836426e-01
    z[6,2,4]  R1647     -2.1668742597103119e-01
    z[6,2,4]  R1648     -2.9552593827247620e-01
    z[6,2,4]  R1649     -3.6308676004409790e-01
    z[6,2,4]  R1650     -3.3995696902275085e-01
    z[6,2,4]  R1651     -1.1001219972968102e-03
    z[6,2,4]  R1652     2.8186461329460144e-01
    z[6,2,4]  R1653     5.1787173748016357e-01
    z[6,2,4]  R1654     3.3614826202392578e-01
    z[6,2,4]  R1655     4.3787100911140442e-01
    z[6,2,4]  R1656     -9.2299081385135651e-02
    z[6,2,4]  R1657     4.5325309038162231e-01
    z[6,2,4]  R1658     1.7119120061397552e-01
    z[6,2,4]  R1659     -0.172170028090477
    z[6,2,4]  R1660     1.5981712937355042e-01
    z[6,2,4]  R1661     -9.1165617108345032e-02
    z[6,2,4]  R1662     3.1064444780349731e-01
    z[6,2,4]  R1663     -4.0164259076118469e-01
    z[6,2,4]  R1664     -0.0375276580452919
    z[6,2,4]  R1665     -2.1597084403038025e-01
    z[6,2,4]  R1666     -2.6986721158027649e-01
    z[6,2,4]  R1667     2.0343777537345886e-01
    z[6,2,4]  R1668     -4.7412395477294922e-01
    z[6,2,4]  R1669     2.9025465250015259e-01
    z[6,2,4]  R1670     4.0439318865537643e-02
    z[6,2,4]  R1671     3.3689764142036438e-01
    z[6,2,4]  R1672     5.4812509566545486e-02
    z[6,2,4]  R1673     3.5733726620674133e-01
    z[6,2,4]  R1674     -3.7407171726226807e-01
    z[6,2,5]  R25       1
    z[6,2,5]  R61       -1
    z[6,2,5]  R1588     -1
    z[6,2,5]  R1589     1
    z[6,2,5]  R1592     -4.1539106518030167e-02
    z[6,2,5]  R1593     2.2819447517395020e-01
    z[6,2,5]  R1594     1.7619884014129639e-01
    z[6,2,5]  R1595     1.3112403452396393e-01
    z[6,2,5]  R1596     1.2630765140056610e-01
    z[6,2,5]  R1597     3.9634126424789429e-01
    z[6,2,5]  R1598     -6.1755768954753876e-02
    z[6,2,5]  R1599     -1.6362796723842621e-01
    z[6,2,5]  R1600     -0.00947926752269268
    z[6,2,5]  R1601     3.7716919183731079e-01
    z[6,2,5]  R1602     -1.2126628309488297e-01
    z[6,2,5]  R1603     -8.2264598459005356e-03
    z[6,2,5]  R1604     7.7099567651748657e-01
    z[6,2,5]  R1605     -9.8559595644474030e-02
    z[6,2,5]  R1606     -3.2236614823341370e-01
    z[6,2,5]  R1607     -3.8575440645217896e-01
    z[6,2,5]  R1608     2.7779513597488403e-01
    z[6,2,5]  R1609     -4.8051732778549194e-01
    z[6,2,5]  R1610     -7.7186834812164307e-01
    z[6,2,5]  R1611     -4.4081023335456848e-01
    z[6,2,5]  R1612     4.9419414997100830e-01
    z[6,2,5]  R1613     -9.7955256700515747e-02
    z[6,2,5]  R1614     -0.336814820766449
    z[6,2,5]  R1615     -5.7692015171051025e-01
    z[6,2,5]  R1616     1.9828870892524719e-01
    z[6,2,5]  R1617     0.127718985080719
    z[6,2,5]  R1618     -7.1706116199493408e-01
    z[6,2,5]  R1619     4.2671549320220947e-01
    z[6,2,5]  R1620     -6.1563742160797119e-01
    z[6,2,5]  R1621     -4.0803611278533936e-02
    z[6,2,5]  R1622     2.2335672378540039e-01
    z[6,2,5]  R1623     4.1427803039550781e-01
    z[6,2,5]  R1624     -1.2038338184356689e-01
    z[6,2,5]  R1625     9.2470802366733551e-02
    z[6,2,5]  R1626     3.5213101655244827e-02
    z[6,2,5]  R1627     8.0370604991912842e-02
    z[6,2,5]  R1628     0.667449414730072
    z[6,2,5]  R1629     -2.9559394717216492e-01
    z[6,2,5]  R1630     -5.7194280624389648e-01
    z[6,2,5]  R1631     -3.8481815718114376e-03
    z[6,2,5]  R1632     2.5344986468553543e-02
    z[6,2,5]  R1633     2.5290971994400024e-01
    z[6,2,5]  R1634     -2.8588702902197838e-02
    z[6,2,5]  R1635     -4.4346663355827332e-01
    z[6,2,5]  R1636     -2.3948095738887787e-01
    z[6,2,5]  R1637     -7.2092288732528687e-01
    z[6,2,5]  R1638     -2.1446606516838074e-01
    z[6,2,5]  R1639     -4.3531975150108337e-01
    z[6,2,5]  R1640     -4.8618495464324951e-01
    z[6,2,5]  R1641     -6.1701752245426178e-02
    z[6,2,5]  R1642     1.9499303773045540e-02
    z[6,2,5]  R1643     -8.5549950599670410e-02
    z[6,2,5]  R1644     1.8580843508243561e-01
    z[6,2,5]  R1645     -4.3025019764900208e-01
    z[6,2,5]  R1646     -1.3461917638778687e-01
    z[6,2,5]  R1647     -9.5116794109344482e-02
    z[6,2,5]  R1648     0.000767854624427855
    z[6,2,5]  R1649     -5.7054489850997925e-01
    z[6,2,5]  R1650     -4.8150390386581421e-01
    z[6,2,5]  R1651     5.8147519826889038e-01
    z[6,2,5]  R1652     -1.3164943456649780e-01
    z[6,2,5]  R1653     0.369782954454422
    z[6,2,5]  R1654     -1.2190397083759308e-01
    z[6,2,5]  R1655     3.2342159748077393e-01
    z[6,2,5]  R1656     -5.2841216325759888e-02
    z[6,2,5]  R1657     3.4322327375411987e-01
    z[6,2,5]  R1658     6.2322318553924561e-01
    z[6,2,5]  R1659     8.4276765584945679e-02
    z[6,2,5]  R1660     -5.3143654018640518e-02
    z[6,2,5]  R1661     1.3258161488920450e-03
    z[6,2,5]  R1662     3.2388001680374146e-01
    z[6,2,5]  R1663     -8.1217736005783081e-02
    z[6,2,5]  R1664     -1.0150302201509476e-01
    z[6,2,5]  R1665     2.2486111521720886e-01
    z[6,2,5]  R1666     2.5098431110382080e-01
    z[6,2,5]  R1667     -5.9654969722032547e-02
    z[6,2,5]  R1668     -4.1578780859708786e-02
    z[6,2,5]  R1669     7.0019364356994629e-02
    z[6,2,5]  R1670     -0.144505113363266
    z[6,2,5]  R1671     8.7805442512035370e-02
    z[6,2,5]  R1672     6.7401833832263947e-02
    z[6,2,5]  R1673     -0.0353923924267292
    z[6,2,5]  R1674     -7.2828090190887451e-01
    z[6,2,6]  R26       1
    z[6,2,6]  R62       -1
    z[6,2,6]  R1590     -1
    z[6,2,6]  R1591     1
    z[6,2,6]  R1592     2.6531422138214111e-01
    z[6,2,6]  R1593     1.2754152715206146e-01
    z[6,2,6]  R1594     1.3739053905010223e-01
    z[6,2,6]  R1595     1.5865311026573181e-01
    z[6,2,6]  R1596     -1.2897776067256927e-01
    z[6,2,6]  R1597     5.1337309181690216e-02
    z[6,2,6]  R1598     3.5426083207130432e-01
    z[6,2,6]  R1599     -2.1180485188961029e-01
    z[6,2,6]  R1600     -1.6379144787788391e-01
    z[6,2,6]  R1601     6.9629065692424774e-02
    z[6,2,6]  R1602     1.1301308125257492e-01
    z[6,2,6]  R1603     -0.0913948118686676
    z[6,2,6]  R1604     -1.2146764993667603e-01
    z[6,2,6]  R1605     -3.8080912828445435e-01
    z[6,2,6]  R1606     -2.7549448609352112e-01
    z[6,2,6]  R1607     -4.1617578268051147e-01
    z[6,2,6]  R1608     -2.3799885809421539e-01
    z[6,2,6]  R1609     -3.3573645353317261e-01
    z[6,2,6]  R1610     -8.6897037923336029e-02
    z[6,2,6]  R1611     -4.7503328323364258e-01
    z[6,2,6]  R1612     -1.4641021192073822e-01
    z[6,2,6]  R1613     -1.2273354083299637e-01
    z[6,2,6]  R1614     4.0288589894771576e-02
    z[6,2,6]  R1615     -2.5131475925445557e-01
    z[6,2,6]  R1616     -6.5688163042068481e-02
    z[6,2,6]  R1617     2.0194327458739281e-02
    z[6,2,6]  R1618     -3.3444055914878845e-01
    z[6,2,6]  R1619     1.5683636069297791e-01
    z[6,2,6]  R1620     1.6815623268485069e-02
    z[6,2,6]  R1621     -7.5065419077873230e-02
    z[6,2,6]  R1622     -4.6393796801567078e-02
    z[6,2,6]  R1623     9.8258063197135925e-02
    z[6,2,6]  R1624     -1.5908671915531158e-01
    z[6,2,6]  R1625     -2.9051387310028076e-01
    z[6,2,6]  R1626     -6.2175148725509644e-01
    z[6,2,6]  R1627     -4.0989780426025391e-01
    z[6,2,6]  R1628     3.0348291993141174e-01
    z[6,2,6]  R1629     1.2335287779569626e-01
    z[6,2,6]  R1630     7.8560203313827515e-02
    z[6,2,6]  R1631     2.9827767610549927e-01
    z[6,2,6]  R1632     0.0264901053160429
    z[6,2,6]  R1633     -6.8063624203205109e-02
    z[6,2,6]  R1634     -5.7983744889497757e-02
    z[6,2,6]  R1635     -2.0843598246574402e-01
    z[6,2,6]  R1636     -3.3385860919952393e-01
    z[6,2,6]  R1637     -1.8527679145336151e-01
    z[6,2,6]  R1638     1.6800068318843842e-01
    z[6,2,6]  R1639     1.2624703347682953e-01
    z[6,2,6]  R1640     1.1233668774366379e-01
    z[6,2,6]  R1641     2.2378845512866974e-01
    z[6,2,6]  R1642     -0.306953102350235
    z[6,2,6]  R1643     3.6419898271560669e-02
    z[6,2,6]  R1644     -0.0854058712720871
    z[6,2,6]  R1645     -2.8591899201273918e-02
    z[6,2,6]  R1646     2.2501243650913239e-01
    z[6,2,6]  R1647     -3.1531330943107605e-01
    z[6,2,6]  R1648     2.4544094502925873e-01
    z[6,2,6]  R1649     -3.0729341506958008e-01
    z[6,2,6]  R1650     -3.2387769222259521e-01
    z[6,2,6]  R1651     -6.5398856997489929e-02
    z[6,2,6]  R1652     -8.5410483181476593e-02
    z[6,2,6]  R1653     -4.9335431307554245e-02
    z[6,2,6]  R1654     -5.1971656084060669e-01
    z[6,2,6]  R1655     1.2869545817375183e-01
    z[6,2,6]  R1656     -2.8008174896240234e-01
    z[6,2,6]  R1657     0.523004949092865
    z[6,2,6]  R1658     -2.2640366852283478e-01
    z[6,2,6]  R1659     2.6593515276908875e-01
    z[6,2,6]  R1660     3.5641238093376160e-01
    z[6,2,6]  R1661     2.8633415699005127e-01
    z[6,2,6]  R1662     1.0971251875162125e-01
    z[6,2,6]  R1663     -3.4122490882873535e-01
    z[6,2,6]  R1664     -5.7082408666610718e-01
    z[6,2,6]  R1665     -5.4641157388687134e-01
    z[6,2,6]  R1666     -3.9022284746170044e-01
    z[6,2,6]  R1667     -2.5672206282615662e-01
    z[6,2,6]  R1668     -3.1493085622787476e-01
    z[6,2,6]  R1669     -4.0359282493591309e-01
    z[6,2,6]  R1670     -1.8941122293472290e-01
    z[6,2,6]  R1671     -3.3500626683235168e-01
    z[6,2,6]  R1672     1.4404852688312531e-01
    z[6,2,6]  R1673     -2.0026246085762978e-02
    z[6,2,6]  R1674     -2.7827879786491394e-01
    z[3,6,0]  R29       -1
    z[3,6,0]  R56       1
    z[3,6,0]  R1675     -1
    z[3,6,0]  R1676     1
    z[3,6,0]  R1689     2.1070216596126556e-01
    z[3,6,0]  R1690     2.3706804215908051e-01
    z[3,6,0]  R1691     -3.3032408356666565e-01
    z[3,6,0]  R1692     -5.0689097493886948e-02
    z[3,6,0]  R1693     9.3185283243656158e-02
    z[3,6,0]  R1694     -3.8340926170349121e-01
    z[3,6,0]  R1695     -3.6293300986289978e-01
    z[3,6,0]  R1696     -1.4409963786602020e-01
    z[3,6,0]  R1697     -2.8153423219919205e-02
    z[3,6,0]  R1698     -1.4287948608398438e-01
    z[3,6,0]  R1699     5.0730270147323608e-01
    z[3,6,0]  R1700     6.8103051185607910e-01
    z[3,6,0]  R1701     3.9166036248207092e-01
    z[3,6,0]  R1702     -4.2965531349182129e-01
    z[3,6,0]  R1703     2.3904596269130707e-01
    z[3,6,0]  R1704     6.1169892549514771e-01
    z[3,6,0]  R1705     -0.323994904756546
    z[3,6,0]  R1706     -0.660135805606842
    z[3,6,0]  R1707     -5.5857664346694946e-01
    z[3,6,0]  R1708     -6.2961035966873169e-01
    z[3,6,0]  R1709     3.1452909111976624e-02
    z[3,6,0]  R1710     7.4064075946807861e-01
    z[3,6,0]  R1711     -1.7483724653720856e-01
    z[3,6,0]  R1712     -1.1822493746876717e-02
    z[3,6,0]  R1713     1.3173650205135345e-01
    z[3,6,0]  R1714     -2.4004104733467102e-01
    z[3,6,0]  R1715     3.2079127430915833e-01
    z[3,6,0]  R1716     0.62704998254776
    z[3,6,0]  R1717     -4.3412479758262634e-01
    z[3,6,0]  R1718     -4.8567795753479004e-01
    z[3,6,0]  R1719     3.8553151488304138e-01
    z[3,6,0]  R1720     2.3259313404560089e-01
    z[3,6,0]  R1721     -4.1952177882194519e-01
    z[3,6,0]  R1722     7.0278279483318329e-02
    z[3,6,0]  R1723     -1.0878144204616547e-01
    z[3,6,0]  R1724     -2.0737315714359283e-01
    z[3,6,0]  R1725     -1.4528167247772217e-01
    z[3,6,0]  R1726     -3.0842933058738708e-01
    z[3,6,0]  R1727     -5.4398483037948608e-01
    z[3,6,0]  R1728     -4.3852820992469788e-01
    z[3,6,0]  R1729     2.5043988227844238e-01
    z[3,6,0]  R1730     -1.1739933490753174e-01
    z[3,6,0]  R1731     -6.8089950084686279e-01
    z[3,6,0]  R1732     9.4819717109203339e-02
    z[3,6,0]  R1733     1.9782318174839020e-01
    z[3,6,0]  R1734     -2.4343258142471313e-01
    z[3,6,0]  R1735     -1.6474086046218872e-01
    z[3,6,0]  R1736     1.1158072203397751e-01
    z[3,6,0]  R1737     0.0373874306678772
    z[3,6,0]  R1738     -8.2292415201663971e-02
    z[3,6,0]  R1739     -6.8636733293533325e-01
    z[3,6,0]  R1740     -3.6941394209861755e-01
    z[3,6,0]  R1741     4.2295315861701965e-01
    z[3,6,0]  R1742     1.9365036487579346e-01
    z[3,6,0]  R1743     -4.2744394391775131e-02
    z[3,6,0]  R1744     -4.0544059872627258e-01
    z[3,6,0]  R1745     -0.047398891299963
    z[3,6,0]  R1746     -4.4668549299240112e-01
    z[3,6,0]  R1747     -3.2467502355575562e-01
    z[3,6,0]  R1748     -4.3154659867286682e-01
    z[3,6,0]  R1749     1.2100342661142349e-01
    z[3,6,0]  R1750     2.9956543445587158e-01
    z[3,6,0]  R1751     -2.7906802296638489e-01
    z[3,6,0]  R1752     2.6324215531349182e-01
    z[3,6,0]  R1753     3.7964138388633728e-01
    z[3,6,0]  R1754     8.2014858722686768e-01
    z[3,6,0]  R1755     -5.1732414960861206e-01
    z[3,6,0]  R1756     2.2022904828190804e-02
    z[3,6,0]  R1757     -6.7554646730422974e-01
    z[3,6,0]  R1758     -3.6076098680496216e-01
    z[3,6,0]  R1759     -2.2130471467971802e-01
    z[3,6,0]  R1760     3.9594525098800659e-01
    z[3,6,0]  R1761     5.2152341604232788e-01
    z[3,6,0]  R1762     1.6126877069473267e-01
    z[3,6,0]  R1763     -5.1240515708923340e-01
    z[3,6,0]  R1764     -5.6220752000808716e-01
    z[3,6,0]  R1765     -2.2039239108562469e-01
    z[3,6,0]  R1766     -4.3702054023742676e-01
    z[3,6,0]  R1767     -1.5497425198554993e-01
    z[3,6,0]  R1768     -5.1202714443206787e-01
    z[3,6,0]  R1769     7.3430542834103107e-03
    z[3,6,0]  R1770     2.0170010626316071e-01
    z[3,6,0]  R1771     3.6225342750549316e-01
    z[3,6,0]  R1772     -5.6179058551788330e-01
    z[3,6,0]  R1773     3.4631749987602234e-01
    z[3,6,0]  R1774     -4.1941487789154053e-01
    z[3,6,0]  R1775     -4.7215002775192261e-01
    z[3,6,0]  R1776     -4.0012276172637939e-01
    z[3,6,0]  R1777     2.7824291586875916e-01
    z[3,6,0]  R1778     4.1739797592163086e-01
    z[3,6,0]  R1779     -4.4357064366340637e-01
    z[3,6,0]  R1780     -3.3242177963256836e-01
    z[3,6,0]  R1781     -4.6058263629674911e-02
    z[3,6,0]  R1782     5.9308332204818726e-01
    z[3,6,0]  R1783     8.7423712015151978e-02
    z[3,6,0]  R1784     -2.8697337955236435e-02
    z[3,6,0]  R1785     5.9080682694911957e-02
    z[3,6,0]  R1786     4.8808166384696960e-01
    z[3,6,0]  R1787     5.8220338821411133e-01
    z[3,6,1]  R30       -1
    z[3,6,1]  R57       1
    z[3,6,1]  R1677     -1
    z[3,6,1]  R1678     1
    z[3,6,1]  R1689     -7.3202508687973022e-01
    z[3,6,1]  R1690     -8.9609622955322266e-01
    z[3,6,1]  R1691     -8.7818670272827148e-01
    z[3,6,1]  R1692     -6.6387432813644409e-01
    z[3,6,1]  R1693     -6.4120382070541382e-01
    z[3,6,1]  R1694     4.5675918459892273e-01
    z[3,6,1]  R1695     3.6966803669929504e-01
    z[3,6,1]  R1696     4.6123948693275452e-01
    z[3,6,1]  R1697     4.6623924374580383e-01
    z[3,6,1]  R1698     0.478381484746933
    z[3,6,1]  R1699     -1.7955128848552704e-01
    z[3,6,1]  R1700     -3.4282706677913666e-02
    z[3,6,1]  R1701     -5.4561026394367218e-02
    z[3,6,1]  R1702     7.4065822362899780e-01
    z[3,6,1]  R1703     8.4010857343673706e-01
    z[3,6,1]  R1704     6.7208075523376465e-01
    z[3,6,1]  R1705     1.6775736585259438e-02
    z[3,6,1]  R1706     2.0863661170005798e-01
    z[3,6,1]  R1707     -1.2913960963487625e-02
    z[3,6,1]  R1708     0.288901686668396
    z[3,6,1]  R1709     -4.1288891434669495e-01
    z[3,6,1]  R1710     -4.0469425916671753e-01
    z[3,6,1]  R1711     8.2116818428039551e-01
    z[3,6,1]  R1712     7.7963519096374512e-01
    z[3,6,1]  R1713     7.3115426301956177e-01
    z[3,6,1]  R1714     9.0361751616001129e-02
    z[3,6,1]  R1715     -2.7667286992073059e-01
    z[3,6,1]  R1716     0.628728449344635
    z[3,6,1]  R1717     -4.3045710772275925e-02
    z[3,6,1]  R1718     -2.8077220544219017e-02
    z[3,6,1]  R1719     -2.6363173127174377e-01
    z[3,6,1]  R1720     7.4782872200012207e-01
    z[3,6,1]  R1721     4.1568708419799805e-01
    z[3,6,1]  R1722     -5.7474941015243530e-02
    z[3,6,1]  R1723     3.9827597141265869e-01
    z[3,6,1]  R1724     -1.1768517643213272e-01
    z[3,6,1]  R1725     -3.6511268466711044e-02
    z[3,6,1]  R1726     2.0624291151762009e-02
    z[3,6,1]  R1727     1.7866080999374390e-01
    z[3,6,1]  R1728     1.8642188608646393e-01
    z[3,6,1]  R1729     -9.0008413791656494e-01
    z[3,6,1]  R1730     4.8491966724395752e-01
    z[3,6,1]  R1731     2.7578523755073547e-01
    z[3,6,1]  R1732     4.0412941575050354e-01
    z[3,6,1]  R1733     -8.4182655811309814e-01
    z[3,6,1]  R1734     3.7795212864875793e-01
    z[3,6,1]  R1735     -4.7477439045906067e-01
    z[3,6,1]  R1736     -8.2168734073638916e-01
    z[3,6,1]  R1737     3.5587257146835327e-01
    z[3,6,1]  R1738     5.9452176094055176e-01
    z[3,6,1]  R1739     5.4028725624084473e-01
    z[3,6,1]  R1740     4.3962958455085754e-01
    z[3,6,1]  R1741     1.2242415547370911e-01
    z[3,6,1]  R1742     4.0875086188316345e-01
    z[3,6,1]  R1743     4.1638728976249695e-01
    z[3,6,1]  R1744     4.0337544679641724e-01
    z[3,6,1]  R1745     4.0010768175125122e-01
    z[3,6,1]  R1746     2.9809844493865967e-01
    z[3,6,1]  R1747     3.8250654935836792e-01
    z[3,6,1]  R1748     2.4132257699966431e-01
    z[3,6,1]  R1749     3.0258321762084961e-01
    z[3,6,1]  R1750     3.1962257623672485e-01
    z[3,6,1]  R1751     5.7955151796340942e-01
    z[3,6,1]  R1752     1.7624391615390778e-01
    z[3,6,1]  R1753     2.0100392401218414e-01
    z[3,6,1]  R1754     -7.4481934309005737e-02
    z[3,6,1]  R1755     2.6645469665527344e-01
    z[3,6,1]  R1756     -5.8485662937164307e-01
    z[3,6,1]  R1757     -3.7440571188926697e-01
    z[3,6,1]  R1758     -6.1355471611022949e-01
    z[3,6,1]  R1759     -2.6705756783485413e-01
    z[3,6,1]  R1760     -7.1646170690655708e-03
    z[3,6,1]  R1761     1.0217893868684769e-01
    z[3,6,1]  R1762     4.0572628378868103e-01
    z[3,6,1]  R1763     3.9647969603538513e-01
    z[3,6,1]  R1764     3.8121148943901062e-01
    z[3,6,1]  R1765     3.7789022922515869e-01
    z[3,6,1]  R1766     -5.6038576364517212e-01
    z[3,6,1]  R1767     -5.3539234399795532e-01
    z[3,6,1]  R1768     -5.6757456064224243e-01
    z[3,6,1]  R1769     4.7778841853141785e-01
    z[3,6,1]  R1770     2.7109444141387939e-01
    z[3,6,1]  R1771     3.9177486300468445e-01
    z[3,6,1]  R1772     4.6451058983802795e-01
    z[3,6,1]  R1773     1.6319791972637177e-01
    z[3,6,1]  R1774     4.5668345689773560e-01
    z[3,6,1]  R1775     -6.4762878417968750e-01
    z[3,6,1]  R1776     -5.0727158784866333e-01
    z[3,6,1]  R1777     -5.3213357925415039e-01
    z[3,6,1]  R1778     -5.4442584514617920e-01
    z[3,6,1]  R1779     4.0950211882591248e-01
    z[3,6,1]  R1780     -6.4772331714630127e-01
    z[3,6,1]  R1781     -4.2938083410263062e-01
    z[3,6,1]  R1782     3.2703793048858643e-01
    z[3,6,1]  R1783     -4.7708502411842346e-01
    z[3,6,1]  R1784     -3.7778580188751221e-01
    z[3,6,1]  R1785     -3.9710542559623718e-01
    z[3,6,1]  R1786     3.7884214520454407e-01
    z[3,6,1]  R1787     3.1807422637939453e-01
    z[3,6,2]  R31       -1
    z[3,6,2]  R58       1
    z[3,6,2]  R1679     -1
    z[3,6,2]  R1680     1
    z[3,6,2]  R1689     6.1484199762344360e-01
    z[3,6,2]  R1690     -2.5353688001632690e-01
    z[3,6,2]  R1691     4.6989362686872482e-02
    z[3,6,2]  R1692     9.8646752536296844e-02
    z[3,6,2]  R1693     -0.305441290140152
    z[3,6,2]  R1694     -6.2570393085479736e-01
    z[3,6,2]  R1695     -6.9680237770080566e-01
    z[3,6,2]  R1696     -6.4595109224319458e-01
    z[3,6,2]  R1697     -6.7250245809555054e-01
    z[3,6,2]  R1698     -5.6332510709762573e-01
    z[3,6,2]  R1699     -4.0046057105064392e-01
    z[3,6,2]  R1700     4.2531597428023815e-03
    z[3,6,2]  R1701     1.0870019346475601e-01
    z[3,6,2]  R1702     -2.6488453149795532e-01
    z[3,6,2]  R1703     2.9680223669856787e-03
    z[3,6,2]  R1704     -4.3982964009046555e-02
    z[3,6,2]  R1705     3.6153453588485718e-01
    z[3,6,2]  R1706     5.5275034904479980e-01
    z[3,6,2]  R1707     4.6292573213577271e-01
    z[3,6,2]  R1708     5.3264069557189941e-01
    z[3,6,2]  R1709     2.2463642060756683e-01
    z[3,6,2]  R1710     -1.6830703616142273e-01
    z[3,6,2]  R1711     -3.9099535346031189e-01
    z[3,6,2]  R1712     -3.8344052433967590e-01
    z[3,6,2]  R1713     -2.6987469196319580e-01
    z[3,6,2]  R1714     -0.394153892993927
    z[3,6,2]  R1715     -5.5422164499759674e-02
    z[3,6,2]  R1716     -4.2012721300125122e-01
    z[3,6,2]  R1717     4.4082674384117126e-01
    z[3,6,2]  R1718     3.8484206795692444e-01
    z[3,6,2]  R1719     -2.6140862703323364e-01
    z[3,6,2]  R1720     -4.0695735812187195e-01
    z[3,6,2]  R1721     -5.0352096557617188e-01
    z[3,6,2]  R1722     1.1228688061237335e-01
    z[3,6,2]  R1723     -6.3518583774566650e-01
    z[3,6,2]  R1724     3.1060567498207092e-01
    z[3,6,2]  R1725     2.3794180154800415e-01
    z[3,6,2]  R1726     3.5464078187942505e-01
    z[3,6,2]  R1727     5.6184995174407959e-01
    z[3,6,2]  R1728     0.663927435874939
    z[3,6,2]  R1729     -2.2932359576225281e-01
    z[3,6,2]  R1730     -6.8683421611785889e-01
    z[3,6,2]  R1731     -5.0153082609176636e-01
    z[3,6,2]  R1732     -6.4585661888122559e-01
    z[3,6,2]  R1733     1.6330896317958832e-01
    z[3,6,2]  R1734     -5.6998163461685181e-01
    z[3,6,2]  R1735     5.9834194183349609e-01
    z[3,6,2]  R1736     -1.1998074501752853e-01
    z[3,6,2]  R1737     -0.644943118095398
    z[3,6,2]  R1738     -4.7349187731742859e-01
    z[3,6,2]  R1739     2.5623485445976257e-01
    z[3,6,2]  R1740     4.7445413470268250e-01
    z[3,6,2]  R1741     -5.6328210048377514e-03
    z[3,6,2]  R1742     1.6692188382148743e-01
    z[3,6,2]  R1743     3.6668628454208374e-01
    z[3,6,2]  R1744     7.6216422021389008e-02
    z[3,6,2]  R1745     2.4714258313179016e-01
    z[3,6,2]  R1746     2.9009503126144409e-01
    z[3,6,2]  R1747     -1.0790310055017471e-01
    z[3,6,2]  R1748     4.0713006258010864e-01
    z[3,6,2]  R1749     2.1538142859935760e-01
    z[3,6,2]  R1750     6.6276490688323975e-01
    z[3,6,2]  R1751     3.0871546268463135e-01
    z[3,6,2]  R1752     2.8660658001899719e-01
    z[3,6,2]  R1753     3.0485492944717407e-01
    z[3,6,2]  R1754     1.6351932287216187e-01
    z[3,6,2]  R1755     6.7355133593082428e-02
    z[3,6,2]  R1756     -5.0796133279800415e-01
    z[3,6,2]  R1757     2.2495531011372805e-03
    z[3,6,2]  R1758     1.5763860195875168e-02
    z[3,6,2]  R1759     1.5075573325157166e-01
    z[3,6,2]  R1760     6.8243521451950073e-01
    z[3,6,2]  R1761     6.0448747873306274e-01
    z[3,6,2]  R1762     2.1318452060222626e-01
    z[3,6,2]  R1763     1.9009378552436829e-01
    z[3,6,2]  R1764     5.0256246328353882e-01
    z[3,6,2]  R1765     4.5426163077354431e-01
    z[3,6,2]  R1766     6.6239468753337860e-02
    z[3,6,2]  R1767     9.6148863434791565e-02
    z[3,6,2]  R1768     -6.8059504032135010e-02
    z[3,6,2]  R1769     6.4776223897933960e-01
    z[3,6,2]  R1770     5.2126592397689819e-01
    z[3,6,2]  R1771     4.7185677289962769e-01
    z[3,6,2]  R1772     7.9380877315998077e-02
    z[3,6,2]  R1773     2.2927826642990112e-01
    z[3,6,2]  R1774     -1.2523406744003296e-01
    z[3,6,2]  R1775     -2.0751677453517914e-02
    z[3,6,2]  R1776     -2.7674663066864014e-01
    z[3,6,2]  R1777     2.1530188620090485e-02
    z[3,6,2]  R1778     -3.0051467474550009e-03
    z[3,6,2]  R1779     -1.7241753637790680e-01
    z[3,6,2]  R1780     -1.3766567409038544e-01
    z[3,6,2]  R1781     4.2141386866569519e-01
    z[3,6,2]  R1782     2.1265690028667450e-01
    z[3,6,2]  R1783     -3.5251066088676453e-01
    z[3,6,2]  R1784     0.394464910030365
    z[3,6,2]  R1785     3.6904075741767883e-01
    z[3,6,2]  R1786     0.0866931602358818
    z[3,6,2]  R1787     -6.8666212260723114e-02
    z[3,6,3]  R32       -1
    z[3,6,3]  R59       1
    z[3,6,3]  R1681     -1
    z[3,6,3]  R1682     1
    z[3,6,3]  R1689     3.5248868167400360e-02
    z[3,6,3]  R1690     3.2933041453361511e-02
    z[3,6,3]  R1691     -1.3289515674114227e-01
    z[3,6,3]  R1692     6.1468955129384995e-02
    z[3,6,3]  R1693     -4.1365999728441238e-02
    z[3,6,3]  R1694     -1.0824655741453171e-01
    z[3,6,3]  R1695     2.5173410773277283e-01
    z[3,6,3]  R1696     0.491875022649765
    z[3,6,3]  R1697     -2.2320429980754852e-01
    z[3,6,3]  R1698     0.630195677280426
    z[3,6,3]  R1699     -3.8113251328468323e-01
    z[3,6,3]  R1700     -7.2333496809005737e-01
    z[3,6,3]  R1701     -2.1607159078121185e-01
    z[3,6,3]  R1702     4.6063192188739777e-02
    z[3,6,3]  R1703     1.5683244168758392e-01
    z[3,6,3]  R1704     2.8763899207115173e-01
    z[3,6,3]  R1705     -5.9141445159912109e-01
    z[3,6,3]  R1706     -3.6886084079742432e-01
    z[3,6,3]  R1707     -3.8016214966773987e-01
    z[3,6,3]  R1708     -3.9001065492630005e-01
    z[3,6,3]  R1709     -0.0961623340845108
    z[3,6,3]  R1710     -2.6174640655517578e-01
    z[3,6,3]  R1711     3.2039511948823929e-02
    z[3,6,3]  R1712     1.8101747334003448e-01
    z[3,6,3]  R1713     7.0701591670513153e-02
    z[3,6,3]  R1714     6.4919614791870117e-01
    z[3,6,3]  R1715     1.1243601888418198e-01
    z[3,6,3]  R1716     1.3497139513492584e-01
    z[3,6,3]  R1717     -5.8058238029479980e-01
    z[3,6,3]  R1718     -6.8739497661590576e-01
    z[3,6,3]  R1719     -2.4818925559520721e-01
    z[3,6,3]  R1720     3.9486980438232422e-01
    z[3,6,3]  R1721     1.2522846460342407e-01
    z[3,6,3]  R1722     -4.3856918811798096e-01
    z[3,6,3]  R1723     -1.0970503836870193e-01
    z[3,6,3]  R1724     -8.2041013240814209e-01
    z[3,6,3]  R1725     -8.6618643999099731e-01
    z[3,6,3]  R1726     -6.7323404550552368e-01
    z[3,6,3]  R1727     -5.3538322448730469e-01
    z[3,6,3]  R1728     -4.3027156591415405e-01
    z[3,6,3]  R1729     5.1031899638473988e-03
    z[3,6,3]  R1730     -1.4898261427879333e-01
    z[3,6,3]  R1731     -2.8086232021450996e-02
    z[3,6,3]  R1732     5.5436813831329346e-01
    z[3,6,3]  R1733     -3.6988684535026550e-01
    z[3,6,3]  R1734     -1.6029103100299835e-01
    z[3,6,3]  R1735     -2.2525161504745483e-01
    z[3,6,3]  R1736     -4.5653226971626282e-01
    z[3,6,3]  R1737     -2.2042134404182434e-01
    z[3,6,3]  R1738     5.0365632772445679e-01
    z[3,6,3]  R1739     7.7158883213996887e-02
    z[3,6,3]  R1740     -0.557939350605011
    z[3,6,3]  R1741     -3.8787013292312622e-01
    z[3,6,3]  R1742     -7.7670890092849731e-01
    z[3,6,3]  R1743     -7.0972442626953125e-01
    z[3,6,3]  R1744     -3.4640991687774658e-01
    z[3,6,3]  R1745     -7.3124104738235474e-01
    z[3,6,3]  R1746     -5.2422147989273071e-01
    z[3,6,3]  R1747     3.5884547233581543e-01
    z[3,6,3]  R1748     4.0285471081733704e-01
    z[3,6,3]  R1749     -0.759775698184967
    z[3,6,3]  R1750     -5.8142524957656860e-01
    z[3,6,3]  R1751     -4.2721742391586304e-01
    z[3,6,3]  R1752     -5.6639397144317627e-01
    z[3,6,3]  R1753     -7.0367473363876343e-01
    z[3,6,3]  R1754     -1.2777270376682281e-01
    z[3,6,3]  R1755     1.6802865266799927e-01
    z[3,6,3]  R1756     4.2923569679260254e-01
    z[3,6,3]  R1757     1.0206146538257599e-01
    z[3,6,3]  R1758     6.9345241785049438e-01
    z[3,6,3]  R1759     -8.5138714313507080e-01
    z[3,6,3]  R1760     -4.4106084108352661e-01
    z[3,6,3]  R1761     -5.5888414382934570e-01
    z[3,6,3]  R1762     -8.1872475147247314e-01
    z[3,6,3]  R1763     3.7962052226066589e-01
    z[3,6,3]  R1764     -3.3120054006576538e-01
    z[3,6,3]  R1765     -2.5419533252716064e-01
    z[3,6,3]  R1766     4.5828998088836670e-01
    z[3,6,3]  R1767     5.4101234674453735e-01
    z[3,6,3]  R1768     5.4365581274032593e-01
    z[3,6,3]  R1769     -5.8628183603286743e-01
    z[3,6,3]  R1770     -7.3722654581069946e-01
    z[3,6,3]  R1771     -6.0235756635665894e-01
    z[3,6,3]  R1772     -4.5180425047874451e-01
    z[3,6,3]  R1773     -7.7838724851608276e-01
    z[3,6,3]  R1774     1.3046717643737793e-01
    z[3,6,3]  R1775     4.4680750370025635e-01
    z[3,6,3]  R1776     0.547261655330658
    z[3,6,3]  R1777     6.1301314830780029e-01
    z[3,6,3]  R1778     0.675198495388031
    z[3,6,3]  R1779     -2.6835939288139343e-01
    z[3,6,3]  R1780     6.6462028026580811e-01
    z[3,6,3]  R1781     7.6194804906845093e-01
    z[3,6,3]  R1782     5.4782259464263916e-01
    z[3,6,3]  R1783     5.4189068078994751e-01
    z[3,6,3]  R1784     7.3853135108947754e-01
    z[3,6,3]  R1785     7.4501550197601318e-01
    z[3,6,3]  R1786     2.4280984699726105e-01
    z[3,6,3]  R1787     3.2068583369255066e-01
    z[3,6,4]  R33       -1
    z[3,6,4]  R60       1
    z[3,6,4]  R1683     -1
    z[3,6,4]  R1684     1
    z[3,6,4]  R1689     1.4900505542755127e-01
    z[3,6,4]  R1690     7.7285328879952431e-03
    z[3,6,4]  R1691     1.2747122347354889e-01
    z[3,6,4]  R1692     9.0370260179042816e-02
    z[3,6,4]  R1693     -1.8519116938114166e-01
    z[3,6,4]  R1694     4.5506274700164795e-01
    z[3,6,4]  R1695     2.1257656812667847e-01
    z[3,6,4]  R1696     1.7690427601337433e-01
    z[3,6,4]  R1697     4.7693067789077759e-01
    z[3,6,4]  R1698     5.3212434053421021e-02
    z[3,6,4]  R1699     4.0723349899053574e-02
    z[3,6,4]  R1700     7.6723806560039520e-02
    z[3,6,4]  R1701     -7.9503792524337769e-01
    z[3,6,4]  R1702     -4.2350319027900696e-01
    z[3,6,4]  R1703     -2.5479269027709961e-01
    z[3,6,4]  R1704     1.5232549607753754e-01
    z[3,6,4]  R1705     -4.6420025825500488e-01
    z[3,6,4]  R1706     -1.8094724416732788e-01
    z[3,6,4]  R1707     -4.8501467704772949e-01
    z[3,6,4]  R1708     1.4656354486942291e-01
    z[3,6,4]  R1709     -8.4032607078552246e-01
    z[3,6,4]  R1710     -2.1480195224285126e-01
    z[3,6,4]  R1711     -3.5190707445144653e-01
    z[3,6,4]  R1712     -5.5060088634490967e-02
    z[3,6,4]  R1713     3.3071920275688171e-01
    z[3,6,4]  R1714     4.6353048086166382e-01
    z[3,6,4]  R1715     1.7799116671085358e-01
    z[3,6,4]  R1716     1.0846702754497528e-01
    z[3,6,4]  R1717     -2.7862530946731567e-01
    z[3,6,4]  R1718     1.7154007218778133e-03
    z[3,6,4]  R1719     4.6138694882392883e-01
    z[3,6,4]  R1720     1.9123828411102295e-01
    z[3,6,4]  R1721     5.6625676155090332e-01
    z[3,6,4]  R1722     6.7100734449923038e-03
    z[3,6,4]  R1723     -3.0774167180061340e-01
    z[3,6,4]  R1724     -3.5249975323677063e-01
    z[3,6,4]  R1725     -4.7529861330986023e-02
    z[3,6,4]  R1726     -1.0738659650087357e-01
    z[3,6,4]  R1727     2.4396489560604095e-01
    z[3,6,4]  R1728     8.7059317156672478e-03
    z[3,6,4]  R1729     -4.8948537558317184e-02
    z[3,6,4]  R1730     4.3450409173965454e-01
    z[3,6,4]  R1731     3.9758551120758057e-01
    z[3,6,4]  R1732     2.4671699106693268e-01
    z[3,6,4]  R1733     -2.3689439892768860e-01
    z[3,6,4]  R1734     5.3628218173980713e-01
    z[3,6,4]  R1735     4.5758464932441711e-01
    z[3,6,4]  R1736     1.3389259576797485e-01
    z[3,6,4]  R1737     6.1684852838516235e-01
    z[3,6,4]  R1738     -1.2166652828454971e-01
    z[3,6,4]  R1739     -3.7135216593742371e-01
    z[3,6,4]  R1740     -0.354168564081192
    z[3,6,4]  R1741     -2.1554410457611084e-01
    z[3,6,4]  R1742     -9.7739897668361664e-02
    z[3,6,4]  R1743     -8.2521423697471619e-02
    z[3,6,4]  R1744     -4.7443509101867676e-01
    z[3,6,4]  R1745     -3.2872599363327026e-01
    z[3,6,4]  R1746     -9.5027446746826172e-02
    z[3,6,4]  R1747     -6.7304037511348724e-02
    z[3,6,4]  R1748     0.0866825059056282
    z[3,6,4]  R1749     -6.7003101110458374e-02
    z[3,6,4]  R1750     -7.8297823667526245e-02
    z[3,6,4]  R1751     4.3972003459930420e-01
    z[3,6,4]  R1752     3.1733307242393494e-01
    z[3,6,4]  R1753     4.2865127325057983e-01
    z[3,6,4]  R1754     5.1188313961029053e-01
    z[3,6,4]  R1755     0.0507943332195282
    z[3,6,4]  R1756     9.2227414250373840e-02
    z[3,6,4]  R1757     -1.1723274737596512e-01
    z[3,6,4]  R1758     7.0551261305809021e-02
    z[3,6,4]  R1759     2.8297787904739380e-01
    z[3,6,4]  R1760     -4.0528275072574615e-02
    z[3,6,4]  R1761     3.9297146722674370e-03
    z[3,6,4]  R1762     -2.5915073230862617e-02
    z[3,6,4]  R1763     1.1037456989288330e-01
    z[3,6,4]  R1764     -0.0431511253118515
    z[3,6,4]  R1765     -8.1617077812552452e-03
    z[3,6,4]  R1766     -4.2186689376831055e-01
    z[3,6,4]  R1767     -2.3261302709579468e-01
    z[3,6,4]  R1768     -1.6281627118587494e-01
    z[3,6,4]  R1769     8.3653137087821960e-02
    z[3,6,4]  R1770     4.4808998703956604e-02
    z[3,6,4]  R1771     3.5443204641342163e-01
    z[3,6,4]  R1772     -1.3447956740856171e-01
    z[3,6,4]  R1773     1.6174888610839844e-01
    z[3,6,4]  R1774     -1.6961348056793213e-01
    z[3,6,4]  R1775     -2.8872808814048767e-01
    z[3,6,4]  R1776     0.0324304923415184
    z[3,6,4]  R1777     1.1904054135084152e-01
    z[3,6,4]  R1778     1.3996081054210663e-01
    z[3,6,4]  R1779     -6.6272771358489990e-01
    z[3,6,4]  R1780     -2.5161406025290489e-02
    z[3,6,4]  R1781     -1.1635018140077591e-01
    z[3,6,4]  R1782     -1.0016535967588425e-01
    z[3,6,4]  R1783     5.2733731269836426e-01
    z[3,6,4]  R1784     -2.1668742597103119e-01
    z[3,6,4]  R1785     -2.9552593827247620e-01
    z[3,6,4]  R1786     -3.6308676004409790e-01
    z[3,6,4]  R1787     -3.3995696902275085e-01
    z[3,6,5]  R34       -1
    z[3,6,5]  R61       1
    z[3,6,5]  R1685     -1
    z[3,6,5]  R1686     1
    z[3,6,5]  R1689     4.8109255731105804e-03
    z[3,6,5]  R1690     0.0659482404589653
    z[3,6,5]  R1691     4.9900867044925690e-02
    z[3,6,5]  R1692     7.3024815320968628e-01
    z[3,6,5]  R1693     5.9566396474838257e-01
    z[3,6,5]  R1694     1.7350588738918304e-01
    z[3,6,5]  R1695     3.6055192351341248e-01
    z[3,6,5]  R1696     2.2199960052967072e-01
    z[3,6,5]  R1697     8.2227960228919983e-02
    z[3,6,5]  R1698     -9.9870055913925171e-02
    z[3,6,5]  R1699     -4.5442107319831848e-01
    z[3,6,5]  R1700     -5.0220921635627747e-02
    z[3,6,5]  R1701     -3.7199845910072327e-01
    z[3,6,5]  R1702     -0.0775558203458786
    z[3,6,5]  R1703     -2.3853132128715515e-01
    z[3,6,5]  R1704     -6.6592812538146973e-02
    z[3,6,5]  R1705     3.8669112324714661e-01
    z[3,6,5]  R1706     1.0121560655534267e-02
    z[3,6,5]  R1707     -1.6500715911388397e-01
    z[3,6,5]  R1708     2.4496668577194214e-01
    z[3,6,5]  R1709     -2.4761931598186493e-01
    z[3,6,5]  R1710     3.2741222530603409e-02
    z[3,6,5]  R1711     1.2170637398958206e-01
    z[3,6,5]  R1712     -4.5652562379837036e-01
    z[3,6,5]  R1713     -4.9590140581130981e-01
    z[3,6,5]  R1714     -3.4327471256256104e-01
    z[3,6,5]  R1715     -0.851716935634613
    z[3,6,5]  R1716     -5.0868522375822067e-02
    z[3,6,5]  R1717     4.1360217332839966e-01
    z[3,6,5]  R1718     2.5672644376754761e-01
    z[3,6,5]  R1719     -5.8026784658432007e-01
    z[3,6,5]  R1720     -1.6099371016025543e-01
    z[3,6,5]  R1721     -2.3186303675174713e-01
    z[3,6,5]  R1722     -7.6824903488159180e-01
    z[3,6,5]  R1723     -4.3951433897018433e-01
    z[3,6,5]  R1724     2.1920882165431976e-01
    z[3,6,5]  R1725     3.8463580608367920e-01
    z[3,6,5]  R1726     -5.5725741386413574e-01
    z[3,6,5]  R1727     -3.1448632478713989e-02
    z[3,6,5]  R1728     3.2223203778266907e-01
    z[3,6,5]  R1729     -4.1539106518030167e-02
    z[3,6,5]  R1730     2.2819447517395020e-01
    z[3,6,5]  R1731     1.7619884014129639e-01
    z[3,6,5]  R1732     1.3112403452396393e-01
    z[3,6,5]  R1733     1.2630765140056610e-01
    z[3,6,5]  R1734     3.9634126424789429e-01
    z[3,6,5]  R1735     -6.1755768954753876e-02
    z[3,6,5]  R1736     -1.6362796723842621e-01
    z[3,6,5]  R1737     -0.00947926752269268
    z[3,6,5]  R1738     3.7716919183731079e-01
    z[3,6,5]  R1739     -1.2126628309488297e-01
    z[3,6,5]  R1740     -8.2264598459005356e-03
    z[3,6,5]  R1741     7.7099567651748657e-01
    z[3,6,5]  R1742     -9.8559595644474030e-02
    z[3,6,5]  R1743     -3.2236614823341370e-01
    z[3,6,5]  R1744     -3.8575440645217896e-01
    z[3,6,5]  R1745     2.7779513597488403e-01
    z[3,6,5]  R1746     -4.8051732778549194e-01
    z[3,6,5]  R1747     -7.7186834812164307e-01
    z[3,6,5]  R1748     -4.4081023335456848e-01
    z[3,6,5]  R1749     4.9419414997100830e-01
    z[3,6,5]  R1750     -9.7955256700515747e-02
    z[3,6,5]  R1751     -0.336814820766449
    z[3,6,5]  R1752     -5.7692015171051025e-01
    z[3,6,5]  R1753     1.9828870892524719e-01
    z[3,6,5]  R1754     0.127718985080719
    z[3,6,5]  R1755     -7.1706116199493408e-01
    z[3,6,5]  R1756     4.2671549320220947e-01
    z[3,6,5]  R1757     -6.1563742160797119e-01
    z[3,6,5]  R1758     -4.0803611278533936e-02
    z[3,6,5]  R1759     2.2335672378540039e-01
    z[3,6,5]  R1760     4.1427803039550781e-01
    z[3,6,5]  R1761     -1.2038338184356689e-01
    z[3,6,5]  R1762     9.2470802366733551e-02
    z[3,6,5]  R1763     3.5213101655244827e-02
    z[3,6,5]  R1764     8.0370604991912842e-02
    z[3,6,5]  R1765     0.667449414730072
    z[3,6,5]  R1766     -2.9559394717216492e-01
    z[3,6,5]  R1767     -5.7194280624389648e-01
    z[3,6,5]  R1768     -3.8481815718114376e-03
    z[3,6,5]  R1769     2.5344986468553543e-02
    z[3,6,5]  R1770     2.5290971994400024e-01
    z[3,6,5]  R1771     -2.8588702902197838e-02
    z[3,6,5]  R1772     -4.4346663355827332e-01
    z[3,6,5]  R1773     -2.3948095738887787e-01
    z[3,6,5]  R1774     -7.2092288732528687e-01
    z[3,6,5]  R1775     -2.1446606516838074e-01
    z[3,6,5]  R1776     -4.3531975150108337e-01
    z[3,6,5]  R1777     -4.8618495464324951e-01
    z[3,6,5]  R1778     -6.1701752245426178e-02
    z[3,6,5]  R1779     1.9499303773045540e-02
    z[3,6,5]  R1780     -8.5549950599670410e-02
    z[3,6,5]  R1781     1.8580843508243561e-01
    z[3,6,5]  R1782     -4.3025019764900208e-01
    z[3,6,5]  R1783     -1.3461917638778687e-01
    z[3,6,5]  R1784     -9.5116794109344482e-02
    z[3,6,5]  R1785     0.000767854624427855
    z[3,6,5]  R1786     -5.7054489850997925e-01
    z[3,6,5]  R1787     -4.8150390386581421e-01
    z[3,6,6]  R35       -1
    z[3,6,6]  R62       1
    z[3,6,6]  R1687     -1
    z[3,6,6]  R1688     1
    z[3,6,6]  R1689     1.3507449626922607e-01
    z[3,6,6]  R1690     2.6652544736862183e-01
    z[3,6,6]  R1691     -2.8472086787223816e-01
    z[3,6,6]  R1692     4.1985213756561279e-02
    z[3,6,6]  R1693     -3.0993112921714783e-01
    z[3,6,6]  R1694     6.2922559678554535e-02
    z[3,6,6]  R1695     -8.6804866790771484e-02
    z[3,6,6]  R1696     1.6346450150012970e-01
    z[3,6,6]  R1697     -2.1336419880390167e-01
    z[3,6,6]  R1698     -1.5313178300857544e-01
    z[3,6,6]  R1699     -4.4341591000556946e-01
    z[3,6,6]  R1700     -5.8153618127107620e-02
    z[3,6,6]  R1701     -1.2105491012334824e-01
    z[3,6,6]  R1702     9.5740392804145813e-02
    z[3,6,6]  R1703     3.0108624696731567e-01
    z[3,6,6]  R1704     2.4864296615123749e-01
    z[3,6,6]  R1705     2.2193619608879089e-01
    z[3,6,6]  R1706     2.1507178246974945e-01
    z[3,6,6]  R1707     2.5794410705566406e-01
    z[3,6,6]  R1708     5.3128913044929504e-02
    z[3,6,6]  R1709     3.6897215992212296e-02
    z[3,6,6]  R1710     -3.7897691130638123e-01
    z[3,6,6]  R1711     5.0594788044691086e-02
    z[3,6,6]  R1712     2.8071720153093338e-02
    z[3,6,6]  R1713     1.2220699340105057e-01
    z[3,6,6]  R1714     -1.5717579424381256e-01
    z[3,6,6]  R1715     -2.1846961975097656e-01
    z[3,6,6]  R1716     -4.9315180629491806e-02
    z[3,6,6]  R1717     1.7198757827281952e-01
    z[3,6,6]  R1718     2.7713131904602051e-01
    z[3,6,6]  R1719     -3.1991052627563477e-01
    z[3,6,6]  R1720     5.1235571503639221e-02
    z[3,6,6]  R1721     -8.7080515921115875e-02
    z[3,6,6]  R1722     4.4334483146667480e-01
    z[3,6,6]  R1723     -3.5520243644714355e-01
    z[3,6,6]  R1724     -3.5905953496694565e-02
    z[3,6,6]  R1725     1.4304243028163910e-01
    z[3,6,6]  R1726     5.8000016957521439e-02
    z[3,6,6]  R1727     -9.6655987203121185e-02
    z[3,6,6]  R1728     -2.0759889483451843e-01
    z[3,6,6]  R1729     2.6531422138214111e-01
    z[3,6,6]  R1730     1.2754152715206146e-01
    z[3,6,6]  R1731     1.3739053905010223e-01
    z[3,6,6]  R1732     1.5865311026573181e-01
    z[3,6,6]  R1733     -1.2897776067256927e-01
    z[3,6,6]  R1734     5.1337309181690216e-02
    z[3,6,6]  R1735     3.5426083207130432e-01
    z[3,6,6]  R1736     -2.1180485188961029e-01
    z[3,6,6]  R1737     -1.6379144787788391e-01
    z[3,6,6]  R1738     6.9629065692424774e-02
    z[3,6,6]  R1739     1.1301308125257492e-01
    z[3,6,6]  R1740     -0.0913948118686676
    z[3,6,6]  R1741     -1.2146764993667603e-01
    z[3,6,6]  R1742     -3.8080912828445435e-01
    z[3,6,6]  R1743     -2.7549448609352112e-01
    z[3,6,6]  R1744     -4.1617578268051147e-01
    z[3,6,6]  R1745     -2.3799885809421539e-01
    z[3,6,6]  R1746     -3.3573645353317261e-01
    z[3,6,6]  R1747     -8.6897037923336029e-02
    z[3,6,6]  R1748     -4.7503328323364258e-01
    z[3,6,6]  R1749     -1.4641021192073822e-01
    z[3,6,6]  R1750     -1.2273354083299637e-01
    z[3,6,6]  R1751     4.0288589894771576e-02
    z[3,6,6]  R1752     -2.5131475925445557e-01
    z[3,6,6]  R1753     -6.5688163042068481e-02
    z[3,6,6]  R1754     2.0194327458739281e-02
    z[3,6,6]  R1755     -3.3444055914878845e-01
    z[3,6,6]  R1756     1.5683636069297791e-01
    z[3,6,6]  R1757     1.6815623268485069e-02
    z[3,6,6]  R1758     -7.5065419077873230e-02
    z[3,6,6]  R1759     -4.6393796801567078e-02
    z[3,6,6]  R1760     9.8258063197135925e-02
    z[3,6,6]  R1761     -1.5908671915531158e-01
    z[3,6,6]  R1762     -2.9051387310028076e-01
    z[3,6,6]  R1763     -6.2175148725509644e-01
    z[3,6,6]  R1764     -4.0989780426025391e-01
    z[3,6,6]  R1765     3.0348291993141174e-01
    z[3,6,6]  R1766     1.2335287779569626e-01
    z[3,6,6]  R1767     7.8560203313827515e-02
    z[3,6,6]  R1768     2.9827767610549927e-01
    z[3,6,6]  R1769     0.0264901053160429
    z[3,6,6]  R1770     -6.8063624203205109e-02
    z[3,6,6]  R1771     -5.7983744889497757e-02
    z[3,6,6]  R1772     -2.0843598246574402e-01
    z[3,6,6]  R1773     -3.3385860919952393e-01
    z[3,6,6]  R1774     -1.8527679145336151e-01
    z[3,6,6]  R1775     1.6800068318843842e-01
    z[3,6,6]  R1776     1.2624703347682953e-01
    z[3,6,6]  R1777     1.1233668774366379e-01
    z[3,6,6]  R1778     2.2378845512866974e-01
    z[3,6,6]  R1779     -0.306953102350235
    z[3,6,6]  R1780     3.6419898271560669e-02
    z[3,6,6]  R1781     -0.0854058712720871
    z[3,6,6]  R1782     -2.8591899201273918e-02
    z[3,6,6]  R1783     2.2501243650913239e-01
    z[3,6,6]  R1784     -3.1531330943107605e-01
    z[3,6,6]  R1785     2.4544094502925873e-01
    z[3,6,6]  R1786     -3.0729341506958008e-01
    z[3,6,6]  R1787     -3.2387769222259521e-01
    z[6,3,0]  R29       1
    z[6,3,0]  R56       -1
    z[6,3,0]  R1788     -1
    z[6,3,0]  R1789     1
    z[6,3,0]  R1802     2.5043988227844238e-01
    z[6,3,0]  R1803     -1.1739933490753174e-01
    z[6,3,0]  R1804     -6.8089950084686279e-01
    z[6,3,0]  R1805     9.4819717109203339e-02
    z[6,3,0]  R1806     1.9782318174839020e-01
    z[6,3,0]  R1807     -2.4343258142471313e-01
    z[6,3,0]  R1808     -1.6474086046218872e-01
    z[6,3,0]  R1809     1.1158072203397751e-01
    z[6,3,0]  R1810     0.0373874306678772
    z[6,3,0]  R1811     -8.2292415201663971e-02
    z[6,3,0]  R1812     -6.8636733293533325e-01
    z[6,3,0]  R1813     -3.6941394209861755e-01
    z[6,3,0]  R1814     4.2295315861701965e-01
    z[6,3,0]  R1815     1.9365036487579346e-01
    z[6,3,0]  R1816     -4.2744394391775131e-02
    z[6,3,0]  R1817     -4.0544059872627258e-01
    z[6,3,0]  R1818     -0.047398891299963
    z[6,3,0]  R1819     -4.4668549299240112e-01
    z[6,3,0]  R1820     -3.2467502355575562e-01
    z[6,3,0]  R1821     -4.3154659867286682e-01
    z[6,3,0]  R1822     1.2100342661142349e-01
    z[6,3,0]  R1823     2.9956543445587158e-01
    z[6,3,0]  R1824     -2.7906802296638489e-01
    z[6,3,0]  R1825     2.6324215531349182e-01
    z[6,3,0]  R1826     3.7964138388633728e-01
    z[6,3,0]  R1827     8.2014858722686768e-01
    z[6,3,0]  R1828     -5.1732414960861206e-01
    z[6,3,0]  R1829     2.2022904828190804e-02
    z[6,3,0]  R1830     -6.7554646730422974e-01
    z[6,3,0]  R1831     -3.6076098680496216e-01
    z[6,3,0]  R1832     -2.2130471467971802e-01
    z[6,3,0]  R1833     3.9594525098800659e-01
    z[6,3,0]  R1834     5.2152341604232788e-01
    z[6,3,0]  R1835     1.6126877069473267e-01
    z[6,3,0]  R1836     -5.1240515708923340e-01
    z[6,3,0]  R1837     -5.6220752000808716e-01
    z[6,3,0]  R1838     -2.2039239108562469e-01
    z[6,3,0]  R1839     -4.3702054023742676e-01
    z[6,3,0]  R1840     -1.5497425198554993e-01
    z[6,3,0]  R1841     -5.1202714443206787e-01
    z[6,3,0]  R1842     7.3430542834103107e-03
    z[6,3,0]  R1843     2.0170010626316071e-01
    z[6,3,0]  R1844     3.6225342750549316e-01
    z[6,3,0]  R1845     -5.6179058551788330e-01
    z[6,3,0]  R1846     3.4631749987602234e-01
    z[6,3,0]  R1847     -4.1941487789154053e-01
    z[6,3,0]  R1848     -4.7215002775192261e-01
    z[6,3,0]  R1849     -4.0012276172637939e-01
    z[6,3,0]  R1850     2.7824291586875916e-01
    z[6,3,0]  R1851     4.1739797592163086e-01
    z[6,3,0]  R1852     -4.4357064366340637e-01
    z[6,3,0]  R1853     -3.3242177963256836e-01
    z[6,3,0]  R1854     -4.6058263629674911e-02
    z[6,3,0]  R1855     5.9308332204818726e-01
    z[6,3,0]  R1856     8.7423712015151978e-02
    z[6,3,0]  R1857     -2.8697337955236435e-02
    z[6,3,0]  R1858     5.9080682694911957e-02
    z[6,3,0]  R1859     4.8808166384696960e-01
    z[6,3,0]  R1860     5.8220338821411133e-01
    z[6,3,0]  R1861     2.1070216596126556e-01
    z[6,3,0]  R1862     2.3706804215908051e-01
    z[6,3,0]  R1863     -3.3032408356666565e-01
    z[6,3,0]  R1864     -5.0689097493886948e-02
    z[6,3,0]  R1865     9.3185283243656158e-02
    z[6,3,0]  R1866     -3.8340926170349121e-01
    z[6,3,0]  R1867     -3.6293300986289978e-01
    z[6,3,0]  R1868     -1.4409963786602020e-01
    z[6,3,0]  R1869     -2.8153423219919205e-02
    z[6,3,0]  R1870     -1.4287948608398438e-01
    z[6,3,0]  R1871     5.0730270147323608e-01
    z[6,3,0]  R1872     6.8103051185607910e-01
    z[6,3,0]  R1873     3.9166036248207092e-01
    z[6,3,0]  R1874     -4.2965531349182129e-01
    z[6,3,0]  R1875     2.3904596269130707e-01
    z[6,3,0]  R1876     6.1169892549514771e-01
    z[6,3,0]  R1877     -0.323994904756546
    z[6,3,0]  R1878     -0.660135805606842
    z[6,3,0]  R1879     -5.5857664346694946e-01
    z[6,3,0]  R1880     -6.2961035966873169e-01
    z[6,3,0]  R1881     3.1452909111976624e-02
    z[6,3,0]  R1882     7.4064075946807861e-01
    z[6,3,0]  R1883     -1.7483724653720856e-01
    z[6,3,0]  R1884     -1.1822493746876717e-02
    z[6,3,0]  R1885     1.3173650205135345e-01
    z[6,3,0]  R1886     -2.4004104733467102e-01
    z[6,3,0]  R1887     3.2079127430915833e-01
    z[6,3,0]  R1888     0.62704998254776
    z[6,3,0]  R1889     -4.3412479758262634e-01
    z[6,3,0]  R1890     -4.8567795753479004e-01
    z[6,3,0]  R1891     3.8553151488304138e-01
    z[6,3,0]  R1892     2.3259313404560089e-01
    z[6,3,0]  R1893     -4.1952177882194519e-01
    z[6,3,0]  R1894     7.0278279483318329e-02
    z[6,3,0]  R1895     -1.0878144204616547e-01
    z[6,3,0]  R1896     -2.0737315714359283e-01
    z[6,3,0]  R1897     -1.4528167247772217e-01
    z[6,3,0]  R1898     -3.0842933058738708e-01
    z[6,3,0]  R1899     -5.4398483037948608e-01
    z[6,3,0]  R1900     -4.3852820992469788e-01
    z[6,3,1]  R30       1
    z[6,3,1]  R57       -1
    z[6,3,1]  R1790     -1
    z[6,3,1]  R1791     1
    z[6,3,1]  R1802     -9.0008413791656494e-01
    z[6,3,1]  R1803     4.8491966724395752e-01
    z[6,3,1]  R1804     2.7578523755073547e-01
    z[6,3,1]  R1805     4.0412941575050354e-01
    z[6,3,1]  R1806     -8.4182655811309814e-01
    z[6,3,1]  R1807     3.7795212864875793e-01
    z[6,3,1]  R1808     -4.7477439045906067e-01
    z[6,3,1]  R1809     -8.2168734073638916e-01
    z[6,3,1]  R1810     3.5587257146835327e-01
    z[6,3,1]  R1811     5.9452176094055176e-01
    z[6,3,1]  R1812     5.4028725624084473e-01
    z[6,3,1]  R1813     4.3962958455085754e-01
    z[6,3,1]  R1814     1.2242415547370911e-01
    z[6,3,1]  R1815     4.0875086188316345e-01
    z[6,3,1]  R1816     4.1638728976249695e-01
    z[6,3,1]  R1817     4.0337544679641724e-01
    z[6,3,1]  R1818     4.0010768175125122e-01
    z[6,3,1]  R1819     2.9809844493865967e-01
    z[6,3,1]  R1820     3.8250654935836792e-01
    z[6,3,1]  R1821     2.4132257699966431e-01
    z[6,3,1]  R1822     3.0258321762084961e-01
    z[6,3,1]  R1823     3.1962257623672485e-01
    z[6,3,1]  R1824     5.7955151796340942e-01
    z[6,3,1]  R1825     1.7624391615390778e-01
    z[6,3,1]  R1826     2.0100392401218414e-01
    z[6,3,1]  R1827     -7.4481934309005737e-02
    z[6,3,1]  R1828     2.6645469665527344e-01
    z[6,3,1]  R1829     -5.8485662937164307e-01
    z[6,3,1]  R1830     -3.7440571188926697e-01
    z[6,3,1]  R1831     -6.1355471611022949e-01
    z[6,3,1]  R1832     -2.6705756783485413e-01
    z[6,3,1]  R1833     -7.1646170690655708e-03
    z[6,3,1]  R1834     1.0217893868684769e-01
    z[6,3,1]  R1835     4.0572628378868103e-01
    z[6,3,1]  R1836     3.9647969603538513e-01
    z[6,3,1]  R1837     3.8121148943901062e-01
    z[6,3,1]  R1838     3.7789022922515869e-01
    z[6,3,1]  R1839     -5.6038576364517212e-01
    z[6,3,1]  R1840     -5.3539234399795532e-01
    z[6,3,1]  R1841     -5.6757456064224243e-01
    z[6,3,1]  R1842     4.7778841853141785e-01
    z[6,3,1]  R1843     2.7109444141387939e-01
    z[6,3,1]  R1844     3.9177486300468445e-01
    z[6,3,1]  R1845     4.6451058983802795e-01
    z[6,3,1]  R1846     1.6319791972637177e-01
    z[6,3,1]  R1847     4.5668345689773560e-01
    z[6,3,1]  R1848     -6.4762878417968750e-01
    z[6,3,1]  R1849     -5.0727158784866333e-01
    z[6,3,1]  R1850     -5.3213357925415039e-01
    z[6,3,1]  R1851     -5.4442584514617920e-01
    z[6,3,1]  R1852     4.0950211882591248e-01
    z[6,3,1]  R1853     -6.4772331714630127e-01
    z[6,3,1]  R1854     -4.2938083410263062e-01
    z[6,3,1]  R1855     3.2703793048858643e-01
    z[6,3,1]  R1856     -4.7708502411842346e-01
    z[6,3,1]  R1857     -3.7778580188751221e-01
    z[6,3,1]  R1858     -3.9710542559623718e-01
    z[6,3,1]  R1859     3.7884214520454407e-01
    z[6,3,1]  R1860     3.1807422637939453e-01
    z[6,3,1]  R1861     -7.3202508687973022e-01
    z[6,3,1]  R1862     -8.9609622955322266e-01
    z[6,3,1]  R1863     -8.7818670272827148e-01
    z[6,3,1]  R1864     -6.6387432813644409e-01
    z[6,3,1]  R1865     -6.4120382070541382e-01
    z[6,3,1]  R1866     4.5675918459892273e-01
    z[6,3,1]  R1867     3.6966803669929504e-01
    z[6,3,1]  R1868     4.6123948693275452e-01
    z[6,3,1]  R1869     4.6623924374580383e-01
    z[6,3,1]  R1870     0.478381484746933
    z[6,3,1]  R1871     -1.7955128848552704e-01
    z[6,3,1]  R1872     -3.4282706677913666e-02
    z[6,3,1]  R1873     -5.4561026394367218e-02
    z[6,3,1]  R1874     7.4065822362899780e-01
    z[6,3,1]  R1875     8.4010857343673706e-01
    z[6,3,1]  R1876     6.7208075523376465e-01
    z[6,3,1]  R1877     1.6775736585259438e-02
    z[6,3,1]  R1878     2.0863661170005798e-01
    z[6,3,1]  R1879     -1.2913960963487625e-02
    z[6,3,1]  R1880     0.288901686668396
    z[6,3,1]  R1881     -4.1288891434669495e-01
    z[6,3,1]  R1882     -4.0469425916671753e-01
    z[6,3,1]  R1883     8.2116818428039551e-01
    z[6,3,1]  R1884     7.7963519096374512e-01
    z[6,3,1]  R1885     7.3115426301956177e-01
    z[6,3,1]  R1886     9.0361751616001129e-02
    z[6,3,1]  R1887     -2.7667286992073059e-01
    z[6,3,1]  R1888     0.628728449344635
    z[6,3,1]  R1889     -4.3045710772275925e-02
    z[6,3,1]  R1890     -2.8077220544219017e-02
    z[6,3,1]  R1891     -2.6363173127174377e-01
    z[6,3,1]  R1892     7.4782872200012207e-01
    z[6,3,1]  R1893     4.1568708419799805e-01
    z[6,3,1]  R1894     -5.7474941015243530e-02
    z[6,3,1]  R1895     3.9827597141265869e-01
    z[6,3,1]  R1896     -1.1768517643213272e-01
    z[6,3,1]  R1897     -3.6511268466711044e-02
    z[6,3,1]  R1898     2.0624291151762009e-02
    z[6,3,1]  R1899     1.7866080999374390e-01
    z[6,3,1]  R1900     1.8642188608646393e-01
    z[6,3,2]  R31       1
    z[6,3,2]  R58       -1
    z[6,3,2]  R1792     -1
    z[6,3,2]  R1793     1
    z[6,3,2]  R1802     -2.2932359576225281e-01
    z[6,3,2]  R1803     -6.8683421611785889e-01
    z[6,3,2]  R1804     -5.0153082609176636e-01
    z[6,3,2]  R1805     -6.4585661888122559e-01
    z[6,3,2]  R1806     1.6330896317958832e-01
    z[6,3,2]  R1807     -5.6998163461685181e-01
    z[6,3,2]  R1808     5.9834194183349609e-01
    z[6,3,2]  R1809     -1.1998074501752853e-01
    z[6,3,2]  R1810     -0.644943118095398
    z[6,3,2]  R1811     -4.7349187731742859e-01
    z[6,3,2]  R1812     2.5623485445976257e-01
    z[6,3,2]  R1813     4.7445413470268250e-01
    z[6,3,2]  R1814     -5.6328210048377514e-03
    z[6,3,2]  R1815     1.6692188382148743e-01
    z[6,3,2]  R1816     3.6668628454208374e-01
    z[6,3,2]  R1817     7.6216422021389008e-02
    z[6,3,2]  R1818     2.4714258313179016e-01
    z[6,3,2]  R1819     2.9009503126144409e-01
    z[6,3,2]  R1820     -1.0790310055017471e-01
    z[6,3,2]  R1821     4.0713006258010864e-01
    z[6,3,2]  R1822     2.1538142859935760e-01
    z[6,3,2]  R1823     6.6276490688323975e-01
    z[6,3,2]  R1824     3.0871546268463135e-01
    z[6,3,2]  R1825     2.8660658001899719e-01
    z[6,3,2]  R1826     3.0485492944717407e-01
    z[6,3,2]  R1827     1.6351932287216187e-01
    z[6,3,2]  R1828     6.7355133593082428e-02
    z[6,3,2]  R1829     -5.0796133279800415e-01
    z[6,3,2]  R1830     2.2495531011372805e-03
    z[6,3,2]  R1831     1.5763860195875168e-02
    z[6,3,2]  R1832     1.5075573325157166e-01
    z[6,3,2]  R1833     6.8243521451950073e-01
    z[6,3,2]  R1834     6.0448747873306274e-01
    z[6,3,2]  R1835     2.1318452060222626e-01
    z[6,3,2]  R1836     1.9009378552436829e-01
    z[6,3,2]  R1837     5.0256246328353882e-01
    z[6,3,2]  R1838     4.5426163077354431e-01
    z[6,3,2]  R1839     6.6239468753337860e-02
    z[6,3,2]  R1840     9.6148863434791565e-02
    z[6,3,2]  R1841     -6.8059504032135010e-02
    z[6,3,2]  R1842     6.4776223897933960e-01
    z[6,3,2]  R1843     5.2126592397689819e-01
    z[6,3,2]  R1844     4.7185677289962769e-01
    z[6,3,2]  R1845     7.9380877315998077e-02
    z[6,3,2]  R1846     2.2927826642990112e-01
    z[6,3,2]  R1847     -1.2523406744003296e-01
    z[6,3,2]  R1848     -2.0751677453517914e-02
    z[6,3,2]  R1849     -2.7674663066864014e-01
    z[6,3,2]  R1850     2.1530188620090485e-02
    z[6,3,2]  R1851     -3.0051467474550009e-03
    z[6,3,2]  R1852     -1.7241753637790680e-01
    z[6,3,2]  R1853     -1.3766567409038544e-01
    z[6,3,2]  R1854     4.2141386866569519e-01
    z[6,3,2]  R1855     2.1265690028667450e-01
    z[6,3,2]  R1856     -3.5251066088676453e-01
    z[6,3,2]  R1857     0.394464910030365
    z[6,3,2]  R1858     3.6904075741767883e-01
    z[6,3,2]  R1859     0.0866931602358818
    z[6,3,2]  R1860     -6.8666212260723114e-02
    z[6,3,2]  R1861     6.1484199762344360e-01
    z[6,3,2]  R1862     -2.5353688001632690e-01
    z[6,3,2]  R1863     4.6989362686872482e-02
    z[6,3,2]  R1864     9.8646752536296844e-02
    z[6,3,2]  R1865     -0.305441290140152
    z[6,3,2]  R1866     -6.2570393085479736e-01
    z[6,3,2]  R1867     -6.9680237770080566e-01
    z[6,3,2]  R1868     -6.4595109224319458e-01
    z[6,3,2]  R1869     -6.7250245809555054e-01
    z[6,3,2]  R1870     -5.6332510709762573e-01
    z[6,3,2]  R1871     -4.0046057105064392e-01
    z[6,3,2]  R1872     4.2531597428023815e-03
    z[6,3,2]  R1873     1.0870019346475601e-01
    z[6,3,2]  R1874     -2.6488453149795532e-01
    z[6,3,2]  R1875     2.9680223669856787e-03
    z[6,3,2]  R1876     -4.3982964009046555e-02
    z[6,3,2]  R1877     3.6153453588485718e-01
    z[6,3,2]  R1878     5.5275034904479980e-01
    z[6,3,2]  R1879     4.6292573213577271e-01
    z[6,3,2]  R1880     5.3264069557189941e-01
    z[6,3,2]  R1881     2.2463642060756683e-01
    z[6,3,2]  R1882     -1.6830703616142273e-01
    z[6,3,2]  R1883     -3.9099535346031189e-01
    z[6,3,2]  R1884     -3.8344052433967590e-01
    z[6,3,2]  R1885     -2.6987469196319580e-01
    z[6,3,2]  R1886     -0.394153892993927
    z[6,3,2]  R1887     -5.5422164499759674e-02
    z[6,3,2]  R1888     -4.2012721300125122e-01
    z[6,3,2]  R1889     4.4082674384117126e-01
    z[6,3,2]  R1890     3.8484206795692444e-01
    z[6,3,2]  R1891     -2.6140862703323364e-01
    z[6,3,2]  R1892     -4.0695735812187195e-01
    z[6,3,2]  R1893     -5.0352096557617188e-01
    z[6,3,2]  R1894     1.1228688061237335e-01
    z[6,3,2]  R1895     -6.3518583774566650e-01
    z[6,3,2]  R1896     3.1060567498207092e-01
    z[6,3,2]  R1897     2.3794180154800415e-01
    z[6,3,2]  R1898     3.5464078187942505e-01
    z[6,3,2]  R1899     5.6184995174407959e-01
    z[6,3,2]  R1900     0.663927435874939
    z[6,3,3]  R32       1
    z[6,3,3]  R59       -1
    z[6,3,3]  R1794     -1
    z[6,3,3]  R1795     1
    z[6,3,3]  R1802     5.1031899638473988e-03
    z[6,3,3]  R1803     -1.4898261427879333e-01
    z[6,3,3]  R1804     -2.8086232021450996e-02
    z[6,3,3]  R1805     5.5436813831329346e-01
    z[6,3,3]  R1806     -3.6988684535026550e-01
    z[6,3,3]  R1807     -1.6029103100299835e-01
    z[6,3,3]  R1808     -2.2525161504745483e-01
    z[6,3,3]  R1809     -4.5653226971626282e-01
    z[6,3,3]  R1810     -2.2042134404182434e-01
    z[6,3,3]  R1811     5.0365632772445679e-01
    z[6,3,3]  R1812     7.7158883213996887e-02
    z[6,3,3]  R1813     -0.557939350605011
    z[6,3,3]  R1814     -3.8787013292312622e-01
    z[6,3,3]  R1815     -7.7670890092849731e-01
    z[6,3,3]  R1816     -7.0972442626953125e-01
    z[6,3,3]  R1817     -3.4640991687774658e-01
    z[6,3,3]  R1818     -7.3124104738235474e-01
    z[6,3,3]  R1819     -5.2422147989273071e-01
    z[6,3,3]  R1820     3.5884547233581543e-01
    z[6,3,3]  R1821     4.0285471081733704e-01
    z[6,3,3]  R1822     -0.759775698184967
    z[6,3,3]  R1823     -5.8142524957656860e-01
    z[6,3,3]  R1824     -4.2721742391586304e-01
    z[6,3,3]  R1825     -5.6639397144317627e-01
    z[6,3,3]  R1826     -7.0367473363876343e-01
    z[6,3,3]  R1827     -1.2777270376682281e-01
    z[6,3,3]  R1828     1.6802865266799927e-01
    z[6,3,3]  R1829     4.2923569679260254e-01
    z[6,3,3]  R1830     1.0206146538257599e-01
    z[6,3,3]  R1831     6.9345241785049438e-01
    z[6,3,3]  R1832     -8.5138714313507080e-01
    z[6,3,3]  R1833     -4.4106084108352661e-01
    z[6,3,3]  R1834     -5.5888414382934570e-01
    z[6,3,3]  R1835     -8.1872475147247314e-01
    z[6,3,3]  R1836     3.7962052226066589e-01
    z[6,3,3]  R1837     -3.3120054006576538e-01
    z[6,3,3]  R1838     -2.5419533252716064e-01
    z[6,3,3]  R1839     4.5828998088836670e-01
    z[6,3,3]  R1840     5.4101234674453735e-01
    z[6,3,3]  R1841     5.4365581274032593e-01
    z[6,3,3]  R1842     -5.8628183603286743e-01
    z[6,3,3]  R1843     -7.3722654581069946e-01
    z[6,3,3]  R1844     -6.0235756635665894e-01
    z[6,3,3]  R1845     -4.5180425047874451e-01
    z[6,3,3]  R1846     -7.7838724851608276e-01
    z[6,3,3]  R1847     1.3046717643737793e-01
    z[6,3,3]  R1848     4.4680750370025635e-01
    z[6,3,3]  R1849     0.547261655330658
    z[6,3,3]  R1850     6.1301314830780029e-01
    z[6,3,3]  R1851     0.675198495388031
    z[6,3,3]  R1852     -2.6835939288139343e-01
    z[6,3,3]  R1853     6.6462028026580811e-01
    z[6,3,3]  R1854     7.6194804906845093e-01
    z[6,3,3]  R1855     5.4782259464263916e-01
    z[6,3,3]  R1856     5.4189068078994751e-01
    z[6,3,3]  R1857     7.3853135108947754e-01
    z[6,3,3]  R1858     7.4501550197601318e-01
    z[6,3,3]  R1859     2.4280984699726105e-01
    z[6,3,3]  R1860     3.2068583369255066e-01
    z[6,3,3]  R1861     3.5248868167400360e-02
    z[6,3,3]  R1862     3.2933041453361511e-02
    z[6,3,3]  R1863     -1.3289515674114227e-01
    z[6,3,3]  R1864     6.1468955129384995e-02
    z[6,3,3]  R1865     -4.1365999728441238e-02
    z[6,3,3]  R1866     -1.0824655741453171e-01
    z[6,3,3]  R1867     2.5173410773277283e-01
    z[6,3,3]  R1868     0.491875022649765
    z[6,3,3]  R1869     -2.2320429980754852e-01
    z[6,3,3]  R1870     0.630195677280426
    z[6,3,3]  R1871     -3.8113251328468323e-01
    z[6,3,3]  R1872     -7.2333496809005737e-01
    z[6,3,3]  R1873     -2.1607159078121185e-01
    z[6,3,3]  R1874     4.6063192188739777e-02
    z[6,3,3]  R1875     1.5683244168758392e-01
    z[6,3,3]  R1876     2.8763899207115173e-01
    z[6,3,3]  R1877     -5.9141445159912109e-01
    z[6,3,3]  R1878     -3.6886084079742432e-01
    z[6,3,3]  R1879     -3.8016214966773987e-01
    z[6,3,3]  R1880     -3.9001065492630005e-01
    z[6,3,3]  R1881     -0.0961623340845108
    z[6,3,3]  R1882     -2.6174640655517578e-01
    z[6,3,3]  R1883     3.2039511948823929e-02
    z[6,3,3]  R1884     1.8101747334003448e-01
    z[6,3,3]  R1885     7.0701591670513153e-02
    z[6,3,3]  R1886     6.4919614791870117e-01
    z[6,3,3]  R1887     1.1243601888418198e-01
    z[6,3,3]  R1888     1.3497139513492584e-01
    z[6,3,3]  R1889     -5.8058238029479980e-01
    z[6,3,3]  R1890     -6.8739497661590576e-01
    z[6,3,3]  R1891     -2.4818925559520721e-01
    z[6,3,3]  R1892     3.9486980438232422e-01
    z[6,3,3]  R1893     1.2522846460342407e-01
    z[6,3,3]  R1894     -4.3856918811798096e-01
    z[6,3,3]  R1895     -1.0970503836870193e-01
    z[6,3,3]  R1896     -8.2041013240814209e-01
    z[6,3,3]  R1897     -8.6618643999099731e-01
    z[6,3,3]  R1898     -6.7323404550552368e-01
    z[6,3,3]  R1899     -5.3538322448730469e-01
    z[6,3,3]  R1900     -4.3027156591415405e-01
    z[6,3,4]  R33       1
    z[6,3,4]  R60       -1
    z[6,3,4]  R1796     -1
    z[6,3,4]  R1797     1
    z[6,3,4]  R1802     -4.8948537558317184e-02
    z[6,3,4]  R1803     4.3450409173965454e-01
    z[6,3,4]  R1804     3.9758551120758057e-01
    z[6,3,4]  R1805     2.4671699106693268e-01
    z[6,3,4]  R1806     -2.3689439892768860e-01
    z[6,3,4]  R1807     5.3628218173980713e-01
    z[6,3,4]  R1808     4.5758464932441711e-01
    z[6,3,4]  R1809     1.3389259576797485e-01
    z[6,3,4]  R1810     6.1684852838516235e-01
    z[6,3,4]  R1811     -1.2166652828454971e-01
    z[6,3,4]  R1812     -3.7135216593742371e-01
    z[6,3,4]  R1813     -0.354168564081192
    z[6,3,4]  R1814     -2.1554410457611084e-01
    z[6,3,4]  R1815     -9.7739897668361664e-02
    z[6,3,4]  R1816     -8.2521423697471619e-02
    z[6,3,4]  R1817     -4.7443509101867676e-01
    z[6,3,4]  R1818     -3.2872599363327026e-01
    z[6,3,4]  R1819     -9.5027446746826172e-02
    z[6,3,4]  R1820     -6.7304037511348724e-02
    z[6,3,4]  R1821     0.0866825059056282
    z[6,3,4]  R1822     -6.7003101110458374e-02
    z[6,3,4]  R1823     -7.8297823667526245e-02
    z[6,3,4]  R1824     4.3972003459930420e-01
    z[6,3,4]  R1825     3.1733307242393494e-01
    z[6,3,4]  R1826     4.2865127325057983e-01
    z[6,3,4]  R1827     5.1188313961029053e-01
    z[6,3,4]  R1828     0.0507943332195282
    z[6,3,4]  R1829     9.2227414250373840e-02
    z[6,3,4]  R1830     -1.1723274737596512e-01
    z[6,3,4]  R1831     7.0551261305809021e-02
    z[6,3,4]  R1832     2.8297787904739380e-01
    z[6,3,4]  R1833     -4.0528275072574615e-02
    z[6,3,4]  R1834     3.9297146722674370e-03
    z[6,3,4]  R1835     -2.5915073230862617e-02
    z[6,3,4]  R1836     1.1037456989288330e-01
    z[6,3,4]  R1837     -0.0431511253118515
    z[6,3,4]  R1838     -8.1617077812552452e-03
    z[6,3,4]  R1839     -4.2186689376831055e-01
    z[6,3,4]  R1840     -2.3261302709579468e-01
    z[6,3,4]  R1841     -1.6281627118587494e-01
    z[6,3,4]  R1842     8.3653137087821960e-02
    z[6,3,4]  R1843     4.4808998703956604e-02
    z[6,3,4]  R1844     3.5443204641342163e-01
    z[6,3,4]  R1845     -1.3447956740856171e-01
    z[6,3,4]  R1846     1.6174888610839844e-01
    z[6,3,4]  R1847     -1.6961348056793213e-01
    z[6,3,4]  R1848     -2.8872808814048767e-01
    z[6,3,4]  R1849     0.0324304923415184
    z[6,3,4]  R1850     1.1904054135084152e-01
    z[6,3,4]  R1851     1.3996081054210663e-01
    z[6,3,4]  R1852     -6.6272771358489990e-01
    z[6,3,4]  R1853     -2.5161406025290489e-02
    z[6,3,4]  R1854     -1.1635018140077591e-01
    z[6,3,4]  R1855     -1.0016535967588425e-01
    z[6,3,4]  R1856     5.2733731269836426e-01
    z[6,3,4]  R1857     -2.1668742597103119e-01
    z[6,3,4]  R1858     -2.9552593827247620e-01
    z[6,3,4]  R1859     -3.6308676004409790e-01
    z[6,3,4]  R1860     -3.3995696902275085e-01
    z[6,3,4]  R1861     1.4900505542755127e-01
    z[6,3,4]  R1862     7.7285328879952431e-03
    z[6,3,4]  R1863     1.2747122347354889e-01
    z[6,3,4]  R1864     9.0370260179042816e-02
    z[6,3,4]  R1865     -1.8519116938114166e-01
    z[6,3,4]  R1866     4.5506274700164795e-01
    z[6,3,4]  R1867     2.1257656812667847e-01
    z[6,3,4]  R1868     1.7690427601337433e-01
    z[6,3,4]  R1869     4.7693067789077759e-01
    z[6,3,4]  R1870     5.3212434053421021e-02
    z[6,3,4]  R1871     4.0723349899053574e-02
    z[6,3,4]  R1872     7.6723806560039520e-02
    z[6,3,4]  R1873     -7.9503792524337769e-01
    z[6,3,4]  R1874     -4.2350319027900696e-01
    z[6,3,4]  R1875     -2.5479269027709961e-01
    z[6,3,4]  R1876     1.5232549607753754e-01
    z[6,3,4]  R1877     -4.6420025825500488e-01
    z[6,3,4]  R1878     -1.8094724416732788e-01
    z[6,3,4]  R1879     -4.8501467704772949e-01
    z[6,3,4]  R1880     1.4656354486942291e-01
    z[6,3,4]  R1881     -8.4032607078552246e-01
    z[6,3,4]  R1882     -2.1480195224285126e-01
    z[6,3,4]  R1883     -3.5190707445144653e-01
    z[6,3,4]  R1884     -5.5060088634490967e-02
    z[6,3,4]  R1885     3.3071920275688171e-01
    z[6,3,4]  R1886     4.6353048086166382e-01
    z[6,3,4]  R1887     1.7799116671085358e-01
    z[6,3,4]  R1888     1.0846702754497528e-01
    z[6,3,4]  R1889     -2.7862530946731567e-01
    z[6,3,4]  R1890     1.7154007218778133e-03
    z[6,3,4]  R1891     4.6138694882392883e-01
    z[6,3,4]  R1892     1.9123828411102295e-01
    z[6,3,4]  R1893     5.6625676155090332e-01
    z[6,3,4]  R1894     6.7100734449923038e-03
    z[6,3,4]  R1895     -3.0774167180061340e-01
    z[6,3,4]  R1896     -3.5249975323677063e-01
    z[6,3,4]  R1897     -4.7529861330986023e-02
    z[6,3,4]  R1898     -1.0738659650087357e-01
    z[6,3,4]  R1899     2.4396489560604095e-01
    z[6,3,4]  R1900     8.7059317156672478e-03
    z[6,3,5]  R34       1
    z[6,3,5]  R61       -1
    z[6,3,5]  R1798     -1
    z[6,3,5]  R1799     1
    z[6,3,5]  R1802     -4.1539106518030167e-02
    z[6,3,5]  R1803     2.2819447517395020e-01
    z[6,3,5]  R1804     1.7619884014129639e-01
    z[6,3,5]  R1805     1.3112403452396393e-01
    z[6,3,5]  R1806     1.2630765140056610e-01
    z[6,3,5]  R1807     3.9634126424789429e-01
    z[6,3,5]  R1808     -6.1755768954753876e-02
    z[6,3,5]  R1809     -1.6362796723842621e-01
    z[6,3,5]  R1810     -0.00947926752269268
    z[6,3,5]  R1811     3.7716919183731079e-01
    z[6,3,5]  R1812     -1.2126628309488297e-01
    z[6,3,5]  R1813     -8.2264598459005356e-03
    z[6,3,5]  R1814     7.7099567651748657e-01
    z[6,3,5]  R1815     -9.8559595644474030e-02
    z[6,3,5]  R1816     -3.2236614823341370e-01
    z[6,3,5]  R1817     -3.8575440645217896e-01
    z[6,3,5]  R1818     2.7779513597488403e-01
    z[6,3,5]  R1819     -4.8051732778549194e-01
    z[6,3,5]  R1820     -7.7186834812164307e-01
    z[6,3,5]  R1821     -4.4081023335456848e-01
    z[6,3,5]  R1822     4.9419414997100830e-01
    z[6,3,5]  R1823     -9.7955256700515747e-02
    z[6,3,5]  R1824     -0.336814820766449
    z[6,3,5]  R1825     -5.7692015171051025e-01
    z[6,3,5]  R1826     1.9828870892524719e-01
    z[6,3,5]  R1827     0.127718985080719
    z[6,3,5]  R1828     -7.1706116199493408e-01
    z[6,3,5]  R1829     4.2671549320220947e-01
    z[6,3,5]  R1830     -6.1563742160797119e-01
    z[6,3,5]  R1831     -4.0803611278533936e-02
    z[6,3,5]  R1832     2.2335672378540039e-01
    z[6,3,5]  R1833     4.1427803039550781e-01
    z[6,3,5]  R1834     -1.2038338184356689e-01
    z[6,3,5]  R1835     9.2470802366733551e-02
    z[6,3,5]  R1836     3.5213101655244827e-02
    z[6,3,5]  R1837     8.0370604991912842e-02
    z[6,3,5]  R1838     0.667449414730072
    z[6,3,5]  R1839     -2.9559394717216492e-01
    z[6,3,5]  R1840     -5.7194280624389648e-01
    z[6,3,5]  R1841     -3.8481815718114376e-03
    z[6,3,5]  R1842     2.5344986468553543e-02
    z[6,3,5]  R1843     2.5290971994400024e-01
    z[6,3,5]  R1844     -2.8588702902197838e-02
    z[6,3,5]  R1845     -4.4346663355827332e-01
    z[6,3,5]  R1846     -2.3948095738887787e-01
    z[6,3,5]  R1847     -7.2092288732528687e-01
    z[6,3,5]  R1848     -2.1446606516838074e-01
    z[6,3,5]  R1849     -4.3531975150108337e-01
    z[6,3,5]  R1850     -4.8618495464324951e-01
    z[6,3,5]  R1851     -6.1701752245426178e-02
    z[6,3,5]  R1852     1.9499303773045540e-02
    z[6,3,5]  R1853     -8.5549950599670410e-02
    z[6,3,5]  R1854     1.8580843508243561e-01
    z[6,3,5]  R1855     -4.3025019764900208e-01
    z[6,3,5]  R1856     -1.3461917638778687e-01
    z[6,3,5]  R1857     -9.5116794109344482e-02
    z[6,3,5]  R1858     0.000767854624427855
    z[6,3,5]  R1859     -5.7054489850997925e-01
    z[6,3,5]  R1860     -4.8150390386581421e-01
    z[6,3,5]  R1861     4.8109255731105804e-03
    z[6,3,5]  R1862     0.0659482404589653
    z[6,3,5]  R1863     4.9900867044925690e-02
    z[6,3,5]  R1864     7.3024815320968628e-01
    z[6,3,5]  R1865     5.9566396474838257e-01
    z[6,3,5]  R1866     1.7350588738918304e-01
    z[6,3,5]  R1867     3.6055192351341248e-01
    z[6,3,5]  R1868     2.2199960052967072e-01
    z[6,3,5]  R1869     8.2227960228919983e-02
    z[6,3,5]  R1870     -9.9870055913925171e-02
    z[6,3,5]  R1871     -4.5442107319831848e-01
    z[6,3,5]  R1872     -5.0220921635627747e-02
    z[6,3,5]  R1873     -3.7199845910072327e-01
    z[6,3,5]  R1874     -0.0775558203458786
    z[6,3,5]  R1875     -2.3853132128715515e-01
    z[6,3,5]  R1876     -6.6592812538146973e-02
    z[6,3,5]  R1877     3.8669112324714661e-01
    z[6,3,5]  R1878     1.0121560655534267e-02
    z[6,3,5]  R1879     -1.6500715911388397e-01
    z[6,3,5]  R1880     2.4496668577194214e-01
    z[6,3,5]  R1881     -2.4761931598186493e-01
    z[6,3,5]  R1882     3.2741222530603409e-02
    z[6,3,5]  R1883     1.2170637398958206e-01
    z[6,3,5]  R1884     -4.5652562379837036e-01
    z[6,3,5]  R1885     -4.9590140581130981e-01
    z[6,3,5]  R1886     -3.4327471256256104e-01
    z[6,3,5]  R1887     -0.851716935634613
    z[6,3,5]  R1888     -5.0868522375822067e-02
    z[6,3,5]  R1889     4.1360217332839966e-01
    z[6,3,5]  R1890     2.5672644376754761e-01
    z[6,3,5]  R1891     -5.8026784658432007e-01
    z[6,3,5]  R1892     -1.6099371016025543e-01
    z[6,3,5]  R1893     -2.3186303675174713e-01
    z[6,3,5]  R1894     -7.6824903488159180e-01
    z[6,3,5]  R1895     -4.3951433897018433e-01
    z[6,3,5]  R1896     2.1920882165431976e-01
    z[6,3,5]  R1897     3.8463580608367920e-01
    z[6,3,5]  R1898     -5.5725741386413574e-01
    z[6,3,5]  R1899     -3.1448632478713989e-02
    z[6,3,5]  R1900     3.2223203778266907e-01
    z[6,3,6]  R35       1
    z[6,3,6]  R62       -1
    z[6,3,6]  R1800     -1
    z[6,3,6]  R1801     1
    z[6,3,6]  R1802     2.6531422138214111e-01
    z[6,3,6]  R1803     1.2754152715206146e-01
    z[6,3,6]  R1804     1.3739053905010223e-01
    z[6,3,6]  R1805     1.5865311026573181e-01
    z[6,3,6]  R1806     -1.2897776067256927e-01
    z[6,3,6]  R1807     5.1337309181690216e-02
    z[6,3,6]  R1808     3.5426083207130432e-01
    z[6,3,6]  R1809     -2.1180485188961029e-01
    z[6,3,6]  R1810     -1.6379144787788391e-01
    z[6,3,6]  R1811     6.9629065692424774e-02
    z[6,3,6]  R1812     1.1301308125257492e-01
    z[6,3,6]  R1813     -0.0913948118686676
    z[6,3,6]  R1814     -1.2146764993667603e-01
    z[6,3,6]  R1815     -3.8080912828445435e-01
    z[6,3,6]  R1816     -2.7549448609352112e-01
    z[6,3,6]  R1817     -4.1617578268051147e-01
    z[6,3,6]  R1818     -2.3799885809421539e-01
    z[6,3,6]  R1819     -3.3573645353317261e-01
    z[6,3,6]  R1820     -8.6897037923336029e-02
    z[6,3,6]  R1821     -4.7503328323364258e-01
    z[6,3,6]  R1822     -1.4641021192073822e-01
    z[6,3,6]  R1823     -1.2273354083299637e-01
    z[6,3,6]  R1824     4.0288589894771576e-02
    z[6,3,6]  R1825     -2.5131475925445557e-01
    z[6,3,6]  R1826     -6.5688163042068481e-02
    z[6,3,6]  R1827     2.0194327458739281e-02
    z[6,3,6]  R1828     -3.3444055914878845e-01
    z[6,3,6]  R1829     1.5683636069297791e-01
    z[6,3,6]  R1830     1.6815623268485069e-02
    z[6,3,6]  R1831     -7.5065419077873230e-02
    z[6,3,6]  R1832     -4.6393796801567078e-02
    z[6,3,6]  R1833     9.8258063197135925e-02
    z[6,3,6]  R1834     -1.5908671915531158e-01
    z[6,3,6]  R1835     -2.9051387310028076e-01
    z[6,3,6]  R1836     -6.2175148725509644e-01
    z[6,3,6]  R1837     -4.0989780426025391e-01
    z[6,3,6]  R1838     3.0348291993141174e-01
    z[6,3,6]  R1839     1.2335287779569626e-01
    z[6,3,6]  R1840     7.8560203313827515e-02
    z[6,3,6]  R1841     2.9827767610549927e-01
    z[6,3,6]  R1842     0.0264901053160429
    z[6,3,6]  R1843     -6.8063624203205109e-02
    z[6,3,6]  R1844     -5.7983744889497757e-02
    z[6,3,6]  R1845     -2.0843598246574402e-01
    z[6,3,6]  R1846     -3.3385860919952393e-01
    z[6,3,6]  R1847     -1.8527679145336151e-01
    z[6,3,6]  R1848     1.6800068318843842e-01
    z[6,3,6]  R1849     1.2624703347682953e-01
    z[6,3,6]  R1850     1.1233668774366379e-01
    z[6,3,6]  R1851     2.2378845512866974e-01
    z[6,3,6]  R1852     -0.306953102350235
    z[6,3,6]  R1853     3.6419898271560669e-02
    z[6,3,6]  R1854     -0.0854058712720871
    z[6,3,6]  R1855     -2.8591899201273918e-02
    z[6,3,6]  R1856     2.2501243650913239e-01
    z[6,3,6]  R1857     -3.1531330943107605e-01
    z[6,3,6]  R1858     2.4544094502925873e-01
    z[6,3,6]  R1859     -3.0729341506958008e-01
    z[6,3,6]  R1860     -3.2387769222259521e-01
    z[6,3,6]  R1861     1.3507449626922607e-01
    z[6,3,6]  R1862     2.6652544736862183e-01
    z[6,3,6]  R1863     -2.8472086787223816e-01
    z[6,3,6]  R1864     4.1985213756561279e-02
    z[6,3,6]  R1865     -3.0993112921714783e-01
    z[6,3,6]  R1866     6.2922559678554535e-02
    z[6,3,6]  R1867     -8.6804866790771484e-02
    z[6,3,6]  R1868     1.6346450150012970e-01
    z[6,3,6]  R1869     -2.1336419880390167e-01
    z[6,3,6]  R1870     -1.5313178300857544e-01
    z[6,3,6]  R1871     -4.4341591000556946e-01
    z[6,3,6]  R1872     -5.8153618127107620e-02
    z[6,3,6]  R1873     -1.2105491012334824e-01
    z[6,3,6]  R1874     9.5740392804145813e-02
    z[6,3,6]  R1875     3.0108624696731567e-01
    z[6,3,6]  R1876     2.4864296615123749e-01
    z[6,3,6]  R1877     2.2193619608879089e-01
    z[6,3,6]  R1878     2.1507178246974945e-01
    z[6,3,6]  R1879     2.5794410705566406e-01
    z[6,3,6]  R1880     5.3128913044929504e-02
    z[6,3,6]  R1881     3.6897215992212296e-02
    z[6,3,6]  R1882     -3.7897691130638123e-01
    z[6,3,6]  R1883     5.0594788044691086e-02
    z[6,3,6]  R1884     2.8071720153093338e-02
    z[6,3,6]  R1885     1.2220699340105057e-01
    z[6,3,6]  R1886     -1.5717579424381256e-01
    z[6,3,6]  R1887     -2.1846961975097656e-01
    z[6,3,6]  R1888     -4.9315180629491806e-02
    z[6,3,6]  R1889     1.7198757827281952e-01
    z[6,3,6]  R1890     2.7713131904602051e-01
    z[6,3,6]  R1891     -3.1991052627563477e-01
    z[6,3,6]  R1892     5.1235571503639221e-02
    z[6,3,6]  R1893     -8.7080515921115875e-02
    z[6,3,6]  R1894     4.4334483146667480e-01
    z[6,3,6]  R1895     -3.5520243644714355e-01
    z[6,3,6]  R1896     -3.5905953496694565e-02
    z[6,3,6]  R1897     1.4304243028163910e-01
    z[6,3,6]  R1898     5.8000016957521439e-02
    z[6,3,6]  R1899     -9.6655987203121185e-02
    z[6,3,6]  R1900     -2.0759889483451843e-01
    z[4,5,0]  R38       -1
    z[4,5,0]  R47       1
    z[4,5,0]  R1955     -1
    z[4,5,0]  R1956     1
    z[4,5,0]  R1969     -5.7847633957862854e-02
    z[4,5,0]  R1970     2.3291967809200287e-01
    z[4,5,0]  R1971     1.9032852351665497e-01
    z[4,5,0]  R1972     1.0687439143657684e-01
    z[4,5,0]  R1973     1.2337212264537811e-01
    z[4,5,0]  R1974     -1.5379829704761505e-01
    z[4,5,0]  R1975     0.612011730670929
    z[4,5,0]  R1976     -2.5405046343803406e-01
    z[4,5,0]  R1977     -1.7137020826339722e-01
    z[4,5,0]  R1978     5.9136056900024414e-01
    z[4,5,0]  R1979     -3.8787201046943665e-01
    z[4,5,0]  R1980     -1.7020131647586823e-01
    z[4,5,0]  R1981     -1.3619169592857361e-01
    z[4,5,0]  R1982     4.5985409617424011e-01
    z[4,5,0]  R1983     1.5315456688404083e-01
    z[4,5,0]  R1984     3.9971357583999634e-01
    z[4,5,0]  R1985     3.3082881569862366e-01
    z[4,5,0]  R1986     -1.5886427462100983e-01
    z[4,5,0]  R1987     2.4377131462097168e-01
    z[4,5,0]  R1988     -9.3194320797920227e-02
    z[4,5,0]  R1989     -1.2749305367469788e-01
    z[4,5,0]  R1990     -3.3869582414627075e-01
    z[4,5,0]  R1991     -3.0979645252227783e-01
    z[4,5,0]  R1992     4.6450782567262650e-02
    z[4,5,0]  R1993     -5.0778716802597046e-01
    z[4,5,0]  R1994     -4.2351409792900085e-01
    z[4,5,0]  R1995     -2.8360605239868164e-01
    z[4,5,0]  R1996     5.3043287992477417e-01
    z[4,5,0]  R1997     5.4679775238037109e-01
    z[4,5,0]  R1998     4.1538336873054504e-01
    z[4,5,0]  R1999     -3.4991261363029480e-01
    z[4,5,0]  R2000     -6.5750330686569214e-02
    z[4,5,0]  R2001     6.4677906036376953e-01
    z[4,5,0]  R2002     2.2338490188121796e-01
    z[4,5,0]  R2003     2.0899084210395813e-01
    z[4,5,0]  R2004     5.5733382701873779e-01
    z[4,5,0]  R2005     8.4454685449600220e-01
    z[4,5,0]  R2006     3.7446701526641846e-01
    z[4,5,0]  R2007     7.4645286798477173e-01
    z[4,5,0]  R2008     4.8767754435539246e-01
    z[4,5,0]  R2009     3.3604595810174942e-02
    z[4,5,0]  R2010     5.7812124490737915e-01
    z[4,5,0]  R2011     8.7086832523345947e-01
    z[4,5,0]  R2012     -2.4377760291099548e-01
    z[4,5,0]  R2013     5.2036845684051514e-01
    z[4,5,0]  R2014     6.8450921773910522e-01
    z[4,5,0]  R2015     -1.7482032999396324e-03
    z[4,5,0]  R2016     4.1061496734619141e-01
    z[4,5,0]  R2017     -8.1347328424453735e-01
    z[4,5,0]  R2018     -7.9426652193069458e-01
    z[4,5,0]  R2019     -1.0821318626403809e-01
    z[4,5,0]  R2020     -6.9208703935146332e-02
    z[4,5,0]  R2021     -3.2698172330856323e-01
    z[4,5,0]  R2022     -0.609432578086853
    z[4,5,0]  R2023     -6.8806296586990356e-01
    z[4,5,0]  R2024     -8.0902999639511108e-01
    z[4,5,0]  R2025     -4.1726133227348328e-01
    z[4,5,0]  R2026     -3.1601142883300781e-01
    z[4,5,0]  R2027     -0.582899808883667
    z[4,5,0]  R2028     -1.7917427420616150e-01
    z[4,5,0]  R2029     3.0699586868286133e-01
    z[4,5,0]  R2030     4.4657203555107117e-01
    z[4,5,0]  R2031     3.9458346366882324e-01
    z[4,5,0]  R2032     2.7564147114753723e-01
    z[4,5,0]  R2033     1.1680698394775391e-01
    z[4,5,0]  R2034     -0.307258665561676
    z[4,5,0]  R2035     4.0832468867301941e-01
    z[4,5,0]  R2036     -1.1998391896486282e-01
    z[4,5,0]  R2037     -5.3194290399551392e-01
    z[4,5,0]  R2038     -2.1263392269611359e-01
    z[4,5,0]  R2039     1.7259493470191956e-01
    z[4,5,0]  R2040     2.1013502776622772e-01
    z[4,5,0]  R2041     9.5719449222087860e-02
    z[4,5,0]  R2042     7.5331754982471466e-02
    z[4,5,0]  R2043     -1.7011393606662750e-01
    z[4,5,0]  R2044     2.8778192400932312e-01
    z[4,5,0]  R2045     1.9439187645912170e-01
    z[4,5,0]  R2046     0.392865389585495
    z[4,5,0]  R2047     -6.4120173454284668e-02
    z[4,5,0]  R2048     3.1283938884735107e-01
    z[4,5,0]  R2049     -4.5278713107109070e-01
    z[4,5,0]  R2050     -4.3649911880493164e-02
    z[4,5,0]  R2051     3.8477461785078049e-02
    z[4,5,0]  R2052     -3.0019250512123108e-01
    z[4,5,0]  R2053     4.6667033433914185e-01
    z[4,5,0]  R2054     -5.4023897647857666e-01
    z[4,5,0]  R2055     0.0761353075504303
    z[4,5,0]  R2056     -1.2854102253913879e-01
    z[4,5,0]  R2057     -5.4745179414749146e-01
    z[4,5,1]  R39       -1
    z[4,5,1]  R48       1
    z[4,5,1]  R1957     -1
    z[4,5,1]  R1958     1
    z[4,5,1]  R1969     -2.2434207797050476e-01
    z[4,5,1]  R1970     -4.1379917412996292e-02
    z[4,5,1]  R1971     -4.6656742691993713e-02
    z[4,5,1]  R1972     -1.2432451546192169e-01
    z[4,5,1]  R1973     -7.1573257446289062e-02
    z[4,5,1]  R1974     5.6521035730838776e-02
    z[4,5,1]  R1975     -3.6553180217742920e-01
    z[4,5,1]  R1976     -8.5622303187847137e-02
    z[4,5,1]  R1977     0.0456363670527935
    z[4,5,1]  R1978     -2.4456253647804260e-01
    z[4,5,1]  R1979     8.4129935503005981e-01
    z[4,5,1]  R1980     8.6757284402847290e-01
    z[4,5,1]  R1981     8.4425538778305054e-01
    z[4,5,1]  R1982     -4.5689931511878967e-01
    z[4,5,1]  R1983     -7.9187095165252686e-01
    z[4,5,1]  R1984     2.4552106857299805e-01
    z[4,5,1]  R1985     -9.0515814721584320e-02
    z[4,5,1]  R1986     -3.9412230253219604e-01
    z[4,5,1]  R1987     -6.0985791683197021e-01
    z[4,5,1]  R1988     -6.7751926183700562e-01
    z[4,5,1]  R1989     -6.6503608226776123e-01
    z[4,5,1]  R1990     -7.6249647140502930e-01
    z[4,5,1]  R1991     -6.5101730823516846e-01
    z[4,5,1]  R1992     -7.9949998855590820e-01
    z[4,5,1]  R1993     -5.5410587787628174e-01
    z[4,5,1]  R1994     -0.576320469379425
    z[4,5,1]  R1995     -7.7463120222091675e-01
    z[4,5,1]  R1996     2.1554206311702728e-01
    z[4,5,1]  R1997     -0.500268816947937
    z[4,5,1]  R1998     -6.4946311712265015e-01
    z[4,5,1]  R1999     -3.6966410279273987e-01
    z[4,5,1]  R2000     -5.5434852838516235e-01
    z[4,5,1]  R2001     -5.8023804426193237e-01
    z[4,5,1]  R2002     1.1254636943340302e-01
    z[4,5,1]  R2003     1.1817237734794617e-01
    z[4,5,1]  R2004     -2.1881256997585297e-01
    z[4,5,1]  R2005     -8.0024182796478271e-02
    z[4,5,1]  R2006     -2.2036722302436829e-01
    z[4,5,1]  R2007     3.2096442580223083e-01
    z[4,5,1]  R2008     -7.2960913181304932e-01
    z[4,5,1]  R2009     -7.2324448823928833e-01
    z[4,5,1]  R2010     -5.4733687639236450e-01
    z[4,5,1]  R2011     -2.4741439521312714e-01
    z[4,5,1]  R2012     -4.4586917757987976e-01
    z[4,5,1]  R2013     -5.3672641515731812e-01
    z[4,5,1]  R2014     -2.4713842570781708e-01
    z[4,5,1]  R2015     -8.9190351963043213e-01
    z[4,5,1]  R2016     3.3194816112518311e-01
    z[4,5,1]  R2017     3.5491049289703369e-01
    z[4,5,1]  R2018     0.244643896818161
    z[4,5,1]  R2019     -3.2988885045051575e-01
    z[4,5,1]  R2020     -6.9191831350326538e-01
    z[4,5,1]  R2021     -8.0293434858322144e-01
    z[4,5,1]  R2022     -5.7155334949493408e-01
    z[4,5,1]  R2023     -4.9672827124595642e-01
    z[4,5,1]  R2024     -2.3610962927341461e-01
    z[4,5,1]  R2025     1.0668906569480896e-01
    z[4,5,1]  R2026     1.1416645348072052e-01
    z[4,5,1]  R2027     2.0661045610904694e-01
    z[4,5,1]  R2028     0.737488329410553
    z[4,5,1]  R2029     7.8674137592315674e-01
    z[4,5,1]  R2030     4.9484989047050476e-01
    z[4,5,1]  R2031     6.3993936777114868e-01
    z[4,5,1]  R2032     5.3592085838317871e-01
    z[4,5,1]  R2033     6.3357603549957275e-01
    z[4,5,1]  R2034     6.0925018787384033e-01
    z[4,5,1]  R2035     5.5019748210906982e-01
    z[4,5,1]  R2036     5.4293698072433472e-01
    z[4,5,1]  R2037     6.1711353063583374e-01
    z[4,5,1]  R2038     -0.664252758026123
    z[4,5,1]  R2039     -7.3075622320175171e-01
    z[4,5,1]  R2040     -9.7127676010131836e-01
    z[4,5,1]  R2041     -9.6090388298034668e-01
    z[4,5,1]  R2042     -9.1653537750244141e-01
    z[4,5,1]  R2043     -9.2195582389831543e-01
    z[4,5,1]  R2044     -8.9673334360122681e-01
    z[4,5,1]  R2045     -9.1193628311157227e-01
    z[4,5,1]  R2046     -8.3954977989196777e-01
    z[4,5,1]  R2047     -0.900809109210968
    z[4,5,1]  R2048     5.2828085422515869e-01
    z[4,5,1]  R2049     2.4775977432727814e-01
    z[4,5,1]  R2050     4.3066747486591339e-02
    z[4,5,1]  R2051     -6.1472386121749878e-01
    z[4,5,1]  R2052     -8.9177715778350830e-01
    z[4,5,1]  R2053     -6.4031100273132324e-01
    z[4,5,1]  R2054     -7.4875533580780029e-01
    z[4,5,1]  R2055     -4.7622591257095337e-01
    z[4,5,1]  R2056     -7.6080149412155151e-01
    z[4,5,1]  R2057     -3.2570815086364746e-01
    z[4,5,2]  R40       -1
    z[4,5,2]  R49       1
    z[4,5,2]  R1959     -1
    z[4,5,2]  R1960     1
    z[4,5,2]  R1969     -5.9244537353515625e-01
    z[4,5,2]  R1970     -8.2150202989578247e-01
    z[4,5,2]  R1971     -5.4357331991195679e-01
    z[4,5,2]  R1972     -3.1353580951690674e-01
    z[4,5,2]  R1973     -7.3006719350814819e-01
    z[4,5,2]  R1974     -7.2983759641647339e-01
    z[4,5,2]  R1975     -2.6255834102630615e-01
    z[4,5,2]  R1976     -2.2652576863765717e-01
    z[4,5,2]  R1977     -6.6095048189163208e-01
    z[4,5,2]  R1978     -6.0441619157791138e-01
    z[4,5,2]  R1979     1.1838949285447598e-02
    z[4,5,2]  R1980     -8.1899136304855347e-02
    z[4,5,2]  R1981     -4.5951315760612488e-01
    z[4,5,2]  R1982     6.1652439832687378e-01
    z[4,5,2]  R1983     2.8402274474501610e-02
    z[4,5,2]  R1984     2.7462553977966309e-01
    z[4,5,2]  R1985     4.0592372417449951e-01
    z[4,5,2]  R1986     2.7861317619681358e-02
    z[4,5,2]  R1987     2.7157512307167053e-01
    z[4,5,2]  R1988     1.4036209881305695e-01
    z[4,5,2]  R1989     -1.9590763747692108e-01
    z[4,5,2]  R1990     -2.3073473572731018e-01
    z[4,5,2]  R1991     -3.0537730455398560e-01
    z[4,5,2]  R1992     2.0183049142360687e-01
    z[4,5,2]  R1993     -2.9556852579116821e-01
    z[4,5,2]  R1994     -4.0751591324806213e-01
    z[4,5,2]  R1995     -1.1781888455152512e-01
    z[4,5,2]  R1996     -6.2708705663681030e-02
    z[4,5,2]  R1997     -7.0346496999263763e-02
    z[4,5,2]  R1998     3.0369493365287781e-01
    z[4,5,2]  R1999     -2.3955148458480835e-01
    z[4,5,2]  R2000     -5.7545232772827148e-01
    z[4,5,2]  R2001     9.1637238860130310e-02
    z[4,5,2]  R2002     -5.8281220495700836e-02
    z[4,5,2]  R2003     -2.0295043289661407e-01
    z[4,5,2]  R2004     -1.2939724326133728e-01
    z[4,5,2]  R2005     5.9550367295742035e-02
    z[4,5,2]  R2006     -2.1915417909622192e-01
    z[4,5,2]  R2007     -5.4754824377596378e-03
    z[4,5,2]  R2008     2.2998669743537903e-01
    z[4,5,2]  R2009     -3.3640664815902710e-01
    z[4,5,2]  R2010     -2.1699997782707214e-01
    z[4,5,2]  R2011     1.5533640980720520e-01
    z[4,5,2]  R2012     -6.7132425308227539e-01
    z[4,5,2]  R2013     -0.544070839881897
    z[4,5,2]  R2014     1.1546090245246887e-01
    z[4,5,2]  R2015     2.4799892306327820e-01
    z[4,5,2]  R2016     -2.8383618593215942e-01
    z[4,5,2]  R2017     7.4420824646949768e-02
    z[4,5,2]  R2018     4.0437978506088257e-01
    z[4,5,2]  R2019     5.6865561753511429e-02
    z[4,5,2]  R2020     -4.4046363234519958e-01
    z[4,5,2]  R2021     2.0109033584594727e-01
    z[4,5,2]  R2022     -1.4814113080501556e-01
    z[4,5,2]  R2023     -2.4655283987522125e-01
    z[4,5,2]  R2024     -4.0472263097763062e-01
    z[4,5,2]  R2025     7.9461358487606049e-02
    z[4,5,2]  R2026     3.3187928795814514e-01
    z[4,5,2]  R2027     3.6535346508026123e-01
    z[4,5,2]  R2028     2.4410922825336456e-01
    z[4,5,2]  R2029     1.5601533651351929e-01
    z[4,5,2]  R2030     2.0370896160602570e-01
    z[4,5,2]  R2031     -2.0028610527515411e-01
    z[4,5,2]  R2032     -0.275034099817276
    z[4,5,2]  R2033     -3.3176821470260620e-01
    z[4,5,2]  R2034     -7.0576362311840057e-02
    z[4,5,2]  R2035     -5.0805234909057617e-01
    z[4,5,2]  R2036     -2.9526489973068237e-01
    z[4,5,2]  R2037     -3.7029787898063660e-01
    z[4,5,2]  R2038     -7.2793923318386078e-02
    z[4,5,2]  R2039     -3.4349292516708374e-01
    z[4,5,2]  R2040     -7.7627012506127357e-03
    z[4,5,2]  R2041     1.4133757352828979e-01
    z[4,5,2]  R2042     -2.7460965514183044e-01
    z[4,5,2]  R2043     -4.9809359014034271e-02
    z[4,5,2]  R2044     2.4540388584136963e-01
    z[4,5,2]  R2045     -3.3133223652839661e-01
    z[4,5,2]  R2046     2.9985567927360535e-01
    z[4,5,2]  R2047     -1.1389529705047607e-01
    z[4,5,2]  R2048     -8.6399927735328674e-02
    z[4,5,2]  R2049     6.4769244194030762e-01
    z[4,5,2]  R2050     7.2858351469039917e-01
    z[4,5,2]  R2051     2.9134291410446167e-01
    z[4,5,2]  R2052     -2.1549564599990845e-01
    z[4,5,2]  R2053     2.0287392660975456e-02
    z[4,5,2]  R2054     3.4914724528789520e-02
    z[4,5,2]  R2055     1.6762803494930267e-01
    z[4,5,2]  R2056     3.2696092128753662e-01
    z[4,5,2]  R2057     -0.512986421585083
    z[4,5,3]  R41       -1
    z[4,5,3]  R50       1
    z[4,5,3]  R1961     -1
    z[4,5,3]  R1962     1
    z[4,5,3]  R1969     2.3699685931205750e-01
    z[4,5,3]  R1970     1.1154517531394958e-01
    z[4,5,3]  R1971     -8.6395636200904846e-02
    z[4,5,3]  R1972     1.1555530875921249e-01
    z[4,5,3]  R1973     1.3171684741973877e-01
    z[4,5,3]  R1974     3.5918179154396057e-01
    z[4,5,3]  R1975     -5.3258669376373291e-01
    z[4,5,3]  R1976     4.1792401671409607e-01
    z[4,5,3]  R1977     -9.7393877804279327e-02
    z[4,5,3]  R1978     -2.8344443440437317e-01
    z[4,5,3]  R1979     -0.271945595741272
    z[4,5,3]  R1980     -1.5372280776500702e-01
    z[4,5,3]  R1981     -1.1726742237806320e-01
    z[4,5,3]  R1982     1.5897387266159058e-01
    z[4,5,3]  R1983     5.3039681911468506e-01
    z[4,5,3]  R1984     4.7791481018066406e-01
    z[4,5,3]  R1985     4.5172640681266785e-01
    z[4,5,3]  R1986     6.5011823177337646e-01
    z[4,5,3]  R1987     6.2212830781936646e-01
    z[4,5,3]  R1988     -1.4795914292335510e-01
    z[4,5,3]  R1989     6.3086384534835815e-01
    z[4,5,3]  R1990     -2.1271225810050964e-01
    z[4,5,3]  R1991     1.8182241916656494e-01
    z[4,5,3]  R1992     4.9371698498725891e-01
    z[4,5,3]  R1993     2.0419631898403168e-01
    z[4,5,3]  R1994     -2.2921408712863922e-01
    z[4,5,3]  R1995     -2.2812442481517792e-01
    z[4,5,3]  R1996     -0.72444748878479
    z[4,5,3]  R1997     3.3810603618621826e-01
    z[4,5,3]  R1998     1.8640232086181641e-01
    z[4,5,3]  R1999     -4.8062512278556824e-01
    z[4,5,3]  R2000     -0.483710378408432
    z[4,5,3]  R2001     5.6191053241491318e-02
    z[4,5,3]  R2002     -3.6831229925155640e-01
    z[4,5,3]  R2003     1.6339768469333649e-01
    z[4,5,3]  R2004     1.0380907356739044e-01
    z[4,5,3]  R2005     1.1003208905458450e-01
    z[4,5,3]  R2006     6.5903908014297485e-01
    z[4,5,3]  R2007     -3.2897201180458069e-01
    z[4,5,3]  R2008     -1.5643297135829926e-01
    z[4,5,3]  R2009     3.9144212007522583e-01
    z[4,5,3]  R2010     -0.00906385201960802
    z[4,5,3]  R2011     -4.2518965899944305e-02
    z[4,5,3]  R2012     -4.3219098448753357e-01
    z[4,5,3]  R2013     2.7163645625114441e-01
    z[4,5,3]  R2014     2.2988820075988770e-01
    z[4,5,3]  R2015     -6.2464926391839981e-02
    z[4,5,3]  R2016     3.9827436208724976e-01
    z[4,5,3]  R2017     3.6196565628051758e-01
    z[4,5,3]  R2018     3.5333672165870667e-01
    z[4,5,3]  R2019     -2.4791575968265533e-01
    z[4,5,3]  R2020     -1.5276212990283966e-01
    z[4,5,3]  R2021     3.0615553259849548e-01
    z[4,5,3]  R2022     2.4574624840170145e-03
    z[4,5,3]  R2023     1.8979637324810028e-01
    z[4,5,3]  R2024     -1.6697503626346588e-01
    z[4,5,3]  R2025     -0.798019289970398
    z[4,5,3]  R2026     -8.2056099176406860e-01
    z[4,5,3]  R2027     4.1949599981307983e-01
    z[4,5,3]  R2028     5.5193895101547241e-01
    z[4,5,3]  R2029     -4.0297082066535950e-01
    z[4,5,3]  R2030     -6.5933072566986084e-01
    z[4,5,3]  R2031     -1.6667121648788452e-01
    z[4,5,3]  R2032     -4.6102777123451233e-01
    z[4,5,3]  R2033     -4.1386270523071289e-01
    z[4,5,3]  R2034     2.9408720135688782e-01
    z[4,5,3]  R2035     3.2679751515388489e-01
    z[4,5,3]  R2036     -1.5496331453323364e-01
    z[4,5,3]  R2037     3.8975742459297180e-01
    z[4,5,3]  R2038     -5.6434392929077148e-01
    z[4,5,3]  R2039     -5.4792308807373047e-01
    z[4,5,3]  R2040     -2.5889266282320023e-02
    z[4,5,3]  R2041     7.3489256203174591e-02
    z[4,5,3]  R2042     -9.3063563108444214e-03
    z[4,5,3]  R2043     1.6248162090778351e-01
    z[4,5,3]  R2044     2.1792547404766083e-01
    z[4,5,3]  R2045     1.0399517416954041e-01
    z[4,5,3]  R2046     -1.1378584057092667e-01
    z[4,5,3]  R2047     1.6098581254482269e-01
    z[4,5,3]  R2048     2.6375246047973633e-01
    z[4,5,3]  R2049     -4.4963663816452026e-01
    z[4,5,3]  R2050     -2.0457515120506287e-01
    z[4,5,3]  R2051     -4.1944715380668640e-01
    z[4,5,3]  R2052     -1.7698907852172852e-01
    z[4,5,3]  R2053     -1.0731939971446991e-01
    z[4,5,3]  R2054     -2.1491670049726963e-03
    z[4,5,3]  R2055     -1.4721606671810150e-01
    z[4,5,3]  R2056     7.5632028281688690e-02
    z[4,5,3]  R2057     -1.1487320810556412e-01
    z[4,5,4]  R42       -1
    z[4,5,4]  R51       1
    z[4,5,4]  R1963     -1
    z[4,5,4]  R1964     1
    z[4,5,4]  R1969     -5.9807217121124268e-01
    z[4,5,4]  R1970     -4.9848622083663940e-01
    z[4,5,4]  R1971     -6.5336924791336060e-01
    z[4,5,4]  R1972     -7.2163826227188110e-01
    z[4,5,4]  R1973     -3.5952815413475037e-01
    z[4,5,4]  R1974     -4.0824940800666809e-01
    z[4,5,4]  R1975     3.1452366709709167e-01
    z[4,5,4]  R1976     -0.684838056564331
    z[4,5,4]  R1977     -4.1711923480033875e-01
    z[4,5,4]  R1978     1.0789326392114162e-02
    z[4,5,4]  R1979     -1.2407668679952621e-01
    z[4,5,4]  R1980     -1.8454334139823914e-01
    z[4,5,4]  R1981     1.1577981710433960e-01
    z[4,5,4]  R1982     -3.2115232944488525e-01
    z[4,5,4]  R1983     -4.9837838858366013e-02
    z[4,5,4]  R1984     -3.9657387137413025e-01
    z[4,5,4]  R1985     -0.182534858584404
    z[4,5,4]  R1986     3.5078135132789612e-01
    z[4,5,4]  R1987     5.4858420044183731e-02
    z[4,5,4]  R1988     1.3900396227836609e-01
    z[4,5,4]  R1989     2.7258116006851196e-01
    z[4,5,4]  R1990     4.3921627104282379e-02
    z[4,5,4]  R1991     5.8377593755722046e-01
    z[4,5,4]  R1992     8.3564937114715576e-02
    z[4,5,4]  R1993     1.8081174790859222e-01
    z[4,5,4]  R1994     4.6877473592758179e-01
    z[4,5,4]  R1995     1.3864706456661224e-01
    z[4,5,4]  R1996     -2.5935885310173035e-01
    z[4,5,4]  R1997     -4.4898489117622375e-01
    z[4,5,4]  R1998     -2.8888520598411560e-01
    z[4,5,4]  R1999     -5.4572808742523193e-01
    z[4,5,4]  R2000     1.7076827585697174e-02
    z[4,5,4]  R2001     -0.0605459026992321
    z[4,5,4]  R2002     -8.3162176609039307e-01
    z[4,5,4]  R2003     -2.4538438022136688e-01
    z[4,5,4]  R2004     -6.3393193483352661e-01
    z[4,5,4]  R2005     -4.3460991978645325e-01
    z[4,5,4]  R2006     -4.3667531013488770e-01
    z[4,5,4]  R2007     -3.4096285700798035e-01
    z[4,5,4]  R2008     -3.3043101429939270e-01
    z[4,5,4]  R2009     -6.0014687478542328e-02
    z[4,5,4]  R2010     -4.6652728319168091e-01
    z[4,5,4]  R2011     -3.2168093323707581e-01
    z[4,5,4]  R2012     -1.8092378973960876e-01
    z[4,5,4]  R2013     1.0825133323669434e-01
    z[4,5,4]  R2014     1.2555750086903572e-02
    z[4,5,4]  R2015     3.4217610955238342e-01
    z[4,5,4]  R2016     -5.0948488712310791e-01
    z[4,5,4]  R2017     1.9620832800865173e-01
    z[4,5,4]  R2018     1.0042093694210052e-01
    z[4,5,4]  R2019     -8.4013324975967407e-01
    z[4,5,4]  R2020     4.8353976011276245e-01
    z[4,5,4]  R2021     -2.5056087970733643e-01
    z[4,5,4]  R2022     -3.0108615756034851e-01
    z[4,5,4]  R2023     -3.7153720855712891e-02
    z[4,5,4]  R2024     -2.7126485109329224e-01
    z[4,5,4]  R2025     3.7175214290618896e-01
    z[4,5,4]  R2026     2.4538248777389526e-01
    z[4,5,4]  R2027     -6.3851051032543182e-02
    z[4,5,4]  R2028     -2.1366906166076660e-01
    z[4,5,4]  R2029     2.9065829515457153e-01
    z[4,5,4]  R2030     1.4960610866546631e-01
    z[4,5,4]  R2031     7.0273235440254211e-02
    z[4,5,4]  R2032     1.9583707675337791e-02
    z[4,5,4]  R2033     3.1935390830039978e-01
    z[4,5,4]  R2034     2.5885611772537231e-01
    z[4,5,4]  R2035     3.1587433815002441e-01
    z[4,5,4]  R2036     4.3797993659973145e-01
    z[4,5,4]  R2037     -2.6162989437580109e-02
    z[4,5,4]  R2038     -0.0783790573477745
    z[4,5,4]  R2039     9.8554842174053192e-02
    z[4,5,4]  R2040     8.3417415618896484e-02
    z[4,5,4]  R2041     -1.2464637309312820e-01
    z[4,5,4]  R2042     1.1390948295593262e-01
    z[4,5,4]  R2043     -2.8092622756958008e-02
    z[4,5,4]  R2044     3.9715595543384552e-02
    z[4,5,4]  R2045     8.3001688122749329e-02
    z[4,5,4]  R2046     1.3679456710815430e-01
    z[4,5,4]  R2047     -2.5100448727607727e-01
    z[4,5,4]  R2048     1.2115333974361420e-01
    z[4,5,4]  R2049     -1.7842277884483337e-01
    z[4,5,4]  R2050     -3.1928396224975586e-01
    z[4,5,4]  R2051     -4.0278270840644836e-01
    z[4,5,4]  R2052     -7.5008712708950043e-02
    z[4,5,4]  R2053     -1.9184872508049011e-01
    z[4,5,4]  R2054     -3.7234139442443848e-01
    z[4,5,4]  R2055     -4.0335541963577271e-01
    z[4,5,4]  R2056     -9.4079233705997467e-02
    z[4,5,4]  R2057     -4.3830177187919617e-01
    z[4,5,5]  R43       -1
    z[4,5,5]  R52       1
    z[4,5,5]  R1965     -1
    z[4,5,5]  R1966     1
    z[4,5,5]  R1969     2.7588501572608948e-01
    z[4,5,5]  R1970     0.0768398642539978
    z[4,5,5]  R1971     4.8011988401412964e-01
    z[4,5,5]  R1972     4.0588292479515076e-01
    z[4,5,5]  R1973     5.3919738531112671e-01
    z[4,5,5]  R1974     3.0846032500267029e-01
    z[4,5,5]  R1975     -1.7066171392798424e-02
    z[4,5,5]  R1976     4.3200677633285522e-01
    z[4,5,5]  R1977     7.2658412158489227e-02
    z[4,5,5]  R1978     3.8039374351501465e-01
    z[4,5,5]  R1979     1.8794685602188110e-01
    z[4,5,5]  R1980     3.1153056025505066e-01
    z[4,5,5]  R1981     3.4912928938865662e-02
    z[4,5,5]  R1982     1.9149954617023468e-01
    z[4,5,5]  R1983     -4.0843873284757137e-03
    z[4,5,5]  R1984     2.9163593053817749e-01
    z[4,5,5]  R1985     5.9292250871658325e-01
    z[4,5,5]  R1986     3.4390920400619507e-01
    z[4,5,5]  R1987     2.2979740798473358e-01
    z[4,5,5]  R1988     2.3302505910396576e-01
    z[4,5,5]  R1989     8.0706931650638580e-02
    z[4,5,5]  R1990     -5.3153578191995621e-02
    z[4,5,5]  R1991     -1.1309825628995895e-01
    z[4,5,5]  R1992     -2.2733679413795471e-01
    z[4,5,5]  R1993     5.2110069990158081e-01
    z[4,5,5]  R1994     2.2259102761745453e-01
    z[4,5,5]  R1995     4.0817445516586304e-01
    z[4,5,5]  R1996     1.9557489454746246e-01
    z[4,5,5]  R1997     -2.4819038808345795e-01
    z[4,5,5]  R1998     1.9170695543289185e-01
    z[4,5,5]  R1999     3.0538302659988403e-01
    z[4,5,5]  R2000     5.1258746534585953e-02
    z[4,5,5]  R2001     4.7907531261444092e-01
    z[4,5,5]  R2002     -0.314779132604599
    z[4,5,5]  R2003     9.0232640504837036e-01
    z[4,5,5]  R2004     1.3097949326038361e-01
    z[4,5,5]  R2005     -5.8001402765512466e-02
    z[4,5,5]  R2006     3.7141764163970947e-01
    z[4,5,5]  R2007     1.2606818974018097e-01
    z[4,5,5]  R2008     -1.2264557927846909e-01
    z[4,5,5]  R2009     1.4420942962169647e-01
    z[4,5,5]  R2010     -2.9039919376373291e-01
    z[4,5,5]  R2011     1.4926192164421082e-01
    z[4,5,5]  R2012     -0.0517929382622242
    z[4,5,5]  R2013     -0.0381213054060936
    z[4,5,5]  R2014     1.5846368670463562e-01
    z[4,5,5]  R2015     1.2515859305858612e-01
    z[4,5,5]  R2016     3.9180997014045715e-01
    z[4,5,5]  R2017     -1.6171494126319885e-01
    z[4,5,5]  R2018     -8.8415652513504028e-02
    z[4,5,5]  R2019     -3.2338467240333557e-01
    z[4,5,5]  R2020     1.0416987538337708e-01
    z[4,5,5]  R2021     -1.7621999979019165e-01
    z[4,5,5]  R2022     -3.2661595940589905e-01
    z[4,5,5]  R2023     -4.2096513509750366e-01
    z[4,5,5]  R2024     -4.1891392320394516e-02
    z[4,5,5]  R2025     -1.3399402797222137e-01
    z[4,5,5]  R2026     -1.3040751218795776e-01
    z[4,5,5]  R2027     -0.0849934071302414
    z[4,5,5]  R2028     -3.3173050731420517e-02
    z[4,5,5]  R2029     -7.7897910960018635e-03
    z[4,5,5]  R2030     -8.7487258017063141e-02
    z[4,5,5]  R2031     -1.5370495617389679e-02
    z[4,5,5]  R2032     -5.7310339063405991e-02
    z[4,5,5]  R2033     3.4435328841209412e-01
    z[4,5,5]  R2034     2.1307244896888733e-01
    z[4,5,5]  R2035     6.8327270448207855e-02
    z[4,5,5]  R2036     1.6446320712566376e-01
    z[4,5,5]  R2037     1.2961356341838837e-01
    z[4,5,5]  R2038     -2.1874779462814331e-01
    z[4,5,5]  R2039     -6.9876156747341156e-02
    z[4,5,5]  R2040     5.9693735092878342e-02
    z[4,5,5]  R2041     4.1034642606973648e-02
    z[4,5,5]  R2042     2.2982439398765564e-01
    z[4,5,5]  R2043     2.9859346151351929e-01
    z[4,5,5]  R2044     5.8090966194868088e-02
    z[4,5,5]  R2045     -5.0983525812625885e-02
    z[4,5,5]  R2046     1.3351324200630188e-01
    z[4,5,5]  R2047     -2.8407073020935059e-01
    z[4,5,5]  R2048     -5.4629868268966675e-01
    z[4,5,5]  R2049     2.7882248163223267e-01
    z[4,5,5]  R2050     -4.6346664428710938e-01
    z[4,5,5]  R2051     -3.3060312271118164e-01
    z[4,5,5]  R2052     5.1499918103218079e-02
    z[4,5,5]  R2053     -5.3591352701187134e-01
    z[4,5,5]  R2054     6.3986793160438538e-02
    z[4,5,5]  R2055     -7.3307341337203979e-01
    z[4,5,5]  R2056     -1.4958636462688446e-01
    z[4,5,5]  R2057     -3.4186232089996338e-01
    z[4,5,6]  R44       -1
    z[4,5,6]  R53       1
    z[4,5,6]  R1967     -1
    z[4,5,6]  R1968     1
    z[4,5,6]  R1969     -3.2459592819213867e-01
    z[4,5,6]  R1970     4.8325583338737488e-02
    z[4,5,6]  R1971     -3.5433974117040634e-02
    z[4,5,6]  R1972     4.1947695612907410e-01
    z[4,5,6]  R1973     9.6513405442237854e-02
    z[4,5,6]  R1974     2.2284905612468719e-01
    z[4,5,6]  R1975     -2.0006555318832397e-01
    z[4,5,6]  R1976     2.1568414568901062e-01
    z[4,5,6]  R1977     5.8561146259307861e-01
    z[4,5,6]  R1978     2.5013424456119537e-03
    z[4,5,6]  R1979     1.3021971285343170e-01
    z[4,5,6]  R1980     -2.3854376375675201e-01
    z[4,5,6]  R1981     -1.7075374722480774e-01
    z[4,5,6]  R1982     1.8598724901676178e-01
    z[4,5,6]  R1983     2.5466856360435486e-01
    z[4,5,6]  R1984     -4.8353332281112671e-01
    z[4,5,6]  R1985     -3.5868138074874878e-01
    z[4,5,6]  R1986     -3.9329206943511963e-01
    z[4,5,6]  R1987     -2.2811383008956909e-01
    z[4,5,6]  R1988     6.4580667018890381e-01
    z[4,5,6]  R1989     -1.5585084259510040e-01
    z[4,5,6]  R1990     -4.4793391227722168e-01
    z[4,5,6]  R1991     -1.7386395484209061e-02
    z[4,5,6]  R1992     -1.2443863600492477e-01
    z[4,5,6]  R1993     4.2697262018918991e-02
    z[4,5,6]  R1994     -2.4199962615966797e-02
    z[4,5,6]  R1995     2.6031273603439331e-01
    z[4,5,6]  R1996     1.9470381736755371e-01
    z[4,5,6]  R1997     2.6132947206497192e-01
    z[4,5,6]  R1998     -0.398084819316864
    z[4,5,6]  R1999     2.4788361787796021e-01
    z[4,5,6]  R2000     3.4689265489578247e-01
    z[4,5,6]  R2001     -1.6337784007191658e-02
    z[4,5,6]  R2002     -8.7756089866161346e-02
    z[4,5,6]  R2003     -7.9994276165962219e-03
    z[4,5,6]  R2004     4.4153681397438049e-01
    z[4,5,6]  R2005     -2.6913493871688843e-01
    z[4,5,6]  R2006     -1.4677749946713448e-02
    z[4,5,6]  R2007     -3.1525948643684387e-01
    z[4,5,6]  R2008     1.6807551681995392e-01
    z[4,5,6]  R2009     4.3010881543159485e-01
    z[4,5,6]  R2010     -1.3056711852550507e-01
    z[4,5,6]  R2011     -1.6935016214847565e-01
    z[4,5,6]  R2012     2.6247268915176392e-01
    z[4,5,6]  R2013     -2.4118547141551971e-01
    z[4,5,6]  R2014     -6.1556601524353027e-01
    z[4,5,6]  R2015     7.9690247774124146e-02
    z[4,5,6]  R2016     -2.6254606246948242e-01
    z[4,5,6]  R2017     -1.0532230883836746e-01
    z[4,5,6]  R2018     5.4940257221460342e-02
    z[4,5,6]  R2019     6.6073901951313019e-02
    z[4,5,6]  R2020     2.3335088789463043e-01
    z[4,5,6]  R2021     1.4274649322032928e-01
    z[4,5,6]  R2022     2.8746458888053894e-01
    z[4,5,6]  R2023     -6.6539153456687927e-02
    z[4,5,6]  R2024     1.5067237615585327e-01
    z[4,5,6]  R2025     -1.2331873923540115e-01
    z[4,5,6]  R2026     -1.6254171729087830e-01
    z[4,5,6]  R2027     -5.4477435350418091e-01
    z[4,5,6]  R2028     1.1413425207138062e-01
    z[4,5,6]  R2029     -1.2458848953247070e-01
    z[4,5,6]  R2030     2.2236593067646027e-01
    z[4,5,6]  R2031     0.60142582654953
    z[4,5,6]  R2032     5.8732640743255615e-01
    z[4,5,6]  R2033     2.8813013434410095e-01
    z[4,5,6]  R2034     -0.574918806552887
    z[4,5,6]  R2035     2.4737544357776642e-01
    z[4,5,6]  R2036     -6.0062789916992188e-01
    z[4,5,6]  R2037     -1.7231461405754089e-01
    z[4,5,6]  R2038     -3.6848086118698120e-01
    z[4,5,6]  R2039     5.8339715003967285e-02
    z[4,5,6]  R2040     -3.4821897745132446e-02
    z[4,5,6]  R2041     1.5780979394912720e-01
    z[4,5,6]  R2042     1.1400125920772552e-01
    z[4,5,6]  R2043     4.7225605696439743e-02
    z[4,5,6]  R2044     -0.019609235227108
    z[4,5,6]  R2045     -2.2348802536725998e-02
    z[4,5,6]  R2046     3.7599030882120132e-02
    z[4,5,6]  R2047     -4.2935546487569809e-02
    z[4,5,6]  R2048     -4.8259723186492920e-01
    z[4,5,6]  R2049     -4.8410382121801376e-02
    z[4,5,6]  R2050     -3.2682019472122192e-01
    z[4,5,6]  R2051     2.9712799191474915e-01
    z[4,5,6]  R2052     -1.6904434561729431e-01
    z[4,5,6]  R2053     1.9047904014587402e-01
    z[4,5,6]  R2054     5.9592097997665405e-02
    z[4,5,6]  R2055     -1.3247039914131165e-01
    z[4,5,6]  R2056     -5.1069319248199463e-01
    z[4,5,6]  R2057     9.4242349267005920e-02
    z[5,4,0]  R38       1
    z[5,4,0]  R47       -1
    z[5,4,0]  R2058     -1
    z[5,4,0]  R2059     1
    z[5,4,0]  R2072     -1.7917427420616150e-01
    z[5,4,0]  R2073     3.0699586868286133e-01
    z[5,4,0]  R2074     4.4657203555107117e-01
    z[5,4,0]  R2075     3.9458346366882324e-01
    z[5,4,0]  R2076     2.7564147114753723e-01
    z[5,4,0]  R2077     1.1680698394775391e-01
    z[5,4,0]  R2078     -0.307258665561676
    z[5,4,0]  R2079     4.0832468867301941e-01
    z[5,4,0]  R2080     -1.1998391896486282e-01
    z[5,4,0]  R2081     -5.3194290399551392e-01
    z[5,4,0]  R2082     -2.1263392269611359e-01
    z[5,4,0]  R2083     1.7259493470191956e-01
    z[5,4,0]  R2084     2.1013502776622772e-01
    z[5,4,0]  R2085     9.5719449222087860e-02
    z[5,4,0]  R2086     7.5331754982471466e-02
    z[5,4,0]  R2087     -1.7011393606662750e-01
    z[5,4,0]  R2088     2.8778192400932312e-01
    z[5,4,0]  R2089     1.9439187645912170e-01
    z[5,4,0]  R2090     0.392865389585495
    z[5,4,0]  R2091     -6.4120173454284668e-02
    z[5,4,0]  R2092     3.1283938884735107e-01
    z[5,4,0]  R2093     -4.5278713107109070e-01
    z[5,4,0]  R2094     -4.3649911880493164e-02
    z[5,4,0]  R2095     3.8477461785078049e-02
    z[5,4,0]  R2096     -3.0019250512123108e-01
    z[5,4,0]  R2097     4.6667033433914185e-01
    z[5,4,0]  R2098     -5.4023897647857666e-01
    z[5,4,0]  R2099     0.0761353075504303
    z[5,4,0]  R2100     -1.2854102253913879e-01
    z[5,4,0]  R2101     -5.4745179414749146e-01
    z[5,4,0]  R2102     -5.7847633957862854e-02
    z[5,4,0]  R2103     2.3291967809200287e-01
    z[5,4,0]  R2104     1.9032852351665497e-01
    z[5,4,0]  R2105     1.0687439143657684e-01
    z[5,4,0]  R2106     1.2337212264537811e-01
    z[5,4,0]  R2107     -1.5379829704761505e-01
    z[5,4,0]  R2108     0.612011730670929
    z[5,4,0]  R2109     -2.5405046343803406e-01
    z[5,4,0]  R2110     -1.7137020826339722e-01
    z[5,4,0]  R2111     5.9136056900024414e-01
    z[5,4,0]  R2112     -3.8787201046943665e-01
    z[5,4,0]  R2113     -1.7020131647586823e-01
    z[5,4,0]  R2114     -1.3619169592857361e-01
    z[5,4,0]  R2115     4.5985409617424011e-01
    z[5,4,0]  R2116     1.5315456688404083e-01
    z[5,4,0]  R2117     3.9971357583999634e-01
    z[5,4,0]  R2118     3.3082881569862366e-01
    z[5,4,0]  R2119     -1.5886427462100983e-01
    z[5,4,0]  R2120     2.4377131462097168e-01
    z[5,4,0]  R2121     -9.3194320797920227e-02
    z[5,4,0]  R2122     -1.2749305367469788e-01
    z[5,4,0]  R2123     -3.3869582414627075e-01
    z[5,4,0]  R2124     -3.0979645252227783e-01
    z[5,4,0]  R2125     4.6450782567262650e-02
    z[5,4,0]  R2126     -5.0778716802597046e-01
    z[5,4,0]  R2127     -4.2351409792900085e-01
    z[5,4,0]  R2128     -2.8360605239868164e-01
    z[5,4,0]  R2129     5.3043287992477417e-01
    z[5,4,0]  R2130     5.4679775238037109e-01
    z[5,4,0]  R2131     4.1538336873054504e-01
    z[5,4,0]  R2132     -3.4991261363029480e-01
    z[5,4,0]  R2133     -6.5750330686569214e-02
    z[5,4,0]  R2134     6.4677906036376953e-01
    z[5,4,0]  R2135     2.2338490188121796e-01
    z[5,4,0]  R2136     2.0899084210395813e-01
    z[5,4,0]  R2137     5.5733382701873779e-01
    z[5,4,0]  R2138     8.4454685449600220e-01
    z[5,4,0]  R2139     3.7446701526641846e-01
    z[5,4,0]  R2140     7.4645286798477173e-01
    z[5,4,0]  R2141     4.8767754435539246e-01
    z[5,4,0]  R2142     3.3604595810174942e-02
    z[5,4,0]  R2143     5.7812124490737915e-01
    z[5,4,0]  R2144     8.7086832523345947e-01
    z[5,4,0]  R2145     -2.4377760291099548e-01
    z[5,4,0]  R2146     5.2036845684051514e-01
    z[5,4,0]  R2147     6.8450921773910522e-01
    z[5,4,0]  R2148     -1.7482032999396324e-03
    z[5,4,0]  R2149     4.1061496734619141e-01
    z[5,4,0]  R2150     -8.1347328424453735e-01
    z[5,4,0]  R2151     -7.9426652193069458e-01
    z[5,4,0]  R2152     -1.0821318626403809e-01
    z[5,4,0]  R2153     -6.9208703935146332e-02
    z[5,4,0]  R2154     -3.2698172330856323e-01
    z[5,4,0]  R2155     -0.609432578086853
    z[5,4,0]  R2156     -6.8806296586990356e-01
    z[5,4,0]  R2157     -8.0902999639511108e-01
    z[5,4,0]  R2158     -4.1726133227348328e-01
    z[5,4,0]  R2159     -3.1601142883300781e-01
    z[5,4,0]  R2160     -0.582899808883667
    z[5,4,1]  R39       1
    z[5,4,1]  R48       -1
    z[5,4,1]  R2060     -1
    z[5,4,1]  R2061     1
    z[5,4,1]  R2072     0.737488329410553
    z[5,4,1]  R2073     7.8674137592315674e-01
    z[5,4,1]  R2074     4.9484989047050476e-01
    z[5,4,1]  R2075     6.3993936777114868e-01
    z[5,4,1]  R2076     5.3592085838317871e-01
    z[5,4,1]  R2077     6.3357603549957275e-01
    z[5,4,1]  R2078     6.0925018787384033e-01
    z[5,4,1]  R2079     5.5019748210906982e-01
    z[5,4,1]  R2080     5.4293698072433472e-01
    z[5,4,1]  R2081     6.1711353063583374e-01
    z[5,4,1]  R2082     -0.664252758026123
    z[5,4,1]  R2083     -7.3075622320175171e-01
    z[5,4,1]  R2084     -9.7127676010131836e-01
    z[5,4,1]  R2085     -9.6090388298034668e-01
    z[5,4,1]  R2086     -9.1653537750244141e-01
    z[5,4,1]  R2087     -9.2195582389831543e-01
    z[5,4,1]  R2088     -8.9673334360122681e-01
    z[5,4,1]  R2089     -9.1193628311157227e-01
    z[5,4,1]  R2090     -8.3954977989196777e-01
    z[5,4,1]  R2091     -0.900809109210968
    z[5,4,1]  R2092     5.2828085422515869e-01
    z[5,4,1]  R2093     2.4775977432727814e-01
    z[5,4,1]  R2094     4.3066747486591339e-02
    z[5,4,1]  R2095     -6.1472386121749878e-01
    z[5,4,1]  R2096     -8.9177715778350830e-01
    z[5,4,1]  R2097     -6.4031100273132324e-01
    z[5,4,1]  R2098     -7.4875533580780029e-01
    z[5,4,1]  R2099     -4.7622591257095337e-01
    z[5,4,1]  R2100     -7.6080149412155151e-01
    z[5,4,1]  R2101     -3.2570815086364746e-01
    z[5,4,1]  R2102     -2.2434207797050476e-01
    z[5,4,1]  R2103     -4.1379917412996292e-02
    z[5,4,1]  R2104     -4.6656742691993713e-02
    z[5,4,1]  R2105     -1.2432451546192169e-01
    z[5,4,1]  R2106     -7.1573257446289062e-02
    z[5,4,1]  R2107     5.6521035730838776e-02
    z[5,4,1]  R2108     -3.6553180217742920e-01
    z[5,4,1]  R2109     -8.5622303187847137e-02
    z[5,4,1]  R2110     0.0456363670527935
    z[5,4,1]  R2111     -2.4456253647804260e-01
    z[5,4,1]  R2112     8.4129935503005981e-01
    z[5,4,1]  R2113     8.6757284402847290e-01
    z[5,4,1]  R2114     8.4425538778305054e-01
    z[5,4,1]  R2115     -4.5689931511878967e-01
    z[5,4,1]  R2116     -7.9187095165252686e-01
    z[5,4,1]  R2117     2.4552106857299805e-01
    z[5,4,1]  R2118     -9.0515814721584320e-02
    z[5,4,1]  R2119     -3.9412230253219604e-01
    z[5,4,1]  R2120     -6.0985791683197021e-01
    z[5,4,1]  R2121     -6.7751926183700562e-01
    z[5,4,1]  R2122     -6.6503608226776123e-01
    z[5,4,1]  R2123     -7.6249647140502930e-01
    z[5,4,1]  R2124     -6.5101730823516846e-01
    z[5,4,1]  R2125     -7.9949998855590820e-01
    z[5,4,1]  R2126     -5.5410587787628174e-01
    z[5,4,1]  R2127     -0.576320469379425
    z[5,4,1]  R2128     -7.7463120222091675e-01
    z[5,4,1]  R2129     2.1554206311702728e-01
    z[5,4,1]  R2130     -0.500268816947937
    z[5,4,1]  R2131     -6.4946311712265015e-01
    z[5,4,1]  R2132     -3.6966410279273987e-01
    z[5,4,1]  R2133     -5.5434852838516235e-01
    z[5,4,1]  R2134     -5.8023804426193237e-01
    z[5,4,1]  R2135     1.1254636943340302e-01
    z[5,4,1]  R2136     1.1817237734794617e-01
    z[5,4,1]  R2137     -2.1881256997585297e-01
    z[5,4,1]  R2138     -8.0024182796478271e-02
    z[5,4,1]  R2139     -2.2036722302436829e-01
    z[5,4,1]  R2140     3.2096442580223083e-01
    z[5,4,1]  R2141     -7.2960913181304932e-01
    z[5,4,1]  R2142     -7.2324448823928833e-01
    z[5,4,1]  R2143     -5.4733687639236450e-01
    z[5,4,1]  R2144     -2.4741439521312714e-01
    z[5,4,1]  R2145     -4.4586917757987976e-01
    z[5,4,1]  R2146     -5.3672641515731812e-01
    z[5,4,1]  R2147     -2.4713842570781708e-01
    z[5,4,1]  R2148     -8.9190351963043213e-01
    z[5,4,1]  R2149     3.3194816112518311e-01
    z[5,4,1]  R2150     3.5491049289703369e-01
    z[5,4,1]  R2151     0.244643896818161
    z[5,4,1]  R2152     -3.2988885045051575e-01
    z[5,4,1]  R2153     -6.9191831350326538e-01
    z[5,4,1]  R2154     -8.0293434858322144e-01
    z[5,4,1]  R2155     -5.7155334949493408e-01
    z[5,4,1]  R2156     -4.9672827124595642e-01
    z[5,4,1]  R2157     -2.3610962927341461e-01
    z[5,4,1]  R2158     1.0668906569480896e-01
    z[5,4,1]  R2159     1.1416645348072052e-01
    z[5,4,1]  R2160     2.0661045610904694e-01
    z[5,4,2]  R40       1
    z[5,4,2]  R49       -1
    z[5,4,2]  R2062     -1
    z[5,4,2]  R2063     1
    z[5,4,2]  R2072     2.4410922825336456e-01
    z[5,4,2]  R2073     1.5601533651351929e-01
    z[5,4,2]  R2074     2.0370896160602570e-01
    z[5,4,2]  R2075     -2.0028610527515411e-01
    z[5,4,2]  R2076     -0.275034099817276
    z[5,4,2]  R2077     -3.3176821470260620e-01
    z[5,4,2]  R2078     -7.0576362311840057e-02
    z[5,4,2]  R2079     -5.0805234909057617e-01
    z[5,4,2]  R2080     -2.9526489973068237e-01
    z[5,4,2]  R2081     -3.7029787898063660e-01
    z[5,4,2]  R2082     -7.2793923318386078e-02
    z[5,4,2]  R2083     -3.4349292516708374e-01
    z[5,4,2]  R2084     -7.7627012506127357e-03
    z[5,4,2]  R2085     1.4133757352828979e-01
    z[5,4,2]  R2086     -2.7460965514183044e-01
    z[5,4,2]  R2087     -4.9809359014034271e-02
    z[5,4,2]  R2088     2.4540388584136963e-01
    z[5,4,2]  R2089     -3.3133223652839661e-01
    z[5,4,2]  R2090     2.9985567927360535e-01
    z[5,4,2]  R2091     -1.1389529705047607e-01
    z[5,4,2]  R2092     -8.6399927735328674e-02
    z[5,4,2]  R2093     6.4769244194030762e-01
    z[5,4,2]  R2094     7.2858351469039917e-01
    z[5,4,2]  R2095     2.9134291410446167e-01
    z[5,4,2]  R2096     -2.1549564599990845e-01
    z[5,4,2]  R2097     2.0287392660975456e-02
    z[5,4,2]  R2098     3.4914724528789520e-02
    z[5,4,2]  R2099     1.6762803494930267e-01
    z[5,4,2]  R2100     3.2696092128753662e-01
    z[5,4,2]  R2101     -0.512986421585083
    z[5,4,2]  R2102     -5.9244537353515625e-01
    z[5,4,2]  R2103     -8.2150202989578247e-01
    z[5,4,2]  R2104     -5.4357331991195679e-01
    z[5,4,2]  R2105     -3.1353580951690674e-01
    z[5,4,2]  R2106     -7.3006719350814819e-01
    z[5,4,2]  R2107     -7.2983759641647339e-01
    z[5,4,2]  R2108     -2.6255834102630615e-01
    z[5,4,2]  R2109     -2.2652576863765717e-01
    z[5,4,2]  R2110     -6.6095048189163208e-01
    z[5,4,2]  R2111     -6.0441619157791138e-01
    z[5,4,2]  R2112     1.1838949285447598e-02
    z[5,4,2]  R2113     -8.1899136304855347e-02
    z[5,4,2]  R2114     -4.5951315760612488e-01
    z[5,4,2]  R2115     6.1652439832687378e-01
    z[5,4,2]  R2116     2.8402274474501610e-02
    z[5,4,2]  R2117     2.7462553977966309e-01
    z[5,4,2]  R2118     4.0592372417449951e-01
    z[5,4,2]  R2119     2.7861317619681358e-02
    z[5,4,2]  R2120     2.7157512307167053e-01
    z[5,4,2]  R2121     1.4036209881305695e-01
    z[5,4,2]  R2122     -1.9590763747692108e-01
    z[5,4,2]  R2123     -2.3073473572731018e-01
    z[5,4,2]  R2124     -3.0537730455398560e-01
    z[5,4,2]  R2125     2.0183049142360687e-01
    z[5,4,2]  R2126     -2.9556852579116821e-01
    z[5,4,2]  R2127     -4.0751591324806213e-01
    z[5,4,2]  R2128     -1.1781888455152512e-01
    z[5,4,2]  R2129     -6.2708705663681030e-02
    z[5,4,2]  R2130     -7.0346496999263763e-02
    z[5,4,2]  R2131     3.0369493365287781e-01
    z[5,4,2]  R2132     -2.3955148458480835e-01
    z[5,4,2]  R2133     -5.7545232772827148e-01
    z[5,4,2]  R2134     9.1637238860130310e-02
    z[5,4,2]  R2135     -5.8281220495700836e-02
    z[5,4,2]  R2136     -2.0295043289661407e-01
    z[5,4,2]  R2137     -1.2939724326133728e-01
    z[5,4,2]  R2138     5.9550367295742035e-02
    z[5,4,2]  R2139     -2.1915417909622192e-01
    z[5,4,2]  R2140     -5.4754824377596378e-03
    z[5,4,2]  R2141     2.2998669743537903e-01
    z[5,4,2]  R2142     -3.3640664815902710e-01
    z[5,4,2]  R2143     -2.1699997782707214e-01
    z[5,4,2]  R2144     1.5533640980720520e-01
    z[5,4,2]  R2145     -6.7132425308227539e-01
    z[5,4,2]  R2146     -0.544070839881897
    z[5,4,2]  R2147     1.1546090245246887e-01
    z[5,4,2]  R2148     2.4799892306327820e-01
    z[5,4,2]  R2149     -2.8383618593215942e-01
    z[5,4,2]  R2150     7.4420824646949768e-02
    z[5,4,2]  R2151     4.0437978506088257e-01
    z[5,4,2]  R2152     5.6865561753511429e-02
    z[5,4,2]  R2153     -4.4046363234519958e-01
    z[5,4,2]  R2154     2.0109033584594727e-01
    z[5,4,2]  R2155     -1.4814113080501556e-01
    z[5,4,2]  R2156     -2.4655283987522125e-01
    z[5,4,2]  R2157     -4.0472263097763062e-01
    z[5,4,2]  R2158     7.9461358487606049e-02
    z[5,4,2]  R2159     3.3187928795814514e-01
    z[5,4,2]  R2160     3.6535346508026123e-01
    z[5,4,3]  R41       1
    z[5,4,3]  R50       -1
    z[5,4,3]  R2064     -1
    z[5,4,3]  R2065     1
    z[5,4,3]  R2072     5.5193895101547241e-01
    z[5,4,3]  R2073     -4.0297082066535950e-01
    z[5,4,3]  R2074     -6.5933072566986084e-01
    z[5,4,3]  R2075     -1.6667121648788452e-01
    z[5,4,3]  R2076     -4.6102777123451233e-01
    z[5,4,3]  R2077     -4.1386270523071289e-01
    z[5,4,3]  R2078     2.9408720135688782e-01
    z[5,4,3]  R2079     3.2679751515388489e-01
    z[5,4,3]  R2080     -1.5496331453323364e-01
    z[5,4,3]  R2081     3.8975742459297180e-01
    z[5,4,3]  R2082     -5.6434392929077148e-01
    z[5,4,3]  R2083     -5.4792308807373047e-01
    z[5,4,3]  R2084     -2.5889266282320023e-02
    z[5,4,3]  R2085     7.3489256203174591e-02
    z[5,4,3]  R2086     -9.3063563108444214e-03
    z[5,4,3]  R2087     1.6248162090778351e-01
    z[5,4,3]  R2088     2.1792547404766083e-01
    z[5,4,3]  R2089     1.0399517416954041e-01
    z[5,4,3]  R2090     -1.1378584057092667e-01
    z[5,4,3]  R2091     1.6098581254482269e-01
    z[5,4,3]  R2092     2.6375246047973633e-01
    z[5,4,3]  R2093     -4.4963663816452026e-01
    z[5,4,3]  R2094     -2.0457515120506287e-01
    z[5,4,3]  R2095     -4.1944715380668640e-01
    z[5,4,3]  R2096     -1.7698907852172852e-01
    z[5,4,3]  R2097     -1.0731939971446991e-01
    z[5,4,3]  R2098     -2.1491670049726963e-03
    z[5,4,3]  R2099     -1.4721606671810150e-01
    z[5,4,3]  R2100     7.5632028281688690e-02
    z[5,4,3]  R2101     -1.1487320810556412e-01
    z[5,4,3]  R2102     2.3699685931205750e-01
    z[5,4,3]  R2103     1.1154517531394958e-01
    z[5,4,3]  R2104     -8.6395636200904846e-02
    z[5,4,3]  R2105     1.1555530875921249e-01
    z[5,4,3]  R2106     1.3171684741973877e-01
    z[5,4,3]  R2107     3.5918179154396057e-01
    z[5,4,3]  R2108     -5.3258669376373291e-01
    z[5,4,3]  R2109     4.1792401671409607e-01
    z[5,4,3]  R2110     -9.7393877804279327e-02
    z[5,4,3]  R2111     -2.8344443440437317e-01
    z[5,4,3]  R2112     -0.271945595741272
    z[5,4,3]  R2113     -1.5372280776500702e-01
    z[5,4,3]  R2114     -1.1726742237806320e-01
    z[5,4,3]  R2115     1.5897387266159058e-01
    z[5,4,3]  R2116     5.3039681911468506e-01
    z[5,4,3]  R2117     4.7791481018066406e-01
    z[5,4,3]  R2118     4.5172640681266785e-01
    z[5,4,3]  R2119     6.5011823177337646e-01
    z[5,4,3]  R2120     6.2212830781936646e-01
    z[5,4,3]  R2121     -1.4795914292335510e-01
    z[5,4,3]  R2122     6.3086384534835815e-01
    z[5,4,3]  R2123     -2.1271225810050964e-01
    z[5,4,3]  R2124     1.8182241916656494e-01
    z[5,4,3]  R2125     4.9371698498725891e-01
    z[5,4,3]  R2126     2.0419631898403168e-01
    z[5,4,3]  R2127     -2.2921408712863922e-01
    z[5,4,3]  R2128     -2.2812442481517792e-01
    z[5,4,3]  R2129     -0.72444748878479
    z[5,4,3]  R2130     3.3810603618621826e-01
    z[5,4,3]  R2131     1.8640232086181641e-01
    z[5,4,3]  R2132     -4.8062512278556824e-01
    z[5,4,3]  R2133     -0.483710378408432
    z[5,4,3]  R2134     5.6191053241491318e-02
    z[5,4,3]  R2135     -3.6831229925155640e-01
    z[5,4,3]  R2136     1.6339768469333649e-01
    z[5,4,3]  R2137     1.0380907356739044e-01
    z[5,4,3]  R2138     1.1003208905458450e-01
    z[5,4,3]  R2139     6.5903908014297485e-01
    z[5,4,3]  R2140     -3.2897201180458069e-01
    z[5,4,3]  R2141     -1.5643297135829926e-01
    z[5,4,3]  R2142     3.9144212007522583e-01
    z[5,4,3]  R2143     -0.00906385201960802
    z[5,4,3]  R2144     -4.2518965899944305e-02
    z[5,4,3]  R2145     -4.3219098448753357e-01
    z[5,4,3]  R2146     2.7163645625114441e-01
    z[5,4,3]  R2147     2.2988820075988770e-01
    z[5,4,3]  R2148     -6.2464926391839981e-02
    z[5,4,3]  R2149     3.9827436208724976e-01
    z[5,4,3]  R2150     3.6196565628051758e-01
    z[5,4,3]  R2151     3.5333672165870667e-01
    z[5,4,3]  R2152     -2.4791575968265533e-01
    z[5,4,3]  R2153     -1.5276212990283966e-01
    z[5,4,3]  R2154     3.0615553259849548e-01
    z[5,4,3]  R2155     2.4574624840170145e-03
    z[5,4,3]  R2156     1.8979637324810028e-01
    z[5,4,3]  R2157     -1.6697503626346588e-01
    z[5,4,3]  R2158     -0.798019289970398
    z[5,4,3]  R2159     -8.2056099176406860e-01
    z[5,4,3]  R2160     4.1949599981307983e-01
    z[5,4,4]  R42       1
    z[5,4,4]  R51       -1
    z[5,4,4]  R2066     -1
    z[5,4,4]  R2067     1
    z[5,4,4]  R2072     -2.1366906166076660e-01
    z[5,4,4]  R2073     2.9065829515457153e-01
    z[5,4,4]  R2074     1.4960610866546631e-01
    z[5,4,4]  R2075     7.0273235440254211e-02
    z[5,4,4]  R2076     1.9583707675337791e-02
    z[5,4,4]  R2077     3.1935390830039978e-01
    z[5,4,4]  R2078     2.5885611772537231e-01
    z[5,4,4]  R2079     3.1587433815002441e-01
    z[5,4,4]  R2080     4.3797993659973145e-01
    z[5,4,4]  R2081     -2.6162989437580109e-02
    z[5,4,4]  R2082     -0.0783790573477745
    z[5,4,4]  R2083     9.8554842174053192e-02
    z[5,4,4]  R2084     8.3417415618896484e-02
    z[5,4,4]  R2085     -1.2464637309312820e-01
    z[5,4,4]  R2086     1.1390948295593262e-01
    z[5,4,4]  R2087     -2.8092622756958008e-02
    z[5,4,4]  R2088     3.9715595543384552e-02
    z[5,4,4]  R2089     8.3001688122749329e-02
    z[5,4,4]  R2090     1.3679456710815430e-01
    z[5,4,4]  R2091     -2.5100448727607727e-01
    z[5,4,4]  R2092     1.2115333974361420e-01
    z[5,4,4]  R2093     -1.7842277884483337e-01
    z[5,4,4]  R2094     -3.1928396224975586e-01
    z[5,4,4]  R2095     -4.0278270840644836e-01
    z[5,4,4]  R2096     -7.5008712708950043e-02
    z[5,4,4]  R2097     -1.9184872508049011e-01
    z[5,4,4]  R2098     -3.7234139442443848e-01
    z[5,4,4]  R2099     -4.0335541963577271e-01
    z[5,4,4]  R2100     -9.4079233705997467e-02
    z[5,4,4]  R2101     -4.3830177187919617e-01
    z[5,4,4]  R2102     -5.9807217121124268e-01
    z[5,4,4]  R2103     -4.9848622083663940e-01
    z[5,4,4]  R2104     -6.5336924791336060e-01
    z[5,4,4]  R2105     -7.2163826227188110e-01
    z[5,4,4]  R2106     -3.5952815413475037e-01
    z[5,4,4]  R2107     -4.0824940800666809e-01
    z[5,4,4]  R2108     3.1452366709709167e-01
    z[5,4,4]  R2109     -0.684838056564331
    z[5,4,4]  R2110     -4.1711923480033875e-01
    z[5,4,4]  R2111     1.0789326392114162e-02
    z[5,4,4]  R2112     -1.2407668679952621e-01
    z[5,4,4]  R2113     -1.8454334139823914e-01
    z[5,4,4]  R2114     1.1577981710433960e-01
    z[5,4,4]  R2115     -3.2115232944488525e-01
    z[5,4,4]  R2116     -4.9837838858366013e-02
    z[5,4,4]  R2117     -3.9657387137413025e-01
    z[5,4,4]  R2118     -0.182534858584404
    z[5,4,4]  R2119     3.5078135132789612e-01
    z[5,4,4]  R2120     5.4858420044183731e-02
    z[5,4,4]  R2121     1.3900396227836609e-01
    z[5,4,4]  R2122     2.7258116006851196e-01
    z[5,4,4]  R2123     4.3921627104282379e-02
    z[5,4,4]  R2124     5.8377593755722046e-01
    z[5,4,4]  R2125     8.3564937114715576e-02
    z[5,4,4]  R2126     1.8081174790859222e-01
    z[5,4,4]  R2127     4.6877473592758179e-01
    z[5,4,4]  R2128     1.3864706456661224e-01
    z[5,4,4]  R2129     -2.5935885310173035e-01
    z[5,4,4]  R2130     -4.4898489117622375e-01
    z[5,4,4]  R2131     -2.8888520598411560e-01
    z[5,4,4]  R2132     -5.4572808742523193e-01
    z[5,4,4]  R2133     1.7076827585697174e-02
    z[5,4,4]  R2134     -0.0605459026992321
    z[5,4,4]  R2135     -8.3162176609039307e-01
    z[5,4,4]  R2136     -2.4538438022136688e-01
    z[5,4,4]  R2137     -6.3393193483352661e-01
    z[5,4,4]  R2138     -4.3460991978645325e-01
    z[5,4,4]  R2139     -4.3667531013488770e-01
    z[5,4,4]  R2140     -3.4096285700798035e-01
    z[5,4,4]  R2141     -3.3043101429939270e-01
    z[5,4,4]  R2142     -6.0014687478542328e-02
    z[5,4,4]  R2143     -4.6652728319168091e-01
    z[5,4,4]  R2144     -3.2168093323707581e-01
    z[5,4,4]  R2145     -1.8092378973960876e-01
    z[5,4,4]  R2146     1.0825133323669434e-01
    z[5,4,4]  R2147     1.2555750086903572e-02
    z[5,4,4]  R2148     3.4217610955238342e-01
    z[5,4,4]  R2149     -5.0948488712310791e-01
    z[5,4,4]  R2150     1.9620832800865173e-01
    z[5,4,4]  R2151     1.0042093694210052e-01
    z[5,4,4]  R2152     -8.4013324975967407e-01
    z[5,4,4]  R2153     4.8353976011276245e-01
    z[5,4,4]  R2154     -2.5056087970733643e-01
    z[5,4,4]  R2155     -3.0108615756034851e-01
    z[5,4,4]  R2156     -3.7153720855712891e-02
    z[5,4,4]  R2157     -2.7126485109329224e-01
    z[5,4,4]  R2158     3.7175214290618896e-01
    z[5,4,4]  R2159     2.4538248777389526e-01
    z[5,4,4]  R2160     -6.3851051032543182e-02
    z[5,4,5]  R43       1
    z[5,4,5]  R52       -1
    z[5,4,5]  R2068     -1
    z[5,4,5]  R2069     1
    z[5,4,5]  R2072     -3.3173050731420517e-02
    z[5,4,5]  R2073     -7.7897910960018635e-03
    z[5,4,5]  R2074     -8.7487258017063141e-02
    z[5,4,5]  R2075     -1.5370495617389679e-02
    z[5,4,5]  R2076     -5.7310339063405991e-02
    z[5,4,5]  R2077     3.4435328841209412e-01
    z[5,4,5]  R2078     2.1307244896888733e-01
    z[5,4,5]  R2079     6.8327270448207855e-02
    z[5,4,5]  R2080     1.6446320712566376e-01
    z[5,4,5]  R2081     1.2961356341838837e-01
    z[5,4,5]  R2082     -2.1874779462814331e-01
    z[5,4,5]  R2083     -6.9876156747341156e-02
    z[5,4,5]  R2084     5.9693735092878342e-02
    z[5,4,5]  R2085     4.1034642606973648e-02
    z[5,4,5]  R2086     2.2982439398765564e-01
    z[5,4,5]  R2087     2.9859346151351929e-01
    z[5,4,5]  R2088     5.8090966194868088e-02
    z[5,4,5]  R2089     -5.0983525812625885e-02
    z[5,4,5]  R2090     1.3351324200630188e-01
    z[5,4,5]  R2091     -2.8407073020935059e-01
    z[5,4,5]  R2092     -5.4629868268966675e-01
    z[5,4,5]  R2093     2.7882248163223267e-01
    z[5,4,5]  R2094     -4.6346664428710938e-01
    z[5,4,5]  R2095     -3.3060312271118164e-01
    z[5,4,5]  R2096     5.1499918103218079e-02
    z[5,4,5]  R2097     -5.3591352701187134e-01
    z[5,4,5]  R2098     6.3986793160438538e-02
    z[5,4,5]  R2099     -7.3307341337203979e-01
    z[5,4,5]  R2100     -1.4958636462688446e-01
    z[5,4,5]  R2101     -3.4186232089996338e-01
    z[5,4,5]  R2102     2.7588501572608948e-01
    z[5,4,5]  R2103     0.0768398642539978
    z[5,4,5]  R2104     4.8011988401412964e-01
    z[5,4,5]  R2105     4.0588292479515076e-01
    z[5,4,5]  R2106     5.3919738531112671e-01
    z[5,4,5]  R2107     3.0846032500267029e-01
    z[5,4,5]  R2108     -1.7066171392798424e-02
    z[5,4,5]  R2109     4.3200677633285522e-01
    z[5,4,5]  R2110     7.2658412158489227e-02
    z[5,4,5]  R2111     3.8039374351501465e-01
    z[5,4,5]  R2112     1.8794685602188110e-01
    z[5,4,5]  R2113     3.1153056025505066e-01
    z[5,4,5]  R2114     3.4912928938865662e-02
    z[5,4,5]  R2115     1.9149954617023468e-01
    z[5,4,5]  R2116     -4.0843873284757137e-03
    z[5,4,5]  R2117     2.9163593053817749e-01
    z[5,4,5]  R2118     5.9292250871658325e-01
    z[5,4,5]  R2119     3.4390920400619507e-01
    z[5,4,5]  R2120     2.2979740798473358e-01
    z[5,4,5]  R2121     2.3302505910396576e-01
    z[5,4,5]  R2122     8.0706931650638580e-02
    z[5,4,5]  R2123     -5.3153578191995621e-02
    z[5,4,5]  R2124     -1.1309825628995895e-01
    z[5,4,5]  R2125     -2.2733679413795471e-01
    z[5,4,5]  R2126     5.2110069990158081e-01
    z[5,4,5]  R2127     2.2259102761745453e-01
    z[5,4,5]  R2128     4.0817445516586304e-01
    z[5,4,5]  R2129     1.9557489454746246e-01
    z[5,4,5]  R2130     -2.4819038808345795e-01
    z[5,4,5]  R2131     1.9170695543289185e-01
    z[5,4,5]  R2132     3.0538302659988403e-01
    z[5,4,5]  R2133     5.1258746534585953e-02
    z[5,4,5]  R2134     4.7907531261444092e-01
    z[5,4,5]  R2135     -0.314779132604599
    z[5,4,5]  R2136     9.0232640504837036e-01
    z[5,4,5]  R2137     1.3097949326038361e-01
    z[5,4,5]  R2138     -5.8001402765512466e-02
    z[5,4,5]  R2139     3.7141764163970947e-01
    z[5,4,5]  R2140     1.2606818974018097e-01
    z[5,4,5]  R2141     -1.2264557927846909e-01
    z[5,4,5]  R2142     1.4420942962169647e-01
    z[5,4,5]  R2143     -2.9039919376373291e-01
    z[5,4,5]  R2144     1.4926192164421082e-01
    z[5,4,5]  R2145     -0.0517929382622242
    z[5,4,5]  R2146     -0.0381213054060936
    z[5,4,5]  R2147     1.5846368670463562e-01
    z[5,4,5]  R2148     1.2515859305858612e-01
    z[5,4,5]  R2149     3.9180997014045715e-01
    z[5,4,5]  R2150     -1.6171494126319885e-01
    z[5,4,5]  R2151     -8.8415652513504028e-02
    z[5,4,5]  R2152     -3.2338467240333557e-01
    z[5,4,5]  R2153     1.0416987538337708e-01
    z[5,4,5]  R2154     -1.7621999979019165e-01
    z[5,4,5]  R2155     -3.2661595940589905e-01
    z[5,4,5]  R2156     -4.2096513509750366e-01
    z[5,4,5]  R2157     -4.1891392320394516e-02
    z[5,4,5]  R2158     -1.3399402797222137e-01
    z[5,4,5]  R2159     -1.3040751218795776e-01
    z[5,4,5]  R2160     -0.0849934071302414
    z[5,4,6]  R44       1
    z[5,4,6]  R53       -1
    z[5,4,6]  R2070     -1
    z[5,4,6]  R2071     1
    z[5,4,6]  R2072     1.1413425207138062e-01
    z[5,4,6]  R2073     -1.2458848953247070e-01
    z[5,4,6]  R2074     2.2236593067646027e-01
    z[5,4,6]  R2075     0.60142582654953
    z[5,4,6]  R2076     5.8732640743255615e-01
    z[5,4,6]  R2077     2.8813013434410095e-01
    z[5,4,6]  R2078     -0.574918806552887
    z[5,4,6]  R2079     2.4737544357776642e-01
    z[5,4,6]  R2080     -6.0062789916992188e-01
    z[5,4,6]  R2081     -1.7231461405754089e-01
    z[5,4,6]  R2082     -3.6848086118698120e-01
    z[5,4,6]  R2083     5.8339715003967285e-02
    z[5,4,6]  R2084     -3.4821897745132446e-02
    z[5,4,6]  R2085     1.5780979394912720e-01
    z[5,4,6]  R2086     1.1400125920772552e-01
    z[5,4,6]  R2087     4.7225605696439743e-02
    z[5,4,6]  R2088     -0.019609235227108
    z[5,4,6]  R2089     -2.2348802536725998e-02
    z[5,4,6]  R2090     3.7599030882120132e-02
    z[5,4,6]  R2091     -4.2935546487569809e-02
    z[5,4,6]  R2092     -4.8259723186492920e-01
    z[5,4,6]  R2093     -4.8410382121801376e-02
    z[5,4,6]  R2094     -3.2682019472122192e-01
    z[5,4,6]  R2095     2.9712799191474915e-01
    z[5,4,6]  R2096     -1.6904434561729431e-01
    z[5,4,6]  R2097     1.9047904014587402e-01
    z[5,4,6]  R2098     5.9592097997665405e-02
    z[5,4,6]  R2099     -1.3247039914131165e-01
    z[5,4,6]  R2100     -5.1069319248199463e-01
    z[5,4,6]  R2101     9.4242349267005920e-02
    z[5,4,6]  R2102     -3.2459592819213867e-01
    z[5,4,6]  R2103     4.8325583338737488e-02
    z[5,4,6]  R2104     -3.5433974117040634e-02
    z[5,4,6]  R2105     4.1947695612907410e-01
    z[5,4,6]  R2106     9.6513405442237854e-02
    z[5,4,6]  R2107     2.2284905612468719e-01
    z[5,4,6]  R2108     -2.0006555318832397e-01
    z[5,4,6]  R2109     2.1568414568901062e-01
    z[5,4,6]  R2110     5.8561146259307861e-01
    z[5,4,6]  R2111     2.5013424456119537e-03
    z[5,4,6]  R2112     1.3021971285343170e-01
    z[5,4,6]  R2113     -2.3854376375675201e-01
    z[5,4,6]  R2114     -1.7075374722480774e-01
    z[5,4,6]  R2115     1.8598724901676178e-01
    z[5,4,6]  R2116     2.5466856360435486e-01
    z[5,4,6]  R2117     -4.8353332281112671e-01
    z[5,4,6]  R2118     -3.5868138074874878e-01
    z[5,4,6]  R2119     -3.9329206943511963e-01
    z[5,4,6]  R2120     -2.2811383008956909e-01
    z[5,4,6]  R2121     6.4580667018890381e-01
    z[5,4,6]  R2122     -1.5585084259510040e-01
    z[5,4,6]  R2123     -4.4793391227722168e-01
    z[5,4,6]  R2124     -1.7386395484209061e-02
    z[5,4,6]  R2125     -1.2443863600492477e-01
    z[5,4,6]  R2126     4.2697262018918991e-02
    z[5,4,6]  R2127     -2.4199962615966797e-02
    z[5,4,6]  R2128     2.6031273603439331e-01
    z[5,4,6]  R2129     1.9470381736755371e-01
    z[5,4,6]  R2130     2.6132947206497192e-01
    z[5,4,6]  R2131     -0.398084819316864
    z[5,4,6]  R2132     2.4788361787796021e-01
    z[5,4,6]  R2133     3.4689265489578247e-01
    z[5,4,6]  R2134     -1.6337784007191658e-02
    z[5,4,6]  R2135     -8.7756089866161346e-02
    z[5,4,6]  R2136     -7.9994276165962219e-03
    z[5,4,6]  R2137     4.4153681397438049e-01
    z[5,4,6]  R2138     -2.6913493871688843e-01
    z[5,4,6]  R2139     -1.4677749946713448e-02
    z[5,4,6]  R2140     -3.1525948643684387e-01
    z[5,4,6]  R2141     1.6807551681995392e-01
    z[5,4,6]  R2142     4.3010881543159485e-01
    z[5,4,6]  R2143     -1.3056711852550507e-01
    z[5,4,6]  R2144     -1.6935016214847565e-01
    z[5,4,6]  R2145     2.6247268915176392e-01
    z[5,4,6]  R2146     -2.4118547141551971e-01
    z[5,4,6]  R2147     -6.1556601524353027e-01
    z[5,4,6]  R2148     7.9690247774124146e-02
    z[5,4,6]  R2149     -2.6254606246948242e-01
    z[5,4,6]  R2150     -1.0532230883836746e-01
    z[5,4,6]  R2151     5.4940257221460342e-02
    z[5,4,6]  R2152     6.6073901951313019e-02
    z[5,4,6]  R2153     2.3335088789463043e-01
    z[5,4,6]  R2154     1.4274649322032928e-01
    z[5,4,6]  R2155     2.8746458888053894e-01
    z[5,4,6]  R2156     -6.6539153456687927e-02
    z[5,4,6]  R2157     1.5067237615585327e-01
    z[5,4,6]  R2158     -1.2331873923540115e-01
    z[5,4,6]  R2159     -1.6254171729087830e-01
    z[5,4,6]  R2160     -5.4477435350418091e-01
    z[5,6,0]  R47       -1
    z[5,6,0]  R56       1
    z[5,6,0]  R2234     -1
    z[5,6,0]  R2235     1
    z[5,6,0]  R2248     -1.7917427420616150e-01
    z[5,6,0]  R2249     3.0699586868286133e-01
    z[5,6,0]  R2250     4.4657203555107117e-01
    z[5,6,0]  R2251     3.9458346366882324e-01
    z[5,6,0]  R2252     2.7564147114753723e-01
    z[5,6,0]  R2253     1.1680698394775391e-01
    z[5,6,0]  R2254     -0.307258665561676
    z[5,6,0]  R2255     4.0832468867301941e-01
    z[5,6,0]  R2256     -1.1998391896486282e-01
    z[5,6,0]  R2257     -5.3194290399551392e-01
    z[5,6,0]  R2258     -2.1263392269611359e-01
    z[5,6,0]  R2259     1.7259493470191956e-01
    z[5,6,0]  R2260     2.1013502776622772e-01
    z[5,6,0]  R2261     9.5719449222087860e-02
    z[5,6,0]  R2262     7.5331754982471466e-02
    z[5,6,0]  R2263     -1.7011393606662750e-01
    z[5,6,0]  R2264     2.8778192400932312e-01
    z[5,6,0]  R2265     1.9439187645912170e-01
    z[5,6,0]  R2266     0.392865389585495
    z[5,6,0]  R2267     -6.4120173454284668e-02
    z[5,6,0]  R2268     3.1283938884735107e-01
    z[5,6,0]  R2269     -4.5278713107109070e-01
    z[5,6,0]  R2270     -4.3649911880493164e-02
    z[5,6,0]  R2271     3.8477461785078049e-02
    z[5,6,0]  R2272     -3.0019250512123108e-01
    z[5,6,0]  R2273     4.6667033433914185e-01
    z[5,6,0]  R2274     -5.4023897647857666e-01
    z[5,6,0]  R2275     0.0761353075504303
    z[5,6,0]  R2276     -1.2854102253913879e-01
    z[5,6,0]  R2277     -5.4745179414749146e-01
    z[5,6,0]  R2278     2.5043988227844238e-01
    z[5,6,0]  R2279     -1.1739933490753174e-01
    z[5,6,0]  R2280     -6.8089950084686279e-01
    z[5,6,0]  R2281     9.4819717109203339e-02
    z[5,6,0]  R2282     1.9782318174839020e-01
    z[5,6,0]  R2283     -2.4343258142471313e-01
    z[5,6,0]  R2284     -1.6474086046218872e-01
    z[5,6,0]  R2285     1.1158072203397751e-01
    z[5,6,0]  R2286     0.0373874306678772
    z[5,6,0]  R2287     -8.2292415201663971e-02
    z[5,6,0]  R2288     -6.8636733293533325e-01
    z[5,6,0]  R2289     -3.6941394209861755e-01
    z[5,6,0]  R2290     4.2295315861701965e-01
    z[5,6,0]  R2291     1.9365036487579346e-01
    z[5,6,0]  R2292     -4.2744394391775131e-02
    z[5,6,0]  R2293     -4.0544059872627258e-01
    z[5,6,0]  R2294     -0.047398891299963
    z[5,6,0]  R2295     -4.4668549299240112e-01
    z[5,6,0]  R2296     -3.2467502355575562e-01
    z[5,6,0]  R2297     -4.3154659867286682e-01
    z[5,6,0]  R2298     1.2100342661142349e-01
    z[5,6,0]  R2299     2.9956543445587158e-01
    z[5,6,0]  R2300     -2.7906802296638489e-01
    z[5,6,0]  R2301     2.6324215531349182e-01
    z[5,6,0]  R2302     3.7964138388633728e-01
    z[5,6,0]  R2303     8.2014858722686768e-01
    z[5,6,0]  R2304     -5.1732414960861206e-01
    z[5,6,0]  R2305     2.2022904828190804e-02
    z[5,6,0]  R2306     -6.7554646730422974e-01
    z[5,6,0]  R2307     -3.6076098680496216e-01
    z[5,6,0]  R2308     -2.2130471467971802e-01
    z[5,6,0]  R2309     3.9594525098800659e-01
    z[5,6,0]  R2310     5.2152341604232788e-01
    z[5,6,0]  R2311     1.6126877069473267e-01
    z[5,6,0]  R2312     -5.1240515708923340e-01
    z[5,6,0]  R2313     -5.6220752000808716e-01
    z[5,6,0]  R2314     -2.2039239108562469e-01
    z[5,6,0]  R2315     -4.3702054023742676e-01
    z[5,6,0]  R2316     -1.5497425198554993e-01
    z[5,6,0]  R2317     -5.1202714443206787e-01
    z[5,6,0]  R2318     7.3430542834103107e-03
    z[5,6,0]  R2319     2.0170010626316071e-01
    z[5,6,0]  R2320     3.6225342750549316e-01
    z[5,6,0]  R2321     -5.6179058551788330e-01
    z[5,6,0]  R2322     3.4631749987602234e-01
    z[5,6,0]  R2323     -4.1941487789154053e-01
    z[5,6,0]  R2324     -4.7215002775192261e-01
    z[5,6,0]  R2325     -4.0012276172637939e-01
    z[5,6,0]  R2326     2.7824291586875916e-01
    z[5,6,0]  R2327     4.1739797592163086e-01
    z[5,6,0]  R2328     -4.4357064366340637e-01
    z[5,6,0]  R2329     -3.3242177963256836e-01
    z[5,6,0]  R2330     -4.6058263629674911e-02
    z[5,6,0]  R2331     5.9308332204818726e-01
    z[5,6,0]  R2332     8.7423712015151978e-02
    z[5,6,0]  R2333     -2.8697337955236435e-02
    z[5,6,0]  R2334     5.9080682694911957e-02
    z[5,6,0]  R2335     4.8808166384696960e-01
    z[5,6,0]  R2336     5.8220338821411133e-01
    z[5,6,1]  R48       -1
    z[5,6,1]  R57       1
    z[5,6,1]  R2236     -1
    z[5,6,1]  R2237     1
    z[5,6,1]  R2248     0.737488329410553
    z[5,6,1]  R2249     7.8674137592315674e-01
    z[5,6,1]  R2250     4.9484989047050476e-01
    z[5,6,1]  R2251     6.3993936777114868e-01
    z[5,6,1]  R2252     5.3592085838317871e-01
    z[5,6,1]  R2253     6.3357603549957275e-01
    z[5,6,1]  R2254     6.0925018787384033e-01
    z[5,6,1]  R2255     5.5019748210906982e-01
    z[5,6,1]  R2256     5.4293698072433472e-01
    z[5,6,1]  R2257     6.1711353063583374e-01
    z[5,6,1]  R2258     -0.664252758026123
    z[5,6,1]  R2259     -7.3075622320175171e-01
    z[5,6,1]  R2260     -9.7127676010131836e-01
    z[5,6,1]  R2261     -9.6090388298034668e-01
    z[5,6,1]  R2262     -9.1653537750244141e-01
    z[5,6,1]  R2263     -9.2195582389831543e-01
    z[5,6,1]  R2264     -8.9673334360122681e-01
    z[5,6,1]  R2265     -9.1193628311157227e-01
    z[5,6,1]  R2266     -8.3954977989196777e-01
    z[5,6,1]  R2267     -0.900809109210968
    z[5,6,1]  R2268     5.2828085422515869e-01
    z[5,6,1]  R2269     2.4775977432727814e-01
    z[5,6,1]  R2270     4.3066747486591339e-02
    z[5,6,1]  R2271     -6.1472386121749878e-01
    z[5,6,1]  R2272     -8.9177715778350830e-01
    z[5,6,1]  R2273     -6.4031100273132324e-01
    z[5,6,1]  R2274     -7.4875533580780029e-01
    z[5,6,1]  R2275     -4.7622591257095337e-01
    z[5,6,1]  R2276     -7.6080149412155151e-01
    z[5,6,1]  R2277     -3.2570815086364746e-01
    z[5,6,1]  R2278     -9.0008413791656494e-01
    z[5,6,1]  R2279     4.8491966724395752e-01
    z[5,6,1]  R2280     2.7578523755073547e-01
    z[5,6,1]  R2281     4.0412941575050354e-01
    z[5,6,1]  R2282     -8.4182655811309814e-01
    z[5,6,1]  R2283     3.7795212864875793e-01
    z[5,6,1]  R2284     -4.7477439045906067e-01
    z[5,6,1]  R2285     -8.2168734073638916e-01
    z[5,6,1]  R2286     3.5587257146835327e-01
    z[5,6,1]  R2287     5.9452176094055176e-01
    z[5,6,1]  R2288     5.4028725624084473e-01
    z[5,6,1]  R2289     4.3962958455085754e-01
    z[5,6,1]  R2290     1.2242415547370911e-01
    z[5,6,1]  R2291     4.0875086188316345e-01
    z[5,6,1]  R2292     4.1638728976249695e-01
    z[5,6,1]  R2293     4.0337544679641724e-01
    z[5,6,1]  R2294     4.0010768175125122e-01
    z[5,6,1]  R2295     2.9809844493865967e-01
    z[5,6,1]  R2296     3.8250654935836792e-01
    z[5,6,1]  R2297     2.4132257699966431e-01
    z[5,6,1]  R2298     3.0258321762084961e-01
    z[5,6,1]  R2299     3.1962257623672485e-01
    z[5,6,1]  R2300     5.7955151796340942e-01
    z[5,6,1]  R2301     1.7624391615390778e-01
    z[5,6,1]  R2302     2.0100392401218414e-01
    z[5,6,1]  R2303     -7.4481934309005737e-02
    z[5,6,1]  R2304     2.6645469665527344e-01
    z[5,6,1]  R2305     -5.8485662937164307e-01
    z[5,6,1]  R2306     -3.7440571188926697e-01
    z[5,6,1]  R2307     -6.1355471611022949e-01
    z[5,6,1]  R2308     -2.6705756783485413e-01
    z[5,6,1]  R2309     -7.1646170690655708e-03
    z[5,6,1]  R2310     1.0217893868684769e-01
    z[5,6,1]  R2311     4.0572628378868103e-01
    z[5,6,1]  R2312     3.9647969603538513e-01
    z[5,6,1]  R2313     3.8121148943901062e-01
    z[5,6,1]  R2314     3.7789022922515869e-01
    z[5,6,1]  R2315     -5.6038576364517212e-01
    z[5,6,1]  R2316     -5.3539234399795532e-01
    z[5,6,1]  R2317     -5.6757456064224243e-01
    z[5,6,1]  R2318     4.7778841853141785e-01
    z[5,6,1]  R2319     2.7109444141387939e-01
    z[5,6,1]  R2320     3.9177486300468445e-01
    z[5,6,1]  R2321     4.6451058983802795e-01
    z[5,6,1]  R2322     1.6319791972637177e-01
    z[5,6,1]  R2323     4.5668345689773560e-01
    z[5,6,1]  R2324     -6.4762878417968750e-01
    z[5,6,1]  R2325     -5.0727158784866333e-01
    z[5,6,1]  R2326     -5.3213357925415039e-01
    z[5,6,1]  R2327     -5.4442584514617920e-01
    z[5,6,1]  R2328     4.0950211882591248e-01
    z[5,6,1]  R2329     -6.4772331714630127e-01
    z[5,6,1]  R2330     -4.2938083410263062e-01
    z[5,6,1]  R2331     3.2703793048858643e-01
    z[5,6,1]  R2332     -4.7708502411842346e-01
    z[5,6,1]  R2333     -3.7778580188751221e-01
    z[5,6,1]  R2334     -3.9710542559623718e-01
    z[5,6,1]  R2335     3.7884214520454407e-01
    z[5,6,1]  R2336     3.1807422637939453e-01
    z[5,6,2]  R49       -1
    z[5,6,2]  R58       1
    z[5,6,2]  R2238     -1
    z[5,6,2]  R2239     1
    z[5,6,2]  R2248     2.4410922825336456e-01
    z[5,6,2]  R2249     1.5601533651351929e-01
    z[5,6,2]  R2250     2.0370896160602570e-01
    z[5,6,2]  R2251     -2.0028610527515411e-01
    z[5,6,2]  R2252     -0.275034099817276
    z[5,6,2]  R2253     -3.3176821470260620e-01
    z[5,6,2]  R2254     -7.0576362311840057e-02
    z[5,6,2]  R2255     -5.0805234909057617e-01
    z[5,6,2]  R2256     -2.9526489973068237e-01
    z[5,6,2]  R2257     -3.7029787898063660e-01
    z[5,6,2]  R2258     -7.2793923318386078e-02
    z[5,6,2]  R2259     -3.4349292516708374e-01
    z[5,6,2]  R2260     -7.7627012506127357e-03
    z[5,6,2]  R2261     1.4133757352828979e-01
    z[5,6,2]  R2262     -2.7460965514183044e-01
    z[5,6,2]  R2263     -4.9809359014034271e-02
    z[5,6,2]  R2264     2.4540388584136963e-01
    z[5,6,2]  R2265     -3.3133223652839661e-01
    z[5,6,2]  R2266     2.9985567927360535e-01
    z[5,6,2]  R2267     -1.1389529705047607e-01
    z[5,6,2]  R2268     -8.6399927735328674e-02
    z[5,6,2]  R2269     6.4769244194030762e-01
    z[5,6,2]  R2270     7.2858351469039917e-01
    z[5,6,2]  R2271     2.9134291410446167e-01
    z[5,6,2]  R2272     -2.1549564599990845e-01
    z[5,6,2]  R2273     2.0287392660975456e-02
    z[5,6,2]  R2274     3.4914724528789520e-02
    z[5,6,2]  R2275     1.6762803494930267e-01
    z[5,6,2]  R2276     3.2696092128753662e-01
    z[5,6,2]  R2277     -0.512986421585083
    z[5,6,2]  R2278     -2.2932359576225281e-01
    z[5,6,2]  R2279     -6.8683421611785889e-01
    z[5,6,2]  R2280     -5.0153082609176636e-01
    z[5,6,2]  R2281     -6.4585661888122559e-01
    z[5,6,2]  R2282     1.6330896317958832e-01
    z[5,6,2]  R2283     -5.6998163461685181e-01
    z[5,6,2]  R2284     5.9834194183349609e-01
    z[5,6,2]  R2285     -1.1998074501752853e-01
    z[5,6,2]  R2286     -0.644943118095398
    z[5,6,2]  R2287     -4.7349187731742859e-01
    z[5,6,2]  R2288     2.5623485445976257e-01
    z[5,6,2]  R2289     4.7445413470268250e-01
    z[5,6,2]  R2290     -5.6328210048377514e-03
    z[5,6,2]  R2291     1.6692188382148743e-01
    z[5,6,2]  R2292     3.6668628454208374e-01
    z[5,6,2]  R2293     7.6216422021389008e-02
    z[5,6,2]  R2294     2.4714258313179016e-01
    z[5,6,2]  R2295     2.9009503126144409e-01
    z[5,6,2]  R2296     -1.0790310055017471e-01
    z[5,6,2]  R2297     4.0713006258010864e-01
    z[5,6,2]  R2298     2.1538142859935760e-01
    z[5,6,2]  R2299     6.6276490688323975e-01
    z[5,6,2]  R2300     3.0871546268463135e-01
    z[5,6,2]  R2301     2.8660658001899719e-01
    z[5,6,2]  R2302     3.0485492944717407e-01
    z[5,6,2]  R2303     1.6351932287216187e-01
    z[5,6,2]  R2304     6.7355133593082428e-02
    z[5,6,2]  R2305     -5.0796133279800415e-01
    z[5,6,2]  R2306     2.2495531011372805e-03
    z[5,6,2]  R2307     1.5763860195875168e-02
    z[5,6,2]  R2308     1.5075573325157166e-01
    z[5,6,2]  R2309     6.8243521451950073e-01
    z[5,6,2]  R2310     6.0448747873306274e-01
    z[5,6,2]  R2311     2.1318452060222626e-01
    z[5,6,2]  R2312     1.9009378552436829e-01
    z[5,6,2]  R2313     5.0256246328353882e-01
    z[5,6,2]  R2314     4.5426163077354431e-01
    z[5,6,2]  R2315     6.6239468753337860e-02
    z[5,6,2]  R2316     9.6148863434791565e-02
    z[5,6,2]  R2317     -6.8059504032135010e-02
    z[5,6,2]  R2318     6.4776223897933960e-01
    z[5,6,2]  R2319     5.2126592397689819e-01
    z[5,6,2]  R2320     4.7185677289962769e-01
    z[5,6,2]  R2321     7.9380877315998077e-02
    z[5,6,2]  R2322     2.2927826642990112e-01
    z[5,6,2]  R2323     -1.2523406744003296e-01
    z[5,6,2]  R2324     -2.0751677453517914e-02
    z[5,6,2]  R2325     -2.7674663066864014e-01
    z[5,6,2]  R2326     2.1530188620090485e-02
    z[5,6,2]  R2327     -3.0051467474550009e-03
    z[5,6,2]  R2328     -1.7241753637790680e-01
    z[5,6,2]  R2329     -1.3766567409038544e-01
    z[5,6,2]  R2330     4.2141386866569519e-01
    z[5,6,2]  R2331     2.1265690028667450e-01
    z[5,6,2]  R2332     -3.5251066088676453e-01
    z[5,6,2]  R2333     0.394464910030365
    z[5,6,2]  R2334     3.6904075741767883e-01
    z[5,6,2]  R2335     0.0866931602358818
    z[5,6,2]  R2336     -6.8666212260723114e-02
    z[5,6,3]  R50       -1
    z[5,6,3]  R59       1
    z[5,6,3]  R2240     -1
    z[5,6,3]  R2241     1
    z[5,6,3]  R2248     5.5193895101547241e-01
    z[5,6,3]  R2249     -4.0297082066535950e-01
    z[5,6,3]  R2250     -6.5933072566986084e-01
    z[5,6,3]  R2251     -1.6667121648788452e-01
    z[5,6,3]  R2252     -4.6102777123451233e-01
    z[5,6,3]  R2253     -4.1386270523071289e-01
    z[5,6,3]  R2254     2.9408720135688782e-01
    z[5,6,3]  R2255     3.2679751515388489e-01
    z[5,6,3]  R2256     -1.5496331453323364e-01
    z[5,6,3]  R2257     3.8975742459297180e-01
    z[5,6,3]  R2258     -5.6434392929077148e-01
    z[5,6,3]  R2259     -5.4792308807373047e-01
    z[5,6,3]  R2260     -2.5889266282320023e-02
    z[5,6,3]  R2261     7.3489256203174591e-02
    z[5,6,3]  R2262     -9.3063563108444214e-03
    z[5,6,3]  R2263     1.6248162090778351e-01
    z[5,6,3]  R2264     2.1792547404766083e-01
    z[5,6,3]  R2265     1.0399517416954041e-01
    z[5,6,3]  R2266     -1.1378584057092667e-01
    z[5,6,3]  R2267     1.6098581254482269e-01
    z[5,6,3]  R2268     2.6375246047973633e-01
    z[5,6,3]  R2269     -4.4963663816452026e-01
    z[5,6,3]  R2270     -2.0457515120506287e-01
    z[5,6,3]  R2271     -4.1944715380668640e-01
    z[5,6,3]  R2272     -1.7698907852172852e-01
    z[5,6,3]  R2273     -1.0731939971446991e-01
    z[5,6,3]  R2274     -2.1491670049726963e-03
    z[5,6,3]  R2275     -1.4721606671810150e-01
    z[5,6,3]  R2276     7.5632028281688690e-02
    z[5,6,3]  R2277     -1.1487320810556412e-01
    z[5,6,3]  R2278     5.1031899638473988e-03
    z[5,6,3]  R2279     -1.4898261427879333e-01
    z[5,6,3]  R2280     -2.8086232021450996e-02
    z[5,6,3]  R2281     5.5436813831329346e-01
    z[5,6,3]  R2282     -3.6988684535026550e-01
    z[5,6,3]  R2283     -1.6029103100299835e-01
    z[5,6,3]  R2284     -2.2525161504745483e-01
    z[5,6,3]  R2285     -4.5653226971626282e-01
    z[5,6,3]  R2286     -2.2042134404182434e-01
    z[5,6,3]  R2287     5.0365632772445679e-01
    z[5,6,3]  R2288     7.7158883213996887e-02
    z[5,6,3]  R2289     -0.557939350605011
    z[5,6,3]  R2290     -3.8787013292312622e-01
    z[5,6,3]  R2291     -7.7670890092849731e-01
    z[5,6,3]  R2292     -7.0972442626953125e-01
    z[5,6,3]  R2293     -3.4640991687774658e-01
    z[5,6,3]  R2294     -7.3124104738235474e-01
    z[5,6,3]  R2295     -5.2422147989273071e-01
    z[5,6,3]  R2296     3.5884547233581543e-01
    z[5,6,3]  R2297     4.0285471081733704e-01
    z[5,6,3]  R2298     -0.759775698184967
    z[5,6,3]  R2299     -5.8142524957656860e-01
    z[5,6,3]  R2300     -4.2721742391586304e-01
    z[5,6,3]  R2301     -5.6639397144317627e-01
    z[5,6,3]  R2302     -7.0367473363876343e-01
    z[5,6,3]  R2303     -1.2777270376682281e-01
    z[5,6,3]  R2304     1.6802865266799927e-01
    z[5,6,3]  R2305     4.2923569679260254e-01
    z[5,6,3]  R2306     1.0206146538257599e-01
    z[5,6,3]  R2307     6.9345241785049438e-01
    z[5,6,3]  R2308     -8.5138714313507080e-01
    z[5,6,3]  R2309     -4.4106084108352661e-01
    z[5,6,3]  R2310     -5.5888414382934570e-01
    z[5,6,3]  R2311     -8.1872475147247314e-01
    z[5,6,3]  R2312     3.7962052226066589e-01
    z[5,6,3]  R2313     -3.3120054006576538e-01
    z[5,6,3]  R2314     -2.5419533252716064e-01
    z[5,6,3]  R2315     4.5828998088836670e-01
    z[5,6,3]  R2316     5.4101234674453735e-01
    z[5,6,3]  R2317     5.4365581274032593e-01
    z[5,6,3]  R2318     -5.8628183603286743e-01
    z[5,6,3]  R2319     -7.3722654581069946e-01
    z[5,6,3]  R2320     -6.0235756635665894e-01
    z[5,6,3]  R2321     -4.5180425047874451e-01
    z[5,6,3]  R2322     -7.7838724851608276e-01
    z[5,6,3]  R2323     1.3046717643737793e-01
    z[5,6,3]  R2324     4.4680750370025635e-01
    z[5,6,3]  R2325     0.547261655330658
    z[5,6,3]  R2326     6.1301314830780029e-01
    z[5,6,3]  R2327     0.675198495388031
    z[5,6,3]  R2328     -2.6835939288139343e-01
    z[5,6,3]  R2329     6.6462028026580811e-01
    z[5,6,3]  R2330     7.6194804906845093e-01
    z[5,6,3]  R2331     5.4782259464263916e-01
    z[5,6,3]  R2332     5.4189068078994751e-01
    z[5,6,3]  R2333     7.3853135108947754e-01
    z[5,6,3]  R2334     7.4501550197601318e-01
    z[5,6,3]  R2335     2.4280984699726105e-01
    z[5,6,3]  R2336     3.2068583369255066e-01
    z[5,6,4]  R51       -1
    z[5,6,4]  R60       1
    z[5,6,4]  R2242     -1
    z[5,6,4]  R2243     1
    z[5,6,4]  R2248     -2.1366906166076660e-01
    z[5,6,4]  R2249     2.9065829515457153e-01
    z[5,6,4]  R2250     1.4960610866546631e-01
    z[5,6,4]  R2251     7.0273235440254211e-02
    z[5,6,4]  R2252     1.9583707675337791e-02
    z[5,6,4]  R2253     3.1935390830039978e-01
    z[5,6,4]  R2254     2.5885611772537231e-01
    z[5,6,4]  R2255     3.1587433815002441e-01
    z[5,6,4]  R2256     4.3797993659973145e-01
    z[5,6,4]  R2257     -2.6162989437580109e-02
    z[5,6,4]  R2258     -0.0783790573477745
    z[5,6,4]  R2259     9.8554842174053192e-02
    z[5,6,4]  R2260     8.3417415618896484e-02
    z[5,6,4]  R2261     -1.2464637309312820e-01
    z[5,6,4]  R2262     1.1390948295593262e-01
    z[5,6,4]  R2263     -2.8092622756958008e-02
    z[5,6,4]  R2264     3.9715595543384552e-02
    z[5,6,4]  R2265     8.3001688122749329e-02
    z[5,6,4]  R2266     1.3679456710815430e-01
    z[5,6,4]  R2267     -2.5100448727607727e-01
    z[5,6,4]  R2268     1.2115333974361420e-01
    z[5,6,4]  R2269     -1.7842277884483337e-01
    z[5,6,4]  R2270     -3.1928396224975586e-01
    z[5,6,4]  R2271     -4.0278270840644836e-01
    z[5,6,4]  R2272     -7.5008712708950043e-02
    z[5,6,4]  R2273     -1.9184872508049011e-01
    z[5,6,4]  R2274     -3.7234139442443848e-01
    z[5,6,4]  R2275     -4.0335541963577271e-01
    z[5,6,4]  R2276     -9.4079233705997467e-02
    z[5,6,4]  R2277     -4.3830177187919617e-01
    z[5,6,4]  R2278     -4.8948537558317184e-02
    z[5,6,4]  R2279     4.3450409173965454e-01
    z[5,6,4]  R2280     3.9758551120758057e-01
    z[5,6,4]  R2281     2.4671699106693268e-01
    z[5,6,4]  R2282     -2.3689439892768860e-01
    z[5,6,4]  R2283     5.3628218173980713e-01
    z[5,6,4]  R2284     4.5758464932441711e-01
    z[5,6,4]  R2285     1.3389259576797485e-01
    z[5,6,4]  R2286     6.1684852838516235e-01
    z[5,6,4]  R2287     -1.2166652828454971e-01
    z[5,6,4]  R2288     -3.7135216593742371e-01
    z[5,6,4]  R2289     -0.354168564081192
    z[5,6,4]  R2290     -2.1554410457611084e-01
    z[5,6,4]  R2291     -9.7739897668361664e-02
    z[5,6,4]  R2292     -8.2521423697471619e-02
    z[5,6,4]  R2293     -4.7443509101867676e-01
    z[5,6,4]  R2294     -3.2872599363327026e-01
    z[5,6,4]  R2295     -9.5027446746826172e-02
    z[5,6,4]  R2296     -6.7304037511348724e-02
    z[5,6,4]  R2297     0.0866825059056282
    z[5,6,4]  R2298     -6.7003101110458374e-02
    z[5,6,4]  R2299     -7.8297823667526245e-02
    z[5,6,4]  R2300     4.3972003459930420e-01
    z[5,6,4]  R2301     3.1733307242393494e-01
    z[5,6,4]  R2302     4.2865127325057983e-01
    z[5,6,4]  R2303     5.1188313961029053e-01
    z[5,6,4]  R2304     0.0507943332195282
    z[5,6,4]  R2305     9.2227414250373840e-02
    z[5,6,4]  R2306     -1.1723274737596512e-01
    z[5,6,4]  R2307     7.0551261305809021e-02
    z[5,6,4]  R2308     2.8297787904739380e-01
    z[5,6,4]  R2309     -4.0528275072574615e-02
    z[5,6,4]  R2310     3.9297146722674370e-03
    z[5,6,4]  R2311     -2.5915073230862617e-02
    z[5,6,4]  R2312     1.1037456989288330e-01
    z[5,6,4]  R2313     -0.0431511253118515
    z[5,6,4]  R2314     -8.1617077812552452e-03
    z[5,6,4]  R2315     -4.2186689376831055e-01
    z[5,6,4]  R2316     -2.3261302709579468e-01
    z[5,6,4]  R2317     -1.6281627118587494e-01
    z[5,6,4]  R2318     8.3653137087821960e-02
    z[5,6,4]  R2319     4.4808998703956604e-02
    z[5,6,4]  R2320     3.5443204641342163e-01
    z[5,6,4]  R2321     -1.3447956740856171e-01
    z[5,6,4]  R2322     1.6174888610839844e-01
    z[5,6,4]  R2323     -1.6961348056793213e-01
    z[5,6,4]  R2324     -2.8872808814048767e-01
    z[5,6,4]  R2325     0.0324304923415184
    z[5,6,4]  R2326     1.1904054135084152e-01
    z[5,6,4]  R2327     1.3996081054210663e-01
    z[5,6,4]  R2328     -6.6272771358489990e-01
    z[5,6,4]  R2329     -2.5161406025290489e-02
    z[5,6,4]  R2330     -1.1635018140077591e-01
    z[5,6,4]  R2331     -1.0016535967588425e-01
    z[5,6,4]  R2332     5.2733731269836426e-01
    z[5,6,4]  R2333     -2.1668742597103119e-01
    z[5,6,4]  R2334     -2.9552593827247620e-01
    z[5,6,4]  R2335     -3.6308676004409790e-01
    z[5,6,4]  R2336     -3.3995696902275085e-01
    z[5,6,5]  R52       -1
    z[5,6,5]  R61       1
    z[5,6,5]  R2244     -1
    z[5,6,5]  R2245     1
    z[5,6,5]  R2248     -3.3173050731420517e-02
    z[5,6,5]  R2249     -7.7897910960018635e-03
    z[5,6,5]  R2250     -8.7487258017063141e-02
    z[5,6,5]  R2251     -1.5370495617389679e-02
    z[5,6,5]  R2252     -5.7310339063405991e-02
    z[5,6,5]  R2253     3.4435328841209412e-01
    z[5,6,5]  R2254     2.1307244896888733e-01
    z[5,6,5]  R2255     6.8327270448207855e-02
    z[5,6,5]  R2256     1.6446320712566376e-01
    z[5,6,5]  R2257     1.2961356341838837e-01
    z[5,6,5]  R2258     -2.1874779462814331e-01
    z[5,6,5]  R2259     -6.9876156747341156e-02
    z[5,6,5]  R2260     5.9693735092878342e-02
    z[5,6,5]  R2261     4.1034642606973648e-02
    z[5,6,5]  R2262     2.2982439398765564e-01
    z[5,6,5]  R2263     2.9859346151351929e-01
    z[5,6,5]  R2264     5.8090966194868088e-02
    z[5,6,5]  R2265     -5.0983525812625885e-02
    z[5,6,5]  R2266     1.3351324200630188e-01
    z[5,6,5]  R2267     -2.8407073020935059e-01
    z[5,6,5]  R2268     -5.4629868268966675e-01
    z[5,6,5]  R2269     2.7882248163223267e-01
    z[5,6,5]  R2270     -4.6346664428710938e-01
    z[5,6,5]  R2271     -3.3060312271118164e-01
    z[5,6,5]  R2272     5.1499918103218079e-02
    z[5,6,5]  R2273     -5.3591352701187134e-01
    z[5,6,5]  R2274     6.3986793160438538e-02
    z[5,6,5]  R2275     -7.3307341337203979e-01
    z[5,6,5]  R2276     -1.4958636462688446e-01
    z[5,6,5]  R2277     -3.4186232089996338e-01
    z[5,6,5]  R2278     -4.1539106518030167e-02
    z[5,6,5]  R2279     2.2819447517395020e-01
    z[5,6,5]  R2280     1.7619884014129639e-01
    z[5,6,5]  R2281     1.3112403452396393e-01
    z[5,6,5]  R2282     1.2630765140056610e-01
    z[5,6,5]  R2283     3.9634126424789429e-01
    z[5,6,5]  R2284     -6.1755768954753876e-02
    z[5,6,5]  R2285     -1.6362796723842621e-01
    z[5,6,5]  R2286     -0.00947926752269268
    z[5,6,5]  R2287     3.7716919183731079e-01
    z[5,6,5]  R2288     -1.2126628309488297e-01
    z[5,6,5]  R2289     -8.2264598459005356e-03
    z[5,6,5]  R2290     7.7099567651748657e-01
    z[5,6,5]  R2291     -9.8559595644474030e-02
    z[5,6,5]  R2292     -3.2236614823341370e-01
    z[5,6,5]  R2293     -3.8575440645217896e-01
    z[5,6,5]  R2294     2.7779513597488403e-01
    z[5,6,5]  R2295     -4.8051732778549194e-01
    z[5,6,5]  R2296     -7.7186834812164307e-01
    z[5,6,5]  R2297     -4.4081023335456848e-01
    z[5,6,5]  R2298     4.9419414997100830e-01
    z[5,6,5]  R2299     -9.7955256700515747e-02
    z[5,6,5]  R2300     -0.336814820766449
    z[5,6,5]  R2301     -5.7692015171051025e-01
    z[5,6,5]  R2302     1.9828870892524719e-01
    z[5,6,5]  R2303     0.127718985080719
    z[5,6,5]  R2304     -7.1706116199493408e-01
    z[5,6,5]  R2305     4.2671549320220947e-01
    z[5,6,5]  R2306     -6.1563742160797119e-01
    z[5,6,5]  R2307     -4.0803611278533936e-02
    z[5,6,5]  R2308     2.2335672378540039e-01
    z[5,6,5]  R2309     4.1427803039550781e-01
    z[5,6,5]  R2310     -1.2038338184356689e-01
    z[5,6,5]  R2311     9.2470802366733551e-02
    z[5,6,5]  R2312     3.5213101655244827e-02
    z[5,6,5]  R2313     8.0370604991912842e-02
    z[5,6,5]  R2314     0.667449414730072
    z[5,6,5]  R2315     -2.9559394717216492e-01
    z[5,6,5]  R2316     -5.7194280624389648e-01
    z[5,6,5]  R2317     -3.8481815718114376e-03
    z[5,6,5]  R2318     2.5344986468553543e-02
    z[5,6,5]  R2319     2.5290971994400024e-01
    z[5,6,5]  R2320     -2.8588702902197838e-02
    z[5,6,5]  R2321     -4.4346663355827332e-01
    z[5,6,5]  R2322     -2.3948095738887787e-01
    z[5,6,5]  R2323     -7.2092288732528687e-01
    z[5,6,5]  R2324     -2.1446606516838074e-01
    z[5,6,5]  R2325     -4.3531975150108337e-01
    z[5,6,5]  R2326     -4.8618495464324951e-01
    z[5,6,5]  R2327     -6.1701752245426178e-02
    z[5,6,5]  R2328     1.9499303773045540e-02
    z[5,6,5]  R2329     -8.5549950599670410e-02
    z[5,6,5]  R2330     1.8580843508243561e-01
    z[5,6,5]  R2331     -4.3025019764900208e-01
    z[5,6,5]  R2332     -1.3461917638778687e-01
    z[5,6,5]  R2333     -9.5116794109344482e-02
    z[5,6,5]  R2334     0.000767854624427855
    z[5,6,5]  R2335     -5.7054489850997925e-01
    z[5,6,5]  R2336     -4.8150390386581421e-01
    z[5,6,6]  R53       -1
    z[5,6,6]  R62       1
    z[5,6,6]  R2246     -1
    z[5,6,6]  R2247     1
    z[5,6,6]  R2248     1.1413425207138062e-01
    z[5,6,6]  R2249     -1.2458848953247070e-01
    z[5,6,6]  R2250     2.2236593067646027e-01
    z[5,6,6]  R2251     0.60142582654953
    z[5,6,6]  R2252     5.8732640743255615e-01
    z[5,6,6]  R2253     2.8813013434410095e-01
    z[5,6,6]  R2254     -0.574918806552887
    z[5,6,6]  R2255     2.4737544357776642e-01
    z[5,6,6]  R2256     -6.0062789916992188e-01
    z[5,6,6]  R2257     -1.7231461405754089e-01
    z[5,6,6]  R2258     -3.6848086118698120e-01
    z[5,6,6]  R2259     5.8339715003967285e-02
    z[5,6,6]  R2260     -3.4821897745132446e-02
    z[5,6,6]  R2261     1.5780979394912720e-01
    z[5,6,6]  R2262     1.1400125920772552e-01
    z[5,6,6]  R2263     4.7225605696439743e-02
    z[5,6,6]  R2264     -0.019609235227108
    z[5,6,6]  R2265     -2.2348802536725998e-02
    z[5,6,6]  R2266     3.7599030882120132e-02
    z[5,6,6]  R2267     -4.2935546487569809e-02
    z[5,6,6]  R2268     -4.8259723186492920e-01
    z[5,6,6]  R2269     -4.8410382121801376e-02
    z[5,6,6]  R2270     -3.2682019472122192e-01
    z[5,6,6]  R2271     2.9712799191474915e-01
    z[5,6,6]  R2272     -1.6904434561729431e-01
    z[5,6,6]  R2273     1.9047904014587402e-01
    z[5,6,6]  R2274     5.9592097997665405e-02
    z[5,6,6]  R2275     -1.3247039914131165e-01
    z[5,6,6]  R2276     -5.1069319248199463e-01
    z[5,6,6]  R2277     9.4242349267005920e-02
    z[5,6,6]  R2278     2.6531422138214111e-01
    z[5,6,6]  R2279     1.2754152715206146e-01
    z[5,6,6]  R2280     1.3739053905010223e-01
    z[5,6,6]  R2281     1.5865311026573181e-01
    z[5,6,6]  R2282     -1.2897776067256927e-01
    z[5,6,6]  R2283     5.1337309181690216e-02
    z[5,6,6]  R2284     3.5426083207130432e-01
    z[5,6,6]  R2285     -2.1180485188961029e-01
    z[5,6,6]  R2286     -1.6379144787788391e-01
    z[5,6,6]  R2287     6.9629065692424774e-02
    z[5,6,6]  R2288     1.1301308125257492e-01
    z[5,6,6]  R2289     -0.0913948118686676
    z[5,6,6]  R2290     -1.2146764993667603e-01
    z[5,6,6]  R2291     -3.8080912828445435e-01
    z[5,6,6]  R2292     -2.7549448609352112e-01
    z[5,6,6]  R2293     -4.1617578268051147e-01
    z[5,6,6]  R2294     -2.3799885809421539e-01
    z[5,6,6]  R2295     -3.3573645353317261e-01
    z[5,6,6]  R2296     -8.6897037923336029e-02
    z[5,6,6]  R2297     -4.7503328323364258e-01
    z[5,6,6]  R2298     -1.4641021192073822e-01
    z[5,6,6]  R2299     -1.2273354083299637e-01
    z[5,6,6]  R2300     4.0288589894771576e-02
    z[5,6,6]  R2301     -2.5131475925445557e-01
    z[5,6,6]  R2302     -6.5688163042068481e-02
    z[5,6,6]  R2303     2.0194327458739281e-02
    z[5,6,6]  R2304     -3.3444055914878845e-01
    z[5,6,6]  R2305     1.5683636069297791e-01
    z[5,6,6]  R2306     1.6815623268485069e-02
    z[5,6,6]  R2307     -7.5065419077873230e-02
    z[5,6,6]  R2308     -4.6393796801567078e-02
    z[5,6,6]  R2309     9.8258063197135925e-02
    z[5,6,6]  R2310     -1.5908671915531158e-01
    z[5,6,6]  R2311     -2.9051387310028076e-01
    z[5,6,6]  R2312     -6.2175148725509644e-01
    z[5,6,6]  R2313     -4.0989780426025391e-01
    z[5,6,6]  R2314     3.0348291993141174e-01
    z[5,6,6]  R2315     1.2335287779569626e-01
    z[5,6,6]  R2316     7.8560203313827515e-02
    z[5,6,6]  R2317     2.9827767610549927e-01
    z[5,6,6]  R2318     0.0264901053160429
    z[5,6,6]  R2319     -6.8063624203205109e-02
    z[5,6,6]  R2320     -5.7983744889497757e-02
    z[5,6,6]  R2321     -2.0843598246574402e-01
    z[5,6,6]  R2322     -3.3385860919952393e-01
    z[5,6,6]  R2323     -1.8527679145336151e-01
    z[5,6,6]  R2324     1.6800068318843842e-01
    z[5,6,6]  R2325     1.2624703347682953e-01
    z[5,6,6]  R2326     1.1233668774366379e-01
    z[5,6,6]  R2327     2.2378845512866974e-01
    z[5,6,6]  R2328     -0.306953102350235
    z[5,6,6]  R2329     3.6419898271560669e-02
    z[5,6,6]  R2330     -0.0854058712720871
    z[5,6,6]  R2331     -2.8591899201273918e-02
    z[5,6,6]  R2332     2.2501243650913239e-01
    z[5,6,6]  R2333     -3.1531330943107605e-01
    z[5,6,6]  R2334     2.4544094502925873e-01
    z[5,6,6]  R2335     -3.0729341506958008e-01
    z[5,6,6]  R2336     -3.2387769222259521e-01
    z[6,5,0]  R47       1
    z[6,5,0]  R56       -1
    z[6,5,0]  R2337     -1
    z[6,5,0]  R2338     1
    z[6,5,0]  R2351     2.5043988227844238e-01
    z[6,5,0]  R2352     -1.1739933490753174e-01
    z[6,5,0]  R2353     -6.8089950084686279e-01
    z[6,5,0]  R2354     9.4819717109203339e-02
    z[6,5,0]  R2355     1.9782318174839020e-01
    z[6,5,0]  R2356     -2.4343258142471313e-01
    z[6,5,0]  R2357     -1.6474086046218872e-01
    z[6,5,0]  R2358     1.1158072203397751e-01
    z[6,5,0]  R2359     0.0373874306678772
    z[6,5,0]  R2360     -8.2292415201663971e-02
    z[6,5,0]  R2361     -6.8636733293533325e-01
    z[6,5,0]  R2362     -3.6941394209861755e-01
    z[6,5,0]  R2363     4.2295315861701965e-01
    z[6,5,0]  R2364     1.9365036487579346e-01
    z[6,5,0]  R2365     -4.2744394391775131e-02
    z[6,5,0]  R2366     -4.0544059872627258e-01
    z[6,5,0]  R2367     -0.047398891299963
    z[6,5,0]  R2368     -4.4668549299240112e-01
    z[6,5,0]  R2369     -3.2467502355575562e-01
    z[6,5,0]  R2370     -4.3154659867286682e-01
    z[6,5,0]  R2371     1.2100342661142349e-01
    z[6,5,0]  R2372     2.9956543445587158e-01
    z[6,5,0]  R2373     -2.7906802296638489e-01
    z[6,5,0]  R2374     2.6324215531349182e-01
    z[6,5,0]  R2375     3.7964138388633728e-01
    z[6,5,0]  R2376     8.2014858722686768e-01
    z[6,5,0]  R2377     -5.1732414960861206e-01
    z[6,5,0]  R2378     2.2022904828190804e-02
    z[6,5,0]  R2379     -6.7554646730422974e-01
    z[6,5,0]  R2380     -3.6076098680496216e-01
    z[6,5,0]  R2381     -2.2130471467971802e-01
    z[6,5,0]  R2382     3.9594525098800659e-01
    z[6,5,0]  R2383     5.2152341604232788e-01
    z[6,5,0]  R2384     1.6126877069473267e-01
    z[6,5,0]  R2385     -5.1240515708923340e-01
    z[6,5,0]  R2386     -5.6220752000808716e-01
    z[6,5,0]  R2387     -2.2039239108562469e-01
    z[6,5,0]  R2388     -4.3702054023742676e-01
    z[6,5,0]  R2389     -1.5497425198554993e-01
    z[6,5,0]  R2390     -5.1202714443206787e-01
    z[6,5,0]  R2391     7.3430542834103107e-03
    z[6,5,0]  R2392     2.0170010626316071e-01
    z[6,5,0]  R2393     3.6225342750549316e-01
    z[6,5,0]  R2394     -5.6179058551788330e-01
    z[6,5,0]  R2395     3.4631749987602234e-01
    z[6,5,0]  R2396     -4.1941487789154053e-01
    z[6,5,0]  R2397     -4.7215002775192261e-01
    z[6,5,0]  R2398     -4.0012276172637939e-01
    z[6,5,0]  R2399     2.7824291586875916e-01
    z[6,5,0]  R2400     4.1739797592163086e-01
    z[6,5,0]  R2401     -4.4357064366340637e-01
    z[6,5,0]  R2402     -3.3242177963256836e-01
    z[6,5,0]  R2403     -4.6058263629674911e-02
    z[6,5,0]  R2404     5.9308332204818726e-01
    z[6,5,0]  R2405     8.7423712015151978e-02
    z[6,5,0]  R2406     -2.8697337955236435e-02
    z[6,5,0]  R2407     5.9080682694911957e-02
    z[6,5,0]  R2408     4.8808166384696960e-01
    z[6,5,0]  R2409     5.8220338821411133e-01
    z[6,5,0]  R2410     -1.7917427420616150e-01
    z[6,5,0]  R2411     3.0699586868286133e-01
    z[6,5,0]  R2412     4.4657203555107117e-01
    z[6,5,0]  R2413     3.9458346366882324e-01
    z[6,5,0]  R2414     2.7564147114753723e-01
    z[6,5,0]  R2415     1.1680698394775391e-01
    z[6,5,0]  R2416     -0.307258665561676
    z[6,5,0]  R2417     4.0832468867301941e-01
    z[6,5,0]  R2418     -1.1998391896486282e-01
    z[6,5,0]  R2419     -5.3194290399551392e-01
    z[6,5,0]  R2420     -2.1263392269611359e-01
    z[6,5,0]  R2421     1.7259493470191956e-01
    z[6,5,0]  R2422     2.1013502776622772e-01
    z[6,5,0]  R2423     9.5719449222087860e-02
    z[6,5,0]  R2424     7.5331754982471466e-02
    z[6,5,0]  R2425     -1.7011393606662750e-01
    z[6,5,0]  R2426     2.8778192400932312e-01
    z[6,5,0]  R2427     1.9439187645912170e-01
    z[6,5,0]  R2428     0.392865389585495
    z[6,5,0]  R2429     -6.4120173454284668e-02
    z[6,5,0]  R2430     3.1283938884735107e-01
    z[6,5,0]  R2431     -4.5278713107109070e-01
    z[6,5,0]  R2432     -4.3649911880493164e-02
    z[6,5,0]  R2433     3.8477461785078049e-02
    z[6,5,0]  R2434     -3.0019250512123108e-01
    z[6,5,0]  R2435     4.6667033433914185e-01
    z[6,5,0]  R2436     -5.4023897647857666e-01
    z[6,5,0]  R2437     0.0761353075504303
    z[6,5,0]  R2438     -1.2854102253913879e-01
    z[6,5,0]  R2439     -5.4745179414749146e-01
    z[6,5,1]  R48       1
    z[6,5,1]  R57       -1
    z[6,5,1]  R2339     -1
    z[6,5,1]  R2340     1
    z[6,5,1]  R2351     -9.0008413791656494e-01
    z[6,5,1]  R2352     4.8491966724395752e-01
    z[6,5,1]  R2353     2.7578523755073547e-01
    z[6,5,1]  R2354     4.0412941575050354e-01
    z[6,5,1]  R2355     -8.4182655811309814e-01
    z[6,5,1]  R2356     3.7795212864875793e-01
    z[6,5,1]  R2357     -4.7477439045906067e-01
    z[6,5,1]  R2358     -8.2168734073638916e-01
    z[6,5,1]  R2359     3.5587257146835327e-01
    z[6,5,1]  R2360     5.9452176094055176e-01
    z[6,5,1]  R2361     5.4028725624084473e-01
    z[6,5,1]  R2362     4.3962958455085754e-01
    z[6,5,1]  R2363     1.2242415547370911e-01
    z[6,5,1]  R2364     4.0875086188316345e-01
    z[6,5,1]  R2365     4.1638728976249695e-01
    z[6,5,1]  R2366     4.0337544679641724e-01
    z[6,5,1]  R2367     4.0010768175125122e-01
    z[6,5,1]  R2368     2.9809844493865967e-01
    z[6,5,1]  R2369     3.8250654935836792e-01
    z[6,5,1]  R2370     2.4132257699966431e-01
    z[6,5,1]  R2371     3.0258321762084961e-01
    z[6,5,1]  R2372     3.1962257623672485e-01
    z[6,5,1]  R2373     5.7955151796340942e-01
    z[6,5,1]  R2374     1.7624391615390778e-01
    z[6,5,1]  R2375     2.0100392401218414e-01
    z[6,5,1]  R2376     -7.4481934309005737e-02
    z[6,5,1]  R2377     2.6645469665527344e-01
    z[6,5,1]  R2378     -5.8485662937164307e-01
    z[6,5,1]  R2379     -3.7440571188926697e-01
    z[6,5,1]  R2380     -6.1355471611022949e-01
    z[6,5,1]  R2381     -2.6705756783485413e-01
    z[6,5,1]  R2382     -7.1646170690655708e-03
    z[6,5,1]  R2383     1.0217893868684769e-01
    z[6,5,1]  R2384     4.0572628378868103e-01
    z[6,5,1]  R2385     3.9647969603538513e-01
    z[6,5,1]  R2386     3.8121148943901062e-01
    z[6,5,1]  R2387     3.7789022922515869e-01
    z[6,5,1]  R2388     -5.6038576364517212e-01
    z[6,5,1]  R2389     -5.3539234399795532e-01
    z[6,5,1]  R2390     -5.6757456064224243e-01
    z[6,5,1]  R2391     4.7778841853141785e-01
    z[6,5,1]  R2392     2.7109444141387939e-01
    z[6,5,1]  R2393     3.9177486300468445e-01
    z[6,5,1]  R2394     4.6451058983802795e-01
    z[6,5,1]  R2395     1.6319791972637177e-01
    z[6,5,1]  R2396     4.5668345689773560e-01
    z[6,5,1]  R2397     -6.4762878417968750e-01
    z[6,5,1]  R2398     -5.0727158784866333e-01
    z[6,5,1]  R2399     -5.3213357925415039e-01
    z[6,5,1]  R2400     -5.4442584514617920e-01
    z[6,5,1]  R2401     4.0950211882591248e-01
    z[6,5,1]  R2402     -6.4772331714630127e-01
    z[6,5,1]  R2403     -4.2938083410263062e-01
    z[6,5,1]  R2404     3.2703793048858643e-01
    z[6,5,1]  R2405     -4.7708502411842346e-01
    z[6,5,1]  R2406     -3.7778580188751221e-01
    z[6,5,1]  R2407     -3.9710542559623718e-01
    z[6,5,1]  R2408     3.7884214520454407e-01
    z[6,5,1]  R2409     3.1807422637939453e-01
    z[6,5,1]  R2410     0.737488329410553
    z[6,5,1]  R2411     7.8674137592315674e-01
    z[6,5,1]  R2412     4.9484989047050476e-01
    z[6,5,1]  R2413     6.3993936777114868e-01
    z[6,5,1]  R2414     5.3592085838317871e-01
    z[6,5,1]  R2415     6.3357603549957275e-01
    z[6,5,1]  R2416     6.0925018787384033e-01
    z[6,5,1]  R2417     5.5019748210906982e-01
    z[6,5,1]  R2418     5.4293698072433472e-01
    z[6,5,1]  R2419     6.1711353063583374e-01
    z[6,5,1]  R2420     -0.664252758026123
    z[6,5,1]  R2421     -7.3075622320175171e-01
    z[6,5,1]  R2422     -9.7127676010131836e-01
    z[6,5,1]  R2423     -9.6090388298034668e-01
    z[6,5,1]  R2424     -9.1653537750244141e-01
    z[6,5,1]  R2425     -9.2195582389831543e-01
    z[6,5,1]  R2426     -8.9673334360122681e-01
    z[6,5,1]  R2427     -9.1193628311157227e-01
    z[6,5,1]  R2428     -8.3954977989196777e-01
    z[6,5,1]  R2429     -0.900809109210968
    z[6,5,1]  R2430     5.2828085422515869e-01
    z[6,5,1]  R2431     2.4775977432727814e-01
    z[6,5,1]  R2432     4.3066747486591339e-02
    z[6,5,1]  R2433     -6.1472386121749878e-01
    z[6,5,1]  R2434     -8.9177715778350830e-01
    z[6,5,1]  R2435     -6.4031100273132324e-01
    z[6,5,1]  R2436     -7.4875533580780029e-01
    z[6,5,1]  R2437     -4.7622591257095337e-01
    z[6,5,1]  R2438     -7.6080149412155151e-01
    z[6,5,1]  R2439     -3.2570815086364746e-01
    z[6,5,2]  R49       1
    z[6,5,2]  R58       -1
    z[6,5,2]  R2341     -1
    z[6,5,2]  R2342     1
    z[6,5,2]  R2351     -2.2932359576225281e-01
    z[6,5,2]  R2352     -6.8683421611785889e-01
    z[6,5,2]  R2353     -5.0153082609176636e-01
    z[6,5,2]  R2354     -6.4585661888122559e-01
    z[6,5,2]  R2355     1.6330896317958832e-01
    z[6,5,2]  R2356     -5.6998163461685181e-01
    z[6,5,2]  R2357     5.9834194183349609e-01
    z[6,5,2]  R2358     -1.1998074501752853e-01
    z[6,5,2]  R2359     -0.644943118095398
    z[6,5,2]  R2360     -4.7349187731742859e-01
    z[6,5,2]  R2361     2.5623485445976257e-01
    z[6,5,2]  R2362     4.7445413470268250e-01
    z[6,5,2]  R2363     -5.6328210048377514e-03
    z[6,5,2]  R2364     1.6692188382148743e-01
    z[6,5,2]  R2365     3.6668628454208374e-01
    z[6,5,2]  R2366     7.6216422021389008e-02
    z[6,5,2]  R2367     2.4714258313179016e-01
    z[6,5,2]  R2368     2.9009503126144409e-01
    z[6,5,2]  R2369     -1.0790310055017471e-01
    z[6,5,2]  R2370     4.0713006258010864e-01
    z[6,5,2]  R2371     2.1538142859935760e-01
    z[6,5,2]  R2372     6.6276490688323975e-01
    z[6,5,2]  R2373     3.0871546268463135e-01
    z[6,5,2]  R2374     2.8660658001899719e-01
    z[6,5,2]  R2375     3.0485492944717407e-01
    z[6,5,2]  R2376     1.6351932287216187e-01
    z[6,5,2]  R2377     6.7355133593082428e-02
    z[6,5,2]  R2378     -5.0796133279800415e-01
    z[6,5,2]  R2379     2.2495531011372805e-03
    z[6,5,2]  R2380     1.5763860195875168e-02
    z[6,5,2]  R2381     1.5075573325157166e-01
    z[6,5,2]  R2382     6.8243521451950073e-01
    z[6,5,2]  R2383     6.0448747873306274e-01
    z[6,5,2]  R2384     2.1318452060222626e-01
    z[6,5,2]  R2385     1.9009378552436829e-01
    z[6,5,2]  R2386     5.0256246328353882e-01
    z[6,5,2]  R2387     4.5426163077354431e-01
    z[6,5,2]  R2388     6.6239468753337860e-02
    z[6,5,2]  R2389     9.6148863434791565e-02
    z[6,5,2]  R2390     -6.8059504032135010e-02
    z[6,5,2]  R2391     6.4776223897933960e-01
    z[6,5,2]  R2392     5.2126592397689819e-01
    z[6,5,2]  R2393     4.7185677289962769e-01
    z[6,5,2]  R2394     7.9380877315998077e-02
    z[6,5,2]  R2395     2.2927826642990112e-01
    z[6,5,2]  R2396     -1.2523406744003296e-01
    z[6,5,2]  R2397     -2.0751677453517914e-02
    z[6,5,2]  R2398     -2.7674663066864014e-01
    z[6,5,2]  R2399     2.1530188620090485e-02
    z[6,5,2]  R2400     -3.0051467474550009e-03
    z[6,5,2]  R2401     -1.7241753637790680e-01
    z[6,5,2]  R2402     -1.3766567409038544e-01
    z[6,5,2]  R2403     4.2141386866569519e-01
    z[6,5,2]  R2404     2.1265690028667450e-01
    z[6,5,2]  R2405     -3.5251066088676453e-01
    z[6,5,2]  R2406     0.394464910030365
    z[6,5,2]  R2407     3.6904075741767883e-01
    z[6,5,2]  R2408     0.0866931602358818
    z[6,5,2]  R2409     -6.8666212260723114e-02
    z[6,5,2]  R2410     2.4410922825336456e-01
    z[6,5,2]  R2411     1.5601533651351929e-01
    z[6,5,2]  R2412     2.0370896160602570e-01
    z[6,5,2]  R2413     -2.0028610527515411e-01
    z[6,5,2]  R2414     -0.275034099817276
    z[6,5,2]  R2415     -3.3176821470260620e-01
    z[6,5,2]  R2416     -7.0576362311840057e-02
    z[6,5,2]  R2417     -5.0805234909057617e-01
    z[6,5,2]  R2418     -2.9526489973068237e-01
    z[6,5,2]  R2419     -3.7029787898063660e-01
    z[6,5,2]  R2420     -7.2793923318386078e-02
    z[6,5,2]  R2421     -3.4349292516708374e-01
    z[6,5,2]  R2422     -7.7627012506127357e-03
    z[6,5,2]  R2423     1.4133757352828979e-01
    z[6,5,2]  R2424     -2.7460965514183044e-01
    z[6,5,2]  R2425     -4.9809359014034271e-02
    z[6,5,2]  R2426     2.4540388584136963e-01
    z[6,5,2]  R2427     -3.3133223652839661e-01
    z[6,5,2]  R2428     2.9985567927360535e-01
    z[6,5,2]  R2429     -1.1389529705047607e-01
    z[6,5,2]  R2430     -8.6399927735328674e-02
    z[6,5,2]  R2431     6.4769244194030762e-01
    z[6,5,2]  R2432     7.2858351469039917e-01
    z[6,5,2]  R2433     2.9134291410446167e-01
    z[6,5,2]  R2434     -2.1549564599990845e-01
    z[6,5,2]  R2435     2.0287392660975456e-02
    z[6,5,2]  R2436     3.4914724528789520e-02
    z[6,5,2]  R2437     1.6762803494930267e-01
    z[6,5,2]  R2438     3.2696092128753662e-01
    z[6,5,2]  R2439     -0.512986421585083
    z[6,5,3]  R50       1
    z[6,5,3]  R59       -1
    z[6,5,3]  R2343     -1
    z[6,5,3]  R2344     1
    z[6,5,3]  R2351     5.1031899638473988e-03
    z[6,5,3]  R2352     -1.4898261427879333e-01
    z[6,5,3]  R2353     -2.8086232021450996e-02
    z[6,5,3]  R2354     5.5436813831329346e-01
    z[6,5,3]  R2355     -3.6988684535026550e-01
    z[6,5,3]  R2356     -1.6029103100299835e-01
    z[6,5,3]  R2357     -2.2525161504745483e-01
    z[6,5,3]  R2358     -4.5653226971626282e-01
    z[6,5,3]  R2359     -2.2042134404182434e-01
    z[6,5,3]  R2360     5.0365632772445679e-01
    z[6,5,3]  R2361     7.7158883213996887e-02
    z[6,5,3]  R2362     -0.557939350605011
    z[6,5,3]  R2363     -3.8787013292312622e-01
    z[6,5,3]  R2364     -7.7670890092849731e-01
    z[6,5,3]  R2365     -7.0972442626953125e-01
    z[6,5,3]  R2366     -3.4640991687774658e-01
    z[6,5,3]  R2367     -7.3124104738235474e-01
    z[6,5,3]  R2368     -5.2422147989273071e-01
    z[6,5,3]  R2369     3.5884547233581543e-01
    z[6,5,3]  R2370     4.0285471081733704e-01
    z[6,5,3]  R2371     -0.759775698184967
    z[6,5,3]  R2372     -5.8142524957656860e-01
    z[6,5,3]  R2373     -4.2721742391586304e-01
    z[6,5,3]  R2374     -5.6639397144317627e-01
    z[6,5,3]  R2375     -7.0367473363876343e-01
    z[6,5,3]  R2376     -1.2777270376682281e-01
    z[6,5,3]  R2377     1.6802865266799927e-01
    z[6,5,3]  R2378     4.2923569679260254e-01
    z[6,5,3]  R2379     1.0206146538257599e-01
    z[6,5,3]  R2380     6.9345241785049438e-01
    z[6,5,3]  R2381     -8.5138714313507080e-01
    z[6,5,3]  R2382     -4.4106084108352661e-01
    z[6,5,3]  R2383     -5.5888414382934570e-01
    z[6,5,3]  R2384     -8.1872475147247314e-01
    z[6,5,3]  R2385     3.7962052226066589e-01
    z[6,5,3]  R2386     -3.3120054006576538e-01
    z[6,5,3]  R2387     -2.5419533252716064e-01
    z[6,5,3]  R2388     4.5828998088836670e-01
    z[6,5,3]  R2389     5.4101234674453735e-01
    z[6,5,3]  R2390     5.4365581274032593e-01
    z[6,5,3]  R2391     -5.8628183603286743e-01
    z[6,5,3]  R2392     -7.3722654581069946e-01
    z[6,5,3]  R2393     -6.0235756635665894e-01
    z[6,5,3]  R2394     -4.5180425047874451e-01
    z[6,5,3]  R2395     -7.7838724851608276e-01
    z[6,5,3]  R2396     1.3046717643737793e-01
    z[6,5,3]  R2397     4.4680750370025635e-01
    z[6,5,3]  R2398     0.547261655330658
    z[6,5,3]  R2399     6.1301314830780029e-01
    z[6,5,3]  R2400     0.675198495388031
    z[6,5,3]  R2401     -2.6835939288139343e-01
    z[6,5,3]  R2402     6.6462028026580811e-01
    z[6,5,3]  R2403     7.6194804906845093e-01
    z[6,5,3]  R2404     5.4782259464263916e-01
    z[6,5,3]  R2405     5.4189068078994751e-01
    z[6,5,3]  R2406     7.3853135108947754e-01
    z[6,5,3]  R2407     7.4501550197601318e-01
    z[6,5,3]  R2408     2.4280984699726105e-01
    z[6,5,3]  R2409     3.2068583369255066e-01
    z[6,5,3]  R2410     5.5193895101547241e-01
    z[6,5,3]  R2411     -4.0297082066535950e-01
    z[6,5,3]  R2412     -6.5933072566986084e-01
    z[6,5,3]  R2413     -1.6667121648788452e-01
    z[6,5,3]  R2414     -4.6102777123451233e-01
    z[6,5,3]  R2415     -4.1386270523071289e-01
    z[6,5,3]  R2416     2.9408720135688782e-01
    z[6,5,3]  R2417     3.2679751515388489e-01
    z[6,5,3]  R2418     -1.5496331453323364e-01
    z[6,5,3]  R2419     3.8975742459297180e-01
    z[6,5,3]  R2420     -5.6434392929077148e-01
    z[6,5,3]  R2421     -5.4792308807373047e-01
    z[6,5,3]  R2422     -2.5889266282320023e-02
    z[6,5,3]  R2423     7.3489256203174591e-02
    z[6,5,3]  R2424     -9.3063563108444214e-03
    z[6,5,3]  R2425     1.6248162090778351e-01
    z[6,5,3]  R2426     2.1792547404766083e-01
    z[6,5,3]  R2427     1.0399517416954041e-01
    z[6,5,3]  R2428     -1.1378584057092667e-01
    z[6,5,3]  R2429     1.6098581254482269e-01
    z[6,5,3]  R2430     2.6375246047973633e-01
    z[6,5,3]  R2431     -4.4963663816452026e-01
    z[6,5,3]  R2432     -2.0457515120506287e-01
    z[6,5,3]  R2433     -4.1944715380668640e-01
    z[6,5,3]  R2434     -1.7698907852172852e-01
    z[6,5,3]  R2435     -1.0731939971446991e-01
    z[6,5,3]  R2436     -2.1491670049726963e-03
    z[6,5,3]  R2437     -1.4721606671810150e-01
    z[6,5,3]  R2438     7.5632028281688690e-02
    z[6,5,3]  R2439     -1.1487320810556412e-01
    z[6,5,4]  R51       1
    z[6,5,4]  R60       -1
    z[6,5,4]  R2345     -1
    z[6,5,4]  R2346     1
    z[6,5,4]  R2351     -4.8948537558317184e-02
    z[6,5,4]  R2352     4.3450409173965454e-01
    z[6,5,4]  R2353     3.9758551120758057e-01
    z[6,5,4]  R2354     2.4671699106693268e-01
    z[6,5,4]  R2355     -2.3689439892768860e-01
    z[6,5,4]  R2356     5.3628218173980713e-01
    z[6,5,4]  R2357     4.5758464932441711e-01
    z[6,5,4]  R2358     1.3389259576797485e-01
    z[6,5,4]  R2359     6.1684852838516235e-01
    z[6,5,4]  R2360     -1.2166652828454971e-01
    z[6,5,4]  R2361     -3.7135216593742371e-01
    z[6,5,4]  R2362     -0.354168564081192
    z[6,5,4]  R2363     -2.1554410457611084e-01
    z[6,5,4]  R2364     -9.7739897668361664e-02
    z[6,5,4]  R2365     -8.2521423697471619e-02
    z[6,5,4]  R2366     -4.7443509101867676e-01
    z[6,5,4]  R2367     -3.2872599363327026e-01
    z[6,5,4]  R2368     -9.5027446746826172e-02
    z[6,5,4]  R2369     -6.7304037511348724e-02
    z[6,5,4]  R2370     0.0866825059056282
    z[6,5,4]  R2371     -6.7003101110458374e-02
    z[6,5,4]  R2372     -7.8297823667526245e-02
    z[6,5,4]  R2373     4.3972003459930420e-01
    z[6,5,4]  R2374     3.1733307242393494e-01
    z[6,5,4]  R2375     4.2865127325057983e-01
    z[6,5,4]  R2376     5.1188313961029053e-01
    z[6,5,4]  R2377     0.0507943332195282
    z[6,5,4]  R2378     9.2227414250373840e-02
    z[6,5,4]  R2379     -1.1723274737596512e-01
    z[6,5,4]  R2380     7.0551261305809021e-02
    z[6,5,4]  R2381     2.8297787904739380e-01
    z[6,5,4]  R2382     -4.0528275072574615e-02
    z[6,5,4]  R2383     3.9297146722674370e-03
    z[6,5,4]  R2384     -2.5915073230862617e-02
    z[6,5,4]  R2385     1.1037456989288330e-01
    z[6,5,4]  R2386     -0.0431511253118515
    z[6,5,4]  R2387     -8.1617077812552452e-03
    z[6,5,4]  R2388     -4.2186689376831055e-01
    z[6,5,4]  R2389     -2.3261302709579468e-01
    z[6,5,4]  R2390     -1.6281627118587494e-01
    z[6,5,4]  R2391     8.3653137087821960e-02
    z[6,5,4]  R2392     4.4808998703956604e-02
    z[6,5,4]  R2393     3.5443204641342163e-01
    z[6,5,4]  R2394     -1.3447956740856171e-01
    z[6,5,4]  R2395     1.6174888610839844e-01
    z[6,5,4]  R2396     -1.6961348056793213e-01
    z[6,5,4]  R2397     -2.8872808814048767e-01
    z[6,5,4]  R2398     0.0324304923415184
    z[6,5,4]  R2399     1.1904054135084152e-01
    z[6,5,4]  R2400     1.3996081054210663e-01
    z[6,5,4]  R2401     -6.6272771358489990e-01
    z[6,5,4]  R2402     -2.5161406025290489e-02
    z[6,5,4]  R2403     -1.1635018140077591e-01
    z[6,5,4]  R2404     -1.0016535967588425e-01
    z[6,5,4]  R2405     5.2733731269836426e-01
    z[6,5,4]  R2406     -2.1668742597103119e-01
    z[6,5,4]  R2407     -2.9552593827247620e-01
    z[6,5,4]  R2408     -3.6308676004409790e-01
    z[6,5,4]  R2409     -3.3995696902275085e-01
    z[6,5,4]  R2410     -2.1366906166076660e-01
    z[6,5,4]  R2411     2.9065829515457153e-01
    z[6,5,4]  R2412     1.4960610866546631e-01
    z[6,5,4]  R2413     7.0273235440254211e-02
    z[6,5,4]  R2414     1.9583707675337791e-02
    z[6,5,4]  R2415     3.1935390830039978e-01
    z[6,5,4]  R2416     2.5885611772537231e-01
    z[6,5,4]  R2417     3.1587433815002441e-01
    z[6,5,4]  R2418     4.3797993659973145e-01
    z[6,5,4]  R2419     -2.6162989437580109e-02
    z[6,5,4]  R2420     -0.0783790573477745
    z[6,5,4]  R2421     9.8554842174053192e-02
    z[6,5,4]  R2422     8.3417415618896484e-02
    z[6,5,4]  R2423     -1.2464637309312820e-01
    z[6,5,4]  R2424     1.1390948295593262e-01
    z[6,5,4]  R2425     -2.8092622756958008e-02
    z[6,5,4]  R2426     3.9715595543384552e-02
    z[6,5,4]  R2427     8.3001688122749329e-02
    z[6,5,4]  R2428     1.3679456710815430e-01
    z[6,5,4]  R2429     -2.5100448727607727e-01
    z[6,5,4]  R2430     1.2115333974361420e-01
    z[6,5,4]  R2431     -1.7842277884483337e-01
    z[6,5,4]  R2432     -3.1928396224975586e-01
    z[6,5,4]  R2433     -4.0278270840644836e-01
    z[6,5,4]  R2434     -7.5008712708950043e-02
    z[6,5,4]  R2435     -1.9184872508049011e-01
    z[6,5,4]  R2436     -3.7234139442443848e-01
    z[6,5,4]  R2437     -4.0335541963577271e-01
    z[6,5,4]  R2438     -9.4079233705997467e-02
    z[6,5,4]  R2439     -4.3830177187919617e-01
    z[6,5,5]  R52       1
    z[6,5,5]  R61       -1
    z[6,5,5]  R2347     -1
    z[6,5,5]  R2348     1
    z[6,5,5]  R2351     -4.1539106518030167e-02
    z[6,5,5]  R2352     2.2819447517395020e-01
    z[6,5,5]  R2353     1.7619884014129639e-01
    z[6,5,5]  R2354     1.3112403452396393e-01
    z[6,5,5]  R2355     1.2630765140056610e-01
    z[6,5,5]  R2356     3.9634126424789429e-01
    z[6,5,5]  R2357     -6.1755768954753876e-02
    z[6,5,5]  R2358     -1.6362796723842621e-01
    z[6,5,5]  R2359     -0.00947926752269268
    z[6,5,5]  R2360     3.7716919183731079e-01
    z[6,5,5]  R2361     -1.2126628309488297e-01
    z[6,5,5]  R2362     -8.2264598459005356e-03
    z[6,5,5]  R2363     7.7099567651748657e-01
    z[6,5,5]  R2364     -9.8559595644474030e-02
    z[6,5,5]  R2365     -3.2236614823341370e-01
    z[6,5,5]  R2366     -3.8575440645217896e-01
    z[6,5,5]  R2367     2.7779513597488403e-01
    z[6,5,5]  R2368     -4.8051732778549194e-01
    z[6,5,5]  R2369     -7.7186834812164307e-01
    z[6,5,5]  R2370     -4.4081023335456848e-01
    z[6,5,5]  R2371     4.9419414997100830e-01
    z[6,5,5]  R2372     -9.7955256700515747e-02
    z[6,5,5]  R2373     -0.336814820766449
    z[6,5,5]  R2374     -5.7692015171051025e-01
    z[6,5,5]  R2375     1.9828870892524719e-01
    z[6,5,5]  R2376     0.127718985080719
    z[6,5,5]  R2377     -7.1706116199493408e-01
    z[6,5,5]  R2378     4.2671549320220947e-01
    z[6,5,5]  R2379     -6.1563742160797119e-01
    z[6,5,5]  R2380     -4.0803611278533936e-02
    z[6,5,5]  R2381     2.2335672378540039e-01
    z[6,5,5]  R2382     4.1427803039550781e-01
    z[6,5,5]  R2383     -1.2038338184356689e-01
    z[6,5,5]  R2384     9.2470802366733551e-02
    z[6,5,5]  R2385     3.5213101655244827e-02
    z[6,5,5]  R2386     8.0370604991912842e-02
    z[6,5,5]  R2387     0.667449414730072
    z[6,5,5]  R2388     -2.9559394717216492e-01
    z[6,5,5]  R2389     -5.7194280624389648e-01
    z[6,5,5]  R2390     -3.8481815718114376e-03
    z[6,5,5]  R2391     2.5344986468553543e-02
    z[6,5,5]  R2392     2.5290971994400024e-01
    z[6,5,5]  R2393     -2.8588702902197838e-02
    z[6,5,5]  R2394     -4.4346663355827332e-01
    z[6,5,5]  R2395     -2.3948095738887787e-01
    z[6,5,5]  R2396     -7.2092288732528687e-01
    z[6,5,5]  R2397     -2.1446606516838074e-01
    z[6,5,5]  R2398     -4.3531975150108337e-01
    z[6,5,5]  R2399     -4.8618495464324951e-01
    z[6,5,5]  R2400     -6.1701752245426178e-02
    z[6,5,5]  R2401     1.9499303773045540e-02
    z[6,5,5]  R2402     -8.5549950599670410e-02
    z[6,5,5]  R2403     1.8580843508243561e-01
    z[6,5,5]  R2404     -4.3025019764900208e-01
    z[6,5,5]  R2405     -1.3461917638778687e-01
    z[6,5,5]  R2406     -9.5116794109344482e-02
    z[6,5,5]  R2407     0.000767854624427855
    z[6,5,5]  R2408     -5.7054489850997925e-01
    z[6,5,5]  R2409     -4.8150390386581421e-01
    z[6,5,5]  R2410     -3.3173050731420517e-02
    z[6,5,5]  R2411     -7.7897910960018635e-03
    z[6,5,5]  R2412     -8.7487258017063141e-02
    z[6,5,5]  R2413     -1.5370495617389679e-02
    z[6,5,5]  R2414     -5.7310339063405991e-02
    z[6,5,5]  R2415     3.4435328841209412e-01
    z[6,5,5]  R2416     2.1307244896888733e-01
    z[6,5,5]  R2417     6.8327270448207855e-02
    z[6,5,5]  R2418     1.6446320712566376e-01
    z[6,5,5]  R2419     1.2961356341838837e-01
    z[6,5,5]  R2420     -2.1874779462814331e-01
    z[6,5,5]  R2421     -6.9876156747341156e-02
    z[6,5,5]  R2422     5.9693735092878342e-02
    z[6,5,5]  R2423     4.1034642606973648e-02
    z[6,5,5]  R2424     2.2982439398765564e-01
    z[6,5,5]  R2425     2.9859346151351929e-01
    z[6,5,5]  R2426     5.8090966194868088e-02
    z[6,5,5]  R2427     -5.0983525812625885e-02
    z[6,5,5]  R2428     1.3351324200630188e-01
    z[6,5,5]  R2429     -2.8407073020935059e-01
    z[6,5,5]  R2430     -5.4629868268966675e-01
    z[6,5,5]  R2431     2.7882248163223267e-01
    z[6,5,5]  R2432     -4.6346664428710938e-01
    z[6,5,5]  R2433     -3.3060312271118164e-01
    z[6,5,5]  R2434     5.1499918103218079e-02
    z[6,5,5]  R2435     -5.3591352701187134e-01
    z[6,5,5]  R2436     6.3986793160438538e-02
    z[6,5,5]  R2437     -7.3307341337203979e-01
    z[6,5,5]  R2438     -1.4958636462688446e-01
    z[6,5,5]  R2439     -3.4186232089996338e-01
    z[6,5,6]  R53       1
    z[6,5,6]  R62       -1
    z[6,5,6]  R2349     -1
    z[6,5,6]  R2350     1
    z[6,5,6]  R2351     2.6531422138214111e-01
    z[6,5,6]  R2352     1.2754152715206146e-01
    z[6,5,6]  R2353     1.3739053905010223e-01
    z[6,5,6]  R2354     1.5865311026573181e-01
    z[6,5,6]  R2355     -1.2897776067256927e-01
    z[6,5,6]  R2356     5.1337309181690216e-02
    z[6,5,6]  R2357     3.5426083207130432e-01
    z[6,5,6]  R2358     -2.1180485188961029e-01
    z[6,5,6]  R2359     -1.6379144787788391e-01
    z[6,5,6]  R2360     6.9629065692424774e-02
    z[6,5,6]  R2361     1.1301308125257492e-01
    z[6,5,6]  R2362     -0.0913948118686676
    z[6,5,6]  R2363     -1.2146764993667603e-01
    z[6,5,6]  R2364     -3.8080912828445435e-01
    z[6,5,6]  R2365     -2.7549448609352112e-01
    z[6,5,6]  R2366     -4.1617578268051147e-01
    z[6,5,6]  R2367     -2.3799885809421539e-01
    z[6,5,6]  R2368     -3.3573645353317261e-01
    z[6,5,6]  R2369     -8.6897037923336029e-02
    z[6,5,6]  R2370     -4.7503328323364258e-01
    z[6,5,6]  R2371     -1.4641021192073822e-01
    z[6,5,6]  R2372     -1.2273354083299637e-01
    z[6,5,6]  R2373     4.0288589894771576e-02
    z[6,5,6]  R2374     -2.5131475925445557e-01
    z[6,5,6]  R2375     -6.5688163042068481e-02
    z[6,5,6]  R2376     2.0194327458739281e-02
    z[6,5,6]  R2377     -3.3444055914878845e-01
    z[6,5,6]  R2378     1.5683636069297791e-01
    z[6,5,6]  R2379     1.6815623268485069e-02
    z[6,5,6]  R2380     -7.5065419077873230e-02
    z[6,5,6]  R2381     -4.6393796801567078e-02
    z[6,5,6]  R2382     9.8258063197135925e-02
    z[6,5,6]  R2383     -1.5908671915531158e-01
    z[6,5,6]  R2384     -2.9051387310028076e-01
    z[6,5,6]  R2385     -6.2175148725509644e-01
    z[6,5,6]  R2386     -4.0989780426025391e-01
    z[6,5,6]  R2387     3.0348291993141174e-01
    z[6,5,6]  R2388     1.2335287779569626e-01
    z[6,5,6]  R2389     7.8560203313827515e-02
    z[6,5,6]  R2390     2.9827767610549927e-01
    z[6,5,6]  R2391     0.0264901053160429
    z[6,5,6]  R2392     -6.8063624203205109e-02
    z[6,5,6]  R2393     -5.7983744889497757e-02
    z[6,5,6]  R2394     -2.0843598246574402e-01
    z[6,5,6]  R2395     -3.3385860919952393e-01
    z[6,5,6]  R2396     -1.8527679145336151e-01
    z[6,5,6]  R2397     1.6800068318843842e-01
    z[6,5,6]  R2398     1.2624703347682953e-01
    z[6,5,6]  R2399     1.1233668774366379e-01
    z[6,5,6]  R2400     2.2378845512866974e-01
    z[6,5,6]  R2401     -0.306953102350235
    z[6,5,6]  R2402     3.6419898271560669e-02
    z[6,5,6]  R2403     -0.0854058712720871
    z[6,5,6]  R2404     -2.8591899201273918e-02
    z[6,5,6]  R2405     2.2501243650913239e-01
    z[6,5,6]  R2406     -3.1531330943107605e-01
    z[6,5,6]  R2407     2.4544094502925873e-01
    z[6,5,6]  R2408     -3.0729341506958008e-01
    z[6,5,6]  R2409     -3.2387769222259521e-01
    z[6,5,6]  R2410     1.1413425207138062e-01
    z[6,5,6]  R2411     -1.2458848953247070e-01
    z[6,5,6]  R2412     2.2236593067646027e-01
    z[6,5,6]  R2413     0.60142582654953
    z[6,5,6]  R2414     5.8732640743255615e-01
    z[6,5,6]  R2415     2.8813013434410095e-01
    z[6,5,6]  R2416     -0.574918806552887
    z[6,5,6]  R2417     2.4737544357776642e-01
    z[6,5,6]  R2418     -6.0062789916992188e-01
    z[6,5,6]  R2419     -1.7231461405754089e-01
    z[6,5,6]  R2420     -3.6848086118698120e-01
    z[6,5,6]  R2421     5.8339715003967285e-02
    z[6,5,6]  R2422     -3.4821897745132446e-02
    z[6,5,6]  R2423     1.5780979394912720e-01
    z[6,5,6]  R2424     1.1400125920772552e-01
    z[6,5,6]  R2425     4.7225605696439743e-02
    z[6,5,6]  R2426     -0.019609235227108
    z[6,5,6]  R2427     -2.2348802536725998e-02
    z[6,5,6]  R2428     3.7599030882120132e-02
    z[6,5,6]  R2429     -4.2935546487569809e-02
    z[6,5,6]  R2430     -4.8259723186492920e-01
    z[6,5,6]  R2431     -4.8410382121801376e-02
    z[6,5,6]  R2432     -3.2682019472122192e-01
    z[6,5,6]  R2433     2.9712799191474915e-01
    z[6,5,6]  R2434     -1.6904434561729431e-01
    z[6,5,6]  R2435     1.9047904014587402e-01
    z[6,5,6]  R2436     5.9592097997665405e-02
    z[6,5,6]  R2437     -1.3247039914131165e-01
    z[6,5,6]  R2438     -5.1069319248199463e-01
    z[6,5,6]  R2439     9.4242349267005920e-02
    length[0]  OBJ       1
    length[1]  OBJ       1
    length[2]  OBJ       1
    length[3]  OBJ       1
    length[4]  OBJ       1
    length[5]  OBJ       1
    length[6]  OBJ       1
    delta[0,0]  R2        1
    delta[0,1]  R3        1
    delta[0,2]  R4        1
    delta[0,3]  R5        1
    delta[0,4]  R6        1
    delta[0,5]  R7        1
    delta[0,6]  R8        1
    delta[1,0]  R11       1
    delta[1,1]  R12       1
    delta[1,2]  R13       1
    delta[1,3]  R14       1
    delta[1,4]  R15       1
    delta[1,5]  R16       1
    delta[1,6]  R17       1
    delta[2,0]  R20       1
    delta[2,1]  R21       1
    delta[2,2]  R22       1
    delta[2,3]  R23       1
    delta[2,4]  R24       1
    delta[2,5]  R25       1
    delta[2,6]  R26       1
    delta[3,0]  R29       1
    delta[3,1]  R30       1
    delta[3,2]  R31       1
    delta[3,3]  R32       1
    delta[3,4]  R33       1
    delta[3,5]  R34       1
    delta[3,6]  R35       1
    delta[4,0]  R38       1
    delta[4,1]  R39       1
    delta[4,2]  R40       1
    delta[4,3]  R41       1
    delta[4,4]  R42       1
    delta[4,5]  R43       1
    delta[4,6]  R44       1
    delta[5,0]  R47       1
    delta[5,1]  R48       1
    delta[5,2]  R49       1
    delta[5,3]  R50       1
    delta[5,4]  R51       1
    delta[5,5]  R52       1
    delta[5,6]  R53       1
    delta[6,0]  R56       1
    delta[6,1]  R57       1
    delta[6,2]  R58       1
    delta[6,3]  R59       1
    delta[6,4]  R60       1
    delta[6,5]  R61       1
    delta[6,6]  R62       1
RHS
    RHS1      R1        1
    RHS1      R10       1
    RHS1      R19       1
    RHS1      R28       1
    RHS1      R37       1
    RHS1      R46       1
    RHS1      R55       1
    RHS1      R63       1
    RHS1      R64       -1
BOUNDS
 BV BND1      phi[0,1]
 BV BND1      phi[1,0]
 BV BND1      phi[0,4]
 BV BND1      phi[4,0]
 BV BND1      phi[7,0]
 BV BND1      phi[1,2]
 BV BND1      phi[2,1]
 BV BND1      phi[1,4]
 BV BND1      phi[4,1]
 BV BND1      phi[2,3]
 BV BND1      phi[3,2]
 BV BND1      phi[2,6]
 BV BND1      phi[6,2]
 BV BND1      phi[3,6]
 BV BND1      phi[6,3]
 BV BND1      phi[3,8]
 BV BND1      phi[4,5]
 BV BND1      phi[5,4]
 BV BND1      phi[7,4]
 BV BND1      phi[5,6]
 BV BND1      phi[6,5]
 BV BND1      phi[6,8]
 FR BND1      z[0,1,0]
 FR BND1      z[0,1,1]
 FR BND1      z[0,1,2]
 FR BND1      z[0,1,3]
 FR BND1      z[0,1,4]
 FR BND1      z[0,1,5]
 FR BND1      z[0,1,6]
 FR BND1      z[1,0,0]
 FR BND1      z[1,0,1]
 FR BND1      z[1,0,2]
 FR BND1      z[1,0,3]
 FR BND1      z[1,0,4]
 FR BND1      z[1,0,5]
 FR BND1      z[1,0,6]
 FR BND1      z[0,4,0]
 FR BND1      z[0,4,1]
 FR BND1      z[0,4,2]
 FR BND1      z[0,4,3]
 FR BND1      z[0,4,4]
 FR BND1      z[0,4,5]
 FR BND1      z[0,4,6]
 FR BND1      z[4,0,0]
 FR BND1      z[4,0,1]
 FR BND1      z[4,0,2]
 FR BND1      z[4,0,3]
 FR BND1      z[4,0,4]
 FR BND1      z[4,0,5]
 FR BND1      z[4,0,6]
 FR BND1      z[1,2,0]
 FR BND1      z[1,2,1]
 FR BND1      z[1,2,2]
 FR BND1      z[1,2,3]
 FR BND1      z[1,2,4]
 FR BND1      z[1,2,5]
 FR BND1      z[1,2,6]
 FR BND1      z[2,1,0]
 FR BND1      z[2,1,1]
 FR BND1      z[2,1,2]
 FR BND1      z[2,1,3]
 FR BND1      z[2,1,4]
 FR BND1      z[2,1,5]
 FR BND1      z[2,1,6]
 FR BND1      z[1,4,0]
 FR BND1      z[1,4,1]
 FR BND1      z[1,4,2]
 FR BND1      z[1,4,3]
 FR BND1      z[1,4,4]
 FR BND1      z[1,4,5]
 FR BND1      z[1,4,6]
 FR BND1      z[4,1,0]
 FR BND1      z[4,1,1]
 FR BND1      z[4,1,2]
 FR BND1      z[4,1,3]
 FR BND1      z[4,1,4]
 FR BND1      z[4,1,5]
 FR BND1      z[4,1,6]
 FR BND1      z[2,3,0]
 FR BND1      z[2,3,1]
 FR BND1      z[2,3,2]
 FR BND1      z[2,3,3]
 FR BND1      z[2,3,4]
 FR BND1      z[2,3,5]
 FR BND1      z[2,3,6]
 FR BND1      z[3,2,0]
 FR BND1      z[3,2,1]
 FR BND1      z[3,2,2]
 FR BND1      z[3,2,3]
 FR BND1      z[3,2,4]
 FR BND1      z[3,2,5]
 FR BND1      z[3,2,6]
 FR BND1      z[2,6,0]
 FR BND1      z[2,6,1]
 FR BND1      z[2,6,2]
 FR BND1      z[2,6,3]
 FR BND1      z[2,6,4]
 FR BND1      z[2,6,5]
 FR BND1      z[2,6,6]
 FR BND1      z[6,2,0]
 FR BND1      z[6,2,1]
 FR BND1      z[6,2,2]
 FR BND1      z[6,2,3]
 FR BND1      z[6,2,4]
 FR BND1      z[6,2,5]
 FR BND1      z[6,2,6]
 FR BND1      z[3,6,0]
 FR BND1      z[3,6,1]
 FR BND1      z[3,6,2]
 FR BND1      z[3,6,3]
 FR BND1      z[3,6,4]
 FR BND1      z[3,6,5]
 FR BND1      z[3,6,6]
 FR BND1      z[6,3,0]
 FR BND1      z[6,3,1]
 FR BND1      z[6,3,2]
 FR BND1      z[6,3,3]
 FR BND1      z[6,3,4]
 FR BND1      z[6,3,5]
 FR BND1      z[6,3,6]
 FR BND1      z[4,5,0]
 FR BND1      z[4,5,1]
 FR BND1      z[4,5,2]
 FR BND1      z[4,5,3]
 FR BND1      z[4,5,4]
 FR BND1      z[4,5,5]
 FR BND1      z[4,5,6]
 FR BND1      z[5,4,0]
 FR BND1      z[5,4,1]
 FR BND1      z[5,4,2]
 FR BND1      z[5,4,3]
 FR BND1      z[5,4,4]
 FR BND1      z[5,4,5]
 FR BND1      z[5,4,6]
 FR BND1      z[5,6,0]
 FR BND1      z[5,6,1]
 FR BND1      z[5,6,2]
 FR BND1      z[5,6,3]
 FR BND1      z[5,6,4]
 FR BND1      z[5,6,5]
 FR BND1      z[5,6,6]
 FR BND1      z[6,5,0]
 FR BND1      z[6,5,1]
 FR BND1      z[6,5,2]
 FR BND1      z[6,5,3]
 FR BND1      z[6,5,4]
 FR BND1      z[6,5,5]
 FR BND1      z[6,5,6]
 FR BND1      delta[0,0]
 FR BND1      delta[0,1]
 FR BND1      delta[0,2]
 FR BND1      delta[0,3]
 FR BND1      delta[0,4]
 FR BND1      delta[0,5]
 FR BND1      delta[0,6]
 FR BND1      delta[1,0]
 FR BND1      delta[1,1]
 FR BND1      delta[1,2]
 FR BND1      delta[1,3]
 FR BND1      delta[1,4]
 FR BND1      delta[1,5]
 FR BND1      delta[1,6]
 FR BND1      delta[2,0]
 FR BND1      delta[2,1]
 FR BND1      delta[2,2]
 FR BND1      delta[2,3]
 FR BND1      delta[2,4]
 FR BND1      delta[2,5]
 FR BND1      delta[2,6]
 FR BND1      delta[3,0]
 FR BND1      delta[3,1]
 FR BND1      delta[3,2]
 FR BND1      delta[3,3]
 FR BND1      delta[3,4]
 FR BND1      delta[3,5]
 FR BND1      delta[3,6]
 FR BND1      delta[4,0]
 FR BND1      delta[4,1]
 FR BND1      delta[4,2]
 FR BND1      delta[4,3]
 FR BND1      delta[4,4]
 FR BND1      delta[4,5]
 FR BND1      delta[4,6]
 FR BND1      delta[5,0]
 FR BND1      delta[5,1]
 FR BND1      delta[5,2]
 FR BND1      delta[5,3]
 FR BND1      delta[5,4]
 FR BND1      delta[5,5]
 FR BND1      delta[5,6]
 FR BND1      delta[6,0]
 FR BND1      delta[6,1]
 FR BND1      delta[6,2]
 FR BND1      delta[6,3]
 FR BND1      delta[6,4]
 FR BND1      delta[6,5]
 FR BND1      delta[6,6]
QCMATRIX   qc0     
    length[0]  length[0]  -1
    delta[0,0]  delta[0,0]  1
    delta[0,1]  delta[0,1]  1
    delta[0,2]  delta[0,2]  1
    delta[0,3]  delta[0,3]  1
    delta[0,4]  delta[0,4]  1
    delta[0,5]  delta[0,5]  1
    delta[0,6]  delta[0,6]  1
QCMATRIX   qc1     
    length[1]  length[1]  -1
    delta[1,0]  delta[1,0]  1
    delta[1,1]  delta[1,1]  1
    delta[1,2]  delta[1,2]  1
    delta[1,3]  delta[1,3]  1
    delta[1,4]  delta[1,4]  1
    delta[1,5]  delta[1,5]  1
    delta[1,6]  delta[1,6]  1
QCMATRIX   qc2     
    length[2]  length[2]  -1
    delta[2,0]  delta[2,0]  1
    delta[2,1]  delta[2,1]  1
    delta[2,2]  delta[2,2]  1
    delta[2,3]  delta[2,3]  1
    delta[2,4]  delta[2,4]  1
    delta[2,5]  delta[2,5]  1
    delta[2,6]  delta[2,6]  1
QCMATRIX   qc3     
    length[3]  length[3]  -1
    delta[3,0]  delta[3,0]  1
    delta[3,1]  delta[3,1]  1
    delta[3,2]  delta[3,2]  1
    delta[3,3]  delta[3,3]  1
    delta[3,4]  delta[3,4]  1
    delta[3,5]  delta[3,5]  1
    delta[3,6]  delta[3,6]  1
QCMATRIX   qc4     
    length[4]  length[4]  -1
    delta[4,0]  delta[4,0]  1
    delta[4,1]  delta[4,1]  1
    delta[4,2]  delta[4,2]  1
    delta[4,3]  delta[4,3]  1
    delta[4,4]  delta[4,4]  1
    delta[4,5]  delta[4,5]  1
    delta[4,6]  delta[4,6]  1
QCMATRIX   qc5     
    length[5]  length[5]  -1
    delta[5,0]  delta[5,0]  1
    delta[5,1]  delta[5,1]  1
    delta[5,2]  delta[5,2]  1
    delta[5,3]  delta[5,3]  1
    delta[5,4]  delta[5,4]  1
    delta[5,5]  delta[5,5]  1
    delta[5,6]  delta[5,6]  1
QCMATRIX   qc6     
    length[6]  length[6]  -1
    delta[6,0]  delta[6,0]  1
    delta[6,1]  delta[6,1]  1
    delta[6,2]  delta[6,2]  1
    delta[6,3]  delta[6,3]  1
    delta[6,4]  delta[6,4]  1
    delta[6,5]  delta[6,5]  1
    delta[6,6]  delta[6,6]  1
ENDATA
