NAME LGCS_GCS_Eq5_5_projected
ROWS
 N  OBJ
 E  R0      
 L  R1      
 E  R2      
 E  R3      
 E  R4      
 E  R5      
 E  R6      
 E  R7      
 E  R8      
 E  R9      
 L  R10     
 E  R11     
 E  R12     
 E  R13     
 E  R14     
 E  R15     
 E  R16     
 E  R17     
 E  R18     
 L  R19     
 E  R20     
 E  R21     
 E  R22     
 E  R23     
 E  R24     
 E  R25     
 E  R26     
 E  R27     
 L  R28     
 E  R29     
 E  R30     
 E  R31     
 E  R32     
 E  R33     
 E  R34     
 E  R35     
 E  R36     
 L  R37     
 E  R38     
 E  R39     
 E  R40     
 E  R41     
 E  R42     
 E  R43     
 E  R44     
 E  R45     
 L  R46     
 E  R47     
 E  R48     
 E  R49     
 E  R50     
 E  R51     
 E  R52     
 E  R53     
 E  R54     
 L  R55     
 E  R56     
 E  R57     
 E  R58     
 E  R59     
 E  R60     
 E  R61     
 E  R62     
 E  R63     
 E  R64     
 L  R65     
 L  R66     
 L  R67     
 L  R68     
 L  R69     
 L  R70     
 L  R71     
 L  R72     
 L  R73     
 L  R74     
 L  R75     
 L  R76     
 L  R77     
 L  R78     
 L  R79     
 L  R80     
 L  R81     
 L  R82     
 L  R83     
 L  R84     
 L  R85     
 L  R86     
 L  R87     
 L  R88     
 L  R89     
 L  R90     
 L  R91     
 L  R92     
 L  R93     
 L  R94     
 L  R95     
 L  R96     
 L  R97     
 L  R98     
 L  R99     
 L  R100    
 L  R101    
 L  R102    
 L  R103    
 L  R104    
 L  R105    
 L  R106    
 L  R107    
 L  R108    
 L  R109    
 L  R110    
 L  R111    
 L  R112    
 L  R113    
 L  R114    
 L  R115    
 L  R116    
 L  R117    
 L  R118    
 L  R119    
 L  R120    
 L  R121    
 L  R122    
 L  R123    
 L  R124    
 L  R125    
 L  R126    
 L  R127    
 L  R128    
 L  R129    
 L  R130    
 L  R131    
 L  R132    
 L  R133    
 L  R134    
 L  R135    
 L  R136    
 L  R137    
 L  R138    
 L  R139    
 L  R140    
 L  R141    
 L  R142    
 L  R143    
 L  R144    
 L  R145    
 L  R146    
 L  R147    
 L  R148    
 L  R149    
 L  R150    
 L  R151    
 L  R152    
 L  R153    
 L  R154    
 L  R155    
 L  R156    
 L  R157    
 L  R158    
 L  R159    
 L  R160    
 L  R161    
 L  R162    
 L  R163    
 L  R164    
 L  R165    
 L  R166    
 L  R167    
 L  R168    
 L  R169    
 L  R170    
 L  R171    
 L  R172    
 L  R173    
 L  R174    
 L  R175    
 L  R176    
 L  R177    
 L  R178    
 L  R179    
 L  R180    
 L  R181    
 L  R182    
 L  R183    
 L  R184    
 L  R185    
 L  R186    
 L  R187    
 L  R188    
 L  R189    
 L  R190    
 L  R191    
 L  R192    
 L  R193    
 L  R194    
 L  R195    
 L  R196    
 L  R197    
 L  R198    
 L  R199    
 L  R200    
 L  R201    
 L  R202    
 L  R203    
 L  R204    
 L  R205    
 L  R206    
 L  R207    
 L  R208    
 L  R209    
 L  R210    
 L  R211    
 L  R212    
 L  R213    
 L  R214    
 L  R215    
 L  R216    
 L  R217    
 L  R218    
 L  R219    
 L  R220    
 L  R221    
 L  R222    
 L  R223    
 L  R224    
 L  R225    
 L  R226    
 L  R227    
 L  R228    
 L  R229    
 L  R230    
 L  R231    
 L  R232    
 L  R233    
 L  R234    
 L  R235    
 L  R236    
 L  R237    
 L  R238    
 L  R239    
 L  R240    
 L  R241    
 L  R242    
 L  R243    
 L  R244    
 L  R245    
 L  R246    
 L  R247    
 L  R248    
 L  R249    
 L  R250    
 L  R251    
 L  R252    
 L  R253    
 L  R254    
 L  R255    
 L  R256    
 L  R257    
 L  R258    
 L  R259    
 L  R260    
 L  R261    
 L  R262    
 L  R263    
 L  R264    
 L  R265    
 L  R266    
 L  R267    
 L  R268    
 L  R269    
 L  R270    
 L  R271    
 L  R272    
 L  R273    
 L  R274    
 L  R275    
 L  R276    
 L  R277    
 L  R278    
 L  R279    
 L  R280    
 L  R281    
 L  R282    
 L  R283    
 L  R284    
 L  R285    
 L  R286    
 L  R287    
 L  R288    
 L  R289    
 L  R290    
 L  R291    
 L  R292    
 L  R293    
 L  R294    
 L  R295    
 L  R296    
 L  R297    
 L  R298    
 L  R299    
 L  R300    
 L  R301    
 L  R302    
 L  R303    
 L  R304    
 L  R305    
 L  R306    
 L  R307    
 L  R308    
 L  R309    
 L  R310    
 L  R311    
 L  R312    
 L  R313    
 L  R314    
 L  R315    
 L  R316    
 L  R317    
 L  R318    
 L  R319    
 L  R320    
 L  R321    
 L  R322    
 L  R323    
 L  R324    
 L  R325    
 L  R326    
 L  R327    
 L  R328    
 L  R329    
 L  R330    
 L  R331    
 L  R332    
 L  R333    
 L  R334    
 L  R335    
 L  R336    
 L  R337    
 L  R338    
 L  R339    
 L  R340    
 L  R341    
 L  R342    
 L  R343    
 L  R344    
 L  R345    
 L  R346    
 L  R347    
 L  R348    
 L  R349    
 L  R350    
 L  R351    
 L  R352    
 L  R353    
 L  R354    
 L  R355    
 L  R356    
 L  R357    
 L  R358    
 L  R359    
 L  R360    
 L  R361    
 L  R362    
 L  R363    
 L  R364    
 L  R365    
 L  R366    
 L  R367    
 L  R368    
 L  R369    
 L  R370    
 L  R371    
 L  R372    
 L  R373    
 L  R374    
 L  R375    
 L  R376    
 L  R377    
 L  R378    
 L  R379    
 L  R380    
 L  R381    
 L  R382    
 L  R383    
 L  R384    
 L  R385    
 L  R386    
 L  R387    
 L  R388    
 L  R389    
 L  R390    
 L  R391    
 L  R392    
 L  R393    
 L  R394    
 L  R395    
 L  R396    
 L  R397    
 L  R398    
 L  R399    
 L  R400    
 L  R401    
 L  R402    
 L  R403    
 L  R404    
 L  R405    
 L  R406    
 L  R407    
 L  R408    
 L  R409    
 L  R410    
 L  R411    
 L  R412    
 L  R413    
 L  R414    
 L  R415    
 L  R416    
 L  R417    
 L  R418    
 L  R419    
 L  R420    
 L  R421    
 L  R422    
 L  R423    
 L  R424    
 L  R425    
 L  R426    
 L  R427    
 L  R428    
 L  R429    
 L  R430    
 L  R431    
 L  R432    
 L  R433    
 L  R434    
 L  R435    
 L  R436    
 L  R437    
 L  R438    
 L  R439    
 L  R440    
 L  R441    
 L  R442    
 L  R443    
 L  R444    
 L  R445    
 L  R446    
 L  R447    
 L  R448    
 L  R449    
 L  R450    
 L  R451    
 L  R452    
 L  R453    
 L  R454    
 L  R455    
 L  R456    
 L  R457    
 L  R458    
 L  R459    
 L  R460    
 L  R461    
 L  R462    
 L  R463    
 L  R464    
 L  R465    
 L  R466    
 L  R467    
 L  R468    
 L  R469    
 L  R470    
 L  R471    
 L  R472    
 L  R473    
 L  R474    
 L  R475    
 L  R476    
 L  R477    
 L  R478    
 L  R479    
 L  R480    
 L  R481    
 L  R482    
 L  R483    
 L  R484    
 L  R485    
 L  R486    
 L  R487    
 L  R488    
 L  R489    
 L  R490    
 L  R491    
 L  R492    
 L  R493    
 L  R494    
 L  R495    
 L  R496    
 L  R497    
 L  R498    
 L  R499    
 L  R500    
 L  R501    
 L  R502    
 L  R503    
 L  R504    
 L  R505    
 L  R506    
 L  R507    
 L  R508    
 L  R509    
 L  R510    
 L  R511    
 L  R512    
 L  R513    
 L  R514    
 L  R515    
 L  R516    
 L  R517    
 L  R518    
 L  R519    
 L  R520    
 L  R521    
 L  R522    
 L  R523    
 L  R524    
 L  R525    
 L  R526    
 L  R527    
 L  R528    
 L  R529    
 L  R530    
 L  R531    
 L  R532    
 L  R533    
 L  R534    
 L  R535    
 L  R536    
 L  R537    
 L  R538    
 L  R539    
 L  R540    
 L  R541    
 L  R542    
 L  R543    
 L  R544    
 L  R545    
 L  R546    
 L  R547    
 L  R548    
 L  R549    
 L  R550    
 L  R551    
 L  R552    
 L  R553    
 L  R554    
 L  R555    
 L  R556    
 L  R557    
 L  R558    
 L  R559    
 L  R560    
 L  R561    
 L  R562    
 L  R563    
 L  R564    
 L  R565    
 L  R566    
 L  R567    
 L  R568    
 L  R569    
 L  R570    
 L  R571    
 L  R572    
 L  R573    
 L  R574    
 L  R575    
 L  R576    
 L  R577    
 L  R578    
 L  R579    
 L  R580    
 L  R581    
 L  R582    
 L  R583    
 L  R584    
 L  R585    
 L  R586    
 L  R587    
 L  R588    
 L  R589    
 L  R590    
 L  R591    
 L  R592    
 L  R593    
 L  R594    
 L  R595    
 L  R596    
 L  R597    
 L  R598    
 L  R599    
 L  R600    
 L  R601    
 L  R602    
 L  R603    
 L  R604    
 L  R605    
 L  R606    
 L  R607    
 L  R608    
 L  R609    
 L  R610    
 L  R611    
 L  R612    
 L  R613    
 L  R614    
 L  R615    
 L  R616    
 L  R617    
 L  R618    
 L  R619    
 L  R620    
 L  R621    
 L  R622    
 L  R623    
 L  R624    
 L  R625    
 L  R626    
 L  R627    
 L  R628    
 L  R629    
 L  R630    
 L  R631    
 L  R632    
 L  R633    
 L  R634    
 L  R635    
 L  R636    
 L  R637    
 L  R638    
 L  R639    
 L  R640    
 L  R641    
 L  R642    
 L  R643    
 L  R644    
 L  R645    
 L  R646    
 L  R647    
 L  R648    
 L  R649    
 L  R650    
 L  R651    
 L  R652    
 L  R653    
 L  R654    
 L  R655    
 L  R656    
 L  R657    
 L  R658    
 L  R659    
 L  R660    
 L  R661    
 L  R662    
 L  R663    
 L  R664    
 L  R665    
 L  R666    
 L  R667    
 L  R668    
 L  R669    
 L  R670    
 L  R671    
 L  R672    
 L  R673    
 L  R674    
 L  R675    
 L  R676    
 L  R677    
 L  R678    
 L  R679    
 L  R680    
 L  R681    
 L  R682    
 L  R683    
 L  R684    
 L  R685    
 L  R686    
 L  R687    
 L  R688    
 L  R689    
 L  R690    
 L  R691    
 L  R692    
 L  R693    
 L  R694    
 L  R695    
 L  R696    
 L  R697    
 L  R698    
 L  R699    
 L  R700    
 L  R701    
 L  R702    
 L  R703    
 L  R704    
 L  R705    
 L  R706    
 L  R707    
 L  R708    
 L  R709    
 L  R710    
 L  R711    
 L  R712    
 L  R713    
 L  R714    
 L  R715    
 L  R716    
 L  R717    
 L  R718    
 L  R719    
 L  R720    
 L  R721    
 L  R722    
 L  R723    
 L  R724    
 L  R725    
 L  R726    
 L  R727    
 L  R728    
 L  R729    
 L  R730    
 L  R731    
 L  R732    
 L  R733    
 L  R734    
 L  R735    
 L  R736    
 L  R737    
 L  R738    
 L  R739    
 L  R740    
 L  R741    
 L  R742    
 L  R743    
 L  R744    
 L  R745    
 L  R746    
 L  R747    
 L  R748    
 L  R749    
 L  R750    
 L  R751    
 L  R752    
 L  R753    
 L  R754    
 L  R755    
 L  R756    
 L  R757    
 L  R758    
 L  R759    
 L  R760    
 L  R761    
 L  R762    
 L  R763    
 L  R764    
 L  R765    
 L  R766    
 L  R767    
 L  R768    
 L  R769    
 L  R770    
 L  R771    
 L  R772    
 L  R773    
 L  R774    
 L  R775    
 L  R776    
 L  R777    
 L  R778    
 L  R779    
 L  R780    
 L  R781    
 L  R782    
 L  R783    
 L  R784    
 L  R785    
 L  R786    
 L  R787    
 L  R788    
 L  R789    
 L  R790    
 L  R791    
 L  R792    
 L  R793    
 L  R794    
 L  R795    
 L  R796    
 L  R797    
 L  R798    
 L  R799    
 L  R800    
 L  R801    
 L  R802    
 L  R803    
 L  R804    
 L  R805    
 L  R806    
 L  R807    
 L  R808    
 L  R809    
 L  R810    
 L  R811    
 L  R812    
 L  R813    
 L  R814    
 L  R815    
 L  R816    
 L  R817    
 L  R818    
 L  R819    
 L  R820    
 L  R821    
 L  R822    
 L  R823    
 L  R824    
 L  R825    
 L  R826    
 L  R827    
 L  R828    
 L  R829    
 L  R830    
 L  R831    
 L  R832    
 L  R833    
 L  R834    
 L  R835    
 L  R836    
 L  R837    
 L  R838    
 L  R839    
 L  R840    
 L  R841    
 L  R842    
 L  R843    
 L  R844    
 L  R845    
 L  R846    
 L  R847    
 L  R848    
 L  R849    
 L  R850    
 L  R851    
 L  R852    
 L  R853    
 L  R854    
 L  R855    
 L  R856    
 L  R857    
 L  R858    
 L  R859    
 L  R860    
 L  R861    
 L  R862    
 L  R863    
 L  R864    
 L  R865    
 L  R866    
 L  R867    
 L  R868    
 L  R869    
 L  R870    
 L  R871    
 L  R872    
 L  R873    
 L  R874    
 L  R875    
 L  R876    
 L  R877    
 L  R878    
 L  R879    
 L  R880    
 L  R881    
 L  R882    
 L  R883    
 L  R884    
 L  R885    
 L  R886    
 L  R887    
 L  R888    
 L  R889    
 L  R890    
 L  R891    
 L  R892    
 L  R893    
 L  R894    
 L  R895    
 L  R896    
 L  R897    
 L  R898    
 L  R899    
 L  R900    
 L  R901    
 L  R902    
 L  R903    
 L  R904    
 L  R905    
 L  R906    
 L  R907    
 L  R908    
 L  R909    
 L  R910    
 L  R911    
 L  R912    
 L  R913    
 L  R914    
 L  R915    
 L  R916    
 L  R917    
 L  R918    
 L  R919    
 L  R920    
 L  R921    
 L  R922    
 L  R923    
 L  R924    
 L  R925    
 L  R926    
 L  R927    
 L  R928    
 L  R929    
 L  R930    
 L  R931    
 L  R932    
 L  R933    
 L  R934    
 L  R935    
 L  R936    
 L  R937    
 L  R938    
 L  R939    
 L  R940    
 L  R941    
 L  R942    
 L  R943    
 L  R944    
 L  R945    
 L  R946    
 L  R947    
 L  R948    
 L  R949    
 L  R950    
 L  R951    
 L  R952    
 L  R953    
 L  R954    
 L  R955    
 L  R956    
 L  R957    
 L  R958    
 L  R959    
 L  R960    
 L  R961    
 L  R962    
 L  R963    
 L  R964    
 L  R965    
 L  R966    
 L  R967    
 L  R968    
 L  R969    
 L  R970    
 L  R971    
 L  R972    
 L  R973    
 L  R974    
 L  R975    
 L  R976    
 L  R977    
 L  R978    
 L  R979    
 L  R980    
 L  R981    
 L  R982    
 L  R983    
 L  R984    
 L  R985    
 L  R986    
 L  R987    
 L  R988    
 L  R989    
 L  R990    
 L  R991    
 L  R992    
 L  R993    
 L  R994    
 L  R995    
 L  R996    
 L  R997    
 L  R998    
 L  R999    
 L  R1000   
 L  R1001   
 L  R1002   
 L  R1003   
 L  R1004   
 L  R1005   
 L  R1006   
 L  R1007   
 L  R1008   
 L  R1009   
 L  R1010   
 L  R1011   
 L  R1012   
 L  R1013   
 L  R1014   
 L  R1015   
 L  R1016   
 L  R1017   
 L  R1018   
 L  R1019   
 L  R1020   
 L  R1021   
 L  R1022   
 L  R1023   
 L  R1024   
 L  R1025   
 L  R1026   
 L  R1027   
 L  R1028   
 L  R1029   
 L  R1030   
 L  R1031   
 L  R1032   
 L  R1033   
 L  R1034   
 L  R1035   
 L  R1036   
 L  R1037   
 L  R1038   
 L  R1039   
 L  R1040   
 L  R1041   
 L  R1042   
 L  R1043   
 L  R1044   
 L  R1045   
 L  R1046   
 L  R1047   
 L  R1048   
 L  R1049   
 L  R1050   
 L  R1051   
 L  R1052   
 L  R1053   
 L  R1054   
 L  R1055   
 L  R1056   
 L  R1057   
 L  R1058   
 L  R1059   
 L  R1060   
 L  R1061   
 L  R1062   
 L  R1063   
 L  R1064   
 L  R1065   
 L  R1066   
 L  R1067   
 L  R1068   
 L  R1069   
 L  R1070   
 L  R1071   
 L  R1072   
 L  R1073   
 L  R1074   
 L  R1075   
 L  R1076   
 L  R1077   
 L  R1078   
 L  R1079   
 L  R1080   
 L  R1081   
 L  R1082   
 L  R1083   
 L  R1084   
 L  R1085   
 L  R1086   
 L  R1087   
 L  R1088   
 L  R1089   
 L  R1090   
 L  R1091   
 L  R1092   
 L  R1093   
 L  R1094   
 L  R1095   
 L  R1096   
 L  R1097   
 L  R1098   
 L  R1099   
 L  R1100   
 L  R1101   
 L  R1102   
 L  R1103   
 L  R1104   
 L  R1105   
 L  R1106   
 L  R1107   
 L  R1108   
 L  R1109   
 L  R1110   
 L  R1111   
 L  R1112   
 L  R1113   
 L  R1114   
 L  R1115   
 L  R1116   
 L  R1117   
 L  R1118   
 L  R1119   
 L  R1120   
 L  R1121   
 L  R1122   
 L  R1123   
 L  R1124   
 L  R1125   
 L  R1126   
 L  R1127   
 L  R1128   
 L  R1129   
 L  R1130   
 L  R1131   
 L  R1132   
 L  R1133   
 L  R1134   
 L  R1135   
 L  R1136   
 L  R1137   
 L  R1138   
 L  R1139   
 L  R1140   
 L  R1141   
 L  R1142   
 L  R1143   
 L  R1144   
 L  R1145   
 L  R1146   
 L  R1147   
 L  R1148   
 L  R1149   
 L  R1150   
 L  R1151   
 L  R1152   
 L  R1153   
 L  R1154   
 L  R1155   
 L  R1156   
 L  R1157   
 L  R1158   
 L  R1159   
 L  R1160   
 L  R1161   
 L  R1162   
 L  R1163   
 L  R1164   
 L  R1165   
 L  R1166   
 L  R1167   
 L  R1168   
 L  R1169   
 L  R1170   
 L  R1171   
 L  R1172   
 L  R1173   
 L  R1174   
 L  R1175   
 L  R1176   
 L  R1177   
 L  R1178   
 L  R1179   
 L  R1180   
 L  R1181   
 L  R1182   
 L  R1183   
 L  R1184   
 L  R1185   
 L  R1186   
 L  R1187   
 L  R1188   
 L  R1189   
 L  R1190   
 L  R1191   
 L  R1192   
 L  R1193   
 L  R1194   
 L  R1195   
 L  R1196   
 L  R1197   
 L  R1198   
 L  R1199   
 L  R1200   
 L  R1201   
 L  R1202   
 L  R1203   
 L  R1204   
 L  R1205   
 L  R1206   
 L  R1207   
 L  R1208   
 L  R1209   
 L  R1210   
 L  R1211   
 L  R1212   
 L  R1213   
 L  R1214   
 L  R1215   
 L  R1216   
 L  R1217   
 L  R1218   
 L  R1219   
 L  R1220   
 L  R1221   
 L  R1222   
 L  R1223   
 L  R1224   
 L  R1225   
 L  R1226   
 L  R1227   
 L  R1228   
 L  R1229   
 L  R1230   
 L  R1231   
 L  R1232   
 L  R1233   
 L  R1234   
 L  R1235   
 L  R1236   
 L  R1237   
 L  R1238   
 L  R1239   
 L  R1240   
 L  R1241   
 L  R1242   
 L  R1243   
 L  R1244   
 L  R1245   
 L  R1246   
 L  R1247   
 L  R1248   
 L  R1249   
 L  R1250   
 L  R1251   
 L  R1252   
 L  R1253   
 L  R1254   
 L  R1255   
 L  R1256   
 L  R1257   
 L  R1258   
 L  R1259   
 L  R1260   
 L  R1261   
 L  R1262   
 L  R1263   
 L  R1264   
 L  R1265   
 L  R1266   
 L  R1267   
 L  R1268   
 L  R1269   
 L  R1270   
 L  R1271   
 L  R1272   
 L  R1273   
 L  R1274   
 L  R1275   
 L  R1276   
 L  R1277   
 L  R1278   
 L  R1279   
 L  R1280   
 L  R1281   
 L  R1282   
 L  R1283   
 L  R1284   
 L  R1285   
 L  R1286   
 L  R1287   
 L  R1288   
 L  R1289   
 L  R1290   
 L  R1291   
 L  R1292   
 L  R1293   
 L  R1294   
 L  R1295   
 L  R1296   
 L  R1297   
 L  R1298   
 L  R1299   
 L  R1300   
 L  R1301   
 L  R1302   
 L  R1303   
 L  R1304   
 L  R1305   
 L  R1306   
 L  R1307   
 L  R1308   
 L  R1309   
 L  R1310   
 L  R1311   
 L  R1312   
 L  R1313   
 L  R1314   
 L  R1315   
 L  R1316   
 L  R1317   
 L  R1318   
 L  R1319   
 L  R1320   
 L  R1321   
 L  R1322   
 L  R1323   
 L  R1324   
 L  R1325   
 L  R1326   
 L  R1327   
 L  R1328   
 L  R1329   
 L  R1330   
 L  R1331   
 L  R1332   
 L  R1333   
 L  R1334   
 L  R1335   
 L  R1336   
 L  R1337   
 L  R1338   
 L  R1339   
 L  R1340   
 L  R1341   
 L  R1342   
 L  R1343   
 L  R1344   
 L  R1345   
 L  R1346   
 L  R1347   
 L  R1348   
 L  R1349   
 L  R1350   
 L  R1351   
 L  R1352   
 L  R1353   
 L  R1354   
 L  R1355   
 L  R1356   
 L  R1357   
 L  R1358   
 L  R1359   
 L  R1360   
 L  R1361   
 L  R1362   
 L  R1363   
 L  R1364   
 L  R1365   
 L  R1366   
 L  R1367   
 L  R1368   
 L  R1369   
 L  R1370   
 L  R1371   
 L  R1372   
 L  R1373   
 L  R1374   
 L  R1375   
 L  R1376   
 L  R1377   
 L  R1378   
 L  R1379   
 L  R1380   
 L  R1381   
 L  R1382   
 L  R1383   
 L  R1384   
 L  R1385   
 L  R1386   
 L  R1387   
 L  R1388   
 L  R1389   
 L  R1390   
 L  R1391   
 L  R1392   
 L  R1393   
 L  R1394   
 L  R1395   
 L  R1396   
 L  R1397   
 L  R1398   
 L  R1399   
 L  R1400   
 L  R1401   
 L  R1402   
 L  R1403   
 L  R1404   
 L  R1405   
 L  R1406   
 L  R1407   
 L  R1408   
 L  R1409   
 L  R1410   
 L  R1411   
 L  R1412   
 L  R1413   
 L  R1414   
 L  R1415   
 L  R1416   
 L  R1417   
 L  R1418   
 L  R1419   
 L  R1420   
 L  R1421   
 L  R1422   
 L  R1423   
 L  R1424   
 L  R1425   
 L  R1426   
 L  R1427   
 L  R1428   
 L  R1429   
 L  R1430   
 L  R1431   
 L  R1432   
 L  R1433   
 L  R1434   
 L  R1435   
 L  R1436   
 L  R1437   
 L  R1438   
 L  R1439   
 L  R1440   
 L  R1441   
 L  R1442   
 L  R1443   
 L  R1444   
 L  R1445   
 L  R1446   
 L  R1447   
 L  R1448   
 L  R1449   
 L  R1450   
 L  R1451   
 L  R1452   
 L  R1453   
 L  R1454   
 L  R1455   
 L  R1456   
 L  R1457   
 L  R1458   
 L  R1459   
 L  R1460   
 L  R1461   
 L  R1462   
 L  R1463   
 L  R1464   
 L  R1465   
 L  R1466   
 L  R1467   
 L  R1468   
 L  R1469   
 L  R1470   
 L  R1471   
 L  R1472   
 L  R1473   
 L  R1474   
 L  R1475   
 L  R1476   
 L  R1477   
 L  R1478   
 L  R1479   
 L  R1480   
 L  R1481   
 L  R1482   
 L  R1483   
 L  R1484   
 L  R1485   
 L  R1486   
 L  R1487   
 L  R1488   
 L  R1489   
 L  R1490   
 L  R1491   
 L  R1492   
 L  R1493   
 L  R1494   
 L  R1495   
 L  R1496   
 L  R1497   
 L  R1498   
 L  R1499   
 L  R1500   
 L  R1501   
 L  R1502   
 L  R1503   
 L  R1504   
 L  R1505   
 L  R1506   
 L  R1507   
 L  R1508   
 L  R1509   
 L  R1510   
 L  R1511   
 L  R1512   
 L  R1513   
 L  R1514   
 L  R1515   
 L  R1516   
 L  R1517   
 L  R1518   
 L  R1519   
 L  R1520   
 L  R1521   
 L  R1522   
 L  R1523   
 L  R1524   
 L  R1525   
 L  R1526   
 L  R1527   
 L  R1528   
 L  R1529   
 L  R1530   
 L  R1531   
 L  R1532   
 L  R1533   
 L  R1534   
 L  R1535   
 L  R1536   
 L  R1537   
 L  R1538   
 L  R1539   
 L  R1540   
 L  R1541   
 L  R1542   
 L  R1543   
 L  R1544   
 L  R1545   
 L  R1546   
 L  R1547   
 L  R1548   
 L  R1549   
 L  R1550   
 L  R1551   
 L  R1552   
 L  R1553   
 L  R1554   
 L  R1555   
 L  R1556   
 L  R1557   
 L  R1558   
 L  R1559   
 L  R1560   
 L  R1561   
 L  R1562   
 L  R1563   
 L  R1564   
 L  R1565   
 L  R1566   
 L  R1567   
 L  R1568   
 L  R1569   
 L  R1570   
 L  R1571   
 L  R1572   
 L  R1573   
 L  R1574   
 L  R1575   
 L  R1576   
 L  R1577   
 L  R1578   
 L  R1579   
 L  R1580   
 L  R1581   
 L  R1582   
 L  R1583   
 L  R1584   
 L  R1585   
 L  R1586   
 L  R1587   
 L  R1588   
 L  R1589   
 L  R1590   
 L  R1591   
 L  R1592   
 L  R1593   
 L  R1594   
 L  R1595   
 L  R1596   
 L  R1597   
 L  R1598   
 L  R1599   
 L  R1600   
 L  R1601   
 L  R1602   
 L  R1603   
 L  R1604   
 L  R1605   
 L  R1606   
 L  R1607   
 L  R1608   
 L  R1609   
 L  R1610   
 L  R1611   
 L  R1612   
 L  R1613   
 L  R1614   
 L  R1615   
 L  R1616   
 L  R1617   
 L  R1618   
 L  R1619   
 L  R1620   
 L  R1621   
 L  R1622   
 L  R1623   
 L  R1624   
 L  R1625   
 L  R1626   
 L  R1627   
 L  R1628   
 L  R1629   
 L  R1630   
 L  R1631   
 L  R1632   
 L  R1633   
 L  R1634   
 L  R1635   
 L  R1636   
 L  R1637   
 L  R1638   
 L  R1639   
 L  R1640   
 L  R1641   
 L  R1642   
 L  R1643   
 L  R1644   
 L  R1645   
 L  R1646   
 L  R1647   
 L  R1648   
 L  R1649   
 L  R1650   
 L  R1651   
 L  R1652   
 L  R1653   
 L  R1654   
 L  R1655   
 L  R1656   
 L  R1657   
 L  R1658   
 L  R1659   
 L  R1660   
 L  R1661   
 L  R1662   
 L  R1663   
 L  R1664   
 L  R1665   
 L  R1666   
 L  R1667   
 L  R1668   
 L  R1669   
 L  R1670   
 L  R1671   
 L  R1672   
 L  R1673   
 L  R1674   
 L  R1675   
 L  R1676   
 L  R1677   
 L  R1678   
 L  R1679   
 L  R1680   
 L  R1681   
 L  R1682   
 L  R1683   
 L  R1684   
 L  R1685   
 L  R1686   
 L  R1687   
 L  R1688   
 L  R1689   
 L  R1690   
 L  R1691   
 L  R1692   
 L  R1693   
 L  R1694   
 L  R1695   
 L  R1696   
 L  R1697   
 L  R1698   
 L  R1699   
 L  R1700   
 L  R1701   
 L  R1702   
 L  R1703   
 L  R1704   
 L  R1705   
 L  R1706   
 L  R1707   
 L  R1708   
 L  R1709   
 L  R1710   
 L  R1711   
 L  R1712   
 L  R1713   
 L  R1714   
 L  R1715   
 L  R1716   
 L  R1717   
 L  R1718   
 L  R1719   
 L  R1720   
 L  R1721   
 L  R1722   
 L  R1723   
 L  R1724   
 L  R1725   
 L  R1726   
 L  R1727   
 L  R1728   
 L  R1729   
 L  R1730   
 L  R1731   
 L  R1732   
 L  R1733   
 L  R1734   
 L  R1735   
 L  R1736   
 L  R1737   
 L  R1738   
 L  R1739   
 L  R1740   
 L  R1741   
 L  R1742   
 L  R1743   
 L  R1744   
 L  R1745   
 L  R1746   
 L  R1747   
 L  R1748   
 L  R1749   
 L  R1750   
 L  R1751   
 L  R1752   
 L  R1753   
 L  R1754   
 L  R1755   
 L  R1756   
 L  R1757   
 L  R1758   
 L  R1759   
 L  R1760   
 L  R1761   
 L  R1762   
 L  R1763   
 L  R1764   
 L  R1765   
 L  R1766   
 L  R1767   
 L  R1768   
 L  R1769   
 L  R1770   
 L  R1771   
 L  R1772   
 L  R1773   
 L  R1774   
 L  R1775   
 L  R1776   
 L  R1777   
 L  R1778   
 L  R1779   
 L  R1780   
 L  R1781   
 L  R1782   
 L  R1783   
 L  R1784   
 L  R1785   
 L  R1786   
 L  R1787   
 L  R1788   
 L  R1789   
 L  R1790   
 L  R1791   
 L  R1792   
 L  R1793   
 L  R1794   
 L  R1795   
 L  R1796   
 L  R1797   
 L  R1798   
 L  R1799   
 L  R1800   
 L  R1801   
 L  R1802   
 L  R1803   
 L  R1804   
 L  R1805   
 L  R1806   
 L  R1807   
 L  R1808   
 L  R1809   
 L  R1810   
 L  R1811   
 L  R1812   
 L  R1813   
 L  R1814   
 L  R1815   
 L  R1816   
 L  R1817   
 L  R1818   
 L  R1819   
 L  R1820   
 L  R1821   
 L  R1822   
 L  R1823   
 L  R1824   
 L  R1825   
 L  R1826   
 L  R1827   
 L  R1828   
 L  R1829   
 L  R1830   
 L  R1831   
 L  R1832   
 L  R1833   
 L  R1834   
 L  R1835   
 L  R1836   
 L  R1837   
 L  R1838   
 L  R1839   
 L  R1840   
 L  R1841   
 L  R1842   
 L  R1843   
 L  R1844   
 L  R1845   
 L  R1846   
 L  R1847   
 L  R1848   
 L  R1849   
 L  R1850   
 L  R1851   
 L  R1852   
 L  R1853   
 L  R1854   
 L  R1855   
 L  R1856   
 L  R1857   
 L  R1858   
 L  R1859   
 L  R1860   
 L  R1861   
 L  R1862   
 L  R1863   
 L  R1864   
 L  R1865   
 L  R1866   
 L  R1867   
 L  R1868   
 L  R1869   
 L  R1870   
 L  R1871   
 L  R1872   
 L  R1873   
 L  R1874   
 L  R1875   
 L  R1876   
 L  R1877   
 L  R1878   
 L  R1879   
 L  R1880   
 L  R1881   
 L  R1882   
 L  R1883   
 L  R1884   
 L  R1885   
 L  R1886   
 L  R1887   
 L  R1888   
 L  R1889   
 L  R1890   
 L  R1891   
 L  R1892   
 L  R1893   
 L  R1894   
 L  R1895   
 L  R1896   
 L  R1897   
 L  R1898   
 L  R1899   
 L  R1900   
 L  R1901   
 L  R1902   
 L  R1903   
 L  R1904   
 L  R1905   
 L  R1906   
 L  R1907   
 L  R1908   
 L  R1909   
 L  R1910   
 L  R1911   
 L  R1912   
 L  R1913   
 L  R1914   
 L  R1915   
 L  R1916   
 L  R1917   
 L  R1918   
 L  R1919   
 L  R1920   
 L  R1921   
 L  R1922   
 L  R1923   
 L  R1924   
 L  R1925   
 L  R1926   
 L  R1927   
 L  R1928   
 L  R1929   
 L  R1930   
 L  R1931   
 L  R1932   
 L  R1933   
 L  R1934   
 L  R1935   
 L  R1936   
 L  R1937   
 L  R1938   
 L  R1939   
 L  R1940   
 L  R1941   
 L  R1942   
 L  R1943   
 L  R1944   
 L  R1945   
 L  R1946   
 L  R1947   
 L  R1948   
 L  R1949   
 L  R1950   
 L  R1951   
 L  R1952   
 L  R1953   
 L  R1954   
 L  R1955   
 L  R1956   
 L  R1957   
 L  R1958   
 L  R1959   
 L  R1960   
 L  R1961   
 L  R1962   
 L  R1963   
 L  R1964   
 L  R1965   
 L  R1966   
 L  R1967   
 L  R1968   
 L  R1969   
 L  R1970   
 L  R1971   
 L  R1972   
 L  R1973   
 L  R1974   
 L  R1975   
 L  R1976   
 L  R1977   
 L  R1978   
 L  R1979   
 L  R1980   
 L  R1981   
 L  R1982   
 L  R1983   
 L  R1984   
 L  R1985   
 L  R1986   
 L  R1987   
 L  R1988   
 L  R1989   
 L  R1990   
 L  R1991   
 L  R1992   
 L  R1993   
 L  R1994   
 L  R1995   
 L  R1996   
 L  R1997   
 L  R1998   
 L  R1999   
 L  R2000   
 L  R2001   
 L  R2002   
 L  R2003   
 L  R2004   
 L  R2005   
 L  R2006   
 L  R2007   
 L  R2008   
 L  R2009   
 L  R2010   
 L  R2011   
 L  R2012   
 L  R2013   
 L  R2014   
 L  R2015   
 L  R2016   
 L  R2017   
 L  R2018   
 L  R2019   
 L  R2020   
 L  R2021   
 L  R2022   
 L  R2023   
 L  R2024   
 L  R2025   
 L  R2026   
 L  R2027   
 L  R2028   
 L  R2029   
 L  R2030   
 L  R2031   
 L  R2032   
 L  R2033   
 L  R2034   
 L  R2035   
 L  R2036   
 L  R2037   
 L  R2038   
 L  R2039   
 L  R2040   
 L  R2041   
 L  R2042   
 L  R2043   
 L  R2044   
 L  R2045   
 L  R2046   
 L  R2047   
 L  R2048   
 L  R2049   
 L  R2050   
 L  R2051   
 L  R2052   
 L  R2053   
 L  R2054   
 L  R2055   
 L  R2056   
 L  R2057   
 L  R2058   
 L  R2059   
 L  R2060   
 L  R2061   
 L  R2062   
 L  R2063   
 L  R2064   
 L  R2065   
 L  R2066   
 L  R2067   
 L  R2068   
 L  R2069   
 L  R2070   
 L  R2071   
 L  R2072   
 L  R2073   
 L  R2074   
 L  R2075   
 L  R2076   
 L  R2077   
 L  R2078   
 L  R2079   
 L  R2080   
 L  R2081   
 L  R2082   
 L  R2083   
 L  R2084   
 L  R2085   
 L  R2086   
 L  R2087   
 L  R2088   
 L  R2089   
 L  R2090   
 L  R2091   
 L  R2092   
 L  R2093   
 L  R2094   
 L  R2095   
 L  R2096   
 L  R2097   
 L  R2098   
 L  R2099   
 L  R2100   
 L  R2101   
 L  R2102   
 L  R2103   
 L  R2104   
 L  R2105   
 L  R2106   
 L  R2107   
 L  R2108   
 L  R2109   
 L  R2110   
 L  R2111   
 L  R2112   
 L  R2113   
 L  R2114   
 L  R2115   
 L  R2116   
 L  R2117   
 L  R2118   
 L  R2119   
 L  R2120   
 L  R2121   
 L  R2122   
 L  R2123   
 L  R2124   
 L  R2125   
 L  R2126   
 L  R2127   
 L  R2128   
 L  R2129   
 L  R2130   
 L  R2131   
 L  R2132   
 L  R2133   
 L  R2134   
 L  R2135   
 L  R2136   
 L  R2137   
 L  R2138   
 L  R2139   
 L  R2140   
 L  R2141   
 L  R2142   
 L  R2143   
 L  R2144   
 L  R2145   
 L  R2146   
 L  R2147   
 L  R2148   
 L  R2149   
 L  R2150   
 L  R2151   
 L  R2152   
 L  R2153   
 L  R2154   
 L  R2155   
 L  R2156   
 L  R2157   
 L  R2158   
 L  R2159   
 L  R2160   
 L  R2161   
 L  R2162   
 L  R2163   
 L  R2164   
 L  R2165   
 L  R2166   
 L  R2167   
 L  R2168   
 L  R2169   
 L  R2170   
 L  R2171   
 L  R2172   
 L  R2173   
 L  R2174   
 L  R2175   
 L  R2176   
 L  R2177   
 L  R2178   
 L  R2179   
 L  R2180   
 L  R2181   
 L  R2182   
 L  R2183   
 L  R2184   
 L  R2185   
 L  R2186   
 L  R2187   
 L  R2188   
 L  R2189   
 L  R2190   
 L  R2191   
 L  R2192   
 L  R2193   
 L  R2194   
 L  R2195   
 L  R2196   
 L  R2197   
 L  R2198   
 L  R2199   
 L  R2200   
 L  R2201   
 L  R2202   
 L  R2203   
 L  R2204   
 L  R2205   
 L  R2206   
 L  R2207   
 L  R2208   
 L  R2209   
 L  R2210   
 L  R2211   
 L  R2212   
 L  R2213   
 L  R2214   
 L  R2215   
 L  R2216   
 L  R2217   
 L  R2218   
 L  R2219   
 L  R2220   
 L  R2221   
 L  R2222   
 L  R2223   
 L  R2224   
 L  R2225   
 L  R2226   
 L  R2227   
 L  R2228   
 L  R2229   
 L  R2230   
 L  R2231   
 L  R2232   
 L  R2233   
 L  R2234   
 L  R2235   
 L  R2236   
 L  R2237   
 L  R2238   
 L  R2239   
 L  R2240   
 L  R2241   
 L  R2242   
 L  R2243   
 L  R2244   
 L  R2245   
 L  R2246   
 L  R2247   
 L  R2248   
 L  R2249   
 L  R2250   
 L  R2251   
 L  R2252   
 L  R2253   
 L  R2254   
 L  R2255   
 L  R2256   
 L  R2257   
 L  R2258   
 L  R2259   
 L  R2260   
 L  R2261   
 L  R2262   
 L  R2263   
 L  R2264   
 L  R2265   
 L  R2266   
 L  R2267   
 L  R2268   
 L  R2269   
 L  R2270   
 L  R2271   
 L  R2272   
 L  R2273   
 L  R2274   
 L  R2275   
 L  R2276   
 L  R2277   
 L  R2278   
 L  R2279   
 L  R2280   
 L  R2281   
 L  R2282   
 L  R2283   
 L  R2284   
 L  R2285   
 L  R2286   
 L  R2287   
 L  R2288   
 L  R2289   
 L  R2290   
 L  R2291   
 L  R2292   
 L  R2293   
 L  R2294   
 L  R2295   
 L  R2296   
 L  R2297   
 L  R2298   
 L  R2299   
 L  R2300   
 L  R2301   
 L  R2302   
 L  R2303   
 L  R2304   
 L  R2305   
 L  R2306   
 L  R2307   
 L  R2308   
 L  R2309   
 L  R2310   
 L  R2311   
 L  R2312   
 L  R2313   
 L  R2314   
 L  R2315   
 L  R2316   
 L  R2317   
 L  R2318   
 L  R2319   
 L  R2320   
 L  R2321   
 L  R2322   
 L  R2323   
 L  R2324   
 L  R2325   
 L  R2326   
 L  R2327   
 L  R2328   
 L  R2329   
 L  R2330   
 L  R2331   
 L  R2332   
 L  R2333   
 L  R2334   
 L  R2335   
 L  R2336   
 L  R2337   
 L  R2338   
 L  R2339   
 L  R2340   
 L  R2341   
 L  R2342   
 L  R2343   
 L  R2344   
 L  R2345   
 L  R2346   
 L  R2347   
 L  R2348   
 L  R2349   
 L  R2350   
 L  R2351   
 L  R2352   
 L  R2353   
 L  R2354   
 L  R2355   
 L  R2356   
 L  R2357   
 L  R2358   
 L  R2359   
 L  R2360   
 L  R2361   
 L  R2362   
 L  R2363   
 L  R2364   
 L  R2365   
 L  R2366   
 L  R2367   
 L  R2368   
 L  R2369   
 L  R2370   
 L  R2371   
 L  R2372   
 L  R2373   
 L  R2374   
 L  R2375   
 L  R2376   
 L  R2377   
 L  R2378   
 L  R2379   
 L  R2380   
 L  R2381   
 L  R2382   
 L  R2383   
 L  R2384   
 L  R2385   
 L  R2386   
 L  R2387   
 L  R2388   
 L  R2389   
 L  R2390   
 L  R2391   
 L  R2392   
 L  R2393   
 L  R2394   
 L  R2395   
 L  R2396   
 L  R2397   
 L  R2398   
 L  R2399   
 L  R2400   
 L  R2401   
 L  R2402   
 L  R2403   
 L  R2404   
 L  R2405   
 L  R2406   
 L  R2407   
 L  R2408   
 L  R2409   
 L  R2410   
 L  R2411   
 L  R2412   
 L  R2413   
 L  R2414   
 L  R2415   
 L  R2416   
 L  R2417   
 L  R2418   
 L  R2419   
 L  R2420   
 L  R2421   
 L  R2422   
 L  R2423   
 L  R2424   
 L  R2425   
 L  R2426   
 L  R2427   
 L  R2428   
 L  R2429   
 L  R2430   
 L  R2431   
 L  R2432   
 L  R2433   
 L  R2434   
 L  R2435   
 L  R2436   
 L  R2437   
 L  R2438   
 L  R2439   
 L  R2440   
 L  R2441   
 L  R2442   
 L  R2443   
 L  R2444   
 L  R2445   
 L  R2446   
 L  R2447   
 L  R2448   
 L  R2449   
 L  R2450   
 L  R2451   
 L  R2452   
 L  R2453   
 L  R2454   
 L  R2455   
 L  R2456   
 L  R2457   
 L  R2458   
 L  R2459   
 L  R2460   
 L  R2461   
 L  R2462   
 L  R2463   
 L  R2464   
 L  R2465   
 L  R2466   
 L  R2467   
 L  R2468   
 L  R2469   
 L  R2470   
 L  R2471   
 L  R2472   
 L  R2473   
 L  R2474   
 L  R2475   
 L  R2476   
 L  R2477   
 L  R2478   
 L  R2479   
 L  R2480   
 L  R2481   
 L  R2482   
 L  R2483   
 L  R2484   
 L  R2485   
 L  R2486   
 L  R2487   
 L  R2488   
 L  R2489   
 L  R2490   
 L  R2491   
 L  R2492   
 L  R2493   
 L  R2494   
 L  R2495   
 L  R2496   
 L  R2497   
 L  R2498   
 L  R2499   
 L  R2500   
 L  R2501   
 L  R2502   
 L  R2503   
 L  R2504   
 L  R2505   
 L  R2506   
 L  R2507   
 L  R2508   
 L  R2509   
 L  R2510   
 L  R2511   
 L  R2512   
 L  R2513   
 L  R2514   
 L  R2515   
 L  R2516   
 L  R2517   
 L  R2518   
 L  R2519   
 L  R2520   
 L  R2521   
 L  R2522   
 L  R2523   
 L  R2524   
 L  R2525   
 L  R2526   
 L  R2527   
 L  R2528   
 L  R2529   
 L  R2530   
 L  R2531   
 L  R2532   
 L  R2533   
 L  R2534   
 L  R2535   
 L  R2536   
 L  R2537   
 L  R2538   
 L  R2539   
 L  R2540   
 L  R2541   
 L  R2542   
 L  R2543   
 L  R2544   
 L  R2545   
 L  R2546   
 L  R2547   
 L  R2548   
 L  R2549   
 L  R2550   
 L  R2551   
 L  R2552   
 L  R2553   
 L  R2554   
 L  R2555   
 L  R2556   
 L  R2557   
 L  R2558   
 L  R2559   
 L  R2560   
 L  R2561   
 L  R2562   
 L  R2563   
 L  R2564   
 L  R2565   
 L  R2566   
 L  R2567   
 L  R2568   
 L  R2569   
 L  R2570   
 L  R2571   
 L  R2572   
 L  R2573   
 L  R2574   
 L  R2575   
 L  R2576   
 L  R2577   
 L  R2578   
 L  R2579   
 L  R2580   
 L  R2581   
 L  R2582   
 L  R2583   
 L  R2584   
 L  R2585   
 L  R2586   
 L  R2587   
 L  R2588   
 L  R2589   
 L  R2590   
 L  R2591   
 L  R2592   
 L  R2593   
 L  R2594   
 L  R2595   
 L  R2596   
 L  R2597   
 L  R2598   
 L  R2599   
 L  R2600   
 L  R2601   
 L  R2602   
 L  R2603   
 L  R2604   
 L  R2605   
 L  R2606   
 L  R2607   
 L  R2608   
 L  R2609   
 L  R2610   
 L  R2611   
 L  R2612   
 L  R2613   
 L  R2614   
 L  R2615   
 L  R2616   
 L  R2617   
 L  R2618   
 L  R2619   
 L  R2620   
 L  R2621   
 L  R2622   
 L  R2623   
 L  R2624   
 L  R2625   
 L  R2626   
 L  R2627   
 L  R2628   
 L  R2629   
 L  R2630   
 L  R2631   
 L  R2632   
 L  R2633   
 L  R2634   
 L  R2635   
 L  R2636   
 L  R2637   
 L  R2638   
 L  R2639   
 L  R2640   
 L  R2641   
 L  R2642   
 L  R2643   
 L  R2644   
 L  R2645   
 L  R2646   
 L  R2647   
 L  R2648   
 L  R2649   
 L  R2650   
 L  R2651   
 L  R2652   
 L  R2653   
 L  R2654   
 L  R2655   
 L  R2656   
 L  R2657   
 L  R2658   
 L  R2659   
 L  R2660   
 L  R2661   
 L  R2662   
 L  R2663   
 L  R2664   
 L  R2665   
 L  R2666   
 L  R2667   
 L  R2668   
 L  R2669   
 L  R2670   
 L  R2671   
 L  R2672   
 L  R2673   
 L  R2674   
 L  R2675   
 L  R2676   
 L  R2677   
 L  R2678   
 L  R2679   
 L  R2680   
 L  R2681   
 L  R2682   
 L  R2683   
 L  R2684   
 L  R2685   
 L  R2686   
 L  R2687   
 L  R2688   
 L  R2689   
 L  R2690   
 L  R2691   
 L  R2692   
 L  R2693   
 L  R2694   
 L  R2695   
 L  R2696   
 L  R2697   
 L  R2698   
 L  R2699   
 L  R2700   
 L  R2701   
 L  R2702   
 L  R2703   
 L  R2704   
 L  R2705   
 L  R2706   
 L  qc0     
 L  qc1     
 L  qc2     
 L  qc3     
 L  qc4     
 L  qc5     
 L  qc6     
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    phi[0,1]  R0        1
    phi[0,1]  R1        1
    phi[0,1]  R9        -1
    phi[0,1]  R65       -3.0999999046325684e+00
    phi[0,1]  R66       -3.0999999046325684e+00
    phi[0,1]  R67       -2.2400000095367432e+00
    phi[0,1]  R68       -2.2400000095367432e+00
    phi[0,1]  R69       -3.0999999046325684e+00
    phi[0,1]  R70       -3.0999999046325684e+00
    phi[0,1]  R71       -2.5699999332427979e+00
    phi[0,1]  R72       -2.5699999332427979e+00
    phi[0,1]  R73       -3.0999999046325684e+00
    phi[0,1]  R74       -3.0999999046325684e+00
    phi[0,1]  R75       -2.0899999141693115e+00
    phi[0,1]  R76       -2.0899999141693115e+00
    phi[0,1]  R77       -3.0999999046325684e+00
    phi[0,1]  R78       -3.0999999046325684e+00
    phi[0,1]  R79       4.4515776634216309e-01
    phi[0,1]  R80       6.4403849840164185e-01
    phi[0,1]  R81       -9.3695586919784546e-01
    phi[0,1]  R82       8.6483970284461975e-02
    phi[0,1]  R83       -2.4135518074035645e+00
    phi[0,1]  R84       0.724830687046051
    phi[0,1]  R85       -3.4893015027046204e-01
    phi[0,1]  R86       1.1205763816833496e+00
    phi[0,1]  R87       7.3818206787109375e-01
    phi[0,1]  R88       -1.5243440866470337e-01
    phi[0,1]  R89       -9.4868677854537964e-01
    phi[0,1]  R90       -9.2290824651718140e-01
    phi[0,1]  R91       -0.632499635219574
    phi[0,1]  R92       -1.9400764703750610e+00
    phi[0,1]  R93       1.3842854499816895e+00
    phi[0,1]  R94       1.7794713973999023e+00
    phi[0,1]  R95       7.8408801555633545e-01
    phi[0,1]  R96       -4.7733107209205627e-01
    phi[0,1]  R97       -2.0144078731536865e+00
    phi[0,1]  R98       -1.4351322650909424e+00
    phi[0,1]  R99       -1.6716867685317993e+00
    phi[0,1]  R100      -1.7559158802032471e+00
    phi[0,1]  R101      -7.3674492537975311e-02
    phi[0,1]  R102      -1.3486362695693970e+00
    phi[0,1]  R103      6.3503402471542358e-01
    phi[0,1]  R104      3.4215487539768219e-02
    phi[0,1]  R105      -1.5424791574478149e+00
    phi[0,1]  R106      7.5226908922195435e-01
    phi[0,1]  R107      1.6495425999164581e-01
    phi[0,1]  R108      -1.1229139566421509e+00
    phi[0,1]  R109      -0.137942373752594
    phi[0,1]  R110      3.7198033928871155e-01
    phi[0,1]  R111      -1.0249259471893311e+00
    phi[0,1]  R112      1.3486187458038330e+00
    phi[0,1]  R113      1.8782571554183960e+00
    phi[0,1]  R114      1.3425756692886353e+00
    phi[0,1]  R115      -1.7554429173469543e-01
    phi[0,1]  R116      -1.5339112281799316e+00
    phi[0,1]  R117      -2.2178952693939209e+00
    phi[0,1]  R118      -2.6003913879394531e+00
    phi[0,1]  R119      -1.1835546493530273e+00
    phi[0,1]  R120      -2.0240969657897949e+00
    phi[0,1]  R121      -1.8206062316894531e+00
    phi[0,1]  R122      -1.8116765022277832e+00
    phi[0,1]  R123      -2.4915387853980064e-02
    phi[0,1]  R124      -7.8346687555313110e-01
    phi[0,1]  R125      -0.828857958316803
    phi[0,1]  R126      -5.4185503721237183e-01
    phi[0,1]  R127      -1.4156435728073120e+00
    phi[0,1]  R128      9.4675523042678833e-01
    phi[0,1]  R129      -1.2832368612289429e+00
    phi[0,1]  R130      1.7051197588443756e-01
    phi[0,1]  R131      4.2683669924736023e-01
    phi[0,1]  R132      -1.0161125659942627e+00
    phi[0,1]  R133      -2.0129200816154480e-01
    phi[0,1]  R134      1.1557854413986206e+00
    phi[0,1]  R135      1.1966971158981323e+00
    phi[1,0]  R0        -1
    phi[1,0]  R9        1
    phi[1,0]  R10       1
    phi[1,0]  R136      -3.0999999046325684e+00
    phi[1,0]  R137      -3.0999999046325684e+00
    phi[1,0]  R138      -2.2400000095367432e+00
    phi[1,0]  R139      -2.2400000095367432e+00
    phi[1,0]  R140      -3.0999999046325684e+00
    phi[1,0]  R141      -3.0999999046325684e+00
    phi[1,0]  R142      -2.5699999332427979e+00
    phi[1,0]  R143      -2.5699999332427979e+00
    phi[1,0]  R144      -3.0999999046325684e+00
    phi[1,0]  R145      -3.0999999046325684e+00
    phi[1,0]  R146      -2.0899999141693115e+00
    phi[1,0]  R147      -2.0899999141693115e+00
    phi[1,0]  R148      -3.0999999046325684e+00
    phi[1,0]  R149      -3.0999999046325684e+00
    phi[1,0]  R150      7.5226908922195435e-01
    phi[1,0]  R151      1.6495425999164581e-01
    phi[1,0]  R152      -1.1229139566421509e+00
    phi[1,0]  R153      -0.137942373752594
    phi[1,0]  R154      3.7198033928871155e-01
    phi[1,0]  R155      -1.0249259471893311e+00
    phi[1,0]  R156      1.3486187458038330e+00
    phi[1,0]  R157      1.8782571554183960e+00
    phi[1,0]  R158      1.3425756692886353e+00
    phi[1,0]  R159      -1.7554429173469543e-01
    phi[1,0]  R160      -1.5339112281799316e+00
    phi[1,0]  R161      -2.2178952693939209e+00
    phi[1,0]  R162      -2.6003913879394531e+00
    phi[1,0]  R163      -1.1835546493530273e+00
    phi[1,0]  R164      -2.0240969657897949e+00
    phi[1,0]  R165      -1.8206062316894531e+00
    phi[1,0]  R166      -1.8116765022277832e+00
    phi[1,0]  R167      -2.4915387853980064e-02
    phi[1,0]  R168      -7.8346687555313110e-01
    phi[1,0]  R169      -0.828857958316803
    phi[1,0]  R170      -5.4185503721237183e-01
    phi[1,0]  R171      -1.4156435728073120e+00
    phi[1,0]  R172      9.4675523042678833e-01
    phi[1,0]  R173      -1.2832368612289429e+00
    phi[1,0]  R174      1.7051197588443756e-01
    phi[1,0]  R175      4.2683669924736023e-01
    phi[1,0]  R176      -1.0161125659942627e+00
    phi[1,0]  R177      -2.0129200816154480e-01
    phi[1,0]  R178      1.1557854413986206e+00
    phi[1,0]  R179      1.1966971158981323e+00
    phi[1,0]  R180      4.4515776634216309e-01
    phi[1,0]  R181      6.4403849840164185e-01
    phi[1,0]  R182      -9.3695586919784546e-01
    phi[1,0]  R183      8.6483970284461975e-02
    phi[1,0]  R184      -2.4135518074035645e+00
    phi[1,0]  R185      0.724830687046051
    phi[1,0]  R186      -3.4893015027046204e-01
    phi[1,0]  R187      1.1205763816833496e+00
    phi[1,0]  R188      7.3818206787109375e-01
    phi[1,0]  R189      -1.5243440866470337e-01
    phi[1,0]  R190      -9.4868677854537964e-01
    phi[1,0]  R191      -9.2290824651718140e-01
    phi[1,0]  R192      -0.632499635219574
    phi[1,0]  R193      -1.9400764703750610e+00
    phi[1,0]  R194      1.3842854499816895e+00
    phi[1,0]  R195      1.7794713973999023e+00
    phi[1,0]  R196      7.8408801555633545e-01
    phi[1,0]  R197      -4.7733107209205627e-01
    phi[1,0]  R198      -2.0144078731536865e+00
    phi[1,0]  R199      -1.4351322650909424e+00
    phi[1,0]  R200      -1.6716867685317993e+00
    phi[1,0]  R201      -1.7559158802032471e+00
    phi[1,0]  R202      -7.3674492537975311e-02
    phi[1,0]  R203      -1.3486362695693970e+00
    phi[1,0]  R204      6.3503402471542358e-01
    phi[1,0]  R205      3.4215487539768219e-02
    phi[1,0]  R206      -1.5424791574478149e+00
    phi[0,4]  R0        1
    phi[0,4]  R1        1
    phi[0,4]  R36       -1
    phi[0,4]  R207      -3.0999999046325684e+00
    phi[0,4]  R208      -3.0999999046325684e+00
    phi[0,4]  R209      -2.2400000095367432e+00
    phi[0,4]  R210      -2.2400000095367432e+00
    phi[0,4]  R211      -3.0999999046325684e+00
    phi[0,4]  R212      -3.0999999046325684e+00
    phi[0,4]  R213      -2.5699999332427979e+00
    phi[0,4]  R214      -2.5699999332427979e+00
    phi[0,4]  R215      -3.0999999046325684e+00
    phi[0,4]  R216      -3.0999999046325684e+00
    phi[0,4]  R217      -2.0899999141693115e+00
    phi[0,4]  R218      -2.0899999141693115e+00
    phi[0,4]  R219      -3.0999999046325684e+00
    phi[0,4]  R220      -3.0999999046325684e+00
    phi[0,4]  R221      4.4515776634216309e-01
    phi[0,4]  R222      6.4403849840164185e-01
    phi[0,4]  R223      -9.3695586919784546e-01
    phi[0,4]  R224      8.6483970284461975e-02
    phi[0,4]  R225      -2.4135518074035645e+00
    phi[0,4]  R226      0.724830687046051
    phi[0,4]  R227      -3.4893015027046204e-01
    phi[0,4]  R228      1.1205763816833496e+00
    phi[0,4]  R229      7.3818206787109375e-01
    phi[0,4]  R230      -1.5243440866470337e-01
    phi[0,4]  R231      -9.4868677854537964e-01
    phi[0,4]  R232      -9.2290824651718140e-01
    phi[0,4]  R233      -0.632499635219574
    phi[0,4]  R234      -1.9400764703750610e+00
    phi[0,4]  R235      1.3842854499816895e+00
    phi[0,4]  R236      1.7794713973999023e+00
    phi[0,4]  R237      7.8408801555633545e-01
    phi[0,4]  R238      -4.7733107209205627e-01
    phi[0,4]  R239      -2.0144078731536865e+00
    phi[0,4]  R240      -1.4351322650909424e+00
    phi[0,4]  R241      -1.6716867685317993e+00
    phi[0,4]  R242      -1.7559158802032471e+00
    phi[0,4]  R243      -7.3674492537975311e-02
    phi[0,4]  R244      -1.3486362695693970e+00
    phi[0,4]  R245      6.3503402471542358e-01
    phi[0,4]  R246      3.4215487539768219e-02
    phi[0,4]  R247      -1.5424791574478149e+00
    phi[0,4]  R248      7.5226908922195435e-01
    phi[0,4]  R249      1.6495425999164581e-01
    phi[0,4]  R250      -1.1229139566421509e+00
    phi[0,4]  R251      -1.0249259471893311e+00
    phi[0,4]  R252      -1.7554429173469543e-01
    phi[0,4]  R253      -1.2616932392120361e+00
    phi[0,4]  R254      1.2988551855087280e+00
    phi[0,4]  R255      -3.5601291060447693e-01
    phi[0,4]  R256      1.2248814105987549e+00
    phi[0,4]  R257      1.3876349925994873e+00
    phi[0,4]  R258      -1.6449849605560303e+00
    phi[0,4]  R259      -1.5965505838394165e+00
    phi[0,4]  R260      1.0506578683853149e+00
    phi[0,4]  R261      -2.1532227993011475e+00
    phi[0,4]  R262      -7.1489334106445312e-01
    phi[0,4]  R263      -1.3149287700653076e+00
    phi[0,4]  R264      -1.6483988761901855e+00
    phi[0,4]  R265      -1.9498124122619629e+00
    phi[0,4]  R266      -1.8240959644317627e+00
    phi[0,4]  R267      -2.0620522499084473e+00
    phi[0,4]  R268      -1.7782114744186401e+00
    phi[0,4]  R269      -1.2523344755172729e+00
    phi[0,4]  R270      -1.4362407922744751e+00
    phi[0,4]  R271      -7.0883202552795410e-01
    phi[0,4]  R272      8.7394618988037109e-01
    phi[0,4]  R273      -2.0614743232727051e-01
    phi[0,4]  R274      0.936630368232727
    phi[0,4]  R275      9.5954102277755737e-01
    phi[0,4]  R276      6.4390486478805542e-01
    phi[0,4]  R277      1.1574842929840088e+00
    phi[0,4]  R278      9.8944336175918579e-01
    phi[0,4]  R279      5.6081300973892212e-01
    phi[0,4]  R280      1.3382477760314941e+00
    phi[0,4]  R281      -7.0380698889493942e-03
    phi[0,4]  R282      1.1206274479627609e-01
    phi[0,4]  R283      -6.6460907459259033e-01
    phi[0,4]  R284      -8.9397162199020386e-01
    phi[0,4]  R285      -1.1216098070144653e+00
    phi[4,0]  R0        -1
    phi[4,0]  R36       1
    phi[4,0]  R37       1
    phi[4,0]  R286      -3.0999999046325684e+00
    phi[4,0]  R287      -3.0999999046325684e+00
    phi[4,0]  R288      -2.2400000095367432e+00
    phi[4,0]  R289      -2.2400000095367432e+00
    phi[4,0]  R290      -3.0999999046325684e+00
    phi[4,0]  R291      -3.0999999046325684e+00
    phi[4,0]  R292      -2.5699999332427979e+00
    phi[4,0]  R293      -2.5699999332427979e+00
    phi[4,0]  R294      -3.0999999046325684e+00
    phi[4,0]  R295      -3.0999999046325684e+00
    phi[4,0]  R296      -2.0899999141693115e+00
    phi[4,0]  R297      -2.0899999141693115e+00
    phi[4,0]  R298      -3.0999999046325684e+00
    phi[4,0]  R299      -3.0999999046325684e+00
    phi[4,0]  R300      7.5226908922195435e-01
    phi[4,0]  R301      1.6495425999164581e-01
    phi[4,0]  R302      -1.1229139566421509e+00
    phi[4,0]  R303      -1.0249259471893311e+00
    phi[4,0]  R304      -1.7554429173469543e-01
    phi[4,0]  R305      -1.2616932392120361e+00
    phi[4,0]  R306      1.2988551855087280e+00
    phi[4,0]  R307      -3.5601291060447693e-01
    phi[4,0]  R308      1.2248814105987549e+00
    phi[4,0]  R309      1.3876349925994873e+00
    phi[4,0]  R310      -1.6449849605560303e+00
    phi[4,0]  R311      -1.5965505838394165e+00
    phi[4,0]  R312      1.0506578683853149e+00
    phi[4,0]  R313      -2.1532227993011475e+00
    phi[4,0]  R314      -7.1489334106445312e-01
    phi[4,0]  R315      -1.3149287700653076e+00
    phi[4,0]  R316      -1.6483988761901855e+00
    phi[4,0]  R317      -1.9498124122619629e+00
    phi[4,0]  R318      -1.8240959644317627e+00
    phi[4,0]  R319      -2.0620522499084473e+00
    phi[4,0]  R320      -1.7782114744186401e+00
    phi[4,0]  R321      -1.2523344755172729e+00
    phi[4,0]  R322      -1.4362407922744751e+00
    phi[4,0]  R323      -7.0883202552795410e-01
    phi[4,0]  R324      8.7394618988037109e-01
    phi[4,0]  R325      -2.0614743232727051e-01
    phi[4,0]  R326      0.936630368232727
    phi[4,0]  R327      9.5954102277755737e-01
    phi[4,0]  R328      6.4390486478805542e-01
    phi[4,0]  R329      1.1574842929840088e+00
    phi[4,0]  R330      9.8944336175918579e-01
    phi[4,0]  R331      5.6081300973892212e-01
    phi[4,0]  R332      1.3382477760314941e+00
    phi[4,0]  R333      -7.0380698889493942e-03
    phi[4,0]  R334      1.1206274479627609e-01
    phi[4,0]  R335      -6.6460907459259033e-01
    phi[4,0]  R336      -8.9397162199020386e-01
    phi[4,0]  R337      -1.1216098070144653e+00
    phi[4,0]  R338      4.4515776634216309e-01
    phi[4,0]  R339      6.4403849840164185e-01
    phi[4,0]  R340      -9.3695586919784546e-01
    phi[4,0]  R341      8.6483970284461975e-02
    phi[4,0]  R342      -2.4135518074035645e+00
    phi[4,0]  R343      0.724830687046051
    phi[4,0]  R344      -3.4893015027046204e-01
    phi[4,0]  R345      1.1205763816833496e+00
    phi[4,0]  R346      7.3818206787109375e-01
    phi[4,0]  R347      -1.5243440866470337e-01
    phi[4,0]  R348      -9.4868677854537964e-01
    phi[4,0]  R349      -9.2290824651718140e-01
    phi[4,0]  R350      -0.632499635219574
    phi[4,0]  R351      -1.9400764703750610e+00
    phi[4,0]  R352      1.3842854499816895e+00
    phi[4,0]  R353      1.7794713973999023e+00
    phi[4,0]  R354      7.8408801555633545e-01
    phi[4,0]  R355      -4.7733107209205627e-01
    phi[4,0]  R356      -2.0144078731536865e+00
    phi[4,0]  R357      -1.4351322650909424e+00
    phi[4,0]  R358      -1.6716867685317993e+00
    phi[4,0]  R359      -1.7559158802032471e+00
    phi[4,0]  R360      -7.3674492537975311e-02
    phi[4,0]  R361      -1.3486362695693970e+00
    phi[4,0]  R362      6.3503402471542358e-01
    phi[4,0]  R363      3.4215487539768219e-02
    phi[4,0]  R364      -1.5424791574478149e+00
    phi[7,0]  R0        -1
    phi[7,0]  R2        -2.9430398269828695e-01
    phi[7,0]  R3        1.4435929728269428e+00
    phi[7,0]  R4        -1.6186037848795294e+00
    phi[7,0]  R5        1.9409360002006895e+00
    phi[7,0]  R6        -5.4095257782371142e-01
    phi[7,0]  R7        -1.9295957809874440e+00
    phi[7,0]  R8        -5.1741005137642126e-01
    phi[7,0]  R63       1
    phi[7,0]  R365      -2.8056959219342814e+00
    phi[7,0]  R366      -3.3943038873308553e+00
    phi[7,0]  R367      -3.6835929823636859e+00
    phi[7,0]  R368      -7.9640703670980040e-01
    phi[7,0]  R369      -1.4813961197530390e+00
    phi[7,0]  R370      -4.7186036895120980e+00
    phi[7,0]  R371      -4.5109359334434878e+00
    phi[7,0]  R372      -6.2906393304210839e-01
    phi[7,0]  R373      -2.5590473268088569e+00
    phi[7,0]  R374      -3.64095248245628
    phi[7,0]  R375      -1.6040413318186753e-01
    phi[7,0]  R376      -4.0195956951567560e+00
    phi[7,0]  R377      -2.5825898532561471e+00
    phi[7,0]  R378      -3.6174099560089896e+00
    phi[7,0]  R379      -6.9474861720795467e-01
    phi[7,0]  R380      -6.5659362058270876e-01
    phi[7,0]  R381      -7.2366066276670238e-01
    phi[7,0]  R382      -0.967089623796261
    phi[7,0]  R383      -2.0685923618301416e-01
    phi[7,0]  R384      -2.1474981628577128e-01
    phi[7,0]  R385      -8.6715391202245762e-01
    phi[7,0]  R386      -7.4074908457724353e-02
    phi[7,0]  R387      -8.7494436910512952e-02
    phi[7,0]  R388      -9.1387505964729082e-02
    phi[7,0]  R389      -7.7317197794847026e-01
    phi[7,0]  R390      -1.6698309032453273e-01
    phi[7,0]  R391      -1.7537092454739356e-01
    phi[7,0]  R392      -1.8431376762759988e-01
    phi[7,0]  R393      -2.0530931373609329e-01
    phi[7,0]  R394      -2.1012900564188186e-01
    phi[7,0]  R395      -2.1617224755868625e-01
    phi[7,0]  R396      -3.2593490853317808e-01
    phi[7,0]  R397      -4.3875039761759216e-01
    phi[7,0]  R398      -4.5399503359776183e-01
    phi[7,0]  R399      -1.3390635674670648e-01
    phi[7,0]  R400      -1.7048477798511952e-01
    phi[7,0]  R401      -2.2092247101269452e-01
    phi[7,0]  R402      -2.4905274849279713e-01
    phi[7,0]  R403      -2.9024811478988810e-01
    phi[7,0]  R404      -2.9044823673015041e-01
    phi[7,0]  R405      -4.6386157148417961e-01
    phi[1,2]  R9        1
    phi[1,2]  R10       1
    phi[1,2]  R18       -1
    phi[1,2]  R406      -3.0999999046325684e+00
    phi[1,2]  R407      -3.0999999046325684e+00
    phi[1,2]  R408      -2.2400000095367432e+00
    phi[1,2]  R409      -2.2400000095367432e+00
    phi[1,2]  R410      -3.0999999046325684e+00
    phi[1,2]  R411      -3.0999999046325684e+00
    phi[1,2]  R412      -2.5699999332427979e+00
    phi[1,2]  R413      -2.5699999332427979e+00
    phi[1,2]  R414      -3.0999999046325684e+00
    phi[1,2]  R415      -3.0999999046325684e+00
    phi[1,2]  R416      -2.0899999141693115e+00
    phi[1,2]  R417      -2.0899999141693115e+00
    phi[1,2]  R418      -3.0999999046325684e+00
    phi[1,2]  R419      -3.0999999046325684e+00
    phi[1,2]  R420      7.5226908922195435e-01
    phi[1,2]  R421      1.6495425999164581e-01
    phi[1,2]  R422      -1.1229139566421509e+00
    phi[1,2]  R423      -0.137942373752594
    phi[1,2]  R424      3.7198033928871155e-01
    phi[1,2]  R425      -1.0249259471893311e+00
    phi[1,2]  R426      1.3486187458038330e+00
    phi[1,2]  R427      1.8782571554183960e+00
    phi[1,2]  R428      1.3425756692886353e+00
    phi[1,2]  R429      -1.7554429173469543e-01
    phi[1,2]  R430      -1.5339112281799316e+00
    phi[1,2]  R431      -2.2178952693939209e+00
    phi[1,2]  R432      -2.6003913879394531e+00
    phi[1,2]  R433      -1.1835546493530273e+00
    phi[1,2]  R434      -2.0240969657897949e+00
    phi[1,2]  R435      -1.8206062316894531e+00
    phi[1,2]  R436      -1.8116765022277832e+00
    phi[1,2]  R437      -2.4915387853980064e-02
    phi[1,2]  R438      -7.8346687555313110e-01
    phi[1,2]  R439      -0.828857958316803
    phi[1,2]  R440      -5.4185503721237183e-01
    phi[1,2]  R441      -1.4156435728073120e+00
    phi[1,2]  R442      9.4675523042678833e-01
    phi[1,2]  R443      -1.2832368612289429e+00
    phi[1,2]  R444      1.7051197588443756e-01
    phi[1,2]  R445      4.2683669924736023e-01
    phi[1,2]  R446      -1.0161125659942627e+00
    phi[1,2]  R447      -2.0129200816154480e-01
    phi[1,2]  R448      1.1557854413986206e+00
    phi[1,2]  R449      1.1966971158981323e+00
    phi[1,2]  R450      -4.1059449315071106e-01
    phi[1,2]  R451      3.7506675720214844e-01
    phi[1,2]  R452      0.302695095539093
    phi[1,2]  R453      0.550740122795105
    phi[1,2]  R454      9.8461306095123291e-01
    phi[1,2]  R455      5.1730567216873169e-01
    phi[1,2]  R456      -1.9616442918777466e+00
    phi[1,2]  R457      -3.8356816768646240e-01
    phi[1,2]  R458      0.00273551931604743
    phi[1,2]  R459      1.34242582321167
    phi[1,2]  R460      -2.0860948562622070e+00
    phi[1,2]  R461      -1.3416309356689453e+00
    phi[1,2]  R462      -1.2164822816848755e+00
    phi[1,2]  R463      -1.9608197212219238e+00
    phi[1,2]  R464      -1.4012874364852905e+00
    phi[1,2]  R465      -2.0051162242889404e+00
    phi[1,2]  R466      -1.4596840143203735e+00
    phi[1,2]  R467      -1.4440631866455078e+00
    phi[1,2]  R468      -1.0570718050003052e+00
    phi[1,2]  R469      -2.6349279880523682e+00
    phi[1,2]  R470      -1.2938522100448608e+00
    phi[1,2]  R471      -8.5892552137374878e-01
    phi[1,2]  R472      -1.1797974109649658e+00
    phi[1,2]  R473      -8.8280421495437622e-01
    phi[1,2]  R474      -2.8812637329101562e+00
    phi[1,2]  R475      -2.4601900577545166e+00
    phi[1,2]  R476      -1.5331609249114990e+00
    phi[1,2]  R477      -2.1858911514282227e+00
    phi[1,2]  R478      -2.3903067111968994e+00
    phi[1,2]  R479      -1.6348053216934204e+00
    phi[1,2]  R480      -1.2297774553298950e+00
    phi[1,2]  R481      -9.3449252843856812e-01
    phi[1,2]  R482      -1.2131445407867432e+00
    phi[1,2]  R483      -2.5646109580993652e+00
    phi[1,2]  R484      -1.6964511871337891e+00
    phi[1,2]  R485      -1.2094031572341919e+00
    phi[1,2]  R486      -1.9356056451797485e+00
    phi[1,2]  R487      -1.7371383905410767e+00
    phi[1,2]  R488      -2.9033150672912598e+00
    phi[1,2]  R489      -2.0469884872436523e+00
    phi[1,2]  R490      -6.2335073947906494e-01
    phi[1,2]  R491      1.3653816282749176e-01
    phi[1,2]  R492      -4.2586025595664978e-01
    phi[1,2]  R493      -2.1545362472534180e+00
    phi[1,2]  R494      -9.8929077386856079e-01
    phi[1,2]  R495      -2.2704544067382812e+00
    phi[1,2]  R496      -1.2108964920043945e+00
    phi[1,2]  R497      -2.2265682220458984e+00
    phi[1,2]  R498      -1.33949613571167
    phi[1,2]  R499      -1.4865072965621948e+00
    phi[1,2]  R500      -5.1061987876892090e-01
    phi[1,2]  R501      -1.8176695108413696e+00
    phi[1,2]  R502      -5.3430527448654175e-01
    phi[1,2]  R503      -1.3052258491516113e+00
    phi[1,2]  R504      -1.2581969499588013e+00
    phi[1,2]  R505      -0.682050883769989
    phi[1,2]  R506      -7.0810538530349731e-01
    phi[1,2]  R507      -1.4164376258850098e+00
    phi[1,2]  R508      -9.9098873138427734e-01
    phi[1,2]  R509      -1.7632838487625122e+00
    phi[1,2]  R510      -2.3081879317760468e-01
    phi[1,2]  R511      -1.0673549175262451e+00
    phi[1,2]  R512      -1.9283260107040405e+00
    phi[1,2]  R513      -1.4222410917282104e+00
    phi[1,2]  R514      -1.77421236038208
    phi[1,2]  R515      -2.3799364566802979e+00
    phi[1,2]  R516      -4.5930331945419312e-01
    phi[1,2]  R517      -1.1929981708526611e+00
    phi[1,2]  R518      -4.8560982942581177e-01
    phi[1,2]  R519      -1.6701107025146484e+00
    phi[1,2]  R520      -4.7812661528587341e-01
    phi[1,2]  R521      -1.8687337636947632e+00
    phi[1,2]  R522      -1.9820977449417114e+00
    phi[1,2]  R523      -3.1967043876647949e+00
    phi[1,2]  R524      -1.1853843927383423e+00
    phi[1,2]  R525      -3.1305823326110840e+00
    phi[1,2]  R526      5.7931149005889893e-01
    phi[1,2]  R527      7.5891190767288208e-01
    phi[1,2]  R528      2.6554688811302185e-01
    phi[1,2]  R529      -9.2355078458786011e-01
    phi[2,1]  R9        -1
    phi[2,1]  R18       1
    phi[2,1]  R19       1
    phi[2,1]  R530      -3.0999999046325684e+00
    phi[2,1]  R531      -3.0999999046325684e+00
    phi[2,1]  R532      -2.2400000095367432e+00
    phi[2,1]  R533      -2.2400000095367432e+00
    phi[2,1]  R534      -3.0999999046325684e+00
    phi[2,1]  R535      -3.0999999046325684e+00
    phi[2,1]  R536      -2.5699999332427979e+00
    phi[2,1]  R537      -2.5699999332427979e+00
    phi[2,1]  R538      -3.0999999046325684e+00
    phi[2,1]  R539      -3.0999999046325684e+00
    phi[2,1]  R540      -2.0899999141693115e+00
    phi[2,1]  R541      -2.0899999141693115e+00
    phi[2,1]  R542      -3.0999999046325684e+00
    phi[2,1]  R543      -3.0999999046325684e+00
    phi[2,1]  R544      -4.1059449315071106e-01
    phi[2,1]  R545      3.7506675720214844e-01
    phi[2,1]  R546      0.302695095539093
    phi[2,1]  R547      0.550740122795105
    phi[2,1]  R548      9.8461306095123291e-01
    phi[2,1]  R549      5.1730567216873169e-01
    phi[2,1]  R550      -1.9616442918777466e+00
    phi[2,1]  R551      -3.8356816768646240e-01
    phi[2,1]  R552      0.00273551931604743
    phi[2,1]  R553      1.34242582321167
    phi[2,1]  R554      -2.0860948562622070e+00
    phi[2,1]  R555      -1.3416309356689453e+00
    phi[2,1]  R556      -1.2164822816848755e+00
    phi[2,1]  R557      -1.9608197212219238e+00
    phi[2,1]  R558      -1.4012874364852905e+00
    phi[2,1]  R559      -2.0051162242889404e+00
    phi[2,1]  R560      -1.4596840143203735e+00
    phi[2,1]  R561      -1.4440631866455078e+00
    phi[2,1]  R562      -1.0570718050003052e+00
    phi[2,1]  R563      -2.6349279880523682e+00
    phi[2,1]  R564      -1.2938522100448608e+00
    phi[2,1]  R565      -8.5892552137374878e-01
    phi[2,1]  R566      -1.1797974109649658e+00
    phi[2,1]  R567      -8.8280421495437622e-01
    phi[2,1]  R568      -2.8812637329101562e+00
    phi[2,1]  R569      -2.4601900577545166e+00
    phi[2,1]  R570      -1.5331609249114990e+00
    phi[2,1]  R571      -2.1858911514282227e+00
    phi[2,1]  R572      -2.3903067111968994e+00
    phi[2,1]  R573      -1.6348053216934204e+00
    phi[2,1]  R574      -1.2297774553298950e+00
    phi[2,1]  R575      -9.3449252843856812e-01
    phi[2,1]  R576      -1.2131445407867432e+00
    phi[2,1]  R577      -2.5646109580993652e+00
    phi[2,1]  R578      -1.6964511871337891e+00
    phi[2,1]  R579      -1.2094031572341919e+00
    phi[2,1]  R580      -1.9356056451797485e+00
    phi[2,1]  R581      -1.7371383905410767e+00
    phi[2,1]  R582      -2.9033150672912598e+00
    phi[2,1]  R583      -2.0469884872436523e+00
    phi[2,1]  R584      -6.2335073947906494e-01
    phi[2,1]  R585      1.3653816282749176e-01
    phi[2,1]  R586      -4.2586025595664978e-01
    phi[2,1]  R587      -2.1545362472534180e+00
    phi[2,1]  R588      -9.8929077386856079e-01
    phi[2,1]  R589      -2.2704544067382812e+00
    phi[2,1]  R590      -1.2108964920043945e+00
    phi[2,1]  R591      -2.2265682220458984e+00
    phi[2,1]  R592      -1.33949613571167
    phi[2,1]  R593      -1.4865072965621948e+00
    phi[2,1]  R594      -5.1061987876892090e-01
    phi[2,1]  R595      -1.8176695108413696e+00
    phi[2,1]  R596      -5.3430527448654175e-01
    phi[2,1]  R597      -1.3052258491516113e+00
    phi[2,1]  R598      -1.2581969499588013e+00
    phi[2,1]  R599      -0.682050883769989
    phi[2,1]  R600      -7.0810538530349731e-01
    phi[2,1]  R601      -1.4164376258850098e+00
    phi[2,1]  R602      -9.9098873138427734e-01
    phi[2,1]  R603      -1.7632838487625122e+00
    phi[2,1]  R604      -2.3081879317760468e-01
    phi[2,1]  R605      -1.0673549175262451e+00
    phi[2,1]  R606      -1.9283260107040405e+00
    phi[2,1]  R607      -1.4222410917282104e+00
    phi[2,1]  R608      -1.77421236038208
    phi[2,1]  R609      -2.3799364566802979e+00
    phi[2,1]  R610      -4.5930331945419312e-01
    phi[2,1]  R611      -1.1929981708526611e+00
    phi[2,1]  R612      -4.8560982942581177e-01
    phi[2,1]  R613      -1.6701107025146484e+00
    phi[2,1]  R614      -4.7812661528587341e-01
    phi[2,1]  R615      -1.8687337636947632e+00
    phi[2,1]  R616      -1.9820977449417114e+00
    phi[2,1]  R617      -3.1967043876647949e+00
    phi[2,1]  R618      -1.1853843927383423e+00
    phi[2,1]  R619      -3.1305823326110840e+00
    phi[2,1]  R620      5.7931149005889893e-01
    phi[2,1]  R621      7.5891190767288208e-01
    phi[2,1]  R622      2.6554688811302185e-01
    phi[2,1]  R623      -9.2355078458786011e-01
    phi[2,1]  R624      7.5226908922195435e-01
    phi[2,1]  R625      1.6495425999164581e-01
    phi[2,1]  R626      -1.1229139566421509e+00
    phi[2,1]  R627      -0.137942373752594
    phi[2,1]  R628      3.7198033928871155e-01
    phi[2,1]  R629      -1.0249259471893311e+00
    phi[2,1]  R630      1.3486187458038330e+00
    phi[2,1]  R631      1.8782571554183960e+00
    phi[2,1]  R632      1.3425756692886353e+00
    phi[2,1]  R633      -1.7554429173469543e-01
    phi[2,1]  R634      -1.5339112281799316e+00
    phi[2,1]  R635      -2.2178952693939209e+00
    phi[2,1]  R636      -2.6003913879394531e+00
    phi[2,1]  R637      -1.1835546493530273e+00
    phi[2,1]  R638      -2.0240969657897949e+00
    phi[2,1]  R639      -1.8206062316894531e+00
    phi[2,1]  R640      -1.8116765022277832e+00
    phi[2,1]  R641      -2.4915387853980064e-02
    phi[2,1]  R642      -7.8346687555313110e-01
    phi[2,1]  R643      -0.828857958316803
    phi[2,1]  R644      -5.4185503721237183e-01
    phi[2,1]  R645      -1.4156435728073120e+00
    phi[2,1]  R646      9.4675523042678833e-01
    phi[2,1]  R647      -1.2832368612289429e+00
    phi[2,1]  R648      1.7051197588443756e-01
    phi[2,1]  R649      4.2683669924736023e-01
    phi[2,1]  R650      -1.0161125659942627e+00
    phi[2,1]  R651      -2.0129200816154480e-01
    phi[2,1]  R652      1.1557854413986206e+00
    phi[2,1]  R653      1.1966971158981323e+00
    phi[1,4]  R9        1
    phi[1,4]  R10       1
    phi[1,4]  R36       -1
    phi[1,4]  R654      -3.0999999046325684e+00
    phi[1,4]  R655      -3.0999999046325684e+00
    phi[1,4]  R656      -2.2400000095367432e+00
    phi[1,4]  R657      -2.2400000095367432e+00
    phi[1,4]  R658      -3.0999999046325684e+00
    phi[1,4]  R659      -3.0999999046325684e+00
    phi[1,4]  R660      -2.5699999332427979e+00
    phi[1,4]  R661      -2.5699999332427979e+00
    phi[1,4]  R662      -3.0999999046325684e+00
    phi[1,4]  R663      -3.0999999046325684e+00
    phi[1,4]  R664      -2.0899999141693115e+00
    phi[1,4]  R665      -2.0899999141693115e+00
    phi[1,4]  R666      -3.0999999046325684e+00
    phi[1,4]  R667      -3.0999999046325684e+00
    phi[1,4]  R668      7.5226908922195435e-01
    phi[1,4]  R669      1.6495425999164581e-01
    phi[1,4]  R670      -1.1229139566421509e+00
    phi[1,4]  R671      -0.137942373752594
    phi[1,4]  R672      3.7198033928871155e-01
    phi[1,4]  R673      -1.0249259471893311e+00
    phi[1,4]  R674      1.3486187458038330e+00
    phi[1,4]  R675      1.8782571554183960e+00
    phi[1,4]  R676      1.3425756692886353e+00
    phi[1,4]  R677      -1.7554429173469543e-01
    phi[1,4]  R678      -1.5339112281799316e+00
    phi[1,4]  R679      -2.2178952693939209e+00
    phi[1,4]  R680      -2.6003913879394531e+00
    phi[1,4]  R681      -1.1835546493530273e+00
    phi[1,4]  R682      -2.0240969657897949e+00
    phi[1,4]  R683      -1.8206062316894531e+00
    phi[1,4]  R684      -1.8116765022277832e+00
    phi[1,4]  R685      -2.4915387853980064e-02
    phi[1,4]  R686      -7.8346687555313110e-01
    phi[1,4]  R687      -0.828857958316803
    phi[1,4]  R688      -5.4185503721237183e-01
    phi[1,4]  R689      -1.4156435728073120e+00
    phi[1,4]  R690      9.4675523042678833e-01
    phi[1,4]  R691      -1.2832368612289429e+00
    phi[1,4]  R692      1.7051197588443756e-01
    phi[1,4]  R693      4.2683669924736023e-01
    phi[1,4]  R694      -1.0161125659942627e+00
    phi[1,4]  R695      -2.0129200816154480e-01
    phi[1,4]  R696      1.1557854413986206e+00
    phi[1,4]  R697      1.1966971158981323e+00
    phi[1,4]  R698      -1.2616932392120361e+00
    phi[1,4]  R699      1.2988551855087280e+00
    phi[1,4]  R700      -3.5601291060447693e-01
    phi[1,4]  R701      1.2248814105987549e+00
    phi[1,4]  R702      1.3876349925994873e+00
    phi[1,4]  R703      -1.6449849605560303e+00
    phi[1,4]  R704      -1.5965505838394165e+00
    phi[1,4]  R705      1.0506578683853149e+00
    phi[1,4]  R706      -2.1532227993011475e+00
    phi[1,4]  R707      -7.1489334106445312e-01
    phi[1,4]  R708      -1.3149287700653076e+00
    phi[1,4]  R709      -1.6483988761901855e+00
    phi[1,4]  R710      -1.9498124122619629e+00
    phi[1,4]  R711      -1.8240959644317627e+00
    phi[1,4]  R712      -2.0620522499084473e+00
    phi[1,4]  R713      -1.7782114744186401e+00
    phi[1,4]  R714      -1.2523344755172729e+00
    phi[1,4]  R715      -1.4362407922744751e+00
    phi[1,4]  R716      -7.0883202552795410e-01
    phi[1,4]  R717      8.7394618988037109e-01
    phi[1,4]  R718      -2.0614743232727051e-01
    phi[1,4]  R719      0.936630368232727
    phi[1,4]  R720      9.5954102277755737e-01
    phi[1,4]  R721      6.4390486478805542e-01
    phi[1,4]  R722      1.1574842929840088e+00
    phi[1,4]  R723      9.8944336175918579e-01
    phi[1,4]  R724      5.6081300973892212e-01
    phi[1,4]  R725      1.3382477760314941e+00
    phi[1,4]  R726      -7.0380698889493942e-03
    phi[1,4]  R727      1.1206274479627609e-01
    phi[1,4]  R728      -6.6460907459259033e-01
    phi[1,4]  R729      -8.9397162199020386e-01
    phi[1,4]  R730      -1.1216098070144653e+00
    phi[4,1]  R9        -1
    phi[4,1]  R36       1
    phi[4,1]  R37       1
    phi[4,1]  R731      -3.0999999046325684e+00
    phi[4,1]  R732      -3.0999999046325684e+00
    phi[4,1]  R733      -2.2400000095367432e+00
    phi[4,1]  R734      -2.2400000095367432e+00
    phi[4,1]  R735      -3.0999999046325684e+00
    phi[4,1]  R736      -3.0999999046325684e+00
    phi[4,1]  R737      -2.5699999332427979e+00
    phi[4,1]  R738      -2.5699999332427979e+00
    phi[4,1]  R739      -3.0999999046325684e+00
    phi[4,1]  R740      -3.0999999046325684e+00
    phi[4,1]  R741      -2.0899999141693115e+00
    phi[4,1]  R742      -2.0899999141693115e+00
    phi[4,1]  R743      -3.0999999046325684e+00
    phi[4,1]  R744      -3.0999999046325684e+00
    phi[4,1]  R745      7.5226908922195435e-01
    phi[4,1]  R746      1.6495425999164581e-01
    phi[4,1]  R747      -1.1229139566421509e+00
    phi[4,1]  R748      -1.0249259471893311e+00
    phi[4,1]  R749      -1.7554429173469543e-01
    phi[4,1]  R750      -1.2616932392120361e+00
    phi[4,1]  R751      1.2988551855087280e+00
    phi[4,1]  R752      -3.5601291060447693e-01
    phi[4,1]  R753      1.2248814105987549e+00
    phi[4,1]  R754      1.3876349925994873e+00
    phi[4,1]  R755      -1.6449849605560303e+00
    phi[4,1]  R756      -1.5965505838394165e+00
    phi[4,1]  R757      1.0506578683853149e+00
    phi[4,1]  R758      -2.1532227993011475e+00
    phi[4,1]  R759      -7.1489334106445312e-01
    phi[4,1]  R760      -1.3149287700653076e+00
    phi[4,1]  R761      -1.6483988761901855e+00
    phi[4,1]  R762      -1.9498124122619629e+00
    phi[4,1]  R763      -1.8240959644317627e+00
    phi[4,1]  R764      -2.0620522499084473e+00
    phi[4,1]  R765      -1.7782114744186401e+00
    phi[4,1]  R766      -1.2523344755172729e+00
    phi[4,1]  R767      -1.4362407922744751e+00
    phi[4,1]  R768      -7.0883202552795410e-01
    phi[4,1]  R769      8.7394618988037109e-01
    phi[4,1]  R770      -2.0614743232727051e-01
    phi[4,1]  R771      0.936630368232727
    phi[4,1]  R772      9.5954102277755737e-01
    phi[4,1]  R773      6.4390486478805542e-01
    phi[4,1]  R774      1.1574842929840088e+00
    phi[4,1]  R775      9.8944336175918579e-01
    phi[4,1]  R776      5.6081300973892212e-01
    phi[4,1]  R777      1.3382477760314941e+00
    phi[4,1]  R778      -7.0380698889493942e-03
    phi[4,1]  R779      1.1206274479627609e-01
    phi[4,1]  R780      -6.6460907459259033e-01
    phi[4,1]  R781      -8.9397162199020386e-01
    phi[4,1]  R782      -1.1216098070144653e+00
    phi[4,1]  R783      -0.137942373752594
    phi[4,1]  R784      3.7198033928871155e-01
    phi[4,1]  R785      1.3486187458038330e+00
    phi[4,1]  R786      1.8782571554183960e+00
    phi[4,1]  R787      1.3425756692886353e+00
    phi[4,1]  R788      -1.5339112281799316e+00
    phi[4,1]  R789      -2.2178952693939209e+00
    phi[4,1]  R790      -2.6003913879394531e+00
    phi[4,1]  R791      -1.1835546493530273e+00
    phi[4,1]  R792      -2.0240969657897949e+00
    phi[4,1]  R793      -1.8206062316894531e+00
    phi[4,1]  R794      -1.8116765022277832e+00
    phi[4,1]  R795      -2.4915387853980064e-02
    phi[4,1]  R796      -7.8346687555313110e-01
    phi[4,1]  R797      -0.828857958316803
    phi[4,1]  R798      -5.4185503721237183e-01
    phi[4,1]  R799      -1.4156435728073120e+00
    phi[4,1]  R800      9.4675523042678833e-01
    phi[4,1]  R801      -1.2832368612289429e+00
    phi[4,1]  R802      1.7051197588443756e-01
    phi[4,1]  R803      4.2683669924736023e-01
    phi[4,1]  R804      -1.0161125659942627e+00
    phi[4,1]  R805      -2.0129200816154480e-01
    phi[4,1]  R806      1.1557854413986206e+00
    phi[4,1]  R807      1.1966971158981323e+00
    phi[2,3]  R18       1
    phi[2,3]  R19       1
    phi[2,3]  R27       -1
    phi[2,3]  R808      -3.0999999046325684e+00
    phi[2,3]  R809      -3.0999999046325684e+00
    phi[2,3]  R810      -2.2400000095367432e+00
    phi[2,3]  R811      -2.2400000095367432e+00
    phi[2,3]  R812      -3.0999999046325684e+00
    phi[2,3]  R813      -3.0999999046325684e+00
    phi[2,3]  R814      -2.5699999332427979e+00
    phi[2,3]  R815      -2.5699999332427979e+00
    phi[2,3]  R816      -3.0999999046325684e+00
    phi[2,3]  R817      -3.0999999046325684e+00
    phi[2,3]  R818      -2.0899999141693115e+00
    phi[2,3]  R819      -2.0899999141693115e+00
    phi[2,3]  R820      -3.0999999046325684e+00
    phi[2,3]  R821      -3.0999999046325684e+00
    phi[2,3]  R822      -4.1059449315071106e-01
    phi[2,3]  R823      3.7506675720214844e-01
    phi[2,3]  R824      0.302695095539093
    phi[2,3]  R825      0.550740122795105
    phi[2,3]  R826      9.8461306095123291e-01
    phi[2,3]  R827      5.1730567216873169e-01
    phi[2,3]  R828      -1.9616442918777466e+00
    phi[2,3]  R829      -3.8356816768646240e-01
    phi[2,3]  R830      0.00273551931604743
    phi[2,3]  R831      1.34242582321167
    phi[2,3]  R832      -2.0860948562622070e+00
    phi[2,3]  R833      -1.3416309356689453e+00
    phi[2,3]  R834      -1.2164822816848755e+00
    phi[2,3]  R835      -1.9608197212219238e+00
    phi[2,3]  R836      -1.4012874364852905e+00
    phi[2,3]  R837      -2.0051162242889404e+00
    phi[2,3]  R838      -1.4596840143203735e+00
    phi[2,3]  R839      -1.4440631866455078e+00
    phi[2,3]  R840      -1.0570718050003052e+00
    phi[2,3]  R841      -2.6349279880523682e+00
    phi[2,3]  R842      -1.2938522100448608e+00
    phi[2,3]  R843      -8.5892552137374878e-01
    phi[2,3]  R844      -1.1797974109649658e+00
    phi[2,3]  R845      -8.8280421495437622e-01
    phi[2,3]  R846      -2.8812637329101562e+00
    phi[2,3]  R847      -2.4601900577545166e+00
    phi[2,3]  R848      -1.5331609249114990e+00
    phi[2,3]  R849      -2.1858911514282227e+00
    phi[2,3]  R850      -2.3903067111968994e+00
    phi[2,3]  R851      -1.6348053216934204e+00
    phi[2,3]  R852      -1.2297774553298950e+00
    phi[2,3]  R853      -9.3449252843856812e-01
    phi[2,3]  R854      -1.2131445407867432e+00
    phi[2,3]  R855      -2.5646109580993652e+00
    phi[2,3]  R856      -1.6964511871337891e+00
    phi[2,3]  R857      -1.2094031572341919e+00
    phi[2,3]  R858      -1.9356056451797485e+00
    phi[2,3]  R859      -1.7371383905410767e+00
    phi[2,3]  R860      -2.9033150672912598e+00
    phi[2,3]  R861      -2.0469884872436523e+00
    phi[2,3]  R862      -6.2335073947906494e-01
    phi[2,3]  R863      1.3653816282749176e-01
    phi[2,3]  R864      -4.2586025595664978e-01
    phi[2,3]  R865      -2.1545362472534180e+00
    phi[2,3]  R866      -9.8929077386856079e-01
    phi[2,3]  R867      -2.2704544067382812e+00
    phi[2,3]  R868      -1.2108964920043945e+00
    phi[2,3]  R869      -2.2265682220458984e+00
    phi[2,3]  R870      -1.33949613571167
    phi[2,3]  R871      -1.4865072965621948e+00
    phi[2,3]  R872      -5.1061987876892090e-01
    phi[2,3]  R873      -1.8176695108413696e+00
    phi[2,3]  R874      -5.3430527448654175e-01
    phi[2,3]  R875      -1.3052258491516113e+00
    phi[2,3]  R876      -1.2581969499588013e+00
    phi[2,3]  R877      -0.682050883769989
    phi[2,3]  R878      -7.0810538530349731e-01
    phi[2,3]  R879      -1.4164376258850098e+00
    phi[2,3]  R880      -9.9098873138427734e-01
    phi[2,3]  R881      -1.7632838487625122e+00
    phi[2,3]  R882      -2.3081879317760468e-01
    phi[2,3]  R883      -1.0673549175262451e+00
    phi[2,3]  R884      -1.9283260107040405e+00
    phi[2,3]  R885      -1.4222410917282104e+00
    phi[2,3]  R886      -1.77421236038208
    phi[2,3]  R887      -2.3799364566802979e+00
    phi[2,3]  R888      -4.5930331945419312e-01
    phi[2,3]  R889      -1.1929981708526611e+00
    phi[2,3]  R890      -4.8560982942581177e-01
    phi[2,3]  R891      -1.6701107025146484e+00
    phi[2,3]  R892      -4.7812661528587341e-01
    phi[2,3]  R893      -1.8687337636947632e+00
    phi[2,3]  R894      -1.9820977449417114e+00
    phi[2,3]  R895      -3.1967043876647949e+00
    phi[2,3]  R896      -1.1853843927383423e+00
    phi[2,3]  R897      -3.1305823326110840e+00
    phi[2,3]  R898      5.7931149005889893e-01
    phi[2,3]  R899      7.5891190767288208e-01
    phi[2,3]  R900      2.6554688811302185e-01
    phi[2,3]  R901      -9.2355078458786011e-01
    phi[2,3]  R902      1.0409064292907715e+00
    phi[2,3]  R903      1.8636420965194702e+00
    phi[2,3]  R904      -1.3719923496246338e+00
    phi[2,3]  R905      -1.4194954633712769e+00
    phi[2,3]  R906      -1.5436004400253296e+00
    phi[2,3]  R907      3.6576864123344421e-01
    phi[2,3]  R908      1.4695732593536377e+00
    phi[2,3]  R909      1.7430297136306763e+00
    phi[2,3]  R910      1.2018660306930542e+00
    phi[2,3]  R911      8.8693320751190186e-01
    phi[2,3]  R912      -1.9800482988357544e+00
    phi[2,3]  R913      4.6119123697280884e-01
    phi[2,3]  R914      -1.2527037858963013e+00
    phi[2,3]  R915      -8.1338649988174438e-01
    phi[2,3]  R916      -1.4177453517913818e+00
    phi[2,3]  R917      1.0714820623397827e+00
    phi[2,3]  R918      9.2184841632843018e-01
    phi[2,3]  R919      -6.6808617115020752e-01
    phi[2,3]  R920      -7.4516147375106812e-01
    phi[2,3]  R921      -1.5168772637844086e-01
    phi[2,3]  R922      -1.1100964546203613e+00
    phi[2,3]  R923      2.9854935407638550e-01
    phi[2,3]  R924      1.3235869407653809e+00
    phi[2,3]  R925      -3.7355655431747437e-01
    phi[2,3]  R926      -2.0636042952537537e-01
    phi[2,3]  R927      9.0924799442291260e-02
    phi[2,3]  R928      1.9307342171669006e-01
    phi[2,3]  R929      5.7279783487319946e-01
    phi[2,3]  R930      -2.3466280102729797e-01
    phi[2,3]  R931      2.2995056211948395e-01
    phi[3,2]  R18       -1
    phi[3,2]  R27       1
    phi[3,2]  R28       1
    phi[3,2]  R932      -3.0999999046325684e+00
    phi[3,2]  R933      -3.0999999046325684e+00
    phi[3,2]  R934      -2.2400000095367432e+00
    phi[3,2]  R935      -2.2400000095367432e+00
    phi[3,2]  R936      -3.0999999046325684e+00
    phi[3,2]  R937      -3.0999999046325684e+00
    phi[3,2]  R938      -2.5699999332427979e+00
    phi[3,2]  R939      -2.5699999332427979e+00
    phi[3,2]  R940      -3.0999999046325684e+00
    phi[3,2]  R941      -3.0999999046325684e+00
    phi[3,2]  R942      -2.0899999141693115e+00
    phi[3,2]  R943      -2.0899999141693115e+00
    phi[3,2]  R944      -3.0999999046325684e+00
    phi[3,2]  R945      -3.0999999046325684e+00
    phi[3,2]  R946      1.0409064292907715e+00
    phi[3,2]  R947      1.8636420965194702e+00
    phi[3,2]  R948      -1.3719923496246338e+00
    phi[3,2]  R949      -1.4194954633712769e+00
    phi[3,2]  R950      -1.5436004400253296e+00
    phi[3,2]  R951      3.6576864123344421e-01
    phi[3,2]  R952      1.4695732593536377e+00
    phi[3,2]  R953      1.7430297136306763e+00
    phi[3,2]  R954      1.2018660306930542e+00
    phi[3,2]  R955      8.8693320751190186e-01
    phi[3,2]  R956      -1.9800482988357544e+00
    phi[3,2]  R957      4.6119123697280884e-01
    phi[3,2]  R958      -1.2527037858963013e+00
    phi[3,2]  R959      -8.1338649988174438e-01
    phi[3,2]  R960      -1.4177453517913818e+00
    phi[3,2]  R961      1.0714820623397827e+00
    phi[3,2]  R962      9.2184841632843018e-01
    phi[3,2]  R963      -6.6808617115020752e-01
    phi[3,2]  R964      -7.4516147375106812e-01
    phi[3,2]  R965      -1.5168772637844086e-01
    phi[3,2]  R966      -1.1100964546203613e+00
    phi[3,2]  R967      2.9854935407638550e-01
    phi[3,2]  R968      1.3235869407653809e+00
    phi[3,2]  R969      -3.7355655431747437e-01
    phi[3,2]  R970      -2.0636042952537537e-01
    phi[3,2]  R971      9.0924799442291260e-02
    phi[3,2]  R972      1.9307342171669006e-01
    phi[3,2]  R973      5.7279783487319946e-01
    phi[3,2]  R974      -2.3466280102729797e-01
    phi[3,2]  R975      2.2995056211948395e-01
    phi[3,2]  R976      -4.1059449315071106e-01
    phi[3,2]  R977      3.7506675720214844e-01
    phi[3,2]  R978      0.302695095539093
    phi[3,2]  R979      0.550740122795105
    phi[3,2]  R980      9.8461306095123291e-01
    phi[3,2]  R981      5.1730567216873169e-01
    phi[3,2]  R982      -1.9616442918777466e+00
    phi[3,2]  R983      -3.8356816768646240e-01
    phi[3,2]  R984      0.00273551931604743
    phi[3,2]  R985      1.34242582321167
    phi[3,2]  R986      -2.0860948562622070e+00
    phi[3,2]  R987      -1.3416309356689453e+00
    phi[3,2]  R988      -1.2164822816848755e+00
    phi[3,2]  R989      -1.9608197212219238e+00
    phi[3,2]  R990      -1.4012874364852905e+00
    phi[3,2]  R991      -2.0051162242889404e+00
    phi[3,2]  R992      -1.4596840143203735e+00
    phi[3,2]  R993      -1.4440631866455078e+00
    phi[3,2]  R994      -1.0570718050003052e+00
    phi[3,2]  R995      -2.6349279880523682e+00
    phi[3,2]  R996      -1.2938522100448608e+00
    phi[3,2]  R997      -8.5892552137374878e-01
    phi[3,2]  R998      -1.1797974109649658e+00
    phi[3,2]  R999      -8.8280421495437622e-01
    phi[3,2]  R1000     -2.8812637329101562e+00
    phi[3,2]  R1001     -2.4601900577545166e+00
    phi[3,2]  R1002     -1.5331609249114990e+00
    phi[3,2]  R1003     -2.1858911514282227e+00
    phi[3,2]  R1004     -2.3903067111968994e+00
    phi[3,2]  R1005     -1.6348053216934204e+00
    phi[3,2]  R1006     -1.2297774553298950e+00
    phi[3,2]  R1007     -9.3449252843856812e-01
    phi[3,2]  R1008     -1.2131445407867432e+00
    phi[3,2]  R1009     -2.5646109580993652e+00
    phi[3,2]  R1010     -1.6964511871337891e+00
    phi[3,2]  R1011     -1.2094031572341919e+00
    phi[3,2]  R1012     -1.9356056451797485e+00
    phi[3,2]  R1013     -1.7371383905410767e+00
    phi[3,2]  R1014     -2.9033150672912598e+00
    phi[3,2]  R1015     -2.0469884872436523e+00
    phi[3,2]  R1016     -6.2335073947906494e-01
    phi[3,2]  R1017     1.3653816282749176e-01
    phi[3,2]  R1018     -4.2586025595664978e-01
    phi[3,2]  R1019     -2.1545362472534180e+00
    phi[3,2]  R1020     -9.8929077386856079e-01
    phi[3,2]  R1021     -2.2704544067382812e+00
    phi[3,2]  R1022     -1.2108964920043945e+00
    phi[3,2]  R1023     -2.2265682220458984e+00
    phi[3,2]  R1024     -1.33949613571167
    phi[3,2]  R1025     -1.4865072965621948e+00
    phi[3,2]  R1026     -5.1061987876892090e-01
    phi[3,2]  R1027     -1.8176695108413696e+00
    phi[3,2]  R1028     -5.3430527448654175e-01
    phi[3,2]  R1029     -1.3052258491516113e+00
    phi[3,2]  R1030     -1.2581969499588013e+00
    phi[3,2]  R1031     -0.682050883769989
    phi[3,2]  R1032     -7.0810538530349731e-01
    phi[3,2]  R1033     -1.4164376258850098e+00
    phi[3,2]  R1034     -9.9098873138427734e-01
    phi[3,2]  R1035     -1.7632838487625122e+00
    phi[3,2]  R1036     -2.3081879317760468e-01
    phi[3,2]  R1037     -1.0673549175262451e+00
    phi[3,2]  R1038     -1.9283260107040405e+00
    phi[3,2]  R1039     -1.4222410917282104e+00
    phi[3,2]  R1040     -1.77421236038208
    phi[3,2]  R1041     -2.3799364566802979e+00
    phi[3,2]  R1042     -4.5930331945419312e-01
    phi[3,2]  R1043     -1.1929981708526611e+00
    phi[3,2]  R1044     -4.8560982942581177e-01
    phi[3,2]  R1045     -1.6701107025146484e+00
    phi[3,2]  R1046     -4.7812661528587341e-01
    phi[3,2]  R1047     -1.8687337636947632e+00
    phi[3,2]  R1048     -1.9820977449417114e+00
    phi[3,2]  R1049     -3.1967043876647949e+00
    phi[3,2]  R1050     -1.1853843927383423e+00
    phi[3,2]  R1051     -3.1305823326110840e+00
    phi[3,2]  R1052     5.7931149005889893e-01
    phi[3,2]  R1053     7.5891190767288208e-01
    phi[3,2]  R1054     2.6554688811302185e-01
    phi[3,2]  R1055     -9.2355078458786011e-01
    phi[2,5]  R18       1
    phi[2,5]  R19       1
    phi[2,5]  R45       -1
    phi[2,5]  R1056     -3.0999999046325684e+00
    phi[2,5]  R1057     -3.0999999046325684e+00
    phi[2,5]  R1058     -2.2400000095367432e+00
    phi[2,5]  R1059     -2.2400000095367432e+00
    phi[2,5]  R1060     -3.0999999046325684e+00
    phi[2,5]  R1061     -3.0999999046325684e+00
    phi[2,5]  R1062     -2.5699999332427979e+00
    phi[2,5]  R1063     -2.5699999332427979e+00
    phi[2,5]  R1064     -3.0999999046325684e+00
    phi[2,5]  R1065     -3.0999999046325684e+00
    phi[2,5]  R1066     -2.0899999141693115e+00
    phi[2,5]  R1067     -2.0899999141693115e+00
    phi[2,5]  R1068     -3.0999999046325684e+00
    phi[2,5]  R1069     -3.0999999046325684e+00
    phi[2,5]  R1070     -4.1059449315071106e-01
    phi[2,5]  R1071     3.7506675720214844e-01
    phi[2,5]  R1072     0.302695095539093
    phi[2,5]  R1073     0.550740122795105
    phi[2,5]  R1074     9.8461306095123291e-01
    phi[2,5]  R1075     5.1730567216873169e-01
    phi[2,5]  R1076     -1.9616442918777466e+00
    phi[2,5]  R1077     -3.8356816768646240e-01
    phi[2,5]  R1078     0.00273551931604743
    phi[2,5]  R1079     1.34242582321167
    phi[2,5]  R1080     -2.0860948562622070e+00
    phi[2,5]  R1081     -1.3416309356689453e+00
    phi[2,5]  R1082     -1.2164822816848755e+00
    phi[2,5]  R1083     -1.9608197212219238e+00
    phi[2,5]  R1084     -1.4012874364852905e+00
    phi[2,5]  R1085     -2.0051162242889404e+00
    phi[2,5]  R1086     -1.4596840143203735e+00
    phi[2,5]  R1087     -1.4440631866455078e+00
    phi[2,5]  R1088     -1.0570718050003052e+00
    phi[2,5]  R1089     -2.6349279880523682e+00
    phi[2,5]  R1090     -1.2938522100448608e+00
    phi[2,5]  R1091     -8.5892552137374878e-01
    phi[2,5]  R1092     -1.1797974109649658e+00
    phi[2,5]  R1093     -8.8280421495437622e-01
    phi[2,5]  R1094     -2.8812637329101562e+00
    phi[2,5]  R1095     -2.4601900577545166e+00
    phi[2,5]  R1096     -1.5331609249114990e+00
    phi[2,5]  R1097     -2.1858911514282227e+00
    phi[2,5]  R1098     -2.3903067111968994e+00
    phi[2,5]  R1099     -1.6348053216934204e+00
    phi[2,5]  R1100     -1.2297774553298950e+00
    phi[2,5]  R1101     -9.3449252843856812e-01
    phi[2,5]  R1102     -1.2131445407867432e+00
    phi[2,5]  R1103     -2.5646109580993652e+00
    phi[2,5]  R1104     -1.6964511871337891e+00
    phi[2,5]  R1105     -1.2094031572341919e+00
    phi[2,5]  R1106     -1.9356056451797485e+00
    phi[2,5]  R1107     -1.7371383905410767e+00
    phi[2,5]  R1108     -2.9033150672912598e+00
    phi[2,5]  R1109     -2.0469884872436523e+00
    phi[2,5]  R1110     -6.2335073947906494e-01
    phi[2,5]  R1111     1.3653816282749176e-01
    phi[2,5]  R1112     -4.2586025595664978e-01
    phi[2,5]  R1113     -2.1545362472534180e+00
    phi[2,5]  R1114     -9.8929077386856079e-01
    phi[2,5]  R1115     -2.2704544067382812e+00
    phi[2,5]  R1116     -1.2108964920043945e+00
    phi[2,5]  R1117     -2.2265682220458984e+00
    phi[2,5]  R1118     -1.33949613571167
    phi[2,5]  R1119     -1.4865072965621948e+00
    phi[2,5]  R1120     -5.1061987876892090e-01
    phi[2,5]  R1121     -1.8176695108413696e+00
    phi[2,5]  R1122     -5.3430527448654175e-01
    phi[2,5]  R1123     -1.3052258491516113e+00
    phi[2,5]  R1124     -1.2581969499588013e+00
    phi[2,5]  R1125     -0.682050883769989
    phi[2,5]  R1126     -7.0810538530349731e-01
    phi[2,5]  R1127     -1.4164376258850098e+00
    phi[2,5]  R1128     -9.9098873138427734e-01
    phi[2,5]  R1129     -1.7632838487625122e+00
    phi[2,5]  R1130     -2.3081879317760468e-01
    phi[2,5]  R1131     -1.0673549175262451e+00
    phi[2,5]  R1132     -1.9283260107040405e+00
    phi[2,5]  R1133     -1.4222410917282104e+00
    phi[2,5]  R1134     -1.77421236038208
    phi[2,5]  R1135     -2.3799364566802979e+00
    phi[2,5]  R1136     -4.5930331945419312e-01
    phi[2,5]  R1137     -1.1929981708526611e+00
    phi[2,5]  R1138     -4.8560982942581177e-01
    phi[2,5]  R1139     -1.6701107025146484e+00
    phi[2,5]  R1140     -4.7812661528587341e-01
    phi[2,5]  R1141     -1.8687337636947632e+00
    phi[2,5]  R1142     -1.9820977449417114e+00
    phi[2,5]  R1143     -3.1967043876647949e+00
    phi[2,5]  R1144     -1.1853843927383423e+00
    phi[2,5]  R1145     -3.1305823326110840e+00
    phi[2,5]  R1146     5.7931149005889893e-01
    phi[2,5]  R1147     7.5891190767288208e-01
    phi[2,5]  R1148     2.6554688811302185e-01
    phi[2,5]  R1149     -9.2355078458786011e-01
    phi[2,5]  R1150     8.0544435977935791e-01
    phi[2,5]  R1151     0.973087728023529
    phi[2,5]  R1152     1.2180260419845581e+00
    phi[2,5]  R1153     4.8487940430641174e-01
    phi[2,5]  R1154     -1.4006030559539795e+00
    phi[2,5]  R1155     -1.4972023963928223e+00
    phi[2,5]  R1156     1.2359386682510376e+00
    phi[2,5]  R1157     1.0257400274276733e+00
    phi[2,5]  R1158     5.2839678525924683e-01
    phi[2,5]  R1159     9.5671236515045166e-01
    phi[2,5]  R1160     -1.2434377670288086e+00
    phi[2,5]  R1161     -1.5167493820190430e+00
    phi[2,5]  R1162     -1.2203935384750366e+00
    phi[2,5]  R1163     -1.7819712162017822e+00
    phi[2,5]  R1164     -1.6413147449493408e+00
    phi[2,5]  R1165     -8.6682152748107910e-01
    phi[2,5]  R1166     -0.997409462928772
    phi[2,5]  R1167     -1.6971688270568848e+00
    phi[2,5]  R1168     -1.5470626354217529e+00
    phi[2,5]  R1169     -1.8657522201538086e+00
    phi[2,5]  R1170     -3.7779641151428223e-01
    phi[2,5]  R1171     1.7627835273742676e-01
    phi[2,5]  R1172     -6.9049972295761108e-01
    phi[2,5]  R1173     -6.5015208721160889e-01
    phi[2,5]  R1174     -1.0731520652770996e+00
    phi[2,5]  R1175     -1.2784301042556763e+00
    phi[2,5]  R1176     -5.7238382101058960e-01
    phi[2,5]  R1177     -2.0980405807495117e+00
    phi[2,5]  R1178     -2.2275238037109375e+00
    phi[2,5]  R1179     -2.1541481018066406e+00
    phi[2,5]  R1180     -1.0098798274993896e+00
    phi[2,5]  R1181     -1.2326946258544922e+00
    phi[2,5]  R1182     -4.0620538592338562e-01
    phi[2,5]  R1183     -6.7001998424530029e-01
    phi[2,5]  R1184     -0.499702513217926
    phi[2,5]  R1185     -2.5419056415557861e+00
    phi[2,5]  R1186     -2.0639407634735107e+00
    phi[2,5]  R1187     5.7012975215911865e-01
    phi[2,5]  R1188     -8.0350227653980255e-02
    phi[2,5]  R1189     -5.5077087879180908e-01
    phi[2,5]  R1190     1.6380780935287476e-01
    phi[2,5]  R1191     2.6567700505256653e-01
    phi[2,5]  R1192     -1.0277023315429688e+00
    phi[2,5]  R1193     -2.6975749060511589e-03
    phi[2,5]  R1194     -1.8068439960479736e+00
    phi[2,5]  R1195     6.5805412828922272e-02
    phi[2,5]  R1196     6.0065108537673950e-01
    phi[2,5]  R1197     -2.0738284587860107e+00
    phi[2,5]  R1198     -1.9757531881332397e+00
    phi[2,5]  R1199     -0.684005856513977
    phi[2,5]  R1200     7.1532171964645386e-01
    phi[2,5]  R1201     -5.0004631280899048e-02
    phi[2,5]  R1202     -6.5592658519744873e-01
    phi[2,5]  R1203     5.6433415412902832e-01
    phi[2,5]  R1204     8.6142492294311523e-01
    phi[2,5]  R1205     -2.0558822154998779e+00
    phi[2,5]  R1206     -1.1305016279220581e+00
    phi[2,5]  R1207     -1.7250468730926514e+00
    phi[2,5]  R1208     -2.0856688022613525e+00
    phi[2,5]  R1209     -2.5460817813873291e+00
    phi[2,5]  R1210     -2.2219960689544678e+00
    phi[2,5]  R1211     4.5952093601226807e-01
    phi[2,5]  R1212     -4.5258036255836487e-01
    phi[2,5]  R1213     -1.7169950008392334e+00
    phi[2,5]  R1214     -2.7968106269836426e+00
    phi[2,5]  R1215     7.1914279460906982e-01
    phi[2,5]  R1216     -1.9644308090209961e+00
    phi[2,5]  R1217     -1.4859426021575928e+00
    phi[2,5]  R1218     -2.2357513904571533e+00
    phi[2,5]  R1219     -2.1062147617340088e+00
    phi[2,5]  R1220     5.0073277950286865e-01
    phi[2,5]  R1221     5.6562179327011108e-01
    phi[2,5]  R1222     -0.819481372833252
    phi[2,5]  R1223     -1.6407839059829712e+00
    phi[2,5]  R1224     -2.5702476501464844e+00
    phi[2,5]  R1225     -1.0241162031888962e-02
    phi[2,5]  R1226     1.9017034769058228e-01
    phi[2,5]  R1227     4.0468281507492065e-01
    phi[2,5]  R1228     1.0109093040227890e-01
    phi[2,5]  R1229     -1.0985653102397919e-01
    phi[2,5]  R1230     -1.7182637453079224e+00
    phi[2,5]  R1231     3.0702481046319008e-02
    phi[2,5]  R1232     0.655983030796051
    phi[2,5]  R1233     7.6226696372032166e-02
    phi[2,5]  R1234     -2.4709425866603851e-01
    phi[2,5]  R1235     -7.7672761678695679e-01
    phi[2,5]  R1236     -7.0843201875686646e-01
    phi[2,5]  R1237     -4.8143498599529266e-02
    phi[2,5]  R1238     -0.610497772693634
    phi[2,5]  R1239     -1.4331958293914795e+00
    phi[5,2]  R18       -1
    phi[5,2]  R45       1
    phi[5,2]  R46       1
    phi[5,2]  R1240     -3.0999999046325684e+00
    phi[5,2]  R1241     -3.0999999046325684e+00
    phi[5,2]  R1242     -2.2400000095367432e+00
    phi[5,2]  R1243     -2.2400000095367432e+00
    phi[5,2]  R1244     -3.0999999046325684e+00
    phi[5,2]  R1245     -3.0999999046325684e+00
    phi[5,2]  R1246     -2.5699999332427979e+00
    phi[5,2]  R1247     -2.5699999332427979e+00
    phi[5,2]  R1248     -3.0999999046325684e+00
    phi[5,2]  R1249     -3.0999999046325684e+00
    phi[5,2]  R1250     -2.0899999141693115e+00
    phi[5,2]  R1251     -2.0899999141693115e+00
    phi[5,2]  R1252     -3.0999999046325684e+00
    phi[5,2]  R1253     -3.0999999046325684e+00
    phi[5,2]  R1254     8.0544435977935791e-01
    phi[5,2]  R1255     0.973087728023529
    phi[5,2]  R1256     1.2180260419845581e+00
    phi[5,2]  R1257     4.8487940430641174e-01
    phi[5,2]  R1258     -1.4006030559539795e+00
    phi[5,2]  R1259     -1.4972023963928223e+00
    phi[5,2]  R1260     1.2359386682510376e+00
    phi[5,2]  R1261     1.0257400274276733e+00
    phi[5,2]  R1262     5.2839678525924683e-01
    phi[5,2]  R1263     9.5671236515045166e-01
    phi[5,2]  R1264     -1.2434377670288086e+00
    phi[5,2]  R1265     -1.5167493820190430e+00
    phi[5,2]  R1266     -1.2203935384750366e+00
    phi[5,2]  R1267     -1.7819712162017822e+00
    phi[5,2]  R1268     -1.6413147449493408e+00
    phi[5,2]  R1269     -8.6682152748107910e-01
    phi[5,2]  R1270     -0.997409462928772
    phi[5,2]  R1271     -1.6971688270568848e+00
    phi[5,2]  R1272     -1.5470626354217529e+00
    phi[5,2]  R1273     -1.8657522201538086e+00
    phi[5,2]  R1274     -3.7779641151428223e-01
    phi[5,2]  R1275     1.7627835273742676e-01
    phi[5,2]  R1276     -6.9049972295761108e-01
    phi[5,2]  R1277     -6.5015208721160889e-01
    phi[5,2]  R1278     -1.0731520652770996e+00
    phi[5,2]  R1279     -1.2784301042556763e+00
    phi[5,2]  R1280     -5.7238382101058960e-01
    phi[5,2]  R1281     -2.0980405807495117e+00
    phi[5,2]  R1282     -2.2275238037109375e+00
    phi[5,2]  R1283     -2.1541481018066406e+00
    phi[5,2]  R1284     -1.0098798274993896e+00
    phi[5,2]  R1285     -1.2326946258544922e+00
    phi[5,2]  R1286     -4.0620538592338562e-01
    phi[5,2]  R1287     -6.7001998424530029e-01
    phi[5,2]  R1288     -0.499702513217926
    phi[5,2]  R1289     -2.5419056415557861e+00
    phi[5,2]  R1290     -2.0639407634735107e+00
    phi[5,2]  R1291     5.7012975215911865e-01
    phi[5,2]  R1292     -8.0350227653980255e-02
    phi[5,2]  R1293     -5.5077087879180908e-01
    phi[5,2]  R1294     1.6380780935287476e-01
    phi[5,2]  R1295     2.6567700505256653e-01
    phi[5,2]  R1296     -1.0277023315429688e+00
    phi[5,2]  R1297     -2.6975749060511589e-03
    phi[5,2]  R1298     -1.8068439960479736e+00
    phi[5,2]  R1299     6.5805412828922272e-02
    phi[5,2]  R1300     6.0065108537673950e-01
    phi[5,2]  R1301     -2.0738284587860107e+00
    phi[5,2]  R1302     -1.9757531881332397e+00
    phi[5,2]  R1303     -0.684005856513977
    phi[5,2]  R1304     7.1532171964645386e-01
    phi[5,2]  R1305     -5.0004631280899048e-02
    phi[5,2]  R1306     -6.5592658519744873e-01
    phi[5,2]  R1307     5.6433415412902832e-01
    phi[5,2]  R1308     8.6142492294311523e-01
    phi[5,2]  R1309     -2.0558822154998779e+00
    phi[5,2]  R1310     -1.1305016279220581e+00
    phi[5,2]  R1311     -1.7250468730926514e+00
    phi[5,2]  R1312     -2.0856688022613525e+00
    phi[5,2]  R1313     -2.5460817813873291e+00
    phi[5,2]  R1314     -2.2219960689544678e+00
    phi[5,2]  R1315     4.5952093601226807e-01
    phi[5,2]  R1316     -4.5258036255836487e-01
    phi[5,2]  R1317     -1.7169950008392334e+00
    phi[5,2]  R1318     -2.7968106269836426e+00
    phi[5,2]  R1319     7.1914279460906982e-01
    phi[5,2]  R1320     -1.9644308090209961e+00
    phi[5,2]  R1321     -1.4859426021575928e+00
    phi[5,2]  R1322     -2.2357513904571533e+00
    phi[5,2]  R1323     -2.1062147617340088e+00
    phi[5,2]  R1324     5.0073277950286865e-01
    phi[5,2]  R1325     5.6562179327011108e-01
    phi[5,2]  R1326     -0.819481372833252
    phi[5,2]  R1327     -1.6407839059829712e+00
    phi[5,2]  R1328     -2.5702476501464844e+00
    phi[5,2]  R1329     -1.0241162031888962e-02
    phi[5,2]  R1330     1.9017034769058228e-01
    phi[5,2]  R1331     4.0468281507492065e-01
    phi[5,2]  R1332     1.0109093040227890e-01
    phi[5,2]  R1333     -1.0985653102397919e-01
    phi[5,2]  R1334     -1.7182637453079224e+00
    phi[5,2]  R1335     3.0702481046319008e-02
    phi[5,2]  R1336     0.655983030796051
    phi[5,2]  R1337     7.6226696372032166e-02
    phi[5,2]  R1338     -2.4709425866603851e-01
    phi[5,2]  R1339     -7.7672761678695679e-01
    phi[5,2]  R1340     -7.0843201875686646e-01
    phi[5,2]  R1341     -4.8143498599529266e-02
    phi[5,2]  R1342     -0.610497772693634
    phi[5,2]  R1343     -1.4331958293914795e+00
    phi[5,2]  R1344     -4.1059449315071106e-01
    phi[5,2]  R1345     3.7506675720214844e-01
    phi[5,2]  R1346     0.302695095539093
    phi[5,2]  R1347     0.550740122795105
    phi[5,2]  R1348     9.8461306095123291e-01
    phi[5,2]  R1349     5.1730567216873169e-01
    phi[5,2]  R1350     -1.9616442918777466e+00
    phi[5,2]  R1351     -3.8356816768646240e-01
    phi[5,2]  R1352     0.00273551931604743
    phi[5,2]  R1353     1.34242582321167
    phi[5,2]  R1354     -2.0860948562622070e+00
    phi[5,2]  R1355     -1.3416309356689453e+00
    phi[5,2]  R1356     -1.2164822816848755e+00
    phi[5,2]  R1357     -1.9608197212219238e+00
    phi[5,2]  R1358     -1.4012874364852905e+00
    phi[5,2]  R1359     -2.0051162242889404e+00
    phi[5,2]  R1360     -1.4596840143203735e+00
    phi[5,2]  R1361     -1.4440631866455078e+00
    phi[5,2]  R1362     -1.0570718050003052e+00
    phi[5,2]  R1363     -2.6349279880523682e+00
    phi[5,2]  R1364     -1.2938522100448608e+00
    phi[5,2]  R1365     -8.5892552137374878e-01
    phi[5,2]  R1366     -1.1797974109649658e+00
    phi[5,2]  R1367     -8.8280421495437622e-01
    phi[5,2]  R1368     -2.8812637329101562e+00
    phi[5,2]  R1369     -2.4601900577545166e+00
    phi[5,2]  R1370     -1.5331609249114990e+00
    phi[5,2]  R1371     -2.1858911514282227e+00
    phi[5,2]  R1372     -2.3903067111968994e+00
    phi[5,2]  R1373     -1.6348053216934204e+00
    phi[5,2]  R1374     -1.2297774553298950e+00
    phi[5,2]  R1375     -9.3449252843856812e-01
    phi[5,2]  R1376     -1.2131445407867432e+00
    phi[5,2]  R1377     -2.5646109580993652e+00
    phi[5,2]  R1378     -1.6964511871337891e+00
    phi[5,2]  R1379     -1.2094031572341919e+00
    phi[5,2]  R1380     -1.9356056451797485e+00
    phi[5,2]  R1381     -1.7371383905410767e+00
    phi[5,2]  R1382     -2.9033150672912598e+00
    phi[5,2]  R1383     -2.0469884872436523e+00
    phi[5,2]  R1384     -6.2335073947906494e-01
    phi[5,2]  R1385     1.3653816282749176e-01
    phi[5,2]  R1386     -4.2586025595664978e-01
    phi[5,2]  R1387     -2.1545362472534180e+00
    phi[5,2]  R1388     -9.8929077386856079e-01
    phi[5,2]  R1389     -2.2704544067382812e+00
    phi[5,2]  R1390     -1.2108964920043945e+00
    phi[5,2]  R1391     -2.2265682220458984e+00
    phi[5,2]  R1392     -1.33949613571167
    phi[5,2]  R1393     -1.4865072965621948e+00
    phi[5,2]  R1394     -5.1061987876892090e-01
    phi[5,2]  R1395     -1.8176695108413696e+00
    phi[5,2]  R1396     -5.3430527448654175e-01
    phi[5,2]  R1397     -1.3052258491516113e+00
    phi[5,2]  R1398     -1.2581969499588013e+00
    phi[5,2]  R1399     -0.682050883769989
    phi[5,2]  R1400     -7.0810538530349731e-01
    phi[5,2]  R1401     -1.4164376258850098e+00
    phi[5,2]  R1402     -9.9098873138427734e-01
    phi[5,2]  R1403     -1.7632838487625122e+00
    phi[5,2]  R1404     -2.3081879317760468e-01
    phi[5,2]  R1405     -1.0673549175262451e+00
    phi[5,2]  R1406     -1.9283260107040405e+00
    phi[5,2]  R1407     -1.4222410917282104e+00
    phi[5,2]  R1408     -1.77421236038208
    phi[5,2]  R1409     -2.3799364566802979e+00
    phi[5,2]  R1410     -4.5930331945419312e-01
    phi[5,2]  R1411     -1.1929981708526611e+00
    phi[5,2]  R1412     -4.8560982942581177e-01
    phi[5,2]  R1413     -1.6701107025146484e+00
    phi[5,2]  R1414     -4.7812661528587341e-01
    phi[5,2]  R1415     -1.8687337636947632e+00
    phi[5,2]  R1416     -1.9820977449417114e+00
    phi[5,2]  R1417     -3.1967043876647949e+00
    phi[5,2]  R1418     -1.1853843927383423e+00
    phi[5,2]  R1419     -3.1305823326110840e+00
    phi[5,2]  R1420     5.7931149005889893e-01
    phi[5,2]  R1421     7.5891190767288208e-01
    phi[5,2]  R1422     2.6554688811302185e-01
    phi[5,2]  R1423     -9.2355078458786011e-01
    phi[2,6]  R18       1
    phi[2,6]  R19       1
    phi[2,6]  R54       -1
    phi[2,6]  R1424     -3.0999999046325684e+00
    phi[2,6]  R1425     -3.0999999046325684e+00
    phi[2,6]  R1426     -2.2400000095367432e+00
    phi[2,6]  R1427     -2.2400000095367432e+00
    phi[2,6]  R1428     -3.0999999046325684e+00
    phi[2,6]  R1429     -3.0999999046325684e+00
    phi[2,6]  R1430     -2.5699999332427979e+00
    phi[2,6]  R1431     -2.5699999332427979e+00
    phi[2,6]  R1432     -3.0999999046325684e+00
    phi[2,6]  R1433     -3.0999999046325684e+00
    phi[2,6]  R1434     -2.0899999141693115e+00
    phi[2,6]  R1435     -2.0899999141693115e+00
    phi[2,6]  R1436     -3.0999999046325684e+00
    phi[2,6]  R1437     -3.0999999046325684e+00
    phi[2,6]  R1438     -4.1059449315071106e-01
    phi[2,6]  R1439     3.7506675720214844e-01
    phi[2,6]  R1440     0.302695095539093
    phi[2,6]  R1441     0.550740122795105
    phi[2,6]  R1442     9.8461306095123291e-01
    phi[2,6]  R1443     5.1730567216873169e-01
    phi[2,6]  R1444     -1.9616442918777466e+00
    phi[2,6]  R1445     -3.8356816768646240e-01
    phi[2,6]  R1446     0.00273551931604743
    phi[2,6]  R1447     1.34242582321167
    phi[2,6]  R1448     -2.0860948562622070e+00
    phi[2,6]  R1449     -1.3416309356689453e+00
    phi[2,6]  R1450     -1.2164822816848755e+00
    phi[2,6]  R1451     -1.9608197212219238e+00
    phi[2,6]  R1452     -1.4012874364852905e+00
    phi[2,6]  R1453     -2.0051162242889404e+00
    phi[2,6]  R1454     -1.4596840143203735e+00
    phi[2,6]  R1455     -1.4440631866455078e+00
    phi[2,6]  R1456     -1.0570718050003052e+00
    phi[2,6]  R1457     -2.6349279880523682e+00
    phi[2,6]  R1458     -1.2938522100448608e+00
    phi[2,6]  R1459     -8.5892552137374878e-01
    phi[2,6]  R1460     -1.1797974109649658e+00
    phi[2,6]  R1461     -8.8280421495437622e-01
    phi[2,6]  R1462     -2.8812637329101562e+00
    phi[2,6]  R1463     -2.4601900577545166e+00
    phi[2,6]  R1464     -1.5331609249114990e+00
    phi[2,6]  R1465     -2.1858911514282227e+00
    phi[2,6]  R1466     -2.3903067111968994e+00
    phi[2,6]  R1467     -1.6348053216934204e+00
    phi[2,6]  R1468     -1.2297774553298950e+00
    phi[2,6]  R1469     -9.3449252843856812e-01
    phi[2,6]  R1470     -1.2131445407867432e+00
    phi[2,6]  R1471     -2.5646109580993652e+00
    phi[2,6]  R1472     -1.6964511871337891e+00
    phi[2,6]  R1473     -1.2094031572341919e+00
    phi[2,6]  R1474     -1.9356056451797485e+00
    phi[2,6]  R1475     -1.7371383905410767e+00
    phi[2,6]  R1476     -2.9033150672912598e+00
    phi[2,6]  R1477     -2.0469884872436523e+00
    phi[2,6]  R1478     -6.2335073947906494e-01
    phi[2,6]  R1479     1.3653816282749176e-01
    phi[2,6]  R1480     -4.2586025595664978e-01
    phi[2,6]  R1481     -2.1545362472534180e+00
    phi[2,6]  R1482     -9.8929077386856079e-01
    phi[2,6]  R1483     -2.2704544067382812e+00
    phi[2,6]  R1484     -1.2108964920043945e+00
    phi[2,6]  R1485     -2.2265682220458984e+00
    phi[2,6]  R1486     -1.33949613571167
    phi[2,6]  R1487     -1.4865072965621948e+00
    phi[2,6]  R1488     -5.1061987876892090e-01
    phi[2,6]  R1489     -1.8176695108413696e+00
    phi[2,6]  R1490     -5.3430527448654175e-01
    phi[2,6]  R1491     -1.3052258491516113e+00
    phi[2,6]  R1492     -1.2581969499588013e+00
    phi[2,6]  R1493     -0.682050883769989
    phi[2,6]  R1494     -7.0810538530349731e-01
    phi[2,6]  R1495     -1.4164376258850098e+00
    phi[2,6]  R1496     -9.9098873138427734e-01
    phi[2,6]  R1497     -1.7632838487625122e+00
    phi[2,6]  R1498     -2.3081879317760468e-01
    phi[2,6]  R1499     -1.0673549175262451e+00
    phi[2,6]  R1500     -1.9283260107040405e+00
    phi[2,6]  R1501     -1.4222410917282104e+00
    phi[2,6]  R1502     -1.77421236038208
    phi[2,6]  R1503     -2.3799364566802979e+00
    phi[2,6]  R1504     -4.5930331945419312e-01
    phi[2,6]  R1505     -1.1929981708526611e+00
    phi[2,6]  R1506     -4.8560982942581177e-01
    phi[2,6]  R1507     -1.6701107025146484e+00
    phi[2,6]  R1508     -4.7812661528587341e-01
    phi[2,6]  R1509     -1.8687337636947632e+00
    phi[2,6]  R1510     -1.9820977449417114e+00
    phi[2,6]  R1511     -3.1967043876647949e+00
    phi[2,6]  R1512     -1.1853843927383423e+00
    phi[2,6]  R1513     -3.1305823326110840e+00
    phi[2,6]  R1514     5.7931149005889893e-01
    phi[2,6]  R1515     7.5891190767288208e-01
    phi[2,6]  R1516     2.6554688811302185e-01
    phi[2,6]  R1517     -9.2355078458786011e-01
    phi[2,6]  R1518     7.9740768671035767e-01
    phi[2,6]  R1519     1.6698783636093140e+00
    phi[2,6]  R1520     2.1052714437246323e-02
    phi[2,6]  R1521     1.0540287494659424e+00
    phi[2,6]  R1522     -1.7421831190586090e-01
    phi[2,6]  R1523     1.4089368581771851e+00
    phi[2,6]  R1524     -3.3452877402305603e-01
    phi[2,6]  R1525     1.1671119928359985e+00
    phi[2,6]  R1526     1.6902462244033813e+00
    phi[2,6]  R1527     1.2835736274719238e+00
    phi[2,6]  R1528     -2.5479822158813477e+00
    phi[2,6]  R1529     -3.4511647224426270e+00
    phi[2,6]  R1530     -0.770904004573822
    phi[2,6]  R1531     -1.4467204809188843e+00
    phi[2,6]  R1532     -2.3574464321136475e+00
    phi[2,6]  R1533     6.3520956039428711e-01
    phi[2,6]  R1534     -2.3900596797466278e-01
    phi[2,6]  R1535     -1.0942143201828003e+00
    phi[2,6]  R1536     1.7405757308006287e-01
    phi[2,6]  R1537     -2.7343741059303284e-01
    phi[2,6]  R1538     -2.2749118804931641e+00
    phi[2,6]  R1539     -3.4299910068511963e+00
    phi[2,6]  R1540     -9.2628955841064453e-01
    phi[2,6]  R1541     -7.5816780328750610e-01
    phi[2,6]  R1542     -7.7381461858749390e-01
    phi[2,6]  R1543     -1.1334320306777954e+00
    phi[2,6]  R1544     -2.1087963581085205e+00
    phi[6,2]  R18       -1
    phi[6,2]  R54       1
    phi[6,2]  R55       1
    phi[6,2]  R1545     -3.0999999046325684e+00
    phi[6,2]  R1546     -3.0999999046325684e+00
    phi[6,2]  R1547     -2.2400000095367432e+00
    phi[6,2]  R1548     -2.2400000095367432e+00
    phi[6,2]  R1549     -3.0999999046325684e+00
    phi[6,2]  R1550     -3.0999999046325684e+00
    phi[6,2]  R1551     -2.5699999332427979e+00
    phi[6,2]  R1552     -2.5699999332427979e+00
    phi[6,2]  R1553     -3.0999999046325684e+00
    phi[6,2]  R1554     -3.0999999046325684e+00
    phi[6,2]  R1555     -2.0899999141693115e+00
    phi[6,2]  R1556     -2.0899999141693115e+00
    phi[6,2]  R1557     -3.0999999046325684e+00
    phi[6,2]  R1558     -3.0999999046325684e+00
    phi[6,2]  R1559     7.9740768671035767e-01
    phi[6,2]  R1560     1.6698783636093140e+00
    phi[6,2]  R1561     2.1052714437246323e-02
    phi[6,2]  R1562     1.0540287494659424e+00
    phi[6,2]  R1563     -1.7421831190586090e-01
    phi[6,2]  R1564     1.4089368581771851e+00
    phi[6,2]  R1565     -3.3452877402305603e-01
    phi[6,2]  R1566     1.1671119928359985e+00
    phi[6,2]  R1567     1.6902462244033813e+00
    phi[6,2]  R1568     1.2835736274719238e+00
    phi[6,2]  R1569     -2.5479822158813477e+00
    phi[6,2]  R1570     -3.4511647224426270e+00
    phi[6,2]  R1571     -0.770904004573822
    phi[6,2]  R1572     -1.4467204809188843e+00
    phi[6,2]  R1573     -2.3574464321136475e+00
    phi[6,2]  R1574     6.3520956039428711e-01
    phi[6,2]  R1575     -2.3900596797466278e-01
    phi[6,2]  R1576     -1.0942143201828003e+00
    phi[6,2]  R1577     1.7405757308006287e-01
    phi[6,2]  R1578     -2.7343741059303284e-01
    phi[6,2]  R1579     -2.2749118804931641e+00
    phi[6,2]  R1580     -3.4299910068511963e+00
    phi[6,2]  R1581     -9.2628955841064453e-01
    phi[6,2]  R1582     -7.5816780328750610e-01
    phi[6,2]  R1583     -7.7381461858749390e-01
    phi[6,2]  R1584     -1.1334320306777954e+00
    phi[6,2]  R1585     -2.1087963581085205e+00
    phi[6,2]  R1586     -4.1059449315071106e-01
    phi[6,2]  R1587     3.7506675720214844e-01
    phi[6,2]  R1588     0.302695095539093
    phi[6,2]  R1589     0.550740122795105
    phi[6,2]  R1590     9.8461306095123291e-01
    phi[6,2]  R1591     5.1730567216873169e-01
    phi[6,2]  R1592     -1.9616442918777466e+00
    phi[6,2]  R1593     -3.8356816768646240e-01
    phi[6,2]  R1594     0.00273551931604743
    phi[6,2]  R1595     1.34242582321167
    phi[6,2]  R1596     -2.0860948562622070e+00
    phi[6,2]  R1597     -1.3416309356689453e+00
    phi[6,2]  R1598     -1.2164822816848755e+00
    phi[6,2]  R1599     -1.9608197212219238e+00
    phi[6,2]  R1600     -1.4012874364852905e+00
    phi[6,2]  R1601     -2.0051162242889404e+00
    phi[6,2]  R1602     -1.4596840143203735e+00
    phi[6,2]  R1603     -1.4440631866455078e+00
    phi[6,2]  R1604     -1.0570718050003052e+00
    phi[6,2]  R1605     -2.6349279880523682e+00
    phi[6,2]  R1606     -1.2938522100448608e+00
    phi[6,2]  R1607     -8.5892552137374878e-01
    phi[6,2]  R1608     -1.1797974109649658e+00
    phi[6,2]  R1609     -8.8280421495437622e-01
    phi[6,2]  R1610     -2.8812637329101562e+00
    phi[6,2]  R1611     -2.4601900577545166e+00
    phi[6,2]  R1612     -1.5331609249114990e+00
    phi[6,2]  R1613     -2.1858911514282227e+00
    phi[6,2]  R1614     -2.3903067111968994e+00
    phi[6,2]  R1615     -1.6348053216934204e+00
    phi[6,2]  R1616     -1.2297774553298950e+00
    phi[6,2]  R1617     -9.3449252843856812e-01
    phi[6,2]  R1618     -1.2131445407867432e+00
    phi[6,2]  R1619     -2.5646109580993652e+00
    phi[6,2]  R1620     -1.6964511871337891e+00
    phi[6,2]  R1621     -1.2094031572341919e+00
    phi[6,2]  R1622     -1.9356056451797485e+00
    phi[6,2]  R1623     -1.7371383905410767e+00
    phi[6,2]  R1624     -2.9033150672912598e+00
    phi[6,2]  R1625     -2.0469884872436523e+00
    phi[6,2]  R1626     -6.2335073947906494e-01
    phi[6,2]  R1627     1.3653816282749176e-01
    phi[6,2]  R1628     -4.2586025595664978e-01
    phi[6,2]  R1629     -2.1545362472534180e+00
    phi[6,2]  R1630     -9.8929077386856079e-01
    phi[6,2]  R1631     -2.2704544067382812e+00
    phi[6,2]  R1632     -1.2108964920043945e+00
    phi[6,2]  R1633     -2.2265682220458984e+00
    phi[6,2]  R1634     -1.33949613571167
    phi[6,2]  R1635     -1.4865072965621948e+00
    phi[6,2]  R1636     -5.1061987876892090e-01
    phi[6,2]  R1637     -1.8176695108413696e+00
    phi[6,2]  R1638     -5.3430527448654175e-01
    phi[6,2]  R1639     -1.3052258491516113e+00
    phi[6,2]  R1640     -1.2581969499588013e+00
    phi[6,2]  R1641     -0.682050883769989
    phi[6,2]  R1642     -7.0810538530349731e-01
    phi[6,2]  R1643     -1.4164376258850098e+00
    phi[6,2]  R1644     -9.9098873138427734e-01
    phi[6,2]  R1645     -1.7632838487625122e+00
    phi[6,2]  R1646     -2.3081879317760468e-01
    phi[6,2]  R1647     -1.0673549175262451e+00
    phi[6,2]  R1648     -1.9283260107040405e+00
    phi[6,2]  R1649     -1.4222410917282104e+00
    phi[6,2]  R1650     -1.77421236038208
    phi[6,2]  R1651     -2.3799364566802979e+00
    phi[6,2]  R1652     -4.5930331945419312e-01
    phi[6,2]  R1653     -1.1929981708526611e+00
    phi[6,2]  R1654     -4.8560982942581177e-01
    phi[6,2]  R1655     -1.6701107025146484e+00
    phi[6,2]  R1656     -4.7812661528587341e-01
    phi[6,2]  R1657     -1.8687337636947632e+00
    phi[6,2]  R1658     -1.9820977449417114e+00
    phi[6,2]  R1659     -3.1967043876647949e+00
    phi[6,2]  R1660     -1.1853843927383423e+00
    phi[6,2]  R1661     -3.1305823326110840e+00
    phi[6,2]  R1662     5.7931149005889893e-01
    phi[6,2]  R1663     7.5891190767288208e-01
    phi[6,2]  R1664     2.6554688811302185e-01
    phi[6,2]  R1665     -9.2355078458786011e-01
    phi[3,5]  R27       1
    phi[3,5]  R28       1
    phi[3,5]  R45       -1
    phi[3,5]  R1666     -3.0999999046325684e+00
    phi[3,5]  R1667     -3.0999999046325684e+00
    phi[3,5]  R1668     -2.2400000095367432e+00
    phi[3,5]  R1669     -2.2400000095367432e+00
    phi[3,5]  R1670     -3.0999999046325684e+00
    phi[3,5]  R1671     -3.0999999046325684e+00
    phi[3,5]  R1672     -2.5699999332427979e+00
    phi[3,5]  R1673     -2.5699999332427979e+00
    phi[3,5]  R1674     -3.0999999046325684e+00
    phi[3,5]  R1675     -3.0999999046325684e+00
    phi[3,5]  R1676     -2.0899999141693115e+00
    phi[3,5]  R1677     -2.0899999141693115e+00
    phi[3,5]  R1678     -3.0999999046325684e+00
    phi[3,5]  R1679     -3.0999999046325684e+00
    phi[3,5]  R1680     1.0409064292907715e+00
    phi[3,5]  R1681     1.8636420965194702e+00
    phi[3,5]  R1682     -1.3719923496246338e+00
    phi[3,5]  R1683     -1.4194954633712769e+00
    phi[3,5]  R1684     -1.5436004400253296e+00
    phi[3,5]  R1685     3.6576864123344421e-01
    phi[3,5]  R1686     1.4695732593536377e+00
    phi[3,5]  R1687     1.7430297136306763e+00
    phi[3,5]  R1688     1.2018660306930542e+00
    phi[3,5]  R1689     8.8693320751190186e-01
    phi[3,5]  R1690     -1.9800482988357544e+00
    phi[3,5]  R1691     4.6119123697280884e-01
    phi[3,5]  R1692     -1.2527037858963013e+00
    phi[3,5]  R1693     -8.1338649988174438e-01
    phi[3,5]  R1694     -1.4177453517913818e+00
    phi[3,5]  R1695     1.0714820623397827e+00
    phi[3,5]  R1696     9.2184841632843018e-01
    phi[3,5]  R1697     -6.6808617115020752e-01
    phi[3,5]  R1698     -7.4516147375106812e-01
    phi[3,5]  R1699     -1.5168772637844086e-01
    phi[3,5]  R1700     -1.1100964546203613e+00
    phi[3,5]  R1701     2.9854935407638550e-01
    phi[3,5]  R1702     1.3235869407653809e+00
    phi[3,5]  R1703     -3.7355655431747437e-01
    phi[3,5]  R1704     -2.0636042952537537e-01
    phi[3,5]  R1705     9.0924799442291260e-02
    phi[3,5]  R1706     1.9307342171669006e-01
    phi[3,5]  R1707     5.7279783487319946e-01
    phi[3,5]  R1708     -2.3466280102729797e-01
    phi[3,5]  R1709     2.2995056211948395e-01
    phi[3,5]  R1710     8.0544435977935791e-01
    phi[3,5]  R1711     0.973087728023529
    phi[3,5]  R1712     1.2180260419845581e+00
    phi[3,5]  R1713     4.8487940430641174e-01
    phi[3,5]  R1714     -1.4006030559539795e+00
    phi[3,5]  R1715     -1.4972023963928223e+00
    phi[3,5]  R1716     1.2359386682510376e+00
    phi[3,5]  R1717     1.0257400274276733e+00
    phi[3,5]  R1718     5.2839678525924683e-01
    phi[3,5]  R1719     9.5671236515045166e-01
    phi[3,5]  R1720     -1.2434377670288086e+00
    phi[3,5]  R1721     -1.5167493820190430e+00
    phi[3,5]  R1722     -1.2203935384750366e+00
    phi[3,5]  R1723     -1.7819712162017822e+00
    phi[3,5]  R1724     -1.6413147449493408e+00
    phi[3,5]  R1725     -8.6682152748107910e-01
    phi[3,5]  R1726     -0.997409462928772
    phi[3,5]  R1727     -1.6971688270568848e+00
    phi[3,5]  R1728     -1.5470626354217529e+00
    phi[3,5]  R1729     -1.8657522201538086e+00
    phi[3,5]  R1730     -3.7779641151428223e-01
    phi[3,5]  R1731     1.7627835273742676e-01
    phi[3,5]  R1732     -6.9049972295761108e-01
    phi[3,5]  R1733     -6.5015208721160889e-01
    phi[3,5]  R1734     -1.0731520652770996e+00
    phi[3,5]  R1735     -1.2784301042556763e+00
    phi[3,5]  R1736     -5.7238382101058960e-01
    phi[3,5]  R1737     -2.0980405807495117e+00
    phi[3,5]  R1738     -2.2275238037109375e+00
    phi[3,5]  R1739     -2.1541481018066406e+00
    phi[3,5]  R1740     -1.0098798274993896e+00
    phi[3,5]  R1741     -1.2326946258544922e+00
    phi[3,5]  R1742     -4.0620538592338562e-01
    phi[3,5]  R1743     -6.7001998424530029e-01
    phi[3,5]  R1744     -0.499702513217926
    phi[3,5]  R1745     -2.5419056415557861e+00
    phi[3,5]  R1746     -2.0639407634735107e+00
    phi[3,5]  R1747     5.7012975215911865e-01
    phi[3,5]  R1748     -8.0350227653980255e-02
    phi[3,5]  R1749     -5.5077087879180908e-01
    phi[3,5]  R1750     1.6380780935287476e-01
    phi[3,5]  R1751     2.6567700505256653e-01
    phi[3,5]  R1752     -1.0277023315429688e+00
    phi[3,5]  R1753     -2.6975749060511589e-03
    phi[3,5]  R1754     -1.8068439960479736e+00
    phi[3,5]  R1755     6.5805412828922272e-02
    phi[3,5]  R1756     6.0065108537673950e-01
    phi[3,5]  R1757     -2.0738284587860107e+00
    phi[3,5]  R1758     -1.9757531881332397e+00
    phi[3,5]  R1759     -0.684005856513977
    phi[3,5]  R1760     7.1532171964645386e-01
    phi[3,5]  R1761     -5.0004631280899048e-02
    phi[3,5]  R1762     -6.5592658519744873e-01
    phi[3,5]  R1763     5.6433415412902832e-01
    phi[3,5]  R1764     8.6142492294311523e-01
    phi[3,5]  R1765     -2.0558822154998779e+00
    phi[3,5]  R1766     -1.1305016279220581e+00
    phi[3,5]  R1767     -1.7250468730926514e+00
    phi[3,5]  R1768     -2.0856688022613525e+00
    phi[3,5]  R1769     -2.5460817813873291e+00
    phi[3,5]  R1770     -2.2219960689544678e+00
    phi[3,5]  R1771     4.5952093601226807e-01
    phi[3,5]  R1772     -4.5258036255836487e-01
    phi[3,5]  R1773     -1.7169950008392334e+00
    phi[3,5]  R1774     -2.7968106269836426e+00
    phi[3,5]  R1775     7.1914279460906982e-01
    phi[3,5]  R1776     -1.9644308090209961e+00
    phi[3,5]  R1777     -1.4859426021575928e+00
    phi[3,5]  R1778     -2.2357513904571533e+00
    phi[3,5]  R1779     -2.1062147617340088e+00
    phi[3,5]  R1780     5.0073277950286865e-01
    phi[3,5]  R1781     5.6562179327011108e-01
    phi[3,5]  R1782     -0.819481372833252
    phi[3,5]  R1783     -1.6407839059829712e+00
    phi[3,5]  R1784     -2.5702476501464844e+00
    phi[3,5]  R1785     -1.0241162031888962e-02
    phi[3,5]  R1786     1.9017034769058228e-01
    phi[3,5]  R1787     4.0468281507492065e-01
    phi[3,5]  R1788     1.0109093040227890e-01
    phi[3,5]  R1789     -1.0985653102397919e-01
    phi[3,5]  R1790     -1.7182637453079224e+00
    phi[3,5]  R1791     3.0702481046319008e-02
    phi[3,5]  R1792     0.655983030796051
    phi[3,5]  R1793     7.6226696372032166e-02
    phi[3,5]  R1794     -2.4709425866603851e-01
    phi[3,5]  R1795     -7.7672761678695679e-01
    phi[3,5]  R1796     -7.0843201875686646e-01
    phi[3,5]  R1797     -4.8143498599529266e-02
    phi[3,5]  R1798     -0.610497772693634
    phi[3,5]  R1799     -1.4331958293914795e+00
    phi[5,3]  R27       -1
    phi[5,3]  R45       1
    phi[5,3]  R46       1
    phi[5,3]  R1800     -3.0999999046325684e+00
    phi[5,3]  R1801     -3.0999999046325684e+00
    phi[5,3]  R1802     -2.2400000095367432e+00
    phi[5,3]  R1803     -2.2400000095367432e+00
    phi[5,3]  R1804     -3.0999999046325684e+00
    phi[5,3]  R1805     -3.0999999046325684e+00
    phi[5,3]  R1806     -2.5699999332427979e+00
    phi[5,3]  R1807     -2.5699999332427979e+00
    phi[5,3]  R1808     -3.0999999046325684e+00
    phi[5,3]  R1809     -3.0999999046325684e+00
    phi[5,3]  R1810     -2.0899999141693115e+00
    phi[5,3]  R1811     -2.0899999141693115e+00
    phi[5,3]  R1812     -3.0999999046325684e+00
    phi[5,3]  R1813     -3.0999999046325684e+00
    phi[5,3]  R1814     8.0544435977935791e-01
    phi[5,3]  R1815     0.973087728023529
    phi[5,3]  R1816     1.2180260419845581e+00
    phi[5,3]  R1817     4.8487940430641174e-01
    phi[5,3]  R1818     -1.4006030559539795e+00
    phi[5,3]  R1819     -1.4972023963928223e+00
    phi[5,3]  R1820     1.2359386682510376e+00
    phi[5,3]  R1821     1.0257400274276733e+00
    phi[5,3]  R1822     5.2839678525924683e-01
    phi[5,3]  R1823     9.5671236515045166e-01
    phi[5,3]  R1824     -1.2434377670288086e+00
    phi[5,3]  R1825     -1.5167493820190430e+00
    phi[5,3]  R1826     -1.2203935384750366e+00
    phi[5,3]  R1827     -1.7819712162017822e+00
    phi[5,3]  R1828     -1.6413147449493408e+00
    phi[5,3]  R1829     -8.6682152748107910e-01
    phi[5,3]  R1830     -0.997409462928772
    phi[5,3]  R1831     -1.6971688270568848e+00
    phi[5,3]  R1832     -1.5470626354217529e+00
    phi[5,3]  R1833     -1.8657522201538086e+00
    phi[5,3]  R1834     -3.7779641151428223e-01
    phi[5,3]  R1835     1.7627835273742676e-01
    phi[5,3]  R1836     -6.9049972295761108e-01
    phi[5,3]  R1837     -6.5015208721160889e-01
    phi[5,3]  R1838     -1.0731520652770996e+00
    phi[5,3]  R1839     -1.2784301042556763e+00
    phi[5,3]  R1840     -5.7238382101058960e-01
    phi[5,3]  R1841     -2.0980405807495117e+00
    phi[5,3]  R1842     -2.2275238037109375e+00
    phi[5,3]  R1843     -2.1541481018066406e+00
    phi[5,3]  R1844     -1.0098798274993896e+00
    phi[5,3]  R1845     -1.2326946258544922e+00
    phi[5,3]  R1846     -4.0620538592338562e-01
    phi[5,3]  R1847     -6.7001998424530029e-01
    phi[5,3]  R1848     -0.499702513217926
    phi[5,3]  R1849     -2.5419056415557861e+00
    phi[5,3]  R1850     -2.0639407634735107e+00
    phi[5,3]  R1851     5.7012975215911865e-01
    phi[5,3]  R1852     -8.0350227653980255e-02
    phi[5,3]  R1853     -5.5077087879180908e-01
    phi[5,3]  R1854     1.6380780935287476e-01
    phi[5,3]  R1855     2.6567700505256653e-01
    phi[5,3]  R1856     -1.0277023315429688e+00
    phi[5,3]  R1857     -2.6975749060511589e-03
    phi[5,3]  R1858     -1.8068439960479736e+00
    phi[5,3]  R1859     6.5805412828922272e-02
    phi[5,3]  R1860     6.0065108537673950e-01
    phi[5,3]  R1861     -2.0738284587860107e+00
    phi[5,3]  R1862     -1.9757531881332397e+00
    phi[5,3]  R1863     -0.684005856513977
    phi[5,3]  R1864     7.1532171964645386e-01
    phi[5,3]  R1865     -5.0004631280899048e-02
    phi[5,3]  R1866     -6.5592658519744873e-01
    phi[5,3]  R1867     5.6433415412902832e-01
    phi[5,3]  R1868     8.6142492294311523e-01
    phi[5,3]  R1869     -2.0558822154998779e+00
    phi[5,3]  R1870     -1.1305016279220581e+00
    phi[5,3]  R1871     -1.7250468730926514e+00
    phi[5,3]  R1872     -2.0856688022613525e+00
    phi[5,3]  R1873     -2.5460817813873291e+00
    phi[5,3]  R1874     -2.2219960689544678e+00
    phi[5,3]  R1875     4.5952093601226807e-01
    phi[5,3]  R1876     -4.5258036255836487e-01
    phi[5,3]  R1877     -1.7169950008392334e+00
    phi[5,3]  R1878     -2.7968106269836426e+00
    phi[5,3]  R1879     7.1914279460906982e-01
    phi[5,3]  R1880     -1.9644308090209961e+00
    phi[5,3]  R1881     -1.4859426021575928e+00
    phi[5,3]  R1882     -2.2357513904571533e+00
    phi[5,3]  R1883     -2.1062147617340088e+00
    phi[5,3]  R1884     5.0073277950286865e-01
    phi[5,3]  R1885     5.6562179327011108e-01
    phi[5,3]  R1886     -0.819481372833252
    phi[5,3]  R1887     -1.6407839059829712e+00
    phi[5,3]  R1888     -2.5702476501464844e+00
    phi[5,3]  R1889     -1.0241162031888962e-02
    phi[5,3]  R1890     1.9017034769058228e-01
    phi[5,3]  R1891     4.0468281507492065e-01
    phi[5,3]  R1892     1.0109093040227890e-01
    phi[5,3]  R1893     -1.0985653102397919e-01
    phi[5,3]  R1894     -1.7182637453079224e+00
    phi[5,3]  R1895     3.0702481046319008e-02
    phi[5,3]  R1896     0.655983030796051
    phi[5,3]  R1897     7.6226696372032166e-02
    phi[5,3]  R1898     -2.4709425866603851e-01
    phi[5,3]  R1899     -7.7672761678695679e-01
    phi[5,3]  R1900     -7.0843201875686646e-01
    phi[5,3]  R1901     -4.8143498599529266e-02
    phi[5,3]  R1902     -0.610497772693634
    phi[5,3]  R1903     -1.4331958293914795e+00
    phi[5,3]  R1904     1.0409064292907715e+00
    phi[5,3]  R1905     1.8636420965194702e+00
    phi[5,3]  R1906     -1.3719923496246338e+00
    phi[5,3]  R1907     -1.4194954633712769e+00
    phi[5,3]  R1908     -1.5436004400253296e+00
    phi[5,3]  R1909     3.6576864123344421e-01
    phi[5,3]  R1910     1.4695732593536377e+00
    phi[5,3]  R1911     1.7430297136306763e+00
    phi[5,3]  R1912     1.2018660306930542e+00
    phi[5,3]  R1913     8.8693320751190186e-01
    phi[5,3]  R1914     -1.9800482988357544e+00
    phi[5,3]  R1915     4.6119123697280884e-01
    phi[5,3]  R1916     -1.2527037858963013e+00
    phi[5,3]  R1917     -8.1338649988174438e-01
    phi[5,3]  R1918     -1.4177453517913818e+00
    phi[5,3]  R1919     1.0714820623397827e+00
    phi[5,3]  R1920     9.2184841632843018e-01
    phi[5,3]  R1921     -6.6808617115020752e-01
    phi[5,3]  R1922     -7.4516147375106812e-01
    phi[5,3]  R1923     -1.5168772637844086e-01
    phi[5,3]  R1924     -1.1100964546203613e+00
    phi[5,3]  R1925     2.9854935407638550e-01
    phi[5,3]  R1926     1.3235869407653809e+00
    phi[5,3]  R1927     -3.7355655431747437e-01
    phi[5,3]  R1928     -2.0636042952537537e-01
    phi[5,3]  R1929     9.0924799442291260e-02
    phi[5,3]  R1930     1.9307342171669006e-01
    phi[5,3]  R1931     5.7279783487319946e-01
    phi[5,3]  R1932     -2.3466280102729797e-01
    phi[5,3]  R1933     2.2995056211948395e-01
    phi[3,6]  R27       1
    phi[3,6]  R28       1
    phi[3,6]  R54       -1
    phi[3,6]  R1934     -3.0999999046325684e+00
    phi[3,6]  R1935     -3.0999999046325684e+00
    phi[3,6]  R1936     -2.2400000095367432e+00
    phi[3,6]  R1937     -2.2400000095367432e+00
    phi[3,6]  R1938     -3.0999999046325684e+00
    phi[3,6]  R1939     -3.0999999046325684e+00
    phi[3,6]  R1940     -2.5699999332427979e+00
    phi[3,6]  R1941     -2.5699999332427979e+00
    phi[3,6]  R1942     -3.0999999046325684e+00
    phi[3,6]  R1943     -3.0999999046325684e+00
    phi[3,6]  R1944     -2.0899999141693115e+00
    phi[3,6]  R1945     -2.0899999141693115e+00
    phi[3,6]  R1946     -3.0999999046325684e+00
    phi[3,6]  R1947     -3.0999999046325684e+00
    phi[3,6]  R1948     1.0409064292907715e+00
    phi[3,6]  R1949     1.8636420965194702e+00
    phi[3,6]  R1950     -1.3719923496246338e+00
    phi[3,6]  R1951     -1.4194954633712769e+00
    phi[3,6]  R1952     -1.5436004400253296e+00
    phi[3,6]  R1953     3.6576864123344421e-01
    phi[3,6]  R1954     1.4695732593536377e+00
    phi[3,6]  R1955     1.7430297136306763e+00
    phi[3,6]  R1956     1.2018660306930542e+00
    phi[3,6]  R1957     8.8693320751190186e-01
    phi[3,6]  R1958     -1.9800482988357544e+00
    phi[3,6]  R1959     4.6119123697280884e-01
    phi[3,6]  R1960     -1.2527037858963013e+00
    phi[3,6]  R1961     -8.1338649988174438e-01
    phi[3,6]  R1962     -1.4177453517913818e+00
    phi[3,6]  R1963     1.0714820623397827e+00
    phi[3,6]  R1964     9.2184841632843018e-01
    phi[3,6]  R1965     -6.6808617115020752e-01
    phi[3,6]  R1966     -7.4516147375106812e-01
    phi[3,6]  R1967     -1.5168772637844086e-01
    phi[3,6]  R1968     -1.1100964546203613e+00
    phi[3,6]  R1969     2.9854935407638550e-01
    phi[3,6]  R1970     1.3235869407653809e+00
    phi[3,6]  R1971     -3.7355655431747437e-01
    phi[3,6]  R1972     -2.0636042952537537e-01
    phi[3,6]  R1973     9.0924799442291260e-02
    phi[3,6]  R1974     1.9307342171669006e-01
    phi[3,6]  R1975     5.7279783487319946e-01
    phi[3,6]  R1976     -2.3466280102729797e-01
    phi[3,6]  R1977     2.2995056211948395e-01
    phi[3,6]  R1978     7.9740768671035767e-01
    phi[3,6]  R1979     1.6698783636093140e+00
    phi[3,6]  R1980     2.1052714437246323e-02
    phi[3,6]  R1981     1.0540287494659424e+00
    phi[3,6]  R1982     -1.7421831190586090e-01
    phi[3,6]  R1983     1.4089368581771851e+00
    phi[3,6]  R1984     -3.3452877402305603e-01
    phi[3,6]  R1985     1.1671119928359985e+00
    phi[3,6]  R1986     1.6902462244033813e+00
    phi[3,6]  R1987     1.2835736274719238e+00
    phi[3,6]  R1988     -2.5479822158813477e+00
    phi[3,6]  R1989     -3.4511647224426270e+00
    phi[3,6]  R1990     -0.770904004573822
    phi[3,6]  R1991     -1.4467204809188843e+00
    phi[3,6]  R1992     -2.3574464321136475e+00
    phi[3,6]  R1993     6.3520956039428711e-01
    phi[3,6]  R1994     -2.3900596797466278e-01
    phi[3,6]  R1995     -1.0942143201828003e+00
    phi[3,6]  R1996     1.7405757308006287e-01
    phi[3,6]  R1997     -2.7343741059303284e-01
    phi[3,6]  R1998     -2.2749118804931641e+00
    phi[3,6]  R1999     -3.4299910068511963e+00
    phi[3,6]  R2000     -9.2628955841064453e-01
    phi[3,6]  R2001     -7.5816780328750610e-01
    phi[3,6]  R2002     -7.7381461858749390e-01
    phi[3,6]  R2003     -1.1334320306777954e+00
    phi[3,6]  R2004     -2.1087963581085205e+00
    phi[6,3]  R27       -1
    phi[6,3]  R54       1
    phi[6,3]  R55       1
    phi[6,3]  R2005     -3.0999999046325684e+00
    phi[6,3]  R2006     -3.0999999046325684e+00
    phi[6,3]  R2007     -2.2400000095367432e+00
    phi[6,3]  R2008     -2.2400000095367432e+00
    phi[6,3]  R2009     -3.0999999046325684e+00
    phi[6,3]  R2010     -3.0999999046325684e+00
    phi[6,3]  R2011     -2.5699999332427979e+00
    phi[6,3]  R2012     -2.5699999332427979e+00
    phi[6,3]  R2013     -3.0999999046325684e+00
    phi[6,3]  R2014     -3.0999999046325684e+00
    phi[6,3]  R2015     -2.0899999141693115e+00
    phi[6,3]  R2016     -2.0899999141693115e+00
    phi[6,3]  R2017     -3.0999999046325684e+00
    phi[6,3]  R2018     -3.0999999046325684e+00
    phi[6,3]  R2019     7.9740768671035767e-01
    phi[6,3]  R2020     1.6698783636093140e+00
    phi[6,3]  R2021     2.1052714437246323e-02
    phi[6,3]  R2022     1.0540287494659424e+00
    phi[6,3]  R2023     -1.7421831190586090e-01
    phi[6,3]  R2024     1.4089368581771851e+00
    phi[6,3]  R2025     -3.3452877402305603e-01
    phi[6,3]  R2026     1.1671119928359985e+00
    phi[6,3]  R2027     1.6902462244033813e+00
    phi[6,3]  R2028     1.2835736274719238e+00
    phi[6,3]  R2029     -2.5479822158813477e+00
    phi[6,3]  R2030     -3.4511647224426270e+00
    phi[6,3]  R2031     -0.770904004573822
    phi[6,3]  R2032     -1.4467204809188843e+00
    phi[6,3]  R2033     -2.3574464321136475e+00
    phi[6,3]  R2034     6.3520956039428711e-01
    phi[6,3]  R2035     -2.3900596797466278e-01
    phi[6,3]  R2036     -1.0942143201828003e+00
    phi[6,3]  R2037     1.7405757308006287e-01
    phi[6,3]  R2038     -2.7343741059303284e-01
    phi[6,3]  R2039     -2.2749118804931641e+00
    phi[6,3]  R2040     -3.4299910068511963e+00
    phi[6,3]  R2041     -9.2628955841064453e-01
    phi[6,3]  R2042     -7.5816780328750610e-01
    phi[6,3]  R2043     -7.7381461858749390e-01
    phi[6,3]  R2044     -1.1334320306777954e+00
    phi[6,3]  R2045     -2.1087963581085205e+00
    phi[6,3]  R2046     1.0409064292907715e+00
    phi[6,3]  R2047     1.8636420965194702e+00
    phi[6,3]  R2048     -1.3719923496246338e+00
    phi[6,3]  R2049     -1.4194954633712769e+00
    phi[6,3]  R2050     -1.5436004400253296e+00
    phi[6,3]  R2051     3.6576864123344421e-01
    phi[6,3]  R2052     1.4695732593536377e+00
    phi[6,3]  R2053     1.7430297136306763e+00
    phi[6,3]  R2054     1.2018660306930542e+00
    phi[6,3]  R2055     8.8693320751190186e-01
    phi[6,3]  R2056     -1.9800482988357544e+00
    phi[6,3]  R2057     4.6119123697280884e-01
    phi[6,3]  R2058     -1.2527037858963013e+00
    phi[6,3]  R2059     -8.1338649988174438e-01
    phi[6,3]  R2060     -1.4177453517913818e+00
    phi[6,3]  R2061     1.0714820623397827e+00
    phi[6,3]  R2062     9.2184841632843018e-01
    phi[6,3]  R2063     -6.6808617115020752e-01
    phi[6,3]  R2064     -7.4516147375106812e-01
    phi[6,3]  R2065     -1.5168772637844086e-01
    phi[6,3]  R2066     -1.1100964546203613e+00
    phi[6,3]  R2067     2.9854935407638550e-01
    phi[6,3]  R2068     1.3235869407653809e+00
    phi[6,3]  R2069     -3.7355655431747437e-01
    phi[6,3]  R2070     -2.0636042952537537e-01
    phi[6,3]  R2071     9.0924799442291260e-02
    phi[6,3]  R2072     1.9307342171669006e-01
    phi[6,3]  R2073     5.7279783487319946e-01
    phi[6,3]  R2074     -2.3466280102729797e-01
    phi[6,3]  R2075     2.2995056211948395e-01
    phi[3,8]  R27       1
    phi[3,8]  R28       1
    phi[3,8]  R29       2.7127936661280603e+00
    phi[3,8]  R30       1.1765436619544698e+00
    phi[3,8]  R31       -4.6604687320369065e-01
    phi[3,8]  R32       2.5182059329197477e+00
    phi[3,8]  R33       7.2983711424221775e-01
    phi[3,8]  R34       1.7731150105510007e+00
    phi[3,8]  R35       -8.1291599655305635e-01
    phi[3,8]  R64       -1
    phi[3,8]  R2076     -3.8720623850450808e-01
    phi[3,8]  R2077     -5.8127935707606291e+00
    phi[3,8]  R2078     -1.0634563475822734e+00
    phi[3,8]  R2079     -3.4165436714912127e+00
    phi[3,8]  R2080     -3.5660467778362590e+00
    phi[3,8]  R2081     -2.6339530314288777e+00
    phi[3,8]  R2082     -5.1794000323050149e-02
    phi[3,8]  R2083     -5.0882058661625456e+00
    phi[3,8]  R2084     -2.3701627903903506e+00
    phi[3,8]  R2085     -3.8298370188747861e+00
    phi[3,8]  R2086     -3.1688490361831079e-01
    phi[3,8]  R2087     -3.8631149247203123e+00
    phi[3,8]  R2088     -3.9129159011856247e+00
    phi[3,8]  R2089     -2.2870839080795120e+00
    phi[3,8]  R2090     -1.8526607833175390e-02
    phi[3,8]  R2091     -2.2654930667848738e-02
    phi[3,8]  R2092     -8.6451213343214928e-02
    phi[3,8]  R2093     -1.0282037574706493e-01
    phi[3,8]  R2094     -1.5204540074250583e-01
    phi[3,8]  R2095     -2.2747682649671408e-01
    phi[3,8]  R2096     -2.9165821275628057e-01
    phi[3,8]  R2097     -3.3014755227878467e-01
    phi[3,8]  R2098     -3.7623623489966707e-01
    phi[3,8]  R2099     -3.9477697698159253e-01
    phi[3,8]  R2100     -2.8833230425342538e-01
    phi[3,8]  R2101     -3.0880732244776687e-01
    phi[3,8]  R2102     -3.3432735735385510e-01
    phi[3,8]  R2103     -3.5097997137566661e-01
    phi[3,8]  R2104     -3.6113884454032985e-01
    phi[3,8]  R2105     -3.6836490893900331e-01
    phi[3,8]  R2106     -3.8143040971385034e-01
    phi[3,8]  R2107     -3.2260368128785917e+00
    phi[3,8]  R2108     -3.3067575823744049e+00
    phi[3,8]  R2109     -2.7422395617307505e+00
    phi[3,8]  R2110     -0.0958014656276518
    phi[3,8]  R2111     -9.9250309541660531e-02
    phi[3,8]  R2112     -1.4691441072593103e-01
    phi[3,8]  R2113     -3.3805265474438351e-01
    phi[3,8]  R2114     -3.5515189406265275e+00
    phi[3,8]  R2115     -2.8383247816864663e+00
    phi[3,8]  R2116     -3.3637743265795712e+00
    phi[3,8]  R2117     -2.7865369732561964e+00
    phi[3,8]  R2118     -2.7317531858494286e+00
    phi[3,8]  R2119     -3.2494066007422062e+00
    phi[4,5]  R36       1
    phi[4,5]  R37       1
    phi[4,5]  R45       -1
    phi[4,5]  R2120     -3.0999999046325684e+00
    phi[4,5]  R2121     -3.0999999046325684e+00
    phi[4,5]  R2122     -2.2400000095367432e+00
    phi[4,5]  R2123     -2.2400000095367432e+00
    phi[4,5]  R2124     -3.0999999046325684e+00
    phi[4,5]  R2125     -3.0999999046325684e+00
    phi[4,5]  R2126     -2.5699999332427979e+00
    phi[4,5]  R2127     -2.5699999332427979e+00
    phi[4,5]  R2128     -3.0999999046325684e+00
    phi[4,5]  R2129     -3.0999999046325684e+00
    phi[4,5]  R2130     -2.0899999141693115e+00
    phi[4,5]  R2131     -2.0899999141693115e+00
    phi[4,5]  R2132     -3.0999999046325684e+00
    phi[4,5]  R2133     -3.0999999046325684e+00
    phi[4,5]  R2134     7.5226908922195435e-01
    phi[4,5]  R2135     1.6495425999164581e-01
    phi[4,5]  R2136     -1.1229139566421509e+00
    phi[4,5]  R2137     -1.0249259471893311e+00
    phi[4,5]  R2138     -1.7554429173469543e-01
    phi[4,5]  R2139     -1.2616932392120361e+00
    phi[4,5]  R2140     1.2988551855087280e+00
    phi[4,5]  R2141     -3.5601291060447693e-01
    phi[4,5]  R2142     1.2248814105987549e+00
    phi[4,5]  R2143     1.3876349925994873e+00
    phi[4,5]  R2144     -1.6449849605560303e+00
    phi[4,5]  R2145     -1.5965505838394165e+00
    phi[4,5]  R2146     1.0506578683853149e+00
    phi[4,5]  R2147     -2.1532227993011475e+00
    phi[4,5]  R2148     -7.1489334106445312e-01
    phi[4,5]  R2149     -1.3149287700653076e+00
    phi[4,5]  R2150     -1.6483988761901855e+00
    phi[4,5]  R2151     -1.9498124122619629e+00
    phi[4,5]  R2152     -1.8240959644317627e+00
    phi[4,5]  R2153     -2.0620522499084473e+00
    phi[4,5]  R2154     -1.7782114744186401e+00
    phi[4,5]  R2155     -1.2523344755172729e+00
    phi[4,5]  R2156     -1.4362407922744751e+00
    phi[4,5]  R2157     -7.0883202552795410e-01
    phi[4,5]  R2158     8.7394618988037109e-01
    phi[4,5]  R2159     -2.0614743232727051e-01
    phi[4,5]  R2160     0.936630368232727
    phi[4,5]  R2161     9.5954102277755737e-01
    phi[4,5]  R2162     6.4390486478805542e-01
    phi[4,5]  R2163     1.1574842929840088e+00
    phi[4,5]  R2164     9.8944336175918579e-01
    phi[4,5]  R2165     5.6081300973892212e-01
    phi[4,5]  R2166     1.3382477760314941e+00
    phi[4,5]  R2167     -7.0380698889493942e-03
    phi[4,5]  R2168     1.1206274479627609e-01
    phi[4,5]  R2169     -6.6460907459259033e-01
    phi[4,5]  R2170     -8.9397162199020386e-01
    phi[4,5]  R2171     -1.1216098070144653e+00
    phi[4,5]  R2172     8.0544435977935791e-01
    phi[4,5]  R2173     0.973087728023529
    phi[4,5]  R2174     1.2180260419845581e+00
    phi[4,5]  R2175     4.8487940430641174e-01
    phi[4,5]  R2176     -1.4006030559539795e+00
    phi[4,5]  R2177     -1.4972023963928223e+00
    phi[4,5]  R2178     1.2359386682510376e+00
    phi[4,5]  R2179     1.0257400274276733e+00
    phi[4,5]  R2180     5.2839678525924683e-01
    phi[4,5]  R2181     9.5671236515045166e-01
    phi[4,5]  R2182     -1.2434377670288086e+00
    phi[4,5]  R2183     -1.5167493820190430e+00
    phi[4,5]  R2184     -1.2203935384750366e+00
    phi[4,5]  R2185     -1.7819712162017822e+00
    phi[4,5]  R2186     -1.6413147449493408e+00
    phi[4,5]  R2187     -8.6682152748107910e-01
    phi[4,5]  R2188     -0.997409462928772
    phi[4,5]  R2189     -1.6971688270568848e+00
    phi[4,5]  R2190     -1.5470626354217529e+00
    phi[4,5]  R2191     -1.8657522201538086e+00
    phi[4,5]  R2192     -3.7779641151428223e-01
    phi[4,5]  R2193     1.7627835273742676e-01
    phi[4,5]  R2194     -6.9049972295761108e-01
    phi[4,5]  R2195     -6.5015208721160889e-01
    phi[4,5]  R2196     -1.0731520652770996e+00
    phi[4,5]  R2197     -1.2784301042556763e+00
    phi[4,5]  R2198     -5.7238382101058960e-01
    phi[4,5]  R2199     -2.0980405807495117e+00
    phi[4,5]  R2200     -2.2275238037109375e+00
    phi[4,5]  R2201     -2.1541481018066406e+00
    phi[4,5]  R2202     -1.0098798274993896e+00
    phi[4,5]  R2203     -1.2326946258544922e+00
    phi[4,5]  R2204     -4.0620538592338562e-01
    phi[4,5]  R2205     -6.7001998424530029e-01
    phi[4,5]  R2206     -0.499702513217926
    phi[4,5]  R2207     -2.5419056415557861e+00
    phi[4,5]  R2208     -2.0639407634735107e+00
    phi[4,5]  R2209     5.7012975215911865e-01
    phi[4,5]  R2210     -8.0350227653980255e-02
    phi[4,5]  R2211     -5.5077087879180908e-01
    phi[4,5]  R2212     1.6380780935287476e-01
    phi[4,5]  R2213     2.6567700505256653e-01
    phi[4,5]  R2214     -1.0277023315429688e+00
    phi[4,5]  R2215     -2.6975749060511589e-03
    phi[4,5]  R2216     -1.8068439960479736e+00
    phi[4,5]  R2217     6.5805412828922272e-02
    phi[4,5]  R2218     6.0065108537673950e-01
    phi[4,5]  R2219     -2.0738284587860107e+00
    phi[4,5]  R2220     -1.9757531881332397e+00
    phi[4,5]  R2221     -0.684005856513977
    phi[4,5]  R2222     7.1532171964645386e-01
    phi[4,5]  R2223     -5.0004631280899048e-02
    phi[4,5]  R2224     -6.5592658519744873e-01
    phi[4,5]  R2225     5.6433415412902832e-01
    phi[4,5]  R2226     8.6142492294311523e-01
    phi[4,5]  R2227     -2.0558822154998779e+00
    phi[4,5]  R2228     -1.1305016279220581e+00
    phi[4,5]  R2229     -1.7250468730926514e+00
    phi[4,5]  R2230     -2.0856688022613525e+00
    phi[4,5]  R2231     -2.5460817813873291e+00
    phi[4,5]  R2232     -2.2219960689544678e+00
    phi[4,5]  R2233     4.5952093601226807e-01
    phi[4,5]  R2234     -4.5258036255836487e-01
    phi[4,5]  R2235     -1.7169950008392334e+00
    phi[4,5]  R2236     -2.7968106269836426e+00
    phi[4,5]  R2237     7.1914279460906982e-01
    phi[4,5]  R2238     -1.9644308090209961e+00
    phi[4,5]  R2239     -1.4859426021575928e+00
    phi[4,5]  R2240     -2.2357513904571533e+00
    phi[4,5]  R2241     -2.1062147617340088e+00
    phi[4,5]  R2242     5.0073277950286865e-01
    phi[4,5]  R2243     5.6562179327011108e-01
    phi[4,5]  R2244     -0.819481372833252
    phi[4,5]  R2245     -1.6407839059829712e+00
    phi[4,5]  R2246     -2.5702476501464844e+00
    phi[4,5]  R2247     -1.0241162031888962e-02
    phi[4,5]  R2248     1.9017034769058228e-01
    phi[4,5]  R2249     4.0468281507492065e-01
    phi[4,5]  R2250     1.0109093040227890e-01
    phi[4,5]  R2251     -1.0985653102397919e-01
    phi[4,5]  R2252     -1.7182637453079224e+00
    phi[4,5]  R2253     3.0702481046319008e-02
    phi[4,5]  R2254     0.655983030796051
    phi[4,5]  R2255     7.6226696372032166e-02
    phi[4,5]  R2256     -2.4709425866603851e-01
    phi[4,5]  R2257     -7.7672761678695679e-01
    phi[4,5]  R2258     -7.0843201875686646e-01
    phi[4,5]  R2259     -4.8143498599529266e-02
    phi[4,5]  R2260     -0.610497772693634
    phi[4,5]  R2261     -1.4331958293914795e+00
    phi[5,4]  R36       -1
    phi[5,4]  R45       1
    phi[5,4]  R46       1
    phi[5,4]  R2262     -3.0999999046325684e+00
    phi[5,4]  R2263     -3.0999999046325684e+00
    phi[5,4]  R2264     -2.2400000095367432e+00
    phi[5,4]  R2265     -2.2400000095367432e+00
    phi[5,4]  R2266     -3.0999999046325684e+00
    phi[5,4]  R2267     -3.0999999046325684e+00
    phi[5,4]  R2268     -2.5699999332427979e+00
    phi[5,4]  R2269     -2.5699999332427979e+00
    phi[5,4]  R2270     -3.0999999046325684e+00
    phi[5,4]  R2271     -3.0999999046325684e+00
    phi[5,4]  R2272     -2.0899999141693115e+00
    phi[5,4]  R2273     -2.0899999141693115e+00
    phi[5,4]  R2274     -3.0999999046325684e+00
    phi[5,4]  R2275     -3.0999999046325684e+00
    phi[5,4]  R2276     8.0544435977935791e-01
    phi[5,4]  R2277     0.973087728023529
    phi[5,4]  R2278     1.2180260419845581e+00
    phi[5,4]  R2279     4.8487940430641174e-01
    phi[5,4]  R2280     -1.4006030559539795e+00
    phi[5,4]  R2281     -1.4972023963928223e+00
    phi[5,4]  R2282     1.2359386682510376e+00
    phi[5,4]  R2283     1.0257400274276733e+00
    phi[5,4]  R2284     5.2839678525924683e-01
    phi[5,4]  R2285     9.5671236515045166e-01
    phi[5,4]  R2286     -1.2434377670288086e+00
    phi[5,4]  R2287     -1.5167493820190430e+00
    phi[5,4]  R2288     -1.2203935384750366e+00
    phi[5,4]  R2289     -1.7819712162017822e+00
    phi[5,4]  R2290     -1.6413147449493408e+00
    phi[5,4]  R2291     -8.6682152748107910e-01
    phi[5,4]  R2292     -0.997409462928772
    phi[5,4]  R2293     -1.6971688270568848e+00
    phi[5,4]  R2294     -1.5470626354217529e+00
    phi[5,4]  R2295     -1.8657522201538086e+00
    phi[5,4]  R2296     -3.7779641151428223e-01
    phi[5,4]  R2297     1.7627835273742676e-01
    phi[5,4]  R2298     -6.9049972295761108e-01
    phi[5,4]  R2299     -6.5015208721160889e-01
    phi[5,4]  R2300     -1.0731520652770996e+00
    phi[5,4]  R2301     -1.2784301042556763e+00
    phi[5,4]  R2302     -5.7238382101058960e-01
    phi[5,4]  R2303     -2.0980405807495117e+00
    phi[5,4]  R2304     -2.2275238037109375e+00
    phi[5,4]  R2305     -2.1541481018066406e+00
    phi[5,4]  R2306     -1.0098798274993896e+00
    phi[5,4]  R2307     -1.2326946258544922e+00
    phi[5,4]  R2308     -4.0620538592338562e-01
    phi[5,4]  R2309     -6.7001998424530029e-01
    phi[5,4]  R2310     -0.499702513217926
    phi[5,4]  R2311     -2.5419056415557861e+00
    phi[5,4]  R2312     -2.0639407634735107e+00
    phi[5,4]  R2313     5.7012975215911865e-01
    phi[5,4]  R2314     -8.0350227653980255e-02
    phi[5,4]  R2315     -5.5077087879180908e-01
    phi[5,4]  R2316     1.6380780935287476e-01
    phi[5,4]  R2317     2.6567700505256653e-01
    phi[5,4]  R2318     -1.0277023315429688e+00
    phi[5,4]  R2319     -2.6975749060511589e-03
    phi[5,4]  R2320     -1.8068439960479736e+00
    phi[5,4]  R2321     6.5805412828922272e-02
    phi[5,4]  R2322     6.0065108537673950e-01
    phi[5,4]  R2323     -2.0738284587860107e+00
    phi[5,4]  R2324     -1.9757531881332397e+00
    phi[5,4]  R2325     -0.684005856513977
    phi[5,4]  R2326     7.1532171964645386e-01
    phi[5,4]  R2327     -5.0004631280899048e-02
    phi[5,4]  R2328     -6.5592658519744873e-01
    phi[5,4]  R2329     5.6433415412902832e-01
    phi[5,4]  R2330     8.6142492294311523e-01
    phi[5,4]  R2331     -2.0558822154998779e+00
    phi[5,4]  R2332     -1.1305016279220581e+00
    phi[5,4]  R2333     -1.7250468730926514e+00
    phi[5,4]  R2334     -2.0856688022613525e+00
    phi[5,4]  R2335     -2.5460817813873291e+00
    phi[5,4]  R2336     -2.2219960689544678e+00
    phi[5,4]  R2337     4.5952093601226807e-01
    phi[5,4]  R2338     -4.5258036255836487e-01
    phi[5,4]  R2339     -1.7169950008392334e+00
    phi[5,4]  R2340     -2.7968106269836426e+00
    phi[5,4]  R2341     7.1914279460906982e-01
    phi[5,4]  R2342     -1.9644308090209961e+00
    phi[5,4]  R2343     -1.4859426021575928e+00
    phi[5,4]  R2344     -2.2357513904571533e+00
    phi[5,4]  R2345     -2.1062147617340088e+00
    phi[5,4]  R2346     5.0073277950286865e-01
    phi[5,4]  R2347     5.6562179327011108e-01
    phi[5,4]  R2348     -0.819481372833252
    phi[5,4]  R2349     -1.6407839059829712e+00
    phi[5,4]  R2350     -2.5702476501464844e+00
    phi[5,4]  R2351     -1.0241162031888962e-02
    phi[5,4]  R2352     1.9017034769058228e-01
    phi[5,4]  R2353     4.0468281507492065e-01
    phi[5,4]  R2354     1.0109093040227890e-01
    phi[5,4]  R2355     -1.0985653102397919e-01
    phi[5,4]  R2356     -1.7182637453079224e+00
    phi[5,4]  R2357     3.0702481046319008e-02
    phi[5,4]  R2358     0.655983030796051
    phi[5,4]  R2359     7.6226696372032166e-02
    phi[5,4]  R2360     -2.4709425866603851e-01
    phi[5,4]  R2361     -7.7672761678695679e-01
    phi[5,4]  R2362     -7.0843201875686646e-01
    phi[5,4]  R2363     -4.8143498599529266e-02
    phi[5,4]  R2364     -0.610497772693634
    phi[5,4]  R2365     -1.4331958293914795e+00
    phi[5,4]  R2366     7.5226908922195435e-01
    phi[5,4]  R2367     1.6495425999164581e-01
    phi[5,4]  R2368     -1.1229139566421509e+00
    phi[5,4]  R2369     -1.0249259471893311e+00
    phi[5,4]  R2370     -1.7554429173469543e-01
    phi[5,4]  R2371     -1.2616932392120361e+00
    phi[5,4]  R2372     1.2988551855087280e+00
    phi[5,4]  R2373     -3.5601291060447693e-01
    phi[5,4]  R2374     1.2248814105987549e+00
    phi[5,4]  R2375     1.3876349925994873e+00
    phi[5,4]  R2376     -1.6449849605560303e+00
    phi[5,4]  R2377     -1.5965505838394165e+00
    phi[5,4]  R2378     1.0506578683853149e+00
    phi[5,4]  R2379     -2.1532227993011475e+00
    phi[5,4]  R2380     -7.1489334106445312e-01
    phi[5,4]  R2381     -1.3149287700653076e+00
    phi[5,4]  R2382     -1.6483988761901855e+00
    phi[5,4]  R2383     -1.9498124122619629e+00
    phi[5,4]  R2384     -1.8240959644317627e+00
    phi[5,4]  R2385     -2.0620522499084473e+00
    phi[5,4]  R2386     -1.7782114744186401e+00
    phi[5,4]  R2387     -1.2523344755172729e+00
    phi[5,4]  R2388     -1.4362407922744751e+00
    phi[5,4]  R2389     -7.0883202552795410e-01
    phi[5,4]  R2390     8.7394618988037109e-01
    phi[5,4]  R2391     -2.0614743232727051e-01
    phi[5,4]  R2392     0.936630368232727
    phi[5,4]  R2393     9.5954102277755737e-01
    phi[5,4]  R2394     6.4390486478805542e-01
    phi[5,4]  R2395     1.1574842929840088e+00
    phi[5,4]  R2396     9.8944336175918579e-01
    phi[5,4]  R2397     5.6081300973892212e-01
    phi[5,4]  R2398     1.3382477760314941e+00
    phi[5,4]  R2399     -7.0380698889493942e-03
    phi[5,4]  R2400     1.1206274479627609e-01
    phi[5,4]  R2401     -6.6460907459259033e-01
    phi[5,4]  R2402     -8.9397162199020386e-01
    phi[5,4]  R2403     -1.1216098070144653e+00
    phi[5,6]  R45       1
    phi[5,6]  R46       1
    phi[5,6]  R54       -1
    phi[5,6]  R2404     -3.0999999046325684e+00
    phi[5,6]  R2405     -3.0999999046325684e+00
    phi[5,6]  R2406     -2.2400000095367432e+00
    phi[5,6]  R2407     -2.2400000095367432e+00
    phi[5,6]  R2408     -3.0999999046325684e+00
    phi[5,6]  R2409     -3.0999999046325684e+00
    phi[5,6]  R2410     -2.5699999332427979e+00
    phi[5,6]  R2411     -2.5699999332427979e+00
    phi[5,6]  R2412     -3.0999999046325684e+00
    phi[5,6]  R2413     -3.0999999046325684e+00
    phi[5,6]  R2414     -2.0899999141693115e+00
    phi[5,6]  R2415     -2.0899999141693115e+00
    phi[5,6]  R2416     -3.0999999046325684e+00
    phi[5,6]  R2417     -3.0999999046325684e+00
    phi[5,6]  R2418     8.0544435977935791e-01
    phi[5,6]  R2419     0.973087728023529
    phi[5,6]  R2420     1.2180260419845581e+00
    phi[5,6]  R2421     4.8487940430641174e-01
    phi[5,6]  R2422     -1.4006030559539795e+00
    phi[5,6]  R2423     -1.4972023963928223e+00
    phi[5,6]  R2424     1.2359386682510376e+00
    phi[5,6]  R2425     1.0257400274276733e+00
    phi[5,6]  R2426     5.2839678525924683e-01
    phi[5,6]  R2427     9.5671236515045166e-01
    phi[5,6]  R2428     -1.2434377670288086e+00
    phi[5,6]  R2429     -1.5167493820190430e+00
    phi[5,6]  R2430     -1.2203935384750366e+00
    phi[5,6]  R2431     -1.7819712162017822e+00
    phi[5,6]  R2432     -1.6413147449493408e+00
    phi[5,6]  R2433     -8.6682152748107910e-01
    phi[5,6]  R2434     -0.997409462928772
    phi[5,6]  R2435     -1.6971688270568848e+00
    phi[5,6]  R2436     -1.5470626354217529e+00
    phi[5,6]  R2437     -1.8657522201538086e+00
    phi[5,6]  R2438     -3.7779641151428223e-01
    phi[5,6]  R2439     1.7627835273742676e-01
    phi[5,6]  R2440     -6.9049972295761108e-01
    phi[5,6]  R2441     -6.5015208721160889e-01
    phi[5,6]  R2442     -1.0731520652770996e+00
    phi[5,6]  R2443     -1.2784301042556763e+00
    phi[5,6]  R2444     -5.7238382101058960e-01
    phi[5,6]  R2445     -2.0980405807495117e+00
    phi[5,6]  R2446     -2.2275238037109375e+00
    phi[5,6]  R2447     -2.1541481018066406e+00
    phi[5,6]  R2448     -1.0098798274993896e+00
    phi[5,6]  R2449     -1.2326946258544922e+00
    phi[5,6]  R2450     -4.0620538592338562e-01
    phi[5,6]  R2451     -6.7001998424530029e-01
    phi[5,6]  R2452     -0.499702513217926
    phi[5,6]  R2453     -2.5419056415557861e+00
    phi[5,6]  R2454     -2.0639407634735107e+00
    phi[5,6]  R2455     5.7012975215911865e-01
    phi[5,6]  R2456     -8.0350227653980255e-02
    phi[5,6]  R2457     -5.5077087879180908e-01
    phi[5,6]  R2458     1.6380780935287476e-01
    phi[5,6]  R2459     2.6567700505256653e-01
    phi[5,6]  R2460     -1.0277023315429688e+00
    phi[5,6]  R2461     -2.6975749060511589e-03
    phi[5,6]  R2462     -1.8068439960479736e+00
    phi[5,6]  R2463     6.5805412828922272e-02
    phi[5,6]  R2464     6.0065108537673950e-01
    phi[5,6]  R2465     -2.0738284587860107e+00
    phi[5,6]  R2466     -1.9757531881332397e+00
    phi[5,6]  R2467     -0.684005856513977
    phi[5,6]  R2468     7.1532171964645386e-01
    phi[5,6]  R2469     -5.0004631280899048e-02
    phi[5,6]  R2470     -6.5592658519744873e-01
    phi[5,6]  R2471     5.6433415412902832e-01
    phi[5,6]  R2472     8.6142492294311523e-01
    phi[5,6]  R2473     -2.0558822154998779e+00
    phi[5,6]  R2474     -1.1305016279220581e+00
    phi[5,6]  R2475     -1.7250468730926514e+00
    phi[5,6]  R2476     -2.0856688022613525e+00
    phi[5,6]  R2477     -2.5460817813873291e+00
    phi[5,6]  R2478     -2.2219960689544678e+00
    phi[5,6]  R2479     4.5952093601226807e-01
    phi[5,6]  R2480     -4.5258036255836487e-01
    phi[5,6]  R2481     -1.7169950008392334e+00
    phi[5,6]  R2482     -2.7968106269836426e+00
    phi[5,6]  R2483     7.1914279460906982e-01
    phi[5,6]  R2484     -1.9644308090209961e+00
    phi[5,6]  R2485     -1.4859426021575928e+00
    phi[5,6]  R2486     -2.2357513904571533e+00
    phi[5,6]  R2487     -2.1062147617340088e+00
    phi[5,6]  R2488     5.0073277950286865e-01
    phi[5,6]  R2489     5.6562179327011108e-01
    phi[5,6]  R2490     -0.819481372833252
    phi[5,6]  R2491     -1.6407839059829712e+00
    phi[5,6]  R2492     -2.5702476501464844e+00
    phi[5,6]  R2493     -1.0241162031888962e-02
    phi[5,6]  R2494     1.9017034769058228e-01
    phi[5,6]  R2495     4.0468281507492065e-01
    phi[5,6]  R2496     1.0109093040227890e-01
    phi[5,6]  R2497     -1.0985653102397919e-01
    phi[5,6]  R2498     -1.7182637453079224e+00
    phi[5,6]  R2499     3.0702481046319008e-02
    phi[5,6]  R2500     0.655983030796051
    phi[5,6]  R2501     7.6226696372032166e-02
    phi[5,6]  R2502     -2.4709425866603851e-01
    phi[5,6]  R2503     -7.7672761678695679e-01
    phi[5,6]  R2504     -7.0843201875686646e-01
    phi[5,6]  R2505     -4.8143498599529266e-02
    phi[5,6]  R2506     -0.610497772693634
    phi[5,6]  R2507     -1.4331958293914795e+00
    phi[5,6]  R2508     7.9740768671035767e-01
    phi[5,6]  R2509     1.6698783636093140e+00
    phi[5,6]  R2510     2.1052714437246323e-02
    phi[5,6]  R2511     1.0540287494659424e+00
    phi[5,6]  R2512     -1.7421831190586090e-01
    phi[5,6]  R2513     1.4089368581771851e+00
    phi[5,6]  R2514     -3.3452877402305603e-01
    phi[5,6]  R2515     1.1671119928359985e+00
    phi[5,6]  R2516     1.6902462244033813e+00
    phi[5,6]  R2517     1.2835736274719238e+00
    phi[5,6]  R2518     -2.5479822158813477e+00
    phi[5,6]  R2519     -3.4511647224426270e+00
    phi[5,6]  R2520     -0.770904004573822
    phi[5,6]  R2521     -1.4467204809188843e+00
    phi[5,6]  R2522     -2.3574464321136475e+00
    phi[5,6]  R2523     6.3520956039428711e-01
    phi[5,6]  R2524     -2.3900596797466278e-01
    phi[5,6]  R2525     -1.0942143201828003e+00
    phi[5,6]  R2526     1.7405757308006287e-01
    phi[5,6]  R2527     -2.7343741059303284e-01
    phi[5,6]  R2528     -2.2749118804931641e+00
    phi[5,6]  R2529     -3.4299910068511963e+00
    phi[5,6]  R2530     -9.2628955841064453e-01
    phi[5,6]  R2531     -7.5816780328750610e-01
    phi[5,6]  R2532     -7.7381461858749390e-01
    phi[5,6]  R2533     -1.1334320306777954e+00
    phi[5,6]  R2534     -2.1087963581085205e+00
    phi[6,5]  R45       -1
    phi[6,5]  R54       1
    phi[6,5]  R55       1
    phi[6,5]  R2535     -3.0999999046325684e+00
    phi[6,5]  R2536     -3.0999999046325684e+00
    phi[6,5]  R2537     -2.2400000095367432e+00
    phi[6,5]  R2538     -2.2400000095367432e+00
    phi[6,5]  R2539     -3.0999999046325684e+00
    phi[6,5]  R2540     -3.0999999046325684e+00
    phi[6,5]  R2541     -2.5699999332427979e+00
    phi[6,5]  R2542     -2.5699999332427979e+00
    phi[6,5]  R2543     -3.0999999046325684e+00
    phi[6,5]  R2544     -3.0999999046325684e+00
    phi[6,5]  R2545     -2.0899999141693115e+00
    phi[6,5]  R2546     -2.0899999141693115e+00
    phi[6,5]  R2547     -3.0999999046325684e+00
    phi[6,5]  R2548     -3.0999999046325684e+00
    phi[6,5]  R2549     7.9740768671035767e-01
    phi[6,5]  R2550     1.6698783636093140e+00
    phi[6,5]  R2551     2.1052714437246323e-02
    phi[6,5]  R2552     1.0540287494659424e+00
    phi[6,5]  R2553     -1.7421831190586090e-01
    phi[6,5]  R2554     1.4089368581771851e+00
    phi[6,5]  R2555     -3.3452877402305603e-01
    phi[6,5]  R2556     1.1671119928359985e+00
    phi[6,5]  R2557     1.6902462244033813e+00
    phi[6,5]  R2558     1.2835736274719238e+00
    phi[6,5]  R2559     -2.5479822158813477e+00
    phi[6,5]  R2560     -3.4511647224426270e+00
    phi[6,5]  R2561     -0.770904004573822
    phi[6,5]  R2562     -1.4467204809188843e+00
    phi[6,5]  R2563     -2.3574464321136475e+00
    phi[6,5]  R2564     6.3520956039428711e-01
    phi[6,5]  R2565     -2.3900596797466278e-01
    phi[6,5]  R2566     -1.0942143201828003e+00
    phi[6,5]  R2567     1.7405757308006287e-01
    phi[6,5]  R2568     -2.7343741059303284e-01
    phi[6,5]  R2569     -2.2749118804931641e+00
    phi[6,5]  R2570     -3.4299910068511963e+00
    phi[6,5]  R2571     -9.2628955841064453e-01
    phi[6,5]  R2572     -7.5816780328750610e-01
    phi[6,5]  R2573     -7.7381461858749390e-01
    phi[6,5]  R2574     -1.1334320306777954e+00
    phi[6,5]  R2575     -2.1087963581085205e+00
    phi[6,5]  R2576     8.0544435977935791e-01
    phi[6,5]  R2577     0.973087728023529
    phi[6,5]  R2578     1.2180260419845581e+00
    phi[6,5]  R2579     4.8487940430641174e-01
    phi[6,5]  R2580     -1.4006030559539795e+00
    phi[6,5]  R2581     -1.4972023963928223e+00
    phi[6,5]  R2582     1.2359386682510376e+00
    phi[6,5]  R2583     1.0257400274276733e+00
    phi[6,5]  R2584     5.2839678525924683e-01
    phi[6,5]  R2585     9.5671236515045166e-01
    phi[6,5]  R2586     -1.2434377670288086e+00
    phi[6,5]  R2587     -1.5167493820190430e+00
    phi[6,5]  R2588     -1.2203935384750366e+00
    phi[6,5]  R2589     -1.7819712162017822e+00
    phi[6,5]  R2590     -1.6413147449493408e+00
    phi[6,5]  R2591     -8.6682152748107910e-01
    phi[6,5]  R2592     -0.997409462928772
    phi[6,5]  R2593     -1.6971688270568848e+00
    phi[6,5]  R2594     -1.5470626354217529e+00
    phi[6,5]  R2595     -1.8657522201538086e+00
    phi[6,5]  R2596     -3.7779641151428223e-01
    phi[6,5]  R2597     1.7627835273742676e-01
    phi[6,5]  R2598     -6.9049972295761108e-01
    phi[6,5]  R2599     -6.5015208721160889e-01
    phi[6,5]  R2600     -1.0731520652770996e+00
    phi[6,5]  R2601     -1.2784301042556763e+00
    phi[6,5]  R2602     -5.7238382101058960e-01
    phi[6,5]  R2603     -2.0980405807495117e+00
    phi[6,5]  R2604     -2.2275238037109375e+00
    phi[6,5]  R2605     -2.1541481018066406e+00
    phi[6,5]  R2606     -1.0098798274993896e+00
    phi[6,5]  R2607     -1.2326946258544922e+00
    phi[6,5]  R2608     -4.0620538592338562e-01
    phi[6,5]  R2609     -6.7001998424530029e-01
    phi[6,5]  R2610     -0.499702513217926
    phi[6,5]  R2611     -2.5419056415557861e+00
    phi[6,5]  R2612     -2.0639407634735107e+00
    phi[6,5]  R2613     5.7012975215911865e-01
    phi[6,5]  R2614     -8.0350227653980255e-02
    phi[6,5]  R2615     -5.5077087879180908e-01
    phi[6,5]  R2616     1.6380780935287476e-01
    phi[6,5]  R2617     2.6567700505256653e-01
    phi[6,5]  R2618     -1.0277023315429688e+00
    phi[6,5]  R2619     -2.6975749060511589e-03
    phi[6,5]  R2620     -1.8068439960479736e+00
    phi[6,5]  R2621     6.5805412828922272e-02
    phi[6,5]  R2622     6.0065108537673950e-01
    phi[6,5]  R2623     -2.0738284587860107e+00
    phi[6,5]  R2624     -1.9757531881332397e+00
    phi[6,5]  R2625     -0.684005856513977
    phi[6,5]  R2626     7.1532171964645386e-01
    phi[6,5]  R2627     -5.0004631280899048e-02
    phi[6,5]  R2628     -6.5592658519744873e-01
    phi[6,5]  R2629     5.6433415412902832e-01
    phi[6,5]  R2630     8.6142492294311523e-01
    phi[6,5]  R2631     -2.0558822154998779e+00
    phi[6,5]  R2632     -1.1305016279220581e+00
    phi[6,5]  R2633     -1.7250468730926514e+00
    phi[6,5]  R2634     -2.0856688022613525e+00
    phi[6,5]  R2635     -2.5460817813873291e+00
    phi[6,5]  R2636     -2.2219960689544678e+00
    phi[6,5]  R2637     4.5952093601226807e-01
    phi[6,5]  R2638     -4.5258036255836487e-01
    phi[6,5]  R2639     -1.7169950008392334e+00
    phi[6,5]  R2640     -2.7968106269836426e+00
    phi[6,5]  R2641     7.1914279460906982e-01
    phi[6,5]  R2642     -1.9644308090209961e+00
    phi[6,5]  R2643     -1.4859426021575928e+00
    phi[6,5]  R2644     -2.2357513904571533e+00
    phi[6,5]  R2645     -2.1062147617340088e+00
    phi[6,5]  R2646     5.0073277950286865e-01
    phi[6,5]  R2647     5.6562179327011108e-01
    phi[6,5]  R2648     -0.819481372833252
    phi[6,5]  R2649     -1.6407839059829712e+00
    phi[6,5]  R2650     -2.5702476501464844e+00
    phi[6,5]  R2651     -1.0241162031888962e-02
    phi[6,5]  R2652     1.9017034769058228e-01
    phi[6,5]  R2653     4.0468281507492065e-01
    phi[6,5]  R2654     1.0109093040227890e-01
    phi[6,5]  R2655     -1.0985653102397919e-01
    phi[6,5]  R2656     -1.7182637453079224e+00
    phi[6,5]  R2657     3.0702481046319008e-02
    phi[6,5]  R2658     0.655983030796051
    phi[6,5]  R2659     7.6226696372032166e-02
    phi[6,5]  R2660     -2.4709425866603851e-01
    phi[6,5]  R2661     -7.7672761678695679e-01
    phi[6,5]  R2662     -7.0843201875686646e-01
    phi[6,5]  R2663     -4.8143498599529266e-02
    phi[6,5]  R2664     -0.610497772693634
    phi[6,5]  R2665     -1.4331958293914795e+00
    phi[6,8]  R54       1
    phi[6,8]  R55       1
    phi[6,8]  R56       2.7127936661280603e+00
    phi[6,8]  R57       1.1765436619544698e+00
    phi[6,8]  R58       -4.6604687320369065e-01
    phi[6,8]  R59       2.5182059329197477e+00
    phi[6,8]  R60       7.2983711424221775e-01
    phi[6,8]  R61       1.7731150105510007e+00
    phi[6,8]  R62       -8.1291599655305635e-01
    phi[6,8]  R64       -1
    phi[6,8]  R2666     -3.8720623850450808e-01
    phi[6,8]  R2667     -5.8127935707606291e+00
    phi[6,8]  R2668     -1.0634563475822734e+00
    phi[6,8]  R2669     -3.4165436714912127e+00
    phi[6,8]  R2670     -3.5660467778362590e+00
    phi[6,8]  R2671     -2.6339530314288777e+00
    phi[6,8]  R2672     -5.1794000323050149e-02
    phi[6,8]  R2673     -5.0882058661625456e+00
    phi[6,8]  R2674     -2.3701627903903506e+00
    phi[6,8]  R2675     -3.8298370188747861e+00
    phi[6,8]  R2676     -3.1688490361831079e-01
    phi[6,8]  R2677     -3.8631149247203123e+00
    phi[6,8]  R2678     -3.9129159011856247e+00
    phi[6,8]  R2679     -2.2870839080795120e+00
    phi[6,8]  R2680     -1.6489725934598520e-02
    phi[6,8]  R2681     -2.7274295059602327e-02
    phi[6,8]  R2682     -6.4604857005224281e-02
    phi[6,8]  R2683     -8.7297952645348564e-02
    phi[6,8]  R2684     -1.4373539028142135e-01
    phi[6,8]  R2685     -1.9261857903903379e-01
    phi[6,8]  R2686     -2.2941172139640292e-01
    phi[6,8]  R2687     -2.9147057678173582e-01
    phi[6,8]  R2688     -3.0070428392548876e-01
    phi[6,8]  R2689     -4.0770569875673912e-01
    phi[6,8]  R2690     -3.4537009955178988e-01
    phi[6,8]  R2691     -3.9698028714448963e-01
    phi[6,8]  R2692     -4.2214412033418042e-01
    phi[6,8]  R2693     -5.4837426298921632e-01
    phi[6,8]  R2694     -5.7044675883868057e-01
    phi[6,8]  R2695     -5.9215166539444741e-01
    phi[6,8]  R2696     -5.9705364322882326e-01
    phi[6,8]  R2697     -6.4575944348194492e-01
    phi[6,8]  R2698     -6.8245823807845984e-01
    phi[6,8]  R2699     -0.687268592570656
    phi[6,8]  R2700     -1.1018654265067029e-01
    phi[6,8]  R2701     -1.2214408466124427e-01
    phi[6,8]  R2702     -2.5922952848253544e-01
    phi[6,8]  R2703     -5.2488008008836484e-01
    phi[6,8]  R2704     -7.0030917861532715e-01
    phi[6,8]  R2705     -7.7252873953482082e-01
    phi[6,8]  R2706     -3.9962353804416337e+00
    MARKER    'MARKER'                 'INTEND'
    z[0,1,0]  R2        -1
    z[0,1,0]  R11       1
    z[0,1,0]  R65       -1
    z[0,1,0]  R66       1
    z[0,1,0]  R79       2.3703399300575256e-01
    z[0,1,0]  R80       -5.1966924220323563e-02
    z[0,1,0]  R81       -3.2384210824966431e-01
    z[0,1,0]  R82       -2.2580642998218536e-01
    z[0,1,0]  R83       -2.7220794558525085e-01
    z[0,1,0]  R84       1.3879048824310303e-01
    z[0,1,0]  R85       -3.5238423943519592e-01
    z[0,1,0]  R86       2.9622837901115417e-01
    z[0,1,0]  R87       3.8015949726104736e-01
    z[0,1,0]  R88       -1.8490074574947357e-01
    z[0,1,0]  R89       -7.3685050010681152e-01
    z[0,1,0]  R90       -1.4456748962402344e-01
    z[0,1,0]  R91       -5.7209278456866741e-03
    z[0,1,0]  R92       -1.8118970096111298e-01
    z[0,1,0]  R93       1.4800044894218445e-01
    z[0,1,0]  R94       1.0989877581596375e-01
    z[0,1,0]  R95       -1.5077717602252960e-01
    z[0,1,0]  R96       -2.1568293869495392e-01
    z[0,1,0]  R97       3.8670411705970764e-01
    z[0,1,0]  R98       2.8635779023170471e-01
    z[0,1,0]  R99       -5.7002358138561249e-02
    z[0,1,0]  R100      -2.8424862027168274e-01
    z[0,1,0]  R101      4.1324037313461304e-01
    z[0,1,0]  R102      -5.3474415093660355e-02
    z[0,1,0]  R103      1.7140798270702362e-01
    z[0,1,0]  R104      -7.2206601500511169e-02
    z[0,1,0]  R105      1.9241647422313690e-01
    z[0,1,0]  R106      2.4657995998859406e-01
    z[0,1,0]  R107      0.255929559469223
    z[0,1,0]  R108      -1.8523028492927551e-01
    z[0,1,0]  R109      -1.9604268670082092e-01
    z[0,1,0]  R110      -2.2875583171844482e-01
    z[0,1,0]  R111      -1.6787399351596832e-01
    z[0,1,0]  R112      9.0189540386199951e-01
    z[0,1,0]  R113      8.8136249780654907e-01
    z[0,1,0]  R114      8.4615147113800049e-01
    z[0,1,0]  R115      -3.2924351096153259e-01
    z[0,1,0]  R116      3.9918351918458939e-02
    z[0,1,0]  R117      -5.6306332349777222e-02
    z[0,1,0]  R118      -5.9193450212478638e-01
    z[0,1,0]  R119      -8.7908446788787842e-01
    z[0,1,0]  R120      -8.4026736021041870e-01
    z[0,1,0]  R121      -7.2747319936752319e-01
    z[0,1,0]  R122      -6.2574809789657593e-01
    z[0,1,0]  R123      -1.8546107411384583e-01
    z[0,1,0]  R124      3.2135257124900818e-01
    z[0,1,0]  R125      2.1261560916900635e-01
    z[0,1,0]  R126      3.8622301816940308e-01
    z[0,1,0]  R127      -6.2194317579269409e-01
    z[0,1,0]  R128      5.9298551082611084e-01
    z[0,1,0]  R129      -8.3533978462219238e-01
    z[0,1,0]  R130      -2.7348718047142029e-01
    z[0,1,0]  R131      6.3934868574142456e-01
    z[0,1,0]  R132      -2.1891364455223083e-01
    z[0,1,0]  R133      -3.1954467296600342e-01
    z[0,1,0]  R134      3.1205892562866211e-01
    z[0,1,0]  R135      3.0639445781707764e-01
    z[0,1,1]  R3        -1
    z[0,1,1]  R12       1
    z[0,1,1]  R67       -1
    z[0,1,1]  R68       1
    z[0,1,1]  R79       2.4043197929859161e-01
    z[0,1,1]  R80       2.6027753949165344e-01
    z[0,1,1]  R81       9.2512935400009155e-02
    z[0,1,1]  R82       2.8046226501464844e-01
    z[0,1,1]  R83       3.3027130365371704e-01
    z[0,1,1]  R84       1.9726713001728058e-01
    z[0,1,1]  R85       1.5464492142200470e-01
    z[0,1,1]  R86       0.165940061211586
    z[0,1,1]  R87       2.0005369186401367e-01
    z[0,1,1]  R88       1.3052280247211456e-01
    z[0,1,1]  R89       -2.7297571301460266e-01
    z[0,1,1]  R90       0.584796130657196
    z[0,1,1]  R91       6.5547966957092285e-01
    z[0,1,1]  R92       0.813894510269165
    z[0,1,1]  R93       -9.6482020616531372e-01
    z[0,1,1]  R94       -9.5070582628250122e-01
    z[0,1,1]  R95       -9.6304059028625488e-01
    z[0,1,1]  R96       -0.615744411945343
    z[0,1,1]  R97       -3.2791653275489807e-01
    z[0,1,1]  R98       -0.351236492395401
    z[0,1,1]  R99       8.8573509454727173e-01
    z[0,1,1]  R100      0.747351348400116
    z[0,1,1]  R101      0.515515148639679
    z[0,1,1]  R102      3.2899799942970276e-01
    z[0,1,1]  R103      -6.3394135236740112e-01
    z[0,1,1]  R104      -6.9849067926406860e-01
    z[0,1,1]  R105      -0.319276362657547
    z[0,1,1]  R106      2.5135436654090881e-01
    z[0,1,1]  R107      0.420491099357605
    z[0,1,1]  R108      2.5548499822616577e-01
    z[0,1,1]  R109      1.5653695166110992e-01
    z[0,1,1]  R110      1.7599220573902130e-01
    z[0,1,1]  R111      2.3999880254268646e-01
    z[0,1,1]  R112      1.9431927800178528e-01
    z[0,1,1]  R113      -1.5722972154617310e-01
    z[0,1,1]  R114      -1.4477474987506866e-01
    z[0,1,1]  R115      3.7604832649230957e-01
    z[0,1,1]  R116      0.689096212387085
    z[0,1,1]  R117      5.3424453735351562e-01
    z[0,1,1]  R118      4.8140963912010193e-01
    z[0,1,1]  R119      -7.9528607428073883e-02
    z[0,1,1]  R120      -2.2351981699466705e-01
    z[0,1,1]  R121      -1.5993355214595795e-01
    z[0,1,1]  R122      -3.0037540197372437e-01
    z[0,1,1]  R123      -3.6878433078527451e-02
    z[0,1,1]  R124      1.3351911678910255e-02
    z[0,1,1]  R125      1.3604276813566685e-02
    z[0,1,1]  R126      2.8984868526458740e-01
    z[0,1,1]  R127      2.1480667591094971e-01
    z[0,1,1]  R128      -0.0954454317688942
    z[0,1,1]  R129      8.9969672262668610e-02
    z[0,1,1]  R130      -1.0357370972633362e-01
    z[0,1,1]  R131      3.8562972098588943e-02
    z[0,1,1]  R132      7.2650928050279617e-03
    z[0,1,1]  R133      -1.8665449321269989e-01
    z[0,1,1]  R134      -3.9170585572719574e-02
    z[0,1,1]  R135      -5.0568240880966187e-01
    z[0,1,2]  R4        -1
    z[0,1,2]  R13       1
    z[0,1,2]  R69       -1
    z[0,1,2]  R70       1
    z[0,1,2]  R79       6.2348848581314087e-01
    z[0,1,2]  R80       5.1360601186752319e-01
    z[0,1,2]  R81       5.3082358837127686e-01
    z[0,1,2]  R82       -6.0419633984565735e-02
    z[0,1,2]  R83       2.1885776892304420e-02
    z[0,1,2]  R84       1.0903645306825638e-01
    z[0,1,2]  R85       4.9447467923164368e-01
    z[0,1,2]  R86       4.3094620108604431e-01
    z[0,1,2]  R87       0.00629103509709239
    z[0,1,2]  R88       -1.3276146352291107e-01
    z[0,1,2]  R89       -5.1149517297744751e-01
    z[0,1,2]  R90       2.4407340213656425e-02
    z[0,1,2]  R91       -0.159625843167305
    z[0,1,2]  R92       1.3904790580272675e-01
    z[0,1,2]  R93       2.1737396717071533e-02
    z[0,1,2]  R94       -5.3422104567289352e-02
    z[0,1,2]  R95       -5.8959450572729111e-02
    z[0,1,2]  R96       -7.4105370044708252e-01
    z[0,1,2]  R97       -7.4771988391876221e-01
    z[0,1,2]  R98       -7.4837243556976318e-01
    z[0,1,2]  R99       1.5689648687839508e-01
    z[0,1,2]  R100      -4.3000534176826477e-01
    z[0,1,2]  R101      4.9908763170242310e-01
    z[0,1,2]  R102      5.4806298017501831e-01
    z[0,1,2]  R103      5.8260971307754517e-01
    z[0,1,2]  R104      3.3097898960113525e-01
    z[0,1,2]  R105      -7.4524426460266113e-01
    z[0,1,2]  R106      3.3723658323287964e-01
    z[0,1,2]  R107      2.1254646778106689e-01
    z[0,1,2]  R108      3.6979696154594421e-01
    z[0,1,2]  R109      8.1125551462173462e-01
    z[0,1,2]  R110      8.3727121353149414e-01
    z[0,1,2]  R111      -3.9338001608848572e-01
    z[0,1,2]  R112      -6.8045049905776978e-02
    z[0,1,2]  R113      5.2481066435575485e-02
    z[0,1,2]  R114      2.3879086971282959e-01
    z[0,1,2]  R115      -2.5375235080718994e-01
    z[0,1,2]  R116      -2.2355543076992035e-01
    z[0,1,2]  R117      -1.0044532269239426e-01
    z[0,1,2]  R118      -5.8036994934082031e-01
    z[0,1,2]  R119      -1.7762959003448486e-01
    z[0,1,2]  R120      -3.6471266299486160e-02
    z[0,1,2]  R121      -3.6093726754188538e-01
    z[0,1,2]  R122      -3.0557924509048462e-01
    z[0,1,2]  R123      -1.9537086784839630e-01
    z[0,1,2]  R124      -1.2592333555221558e-01
    z[0,1,2]  R125      2.4499481916427612e-01
    z[0,1,2]  R126      -1.9908134639263153e-01
    z[0,1,2]  R127      -5.0699585676193237e-01
    z[0,1,2]  R128      3.3400547504425049e-01
    z[0,1,2]  R129      1.7254938185214996e-01
    z[0,1,2]  R130      -2.0253041386604309e-01
    z[0,1,2]  R131      -3.6949047446250916e-01
    z[0,1,2]  R132      -7.6224929094314575e-01
    z[0,1,2]  R133      5.7550603523850441e-03
    z[0,1,2]  R134      6.9921833276748657e-01
    z[0,1,2]  R135      3.4651690721511841e-01
    z[0,1,3]  R5        -1
    z[0,1,3]  R14       1
    z[0,1,3]  R71       -1
    z[0,1,3]  R72       1
    z[0,1,3]  R79       3.7029585242271423e-01
    z[0,1,3]  R80       -6.7879520356655121e-02
    z[0,1,3]  R81       0.385850191116333
    z[0,1,3]  R82       1.3266208767890930e-01
    z[0,1,3]  R83       5.3007531166076660e-01
    z[0,1,3]  R84       1.3118194043636322e-01
    z[0,1,3]  R85       1.6925455629825592e-01
    z[0,1,3]  R86       1.3480573892593384e-01
    z[0,1,3]  R87       -0.0965004414319992
    z[0,1,3]  R88       2.0687343180179596e-01
    z[0,1,3]  R89       -3.3261656761169434e-01
    z[0,1,3]  R90       -6.0069161653518677e-01
    z[0,1,3]  R91       -6.2040686607360840e-01
    z[0,1,3]  R92       -1.0429682582616806e-01
    z[0,1,3]  R93       0.0641801655292511
    z[0,1,3]  R94       -0.265689492225647
    z[0,1,3]  R95       6.4403064548969269e-02
    z[0,1,3]  R96       -7.1564622223377228e-02
    z[0,1,3]  R97       4.1718116402626038e-01
    z[0,1,3]  R98       2.1552835404872894e-01
    z[0,1,3]  R99       2.7608352899551392e-01
    z[0,1,3]  R100      -1.7727948725223541e-01
    z[0,1,3]  R101      5.3987507708370686e-03
    z[0,1,3]  R102      3.1298029422760010e-01
    z[0,1,3]  R103      1.7882123589515686e-02
    z[0,1,3]  R104      1.9838282465934753e-01
    z[0,1,3]  R105      4.3217512965202332e-01
    z[0,1,3]  R106      1.9407291710376740e-01
    z[0,1,3]  R107      3.7785834074020386e-01
    z[0,1,3]  R108      0.359621524810791
    z[0,1,3]  R109      1.1336320638656616e-01
    z[0,1,3]  R110      -1.7726014554500580e-01
    z[0,1,3]  R111      3.5334849357604980e-01
    z[0,1,3]  R112      -1.6869869828224182e-01
    z[0,1,3]  R113      1.1771301925182343e-01
    z[0,1,3]  R114      -7.7181234955787659e-02
    z[0,1,3]  R115      -5.9966671466827393e-01
    z[0,1,3]  R116      -2.7676156163215637e-01
    z[0,1,3]  R117      2.1508021652698517e-01
    z[0,1,3]  R118      9.7305081784725189e-02
    z[0,1,3]  R119      0.0887034460902214
    z[0,1,3]  R120      3.4676992893218994e-01
    z[0,1,3]  R121      2.7455356717109680e-01
    z[0,1,3]  R122      4.8621648550033569e-01
    z[0,1,3]  R123      -4.0148496627807617e-03
    z[0,1,3]  R124      2.8074583411216736e-01
    z[0,1,3]  R125      1.6979804635047913e-01
    z[0,1,3]  R126      3.2959511876106262e-01
    z[0,1,3]  R127      -8.2395315170288086e-02
    z[0,1,3]  R128      1.8020935356616974e-02
    z[0,1,3]  R129      -2.4140359461307526e-01
    z[0,1,3]  R130      5.4319225251674652e-02
    z[0,1,3]  R131      7.3736339807510376e-02
    z[0,1,3]  R132      3.0708810687065125e-01
    z[0,1,3]  R133      1.3325117528438568e-02
    z[0,1,3]  R134      -2.1088348329067230e-01
    z[0,1,3]  R135      1.6426447033882141e-01
    z[0,1,4]  R6        -1
    z[0,1,4]  R15       1
    z[0,1,4]  R73       -1
    z[0,1,4]  R74       1
    z[0,1,4]  R79       2.0265898108482361e-01
    z[0,1,4]  R80       -0.612044095993042
    z[0,1,4]  R81       -5.2262353897094727e-01
    z[0,1,4]  R82       1.0441654175519943e-01
    z[0,1,4]  R83       2.2773596644401550e-01
    z[0,1,4]  R84       2.9111242294311523e-01
    z[0,1,4]  R85       2.2869792580604553e-01
    z[0,1,4]  R86       -4.0259966254234314e-01
    z[0,1,4]  R87       -0.286471426486969
    z[0,1,4]  R88       -0.689846396446228
    z[0,1,4]  R89       3.4563422203063965e-02
    z[0,1,4]  R90       -1.7491841316223145e-01
    z[0,1,4]  R91       2.4612756073474884e-01
    z[0,1,4]  R92       -3.0498182773590088e-01
    z[0,1,4]  R93       1.1260775476694107e-01
    z[0,1,4]  R94       3.5520192235708237e-02
    z[0,1,4]  R95       -8.8303722441196442e-02
    z[0,1,4]  R96       3.5890364088118076e-03
    z[0,1,4]  R97       -8.1895049661397934e-03
    z[0,1,4]  R98       4.2021960020065308e-01
    z[0,1,4]  R99       -3.1353679299354553e-01
    z[0,1,4]  R100      -2.8633216023445129e-01
    z[0,1,4]  R101      5.0904160737991333e-01
    z[0,1,4]  R102      1.8660099804401398e-01
    z[0,1,4]  R103      2.9098801314830780e-03
    z[0,1,4]  R104      -4.2806175351142883e-01
    z[0,1,4]  R105      1.9860044121742249e-01
    z[0,1,4]  R106      -5.3325051069259644e-01
    z[0,1,4]  R107      3.5291498899459839e-01
    z[0,1,4]  R108      -7.4833756685256958e-01
    z[0,1,4]  R109      9.5168747007846832e-02
    z[0,1,4]  R110      -1.1875925958156586e-01
    z[0,1,4]  R111      9.6530608832836151e-02
    z[0,1,4]  R112      3.0272430181503296e-01
    z[0,1,4]  R113      1.7969278991222382e-01
    z[0,1,4]  R114      1.8295511603355408e-01
    z[0,1,4]  R115      1.3895675539970398e-01
    z[0,1,4]  R116      2.5637738406658173e-02
    z[0,1,4]  R117      3.8580101728439331e-01
    z[0,1,4]  R118      3.0356483533978462e-02
    z[0,1,4]  R119      -6.0467068105936050e-02
    z[0,1,4]  R120      2.6015114784240723e-01
    z[0,1,4]  R121      -1.6977331042289734e-01
    z[0,1,4]  R122      2.5859564542770386e-01
    z[0,1,4]  R123      8.3201992511749268e-01
    z[0,1,4]  R124      -8.2185596227645874e-01
    z[0,1,4]  R125      -6.2639784812927246e-01
    z[0,1,4]  R126      -2.4580799043178558e-01
    z[0,1,4]  R127      4.6386823058128357e-01
    z[0,1,4]  R128      -6.9450271129608154e-01
    z[0,1,4]  R129      4.4686034321784973e-01
    z[0,1,4]  R130      6.2149971723556519e-01
    z[0,1,4]  R131      -5.8028399944305420e-01
    z[0,1,4]  R132      2.3789599537849426e-02
    z[0,1,4]  R133      8.4485846757888794e-01
    z[0,1,4]  R134      2.5438550114631653e-01
    z[0,1,4]  R135      -4.7681885957717896e-01
    z[0,1,5]  R7        -1
    z[0,1,5]  R16       1
    z[0,1,5]  R75       -1
    z[0,1,5]  R76       1
    z[0,1,5]  R79       5.5513250827789307e-01
    z[0,1,5]  R80       4.9365133047103882e-01
    z[0,1,5]  R81       1.9890367984771729e-01
    z[0,1,5]  R82       8.9978581666946411e-01
    z[0,1,5]  R83       -2.2785457968711853e-01
    z[0,1,5]  R84       3.4662586450576782e-01
    z[0,1,5]  R85       -6.4428210258483887e-02
    z[0,1,5]  R86       4.3015927076339722e-01
    z[0,1,5]  R87       6.4604347944259644e-01
    z[0,1,5]  R88       4.9847480654716492e-01
    z[0,1,5]  R89       -8.8586784899234772e-02
    z[0,1,5]  R90       -4.9111318588256836e-01
    z[0,1,5]  R91       -3.1351727247238159e-01
    z[0,1,5]  R92       -3.4089747071266174e-01
    z[0,1,5]  R93       1.2597735226154327e-01
    z[0,1,5]  R94       4.8162639141082764e-02
    z[0,1,5]  R95       -8.4397055208683014e-02
    z[0,1,5]  R96       0.0746607631444931
    z[0,1,5]  R97       -4.8730060458183289e-02
    z[0,1,5]  R98       -6.5307103097438812e-02
    z[0,1,5]  R99       1.1304462701082230e-01
    z[0,1,5]  R100      1.0431724786758423e-01
    z[0,1,5]  R101      -1.9295139610767365e-01
    z[0,1,5]  R102      -5.9720021486282349e-01
    z[0,1,5]  R103      -4.4581872224807739e-01
    z[0,1,5]  R104      -2.0345355570316315e-01
    z[0,1,5]  R105      1.0707014799118042e-01
    z[0,1,5]  R106      6.5626579523086548e-01
    z[0,1,5]  R107      6.6537988185882568e-01
    z[0,1,5]  R108      3.3398557454347610e-02
    z[0,1,5]  R109      0.296827495098114
    z[0,1,5]  R110      -4.5416764914989471e-02
    z[0,1,5]  R111      -5.4162133485078812e-02
    z[0,1,5]  R112      -1.4519900083541870e-02
    z[0,1,5]  R113      3.0179911851882935e-01
    z[0,1,5]  R114      -9.4601154327392578e-02
    z[0,1,5]  R115      4.6772268414497375e-01
    z[0,1,5]  R116      -5.4586249589920044e-01
    z[0,1,5]  R117      -6.1169409751892090e-01
    z[0,1,5]  R118      -1.9058316946029663e-01
    z[0,1,5]  R119      4.1480389237403870e-01
    z[0,1,5]  R120      -1.7482955753803253e-01
    z[0,1,5]  R121      1.8879230320453644e-01
    z[0,1,5]  R122      6.7648209631443024e-02
    z[0,1,5]  R123      4.7131654620170593e-01
    z[0,1,5]  R124      -3.4881058335304260e-01
    z[0,1,5]  R125      -0.663200855255127
    z[0,1,5]  R126      -4.2663764953613281e-01
    z[0,1,5]  R127      2.8599733114242554e-01
    z[0,1,5]  R128      -1.9886104762554169e-01
    z[0,1,5]  R129      -7.7556155622005463e-02
    z[0,1,5]  R130      6.6100579500198364e-01
    z[0,1,5]  R131      1.8605035543441772e-01
    z[0,1,5]  R132      0.519503653049469
    z[0,1,5]  R133      3.5062929987907410e-01
    z[0,1,5]  R134      -2.4049113690853119e-01
    z[0,1,5]  R135      4.2587769031524658e-01
    z[0,1,6]  R8        -1
    z[0,1,6]  R17       1
    z[0,1,6]  R77       -1
    z[0,1,6]  R78       1
    z[0,1,6]  R79       -1.0443992167711258e-01
    z[0,1,6]  R80       2.0704253017902374e-01
    z[0,1,6]  R81       -3.7843844294548035e-01
    z[0,1,6]  R82       1.6907177865505219e-01
    z[0,1,6]  R83       -6.5695017576217651e-01
    z[0,1,6]  R84       8.4132587909698486e-01
    z[0,1,6]  R85       7.2270631790161133e-01
    z[0,1,6]  R86       5.7766944169998169e-01
    z[0,1,6]  R87       -5.5377554893493652e-01
    z[0,1,6]  R88       4.0495449304580688e-01
    z[0,1,6]  R89       -3.5102754831314087e-02
    z[0,1,6]  R90       -6.2441930174827576e-02
    z[0,1,6]  R91       3.2508194446563721e-02
    z[0,1,6]  R92       -2.5555622577667236e-01
    z[0,1,6]  R93       -1.1863992363214493e-01
    z[0,1,6]  R94       8.3991914987564087e-02
    z[0,1,6]  R95       0.165150448679924
    z[0,1,6]  R96       -1.2029287219047546e-01
    z[0,1,6]  R97       -8.5812814533710480e-02
    z[0,1,6]  R98       -8.5258044302463531e-02
    z[0,1,6]  R99       -1.7352037131786346e-02
    z[0,1,6]  R100      -2.2686515748500824e-01
    z[0,1,6]  R101      1.3418383896350861e-01
    z[0,1,6]  R102      3.1480649113655090e-01
    z[0,1,6]  R103      -1.7384201288223267e-01
    z[0,1,6]  R104      -3.6519017815589905e-01
    z[0,1,6]  R105      2.6070675253868103e-01
    z[0,1,6]  R106      9.7905740141868591e-02
    z[0,1,6]  R107      4.9548465758562088e-02
    z[0,1,6]  R108      -2.7058309316635132e-01
    z[0,1,6]  R109      -4.1099029779434204e-01
    z[0,1,6]  R110      4.0998399257659912e-01
    z[0,1,6]  R111      7.8890067338943481e-01
    z[0,1,6]  R112      0.154539555311203
    z[0,1,6]  R113      2.4185986816883087e-01
    z[0,1,6]  R114      -3.9707425236701965e-01
    z[0,1,6]  R115      -2.9685431718826294e-01
    z[0,1,6]  R116      -3.1361716985702515e-01
    z[0,1,6]  R117      -3.6338892579078674e-01
    z[0,1,6]  R118      -1.8524931371212006e-01
    z[0,1,6]  R119      7.5806602835655212e-02
    z[0,1,6]  R120      -1.5545448660850525e-01
    z[0,1,6]  R121      -4.1842922568321228e-01
    z[0,1,6]  R122      -3.4202453494071960e-01
    z[0,1,6]  R123      1.0799054801464081e-01
    z[0,1,6]  R124      6.9016069173812866e-02
    z[0,1,6]  R125      1.8315553665161133e-01
    z[0,1,6]  R126      6.1327970027923584e-01
    z[0,1,6]  R127      -7.9011484980583191e-02
    z[0,1,6]  R128      0.0741225853562355
    z[0,1,6]  R129      -1.9100518897175789e-02
    z[0,1,6]  R130      2.1752619743347168e-01
    z[0,1,6]  R131      -2.7648079395294189e-01
    z[0,1,6]  R132      -7.9037941992282867e-02
    z[0,1,6]  R133      -1.6159781813621521e-01
    z[0,1,6]  R134      4.9513506889343262e-01
    z[0,1,6]  R135      -3.0760830640792847e-01
    z[1,0,0]  R2        1
    z[1,0,0]  R11       -1
    z[1,0,0]  R136      -1
    z[1,0,0]  R137      1
    z[1,0,0]  R150      2.4657995998859406e-01
    z[1,0,0]  R151      0.255929559469223
    z[1,0,0]  R152      -1.8523028492927551e-01
    z[1,0,0]  R153      -1.9604268670082092e-01
    z[1,0,0]  R154      -2.2875583171844482e-01
    z[1,0,0]  R155      -1.6787399351596832e-01
    z[1,0,0]  R156      9.0189540386199951e-01
    z[1,0,0]  R157      8.8136249780654907e-01
    z[1,0,0]  R158      8.4615147113800049e-01
    z[1,0,0]  R159      -3.2924351096153259e-01
    z[1,0,0]  R160      3.9918351918458939e-02
    z[1,0,0]  R161      -5.6306332349777222e-02
    z[1,0,0]  R162      -5.9193450212478638e-01
    z[1,0,0]  R163      -8.7908446788787842e-01
    z[1,0,0]  R164      -8.4026736021041870e-01
    z[1,0,0]  R165      -7.2747319936752319e-01
    z[1,0,0]  R166      -6.2574809789657593e-01
    z[1,0,0]  R167      -1.8546107411384583e-01
    z[1,0,0]  R168      3.2135257124900818e-01
    z[1,0,0]  R169      2.1261560916900635e-01
    z[1,0,0]  R170      3.8622301816940308e-01
    z[1,0,0]  R171      -6.2194317579269409e-01
    z[1,0,0]  R172      5.9298551082611084e-01
    z[1,0,0]  R173      -8.3533978462219238e-01
    z[1,0,0]  R174      -2.7348718047142029e-01
    z[1,0,0]  R175      6.3934868574142456e-01
    z[1,0,0]  R176      -2.1891364455223083e-01
    z[1,0,0]  R177      -3.1954467296600342e-01
    z[1,0,0]  R178      3.1205892562866211e-01
    z[1,0,0]  R179      3.0639445781707764e-01
    z[1,0,0]  R180      2.3703399300575256e-01
    z[1,0,0]  R181      -5.1966924220323563e-02
    z[1,0,0]  R182      -3.2384210824966431e-01
    z[1,0,0]  R183      -2.2580642998218536e-01
    z[1,0,0]  R184      -2.7220794558525085e-01
    z[1,0,0]  R185      1.3879048824310303e-01
    z[1,0,0]  R186      -3.5238423943519592e-01
    z[1,0,0]  R187      2.9622837901115417e-01
    z[1,0,0]  R188      3.8015949726104736e-01
    z[1,0,0]  R189      -1.8490074574947357e-01
    z[1,0,0]  R190      -7.3685050010681152e-01
    z[1,0,0]  R191      -1.4456748962402344e-01
    z[1,0,0]  R192      -5.7209278456866741e-03
    z[1,0,0]  R193      -1.8118970096111298e-01
    z[1,0,0]  R194      1.4800044894218445e-01
    z[1,0,0]  R195      1.0989877581596375e-01
    z[1,0,0]  R196      -1.5077717602252960e-01
    z[1,0,0]  R197      -2.1568293869495392e-01
    z[1,0,0]  R198      3.8670411705970764e-01
    z[1,0,0]  R199      2.8635779023170471e-01
    z[1,0,0]  R200      -5.7002358138561249e-02
    z[1,0,0]  R201      -2.8424862027168274e-01
    z[1,0,0]  R202      4.1324037313461304e-01
    z[1,0,0]  R203      -5.3474415093660355e-02
    z[1,0,0]  R204      1.7140798270702362e-01
    z[1,0,0]  R205      -7.2206601500511169e-02
    z[1,0,0]  R206      1.9241647422313690e-01
    z[1,0,1]  R3        1
    z[1,0,1]  R12       -1
    z[1,0,1]  R138      -1
    z[1,0,1]  R139      1
    z[1,0,1]  R150      2.5135436654090881e-01
    z[1,0,1]  R151      0.420491099357605
    z[1,0,1]  R152      2.5548499822616577e-01
    z[1,0,1]  R153      1.5653695166110992e-01
    z[1,0,1]  R154      1.7599220573902130e-01
    z[1,0,1]  R155      2.3999880254268646e-01
    z[1,0,1]  R156      1.9431927800178528e-01
    z[1,0,1]  R157      -1.5722972154617310e-01
    z[1,0,1]  R158      -1.4477474987506866e-01
    z[1,0,1]  R159      3.7604832649230957e-01
    z[1,0,1]  R160      0.689096212387085
    z[1,0,1]  R161      5.3424453735351562e-01
    z[1,0,1]  R162      4.8140963912010193e-01
    z[1,0,1]  R163      -7.9528607428073883e-02
    z[1,0,1]  R164      -2.2351981699466705e-01
    z[1,0,1]  R165      -1.5993355214595795e-01
    z[1,0,1]  R166      -3.0037540197372437e-01
    z[1,0,1]  R167      -3.6878433078527451e-02
    z[1,0,1]  R168      1.3351911678910255e-02
    z[1,0,1]  R169      1.3604276813566685e-02
    z[1,0,1]  R170      2.8984868526458740e-01
    z[1,0,1]  R171      2.1480667591094971e-01
    z[1,0,1]  R172      -0.0954454317688942
    z[1,0,1]  R173      8.9969672262668610e-02
    z[1,0,1]  R174      -1.0357370972633362e-01
    z[1,0,1]  R175      3.8562972098588943e-02
    z[1,0,1]  R176      7.2650928050279617e-03
    z[1,0,1]  R177      -1.8665449321269989e-01
    z[1,0,1]  R178      -3.9170585572719574e-02
    z[1,0,1]  R179      -5.0568240880966187e-01
    z[1,0,1]  R180      2.4043197929859161e-01
    z[1,0,1]  R181      2.6027753949165344e-01
    z[1,0,1]  R182      9.2512935400009155e-02
    z[1,0,1]  R183      2.8046226501464844e-01
    z[1,0,1]  R184      3.3027130365371704e-01
    z[1,0,1]  R185      1.9726713001728058e-01
    z[1,0,1]  R186      1.5464492142200470e-01
    z[1,0,1]  R187      0.165940061211586
    z[1,0,1]  R188      2.0005369186401367e-01
    z[1,0,1]  R189      1.3052280247211456e-01
    z[1,0,1]  R190      -2.7297571301460266e-01
    z[1,0,1]  R191      0.584796130657196
    z[1,0,1]  R192      6.5547966957092285e-01
    z[1,0,1]  R193      0.813894510269165
    z[1,0,1]  R194      -9.6482020616531372e-01
    z[1,0,1]  R195      -9.5070582628250122e-01
    z[1,0,1]  R196      -9.6304059028625488e-01
    z[1,0,1]  R197      -0.615744411945343
    z[1,0,1]  R198      -3.2791653275489807e-01
    z[1,0,1]  R199      -0.351236492395401
    z[1,0,1]  R200      8.8573509454727173e-01
    z[1,0,1]  R201      0.747351348400116
    z[1,0,1]  R202      0.515515148639679
    z[1,0,1]  R203      3.2899799942970276e-01
    z[1,0,1]  R204      -6.3394135236740112e-01
    z[1,0,1]  R205      -6.9849067926406860e-01
    z[1,0,1]  R206      -0.319276362657547
    z[1,0,2]  R4        1
    z[1,0,2]  R13       -1
    z[1,0,2]  R140      -1
    z[1,0,2]  R141      1
    z[1,0,2]  R150      3.3723658323287964e-01
    z[1,0,2]  R151      2.1254646778106689e-01
    z[1,0,2]  R152      3.6979696154594421e-01
    z[1,0,2]  R153      8.1125551462173462e-01
    z[1,0,2]  R154      8.3727121353149414e-01
    z[1,0,2]  R155      -3.9338001608848572e-01
    z[1,0,2]  R156      -6.8045049905776978e-02
    z[1,0,2]  R157      5.2481066435575485e-02
    z[1,0,2]  R158      2.3879086971282959e-01
    z[1,0,2]  R159      -2.5375235080718994e-01
    z[1,0,2]  R160      -2.2355543076992035e-01
    z[1,0,2]  R161      -1.0044532269239426e-01
    z[1,0,2]  R162      -5.8036994934082031e-01
    z[1,0,2]  R163      -1.7762959003448486e-01
    z[1,0,2]  R164      -3.6471266299486160e-02
    z[1,0,2]  R165      -3.6093726754188538e-01
    z[1,0,2]  R166      -3.0557924509048462e-01
    z[1,0,2]  R167      -1.9537086784839630e-01
    z[1,0,2]  R168      -1.2592333555221558e-01
    z[1,0,2]  R169      2.4499481916427612e-01
    z[1,0,2]  R170      -1.9908134639263153e-01
    z[1,0,2]  R171      -5.0699585676193237e-01
    z[1,0,2]  R172      3.3400547504425049e-01
    z[1,0,2]  R173      1.7254938185214996e-01
    z[1,0,2]  R174      -2.0253041386604309e-01
    z[1,0,2]  R175      -3.6949047446250916e-01
    z[1,0,2]  R176      -7.6224929094314575e-01
    z[1,0,2]  R177      5.7550603523850441e-03
    z[1,0,2]  R178      6.9921833276748657e-01
    z[1,0,2]  R179      3.4651690721511841e-01
    z[1,0,2]  R180      6.2348848581314087e-01
    z[1,0,2]  R181      5.1360601186752319e-01
    z[1,0,2]  R182      5.3082358837127686e-01
    z[1,0,2]  R183      -6.0419633984565735e-02
    z[1,0,2]  R184      2.1885776892304420e-02
    z[1,0,2]  R185      1.0903645306825638e-01
    z[1,0,2]  R186      4.9447467923164368e-01
    z[1,0,2]  R187      4.3094620108604431e-01
    z[1,0,2]  R188      0.00629103509709239
    z[1,0,2]  R189      -1.3276146352291107e-01
    z[1,0,2]  R190      -5.1149517297744751e-01
    z[1,0,2]  R191      2.4407340213656425e-02
    z[1,0,2]  R192      -0.159625843167305
    z[1,0,2]  R193      1.3904790580272675e-01
    z[1,0,2]  R194      2.1737396717071533e-02
    z[1,0,2]  R195      -5.3422104567289352e-02
    z[1,0,2]  R196      -5.8959450572729111e-02
    z[1,0,2]  R197      -7.4105370044708252e-01
    z[1,0,2]  R198      -7.4771988391876221e-01
    z[1,0,2]  R199      -7.4837243556976318e-01
    z[1,0,2]  R200      1.5689648687839508e-01
    z[1,0,2]  R201      -4.3000534176826477e-01
    z[1,0,2]  R202      4.9908763170242310e-01
    z[1,0,2]  R203      5.4806298017501831e-01
    z[1,0,2]  R204      5.8260971307754517e-01
    z[1,0,2]  R205      3.3097898960113525e-01
    z[1,0,2]  R206      -7.4524426460266113e-01
    z[1,0,3]  R5        1
    z[1,0,3]  R14       -1
    z[1,0,3]  R142      -1
    z[1,0,3]  R143      1
    z[1,0,3]  R150      1.9407291710376740e-01
    z[1,0,3]  R151      3.7785834074020386e-01
    z[1,0,3]  R152      0.359621524810791
    z[1,0,3]  R153      1.1336320638656616e-01
    z[1,0,3]  R154      -1.7726014554500580e-01
    z[1,0,3]  R155      3.5334849357604980e-01
    z[1,0,3]  R156      -1.6869869828224182e-01
    z[1,0,3]  R157      1.1771301925182343e-01
    z[1,0,3]  R158      -7.7181234955787659e-02
    z[1,0,3]  R159      -5.9966671466827393e-01
    z[1,0,3]  R160      -2.7676156163215637e-01
    z[1,0,3]  R161      2.1508021652698517e-01
    z[1,0,3]  R162      9.7305081784725189e-02
    z[1,0,3]  R163      0.0887034460902214
    z[1,0,3]  R164      3.4676992893218994e-01
    z[1,0,3]  R165      2.7455356717109680e-01
    z[1,0,3]  R166      4.8621648550033569e-01
    z[1,0,3]  R167      -4.0148496627807617e-03
    z[1,0,3]  R168      2.8074583411216736e-01
    z[1,0,3]  R169      1.6979804635047913e-01
    z[1,0,3]  R170      3.2959511876106262e-01
    z[1,0,3]  R171      -8.2395315170288086e-02
    z[1,0,3]  R172      1.8020935356616974e-02
    z[1,0,3]  R173      -2.4140359461307526e-01
    z[1,0,3]  R174      5.4319225251674652e-02
    z[1,0,3]  R175      7.3736339807510376e-02
    z[1,0,3]  R176      3.0708810687065125e-01
    z[1,0,3]  R177      1.3325117528438568e-02
    z[1,0,3]  R178      -2.1088348329067230e-01
    z[1,0,3]  R179      1.6426447033882141e-01
    z[1,0,3]  R180      3.7029585242271423e-01
    z[1,0,3]  R181      -6.7879520356655121e-02
    z[1,0,3]  R182      0.385850191116333
    z[1,0,3]  R183      1.3266208767890930e-01
    z[1,0,3]  R184      5.3007531166076660e-01
    z[1,0,3]  R185      1.3118194043636322e-01
    z[1,0,3]  R186      1.6925455629825592e-01
    z[1,0,3]  R187      1.3480573892593384e-01
    z[1,0,3]  R188      -0.0965004414319992
    z[1,0,3]  R189      2.0687343180179596e-01
    z[1,0,3]  R190      -3.3261656761169434e-01
    z[1,0,3]  R191      -6.0069161653518677e-01
    z[1,0,3]  R192      -6.2040686607360840e-01
    z[1,0,3]  R193      -1.0429682582616806e-01
    z[1,0,3]  R194      0.0641801655292511
    z[1,0,3]  R195      -0.265689492225647
    z[1,0,3]  R196      6.4403064548969269e-02
    z[1,0,3]  R197      -7.1564622223377228e-02
    z[1,0,3]  R198      4.1718116402626038e-01
    z[1,0,3]  R199      2.1552835404872894e-01
    z[1,0,3]  R200      2.7608352899551392e-01
    z[1,0,3]  R201      -1.7727948725223541e-01
    z[1,0,3]  R202      5.3987507708370686e-03
    z[1,0,3]  R203      3.1298029422760010e-01
    z[1,0,3]  R204      1.7882123589515686e-02
    z[1,0,3]  R205      1.9838282465934753e-01
    z[1,0,3]  R206      4.3217512965202332e-01
    z[1,0,4]  R6        1
    z[1,0,4]  R15       -1
    z[1,0,4]  R144      -1
    z[1,0,4]  R145      1
    z[1,0,4]  R150      -5.3325051069259644e-01
    z[1,0,4]  R151      3.5291498899459839e-01
    z[1,0,4]  R152      -7.4833756685256958e-01
    z[1,0,4]  R153      9.5168747007846832e-02
    z[1,0,4]  R154      -1.1875925958156586e-01
    z[1,0,4]  R155      9.6530608832836151e-02
    z[1,0,4]  R156      3.0272430181503296e-01
    z[1,0,4]  R157      1.7969278991222382e-01
    z[1,0,4]  R158      1.8295511603355408e-01
    z[1,0,4]  R159      1.3895675539970398e-01
    z[1,0,4]  R160      2.5637738406658173e-02
    z[1,0,4]  R161      3.8580101728439331e-01
    z[1,0,4]  R162      3.0356483533978462e-02
    z[1,0,4]  R163      -6.0467068105936050e-02
    z[1,0,4]  R164      2.6015114784240723e-01
    z[1,0,4]  R165      -1.6977331042289734e-01
    z[1,0,4]  R166      2.5859564542770386e-01
    z[1,0,4]  R167      8.3201992511749268e-01
    z[1,0,4]  R168      -8.2185596227645874e-01
    z[1,0,4]  R169      -6.2639784812927246e-01
    z[1,0,4]  R170      -2.4580799043178558e-01
    z[1,0,4]  R171      4.6386823058128357e-01
    z[1,0,4]  R172      -6.9450271129608154e-01
    z[1,0,4]  R173      4.4686034321784973e-01
    z[1,0,4]  R174      6.2149971723556519e-01
    z[1,0,4]  R175      -5.8028399944305420e-01
    z[1,0,4]  R176      2.3789599537849426e-02
    z[1,0,4]  R177      8.4485846757888794e-01
    z[1,0,4]  R178      2.5438550114631653e-01
    z[1,0,4]  R179      -4.7681885957717896e-01
    z[1,0,4]  R180      2.0265898108482361e-01
    z[1,0,4]  R181      -0.612044095993042
    z[1,0,4]  R182      -5.2262353897094727e-01
    z[1,0,4]  R183      1.0441654175519943e-01
    z[1,0,4]  R184      2.2773596644401550e-01
    z[1,0,4]  R185      2.9111242294311523e-01
    z[1,0,4]  R186      2.2869792580604553e-01
    z[1,0,4]  R187      -4.0259966254234314e-01
    z[1,0,4]  R188      -0.286471426486969
    z[1,0,4]  R189      -0.689846396446228
    z[1,0,4]  R190      3.4563422203063965e-02
    z[1,0,4]  R191      -1.7491841316223145e-01
    z[1,0,4]  R192      2.4612756073474884e-01
    z[1,0,4]  R193      -3.0498182773590088e-01
    z[1,0,4]  R194      1.1260775476694107e-01
    z[1,0,4]  R195      3.5520192235708237e-02
    z[1,0,4]  R196      -8.8303722441196442e-02
    z[1,0,4]  R197      3.5890364088118076e-03
    z[1,0,4]  R198      -8.1895049661397934e-03
    z[1,0,4]  R199      4.2021960020065308e-01
    z[1,0,4]  R200      -3.1353679299354553e-01
    z[1,0,4]  R201      -2.8633216023445129e-01
    z[1,0,4]  R202      5.0904160737991333e-01
    z[1,0,4]  R203      1.8660099804401398e-01
    z[1,0,4]  R204      2.9098801314830780e-03
    z[1,0,4]  R205      -4.2806175351142883e-01
    z[1,0,4]  R206      1.9860044121742249e-01
    z[1,0,5]  R7        1
    z[1,0,5]  R16       -1
    z[1,0,5]  R146      -1
    z[1,0,5]  R147      1
    z[1,0,5]  R150      6.5626579523086548e-01
    z[1,0,5]  R151      6.6537988185882568e-01
    z[1,0,5]  R152      3.3398557454347610e-02
    z[1,0,5]  R153      0.296827495098114
    z[1,0,5]  R154      -4.5416764914989471e-02
    z[1,0,5]  R155      -5.4162133485078812e-02
    z[1,0,5]  R156      -1.4519900083541870e-02
    z[1,0,5]  R157      3.0179911851882935e-01
    z[1,0,5]  R158      -9.4601154327392578e-02
    z[1,0,5]  R159      4.6772268414497375e-01
    z[1,0,5]  R160      -5.4586249589920044e-01
    z[1,0,5]  R161      -6.1169409751892090e-01
    z[1,0,5]  R162      -1.9058316946029663e-01
    z[1,0,5]  R163      4.1480389237403870e-01
    z[1,0,5]  R164      -1.7482955753803253e-01
    z[1,0,5]  R165      1.8879230320453644e-01
    z[1,0,5]  R166      6.7648209631443024e-02
    z[1,0,5]  R167      4.7131654620170593e-01
    z[1,0,5]  R168      -3.4881058335304260e-01
    z[1,0,5]  R169      -0.663200855255127
    z[1,0,5]  R170      -4.2663764953613281e-01
    z[1,0,5]  R171      2.8599733114242554e-01
    z[1,0,5]  R172      -1.9886104762554169e-01
    z[1,0,5]  R173      -7.7556155622005463e-02
    z[1,0,5]  R174      6.6100579500198364e-01
    z[1,0,5]  R175      1.8605035543441772e-01
    z[1,0,5]  R176      0.519503653049469
    z[1,0,5]  R177      3.5062929987907410e-01
    z[1,0,5]  R178      -2.4049113690853119e-01
    z[1,0,5]  R179      4.2587769031524658e-01
    z[1,0,5]  R180      5.5513250827789307e-01
    z[1,0,5]  R181      4.9365133047103882e-01
    z[1,0,5]  R182      1.9890367984771729e-01
    z[1,0,5]  R183      8.9978581666946411e-01
    z[1,0,5]  R184      -2.2785457968711853e-01
    z[1,0,5]  R185      3.4662586450576782e-01
    z[1,0,5]  R186      -6.4428210258483887e-02
    z[1,0,5]  R187      4.3015927076339722e-01
    z[1,0,5]  R188      6.4604347944259644e-01
    z[1,0,5]  R189      4.9847480654716492e-01
    z[1,0,5]  R190      -8.8586784899234772e-02
    z[1,0,5]  R191      -4.9111318588256836e-01
    z[1,0,5]  R192      -3.1351727247238159e-01
    z[1,0,5]  R193      -3.4089747071266174e-01
    z[1,0,5]  R194      1.2597735226154327e-01
    z[1,0,5]  R195      4.8162639141082764e-02
    z[1,0,5]  R196      -8.4397055208683014e-02
    z[1,0,5]  R197      0.0746607631444931
    z[1,0,5]  R198      -4.8730060458183289e-02
    z[1,0,5]  R199      -6.5307103097438812e-02
    z[1,0,5]  R200      1.1304462701082230e-01
    z[1,0,5]  R201      1.0431724786758423e-01
    z[1,0,5]  R202      -1.9295139610767365e-01
    z[1,0,5]  R203      -5.9720021486282349e-01
    z[1,0,5]  R204      -4.4581872224807739e-01
    z[1,0,5]  R205      -2.0345355570316315e-01
    z[1,0,5]  R206      1.0707014799118042e-01
    z[1,0,6]  R8        1
    z[1,0,6]  R17       -1
    z[1,0,6]  R148      -1
    z[1,0,6]  R149      1
    z[1,0,6]  R150      9.7905740141868591e-02
    z[1,0,6]  R151      4.9548465758562088e-02
    z[1,0,6]  R152      -2.7058309316635132e-01
    z[1,0,6]  R153      -4.1099029779434204e-01
    z[1,0,6]  R154      4.0998399257659912e-01
    z[1,0,6]  R155      7.8890067338943481e-01
    z[1,0,6]  R156      0.154539555311203
    z[1,0,6]  R157      2.4185986816883087e-01
    z[1,0,6]  R158      -3.9707425236701965e-01
    z[1,0,6]  R159      -2.9685431718826294e-01
    z[1,0,6]  R160      -3.1361716985702515e-01
    z[1,0,6]  R161      -3.6338892579078674e-01
    z[1,0,6]  R162      -1.8524931371212006e-01
    z[1,0,6]  R163      7.5806602835655212e-02
    z[1,0,6]  R164      -1.5545448660850525e-01
    z[1,0,6]  R165      -4.1842922568321228e-01
    z[1,0,6]  R166      -3.4202453494071960e-01
    z[1,0,6]  R167      1.0799054801464081e-01
    z[1,0,6]  R168      6.9016069173812866e-02
    z[1,0,6]  R169      1.8315553665161133e-01
    z[1,0,6]  R170      6.1327970027923584e-01
    z[1,0,6]  R171      -7.9011484980583191e-02
    z[1,0,6]  R172      0.0741225853562355
    z[1,0,6]  R173      -1.9100518897175789e-02
    z[1,0,6]  R174      2.1752619743347168e-01
    z[1,0,6]  R175      -2.7648079395294189e-01
    z[1,0,6]  R176      -7.9037941992282867e-02
    z[1,0,6]  R177      -1.6159781813621521e-01
    z[1,0,6]  R178      4.9513506889343262e-01
    z[1,0,6]  R179      -3.0760830640792847e-01
    z[1,0,6]  R180      -1.0443992167711258e-01
    z[1,0,6]  R181      2.0704253017902374e-01
    z[1,0,6]  R182      -3.7843844294548035e-01
    z[1,0,6]  R183      1.6907177865505219e-01
    z[1,0,6]  R184      -6.5695017576217651e-01
    z[1,0,6]  R185      8.4132587909698486e-01
    z[1,0,6]  R186      7.2270631790161133e-01
    z[1,0,6]  R187      5.7766944169998169e-01
    z[1,0,6]  R188      -5.5377554893493652e-01
    z[1,0,6]  R189      4.0495449304580688e-01
    z[1,0,6]  R190      -3.5102754831314087e-02
    z[1,0,6]  R191      -6.2441930174827576e-02
    z[1,0,6]  R192      3.2508194446563721e-02
    z[1,0,6]  R193      -2.5555622577667236e-01
    z[1,0,6]  R194      -1.1863992363214493e-01
    z[1,0,6]  R195      8.3991914987564087e-02
    z[1,0,6]  R196      0.165150448679924
    z[1,0,6]  R197      -1.2029287219047546e-01
    z[1,0,6]  R198      -8.5812814533710480e-02
    z[1,0,6]  R199      -8.5258044302463531e-02
    z[1,0,6]  R200      -1.7352037131786346e-02
    z[1,0,6]  R201      -2.2686515748500824e-01
    z[1,0,6]  R202      1.3418383896350861e-01
    z[1,0,6]  R203      3.1480649113655090e-01
    z[1,0,6]  R204      -1.7384201288223267e-01
    z[1,0,6]  R205      -3.6519017815589905e-01
    z[1,0,6]  R206      2.6070675253868103e-01
    z[0,4,0]  R2        -1
    z[0,4,0]  R38       1
    z[0,4,0]  R207      -1
    z[0,4,0]  R208      1
    z[0,4,0]  R221      2.3703399300575256e-01
    z[0,4,0]  R222      -5.1966924220323563e-02
    z[0,4,0]  R223      -3.2384210824966431e-01
    z[0,4,0]  R224      -2.2580642998218536e-01
    z[0,4,0]  R225      -2.7220794558525085e-01
    z[0,4,0]  R226      1.3879048824310303e-01
    z[0,4,0]  R227      -3.5238423943519592e-01
    z[0,4,0]  R228      2.9622837901115417e-01
    z[0,4,0]  R229      3.8015949726104736e-01
    z[0,4,0]  R230      -1.8490074574947357e-01
    z[0,4,0]  R231      -7.3685050010681152e-01
    z[0,4,0]  R232      -1.4456748962402344e-01
    z[0,4,0]  R233      -5.7209278456866741e-03
    z[0,4,0]  R234      -1.8118970096111298e-01
    z[0,4,0]  R235      1.4800044894218445e-01
    z[0,4,0]  R236      1.0989877581596375e-01
    z[0,4,0]  R237      -1.5077717602252960e-01
    z[0,4,0]  R238      -2.1568293869495392e-01
    z[0,4,0]  R239      3.8670411705970764e-01
    z[0,4,0]  R240      2.8635779023170471e-01
    z[0,4,0]  R241      -5.7002358138561249e-02
    z[0,4,0]  R242      -2.8424862027168274e-01
    z[0,4,0]  R243      4.1324037313461304e-01
    z[0,4,0]  R244      -5.3474415093660355e-02
    z[0,4,0]  R245      1.7140798270702362e-01
    z[0,4,0]  R246      -7.2206601500511169e-02
    z[0,4,0]  R247      1.9241647422313690e-01
    z[0,4,0]  R248      2.4657995998859406e-01
    z[0,4,0]  R249      0.255929559469223
    z[0,4,0]  R250      -1.8523028492927551e-01
    z[0,4,0]  R251      -1.6787399351596832e-01
    z[0,4,0]  R252      -3.2924351096153259e-01
    z[0,4,0]  R253      -4.7347900271415710e-01
    z[0,4,0]  R254      9.0349888801574707e-01
    z[0,4,0]  R255      -3.5524335503578186e-01
    z[0,4,0]  R256      8.7765812873840332e-01
    z[0,4,0]  R257      8.9711707830429077e-01
    z[0,4,0]  R258      8.5212677717208862e-02
    z[0,4,0]  R259      -8.4351825714111328e-01
    z[0,4,0]  R260      4.9002498388290405e-01
    z[0,4,0]  R261      -7.4569523334503174e-01
    z[0,4,0]  R262      2.5136426091194153e-01
    z[0,4,0]  R263      -5.4509627819061279e-01
    z[0,4,0]  R264      -5.5023926496505737e-01
    z[0,4,0]  R265      -5.0054174661636353e-01
    z[0,4,0]  R266      -5.7826393842697144e-01
    z[0,4,0]  R267      -5.1791024208068848e-01
    z[0,4,0]  R268      -7.3025655746459961e-01
    z[0,4,0]  R269      -7.3584026098251343e-01
    z[0,4,0]  R270      -0.660832405090332
    z[0,4,0]  R271      -6.5865439176559448e-01
    z[0,4,0]  R272      5.3700363636016846e-01
    z[0,4,0]  R273      5.1652848720550537e-01
    z[0,4,0]  R274      4.7987800836563110e-01
    z[0,4,0]  R275      2.9732385277748108e-01
    z[0,4,0]  R276      3.5026237368583679e-01
    z[0,4,0]  R277      4.0412786602973938e-01
    z[0,4,0]  R278      8.9487487077713013e-01
    z[0,4,0]  R279      5.7791447639465332e-01
    z[0,4,0]  R280      3.3423185348510742e-01
    z[0,4,0]  R281      3.9829817414283752e-01
    z[0,4,0]  R282      3.0566087365150452e-01
    z[0,4,0]  R283      3.0863767862319946e-01
    z[0,4,0]  R284      2.8419691324234009e-01
    z[0,4,0]  R285      -3.2681086659431458e-01
    z[0,4,1]  R3        -1
    z[0,4,1]  R39       1
    z[0,4,1]  R209      -1
    z[0,4,1]  R210      1
    z[0,4,1]  R221      2.4043197929859161e-01
    z[0,4,1]  R222      2.6027753949165344e-01
    z[0,4,1]  R223      9.2512935400009155e-02
    z[0,4,1]  R224      2.8046226501464844e-01
    z[0,4,1]  R225      3.3027130365371704e-01
    z[0,4,1]  R226      1.9726713001728058e-01
    z[0,4,1]  R227      1.5464492142200470e-01
    z[0,4,1]  R228      0.165940061211586
    z[0,4,1]  R229      2.0005369186401367e-01
    z[0,4,1]  R230      1.3052280247211456e-01
    z[0,4,1]  R231      -2.7297571301460266e-01
    z[0,4,1]  R232      0.584796130657196
    z[0,4,1]  R233      6.5547966957092285e-01
    z[0,4,1]  R234      0.813894510269165
    z[0,4,1]  R235      -9.6482020616531372e-01
    z[0,4,1]  R236      -9.5070582628250122e-01
    z[0,4,1]  R237      -9.6304059028625488e-01
    z[0,4,1]  R238      -0.615744411945343
    z[0,4,1]  R239      -3.2791653275489807e-01
    z[0,4,1]  R240      -0.351236492395401
    z[0,4,1]  R241      8.8573509454727173e-01
    z[0,4,1]  R242      0.747351348400116
    z[0,4,1]  R243      0.515515148639679
    z[0,4,1]  R244      3.2899799942970276e-01
    z[0,4,1]  R245      -6.3394135236740112e-01
    z[0,4,1]  R246      -6.9849067926406860e-01
    z[0,4,1]  R247      -0.319276362657547
    z[0,4,1]  R248      2.5135436654090881e-01
    z[0,4,1]  R249      0.420491099357605
    z[0,4,1]  R250      2.5548499822616577e-01
    z[0,4,1]  R251      2.3999880254268646e-01
    z[0,4,1]  R252      3.7604832649230957e-01
    z[0,4,1]  R253      -4.3337881565093994e-01
    z[0,4,1]  R254      -8.1412322819232941e-02
    z[0,4,1]  R255      4.7677550464868546e-02
    z[0,4,1]  R256      -2.4651013314723969e-01
    z[0,4,1]  R257      9.0749554336071014e-02
    z[0,4,1]  R258      7.1628761291503906e-01
    z[0,4,1]  R259      8.1906437873840332e-02
    z[0,4,1]  R260      -2.1238750219345093e-01
    z[0,4,1]  R261      3.3670984208583832e-02
    z[0,4,1]  R262      -4.5006313920021057e-01
    z[0,4,1]  R263      -2.9721334576606750e-01
    z[0,4,1]  R264      -4.0150359272956848e-01
    z[0,4,1]  R265      -3.8969784975051880e-01
    z[0,4,1]  R266      -3.7562859058380127e-01
    z[0,4,1]  R267      -3.1049597263336182e-01
    z[0,4,1]  R268      3.8402697443962097e-01
    z[0,4,1]  R269      -2.2488430142402649e-01
    z[0,4,1]  R270      -2.9133029282093048e-02
    z[0,4,1]  R271      -3.5321453213691711e-01
    z[0,4,1]  R272      -4.7083371877670288e-01
    z[0,4,1]  R273      -3.0634710192680359e-01
    z[0,4,1]  R274      -4.5350956916809082e-01
    z[0,4,1]  R275      -2.1151988208293915e-01
    z[0,4,1]  R276      -1.7822524905204773e-01
    z[0,4,1]  R277      2.1170638501644135e-01
    z[0,4,1]  R278      -2.2562728822231293e-01
    z[0,4,1]  R279      -5.6426286697387695e-02
    z[0,4,1]  R280      -1.3580378890037537e-01
    z[0,4,1]  R281      4.9179205298423767e-01
    z[0,4,1]  R282      3.1875270605087280e-01
    z[0,4,1]  R283      2.9287168383598328e-01
    z[0,4,1]  R284      3.4953951835632324e-01
    z[0,4,1]  R285      -2.0246687531471252e-01
    z[0,4,2]  R4        -1
    z[0,4,2]  R40       1
    z[0,4,2]  R211      -1
    z[0,4,2]  R212      1
    z[0,4,2]  R221      6.2348848581314087e-01
    z[0,4,2]  R222      5.1360601186752319e-01
    z[0,4,2]  R223      5.3082358837127686e-01
    z[0,4,2]  R224      -6.0419633984565735e-02
    z[0,4,2]  R225      2.1885776892304420e-02
    z[0,4,2]  R226      1.0903645306825638e-01
    z[0,4,2]  R227      4.9447467923164368e-01
    z[0,4,2]  R228      4.3094620108604431e-01
    z[0,4,2]  R229      0.00629103509709239
    z[0,4,2]  R230      -1.3276146352291107e-01
    z[0,4,2]  R231      -5.1149517297744751e-01
    z[0,4,2]  R232      2.4407340213656425e-02
    z[0,4,2]  R233      -0.159625843167305
    z[0,4,2]  R234      1.3904790580272675e-01
    z[0,4,2]  R235      2.1737396717071533e-02
    z[0,4,2]  R236      -5.3422104567289352e-02
    z[0,4,2]  R237      -5.8959450572729111e-02
    z[0,4,2]  R238      -7.4105370044708252e-01
    z[0,4,2]  R239      -7.4771988391876221e-01
    z[0,4,2]  R240      -7.4837243556976318e-01
    z[0,4,2]  R241      1.5689648687839508e-01
    z[0,4,2]  R242      -4.3000534176826477e-01
    z[0,4,2]  R243      4.9908763170242310e-01
    z[0,4,2]  R244      5.4806298017501831e-01
    z[0,4,2]  R245      5.8260971307754517e-01
    z[0,4,2]  R246      3.3097898960113525e-01
    z[0,4,2]  R247      -7.4524426460266113e-01
    z[0,4,2]  R248      3.3723658323287964e-01
    z[0,4,2]  R249      2.1254646778106689e-01
    z[0,4,2]  R250      3.6979696154594421e-01
    z[0,4,2]  R251      -3.9338001608848572e-01
    z[0,4,2]  R252      -2.5375235080718994e-01
    z[0,4,2]  R253      -4.0026667714118958e-01
    z[0,4,2]  R254      -1.8174979090690613e-01
    z[0,4,2]  R255      -7.2701007127761841e-01
    z[0,4,2]  R256      6.9238655269145966e-02
    z[0,4,2]  R257      -1.9710262119770050e-01
    z[0,4,2]  R258      5.6447625160217285e-02
    z[0,4,2]  R259      2.0022470504045486e-02
    z[0,4,2]  R260      1.3306963443756104e-01
    z[0,4,2]  R261      -1.9731815159320831e-01
    z[0,4,2]  R262      -5.8517616987228394e-01
    z[0,4,2]  R263      6.3593953847885132e-01
    z[0,4,2]  R264      5.4929924011230469e-01
    z[0,4,2]  R265      5.8574265241622925e-01
    z[0,4,2]  R266      4.4907850027084351e-01
    z[0,4,2]  R267      5.3506422042846680e-01
    z[0,4,2]  R268      -4.1943371295928955e-01
    z[0,4,2]  R269      -3.1705504655838013e-01
    z[0,4,2]  R270      -5.5717867612838745e-01
    z[0,4,2]  R271      -3.3449560403823853e-01
    z[0,4,2]  R272      -5.0315749645233154e-01
    z[0,4,2]  R273      -3.1380680203437805e-01
    z[0,4,2]  R274      1.7505396157503128e-02
    z[0,4,2]  R275      -6.4479392766952515e-01
    z[0,4,2]  R276      -5.8811032772064209e-01
    z[0,4,2]  R277      4.3414118885993958e-01
    z[0,4,2]  R278      -1.1416142433881760e-01
    z[0,4,2]  R279      -4.8208889365196228e-01
    z[0,4,2]  R280      -2.0556335151195526e-01
    z[0,4,2]  R281      7.0926159620285034e-01
    z[0,4,2]  R282      0.772919774055481
    z[0,4,2]  R283      7.5071024894714355e-01
    z[0,4,2]  R284      6.2224715948104858e-01
    z[0,4,2]  R285      7.0781558752059937e-01
    z[0,4,3]  R5        -1
    z[0,4,3]  R41       1
    z[0,4,3]  R213      -1
    z[0,4,3]  R214      1
    z[0,4,3]  R221      3.7029585242271423e-01
    z[0,4,3]  R222      -6.7879520356655121e-02
    z[0,4,3]  R223      0.385850191116333
    z[0,4,3]  R224      1.3266208767890930e-01
    z[0,4,3]  R225      5.3007531166076660e-01
    z[0,4,3]  R226      1.3118194043636322e-01
    z[0,4,3]  R227      1.6925455629825592e-01
    z[0,4,3]  R228      1.3480573892593384e-01
    z[0,4,3]  R229      -0.0965004414319992
    z[0,4,3]  R230      2.0687343180179596e-01
    z[0,4,3]  R231      -3.3261656761169434e-01
    z[0,4,3]  R232      -6.0069161653518677e-01
    z[0,4,3]  R233      -6.2040686607360840e-01
    z[0,4,3]  R234      -1.0429682582616806e-01
    z[0,4,3]  R235      0.0641801655292511
    z[0,4,3]  R236      -0.265689492225647
    z[0,4,3]  R237      6.4403064548969269e-02
    z[0,4,3]  R238      -7.1564622223377228e-02
    z[0,4,3]  R239      4.1718116402626038e-01
    z[0,4,3]  R240      2.1552835404872894e-01
    z[0,4,3]  R241      2.7608352899551392e-01
    z[0,4,3]  R242      -1.7727948725223541e-01
    z[0,4,3]  R243      5.3987507708370686e-03
    z[0,4,3]  R244      3.1298029422760010e-01
    z[0,4,3]  R245      1.7882123589515686e-02
    z[0,4,3]  R246      1.9838282465934753e-01
    z[0,4,3]  R247      4.3217512965202332e-01
    z[0,4,3]  R248      1.9407291710376740e-01
    z[0,4,3]  R249      3.7785834074020386e-01
    z[0,4,3]  R250      0.359621524810791
    z[0,4,3]  R251      3.5334849357604980e-01
    z[0,4,3]  R252      -5.9966671466827393e-01
    z[0,4,3]  R253      3.5166677832603455e-01
    z[0,4,3]  R254      -1.7718973755836487e-01
    z[0,4,3]  R255      -1.7114609479904175e-01
    z[0,4,3]  R256      1.0475947707891464e-01
    z[0,4,3]  R257      -1.4726942777633667e-01
    z[0,4,3]  R258      -7.2947158478200436e-03
    z[0,4,3]  R259      9.5679499208927155e-02
    z[0,4,3]  R260      3.3502838015556335e-01
    z[0,4,3]  R261      -1.4262425899505615e-01
    z[0,4,3]  R262      3.4569406509399414e-01
    z[0,4,3]  R263      -1.8511952459812164e-01
    z[0,4,3]  R264      1.8296670913696289e-01
    z[0,4,3]  R265      2.8348726034164429e-01
    z[0,4,3]  R266      -1.3576443493366241e-01
    z[0,4,3]  R267      1.6956056654453278e-01
    z[0,4,3]  R268      -4.3668370693922043e-02
    z[0,4,3]  R269      2.3234169185161591e-01
    z[0,4,3]  R270      4.1011381894350052e-02
    z[0,4,3]  R271      3.1981386244297028e-02
    z[0,4,3]  R272      0.309207946062088
    z[0,4,3]  R273      3.5993787646293640e-01
    z[0,4,3]  R274      5.1507014036178589e-01
    z[0,4,3]  R275      -3.3113643527030945e-01
    z[0,4,3]  R276      -0.296572744846344
    z[0,4,3]  R277      -1.6149322688579559e-01
    z[0,4,3]  R278      2.6683533191680908e-01
    z[0,4,3]  R279      -2.6365929841995239e-01
    z[0,4,3]  R280      -1.7282043397426605e-01
    z[0,4,3]  R281      -9.6074566245079041e-02
    z[0,4,3]  R282      2.1486331522464752e-01
    z[0,4,3]  R283      3.2078996300697327e-01
    z[0,4,3]  R284      1.3732829689979553e-01
    z[0,4,3]  R285      -4.2660561203956604e-01
    z[0,4,4]  R6        -1
    z[0,4,4]  R42       1
    z[0,4,4]  R215      -1
    z[0,4,4]  R216      1
    z[0,4,4]  R221      2.0265898108482361e-01
    z[0,4,4]  R222      -0.612044095993042
    z[0,4,4]  R223      -5.2262353897094727e-01
    z[0,4,4]  R224      1.0441654175519943e-01
    z[0,4,4]  R225      2.2773596644401550e-01
    z[0,4,4]  R226      2.9111242294311523e-01
    z[0,4,4]  R227      2.2869792580604553e-01
    z[0,4,4]  R228      -4.0259966254234314e-01
    z[0,4,4]  R229      -0.286471426486969
    z[0,4,4]  R230      -0.689846396446228
    z[0,4,4]  R231      3.4563422203063965e-02
    z[0,4,4]  R232      -1.7491841316223145e-01
    z[0,4,4]  R233      2.4612756073474884e-01
    z[0,4,4]  R234      -3.0498182773590088e-01
    z[0,4,4]  R235      1.1260775476694107e-01
    z[0,4,4]  R236      3.5520192235708237e-02
    z[0,4,4]  R237      -8.8303722441196442e-02
    z[0,4,4]  R238      3.5890364088118076e-03
    z[0,4,4]  R239      -8.1895049661397934e-03
    z[0,4,4]  R240      4.2021960020065308e-01
    z[0,4,4]  R241      -3.1353679299354553e-01
    z[0,4,4]  R242      -2.8633216023445129e-01
    z[0,4,4]  R243      5.0904160737991333e-01
    z[0,4,4]  R244      1.8660099804401398e-01
    z[0,4,4]  R245      2.9098801314830780e-03
    z[0,4,4]  R246      -4.2806175351142883e-01
    z[0,4,4]  R247      1.9860044121742249e-01
    z[0,4,4]  R248      -5.3325051069259644e-01
    z[0,4,4]  R249      3.5291498899459839e-01
    z[0,4,4]  R250      -7.4833756685256958e-01
    z[0,4,4]  R251      9.6530608832836151e-02
    z[0,4,4]  R252      1.3895675539970398e-01
    z[0,4,4]  R253      2.2054056823253632e-01
    z[0,4,4]  R254      -2.8322175145149231e-01
    z[0,4,4]  R255      1.1401998996734619e-01
    z[0,4,4]  R256      -1.3707152009010315e-01
    z[0,4,4]  R257      4.4733222573995590e-02
    z[0,4,4]  R258      2.6117414236068726e-01
    z[0,4,4]  R259      4.9561902880668640e-01
    z[0,4,4]  R260      0.406207412481308
    z[0,4,4]  R261      -3.5524827241897583e-01
    z[0,4,4]  R262      3.7169721722602844e-01
    z[0,4,4]  R263      -3.1640312075614929e-01
    z[0,4,4]  R264      -4.2178431153297424e-01
    z[0,4,4]  R265      -2.5168126821517944e-01
    z[0,4,4]  R266      -4.4645896553993225e-01
    z[0,4,4]  R267      -3.5246381163597107e-01
    z[0,4,4]  R268      0.280819296836853
    z[0,4,4]  R269      4.3981426954269409e-01
    z[0,4,4]  R270      4.0599894709885120e-03
    z[0,4,4]  R271      -4.7642147541046143e-01
    z[0,4,4]  R272      2.0234338939189911e-01
    z[0,4,4]  R273      5.0732856988906860e-01
    z[0,4,4]  R274      -2.6159477233886719e-01
    z[0,4,4]  R275      1.0549803078174591e-01
    z[0,4,4]  R276      3.7096962332725525e-01
    z[0,4,4]  R277      -4.3181905150413513e-01
    z[0,4,4]  R278      1.6442857682704926e-01
    z[0,4,4]  R279      4.8693239688873291e-01
    z[0,4,4]  R280      6.7832469940185547e-02
    z[0,4,4]  R281      2.7059277892112732e-01
    z[0,4,4]  R282      -3.8322050124406815e-02
    z[0,4,4]  R283      1.9262421131134033e-01
    z[0,4,4]  R284      -1.2879092991352081e-01
    z[0,4,4]  R285      -1.4227072894573212e-01
    z[0,4,5]  R7        -1
    z[0,4,5]  R43       1
    z[0,4,5]  R217      -1
    z[0,4,5]  R218      1
    z[0,4,5]  R221      5.5513250827789307e-01
    z[0,4,5]  R222      4.9365133047103882e-01
    z[0,4,5]  R223      1.9890367984771729e-01
    z[0,4,5]  R224      8.9978581666946411e-01
    z[0,4,5]  R225      -2.2785457968711853e-01
    z[0,4,5]  R226      3.4662586450576782e-01
    z[0,4,5]  R227      -6.4428210258483887e-02
    z[0,4,5]  R228      4.3015927076339722e-01
    z[0,4,5]  R229      6.4604347944259644e-01
    z[0,4,5]  R230      4.9847480654716492e-01
    z[0,4,5]  R231      -8.8586784899234772e-02
    z[0,4,5]  R232      -4.9111318588256836e-01
    z[0,4,5]  R233      -3.1351727247238159e-01
    z[0,4,5]  R234      -3.4089747071266174e-01
    z[0,4,5]  R235      1.2597735226154327e-01
    z[0,4,5]  R236      4.8162639141082764e-02
    z[0,4,5]  R237      -8.4397055208683014e-02
    z[0,4,5]  R238      0.0746607631444931
    z[0,4,5]  R239      -4.8730060458183289e-02
    z[0,4,5]  R240      -6.5307103097438812e-02
    z[0,4,5]  R241      1.1304462701082230e-01
    z[0,4,5]  R242      1.0431724786758423e-01
    z[0,4,5]  R243      -1.9295139610767365e-01
    z[0,4,5]  R244      -5.9720021486282349e-01
    z[0,4,5]  R245      -4.4581872224807739e-01
    z[0,4,5]  R246      -2.0345355570316315e-01
    z[0,4,5]  R247      1.0707014799118042e-01
    z[0,4,5]  R248      6.5626579523086548e-01
    z[0,4,5]  R249      6.6537988185882568e-01
    z[0,4,5]  R250      3.3398557454347610e-02
    z[0,4,5]  R251      -5.4162133485078812e-02
    z[0,4,5]  R252      4.6772268414497375e-01
    z[0,4,5]  R253      1.5188623964786530e-01
    z[0,4,5]  R254      -1.6468483209609985e-01
    z[0,4,5]  R255      5.0029838085174561e-01
    z[0,4,5]  R256      -1.1389130959287286e-03
    z[0,4,5]  R257      -5.6748535484075546e-02
    z[0,4,5]  R258      -6.2615203857421875e-01
    z[0,4,5]  R259      1.6065572202205658e-01
    z[0,4,5]  R260      6.4777636528015137e-01
    z[0,4,5]  R261      -5.0720870494842529e-01
    z[0,4,5]  R262      -3.6588084697723389e-01
    z[0,4,5]  R263      7.4011576361954212e-03
    z[0,4,5]  R264      -1.0231139510869980e-01
    z[0,4,5]  R265      -3.2818627357482910e-01
    z[0,4,5]  R266      -3.0741935968399048e-01
    z[0,4,5]  R267      -4.0899041295051575e-01
    z[0,4,5]  R268      1.0906521230936050e-01
    z[0,4,5]  R269      2.3966281116008759e-01
    z[0,4,5]  R270      3.5929358005523682e-01
    z[0,4,5]  R271      3.1823945045471191e-01
    z[0,4,5]  R272      2.2841575741767883e-01
    z[0,4,5]  R273      -3.8880008459091187e-01
    z[0,4,5]  R274      3.3971187472343445e-01
    z[0,4,5]  R275      5.5800056457519531e-01
    z[0,4,5]  R276      3.8121134042739868e-01
    z[0,4,5]  R277      5.7679861783981323e-01
    z[0,4,5]  R278      -1.6769881546497345e-01
    z[0,4,5]  R279      -3.3462487161159515e-02
    z[0,4,5]  R280      8.8889855146408081e-01
    z[0,4,5]  R281      -2.6256833225488663e-02
    z[0,4,5]  R282      1.5315471589565277e-01
    z[0,4,5]  R283      -2.9874238371849060e-01
    z[0,4,5]  R284      -5.6345868110656738e-01
    z[0,4,5]  R285      9.4821535050868988e-02
    z[0,4,6]  R8        -1
    z[0,4,6]  R44       1
    z[0,4,6]  R219      -1
    z[0,4,6]  R220      1
    z[0,4,6]  R221      -1.0443992167711258e-01
    z[0,4,6]  R222      2.0704253017902374e-01
    z[0,4,6]  R223      -3.7843844294548035e-01
    z[0,4,6]  R224      1.6907177865505219e-01
    z[0,4,6]  R225      -6.5695017576217651e-01
    z[0,4,6]  R226      8.4132587909698486e-01
    z[0,4,6]  R227      7.2270631790161133e-01
    z[0,4,6]  R228      5.7766944169998169e-01
    z[0,4,6]  R229      -5.5377554893493652e-01
    z[0,4,6]  R230      4.0495449304580688e-01
    z[0,4,6]  R231      -3.5102754831314087e-02
    z[0,4,6]  R232      -6.2441930174827576e-02
    z[0,4,6]  R233      3.2508194446563721e-02
    z[0,4,6]  R234      -2.5555622577667236e-01
    z[0,4,6]  R235      -1.1863992363214493e-01
    z[0,4,6]  R236      8.3991914987564087e-02
    z[0,4,6]  R237      0.165150448679924
    z[0,4,6]  R238      -1.2029287219047546e-01
    z[0,4,6]  R239      -8.5812814533710480e-02
    z[0,4,6]  R240      -8.5258044302463531e-02
    z[0,4,6]  R241      -1.7352037131786346e-02
    z[0,4,6]  R242      -2.2686515748500824e-01
    z[0,4,6]  R243      1.3418383896350861e-01
    z[0,4,6]  R244      3.1480649113655090e-01
    z[0,4,6]  R245      -1.7384201288223267e-01
    z[0,4,6]  R246      -3.6519017815589905e-01
    z[0,4,6]  R247      2.6070675253868103e-01
    z[0,4,6]  R248      9.7905740141868591e-02
    z[0,4,6]  R249      4.9548465758562088e-02
    z[0,4,6]  R250      -2.7058309316635132e-01
    z[0,4,6]  R251      7.8890067338943481e-01
    z[0,4,6]  R252      -2.9685431718826294e-01
    z[0,4,6]  R253      -4.8208922147750854e-01
    z[0,4,6]  R254      -7.2780676186084747e-02
    z[0,4,6]  R255      2.2448913753032684e-01
    z[0,4,6]  R256      -3.6659315228462219e-01
    z[0,4,6]  R257      3.4811830520629883e-01
    z[0,4,6]  R258      -1.2709483504295349e-01
    z[0,4,6]  R259      -2.7647811919450760e-02
    z[0,4,6]  R260      1.4032294973731041e-02
    z[0,4,6]  R261      8.1678237766027451e-03
    z[0,4,6]  R262      1.7205484211444855e-02
    z[0,4,6]  R263      2.7510038018226624e-01
    z[0,4,6]  R264      -1.1160384118556976e-01
    z[0,4,6]  R265      5.5536616593599319e-02
    z[0,4,6]  R266      0.102850541472435
    z[0,4,6]  R267      -0.169743612408638
    z[0,4,6]  R268      2.2508314251899719e-01
    z[0,4,6]  R269      5.0840977579355240e-02
    z[0,4,6]  R270      -3.4815722703933716e-01
    z[0,4,6]  R271      1.5809737145900726e-02
    z[0,4,6]  R272      2.1920089423656464e-01
    z[0,4,6]  R273      -5.2649658173322678e-02
    z[0,4,6]  R274      3.3853590488433838e-01
    z[0,4,6]  R275      -1.3766942918300629e-01
    z[0,4,6]  R276      -3.5886257886886597e-01
    z[0,4,6]  R277      2.4111849069595337e-01
    z[0,4,6]  R278      9.4328567385673523e-02
    z[0,4,6]  R279      -3.5025981068611145e-01
    z[0,4,6]  R280      -5.4601531475782394e-02
    z[0,4,6]  R281      -1.1535544693470001e-01
    z[0,4,6]  R282      3.6942100524902344e-01
    z[0,4,6]  R283      1.6169679164886475e-01
    z[0,4,6]  R284      2.3860198259353638e-01
    z[0,4,6]  R285      -3.7413170933723450e-01
    z[4,0,0]  R2        1
    z[4,0,0]  R38       -1
    z[4,0,0]  R286      -1
    z[4,0,0]  R287      1
    z[4,0,0]  R300      2.4657995998859406e-01
    z[4,0,0]  R301      0.255929559469223
    z[4,0,0]  R302      -1.8523028492927551e-01
    z[4,0,0]  R303      -1.6787399351596832e-01
    z[4,0,0]  R304      -3.2924351096153259e-01
    z[4,0,0]  R305      -4.7347900271415710e-01
    z[4,0,0]  R306      9.0349888801574707e-01
    z[4,0,0]  R307      -3.5524335503578186e-01
    z[4,0,0]  R308      8.7765812873840332e-01
    z[4,0,0]  R309      8.9711707830429077e-01
    z[4,0,0]  R310      8.5212677717208862e-02
    z[4,0,0]  R311      -8.4351825714111328e-01
    z[4,0,0]  R312      4.9002498388290405e-01
    z[4,0,0]  R313      -7.4569523334503174e-01
    z[4,0,0]  R314      2.5136426091194153e-01
    z[4,0,0]  R315      -5.4509627819061279e-01
    z[4,0,0]  R316      -5.5023926496505737e-01
    z[4,0,0]  R317      -5.0054174661636353e-01
    z[4,0,0]  R318      -5.7826393842697144e-01
    z[4,0,0]  R319      -5.1791024208068848e-01
    z[4,0,0]  R320      -7.3025655746459961e-01
    z[4,0,0]  R321      -7.3584026098251343e-01
    z[4,0,0]  R322      -0.660832405090332
    z[4,0,0]  R323      -6.5865439176559448e-01
    z[4,0,0]  R324      5.3700363636016846e-01
    z[4,0,0]  R325      5.1652848720550537e-01
    z[4,0,0]  R326      4.7987800836563110e-01
    z[4,0,0]  R327      2.9732385277748108e-01
    z[4,0,0]  R328      3.5026237368583679e-01
    z[4,0,0]  R329      4.0412786602973938e-01
    z[4,0,0]  R330      8.9487487077713013e-01
    z[4,0,0]  R331      5.7791447639465332e-01
    z[4,0,0]  R332      3.3423185348510742e-01
    z[4,0,0]  R333      3.9829817414283752e-01
    z[4,0,0]  R334      3.0566087365150452e-01
    z[4,0,0]  R335      3.0863767862319946e-01
    z[4,0,0]  R336      2.8419691324234009e-01
    z[4,0,0]  R337      -3.2681086659431458e-01
    z[4,0,0]  R338      2.3703399300575256e-01
    z[4,0,0]  R339      -5.1966924220323563e-02
    z[4,0,0]  R340      -3.2384210824966431e-01
    z[4,0,0]  R341      -2.2580642998218536e-01
    z[4,0,0]  R342      -2.7220794558525085e-01
    z[4,0,0]  R343      1.3879048824310303e-01
    z[4,0,0]  R344      -3.5238423943519592e-01
    z[4,0,0]  R345      2.9622837901115417e-01
    z[4,0,0]  R346      3.8015949726104736e-01
    z[4,0,0]  R347      -1.8490074574947357e-01
    z[4,0,0]  R348      -7.3685050010681152e-01
    z[4,0,0]  R349      -1.4456748962402344e-01
    z[4,0,0]  R350      -5.7209278456866741e-03
    z[4,0,0]  R351      -1.8118970096111298e-01
    z[4,0,0]  R352      1.4800044894218445e-01
    z[4,0,0]  R353      1.0989877581596375e-01
    z[4,0,0]  R354      -1.5077717602252960e-01
    z[4,0,0]  R355      -2.1568293869495392e-01
    z[4,0,0]  R356      3.8670411705970764e-01
    z[4,0,0]  R357      2.8635779023170471e-01
    z[4,0,0]  R358      -5.7002358138561249e-02
    z[4,0,0]  R359      -2.8424862027168274e-01
    z[4,0,0]  R360      4.1324037313461304e-01
    z[4,0,0]  R361      -5.3474415093660355e-02
    z[4,0,0]  R362      1.7140798270702362e-01
    z[4,0,0]  R363      -7.2206601500511169e-02
    z[4,0,0]  R364      1.9241647422313690e-01
    z[4,0,1]  R3        1
    z[4,0,1]  R39       -1
    z[4,0,1]  R288      -1
    z[4,0,1]  R289      1
    z[4,0,1]  R300      2.5135436654090881e-01
    z[4,0,1]  R301      0.420491099357605
    z[4,0,1]  R302      2.5548499822616577e-01
    z[4,0,1]  R303      2.3999880254268646e-01
    z[4,0,1]  R304      3.7604832649230957e-01
    z[4,0,1]  R305      -4.3337881565093994e-01
    z[4,0,1]  R306      -8.1412322819232941e-02
    z[4,0,1]  R307      4.7677550464868546e-02
    z[4,0,1]  R308      -2.4651013314723969e-01
    z[4,0,1]  R309      9.0749554336071014e-02
    z[4,0,1]  R310      7.1628761291503906e-01
    z[4,0,1]  R311      8.1906437873840332e-02
    z[4,0,1]  R312      -2.1238750219345093e-01
    z[4,0,1]  R313      3.3670984208583832e-02
    z[4,0,1]  R314      -4.5006313920021057e-01
    z[4,0,1]  R315      -2.9721334576606750e-01
    z[4,0,1]  R316      -4.0150359272956848e-01
    z[4,0,1]  R317      -3.8969784975051880e-01
    z[4,0,1]  R318      -3.7562859058380127e-01
    z[4,0,1]  R319      -3.1049597263336182e-01
    z[4,0,1]  R320      3.8402697443962097e-01
    z[4,0,1]  R321      -2.2488430142402649e-01
    z[4,0,1]  R322      -2.9133029282093048e-02
    z[4,0,1]  R323      -3.5321453213691711e-01
    z[4,0,1]  R324      -4.7083371877670288e-01
    z[4,0,1]  R325      -3.0634710192680359e-01
    z[4,0,1]  R326      -4.5350956916809082e-01
    z[4,0,1]  R327      -2.1151988208293915e-01
    z[4,0,1]  R328      -1.7822524905204773e-01
    z[4,0,1]  R329      2.1170638501644135e-01
    z[4,0,1]  R330      -2.2562728822231293e-01
    z[4,0,1]  R331      -5.6426286697387695e-02
    z[4,0,1]  R332      -1.3580378890037537e-01
    z[4,0,1]  R333      4.9179205298423767e-01
    z[4,0,1]  R334      3.1875270605087280e-01
    z[4,0,1]  R335      2.9287168383598328e-01
    z[4,0,1]  R336      3.4953951835632324e-01
    z[4,0,1]  R337      -2.0246687531471252e-01
    z[4,0,1]  R338      2.4043197929859161e-01
    z[4,0,1]  R339      2.6027753949165344e-01
    z[4,0,1]  R340      9.2512935400009155e-02
    z[4,0,1]  R341      2.8046226501464844e-01
    z[4,0,1]  R342      3.3027130365371704e-01
    z[4,0,1]  R343      1.9726713001728058e-01
    z[4,0,1]  R344      1.5464492142200470e-01
    z[4,0,1]  R345      0.165940061211586
    z[4,0,1]  R346      2.0005369186401367e-01
    z[4,0,1]  R347      1.3052280247211456e-01
    z[4,0,1]  R348      -2.7297571301460266e-01
    z[4,0,1]  R349      0.584796130657196
    z[4,0,1]  R350      6.5547966957092285e-01
    z[4,0,1]  R351      0.813894510269165
    z[4,0,1]  R352      -9.6482020616531372e-01
    z[4,0,1]  R353      -9.5070582628250122e-01
    z[4,0,1]  R354      -9.6304059028625488e-01
    z[4,0,1]  R355      -0.615744411945343
    z[4,0,1]  R356      -3.2791653275489807e-01
    z[4,0,1]  R357      -0.351236492395401
    z[4,0,1]  R358      8.8573509454727173e-01
    z[4,0,1]  R359      0.747351348400116
    z[4,0,1]  R360      0.515515148639679
    z[4,0,1]  R361      3.2899799942970276e-01
    z[4,0,1]  R362      -6.3394135236740112e-01
    z[4,0,1]  R363      -6.9849067926406860e-01
    z[4,0,1]  R364      -0.319276362657547
    z[4,0,2]  R4        1
    z[4,0,2]  R40       -1
    z[4,0,2]  R290      -1
    z[4,0,2]  R291      1
    z[4,0,2]  R300      3.3723658323287964e-01
    z[4,0,2]  R301      2.1254646778106689e-01
    z[4,0,2]  R302      3.6979696154594421e-01
    z[4,0,2]  R303      -3.9338001608848572e-01
    z[4,0,2]  R304      -2.5375235080718994e-01
    z[4,0,2]  R305      -4.0026667714118958e-01
    z[4,0,2]  R306      -1.8174979090690613e-01
    z[4,0,2]  R307      -7.2701007127761841e-01
    z[4,0,2]  R308      6.9238655269145966e-02
    z[4,0,2]  R309      -1.9710262119770050e-01
    z[4,0,2]  R310      5.6447625160217285e-02
    z[4,0,2]  R311      2.0022470504045486e-02
    z[4,0,2]  R312      1.3306963443756104e-01
    z[4,0,2]  R313      -1.9731815159320831e-01
    z[4,0,2]  R314      -5.8517616987228394e-01
    z[4,0,2]  R315      6.3593953847885132e-01
    z[4,0,2]  R316      5.4929924011230469e-01
    z[4,0,2]  R317      5.8574265241622925e-01
    z[4,0,2]  R318      4.4907850027084351e-01
    z[4,0,2]  R319      5.3506422042846680e-01
    z[4,0,2]  R320      -4.1943371295928955e-01
    z[4,0,2]  R321      -3.1705504655838013e-01
    z[4,0,2]  R322      -5.5717867612838745e-01
    z[4,0,2]  R323      -3.3449560403823853e-01
    z[4,0,2]  R324      -5.0315749645233154e-01
    z[4,0,2]  R325      -3.1380680203437805e-01
    z[4,0,2]  R326      1.7505396157503128e-02
    z[4,0,2]  R327      -6.4479392766952515e-01
    z[4,0,2]  R328      -5.8811032772064209e-01
    z[4,0,2]  R329      4.3414118885993958e-01
    z[4,0,2]  R330      -1.1416142433881760e-01
    z[4,0,2]  R331      -4.8208889365196228e-01
    z[4,0,2]  R332      -2.0556335151195526e-01
    z[4,0,2]  R333      7.0926159620285034e-01
    z[4,0,2]  R334      0.772919774055481
    z[4,0,2]  R335      7.5071024894714355e-01
    z[4,0,2]  R336      6.2224715948104858e-01
    z[4,0,2]  R337      7.0781558752059937e-01
    z[4,0,2]  R338      6.2348848581314087e-01
    z[4,0,2]  R339      5.1360601186752319e-01
    z[4,0,2]  R340      5.3082358837127686e-01
    z[4,0,2]  R341      -6.0419633984565735e-02
    z[4,0,2]  R342      2.1885776892304420e-02
    z[4,0,2]  R343      1.0903645306825638e-01
    z[4,0,2]  R344      4.9447467923164368e-01
    z[4,0,2]  R345      4.3094620108604431e-01
    z[4,0,2]  R346      0.00629103509709239
    z[4,0,2]  R347      -1.3276146352291107e-01
    z[4,0,2]  R348      -5.1149517297744751e-01
    z[4,0,2]  R349      2.4407340213656425e-02
    z[4,0,2]  R350      -0.159625843167305
    z[4,0,2]  R351      1.3904790580272675e-01
    z[4,0,2]  R352      2.1737396717071533e-02
    z[4,0,2]  R353      -5.3422104567289352e-02
    z[4,0,2]  R354      -5.8959450572729111e-02
    z[4,0,2]  R355      -7.4105370044708252e-01
    z[4,0,2]  R356      -7.4771988391876221e-01
    z[4,0,2]  R357      -7.4837243556976318e-01
    z[4,0,2]  R358      1.5689648687839508e-01
    z[4,0,2]  R359      -4.3000534176826477e-01
    z[4,0,2]  R360      4.9908763170242310e-01
    z[4,0,2]  R361      5.4806298017501831e-01
    z[4,0,2]  R362      5.8260971307754517e-01
    z[4,0,2]  R363      3.3097898960113525e-01
    z[4,0,2]  R364      -7.4524426460266113e-01
    z[4,0,3]  R5        1
    z[4,0,3]  R41       -1
    z[4,0,3]  R292      -1
    z[4,0,3]  R293      1
    z[4,0,3]  R300      1.9407291710376740e-01
    z[4,0,3]  R301      3.7785834074020386e-01
    z[4,0,3]  R302      0.359621524810791
    z[4,0,3]  R303      3.5334849357604980e-01
    z[4,0,3]  R304      -5.9966671466827393e-01
    z[4,0,3]  R305      3.5166677832603455e-01
    z[4,0,3]  R306      -1.7718973755836487e-01
    z[4,0,3]  R307      -1.7114609479904175e-01
    z[4,0,3]  R308      1.0475947707891464e-01
    z[4,0,3]  R309      -1.4726942777633667e-01
    z[4,0,3]  R310      -7.2947158478200436e-03
    z[4,0,3]  R311      9.5679499208927155e-02
    z[4,0,3]  R312      3.3502838015556335e-01
    z[4,0,3]  R313      -1.4262425899505615e-01
    z[4,0,3]  R314      3.4569406509399414e-01
    z[4,0,3]  R315      -1.8511952459812164e-01
    z[4,0,3]  R316      1.8296670913696289e-01
    z[4,0,3]  R317      2.8348726034164429e-01
    z[4,0,3]  R318      -1.3576443493366241e-01
    z[4,0,3]  R319      1.6956056654453278e-01
    z[4,0,3]  R320      -4.3668370693922043e-02
    z[4,0,3]  R321      2.3234169185161591e-01
    z[4,0,3]  R322      4.1011381894350052e-02
    z[4,0,3]  R323      3.1981386244297028e-02
    z[4,0,3]  R324      0.309207946062088
    z[4,0,3]  R325      3.5993787646293640e-01
    z[4,0,3]  R326      5.1507014036178589e-01
    z[4,0,3]  R327      -3.3113643527030945e-01
    z[4,0,3]  R328      -0.296572744846344
    z[4,0,3]  R329      -1.6149322688579559e-01
    z[4,0,3]  R330      2.6683533191680908e-01
    z[4,0,3]  R331      -2.6365929841995239e-01
    z[4,0,3]  R332      -1.7282043397426605e-01
    z[4,0,3]  R333      -9.6074566245079041e-02
    z[4,0,3]  R334      2.1486331522464752e-01
    z[4,0,3]  R335      3.2078996300697327e-01
    z[4,0,3]  R336      1.3732829689979553e-01
    z[4,0,3]  R337      -4.2660561203956604e-01
    z[4,0,3]  R338      3.7029585242271423e-01
    z[4,0,3]  R339      -6.7879520356655121e-02
    z[4,0,3]  R340      0.385850191116333
    z[4,0,3]  R341      1.3266208767890930e-01
    z[4,0,3]  R342      5.3007531166076660e-01
    z[4,0,3]  R343      1.3118194043636322e-01
    z[4,0,3]  R344      1.6925455629825592e-01
    z[4,0,3]  R345      1.3480573892593384e-01
    z[4,0,3]  R346      -0.0965004414319992
    z[4,0,3]  R347      2.0687343180179596e-01
    z[4,0,3]  R348      -3.3261656761169434e-01
    z[4,0,3]  R349      -6.0069161653518677e-01
    z[4,0,3]  R350      -6.2040686607360840e-01
    z[4,0,3]  R351      -1.0429682582616806e-01
    z[4,0,3]  R352      0.0641801655292511
    z[4,0,3]  R353      -0.265689492225647
    z[4,0,3]  R354      6.4403064548969269e-02
    z[4,0,3]  R355      -7.1564622223377228e-02
    z[4,0,3]  R356      4.1718116402626038e-01
    z[4,0,3]  R357      2.1552835404872894e-01
    z[4,0,3]  R358      2.7608352899551392e-01
    z[4,0,3]  R359      -1.7727948725223541e-01
    z[4,0,3]  R360      5.3987507708370686e-03
    z[4,0,3]  R361      3.1298029422760010e-01
    z[4,0,3]  R362      1.7882123589515686e-02
    z[4,0,3]  R363      1.9838282465934753e-01
    z[4,0,3]  R364      4.3217512965202332e-01
    z[4,0,4]  R6        1
    z[4,0,4]  R42       -1
    z[4,0,4]  R294      -1
    z[4,0,4]  R295      1
    z[4,0,4]  R300      -5.3325051069259644e-01
    z[4,0,4]  R301      3.5291498899459839e-01
    z[4,0,4]  R302      -7.4833756685256958e-01
    z[4,0,4]  R303      9.6530608832836151e-02
    z[4,0,4]  R304      1.3895675539970398e-01
    z[4,0,4]  R305      2.2054056823253632e-01
    z[4,0,4]  R306      -2.8322175145149231e-01
    z[4,0,4]  R307      1.1401998996734619e-01
    z[4,0,4]  R308      -1.3707152009010315e-01
    z[4,0,4]  R309      4.4733222573995590e-02
    z[4,0,4]  R310      2.6117414236068726e-01
    z[4,0,4]  R311      4.9561902880668640e-01
    z[4,0,4]  R312      0.406207412481308
    z[4,0,4]  R313      -3.5524827241897583e-01
    z[4,0,4]  R314      3.7169721722602844e-01
    z[4,0,4]  R315      -3.1640312075614929e-01
    z[4,0,4]  R316      -4.2178431153297424e-01
    z[4,0,4]  R317      -2.5168126821517944e-01
    z[4,0,4]  R318      -4.4645896553993225e-01
    z[4,0,4]  R319      -3.5246381163597107e-01
    z[4,0,4]  R320      0.280819296836853
    z[4,0,4]  R321      4.3981426954269409e-01
    z[4,0,4]  R322      4.0599894709885120e-03
    z[4,0,4]  R323      -4.7642147541046143e-01
    z[4,0,4]  R324      2.0234338939189911e-01
    z[4,0,4]  R325      5.0732856988906860e-01
    z[4,0,4]  R326      -2.6159477233886719e-01
    z[4,0,4]  R327      1.0549803078174591e-01
    z[4,0,4]  R328      3.7096962332725525e-01
    z[4,0,4]  R329      -4.3181905150413513e-01
    z[4,0,4]  R330      1.6442857682704926e-01
    z[4,0,4]  R331      4.8693239688873291e-01
    z[4,0,4]  R332      6.7832469940185547e-02
    z[4,0,4]  R333      2.7059277892112732e-01
    z[4,0,4]  R334      -3.8322050124406815e-02
    z[4,0,4]  R335      1.9262421131134033e-01
    z[4,0,4]  R336      -1.2879092991352081e-01
    z[4,0,4]  R337      -1.4227072894573212e-01
    z[4,0,4]  R338      2.0265898108482361e-01
    z[4,0,4]  R339      -0.612044095993042
    z[4,0,4]  R340      -5.2262353897094727e-01
    z[4,0,4]  R341      1.0441654175519943e-01
    z[4,0,4]  R342      2.2773596644401550e-01
    z[4,0,4]  R343      2.9111242294311523e-01
    z[4,0,4]  R344      2.2869792580604553e-01
    z[4,0,4]  R345      -4.0259966254234314e-01
    z[4,0,4]  R346      -0.286471426486969
    z[4,0,4]  R347      -0.689846396446228
    z[4,0,4]  R348      3.4563422203063965e-02
    z[4,0,4]  R349      -1.7491841316223145e-01
    z[4,0,4]  R350      2.4612756073474884e-01
    z[4,0,4]  R351      -3.0498182773590088e-01
    z[4,0,4]  R352      1.1260775476694107e-01
    z[4,0,4]  R353      3.5520192235708237e-02
    z[4,0,4]  R354      -8.8303722441196442e-02
    z[4,0,4]  R355      3.5890364088118076e-03
    z[4,0,4]  R356      -8.1895049661397934e-03
    z[4,0,4]  R357      4.2021960020065308e-01
    z[4,0,4]  R358      -3.1353679299354553e-01
    z[4,0,4]  R359      -2.8633216023445129e-01
    z[4,0,4]  R360      5.0904160737991333e-01
    z[4,0,4]  R361      1.8660099804401398e-01
    z[4,0,4]  R362      2.9098801314830780e-03
    z[4,0,4]  R363      -4.2806175351142883e-01
    z[4,0,4]  R364      1.9860044121742249e-01
    z[4,0,5]  R7        1
    z[4,0,5]  R43       -1
    z[4,0,5]  R296      -1
    z[4,0,5]  R297      1
    z[4,0,5]  R300      6.5626579523086548e-01
    z[4,0,5]  R301      6.6537988185882568e-01
    z[4,0,5]  R302      3.3398557454347610e-02
    z[4,0,5]  R303      -5.4162133485078812e-02
    z[4,0,5]  R304      4.6772268414497375e-01
    z[4,0,5]  R305      1.5188623964786530e-01
    z[4,0,5]  R306      -1.6468483209609985e-01
    z[4,0,5]  R307      5.0029838085174561e-01
    z[4,0,5]  R308      -1.1389130959287286e-03
    z[4,0,5]  R309      -5.6748535484075546e-02
    z[4,0,5]  R310      -6.2615203857421875e-01
    z[4,0,5]  R311      1.6065572202205658e-01
    z[4,0,5]  R312      6.4777636528015137e-01
    z[4,0,5]  R313      -5.0720870494842529e-01
    z[4,0,5]  R314      -3.6588084697723389e-01
    z[4,0,5]  R315      7.4011576361954212e-03
    z[4,0,5]  R316      -1.0231139510869980e-01
    z[4,0,5]  R317      -3.2818627357482910e-01
    z[4,0,5]  R318      -3.0741935968399048e-01
    z[4,0,5]  R319      -4.0899041295051575e-01
    z[4,0,5]  R320      1.0906521230936050e-01
    z[4,0,5]  R321      2.3966281116008759e-01
    z[4,0,5]  R322      3.5929358005523682e-01
    z[4,0,5]  R323      3.1823945045471191e-01
    z[4,0,5]  R324      2.2841575741767883e-01
    z[4,0,5]  R325      -3.8880008459091187e-01
    z[4,0,5]  R326      3.3971187472343445e-01
    z[4,0,5]  R327      5.5800056457519531e-01
    z[4,0,5]  R328      3.8121134042739868e-01
    z[4,0,5]  R329      5.7679861783981323e-01
    z[4,0,5]  R330      -1.6769881546497345e-01
    z[4,0,5]  R331      -3.3462487161159515e-02
    z[4,0,5]  R332      8.8889855146408081e-01
    z[4,0,5]  R333      -2.6256833225488663e-02
    z[4,0,5]  R334      1.5315471589565277e-01
    z[4,0,5]  R335      -2.9874238371849060e-01
    z[4,0,5]  R336      -5.6345868110656738e-01
    z[4,0,5]  R337      9.4821535050868988e-02
    z[4,0,5]  R338      5.5513250827789307e-01
    z[4,0,5]  R339      4.9365133047103882e-01
    z[4,0,5]  R340      1.9890367984771729e-01
    z[4,0,5]  R341      8.9978581666946411e-01
    z[4,0,5]  R342      -2.2785457968711853e-01
    z[4,0,5]  R343      3.4662586450576782e-01
    z[4,0,5]  R344      -6.4428210258483887e-02
    z[4,0,5]  R345      4.3015927076339722e-01
    z[4,0,5]  R346      6.4604347944259644e-01
    z[4,0,5]  R347      4.9847480654716492e-01
    z[4,0,5]  R348      -8.8586784899234772e-02
    z[4,0,5]  R349      -4.9111318588256836e-01
    z[4,0,5]  R350      -3.1351727247238159e-01
    z[4,0,5]  R351      -3.4089747071266174e-01
    z[4,0,5]  R352      1.2597735226154327e-01
    z[4,0,5]  R353      4.8162639141082764e-02
    z[4,0,5]  R354      -8.4397055208683014e-02
    z[4,0,5]  R355      0.0746607631444931
    z[4,0,5]  R356      -4.8730060458183289e-02
    z[4,0,5]  R357      -6.5307103097438812e-02
    z[4,0,5]  R358      1.1304462701082230e-01
    z[4,0,5]  R359      1.0431724786758423e-01
    z[4,0,5]  R360      -1.9295139610767365e-01
    z[4,0,5]  R361      -5.9720021486282349e-01
    z[4,0,5]  R362      -4.4581872224807739e-01
    z[4,0,5]  R363      -2.0345355570316315e-01
    z[4,0,5]  R364      1.0707014799118042e-01
    z[4,0,6]  R8        1
    z[4,0,6]  R44       -1
    z[4,0,6]  R298      -1
    z[4,0,6]  R299      1
    z[4,0,6]  R300      9.7905740141868591e-02
    z[4,0,6]  R301      4.9548465758562088e-02
    z[4,0,6]  R302      -2.7058309316635132e-01
    z[4,0,6]  R303      7.8890067338943481e-01
    z[4,0,6]  R304      -2.9685431718826294e-01
    z[4,0,6]  R305      -4.8208922147750854e-01
    z[4,0,6]  R306      -7.2780676186084747e-02
    z[4,0,6]  R307      2.2448913753032684e-01
    z[4,0,6]  R308      -3.6659315228462219e-01
    z[4,0,6]  R309      3.4811830520629883e-01
    z[4,0,6]  R310      -1.2709483504295349e-01
    z[4,0,6]  R311      -2.7647811919450760e-02
    z[4,0,6]  R312      1.4032294973731041e-02
    z[4,0,6]  R313      8.1678237766027451e-03
    z[4,0,6]  R314      1.7205484211444855e-02
    z[4,0,6]  R315      2.7510038018226624e-01
    z[4,0,6]  R316      -1.1160384118556976e-01
    z[4,0,6]  R317      5.5536616593599319e-02
    z[4,0,6]  R318      0.102850541472435
    z[4,0,6]  R319      -0.169743612408638
    z[4,0,6]  R320      2.2508314251899719e-01
    z[4,0,6]  R321      5.0840977579355240e-02
    z[4,0,6]  R322      -3.4815722703933716e-01
    z[4,0,6]  R323      1.5809737145900726e-02
    z[4,0,6]  R324      2.1920089423656464e-01
    z[4,0,6]  R325      -5.2649658173322678e-02
    z[4,0,6]  R326      3.3853590488433838e-01
    z[4,0,6]  R327      -1.3766942918300629e-01
    z[4,0,6]  R328      -3.5886257886886597e-01
    z[4,0,6]  R329      2.4111849069595337e-01
    z[4,0,6]  R330      9.4328567385673523e-02
    z[4,0,6]  R331      -3.5025981068611145e-01
    z[4,0,6]  R332      -5.4601531475782394e-02
    z[4,0,6]  R333      -1.1535544693470001e-01
    z[4,0,6]  R334      3.6942100524902344e-01
    z[4,0,6]  R335      1.6169679164886475e-01
    z[4,0,6]  R336      2.3860198259353638e-01
    z[4,0,6]  R337      -3.7413170933723450e-01
    z[4,0,6]  R338      -1.0443992167711258e-01
    z[4,0,6]  R339      2.0704253017902374e-01
    z[4,0,6]  R340      -3.7843844294548035e-01
    z[4,0,6]  R341      1.6907177865505219e-01
    z[4,0,6]  R342      -6.5695017576217651e-01
    z[4,0,6]  R343      8.4132587909698486e-01
    z[4,0,6]  R344      7.2270631790161133e-01
    z[4,0,6]  R345      5.7766944169998169e-01
    z[4,0,6]  R346      -5.5377554893493652e-01
    z[4,0,6]  R347      4.0495449304580688e-01
    z[4,0,6]  R348      -3.5102754831314087e-02
    z[4,0,6]  R349      -6.2441930174827576e-02
    z[4,0,6]  R350      3.2508194446563721e-02
    z[4,0,6]  R351      -2.5555622577667236e-01
    z[4,0,6]  R352      -1.1863992363214493e-01
    z[4,0,6]  R353      8.3991914987564087e-02
    z[4,0,6]  R354      0.165150448679924
    z[4,0,6]  R355      -1.2029287219047546e-01
    z[4,0,6]  R356      -8.5812814533710480e-02
    z[4,0,6]  R357      -8.5258044302463531e-02
    z[4,0,6]  R358      -1.7352037131786346e-02
    z[4,0,6]  R359      -2.2686515748500824e-01
    z[4,0,6]  R360      1.3418383896350861e-01
    z[4,0,6]  R361      3.1480649113655090e-01
    z[4,0,6]  R362      -1.7384201288223267e-01
    z[4,0,6]  R363      -3.6519017815589905e-01
    z[4,0,6]  R364      2.6070675253868103e-01
    z[1,2,0]  R11       -1
    z[1,2,0]  R20       1
    z[1,2,0]  R406      -1
    z[1,2,0]  R407      1
    z[1,2,0]  R420      2.4657995998859406e-01
    z[1,2,0]  R421      0.255929559469223
    z[1,2,0]  R422      -1.8523028492927551e-01
    z[1,2,0]  R423      -1.9604268670082092e-01
    z[1,2,0]  R424      -2.2875583171844482e-01
    z[1,2,0]  R425      -1.6787399351596832e-01
    z[1,2,0]  R426      9.0189540386199951e-01
    z[1,2,0]  R427      8.8136249780654907e-01
    z[1,2,0]  R428      8.4615147113800049e-01
    z[1,2,0]  R429      -3.2924351096153259e-01
    z[1,2,0]  R430      3.9918351918458939e-02
    z[1,2,0]  R431      -5.6306332349777222e-02
    z[1,2,0]  R432      -5.9193450212478638e-01
    z[1,2,0]  R433      -8.7908446788787842e-01
    z[1,2,0]  R434      -8.4026736021041870e-01
    z[1,2,0]  R435      -7.2747319936752319e-01
    z[1,2,0]  R436      -6.2574809789657593e-01
    z[1,2,0]  R437      -1.8546107411384583e-01
    z[1,2,0]  R438      3.2135257124900818e-01
    z[1,2,0]  R439      2.1261560916900635e-01
    z[1,2,0]  R440      3.8622301816940308e-01
    z[1,2,0]  R441      -6.2194317579269409e-01
    z[1,2,0]  R442      5.9298551082611084e-01
    z[1,2,0]  R443      -8.3533978462219238e-01
    z[1,2,0]  R444      -2.7348718047142029e-01
    z[1,2,0]  R445      6.3934868574142456e-01
    z[1,2,0]  R446      -2.1891364455223083e-01
    z[1,2,0]  R447      -3.1954467296600342e-01
    z[1,2,0]  R448      3.1205892562866211e-01
    z[1,2,0]  R449      3.0639445781707764e-01
    z[1,2,0]  R450      -3.9224180579185486e-01
    z[1,2,0]  R451      -3.5216581821441650e-01
    z[1,2,0]  R452      0.797160267829895
    z[1,2,0]  R453      -4.2389002442359924e-01
    z[1,2,0]  R454      6.8974149227142334e-01
    z[1,2,0]  R455      7.9577147960662842e-01
    z[1,2,0]  R456      -6.8320196866989136e-01
    z[1,2,0]  R457      7.5881582498550415e-01
    z[1,2,0]  R458      6.3608884811401367e-01
    z[1,2,0]  R459      7.3341244459152222e-01
    z[1,2,0]  R460      -8.1882697343826294e-01
    z[1,2,0]  R461      3.5091996192932129e-01
    z[1,2,0]  R462      8.4362350404262543e-02
    z[1,2,0]  R463      -7.2980821132659912e-01
    z[1,2,0]  R464      1.9111198186874390e-01
    z[1,2,0]  R465      -1.4493685960769653e-01
    z[1,2,0]  R466      -1.6609892249107361e-01
    z[1,2,0]  R467      -5.5685228109359741e-01
    z[1,2,0]  R468      0.319084495306015
    z[1,2,0]  R469      -6.5375095605850220e-01
    z[1,2,0]  R470      -7.2028857469558716e-01
    z[1,2,0]  R471      -7.1874296665191650e-01
    z[1,2,0]  R472      -0.296962708234787
    z[1,2,0]  R473      -7.2221815586090088e-01
    z[1,2,0]  R474      -0.374138206243515
    z[1,2,0]  R475      -7.7556854486465454e-01
    z[1,2,0]  R476      -7.4139153957366943e-01
    z[1,2,0]  R477      -3.9027959108352661e-02
    z[1,2,0]  R478      3.6240735650062561e-01
    z[1,2,0]  R479      -6.0498553514480591e-01
    z[1,2,0]  R480      -1.0302574932575226e-01
    z[1,2,0]  R481      -5.9329774230718613e-02
    z[1,2,0]  R482      -3.0037942528724670e-01
    z[1,2,0]  R483      -0.743958592414856
    z[1,2,0]  R484      -7.8501778841018677e-01
    z[1,2,0]  R485      -7.5105243921279907e-01
    z[1,2,0]  R486      -5.6015497446060181e-01
    z[1,2,0]  R487      -8.9161342382431030e-01
    z[1,2,0]  R488      -5.9007924795150757e-01
    z[1,2,0]  R489      -8.1120771169662476e-01
    z[1,2,0]  R490      -7.1645969152450562e-01
    z[1,2,0]  R491      -6.8813055753707886e-01
    z[1,2,0]  R492      -4.4439971446990967e-01
    z[1,2,0]  R493      -3.7683433294296265e-01
    z[1,2,0]  R494      -3.2920166850090027e-01
    z[1,2,0]  R495      -7.2472792863845825e-01
    z[1,2,0]  R496      4.9414688348770142e-01
    z[1,2,0]  R497      4.4974252581596375e-01
    z[1,2,0]  R498      9.6794553101062775e-02
    z[1,2,0]  R499      -4.8676044680178165e-03
    z[1,2,0]  R500      -2.4586421251296997e-01
    z[1,2,0]  R501      1.1634296923875809e-01
    z[1,2,0]  R502      0.600662350654602
    z[1,2,0]  R503      2.7329126000404358e-01
    z[1,2,0]  R504      6.2698286771774292e-01
    z[1,2,0]  R505      2.1078411489725113e-02
    z[1,2,0]  R506      2.4044297635555267e-01
    z[1,2,0]  R507      -3.8858661055564880e-01
    z[1,2,0]  R508      -4.6192719601094723e-03
    z[1,2,0]  R509      5.2527695894241333e-01
    z[1,2,0]  R510      -6.3333630561828613e-01
    z[1,2,0]  R511      4.8260340094566345e-01
    z[1,2,0]  R512      -6.0316592454910278e-01
    z[1,2,0]  R513      3.4032773971557617e-01
    z[1,2,0]  R514      2.0777510106563568e-01
    z[1,2,0]  R515      -3.5108034498989582e-03
    z[1,2,0]  R516      4.8921483755111694e-01
    z[1,2,0]  R517      -9.1450080275535583e-02
    z[1,2,0]  R518      2.1135492622852325e-01
    z[1,2,0]  R519      2.4746231734752655e-01
    z[1,2,0]  R520      -1.0800433158874512e-01
    z[1,2,0]  R521      -4.7529187798500061e-01
    z[1,2,0]  R522      -0.620422899723053
    z[1,2,0]  R523      -8.1994032859802246e-01
    z[1,2,0]  R524      2.0614795386791229e-01
    z[1,2,0]  R525      -7.1798115968704224e-02
    z[1,2,0]  R526      2.6360219717025757e-01
    z[1,2,0]  R527      1.6038280725479126e-01
    z[1,2,0]  R528      6.0919380187988281e-01
    z[1,2,0]  R529      7.2385388612747192e-01
    z[1,2,1]  R12       -1
    z[1,2,1]  R21       1
    z[1,2,1]  R408      -1
    z[1,2,1]  R409      1
    z[1,2,1]  R420      2.5135436654090881e-01
    z[1,2,1]  R421      0.420491099357605
    z[1,2,1]  R422      2.5548499822616577e-01
    z[1,2,1]  R423      1.5653695166110992e-01
    z[1,2,1]  R424      1.7599220573902130e-01
    z[1,2,1]  R425      2.3999880254268646e-01
    z[1,2,1]  R426      1.9431927800178528e-01
    z[1,2,1]  R427      -1.5722972154617310e-01
    z[1,2,1]  R428      -1.4477474987506866e-01
    z[1,2,1]  R429      3.7604832649230957e-01
    z[1,2,1]  R430      0.689096212387085
    z[1,2,1]  R431      5.3424453735351562e-01
    z[1,2,1]  R432      4.8140963912010193e-01
    z[1,2,1]  R433      -7.9528607428073883e-02
    z[1,2,1]  R434      -2.2351981699466705e-01
    z[1,2,1]  R435      -1.5993355214595795e-01
    z[1,2,1]  R436      -3.0037540197372437e-01
    z[1,2,1]  R437      -3.6878433078527451e-02
    z[1,2,1]  R438      1.3351911678910255e-02
    z[1,2,1]  R439      1.3604276813566685e-02
    z[1,2,1]  R440      2.8984868526458740e-01
    z[1,2,1]  R441      2.1480667591094971e-01
    z[1,2,1]  R442      -0.0954454317688942
    z[1,2,1]  R443      8.9969672262668610e-02
    z[1,2,1]  R444      -1.0357370972633362e-01
    z[1,2,1]  R445      3.8562972098588943e-02
    z[1,2,1]  R446      7.2650928050279617e-03
    z[1,2,1]  R447      -1.8665449321269989e-01
    z[1,2,1]  R448      -3.9170585572719574e-02
    z[1,2,1]  R449      -5.0568240880966187e-01
    z[1,2,1]  R450      1.6793204471468925e-02
    z[1,2,1]  R451      4.1982802748680115e-01
    z[1,2,1]  R452      -3.0217638611793518e-01
    z[1,2,1]  R453      3.3735528588294983e-01
    z[1,2,1]  R454      -2.1396717429161072e-01
    z[1,2,1]  R455      -1.4922298491001129e-01
    z[1,2,1]  R456      -4.6211519837379456e-01
    z[1,2,1]  R457      -2.4508625268936157e-01
    z[1,2,1]  R458      -1.8263725936412811e-01
    z[1,2,1]  R459      -2.3488880693912506e-01
    z[1,2,1]  R460      -1.6358684003353119e-01
    z[1,2,1]  R461      5.3442692756652832e-01
    z[1,2,1]  R462      5.0623804330825806e-01
    z[1,2,1]  R463      4.6645689010620117e-01
    z[1,2,1]  R464      6.5295898914337158e-01
    z[1,2,1]  R465      -9.4652932882308960e-01
    z[1,2,1]  R466      -0.909305214881897
    z[1,2,1]  R467      6.1326795816421509e-01
    z[1,2,1]  R468      5.5151903629302979e-01
    z[1,2,1]  R469      4.0061524510383606e-01
    z[1,2,1]  R470      -0.264529287815094
    z[1,2,1]  R471      -1.4760753512382507e-01
    z[1,2,1]  R472      7.9781192541122437e-01
    z[1,2,1]  R473      -1.7197097837924957e-01
    z[1,2,1]  R474      1.4941245317459106e-01
    z[1,2,1]  R475      4.4548544287681580e-01
    z[1,2,1]  R476      0.653929591178894
    z[1,2,1]  R477      4.0577349066734314e-01
    z[1,2,1]  R478      -3.6976438760757446e-01
    z[1,2,1]  R479      -6.7304052412509918e-02
    z[1,2,1]  R480      4.9294161796569824e-01
    z[1,2,1]  R481      3.5584241151809692e-01
    z[1,2,1]  R482      3.9754968881607056e-01
    z[1,2,1]  R483      1.6869686543941498e-02
    z[1,2,1]  R484      7.1616090834140778e-02
    z[1,2,1]  R485      2.5303310155868530e-01
    z[1,2,1]  R486      -1.7502473667263985e-02
    z[1,2,1]  R487      6.7946580238640308e-03
    z[1,2,1]  R488      -4.3117246031761169e-01
    z[1,2,1]  R489      3.8872316479682922e-01
    z[1,2,1]  R490      -1.3841395080089569e-01
    z[1,2,1]  R491      -4.6720635145902634e-02
    z[1,2,1]  R492      5.3251668810844421e-02
    z[1,2,1]  R493      3.9715209603309631e-01
    z[1,2,1]  R494      -2.7576866745948792e-01
    z[1,2,1]  R495      4.9373021721839905e-01
    z[1,2,1]  R496      -5.0862950086593628e-01
    z[1,2,1]  R497      -4.7206935286521912e-01
    z[1,2,1]  R498      -9.2534351348876953e-01
    z[1,2,1]  R499      -9.3733829259872437e-01
    z[1,2,1]  R500      5.0692892074584961e-01
    z[1,2,1]  R501      5.6872403621673584e-01
    z[1,2,1]  R502      -5.3618443012237549e-01
    z[1,2,1]  R503      -6.4487606287002563e-01
    z[1,2,1]  R504      -3.6818471550941467e-01
    z[1,2,1]  R505      -7.2963792085647583e-01
    z[1,2,1]  R506      -8.2487720251083374e-01
    z[1,2,1]  R507      7.6968425512313843e-01
    z[1,2,1]  R508      -7.7254432439804077e-01
    z[1,2,1]  R509      -2.3884780704975128e-01
    z[1,2,1]  R510      3.0962151288986206e-01
    z[1,2,1]  R511      -5.0188940763473511e-01
    z[1,2,1]  R512      -9.2821039259433746e-02
    z[1,2,1]  R513      -2.9327511787414551e-01
    z[1,2,1]  R514      -0.954384446144104
    z[1,2,1]  R515      -8.4556078910827637e-01
    z[1,2,1]  R516      -1.5219414234161377e-01
    z[1,2,1]  R517      -8.5327720642089844e-01
    z[1,2,1]  R518      -8.0013388395309448e-01
    z[1,2,1]  R519      -0.837171733379364
    z[1,2,1]  R520      5.9243518114089966e-01
    z[1,2,1]  R521      5.3607380390167236e-01
    z[1,2,1]  R522      5.0177198648452759e-01
    z[1,2,1]  R523      -4.3665003776550293e-01
    z[1,2,1]  R524      -9.2628234624862671e-01
    z[1,2,1]  R525      -8.7773799896240234e-01
    z[1,2,1]  R526      9.4409698247909546e-01
    z[1,2,1]  R527      9.3283069133758545e-01
    z[1,2,1]  R528      4.4027809053659439e-02
    z[1,2,1]  R529      -4.1449481248855591e-01
    z[1,2,2]  R13       -1
    z[1,2,2]  R22       1
    z[1,2,2]  R410      -1
    z[1,2,2]  R411      1
    z[1,2,2]  R420      3.3723658323287964e-01
    z[1,2,2]  R421      2.1254646778106689e-01
    z[1,2,2]  R422      3.6979696154594421e-01
    z[1,2,2]  R423      8.1125551462173462e-01
    z[1,2,2]  R424      8.3727121353149414e-01
    z[1,2,2]  R425      -3.9338001608848572e-01
    z[1,2,2]  R426      -6.8045049905776978e-02
    z[1,2,2]  R427      5.2481066435575485e-02
    z[1,2,2]  R428      2.3879086971282959e-01
    z[1,2,2]  R429      -2.5375235080718994e-01
    z[1,2,2]  R430      -2.2355543076992035e-01
    z[1,2,2]  R431      -1.0044532269239426e-01
    z[1,2,2]  R432      -5.8036994934082031e-01
    z[1,2,2]  R433      -1.7762959003448486e-01
    z[1,2,2]  R434      -3.6471266299486160e-02
    z[1,2,2]  R435      -3.6093726754188538e-01
    z[1,2,2]  R436      -3.0557924509048462e-01
    z[1,2,2]  R437      -1.9537086784839630e-01
    z[1,2,2]  R438      -1.2592333555221558e-01
    z[1,2,2]  R439      2.4499481916427612e-01
    z[1,2,2]  R440      -1.9908134639263153e-01
    z[1,2,2]  R441      -5.0699585676193237e-01
    z[1,2,2]  R442      3.3400547504425049e-01
    z[1,2,2]  R443      1.7254938185214996e-01
    z[1,2,2]  R444      -2.0253041386604309e-01
    z[1,2,2]  R445      -3.6949047446250916e-01
    z[1,2,2]  R446      -7.6224929094314575e-01
    z[1,2,2]  R447      5.7550603523850441e-03
    z[1,2,2]  R448      6.9921833276748657e-01
    z[1,2,2]  R449      3.4651690721511841e-01
    z[1,2,2]  R450      5.3428955376148224e-02
    z[1,2,2]  R451      4.7465705871582031e-01
    z[1,2,2]  R452      3.6648120731115341e-02
    z[1,2,2]  R453      0.377734899520874
    z[1,2,2]  R454      6.5484158694744110e-02
    z[1,2,2]  R455      -1.2441141903400421e-01
    z[1,2,2]  R456      2.5291427969932556e-01
    z[1,2,2]  R457      -2.6075729727745056e-01
    z[1,2,2]  R458      -2.3586069047451019e-01
    z[1,2,2]  R459      2.9757454991340637e-01
    z[1,2,2]  R460      1.2146435678005219e-01
    z[1,2,2]  R461      -4.2763182520866394e-01
    z[1,2,2]  R462      0.0552813895046711
    z[1,2,2]  R463      -3.2051667571067810e-01
    z[1,2,2]  R464      -5.6332081556320190e-01
    z[1,2,2]  R465      4.8455204814672470e-02
    z[1,2,2]  R466      2.8371301293373108e-01
    z[1,2,2]  R467      -2.1615797281265259e-01
    z[1,2,2]  R468      -3.4118276834487915e-01
    z[1,2,2]  R469      -4.3730372190475464e-01
    z[1,2,2]  R470      4.1211673617362976e-01
    z[1,2,2]  R471      4.9223366379737854e-01
    z[1,2,2]  R472      -1.7958946526050568e-02
    z[1,2,2]  R473      4.7048786282539368e-01
    z[1,2,2]  R474      -3.8058489561080933e-01
    z[1,2,2]  R475      -3.2974272966384888e-01
    z[1,2,2]  R476      5.8110468089580536e-02
    z[1,2,2]  R477      -1.9358810782432556e-01
    z[1,2,2]  R478      -6.7814439535140991e-01
    z[1,2,2]  R479      -0.0276302732527256
    z[1,2,2]  R480      -1.1719395220279694e-01
    z[1,2,2]  R481      -9.6887126564979553e-02
    z[1,2,2]  R482      3.9203721284866333e-01
    z[1,2,2]  R483      -9.0094834566116333e-02
    z[1,2,2]  R484      4.0363538265228271e-01
    z[1,2,2]  R485      2.3727929592132568e-01
    z[1,2,2]  R486      3.7829467654228210e-01
    z[1,2,2]  R487      2.0727132260799408e-01
    z[1,2,2]  R488      -3.5161191225051880e-01
    z[1,2,2]  R489      -1.8203815817832947e-01
    z[1,2,2]  R490      5.9477311372756958e-01
    z[1,2,2]  R491      3.3852979540824890e-01
    z[1,2,2]  R492      0.564498245716095
    z[1,2,2]  R493      -3.1396320462226868e-01
    z[1,2,2]  R494      1.2137076258659363e-01
    z[1,2,2]  R495      -3.5435834527015686e-01
    z[1,2,2]  R496      -0.539020299911499
    z[1,2,2]  R497      -2.3951514065265656e-01
    z[1,2,2]  R498      1.6637371480464935e-01
    z[1,2,2]  R499      -6.2574379146099091e-02
    z[1,2,2]  R500      1.5445311367511749e-01
    z[1,2,2]  R501      -3.8655731081962585e-01
    z[1,2,2]  R502      -2.5803402066230774e-01
    z[1,2,2]  R503      -5.0074491649866104e-02
    z[1,2,2]  R504      -1.7812184989452362e-01
    z[1,2,2]  R505      6.3637781143188477e-01
    z[1,2,2]  R506      4.4004756212234497e-01
    z[1,2,2]  R507      -3.7844008207321167e-01
    z[1,2,2]  R508      4.7437658905982971e-01
    z[1,2,2]  R509      -1.9614732265472412e-01
    z[1,2,2]  R510      2.9345509409904480e-01
    z[1,2,2]  R511      1.8945498391985893e-02
    z[1,2,2]  R512      -2.8382557630538940e-01
    z[1,2,2]  R513      -7.5607880949974060e-02
    z[1,2,2]  R514      4.0291804820299149e-02
    z[1,2,2]  R515      -3.9303341507911682e-01
    z[1,2,2]  R516      2.5031521916389465e-01
    z[1,2,2]  R517      3.0954939126968384e-01
    z[1,2,2]  R518      2.4709241092205048e-01
    z[1,2,2]  R519      -1.3379940390586853e-01
    z[1,2,2]  R520      0.374731183052063
    z[1,2,2]  R521      -2.3399564623832703e-01
    z[1,2,2]  R522      -1.5763019025325775e-01
    z[1,2,2]  R523      -2.4272593855857849e-01
    z[1,2,2]  R524      1.6245366632938385e-01
    z[1,2,2]  R525      -2.3109002411365509e-01
    z[1,2,2]  R526      5.0432592630386353e-02
    z[1,2,2]  R527      1.3996334373950958e-01
    z[1,2,2]  R528      0.632743239402771
    z[1,2,2]  R529      -1.8757671117782593e-01
    z[1,2,3]  R14       -1
    z[1,2,3]  R23       1
    z[1,2,3]  R412      -1
    z[1,2,3]  R413      1
    z[1,2,3]  R420      1.9407291710376740e-01
    z[1,2,3]  R421      3.7785834074020386e-01
    z[1,2,3]  R422      0.359621524810791
    z[1,2,3]  R423      1.1336320638656616e-01
    z[1,2,3]  R424      -1.7726014554500580e-01
    z[1,2,3]  R425      3.5334849357604980e-01
    z[1,2,3]  R426      -1.6869869828224182e-01
    z[1,2,3]  R427      1.1771301925182343e-01
    z[1,2,3]  R428      -7.7181234955787659e-02
    z[1,2,3]  R429      -5.9966671466827393e-01
    z[1,2,3]  R430      -2.7676156163215637e-01
    z[1,2,3]  R431      2.1508021652698517e-01
    z[1,2,3]  R432      9.7305081784725189e-02
    z[1,2,3]  R433      0.0887034460902214
    z[1,2,3]  R434      3.4676992893218994e-01
    z[1,2,3]  R435      2.7455356717109680e-01
    z[1,2,3]  R436      4.8621648550033569e-01
    z[1,2,3]  R437      -4.0148496627807617e-03
    z[1,2,3]  R438      2.8074583411216736e-01
    z[1,2,3]  R439      1.6979804635047913e-01
    z[1,2,3]  R440      3.2959511876106262e-01
    z[1,2,3]  R441      -8.2395315170288086e-02
    z[1,2,3]  R442      1.8020935356616974e-02
    z[1,2,3]  R443      -2.4140359461307526e-01
    z[1,2,3]  R444      5.4319225251674652e-02
    z[1,2,3]  R445      7.3736339807510376e-02
    z[1,2,3]  R446      3.0708810687065125e-01
    z[1,2,3]  R447      1.3325117528438568e-02
    z[1,2,3]  R448      -2.1088348329067230e-01
    z[1,2,3]  R449      1.6426447033882141e-01
    z[1,2,3]  R450      -5.7658666372299194e-01
    z[1,2,3]  R451      -4.8413532972335815e-01
    z[1,2,3]  R452      5.0298297405242920e-01
    z[1,2,3]  R453      -3.8413512706756592e-01
    z[1,2,3]  R454      6.3380491733551025e-01
    z[1,2,3]  R455      4.7572395205497742e-01
    z[1,2,3]  R456      -4.7816762328147888e-01
    z[1,2,3]  R457      4.1079682111740112e-01
    z[1,2,3]  R458      6.8301928043365479e-01
    z[1,2,3]  R459      4.1419026255607605e-01
    z[1,2,3]  R460      5.2072703838348389e-01
    z[1,2,3]  R461      -4.7158092260360718e-01
    z[1,2,3]  R462      -4.2060464620590210e-01
    z[1,2,3]  R463      -2.1827220916748047e-02
    z[1,2,3]  R464      -4.3719586730003357e-01
    z[1,2,3]  R465      2.4062652885913849e-01
    z[1,2,3]  R466      1.5694554895162582e-02
    z[1,2,3]  R467      4.5493260025978088e-01
    z[1,2,3]  R468      -5.2448230981826782e-01
    z[1,2,3]  R469      1.5438485145568848e-01
    z[1,2,3]  R470      -9.3475859612226486e-03
    z[1,2,3]  R471      -7.0925705134868622e-02
    z[1,2,3]  R472      -3.5661661624908447e-01
    z[1,2,3]  R473      3.1329268217086792e-01
    z[1,2,3]  R474      -7.3681735992431641e-01
    z[1,2,3]  R475      1.6105762124061584e-01
    z[1,2,3]  R476      2.0723575726151466e-03
    z[1,2,3]  R477      -8.0785721540451050e-01
    z[1,2,3]  R478      2.6825010776519775e-01
    z[1,2,3]  R479      1.4808334410190582e-01
    z[1,2,3]  R480      -5.6925994157791138e-01
    z[1,2,3]  R481      -7.7147370576858521e-01
    z[1,2,3]  R482      -5.1840478181838989e-01
    z[1,2,3]  R483      -3.9839029312133789e-01
    z[1,2,3]  R484      -1.6759096086025238e-01
    z[1,2,3]  R485      2.2435568273067474e-01
    z[1,2,3]  R486      -5.7995975017547607e-01
    z[1,2,3]  R487      -5.5508546531200409e-02
    z[1,2,3]  R488      -0.162618488073349
    z[1,2,3]  R489      -1.8966302275657654e-01
    z[1,2,3]  R490      -1.6043733060359955e-01
    z[1,2,3]  R491      -3.4989330917596817e-02
    z[1,2,3]  R492      -4.5814856886863708e-01
    z[1,2,3]  R493      -4.3502718210220337e-01
    z[1,2,3]  R494      -4.5113736391067505e-01
    z[1,2,3]  R495      -1.7009107768535614e-01
    z[1,2,3]  R496      2.9478520154953003e-01
    z[1,2,3]  R497      1.8935614824295044e-01
    z[1,2,3]  R498      2.7815201878547668e-01
    z[1,2,3]  R499      1.7314006388187408e-01
    z[1,2,3]  R500      -7.3491680622100830e-01
    z[1,2,3]  R501      -5.5577796697616577e-01
    z[1,2,3]  R502      1.8954205513000488e-01
    z[1,2,3]  R503      4.7849395871162415e-01
    z[1,2,3]  R504      6.3952714204788208e-02
    z[1,2,3]  R505      -1.4681740105152130e-01
    z[1,2,3]  R506      0.00597138237208128
    z[1,2,3]  R507      2.1508035063743591e-01
    z[1,2,3]  R508      1.8963800370693207e-01
    z[1,2,3]  R509      6.0778830200433731e-02
    z[1,2,3]  R510      -0.0553843230009079
    z[1,2,3]  R511      0.38902547955513
    z[1,2,3]  R512      2.6066571474075317e-01
    z[1,2,3]  R513      3.7355315685272217e-01
    z[1,2,3]  R514      -8.0543659627437592e-02
    z[1,2,3]  R515      2.9656881093978882e-01
    z[1,2,3]  R516      2.5672686100006104e-01
    z[1,2,3]  R517      -2.0979759097099304e-01
    z[1,2,3]  R518      7.3786050081253052e-02
    z[1,2,3]  R519      2.5442928075790405e-01
    z[1,2,3]  R520      -0.555517852306366
    z[1,2,3]  R521      -3.0220049619674683e-01
    z[1,2,3]  R522      -4.7199490666389465e-01
    z[1,2,3]  R523      -1.3955840468406677e-01
    z[1,2,3]  R524      -7.2610370814800262e-02
    z[1,2,3]  R525      -3.0861049890518188e-01
    z[1,2,3]  R526      9.9657423794269562e-02
    z[1,2,3]  R527      1.7827060818672180e-01
    z[1,2,3]  R528      -0.0658518373966217
    z[1,2,3]  R529      -2.5762474536895752e-01
    z[1,2,4]  R15       -1
    z[1,2,4]  R24       1
    z[1,2,4]  R414      -1
    z[1,2,4]  R415      1
    z[1,2,4]  R420      -5.3325051069259644e-01
    z[1,2,4]  R421      3.5291498899459839e-01
    z[1,2,4]  R422      -7.4833756685256958e-01
    z[1,2,4]  R423      9.5168747007846832e-02
    z[1,2,4]  R424      -1.1875925958156586e-01
    z[1,2,4]  R425      9.6530608832836151e-02
    z[1,2,4]  R426      3.0272430181503296e-01
    z[1,2,4]  R427      1.7969278991222382e-01
    z[1,2,4]  R428      1.8295511603355408e-01
    z[1,2,4]  R429      1.3895675539970398e-01
    z[1,2,4]  R430      2.5637738406658173e-02
    z[1,2,4]  R431      3.8580101728439331e-01
    z[1,2,4]  R432      3.0356483533978462e-02
    z[1,2,4]  R433      -6.0467068105936050e-02
    z[1,2,4]  R434      2.6015114784240723e-01
    z[1,2,4]  R435      -1.6977331042289734e-01
    z[1,2,4]  R436      2.5859564542770386e-01
    z[1,2,4]  R437      8.3201992511749268e-01
    z[1,2,4]  R438      -8.2185596227645874e-01
    z[1,2,4]  R439      -6.2639784812927246e-01
    z[1,2,4]  R440      -2.4580799043178558e-01
    z[1,2,4]  R441      4.6386823058128357e-01
    z[1,2,4]  R442      -6.9450271129608154e-01
    z[1,2,4]  R443      4.4686034321784973e-01
    z[1,2,4]  R444      6.2149971723556519e-01
    z[1,2,4]  R445      -5.8028399944305420e-01
    z[1,2,4]  R446      2.3789599537849426e-02
    z[1,2,4]  R447      8.4485846757888794e-01
    z[1,2,4]  R448      2.5438550114631653e-01
    z[1,2,4]  R449      -4.7681885957717896e-01
    z[1,2,4]  R450      0.585985004901886
    z[1,2,4]  R451      4.5392480492591858e-01
    z[1,2,4]  R452      -4.9370858818292618e-02
    z[1,2,4]  R453      2.9065108299255371e-01
    z[1,2,4]  R454      0.0555245578289032
    z[1,2,4]  R455      -8.8652148842811584e-02
    z[1,2,4]  R456      1.3986818492412567e-01
    z[1,2,4]  R457      1.1174959689378738e-01
    z[1,2,4]  R458      -8.8005885481834412e-02
    z[1,2,4]  R459      0.0831865444779396
    z[1,2,4]  R460      -8.0534592270851135e-03
    z[1,2,4]  R461      2.4362045526504517e-01
    z[1,2,4]  R462      2.3618039488792419e-01
    z[1,2,4]  R463      -3.3481118083000183e-01
    z[1,2,4]  R464      1.1404404789209366e-01
    z[1,2,4]  R465      -1.1398802697658539e-01
    z[1,2,4]  R466      -8.5143849253654480e-02
    z[1,2,4]  R467      -1.4496196806430817e-01
    z[1,2,4]  R468      -2.6472138240933418e-02
    z[1,2,4]  R469      3.2402139902114868e-01
    z[1,2,4]  R470      1.8986824154853821e-01
    z[1,2,4]  R471      -3.4458765387535095e-01
    z[1,2,4]  R472      -1.5601888298988342e-01
    z[1,2,4]  R473      -3.3036106824874878e-01
    z[1,2,4]  R474      7.9754993319511414e-02
    z[1,2,4]  R475      2.2440824657678604e-02
    z[1,2,4]  R476      -5.4176026023924351e-03
    z[1,2,4]  R477      -8.7099701166152954e-02
    z[1,2,4]  R478      -3.8170254230499268e-01
    z[1,2,4]  R479      2.8691646456718445e-01
    z[1,2,4]  R480      0.372158020734787
    z[1,2,4]  R481      4.3288782238960266e-02
    z[1,2,4]  R482      -1.2515020370483398e-01
    z[1,2,4]  R483      9.4737574458122253e-02
    z[1,2,4]  R484      -1.8336981534957886e-01
    z[1,2,4]  R485      3.9586311578750610e-01
    z[1,2,4]  R486      -2.0542104542255402e-01
    z[1,2,4]  R487      -3.3603996038436890e-02
    z[1,2,4]  R488      2.5538778305053711e-01
    z[1,2,4]  R489      -3.2243865728378296e-01
    z[1,2,4]  R490      1.0967319458723068e-01
    z[1,2,4]  R491      2.0001262426376343e-01
    z[1,2,4]  R492      -2.1655750274658203e-01
    z[1,2,4]  R493      4.7490587830543518e-01
    z[1,2,4]  R494      -1.1311549693346024e-01
    z[1,2,4]  R495      0.269917756319046
    z[1,2,4]  R496      -6.3240818679332733e-02
    z[1,2,4]  R497      -4.9538484215736389e-01
    z[1,2,4]  R498      1.2240315973758698e-01
    z[1,2,4]  R499      1.0413980484008789e-01
    z[1,2,4]  R500      8.3759091794490814e-02
    z[1,2,4]  R501      -5.6565467268228531e-02
    z[1,2,4]  R502      -1.3234561309218407e-02
    z[1,2,4]  R503      -5.1011848449707031e-01
    z[1,2,4]  R504      -5.7242041826248169e-01
    z[1,2,4]  R505      0.0806722566485405
    z[1,2,4]  R506      2.3295298218727112e-01
    z[1,2,4]  R507      6.3670896925032139e-03
    z[1,2,4]  R508      1.4857368171215057e-01
    z[1,2,4]  R509      -7.8706592321395874e-01
    z[1,2,4]  R510      5.9010720252990723e-01
    z[1,2,4]  R511      -4.9014893174171448e-01
    z[1,2,4]  R512      3.4605216979980469e-01
    z[1,2,4]  R513      -0.784143328666687
    z[1,2,4]  R514      1.6048873960971832e-01
    z[1,2,4]  R515      -1.6336247324943542e-01
    z[1,2,4]  R516      -7.4287265539169312e-01
    z[1,2,4]  R517      2.8813734650611877e-01
    z[1,2,4]  R518      3.4640464186668396e-01
    z[1,2,4]  R519      2.3118773102760315e-01
    z[1,2,4]  R520      2.5349294766783714e-02
    z[1,2,4]  R521      5.0959908962249756e-01
    z[1,2,4]  R522      5.9191279113292694e-02
    z[1,2,4]  R523      -1.9709999859333038e-01
    z[1,2,4]  R524      2.4052542448043823e-01
    z[1,2,4]  R525      -9.3885980546474457e-02
    z[1,2,4]  R526      2.2049862891435623e-02
    z[1,2,4]  R527      1.2017721310257912e-02
    z[1,2,4]  R528      -1.8670603632926941e-01
    z[1,2,4]  R529      4.3236309289932251e-01
    z[1,2,5]  R16       -1
    z[1,2,5]  R25       1
    z[1,2,5]  R416      -1
    z[1,2,5]  R417      1
    z[1,2,5]  R420      6.5626579523086548e-01
    z[1,2,5]  R421      6.6537988185882568e-01
    z[1,2,5]  R422      3.3398557454347610e-02
    z[1,2,5]  R423      0.296827495098114
    z[1,2,5]  R424      -4.5416764914989471e-02
    z[1,2,5]  R425      -5.4162133485078812e-02
    z[1,2,5]  R426      -1.4519900083541870e-02
    z[1,2,5]  R427      3.0179911851882935e-01
    z[1,2,5]  R428      -9.4601154327392578e-02
    z[1,2,5]  R429      4.6772268414497375e-01
    z[1,2,5]  R430      -5.4586249589920044e-01
    z[1,2,5]  R431      -6.1169409751892090e-01
    z[1,2,5]  R432      -1.9058316946029663e-01
    z[1,2,5]  R433      4.1480389237403870e-01
    z[1,2,5]  R434      -1.7482955753803253e-01
    z[1,2,5]  R435      1.8879230320453644e-01
    z[1,2,5]  R436      6.7648209631443024e-02
    z[1,2,5]  R437      4.7131654620170593e-01
    z[1,2,5]  R438      -3.4881058335304260e-01
    z[1,2,5]  R439      -0.663200855255127
    z[1,2,5]  R440      -4.2663764953613281e-01
    z[1,2,5]  R441      2.8599733114242554e-01
    z[1,2,5]  R442      -1.9886104762554169e-01
    z[1,2,5]  R443      -7.7556155622005463e-02
    z[1,2,5]  R444      6.6100579500198364e-01
    z[1,2,5]  R445      1.8605035543441772e-01
    z[1,2,5]  R446      0.519503653049469
    z[1,2,5]  R447      3.5062929987907410e-01
    z[1,2,5]  R448      -2.4049113690853119e-01
    z[1,2,5]  R449      4.2587769031524658e-01
    z[1,2,5]  R450      4.0886640548706055e-01
    z[1,2,5]  R451      1.1239586770534515e-01
    z[1,2,5]  R452      -1.2824654579162598e-01
    z[1,2,5]  R453      4.8890876770019531e-01
    z[1,2,5]  R454      2.4667195975780487e-01
    z[1,2,5]  R455      3.0765545368194580e-01
    z[1,2,5]  R456      -1.6746150329709053e-02
    z[1,2,5]  R457      -0.0683315098285675
    z[1,2,5]  R458      1.2376486510038376e-01
    z[1,2,5]  R459      3.5071703791618347e-01
    z[1,2,5]  R460      -1.2956143915653229e-01
    z[1,2,5]  R461      -3.2415542006492615e-01
    z[1,2,5]  R462      -5.3670185804367065e-01
    z[1,2,5]  R463      1.8109139800071716e-01
    z[1,2,5]  R464      -9.8403267562389374e-02
    z[1,2,5]  R465      -2.3633357137441635e-02
    z[1,2,5]  R466      8.2218162715435028e-02
    z[1,2,5]  R467      6.8722128868103027e-02
    z[1,2,5]  R468      -1.4278912544250488e-01
    z[1,2,5]  R469      -9.1430328786373138e-02
    z[1,2,5]  R470      -6.5892316401004791e-02
    z[1,2,5]  R471      1.1503832787275314e-01
    z[1,2,5]  R472      -3.3437585830688477e-01
    z[1,2,5]  R473      1.0261550545692444e-01
    z[1,2,5]  R474      -3.5006096959114075e-01
    z[1,2,5]  R475      -1.1785305291414261e-01
    z[1,2,5]  R476      -1.3829918205738068e-01
    z[1,2,5]  R477      -3.6164256930351257e-01
    z[1,2,5]  R478      -2.0925061404705048e-01
    z[1,2,5]  R479      1.5344475209712982e-01
    z[1,2,5]  R480      -3.1367599964141846e-01
    z[1,2,5]  R481      -3.9566081017255783e-02
    z[1,2,5]  R482      -5.5153405666351318e-01
    z[1,2,5]  R483      -2.1115562319755554e-01
    z[1,2,5]  R484      -2.5290203094482422e-01
    z[1,2,5]  R485      -3.4231055527925491e-02
    z[1,2,5]  R486      -3.9365702867507935e-01
    z[1,2,5]  R487      7.4246935546398163e-02
    z[1,2,5]  R488      1.3931236229836941e-02
    z[1,2,5]  R489      1.0323248058557510e-01
    z[1,2,5]  R490      1.1458898894488811e-02
    z[1,2,5]  R491      6.0198950767517090e-01
    z[1,2,5]  R492      -5.7573366910219193e-02
    z[1,2,5]  R493      -2.5862815976142883e-01
    z[1,2,5]  R494      2.9186886548995972e-01
    z[1,2,5]  R495      0.00526859937235713
    z[1,2,5]  R496      2.1128852665424347e-01
    z[1,2,5]  R497      -2.2448942065238953e-01
    z[1,2,5]  R498      -2.1524254232645035e-02
    z[1,2,5]  R499      2.6794016361236572e-01
    z[1,2,5]  R500      -6.7306622862815857e-02
    z[1,2,5]  R501      -4.4824701547622681e-01
    z[1,2,5]  R502      2.5261655449867249e-01
    z[1,2,5]  R503      9.6087656915187836e-02
    z[1,2,5]  R504      1.1172868311405182e-02
    z[1,2,5]  R505      -1.1932700127363205e-01
    z[1,2,5]  R506      -9.9355757236480713e-02
    z[1,2,5]  R507      0.0643991008400917
    z[1,2,5]  R508      -1.3695776462554932e-01
    z[1,2,5]  R509      6.5878160297870636e-02
    z[1,2,5]  R510      2.0843271911144257e-01
    z[1,2,5]  R511      1.0014345496892929e-01
    z[1,2,5]  R512      2.5994306802749634e-01
    z[1,2,5]  R513      -7.1071274578571320e-02
    z[1,2,5]  R514      -1.0951571911573410e-01
    z[1,2,5]  R515      1.1942744255065918e-01
    z[1,2,5]  R516      2.3815682530403137e-01
    z[1,2,5]  R517      1.6805014014244080e-01
    z[1,2,5]  R518      3.5341310501098633e-01
    z[1,2,5]  R519      -5.7587809860706329e-03
    z[1,2,5]  R520      -4.3268963694572449e-01
    z[1,2,5]  R521      -2.1182611584663391e-01
    z[1,2,5]  R522      -1.6084384918212891e-01
    z[1,2,5]  R523      -5.2090730518102646e-02
    z[1,2,5]  R524      5.4125446826219559e-02
    z[1,2,5]  R525      -2.0764803886413574e-01
    z[1,2,5]  R526      1.2295242398977280e-01
    z[1,2,5]  R527      2.0872300863265991e-01
    z[1,2,5]  R528      1.1930776387453079e-01
    z[1,2,5]  R529      -3.1884968280792236e-02
    z[1,2,6]  R17       -1
    z[1,2,6]  R26       1
    z[1,2,6]  R418      -1
    z[1,2,6]  R419      1
    z[1,2,6]  R420      9.7905740141868591e-02
    z[1,2,6]  R421      4.9548465758562088e-02
    z[1,2,6]  R422      -2.7058309316635132e-01
    z[1,2,6]  R423      -4.1099029779434204e-01
    z[1,2,6]  R424      4.0998399257659912e-01
    z[1,2,6]  R425      7.8890067338943481e-01
    z[1,2,6]  R426      0.154539555311203
    z[1,2,6]  R427      2.4185986816883087e-01
    z[1,2,6]  R428      -3.9707425236701965e-01
    z[1,2,6]  R429      -2.9685431718826294e-01
    z[1,2,6]  R430      -3.1361716985702515e-01
    z[1,2,6]  R431      -3.6338892579078674e-01
    z[1,2,6]  R432      -1.8524931371212006e-01
    z[1,2,6]  R433      7.5806602835655212e-02
    z[1,2,6]  R434      -1.5545448660850525e-01
    z[1,2,6]  R435      -4.1842922568321228e-01
    z[1,2,6]  R436      -3.4202453494071960e-01
    z[1,2,6]  R437      1.0799054801464081e-01
    z[1,2,6]  R438      6.9016069173812866e-02
    z[1,2,6]  R439      1.8315553665161133e-01
    z[1,2,6]  R440      6.1327970027923584e-01
    z[1,2,6]  R441      -7.9011484980583191e-02
    z[1,2,6]  R442      0.0741225853562355
    z[1,2,6]  R443      -1.9100518897175789e-02
    z[1,2,6]  R444      2.1752619743347168e-01
    z[1,2,6]  R445      -2.7648079395294189e-01
    z[1,2,6]  R446      -7.9037941992282867e-02
    z[1,2,6]  R447      -1.6159781813621521e-01
    z[1,2,6]  R448      4.9513506889343262e-01
    z[1,2,6]  R449      -3.0760830640792847e-01
    z[1,2,6]  R450      -2.7494572568684816e-03
    z[1,2,6]  R451      1.4613977074623108e-01
    z[1,2,6]  R452      -2.2966891992837191e-03
    z[1,2,6]  R453      -3.0455753207206726e-01
    z[1,2,6]  R454      -9.2454567551612854e-02
    z[1,2,6]  R455      -1.3331221416592598e-02
    z[1,2,6]  R456      0.0850360244512558
    z[1,2,6]  R457      3.3200240135192871e-01
    z[1,2,6]  R458      1.2971581518650055e-01
    z[1,2,6]  R459      -1.3002598285675049e-01
    z[1,2,6]  R460      6.4658035989850760e-04
    z[1,2,6]  R461      1.4682596921920776e-01
    z[1,2,6]  R462      4.6131512522697449e-01
    z[1,2,6]  R463      -4.1206661611795425e-02
    z[1,2,6]  R464      -7.7206864953041077e-02
    z[1,2,6]  R465      9.6304953098297119e-02
    z[1,2,6]  R466      -2.2544731199741364e-01
    z[1,2,6]  R467      -1.8545429408550262e-01
    z[1,2,6]  R468      -4.2595180869102478e-01
    z[1,2,6]  R469      -2.8930693864822388e-01
    z[1,2,6]  R470      -4.4820669293403625e-01
    z[1,2,6]  R471      -2.8691756725311279e-01
    z[1,2,6]  R472      1.0799196362495422e-01
    z[1,2,6]  R473      9.8221465945243835e-02
    z[1,2,6]  R474      1.4508076012134552e-01
    z[1,2,6]  R475      2.2577278316020966e-01
    z[1,2,6]  R476      -1.3321690261363983e-02
    z[1,2,6]  R477      7.3098443448543549e-02
    z[1,2,6]  R478      -1.0302697867155075e-01
    z[1,2,6]  R479      7.0774590969085693e-01
    z[1,2,6]  R480      4.1437754034996033e-01
    z[1,2,6]  R481      -0.511720597743988
    z[1,2,6]  R482      9.7146227955818176e-02
    z[1,2,6]  R483      4.7523382306098938e-01
    z[1,2,6]  R484      3.0004331469535828e-01
    z[1,2,6]  R485      3.2768625020980835e-01
    z[1,2,6]  R486      -9.6416510641574860e-02
    z[1,2,6]  R487      3.9024993777275085e-01
    z[1,2,6]  R488      0.500403881072998
    z[1,2,6]  R489      -0.0842781662940979
    z[1,2,6]  R490      0.275449275970459
    z[1,2,6]  R491      -7.7913120388984680e-02
    z[1,2,6]  R492      -4.7000306844711304e-01
    z[1,2,6]  R493      -3.4643980860710144e-01
    z[1,2,6]  R494      -7.0663958787918091e-01
    z[1,2,6]  R495      6.0131076723337173e-02
    z[1,2,6]  R496      -2.6651713252067566e-01
    z[1,2,6]  R497      4.3111163377761841e-01
    z[1,2,6]  R498      -1.1779459565877914e-01
    z[1,2,6]  R499      -6.9593206048011780e-02
    z[1,2,6]  R500      -3.2721498608589172e-01
    z[1,2,6]  R501      -2.4010214954614639e-02
    z[1,2,6]  R502      -4.3036383390426636e-01
    z[1,2,6]  R503      -0.0923534482717514
    z[1,2,6]  R504      -0.328215092420578
    z[1,2,6]  R505      -1.4108602702617645e-01
    z[1,2,6]  R506      6.2837995588779449e-02
    z[1,2,6]  R507      -2.5084343552589417e-01
    z[1,2,6]  R508      3.1831854581832886e-01
    z[1,2,6]  R509      3.2484382390975952e-02
    z[1,2,6]  R510      -0.148881196975708
    z[1,2,6]  R511      3.3649137616157532e-01
    z[1,2,6]  R512      5.4013800621032715e-01
    z[1,2,6]  R513      -1.8159356713294983e-01
    z[1,2,6]  R514      1.0902926325798035e-02
    z[1,2,6]  R515      -4.0447127074003220e-02
    z[1,2,6]  R516      -1.8995296210050583e-02
    z[1,2,6]  R517      -1.1160200834274292e-01
    z[1,2,6]  R518      6.0983393341302872e-02
    z[1,2,6]  R519      3.1904298067092896e-01
    z[1,2,6]  R520      2.1662132814526558e-02
    z[1,2,6]  R521      -1.8995198607444763e-01
    z[1,2,6]  R522      2.9376775026321411e-01
    z[1,2,6]  R523      1.3069215416908264e-01
    z[1,2,6]  R524      -8.4015779197216034e-02
    z[1,2,6]  R525      -1.5442037582397461e-01
    z[1,2,6]  R526      -1.0543386638164520e-01
    z[1,2,6]  R527      -0.0949973315000534
    z[1,2,6]  R528      4.1611364483833313e-01
    z[1,2,6]  R529      -1.2132444977760315e-01
    z[2,1,0]  R11       1
    z[2,1,0]  R20       -1
    z[2,1,0]  R530      -1
    z[2,1,0]  R531      1
    z[2,1,0]  R544      -3.9224180579185486e-01
    z[2,1,0]  R545      -3.5216581821441650e-01
    z[2,1,0]  R546      0.797160267829895
    z[2,1,0]  R547      -4.2389002442359924e-01
    z[2,1,0]  R548      6.8974149227142334e-01
    z[2,1,0]  R549      7.9577147960662842e-01
    z[2,1,0]  R550      -6.8320196866989136e-01
    z[2,1,0]  R551      7.5881582498550415e-01
    z[2,1,0]  R552      6.3608884811401367e-01
    z[2,1,0]  R553      7.3341244459152222e-01
    z[2,1,0]  R554      -8.1882697343826294e-01
    z[2,1,0]  R555      3.5091996192932129e-01
    z[2,1,0]  R556      8.4362350404262543e-02
    z[2,1,0]  R557      -7.2980821132659912e-01
    z[2,1,0]  R558      1.9111198186874390e-01
    z[2,1,0]  R559      -1.4493685960769653e-01
    z[2,1,0]  R560      -1.6609892249107361e-01
    z[2,1,0]  R561      -5.5685228109359741e-01
    z[2,1,0]  R562      0.319084495306015
    z[2,1,0]  R563      -6.5375095605850220e-01
    z[2,1,0]  R564      -7.2028857469558716e-01
    z[2,1,0]  R565      -7.1874296665191650e-01
    z[2,1,0]  R566      -0.296962708234787
    z[2,1,0]  R567      -7.2221815586090088e-01
    z[2,1,0]  R568      -0.374138206243515
    z[2,1,0]  R569      -7.7556854486465454e-01
    z[2,1,0]  R570      -7.4139153957366943e-01
    z[2,1,0]  R571      -3.9027959108352661e-02
    z[2,1,0]  R572      3.6240735650062561e-01
    z[2,1,0]  R573      -6.0498553514480591e-01
    z[2,1,0]  R574      -1.0302574932575226e-01
    z[2,1,0]  R575      -5.9329774230718613e-02
    z[2,1,0]  R576      -3.0037942528724670e-01
    z[2,1,0]  R577      -0.743958592414856
    z[2,1,0]  R578      -7.8501778841018677e-01
    z[2,1,0]  R579      -7.5105243921279907e-01
    z[2,1,0]  R580      -5.6015497446060181e-01
    z[2,1,0]  R581      -8.9161342382431030e-01
    z[2,1,0]  R582      -5.9007924795150757e-01
    z[2,1,0]  R583      -8.1120771169662476e-01
    z[2,1,0]  R584      -7.1645969152450562e-01
    z[2,1,0]  R585      -6.8813055753707886e-01
    z[2,1,0]  R586      -4.4439971446990967e-01
    z[2,1,0]  R587      -3.7683433294296265e-01
    z[2,1,0]  R588      -3.2920166850090027e-01
    z[2,1,0]  R589      -7.2472792863845825e-01
    z[2,1,0]  R590      4.9414688348770142e-01
    z[2,1,0]  R591      4.4974252581596375e-01
    z[2,1,0]  R592      9.6794553101062775e-02
    z[2,1,0]  R593      -4.8676044680178165e-03
    z[2,1,0]  R594      -2.4586421251296997e-01
    z[2,1,0]  R595      1.1634296923875809e-01
    z[2,1,0]  R596      0.600662350654602
    z[2,1,0]  R597      2.7329126000404358e-01
    z[2,1,0]  R598      6.2698286771774292e-01
    z[2,1,0]  R599      2.1078411489725113e-02
    z[2,1,0]  R600      2.4044297635555267e-01
    z[2,1,0]  R601      -3.8858661055564880e-01
    z[2,1,0]  R602      -4.6192719601094723e-03
    z[2,1,0]  R603      5.2527695894241333e-01
    z[2,1,0]  R604      -6.3333630561828613e-01
    z[2,1,0]  R605      4.8260340094566345e-01
    z[2,1,0]  R606      -6.0316592454910278e-01
    z[2,1,0]  R607      3.4032773971557617e-01
    z[2,1,0]  R608      2.0777510106563568e-01
    z[2,1,0]  R609      -3.5108034498989582e-03
    z[2,1,0]  R610      4.8921483755111694e-01
    z[2,1,0]  R611      -9.1450080275535583e-02
    z[2,1,0]  R612      2.1135492622852325e-01
    z[2,1,0]  R613      2.4746231734752655e-01
    z[2,1,0]  R614      -1.0800433158874512e-01
    z[2,1,0]  R615      -4.7529187798500061e-01
    z[2,1,0]  R616      -0.620422899723053
    z[2,1,0]  R617      -8.1994032859802246e-01
    z[2,1,0]  R618      2.0614795386791229e-01
    z[2,1,0]  R619      -7.1798115968704224e-02
    z[2,1,0]  R620      2.6360219717025757e-01
    z[2,1,0]  R621      1.6038280725479126e-01
    z[2,1,0]  R622      6.0919380187988281e-01
    z[2,1,0]  R623      7.2385388612747192e-01
    z[2,1,0]  R624      2.4657995998859406e-01
    z[2,1,0]  R625      0.255929559469223
    z[2,1,0]  R626      -1.8523028492927551e-01
    z[2,1,0]  R627      -1.9604268670082092e-01
    z[2,1,0]  R628      -2.2875583171844482e-01
    z[2,1,0]  R629      -1.6787399351596832e-01
    z[2,1,0]  R630      9.0189540386199951e-01
    z[2,1,0]  R631      8.8136249780654907e-01
    z[2,1,0]  R632      8.4615147113800049e-01
    z[2,1,0]  R633      -3.2924351096153259e-01
    z[2,1,0]  R634      3.9918351918458939e-02
    z[2,1,0]  R635      -5.6306332349777222e-02
    z[2,1,0]  R636      -5.9193450212478638e-01
    z[2,1,0]  R637      -8.7908446788787842e-01
    z[2,1,0]  R638      -8.4026736021041870e-01
    z[2,1,0]  R639      -7.2747319936752319e-01
    z[2,1,0]  R640      -6.2574809789657593e-01
    z[2,1,0]  R641      -1.8546107411384583e-01
    z[2,1,0]  R642      3.2135257124900818e-01
    z[2,1,0]  R643      2.1261560916900635e-01
    z[2,1,0]  R644      3.8622301816940308e-01
    z[2,1,0]  R645      -6.2194317579269409e-01
    z[2,1,0]  R646      5.9298551082611084e-01
    z[2,1,0]  R647      -8.3533978462219238e-01
    z[2,1,0]  R648      -2.7348718047142029e-01
    z[2,1,0]  R649      6.3934868574142456e-01
    z[2,1,0]  R650      -2.1891364455223083e-01
    z[2,1,0]  R651      -3.1954467296600342e-01
    z[2,1,0]  R652      3.1205892562866211e-01
    z[2,1,0]  R653      3.0639445781707764e-01
    z[2,1,1]  R12       1
    z[2,1,1]  R21       -1
    z[2,1,1]  R532      -1
    z[2,1,1]  R533      1
    z[2,1,1]  R544      1.6793204471468925e-02
    z[2,1,1]  R545      4.1982802748680115e-01
    z[2,1,1]  R546      -3.0217638611793518e-01
    z[2,1,1]  R547      3.3735528588294983e-01
    z[2,1,1]  R548      -2.1396717429161072e-01
    z[2,1,1]  R549      -1.4922298491001129e-01
    z[2,1,1]  R550      -4.6211519837379456e-01
    z[2,1,1]  R551      -2.4508625268936157e-01
    z[2,1,1]  R552      -1.8263725936412811e-01
    z[2,1,1]  R553      -2.3488880693912506e-01
    z[2,1,1]  R554      -1.6358684003353119e-01
    z[2,1,1]  R555      5.3442692756652832e-01
    z[2,1,1]  R556      5.0623804330825806e-01
    z[2,1,1]  R557      4.6645689010620117e-01
    z[2,1,1]  R558      6.5295898914337158e-01
    z[2,1,1]  R559      -9.4652932882308960e-01
    z[2,1,1]  R560      -0.909305214881897
    z[2,1,1]  R561      6.1326795816421509e-01
    z[2,1,1]  R562      5.5151903629302979e-01
    z[2,1,1]  R563      4.0061524510383606e-01
    z[2,1,1]  R564      -0.264529287815094
    z[2,1,1]  R565      -1.4760753512382507e-01
    z[2,1,1]  R566      7.9781192541122437e-01
    z[2,1,1]  R567      -1.7197097837924957e-01
    z[2,1,1]  R568      1.4941245317459106e-01
    z[2,1,1]  R569      4.4548544287681580e-01
    z[2,1,1]  R570      0.653929591178894
    z[2,1,1]  R571      4.0577349066734314e-01
    z[2,1,1]  R572      -3.6976438760757446e-01
    z[2,1,1]  R573      -6.7304052412509918e-02
    z[2,1,1]  R574      4.9294161796569824e-01
    z[2,1,1]  R575      3.5584241151809692e-01
    z[2,1,1]  R576      3.9754968881607056e-01
    z[2,1,1]  R577      1.6869686543941498e-02
    z[2,1,1]  R578      7.1616090834140778e-02
    z[2,1,1]  R579      2.5303310155868530e-01
    z[2,1,1]  R580      -1.7502473667263985e-02
    z[2,1,1]  R581      6.7946580238640308e-03
    z[2,1,1]  R582      -4.3117246031761169e-01
    z[2,1,1]  R583      3.8872316479682922e-01
    z[2,1,1]  R584      -1.3841395080089569e-01
    z[2,1,1]  R585      -4.6720635145902634e-02
    z[2,1,1]  R586      5.3251668810844421e-02
    z[2,1,1]  R587      3.9715209603309631e-01
    z[2,1,1]  R588      -2.7576866745948792e-01
    z[2,1,1]  R589      4.9373021721839905e-01
    z[2,1,1]  R590      -5.0862950086593628e-01
    z[2,1,1]  R591      -4.7206935286521912e-01
    z[2,1,1]  R592      -9.2534351348876953e-01
    z[2,1,1]  R593      -9.3733829259872437e-01
    z[2,1,1]  R594      5.0692892074584961e-01
    z[2,1,1]  R595      5.6872403621673584e-01
    z[2,1,1]  R596      -5.3618443012237549e-01
    z[2,1,1]  R597      -6.4487606287002563e-01
    z[2,1,1]  R598      -3.6818471550941467e-01
    z[2,1,1]  R599      -7.2963792085647583e-01
    z[2,1,1]  R600      -8.2487720251083374e-01
    z[2,1,1]  R601      7.6968425512313843e-01
    z[2,1,1]  R602      -7.7254432439804077e-01
    z[2,1,1]  R603      -2.3884780704975128e-01
    z[2,1,1]  R604      3.0962151288986206e-01
    z[2,1,1]  R605      -5.0188940763473511e-01
    z[2,1,1]  R606      -9.2821039259433746e-02
    z[2,1,1]  R607      -2.9327511787414551e-01
    z[2,1,1]  R608      -0.954384446144104
    z[2,1,1]  R609      -8.4556078910827637e-01
    z[2,1,1]  R610      -1.5219414234161377e-01
    z[2,1,1]  R611      -8.5327720642089844e-01
    z[2,1,1]  R612      -8.0013388395309448e-01
    z[2,1,1]  R613      -0.837171733379364
    z[2,1,1]  R614      5.9243518114089966e-01
    z[2,1,1]  R615      5.3607380390167236e-01
    z[2,1,1]  R616      5.0177198648452759e-01
    z[2,1,1]  R617      -4.3665003776550293e-01
    z[2,1,1]  R618      -9.2628234624862671e-01
    z[2,1,1]  R619      -8.7773799896240234e-01
    z[2,1,1]  R620      9.4409698247909546e-01
    z[2,1,1]  R621      9.3283069133758545e-01
    z[2,1,1]  R622      4.4027809053659439e-02
    z[2,1,1]  R623      -4.1449481248855591e-01
    z[2,1,1]  R624      2.5135436654090881e-01
    z[2,1,1]  R625      0.420491099357605
    z[2,1,1]  R626      2.5548499822616577e-01
    z[2,1,1]  R627      1.5653695166110992e-01
    z[2,1,1]  R628      1.7599220573902130e-01
    z[2,1,1]  R629      2.3999880254268646e-01
    z[2,1,1]  R630      1.9431927800178528e-01
    z[2,1,1]  R631      -1.5722972154617310e-01
    z[2,1,1]  R632      -1.4477474987506866e-01
    z[2,1,1]  R633      3.7604832649230957e-01
    z[2,1,1]  R634      0.689096212387085
    z[2,1,1]  R635      5.3424453735351562e-01
    z[2,1,1]  R636      4.8140963912010193e-01
    z[2,1,1]  R637      -7.9528607428073883e-02
    z[2,1,1]  R638      -2.2351981699466705e-01
    z[2,1,1]  R639      -1.5993355214595795e-01
    z[2,1,1]  R640      -3.0037540197372437e-01
    z[2,1,1]  R641      -3.6878433078527451e-02
    z[2,1,1]  R642      1.3351911678910255e-02
    z[2,1,1]  R643      1.3604276813566685e-02
    z[2,1,1]  R644      2.8984868526458740e-01
    z[2,1,1]  R645      2.1480667591094971e-01
    z[2,1,1]  R646      -0.0954454317688942
    z[2,1,1]  R647      8.9969672262668610e-02
    z[2,1,1]  R648      -1.0357370972633362e-01
    z[2,1,1]  R649      3.8562972098588943e-02
    z[2,1,1]  R650      7.2650928050279617e-03
    z[2,1,1]  R651      -1.8665449321269989e-01
    z[2,1,1]  R652      -3.9170585572719574e-02
    z[2,1,1]  R653      -5.0568240880966187e-01
    z[2,1,2]  R13       1
    z[2,1,2]  R22       -1
    z[2,1,2]  R534      -1
    z[2,1,2]  R535      1
    z[2,1,2]  R544      5.3428955376148224e-02
    z[2,1,2]  R545      4.7465705871582031e-01
    z[2,1,2]  R546      3.6648120731115341e-02
    z[2,1,2]  R547      0.377734899520874
    z[2,1,2]  R548      6.5484158694744110e-02
    z[2,1,2]  R549      -1.2441141903400421e-01
    z[2,1,2]  R550      2.5291427969932556e-01
    z[2,1,2]  R551      -2.6075729727745056e-01
    z[2,1,2]  R552      -2.3586069047451019e-01
    z[2,1,2]  R553      2.9757454991340637e-01
    z[2,1,2]  R554      1.2146435678005219e-01
    z[2,1,2]  R555      -4.2763182520866394e-01
    z[2,1,2]  R556      0.0552813895046711
    z[2,1,2]  R557      -3.2051667571067810e-01
    z[2,1,2]  R558      -5.6332081556320190e-01
    z[2,1,2]  R559      4.8455204814672470e-02
    z[2,1,2]  R560      2.8371301293373108e-01
    z[2,1,2]  R561      -2.1615797281265259e-01
    z[2,1,2]  R562      -3.4118276834487915e-01
    z[2,1,2]  R563      -4.3730372190475464e-01
    z[2,1,2]  R564      4.1211673617362976e-01
    z[2,1,2]  R565      4.9223366379737854e-01
    z[2,1,2]  R566      -1.7958946526050568e-02
    z[2,1,2]  R567      4.7048786282539368e-01
    z[2,1,2]  R568      -3.8058489561080933e-01
    z[2,1,2]  R569      -3.2974272966384888e-01
    z[2,1,2]  R570      5.8110468089580536e-02
    z[2,1,2]  R571      -1.9358810782432556e-01
    z[2,1,2]  R572      -6.7814439535140991e-01
    z[2,1,2]  R573      -0.0276302732527256
    z[2,1,2]  R574      -1.1719395220279694e-01
    z[2,1,2]  R575      -9.6887126564979553e-02
    z[2,1,2]  R576      3.9203721284866333e-01
    z[2,1,2]  R577      -9.0094834566116333e-02
    z[2,1,2]  R578      4.0363538265228271e-01
    z[2,1,2]  R579      2.3727929592132568e-01
    z[2,1,2]  R580      3.7829467654228210e-01
    z[2,1,2]  R581      2.0727132260799408e-01
    z[2,1,2]  R582      -3.5161191225051880e-01
    z[2,1,2]  R583      -1.8203815817832947e-01
    z[2,1,2]  R584      5.9477311372756958e-01
    z[2,1,2]  R585      3.3852979540824890e-01
    z[2,1,2]  R586      0.564498245716095
    z[2,1,2]  R587      -3.1396320462226868e-01
    z[2,1,2]  R588      1.2137076258659363e-01
    z[2,1,2]  R589      -3.5435834527015686e-01
    z[2,1,2]  R590      -0.539020299911499
    z[2,1,2]  R591      -2.3951514065265656e-01
    z[2,1,2]  R592      1.6637371480464935e-01
    z[2,1,2]  R593      -6.2574379146099091e-02
    z[2,1,2]  R594      1.5445311367511749e-01
    z[2,1,2]  R595      -3.8655731081962585e-01
    z[2,1,2]  R596      -2.5803402066230774e-01
    z[2,1,2]  R597      -5.0074491649866104e-02
    z[2,1,2]  R598      -1.7812184989452362e-01
    z[2,1,2]  R599      6.3637781143188477e-01
    z[2,1,2]  R600      4.4004756212234497e-01
    z[2,1,2]  R601      -3.7844008207321167e-01
    z[2,1,2]  R602      4.7437658905982971e-01
    z[2,1,2]  R603      -1.9614732265472412e-01
    z[2,1,2]  R604      2.9345509409904480e-01
    z[2,1,2]  R605      1.8945498391985893e-02
    z[2,1,2]  R606      -2.8382557630538940e-01
    z[2,1,2]  R607      -7.5607880949974060e-02
    z[2,1,2]  R608      4.0291804820299149e-02
    z[2,1,2]  R609      -3.9303341507911682e-01
    z[2,1,2]  R610      2.5031521916389465e-01
    z[2,1,2]  R611      3.0954939126968384e-01
    z[2,1,2]  R612      2.4709241092205048e-01
    z[2,1,2]  R613      -1.3379940390586853e-01
    z[2,1,2]  R614      0.374731183052063
    z[2,1,2]  R615      -2.3399564623832703e-01
    z[2,1,2]  R616      -1.5763019025325775e-01
    z[2,1,2]  R617      -2.4272593855857849e-01
    z[2,1,2]  R618      1.6245366632938385e-01
    z[2,1,2]  R619      -2.3109002411365509e-01
    z[2,1,2]  R620      5.0432592630386353e-02
    z[2,1,2]  R621      1.3996334373950958e-01
    z[2,1,2]  R622      0.632743239402771
    z[2,1,2]  R623      -1.8757671117782593e-01
    z[2,1,2]  R624      3.3723658323287964e-01
    z[2,1,2]  R625      2.1254646778106689e-01
    z[2,1,2]  R626      3.6979696154594421e-01
    z[2,1,2]  R627      8.1125551462173462e-01
    z[2,1,2]  R628      8.3727121353149414e-01
    z[2,1,2]  R629      -3.9338001608848572e-01
    z[2,1,2]  R630      -6.8045049905776978e-02
    z[2,1,2]  R631      5.2481066435575485e-02
    z[2,1,2]  R632      2.3879086971282959e-01
    z[2,1,2]  R633      -2.5375235080718994e-01
    z[2,1,2]  R634      -2.2355543076992035e-01
    z[2,1,2]  R635      -1.0044532269239426e-01
    z[2,1,2]  R636      -5.8036994934082031e-01
    z[2,1,2]  R637      -1.7762959003448486e-01
    z[2,1,2]  R638      -3.6471266299486160e-02
    z[2,1,2]  R639      -3.6093726754188538e-01
    z[2,1,2]  R640      -3.0557924509048462e-01
    z[2,1,2]  R641      -1.9537086784839630e-01
    z[2,1,2]  R642      -1.2592333555221558e-01
    z[2,1,2]  R643      2.4499481916427612e-01
    z[2,1,2]  R644      -1.9908134639263153e-01
    z[2,1,2]  R645      -5.0699585676193237e-01
    z[2,1,2]  R646      3.3400547504425049e-01
    z[2,1,2]  R647      1.7254938185214996e-01
    z[2,1,2]  R648      -2.0253041386604309e-01
    z[2,1,2]  R649      -3.6949047446250916e-01
    z[2,1,2]  R650      -7.6224929094314575e-01
    z[2,1,2]  R651      5.7550603523850441e-03
    z[2,1,2]  R652      6.9921833276748657e-01
    z[2,1,2]  R653      3.4651690721511841e-01
    z[2,1,3]  R14       1
    z[2,1,3]  R23       -1
    z[2,1,3]  R536      -1
    z[2,1,3]  R537      1
    z[2,1,3]  R544      -5.7658666372299194e-01
    z[2,1,3]  R545      -4.8413532972335815e-01
    z[2,1,3]  R546      5.0298297405242920e-01
    z[2,1,3]  R547      -3.8413512706756592e-01
    z[2,1,3]  R548      6.3380491733551025e-01
    z[2,1,3]  R549      4.7572395205497742e-01
    z[2,1,3]  R550      -4.7816762328147888e-01
    z[2,1,3]  R551      4.1079682111740112e-01
    z[2,1,3]  R552      6.8301928043365479e-01
    z[2,1,3]  R553      4.1419026255607605e-01
    z[2,1,3]  R554      5.2072703838348389e-01
    z[2,1,3]  R555      -4.7158092260360718e-01
    z[2,1,3]  R556      -4.2060464620590210e-01
    z[2,1,3]  R557      -2.1827220916748047e-02
    z[2,1,3]  R558      -4.3719586730003357e-01
    z[2,1,3]  R559      2.4062652885913849e-01
    z[2,1,3]  R560      1.5694554895162582e-02
    z[2,1,3]  R561      4.5493260025978088e-01
    z[2,1,3]  R562      -5.2448230981826782e-01
    z[2,1,3]  R563      1.5438485145568848e-01
    z[2,1,3]  R564      -9.3475859612226486e-03
    z[2,1,3]  R565      -7.0925705134868622e-02
    z[2,1,3]  R566      -3.5661661624908447e-01
    z[2,1,3]  R567      3.1329268217086792e-01
    z[2,1,3]  R568      -7.3681735992431641e-01
    z[2,1,3]  R569      1.6105762124061584e-01
    z[2,1,3]  R570      2.0723575726151466e-03
    z[2,1,3]  R571      -8.0785721540451050e-01
    z[2,1,3]  R572      2.6825010776519775e-01
    z[2,1,3]  R573      1.4808334410190582e-01
    z[2,1,3]  R574      -5.6925994157791138e-01
    z[2,1,3]  R575      -7.7147370576858521e-01
    z[2,1,3]  R576      -5.1840478181838989e-01
    z[2,1,3]  R577      -3.9839029312133789e-01
    z[2,1,3]  R578      -1.6759096086025238e-01
    z[2,1,3]  R579      2.2435568273067474e-01
    z[2,1,3]  R580      -5.7995975017547607e-01
    z[2,1,3]  R581      -5.5508546531200409e-02
    z[2,1,3]  R582      -0.162618488073349
    z[2,1,3]  R583      -1.8966302275657654e-01
    z[2,1,3]  R584      -1.6043733060359955e-01
    z[2,1,3]  R585      -3.4989330917596817e-02
    z[2,1,3]  R586      -4.5814856886863708e-01
    z[2,1,3]  R587      -4.3502718210220337e-01
    z[2,1,3]  R588      -4.5113736391067505e-01
    z[2,1,3]  R589      -1.7009107768535614e-01
    z[2,1,3]  R590      2.9478520154953003e-01
    z[2,1,3]  R591      1.8935614824295044e-01
    z[2,1,3]  R592      2.7815201878547668e-01
    z[2,1,3]  R593      1.7314006388187408e-01
    z[2,1,3]  R594      -7.3491680622100830e-01
    z[2,1,3]  R595      -5.5577796697616577e-01
    z[2,1,3]  R596      1.8954205513000488e-01
    z[2,1,3]  R597      4.7849395871162415e-01
    z[2,1,3]  R598      6.3952714204788208e-02
    z[2,1,3]  R599      -1.4681740105152130e-01
    z[2,1,3]  R600      0.00597138237208128
    z[2,1,3]  R601      2.1508035063743591e-01
    z[2,1,3]  R602      1.8963800370693207e-01
    z[2,1,3]  R603      6.0778830200433731e-02
    z[2,1,3]  R604      -0.0553843230009079
    z[2,1,3]  R605      0.38902547955513
    z[2,1,3]  R606      2.6066571474075317e-01
    z[2,1,3]  R607      3.7355315685272217e-01
    z[2,1,3]  R608      -8.0543659627437592e-02
    z[2,1,3]  R609      2.9656881093978882e-01
    z[2,1,3]  R610      2.5672686100006104e-01
    z[2,1,3]  R611      -2.0979759097099304e-01
    z[2,1,3]  R612      7.3786050081253052e-02
    z[2,1,3]  R613      2.5442928075790405e-01
    z[2,1,3]  R614      -0.555517852306366
    z[2,1,3]  R615      -3.0220049619674683e-01
    z[2,1,3]  R616      -4.7199490666389465e-01
    z[2,1,3]  R617      -1.3955840468406677e-01
    z[2,1,3]  R618      -7.2610370814800262e-02
    z[2,1,3]  R619      -3.0861049890518188e-01
    z[2,1,3]  R620      9.9657423794269562e-02
    z[2,1,3]  R621      1.7827060818672180e-01
    z[2,1,3]  R622      -0.0658518373966217
    z[2,1,3]  R623      -2.5762474536895752e-01
    z[2,1,3]  R624      1.9407291710376740e-01
    z[2,1,3]  R625      3.7785834074020386e-01
    z[2,1,3]  R626      0.359621524810791
    z[2,1,3]  R627      1.1336320638656616e-01
    z[2,1,3]  R628      -1.7726014554500580e-01
    z[2,1,3]  R629      3.5334849357604980e-01
    z[2,1,3]  R630      -1.6869869828224182e-01
    z[2,1,3]  R631      1.1771301925182343e-01
    z[2,1,3]  R632      -7.7181234955787659e-02
    z[2,1,3]  R633      -5.9966671466827393e-01
    z[2,1,3]  R634      -2.7676156163215637e-01
    z[2,1,3]  R635      2.1508021652698517e-01
    z[2,1,3]  R636      9.7305081784725189e-02
    z[2,1,3]  R637      0.0887034460902214
    z[2,1,3]  R638      3.4676992893218994e-01
    z[2,1,3]  R639      2.7455356717109680e-01
    z[2,1,3]  R640      4.8621648550033569e-01
    z[2,1,3]  R641      -4.0148496627807617e-03
    z[2,1,3]  R642      2.8074583411216736e-01
    z[2,1,3]  R643      1.6979804635047913e-01
    z[2,1,3]  R644      3.2959511876106262e-01
    z[2,1,3]  R645      -8.2395315170288086e-02
    z[2,1,3]  R646      1.8020935356616974e-02
    z[2,1,3]  R647      -2.4140359461307526e-01
    z[2,1,3]  R648      5.4319225251674652e-02
    z[2,1,3]  R649      7.3736339807510376e-02
    z[2,1,3]  R650      3.0708810687065125e-01
    z[2,1,3]  R651      1.3325117528438568e-02
    z[2,1,3]  R652      -2.1088348329067230e-01
    z[2,1,3]  R653      1.6426447033882141e-01
    z[2,1,4]  R15       1
    z[2,1,4]  R24       -1
    z[2,1,4]  R538      -1
    z[2,1,4]  R539      1
    z[2,1,4]  R544      0.585985004901886
    z[2,1,4]  R545      4.5392480492591858e-01
    z[2,1,4]  R546      -4.9370858818292618e-02
    z[2,1,4]  R547      2.9065108299255371e-01
    z[2,1,4]  R548      0.0555245578289032
    z[2,1,4]  R549      -8.8652148842811584e-02
    z[2,1,4]  R550      1.3986818492412567e-01
    z[2,1,4]  R551      1.1174959689378738e-01
    z[2,1,4]  R552      -8.8005885481834412e-02
    z[2,1,4]  R553      0.0831865444779396
    z[2,1,4]  R554      -8.0534592270851135e-03
    z[2,1,4]  R555      2.4362045526504517e-01
    z[2,1,4]  R556      2.3618039488792419e-01
    z[2,1,4]  R557      -3.3481118083000183e-01
    z[2,1,4]  R558      1.1404404789209366e-01
    z[2,1,4]  R559      -1.1398802697658539e-01
    z[2,1,4]  R560      -8.5143849253654480e-02
    z[2,1,4]  R561      -1.4496196806430817e-01
    z[2,1,4]  R562      -2.6472138240933418e-02
    z[2,1,4]  R563      3.2402139902114868e-01
    z[2,1,4]  R564      1.8986824154853821e-01
    z[2,1,4]  R565      -3.4458765387535095e-01
    z[2,1,4]  R566      -1.5601888298988342e-01
    z[2,1,4]  R567      -3.3036106824874878e-01
    z[2,1,4]  R568      7.9754993319511414e-02
    z[2,1,4]  R569      2.2440824657678604e-02
    z[2,1,4]  R570      -5.4176026023924351e-03
    z[2,1,4]  R571      -8.7099701166152954e-02
    z[2,1,4]  R572      -3.8170254230499268e-01
    z[2,1,4]  R573      2.8691646456718445e-01
    z[2,1,4]  R574      0.372158020734787
    z[2,1,4]  R575      4.3288782238960266e-02
    z[2,1,4]  R576      -1.2515020370483398e-01
    z[2,1,4]  R577      9.4737574458122253e-02
    z[2,1,4]  R578      -1.8336981534957886e-01
    z[2,1,4]  R579      3.9586311578750610e-01
    z[2,1,4]  R580      -2.0542104542255402e-01
    z[2,1,4]  R581      -3.3603996038436890e-02
    z[2,1,4]  R582      2.5538778305053711e-01
    z[2,1,4]  R583      -3.2243865728378296e-01
    z[2,1,4]  R584      1.0967319458723068e-01
    z[2,1,4]  R585      2.0001262426376343e-01
    z[2,1,4]  R586      -2.1655750274658203e-01
    z[2,1,4]  R587      4.7490587830543518e-01
    z[2,1,4]  R588      -1.1311549693346024e-01
    z[2,1,4]  R589      0.269917756319046
    z[2,1,4]  R590      -6.3240818679332733e-02
    z[2,1,4]  R591      -4.9538484215736389e-01
    z[2,1,4]  R592      1.2240315973758698e-01
    z[2,1,4]  R593      1.0413980484008789e-01
    z[2,1,4]  R594      8.3759091794490814e-02
    z[2,1,4]  R595      -5.6565467268228531e-02
    z[2,1,4]  R596      -1.3234561309218407e-02
    z[2,1,4]  R597      -5.1011848449707031e-01
    z[2,1,4]  R598      -5.7242041826248169e-01
    z[2,1,4]  R599      0.0806722566485405
    z[2,1,4]  R600      2.3295298218727112e-01
    z[2,1,4]  R601      6.3670896925032139e-03
    z[2,1,4]  R602      1.4857368171215057e-01
    z[2,1,4]  R603      -7.8706592321395874e-01
    z[2,1,4]  R604      5.9010720252990723e-01
    z[2,1,4]  R605      -4.9014893174171448e-01
    z[2,1,4]  R606      3.4605216979980469e-01
    z[2,1,4]  R607      -0.784143328666687
    z[2,1,4]  R608      1.6048873960971832e-01
    z[2,1,4]  R609      -1.6336247324943542e-01
    z[2,1,4]  R610      -7.4287265539169312e-01
    z[2,1,4]  R611      2.8813734650611877e-01
    z[2,1,4]  R612      3.4640464186668396e-01
    z[2,1,4]  R613      2.3118773102760315e-01
    z[2,1,4]  R614      2.5349294766783714e-02
    z[2,1,4]  R615      5.0959908962249756e-01
    z[2,1,4]  R616      5.9191279113292694e-02
    z[2,1,4]  R617      -1.9709999859333038e-01
    z[2,1,4]  R618      2.4052542448043823e-01
    z[2,1,4]  R619      -9.3885980546474457e-02
    z[2,1,4]  R620      2.2049862891435623e-02
    z[2,1,4]  R621      1.2017721310257912e-02
    z[2,1,4]  R622      -1.8670603632926941e-01
    z[2,1,4]  R623      4.3236309289932251e-01
    z[2,1,4]  R624      -5.3325051069259644e-01
    z[2,1,4]  R625      3.5291498899459839e-01
    z[2,1,4]  R626      -7.4833756685256958e-01
    z[2,1,4]  R627      9.5168747007846832e-02
    z[2,1,4]  R628      -1.1875925958156586e-01
    z[2,1,4]  R629      9.6530608832836151e-02
    z[2,1,4]  R630      3.0272430181503296e-01
    z[2,1,4]  R631      1.7969278991222382e-01
    z[2,1,4]  R632      1.8295511603355408e-01
    z[2,1,4]  R633      1.3895675539970398e-01
    z[2,1,4]  R634      2.5637738406658173e-02
    z[2,1,4]  R635      3.8580101728439331e-01
    z[2,1,4]  R636      3.0356483533978462e-02
    z[2,1,4]  R637      -6.0467068105936050e-02
    z[2,1,4]  R638      2.6015114784240723e-01
    z[2,1,4]  R639      -1.6977331042289734e-01
    z[2,1,4]  R640      2.5859564542770386e-01
    z[2,1,4]  R641      8.3201992511749268e-01
    z[2,1,4]  R642      -8.2185596227645874e-01
    z[2,1,4]  R643      -6.2639784812927246e-01
    z[2,1,4]  R644      -2.4580799043178558e-01
    z[2,1,4]  R645      4.6386823058128357e-01
    z[2,1,4]  R646      -6.9450271129608154e-01
    z[2,1,4]  R647      4.4686034321784973e-01
    z[2,1,4]  R648      6.2149971723556519e-01
    z[2,1,4]  R649      -5.8028399944305420e-01
    z[2,1,4]  R650      2.3789599537849426e-02
    z[2,1,4]  R651      8.4485846757888794e-01
    z[2,1,4]  R652      2.5438550114631653e-01
    z[2,1,4]  R653      -4.7681885957717896e-01
    z[2,1,5]  R16       1
    z[2,1,5]  R25       -1
    z[2,1,5]  R540      -1
    z[2,1,5]  R541      1
    z[2,1,5]  R544      4.0886640548706055e-01
    z[2,1,5]  R545      1.1239586770534515e-01
    z[2,1,5]  R546      -1.2824654579162598e-01
    z[2,1,5]  R547      4.8890876770019531e-01
    z[2,1,5]  R548      2.4667195975780487e-01
    z[2,1,5]  R549      3.0765545368194580e-01
    z[2,1,5]  R550      -1.6746150329709053e-02
    z[2,1,5]  R551      -0.0683315098285675
    z[2,1,5]  R552      1.2376486510038376e-01
    z[2,1,5]  R553      3.5071703791618347e-01
    z[2,1,5]  R554      -1.2956143915653229e-01
    z[2,1,5]  R555      -3.2415542006492615e-01
    z[2,1,5]  R556      -5.3670185804367065e-01
    z[2,1,5]  R557      1.8109139800071716e-01
    z[2,1,5]  R558      -9.8403267562389374e-02
    z[2,1,5]  R559      -2.3633357137441635e-02
    z[2,1,5]  R560      8.2218162715435028e-02
    z[2,1,5]  R561      6.8722128868103027e-02
    z[2,1,5]  R562      -1.4278912544250488e-01
    z[2,1,5]  R563      -9.1430328786373138e-02
    z[2,1,5]  R564      -6.5892316401004791e-02
    z[2,1,5]  R565      1.1503832787275314e-01
    z[2,1,5]  R566      -3.3437585830688477e-01
    z[2,1,5]  R567      1.0261550545692444e-01
    z[2,1,5]  R568      -3.5006096959114075e-01
    z[2,1,5]  R569      -1.1785305291414261e-01
    z[2,1,5]  R570      -1.3829918205738068e-01
    z[2,1,5]  R571      -3.6164256930351257e-01
    z[2,1,5]  R572      -2.0925061404705048e-01
    z[2,1,5]  R573      1.5344475209712982e-01
    z[2,1,5]  R574      -3.1367599964141846e-01
    z[2,1,5]  R575      -3.9566081017255783e-02
    z[2,1,5]  R576      -5.5153405666351318e-01
    z[2,1,5]  R577      -2.1115562319755554e-01
    z[2,1,5]  R578      -2.5290203094482422e-01
    z[2,1,5]  R579      -3.4231055527925491e-02
    z[2,1,5]  R580      -3.9365702867507935e-01
    z[2,1,5]  R581      7.4246935546398163e-02
    z[2,1,5]  R582      1.3931236229836941e-02
    z[2,1,5]  R583      1.0323248058557510e-01
    z[2,1,5]  R584      1.1458898894488811e-02
    z[2,1,5]  R585      6.0198950767517090e-01
    z[2,1,5]  R586      -5.7573366910219193e-02
    z[2,1,5]  R587      -2.5862815976142883e-01
    z[2,1,5]  R588      2.9186886548995972e-01
    z[2,1,5]  R589      0.00526859937235713
    z[2,1,5]  R590      2.1128852665424347e-01
    z[2,1,5]  R591      -2.2448942065238953e-01
    z[2,1,5]  R592      -2.1524254232645035e-02
    z[2,1,5]  R593      2.6794016361236572e-01
    z[2,1,5]  R594      -6.7306622862815857e-02
    z[2,1,5]  R595      -4.4824701547622681e-01
    z[2,1,5]  R596      2.5261655449867249e-01
    z[2,1,5]  R597      9.6087656915187836e-02
    z[2,1,5]  R598      1.1172868311405182e-02
    z[2,1,5]  R599      -1.1932700127363205e-01
    z[2,1,5]  R600      -9.9355757236480713e-02
    z[2,1,5]  R601      0.0643991008400917
    z[2,1,5]  R602      -1.3695776462554932e-01
    z[2,1,5]  R603      6.5878160297870636e-02
    z[2,1,5]  R604      2.0843271911144257e-01
    z[2,1,5]  R605      1.0014345496892929e-01
    z[2,1,5]  R606      2.5994306802749634e-01
    z[2,1,5]  R607      -7.1071274578571320e-02
    z[2,1,5]  R608      -1.0951571911573410e-01
    z[2,1,5]  R609      1.1942744255065918e-01
    z[2,1,5]  R610      2.3815682530403137e-01
    z[2,1,5]  R611      1.6805014014244080e-01
    z[2,1,5]  R612      3.5341310501098633e-01
    z[2,1,5]  R613      -5.7587809860706329e-03
    z[2,1,5]  R614      -4.3268963694572449e-01
    z[2,1,5]  R615      -2.1182611584663391e-01
    z[2,1,5]  R616      -1.6084384918212891e-01
    z[2,1,5]  R617      -5.2090730518102646e-02
    z[2,1,5]  R618      5.4125446826219559e-02
    z[2,1,5]  R619      -2.0764803886413574e-01
    z[2,1,5]  R620      1.2295242398977280e-01
    z[2,1,5]  R621      2.0872300863265991e-01
    z[2,1,5]  R622      1.1930776387453079e-01
    z[2,1,5]  R623      -3.1884968280792236e-02
    z[2,1,5]  R624      6.5626579523086548e-01
    z[2,1,5]  R625      6.6537988185882568e-01
    z[2,1,5]  R626      3.3398557454347610e-02
    z[2,1,5]  R627      0.296827495098114
    z[2,1,5]  R628      -4.5416764914989471e-02
    z[2,1,5]  R629      -5.4162133485078812e-02
    z[2,1,5]  R630      -1.4519900083541870e-02
    z[2,1,5]  R631      3.0179911851882935e-01
    z[2,1,5]  R632      -9.4601154327392578e-02
    z[2,1,5]  R633      4.6772268414497375e-01
    z[2,1,5]  R634      -5.4586249589920044e-01
    z[2,1,5]  R635      -6.1169409751892090e-01
    z[2,1,5]  R636      -1.9058316946029663e-01
    z[2,1,5]  R637      4.1480389237403870e-01
    z[2,1,5]  R638      -1.7482955753803253e-01
    z[2,1,5]  R639      1.8879230320453644e-01
    z[2,1,5]  R640      6.7648209631443024e-02
    z[2,1,5]  R641      4.7131654620170593e-01
    z[2,1,5]  R642      -3.4881058335304260e-01
    z[2,1,5]  R643      -0.663200855255127
    z[2,1,5]  R644      -4.2663764953613281e-01
    z[2,1,5]  R645      2.8599733114242554e-01
    z[2,1,5]  R646      -1.9886104762554169e-01
    z[2,1,5]  R647      -7.7556155622005463e-02
    z[2,1,5]  R648      6.6100579500198364e-01
    z[2,1,5]  R649      1.8605035543441772e-01
    z[2,1,5]  R650      0.519503653049469
    z[2,1,5]  R651      3.5062929987907410e-01
    z[2,1,5]  R652      -2.4049113690853119e-01
    z[2,1,5]  R653      4.2587769031524658e-01
    z[2,1,6]  R17       1
    z[2,1,6]  R26       -1
    z[2,1,6]  R542      -1
    z[2,1,6]  R543      1
    z[2,1,6]  R544      -2.7494572568684816e-03
    z[2,1,6]  R545      1.4613977074623108e-01
    z[2,1,6]  R546      -2.2966891992837191e-03
    z[2,1,6]  R547      -3.0455753207206726e-01
    z[2,1,6]  R548      -9.2454567551612854e-02
    z[2,1,6]  R549      -1.3331221416592598e-02
    z[2,1,6]  R550      0.0850360244512558
    z[2,1,6]  R551      3.3200240135192871e-01
    z[2,1,6]  R552      1.2971581518650055e-01
    z[2,1,6]  R553      -1.3002598285675049e-01
    z[2,1,6]  R554      6.4658035989850760e-04
    z[2,1,6]  R555      1.4682596921920776e-01
    z[2,1,6]  R556      4.6131512522697449e-01
    z[2,1,6]  R557      -4.1206661611795425e-02
    z[2,1,6]  R558      -7.7206864953041077e-02
    z[2,1,6]  R559      9.6304953098297119e-02
    z[2,1,6]  R560      -2.2544731199741364e-01
    z[2,1,6]  R561      -1.8545429408550262e-01
    z[2,1,6]  R562      -4.2595180869102478e-01
    z[2,1,6]  R563      -2.8930693864822388e-01
    z[2,1,6]  R564      -4.4820669293403625e-01
    z[2,1,6]  R565      -2.8691756725311279e-01
    z[2,1,6]  R566      1.0799196362495422e-01
    z[2,1,6]  R567      9.8221465945243835e-02
    z[2,1,6]  R568      1.4508076012134552e-01
    z[2,1,6]  R569      2.2577278316020966e-01
    z[2,1,6]  R570      -1.3321690261363983e-02
    z[2,1,6]  R571      7.3098443448543549e-02
    z[2,1,6]  R572      -1.0302697867155075e-01
    z[2,1,6]  R573      7.0774590969085693e-01
    z[2,1,6]  R574      4.1437754034996033e-01
    z[2,1,6]  R575      -0.511720597743988
    z[2,1,6]  R576      9.7146227955818176e-02
    z[2,1,6]  R577      4.7523382306098938e-01
    z[2,1,6]  R578      3.0004331469535828e-01
    z[2,1,6]  R579      3.2768625020980835e-01
    z[2,1,6]  R580      -9.6416510641574860e-02
    z[2,1,6]  R581      3.9024993777275085e-01
    z[2,1,6]  R582      0.500403881072998
    z[2,1,6]  R583      -0.0842781662940979
    z[2,1,6]  R584      0.275449275970459
    z[2,1,6]  R585      -7.7913120388984680e-02
    z[2,1,6]  R586      -4.7000306844711304e-01
    z[2,1,6]  R587      -3.4643980860710144e-01
    z[2,1,6]  R588      -7.0663958787918091e-01
    z[2,1,6]  R589      6.0131076723337173e-02
    z[2,1,6]  R590      -2.6651713252067566e-01
    z[2,1,6]  R591      4.3111163377761841e-01
    z[2,1,6]  R592      -1.1779459565877914e-01
    z[2,1,6]  R593      -6.9593206048011780e-02
    z[2,1,6]  R594      -3.2721498608589172e-01
    z[2,1,6]  R595      -2.4010214954614639e-02
    z[2,1,6]  R596      -4.3036383390426636e-01
    z[2,1,6]  R597      -0.0923534482717514
    z[2,1,6]  R598      -0.328215092420578
    z[2,1,6]  R599      -1.4108602702617645e-01
    z[2,1,6]  R600      6.2837995588779449e-02
    z[2,1,6]  R601      -2.5084343552589417e-01
    z[2,1,6]  R602      3.1831854581832886e-01
    z[2,1,6]  R603      3.2484382390975952e-02
    z[2,1,6]  R604      -0.148881196975708
    z[2,1,6]  R605      3.3649137616157532e-01
    z[2,1,6]  R606      5.4013800621032715e-01
    z[2,1,6]  R607      -1.8159356713294983e-01
    z[2,1,6]  R608      1.0902926325798035e-02
    z[2,1,6]  R609      -4.0447127074003220e-02
    z[2,1,6]  R610      -1.8995296210050583e-02
    z[2,1,6]  R611      -1.1160200834274292e-01
    z[2,1,6]  R612      6.0983393341302872e-02
    z[2,1,6]  R613      3.1904298067092896e-01
    z[2,1,6]  R614      2.1662132814526558e-02
    z[2,1,6]  R615      -1.8995198607444763e-01
    z[2,1,6]  R616      2.9376775026321411e-01
    z[2,1,6]  R617      1.3069215416908264e-01
    z[2,1,6]  R618      -8.4015779197216034e-02
    z[2,1,6]  R619      -1.5442037582397461e-01
    z[2,1,6]  R620      -1.0543386638164520e-01
    z[2,1,6]  R621      -0.0949973315000534
    z[2,1,6]  R622      4.1611364483833313e-01
    z[2,1,6]  R623      -1.2132444977760315e-01
    z[2,1,6]  R624      9.7905740141868591e-02
    z[2,1,6]  R625      4.9548465758562088e-02
    z[2,1,6]  R626      -2.7058309316635132e-01
    z[2,1,6]  R627      -4.1099029779434204e-01
    z[2,1,6]  R628      4.0998399257659912e-01
    z[2,1,6]  R629      7.8890067338943481e-01
    z[2,1,6]  R630      0.154539555311203
    z[2,1,6]  R631      2.4185986816883087e-01
    z[2,1,6]  R632      -3.9707425236701965e-01
    z[2,1,6]  R633      -2.9685431718826294e-01
    z[2,1,6]  R634      -3.1361716985702515e-01
    z[2,1,6]  R635      -3.6338892579078674e-01
    z[2,1,6]  R636      -1.8524931371212006e-01
    z[2,1,6]  R637      7.5806602835655212e-02
    z[2,1,6]  R638      -1.5545448660850525e-01
    z[2,1,6]  R639      -4.1842922568321228e-01
    z[2,1,6]  R640      -3.4202453494071960e-01
    z[2,1,6]  R641      1.0799054801464081e-01
    z[2,1,6]  R642      6.9016069173812866e-02
    z[2,1,6]  R643      1.8315553665161133e-01
    z[2,1,6]  R644      6.1327970027923584e-01
    z[2,1,6]  R645      -7.9011484980583191e-02
    z[2,1,6]  R646      0.0741225853562355
    z[2,1,6]  R647      -1.9100518897175789e-02
    z[2,1,6]  R648      2.1752619743347168e-01
    z[2,1,6]  R649      -2.7648079395294189e-01
    z[2,1,6]  R650      -7.9037941992282867e-02
    z[2,1,6]  R651      -1.6159781813621521e-01
    z[2,1,6]  R652      4.9513506889343262e-01
    z[2,1,6]  R653      -3.0760830640792847e-01
    z[1,4,0]  R11       -1
    z[1,4,0]  R38       1
    z[1,4,0]  R654      -1
    z[1,4,0]  R655      1
    z[1,4,0]  R668      2.4657995998859406e-01
    z[1,4,0]  R669      0.255929559469223
    z[1,4,0]  R670      -1.8523028492927551e-01
    z[1,4,0]  R671      -1.9604268670082092e-01
    z[1,4,0]  R672      -2.2875583171844482e-01
    z[1,4,0]  R673      -1.6787399351596832e-01
    z[1,4,0]  R674      9.0189540386199951e-01
    z[1,4,0]  R675      8.8136249780654907e-01
    z[1,4,0]  R676      8.4615147113800049e-01
    z[1,4,0]  R677      -3.2924351096153259e-01
    z[1,4,0]  R678      3.9918351918458939e-02
    z[1,4,0]  R679      -5.6306332349777222e-02
    z[1,4,0]  R680      -5.9193450212478638e-01
    z[1,4,0]  R681      -8.7908446788787842e-01
    z[1,4,0]  R682      -8.4026736021041870e-01
    z[1,4,0]  R683      -7.2747319936752319e-01
    z[1,4,0]  R684      -6.2574809789657593e-01
    z[1,4,0]  R685      -1.8546107411384583e-01
    z[1,4,0]  R686      3.2135257124900818e-01
    z[1,4,0]  R687      2.1261560916900635e-01
    z[1,4,0]  R688      3.8622301816940308e-01
    z[1,4,0]  R689      -6.2194317579269409e-01
    z[1,4,0]  R690      5.9298551082611084e-01
    z[1,4,0]  R691      -8.3533978462219238e-01
    z[1,4,0]  R692      -2.7348718047142029e-01
    z[1,4,0]  R693      6.3934868574142456e-01
    z[1,4,0]  R694      -2.1891364455223083e-01
    z[1,4,0]  R695      -3.1954467296600342e-01
    z[1,4,0]  R696      3.1205892562866211e-01
    z[1,4,0]  R697      3.0639445781707764e-01
    z[1,4,0]  R698      -4.7347900271415710e-01
    z[1,4,0]  R699      9.0349888801574707e-01
    z[1,4,0]  R700      -3.5524335503578186e-01
    z[1,4,0]  R701      8.7765812873840332e-01
    z[1,4,0]  R702      8.9711707830429077e-01
    z[1,4,0]  R703      8.5212677717208862e-02
    z[1,4,0]  R704      -8.4351825714111328e-01
    z[1,4,0]  R705      4.9002498388290405e-01
    z[1,4,0]  R706      -7.4569523334503174e-01
    z[1,4,0]  R707      2.5136426091194153e-01
    z[1,4,0]  R708      -5.4509627819061279e-01
    z[1,4,0]  R709      -5.5023926496505737e-01
    z[1,4,0]  R710      -5.0054174661636353e-01
    z[1,4,0]  R711      -5.7826393842697144e-01
    z[1,4,0]  R712      -5.1791024208068848e-01
    z[1,4,0]  R713      -7.3025655746459961e-01
    z[1,4,0]  R714      -7.3584026098251343e-01
    z[1,4,0]  R715      -0.660832405090332
    z[1,4,0]  R716      -6.5865439176559448e-01
    z[1,4,0]  R717      5.3700363636016846e-01
    z[1,4,0]  R718      5.1652848720550537e-01
    z[1,4,0]  R719      4.7987800836563110e-01
    z[1,4,0]  R720      2.9732385277748108e-01
    z[1,4,0]  R721      3.5026237368583679e-01
    z[1,4,0]  R722      4.0412786602973938e-01
    z[1,4,0]  R723      8.9487487077713013e-01
    z[1,4,0]  R724      5.7791447639465332e-01
    z[1,4,0]  R725      3.3423185348510742e-01
    z[1,4,0]  R726      3.9829817414283752e-01
    z[1,4,0]  R727      3.0566087365150452e-01
    z[1,4,0]  R728      3.0863767862319946e-01
    z[1,4,0]  R729      2.8419691324234009e-01
    z[1,4,0]  R730      -3.2681086659431458e-01
    z[1,4,1]  R12       -1
    z[1,4,1]  R39       1
    z[1,4,1]  R656      -1
    z[1,4,1]  R657      1
    z[1,4,1]  R668      2.5135436654090881e-01
    z[1,4,1]  R669      0.420491099357605
    z[1,4,1]  R670      2.5548499822616577e-01
    z[1,4,1]  R671      1.5653695166110992e-01
    z[1,4,1]  R672      1.7599220573902130e-01
    z[1,4,1]  R673      2.3999880254268646e-01
    z[1,4,1]  R674      1.9431927800178528e-01
    z[1,4,1]  R675      -1.5722972154617310e-01
    z[1,4,1]  R676      -1.4477474987506866e-01
    z[1,4,1]  R677      3.7604832649230957e-01
    z[1,4,1]  R678      0.689096212387085
    z[1,4,1]  R679      5.3424453735351562e-01
    z[1,4,1]  R680      4.8140963912010193e-01
    z[1,4,1]  R681      -7.9528607428073883e-02
    z[1,4,1]  R682      -2.2351981699466705e-01
    z[1,4,1]  R683      -1.5993355214595795e-01
    z[1,4,1]  R684      -3.0037540197372437e-01
    z[1,4,1]  R685      -3.6878433078527451e-02
    z[1,4,1]  R686      1.3351911678910255e-02
    z[1,4,1]  R687      1.3604276813566685e-02
    z[1,4,1]  R688      2.8984868526458740e-01
    z[1,4,1]  R689      2.1480667591094971e-01
    z[1,4,1]  R690      -0.0954454317688942
    z[1,4,1]  R691      8.9969672262668610e-02
    z[1,4,1]  R692      -1.0357370972633362e-01
    z[1,4,1]  R693      3.8562972098588943e-02
    z[1,4,1]  R694      7.2650928050279617e-03
    z[1,4,1]  R695      -1.8665449321269989e-01
    z[1,4,1]  R696      -3.9170585572719574e-02
    z[1,4,1]  R697      -5.0568240880966187e-01
    z[1,4,1]  R698      -4.3337881565093994e-01
    z[1,4,1]  R699      -8.1412322819232941e-02
    z[1,4,1]  R700      4.7677550464868546e-02
    z[1,4,1]  R701      -2.4651013314723969e-01
    z[1,4,1]  R702      9.0749554336071014e-02
    z[1,4,1]  R703      7.1628761291503906e-01
    z[1,4,1]  R704      8.1906437873840332e-02
    z[1,4,1]  R705      -2.1238750219345093e-01
    z[1,4,1]  R706      3.3670984208583832e-02
    z[1,4,1]  R707      -4.5006313920021057e-01
    z[1,4,1]  R708      -2.9721334576606750e-01
    z[1,4,1]  R709      -4.0150359272956848e-01
    z[1,4,1]  R710      -3.8969784975051880e-01
    z[1,4,1]  R711      -3.7562859058380127e-01
    z[1,4,1]  R712      -3.1049597263336182e-01
    z[1,4,1]  R713      3.8402697443962097e-01
    z[1,4,1]  R714      -2.2488430142402649e-01
    z[1,4,1]  R715      -2.9133029282093048e-02
    z[1,4,1]  R716      -3.5321453213691711e-01
    z[1,4,1]  R717      -4.7083371877670288e-01
    z[1,4,1]  R718      -3.0634710192680359e-01
    z[1,4,1]  R719      -4.5350956916809082e-01
    z[1,4,1]  R720      -2.1151988208293915e-01
    z[1,4,1]  R721      -1.7822524905204773e-01
    z[1,4,1]  R722      2.1170638501644135e-01
    z[1,4,1]  R723      -2.2562728822231293e-01
    z[1,4,1]  R724      -5.6426286697387695e-02
    z[1,4,1]  R725      -1.3580378890037537e-01
    z[1,4,1]  R726      4.9179205298423767e-01
    z[1,4,1]  R727      3.1875270605087280e-01
    z[1,4,1]  R728      2.9287168383598328e-01
    z[1,4,1]  R729      3.4953951835632324e-01
    z[1,4,1]  R730      -2.0246687531471252e-01
    z[1,4,2]  R13       -1
    z[1,4,2]  R40       1
    z[1,4,2]  R658      -1
    z[1,4,2]  R659      1
    z[1,4,2]  R668      3.3723658323287964e-01
    z[1,4,2]  R669      2.1254646778106689e-01
    z[1,4,2]  R670      3.6979696154594421e-01
    z[1,4,2]  R671      8.1125551462173462e-01
    z[1,4,2]  R672      8.3727121353149414e-01
    z[1,4,2]  R673      -3.9338001608848572e-01
    z[1,4,2]  R674      -6.8045049905776978e-02
    z[1,4,2]  R675      5.2481066435575485e-02
    z[1,4,2]  R676      2.3879086971282959e-01
    z[1,4,2]  R677      -2.5375235080718994e-01
    z[1,4,2]  R678      -2.2355543076992035e-01
    z[1,4,2]  R679      -1.0044532269239426e-01
    z[1,4,2]  R680      -5.8036994934082031e-01
    z[1,4,2]  R681      -1.7762959003448486e-01
    z[1,4,2]  R682      -3.6471266299486160e-02
    z[1,4,2]  R683      -3.6093726754188538e-01
    z[1,4,2]  R684      -3.0557924509048462e-01
    z[1,4,2]  R685      -1.9537086784839630e-01
    z[1,4,2]  R686      -1.2592333555221558e-01
    z[1,4,2]  R687      2.4499481916427612e-01
    z[1,4,2]  R688      -1.9908134639263153e-01
    z[1,4,2]  R689      -5.0699585676193237e-01
    z[1,4,2]  R690      3.3400547504425049e-01
    z[1,4,2]  R691      1.7254938185214996e-01
    z[1,4,2]  R692      -2.0253041386604309e-01
    z[1,4,2]  R693      -3.6949047446250916e-01
    z[1,4,2]  R694      -7.6224929094314575e-01
    z[1,4,2]  R695      5.7550603523850441e-03
    z[1,4,2]  R696      6.9921833276748657e-01
    z[1,4,2]  R697      3.4651690721511841e-01
    z[1,4,2]  R698      -4.0026667714118958e-01
    z[1,4,2]  R699      -1.8174979090690613e-01
    z[1,4,2]  R700      -7.2701007127761841e-01
    z[1,4,2]  R701      6.9238655269145966e-02
    z[1,4,2]  R702      -1.9710262119770050e-01
    z[1,4,2]  R703      5.6447625160217285e-02
    z[1,4,2]  R704      2.0022470504045486e-02
    z[1,4,2]  R705      1.3306963443756104e-01
    z[1,4,2]  R706      -1.9731815159320831e-01
    z[1,4,2]  R707      -5.8517616987228394e-01
    z[1,4,2]  R708      6.3593953847885132e-01
    z[1,4,2]  R709      5.4929924011230469e-01
    z[1,4,2]  R710      5.8574265241622925e-01
    z[1,4,2]  R711      4.4907850027084351e-01
    z[1,4,2]  R712      5.3506422042846680e-01
    z[1,4,2]  R713      -4.1943371295928955e-01
    z[1,4,2]  R714      -3.1705504655838013e-01
    z[1,4,2]  R715      -5.5717867612838745e-01
    z[1,4,2]  R716      -3.3449560403823853e-01
    z[1,4,2]  R717      -5.0315749645233154e-01
    z[1,4,2]  R718      -3.1380680203437805e-01
    z[1,4,2]  R719      1.7505396157503128e-02
    z[1,4,2]  R720      -6.4479392766952515e-01
    z[1,4,2]  R721      -5.8811032772064209e-01
    z[1,4,2]  R722      4.3414118885993958e-01
    z[1,4,2]  R723      -1.1416142433881760e-01
    z[1,4,2]  R724      -4.8208889365196228e-01
    z[1,4,2]  R725      -2.0556335151195526e-01
    z[1,4,2]  R726      7.0926159620285034e-01
    z[1,4,2]  R727      0.772919774055481
    z[1,4,2]  R728      7.5071024894714355e-01
    z[1,4,2]  R729      6.2224715948104858e-01
    z[1,4,2]  R730      7.0781558752059937e-01
    z[1,4,3]  R14       -1
    z[1,4,3]  R41       1
    z[1,4,3]  R660      -1
    z[1,4,3]  R661      1
    z[1,4,3]  R668      1.9407291710376740e-01
    z[1,4,3]  R669      3.7785834074020386e-01
    z[1,4,3]  R670      0.359621524810791
    z[1,4,3]  R671      1.1336320638656616e-01
    z[1,4,3]  R672      -1.7726014554500580e-01
    z[1,4,3]  R673      3.5334849357604980e-01
    z[1,4,3]  R674      -1.6869869828224182e-01
    z[1,4,3]  R675      1.1771301925182343e-01
    z[1,4,3]  R676      -7.7181234955787659e-02
    z[1,4,3]  R677      -5.9966671466827393e-01
    z[1,4,3]  R678      -2.7676156163215637e-01
    z[1,4,3]  R679      2.1508021652698517e-01
    z[1,4,3]  R680      9.7305081784725189e-02
    z[1,4,3]  R681      0.0887034460902214
    z[1,4,3]  R682      3.4676992893218994e-01
    z[1,4,3]  R683      2.7455356717109680e-01
    z[1,4,3]  R684      4.8621648550033569e-01
    z[1,4,3]  R685      -4.0148496627807617e-03
    z[1,4,3]  R686      2.8074583411216736e-01
    z[1,4,3]  R687      1.6979804635047913e-01
    z[1,4,3]  R688      3.2959511876106262e-01
    z[1,4,3]  R689      -8.2395315170288086e-02
    z[1,4,3]  R690      1.8020935356616974e-02
    z[1,4,3]  R691      -2.4140359461307526e-01
    z[1,4,3]  R692      5.4319225251674652e-02
    z[1,4,3]  R693      7.3736339807510376e-02
    z[1,4,3]  R694      3.0708810687065125e-01
    z[1,4,3]  R695      1.3325117528438568e-02
    z[1,4,3]  R696      -2.1088348329067230e-01
    z[1,4,3]  R697      1.6426447033882141e-01
    z[1,4,3]  R698      3.5166677832603455e-01
    z[1,4,3]  R699      -1.7718973755836487e-01
    z[1,4,3]  R700      -1.7114609479904175e-01
    z[1,4,3]  R701      1.0475947707891464e-01
    z[1,4,3]  R702      -1.4726942777633667e-01
    z[1,4,3]  R703      -7.2947158478200436e-03
    z[1,4,3]  R704      9.5679499208927155e-02
    z[1,4,3]  R705      3.3502838015556335e-01
    z[1,4,3]  R706      -1.4262425899505615e-01
    z[1,4,3]  R707      3.4569406509399414e-01
    z[1,4,3]  R708      -1.8511952459812164e-01
    z[1,4,3]  R709      1.8296670913696289e-01
    z[1,4,3]  R710      2.8348726034164429e-01
    z[1,4,3]  R711      -1.3576443493366241e-01
    z[1,4,3]  R712      1.6956056654453278e-01
    z[1,4,3]  R713      -4.3668370693922043e-02
    z[1,4,3]  R714      2.3234169185161591e-01
    z[1,4,3]  R715      4.1011381894350052e-02
    z[1,4,3]  R716      3.1981386244297028e-02
    z[1,4,3]  R717      0.309207946062088
    z[1,4,3]  R718      3.5993787646293640e-01
    z[1,4,3]  R719      5.1507014036178589e-01
    z[1,4,3]  R720      -3.3113643527030945e-01
    z[1,4,3]  R721      -0.296572744846344
    z[1,4,3]  R722      -1.6149322688579559e-01
    z[1,4,3]  R723      2.6683533191680908e-01
    z[1,4,3]  R724      -2.6365929841995239e-01
    z[1,4,3]  R725      -1.7282043397426605e-01
    z[1,4,3]  R726      -9.6074566245079041e-02
    z[1,4,3]  R727      2.1486331522464752e-01
    z[1,4,3]  R728      3.2078996300697327e-01
    z[1,4,3]  R729      1.3732829689979553e-01
    z[1,4,3]  R730      -4.2660561203956604e-01
    z[1,4,4]  R15       -1
    z[1,4,4]  R42       1
    z[1,4,4]  R662      -1
    z[1,4,4]  R663      1
    z[1,4,4]  R668      -5.3325051069259644e-01
    z[1,4,4]  R669      3.5291498899459839e-01
    z[1,4,4]  R670      -7.4833756685256958e-01
    z[1,4,4]  R671      9.5168747007846832e-02
    z[1,4,4]  R672      -1.1875925958156586e-01
    z[1,4,4]  R673      9.6530608832836151e-02
    z[1,4,4]  R674      3.0272430181503296e-01
    z[1,4,4]  R675      1.7969278991222382e-01
    z[1,4,4]  R676      1.8295511603355408e-01
    z[1,4,4]  R677      1.3895675539970398e-01
    z[1,4,4]  R678      2.5637738406658173e-02
    z[1,4,4]  R679      3.8580101728439331e-01
    z[1,4,4]  R680      3.0356483533978462e-02
    z[1,4,4]  R681      -6.0467068105936050e-02
    z[1,4,4]  R682      2.6015114784240723e-01
    z[1,4,4]  R683      -1.6977331042289734e-01
    z[1,4,4]  R684      2.5859564542770386e-01
    z[1,4,4]  R685      8.3201992511749268e-01
    z[1,4,4]  R686      -8.2185596227645874e-01
    z[1,4,4]  R687      -6.2639784812927246e-01
    z[1,4,4]  R688      -2.4580799043178558e-01
    z[1,4,4]  R689      4.6386823058128357e-01
    z[1,4,4]  R690      -6.9450271129608154e-01
    z[1,4,4]  R691      4.4686034321784973e-01
    z[1,4,4]  R692      6.2149971723556519e-01
    z[1,4,4]  R693      -5.8028399944305420e-01
    z[1,4,4]  R694      2.3789599537849426e-02
    z[1,4,4]  R695      8.4485846757888794e-01
    z[1,4,4]  R696      2.5438550114631653e-01
    z[1,4,4]  R697      -4.7681885957717896e-01
    z[1,4,4]  R698      2.2054056823253632e-01
    z[1,4,4]  R699      -2.8322175145149231e-01
    z[1,4,4]  R700      1.1401998996734619e-01
    z[1,4,4]  R701      -1.3707152009010315e-01
    z[1,4,4]  R702      4.4733222573995590e-02
    z[1,4,4]  R703      2.6117414236068726e-01
    z[1,4,4]  R704      4.9561902880668640e-01
    z[1,4,4]  R705      0.406207412481308
    z[1,4,4]  R706      -3.5524827241897583e-01
    z[1,4,4]  R707      3.7169721722602844e-01
    z[1,4,4]  R708      -3.1640312075614929e-01
    z[1,4,4]  R709      -4.2178431153297424e-01
    z[1,4,4]  R710      -2.5168126821517944e-01
    z[1,4,4]  R711      -4.4645896553993225e-01
    z[1,4,4]  R712      -3.5246381163597107e-01
    z[1,4,4]  R713      0.280819296836853
    z[1,4,4]  R714      4.3981426954269409e-01
    z[1,4,4]  R715      4.0599894709885120e-03
    z[1,4,4]  R716      -4.7642147541046143e-01
    z[1,4,4]  R717      2.0234338939189911e-01
    z[1,4,4]  R718      5.0732856988906860e-01
    z[1,4,4]  R719      -2.6159477233886719e-01
    z[1,4,4]  R720      1.0549803078174591e-01
    z[1,4,4]  R721      3.7096962332725525e-01
    z[1,4,4]  R722      -4.3181905150413513e-01
    z[1,4,4]  R723      1.6442857682704926e-01
    z[1,4,4]  R724      4.8693239688873291e-01
    z[1,4,4]  R725      6.7832469940185547e-02
    z[1,4,4]  R726      2.7059277892112732e-01
    z[1,4,4]  R727      -3.8322050124406815e-02
    z[1,4,4]  R728      1.9262421131134033e-01
    z[1,4,4]  R729      -1.2879092991352081e-01
    z[1,4,4]  R730      -1.4227072894573212e-01
    z[1,4,5]  R16       -1
    z[1,4,5]  R43       1
    z[1,4,5]  R664      -1
    z[1,4,5]  R665      1
    z[1,4,5]  R668      6.5626579523086548e-01
    z[1,4,5]  R669      6.6537988185882568e-01
    z[1,4,5]  R670      3.3398557454347610e-02
    z[1,4,5]  R671      0.296827495098114
    z[1,4,5]  R672      -4.5416764914989471e-02
    z[1,4,5]  R673      -5.4162133485078812e-02
    z[1,4,5]  R674      -1.4519900083541870e-02
    z[1,4,5]  R675      3.0179911851882935e-01
    z[1,4,5]  R676      -9.4601154327392578e-02
    z[1,4,5]  R677      4.6772268414497375e-01
    z[1,4,5]  R678      -5.4586249589920044e-01
    z[1,4,5]  R679      -6.1169409751892090e-01
    z[1,4,5]  R680      -1.9058316946029663e-01
    z[1,4,5]  R681      4.1480389237403870e-01
    z[1,4,5]  R682      -1.7482955753803253e-01
    z[1,4,5]  R683      1.8879230320453644e-01
    z[1,4,5]  R684      6.7648209631443024e-02
    z[1,4,5]  R685      4.7131654620170593e-01
    z[1,4,5]  R686      -3.4881058335304260e-01
    z[1,4,5]  R687      -0.663200855255127
    z[1,4,5]  R688      -4.2663764953613281e-01
    z[1,4,5]  R689      2.8599733114242554e-01
    z[1,4,5]  R690      -1.9886104762554169e-01
    z[1,4,5]  R691      -7.7556155622005463e-02
    z[1,4,5]  R692      6.6100579500198364e-01
    z[1,4,5]  R693      1.8605035543441772e-01
    z[1,4,5]  R694      0.519503653049469
    z[1,4,5]  R695      3.5062929987907410e-01
    z[1,4,5]  R696      -2.4049113690853119e-01
    z[1,4,5]  R697      4.2587769031524658e-01
    z[1,4,5]  R698      1.5188623964786530e-01
    z[1,4,5]  R699      -1.6468483209609985e-01
    z[1,4,5]  R700      5.0029838085174561e-01
    z[1,4,5]  R701      -1.1389130959287286e-03
    z[1,4,5]  R702      -5.6748535484075546e-02
    z[1,4,5]  R703      -6.2615203857421875e-01
    z[1,4,5]  R704      1.6065572202205658e-01
    z[1,4,5]  R705      6.4777636528015137e-01
    z[1,4,5]  R706      -5.0720870494842529e-01
    z[1,4,5]  R707      -3.6588084697723389e-01
    z[1,4,5]  R708      7.4011576361954212e-03
    z[1,4,5]  R709      -1.0231139510869980e-01
    z[1,4,5]  R710      -3.2818627357482910e-01
    z[1,4,5]  R711      -3.0741935968399048e-01
    z[1,4,5]  R712      -4.0899041295051575e-01
    z[1,4,5]  R713      1.0906521230936050e-01
    z[1,4,5]  R714      2.3966281116008759e-01
    z[1,4,5]  R715      3.5929358005523682e-01
    z[1,4,5]  R716      3.1823945045471191e-01
    z[1,4,5]  R717      2.2841575741767883e-01
    z[1,4,5]  R718      -3.8880008459091187e-01
    z[1,4,5]  R719      3.3971187472343445e-01
    z[1,4,5]  R720      5.5800056457519531e-01
    z[1,4,5]  R721      3.8121134042739868e-01
    z[1,4,5]  R722      5.7679861783981323e-01
    z[1,4,5]  R723      -1.6769881546497345e-01
    z[1,4,5]  R724      -3.3462487161159515e-02
    z[1,4,5]  R725      8.8889855146408081e-01
    z[1,4,5]  R726      -2.6256833225488663e-02
    z[1,4,5]  R727      1.5315471589565277e-01
    z[1,4,5]  R728      -2.9874238371849060e-01
    z[1,4,5]  R729      -5.6345868110656738e-01
    z[1,4,5]  R730      9.4821535050868988e-02
    z[1,4,6]  R17       -1
    z[1,4,6]  R44       1
    z[1,4,6]  R666      -1
    z[1,4,6]  R667      1
    z[1,4,6]  R668      9.7905740141868591e-02
    z[1,4,6]  R669      4.9548465758562088e-02
    z[1,4,6]  R670      -2.7058309316635132e-01
    z[1,4,6]  R671      -4.1099029779434204e-01
    z[1,4,6]  R672      4.0998399257659912e-01
    z[1,4,6]  R673      7.8890067338943481e-01
    z[1,4,6]  R674      0.154539555311203
    z[1,4,6]  R675      2.4185986816883087e-01
    z[1,4,6]  R676      -3.9707425236701965e-01
    z[1,4,6]  R677      -2.9685431718826294e-01
    z[1,4,6]  R678      -3.1361716985702515e-01
    z[1,4,6]  R679      -3.6338892579078674e-01
    z[1,4,6]  R680      -1.8524931371212006e-01
    z[1,4,6]  R681      7.5806602835655212e-02
    z[1,4,6]  R682      -1.5545448660850525e-01
    z[1,4,6]  R683      -4.1842922568321228e-01
    z[1,4,6]  R684      -3.4202453494071960e-01
    z[1,4,6]  R685      1.0799054801464081e-01
    z[1,4,6]  R686      6.9016069173812866e-02
    z[1,4,6]  R687      1.8315553665161133e-01
    z[1,4,6]  R688      6.1327970027923584e-01
    z[1,4,6]  R689      -7.9011484980583191e-02
    z[1,4,6]  R690      0.0741225853562355
    z[1,4,6]  R691      -1.9100518897175789e-02
    z[1,4,6]  R692      2.1752619743347168e-01
    z[1,4,6]  R693      -2.7648079395294189e-01
    z[1,4,6]  R694      -7.9037941992282867e-02
    z[1,4,6]  R695      -1.6159781813621521e-01
    z[1,4,6]  R696      4.9513506889343262e-01
    z[1,4,6]  R697      -3.0760830640792847e-01
    z[1,4,6]  R698      -4.8208922147750854e-01
    z[1,4,6]  R699      -7.2780676186084747e-02
    z[1,4,6]  R700      2.2448913753032684e-01
    z[1,4,6]  R701      -3.6659315228462219e-01
    z[1,4,6]  R702      3.4811830520629883e-01
    z[1,4,6]  R703      -1.2709483504295349e-01
    z[1,4,6]  R704      -2.7647811919450760e-02
    z[1,4,6]  R705      1.4032294973731041e-02
    z[1,4,6]  R706      8.1678237766027451e-03
    z[1,4,6]  R707      1.7205484211444855e-02
    z[1,4,6]  R708      2.7510038018226624e-01
    z[1,4,6]  R709      -1.1160384118556976e-01
    z[1,4,6]  R710      5.5536616593599319e-02
    z[1,4,6]  R711      0.102850541472435
    z[1,4,6]  R712      -0.169743612408638
    z[1,4,6]  R713      2.2508314251899719e-01
    z[1,4,6]  R714      5.0840977579355240e-02
    z[1,4,6]  R715      -3.4815722703933716e-01
    z[1,4,6]  R716      1.5809737145900726e-02
    z[1,4,6]  R717      2.1920089423656464e-01
    z[1,4,6]  R718      -5.2649658173322678e-02
    z[1,4,6]  R719      3.3853590488433838e-01
    z[1,4,6]  R720      -1.3766942918300629e-01
    z[1,4,6]  R721      -3.5886257886886597e-01
    z[1,4,6]  R722      2.4111849069595337e-01
    z[1,4,6]  R723      9.4328567385673523e-02
    z[1,4,6]  R724      -3.5025981068611145e-01
    z[1,4,6]  R725      -5.4601531475782394e-02
    z[1,4,6]  R726      -1.1535544693470001e-01
    z[1,4,6]  R727      3.6942100524902344e-01
    z[1,4,6]  R728      1.6169679164886475e-01
    z[1,4,6]  R729      2.3860198259353638e-01
    z[1,4,6]  R730      -3.7413170933723450e-01
    z[4,1,0]  R11       1
    z[4,1,0]  R38       -1
    z[4,1,0]  R731      -1
    z[4,1,0]  R732      1
    z[4,1,0]  R745      2.4657995998859406e-01
    z[4,1,0]  R746      0.255929559469223
    z[4,1,0]  R747      -1.8523028492927551e-01
    z[4,1,0]  R748      -1.6787399351596832e-01
    z[4,1,0]  R749      -3.2924351096153259e-01
    z[4,1,0]  R750      -4.7347900271415710e-01
    z[4,1,0]  R751      9.0349888801574707e-01
    z[4,1,0]  R752      -3.5524335503578186e-01
    z[4,1,0]  R753      8.7765812873840332e-01
    z[4,1,0]  R754      8.9711707830429077e-01
    z[4,1,0]  R755      8.5212677717208862e-02
    z[4,1,0]  R756      -8.4351825714111328e-01
    z[4,1,0]  R757      4.9002498388290405e-01
    z[4,1,0]  R758      -7.4569523334503174e-01
    z[4,1,0]  R759      2.5136426091194153e-01
    z[4,1,0]  R760      -5.4509627819061279e-01
    z[4,1,0]  R761      -5.5023926496505737e-01
    z[4,1,0]  R762      -5.0054174661636353e-01
    z[4,1,0]  R763      -5.7826393842697144e-01
    z[4,1,0]  R764      -5.1791024208068848e-01
    z[4,1,0]  R765      -7.3025655746459961e-01
    z[4,1,0]  R766      -7.3584026098251343e-01
    z[4,1,0]  R767      -0.660832405090332
    z[4,1,0]  R768      -6.5865439176559448e-01
    z[4,1,0]  R769      5.3700363636016846e-01
    z[4,1,0]  R770      5.1652848720550537e-01
    z[4,1,0]  R771      4.7987800836563110e-01
    z[4,1,0]  R772      2.9732385277748108e-01
    z[4,1,0]  R773      3.5026237368583679e-01
    z[4,1,0]  R774      4.0412786602973938e-01
    z[4,1,0]  R775      8.9487487077713013e-01
    z[4,1,0]  R776      5.7791447639465332e-01
    z[4,1,0]  R777      3.3423185348510742e-01
    z[4,1,0]  R778      3.9829817414283752e-01
    z[4,1,0]  R779      3.0566087365150452e-01
    z[4,1,0]  R780      3.0863767862319946e-01
    z[4,1,0]  R781      2.8419691324234009e-01
    z[4,1,0]  R782      -3.2681086659431458e-01
    z[4,1,0]  R783      -1.9604268670082092e-01
    z[4,1,0]  R784      -2.2875583171844482e-01
    z[4,1,0]  R785      9.0189540386199951e-01
    z[4,1,0]  R786      8.8136249780654907e-01
    z[4,1,0]  R787      8.4615147113800049e-01
    z[4,1,0]  R788      3.9918351918458939e-02
    z[4,1,0]  R789      -5.6306332349777222e-02
    z[4,1,0]  R790      -5.9193450212478638e-01
    z[4,1,0]  R791      -8.7908446788787842e-01
    z[4,1,0]  R792      -8.4026736021041870e-01
    z[4,1,0]  R793      -7.2747319936752319e-01
    z[4,1,0]  R794      -6.2574809789657593e-01
    z[4,1,0]  R795      -1.8546107411384583e-01
    z[4,1,0]  R796      3.2135257124900818e-01
    z[4,1,0]  R797      2.1261560916900635e-01
    z[4,1,0]  R798      3.8622301816940308e-01
    z[4,1,0]  R799      -6.2194317579269409e-01
    z[4,1,0]  R800      5.9298551082611084e-01
    z[4,1,0]  R801      -8.3533978462219238e-01
    z[4,1,0]  R802      -2.7348718047142029e-01
    z[4,1,0]  R803      6.3934868574142456e-01
    z[4,1,0]  R804      -2.1891364455223083e-01
    z[4,1,0]  R805      -3.1954467296600342e-01
    z[4,1,0]  R806      3.1205892562866211e-01
    z[4,1,0]  R807      3.0639445781707764e-01
    z[4,1,1]  R12       1
    z[4,1,1]  R39       -1
    z[4,1,1]  R733      -1
    z[4,1,1]  R734      1
    z[4,1,1]  R745      2.5135436654090881e-01
    z[4,1,1]  R746      0.420491099357605
    z[4,1,1]  R747      2.5548499822616577e-01
    z[4,1,1]  R748      2.3999880254268646e-01
    z[4,1,1]  R749      3.7604832649230957e-01
    z[4,1,1]  R750      -4.3337881565093994e-01
    z[4,1,1]  R751      -8.1412322819232941e-02
    z[4,1,1]  R752      4.7677550464868546e-02
    z[4,1,1]  R753      -2.4651013314723969e-01
    z[4,1,1]  R754      9.0749554336071014e-02
    z[4,1,1]  R755      7.1628761291503906e-01
    z[4,1,1]  R756      8.1906437873840332e-02
    z[4,1,1]  R757      -2.1238750219345093e-01
    z[4,1,1]  R758      3.3670984208583832e-02
    z[4,1,1]  R759      -4.5006313920021057e-01
    z[4,1,1]  R760      -2.9721334576606750e-01
    z[4,1,1]  R761      -4.0150359272956848e-01
    z[4,1,1]  R762      -3.8969784975051880e-01
    z[4,1,1]  R763      -3.7562859058380127e-01
    z[4,1,1]  R764      -3.1049597263336182e-01
    z[4,1,1]  R765      3.8402697443962097e-01
    z[4,1,1]  R766      -2.2488430142402649e-01
    z[4,1,1]  R767      -2.9133029282093048e-02
    z[4,1,1]  R768      -3.5321453213691711e-01
    z[4,1,1]  R769      -4.7083371877670288e-01
    z[4,1,1]  R770      -3.0634710192680359e-01
    z[4,1,1]  R771      -4.5350956916809082e-01
    z[4,1,1]  R772      -2.1151988208293915e-01
    z[4,1,1]  R773      -1.7822524905204773e-01
    z[4,1,1]  R774      2.1170638501644135e-01
    z[4,1,1]  R775      -2.2562728822231293e-01
    z[4,1,1]  R776      -5.6426286697387695e-02
    z[4,1,1]  R777      -1.3580378890037537e-01
    z[4,1,1]  R778      4.9179205298423767e-01
    z[4,1,1]  R779      3.1875270605087280e-01
    z[4,1,1]  R780      2.9287168383598328e-01
    z[4,1,1]  R781      3.4953951835632324e-01
    z[4,1,1]  R782      -2.0246687531471252e-01
    z[4,1,1]  R783      1.5653695166110992e-01
    z[4,1,1]  R784      1.7599220573902130e-01
    z[4,1,1]  R785      1.9431927800178528e-01
    z[4,1,1]  R786      -1.5722972154617310e-01
    z[4,1,1]  R787      -1.4477474987506866e-01
    z[4,1,1]  R788      0.689096212387085
    z[4,1,1]  R789      5.3424453735351562e-01
    z[4,1,1]  R790      4.8140963912010193e-01
    z[4,1,1]  R791      -7.9528607428073883e-02
    z[4,1,1]  R792      -2.2351981699466705e-01
    z[4,1,1]  R793      -1.5993355214595795e-01
    z[4,1,1]  R794      -3.0037540197372437e-01
    z[4,1,1]  R795      -3.6878433078527451e-02
    z[4,1,1]  R796      1.3351911678910255e-02
    z[4,1,1]  R797      1.3604276813566685e-02
    z[4,1,1]  R798      2.8984868526458740e-01
    z[4,1,1]  R799      2.1480667591094971e-01
    z[4,1,1]  R800      -0.0954454317688942
    z[4,1,1]  R801      8.9969672262668610e-02
    z[4,1,1]  R802      -1.0357370972633362e-01
    z[4,1,1]  R803      3.8562972098588943e-02
    z[4,1,1]  R804      7.2650928050279617e-03
    z[4,1,1]  R805      -1.8665449321269989e-01
    z[4,1,1]  R806      -3.9170585572719574e-02
    z[4,1,1]  R807      -5.0568240880966187e-01
    z[4,1,2]  R13       1
    z[4,1,2]  R40       -1
    z[4,1,2]  R735      -1
    z[4,1,2]  R736      1
    z[4,1,2]  R745      3.3723658323287964e-01
    z[4,1,2]  R746      2.1254646778106689e-01
    z[4,1,2]  R747      3.6979696154594421e-01
    z[4,1,2]  R748      -3.9338001608848572e-01
    z[4,1,2]  R749      -2.5375235080718994e-01
    z[4,1,2]  R750      -4.0026667714118958e-01
    z[4,1,2]  R751      -1.8174979090690613e-01
    z[4,1,2]  R752      -7.2701007127761841e-01
    z[4,1,2]  R753      6.9238655269145966e-02
    z[4,1,2]  R754      -1.9710262119770050e-01
    z[4,1,2]  R755      5.6447625160217285e-02
    z[4,1,2]  R756      2.0022470504045486e-02
    z[4,1,2]  R757      1.3306963443756104e-01
    z[4,1,2]  R758      -1.9731815159320831e-01
    z[4,1,2]  R759      -5.8517616987228394e-01
    z[4,1,2]  R760      6.3593953847885132e-01
    z[4,1,2]  R761      5.4929924011230469e-01
    z[4,1,2]  R762      5.8574265241622925e-01
    z[4,1,2]  R763      4.4907850027084351e-01
    z[4,1,2]  R764      5.3506422042846680e-01
    z[4,1,2]  R765      -4.1943371295928955e-01
    z[4,1,2]  R766      -3.1705504655838013e-01
    z[4,1,2]  R767      -5.5717867612838745e-01
    z[4,1,2]  R768      -3.3449560403823853e-01
    z[4,1,2]  R769      -5.0315749645233154e-01
    z[4,1,2]  R770      -3.1380680203437805e-01
    z[4,1,2]  R771      1.7505396157503128e-02
    z[4,1,2]  R772      -6.4479392766952515e-01
    z[4,1,2]  R773      -5.8811032772064209e-01
    z[4,1,2]  R774      4.3414118885993958e-01
    z[4,1,2]  R775      -1.1416142433881760e-01
    z[4,1,2]  R776      -4.8208889365196228e-01
    z[4,1,2]  R777      -2.0556335151195526e-01
    z[4,1,2]  R778      7.0926159620285034e-01
    z[4,1,2]  R779      0.772919774055481
    z[4,1,2]  R780      7.5071024894714355e-01
    z[4,1,2]  R781      6.2224715948104858e-01
    z[4,1,2]  R782      7.0781558752059937e-01
    z[4,1,2]  R783      8.1125551462173462e-01
    z[4,1,2]  R784      8.3727121353149414e-01
    z[4,1,2]  R785      -6.8045049905776978e-02
    z[4,1,2]  R786      5.2481066435575485e-02
    z[4,1,2]  R787      2.3879086971282959e-01
    z[4,1,2]  R788      -2.2355543076992035e-01
    z[4,1,2]  R789      -1.0044532269239426e-01
    z[4,1,2]  R790      -5.8036994934082031e-01
    z[4,1,2]  R791      -1.7762959003448486e-01
    z[4,1,2]  R792      -3.6471266299486160e-02
    z[4,1,2]  R793      -3.6093726754188538e-01
    z[4,1,2]  R794      -3.0557924509048462e-01
    z[4,1,2]  R795      -1.9537086784839630e-01
    z[4,1,2]  R796      -1.2592333555221558e-01
    z[4,1,2]  R797      2.4499481916427612e-01
    z[4,1,2]  R798      -1.9908134639263153e-01
    z[4,1,2]  R799      -5.0699585676193237e-01
    z[4,1,2]  R800      3.3400547504425049e-01
    z[4,1,2]  R801      1.7254938185214996e-01
    z[4,1,2]  R802      -2.0253041386604309e-01
    z[4,1,2]  R803      -3.6949047446250916e-01
    z[4,1,2]  R804      -7.6224929094314575e-01
    z[4,1,2]  R805      5.7550603523850441e-03
    z[4,1,2]  R806      6.9921833276748657e-01
    z[4,1,2]  R807      3.4651690721511841e-01
    z[4,1,3]  R14       1
    z[4,1,3]  R41       -1
    z[4,1,3]  R737      -1
    z[4,1,3]  R738      1
    z[4,1,3]  R745      1.9407291710376740e-01
    z[4,1,3]  R746      3.7785834074020386e-01
    z[4,1,3]  R747      0.359621524810791
    z[4,1,3]  R748      3.5334849357604980e-01
    z[4,1,3]  R749      -5.9966671466827393e-01
    z[4,1,3]  R750      3.5166677832603455e-01
    z[4,1,3]  R751      -1.7718973755836487e-01
    z[4,1,3]  R752      -1.7114609479904175e-01
    z[4,1,3]  R753      1.0475947707891464e-01
    z[4,1,3]  R754      -1.4726942777633667e-01
    z[4,1,3]  R755      -7.2947158478200436e-03
    z[4,1,3]  R756      9.5679499208927155e-02
    z[4,1,3]  R757      3.3502838015556335e-01
    z[4,1,3]  R758      -1.4262425899505615e-01
    z[4,1,3]  R759      3.4569406509399414e-01
    z[4,1,3]  R760      -1.8511952459812164e-01
    z[4,1,3]  R761      1.8296670913696289e-01
    z[4,1,3]  R762      2.8348726034164429e-01
    z[4,1,3]  R763      -1.3576443493366241e-01
    z[4,1,3]  R764      1.6956056654453278e-01
    z[4,1,3]  R765      -4.3668370693922043e-02
    z[4,1,3]  R766      2.3234169185161591e-01
    z[4,1,3]  R767      4.1011381894350052e-02
    z[4,1,3]  R768      3.1981386244297028e-02
    z[4,1,3]  R769      0.309207946062088
    z[4,1,3]  R770      3.5993787646293640e-01
    z[4,1,3]  R771      5.1507014036178589e-01
    z[4,1,3]  R772      -3.3113643527030945e-01
    z[4,1,3]  R773      -0.296572744846344
    z[4,1,3]  R774      -1.6149322688579559e-01
    z[4,1,3]  R775      2.6683533191680908e-01
    z[4,1,3]  R776      -2.6365929841995239e-01
    z[4,1,3]  R777      -1.7282043397426605e-01
    z[4,1,3]  R778      -9.6074566245079041e-02
    z[4,1,3]  R779      2.1486331522464752e-01
    z[4,1,3]  R780      3.2078996300697327e-01
    z[4,1,3]  R781      1.3732829689979553e-01
    z[4,1,3]  R782      -4.2660561203956604e-01
    z[4,1,3]  R783      1.1336320638656616e-01
    z[4,1,3]  R784      -1.7726014554500580e-01
    z[4,1,3]  R785      -1.6869869828224182e-01
    z[4,1,3]  R786      1.1771301925182343e-01
    z[4,1,3]  R787      -7.7181234955787659e-02
    z[4,1,3]  R788      -2.7676156163215637e-01
    z[4,1,3]  R789      2.1508021652698517e-01
    z[4,1,3]  R790      9.7305081784725189e-02
    z[4,1,3]  R791      0.0887034460902214
    z[4,1,3]  R792      3.4676992893218994e-01
    z[4,1,3]  R793      2.7455356717109680e-01
    z[4,1,3]  R794      4.8621648550033569e-01
    z[4,1,3]  R795      -4.0148496627807617e-03
    z[4,1,3]  R796      2.8074583411216736e-01
    z[4,1,3]  R797      1.6979804635047913e-01
    z[4,1,3]  R798      3.2959511876106262e-01
    z[4,1,3]  R799      -8.2395315170288086e-02
    z[4,1,3]  R800      1.8020935356616974e-02
    z[4,1,3]  R801      -2.4140359461307526e-01
    z[4,1,3]  R802      5.4319225251674652e-02
    z[4,1,3]  R803      7.3736339807510376e-02
    z[4,1,3]  R804      3.0708810687065125e-01
    z[4,1,3]  R805      1.3325117528438568e-02
    z[4,1,3]  R806      -2.1088348329067230e-01
    z[4,1,3]  R807      1.6426447033882141e-01
    z[4,1,4]  R15       1
    z[4,1,4]  R42       -1
    z[4,1,4]  R739      -1
    z[4,1,4]  R740      1
    z[4,1,4]  R745      -5.3325051069259644e-01
    z[4,1,4]  R746      3.5291498899459839e-01
    z[4,1,4]  R747      -7.4833756685256958e-01
    z[4,1,4]  R748      9.6530608832836151e-02
    z[4,1,4]  R749      1.3895675539970398e-01
    z[4,1,4]  R750      2.2054056823253632e-01
    z[4,1,4]  R751      -2.8322175145149231e-01
    z[4,1,4]  R752      1.1401998996734619e-01
    z[4,1,4]  R753      -1.3707152009010315e-01
    z[4,1,4]  R754      4.4733222573995590e-02
    z[4,1,4]  R755      2.6117414236068726e-01
    z[4,1,4]  R756      4.9561902880668640e-01
    z[4,1,4]  R757      0.406207412481308
    z[4,1,4]  R758      -3.5524827241897583e-01
    z[4,1,4]  R759      3.7169721722602844e-01
    z[4,1,4]  R760      -3.1640312075614929e-01
    z[4,1,4]  R761      -4.2178431153297424e-01
    z[4,1,4]  R762      -2.5168126821517944e-01
    z[4,1,4]  R763      -4.4645896553993225e-01
    z[4,1,4]  R764      -3.5246381163597107e-01
    z[4,1,4]  R765      0.280819296836853
    z[4,1,4]  R766      4.3981426954269409e-01
    z[4,1,4]  R767      4.0599894709885120e-03
    z[4,1,4]  R768      -4.7642147541046143e-01
    z[4,1,4]  R769      2.0234338939189911e-01
    z[4,1,4]  R770      5.0732856988906860e-01
    z[4,1,4]  R771      -2.6159477233886719e-01
    z[4,1,4]  R772      1.0549803078174591e-01
    z[4,1,4]  R773      3.7096962332725525e-01
    z[4,1,4]  R774      -4.3181905150413513e-01
    z[4,1,4]  R775      1.6442857682704926e-01
    z[4,1,4]  R776      4.8693239688873291e-01
    z[4,1,4]  R777      6.7832469940185547e-02
    z[4,1,4]  R778      2.7059277892112732e-01
    z[4,1,4]  R779      -3.8322050124406815e-02
    z[4,1,4]  R780      1.9262421131134033e-01
    z[4,1,4]  R781      -1.2879092991352081e-01
    z[4,1,4]  R782      -1.4227072894573212e-01
    z[4,1,4]  R783      9.5168747007846832e-02
    z[4,1,4]  R784      -1.1875925958156586e-01
    z[4,1,4]  R785      3.0272430181503296e-01
    z[4,1,4]  R786      1.7969278991222382e-01
    z[4,1,4]  R787      1.8295511603355408e-01
    z[4,1,4]  R788      2.5637738406658173e-02
    z[4,1,4]  R789      3.8580101728439331e-01
    z[4,1,4]  R790      3.0356483533978462e-02
    z[4,1,4]  R791      -6.0467068105936050e-02
    z[4,1,4]  R792      2.6015114784240723e-01
    z[4,1,4]  R793      -1.6977331042289734e-01
    z[4,1,4]  R794      2.5859564542770386e-01
    z[4,1,4]  R795      8.3201992511749268e-01
    z[4,1,4]  R796      -8.2185596227645874e-01
    z[4,1,4]  R797      -6.2639784812927246e-01
    z[4,1,4]  R798      -2.4580799043178558e-01
    z[4,1,4]  R799      4.6386823058128357e-01
    z[4,1,4]  R800      -6.9450271129608154e-01
    z[4,1,4]  R801      4.4686034321784973e-01
    z[4,1,4]  R802      6.2149971723556519e-01
    z[4,1,4]  R803      -5.8028399944305420e-01
    z[4,1,4]  R804      2.3789599537849426e-02
    z[4,1,4]  R805      8.4485846757888794e-01
    z[4,1,4]  R806      2.5438550114631653e-01
    z[4,1,4]  R807      -4.7681885957717896e-01
    z[4,1,5]  R16       1
    z[4,1,5]  R43       -1
    z[4,1,5]  R741      -1
    z[4,1,5]  R742      1
    z[4,1,5]  R745      6.5626579523086548e-01
    z[4,1,5]  R746      6.6537988185882568e-01
    z[4,1,5]  R747      3.3398557454347610e-02
    z[4,1,5]  R748      -5.4162133485078812e-02
    z[4,1,5]  R749      4.6772268414497375e-01
    z[4,1,5]  R750      1.5188623964786530e-01
    z[4,1,5]  R751      -1.6468483209609985e-01
    z[4,1,5]  R752      5.0029838085174561e-01
    z[4,1,5]  R753      -1.1389130959287286e-03
    z[4,1,5]  R754      -5.6748535484075546e-02
    z[4,1,5]  R755      -6.2615203857421875e-01
    z[4,1,5]  R756      1.6065572202205658e-01
    z[4,1,5]  R757      6.4777636528015137e-01
    z[4,1,5]  R758      -5.0720870494842529e-01
    z[4,1,5]  R759      -3.6588084697723389e-01
    z[4,1,5]  R760      7.4011576361954212e-03
    z[4,1,5]  R761      -1.0231139510869980e-01
    z[4,1,5]  R762      -3.2818627357482910e-01
    z[4,1,5]  R763      -3.0741935968399048e-01
    z[4,1,5]  R764      -4.0899041295051575e-01
    z[4,1,5]  R765      1.0906521230936050e-01
    z[4,1,5]  R766      2.3966281116008759e-01
    z[4,1,5]  R767      3.5929358005523682e-01
    z[4,1,5]  R768      3.1823945045471191e-01
    z[4,1,5]  R769      2.2841575741767883e-01
    z[4,1,5]  R770      -3.8880008459091187e-01
    z[4,1,5]  R771      3.3971187472343445e-01
    z[4,1,5]  R772      5.5800056457519531e-01
    z[4,1,5]  R773      3.8121134042739868e-01
    z[4,1,5]  R774      5.7679861783981323e-01
    z[4,1,5]  R775      -1.6769881546497345e-01
    z[4,1,5]  R776      -3.3462487161159515e-02
    z[4,1,5]  R777      8.8889855146408081e-01
    z[4,1,5]  R778      -2.6256833225488663e-02
    z[4,1,5]  R779      1.5315471589565277e-01
    z[4,1,5]  R780      -2.9874238371849060e-01
    z[4,1,5]  R781      -5.6345868110656738e-01
    z[4,1,5]  R782      9.4821535050868988e-02
    z[4,1,5]  R783      0.296827495098114
    z[4,1,5]  R784      -4.5416764914989471e-02
    z[4,1,5]  R785      -1.4519900083541870e-02
    z[4,1,5]  R786      3.0179911851882935e-01
    z[4,1,5]  R787      -9.4601154327392578e-02
    z[4,1,5]  R788      -5.4586249589920044e-01
    z[4,1,5]  R789      -6.1169409751892090e-01
    z[4,1,5]  R790      -1.9058316946029663e-01
    z[4,1,5]  R791      4.1480389237403870e-01
    z[4,1,5]  R792      -1.7482955753803253e-01
    z[4,1,5]  R793      1.8879230320453644e-01
    z[4,1,5]  R794      6.7648209631443024e-02
    z[4,1,5]  R795      4.7131654620170593e-01
    z[4,1,5]  R796      -3.4881058335304260e-01
    z[4,1,5]  R797      -0.663200855255127
    z[4,1,5]  R798      -4.2663764953613281e-01
    z[4,1,5]  R799      2.8599733114242554e-01
    z[4,1,5]  R800      -1.9886104762554169e-01
    z[4,1,5]  R801      -7.7556155622005463e-02
    z[4,1,5]  R802      6.6100579500198364e-01
    z[4,1,5]  R803      1.8605035543441772e-01
    z[4,1,5]  R804      0.519503653049469
    z[4,1,5]  R805      3.5062929987907410e-01
    z[4,1,5]  R806      -2.4049113690853119e-01
    z[4,1,5]  R807      4.2587769031524658e-01
    z[4,1,6]  R17       1
    z[4,1,6]  R44       -1
    z[4,1,6]  R743      -1
    z[4,1,6]  R744      1
    z[4,1,6]  R745      9.7905740141868591e-02
    z[4,1,6]  R746      4.9548465758562088e-02
    z[4,1,6]  R747      -2.7058309316635132e-01
    z[4,1,6]  R748      7.8890067338943481e-01
    z[4,1,6]  R749      -2.9685431718826294e-01
    z[4,1,6]  R750      -4.8208922147750854e-01
    z[4,1,6]  R751      -7.2780676186084747e-02
    z[4,1,6]  R752      2.2448913753032684e-01
    z[4,1,6]  R753      -3.6659315228462219e-01
    z[4,1,6]  R754      3.4811830520629883e-01
    z[4,1,6]  R755      -1.2709483504295349e-01
    z[4,1,6]  R756      -2.7647811919450760e-02
    z[4,1,6]  R757      1.4032294973731041e-02
    z[4,1,6]  R758      8.1678237766027451e-03
    z[4,1,6]  R759      1.7205484211444855e-02
    z[4,1,6]  R760      2.7510038018226624e-01
    z[4,1,6]  R761      -1.1160384118556976e-01
    z[4,1,6]  R762      5.5536616593599319e-02
    z[4,1,6]  R763      0.102850541472435
    z[4,1,6]  R764      -0.169743612408638
    z[4,1,6]  R765      2.2508314251899719e-01
    z[4,1,6]  R766      5.0840977579355240e-02
    z[4,1,6]  R767      -3.4815722703933716e-01
    z[4,1,6]  R768      1.5809737145900726e-02
    z[4,1,6]  R769      2.1920089423656464e-01
    z[4,1,6]  R770      -5.2649658173322678e-02
    z[4,1,6]  R771      3.3853590488433838e-01
    z[4,1,6]  R772      -1.3766942918300629e-01
    z[4,1,6]  R773      -3.5886257886886597e-01
    z[4,1,6]  R774      2.4111849069595337e-01
    z[4,1,6]  R775      9.4328567385673523e-02
    z[4,1,6]  R776      -3.5025981068611145e-01
    z[4,1,6]  R777      -5.4601531475782394e-02
    z[4,1,6]  R778      -1.1535544693470001e-01
    z[4,1,6]  R779      3.6942100524902344e-01
    z[4,1,6]  R780      1.6169679164886475e-01
    z[4,1,6]  R781      2.3860198259353638e-01
    z[4,1,6]  R782      -3.7413170933723450e-01
    z[4,1,6]  R783      -4.1099029779434204e-01
    z[4,1,6]  R784      4.0998399257659912e-01
    z[4,1,6]  R785      0.154539555311203
    z[4,1,6]  R786      2.4185986816883087e-01
    z[4,1,6]  R787      -3.9707425236701965e-01
    z[4,1,6]  R788      -3.1361716985702515e-01
    z[4,1,6]  R789      -3.6338892579078674e-01
    z[4,1,6]  R790      -1.8524931371212006e-01
    z[4,1,6]  R791      7.5806602835655212e-02
    z[4,1,6]  R792      -1.5545448660850525e-01
    z[4,1,6]  R793      -4.1842922568321228e-01
    z[4,1,6]  R794      -3.4202453494071960e-01
    z[4,1,6]  R795      1.0799054801464081e-01
    z[4,1,6]  R796      6.9016069173812866e-02
    z[4,1,6]  R797      1.8315553665161133e-01
    z[4,1,6]  R798      6.1327970027923584e-01
    z[4,1,6]  R799      -7.9011484980583191e-02
    z[4,1,6]  R800      0.0741225853562355
    z[4,1,6]  R801      -1.9100518897175789e-02
    z[4,1,6]  R802      2.1752619743347168e-01
    z[4,1,6]  R803      -2.7648079395294189e-01
    z[4,1,6]  R804      -7.9037941992282867e-02
    z[4,1,6]  R805      -1.6159781813621521e-01
    z[4,1,6]  R806      4.9513506889343262e-01
    z[4,1,6]  R807      -3.0760830640792847e-01
    z[2,3,0]  R20       -1
    z[2,3,0]  R29       1
    z[2,3,0]  R808      -1
    z[2,3,0]  R809      1
    z[2,3,0]  R822      -3.9224180579185486e-01
    z[2,3,0]  R823      -3.5216581821441650e-01
    z[2,3,0]  R824      0.797160267829895
    z[2,3,0]  R825      -4.2389002442359924e-01
    z[2,3,0]  R826      6.8974149227142334e-01
    z[2,3,0]  R827      7.9577147960662842e-01
    z[2,3,0]  R828      -6.8320196866989136e-01
    z[2,3,0]  R829      7.5881582498550415e-01
    z[2,3,0]  R830      6.3608884811401367e-01
    z[2,3,0]  R831      7.3341244459152222e-01
    z[2,3,0]  R832      -8.1882697343826294e-01
    z[2,3,0]  R833      3.5091996192932129e-01
    z[2,3,0]  R834      8.4362350404262543e-02
    z[2,3,0]  R835      -7.2980821132659912e-01
    z[2,3,0]  R836      1.9111198186874390e-01
    z[2,3,0]  R837      -1.4493685960769653e-01
    z[2,3,0]  R838      -1.6609892249107361e-01
    z[2,3,0]  R839      -5.5685228109359741e-01
    z[2,3,0]  R840      0.319084495306015
    z[2,3,0]  R841      -6.5375095605850220e-01
    z[2,3,0]  R842      -7.2028857469558716e-01
    z[2,3,0]  R843      -7.1874296665191650e-01
    z[2,3,0]  R844      -0.296962708234787
    z[2,3,0]  R845      -7.2221815586090088e-01
    z[2,3,0]  R846      -0.374138206243515
    z[2,3,0]  R847      -7.7556854486465454e-01
    z[2,3,0]  R848      -7.4139153957366943e-01
    z[2,3,0]  R849      -3.9027959108352661e-02
    z[2,3,0]  R850      3.6240735650062561e-01
    z[2,3,0]  R851      -6.0498553514480591e-01
    z[2,3,0]  R852      -1.0302574932575226e-01
    z[2,3,0]  R853      -5.9329774230718613e-02
    z[2,3,0]  R854      -3.0037942528724670e-01
    z[2,3,0]  R855      -0.743958592414856
    z[2,3,0]  R856      -7.8501778841018677e-01
    z[2,3,0]  R857      -7.5105243921279907e-01
    z[2,3,0]  R858      -5.6015497446060181e-01
    z[2,3,0]  R859      -8.9161342382431030e-01
    z[2,3,0]  R860      -5.9007924795150757e-01
    z[2,3,0]  R861      -8.1120771169662476e-01
    z[2,3,0]  R862      -7.1645969152450562e-01
    z[2,3,0]  R863      -6.8813055753707886e-01
    z[2,3,0]  R864      -4.4439971446990967e-01
    z[2,3,0]  R865      -3.7683433294296265e-01
    z[2,3,0]  R866      -3.2920166850090027e-01
    z[2,3,0]  R867      -7.2472792863845825e-01
    z[2,3,0]  R868      4.9414688348770142e-01
    z[2,3,0]  R869      4.4974252581596375e-01
    z[2,3,0]  R870      9.6794553101062775e-02
    z[2,3,0]  R871      -4.8676044680178165e-03
    z[2,3,0]  R872      -2.4586421251296997e-01
    z[2,3,0]  R873      1.1634296923875809e-01
    z[2,3,0]  R874      0.600662350654602
    z[2,3,0]  R875      2.7329126000404358e-01
    z[2,3,0]  R876      6.2698286771774292e-01
    z[2,3,0]  R877      2.1078411489725113e-02
    z[2,3,0]  R878      2.4044297635555267e-01
    z[2,3,0]  R879      -3.8858661055564880e-01
    z[2,3,0]  R880      -4.6192719601094723e-03
    z[2,3,0]  R881      5.2527695894241333e-01
    z[2,3,0]  R882      -6.3333630561828613e-01
    z[2,3,0]  R883      4.8260340094566345e-01
    z[2,3,0]  R884      -6.0316592454910278e-01
    z[2,3,0]  R885      3.4032773971557617e-01
    z[2,3,0]  R886      2.0777510106563568e-01
    z[2,3,0]  R887      -3.5108034498989582e-03
    z[2,3,0]  R888      4.8921483755111694e-01
    z[2,3,0]  R889      -9.1450080275535583e-02
    z[2,3,0]  R890      2.1135492622852325e-01
    z[2,3,0]  R891      2.4746231734752655e-01
    z[2,3,0]  R892      -1.0800433158874512e-01
    z[2,3,0]  R893      -4.7529187798500061e-01
    z[2,3,0]  R894      -0.620422899723053
    z[2,3,0]  R895      -8.1994032859802246e-01
    z[2,3,0]  R896      2.0614795386791229e-01
    z[2,3,0]  R897      -7.1798115968704224e-02
    z[2,3,0]  R898      2.6360219717025757e-01
    z[2,3,0]  R899      1.6038280725479126e-01
    z[2,3,0]  R900      6.0919380187988281e-01
    z[2,3,0]  R901      7.2385388612747192e-01
    z[2,3,0]  R902      1.2302646785974503e-01
    z[2,3,0]  R903      3.9639464020729065e-01
    z[2,3,0]  R904      -4.4419410824775696e-01
    z[2,3,0]  R905      -3.4195578098297119e-01
    z[2,3,0]  R906      -4.2483130097389221e-01
    z[2,3,0]  R907      -4.7725465893745422e-01
    z[2,3,0]  R908      -1.1169387027621269e-02
    z[2,3,0]  R909      2.6945248246192932e-01
    z[2,3,0]  R910      1.1034189164638519e-01
    z[2,3,0]  R911      -1.4272119104862213e-01
    z[2,3,0]  R912      -6.6784307360649109e-02
    z[2,3,0]  R913      4.2604845762252808e-01
    z[2,3,0]  R914      3.7830349802970886e-01
    z[2,3,0]  R915      4.3023020029067993e-01
    z[2,3,0]  R916      4.3663305044174194e-01
    z[2,3,0]  R917      -3.4835276007652283e-01
    z[2,3,0]  R918      -3.6363103985786438e-01
    z[2,3,0]  R919      7.8226590156555176e-01
    z[2,3,0]  R920      6.4075648784637451e-01
    z[2,3,0]  R921      6.8611931800842285e-01
    z[2,3,0]  R922      -1.6029927134513855e-01
    z[2,3,0]  R923      4.0806140750646591e-02
    z[2,3,0]  R924      -2.8304606676101685e-01
    z[2,3,0]  R925      -5.8769184350967407e-01
    z[2,3,0]  R926      6.7144066095352173e-01
    z[2,3,0]  R927      0.865686297416687
    z[2,3,0]  R928      6.8237137794494629e-01
    z[2,3,0]  R929      8.3832150697708130e-01
    z[2,3,0]  R930      8.1652325391769409e-01
    z[2,3,0]  R931      6.7006939649581909e-01
    z[2,3,1]  R21       -1
    z[2,3,1]  R30       1
    z[2,3,1]  R810      -1
    z[2,3,1]  R811      1
    z[2,3,1]  R822      1.6793204471468925e-02
    z[2,3,1]  R823      4.1982802748680115e-01
    z[2,3,1]  R824      -3.0217638611793518e-01
    z[2,3,1]  R825      3.3735528588294983e-01
    z[2,3,1]  R826      -2.1396717429161072e-01
    z[2,3,1]  R827      -1.4922298491001129e-01
    z[2,3,1]  R828      -4.6211519837379456e-01
    z[2,3,1]  R829      -2.4508625268936157e-01
    z[2,3,1]  R830      -1.8263725936412811e-01
    z[2,3,1]  R831      -2.3488880693912506e-01
    z[2,3,1]  R832      -1.6358684003353119e-01
    z[2,3,1]  R833      5.3442692756652832e-01
    z[2,3,1]  R834      5.0623804330825806e-01
    z[2,3,1]  R835      4.6645689010620117e-01
    z[2,3,1]  R836      6.5295898914337158e-01
    z[2,3,1]  R837      -9.4652932882308960e-01
    z[2,3,1]  R838      -0.909305214881897
    z[2,3,1]  R839      6.1326795816421509e-01
    z[2,3,1]  R840      5.5151903629302979e-01
    z[2,3,1]  R841      4.0061524510383606e-01
    z[2,3,1]  R842      -0.264529287815094
    z[2,3,1]  R843      -1.4760753512382507e-01
    z[2,3,1]  R844      7.9781192541122437e-01
    z[2,3,1]  R845      -1.7197097837924957e-01
    z[2,3,1]  R846      1.4941245317459106e-01
    z[2,3,1]  R847      4.4548544287681580e-01
    z[2,3,1]  R848      0.653929591178894
    z[2,3,1]  R849      4.0577349066734314e-01
    z[2,3,1]  R850      -3.6976438760757446e-01
    z[2,3,1]  R851      -6.7304052412509918e-02
    z[2,3,1]  R852      4.9294161796569824e-01
    z[2,3,1]  R853      3.5584241151809692e-01
    z[2,3,1]  R854      3.9754968881607056e-01
    z[2,3,1]  R855      1.6869686543941498e-02
    z[2,3,1]  R856      7.1616090834140778e-02
    z[2,3,1]  R857      2.5303310155868530e-01
    z[2,3,1]  R858      -1.7502473667263985e-02
    z[2,3,1]  R859      6.7946580238640308e-03
    z[2,3,1]  R860      -4.3117246031761169e-01
    z[2,3,1]  R861      3.8872316479682922e-01
    z[2,3,1]  R862      -1.3841395080089569e-01
    z[2,3,1]  R863      -4.6720635145902634e-02
    z[2,3,1]  R864      5.3251668810844421e-02
    z[2,3,1]  R865      3.9715209603309631e-01
    z[2,3,1]  R866      -2.7576866745948792e-01
    z[2,3,1]  R867      4.9373021721839905e-01
    z[2,3,1]  R868      -5.0862950086593628e-01
    z[2,3,1]  R869      -4.7206935286521912e-01
    z[2,3,1]  R870      -9.2534351348876953e-01
    z[2,3,1]  R871      -9.3733829259872437e-01
    z[2,3,1]  R872      5.0692892074584961e-01
    z[2,3,1]  R873      5.6872403621673584e-01
    z[2,3,1]  R874      -5.3618443012237549e-01
    z[2,3,1]  R875      -6.4487606287002563e-01
    z[2,3,1]  R876      -3.6818471550941467e-01
    z[2,3,1]  R877      -7.2963792085647583e-01
    z[2,3,1]  R878      -8.2487720251083374e-01
    z[2,3,1]  R879      7.6968425512313843e-01
    z[2,3,1]  R880      -7.7254432439804077e-01
    z[2,3,1]  R881      -2.3884780704975128e-01
    z[2,3,1]  R882      3.0962151288986206e-01
    z[2,3,1]  R883      -5.0188940763473511e-01
    z[2,3,1]  R884      -9.2821039259433746e-02
    z[2,3,1]  R885      -2.9327511787414551e-01
    z[2,3,1]  R886      -0.954384446144104
    z[2,3,1]  R887      -8.4556078910827637e-01
    z[2,3,1]  R888      -1.5219414234161377e-01
    z[2,3,1]  R889      -8.5327720642089844e-01
    z[2,3,1]  R890      -8.0013388395309448e-01
    z[2,3,1]  R891      -0.837171733379364
    z[2,3,1]  R892      5.9243518114089966e-01
    z[2,3,1]  R893      5.3607380390167236e-01
    z[2,3,1]  R894      5.0177198648452759e-01
    z[2,3,1]  R895      -4.3665003776550293e-01
    z[2,3,1]  R896      -9.2628234624862671e-01
    z[2,3,1]  R897      -8.7773799896240234e-01
    z[2,3,1]  R898      9.4409698247909546e-01
    z[2,3,1]  R899      9.3283069133758545e-01
    z[2,3,1]  R900      4.4027809053659439e-02
    z[2,3,1]  R901      -4.1449481248855591e-01
    z[2,3,1]  R902      3.5636723041534424e-01
    z[2,3,1]  R903      1.4859323203563690e-01
    z[2,3,1]  R904      4.9766483902931213e-01
    z[2,3,1]  R905      -2.0866273343563080e-01
    z[2,3,1]  R906      0.191564679145813
    z[2,3,1]  R907      1.2885032594203949e-01
    z[2,3,1]  R908      -1.8866440653800964e-01
    z[2,3,1]  R909      -2.2225941717624664e-01
    z[2,3,1]  R910      -2.5352746248245239e-01
    z[2,3,1]  R911      -1.8692450225353241e-01
    z[2,3,1]  R912      -9.0078812837600708e-01
    z[2,3,1]  R913      -6.3910853862762451e-01
    z[2,3,1]  R914      -8.7422186136245728e-01
    z[2,3,1]  R915      -8.1641918420791626e-01
    z[2,3,1]  R916      2.1426524221897125e-01
    z[2,3,1]  R917      4.7654518485069275e-01
    z[2,3,1]  R918      3.5593998432159424e-01
    z[2,3,1]  R919      -1.8441970646381378e-01
    z[2,3,1]  R920      -2.9422175884246826e-01
    z[2,3,1]  R921      -1.8421749770641327e-01
    z[2,3,1]  R922      0.215898334980011
    z[2,3,1]  R923      7.7527087926864624e-01
    z[2,3,1]  R924      6.9777315855026245e-01
    z[2,3,1]  R925      -2.1259206533432007e-01
    z[2,3,1]  R926      -2.4626728892326355e-01
    z[2,3,1]  R927      -1.0118196159601212e-01
    z[2,3,1]  R928      -1.8070322275161743e-01
    z[2,3,1]  R929      -7.5816445052623749e-02
    z[2,3,1]  R930      -1.8228402733802795e-01
    z[2,3,1]  R931      -5.8117534965276718e-02
    z[2,3,2]  R22       -1
    z[2,3,2]  R31       1
    z[2,3,2]  R812      -1
    z[2,3,2]  R813      1
    z[2,3,2]  R822      5.3428955376148224e-02
    z[2,3,2]  R823      4.7465705871582031e-01
    z[2,3,2]  R824      3.6648120731115341e-02
    z[2,3,2]  R825      0.377734899520874
    z[2,3,2]  R826      6.5484158694744110e-02
    z[2,3,2]  R827      -1.2441141903400421e-01
    z[2,3,2]  R828      2.5291427969932556e-01
    z[2,3,2]  R829      -2.6075729727745056e-01
    z[2,3,2]  R830      -2.3586069047451019e-01
    z[2,3,2]  R831      2.9757454991340637e-01
    z[2,3,2]  R832      1.2146435678005219e-01
    z[2,3,2]  R833      -4.2763182520866394e-01
    z[2,3,2]  R834      0.0552813895046711
    z[2,3,2]  R835      -3.2051667571067810e-01
    z[2,3,2]  R836      -5.6332081556320190e-01
    z[2,3,2]  R837      4.8455204814672470e-02
    z[2,3,2]  R838      2.8371301293373108e-01
    z[2,3,2]  R839      -2.1615797281265259e-01
    z[2,3,2]  R840      -3.4118276834487915e-01
    z[2,3,2]  R841      -4.3730372190475464e-01
    z[2,3,2]  R842      4.1211673617362976e-01
    z[2,3,2]  R843      4.9223366379737854e-01
    z[2,3,2]  R844      -1.7958946526050568e-02
    z[2,3,2]  R845      4.7048786282539368e-01
    z[2,3,2]  R846      -3.8058489561080933e-01
    z[2,3,2]  R847      -3.2974272966384888e-01
    z[2,3,2]  R848      5.8110468089580536e-02
    z[2,3,2]  R849      -1.9358810782432556e-01
    z[2,3,2]  R850      -6.7814439535140991e-01
    z[2,3,2]  R851      -0.0276302732527256
    z[2,3,2]  R852      -1.1719395220279694e-01
    z[2,3,2]  R853      -9.6887126564979553e-02
    z[2,3,2]  R854      3.9203721284866333e-01
    z[2,3,2]  R855      -9.0094834566116333e-02
    z[2,3,2]  R856      4.0363538265228271e-01
    z[2,3,2]  R857      2.3727929592132568e-01
    z[2,3,2]  R858      3.7829467654228210e-01
    z[2,3,2]  R859      2.0727132260799408e-01
    z[2,3,2]  R860      -3.5161191225051880e-01
    z[2,3,2]  R861      -1.8203815817832947e-01
    z[2,3,2]  R862      5.9477311372756958e-01
    z[2,3,2]  R863      3.3852979540824890e-01
    z[2,3,2]  R864      0.564498245716095
    z[2,3,2]  R865      -3.1396320462226868e-01
    z[2,3,2]  R866      1.2137076258659363e-01
    z[2,3,2]  R867      -3.5435834527015686e-01
    z[2,3,2]  R868      -0.539020299911499
    z[2,3,2]  R869      -2.3951514065265656e-01
    z[2,3,2]  R870      1.6637371480464935e-01
    z[2,3,2]  R871      -6.2574379146099091e-02
    z[2,3,2]  R872      1.5445311367511749e-01
    z[2,3,2]  R873      -3.8655731081962585e-01
    z[2,3,2]  R874      -2.5803402066230774e-01
    z[2,3,2]  R875      -5.0074491649866104e-02
    z[2,3,2]  R876      -1.7812184989452362e-01
    z[2,3,2]  R877      6.3637781143188477e-01
    z[2,3,2]  R878      4.4004756212234497e-01
    z[2,3,2]  R879      -3.7844008207321167e-01
    z[2,3,2]  R880      4.7437658905982971e-01
    z[2,3,2]  R881      -1.9614732265472412e-01
    z[2,3,2]  R882      2.9345509409904480e-01
    z[2,3,2]  R883      1.8945498391985893e-02
    z[2,3,2]  R884      -2.8382557630538940e-01
    z[2,3,2]  R885      -7.5607880949974060e-02
    z[2,3,2]  R886      4.0291804820299149e-02
    z[2,3,2]  R887      -3.9303341507911682e-01
    z[2,3,2]  R888      2.5031521916389465e-01
    z[2,3,2]  R889      3.0954939126968384e-01
    z[2,3,2]  R890      2.4709241092205048e-01
    z[2,3,2]  R891      -1.3379940390586853e-01
    z[2,3,2]  R892      0.374731183052063
    z[2,3,2]  R893      -2.3399564623832703e-01
    z[2,3,2]  R894      -1.5763019025325775e-01
    z[2,3,2]  R895      -2.4272593855857849e-01
    z[2,3,2]  R896      1.6245366632938385e-01
    z[2,3,2]  R897      -2.3109002411365509e-01
    z[2,3,2]  R898      5.0432592630386353e-02
    z[2,3,2]  R899      1.3996334373950958e-01
    z[2,3,2]  R900      0.632743239402771
    z[2,3,2]  R901      -1.8757671117782593e-01
    z[2,3,2]  R902      2.5317168235778809e-01
    z[2,3,2]  R903      4.4305637478828430e-01
    z[2,3,2]  R904      -2.3154832422733307e-01
    z[2,3,2]  R905      -4.9875292181968689e-01
    z[2,3,2]  R906      -4.9246424436569214e-01
    z[2,3,2]  R907      -0.179381862282753
    z[2,3,2]  R908      0.50576251745224
    z[2,3,2]  R909      4.9431779980659485e-01
    z[2,3,2]  R910      5.8363676071166992e-01
    z[2,3,2]  R911      3.7546235322952271e-01
    z[2,3,2]  R912      -5.5164024233818054e-02
    z[2,3,2]  R913      4.6470394730567932e-01
    z[2,3,2]  R914      6.0612101107835770e-02
    z[2,3,2]  R915      1.7800678312778473e-01
    z[2,3,2]  R916      -2.4674880504608154e-01
    z[2,3,2]  R917      1.0945523530244827e-01
    z[2,3,2]  R918      2.0087005198001862e-01
    z[2,3,2]  R919      -4.0304175019264221e-01
    z[2,3,2]  R920      -4.7503703832626343e-01
    z[2,3,2]  R921      -2.3438222706317902e-01
    z[2,3,2]  R922      -4.0537121891975403e-01
    z[2,3,2]  R923      -2.3900006711483002e-01
    z[2,3,2]  R924      3.1247567385435104e-02
    z[2,3,2]  R925      5.2226681262254715e-02
    z[2,3,2]  R926      -3.5896146297454834e-01
    z[2,3,2]  R927      -1.0460843890905380e-01
    z[2,3,2]  R928      -3.1134307384490967e-01
    z[2,3,2]  R929      -1.2013496458530426e-01
    z[2,3,2]  R930      -2.0758289098739624e-01
    z[2,3,2]  R931      -2.4450413882732391e-01
    z[2,3,3]  R23       -1
    z[2,3,3]  R32       1
    z[2,3,3]  R814      -1
    z[2,3,3]  R815      1
    z[2,3,3]  R822      -5.7658666372299194e-01
    z[2,3,3]  R823      -4.8413532972335815e-01
    z[2,3,3]  R824      5.0298297405242920e-01
    z[2,3,3]  R825      -3.8413512706756592e-01
    z[2,3,3]  R826      6.3380491733551025e-01
    z[2,3,3]  R827      4.7572395205497742e-01
    z[2,3,3]  R828      -4.7816762328147888e-01
    z[2,3,3]  R829      4.1079682111740112e-01
    z[2,3,3]  R830      6.8301928043365479e-01
    z[2,3,3]  R831      4.1419026255607605e-01
    z[2,3,3]  R832      5.2072703838348389e-01
    z[2,3,3]  R833      -4.7158092260360718e-01
    z[2,3,3]  R834      -4.2060464620590210e-01
    z[2,3,3]  R835      -2.1827220916748047e-02
    z[2,3,3]  R836      -4.3719586730003357e-01
    z[2,3,3]  R837      2.4062652885913849e-01
    z[2,3,3]  R838      1.5694554895162582e-02
    z[2,3,3]  R839      4.5493260025978088e-01
    z[2,3,3]  R840      -5.2448230981826782e-01
    z[2,3,3]  R841      1.5438485145568848e-01
    z[2,3,3]  R842      -9.3475859612226486e-03
    z[2,3,3]  R843      -7.0925705134868622e-02
    z[2,3,3]  R844      -3.5661661624908447e-01
    z[2,3,3]  R845      3.1329268217086792e-01
    z[2,3,3]  R846      -7.3681735992431641e-01
    z[2,3,3]  R847      1.6105762124061584e-01
    z[2,3,3]  R848      2.0723575726151466e-03
    z[2,3,3]  R849      -8.0785721540451050e-01
    z[2,3,3]  R850      2.6825010776519775e-01
    z[2,3,3]  R851      1.4808334410190582e-01
    z[2,3,3]  R852      -5.6925994157791138e-01
    z[2,3,3]  R853      -7.7147370576858521e-01
    z[2,3,3]  R854      -5.1840478181838989e-01
    z[2,3,3]  R855      -3.9839029312133789e-01
    z[2,3,3]  R856      -1.6759096086025238e-01
    z[2,3,3]  R857      2.2435568273067474e-01
    z[2,3,3]  R858      -5.7995975017547607e-01
    z[2,3,3]  R859      -5.5508546531200409e-02
    z[2,3,3]  R860      -0.162618488073349
    z[2,3,3]  R861      -1.8966302275657654e-01
    z[2,3,3]  R862      -1.6043733060359955e-01
    z[2,3,3]  R863      -3.4989330917596817e-02
    z[2,3,3]  R864      -4.5814856886863708e-01
    z[2,3,3]  R865      -4.3502718210220337e-01
    z[2,3,3]  R866      -4.5113736391067505e-01
    z[2,3,3]  R867      -1.7009107768535614e-01
    z[2,3,3]  R868      2.9478520154953003e-01
    z[2,3,3]  R869      1.8935614824295044e-01
    z[2,3,3]  R870      2.7815201878547668e-01
    z[2,3,3]  R871      1.7314006388187408e-01
    z[2,3,3]  R872      -7.3491680622100830e-01
    z[2,3,3]  R873      -5.5577796697616577e-01
    z[2,3,3]  R874      1.8954205513000488e-01
    z[2,3,3]  R875      4.7849395871162415e-01
    z[2,3,3]  R876      6.3952714204788208e-02
    z[2,3,3]  R877      -1.4681740105152130e-01
    z[2,3,3]  R878      0.00597138237208128
    z[2,3,3]  R879      2.1508035063743591e-01
    z[2,3,3]  R880      1.8963800370693207e-01
    z[2,3,3]  R881      6.0778830200433731e-02
    z[2,3,3]  R882      -0.0553843230009079
    z[2,3,3]  R883      0.38902547955513
    z[2,3,3]  R884      2.6066571474075317e-01
    z[2,3,3]  R885      3.7355315685272217e-01
    z[2,3,3]  R886      -8.0543659627437592e-02
    z[2,3,3]  R887      2.9656881093978882e-01
    z[2,3,3]  R888      2.5672686100006104e-01
    z[2,3,3]  R889      -2.0979759097099304e-01
    z[2,3,3]  R890      7.3786050081253052e-02
    z[2,3,3]  R891      2.5442928075790405e-01
    z[2,3,3]  R892      -0.555517852306366
    z[2,3,3]  R893      -3.0220049619674683e-01
    z[2,3,3]  R894      -4.7199490666389465e-01
    z[2,3,3]  R895      -1.3955840468406677e-01
    z[2,3,3]  R896      -7.2610370814800262e-02
    z[2,3,3]  R897      -3.0861049890518188e-01
    z[2,3,3]  R898      9.9657423794269562e-02
    z[2,3,3]  R899      1.7827060818672180e-01
    z[2,3,3]  R900      -0.0658518373966217
    z[2,3,3]  R901      -2.5762474536895752e-01
    z[2,3,3]  R902      4.7430381178855896e-02
    z[2,3,3]  R903      2.8876092284917831e-02
    z[2,3,3]  R904      5.0100311636924744e-02
    z[2,3,3]  R905      -2.7720436453819275e-01
    z[2,3,3]  R906      -4.6595868468284607e-01
    z[2,3,3]  R907      -5.5398764088749886e-03
    z[2,3,3]  R908      4.4093075394630432e-01
    z[2,3,3]  R909      2.7040678262710571e-01
    z[2,3,3]  R910      7.3127579689025879e-01
    z[2,3,3]  R911      4.1562882065773010e-01
    z[2,3,3]  R912      1.2848268449306488e-01
    z[2,3,3]  R913      2.1257027983665466e-01
    z[2,3,3]  R914      -1.9541363418102264e-01
    z[2,3,3]  R915      -1.9743348658084869e-01
    z[2,3,3]  R916      -5.4969519376754761e-01
    z[2,3,3]  R917      6.3999301195144653e-01
    z[2,3,3]  R918      6.6140717267990112e-01
    z[2,3,3]  R919      3.5298663377761841e-01
    z[2,3,3]  R920      4.4309777021408081e-01
    z[2,3,3]  R921      4.6353161334991455e-01
    z[2,3,3]  R922      -3.0771313235163689e-02
    z[2,3,3]  R923      -2.6654061675071716e-01
    z[2,3,3]  R924      2.0046578347682953e-01
    z[2,3,3]  R925      4.1446754336357117e-01
    z[2,3,3]  R926      5.8468794822692871e-01
    z[2,3,3]  R927      3.7966915965080261e-01
    z[2,3,3]  R928      5.9524923563003540e-01
    z[2,3,3]  R929      4.0818822383880615e-01
    z[2,3,3]  R930      3.3546721935272217e-01
    z[2,3,3]  R931      6.5078121423721313e-01
    z[2,3,4]  R24       -1
    z[2,3,4]  R33       1
    z[2,3,4]  R816      -1
    z[2,3,4]  R817      1
    z[2,3,4]  R822      0.585985004901886
    z[2,3,4]  R823      4.5392480492591858e-01
    z[2,3,4]  R824      -4.9370858818292618e-02
    z[2,3,4]  R825      2.9065108299255371e-01
    z[2,3,4]  R826      0.0555245578289032
    z[2,3,4]  R827      -8.8652148842811584e-02
    z[2,3,4]  R828      1.3986818492412567e-01
    z[2,3,4]  R829      1.1174959689378738e-01
    z[2,3,4]  R830      -8.8005885481834412e-02
    z[2,3,4]  R831      0.0831865444779396
    z[2,3,4]  R832      -8.0534592270851135e-03
    z[2,3,4]  R833      2.4362045526504517e-01
    z[2,3,4]  R834      2.3618039488792419e-01
    z[2,3,4]  R835      -3.3481118083000183e-01
    z[2,3,4]  R836      1.1404404789209366e-01
    z[2,3,4]  R837      -1.1398802697658539e-01
    z[2,3,4]  R838      -8.5143849253654480e-02
    z[2,3,4]  R839      -1.4496196806430817e-01
    z[2,3,4]  R840      -2.6472138240933418e-02
    z[2,3,4]  R841      3.2402139902114868e-01
    z[2,3,4]  R842      1.8986824154853821e-01
    z[2,3,4]  R843      -3.4458765387535095e-01
    z[2,3,4]  R844      -1.5601888298988342e-01
    z[2,3,4]  R845      -3.3036106824874878e-01
    z[2,3,4]  R846      7.9754993319511414e-02
    z[2,3,4]  R847      2.2440824657678604e-02
    z[2,3,4]  R848      -5.4176026023924351e-03
    z[2,3,4]  R849      -8.7099701166152954e-02
    z[2,3,4]  R850      -3.8170254230499268e-01
    z[2,3,4]  R851      2.8691646456718445e-01
    z[2,3,4]  R852      0.372158020734787
    z[2,3,4]  R853      4.3288782238960266e-02
    z[2,3,4]  R854      -1.2515020370483398e-01
    z[2,3,4]  R855      9.4737574458122253e-02
    z[2,3,4]  R856      -1.8336981534957886e-01
    z[2,3,4]  R857      3.9586311578750610e-01
    z[2,3,4]  R858      -2.0542104542255402e-01
    z[2,3,4]  R859      -3.3603996038436890e-02
    z[2,3,4]  R860      2.5538778305053711e-01
    z[2,3,4]  R861      -3.2243865728378296e-01
    z[2,3,4]  R862      1.0967319458723068e-01
    z[2,3,4]  R863      2.0001262426376343e-01
    z[2,3,4]  R864      -2.1655750274658203e-01
    z[2,3,4]  R865      4.7490587830543518e-01
    z[2,3,4]  R866      -1.1311549693346024e-01
    z[2,3,4]  R867      0.269917756319046
    z[2,3,4]  R868      -6.3240818679332733e-02
    z[2,3,4]  R869      -4.9538484215736389e-01
    z[2,3,4]  R870      1.2240315973758698e-01
    z[2,3,4]  R871      1.0413980484008789e-01
    z[2,3,4]  R872      8.3759091794490814e-02
    z[2,3,4]  R873      -5.6565467268228531e-02
    z[2,3,4]  R874      -1.3234561309218407e-02
    z[2,3,4]  R875      -5.1011848449707031e-01
    z[2,3,4]  R876      -5.7242041826248169e-01
    z[2,3,4]  R877      0.0806722566485405
    z[2,3,4]  R878      2.3295298218727112e-01
    z[2,3,4]  R879      6.3670896925032139e-03
    z[2,3,4]  R880      1.4857368171215057e-01
    z[2,3,4]  R881      -7.8706592321395874e-01
    z[2,3,4]  R882      5.9010720252990723e-01
    z[2,3,4]  R883      -4.9014893174171448e-01
    z[2,3,4]  R884      3.4605216979980469e-01
    z[2,3,4]  R885      -0.784143328666687
    z[2,3,4]  R886      1.6048873960971832e-01
    z[2,3,4]  R887      -1.6336247324943542e-01
    z[2,3,4]  R888      -7.4287265539169312e-01
    z[2,3,4]  R889      2.8813734650611877e-01
    z[2,3,4]  R890      3.4640464186668396e-01
    z[2,3,4]  R891      2.3118773102760315e-01
    z[2,3,4]  R892      2.5349294766783714e-02
    z[2,3,4]  R893      5.0959908962249756e-01
    z[2,3,4]  R894      5.9191279113292694e-02
    z[2,3,4]  R895      -1.9709999859333038e-01
    z[2,3,4]  R896      2.4052542448043823e-01
    z[2,3,4]  R897      -9.3885980546474457e-02
    z[2,3,4]  R898      2.2049862891435623e-02
    z[2,3,4]  R899      1.2017721310257912e-02
    z[2,3,4]  R900      -1.8670603632926941e-01
    z[2,3,4]  R901      4.3236309289932251e-01
    z[2,3,4]  R902      0.85572350025177
    z[2,3,4]  R903      5.5156075954437256e-01
    z[2,3,4]  R904      -5.2889782190322876e-01
    z[2,3,4]  R905      2.3898379504680634e-01
    z[2,3,4]  R906      0.0794677734375
    z[2,3,4]  R907      4.9426129460334778e-01
    z[2,3,4]  R908      -7.3871716856956482e-02
    z[2,3,4]  R909      3.4427908062934875e-01
    z[2,3,4]  R910      -1.7902587354183197e-01
    z[2,3,4]  R911      -3.1540572643280029e-01
    z[2,3,4]  R912      -2.4714456498622894e-01
    z[2,3,4]  R913      -3.8467753678560257e-02
    z[2,3,4]  R914      -3.4658830612897873e-02
    z[2,3,4]  R915      -2.4372906982898712e-01
    z[2,3,4]  R916      8.9103868231177330e-03
    z[2,3,4]  R917      3.9257079362869263e-01
    z[2,3,4]  R918      -2.1384319290518761e-02
    z[2,3,4]  R919      6.7004904150962830e-02
    z[2,3,4]  R920      2.2348852455615997e-01
    z[2,3,4]  R921      3.6299028992652893e-01
    z[2,3,4]  R922      5.3707206249237061e-01
    z[2,3,4]  R923      2.9634320735931396e-01
    z[2,3,4]  R924      1.3828288018703461e-01
    z[2,3,4]  R925      -3.4940603375434875e-01
    z[2,3,4]  R926      -6.5426945686340332e-02
    z[2,3,4]  R927      -1.6886492073535919e-01
    z[2,3,4]  R928      2.1630893647670746e-01
    z[2,3,4]  R929      3.2086926698684692e-01
    z[2,3,4]  R930      9.5850922167301178e-02
    z[2,3,4]  R931      5.9840731322765350e-02
    z[2,3,5]  R25       -1
    z[2,3,5]  R34       1
    z[2,3,5]  R818      -1
    z[2,3,5]  R819      1
    z[2,3,5]  R822      4.0886640548706055e-01
    z[2,3,5]  R823      1.1239586770534515e-01
    z[2,3,5]  R824      -1.2824654579162598e-01
    z[2,3,5]  R825      4.8890876770019531e-01
    z[2,3,5]  R826      2.4667195975780487e-01
    z[2,3,5]  R827      3.0765545368194580e-01
    z[2,3,5]  R828      -1.6746150329709053e-02
    z[2,3,5]  R829      -0.0683315098285675
    z[2,3,5]  R830      1.2376486510038376e-01
    z[2,3,5]  R831      3.5071703791618347e-01
    z[2,3,5]  R832      -1.2956143915653229e-01
    z[2,3,5]  R833      -3.2415542006492615e-01
    z[2,3,5]  R834      -5.3670185804367065e-01
    z[2,3,5]  R835      1.8109139800071716e-01
    z[2,3,5]  R836      -9.8403267562389374e-02
    z[2,3,5]  R837      -2.3633357137441635e-02
    z[2,3,5]  R838      8.2218162715435028e-02
    z[2,3,5]  R839      6.8722128868103027e-02
    z[2,3,5]  R840      -1.4278912544250488e-01
    z[2,3,5]  R841      -9.1430328786373138e-02
    z[2,3,5]  R842      -6.5892316401004791e-02
    z[2,3,5]  R843      1.1503832787275314e-01
    z[2,3,5]  R844      -3.3437585830688477e-01
    z[2,3,5]  R845      1.0261550545692444e-01
    z[2,3,5]  R846      -3.5006096959114075e-01
    z[2,3,5]  R847      -1.1785305291414261e-01
    z[2,3,5]  R848      -1.3829918205738068e-01
    z[2,3,5]  R849      -3.6164256930351257e-01
    z[2,3,5]  R850      -2.0925061404705048e-01
    z[2,3,5]  R851      1.5344475209712982e-01
    z[2,3,5]  R852      -3.1367599964141846e-01
    z[2,3,5]  R853      -3.9566081017255783e-02
    z[2,3,5]  R854      -5.5153405666351318e-01
    z[2,3,5]  R855      -2.1115562319755554e-01
    z[2,3,5]  R856      -2.5290203094482422e-01
    z[2,3,5]  R857      -3.4231055527925491e-02
    z[2,3,5]  R858      -3.9365702867507935e-01
    z[2,3,5]  R859      7.4246935546398163e-02
    z[2,3,5]  R860      1.3931236229836941e-02
    z[2,3,5]  R861      1.0323248058557510e-01
    z[2,3,5]  R862      1.1458898894488811e-02
    z[2,3,5]  R863      6.0198950767517090e-01
    z[2,3,5]  R864      -5.7573366910219193e-02
    z[2,3,5]  R865      -2.5862815976142883e-01
    z[2,3,5]  R866      2.9186886548995972e-01
    z[2,3,5]  R867      0.00526859937235713
    z[2,3,5]  R868      2.1128852665424347e-01
    z[2,3,5]  R869      -2.2448942065238953e-01
    z[2,3,5]  R870      -2.1524254232645035e-02
    z[2,3,5]  R871      2.6794016361236572e-01
    z[2,3,5]  R872      -6.7306622862815857e-02
    z[2,3,5]  R873      -4.4824701547622681e-01
    z[2,3,5]  R874      2.5261655449867249e-01
    z[2,3,5]  R875      9.6087656915187836e-02
    z[2,3,5]  R876      1.1172868311405182e-02
    z[2,3,5]  R877      -1.1932700127363205e-01
    z[2,3,5]  R878      -9.9355757236480713e-02
    z[2,3,5]  R879      0.0643991008400917
    z[2,3,5]  R880      -1.3695776462554932e-01
    z[2,3,5]  R881      6.5878160297870636e-02
    z[2,3,5]  R882      2.0843271911144257e-01
    z[2,3,5]  R883      1.0014345496892929e-01
    z[2,3,5]  R884      2.5994306802749634e-01
    z[2,3,5]  R885      -7.1071274578571320e-02
    z[2,3,5]  R886      -1.0951571911573410e-01
    z[2,3,5]  R887      1.1942744255065918e-01
    z[2,3,5]  R888      2.3815682530403137e-01
    z[2,3,5]  R889      1.6805014014244080e-01
    z[2,3,5]  R890      3.5341310501098633e-01
    z[2,3,5]  R891      -5.7587809860706329e-03
    z[2,3,5]  R892      -4.3268963694572449e-01
    z[2,3,5]  R893      -2.1182611584663391e-01
    z[2,3,5]  R894      -1.6084384918212891e-01
    z[2,3,5]  R895      -5.2090730518102646e-02
    z[2,3,5]  R896      5.4125446826219559e-02
    z[2,3,5]  R897      -2.0764803886413574e-01
    z[2,3,5]  R898      1.2295242398977280e-01
    z[2,3,5]  R899      2.0872300863265991e-01
    z[2,3,5]  R900      1.1930776387453079e-01
    z[2,3,5]  R901      -3.1884968280792236e-02
    z[2,3,5]  R902      -7.3899462819099426e-02
    z[2,3,5]  R903      -5.0889093428850174e-02
    z[2,3,5]  R904      -7.8351572155952454e-02
    z[2,3,5]  R905      -2.1108351647853851e-01
    z[2,3,5]  R906      4.1301745176315308e-01
    z[2,3,5]  R907      6.8182200193405151e-01
    z[2,3,5]  R908      7.0880597829818726e-01
    z[2,3,5]  R909      6.1938923597335815e-01
    z[2,3,5]  R910      2.0538989454507828e-02
    z[2,3,5]  R911      4.3539252877235413e-01
    z[2,3,5]  R912      -2.6755759119987488e-01
    z[2,3,5]  R913      1.9438152015209198e-01
    z[2,3,5]  R914      -1.2422193586826324e-01
    z[2,3,5]  R915      -1.1561634950339794e-02
    z[2,3,5]  R916      -5.9379488229751587e-01
    z[2,3,5]  R917      -1.2538772821426392e-01
    z[2,3,5]  R918      -5.6181255728006363e-02
    z[2,3,5]  R919      -2.4589703977108002e-01
    z[2,3,5]  R920      -1.7353695631027222e-01
    z[2,3,5]  R921      -2.8736993670463562e-01
    z[2,3,5]  R922      -5.9584236145019531e-01
    z[2,3,5]  R923      -2.9813820123672485e-01
    z[2,3,5]  R924      2.0180438458919525e-01
    z[2,3,5]  R925      4.1949892044067383e-01
    z[2,3,5]  R926      9.2779628932476044e-02
    z[2,3,5]  R927      -1.7605556547641754e-01
    z[2,3,5]  R928      5.8603119105100632e-02
    z[2,3,5]  R929      -8.5768803954124451e-02
    z[2,3,5]  R930      -3.4668779373168945e-01
    z[2,3,5]  R931      -1.3270154595375061e-01
    z[2,3,6]  R26       -1
    z[2,3,6]  R35       1
    z[2,3,6]  R820      -1
    z[2,3,6]  R821      1
    z[2,3,6]  R822      -2.7494572568684816e-03
    z[2,3,6]  R823      1.4613977074623108e-01
    z[2,3,6]  R824      -2.2966891992837191e-03
    z[2,3,6]  R825      -3.0455753207206726e-01
    z[2,3,6]  R826      -9.2454567551612854e-02
    z[2,3,6]  R827      -1.3331221416592598e-02
    z[2,3,6]  R828      0.0850360244512558
    z[2,3,6]  R829      3.3200240135192871e-01
    z[2,3,6]  R830      1.2971581518650055e-01
    z[2,3,6]  R831      -1.3002598285675049e-01
    z[2,3,6]  R832      6.4658035989850760e-04
    z[2,3,6]  R833      1.4682596921920776e-01
    z[2,3,6]  R834      4.6131512522697449e-01
    z[2,3,6]  R835      -4.1206661611795425e-02
    z[2,3,6]  R836      -7.7206864953041077e-02
    z[2,3,6]  R837      9.6304953098297119e-02
    z[2,3,6]  R838      -2.2544731199741364e-01
    z[2,3,6]  R839      -1.8545429408550262e-01
    z[2,3,6]  R840      -4.2595180869102478e-01
    z[2,3,6]  R841      -2.8930693864822388e-01
    z[2,3,6]  R842      -4.4820669293403625e-01
    z[2,3,6]  R843      -2.8691756725311279e-01
    z[2,3,6]  R844      1.0799196362495422e-01
    z[2,3,6]  R845      9.8221465945243835e-02
    z[2,3,6]  R846      1.4508076012134552e-01
    z[2,3,6]  R847      2.2577278316020966e-01
    z[2,3,6]  R848      -1.3321690261363983e-02
    z[2,3,6]  R849      7.3098443448543549e-02
    z[2,3,6]  R850      -1.0302697867155075e-01
    z[2,3,6]  R851      7.0774590969085693e-01
    z[2,3,6]  R852      4.1437754034996033e-01
    z[2,3,6]  R853      -0.511720597743988
    z[2,3,6]  R854      9.7146227955818176e-02
    z[2,3,6]  R855      4.7523382306098938e-01
    z[2,3,6]  R856      3.0004331469535828e-01
    z[2,3,6]  R857      3.2768625020980835e-01
    z[2,3,6]  R858      -9.6416510641574860e-02
    z[2,3,6]  R859      3.9024993777275085e-01
    z[2,3,6]  R860      0.500403881072998
    z[2,3,6]  R861      -0.0842781662940979
    z[2,3,6]  R862      0.275449275970459
    z[2,3,6]  R863      -7.7913120388984680e-02
    z[2,3,6]  R864      -4.7000306844711304e-01
    z[2,3,6]  R865      -3.4643980860710144e-01
    z[2,3,6]  R866      -7.0663958787918091e-01
    z[2,3,6]  R867      6.0131076723337173e-02
    z[2,3,6]  R868      -2.6651713252067566e-01
    z[2,3,6]  R869      4.3111163377761841e-01
    z[2,3,6]  R870      -1.1779459565877914e-01
    z[2,3,6]  R871      -6.9593206048011780e-02
    z[2,3,6]  R872      -3.2721498608589172e-01
    z[2,3,6]  R873      -2.4010214954614639e-02
    z[2,3,6]  R874      -4.3036383390426636e-01
    z[2,3,6]  R875      -0.0923534482717514
    z[2,3,6]  R876      -0.328215092420578
    z[2,3,6]  R877      -1.4108602702617645e-01
    z[2,3,6]  R878      6.2837995588779449e-02
    z[2,3,6]  R879      -2.5084343552589417e-01
    z[2,3,6]  R880      3.1831854581832886e-01
    z[2,3,6]  R881      3.2484382390975952e-02
    z[2,3,6]  R882      -0.148881196975708
    z[2,3,6]  R883      3.3649137616157532e-01
    z[2,3,6]  R884      5.4013800621032715e-01
    z[2,3,6]  R885      -1.8159356713294983e-01
    z[2,3,6]  R886      1.0902926325798035e-02
    z[2,3,6]  R887      -4.0447127074003220e-02
    z[2,3,6]  R888      -1.8995296210050583e-02
    z[2,3,6]  R889      -1.1160200834274292e-01
    z[2,3,6]  R890      6.0983393341302872e-02
    z[2,3,6]  R891      3.1904298067092896e-01
    z[2,3,6]  R892      2.1662132814526558e-02
    z[2,3,6]  R893      -1.8995198607444763e-01
    z[2,3,6]  R894      2.9376775026321411e-01
    z[2,3,6]  R895      1.3069215416908264e-01
    z[2,3,6]  R896      -8.4015779197216034e-02
    z[2,3,6]  R897      -1.5442037582397461e-01
    z[2,3,6]  R898      -1.0543386638164520e-01
    z[2,3,6]  R899      -0.0949973315000534
    z[2,3,6]  R900      4.1611364483833313e-01
    z[2,3,6]  R901      -1.2132444977760315e-01
    z[2,3,6]  R902      2.3194292187690735e-01
    z[2,3,6]  R903      -5.6289398670196533e-01
    z[2,3,6]  R904      4.6154615283012390e-01
    z[2,3,6]  R905      -6.4207464456558228e-01
    z[2,3,6]  R906      3.8247132301330566e-01
    z[2,3,6]  R907      -0.119338259100914
    z[2,3,6]  R908      0.0787559524178505
    z[2,3,6]  R909      2.4156802892684937e-01
    z[2,3,6]  R910      -1.2522128224372864e-01
    z[2,3,6]  R911      -5.8474189043045044e-01
    z[2,3,6]  R912      1.7861206829547882e-01
    z[2,3,6]  R913      3.3109375834465027e-01
    z[2,3,6]  R914      1.8474312126636505e-01
    z[2,3,6]  R915      -1.3475050032138824e-01
    z[2,3,6]  R916      2.1845014393329620e-01
    z[2,3,6]  R917      -2.4525426328182220e-01
    z[2,3,6]  R918      -5.0956577062606812e-01
    z[2,3,6]  R919      4.5300893485546112e-02
    z[2,3,6]  R920      2.8403285890817642e-02
    z[2,3,6]  R921      1.0566082596778870e-01
    z[2,3,6]  R922      3.4488376975059509e-01
    z[2,3,6]  R923      -3.0400553345680237e-01
    z[2,3,6]  R924      -5.7618337869644165e-01
    z[2,3,6]  R925      -0.369929701089859
    z[2,3,6]  R926      -7.0126913487911224e-02
    z[2,3,6]  R927      -1.6045859456062317e-01
    z[2,3,6]  R928      -1.5351210720837116e-02
    z[2,3,6]  R929      -1.0269220918416977e-02
    z[2,3,6]  R930      -1.2269319593906403e-01
    z[2,3,6]  R931      -2.0770236849784851e-01
    z[3,2,0]  R20       1
    z[3,2,0]  R29       -1
    z[3,2,0]  R932      -1
    z[3,2,0]  R933      1
    z[3,2,0]  R946      1.2302646785974503e-01
    z[3,2,0]  R947      3.9639464020729065e-01
    z[3,2,0]  R948      -4.4419410824775696e-01
    z[3,2,0]  R949      -3.4195578098297119e-01
    z[3,2,0]  R950      -4.2483130097389221e-01
    z[3,2,0]  R951      -4.7725465893745422e-01
    z[3,2,0]  R952      -1.1169387027621269e-02
    z[3,2,0]  R953      2.6945248246192932e-01
    z[3,2,0]  R954      1.1034189164638519e-01
    z[3,2,0]  R955      -1.4272119104862213e-01
    z[3,2,0]  R956      -6.6784307360649109e-02
    z[3,2,0]  R957      4.2604845762252808e-01
    z[3,2,0]  R958      3.7830349802970886e-01
    z[3,2,0]  R959      4.3023020029067993e-01
    z[3,2,0]  R960      4.3663305044174194e-01
    z[3,2,0]  R961      -3.4835276007652283e-01
    z[3,2,0]  R962      -3.6363103985786438e-01
    z[3,2,0]  R963      7.8226590156555176e-01
    z[3,2,0]  R964      6.4075648784637451e-01
    z[3,2,0]  R965      6.8611931800842285e-01
    z[3,2,0]  R966      -1.6029927134513855e-01
    z[3,2,0]  R967      4.0806140750646591e-02
    z[3,2,0]  R968      -2.8304606676101685e-01
    z[3,2,0]  R969      -5.8769184350967407e-01
    z[3,2,0]  R970      6.7144066095352173e-01
    z[3,2,0]  R971      0.865686297416687
    z[3,2,0]  R972      6.8237137794494629e-01
    z[3,2,0]  R973      8.3832150697708130e-01
    z[3,2,0]  R974      8.1652325391769409e-01
    z[3,2,0]  R975      6.7006939649581909e-01
    z[3,2,0]  R976      -3.9224180579185486e-01
    z[3,2,0]  R977      -3.5216581821441650e-01
    z[3,2,0]  R978      0.797160267829895
    z[3,2,0]  R979      -4.2389002442359924e-01
    z[3,2,0]  R980      6.8974149227142334e-01
    z[3,2,0]  R981      7.9577147960662842e-01
    z[3,2,0]  R982      -6.8320196866989136e-01
    z[3,2,0]  R983      7.5881582498550415e-01
    z[3,2,0]  R984      6.3608884811401367e-01
    z[3,2,0]  R985      7.3341244459152222e-01
    z[3,2,0]  R986      -8.1882697343826294e-01
    z[3,2,0]  R987      3.5091996192932129e-01
    z[3,2,0]  R988      8.4362350404262543e-02
    z[3,2,0]  R989      -7.2980821132659912e-01
    z[3,2,0]  R990      1.9111198186874390e-01
    z[3,2,0]  R991      -1.4493685960769653e-01
    z[3,2,0]  R992      -1.6609892249107361e-01
    z[3,2,0]  R993      -5.5685228109359741e-01
    z[3,2,0]  R994      0.319084495306015
    z[3,2,0]  R995      -6.5375095605850220e-01
    z[3,2,0]  R996      -7.2028857469558716e-01
    z[3,2,0]  R997      -7.1874296665191650e-01
    z[3,2,0]  R998      -0.296962708234787
    z[3,2,0]  R999      -7.2221815586090088e-01
    z[3,2,0]  R1000     -0.374138206243515
    z[3,2,0]  R1001     -7.7556854486465454e-01
    z[3,2,0]  R1002     -7.4139153957366943e-01
    z[3,2,0]  R1003     -3.9027959108352661e-02
    z[3,2,0]  R1004     3.6240735650062561e-01
    z[3,2,0]  R1005     -6.0498553514480591e-01
    z[3,2,0]  R1006     -1.0302574932575226e-01
    z[3,2,0]  R1007     -5.9329774230718613e-02
    z[3,2,0]  R1008     -3.0037942528724670e-01
    z[3,2,0]  R1009     -0.743958592414856
    z[3,2,0]  R1010     -7.8501778841018677e-01
    z[3,2,0]  R1011     -7.5105243921279907e-01
    z[3,2,0]  R1012     -5.6015497446060181e-01
    z[3,2,0]  R1013     -8.9161342382431030e-01
    z[3,2,0]  R1014     -5.9007924795150757e-01
    z[3,2,0]  R1015     -8.1120771169662476e-01
    z[3,2,0]  R1016     -7.1645969152450562e-01
    z[3,2,0]  R1017     -6.8813055753707886e-01
    z[3,2,0]  R1018     -4.4439971446990967e-01
    z[3,2,0]  R1019     -3.7683433294296265e-01
    z[3,2,0]  R1020     -3.2920166850090027e-01
    z[3,2,0]  R1021     -7.2472792863845825e-01
    z[3,2,0]  R1022     4.9414688348770142e-01
    z[3,2,0]  R1023     4.4974252581596375e-01
    z[3,2,0]  R1024     9.6794553101062775e-02
    z[3,2,0]  R1025     -4.8676044680178165e-03
    z[3,2,0]  R1026     -2.4586421251296997e-01
    z[3,2,0]  R1027     1.1634296923875809e-01
    z[3,2,0]  R1028     0.600662350654602
    z[3,2,0]  R1029     2.7329126000404358e-01
    z[3,2,0]  R1030     6.2698286771774292e-01
    z[3,2,0]  R1031     2.1078411489725113e-02
    z[3,2,0]  R1032     2.4044297635555267e-01
    z[3,2,0]  R1033     -3.8858661055564880e-01
    z[3,2,0]  R1034     -4.6192719601094723e-03
    z[3,2,0]  R1035     5.2527695894241333e-01
    z[3,2,0]  R1036     -6.3333630561828613e-01
    z[3,2,0]  R1037     4.8260340094566345e-01
    z[3,2,0]  R1038     -6.0316592454910278e-01
    z[3,2,0]  R1039     3.4032773971557617e-01
    z[3,2,0]  R1040     2.0777510106563568e-01
    z[3,2,0]  R1041     -3.5108034498989582e-03
    z[3,2,0]  R1042     4.8921483755111694e-01
    z[3,2,0]  R1043     -9.1450080275535583e-02
    z[3,2,0]  R1044     2.1135492622852325e-01
    z[3,2,0]  R1045     2.4746231734752655e-01
    z[3,2,0]  R1046     -1.0800433158874512e-01
    z[3,2,0]  R1047     -4.7529187798500061e-01
    z[3,2,0]  R1048     -0.620422899723053
    z[3,2,0]  R1049     -8.1994032859802246e-01
    z[3,2,0]  R1050     2.0614795386791229e-01
    z[3,2,0]  R1051     -7.1798115968704224e-02
    z[3,2,0]  R1052     2.6360219717025757e-01
    z[3,2,0]  R1053     1.6038280725479126e-01
    z[3,2,0]  R1054     6.0919380187988281e-01
    z[3,2,0]  R1055     7.2385388612747192e-01
    z[3,2,1]  R21       1
    z[3,2,1]  R30       -1
    z[3,2,1]  R934      -1
    z[3,2,1]  R935      1
    z[3,2,1]  R946      3.5636723041534424e-01
    z[3,2,1]  R947      1.4859323203563690e-01
    z[3,2,1]  R948      4.9766483902931213e-01
    z[3,2,1]  R949      -2.0866273343563080e-01
    z[3,2,1]  R950      0.191564679145813
    z[3,2,1]  R951      1.2885032594203949e-01
    z[3,2,1]  R952      -1.8866440653800964e-01
    z[3,2,1]  R953      -2.2225941717624664e-01
    z[3,2,1]  R954      -2.5352746248245239e-01
    z[3,2,1]  R955      -1.8692450225353241e-01
    z[3,2,1]  R956      -9.0078812837600708e-01
    z[3,2,1]  R957      -6.3910853862762451e-01
    z[3,2,1]  R958      -8.7422186136245728e-01
    z[3,2,1]  R959      -8.1641918420791626e-01
    z[3,2,1]  R960      2.1426524221897125e-01
    z[3,2,1]  R961      4.7654518485069275e-01
    z[3,2,1]  R962      3.5593998432159424e-01
    z[3,2,1]  R963      -1.8441970646381378e-01
    z[3,2,1]  R964      -2.9422175884246826e-01
    z[3,2,1]  R965      -1.8421749770641327e-01
    z[3,2,1]  R966      0.215898334980011
    z[3,2,1]  R967      7.7527087926864624e-01
    z[3,2,1]  R968      6.9777315855026245e-01
    z[3,2,1]  R969      -2.1259206533432007e-01
    z[3,2,1]  R970      -2.4626728892326355e-01
    z[3,2,1]  R971      -1.0118196159601212e-01
    z[3,2,1]  R972      -1.8070322275161743e-01
    z[3,2,1]  R973      -7.5816445052623749e-02
    z[3,2,1]  R974      -1.8228402733802795e-01
    z[3,2,1]  R975      -5.8117534965276718e-02
    z[3,2,1]  R976      1.6793204471468925e-02
    z[3,2,1]  R977      4.1982802748680115e-01
    z[3,2,1]  R978      -3.0217638611793518e-01
    z[3,2,1]  R979      3.3735528588294983e-01
    z[3,2,1]  R980      -2.1396717429161072e-01
    z[3,2,1]  R981      -1.4922298491001129e-01
    z[3,2,1]  R982      -4.6211519837379456e-01
    z[3,2,1]  R983      -2.4508625268936157e-01
    z[3,2,1]  R984      -1.8263725936412811e-01
    z[3,2,1]  R985      -2.3488880693912506e-01
    z[3,2,1]  R986      -1.6358684003353119e-01
    z[3,2,1]  R987      5.3442692756652832e-01
    z[3,2,1]  R988      5.0623804330825806e-01
    z[3,2,1]  R989      4.6645689010620117e-01
    z[3,2,1]  R990      6.5295898914337158e-01
    z[3,2,1]  R991      -9.4652932882308960e-01
    z[3,2,1]  R992      -0.909305214881897
    z[3,2,1]  R993      6.1326795816421509e-01
    z[3,2,1]  R994      5.5151903629302979e-01
    z[3,2,1]  R995      4.0061524510383606e-01
    z[3,2,1]  R996      -0.264529287815094
    z[3,2,1]  R997      -1.4760753512382507e-01
    z[3,2,1]  R998      7.9781192541122437e-01
    z[3,2,1]  R999      -1.7197097837924957e-01
    z[3,2,1]  R1000     1.4941245317459106e-01
    z[3,2,1]  R1001     4.4548544287681580e-01
    z[3,2,1]  R1002     0.653929591178894
    z[3,2,1]  R1003     4.0577349066734314e-01
    z[3,2,1]  R1004     -3.6976438760757446e-01
    z[3,2,1]  R1005     -6.7304052412509918e-02
    z[3,2,1]  R1006     4.9294161796569824e-01
    z[3,2,1]  R1007     3.5584241151809692e-01
    z[3,2,1]  R1008     3.9754968881607056e-01
    z[3,2,1]  R1009     1.6869686543941498e-02
    z[3,2,1]  R1010     7.1616090834140778e-02
    z[3,2,1]  R1011     2.5303310155868530e-01
    z[3,2,1]  R1012     -1.7502473667263985e-02
    z[3,2,1]  R1013     6.7946580238640308e-03
    z[3,2,1]  R1014     -4.3117246031761169e-01
    z[3,2,1]  R1015     3.8872316479682922e-01
    z[3,2,1]  R1016     -1.3841395080089569e-01
    z[3,2,1]  R1017     -4.6720635145902634e-02
    z[3,2,1]  R1018     5.3251668810844421e-02
    z[3,2,1]  R1019     3.9715209603309631e-01
    z[3,2,1]  R1020     -2.7576866745948792e-01
    z[3,2,1]  R1021     4.9373021721839905e-01
    z[3,2,1]  R1022     -5.0862950086593628e-01
    z[3,2,1]  R1023     -4.7206935286521912e-01
    z[3,2,1]  R1024     -9.2534351348876953e-01
    z[3,2,1]  R1025     -9.3733829259872437e-01
    z[3,2,1]  R1026     5.0692892074584961e-01
    z[3,2,1]  R1027     5.6872403621673584e-01
    z[3,2,1]  R1028     -5.3618443012237549e-01
    z[3,2,1]  R1029     -6.4487606287002563e-01
    z[3,2,1]  R1030     -3.6818471550941467e-01
    z[3,2,1]  R1031     -7.2963792085647583e-01
    z[3,2,1]  R1032     -8.2487720251083374e-01
    z[3,2,1]  R1033     7.6968425512313843e-01
    z[3,2,1]  R1034     -7.7254432439804077e-01
    z[3,2,1]  R1035     -2.3884780704975128e-01
    z[3,2,1]  R1036     3.0962151288986206e-01
    z[3,2,1]  R1037     -5.0188940763473511e-01
    z[3,2,1]  R1038     -9.2821039259433746e-02
    z[3,2,1]  R1039     -2.9327511787414551e-01
    z[3,2,1]  R1040     -0.954384446144104
    z[3,2,1]  R1041     -8.4556078910827637e-01
    z[3,2,1]  R1042     -1.5219414234161377e-01
    z[3,2,1]  R1043     -8.5327720642089844e-01
    z[3,2,1]  R1044     -8.0013388395309448e-01
    z[3,2,1]  R1045     -0.837171733379364
    z[3,2,1]  R1046     5.9243518114089966e-01
    z[3,2,1]  R1047     5.3607380390167236e-01
    z[3,2,1]  R1048     5.0177198648452759e-01
    z[3,2,1]  R1049     -4.3665003776550293e-01
    z[3,2,1]  R1050     -9.2628234624862671e-01
    z[3,2,1]  R1051     -8.7773799896240234e-01
    z[3,2,1]  R1052     9.4409698247909546e-01
    z[3,2,1]  R1053     9.3283069133758545e-01
    z[3,2,1]  R1054     4.4027809053659439e-02
    z[3,2,1]  R1055     -4.1449481248855591e-01
    z[3,2,2]  R22       1
    z[3,2,2]  R31       -1
    z[3,2,2]  R936      -1
    z[3,2,2]  R937      1
    z[3,2,2]  R946      2.5317168235778809e-01
    z[3,2,2]  R947      4.4305637478828430e-01
    z[3,2,2]  R948      -2.3154832422733307e-01
    z[3,2,2]  R949      -4.9875292181968689e-01
    z[3,2,2]  R950      -4.9246424436569214e-01
    z[3,2,2]  R951      -0.179381862282753
    z[3,2,2]  R952      0.50576251745224
    z[3,2,2]  R953      4.9431779980659485e-01
    z[3,2,2]  R954      5.8363676071166992e-01
    z[3,2,2]  R955      3.7546235322952271e-01
    z[3,2,2]  R956      -5.5164024233818054e-02
    z[3,2,2]  R957      4.6470394730567932e-01
    z[3,2,2]  R958      6.0612101107835770e-02
    z[3,2,2]  R959      1.7800678312778473e-01
    z[3,2,2]  R960      -2.4674880504608154e-01
    z[3,2,2]  R961      1.0945523530244827e-01
    z[3,2,2]  R962      2.0087005198001862e-01
    z[3,2,2]  R963      -4.0304175019264221e-01
    z[3,2,2]  R964      -4.7503703832626343e-01
    z[3,2,2]  R965      -2.3438222706317902e-01
    z[3,2,2]  R966      -4.0537121891975403e-01
    z[3,2,2]  R967      -2.3900006711483002e-01
    z[3,2,2]  R968      3.1247567385435104e-02
    z[3,2,2]  R969      5.2226681262254715e-02
    z[3,2,2]  R970      -3.5896146297454834e-01
    z[3,2,2]  R971      -1.0460843890905380e-01
    z[3,2,2]  R972      -3.1134307384490967e-01
    z[3,2,2]  R973      -1.2013496458530426e-01
    z[3,2,2]  R974      -2.0758289098739624e-01
    z[3,2,2]  R975      -2.4450413882732391e-01
    z[3,2,2]  R976      5.3428955376148224e-02
    z[3,2,2]  R977      4.7465705871582031e-01
    z[3,2,2]  R978      3.6648120731115341e-02
    z[3,2,2]  R979      0.377734899520874
    z[3,2,2]  R980      6.5484158694744110e-02
    z[3,2,2]  R981      -1.2441141903400421e-01
    z[3,2,2]  R982      2.5291427969932556e-01
    z[3,2,2]  R983      -2.6075729727745056e-01
    z[3,2,2]  R984      -2.3586069047451019e-01
    z[3,2,2]  R985      2.9757454991340637e-01
    z[3,2,2]  R986      1.2146435678005219e-01
    z[3,2,2]  R987      -4.2763182520866394e-01
    z[3,2,2]  R988      0.0552813895046711
    z[3,2,2]  R989      -3.2051667571067810e-01
    z[3,2,2]  R990      -5.6332081556320190e-01
    z[3,2,2]  R991      4.8455204814672470e-02
    z[3,2,2]  R992      2.8371301293373108e-01
    z[3,2,2]  R993      -2.1615797281265259e-01
    z[3,2,2]  R994      -3.4118276834487915e-01
    z[3,2,2]  R995      -4.3730372190475464e-01
    z[3,2,2]  R996      4.1211673617362976e-01
    z[3,2,2]  R997      4.9223366379737854e-01
    z[3,2,2]  R998      -1.7958946526050568e-02
    z[3,2,2]  R999      4.7048786282539368e-01
    z[3,2,2]  R1000     -3.8058489561080933e-01
    z[3,2,2]  R1001     -3.2974272966384888e-01
    z[3,2,2]  R1002     5.8110468089580536e-02
    z[3,2,2]  R1003     -1.9358810782432556e-01
    z[3,2,2]  R1004     -6.7814439535140991e-01
    z[3,2,2]  R1005     -0.0276302732527256
    z[3,2,2]  R1006     -1.1719395220279694e-01
    z[3,2,2]  R1007     -9.6887126564979553e-02
    z[3,2,2]  R1008     3.9203721284866333e-01
    z[3,2,2]  R1009     -9.0094834566116333e-02
    z[3,2,2]  R1010     4.0363538265228271e-01
    z[3,2,2]  R1011     2.3727929592132568e-01
    z[3,2,2]  R1012     3.7829467654228210e-01
    z[3,2,2]  R1013     2.0727132260799408e-01
    z[3,2,2]  R1014     -3.5161191225051880e-01
    z[3,2,2]  R1015     -1.8203815817832947e-01
    z[3,2,2]  R1016     5.9477311372756958e-01
    z[3,2,2]  R1017     3.3852979540824890e-01
    z[3,2,2]  R1018     0.564498245716095
    z[3,2,2]  R1019     -3.1396320462226868e-01
    z[3,2,2]  R1020     1.2137076258659363e-01
    z[3,2,2]  R1021     -3.5435834527015686e-01
    z[3,2,2]  R1022     -0.539020299911499
    z[3,2,2]  R1023     -2.3951514065265656e-01
    z[3,2,2]  R1024     1.6637371480464935e-01
    z[3,2,2]  R1025     -6.2574379146099091e-02
    z[3,2,2]  R1026     1.5445311367511749e-01
    z[3,2,2]  R1027     -3.8655731081962585e-01
    z[3,2,2]  R1028     -2.5803402066230774e-01
    z[3,2,2]  R1029     -5.0074491649866104e-02
    z[3,2,2]  R1030     -1.7812184989452362e-01
    z[3,2,2]  R1031     6.3637781143188477e-01
    z[3,2,2]  R1032     4.4004756212234497e-01
    z[3,2,2]  R1033     -3.7844008207321167e-01
    z[3,2,2]  R1034     4.7437658905982971e-01
    z[3,2,2]  R1035     -1.9614732265472412e-01
    z[3,2,2]  R1036     2.9345509409904480e-01
    z[3,2,2]  R1037     1.8945498391985893e-02
    z[3,2,2]  R1038     -2.8382557630538940e-01
    z[3,2,2]  R1039     -7.5607880949974060e-02
    z[3,2,2]  R1040     4.0291804820299149e-02
    z[3,2,2]  R1041     -3.9303341507911682e-01
    z[3,2,2]  R1042     2.5031521916389465e-01
    z[3,2,2]  R1043     3.0954939126968384e-01
    z[3,2,2]  R1044     2.4709241092205048e-01
    z[3,2,2]  R1045     -1.3379940390586853e-01
    z[3,2,2]  R1046     0.374731183052063
    z[3,2,2]  R1047     -2.3399564623832703e-01
    z[3,2,2]  R1048     -1.5763019025325775e-01
    z[3,2,2]  R1049     -2.4272593855857849e-01
    z[3,2,2]  R1050     1.6245366632938385e-01
    z[3,2,2]  R1051     -2.3109002411365509e-01
    z[3,2,2]  R1052     5.0432592630386353e-02
    z[3,2,2]  R1053     1.3996334373950958e-01
    z[3,2,2]  R1054     0.632743239402771
    z[3,2,2]  R1055     -1.8757671117782593e-01
    z[3,2,3]  R23       1
    z[3,2,3]  R32       -1
    z[3,2,3]  R938      -1
    z[3,2,3]  R939      1
    z[3,2,3]  R946      4.7430381178855896e-02
    z[3,2,3]  R947      2.8876092284917831e-02
    z[3,2,3]  R948      5.0100311636924744e-02
    z[3,2,3]  R949      -2.7720436453819275e-01
    z[3,2,3]  R950      -4.6595868468284607e-01
    z[3,2,3]  R951      -5.5398764088749886e-03
    z[3,2,3]  R952      4.4093075394630432e-01
    z[3,2,3]  R953      2.7040678262710571e-01
    z[3,2,3]  R954      7.3127579689025879e-01
    z[3,2,3]  R955      4.1562882065773010e-01
    z[3,2,3]  R956      1.2848268449306488e-01
    z[3,2,3]  R957      2.1257027983665466e-01
    z[3,2,3]  R958      -1.9541363418102264e-01
    z[3,2,3]  R959      -1.9743348658084869e-01
    z[3,2,3]  R960      -5.4969519376754761e-01
    z[3,2,3]  R961      6.3999301195144653e-01
    z[3,2,3]  R962      6.6140717267990112e-01
    z[3,2,3]  R963      3.5298663377761841e-01
    z[3,2,3]  R964      4.4309777021408081e-01
    z[3,2,3]  R965      4.6353161334991455e-01
    z[3,2,3]  R966      -3.0771313235163689e-02
    z[3,2,3]  R967      -2.6654061675071716e-01
    z[3,2,3]  R968      2.0046578347682953e-01
    z[3,2,3]  R969      4.1446754336357117e-01
    z[3,2,3]  R970      5.8468794822692871e-01
    z[3,2,3]  R971      3.7966915965080261e-01
    z[3,2,3]  R972      5.9524923563003540e-01
    z[3,2,3]  R973      4.0818822383880615e-01
    z[3,2,3]  R974      3.3546721935272217e-01
    z[3,2,3]  R975      6.5078121423721313e-01
    z[3,2,3]  R976      -5.7658666372299194e-01
    z[3,2,3]  R977      -4.8413532972335815e-01
    z[3,2,3]  R978      5.0298297405242920e-01
    z[3,2,3]  R979      -3.8413512706756592e-01
    z[3,2,3]  R980      6.3380491733551025e-01
    z[3,2,3]  R981      4.7572395205497742e-01
    z[3,2,3]  R982      -4.7816762328147888e-01
    z[3,2,3]  R983      4.1079682111740112e-01
    z[3,2,3]  R984      6.8301928043365479e-01
    z[3,2,3]  R985      4.1419026255607605e-01
    z[3,2,3]  R986      5.2072703838348389e-01
    z[3,2,3]  R987      -4.7158092260360718e-01
    z[3,2,3]  R988      -4.2060464620590210e-01
    z[3,2,3]  R989      -2.1827220916748047e-02
    z[3,2,3]  R990      -4.3719586730003357e-01
    z[3,2,3]  R991      2.4062652885913849e-01
    z[3,2,3]  R992      1.5694554895162582e-02
    z[3,2,3]  R993      4.5493260025978088e-01
    z[3,2,3]  R994      -5.2448230981826782e-01
    z[3,2,3]  R995      1.5438485145568848e-01
    z[3,2,3]  R996      -9.3475859612226486e-03
    z[3,2,3]  R997      -7.0925705134868622e-02
    z[3,2,3]  R998      -3.5661661624908447e-01
    z[3,2,3]  R999      3.1329268217086792e-01
    z[3,2,3]  R1000     -7.3681735992431641e-01
    z[3,2,3]  R1001     1.6105762124061584e-01
    z[3,2,3]  R1002     2.0723575726151466e-03
    z[3,2,3]  R1003     -8.0785721540451050e-01
    z[3,2,3]  R1004     2.6825010776519775e-01
    z[3,2,3]  R1005     1.4808334410190582e-01
    z[3,2,3]  R1006     -5.6925994157791138e-01
    z[3,2,3]  R1007     -7.7147370576858521e-01
    z[3,2,3]  R1008     -5.1840478181838989e-01
    z[3,2,3]  R1009     -3.9839029312133789e-01
    z[3,2,3]  R1010     -1.6759096086025238e-01
    z[3,2,3]  R1011     2.2435568273067474e-01
    z[3,2,3]  R1012     -5.7995975017547607e-01
    z[3,2,3]  R1013     -5.5508546531200409e-02
    z[3,2,3]  R1014     -0.162618488073349
    z[3,2,3]  R1015     -1.8966302275657654e-01
    z[3,2,3]  R1016     -1.6043733060359955e-01
    z[3,2,3]  R1017     -3.4989330917596817e-02
    z[3,2,3]  R1018     -4.5814856886863708e-01
    z[3,2,3]  R1019     -4.3502718210220337e-01
    z[3,2,3]  R1020     -4.5113736391067505e-01
    z[3,2,3]  R1021     -1.7009107768535614e-01
    z[3,2,3]  R1022     2.9478520154953003e-01
    z[3,2,3]  R1023     1.8935614824295044e-01
    z[3,2,3]  R1024     2.7815201878547668e-01
    z[3,2,3]  R1025     1.7314006388187408e-01
    z[3,2,3]  R1026     -7.3491680622100830e-01
    z[3,2,3]  R1027     -5.5577796697616577e-01
    z[3,2,3]  R1028     1.8954205513000488e-01
    z[3,2,3]  R1029     4.7849395871162415e-01
    z[3,2,3]  R1030     6.3952714204788208e-02
    z[3,2,3]  R1031     -1.4681740105152130e-01
    z[3,2,3]  R1032     0.00597138237208128
    z[3,2,3]  R1033     2.1508035063743591e-01
    z[3,2,3]  R1034     1.8963800370693207e-01
    z[3,2,3]  R1035     6.0778830200433731e-02
    z[3,2,3]  R1036     -0.0553843230009079
    z[3,2,3]  R1037     0.38902547955513
    z[3,2,3]  R1038     2.6066571474075317e-01
    z[3,2,3]  R1039     3.7355315685272217e-01
    z[3,2,3]  R1040     -8.0543659627437592e-02
    z[3,2,3]  R1041     2.9656881093978882e-01
    z[3,2,3]  R1042     2.5672686100006104e-01
    z[3,2,3]  R1043     -2.0979759097099304e-01
    z[3,2,3]  R1044     7.3786050081253052e-02
    z[3,2,3]  R1045     2.5442928075790405e-01
    z[3,2,3]  R1046     -0.555517852306366
    z[3,2,3]  R1047     -3.0220049619674683e-01
    z[3,2,3]  R1048     -4.7199490666389465e-01
    z[3,2,3]  R1049     -1.3955840468406677e-01
    z[3,2,3]  R1050     -7.2610370814800262e-02
    z[3,2,3]  R1051     -3.0861049890518188e-01
    z[3,2,3]  R1052     9.9657423794269562e-02
    z[3,2,3]  R1053     1.7827060818672180e-01
    z[3,2,3]  R1054     -0.0658518373966217
    z[3,2,3]  R1055     -2.5762474536895752e-01
    z[3,2,4]  R24       1
    z[3,2,4]  R33       -1
    z[3,2,4]  R940      -1
    z[3,2,4]  R941      1
    z[3,2,4]  R946      0.85572350025177
    z[3,2,4]  R947      5.5156075954437256e-01
    z[3,2,4]  R948      -5.2889782190322876e-01
    z[3,2,4]  R949      2.3898379504680634e-01
    z[3,2,4]  R950      0.0794677734375
    z[3,2,4]  R951      4.9426129460334778e-01
    z[3,2,4]  R952      -7.3871716856956482e-02
    z[3,2,4]  R953      3.4427908062934875e-01
    z[3,2,4]  R954      -1.7902587354183197e-01
    z[3,2,4]  R955      -3.1540572643280029e-01
    z[3,2,4]  R956      -2.4714456498622894e-01
    z[3,2,4]  R957      -3.8467753678560257e-02
    z[3,2,4]  R958      -3.4658830612897873e-02
    z[3,2,4]  R959      -2.4372906982898712e-01
    z[3,2,4]  R960      8.9103868231177330e-03
    z[3,2,4]  R961      3.9257079362869263e-01
    z[3,2,4]  R962      -2.1384319290518761e-02
    z[3,2,4]  R963      6.7004904150962830e-02
    z[3,2,4]  R964      2.2348852455615997e-01
    z[3,2,4]  R965      3.6299028992652893e-01
    z[3,2,4]  R966      5.3707206249237061e-01
    z[3,2,4]  R967      2.9634320735931396e-01
    z[3,2,4]  R968      1.3828288018703461e-01
    z[3,2,4]  R969      -3.4940603375434875e-01
    z[3,2,4]  R970      -6.5426945686340332e-02
    z[3,2,4]  R971      -1.6886492073535919e-01
    z[3,2,4]  R972      2.1630893647670746e-01
    z[3,2,4]  R973      3.2086926698684692e-01
    z[3,2,4]  R974      9.5850922167301178e-02
    z[3,2,4]  R975      5.9840731322765350e-02
    z[3,2,4]  R976      0.585985004901886
    z[3,2,4]  R977      4.5392480492591858e-01
    z[3,2,4]  R978      -4.9370858818292618e-02
    z[3,2,4]  R979      2.9065108299255371e-01
    z[3,2,4]  R980      0.0555245578289032
    z[3,2,4]  R981      -8.8652148842811584e-02
    z[3,2,4]  R982      1.3986818492412567e-01
    z[3,2,4]  R983      1.1174959689378738e-01
    z[3,2,4]  R984      -8.8005885481834412e-02
    z[3,2,4]  R985      0.0831865444779396
    z[3,2,4]  R986      -8.0534592270851135e-03
    z[3,2,4]  R987      2.4362045526504517e-01
    z[3,2,4]  R988      2.3618039488792419e-01
    z[3,2,4]  R989      -3.3481118083000183e-01
    z[3,2,4]  R990      1.1404404789209366e-01
    z[3,2,4]  R991      -1.1398802697658539e-01
    z[3,2,4]  R992      -8.5143849253654480e-02
    z[3,2,4]  R993      -1.4496196806430817e-01
    z[3,2,4]  R994      -2.6472138240933418e-02
    z[3,2,4]  R995      3.2402139902114868e-01
    z[3,2,4]  R996      1.8986824154853821e-01
    z[3,2,4]  R997      -3.4458765387535095e-01
    z[3,2,4]  R998      -1.5601888298988342e-01
    z[3,2,4]  R999      -3.3036106824874878e-01
    z[3,2,4]  R1000     7.9754993319511414e-02
    z[3,2,4]  R1001     2.2440824657678604e-02
    z[3,2,4]  R1002     -5.4176026023924351e-03
    z[3,2,4]  R1003     -8.7099701166152954e-02
    z[3,2,4]  R1004     -3.8170254230499268e-01
    z[3,2,4]  R1005     2.8691646456718445e-01
    z[3,2,4]  R1006     0.372158020734787
    z[3,2,4]  R1007     4.3288782238960266e-02
    z[3,2,4]  R1008     -1.2515020370483398e-01
    z[3,2,4]  R1009     9.4737574458122253e-02
    z[3,2,4]  R1010     -1.8336981534957886e-01
    z[3,2,4]  R1011     3.9586311578750610e-01
    z[3,2,4]  R1012     -2.0542104542255402e-01
    z[3,2,4]  R1013     -3.3603996038436890e-02
    z[3,2,4]  R1014     2.5538778305053711e-01
    z[3,2,4]  R1015     -3.2243865728378296e-01
    z[3,2,4]  R1016     1.0967319458723068e-01
    z[3,2,4]  R1017     2.0001262426376343e-01
    z[3,2,4]  R1018     -2.1655750274658203e-01
    z[3,2,4]  R1019     4.7490587830543518e-01
    z[3,2,4]  R1020     -1.1311549693346024e-01
    z[3,2,4]  R1021     0.269917756319046
    z[3,2,4]  R1022     -6.3240818679332733e-02
    z[3,2,4]  R1023     -4.9538484215736389e-01
    z[3,2,4]  R1024     1.2240315973758698e-01
    z[3,2,4]  R1025     1.0413980484008789e-01
    z[3,2,4]  R1026     8.3759091794490814e-02
    z[3,2,4]  R1027     -5.6565467268228531e-02
    z[3,2,4]  R1028     -1.3234561309218407e-02
    z[3,2,4]  R1029     -5.1011848449707031e-01
    z[3,2,4]  R1030     -5.7242041826248169e-01
    z[3,2,4]  R1031     0.0806722566485405
    z[3,2,4]  R1032     2.3295298218727112e-01
    z[3,2,4]  R1033     6.3670896925032139e-03
    z[3,2,4]  R1034     1.4857368171215057e-01
    z[3,2,4]  R1035     -7.8706592321395874e-01
    z[3,2,4]  R1036     5.9010720252990723e-01
    z[3,2,4]  R1037     -4.9014893174171448e-01
    z[3,2,4]  R1038     3.4605216979980469e-01
    z[3,2,4]  R1039     -0.784143328666687
    z[3,2,4]  R1040     1.6048873960971832e-01
    z[3,2,4]  R1041     -1.6336247324943542e-01
    z[3,2,4]  R1042     -7.4287265539169312e-01
    z[3,2,4]  R1043     2.8813734650611877e-01
    z[3,2,4]  R1044     3.4640464186668396e-01
    z[3,2,4]  R1045     2.3118773102760315e-01
    z[3,2,4]  R1046     2.5349294766783714e-02
    z[3,2,4]  R1047     5.0959908962249756e-01
    z[3,2,4]  R1048     5.9191279113292694e-02
    z[3,2,4]  R1049     -1.9709999859333038e-01
    z[3,2,4]  R1050     2.4052542448043823e-01
    z[3,2,4]  R1051     -9.3885980546474457e-02
    z[3,2,4]  R1052     2.2049862891435623e-02
    z[3,2,4]  R1053     1.2017721310257912e-02
    z[3,2,4]  R1054     -1.8670603632926941e-01
    z[3,2,4]  R1055     4.3236309289932251e-01
    z[3,2,5]  R25       1
    z[3,2,5]  R34       -1
    z[3,2,5]  R942      -1
    z[3,2,5]  R943      1
    z[3,2,5]  R946      -7.3899462819099426e-02
    z[3,2,5]  R947      -5.0889093428850174e-02
    z[3,2,5]  R948      -7.8351572155952454e-02
    z[3,2,5]  R949      -2.1108351647853851e-01
    z[3,2,5]  R950      4.1301745176315308e-01
    z[3,2,5]  R951      6.8182200193405151e-01
    z[3,2,5]  R952      7.0880597829818726e-01
    z[3,2,5]  R953      6.1938923597335815e-01
    z[3,2,5]  R954      2.0538989454507828e-02
    z[3,2,5]  R955      4.3539252877235413e-01
    z[3,2,5]  R956      -2.6755759119987488e-01
    z[3,2,5]  R957      1.9438152015209198e-01
    z[3,2,5]  R958      -1.2422193586826324e-01
    z[3,2,5]  R959      -1.1561634950339794e-02
    z[3,2,5]  R960      -5.9379488229751587e-01
    z[3,2,5]  R961      -1.2538772821426392e-01
    z[3,2,5]  R962      -5.6181255728006363e-02
    z[3,2,5]  R963      -2.4589703977108002e-01
    z[3,2,5]  R964      -1.7353695631027222e-01
    z[3,2,5]  R965      -2.8736993670463562e-01
    z[3,2,5]  R966      -5.9584236145019531e-01
    z[3,2,5]  R967      -2.9813820123672485e-01
    z[3,2,5]  R968      2.0180438458919525e-01
    z[3,2,5]  R969      4.1949892044067383e-01
    z[3,2,5]  R970      9.2779628932476044e-02
    z[3,2,5]  R971      -1.7605556547641754e-01
    z[3,2,5]  R972      5.8603119105100632e-02
    z[3,2,5]  R973      -8.5768803954124451e-02
    z[3,2,5]  R974      -3.4668779373168945e-01
    z[3,2,5]  R975      -1.3270154595375061e-01
    z[3,2,5]  R976      4.0886640548706055e-01
    z[3,2,5]  R977      1.1239586770534515e-01
    z[3,2,5]  R978      -1.2824654579162598e-01
    z[3,2,5]  R979      4.8890876770019531e-01
    z[3,2,5]  R980      2.4667195975780487e-01
    z[3,2,5]  R981      3.0765545368194580e-01
    z[3,2,5]  R982      -1.6746150329709053e-02
    z[3,2,5]  R983      -0.0683315098285675
    z[3,2,5]  R984      1.2376486510038376e-01
    z[3,2,5]  R985      3.5071703791618347e-01
    z[3,2,5]  R986      -1.2956143915653229e-01
    z[3,2,5]  R987      -3.2415542006492615e-01
    z[3,2,5]  R988      -5.3670185804367065e-01
    z[3,2,5]  R989      1.8109139800071716e-01
    z[3,2,5]  R990      -9.8403267562389374e-02
    z[3,2,5]  R991      -2.3633357137441635e-02
    z[3,2,5]  R992      8.2218162715435028e-02
    z[3,2,5]  R993      6.8722128868103027e-02
    z[3,2,5]  R994      -1.4278912544250488e-01
    z[3,2,5]  R995      -9.1430328786373138e-02
    z[3,2,5]  R996      -6.5892316401004791e-02
    z[3,2,5]  R997      1.1503832787275314e-01
    z[3,2,5]  R998      -3.3437585830688477e-01
    z[3,2,5]  R999      1.0261550545692444e-01
    z[3,2,5]  R1000     -3.5006096959114075e-01
    z[3,2,5]  R1001     -1.1785305291414261e-01
    z[3,2,5]  R1002     -1.3829918205738068e-01
    z[3,2,5]  R1003     -3.6164256930351257e-01
    z[3,2,5]  R1004     -2.0925061404705048e-01
    z[3,2,5]  R1005     1.5344475209712982e-01
    z[3,2,5]  R1006     -3.1367599964141846e-01
    z[3,2,5]  R1007     -3.9566081017255783e-02
    z[3,2,5]  R1008     -5.5153405666351318e-01
    z[3,2,5]  R1009     -2.1115562319755554e-01
    z[3,2,5]  R1010     -2.5290203094482422e-01
    z[3,2,5]  R1011     -3.4231055527925491e-02
    z[3,2,5]  R1012     -3.9365702867507935e-01
    z[3,2,5]  R1013     7.4246935546398163e-02
    z[3,2,5]  R1014     1.3931236229836941e-02
    z[3,2,5]  R1015     1.0323248058557510e-01
    z[3,2,5]  R1016     1.1458898894488811e-02
    z[3,2,5]  R1017     6.0198950767517090e-01
    z[3,2,5]  R1018     -5.7573366910219193e-02
    z[3,2,5]  R1019     -2.5862815976142883e-01
    z[3,2,5]  R1020     2.9186886548995972e-01
    z[3,2,5]  R1021     0.00526859937235713
    z[3,2,5]  R1022     2.1128852665424347e-01
    z[3,2,5]  R1023     -2.2448942065238953e-01
    z[3,2,5]  R1024     -2.1524254232645035e-02
    z[3,2,5]  R1025     2.6794016361236572e-01
    z[3,2,5]  R1026     -6.7306622862815857e-02
    z[3,2,5]  R1027     -4.4824701547622681e-01
    z[3,2,5]  R1028     2.5261655449867249e-01
    z[3,2,5]  R1029     9.6087656915187836e-02
    z[3,2,5]  R1030     1.1172868311405182e-02
    z[3,2,5]  R1031     -1.1932700127363205e-01
    z[3,2,5]  R1032     -9.9355757236480713e-02
    z[3,2,5]  R1033     0.0643991008400917
    z[3,2,5]  R1034     -1.3695776462554932e-01
    z[3,2,5]  R1035     6.5878160297870636e-02
    z[3,2,5]  R1036     2.0843271911144257e-01
    z[3,2,5]  R1037     1.0014345496892929e-01
    z[3,2,5]  R1038     2.5994306802749634e-01
    z[3,2,5]  R1039     -7.1071274578571320e-02
    z[3,2,5]  R1040     -1.0951571911573410e-01
    z[3,2,5]  R1041     1.1942744255065918e-01
    z[3,2,5]  R1042     2.3815682530403137e-01
    z[3,2,5]  R1043     1.6805014014244080e-01
    z[3,2,5]  R1044     3.5341310501098633e-01
    z[3,2,5]  R1045     -5.7587809860706329e-03
    z[3,2,5]  R1046     -4.3268963694572449e-01
    z[3,2,5]  R1047     -2.1182611584663391e-01
    z[3,2,5]  R1048     -1.6084384918212891e-01
    z[3,2,5]  R1049     -5.2090730518102646e-02
    z[3,2,5]  R1050     5.4125446826219559e-02
    z[3,2,5]  R1051     -2.0764803886413574e-01
    z[3,2,5]  R1052     1.2295242398977280e-01
    z[3,2,5]  R1053     2.0872300863265991e-01
    z[3,2,5]  R1054     1.1930776387453079e-01
    z[3,2,5]  R1055     -3.1884968280792236e-02
    z[3,2,6]  R26       1
    z[3,2,6]  R35       -1
    z[3,2,6]  R944      -1
    z[3,2,6]  R945      1
    z[3,2,6]  R946      2.3194292187690735e-01
    z[3,2,6]  R947      -5.6289398670196533e-01
    z[3,2,6]  R948      4.6154615283012390e-01
    z[3,2,6]  R949      -6.4207464456558228e-01
    z[3,2,6]  R950      3.8247132301330566e-01
    z[3,2,6]  R951      -0.119338259100914
    z[3,2,6]  R952      0.0787559524178505
    z[3,2,6]  R953      2.4156802892684937e-01
    z[3,2,6]  R954      -1.2522128224372864e-01
    z[3,2,6]  R955      -5.8474189043045044e-01
    z[3,2,6]  R956      1.7861206829547882e-01
    z[3,2,6]  R957      3.3109375834465027e-01
    z[3,2,6]  R958      1.8474312126636505e-01
    z[3,2,6]  R959      -1.3475050032138824e-01
    z[3,2,6]  R960      2.1845014393329620e-01
    z[3,2,6]  R961      -2.4525426328182220e-01
    z[3,2,6]  R962      -5.0956577062606812e-01
    z[3,2,6]  R963      4.5300893485546112e-02
    z[3,2,6]  R964      2.8403285890817642e-02
    z[3,2,6]  R965      1.0566082596778870e-01
    z[3,2,6]  R966      3.4488376975059509e-01
    z[3,2,6]  R967      -3.0400553345680237e-01
    z[3,2,6]  R968      -5.7618337869644165e-01
    z[3,2,6]  R969      -0.369929701089859
    z[3,2,6]  R970      -7.0126913487911224e-02
    z[3,2,6]  R971      -1.6045859456062317e-01
    z[3,2,6]  R972      -1.5351210720837116e-02
    z[3,2,6]  R973      -1.0269220918416977e-02
    z[3,2,6]  R974      -1.2269319593906403e-01
    z[3,2,6]  R975      -2.0770236849784851e-01
    z[3,2,6]  R976      -2.7494572568684816e-03
    z[3,2,6]  R977      1.4613977074623108e-01
    z[3,2,6]  R978      -2.2966891992837191e-03
    z[3,2,6]  R979      -3.0455753207206726e-01
    z[3,2,6]  R980      -9.2454567551612854e-02
    z[3,2,6]  R981      -1.3331221416592598e-02
    z[3,2,6]  R982      0.0850360244512558
    z[3,2,6]  R983      3.3200240135192871e-01
    z[3,2,6]  R984      1.2971581518650055e-01
    z[3,2,6]  R985      -1.3002598285675049e-01
    z[3,2,6]  R986      6.4658035989850760e-04
    z[3,2,6]  R987      1.4682596921920776e-01
    z[3,2,6]  R988      4.6131512522697449e-01
    z[3,2,6]  R989      -4.1206661611795425e-02
    z[3,2,6]  R990      -7.7206864953041077e-02
    z[3,2,6]  R991      9.6304953098297119e-02
    z[3,2,6]  R992      -2.2544731199741364e-01
    z[3,2,6]  R993      -1.8545429408550262e-01
    z[3,2,6]  R994      -4.2595180869102478e-01
    z[3,2,6]  R995      -2.8930693864822388e-01
    z[3,2,6]  R996      -4.4820669293403625e-01
    z[3,2,6]  R997      -2.8691756725311279e-01
    z[3,2,6]  R998      1.0799196362495422e-01
    z[3,2,6]  R999      9.8221465945243835e-02
    z[3,2,6]  R1000     1.4508076012134552e-01
    z[3,2,6]  R1001     2.2577278316020966e-01
    z[3,2,6]  R1002     -1.3321690261363983e-02
    z[3,2,6]  R1003     7.3098443448543549e-02
    z[3,2,6]  R1004     -1.0302697867155075e-01
    z[3,2,6]  R1005     7.0774590969085693e-01
    z[3,2,6]  R1006     4.1437754034996033e-01
    z[3,2,6]  R1007     -0.511720597743988
    z[3,2,6]  R1008     9.7146227955818176e-02
    z[3,2,6]  R1009     4.7523382306098938e-01
    z[3,2,6]  R1010     3.0004331469535828e-01
    z[3,2,6]  R1011     3.2768625020980835e-01
    z[3,2,6]  R1012     -9.6416510641574860e-02
    z[3,2,6]  R1013     3.9024993777275085e-01
    z[3,2,6]  R1014     0.500403881072998
    z[3,2,6]  R1015     -0.0842781662940979
    z[3,2,6]  R1016     0.275449275970459
    z[3,2,6]  R1017     -7.7913120388984680e-02
    z[3,2,6]  R1018     -4.7000306844711304e-01
    z[3,2,6]  R1019     -3.4643980860710144e-01
    z[3,2,6]  R1020     -7.0663958787918091e-01
    z[3,2,6]  R1021     6.0131076723337173e-02
    z[3,2,6]  R1022     -2.6651713252067566e-01
    z[3,2,6]  R1023     4.3111163377761841e-01
    z[3,2,6]  R1024     -1.1779459565877914e-01
    z[3,2,6]  R1025     -6.9593206048011780e-02
    z[3,2,6]  R1026     -3.2721498608589172e-01
    z[3,2,6]  R1027     -2.4010214954614639e-02
    z[3,2,6]  R1028     -4.3036383390426636e-01
    z[3,2,6]  R1029     -0.0923534482717514
    z[3,2,6]  R1030     -0.328215092420578
    z[3,2,6]  R1031     -1.4108602702617645e-01
    z[3,2,6]  R1032     6.2837995588779449e-02
    z[3,2,6]  R1033     -2.5084343552589417e-01
    z[3,2,6]  R1034     3.1831854581832886e-01
    z[3,2,6]  R1035     3.2484382390975952e-02
    z[3,2,6]  R1036     -0.148881196975708
    z[3,2,6]  R1037     3.3649137616157532e-01
    z[3,2,6]  R1038     5.4013800621032715e-01
    z[3,2,6]  R1039     -1.8159356713294983e-01
    z[3,2,6]  R1040     1.0902926325798035e-02
    z[3,2,6]  R1041     -4.0447127074003220e-02
    z[3,2,6]  R1042     -1.8995296210050583e-02
    z[3,2,6]  R1043     -1.1160200834274292e-01
    z[3,2,6]  R1044     6.0983393341302872e-02
    z[3,2,6]  R1045     3.1904298067092896e-01
    z[3,2,6]  R1046     2.1662132814526558e-02
    z[3,2,6]  R1047     -1.8995198607444763e-01
    z[3,2,6]  R1048     2.9376775026321411e-01
    z[3,2,6]  R1049     1.3069215416908264e-01
    z[3,2,6]  R1050     -8.4015779197216034e-02
    z[3,2,6]  R1051     -1.5442037582397461e-01
    z[3,2,6]  R1052     -1.0543386638164520e-01
    z[3,2,6]  R1053     -0.0949973315000534
    z[3,2,6]  R1054     4.1611364483833313e-01
    z[3,2,6]  R1055     -1.2132444977760315e-01
    z[2,5,0]  R20       -1
    z[2,5,0]  R47       1
    z[2,5,0]  R1056     -1
    z[2,5,0]  R1057     1
    z[2,5,0]  R1070     -3.9224180579185486e-01
    z[2,5,0]  R1071     -3.5216581821441650e-01
    z[2,5,0]  R1072     0.797160267829895
    z[2,5,0]  R1073     -4.2389002442359924e-01
    z[2,5,0]  R1074     6.8974149227142334e-01
    z[2,5,0]  R1075     7.9577147960662842e-01
    z[2,5,0]  R1076     -6.8320196866989136e-01
    z[2,5,0]  R1077     7.5881582498550415e-01
    z[2,5,0]  R1078     6.3608884811401367e-01
    z[2,5,0]  R1079     7.3341244459152222e-01
    z[2,5,0]  R1080     -8.1882697343826294e-01
    z[2,5,0]  R1081     3.5091996192932129e-01
    z[2,5,0]  R1082     8.4362350404262543e-02
    z[2,5,0]  R1083     -7.2980821132659912e-01
    z[2,5,0]  R1084     1.9111198186874390e-01
    z[2,5,0]  R1085     -1.4493685960769653e-01
    z[2,5,0]  R1086     -1.6609892249107361e-01
    z[2,5,0]  R1087     -5.5685228109359741e-01
    z[2,5,0]  R1088     0.319084495306015
    z[2,5,0]  R1089     -6.5375095605850220e-01
    z[2,5,0]  R1090     -7.2028857469558716e-01
    z[2,5,0]  R1091     -7.1874296665191650e-01
    z[2,5,0]  R1092     -0.296962708234787
    z[2,5,0]  R1093     -7.2221815586090088e-01
    z[2,5,0]  R1094     -0.374138206243515
    z[2,5,0]  R1095     -7.7556854486465454e-01
    z[2,5,0]  R1096     -7.4139153957366943e-01
    z[2,5,0]  R1097     -3.9027959108352661e-02
    z[2,5,0]  R1098     3.6240735650062561e-01
    z[2,5,0]  R1099     -6.0498553514480591e-01
    z[2,5,0]  R1100     -1.0302574932575226e-01
    z[2,5,0]  R1101     -5.9329774230718613e-02
    z[2,5,0]  R1102     -3.0037942528724670e-01
    z[2,5,0]  R1103     -0.743958592414856
    z[2,5,0]  R1104     -7.8501778841018677e-01
    z[2,5,0]  R1105     -7.5105243921279907e-01
    z[2,5,0]  R1106     -5.6015497446060181e-01
    z[2,5,0]  R1107     -8.9161342382431030e-01
    z[2,5,0]  R1108     -5.9007924795150757e-01
    z[2,5,0]  R1109     -8.1120771169662476e-01
    z[2,5,0]  R1110     -7.1645969152450562e-01
    z[2,5,0]  R1111     -6.8813055753707886e-01
    z[2,5,0]  R1112     -4.4439971446990967e-01
    z[2,5,0]  R1113     -3.7683433294296265e-01
    z[2,5,0]  R1114     -3.2920166850090027e-01
    z[2,5,0]  R1115     -7.2472792863845825e-01
    z[2,5,0]  R1116     4.9414688348770142e-01
    z[2,5,0]  R1117     4.4974252581596375e-01
    z[2,5,0]  R1118     9.6794553101062775e-02
    z[2,5,0]  R1119     -4.8676044680178165e-03
    z[2,5,0]  R1120     -2.4586421251296997e-01
    z[2,5,0]  R1121     1.1634296923875809e-01
    z[2,5,0]  R1122     0.600662350654602
    z[2,5,0]  R1123     2.7329126000404358e-01
    z[2,5,0]  R1124     6.2698286771774292e-01
    z[2,5,0]  R1125     2.1078411489725113e-02
    z[2,5,0]  R1126     2.4044297635555267e-01
    z[2,5,0]  R1127     -3.8858661055564880e-01
    z[2,5,0]  R1128     -4.6192719601094723e-03
    z[2,5,0]  R1129     5.2527695894241333e-01
    z[2,5,0]  R1130     -6.3333630561828613e-01
    z[2,5,0]  R1131     4.8260340094566345e-01
    z[2,5,0]  R1132     -6.0316592454910278e-01
    z[2,5,0]  R1133     3.4032773971557617e-01
    z[2,5,0]  R1134     2.0777510106563568e-01
    z[2,5,0]  R1135     -3.5108034498989582e-03
    z[2,5,0]  R1136     4.8921483755111694e-01
    z[2,5,0]  R1137     -9.1450080275535583e-02
    z[2,5,0]  R1138     2.1135492622852325e-01
    z[2,5,0]  R1139     2.4746231734752655e-01
    z[2,5,0]  R1140     -1.0800433158874512e-01
    z[2,5,0]  R1141     -4.7529187798500061e-01
    z[2,5,0]  R1142     -0.620422899723053
    z[2,5,0]  R1143     -8.1994032859802246e-01
    z[2,5,0]  R1144     2.0614795386791229e-01
    z[2,5,0]  R1145     -7.1798115968704224e-02
    z[2,5,0]  R1146     2.6360219717025757e-01
    z[2,5,0]  R1147     1.6038280725479126e-01
    z[2,5,0]  R1148     6.0919380187988281e-01
    z[2,5,0]  R1149     7.2385388612747192e-01
    z[2,5,0]  R1150     7.5943458080291748e-01
    z[2,5,0]  R1151     8.6767166852951050e-01
    z[2,5,0]  R1152     7.3249679803848267e-01
    z[2,5,0]  R1153     6.8604403734207153e-01
    z[2,5,0]  R1154     -4.4286161661148071e-01
    z[2,5,0]  R1155     -5.4820311069488525e-01
    z[2,5,0]  R1156     8.8026702404022217e-01
    z[2,5,0]  R1157     6.8000304698944092e-01
    z[2,5,0]  R1158     1.1706885695457458e-01
    z[2,5,0]  R1159     6.7970955371856689e-01
    z[2,5,0]  R1160     -7.2851979732513428e-01
    z[2,5,0]  R1161     -5.3250616788864136e-01
    z[2,5,0]  R1162     -4.5595401525497437e-01
    z[2,5,0]  R1163     -4.3952351808547974e-01
    z[2,5,0]  R1164     -4.3826425075531006e-01
    z[2,5,0]  R1165     -4.2607232928276062e-01
    z[2,5,0]  R1166     -4.5474034547805786e-01
    z[2,5,0]  R1167     -0.492642879486084
    z[2,5,0]  R1168     -3.5169291496276855e-01
    z[2,5,0]  R1169     -4.2849314212799072e-01
    z[2,5,0]  R1170     -1.8124037981033325e-01
    z[2,5,0]  R1171     1.0111644119024277e-01
    z[2,5,0]  R1172     -1.4891627430915833e-01
    z[2,5,0]  R1173     -3.5820782184600830e-01
    z[2,5,0]  R1174     1.6601191833615303e-02
    z[2,5,0]  R1175     -9.0139172971248627e-02
    z[2,5,0]  R1176     9.9790267646312714e-02
    z[2,5,0]  R1177     -5.5877542495727539e-01
    z[2,5,0]  R1178     -6.8435692787170410e-01
    z[2,5,0]  R1179     0.591355562210083
    z[2,5,0]  R1180     -0.634787917137146
    z[2,5,0]  R1181     -4.2726138234138489e-01
    z[2,5,0]  R1182     1.2502075731754303e-01
    z[2,5,0]  R1183     3.1266176700592041e-01
    z[2,5,0]  R1184     3.5332730412483215e-01
    z[2,5,0]  R1185     -8.6019468307495117e-01
    z[2,5,0]  R1186     -0.551559567451477
    z[2,5,0]  R1187     0.562705397605896
    z[2,5,0]  R1188     5.3335338830947876e-01
    z[2,5,0]  R1189     5.8284366130828857e-01
    z[2,5,0]  R1190     -1.4608344435691833e-01
    z[2,5,0]  R1191     4.0938743948936462e-01
    z[2,5,0]  R1192     1.8510198593139648e-01
    z[2,5,0]  R1193     2.6271072030067444e-01
    z[2,5,0]  R1194     5.9153407812118530e-01
    z[2,5,0]  R1195     2.2646707296371460e-01
    z[2,5,0]  R1196     5.1118308305740356e-01
    z[2,5,0]  R1197     -8.3527660369873047e-01
    z[2,5,0]  R1198     -4.7554358839988708e-01
    z[2,5,0]  R1199     -5.4265040159225464e-01
    z[2,5,0]  R1200     4.9199834465980530e-01
    z[2,5,0]  R1201     6.2315154075622559e-01
    z[2,5,0]  R1202     -5.2788324654102325e-02
    z[2,5,0]  R1203     4.3013170361518860e-01
    z[2,5,0]  R1204     0.500211238861084
    z[2,5,0]  R1205     -4.3523499369621277e-01
    z[2,5,0]  R1206     -5.9402501583099365e-01
    z[2,5,0]  R1207     -0.832075297832489
    z[2,5,0]  R1208     -5.5556356906890869e-01
    z[2,5,0]  R1209     -8.5553938150405884e-01
    z[2,5,0]  R1210     -7.5360065698623657e-01
    z[2,5,0]  R1211     7.5770670175552368e-01
    z[2,5,0]  R1212     1.5656508505344391e-01
    z[2,5,0]  R1213     -2.8213843703269958e-01
    z[2,5,0]  R1214     -2.8486687690019608e-02
    z[2,5,0]  R1215     4.7304117679595947e-01
    z[2,5,0]  R1216     -8.5314494371414185e-01
    z[2,5,0]  R1217     -6.6401398181915283e-01
    z[2,5,0]  R1218     -9.0782427787780762e-01
    z[2,5,0]  R1219     -6.1012154817581177e-01
    z[2,5,0]  R1220     5.7783633470535278e-01
    z[2,5,0]  R1221     4.4784688949584961e-01
    z[2,5,0]  R1222     -4.8408564925193787e-01
    z[2,5,0]  R1223     -0.672747015953064
    z[2,5,0]  R1224     -4.9150905013084412e-01
    z[2,5,0]  R1225     5.8502227067947388e-01
    z[2,5,0]  R1226     6.6070383787155151e-01
    z[2,5,0]  R1227     6.8326950073242188e-01
    z[2,5,0]  R1228     6.8778365850448608e-01
    z[2,5,0]  R1229     6.7371368408203125e-01
    z[2,5,0]  R1230     -8.9634925127029419e-01
    z[2,5,0]  R1231     5.8706700801849365e-01
    z[2,5,0]  R1232     6.3879698514938354e-01
    z[2,5,0]  R1233     6.2776446342468262e-01
    z[2,5,0]  R1234     4.9042728543281555e-01
    z[2,5,0]  R1235     -4.4271769002079964e-03
    z[2,5,0]  R1236     3.7055447697639465e-02
    z[2,5,0]  R1237     5.4906487464904785e-01
    z[2,5,0]  R1238     5.7185983657836914e-01
    z[2,5,0]  R1239     2.9208138585090637e-01
    z[2,5,1]  R21       -1
    z[2,5,1]  R48       1
    z[2,5,1]  R1058     -1
    z[2,5,1]  R1059     1
    z[2,5,1]  R1070     1.6793204471468925e-02
    z[2,5,1]  R1071     4.1982802748680115e-01
    z[2,5,1]  R1072     -3.0217638611793518e-01
    z[2,5,1]  R1073     3.3735528588294983e-01
    z[2,5,1]  R1074     -2.1396717429161072e-01
    z[2,5,1]  R1075     -1.4922298491001129e-01
    z[2,5,1]  R1076     -4.6211519837379456e-01
    z[2,5,1]  R1077     -2.4508625268936157e-01
    z[2,5,1]  R1078     -1.8263725936412811e-01
    z[2,5,1]  R1079     -2.3488880693912506e-01
    z[2,5,1]  R1080     -1.6358684003353119e-01
    z[2,5,1]  R1081     5.3442692756652832e-01
    z[2,5,1]  R1082     5.0623804330825806e-01
    z[2,5,1]  R1083     4.6645689010620117e-01
    z[2,5,1]  R1084     6.5295898914337158e-01
    z[2,5,1]  R1085     -9.4652932882308960e-01
    z[2,5,1]  R1086     -0.909305214881897
    z[2,5,1]  R1087     6.1326795816421509e-01
    z[2,5,1]  R1088     5.5151903629302979e-01
    z[2,5,1]  R1089     4.0061524510383606e-01
    z[2,5,1]  R1090     -0.264529287815094
    z[2,5,1]  R1091     -1.4760753512382507e-01
    z[2,5,1]  R1092     7.9781192541122437e-01
    z[2,5,1]  R1093     -1.7197097837924957e-01
    z[2,5,1]  R1094     1.4941245317459106e-01
    z[2,5,1]  R1095     4.4548544287681580e-01
    z[2,5,1]  R1096     0.653929591178894
    z[2,5,1]  R1097     4.0577349066734314e-01
    z[2,5,1]  R1098     -3.6976438760757446e-01
    z[2,5,1]  R1099     -6.7304052412509918e-02
    z[2,5,1]  R1100     4.9294161796569824e-01
    z[2,5,1]  R1101     3.5584241151809692e-01
    z[2,5,1]  R1102     3.9754968881607056e-01
    z[2,5,1]  R1103     1.6869686543941498e-02
    z[2,5,1]  R1104     7.1616090834140778e-02
    z[2,5,1]  R1105     2.5303310155868530e-01
    z[2,5,1]  R1106     -1.7502473667263985e-02
    z[2,5,1]  R1107     6.7946580238640308e-03
    z[2,5,1]  R1108     -4.3117246031761169e-01
    z[2,5,1]  R1109     3.8872316479682922e-01
    z[2,5,1]  R1110     -1.3841395080089569e-01
    z[2,5,1]  R1111     -4.6720635145902634e-02
    z[2,5,1]  R1112     5.3251668810844421e-02
    z[2,5,1]  R1113     3.9715209603309631e-01
    z[2,5,1]  R1114     -2.7576866745948792e-01
    z[2,5,1]  R1115     4.9373021721839905e-01
    z[2,5,1]  R1116     -5.0862950086593628e-01
    z[2,5,1]  R1117     -4.7206935286521912e-01
    z[2,5,1]  R1118     -9.2534351348876953e-01
    z[2,5,1]  R1119     -9.3733829259872437e-01
    z[2,5,1]  R1120     5.0692892074584961e-01
    z[2,5,1]  R1121     5.6872403621673584e-01
    z[2,5,1]  R1122     -5.3618443012237549e-01
    z[2,5,1]  R1123     -6.4487606287002563e-01
    z[2,5,1]  R1124     -3.6818471550941467e-01
    z[2,5,1]  R1125     -7.2963792085647583e-01
    z[2,5,1]  R1126     -8.2487720251083374e-01
    z[2,5,1]  R1127     7.6968425512313843e-01
    z[2,5,1]  R1128     -7.7254432439804077e-01
    z[2,5,1]  R1129     -2.3884780704975128e-01
    z[2,5,1]  R1130     3.0962151288986206e-01
    z[2,5,1]  R1131     -5.0188940763473511e-01
    z[2,5,1]  R1132     -9.2821039259433746e-02
    z[2,5,1]  R1133     -2.9327511787414551e-01
    z[2,5,1]  R1134     -0.954384446144104
    z[2,5,1]  R1135     -8.4556078910827637e-01
    z[2,5,1]  R1136     -1.5219414234161377e-01
    z[2,5,1]  R1137     -8.5327720642089844e-01
    z[2,5,1]  R1138     -8.0013388395309448e-01
    z[2,5,1]  R1139     -0.837171733379364
    z[2,5,1]  R1140     5.9243518114089966e-01
    z[2,5,1]  R1141     5.3607380390167236e-01
    z[2,5,1]  R1142     5.0177198648452759e-01
    z[2,5,1]  R1143     -4.3665003776550293e-01
    z[2,5,1]  R1144     -9.2628234624862671e-01
    z[2,5,1]  R1145     -8.7773799896240234e-01
    z[2,5,1]  R1146     9.4409698247909546e-01
    z[2,5,1]  R1147     9.3283069133758545e-01
    z[2,5,1]  R1148     4.4027809053659439e-02
    z[2,5,1]  R1149     -4.1449481248855591e-01
    z[2,5,1]  R1150     5.1057547330856323e-01
    z[2,5,1]  R1151     3.1768313050270081e-01
    z[2,5,1]  R1152     4.8648440837860107e-01
    z[2,5,1]  R1153     4.7185283899307251e-01
    z[2,5,1]  R1154     4.4452327489852905e-01
    z[2,5,1]  R1155     -4.0931418538093567e-02
    z[2,5,1]  R1156     3.4900563955307007e-01
    z[2,5,1]  R1157     4.5200872421264648e-01
    z[2,5,1]  R1158     6.1654180288314819e-01
    z[2,5,1]  R1159     3.8457027077674866e-01
    z[2,5,1]  R1160     2.4004091322422028e-01
    z[2,5,1]  R1161     -4.3289753794670105e-01
    z[2,5,1]  R1162     -0.192816823720932
    z[2,5,1]  R1163     -2.1364213526248932e-01
    z[2,5,1]  R1164     -2.2704876959323883e-01
    z[2,5,1]  R1165     -2.5199401378631592e-01
    z[2,5,1]  R1166     -2.0157837867736816e-01
    z[2,5,1]  R1167     -1.9670151174068451e-01
    z[2,5,1]  R1168     -2.3894466459751129e-01
    z[2,5,1]  R1169     -2.3336625099182129e-01
    z[2,5,1]  R1170     3.4802475571632385e-01
    z[2,5,1]  R1171     7.8177338838577271e-01
    z[2,5,1]  R1172     2.4236483871936798e-01
    z[2,5,1]  R1173     1.7813818156719208e-01
    z[2,5,1]  R1174     8.5366815328598022e-01
    z[2,5,1]  R1175     6.6496598720550537e-01
    z[2,5,1]  R1176     3.4388515353202820e-01
    z[2,5,1]  R1177     -3.1246135011315346e-02
    z[2,5,1]  R1178     -1.8710640072822571e-01
    z[2,5,1]  R1179     -7.2522288560867310e-01
    z[2,5,1]  R1180     5.2543687820434570e-01
    z[2,5,1]  R1181     5.8598470687866211e-01
    z[2,5,1]  R1182     0.849338948726654
    z[2,5,1]  R1183     7.1854478120803833e-01
    z[2,5,1]  R1184     4.8190990090370178e-01
    z[2,5,1]  R1185     -1.8543800711631775e-01
    z[2,5,1]  R1186     -3.7781310081481934e-01
    z[2,5,1]  R1187     -5.2031236886978149e-01
    z[2,5,1]  R1188     -6.2621653079986572e-01
    z[2,5,1]  R1189     1.9602222368121147e-02
    z[2,5,1]  R1190     7.7178794145584106e-01
    z[2,5,1]  R1191     7.8734922409057617e-01
    z[2,5,1]  R1192     6.1397576332092285e-01
    z[2,5,1]  R1193     8.8871586322784424e-01
    z[2,5,1]  R1194     0.267733097076416
    z[2,5,1]  R1195     3.3866789937019348e-01
    z[2,5,1]  R1196     5.2049368619918823e-01
    z[2,5,1]  R1197     -1.1216162145137787e-01
    z[2,5,1]  R1198     3.0052950978279114e-01
    z[2,5,1]  R1199     -3.2113844156265259e-01
    z[2,5,1]  R1200     4.7029018402099609e-01
    z[2,5,1]  R1201     3.7659695744514465e-01
    z[2,5,1]  R1202     0.0677233412861824
    z[2,5,1]  R1203     1.5144044160842896e-01
    z[2,5,1]  R1204     5.7834458351135254e-01
    z[2,5,1]  R1205     5.1786535978317261e-01
    z[2,5,1]  R1206     -2.8375563025474548e-01
    z[2,5,1]  R1207     -3.4214520454406738e-01
    z[2,5,1]  R1208     -3.3144152164459229e-01
    z[2,5,1]  R1209     -0.0317201092839241
    z[2,5,1]  R1210     1.1143982410430908e-01
    z[2,5,1]  R1211     4.7424244880676270e-01
    z[2,5,1]  R1212     8.5829752683639526e-01
    z[2,5,1]  R1213     3.1502538919448853e-01
    z[2,5,1]  R1214     4.6628189086914062e-01
    z[2,5,1]  R1215     5.6245517730712891e-01
    z[2,5,1]  R1216     -2.7969694137573242e-01
    z[2,5,1]  R1217     -4.1869038343429565e-01
    z[2,5,1]  R1218     -2.2984184324741364e-01
    z[2,5,1]  R1219     -3.1074598431587219e-02
    z[2,5,1]  R1220     7.8660178184509277e-01
    z[2,5,1]  R1221     6.3052386045455933e-01
    z[2,5,1]  R1222     1.7272271215915680e-01
    z[2,5,1]  R1223     -3.2018333673477173e-01
    z[2,5,1]  R1224     -2.6289907097816467e-01
    z[2,5,1]  R1225     -3.7370449304580688e-01
    z[2,5,1]  R1226     -5.1204943656921387e-01
    z[2,5,1]  R1227     -3.6264434456825256e-01
    z[2,5,1]  R1228     -5.7322126626968384e-01
    z[2,5,1]  R1229     -4.6222689747810364e-01
    z[2,5,1]  R1230     -9.9885143339633942e-02
    z[2,5,1]  R1231     -4.1757720708847046e-01
    z[2,5,1]  R1232     -5.2153486013412476e-01
    z[2,5,1]  R1233     -5.8511340618133545e-01
    z[2,5,1]  R1234     -6.2838965654373169e-01
    z[2,5,1]  R1235     -7.2098881006240845e-01
    z[2,5,1]  R1236     -8.9664030075073242e-01
    z[2,5,1]  R1237     -5.7314264774322510e-01
    z[2,5,1]  R1238     -4.7685539722442627e-01
    z[2,5,1]  R1239     -5.5895823240280151e-01
    z[2,5,2]  R22       -1
    z[2,5,2]  R49       1
    z[2,5,2]  R1060     -1
    z[2,5,2]  R1061     1
    z[2,5,2]  R1070     5.3428955376148224e-02
    z[2,5,2]  R1071     4.7465705871582031e-01
    z[2,5,2]  R1072     3.6648120731115341e-02
    z[2,5,2]  R1073     0.377734899520874
    z[2,5,2]  R1074     6.5484158694744110e-02
    z[2,5,2]  R1075     -1.2441141903400421e-01
    z[2,5,2]  R1076     2.5291427969932556e-01
    z[2,5,2]  R1077     -2.6075729727745056e-01
    z[2,5,2]  R1078     -2.3586069047451019e-01
    z[2,5,2]  R1079     2.9757454991340637e-01
    z[2,5,2]  R1080     1.2146435678005219e-01
    z[2,5,2]  R1081     -4.2763182520866394e-01
    z[2,5,2]  R1082     0.0552813895046711
    z[2,5,2]  R1083     -3.2051667571067810e-01
    z[2,5,2]  R1084     -5.6332081556320190e-01
    z[2,5,2]  R1085     4.8455204814672470e-02
    z[2,5,2]  R1086     2.8371301293373108e-01
    z[2,5,2]  R1087     -2.1615797281265259e-01
    z[2,5,2]  R1088     -3.4118276834487915e-01
    z[2,5,2]  R1089     -4.3730372190475464e-01
    z[2,5,2]  R1090     4.1211673617362976e-01
    z[2,5,2]  R1091     4.9223366379737854e-01
    z[2,5,2]  R1092     -1.7958946526050568e-02
    z[2,5,2]  R1093     4.7048786282539368e-01
    z[2,5,2]  R1094     -3.8058489561080933e-01
    z[2,5,2]  R1095     -3.2974272966384888e-01
    z[2,5,2]  R1096     5.8110468089580536e-02
    z[2,5,2]  R1097     -1.9358810782432556e-01
    z[2,5,2]  R1098     -6.7814439535140991e-01
    z[2,5,2]  R1099     -0.0276302732527256
    z[2,5,2]  R1100     -1.1719395220279694e-01
    z[2,5,2]  R1101     -9.6887126564979553e-02
    z[2,5,2]  R1102     3.9203721284866333e-01
    z[2,5,2]  R1103     -9.0094834566116333e-02
    z[2,5,2]  R1104     4.0363538265228271e-01
    z[2,5,2]  R1105     2.3727929592132568e-01
    z[2,5,2]  R1106     3.7829467654228210e-01
    z[2,5,2]  R1107     2.0727132260799408e-01
    z[2,5,2]  R1108     -3.5161191225051880e-01
    z[2,5,2]  R1109     -1.8203815817832947e-01
    z[2,5,2]  R1110     5.9477311372756958e-01
    z[2,5,2]  R1111     3.3852979540824890e-01
    z[2,5,2]  R1112     0.564498245716095
    z[2,5,2]  R1113     -3.1396320462226868e-01
    z[2,5,2]  R1114     1.2137076258659363e-01
    z[2,5,2]  R1115     -3.5435834527015686e-01
    z[2,5,2]  R1116     -0.539020299911499
    z[2,5,2]  R1117     -2.3951514065265656e-01
    z[2,5,2]  R1118     1.6637371480464935e-01
    z[2,5,2]  R1119     -6.2574379146099091e-02
    z[2,5,2]  R1120     1.5445311367511749e-01
    z[2,5,2]  R1121     -3.8655731081962585e-01
    z[2,5,2]  R1122     -2.5803402066230774e-01
    z[2,5,2]  R1123     -5.0074491649866104e-02
    z[2,5,2]  R1124     -1.7812184989452362e-01
    z[2,5,2]  R1125     6.3637781143188477e-01
    z[2,5,2]  R1126     4.4004756212234497e-01
    z[2,5,2]  R1127     -3.7844008207321167e-01
    z[2,5,2]  R1128     4.7437658905982971e-01
    z[2,5,2]  R1129     -1.9614732265472412e-01
    z[2,5,2]  R1130     2.9345509409904480e-01
    z[2,5,2]  R1131     1.8945498391985893e-02
    z[2,5,2]  R1132     -2.8382557630538940e-01
    z[2,5,2]  R1133     -7.5607880949974060e-02
    z[2,5,2]  R1134     4.0291804820299149e-02
    z[2,5,2]  R1135     -3.9303341507911682e-01
    z[2,5,2]  R1136     2.5031521916389465e-01
    z[2,5,2]  R1137     3.0954939126968384e-01
    z[2,5,2]  R1138     2.4709241092205048e-01
    z[2,5,2]  R1139     -1.3379940390586853e-01
    z[2,5,2]  R1140     0.374731183052063
    z[2,5,2]  R1141     -2.3399564623832703e-01
    z[2,5,2]  R1142     -1.5763019025325775e-01
    z[2,5,2]  R1143     -2.4272593855857849e-01
    z[2,5,2]  R1144     1.6245366632938385e-01
    z[2,5,2]  R1145     -2.3109002411365509e-01
    z[2,5,2]  R1146     5.0432592630386353e-02
    z[2,5,2]  R1147     1.3996334373950958e-01
    z[2,5,2]  R1148     0.632743239402771
    z[2,5,2]  R1149     -1.8757671117782593e-01
    z[2,5,2]  R1150     0.225607231259346
    z[2,5,2]  R1151     3.1976962089538574e-01
    z[2,5,2]  R1152     2.1875400841236115e-01
    z[2,5,2]  R1153     4.4502955675125122e-01
    z[2,5,2]  R1154     -4.7080716490745544e-01
    z[2,5,2]  R1155     -4.1226577758789062e-01
    z[2,5,2]  R1156     1.5544793009757996e-01
    z[2,5,2]  R1157     3.5547360777854919e-01
    z[2,5,2]  R1158     -3.2983991503715515e-01
    z[2,5,2]  R1159     4.8570439219474792e-01
    z[2,5,2]  R1160     2.3494124412536621e-01
    z[2,5,2]  R1161     6.5841847658157349e-01
    z[2,5,2]  R1162     8.0758494138717651e-01
    z[2,5,2]  R1163     6.8192929029464722e-01
    z[2,5,2]  R1164     6.5245223045349121e-01
    z[2,5,2]  R1165     6.6472548246383667e-01
    z[2,5,2]  R1166     0.639353334903717
    z[2,5,2]  R1167     6.3165879249572754e-01
    z[2,5,2]  R1168     7.7503788471221924e-01
    z[2,5,2]  R1169     5.7745563983917236e-01
    z[2,5,2]  R1170     2.3937088251113892e-01
    z[2,5,2]  R1171     2.8595605492591858e-01
    z[2,5,2]  R1172     -4.6420689672231674e-02
    z[2,5,2]  R1173     -2.5077894330024719e-01
    z[2,5,2]  R1174     1.2380032241344452e-01
    z[2,5,2]  R1175     -3.7403452396392822e-01
    z[2,5,2]  R1176     -7.1206778287887573e-01
    z[2,5,2]  R1177     -4.7657048702239990e-01
    z[2,5,2]  R1178     -2.1853515505790710e-01
    z[2,5,2]  R1179     -5.7819854468107224e-02
    z[2,5,2]  R1180     -4.0094745159149170e-01
    z[2,5,2]  R1181     -6.7131072282791138e-01
    z[2,5,2]  R1182     -4.1002368927001953e-01
    z[2,5,2]  R1183     -2.6114150881767273e-01
    z[2,5,2]  R1184     4.2280846834182739e-01
    z[2,5,2]  R1185     -2.4369031190872192e-01
    z[2,5,2]  R1186     0.328095406293869
    z[2,5,2]  R1187     3.8787674903869629e-01
    z[2,5,2]  R1188     2.9203245043754578e-01
    z[2,5,2]  R1189     -2.7586886286735535e-01
    z[2,5,2]  R1190     -2.2261705994606018e-01
    z[2,5,2]  R1191     3.4349447488784790e-01
    z[2,5,2]  R1192     -1.4417226612567902e-01
    z[2,5,2]  R1193     -1.2380160391330719e-01
    z[2,5,2]  R1194     -0.395833283662796
    z[2,5,2]  R1195     2.3510010540485382e-01
    z[2,5,2]  R1196     -2.0400816202163696e-01
    z[2,5,2]  R1197     -9.6323236823081970e-02
    z[2,5,2]  R1198     3.9766165614128113e-01
    z[2,5,2]  R1199     2.9063206911087036e-01
    z[2,5,2]  R1200     6.3487243652343750e-01
    z[2,5,2]  R1201     3.7208899855613708e-01
    z[2,5,2]  R1202     1.3445743918418884e-01
    z[2,5,2]  R1203     -4.3952378630638123e-01
    z[2,5,2]  R1204     -2.9135462641716003e-01
    z[2,5,2]  R1205     0.0922401174902916
    z[2,5,2]  R1206     4.4079285860061646e-01
    z[2,5,2]  R1207     -3.1065413355827332e-01
    z[2,5,2]  R1208     0.355376273393631
    z[2,5,2]  R1209     1.2634010612964630e-01
    z[2,5,2]  R1210     -4.2379835247993469e-01
    z[2,5,2]  R1211     3.0889004468917847e-01
    z[2,5,2]  R1212     -3.6990982294082642e-01
    z[2,5,2]  R1213     3.5622832179069519e-01
    z[2,5,2]  R1214     -4.7861674427986145e-01
    z[2,5,2]  R1215     -1.3612095499411225e-03
    z[2,5,2]  R1216     -1.4447963237762451e-01
    z[2,5,2]  R1217     2.8854611515998840e-01
    z[2,5,2]  R1218     2.1654902398586273e-01
    z[2,5,2]  R1219     6.2843970954418182e-02
    z[2,5,2]  R1220     -1.7592564225196838e-01
    z[2,5,2]  R1221     2.0112448930740356e-01
    z[2,5,2]  R1222     3.3232292532920837e-01
    z[2,5,2]  R1223     4.4547894597053528e-01
    z[2,5,2]  R1224     3.8438367843627930e-01
    z[2,5,2]  R1225     5.4896640777587891e-01
    z[2,5,2]  R1226     5.2453732490539551e-01
    z[2,5,2]  R1227     2.7125416323542595e-02
    z[2,5,2]  R1228     1.1758831888437271e-01
    z[2,5,2]  R1229     -1.3787375390529633e-01
    z[2,5,2]  R1230     -1.0769053548574448e-01
    z[2,5,2]  R1231     5.5269473791122437e-01
    z[2,5,2]  R1232     1.5828667581081390e-01
    z[2,5,2]  R1233     3.8291251659393311e-01
    z[2,5,2]  R1234     5.5537527799606323e-01
    z[2,5,2]  R1235     0.521673321723938
    z[2,5,2]  R1236     3.5263195633888245e-01
    z[2,5,2]  R1237     5.3273621946573257e-02
    z[2,5,2]  R1238     2.5538769364356995e-01
    z[2,5,2]  R1239     -2.4770677089691162e-01
    z[2,5,3]  R23       -1
    z[2,5,3]  R50       1
    z[2,5,3]  R1062     -1
    z[2,5,3]  R1063     1
    z[2,5,3]  R1070     -5.7658666372299194e-01
    z[2,5,3]  R1071     -4.8413532972335815e-01
    z[2,5,3]  R1072     5.0298297405242920e-01
    z[2,5,3]  R1073     -3.8413512706756592e-01
    z[2,5,3]  R1074     6.3380491733551025e-01
    z[2,5,3]  R1075     4.7572395205497742e-01
    z[2,5,3]  R1076     -4.7816762328147888e-01
    z[2,5,3]  R1077     4.1079682111740112e-01
    z[2,5,3]  R1078     6.8301928043365479e-01
    z[2,5,3]  R1079     4.1419026255607605e-01
    z[2,5,3]  R1080     5.2072703838348389e-01
    z[2,5,3]  R1081     -4.7158092260360718e-01
    z[2,5,3]  R1082     -4.2060464620590210e-01
    z[2,5,3]  R1083     -2.1827220916748047e-02
    z[2,5,3]  R1084     -4.3719586730003357e-01
    z[2,5,3]  R1085     2.4062652885913849e-01
    z[2,5,3]  R1086     1.5694554895162582e-02
    z[2,5,3]  R1087     4.5493260025978088e-01
    z[2,5,3]  R1088     -5.2448230981826782e-01
    z[2,5,3]  R1089     1.5438485145568848e-01
    z[2,5,3]  R1090     -9.3475859612226486e-03
    z[2,5,3]  R1091     -7.0925705134868622e-02
    z[2,5,3]  R1092     -3.5661661624908447e-01
    z[2,5,3]  R1093     3.1329268217086792e-01
    z[2,5,3]  R1094     -7.3681735992431641e-01
    z[2,5,3]  R1095     1.6105762124061584e-01
    z[2,5,3]  R1096     2.0723575726151466e-03
    z[2,5,3]  R1097     -8.0785721540451050e-01
    z[2,5,3]  R1098     2.6825010776519775e-01
    z[2,5,3]  R1099     1.4808334410190582e-01
    z[2,5,3]  R1100     -5.6925994157791138e-01
    z[2,5,3]  R1101     -7.7147370576858521e-01
    z[2,5,3]  R1102     -5.1840478181838989e-01
    z[2,5,3]  R1103     -3.9839029312133789e-01
    z[2,5,3]  R1104     -1.6759096086025238e-01
    z[2,5,3]  R1105     2.2435568273067474e-01
    z[2,5,3]  R1106     -5.7995975017547607e-01
    z[2,5,3]  R1107     -5.5508546531200409e-02
    z[2,5,3]  R1108     -0.162618488073349
    z[2,5,3]  R1109     -1.8966302275657654e-01
    z[2,5,3]  R1110     -1.6043733060359955e-01
    z[2,5,3]  R1111     -3.4989330917596817e-02
    z[2,5,3]  R1112     -4.5814856886863708e-01
    z[2,5,3]  R1113     -4.3502718210220337e-01
    z[2,5,3]  R1114     -4.5113736391067505e-01
    z[2,5,3]  R1115     -1.7009107768535614e-01
    z[2,5,3]  R1116     2.9478520154953003e-01
    z[2,5,3]  R1117     1.8935614824295044e-01
    z[2,5,3]  R1118     2.7815201878547668e-01
    z[2,5,3]  R1119     1.7314006388187408e-01
    z[2,5,3]  R1120     -7.3491680622100830e-01
    z[2,5,3]  R1121     -5.5577796697616577e-01
    z[2,5,3]  R1122     1.8954205513000488e-01
    z[2,5,3]  R1123     4.7849395871162415e-01
    z[2,5,3]  R1124     6.3952714204788208e-02
    z[2,5,3]  R1125     -1.4681740105152130e-01
    z[2,5,3]  R1126     0.00597138237208128
    z[2,5,3]  R1127     2.1508035063743591e-01
    z[2,5,3]  R1128     1.8963800370693207e-01
    z[2,5,3]  R1129     6.0778830200433731e-02
    z[2,5,3]  R1130     -0.0553843230009079
    z[2,5,3]  R1131     0.38902547955513
    z[2,5,3]  R1132     2.6066571474075317e-01
    z[2,5,3]  R1133     3.7355315685272217e-01
    z[2,5,3]  R1134     -8.0543659627437592e-02
    z[2,5,3]  R1135     2.9656881093978882e-01
    z[2,5,3]  R1136     2.5672686100006104e-01
    z[2,5,3]  R1137     -2.0979759097099304e-01
    z[2,5,3]  R1138     7.3786050081253052e-02
    z[2,5,3]  R1139     2.5442928075790405e-01
    z[2,5,3]  R1140     -0.555517852306366
    z[2,5,3]  R1141     -3.0220049619674683e-01
    z[2,5,3]  R1142     -4.7199490666389465e-01
    z[2,5,3]  R1143     -1.3955840468406677e-01
    z[2,5,3]  R1144     -7.2610370814800262e-02
    z[2,5,3]  R1145     -3.0861049890518188e-01
    z[2,5,3]  R1146     9.9657423794269562e-02
    z[2,5,3]  R1147     1.7827060818672180e-01
    z[2,5,3]  R1148     -0.0658518373966217
    z[2,5,3]  R1149     -2.5762474536895752e-01
    z[2,5,3]  R1150     2.8614804148674011e-01
    z[2,5,3]  R1151     1.9862221181392670e-01
    z[2,5,3]  R1152     9.6923463046550751e-02
    z[2,5,3]  R1153     1.0683256387710571e-01
    z[2,5,3]  R1154     -3.4418621659278870e-01
    z[2,5,3]  R1155     -3.7811005115509033e-01
    z[2,5,3]  R1156     7.2333104908466339e-02
    z[2,5,3]  R1157     -1.9786326587200165e-01
    z[2,5,3]  R1158     -1.4166752994060516e-01
    z[2,5,3]  R1159     -8.8863588869571686e-02
    z[2,5,3]  R1160     -1.4615970849990845e-01
    z[2,5,3]  R1161     2.3510551452636719e-01
    z[2,5,3]  R1162     8.4521457552909851e-02
    z[2,5,3]  R1163     4.4326889514923096e-01
    z[2,5,3]  R1164     3.0297595262527466e-01
    z[2,5,3]  R1165     -6.4370416104793549e-02
    z[2,5,3]  R1166     2.6252093911170959e-01
    z[2,5,3]  R1167     2.3608949780464172e-01
    z[2,5,3]  R1168     -0.383390337228775
    z[2,5,3]  R1169     4.6426522731781006e-01
    z[2,5,3]  R1170     -5.3112649917602539e-01
    z[2,5,3]  R1171     -1.9288714230060577e-01
    z[2,5,3]  R1172     -2.5173398852348328e-01
    z[2,5,3]  R1173     -1.6380971670150757e-01
    z[2,5,3]  R1174     -9.9699504673480988e-02
    z[2,5,3]  R1175     1.8503373861312866e-01
    z[2,5,3]  R1176     5.2364283800125122e-01
    z[2,5,3]  R1177     5.2530074119567871e-01
    z[2,5,3]  R1178     1.2904337048530579e-01
    z[2,5,3]  R1179     -1.1997362226247787e-01
    z[2,5,3]  R1180     -2.3272280395030975e-01
    z[2,5,3]  R1181     4.1645620018243790e-02
    z[2,5,3]  R1182     2.0353603363037109e-01
    z[2,5,3]  R1183     1.6257666051387787e-01
    z[2,5,3]  R1184     -4.2788782715797424e-01
    z[2,5,3]  R1185     1.0887966305017471e-01
    z[2,5,3]  R1186     -2.7930095791816711e-01
    z[2,5,3]  R1187     -1.5871591866016388e-01
    z[2,5,3]  R1188     -0.0847240760922432
    z[2,5,3]  R1189     2.6343245059251785e-02
    z[2,5,3]  R1190     -2.5393217802047729e-01
    z[2,5,3]  R1191     -2.6008498668670654e-01
    z[2,5,3]  R1192     -2.3698411881923676e-01
    z[2,5,3]  R1193     -1.5202210843563080e-01
    z[2,5,3]  R1194     -5.7442313432693481e-01
    z[2,5,3]  R1195     -6.6975212097167969e-01
    z[2,5,3]  R1196     4.0605121850967407e-01
    z[2,5,3]  R1197     1.2707798182964325e-01
    z[2,5,3]  R1198     -5.3396087884902954e-01
    z[2,5,3]  R1199     -8.2362376153469086e-02
    z[2,5,3]  R1200     -4.7547496855258942e-02
    z[2,5,3]  R1201     0.0390746146440506
    z[2,5,3]  R1202     -7.0815253257751465e-01
    z[2,5,3]  R1203     -1.5038779377937317e-01
    z[2,5,3]  R1204     3.5058364272117615e-01
    z[2,5,3]  R1205     -1.2800544500350952e-01
    z[2,5,3]  R1206     1.1343742907047272e-01
    z[2,5,3]  R1207     1.1935079097747803e-01
    z[2,5,3]  R1208     2.7844834327697754e-01
    z[2,5,3]  R1209     3.0967876315116882e-01
    z[2,5,3]  R1210     -8.1400223076343536e-02
    z[2,5,3]  R1211     2.4099707603454590e-02
    z[2,5,3]  R1212     -5.8336075395345688e-02
    z[2,5,3]  R1213     -5.3081786632537842e-01
    z[2,5,3]  R1214     -3.9032605290412903e-01
    z[2,5,3]  R1215     -3.8091403245925903e-01
    z[2,5,3]  R1216     -1.1232873797416687e-01
    z[2,5,3]  R1217     2.5902670621871948e-01
    z[2,5,3]  R1218     -5.9855529107153416e-03
    z[2,5,3]  R1219     -2.2981157898902893e-01
    z[2,5,3]  R1220     0.0851278305053711
    z[2,5,3]  R1221     -4.1740727424621582e-01
    z[2,5,3]  R1222     -5.7617175579071045e-01
    z[2,5,3]  R1223     -4.9353456497192383e-01
    z[2,5,3]  R1224     1.1958824843168259e-01
    z[2,5,3]  R1225     -2.5140696763992310e-01
    z[2,5,3]  R1226     4.2824551463127136e-02
    z[2,5,3]  R1227     -3.0461966991424561e-02
    z[2,5,3]  R1228     0.380967378616333
    z[2,5,3]  R1229     1.2610933184623718e-01
    z[2,5,3]  R1230     6.9487184286117554e-02
    z[2,5,3]  R1231     -2.3484340310096741e-01
    z[2,5,3]  R1232     -4.0507983416318893e-02
    z[2,5,3]  R1233     2.1431854367256165e-01
    z[2,5,3]  R1234     -8.1822186708450317e-02
    z[2,5,3]  R1235     -2.6592493057250977e-01
    z[2,5,3]  R1236     -7.9549968242645264e-02
    z[2,5,3]  R1237     4.8030912876129150e-01
    z[2,5,3]  R1238     2.9239574074745178e-01
    z[2,5,3]  R1239     5.8321475982666016e-01
    z[2,5,4]  R24       -1
    z[2,5,4]  R51       1
    z[2,5,4]  R1064     -1
    z[2,5,4]  R1065     1
    z[2,5,4]  R1070     0.585985004901886
    z[2,5,4]  R1071     4.5392480492591858e-01
    z[2,5,4]  R1072     -4.9370858818292618e-02
    z[2,5,4]  R1073     2.9065108299255371e-01
    z[2,5,4]  R1074     0.0555245578289032
    z[2,5,4]  R1075     -8.8652148842811584e-02
    z[2,5,4]  R1076     1.3986818492412567e-01
    z[2,5,4]  R1077     1.1174959689378738e-01
    z[2,5,4]  R1078     -8.8005885481834412e-02
    z[2,5,4]  R1079     0.0831865444779396
    z[2,5,4]  R1080     -8.0534592270851135e-03
    z[2,5,4]  R1081     2.4362045526504517e-01
    z[2,5,4]  R1082     2.3618039488792419e-01
    z[2,5,4]  R1083     -3.3481118083000183e-01
    z[2,5,4]  R1084     1.1404404789209366e-01
    z[2,5,4]  R1085     -1.1398802697658539e-01
    z[2,5,4]  R1086     -8.5143849253654480e-02
    z[2,5,4]  R1087     -1.4496196806430817e-01
    z[2,5,4]  R1088     -2.6472138240933418e-02
    z[2,5,4]  R1089     3.2402139902114868e-01
    z[2,5,4]  R1090     1.8986824154853821e-01
    z[2,5,4]  R1091     -3.4458765387535095e-01
    z[2,5,4]  R1092     -1.5601888298988342e-01
    z[2,5,4]  R1093     -3.3036106824874878e-01
    z[2,5,4]  R1094     7.9754993319511414e-02
    z[2,5,4]  R1095     2.2440824657678604e-02
    z[2,5,4]  R1096     -5.4176026023924351e-03
    z[2,5,4]  R1097     -8.7099701166152954e-02
    z[2,5,4]  R1098     -3.8170254230499268e-01
    z[2,5,4]  R1099     2.8691646456718445e-01
    z[2,5,4]  R1100     0.372158020734787
    z[2,5,4]  R1101     4.3288782238960266e-02
    z[2,5,4]  R1102     -1.2515020370483398e-01
    z[2,5,4]  R1103     9.4737574458122253e-02
    z[2,5,4]  R1104     -1.8336981534957886e-01
    z[2,5,4]  R1105     3.9586311578750610e-01
    z[2,5,4]  R1106     -2.0542104542255402e-01
    z[2,5,4]  R1107     -3.3603996038436890e-02
    z[2,5,4]  R1108     2.5538778305053711e-01
    z[2,5,4]  R1109     -3.2243865728378296e-01
    z[2,5,4]  R1110     1.0967319458723068e-01
    z[2,5,4]  R1111     2.0001262426376343e-01
    z[2,5,4]  R1112     -2.1655750274658203e-01
    z[2,5,4]  R1113     4.7490587830543518e-01
    z[2,5,4]  R1114     -1.1311549693346024e-01
    z[2,5,4]  R1115     0.269917756319046
    z[2,5,4]  R1116     -6.3240818679332733e-02
    z[2,5,4]  R1117     -4.9538484215736389e-01
    z[2,5,4]  R1118     1.2240315973758698e-01
    z[2,5,4]  R1119     1.0413980484008789e-01
    z[2,5,4]  R1120     8.3759091794490814e-02
    z[2,5,4]  R1121     -5.6565467268228531e-02
    z[2,5,4]  R1122     -1.3234561309218407e-02
    z[2,5,4]  R1123     -5.1011848449707031e-01
    z[2,5,4]  R1124     -5.7242041826248169e-01
    z[2,5,4]  R1125     0.0806722566485405
    z[2,5,4]  R1126     2.3295298218727112e-01
    z[2,5,4]  R1127     6.3670896925032139e-03
    z[2,5,4]  R1128     1.4857368171215057e-01
    z[2,5,4]  R1129     -7.8706592321395874e-01
    z[2,5,4]  R1130     5.9010720252990723e-01
    z[2,5,4]  R1131     -4.9014893174171448e-01
    z[2,5,4]  R1132     3.4605216979980469e-01
    z[2,5,4]  R1133     -0.784143328666687
    z[2,5,4]  R1134     1.6048873960971832e-01
    z[2,5,4]  R1135     -1.6336247324943542e-01
    z[2,5,4]  R1136     -7.4287265539169312e-01
    z[2,5,4]  R1137     2.8813734650611877e-01
    z[2,5,4]  R1138     3.4640464186668396e-01
    z[2,5,4]  R1139     2.3118773102760315e-01
    z[2,5,4]  R1140     2.5349294766783714e-02
    z[2,5,4]  R1141     5.0959908962249756e-01
    z[2,5,4]  R1142     5.9191279113292694e-02
    z[2,5,4]  R1143     -1.9709999859333038e-01
    z[2,5,4]  R1144     2.4052542448043823e-01
    z[2,5,4]  R1145     -9.3885980546474457e-02
    z[2,5,4]  R1146     2.2049862891435623e-02
    z[2,5,4]  R1147     1.2017721310257912e-02
    z[2,5,4]  R1148     -1.8670603632926941e-01
    z[2,5,4]  R1149     4.3236309289932251e-01
    z[2,5,4]  R1150     -8.9635804295539856e-02
    z[2,5,4]  R1151     5.9240357950329781e-03
    z[2,5,4]  R1152     1.6294494271278381e-01
    z[2,5,4]  R1153     2.9447984695434570e-01
    z[2,5,4]  R1154     4.7585102915763855e-01
    z[2,5,4]  R1155     6.0992515087127686e-01
    z[2,5,4]  R1156     5.3177025169134140e-02
    z[2,5,4]  R1157     2.7024206519126892e-01
    z[2,5,4]  R1158     1.8455411493778229e-01
    z[2,5,4]  R1159     2.6636752486228943e-01
    z[2,5,4]  R1160     -0.532170832157135
    z[2,5,4]  R1161     -1.8462254106998444e-01
    z[2,5,4]  R1162     -2.2556984424591064e-01
    z[2,5,4]  R1163     2.7346667647361755e-01
    z[2,5,4]  R1164     1.0784591734409332e-01
    z[2,5,4]  R1165     2.4785001575946808e-01
    z[2,5,4]  R1166     2.0645757019519806e-01
    z[2,5,4]  R1167     3.7460610270500183e-01
    z[2,5,4]  R1168     0.00777652719989419
    z[2,5,4]  R1169     1.9684703648090363e-01
    z[2,5,4]  R1170     8.7425507605075836e-02
    z[2,5,4]  R1171     -3.7611982226371765e-01
    z[2,5,4]  R1172     8.4554873406887054e-02
    z[2,5,4]  R1173     4.4912289828062057e-02
    z[2,5,4]  R1174     -2.7962690591812134e-01
    z[2,5,4]  R1175     -1.9024184346199036e-01
    z[2,5,4]  R1176     -1.2297239154577255e-01
    z[2,5,4]  R1177     -1.7264726758003235e-01
    z[2,5,4]  R1178     -2.0380100607872009e-01
    z[2,5,4]  R1179     -1.6615694761276245e-01
    z[2,5,4]  R1180     4.9837347120046616e-02
    z[2,5,4]  R1181     1.0925633460283279e-01
    z[2,5,4]  R1182     -1.6090567409992218e-01
    z[2,5,4]  R1183     -2.3118624463677406e-02
    z[2,5,4]  R1184     1.8447768688201904e-01
    z[2,5,4]  R1185     -1.7895893752574921e-01
    z[2,5,4]  R1186     1.9566673040390015e-01
    z[2,5,4]  R1187     2.8256335854530334e-01
    z[2,5,4]  R1188     3.9508658647537231e-01
    z[2,5,4]  R1189     5.8149969577789307e-01
    z[2,5,4]  R1190     -1.5922186430543661e-03
    z[2,5,4]  R1191     -1.3166756927967072e-01
    z[2,5,4]  R1192     3.4759557247161865e-01
    z[2,5,4]  R1193     1.0526530444622040e-02
    z[2,5,4]  R1194     -1.4662112109363079e-02
    z[2,5,4]  R1195     5.3493720293045044e-01
    z[2,5,4]  R1196     -3.1676670908927917e-01
    z[2,5,4]  R1197     -3.7845450639724731e-01
    z[2,5,4]  R1198     -1.3518825289793313e-04
    z[2,5,4]  R1199     -3.3785271644592285e-01
    z[2,5,4]  R1200     -3.0541995167732239e-01
    z[2,5,4]  R1201     -1.8798868358135223e-01
    z[2,5,4]  R1202     6.7701435089111328e-01
    z[2,5,4]  R1203     6.3727504014968872e-01
    z[2,5,4]  R1204     -2.4129703640937805e-01
    z[2,5,4]  R1205     -2.4397027492523193e-01
    z[2,5,4]  R1206     2.3534847795963287e-01
    z[2,5,4]  R1207     -1.3661400973796844e-01
    z[2,5,4]  R1208     5.0487709045410156e-01
    z[2,5,4]  R1209     -5.3828172385692596e-02
    z[2,5,4]  R1210     1.3678911328315735e-01
    z[2,5,4]  R1211     -1.1057466268539429e-01
    z[2,5,4]  R1212     1.4980529248714447e-01
    z[2,5,4]  R1213     1.3441678881645203e-01
    z[2,5,4]  R1214     -5.0711023807525635e-01
    z[2,5,4]  R1215     3.5708293318748474e-01
    z[2,5,4]  R1216     6.6397930495440960e-03
    z[2,5,4]  R1217     3.1206998229026794e-01
    z[2,5,4]  R1218     1.1286263167858124e-01
    z[2,5,4]  R1219     5.7297468185424805e-02
    z[2,5,4]  R1220     -1.1313164606690407e-02
    z[2,5,4]  R1221     2.0030789077281952e-01
    z[2,5,4]  R1222     0.0537506528198719
    z[2,5,4]  R1223     9.6015287563204765e-03
    z[2,5,4]  R1224     -2.5005133822560310e-02
    z[2,5,4]  R1225     2.5555279850959778e-01
    z[2,5,4]  R1226     8.7121017277240753e-03
    z[2,5,4]  R1227     4.8978802561759949e-01
    z[2,5,4]  R1228     1.1990191414952278e-02
    z[2,5,4]  R1229     5.2671605348587036e-01
    z[2,5,4]  R1230     -0.384162575006485
    z[2,5,4]  R1231     2.5257727503776550e-01
    z[2,5,4]  R1232     3.8030573725700378e-01
    z[2,5,4]  R1233     -5.5059641599655151e-02
    z[2,5,4]  R1234     1.3978768885135651e-01
    z[2,5,4]  R1235     1.6580714285373688e-01
    z[2,5,4]  R1236     1.5398119390010834e-01
    z[2,5,4]  R1237     -1.0099439322948456e-01
    z[2,5,4]  R1238     -3.1638448126614094e-03
    z[2,5,4]  R1239     -3.8547852635383606e-01
    z[2,5,5]  R25       -1
    z[2,5,5]  R52       1
    z[2,5,5]  R1066     -1
    z[2,5,5]  R1067     1
    z[2,5,5]  R1070     4.0886640548706055e-01
    z[2,5,5]  R1071     1.1239586770534515e-01
    z[2,5,5]  R1072     -1.2824654579162598e-01
    z[2,5,5]  R1073     4.8890876770019531e-01
    z[2,5,5]  R1074     2.4667195975780487e-01
    z[2,5,5]  R1075     3.0765545368194580e-01
    z[2,5,5]  R1076     -1.6746150329709053e-02
    z[2,5,5]  R1077     -0.0683315098285675
    z[2,5,5]  R1078     1.2376486510038376e-01
    z[2,5,5]  R1079     3.5071703791618347e-01
    z[2,5,5]  R1080     -1.2956143915653229e-01
    z[2,5,5]  R1081     -3.2415542006492615e-01
    z[2,5,5]  R1082     -5.3670185804367065e-01
    z[2,5,5]  R1083     1.8109139800071716e-01
    z[2,5,5]  R1084     -9.8403267562389374e-02
    z[2,5,5]  R1085     -2.3633357137441635e-02
    z[2,5,5]  R1086     8.2218162715435028e-02
    z[2,5,5]  R1087     6.8722128868103027e-02
    z[2,5,5]  R1088     -1.4278912544250488e-01
    z[2,5,5]  R1089     -9.1430328786373138e-02
    z[2,5,5]  R1090     -6.5892316401004791e-02
    z[2,5,5]  R1091     1.1503832787275314e-01
    z[2,5,5]  R1092     -3.3437585830688477e-01
    z[2,5,5]  R1093     1.0261550545692444e-01
    z[2,5,5]  R1094     -3.5006096959114075e-01
    z[2,5,5]  R1095     -1.1785305291414261e-01
    z[2,5,5]  R1096     -1.3829918205738068e-01
    z[2,5,5]  R1097     -3.6164256930351257e-01
    z[2,5,5]  R1098     -2.0925061404705048e-01
    z[2,5,5]  R1099     1.5344475209712982e-01
    z[2,5,5]  R1100     -3.1367599964141846e-01
    z[2,5,5]  R1101     -3.9566081017255783e-02
    z[2,5,5]  R1102     -5.5153405666351318e-01
    z[2,5,5]  R1103     -2.1115562319755554e-01
    z[2,5,5]  R1104     -2.5290203094482422e-01
    z[2,5,5]  R1105     -3.4231055527925491e-02
    z[2,5,5]  R1106     -3.9365702867507935e-01
    z[2,5,5]  R1107     7.4246935546398163e-02
    z[2,5,5]  R1108     1.3931236229836941e-02
    z[2,5,5]  R1109     1.0323248058557510e-01
    z[2,5,5]  R1110     1.1458898894488811e-02
    z[2,5,5]  R1111     6.0198950767517090e-01
    z[2,5,5]  R1112     -5.7573366910219193e-02
    z[2,5,5]  R1113     -2.5862815976142883e-01
    z[2,5,5]  R1114     2.9186886548995972e-01
    z[2,5,5]  R1115     0.00526859937235713
    z[2,5,5]  R1116     2.1128852665424347e-01
    z[2,5,5]  R1117     -2.2448942065238953e-01
    z[2,5,5]  R1118     -2.1524254232645035e-02
    z[2,5,5]  R1119     2.6794016361236572e-01
    z[2,5,5]  R1120     -6.7306622862815857e-02
    z[2,5,5]  R1121     -4.4824701547622681e-01
    z[2,5,5]  R1122     2.5261655449867249e-01
    z[2,5,5]  R1123     9.6087656915187836e-02
    z[2,5,5]  R1124     1.1172868311405182e-02
    z[2,5,5]  R1125     -1.1932700127363205e-01
    z[2,5,5]  R1126     -9.9355757236480713e-02
    z[2,5,5]  R1127     0.0643991008400917
    z[2,5,5]  R1128     -1.3695776462554932e-01
    z[2,5,5]  R1129     6.5878160297870636e-02
    z[2,5,5]  R1130     2.0843271911144257e-01
    z[2,5,5]  R1131     1.0014345496892929e-01
    z[2,5,5]  R1132     2.5994306802749634e-01
    z[2,5,5]  R1133     -7.1071274578571320e-02
    z[2,5,5]  R1134     -1.0951571911573410e-01
    z[2,5,5]  R1135     1.1942744255065918e-01
    z[2,5,5]  R1136     2.3815682530403137e-01
    z[2,5,5]  R1137     1.6805014014244080e-01
    z[2,5,5]  R1138     3.5341310501098633e-01
    z[2,5,5]  R1139     -5.7587809860706329e-03
    z[2,5,5]  R1140     -4.3268963694572449e-01
    z[2,5,5]  R1141     -2.1182611584663391e-01
    z[2,5,5]  R1142     -1.6084384918212891e-01
    z[2,5,5]  R1143     -5.2090730518102646e-02
    z[2,5,5]  R1144     5.4125446826219559e-02
    z[2,5,5]  R1145     -2.0764803886413574e-01
    z[2,5,5]  R1146     1.2295242398977280e-01
    z[2,5,5]  R1147     2.0872300863265991e-01
    z[2,5,5]  R1148     1.1930776387453079e-01
    z[2,5,5]  R1149     -3.1884968280792236e-02
    z[2,5,5]  R1150     -7.5947046279907227e-03
    z[2,5,5]  R1151     -8.7791271507740021e-03
    z[2,5,5]  R1152     3.1882032752037048e-01
    z[2,5,5]  R1153     -5.7182990014553070e-02
    z[2,5,5]  R1154     -1.6890972852706909e-01
    z[2,5,5]  R1155     -6.4772136509418488e-02
    z[2,5,5]  R1156     1.0017333924770355e-01
    z[2,5,5]  R1157     0.231211319565773
    z[2,5,5]  R1158     5.7747727632522583e-01
    z[2,5,5]  R1159     2.6583153009414673e-01
    z[2,5,5]  R1160     2.2481076419353485e-01
    z[2,5,5]  R1161     1.3052079826593399e-02
    z[2,5,5]  R1162     1.5171720087528229e-01
    z[2,5,5]  R1163     -4.3023936450481415e-02
    z[2,5,5]  R1164     0.0353940911591053
    z[2,5,5]  R1165     4.4357147812843323e-01
    z[2,5,5]  R1166     4.7407639026641846e-01
    z[2,5,5]  R1167     6.2767281197011471e-03
    z[2,5,5]  R1168     -1.9781421124935150e-01
    z[2,5,5]  R1169     -1.9604696333408356e-01
    z[2,5,5]  R1170     1.9839632511138916e-01
    z[2,5,5]  R1171     3.3862125873565674e-01
    z[2,5,5]  R1172     -3.0617916956543922e-02
    z[2,5,5]  R1173     2.9147979617118835e-01
    z[2,5,5]  R1174     -3.6393553018569946e-01
    z[2,5,5]  R1175     -4.2408636212348938e-01
    z[2,5,5]  R1176     -1.2743981555104256e-02
    z[2,5,5]  R1177     -1.8517075479030609e-01
    z[2,5,5]  R1178     -3.0390882492065430e-01
    z[2,5,5]  R1179     -2.0238092541694641e-01
    z[2,5,5]  R1180     1.9782733917236328e-01
    z[2,5,5]  R1181     -9.8644390702247620e-02
    z[2,5,5]  R1182     -0.148346409201622
    z[2,5,5]  R1183     -4.6158552169799805e-01
    z[2,5,5]  R1184     -2.9842260479927063e-01
    z[2,5,5]  R1185     -3.4983307123184204e-01
    z[2,5,5]  R1186     -0.377279132604599
    z[2,5,5]  R1187     3.8751029968261719e-01
    z[2,5,5]  R1188     2.0157396793365479e-02
    z[2,5,5]  R1189     -3.3282953500747681e-01
    z[2,5,5]  R1190     5.0642937421798706e-01
    z[2,5,5]  R1191     -4.5824404805898666e-02
    z[2,5,5]  R1192     -6.2417805194854736e-01
    z[2,5,5]  R1193     -0.0754033774137497
    z[2,5,5]  R1194     -6.4436845481395721e-02
    z[2,5,5]  R1195     1.9234506785869598e-01
    z[2,5,5]  R1196     2.7806267142295837e-01
    z[2,5,5]  R1197     -2.3896206170320511e-02
    z[2,5,5]  R1198     -4.7335988283157349e-01
    z[2,5,5]  R1199     6.2632042169570923e-01
    z[2,5,5]  R1200     1.9467703998088837e-01
    z[2,5,5]  R1201     -4.9738940596580505e-01
    z[2,5,5]  R1202     -2.1414436399936676e-02
    z[2,5,5]  R1203     3.2057842612266541e-01
    z[2,5,5]  R1204     3.8099128007888794e-01
    z[2,5,5]  R1205     -6.7592531442642212e-01
    z[2,5,5]  R1206     5.3517264127731323e-01
    z[2,5,5]  R1207     2.1830736100673676e-01
    z[2,5,5]  R1208     -6.1397127807140350e-02
    z[2,5,5]  R1209     -2.8867498040199280e-01
    z[2,5,5]  R1210     -4.4239038228988647e-01
    z[2,5,5]  R1211     -2.9919949173927307e-01
    z[2,5,5]  R1212     -1.6329869627952576e-01
    z[2,5,5]  R1213     -5.9690177440643311e-01
    z[2,5,5]  R1214     1.0459543205797672e-02
    z[2,5,5]  R1215     3.1147959828376770e-01
    z[2,5,5]  R1216     9.0109594166278839e-02
    z[2,5,5]  R1217     3.6661437153816223e-01
    z[2,5,5]  R1218     -4.7735314816236496e-02
    z[2,5,5]  R1219     -2.3951521515846252e-01
    z[2,5,5]  R1220     -7.1482270956039429e-02
    z[2,5,5]  R1221     1.4146538078784943e-01
    z[2,5,5]  R1222     4.1564801335334778e-01
    z[2,5,5]  R1223     5.2571278065443039e-02
    z[2,5,5]  R1224     -6.4349097013473511e-01
    z[2,5,5]  R1225     -1.4879024028778076e-01
    z[2,5,5]  R1226     -4.0760420262813568e-02
    z[2,5,5]  R1227     2.3870344460010529e-01
    z[2,5,5]  R1228     -9.2644453048706055e-02
    z[2,5,5]  R1229     -1.2771388888359070e-01
    z[2,5,5]  R1230     1.2331591546535492e-01
    z[2,5,5]  R1231     -1.2022284418344498e-01
    z[2,5,5]  R1232     0.382844477891922
    z[2,5,5]  R1233     -9.3877725303173065e-02
    z[2,5,5]  R1234     -8.1795983016490936e-02
    z[2,5,5]  R1235     1.7924067378044128e-01
    z[2,5,5]  R1236     1.5473881363868713e-01
    z[2,5,5]  R1237     1.0495068877935410e-01
    z[2,5,5]  R1238     -3.1709831953048706e-01
    z[2,5,5]  R1239     -2.2529639303684235e-01
    z[2,5,6]  R26       -1
    z[2,5,6]  R53       1
    z[2,5,6]  R1068     -1
    z[2,5,6]  R1069     1
    z[2,5,6]  R1070     -2.7494572568684816e-03
    z[2,5,6]  R1071     1.4613977074623108e-01
    z[2,5,6]  R1072     -2.2966891992837191e-03
    z[2,5,6]  R1073     -3.0455753207206726e-01
    z[2,5,6]  R1074     -9.2454567551612854e-02
    z[2,5,6]  R1075     -1.3331221416592598e-02
    z[2,5,6]  R1076     0.0850360244512558
    z[2,5,6]  R1077     3.3200240135192871e-01
    z[2,5,6]  R1078     1.2971581518650055e-01
    z[2,5,6]  R1079     -1.3002598285675049e-01
    z[2,5,6]  R1080     6.4658035989850760e-04
    z[2,5,6]  R1081     1.4682596921920776e-01
    z[2,5,6]  R1082     4.6131512522697449e-01
    z[2,5,6]  R1083     -4.1206661611795425e-02
    z[2,5,6]  R1084     -7.7206864953041077e-02
    z[2,5,6]  R1085     9.6304953098297119e-02
    z[2,5,6]  R1086     -2.2544731199741364e-01
    z[2,5,6]  R1087     -1.8545429408550262e-01
    z[2,5,6]  R1088     -4.2595180869102478e-01
    z[2,5,6]  R1089     -2.8930693864822388e-01
    z[2,5,6]  R1090     -4.4820669293403625e-01
    z[2,5,6]  R1091     -2.8691756725311279e-01
    z[2,5,6]  R1092     1.0799196362495422e-01
    z[2,5,6]  R1093     9.8221465945243835e-02
    z[2,5,6]  R1094     1.4508076012134552e-01
    z[2,5,6]  R1095     2.2577278316020966e-01
    z[2,5,6]  R1096     -1.3321690261363983e-02
    z[2,5,6]  R1097     7.3098443448543549e-02
    z[2,5,6]  R1098     -1.0302697867155075e-01
    z[2,5,6]  R1099     7.0774590969085693e-01
    z[2,5,6]  R1100     4.1437754034996033e-01
    z[2,5,6]  R1101     -0.511720597743988
    z[2,5,6]  R1102     9.7146227955818176e-02
    z[2,5,6]  R1103     4.7523382306098938e-01
    z[2,5,6]  R1104     3.0004331469535828e-01
    z[2,5,6]  R1105     3.2768625020980835e-01
    z[2,5,6]  R1106     -9.6416510641574860e-02
    z[2,5,6]  R1107     3.9024993777275085e-01
    z[2,5,6]  R1108     0.500403881072998
    z[2,5,6]  R1109     -0.0842781662940979
    z[2,5,6]  R1110     0.275449275970459
    z[2,5,6]  R1111     -7.7913120388984680e-02
    z[2,5,6]  R1112     -4.7000306844711304e-01
    z[2,5,6]  R1113     -3.4643980860710144e-01
    z[2,5,6]  R1114     -7.0663958787918091e-01
    z[2,5,6]  R1115     6.0131076723337173e-02
    z[2,5,6]  R1116     -2.6651713252067566e-01
    z[2,5,6]  R1117     4.3111163377761841e-01
    z[2,5,6]  R1118     -1.1779459565877914e-01
    z[2,5,6]  R1119     -6.9593206048011780e-02
    z[2,5,6]  R1120     -3.2721498608589172e-01
    z[2,5,6]  R1121     -2.4010214954614639e-02
    z[2,5,6]  R1122     -4.3036383390426636e-01
    z[2,5,6]  R1123     -0.0923534482717514
    z[2,5,6]  R1124     -0.328215092420578
    z[2,5,6]  R1125     -1.4108602702617645e-01
    z[2,5,6]  R1126     6.2837995588779449e-02
    z[2,5,6]  R1127     -2.5084343552589417e-01
    z[2,5,6]  R1128     3.1831854581832886e-01
    z[2,5,6]  R1129     3.2484382390975952e-02
    z[2,5,6]  R1130     -0.148881196975708
    z[2,5,6]  R1131     3.3649137616157532e-01
    z[2,5,6]  R1132     5.4013800621032715e-01
    z[2,5,6]  R1133     -1.8159356713294983e-01
    z[2,5,6]  R1134     1.0902926325798035e-02
    z[2,5,6]  R1135     -4.0447127074003220e-02
    z[2,5,6]  R1136     -1.8995296210050583e-02
    z[2,5,6]  R1137     -1.1160200834274292e-01
    z[2,5,6]  R1138     6.0983393341302872e-02
    z[2,5,6]  R1139     3.1904298067092896e-01
    z[2,5,6]  R1140     2.1662132814526558e-02
    z[2,5,6]  R1141     -1.8995198607444763e-01
    z[2,5,6]  R1142     2.9376775026321411e-01
    z[2,5,6]  R1143     1.3069215416908264e-01
    z[2,5,6]  R1144     -8.4015779197216034e-02
    z[2,5,6]  R1145     -1.5442037582397461e-01
    z[2,5,6]  R1146     -1.0543386638164520e-01
    z[2,5,6]  R1147     -0.0949973315000534
    z[2,5,6]  R1148     4.1611364483833313e-01
    z[2,5,6]  R1149     -1.2132444977760315e-01
    z[2,5,6]  R1150     -1.4731016755104065e-01
    z[2,5,6]  R1151     -6.6391073167324066e-02
    z[2,5,6]  R1152     2.0331348478794098e-01
    z[2,5,6]  R1153     -8.5120923817157745e-02
    z[2,5,6]  R1154     -1.0575703531503677e-01
    z[2,5,6]  R1155     -0.09307861328125
    z[2,5,6]  R1156     2.4711626768112183e-01
    z[2,5,6]  R1157     2.0318250358104706e-01
    z[2,5,6]  R1158     -3.3131068944931030e-01
    z[2,5,6]  R1159     -6.8389378488063812e-02
    z[2,5,6]  R1160     3.6516536027193069e-02
    z[2,5,6]  R1161     0.0774056687951088
    z[2,5,6]  R1162     -1.4727701246738434e-01
    z[2,5,6]  R1163     -1.5174393355846405e-01
    z[2,5,6]  R1164     -4.7539597749710083e-01
    z[2,5,6]  R1165     2.2532801330089569e-01
    z[2,5,6]  R1166     8.6684837937355042e-02
    z[2,5,6]  R1167     3.5144168138504028e-01
    z[2,5,6]  R1168     -1.7987428605556488e-01
    z[2,5,6]  R1169     3.6844724416732788e-01
    z[2,5,6]  R1170     0.677962064743042
    z[2,5,6]  R1171     -5.9153027832508087e-02
    z[2,5,6]  R1172     0.919495165348053
    z[2,5,6]  R1173     0.814403235912323
    z[2,5,6]  R1174     -1.8726487457752228e-01
    z[2,5,6]  R1175     3.9939272403717041e-01
    z[2,5,6]  R1176     2.7433177828788757e-01
    z[2,5,6]  R1177     -3.4588745236396790e-01
    z[2,5,6]  R1178     5.4620647430419922e-01
    z[2,5,6]  R1179     -1.9505728781223297e-01
    z[2,5,6]  R1180     2.5381517410278320e-01
    z[2,5,6]  R1181     3.0845694709569216e-03
    z[2,5,6]  R1182     -0.074495330452919
    z[2,5,6]  R1183     -2.7877295017242432e-01
    z[2,5,6]  R1184     -3.9746654033660889e-01
    z[2,5,6]  R1185     -5.3462157957255840e-03
    z[2,5,6]  R1186     4.3215584754943848e-01
    z[2,5,6]  R1187     -8.3619892597198486e-02
    z[2,5,6]  R1188     -2.7281185984611511e-01
    z[2,5,6]  R1189     -3.6632496118545532e-01
    z[2,5,6]  R1190     1.1175787448883057e-01
    z[2,5,6]  R1191     -8.6105622351169586e-02
    z[2,5,6]  R1192     -3.7456639111042023e-02
    z[2,5,6]  R1193     3.1134110689163208e-01
    z[2,5,6]  R1194     2.9562366008758545e-01
    z[2,5,6]  R1195     -8.3799540996551514e-02
    z[2,5,6]  R1196     -2.8917360305786133e-01
    z[2,5,6]  R1197     -3.4714111685752869e-01
    z[2,5,6]  R1198     1.2736445665359497e-01
    z[2,5,6]  R1199     -6.8762958049774170e-02
    z[2,5,6]  R1200     -1.6143139451742172e-02
    z[2,5,6]  R1201     2.1712635457515717e-01
    z[2,5,6]  R1202     1.1941968649625778e-01
    z[2,5,6]  R1203     2.5954738259315491e-01
    z[2,5,6]  R1204     -6.4274176955223083e-02
    z[2,5,6]  R1205     -3.3101800829172134e-02
    z[2,5,6]  R1206     -1.3286098837852478e-01
    z[2,5,6]  R1207     -1.1625555902719498e-01
    z[2,5,6]  R1208     -3.4496295452117920e-01
    z[2,5,6]  R1209     2.6258850097656250e-01
    z[2,5,6]  R1210     1.3789756596088409e-01
    z[2,5,6]  R1211     5.6865904480218887e-02
    z[2,5,6]  R1212     -2.2241444885730743e-01
    z[2,5,6]  R1213     0.195271834731102
    z[2,5,6]  R1214     -3.7824764847755432e-01
    z[2,5,6]  R1215     3.0041828751564026e-01
    z[2,5,6]  R1216     -3.9020174741744995e-01
    z[2,5,6]  R1217     -4.0451325476169586e-02
    z[2,5,6]  R1218     2.4714720249176025e-01
    z[2,5,6]  R1219     -7.1370363235473633e-01
    z[2,5,6]  R1220     6.2678046524524689e-02
    z[2,5,6]  R1221     3.5645064711570740e-01
    z[2,5,6]  R1222     -3.4316653013229370e-01
    z[2,5,6]  R1223     -3.2001107465475798e-03
    z[2,5,6]  R1224     -3.3547705411911011e-01
    z[2,5,6]  R1225     2.5705745816230774e-01
    z[2,5,6]  R1226     1.5021668374538422e-01
    z[2,5,6]  R1227     -3.2108661532402039e-01
    z[2,5,6]  R1228     1.7515990138053894e-01
    z[2,5,6]  R1229     -6.1666302382946014e-02
    z[2,5,6]  R1230     -8.5834875702857971e-02
    z[2,5,6]  R1231     2.0520697534084320e-01
    z[2,5,6]  R1232     -4.5186918228864670e-02
    z[2,5,6]  R1233     2.4321815371513367e-01
    z[2,5,6]  R1234     -1.5244592726230621e-01
    z[2,5,6]  R1235     -2.7870634198188782e-01
    z[2,5,6]  R1236     1.2779383361339569e-01
    z[2,5,6]  R1237     -3.3953779935836792e-01
    z[2,5,6]  R1238     -0.440801203250885
    z[2,5,6]  R1239     -3.7467747926712036e-02
    z[5,2,0]  R20       1
    z[5,2,0]  R47       -1
    z[5,2,0]  R1240     -1
    z[5,2,0]  R1241     1
    z[5,2,0]  R1254     7.5943458080291748e-01
    z[5,2,0]  R1255     8.6767166852951050e-01
    z[5,2,0]  R1256     7.3249679803848267e-01
    z[5,2,0]  R1257     6.8604403734207153e-01
    z[5,2,0]  R1258     -4.4286161661148071e-01
    z[5,2,0]  R1259     -5.4820311069488525e-01
    z[5,2,0]  R1260     8.8026702404022217e-01
    z[5,2,0]  R1261     6.8000304698944092e-01
    z[5,2,0]  R1262     1.1706885695457458e-01
    z[5,2,0]  R1263     6.7970955371856689e-01
    z[5,2,0]  R1264     -7.2851979732513428e-01
    z[5,2,0]  R1265     -5.3250616788864136e-01
    z[5,2,0]  R1266     -4.5595401525497437e-01
    z[5,2,0]  R1267     -4.3952351808547974e-01
    z[5,2,0]  R1268     -4.3826425075531006e-01
    z[5,2,0]  R1269     -4.2607232928276062e-01
    z[5,2,0]  R1270     -4.5474034547805786e-01
    z[5,2,0]  R1271     -0.492642879486084
    z[5,2,0]  R1272     -3.5169291496276855e-01
    z[5,2,0]  R1273     -4.2849314212799072e-01
    z[5,2,0]  R1274     -1.8124037981033325e-01
    z[5,2,0]  R1275     1.0111644119024277e-01
    z[5,2,0]  R1276     -1.4891627430915833e-01
    z[5,2,0]  R1277     -3.5820782184600830e-01
    z[5,2,0]  R1278     1.6601191833615303e-02
    z[5,2,0]  R1279     -9.0139172971248627e-02
    z[5,2,0]  R1280     9.9790267646312714e-02
    z[5,2,0]  R1281     -5.5877542495727539e-01
    z[5,2,0]  R1282     -6.8435692787170410e-01
    z[5,2,0]  R1283     0.591355562210083
    z[5,2,0]  R1284     -0.634787917137146
    z[5,2,0]  R1285     -4.2726138234138489e-01
    z[5,2,0]  R1286     1.2502075731754303e-01
    z[5,2,0]  R1287     3.1266176700592041e-01
    z[5,2,0]  R1288     3.5332730412483215e-01
    z[5,2,0]  R1289     -8.6019468307495117e-01
    z[5,2,0]  R1290     -0.551559567451477
    z[5,2,0]  R1291     0.562705397605896
    z[5,2,0]  R1292     5.3335338830947876e-01
    z[5,2,0]  R1293     5.8284366130828857e-01
    z[5,2,0]  R1294     -1.4608344435691833e-01
    z[5,2,0]  R1295     4.0938743948936462e-01
    z[5,2,0]  R1296     1.8510198593139648e-01
    z[5,2,0]  R1297     2.6271072030067444e-01
    z[5,2,0]  R1298     5.9153407812118530e-01
    z[5,2,0]  R1299     2.2646707296371460e-01
    z[5,2,0]  R1300     5.1118308305740356e-01
    z[5,2,0]  R1301     -8.3527660369873047e-01
    z[5,2,0]  R1302     -4.7554358839988708e-01
    z[5,2,0]  R1303     -5.4265040159225464e-01
    z[5,2,0]  R1304     4.9199834465980530e-01
    z[5,2,0]  R1305     6.2315154075622559e-01
    z[5,2,0]  R1306     -5.2788324654102325e-02
    z[5,2,0]  R1307     4.3013170361518860e-01
    z[5,2,0]  R1308     0.500211238861084
    z[5,2,0]  R1309     -4.3523499369621277e-01
    z[5,2,0]  R1310     -5.9402501583099365e-01
    z[5,2,0]  R1311     -0.832075297832489
    z[5,2,0]  R1312     -5.5556356906890869e-01
    z[5,2,0]  R1313     -8.5553938150405884e-01
    z[5,2,0]  R1314     -7.5360065698623657e-01
    z[5,2,0]  R1315     7.5770670175552368e-01
    z[5,2,0]  R1316     1.5656508505344391e-01
    z[5,2,0]  R1317     -2.8213843703269958e-01
    z[5,2,0]  R1318     -2.8486687690019608e-02
    z[5,2,0]  R1319     4.7304117679595947e-01
    z[5,2,0]  R1320     -8.5314494371414185e-01
    z[5,2,0]  R1321     -6.6401398181915283e-01
    z[5,2,0]  R1322     -9.0782427787780762e-01
    z[5,2,0]  R1323     -6.1012154817581177e-01
    z[5,2,0]  R1324     5.7783633470535278e-01
    z[5,2,0]  R1325     4.4784688949584961e-01
    z[5,2,0]  R1326     -4.8408564925193787e-01
    z[5,2,0]  R1327     -0.672747015953064
    z[5,2,0]  R1328     -4.9150905013084412e-01
    z[5,2,0]  R1329     5.8502227067947388e-01
    z[5,2,0]  R1330     6.6070383787155151e-01
    z[5,2,0]  R1331     6.8326950073242188e-01
    z[5,2,0]  R1332     6.8778365850448608e-01
    z[5,2,0]  R1333     6.7371368408203125e-01
    z[5,2,0]  R1334     -8.9634925127029419e-01
    z[5,2,0]  R1335     5.8706700801849365e-01
    z[5,2,0]  R1336     6.3879698514938354e-01
    z[5,2,0]  R1337     6.2776446342468262e-01
    z[5,2,0]  R1338     4.9042728543281555e-01
    z[5,2,0]  R1339     -4.4271769002079964e-03
    z[5,2,0]  R1340     3.7055447697639465e-02
    z[5,2,0]  R1341     5.4906487464904785e-01
    z[5,2,0]  R1342     5.7185983657836914e-01
    z[5,2,0]  R1343     2.9208138585090637e-01
    z[5,2,0]  R1344     -3.9224180579185486e-01
    z[5,2,0]  R1345     -3.5216581821441650e-01
    z[5,2,0]  R1346     0.797160267829895
    z[5,2,0]  R1347     -4.2389002442359924e-01
    z[5,2,0]  R1348     6.8974149227142334e-01
    z[5,2,0]  R1349     7.9577147960662842e-01
    z[5,2,0]  R1350     -6.8320196866989136e-01
    z[5,2,0]  R1351     7.5881582498550415e-01
    z[5,2,0]  R1352     6.3608884811401367e-01
    z[5,2,0]  R1353     7.3341244459152222e-01
    z[5,2,0]  R1354     -8.1882697343826294e-01
    z[5,2,0]  R1355     3.5091996192932129e-01
    z[5,2,0]  R1356     8.4362350404262543e-02
    z[5,2,0]  R1357     -7.2980821132659912e-01
    z[5,2,0]  R1358     1.9111198186874390e-01
    z[5,2,0]  R1359     -1.4493685960769653e-01
    z[5,2,0]  R1360     -1.6609892249107361e-01
    z[5,2,0]  R1361     -5.5685228109359741e-01
    z[5,2,0]  R1362     0.319084495306015
    z[5,2,0]  R1363     -6.5375095605850220e-01
    z[5,2,0]  R1364     -7.2028857469558716e-01
    z[5,2,0]  R1365     -7.1874296665191650e-01
    z[5,2,0]  R1366     -0.296962708234787
    z[5,2,0]  R1367     -7.2221815586090088e-01
    z[5,2,0]  R1368     -0.374138206243515
    z[5,2,0]  R1369     -7.7556854486465454e-01
    z[5,2,0]  R1370     -7.4139153957366943e-01
    z[5,2,0]  R1371     -3.9027959108352661e-02
    z[5,2,0]  R1372     3.6240735650062561e-01
    z[5,2,0]  R1373     -6.0498553514480591e-01
    z[5,2,0]  R1374     -1.0302574932575226e-01
    z[5,2,0]  R1375     -5.9329774230718613e-02
    z[5,2,0]  R1376     -3.0037942528724670e-01
    z[5,2,0]  R1377     -0.743958592414856
    z[5,2,0]  R1378     -7.8501778841018677e-01
    z[5,2,0]  R1379     -7.5105243921279907e-01
    z[5,2,0]  R1380     -5.6015497446060181e-01
    z[5,2,0]  R1381     -8.9161342382431030e-01
    z[5,2,0]  R1382     -5.9007924795150757e-01
    z[5,2,0]  R1383     -8.1120771169662476e-01
    z[5,2,0]  R1384     -7.1645969152450562e-01
    z[5,2,0]  R1385     -6.8813055753707886e-01
    z[5,2,0]  R1386     -4.4439971446990967e-01
    z[5,2,0]  R1387     -3.7683433294296265e-01
    z[5,2,0]  R1388     -3.2920166850090027e-01
    z[5,2,0]  R1389     -7.2472792863845825e-01
    z[5,2,0]  R1390     4.9414688348770142e-01
    z[5,2,0]  R1391     4.4974252581596375e-01
    z[5,2,0]  R1392     9.6794553101062775e-02
    z[5,2,0]  R1393     -4.8676044680178165e-03
    z[5,2,0]  R1394     -2.4586421251296997e-01
    z[5,2,0]  R1395     1.1634296923875809e-01
    z[5,2,0]  R1396     0.600662350654602
    z[5,2,0]  R1397     2.7329126000404358e-01
    z[5,2,0]  R1398     6.2698286771774292e-01
    z[5,2,0]  R1399     2.1078411489725113e-02
    z[5,2,0]  R1400     2.4044297635555267e-01
    z[5,2,0]  R1401     -3.8858661055564880e-01
    z[5,2,0]  R1402     -4.6192719601094723e-03
    z[5,2,0]  R1403     5.2527695894241333e-01
    z[5,2,0]  R1404     -6.3333630561828613e-01
    z[5,2,0]  R1405     4.8260340094566345e-01
    z[5,2,0]  R1406     -6.0316592454910278e-01
    z[5,2,0]  R1407     3.4032773971557617e-01
    z[5,2,0]  R1408     2.0777510106563568e-01
    z[5,2,0]  R1409     -3.5108034498989582e-03
    z[5,2,0]  R1410     4.8921483755111694e-01
    z[5,2,0]  R1411     -9.1450080275535583e-02
    z[5,2,0]  R1412     2.1135492622852325e-01
    z[5,2,0]  R1413     2.4746231734752655e-01
    z[5,2,0]  R1414     -1.0800433158874512e-01
    z[5,2,0]  R1415     -4.7529187798500061e-01
    z[5,2,0]  R1416     -0.620422899723053
    z[5,2,0]  R1417     -8.1994032859802246e-01
    z[5,2,0]  R1418     2.0614795386791229e-01
    z[5,2,0]  R1419     -7.1798115968704224e-02
    z[5,2,0]  R1420     2.6360219717025757e-01
    z[5,2,0]  R1421     1.6038280725479126e-01
    z[5,2,0]  R1422     6.0919380187988281e-01
    z[5,2,0]  R1423     7.2385388612747192e-01
    z[5,2,1]  R21       1
    z[5,2,1]  R48       -1
    z[5,2,1]  R1242     -1
    z[5,2,1]  R1243     1
    z[5,2,1]  R1254     5.1057547330856323e-01
    z[5,2,1]  R1255     3.1768313050270081e-01
    z[5,2,1]  R1256     4.8648440837860107e-01
    z[5,2,1]  R1257     4.7185283899307251e-01
    z[5,2,1]  R1258     4.4452327489852905e-01
    z[5,2,1]  R1259     -4.0931418538093567e-02
    z[5,2,1]  R1260     3.4900563955307007e-01
    z[5,2,1]  R1261     4.5200872421264648e-01
    z[5,2,1]  R1262     6.1654180288314819e-01
    z[5,2,1]  R1263     3.8457027077674866e-01
    z[5,2,1]  R1264     2.4004091322422028e-01
    z[5,2,1]  R1265     -4.3289753794670105e-01
    z[5,2,1]  R1266     -0.192816823720932
    z[5,2,1]  R1267     -2.1364213526248932e-01
    z[5,2,1]  R1268     -2.2704876959323883e-01
    z[5,2,1]  R1269     -2.5199401378631592e-01
    z[5,2,1]  R1270     -2.0157837867736816e-01
    z[5,2,1]  R1271     -1.9670151174068451e-01
    z[5,2,1]  R1272     -2.3894466459751129e-01
    z[5,2,1]  R1273     -2.3336625099182129e-01
    z[5,2,1]  R1274     3.4802475571632385e-01
    z[5,2,1]  R1275     7.8177338838577271e-01
    z[5,2,1]  R1276     2.4236483871936798e-01
    z[5,2,1]  R1277     1.7813818156719208e-01
    z[5,2,1]  R1278     8.5366815328598022e-01
    z[5,2,1]  R1279     6.6496598720550537e-01
    z[5,2,1]  R1280     3.4388515353202820e-01
    z[5,2,1]  R1281     -3.1246135011315346e-02
    z[5,2,1]  R1282     -1.8710640072822571e-01
    z[5,2,1]  R1283     -7.2522288560867310e-01
    z[5,2,1]  R1284     5.2543687820434570e-01
    z[5,2,1]  R1285     5.8598470687866211e-01
    z[5,2,1]  R1286     0.849338948726654
    z[5,2,1]  R1287     7.1854478120803833e-01
    z[5,2,1]  R1288     4.8190990090370178e-01
    z[5,2,1]  R1289     -1.8543800711631775e-01
    z[5,2,1]  R1290     -3.7781310081481934e-01
    z[5,2,1]  R1291     -5.2031236886978149e-01
    z[5,2,1]  R1292     -6.2621653079986572e-01
    z[5,2,1]  R1293     1.9602222368121147e-02
    z[5,2,1]  R1294     7.7178794145584106e-01
    z[5,2,1]  R1295     7.8734922409057617e-01
    z[5,2,1]  R1296     6.1397576332092285e-01
    z[5,2,1]  R1297     8.8871586322784424e-01
    z[5,2,1]  R1298     0.267733097076416
    z[5,2,1]  R1299     3.3866789937019348e-01
    z[5,2,1]  R1300     5.2049368619918823e-01
    z[5,2,1]  R1301     -1.1216162145137787e-01
    z[5,2,1]  R1302     3.0052950978279114e-01
    z[5,2,1]  R1303     -3.2113844156265259e-01
    z[5,2,1]  R1304     4.7029018402099609e-01
    z[5,2,1]  R1305     3.7659695744514465e-01
    z[5,2,1]  R1306     0.0677233412861824
    z[5,2,1]  R1307     1.5144044160842896e-01
    z[5,2,1]  R1308     5.7834458351135254e-01
    z[5,2,1]  R1309     5.1786535978317261e-01
    z[5,2,1]  R1310     -2.8375563025474548e-01
    z[5,2,1]  R1311     -3.4214520454406738e-01
    z[5,2,1]  R1312     -3.3144152164459229e-01
    z[5,2,1]  R1313     -0.0317201092839241
    z[5,2,1]  R1314     1.1143982410430908e-01
    z[5,2,1]  R1315     4.7424244880676270e-01
    z[5,2,1]  R1316     8.5829752683639526e-01
    z[5,2,1]  R1317     3.1502538919448853e-01
    z[5,2,1]  R1318     4.6628189086914062e-01
    z[5,2,1]  R1319     5.6245517730712891e-01
    z[5,2,1]  R1320     -2.7969694137573242e-01
    z[5,2,1]  R1321     -4.1869038343429565e-01
    z[5,2,1]  R1322     -2.2984184324741364e-01
    z[5,2,1]  R1323     -3.1074598431587219e-02
    z[5,2,1]  R1324     7.8660178184509277e-01
    z[5,2,1]  R1325     6.3052386045455933e-01
    z[5,2,1]  R1326     1.7272271215915680e-01
    z[5,2,1]  R1327     -3.2018333673477173e-01
    z[5,2,1]  R1328     -2.6289907097816467e-01
    z[5,2,1]  R1329     -3.7370449304580688e-01
    z[5,2,1]  R1330     -5.1204943656921387e-01
    z[5,2,1]  R1331     -3.6264434456825256e-01
    z[5,2,1]  R1332     -5.7322126626968384e-01
    z[5,2,1]  R1333     -4.6222689747810364e-01
    z[5,2,1]  R1334     -9.9885143339633942e-02
    z[5,2,1]  R1335     -4.1757720708847046e-01
    z[5,2,1]  R1336     -5.2153486013412476e-01
    z[5,2,1]  R1337     -5.8511340618133545e-01
    z[5,2,1]  R1338     -6.2838965654373169e-01
    z[5,2,1]  R1339     -7.2098881006240845e-01
    z[5,2,1]  R1340     -8.9664030075073242e-01
    z[5,2,1]  R1341     -5.7314264774322510e-01
    z[5,2,1]  R1342     -4.7685539722442627e-01
    z[5,2,1]  R1343     -5.5895823240280151e-01
    z[5,2,1]  R1344     1.6793204471468925e-02
    z[5,2,1]  R1345     4.1982802748680115e-01
    z[5,2,1]  R1346     -3.0217638611793518e-01
    z[5,2,1]  R1347     3.3735528588294983e-01
    z[5,2,1]  R1348     -2.1396717429161072e-01
    z[5,2,1]  R1349     -1.4922298491001129e-01
    z[5,2,1]  R1350     -4.6211519837379456e-01
    z[5,2,1]  R1351     -2.4508625268936157e-01
    z[5,2,1]  R1352     -1.8263725936412811e-01
    z[5,2,1]  R1353     -2.3488880693912506e-01
    z[5,2,1]  R1354     -1.6358684003353119e-01
    z[5,2,1]  R1355     5.3442692756652832e-01
    z[5,2,1]  R1356     5.0623804330825806e-01
    z[5,2,1]  R1357     4.6645689010620117e-01
    z[5,2,1]  R1358     6.5295898914337158e-01
    z[5,2,1]  R1359     -9.4652932882308960e-01
    z[5,2,1]  R1360     -0.909305214881897
    z[5,2,1]  R1361     6.1326795816421509e-01
    z[5,2,1]  R1362     5.5151903629302979e-01
    z[5,2,1]  R1363     4.0061524510383606e-01
    z[5,2,1]  R1364     -0.264529287815094
    z[5,2,1]  R1365     -1.4760753512382507e-01
    z[5,2,1]  R1366     7.9781192541122437e-01
    z[5,2,1]  R1367     -1.7197097837924957e-01
    z[5,2,1]  R1368     1.4941245317459106e-01
    z[5,2,1]  R1369     4.4548544287681580e-01
    z[5,2,1]  R1370     0.653929591178894
    z[5,2,1]  R1371     4.0577349066734314e-01
    z[5,2,1]  R1372     -3.6976438760757446e-01
    z[5,2,1]  R1373     -6.7304052412509918e-02
    z[5,2,1]  R1374     4.9294161796569824e-01
    z[5,2,1]  R1375     3.5584241151809692e-01
    z[5,2,1]  R1376     3.9754968881607056e-01
    z[5,2,1]  R1377     1.6869686543941498e-02
    z[5,2,1]  R1378     7.1616090834140778e-02
    z[5,2,1]  R1379     2.5303310155868530e-01
    z[5,2,1]  R1380     -1.7502473667263985e-02
    z[5,2,1]  R1381     6.7946580238640308e-03
    z[5,2,1]  R1382     -4.3117246031761169e-01
    z[5,2,1]  R1383     3.8872316479682922e-01
    z[5,2,1]  R1384     -1.3841395080089569e-01
    z[5,2,1]  R1385     -4.6720635145902634e-02
    z[5,2,1]  R1386     5.3251668810844421e-02
    z[5,2,1]  R1387     3.9715209603309631e-01
    z[5,2,1]  R1388     -2.7576866745948792e-01
    z[5,2,1]  R1389     4.9373021721839905e-01
    z[5,2,1]  R1390     -5.0862950086593628e-01
    z[5,2,1]  R1391     -4.7206935286521912e-01
    z[5,2,1]  R1392     -9.2534351348876953e-01
    z[5,2,1]  R1393     -9.3733829259872437e-01
    z[5,2,1]  R1394     5.0692892074584961e-01
    z[5,2,1]  R1395     5.6872403621673584e-01
    z[5,2,1]  R1396     -5.3618443012237549e-01
    z[5,2,1]  R1397     -6.4487606287002563e-01
    z[5,2,1]  R1398     -3.6818471550941467e-01
    z[5,2,1]  R1399     -7.2963792085647583e-01
    z[5,2,1]  R1400     -8.2487720251083374e-01
    z[5,2,1]  R1401     7.6968425512313843e-01
    z[5,2,1]  R1402     -7.7254432439804077e-01
    z[5,2,1]  R1403     -2.3884780704975128e-01
    z[5,2,1]  R1404     3.0962151288986206e-01
    z[5,2,1]  R1405     -5.0188940763473511e-01
    z[5,2,1]  R1406     -9.2821039259433746e-02
    z[5,2,1]  R1407     -2.9327511787414551e-01
    z[5,2,1]  R1408     -0.954384446144104
    z[5,2,1]  R1409     -8.4556078910827637e-01
    z[5,2,1]  R1410     -1.5219414234161377e-01
    z[5,2,1]  R1411     -8.5327720642089844e-01
    z[5,2,1]  R1412     -8.0013388395309448e-01
    z[5,2,1]  R1413     -0.837171733379364
    z[5,2,1]  R1414     5.9243518114089966e-01
    z[5,2,1]  R1415     5.3607380390167236e-01
    z[5,2,1]  R1416     5.0177198648452759e-01
    z[5,2,1]  R1417     -4.3665003776550293e-01
    z[5,2,1]  R1418     -9.2628234624862671e-01
    z[5,2,1]  R1419     -8.7773799896240234e-01
    z[5,2,1]  R1420     9.4409698247909546e-01
    z[5,2,1]  R1421     9.3283069133758545e-01
    z[5,2,1]  R1422     4.4027809053659439e-02
    z[5,2,1]  R1423     -4.1449481248855591e-01
    z[5,2,2]  R22       1
    z[5,2,2]  R49       -1
    z[5,2,2]  R1244     -1
    z[5,2,2]  R1245     1
    z[5,2,2]  R1254     0.225607231259346
    z[5,2,2]  R1255     3.1976962089538574e-01
    z[5,2,2]  R1256     2.1875400841236115e-01
    z[5,2,2]  R1257     4.4502955675125122e-01
    z[5,2,2]  R1258     -4.7080716490745544e-01
    z[5,2,2]  R1259     -4.1226577758789062e-01
    z[5,2,2]  R1260     1.5544793009757996e-01
    z[5,2,2]  R1261     3.5547360777854919e-01
    z[5,2,2]  R1262     -3.2983991503715515e-01
    z[5,2,2]  R1263     4.8570439219474792e-01
    z[5,2,2]  R1264     2.3494124412536621e-01
    z[5,2,2]  R1265     6.5841847658157349e-01
    z[5,2,2]  R1266     8.0758494138717651e-01
    z[5,2,2]  R1267     6.8192929029464722e-01
    z[5,2,2]  R1268     6.5245223045349121e-01
    z[5,2,2]  R1269     6.6472548246383667e-01
    z[5,2,2]  R1270     0.639353334903717
    z[5,2,2]  R1271     6.3165879249572754e-01
    z[5,2,2]  R1272     7.7503788471221924e-01
    z[5,2,2]  R1273     5.7745563983917236e-01
    z[5,2,2]  R1274     2.3937088251113892e-01
    z[5,2,2]  R1275     2.8595605492591858e-01
    z[5,2,2]  R1276     -4.6420689672231674e-02
    z[5,2,2]  R1277     -2.5077894330024719e-01
    z[5,2,2]  R1278     1.2380032241344452e-01
    z[5,2,2]  R1279     -3.7403452396392822e-01
    z[5,2,2]  R1280     -7.1206778287887573e-01
    z[5,2,2]  R1281     -4.7657048702239990e-01
    z[5,2,2]  R1282     -2.1853515505790710e-01
    z[5,2,2]  R1283     -5.7819854468107224e-02
    z[5,2,2]  R1284     -4.0094745159149170e-01
    z[5,2,2]  R1285     -6.7131072282791138e-01
    z[5,2,2]  R1286     -4.1002368927001953e-01
    z[5,2,2]  R1287     -2.6114150881767273e-01
    z[5,2,2]  R1288     4.2280846834182739e-01
    z[5,2,2]  R1289     -2.4369031190872192e-01
    z[5,2,2]  R1290     0.328095406293869
    z[5,2,2]  R1291     3.8787674903869629e-01
    z[5,2,2]  R1292     2.9203245043754578e-01
    z[5,2,2]  R1293     -2.7586886286735535e-01
    z[5,2,2]  R1294     -2.2261705994606018e-01
    z[5,2,2]  R1295     3.4349447488784790e-01
    z[5,2,2]  R1296     -1.4417226612567902e-01
    z[5,2,2]  R1297     -1.2380160391330719e-01
    z[5,2,2]  R1298     -0.395833283662796
    z[5,2,2]  R1299     2.3510010540485382e-01
    z[5,2,2]  R1300     -2.0400816202163696e-01
    z[5,2,2]  R1301     -9.6323236823081970e-02
    z[5,2,2]  R1302     3.9766165614128113e-01
    z[5,2,2]  R1303     2.9063206911087036e-01
    z[5,2,2]  R1304     6.3487243652343750e-01
    z[5,2,2]  R1305     3.7208899855613708e-01
    z[5,2,2]  R1306     1.3445743918418884e-01
    z[5,2,2]  R1307     -4.3952378630638123e-01
    z[5,2,2]  R1308     -2.9135462641716003e-01
    z[5,2,2]  R1309     0.0922401174902916
    z[5,2,2]  R1310     4.4079285860061646e-01
    z[5,2,2]  R1311     -3.1065413355827332e-01
    z[5,2,2]  R1312     0.355376273393631
    z[5,2,2]  R1313     1.2634010612964630e-01
    z[5,2,2]  R1314     -4.2379835247993469e-01
    z[5,2,2]  R1315     3.0889004468917847e-01
    z[5,2,2]  R1316     -3.6990982294082642e-01
    z[5,2,2]  R1317     3.5622832179069519e-01
    z[5,2,2]  R1318     -4.7861674427986145e-01
    z[5,2,2]  R1319     -1.3612095499411225e-03
    z[5,2,2]  R1320     -1.4447963237762451e-01
    z[5,2,2]  R1321     2.8854611515998840e-01
    z[5,2,2]  R1322     2.1654902398586273e-01
    z[5,2,2]  R1323     6.2843970954418182e-02
    z[5,2,2]  R1324     -1.7592564225196838e-01
    z[5,2,2]  R1325     2.0112448930740356e-01
    z[5,2,2]  R1326     3.3232292532920837e-01
    z[5,2,2]  R1327     4.4547894597053528e-01
    z[5,2,2]  R1328     3.8438367843627930e-01
    z[5,2,2]  R1329     5.4896640777587891e-01
    z[5,2,2]  R1330     5.2453732490539551e-01
    z[5,2,2]  R1331     2.7125416323542595e-02
    z[5,2,2]  R1332     1.1758831888437271e-01
    z[5,2,2]  R1333     -1.3787375390529633e-01
    z[5,2,2]  R1334     -1.0769053548574448e-01
    z[5,2,2]  R1335     5.5269473791122437e-01
    z[5,2,2]  R1336     1.5828667581081390e-01
    z[5,2,2]  R1337     3.8291251659393311e-01
    z[5,2,2]  R1338     5.5537527799606323e-01
    z[5,2,2]  R1339     0.521673321723938
    z[5,2,2]  R1340     3.5263195633888245e-01
    z[5,2,2]  R1341     5.3273621946573257e-02
    z[5,2,2]  R1342     2.5538769364356995e-01
    z[5,2,2]  R1343     -2.4770677089691162e-01
    z[5,2,2]  R1344     5.3428955376148224e-02
    z[5,2,2]  R1345     4.7465705871582031e-01
    z[5,2,2]  R1346     3.6648120731115341e-02
    z[5,2,2]  R1347     0.377734899520874
    z[5,2,2]  R1348     6.5484158694744110e-02
    z[5,2,2]  R1349     -1.2441141903400421e-01
    z[5,2,2]  R1350     2.5291427969932556e-01
    z[5,2,2]  R1351     -2.6075729727745056e-01
    z[5,2,2]  R1352     -2.3586069047451019e-01
    z[5,2,2]  R1353     2.9757454991340637e-01
    z[5,2,2]  R1354     1.2146435678005219e-01
    z[5,2,2]  R1355     -4.2763182520866394e-01
    z[5,2,2]  R1356     0.0552813895046711
    z[5,2,2]  R1357     -3.2051667571067810e-01
    z[5,2,2]  R1358     -5.6332081556320190e-01
    z[5,2,2]  R1359     4.8455204814672470e-02
    z[5,2,2]  R1360     2.8371301293373108e-01
    z[5,2,2]  R1361     -2.1615797281265259e-01
    z[5,2,2]  R1362     -3.4118276834487915e-01
    z[5,2,2]  R1363     -4.3730372190475464e-01
    z[5,2,2]  R1364     4.1211673617362976e-01
    z[5,2,2]  R1365     4.9223366379737854e-01
    z[5,2,2]  R1366     -1.7958946526050568e-02
    z[5,2,2]  R1367     4.7048786282539368e-01
    z[5,2,2]  R1368     -3.8058489561080933e-01
    z[5,2,2]  R1369     -3.2974272966384888e-01
    z[5,2,2]  R1370     5.8110468089580536e-02
    z[5,2,2]  R1371     -1.9358810782432556e-01
    z[5,2,2]  R1372     -6.7814439535140991e-01
    z[5,2,2]  R1373     -0.0276302732527256
    z[5,2,2]  R1374     -1.1719395220279694e-01
    z[5,2,2]  R1375     -9.6887126564979553e-02
    z[5,2,2]  R1376     3.9203721284866333e-01
    z[5,2,2]  R1377     -9.0094834566116333e-02
    z[5,2,2]  R1378     4.0363538265228271e-01
    z[5,2,2]  R1379     2.3727929592132568e-01
    z[5,2,2]  R1380     3.7829467654228210e-01
    z[5,2,2]  R1381     2.0727132260799408e-01
    z[5,2,2]  R1382     -3.5161191225051880e-01
    z[5,2,2]  R1383     -1.8203815817832947e-01
    z[5,2,2]  R1384     5.9477311372756958e-01
    z[5,2,2]  R1385     3.3852979540824890e-01
    z[5,2,2]  R1386     0.564498245716095
    z[5,2,2]  R1387     -3.1396320462226868e-01
    z[5,2,2]  R1388     1.2137076258659363e-01
    z[5,2,2]  R1389     -3.5435834527015686e-01
    z[5,2,2]  R1390     -0.539020299911499
    z[5,2,2]  R1391     -2.3951514065265656e-01
    z[5,2,2]  R1392     1.6637371480464935e-01
    z[5,2,2]  R1393     -6.2574379146099091e-02
    z[5,2,2]  R1394     1.5445311367511749e-01
    z[5,2,2]  R1395     -3.8655731081962585e-01
    z[5,2,2]  R1396     -2.5803402066230774e-01
    z[5,2,2]  R1397     -5.0074491649866104e-02
    z[5,2,2]  R1398     -1.7812184989452362e-01
    z[5,2,2]  R1399     6.3637781143188477e-01
    z[5,2,2]  R1400     4.4004756212234497e-01
    z[5,2,2]  R1401     -3.7844008207321167e-01
    z[5,2,2]  R1402     4.7437658905982971e-01
    z[5,2,2]  R1403     -1.9614732265472412e-01
    z[5,2,2]  R1404     2.9345509409904480e-01
    z[5,2,2]  R1405     1.8945498391985893e-02
    z[5,2,2]  R1406     -2.8382557630538940e-01
    z[5,2,2]  R1407     -7.5607880949974060e-02
    z[5,2,2]  R1408     4.0291804820299149e-02
    z[5,2,2]  R1409     -3.9303341507911682e-01
    z[5,2,2]  R1410     2.5031521916389465e-01
    z[5,2,2]  R1411     3.0954939126968384e-01
    z[5,2,2]  R1412     2.4709241092205048e-01
    z[5,2,2]  R1413     -1.3379940390586853e-01
    z[5,2,2]  R1414     0.374731183052063
    z[5,2,2]  R1415     -2.3399564623832703e-01
    z[5,2,2]  R1416     -1.5763019025325775e-01
    z[5,2,2]  R1417     -2.4272593855857849e-01
    z[5,2,2]  R1418     1.6245366632938385e-01
    z[5,2,2]  R1419     -2.3109002411365509e-01
    z[5,2,2]  R1420     5.0432592630386353e-02
    z[5,2,2]  R1421     1.3996334373950958e-01
    z[5,2,2]  R1422     0.632743239402771
    z[5,2,2]  R1423     -1.8757671117782593e-01
    z[5,2,3]  R23       1
    z[5,2,3]  R50       -1
    z[5,2,3]  R1246     -1
    z[5,2,3]  R1247     1
    z[5,2,3]  R1254     2.8614804148674011e-01
    z[5,2,3]  R1255     1.9862221181392670e-01
    z[5,2,3]  R1256     9.6923463046550751e-02
    z[5,2,3]  R1257     1.0683256387710571e-01
    z[5,2,3]  R1258     -3.4418621659278870e-01
    z[5,2,3]  R1259     -3.7811005115509033e-01
    z[5,2,3]  R1260     7.2333104908466339e-02
    z[5,2,3]  R1261     -1.9786326587200165e-01
    z[5,2,3]  R1262     -1.4166752994060516e-01
    z[5,2,3]  R1263     -8.8863588869571686e-02
    z[5,2,3]  R1264     -1.4615970849990845e-01
    z[5,2,3]  R1265     2.3510551452636719e-01
    z[5,2,3]  R1266     8.4521457552909851e-02
    z[5,2,3]  R1267     4.4326889514923096e-01
    z[5,2,3]  R1268     3.0297595262527466e-01
    z[5,2,3]  R1269     -6.4370416104793549e-02
    z[5,2,3]  R1270     2.6252093911170959e-01
    z[5,2,3]  R1271     2.3608949780464172e-01
    z[5,2,3]  R1272     -0.383390337228775
    z[5,2,3]  R1273     4.6426522731781006e-01
    z[5,2,3]  R1274     -5.3112649917602539e-01
    z[5,2,3]  R1275     -1.9288714230060577e-01
    z[5,2,3]  R1276     -2.5173398852348328e-01
    z[5,2,3]  R1277     -1.6380971670150757e-01
    z[5,2,3]  R1278     -9.9699504673480988e-02
    z[5,2,3]  R1279     1.8503373861312866e-01
    z[5,2,3]  R1280     5.2364283800125122e-01
    z[5,2,3]  R1281     5.2530074119567871e-01
    z[5,2,3]  R1282     1.2904337048530579e-01
    z[5,2,3]  R1283     -1.1997362226247787e-01
    z[5,2,3]  R1284     -2.3272280395030975e-01
    z[5,2,3]  R1285     4.1645620018243790e-02
    z[5,2,3]  R1286     2.0353603363037109e-01
    z[5,2,3]  R1287     1.6257666051387787e-01
    z[5,2,3]  R1288     -4.2788782715797424e-01
    z[5,2,3]  R1289     1.0887966305017471e-01
    z[5,2,3]  R1290     -2.7930095791816711e-01
    z[5,2,3]  R1291     -1.5871591866016388e-01
    z[5,2,3]  R1292     -0.0847240760922432
    z[5,2,3]  R1293     2.6343245059251785e-02
    z[5,2,3]  R1294     -2.5393217802047729e-01
    z[5,2,3]  R1295     -2.6008498668670654e-01
    z[5,2,3]  R1296     -2.3698411881923676e-01
    z[5,2,3]  R1297     -1.5202210843563080e-01
    z[5,2,3]  R1298     -5.7442313432693481e-01
    z[5,2,3]  R1299     -6.6975212097167969e-01
    z[5,2,3]  R1300     4.0605121850967407e-01
    z[5,2,3]  R1301     1.2707798182964325e-01
    z[5,2,3]  R1302     -5.3396087884902954e-01
    z[5,2,3]  R1303     -8.2362376153469086e-02
    z[5,2,3]  R1304     -4.7547496855258942e-02
    z[5,2,3]  R1305     0.0390746146440506
    z[5,2,3]  R1306     -7.0815253257751465e-01
    z[5,2,3]  R1307     -1.5038779377937317e-01
    z[5,2,3]  R1308     3.5058364272117615e-01
    z[5,2,3]  R1309     -1.2800544500350952e-01
    z[5,2,3]  R1310     1.1343742907047272e-01
    z[5,2,3]  R1311     1.1935079097747803e-01
    z[5,2,3]  R1312     2.7844834327697754e-01
    z[5,2,3]  R1313     3.0967876315116882e-01
    z[5,2,3]  R1314     -8.1400223076343536e-02
    z[5,2,3]  R1315     2.4099707603454590e-02
    z[5,2,3]  R1316     -5.8336075395345688e-02
    z[5,2,3]  R1317     -5.3081786632537842e-01
    z[5,2,3]  R1318     -3.9032605290412903e-01
    z[5,2,3]  R1319     -3.8091403245925903e-01
    z[5,2,3]  R1320     -1.1232873797416687e-01
    z[5,2,3]  R1321     2.5902670621871948e-01
    z[5,2,3]  R1322     -5.9855529107153416e-03
    z[5,2,3]  R1323     -2.2981157898902893e-01
    z[5,2,3]  R1324     0.0851278305053711
    z[5,2,3]  R1325     -4.1740727424621582e-01
    z[5,2,3]  R1326     -5.7617175579071045e-01
    z[5,2,3]  R1327     -4.9353456497192383e-01
    z[5,2,3]  R1328     1.1958824843168259e-01
    z[5,2,3]  R1329     -2.5140696763992310e-01
    z[5,2,3]  R1330     4.2824551463127136e-02
    z[5,2,3]  R1331     -3.0461966991424561e-02
    z[5,2,3]  R1332     0.380967378616333
    z[5,2,3]  R1333     1.2610933184623718e-01
    z[5,2,3]  R1334     6.9487184286117554e-02
    z[5,2,3]  R1335     -2.3484340310096741e-01
    z[5,2,3]  R1336     -4.0507983416318893e-02
    z[5,2,3]  R1337     2.1431854367256165e-01
    z[5,2,3]  R1338     -8.1822186708450317e-02
    z[5,2,3]  R1339     -2.6592493057250977e-01
    z[5,2,3]  R1340     -7.9549968242645264e-02
    z[5,2,3]  R1341     4.8030912876129150e-01
    z[5,2,3]  R1342     2.9239574074745178e-01
    z[5,2,3]  R1343     5.8321475982666016e-01
    z[5,2,3]  R1344     -5.7658666372299194e-01
    z[5,2,3]  R1345     -4.8413532972335815e-01
    z[5,2,3]  R1346     5.0298297405242920e-01
    z[5,2,3]  R1347     -3.8413512706756592e-01
    z[5,2,3]  R1348     6.3380491733551025e-01
    z[5,2,3]  R1349     4.7572395205497742e-01
    z[5,2,3]  R1350     -4.7816762328147888e-01
    z[5,2,3]  R1351     4.1079682111740112e-01
    z[5,2,3]  R1352     6.8301928043365479e-01
    z[5,2,3]  R1353     4.1419026255607605e-01
    z[5,2,3]  R1354     5.2072703838348389e-01
    z[5,2,3]  R1355     -4.7158092260360718e-01
    z[5,2,3]  R1356     -4.2060464620590210e-01
    z[5,2,3]  R1357     -2.1827220916748047e-02
    z[5,2,3]  R1358     -4.3719586730003357e-01
    z[5,2,3]  R1359     2.4062652885913849e-01
    z[5,2,3]  R1360     1.5694554895162582e-02
    z[5,2,3]  R1361     4.5493260025978088e-01
    z[5,2,3]  R1362     -5.2448230981826782e-01
    z[5,2,3]  R1363     1.5438485145568848e-01
    z[5,2,3]  R1364     -9.3475859612226486e-03
    z[5,2,3]  R1365     -7.0925705134868622e-02
    z[5,2,3]  R1366     -3.5661661624908447e-01
    z[5,2,3]  R1367     3.1329268217086792e-01
    z[5,2,3]  R1368     -7.3681735992431641e-01
    z[5,2,3]  R1369     1.6105762124061584e-01
    z[5,2,3]  R1370     2.0723575726151466e-03
    z[5,2,3]  R1371     -8.0785721540451050e-01
    z[5,2,3]  R1372     2.6825010776519775e-01
    z[5,2,3]  R1373     1.4808334410190582e-01
    z[5,2,3]  R1374     -5.6925994157791138e-01
    z[5,2,3]  R1375     -7.7147370576858521e-01
    z[5,2,3]  R1376     -5.1840478181838989e-01
    z[5,2,3]  R1377     -3.9839029312133789e-01
    z[5,2,3]  R1378     -1.6759096086025238e-01
    z[5,2,3]  R1379     2.2435568273067474e-01
    z[5,2,3]  R1380     -5.7995975017547607e-01
    z[5,2,3]  R1381     -5.5508546531200409e-02
    z[5,2,3]  R1382     -0.162618488073349
    z[5,2,3]  R1383     -1.8966302275657654e-01
    z[5,2,3]  R1384     -1.6043733060359955e-01
    z[5,2,3]  R1385     -3.4989330917596817e-02
    z[5,2,3]  R1386     -4.5814856886863708e-01
    z[5,2,3]  R1387     -4.3502718210220337e-01
    z[5,2,3]  R1388     -4.5113736391067505e-01
    z[5,2,3]  R1389     -1.7009107768535614e-01
    z[5,2,3]  R1390     2.9478520154953003e-01
    z[5,2,3]  R1391     1.8935614824295044e-01
    z[5,2,3]  R1392     2.7815201878547668e-01
    z[5,2,3]  R1393     1.7314006388187408e-01
    z[5,2,3]  R1394     -7.3491680622100830e-01
    z[5,2,3]  R1395     -5.5577796697616577e-01
    z[5,2,3]  R1396     1.8954205513000488e-01
    z[5,2,3]  R1397     4.7849395871162415e-01
    z[5,2,3]  R1398     6.3952714204788208e-02
    z[5,2,3]  R1399     -1.4681740105152130e-01
    z[5,2,3]  R1400     0.00597138237208128
    z[5,2,3]  R1401     2.1508035063743591e-01
    z[5,2,3]  R1402     1.8963800370693207e-01
    z[5,2,3]  R1403     6.0778830200433731e-02
    z[5,2,3]  R1404     -0.0553843230009079
    z[5,2,3]  R1405     0.38902547955513
    z[5,2,3]  R1406     2.6066571474075317e-01
    z[5,2,3]  R1407     3.7355315685272217e-01
    z[5,2,3]  R1408     -8.0543659627437592e-02
    z[5,2,3]  R1409     2.9656881093978882e-01
    z[5,2,3]  R1410     2.5672686100006104e-01
    z[5,2,3]  R1411     -2.0979759097099304e-01
    z[5,2,3]  R1412     7.3786050081253052e-02
    z[5,2,3]  R1413     2.5442928075790405e-01
    z[5,2,3]  R1414     -0.555517852306366
    z[5,2,3]  R1415     -3.0220049619674683e-01
    z[5,2,3]  R1416     -4.7199490666389465e-01
    z[5,2,3]  R1417     -1.3955840468406677e-01
    z[5,2,3]  R1418     -7.2610370814800262e-02
    z[5,2,3]  R1419     -3.0861049890518188e-01
    z[5,2,3]  R1420     9.9657423794269562e-02
    z[5,2,3]  R1421     1.7827060818672180e-01
    z[5,2,3]  R1422     -0.0658518373966217
    z[5,2,3]  R1423     -2.5762474536895752e-01
    z[5,2,4]  R24       1
    z[5,2,4]  R51       -1
    z[5,2,4]  R1248     -1
    z[5,2,4]  R1249     1
    z[5,2,4]  R1254     -8.9635804295539856e-02
    z[5,2,4]  R1255     5.9240357950329781e-03
    z[5,2,4]  R1256     1.6294494271278381e-01
    z[5,2,4]  R1257     2.9447984695434570e-01
    z[5,2,4]  R1258     4.7585102915763855e-01
    z[5,2,4]  R1259     6.0992515087127686e-01
    z[5,2,4]  R1260     5.3177025169134140e-02
    z[5,2,4]  R1261     2.7024206519126892e-01
    z[5,2,4]  R1262     1.8455411493778229e-01
    z[5,2,4]  R1263     2.6636752486228943e-01
    z[5,2,4]  R1264     -0.532170832157135
    z[5,2,4]  R1265     -1.8462254106998444e-01
    z[5,2,4]  R1266     -2.2556984424591064e-01
    z[5,2,4]  R1267     2.7346667647361755e-01
    z[5,2,4]  R1268     1.0784591734409332e-01
    z[5,2,4]  R1269     2.4785001575946808e-01
    z[5,2,4]  R1270     2.0645757019519806e-01
    z[5,2,4]  R1271     3.7460610270500183e-01
    z[5,2,4]  R1272     0.00777652719989419
    z[5,2,4]  R1273     1.9684703648090363e-01
    z[5,2,4]  R1274     8.7425507605075836e-02
    z[5,2,4]  R1275     -3.7611982226371765e-01
    z[5,2,4]  R1276     8.4554873406887054e-02
    z[5,2,4]  R1277     4.4912289828062057e-02
    z[5,2,4]  R1278     -2.7962690591812134e-01
    z[5,2,4]  R1279     -1.9024184346199036e-01
    z[5,2,4]  R1280     -1.2297239154577255e-01
    z[5,2,4]  R1281     -1.7264726758003235e-01
    z[5,2,4]  R1282     -2.0380100607872009e-01
    z[5,2,4]  R1283     -1.6615694761276245e-01
    z[5,2,4]  R1284     4.9837347120046616e-02
    z[5,2,4]  R1285     1.0925633460283279e-01
    z[5,2,4]  R1286     -1.6090567409992218e-01
    z[5,2,4]  R1287     -2.3118624463677406e-02
    z[5,2,4]  R1288     1.8447768688201904e-01
    z[5,2,4]  R1289     -1.7895893752574921e-01
    z[5,2,4]  R1290     1.9566673040390015e-01
    z[5,2,4]  R1291     2.8256335854530334e-01
    z[5,2,4]  R1292     3.9508658647537231e-01
    z[5,2,4]  R1293     5.8149969577789307e-01
    z[5,2,4]  R1294     -1.5922186430543661e-03
    z[5,2,4]  R1295     -1.3166756927967072e-01
    z[5,2,4]  R1296     3.4759557247161865e-01
    z[5,2,4]  R1297     1.0526530444622040e-02
    z[5,2,4]  R1298     -1.4662112109363079e-02
    z[5,2,4]  R1299     5.3493720293045044e-01
    z[5,2,4]  R1300     -3.1676670908927917e-01
    z[5,2,4]  R1301     -3.7845450639724731e-01
    z[5,2,4]  R1302     -1.3518825289793313e-04
    z[5,2,4]  R1303     -3.3785271644592285e-01
    z[5,2,4]  R1304     -3.0541995167732239e-01
    z[5,2,4]  R1305     -1.8798868358135223e-01
    z[5,2,4]  R1306     6.7701435089111328e-01
    z[5,2,4]  R1307     6.3727504014968872e-01
    z[5,2,4]  R1308     -2.4129703640937805e-01
    z[5,2,4]  R1309     -2.4397027492523193e-01
    z[5,2,4]  R1310     2.3534847795963287e-01
    z[5,2,4]  R1311     -1.3661400973796844e-01
    z[5,2,4]  R1312     5.0487709045410156e-01
    z[5,2,4]  R1313     -5.3828172385692596e-02
    z[5,2,4]  R1314     1.3678911328315735e-01
    z[5,2,4]  R1315     -1.1057466268539429e-01
    z[5,2,4]  R1316     1.4980529248714447e-01
    z[5,2,4]  R1317     1.3441678881645203e-01
    z[5,2,4]  R1318     -5.0711023807525635e-01
    z[5,2,4]  R1319     3.5708293318748474e-01
    z[5,2,4]  R1320     6.6397930495440960e-03
    z[5,2,4]  R1321     3.1206998229026794e-01
    z[5,2,4]  R1322     1.1286263167858124e-01
    z[5,2,4]  R1323     5.7297468185424805e-02
    z[5,2,4]  R1324     -1.1313164606690407e-02
    z[5,2,4]  R1325     2.0030789077281952e-01
    z[5,2,4]  R1326     0.0537506528198719
    z[5,2,4]  R1327     9.6015287563204765e-03
    z[5,2,4]  R1328     -2.5005133822560310e-02
    z[5,2,4]  R1329     2.5555279850959778e-01
    z[5,2,4]  R1330     8.7121017277240753e-03
    z[5,2,4]  R1331     4.8978802561759949e-01
    z[5,2,4]  R1332     1.1990191414952278e-02
    z[5,2,4]  R1333     5.2671605348587036e-01
    z[5,2,4]  R1334     -0.384162575006485
    z[5,2,4]  R1335     2.5257727503776550e-01
    z[5,2,4]  R1336     3.8030573725700378e-01
    z[5,2,4]  R1337     -5.5059641599655151e-02
    z[5,2,4]  R1338     1.3978768885135651e-01
    z[5,2,4]  R1339     1.6580714285373688e-01
    z[5,2,4]  R1340     1.5398119390010834e-01
    z[5,2,4]  R1341     -1.0099439322948456e-01
    z[5,2,4]  R1342     -3.1638448126614094e-03
    z[5,2,4]  R1343     -3.8547852635383606e-01
    z[5,2,4]  R1344     0.585985004901886
    z[5,2,4]  R1345     4.5392480492591858e-01
    z[5,2,4]  R1346     -4.9370858818292618e-02
    z[5,2,4]  R1347     2.9065108299255371e-01
    z[5,2,4]  R1348     0.0555245578289032
    z[5,2,4]  R1349     -8.8652148842811584e-02
    z[5,2,4]  R1350     1.3986818492412567e-01
    z[5,2,4]  R1351     1.1174959689378738e-01
    z[5,2,4]  R1352     -8.8005885481834412e-02
    z[5,2,4]  R1353     0.0831865444779396
    z[5,2,4]  R1354     -8.0534592270851135e-03
    z[5,2,4]  R1355     2.4362045526504517e-01
    z[5,2,4]  R1356     2.3618039488792419e-01
    z[5,2,4]  R1357     -3.3481118083000183e-01
    z[5,2,4]  R1358     1.1404404789209366e-01
    z[5,2,4]  R1359     -1.1398802697658539e-01
    z[5,2,4]  R1360     -8.5143849253654480e-02
    z[5,2,4]  R1361     -1.4496196806430817e-01
    z[5,2,4]  R1362     -2.6472138240933418e-02
    z[5,2,4]  R1363     3.2402139902114868e-01
    z[5,2,4]  R1364     1.8986824154853821e-01
    z[5,2,4]  R1365     -3.4458765387535095e-01
    z[5,2,4]  R1366     -1.5601888298988342e-01
    z[5,2,4]  R1367     -3.3036106824874878e-01
    z[5,2,4]  R1368     7.9754993319511414e-02
    z[5,2,4]  R1369     2.2440824657678604e-02
    z[5,2,4]  R1370     -5.4176026023924351e-03
    z[5,2,4]  R1371     -8.7099701166152954e-02
    z[5,2,4]  R1372     -3.8170254230499268e-01
    z[5,2,4]  R1373     2.8691646456718445e-01
    z[5,2,4]  R1374     0.372158020734787
    z[5,2,4]  R1375     4.3288782238960266e-02
    z[5,2,4]  R1376     -1.2515020370483398e-01
    z[5,2,4]  R1377     9.4737574458122253e-02
    z[5,2,4]  R1378     -1.8336981534957886e-01
    z[5,2,4]  R1379     3.9586311578750610e-01
    z[5,2,4]  R1380     -2.0542104542255402e-01
    z[5,2,4]  R1381     -3.3603996038436890e-02
    z[5,2,4]  R1382     2.5538778305053711e-01
    z[5,2,4]  R1383     -3.2243865728378296e-01
    z[5,2,4]  R1384     1.0967319458723068e-01
    z[5,2,4]  R1385     2.0001262426376343e-01
    z[5,2,4]  R1386     -2.1655750274658203e-01
    z[5,2,4]  R1387     4.7490587830543518e-01
    z[5,2,4]  R1388     -1.1311549693346024e-01
    z[5,2,4]  R1389     0.269917756319046
    z[5,2,4]  R1390     -6.3240818679332733e-02
    z[5,2,4]  R1391     -4.9538484215736389e-01
    z[5,2,4]  R1392     1.2240315973758698e-01
    z[5,2,4]  R1393     1.0413980484008789e-01
    z[5,2,4]  R1394     8.3759091794490814e-02
    z[5,2,4]  R1395     -5.6565467268228531e-02
    z[5,2,4]  R1396     -1.3234561309218407e-02
    z[5,2,4]  R1397     -5.1011848449707031e-01
    z[5,2,4]  R1398     -5.7242041826248169e-01
    z[5,2,4]  R1399     0.0806722566485405
    z[5,2,4]  R1400     2.3295298218727112e-01
    z[5,2,4]  R1401     6.3670896925032139e-03
    z[5,2,4]  R1402     1.4857368171215057e-01
    z[5,2,4]  R1403     -7.8706592321395874e-01
    z[5,2,4]  R1404     5.9010720252990723e-01
    z[5,2,4]  R1405     -4.9014893174171448e-01
    z[5,2,4]  R1406     3.4605216979980469e-01
    z[5,2,4]  R1407     -0.784143328666687
    z[5,2,4]  R1408     1.6048873960971832e-01
    z[5,2,4]  R1409     -1.6336247324943542e-01
    z[5,2,4]  R1410     -7.4287265539169312e-01
    z[5,2,4]  R1411     2.8813734650611877e-01
    z[5,2,4]  R1412     3.4640464186668396e-01
    z[5,2,4]  R1413     2.3118773102760315e-01
    z[5,2,4]  R1414     2.5349294766783714e-02
    z[5,2,4]  R1415     5.0959908962249756e-01
    z[5,2,4]  R1416     5.9191279113292694e-02
    z[5,2,4]  R1417     -1.9709999859333038e-01
    z[5,2,4]  R1418     2.4052542448043823e-01
    z[5,2,4]  R1419     -9.3885980546474457e-02
    z[5,2,4]  R1420     2.2049862891435623e-02
    z[5,2,4]  R1421     1.2017721310257912e-02
    z[5,2,4]  R1422     -1.8670603632926941e-01
    z[5,2,4]  R1423     4.3236309289932251e-01
    z[5,2,5]  R25       1
    z[5,2,5]  R52       -1
    z[5,2,5]  R1250     -1
    z[5,2,5]  R1251     1
    z[5,2,5]  R1254     -7.5947046279907227e-03
    z[5,2,5]  R1255     -8.7791271507740021e-03
    z[5,2,5]  R1256     3.1882032752037048e-01
    z[5,2,5]  R1257     -5.7182990014553070e-02
    z[5,2,5]  R1258     -1.6890972852706909e-01
    z[5,2,5]  R1259     -6.4772136509418488e-02
    z[5,2,5]  R1260     1.0017333924770355e-01
    z[5,2,5]  R1261     0.231211319565773
    z[5,2,5]  R1262     5.7747727632522583e-01
    z[5,2,5]  R1263     2.6583153009414673e-01
    z[5,2,5]  R1264     2.2481076419353485e-01
    z[5,2,5]  R1265     1.3052079826593399e-02
    z[5,2,5]  R1266     1.5171720087528229e-01
    z[5,2,5]  R1267     -4.3023936450481415e-02
    z[5,2,5]  R1268     0.0353940911591053
    z[5,2,5]  R1269     4.4357147812843323e-01
    z[5,2,5]  R1270     4.7407639026641846e-01
    z[5,2,5]  R1271     6.2767281197011471e-03
    z[5,2,5]  R1272     -1.9781421124935150e-01
    z[5,2,5]  R1273     -1.9604696333408356e-01
    z[5,2,5]  R1274     1.9839632511138916e-01
    z[5,2,5]  R1275     3.3862125873565674e-01
    z[5,2,5]  R1276     -3.0617916956543922e-02
    z[5,2,5]  R1277     2.9147979617118835e-01
    z[5,2,5]  R1278     -3.6393553018569946e-01
    z[5,2,5]  R1279     -4.2408636212348938e-01
    z[5,2,5]  R1280     -1.2743981555104256e-02
    z[5,2,5]  R1281     -1.8517075479030609e-01
    z[5,2,5]  R1282     -3.0390882492065430e-01
    z[5,2,5]  R1283     -2.0238092541694641e-01
    z[5,2,5]  R1284     1.9782733917236328e-01
    z[5,2,5]  R1285     -9.8644390702247620e-02
    z[5,2,5]  R1286     -0.148346409201622
    z[5,2,5]  R1287     -4.6158552169799805e-01
    z[5,2,5]  R1288     -2.9842260479927063e-01
    z[5,2,5]  R1289     -3.4983307123184204e-01
    z[5,2,5]  R1290     -0.377279132604599
    z[5,2,5]  R1291     3.8751029968261719e-01
    z[5,2,5]  R1292     2.0157396793365479e-02
    z[5,2,5]  R1293     -3.3282953500747681e-01
    z[5,2,5]  R1294     5.0642937421798706e-01
    z[5,2,5]  R1295     -4.5824404805898666e-02
    z[5,2,5]  R1296     -6.2417805194854736e-01
    z[5,2,5]  R1297     -0.0754033774137497
    z[5,2,5]  R1298     -6.4436845481395721e-02
    z[5,2,5]  R1299     1.9234506785869598e-01
    z[5,2,5]  R1300     2.7806267142295837e-01
    z[5,2,5]  R1301     -2.3896206170320511e-02
    z[5,2,5]  R1302     -4.7335988283157349e-01
    z[5,2,5]  R1303     6.2632042169570923e-01
    z[5,2,5]  R1304     1.9467703998088837e-01
    z[5,2,5]  R1305     -4.9738940596580505e-01
    z[5,2,5]  R1306     -2.1414436399936676e-02
    z[5,2,5]  R1307     3.2057842612266541e-01
    z[5,2,5]  R1308     3.8099128007888794e-01
    z[5,2,5]  R1309     -6.7592531442642212e-01
    z[5,2,5]  R1310     5.3517264127731323e-01
    z[5,2,5]  R1311     2.1830736100673676e-01
    z[5,2,5]  R1312     -6.1397127807140350e-02
    z[5,2,5]  R1313     -2.8867498040199280e-01
    z[5,2,5]  R1314     -4.4239038228988647e-01
    z[5,2,5]  R1315     -2.9919949173927307e-01
    z[5,2,5]  R1316     -1.6329869627952576e-01
    z[5,2,5]  R1317     -5.9690177440643311e-01
    z[5,2,5]  R1318     1.0459543205797672e-02
    z[5,2,5]  R1319     3.1147959828376770e-01
    z[5,2,5]  R1320     9.0109594166278839e-02
    z[5,2,5]  R1321     3.6661437153816223e-01
    z[5,2,5]  R1322     -4.7735314816236496e-02
    z[5,2,5]  R1323     -2.3951521515846252e-01
    z[5,2,5]  R1324     -7.1482270956039429e-02
    z[5,2,5]  R1325     1.4146538078784943e-01
    z[5,2,5]  R1326     4.1564801335334778e-01
    z[5,2,5]  R1327     5.2571278065443039e-02
    z[5,2,5]  R1328     -6.4349097013473511e-01
    z[5,2,5]  R1329     -1.4879024028778076e-01
    z[5,2,5]  R1330     -4.0760420262813568e-02
    z[5,2,5]  R1331     2.3870344460010529e-01
    z[5,2,5]  R1332     -9.2644453048706055e-02
    z[5,2,5]  R1333     -1.2771388888359070e-01
    z[5,2,5]  R1334     1.2331591546535492e-01
    z[5,2,5]  R1335     -1.2022284418344498e-01
    z[5,2,5]  R1336     0.382844477891922
    z[5,2,5]  R1337     -9.3877725303173065e-02
    z[5,2,5]  R1338     -8.1795983016490936e-02
    z[5,2,5]  R1339     1.7924067378044128e-01
    z[5,2,5]  R1340     1.5473881363868713e-01
    z[5,2,5]  R1341     1.0495068877935410e-01
    z[5,2,5]  R1342     -3.1709831953048706e-01
    z[5,2,5]  R1343     -2.2529639303684235e-01
    z[5,2,5]  R1344     4.0886640548706055e-01
    z[5,2,5]  R1345     1.1239586770534515e-01
    z[5,2,5]  R1346     -1.2824654579162598e-01
    z[5,2,5]  R1347     4.8890876770019531e-01
    z[5,2,5]  R1348     2.4667195975780487e-01
    z[5,2,5]  R1349     3.0765545368194580e-01
    z[5,2,5]  R1350     -1.6746150329709053e-02
    z[5,2,5]  R1351     -0.0683315098285675
    z[5,2,5]  R1352     1.2376486510038376e-01
    z[5,2,5]  R1353     3.5071703791618347e-01
    z[5,2,5]  R1354     -1.2956143915653229e-01
    z[5,2,5]  R1355     -3.2415542006492615e-01
    z[5,2,5]  R1356     -5.3670185804367065e-01
    z[5,2,5]  R1357     1.8109139800071716e-01
    z[5,2,5]  R1358     -9.8403267562389374e-02
    z[5,2,5]  R1359     -2.3633357137441635e-02
    z[5,2,5]  R1360     8.2218162715435028e-02
    z[5,2,5]  R1361     6.8722128868103027e-02
    z[5,2,5]  R1362     -1.4278912544250488e-01
    z[5,2,5]  R1363     -9.1430328786373138e-02
    z[5,2,5]  R1364     -6.5892316401004791e-02
    z[5,2,5]  R1365     1.1503832787275314e-01
    z[5,2,5]  R1366     -3.3437585830688477e-01
    z[5,2,5]  R1367     1.0261550545692444e-01
    z[5,2,5]  R1368     -3.5006096959114075e-01
    z[5,2,5]  R1369     -1.1785305291414261e-01
    z[5,2,5]  R1370     -1.3829918205738068e-01
    z[5,2,5]  R1371     -3.6164256930351257e-01
    z[5,2,5]  R1372     -2.0925061404705048e-01
    z[5,2,5]  R1373     1.5344475209712982e-01
    z[5,2,5]  R1374     -3.1367599964141846e-01
    z[5,2,5]  R1375     -3.9566081017255783e-02
    z[5,2,5]  R1376     -5.5153405666351318e-01
    z[5,2,5]  R1377     -2.1115562319755554e-01
    z[5,2,5]  R1378     -2.5290203094482422e-01
    z[5,2,5]  R1379     -3.4231055527925491e-02
    z[5,2,5]  R1380     -3.9365702867507935e-01
    z[5,2,5]  R1381     7.4246935546398163e-02
    z[5,2,5]  R1382     1.3931236229836941e-02
    z[5,2,5]  R1383     1.0323248058557510e-01
    z[5,2,5]  R1384     1.1458898894488811e-02
    z[5,2,5]  R1385     6.0198950767517090e-01
    z[5,2,5]  R1386     -5.7573366910219193e-02
    z[5,2,5]  R1387     -2.5862815976142883e-01
    z[5,2,5]  R1388     2.9186886548995972e-01
    z[5,2,5]  R1389     0.00526859937235713
    z[5,2,5]  R1390     2.1128852665424347e-01
    z[5,2,5]  R1391     -2.2448942065238953e-01
    z[5,2,5]  R1392     -2.1524254232645035e-02
    z[5,2,5]  R1393     2.6794016361236572e-01
    z[5,2,5]  R1394     -6.7306622862815857e-02
    z[5,2,5]  R1395     -4.4824701547622681e-01
    z[5,2,5]  R1396     2.5261655449867249e-01
    z[5,2,5]  R1397     9.6087656915187836e-02
    z[5,2,5]  R1398     1.1172868311405182e-02
    z[5,2,5]  R1399     -1.1932700127363205e-01
    z[5,2,5]  R1400     -9.9355757236480713e-02
    z[5,2,5]  R1401     0.0643991008400917
    z[5,2,5]  R1402     -1.3695776462554932e-01
    z[5,2,5]  R1403     6.5878160297870636e-02
    z[5,2,5]  R1404     2.0843271911144257e-01
    z[5,2,5]  R1405     1.0014345496892929e-01
    z[5,2,5]  R1406     2.5994306802749634e-01
    z[5,2,5]  R1407     -7.1071274578571320e-02
    z[5,2,5]  R1408     -1.0951571911573410e-01
    z[5,2,5]  R1409     1.1942744255065918e-01
    z[5,2,5]  R1410     2.3815682530403137e-01
    z[5,2,5]  R1411     1.6805014014244080e-01
    z[5,2,5]  R1412     3.5341310501098633e-01
    z[5,2,5]  R1413     -5.7587809860706329e-03
    z[5,2,5]  R1414     -4.3268963694572449e-01
    z[5,2,5]  R1415     -2.1182611584663391e-01
    z[5,2,5]  R1416     -1.6084384918212891e-01
    z[5,2,5]  R1417     -5.2090730518102646e-02
    z[5,2,5]  R1418     5.4125446826219559e-02
    z[5,2,5]  R1419     -2.0764803886413574e-01
    z[5,2,5]  R1420     1.2295242398977280e-01
    z[5,2,5]  R1421     2.0872300863265991e-01
    z[5,2,5]  R1422     1.1930776387453079e-01
    z[5,2,5]  R1423     -3.1884968280792236e-02
    z[5,2,6]  R26       1
    z[5,2,6]  R53       -1
    z[5,2,6]  R1252     -1
    z[5,2,6]  R1253     1
    z[5,2,6]  R1254     -1.4731016755104065e-01
    z[5,2,6]  R1255     -6.6391073167324066e-02
    z[5,2,6]  R1256     2.0331348478794098e-01
    z[5,2,6]  R1257     -8.5120923817157745e-02
    z[5,2,6]  R1258     -1.0575703531503677e-01
    z[5,2,6]  R1259     -0.09307861328125
    z[5,2,6]  R1260     2.4711626768112183e-01
    z[5,2,6]  R1261     2.0318250358104706e-01
    z[5,2,6]  R1262     -3.3131068944931030e-01
    z[5,2,6]  R1263     -6.8389378488063812e-02
    z[5,2,6]  R1264     3.6516536027193069e-02
    z[5,2,6]  R1265     0.0774056687951088
    z[5,2,6]  R1266     -1.4727701246738434e-01
    z[5,2,6]  R1267     -1.5174393355846405e-01
    z[5,2,6]  R1268     -4.7539597749710083e-01
    z[5,2,6]  R1269     2.2532801330089569e-01
    z[5,2,6]  R1270     8.6684837937355042e-02
    z[5,2,6]  R1271     3.5144168138504028e-01
    z[5,2,6]  R1272     -1.7987428605556488e-01
    z[5,2,6]  R1273     3.6844724416732788e-01
    z[5,2,6]  R1274     0.677962064743042
    z[5,2,6]  R1275     -5.9153027832508087e-02
    z[5,2,6]  R1276     0.919495165348053
    z[5,2,6]  R1277     0.814403235912323
    z[5,2,6]  R1278     -1.8726487457752228e-01
    z[5,2,6]  R1279     3.9939272403717041e-01
    z[5,2,6]  R1280     2.7433177828788757e-01
    z[5,2,6]  R1281     -3.4588745236396790e-01
    z[5,2,6]  R1282     5.4620647430419922e-01
    z[5,2,6]  R1283     -1.9505728781223297e-01
    z[5,2,6]  R1284     2.5381517410278320e-01
    z[5,2,6]  R1285     3.0845694709569216e-03
    z[5,2,6]  R1286     -0.074495330452919
    z[5,2,6]  R1287     -2.7877295017242432e-01
    z[5,2,6]  R1288     -3.9746654033660889e-01
    z[5,2,6]  R1289     -5.3462157957255840e-03
    z[5,2,6]  R1290     4.3215584754943848e-01
    z[5,2,6]  R1291     -8.3619892597198486e-02
    z[5,2,6]  R1292     -2.7281185984611511e-01
    z[5,2,6]  R1293     -3.6632496118545532e-01
    z[5,2,6]  R1294     1.1175787448883057e-01
    z[5,2,6]  R1295     -8.6105622351169586e-02
    z[5,2,6]  R1296     -3.7456639111042023e-02
    z[5,2,6]  R1297     3.1134110689163208e-01
    z[5,2,6]  R1298     2.9562366008758545e-01
    z[5,2,6]  R1299     -8.3799540996551514e-02
    z[5,2,6]  R1300     -2.8917360305786133e-01
    z[5,2,6]  R1301     -3.4714111685752869e-01
    z[5,2,6]  R1302     1.2736445665359497e-01
    z[5,2,6]  R1303     -6.8762958049774170e-02
    z[5,2,6]  R1304     -1.6143139451742172e-02
    z[5,2,6]  R1305     2.1712635457515717e-01
    z[5,2,6]  R1306     1.1941968649625778e-01
    z[5,2,6]  R1307     2.5954738259315491e-01
    z[5,2,6]  R1308     -6.4274176955223083e-02
    z[5,2,6]  R1309     -3.3101800829172134e-02
    z[5,2,6]  R1310     -1.3286098837852478e-01
    z[5,2,6]  R1311     -1.1625555902719498e-01
    z[5,2,6]  R1312     -3.4496295452117920e-01
    z[5,2,6]  R1313     2.6258850097656250e-01
    z[5,2,6]  R1314     1.3789756596088409e-01
    z[5,2,6]  R1315     5.6865904480218887e-02
    z[5,2,6]  R1316     -2.2241444885730743e-01
    z[5,2,6]  R1317     0.195271834731102
    z[5,2,6]  R1318     -3.7824764847755432e-01
    z[5,2,6]  R1319     3.0041828751564026e-01
    z[5,2,6]  R1320     -3.9020174741744995e-01
    z[5,2,6]  R1321     -4.0451325476169586e-02
    z[5,2,6]  R1322     2.4714720249176025e-01
    z[5,2,6]  R1323     -7.1370363235473633e-01
    z[5,2,6]  R1324     6.2678046524524689e-02
    z[5,2,6]  R1325     3.5645064711570740e-01
    z[5,2,6]  R1326     -3.4316653013229370e-01
    z[5,2,6]  R1327     -3.2001107465475798e-03
    z[5,2,6]  R1328     -3.3547705411911011e-01
    z[5,2,6]  R1329     2.5705745816230774e-01
    z[5,2,6]  R1330     1.5021668374538422e-01
    z[5,2,6]  R1331     -3.2108661532402039e-01
    z[5,2,6]  R1332     1.7515990138053894e-01
    z[5,2,6]  R1333     -6.1666302382946014e-02
    z[5,2,6]  R1334     -8.5834875702857971e-02
    z[5,2,6]  R1335     2.0520697534084320e-01
    z[5,2,6]  R1336     -4.5186918228864670e-02
    z[5,2,6]  R1337     2.4321815371513367e-01
    z[5,2,6]  R1338     -1.5244592726230621e-01
    z[5,2,6]  R1339     -2.7870634198188782e-01
    z[5,2,6]  R1340     1.2779383361339569e-01
    z[5,2,6]  R1341     -3.3953779935836792e-01
    z[5,2,6]  R1342     -0.440801203250885
    z[5,2,6]  R1343     -3.7467747926712036e-02
    z[5,2,6]  R1344     -2.7494572568684816e-03
    z[5,2,6]  R1345     1.4613977074623108e-01
    z[5,2,6]  R1346     -2.2966891992837191e-03
    z[5,2,6]  R1347     -3.0455753207206726e-01
    z[5,2,6]  R1348     -9.2454567551612854e-02
    z[5,2,6]  R1349     -1.3331221416592598e-02
    z[5,2,6]  R1350     0.0850360244512558
    z[5,2,6]  R1351     3.3200240135192871e-01
    z[5,2,6]  R1352     1.2971581518650055e-01
    z[5,2,6]  R1353     -1.3002598285675049e-01
    z[5,2,6]  R1354     6.4658035989850760e-04
    z[5,2,6]  R1355     1.4682596921920776e-01
    z[5,2,6]  R1356     4.6131512522697449e-01
    z[5,2,6]  R1357     -4.1206661611795425e-02
    z[5,2,6]  R1358     -7.7206864953041077e-02
    z[5,2,6]  R1359     9.6304953098297119e-02
    z[5,2,6]  R1360     -2.2544731199741364e-01
    z[5,2,6]  R1361     -1.8545429408550262e-01
    z[5,2,6]  R1362     -4.2595180869102478e-01
    z[5,2,6]  R1363     -2.8930693864822388e-01
    z[5,2,6]  R1364     -4.4820669293403625e-01
    z[5,2,6]  R1365     -2.8691756725311279e-01
    z[5,2,6]  R1366     1.0799196362495422e-01
    z[5,2,6]  R1367     9.8221465945243835e-02
    z[5,2,6]  R1368     1.4508076012134552e-01
    z[5,2,6]  R1369     2.2577278316020966e-01
    z[5,2,6]  R1370     -1.3321690261363983e-02
    z[5,2,6]  R1371     7.3098443448543549e-02
    z[5,2,6]  R1372     -1.0302697867155075e-01
    z[5,2,6]  R1373     7.0774590969085693e-01
    z[5,2,6]  R1374     4.1437754034996033e-01
    z[5,2,6]  R1375     -0.511720597743988
    z[5,2,6]  R1376     9.7146227955818176e-02
    z[5,2,6]  R1377     4.7523382306098938e-01
    z[5,2,6]  R1378     3.0004331469535828e-01
    z[5,2,6]  R1379     3.2768625020980835e-01
    z[5,2,6]  R1380     -9.6416510641574860e-02
    z[5,2,6]  R1381     3.9024993777275085e-01
    z[5,2,6]  R1382     0.500403881072998
    z[5,2,6]  R1383     -0.0842781662940979
    z[5,2,6]  R1384     0.275449275970459
    z[5,2,6]  R1385     -7.7913120388984680e-02
    z[5,2,6]  R1386     -4.7000306844711304e-01
    z[5,2,6]  R1387     -3.4643980860710144e-01
    z[5,2,6]  R1388     -7.0663958787918091e-01
    z[5,2,6]  R1389     6.0131076723337173e-02
    z[5,2,6]  R1390     -2.6651713252067566e-01
    z[5,2,6]  R1391     4.3111163377761841e-01
    z[5,2,6]  R1392     -1.1779459565877914e-01
    z[5,2,6]  R1393     -6.9593206048011780e-02
    z[5,2,6]  R1394     -3.2721498608589172e-01
    z[5,2,6]  R1395     -2.4010214954614639e-02
    z[5,2,6]  R1396     -4.3036383390426636e-01
    z[5,2,6]  R1397     -0.0923534482717514
    z[5,2,6]  R1398     -0.328215092420578
    z[5,2,6]  R1399     -1.4108602702617645e-01
    z[5,2,6]  R1400     6.2837995588779449e-02
    z[5,2,6]  R1401     -2.5084343552589417e-01
    z[5,2,6]  R1402     3.1831854581832886e-01
    z[5,2,6]  R1403     3.2484382390975952e-02
    z[5,2,6]  R1404     -0.148881196975708
    z[5,2,6]  R1405     3.3649137616157532e-01
    z[5,2,6]  R1406     5.4013800621032715e-01
    z[5,2,6]  R1407     -1.8159356713294983e-01
    z[5,2,6]  R1408     1.0902926325798035e-02
    z[5,2,6]  R1409     -4.0447127074003220e-02
    z[5,2,6]  R1410     -1.8995296210050583e-02
    z[5,2,6]  R1411     -1.1160200834274292e-01
    z[5,2,6]  R1412     6.0983393341302872e-02
    z[5,2,6]  R1413     3.1904298067092896e-01
    z[5,2,6]  R1414     2.1662132814526558e-02
    z[5,2,6]  R1415     -1.8995198607444763e-01
    z[5,2,6]  R1416     2.9376775026321411e-01
    z[5,2,6]  R1417     1.3069215416908264e-01
    z[5,2,6]  R1418     -8.4015779197216034e-02
    z[5,2,6]  R1419     -1.5442037582397461e-01
    z[5,2,6]  R1420     -1.0543386638164520e-01
    z[5,2,6]  R1421     -0.0949973315000534
    z[5,2,6]  R1422     4.1611364483833313e-01
    z[5,2,6]  R1423     -1.2132444977760315e-01
    z[2,6,0]  R20       -1
    z[2,6,0]  R56       1
    z[2,6,0]  R1424     -1
    z[2,6,0]  R1425     1
    z[2,6,0]  R1438     -3.9224180579185486e-01
    z[2,6,0]  R1439     -3.5216581821441650e-01
    z[2,6,0]  R1440     0.797160267829895
    z[2,6,0]  R1441     -4.2389002442359924e-01
    z[2,6,0]  R1442     6.8974149227142334e-01
    z[2,6,0]  R1443     7.9577147960662842e-01
    z[2,6,0]  R1444     -6.8320196866989136e-01
    z[2,6,0]  R1445     7.5881582498550415e-01
    z[2,6,0]  R1446     6.3608884811401367e-01
    z[2,6,0]  R1447     7.3341244459152222e-01
    z[2,6,0]  R1448     -8.1882697343826294e-01
    z[2,6,0]  R1449     3.5091996192932129e-01
    z[2,6,0]  R1450     8.4362350404262543e-02
    z[2,6,0]  R1451     -7.2980821132659912e-01
    z[2,6,0]  R1452     1.9111198186874390e-01
    z[2,6,0]  R1453     -1.4493685960769653e-01
    z[2,6,0]  R1454     -1.6609892249107361e-01
    z[2,6,0]  R1455     -5.5685228109359741e-01
    z[2,6,0]  R1456     0.319084495306015
    z[2,6,0]  R1457     -6.5375095605850220e-01
    z[2,6,0]  R1458     -7.2028857469558716e-01
    z[2,6,0]  R1459     -7.1874296665191650e-01
    z[2,6,0]  R1460     -0.296962708234787
    z[2,6,0]  R1461     -7.2221815586090088e-01
    z[2,6,0]  R1462     -0.374138206243515
    z[2,6,0]  R1463     -7.7556854486465454e-01
    z[2,6,0]  R1464     -7.4139153957366943e-01
    z[2,6,0]  R1465     -3.9027959108352661e-02
    z[2,6,0]  R1466     3.6240735650062561e-01
    z[2,6,0]  R1467     -6.0498553514480591e-01
    z[2,6,0]  R1468     -1.0302574932575226e-01
    z[2,6,0]  R1469     -5.9329774230718613e-02
    z[2,6,0]  R1470     -3.0037942528724670e-01
    z[2,6,0]  R1471     -0.743958592414856
    z[2,6,0]  R1472     -7.8501778841018677e-01
    z[2,6,0]  R1473     -7.5105243921279907e-01
    z[2,6,0]  R1474     -5.6015497446060181e-01
    z[2,6,0]  R1475     -8.9161342382431030e-01
    z[2,6,0]  R1476     -5.9007924795150757e-01
    z[2,6,0]  R1477     -8.1120771169662476e-01
    z[2,6,0]  R1478     -7.1645969152450562e-01
    z[2,6,0]  R1479     -6.8813055753707886e-01
    z[2,6,0]  R1480     -4.4439971446990967e-01
    z[2,6,0]  R1481     -3.7683433294296265e-01
    z[2,6,0]  R1482     -3.2920166850090027e-01
    z[2,6,0]  R1483     -7.2472792863845825e-01
    z[2,6,0]  R1484     4.9414688348770142e-01
    z[2,6,0]  R1485     4.4974252581596375e-01
    z[2,6,0]  R1486     9.6794553101062775e-02
    z[2,6,0]  R1487     -4.8676044680178165e-03
    z[2,6,0]  R1488     -2.4586421251296997e-01
    z[2,6,0]  R1489     1.1634296923875809e-01
    z[2,6,0]  R1490     0.600662350654602
    z[2,6,0]  R1491     2.7329126000404358e-01
    z[2,6,0]  R1492     6.2698286771774292e-01
    z[2,6,0]  R1493     2.1078411489725113e-02
    z[2,6,0]  R1494     2.4044297635555267e-01
    z[2,6,0]  R1495     -3.8858661055564880e-01
    z[2,6,0]  R1496     -4.6192719601094723e-03
    z[2,6,0]  R1497     5.2527695894241333e-01
    z[2,6,0]  R1498     -6.3333630561828613e-01
    z[2,6,0]  R1499     4.8260340094566345e-01
    z[2,6,0]  R1500     -6.0316592454910278e-01
    z[2,6,0]  R1501     3.4032773971557617e-01
    z[2,6,0]  R1502     2.0777510106563568e-01
    z[2,6,0]  R1503     -3.5108034498989582e-03
    z[2,6,0]  R1504     4.8921483755111694e-01
    z[2,6,0]  R1505     -9.1450080275535583e-02
    z[2,6,0]  R1506     2.1135492622852325e-01
    z[2,6,0]  R1507     2.4746231734752655e-01
    z[2,6,0]  R1508     -1.0800433158874512e-01
    z[2,6,0]  R1509     -4.7529187798500061e-01
    z[2,6,0]  R1510     -0.620422899723053
    z[2,6,0]  R1511     -8.1994032859802246e-01
    z[2,6,0]  R1512     2.0614795386791229e-01
    z[2,6,0]  R1513     -7.1798115968704224e-02
    z[2,6,0]  R1514     2.6360219717025757e-01
    z[2,6,0]  R1515     1.6038280725479126e-01
    z[2,6,0]  R1516     6.0919380187988281e-01
    z[2,6,0]  R1517     7.2385388612747192e-01
    z[2,6,0]  R1518     -1.1970573104918003e-03
    z[2,6,0]  R1519     3.9835777878761292e-01
    z[2,6,0]  R1520     -3.0083894729614258e-01
    z[2,6,0]  R1521     -3.6715969443321228e-01
    z[2,6,0]  R1522     -4.1392204165458679e-01
    z[2,6,0]  R1523     4.1932117938995361e-01
    z[2,6,0]  R1524     -1.1834224313497543e-01
    z[2,6,0]  R1525     -3.0072543025016785e-01
    z[2,6,0]  R1526     -7.6365791261196136e-02
    z[2,6,0]  R1527     -1.2636126577854156e-01
    z[2,6,0]  R1528     -8.2340574264526367e-01
    z[2,6,0]  R1529     -1.9203135371208191e-01
    z[2,6,0]  R1530     9.6498638391494751e-02
    z[2,6,0]  R1531     -3.2801163196563721e-01
    z[2,6,0]  R1532     -5.0426584482192993e-01
    z[2,6,0]  R1533     3.8767620921134949e-01
    z[2,6,0]  R1534     3.7921980023384094e-01
    z[2,6,0]  R1535     3.0902782082557678e-01
    z[2,6,0]  R1536     2.1062324941158295e-01
    z[2,6,0]  R1537     1.6345719993114471e-01
    z[2,6,0]  R1538     -7.6807297766208649e-02
    z[2,6,0]  R1539     -5.3572410345077515e-01
    z[2,6,0]  R1540     0.298926442861557
    z[2,6,0]  R1541     1.9086718559265137e-01
    z[2,6,0]  R1542     3.7786403298377991e-01
    z[2,6,0]  R1543     -5.9229653328657150e-02
    z[2,6,0]  R1544     0.685613214969635
    z[2,6,1]  R21       -1
    z[2,6,1]  R57       1
    z[2,6,1]  R1426     -1
    z[2,6,1]  R1427     1
    z[2,6,1]  R1438     1.6793204471468925e-02
    z[2,6,1]  R1439     4.1982802748680115e-01
    z[2,6,1]  R1440     -3.0217638611793518e-01
    z[2,6,1]  R1441     3.3735528588294983e-01
    z[2,6,1]  R1442     -2.1396717429161072e-01
    z[2,6,1]  R1443     -1.4922298491001129e-01
    z[2,6,1]  R1444     -4.6211519837379456e-01
    z[2,6,1]  R1445     -2.4508625268936157e-01
    z[2,6,1]  R1446     -1.8263725936412811e-01
    z[2,6,1]  R1447     -2.3488880693912506e-01
    z[2,6,1]  R1448     -1.6358684003353119e-01
    z[2,6,1]  R1449     5.3442692756652832e-01
    z[2,6,1]  R1450     5.0623804330825806e-01
    z[2,6,1]  R1451     4.6645689010620117e-01
    z[2,6,1]  R1452     6.5295898914337158e-01
    z[2,6,1]  R1453     -9.4652932882308960e-01
    z[2,6,1]  R1454     -0.909305214881897
    z[2,6,1]  R1455     6.1326795816421509e-01
    z[2,6,1]  R1456     5.5151903629302979e-01
    z[2,6,1]  R1457     4.0061524510383606e-01
    z[2,6,1]  R1458     -0.264529287815094
    z[2,6,1]  R1459     -1.4760753512382507e-01
    z[2,6,1]  R1460     7.9781192541122437e-01
    z[2,6,1]  R1461     -1.7197097837924957e-01
    z[2,6,1]  R1462     1.4941245317459106e-01
    z[2,6,1]  R1463     4.4548544287681580e-01
    z[2,6,1]  R1464     0.653929591178894
    z[2,6,1]  R1465     4.0577349066734314e-01
    z[2,6,1]  R1466     -3.6976438760757446e-01
    z[2,6,1]  R1467     -6.7304052412509918e-02
    z[2,6,1]  R1468     4.9294161796569824e-01
    z[2,6,1]  R1469     3.5584241151809692e-01
    z[2,6,1]  R1470     3.9754968881607056e-01
    z[2,6,1]  R1471     1.6869686543941498e-02
    z[2,6,1]  R1472     7.1616090834140778e-02
    z[2,6,1]  R1473     2.5303310155868530e-01
    z[2,6,1]  R1474     -1.7502473667263985e-02
    z[2,6,1]  R1475     6.7946580238640308e-03
    z[2,6,1]  R1476     -4.3117246031761169e-01
    z[2,6,1]  R1477     3.8872316479682922e-01
    z[2,6,1]  R1478     -1.3841395080089569e-01
    z[2,6,1]  R1479     -4.6720635145902634e-02
    z[2,6,1]  R1480     5.3251668810844421e-02
    z[2,6,1]  R1481     3.9715209603309631e-01
    z[2,6,1]  R1482     -2.7576866745948792e-01
    z[2,6,1]  R1483     4.9373021721839905e-01
    z[2,6,1]  R1484     -5.0862950086593628e-01
    z[2,6,1]  R1485     -4.7206935286521912e-01
    z[2,6,1]  R1486     -9.2534351348876953e-01
    z[2,6,1]  R1487     -9.3733829259872437e-01
    z[2,6,1]  R1488     5.0692892074584961e-01
    z[2,6,1]  R1489     5.6872403621673584e-01
    z[2,6,1]  R1490     -5.3618443012237549e-01
    z[2,6,1]  R1491     -6.4487606287002563e-01
    z[2,6,1]  R1492     -3.6818471550941467e-01
    z[2,6,1]  R1493     -7.2963792085647583e-01
    z[2,6,1]  R1494     -8.2487720251083374e-01
    z[2,6,1]  R1495     7.6968425512313843e-01
    z[2,6,1]  R1496     -7.7254432439804077e-01
    z[2,6,1]  R1497     -2.3884780704975128e-01
    z[2,6,1]  R1498     3.0962151288986206e-01
    z[2,6,1]  R1499     -5.0188940763473511e-01
    z[2,6,1]  R1500     -9.2821039259433746e-02
    z[2,6,1]  R1501     -2.9327511787414551e-01
    z[2,6,1]  R1502     -0.954384446144104
    z[2,6,1]  R1503     -8.4556078910827637e-01
    z[2,6,1]  R1504     -1.5219414234161377e-01
    z[2,6,1]  R1505     -8.5327720642089844e-01
    z[2,6,1]  R1506     -8.0013388395309448e-01
    z[2,6,1]  R1507     -0.837171733379364
    z[2,6,1]  R1508     5.9243518114089966e-01
    z[2,6,1]  R1509     5.3607380390167236e-01
    z[2,6,1]  R1510     5.0177198648452759e-01
    z[2,6,1]  R1511     -4.3665003776550293e-01
    z[2,6,1]  R1512     -9.2628234624862671e-01
    z[2,6,1]  R1513     -8.7773799896240234e-01
    z[2,6,1]  R1514     9.4409698247909546e-01
    z[2,6,1]  R1515     9.3283069133758545e-01
    z[2,6,1]  R1516     4.4027809053659439e-02
    z[2,6,1]  R1517     -4.1449481248855591e-01
    z[2,6,1]  R1518     -2.2033055126667023e-01
    z[2,6,1]  R1519     4.5959314703941345e-01
    z[2,6,1]  R1520     1.1390078812837601e-01
    z[2,6,1]  R1521     2.0924666523933411e-01
    z[2,6,1]  R1522     4.6872356534004211e-01
    z[2,6,1]  R1523     6.3018488883972168e-01
    z[2,6,1]  R1524     8.3565098047256470e-01
    z[2,6,1]  R1525     6.2042653560638428e-01
    z[2,6,1]  R1526     5.0904005765914917e-01
    z[2,6,1]  R1527     -3.0407229065895081e-01
    z[2,6,1]  R1528     9.4793796539306641e-02
    z[2,6,1]  R1529     2.8459683060646057e-01
    z[2,6,1]  R1530     -9.0831464529037476e-01
    z[2,6,1]  R1531     -5.9445196390151978e-01
    z[2,6,1]  R1532     -6.4131164550781250e-01
    z[2,6,1]  R1533     -6.1285120248794556e-01
    z[2,6,1]  R1534     -2.4251176416873932e-01
    z[2,6,1]  R1535     -3.5514634847640991e-01
    z[2,6,1]  R1536     -5.4501199722290039e-01
    z[2,6,1]  R1537     -4.6743515133857727e-01
    z[2,6,1]  R1538     -6.1531532555818558e-02
    z[2,6,1]  R1539     1.4721401967108250e-02
    z[2,6,1]  R1540     -2.9983457922935486e-01
    z[2,6,1]  R1541     -0.711582601070404
    z[2,6,1]  R1542     -1.3799284398555756e-01
    z[2,6,1]  R1543     -2.6491332054138184e-01
    z[2,6,1]  R1544     -3.3857762813568115e-01
    z[2,6,2]  R22       -1
    z[2,6,2]  R58       1
    z[2,6,2]  R1428     -1
    z[2,6,2]  R1429     1
    z[2,6,2]  R1438     5.3428955376148224e-02
    z[2,6,2]  R1439     4.7465705871582031e-01
    z[2,6,2]  R1440     3.6648120731115341e-02
    z[2,6,2]  R1441     0.377734899520874
    z[2,6,2]  R1442     6.5484158694744110e-02
    z[2,6,2]  R1443     -1.2441141903400421e-01
    z[2,6,2]  R1444     2.5291427969932556e-01
    z[2,6,2]  R1445     -2.6075729727745056e-01
    z[2,6,2]  R1446     -2.3586069047451019e-01
    z[2,6,2]  R1447     2.9757454991340637e-01
    z[2,6,2]  R1448     1.2146435678005219e-01
    z[2,6,2]  R1449     -4.2763182520866394e-01
    z[2,6,2]  R1450     0.0552813895046711
    z[2,6,2]  R1451     -3.2051667571067810e-01
    z[2,6,2]  R1452     -5.6332081556320190e-01
    z[2,6,2]  R1453     4.8455204814672470e-02
    z[2,6,2]  R1454     2.8371301293373108e-01
    z[2,6,2]  R1455     -2.1615797281265259e-01
    z[2,6,2]  R1456     -3.4118276834487915e-01
    z[2,6,2]  R1457     -4.3730372190475464e-01
    z[2,6,2]  R1458     4.1211673617362976e-01
    z[2,6,2]  R1459     4.9223366379737854e-01
    z[2,6,2]  R1460     -1.7958946526050568e-02
    z[2,6,2]  R1461     4.7048786282539368e-01
    z[2,6,2]  R1462     -3.8058489561080933e-01
    z[2,6,2]  R1463     -3.2974272966384888e-01
    z[2,6,2]  R1464     5.8110468089580536e-02
    z[2,6,2]  R1465     -1.9358810782432556e-01
    z[2,6,2]  R1466     -6.7814439535140991e-01
    z[2,6,2]  R1467     -0.0276302732527256
    z[2,6,2]  R1468     -1.1719395220279694e-01
    z[2,6,2]  R1469     -9.6887126564979553e-02
    z[2,6,2]  R1470     3.9203721284866333e-01
    z[2,6,2]  R1471     -9.0094834566116333e-02
    z[2,6,2]  R1472     4.0363538265228271e-01
    z[2,6,2]  R1473     2.3727929592132568e-01
    z[2,6,2]  R1474     3.7829467654228210e-01
    z[2,6,2]  R1475     2.0727132260799408e-01
    z[2,6,2]  R1476     -3.5161191225051880e-01
    z[2,6,2]  R1477     -1.8203815817832947e-01
    z[2,6,2]  R1478     5.9477311372756958e-01
    z[2,6,2]  R1479     3.3852979540824890e-01
    z[2,6,2]  R1480     0.564498245716095
    z[2,6,2]  R1481     -3.1396320462226868e-01
    z[2,6,2]  R1482     1.2137076258659363e-01
    z[2,6,2]  R1483     -3.5435834527015686e-01
    z[2,6,2]  R1484     -0.539020299911499
    z[2,6,2]  R1485     -2.3951514065265656e-01
    z[2,6,2]  R1486     1.6637371480464935e-01
    z[2,6,2]  R1487     -6.2574379146099091e-02
    z[2,6,2]  R1488     1.5445311367511749e-01
    z[2,6,2]  R1489     -3.8655731081962585e-01
    z[2,6,2]  R1490     -2.5803402066230774e-01
    z[2,6,2]  R1491     -5.0074491649866104e-02
    z[2,6,2]  R1492     -1.7812184989452362e-01
    z[2,6,2]  R1493     6.3637781143188477e-01
    z[2,6,2]  R1494     4.4004756212234497e-01
    z[2,6,2]  R1495     -3.7844008207321167e-01
    z[2,6,2]  R1496     4.7437658905982971e-01
    z[2,6,2]  R1497     -1.9614732265472412e-01
    z[2,6,2]  R1498     2.9345509409904480e-01
    z[2,6,2]  R1499     1.8945498391985893e-02
    z[2,6,2]  R1500     -2.8382557630538940e-01
    z[2,6,2]  R1501     -7.5607880949974060e-02
    z[2,6,2]  R1502     4.0291804820299149e-02
    z[2,6,2]  R1503     -3.9303341507911682e-01
    z[2,6,2]  R1504     2.5031521916389465e-01
    z[2,6,2]  R1505     3.0954939126968384e-01
    z[2,6,2]  R1506     2.4709241092205048e-01
    z[2,6,2]  R1507     -1.3379940390586853e-01
    z[2,6,2]  R1508     0.374731183052063
    z[2,6,2]  R1509     -2.3399564623832703e-01
    z[2,6,2]  R1510     -1.5763019025325775e-01
    z[2,6,2]  R1511     -2.4272593855857849e-01
    z[2,6,2]  R1512     1.6245366632938385e-01
    z[2,6,2]  R1513     -2.3109002411365509e-01
    z[2,6,2]  R1514     5.0432592630386353e-02
    z[2,6,2]  R1515     1.3996334373950958e-01
    z[2,6,2]  R1516     0.632743239402771
    z[2,6,2]  R1517     -1.8757671117782593e-01
    z[2,6,2]  R1518     -1.5700127184391022e-01
    z[2,6,2]  R1519     4.0909403562545776e-01
    z[2,6,2]  R1520     -6.0636216402053833e-01
    z[2,6,2]  R1521     -4.0500751137733459e-01
    z[2,6,2]  R1522     1.3352312147617340e-02
    z[2,6,2]  R1523     -7.7508250251412392e-03
    z[2,6,2]  R1524     -5.8390375226736069e-02
    z[2,6,2]  R1525     3.7913840264081955e-02
    z[2,6,2]  R1526     2.6878255605697632e-01
    z[2,6,2]  R1527     2.1994440257549286e-01
    z[2,6,2]  R1528     5.1407706737518311e-01
    z[2,6,2]  R1529     -0.190054789185524
    z[2,6,2]  R1530     8.1887438893318176e-02
    z[2,6,2]  R1531     1.0052428394556046e-01
    z[2,6,2]  R1532     -2.0116455852985382e-01
    z[2,6,2]  R1533     5.0907045602798462e-01
    z[2,6,2]  R1534     6.6290384531021118e-01
    z[2,6,2]  R1535     4.4923242926597595e-01
    z[2,6,2]  R1536     4.0708842873573303e-01
    z[2,6,2]  R1537     5.3370285034179688e-01
    z[2,6,2]  R1538     -4.0093046426773071e-01
    z[2,6,2]  R1539     -2.1145179867744446e-01
    z[2,6,2]  R1540     -8.2104299217462540e-03
    z[2,6,2]  R1541     3.5090631246566772e-01
    z[2,6,2]  R1542     4.9911147356033325e-01
    z[2,6,2]  R1543     2.3015265166759491e-01
    z[2,6,2]  R1544     -5.2543884515762329e-01
    z[2,6,3]  R23       -1
    z[2,6,3]  R59       1
    z[2,6,3]  R1430     -1
    z[2,6,3]  R1431     1
    z[2,6,3]  R1438     -5.7658666372299194e-01
    z[2,6,3]  R1439     -4.8413532972335815e-01
    z[2,6,3]  R1440     5.0298297405242920e-01
    z[2,6,3]  R1441     -3.8413512706756592e-01
    z[2,6,3]  R1442     6.3380491733551025e-01
    z[2,6,3]  R1443     4.7572395205497742e-01
    z[2,6,3]  R1444     -4.7816762328147888e-01
    z[2,6,3]  R1445     4.1079682111740112e-01
    z[2,6,3]  R1446     6.8301928043365479e-01
    z[2,6,3]  R1447     4.1419026255607605e-01
    z[2,6,3]  R1448     5.2072703838348389e-01
    z[2,6,3]  R1449     -4.7158092260360718e-01
    z[2,6,3]  R1450     -4.2060464620590210e-01
    z[2,6,3]  R1451     -2.1827220916748047e-02
    z[2,6,3]  R1452     -4.3719586730003357e-01
    z[2,6,3]  R1453     2.4062652885913849e-01
    z[2,6,3]  R1454     1.5694554895162582e-02
    z[2,6,3]  R1455     4.5493260025978088e-01
    z[2,6,3]  R1456     -5.2448230981826782e-01
    z[2,6,3]  R1457     1.5438485145568848e-01
    z[2,6,3]  R1458     -9.3475859612226486e-03
    z[2,6,3]  R1459     -7.0925705134868622e-02
    z[2,6,3]  R1460     -3.5661661624908447e-01
    z[2,6,3]  R1461     3.1329268217086792e-01
    z[2,6,3]  R1462     -7.3681735992431641e-01
    z[2,6,3]  R1463     1.6105762124061584e-01
    z[2,6,3]  R1464     2.0723575726151466e-03
    z[2,6,3]  R1465     -8.0785721540451050e-01
    z[2,6,3]  R1466     2.6825010776519775e-01
    z[2,6,3]  R1467     1.4808334410190582e-01
    z[2,6,3]  R1468     -5.6925994157791138e-01
    z[2,6,3]  R1469     -7.7147370576858521e-01
    z[2,6,3]  R1470     -5.1840478181838989e-01
    z[2,6,3]  R1471     -3.9839029312133789e-01
    z[2,6,3]  R1472     -1.6759096086025238e-01
    z[2,6,3]  R1473     2.2435568273067474e-01
    z[2,6,3]  R1474     -5.7995975017547607e-01
    z[2,6,3]  R1475     -5.5508546531200409e-02
    z[2,6,3]  R1476     -0.162618488073349
    z[2,6,3]  R1477     -1.8966302275657654e-01
    z[2,6,3]  R1478     -1.6043733060359955e-01
    z[2,6,3]  R1479     -3.4989330917596817e-02
    z[2,6,3]  R1480     -4.5814856886863708e-01
    z[2,6,3]  R1481     -4.3502718210220337e-01
    z[2,6,3]  R1482     -4.5113736391067505e-01
    z[2,6,3]  R1483     -1.7009107768535614e-01
    z[2,6,3]  R1484     2.9478520154953003e-01
    z[2,6,3]  R1485     1.8935614824295044e-01
    z[2,6,3]  R1486     2.7815201878547668e-01
    z[2,6,3]  R1487     1.7314006388187408e-01
    z[2,6,3]  R1488     -7.3491680622100830e-01
    z[2,6,3]  R1489     -5.5577796697616577e-01
    z[2,6,3]  R1490     1.8954205513000488e-01
    z[2,6,3]  R1491     4.7849395871162415e-01
    z[2,6,3]  R1492     6.3952714204788208e-02
    z[2,6,3]  R1493     -1.4681740105152130e-01
    z[2,6,3]  R1494     0.00597138237208128
    z[2,6,3]  R1495     2.1508035063743591e-01
    z[2,6,3]  R1496     1.8963800370693207e-01
    z[2,6,3]  R1497     6.0778830200433731e-02
    z[2,6,3]  R1498     -0.0553843230009079
    z[2,6,3]  R1499     0.38902547955513
    z[2,6,3]  R1500     2.6066571474075317e-01
    z[2,6,3]  R1501     3.7355315685272217e-01
    z[2,6,3]  R1502     -8.0543659627437592e-02
    z[2,6,3]  R1503     2.9656881093978882e-01
    z[2,6,3]  R1504     2.5672686100006104e-01
    z[2,6,3]  R1505     -2.0979759097099304e-01
    z[2,6,3]  R1506     7.3786050081253052e-02
    z[2,6,3]  R1507     2.5442928075790405e-01
    z[2,6,3]  R1508     -0.555517852306366
    z[2,6,3]  R1509     -3.0220049619674683e-01
    z[2,6,3]  R1510     -4.7199490666389465e-01
    z[2,6,3]  R1511     -1.3955840468406677e-01
    z[2,6,3]  R1512     -7.2610370814800262e-02
    z[2,6,3]  R1513     -3.0861049890518188e-01
    z[2,6,3]  R1514     9.9657423794269562e-02
    z[2,6,3]  R1515     1.7827060818672180e-01
    z[2,6,3]  R1516     -0.0658518373966217
    z[2,6,3]  R1517     -2.5762474536895752e-01
    z[2,6,3]  R1518     1.8152070045471191e-01
    z[2,6,3]  R1519     3.0024429783225060e-02
    z[2,6,3]  R1520     -6.7329630255699158e-02
    z[2,6,3]  R1521     1.4320933818817139e-01
    z[2,6,3]  R1522     -5.0282761454582214e-02
    z[2,6,3]  R1523     5.4868827573955059e-03
    z[2,6,3]  R1524     -7.1596577763557434e-02
    z[2,6,3]  R1525     6.7600446939468384e-01
    z[2,6,3]  R1526     0.30000039935112
    z[2,6,3]  R1527     0.794006884098053
    z[2,6,3]  R1528     1.1935956031084061e-01
    z[2,6,3]  R1529     -6.9941782951354980e-01
    z[2,6,3]  R1530     0.301226943731308
    z[2,6,3]  R1531     3.8864842057228088e-01
    z[2,6,3]  R1532     2.3955328762531281e-01
    z[2,6,3]  R1533     2.5290060043334961e-01
    z[2,6,3]  R1534     7.8742668032646179e-02
    z[2,6,3]  R1535     4.4505367986857891e-03
    z[2,6,3]  R1536     -4.0808707475662231e-02
    z[2,6,3]  R1537     3.4651394933462143e-02
    z[2,6,3]  R1538     -4.1442832350730896e-01
    z[2,6,3]  R1539     -4.0571314096450806e-01
    z[2,6,3]  R1540     -7.3294615745544434e-01
    z[2,6,3]  R1541     2.0180614292621613e-01
    z[2,6,3]  R1542     -3.9547482132911682e-01
    z[2,6,3]  R1543     -3.7801361083984375e-01
    z[2,6,3]  R1544     -9.5134507864713669e-03
    z[2,6,4]  R24       -1
    z[2,6,4]  R60       1
    z[2,6,4]  R1432     -1
    z[2,6,4]  R1433     1
    z[2,6,4]  R1438     0.585985004901886
    z[2,6,4]  R1439     4.5392480492591858e-01
    z[2,6,4]  R1440     -4.9370858818292618e-02
    z[2,6,4]  R1441     2.9065108299255371e-01
    z[2,6,4]  R1442     0.0555245578289032
    z[2,6,4]  R1443     -8.8652148842811584e-02
    z[2,6,4]  R1444     1.3986818492412567e-01
    z[2,6,4]  R1445     1.1174959689378738e-01
    z[2,6,4]  R1446     -8.8005885481834412e-02
    z[2,6,4]  R1447     0.0831865444779396
    z[2,6,4]  R1448     -8.0534592270851135e-03
    z[2,6,4]  R1449     2.4362045526504517e-01
    z[2,6,4]  R1450     2.3618039488792419e-01
    z[2,6,4]  R1451     -3.3481118083000183e-01
    z[2,6,4]  R1452     1.1404404789209366e-01
    z[2,6,4]  R1453     -1.1398802697658539e-01
    z[2,6,4]  R1454     -8.5143849253654480e-02
    z[2,6,4]  R1455     -1.4496196806430817e-01
    z[2,6,4]  R1456     -2.6472138240933418e-02
    z[2,6,4]  R1457     3.2402139902114868e-01
    z[2,6,4]  R1458     1.8986824154853821e-01
    z[2,6,4]  R1459     -3.4458765387535095e-01
    z[2,6,4]  R1460     -1.5601888298988342e-01
    z[2,6,4]  R1461     -3.3036106824874878e-01
    z[2,6,4]  R1462     7.9754993319511414e-02
    z[2,6,4]  R1463     2.2440824657678604e-02
    z[2,6,4]  R1464     -5.4176026023924351e-03
    z[2,6,4]  R1465     -8.7099701166152954e-02
    z[2,6,4]  R1466     -3.8170254230499268e-01
    z[2,6,4]  R1467     2.8691646456718445e-01
    z[2,6,4]  R1468     0.372158020734787
    z[2,6,4]  R1469     4.3288782238960266e-02
    z[2,6,4]  R1470     -1.2515020370483398e-01
    z[2,6,4]  R1471     9.4737574458122253e-02
    z[2,6,4]  R1472     -1.8336981534957886e-01
    z[2,6,4]  R1473     3.9586311578750610e-01
    z[2,6,4]  R1474     -2.0542104542255402e-01
    z[2,6,4]  R1475     -3.3603996038436890e-02
    z[2,6,4]  R1476     2.5538778305053711e-01
    z[2,6,4]  R1477     -3.2243865728378296e-01
    z[2,6,4]  R1478     1.0967319458723068e-01
    z[2,6,4]  R1479     2.0001262426376343e-01
    z[2,6,4]  R1480     -2.1655750274658203e-01
    z[2,6,4]  R1481     4.7490587830543518e-01
    z[2,6,4]  R1482     -1.1311549693346024e-01
    z[2,6,4]  R1483     0.269917756319046
    z[2,6,4]  R1484     -6.3240818679332733e-02
    z[2,6,4]  R1485     -4.9538484215736389e-01
    z[2,6,4]  R1486     1.2240315973758698e-01
    z[2,6,4]  R1487     1.0413980484008789e-01
    z[2,6,4]  R1488     8.3759091794490814e-02
    z[2,6,4]  R1489     -5.6565467268228531e-02
    z[2,6,4]  R1490     -1.3234561309218407e-02
    z[2,6,4]  R1491     -5.1011848449707031e-01
    z[2,6,4]  R1492     -5.7242041826248169e-01
    z[2,6,4]  R1493     0.0806722566485405
    z[2,6,4]  R1494     2.3295298218727112e-01
    z[2,6,4]  R1495     6.3670896925032139e-03
    z[2,6,4]  R1496     1.4857368171215057e-01
    z[2,6,4]  R1497     -7.8706592321395874e-01
    z[2,6,4]  R1498     5.9010720252990723e-01
    z[2,6,4]  R1499     -4.9014893174171448e-01
    z[2,6,4]  R1500     3.4605216979980469e-01
    z[2,6,4]  R1501     -0.784143328666687
    z[2,6,4]  R1502     1.6048873960971832e-01
    z[2,6,4]  R1503     -1.6336247324943542e-01
    z[2,6,4]  R1504     -7.4287265539169312e-01
    z[2,6,4]  R1505     2.8813734650611877e-01
    z[2,6,4]  R1506     3.4640464186668396e-01
    z[2,6,4]  R1507     2.3118773102760315e-01
    z[2,6,4]  R1508     2.5349294766783714e-02
    z[2,6,4]  R1509     5.0959908962249756e-01
    z[2,6,4]  R1510     5.9191279113292694e-02
    z[2,6,4]  R1511     -1.9709999859333038e-01
    z[2,6,4]  R1512     2.4052542448043823e-01
    z[2,6,4]  R1513     -9.3885980546474457e-02
    z[2,6,4]  R1514     2.2049862891435623e-02
    z[2,6,4]  R1515     1.2017721310257912e-02
    z[2,6,4]  R1516     -1.8670603632926941e-01
    z[2,6,4]  R1517     4.3236309289932251e-01
    z[2,6,4]  R1518     9.3230515718460083e-01
    z[2,6,4]  R1519     6.4843553304672241e-01
    z[2,6,4]  R1520     1.8940374255180359e-01
    z[2,6,4]  R1521     6.5703099966049194e-01
    z[2,6,4]  R1522     1.8320725858211517e-01
    z[2,6,4]  R1523     0.368007093667984
    z[2,6,4]  R1524     -3.9148527383804321e-01
    z[2,6,4]  R1525     -0.251006543636322
    z[2,6,4]  R1526     -3.4782004356384277e-01
    z[2,6,4]  R1527     -2.3502174019813538e-01
    z[2,6,4]  R1528     -1.3876289129257202e-01
    z[2,6,4]  R1529     -2.9398933053016663e-01
    z[2,6,4]  R1530     -2.4249014258384705e-01
    z[2,6,4]  R1531     -5.0091665983200073e-01
    z[2,6,4]  R1532     -4.2328283190727234e-01
    z[2,6,4]  R1533     6.4704000949859619e-02
    z[2,6,4]  R1534     -5.7221513986587524e-01
    z[2,6,4]  R1535     -5.2367347478866577e-01
    z[2,6,4]  R1536     -1.4771215617656708e-01
    z[2,6,4]  R1537     -3.8605967164039612e-01
    z[2,6,4]  R1538     4.0591907501220703e-01
    z[2,6,4]  R1539     -5.4308164119720459e-01
    z[2,6,4]  R1540     0.496865838766098
    z[2,6,4]  R1541     3.9167352952063084e-03
    z[2,6,4]  R1542     -5.3028100728988647e-01
    z[2,6,4]  R1543     -4.0601128339767456e-01
    z[2,6,4]  R1544     -2.8760954737663269e-01
    z[2,6,5]  R25       -1
    z[2,6,5]  R61       1
    z[2,6,5]  R1434     -1
    z[2,6,5]  R1435     1
    z[2,6,5]  R1438     4.0886640548706055e-01
    z[2,6,5]  R1439     1.1239586770534515e-01
    z[2,6,5]  R1440     -1.2824654579162598e-01
    z[2,6,5]  R1441     4.8890876770019531e-01
    z[2,6,5]  R1442     2.4667195975780487e-01
    z[2,6,5]  R1443     3.0765545368194580e-01
    z[2,6,5]  R1444     -1.6746150329709053e-02
    z[2,6,5]  R1445     -0.0683315098285675
    z[2,6,5]  R1446     1.2376486510038376e-01
    z[2,6,5]  R1447     3.5071703791618347e-01
    z[2,6,5]  R1448     -1.2956143915653229e-01
    z[2,6,5]  R1449     -3.2415542006492615e-01
    z[2,6,5]  R1450     -5.3670185804367065e-01
    z[2,6,5]  R1451     1.8109139800071716e-01
    z[2,6,5]  R1452     -9.8403267562389374e-02
    z[2,6,5]  R1453     -2.3633357137441635e-02
    z[2,6,5]  R1454     8.2218162715435028e-02
    z[2,6,5]  R1455     6.8722128868103027e-02
    z[2,6,5]  R1456     -1.4278912544250488e-01
    z[2,6,5]  R1457     -9.1430328786373138e-02
    z[2,6,5]  R1458     -6.5892316401004791e-02
    z[2,6,5]  R1459     1.1503832787275314e-01
    z[2,6,5]  R1460     -3.3437585830688477e-01
    z[2,6,5]  R1461     1.0261550545692444e-01
    z[2,6,5]  R1462     -3.5006096959114075e-01
    z[2,6,5]  R1463     -1.1785305291414261e-01
    z[2,6,5]  R1464     -1.3829918205738068e-01
    z[2,6,5]  R1465     -3.6164256930351257e-01
    z[2,6,5]  R1466     -2.0925061404705048e-01
    z[2,6,5]  R1467     1.5344475209712982e-01
    z[2,6,5]  R1468     -3.1367599964141846e-01
    z[2,6,5]  R1469     -3.9566081017255783e-02
    z[2,6,5]  R1470     -5.5153405666351318e-01
    z[2,6,5]  R1471     -2.1115562319755554e-01
    z[2,6,5]  R1472     -2.5290203094482422e-01
    z[2,6,5]  R1473     -3.4231055527925491e-02
    z[2,6,5]  R1474     -3.9365702867507935e-01
    z[2,6,5]  R1475     7.4246935546398163e-02
    z[2,6,5]  R1476     1.3931236229836941e-02
    z[2,6,5]  R1477     1.0323248058557510e-01
    z[2,6,5]  R1478     1.1458898894488811e-02
    z[2,6,5]  R1479     6.0198950767517090e-01
    z[2,6,5]  R1480     -5.7573366910219193e-02
    z[2,6,5]  R1481     -2.5862815976142883e-01
    z[2,6,5]  R1482     2.9186886548995972e-01
    z[2,6,5]  R1483     0.00526859937235713
    z[2,6,5]  R1484     2.1128852665424347e-01
    z[2,6,5]  R1485     -2.2448942065238953e-01
    z[2,6,5]  R1486     -2.1524254232645035e-02
    z[2,6,5]  R1487     2.6794016361236572e-01
    z[2,6,5]  R1488     -6.7306622862815857e-02
    z[2,6,5]  R1489     -4.4824701547622681e-01
    z[2,6,5]  R1490     2.5261655449867249e-01
    z[2,6,5]  R1491     9.6087656915187836e-02
    z[2,6,5]  R1492     1.1172868311405182e-02
    z[2,6,5]  R1493     -1.1932700127363205e-01
    z[2,6,5]  R1494     -9.9355757236480713e-02
    z[2,6,5]  R1495     0.0643991008400917
    z[2,6,5]  R1496     -1.3695776462554932e-01
    z[2,6,5]  R1497     6.5878160297870636e-02
    z[2,6,5]  R1498     2.0843271911144257e-01
    z[2,6,5]  R1499     1.0014345496892929e-01
    z[2,6,5]  R1500     2.5994306802749634e-01
    z[2,6,5]  R1501     -7.1071274578571320e-02
    z[2,6,5]  R1502     -1.0951571911573410e-01
    z[2,6,5]  R1503     1.1942744255065918e-01
    z[2,6,5]  R1504     2.3815682530403137e-01
    z[2,6,5]  R1505     1.6805014014244080e-01
    z[2,6,5]  R1506     3.5341310501098633e-01
    z[2,6,5]  R1507     -5.7587809860706329e-03
    z[2,6,5]  R1508     -4.3268963694572449e-01
    z[2,6,5]  R1509     -2.1182611584663391e-01
    z[2,6,5]  R1510     -1.6084384918212891e-01
    z[2,6,5]  R1511     -5.2090730518102646e-02
    z[2,6,5]  R1512     5.4125446826219559e-02
    z[2,6,5]  R1513     -2.0764803886413574e-01
    z[2,6,5]  R1514     1.2295242398977280e-01
    z[2,6,5]  R1515     2.0872300863265991e-01
    z[2,6,5]  R1516     1.1930776387453079e-01
    z[2,6,5]  R1517     -3.1884968280792236e-02
    z[2,6,5]  R1518     -1.2142031639814377e-01
    z[2,6,5]  R1519     -7.2115555405616760e-02
    z[2,6,5]  R1520     5.1024538278579712e-01
    z[2,6,5]  R1521     3.6064037680625916e-01
    z[2,6,5]  R1522     -4.1838459670543671e-02
    z[2,6,5]  R1523     -7.2465568780899048e-02
    z[2,6,5]  R1524     -2.2915486246347427e-02
    z[2,6,5]  R1525     -1.7315704608336091e-03
    z[2,6,5]  R1526     6.7093491554260254e-01
    z[2,6,5]  R1527     3.9473345875740051e-01
    z[2,6,5]  R1528     3.2030217349529266e-02
    z[2,6,5]  R1529     -0.512298047542572
    z[2,6,5]  R1530     -3.6583945620805025e-03
    z[2,6,5]  R1531     -8.8016480207443237e-02
    z[2,6,5]  R1532     -1.2372436374425888e-01
    z[2,6,5]  R1533     8.2141578197479248e-02
    z[2,6,5]  R1534     9.2413406819105148e-03
    z[2,6,5]  R1535     8.6203746497631073e-02
    z[2,6,5]  R1536     0.583867073059082
    z[2,6,5]  R1537     3.3442100882530212e-01
    z[2,6,5]  R1538     -6.9211864471435547e-01
    z[2,6,5]  R1539     -4.0671899914741516e-01
    z[2,6,5]  R1540     1.3982349634170532e-01
    z[2,6,5]  R1541     -3.4050858020782471e-01
    z[2,6,5]  R1542     3.8897618651390076e-01
    z[2,6,5]  R1543     6.8253362178802490e-01
    z[2,6,5]  R1544     1.4928117394447327e-01
    z[2,6,6]  R26       -1
    z[2,6,6]  R62       1
    z[2,6,6]  R1436     -1
    z[2,6,6]  R1437     1
    z[2,6,6]  R1438     -2.7494572568684816e-03
    z[2,6,6]  R1439     1.4613977074623108e-01
    z[2,6,6]  R1440     -2.2966891992837191e-03
    z[2,6,6]  R1441     -3.0455753207206726e-01
    z[2,6,6]  R1442     -9.2454567551612854e-02
    z[2,6,6]  R1443     -1.3331221416592598e-02
    z[2,6,6]  R1444     0.0850360244512558
    z[2,6,6]  R1445     3.3200240135192871e-01
    z[2,6,6]  R1446     1.2971581518650055e-01
    z[2,6,6]  R1447     -1.3002598285675049e-01
    z[2,6,6]  R1448     6.4658035989850760e-04
    z[2,6,6]  R1449     1.4682596921920776e-01
    z[2,6,6]  R1450     4.6131512522697449e-01
    z[2,6,6]  R1451     -4.1206661611795425e-02
    z[2,6,6]  R1452     -7.7206864953041077e-02
    z[2,6,6]  R1453     9.6304953098297119e-02
    z[2,6,6]  R1454     -2.2544731199741364e-01
    z[2,6,6]  R1455     -1.8545429408550262e-01
    z[2,6,6]  R1456     -4.2595180869102478e-01
    z[2,6,6]  R1457     -2.8930693864822388e-01
    z[2,6,6]  R1458     -4.4820669293403625e-01
    z[2,6,6]  R1459     -2.8691756725311279e-01
    z[2,6,6]  R1460     1.0799196362495422e-01
    z[2,6,6]  R1461     9.8221465945243835e-02
    z[2,6,6]  R1462     1.4508076012134552e-01
    z[2,6,6]  R1463     2.2577278316020966e-01
    z[2,6,6]  R1464     -1.3321690261363983e-02
    z[2,6,6]  R1465     7.3098443448543549e-02
    z[2,6,6]  R1466     -1.0302697867155075e-01
    z[2,6,6]  R1467     7.0774590969085693e-01
    z[2,6,6]  R1468     4.1437754034996033e-01
    z[2,6,6]  R1469     -0.511720597743988
    z[2,6,6]  R1470     9.7146227955818176e-02
    z[2,6,6]  R1471     4.7523382306098938e-01
    z[2,6,6]  R1472     3.0004331469535828e-01
    z[2,6,6]  R1473     3.2768625020980835e-01
    z[2,6,6]  R1474     -9.6416510641574860e-02
    z[2,6,6]  R1475     3.9024993777275085e-01
    z[2,6,6]  R1476     0.500403881072998
    z[2,6,6]  R1477     -0.0842781662940979
    z[2,6,6]  R1478     0.275449275970459
    z[2,6,6]  R1479     -7.7913120388984680e-02
    z[2,6,6]  R1480     -4.7000306844711304e-01
    z[2,6,6]  R1481     -3.4643980860710144e-01
    z[2,6,6]  R1482     -7.0663958787918091e-01
    z[2,6,6]  R1483     6.0131076723337173e-02
    z[2,6,6]  R1484     -2.6651713252067566e-01
    z[2,6,6]  R1485     4.3111163377761841e-01
    z[2,6,6]  R1486     -1.1779459565877914e-01
    z[2,6,6]  R1487     -6.9593206048011780e-02
    z[2,6,6]  R1488     -3.2721498608589172e-01
    z[2,6,6]  R1489     -2.4010214954614639e-02
    z[2,6,6]  R1490     -4.3036383390426636e-01
    z[2,6,6]  R1491     -0.0923534482717514
    z[2,6,6]  R1492     -0.328215092420578
    z[2,6,6]  R1493     -1.4108602702617645e-01
    z[2,6,6]  R1494     6.2837995588779449e-02
    z[2,6,6]  R1495     -2.5084343552589417e-01
    z[2,6,6]  R1496     3.1831854581832886e-01
    z[2,6,6]  R1497     3.2484382390975952e-02
    z[2,6,6]  R1498     -0.148881196975708
    z[2,6,6]  R1499     3.3649137616157532e-01
    z[2,6,6]  R1500     5.4013800621032715e-01
    z[2,6,6]  R1501     -1.8159356713294983e-01
    z[2,6,6]  R1502     1.0902926325798035e-02
    z[2,6,6]  R1503     -4.0447127074003220e-02
    z[2,6,6]  R1504     -1.8995296210050583e-02
    z[2,6,6]  R1505     -1.1160200834274292e-01
    z[2,6,6]  R1506     6.0983393341302872e-02
    z[2,6,6]  R1507     3.1904298067092896e-01
    z[2,6,6]  R1508     2.1662132814526558e-02
    z[2,6,6]  R1509     -1.8995198607444763e-01
    z[2,6,6]  R1510     2.9376775026321411e-01
    z[2,6,6]  R1511     1.3069215416908264e-01
    z[2,6,6]  R1512     -8.4015779197216034e-02
    z[2,6,6]  R1513     -1.5442037582397461e-01
    z[2,6,6]  R1514     -1.0543386638164520e-01
    z[2,6,6]  R1515     -0.0949973315000534
    z[2,6,6]  R1516     4.1611364483833313e-01
    z[2,6,6]  R1517     -1.2132444977760315e-01
    z[2,6,6]  R1518     -0.0995897725224495
    z[2,6,6]  R1519     1.9014886021614075e-01
    z[2,6,6]  R1520     4.7758764028549194e-01
    z[2,6,6]  R1521     -2.7407726645469666e-01
    z[2,6,6]  R1522     -0.755608856678009
    z[2,6,6]  R1523     5.3503835201263428e-01
    z[2,6,6]  R1524     3.5406398773193359e-01
    z[2,6,6]  R1525     -5.6641805917024612e-02
    z[2,6,6]  R1526     -4.0861517190933228e-02
    z[2,6,6]  R1527     4.1237942874431610e-02
    z[2,6,6]  R1528     1.1922285705804825e-01
    z[2,6,6]  R1529     0.0891263335943222
    z[2,6,6]  R1530     9.6925109624862671e-02
    z[2,6,6]  R1531     -3.4527987241744995e-01
    z[2,6,6]  R1532     -2.0519843697547913e-01
    z[2,6,6]  R1533     -0.374266117811203
    z[2,6,6]  R1534     -1.5563745796680450e-01
    z[2,6,6]  R1535     0.543026864528656
    z[2,6,6]  R1536     -3.5846036672592163e-01
    z[2,6,6]  R1537     -4.5592454075813293e-01
    z[2,6,6]  R1538     1.1840562522411346e-01
    z[2,6,6]  R1539     -2.0762926340103149e-01
    z[2,6,6]  R1540     -1.3053172826766968e-01
    z[2,6,6]  R1541     -4.2118576169013977e-01
    z[2,6,6]  R1542     1.2796354480087757e-02
    z[2,6,6]  R1543     -3.1583356857299805e-01
    z[2,6,6]  R1544     -0.184713214635849
    z[6,2,0]  R20       1
    z[6,2,0]  R56       -1
    z[6,2,0]  R1545     -1
    z[6,2,0]  R1546     1
    z[6,2,0]  R1559     -1.1970573104918003e-03
    z[6,2,0]  R1560     3.9835777878761292e-01
    z[6,2,0]  R1561     -3.0083894729614258e-01
    z[6,2,0]  R1562     -3.6715969443321228e-01
    z[6,2,0]  R1563     -4.1392204165458679e-01
    z[6,2,0]  R1564     4.1932117938995361e-01
    z[6,2,0]  R1565     -1.1834224313497543e-01
    z[6,2,0]  R1566     -3.0072543025016785e-01
    z[6,2,0]  R1567     -7.6365791261196136e-02
    z[6,2,0]  R1568     -1.2636126577854156e-01
    z[6,2,0]  R1569     -8.2340574264526367e-01
    z[6,2,0]  R1570     -1.9203135371208191e-01
    z[6,2,0]  R1571     9.6498638391494751e-02
    z[6,2,0]  R1572     -3.2801163196563721e-01
    z[6,2,0]  R1573     -5.0426584482192993e-01
    z[6,2,0]  R1574     3.8767620921134949e-01
    z[6,2,0]  R1575     3.7921980023384094e-01
    z[6,2,0]  R1576     3.0902782082557678e-01
    z[6,2,0]  R1577     2.1062324941158295e-01
    z[6,2,0]  R1578     1.6345719993114471e-01
    z[6,2,0]  R1579     -7.6807297766208649e-02
    z[6,2,0]  R1580     -5.3572410345077515e-01
    z[6,2,0]  R1581     0.298926442861557
    z[6,2,0]  R1582     1.9086718559265137e-01
    z[6,2,0]  R1583     3.7786403298377991e-01
    z[6,2,0]  R1584     -5.9229653328657150e-02
    z[6,2,0]  R1585     0.685613214969635
    z[6,2,0]  R1586     -3.9224180579185486e-01
    z[6,2,0]  R1587     -3.5216581821441650e-01
    z[6,2,0]  R1588     0.797160267829895
    z[6,2,0]  R1589     -4.2389002442359924e-01
    z[6,2,0]  R1590     6.8974149227142334e-01
    z[6,2,0]  R1591     7.9577147960662842e-01
    z[6,2,0]  R1592     -6.8320196866989136e-01
    z[6,2,0]  R1593     7.5881582498550415e-01
    z[6,2,0]  R1594     6.3608884811401367e-01
    z[6,2,0]  R1595     7.3341244459152222e-01
    z[6,2,0]  R1596     -8.1882697343826294e-01
    z[6,2,0]  R1597     3.5091996192932129e-01
    z[6,2,0]  R1598     8.4362350404262543e-02
    z[6,2,0]  R1599     -7.2980821132659912e-01
    z[6,2,0]  R1600     1.9111198186874390e-01
    z[6,2,0]  R1601     -1.4493685960769653e-01
    z[6,2,0]  R1602     -1.6609892249107361e-01
    z[6,2,0]  R1603     -5.5685228109359741e-01
    z[6,2,0]  R1604     0.319084495306015
    z[6,2,0]  R1605     -6.5375095605850220e-01
    z[6,2,0]  R1606     -7.2028857469558716e-01
    z[6,2,0]  R1607     -7.1874296665191650e-01
    z[6,2,0]  R1608     -0.296962708234787
    z[6,2,0]  R1609     -7.2221815586090088e-01
    z[6,2,0]  R1610     -0.374138206243515
    z[6,2,0]  R1611     -7.7556854486465454e-01
    z[6,2,0]  R1612     -7.4139153957366943e-01
    z[6,2,0]  R1613     -3.9027959108352661e-02
    z[6,2,0]  R1614     3.6240735650062561e-01
    z[6,2,0]  R1615     -6.0498553514480591e-01
    z[6,2,0]  R1616     -1.0302574932575226e-01
    z[6,2,0]  R1617     -5.9329774230718613e-02
    z[6,2,0]  R1618     -3.0037942528724670e-01
    z[6,2,0]  R1619     -0.743958592414856
    z[6,2,0]  R1620     -7.8501778841018677e-01
    z[6,2,0]  R1621     -7.5105243921279907e-01
    z[6,2,0]  R1622     -5.6015497446060181e-01
    z[6,2,0]  R1623     -8.9161342382431030e-01
    z[6,2,0]  R1624     -5.9007924795150757e-01
    z[6,2,0]  R1625     -8.1120771169662476e-01
    z[6,2,0]  R1626     -7.1645969152450562e-01
    z[6,2,0]  R1627     -6.8813055753707886e-01
    z[6,2,0]  R1628     -4.4439971446990967e-01
    z[6,2,0]  R1629     -3.7683433294296265e-01
    z[6,2,0]  R1630     -3.2920166850090027e-01
    z[6,2,0]  R1631     -7.2472792863845825e-01
    z[6,2,0]  R1632     4.9414688348770142e-01
    z[6,2,0]  R1633     4.4974252581596375e-01
    z[6,2,0]  R1634     9.6794553101062775e-02
    z[6,2,0]  R1635     -4.8676044680178165e-03
    z[6,2,0]  R1636     -2.4586421251296997e-01
    z[6,2,0]  R1637     1.1634296923875809e-01
    z[6,2,0]  R1638     0.600662350654602
    z[6,2,0]  R1639     2.7329126000404358e-01
    z[6,2,0]  R1640     6.2698286771774292e-01
    z[6,2,0]  R1641     2.1078411489725113e-02
    z[6,2,0]  R1642     2.4044297635555267e-01
    z[6,2,0]  R1643     -3.8858661055564880e-01
    z[6,2,0]  R1644     -4.6192719601094723e-03
    z[6,2,0]  R1645     5.2527695894241333e-01
    z[6,2,0]  R1646     -6.3333630561828613e-01
    z[6,2,0]  R1647     4.8260340094566345e-01
    z[6,2,0]  R1648     -6.0316592454910278e-01
    z[6,2,0]  R1649     3.4032773971557617e-01
    z[6,2,0]  R1650     2.0777510106563568e-01
    z[6,2,0]  R1651     -3.5108034498989582e-03
    z[6,2,0]  R1652     4.8921483755111694e-01
    z[6,2,0]  R1653     -9.1450080275535583e-02
    z[6,2,0]  R1654     2.1135492622852325e-01
    z[6,2,0]  R1655     2.4746231734752655e-01
    z[6,2,0]  R1656     -1.0800433158874512e-01
    z[6,2,0]  R1657     -4.7529187798500061e-01
    z[6,2,0]  R1658     -0.620422899723053
    z[6,2,0]  R1659     -8.1994032859802246e-01
    z[6,2,0]  R1660     2.0614795386791229e-01
    z[6,2,0]  R1661     -7.1798115968704224e-02
    z[6,2,0]  R1662     2.6360219717025757e-01
    z[6,2,0]  R1663     1.6038280725479126e-01
    z[6,2,0]  R1664     6.0919380187988281e-01
    z[6,2,0]  R1665     7.2385388612747192e-01
    z[6,2,1]  R21       1
    z[6,2,1]  R57       -1
    z[6,2,1]  R1547     -1
    z[6,2,1]  R1548     1
    z[6,2,1]  R1559     -2.2033055126667023e-01
    z[6,2,1]  R1560     4.5959314703941345e-01
    z[6,2,1]  R1561     1.1390078812837601e-01
    z[6,2,1]  R1562     2.0924666523933411e-01
    z[6,2,1]  R1563     4.6872356534004211e-01
    z[6,2,1]  R1564     6.3018488883972168e-01
    z[6,2,1]  R1565     8.3565098047256470e-01
    z[6,2,1]  R1566     6.2042653560638428e-01
    z[6,2,1]  R1567     5.0904005765914917e-01
    z[6,2,1]  R1568     -3.0407229065895081e-01
    z[6,2,1]  R1569     9.4793796539306641e-02
    z[6,2,1]  R1570     2.8459683060646057e-01
    z[6,2,1]  R1571     -9.0831464529037476e-01
    z[6,2,1]  R1572     -5.9445196390151978e-01
    z[6,2,1]  R1573     -6.4131164550781250e-01
    z[6,2,1]  R1574     -6.1285120248794556e-01
    z[6,2,1]  R1575     -2.4251176416873932e-01
    z[6,2,1]  R1576     -3.5514634847640991e-01
    z[6,2,1]  R1577     -5.4501199722290039e-01
    z[6,2,1]  R1578     -4.6743515133857727e-01
    z[6,2,1]  R1579     -6.1531532555818558e-02
    z[6,2,1]  R1580     1.4721401967108250e-02
    z[6,2,1]  R1581     -2.9983457922935486e-01
    z[6,2,1]  R1582     -0.711582601070404
    z[6,2,1]  R1583     -1.3799284398555756e-01
    z[6,2,1]  R1584     -2.6491332054138184e-01
    z[6,2,1]  R1585     -3.3857762813568115e-01
    z[6,2,1]  R1586     1.6793204471468925e-02
    z[6,2,1]  R1587     4.1982802748680115e-01
    z[6,2,1]  R1588     -3.0217638611793518e-01
    z[6,2,1]  R1589     3.3735528588294983e-01
    z[6,2,1]  R1590     -2.1396717429161072e-01
    z[6,2,1]  R1591     -1.4922298491001129e-01
    z[6,2,1]  R1592     -4.6211519837379456e-01
    z[6,2,1]  R1593     -2.4508625268936157e-01
    z[6,2,1]  R1594     -1.8263725936412811e-01
    z[6,2,1]  R1595     -2.3488880693912506e-01
    z[6,2,1]  R1596     -1.6358684003353119e-01
    z[6,2,1]  R1597     5.3442692756652832e-01
    z[6,2,1]  R1598     5.0623804330825806e-01
    z[6,2,1]  R1599     4.6645689010620117e-01
    z[6,2,1]  R1600     6.5295898914337158e-01
    z[6,2,1]  R1601     -9.4652932882308960e-01
    z[6,2,1]  R1602     -0.909305214881897
    z[6,2,1]  R1603     6.1326795816421509e-01
    z[6,2,1]  R1604     5.5151903629302979e-01
    z[6,2,1]  R1605     4.0061524510383606e-01
    z[6,2,1]  R1606     -0.264529287815094
    z[6,2,1]  R1607     -1.4760753512382507e-01
    z[6,2,1]  R1608     7.9781192541122437e-01
    z[6,2,1]  R1609     -1.7197097837924957e-01
    z[6,2,1]  R1610     1.4941245317459106e-01
    z[6,2,1]  R1611     4.4548544287681580e-01
    z[6,2,1]  R1612     0.653929591178894
    z[6,2,1]  R1613     4.0577349066734314e-01
    z[6,2,1]  R1614     -3.6976438760757446e-01
    z[6,2,1]  R1615     -6.7304052412509918e-02
    z[6,2,1]  R1616     4.9294161796569824e-01
    z[6,2,1]  R1617     3.5584241151809692e-01
    z[6,2,1]  R1618     3.9754968881607056e-01
    z[6,2,1]  R1619     1.6869686543941498e-02
    z[6,2,1]  R1620     7.1616090834140778e-02
    z[6,2,1]  R1621     2.5303310155868530e-01
    z[6,2,1]  R1622     -1.7502473667263985e-02
    z[6,2,1]  R1623     6.7946580238640308e-03
    z[6,2,1]  R1624     -4.3117246031761169e-01
    z[6,2,1]  R1625     3.8872316479682922e-01
    z[6,2,1]  R1626     -1.3841395080089569e-01
    z[6,2,1]  R1627     -4.6720635145902634e-02
    z[6,2,1]  R1628     5.3251668810844421e-02
    z[6,2,1]  R1629     3.9715209603309631e-01
    z[6,2,1]  R1630     -2.7576866745948792e-01
    z[6,2,1]  R1631     4.9373021721839905e-01
    z[6,2,1]  R1632     -5.0862950086593628e-01
    z[6,2,1]  R1633     -4.7206935286521912e-01
    z[6,2,1]  R1634     -9.2534351348876953e-01
    z[6,2,1]  R1635     -9.3733829259872437e-01
    z[6,2,1]  R1636     5.0692892074584961e-01
    z[6,2,1]  R1637     5.6872403621673584e-01
    z[6,2,1]  R1638     -5.3618443012237549e-01
    z[6,2,1]  R1639     -6.4487606287002563e-01
    z[6,2,1]  R1640     -3.6818471550941467e-01
    z[6,2,1]  R1641     -7.2963792085647583e-01
    z[6,2,1]  R1642     -8.2487720251083374e-01
    z[6,2,1]  R1643     7.6968425512313843e-01
    z[6,2,1]  R1644     -7.7254432439804077e-01
    z[6,2,1]  R1645     -2.3884780704975128e-01
    z[6,2,1]  R1646     3.0962151288986206e-01
    z[6,2,1]  R1647     -5.0188940763473511e-01
    z[6,2,1]  R1648     -9.2821039259433746e-02
    z[6,2,1]  R1649     -2.9327511787414551e-01
    z[6,2,1]  R1650     -0.954384446144104
    z[6,2,1]  R1651     -8.4556078910827637e-01
    z[6,2,1]  R1652     -1.5219414234161377e-01
    z[6,2,1]  R1653     -8.5327720642089844e-01
    z[6,2,1]  R1654     -8.0013388395309448e-01
    z[6,2,1]  R1655     -0.837171733379364
    z[6,2,1]  R1656     5.9243518114089966e-01
    z[6,2,1]  R1657     5.3607380390167236e-01
    z[6,2,1]  R1658     5.0177198648452759e-01
    z[6,2,1]  R1659     -4.3665003776550293e-01
    z[6,2,1]  R1660     -9.2628234624862671e-01
    z[6,2,1]  R1661     -8.7773799896240234e-01
    z[6,2,1]  R1662     9.4409698247909546e-01
    z[6,2,1]  R1663     9.3283069133758545e-01
    z[6,2,1]  R1664     4.4027809053659439e-02
    z[6,2,1]  R1665     -4.1449481248855591e-01
    z[6,2,2]  R22       1
    z[6,2,2]  R58       -1
    z[6,2,2]  R1549     -1
    z[6,2,2]  R1550     1
    z[6,2,2]  R1559     -1.5700127184391022e-01
    z[6,2,2]  R1560     4.0909403562545776e-01
    z[6,2,2]  R1561     -6.0636216402053833e-01
    z[6,2,2]  R1562     -4.0500751137733459e-01
    z[6,2,2]  R1563     1.3352312147617340e-02
    z[6,2,2]  R1564     -7.7508250251412392e-03
    z[6,2,2]  R1565     -5.8390375226736069e-02
    z[6,2,2]  R1566     3.7913840264081955e-02
    z[6,2,2]  R1567     2.6878255605697632e-01
    z[6,2,2]  R1568     2.1994440257549286e-01
    z[6,2,2]  R1569     5.1407706737518311e-01
    z[6,2,2]  R1570     -0.190054789185524
    z[6,2,2]  R1571     8.1887438893318176e-02
    z[6,2,2]  R1572     1.0052428394556046e-01
    z[6,2,2]  R1573     -2.0116455852985382e-01
    z[6,2,2]  R1574     5.0907045602798462e-01
    z[6,2,2]  R1575     6.6290384531021118e-01
    z[6,2,2]  R1576     4.4923242926597595e-01
    z[6,2,2]  R1577     4.0708842873573303e-01
    z[6,2,2]  R1578     5.3370285034179688e-01
    z[6,2,2]  R1579     -4.0093046426773071e-01
    z[6,2,2]  R1580     -2.1145179867744446e-01
    z[6,2,2]  R1581     -8.2104299217462540e-03
    z[6,2,2]  R1582     3.5090631246566772e-01
    z[6,2,2]  R1583     4.9911147356033325e-01
    z[6,2,2]  R1584     2.3015265166759491e-01
    z[6,2,2]  R1585     -5.2543884515762329e-01
    z[6,2,2]  R1586     5.3428955376148224e-02
    z[6,2,2]  R1587     4.7465705871582031e-01
    z[6,2,2]  R1588     3.6648120731115341e-02
    z[6,2,2]  R1589     0.377734899520874
    z[6,2,2]  R1590     6.5484158694744110e-02
    z[6,2,2]  R1591     -1.2441141903400421e-01
    z[6,2,2]  R1592     2.5291427969932556e-01
    z[6,2,2]  R1593     -2.6075729727745056e-01
    z[6,2,2]  R1594     -2.3586069047451019e-01
    z[6,2,2]  R1595     2.9757454991340637e-01
    z[6,2,2]  R1596     1.2146435678005219e-01
    z[6,2,2]  R1597     -4.2763182520866394e-01
    z[6,2,2]  R1598     0.0552813895046711
    z[6,2,2]  R1599     -3.2051667571067810e-01
    z[6,2,2]  R1600     -5.6332081556320190e-01
    z[6,2,2]  R1601     4.8455204814672470e-02
    z[6,2,2]  R1602     2.8371301293373108e-01
    z[6,2,2]  R1603     -2.1615797281265259e-01
    z[6,2,2]  R1604     -3.4118276834487915e-01
    z[6,2,2]  R1605     -4.3730372190475464e-01
    z[6,2,2]  R1606     4.1211673617362976e-01
    z[6,2,2]  R1607     4.9223366379737854e-01
    z[6,2,2]  R1608     -1.7958946526050568e-02
    z[6,2,2]  R1609     4.7048786282539368e-01
    z[6,2,2]  R1610     -3.8058489561080933e-01
    z[6,2,2]  R1611     -3.2974272966384888e-01
    z[6,2,2]  R1612     5.8110468089580536e-02
    z[6,2,2]  R1613     -1.9358810782432556e-01
    z[6,2,2]  R1614     -6.7814439535140991e-01
    z[6,2,2]  R1615     -0.0276302732527256
    z[6,2,2]  R1616     -1.1719395220279694e-01
    z[6,2,2]  R1617     -9.6887126564979553e-02
    z[6,2,2]  R1618     3.9203721284866333e-01
    z[6,2,2]  R1619     -9.0094834566116333e-02
    z[6,2,2]  R1620     4.0363538265228271e-01
    z[6,2,2]  R1621     2.3727929592132568e-01
    z[6,2,2]  R1622     3.7829467654228210e-01
    z[6,2,2]  R1623     2.0727132260799408e-01
    z[6,2,2]  R1624     -3.5161191225051880e-01
    z[6,2,2]  R1625     -1.8203815817832947e-01
    z[6,2,2]  R1626     5.9477311372756958e-01
    z[6,2,2]  R1627     3.3852979540824890e-01
    z[6,2,2]  R1628     0.564498245716095
    z[6,2,2]  R1629     -3.1396320462226868e-01
    z[6,2,2]  R1630     1.2137076258659363e-01
    z[6,2,2]  R1631     -3.5435834527015686e-01
    z[6,2,2]  R1632     -0.539020299911499
    z[6,2,2]  R1633     -2.3951514065265656e-01
    z[6,2,2]  R1634     1.6637371480464935e-01
    z[6,2,2]  R1635     -6.2574379146099091e-02
    z[6,2,2]  R1636     1.5445311367511749e-01
    z[6,2,2]  R1637     -3.8655731081962585e-01
    z[6,2,2]  R1638     -2.5803402066230774e-01
    z[6,2,2]  R1639     -5.0074491649866104e-02
    z[6,2,2]  R1640     -1.7812184989452362e-01
    z[6,2,2]  R1641     6.3637781143188477e-01
    z[6,2,2]  R1642     4.4004756212234497e-01
    z[6,2,2]  R1643     -3.7844008207321167e-01
    z[6,2,2]  R1644     4.7437658905982971e-01
    z[6,2,2]  R1645     -1.9614732265472412e-01
    z[6,2,2]  R1646     2.9345509409904480e-01
    z[6,2,2]  R1647     1.8945498391985893e-02
    z[6,2,2]  R1648     -2.8382557630538940e-01
    z[6,2,2]  R1649     -7.5607880949974060e-02
    z[6,2,2]  R1650     4.0291804820299149e-02
    z[6,2,2]  R1651     -3.9303341507911682e-01
    z[6,2,2]  R1652     2.5031521916389465e-01
    z[6,2,2]  R1653     3.0954939126968384e-01
    z[6,2,2]  R1654     2.4709241092205048e-01
    z[6,2,2]  R1655     -1.3379940390586853e-01
    z[6,2,2]  R1656     0.374731183052063
    z[6,2,2]  R1657     -2.3399564623832703e-01
    z[6,2,2]  R1658     -1.5763019025325775e-01
    z[6,2,2]  R1659     -2.4272593855857849e-01
    z[6,2,2]  R1660     1.6245366632938385e-01
    z[6,2,2]  R1661     -2.3109002411365509e-01
    z[6,2,2]  R1662     5.0432592630386353e-02
    z[6,2,2]  R1663     1.3996334373950958e-01
    z[6,2,2]  R1664     0.632743239402771
    z[6,2,2]  R1665     -1.8757671117782593e-01
    z[6,2,3]  R23       1
    z[6,2,3]  R59       -1
    z[6,2,3]  R1551     -1
    z[6,2,3]  R1552     1
    z[6,2,3]  R1559     1.8152070045471191e-01
    z[6,2,3]  R1560     3.0024429783225060e-02
    z[6,2,3]  R1561     -6.7329630255699158e-02
    z[6,2,3]  R1562     1.4320933818817139e-01
    z[6,2,3]  R1563     -5.0282761454582214e-02
    z[6,2,3]  R1564     5.4868827573955059e-03
    z[6,2,3]  R1565     -7.1596577763557434e-02
    z[6,2,3]  R1566     6.7600446939468384e-01
    z[6,2,3]  R1567     0.30000039935112
    z[6,2,3]  R1568     0.794006884098053
    z[6,2,3]  R1569     1.1935956031084061e-01
    z[6,2,3]  R1570     -6.9941782951354980e-01
    z[6,2,3]  R1571     0.301226943731308
    z[6,2,3]  R1572     3.8864842057228088e-01
    z[6,2,3]  R1573     2.3955328762531281e-01
    z[6,2,3]  R1574     2.5290060043334961e-01
    z[6,2,3]  R1575     7.8742668032646179e-02
    z[6,2,3]  R1576     4.4505367986857891e-03
    z[6,2,3]  R1577     -4.0808707475662231e-02
    z[6,2,3]  R1578     3.4651394933462143e-02
    z[6,2,3]  R1579     -4.1442832350730896e-01
    z[6,2,3]  R1580     -4.0571314096450806e-01
    z[6,2,3]  R1581     -7.3294615745544434e-01
    z[6,2,3]  R1582     2.0180614292621613e-01
    z[6,2,3]  R1583     -3.9547482132911682e-01
    z[6,2,3]  R1584     -3.7801361083984375e-01
    z[6,2,3]  R1585     -9.5134507864713669e-03
    z[6,2,3]  R1586     -5.7658666372299194e-01
    z[6,2,3]  R1587     -4.8413532972335815e-01
    z[6,2,3]  R1588     5.0298297405242920e-01
    z[6,2,3]  R1589     -3.8413512706756592e-01
    z[6,2,3]  R1590     6.3380491733551025e-01
    z[6,2,3]  R1591     4.7572395205497742e-01
    z[6,2,3]  R1592     -4.7816762328147888e-01
    z[6,2,3]  R1593     4.1079682111740112e-01
    z[6,2,3]  R1594     6.8301928043365479e-01
    z[6,2,3]  R1595     4.1419026255607605e-01
    z[6,2,3]  R1596     5.2072703838348389e-01
    z[6,2,3]  R1597     -4.7158092260360718e-01
    z[6,2,3]  R1598     -4.2060464620590210e-01
    z[6,2,3]  R1599     -2.1827220916748047e-02
    z[6,2,3]  R1600     -4.3719586730003357e-01
    z[6,2,3]  R1601     2.4062652885913849e-01
    z[6,2,3]  R1602     1.5694554895162582e-02
    z[6,2,3]  R1603     4.5493260025978088e-01
    z[6,2,3]  R1604     -5.2448230981826782e-01
    z[6,2,3]  R1605     1.5438485145568848e-01
    z[6,2,3]  R1606     -9.3475859612226486e-03
    z[6,2,3]  R1607     -7.0925705134868622e-02
    z[6,2,3]  R1608     -3.5661661624908447e-01
    z[6,2,3]  R1609     3.1329268217086792e-01
    z[6,2,3]  R1610     -7.3681735992431641e-01
    z[6,2,3]  R1611     1.6105762124061584e-01
    z[6,2,3]  R1612     2.0723575726151466e-03
    z[6,2,3]  R1613     -8.0785721540451050e-01
    z[6,2,3]  R1614     2.6825010776519775e-01
    z[6,2,3]  R1615     1.4808334410190582e-01
    z[6,2,3]  R1616     -5.6925994157791138e-01
    z[6,2,3]  R1617     -7.7147370576858521e-01
    z[6,2,3]  R1618     -5.1840478181838989e-01
    z[6,2,3]  R1619     -3.9839029312133789e-01
    z[6,2,3]  R1620     -1.6759096086025238e-01
    z[6,2,3]  R1621     2.2435568273067474e-01
    z[6,2,3]  R1622     -5.7995975017547607e-01
    z[6,2,3]  R1623     -5.5508546531200409e-02
    z[6,2,3]  R1624     -0.162618488073349
    z[6,2,3]  R1625     -1.8966302275657654e-01
    z[6,2,3]  R1626     -1.6043733060359955e-01
    z[6,2,3]  R1627     -3.4989330917596817e-02
    z[6,2,3]  R1628     -4.5814856886863708e-01
    z[6,2,3]  R1629     -4.3502718210220337e-01
    z[6,2,3]  R1630     -4.5113736391067505e-01
    z[6,2,3]  R1631     -1.7009107768535614e-01
    z[6,2,3]  R1632     2.9478520154953003e-01
    z[6,2,3]  R1633     1.8935614824295044e-01
    z[6,2,3]  R1634     2.7815201878547668e-01
    z[6,2,3]  R1635     1.7314006388187408e-01
    z[6,2,3]  R1636     -7.3491680622100830e-01
    z[6,2,3]  R1637     -5.5577796697616577e-01
    z[6,2,3]  R1638     1.8954205513000488e-01
    z[6,2,3]  R1639     4.7849395871162415e-01
    z[6,2,3]  R1640     6.3952714204788208e-02
    z[6,2,3]  R1641     -1.4681740105152130e-01
    z[6,2,3]  R1642     0.00597138237208128
    z[6,2,3]  R1643     2.1508035063743591e-01
    z[6,2,3]  R1644     1.8963800370693207e-01
    z[6,2,3]  R1645     6.0778830200433731e-02
    z[6,2,3]  R1646     -0.0553843230009079
    z[6,2,3]  R1647     0.38902547955513
    z[6,2,3]  R1648     2.6066571474075317e-01
    z[6,2,3]  R1649     3.7355315685272217e-01
    z[6,2,3]  R1650     -8.0543659627437592e-02
    z[6,2,3]  R1651     2.9656881093978882e-01
    z[6,2,3]  R1652     2.5672686100006104e-01
    z[6,2,3]  R1653     -2.0979759097099304e-01
    z[6,2,3]  R1654     7.3786050081253052e-02
    z[6,2,3]  R1655     2.5442928075790405e-01
    z[6,2,3]  R1656     -0.555517852306366
    z[6,2,3]  R1657     -3.0220049619674683e-01
    z[6,2,3]  R1658     -4.7199490666389465e-01
    z[6,2,3]  R1659     -1.3955840468406677e-01
    z[6,2,3]  R1660     -7.2610370814800262e-02
    z[6,2,3]  R1661     -3.0861049890518188e-01
    z[6,2,3]  R1662     9.9657423794269562e-02
    z[6,2,3]  R1663     1.7827060818672180e-01
    z[6,2,3]  R1664     -0.0658518373966217
    z[6,2,3]  R1665     -2.5762474536895752e-01
    z[6,2,4]  R24       1
    z[6,2,4]  R60       -1
    z[6,2,4]  R1553     -1
    z[6,2,4]  R1554     1
    z[6,2,4]  R1559     9.3230515718460083e-01
    z[6,2,4]  R1560     6.4843553304672241e-01
    z[6,2,4]  R1561     1.8940374255180359e-01
    z[6,2,4]  R1562     6.5703099966049194e-01
    z[6,2,4]  R1563     1.8320725858211517e-01
    z[6,2,4]  R1564     0.368007093667984
    z[6,2,4]  R1565     -3.9148527383804321e-01
    z[6,2,4]  R1566     -0.251006543636322
    z[6,2,4]  R1567     -3.4782004356384277e-01
    z[6,2,4]  R1568     -2.3502174019813538e-01
    z[6,2,4]  R1569     -1.3876289129257202e-01
    z[6,2,4]  R1570     -2.9398933053016663e-01
    z[6,2,4]  R1571     -2.4249014258384705e-01
    z[6,2,4]  R1572     -5.0091665983200073e-01
    z[6,2,4]  R1573     -4.2328283190727234e-01
    z[6,2,4]  R1574     6.4704000949859619e-02
    z[6,2,4]  R1575     -5.7221513986587524e-01
    z[6,2,4]  R1576     -5.2367347478866577e-01
    z[6,2,4]  R1577     -1.4771215617656708e-01
    z[6,2,4]  R1578     -3.8605967164039612e-01
    z[6,2,4]  R1579     4.0591907501220703e-01
    z[6,2,4]  R1580     -5.4308164119720459e-01
    z[6,2,4]  R1581     0.496865838766098
    z[6,2,4]  R1582     3.9167352952063084e-03
    z[6,2,4]  R1583     -5.3028100728988647e-01
    z[6,2,4]  R1584     -4.0601128339767456e-01
    z[6,2,4]  R1585     -2.8760954737663269e-01
    z[6,2,4]  R1586     0.585985004901886
    z[6,2,4]  R1587     4.5392480492591858e-01
    z[6,2,4]  R1588     -4.9370858818292618e-02
    z[6,2,4]  R1589     2.9065108299255371e-01
    z[6,2,4]  R1590     0.0555245578289032
    z[6,2,4]  R1591     -8.8652148842811584e-02
    z[6,2,4]  R1592     1.3986818492412567e-01
    z[6,2,4]  R1593     1.1174959689378738e-01
    z[6,2,4]  R1594     -8.8005885481834412e-02
    z[6,2,4]  R1595     0.0831865444779396
    z[6,2,4]  R1596     -8.0534592270851135e-03
    z[6,2,4]  R1597     2.4362045526504517e-01
    z[6,2,4]  R1598     2.3618039488792419e-01
    z[6,2,4]  R1599     -3.3481118083000183e-01
    z[6,2,4]  R1600     1.1404404789209366e-01
    z[6,2,4]  R1601     -1.1398802697658539e-01
    z[6,2,4]  R1602     -8.5143849253654480e-02
    z[6,2,4]  R1603     -1.4496196806430817e-01
    z[6,2,4]  R1604     -2.6472138240933418e-02
    z[6,2,4]  R1605     3.2402139902114868e-01
    z[6,2,4]  R1606     1.8986824154853821e-01
    z[6,2,4]  R1607     -3.4458765387535095e-01
    z[6,2,4]  R1608     -1.5601888298988342e-01
    z[6,2,4]  R1609     -3.3036106824874878e-01
    z[6,2,4]  R1610     7.9754993319511414e-02
    z[6,2,4]  R1611     2.2440824657678604e-02
    z[6,2,4]  R1612     -5.4176026023924351e-03
    z[6,2,4]  R1613     -8.7099701166152954e-02
    z[6,2,4]  R1614     -3.8170254230499268e-01
    z[6,2,4]  R1615     2.8691646456718445e-01
    z[6,2,4]  R1616     0.372158020734787
    z[6,2,4]  R1617     4.3288782238960266e-02
    z[6,2,4]  R1618     -1.2515020370483398e-01
    z[6,2,4]  R1619     9.4737574458122253e-02
    z[6,2,4]  R1620     -1.8336981534957886e-01
    z[6,2,4]  R1621     3.9586311578750610e-01
    z[6,2,4]  R1622     -2.0542104542255402e-01
    z[6,2,4]  R1623     -3.3603996038436890e-02
    z[6,2,4]  R1624     2.5538778305053711e-01
    z[6,2,4]  R1625     -3.2243865728378296e-01
    z[6,2,4]  R1626     1.0967319458723068e-01
    z[6,2,4]  R1627     2.0001262426376343e-01
    z[6,2,4]  R1628     -2.1655750274658203e-01
    z[6,2,4]  R1629     4.7490587830543518e-01
    z[6,2,4]  R1630     -1.1311549693346024e-01
    z[6,2,4]  R1631     0.269917756319046
    z[6,2,4]  R1632     -6.3240818679332733e-02
    z[6,2,4]  R1633     -4.9538484215736389e-01
    z[6,2,4]  R1634     1.2240315973758698e-01
    z[6,2,4]  R1635     1.0413980484008789e-01
    z[6,2,4]  R1636     8.3759091794490814e-02
    z[6,2,4]  R1637     -5.6565467268228531e-02
    z[6,2,4]  R1638     -1.3234561309218407e-02
    z[6,2,4]  R1639     -5.1011848449707031e-01
    z[6,2,4]  R1640     -5.7242041826248169e-01
    z[6,2,4]  R1641     0.0806722566485405
    z[6,2,4]  R1642     2.3295298218727112e-01
    z[6,2,4]  R1643     6.3670896925032139e-03
    z[6,2,4]  R1644     1.4857368171215057e-01
    z[6,2,4]  R1645     -7.8706592321395874e-01
    z[6,2,4]  R1646     5.9010720252990723e-01
    z[6,2,4]  R1647     -4.9014893174171448e-01
    z[6,2,4]  R1648     3.4605216979980469e-01
    z[6,2,4]  R1649     -0.784143328666687
    z[6,2,4]  R1650     1.6048873960971832e-01
    z[6,2,4]  R1651     -1.6336247324943542e-01
    z[6,2,4]  R1652     -7.4287265539169312e-01
    z[6,2,4]  R1653     2.8813734650611877e-01
    z[6,2,4]  R1654     3.4640464186668396e-01
    z[6,2,4]  R1655     2.3118773102760315e-01
    z[6,2,4]  R1656     2.5349294766783714e-02
    z[6,2,4]  R1657     5.0959908962249756e-01
    z[6,2,4]  R1658     5.9191279113292694e-02
    z[6,2,4]  R1659     -1.9709999859333038e-01
    z[6,2,4]  R1660     2.4052542448043823e-01
    z[6,2,4]  R1661     -9.3885980546474457e-02
    z[6,2,4]  R1662     2.2049862891435623e-02
    z[6,2,4]  R1663     1.2017721310257912e-02
    z[6,2,4]  R1664     -1.8670603632926941e-01
    z[6,2,4]  R1665     4.3236309289932251e-01
    z[6,2,5]  R25       1
    z[6,2,5]  R61       -1
    z[6,2,5]  R1555     -1
    z[6,2,5]  R1556     1
    z[6,2,5]  R1559     -1.2142031639814377e-01
    z[6,2,5]  R1560     -7.2115555405616760e-02
    z[6,2,5]  R1561     5.1024538278579712e-01
    z[6,2,5]  R1562     3.6064037680625916e-01
    z[6,2,5]  R1563     -4.1838459670543671e-02
    z[6,2,5]  R1564     -7.2465568780899048e-02
    z[6,2,5]  R1565     -2.2915486246347427e-02
    z[6,2,5]  R1566     -1.7315704608336091e-03
    z[6,2,5]  R1567     6.7093491554260254e-01
    z[6,2,5]  R1568     3.9473345875740051e-01
    z[6,2,5]  R1569     3.2030217349529266e-02
    z[6,2,5]  R1570     -0.512298047542572
    z[6,2,5]  R1571     -3.6583945620805025e-03
    z[6,2,5]  R1572     -8.8016480207443237e-02
    z[6,2,5]  R1573     -1.2372436374425888e-01
    z[6,2,5]  R1574     8.2141578197479248e-02
    z[6,2,5]  R1575     9.2413406819105148e-03
    z[6,2,5]  R1576     8.6203746497631073e-02
    z[6,2,5]  R1577     0.583867073059082
    z[6,2,5]  R1578     3.3442100882530212e-01
    z[6,2,5]  R1579     -6.9211864471435547e-01
    z[6,2,5]  R1580     -4.0671899914741516e-01
    z[6,2,5]  R1581     1.3982349634170532e-01
    z[6,2,5]  R1582     -3.4050858020782471e-01
    z[6,2,5]  R1583     3.8897618651390076e-01
    z[6,2,5]  R1584     6.8253362178802490e-01
    z[6,2,5]  R1585     1.4928117394447327e-01
    z[6,2,5]  R1586     4.0886640548706055e-01
    z[6,2,5]  R1587     1.1239586770534515e-01
    z[6,2,5]  R1588     -1.2824654579162598e-01
    z[6,2,5]  R1589     4.8890876770019531e-01
    z[6,2,5]  R1590     2.4667195975780487e-01
    z[6,2,5]  R1591     3.0765545368194580e-01
    z[6,2,5]  R1592     -1.6746150329709053e-02
    z[6,2,5]  R1593     -0.0683315098285675
    z[6,2,5]  R1594     1.2376486510038376e-01
    z[6,2,5]  R1595     3.5071703791618347e-01
    z[6,2,5]  R1596     -1.2956143915653229e-01
    z[6,2,5]  R1597     -3.2415542006492615e-01
    z[6,2,5]  R1598     -5.3670185804367065e-01
    z[6,2,5]  R1599     1.8109139800071716e-01
    z[6,2,5]  R1600     -9.8403267562389374e-02
    z[6,2,5]  R1601     -2.3633357137441635e-02
    z[6,2,5]  R1602     8.2218162715435028e-02
    z[6,2,5]  R1603     6.8722128868103027e-02
    z[6,2,5]  R1604     -1.4278912544250488e-01
    z[6,2,5]  R1605     -9.1430328786373138e-02
    z[6,2,5]  R1606     -6.5892316401004791e-02
    z[6,2,5]  R1607     1.1503832787275314e-01
    z[6,2,5]  R1608     -3.3437585830688477e-01
    z[6,2,5]  R1609     1.0261550545692444e-01
    z[6,2,5]  R1610     -3.5006096959114075e-01
    z[6,2,5]  R1611     -1.1785305291414261e-01
    z[6,2,5]  R1612     -1.3829918205738068e-01
    z[6,2,5]  R1613     -3.6164256930351257e-01
    z[6,2,5]  R1614     -2.0925061404705048e-01
    z[6,2,5]  R1615     1.5344475209712982e-01
    z[6,2,5]  R1616     -3.1367599964141846e-01
    z[6,2,5]  R1617     -3.9566081017255783e-02
    z[6,2,5]  R1618     -5.5153405666351318e-01
    z[6,2,5]  R1619     -2.1115562319755554e-01
    z[6,2,5]  R1620     -2.5290203094482422e-01
    z[6,2,5]  R1621     -3.4231055527925491e-02
    z[6,2,5]  R1622     -3.9365702867507935e-01
    z[6,2,5]  R1623     7.4246935546398163e-02
    z[6,2,5]  R1624     1.3931236229836941e-02
    z[6,2,5]  R1625     1.0323248058557510e-01
    z[6,2,5]  R1626     1.1458898894488811e-02
    z[6,2,5]  R1627     6.0198950767517090e-01
    z[6,2,5]  R1628     -5.7573366910219193e-02
    z[6,2,5]  R1629     -2.5862815976142883e-01
    z[6,2,5]  R1630     2.9186886548995972e-01
    z[6,2,5]  R1631     0.00526859937235713
    z[6,2,5]  R1632     2.1128852665424347e-01
    z[6,2,5]  R1633     -2.2448942065238953e-01
    z[6,2,5]  R1634     -2.1524254232645035e-02
    z[6,2,5]  R1635     2.6794016361236572e-01
    z[6,2,5]  R1636     -6.7306622862815857e-02
    z[6,2,5]  R1637     -4.4824701547622681e-01
    z[6,2,5]  R1638     2.5261655449867249e-01
    z[6,2,5]  R1639     9.6087656915187836e-02
    z[6,2,5]  R1640     1.1172868311405182e-02
    z[6,2,5]  R1641     -1.1932700127363205e-01
    z[6,2,5]  R1642     -9.9355757236480713e-02
    z[6,2,5]  R1643     0.0643991008400917
    z[6,2,5]  R1644     -1.3695776462554932e-01
    z[6,2,5]  R1645     6.5878160297870636e-02
    z[6,2,5]  R1646     2.0843271911144257e-01
    z[6,2,5]  R1647     1.0014345496892929e-01
    z[6,2,5]  R1648     2.5994306802749634e-01
    z[6,2,5]  R1649     -7.1071274578571320e-02
    z[6,2,5]  R1650     -1.0951571911573410e-01
    z[6,2,5]  R1651     1.1942744255065918e-01
    z[6,2,5]  R1652     2.3815682530403137e-01
    z[6,2,5]  R1653     1.6805014014244080e-01
    z[6,2,5]  R1654     3.5341310501098633e-01
    z[6,2,5]  R1655     -5.7587809860706329e-03
    z[6,2,5]  R1656     -4.3268963694572449e-01
    z[6,2,5]  R1657     -2.1182611584663391e-01
    z[6,2,5]  R1658     -1.6084384918212891e-01
    z[6,2,5]  R1659     -5.2090730518102646e-02
    z[6,2,5]  R1660     5.4125446826219559e-02
    z[6,2,5]  R1661     -2.0764803886413574e-01
    z[6,2,5]  R1662     1.2295242398977280e-01
    z[6,2,5]  R1663     2.0872300863265991e-01
    z[6,2,5]  R1664     1.1930776387453079e-01
    z[6,2,5]  R1665     -3.1884968280792236e-02
    z[6,2,6]  R26       1
    z[6,2,6]  R62       -1
    z[6,2,6]  R1557     -1
    z[6,2,6]  R1558     1
    z[6,2,6]  R1559     -0.0995897725224495
    z[6,2,6]  R1560     1.9014886021614075e-01
    z[6,2,6]  R1561     4.7758764028549194e-01
    z[6,2,6]  R1562     -2.7407726645469666e-01
    z[6,2,6]  R1563     -0.755608856678009
    z[6,2,6]  R1564     5.3503835201263428e-01
    z[6,2,6]  R1565     3.5406398773193359e-01
    z[6,2,6]  R1566     -5.6641805917024612e-02
    z[6,2,6]  R1567     -4.0861517190933228e-02
    z[6,2,6]  R1568     4.1237942874431610e-02
    z[6,2,6]  R1569     1.1922285705804825e-01
    z[6,2,6]  R1570     0.0891263335943222
    z[6,2,6]  R1571     9.6925109624862671e-02
    z[6,2,6]  R1572     -3.4527987241744995e-01
    z[6,2,6]  R1573     -2.0519843697547913e-01
    z[6,2,6]  R1574     -0.374266117811203
    z[6,2,6]  R1575     -1.5563745796680450e-01
    z[6,2,6]  R1576     0.543026864528656
    z[6,2,6]  R1577     -3.5846036672592163e-01
    z[6,2,6]  R1578     -4.5592454075813293e-01
    z[6,2,6]  R1579     1.1840562522411346e-01
    z[6,2,6]  R1580     -2.0762926340103149e-01
    z[6,2,6]  R1581     -1.3053172826766968e-01
    z[6,2,6]  R1582     -4.2118576169013977e-01
    z[6,2,6]  R1583     1.2796354480087757e-02
    z[6,2,6]  R1584     -3.1583356857299805e-01
    z[6,2,6]  R1585     -0.184713214635849
    z[6,2,6]  R1586     -2.7494572568684816e-03
    z[6,2,6]  R1587     1.4613977074623108e-01
    z[6,2,6]  R1588     -2.2966891992837191e-03
    z[6,2,6]  R1589     -3.0455753207206726e-01
    z[6,2,6]  R1590     -9.2454567551612854e-02
    z[6,2,6]  R1591     -1.3331221416592598e-02
    z[6,2,6]  R1592     0.0850360244512558
    z[6,2,6]  R1593     3.3200240135192871e-01
    z[6,2,6]  R1594     1.2971581518650055e-01
    z[6,2,6]  R1595     -1.3002598285675049e-01
    z[6,2,6]  R1596     6.4658035989850760e-04
    z[6,2,6]  R1597     1.4682596921920776e-01
    z[6,2,6]  R1598     4.6131512522697449e-01
    z[6,2,6]  R1599     -4.1206661611795425e-02
    z[6,2,6]  R1600     -7.7206864953041077e-02
    z[6,2,6]  R1601     9.6304953098297119e-02
    z[6,2,6]  R1602     -2.2544731199741364e-01
    z[6,2,6]  R1603     -1.8545429408550262e-01
    z[6,2,6]  R1604     -4.2595180869102478e-01
    z[6,2,6]  R1605     -2.8930693864822388e-01
    z[6,2,6]  R1606     -4.4820669293403625e-01
    z[6,2,6]  R1607     -2.8691756725311279e-01
    z[6,2,6]  R1608     1.0799196362495422e-01
    z[6,2,6]  R1609     9.8221465945243835e-02
    z[6,2,6]  R1610     1.4508076012134552e-01
    z[6,2,6]  R1611     2.2577278316020966e-01
    z[6,2,6]  R1612     -1.3321690261363983e-02
    z[6,2,6]  R1613     7.3098443448543549e-02
    z[6,2,6]  R1614     -1.0302697867155075e-01
    z[6,2,6]  R1615     7.0774590969085693e-01
    z[6,2,6]  R1616     4.1437754034996033e-01
    z[6,2,6]  R1617     -0.511720597743988
    z[6,2,6]  R1618     9.7146227955818176e-02
    z[6,2,6]  R1619     4.7523382306098938e-01
    z[6,2,6]  R1620     3.0004331469535828e-01
    z[6,2,6]  R1621     3.2768625020980835e-01
    z[6,2,6]  R1622     -9.6416510641574860e-02
    z[6,2,6]  R1623     3.9024993777275085e-01
    z[6,2,6]  R1624     0.500403881072998
    z[6,2,6]  R1625     -0.0842781662940979
    z[6,2,6]  R1626     0.275449275970459
    z[6,2,6]  R1627     -7.7913120388984680e-02
    z[6,2,6]  R1628     -4.7000306844711304e-01
    z[6,2,6]  R1629     -3.4643980860710144e-01
    z[6,2,6]  R1630     -7.0663958787918091e-01
    z[6,2,6]  R1631     6.0131076723337173e-02
    z[6,2,6]  R1632     -2.6651713252067566e-01
    z[6,2,6]  R1633     4.3111163377761841e-01
    z[6,2,6]  R1634     -1.1779459565877914e-01
    z[6,2,6]  R1635     -6.9593206048011780e-02
    z[6,2,6]  R1636     -3.2721498608589172e-01
    z[6,2,6]  R1637     -2.4010214954614639e-02
    z[6,2,6]  R1638     -4.3036383390426636e-01
    z[6,2,6]  R1639     -0.0923534482717514
    z[6,2,6]  R1640     -0.328215092420578
    z[6,2,6]  R1641     -1.4108602702617645e-01
    z[6,2,6]  R1642     6.2837995588779449e-02
    z[6,2,6]  R1643     -2.5084343552589417e-01
    z[6,2,6]  R1644     3.1831854581832886e-01
    z[6,2,6]  R1645     3.2484382390975952e-02
    z[6,2,6]  R1646     -0.148881196975708
    z[6,2,6]  R1647     3.3649137616157532e-01
    z[6,2,6]  R1648     5.4013800621032715e-01
    z[6,2,6]  R1649     -1.8159356713294983e-01
    z[6,2,6]  R1650     1.0902926325798035e-02
    z[6,2,6]  R1651     -4.0447127074003220e-02
    z[6,2,6]  R1652     -1.8995296210050583e-02
    z[6,2,6]  R1653     -1.1160200834274292e-01
    z[6,2,6]  R1654     6.0983393341302872e-02
    z[6,2,6]  R1655     3.1904298067092896e-01
    z[6,2,6]  R1656     2.1662132814526558e-02
    z[6,2,6]  R1657     -1.8995198607444763e-01
    z[6,2,6]  R1658     2.9376775026321411e-01
    z[6,2,6]  R1659     1.3069215416908264e-01
    z[6,2,6]  R1660     -8.4015779197216034e-02
    z[6,2,6]  R1661     -1.5442037582397461e-01
    z[6,2,6]  R1662     -1.0543386638164520e-01
    z[6,2,6]  R1663     -0.0949973315000534
    z[6,2,6]  R1664     4.1611364483833313e-01
    z[6,2,6]  R1665     -1.2132444977760315e-01
    z[3,5,0]  R29       -1
    z[3,5,0]  R47       1
    z[3,5,0]  R1666     -1
    z[3,5,0]  R1667     1
    z[3,5,0]  R1680     1.2302646785974503e-01
    z[3,5,0]  R1681     3.9639464020729065e-01
    z[3,5,0]  R1682     -4.4419410824775696e-01
    z[3,5,0]  R1683     -3.4195578098297119e-01
    z[3,5,0]  R1684     -4.2483130097389221e-01
    z[3,5,0]  R1685     -4.7725465893745422e-01
    z[3,5,0]  R1686     -1.1169387027621269e-02
    z[3,5,0]  R1687     2.6945248246192932e-01
    z[3,5,0]  R1688     1.1034189164638519e-01
    z[3,5,0]  R1689     -1.4272119104862213e-01
    z[3,5,0]  R1690     -6.6784307360649109e-02
    z[3,5,0]  R1691     4.2604845762252808e-01
    z[3,5,0]  R1692     3.7830349802970886e-01
    z[3,5,0]  R1693     4.3023020029067993e-01
    z[3,5,0]  R1694     4.3663305044174194e-01
    z[3,5,0]  R1695     -3.4835276007652283e-01
    z[3,5,0]  R1696     -3.6363103985786438e-01
    z[3,5,0]  R1697     7.8226590156555176e-01
    z[3,5,0]  R1698     6.4075648784637451e-01
    z[3,5,0]  R1699     6.8611931800842285e-01
    z[3,5,0]  R1700     -1.6029927134513855e-01
    z[3,5,0]  R1701     4.0806140750646591e-02
    z[3,5,0]  R1702     -2.8304606676101685e-01
    z[3,5,0]  R1703     -5.8769184350967407e-01
    z[3,5,0]  R1704     6.7144066095352173e-01
    z[3,5,0]  R1705     0.865686297416687
    z[3,5,0]  R1706     6.8237137794494629e-01
    z[3,5,0]  R1707     8.3832150697708130e-01
    z[3,5,0]  R1708     8.1652325391769409e-01
    z[3,5,0]  R1709     6.7006939649581909e-01
    z[3,5,0]  R1710     7.5943458080291748e-01
    z[3,5,0]  R1711     8.6767166852951050e-01
    z[3,5,0]  R1712     7.3249679803848267e-01
    z[3,5,0]  R1713     6.8604403734207153e-01
    z[3,5,0]  R1714     -4.4286161661148071e-01
    z[3,5,0]  R1715     -5.4820311069488525e-01
    z[3,5,0]  R1716     8.8026702404022217e-01
    z[3,5,0]  R1717     6.8000304698944092e-01
    z[3,5,0]  R1718     1.1706885695457458e-01
    z[3,5,0]  R1719     6.7970955371856689e-01
    z[3,5,0]  R1720     -7.2851979732513428e-01
    z[3,5,0]  R1721     -5.3250616788864136e-01
    z[3,5,0]  R1722     -4.5595401525497437e-01
    z[3,5,0]  R1723     -4.3952351808547974e-01
    z[3,5,0]  R1724     -4.3826425075531006e-01
    z[3,5,0]  R1725     -4.2607232928276062e-01
    z[3,5,0]  R1726     -4.5474034547805786e-01
    z[3,5,0]  R1727     -0.492642879486084
    z[3,5,0]  R1728     -3.5169291496276855e-01
    z[3,5,0]  R1729     -4.2849314212799072e-01
    z[3,5,0]  R1730     -1.8124037981033325e-01
    z[3,5,0]  R1731     1.0111644119024277e-01
    z[3,5,0]  R1732     -1.4891627430915833e-01
    z[3,5,0]  R1733     -3.5820782184600830e-01
    z[3,5,0]  R1734     1.6601191833615303e-02
    z[3,5,0]  R1735     -9.0139172971248627e-02
    z[3,5,0]  R1736     9.9790267646312714e-02
    z[3,5,0]  R1737     -5.5877542495727539e-01
    z[3,5,0]  R1738     -6.8435692787170410e-01
    z[3,5,0]  R1739     0.591355562210083
    z[3,5,0]  R1740     -0.634787917137146
    z[3,5,0]  R1741     -4.2726138234138489e-01
    z[3,5,0]  R1742     1.2502075731754303e-01
    z[3,5,0]  R1743     3.1266176700592041e-01
    z[3,5,0]  R1744     3.5332730412483215e-01
    z[3,5,0]  R1745     -8.6019468307495117e-01
    z[3,5,0]  R1746     -0.551559567451477
    z[3,5,0]  R1747     0.562705397605896
    z[3,5,0]  R1748     5.3335338830947876e-01
    z[3,5,0]  R1749     5.8284366130828857e-01
    z[3,5,0]  R1750     -1.4608344435691833e-01
    z[3,5,0]  R1751     4.0938743948936462e-01
    z[3,5,0]  R1752     1.8510198593139648e-01
    z[3,5,0]  R1753     2.6271072030067444e-01
    z[3,5,0]  R1754     5.9153407812118530e-01
    z[3,5,0]  R1755     2.2646707296371460e-01
    z[3,5,0]  R1756     5.1118308305740356e-01
    z[3,5,0]  R1757     -8.3527660369873047e-01
    z[3,5,0]  R1758     -4.7554358839988708e-01
    z[3,5,0]  R1759     -5.4265040159225464e-01
    z[3,5,0]  R1760     4.9199834465980530e-01
    z[3,5,0]  R1761     6.2315154075622559e-01
    z[3,5,0]  R1762     -5.2788324654102325e-02
    z[3,5,0]  R1763     4.3013170361518860e-01
    z[3,5,0]  R1764     0.500211238861084
    z[3,5,0]  R1765     -4.3523499369621277e-01
    z[3,5,0]  R1766     -5.9402501583099365e-01
    z[3,5,0]  R1767     -0.832075297832489
    z[3,5,0]  R1768     -5.5556356906890869e-01
    z[3,5,0]  R1769     -8.5553938150405884e-01
    z[3,5,0]  R1770     -7.5360065698623657e-01
    z[3,5,0]  R1771     7.5770670175552368e-01
    z[3,5,0]  R1772     1.5656508505344391e-01
    z[3,5,0]  R1773     -2.8213843703269958e-01
    z[3,5,0]  R1774     -2.8486687690019608e-02
    z[3,5,0]  R1775     4.7304117679595947e-01
    z[3,5,0]  R1776     -8.5314494371414185e-01
    z[3,5,0]  R1777     -6.6401398181915283e-01
    z[3,5,0]  R1778     -9.0782427787780762e-01
    z[3,5,0]  R1779     -6.1012154817581177e-01
    z[3,5,0]  R1780     5.7783633470535278e-01
    z[3,5,0]  R1781     4.4784688949584961e-01
    z[3,5,0]  R1782     -4.8408564925193787e-01
    z[3,5,0]  R1783     -0.672747015953064
    z[3,5,0]  R1784     -4.9150905013084412e-01
    z[3,5,0]  R1785     5.8502227067947388e-01
    z[3,5,0]  R1786     6.6070383787155151e-01
    z[3,5,0]  R1787     6.8326950073242188e-01
    z[3,5,0]  R1788     6.8778365850448608e-01
    z[3,5,0]  R1789     6.7371368408203125e-01
    z[3,5,0]  R1790     -8.9634925127029419e-01
    z[3,5,0]  R1791     5.8706700801849365e-01
    z[3,5,0]  R1792     6.3879698514938354e-01
    z[3,5,0]  R1793     6.2776446342468262e-01
    z[3,5,0]  R1794     4.9042728543281555e-01
    z[3,5,0]  R1795     -4.4271769002079964e-03
    z[3,5,0]  R1796     3.7055447697639465e-02
    z[3,5,0]  R1797     5.4906487464904785e-01
    z[3,5,0]  R1798     5.7185983657836914e-01
    z[3,5,0]  R1799     2.9208138585090637e-01
    z[3,5,1]  R30       -1
    z[3,5,1]  R48       1
    z[3,5,1]  R1668     -1
    z[3,5,1]  R1669     1
    z[3,5,1]  R1680     3.5636723041534424e-01
    z[3,5,1]  R1681     1.4859323203563690e-01
    z[3,5,1]  R1682     4.9766483902931213e-01
    z[3,5,1]  R1683     -2.0866273343563080e-01
    z[3,5,1]  R1684     0.191564679145813
    z[3,5,1]  R1685     1.2885032594203949e-01
    z[3,5,1]  R1686     -1.8866440653800964e-01
    z[3,5,1]  R1687     -2.2225941717624664e-01
    z[3,5,1]  R1688     -2.5352746248245239e-01
    z[3,5,1]  R1689     -1.8692450225353241e-01
    z[3,5,1]  R1690     -9.0078812837600708e-01
    z[3,5,1]  R1691     -6.3910853862762451e-01
    z[3,5,1]  R1692     -8.7422186136245728e-01
    z[3,5,1]  R1693     -8.1641918420791626e-01
    z[3,5,1]  R1694     2.1426524221897125e-01
    z[3,5,1]  R1695     4.7654518485069275e-01
    z[3,5,1]  R1696     3.5593998432159424e-01
    z[3,5,1]  R1697     -1.8441970646381378e-01
    z[3,5,1]  R1698     -2.9422175884246826e-01
    z[3,5,1]  R1699     -1.8421749770641327e-01
    z[3,5,1]  R1700     0.215898334980011
    z[3,5,1]  R1701     7.7527087926864624e-01
    z[3,5,1]  R1702     6.9777315855026245e-01
    z[3,5,1]  R1703     -2.1259206533432007e-01
    z[3,5,1]  R1704     -2.4626728892326355e-01
    z[3,5,1]  R1705     -1.0118196159601212e-01
    z[3,5,1]  R1706     -1.8070322275161743e-01
    z[3,5,1]  R1707     -7.5816445052623749e-02
    z[3,5,1]  R1708     -1.8228402733802795e-01
    z[3,5,1]  R1709     -5.8117534965276718e-02
    z[3,5,1]  R1710     5.1057547330856323e-01
    z[3,5,1]  R1711     3.1768313050270081e-01
    z[3,5,1]  R1712     4.8648440837860107e-01
    z[3,5,1]  R1713     4.7185283899307251e-01
    z[3,5,1]  R1714     4.4452327489852905e-01
    z[3,5,1]  R1715     -4.0931418538093567e-02
    z[3,5,1]  R1716     3.4900563955307007e-01
    z[3,5,1]  R1717     4.5200872421264648e-01
    z[3,5,1]  R1718     6.1654180288314819e-01
    z[3,5,1]  R1719     3.8457027077674866e-01
    z[3,5,1]  R1720     2.4004091322422028e-01
    z[3,5,1]  R1721     -4.3289753794670105e-01
    z[3,5,1]  R1722     -0.192816823720932
    z[3,5,1]  R1723     -2.1364213526248932e-01
    z[3,5,1]  R1724     -2.2704876959323883e-01
    z[3,5,1]  R1725     -2.5199401378631592e-01
    z[3,5,1]  R1726     -2.0157837867736816e-01
    z[3,5,1]  R1727     -1.9670151174068451e-01
    z[3,5,1]  R1728     -2.3894466459751129e-01
    z[3,5,1]  R1729     -2.3336625099182129e-01
    z[3,5,1]  R1730     3.4802475571632385e-01
    z[3,5,1]  R1731     7.8177338838577271e-01
    z[3,5,1]  R1732     2.4236483871936798e-01
    z[3,5,1]  R1733     1.7813818156719208e-01
    z[3,5,1]  R1734     8.5366815328598022e-01
    z[3,5,1]  R1735     6.6496598720550537e-01
    z[3,5,1]  R1736     3.4388515353202820e-01
    z[3,5,1]  R1737     -3.1246135011315346e-02
    z[3,5,1]  R1738     -1.8710640072822571e-01
    z[3,5,1]  R1739     -7.2522288560867310e-01
    z[3,5,1]  R1740     5.2543687820434570e-01
    z[3,5,1]  R1741     5.8598470687866211e-01
    z[3,5,1]  R1742     0.849338948726654
    z[3,5,1]  R1743     7.1854478120803833e-01
    z[3,5,1]  R1744     4.8190990090370178e-01
    z[3,5,1]  R1745     -1.8543800711631775e-01
    z[3,5,1]  R1746     -3.7781310081481934e-01
    z[3,5,1]  R1747     -5.2031236886978149e-01
    z[3,5,1]  R1748     -6.2621653079986572e-01
    z[3,5,1]  R1749     1.9602222368121147e-02
    z[3,5,1]  R1750     7.7178794145584106e-01
    z[3,5,1]  R1751     7.8734922409057617e-01
    z[3,5,1]  R1752     6.1397576332092285e-01
    z[3,5,1]  R1753     8.8871586322784424e-01
    z[3,5,1]  R1754     0.267733097076416
    z[3,5,1]  R1755     3.3866789937019348e-01
    z[3,5,1]  R1756     5.2049368619918823e-01
    z[3,5,1]  R1757     -1.1216162145137787e-01
    z[3,5,1]  R1758     3.0052950978279114e-01
    z[3,5,1]  R1759     -3.2113844156265259e-01
    z[3,5,1]  R1760     4.7029018402099609e-01
    z[3,5,1]  R1761     3.7659695744514465e-01
    z[3,5,1]  R1762     0.0677233412861824
    z[3,5,1]  R1763     1.5144044160842896e-01
    z[3,5,1]  R1764     5.7834458351135254e-01
    z[3,5,1]  R1765     5.1786535978317261e-01
    z[3,5,1]  R1766     -2.8375563025474548e-01
    z[3,5,1]  R1767     -3.4214520454406738e-01
    z[3,5,1]  R1768     -3.3144152164459229e-01
    z[3,5,1]  R1769     -0.0317201092839241
    z[3,5,1]  R1770     1.1143982410430908e-01
    z[3,5,1]  R1771     4.7424244880676270e-01
    z[3,5,1]  R1772     8.5829752683639526e-01
    z[3,5,1]  R1773     3.1502538919448853e-01
    z[3,5,1]  R1774     4.6628189086914062e-01
    z[3,5,1]  R1775     5.6245517730712891e-01
    z[3,5,1]  R1776     -2.7969694137573242e-01
    z[3,5,1]  R1777     -4.1869038343429565e-01
    z[3,5,1]  R1778     -2.2984184324741364e-01
    z[3,5,1]  R1779     -3.1074598431587219e-02
    z[3,5,1]  R1780     7.8660178184509277e-01
    z[3,5,1]  R1781     6.3052386045455933e-01
    z[3,5,1]  R1782     1.7272271215915680e-01
    z[3,5,1]  R1783     -3.2018333673477173e-01
    z[3,5,1]  R1784     -2.6289907097816467e-01
    z[3,5,1]  R1785     -3.7370449304580688e-01
    z[3,5,1]  R1786     -5.1204943656921387e-01
    z[3,5,1]  R1787     -3.6264434456825256e-01
    z[3,5,1]  R1788     -5.7322126626968384e-01
    z[3,5,1]  R1789     -4.6222689747810364e-01
    z[3,5,1]  R1790     -9.9885143339633942e-02
    z[3,5,1]  R1791     -4.1757720708847046e-01
    z[3,5,1]  R1792     -5.2153486013412476e-01
    z[3,5,1]  R1793     -5.8511340618133545e-01
    z[3,5,1]  R1794     -6.2838965654373169e-01
    z[3,5,1]  R1795     -7.2098881006240845e-01
    z[3,5,1]  R1796     -8.9664030075073242e-01
    z[3,5,1]  R1797     -5.7314264774322510e-01
    z[3,5,1]  R1798     -4.7685539722442627e-01
    z[3,5,1]  R1799     -5.5895823240280151e-01
    z[3,5,2]  R31       -1
    z[3,5,2]  R49       1
    z[3,5,2]  R1670     -1
    z[3,5,2]  R1671     1
    z[3,5,2]  R1680     2.5317168235778809e-01
    z[3,5,2]  R1681     4.4305637478828430e-01
    z[3,5,2]  R1682     -2.3154832422733307e-01
    z[3,5,2]  R1683     -4.9875292181968689e-01
    z[3,5,2]  R1684     -4.9246424436569214e-01
    z[3,5,2]  R1685     -0.179381862282753
    z[3,5,2]  R1686     0.50576251745224
    z[3,5,2]  R1687     4.9431779980659485e-01
    z[3,5,2]  R1688     5.8363676071166992e-01
    z[3,5,2]  R1689     3.7546235322952271e-01
    z[3,5,2]  R1690     -5.5164024233818054e-02
    z[3,5,2]  R1691     4.6470394730567932e-01
    z[3,5,2]  R1692     6.0612101107835770e-02
    z[3,5,2]  R1693     1.7800678312778473e-01
    z[3,5,2]  R1694     -2.4674880504608154e-01
    z[3,5,2]  R1695     1.0945523530244827e-01
    z[3,5,2]  R1696     2.0087005198001862e-01
    z[3,5,2]  R1697     -4.0304175019264221e-01
    z[3,5,2]  R1698     -4.7503703832626343e-01
    z[3,5,2]  R1699     -2.3438222706317902e-01
    z[3,5,2]  R1700     -4.0537121891975403e-01
    z[3,5,2]  R1701     -2.3900006711483002e-01
    z[3,5,2]  R1702     3.1247567385435104e-02
    z[3,5,2]  R1703     5.2226681262254715e-02
    z[3,5,2]  R1704     -3.5896146297454834e-01
    z[3,5,2]  R1705     -1.0460843890905380e-01
    z[3,5,2]  R1706     -3.1134307384490967e-01
    z[3,5,2]  R1707     -1.2013496458530426e-01
    z[3,5,2]  R1708     -2.0758289098739624e-01
    z[3,5,2]  R1709     -2.4450413882732391e-01
    z[3,5,2]  R1710     0.225607231259346
    z[3,5,2]  R1711     3.1976962089538574e-01
    z[3,5,2]  R1712     2.1875400841236115e-01
    z[3,5,2]  R1713     4.4502955675125122e-01
    z[3,5,2]  R1714     -4.7080716490745544e-01
    z[3,5,2]  R1715     -4.1226577758789062e-01
    z[3,5,2]  R1716     1.5544793009757996e-01
    z[3,5,2]  R1717     3.5547360777854919e-01
    z[3,5,2]  R1718     -3.2983991503715515e-01
    z[3,5,2]  R1719     4.8570439219474792e-01
    z[3,5,2]  R1720     2.3494124412536621e-01
    z[3,5,2]  R1721     6.5841847658157349e-01
    z[3,5,2]  R1722     8.0758494138717651e-01
    z[3,5,2]  R1723     6.8192929029464722e-01
    z[3,5,2]  R1724     6.5245223045349121e-01
    z[3,5,2]  R1725     6.6472548246383667e-01
    z[3,5,2]  R1726     0.639353334903717
    z[3,5,2]  R1727     6.3165879249572754e-01
    z[3,5,2]  R1728     7.7503788471221924e-01
    z[3,5,2]  R1729     5.7745563983917236e-01
    z[3,5,2]  R1730     2.3937088251113892e-01
    z[3,5,2]  R1731     2.8595605492591858e-01
    z[3,5,2]  R1732     -4.6420689672231674e-02
    z[3,5,2]  R1733     -2.5077894330024719e-01
    z[3,5,2]  R1734     1.2380032241344452e-01
    z[3,5,2]  R1735     -3.7403452396392822e-01
    z[3,5,2]  R1736     -7.1206778287887573e-01
    z[3,5,2]  R1737     -4.7657048702239990e-01
    z[3,5,2]  R1738     -2.1853515505790710e-01
    z[3,5,2]  R1739     -5.7819854468107224e-02
    z[3,5,2]  R1740     -4.0094745159149170e-01
    z[3,5,2]  R1741     -6.7131072282791138e-01
    z[3,5,2]  R1742     -4.1002368927001953e-01
    z[3,5,2]  R1743     -2.6114150881767273e-01
    z[3,5,2]  R1744     4.2280846834182739e-01
    z[3,5,2]  R1745     -2.4369031190872192e-01
    z[3,5,2]  R1746     0.328095406293869
    z[3,5,2]  R1747     3.8787674903869629e-01
    z[3,5,2]  R1748     2.9203245043754578e-01
    z[3,5,2]  R1749     -2.7586886286735535e-01
    z[3,5,2]  R1750     -2.2261705994606018e-01
    z[3,5,2]  R1751     3.4349447488784790e-01
    z[3,5,2]  R1752     -1.4417226612567902e-01
    z[3,5,2]  R1753     -1.2380160391330719e-01
    z[3,5,2]  R1754     -0.395833283662796
    z[3,5,2]  R1755     2.3510010540485382e-01
    z[3,5,2]  R1756     -2.0400816202163696e-01
    z[3,5,2]  R1757     -9.6323236823081970e-02
    z[3,5,2]  R1758     3.9766165614128113e-01
    z[3,5,2]  R1759     2.9063206911087036e-01
    z[3,5,2]  R1760     6.3487243652343750e-01
    z[3,5,2]  R1761     3.7208899855613708e-01
    z[3,5,2]  R1762     1.3445743918418884e-01
    z[3,5,2]  R1763     -4.3952378630638123e-01
    z[3,5,2]  R1764     -2.9135462641716003e-01
    z[3,5,2]  R1765     0.0922401174902916
    z[3,5,2]  R1766     4.4079285860061646e-01
    z[3,5,2]  R1767     -3.1065413355827332e-01
    z[3,5,2]  R1768     0.355376273393631
    z[3,5,2]  R1769     1.2634010612964630e-01
    z[3,5,2]  R1770     -4.2379835247993469e-01
    z[3,5,2]  R1771     3.0889004468917847e-01
    z[3,5,2]  R1772     -3.6990982294082642e-01
    z[3,5,2]  R1773     3.5622832179069519e-01
    z[3,5,2]  R1774     -4.7861674427986145e-01
    z[3,5,2]  R1775     -1.3612095499411225e-03
    z[3,5,2]  R1776     -1.4447963237762451e-01
    z[3,5,2]  R1777     2.8854611515998840e-01
    z[3,5,2]  R1778     2.1654902398586273e-01
    z[3,5,2]  R1779     6.2843970954418182e-02
    z[3,5,2]  R1780     -1.7592564225196838e-01
    z[3,5,2]  R1781     2.0112448930740356e-01
    z[3,5,2]  R1782     3.3232292532920837e-01
    z[3,5,2]  R1783     4.4547894597053528e-01
    z[3,5,2]  R1784     3.8438367843627930e-01
    z[3,5,2]  R1785     5.4896640777587891e-01
    z[3,5,2]  R1786     5.2453732490539551e-01
    z[3,5,2]  R1787     2.7125416323542595e-02
    z[3,5,2]  R1788     1.1758831888437271e-01
    z[3,5,2]  R1789     -1.3787375390529633e-01
    z[3,5,2]  R1790     -1.0769053548574448e-01
    z[3,5,2]  R1791     5.5269473791122437e-01
    z[3,5,2]  R1792     1.5828667581081390e-01
    z[3,5,2]  R1793     3.8291251659393311e-01
    z[3,5,2]  R1794     5.5537527799606323e-01
    z[3,5,2]  R1795     0.521673321723938
    z[3,5,2]  R1796     3.5263195633888245e-01
    z[3,5,2]  R1797     5.3273621946573257e-02
    z[3,5,2]  R1798     2.5538769364356995e-01
    z[3,5,2]  R1799     -2.4770677089691162e-01
    z[3,5,3]  R32       -1
    z[3,5,3]  R50       1
    z[3,5,3]  R1672     -1
    z[3,5,3]  R1673     1
    z[3,5,3]  R1680     4.7430381178855896e-02
    z[3,5,3]  R1681     2.8876092284917831e-02
    z[3,5,3]  R1682     5.0100311636924744e-02
    z[3,5,3]  R1683     -2.7720436453819275e-01
    z[3,5,3]  R1684     -4.6595868468284607e-01
    z[3,5,3]  R1685     -5.5398764088749886e-03
    z[3,5,3]  R1686     4.4093075394630432e-01
    z[3,5,3]  R1687     2.7040678262710571e-01
    z[3,5,3]  R1688     7.3127579689025879e-01
    z[3,5,3]  R1689     4.1562882065773010e-01
    z[3,5,3]  R1690     1.2848268449306488e-01
    z[3,5,3]  R1691     2.1257027983665466e-01
    z[3,5,3]  R1692     -1.9541363418102264e-01
    z[3,5,3]  R1693     -1.9743348658084869e-01
    z[3,5,3]  R1694     -5.4969519376754761e-01
    z[3,5,3]  R1695     6.3999301195144653e-01
    z[3,5,3]  R1696     6.6140717267990112e-01
    z[3,5,3]  R1697     3.5298663377761841e-01
    z[3,5,3]  R1698     4.4309777021408081e-01
    z[3,5,3]  R1699     4.6353161334991455e-01
    z[3,5,3]  R1700     -3.0771313235163689e-02
    z[3,5,3]  R1701     -2.6654061675071716e-01
    z[3,5,3]  R1702     2.0046578347682953e-01
    z[3,5,3]  R1703     4.1446754336357117e-01
    z[3,5,3]  R1704     5.8468794822692871e-01
    z[3,5,3]  R1705     3.7966915965080261e-01
    z[3,5,3]  R1706     5.9524923563003540e-01
    z[3,5,3]  R1707     4.0818822383880615e-01
    z[3,5,3]  R1708     3.3546721935272217e-01
    z[3,5,3]  R1709     6.5078121423721313e-01
    z[3,5,3]  R1710     2.8614804148674011e-01
    z[3,5,3]  R1711     1.9862221181392670e-01
    z[3,5,3]  R1712     9.6923463046550751e-02
    z[3,5,3]  R1713     1.0683256387710571e-01
    z[3,5,3]  R1714     -3.4418621659278870e-01
    z[3,5,3]  R1715     -3.7811005115509033e-01
    z[3,5,3]  R1716     7.2333104908466339e-02
    z[3,5,3]  R1717     -1.9786326587200165e-01
    z[3,5,3]  R1718     -1.4166752994060516e-01
    z[3,5,3]  R1719     -8.8863588869571686e-02
    z[3,5,3]  R1720     -1.4615970849990845e-01
    z[3,5,3]  R1721     2.3510551452636719e-01
    z[3,5,3]  R1722     8.4521457552909851e-02
    z[3,5,3]  R1723     4.4326889514923096e-01
    z[3,5,3]  R1724     3.0297595262527466e-01
    z[3,5,3]  R1725     -6.4370416104793549e-02
    z[3,5,3]  R1726     2.6252093911170959e-01
    z[3,5,3]  R1727     2.3608949780464172e-01
    z[3,5,3]  R1728     -0.383390337228775
    z[3,5,3]  R1729     4.6426522731781006e-01
    z[3,5,3]  R1730     -5.3112649917602539e-01
    z[3,5,3]  R1731     -1.9288714230060577e-01
    z[3,5,3]  R1732     -2.5173398852348328e-01
    z[3,5,3]  R1733     -1.6380971670150757e-01
    z[3,5,3]  R1734     -9.9699504673480988e-02
    z[3,5,3]  R1735     1.8503373861312866e-01
    z[3,5,3]  R1736     5.2364283800125122e-01
    z[3,5,3]  R1737     5.2530074119567871e-01
    z[3,5,3]  R1738     1.2904337048530579e-01
    z[3,5,3]  R1739     -1.1997362226247787e-01
    z[3,5,3]  R1740     -2.3272280395030975e-01
    z[3,5,3]  R1741     4.1645620018243790e-02
    z[3,5,3]  R1742     2.0353603363037109e-01
    z[3,5,3]  R1743     1.6257666051387787e-01
    z[3,5,3]  R1744     -4.2788782715797424e-01
    z[3,5,3]  R1745     1.0887966305017471e-01
    z[3,5,3]  R1746     -2.7930095791816711e-01
    z[3,5,3]  R1747     -1.5871591866016388e-01
    z[3,5,3]  R1748     -0.0847240760922432
    z[3,5,3]  R1749     2.6343245059251785e-02
    z[3,5,3]  R1750     -2.5393217802047729e-01
    z[3,5,3]  R1751     -2.6008498668670654e-01
    z[3,5,3]  R1752     -2.3698411881923676e-01
    z[3,5,3]  R1753     -1.5202210843563080e-01
    z[3,5,3]  R1754     -5.7442313432693481e-01
    z[3,5,3]  R1755     -6.6975212097167969e-01
    z[3,5,3]  R1756     4.0605121850967407e-01
    z[3,5,3]  R1757     1.2707798182964325e-01
    z[3,5,3]  R1758     -5.3396087884902954e-01
    z[3,5,3]  R1759     -8.2362376153469086e-02
    z[3,5,3]  R1760     -4.7547496855258942e-02
    z[3,5,3]  R1761     0.0390746146440506
    z[3,5,3]  R1762     -7.0815253257751465e-01
    z[3,5,3]  R1763     -1.5038779377937317e-01
    z[3,5,3]  R1764     3.5058364272117615e-01
    z[3,5,3]  R1765     -1.2800544500350952e-01
    z[3,5,3]  R1766     1.1343742907047272e-01
    z[3,5,3]  R1767     1.1935079097747803e-01
    z[3,5,3]  R1768     2.7844834327697754e-01
    z[3,5,3]  R1769     3.0967876315116882e-01
    z[3,5,3]  R1770     -8.1400223076343536e-02
    z[3,5,3]  R1771     2.4099707603454590e-02
    z[3,5,3]  R1772     -5.8336075395345688e-02
    z[3,5,3]  R1773     -5.3081786632537842e-01
    z[3,5,3]  R1774     -3.9032605290412903e-01
    z[3,5,3]  R1775     -3.8091403245925903e-01
    z[3,5,3]  R1776     -1.1232873797416687e-01
    z[3,5,3]  R1777     2.5902670621871948e-01
    z[3,5,3]  R1778     -5.9855529107153416e-03
    z[3,5,3]  R1779     -2.2981157898902893e-01
    z[3,5,3]  R1780     0.0851278305053711
    z[3,5,3]  R1781     -4.1740727424621582e-01
    z[3,5,3]  R1782     -5.7617175579071045e-01
    z[3,5,3]  R1783     -4.9353456497192383e-01
    z[3,5,3]  R1784     1.1958824843168259e-01
    z[3,5,3]  R1785     -2.5140696763992310e-01
    z[3,5,3]  R1786     4.2824551463127136e-02
    z[3,5,3]  R1787     -3.0461966991424561e-02
    z[3,5,3]  R1788     0.380967378616333
    z[3,5,3]  R1789     1.2610933184623718e-01
    z[3,5,3]  R1790     6.9487184286117554e-02
    z[3,5,3]  R1791     -2.3484340310096741e-01
    z[3,5,3]  R1792     -4.0507983416318893e-02
    z[3,5,3]  R1793     2.1431854367256165e-01
    z[3,5,3]  R1794     -8.1822186708450317e-02
    z[3,5,3]  R1795     -2.6592493057250977e-01
    z[3,5,3]  R1796     -7.9549968242645264e-02
    z[3,5,3]  R1797     4.8030912876129150e-01
    z[3,5,3]  R1798     2.9239574074745178e-01
    z[3,5,3]  R1799     5.8321475982666016e-01
    z[3,5,4]  R33       -1
    z[3,5,4]  R51       1
    z[3,5,4]  R1674     -1
    z[3,5,4]  R1675     1
    z[3,5,4]  R1680     0.85572350025177
    z[3,5,4]  R1681     5.5156075954437256e-01
    z[3,5,4]  R1682     -5.2889782190322876e-01
    z[3,5,4]  R1683     2.3898379504680634e-01
    z[3,5,4]  R1684     0.0794677734375
    z[3,5,4]  R1685     4.9426129460334778e-01
    z[3,5,4]  R1686     -7.3871716856956482e-02
    z[3,5,4]  R1687     3.4427908062934875e-01
    z[3,5,4]  R1688     -1.7902587354183197e-01
    z[3,5,4]  R1689     -3.1540572643280029e-01
    z[3,5,4]  R1690     -2.4714456498622894e-01
    z[3,5,4]  R1691     -3.8467753678560257e-02
    z[3,5,4]  R1692     -3.4658830612897873e-02
    z[3,5,4]  R1693     -2.4372906982898712e-01
    z[3,5,4]  R1694     8.9103868231177330e-03
    z[3,5,4]  R1695     3.9257079362869263e-01
    z[3,5,4]  R1696     -2.1384319290518761e-02
    z[3,5,4]  R1697     6.7004904150962830e-02
    z[3,5,4]  R1698     2.2348852455615997e-01
    z[3,5,4]  R1699     3.6299028992652893e-01
    z[3,5,4]  R1700     5.3707206249237061e-01
    z[3,5,4]  R1701     2.9634320735931396e-01
    z[3,5,4]  R1702     1.3828288018703461e-01
    z[3,5,4]  R1703     -3.4940603375434875e-01
    z[3,5,4]  R1704     -6.5426945686340332e-02
    z[3,5,4]  R1705     -1.6886492073535919e-01
    z[3,5,4]  R1706     2.1630893647670746e-01
    z[3,5,4]  R1707     3.2086926698684692e-01
    z[3,5,4]  R1708     9.5850922167301178e-02
    z[3,5,4]  R1709     5.9840731322765350e-02
    z[3,5,4]  R1710     -8.9635804295539856e-02
    z[3,5,4]  R1711     5.9240357950329781e-03
    z[3,5,4]  R1712     1.6294494271278381e-01
    z[3,5,4]  R1713     2.9447984695434570e-01
    z[3,5,4]  R1714     4.7585102915763855e-01
    z[3,5,4]  R1715     6.0992515087127686e-01
    z[3,5,4]  R1716     5.3177025169134140e-02
    z[3,5,4]  R1717     2.7024206519126892e-01
    z[3,5,4]  R1718     1.8455411493778229e-01
    z[3,5,4]  R1719     2.6636752486228943e-01
    z[3,5,4]  R1720     -0.532170832157135
    z[3,5,4]  R1721     -1.8462254106998444e-01
    z[3,5,4]  R1722     -2.2556984424591064e-01
    z[3,5,4]  R1723     2.7346667647361755e-01
    z[3,5,4]  R1724     1.0784591734409332e-01
    z[3,5,4]  R1725     2.4785001575946808e-01
    z[3,5,4]  R1726     2.0645757019519806e-01
    z[3,5,4]  R1727     3.7460610270500183e-01
    z[3,5,4]  R1728     0.00777652719989419
    z[3,5,4]  R1729     1.9684703648090363e-01
    z[3,5,4]  R1730     8.7425507605075836e-02
    z[3,5,4]  R1731     -3.7611982226371765e-01
    z[3,5,4]  R1732     8.4554873406887054e-02
    z[3,5,4]  R1733     4.4912289828062057e-02
    z[3,5,4]  R1734     -2.7962690591812134e-01
    z[3,5,4]  R1735     -1.9024184346199036e-01
    z[3,5,4]  R1736     -1.2297239154577255e-01
    z[3,5,4]  R1737     -1.7264726758003235e-01
    z[3,5,4]  R1738     -2.0380100607872009e-01
    z[3,5,4]  R1739     -1.6615694761276245e-01
    z[3,5,4]  R1740     4.9837347120046616e-02
    z[3,5,4]  R1741     1.0925633460283279e-01
    z[3,5,4]  R1742     -1.6090567409992218e-01
    z[3,5,4]  R1743     -2.3118624463677406e-02
    z[3,5,4]  R1744     1.8447768688201904e-01
    z[3,5,4]  R1745     -1.7895893752574921e-01
    z[3,5,4]  R1746     1.9566673040390015e-01
    z[3,5,4]  R1747     2.8256335854530334e-01
    z[3,5,4]  R1748     3.9508658647537231e-01
    z[3,5,4]  R1749     5.8149969577789307e-01
    z[3,5,4]  R1750     -1.5922186430543661e-03
    z[3,5,4]  R1751     -1.3166756927967072e-01
    z[3,5,4]  R1752     3.4759557247161865e-01
    z[3,5,4]  R1753     1.0526530444622040e-02
    z[3,5,4]  R1754     -1.4662112109363079e-02
    z[3,5,4]  R1755     5.3493720293045044e-01
    z[3,5,4]  R1756     -3.1676670908927917e-01
    z[3,5,4]  R1757     -3.7845450639724731e-01
    z[3,5,4]  R1758     -1.3518825289793313e-04
    z[3,5,4]  R1759     -3.3785271644592285e-01
    z[3,5,4]  R1760     -3.0541995167732239e-01
    z[3,5,4]  R1761     -1.8798868358135223e-01
    z[3,5,4]  R1762     6.7701435089111328e-01
    z[3,5,4]  R1763     6.3727504014968872e-01
    z[3,5,4]  R1764     -2.4129703640937805e-01
    z[3,5,4]  R1765     -2.4397027492523193e-01
    z[3,5,4]  R1766     2.3534847795963287e-01
    z[3,5,4]  R1767     -1.3661400973796844e-01
    z[3,5,4]  R1768     5.0487709045410156e-01
    z[3,5,4]  R1769     -5.3828172385692596e-02
    z[3,5,4]  R1770     1.3678911328315735e-01
    z[3,5,4]  R1771     -1.1057466268539429e-01
    z[3,5,4]  R1772     1.4980529248714447e-01
    z[3,5,4]  R1773     1.3441678881645203e-01
    z[3,5,4]  R1774     -5.0711023807525635e-01
    z[3,5,4]  R1775     3.5708293318748474e-01
    z[3,5,4]  R1776     6.6397930495440960e-03
    z[3,5,4]  R1777     3.1206998229026794e-01
    z[3,5,4]  R1778     1.1286263167858124e-01
    z[3,5,4]  R1779     5.7297468185424805e-02
    z[3,5,4]  R1780     -1.1313164606690407e-02
    z[3,5,4]  R1781     2.0030789077281952e-01
    z[3,5,4]  R1782     0.0537506528198719
    z[3,5,4]  R1783     9.6015287563204765e-03
    z[3,5,4]  R1784     -2.5005133822560310e-02
    z[3,5,4]  R1785     2.5555279850959778e-01
    z[3,5,4]  R1786     8.7121017277240753e-03
    z[3,5,4]  R1787     4.8978802561759949e-01
    z[3,5,4]  R1788     1.1990191414952278e-02
    z[3,5,4]  R1789     5.2671605348587036e-01
    z[3,5,4]  R1790     -0.384162575006485
    z[3,5,4]  R1791     2.5257727503776550e-01
    z[3,5,4]  R1792     3.8030573725700378e-01
    z[3,5,4]  R1793     -5.5059641599655151e-02
    z[3,5,4]  R1794     1.3978768885135651e-01
    z[3,5,4]  R1795     1.6580714285373688e-01
    z[3,5,4]  R1796     1.5398119390010834e-01
    z[3,5,4]  R1797     -1.0099439322948456e-01
    z[3,5,4]  R1798     -3.1638448126614094e-03
    z[3,5,4]  R1799     -3.8547852635383606e-01
    z[3,5,5]  R34       -1
    z[3,5,5]  R52       1
    z[3,5,5]  R1676     -1
    z[3,5,5]  R1677     1
    z[3,5,5]  R1680     -7.3899462819099426e-02
    z[3,5,5]  R1681     -5.0889093428850174e-02
    z[3,5,5]  R1682     -7.8351572155952454e-02
    z[3,5,5]  R1683     -2.1108351647853851e-01
    z[3,5,5]  R1684     4.1301745176315308e-01
    z[3,5,5]  R1685     6.8182200193405151e-01
    z[3,5,5]  R1686     7.0880597829818726e-01
    z[3,5,5]  R1687     6.1938923597335815e-01
    z[3,5,5]  R1688     2.0538989454507828e-02
    z[3,5,5]  R1689     4.3539252877235413e-01
    z[3,5,5]  R1690     -2.6755759119987488e-01
    z[3,5,5]  R1691     1.9438152015209198e-01
    z[3,5,5]  R1692     -1.2422193586826324e-01
    z[3,5,5]  R1693     -1.1561634950339794e-02
    z[3,5,5]  R1694     -5.9379488229751587e-01
    z[3,5,5]  R1695     -1.2538772821426392e-01
    z[3,5,5]  R1696     -5.6181255728006363e-02
    z[3,5,5]  R1697     -2.4589703977108002e-01
    z[3,5,5]  R1698     -1.7353695631027222e-01
    z[3,5,5]  R1699     -2.8736993670463562e-01
    z[3,5,5]  R1700     -5.9584236145019531e-01
    z[3,5,5]  R1701     -2.9813820123672485e-01
    z[3,5,5]  R1702     2.0180438458919525e-01
    z[3,5,5]  R1703     4.1949892044067383e-01
    z[3,5,5]  R1704     9.2779628932476044e-02
    z[3,5,5]  R1705     -1.7605556547641754e-01
    z[3,5,5]  R1706     5.8603119105100632e-02
    z[3,5,5]  R1707     -8.5768803954124451e-02
    z[3,5,5]  R1708     -3.4668779373168945e-01
    z[3,5,5]  R1709     -1.3270154595375061e-01
    z[3,5,5]  R1710     -7.5947046279907227e-03
    z[3,5,5]  R1711     -8.7791271507740021e-03
    z[3,5,5]  R1712     3.1882032752037048e-01
    z[3,5,5]  R1713     -5.7182990014553070e-02
    z[3,5,5]  R1714     -1.6890972852706909e-01
    z[3,5,5]  R1715     -6.4772136509418488e-02
    z[3,5,5]  R1716     1.0017333924770355e-01
    z[3,5,5]  R1717     0.231211319565773
    z[3,5,5]  R1718     5.7747727632522583e-01
    z[3,5,5]  R1719     2.6583153009414673e-01
    z[3,5,5]  R1720     2.2481076419353485e-01
    z[3,5,5]  R1721     1.3052079826593399e-02
    z[3,5,5]  R1722     1.5171720087528229e-01
    z[3,5,5]  R1723     -4.3023936450481415e-02
    z[3,5,5]  R1724     0.0353940911591053
    z[3,5,5]  R1725     4.4357147812843323e-01
    z[3,5,5]  R1726     4.7407639026641846e-01
    z[3,5,5]  R1727     6.2767281197011471e-03
    z[3,5,5]  R1728     -1.9781421124935150e-01
    z[3,5,5]  R1729     -1.9604696333408356e-01
    z[3,5,5]  R1730     1.9839632511138916e-01
    z[3,5,5]  R1731     3.3862125873565674e-01
    z[3,5,5]  R1732     -3.0617916956543922e-02
    z[3,5,5]  R1733     2.9147979617118835e-01
    z[3,5,5]  R1734     -3.6393553018569946e-01
    z[3,5,5]  R1735     -4.2408636212348938e-01
    z[3,5,5]  R1736     -1.2743981555104256e-02
    z[3,5,5]  R1737     -1.8517075479030609e-01
    z[3,5,5]  R1738     -3.0390882492065430e-01
    z[3,5,5]  R1739     -2.0238092541694641e-01
    z[3,5,5]  R1740     1.9782733917236328e-01
    z[3,5,5]  R1741     -9.8644390702247620e-02
    z[3,5,5]  R1742     -0.148346409201622
    z[3,5,5]  R1743     -4.6158552169799805e-01
    z[3,5,5]  R1744     -2.9842260479927063e-01
    z[3,5,5]  R1745     -3.4983307123184204e-01
    z[3,5,5]  R1746     -0.377279132604599
    z[3,5,5]  R1747     3.8751029968261719e-01
    z[3,5,5]  R1748     2.0157396793365479e-02
    z[3,5,5]  R1749     -3.3282953500747681e-01
    z[3,5,5]  R1750     5.0642937421798706e-01
    z[3,5,5]  R1751     -4.5824404805898666e-02
    z[3,5,5]  R1752     -6.2417805194854736e-01
    z[3,5,5]  R1753     -0.0754033774137497
    z[3,5,5]  R1754     -6.4436845481395721e-02
    z[3,5,5]  R1755     1.9234506785869598e-01
    z[3,5,5]  R1756     2.7806267142295837e-01
    z[3,5,5]  R1757     -2.3896206170320511e-02
    z[3,5,5]  R1758     -4.7335988283157349e-01
    z[3,5,5]  R1759     6.2632042169570923e-01
    z[3,5,5]  R1760     1.9467703998088837e-01
    z[3,5,5]  R1761     -4.9738940596580505e-01
    z[3,5,5]  R1762     -2.1414436399936676e-02
    z[3,5,5]  R1763     3.2057842612266541e-01
    z[3,5,5]  R1764     3.8099128007888794e-01
    z[3,5,5]  R1765     -6.7592531442642212e-01
    z[3,5,5]  R1766     5.3517264127731323e-01
    z[3,5,5]  R1767     2.1830736100673676e-01
    z[3,5,5]  R1768     -6.1397127807140350e-02
    z[3,5,5]  R1769     -2.8867498040199280e-01
    z[3,5,5]  R1770     -4.4239038228988647e-01
    z[3,5,5]  R1771     -2.9919949173927307e-01
    z[3,5,5]  R1772     -1.6329869627952576e-01
    z[3,5,5]  R1773     -5.9690177440643311e-01
    z[3,5,5]  R1774     1.0459543205797672e-02
    z[3,5,5]  R1775     3.1147959828376770e-01
    z[3,5,5]  R1776     9.0109594166278839e-02
    z[3,5,5]  R1777     3.6661437153816223e-01
    z[3,5,5]  R1778     -4.7735314816236496e-02
    z[3,5,5]  R1779     -2.3951521515846252e-01
    z[3,5,5]  R1780     -7.1482270956039429e-02
    z[3,5,5]  R1781     1.4146538078784943e-01
    z[3,5,5]  R1782     4.1564801335334778e-01
    z[3,5,5]  R1783     5.2571278065443039e-02
    z[3,5,5]  R1784     -6.4349097013473511e-01
    z[3,5,5]  R1785     -1.4879024028778076e-01
    z[3,5,5]  R1786     -4.0760420262813568e-02
    z[3,5,5]  R1787     2.3870344460010529e-01
    z[3,5,5]  R1788     -9.2644453048706055e-02
    z[3,5,5]  R1789     -1.2771388888359070e-01
    z[3,5,5]  R1790     1.2331591546535492e-01
    z[3,5,5]  R1791     -1.2022284418344498e-01
    z[3,5,5]  R1792     0.382844477891922
    z[3,5,5]  R1793     -9.3877725303173065e-02
    z[3,5,5]  R1794     -8.1795983016490936e-02
    z[3,5,5]  R1795     1.7924067378044128e-01
    z[3,5,5]  R1796     1.5473881363868713e-01
    z[3,5,5]  R1797     1.0495068877935410e-01
    z[3,5,5]  R1798     -3.1709831953048706e-01
    z[3,5,5]  R1799     -2.2529639303684235e-01
    z[3,5,6]  R35       -1
    z[3,5,6]  R53       1
    z[3,5,6]  R1678     -1
    z[3,5,6]  R1679     1
    z[3,5,6]  R1680     2.3194292187690735e-01
    z[3,5,6]  R1681     -5.6289398670196533e-01
    z[3,5,6]  R1682     4.6154615283012390e-01
    z[3,5,6]  R1683     -6.4207464456558228e-01
    z[3,5,6]  R1684     3.8247132301330566e-01
    z[3,5,6]  R1685     -0.119338259100914
    z[3,5,6]  R1686     0.0787559524178505
    z[3,5,6]  R1687     2.4156802892684937e-01
    z[3,5,6]  R1688     -1.2522128224372864e-01
    z[3,5,6]  R1689     -5.8474189043045044e-01
    z[3,5,6]  R1690     1.7861206829547882e-01
    z[3,5,6]  R1691     3.3109375834465027e-01
    z[3,5,6]  R1692     1.8474312126636505e-01
    z[3,5,6]  R1693     -1.3475050032138824e-01
    z[3,5,6]  R1694     2.1845014393329620e-01
    z[3,5,6]  R1695     -2.4525426328182220e-01
    z[3,5,6]  R1696     -5.0956577062606812e-01
    z[3,5,6]  R1697     4.5300893485546112e-02
    z[3,5,6]  R1698     2.8403285890817642e-02
    z[3,5,6]  R1699     1.0566082596778870e-01
    z[3,5,6]  R1700     3.4488376975059509e-01
    z[3,5,6]  R1701     -3.0400553345680237e-01
    z[3,5,6]  R1702     -5.7618337869644165e-01
    z[3,5,6]  R1703     -0.369929701089859
    z[3,5,6]  R1704     -7.0126913487911224e-02
    z[3,5,6]  R1705     -1.6045859456062317e-01
    z[3,5,6]  R1706     -1.5351210720837116e-02
    z[3,5,6]  R1707     -1.0269220918416977e-02
    z[3,5,6]  R1708     -1.2269319593906403e-01
    z[3,5,6]  R1709     -2.0770236849784851e-01
    z[3,5,6]  R1710     -1.4731016755104065e-01
    z[3,5,6]  R1711     -6.6391073167324066e-02
    z[3,5,6]  R1712     2.0331348478794098e-01
    z[3,5,6]  R1713     -8.5120923817157745e-02
    z[3,5,6]  R1714     -1.0575703531503677e-01
    z[3,5,6]  R1715     -0.09307861328125
    z[3,5,6]  R1716     2.4711626768112183e-01
    z[3,5,6]  R1717     2.0318250358104706e-01
    z[3,5,6]  R1718     -3.3131068944931030e-01
    z[3,5,6]  R1719     -6.8389378488063812e-02
    z[3,5,6]  R1720     3.6516536027193069e-02
    z[3,5,6]  R1721     0.0774056687951088
    z[3,5,6]  R1722     -1.4727701246738434e-01
    z[3,5,6]  R1723     -1.5174393355846405e-01
    z[3,5,6]  R1724     -4.7539597749710083e-01
    z[3,5,6]  R1725     2.2532801330089569e-01
    z[3,5,6]  R1726     8.6684837937355042e-02
    z[3,5,6]  R1727     3.5144168138504028e-01
    z[3,5,6]  R1728     -1.7987428605556488e-01
    z[3,5,6]  R1729     3.6844724416732788e-01
    z[3,5,6]  R1730     0.677962064743042
    z[3,5,6]  R1731     -5.9153027832508087e-02
    z[3,5,6]  R1732     0.919495165348053
    z[3,5,6]  R1733     0.814403235912323
    z[3,5,6]  R1734     -1.8726487457752228e-01
    z[3,5,6]  R1735     3.9939272403717041e-01
    z[3,5,6]  R1736     2.7433177828788757e-01
    z[3,5,6]  R1737     -3.4588745236396790e-01
    z[3,5,6]  R1738     5.4620647430419922e-01
    z[3,5,6]  R1739     -1.9505728781223297e-01
    z[3,5,6]  R1740     2.5381517410278320e-01
    z[3,5,6]  R1741     3.0845694709569216e-03
    z[3,5,6]  R1742     -0.074495330452919
    z[3,5,6]  R1743     -2.7877295017242432e-01
    z[3,5,6]  R1744     -3.9746654033660889e-01
    z[3,5,6]  R1745     -5.3462157957255840e-03
    z[3,5,6]  R1746     4.3215584754943848e-01
    z[3,5,6]  R1747     -8.3619892597198486e-02
    z[3,5,6]  R1748     -2.7281185984611511e-01
    z[3,5,6]  R1749     -3.6632496118545532e-01
    z[3,5,6]  R1750     1.1175787448883057e-01
    z[3,5,6]  R1751     -8.6105622351169586e-02
    z[3,5,6]  R1752     -3.7456639111042023e-02
    z[3,5,6]  R1753     3.1134110689163208e-01
    z[3,5,6]  R1754     2.9562366008758545e-01
    z[3,5,6]  R1755     -8.3799540996551514e-02
    z[3,5,6]  R1756     -2.8917360305786133e-01
    z[3,5,6]  R1757     -3.4714111685752869e-01
    z[3,5,6]  R1758     1.2736445665359497e-01
    z[3,5,6]  R1759     -6.8762958049774170e-02
    z[3,5,6]  R1760     -1.6143139451742172e-02
    z[3,5,6]  R1761     2.1712635457515717e-01
    z[3,5,6]  R1762     1.1941968649625778e-01
    z[3,5,6]  R1763     2.5954738259315491e-01
    z[3,5,6]  R1764     -6.4274176955223083e-02
    z[3,5,6]  R1765     -3.3101800829172134e-02
    z[3,5,6]  R1766     -1.3286098837852478e-01
    z[3,5,6]  R1767     -1.1625555902719498e-01
    z[3,5,6]  R1768     -3.4496295452117920e-01
    z[3,5,6]  R1769     2.6258850097656250e-01
    z[3,5,6]  R1770     1.3789756596088409e-01
    z[3,5,6]  R1771     5.6865904480218887e-02
    z[3,5,6]  R1772     -2.2241444885730743e-01
    z[3,5,6]  R1773     0.195271834731102
    z[3,5,6]  R1774     -3.7824764847755432e-01
    z[3,5,6]  R1775     3.0041828751564026e-01
    z[3,5,6]  R1776     -3.9020174741744995e-01
    z[3,5,6]  R1777     -4.0451325476169586e-02
    z[3,5,6]  R1778     2.4714720249176025e-01
    z[3,5,6]  R1779     -7.1370363235473633e-01
    z[3,5,6]  R1780     6.2678046524524689e-02
    z[3,5,6]  R1781     3.5645064711570740e-01
    z[3,5,6]  R1782     -3.4316653013229370e-01
    z[3,5,6]  R1783     -3.2001107465475798e-03
    z[3,5,6]  R1784     -3.3547705411911011e-01
    z[3,5,6]  R1785     2.5705745816230774e-01
    z[3,5,6]  R1786     1.5021668374538422e-01
    z[3,5,6]  R1787     -3.2108661532402039e-01
    z[3,5,6]  R1788     1.7515990138053894e-01
    z[3,5,6]  R1789     -6.1666302382946014e-02
    z[3,5,6]  R1790     -8.5834875702857971e-02
    z[3,5,6]  R1791     2.0520697534084320e-01
    z[3,5,6]  R1792     -4.5186918228864670e-02
    z[3,5,6]  R1793     2.4321815371513367e-01
    z[3,5,6]  R1794     -1.5244592726230621e-01
    z[3,5,6]  R1795     -2.7870634198188782e-01
    z[3,5,6]  R1796     1.2779383361339569e-01
    z[3,5,6]  R1797     -3.3953779935836792e-01
    z[3,5,6]  R1798     -0.440801203250885
    z[3,5,6]  R1799     -3.7467747926712036e-02
    z[5,3,0]  R29       1
    z[5,3,0]  R47       -1
    z[5,3,0]  R1800     -1
    z[5,3,0]  R1801     1
    z[5,3,0]  R1814     7.5943458080291748e-01
    z[5,3,0]  R1815     8.6767166852951050e-01
    z[5,3,0]  R1816     7.3249679803848267e-01
    z[5,3,0]  R1817     6.8604403734207153e-01
    z[5,3,0]  R1818     -4.4286161661148071e-01
    z[5,3,0]  R1819     -5.4820311069488525e-01
    z[5,3,0]  R1820     8.8026702404022217e-01
    z[5,3,0]  R1821     6.8000304698944092e-01
    z[5,3,0]  R1822     1.1706885695457458e-01
    z[5,3,0]  R1823     6.7970955371856689e-01
    z[5,3,0]  R1824     -7.2851979732513428e-01
    z[5,3,0]  R1825     -5.3250616788864136e-01
    z[5,3,0]  R1826     -4.5595401525497437e-01
    z[5,3,0]  R1827     -4.3952351808547974e-01
    z[5,3,0]  R1828     -4.3826425075531006e-01
    z[5,3,0]  R1829     -4.2607232928276062e-01
    z[5,3,0]  R1830     -4.5474034547805786e-01
    z[5,3,0]  R1831     -0.492642879486084
    z[5,3,0]  R1832     -3.5169291496276855e-01
    z[5,3,0]  R1833     -4.2849314212799072e-01
    z[5,3,0]  R1834     -1.8124037981033325e-01
    z[5,3,0]  R1835     1.0111644119024277e-01
    z[5,3,0]  R1836     -1.4891627430915833e-01
    z[5,3,0]  R1837     -3.5820782184600830e-01
    z[5,3,0]  R1838     1.6601191833615303e-02
    z[5,3,0]  R1839     -9.0139172971248627e-02
    z[5,3,0]  R1840     9.9790267646312714e-02
    z[5,3,0]  R1841     -5.5877542495727539e-01
    z[5,3,0]  R1842     -6.8435692787170410e-01
    z[5,3,0]  R1843     0.591355562210083
    z[5,3,0]  R1844     -0.634787917137146
    z[5,3,0]  R1845     -4.2726138234138489e-01
    z[5,3,0]  R1846     1.2502075731754303e-01
    z[5,3,0]  R1847     3.1266176700592041e-01
    z[5,3,0]  R1848     3.5332730412483215e-01
    z[5,3,0]  R1849     -8.6019468307495117e-01
    z[5,3,0]  R1850     -0.551559567451477
    z[5,3,0]  R1851     0.562705397605896
    z[5,3,0]  R1852     5.3335338830947876e-01
    z[5,3,0]  R1853     5.8284366130828857e-01
    z[5,3,0]  R1854     -1.4608344435691833e-01
    z[5,3,0]  R1855     4.0938743948936462e-01
    z[5,3,0]  R1856     1.8510198593139648e-01
    z[5,3,0]  R1857     2.6271072030067444e-01
    z[5,3,0]  R1858     5.9153407812118530e-01
    z[5,3,0]  R1859     2.2646707296371460e-01
    z[5,3,0]  R1860     5.1118308305740356e-01
    z[5,3,0]  R1861     -8.3527660369873047e-01
    z[5,3,0]  R1862     -4.7554358839988708e-01
    z[5,3,0]  R1863     -5.4265040159225464e-01
    z[5,3,0]  R1864     4.9199834465980530e-01
    z[5,3,0]  R1865     6.2315154075622559e-01
    z[5,3,0]  R1866     -5.2788324654102325e-02
    z[5,3,0]  R1867     4.3013170361518860e-01
    z[5,3,0]  R1868     0.500211238861084
    z[5,3,0]  R1869     -4.3523499369621277e-01
    z[5,3,0]  R1870     -5.9402501583099365e-01
    z[5,3,0]  R1871     -0.832075297832489
    z[5,3,0]  R1872     -5.5556356906890869e-01
    z[5,3,0]  R1873     -8.5553938150405884e-01
    z[5,3,0]  R1874     -7.5360065698623657e-01
    z[5,3,0]  R1875     7.5770670175552368e-01
    z[5,3,0]  R1876     1.5656508505344391e-01
    z[5,3,0]  R1877     -2.8213843703269958e-01
    z[5,3,0]  R1878     -2.8486687690019608e-02
    z[5,3,0]  R1879     4.7304117679595947e-01
    z[5,3,0]  R1880     -8.5314494371414185e-01
    z[5,3,0]  R1881     -6.6401398181915283e-01
    z[5,3,0]  R1882     -9.0782427787780762e-01
    z[5,3,0]  R1883     -6.1012154817581177e-01
    z[5,3,0]  R1884     5.7783633470535278e-01
    z[5,3,0]  R1885     4.4784688949584961e-01
    z[5,3,0]  R1886     -4.8408564925193787e-01
    z[5,3,0]  R1887     -0.672747015953064
    z[5,3,0]  R1888     -4.9150905013084412e-01
    z[5,3,0]  R1889     5.8502227067947388e-01
    z[5,3,0]  R1890     6.6070383787155151e-01
    z[5,3,0]  R1891     6.8326950073242188e-01
    z[5,3,0]  R1892     6.8778365850448608e-01
    z[5,3,0]  R1893     6.7371368408203125e-01
    z[5,3,0]  R1894     -8.9634925127029419e-01
    z[5,3,0]  R1895     5.8706700801849365e-01
    z[5,3,0]  R1896     6.3879698514938354e-01
    z[5,3,0]  R1897     6.2776446342468262e-01
    z[5,3,0]  R1898     4.9042728543281555e-01
    z[5,3,0]  R1899     -4.4271769002079964e-03
    z[5,3,0]  R1900     3.7055447697639465e-02
    z[5,3,0]  R1901     5.4906487464904785e-01
    z[5,3,0]  R1902     5.7185983657836914e-01
    z[5,3,0]  R1903     2.9208138585090637e-01
    z[5,3,0]  R1904     1.2302646785974503e-01
    z[5,3,0]  R1905     3.9639464020729065e-01
    z[5,3,0]  R1906     -4.4419410824775696e-01
    z[5,3,0]  R1907     -3.4195578098297119e-01
    z[5,3,0]  R1908     -4.2483130097389221e-01
    z[5,3,0]  R1909     -4.7725465893745422e-01
    z[5,3,0]  R1910     -1.1169387027621269e-02
    z[5,3,0]  R1911     2.6945248246192932e-01
    z[5,3,0]  R1912     1.1034189164638519e-01
    z[5,3,0]  R1913     -1.4272119104862213e-01
    z[5,3,0]  R1914     -6.6784307360649109e-02
    z[5,3,0]  R1915     4.2604845762252808e-01
    z[5,3,0]  R1916     3.7830349802970886e-01
    z[5,3,0]  R1917     4.3023020029067993e-01
    z[5,3,0]  R1918     4.3663305044174194e-01
    z[5,3,0]  R1919     -3.4835276007652283e-01
    z[5,3,0]  R1920     -3.6363103985786438e-01
    z[5,3,0]  R1921     7.8226590156555176e-01
    z[5,3,0]  R1922     6.4075648784637451e-01
    z[5,3,0]  R1923     6.8611931800842285e-01
    z[5,3,0]  R1924     -1.6029927134513855e-01
    z[5,3,0]  R1925     4.0806140750646591e-02
    z[5,3,0]  R1926     -2.8304606676101685e-01
    z[5,3,0]  R1927     -5.8769184350967407e-01
    z[5,3,0]  R1928     6.7144066095352173e-01
    z[5,3,0]  R1929     0.865686297416687
    z[5,3,0]  R1930     6.8237137794494629e-01
    z[5,3,0]  R1931     8.3832150697708130e-01
    z[5,3,0]  R1932     8.1652325391769409e-01
    z[5,3,0]  R1933     6.7006939649581909e-01
    z[5,3,1]  R30       1
    z[5,3,1]  R48       -1
    z[5,3,1]  R1802     -1
    z[5,3,1]  R1803     1
    z[5,3,1]  R1814     5.1057547330856323e-01
    z[5,3,1]  R1815     3.1768313050270081e-01
    z[5,3,1]  R1816     4.8648440837860107e-01
    z[5,3,1]  R1817     4.7185283899307251e-01
    z[5,3,1]  R1818     4.4452327489852905e-01
    z[5,3,1]  R1819     -4.0931418538093567e-02
    z[5,3,1]  R1820     3.4900563955307007e-01
    z[5,3,1]  R1821     4.5200872421264648e-01
    z[5,3,1]  R1822     6.1654180288314819e-01
    z[5,3,1]  R1823     3.8457027077674866e-01
    z[5,3,1]  R1824     2.4004091322422028e-01
    z[5,3,1]  R1825     -4.3289753794670105e-01
    z[5,3,1]  R1826     -0.192816823720932
    z[5,3,1]  R1827     -2.1364213526248932e-01
    z[5,3,1]  R1828     -2.2704876959323883e-01
    z[5,3,1]  R1829     -2.5199401378631592e-01
    z[5,3,1]  R1830     -2.0157837867736816e-01
    z[5,3,1]  R1831     -1.9670151174068451e-01
    z[5,3,1]  R1832     -2.3894466459751129e-01
    z[5,3,1]  R1833     -2.3336625099182129e-01
    z[5,3,1]  R1834     3.4802475571632385e-01
    z[5,3,1]  R1835     7.8177338838577271e-01
    z[5,3,1]  R1836     2.4236483871936798e-01
    z[5,3,1]  R1837     1.7813818156719208e-01
    z[5,3,1]  R1838     8.5366815328598022e-01
    z[5,3,1]  R1839     6.6496598720550537e-01
    z[5,3,1]  R1840     3.4388515353202820e-01
    z[5,3,1]  R1841     -3.1246135011315346e-02
    z[5,3,1]  R1842     -1.8710640072822571e-01
    z[5,3,1]  R1843     -7.2522288560867310e-01
    z[5,3,1]  R1844     5.2543687820434570e-01
    z[5,3,1]  R1845     5.8598470687866211e-01
    z[5,3,1]  R1846     0.849338948726654
    z[5,3,1]  R1847     7.1854478120803833e-01
    z[5,3,1]  R1848     4.8190990090370178e-01
    z[5,3,1]  R1849     -1.8543800711631775e-01
    z[5,3,1]  R1850     -3.7781310081481934e-01
    z[5,3,1]  R1851     -5.2031236886978149e-01
    z[5,3,1]  R1852     -6.2621653079986572e-01
    z[5,3,1]  R1853     1.9602222368121147e-02
    z[5,3,1]  R1854     7.7178794145584106e-01
    z[5,3,1]  R1855     7.8734922409057617e-01
    z[5,3,1]  R1856     6.1397576332092285e-01
    z[5,3,1]  R1857     8.8871586322784424e-01
    z[5,3,1]  R1858     0.267733097076416
    z[5,3,1]  R1859     3.3866789937019348e-01
    z[5,3,1]  R1860     5.2049368619918823e-01
    z[5,3,1]  R1861     -1.1216162145137787e-01
    z[5,3,1]  R1862     3.0052950978279114e-01
    z[5,3,1]  R1863     -3.2113844156265259e-01
    z[5,3,1]  R1864     4.7029018402099609e-01
    z[5,3,1]  R1865     3.7659695744514465e-01
    z[5,3,1]  R1866     0.0677233412861824
    z[5,3,1]  R1867     1.5144044160842896e-01
    z[5,3,1]  R1868     5.7834458351135254e-01
    z[5,3,1]  R1869     5.1786535978317261e-01
    z[5,3,1]  R1870     -2.8375563025474548e-01
    z[5,3,1]  R1871     -3.4214520454406738e-01
    z[5,3,1]  R1872     -3.3144152164459229e-01
    z[5,3,1]  R1873     -0.0317201092839241
    z[5,3,1]  R1874     1.1143982410430908e-01
    z[5,3,1]  R1875     4.7424244880676270e-01
    z[5,3,1]  R1876     8.5829752683639526e-01
    z[5,3,1]  R1877     3.1502538919448853e-01
    z[5,3,1]  R1878     4.6628189086914062e-01
    z[5,3,1]  R1879     5.6245517730712891e-01
    z[5,3,1]  R1880     -2.7969694137573242e-01
    z[5,3,1]  R1881     -4.1869038343429565e-01
    z[5,3,1]  R1882     -2.2984184324741364e-01
    z[5,3,1]  R1883     -3.1074598431587219e-02
    z[5,3,1]  R1884     7.8660178184509277e-01
    z[5,3,1]  R1885     6.3052386045455933e-01
    z[5,3,1]  R1886     1.7272271215915680e-01
    z[5,3,1]  R1887     -3.2018333673477173e-01
    z[5,3,1]  R1888     -2.6289907097816467e-01
    z[5,3,1]  R1889     -3.7370449304580688e-01
    z[5,3,1]  R1890     -5.1204943656921387e-01
    z[5,3,1]  R1891     -3.6264434456825256e-01
    z[5,3,1]  R1892     -5.7322126626968384e-01
    z[5,3,1]  R1893     -4.6222689747810364e-01
    z[5,3,1]  R1894     -9.9885143339633942e-02
    z[5,3,1]  R1895     -4.1757720708847046e-01
    z[5,3,1]  R1896     -5.2153486013412476e-01
    z[5,3,1]  R1897     -5.8511340618133545e-01
    z[5,3,1]  R1898     -6.2838965654373169e-01
    z[5,3,1]  R1899     -7.2098881006240845e-01
    z[5,3,1]  R1900     -8.9664030075073242e-01
    z[5,3,1]  R1901     -5.7314264774322510e-01
    z[5,3,1]  R1902     -4.7685539722442627e-01
    z[5,3,1]  R1903     -5.5895823240280151e-01
    z[5,3,1]  R1904     3.5636723041534424e-01
    z[5,3,1]  R1905     1.4859323203563690e-01
    z[5,3,1]  R1906     4.9766483902931213e-01
    z[5,3,1]  R1907     -2.0866273343563080e-01
    z[5,3,1]  R1908     0.191564679145813
    z[5,3,1]  R1909     1.2885032594203949e-01
    z[5,3,1]  R1910     -1.8866440653800964e-01
    z[5,3,1]  R1911     -2.2225941717624664e-01
    z[5,3,1]  R1912     -2.5352746248245239e-01
    z[5,3,1]  R1913     -1.8692450225353241e-01
    z[5,3,1]  R1914     -9.0078812837600708e-01
    z[5,3,1]  R1915     -6.3910853862762451e-01
    z[5,3,1]  R1916     -8.7422186136245728e-01
    z[5,3,1]  R1917     -8.1641918420791626e-01
    z[5,3,1]  R1918     2.1426524221897125e-01
    z[5,3,1]  R1919     4.7654518485069275e-01
    z[5,3,1]  R1920     3.5593998432159424e-01
    z[5,3,1]  R1921     -1.8441970646381378e-01
    z[5,3,1]  R1922     -2.9422175884246826e-01
    z[5,3,1]  R1923     -1.8421749770641327e-01
    z[5,3,1]  R1924     0.215898334980011
    z[5,3,1]  R1925     7.7527087926864624e-01
    z[5,3,1]  R1926     6.9777315855026245e-01
    z[5,3,1]  R1927     -2.1259206533432007e-01
    z[5,3,1]  R1928     -2.4626728892326355e-01
    z[5,3,1]  R1929     -1.0118196159601212e-01
    z[5,3,1]  R1930     -1.8070322275161743e-01
    z[5,3,1]  R1931     -7.5816445052623749e-02
    z[5,3,1]  R1932     -1.8228402733802795e-01
    z[5,3,1]  R1933     -5.8117534965276718e-02
    z[5,3,2]  R31       1
    z[5,3,2]  R49       -1
    z[5,3,2]  R1804     -1
    z[5,3,2]  R1805     1
    z[5,3,2]  R1814     0.225607231259346
    z[5,3,2]  R1815     3.1976962089538574e-01
    z[5,3,2]  R1816     2.1875400841236115e-01
    z[5,3,2]  R1817     4.4502955675125122e-01
    z[5,3,2]  R1818     -4.7080716490745544e-01
    z[5,3,2]  R1819     -4.1226577758789062e-01
    z[5,3,2]  R1820     1.5544793009757996e-01
    z[5,3,2]  R1821     3.5547360777854919e-01
    z[5,3,2]  R1822     -3.2983991503715515e-01
    z[5,3,2]  R1823     4.8570439219474792e-01
    z[5,3,2]  R1824     2.3494124412536621e-01
    z[5,3,2]  R1825     6.5841847658157349e-01
    z[5,3,2]  R1826     8.0758494138717651e-01
    z[5,3,2]  R1827     6.8192929029464722e-01
    z[5,3,2]  R1828     6.5245223045349121e-01
    z[5,3,2]  R1829     6.6472548246383667e-01
    z[5,3,2]  R1830     0.639353334903717
    z[5,3,2]  R1831     6.3165879249572754e-01
    z[5,3,2]  R1832     7.7503788471221924e-01
    z[5,3,2]  R1833     5.7745563983917236e-01
    z[5,3,2]  R1834     2.3937088251113892e-01
    z[5,3,2]  R1835     2.8595605492591858e-01
    z[5,3,2]  R1836     -4.6420689672231674e-02
    z[5,3,2]  R1837     -2.5077894330024719e-01
    z[5,3,2]  R1838     1.2380032241344452e-01
    z[5,3,2]  R1839     -3.7403452396392822e-01
    z[5,3,2]  R1840     -7.1206778287887573e-01
    z[5,3,2]  R1841     -4.7657048702239990e-01
    z[5,3,2]  R1842     -2.1853515505790710e-01
    z[5,3,2]  R1843     -5.7819854468107224e-02
    z[5,3,2]  R1844     -4.0094745159149170e-01
    z[5,3,2]  R1845     -6.7131072282791138e-01
    z[5,3,2]  R1846     -4.1002368927001953e-01
    z[5,3,2]  R1847     -2.6114150881767273e-01
    z[5,3,2]  R1848     4.2280846834182739e-01
    z[5,3,2]  R1849     -2.4369031190872192e-01
    z[5,3,2]  R1850     0.328095406293869
    z[5,3,2]  R1851     3.8787674903869629e-01
    z[5,3,2]  R1852     2.9203245043754578e-01
    z[5,3,2]  R1853     -2.7586886286735535e-01
    z[5,3,2]  R1854     -2.2261705994606018e-01
    z[5,3,2]  R1855     3.4349447488784790e-01
    z[5,3,2]  R1856     -1.4417226612567902e-01
    z[5,3,2]  R1857     -1.2380160391330719e-01
    z[5,3,2]  R1858     -0.395833283662796
    z[5,3,2]  R1859     2.3510010540485382e-01
    z[5,3,2]  R1860     -2.0400816202163696e-01
    z[5,3,2]  R1861     -9.6323236823081970e-02
    z[5,3,2]  R1862     3.9766165614128113e-01
    z[5,3,2]  R1863     2.9063206911087036e-01
    z[5,3,2]  R1864     6.3487243652343750e-01
    z[5,3,2]  R1865     3.7208899855613708e-01
    z[5,3,2]  R1866     1.3445743918418884e-01
    z[5,3,2]  R1867     -4.3952378630638123e-01
    z[5,3,2]  R1868     -2.9135462641716003e-01
    z[5,3,2]  R1869     0.0922401174902916
    z[5,3,2]  R1870     4.4079285860061646e-01
    z[5,3,2]  R1871     -3.1065413355827332e-01
    z[5,3,2]  R1872     0.355376273393631
    z[5,3,2]  R1873     1.2634010612964630e-01
    z[5,3,2]  R1874     -4.2379835247993469e-01
    z[5,3,2]  R1875     3.0889004468917847e-01
    z[5,3,2]  R1876     -3.6990982294082642e-01
    z[5,3,2]  R1877     3.5622832179069519e-01
    z[5,3,2]  R1878     -4.7861674427986145e-01
    z[5,3,2]  R1879     -1.3612095499411225e-03
    z[5,3,2]  R1880     -1.4447963237762451e-01
    z[5,3,2]  R1881     2.8854611515998840e-01
    z[5,3,2]  R1882     2.1654902398586273e-01
    z[5,3,2]  R1883     6.2843970954418182e-02
    z[5,3,2]  R1884     -1.7592564225196838e-01
    z[5,3,2]  R1885     2.0112448930740356e-01
    z[5,3,2]  R1886     3.3232292532920837e-01
    z[5,3,2]  R1887     4.4547894597053528e-01
    z[5,3,2]  R1888     3.8438367843627930e-01
    z[5,3,2]  R1889     5.4896640777587891e-01
    z[5,3,2]  R1890     5.2453732490539551e-01
    z[5,3,2]  R1891     2.7125416323542595e-02
    z[5,3,2]  R1892     1.1758831888437271e-01
    z[5,3,2]  R1893     -1.3787375390529633e-01
    z[5,3,2]  R1894     -1.0769053548574448e-01
    z[5,3,2]  R1895     5.5269473791122437e-01
    z[5,3,2]  R1896     1.5828667581081390e-01
    z[5,3,2]  R1897     3.8291251659393311e-01
    z[5,3,2]  R1898     5.5537527799606323e-01
    z[5,3,2]  R1899     0.521673321723938
    z[5,3,2]  R1900     3.5263195633888245e-01
    z[5,3,2]  R1901     5.3273621946573257e-02
    z[5,3,2]  R1902     2.5538769364356995e-01
    z[5,3,2]  R1903     -2.4770677089691162e-01
    z[5,3,2]  R1904     2.5317168235778809e-01
    z[5,3,2]  R1905     4.4305637478828430e-01
    z[5,3,2]  R1906     -2.3154832422733307e-01
    z[5,3,2]  R1907     -4.9875292181968689e-01
    z[5,3,2]  R1908     -4.9246424436569214e-01
    z[5,3,2]  R1909     -0.179381862282753
    z[5,3,2]  R1910     0.50576251745224
    z[5,3,2]  R1911     4.9431779980659485e-01
    z[5,3,2]  R1912     5.8363676071166992e-01
    z[5,3,2]  R1913     3.7546235322952271e-01
    z[5,3,2]  R1914     -5.5164024233818054e-02
    z[5,3,2]  R1915     4.6470394730567932e-01
    z[5,3,2]  R1916     6.0612101107835770e-02
    z[5,3,2]  R1917     1.7800678312778473e-01
    z[5,3,2]  R1918     -2.4674880504608154e-01
    z[5,3,2]  R1919     1.0945523530244827e-01
    z[5,3,2]  R1920     2.0087005198001862e-01
    z[5,3,2]  R1921     -4.0304175019264221e-01
    z[5,3,2]  R1922     -4.7503703832626343e-01
    z[5,3,2]  R1923     -2.3438222706317902e-01
    z[5,3,2]  R1924     -4.0537121891975403e-01
    z[5,3,2]  R1925     -2.3900006711483002e-01
    z[5,3,2]  R1926     3.1247567385435104e-02
    z[5,3,2]  R1927     5.2226681262254715e-02
    z[5,3,2]  R1928     -3.5896146297454834e-01
    z[5,3,2]  R1929     -1.0460843890905380e-01
    z[5,3,2]  R1930     -3.1134307384490967e-01
    z[5,3,2]  R1931     -1.2013496458530426e-01
    z[5,3,2]  R1932     -2.0758289098739624e-01
    z[5,3,2]  R1933     -2.4450413882732391e-01
    z[5,3,3]  R32       1
    z[5,3,3]  R50       -1
    z[5,3,3]  R1806     -1
    z[5,3,3]  R1807     1
    z[5,3,3]  R1814     2.8614804148674011e-01
    z[5,3,3]  R1815     1.9862221181392670e-01
    z[5,3,3]  R1816     9.6923463046550751e-02
    z[5,3,3]  R1817     1.0683256387710571e-01
    z[5,3,3]  R1818     -3.4418621659278870e-01
    z[5,3,3]  R1819     -3.7811005115509033e-01
    z[5,3,3]  R1820     7.2333104908466339e-02
    z[5,3,3]  R1821     -1.9786326587200165e-01
    z[5,3,3]  R1822     -1.4166752994060516e-01
    z[5,3,3]  R1823     -8.8863588869571686e-02
    z[5,3,3]  R1824     -1.4615970849990845e-01
    z[5,3,3]  R1825     2.3510551452636719e-01
    z[5,3,3]  R1826     8.4521457552909851e-02
    z[5,3,3]  R1827     4.4326889514923096e-01
    z[5,3,3]  R1828     3.0297595262527466e-01
    z[5,3,3]  R1829     -6.4370416104793549e-02
    z[5,3,3]  R1830     2.6252093911170959e-01
    z[5,3,3]  R1831     2.3608949780464172e-01
    z[5,3,3]  R1832     -0.383390337228775
    z[5,3,3]  R1833     4.6426522731781006e-01
    z[5,3,3]  R1834     -5.3112649917602539e-01
    z[5,3,3]  R1835     -1.9288714230060577e-01
    z[5,3,3]  R1836     -2.5173398852348328e-01
    z[5,3,3]  R1837     -1.6380971670150757e-01
    z[5,3,3]  R1838     -9.9699504673480988e-02
    z[5,3,3]  R1839     1.8503373861312866e-01
    z[5,3,3]  R1840     5.2364283800125122e-01
    z[5,3,3]  R1841     5.2530074119567871e-01
    z[5,3,3]  R1842     1.2904337048530579e-01
    z[5,3,3]  R1843     -1.1997362226247787e-01
    z[5,3,3]  R1844     -2.3272280395030975e-01
    z[5,3,3]  R1845     4.1645620018243790e-02
    z[5,3,3]  R1846     2.0353603363037109e-01
    z[5,3,3]  R1847     1.6257666051387787e-01
    z[5,3,3]  R1848     -4.2788782715797424e-01
    z[5,3,3]  R1849     1.0887966305017471e-01
    z[5,3,3]  R1850     -2.7930095791816711e-01
    z[5,3,3]  R1851     -1.5871591866016388e-01
    z[5,3,3]  R1852     -0.0847240760922432
    z[5,3,3]  R1853     2.6343245059251785e-02
    z[5,3,3]  R1854     -2.5393217802047729e-01
    z[5,3,3]  R1855     -2.6008498668670654e-01
    z[5,3,3]  R1856     -2.3698411881923676e-01
    z[5,3,3]  R1857     -1.5202210843563080e-01
    z[5,3,3]  R1858     -5.7442313432693481e-01
    z[5,3,3]  R1859     -6.6975212097167969e-01
    z[5,3,3]  R1860     4.0605121850967407e-01
    z[5,3,3]  R1861     1.2707798182964325e-01
    z[5,3,3]  R1862     -5.3396087884902954e-01
    z[5,3,3]  R1863     -8.2362376153469086e-02
    z[5,3,3]  R1864     -4.7547496855258942e-02
    z[5,3,3]  R1865     0.0390746146440506
    z[5,3,3]  R1866     -7.0815253257751465e-01
    z[5,3,3]  R1867     -1.5038779377937317e-01
    z[5,3,3]  R1868     3.5058364272117615e-01
    z[5,3,3]  R1869     -1.2800544500350952e-01
    z[5,3,3]  R1870     1.1343742907047272e-01
    z[5,3,3]  R1871     1.1935079097747803e-01
    z[5,3,3]  R1872     2.7844834327697754e-01
    z[5,3,3]  R1873     3.0967876315116882e-01
    z[5,3,3]  R1874     -8.1400223076343536e-02
    z[5,3,3]  R1875     2.4099707603454590e-02
    z[5,3,3]  R1876     -5.8336075395345688e-02
    z[5,3,3]  R1877     -5.3081786632537842e-01
    z[5,3,3]  R1878     -3.9032605290412903e-01
    z[5,3,3]  R1879     -3.8091403245925903e-01
    z[5,3,3]  R1880     -1.1232873797416687e-01
    z[5,3,3]  R1881     2.5902670621871948e-01
    z[5,3,3]  R1882     -5.9855529107153416e-03
    z[5,3,3]  R1883     -2.2981157898902893e-01
    z[5,3,3]  R1884     0.0851278305053711
    z[5,3,3]  R1885     -4.1740727424621582e-01
    z[5,3,3]  R1886     -5.7617175579071045e-01
    z[5,3,3]  R1887     -4.9353456497192383e-01
    z[5,3,3]  R1888     1.1958824843168259e-01
    z[5,3,3]  R1889     -2.5140696763992310e-01
    z[5,3,3]  R1890     4.2824551463127136e-02
    z[5,3,3]  R1891     -3.0461966991424561e-02
    z[5,3,3]  R1892     0.380967378616333
    z[5,3,3]  R1893     1.2610933184623718e-01
    z[5,3,3]  R1894     6.9487184286117554e-02
    z[5,3,3]  R1895     -2.3484340310096741e-01
    z[5,3,3]  R1896     -4.0507983416318893e-02
    z[5,3,3]  R1897     2.1431854367256165e-01
    z[5,3,3]  R1898     -8.1822186708450317e-02
    z[5,3,3]  R1899     -2.6592493057250977e-01
    z[5,3,3]  R1900     -7.9549968242645264e-02
    z[5,3,3]  R1901     4.8030912876129150e-01
    z[5,3,3]  R1902     2.9239574074745178e-01
    z[5,3,3]  R1903     5.8321475982666016e-01
    z[5,3,3]  R1904     4.7430381178855896e-02
    z[5,3,3]  R1905     2.8876092284917831e-02
    z[5,3,3]  R1906     5.0100311636924744e-02
    z[5,3,3]  R1907     -2.7720436453819275e-01
    z[5,3,3]  R1908     -4.6595868468284607e-01
    z[5,3,3]  R1909     -5.5398764088749886e-03
    z[5,3,3]  R1910     4.4093075394630432e-01
    z[5,3,3]  R1911     2.7040678262710571e-01
    z[5,3,3]  R1912     7.3127579689025879e-01
    z[5,3,3]  R1913     4.1562882065773010e-01
    z[5,3,3]  R1914     1.2848268449306488e-01
    z[5,3,3]  R1915     2.1257027983665466e-01
    z[5,3,3]  R1916     -1.9541363418102264e-01
    z[5,3,3]  R1917     -1.9743348658084869e-01
    z[5,3,3]  R1918     -5.4969519376754761e-01
    z[5,3,3]  R1919     6.3999301195144653e-01
    z[5,3,3]  R1920     6.6140717267990112e-01
    z[5,3,3]  R1921     3.5298663377761841e-01
    z[5,3,3]  R1922     4.4309777021408081e-01
    z[5,3,3]  R1923     4.6353161334991455e-01
    z[5,3,3]  R1924     -3.0771313235163689e-02
    z[5,3,3]  R1925     -2.6654061675071716e-01
    z[5,3,3]  R1926     2.0046578347682953e-01
    z[5,3,3]  R1927     4.1446754336357117e-01
    z[5,3,3]  R1928     5.8468794822692871e-01
    z[5,3,3]  R1929     3.7966915965080261e-01
    z[5,3,3]  R1930     5.9524923563003540e-01
    z[5,3,3]  R1931     4.0818822383880615e-01
    z[5,3,3]  R1932     3.3546721935272217e-01
    z[5,3,3]  R1933     6.5078121423721313e-01
    z[5,3,4]  R33       1
    z[5,3,4]  R51       -1
    z[5,3,4]  R1808     -1
    z[5,3,4]  R1809     1
    z[5,3,4]  R1814     -8.9635804295539856e-02
    z[5,3,4]  R1815     5.9240357950329781e-03
    z[5,3,4]  R1816     1.6294494271278381e-01
    z[5,3,4]  R1817     2.9447984695434570e-01
    z[5,3,4]  R1818     4.7585102915763855e-01
    z[5,3,4]  R1819     6.0992515087127686e-01
    z[5,3,4]  R1820     5.3177025169134140e-02
    z[5,3,4]  R1821     2.7024206519126892e-01
    z[5,3,4]  R1822     1.8455411493778229e-01
    z[5,3,4]  R1823     2.6636752486228943e-01
    z[5,3,4]  R1824     -0.532170832157135
    z[5,3,4]  R1825     -1.8462254106998444e-01
    z[5,3,4]  R1826     -2.2556984424591064e-01
    z[5,3,4]  R1827     2.7346667647361755e-01
    z[5,3,4]  R1828     1.0784591734409332e-01
    z[5,3,4]  R1829     2.4785001575946808e-01
    z[5,3,4]  R1830     2.0645757019519806e-01
    z[5,3,4]  R1831     3.7460610270500183e-01
    z[5,3,4]  R1832     0.00777652719989419
    z[5,3,4]  R1833     1.9684703648090363e-01
    z[5,3,4]  R1834     8.7425507605075836e-02
    z[5,3,4]  R1835     -3.7611982226371765e-01
    z[5,3,4]  R1836     8.4554873406887054e-02
    z[5,3,4]  R1837     4.4912289828062057e-02
    z[5,3,4]  R1838     -2.7962690591812134e-01
    z[5,3,4]  R1839     -1.9024184346199036e-01
    z[5,3,4]  R1840     -1.2297239154577255e-01
    z[5,3,4]  R1841     -1.7264726758003235e-01
    z[5,3,4]  R1842     -2.0380100607872009e-01
    z[5,3,4]  R1843     -1.6615694761276245e-01
    z[5,3,4]  R1844     4.9837347120046616e-02
    z[5,3,4]  R1845     1.0925633460283279e-01
    z[5,3,4]  R1846     -1.6090567409992218e-01
    z[5,3,4]  R1847     -2.3118624463677406e-02
    z[5,3,4]  R1848     1.8447768688201904e-01
    z[5,3,4]  R1849     -1.7895893752574921e-01
    z[5,3,4]  R1850     1.9566673040390015e-01
    z[5,3,4]  R1851     2.8256335854530334e-01
    z[5,3,4]  R1852     3.9508658647537231e-01
    z[5,3,4]  R1853     5.8149969577789307e-01
    z[5,3,4]  R1854     -1.5922186430543661e-03
    z[5,3,4]  R1855     -1.3166756927967072e-01
    z[5,3,4]  R1856     3.4759557247161865e-01
    z[5,3,4]  R1857     1.0526530444622040e-02
    z[5,3,4]  R1858     -1.4662112109363079e-02
    z[5,3,4]  R1859     5.3493720293045044e-01
    z[5,3,4]  R1860     -3.1676670908927917e-01
    z[5,3,4]  R1861     -3.7845450639724731e-01
    z[5,3,4]  R1862     -1.3518825289793313e-04
    z[5,3,4]  R1863     -3.3785271644592285e-01
    z[5,3,4]  R1864     -3.0541995167732239e-01
    z[5,3,4]  R1865     -1.8798868358135223e-01
    z[5,3,4]  R1866     6.7701435089111328e-01
    z[5,3,4]  R1867     6.3727504014968872e-01
    z[5,3,4]  R1868     -2.4129703640937805e-01
    z[5,3,4]  R1869     -2.4397027492523193e-01
    z[5,3,4]  R1870     2.3534847795963287e-01
    z[5,3,4]  R1871     -1.3661400973796844e-01
    z[5,3,4]  R1872     5.0487709045410156e-01
    z[5,3,4]  R1873     -5.3828172385692596e-02
    z[5,3,4]  R1874     1.3678911328315735e-01
    z[5,3,4]  R1875     -1.1057466268539429e-01
    z[5,3,4]  R1876     1.4980529248714447e-01
    z[5,3,4]  R1877     1.3441678881645203e-01
    z[5,3,4]  R1878     -5.0711023807525635e-01
    z[5,3,4]  R1879     3.5708293318748474e-01
    z[5,3,4]  R1880     6.6397930495440960e-03
    z[5,3,4]  R1881     3.1206998229026794e-01
    z[5,3,4]  R1882     1.1286263167858124e-01
    z[5,3,4]  R1883     5.7297468185424805e-02
    z[5,3,4]  R1884     -1.1313164606690407e-02
    z[5,3,4]  R1885     2.0030789077281952e-01
    z[5,3,4]  R1886     0.0537506528198719
    z[5,3,4]  R1887     9.6015287563204765e-03
    z[5,3,4]  R1888     -2.5005133822560310e-02
    z[5,3,4]  R1889     2.5555279850959778e-01
    z[5,3,4]  R1890     8.7121017277240753e-03
    z[5,3,4]  R1891     4.8978802561759949e-01
    z[5,3,4]  R1892     1.1990191414952278e-02
    z[5,3,4]  R1893     5.2671605348587036e-01
    z[5,3,4]  R1894     -0.384162575006485
    z[5,3,4]  R1895     2.5257727503776550e-01
    z[5,3,4]  R1896     3.8030573725700378e-01
    z[5,3,4]  R1897     -5.5059641599655151e-02
    z[5,3,4]  R1898     1.3978768885135651e-01
    z[5,3,4]  R1899     1.6580714285373688e-01
    z[5,3,4]  R1900     1.5398119390010834e-01
    z[5,3,4]  R1901     -1.0099439322948456e-01
    z[5,3,4]  R1902     -3.1638448126614094e-03
    z[5,3,4]  R1903     -3.8547852635383606e-01
    z[5,3,4]  R1904     0.85572350025177
    z[5,3,4]  R1905     5.5156075954437256e-01
    z[5,3,4]  R1906     -5.2889782190322876e-01
    z[5,3,4]  R1907     2.3898379504680634e-01
    z[5,3,4]  R1908     0.0794677734375
    z[5,3,4]  R1909     4.9426129460334778e-01
    z[5,3,4]  R1910     -7.3871716856956482e-02
    z[5,3,4]  R1911     3.4427908062934875e-01
    z[5,3,4]  R1912     -1.7902587354183197e-01
    z[5,3,4]  R1913     -3.1540572643280029e-01
    z[5,3,4]  R1914     -2.4714456498622894e-01
    z[5,3,4]  R1915     -3.8467753678560257e-02
    z[5,3,4]  R1916     -3.4658830612897873e-02
    z[5,3,4]  R1917     -2.4372906982898712e-01
    z[5,3,4]  R1918     8.9103868231177330e-03
    z[5,3,4]  R1919     3.9257079362869263e-01
    z[5,3,4]  R1920     -2.1384319290518761e-02
    z[5,3,4]  R1921     6.7004904150962830e-02
    z[5,3,4]  R1922     2.2348852455615997e-01
    z[5,3,4]  R1923     3.6299028992652893e-01
    z[5,3,4]  R1924     5.3707206249237061e-01
    z[5,3,4]  R1925     2.9634320735931396e-01
    z[5,3,4]  R1926     1.3828288018703461e-01
    z[5,3,4]  R1927     -3.4940603375434875e-01
    z[5,3,4]  R1928     -6.5426945686340332e-02
    z[5,3,4]  R1929     -1.6886492073535919e-01
    z[5,3,4]  R1930     2.1630893647670746e-01
    z[5,3,4]  R1931     3.2086926698684692e-01
    z[5,3,4]  R1932     9.5850922167301178e-02
    z[5,3,4]  R1933     5.9840731322765350e-02
    z[5,3,5]  R34       1
    z[5,3,5]  R52       -1
    z[5,3,5]  R1810     -1
    z[5,3,5]  R1811     1
    z[5,3,5]  R1814     -7.5947046279907227e-03
    z[5,3,5]  R1815     -8.7791271507740021e-03
    z[5,3,5]  R1816     3.1882032752037048e-01
    z[5,3,5]  R1817     -5.7182990014553070e-02
    z[5,3,5]  R1818     -1.6890972852706909e-01
    z[5,3,5]  R1819     -6.4772136509418488e-02
    z[5,3,5]  R1820     1.0017333924770355e-01
    z[5,3,5]  R1821     0.231211319565773
    z[5,3,5]  R1822     5.7747727632522583e-01
    z[5,3,5]  R1823     2.6583153009414673e-01
    z[5,3,5]  R1824     2.2481076419353485e-01
    z[5,3,5]  R1825     1.3052079826593399e-02
    z[5,3,5]  R1826     1.5171720087528229e-01
    z[5,3,5]  R1827     -4.3023936450481415e-02
    z[5,3,5]  R1828     0.0353940911591053
    z[5,3,5]  R1829     4.4357147812843323e-01
    z[5,3,5]  R1830     4.7407639026641846e-01
    z[5,3,5]  R1831     6.2767281197011471e-03
    z[5,3,5]  R1832     -1.9781421124935150e-01
    z[5,3,5]  R1833     -1.9604696333408356e-01
    z[5,3,5]  R1834     1.9839632511138916e-01
    z[5,3,5]  R1835     3.3862125873565674e-01
    z[5,3,5]  R1836     -3.0617916956543922e-02
    z[5,3,5]  R1837     2.9147979617118835e-01
    z[5,3,5]  R1838     -3.6393553018569946e-01
    z[5,3,5]  R1839     -4.2408636212348938e-01
    z[5,3,5]  R1840     -1.2743981555104256e-02
    z[5,3,5]  R1841     -1.8517075479030609e-01
    z[5,3,5]  R1842     -3.0390882492065430e-01
    z[5,3,5]  R1843     -2.0238092541694641e-01
    z[5,3,5]  R1844     1.9782733917236328e-01
    z[5,3,5]  R1845     -9.8644390702247620e-02
    z[5,3,5]  R1846     -0.148346409201622
    z[5,3,5]  R1847     -4.6158552169799805e-01
    z[5,3,5]  R1848     -2.9842260479927063e-01
    z[5,3,5]  R1849     -3.4983307123184204e-01
    z[5,3,5]  R1850     -0.377279132604599
    z[5,3,5]  R1851     3.8751029968261719e-01
    z[5,3,5]  R1852     2.0157396793365479e-02
    z[5,3,5]  R1853     -3.3282953500747681e-01
    z[5,3,5]  R1854     5.0642937421798706e-01
    z[5,3,5]  R1855     -4.5824404805898666e-02
    z[5,3,5]  R1856     -6.2417805194854736e-01
    z[5,3,5]  R1857     -0.0754033774137497
    z[5,3,5]  R1858     -6.4436845481395721e-02
    z[5,3,5]  R1859     1.9234506785869598e-01
    z[5,3,5]  R1860     2.7806267142295837e-01
    z[5,3,5]  R1861     -2.3896206170320511e-02
    z[5,3,5]  R1862     -4.7335988283157349e-01
    z[5,3,5]  R1863     6.2632042169570923e-01
    z[5,3,5]  R1864     1.9467703998088837e-01
    z[5,3,5]  R1865     -4.9738940596580505e-01
    z[5,3,5]  R1866     -2.1414436399936676e-02
    z[5,3,5]  R1867     3.2057842612266541e-01
    z[5,3,5]  R1868     3.8099128007888794e-01
    z[5,3,5]  R1869     -6.7592531442642212e-01
    z[5,3,5]  R1870     5.3517264127731323e-01
    z[5,3,5]  R1871     2.1830736100673676e-01
    z[5,3,5]  R1872     -6.1397127807140350e-02
    z[5,3,5]  R1873     -2.8867498040199280e-01
    z[5,3,5]  R1874     -4.4239038228988647e-01
    z[5,3,5]  R1875     -2.9919949173927307e-01
    z[5,3,5]  R1876     -1.6329869627952576e-01
    z[5,3,5]  R1877     -5.9690177440643311e-01
    z[5,3,5]  R1878     1.0459543205797672e-02
    z[5,3,5]  R1879     3.1147959828376770e-01
    z[5,3,5]  R1880     9.0109594166278839e-02
    z[5,3,5]  R1881     3.6661437153816223e-01
    z[5,3,5]  R1882     -4.7735314816236496e-02
    z[5,3,5]  R1883     -2.3951521515846252e-01
    z[5,3,5]  R1884     -7.1482270956039429e-02
    z[5,3,5]  R1885     1.4146538078784943e-01
    z[5,3,5]  R1886     4.1564801335334778e-01
    z[5,3,5]  R1887     5.2571278065443039e-02
    z[5,3,5]  R1888     -6.4349097013473511e-01
    z[5,3,5]  R1889     -1.4879024028778076e-01
    z[5,3,5]  R1890     -4.0760420262813568e-02
    z[5,3,5]  R1891     2.3870344460010529e-01
    z[5,3,5]  R1892     -9.2644453048706055e-02
    z[5,3,5]  R1893     -1.2771388888359070e-01
    z[5,3,5]  R1894     1.2331591546535492e-01
    z[5,3,5]  R1895     -1.2022284418344498e-01
    z[5,3,5]  R1896     0.382844477891922
    z[5,3,5]  R1897     -9.3877725303173065e-02
    z[5,3,5]  R1898     -8.1795983016490936e-02
    z[5,3,5]  R1899     1.7924067378044128e-01
    z[5,3,5]  R1900     1.5473881363868713e-01
    z[5,3,5]  R1901     1.0495068877935410e-01
    z[5,3,5]  R1902     -3.1709831953048706e-01
    z[5,3,5]  R1903     -2.2529639303684235e-01
    z[5,3,5]  R1904     -7.3899462819099426e-02
    z[5,3,5]  R1905     -5.0889093428850174e-02
    z[5,3,5]  R1906     -7.8351572155952454e-02
    z[5,3,5]  R1907     -2.1108351647853851e-01
    z[5,3,5]  R1908     4.1301745176315308e-01
    z[5,3,5]  R1909     6.8182200193405151e-01
    z[5,3,5]  R1910     7.0880597829818726e-01
    z[5,3,5]  R1911     6.1938923597335815e-01
    z[5,3,5]  R1912     2.0538989454507828e-02
    z[5,3,5]  R1913     4.3539252877235413e-01
    z[5,3,5]  R1914     -2.6755759119987488e-01
    z[5,3,5]  R1915     1.9438152015209198e-01
    z[5,3,5]  R1916     -1.2422193586826324e-01
    z[5,3,5]  R1917     -1.1561634950339794e-02
    z[5,3,5]  R1918     -5.9379488229751587e-01
    z[5,3,5]  R1919     -1.2538772821426392e-01
    z[5,3,5]  R1920     -5.6181255728006363e-02
    z[5,3,5]  R1921     -2.4589703977108002e-01
    z[5,3,5]  R1922     -1.7353695631027222e-01
    z[5,3,5]  R1923     -2.8736993670463562e-01
    z[5,3,5]  R1924     -5.9584236145019531e-01
    z[5,3,5]  R1925     -2.9813820123672485e-01
    z[5,3,5]  R1926     2.0180438458919525e-01
    z[5,3,5]  R1927     4.1949892044067383e-01
    z[5,3,5]  R1928     9.2779628932476044e-02
    z[5,3,5]  R1929     -1.7605556547641754e-01
    z[5,3,5]  R1930     5.8603119105100632e-02
    z[5,3,5]  R1931     -8.5768803954124451e-02
    z[5,3,5]  R1932     -3.4668779373168945e-01
    z[5,3,5]  R1933     -1.3270154595375061e-01
    z[5,3,6]  R35       1
    z[5,3,6]  R53       -1
    z[5,3,6]  R1812     -1
    z[5,3,6]  R1813     1
    z[5,3,6]  R1814     -1.4731016755104065e-01
    z[5,3,6]  R1815     -6.6391073167324066e-02
    z[5,3,6]  R1816     2.0331348478794098e-01
    z[5,3,6]  R1817     -8.5120923817157745e-02
    z[5,3,6]  R1818     -1.0575703531503677e-01
    z[5,3,6]  R1819     -0.09307861328125
    z[5,3,6]  R1820     2.4711626768112183e-01
    z[5,3,6]  R1821     2.0318250358104706e-01
    z[5,3,6]  R1822     -3.3131068944931030e-01
    z[5,3,6]  R1823     -6.8389378488063812e-02
    z[5,3,6]  R1824     3.6516536027193069e-02
    z[5,3,6]  R1825     0.0774056687951088
    z[5,3,6]  R1826     -1.4727701246738434e-01
    z[5,3,6]  R1827     -1.5174393355846405e-01
    z[5,3,6]  R1828     -4.7539597749710083e-01
    z[5,3,6]  R1829     2.2532801330089569e-01
    z[5,3,6]  R1830     8.6684837937355042e-02
    z[5,3,6]  R1831     3.5144168138504028e-01
    z[5,3,6]  R1832     -1.7987428605556488e-01
    z[5,3,6]  R1833     3.6844724416732788e-01
    z[5,3,6]  R1834     0.677962064743042
    z[5,3,6]  R1835     -5.9153027832508087e-02
    z[5,3,6]  R1836     0.919495165348053
    z[5,3,6]  R1837     0.814403235912323
    z[5,3,6]  R1838     -1.8726487457752228e-01
    z[5,3,6]  R1839     3.9939272403717041e-01
    z[5,3,6]  R1840     2.7433177828788757e-01
    z[5,3,6]  R1841     -3.4588745236396790e-01
    z[5,3,6]  R1842     5.4620647430419922e-01
    z[5,3,6]  R1843     -1.9505728781223297e-01
    z[5,3,6]  R1844     2.5381517410278320e-01
    z[5,3,6]  R1845     3.0845694709569216e-03
    z[5,3,6]  R1846     -0.074495330452919
    z[5,3,6]  R1847     -2.7877295017242432e-01
    z[5,3,6]  R1848     -3.9746654033660889e-01
    z[5,3,6]  R1849     -5.3462157957255840e-03
    z[5,3,6]  R1850     4.3215584754943848e-01
    z[5,3,6]  R1851     -8.3619892597198486e-02
    z[5,3,6]  R1852     -2.7281185984611511e-01
    z[5,3,6]  R1853     -3.6632496118545532e-01
    z[5,3,6]  R1854     1.1175787448883057e-01
    z[5,3,6]  R1855     -8.6105622351169586e-02
    z[5,3,6]  R1856     -3.7456639111042023e-02
    z[5,3,6]  R1857     3.1134110689163208e-01
    z[5,3,6]  R1858     2.9562366008758545e-01
    z[5,3,6]  R1859     -8.3799540996551514e-02
    z[5,3,6]  R1860     -2.8917360305786133e-01
    z[5,3,6]  R1861     -3.4714111685752869e-01
    z[5,3,6]  R1862     1.2736445665359497e-01
    z[5,3,6]  R1863     -6.8762958049774170e-02
    z[5,3,6]  R1864     -1.6143139451742172e-02
    z[5,3,6]  R1865     2.1712635457515717e-01
    z[5,3,6]  R1866     1.1941968649625778e-01
    z[5,3,6]  R1867     2.5954738259315491e-01
    z[5,3,6]  R1868     -6.4274176955223083e-02
    z[5,3,6]  R1869     -3.3101800829172134e-02
    z[5,3,6]  R1870     -1.3286098837852478e-01
    z[5,3,6]  R1871     -1.1625555902719498e-01
    z[5,3,6]  R1872     -3.4496295452117920e-01
    z[5,3,6]  R1873     2.6258850097656250e-01
    z[5,3,6]  R1874     1.3789756596088409e-01
    z[5,3,6]  R1875     5.6865904480218887e-02
    z[5,3,6]  R1876     -2.2241444885730743e-01
    z[5,3,6]  R1877     0.195271834731102
    z[5,3,6]  R1878     -3.7824764847755432e-01
    z[5,3,6]  R1879     3.0041828751564026e-01
    z[5,3,6]  R1880     -3.9020174741744995e-01
    z[5,3,6]  R1881     -4.0451325476169586e-02
    z[5,3,6]  R1882     2.4714720249176025e-01
    z[5,3,6]  R1883     -7.1370363235473633e-01
    z[5,3,6]  R1884     6.2678046524524689e-02
    z[5,3,6]  R1885     3.5645064711570740e-01
    z[5,3,6]  R1886     -3.4316653013229370e-01
    z[5,3,6]  R1887     -3.2001107465475798e-03
    z[5,3,6]  R1888     -3.3547705411911011e-01
    z[5,3,6]  R1889     2.5705745816230774e-01
    z[5,3,6]  R1890     1.5021668374538422e-01
    z[5,3,6]  R1891     -3.2108661532402039e-01
    z[5,3,6]  R1892     1.7515990138053894e-01
    z[5,3,6]  R1893     -6.1666302382946014e-02
    z[5,3,6]  R1894     -8.5834875702857971e-02
    z[5,3,6]  R1895     2.0520697534084320e-01
    z[5,3,6]  R1896     -4.5186918228864670e-02
    z[5,3,6]  R1897     2.4321815371513367e-01
    z[5,3,6]  R1898     -1.5244592726230621e-01
    z[5,3,6]  R1899     -2.7870634198188782e-01
    z[5,3,6]  R1900     1.2779383361339569e-01
    z[5,3,6]  R1901     -3.3953779935836792e-01
    z[5,3,6]  R1902     -0.440801203250885
    z[5,3,6]  R1903     -3.7467747926712036e-02
    z[5,3,6]  R1904     2.3194292187690735e-01
    z[5,3,6]  R1905     -5.6289398670196533e-01
    z[5,3,6]  R1906     4.6154615283012390e-01
    z[5,3,6]  R1907     -6.4207464456558228e-01
    z[5,3,6]  R1908     3.8247132301330566e-01
    z[5,3,6]  R1909     -0.119338259100914
    z[5,3,6]  R1910     0.0787559524178505
    z[5,3,6]  R1911     2.4156802892684937e-01
    z[5,3,6]  R1912     -1.2522128224372864e-01
    z[5,3,6]  R1913     -5.8474189043045044e-01
    z[5,3,6]  R1914     1.7861206829547882e-01
    z[5,3,6]  R1915     3.3109375834465027e-01
    z[5,3,6]  R1916     1.8474312126636505e-01
    z[5,3,6]  R1917     -1.3475050032138824e-01
    z[5,3,6]  R1918     2.1845014393329620e-01
    z[5,3,6]  R1919     -2.4525426328182220e-01
    z[5,3,6]  R1920     -5.0956577062606812e-01
    z[5,3,6]  R1921     4.5300893485546112e-02
    z[5,3,6]  R1922     2.8403285890817642e-02
    z[5,3,6]  R1923     1.0566082596778870e-01
    z[5,3,6]  R1924     3.4488376975059509e-01
    z[5,3,6]  R1925     -3.0400553345680237e-01
    z[5,3,6]  R1926     -5.7618337869644165e-01
    z[5,3,6]  R1927     -0.369929701089859
    z[5,3,6]  R1928     -7.0126913487911224e-02
    z[5,3,6]  R1929     -1.6045859456062317e-01
    z[5,3,6]  R1930     -1.5351210720837116e-02
    z[5,3,6]  R1931     -1.0269220918416977e-02
    z[5,3,6]  R1932     -1.2269319593906403e-01
    z[5,3,6]  R1933     -2.0770236849784851e-01
    z[3,6,0]  R29       -1
    z[3,6,0]  R56       1
    z[3,6,0]  R1934     -1
    z[3,6,0]  R1935     1
    z[3,6,0]  R1948     1.2302646785974503e-01
    z[3,6,0]  R1949     3.9639464020729065e-01
    z[3,6,0]  R1950     -4.4419410824775696e-01
    z[3,6,0]  R1951     -3.4195578098297119e-01
    z[3,6,0]  R1952     -4.2483130097389221e-01
    z[3,6,0]  R1953     -4.7725465893745422e-01
    z[3,6,0]  R1954     -1.1169387027621269e-02
    z[3,6,0]  R1955     2.6945248246192932e-01
    z[3,6,0]  R1956     1.1034189164638519e-01
    z[3,6,0]  R1957     -1.4272119104862213e-01
    z[3,6,0]  R1958     -6.6784307360649109e-02
    z[3,6,0]  R1959     4.2604845762252808e-01
    z[3,6,0]  R1960     3.7830349802970886e-01
    z[3,6,0]  R1961     4.3023020029067993e-01
    z[3,6,0]  R1962     4.3663305044174194e-01
    z[3,6,0]  R1963     -3.4835276007652283e-01
    z[3,6,0]  R1964     -3.6363103985786438e-01
    z[3,6,0]  R1965     7.8226590156555176e-01
    z[3,6,0]  R1966     6.4075648784637451e-01
    z[3,6,0]  R1967     6.8611931800842285e-01
    z[3,6,0]  R1968     -1.6029927134513855e-01
    z[3,6,0]  R1969     4.0806140750646591e-02
    z[3,6,0]  R1970     -2.8304606676101685e-01
    z[3,6,0]  R1971     -5.8769184350967407e-01
    z[3,6,0]  R1972     6.7144066095352173e-01
    z[3,6,0]  R1973     0.865686297416687
    z[3,6,0]  R1974     6.8237137794494629e-01
    z[3,6,0]  R1975     8.3832150697708130e-01
    z[3,6,0]  R1976     8.1652325391769409e-01
    z[3,6,0]  R1977     6.7006939649581909e-01
    z[3,6,0]  R1978     -1.1970573104918003e-03
    z[3,6,0]  R1979     3.9835777878761292e-01
    z[3,6,0]  R1980     -3.0083894729614258e-01
    z[3,6,0]  R1981     -3.6715969443321228e-01
    z[3,6,0]  R1982     -4.1392204165458679e-01
    z[3,6,0]  R1983     4.1932117938995361e-01
    z[3,6,0]  R1984     -1.1834224313497543e-01
    z[3,6,0]  R1985     -3.0072543025016785e-01
    z[3,6,0]  R1986     -7.6365791261196136e-02
    z[3,6,0]  R1987     -1.2636126577854156e-01
    z[3,6,0]  R1988     -8.2340574264526367e-01
    z[3,6,0]  R1989     -1.9203135371208191e-01
    z[3,6,0]  R1990     9.6498638391494751e-02
    z[3,6,0]  R1991     -3.2801163196563721e-01
    z[3,6,0]  R1992     -5.0426584482192993e-01
    z[3,6,0]  R1993     3.8767620921134949e-01
    z[3,6,0]  R1994     3.7921980023384094e-01
    z[3,6,0]  R1995     3.0902782082557678e-01
    z[3,6,0]  R1996     2.1062324941158295e-01
    z[3,6,0]  R1997     1.6345719993114471e-01
    z[3,6,0]  R1998     -7.6807297766208649e-02
    z[3,6,0]  R1999     -5.3572410345077515e-01
    z[3,6,0]  R2000     0.298926442861557
    z[3,6,0]  R2001     1.9086718559265137e-01
    z[3,6,0]  R2002     3.7786403298377991e-01
    z[3,6,0]  R2003     -5.9229653328657150e-02
    z[3,6,0]  R2004     0.685613214969635
    z[3,6,1]  R30       -1
    z[3,6,1]  R57       1
    z[3,6,1]  R1936     -1
    z[3,6,1]  R1937     1
    z[3,6,1]  R1948     3.5636723041534424e-01
    z[3,6,1]  R1949     1.4859323203563690e-01
    z[3,6,1]  R1950     4.9766483902931213e-01
    z[3,6,1]  R1951     -2.0866273343563080e-01
    z[3,6,1]  R1952     0.191564679145813
    z[3,6,1]  R1953     1.2885032594203949e-01
    z[3,6,1]  R1954     -1.8866440653800964e-01
    z[3,6,1]  R1955     -2.2225941717624664e-01
    z[3,6,1]  R1956     -2.5352746248245239e-01
    z[3,6,1]  R1957     -1.8692450225353241e-01
    z[3,6,1]  R1958     -9.0078812837600708e-01
    z[3,6,1]  R1959     -6.3910853862762451e-01
    z[3,6,1]  R1960     -8.7422186136245728e-01
    z[3,6,1]  R1961     -8.1641918420791626e-01
    z[3,6,1]  R1962     2.1426524221897125e-01
    z[3,6,1]  R1963     4.7654518485069275e-01
    z[3,6,1]  R1964     3.5593998432159424e-01
    z[3,6,1]  R1965     -1.8441970646381378e-01
    z[3,6,1]  R1966     -2.9422175884246826e-01
    z[3,6,1]  R1967     -1.8421749770641327e-01
    z[3,6,1]  R1968     0.215898334980011
    z[3,6,1]  R1969     7.7527087926864624e-01
    z[3,6,1]  R1970     6.9777315855026245e-01
    z[3,6,1]  R1971     -2.1259206533432007e-01
    z[3,6,1]  R1972     -2.4626728892326355e-01
    z[3,6,1]  R1973     -1.0118196159601212e-01
    z[3,6,1]  R1974     -1.8070322275161743e-01
    z[3,6,1]  R1975     -7.5816445052623749e-02
    z[3,6,1]  R1976     -1.8228402733802795e-01
    z[3,6,1]  R1977     -5.8117534965276718e-02
    z[3,6,1]  R1978     -2.2033055126667023e-01
    z[3,6,1]  R1979     4.5959314703941345e-01
    z[3,6,1]  R1980     1.1390078812837601e-01
    z[3,6,1]  R1981     2.0924666523933411e-01
    z[3,6,1]  R1982     4.6872356534004211e-01
    z[3,6,1]  R1983     6.3018488883972168e-01
    z[3,6,1]  R1984     8.3565098047256470e-01
    z[3,6,1]  R1985     6.2042653560638428e-01
    z[3,6,1]  R1986     5.0904005765914917e-01
    z[3,6,1]  R1987     -3.0407229065895081e-01
    z[3,6,1]  R1988     9.4793796539306641e-02
    z[3,6,1]  R1989     2.8459683060646057e-01
    z[3,6,1]  R1990     -9.0831464529037476e-01
    z[3,6,1]  R1991     -5.9445196390151978e-01
    z[3,6,1]  R1992     -6.4131164550781250e-01
    z[3,6,1]  R1993     -6.1285120248794556e-01
    z[3,6,1]  R1994     -2.4251176416873932e-01
    z[3,6,1]  R1995     -3.5514634847640991e-01
    z[3,6,1]  R1996     -5.4501199722290039e-01
    z[3,6,1]  R1997     -4.6743515133857727e-01
    z[3,6,1]  R1998     -6.1531532555818558e-02
    z[3,6,1]  R1999     1.4721401967108250e-02
    z[3,6,1]  R2000     -2.9983457922935486e-01
    z[3,6,1]  R2001     -0.711582601070404
    z[3,6,1]  R2002     -1.3799284398555756e-01
    z[3,6,1]  R2003     -2.6491332054138184e-01
    z[3,6,1]  R2004     -3.3857762813568115e-01
    z[3,6,2]  R31       -1
    z[3,6,2]  R58       1
    z[3,6,2]  R1938     -1
    z[3,6,2]  R1939     1
    z[3,6,2]  R1948     2.5317168235778809e-01
    z[3,6,2]  R1949     4.4305637478828430e-01
    z[3,6,2]  R1950     -2.3154832422733307e-01
    z[3,6,2]  R1951     -4.9875292181968689e-01
    z[3,6,2]  R1952     -4.9246424436569214e-01
    z[3,6,2]  R1953     -0.179381862282753
    z[3,6,2]  R1954     0.50576251745224
    z[3,6,2]  R1955     4.9431779980659485e-01
    z[3,6,2]  R1956     5.8363676071166992e-01
    z[3,6,2]  R1957     3.7546235322952271e-01
    z[3,6,2]  R1958     -5.5164024233818054e-02
    z[3,6,2]  R1959     4.6470394730567932e-01
    z[3,6,2]  R1960     6.0612101107835770e-02
    z[3,6,2]  R1961     1.7800678312778473e-01
    z[3,6,2]  R1962     -2.4674880504608154e-01
    z[3,6,2]  R1963     1.0945523530244827e-01
    z[3,6,2]  R1964     2.0087005198001862e-01
    z[3,6,2]  R1965     -4.0304175019264221e-01
    z[3,6,2]  R1966     -4.7503703832626343e-01
    z[3,6,2]  R1967     -2.3438222706317902e-01
    z[3,6,2]  R1968     -4.0537121891975403e-01
    z[3,6,2]  R1969     -2.3900006711483002e-01
    z[3,6,2]  R1970     3.1247567385435104e-02
    z[3,6,2]  R1971     5.2226681262254715e-02
    z[3,6,2]  R1972     -3.5896146297454834e-01
    z[3,6,2]  R1973     -1.0460843890905380e-01
    z[3,6,2]  R1974     -3.1134307384490967e-01
    z[3,6,2]  R1975     -1.2013496458530426e-01
    z[3,6,2]  R1976     -2.0758289098739624e-01
    z[3,6,2]  R1977     -2.4450413882732391e-01
    z[3,6,2]  R1978     -1.5700127184391022e-01
    z[3,6,2]  R1979     4.0909403562545776e-01
    z[3,6,2]  R1980     -6.0636216402053833e-01
    z[3,6,2]  R1981     -4.0500751137733459e-01
    z[3,6,2]  R1982     1.3352312147617340e-02
    z[3,6,2]  R1983     -7.7508250251412392e-03
    z[3,6,2]  R1984     -5.8390375226736069e-02
    z[3,6,2]  R1985     3.7913840264081955e-02
    z[3,6,2]  R1986     2.6878255605697632e-01
    z[3,6,2]  R1987     2.1994440257549286e-01
    z[3,6,2]  R1988     5.1407706737518311e-01
    z[3,6,2]  R1989     -0.190054789185524
    z[3,6,2]  R1990     8.1887438893318176e-02
    z[3,6,2]  R1991     1.0052428394556046e-01
    z[3,6,2]  R1992     -2.0116455852985382e-01
    z[3,6,2]  R1993     5.0907045602798462e-01
    z[3,6,2]  R1994     6.6290384531021118e-01
    z[3,6,2]  R1995     4.4923242926597595e-01
    z[3,6,2]  R1996     4.0708842873573303e-01
    z[3,6,2]  R1997     5.3370285034179688e-01
    z[3,6,2]  R1998     -4.0093046426773071e-01
    z[3,6,2]  R1999     -2.1145179867744446e-01
    z[3,6,2]  R2000     -8.2104299217462540e-03
    z[3,6,2]  R2001     3.5090631246566772e-01
    z[3,6,2]  R2002     4.9911147356033325e-01
    z[3,6,2]  R2003     2.3015265166759491e-01
    z[3,6,2]  R2004     -5.2543884515762329e-01
    z[3,6,3]  R32       -1
    z[3,6,3]  R59       1
    z[3,6,3]  R1940     -1
    z[3,6,3]  R1941     1
    z[3,6,3]  R1948     4.7430381178855896e-02
    z[3,6,3]  R1949     2.8876092284917831e-02
    z[3,6,3]  R1950     5.0100311636924744e-02
    z[3,6,3]  R1951     -2.7720436453819275e-01
    z[3,6,3]  R1952     -4.6595868468284607e-01
    z[3,6,3]  R1953     -5.5398764088749886e-03
    z[3,6,3]  R1954     4.4093075394630432e-01
    z[3,6,3]  R1955     2.7040678262710571e-01
    z[3,6,3]  R1956     7.3127579689025879e-01
    z[3,6,3]  R1957     4.1562882065773010e-01
    z[3,6,3]  R1958     1.2848268449306488e-01
    z[3,6,3]  R1959     2.1257027983665466e-01
    z[3,6,3]  R1960     -1.9541363418102264e-01
    z[3,6,3]  R1961     -1.9743348658084869e-01
    z[3,6,3]  R1962     -5.4969519376754761e-01
    z[3,6,3]  R1963     6.3999301195144653e-01
    z[3,6,3]  R1964     6.6140717267990112e-01
    z[3,6,3]  R1965     3.5298663377761841e-01
    z[3,6,3]  R1966     4.4309777021408081e-01
    z[3,6,3]  R1967     4.6353161334991455e-01
    z[3,6,3]  R1968     -3.0771313235163689e-02
    z[3,6,3]  R1969     -2.6654061675071716e-01
    z[3,6,3]  R1970     2.0046578347682953e-01
    z[3,6,3]  R1971     4.1446754336357117e-01
    z[3,6,3]  R1972     5.8468794822692871e-01
    z[3,6,3]  R1973     3.7966915965080261e-01
    z[3,6,3]  R1974     5.9524923563003540e-01
    z[3,6,3]  R1975     4.0818822383880615e-01
    z[3,6,3]  R1976     3.3546721935272217e-01
    z[3,6,3]  R1977     6.5078121423721313e-01
    z[3,6,3]  R1978     1.8152070045471191e-01
    z[3,6,3]  R1979     3.0024429783225060e-02
    z[3,6,3]  R1980     -6.7329630255699158e-02
    z[3,6,3]  R1981     1.4320933818817139e-01
    z[3,6,3]  R1982     -5.0282761454582214e-02
    z[3,6,3]  R1983     5.4868827573955059e-03
    z[3,6,3]  R1984     -7.1596577763557434e-02
    z[3,6,3]  R1985     6.7600446939468384e-01
    z[3,6,3]  R1986     0.30000039935112
    z[3,6,3]  R1987     0.794006884098053
    z[3,6,3]  R1988     1.1935956031084061e-01
    z[3,6,3]  R1989     -6.9941782951354980e-01
    z[3,6,3]  R1990     0.301226943731308
    z[3,6,3]  R1991     3.8864842057228088e-01
    z[3,6,3]  R1992     2.3955328762531281e-01
    z[3,6,3]  R1993     2.5290060043334961e-01
    z[3,6,3]  R1994     7.8742668032646179e-02
    z[3,6,3]  R1995     4.4505367986857891e-03
    z[3,6,3]  R1996     -4.0808707475662231e-02
    z[3,6,3]  R1997     3.4651394933462143e-02
    z[3,6,3]  R1998     -4.1442832350730896e-01
    z[3,6,3]  R1999     -4.0571314096450806e-01
    z[3,6,3]  R2000     -7.3294615745544434e-01
    z[3,6,3]  R2001     2.0180614292621613e-01
    z[3,6,3]  R2002     -3.9547482132911682e-01
    z[3,6,3]  R2003     -3.7801361083984375e-01
    z[3,6,3]  R2004     -9.5134507864713669e-03
    z[3,6,4]  R33       -1
    z[3,6,4]  R60       1
    z[3,6,4]  R1942     -1
    z[3,6,4]  R1943     1
    z[3,6,4]  R1948     0.85572350025177
    z[3,6,4]  R1949     5.5156075954437256e-01
    z[3,6,4]  R1950     -5.2889782190322876e-01
    z[3,6,4]  R1951     2.3898379504680634e-01
    z[3,6,4]  R1952     0.0794677734375
    z[3,6,4]  R1953     4.9426129460334778e-01
    z[3,6,4]  R1954     -7.3871716856956482e-02
    z[3,6,4]  R1955     3.4427908062934875e-01
    z[3,6,4]  R1956     -1.7902587354183197e-01
    z[3,6,4]  R1957     -3.1540572643280029e-01
    z[3,6,4]  R1958     -2.4714456498622894e-01
    z[3,6,4]  R1959     -3.8467753678560257e-02
    z[3,6,4]  R1960     -3.4658830612897873e-02
    z[3,6,4]  R1961     -2.4372906982898712e-01
    z[3,6,4]  R1962     8.9103868231177330e-03
    z[3,6,4]  R1963     3.9257079362869263e-01
    z[3,6,4]  R1964     -2.1384319290518761e-02
    z[3,6,4]  R1965     6.7004904150962830e-02
    z[3,6,4]  R1966     2.2348852455615997e-01
    z[3,6,4]  R1967     3.6299028992652893e-01
    z[3,6,4]  R1968     5.3707206249237061e-01
    z[3,6,4]  R1969     2.9634320735931396e-01
    z[3,6,4]  R1970     1.3828288018703461e-01
    z[3,6,4]  R1971     -3.4940603375434875e-01
    z[3,6,4]  R1972     -6.5426945686340332e-02
    z[3,6,4]  R1973     -1.6886492073535919e-01
    z[3,6,4]  R1974     2.1630893647670746e-01
    z[3,6,4]  R1975     3.2086926698684692e-01
    z[3,6,4]  R1976     9.5850922167301178e-02
    z[3,6,4]  R1977     5.9840731322765350e-02
    z[3,6,4]  R1978     9.3230515718460083e-01
    z[3,6,4]  R1979     6.4843553304672241e-01
    z[3,6,4]  R1980     1.8940374255180359e-01
    z[3,6,4]  R1981     6.5703099966049194e-01
    z[3,6,4]  R1982     1.8320725858211517e-01
    z[3,6,4]  R1983     0.368007093667984
    z[3,6,4]  R1984     -3.9148527383804321e-01
    z[3,6,4]  R1985     -0.251006543636322
    z[3,6,4]  R1986     -3.4782004356384277e-01
    z[3,6,4]  R1987     -2.3502174019813538e-01
    z[3,6,4]  R1988     -1.3876289129257202e-01
    z[3,6,4]  R1989     -2.9398933053016663e-01
    z[3,6,4]  R1990     -2.4249014258384705e-01
    z[3,6,4]  R1991     -5.0091665983200073e-01
    z[3,6,4]  R1992     -4.2328283190727234e-01
    z[3,6,4]  R1993     6.4704000949859619e-02
    z[3,6,4]  R1994     -5.7221513986587524e-01
    z[3,6,4]  R1995     -5.2367347478866577e-01
    z[3,6,4]  R1996     -1.4771215617656708e-01
    z[3,6,4]  R1997     -3.8605967164039612e-01
    z[3,6,4]  R1998     4.0591907501220703e-01
    z[3,6,4]  R1999     -5.4308164119720459e-01
    z[3,6,4]  R2000     0.496865838766098
    z[3,6,4]  R2001     3.9167352952063084e-03
    z[3,6,4]  R2002     -5.3028100728988647e-01
    z[3,6,4]  R2003     -4.0601128339767456e-01
    z[3,6,4]  R2004     -2.8760954737663269e-01
    z[3,6,5]  R34       -1
    z[3,6,5]  R61       1
    z[3,6,5]  R1944     -1
    z[3,6,5]  R1945     1
    z[3,6,5]  R1948     -7.3899462819099426e-02
    z[3,6,5]  R1949     -5.0889093428850174e-02
    z[3,6,5]  R1950     -7.8351572155952454e-02
    z[3,6,5]  R1951     -2.1108351647853851e-01
    z[3,6,5]  R1952     4.1301745176315308e-01
    z[3,6,5]  R1953     6.8182200193405151e-01
    z[3,6,5]  R1954     7.0880597829818726e-01
    z[3,6,5]  R1955     6.1938923597335815e-01
    z[3,6,5]  R1956     2.0538989454507828e-02
    z[3,6,5]  R1957     4.3539252877235413e-01
    z[3,6,5]  R1958     -2.6755759119987488e-01
    z[3,6,5]  R1959     1.9438152015209198e-01
    z[3,6,5]  R1960     -1.2422193586826324e-01
    z[3,6,5]  R1961     -1.1561634950339794e-02
    z[3,6,5]  R1962     -5.9379488229751587e-01
    z[3,6,5]  R1963     -1.2538772821426392e-01
    z[3,6,5]  R1964     -5.6181255728006363e-02
    z[3,6,5]  R1965     -2.4589703977108002e-01
    z[3,6,5]  R1966     -1.7353695631027222e-01
    z[3,6,5]  R1967     -2.8736993670463562e-01
    z[3,6,5]  R1968     -5.9584236145019531e-01
    z[3,6,5]  R1969     -2.9813820123672485e-01
    z[3,6,5]  R1970     2.0180438458919525e-01
    z[3,6,5]  R1971     4.1949892044067383e-01
    z[3,6,5]  R1972     9.2779628932476044e-02
    z[3,6,5]  R1973     -1.7605556547641754e-01
    z[3,6,5]  R1974     5.8603119105100632e-02
    z[3,6,5]  R1975     -8.5768803954124451e-02
    z[3,6,5]  R1976     -3.4668779373168945e-01
    z[3,6,5]  R1977     -1.3270154595375061e-01
    z[3,6,5]  R1978     -1.2142031639814377e-01
    z[3,6,5]  R1979     -7.2115555405616760e-02
    z[3,6,5]  R1980     5.1024538278579712e-01
    z[3,6,5]  R1981     3.6064037680625916e-01
    z[3,6,5]  R1982     -4.1838459670543671e-02
    z[3,6,5]  R1983     -7.2465568780899048e-02
    z[3,6,5]  R1984     -2.2915486246347427e-02
    z[3,6,5]  R1985     -1.7315704608336091e-03
    z[3,6,5]  R1986     6.7093491554260254e-01
    z[3,6,5]  R1987     3.9473345875740051e-01
    z[3,6,5]  R1988     3.2030217349529266e-02
    z[3,6,5]  R1989     -0.512298047542572
    z[3,6,5]  R1990     -3.6583945620805025e-03
    z[3,6,5]  R1991     -8.8016480207443237e-02
    z[3,6,5]  R1992     -1.2372436374425888e-01
    z[3,6,5]  R1993     8.2141578197479248e-02
    z[3,6,5]  R1994     9.2413406819105148e-03
    z[3,6,5]  R1995     8.6203746497631073e-02
    z[3,6,5]  R1996     0.583867073059082
    z[3,6,5]  R1997     3.3442100882530212e-01
    z[3,6,5]  R1998     -6.9211864471435547e-01
    z[3,6,5]  R1999     -4.0671899914741516e-01
    z[3,6,5]  R2000     1.3982349634170532e-01
    z[3,6,5]  R2001     -3.4050858020782471e-01
    z[3,6,5]  R2002     3.8897618651390076e-01
    z[3,6,5]  R2003     6.8253362178802490e-01
    z[3,6,5]  R2004     1.4928117394447327e-01
    z[3,6,6]  R35       -1
    z[3,6,6]  R62       1
    z[3,6,6]  R1946     -1
    z[3,6,6]  R1947     1
    z[3,6,6]  R1948     2.3194292187690735e-01
    z[3,6,6]  R1949     -5.6289398670196533e-01
    z[3,6,6]  R1950     4.6154615283012390e-01
    z[3,6,6]  R1951     -6.4207464456558228e-01
    z[3,6,6]  R1952     3.8247132301330566e-01
    z[3,6,6]  R1953     -0.119338259100914
    z[3,6,6]  R1954     0.0787559524178505
    z[3,6,6]  R1955     2.4156802892684937e-01
    z[3,6,6]  R1956     -1.2522128224372864e-01
    z[3,6,6]  R1957     -5.8474189043045044e-01
    z[3,6,6]  R1958     1.7861206829547882e-01
    z[3,6,6]  R1959     3.3109375834465027e-01
    z[3,6,6]  R1960     1.8474312126636505e-01
    z[3,6,6]  R1961     -1.3475050032138824e-01
    z[3,6,6]  R1962     2.1845014393329620e-01
    z[3,6,6]  R1963     -2.4525426328182220e-01
    z[3,6,6]  R1964     -5.0956577062606812e-01
    z[3,6,6]  R1965     4.5300893485546112e-02
    z[3,6,6]  R1966     2.8403285890817642e-02
    z[3,6,6]  R1967     1.0566082596778870e-01
    z[3,6,6]  R1968     3.4488376975059509e-01
    z[3,6,6]  R1969     -3.0400553345680237e-01
    z[3,6,6]  R1970     -5.7618337869644165e-01
    z[3,6,6]  R1971     -0.369929701089859
    z[3,6,6]  R1972     -7.0126913487911224e-02
    z[3,6,6]  R1973     -1.6045859456062317e-01
    z[3,6,6]  R1974     -1.5351210720837116e-02
    z[3,6,6]  R1975     -1.0269220918416977e-02
    z[3,6,6]  R1976     -1.2269319593906403e-01
    z[3,6,6]  R1977     -2.0770236849784851e-01
    z[3,6,6]  R1978     -0.0995897725224495
    z[3,6,6]  R1979     1.9014886021614075e-01
    z[3,6,6]  R1980     4.7758764028549194e-01
    z[3,6,6]  R1981     -2.7407726645469666e-01
    z[3,6,6]  R1982     -0.755608856678009
    z[3,6,6]  R1983     5.3503835201263428e-01
    z[3,6,6]  R1984     3.5406398773193359e-01
    z[3,6,6]  R1985     -5.6641805917024612e-02
    z[3,6,6]  R1986     -4.0861517190933228e-02
    z[3,6,6]  R1987     4.1237942874431610e-02
    z[3,6,6]  R1988     1.1922285705804825e-01
    z[3,6,6]  R1989     0.0891263335943222
    z[3,6,6]  R1990     9.6925109624862671e-02
    z[3,6,6]  R1991     -3.4527987241744995e-01
    z[3,6,6]  R1992     -2.0519843697547913e-01
    z[3,6,6]  R1993     -0.374266117811203
    z[3,6,6]  R1994     -1.5563745796680450e-01
    z[3,6,6]  R1995     0.543026864528656
    z[3,6,6]  R1996     -3.5846036672592163e-01
    z[3,6,6]  R1997     -4.5592454075813293e-01
    z[3,6,6]  R1998     1.1840562522411346e-01
    z[3,6,6]  R1999     -2.0762926340103149e-01
    z[3,6,6]  R2000     -1.3053172826766968e-01
    z[3,6,6]  R2001     -4.2118576169013977e-01
    z[3,6,6]  R2002     1.2796354480087757e-02
    z[3,6,6]  R2003     -3.1583356857299805e-01
    z[3,6,6]  R2004     -0.184713214635849
    z[6,3,0]  R29       1
    z[6,3,0]  R56       -1
    z[6,3,0]  R2005     -1
    z[6,3,0]  R2006     1
    z[6,3,0]  R2019     -1.1970573104918003e-03
    z[6,3,0]  R2020     3.9835777878761292e-01
    z[6,3,0]  R2021     -3.0083894729614258e-01
    z[6,3,0]  R2022     -3.6715969443321228e-01
    z[6,3,0]  R2023     -4.1392204165458679e-01
    z[6,3,0]  R2024     4.1932117938995361e-01
    z[6,3,0]  R2025     -1.1834224313497543e-01
    z[6,3,0]  R2026     -3.0072543025016785e-01
    z[6,3,0]  R2027     -7.6365791261196136e-02
    z[6,3,0]  R2028     -1.2636126577854156e-01
    z[6,3,0]  R2029     -8.2340574264526367e-01
    z[6,3,0]  R2030     -1.9203135371208191e-01
    z[6,3,0]  R2031     9.6498638391494751e-02
    z[6,3,0]  R2032     -3.2801163196563721e-01
    z[6,3,0]  R2033     -5.0426584482192993e-01
    z[6,3,0]  R2034     3.8767620921134949e-01
    z[6,3,0]  R2035     3.7921980023384094e-01
    z[6,3,0]  R2036     3.0902782082557678e-01
    z[6,3,0]  R2037     2.1062324941158295e-01
    z[6,3,0]  R2038     1.6345719993114471e-01
    z[6,3,0]  R2039     -7.6807297766208649e-02
    z[6,3,0]  R2040     -5.3572410345077515e-01
    z[6,3,0]  R2041     0.298926442861557
    z[6,3,0]  R2042     1.9086718559265137e-01
    z[6,3,0]  R2043     3.7786403298377991e-01
    z[6,3,0]  R2044     -5.9229653328657150e-02
    z[6,3,0]  R2045     0.685613214969635
    z[6,3,0]  R2046     1.2302646785974503e-01
    z[6,3,0]  R2047     3.9639464020729065e-01
    z[6,3,0]  R2048     -4.4419410824775696e-01
    z[6,3,0]  R2049     -3.4195578098297119e-01
    z[6,3,0]  R2050     -4.2483130097389221e-01
    z[6,3,0]  R2051     -4.7725465893745422e-01
    z[6,3,0]  R2052     -1.1169387027621269e-02
    z[6,3,0]  R2053     2.6945248246192932e-01
    z[6,3,0]  R2054     1.1034189164638519e-01
    z[6,3,0]  R2055     -1.4272119104862213e-01
    z[6,3,0]  R2056     -6.6784307360649109e-02
    z[6,3,0]  R2057     4.2604845762252808e-01
    z[6,3,0]  R2058     3.7830349802970886e-01
    z[6,3,0]  R2059     4.3023020029067993e-01
    z[6,3,0]  R2060     4.3663305044174194e-01
    z[6,3,0]  R2061     -3.4835276007652283e-01
    z[6,3,0]  R2062     -3.6363103985786438e-01
    z[6,3,0]  R2063     7.8226590156555176e-01
    z[6,3,0]  R2064     6.4075648784637451e-01
    z[6,3,0]  R2065     6.8611931800842285e-01
    z[6,3,0]  R2066     -1.6029927134513855e-01
    z[6,3,0]  R2067     4.0806140750646591e-02
    z[6,3,0]  R2068     -2.8304606676101685e-01
    z[6,3,0]  R2069     -5.8769184350967407e-01
    z[6,3,0]  R2070     6.7144066095352173e-01
    z[6,3,0]  R2071     0.865686297416687
    z[6,3,0]  R2072     6.8237137794494629e-01
    z[6,3,0]  R2073     8.3832150697708130e-01
    z[6,3,0]  R2074     8.1652325391769409e-01
    z[6,3,0]  R2075     6.7006939649581909e-01
    z[6,3,1]  R30       1
    z[6,3,1]  R57       -1
    z[6,3,1]  R2007     -1
    z[6,3,1]  R2008     1
    z[6,3,1]  R2019     -2.2033055126667023e-01
    z[6,3,1]  R2020     4.5959314703941345e-01
    z[6,3,1]  R2021     1.1390078812837601e-01
    z[6,3,1]  R2022     2.0924666523933411e-01
    z[6,3,1]  R2023     4.6872356534004211e-01
    z[6,3,1]  R2024     6.3018488883972168e-01
    z[6,3,1]  R2025     8.3565098047256470e-01
    z[6,3,1]  R2026     6.2042653560638428e-01
    z[6,3,1]  R2027     5.0904005765914917e-01
    z[6,3,1]  R2028     -3.0407229065895081e-01
    z[6,3,1]  R2029     9.4793796539306641e-02
    z[6,3,1]  R2030     2.8459683060646057e-01
    z[6,3,1]  R2031     -9.0831464529037476e-01
    z[6,3,1]  R2032     -5.9445196390151978e-01
    z[6,3,1]  R2033     -6.4131164550781250e-01
    z[6,3,1]  R2034     -6.1285120248794556e-01
    z[6,3,1]  R2035     -2.4251176416873932e-01
    z[6,3,1]  R2036     -3.5514634847640991e-01
    z[6,3,1]  R2037     -5.4501199722290039e-01
    z[6,3,1]  R2038     -4.6743515133857727e-01
    z[6,3,1]  R2039     -6.1531532555818558e-02
    z[6,3,1]  R2040     1.4721401967108250e-02
    z[6,3,1]  R2041     -2.9983457922935486e-01
    z[6,3,1]  R2042     -0.711582601070404
    z[6,3,1]  R2043     -1.3799284398555756e-01
    z[6,3,1]  R2044     -2.6491332054138184e-01
    z[6,3,1]  R2045     -3.3857762813568115e-01
    z[6,3,1]  R2046     3.5636723041534424e-01
    z[6,3,1]  R2047     1.4859323203563690e-01
    z[6,3,1]  R2048     4.9766483902931213e-01
    z[6,3,1]  R2049     -2.0866273343563080e-01
    z[6,3,1]  R2050     0.191564679145813
    z[6,3,1]  R2051     1.2885032594203949e-01
    z[6,3,1]  R2052     -1.8866440653800964e-01
    z[6,3,1]  R2053     -2.2225941717624664e-01
    z[6,3,1]  R2054     -2.5352746248245239e-01
    z[6,3,1]  R2055     -1.8692450225353241e-01
    z[6,3,1]  R2056     -9.0078812837600708e-01
    z[6,3,1]  R2057     -6.3910853862762451e-01
    z[6,3,1]  R2058     -8.7422186136245728e-01
    z[6,3,1]  R2059     -8.1641918420791626e-01
    z[6,3,1]  R2060     2.1426524221897125e-01
    z[6,3,1]  R2061     4.7654518485069275e-01
    z[6,3,1]  R2062     3.5593998432159424e-01
    z[6,3,1]  R2063     -1.8441970646381378e-01
    z[6,3,1]  R2064     -2.9422175884246826e-01
    z[6,3,1]  R2065     -1.8421749770641327e-01
    z[6,3,1]  R2066     0.215898334980011
    z[6,3,1]  R2067     7.7527087926864624e-01
    z[6,3,1]  R2068     6.9777315855026245e-01
    z[6,3,1]  R2069     -2.1259206533432007e-01
    z[6,3,1]  R2070     -2.4626728892326355e-01
    z[6,3,1]  R2071     -1.0118196159601212e-01
    z[6,3,1]  R2072     -1.8070322275161743e-01
    z[6,3,1]  R2073     -7.5816445052623749e-02
    z[6,3,1]  R2074     -1.8228402733802795e-01
    z[6,3,1]  R2075     -5.8117534965276718e-02
    z[6,3,2]  R31       1
    z[6,3,2]  R58       -1
    z[6,3,2]  R2009     -1
    z[6,3,2]  R2010     1
    z[6,3,2]  R2019     -1.5700127184391022e-01
    z[6,3,2]  R2020     4.0909403562545776e-01
    z[6,3,2]  R2021     -6.0636216402053833e-01
    z[6,3,2]  R2022     -4.0500751137733459e-01
    z[6,3,2]  R2023     1.3352312147617340e-02
    z[6,3,2]  R2024     -7.7508250251412392e-03
    z[6,3,2]  R2025     -5.8390375226736069e-02
    z[6,3,2]  R2026     3.7913840264081955e-02
    z[6,3,2]  R2027     2.6878255605697632e-01
    z[6,3,2]  R2028     2.1994440257549286e-01
    z[6,3,2]  R2029     5.1407706737518311e-01
    z[6,3,2]  R2030     -0.190054789185524
    z[6,3,2]  R2031     8.1887438893318176e-02
    z[6,3,2]  R2032     1.0052428394556046e-01
    z[6,3,2]  R2033     -2.0116455852985382e-01
    z[6,3,2]  R2034     5.0907045602798462e-01
    z[6,3,2]  R2035     6.6290384531021118e-01
    z[6,3,2]  R2036     4.4923242926597595e-01
    z[6,3,2]  R2037     4.0708842873573303e-01
    z[6,3,2]  R2038     5.3370285034179688e-01
    z[6,3,2]  R2039     -4.0093046426773071e-01
    z[6,3,2]  R2040     -2.1145179867744446e-01
    z[6,3,2]  R2041     -8.2104299217462540e-03
    z[6,3,2]  R2042     3.5090631246566772e-01
    z[6,3,2]  R2043     4.9911147356033325e-01
    z[6,3,2]  R2044     2.3015265166759491e-01
    z[6,3,2]  R2045     -5.2543884515762329e-01
    z[6,3,2]  R2046     2.5317168235778809e-01
    z[6,3,2]  R2047     4.4305637478828430e-01
    z[6,3,2]  R2048     -2.3154832422733307e-01
    z[6,3,2]  R2049     -4.9875292181968689e-01
    z[6,3,2]  R2050     -4.9246424436569214e-01
    z[6,3,2]  R2051     -0.179381862282753
    z[6,3,2]  R2052     0.50576251745224
    z[6,3,2]  R2053     4.9431779980659485e-01
    z[6,3,2]  R2054     5.8363676071166992e-01
    z[6,3,2]  R2055     3.7546235322952271e-01
    z[6,3,2]  R2056     -5.5164024233818054e-02
    z[6,3,2]  R2057     4.6470394730567932e-01
    z[6,3,2]  R2058     6.0612101107835770e-02
    z[6,3,2]  R2059     1.7800678312778473e-01
    z[6,3,2]  R2060     -2.4674880504608154e-01
    z[6,3,2]  R2061     1.0945523530244827e-01
    z[6,3,2]  R2062     2.0087005198001862e-01
    z[6,3,2]  R2063     -4.0304175019264221e-01
    z[6,3,2]  R2064     -4.7503703832626343e-01
    z[6,3,2]  R2065     -2.3438222706317902e-01
    z[6,3,2]  R2066     -4.0537121891975403e-01
    z[6,3,2]  R2067     -2.3900006711483002e-01
    z[6,3,2]  R2068     3.1247567385435104e-02
    z[6,3,2]  R2069     5.2226681262254715e-02
    z[6,3,2]  R2070     -3.5896146297454834e-01
    z[6,3,2]  R2071     -1.0460843890905380e-01
    z[6,3,2]  R2072     -3.1134307384490967e-01
    z[6,3,2]  R2073     -1.2013496458530426e-01
    z[6,3,2]  R2074     -2.0758289098739624e-01
    z[6,3,2]  R2075     -2.4450413882732391e-01
    z[6,3,3]  R32       1
    z[6,3,3]  R59       -1
    z[6,3,3]  R2011     -1
    z[6,3,3]  R2012     1
    z[6,3,3]  R2019     1.8152070045471191e-01
    z[6,3,3]  R2020     3.0024429783225060e-02
    z[6,3,3]  R2021     -6.7329630255699158e-02
    z[6,3,3]  R2022     1.4320933818817139e-01
    z[6,3,3]  R2023     -5.0282761454582214e-02
    z[6,3,3]  R2024     5.4868827573955059e-03
    z[6,3,3]  R2025     -7.1596577763557434e-02
    z[6,3,3]  R2026     6.7600446939468384e-01
    z[6,3,3]  R2027     0.30000039935112
    z[6,3,3]  R2028     0.794006884098053
    z[6,3,3]  R2029     1.1935956031084061e-01
    z[6,3,3]  R2030     -6.9941782951354980e-01
    z[6,3,3]  R2031     0.301226943731308
    z[6,3,3]  R2032     3.8864842057228088e-01
    z[6,3,3]  R2033     2.3955328762531281e-01
    z[6,3,3]  R2034     2.5290060043334961e-01
    z[6,3,3]  R2035     7.8742668032646179e-02
    z[6,3,3]  R2036     4.4505367986857891e-03
    z[6,3,3]  R2037     -4.0808707475662231e-02
    z[6,3,3]  R2038     3.4651394933462143e-02
    z[6,3,3]  R2039     -4.1442832350730896e-01
    z[6,3,3]  R2040     -4.0571314096450806e-01
    z[6,3,3]  R2041     -7.3294615745544434e-01
    z[6,3,3]  R2042     2.0180614292621613e-01
    z[6,3,3]  R2043     -3.9547482132911682e-01
    z[6,3,3]  R2044     -3.7801361083984375e-01
    z[6,3,3]  R2045     -9.5134507864713669e-03
    z[6,3,3]  R2046     4.7430381178855896e-02
    z[6,3,3]  R2047     2.8876092284917831e-02
    z[6,3,3]  R2048     5.0100311636924744e-02
    z[6,3,3]  R2049     -2.7720436453819275e-01
    z[6,3,3]  R2050     -4.6595868468284607e-01
    z[6,3,3]  R2051     -5.5398764088749886e-03
    z[6,3,3]  R2052     4.4093075394630432e-01
    z[6,3,3]  R2053     2.7040678262710571e-01
    z[6,3,3]  R2054     7.3127579689025879e-01
    z[6,3,3]  R2055     4.1562882065773010e-01
    z[6,3,3]  R2056     1.2848268449306488e-01
    z[6,3,3]  R2057     2.1257027983665466e-01
    z[6,3,3]  R2058     -1.9541363418102264e-01
    z[6,3,3]  R2059     -1.9743348658084869e-01
    z[6,3,3]  R2060     -5.4969519376754761e-01
    z[6,3,3]  R2061     6.3999301195144653e-01
    z[6,3,3]  R2062     6.6140717267990112e-01
    z[6,3,3]  R2063     3.5298663377761841e-01
    z[6,3,3]  R2064     4.4309777021408081e-01
    z[6,3,3]  R2065     4.6353161334991455e-01
    z[6,3,3]  R2066     -3.0771313235163689e-02
    z[6,3,3]  R2067     -2.6654061675071716e-01
    z[6,3,3]  R2068     2.0046578347682953e-01
    z[6,3,3]  R2069     4.1446754336357117e-01
    z[6,3,3]  R2070     5.8468794822692871e-01
    z[6,3,3]  R2071     3.7966915965080261e-01
    z[6,3,3]  R2072     5.9524923563003540e-01
    z[6,3,3]  R2073     4.0818822383880615e-01
    z[6,3,3]  R2074     3.3546721935272217e-01
    z[6,3,3]  R2075     6.5078121423721313e-01
    z[6,3,4]  R33       1
    z[6,3,4]  R60       -1
    z[6,3,4]  R2013     -1
    z[6,3,4]  R2014     1
    z[6,3,4]  R2019     9.3230515718460083e-01
    z[6,3,4]  R2020     6.4843553304672241e-01
    z[6,3,4]  R2021     1.8940374255180359e-01
    z[6,3,4]  R2022     6.5703099966049194e-01
    z[6,3,4]  R2023     1.8320725858211517e-01
    z[6,3,4]  R2024     0.368007093667984
    z[6,3,4]  R2025     -3.9148527383804321e-01
    z[6,3,4]  R2026     -0.251006543636322
    z[6,3,4]  R2027     -3.4782004356384277e-01
    z[6,3,4]  R2028     -2.3502174019813538e-01
    z[6,3,4]  R2029     -1.3876289129257202e-01
    z[6,3,4]  R2030     -2.9398933053016663e-01
    z[6,3,4]  R2031     -2.4249014258384705e-01
    z[6,3,4]  R2032     -5.0091665983200073e-01
    z[6,3,4]  R2033     -4.2328283190727234e-01
    z[6,3,4]  R2034     6.4704000949859619e-02
    z[6,3,4]  R2035     -5.7221513986587524e-01
    z[6,3,4]  R2036     -5.2367347478866577e-01
    z[6,3,4]  R2037     -1.4771215617656708e-01
    z[6,3,4]  R2038     -3.8605967164039612e-01
    z[6,3,4]  R2039     4.0591907501220703e-01
    z[6,3,4]  R2040     -5.4308164119720459e-01
    z[6,3,4]  R2041     0.496865838766098
    z[6,3,4]  R2042     3.9167352952063084e-03
    z[6,3,4]  R2043     -5.3028100728988647e-01
    z[6,3,4]  R2044     -4.0601128339767456e-01
    z[6,3,4]  R2045     -2.8760954737663269e-01
    z[6,3,4]  R2046     0.85572350025177
    z[6,3,4]  R2047     5.5156075954437256e-01
    z[6,3,4]  R2048     -5.2889782190322876e-01
    z[6,3,4]  R2049     2.3898379504680634e-01
    z[6,3,4]  R2050     0.0794677734375
    z[6,3,4]  R2051     4.9426129460334778e-01
    z[6,3,4]  R2052     -7.3871716856956482e-02
    z[6,3,4]  R2053     3.4427908062934875e-01
    z[6,3,4]  R2054     -1.7902587354183197e-01
    z[6,3,4]  R2055     -3.1540572643280029e-01
    z[6,3,4]  R2056     -2.4714456498622894e-01
    z[6,3,4]  R2057     -3.8467753678560257e-02
    z[6,3,4]  R2058     -3.4658830612897873e-02
    z[6,3,4]  R2059     -2.4372906982898712e-01
    z[6,3,4]  R2060     8.9103868231177330e-03
    z[6,3,4]  R2061     3.9257079362869263e-01
    z[6,3,4]  R2062     -2.1384319290518761e-02
    z[6,3,4]  R2063     6.7004904150962830e-02
    z[6,3,4]  R2064     2.2348852455615997e-01
    z[6,3,4]  R2065     3.6299028992652893e-01
    z[6,3,4]  R2066     5.3707206249237061e-01
    z[6,3,4]  R2067     2.9634320735931396e-01
    z[6,3,4]  R2068     1.3828288018703461e-01
    z[6,3,4]  R2069     -3.4940603375434875e-01
    z[6,3,4]  R2070     -6.5426945686340332e-02
    z[6,3,4]  R2071     -1.6886492073535919e-01
    z[6,3,4]  R2072     2.1630893647670746e-01
    z[6,3,4]  R2073     3.2086926698684692e-01
    z[6,3,4]  R2074     9.5850922167301178e-02
    z[6,3,4]  R2075     5.9840731322765350e-02
    z[6,3,5]  R34       1
    z[6,3,5]  R61       -1
    z[6,3,5]  R2015     -1
    z[6,3,5]  R2016     1
    z[6,3,5]  R2019     -1.2142031639814377e-01
    z[6,3,5]  R2020     -7.2115555405616760e-02
    z[6,3,5]  R2021     5.1024538278579712e-01
    z[6,3,5]  R2022     3.6064037680625916e-01
    z[6,3,5]  R2023     -4.1838459670543671e-02
    z[6,3,5]  R2024     -7.2465568780899048e-02
    z[6,3,5]  R2025     -2.2915486246347427e-02
    z[6,3,5]  R2026     -1.7315704608336091e-03
    z[6,3,5]  R2027     6.7093491554260254e-01
    z[6,3,5]  R2028     3.9473345875740051e-01
    z[6,3,5]  R2029     3.2030217349529266e-02
    z[6,3,5]  R2030     -0.512298047542572
    z[6,3,5]  R2031     -3.6583945620805025e-03
    z[6,3,5]  R2032     -8.8016480207443237e-02
    z[6,3,5]  R2033     -1.2372436374425888e-01
    z[6,3,5]  R2034     8.2141578197479248e-02
    z[6,3,5]  R2035     9.2413406819105148e-03
    z[6,3,5]  R2036     8.6203746497631073e-02
    z[6,3,5]  R2037     0.583867073059082
    z[6,3,5]  R2038     3.3442100882530212e-01
    z[6,3,5]  R2039     -6.9211864471435547e-01
    z[6,3,5]  R2040     -4.0671899914741516e-01
    z[6,3,5]  R2041     1.3982349634170532e-01
    z[6,3,5]  R2042     -3.4050858020782471e-01
    z[6,3,5]  R2043     3.8897618651390076e-01
    z[6,3,5]  R2044     6.8253362178802490e-01
    z[6,3,5]  R2045     1.4928117394447327e-01
    z[6,3,5]  R2046     -7.3899462819099426e-02
    z[6,3,5]  R2047     -5.0889093428850174e-02
    z[6,3,5]  R2048     -7.8351572155952454e-02
    z[6,3,5]  R2049     -2.1108351647853851e-01
    z[6,3,5]  R2050     4.1301745176315308e-01
    z[6,3,5]  R2051     6.8182200193405151e-01
    z[6,3,5]  R2052     7.0880597829818726e-01
    z[6,3,5]  R2053     6.1938923597335815e-01
    z[6,3,5]  R2054     2.0538989454507828e-02
    z[6,3,5]  R2055     4.3539252877235413e-01
    z[6,3,5]  R2056     -2.6755759119987488e-01
    z[6,3,5]  R2057     1.9438152015209198e-01
    z[6,3,5]  R2058     -1.2422193586826324e-01
    z[6,3,5]  R2059     -1.1561634950339794e-02
    z[6,3,5]  R2060     -5.9379488229751587e-01
    z[6,3,5]  R2061     -1.2538772821426392e-01
    z[6,3,5]  R2062     -5.6181255728006363e-02
    z[6,3,5]  R2063     -2.4589703977108002e-01
    z[6,3,5]  R2064     -1.7353695631027222e-01
    z[6,3,5]  R2065     -2.8736993670463562e-01
    z[6,3,5]  R2066     -5.9584236145019531e-01
    z[6,3,5]  R2067     -2.9813820123672485e-01
    z[6,3,5]  R2068     2.0180438458919525e-01
    z[6,3,5]  R2069     4.1949892044067383e-01
    z[6,3,5]  R2070     9.2779628932476044e-02
    z[6,3,5]  R2071     -1.7605556547641754e-01
    z[6,3,5]  R2072     5.8603119105100632e-02
    z[6,3,5]  R2073     -8.5768803954124451e-02
    z[6,3,5]  R2074     -3.4668779373168945e-01
    z[6,3,5]  R2075     -1.3270154595375061e-01
    z[6,3,6]  R35       1
    z[6,3,6]  R62       -1
    z[6,3,6]  R2017     -1
    z[6,3,6]  R2018     1
    z[6,3,6]  R2019     -0.0995897725224495
    z[6,3,6]  R2020     1.9014886021614075e-01
    z[6,3,6]  R2021     4.7758764028549194e-01
    z[6,3,6]  R2022     -2.7407726645469666e-01
    z[6,3,6]  R2023     -0.755608856678009
    z[6,3,6]  R2024     5.3503835201263428e-01
    z[6,3,6]  R2025     3.5406398773193359e-01
    z[6,3,6]  R2026     -5.6641805917024612e-02
    z[6,3,6]  R2027     -4.0861517190933228e-02
    z[6,3,6]  R2028     4.1237942874431610e-02
    z[6,3,6]  R2029     1.1922285705804825e-01
    z[6,3,6]  R2030     0.0891263335943222
    z[6,3,6]  R2031     9.6925109624862671e-02
    z[6,3,6]  R2032     -3.4527987241744995e-01
    z[6,3,6]  R2033     -2.0519843697547913e-01
    z[6,3,6]  R2034     -0.374266117811203
    z[6,3,6]  R2035     -1.5563745796680450e-01
    z[6,3,6]  R2036     0.543026864528656
    z[6,3,6]  R2037     -3.5846036672592163e-01
    z[6,3,6]  R2038     -4.5592454075813293e-01
    z[6,3,6]  R2039     1.1840562522411346e-01
    z[6,3,6]  R2040     -2.0762926340103149e-01
    z[6,3,6]  R2041     -1.3053172826766968e-01
    z[6,3,6]  R2042     -4.2118576169013977e-01
    z[6,3,6]  R2043     1.2796354480087757e-02
    z[6,3,6]  R2044     -3.1583356857299805e-01
    z[6,3,6]  R2045     -0.184713214635849
    z[6,3,6]  R2046     2.3194292187690735e-01
    z[6,3,6]  R2047     -5.6289398670196533e-01
    z[6,3,6]  R2048     4.6154615283012390e-01
    z[6,3,6]  R2049     -6.4207464456558228e-01
    z[6,3,6]  R2050     3.8247132301330566e-01
    z[6,3,6]  R2051     -0.119338259100914
    z[6,3,6]  R2052     0.0787559524178505
    z[6,3,6]  R2053     2.4156802892684937e-01
    z[6,3,6]  R2054     -1.2522128224372864e-01
    z[6,3,6]  R2055     -5.8474189043045044e-01
    z[6,3,6]  R2056     1.7861206829547882e-01
    z[6,3,6]  R2057     3.3109375834465027e-01
    z[6,3,6]  R2058     1.8474312126636505e-01
    z[6,3,6]  R2059     -1.3475050032138824e-01
    z[6,3,6]  R2060     2.1845014393329620e-01
    z[6,3,6]  R2061     -2.4525426328182220e-01
    z[6,3,6]  R2062     -5.0956577062606812e-01
    z[6,3,6]  R2063     4.5300893485546112e-02
    z[6,3,6]  R2064     2.8403285890817642e-02
    z[6,3,6]  R2065     1.0566082596778870e-01
    z[6,3,6]  R2066     3.4488376975059509e-01
    z[6,3,6]  R2067     -3.0400553345680237e-01
    z[6,3,6]  R2068     -5.7618337869644165e-01
    z[6,3,6]  R2069     -0.369929701089859
    z[6,3,6]  R2070     -7.0126913487911224e-02
    z[6,3,6]  R2071     -1.6045859456062317e-01
    z[6,3,6]  R2072     -1.5351210720837116e-02
    z[6,3,6]  R2073     -1.0269220918416977e-02
    z[6,3,6]  R2074     -1.2269319593906403e-01
    z[6,3,6]  R2075     -2.0770236849784851e-01
    z[4,5,0]  R38       -1
    z[4,5,0]  R47       1
    z[4,5,0]  R2120     -1
    z[4,5,0]  R2121     1
    z[4,5,0]  R2134     2.4657995998859406e-01
    z[4,5,0]  R2135     0.255929559469223
    z[4,5,0]  R2136     -1.8523028492927551e-01
    z[4,5,0]  R2137     -1.6787399351596832e-01
    z[4,5,0]  R2138     -3.2924351096153259e-01
    z[4,5,0]  R2139     -4.7347900271415710e-01
    z[4,5,0]  R2140     9.0349888801574707e-01
    z[4,5,0]  R2141     -3.5524335503578186e-01
    z[4,5,0]  R2142     8.7765812873840332e-01
    z[4,5,0]  R2143     8.9711707830429077e-01
    z[4,5,0]  R2144     8.5212677717208862e-02
    z[4,5,0]  R2145     -8.4351825714111328e-01
    z[4,5,0]  R2146     4.9002498388290405e-01
    z[4,5,0]  R2147     -7.4569523334503174e-01
    z[4,5,0]  R2148     2.5136426091194153e-01
    z[4,5,0]  R2149     -5.4509627819061279e-01
    z[4,5,0]  R2150     -5.5023926496505737e-01
    z[4,5,0]  R2151     -5.0054174661636353e-01
    z[4,5,0]  R2152     -5.7826393842697144e-01
    z[4,5,0]  R2153     -5.1791024208068848e-01
    z[4,5,0]  R2154     -7.3025655746459961e-01
    z[4,5,0]  R2155     -7.3584026098251343e-01
    z[4,5,0]  R2156     -0.660832405090332
    z[4,5,0]  R2157     -6.5865439176559448e-01
    z[4,5,0]  R2158     5.3700363636016846e-01
    z[4,5,0]  R2159     5.1652848720550537e-01
    z[4,5,0]  R2160     4.7987800836563110e-01
    z[4,5,0]  R2161     2.9732385277748108e-01
    z[4,5,0]  R2162     3.5026237368583679e-01
    z[4,5,0]  R2163     4.0412786602973938e-01
    z[4,5,0]  R2164     8.9487487077713013e-01
    z[4,5,0]  R2165     5.7791447639465332e-01
    z[4,5,0]  R2166     3.3423185348510742e-01
    z[4,5,0]  R2167     3.9829817414283752e-01
    z[4,5,0]  R2168     3.0566087365150452e-01
    z[4,5,0]  R2169     3.0863767862319946e-01
    z[4,5,0]  R2170     2.8419691324234009e-01
    z[4,5,0]  R2171     -3.2681086659431458e-01
    z[4,5,0]  R2172     7.5943458080291748e-01
    z[4,5,0]  R2173     8.6767166852951050e-01
    z[4,5,0]  R2174     7.3249679803848267e-01
    z[4,5,0]  R2175     6.8604403734207153e-01
    z[4,5,0]  R2176     -4.4286161661148071e-01
    z[4,5,0]  R2177     -5.4820311069488525e-01
    z[4,5,0]  R2178     8.8026702404022217e-01
    z[4,5,0]  R2179     6.8000304698944092e-01
    z[4,5,0]  R2180     1.1706885695457458e-01
    z[4,5,0]  R2181     6.7970955371856689e-01
    z[4,5,0]  R2182     -7.2851979732513428e-01
    z[4,5,0]  R2183     -5.3250616788864136e-01
    z[4,5,0]  R2184     -4.5595401525497437e-01
    z[4,5,0]  R2185     -4.3952351808547974e-01
    z[4,5,0]  R2186     -4.3826425075531006e-01
    z[4,5,0]  R2187     -4.2607232928276062e-01
    z[4,5,0]  R2188     -4.5474034547805786e-01
    z[4,5,0]  R2189     -0.492642879486084
    z[4,5,0]  R2190     -3.5169291496276855e-01
    z[4,5,0]  R2191     -4.2849314212799072e-01
    z[4,5,0]  R2192     -1.8124037981033325e-01
    z[4,5,0]  R2193     1.0111644119024277e-01
    z[4,5,0]  R2194     -1.4891627430915833e-01
    z[4,5,0]  R2195     -3.5820782184600830e-01
    z[4,5,0]  R2196     1.6601191833615303e-02
    z[4,5,0]  R2197     -9.0139172971248627e-02
    z[4,5,0]  R2198     9.9790267646312714e-02
    z[4,5,0]  R2199     -5.5877542495727539e-01
    z[4,5,0]  R2200     -6.8435692787170410e-01
    z[4,5,0]  R2201     0.591355562210083
    z[4,5,0]  R2202     -0.634787917137146
    z[4,5,0]  R2203     -4.2726138234138489e-01
    z[4,5,0]  R2204     1.2502075731754303e-01
    z[4,5,0]  R2205     3.1266176700592041e-01
    z[4,5,0]  R2206     3.5332730412483215e-01
    z[4,5,0]  R2207     -8.6019468307495117e-01
    z[4,5,0]  R2208     -0.551559567451477
    z[4,5,0]  R2209     0.562705397605896
    z[4,5,0]  R2210     5.3335338830947876e-01
    z[4,5,0]  R2211     5.8284366130828857e-01
    z[4,5,0]  R2212     -1.4608344435691833e-01
    z[4,5,0]  R2213     4.0938743948936462e-01
    z[4,5,0]  R2214     1.8510198593139648e-01
    z[4,5,0]  R2215     2.6271072030067444e-01
    z[4,5,0]  R2216     5.9153407812118530e-01
    z[4,5,0]  R2217     2.2646707296371460e-01
    z[4,5,0]  R2218     5.1118308305740356e-01
    z[4,5,0]  R2219     -8.3527660369873047e-01
    z[4,5,0]  R2220     -4.7554358839988708e-01
    z[4,5,0]  R2221     -5.4265040159225464e-01
    z[4,5,0]  R2222     4.9199834465980530e-01
    z[4,5,0]  R2223     6.2315154075622559e-01
    z[4,5,0]  R2224     -5.2788324654102325e-02
    z[4,5,0]  R2225     4.3013170361518860e-01
    z[4,5,0]  R2226     0.500211238861084
    z[4,5,0]  R2227     -4.3523499369621277e-01
    z[4,5,0]  R2228     -5.9402501583099365e-01
    z[4,5,0]  R2229     -0.832075297832489
    z[4,5,0]  R2230     -5.5556356906890869e-01
    z[4,5,0]  R2231     -8.5553938150405884e-01
    z[4,5,0]  R2232     -7.5360065698623657e-01
    z[4,5,0]  R2233     7.5770670175552368e-01
    z[4,5,0]  R2234     1.5656508505344391e-01
    z[4,5,0]  R2235     -2.8213843703269958e-01
    z[4,5,0]  R2236     -2.8486687690019608e-02
    z[4,5,0]  R2237     4.7304117679595947e-01
    z[4,5,0]  R2238     -8.5314494371414185e-01
    z[4,5,0]  R2239     -6.6401398181915283e-01
    z[4,5,0]  R2240     -9.0782427787780762e-01
    z[4,5,0]  R2241     -6.1012154817581177e-01
    z[4,5,0]  R2242     5.7783633470535278e-01
    z[4,5,0]  R2243     4.4784688949584961e-01
    z[4,5,0]  R2244     -4.8408564925193787e-01
    z[4,5,0]  R2245     -0.672747015953064
    z[4,5,0]  R2246     -4.9150905013084412e-01
    z[4,5,0]  R2247     5.8502227067947388e-01
    z[4,5,0]  R2248     6.6070383787155151e-01
    z[4,5,0]  R2249     6.8326950073242188e-01
    z[4,5,0]  R2250     6.8778365850448608e-01
    z[4,5,0]  R2251     6.7371368408203125e-01
    z[4,5,0]  R2252     -8.9634925127029419e-01
    z[4,5,0]  R2253     5.8706700801849365e-01
    z[4,5,0]  R2254     6.3879698514938354e-01
    z[4,5,0]  R2255     6.2776446342468262e-01
    z[4,5,0]  R2256     4.9042728543281555e-01
    z[4,5,0]  R2257     -4.4271769002079964e-03
    z[4,5,0]  R2258     3.7055447697639465e-02
    z[4,5,0]  R2259     5.4906487464904785e-01
    z[4,5,0]  R2260     5.7185983657836914e-01
    z[4,5,0]  R2261     2.9208138585090637e-01
    z[4,5,1]  R39       -1
    z[4,5,1]  R48       1
    z[4,5,1]  R2122     -1
    z[4,5,1]  R2123     1
    z[4,5,1]  R2134     2.5135436654090881e-01
    z[4,5,1]  R2135     0.420491099357605
    z[4,5,1]  R2136     2.5548499822616577e-01
    z[4,5,1]  R2137     2.3999880254268646e-01
    z[4,5,1]  R2138     3.7604832649230957e-01
    z[4,5,1]  R2139     -4.3337881565093994e-01
    z[4,5,1]  R2140     -8.1412322819232941e-02
    z[4,5,1]  R2141     4.7677550464868546e-02
    z[4,5,1]  R2142     -2.4651013314723969e-01
    z[4,5,1]  R2143     9.0749554336071014e-02
    z[4,5,1]  R2144     7.1628761291503906e-01
    z[4,5,1]  R2145     8.1906437873840332e-02
    z[4,5,1]  R2146     -2.1238750219345093e-01
    z[4,5,1]  R2147     3.3670984208583832e-02
    z[4,5,1]  R2148     -4.5006313920021057e-01
    z[4,5,1]  R2149     -2.9721334576606750e-01
    z[4,5,1]  R2150     -4.0150359272956848e-01
    z[4,5,1]  R2151     -3.8969784975051880e-01
    z[4,5,1]  R2152     -3.7562859058380127e-01
    z[4,5,1]  R2153     -3.1049597263336182e-01
    z[4,5,1]  R2154     3.8402697443962097e-01
    z[4,5,1]  R2155     -2.2488430142402649e-01
    z[4,5,1]  R2156     -2.9133029282093048e-02
    z[4,5,1]  R2157     -3.5321453213691711e-01
    z[4,5,1]  R2158     -4.7083371877670288e-01
    z[4,5,1]  R2159     -3.0634710192680359e-01
    z[4,5,1]  R2160     -4.5350956916809082e-01
    z[4,5,1]  R2161     -2.1151988208293915e-01
    z[4,5,1]  R2162     -1.7822524905204773e-01
    z[4,5,1]  R2163     2.1170638501644135e-01
    z[4,5,1]  R2164     -2.2562728822231293e-01
    z[4,5,1]  R2165     -5.6426286697387695e-02
    z[4,5,1]  R2166     -1.3580378890037537e-01
    z[4,5,1]  R2167     4.9179205298423767e-01
    z[4,5,1]  R2168     3.1875270605087280e-01
    z[4,5,1]  R2169     2.9287168383598328e-01
    z[4,5,1]  R2170     3.4953951835632324e-01
    z[4,5,1]  R2171     -2.0246687531471252e-01
    z[4,5,1]  R2172     5.1057547330856323e-01
    z[4,5,1]  R2173     3.1768313050270081e-01
    z[4,5,1]  R2174     4.8648440837860107e-01
    z[4,5,1]  R2175     4.7185283899307251e-01
    z[4,5,1]  R2176     4.4452327489852905e-01
    z[4,5,1]  R2177     -4.0931418538093567e-02
    z[4,5,1]  R2178     3.4900563955307007e-01
    z[4,5,1]  R2179     4.5200872421264648e-01
    z[4,5,1]  R2180     6.1654180288314819e-01
    z[4,5,1]  R2181     3.8457027077674866e-01
    z[4,5,1]  R2182     2.4004091322422028e-01
    z[4,5,1]  R2183     -4.3289753794670105e-01
    z[4,5,1]  R2184     -0.192816823720932
    z[4,5,1]  R2185     -2.1364213526248932e-01
    z[4,5,1]  R2186     -2.2704876959323883e-01
    z[4,5,1]  R2187     -2.5199401378631592e-01
    z[4,5,1]  R2188     -2.0157837867736816e-01
    z[4,5,1]  R2189     -1.9670151174068451e-01
    z[4,5,1]  R2190     -2.3894466459751129e-01
    z[4,5,1]  R2191     -2.3336625099182129e-01
    z[4,5,1]  R2192     3.4802475571632385e-01
    z[4,5,1]  R2193     7.8177338838577271e-01
    z[4,5,1]  R2194     2.4236483871936798e-01
    z[4,5,1]  R2195     1.7813818156719208e-01
    z[4,5,1]  R2196     8.5366815328598022e-01
    z[4,5,1]  R2197     6.6496598720550537e-01
    z[4,5,1]  R2198     3.4388515353202820e-01
    z[4,5,1]  R2199     -3.1246135011315346e-02
    z[4,5,1]  R2200     -1.8710640072822571e-01
    z[4,5,1]  R2201     -7.2522288560867310e-01
    z[4,5,1]  R2202     5.2543687820434570e-01
    z[4,5,1]  R2203     5.8598470687866211e-01
    z[4,5,1]  R2204     0.849338948726654
    z[4,5,1]  R2205     7.1854478120803833e-01
    z[4,5,1]  R2206     4.8190990090370178e-01
    z[4,5,1]  R2207     -1.8543800711631775e-01
    z[4,5,1]  R2208     -3.7781310081481934e-01
    z[4,5,1]  R2209     -5.2031236886978149e-01
    z[4,5,1]  R2210     -6.2621653079986572e-01
    z[4,5,1]  R2211     1.9602222368121147e-02
    z[4,5,1]  R2212     7.7178794145584106e-01
    z[4,5,1]  R2213     7.8734922409057617e-01
    z[4,5,1]  R2214     6.1397576332092285e-01
    z[4,5,1]  R2215     8.8871586322784424e-01
    z[4,5,1]  R2216     0.267733097076416
    z[4,5,1]  R2217     3.3866789937019348e-01
    z[4,5,1]  R2218     5.2049368619918823e-01
    z[4,5,1]  R2219     -1.1216162145137787e-01
    z[4,5,1]  R2220     3.0052950978279114e-01
    z[4,5,1]  R2221     -3.2113844156265259e-01
    z[4,5,1]  R2222     4.7029018402099609e-01
    z[4,5,1]  R2223     3.7659695744514465e-01
    z[4,5,1]  R2224     0.0677233412861824
    z[4,5,1]  R2225     1.5144044160842896e-01
    z[4,5,1]  R2226     5.7834458351135254e-01
    z[4,5,1]  R2227     5.1786535978317261e-01
    z[4,5,1]  R2228     -2.8375563025474548e-01
    z[4,5,1]  R2229     -3.4214520454406738e-01
    z[4,5,1]  R2230     -3.3144152164459229e-01
    z[4,5,1]  R2231     -0.0317201092839241
    z[4,5,1]  R2232     1.1143982410430908e-01
    z[4,5,1]  R2233     4.7424244880676270e-01
    z[4,5,1]  R2234     8.5829752683639526e-01
    z[4,5,1]  R2235     3.1502538919448853e-01
    z[4,5,1]  R2236     4.6628189086914062e-01
    z[4,5,1]  R2237     5.6245517730712891e-01
    z[4,5,1]  R2238     -2.7969694137573242e-01
    z[4,5,1]  R2239     -4.1869038343429565e-01
    z[4,5,1]  R2240     -2.2984184324741364e-01
    z[4,5,1]  R2241     -3.1074598431587219e-02
    z[4,5,1]  R2242     7.8660178184509277e-01
    z[4,5,1]  R2243     6.3052386045455933e-01
    z[4,5,1]  R2244     1.7272271215915680e-01
    z[4,5,1]  R2245     -3.2018333673477173e-01
    z[4,5,1]  R2246     -2.6289907097816467e-01
    z[4,5,1]  R2247     -3.7370449304580688e-01
    z[4,5,1]  R2248     -5.1204943656921387e-01
    z[4,5,1]  R2249     -3.6264434456825256e-01
    z[4,5,1]  R2250     -5.7322126626968384e-01
    z[4,5,1]  R2251     -4.6222689747810364e-01
    z[4,5,1]  R2252     -9.9885143339633942e-02
    z[4,5,1]  R2253     -4.1757720708847046e-01
    z[4,5,1]  R2254     -5.2153486013412476e-01
    z[4,5,1]  R2255     -5.8511340618133545e-01
    z[4,5,1]  R2256     -6.2838965654373169e-01
    z[4,5,1]  R2257     -7.2098881006240845e-01
    z[4,5,1]  R2258     -8.9664030075073242e-01
    z[4,5,1]  R2259     -5.7314264774322510e-01
    z[4,5,1]  R2260     -4.7685539722442627e-01
    z[4,5,1]  R2261     -5.5895823240280151e-01
    z[4,5,2]  R40       -1
    z[4,5,2]  R49       1
    z[4,5,2]  R2124     -1
    z[4,5,2]  R2125     1
    z[4,5,2]  R2134     3.3723658323287964e-01
    z[4,5,2]  R2135     2.1254646778106689e-01
    z[4,5,2]  R2136     3.6979696154594421e-01
    z[4,5,2]  R2137     -3.9338001608848572e-01
    z[4,5,2]  R2138     -2.5375235080718994e-01
    z[4,5,2]  R2139     -4.0026667714118958e-01
    z[4,5,2]  R2140     -1.8174979090690613e-01
    z[4,5,2]  R2141     -7.2701007127761841e-01
    z[4,5,2]  R2142     6.9238655269145966e-02
    z[4,5,2]  R2143     -1.9710262119770050e-01
    z[4,5,2]  R2144     5.6447625160217285e-02
    z[4,5,2]  R2145     2.0022470504045486e-02
    z[4,5,2]  R2146     1.3306963443756104e-01
    z[4,5,2]  R2147     -1.9731815159320831e-01
    z[4,5,2]  R2148     -5.8517616987228394e-01
    z[4,5,2]  R2149     6.3593953847885132e-01
    z[4,5,2]  R2150     5.4929924011230469e-01
    z[4,5,2]  R2151     5.8574265241622925e-01
    z[4,5,2]  R2152     4.4907850027084351e-01
    z[4,5,2]  R2153     5.3506422042846680e-01
    z[4,5,2]  R2154     -4.1943371295928955e-01
    z[4,5,2]  R2155     -3.1705504655838013e-01
    z[4,5,2]  R2156     -5.5717867612838745e-01
    z[4,5,2]  R2157     -3.3449560403823853e-01
    z[4,5,2]  R2158     -5.0315749645233154e-01
    z[4,5,2]  R2159     -3.1380680203437805e-01
    z[4,5,2]  R2160     1.7505396157503128e-02
    z[4,5,2]  R2161     -6.4479392766952515e-01
    z[4,5,2]  R2162     -5.8811032772064209e-01
    z[4,5,2]  R2163     4.3414118885993958e-01
    z[4,5,2]  R2164     -1.1416142433881760e-01
    z[4,5,2]  R2165     -4.8208889365196228e-01
    z[4,5,2]  R2166     -2.0556335151195526e-01
    z[4,5,2]  R2167     7.0926159620285034e-01
    z[4,5,2]  R2168     0.772919774055481
    z[4,5,2]  R2169     7.5071024894714355e-01
    z[4,5,2]  R2170     6.2224715948104858e-01
    z[4,5,2]  R2171     7.0781558752059937e-01
    z[4,5,2]  R2172     0.225607231259346
    z[4,5,2]  R2173     3.1976962089538574e-01
    z[4,5,2]  R2174     2.1875400841236115e-01
    z[4,5,2]  R2175     4.4502955675125122e-01
    z[4,5,2]  R2176     -4.7080716490745544e-01
    z[4,5,2]  R2177     -4.1226577758789062e-01
    z[4,5,2]  R2178     1.5544793009757996e-01
    z[4,5,2]  R2179     3.5547360777854919e-01
    z[4,5,2]  R2180     -3.2983991503715515e-01
    z[4,5,2]  R2181     4.8570439219474792e-01
    z[4,5,2]  R2182     2.3494124412536621e-01
    z[4,5,2]  R2183     6.5841847658157349e-01
    z[4,5,2]  R2184     8.0758494138717651e-01
    z[4,5,2]  R2185     6.8192929029464722e-01
    z[4,5,2]  R2186     6.5245223045349121e-01
    z[4,5,2]  R2187     6.6472548246383667e-01
    z[4,5,2]  R2188     0.639353334903717
    z[4,5,2]  R2189     6.3165879249572754e-01
    z[4,5,2]  R2190     7.7503788471221924e-01
    z[4,5,2]  R2191     5.7745563983917236e-01
    z[4,5,2]  R2192     2.3937088251113892e-01
    z[4,5,2]  R2193     2.8595605492591858e-01
    z[4,5,2]  R2194     -4.6420689672231674e-02
    z[4,5,2]  R2195     -2.5077894330024719e-01
    z[4,5,2]  R2196     1.2380032241344452e-01
    z[4,5,2]  R2197     -3.7403452396392822e-01
    z[4,5,2]  R2198     -7.1206778287887573e-01
    z[4,5,2]  R2199     -4.7657048702239990e-01
    z[4,5,2]  R2200     -2.1853515505790710e-01
    z[4,5,2]  R2201     -5.7819854468107224e-02
    z[4,5,2]  R2202     -4.0094745159149170e-01
    z[4,5,2]  R2203     -6.7131072282791138e-01
    z[4,5,2]  R2204     -4.1002368927001953e-01
    z[4,5,2]  R2205     -2.6114150881767273e-01
    z[4,5,2]  R2206     4.2280846834182739e-01
    z[4,5,2]  R2207     -2.4369031190872192e-01
    z[4,5,2]  R2208     0.328095406293869
    z[4,5,2]  R2209     3.8787674903869629e-01
    z[4,5,2]  R2210     2.9203245043754578e-01
    z[4,5,2]  R2211     -2.7586886286735535e-01
    z[4,5,2]  R2212     -2.2261705994606018e-01
    z[4,5,2]  R2213     3.4349447488784790e-01
    z[4,5,2]  R2214     -1.4417226612567902e-01
    z[4,5,2]  R2215     -1.2380160391330719e-01
    z[4,5,2]  R2216     -0.395833283662796
    z[4,5,2]  R2217     2.3510010540485382e-01
    z[4,5,2]  R2218     -2.0400816202163696e-01
    z[4,5,2]  R2219     -9.6323236823081970e-02
    z[4,5,2]  R2220     3.9766165614128113e-01
    z[4,5,2]  R2221     2.9063206911087036e-01
    z[4,5,2]  R2222     6.3487243652343750e-01
    z[4,5,2]  R2223     3.7208899855613708e-01
    z[4,5,2]  R2224     1.3445743918418884e-01
    z[4,5,2]  R2225     -4.3952378630638123e-01
    z[4,5,2]  R2226     -2.9135462641716003e-01
    z[4,5,2]  R2227     0.0922401174902916
    z[4,5,2]  R2228     4.4079285860061646e-01
    z[4,5,2]  R2229     -3.1065413355827332e-01
    z[4,5,2]  R2230     0.355376273393631
    z[4,5,2]  R2231     1.2634010612964630e-01
    z[4,5,2]  R2232     -4.2379835247993469e-01
    z[4,5,2]  R2233     3.0889004468917847e-01
    z[4,5,2]  R2234     -3.6990982294082642e-01
    z[4,5,2]  R2235     3.5622832179069519e-01
    z[4,5,2]  R2236     -4.7861674427986145e-01
    z[4,5,2]  R2237     -1.3612095499411225e-03
    z[4,5,2]  R2238     -1.4447963237762451e-01
    z[4,5,2]  R2239     2.8854611515998840e-01
    z[4,5,2]  R2240     2.1654902398586273e-01
    z[4,5,2]  R2241     6.2843970954418182e-02
    z[4,5,2]  R2242     -1.7592564225196838e-01
    z[4,5,2]  R2243     2.0112448930740356e-01
    z[4,5,2]  R2244     3.3232292532920837e-01
    z[4,5,2]  R2245     4.4547894597053528e-01
    z[4,5,2]  R2246     3.8438367843627930e-01
    z[4,5,2]  R2247     5.4896640777587891e-01
    z[4,5,2]  R2248     5.2453732490539551e-01
    z[4,5,2]  R2249     2.7125416323542595e-02
    z[4,5,2]  R2250     1.1758831888437271e-01
    z[4,5,2]  R2251     -1.3787375390529633e-01
    z[4,5,2]  R2252     -1.0769053548574448e-01
    z[4,5,2]  R2253     5.5269473791122437e-01
    z[4,5,2]  R2254     1.5828667581081390e-01
    z[4,5,2]  R2255     3.8291251659393311e-01
    z[4,5,2]  R2256     5.5537527799606323e-01
    z[4,5,2]  R2257     0.521673321723938
    z[4,5,2]  R2258     3.5263195633888245e-01
    z[4,5,2]  R2259     5.3273621946573257e-02
    z[4,5,2]  R2260     2.5538769364356995e-01
    z[4,5,2]  R2261     -2.4770677089691162e-01
    z[4,5,3]  R41       -1
    z[4,5,3]  R50       1
    z[4,5,3]  R2126     -1
    z[4,5,3]  R2127     1
    z[4,5,3]  R2134     1.9407291710376740e-01
    z[4,5,3]  R2135     3.7785834074020386e-01
    z[4,5,3]  R2136     0.359621524810791
    z[4,5,3]  R2137     3.5334849357604980e-01
    z[4,5,3]  R2138     -5.9966671466827393e-01
    z[4,5,3]  R2139     3.5166677832603455e-01
    z[4,5,3]  R2140     -1.7718973755836487e-01
    z[4,5,3]  R2141     -1.7114609479904175e-01
    z[4,5,3]  R2142     1.0475947707891464e-01
    z[4,5,3]  R2143     -1.4726942777633667e-01
    z[4,5,3]  R2144     -7.2947158478200436e-03
    z[4,5,3]  R2145     9.5679499208927155e-02
    z[4,5,3]  R2146     3.3502838015556335e-01
    z[4,5,3]  R2147     -1.4262425899505615e-01
    z[4,5,3]  R2148     3.4569406509399414e-01
    z[4,5,3]  R2149     -1.8511952459812164e-01
    z[4,5,3]  R2150     1.8296670913696289e-01
    z[4,5,3]  R2151     2.8348726034164429e-01
    z[4,5,3]  R2152     -1.3576443493366241e-01
    z[4,5,3]  R2153     1.6956056654453278e-01
    z[4,5,3]  R2154     -4.3668370693922043e-02
    z[4,5,3]  R2155     2.3234169185161591e-01
    z[4,5,3]  R2156     4.1011381894350052e-02
    z[4,5,3]  R2157     3.1981386244297028e-02
    z[4,5,3]  R2158     0.309207946062088
    z[4,5,3]  R2159     3.5993787646293640e-01
    z[4,5,3]  R2160     5.1507014036178589e-01
    z[4,5,3]  R2161     -3.3113643527030945e-01
    z[4,5,3]  R2162     -0.296572744846344
    z[4,5,3]  R2163     -1.6149322688579559e-01
    z[4,5,3]  R2164     2.6683533191680908e-01
    z[4,5,3]  R2165     -2.6365929841995239e-01
    z[4,5,3]  R2166     -1.7282043397426605e-01
    z[4,5,3]  R2167     -9.6074566245079041e-02
    z[4,5,3]  R2168     2.1486331522464752e-01
    z[4,5,3]  R2169     3.2078996300697327e-01
    z[4,5,3]  R2170     1.3732829689979553e-01
    z[4,5,3]  R2171     -4.2660561203956604e-01
    z[4,5,3]  R2172     2.8614804148674011e-01
    z[4,5,3]  R2173     1.9862221181392670e-01
    z[4,5,3]  R2174     9.6923463046550751e-02
    z[4,5,3]  R2175     1.0683256387710571e-01
    z[4,5,3]  R2176     -3.4418621659278870e-01
    z[4,5,3]  R2177     -3.7811005115509033e-01
    z[4,5,3]  R2178     7.2333104908466339e-02
    z[4,5,3]  R2179     -1.9786326587200165e-01
    z[4,5,3]  R2180     -1.4166752994060516e-01
    z[4,5,3]  R2181     -8.8863588869571686e-02
    z[4,5,3]  R2182     -1.4615970849990845e-01
    z[4,5,3]  R2183     2.3510551452636719e-01
    z[4,5,3]  R2184     8.4521457552909851e-02
    z[4,5,3]  R2185     4.4326889514923096e-01
    z[4,5,3]  R2186     3.0297595262527466e-01
    z[4,5,3]  R2187     -6.4370416104793549e-02
    z[4,5,3]  R2188     2.6252093911170959e-01
    z[4,5,3]  R2189     2.3608949780464172e-01
    z[4,5,3]  R2190     -0.383390337228775
    z[4,5,3]  R2191     4.6426522731781006e-01
    z[4,5,3]  R2192     -5.3112649917602539e-01
    z[4,5,3]  R2193     -1.9288714230060577e-01
    z[4,5,3]  R2194     -2.5173398852348328e-01
    z[4,5,3]  R2195     -1.6380971670150757e-01
    z[4,5,3]  R2196     -9.9699504673480988e-02
    z[4,5,3]  R2197     1.8503373861312866e-01
    z[4,5,3]  R2198     5.2364283800125122e-01
    z[4,5,3]  R2199     5.2530074119567871e-01
    z[4,5,3]  R2200     1.2904337048530579e-01
    z[4,5,3]  R2201     -1.1997362226247787e-01
    z[4,5,3]  R2202     -2.3272280395030975e-01
    z[4,5,3]  R2203     4.1645620018243790e-02
    z[4,5,3]  R2204     2.0353603363037109e-01
    z[4,5,3]  R2205     1.6257666051387787e-01
    z[4,5,3]  R2206     -4.2788782715797424e-01
    z[4,5,3]  R2207     1.0887966305017471e-01
    z[4,5,3]  R2208     -2.7930095791816711e-01
    z[4,5,3]  R2209     -1.5871591866016388e-01
    z[4,5,3]  R2210     -0.0847240760922432
    z[4,5,3]  R2211     2.6343245059251785e-02
    z[4,5,3]  R2212     -2.5393217802047729e-01
    z[4,5,3]  R2213     -2.6008498668670654e-01
    z[4,5,3]  R2214     -2.3698411881923676e-01
    z[4,5,3]  R2215     -1.5202210843563080e-01
    z[4,5,3]  R2216     -5.7442313432693481e-01
    z[4,5,3]  R2217     -6.6975212097167969e-01
    z[4,5,3]  R2218     4.0605121850967407e-01
    z[4,5,3]  R2219     1.2707798182964325e-01
    z[4,5,3]  R2220     -5.3396087884902954e-01
    z[4,5,3]  R2221     -8.2362376153469086e-02
    z[4,5,3]  R2222     -4.7547496855258942e-02
    z[4,5,3]  R2223     0.0390746146440506
    z[4,5,3]  R2224     -7.0815253257751465e-01
    z[4,5,3]  R2225     -1.5038779377937317e-01
    z[4,5,3]  R2226     3.5058364272117615e-01
    z[4,5,3]  R2227     -1.2800544500350952e-01
    z[4,5,3]  R2228     1.1343742907047272e-01
    z[4,5,3]  R2229     1.1935079097747803e-01
    z[4,5,3]  R2230     2.7844834327697754e-01
    z[4,5,3]  R2231     3.0967876315116882e-01
    z[4,5,3]  R2232     -8.1400223076343536e-02
    z[4,5,3]  R2233     2.4099707603454590e-02
    z[4,5,3]  R2234     -5.8336075395345688e-02
    z[4,5,3]  R2235     -5.3081786632537842e-01
    z[4,5,3]  R2236     -3.9032605290412903e-01
    z[4,5,3]  R2237     -3.8091403245925903e-01
    z[4,5,3]  R2238     -1.1232873797416687e-01
    z[4,5,3]  R2239     2.5902670621871948e-01
    z[4,5,3]  R2240     -5.9855529107153416e-03
    z[4,5,3]  R2241     -2.2981157898902893e-01
    z[4,5,3]  R2242     0.0851278305053711
    z[4,5,3]  R2243     -4.1740727424621582e-01
    z[4,5,3]  R2244     -5.7617175579071045e-01
    z[4,5,3]  R2245     -4.9353456497192383e-01
    z[4,5,3]  R2246     1.1958824843168259e-01
    z[4,5,3]  R2247     -2.5140696763992310e-01
    z[4,5,3]  R2248     4.2824551463127136e-02
    z[4,5,3]  R2249     -3.0461966991424561e-02
    z[4,5,3]  R2250     0.380967378616333
    z[4,5,3]  R2251     1.2610933184623718e-01
    z[4,5,3]  R2252     6.9487184286117554e-02
    z[4,5,3]  R2253     -2.3484340310096741e-01
    z[4,5,3]  R2254     -4.0507983416318893e-02
    z[4,5,3]  R2255     2.1431854367256165e-01
    z[4,5,3]  R2256     -8.1822186708450317e-02
    z[4,5,3]  R2257     -2.6592493057250977e-01
    z[4,5,3]  R2258     -7.9549968242645264e-02
    z[4,5,3]  R2259     4.8030912876129150e-01
    z[4,5,3]  R2260     2.9239574074745178e-01
    z[4,5,3]  R2261     5.8321475982666016e-01
    z[4,5,4]  R42       -1
    z[4,5,4]  R51       1
    z[4,5,4]  R2128     -1
    z[4,5,4]  R2129     1
    z[4,5,4]  R2134     -5.3325051069259644e-01
    z[4,5,4]  R2135     3.5291498899459839e-01
    z[4,5,4]  R2136     -7.4833756685256958e-01
    z[4,5,4]  R2137     9.6530608832836151e-02
    z[4,5,4]  R2138     1.3895675539970398e-01
    z[4,5,4]  R2139     2.2054056823253632e-01
    z[4,5,4]  R2140     -2.8322175145149231e-01
    z[4,5,4]  R2141     1.1401998996734619e-01
    z[4,5,4]  R2142     -1.3707152009010315e-01
    z[4,5,4]  R2143     4.4733222573995590e-02
    z[4,5,4]  R2144     2.6117414236068726e-01
    z[4,5,4]  R2145     4.9561902880668640e-01
    z[4,5,4]  R2146     0.406207412481308
    z[4,5,4]  R2147     -3.5524827241897583e-01
    z[4,5,4]  R2148     3.7169721722602844e-01
    z[4,5,4]  R2149     -3.1640312075614929e-01
    z[4,5,4]  R2150     -4.2178431153297424e-01
    z[4,5,4]  R2151     -2.5168126821517944e-01
    z[4,5,4]  R2152     -4.4645896553993225e-01
    z[4,5,4]  R2153     -3.5246381163597107e-01
    z[4,5,4]  R2154     0.280819296836853
    z[4,5,4]  R2155     4.3981426954269409e-01
    z[4,5,4]  R2156     4.0599894709885120e-03
    z[4,5,4]  R2157     -4.7642147541046143e-01
    z[4,5,4]  R2158     2.0234338939189911e-01
    z[4,5,4]  R2159     5.0732856988906860e-01
    z[4,5,4]  R2160     -2.6159477233886719e-01
    z[4,5,4]  R2161     1.0549803078174591e-01
    z[4,5,4]  R2162     3.7096962332725525e-01
    z[4,5,4]  R2163     -4.3181905150413513e-01
    z[4,5,4]  R2164     1.6442857682704926e-01
    z[4,5,4]  R2165     4.8693239688873291e-01
    z[4,5,4]  R2166     6.7832469940185547e-02
    z[4,5,4]  R2167     2.7059277892112732e-01
    z[4,5,4]  R2168     -3.8322050124406815e-02
    z[4,5,4]  R2169     1.9262421131134033e-01
    z[4,5,4]  R2170     -1.2879092991352081e-01
    z[4,5,4]  R2171     -1.4227072894573212e-01
    z[4,5,4]  R2172     -8.9635804295539856e-02
    z[4,5,4]  R2173     5.9240357950329781e-03
    z[4,5,4]  R2174     1.6294494271278381e-01
    z[4,5,4]  R2175     2.9447984695434570e-01
    z[4,5,4]  R2176     4.7585102915763855e-01
    z[4,5,4]  R2177     6.0992515087127686e-01
    z[4,5,4]  R2178     5.3177025169134140e-02
    z[4,5,4]  R2179     2.7024206519126892e-01
    z[4,5,4]  R2180     1.8455411493778229e-01
    z[4,5,4]  R2181     2.6636752486228943e-01
    z[4,5,4]  R2182     -0.532170832157135
    z[4,5,4]  R2183     -1.8462254106998444e-01
    z[4,5,4]  R2184     -2.2556984424591064e-01
    z[4,5,4]  R2185     2.7346667647361755e-01
    z[4,5,4]  R2186     1.0784591734409332e-01
    z[4,5,4]  R2187     2.4785001575946808e-01
    z[4,5,4]  R2188     2.0645757019519806e-01
    z[4,5,4]  R2189     3.7460610270500183e-01
    z[4,5,4]  R2190     0.00777652719989419
    z[4,5,4]  R2191     1.9684703648090363e-01
    z[4,5,4]  R2192     8.7425507605075836e-02
    z[4,5,4]  R2193     -3.7611982226371765e-01
    z[4,5,4]  R2194     8.4554873406887054e-02
    z[4,5,4]  R2195     4.4912289828062057e-02
    z[4,5,4]  R2196     -2.7962690591812134e-01
    z[4,5,4]  R2197     -1.9024184346199036e-01
    z[4,5,4]  R2198     -1.2297239154577255e-01
    z[4,5,4]  R2199     -1.7264726758003235e-01
    z[4,5,4]  R2200     -2.0380100607872009e-01
    z[4,5,4]  R2201     -1.6615694761276245e-01
    z[4,5,4]  R2202     4.9837347120046616e-02
    z[4,5,4]  R2203     1.0925633460283279e-01
    z[4,5,4]  R2204     -1.6090567409992218e-01
    z[4,5,4]  R2205     -2.3118624463677406e-02
    z[4,5,4]  R2206     1.8447768688201904e-01
    z[4,5,4]  R2207     -1.7895893752574921e-01
    z[4,5,4]  R2208     1.9566673040390015e-01
    z[4,5,4]  R2209     2.8256335854530334e-01
    z[4,5,4]  R2210     3.9508658647537231e-01
    z[4,5,4]  R2211     5.8149969577789307e-01
    z[4,5,4]  R2212     -1.5922186430543661e-03
    z[4,5,4]  R2213     -1.3166756927967072e-01
    z[4,5,4]  R2214     3.4759557247161865e-01
    z[4,5,4]  R2215     1.0526530444622040e-02
    z[4,5,4]  R2216     -1.4662112109363079e-02
    z[4,5,4]  R2217     5.3493720293045044e-01
    z[4,5,4]  R2218     -3.1676670908927917e-01
    z[4,5,4]  R2219     -3.7845450639724731e-01
    z[4,5,4]  R2220     -1.3518825289793313e-04
    z[4,5,4]  R2221     -3.3785271644592285e-01
    z[4,5,4]  R2222     -3.0541995167732239e-01
    z[4,5,4]  R2223     -1.8798868358135223e-01
    z[4,5,4]  R2224     6.7701435089111328e-01
    z[4,5,4]  R2225     6.3727504014968872e-01
    z[4,5,4]  R2226     -2.4129703640937805e-01
    z[4,5,4]  R2227     -2.4397027492523193e-01
    z[4,5,4]  R2228     2.3534847795963287e-01
    z[4,5,4]  R2229     -1.3661400973796844e-01
    z[4,5,4]  R2230     5.0487709045410156e-01
    z[4,5,4]  R2231     -5.3828172385692596e-02
    z[4,5,4]  R2232     1.3678911328315735e-01
    z[4,5,4]  R2233     -1.1057466268539429e-01
    z[4,5,4]  R2234     1.4980529248714447e-01
    z[4,5,4]  R2235     1.3441678881645203e-01
    z[4,5,4]  R2236     -5.0711023807525635e-01
    z[4,5,4]  R2237     3.5708293318748474e-01
    z[4,5,4]  R2238     6.6397930495440960e-03
    z[4,5,4]  R2239     3.1206998229026794e-01
    z[4,5,4]  R2240     1.1286263167858124e-01
    z[4,5,4]  R2241     5.7297468185424805e-02
    z[4,5,4]  R2242     -1.1313164606690407e-02
    z[4,5,4]  R2243     2.0030789077281952e-01
    z[4,5,4]  R2244     0.0537506528198719
    z[4,5,4]  R2245     9.6015287563204765e-03
    z[4,5,4]  R2246     -2.5005133822560310e-02
    z[4,5,4]  R2247     2.5555279850959778e-01
    z[4,5,4]  R2248     8.7121017277240753e-03
    z[4,5,4]  R2249     4.8978802561759949e-01
    z[4,5,4]  R2250     1.1990191414952278e-02
    z[4,5,4]  R2251     5.2671605348587036e-01
    z[4,5,4]  R2252     -0.384162575006485
    z[4,5,4]  R2253     2.5257727503776550e-01
    z[4,5,4]  R2254     3.8030573725700378e-01
    z[4,5,4]  R2255     -5.5059641599655151e-02
    z[4,5,4]  R2256     1.3978768885135651e-01
    z[4,5,4]  R2257     1.6580714285373688e-01
    z[4,5,4]  R2258     1.5398119390010834e-01
    z[4,5,4]  R2259     -1.0099439322948456e-01
    z[4,5,4]  R2260     -3.1638448126614094e-03
    z[4,5,4]  R2261     -3.8547852635383606e-01
    z[4,5,5]  R43       -1
    z[4,5,5]  R52       1
    z[4,5,5]  R2130     -1
    z[4,5,5]  R2131     1
    z[4,5,5]  R2134     6.5626579523086548e-01
    z[4,5,5]  R2135     6.6537988185882568e-01
    z[4,5,5]  R2136     3.3398557454347610e-02
    z[4,5,5]  R2137     -5.4162133485078812e-02
    z[4,5,5]  R2138     4.6772268414497375e-01
    z[4,5,5]  R2139     1.5188623964786530e-01
    z[4,5,5]  R2140     -1.6468483209609985e-01
    z[4,5,5]  R2141     5.0029838085174561e-01
    z[4,5,5]  R2142     -1.1389130959287286e-03
    z[4,5,5]  R2143     -5.6748535484075546e-02
    z[4,5,5]  R2144     -6.2615203857421875e-01
    z[4,5,5]  R2145     1.6065572202205658e-01
    z[4,5,5]  R2146     6.4777636528015137e-01
    z[4,5,5]  R2147     -5.0720870494842529e-01
    z[4,5,5]  R2148     -3.6588084697723389e-01
    z[4,5,5]  R2149     7.4011576361954212e-03
    z[4,5,5]  R2150     -1.0231139510869980e-01
    z[4,5,5]  R2151     -3.2818627357482910e-01
    z[4,5,5]  R2152     -3.0741935968399048e-01
    z[4,5,5]  R2153     -4.0899041295051575e-01
    z[4,5,5]  R2154     1.0906521230936050e-01
    z[4,5,5]  R2155     2.3966281116008759e-01
    z[4,5,5]  R2156     3.5929358005523682e-01
    z[4,5,5]  R2157     3.1823945045471191e-01
    z[4,5,5]  R2158     2.2841575741767883e-01
    z[4,5,5]  R2159     -3.8880008459091187e-01
    z[4,5,5]  R2160     3.3971187472343445e-01
    z[4,5,5]  R2161     5.5800056457519531e-01
    z[4,5,5]  R2162     3.8121134042739868e-01
    z[4,5,5]  R2163     5.7679861783981323e-01
    z[4,5,5]  R2164     -1.6769881546497345e-01
    z[4,5,5]  R2165     -3.3462487161159515e-02
    z[4,5,5]  R2166     8.8889855146408081e-01
    z[4,5,5]  R2167     -2.6256833225488663e-02
    z[4,5,5]  R2168     1.5315471589565277e-01
    z[4,5,5]  R2169     -2.9874238371849060e-01
    z[4,5,5]  R2170     -5.6345868110656738e-01
    z[4,5,5]  R2171     9.4821535050868988e-02
    z[4,5,5]  R2172     -7.5947046279907227e-03
    z[4,5,5]  R2173     -8.7791271507740021e-03
    z[4,5,5]  R2174     3.1882032752037048e-01
    z[4,5,5]  R2175     -5.7182990014553070e-02
    z[4,5,5]  R2176     -1.6890972852706909e-01
    z[4,5,5]  R2177     -6.4772136509418488e-02
    z[4,5,5]  R2178     1.0017333924770355e-01
    z[4,5,5]  R2179     0.231211319565773
    z[4,5,5]  R2180     5.7747727632522583e-01
    z[4,5,5]  R2181     2.6583153009414673e-01
    z[4,5,5]  R2182     2.2481076419353485e-01
    z[4,5,5]  R2183     1.3052079826593399e-02
    z[4,5,5]  R2184     1.5171720087528229e-01
    z[4,5,5]  R2185     -4.3023936450481415e-02
    z[4,5,5]  R2186     0.0353940911591053
    z[4,5,5]  R2187     4.4357147812843323e-01
    z[4,5,5]  R2188     4.7407639026641846e-01
    z[4,5,5]  R2189     6.2767281197011471e-03
    z[4,5,5]  R2190     -1.9781421124935150e-01
    z[4,5,5]  R2191     -1.9604696333408356e-01
    z[4,5,5]  R2192     1.9839632511138916e-01
    z[4,5,5]  R2193     3.3862125873565674e-01
    z[4,5,5]  R2194     -3.0617916956543922e-02
    z[4,5,5]  R2195     2.9147979617118835e-01
    z[4,5,5]  R2196     -3.6393553018569946e-01
    z[4,5,5]  R2197     -4.2408636212348938e-01
    z[4,5,5]  R2198     -1.2743981555104256e-02
    z[4,5,5]  R2199     -1.8517075479030609e-01
    z[4,5,5]  R2200     -3.0390882492065430e-01
    z[4,5,5]  R2201     -2.0238092541694641e-01
    z[4,5,5]  R2202     1.9782733917236328e-01
    z[4,5,5]  R2203     -9.8644390702247620e-02
    z[4,5,5]  R2204     -0.148346409201622
    z[4,5,5]  R2205     -4.6158552169799805e-01
    z[4,5,5]  R2206     -2.9842260479927063e-01
    z[4,5,5]  R2207     -3.4983307123184204e-01
    z[4,5,5]  R2208     -0.377279132604599
    z[4,5,5]  R2209     3.8751029968261719e-01
    z[4,5,5]  R2210     2.0157396793365479e-02
    z[4,5,5]  R2211     -3.3282953500747681e-01
    z[4,5,5]  R2212     5.0642937421798706e-01
    z[4,5,5]  R2213     -4.5824404805898666e-02
    z[4,5,5]  R2214     -6.2417805194854736e-01
    z[4,5,5]  R2215     -0.0754033774137497
    z[4,5,5]  R2216     -6.4436845481395721e-02
    z[4,5,5]  R2217     1.9234506785869598e-01
    z[4,5,5]  R2218     2.7806267142295837e-01
    z[4,5,5]  R2219     -2.3896206170320511e-02
    z[4,5,5]  R2220     -4.7335988283157349e-01
    z[4,5,5]  R2221     6.2632042169570923e-01
    z[4,5,5]  R2222     1.9467703998088837e-01
    z[4,5,5]  R2223     -4.9738940596580505e-01
    z[4,5,5]  R2224     -2.1414436399936676e-02
    z[4,5,5]  R2225     3.2057842612266541e-01
    z[4,5,5]  R2226     3.8099128007888794e-01
    z[4,5,5]  R2227     -6.7592531442642212e-01
    z[4,5,5]  R2228     5.3517264127731323e-01
    z[4,5,5]  R2229     2.1830736100673676e-01
    z[4,5,5]  R2230     -6.1397127807140350e-02
    z[4,5,5]  R2231     -2.8867498040199280e-01
    z[4,5,5]  R2232     -4.4239038228988647e-01
    z[4,5,5]  R2233     -2.9919949173927307e-01
    z[4,5,5]  R2234     -1.6329869627952576e-01
    z[4,5,5]  R2235     -5.9690177440643311e-01
    z[4,5,5]  R2236     1.0459543205797672e-02
    z[4,5,5]  R2237     3.1147959828376770e-01
    z[4,5,5]  R2238     9.0109594166278839e-02
    z[4,5,5]  R2239     3.6661437153816223e-01
    z[4,5,5]  R2240     -4.7735314816236496e-02
    z[4,5,5]  R2241     -2.3951521515846252e-01
    z[4,5,5]  R2242     -7.1482270956039429e-02
    z[4,5,5]  R2243     1.4146538078784943e-01
    z[4,5,5]  R2244     4.1564801335334778e-01
    z[4,5,5]  R2245     5.2571278065443039e-02
    z[4,5,5]  R2246     -6.4349097013473511e-01
    z[4,5,5]  R2247     -1.4879024028778076e-01
    z[4,5,5]  R2248     -4.0760420262813568e-02
    z[4,5,5]  R2249     2.3870344460010529e-01
    z[4,5,5]  R2250     -9.2644453048706055e-02
    z[4,5,5]  R2251     -1.2771388888359070e-01
    z[4,5,5]  R2252     1.2331591546535492e-01
    z[4,5,5]  R2253     -1.2022284418344498e-01
    z[4,5,5]  R2254     0.382844477891922
    z[4,5,5]  R2255     -9.3877725303173065e-02
    z[4,5,5]  R2256     -8.1795983016490936e-02
    z[4,5,5]  R2257     1.7924067378044128e-01
    z[4,5,5]  R2258     1.5473881363868713e-01
    z[4,5,5]  R2259     1.0495068877935410e-01
    z[4,5,5]  R2260     -3.1709831953048706e-01
    z[4,5,5]  R2261     -2.2529639303684235e-01
    z[4,5,6]  R44       -1
    z[4,5,6]  R53       1
    z[4,5,6]  R2132     -1
    z[4,5,6]  R2133     1
    z[4,5,6]  R2134     9.7905740141868591e-02
    z[4,5,6]  R2135     4.9548465758562088e-02
    z[4,5,6]  R2136     -2.7058309316635132e-01
    z[4,5,6]  R2137     7.8890067338943481e-01
    z[4,5,6]  R2138     -2.9685431718826294e-01
    z[4,5,6]  R2139     -4.8208922147750854e-01
    z[4,5,6]  R2140     -7.2780676186084747e-02
    z[4,5,6]  R2141     2.2448913753032684e-01
    z[4,5,6]  R2142     -3.6659315228462219e-01
    z[4,5,6]  R2143     3.4811830520629883e-01
    z[4,5,6]  R2144     -1.2709483504295349e-01
    z[4,5,6]  R2145     -2.7647811919450760e-02
    z[4,5,6]  R2146     1.4032294973731041e-02
    z[4,5,6]  R2147     8.1678237766027451e-03
    z[4,5,6]  R2148     1.7205484211444855e-02
    z[4,5,6]  R2149     2.7510038018226624e-01
    z[4,5,6]  R2150     -1.1160384118556976e-01
    z[4,5,6]  R2151     5.5536616593599319e-02
    z[4,5,6]  R2152     0.102850541472435
    z[4,5,6]  R2153     -0.169743612408638
    z[4,5,6]  R2154     2.2508314251899719e-01
    z[4,5,6]  R2155     5.0840977579355240e-02
    z[4,5,6]  R2156     -3.4815722703933716e-01
    z[4,5,6]  R2157     1.5809737145900726e-02
    z[4,5,6]  R2158     2.1920089423656464e-01
    z[4,5,6]  R2159     -5.2649658173322678e-02
    z[4,5,6]  R2160     3.3853590488433838e-01
    z[4,5,6]  R2161     -1.3766942918300629e-01
    z[4,5,6]  R2162     -3.5886257886886597e-01
    z[4,5,6]  R2163     2.4111849069595337e-01
    z[4,5,6]  R2164     9.4328567385673523e-02
    z[4,5,6]  R2165     -3.5025981068611145e-01
    z[4,5,6]  R2166     -5.4601531475782394e-02
    z[4,5,6]  R2167     -1.1535544693470001e-01
    z[4,5,6]  R2168     3.6942100524902344e-01
    z[4,5,6]  R2169     1.6169679164886475e-01
    z[4,5,6]  R2170     2.3860198259353638e-01
    z[4,5,6]  R2171     -3.7413170933723450e-01
    z[4,5,6]  R2172     -1.4731016755104065e-01
    z[4,5,6]  R2173     -6.6391073167324066e-02
    z[4,5,6]  R2174     2.0331348478794098e-01
    z[4,5,6]  R2175     -8.5120923817157745e-02
    z[4,5,6]  R2176     -1.0575703531503677e-01
    z[4,5,6]  R2177     -0.09307861328125
    z[4,5,6]  R2178     2.4711626768112183e-01
    z[4,5,6]  R2179     2.0318250358104706e-01
    z[4,5,6]  R2180     -3.3131068944931030e-01
    z[4,5,6]  R2181     -6.8389378488063812e-02
    z[4,5,6]  R2182     3.6516536027193069e-02
    z[4,5,6]  R2183     0.0774056687951088
    z[4,5,6]  R2184     -1.4727701246738434e-01
    z[4,5,6]  R2185     -1.5174393355846405e-01
    z[4,5,6]  R2186     -4.7539597749710083e-01
    z[4,5,6]  R2187     2.2532801330089569e-01
    z[4,5,6]  R2188     8.6684837937355042e-02
    z[4,5,6]  R2189     3.5144168138504028e-01
    z[4,5,6]  R2190     -1.7987428605556488e-01
    z[4,5,6]  R2191     3.6844724416732788e-01
    z[4,5,6]  R2192     0.677962064743042
    z[4,5,6]  R2193     -5.9153027832508087e-02
    z[4,5,6]  R2194     0.919495165348053
    z[4,5,6]  R2195     0.814403235912323
    z[4,5,6]  R2196     -1.8726487457752228e-01
    z[4,5,6]  R2197     3.9939272403717041e-01
    z[4,5,6]  R2198     2.7433177828788757e-01
    z[4,5,6]  R2199     -3.4588745236396790e-01
    z[4,5,6]  R2200     5.4620647430419922e-01
    z[4,5,6]  R2201     -1.9505728781223297e-01
    z[4,5,6]  R2202     2.5381517410278320e-01
    z[4,5,6]  R2203     3.0845694709569216e-03
    z[4,5,6]  R2204     -0.074495330452919
    z[4,5,6]  R2205     -2.7877295017242432e-01
    z[4,5,6]  R2206     -3.9746654033660889e-01
    z[4,5,6]  R2207     -5.3462157957255840e-03
    z[4,5,6]  R2208     4.3215584754943848e-01
    z[4,5,6]  R2209     -8.3619892597198486e-02
    z[4,5,6]  R2210     -2.7281185984611511e-01
    z[4,5,6]  R2211     -3.6632496118545532e-01
    z[4,5,6]  R2212     1.1175787448883057e-01
    z[4,5,6]  R2213     -8.6105622351169586e-02
    z[4,5,6]  R2214     -3.7456639111042023e-02
    z[4,5,6]  R2215     3.1134110689163208e-01
    z[4,5,6]  R2216     2.9562366008758545e-01
    z[4,5,6]  R2217     -8.3799540996551514e-02
    z[4,5,6]  R2218     -2.8917360305786133e-01
    z[4,5,6]  R2219     -3.4714111685752869e-01
    z[4,5,6]  R2220     1.2736445665359497e-01
    z[4,5,6]  R2221     -6.8762958049774170e-02
    z[4,5,6]  R2222     -1.6143139451742172e-02
    z[4,5,6]  R2223     2.1712635457515717e-01
    z[4,5,6]  R2224     1.1941968649625778e-01
    z[4,5,6]  R2225     2.5954738259315491e-01
    z[4,5,6]  R2226     -6.4274176955223083e-02
    z[4,5,6]  R2227     -3.3101800829172134e-02
    z[4,5,6]  R2228     -1.3286098837852478e-01
    z[4,5,6]  R2229     -1.1625555902719498e-01
    z[4,5,6]  R2230     -3.4496295452117920e-01
    z[4,5,6]  R2231     2.6258850097656250e-01
    z[4,5,6]  R2232     1.3789756596088409e-01
    z[4,5,6]  R2233     5.6865904480218887e-02
    z[4,5,6]  R2234     -2.2241444885730743e-01
    z[4,5,6]  R2235     0.195271834731102
    z[4,5,6]  R2236     -3.7824764847755432e-01
    z[4,5,6]  R2237     3.0041828751564026e-01
    z[4,5,6]  R2238     -3.9020174741744995e-01
    z[4,5,6]  R2239     -4.0451325476169586e-02
    z[4,5,6]  R2240     2.4714720249176025e-01
    z[4,5,6]  R2241     -7.1370363235473633e-01
    z[4,5,6]  R2242     6.2678046524524689e-02
    z[4,5,6]  R2243     3.5645064711570740e-01
    z[4,5,6]  R2244     -3.4316653013229370e-01
    z[4,5,6]  R2245     -3.2001107465475798e-03
    z[4,5,6]  R2246     -3.3547705411911011e-01
    z[4,5,6]  R2247     2.5705745816230774e-01
    z[4,5,6]  R2248     1.5021668374538422e-01
    z[4,5,6]  R2249     -3.2108661532402039e-01
    z[4,5,6]  R2250     1.7515990138053894e-01
    z[4,5,6]  R2251     -6.1666302382946014e-02
    z[4,5,6]  R2252     -8.5834875702857971e-02
    z[4,5,6]  R2253     2.0520697534084320e-01
    z[4,5,6]  R2254     -4.5186918228864670e-02
    z[4,5,6]  R2255     2.4321815371513367e-01
    z[4,5,6]  R2256     -1.5244592726230621e-01
    z[4,5,6]  R2257     -2.7870634198188782e-01
    z[4,5,6]  R2258     1.2779383361339569e-01
    z[4,5,6]  R2259     -3.3953779935836792e-01
    z[4,5,6]  R2260     -0.440801203250885
    z[4,5,6]  R2261     -3.7467747926712036e-02
    z[5,4,0]  R38       1
    z[5,4,0]  R47       -1
    z[5,4,0]  R2262     -1
    z[5,4,0]  R2263     1
    z[5,4,0]  R2276     7.5943458080291748e-01
    z[5,4,0]  R2277     8.6767166852951050e-01
    z[5,4,0]  R2278     7.3249679803848267e-01
    z[5,4,0]  R2279     6.8604403734207153e-01
    z[5,4,0]  R2280     -4.4286161661148071e-01
    z[5,4,0]  R2281     -5.4820311069488525e-01
    z[5,4,0]  R2282     8.8026702404022217e-01
    z[5,4,0]  R2283     6.8000304698944092e-01
    z[5,4,0]  R2284     1.1706885695457458e-01
    z[5,4,0]  R2285     6.7970955371856689e-01
    z[5,4,0]  R2286     -7.2851979732513428e-01
    z[5,4,0]  R2287     -5.3250616788864136e-01
    z[5,4,0]  R2288     -4.5595401525497437e-01
    z[5,4,0]  R2289     -4.3952351808547974e-01
    z[5,4,0]  R2290     -4.3826425075531006e-01
    z[5,4,0]  R2291     -4.2607232928276062e-01
    z[5,4,0]  R2292     -4.5474034547805786e-01
    z[5,4,0]  R2293     -0.492642879486084
    z[5,4,0]  R2294     -3.5169291496276855e-01
    z[5,4,0]  R2295     -4.2849314212799072e-01
    z[5,4,0]  R2296     -1.8124037981033325e-01
    z[5,4,0]  R2297     1.0111644119024277e-01
    z[5,4,0]  R2298     -1.4891627430915833e-01
    z[5,4,0]  R2299     -3.5820782184600830e-01
    z[5,4,0]  R2300     1.6601191833615303e-02
    z[5,4,0]  R2301     -9.0139172971248627e-02
    z[5,4,0]  R2302     9.9790267646312714e-02
    z[5,4,0]  R2303     -5.5877542495727539e-01
    z[5,4,0]  R2304     -6.8435692787170410e-01
    z[5,4,0]  R2305     0.591355562210083
    z[5,4,0]  R2306     -0.634787917137146
    z[5,4,0]  R2307     -4.2726138234138489e-01
    z[5,4,0]  R2308     1.2502075731754303e-01
    z[5,4,0]  R2309     3.1266176700592041e-01
    z[5,4,0]  R2310     3.5332730412483215e-01
    z[5,4,0]  R2311     -8.6019468307495117e-01
    z[5,4,0]  R2312     -0.551559567451477
    z[5,4,0]  R2313     0.562705397605896
    z[5,4,0]  R2314     5.3335338830947876e-01
    z[5,4,0]  R2315     5.8284366130828857e-01
    z[5,4,0]  R2316     -1.4608344435691833e-01
    z[5,4,0]  R2317     4.0938743948936462e-01
    z[5,4,0]  R2318     1.8510198593139648e-01
    z[5,4,0]  R2319     2.6271072030067444e-01
    z[5,4,0]  R2320     5.9153407812118530e-01
    z[5,4,0]  R2321     2.2646707296371460e-01
    z[5,4,0]  R2322     5.1118308305740356e-01
    z[5,4,0]  R2323     -8.3527660369873047e-01
    z[5,4,0]  R2324     -4.7554358839988708e-01
    z[5,4,0]  R2325     -5.4265040159225464e-01
    z[5,4,0]  R2326     4.9199834465980530e-01
    z[5,4,0]  R2327     6.2315154075622559e-01
    z[5,4,0]  R2328     -5.2788324654102325e-02
    z[5,4,0]  R2329     4.3013170361518860e-01
    z[5,4,0]  R2330     0.500211238861084
    z[5,4,0]  R2331     -4.3523499369621277e-01
    z[5,4,0]  R2332     -5.9402501583099365e-01
    z[5,4,0]  R2333     -0.832075297832489
    z[5,4,0]  R2334     -5.5556356906890869e-01
    z[5,4,0]  R2335     -8.5553938150405884e-01
    z[5,4,0]  R2336     -7.5360065698623657e-01
    z[5,4,0]  R2337     7.5770670175552368e-01
    z[5,4,0]  R2338     1.5656508505344391e-01
    z[5,4,0]  R2339     -2.8213843703269958e-01
    z[5,4,0]  R2340     -2.8486687690019608e-02
    z[5,4,0]  R2341     4.7304117679595947e-01
    z[5,4,0]  R2342     -8.5314494371414185e-01
    z[5,4,0]  R2343     -6.6401398181915283e-01
    z[5,4,0]  R2344     -9.0782427787780762e-01
    z[5,4,0]  R2345     -6.1012154817581177e-01
    z[5,4,0]  R2346     5.7783633470535278e-01
    z[5,4,0]  R2347     4.4784688949584961e-01
    z[5,4,0]  R2348     -4.8408564925193787e-01
    z[5,4,0]  R2349     -0.672747015953064
    z[5,4,0]  R2350     -4.9150905013084412e-01
    z[5,4,0]  R2351     5.8502227067947388e-01
    z[5,4,0]  R2352     6.6070383787155151e-01
    z[5,4,0]  R2353     6.8326950073242188e-01
    z[5,4,0]  R2354     6.8778365850448608e-01
    z[5,4,0]  R2355     6.7371368408203125e-01
    z[5,4,0]  R2356     -8.9634925127029419e-01
    z[5,4,0]  R2357     5.8706700801849365e-01
    z[5,4,0]  R2358     6.3879698514938354e-01
    z[5,4,0]  R2359     6.2776446342468262e-01
    z[5,4,0]  R2360     4.9042728543281555e-01
    z[5,4,0]  R2361     -4.4271769002079964e-03
    z[5,4,0]  R2362     3.7055447697639465e-02
    z[5,4,0]  R2363     5.4906487464904785e-01
    z[5,4,0]  R2364     5.7185983657836914e-01
    z[5,4,0]  R2365     2.9208138585090637e-01
    z[5,4,0]  R2366     2.4657995998859406e-01
    z[5,4,0]  R2367     0.255929559469223
    z[5,4,0]  R2368     -1.8523028492927551e-01
    z[5,4,0]  R2369     -1.6787399351596832e-01
    z[5,4,0]  R2370     -3.2924351096153259e-01
    z[5,4,0]  R2371     -4.7347900271415710e-01
    z[5,4,0]  R2372     9.0349888801574707e-01
    z[5,4,0]  R2373     -3.5524335503578186e-01
    z[5,4,0]  R2374     8.7765812873840332e-01
    z[5,4,0]  R2375     8.9711707830429077e-01
    z[5,4,0]  R2376     8.5212677717208862e-02
    z[5,4,0]  R2377     -8.4351825714111328e-01
    z[5,4,0]  R2378     4.9002498388290405e-01
    z[5,4,0]  R2379     -7.4569523334503174e-01
    z[5,4,0]  R2380     2.5136426091194153e-01
    z[5,4,0]  R2381     -5.4509627819061279e-01
    z[5,4,0]  R2382     -5.5023926496505737e-01
    z[5,4,0]  R2383     -5.0054174661636353e-01
    z[5,4,0]  R2384     -5.7826393842697144e-01
    z[5,4,0]  R2385     -5.1791024208068848e-01
    z[5,4,0]  R2386     -7.3025655746459961e-01
    z[5,4,0]  R2387     -7.3584026098251343e-01
    z[5,4,0]  R2388     -0.660832405090332
    z[5,4,0]  R2389     -6.5865439176559448e-01
    z[5,4,0]  R2390     5.3700363636016846e-01
    z[5,4,0]  R2391     5.1652848720550537e-01
    z[5,4,0]  R2392     4.7987800836563110e-01
    z[5,4,0]  R2393     2.9732385277748108e-01
    z[5,4,0]  R2394     3.5026237368583679e-01
    z[5,4,0]  R2395     4.0412786602973938e-01
    z[5,4,0]  R2396     8.9487487077713013e-01
    z[5,4,0]  R2397     5.7791447639465332e-01
    z[5,4,0]  R2398     3.3423185348510742e-01
    z[5,4,0]  R2399     3.9829817414283752e-01
    z[5,4,0]  R2400     3.0566087365150452e-01
    z[5,4,0]  R2401     3.0863767862319946e-01
    z[5,4,0]  R2402     2.8419691324234009e-01
    z[5,4,0]  R2403     -3.2681086659431458e-01
    z[5,4,1]  R39       1
    z[5,4,1]  R48       -1
    z[5,4,1]  R2264     -1
    z[5,4,1]  R2265     1
    z[5,4,1]  R2276     5.1057547330856323e-01
    z[5,4,1]  R2277     3.1768313050270081e-01
    z[5,4,1]  R2278     4.8648440837860107e-01
    z[5,4,1]  R2279     4.7185283899307251e-01
    z[5,4,1]  R2280     4.4452327489852905e-01
    z[5,4,1]  R2281     -4.0931418538093567e-02
    z[5,4,1]  R2282     3.4900563955307007e-01
    z[5,4,1]  R2283     4.5200872421264648e-01
    z[5,4,1]  R2284     6.1654180288314819e-01
    z[5,4,1]  R2285     3.8457027077674866e-01
    z[5,4,1]  R2286     2.4004091322422028e-01
    z[5,4,1]  R2287     -4.3289753794670105e-01
    z[5,4,1]  R2288     -0.192816823720932
    z[5,4,1]  R2289     -2.1364213526248932e-01
    z[5,4,1]  R2290     -2.2704876959323883e-01
    z[5,4,1]  R2291     -2.5199401378631592e-01
    z[5,4,1]  R2292     -2.0157837867736816e-01
    z[5,4,1]  R2293     -1.9670151174068451e-01
    z[5,4,1]  R2294     -2.3894466459751129e-01
    z[5,4,1]  R2295     -2.3336625099182129e-01
    z[5,4,1]  R2296     3.4802475571632385e-01
    z[5,4,1]  R2297     7.8177338838577271e-01
    z[5,4,1]  R2298     2.4236483871936798e-01
    z[5,4,1]  R2299     1.7813818156719208e-01
    z[5,4,1]  R2300     8.5366815328598022e-01
    z[5,4,1]  R2301     6.6496598720550537e-01
    z[5,4,1]  R2302     3.4388515353202820e-01
    z[5,4,1]  R2303     -3.1246135011315346e-02
    z[5,4,1]  R2304     -1.8710640072822571e-01
    z[5,4,1]  R2305     -7.2522288560867310e-01
    z[5,4,1]  R2306     5.2543687820434570e-01
    z[5,4,1]  R2307     5.8598470687866211e-01
    z[5,4,1]  R2308     0.849338948726654
    z[5,4,1]  R2309     7.1854478120803833e-01
    z[5,4,1]  R2310     4.8190990090370178e-01
    z[5,4,1]  R2311     -1.8543800711631775e-01
    z[5,4,1]  R2312     -3.7781310081481934e-01
    z[5,4,1]  R2313     -5.2031236886978149e-01
    z[5,4,1]  R2314     -6.2621653079986572e-01
    z[5,4,1]  R2315     1.9602222368121147e-02
    z[5,4,1]  R2316     7.7178794145584106e-01
    z[5,4,1]  R2317     7.8734922409057617e-01
    z[5,4,1]  R2318     6.1397576332092285e-01
    z[5,4,1]  R2319     8.8871586322784424e-01
    z[5,4,1]  R2320     0.267733097076416
    z[5,4,1]  R2321     3.3866789937019348e-01
    z[5,4,1]  R2322     5.2049368619918823e-01
    z[5,4,1]  R2323     -1.1216162145137787e-01
    z[5,4,1]  R2324     3.0052950978279114e-01
    z[5,4,1]  R2325     -3.2113844156265259e-01
    z[5,4,1]  R2326     4.7029018402099609e-01
    z[5,4,1]  R2327     3.7659695744514465e-01
    z[5,4,1]  R2328     0.0677233412861824
    z[5,4,1]  R2329     1.5144044160842896e-01
    z[5,4,1]  R2330     5.7834458351135254e-01
    z[5,4,1]  R2331     5.1786535978317261e-01
    z[5,4,1]  R2332     -2.8375563025474548e-01
    z[5,4,1]  R2333     -3.4214520454406738e-01
    z[5,4,1]  R2334     -3.3144152164459229e-01
    z[5,4,1]  R2335     -0.0317201092839241
    z[5,4,1]  R2336     1.1143982410430908e-01
    z[5,4,1]  R2337     4.7424244880676270e-01
    z[5,4,1]  R2338     8.5829752683639526e-01
    z[5,4,1]  R2339     3.1502538919448853e-01
    z[5,4,1]  R2340     4.6628189086914062e-01
    z[5,4,1]  R2341     5.6245517730712891e-01
    z[5,4,1]  R2342     -2.7969694137573242e-01
    z[5,4,1]  R2343     -4.1869038343429565e-01
    z[5,4,1]  R2344     -2.2984184324741364e-01
    z[5,4,1]  R2345     -3.1074598431587219e-02
    z[5,4,1]  R2346     7.8660178184509277e-01
    z[5,4,1]  R2347     6.3052386045455933e-01
    z[5,4,1]  R2348     1.7272271215915680e-01
    z[5,4,1]  R2349     -3.2018333673477173e-01
    z[5,4,1]  R2350     -2.6289907097816467e-01
    z[5,4,1]  R2351     -3.7370449304580688e-01
    z[5,4,1]  R2352     -5.1204943656921387e-01
    z[5,4,1]  R2353     -3.6264434456825256e-01
    z[5,4,1]  R2354     -5.7322126626968384e-01
    z[5,4,1]  R2355     -4.6222689747810364e-01
    z[5,4,1]  R2356     -9.9885143339633942e-02
    z[5,4,1]  R2357     -4.1757720708847046e-01
    z[5,4,1]  R2358     -5.2153486013412476e-01
    z[5,4,1]  R2359     -5.8511340618133545e-01
    z[5,4,1]  R2360     -6.2838965654373169e-01
    z[5,4,1]  R2361     -7.2098881006240845e-01
    z[5,4,1]  R2362     -8.9664030075073242e-01
    z[5,4,1]  R2363     -5.7314264774322510e-01
    z[5,4,1]  R2364     -4.7685539722442627e-01
    z[5,4,1]  R2365     -5.5895823240280151e-01
    z[5,4,1]  R2366     2.5135436654090881e-01
    z[5,4,1]  R2367     0.420491099357605
    z[5,4,1]  R2368     2.5548499822616577e-01
    z[5,4,1]  R2369     2.3999880254268646e-01
    z[5,4,1]  R2370     3.7604832649230957e-01
    z[5,4,1]  R2371     -4.3337881565093994e-01
    z[5,4,1]  R2372     -8.1412322819232941e-02
    z[5,4,1]  R2373     4.7677550464868546e-02
    z[5,4,1]  R2374     -2.4651013314723969e-01
    z[5,4,1]  R2375     9.0749554336071014e-02
    z[5,4,1]  R2376     7.1628761291503906e-01
    z[5,4,1]  R2377     8.1906437873840332e-02
    z[5,4,1]  R2378     -2.1238750219345093e-01
    z[5,4,1]  R2379     3.3670984208583832e-02
    z[5,4,1]  R2380     -4.5006313920021057e-01
    z[5,4,1]  R2381     -2.9721334576606750e-01
    z[5,4,1]  R2382     -4.0150359272956848e-01
    z[5,4,1]  R2383     -3.8969784975051880e-01
    z[5,4,1]  R2384     -3.7562859058380127e-01
    z[5,4,1]  R2385     -3.1049597263336182e-01
    z[5,4,1]  R2386     3.8402697443962097e-01
    z[5,4,1]  R2387     -2.2488430142402649e-01
    z[5,4,1]  R2388     -2.9133029282093048e-02
    z[5,4,1]  R2389     -3.5321453213691711e-01
    z[5,4,1]  R2390     -4.7083371877670288e-01
    z[5,4,1]  R2391     -3.0634710192680359e-01
    z[5,4,1]  R2392     -4.5350956916809082e-01
    z[5,4,1]  R2393     -2.1151988208293915e-01
    z[5,4,1]  R2394     -1.7822524905204773e-01
    z[5,4,1]  R2395     2.1170638501644135e-01
    z[5,4,1]  R2396     -2.2562728822231293e-01
    z[5,4,1]  R2397     -5.6426286697387695e-02
    z[5,4,1]  R2398     -1.3580378890037537e-01
    z[5,4,1]  R2399     4.9179205298423767e-01
    z[5,4,1]  R2400     3.1875270605087280e-01
    z[5,4,1]  R2401     2.9287168383598328e-01
    z[5,4,1]  R2402     3.4953951835632324e-01
    z[5,4,1]  R2403     -2.0246687531471252e-01
    z[5,4,2]  R40       1
    z[5,4,2]  R49       -1
    z[5,4,2]  R2266     -1
    z[5,4,2]  R2267     1
    z[5,4,2]  R2276     0.225607231259346
    z[5,4,2]  R2277     3.1976962089538574e-01
    z[5,4,2]  R2278     2.1875400841236115e-01
    z[5,4,2]  R2279     4.4502955675125122e-01
    z[5,4,2]  R2280     -4.7080716490745544e-01
    z[5,4,2]  R2281     -4.1226577758789062e-01
    z[5,4,2]  R2282     1.5544793009757996e-01
    z[5,4,2]  R2283     3.5547360777854919e-01
    z[5,4,2]  R2284     -3.2983991503715515e-01
    z[5,4,2]  R2285     4.8570439219474792e-01
    z[5,4,2]  R2286     2.3494124412536621e-01
    z[5,4,2]  R2287     6.5841847658157349e-01
    z[5,4,2]  R2288     8.0758494138717651e-01
    z[5,4,2]  R2289     6.8192929029464722e-01
    z[5,4,2]  R2290     6.5245223045349121e-01
    z[5,4,2]  R2291     6.6472548246383667e-01
    z[5,4,2]  R2292     0.639353334903717
    z[5,4,2]  R2293     6.3165879249572754e-01
    z[5,4,2]  R2294     7.7503788471221924e-01
    z[5,4,2]  R2295     5.7745563983917236e-01
    z[5,4,2]  R2296     2.3937088251113892e-01
    z[5,4,2]  R2297     2.8595605492591858e-01
    z[5,4,2]  R2298     -4.6420689672231674e-02
    z[5,4,2]  R2299     -2.5077894330024719e-01
    z[5,4,2]  R2300     1.2380032241344452e-01
    z[5,4,2]  R2301     -3.7403452396392822e-01
    z[5,4,2]  R2302     -7.1206778287887573e-01
    z[5,4,2]  R2303     -4.7657048702239990e-01
    z[5,4,2]  R2304     -2.1853515505790710e-01
    z[5,4,2]  R2305     -5.7819854468107224e-02
    z[5,4,2]  R2306     -4.0094745159149170e-01
    z[5,4,2]  R2307     -6.7131072282791138e-01
    z[5,4,2]  R2308     -4.1002368927001953e-01
    z[5,4,2]  R2309     -2.6114150881767273e-01
    z[5,4,2]  R2310     4.2280846834182739e-01
    z[5,4,2]  R2311     -2.4369031190872192e-01
    z[5,4,2]  R2312     0.328095406293869
    z[5,4,2]  R2313     3.8787674903869629e-01
    z[5,4,2]  R2314     2.9203245043754578e-01
    z[5,4,2]  R2315     -2.7586886286735535e-01
    z[5,4,2]  R2316     -2.2261705994606018e-01
    z[5,4,2]  R2317     3.4349447488784790e-01
    z[5,4,2]  R2318     -1.4417226612567902e-01
    z[5,4,2]  R2319     -1.2380160391330719e-01
    z[5,4,2]  R2320     -0.395833283662796
    z[5,4,2]  R2321     2.3510010540485382e-01
    z[5,4,2]  R2322     -2.0400816202163696e-01
    z[5,4,2]  R2323     -9.6323236823081970e-02
    z[5,4,2]  R2324     3.9766165614128113e-01
    z[5,4,2]  R2325     2.9063206911087036e-01
    z[5,4,2]  R2326     6.3487243652343750e-01
    z[5,4,2]  R2327     3.7208899855613708e-01
    z[5,4,2]  R2328     1.3445743918418884e-01
    z[5,4,2]  R2329     -4.3952378630638123e-01
    z[5,4,2]  R2330     -2.9135462641716003e-01
    z[5,4,2]  R2331     0.0922401174902916
    z[5,4,2]  R2332     4.4079285860061646e-01
    z[5,4,2]  R2333     -3.1065413355827332e-01
    z[5,4,2]  R2334     0.355376273393631
    z[5,4,2]  R2335     1.2634010612964630e-01
    z[5,4,2]  R2336     -4.2379835247993469e-01
    z[5,4,2]  R2337     3.0889004468917847e-01
    z[5,4,2]  R2338     -3.6990982294082642e-01
    z[5,4,2]  R2339     3.5622832179069519e-01
    z[5,4,2]  R2340     -4.7861674427986145e-01
    z[5,4,2]  R2341     -1.3612095499411225e-03
    z[5,4,2]  R2342     -1.4447963237762451e-01
    z[5,4,2]  R2343     2.8854611515998840e-01
    z[5,4,2]  R2344     2.1654902398586273e-01
    z[5,4,2]  R2345     6.2843970954418182e-02
    z[5,4,2]  R2346     -1.7592564225196838e-01
    z[5,4,2]  R2347     2.0112448930740356e-01
    z[5,4,2]  R2348     3.3232292532920837e-01
    z[5,4,2]  R2349     4.4547894597053528e-01
    z[5,4,2]  R2350     3.8438367843627930e-01
    z[5,4,2]  R2351     5.4896640777587891e-01
    z[5,4,2]  R2352     5.2453732490539551e-01
    z[5,4,2]  R2353     2.7125416323542595e-02
    z[5,4,2]  R2354     1.1758831888437271e-01
    z[5,4,2]  R2355     -1.3787375390529633e-01
    z[5,4,2]  R2356     -1.0769053548574448e-01
    z[5,4,2]  R2357     5.5269473791122437e-01
    z[5,4,2]  R2358     1.5828667581081390e-01
    z[5,4,2]  R2359     3.8291251659393311e-01
    z[5,4,2]  R2360     5.5537527799606323e-01
    z[5,4,2]  R2361     0.521673321723938
    z[5,4,2]  R2362     3.5263195633888245e-01
    z[5,4,2]  R2363     5.3273621946573257e-02
    z[5,4,2]  R2364     2.5538769364356995e-01
    z[5,4,2]  R2365     -2.4770677089691162e-01
    z[5,4,2]  R2366     3.3723658323287964e-01
    z[5,4,2]  R2367     2.1254646778106689e-01
    z[5,4,2]  R2368     3.6979696154594421e-01
    z[5,4,2]  R2369     -3.9338001608848572e-01
    z[5,4,2]  R2370     -2.5375235080718994e-01
    z[5,4,2]  R2371     -4.0026667714118958e-01
    z[5,4,2]  R2372     -1.8174979090690613e-01
    z[5,4,2]  R2373     -7.2701007127761841e-01
    z[5,4,2]  R2374     6.9238655269145966e-02
    z[5,4,2]  R2375     -1.9710262119770050e-01
    z[5,4,2]  R2376     5.6447625160217285e-02
    z[5,4,2]  R2377     2.0022470504045486e-02
    z[5,4,2]  R2378     1.3306963443756104e-01
    z[5,4,2]  R2379     -1.9731815159320831e-01
    z[5,4,2]  R2380     -5.8517616987228394e-01
    z[5,4,2]  R2381     6.3593953847885132e-01
    z[5,4,2]  R2382     5.4929924011230469e-01
    z[5,4,2]  R2383     5.8574265241622925e-01
    z[5,4,2]  R2384     4.4907850027084351e-01
    z[5,4,2]  R2385     5.3506422042846680e-01
    z[5,4,2]  R2386     -4.1943371295928955e-01
    z[5,4,2]  R2387     -3.1705504655838013e-01
    z[5,4,2]  R2388     -5.5717867612838745e-01
    z[5,4,2]  R2389     -3.3449560403823853e-01
    z[5,4,2]  R2390     -5.0315749645233154e-01
    z[5,4,2]  R2391     -3.1380680203437805e-01
    z[5,4,2]  R2392     1.7505396157503128e-02
    z[5,4,2]  R2393     -6.4479392766952515e-01
    z[5,4,2]  R2394     -5.8811032772064209e-01
    z[5,4,2]  R2395     4.3414118885993958e-01
    z[5,4,2]  R2396     -1.1416142433881760e-01
    z[5,4,2]  R2397     -4.8208889365196228e-01
    z[5,4,2]  R2398     -2.0556335151195526e-01
    z[5,4,2]  R2399     7.0926159620285034e-01
    z[5,4,2]  R2400     0.772919774055481
    z[5,4,2]  R2401     7.5071024894714355e-01
    z[5,4,2]  R2402     6.2224715948104858e-01
    z[5,4,2]  R2403     7.0781558752059937e-01
    z[5,4,3]  R41       1
    z[5,4,3]  R50       -1
    z[5,4,3]  R2268     -1
    z[5,4,3]  R2269     1
    z[5,4,3]  R2276     2.8614804148674011e-01
    z[5,4,3]  R2277     1.9862221181392670e-01
    z[5,4,3]  R2278     9.6923463046550751e-02
    z[5,4,3]  R2279     1.0683256387710571e-01
    z[5,4,3]  R2280     -3.4418621659278870e-01
    z[5,4,3]  R2281     -3.7811005115509033e-01
    z[5,4,3]  R2282     7.2333104908466339e-02
    z[5,4,3]  R2283     -1.9786326587200165e-01
    z[5,4,3]  R2284     -1.4166752994060516e-01
    z[5,4,3]  R2285     -8.8863588869571686e-02
    z[5,4,3]  R2286     -1.4615970849990845e-01
    z[5,4,3]  R2287     2.3510551452636719e-01
    z[5,4,3]  R2288     8.4521457552909851e-02
    z[5,4,3]  R2289     4.4326889514923096e-01
    z[5,4,3]  R2290     3.0297595262527466e-01
    z[5,4,3]  R2291     -6.4370416104793549e-02
    z[5,4,3]  R2292     2.6252093911170959e-01
    z[5,4,3]  R2293     2.3608949780464172e-01
    z[5,4,3]  R2294     -0.383390337228775
    z[5,4,3]  R2295     4.6426522731781006e-01
    z[5,4,3]  R2296     -5.3112649917602539e-01
    z[5,4,3]  R2297     -1.9288714230060577e-01
    z[5,4,3]  R2298     -2.5173398852348328e-01
    z[5,4,3]  R2299     -1.6380971670150757e-01
    z[5,4,3]  R2300     -9.9699504673480988e-02
    z[5,4,3]  R2301     1.8503373861312866e-01
    z[5,4,3]  R2302     5.2364283800125122e-01
    z[5,4,3]  R2303     5.2530074119567871e-01
    z[5,4,3]  R2304     1.2904337048530579e-01
    z[5,4,3]  R2305     -1.1997362226247787e-01
    z[5,4,3]  R2306     -2.3272280395030975e-01
    z[5,4,3]  R2307     4.1645620018243790e-02
    z[5,4,3]  R2308     2.0353603363037109e-01
    z[5,4,3]  R2309     1.6257666051387787e-01
    z[5,4,3]  R2310     -4.2788782715797424e-01
    z[5,4,3]  R2311     1.0887966305017471e-01
    z[5,4,3]  R2312     -2.7930095791816711e-01
    z[5,4,3]  R2313     -1.5871591866016388e-01
    z[5,4,3]  R2314     -0.0847240760922432
    z[5,4,3]  R2315     2.6343245059251785e-02
    z[5,4,3]  R2316     -2.5393217802047729e-01
    z[5,4,3]  R2317     -2.6008498668670654e-01
    z[5,4,3]  R2318     -2.3698411881923676e-01
    z[5,4,3]  R2319     -1.5202210843563080e-01
    z[5,4,3]  R2320     -5.7442313432693481e-01
    z[5,4,3]  R2321     -6.6975212097167969e-01
    z[5,4,3]  R2322     4.0605121850967407e-01
    z[5,4,3]  R2323     1.2707798182964325e-01
    z[5,4,3]  R2324     -5.3396087884902954e-01
    z[5,4,3]  R2325     -8.2362376153469086e-02
    z[5,4,3]  R2326     -4.7547496855258942e-02
    z[5,4,3]  R2327     0.0390746146440506
    z[5,4,3]  R2328     -7.0815253257751465e-01
    z[5,4,3]  R2329     -1.5038779377937317e-01
    z[5,4,3]  R2330     3.5058364272117615e-01
    z[5,4,3]  R2331     -1.2800544500350952e-01
    z[5,4,3]  R2332     1.1343742907047272e-01
    z[5,4,3]  R2333     1.1935079097747803e-01
    z[5,4,3]  R2334     2.7844834327697754e-01
    z[5,4,3]  R2335     3.0967876315116882e-01
    z[5,4,3]  R2336     -8.1400223076343536e-02
    z[5,4,3]  R2337     2.4099707603454590e-02
    z[5,4,3]  R2338     -5.8336075395345688e-02
    z[5,4,3]  R2339     -5.3081786632537842e-01
    z[5,4,3]  R2340     -3.9032605290412903e-01
    z[5,4,3]  R2341     -3.8091403245925903e-01
    z[5,4,3]  R2342     -1.1232873797416687e-01
    z[5,4,3]  R2343     2.5902670621871948e-01
    z[5,4,3]  R2344     -5.9855529107153416e-03
    z[5,4,3]  R2345     -2.2981157898902893e-01
    z[5,4,3]  R2346     0.0851278305053711
    z[5,4,3]  R2347     -4.1740727424621582e-01
    z[5,4,3]  R2348     -5.7617175579071045e-01
    z[5,4,3]  R2349     -4.9353456497192383e-01
    z[5,4,3]  R2350     1.1958824843168259e-01
    z[5,4,3]  R2351     -2.5140696763992310e-01
    z[5,4,3]  R2352     4.2824551463127136e-02
    z[5,4,3]  R2353     -3.0461966991424561e-02
    z[5,4,3]  R2354     0.380967378616333
    z[5,4,3]  R2355     1.2610933184623718e-01
    z[5,4,3]  R2356     6.9487184286117554e-02
    z[5,4,3]  R2357     -2.3484340310096741e-01
    z[5,4,3]  R2358     -4.0507983416318893e-02
    z[5,4,3]  R2359     2.1431854367256165e-01
    z[5,4,3]  R2360     -8.1822186708450317e-02
    z[5,4,3]  R2361     -2.6592493057250977e-01
    z[5,4,3]  R2362     -7.9549968242645264e-02
    z[5,4,3]  R2363     4.8030912876129150e-01
    z[5,4,3]  R2364     2.9239574074745178e-01
    z[5,4,3]  R2365     5.8321475982666016e-01
    z[5,4,3]  R2366     1.9407291710376740e-01
    z[5,4,3]  R2367     3.7785834074020386e-01
    z[5,4,3]  R2368     0.359621524810791
    z[5,4,3]  R2369     3.5334849357604980e-01
    z[5,4,3]  R2370     -5.9966671466827393e-01
    z[5,4,3]  R2371     3.5166677832603455e-01
    z[5,4,3]  R2372     -1.7718973755836487e-01
    z[5,4,3]  R2373     -1.7114609479904175e-01
    z[5,4,3]  R2374     1.0475947707891464e-01
    z[5,4,3]  R2375     -1.4726942777633667e-01
    z[5,4,3]  R2376     -7.2947158478200436e-03
    z[5,4,3]  R2377     9.5679499208927155e-02
    z[5,4,3]  R2378     3.3502838015556335e-01
    z[5,4,3]  R2379     -1.4262425899505615e-01
    z[5,4,3]  R2380     3.4569406509399414e-01
    z[5,4,3]  R2381     -1.8511952459812164e-01
    z[5,4,3]  R2382     1.8296670913696289e-01
    z[5,4,3]  R2383     2.8348726034164429e-01
    z[5,4,3]  R2384     -1.3576443493366241e-01
    z[5,4,3]  R2385     1.6956056654453278e-01
    z[5,4,3]  R2386     -4.3668370693922043e-02
    z[5,4,3]  R2387     2.3234169185161591e-01
    z[5,4,3]  R2388     4.1011381894350052e-02
    z[5,4,3]  R2389     3.1981386244297028e-02
    z[5,4,3]  R2390     0.309207946062088
    z[5,4,3]  R2391     3.5993787646293640e-01
    z[5,4,3]  R2392     5.1507014036178589e-01
    z[5,4,3]  R2393     -3.3113643527030945e-01
    z[5,4,3]  R2394     -0.296572744846344
    z[5,4,3]  R2395     -1.6149322688579559e-01
    z[5,4,3]  R2396     2.6683533191680908e-01
    z[5,4,3]  R2397     -2.6365929841995239e-01
    z[5,4,3]  R2398     -1.7282043397426605e-01
    z[5,4,3]  R2399     -9.6074566245079041e-02
    z[5,4,3]  R2400     2.1486331522464752e-01
    z[5,4,3]  R2401     3.2078996300697327e-01
    z[5,4,3]  R2402     1.3732829689979553e-01
    z[5,4,3]  R2403     -4.2660561203956604e-01
    z[5,4,4]  R42       1
    z[5,4,4]  R51       -1
    z[5,4,4]  R2270     -1
    z[5,4,4]  R2271     1
    z[5,4,4]  R2276     -8.9635804295539856e-02
    z[5,4,4]  R2277     5.9240357950329781e-03
    z[5,4,4]  R2278     1.6294494271278381e-01
    z[5,4,4]  R2279     2.9447984695434570e-01
    z[5,4,4]  R2280     4.7585102915763855e-01
    z[5,4,4]  R2281     6.0992515087127686e-01
    z[5,4,4]  R2282     5.3177025169134140e-02
    z[5,4,4]  R2283     2.7024206519126892e-01
    z[5,4,4]  R2284     1.8455411493778229e-01
    z[5,4,4]  R2285     2.6636752486228943e-01
    z[5,4,4]  R2286     -0.532170832157135
    z[5,4,4]  R2287     -1.8462254106998444e-01
    z[5,4,4]  R2288     -2.2556984424591064e-01
    z[5,4,4]  R2289     2.7346667647361755e-01
    z[5,4,4]  R2290     1.0784591734409332e-01
    z[5,4,4]  R2291     2.4785001575946808e-01
    z[5,4,4]  R2292     2.0645757019519806e-01
    z[5,4,4]  R2293     3.7460610270500183e-01
    z[5,4,4]  R2294     0.00777652719989419
    z[5,4,4]  R2295     1.9684703648090363e-01
    z[5,4,4]  R2296     8.7425507605075836e-02
    z[5,4,4]  R2297     -3.7611982226371765e-01
    z[5,4,4]  R2298     8.4554873406887054e-02
    z[5,4,4]  R2299     4.4912289828062057e-02
    z[5,4,4]  R2300     -2.7962690591812134e-01
    z[5,4,4]  R2301     -1.9024184346199036e-01
    z[5,4,4]  R2302     -1.2297239154577255e-01
    z[5,4,4]  R2303     -1.7264726758003235e-01
    z[5,4,4]  R2304     -2.0380100607872009e-01
    z[5,4,4]  R2305     -1.6615694761276245e-01
    z[5,4,4]  R2306     4.9837347120046616e-02
    z[5,4,4]  R2307     1.0925633460283279e-01
    z[5,4,4]  R2308     -1.6090567409992218e-01
    z[5,4,4]  R2309     -2.3118624463677406e-02
    z[5,4,4]  R2310     1.8447768688201904e-01
    z[5,4,4]  R2311     -1.7895893752574921e-01
    z[5,4,4]  R2312     1.9566673040390015e-01
    z[5,4,4]  R2313     2.8256335854530334e-01
    z[5,4,4]  R2314     3.9508658647537231e-01
    z[5,4,4]  R2315     5.8149969577789307e-01
    z[5,4,4]  R2316     -1.5922186430543661e-03
    z[5,4,4]  R2317     -1.3166756927967072e-01
    z[5,4,4]  R2318     3.4759557247161865e-01
    z[5,4,4]  R2319     1.0526530444622040e-02
    z[5,4,4]  R2320     -1.4662112109363079e-02
    z[5,4,4]  R2321     5.3493720293045044e-01
    z[5,4,4]  R2322     -3.1676670908927917e-01
    z[5,4,4]  R2323     -3.7845450639724731e-01
    z[5,4,4]  R2324     -1.3518825289793313e-04
    z[5,4,4]  R2325     -3.3785271644592285e-01
    z[5,4,4]  R2326     -3.0541995167732239e-01
    z[5,4,4]  R2327     -1.8798868358135223e-01
    z[5,4,4]  R2328     6.7701435089111328e-01
    z[5,4,4]  R2329     6.3727504014968872e-01
    z[5,4,4]  R2330     -2.4129703640937805e-01
    z[5,4,4]  R2331     -2.4397027492523193e-01
    z[5,4,4]  R2332     2.3534847795963287e-01
    z[5,4,4]  R2333     -1.3661400973796844e-01
    z[5,4,4]  R2334     5.0487709045410156e-01
    z[5,4,4]  R2335     -5.3828172385692596e-02
    z[5,4,4]  R2336     1.3678911328315735e-01
    z[5,4,4]  R2337     -1.1057466268539429e-01
    z[5,4,4]  R2338     1.4980529248714447e-01
    z[5,4,4]  R2339     1.3441678881645203e-01
    z[5,4,4]  R2340     -5.0711023807525635e-01
    z[5,4,4]  R2341     3.5708293318748474e-01
    z[5,4,4]  R2342     6.6397930495440960e-03
    z[5,4,4]  R2343     3.1206998229026794e-01
    z[5,4,4]  R2344     1.1286263167858124e-01
    z[5,4,4]  R2345     5.7297468185424805e-02
    z[5,4,4]  R2346     -1.1313164606690407e-02
    z[5,4,4]  R2347     2.0030789077281952e-01
    z[5,4,4]  R2348     0.0537506528198719
    z[5,4,4]  R2349     9.6015287563204765e-03
    z[5,4,4]  R2350     -2.5005133822560310e-02
    z[5,4,4]  R2351     2.5555279850959778e-01
    z[5,4,4]  R2352     8.7121017277240753e-03
    z[5,4,4]  R2353     4.8978802561759949e-01
    z[5,4,4]  R2354     1.1990191414952278e-02
    z[5,4,4]  R2355     5.2671605348587036e-01
    z[5,4,4]  R2356     -0.384162575006485
    z[5,4,4]  R2357     2.5257727503776550e-01
    z[5,4,4]  R2358     3.8030573725700378e-01
    z[5,4,4]  R2359     -5.5059641599655151e-02
    z[5,4,4]  R2360     1.3978768885135651e-01
    z[5,4,4]  R2361     1.6580714285373688e-01
    z[5,4,4]  R2362     1.5398119390010834e-01
    z[5,4,4]  R2363     -1.0099439322948456e-01
    z[5,4,4]  R2364     -3.1638448126614094e-03
    z[5,4,4]  R2365     -3.8547852635383606e-01
    z[5,4,4]  R2366     -5.3325051069259644e-01
    z[5,4,4]  R2367     3.5291498899459839e-01
    z[5,4,4]  R2368     -7.4833756685256958e-01
    z[5,4,4]  R2369     9.6530608832836151e-02
    z[5,4,4]  R2370     1.3895675539970398e-01
    z[5,4,4]  R2371     2.2054056823253632e-01
    z[5,4,4]  R2372     -2.8322175145149231e-01
    z[5,4,4]  R2373     1.1401998996734619e-01
    z[5,4,4]  R2374     -1.3707152009010315e-01
    z[5,4,4]  R2375     4.4733222573995590e-02
    z[5,4,4]  R2376     2.6117414236068726e-01
    z[5,4,4]  R2377     4.9561902880668640e-01
    z[5,4,4]  R2378     0.406207412481308
    z[5,4,4]  R2379     -3.5524827241897583e-01
    z[5,4,4]  R2380     3.7169721722602844e-01
    z[5,4,4]  R2381     -3.1640312075614929e-01
    z[5,4,4]  R2382     -4.2178431153297424e-01
    z[5,4,4]  R2383     -2.5168126821517944e-01
    z[5,4,4]  R2384     -4.4645896553993225e-01
    z[5,4,4]  R2385     -3.5246381163597107e-01
    z[5,4,4]  R2386     0.280819296836853
    z[5,4,4]  R2387     4.3981426954269409e-01
    z[5,4,4]  R2388     4.0599894709885120e-03
    z[5,4,4]  R2389     -4.7642147541046143e-01
    z[5,4,4]  R2390     2.0234338939189911e-01
    z[5,4,4]  R2391     5.0732856988906860e-01
    z[5,4,4]  R2392     -2.6159477233886719e-01
    z[5,4,4]  R2393     1.0549803078174591e-01
    z[5,4,4]  R2394     3.7096962332725525e-01
    z[5,4,4]  R2395     -4.3181905150413513e-01
    z[5,4,4]  R2396     1.6442857682704926e-01
    z[5,4,4]  R2397     4.8693239688873291e-01
    z[5,4,4]  R2398     6.7832469940185547e-02
    z[5,4,4]  R2399     2.7059277892112732e-01
    z[5,4,4]  R2400     -3.8322050124406815e-02
    z[5,4,4]  R2401     1.9262421131134033e-01
    z[5,4,4]  R2402     -1.2879092991352081e-01
    z[5,4,4]  R2403     -1.4227072894573212e-01
    z[5,4,5]  R43       1
    z[5,4,5]  R52       -1
    z[5,4,5]  R2272     -1
    z[5,4,5]  R2273     1
    z[5,4,5]  R2276     -7.5947046279907227e-03
    z[5,4,5]  R2277     -8.7791271507740021e-03
    z[5,4,5]  R2278     3.1882032752037048e-01
    z[5,4,5]  R2279     -5.7182990014553070e-02
    z[5,4,5]  R2280     -1.6890972852706909e-01
    z[5,4,5]  R2281     -6.4772136509418488e-02
    z[5,4,5]  R2282     1.0017333924770355e-01
    z[5,4,5]  R2283     0.231211319565773
    z[5,4,5]  R2284     5.7747727632522583e-01
    z[5,4,5]  R2285     2.6583153009414673e-01
    z[5,4,5]  R2286     2.2481076419353485e-01
    z[5,4,5]  R2287     1.3052079826593399e-02
    z[5,4,5]  R2288     1.5171720087528229e-01
    z[5,4,5]  R2289     -4.3023936450481415e-02
    z[5,4,5]  R2290     0.0353940911591053
    z[5,4,5]  R2291     4.4357147812843323e-01
    z[5,4,5]  R2292     4.7407639026641846e-01
    z[5,4,5]  R2293     6.2767281197011471e-03
    z[5,4,5]  R2294     -1.9781421124935150e-01
    z[5,4,5]  R2295     -1.9604696333408356e-01
    z[5,4,5]  R2296     1.9839632511138916e-01
    z[5,4,5]  R2297     3.3862125873565674e-01
    z[5,4,5]  R2298     -3.0617916956543922e-02
    z[5,4,5]  R2299     2.9147979617118835e-01
    z[5,4,5]  R2300     -3.6393553018569946e-01
    z[5,4,5]  R2301     -4.2408636212348938e-01
    z[5,4,5]  R2302     -1.2743981555104256e-02
    z[5,4,5]  R2303     -1.8517075479030609e-01
    z[5,4,5]  R2304     -3.0390882492065430e-01
    z[5,4,5]  R2305     -2.0238092541694641e-01
    z[5,4,5]  R2306     1.9782733917236328e-01
    z[5,4,5]  R2307     -9.8644390702247620e-02
    z[5,4,5]  R2308     -0.148346409201622
    z[5,4,5]  R2309     -4.6158552169799805e-01
    z[5,4,5]  R2310     -2.9842260479927063e-01
    z[5,4,5]  R2311     -3.4983307123184204e-01
    z[5,4,5]  R2312     -0.377279132604599
    z[5,4,5]  R2313     3.8751029968261719e-01
    z[5,4,5]  R2314     2.0157396793365479e-02
    z[5,4,5]  R2315     -3.3282953500747681e-01
    z[5,4,5]  R2316     5.0642937421798706e-01
    z[5,4,5]  R2317     -4.5824404805898666e-02
    z[5,4,5]  R2318     -6.2417805194854736e-01
    z[5,4,5]  R2319     -0.0754033774137497
    z[5,4,5]  R2320     -6.4436845481395721e-02
    z[5,4,5]  R2321     1.9234506785869598e-01
    z[5,4,5]  R2322     2.7806267142295837e-01
    z[5,4,5]  R2323     -2.3896206170320511e-02
    z[5,4,5]  R2324     -4.7335988283157349e-01
    z[5,4,5]  R2325     6.2632042169570923e-01
    z[5,4,5]  R2326     1.9467703998088837e-01
    z[5,4,5]  R2327     -4.9738940596580505e-01
    z[5,4,5]  R2328     -2.1414436399936676e-02
    z[5,4,5]  R2329     3.2057842612266541e-01
    z[5,4,5]  R2330     3.8099128007888794e-01
    z[5,4,5]  R2331     -6.7592531442642212e-01
    z[5,4,5]  R2332     5.3517264127731323e-01
    z[5,4,5]  R2333     2.1830736100673676e-01
    z[5,4,5]  R2334     -6.1397127807140350e-02
    z[5,4,5]  R2335     -2.8867498040199280e-01
    z[5,4,5]  R2336     -4.4239038228988647e-01
    z[5,4,5]  R2337     -2.9919949173927307e-01
    z[5,4,5]  R2338     -1.6329869627952576e-01
    z[5,4,5]  R2339     -5.9690177440643311e-01
    z[5,4,5]  R2340     1.0459543205797672e-02
    z[5,4,5]  R2341     3.1147959828376770e-01
    z[5,4,5]  R2342     9.0109594166278839e-02
    z[5,4,5]  R2343     3.6661437153816223e-01
    z[5,4,5]  R2344     -4.7735314816236496e-02
    z[5,4,5]  R2345     -2.3951521515846252e-01
    z[5,4,5]  R2346     -7.1482270956039429e-02
    z[5,4,5]  R2347     1.4146538078784943e-01
    z[5,4,5]  R2348     4.1564801335334778e-01
    z[5,4,5]  R2349     5.2571278065443039e-02
    z[5,4,5]  R2350     -6.4349097013473511e-01
    z[5,4,5]  R2351     -1.4879024028778076e-01
    z[5,4,5]  R2352     -4.0760420262813568e-02
    z[5,4,5]  R2353     2.3870344460010529e-01
    z[5,4,5]  R2354     -9.2644453048706055e-02
    z[5,4,5]  R2355     -1.2771388888359070e-01
    z[5,4,5]  R2356     1.2331591546535492e-01
    z[5,4,5]  R2357     -1.2022284418344498e-01
    z[5,4,5]  R2358     0.382844477891922
    z[5,4,5]  R2359     -9.3877725303173065e-02
    z[5,4,5]  R2360     -8.1795983016490936e-02
    z[5,4,5]  R2361     1.7924067378044128e-01
    z[5,4,5]  R2362     1.5473881363868713e-01
    z[5,4,5]  R2363     1.0495068877935410e-01
    z[5,4,5]  R2364     -3.1709831953048706e-01
    z[5,4,5]  R2365     -2.2529639303684235e-01
    z[5,4,5]  R2366     6.5626579523086548e-01
    z[5,4,5]  R2367     6.6537988185882568e-01
    z[5,4,5]  R2368     3.3398557454347610e-02
    z[5,4,5]  R2369     -5.4162133485078812e-02
    z[5,4,5]  R2370     4.6772268414497375e-01
    z[5,4,5]  R2371     1.5188623964786530e-01
    z[5,4,5]  R2372     -1.6468483209609985e-01
    z[5,4,5]  R2373     5.0029838085174561e-01
    z[5,4,5]  R2374     -1.1389130959287286e-03
    z[5,4,5]  R2375     -5.6748535484075546e-02
    z[5,4,5]  R2376     -6.2615203857421875e-01
    z[5,4,5]  R2377     1.6065572202205658e-01
    z[5,4,5]  R2378     6.4777636528015137e-01
    z[5,4,5]  R2379     -5.0720870494842529e-01
    z[5,4,5]  R2380     -3.6588084697723389e-01
    z[5,4,5]  R2381     7.4011576361954212e-03
    z[5,4,5]  R2382     -1.0231139510869980e-01
    z[5,4,5]  R2383     -3.2818627357482910e-01
    z[5,4,5]  R2384     -3.0741935968399048e-01
    z[5,4,5]  R2385     -4.0899041295051575e-01
    z[5,4,5]  R2386     1.0906521230936050e-01
    z[5,4,5]  R2387     2.3966281116008759e-01
    z[5,4,5]  R2388     3.5929358005523682e-01
    z[5,4,5]  R2389     3.1823945045471191e-01
    z[5,4,5]  R2390     2.2841575741767883e-01
    z[5,4,5]  R2391     -3.8880008459091187e-01
    z[5,4,5]  R2392     3.3971187472343445e-01
    z[5,4,5]  R2393     5.5800056457519531e-01
    z[5,4,5]  R2394     3.8121134042739868e-01
    z[5,4,5]  R2395     5.7679861783981323e-01
    z[5,4,5]  R2396     -1.6769881546497345e-01
    z[5,4,5]  R2397     -3.3462487161159515e-02
    z[5,4,5]  R2398     8.8889855146408081e-01
    z[5,4,5]  R2399     -2.6256833225488663e-02
    z[5,4,5]  R2400     1.5315471589565277e-01
    z[5,4,5]  R2401     -2.9874238371849060e-01
    z[5,4,5]  R2402     -5.6345868110656738e-01
    z[5,4,5]  R2403     9.4821535050868988e-02
    z[5,4,6]  R44       1
    z[5,4,6]  R53       -1
    z[5,4,6]  R2274     -1
    z[5,4,6]  R2275     1
    z[5,4,6]  R2276     -1.4731016755104065e-01
    z[5,4,6]  R2277     -6.6391073167324066e-02
    z[5,4,6]  R2278     2.0331348478794098e-01
    z[5,4,6]  R2279     -8.5120923817157745e-02
    z[5,4,6]  R2280     -1.0575703531503677e-01
    z[5,4,6]  R2281     -0.09307861328125
    z[5,4,6]  R2282     2.4711626768112183e-01
    z[5,4,6]  R2283     2.0318250358104706e-01
    z[5,4,6]  R2284     -3.3131068944931030e-01
    z[5,4,6]  R2285     -6.8389378488063812e-02
    z[5,4,6]  R2286     3.6516536027193069e-02
    z[5,4,6]  R2287     0.0774056687951088
    z[5,4,6]  R2288     -1.4727701246738434e-01
    z[5,4,6]  R2289     -1.5174393355846405e-01
    z[5,4,6]  R2290     -4.7539597749710083e-01
    z[5,4,6]  R2291     2.2532801330089569e-01
    z[5,4,6]  R2292     8.6684837937355042e-02
    z[5,4,6]  R2293     3.5144168138504028e-01
    z[5,4,6]  R2294     -1.7987428605556488e-01
    z[5,4,6]  R2295     3.6844724416732788e-01
    z[5,4,6]  R2296     0.677962064743042
    z[5,4,6]  R2297     -5.9153027832508087e-02
    z[5,4,6]  R2298     0.919495165348053
    z[5,4,6]  R2299     0.814403235912323
    z[5,4,6]  R2300     -1.8726487457752228e-01
    z[5,4,6]  R2301     3.9939272403717041e-01
    z[5,4,6]  R2302     2.7433177828788757e-01
    z[5,4,6]  R2303     -3.4588745236396790e-01
    z[5,4,6]  R2304     5.4620647430419922e-01
    z[5,4,6]  R2305     -1.9505728781223297e-01
    z[5,4,6]  R2306     2.5381517410278320e-01
    z[5,4,6]  R2307     3.0845694709569216e-03
    z[5,4,6]  R2308     -0.074495330452919
    z[5,4,6]  R2309     -2.7877295017242432e-01
    z[5,4,6]  R2310     -3.9746654033660889e-01
    z[5,4,6]  R2311     -5.3462157957255840e-03
    z[5,4,6]  R2312     4.3215584754943848e-01
    z[5,4,6]  R2313     -8.3619892597198486e-02
    z[5,4,6]  R2314     -2.7281185984611511e-01
    z[5,4,6]  R2315     -3.6632496118545532e-01
    z[5,4,6]  R2316     1.1175787448883057e-01
    z[5,4,6]  R2317     -8.6105622351169586e-02
    z[5,4,6]  R2318     -3.7456639111042023e-02
    z[5,4,6]  R2319     3.1134110689163208e-01
    z[5,4,6]  R2320     2.9562366008758545e-01
    z[5,4,6]  R2321     -8.3799540996551514e-02
    z[5,4,6]  R2322     -2.8917360305786133e-01
    z[5,4,6]  R2323     -3.4714111685752869e-01
    z[5,4,6]  R2324     1.2736445665359497e-01
    z[5,4,6]  R2325     -6.8762958049774170e-02
    z[5,4,6]  R2326     -1.6143139451742172e-02
    z[5,4,6]  R2327     2.1712635457515717e-01
    z[5,4,6]  R2328     1.1941968649625778e-01
    z[5,4,6]  R2329     2.5954738259315491e-01
    z[5,4,6]  R2330     -6.4274176955223083e-02
    z[5,4,6]  R2331     -3.3101800829172134e-02
    z[5,4,6]  R2332     -1.3286098837852478e-01
    z[5,4,6]  R2333     -1.1625555902719498e-01
    z[5,4,6]  R2334     -3.4496295452117920e-01
    z[5,4,6]  R2335     2.6258850097656250e-01
    z[5,4,6]  R2336     1.3789756596088409e-01
    z[5,4,6]  R2337     5.6865904480218887e-02
    z[5,4,6]  R2338     -2.2241444885730743e-01
    z[5,4,6]  R2339     0.195271834731102
    z[5,4,6]  R2340     -3.7824764847755432e-01
    z[5,4,6]  R2341     3.0041828751564026e-01
    z[5,4,6]  R2342     -3.9020174741744995e-01
    z[5,4,6]  R2343     -4.0451325476169586e-02
    z[5,4,6]  R2344     2.4714720249176025e-01
    z[5,4,6]  R2345     -7.1370363235473633e-01
    z[5,4,6]  R2346     6.2678046524524689e-02
    z[5,4,6]  R2347     3.5645064711570740e-01
    z[5,4,6]  R2348     -3.4316653013229370e-01
    z[5,4,6]  R2349     -3.2001107465475798e-03
    z[5,4,6]  R2350     -3.3547705411911011e-01
    z[5,4,6]  R2351     2.5705745816230774e-01
    z[5,4,6]  R2352     1.5021668374538422e-01
    z[5,4,6]  R2353     -3.2108661532402039e-01
    z[5,4,6]  R2354     1.7515990138053894e-01
    z[5,4,6]  R2355     -6.1666302382946014e-02
    z[5,4,6]  R2356     -8.5834875702857971e-02
    z[5,4,6]  R2357     2.0520697534084320e-01
    z[5,4,6]  R2358     -4.5186918228864670e-02
    z[5,4,6]  R2359     2.4321815371513367e-01
    z[5,4,6]  R2360     -1.5244592726230621e-01
    z[5,4,6]  R2361     -2.7870634198188782e-01
    z[5,4,6]  R2362     1.2779383361339569e-01
    z[5,4,6]  R2363     -3.3953779935836792e-01
    z[5,4,6]  R2364     -0.440801203250885
    z[5,4,6]  R2365     -3.7467747926712036e-02
    z[5,4,6]  R2366     9.7905740141868591e-02
    z[5,4,6]  R2367     4.9548465758562088e-02
    z[5,4,6]  R2368     -2.7058309316635132e-01
    z[5,4,6]  R2369     7.8890067338943481e-01
    z[5,4,6]  R2370     -2.9685431718826294e-01
    z[5,4,6]  R2371     -4.8208922147750854e-01
    z[5,4,6]  R2372     -7.2780676186084747e-02
    z[5,4,6]  R2373     2.2448913753032684e-01
    z[5,4,6]  R2374     -3.6659315228462219e-01
    z[5,4,6]  R2375     3.4811830520629883e-01
    z[5,4,6]  R2376     -1.2709483504295349e-01
    z[5,4,6]  R2377     -2.7647811919450760e-02
    z[5,4,6]  R2378     1.4032294973731041e-02
    z[5,4,6]  R2379     8.1678237766027451e-03
    z[5,4,6]  R2380     1.7205484211444855e-02
    z[5,4,6]  R2381     2.7510038018226624e-01
    z[5,4,6]  R2382     -1.1160384118556976e-01
    z[5,4,6]  R2383     5.5536616593599319e-02
    z[5,4,6]  R2384     0.102850541472435
    z[5,4,6]  R2385     -0.169743612408638
    z[5,4,6]  R2386     2.2508314251899719e-01
    z[5,4,6]  R2387     5.0840977579355240e-02
    z[5,4,6]  R2388     -3.4815722703933716e-01
    z[5,4,6]  R2389     1.5809737145900726e-02
    z[5,4,6]  R2390     2.1920089423656464e-01
    z[5,4,6]  R2391     -5.2649658173322678e-02
    z[5,4,6]  R2392     3.3853590488433838e-01
    z[5,4,6]  R2393     -1.3766942918300629e-01
    z[5,4,6]  R2394     -3.5886257886886597e-01
    z[5,4,6]  R2395     2.4111849069595337e-01
    z[5,4,6]  R2396     9.4328567385673523e-02
    z[5,4,6]  R2397     -3.5025981068611145e-01
    z[5,4,6]  R2398     -5.4601531475782394e-02
    z[5,4,6]  R2399     -1.1535544693470001e-01
    z[5,4,6]  R2400     3.6942100524902344e-01
    z[5,4,6]  R2401     1.6169679164886475e-01
    z[5,4,6]  R2402     2.3860198259353638e-01
    z[5,4,6]  R2403     -3.7413170933723450e-01
    z[5,6,0]  R47       -1
    z[5,6,0]  R56       1
    z[5,6,0]  R2404     -1
    z[5,6,0]  R2405     1
    z[5,6,0]  R2418     7.5943458080291748e-01
    z[5,6,0]  R2419     8.6767166852951050e-01
    z[5,6,0]  R2420     7.3249679803848267e-01
    z[5,6,0]  R2421     6.8604403734207153e-01
    z[5,6,0]  R2422     -4.4286161661148071e-01
    z[5,6,0]  R2423     -5.4820311069488525e-01
    z[5,6,0]  R2424     8.8026702404022217e-01
    z[5,6,0]  R2425     6.8000304698944092e-01
    z[5,6,0]  R2426     1.1706885695457458e-01
    z[5,6,0]  R2427     6.7970955371856689e-01
    z[5,6,0]  R2428     -7.2851979732513428e-01
    z[5,6,0]  R2429     -5.3250616788864136e-01
    z[5,6,0]  R2430     -4.5595401525497437e-01
    z[5,6,0]  R2431     -4.3952351808547974e-01
    z[5,6,0]  R2432     -4.3826425075531006e-01
    z[5,6,0]  R2433     -4.2607232928276062e-01
    z[5,6,0]  R2434     -4.5474034547805786e-01
    z[5,6,0]  R2435     -0.492642879486084
    z[5,6,0]  R2436     -3.5169291496276855e-01
    z[5,6,0]  R2437     -4.2849314212799072e-01
    z[5,6,0]  R2438     -1.8124037981033325e-01
    z[5,6,0]  R2439     1.0111644119024277e-01
    z[5,6,0]  R2440     -1.4891627430915833e-01
    z[5,6,0]  R2441     -3.5820782184600830e-01
    z[5,6,0]  R2442     1.6601191833615303e-02
    z[5,6,0]  R2443     -9.0139172971248627e-02
    z[5,6,0]  R2444     9.9790267646312714e-02
    z[5,6,0]  R2445     -5.5877542495727539e-01
    z[5,6,0]  R2446     -6.8435692787170410e-01
    z[5,6,0]  R2447     0.591355562210083
    z[5,6,0]  R2448     -0.634787917137146
    z[5,6,0]  R2449     -4.2726138234138489e-01
    z[5,6,0]  R2450     1.2502075731754303e-01
    z[5,6,0]  R2451     3.1266176700592041e-01
    z[5,6,0]  R2452     3.5332730412483215e-01
    z[5,6,0]  R2453     -8.6019468307495117e-01
    z[5,6,0]  R2454     -0.551559567451477
    z[5,6,0]  R2455     0.562705397605896
    z[5,6,0]  R2456     5.3335338830947876e-01
    z[5,6,0]  R2457     5.8284366130828857e-01
    z[5,6,0]  R2458     -1.4608344435691833e-01
    z[5,6,0]  R2459     4.0938743948936462e-01
    z[5,6,0]  R2460     1.8510198593139648e-01
    z[5,6,0]  R2461     2.6271072030067444e-01
    z[5,6,0]  R2462     5.9153407812118530e-01
    z[5,6,0]  R2463     2.2646707296371460e-01
    z[5,6,0]  R2464     5.1118308305740356e-01
    z[5,6,0]  R2465     -8.3527660369873047e-01
    z[5,6,0]  R2466     -4.7554358839988708e-01
    z[5,6,0]  R2467     -5.4265040159225464e-01
    z[5,6,0]  R2468     4.9199834465980530e-01
    z[5,6,0]  R2469     6.2315154075622559e-01
    z[5,6,0]  R2470     -5.2788324654102325e-02
    z[5,6,0]  R2471     4.3013170361518860e-01
    z[5,6,0]  R2472     0.500211238861084
    z[5,6,0]  R2473     -4.3523499369621277e-01
    z[5,6,0]  R2474     -5.9402501583099365e-01
    z[5,6,0]  R2475     -0.832075297832489
    z[5,6,0]  R2476     -5.5556356906890869e-01
    z[5,6,0]  R2477     -8.5553938150405884e-01
    z[5,6,0]  R2478     -7.5360065698623657e-01
    z[5,6,0]  R2479     7.5770670175552368e-01
    z[5,6,0]  R2480     1.5656508505344391e-01
    z[5,6,0]  R2481     -2.8213843703269958e-01
    z[5,6,0]  R2482     -2.8486687690019608e-02
    z[5,6,0]  R2483     4.7304117679595947e-01
    z[5,6,0]  R2484     -8.5314494371414185e-01
    z[5,6,0]  R2485     -6.6401398181915283e-01
    z[5,6,0]  R2486     -9.0782427787780762e-01
    z[5,6,0]  R2487     -6.1012154817581177e-01
    z[5,6,0]  R2488     5.7783633470535278e-01
    z[5,6,0]  R2489     4.4784688949584961e-01
    z[5,6,0]  R2490     -4.8408564925193787e-01
    z[5,6,0]  R2491     -0.672747015953064
    z[5,6,0]  R2492     -4.9150905013084412e-01
    z[5,6,0]  R2493     5.8502227067947388e-01
    z[5,6,0]  R2494     6.6070383787155151e-01
    z[5,6,0]  R2495     6.8326950073242188e-01
    z[5,6,0]  R2496     6.8778365850448608e-01
    z[5,6,0]  R2497     6.7371368408203125e-01
    z[5,6,0]  R2498     -8.9634925127029419e-01
    z[5,6,0]  R2499     5.8706700801849365e-01
    z[5,6,0]  R2500     6.3879698514938354e-01
    z[5,6,0]  R2501     6.2776446342468262e-01
    z[5,6,0]  R2502     4.9042728543281555e-01
    z[5,6,0]  R2503     -4.4271769002079964e-03
    z[5,6,0]  R2504     3.7055447697639465e-02
    z[5,6,0]  R2505     5.4906487464904785e-01
    z[5,6,0]  R2506     5.7185983657836914e-01
    z[5,6,0]  R2507     2.9208138585090637e-01
    z[5,6,0]  R2508     -1.1970573104918003e-03
    z[5,6,0]  R2509     3.9835777878761292e-01
    z[5,6,0]  R2510     -3.0083894729614258e-01
    z[5,6,0]  R2511     -3.6715969443321228e-01
    z[5,6,0]  R2512     -4.1392204165458679e-01
    z[5,6,0]  R2513     4.1932117938995361e-01
    z[5,6,0]  R2514     -1.1834224313497543e-01
    z[5,6,0]  R2515     -3.0072543025016785e-01
    z[5,6,0]  R2516     -7.6365791261196136e-02
    z[5,6,0]  R2517     -1.2636126577854156e-01
    z[5,6,0]  R2518     -8.2340574264526367e-01
    z[5,6,0]  R2519     -1.9203135371208191e-01
    z[5,6,0]  R2520     9.6498638391494751e-02
    z[5,6,0]  R2521     -3.2801163196563721e-01
    z[5,6,0]  R2522     -5.0426584482192993e-01
    z[5,6,0]  R2523     3.8767620921134949e-01
    z[5,6,0]  R2524     3.7921980023384094e-01
    z[5,6,0]  R2525     3.0902782082557678e-01
    z[5,6,0]  R2526     2.1062324941158295e-01
    z[5,6,0]  R2527     1.6345719993114471e-01
    z[5,6,0]  R2528     -7.6807297766208649e-02
    z[5,6,0]  R2529     -5.3572410345077515e-01
    z[5,6,0]  R2530     0.298926442861557
    z[5,6,0]  R2531     1.9086718559265137e-01
    z[5,6,0]  R2532     3.7786403298377991e-01
    z[5,6,0]  R2533     -5.9229653328657150e-02
    z[5,6,0]  R2534     0.685613214969635
    z[5,6,1]  R48       -1
    z[5,6,1]  R57       1
    z[5,6,1]  R2406     -1
    z[5,6,1]  R2407     1
    z[5,6,1]  R2418     5.1057547330856323e-01
    z[5,6,1]  R2419     3.1768313050270081e-01
    z[5,6,1]  R2420     4.8648440837860107e-01
    z[5,6,1]  R2421     4.7185283899307251e-01
    z[5,6,1]  R2422     4.4452327489852905e-01
    z[5,6,1]  R2423     -4.0931418538093567e-02
    z[5,6,1]  R2424     3.4900563955307007e-01
    z[5,6,1]  R2425     4.5200872421264648e-01
    z[5,6,1]  R2426     6.1654180288314819e-01
    z[5,6,1]  R2427     3.8457027077674866e-01
    z[5,6,1]  R2428     2.4004091322422028e-01
    z[5,6,1]  R2429     -4.3289753794670105e-01
    z[5,6,1]  R2430     -0.192816823720932
    z[5,6,1]  R2431     -2.1364213526248932e-01
    z[5,6,1]  R2432     -2.2704876959323883e-01
    z[5,6,1]  R2433     -2.5199401378631592e-01
    z[5,6,1]  R2434     -2.0157837867736816e-01
    z[5,6,1]  R2435     -1.9670151174068451e-01
    z[5,6,1]  R2436     -2.3894466459751129e-01
    z[5,6,1]  R2437     -2.3336625099182129e-01
    z[5,6,1]  R2438     3.4802475571632385e-01
    z[5,6,1]  R2439     7.8177338838577271e-01
    z[5,6,1]  R2440     2.4236483871936798e-01
    z[5,6,1]  R2441     1.7813818156719208e-01
    z[5,6,1]  R2442     8.5366815328598022e-01
    z[5,6,1]  R2443     6.6496598720550537e-01
    z[5,6,1]  R2444     3.4388515353202820e-01
    z[5,6,1]  R2445     -3.1246135011315346e-02
    z[5,6,1]  R2446     -1.8710640072822571e-01
    z[5,6,1]  R2447     -7.2522288560867310e-01
    z[5,6,1]  R2448     5.2543687820434570e-01
    z[5,6,1]  R2449     5.8598470687866211e-01
    z[5,6,1]  R2450     0.849338948726654
    z[5,6,1]  R2451     7.1854478120803833e-01
    z[5,6,1]  R2452     4.8190990090370178e-01
    z[5,6,1]  R2453     -1.8543800711631775e-01
    z[5,6,1]  R2454     -3.7781310081481934e-01
    z[5,6,1]  R2455     -5.2031236886978149e-01
    z[5,6,1]  R2456     -6.2621653079986572e-01
    z[5,6,1]  R2457     1.9602222368121147e-02
    z[5,6,1]  R2458     7.7178794145584106e-01
    z[5,6,1]  R2459     7.8734922409057617e-01
    z[5,6,1]  R2460     6.1397576332092285e-01
    z[5,6,1]  R2461     8.8871586322784424e-01
    z[5,6,1]  R2462     0.267733097076416
    z[5,6,1]  R2463     3.3866789937019348e-01
    z[5,6,1]  R2464     5.2049368619918823e-01
    z[5,6,1]  R2465     -1.1216162145137787e-01
    z[5,6,1]  R2466     3.0052950978279114e-01
    z[5,6,1]  R2467     -3.2113844156265259e-01
    z[5,6,1]  R2468     4.7029018402099609e-01
    z[5,6,1]  R2469     3.7659695744514465e-01
    z[5,6,1]  R2470     0.0677233412861824
    z[5,6,1]  R2471     1.5144044160842896e-01
    z[5,6,1]  R2472     5.7834458351135254e-01
    z[5,6,1]  R2473     5.1786535978317261e-01
    z[5,6,1]  R2474     -2.8375563025474548e-01
    z[5,6,1]  R2475     -3.4214520454406738e-01
    z[5,6,1]  R2476     -3.3144152164459229e-01
    z[5,6,1]  R2477     -0.0317201092839241
    z[5,6,1]  R2478     1.1143982410430908e-01
    z[5,6,1]  R2479     4.7424244880676270e-01
    z[5,6,1]  R2480     8.5829752683639526e-01
    z[5,6,1]  R2481     3.1502538919448853e-01
    z[5,6,1]  R2482     4.6628189086914062e-01
    z[5,6,1]  R2483     5.6245517730712891e-01
    z[5,6,1]  R2484     -2.7969694137573242e-01
    z[5,6,1]  R2485     -4.1869038343429565e-01
    z[5,6,1]  R2486     -2.2984184324741364e-01
    z[5,6,1]  R2487     -3.1074598431587219e-02
    z[5,6,1]  R2488     7.8660178184509277e-01
    z[5,6,1]  R2489     6.3052386045455933e-01
    z[5,6,1]  R2490     1.7272271215915680e-01
    z[5,6,1]  R2491     -3.2018333673477173e-01
    z[5,6,1]  R2492     -2.6289907097816467e-01
    z[5,6,1]  R2493     -3.7370449304580688e-01
    z[5,6,1]  R2494     -5.1204943656921387e-01
    z[5,6,1]  R2495     -3.6264434456825256e-01
    z[5,6,1]  R2496     -5.7322126626968384e-01
    z[5,6,1]  R2497     -4.6222689747810364e-01
    z[5,6,1]  R2498     -9.9885143339633942e-02
    z[5,6,1]  R2499     -4.1757720708847046e-01
    z[5,6,1]  R2500     -5.2153486013412476e-01
    z[5,6,1]  R2501     -5.8511340618133545e-01
    z[5,6,1]  R2502     -6.2838965654373169e-01
    z[5,6,1]  R2503     -7.2098881006240845e-01
    z[5,6,1]  R2504     -8.9664030075073242e-01
    z[5,6,1]  R2505     -5.7314264774322510e-01
    z[5,6,1]  R2506     -4.7685539722442627e-01
    z[5,6,1]  R2507     -5.5895823240280151e-01
    z[5,6,1]  R2508     -2.2033055126667023e-01
    z[5,6,1]  R2509     4.5959314703941345e-01
    z[5,6,1]  R2510     1.1390078812837601e-01
    z[5,6,1]  R2511     2.0924666523933411e-01
    z[5,6,1]  R2512     4.6872356534004211e-01
    z[5,6,1]  R2513     6.3018488883972168e-01
    z[5,6,1]  R2514     8.3565098047256470e-01
    z[5,6,1]  R2515     6.2042653560638428e-01
    z[5,6,1]  R2516     5.0904005765914917e-01
    z[5,6,1]  R2517     -3.0407229065895081e-01
    z[5,6,1]  R2518     9.4793796539306641e-02
    z[5,6,1]  R2519     2.8459683060646057e-01
    z[5,6,1]  R2520     -9.0831464529037476e-01
    z[5,6,1]  R2521     -5.9445196390151978e-01
    z[5,6,1]  R2522     -6.4131164550781250e-01
    z[5,6,1]  R2523     -6.1285120248794556e-01
    z[5,6,1]  R2524     -2.4251176416873932e-01
    z[5,6,1]  R2525     -3.5514634847640991e-01
    z[5,6,1]  R2526     -5.4501199722290039e-01
    z[5,6,1]  R2527     -4.6743515133857727e-01
    z[5,6,1]  R2528     -6.1531532555818558e-02
    z[5,6,1]  R2529     1.4721401967108250e-02
    z[5,6,1]  R2530     -2.9983457922935486e-01
    z[5,6,1]  R2531     -0.711582601070404
    z[5,6,1]  R2532     -1.3799284398555756e-01
    z[5,6,1]  R2533     -2.6491332054138184e-01
    z[5,6,1]  R2534     -3.3857762813568115e-01
    z[5,6,2]  R49       -1
    z[5,6,2]  R58       1
    z[5,6,2]  R2408     -1
    z[5,6,2]  R2409     1
    z[5,6,2]  R2418     0.225607231259346
    z[5,6,2]  R2419     3.1976962089538574e-01
    z[5,6,2]  R2420     2.1875400841236115e-01
    z[5,6,2]  R2421     4.4502955675125122e-01
    z[5,6,2]  R2422     -4.7080716490745544e-01
    z[5,6,2]  R2423     -4.1226577758789062e-01
    z[5,6,2]  R2424     1.5544793009757996e-01
    z[5,6,2]  R2425     3.5547360777854919e-01
    z[5,6,2]  R2426     -3.2983991503715515e-01
    z[5,6,2]  R2427     4.8570439219474792e-01
    z[5,6,2]  R2428     2.3494124412536621e-01
    z[5,6,2]  R2429     6.5841847658157349e-01
    z[5,6,2]  R2430     8.0758494138717651e-01
    z[5,6,2]  R2431     6.8192929029464722e-01
    z[5,6,2]  R2432     6.5245223045349121e-01
    z[5,6,2]  R2433     6.6472548246383667e-01
    z[5,6,2]  R2434     0.639353334903717
    z[5,6,2]  R2435     6.3165879249572754e-01
    z[5,6,2]  R2436     7.7503788471221924e-01
    z[5,6,2]  R2437     5.7745563983917236e-01
    z[5,6,2]  R2438     2.3937088251113892e-01
    z[5,6,2]  R2439     2.8595605492591858e-01
    z[5,6,2]  R2440     -4.6420689672231674e-02
    z[5,6,2]  R2441     -2.5077894330024719e-01
    z[5,6,2]  R2442     1.2380032241344452e-01
    z[5,6,2]  R2443     -3.7403452396392822e-01
    z[5,6,2]  R2444     -7.1206778287887573e-01
    z[5,6,2]  R2445     -4.7657048702239990e-01
    z[5,6,2]  R2446     -2.1853515505790710e-01
    z[5,6,2]  R2447     -5.7819854468107224e-02
    z[5,6,2]  R2448     -4.0094745159149170e-01
    z[5,6,2]  R2449     -6.7131072282791138e-01
    z[5,6,2]  R2450     -4.1002368927001953e-01
    z[5,6,2]  R2451     -2.6114150881767273e-01
    z[5,6,2]  R2452     4.2280846834182739e-01
    z[5,6,2]  R2453     -2.4369031190872192e-01
    z[5,6,2]  R2454     0.328095406293869
    z[5,6,2]  R2455     3.8787674903869629e-01
    z[5,6,2]  R2456     2.9203245043754578e-01
    z[5,6,2]  R2457     -2.7586886286735535e-01
    z[5,6,2]  R2458     -2.2261705994606018e-01
    z[5,6,2]  R2459     3.4349447488784790e-01
    z[5,6,2]  R2460     -1.4417226612567902e-01
    z[5,6,2]  R2461     -1.2380160391330719e-01
    z[5,6,2]  R2462     -0.395833283662796
    z[5,6,2]  R2463     2.3510010540485382e-01
    z[5,6,2]  R2464     -2.0400816202163696e-01
    z[5,6,2]  R2465     -9.6323236823081970e-02
    z[5,6,2]  R2466     3.9766165614128113e-01
    z[5,6,2]  R2467     2.9063206911087036e-01
    z[5,6,2]  R2468     6.3487243652343750e-01
    z[5,6,2]  R2469     3.7208899855613708e-01
    z[5,6,2]  R2470     1.3445743918418884e-01
    z[5,6,2]  R2471     -4.3952378630638123e-01
    z[5,6,2]  R2472     -2.9135462641716003e-01
    z[5,6,2]  R2473     0.0922401174902916
    z[5,6,2]  R2474     4.4079285860061646e-01
    z[5,6,2]  R2475     -3.1065413355827332e-01
    z[5,6,2]  R2476     0.355376273393631
    z[5,6,2]  R2477     1.2634010612964630e-01
    z[5,6,2]  R2478     -4.2379835247993469e-01
    z[5,6,2]  R2479     3.0889004468917847e-01
    z[5,6,2]  R2480     -3.6990982294082642e-01
    z[5,6,2]  R2481     3.5622832179069519e-01
    z[5,6,2]  R2482     -4.7861674427986145e-01
    z[5,6,2]  R2483     -1.3612095499411225e-03
    z[5,6,2]  R2484     -1.4447963237762451e-01
    z[5,6,2]  R2485     2.8854611515998840e-01
    z[5,6,2]  R2486     2.1654902398586273e-01
    z[5,6,2]  R2487     6.2843970954418182e-02
    z[5,6,2]  R2488     -1.7592564225196838e-01
    z[5,6,2]  R2489     2.0112448930740356e-01
    z[5,6,2]  R2490     3.3232292532920837e-01
    z[5,6,2]  R2491     4.4547894597053528e-01
    z[5,6,2]  R2492     3.8438367843627930e-01
    z[5,6,2]  R2493     5.4896640777587891e-01
    z[5,6,2]  R2494     5.2453732490539551e-01
    z[5,6,2]  R2495     2.7125416323542595e-02
    z[5,6,2]  R2496     1.1758831888437271e-01
    z[5,6,2]  R2497     -1.3787375390529633e-01
    z[5,6,2]  R2498     -1.0769053548574448e-01
    z[5,6,2]  R2499     5.5269473791122437e-01
    z[5,6,2]  R2500     1.5828667581081390e-01
    z[5,6,2]  R2501     3.8291251659393311e-01
    z[5,6,2]  R2502     5.5537527799606323e-01
    z[5,6,2]  R2503     0.521673321723938
    z[5,6,2]  R2504     3.5263195633888245e-01
    z[5,6,2]  R2505     5.3273621946573257e-02
    z[5,6,2]  R2506     2.5538769364356995e-01
    z[5,6,2]  R2507     -2.4770677089691162e-01
    z[5,6,2]  R2508     -1.5700127184391022e-01
    z[5,6,2]  R2509     4.0909403562545776e-01
    z[5,6,2]  R2510     -6.0636216402053833e-01
    z[5,6,2]  R2511     -4.0500751137733459e-01
    z[5,6,2]  R2512     1.3352312147617340e-02
    z[5,6,2]  R2513     -7.7508250251412392e-03
    z[5,6,2]  R2514     -5.8390375226736069e-02
    z[5,6,2]  R2515     3.7913840264081955e-02
    z[5,6,2]  R2516     2.6878255605697632e-01
    z[5,6,2]  R2517     2.1994440257549286e-01
    z[5,6,2]  R2518     5.1407706737518311e-01
    z[5,6,2]  R2519     -0.190054789185524
    z[5,6,2]  R2520     8.1887438893318176e-02
    z[5,6,2]  R2521     1.0052428394556046e-01
    z[5,6,2]  R2522     -2.0116455852985382e-01
    z[5,6,2]  R2523     5.0907045602798462e-01
    z[5,6,2]  R2524     6.6290384531021118e-01
    z[5,6,2]  R2525     4.4923242926597595e-01
    z[5,6,2]  R2526     4.0708842873573303e-01
    z[5,6,2]  R2527     5.3370285034179688e-01
    z[5,6,2]  R2528     -4.0093046426773071e-01
    z[5,6,2]  R2529     -2.1145179867744446e-01
    z[5,6,2]  R2530     -8.2104299217462540e-03
    z[5,6,2]  R2531     3.5090631246566772e-01
    z[5,6,2]  R2532     4.9911147356033325e-01
    z[5,6,2]  R2533     2.3015265166759491e-01
    z[5,6,2]  R2534     -5.2543884515762329e-01
    z[5,6,3]  R50       -1
    z[5,6,3]  R59       1
    z[5,6,3]  R2410     -1
    z[5,6,3]  R2411     1
    z[5,6,3]  R2418     2.8614804148674011e-01
    z[5,6,3]  R2419     1.9862221181392670e-01
    z[5,6,3]  R2420     9.6923463046550751e-02
    z[5,6,3]  R2421     1.0683256387710571e-01
    z[5,6,3]  R2422     -3.4418621659278870e-01
    z[5,6,3]  R2423     -3.7811005115509033e-01
    z[5,6,3]  R2424     7.2333104908466339e-02
    z[5,6,3]  R2425     -1.9786326587200165e-01
    z[5,6,3]  R2426     -1.4166752994060516e-01
    z[5,6,3]  R2427     -8.8863588869571686e-02
    z[5,6,3]  R2428     -1.4615970849990845e-01
    z[5,6,3]  R2429     2.3510551452636719e-01
    z[5,6,3]  R2430     8.4521457552909851e-02
    z[5,6,3]  R2431     4.4326889514923096e-01
    z[5,6,3]  R2432     3.0297595262527466e-01
    z[5,6,3]  R2433     -6.4370416104793549e-02
    z[5,6,3]  R2434     2.6252093911170959e-01
    z[5,6,3]  R2435     2.3608949780464172e-01
    z[5,6,3]  R2436     -0.383390337228775
    z[5,6,3]  R2437     4.6426522731781006e-01
    z[5,6,3]  R2438     -5.3112649917602539e-01
    z[5,6,3]  R2439     -1.9288714230060577e-01
    z[5,6,3]  R2440     -2.5173398852348328e-01
    z[5,6,3]  R2441     -1.6380971670150757e-01
    z[5,6,3]  R2442     -9.9699504673480988e-02
    z[5,6,3]  R2443     1.8503373861312866e-01
    z[5,6,3]  R2444     5.2364283800125122e-01
    z[5,6,3]  R2445     5.2530074119567871e-01
    z[5,6,3]  R2446     1.2904337048530579e-01
    z[5,6,3]  R2447     -1.1997362226247787e-01
    z[5,6,3]  R2448     -2.3272280395030975e-01
    z[5,6,3]  R2449     4.1645620018243790e-02
    z[5,6,3]  R2450     2.0353603363037109e-01
    z[5,6,3]  R2451     1.6257666051387787e-01
    z[5,6,3]  R2452     -4.2788782715797424e-01
    z[5,6,3]  R2453     1.0887966305017471e-01
    z[5,6,3]  R2454     -2.7930095791816711e-01
    z[5,6,3]  R2455     -1.5871591866016388e-01
    z[5,6,3]  R2456     -0.0847240760922432
    z[5,6,3]  R2457     2.6343245059251785e-02
    z[5,6,3]  R2458     -2.5393217802047729e-01
    z[5,6,3]  R2459     -2.6008498668670654e-01
    z[5,6,3]  R2460     -2.3698411881923676e-01
    z[5,6,3]  R2461     -1.5202210843563080e-01
    z[5,6,3]  R2462     -5.7442313432693481e-01
    z[5,6,3]  R2463     -6.6975212097167969e-01
    z[5,6,3]  R2464     4.0605121850967407e-01
    z[5,6,3]  R2465     1.2707798182964325e-01
    z[5,6,3]  R2466     -5.3396087884902954e-01
    z[5,6,3]  R2467     -8.2362376153469086e-02
    z[5,6,3]  R2468     -4.7547496855258942e-02
    z[5,6,3]  R2469     0.0390746146440506
    z[5,6,3]  R2470     -7.0815253257751465e-01
    z[5,6,3]  R2471     -1.5038779377937317e-01
    z[5,6,3]  R2472     3.5058364272117615e-01
    z[5,6,3]  R2473     -1.2800544500350952e-01
    z[5,6,3]  R2474     1.1343742907047272e-01
    z[5,6,3]  R2475     1.1935079097747803e-01
    z[5,6,3]  R2476     2.7844834327697754e-01
    z[5,6,3]  R2477     3.0967876315116882e-01
    z[5,6,3]  R2478     -8.1400223076343536e-02
    z[5,6,3]  R2479     2.4099707603454590e-02
    z[5,6,3]  R2480     -5.8336075395345688e-02
    z[5,6,3]  R2481     -5.3081786632537842e-01
    z[5,6,3]  R2482     -3.9032605290412903e-01
    z[5,6,3]  R2483     -3.8091403245925903e-01
    z[5,6,3]  R2484     -1.1232873797416687e-01
    z[5,6,3]  R2485     2.5902670621871948e-01
    z[5,6,3]  R2486     -5.9855529107153416e-03
    z[5,6,3]  R2487     -2.2981157898902893e-01
    z[5,6,3]  R2488     0.0851278305053711
    z[5,6,3]  R2489     -4.1740727424621582e-01
    z[5,6,3]  R2490     -5.7617175579071045e-01
    z[5,6,3]  R2491     -4.9353456497192383e-01
    z[5,6,3]  R2492     1.1958824843168259e-01
    z[5,6,3]  R2493     -2.5140696763992310e-01
    z[5,6,3]  R2494     4.2824551463127136e-02
    z[5,6,3]  R2495     -3.0461966991424561e-02
    z[5,6,3]  R2496     0.380967378616333
    z[5,6,3]  R2497     1.2610933184623718e-01
    z[5,6,3]  R2498     6.9487184286117554e-02
    z[5,6,3]  R2499     -2.3484340310096741e-01
    z[5,6,3]  R2500     -4.0507983416318893e-02
    z[5,6,3]  R2501     2.1431854367256165e-01
    z[5,6,3]  R2502     -8.1822186708450317e-02
    z[5,6,3]  R2503     -2.6592493057250977e-01
    z[5,6,3]  R2504     -7.9549968242645264e-02
    z[5,6,3]  R2505     4.8030912876129150e-01
    z[5,6,3]  R2506     2.9239574074745178e-01
    z[5,6,3]  R2507     5.8321475982666016e-01
    z[5,6,3]  R2508     1.8152070045471191e-01
    z[5,6,3]  R2509     3.0024429783225060e-02
    z[5,6,3]  R2510     -6.7329630255699158e-02
    z[5,6,3]  R2511     1.4320933818817139e-01
    z[5,6,3]  R2512     -5.0282761454582214e-02
    z[5,6,3]  R2513     5.4868827573955059e-03
    z[5,6,3]  R2514     -7.1596577763557434e-02
    z[5,6,3]  R2515     6.7600446939468384e-01
    z[5,6,3]  R2516     0.30000039935112
    z[5,6,3]  R2517     0.794006884098053
    z[5,6,3]  R2518     1.1935956031084061e-01
    z[5,6,3]  R2519     -6.9941782951354980e-01
    z[5,6,3]  R2520     0.301226943731308
    z[5,6,3]  R2521     3.8864842057228088e-01
    z[5,6,3]  R2522     2.3955328762531281e-01
    z[5,6,3]  R2523     2.5290060043334961e-01
    z[5,6,3]  R2524     7.8742668032646179e-02
    z[5,6,3]  R2525     4.4505367986857891e-03
    z[5,6,3]  R2526     -4.0808707475662231e-02
    z[5,6,3]  R2527     3.4651394933462143e-02
    z[5,6,3]  R2528     -4.1442832350730896e-01
    z[5,6,3]  R2529     -4.0571314096450806e-01
    z[5,6,3]  R2530     -7.3294615745544434e-01
    z[5,6,3]  R2531     2.0180614292621613e-01
    z[5,6,3]  R2532     -3.9547482132911682e-01
    z[5,6,3]  R2533     -3.7801361083984375e-01
    z[5,6,3]  R2534     -9.5134507864713669e-03
    z[5,6,4]  R51       -1
    z[5,6,4]  R60       1
    z[5,6,4]  R2412     -1
    z[5,6,4]  R2413     1
    z[5,6,4]  R2418     -8.9635804295539856e-02
    z[5,6,4]  R2419     5.9240357950329781e-03
    z[5,6,4]  R2420     1.6294494271278381e-01
    z[5,6,4]  R2421     2.9447984695434570e-01
    z[5,6,4]  R2422     4.7585102915763855e-01
    z[5,6,4]  R2423     6.0992515087127686e-01
    z[5,6,4]  R2424     5.3177025169134140e-02
    z[5,6,4]  R2425     2.7024206519126892e-01
    z[5,6,4]  R2426     1.8455411493778229e-01
    z[5,6,4]  R2427     2.6636752486228943e-01
    z[5,6,4]  R2428     -0.532170832157135
    z[5,6,4]  R2429     -1.8462254106998444e-01
    z[5,6,4]  R2430     -2.2556984424591064e-01
    z[5,6,4]  R2431     2.7346667647361755e-01
    z[5,6,4]  R2432     1.0784591734409332e-01
    z[5,6,4]  R2433     2.4785001575946808e-01
    z[5,6,4]  R2434     2.0645757019519806e-01
    z[5,6,4]  R2435     3.7460610270500183e-01
    z[5,6,4]  R2436     0.00777652719989419
    z[5,6,4]  R2437     1.9684703648090363e-01
    z[5,6,4]  R2438     8.7425507605075836e-02
    z[5,6,4]  R2439     -3.7611982226371765e-01
    z[5,6,4]  R2440     8.4554873406887054e-02
    z[5,6,4]  R2441     4.4912289828062057e-02
    z[5,6,4]  R2442     -2.7962690591812134e-01
    z[5,6,4]  R2443     -1.9024184346199036e-01
    z[5,6,4]  R2444     -1.2297239154577255e-01
    z[5,6,4]  R2445     -1.7264726758003235e-01
    z[5,6,4]  R2446     -2.0380100607872009e-01
    z[5,6,4]  R2447     -1.6615694761276245e-01
    z[5,6,4]  R2448     4.9837347120046616e-02
    z[5,6,4]  R2449     1.0925633460283279e-01
    z[5,6,4]  R2450     -1.6090567409992218e-01
    z[5,6,4]  R2451     -2.3118624463677406e-02
    z[5,6,4]  R2452     1.8447768688201904e-01
    z[5,6,4]  R2453     -1.7895893752574921e-01
    z[5,6,4]  R2454     1.9566673040390015e-01
    z[5,6,4]  R2455     2.8256335854530334e-01
    z[5,6,4]  R2456     3.9508658647537231e-01
    z[5,6,4]  R2457     5.8149969577789307e-01
    z[5,6,4]  R2458     -1.5922186430543661e-03
    z[5,6,4]  R2459     -1.3166756927967072e-01
    z[5,6,4]  R2460     3.4759557247161865e-01
    z[5,6,4]  R2461     1.0526530444622040e-02
    z[5,6,4]  R2462     -1.4662112109363079e-02
    z[5,6,4]  R2463     5.3493720293045044e-01
    z[5,6,4]  R2464     -3.1676670908927917e-01
    z[5,6,4]  R2465     -3.7845450639724731e-01
    z[5,6,4]  R2466     -1.3518825289793313e-04
    z[5,6,4]  R2467     -3.3785271644592285e-01
    z[5,6,4]  R2468     -3.0541995167732239e-01
    z[5,6,4]  R2469     -1.8798868358135223e-01
    z[5,6,4]  R2470     6.7701435089111328e-01
    z[5,6,4]  R2471     6.3727504014968872e-01
    z[5,6,4]  R2472     -2.4129703640937805e-01
    z[5,6,4]  R2473     -2.4397027492523193e-01
    z[5,6,4]  R2474     2.3534847795963287e-01
    z[5,6,4]  R2475     -1.3661400973796844e-01
    z[5,6,4]  R2476     5.0487709045410156e-01
    z[5,6,4]  R2477     -5.3828172385692596e-02
    z[5,6,4]  R2478     1.3678911328315735e-01
    z[5,6,4]  R2479     -1.1057466268539429e-01
    z[5,6,4]  R2480     1.4980529248714447e-01
    z[5,6,4]  R2481     1.3441678881645203e-01
    z[5,6,4]  R2482     -5.0711023807525635e-01
    z[5,6,4]  R2483     3.5708293318748474e-01
    z[5,6,4]  R2484     6.6397930495440960e-03
    z[5,6,4]  R2485     3.1206998229026794e-01
    z[5,6,4]  R2486     1.1286263167858124e-01
    z[5,6,4]  R2487     5.7297468185424805e-02
    z[5,6,4]  R2488     -1.1313164606690407e-02
    z[5,6,4]  R2489     2.0030789077281952e-01
    z[5,6,4]  R2490     0.0537506528198719
    z[5,6,4]  R2491     9.6015287563204765e-03
    z[5,6,4]  R2492     -2.5005133822560310e-02
    z[5,6,4]  R2493     2.5555279850959778e-01
    z[5,6,4]  R2494     8.7121017277240753e-03
    z[5,6,4]  R2495     4.8978802561759949e-01
    z[5,6,4]  R2496     1.1990191414952278e-02
    z[5,6,4]  R2497     5.2671605348587036e-01
    z[5,6,4]  R2498     -0.384162575006485
    z[5,6,4]  R2499     2.5257727503776550e-01
    z[5,6,4]  R2500     3.8030573725700378e-01
    z[5,6,4]  R2501     -5.5059641599655151e-02
    z[5,6,4]  R2502     1.3978768885135651e-01
    z[5,6,4]  R2503     1.6580714285373688e-01
    z[5,6,4]  R2504     1.5398119390010834e-01
    z[5,6,4]  R2505     -1.0099439322948456e-01
    z[5,6,4]  R2506     -3.1638448126614094e-03
    z[5,6,4]  R2507     -3.8547852635383606e-01
    z[5,6,4]  R2508     9.3230515718460083e-01
    z[5,6,4]  R2509     6.4843553304672241e-01
    z[5,6,4]  R2510     1.8940374255180359e-01
    z[5,6,4]  R2511     6.5703099966049194e-01
    z[5,6,4]  R2512     1.8320725858211517e-01
    z[5,6,4]  R2513     0.368007093667984
    z[5,6,4]  R2514     -3.9148527383804321e-01
    z[5,6,4]  R2515     -0.251006543636322
    z[5,6,4]  R2516     -3.4782004356384277e-01
    z[5,6,4]  R2517     -2.3502174019813538e-01
    z[5,6,4]  R2518     -1.3876289129257202e-01
    z[5,6,4]  R2519     -2.9398933053016663e-01
    z[5,6,4]  R2520     -2.4249014258384705e-01
    z[5,6,4]  R2521     -5.0091665983200073e-01
    z[5,6,4]  R2522     -4.2328283190727234e-01
    z[5,6,4]  R2523     6.4704000949859619e-02
    z[5,6,4]  R2524     -5.7221513986587524e-01
    z[5,6,4]  R2525     -5.2367347478866577e-01
    z[5,6,4]  R2526     -1.4771215617656708e-01
    z[5,6,4]  R2527     -3.8605967164039612e-01
    z[5,6,4]  R2528     4.0591907501220703e-01
    z[5,6,4]  R2529     -5.4308164119720459e-01
    z[5,6,4]  R2530     0.496865838766098
    z[5,6,4]  R2531     3.9167352952063084e-03
    z[5,6,4]  R2532     -5.3028100728988647e-01
    z[5,6,4]  R2533     -4.0601128339767456e-01
    z[5,6,4]  R2534     -2.8760954737663269e-01
    z[5,6,5]  R52       -1
    z[5,6,5]  R61       1
    z[5,6,5]  R2414     -1
    z[5,6,5]  R2415     1
    z[5,6,5]  R2418     -7.5947046279907227e-03
    z[5,6,5]  R2419     -8.7791271507740021e-03
    z[5,6,5]  R2420     3.1882032752037048e-01
    z[5,6,5]  R2421     -5.7182990014553070e-02
    z[5,6,5]  R2422     -1.6890972852706909e-01
    z[5,6,5]  R2423     -6.4772136509418488e-02
    z[5,6,5]  R2424     1.0017333924770355e-01
    z[5,6,5]  R2425     0.231211319565773
    z[5,6,5]  R2426     5.7747727632522583e-01
    z[5,6,5]  R2427     2.6583153009414673e-01
    z[5,6,5]  R2428     2.2481076419353485e-01
    z[5,6,5]  R2429     1.3052079826593399e-02
    z[5,6,5]  R2430     1.5171720087528229e-01
    z[5,6,5]  R2431     -4.3023936450481415e-02
    z[5,6,5]  R2432     0.0353940911591053
    z[5,6,5]  R2433     4.4357147812843323e-01
    z[5,6,5]  R2434     4.7407639026641846e-01
    z[5,6,5]  R2435     6.2767281197011471e-03
    z[5,6,5]  R2436     -1.9781421124935150e-01
    z[5,6,5]  R2437     -1.9604696333408356e-01
    z[5,6,5]  R2438     1.9839632511138916e-01
    z[5,6,5]  R2439     3.3862125873565674e-01
    z[5,6,5]  R2440     -3.0617916956543922e-02
    z[5,6,5]  R2441     2.9147979617118835e-01
    z[5,6,5]  R2442     -3.6393553018569946e-01
    z[5,6,5]  R2443     -4.2408636212348938e-01
    z[5,6,5]  R2444     -1.2743981555104256e-02
    z[5,6,5]  R2445     -1.8517075479030609e-01
    z[5,6,5]  R2446     -3.0390882492065430e-01
    z[5,6,5]  R2447     -2.0238092541694641e-01
    z[5,6,5]  R2448     1.9782733917236328e-01
    z[5,6,5]  R2449     -9.8644390702247620e-02
    z[5,6,5]  R2450     -0.148346409201622
    z[5,6,5]  R2451     -4.6158552169799805e-01
    z[5,6,5]  R2452     -2.9842260479927063e-01
    z[5,6,5]  R2453     -3.4983307123184204e-01
    z[5,6,5]  R2454     -0.377279132604599
    z[5,6,5]  R2455     3.8751029968261719e-01
    z[5,6,5]  R2456     2.0157396793365479e-02
    z[5,6,5]  R2457     -3.3282953500747681e-01
    z[5,6,5]  R2458     5.0642937421798706e-01
    z[5,6,5]  R2459     -4.5824404805898666e-02
    z[5,6,5]  R2460     -6.2417805194854736e-01
    z[5,6,5]  R2461     -0.0754033774137497
    z[5,6,5]  R2462     -6.4436845481395721e-02
    z[5,6,5]  R2463     1.9234506785869598e-01
    z[5,6,5]  R2464     2.7806267142295837e-01
    z[5,6,5]  R2465     -2.3896206170320511e-02
    z[5,6,5]  R2466     -4.7335988283157349e-01
    z[5,6,5]  R2467     6.2632042169570923e-01
    z[5,6,5]  R2468     1.9467703998088837e-01
    z[5,6,5]  R2469     -4.9738940596580505e-01
    z[5,6,5]  R2470     -2.1414436399936676e-02
    z[5,6,5]  R2471     3.2057842612266541e-01
    z[5,6,5]  R2472     3.8099128007888794e-01
    z[5,6,5]  R2473     -6.7592531442642212e-01
    z[5,6,5]  R2474     5.3517264127731323e-01
    z[5,6,5]  R2475     2.1830736100673676e-01
    z[5,6,5]  R2476     -6.1397127807140350e-02
    z[5,6,5]  R2477     -2.8867498040199280e-01
    z[5,6,5]  R2478     -4.4239038228988647e-01
    z[5,6,5]  R2479     -2.9919949173927307e-01
    z[5,6,5]  R2480     -1.6329869627952576e-01
    z[5,6,5]  R2481     -5.9690177440643311e-01
    z[5,6,5]  R2482     1.0459543205797672e-02
    z[5,6,5]  R2483     3.1147959828376770e-01
    z[5,6,5]  R2484     9.0109594166278839e-02
    z[5,6,5]  R2485     3.6661437153816223e-01
    z[5,6,5]  R2486     -4.7735314816236496e-02
    z[5,6,5]  R2487     -2.3951521515846252e-01
    z[5,6,5]  R2488     -7.1482270956039429e-02
    z[5,6,5]  R2489     1.4146538078784943e-01
    z[5,6,5]  R2490     4.1564801335334778e-01
    z[5,6,5]  R2491     5.2571278065443039e-02
    z[5,6,5]  R2492     -6.4349097013473511e-01
    z[5,6,5]  R2493     -1.4879024028778076e-01
    z[5,6,5]  R2494     -4.0760420262813568e-02
    z[5,6,5]  R2495     2.3870344460010529e-01
    z[5,6,5]  R2496     -9.2644453048706055e-02
    z[5,6,5]  R2497     -1.2771388888359070e-01
    z[5,6,5]  R2498     1.2331591546535492e-01
    z[5,6,5]  R2499     -1.2022284418344498e-01
    z[5,6,5]  R2500     0.382844477891922
    z[5,6,5]  R2501     -9.3877725303173065e-02
    z[5,6,5]  R2502     -8.1795983016490936e-02
    z[5,6,5]  R2503     1.7924067378044128e-01
    z[5,6,5]  R2504     1.5473881363868713e-01
    z[5,6,5]  R2505     1.0495068877935410e-01
    z[5,6,5]  R2506     -3.1709831953048706e-01
    z[5,6,5]  R2507     -2.2529639303684235e-01
    z[5,6,5]  R2508     -1.2142031639814377e-01
    z[5,6,5]  R2509     -7.2115555405616760e-02
    z[5,6,5]  R2510     5.1024538278579712e-01
    z[5,6,5]  R2511     3.6064037680625916e-01
    z[5,6,5]  R2512     -4.1838459670543671e-02
    z[5,6,5]  R2513     -7.2465568780899048e-02
    z[5,6,5]  R2514     -2.2915486246347427e-02
    z[5,6,5]  R2515     -1.7315704608336091e-03
    z[5,6,5]  R2516     6.7093491554260254e-01
    z[5,6,5]  R2517     3.9473345875740051e-01
    z[5,6,5]  R2518     3.2030217349529266e-02
    z[5,6,5]  R2519     -0.512298047542572
    z[5,6,5]  R2520     -3.6583945620805025e-03
    z[5,6,5]  R2521     -8.8016480207443237e-02
    z[5,6,5]  R2522     -1.2372436374425888e-01
    z[5,6,5]  R2523     8.2141578197479248e-02
    z[5,6,5]  R2524     9.2413406819105148e-03
    z[5,6,5]  R2525     8.6203746497631073e-02
    z[5,6,5]  R2526     0.583867073059082
    z[5,6,5]  R2527     3.3442100882530212e-01
    z[5,6,5]  R2528     -6.9211864471435547e-01
    z[5,6,5]  R2529     -4.0671899914741516e-01
    z[5,6,5]  R2530     1.3982349634170532e-01
    z[5,6,5]  R2531     -3.4050858020782471e-01
    z[5,6,5]  R2532     3.8897618651390076e-01
    z[5,6,5]  R2533     6.8253362178802490e-01
    z[5,6,5]  R2534     1.4928117394447327e-01
    z[5,6,6]  R53       -1
    z[5,6,6]  R62       1
    z[5,6,6]  R2416     -1
    z[5,6,6]  R2417     1
    z[5,6,6]  R2418     -1.4731016755104065e-01
    z[5,6,6]  R2419     -6.6391073167324066e-02
    z[5,6,6]  R2420     2.0331348478794098e-01
    z[5,6,6]  R2421     -8.5120923817157745e-02
    z[5,6,6]  R2422     -1.0575703531503677e-01
    z[5,6,6]  R2423     -0.09307861328125
    z[5,6,6]  R2424     2.4711626768112183e-01
    z[5,6,6]  R2425     2.0318250358104706e-01
    z[5,6,6]  R2426     -3.3131068944931030e-01
    z[5,6,6]  R2427     -6.8389378488063812e-02
    z[5,6,6]  R2428     3.6516536027193069e-02
    z[5,6,6]  R2429     0.0774056687951088
    z[5,6,6]  R2430     -1.4727701246738434e-01
    z[5,6,6]  R2431     -1.5174393355846405e-01
    z[5,6,6]  R2432     -4.7539597749710083e-01
    z[5,6,6]  R2433     2.2532801330089569e-01
    z[5,6,6]  R2434     8.6684837937355042e-02
    z[5,6,6]  R2435     3.5144168138504028e-01
    z[5,6,6]  R2436     -1.7987428605556488e-01
    z[5,6,6]  R2437     3.6844724416732788e-01
    z[5,6,6]  R2438     0.677962064743042
    z[5,6,6]  R2439     -5.9153027832508087e-02
    z[5,6,6]  R2440     0.919495165348053
    z[5,6,6]  R2441     0.814403235912323
    z[5,6,6]  R2442     -1.8726487457752228e-01
    z[5,6,6]  R2443     3.9939272403717041e-01
    z[5,6,6]  R2444     2.7433177828788757e-01
    z[5,6,6]  R2445     -3.4588745236396790e-01
    z[5,6,6]  R2446     5.4620647430419922e-01
    z[5,6,6]  R2447     -1.9505728781223297e-01
    z[5,6,6]  R2448     2.5381517410278320e-01
    z[5,6,6]  R2449     3.0845694709569216e-03
    z[5,6,6]  R2450     -0.074495330452919
    z[5,6,6]  R2451     -2.7877295017242432e-01
    z[5,6,6]  R2452     -3.9746654033660889e-01
    z[5,6,6]  R2453     -5.3462157957255840e-03
    z[5,6,6]  R2454     4.3215584754943848e-01
    z[5,6,6]  R2455     -8.3619892597198486e-02
    z[5,6,6]  R2456     -2.7281185984611511e-01
    z[5,6,6]  R2457     -3.6632496118545532e-01
    z[5,6,6]  R2458     1.1175787448883057e-01
    z[5,6,6]  R2459     -8.6105622351169586e-02
    z[5,6,6]  R2460     -3.7456639111042023e-02
    z[5,6,6]  R2461     3.1134110689163208e-01
    z[5,6,6]  R2462     2.9562366008758545e-01
    z[5,6,6]  R2463     -8.3799540996551514e-02
    z[5,6,6]  R2464     -2.8917360305786133e-01
    z[5,6,6]  R2465     -3.4714111685752869e-01
    z[5,6,6]  R2466     1.2736445665359497e-01
    z[5,6,6]  R2467     -6.8762958049774170e-02
    z[5,6,6]  R2468     -1.6143139451742172e-02
    z[5,6,6]  R2469     2.1712635457515717e-01
    z[5,6,6]  R2470     1.1941968649625778e-01
    z[5,6,6]  R2471     2.5954738259315491e-01
    z[5,6,6]  R2472     -6.4274176955223083e-02
    z[5,6,6]  R2473     -3.3101800829172134e-02
    z[5,6,6]  R2474     -1.3286098837852478e-01
    z[5,6,6]  R2475     -1.1625555902719498e-01
    z[5,6,6]  R2476     -3.4496295452117920e-01
    z[5,6,6]  R2477     2.6258850097656250e-01
    z[5,6,6]  R2478     1.3789756596088409e-01
    z[5,6,6]  R2479     5.6865904480218887e-02
    z[5,6,6]  R2480     -2.2241444885730743e-01
    z[5,6,6]  R2481     0.195271834731102
    z[5,6,6]  R2482     -3.7824764847755432e-01
    z[5,6,6]  R2483     3.0041828751564026e-01
    z[5,6,6]  R2484     -3.9020174741744995e-01
    z[5,6,6]  R2485     -4.0451325476169586e-02
    z[5,6,6]  R2486     2.4714720249176025e-01
    z[5,6,6]  R2487     -7.1370363235473633e-01
    z[5,6,6]  R2488     6.2678046524524689e-02
    z[5,6,6]  R2489     3.5645064711570740e-01
    z[5,6,6]  R2490     -3.4316653013229370e-01
    z[5,6,6]  R2491     -3.2001107465475798e-03
    z[5,6,6]  R2492     -3.3547705411911011e-01
    z[5,6,6]  R2493     2.5705745816230774e-01
    z[5,6,6]  R2494     1.5021668374538422e-01
    z[5,6,6]  R2495     -3.2108661532402039e-01
    z[5,6,6]  R2496     1.7515990138053894e-01
    z[5,6,6]  R2497     -6.1666302382946014e-02
    z[5,6,6]  R2498     -8.5834875702857971e-02
    z[5,6,6]  R2499     2.0520697534084320e-01
    z[5,6,6]  R2500     -4.5186918228864670e-02
    z[5,6,6]  R2501     2.4321815371513367e-01
    z[5,6,6]  R2502     -1.5244592726230621e-01
    z[5,6,6]  R2503     -2.7870634198188782e-01
    z[5,6,6]  R2504     1.2779383361339569e-01
    z[5,6,6]  R2505     -3.3953779935836792e-01
    z[5,6,6]  R2506     -0.440801203250885
    z[5,6,6]  R2507     -3.7467747926712036e-02
    z[5,6,6]  R2508     -0.0995897725224495
    z[5,6,6]  R2509     1.9014886021614075e-01
    z[5,6,6]  R2510     4.7758764028549194e-01
    z[5,6,6]  R2511     -2.7407726645469666e-01
    z[5,6,6]  R2512     -0.755608856678009
    z[5,6,6]  R2513     5.3503835201263428e-01
    z[5,6,6]  R2514     3.5406398773193359e-01
    z[5,6,6]  R2515     -5.6641805917024612e-02
    z[5,6,6]  R2516     -4.0861517190933228e-02
    z[5,6,6]  R2517     4.1237942874431610e-02
    z[5,6,6]  R2518     1.1922285705804825e-01
    z[5,6,6]  R2519     0.0891263335943222
    z[5,6,6]  R2520     9.6925109624862671e-02
    z[5,6,6]  R2521     -3.4527987241744995e-01
    z[5,6,6]  R2522     -2.0519843697547913e-01
    z[5,6,6]  R2523     -0.374266117811203
    z[5,6,6]  R2524     -1.5563745796680450e-01
    z[5,6,6]  R2525     0.543026864528656
    z[5,6,6]  R2526     -3.5846036672592163e-01
    z[5,6,6]  R2527     -4.5592454075813293e-01
    z[5,6,6]  R2528     1.1840562522411346e-01
    z[5,6,6]  R2529     -2.0762926340103149e-01
    z[5,6,6]  R2530     -1.3053172826766968e-01
    z[5,6,6]  R2531     -4.2118576169013977e-01
    z[5,6,6]  R2532     1.2796354480087757e-02
    z[5,6,6]  R2533     -3.1583356857299805e-01
    z[5,6,6]  R2534     -0.184713214635849
    z[6,5,0]  R47       1
    z[6,5,0]  R56       -1
    z[6,5,0]  R2535     -1
    z[6,5,0]  R2536     1
    z[6,5,0]  R2549     -1.1970573104918003e-03
    z[6,5,0]  R2550     3.9835777878761292e-01
    z[6,5,0]  R2551     -3.0083894729614258e-01
    z[6,5,0]  R2552     -3.6715969443321228e-01
    z[6,5,0]  R2553     -4.1392204165458679e-01
    z[6,5,0]  R2554     4.1932117938995361e-01
    z[6,5,0]  R2555     -1.1834224313497543e-01
    z[6,5,0]  R2556     -3.0072543025016785e-01
    z[6,5,0]  R2557     -7.6365791261196136e-02
    z[6,5,0]  R2558     -1.2636126577854156e-01
    z[6,5,0]  R2559     -8.2340574264526367e-01
    z[6,5,0]  R2560     -1.9203135371208191e-01
    z[6,5,0]  R2561     9.6498638391494751e-02
    z[6,5,0]  R2562     -3.2801163196563721e-01
    z[6,5,0]  R2563     -5.0426584482192993e-01
    z[6,5,0]  R2564     3.8767620921134949e-01
    z[6,5,0]  R2565     3.7921980023384094e-01
    z[6,5,0]  R2566     3.0902782082557678e-01
    z[6,5,0]  R2567     2.1062324941158295e-01
    z[6,5,0]  R2568     1.6345719993114471e-01
    z[6,5,0]  R2569     -7.6807297766208649e-02
    z[6,5,0]  R2570     -5.3572410345077515e-01
    z[6,5,0]  R2571     0.298926442861557
    z[6,5,0]  R2572     1.9086718559265137e-01
    z[6,5,0]  R2573     3.7786403298377991e-01
    z[6,5,0]  R2574     -5.9229653328657150e-02
    z[6,5,0]  R2575     0.685613214969635
    z[6,5,0]  R2576     7.5943458080291748e-01
    z[6,5,0]  R2577     8.6767166852951050e-01
    z[6,5,0]  R2578     7.3249679803848267e-01
    z[6,5,0]  R2579     6.8604403734207153e-01
    z[6,5,0]  R2580     -4.4286161661148071e-01
    z[6,5,0]  R2581     -5.4820311069488525e-01
    z[6,5,0]  R2582     8.8026702404022217e-01
    z[6,5,0]  R2583     6.8000304698944092e-01
    z[6,5,0]  R2584     1.1706885695457458e-01
    z[6,5,0]  R2585     6.7970955371856689e-01
    z[6,5,0]  R2586     -7.2851979732513428e-01
    z[6,5,0]  R2587     -5.3250616788864136e-01
    z[6,5,0]  R2588     -4.5595401525497437e-01
    z[6,5,0]  R2589     -4.3952351808547974e-01
    z[6,5,0]  R2590     -4.3826425075531006e-01
    z[6,5,0]  R2591     -4.2607232928276062e-01
    z[6,5,0]  R2592     -4.5474034547805786e-01
    z[6,5,0]  R2593     -0.492642879486084
    z[6,5,0]  R2594     -3.5169291496276855e-01
    z[6,5,0]  R2595     -4.2849314212799072e-01
    z[6,5,0]  R2596     -1.8124037981033325e-01
    z[6,5,0]  R2597     1.0111644119024277e-01
    z[6,5,0]  R2598     -1.4891627430915833e-01
    z[6,5,0]  R2599     -3.5820782184600830e-01
    z[6,5,0]  R2600     1.6601191833615303e-02
    z[6,5,0]  R2601     -9.0139172971248627e-02
    z[6,5,0]  R2602     9.9790267646312714e-02
    z[6,5,0]  R2603     -5.5877542495727539e-01
    z[6,5,0]  R2604     -6.8435692787170410e-01
    z[6,5,0]  R2605     0.591355562210083
    z[6,5,0]  R2606     -0.634787917137146
    z[6,5,0]  R2607     -4.2726138234138489e-01
    z[6,5,0]  R2608     1.2502075731754303e-01
    z[6,5,0]  R2609     3.1266176700592041e-01
    z[6,5,0]  R2610     3.5332730412483215e-01
    z[6,5,0]  R2611     -8.6019468307495117e-01
    z[6,5,0]  R2612     -0.551559567451477
    z[6,5,0]  R2613     0.562705397605896
    z[6,5,0]  R2614     5.3335338830947876e-01
    z[6,5,0]  R2615     5.8284366130828857e-01
    z[6,5,0]  R2616     -1.4608344435691833e-01
    z[6,5,0]  R2617     4.0938743948936462e-01
    z[6,5,0]  R2618     1.8510198593139648e-01
    z[6,5,0]  R2619     2.6271072030067444e-01
    z[6,5,0]  R2620     5.9153407812118530e-01
    z[6,5,0]  R2621     2.2646707296371460e-01
    z[6,5,0]  R2622     5.1118308305740356e-01
    z[6,5,0]  R2623     -8.3527660369873047e-01
    z[6,5,0]  R2624     -4.7554358839988708e-01
    z[6,5,0]  R2625     -5.4265040159225464e-01
    z[6,5,0]  R2626     4.9199834465980530e-01
    z[6,5,0]  R2627     6.2315154075622559e-01
    z[6,5,0]  R2628     -5.2788324654102325e-02
    z[6,5,0]  R2629     4.3013170361518860e-01
    z[6,5,0]  R2630     0.500211238861084
    z[6,5,0]  R2631     -4.3523499369621277e-01
    z[6,5,0]  R2632     -5.9402501583099365e-01
    z[6,5,0]  R2633     -0.832075297832489
    z[6,5,0]  R2634     -5.5556356906890869e-01
    z[6,5,0]  R2635     -8.5553938150405884e-01
    z[6,5,0]  R2636     -7.5360065698623657e-01
    z[6,5,0]  R2637     7.5770670175552368e-01
    z[6,5,0]  R2638     1.5656508505344391e-01
    z[6,5,0]  R2639     -2.8213843703269958e-01
    z[6,5,0]  R2640     -2.8486687690019608e-02
    z[6,5,0]  R2641     4.7304117679595947e-01
    z[6,5,0]  R2642     -8.5314494371414185e-01
    z[6,5,0]  R2643     -6.6401398181915283e-01
    z[6,5,0]  R2644     -9.0782427787780762e-01
    z[6,5,0]  R2645     -6.1012154817581177e-01
    z[6,5,0]  R2646     5.7783633470535278e-01
    z[6,5,0]  R2647     4.4784688949584961e-01
    z[6,5,0]  R2648     -4.8408564925193787e-01
    z[6,5,0]  R2649     -0.672747015953064
    z[6,5,0]  R2650     -4.9150905013084412e-01
    z[6,5,0]  R2651     5.8502227067947388e-01
    z[6,5,0]  R2652     6.6070383787155151e-01
    z[6,5,0]  R2653     6.8326950073242188e-01
    z[6,5,0]  R2654     6.8778365850448608e-01
    z[6,5,0]  R2655     6.7371368408203125e-01
    z[6,5,0]  R2656     -8.9634925127029419e-01
    z[6,5,0]  R2657     5.8706700801849365e-01
    z[6,5,0]  R2658     6.3879698514938354e-01
    z[6,5,0]  R2659     6.2776446342468262e-01
    z[6,5,0]  R2660     4.9042728543281555e-01
    z[6,5,0]  R2661     -4.4271769002079964e-03
    z[6,5,0]  R2662     3.7055447697639465e-02
    z[6,5,0]  R2663     5.4906487464904785e-01
    z[6,5,0]  R2664     5.7185983657836914e-01
    z[6,5,0]  R2665     2.9208138585090637e-01
    z[6,5,1]  R48       1
    z[6,5,1]  R57       -1
    z[6,5,1]  R2537     -1
    z[6,5,1]  R2538     1
    z[6,5,1]  R2549     -2.2033055126667023e-01
    z[6,5,1]  R2550     4.5959314703941345e-01
    z[6,5,1]  R2551     1.1390078812837601e-01
    z[6,5,1]  R2552     2.0924666523933411e-01
    z[6,5,1]  R2553     4.6872356534004211e-01
    z[6,5,1]  R2554     6.3018488883972168e-01
    z[6,5,1]  R2555     8.3565098047256470e-01
    z[6,5,1]  R2556     6.2042653560638428e-01
    z[6,5,1]  R2557     5.0904005765914917e-01
    z[6,5,1]  R2558     -3.0407229065895081e-01
    z[6,5,1]  R2559     9.4793796539306641e-02
    z[6,5,1]  R2560     2.8459683060646057e-01
    z[6,5,1]  R2561     -9.0831464529037476e-01
    z[6,5,1]  R2562     -5.9445196390151978e-01
    z[6,5,1]  R2563     -6.4131164550781250e-01
    z[6,5,1]  R2564     -6.1285120248794556e-01
    z[6,5,1]  R2565     -2.4251176416873932e-01
    z[6,5,1]  R2566     -3.5514634847640991e-01
    z[6,5,1]  R2567     -5.4501199722290039e-01
    z[6,5,1]  R2568     -4.6743515133857727e-01
    z[6,5,1]  R2569     -6.1531532555818558e-02
    z[6,5,1]  R2570     1.4721401967108250e-02
    z[6,5,1]  R2571     -2.9983457922935486e-01
    z[6,5,1]  R2572     -0.711582601070404
    z[6,5,1]  R2573     -1.3799284398555756e-01
    z[6,5,1]  R2574     -2.6491332054138184e-01
    z[6,5,1]  R2575     -3.3857762813568115e-01
    z[6,5,1]  R2576     5.1057547330856323e-01
    z[6,5,1]  R2577     3.1768313050270081e-01
    z[6,5,1]  R2578     4.8648440837860107e-01
    z[6,5,1]  R2579     4.7185283899307251e-01
    z[6,5,1]  R2580     4.4452327489852905e-01
    z[6,5,1]  R2581     -4.0931418538093567e-02
    z[6,5,1]  R2582     3.4900563955307007e-01
    z[6,5,1]  R2583     4.5200872421264648e-01
    z[6,5,1]  R2584     6.1654180288314819e-01
    z[6,5,1]  R2585     3.8457027077674866e-01
    z[6,5,1]  R2586     2.4004091322422028e-01
    z[6,5,1]  R2587     -4.3289753794670105e-01
    z[6,5,1]  R2588     -0.192816823720932
    z[6,5,1]  R2589     -2.1364213526248932e-01
    z[6,5,1]  R2590     -2.2704876959323883e-01
    z[6,5,1]  R2591     -2.5199401378631592e-01
    z[6,5,1]  R2592     -2.0157837867736816e-01
    z[6,5,1]  R2593     -1.9670151174068451e-01
    z[6,5,1]  R2594     -2.3894466459751129e-01
    z[6,5,1]  R2595     -2.3336625099182129e-01
    z[6,5,1]  R2596     3.4802475571632385e-01
    z[6,5,1]  R2597     7.8177338838577271e-01
    z[6,5,1]  R2598     2.4236483871936798e-01
    z[6,5,1]  R2599     1.7813818156719208e-01
    z[6,5,1]  R2600     8.5366815328598022e-01
    z[6,5,1]  R2601     6.6496598720550537e-01
    z[6,5,1]  R2602     3.4388515353202820e-01
    z[6,5,1]  R2603     -3.1246135011315346e-02
    z[6,5,1]  R2604     -1.8710640072822571e-01
    z[6,5,1]  R2605     -7.2522288560867310e-01
    z[6,5,1]  R2606     5.2543687820434570e-01
    z[6,5,1]  R2607     5.8598470687866211e-01
    z[6,5,1]  R2608     0.849338948726654
    z[6,5,1]  R2609     7.1854478120803833e-01
    z[6,5,1]  R2610     4.8190990090370178e-01
    z[6,5,1]  R2611     -1.8543800711631775e-01
    z[6,5,1]  R2612     -3.7781310081481934e-01
    z[6,5,1]  R2613     -5.2031236886978149e-01
    z[6,5,1]  R2614     -6.2621653079986572e-01
    z[6,5,1]  R2615     1.9602222368121147e-02
    z[6,5,1]  R2616     7.7178794145584106e-01
    z[6,5,1]  R2617     7.8734922409057617e-01
    z[6,5,1]  R2618     6.1397576332092285e-01
    z[6,5,1]  R2619     8.8871586322784424e-01
    z[6,5,1]  R2620     0.267733097076416
    z[6,5,1]  R2621     3.3866789937019348e-01
    z[6,5,1]  R2622     5.2049368619918823e-01
    z[6,5,1]  R2623     -1.1216162145137787e-01
    z[6,5,1]  R2624     3.0052950978279114e-01
    z[6,5,1]  R2625     -3.2113844156265259e-01
    z[6,5,1]  R2626     4.7029018402099609e-01
    z[6,5,1]  R2627     3.7659695744514465e-01
    z[6,5,1]  R2628     0.0677233412861824
    z[6,5,1]  R2629     1.5144044160842896e-01
    z[6,5,1]  R2630     5.7834458351135254e-01
    z[6,5,1]  R2631     5.1786535978317261e-01
    z[6,5,1]  R2632     -2.8375563025474548e-01
    z[6,5,1]  R2633     -3.4214520454406738e-01
    z[6,5,1]  R2634     -3.3144152164459229e-01
    z[6,5,1]  R2635     -0.0317201092839241
    z[6,5,1]  R2636     1.1143982410430908e-01
    z[6,5,1]  R2637     4.7424244880676270e-01
    z[6,5,1]  R2638     8.5829752683639526e-01
    z[6,5,1]  R2639     3.1502538919448853e-01
    z[6,5,1]  R2640     4.6628189086914062e-01
    z[6,5,1]  R2641     5.6245517730712891e-01
    z[6,5,1]  R2642     -2.7969694137573242e-01
    z[6,5,1]  R2643     -4.1869038343429565e-01
    z[6,5,1]  R2644     -2.2984184324741364e-01
    z[6,5,1]  R2645     -3.1074598431587219e-02
    z[6,5,1]  R2646     7.8660178184509277e-01
    z[6,5,1]  R2647     6.3052386045455933e-01
    z[6,5,1]  R2648     1.7272271215915680e-01
    z[6,5,1]  R2649     -3.2018333673477173e-01
    z[6,5,1]  R2650     -2.6289907097816467e-01
    z[6,5,1]  R2651     -3.7370449304580688e-01
    z[6,5,1]  R2652     -5.1204943656921387e-01
    z[6,5,1]  R2653     -3.6264434456825256e-01
    z[6,5,1]  R2654     -5.7322126626968384e-01
    z[6,5,1]  R2655     -4.6222689747810364e-01
    z[6,5,1]  R2656     -9.9885143339633942e-02
    z[6,5,1]  R2657     -4.1757720708847046e-01
    z[6,5,1]  R2658     -5.2153486013412476e-01
    z[6,5,1]  R2659     -5.8511340618133545e-01
    z[6,5,1]  R2660     -6.2838965654373169e-01
    z[6,5,1]  R2661     -7.2098881006240845e-01
    z[6,5,1]  R2662     -8.9664030075073242e-01
    z[6,5,1]  R2663     -5.7314264774322510e-01
    z[6,5,1]  R2664     -4.7685539722442627e-01
    z[6,5,1]  R2665     -5.5895823240280151e-01
    z[6,5,2]  R49       1
    z[6,5,2]  R58       -1
    z[6,5,2]  R2539     -1
    z[6,5,2]  R2540     1
    z[6,5,2]  R2549     -1.5700127184391022e-01
    z[6,5,2]  R2550     4.0909403562545776e-01
    z[6,5,2]  R2551     -6.0636216402053833e-01
    z[6,5,2]  R2552     -4.0500751137733459e-01
    z[6,5,2]  R2553     1.3352312147617340e-02
    z[6,5,2]  R2554     -7.7508250251412392e-03
    z[6,5,2]  R2555     -5.8390375226736069e-02
    z[6,5,2]  R2556     3.7913840264081955e-02
    z[6,5,2]  R2557     2.6878255605697632e-01
    z[6,5,2]  R2558     2.1994440257549286e-01
    z[6,5,2]  R2559     5.1407706737518311e-01
    z[6,5,2]  R2560     -0.190054789185524
    z[6,5,2]  R2561     8.1887438893318176e-02
    z[6,5,2]  R2562     1.0052428394556046e-01
    z[6,5,2]  R2563     -2.0116455852985382e-01
    z[6,5,2]  R2564     5.0907045602798462e-01
    z[6,5,2]  R2565     6.6290384531021118e-01
    z[6,5,2]  R2566     4.4923242926597595e-01
    z[6,5,2]  R2567     4.0708842873573303e-01
    z[6,5,2]  R2568     5.3370285034179688e-01
    z[6,5,2]  R2569     -4.0093046426773071e-01
    z[6,5,2]  R2570     -2.1145179867744446e-01
    z[6,5,2]  R2571     -8.2104299217462540e-03
    z[6,5,2]  R2572     3.5090631246566772e-01
    z[6,5,2]  R2573     4.9911147356033325e-01
    z[6,5,2]  R2574     2.3015265166759491e-01
    z[6,5,2]  R2575     -5.2543884515762329e-01
    z[6,5,2]  R2576     0.225607231259346
    z[6,5,2]  R2577     3.1976962089538574e-01
    z[6,5,2]  R2578     2.1875400841236115e-01
    z[6,5,2]  R2579     4.4502955675125122e-01
    z[6,5,2]  R2580     -4.7080716490745544e-01
    z[6,5,2]  R2581     -4.1226577758789062e-01
    z[6,5,2]  R2582     1.5544793009757996e-01
    z[6,5,2]  R2583     3.5547360777854919e-01
    z[6,5,2]  R2584     -3.2983991503715515e-01
    z[6,5,2]  R2585     4.8570439219474792e-01
    z[6,5,2]  R2586     2.3494124412536621e-01
    z[6,5,2]  R2587     6.5841847658157349e-01
    z[6,5,2]  R2588     8.0758494138717651e-01
    z[6,5,2]  R2589     6.8192929029464722e-01
    z[6,5,2]  R2590     6.5245223045349121e-01
    z[6,5,2]  R2591     6.6472548246383667e-01
    z[6,5,2]  R2592     0.639353334903717
    z[6,5,2]  R2593     6.3165879249572754e-01
    z[6,5,2]  R2594     7.7503788471221924e-01
    z[6,5,2]  R2595     5.7745563983917236e-01
    z[6,5,2]  R2596     2.3937088251113892e-01
    z[6,5,2]  R2597     2.8595605492591858e-01
    z[6,5,2]  R2598     -4.6420689672231674e-02
    z[6,5,2]  R2599     -2.5077894330024719e-01
    z[6,5,2]  R2600     1.2380032241344452e-01
    z[6,5,2]  R2601     -3.7403452396392822e-01
    z[6,5,2]  R2602     -7.1206778287887573e-01
    z[6,5,2]  R2603     -4.7657048702239990e-01
    z[6,5,2]  R2604     -2.1853515505790710e-01
    z[6,5,2]  R2605     -5.7819854468107224e-02
    z[6,5,2]  R2606     -4.0094745159149170e-01
    z[6,5,2]  R2607     -6.7131072282791138e-01
    z[6,5,2]  R2608     -4.1002368927001953e-01
    z[6,5,2]  R2609     -2.6114150881767273e-01
    z[6,5,2]  R2610     4.2280846834182739e-01
    z[6,5,2]  R2611     -2.4369031190872192e-01
    z[6,5,2]  R2612     0.328095406293869
    z[6,5,2]  R2613     3.8787674903869629e-01
    z[6,5,2]  R2614     2.9203245043754578e-01
    z[6,5,2]  R2615     -2.7586886286735535e-01
    z[6,5,2]  R2616     -2.2261705994606018e-01
    z[6,5,2]  R2617     3.4349447488784790e-01
    z[6,5,2]  R2618     -1.4417226612567902e-01
    z[6,5,2]  R2619     -1.2380160391330719e-01
    z[6,5,2]  R2620     -0.395833283662796
    z[6,5,2]  R2621     2.3510010540485382e-01
    z[6,5,2]  R2622     -2.0400816202163696e-01
    z[6,5,2]  R2623     -9.6323236823081970e-02
    z[6,5,2]  R2624     3.9766165614128113e-01
    z[6,5,2]  R2625     2.9063206911087036e-01
    z[6,5,2]  R2626     6.3487243652343750e-01
    z[6,5,2]  R2627     3.7208899855613708e-01
    z[6,5,2]  R2628     1.3445743918418884e-01
    z[6,5,2]  R2629     -4.3952378630638123e-01
    z[6,5,2]  R2630     -2.9135462641716003e-01
    z[6,5,2]  R2631     0.0922401174902916
    z[6,5,2]  R2632     4.4079285860061646e-01
    z[6,5,2]  R2633     -3.1065413355827332e-01
    z[6,5,2]  R2634     0.355376273393631
    z[6,5,2]  R2635     1.2634010612964630e-01
    z[6,5,2]  R2636     -4.2379835247993469e-01
    z[6,5,2]  R2637     3.0889004468917847e-01
    z[6,5,2]  R2638     -3.6990982294082642e-01
    z[6,5,2]  R2639     3.5622832179069519e-01
    z[6,5,2]  R2640     -4.7861674427986145e-01
    z[6,5,2]  R2641     -1.3612095499411225e-03
    z[6,5,2]  R2642     -1.4447963237762451e-01
    z[6,5,2]  R2643     2.8854611515998840e-01
    z[6,5,2]  R2644     2.1654902398586273e-01
    z[6,5,2]  R2645     6.2843970954418182e-02
    z[6,5,2]  R2646     -1.7592564225196838e-01
    z[6,5,2]  R2647     2.0112448930740356e-01
    z[6,5,2]  R2648     3.3232292532920837e-01
    z[6,5,2]  R2649     4.4547894597053528e-01
    z[6,5,2]  R2650     3.8438367843627930e-01
    z[6,5,2]  R2651     5.4896640777587891e-01
    z[6,5,2]  R2652     5.2453732490539551e-01
    z[6,5,2]  R2653     2.7125416323542595e-02
    z[6,5,2]  R2654     1.1758831888437271e-01
    z[6,5,2]  R2655     -1.3787375390529633e-01
    z[6,5,2]  R2656     -1.0769053548574448e-01
    z[6,5,2]  R2657     5.5269473791122437e-01
    z[6,5,2]  R2658     1.5828667581081390e-01
    z[6,5,2]  R2659     3.8291251659393311e-01
    z[6,5,2]  R2660     5.5537527799606323e-01
    z[6,5,2]  R2661     0.521673321723938
    z[6,5,2]  R2662     3.5263195633888245e-01
    z[6,5,2]  R2663     5.3273621946573257e-02
    z[6,5,2]  R2664     2.5538769364356995e-01
    z[6,5,2]  R2665     -2.4770677089691162e-01
    z[6,5,3]  R50       1
    z[6,5,3]  R59       -1
    z[6,5,3]  R2541     -1
    z[6,5,3]  R2542     1
    z[6,5,3]  R2549     1.8152070045471191e-01
    z[6,5,3]  R2550     3.0024429783225060e-02
    z[6,5,3]  R2551     -6.7329630255699158e-02
    z[6,5,3]  R2552     1.4320933818817139e-01
    z[6,5,3]  R2553     -5.0282761454582214e-02
    z[6,5,3]  R2554     5.4868827573955059e-03
    z[6,5,3]  R2555     -7.1596577763557434e-02
    z[6,5,3]  R2556     6.7600446939468384e-01
    z[6,5,3]  R2557     0.30000039935112
    z[6,5,3]  R2558     0.794006884098053
    z[6,5,3]  R2559     1.1935956031084061e-01
    z[6,5,3]  R2560     -6.9941782951354980e-01
    z[6,5,3]  R2561     0.301226943731308
    z[6,5,3]  R2562     3.8864842057228088e-01
    z[6,5,3]  R2563     2.3955328762531281e-01
    z[6,5,3]  R2564     2.5290060043334961e-01
    z[6,5,3]  R2565     7.8742668032646179e-02
    z[6,5,3]  R2566     4.4505367986857891e-03
    z[6,5,3]  R2567     -4.0808707475662231e-02
    z[6,5,3]  R2568     3.4651394933462143e-02
    z[6,5,3]  R2569     -4.1442832350730896e-01
    z[6,5,3]  R2570     -4.0571314096450806e-01
    z[6,5,3]  R2571     -7.3294615745544434e-01
    z[6,5,3]  R2572     2.0180614292621613e-01
    z[6,5,3]  R2573     -3.9547482132911682e-01
    z[6,5,3]  R2574     -3.7801361083984375e-01
    z[6,5,3]  R2575     -9.5134507864713669e-03
    z[6,5,3]  R2576     2.8614804148674011e-01
    z[6,5,3]  R2577     1.9862221181392670e-01
    z[6,5,3]  R2578     9.6923463046550751e-02
    z[6,5,3]  R2579     1.0683256387710571e-01
    z[6,5,3]  R2580     -3.4418621659278870e-01
    z[6,5,3]  R2581     -3.7811005115509033e-01
    z[6,5,3]  R2582     7.2333104908466339e-02
    z[6,5,3]  R2583     -1.9786326587200165e-01
    z[6,5,3]  R2584     -1.4166752994060516e-01
    z[6,5,3]  R2585     -8.8863588869571686e-02
    z[6,5,3]  R2586     -1.4615970849990845e-01
    z[6,5,3]  R2587     2.3510551452636719e-01
    z[6,5,3]  R2588     8.4521457552909851e-02
    z[6,5,3]  R2589     4.4326889514923096e-01
    z[6,5,3]  R2590     3.0297595262527466e-01
    z[6,5,3]  R2591     -6.4370416104793549e-02
    z[6,5,3]  R2592     2.6252093911170959e-01
    z[6,5,3]  R2593     2.3608949780464172e-01
    z[6,5,3]  R2594     -0.383390337228775
    z[6,5,3]  R2595     4.6426522731781006e-01
    z[6,5,3]  R2596     -5.3112649917602539e-01
    z[6,5,3]  R2597     -1.9288714230060577e-01
    z[6,5,3]  R2598     -2.5173398852348328e-01
    z[6,5,3]  R2599     -1.6380971670150757e-01
    z[6,5,3]  R2600     -9.9699504673480988e-02
    z[6,5,3]  R2601     1.8503373861312866e-01
    z[6,5,3]  R2602     5.2364283800125122e-01
    z[6,5,3]  R2603     5.2530074119567871e-01
    z[6,5,3]  R2604     1.2904337048530579e-01
    z[6,5,3]  R2605     -1.1997362226247787e-01
    z[6,5,3]  R2606     -2.3272280395030975e-01
    z[6,5,3]  R2607     4.1645620018243790e-02
    z[6,5,3]  R2608     2.0353603363037109e-01
    z[6,5,3]  R2609     1.6257666051387787e-01
    z[6,5,3]  R2610     -4.2788782715797424e-01
    z[6,5,3]  R2611     1.0887966305017471e-01
    z[6,5,3]  R2612     -2.7930095791816711e-01
    z[6,5,3]  R2613     -1.5871591866016388e-01
    z[6,5,3]  R2614     -0.0847240760922432
    z[6,5,3]  R2615     2.6343245059251785e-02
    z[6,5,3]  R2616     -2.5393217802047729e-01
    z[6,5,3]  R2617     -2.6008498668670654e-01
    z[6,5,3]  R2618     -2.3698411881923676e-01
    z[6,5,3]  R2619     -1.5202210843563080e-01
    z[6,5,3]  R2620     -5.7442313432693481e-01
    z[6,5,3]  R2621     -6.6975212097167969e-01
    z[6,5,3]  R2622     4.0605121850967407e-01
    z[6,5,3]  R2623     1.2707798182964325e-01
    z[6,5,3]  R2624     -5.3396087884902954e-01
    z[6,5,3]  R2625     -8.2362376153469086e-02
    z[6,5,3]  R2626     -4.7547496855258942e-02
    z[6,5,3]  R2627     0.0390746146440506
    z[6,5,3]  R2628     -7.0815253257751465e-01
    z[6,5,3]  R2629     -1.5038779377937317e-01
    z[6,5,3]  R2630     3.5058364272117615e-01
    z[6,5,3]  R2631     -1.2800544500350952e-01
    z[6,5,3]  R2632     1.1343742907047272e-01
    z[6,5,3]  R2633     1.1935079097747803e-01
    z[6,5,3]  R2634     2.7844834327697754e-01
    z[6,5,3]  R2635     3.0967876315116882e-01
    z[6,5,3]  R2636     -8.1400223076343536e-02
    z[6,5,3]  R2637     2.4099707603454590e-02
    z[6,5,3]  R2638     -5.8336075395345688e-02
    z[6,5,3]  R2639     -5.3081786632537842e-01
    z[6,5,3]  R2640     -3.9032605290412903e-01
    z[6,5,3]  R2641     -3.8091403245925903e-01
    z[6,5,3]  R2642     -1.1232873797416687e-01
    z[6,5,3]  R2643     2.5902670621871948e-01
    z[6,5,3]  R2644     -5.9855529107153416e-03
    z[6,5,3]  R2645     -2.2981157898902893e-01
    z[6,5,3]  R2646     0.0851278305053711
    z[6,5,3]  R2647     -4.1740727424621582e-01
    z[6,5,3]  R2648     -5.7617175579071045e-01
    z[6,5,3]  R2649     -4.9353456497192383e-01
    z[6,5,3]  R2650     1.1958824843168259e-01
    z[6,5,3]  R2651     -2.5140696763992310e-01
    z[6,5,3]  R2652     4.2824551463127136e-02
    z[6,5,3]  R2653     -3.0461966991424561e-02
    z[6,5,3]  R2654     0.380967378616333
    z[6,5,3]  R2655     1.2610933184623718e-01
    z[6,5,3]  R2656     6.9487184286117554e-02
    z[6,5,3]  R2657     -2.3484340310096741e-01
    z[6,5,3]  R2658     -4.0507983416318893e-02
    z[6,5,3]  R2659     2.1431854367256165e-01
    z[6,5,3]  R2660     -8.1822186708450317e-02
    z[6,5,3]  R2661     -2.6592493057250977e-01
    z[6,5,3]  R2662     -7.9549968242645264e-02
    z[6,5,3]  R2663     4.8030912876129150e-01
    z[6,5,3]  R2664     2.9239574074745178e-01
    z[6,5,3]  R2665     5.8321475982666016e-01
    z[6,5,4]  R51       1
    z[6,5,4]  R60       -1
    z[6,5,4]  R2543     -1
    z[6,5,4]  R2544     1
    z[6,5,4]  R2549     9.3230515718460083e-01
    z[6,5,4]  R2550     6.4843553304672241e-01
    z[6,5,4]  R2551     1.8940374255180359e-01
    z[6,5,4]  R2552     6.5703099966049194e-01
    z[6,5,4]  R2553     1.8320725858211517e-01
    z[6,5,4]  R2554     0.368007093667984
    z[6,5,4]  R2555     -3.9148527383804321e-01
    z[6,5,4]  R2556     -0.251006543636322
    z[6,5,4]  R2557     -3.4782004356384277e-01
    z[6,5,4]  R2558     -2.3502174019813538e-01
    z[6,5,4]  R2559     -1.3876289129257202e-01
    z[6,5,4]  R2560     -2.9398933053016663e-01
    z[6,5,4]  R2561     -2.4249014258384705e-01
    z[6,5,4]  R2562     -5.0091665983200073e-01
    z[6,5,4]  R2563     -4.2328283190727234e-01
    z[6,5,4]  R2564     6.4704000949859619e-02
    z[6,5,4]  R2565     -5.7221513986587524e-01
    z[6,5,4]  R2566     -5.2367347478866577e-01
    z[6,5,4]  R2567     -1.4771215617656708e-01
    z[6,5,4]  R2568     -3.8605967164039612e-01
    z[6,5,4]  R2569     4.0591907501220703e-01
    z[6,5,4]  R2570     -5.4308164119720459e-01
    z[6,5,4]  R2571     0.496865838766098
    z[6,5,4]  R2572     3.9167352952063084e-03
    z[6,5,4]  R2573     -5.3028100728988647e-01
    z[6,5,4]  R2574     -4.0601128339767456e-01
    z[6,5,4]  R2575     -2.8760954737663269e-01
    z[6,5,4]  R2576     -8.9635804295539856e-02
    z[6,5,4]  R2577     5.9240357950329781e-03
    z[6,5,4]  R2578     1.6294494271278381e-01
    z[6,5,4]  R2579     2.9447984695434570e-01
    z[6,5,4]  R2580     4.7585102915763855e-01
    z[6,5,4]  R2581     6.0992515087127686e-01
    z[6,5,4]  R2582     5.3177025169134140e-02
    z[6,5,4]  R2583     2.7024206519126892e-01
    z[6,5,4]  R2584     1.8455411493778229e-01
    z[6,5,4]  R2585     2.6636752486228943e-01
    z[6,5,4]  R2586     -0.532170832157135
    z[6,5,4]  R2587     -1.8462254106998444e-01
    z[6,5,4]  R2588     -2.2556984424591064e-01
    z[6,5,4]  R2589     2.7346667647361755e-01
    z[6,5,4]  R2590     1.0784591734409332e-01
    z[6,5,4]  R2591     2.4785001575946808e-01
    z[6,5,4]  R2592     2.0645757019519806e-01
    z[6,5,4]  R2593     3.7460610270500183e-01
    z[6,5,4]  R2594     0.00777652719989419
    z[6,5,4]  R2595     1.9684703648090363e-01
    z[6,5,4]  R2596     8.7425507605075836e-02
    z[6,5,4]  R2597     -3.7611982226371765e-01
    z[6,5,4]  R2598     8.4554873406887054e-02
    z[6,5,4]  R2599     4.4912289828062057e-02
    z[6,5,4]  R2600     -2.7962690591812134e-01
    z[6,5,4]  R2601     -1.9024184346199036e-01
    z[6,5,4]  R2602     -1.2297239154577255e-01
    z[6,5,4]  R2603     -1.7264726758003235e-01
    z[6,5,4]  R2604     -2.0380100607872009e-01
    z[6,5,4]  R2605     -1.6615694761276245e-01
    z[6,5,4]  R2606     4.9837347120046616e-02
    z[6,5,4]  R2607     1.0925633460283279e-01
    z[6,5,4]  R2608     -1.6090567409992218e-01
    z[6,5,4]  R2609     -2.3118624463677406e-02
    z[6,5,4]  R2610     1.8447768688201904e-01
    z[6,5,4]  R2611     -1.7895893752574921e-01
    z[6,5,4]  R2612     1.9566673040390015e-01
    z[6,5,4]  R2613     2.8256335854530334e-01
    z[6,5,4]  R2614     3.9508658647537231e-01
    z[6,5,4]  R2615     5.8149969577789307e-01
    z[6,5,4]  R2616     -1.5922186430543661e-03
    z[6,5,4]  R2617     -1.3166756927967072e-01
    z[6,5,4]  R2618     3.4759557247161865e-01
    z[6,5,4]  R2619     1.0526530444622040e-02
    z[6,5,4]  R2620     -1.4662112109363079e-02
    z[6,5,4]  R2621     5.3493720293045044e-01
    z[6,5,4]  R2622     -3.1676670908927917e-01
    z[6,5,4]  R2623     -3.7845450639724731e-01
    z[6,5,4]  R2624     -1.3518825289793313e-04
    z[6,5,4]  R2625     -3.3785271644592285e-01
    z[6,5,4]  R2626     -3.0541995167732239e-01
    z[6,5,4]  R2627     -1.8798868358135223e-01
    z[6,5,4]  R2628     6.7701435089111328e-01
    z[6,5,4]  R2629     6.3727504014968872e-01
    z[6,5,4]  R2630     -2.4129703640937805e-01
    z[6,5,4]  R2631     -2.4397027492523193e-01
    z[6,5,4]  R2632     2.3534847795963287e-01
    z[6,5,4]  R2633     -1.3661400973796844e-01
    z[6,5,4]  R2634     5.0487709045410156e-01
    z[6,5,4]  R2635     -5.3828172385692596e-02
    z[6,5,4]  R2636     1.3678911328315735e-01
    z[6,5,4]  R2637     -1.1057466268539429e-01
    z[6,5,4]  R2638     1.4980529248714447e-01
    z[6,5,4]  R2639     1.3441678881645203e-01
    z[6,5,4]  R2640     -5.0711023807525635e-01
    z[6,5,4]  R2641     3.5708293318748474e-01
    z[6,5,4]  R2642     6.6397930495440960e-03
    z[6,5,4]  R2643     3.1206998229026794e-01
    z[6,5,4]  R2644     1.1286263167858124e-01
    z[6,5,4]  R2645     5.7297468185424805e-02
    z[6,5,4]  R2646     -1.1313164606690407e-02
    z[6,5,4]  R2647     2.0030789077281952e-01
    z[6,5,4]  R2648     0.0537506528198719
    z[6,5,4]  R2649     9.6015287563204765e-03
    z[6,5,4]  R2650     -2.5005133822560310e-02
    z[6,5,4]  R2651     2.5555279850959778e-01
    z[6,5,4]  R2652     8.7121017277240753e-03
    z[6,5,4]  R2653     4.8978802561759949e-01
    z[6,5,4]  R2654     1.1990191414952278e-02
    z[6,5,4]  R2655     5.2671605348587036e-01
    z[6,5,4]  R2656     -0.384162575006485
    z[6,5,4]  R2657     2.5257727503776550e-01
    z[6,5,4]  R2658     3.8030573725700378e-01
    z[6,5,4]  R2659     -5.5059641599655151e-02
    z[6,5,4]  R2660     1.3978768885135651e-01
    z[6,5,4]  R2661     1.6580714285373688e-01
    z[6,5,4]  R2662     1.5398119390010834e-01
    z[6,5,4]  R2663     -1.0099439322948456e-01
    z[6,5,4]  R2664     -3.1638448126614094e-03
    z[6,5,4]  R2665     -3.8547852635383606e-01
    z[6,5,5]  R52       1
    z[6,5,5]  R61       -1
    z[6,5,5]  R2545     -1
    z[6,5,5]  R2546     1
    z[6,5,5]  R2549     -1.2142031639814377e-01
    z[6,5,5]  R2550     -7.2115555405616760e-02
    z[6,5,5]  R2551     5.1024538278579712e-01
    z[6,5,5]  R2552     3.6064037680625916e-01
    z[6,5,5]  R2553     -4.1838459670543671e-02
    z[6,5,5]  R2554     -7.2465568780899048e-02
    z[6,5,5]  R2555     -2.2915486246347427e-02
    z[6,5,5]  R2556     -1.7315704608336091e-03
    z[6,5,5]  R2557     6.7093491554260254e-01
    z[6,5,5]  R2558     3.9473345875740051e-01
    z[6,5,5]  R2559     3.2030217349529266e-02
    z[6,5,5]  R2560     -0.512298047542572
    z[6,5,5]  R2561     -3.6583945620805025e-03
    z[6,5,5]  R2562     -8.8016480207443237e-02
    z[6,5,5]  R2563     -1.2372436374425888e-01
    z[6,5,5]  R2564     8.2141578197479248e-02
    z[6,5,5]  R2565     9.2413406819105148e-03
    z[6,5,5]  R2566     8.6203746497631073e-02
    z[6,5,5]  R2567     0.583867073059082
    z[6,5,5]  R2568     3.3442100882530212e-01
    z[6,5,5]  R2569     -6.9211864471435547e-01
    z[6,5,5]  R2570     -4.0671899914741516e-01
    z[6,5,5]  R2571     1.3982349634170532e-01
    z[6,5,5]  R2572     -3.4050858020782471e-01
    z[6,5,5]  R2573     3.8897618651390076e-01
    z[6,5,5]  R2574     6.8253362178802490e-01
    z[6,5,5]  R2575     1.4928117394447327e-01
    z[6,5,5]  R2576     -7.5947046279907227e-03
    z[6,5,5]  R2577     -8.7791271507740021e-03
    z[6,5,5]  R2578     3.1882032752037048e-01
    z[6,5,5]  R2579     -5.7182990014553070e-02
    z[6,5,5]  R2580     -1.6890972852706909e-01
    z[6,5,5]  R2581     -6.4772136509418488e-02
    z[6,5,5]  R2582     1.0017333924770355e-01
    z[6,5,5]  R2583     0.231211319565773
    z[6,5,5]  R2584     5.7747727632522583e-01
    z[6,5,5]  R2585     2.6583153009414673e-01
    z[6,5,5]  R2586     2.2481076419353485e-01
    z[6,5,5]  R2587     1.3052079826593399e-02
    z[6,5,5]  R2588     1.5171720087528229e-01
    z[6,5,5]  R2589     -4.3023936450481415e-02
    z[6,5,5]  R2590     0.0353940911591053
    z[6,5,5]  R2591     4.4357147812843323e-01
    z[6,5,5]  R2592     4.7407639026641846e-01
    z[6,5,5]  R2593     6.2767281197011471e-03
    z[6,5,5]  R2594     -1.9781421124935150e-01
    z[6,5,5]  R2595     -1.9604696333408356e-01
    z[6,5,5]  R2596     1.9839632511138916e-01
    z[6,5,5]  R2597     3.3862125873565674e-01
    z[6,5,5]  R2598     -3.0617916956543922e-02
    z[6,5,5]  R2599     2.9147979617118835e-01
    z[6,5,5]  R2600     -3.6393553018569946e-01
    z[6,5,5]  R2601     -4.2408636212348938e-01
    z[6,5,5]  R2602     -1.2743981555104256e-02
    z[6,5,5]  R2603     -1.8517075479030609e-01
    z[6,5,5]  R2604     -3.0390882492065430e-01
    z[6,5,5]  R2605     -2.0238092541694641e-01
    z[6,5,5]  R2606     1.9782733917236328e-01
    z[6,5,5]  R2607     -9.8644390702247620e-02
    z[6,5,5]  R2608     -0.148346409201622
    z[6,5,5]  R2609     -4.6158552169799805e-01
    z[6,5,5]  R2610     -2.9842260479927063e-01
    z[6,5,5]  R2611     -3.4983307123184204e-01
    z[6,5,5]  R2612     -0.377279132604599
    z[6,5,5]  R2613     3.8751029968261719e-01
    z[6,5,5]  R2614     2.0157396793365479e-02
    z[6,5,5]  R2615     -3.3282953500747681e-01
    z[6,5,5]  R2616     5.0642937421798706e-01
    z[6,5,5]  R2617     -4.5824404805898666e-02
    z[6,5,5]  R2618     -6.2417805194854736e-01
    z[6,5,5]  R2619     -0.0754033774137497
    z[6,5,5]  R2620     -6.4436845481395721e-02
    z[6,5,5]  R2621     1.9234506785869598e-01
    z[6,5,5]  R2622     2.7806267142295837e-01
    z[6,5,5]  R2623     -2.3896206170320511e-02
    z[6,5,5]  R2624     -4.7335988283157349e-01
    z[6,5,5]  R2625     6.2632042169570923e-01
    z[6,5,5]  R2626     1.9467703998088837e-01
    z[6,5,5]  R2627     -4.9738940596580505e-01
    z[6,5,5]  R2628     -2.1414436399936676e-02
    z[6,5,5]  R2629     3.2057842612266541e-01
    z[6,5,5]  R2630     3.8099128007888794e-01
    z[6,5,5]  R2631     -6.7592531442642212e-01
    z[6,5,5]  R2632     5.3517264127731323e-01
    z[6,5,5]  R2633     2.1830736100673676e-01
    z[6,5,5]  R2634     -6.1397127807140350e-02
    z[6,5,5]  R2635     -2.8867498040199280e-01
    z[6,5,5]  R2636     -4.4239038228988647e-01
    z[6,5,5]  R2637     -2.9919949173927307e-01
    z[6,5,5]  R2638     -1.6329869627952576e-01
    z[6,5,5]  R2639     -5.9690177440643311e-01
    z[6,5,5]  R2640     1.0459543205797672e-02
    z[6,5,5]  R2641     3.1147959828376770e-01
    z[6,5,5]  R2642     9.0109594166278839e-02
    z[6,5,5]  R2643     3.6661437153816223e-01
    z[6,5,5]  R2644     -4.7735314816236496e-02
    z[6,5,5]  R2645     -2.3951521515846252e-01
    z[6,5,5]  R2646     -7.1482270956039429e-02
    z[6,5,5]  R2647     1.4146538078784943e-01
    z[6,5,5]  R2648     4.1564801335334778e-01
    z[6,5,5]  R2649     5.2571278065443039e-02
    z[6,5,5]  R2650     -6.4349097013473511e-01
    z[6,5,5]  R2651     -1.4879024028778076e-01
    z[6,5,5]  R2652     -4.0760420262813568e-02
    z[6,5,5]  R2653     2.3870344460010529e-01
    z[6,5,5]  R2654     -9.2644453048706055e-02
    z[6,5,5]  R2655     -1.2771388888359070e-01
    z[6,5,5]  R2656     1.2331591546535492e-01
    z[6,5,5]  R2657     -1.2022284418344498e-01
    z[6,5,5]  R2658     0.382844477891922
    z[6,5,5]  R2659     -9.3877725303173065e-02
    z[6,5,5]  R2660     -8.1795983016490936e-02
    z[6,5,5]  R2661     1.7924067378044128e-01
    z[6,5,5]  R2662     1.5473881363868713e-01
    z[6,5,5]  R2663     1.0495068877935410e-01
    z[6,5,5]  R2664     -3.1709831953048706e-01
    z[6,5,5]  R2665     -2.2529639303684235e-01
    z[6,5,6]  R53       1
    z[6,5,6]  R62       -1
    z[6,5,6]  R2547     -1
    z[6,5,6]  R2548     1
    z[6,5,6]  R2549     -0.0995897725224495
    z[6,5,6]  R2550     1.9014886021614075e-01
    z[6,5,6]  R2551     4.7758764028549194e-01
    z[6,5,6]  R2552     -2.7407726645469666e-01
    z[6,5,6]  R2553     -0.755608856678009
    z[6,5,6]  R2554     5.3503835201263428e-01
    z[6,5,6]  R2555     3.5406398773193359e-01
    z[6,5,6]  R2556     -5.6641805917024612e-02
    z[6,5,6]  R2557     -4.0861517190933228e-02
    z[6,5,6]  R2558     4.1237942874431610e-02
    z[6,5,6]  R2559     1.1922285705804825e-01
    z[6,5,6]  R2560     0.0891263335943222
    z[6,5,6]  R2561     9.6925109624862671e-02
    z[6,5,6]  R2562     -3.4527987241744995e-01
    z[6,5,6]  R2563     -2.0519843697547913e-01
    z[6,5,6]  R2564     -0.374266117811203
    z[6,5,6]  R2565     -1.5563745796680450e-01
    z[6,5,6]  R2566     0.543026864528656
    z[6,5,6]  R2567     -3.5846036672592163e-01
    z[6,5,6]  R2568     -4.5592454075813293e-01
    z[6,5,6]  R2569     1.1840562522411346e-01
    z[6,5,6]  R2570     -2.0762926340103149e-01
    z[6,5,6]  R2571     -1.3053172826766968e-01
    z[6,5,6]  R2572     -4.2118576169013977e-01
    z[6,5,6]  R2573     1.2796354480087757e-02
    z[6,5,6]  R2574     -3.1583356857299805e-01
    z[6,5,6]  R2575     -0.184713214635849
    z[6,5,6]  R2576     -1.4731016755104065e-01
    z[6,5,6]  R2577     -6.6391073167324066e-02
    z[6,5,6]  R2578     2.0331348478794098e-01
    z[6,5,6]  R2579     -8.5120923817157745e-02
    z[6,5,6]  R2580     -1.0575703531503677e-01
    z[6,5,6]  R2581     -0.09307861328125
    z[6,5,6]  R2582     2.4711626768112183e-01
    z[6,5,6]  R2583     2.0318250358104706e-01
    z[6,5,6]  R2584     -3.3131068944931030e-01
    z[6,5,6]  R2585     -6.8389378488063812e-02
    z[6,5,6]  R2586     3.6516536027193069e-02
    z[6,5,6]  R2587     0.0774056687951088
    z[6,5,6]  R2588     -1.4727701246738434e-01
    z[6,5,6]  R2589     -1.5174393355846405e-01
    z[6,5,6]  R2590     -4.7539597749710083e-01
    z[6,5,6]  R2591     2.2532801330089569e-01
    z[6,5,6]  R2592     8.6684837937355042e-02
    z[6,5,6]  R2593     3.5144168138504028e-01
    z[6,5,6]  R2594     -1.7987428605556488e-01
    z[6,5,6]  R2595     3.6844724416732788e-01
    z[6,5,6]  R2596     0.677962064743042
    z[6,5,6]  R2597     -5.9153027832508087e-02
    z[6,5,6]  R2598     0.919495165348053
    z[6,5,6]  R2599     0.814403235912323
    z[6,5,6]  R2600     -1.8726487457752228e-01
    z[6,5,6]  R2601     3.9939272403717041e-01
    z[6,5,6]  R2602     2.7433177828788757e-01
    z[6,5,6]  R2603     -3.4588745236396790e-01
    z[6,5,6]  R2604     5.4620647430419922e-01
    z[6,5,6]  R2605     -1.9505728781223297e-01
    z[6,5,6]  R2606     2.5381517410278320e-01
    z[6,5,6]  R2607     3.0845694709569216e-03
    z[6,5,6]  R2608     -0.074495330452919
    z[6,5,6]  R2609     -2.7877295017242432e-01
    z[6,5,6]  R2610     -3.9746654033660889e-01
    z[6,5,6]  R2611     -5.3462157957255840e-03
    z[6,5,6]  R2612     4.3215584754943848e-01
    z[6,5,6]  R2613     -8.3619892597198486e-02
    z[6,5,6]  R2614     -2.7281185984611511e-01
    z[6,5,6]  R2615     -3.6632496118545532e-01
    z[6,5,6]  R2616     1.1175787448883057e-01
    z[6,5,6]  R2617     -8.6105622351169586e-02
    z[6,5,6]  R2618     -3.7456639111042023e-02
    z[6,5,6]  R2619     3.1134110689163208e-01
    z[6,5,6]  R2620     2.9562366008758545e-01
    z[6,5,6]  R2621     -8.3799540996551514e-02
    z[6,5,6]  R2622     -2.8917360305786133e-01
    z[6,5,6]  R2623     -3.4714111685752869e-01
    z[6,5,6]  R2624     1.2736445665359497e-01
    z[6,5,6]  R2625     -6.8762958049774170e-02
    z[6,5,6]  R2626     -1.6143139451742172e-02
    z[6,5,6]  R2627     2.1712635457515717e-01
    z[6,5,6]  R2628     1.1941968649625778e-01
    z[6,5,6]  R2629     2.5954738259315491e-01
    z[6,5,6]  R2630     -6.4274176955223083e-02
    z[6,5,6]  R2631     -3.3101800829172134e-02
    z[6,5,6]  R2632     -1.3286098837852478e-01
    z[6,5,6]  R2633     -1.1625555902719498e-01
    z[6,5,6]  R2634     -3.4496295452117920e-01
    z[6,5,6]  R2635     2.6258850097656250e-01
    z[6,5,6]  R2636     1.3789756596088409e-01
    z[6,5,6]  R2637     5.6865904480218887e-02
    z[6,5,6]  R2638     -2.2241444885730743e-01
    z[6,5,6]  R2639     0.195271834731102
    z[6,5,6]  R2640     -3.7824764847755432e-01
    z[6,5,6]  R2641     3.0041828751564026e-01
    z[6,5,6]  R2642     -3.9020174741744995e-01
    z[6,5,6]  R2643     -4.0451325476169586e-02
    z[6,5,6]  R2644     2.4714720249176025e-01
    z[6,5,6]  R2645     -7.1370363235473633e-01
    z[6,5,6]  R2646     6.2678046524524689e-02
    z[6,5,6]  R2647     3.5645064711570740e-01
    z[6,5,6]  R2648     -3.4316653013229370e-01
    z[6,5,6]  R2649     -3.2001107465475798e-03
    z[6,5,6]  R2650     -3.3547705411911011e-01
    z[6,5,6]  R2651     2.5705745816230774e-01
    z[6,5,6]  R2652     1.5021668374538422e-01
    z[6,5,6]  R2653     -3.2108661532402039e-01
    z[6,5,6]  R2654     1.7515990138053894e-01
    z[6,5,6]  R2655     -6.1666302382946014e-02
    z[6,5,6]  R2656     -8.5834875702857971e-02
    z[6,5,6]  R2657     2.0520697534084320e-01
    z[6,5,6]  R2658     -4.5186918228864670e-02
    z[6,5,6]  R2659     2.4321815371513367e-01
    z[6,5,6]  R2660     -1.5244592726230621e-01
    z[6,5,6]  R2661     -2.7870634198188782e-01
    z[6,5,6]  R2662     1.2779383361339569e-01
    z[6,5,6]  R2663     -3.3953779935836792e-01
    z[6,5,6]  R2664     -0.440801203250885
    z[6,5,6]  R2665     -3.7467747926712036e-02
    length[0]  OBJ       1
    length[1]  OBJ       1
    length[2]  OBJ       1
    length[3]  OBJ       1
    length[4]  OBJ       1
    length[5]  OBJ       1
    length[6]  OBJ       1
    delta[0,0]  R2        1
    delta[0,1]  R3        1
    delta[0,2]  R4        1
    delta[0,3]  R5        1
    delta[0,4]  R6        1
    delta[0,5]  R7        1
    delta[0,6]  R8        1
    delta[1,0]  R11       1
    delta[1,1]  R12       1
    delta[1,2]  R13       1
    delta[1,3]  R14       1
    delta[1,4]  R15       1
    delta[1,5]  R16       1
    delta[1,6]  R17       1
    delta[2,0]  R20       1
    delta[2,1]  R21       1
    delta[2,2]  R22       1
    delta[2,3]  R23       1
    delta[2,4]  R24       1
    delta[2,5]  R25       1
    delta[2,6]  R26       1
    delta[3,0]  R29       1
    delta[3,1]  R30       1
    delta[3,2]  R31       1
    delta[3,3]  R32       1
    delta[3,4]  R33       1
    delta[3,5]  R34       1
    delta[3,6]  R35       1
    delta[4,0]  R38       1
    delta[4,1]  R39       1
    delta[4,2]  R40       1
    delta[4,3]  R41       1
    delta[4,4]  R42       1
    delta[4,5]  R43       1
    delta[4,6]  R44       1
    delta[5,0]  R47       1
    delta[5,1]  R48       1
    delta[5,2]  R49       1
    delta[5,3]  R50       1
    delta[5,4]  R51       1
    delta[5,5]  R52       1
    delta[5,6]  R53       1
    delta[6,0]  R56       1
    delta[6,1]  R57       1
    delta[6,2]  R58       1
    delta[6,3]  R59       1
    delta[6,4]  R60       1
    delta[6,5]  R61       1
    delta[6,6]  R62       1
RHS
    RHS1      R1        1
    RHS1      R10       1
    RHS1      R19       1
    RHS1      R28       1
    RHS1      R37       1
    RHS1      R46       1
    RHS1      R55       1
    RHS1      R63       1
    RHS1      R64       -1
BOUNDS
 BV BND1      phi[0,1]
 BV BND1      phi[1,0]
 BV BND1      phi[0,4]
 BV BND1      phi[4,0]
 BV BND1      phi[7,0]
 BV BND1      phi[1,2]
 BV BND1      phi[2,1]
 BV BND1      phi[1,4]
 BV BND1      phi[4,1]
 BV BND1      phi[2,3]
 BV BND1      phi[3,2]
 BV BND1      phi[2,5]
 BV BND1      phi[5,2]
 BV BND1      phi[2,6]
 BV BND1      phi[6,2]
 BV BND1      phi[3,5]
 BV BND1      phi[5,3]
 BV BND1      phi[3,6]
 BV BND1      phi[6,3]
 BV BND1      phi[3,8]
 BV BND1      phi[4,5]
 BV BND1      phi[5,4]
 BV BND1      phi[5,6]
 BV BND1      phi[6,5]
 BV BND1      phi[6,8]
 FR BND1      z[0,1,0]
 FR BND1      z[0,1,1]
 FR BND1      z[0,1,2]
 FR BND1      z[0,1,3]
 FR BND1      z[0,1,4]
 FR BND1      z[0,1,5]
 FR BND1      z[0,1,6]
 FR BND1      z[1,0,0]
 FR BND1      z[1,0,1]
 FR BND1      z[1,0,2]
 FR BND1      z[1,0,3]
 FR BND1      z[1,0,4]
 FR BND1      z[1,0,5]
 FR BND1      z[1,0,6]
 FR BND1      z[0,4,0]
 FR BND1      z[0,4,1]
 FR BND1      z[0,4,2]
 FR BND1      z[0,4,3]
 FR BND1      z[0,4,4]
 FR BND1      z[0,4,5]
 FR BND1      z[0,4,6]
 FR BND1      z[4,0,0]
 FR BND1      z[4,0,1]
 FR BND1      z[4,0,2]
 FR BND1      z[4,0,3]
 FR BND1      z[4,0,4]
 FR BND1      z[4,0,5]
 FR BND1      z[4,0,6]
 FR BND1      z[1,2,0]
 FR BND1      z[1,2,1]
 FR BND1      z[1,2,2]
 FR BND1      z[1,2,3]
 FR BND1      z[1,2,4]
 FR BND1      z[1,2,5]
 FR BND1      z[1,2,6]
 FR BND1      z[2,1,0]
 FR BND1      z[2,1,1]
 FR BND1      z[2,1,2]
 FR BND1      z[2,1,3]
 FR BND1      z[2,1,4]
 FR BND1      z[2,1,5]
 FR BND1      z[2,1,6]
 FR BND1      z[1,4,0]
 FR BND1      z[1,4,1]
 FR BND1      z[1,4,2]
 FR BND1      z[1,4,3]
 FR BND1      z[1,4,4]
 FR BND1      z[1,4,5]
 FR BND1      z[1,4,6]
 FR BND1      z[4,1,0]
 FR BND1      z[4,1,1]
 FR BND1      z[4,1,2]
 FR BND1      z[4,1,3]
 FR BND1      z[4,1,4]
 FR BND1      z[4,1,5]
 FR BND1      z[4,1,6]
 FR BND1      z[2,3,0]
 FR BND1      z[2,3,1]
 FR BND1      z[2,3,2]
 FR BND1      z[2,3,3]
 FR BND1      z[2,3,4]
 FR BND1      z[2,3,5]
 FR BND1      z[2,3,6]
 FR BND1      z[3,2,0]
 FR BND1      z[3,2,1]
 FR BND1      z[3,2,2]
 FR BND1      z[3,2,3]
 FR BND1      z[3,2,4]
 FR BND1      z[3,2,5]
 FR BND1      z[3,2,6]
 FR BND1      z[2,5,0]
 FR BND1      z[2,5,1]
 FR BND1      z[2,5,2]
 FR BND1      z[2,5,3]
 FR BND1      z[2,5,4]
 FR BND1      z[2,5,5]
 FR BND1      z[2,5,6]
 FR BND1      z[5,2,0]
 FR BND1      z[5,2,1]
 FR BND1      z[5,2,2]
 FR BND1      z[5,2,3]
 FR BND1      z[5,2,4]
 FR BND1      z[5,2,5]
 FR BND1      z[5,2,6]
 FR BND1      z[2,6,0]
 FR BND1      z[2,6,1]
 FR BND1      z[2,6,2]
 FR BND1      z[2,6,3]
 FR BND1      z[2,6,4]
 FR BND1      z[2,6,5]
 FR BND1      z[2,6,6]
 FR BND1      z[6,2,0]
 FR BND1      z[6,2,1]
 FR BND1      z[6,2,2]
 FR BND1      z[6,2,3]
 FR BND1      z[6,2,4]
 FR BND1      z[6,2,5]
 FR BND1      z[6,2,6]
 FR BND1      z[3,5,0]
 FR BND1      z[3,5,1]
 FR BND1      z[3,5,2]
 FR BND1      z[3,5,3]
 FR BND1      z[3,5,4]
 FR BND1      z[3,5,5]
 FR BND1      z[3,5,6]
 FR BND1      z[5,3,0]
 FR BND1      z[5,3,1]
 FR BND1      z[5,3,2]
 FR BND1      z[5,3,3]
 FR BND1      z[5,3,4]
 FR BND1      z[5,3,5]
 FR BND1      z[5,3,6]
 FR BND1      z[3,6,0]
 FR BND1      z[3,6,1]
 FR BND1      z[3,6,2]
 FR BND1      z[3,6,3]
 FR BND1      z[3,6,4]
 FR BND1      z[3,6,5]
 FR BND1      z[3,6,6]
 FR BND1      z[6,3,0]
 FR BND1      z[6,3,1]
 FR BND1      z[6,3,2]
 FR BND1      z[6,3,3]
 FR BND1      z[6,3,4]
 FR BND1      z[6,3,5]
 FR BND1      z[6,3,6]
 FR BND1      z[4,5,0]
 FR BND1      z[4,5,1]
 FR BND1      z[4,5,2]
 FR BND1      z[4,5,3]
 FR BND1      z[4,5,4]
 FR BND1      z[4,5,5]
 FR BND1      z[4,5,6]
 FR BND1      z[5,4,0]
 FR BND1      z[5,4,1]
 FR BND1      z[5,4,2]
 FR BND1      z[5,4,3]
 FR BND1      z[5,4,4]
 FR BND1      z[5,4,5]
 FR BND1      z[5,4,6]
 FR BND1      z[5,6,0]
 FR BND1      z[5,6,1]
 FR BND1      z[5,6,2]
 FR BND1      z[5,6,3]
 FR BND1      z[5,6,4]
 FR BND1      z[5,6,5]
 FR BND1      z[5,6,6]
 FR BND1      z[6,5,0]
 FR BND1      z[6,5,1]
 FR BND1      z[6,5,2]
 FR BND1      z[6,5,3]
 FR BND1      z[6,5,4]
 FR BND1      z[6,5,5]
 FR BND1      z[6,5,6]
 FR BND1      delta[0,0]
 FR BND1      delta[0,1]
 FR BND1      delta[0,2]
 FR BND1      delta[0,3]
 FR BND1      delta[0,4]
 FR BND1      delta[0,5]
 FR BND1      delta[0,6]
 FR BND1      delta[1,0]
 FR BND1      delta[1,1]
 FR BND1      delta[1,2]
 FR BND1      delta[1,3]
 FR BND1      delta[1,4]
 FR BND1      delta[1,5]
 FR BND1      delta[1,6]
 FR BND1      delta[2,0]
 FR BND1      delta[2,1]
 FR BND1      delta[2,2]
 FR BND1      delta[2,3]
 FR BND1      delta[2,4]
 FR BND1      delta[2,5]
 FR BND1      delta[2,6]
 FR BND1      delta[3,0]
 FR BND1      delta[3,1]
 FR BND1      delta[3,2]
 FR BND1      delta[3,3]
 FR BND1      delta[3,4]
 FR BND1      delta[3,5]
 FR BND1      delta[3,6]
 FR BND1      delta[4,0]
 FR BND1      delta[4,1]
 FR BND1      delta[4,2]
 FR BND1      delta[4,3]
 FR BND1      delta[4,4]
 FR BND1      delta[4,5]
 FR BND1      delta[4,6]
 FR BND1      delta[5,0]
 FR BND1      delta[5,1]
 FR BND1      delta[5,2]
 FR BND1      delta[5,3]
 FR BND1      delta[5,4]
 FR BND1      delta[5,5]
 FR BND1      delta[5,6]
 FR BND1      delta[6,0]
 FR BND1      delta[6,1]
 FR BND1      delta[6,2]
 FR BND1      delta[6,3]
 FR BND1      delta[6,4]
 FR BND1      delta[6,5]
 FR BND1      delta[6,6]
QCMATRIX   qc0     
    length[0]  length[0]  -1
    delta[0,0]  delta[0,0]  1
    delta[0,1]  delta[0,1]  1
    delta[0,2]  delta[0,2]  1
    delta[0,3]  delta[0,3]  1
    delta[0,4]  delta[0,4]  1
    delta[0,5]  delta[0,5]  1
    delta[0,6]  delta[0,6]  1
QCMATRIX   qc1     
    length[1]  length[1]  -1
    delta[1,0]  delta[1,0]  1
    delta[1,1]  delta[1,1]  1
    delta[1,2]  delta[1,2]  1
    delta[1,3]  delta[1,3]  1
    delta[1,4]  delta[1,4]  1
    delta[1,5]  delta[1,5]  1
    delta[1,6]  delta[1,6]  1
QCMATRIX   qc2     
    length[2]  length[2]  -1
    delta[2,0]  delta[2,0]  1
    delta[2,1]  delta[2,1]  1
    delta[2,2]  delta[2,2]  1
    delta[2,3]  delta[2,3]  1
    delta[2,4]  delta[2,4]  1
    delta[2,5]  delta[2,5]  1
    delta[2,6]  delta[2,6]  1
QCMATRIX   qc3     
    length[3]  length[3]  -1
    delta[3,0]  delta[3,0]  1
    delta[3,1]  delta[3,1]  1
    delta[3,2]  delta[3,2]  1
    delta[3,3]  delta[3,3]  1
    delta[3,4]  delta[3,4]  1
    delta[3,5]  delta[3,5]  1
    delta[3,6]  delta[3,6]  1
QCMATRIX   qc4     
    length[4]  length[4]  -1
    delta[4,0]  delta[4,0]  1
    delta[4,1]  delta[4,1]  1
    delta[4,2]  delta[4,2]  1
    delta[4,3]  delta[4,3]  1
    delta[4,4]  delta[4,4]  1
    delta[4,5]  delta[4,5]  1
    delta[4,6]  delta[4,6]  1
QCMATRIX   qc5     
    length[5]  length[5]  -1
    delta[5,0]  delta[5,0]  1
    delta[5,1]  delta[5,1]  1
    delta[5,2]  delta[5,2]  1
    delta[5,3]  delta[5,3]  1
    delta[5,4]  delta[5,4]  1
    delta[5,5]  delta[5,5]  1
    delta[5,6]  delta[5,6]  1
QCMATRIX   qc6     
    length[6]  length[6]  -1
    delta[6,0]  delta[6,0]  1
    delta[6,1]  delta[6,1]  1
    delta[6,2]  delta[6,2]  1
    delta[6,3]  delta[6,3]  1
    delta[6,4]  delta[6,4]  1
    delta[6,5]  delta[6,5]  1
    delta[6,6]  delta[6,6]  1
ENDATA
