NAME LGCS_GCS_Eq5_5_projected
ROWS
 N  OBJ
 E  R0      
 L  R1      
 E  R2      
 E  R3      
 E  R4      
 E  R5      
 E  R6      
 E  R7      
 E  R8      
 E  R9      
 L  R10     
 E  R11     
 E  R12     
 E  R13     
 E  R14     
 E  R15     
 E  R16     
 E  R17     
 E  R18     
 L  R19     
 E  R20     
 E  R21     
 E  R22     
 E  R23     
 E  R24     
 E  R25     
 E  R26     
 E  R27     
 L  R28     
 E  R29     
 E  R30     
 E  R31     
 E  R32     
 E  R33     
 E  R34     
 E  R35     
 E  R36     
 L  R37     
 E  R38     
 E  R39     
 E  R40     
 E  R41     
 E  R42     
 E  R43     
 E  R44     
 E  R45     
 L  R46     
 E  R47     
 E  R48     
 E  R49     
 E  R50     
 E  R51     
 E  R52     
 E  R53     
 E  R54     
 L  R55     
 E  R56     
 E  R57     
 E  R58     
 E  R59     
 E  R60     
 E  R61     
 E  R62     
 E  R63     
 L  R64     
 E  R65     
 E  R66     
 E  R67     
 E  R68     
 E  R69     
 E  R70     
 E  R71     
 E  R72     
 E  R73     
 L  R74     
 L  R75     
 L  R76     
 L  R77     
 L  R78     
 L  R79     
 L  R80     
 L  R81     
 L  R82     
 L  R83     
 L  R84     
 L  R85     
 L  R86     
 L  R87     
 L  R88     
 L  R89     
 L  R90     
 L  R91     
 L  R92     
 L  R93     
 L  R94     
 L  R95     
 L  R96     
 L  R97     
 L  R98     
 L  R99     
 L  R100    
 L  R101    
 L  R102    
 L  R103    
 L  R104    
 L  R105    
 L  R106    
 L  R107    
 L  R108    
 L  R109    
 L  R110    
 L  R111    
 L  R112    
 L  R113    
 L  R114    
 L  R115    
 L  R116    
 L  R117    
 L  R118    
 L  R119    
 L  R120    
 L  R121    
 L  R122    
 L  R123    
 L  R124    
 L  R125    
 L  R126    
 L  R127    
 L  R128    
 L  R129    
 L  R130    
 L  R131    
 L  R132    
 L  R133    
 L  R134    
 L  R135    
 L  R136    
 L  R137    
 L  R138    
 L  R139    
 L  R140    
 L  R141    
 L  R142    
 L  R143    
 L  R144    
 L  R145    
 L  R146    
 L  R147    
 L  R148    
 L  R149    
 L  R150    
 L  R151    
 L  R152    
 L  R153    
 L  R154    
 L  R155    
 L  R156    
 L  R157    
 L  R158    
 L  R159    
 L  R160    
 L  R161    
 L  R162    
 L  R163    
 L  R164    
 L  R165    
 L  R166    
 L  R167    
 L  R168    
 L  R169    
 L  R170    
 L  R171    
 L  R172    
 L  R173    
 L  R174    
 L  R175    
 L  R176    
 L  R177    
 L  R178    
 L  R179    
 L  R180    
 L  R181    
 L  R182    
 L  R183    
 L  R184    
 L  R185    
 L  R186    
 L  R187    
 L  R188    
 L  R189    
 L  R190    
 L  R191    
 L  R192    
 L  R193    
 L  R194    
 L  R195    
 L  R196    
 L  R197    
 L  R198    
 L  R199    
 L  R200    
 L  R201    
 L  R202    
 L  R203    
 L  R204    
 L  R205    
 L  R206    
 L  R207    
 L  R208    
 L  R209    
 L  R210    
 L  R211    
 L  R212    
 L  R213    
 L  R214    
 L  R215    
 L  R216    
 L  R217    
 L  R218    
 L  R219    
 L  R220    
 L  R221    
 L  R222    
 L  R223    
 L  R224    
 L  R225    
 L  R226    
 L  R227    
 L  R228    
 L  R229    
 L  R230    
 L  R231    
 L  R232    
 L  R233    
 L  R234    
 L  R235    
 L  R236    
 L  R237    
 L  R238    
 L  R239    
 L  R240    
 L  R241    
 L  R242    
 L  R243    
 L  R244    
 L  R245    
 L  R246    
 L  R247    
 L  R248    
 L  R249    
 L  R250    
 L  R251    
 L  R252    
 L  R253    
 L  R254    
 L  R255    
 L  R256    
 L  R257    
 L  R258    
 L  R259    
 L  R260    
 L  R261    
 L  R262    
 L  R263    
 L  R264    
 L  R265    
 L  R266    
 L  R267    
 L  R268    
 L  R269    
 L  R270    
 L  R271    
 L  R272    
 L  R273    
 L  R274    
 L  R275    
 L  R276    
 L  R277    
 L  R278    
 L  R279    
 L  R280    
 L  R281    
 L  R282    
 L  R283    
 L  R284    
 L  R285    
 L  R286    
 L  R287    
 L  R288    
 L  R289    
 L  R290    
 L  R291    
 L  R292    
 L  R293    
 L  R294    
 L  R295    
 L  R296    
 L  R297    
 L  R298    
 L  R299    
 L  R300    
 L  R301    
 L  R302    
 L  R303    
 L  R304    
 L  R305    
 L  R306    
 L  R307    
 L  R308    
 L  R309    
 L  R310    
 L  R311    
 L  R312    
 L  R313    
 L  R314    
 L  R315    
 L  R316    
 L  R317    
 L  R318    
 L  R319    
 L  R320    
 L  R321    
 L  R322    
 L  R323    
 L  R324    
 L  R325    
 L  R326    
 L  R327    
 L  R328    
 L  R329    
 L  R330    
 L  R331    
 L  R332    
 L  R333    
 L  R334    
 L  R335    
 L  R336    
 L  R337    
 L  R338    
 L  R339    
 L  R340    
 L  R341    
 L  R342    
 L  R343    
 L  R344    
 L  R345    
 L  R346    
 L  R347    
 L  R348    
 L  R349    
 L  R350    
 L  R351    
 L  R352    
 L  R353    
 L  R354    
 L  R355    
 L  R356    
 L  R357    
 L  R358    
 L  R359    
 L  R360    
 L  R361    
 L  R362    
 L  R363    
 L  R364    
 L  R365    
 L  R366    
 L  R367    
 L  R368    
 L  R369    
 L  R370    
 L  R371    
 L  R372    
 L  R373    
 L  R374    
 L  R375    
 L  R376    
 L  R377    
 L  R378    
 L  R379    
 L  R380    
 L  R381    
 L  R382    
 L  R383    
 L  R384    
 L  R385    
 L  R386    
 L  R387    
 L  R388    
 L  R389    
 L  R390    
 L  R391    
 L  R392    
 L  R393    
 L  R394    
 L  R395    
 L  R396    
 L  R397    
 L  R398    
 L  R399    
 L  R400    
 L  R401    
 L  R402    
 L  R403    
 L  R404    
 L  R405    
 L  R406    
 L  R407    
 L  R408    
 L  R409    
 L  R410    
 L  R411    
 L  R412    
 L  R413    
 L  R414    
 L  R415    
 L  R416    
 L  R417    
 L  R418    
 L  R419    
 L  R420    
 L  R421    
 L  R422    
 L  R423    
 L  R424    
 L  R425    
 L  R426    
 L  R427    
 L  R428    
 L  R429    
 L  R430    
 L  R431    
 L  R432    
 L  R433    
 L  R434    
 L  R435    
 L  R436    
 L  R437    
 L  R438    
 L  R439    
 L  R440    
 L  R441    
 L  R442    
 L  R443    
 L  R444    
 L  R445    
 L  R446    
 L  R447    
 L  R448    
 L  R449    
 L  R450    
 L  R451    
 L  R452    
 L  R453    
 L  R454    
 L  R455    
 L  R456    
 L  R457    
 L  R458    
 L  R459    
 L  R460    
 L  R461    
 L  R462    
 L  R463    
 L  R464    
 L  R465    
 L  R466    
 L  R467    
 L  R468    
 L  R469    
 L  R470    
 L  R471    
 L  R472    
 L  R473    
 L  R474    
 L  R475    
 L  R476    
 L  R477    
 L  R478    
 L  R479    
 L  R480    
 L  R481    
 L  R482    
 L  R483    
 L  R484    
 L  R485    
 L  R486    
 L  R487    
 L  R488    
 L  R489    
 L  R490    
 L  R491    
 L  R492    
 L  R493    
 L  R494    
 L  R495    
 L  R496    
 L  R497    
 L  R498    
 L  R499    
 L  R500    
 L  R501    
 L  R502    
 L  R503    
 L  R504    
 L  R505    
 L  R506    
 L  R507    
 L  R508    
 L  R509    
 L  R510    
 L  R511    
 L  R512    
 L  R513    
 L  R514    
 L  R515    
 L  R516    
 L  R517    
 L  R518    
 L  R519    
 L  R520    
 L  R521    
 L  R522    
 L  R523    
 L  R524    
 L  R525    
 L  R526    
 L  R527    
 L  R528    
 L  R529    
 L  R530    
 L  R531    
 L  R532    
 L  R533    
 L  R534    
 L  R535    
 L  R536    
 L  R537    
 L  R538    
 L  R539    
 L  R540    
 L  R541    
 L  R542    
 L  R543    
 L  R544    
 L  R545    
 L  R546    
 L  R547    
 L  R548    
 L  R549    
 L  R550    
 L  R551    
 L  R552    
 L  R553    
 L  R554    
 L  R555    
 L  R556    
 L  R557    
 L  R558    
 L  R559    
 L  R560    
 L  R561    
 L  R562    
 L  R563    
 L  R564    
 L  R565    
 L  R566    
 L  R567    
 L  R568    
 L  R569    
 L  R570    
 L  R571    
 L  R572    
 L  R573    
 L  R574    
 L  R575    
 L  R576    
 L  R577    
 L  R578    
 L  R579    
 L  R580    
 L  R581    
 L  R582    
 L  R583    
 L  R584    
 L  R585    
 L  R586    
 L  R587    
 L  R588    
 L  R589    
 L  R590    
 L  R591    
 L  R592    
 L  R593    
 L  R594    
 L  R595    
 L  R596    
 L  R597    
 L  R598    
 L  R599    
 L  R600    
 L  R601    
 L  R602    
 L  R603    
 L  R604    
 L  R605    
 L  R606    
 L  R607    
 L  R608    
 L  R609    
 L  R610    
 L  R611    
 L  R612    
 L  R613    
 L  R614    
 L  R615    
 L  R616    
 L  R617    
 L  R618    
 L  R619    
 L  R620    
 L  R621    
 L  R622    
 L  R623    
 L  R624    
 L  R625    
 L  R626    
 L  R627    
 L  R628    
 L  R629    
 L  R630    
 L  R631    
 L  R632    
 L  R633    
 L  R634    
 L  R635    
 L  R636    
 L  R637    
 L  R638    
 L  R639    
 L  R640    
 L  R641    
 L  R642    
 L  R643    
 L  R644    
 L  R645    
 L  R646    
 L  R647    
 L  R648    
 L  R649    
 L  R650    
 L  R651    
 L  R652    
 L  R653    
 L  R654    
 L  R655    
 L  R656    
 L  R657    
 L  R658    
 L  R659    
 L  R660    
 L  R661    
 L  R662    
 L  R663    
 L  R664    
 L  R665    
 L  R666    
 L  R667    
 L  R668    
 L  R669    
 L  R670    
 L  R671    
 L  R672    
 L  R673    
 L  R674    
 L  R675    
 L  R676    
 L  R677    
 L  R678    
 L  R679    
 L  R680    
 L  R681    
 L  R682    
 L  R683    
 L  R684    
 L  R685    
 L  R686    
 L  R687    
 L  R688    
 L  R689    
 L  R690    
 L  R691    
 L  R692    
 L  R693    
 L  R694    
 L  R695    
 L  R696    
 L  R697    
 L  R698    
 L  R699    
 L  R700    
 L  R701    
 L  R702    
 L  R703    
 L  R704    
 L  R705    
 L  R706    
 L  R707    
 L  R708    
 L  R709    
 L  R710    
 L  R711    
 L  R712    
 L  R713    
 L  R714    
 L  R715    
 L  R716    
 L  R717    
 L  R718    
 L  R719    
 L  R720    
 L  R721    
 L  R722    
 L  R723    
 L  R724    
 L  R725    
 L  R726    
 L  R727    
 L  R728    
 L  R729    
 L  R730    
 L  R731    
 L  R732    
 L  R733    
 L  R734    
 L  R735    
 L  R736    
 L  R737    
 L  R738    
 L  R739    
 L  R740    
 L  R741    
 L  R742    
 L  R743    
 L  R744    
 L  R745    
 L  R746    
 L  R747    
 L  R748    
 L  R749    
 L  R750    
 L  R751    
 L  R752    
 L  R753    
 L  R754    
 L  R755    
 L  R756    
 L  R757    
 L  R758    
 L  R759    
 L  R760    
 L  R761    
 L  R762    
 L  R763    
 L  R764    
 L  R765    
 L  R766    
 L  R767    
 L  R768    
 L  R769    
 L  R770    
 L  R771    
 L  R772    
 L  R773    
 L  R774    
 L  R775    
 L  R776    
 L  R777    
 L  R778    
 L  R779    
 L  R780    
 L  R781    
 L  R782    
 L  R783    
 L  R784    
 L  R785    
 L  R786    
 L  R787    
 L  R788    
 L  R789    
 L  R790    
 L  R791    
 L  R792    
 L  R793    
 L  R794    
 L  R795    
 L  R796    
 L  R797    
 L  R798    
 L  R799    
 L  R800    
 L  R801    
 L  R802    
 L  R803    
 L  R804    
 L  R805    
 L  R806    
 L  R807    
 L  R808    
 L  R809    
 L  R810    
 L  R811    
 L  R812    
 L  R813    
 L  R814    
 L  R815    
 L  R816    
 L  R817    
 L  R818    
 L  R819    
 L  R820    
 L  R821    
 L  R822    
 L  R823    
 L  R824    
 L  R825    
 L  R826    
 L  R827    
 L  R828    
 L  R829    
 L  R830    
 L  R831    
 L  R832    
 L  R833    
 L  R834    
 L  R835    
 L  R836    
 L  R837    
 L  R838    
 L  R839    
 L  R840    
 L  R841    
 L  R842    
 L  R843    
 L  R844    
 L  R845    
 L  R846    
 L  R847    
 L  R848    
 L  R849    
 L  R850    
 L  R851    
 L  R852    
 L  R853    
 L  R854    
 L  R855    
 L  R856    
 L  R857    
 L  R858    
 L  R859    
 L  R860    
 L  R861    
 L  R862    
 L  R863    
 L  R864    
 L  R865    
 L  R866    
 L  R867    
 L  R868    
 L  R869    
 L  R870    
 L  R871    
 L  R872    
 L  R873    
 L  R874    
 L  R875    
 L  R876    
 L  R877    
 L  R878    
 L  R879    
 L  R880    
 L  R881    
 L  R882    
 L  R883    
 L  R884    
 L  R885    
 L  R886    
 L  R887    
 L  R888    
 L  R889    
 L  R890    
 L  R891    
 L  R892    
 L  R893    
 L  R894    
 L  R895    
 L  R896    
 L  R897    
 L  R898    
 L  R899    
 L  R900    
 L  R901    
 L  R902    
 L  R903    
 L  R904    
 L  R905    
 L  R906    
 L  R907    
 L  R908    
 L  R909    
 L  R910    
 L  R911    
 L  R912    
 L  R913    
 L  R914    
 L  R915    
 L  R916    
 L  R917    
 L  R918    
 L  R919    
 L  R920    
 L  R921    
 L  R922    
 L  R923    
 L  R924    
 L  R925    
 L  R926    
 L  R927    
 L  R928    
 L  R929    
 L  R930    
 L  R931    
 L  R932    
 L  R933    
 L  R934    
 L  R935    
 L  R936    
 L  R937    
 L  R938    
 L  R939    
 L  R940    
 L  R941    
 L  R942    
 L  R943    
 L  R944    
 L  R945    
 L  R946    
 L  R947    
 L  R948    
 L  R949    
 L  R950    
 L  R951    
 L  R952    
 L  R953    
 L  R954    
 L  R955    
 L  R956    
 L  R957    
 L  R958    
 L  R959    
 L  R960    
 L  R961    
 L  R962    
 L  R963    
 L  R964    
 L  R965    
 L  R966    
 L  R967    
 L  R968    
 L  R969    
 L  R970    
 L  R971    
 L  R972    
 L  R973    
 L  R974    
 L  R975    
 L  R976    
 L  R977    
 L  R978    
 L  R979    
 L  R980    
 L  R981    
 L  R982    
 L  R983    
 L  R984    
 L  R985    
 L  R986    
 L  R987    
 L  R988    
 L  R989    
 L  R990    
 L  R991    
 L  R992    
 L  R993    
 L  R994    
 L  R995    
 L  R996    
 L  R997    
 L  R998    
 L  R999    
 L  R1000   
 L  R1001   
 L  R1002   
 L  R1003   
 L  R1004   
 L  R1005   
 L  R1006   
 L  R1007   
 L  R1008   
 L  R1009   
 L  R1010   
 L  R1011   
 L  R1012   
 L  R1013   
 L  R1014   
 L  R1015   
 L  R1016   
 L  R1017   
 L  R1018   
 L  R1019   
 L  R1020   
 L  R1021   
 L  R1022   
 L  R1023   
 L  R1024   
 L  R1025   
 L  R1026   
 L  R1027   
 L  R1028   
 L  R1029   
 L  R1030   
 L  R1031   
 L  R1032   
 L  R1033   
 L  R1034   
 L  R1035   
 L  R1036   
 L  R1037   
 L  R1038   
 L  R1039   
 L  R1040   
 L  R1041   
 L  R1042   
 L  R1043   
 L  R1044   
 L  R1045   
 L  R1046   
 L  R1047   
 L  R1048   
 L  R1049   
 L  R1050   
 L  R1051   
 L  R1052   
 L  R1053   
 L  R1054   
 L  R1055   
 L  R1056   
 L  R1057   
 L  R1058   
 L  R1059   
 L  R1060   
 L  R1061   
 L  R1062   
 L  R1063   
 L  R1064   
 L  R1065   
 L  R1066   
 L  R1067   
 L  R1068   
 L  R1069   
 L  R1070   
 L  R1071   
 L  R1072   
 L  R1073   
 L  R1074   
 L  R1075   
 L  R1076   
 L  R1077   
 L  R1078   
 L  R1079   
 L  R1080   
 L  R1081   
 L  R1082   
 L  R1083   
 L  R1084   
 L  R1085   
 L  R1086   
 L  R1087   
 L  R1088   
 L  R1089   
 L  R1090   
 L  R1091   
 L  R1092   
 L  R1093   
 L  R1094   
 L  R1095   
 L  R1096   
 L  R1097   
 L  R1098   
 L  R1099   
 L  R1100   
 L  R1101   
 L  R1102   
 L  R1103   
 L  R1104   
 L  R1105   
 L  R1106   
 L  R1107   
 L  R1108   
 L  R1109   
 L  R1110   
 L  R1111   
 L  R1112   
 L  R1113   
 L  R1114   
 L  R1115   
 L  R1116   
 L  R1117   
 L  R1118   
 L  R1119   
 L  R1120   
 L  R1121   
 L  R1122   
 L  R1123   
 L  R1124   
 L  R1125   
 L  R1126   
 L  R1127   
 L  R1128   
 L  R1129   
 L  R1130   
 L  R1131   
 L  R1132   
 L  R1133   
 L  R1134   
 L  R1135   
 L  R1136   
 L  R1137   
 L  R1138   
 L  R1139   
 L  R1140   
 L  R1141   
 L  R1142   
 L  R1143   
 L  R1144   
 L  R1145   
 L  R1146   
 L  R1147   
 L  R1148   
 L  R1149   
 L  R1150   
 L  R1151   
 L  R1152   
 L  R1153   
 L  R1154   
 L  R1155   
 L  R1156   
 L  R1157   
 L  R1158   
 L  R1159   
 L  R1160   
 L  R1161   
 L  R1162   
 L  R1163   
 L  R1164   
 L  R1165   
 L  R1166   
 L  R1167   
 L  R1168   
 L  R1169   
 L  R1170   
 L  R1171   
 L  R1172   
 L  R1173   
 L  R1174   
 L  R1175   
 L  R1176   
 L  R1177   
 L  R1178   
 L  R1179   
 L  R1180   
 L  R1181   
 L  R1182   
 L  R1183   
 L  R1184   
 L  R1185   
 L  R1186   
 L  R1187   
 L  R1188   
 L  R1189   
 L  R1190   
 L  R1191   
 L  R1192   
 L  R1193   
 L  R1194   
 L  R1195   
 L  R1196   
 L  R1197   
 L  R1198   
 L  R1199   
 L  R1200   
 L  R1201   
 L  R1202   
 L  R1203   
 L  R1204   
 L  R1205   
 L  R1206   
 L  R1207   
 L  R1208   
 L  R1209   
 L  R1210   
 L  R1211   
 L  R1212   
 L  R1213   
 L  R1214   
 L  R1215   
 L  R1216   
 L  R1217   
 L  R1218   
 L  R1219   
 L  R1220   
 L  R1221   
 L  R1222   
 L  R1223   
 L  R1224   
 L  R1225   
 L  R1226   
 L  R1227   
 L  R1228   
 L  R1229   
 L  R1230   
 L  R1231   
 L  R1232   
 L  R1233   
 L  R1234   
 L  R1235   
 L  R1236   
 L  R1237   
 L  R1238   
 L  R1239   
 L  R1240   
 L  R1241   
 L  R1242   
 L  R1243   
 L  R1244   
 L  R1245   
 L  R1246   
 L  R1247   
 L  R1248   
 L  R1249   
 L  R1250   
 L  R1251   
 L  R1252   
 L  R1253   
 L  R1254   
 L  R1255   
 L  R1256   
 L  R1257   
 L  R1258   
 L  R1259   
 L  R1260   
 L  R1261   
 L  R1262   
 L  R1263   
 L  R1264   
 L  R1265   
 L  R1266   
 L  R1267   
 L  R1268   
 L  R1269   
 L  R1270   
 L  R1271   
 L  R1272   
 L  R1273   
 L  R1274   
 L  R1275   
 L  R1276   
 L  R1277   
 L  R1278   
 L  R1279   
 L  R1280   
 L  R1281   
 L  R1282   
 L  R1283   
 L  R1284   
 L  R1285   
 L  R1286   
 L  R1287   
 L  R1288   
 L  R1289   
 L  R1290   
 L  R1291   
 L  R1292   
 L  R1293   
 L  R1294   
 L  R1295   
 L  R1296   
 L  R1297   
 L  R1298   
 L  R1299   
 L  R1300   
 L  R1301   
 L  R1302   
 L  R1303   
 L  R1304   
 L  R1305   
 L  R1306   
 L  R1307   
 L  R1308   
 L  R1309   
 L  R1310   
 L  R1311   
 L  R1312   
 L  R1313   
 L  R1314   
 L  R1315   
 L  R1316   
 L  R1317   
 L  R1318   
 L  R1319   
 L  R1320   
 L  R1321   
 L  R1322   
 L  R1323   
 L  R1324   
 L  R1325   
 L  R1326   
 L  R1327   
 L  R1328   
 L  R1329   
 L  R1330   
 L  R1331   
 L  R1332   
 L  R1333   
 L  R1334   
 L  R1335   
 L  R1336   
 L  R1337   
 L  R1338   
 L  R1339   
 L  R1340   
 L  R1341   
 L  R1342   
 L  R1343   
 L  R1344   
 L  R1345   
 L  R1346   
 L  R1347   
 L  R1348   
 L  R1349   
 L  R1350   
 L  R1351   
 L  R1352   
 L  R1353   
 L  R1354   
 L  R1355   
 L  R1356   
 L  R1357   
 L  R1358   
 L  R1359   
 L  R1360   
 L  R1361   
 L  R1362   
 L  R1363   
 L  R1364   
 L  R1365   
 L  R1366   
 L  R1367   
 L  R1368   
 L  R1369   
 L  R1370   
 L  R1371   
 L  R1372   
 L  R1373   
 L  R1374   
 L  R1375   
 L  R1376   
 L  R1377   
 L  R1378   
 L  R1379   
 L  R1380   
 L  R1381   
 L  R1382   
 L  R1383   
 L  R1384   
 L  R1385   
 L  R1386   
 L  R1387   
 L  R1388   
 L  R1389   
 L  R1390   
 L  R1391   
 L  R1392   
 L  R1393   
 L  R1394   
 L  R1395   
 L  R1396   
 L  R1397   
 L  R1398   
 L  R1399   
 L  R1400   
 L  R1401   
 L  R1402   
 L  R1403   
 L  R1404   
 L  R1405   
 L  R1406   
 L  R1407   
 L  R1408   
 L  R1409   
 L  R1410   
 L  R1411   
 L  R1412   
 L  R1413   
 L  R1414   
 L  R1415   
 L  R1416   
 L  R1417   
 L  R1418   
 L  R1419   
 L  R1420   
 L  R1421   
 L  R1422   
 L  R1423   
 L  R1424   
 L  R1425   
 L  R1426   
 L  R1427   
 L  R1428   
 L  R1429   
 L  R1430   
 L  R1431   
 L  R1432   
 L  R1433   
 L  R1434   
 L  R1435   
 L  R1436   
 L  R1437   
 L  R1438   
 L  R1439   
 L  R1440   
 L  R1441   
 L  R1442   
 L  R1443   
 L  R1444   
 L  R1445   
 L  R1446   
 L  R1447   
 L  R1448   
 L  R1449   
 L  R1450   
 L  R1451   
 L  R1452   
 L  R1453   
 L  R1454   
 L  R1455   
 L  R1456   
 L  R1457   
 L  R1458   
 L  R1459   
 L  R1460   
 L  R1461   
 L  R1462   
 L  R1463   
 L  R1464   
 L  R1465   
 L  R1466   
 L  R1467   
 L  R1468   
 L  R1469   
 L  R1470   
 L  R1471   
 L  R1472   
 L  R1473   
 L  R1474   
 L  R1475   
 L  R1476   
 L  R1477   
 L  R1478   
 L  R1479   
 L  R1480   
 L  R1481   
 L  R1482   
 L  R1483   
 L  R1484   
 L  R1485   
 L  R1486   
 L  R1487   
 L  R1488   
 L  R1489   
 L  R1490   
 L  R1491   
 L  R1492   
 L  R1493   
 L  R1494   
 L  R1495   
 L  R1496   
 L  R1497   
 L  R1498   
 L  R1499   
 L  R1500   
 L  R1501   
 L  R1502   
 L  R1503   
 L  R1504   
 L  R1505   
 L  R1506   
 L  R1507   
 L  R1508   
 L  R1509   
 L  R1510   
 L  R1511   
 L  R1512   
 L  R1513   
 L  R1514   
 L  R1515   
 L  R1516   
 L  R1517   
 L  R1518   
 L  R1519   
 L  R1520   
 L  R1521   
 L  R1522   
 L  R1523   
 L  R1524   
 L  R1525   
 L  R1526   
 L  R1527   
 L  R1528   
 L  R1529   
 L  R1530   
 L  R1531   
 L  R1532   
 L  R1533   
 L  R1534   
 L  R1535   
 L  R1536   
 L  R1537   
 L  R1538   
 L  R1539   
 L  R1540   
 L  R1541   
 L  R1542   
 L  R1543   
 L  R1544   
 L  R1545   
 L  R1546   
 L  R1547   
 L  R1548   
 L  R1549   
 L  R1550   
 L  R1551   
 L  R1552   
 L  R1553   
 L  R1554   
 L  R1555   
 L  R1556   
 L  R1557   
 L  R1558   
 L  R1559   
 L  R1560   
 L  R1561   
 L  R1562   
 L  R1563   
 L  R1564   
 L  R1565   
 L  R1566   
 L  R1567   
 L  R1568   
 L  R1569   
 L  R1570   
 L  R1571   
 L  R1572   
 L  R1573   
 L  R1574   
 L  R1575   
 L  R1576   
 L  R1577   
 L  R1578   
 L  R1579   
 L  R1580   
 L  R1581   
 L  R1582   
 L  R1583   
 L  R1584   
 L  R1585   
 L  R1586   
 L  R1587   
 L  R1588   
 L  R1589   
 L  R1590   
 L  R1591   
 L  R1592   
 L  R1593   
 L  R1594   
 L  R1595   
 L  R1596   
 L  R1597   
 L  R1598   
 L  R1599   
 L  R1600   
 L  R1601   
 L  R1602   
 L  R1603   
 L  R1604   
 L  R1605   
 L  R1606   
 L  R1607   
 L  R1608   
 L  R1609   
 L  R1610   
 L  R1611   
 L  R1612   
 L  R1613   
 L  R1614   
 L  R1615   
 L  R1616   
 L  R1617   
 L  R1618   
 L  R1619   
 L  R1620   
 L  R1621   
 L  R1622   
 L  R1623   
 L  R1624   
 L  R1625   
 L  R1626   
 L  R1627   
 L  R1628   
 L  R1629   
 L  R1630   
 L  R1631   
 L  R1632   
 L  R1633   
 L  R1634   
 L  R1635   
 L  R1636   
 L  R1637   
 L  R1638   
 L  R1639   
 L  R1640   
 L  R1641   
 L  R1642   
 L  R1643   
 L  R1644   
 L  R1645   
 L  R1646   
 L  R1647   
 L  R1648   
 L  R1649   
 L  R1650   
 L  R1651   
 L  R1652   
 L  R1653   
 L  R1654   
 L  R1655   
 L  R1656   
 L  R1657   
 L  R1658   
 L  R1659   
 L  R1660   
 L  R1661   
 L  R1662   
 L  R1663   
 L  R1664   
 L  R1665   
 L  R1666   
 L  R1667   
 L  R1668   
 L  R1669   
 L  R1670   
 L  R1671   
 L  R1672   
 L  R1673   
 L  R1674   
 L  R1675   
 L  R1676   
 L  R1677   
 L  R1678   
 L  R1679   
 L  R1680   
 L  R1681   
 L  R1682   
 L  R1683   
 L  R1684   
 L  R1685   
 L  R1686   
 L  R1687   
 L  R1688   
 L  R1689   
 L  R1690   
 L  R1691   
 L  R1692   
 L  R1693   
 L  R1694   
 L  R1695   
 L  R1696   
 L  R1697   
 L  R1698   
 L  R1699   
 L  R1700   
 L  R1701   
 L  R1702   
 L  R1703   
 L  R1704   
 L  R1705   
 L  R1706   
 L  R1707   
 L  R1708   
 L  R1709   
 L  R1710   
 L  R1711   
 L  R1712   
 L  R1713   
 L  R1714   
 L  R1715   
 L  R1716   
 L  R1717   
 L  R1718   
 L  R1719   
 L  R1720   
 L  R1721   
 L  R1722   
 L  R1723   
 L  R1724   
 L  R1725   
 L  R1726   
 L  R1727   
 L  R1728   
 L  R1729   
 L  R1730   
 L  R1731   
 L  R1732   
 L  R1733   
 L  R1734   
 L  R1735   
 L  R1736   
 L  R1737   
 L  R1738   
 L  R1739   
 L  R1740   
 L  R1741   
 L  R1742   
 L  R1743   
 L  R1744   
 L  R1745   
 L  R1746   
 L  R1747   
 L  R1748   
 L  R1749   
 L  R1750   
 L  R1751   
 L  R1752   
 L  R1753   
 L  R1754   
 L  R1755   
 L  R1756   
 L  R1757   
 L  R1758   
 L  R1759   
 L  R1760   
 L  R1761   
 L  R1762   
 L  R1763   
 L  R1764   
 L  R1765   
 L  R1766   
 L  R1767   
 L  R1768   
 L  R1769   
 L  R1770   
 L  R1771   
 L  R1772   
 L  R1773   
 L  R1774   
 L  R1775   
 L  R1776   
 L  R1777   
 L  R1778   
 L  R1779   
 L  R1780   
 L  R1781   
 L  R1782   
 L  R1783   
 L  R1784   
 L  R1785   
 L  R1786   
 L  R1787   
 L  R1788   
 L  R1789   
 L  R1790   
 L  R1791   
 L  R1792   
 L  R1793   
 L  R1794   
 L  R1795   
 L  R1796   
 L  R1797   
 L  R1798   
 L  R1799   
 L  R1800   
 L  R1801   
 L  R1802   
 L  R1803   
 L  R1804   
 L  R1805   
 L  R1806   
 L  R1807   
 L  R1808   
 L  R1809   
 L  R1810   
 L  R1811   
 L  R1812   
 L  R1813   
 L  R1814   
 L  R1815   
 L  R1816   
 L  R1817   
 L  R1818   
 L  R1819   
 L  R1820   
 L  R1821   
 L  R1822   
 L  R1823   
 L  R1824   
 L  R1825   
 L  R1826   
 L  R1827   
 L  R1828   
 L  R1829   
 L  R1830   
 L  R1831   
 L  R1832   
 L  R1833   
 L  R1834   
 L  R1835   
 L  R1836   
 L  R1837   
 L  R1838   
 L  R1839   
 L  R1840   
 L  R1841   
 L  R1842   
 L  R1843   
 L  R1844   
 L  R1845   
 L  R1846   
 L  R1847   
 L  R1848   
 L  R1849   
 L  R1850   
 L  R1851   
 L  R1852   
 L  R1853   
 L  R1854   
 L  R1855   
 L  R1856   
 L  R1857   
 L  R1858   
 L  R1859   
 L  R1860   
 L  R1861   
 L  R1862   
 L  R1863   
 L  R1864   
 L  R1865   
 L  R1866   
 L  R1867   
 L  R1868   
 L  R1869   
 L  R1870   
 L  R1871   
 L  R1872   
 L  R1873   
 L  R1874   
 L  R1875   
 L  R1876   
 L  R1877   
 L  R1878   
 L  R1879   
 L  R1880   
 L  R1881   
 L  R1882   
 L  R1883   
 L  R1884   
 L  R1885   
 L  R1886   
 L  R1887   
 L  R1888   
 L  R1889   
 L  R1890   
 L  R1891   
 L  R1892   
 L  R1893   
 L  R1894   
 L  R1895   
 L  R1896   
 L  R1897   
 L  R1898   
 L  R1899   
 L  R1900   
 L  R1901   
 L  R1902   
 L  R1903   
 L  R1904   
 L  R1905   
 L  R1906   
 L  R1907   
 L  R1908   
 L  R1909   
 L  R1910   
 L  R1911   
 L  R1912   
 L  R1913   
 L  R1914   
 L  R1915   
 L  R1916   
 L  R1917   
 L  R1918   
 L  R1919   
 L  R1920   
 L  R1921   
 L  R1922   
 L  R1923   
 L  R1924   
 L  R1925   
 L  R1926   
 L  R1927   
 L  R1928   
 L  R1929   
 L  R1930   
 L  R1931   
 L  R1932   
 L  R1933   
 L  R1934   
 L  R1935   
 L  R1936   
 L  R1937   
 L  R1938   
 L  R1939   
 L  R1940   
 L  R1941   
 L  R1942   
 L  R1943   
 L  R1944   
 L  R1945   
 L  R1946   
 L  R1947   
 L  R1948   
 L  R1949   
 L  R1950   
 L  R1951   
 L  R1952   
 L  R1953   
 L  R1954   
 L  R1955   
 L  R1956   
 L  R1957   
 L  R1958   
 L  R1959   
 L  R1960   
 L  R1961   
 L  R1962   
 L  R1963   
 L  R1964   
 L  R1965   
 L  R1966   
 L  R1967   
 L  R1968   
 L  R1969   
 L  R1970   
 L  R1971   
 L  R1972   
 L  R1973   
 L  R1974   
 L  R1975   
 L  R1976   
 L  R1977   
 L  R1978   
 L  R1979   
 L  R1980   
 L  R1981   
 L  R1982   
 L  R1983   
 L  R1984   
 L  R1985   
 L  R1986   
 L  R1987   
 L  R1988   
 L  R1989   
 L  R1990   
 L  R1991   
 L  R1992   
 L  R1993   
 L  R1994   
 L  R1995   
 L  R1996   
 L  R1997   
 L  R1998   
 L  R1999   
 L  R2000   
 L  R2001   
 L  R2002   
 L  R2003   
 L  R2004   
 L  R2005   
 L  R2006   
 L  R2007   
 L  R2008   
 L  R2009   
 L  R2010   
 L  R2011   
 L  R2012   
 L  R2013   
 L  R2014   
 L  R2015   
 L  R2016   
 L  R2017   
 L  R2018   
 L  R2019   
 L  R2020   
 L  R2021   
 L  R2022   
 L  R2023   
 L  R2024   
 L  R2025   
 L  R2026   
 L  R2027   
 L  R2028   
 L  R2029   
 L  R2030   
 L  R2031   
 L  R2032   
 L  R2033   
 L  R2034   
 L  R2035   
 L  R2036   
 L  R2037   
 L  R2038   
 L  R2039   
 L  R2040   
 L  R2041   
 L  R2042   
 L  R2043   
 L  R2044   
 L  R2045   
 L  R2046   
 L  R2047   
 L  R2048   
 L  R2049   
 L  R2050   
 L  R2051   
 L  R2052   
 L  R2053   
 L  R2054   
 L  R2055   
 L  R2056   
 L  R2057   
 L  R2058   
 L  R2059   
 L  R2060   
 L  R2061   
 L  R2062   
 L  R2063   
 L  R2064   
 L  R2065   
 L  R2066   
 L  R2067   
 L  R2068   
 L  R2069   
 L  R2070   
 L  R2071   
 L  R2072   
 L  R2073   
 L  R2074   
 L  R2075   
 L  R2076   
 L  R2077   
 L  R2078   
 L  R2079   
 L  R2080   
 L  R2081   
 L  R2082   
 L  R2083   
 L  R2084   
 L  R2085   
 L  R2086   
 L  R2087   
 L  R2088   
 L  R2089   
 L  R2090   
 L  R2091   
 L  R2092   
 L  R2093   
 L  R2094   
 L  R2095   
 L  R2096   
 L  R2097   
 L  R2098   
 L  R2099   
 L  R2100   
 L  R2101   
 L  R2102   
 L  R2103   
 L  R2104   
 L  R2105   
 L  R2106   
 L  R2107   
 L  R2108   
 L  R2109   
 L  R2110   
 L  R2111   
 L  R2112   
 L  R2113   
 L  R2114   
 L  R2115   
 L  R2116   
 L  R2117   
 L  R2118   
 L  R2119   
 L  R2120   
 L  R2121   
 L  R2122   
 L  R2123   
 L  R2124   
 L  R2125   
 L  R2126   
 L  R2127   
 L  R2128   
 L  R2129   
 L  R2130   
 L  R2131   
 L  R2132   
 L  R2133   
 L  R2134   
 L  R2135   
 L  R2136   
 L  R2137   
 L  R2138   
 L  R2139   
 L  R2140   
 L  R2141   
 L  R2142   
 L  R2143   
 L  R2144   
 L  R2145   
 L  R2146   
 L  R2147   
 L  R2148   
 L  R2149   
 L  R2150   
 L  R2151   
 L  R2152   
 L  R2153   
 L  R2154   
 L  R2155   
 L  R2156   
 L  R2157   
 L  R2158   
 L  R2159   
 L  R2160   
 L  R2161   
 L  R2162   
 L  R2163   
 L  R2164   
 L  R2165   
 L  R2166   
 L  R2167   
 L  R2168   
 L  R2169   
 L  R2170   
 L  R2171   
 L  R2172   
 L  R2173   
 L  R2174   
 L  R2175   
 L  R2176   
 L  R2177   
 L  R2178   
 L  R2179   
 L  R2180   
 L  R2181   
 L  R2182   
 L  R2183   
 L  R2184   
 L  R2185   
 L  R2186   
 L  R2187   
 L  R2188   
 L  R2189   
 L  R2190   
 L  R2191   
 L  R2192   
 L  R2193   
 L  R2194   
 L  R2195   
 L  R2196   
 L  R2197   
 L  R2198   
 L  R2199   
 L  R2200   
 L  R2201   
 L  R2202   
 L  R2203   
 L  R2204   
 L  R2205   
 L  R2206   
 L  R2207   
 L  R2208   
 L  R2209   
 L  R2210   
 L  R2211   
 L  R2212   
 L  R2213   
 L  R2214   
 L  R2215   
 L  R2216   
 L  R2217   
 L  R2218   
 L  R2219   
 L  R2220   
 L  R2221   
 L  R2222   
 L  R2223   
 L  R2224   
 L  R2225   
 L  R2226   
 L  R2227   
 L  R2228   
 L  R2229   
 L  R2230   
 L  R2231   
 L  R2232   
 L  R2233   
 L  R2234   
 L  R2235   
 L  R2236   
 L  R2237   
 L  R2238   
 L  R2239   
 L  R2240   
 L  R2241   
 L  R2242   
 L  R2243   
 L  R2244   
 L  R2245   
 L  R2246   
 L  R2247   
 L  R2248   
 L  R2249   
 L  R2250   
 L  R2251   
 L  R2252   
 L  R2253   
 L  R2254   
 L  R2255   
 L  R2256   
 L  R2257   
 L  R2258   
 L  R2259   
 L  R2260   
 L  R2261   
 L  R2262   
 L  R2263   
 L  R2264   
 L  R2265   
 L  R2266   
 L  R2267   
 L  R2268   
 L  R2269   
 L  R2270   
 L  R2271   
 L  R2272   
 L  R2273   
 L  R2274   
 L  R2275   
 L  R2276   
 L  R2277   
 L  R2278   
 L  R2279   
 L  R2280   
 L  R2281   
 L  R2282   
 L  R2283   
 L  R2284   
 L  R2285   
 L  R2286   
 L  R2287   
 L  R2288   
 L  R2289   
 L  R2290   
 L  R2291   
 L  R2292   
 L  R2293   
 L  R2294   
 L  R2295   
 L  R2296   
 L  R2297   
 L  R2298   
 L  R2299   
 L  R2300   
 L  R2301   
 L  R2302   
 L  R2303   
 L  R2304   
 L  R2305   
 L  R2306   
 L  R2307   
 L  R2308   
 L  R2309   
 L  R2310   
 L  R2311   
 L  R2312   
 L  R2313   
 L  R2314   
 L  R2315   
 L  R2316   
 L  R2317   
 L  R2318   
 L  R2319   
 L  R2320   
 L  R2321   
 L  R2322   
 L  R2323   
 L  R2324   
 L  R2325   
 L  R2326   
 L  R2327   
 L  R2328   
 L  R2329   
 L  R2330   
 L  R2331   
 L  R2332   
 L  R2333   
 L  R2334   
 L  R2335   
 L  R2336   
 L  R2337   
 L  R2338   
 L  R2339   
 L  R2340   
 L  R2341   
 L  R2342   
 L  R2343   
 L  R2344   
 L  R2345   
 L  R2346   
 L  R2347   
 L  R2348   
 L  R2349   
 L  R2350   
 L  R2351   
 L  R2352   
 L  R2353   
 L  R2354   
 L  R2355   
 L  R2356   
 L  R2357   
 L  R2358   
 L  R2359   
 L  R2360   
 L  R2361   
 L  R2362   
 L  R2363   
 L  R2364   
 L  R2365   
 L  R2366   
 L  R2367   
 L  R2368   
 L  R2369   
 L  R2370   
 L  R2371   
 L  R2372   
 L  R2373   
 L  R2374   
 L  R2375   
 L  R2376   
 L  R2377   
 L  R2378   
 L  R2379   
 L  R2380   
 L  R2381   
 L  R2382   
 L  R2383   
 L  R2384   
 L  R2385   
 L  R2386   
 L  R2387   
 L  R2388   
 L  R2389   
 L  R2390   
 L  R2391   
 L  R2392   
 L  R2393   
 L  R2394   
 L  R2395   
 L  R2396   
 L  R2397   
 L  R2398   
 L  R2399   
 L  R2400   
 L  R2401   
 L  R2402   
 L  R2403   
 L  R2404   
 L  R2405   
 L  R2406   
 L  R2407   
 L  R2408   
 L  R2409   
 L  R2410   
 L  R2411   
 L  R2412   
 L  R2413   
 L  R2414   
 L  R2415   
 L  R2416   
 L  R2417   
 L  R2418   
 L  R2419   
 L  R2420   
 L  R2421   
 L  R2422   
 L  R2423   
 L  R2424   
 L  R2425   
 L  R2426   
 L  R2427   
 L  R2428   
 L  R2429   
 L  R2430   
 L  R2431   
 L  R2432   
 L  R2433   
 L  R2434   
 L  R2435   
 L  R2436   
 L  R2437   
 L  R2438   
 L  R2439   
 L  R2440   
 L  R2441   
 L  R2442   
 L  R2443   
 L  R2444   
 L  R2445   
 L  R2446   
 L  R2447   
 L  R2448   
 L  R2449   
 L  R2450   
 L  R2451   
 L  R2452   
 L  R2453   
 L  R2454   
 L  R2455   
 L  R2456   
 L  R2457   
 L  R2458   
 L  R2459   
 L  R2460   
 L  R2461   
 L  R2462   
 L  R2463   
 L  R2464   
 L  R2465   
 L  R2466   
 L  R2467   
 L  R2468   
 L  R2469   
 L  R2470   
 L  R2471   
 L  R2472   
 L  R2473   
 L  R2474   
 L  R2475   
 L  R2476   
 L  R2477   
 L  R2478   
 L  R2479   
 L  R2480   
 L  R2481   
 L  R2482   
 L  R2483   
 L  R2484   
 L  R2485   
 L  R2486   
 L  R2487   
 L  R2488   
 L  R2489   
 L  R2490   
 L  R2491   
 L  R2492   
 L  R2493   
 L  R2494   
 L  R2495   
 L  R2496   
 L  R2497   
 L  R2498   
 L  R2499   
 L  R2500   
 L  R2501   
 L  R2502   
 L  R2503   
 L  R2504   
 L  R2505   
 L  R2506   
 L  R2507   
 L  R2508   
 L  R2509   
 L  qc0     
 L  qc1     
 L  qc2     
 L  qc3     
 L  qc4     
 L  qc5     
 L  qc6     
 L  qc7     
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    phi[0,1]  R0        1
    phi[0,1]  R1        1
    phi[0,1]  R9        -1
    phi[0,1]  R74       -3.0999999046325684e+00
    phi[0,1]  R75       -3.0999999046325684e+00
    phi[0,1]  R76       -2.2400000095367432e+00
    phi[0,1]  R77       -2.2400000095367432e+00
    phi[0,1]  R78       -3.0999999046325684e+00
    phi[0,1]  R79       -3.0999999046325684e+00
    phi[0,1]  R80       -2.5699999332427979e+00
    phi[0,1]  R81       -2.5699999332427979e+00
    phi[0,1]  R82       -3.0999999046325684e+00
    phi[0,1]  R83       -3.0999999046325684e+00
    phi[0,1]  R84       -2.0899999141693115e+00
    phi[0,1]  R85       -2.0899999141693115e+00
    phi[0,1]  R86       -3.0999999046325684e+00
    phi[0,1]  R87       -3.0999999046325684e+00
    phi[0,1]  R88       1.5871444940567017e+00
    phi[0,1]  R89       3.1327443122863770e+00
    phi[0,1]  R90       1.5062488317489624e+00
    phi[0,1]  R91       -1.5537766218185425e+00
    phi[0,1]  R92       1.0565611720085144e-01
    phi[0,1]  R93       -9.8675107955932617e-01
    phi[0,1]  R94       -6.2375295162200928e-01
    phi[0,1]  R95       -2.0804860591888428e+00
    phi[0,1]  R96       -1.6238176822662354e+00
    phi[0,1]  R97       -2.1933937072753906e+00
    phi[0,1]  R98       -2.3932843208312988e+00
    phi[0,1]  R99       -2.6565697193145752e+00
    phi[0,1]  R100      -1.2945883274078369e+00
    phi[0,1]  R101      -2.7847125530242920e+00
    phi[0,1]  R102      -3.1523334980010986e+00
    phi[0,1]  R103      -3.1884582042694092e+00
    phi[0,1]  R104      -2.5406651496887207e+00
    phi[0,1]  R105      -3.48580002784729
    phi[0,1]  R106      -4.4214873313903809e+00
    phi[0,1]  R107      -3.1795775890350342e+00
    phi[0,1]  R108      -2.6049892902374268e+00
    phi[0,1]  R109      -3.5210156440734863e+00
    phi[0,1]  R110      -1.4340366125106812e+00
    phi[0,1]  R111      -2.6746599674224854e+00
    phi[0,1]  R112      -1.1563403606414795e+00
    phi[0,1]  R113      -2.3634719848632812e+00
    phi[0,1]  R114      -1.7773422002792358e+00
    phi[0,1]  R115      -2.6609058380126953e+00
    phi[0,1]  R116      4.6668320894241333e-02
    phi[0,1]  R117      1.2699224948883057e+00
    phi[0,1]  R118      9.6895498037338257e-01
    phi[0,1]  R119      -2.0685620307922363e+00
    phi[0,1]  R120      5.1294195652008057e-01
    phi[0,1]  R121      -2.9464921951293945e+00
    phi[0,1]  R122      -9.2210000753402710e-01
    phi[0,1]  R123      -2.7731106281280518e+00
    phi[0,1]  R124      -3.6497633457183838e+00
    phi[0,1]  R125      -1.2681646347045898e+00
    phi[0,1]  R126      -2.0597469806671143e+00
    phi[0,1]  R127      1.2252575717866421e-02
    phi[0,1]  R128      -1.1620271950960159e-01
    phi[0,1]  R129      -1.3900592327117920e+00
    phi[0,1]  R130      -3.8215339183807373e+00
    phi[0,1]  R131      -2.7651870250701904e+00
    phi[0,1]  R132      -3.6894650459289551e+00
    phi[0,1]  R133      -4.0300340652465820e+00
    phi[0,1]  R134      -3.8696577548980713e+00
    phi[0,1]  R135      -3.2762682437896729e+00
    phi[0,1]  R136      -3.5559861660003662e+00
    phi[0,1]  R137      -1.1963206529617310e+00
    phi[0,1]  R138      -4.8483544588088989e-01
    phi[0,1]  R139      -1.6218549013137817e+00
    phi[0,1]  R140      -3.0645966529846191e+00
    phi[0,1]  R141      -2.1467866897583008e+00
    phi[0,1]  R142      -3.1298046112060547e+00
    phi[0,1]  R143      -2.8157329559326172e-01
    phi[0,1]  R144      -2.9254474639892578e+00
    phi[0,1]  R145      -1.3992965221405029e+00
    phi[0,1]  R146      -1.5387237071990967e-01
    phi[0,1]  R147      -1.9184720516204834e-01
    phi[0,1]  R148      1.0953590869903564e+00
    phi[0,1]  R149      1.0949059724807739e+00
    phi[0,1]  R150      3.2336792349815369e-01
    phi[0,1]  R151      2.4676816165447235e-01
    phi[0,1]  R152      -1.0653502941131592e+00
    phi[0,1]  R153      -2.0282294750213623e+00
    phi[0,1]  R154      1.0122755765914917e+00
    phi[0,1]  R155      -3.8481515645980835e-01
    phi[0,1]  R156      -1.1844459772109985e+00
    phi[0,1]  R157      -1.2625811100006104e+00
    phi[0,1]  R158      -2.0794820785522461e+00
    phi[0,1]  R159      -1.9246559143066406e+00
    phi[0,1]  R160      -8.9861404895782471e-01
    phi[0,1]  R161      -2.23384428024292
    phi[0,1]  R162      -9.3556308746337891e-01
    phi[0,1]  R163      1.1689919233322144e+00
    phi[0,1]  R164      -2.8804833889007568e+00
    phi[0,1]  R165      -1.6614713668823242e+00
    phi[0,1]  R166      5.5326007306575775e-02
    phi[0,1]  R167      -1.3306286334991455e+00
    phi[0,1]  R168      -1.0094625949859619e+00
    phi[0,1]  R169      -2.5318114757537842e+00
    phi[0,1]  R170      1.4510639905929565e+00
    phi[0,1]  R171      -3.0313420295715332e+00
    phi[0,1]  R172      -1.8906174898147583e+00
    phi[0,1]  R173      -2.6267926692962646e+00
    phi[0,1]  R174      -3.4027280807495117e+00
    phi[0,1]  R175      -9.0056687593460083e-02
    phi[0,1]  R176      -1.1165565252304077e+00
    phi[0,1]  R177      -9.5106318593025208e-02
    phi[0,1]  R178      5.5066192150115967e-01
    phi[0,1]  R179      4.1080260276794434e-01
    phi[0,1]  R180      1.3418530225753784e+00
    phi[0,1]  R181      -2.7474288940429688e+00
    phi[0,1]  R182      -2.0025949925184250e-04
    phi[0,1]  R183      -1.4305970668792725e+00
    phi[0,1]  R184      5.5264055728912354e-01
    phi[0,1]  R185      -6.8360972404479980e-01
    phi[0,1]  R186      -1.0948202610015869e+00
    phi[0,1]  R187      -1.3564723730087280e+00
    phi[1,0]  R0        -1
    phi[1,0]  R9        1
    phi[1,0]  R10       1
    phi[1,0]  R188      -3.0999999046325684e+00
    phi[1,0]  R189      -3.0999999046325684e+00
    phi[1,0]  R190      -2.2400000095367432e+00
    phi[1,0]  R191      -2.2400000095367432e+00
    phi[1,0]  R192      -3.0999999046325684e+00
    phi[1,0]  R193      -3.0999999046325684e+00
    phi[1,0]  R194      -2.5699999332427979e+00
    phi[1,0]  R195      -2.5699999332427979e+00
    phi[1,0]  R196      -3.0999999046325684e+00
    phi[1,0]  R197      -3.0999999046325684e+00
    phi[1,0]  R198      -2.0899999141693115e+00
    phi[1,0]  R199      -2.0899999141693115e+00
    phi[1,0]  R200      -3.0999999046325684e+00
    phi[1,0]  R201      -3.0999999046325684e+00
    phi[1,0]  R202      1.0953590869903564e+00
    phi[1,0]  R203      1.0949059724807739e+00
    phi[1,0]  R204      3.2336792349815369e-01
    phi[1,0]  R205      2.4676816165447235e-01
    phi[1,0]  R206      -1.0653502941131592e+00
    phi[1,0]  R207      -2.0282294750213623e+00
    phi[1,0]  R208      1.0122755765914917e+00
    phi[1,0]  R209      -3.8481515645980835e-01
    phi[1,0]  R210      -1.1844459772109985e+00
    phi[1,0]  R211      -1.2625811100006104e+00
    phi[1,0]  R212      -2.0794820785522461e+00
    phi[1,0]  R213      -1.9246559143066406e+00
    phi[1,0]  R214      -8.9861404895782471e-01
    phi[1,0]  R215      -2.23384428024292
    phi[1,0]  R216      -9.3556308746337891e-01
    phi[1,0]  R217      1.1689919233322144e+00
    phi[1,0]  R218      -2.8804833889007568e+00
    phi[1,0]  R219      -1.6614713668823242e+00
    phi[1,0]  R220      5.5326007306575775e-02
    phi[1,0]  R221      -1.3306286334991455e+00
    phi[1,0]  R222      -1.0094625949859619e+00
    phi[1,0]  R223      -2.5318114757537842e+00
    phi[1,0]  R224      1.4510639905929565e+00
    phi[1,0]  R225      -3.0313420295715332e+00
    phi[1,0]  R226      -1.8906174898147583e+00
    phi[1,0]  R227      -2.6267926692962646e+00
    phi[1,0]  R228      -3.4027280807495117e+00
    phi[1,0]  R229      -9.0056687593460083e-02
    phi[1,0]  R230      -1.1165565252304077e+00
    phi[1,0]  R231      -9.5106318593025208e-02
    phi[1,0]  R232      5.5066192150115967e-01
    phi[1,0]  R233      4.1080260276794434e-01
    phi[1,0]  R234      1.3418530225753784e+00
    phi[1,0]  R235      -2.7474288940429688e+00
    phi[1,0]  R236      -2.0025949925184250e-04
    phi[1,0]  R237      -1.4305970668792725e+00
    phi[1,0]  R238      5.5264055728912354e-01
    phi[1,0]  R239      -6.8360972404479980e-01
    phi[1,0]  R240      -1.0948202610015869e+00
    phi[1,0]  R241      -1.3564723730087280e+00
    phi[1,0]  R242      1.5871444940567017e+00
    phi[1,0]  R243      3.1327443122863770e+00
    phi[1,0]  R244      1.5062488317489624e+00
    phi[1,0]  R245      -1.5537766218185425e+00
    phi[1,0]  R246      1.0565611720085144e-01
    phi[1,0]  R247      -9.8675107955932617e-01
    phi[1,0]  R248      -6.2375295162200928e-01
    phi[1,0]  R249      -2.0804860591888428e+00
    phi[1,0]  R250      -1.6238176822662354e+00
    phi[1,0]  R251      -2.1933937072753906e+00
    phi[1,0]  R252      -2.3932843208312988e+00
    phi[1,0]  R253      -2.6565697193145752e+00
    phi[1,0]  R254      -1.2945883274078369e+00
    phi[1,0]  R255      -2.7847125530242920e+00
    phi[1,0]  R256      -3.1523334980010986e+00
    phi[1,0]  R257      -3.1884582042694092e+00
    phi[1,0]  R258      -2.5406651496887207e+00
    phi[1,0]  R259      -3.48580002784729
    phi[1,0]  R260      -4.4214873313903809e+00
    phi[1,0]  R261      -3.1795775890350342e+00
    phi[1,0]  R262      -2.6049892902374268e+00
    phi[1,0]  R263      -3.5210156440734863e+00
    phi[1,0]  R264      -1.4340366125106812e+00
    phi[1,0]  R265      -2.6746599674224854e+00
    phi[1,0]  R266      -1.1563403606414795e+00
    phi[1,0]  R267      -2.3634719848632812e+00
    phi[1,0]  R268      -1.7773422002792358e+00
    phi[1,0]  R269      -2.6609058380126953e+00
    phi[1,0]  R270      4.6668320894241333e-02
    phi[1,0]  R271      1.2699224948883057e+00
    phi[1,0]  R272      9.6895498037338257e-01
    phi[1,0]  R273      -2.0685620307922363e+00
    phi[1,0]  R274      5.1294195652008057e-01
    phi[1,0]  R275      -2.9464921951293945e+00
    phi[1,0]  R276      -9.2210000753402710e-01
    phi[1,0]  R277      -2.7731106281280518e+00
    phi[1,0]  R278      -3.6497633457183838e+00
    phi[1,0]  R279      -1.2681646347045898e+00
    phi[1,0]  R280      -2.0597469806671143e+00
    phi[1,0]  R281      1.2252575717866421e-02
    phi[1,0]  R282      -1.1620271950960159e-01
    phi[1,0]  R283      -1.3900592327117920e+00
    phi[1,0]  R284      -3.8215339183807373e+00
    phi[1,0]  R285      -2.7651870250701904e+00
    phi[1,0]  R286      -3.6894650459289551e+00
    phi[1,0]  R287      -4.0300340652465820e+00
    phi[1,0]  R288      -3.8696577548980713e+00
    phi[1,0]  R289      -3.2762682437896729e+00
    phi[1,0]  R290      -3.5559861660003662e+00
    phi[1,0]  R291      -1.1963206529617310e+00
    phi[1,0]  R292      -4.8483544588088989e-01
    phi[1,0]  R293      -1.6218549013137817e+00
    phi[1,0]  R294      -3.0645966529846191e+00
    phi[1,0]  R295      -2.1467866897583008e+00
    phi[1,0]  R296      -3.1298046112060547e+00
    phi[1,0]  R297      -2.8157329559326172e-01
    phi[1,0]  R298      -2.9254474639892578e+00
    phi[1,0]  R299      -1.3992965221405029e+00
    phi[1,0]  R300      -1.5387237071990967e-01
    phi[1,0]  R301      -1.9184720516204834e-01
    phi[0,4]  R0        1
    phi[0,4]  R1        1
    phi[0,4]  R36       -1
    phi[0,4]  R302      -3.0999999046325684e+00
    phi[0,4]  R303      -3.0999999046325684e+00
    phi[0,4]  R304      -2.2400000095367432e+00
    phi[0,4]  R305      -2.2400000095367432e+00
    phi[0,4]  R306      -3.0999999046325684e+00
    phi[0,4]  R307      -3.0999999046325684e+00
    phi[0,4]  R308      -2.5699999332427979e+00
    phi[0,4]  R309      -2.5699999332427979e+00
    phi[0,4]  R310      -3.0999999046325684e+00
    phi[0,4]  R311      -3.0999999046325684e+00
    phi[0,4]  R312      -2.0899999141693115e+00
    phi[0,4]  R313      -2.0899999141693115e+00
    phi[0,4]  R314      -3.0999999046325684e+00
    phi[0,4]  R315      -3.0999999046325684e+00
    phi[0,4]  R316      1.5871444940567017e+00
    phi[0,4]  R317      3.1327443122863770e+00
    phi[0,4]  R318      1.5062488317489624e+00
    phi[0,4]  R319      -1.5537766218185425e+00
    phi[0,4]  R320      1.0565611720085144e-01
    phi[0,4]  R321      -9.8675107955932617e-01
    phi[0,4]  R322      -6.2375295162200928e-01
    phi[0,4]  R323      -2.0804860591888428e+00
    phi[0,4]  R324      -1.6238176822662354e+00
    phi[0,4]  R325      -2.1933937072753906e+00
    phi[0,4]  R326      -2.3932843208312988e+00
    phi[0,4]  R327      -2.6565697193145752e+00
    phi[0,4]  R328      -1.2945883274078369e+00
    phi[0,4]  R329      -2.7847125530242920e+00
    phi[0,4]  R330      -3.1523334980010986e+00
    phi[0,4]  R331      -3.1884582042694092e+00
    phi[0,4]  R332      -2.5406651496887207e+00
    phi[0,4]  R333      -3.48580002784729
    phi[0,4]  R334      -4.4214873313903809e+00
    phi[0,4]  R335      -3.1795775890350342e+00
    phi[0,4]  R336      -2.6049892902374268e+00
    phi[0,4]  R337      -3.5210156440734863e+00
    phi[0,4]  R338      -1.4340366125106812e+00
    phi[0,4]  R339      -2.6746599674224854e+00
    phi[0,4]  R340      -1.1563403606414795e+00
    phi[0,4]  R341      -2.3634719848632812e+00
    phi[0,4]  R342      -1.7773422002792358e+00
    phi[0,4]  R343      -2.6609058380126953e+00
    phi[0,4]  R344      4.6668320894241333e-02
    phi[0,4]  R345      1.2699224948883057e+00
    phi[0,4]  R346      9.6895498037338257e-01
    phi[0,4]  R347      -2.0685620307922363e+00
    phi[0,4]  R348      5.1294195652008057e-01
    phi[0,4]  R349      -2.9464921951293945e+00
    phi[0,4]  R350      -9.2210000753402710e-01
    phi[0,4]  R351      -2.7731106281280518e+00
    phi[0,4]  R352      -3.6497633457183838e+00
    phi[0,4]  R353      -1.2681646347045898e+00
    phi[0,4]  R354      -2.0597469806671143e+00
    phi[0,4]  R355      1.2252575717866421e-02
    phi[0,4]  R356      -1.1620271950960159e-01
    phi[0,4]  R357      -1.3900592327117920e+00
    phi[0,4]  R358      -3.8215339183807373e+00
    phi[0,4]  R359      -2.7651870250701904e+00
    phi[0,4]  R360      -3.6894650459289551e+00
    phi[0,4]  R361      -4.0300340652465820e+00
    phi[0,4]  R362      -3.8696577548980713e+00
    phi[0,4]  R363      -3.2762682437896729e+00
    phi[0,4]  R364      -3.5559861660003662e+00
    phi[0,4]  R365      -1.1963206529617310e+00
    phi[0,4]  R366      -4.8483544588088989e-01
    phi[0,4]  R367      -1.6218549013137817e+00
    phi[0,4]  R368      -3.0645966529846191e+00
    phi[0,4]  R369      -2.1467866897583008e+00
    phi[0,4]  R370      -3.1298046112060547e+00
    phi[0,4]  R371      -2.8157329559326172e-01
    phi[0,4]  R372      -2.9254474639892578e+00
    phi[0,4]  R373      -1.3992965221405029e+00
    phi[0,4]  R374      -1.5387237071990967e-01
    phi[0,4]  R375      -1.9184720516204834e-01
    phi[0,4]  R376      1.0409893989562988e+00
    phi[0,4]  R377      3.12511944770813
    phi[0,4]  R378      2.2121331691741943e+00
    phi[0,4]  R379      2.4603700637817383e+00
    phi[0,4]  R380      2.8742768764495850e+00
    phi[0,4]  R381      1.7729644775390625e+00
    phi[0,4]  R382      2.6363046169281006e+00
    phi[0,4]  R383      3.3461880683898926e+00
    phi[0,4]  R384      3.1400470733642578e+00
    phi[0,4]  R385      2.1398820877075195e+00
    phi[0,4]  R386      1.4088853597640991e+00
    phi[0,4]  R387      -1.8469457626342773e+00
    phi[0,4]  R388      -1.9318068027496338e+00
    phi[0,4]  R389      -3.1918501853942871e-01
    phi[0,4]  R390      -3.5772633552551270e-01
    phi[0,4]  R391      9.4723916053771973e-01
    phi[0,4]  R392      -2.7779671549797058e-01
    phi[0,4]  R393      -4.1765800118446350e-01
    phi[0,4]  R394      -1.5578038692474365e+00
    phi[0,4]  R395      -9.8187726736068726e-01
    phi[0,4]  R396      2.4526591598987579e-01
    phi[0,4]  R397      -6.5786713361740112e-01
    phi[0,4]  R398      -1.4257522821426392e+00
    phi[0,4]  R399      -8.0545246601104736e-01
    phi[0,4]  R400      8.1633490324020386e-01
    phi[0,4]  R401      -2.4227447509765625e+00
    phi[0,4]  R402      -2.3991665840148926e+00
    phi[0,4]  R403      -1.3566262722015381e+00
    phi[0,4]  R404      -1.5960556268692017e+00
    phi[0,4]  R405      -2.28151273727417
    phi[0,4]  R406      4.3044766783714294e-01
    phi[0,4]  R407      6.4302825927734375e-01
    phi[0,4]  R408      7.4261862039566040e-01
    phi[0,4]  R409      -2.4349112510681152e+00
    phi[0,4]  R410      6.1484597623348236e-02
    phi[0,4]  R411      8.4120386838912964e-01
    phi[0,4]  R412      1.6435261964797974e+00
    phi[0,4]  R413      -2.0030975341796875e+00
    phi[0,4]  R414      -7.3184430599212646e-01
    phi[0,4]  R415      -1.2200669199228287e-01
    phi[4,0]  R0        -1
    phi[4,0]  R36       1
    phi[4,0]  R37       1
    phi[4,0]  R416      -3.0999999046325684e+00
    phi[4,0]  R417      -3.0999999046325684e+00
    phi[4,0]  R418      -2.2400000095367432e+00
    phi[4,0]  R419      -2.2400000095367432e+00
    phi[4,0]  R420      -3.0999999046325684e+00
    phi[4,0]  R421      -3.0999999046325684e+00
    phi[4,0]  R422      -2.5699999332427979e+00
    phi[4,0]  R423      -2.5699999332427979e+00
    phi[4,0]  R424      -3.0999999046325684e+00
    phi[4,0]  R425      -3.0999999046325684e+00
    phi[4,0]  R426      -2.0899999141693115e+00
    phi[4,0]  R427      -2.0899999141693115e+00
    phi[4,0]  R428      -3.0999999046325684e+00
    phi[4,0]  R429      -3.0999999046325684e+00
    phi[4,0]  R430      1.0409893989562988e+00
    phi[4,0]  R431      3.12511944770813
    phi[4,0]  R432      2.2121331691741943e+00
    phi[4,0]  R433      2.4603700637817383e+00
    phi[4,0]  R434      2.8742768764495850e+00
    phi[4,0]  R435      1.7729644775390625e+00
    phi[4,0]  R436      2.6363046169281006e+00
    phi[4,0]  R437      3.3461880683898926e+00
    phi[4,0]  R438      3.1400470733642578e+00
    phi[4,0]  R439      2.1398820877075195e+00
    phi[4,0]  R440      1.4088853597640991e+00
    phi[4,0]  R441      -1.8469457626342773e+00
    phi[4,0]  R442      -1.9318068027496338e+00
    phi[4,0]  R443      -3.1918501853942871e-01
    phi[4,0]  R444      -3.5772633552551270e-01
    phi[4,0]  R445      9.4723916053771973e-01
    phi[4,0]  R446      -2.7779671549797058e-01
    phi[4,0]  R447      -4.1765800118446350e-01
    phi[4,0]  R448      -1.5578038692474365e+00
    phi[4,0]  R449      -9.8187726736068726e-01
    phi[4,0]  R450      2.4526591598987579e-01
    phi[4,0]  R451      -6.5786713361740112e-01
    phi[4,0]  R452      -1.4257522821426392e+00
    phi[4,0]  R453      -8.0545246601104736e-01
    phi[4,0]  R454      8.1633490324020386e-01
    phi[4,0]  R455      -2.4227447509765625e+00
    phi[4,0]  R456      -2.3991665840148926e+00
    phi[4,0]  R457      -1.3566262722015381e+00
    phi[4,0]  R458      -1.5960556268692017e+00
    phi[4,0]  R459      -2.28151273727417
    phi[4,0]  R460      4.3044766783714294e-01
    phi[4,0]  R461      6.4302825927734375e-01
    phi[4,0]  R462      7.4261862039566040e-01
    phi[4,0]  R463      -2.4349112510681152e+00
    phi[4,0]  R464      6.1484597623348236e-02
    phi[4,0]  R465      8.4120386838912964e-01
    phi[4,0]  R466      1.6435261964797974e+00
    phi[4,0]  R467      -2.0030975341796875e+00
    phi[4,0]  R468      -7.3184430599212646e-01
    phi[4,0]  R469      -1.2200669199228287e-01
    phi[4,0]  R470      1.5871444940567017e+00
    phi[4,0]  R471      3.1327443122863770e+00
    phi[4,0]  R472      1.5062488317489624e+00
    phi[4,0]  R473      -1.5537766218185425e+00
    phi[4,0]  R474      1.0565611720085144e-01
    phi[4,0]  R475      -9.8675107955932617e-01
    phi[4,0]  R476      -6.2375295162200928e-01
    phi[4,0]  R477      -2.0804860591888428e+00
    phi[4,0]  R478      -1.6238176822662354e+00
    phi[4,0]  R479      -2.1933937072753906e+00
    phi[4,0]  R480      -2.3932843208312988e+00
    phi[4,0]  R481      -2.6565697193145752e+00
    phi[4,0]  R482      -1.2945883274078369e+00
    phi[4,0]  R483      -2.7847125530242920e+00
    phi[4,0]  R484      -3.1523334980010986e+00
    phi[4,0]  R485      -3.1884582042694092e+00
    phi[4,0]  R486      -2.5406651496887207e+00
    phi[4,0]  R487      -3.48580002784729
    phi[4,0]  R488      -4.4214873313903809e+00
    phi[4,0]  R489      -3.1795775890350342e+00
    phi[4,0]  R490      -2.6049892902374268e+00
    phi[4,0]  R491      -3.5210156440734863e+00
    phi[4,0]  R492      -1.4340366125106812e+00
    phi[4,0]  R493      -2.6746599674224854e+00
    phi[4,0]  R494      -1.1563403606414795e+00
    phi[4,0]  R495      -2.3634719848632812e+00
    phi[4,0]  R496      -1.7773422002792358e+00
    phi[4,0]  R497      -2.6609058380126953e+00
    phi[4,0]  R498      4.6668320894241333e-02
    phi[4,0]  R499      1.2699224948883057e+00
    phi[4,0]  R500      9.6895498037338257e-01
    phi[4,0]  R501      -2.0685620307922363e+00
    phi[4,0]  R502      5.1294195652008057e-01
    phi[4,0]  R503      -2.9464921951293945e+00
    phi[4,0]  R504      -9.2210000753402710e-01
    phi[4,0]  R505      -2.7731106281280518e+00
    phi[4,0]  R506      -3.6497633457183838e+00
    phi[4,0]  R507      -1.2681646347045898e+00
    phi[4,0]  R508      -2.0597469806671143e+00
    phi[4,0]  R509      1.2252575717866421e-02
    phi[4,0]  R510      -1.1620271950960159e-01
    phi[4,0]  R511      -1.3900592327117920e+00
    phi[4,0]  R512      -3.8215339183807373e+00
    phi[4,0]  R513      -2.7651870250701904e+00
    phi[4,0]  R514      -3.6894650459289551e+00
    phi[4,0]  R515      -4.0300340652465820e+00
    phi[4,0]  R516      -3.8696577548980713e+00
    phi[4,0]  R517      -3.2762682437896729e+00
    phi[4,0]  R518      -3.5559861660003662e+00
    phi[4,0]  R519      -1.1963206529617310e+00
    phi[4,0]  R520      -4.8483544588088989e-01
    phi[4,0]  R521      -1.6218549013137817e+00
    phi[4,0]  R522      -3.0645966529846191e+00
    phi[4,0]  R523      -2.1467866897583008e+00
    phi[4,0]  R524      -3.1298046112060547e+00
    phi[4,0]  R525      -2.8157329559326172e-01
    phi[4,0]  R526      -2.9254474639892578e+00
    phi[4,0]  R527      -1.3992965221405029e+00
    phi[4,0]  R528      -1.5387237071990967e-01
    phi[4,0]  R529      -1.9184720516204834e-01
    phi[0,5]  R0        1
    phi[0,5]  R1        1
    phi[0,5]  R45       -1
    phi[0,5]  R530      -3.0999999046325684e+00
    phi[0,5]  R531      -3.0999999046325684e+00
    phi[0,5]  R532      -2.2400000095367432e+00
    phi[0,5]  R533      -2.2400000095367432e+00
    phi[0,5]  R534      -3.0999999046325684e+00
    phi[0,5]  R535      -3.0999999046325684e+00
    phi[0,5]  R536      -2.5699999332427979e+00
    phi[0,5]  R537      -2.5699999332427979e+00
    phi[0,5]  R538      -3.0999999046325684e+00
    phi[0,5]  R539      -3.0999999046325684e+00
    phi[0,5]  R540      -2.0899999141693115e+00
    phi[0,5]  R541      -2.0899999141693115e+00
    phi[0,5]  R542      -3.0999999046325684e+00
    phi[0,5]  R543      -3.0999999046325684e+00
    phi[0,5]  R544      1.5871444940567017e+00
    phi[0,5]  R545      3.1327443122863770e+00
    phi[0,5]  R546      1.5062488317489624e+00
    phi[0,5]  R547      -1.5537766218185425e+00
    phi[0,5]  R548      1.0565611720085144e-01
    phi[0,5]  R549      -9.8675107955932617e-01
    phi[0,5]  R550      -6.2375295162200928e-01
    phi[0,5]  R551      -2.0804860591888428e+00
    phi[0,5]  R552      -1.6238176822662354e+00
    phi[0,5]  R553      -2.1933937072753906e+00
    phi[0,5]  R554      -2.3932843208312988e+00
    phi[0,5]  R555      -2.6565697193145752e+00
    phi[0,5]  R556      -1.2945883274078369e+00
    phi[0,5]  R557      -2.7847125530242920e+00
    phi[0,5]  R558      -3.1523334980010986e+00
    phi[0,5]  R559      -3.1884582042694092e+00
    phi[0,5]  R560      -2.5406651496887207e+00
    phi[0,5]  R561      -3.48580002784729
    phi[0,5]  R562      -4.4214873313903809e+00
    phi[0,5]  R563      -3.1795775890350342e+00
    phi[0,5]  R564      -2.6049892902374268e+00
    phi[0,5]  R565      -3.5210156440734863e+00
    phi[0,5]  R566      -1.4340366125106812e+00
    phi[0,5]  R567      -2.6746599674224854e+00
    phi[0,5]  R568      -1.1563403606414795e+00
    phi[0,5]  R569      -2.3634719848632812e+00
    phi[0,5]  R570      -1.7773422002792358e+00
    phi[0,5]  R571      -2.6609058380126953e+00
    phi[0,5]  R572      4.6668320894241333e-02
    phi[0,5]  R573      1.2699224948883057e+00
    phi[0,5]  R574      9.6895498037338257e-01
    phi[0,5]  R575      -2.0685620307922363e+00
    phi[0,5]  R576      5.1294195652008057e-01
    phi[0,5]  R577      -2.9464921951293945e+00
    phi[0,5]  R578      -9.2210000753402710e-01
    phi[0,5]  R579      -2.7731106281280518e+00
    phi[0,5]  R580      -3.6497633457183838e+00
    phi[0,5]  R581      -1.2681646347045898e+00
    phi[0,5]  R582      -2.0597469806671143e+00
    phi[0,5]  R583      1.2252575717866421e-02
    phi[0,5]  R584      -1.1620271950960159e-01
    phi[0,5]  R585      -1.3900592327117920e+00
    phi[0,5]  R586      -3.8215339183807373e+00
    phi[0,5]  R587      -2.7651870250701904e+00
    phi[0,5]  R588      -3.6894650459289551e+00
    phi[0,5]  R589      -4.0300340652465820e+00
    phi[0,5]  R590      -3.8696577548980713e+00
    phi[0,5]  R591      -3.2762682437896729e+00
    phi[0,5]  R592      -3.5559861660003662e+00
    phi[0,5]  R593      -1.1963206529617310e+00
    phi[0,5]  R594      -4.8483544588088989e-01
    phi[0,5]  R595      -1.6218549013137817e+00
    phi[0,5]  R596      -3.0645966529846191e+00
    phi[0,5]  R597      -2.1467866897583008e+00
    phi[0,5]  R598      -3.1298046112060547e+00
    phi[0,5]  R599      -2.8157329559326172e-01
    phi[0,5]  R600      -2.9254474639892578e+00
    phi[0,5]  R601      -1.3992965221405029e+00
    phi[0,5]  R602      -1.5387237071990967e-01
    phi[0,5]  R603      -1.9184720516204834e-01
    phi[0,5]  R604      1.9300042390823364e+00
    phi[0,5]  R605      7.4363201856613159e-01
    phi[0,5]  R606      7.5290125608444214e-01
    phi[0,5]  R607      8.8865995407104492e-01
    phi[0,5]  R608      1.8823522329330444e+00
    phi[0,5]  R609      2.8884959220886230e-01
    phi[0,5]  R610      6.1533157713711262e-03
    phi[0,5]  R611      -1.3884544372558594e+00
    phi[0,5]  R612      -1.1666467189788818e+00
    phi[0,5]  R613      -2.3745880126953125e+00
    phi[0,5]  R614      -2.6544380187988281e+00
    phi[0,5]  R615      -3.3787441253662109e+00
    phi[0,5]  R616      -1.2786622047424316e+00
    phi[0,5]  R617      -1.7446815967559814e+00
    phi[0,5]  R618      -1.1144081354141235e+00
    phi[0,5]  R619      -1.3227696418762207e+00
    phi[0,5]  R620      -7.0742154121398926e-01
    phi[0,5]  R621      -1.3913764953613281e+00
    phi[5,0]  R0        -1
    phi[5,0]  R45       1
    phi[5,0]  R46       1
    phi[5,0]  R622      -3.0999999046325684e+00
    phi[5,0]  R623      -3.0999999046325684e+00
    phi[5,0]  R624      -2.2400000095367432e+00
    phi[5,0]  R625      -2.2400000095367432e+00
    phi[5,0]  R626      -3.0999999046325684e+00
    phi[5,0]  R627      -3.0999999046325684e+00
    phi[5,0]  R628      -2.5699999332427979e+00
    phi[5,0]  R629      -2.5699999332427979e+00
    phi[5,0]  R630      -3.0999999046325684e+00
    phi[5,0]  R631      -3.0999999046325684e+00
    phi[5,0]  R632      -2.0899999141693115e+00
    phi[5,0]  R633      -2.0899999141693115e+00
    phi[5,0]  R634      -3.0999999046325684e+00
    phi[5,0]  R635      -3.0999999046325684e+00
    phi[5,0]  R636      1.9300042390823364e+00
    phi[5,0]  R637      7.4363201856613159e-01
    phi[5,0]  R638      7.5290125608444214e-01
    phi[5,0]  R639      8.8865995407104492e-01
    phi[5,0]  R640      1.8823522329330444e+00
    phi[5,0]  R641      2.8884959220886230e-01
    phi[5,0]  R642      6.1533157713711262e-03
    phi[5,0]  R643      -1.3884544372558594e+00
    phi[5,0]  R644      -1.1666467189788818e+00
    phi[5,0]  R645      -2.3745880126953125e+00
    phi[5,0]  R646      -2.6544380187988281e+00
    phi[5,0]  R647      -3.3787441253662109e+00
    phi[5,0]  R648      -1.2786622047424316e+00
    phi[5,0]  R649      -1.7446815967559814e+00
    phi[5,0]  R650      -1.1144081354141235e+00
    phi[5,0]  R651      -1.3227696418762207e+00
    phi[5,0]  R652      -7.0742154121398926e-01
    phi[5,0]  R653      -1.3913764953613281e+00
    phi[5,0]  R654      1.5871444940567017e+00
    phi[5,0]  R655      3.1327443122863770e+00
    phi[5,0]  R656      1.5062488317489624e+00
    phi[5,0]  R657      -1.5537766218185425e+00
    phi[5,0]  R658      1.0565611720085144e-01
    phi[5,0]  R659      -9.8675107955932617e-01
    phi[5,0]  R660      -6.2375295162200928e-01
    phi[5,0]  R661      -2.0804860591888428e+00
    phi[5,0]  R662      -1.6238176822662354e+00
    phi[5,0]  R663      -2.1933937072753906e+00
    phi[5,0]  R664      -2.3932843208312988e+00
    phi[5,0]  R665      -2.6565697193145752e+00
    phi[5,0]  R666      -1.2945883274078369e+00
    phi[5,0]  R667      -2.7847125530242920e+00
    phi[5,0]  R668      -3.1523334980010986e+00
    phi[5,0]  R669      -3.1884582042694092e+00
    phi[5,0]  R670      -2.5406651496887207e+00
    phi[5,0]  R671      -3.48580002784729
    phi[5,0]  R672      -4.4214873313903809e+00
    phi[5,0]  R673      -3.1795775890350342e+00
    phi[5,0]  R674      -2.6049892902374268e+00
    phi[5,0]  R675      -3.5210156440734863e+00
    phi[5,0]  R676      -1.4340366125106812e+00
    phi[5,0]  R677      -2.6746599674224854e+00
    phi[5,0]  R678      -1.1563403606414795e+00
    phi[5,0]  R679      -2.3634719848632812e+00
    phi[5,0]  R680      -1.7773422002792358e+00
    phi[5,0]  R681      -2.6609058380126953e+00
    phi[5,0]  R682      4.6668320894241333e-02
    phi[5,0]  R683      1.2699224948883057e+00
    phi[5,0]  R684      9.6895498037338257e-01
    phi[5,0]  R685      -2.0685620307922363e+00
    phi[5,0]  R686      5.1294195652008057e-01
    phi[5,0]  R687      -2.9464921951293945e+00
    phi[5,0]  R688      -9.2210000753402710e-01
    phi[5,0]  R689      -2.7731106281280518e+00
    phi[5,0]  R690      -3.6497633457183838e+00
    phi[5,0]  R691      -1.2681646347045898e+00
    phi[5,0]  R692      -2.0597469806671143e+00
    phi[5,0]  R693      1.2252575717866421e-02
    phi[5,0]  R694      -1.1620271950960159e-01
    phi[5,0]  R695      -1.3900592327117920e+00
    phi[5,0]  R696      -3.8215339183807373e+00
    phi[5,0]  R697      -2.7651870250701904e+00
    phi[5,0]  R698      -3.6894650459289551e+00
    phi[5,0]  R699      -4.0300340652465820e+00
    phi[5,0]  R700      -3.8696577548980713e+00
    phi[5,0]  R701      -3.2762682437896729e+00
    phi[5,0]  R702      -3.5559861660003662e+00
    phi[5,0]  R703      -1.1963206529617310e+00
    phi[5,0]  R704      -4.8483544588088989e-01
    phi[5,0]  R705      -1.6218549013137817e+00
    phi[5,0]  R706      -3.0645966529846191e+00
    phi[5,0]  R707      -2.1467866897583008e+00
    phi[5,0]  R708      -3.1298046112060547e+00
    phi[5,0]  R709      -2.8157329559326172e-01
    phi[5,0]  R710      -2.9254474639892578e+00
    phi[5,0]  R711      -1.3992965221405029e+00
    phi[5,0]  R712      -1.5387237071990967e-01
    phi[5,0]  R713      -1.9184720516204834e-01
    phi[8,0]  R0        -1
    phi[8,0]  R2        -1.3550681263039
    phi[8,0]  R3        2.0686367358790969e-01
    phi[8,0]  R4        2.9534051777112533e+00
    phi[8,0]  R5        1.5626497589467756e+00
    phi[8,0]  R6        2.8910893979909322e+00
    phi[8,0]  R7        5.7556263234235239e-01
    phi[8,0]  R8        -1.5764510220519012e-01
    phi[8,0]  R72       1
    phi[8,0]  R714      -1.7449317783286684e+00
    phi[8,0]  R715      -4.4550680309364683e+00
    phi[8,0]  R716      -2.4468636831246529e+00
    phi[8,0]  R717      -2.0331363359488335e+00
    phi[8,0]  R718      -6.0534050823438221e+00
    phi[8,0]  R719      -1.4659472692131503e-01
    phi[8,0]  R720      -4.1326496921895739e+00
    phi[8,0]  R721      -1.0073501742960222e+00
    phi[8,0]  R722      -5.9910893026235
    phi[8,0]  R723      -2.0891050664163613e-01
    phi[8,0]  R724      -2.6655625465116639e+00
    phi[8,0]  R725      -1.5144372818269591e+00
    phi[8,0]  R726      -2.9423548024273782e+00
    phi[8,0]  R727      -3.2576450068377585e+00
    phi[8,0]  R728      -1.6228159808650577e-01
    phi[8,0]  R729      -2.5031703306596320e-01
    phi[8,0]  R730      -2.9480356064231783e-01
    phi[8,0]  R731      -8.2920520555281163e-01
    phi[8,0]  R732      -5.0689005079473648e-01
    phi[8,0]  R733      -1.1706703623763919e+00
    phi[8,0]  R734      -1.6562915398008480e+00
    phi[8,0]  R735      -9.2580546633635774e-01
    phi[8,0]  R736      -1.6407054890615638e+00
    phi[8,0]  R737      -1.2063339604897259e+00
    phi[8,0]  R738      -2.9571320193798689e-01
    phi[8,0]  R739      -3.0603577260357406e-01
    phi[8,0]  R740      -3.3009027185030160e-01
    phi[8,0]  R741      -4.0920778557432946e-01
    phi[8,0]  R742      -4.9130572532295469e-01
    phi[8,0]  R743      -1.5327147827339185e+00
    phi[8,0]  R744      -1.7975023127213541e+00
    phi[8,0]  R745      -1.3264291208725520e+00
    phi[8,0]  R746      -8.4379548617430578e-01
    phi[8,0]  R747      -8.0051541458614706e-01
    phi[8,0]  R748      -1.2186536148743445e+00
    phi[8,0]  R749      -4.8980395945959376e-01
    phi[8,0]  R750      -5.1703705983641512e-01
    phi[8,0]  R751      -7.9646949542919532e-01
    phi[8,0]  R752      -5.5910984575323819e-01
    phi[8,0]  R753      -7.7371219631685650e-01
    phi[8,0]  R754      -1.8343554275014058e+00
    phi[8,0]  R755      -1.7906101874372895e+00
    phi[8,0]  R756      -7.4601803276090028e-01
    phi[8,0]  R757      -8.0576527251134955e-01
    phi[8,0]  R758      -3.5223190465933651e-01
    phi[8,0]  R759      -4.1230987133679453e-01
    phi[8,0]  R760      -4.1869687154681667e-01
    phi[8,0]  R761      -4.7669700658090663e-01
    phi[8,0]  R762      -5.3658388774944210e-01
    phi[8,0]  R763      -1.4577293335961783e+00
    phi[8,0]  R764      -5.5245771636167618e-01
    phi[8,0]  R765      -2.0059740771454115e+00
    phi[8,0]  R766      -8.7714015301690318e-01
    phi[8,0]  R767      -6.1137966135462718e-01
    phi[8,0]  R768      -3.0686136232249406e-01
    phi[8,0]  R769      -3.1725738418521354e-01
    phi[8,0]  R770      -1.0595458587150577e+00
    phi[8,0]  R771      -4.4215783017376609e-01
    phi[8,0]  R772      -4.6684858083712388e-01
    phi[8,0]  R773      -4.9112258889552685e-01
    phi[8,0]  R774      -4.9303838783996090e-01
    phi[8,0]  R775      -4.9722374656150192e-01
    phi[8,0]  R776      -5.0166163191702529e-01
    phi[8,0]  R777      -1.7057118588228726e+00
    phi[8,0]  R778      -3.1153963334753260e-01
    phi[8,0]  R779      -3.3579031113483060e-01
    phi[8,0]  R780      -4.3093196764844865e-01
    phi[8,0]  R781      -1.6838812622523509e+00
    phi[8,0]  R782      -1.0460060165881080e+00
    phi[8,0]  R783      -1.4514028639609056e+00
    phi[8,0]  R784      -9.9359028061736532e-01
    phi[8,0]  R785      -7.8946407597494461e-01
    phi[8,0]  R786      -8.5932244002844882e-01
    phi[8,0]  R787      -8.9802035169138639e-01
    phi[1,2]  R9        1
    phi[1,2]  R10       1
    phi[1,2]  R18       -1
    phi[1,2]  R788      -3.0999999046325684e+00
    phi[1,2]  R789      -3.0999999046325684e+00
    phi[1,2]  R790      -2.2400000095367432e+00
    phi[1,2]  R791      -2.2400000095367432e+00
    phi[1,2]  R792      -3.0999999046325684e+00
    phi[1,2]  R793      -3.0999999046325684e+00
    phi[1,2]  R794      -2.5699999332427979e+00
    phi[1,2]  R795      -2.5699999332427979e+00
    phi[1,2]  R796      -3.0999999046325684e+00
    phi[1,2]  R797      -3.0999999046325684e+00
    phi[1,2]  R798      -2.0899999141693115e+00
    phi[1,2]  R799      -2.0899999141693115e+00
    phi[1,2]  R800      -3.0999999046325684e+00
    phi[1,2]  R801      -3.0999999046325684e+00
    phi[1,2]  R802      1.0953590869903564e+00
    phi[1,2]  R803      1.0949059724807739e+00
    phi[1,2]  R804      3.2336792349815369e-01
    phi[1,2]  R805      2.4676816165447235e-01
    phi[1,2]  R806      -1.0653502941131592e+00
    phi[1,2]  R807      -2.0282294750213623e+00
    phi[1,2]  R808      1.0122755765914917e+00
    phi[1,2]  R809      -3.8481515645980835e-01
    phi[1,2]  R810      -1.1844459772109985e+00
    phi[1,2]  R811      -1.2625811100006104e+00
    phi[1,2]  R812      -2.0794820785522461e+00
    phi[1,2]  R813      -1.9246559143066406e+00
    phi[1,2]  R814      -8.9861404895782471e-01
    phi[1,2]  R815      -2.23384428024292
    phi[1,2]  R816      -9.3556308746337891e-01
    phi[1,2]  R817      1.1689919233322144e+00
    phi[1,2]  R818      -2.8804833889007568e+00
    phi[1,2]  R819      -1.6614713668823242e+00
    phi[1,2]  R820      5.5326007306575775e-02
    phi[1,2]  R821      -1.3306286334991455e+00
    phi[1,2]  R822      -1.0094625949859619e+00
    phi[1,2]  R823      -2.5318114757537842e+00
    phi[1,2]  R824      1.4510639905929565e+00
    phi[1,2]  R825      -3.0313420295715332e+00
    phi[1,2]  R826      -1.8906174898147583e+00
    phi[1,2]  R827      -2.6267926692962646e+00
    phi[1,2]  R828      -3.4027280807495117e+00
    phi[1,2]  R829      -9.0056687593460083e-02
    phi[1,2]  R830      -1.1165565252304077e+00
    phi[1,2]  R831      -9.5106318593025208e-02
    phi[1,2]  R832      5.5066192150115967e-01
    phi[1,2]  R833      4.1080260276794434e-01
    phi[1,2]  R834      1.3418530225753784e+00
    phi[1,2]  R835      -2.7474288940429688e+00
    phi[1,2]  R836      -2.0025949925184250e-04
    phi[1,2]  R837      -1.4305970668792725e+00
    phi[1,2]  R838      5.5264055728912354e-01
    phi[1,2]  R839      -6.8360972404479980e-01
    phi[1,2]  R840      -1.0948202610015869e+00
    phi[1,2]  R841      -1.3564723730087280e+00
    phi[1,2]  R842      -0.639030933380127
    phi[1,2]  R843      1.9622149467468262e+00
    phi[1,2]  R844      8.6084157228469849e-01
    phi[1,2]  R845      1.9289108514785767e+00
    phi[1,2]  R846      1.1251482963562012e+00
    phi[1,2]  R847      -2.8704500198364258e-01
    phi[1,2]  R848      1.1227023601531982e+00
    phi[1,2]  R849      3.7896066904067993e-01
    phi[1,2]  R850      -3.2580140233039856e-01
    phi[1,2]  R851      5.7166717946529388e-02
    phi[1,2]  R852      -1.2111747264862061e+00
    phi[1,2]  R853      -1.5875182151794434e+00
    phi[1,2]  R854      -1.8528891801834106e+00
    phi[1,2]  R855      -1.8588619232177734e+00
    phi[1,2]  R856      -2.5788536071777344e+00
    phi[1,2]  R857      -9.7165119647979736e-01
    phi[1,2]  R858      -6.6313332319259644e-01
    phi[1,2]  R859      -1.5588051080703735e+00
    phi[1,2]  R860      -5.0865840911865234e-01
    phi[1,2]  R861      -1.8580968379974365e+00
    phi[1,2]  R862      4.8742389678955078e-01
    phi[1,2]  R863      -2.5861542224884033e+00
    phi[1,2]  R864      -1.6427432298660278e+00
    phi[1,2]  R865      -0.337889701128006
    phi[1,2]  R866      -7.3016655445098877e-01
    phi[1,2]  R867      -1.4531118869781494e+00
    phi[1,2]  R868      -1.5581912994384766e+00
    phi[1,2]  R869      1.0206624269485474e+00
    phi[1,2]  R870      -1.9672541618347168e+00
    phi[1,2]  R871      -0.761530876159668
    phi[1,2]  R872      -1.5252308845520020e+00
    phi[1,2]  R873      -6.9365328550338745e-01
    phi[1,2]  R874      1.9604235887527466e+00
    phi[1,2]  R875      -6.0929852724075317e-01
    phi[1,2]  R876      -9.7290998697280884e-01
    phi[1,2]  R877      1.0316015481948853e+00
    phi[1,2]  R878      4.8142120242118835e-01
    phi[1,2]  R879      7.7350193262100220e-01
    phi[1,2]  R880      8.1951344013214111e-01
    phi[1,2]  R881      -2.2848446369171143e+00
    phi[1,2]  R882      1.2338868379592896e+00
    phi[1,2]  R883      1.5070356130599976e+00
    phi[1,2]  R884      -1.4971580505371094e+00
    phi[1,2]  R885      -5.3001278638839722e-01
    phi[1,2]  R886      -9.8340988159179688e-01
    phi[1,2]  R887      1.1091046333312988e+00
    phi[1,2]  R888      7.5640785694122314e-01
    phi[1,2]  R889      5.7240372896194458e-01
    phi[1,2]  R890      -2.7329878807067871e+00
    phi[1,2]  R891      2.5290653705596924e+00
    phi[1,2]  R892      4.9952107667922974e-01
    phi[1,2]  R893      -1.6742812395095825e+00
    phi[1,2]  R894      -1.9607321023941040e+00
    phi[1,2]  R895      2.2819032669067383e+00
    phi[1,2]  R896      1.6397927999496460e+00
    phi[1,2]  R897      -9.2800593376159668e-01
    phi[1,2]  R898      2.9060785770416260e+00
    phi[1,2]  R899      2.0339558124542236e+00
    phi[1,2]  R900      2.8528702259063721e-01
    phi[1,2]  R901      -6.5872468054294586e-02
    phi[1,2]  R902      -1.6112822294235229e+00
    phi[1,2]  R903      -1.3321362733840942e+00
    phi[1,2]  R904      2.2171361446380615e+00
    phi[1,2]  R905      -9.3284922838211060e-01
    phi[1,2]  R906      0.253875195980072
    phi[1,2]  R907      2.2718071937561035e-01
    phi[1,2]  R908      -1.6169983148574829e+00
    phi[1,2]  R909      -1.6760454177856445e+00
    phi[1,2]  R910      -1.8260077238082886e+00
    phi[1,2]  R911      -1.7918407917022705e+00
    phi[2,1]  R9        -1
    phi[2,1]  R18       1
    phi[2,1]  R19       1
    phi[2,1]  R912      -3.0999999046325684e+00
    phi[2,1]  R913      -3.0999999046325684e+00
    phi[2,1]  R914      -2.2400000095367432e+00
    phi[2,1]  R915      -2.2400000095367432e+00
    phi[2,1]  R916      -3.0999999046325684e+00
    phi[2,1]  R917      -3.0999999046325684e+00
    phi[2,1]  R918      -2.5699999332427979e+00
    phi[2,1]  R919      -2.5699999332427979e+00
    phi[2,1]  R920      -3.0999999046325684e+00
    phi[2,1]  R921      -3.0999999046325684e+00
    phi[2,1]  R922      -2.0899999141693115e+00
    phi[2,1]  R923      -2.0899999141693115e+00
    phi[2,1]  R924      -3.0999999046325684e+00
    phi[2,1]  R925      -3.0999999046325684e+00
    phi[2,1]  R926      -0.639030933380127
    phi[2,1]  R927      1.9622149467468262e+00
    phi[2,1]  R928      8.6084157228469849e-01
    phi[2,1]  R929      1.9289108514785767e+00
    phi[2,1]  R930      1.1251482963562012e+00
    phi[2,1]  R931      -2.8704500198364258e-01
    phi[2,1]  R932      1.1227023601531982e+00
    phi[2,1]  R933      3.7896066904067993e-01
    phi[2,1]  R934      -3.2580140233039856e-01
    phi[2,1]  R935      5.7166717946529388e-02
    phi[2,1]  R936      -1.2111747264862061e+00
    phi[2,1]  R937      -1.5875182151794434e+00
    phi[2,1]  R938      -1.8528891801834106e+00
    phi[2,1]  R939      -1.8588619232177734e+00
    phi[2,1]  R940      -2.5788536071777344e+00
    phi[2,1]  R941      -9.7165119647979736e-01
    phi[2,1]  R942      -6.6313332319259644e-01
    phi[2,1]  R943      -1.5588051080703735e+00
    phi[2,1]  R944      -5.0865840911865234e-01
    phi[2,1]  R945      -1.8580968379974365e+00
    phi[2,1]  R946      4.8742389678955078e-01
    phi[2,1]  R947      -2.5861542224884033e+00
    phi[2,1]  R948      -1.6427432298660278e+00
    phi[2,1]  R949      -0.337889701128006
    phi[2,1]  R950      -7.3016655445098877e-01
    phi[2,1]  R951      -1.4531118869781494e+00
    phi[2,1]  R952      -1.5581912994384766e+00
    phi[2,1]  R953      1.0206624269485474e+00
    phi[2,1]  R954      -1.9672541618347168e+00
    phi[2,1]  R955      -0.761530876159668
    phi[2,1]  R956      -1.5252308845520020e+00
    phi[2,1]  R957      -6.9365328550338745e-01
    phi[2,1]  R958      1.9604235887527466e+00
    phi[2,1]  R959      -6.0929852724075317e-01
    phi[2,1]  R960      -9.7290998697280884e-01
    phi[2,1]  R961      1.0316015481948853e+00
    phi[2,1]  R962      4.8142120242118835e-01
    phi[2,1]  R963      7.7350193262100220e-01
    phi[2,1]  R964      8.1951344013214111e-01
    phi[2,1]  R965      -2.2848446369171143e+00
    phi[2,1]  R966      1.2338868379592896e+00
    phi[2,1]  R967      1.5070356130599976e+00
    phi[2,1]  R968      -1.4971580505371094e+00
    phi[2,1]  R969      -5.3001278638839722e-01
    phi[2,1]  R970      -9.8340988159179688e-01
    phi[2,1]  R971      1.1091046333312988e+00
    phi[2,1]  R972      7.5640785694122314e-01
    phi[2,1]  R973      5.7240372896194458e-01
    phi[2,1]  R974      -2.7329878807067871e+00
    phi[2,1]  R975      2.5290653705596924e+00
    phi[2,1]  R976      4.9952107667922974e-01
    phi[2,1]  R977      -1.6742812395095825e+00
    phi[2,1]  R978      -1.9607321023941040e+00
    phi[2,1]  R979      2.2819032669067383e+00
    phi[2,1]  R980      1.6397927999496460e+00
    phi[2,1]  R981      -9.2800593376159668e-01
    phi[2,1]  R982      2.9060785770416260e+00
    phi[2,1]  R983      2.0339558124542236e+00
    phi[2,1]  R984      2.8528702259063721e-01
    phi[2,1]  R985      -6.5872468054294586e-02
    phi[2,1]  R986      -1.6112822294235229e+00
    phi[2,1]  R987      -1.3321362733840942e+00
    phi[2,1]  R988      2.2171361446380615e+00
    phi[2,1]  R989      -9.3284922838211060e-01
    phi[2,1]  R990      0.253875195980072
    phi[2,1]  R991      2.2718071937561035e-01
    phi[2,1]  R992      -1.6169983148574829e+00
    phi[2,1]  R993      -1.6760454177856445e+00
    phi[2,1]  R994      -1.8260077238082886e+00
    phi[2,1]  R995      -1.7918407917022705e+00
    phi[2,1]  R996      1.0953590869903564e+00
    phi[2,1]  R997      1.0949059724807739e+00
    phi[2,1]  R998      3.2336792349815369e-01
    phi[2,1]  R999      2.4676816165447235e-01
    phi[2,1]  R1000     -1.0653502941131592e+00
    phi[2,1]  R1001     -2.0282294750213623e+00
    phi[2,1]  R1002     1.0122755765914917e+00
    phi[2,1]  R1003     -3.8481515645980835e-01
    phi[2,1]  R1004     -1.1844459772109985e+00
    phi[2,1]  R1005     -1.2625811100006104e+00
    phi[2,1]  R1006     -2.0794820785522461e+00
    phi[2,1]  R1007     -1.9246559143066406e+00
    phi[2,1]  R1008     -8.9861404895782471e-01
    phi[2,1]  R1009     -2.23384428024292
    phi[2,1]  R1010     -9.3556308746337891e-01
    phi[2,1]  R1011     1.1689919233322144e+00
    phi[2,1]  R1012     -2.8804833889007568e+00
    phi[2,1]  R1013     -1.6614713668823242e+00
    phi[2,1]  R1014     5.5326007306575775e-02
    phi[2,1]  R1015     -1.3306286334991455e+00
    phi[2,1]  R1016     -1.0094625949859619e+00
    phi[2,1]  R1017     -2.5318114757537842e+00
    phi[2,1]  R1018     1.4510639905929565e+00
    phi[2,1]  R1019     -3.0313420295715332e+00
    phi[2,1]  R1020     -1.8906174898147583e+00
    phi[2,1]  R1021     -2.6267926692962646e+00
    phi[2,1]  R1022     -3.4027280807495117e+00
    phi[2,1]  R1023     -9.0056687593460083e-02
    phi[2,1]  R1024     -1.1165565252304077e+00
    phi[2,1]  R1025     -9.5106318593025208e-02
    phi[2,1]  R1026     5.5066192150115967e-01
    phi[2,1]  R1027     4.1080260276794434e-01
    phi[2,1]  R1028     1.3418530225753784e+00
    phi[2,1]  R1029     -2.7474288940429688e+00
    phi[2,1]  R1030     -2.0025949925184250e-04
    phi[2,1]  R1031     -1.4305970668792725e+00
    phi[2,1]  R1032     5.5264055728912354e-01
    phi[2,1]  R1033     -6.8360972404479980e-01
    phi[2,1]  R1034     -1.0948202610015869e+00
    phi[2,1]  R1035     -1.3564723730087280e+00
    phi[1,4]  R9        1
    phi[1,4]  R10       1
    phi[1,4]  R36       -1
    phi[1,4]  R1036     -3.0999999046325684e+00
    phi[1,4]  R1037     -3.0999999046325684e+00
    phi[1,4]  R1038     -2.2400000095367432e+00
    phi[1,4]  R1039     -2.2400000095367432e+00
    phi[1,4]  R1040     -3.0999999046325684e+00
    phi[1,4]  R1041     -3.0999999046325684e+00
    phi[1,4]  R1042     -2.5699999332427979e+00
    phi[1,4]  R1043     -2.5699999332427979e+00
    phi[1,4]  R1044     -3.0999999046325684e+00
    phi[1,4]  R1045     -3.0999999046325684e+00
    phi[1,4]  R1046     -2.0899999141693115e+00
    phi[1,4]  R1047     -2.0899999141693115e+00
    phi[1,4]  R1048     -3.0999999046325684e+00
    phi[1,4]  R1049     -3.0999999046325684e+00
    phi[1,4]  R1050     1.0953590869903564e+00
    phi[1,4]  R1051     1.0949059724807739e+00
    phi[1,4]  R1052     3.2336792349815369e-01
    phi[1,4]  R1053     2.4676816165447235e-01
    phi[1,4]  R1054     -1.0653502941131592e+00
    phi[1,4]  R1055     -2.0282294750213623e+00
    phi[1,4]  R1056     1.0122755765914917e+00
    phi[1,4]  R1057     -3.8481515645980835e-01
    phi[1,4]  R1058     -1.1844459772109985e+00
    phi[1,4]  R1059     -1.2625811100006104e+00
    phi[1,4]  R1060     -2.0794820785522461e+00
    phi[1,4]  R1061     -1.9246559143066406e+00
    phi[1,4]  R1062     -8.9861404895782471e-01
    phi[1,4]  R1063     -2.23384428024292
    phi[1,4]  R1064     -9.3556308746337891e-01
    phi[1,4]  R1065     1.1689919233322144e+00
    phi[1,4]  R1066     -2.8804833889007568e+00
    phi[1,4]  R1067     -1.6614713668823242e+00
    phi[1,4]  R1068     5.5326007306575775e-02
    phi[1,4]  R1069     -1.3306286334991455e+00
    phi[1,4]  R1070     -1.0094625949859619e+00
    phi[1,4]  R1071     -2.5318114757537842e+00
    phi[1,4]  R1072     1.4510639905929565e+00
    phi[1,4]  R1073     -3.0313420295715332e+00
    phi[1,4]  R1074     -1.8906174898147583e+00
    phi[1,4]  R1075     -2.6267926692962646e+00
    phi[1,4]  R1076     -3.4027280807495117e+00
    phi[1,4]  R1077     -9.0056687593460083e-02
    phi[1,4]  R1078     -1.1165565252304077e+00
    phi[1,4]  R1079     -9.5106318593025208e-02
    phi[1,4]  R1080     5.5066192150115967e-01
    phi[1,4]  R1081     4.1080260276794434e-01
    phi[1,4]  R1082     1.3418530225753784e+00
    phi[1,4]  R1083     -2.7474288940429688e+00
    phi[1,4]  R1084     -2.0025949925184250e-04
    phi[1,4]  R1085     -1.4305970668792725e+00
    phi[1,4]  R1086     5.5264055728912354e-01
    phi[1,4]  R1087     -6.8360972404479980e-01
    phi[1,4]  R1088     -1.0948202610015869e+00
    phi[1,4]  R1089     -1.3564723730087280e+00
    phi[1,4]  R1090     1.0409893989562988e+00
    phi[1,4]  R1091     3.12511944770813
    phi[1,4]  R1092     2.2121331691741943e+00
    phi[1,4]  R1093     2.4603700637817383e+00
    phi[1,4]  R1094     2.8742768764495850e+00
    phi[1,4]  R1095     1.7729644775390625e+00
    phi[1,4]  R1096     2.6363046169281006e+00
    phi[1,4]  R1097     3.3461880683898926e+00
    phi[1,4]  R1098     3.1400470733642578e+00
    phi[1,4]  R1099     2.1398820877075195e+00
    phi[1,4]  R1100     1.4088853597640991e+00
    phi[1,4]  R1101     -1.8469457626342773e+00
    phi[1,4]  R1102     -1.9318068027496338e+00
    phi[1,4]  R1103     -3.1918501853942871e-01
    phi[1,4]  R1104     -3.5772633552551270e-01
    phi[1,4]  R1105     9.4723916053771973e-01
    phi[1,4]  R1106     -2.7779671549797058e-01
    phi[1,4]  R1107     -4.1765800118446350e-01
    phi[1,4]  R1108     -1.5578038692474365e+00
    phi[1,4]  R1109     -9.8187726736068726e-01
    phi[1,4]  R1110     2.4526591598987579e-01
    phi[1,4]  R1111     -6.5786713361740112e-01
    phi[1,4]  R1112     -1.4257522821426392e+00
    phi[1,4]  R1113     -8.0545246601104736e-01
    phi[1,4]  R1114     8.1633490324020386e-01
    phi[1,4]  R1115     -2.4227447509765625e+00
    phi[1,4]  R1116     -2.3991665840148926e+00
    phi[1,4]  R1117     -1.3566262722015381e+00
    phi[1,4]  R1118     -1.5960556268692017e+00
    phi[1,4]  R1119     -2.28151273727417
    phi[1,4]  R1120     4.3044766783714294e-01
    phi[1,4]  R1121     6.4302825927734375e-01
    phi[1,4]  R1122     7.4261862039566040e-01
    phi[1,4]  R1123     -2.4349112510681152e+00
    phi[1,4]  R1124     6.1484597623348236e-02
    phi[1,4]  R1125     8.4120386838912964e-01
    phi[1,4]  R1126     1.6435261964797974e+00
    phi[1,4]  R1127     -2.0030975341796875e+00
    phi[1,4]  R1128     -7.3184430599212646e-01
    phi[1,4]  R1129     -1.2200669199228287e-01
    phi[4,1]  R9        -1
    phi[4,1]  R36       1
    phi[4,1]  R37       1
    phi[4,1]  R1130     -3.0999999046325684e+00
    phi[4,1]  R1131     -3.0999999046325684e+00
    phi[4,1]  R1132     -2.2400000095367432e+00
    phi[4,1]  R1133     -2.2400000095367432e+00
    phi[4,1]  R1134     -3.0999999046325684e+00
    phi[4,1]  R1135     -3.0999999046325684e+00
    phi[4,1]  R1136     -2.5699999332427979e+00
    phi[4,1]  R1137     -2.5699999332427979e+00
    phi[4,1]  R1138     -3.0999999046325684e+00
    phi[4,1]  R1139     -3.0999999046325684e+00
    phi[4,1]  R1140     -2.0899999141693115e+00
    phi[4,1]  R1141     -2.0899999141693115e+00
    phi[4,1]  R1142     -3.0999999046325684e+00
    phi[4,1]  R1143     -3.0999999046325684e+00
    phi[4,1]  R1144     1.0409893989562988e+00
    phi[4,1]  R1145     3.12511944770813
    phi[4,1]  R1146     2.2121331691741943e+00
    phi[4,1]  R1147     2.4603700637817383e+00
    phi[4,1]  R1148     2.8742768764495850e+00
    phi[4,1]  R1149     1.7729644775390625e+00
    phi[4,1]  R1150     2.6363046169281006e+00
    phi[4,1]  R1151     3.3461880683898926e+00
    phi[4,1]  R1152     3.1400470733642578e+00
    phi[4,1]  R1153     2.1398820877075195e+00
    phi[4,1]  R1154     1.4088853597640991e+00
    phi[4,1]  R1155     -1.8469457626342773e+00
    phi[4,1]  R1156     -1.9318068027496338e+00
    phi[4,1]  R1157     -3.1918501853942871e-01
    phi[4,1]  R1158     -3.5772633552551270e-01
    phi[4,1]  R1159     9.4723916053771973e-01
    phi[4,1]  R1160     -2.7779671549797058e-01
    phi[4,1]  R1161     -4.1765800118446350e-01
    phi[4,1]  R1162     -1.5578038692474365e+00
    phi[4,1]  R1163     -9.8187726736068726e-01
    phi[4,1]  R1164     2.4526591598987579e-01
    phi[4,1]  R1165     -6.5786713361740112e-01
    phi[4,1]  R1166     -1.4257522821426392e+00
    phi[4,1]  R1167     -8.0545246601104736e-01
    phi[4,1]  R1168     8.1633490324020386e-01
    phi[4,1]  R1169     -2.4227447509765625e+00
    phi[4,1]  R1170     -2.3991665840148926e+00
    phi[4,1]  R1171     -1.3566262722015381e+00
    phi[4,1]  R1172     -1.5960556268692017e+00
    phi[4,1]  R1173     -2.28151273727417
    phi[4,1]  R1174     4.3044766783714294e-01
    phi[4,1]  R1175     6.4302825927734375e-01
    phi[4,1]  R1176     7.4261862039566040e-01
    phi[4,1]  R1177     -2.4349112510681152e+00
    phi[4,1]  R1178     6.1484597623348236e-02
    phi[4,1]  R1179     8.4120386838912964e-01
    phi[4,1]  R1180     1.6435261964797974e+00
    phi[4,1]  R1181     -2.0030975341796875e+00
    phi[4,1]  R1182     -7.3184430599212646e-01
    phi[4,1]  R1183     -1.2200669199228287e-01
    phi[4,1]  R1184     1.0953590869903564e+00
    phi[4,1]  R1185     1.0949059724807739e+00
    phi[4,1]  R1186     3.2336792349815369e-01
    phi[4,1]  R1187     2.4676816165447235e-01
    phi[4,1]  R1188     -1.0653502941131592e+00
    phi[4,1]  R1189     -2.0282294750213623e+00
    phi[4,1]  R1190     1.0122755765914917e+00
    phi[4,1]  R1191     -3.8481515645980835e-01
    phi[4,1]  R1192     -1.1844459772109985e+00
    phi[4,1]  R1193     -1.2625811100006104e+00
    phi[4,1]  R1194     -2.0794820785522461e+00
    phi[4,1]  R1195     -1.9246559143066406e+00
    phi[4,1]  R1196     -8.9861404895782471e-01
    phi[4,1]  R1197     -2.23384428024292
    phi[4,1]  R1198     -9.3556308746337891e-01
    phi[4,1]  R1199     1.1689919233322144e+00
    phi[4,1]  R1200     -2.8804833889007568e+00
    phi[4,1]  R1201     -1.6614713668823242e+00
    phi[4,1]  R1202     5.5326007306575775e-02
    phi[4,1]  R1203     -1.3306286334991455e+00
    phi[4,1]  R1204     -1.0094625949859619e+00
    phi[4,1]  R1205     -2.5318114757537842e+00
    phi[4,1]  R1206     1.4510639905929565e+00
    phi[4,1]  R1207     -3.0313420295715332e+00
    phi[4,1]  R1208     -1.8906174898147583e+00
    phi[4,1]  R1209     -2.6267926692962646e+00
    phi[4,1]  R1210     -3.4027280807495117e+00
    phi[4,1]  R1211     -9.0056687593460083e-02
    phi[4,1]  R1212     -1.1165565252304077e+00
    phi[4,1]  R1213     -9.5106318593025208e-02
    phi[4,1]  R1214     5.5066192150115967e-01
    phi[4,1]  R1215     4.1080260276794434e-01
    phi[4,1]  R1216     1.3418530225753784e+00
    phi[4,1]  R1217     -2.7474288940429688e+00
    phi[4,1]  R1218     -2.0025949925184250e-04
    phi[4,1]  R1219     -1.4305970668792725e+00
    phi[4,1]  R1220     5.5264055728912354e-01
    phi[4,1]  R1221     -6.8360972404479980e-01
    phi[4,1]  R1222     -1.0948202610015869e+00
    phi[4,1]  R1223     -1.3564723730087280e+00
    phi[1,5]  R9        1
    phi[1,5]  R10       1
    phi[1,5]  R45       -1
    phi[1,5]  R1224     -3.0999999046325684e+00
    phi[1,5]  R1225     -3.0999999046325684e+00
    phi[1,5]  R1226     -2.2400000095367432e+00
    phi[1,5]  R1227     -2.2400000095367432e+00
    phi[1,5]  R1228     -3.0999999046325684e+00
    phi[1,5]  R1229     -3.0999999046325684e+00
    phi[1,5]  R1230     -2.5699999332427979e+00
    phi[1,5]  R1231     -2.5699999332427979e+00
    phi[1,5]  R1232     -3.0999999046325684e+00
    phi[1,5]  R1233     -3.0999999046325684e+00
    phi[1,5]  R1234     -2.0899999141693115e+00
    phi[1,5]  R1235     -2.0899999141693115e+00
    phi[1,5]  R1236     -3.0999999046325684e+00
    phi[1,5]  R1237     -3.0999999046325684e+00
    phi[1,5]  R1238     1.0953590869903564e+00
    phi[1,5]  R1239     1.0949059724807739e+00
    phi[1,5]  R1240     3.2336792349815369e-01
    phi[1,5]  R1241     2.4676816165447235e-01
    phi[1,5]  R1242     -1.0653502941131592e+00
    phi[1,5]  R1243     -2.0282294750213623e+00
    phi[1,5]  R1244     1.0122755765914917e+00
    phi[1,5]  R1245     -3.8481515645980835e-01
    phi[1,5]  R1246     -1.1844459772109985e+00
    phi[1,5]  R1247     -1.2625811100006104e+00
    phi[1,5]  R1248     -2.0794820785522461e+00
    phi[1,5]  R1249     -1.9246559143066406e+00
    phi[1,5]  R1250     -8.9861404895782471e-01
    phi[1,5]  R1251     -2.23384428024292
    phi[1,5]  R1252     -9.3556308746337891e-01
    phi[1,5]  R1253     1.1689919233322144e+00
    phi[1,5]  R1254     -2.8804833889007568e+00
    phi[1,5]  R1255     -1.6614713668823242e+00
    phi[1,5]  R1256     5.5326007306575775e-02
    phi[1,5]  R1257     -1.3306286334991455e+00
    phi[1,5]  R1258     -1.0094625949859619e+00
    phi[1,5]  R1259     -2.5318114757537842e+00
    phi[1,5]  R1260     1.4510639905929565e+00
    phi[1,5]  R1261     -3.0313420295715332e+00
    phi[1,5]  R1262     -1.8906174898147583e+00
    phi[1,5]  R1263     -2.6267926692962646e+00
    phi[1,5]  R1264     -3.4027280807495117e+00
    phi[1,5]  R1265     -9.0056687593460083e-02
    phi[1,5]  R1266     -1.1165565252304077e+00
    phi[1,5]  R1267     -9.5106318593025208e-02
    phi[1,5]  R1268     5.5066192150115967e-01
    phi[1,5]  R1269     4.1080260276794434e-01
    phi[1,5]  R1270     1.3418530225753784e+00
    phi[1,5]  R1271     -2.7474288940429688e+00
    phi[1,5]  R1272     -2.0025949925184250e-04
    phi[1,5]  R1273     -1.4305970668792725e+00
    phi[1,5]  R1274     5.5264055728912354e-01
    phi[1,5]  R1275     -6.8360972404479980e-01
    phi[1,5]  R1276     -1.0948202610015869e+00
    phi[1,5]  R1277     -1.3564723730087280e+00
    phi[1,5]  R1278     1.9300042390823364e+00
    phi[1,5]  R1279     7.4363201856613159e-01
    phi[1,5]  R1280     7.5290125608444214e-01
    phi[1,5]  R1281     8.8865995407104492e-01
    phi[1,5]  R1282     1.8823522329330444e+00
    phi[1,5]  R1283     2.8884959220886230e-01
    phi[1,5]  R1284     6.1533157713711262e-03
    phi[1,5]  R1285     -1.3884544372558594e+00
    phi[1,5]  R1286     -1.1666467189788818e+00
    phi[1,5]  R1287     -2.3745880126953125e+00
    phi[1,5]  R1288     -2.6544380187988281e+00
    phi[1,5]  R1289     -3.3787441253662109e+00
    phi[1,5]  R1290     -1.2786622047424316e+00
    phi[1,5]  R1291     -1.7446815967559814e+00
    phi[1,5]  R1292     -1.1144081354141235e+00
    phi[1,5]  R1293     -1.3227696418762207e+00
    phi[1,5]  R1294     -7.0742154121398926e-01
    phi[1,5]  R1295     -1.3913764953613281e+00
    phi[5,1]  R9        -1
    phi[5,1]  R45       1
    phi[5,1]  R46       1
    phi[5,1]  R1296     -3.0999999046325684e+00
    phi[5,1]  R1297     -3.0999999046325684e+00
    phi[5,1]  R1298     -2.2400000095367432e+00
    phi[5,1]  R1299     -2.2400000095367432e+00
    phi[5,1]  R1300     -3.0999999046325684e+00
    phi[5,1]  R1301     -3.0999999046325684e+00
    phi[5,1]  R1302     -2.5699999332427979e+00
    phi[5,1]  R1303     -2.5699999332427979e+00
    phi[5,1]  R1304     -3.0999999046325684e+00
    phi[5,1]  R1305     -3.0999999046325684e+00
    phi[5,1]  R1306     -2.0899999141693115e+00
    phi[5,1]  R1307     -2.0899999141693115e+00
    phi[5,1]  R1308     -3.0999999046325684e+00
    phi[5,1]  R1309     -3.0999999046325684e+00
    phi[5,1]  R1310     1.9300042390823364e+00
    phi[5,1]  R1311     7.4363201856613159e-01
    phi[5,1]  R1312     7.5290125608444214e-01
    phi[5,1]  R1313     8.8865995407104492e-01
    phi[5,1]  R1314     1.8823522329330444e+00
    phi[5,1]  R1315     2.8884959220886230e-01
    phi[5,1]  R1316     6.1533157713711262e-03
    phi[5,1]  R1317     -1.3884544372558594e+00
    phi[5,1]  R1318     -1.1666467189788818e+00
    phi[5,1]  R1319     -2.3745880126953125e+00
    phi[5,1]  R1320     -2.6544380187988281e+00
    phi[5,1]  R1321     -3.3787441253662109e+00
    phi[5,1]  R1322     -1.2786622047424316e+00
    phi[5,1]  R1323     -1.7446815967559814e+00
    phi[5,1]  R1324     -1.1144081354141235e+00
    phi[5,1]  R1325     -1.3227696418762207e+00
    phi[5,1]  R1326     -7.0742154121398926e-01
    phi[5,1]  R1327     -1.3913764953613281e+00
    phi[5,1]  R1328     1.0953590869903564e+00
    phi[5,1]  R1329     1.0949059724807739e+00
    phi[5,1]  R1330     3.2336792349815369e-01
    phi[5,1]  R1331     2.4676816165447235e-01
    phi[5,1]  R1332     -1.0653502941131592e+00
    phi[5,1]  R1333     -2.0282294750213623e+00
    phi[5,1]  R1334     1.0122755765914917e+00
    phi[5,1]  R1335     -3.8481515645980835e-01
    phi[5,1]  R1336     -1.1844459772109985e+00
    phi[5,1]  R1337     -1.2625811100006104e+00
    phi[5,1]  R1338     -2.0794820785522461e+00
    phi[5,1]  R1339     -1.9246559143066406e+00
    phi[5,1]  R1340     -8.9861404895782471e-01
    phi[5,1]  R1341     -2.23384428024292
    phi[5,1]  R1342     -9.3556308746337891e-01
    phi[5,1]  R1343     1.1689919233322144e+00
    phi[5,1]  R1344     -2.8804833889007568e+00
    phi[5,1]  R1345     -1.6614713668823242e+00
    phi[5,1]  R1346     5.5326007306575775e-02
    phi[5,1]  R1347     -1.3306286334991455e+00
    phi[5,1]  R1348     -1.0094625949859619e+00
    phi[5,1]  R1349     -2.5318114757537842e+00
    phi[5,1]  R1350     1.4510639905929565e+00
    phi[5,1]  R1351     -3.0313420295715332e+00
    phi[5,1]  R1352     -1.8906174898147583e+00
    phi[5,1]  R1353     -2.6267926692962646e+00
    phi[5,1]  R1354     -3.4027280807495117e+00
    phi[5,1]  R1355     -9.0056687593460083e-02
    phi[5,1]  R1356     -1.1165565252304077e+00
    phi[5,1]  R1357     -9.5106318593025208e-02
    phi[5,1]  R1358     5.5066192150115967e-01
    phi[5,1]  R1359     4.1080260276794434e-01
    phi[5,1]  R1360     1.3418530225753784e+00
    phi[5,1]  R1361     -2.7474288940429688e+00
    phi[5,1]  R1362     -2.0025949925184250e-04
    phi[5,1]  R1363     -1.4305970668792725e+00
    phi[5,1]  R1364     5.5264055728912354e-01
    phi[5,1]  R1365     -6.8360972404479980e-01
    phi[5,1]  R1366     -1.0948202610015869e+00
    phi[5,1]  R1367     -1.3564723730087280e+00
    phi[2,3]  R18       1
    phi[2,3]  R19       1
    phi[2,3]  R27       -1
    phi[2,3]  R1368     -3.0999999046325684e+00
    phi[2,3]  R1369     -3.0999999046325684e+00
    phi[2,3]  R1370     -2.2400000095367432e+00
    phi[2,3]  R1371     -2.2400000095367432e+00
    phi[2,3]  R1372     -3.0999999046325684e+00
    phi[2,3]  R1373     -3.0999999046325684e+00
    phi[2,3]  R1374     -2.5699999332427979e+00
    phi[2,3]  R1375     -2.5699999332427979e+00
    phi[2,3]  R1376     -3.0999999046325684e+00
    phi[2,3]  R1377     -3.0999999046325684e+00
    phi[2,3]  R1378     -2.0899999141693115e+00
    phi[2,3]  R1379     -2.0899999141693115e+00
    phi[2,3]  R1380     -3.0999999046325684e+00
    phi[2,3]  R1381     -3.0999999046325684e+00
    phi[2,3]  R1382     -0.639030933380127
    phi[2,3]  R1383     1.9622149467468262e+00
    phi[2,3]  R1384     8.6084157228469849e-01
    phi[2,3]  R1385     1.9289108514785767e+00
    phi[2,3]  R1386     1.1251482963562012e+00
    phi[2,3]  R1387     -2.8704500198364258e-01
    phi[2,3]  R1388     1.1227023601531982e+00
    phi[2,3]  R1389     3.7896066904067993e-01
    phi[2,3]  R1390     -3.2580140233039856e-01
    phi[2,3]  R1391     5.7166717946529388e-02
    phi[2,3]  R1392     -1.2111747264862061e+00
    phi[2,3]  R1393     -1.5875182151794434e+00
    phi[2,3]  R1394     -1.8528891801834106e+00
    phi[2,3]  R1395     -1.8588619232177734e+00
    phi[2,3]  R1396     -2.5788536071777344e+00
    phi[2,3]  R1397     -9.7165119647979736e-01
    phi[2,3]  R1398     -6.6313332319259644e-01
    phi[2,3]  R1399     -1.5588051080703735e+00
    phi[2,3]  R1400     -5.0865840911865234e-01
    phi[2,3]  R1401     -1.8580968379974365e+00
    phi[2,3]  R1402     4.8742389678955078e-01
    phi[2,3]  R1403     -2.5861542224884033e+00
    phi[2,3]  R1404     -1.6427432298660278e+00
    phi[2,3]  R1405     -0.337889701128006
    phi[2,3]  R1406     -7.3016655445098877e-01
    phi[2,3]  R1407     -1.4531118869781494e+00
    phi[2,3]  R1408     -1.5581912994384766e+00
    phi[2,3]  R1409     1.0206624269485474e+00
    phi[2,3]  R1410     -1.9672541618347168e+00
    phi[2,3]  R1411     -0.761530876159668
    phi[2,3]  R1412     -1.5252308845520020e+00
    phi[2,3]  R1413     -6.9365328550338745e-01
    phi[2,3]  R1414     1.9604235887527466e+00
    phi[2,3]  R1415     -6.0929852724075317e-01
    phi[2,3]  R1416     -9.7290998697280884e-01
    phi[2,3]  R1417     1.0316015481948853e+00
    phi[2,3]  R1418     4.8142120242118835e-01
    phi[2,3]  R1419     7.7350193262100220e-01
    phi[2,3]  R1420     8.1951344013214111e-01
    phi[2,3]  R1421     -2.2848446369171143e+00
    phi[2,3]  R1422     1.2338868379592896e+00
    phi[2,3]  R1423     1.5070356130599976e+00
    phi[2,3]  R1424     -1.4971580505371094e+00
    phi[2,3]  R1425     -5.3001278638839722e-01
    phi[2,3]  R1426     -9.8340988159179688e-01
    phi[2,3]  R1427     1.1091046333312988e+00
    phi[2,3]  R1428     7.5640785694122314e-01
    phi[2,3]  R1429     5.7240372896194458e-01
    phi[2,3]  R1430     -2.7329878807067871e+00
    phi[2,3]  R1431     2.5290653705596924e+00
    phi[2,3]  R1432     4.9952107667922974e-01
    phi[2,3]  R1433     -1.6742812395095825e+00
    phi[2,3]  R1434     -1.9607321023941040e+00
    phi[2,3]  R1435     2.2819032669067383e+00
    phi[2,3]  R1436     1.6397927999496460e+00
    phi[2,3]  R1437     -9.2800593376159668e-01
    phi[2,3]  R1438     2.9060785770416260e+00
    phi[2,3]  R1439     2.0339558124542236e+00
    phi[2,3]  R1440     2.8528702259063721e-01
    phi[2,3]  R1441     -6.5872468054294586e-02
    phi[2,3]  R1442     -1.6112822294235229e+00
    phi[2,3]  R1443     -1.3321362733840942e+00
    phi[2,3]  R1444     2.2171361446380615e+00
    phi[2,3]  R1445     -9.3284922838211060e-01
    phi[2,3]  R1446     0.253875195980072
    phi[2,3]  R1447     2.2718071937561035e-01
    phi[2,3]  R1448     -1.6169983148574829e+00
    phi[2,3]  R1449     -1.6760454177856445e+00
    phi[2,3]  R1450     -1.8260077238082886e+00
    phi[2,3]  R1451     -1.7918407917022705e+00
    phi[2,3]  R1452     2.4432432651519775e+00
    phi[2,3]  R1453     2.2006754875183105e+00
    phi[2,3]  R1454     1.3037314414978027e+00
    phi[2,3]  R1455     1.5777359008789062e+00
    phi[2,3]  R1456     1.9859349727630615e+00
    phi[2,3]  R1457     2.1674926280975342e+00
    phi[2,3]  R1458     1.1561129093170166e+00
    phi[2,3]  R1459     3.0700811743736267e-01
    phi[2,3]  R1460     1.9597383737564087e+00
    phi[2,3]  R1461     -6.9506055116653442e-01
    phi[2,3]  R1462     -1.3423196077346802e+00
    phi[2,3]  R1463     -2.3788456916809082e+00
    phi[2,3]  R1464     -1.6323411464691162e+00
    phi[2,3]  R1465     -1.6086171865463257e+00
    phi[2,3]  R1466     -3.0121240615844727e+00
    phi[2,3]  R1467     -6.9623184204101562e-01
    phi[2,3]  R1468     -2.7135293483734131e+00
    phi[2,3]  R1469     2.8936722874641418e-01
    phi[2,3]  R1470     -1.2509827315807343e-01
    phi[2,3]  R1471     -4.8329296708106995e-01
    phi[2,3]  R1472     0.301330029964447
    phi[2,3]  R1473     -1.3317170143127441e+00
    phi[2,3]  R1474     -1.3082293272018433e+00
    phi[2,3]  R1475     1.1023093461990356e+00
    phi[2,3]  R1476     -6.0125136375427246e-01
    phi[2,3]  R1477     1.3480714559555054e+00
    phi[2,3]  R1478     -9.4166636466979980e-01
    phi[2,3]  R1479     0.539718747138977
    phi[2,3]  R1480     1.3057625293731689e+00
    phi[2,3]  R1481     1.3341449499130249e+00
    phi[2,3]  R1482     -4.7819700837135315e-01
    phi[2,3]  R1483     2.1048738956451416e+00
    phi[2,3]  R1484     2.2620997428894043e+00
    phi[2,3]  R1485     3.3220097422599792e-01
    phi[2,3]  R1486     6.1972582340240479e-01
    phi[2,3]  R1487     8.6876475811004639e-01
    phi[2,3]  R1488     -1.1355627775192261e+00
    phi[2,3]  R1489     -1.4717340469360352e+00
    phi[2,3]  R1490     -5.5237036943435669e-01
    phi[2,3]  R1491     2.3153524398803711e+00
    phi[2,3]  R1492     5.5375564098358154e-01
    phi[2,3]  R1493     9.4974571466445923e-01
    phi[2,3]  R1494     1.4389872550964355e+00
    phi[2,3]  R1495     2.6158072948455811e+00
    phi[2,3]  R1496     -4.5568060874938965e-01
    phi[2,3]  R1497     -2.3821408748626709e+00
    phi[2,3]  R1498     -9.4991987943649292e-01
    phi[2,3]  R1499     -4.3962943553924561e-01
    phi[2,3]  R1500     1.8360754847526550e-01
    phi[2,3]  R1501     6.8203949928283691e-01
    phi[3,2]  R18       -1
    phi[3,2]  R27       1
    phi[3,2]  R28       1
    phi[3,2]  R1502     -3.0999999046325684e+00
    phi[3,2]  R1503     -3.0999999046325684e+00
    phi[3,2]  R1504     -2.2400000095367432e+00
    phi[3,2]  R1505     -2.2400000095367432e+00
    phi[3,2]  R1506     -3.0999999046325684e+00
    phi[3,2]  R1507     -3.0999999046325684e+00
    phi[3,2]  R1508     -2.5699999332427979e+00
    phi[3,2]  R1509     -2.5699999332427979e+00
    phi[3,2]  R1510     -3.0999999046325684e+00
    phi[3,2]  R1511     -3.0999999046325684e+00
    phi[3,2]  R1512     -2.0899999141693115e+00
    phi[3,2]  R1513     -2.0899999141693115e+00
    phi[3,2]  R1514     -3.0999999046325684e+00
    phi[3,2]  R1515     -3.0999999046325684e+00
    phi[3,2]  R1516     2.4432432651519775e+00
    phi[3,2]  R1517     2.2006754875183105e+00
    phi[3,2]  R1518     1.3037314414978027e+00
    phi[3,2]  R1519     1.5777359008789062e+00
    phi[3,2]  R1520     1.9859349727630615e+00
    phi[3,2]  R1521     2.1674926280975342e+00
    phi[3,2]  R1522     1.1561129093170166e+00
    phi[3,2]  R1523     3.0700811743736267e-01
    phi[3,2]  R1524     1.9597383737564087e+00
    phi[3,2]  R1525     -6.9506055116653442e-01
    phi[3,2]  R1526     -1.3423196077346802e+00
    phi[3,2]  R1527     -2.3788456916809082e+00
    phi[3,2]  R1528     -1.6323411464691162e+00
    phi[3,2]  R1529     -1.6086171865463257e+00
    phi[3,2]  R1530     -3.0121240615844727e+00
    phi[3,2]  R1531     -6.9623184204101562e-01
    phi[3,2]  R1532     -2.7135293483734131e+00
    phi[3,2]  R1533     2.8936722874641418e-01
    phi[3,2]  R1534     -1.2509827315807343e-01
    phi[3,2]  R1535     -4.8329296708106995e-01
    phi[3,2]  R1536     0.301330029964447
    phi[3,2]  R1537     -1.3317170143127441e+00
    phi[3,2]  R1538     -1.3082293272018433e+00
    phi[3,2]  R1539     1.1023093461990356e+00
    phi[3,2]  R1540     -6.0125136375427246e-01
    phi[3,2]  R1541     1.3480714559555054e+00
    phi[3,2]  R1542     -9.4166636466979980e-01
    phi[3,2]  R1543     0.539718747138977
    phi[3,2]  R1544     1.3057625293731689e+00
    phi[3,2]  R1545     1.3341449499130249e+00
    phi[3,2]  R1546     -4.7819700837135315e-01
    phi[3,2]  R1547     2.1048738956451416e+00
    phi[3,2]  R1548     2.2620997428894043e+00
    phi[3,2]  R1549     3.3220097422599792e-01
    phi[3,2]  R1550     6.1972582340240479e-01
    phi[3,2]  R1551     8.6876475811004639e-01
    phi[3,2]  R1552     -1.1355627775192261e+00
    phi[3,2]  R1553     -1.4717340469360352e+00
    phi[3,2]  R1554     -5.5237036943435669e-01
    phi[3,2]  R1555     2.3153524398803711e+00
    phi[3,2]  R1556     5.5375564098358154e-01
    phi[3,2]  R1557     9.4974571466445923e-01
    phi[3,2]  R1558     1.4389872550964355e+00
    phi[3,2]  R1559     2.6158072948455811e+00
    phi[3,2]  R1560     -4.5568060874938965e-01
    phi[3,2]  R1561     -2.3821408748626709e+00
    phi[3,2]  R1562     -9.4991987943649292e-01
    phi[3,2]  R1563     -4.3962943553924561e-01
    phi[3,2]  R1564     1.8360754847526550e-01
    phi[3,2]  R1565     6.8203949928283691e-01
    phi[3,2]  R1566     -0.639030933380127
    phi[3,2]  R1567     1.9622149467468262e+00
    phi[3,2]  R1568     8.6084157228469849e-01
    phi[3,2]  R1569     1.9289108514785767e+00
    phi[3,2]  R1570     1.1251482963562012e+00
    phi[3,2]  R1571     -2.8704500198364258e-01
    phi[3,2]  R1572     1.1227023601531982e+00
    phi[3,2]  R1573     3.7896066904067993e-01
    phi[3,2]  R1574     -3.2580140233039856e-01
    phi[3,2]  R1575     5.7166717946529388e-02
    phi[3,2]  R1576     -1.2111747264862061e+00
    phi[3,2]  R1577     -1.5875182151794434e+00
    phi[3,2]  R1578     -1.8528891801834106e+00
    phi[3,2]  R1579     -1.8588619232177734e+00
    phi[3,2]  R1580     -2.5788536071777344e+00
    phi[3,2]  R1581     -9.7165119647979736e-01
    phi[3,2]  R1582     -6.6313332319259644e-01
    phi[3,2]  R1583     -1.5588051080703735e+00
    phi[3,2]  R1584     -5.0865840911865234e-01
    phi[3,2]  R1585     -1.8580968379974365e+00
    phi[3,2]  R1586     4.8742389678955078e-01
    phi[3,2]  R1587     -2.5861542224884033e+00
    phi[3,2]  R1588     -1.6427432298660278e+00
    phi[3,2]  R1589     -0.337889701128006
    phi[3,2]  R1590     -7.3016655445098877e-01
    phi[3,2]  R1591     -1.4531118869781494e+00
    phi[3,2]  R1592     -1.5581912994384766e+00
    phi[3,2]  R1593     1.0206624269485474e+00
    phi[3,2]  R1594     -1.9672541618347168e+00
    phi[3,2]  R1595     -0.761530876159668
    phi[3,2]  R1596     -1.5252308845520020e+00
    phi[3,2]  R1597     -6.9365328550338745e-01
    phi[3,2]  R1598     1.9604235887527466e+00
    phi[3,2]  R1599     -6.0929852724075317e-01
    phi[3,2]  R1600     -9.7290998697280884e-01
    phi[3,2]  R1601     1.0316015481948853e+00
    phi[3,2]  R1602     4.8142120242118835e-01
    phi[3,2]  R1603     7.7350193262100220e-01
    phi[3,2]  R1604     8.1951344013214111e-01
    phi[3,2]  R1605     -2.2848446369171143e+00
    phi[3,2]  R1606     1.2338868379592896e+00
    phi[3,2]  R1607     1.5070356130599976e+00
    phi[3,2]  R1608     -1.4971580505371094e+00
    phi[3,2]  R1609     -5.3001278638839722e-01
    phi[3,2]  R1610     -9.8340988159179688e-01
    phi[3,2]  R1611     1.1091046333312988e+00
    phi[3,2]  R1612     7.5640785694122314e-01
    phi[3,2]  R1613     5.7240372896194458e-01
    phi[3,2]  R1614     -2.7329878807067871e+00
    phi[3,2]  R1615     2.5290653705596924e+00
    phi[3,2]  R1616     4.9952107667922974e-01
    phi[3,2]  R1617     -1.6742812395095825e+00
    phi[3,2]  R1618     -1.9607321023941040e+00
    phi[3,2]  R1619     2.2819032669067383e+00
    phi[3,2]  R1620     1.6397927999496460e+00
    phi[3,2]  R1621     -9.2800593376159668e-01
    phi[3,2]  R1622     2.9060785770416260e+00
    phi[3,2]  R1623     2.0339558124542236e+00
    phi[3,2]  R1624     2.8528702259063721e-01
    phi[3,2]  R1625     -6.5872468054294586e-02
    phi[3,2]  R1626     -1.6112822294235229e+00
    phi[3,2]  R1627     -1.3321362733840942e+00
    phi[3,2]  R1628     2.2171361446380615e+00
    phi[3,2]  R1629     -9.3284922838211060e-01
    phi[3,2]  R1630     0.253875195980072
    phi[3,2]  R1631     2.2718071937561035e-01
    phi[3,2]  R1632     -1.6169983148574829e+00
    phi[3,2]  R1633     -1.6760454177856445e+00
    phi[3,2]  R1634     -1.8260077238082886e+00
    phi[3,2]  R1635     -1.7918407917022705e+00
    phi[3,7]  R27       1
    phi[3,7]  R28       1
    phi[3,7]  R63       -1
    phi[3,7]  R1636     -3.0999999046325684e+00
    phi[3,7]  R1637     -3.0999999046325684e+00
    phi[3,7]  R1638     -2.2400000095367432e+00
    phi[3,7]  R1639     -2.2400000095367432e+00
    phi[3,7]  R1640     -3.0999999046325684e+00
    phi[3,7]  R1641     -3.0999999046325684e+00
    phi[3,7]  R1642     -2.5699999332427979e+00
    phi[3,7]  R1643     -2.5699999332427979e+00
    phi[3,7]  R1644     -3.0999999046325684e+00
    phi[3,7]  R1645     -3.0999999046325684e+00
    phi[3,7]  R1646     -2.0899999141693115e+00
    phi[3,7]  R1647     -2.0899999141693115e+00
    phi[3,7]  R1648     -3.0999999046325684e+00
    phi[3,7]  R1649     -3.0999999046325684e+00
    phi[3,7]  R1650     2.4432432651519775e+00
    phi[3,7]  R1651     2.2006754875183105e+00
    phi[3,7]  R1652     1.3037314414978027e+00
    phi[3,7]  R1653     1.5777359008789062e+00
    phi[3,7]  R1654     1.9859349727630615e+00
    phi[3,7]  R1655     2.1674926280975342e+00
    phi[3,7]  R1656     1.1561129093170166e+00
    phi[3,7]  R1657     3.0700811743736267e-01
    phi[3,7]  R1658     1.9597383737564087e+00
    phi[3,7]  R1659     -6.9506055116653442e-01
    phi[3,7]  R1660     -1.3423196077346802e+00
    phi[3,7]  R1661     -2.3788456916809082e+00
    phi[3,7]  R1662     -1.6323411464691162e+00
    phi[3,7]  R1663     -1.6086171865463257e+00
    phi[3,7]  R1664     -3.0121240615844727e+00
    phi[3,7]  R1665     -6.9623184204101562e-01
    phi[3,7]  R1666     -2.7135293483734131e+00
    phi[3,7]  R1667     2.8936722874641418e-01
    phi[3,7]  R1668     -1.2509827315807343e-01
    phi[3,7]  R1669     -4.8329296708106995e-01
    phi[3,7]  R1670     0.301330029964447
    phi[3,7]  R1671     -1.3317170143127441e+00
    phi[3,7]  R1672     -1.3082293272018433e+00
    phi[3,7]  R1673     1.1023093461990356e+00
    phi[3,7]  R1674     -6.0125136375427246e-01
    phi[3,7]  R1675     1.3480714559555054e+00
    phi[3,7]  R1676     -9.4166636466979980e-01
    phi[3,7]  R1677     0.539718747138977
    phi[3,7]  R1678     1.3057625293731689e+00
    phi[3,7]  R1679     1.3341449499130249e+00
    phi[3,7]  R1680     -4.7819700837135315e-01
    phi[3,7]  R1681     2.1048738956451416e+00
    phi[3,7]  R1682     2.2620997428894043e+00
    phi[3,7]  R1683     3.3220097422599792e-01
    phi[3,7]  R1684     6.1972582340240479e-01
    phi[3,7]  R1685     8.6876475811004639e-01
    phi[3,7]  R1686     -1.1355627775192261e+00
    phi[3,7]  R1687     -1.4717340469360352e+00
    phi[3,7]  R1688     -5.5237036943435669e-01
    phi[3,7]  R1689     2.3153524398803711e+00
    phi[3,7]  R1690     5.5375564098358154e-01
    phi[3,7]  R1691     9.4974571466445923e-01
    phi[3,7]  R1692     1.4389872550964355e+00
    phi[3,7]  R1693     2.6158072948455811e+00
    phi[3,7]  R1694     -4.5568060874938965e-01
    phi[3,7]  R1695     -2.3821408748626709e+00
    phi[3,7]  R1696     -9.4991987943649292e-01
    phi[3,7]  R1697     -4.3962943553924561e-01
    phi[3,7]  R1698     1.8360754847526550e-01
    phi[3,7]  R1699     6.8203949928283691e-01
    phi[3,7]  R1700     -7.7624785900115967e-01
    phi[3,7]  R1701     0.286338746547699
    phi[3,7]  R1702     1.1432054042816162e+00
    phi[3,7]  R1703     9.4262385368347168e-01
    phi[3,7]  R1704     -4.5222994685173035e-01
    phi[3,7]  R1705     7.4979829788208008e-01
    phi[3,7]  R1706     1.1047372817993164e+00
    phi[3,7]  R1707     0.621229350566864
    phi[3,7]  R1708     1.7755998373031616e+00
    phi[3,7]  R1709     1.0287989377975464e+00
    phi[3,7]  R1710     -3.1104570627212524e-01
    phi[3,7]  R1711     -2.2868425846099854e+00
    phi[3,7]  R1712     -1.2517036199569702e+00
    phi[3,7]  R1713     -2.5400383472442627e+00
    phi[3,7]  R1714     1.1652899980545044e+00
    phi[3,7]  R1715     4.2673242092132568e-01
    phi[3,7]  R1716     1.6328843832015991e+00
    phi[3,7]  R1717     1.0937812328338623e+00
    phi[3,7]  R1718     1.2881648540496826e+00
    phi[3,7]  R1719     5.8761775493621826e-01
    phi[3,7]  R1720     -1.5248589515686035e+00
    phi[3,7]  R1721     -8.3783918619155884e-01
    phi[3,7]  R1722     5.5841177701950073e-01
    phi[3,7]  R1723     -2.5075094699859619e+00
    phi[3,7]  R1724     9.7332602739334106e-01
    phi[3,7]  R1725     7.4454230070114136e-01
    phi[3,7]  R1726     1.9657289981842041e-01
    phi[3,7]  R1727     0.0837339535355568
    phi[3,7]  R1728     2.0328288078308105e+00
    phi[3,7]  R1729     1.1393010616302490e+00
    phi[7,3]  R27       -1
    phi[7,3]  R63       1
    phi[7,3]  R64       1
    phi[7,3]  R1730     -3.0999999046325684e+00
    phi[7,3]  R1731     -3.0999999046325684e+00
    phi[7,3]  R1732     -2.2400000095367432e+00
    phi[7,3]  R1733     -2.2400000095367432e+00
    phi[7,3]  R1734     -3.0999999046325684e+00
    phi[7,3]  R1735     -3.0999999046325684e+00
    phi[7,3]  R1736     -2.5699999332427979e+00
    phi[7,3]  R1737     -2.5699999332427979e+00
    phi[7,3]  R1738     -3.0999999046325684e+00
    phi[7,3]  R1739     -3.0999999046325684e+00
    phi[7,3]  R1740     -2.0899999141693115e+00
    phi[7,3]  R1741     -2.0899999141693115e+00
    phi[7,3]  R1742     -3.0999999046325684e+00
    phi[7,3]  R1743     -3.0999999046325684e+00
    phi[7,3]  R1744     -7.7624785900115967e-01
    phi[7,3]  R1745     0.286338746547699
    phi[7,3]  R1746     1.1432054042816162e+00
    phi[7,3]  R1747     9.4262385368347168e-01
    phi[7,3]  R1748     -4.5222994685173035e-01
    phi[7,3]  R1749     7.4979829788208008e-01
    phi[7,3]  R1750     1.1047372817993164e+00
    phi[7,3]  R1751     0.621229350566864
    phi[7,3]  R1752     1.7755998373031616e+00
    phi[7,3]  R1753     1.0287989377975464e+00
    phi[7,3]  R1754     -3.1104570627212524e-01
    phi[7,3]  R1755     -2.2868425846099854e+00
    phi[7,3]  R1756     -1.2517036199569702e+00
    phi[7,3]  R1757     -2.5400383472442627e+00
    phi[7,3]  R1758     1.1652899980545044e+00
    phi[7,3]  R1759     4.2673242092132568e-01
    phi[7,3]  R1760     1.6328843832015991e+00
    phi[7,3]  R1761     1.0937812328338623e+00
    phi[7,3]  R1762     1.2881648540496826e+00
    phi[7,3]  R1763     5.8761775493621826e-01
    phi[7,3]  R1764     -1.5248589515686035e+00
    phi[7,3]  R1765     -8.3783918619155884e-01
    phi[7,3]  R1766     5.5841177701950073e-01
    phi[7,3]  R1767     -2.5075094699859619e+00
    phi[7,3]  R1768     9.7332602739334106e-01
    phi[7,3]  R1769     7.4454230070114136e-01
    phi[7,3]  R1770     1.9657289981842041e-01
    phi[7,3]  R1771     0.0837339535355568
    phi[7,3]  R1772     2.0328288078308105e+00
    phi[7,3]  R1773     1.1393010616302490e+00
    phi[7,3]  R1774     2.4432432651519775e+00
    phi[7,3]  R1775     2.2006754875183105e+00
    phi[7,3]  R1776     1.3037314414978027e+00
    phi[7,3]  R1777     1.5777359008789062e+00
    phi[7,3]  R1778     1.9859349727630615e+00
    phi[7,3]  R1779     2.1674926280975342e+00
    phi[7,3]  R1780     1.1561129093170166e+00
    phi[7,3]  R1781     3.0700811743736267e-01
    phi[7,3]  R1782     1.9597383737564087e+00
    phi[7,3]  R1783     -6.9506055116653442e-01
    phi[7,3]  R1784     -1.3423196077346802e+00
    phi[7,3]  R1785     -2.3788456916809082e+00
    phi[7,3]  R1786     -1.6323411464691162e+00
    phi[7,3]  R1787     -1.6086171865463257e+00
    phi[7,3]  R1788     -3.0121240615844727e+00
    phi[7,3]  R1789     -6.9623184204101562e-01
    phi[7,3]  R1790     -2.7135293483734131e+00
    phi[7,3]  R1791     2.8936722874641418e-01
    phi[7,3]  R1792     -1.2509827315807343e-01
    phi[7,3]  R1793     -4.8329296708106995e-01
    phi[7,3]  R1794     0.301330029964447
    phi[7,3]  R1795     -1.3317170143127441e+00
    phi[7,3]  R1796     -1.3082293272018433e+00
    phi[7,3]  R1797     1.1023093461990356e+00
    phi[7,3]  R1798     -6.0125136375427246e-01
    phi[7,3]  R1799     1.3480714559555054e+00
    phi[7,3]  R1800     -9.4166636466979980e-01
    phi[7,3]  R1801     0.539718747138977
    phi[7,3]  R1802     1.3057625293731689e+00
    phi[7,3]  R1803     1.3341449499130249e+00
    phi[7,3]  R1804     -4.7819700837135315e-01
    phi[7,3]  R1805     2.1048738956451416e+00
    phi[7,3]  R1806     2.2620997428894043e+00
    phi[7,3]  R1807     3.3220097422599792e-01
    phi[7,3]  R1808     6.1972582340240479e-01
    phi[7,3]  R1809     8.6876475811004639e-01
    phi[7,3]  R1810     -1.1355627775192261e+00
    phi[7,3]  R1811     -1.4717340469360352e+00
    phi[7,3]  R1812     -5.5237036943435669e-01
    phi[7,3]  R1813     2.3153524398803711e+00
    phi[7,3]  R1814     5.5375564098358154e-01
    phi[7,3]  R1815     9.4974571466445923e-01
    phi[7,3]  R1816     1.4389872550964355e+00
    phi[7,3]  R1817     2.6158072948455811e+00
    phi[7,3]  R1818     -4.5568060874938965e-01
    phi[7,3]  R1819     -2.3821408748626709e+00
    phi[7,3]  R1820     -9.4991987943649292e-01
    phi[7,3]  R1821     -4.3962943553924561e-01
    phi[7,3]  R1822     1.8360754847526550e-01
    phi[7,3]  R1823     6.8203949928283691e-01
    phi[3,9]  R27       1
    phi[3,9]  R28       1
    phi[3,9]  R29       2.4873720137694155e-01
    phi[3,9]  R30       -1.7292262623421930e+00
    phi[3,9]  R31       2.7207785497190908e+00
    phi[3,9]  R32       -8.9157918352655541e-01
    phi[3,9]  R33       -1.9594099882948943e+00
    phi[3,9]  R34       -1.6241265206712572e+00
    phi[3,9]  R35       1.3997847368650440e-01
    phi[3,9]  R73       -1
    phi[3,9]  R1824     -2.8512627032556268e+00
    phi[3,9]  R1825     -3.34873710600951
    phi[3,9]  R1826     -3.9692262718789362e+00
    phi[3,9]  R1827     -5.1077374719455015e-01
    phi[3,9]  R1828     -3.7922135491347753e-01
    phi[3,9]  R1829     -5.8207784543516592e+00
    phi[3,9]  R1830     -3.4615791167693533e+00
    phi[3,9]  R1831     -1.6784207497162424e+00
    phi[3,9]  R1832     -5.0594098929274622e+00
    phi[3,9]  R1833     -1.1405899163376740e+00
    phi[3,9]  R1834     -3.7141264348405687e+00
    phi[3,9]  R1835     -4.6587339349805434e-01
    phi[3,9]  R1836     -2.9600214309460640e+00
    phi[3,9]  R1837     -3.2399783783190728e+00
    phi[3,9]  R1838     -1.9471726052438143e-01
    phi[3,9]  R1839     -1.9794098459945353e-01
    phi[3,9]  R1840     -2.5436924735731248e-01
    phi[3,9]  R1841     -2.4908943703418807e-01
    phi[3,9]  R1842     -2.8023108957713694e-01
    phi[3,9]  R1843     -3.9781290770214639e-01
    phi[3,9]  R1844     -0.357297975837787
    phi[3,9]  R1845     -3.9158042808790094e-01
    phi[3,9]  R1846     -4.1374386131713026e-01
    phi[3,9]  R1847     -6.4414820681959484e-01
    phi[3,9]  R1848     -1.5266924870824128e-01
    phi[3,9]  R1849     -1.6752265953260626e-01
    phi[3,9]  R1850     -1.9046416837326130e-01
    phi[3,9]  R1851     -1.9532389851194476e-01
    phi[3,9]  R1852     -1.9676572315734076e-01
    phi[3,9]  R1853     -3.1180792665084012e-01
    phi[3,9]  R1854     -2.1170327450271786e-01
    phi[3,9]  R1855     -2.1438492466869807e-01
    phi[3,9]  R1856     -2.4231028365650409e-01
    phi[3,9]  R1857     -2.4484290058267583e-01
    phi[3,9]  R1858     -4.5943930482919915e-01
    phi[3,9]  R1859     -2.5694563604650766e-01
    phi[3,9]  R1860     -2.6568136169046386e-01
    phi[3,9]  R1861     -3.0668946853631485e-01
    phi[3,9]  R1862     -3.1429106209099045e-01
    phi[3,9]  R1863     -3.1961513810778097e-01
    phi[3,9]  R1864     -3.4114072465490608e-01
    phi[3,9]  R1865     -4.1793356958827421e-01
    phi[3,9]  R1866     -6.4425236148512788e-01
    phi[3,9]  R1867     -6.0378473681669420e-01
    phi[3,9]  R1868     -1.7241650231420985e-01
    phi[3,9]  R1869     -1.8659968215561396e-01
    phi[3,9]  R1870     -1.9730904294236051e-01
    phi[3,9]  R1871     -1.9744506952272756e-01
    phi[3,9]  R1872     -2.1944340840947318e-01
    phi[3,9]  R1873     -2.3699130363022358e-01
    phi[3,9]  R1874     -2.4219148935545198e-01
    phi[3,9]  R1875     -2.6652546834164914e-01
    phi[3,9]  R1876     -9.7103645857595433e-01
    phi[3,9]  R1877     -2.9059721782281889e-01
    phi[3,9]  R1878     -1.6376303053645724e-01
    phi[3,9]  R1879     -1.7815648678662988e-01
    phi[3,9]  R1880     -1.8127431290545704e-01
    phi[3,9]  R1881     -2.1253645879605942e-01
    phi[3,9]  R1882     -2.4524067407697275e-01
    phi[3,9]  R1883     -2.6981884776575438e-01
    phi[3,9]  R1884     -2.9226936711167650e-01
    phi[3,9]  R1885     -6.2450565876485586e-01
    phi[3,9]  R1886     -6.7227640108528763e-01
    phi[3,9]  R1887     -7.7751678096107235e-01
    phi[4,5]  R36       1
    phi[4,5]  R37       1
    phi[4,5]  R45       -1
    phi[4,5]  R1888     -3.0999999046325684e+00
    phi[4,5]  R1889     -3.0999999046325684e+00
    phi[4,5]  R1890     -2.2400000095367432e+00
    phi[4,5]  R1891     -2.2400000095367432e+00
    phi[4,5]  R1892     -3.0999999046325684e+00
    phi[4,5]  R1893     -3.0999999046325684e+00
    phi[4,5]  R1894     -2.5699999332427979e+00
    phi[4,5]  R1895     -2.5699999332427979e+00
    phi[4,5]  R1896     -3.0999999046325684e+00
    phi[4,5]  R1897     -3.0999999046325684e+00
    phi[4,5]  R1898     -2.0899999141693115e+00
    phi[4,5]  R1899     -2.0899999141693115e+00
    phi[4,5]  R1900     -3.0999999046325684e+00
    phi[4,5]  R1901     -3.0999999046325684e+00
    phi[4,5]  R1902     1.0409893989562988e+00
    phi[4,5]  R1903     3.12511944770813
    phi[4,5]  R1904     2.2121331691741943e+00
    phi[4,5]  R1905     2.4603700637817383e+00
    phi[4,5]  R1906     2.8742768764495850e+00
    phi[4,5]  R1907     1.7729644775390625e+00
    phi[4,5]  R1908     2.6363046169281006e+00
    phi[4,5]  R1909     3.3461880683898926e+00
    phi[4,5]  R1910     3.1400470733642578e+00
    phi[4,5]  R1911     2.1398820877075195e+00
    phi[4,5]  R1912     1.4088853597640991e+00
    phi[4,5]  R1913     -1.8469457626342773e+00
    phi[4,5]  R1914     -1.9318068027496338e+00
    phi[4,5]  R1915     -3.1918501853942871e-01
    phi[4,5]  R1916     -3.5772633552551270e-01
    phi[4,5]  R1917     9.4723916053771973e-01
    phi[4,5]  R1918     -2.7779671549797058e-01
    phi[4,5]  R1919     -4.1765800118446350e-01
    phi[4,5]  R1920     -1.5578038692474365e+00
    phi[4,5]  R1921     -9.8187726736068726e-01
    phi[4,5]  R1922     2.4526591598987579e-01
    phi[4,5]  R1923     -6.5786713361740112e-01
    phi[4,5]  R1924     -1.4257522821426392e+00
    phi[4,5]  R1925     -8.0545246601104736e-01
    phi[4,5]  R1926     8.1633490324020386e-01
    phi[4,5]  R1927     -2.4227447509765625e+00
    phi[4,5]  R1928     -2.3991665840148926e+00
    phi[4,5]  R1929     -1.3566262722015381e+00
    phi[4,5]  R1930     -1.5960556268692017e+00
    phi[4,5]  R1931     -2.28151273727417
    phi[4,5]  R1932     4.3044766783714294e-01
    phi[4,5]  R1933     6.4302825927734375e-01
    phi[4,5]  R1934     7.4261862039566040e-01
    phi[4,5]  R1935     -2.4349112510681152e+00
    phi[4,5]  R1936     6.1484597623348236e-02
    phi[4,5]  R1937     8.4120386838912964e-01
    phi[4,5]  R1938     1.6435261964797974e+00
    phi[4,5]  R1939     -2.0030975341796875e+00
    phi[4,5]  R1940     -7.3184430599212646e-01
    phi[4,5]  R1941     -1.2200669199228287e-01
    phi[4,5]  R1942     1.9300042390823364e+00
    phi[4,5]  R1943     7.4363201856613159e-01
    phi[4,5]  R1944     7.5290125608444214e-01
    phi[4,5]  R1945     8.8865995407104492e-01
    phi[4,5]  R1946     1.8823522329330444e+00
    phi[4,5]  R1947     2.8884959220886230e-01
    phi[4,5]  R1948     6.1533157713711262e-03
    phi[4,5]  R1949     -1.3884544372558594e+00
    phi[4,5]  R1950     -1.1666467189788818e+00
    phi[4,5]  R1951     -2.3745880126953125e+00
    phi[4,5]  R1952     -2.6544380187988281e+00
    phi[4,5]  R1953     -3.3787441253662109e+00
    phi[4,5]  R1954     -1.2786622047424316e+00
    phi[4,5]  R1955     -1.7446815967559814e+00
    phi[4,5]  R1956     -1.1144081354141235e+00
    phi[4,5]  R1957     -1.3227696418762207e+00
    phi[4,5]  R1958     -7.0742154121398926e-01
    phi[4,5]  R1959     -1.3913764953613281e+00
    phi[5,4]  R36       -1
    phi[5,4]  R45       1
    phi[5,4]  R46       1
    phi[5,4]  R1960     -3.0999999046325684e+00
    phi[5,4]  R1961     -3.0999999046325684e+00
    phi[5,4]  R1962     -2.2400000095367432e+00
    phi[5,4]  R1963     -2.2400000095367432e+00
    phi[5,4]  R1964     -3.0999999046325684e+00
    phi[5,4]  R1965     -3.0999999046325684e+00
    phi[5,4]  R1966     -2.5699999332427979e+00
    phi[5,4]  R1967     -2.5699999332427979e+00
    phi[5,4]  R1968     -3.0999999046325684e+00
    phi[5,4]  R1969     -3.0999999046325684e+00
    phi[5,4]  R1970     -2.0899999141693115e+00
    phi[5,4]  R1971     -2.0899999141693115e+00
    phi[5,4]  R1972     -3.0999999046325684e+00
    phi[5,4]  R1973     -3.0999999046325684e+00
    phi[5,4]  R1974     1.9300042390823364e+00
    phi[5,4]  R1975     7.4363201856613159e-01
    phi[5,4]  R1976     7.5290125608444214e-01
    phi[5,4]  R1977     8.8865995407104492e-01
    phi[5,4]  R1978     1.8823522329330444e+00
    phi[5,4]  R1979     2.8884959220886230e-01
    phi[5,4]  R1980     6.1533157713711262e-03
    phi[5,4]  R1981     -1.3884544372558594e+00
    phi[5,4]  R1982     -1.1666467189788818e+00
    phi[5,4]  R1983     -2.3745880126953125e+00
    phi[5,4]  R1984     -2.6544380187988281e+00
    phi[5,4]  R1985     -3.3787441253662109e+00
    phi[5,4]  R1986     -1.2786622047424316e+00
    phi[5,4]  R1987     -1.7446815967559814e+00
    phi[5,4]  R1988     -1.1144081354141235e+00
    phi[5,4]  R1989     -1.3227696418762207e+00
    phi[5,4]  R1990     -7.0742154121398926e-01
    phi[5,4]  R1991     -1.3913764953613281e+00
    phi[5,4]  R1992     1.0409893989562988e+00
    phi[5,4]  R1993     3.12511944770813
    phi[5,4]  R1994     2.2121331691741943e+00
    phi[5,4]  R1995     2.4603700637817383e+00
    phi[5,4]  R1996     2.8742768764495850e+00
    phi[5,4]  R1997     1.7729644775390625e+00
    phi[5,4]  R1998     2.6363046169281006e+00
    phi[5,4]  R1999     3.3461880683898926e+00
    phi[5,4]  R2000     3.1400470733642578e+00
    phi[5,4]  R2001     2.1398820877075195e+00
    phi[5,4]  R2002     1.4088853597640991e+00
    phi[5,4]  R2003     -1.8469457626342773e+00
    phi[5,4]  R2004     -1.9318068027496338e+00
    phi[5,4]  R2005     -3.1918501853942871e-01
    phi[5,4]  R2006     -3.5772633552551270e-01
    phi[5,4]  R2007     9.4723916053771973e-01
    phi[5,4]  R2008     -2.7779671549797058e-01
    phi[5,4]  R2009     -4.1765800118446350e-01
    phi[5,4]  R2010     -1.5578038692474365e+00
    phi[5,4]  R2011     -9.8187726736068726e-01
    phi[5,4]  R2012     2.4526591598987579e-01
    phi[5,4]  R2013     -6.5786713361740112e-01
    phi[5,4]  R2014     -1.4257522821426392e+00
    phi[5,4]  R2015     -8.0545246601104736e-01
    phi[5,4]  R2016     8.1633490324020386e-01
    phi[5,4]  R2017     -2.4227447509765625e+00
    phi[5,4]  R2018     -2.3991665840148926e+00
    phi[5,4]  R2019     -1.3566262722015381e+00
    phi[5,4]  R2020     -1.5960556268692017e+00
    phi[5,4]  R2021     -2.28151273727417
    phi[5,4]  R2022     4.3044766783714294e-01
    phi[5,4]  R2023     6.4302825927734375e-01
    phi[5,4]  R2024     7.4261862039566040e-01
    phi[5,4]  R2025     -2.4349112510681152e+00
    phi[5,4]  R2026     6.1484597623348236e-02
    phi[5,4]  R2027     8.4120386838912964e-01
    phi[5,4]  R2028     1.6435261964797974e+00
    phi[5,4]  R2029     -2.0030975341796875e+00
    phi[5,4]  R2030     -7.3184430599212646e-01
    phi[5,4]  R2031     -1.2200669199228287e-01
    phi[4,6]  R36       1
    phi[4,6]  R37       1
    phi[4,6]  R54       -1
    phi[4,6]  R2032     -3.0999999046325684e+00
    phi[4,6]  R2033     -3.0999999046325684e+00
    phi[4,6]  R2034     -2.2400000095367432e+00
    phi[4,6]  R2035     -2.2400000095367432e+00
    phi[4,6]  R2036     -3.0999999046325684e+00
    phi[4,6]  R2037     -3.0999999046325684e+00
    phi[4,6]  R2038     -2.5699999332427979e+00
    phi[4,6]  R2039     -2.5699999332427979e+00
    phi[4,6]  R2040     -3.0999999046325684e+00
    phi[4,6]  R2041     -3.0999999046325684e+00
    phi[4,6]  R2042     -2.0899999141693115e+00
    phi[4,6]  R2043     -2.0899999141693115e+00
    phi[4,6]  R2044     -3.0999999046325684e+00
    phi[4,6]  R2045     -3.0999999046325684e+00
    phi[4,6]  R2046     1.0409893989562988e+00
    phi[4,6]  R2047     3.12511944770813
    phi[4,6]  R2048     2.2121331691741943e+00
    phi[4,6]  R2049     2.4603700637817383e+00
    phi[4,6]  R2050     2.8742768764495850e+00
    phi[4,6]  R2051     1.7729644775390625e+00
    phi[4,6]  R2052     2.6363046169281006e+00
    phi[4,6]  R2053     3.3461880683898926e+00
    phi[4,6]  R2054     3.1400470733642578e+00
    phi[4,6]  R2055     2.1398820877075195e+00
    phi[4,6]  R2056     1.4088853597640991e+00
    phi[4,6]  R2057     -1.8469457626342773e+00
    phi[4,6]  R2058     -1.9318068027496338e+00
    phi[4,6]  R2059     -3.1918501853942871e-01
    phi[4,6]  R2060     -3.5772633552551270e-01
    phi[4,6]  R2061     9.4723916053771973e-01
    phi[4,6]  R2062     -2.7779671549797058e-01
    phi[4,6]  R2063     -4.1765800118446350e-01
    phi[4,6]  R2064     -1.5578038692474365e+00
    phi[4,6]  R2065     -9.8187726736068726e-01
    phi[4,6]  R2066     2.4526591598987579e-01
    phi[4,6]  R2067     -6.5786713361740112e-01
    phi[4,6]  R2068     -1.4257522821426392e+00
    phi[4,6]  R2069     -8.0545246601104736e-01
    phi[4,6]  R2070     8.1633490324020386e-01
    phi[4,6]  R2071     -2.4227447509765625e+00
    phi[4,6]  R2072     -2.3991665840148926e+00
    phi[4,6]  R2073     -1.3566262722015381e+00
    phi[4,6]  R2074     -1.5960556268692017e+00
    phi[4,6]  R2075     -2.28151273727417
    phi[4,6]  R2076     4.3044766783714294e-01
    phi[4,6]  R2077     6.4302825927734375e-01
    phi[4,6]  R2078     7.4261862039566040e-01
    phi[4,6]  R2079     -2.4349112510681152e+00
    phi[4,6]  R2080     6.1484597623348236e-02
    phi[4,6]  R2081     8.4120386838912964e-01
    phi[4,6]  R2082     1.6435261964797974e+00
    phi[4,6]  R2083     -2.0030975341796875e+00
    phi[4,6]  R2084     -7.3184430599212646e-01
    phi[4,6]  R2085     -1.2200669199228287e-01
    phi[4,6]  R2086     -1.1736383438110352e+00
    phi[4,6]  R2087     6.4546424150466919e-01
    phi[4,6]  R2088     7.9511034488677979e-01
    phi[4,6]  R2089     -9.1030347347259521e-01
    phi[4,6]  R2090     -2.5765165686607361e-01
    phi[4,6]  R2091     -8.2332092523574829e-01
    phi[4,6]  R2092     6.0597646236419678e-01
    phi[4,6]  R2093     2.8944343328475952e-01
    phi[4,6]  R2094     8.9632856845855713e-01
    phi[4,6]  R2095     4.7483021020889282e-01
    phi[4,6]  R2096     -2.7093849182128906e+00
    phi[4,6]  R2097     1.3204421997070312e+00
    phi[4,6]  R2098     1.0030152797698975e+00
    phi[4,6]  R2099     5.5096292495727539e-01
    phi[4,6]  R2100     5.7313877344131470e-01
    phi[4,6]  R2101     -1.8256443738937378e-01
    phi[4,6]  R2102     -1.1110488176345825e+00
    phi[4,6]  R2103     8.3825695514678955e-01
    phi[4,6]  R2104     1.0442655086517334e+00
    phi[4,6]  R2105     4.6041089296340942e-01
    phi[6,4]  R36       -1
    phi[6,4]  R54       1
    phi[6,4]  R55       1
    phi[6,4]  R2106     -3.0999999046325684e+00
    phi[6,4]  R2107     -3.0999999046325684e+00
    phi[6,4]  R2108     -2.2400000095367432e+00
    phi[6,4]  R2109     -2.2400000095367432e+00
    phi[6,4]  R2110     -3.0999999046325684e+00
    phi[6,4]  R2111     -3.0999999046325684e+00
    phi[6,4]  R2112     -2.5699999332427979e+00
    phi[6,4]  R2113     -2.5699999332427979e+00
    phi[6,4]  R2114     -3.0999999046325684e+00
    phi[6,4]  R2115     -3.0999999046325684e+00
    phi[6,4]  R2116     -2.0899999141693115e+00
    phi[6,4]  R2117     -2.0899999141693115e+00
    phi[6,4]  R2118     -3.0999999046325684e+00
    phi[6,4]  R2119     -3.0999999046325684e+00
    phi[6,4]  R2120     -1.1736383438110352e+00
    phi[6,4]  R2121     6.4546424150466919e-01
    phi[6,4]  R2122     7.9511034488677979e-01
    phi[6,4]  R2123     -9.1030347347259521e-01
    phi[6,4]  R2124     -2.5765165686607361e-01
    phi[6,4]  R2125     -8.2332092523574829e-01
    phi[6,4]  R2126     6.0597646236419678e-01
    phi[6,4]  R2127     2.8944343328475952e-01
    phi[6,4]  R2128     8.9632856845855713e-01
    phi[6,4]  R2129     4.7483021020889282e-01
    phi[6,4]  R2130     -2.7093849182128906e+00
    phi[6,4]  R2131     1.3204421997070312e+00
    phi[6,4]  R2132     1.0030152797698975e+00
    phi[6,4]  R2133     5.5096292495727539e-01
    phi[6,4]  R2134     5.7313877344131470e-01
    phi[6,4]  R2135     -1.8256443738937378e-01
    phi[6,4]  R2136     -1.1110488176345825e+00
    phi[6,4]  R2137     8.3825695514678955e-01
    phi[6,4]  R2138     1.0442655086517334e+00
    phi[6,4]  R2139     4.6041089296340942e-01
    phi[6,4]  R2140     1.0409893989562988e+00
    phi[6,4]  R2141     3.12511944770813
    phi[6,4]  R2142     2.2121331691741943e+00
    phi[6,4]  R2143     2.4603700637817383e+00
    phi[6,4]  R2144     2.8742768764495850e+00
    phi[6,4]  R2145     1.7729644775390625e+00
    phi[6,4]  R2146     2.6363046169281006e+00
    phi[6,4]  R2147     3.3461880683898926e+00
    phi[6,4]  R2148     3.1400470733642578e+00
    phi[6,4]  R2149     2.1398820877075195e+00
    phi[6,4]  R2150     1.4088853597640991e+00
    phi[6,4]  R2151     -1.8469457626342773e+00
    phi[6,4]  R2152     -1.9318068027496338e+00
    phi[6,4]  R2153     -3.1918501853942871e-01
    phi[6,4]  R2154     -3.5772633552551270e-01
    phi[6,4]  R2155     9.4723916053771973e-01
    phi[6,4]  R2156     -2.7779671549797058e-01
    phi[6,4]  R2157     -4.1765800118446350e-01
    phi[6,4]  R2158     -1.5578038692474365e+00
    phi[6,4]  R2159     -9.8187726736068726e-01
    phi[6,4]  R2160     2.4526591598987579e-01
    phi[6,4]  R2161     -6.5786713361740112e-01
    phi[6,4]  R2162     -1.4257522821426392e+00
    phi[6,4]  R2163     -8.0545246601104736e-01
    phi[6,4]  R2164     8.1633490324020386e-01
    phi[6,4]  R2165     -2.4227447509765625e+00
    phi[6,4]  R2166     -2.3991665840148926e+00
    phi[6,4]  R2167     -1.3566262722015381e+00
    phi[6,4]  R2168     -1.5960556268692017e+00
    phi[6,4]  R2169     -2.28151273727417
    phi[6,4]  R2170     4.3044766783714294e-01
    phi[6,4]  R2171     6.4302825927734375e-01
    phi[6,4]  R2172     7.4261862039566040e-01
    phi[6,4]  R2173     -2.4349112510681152e+00
    phi[6,4]  R2174     6.1484597623348236e-02
    phi[6,4]  R2175     8.4120386838912964e-01
    phi[6,4]  R2176     1.6435261964797974e+00
    phi[6,4]  R2177     -2.0030975341796875e+00
    phi[6,4]  R2178     -7.3184430599212646e-01
    phi[6,4]  R2179     -1.2200669199228287e-01
    phi[8,4]  R36       -1
    phi[8,4]  R38       -1.3550681263039
    phi[8,4]  R39       2.0686367358790969e-01
    phi[8,4]  R40       2.9534051777112533e+00
    phi[8,4]  R41       1.5626497589467756e+00
    phi[8,4]  R42       2.8910893979909322e+00
    phi[8,4]  R43       5.7556263234235239e-01
    phi[8,4]  R44       -1.5764510220519012e-01
    phi[8,4]  R72       1
    phi[8,4]  R2180     -1.7449317783286684e+00
    phi[8,4]  R2181     -4.4550680309364683e+00
    phi[8,4]  R2182     -2.4468636831246529e+00
    phi[8,4]  R2183     -2.0331363359488335e+00
    phi[8,4]  R2184     -6.0534050823438221e+00
    phi[8,4]  R2185     -1.4659472692131503e-01
    phi[8,4]  R2186     -4.1326496921895739e+00
    phi[8,4]  R2187     -1.0073501742960222e+00
    phi[8,4]  R2188     -5.9910893026235
    phi[8,4]  R2189     -2.0891050664163613e-01
    phi[8,4]  R2190     -2.6655625465116639e+00
    phi[8,4]  R2191     -1.5144372818269591e+00
    phi[8,4]  R2192     -2.9423548024273782e+00
    phi[8,4]  R2193     -3.2576450068377585e+00
    phi[8,4]  R2194     -5.6626150373876549e-01
    phi[8,4]  R2195     -5.8523375506747666e-01
    phi[8,4]  R2196     -2.5637837344442005e-01
    phi[8,4]  R2197     -5.4778566527134931e-01
    phi[8,4]  R2198     -8.5416548001870929e-01
    phi[8,4]  R2199     -1.3225422079594953e+00
    phi[8,4]  R2200     -6.0271831850701707e-01
    phi[8,4]  R2201     -4.2064611395133822e-01
    phi[8,4]  R2202     -4.2543521983010413e-01
    phi[8,4]  R2203     -4.3215123752316753e-01
    phi[8,4]  R2204     -7.8022256661296030e-02
    phi[8,4]  R2205     -3.5686979302030930e-01
    phi[8,4]  R2206     -1.2438037631291987e+00
    phi[8,4]  R2207     -3.8230676547799414e-01
    phi[8,4]  R2208     -3.8706875506412658e-01
    phi[8,4]  R2209     -3.9334362924806565e-01
    phi[8,4]  R2210     -3.9629289565906123e-01
    phi[8,4]  R2211     -3.9847276791145281e-01
    phi[8,4]  R2212     -4.1884835005216159e-01
    phi[8,4]  R2213     -4.1916172512168604e-01
    phi[8,4]  R2214     -2.9252234034923907e-01
    phi[8,4]  R2215     -3.8728164580719204e-01
    phi[8,4]  R2216     -3.9430219982454973e-01
    phi[8,4]  R2217     -4.3951596488534966e-01
    phi[8,4]  R2218     -4.5237080587440359e-01
    phi[8,4]  R2219     -1.2701362471332298e+00
    phi[8,4]  R2220     -1.4404350740874512e+00
    phi[8,4]  R2221     -1.9667192009734640e+00
    phi[8,4]  R2222     -1.8038101860105944e+00
    phi[8,4]  R2223     -1.9136499384636645e+00
    phi[8,4]  R2224     -1.4539058784057834e-01
    phi[8,4]  R2225     -1.7994290479640784e-01
    phi[8,4]  R2226     -2.2027172898930658e-01
    phi[8,4]  R2227     -2.3374278203542653e-01
    phi[8,4]  R2228     -3.0367025994931579e-01
    phi[8,4]  R2229     -7.4615454174136886e-01
    phi[8,4]  R2230     -7.5537148302282642e-01
    phi[8,4]  R2231     -8.7534742002775023e-01
    phi[8,4]  R2232     -9.8048640958755073e-01
    phi[8,4]  R2233     -9.9213222501401543e-01
    phi[5,6]  R45       1
    phi[5,6]  R46       1
    phi[5,6]  R54       -1
    phi[5,6]  R2234     -3.0999999046325684e+00
    phi[5,6]  R2235     -3.0999999046325684e+00
    phi[5,6]  R2236     -2.2400000095367432e+00
    phi[5,6]  R2237     -2.2400000095367432e+00
    phi[5,6]  R2238     -3.0999999046325684e+00
    phi[5,6]  R2239     -3.0999999046325684e+00
    phi[5,6]  R2240     -2.5699999332427979e+00
    phi[5,6]  R2241     -2.5699999332427979e+00
    phi[5,6]  R2242     -3.0999999046325684e+00
    phi[5,6]  R2243     -3.0999999046325684e+00
    phi[5,6]  R2244     -2.0899999141693115e+00
    phi[5,6]  R2245     -2.0899999141693115e+00
    phi[5,6]  R2246     -3.0999999046325684e+00
    phi[5,6]  R2247     -3.0999999046325684e+00
    phi[5,6]  R2248     1.9300042390823364e+00
    phi[5,6]  R2249     7.4363201856613159e-01
    phi[5,6]  R2250     7.5290125608444214e-01
    phi[5,6]  R2251     8.8865995407104492e-01
    phi[5,6]  R2252     1.8823522329330444e+00
    phi[5,6]  R2253     2.8884959220886230e-01
    phi[5,6]  R2254     6.1533157713711262e-03
    phi[5,6]  R2255     -1.3884544372558594e+00
    phi[5,6]  R2256     -1.1666467189788818e+00
    phi[5,6]  R2257     -2.3745880126953125e+00
    phi[5,6]  R2258     -2.6544380187988281e+00
    phi[5,6]  R2259     -3.3787441253662109e+00
    phi[5,6]  R2260     -1.2786622047424316e+00
    phi[5,6]  R2261     -1.7446815967559814e+00
    phi[5,6]  R2262     -1.1144081354141235e+00
    phi[5,6]  R2263     -1.3227696418762207e+00
    phi[5,6]  R2264     -7.0742154121398926e-01
    phi[5,6]  R2265     -1.3913764953613281e+00
    phi[5,6]  R2266     -1.1736383438110352e+00
    phi[5,6]  R2267     6.4546424150466919e-01
    phi[5,6]  R2268     7.9511034488677979e-01
    phi[5,6]  R2269     -9.1030347347259521e-01
    phi[5,6]  R2270     -2.5765165686607361e-01
    phi[5,6]  R2271     -8.2332092523574829e-01
    phi[5,6]  R2272     6.0597646236419678e-01
    phi[5,6]  R2273     2.8944343328475952e-01
    phi[5,6]  R2274     8.9632856845855713e-01
    phi[5,6]  R2275     4.7483021020889282e-01
    phi[5,6]  R2276     -2.7093849182128906e+00
    phi[5,6]  R2277     1.3204421997070312e+00
    phi[5,6]  R2278     1.0030152797698975e+00
    phi[5,6]  R2279     5.5096292495727539e-01
    phi[5,6]  R2280     5.7313877344131470e-01
    phi[5,6]  R2281     -1.8256443738937378e-01
    phi[5,6]  R2282     -1.1110488176345825e+00
    phi[5,6]  R2283     8.3825695514678955e-01
    phi[5,6]  R2284     1.0442655086517334e+00
    phi[5,6]  R2285     4.6041089296340942e-01
    phi[6,5]  R45       -1
    phi[6,5]  R54       1
    phi[6,5]  R55       1
    phi[6,5]  R2286     -3.0999999046325684e+00
    phi[6,5]  R2287     -3.0999999046325684e+00
    phi[6,5]  R2288     -2.2400000095367432e+00
    phi[6,5]  R2289     -2.2400000095367432e+00
    phi[6,5]  R2290     -3.0999999046325684e+00
    phi[6,5]  R2291     -3.0999999046325684e+00
    phi[6,5]  R2292     -2.5699999332427979e+00
    phi[6,5]  R2293     -2.5699999332427979e+00
    phi[6,5]  R2294     -3.0999999046325684e+00
    phi[6,5]  R2295     -3.0999999046325684e+00
    phi[6,5]  R2296     -2.0899999141693115e+00
    phi[6,5]  R2297     -2.0899999141693115e+00
    phi[6,5]  R2298     -3.0999999046325684e+00
    phi[6,5]  R2299     -3.0999999046325684e+00
    phi[6,5]  R2300     -1.1736383438110352e+00
    phi[6,5]  R2301     6.4546424150466919e-01
    phi[6,5]  R2302     7.9511034488677979e-01
    phi[6,5]  R2303     -9.1030347347259521e-01
    phi[6,5]  R2304     -2.5765165686607361e-01
    phi[6,5]  R2305     -8.2332092523574829e-01
    phi[6,5]  R2306     6.0597646236419678e-01
    phi[6,5]  R2307     2.8944343328475952e-01
    phi[6,5]  R2308     8.9632856845855713e-01
    phi[6,5]  R2309     4.7483021020889282e-01
    phi[6,5]  R2310     -2.7093849182128906e+00
    phi[6,5]  R2311     1.3204421997070312e+00
    phi[6,5]  R2312     1.0030152797698975e+00
    phi[6,5]  R2313     5.5096292495727539e-01
    phi[6,5]  R2314     5.7313877344131470e-01
    phi[6,5]  R2315     -1.8256443738937378e-01
    phi[6,5]  R2316     -1.1110488176345825e+00
    phi[6,5]  R2317     8.3825695514678955e-01
    phi[6,5]  R2318     1.0442655086517334e+00
    phi[6,5]  R2319     4.6041089296340942e-01
    phi[6,5]  R2320     1.9300042390823364e+00
    phi[6,5]  R2321     7.4363201856613159e-01
    phi[6,5]  R2322     7.5290125608444214e-01
    phi[6,5]  R2323     8.8865995407104492e-01
    phi[6,5]  R2324     1.8823522329330444e+00
    phi[6,5]  R2325     2.8884959220886230e-01
    phi[6,5]  R2326     6.1533157713711262e-03
    phi[6,5]  R2327     -1.3884544372558594e+00
    phi[6,5]  R2328     -1.1666467189788818e+00
    phi[6,5]  R2329     -2.3745880126953125e+00
    phi[6,5]  R2330     -2.6544380187988281e+00
    phi[6,5]  R2331     -3.3787441253662109e+00
    phi[6,5]  R2332     -1.2786622047424316e+00
    phi[6,5]  R2333     -1.7446815967559814e+00
    phi[6,5]  R2334     -1.1144081354141235e+00
    phi[6,5]  R2335     -1.3227696418762207e+00
    phi[6,5]  R2336     -7.0742154121398926e-01
    phi[6,5]  R2337     -1.3913764953613281e+00
    phi[6,7]  R54       1
    phi[6,7]  R55       1
    phi[6,7]  R63       -1
    phi[6,7]  R2338     -3.0999999046325684e+00
    phi[6,7]  R2339     -3.0999999046325684e+00
    phi[6,7]  R2340     -2.2400000095367432e+00
    phi[6,7]  R2341     -2.2400000095367432e+00
    phi[6,7]  R2342     -3.0999999046325684e+00
    phi[6,7]  R2343     -3.0999999046325684e+00
    phi[6,7]  R2344     -2.5699999332427979e+00
    phi[6,7]  R2345     -2.5699999332427979e+00
    phi[6,7]  R2346     -3.0999999046325684e+00
    phi[6,7]  R2347     -3.0999999046325684e+00
    phi[6,7]  R2348     -2.0899999141693115e+00
    phi[6,7]  R2349     -2.0899999141693115e+00
    phi[6,7]  R2350     -3.0999999046325684e+00
    phi[6,7]  R2351     -3.0999999046325684e+00
    phi[6,7]  R2352     -1.1736383438110352e+00
    phi[6,7]  R2353     6.4546424150466919e-01
    phi[6,7]  R2354     7.9511034488677979e-01
    phi[6,7]  R2355     -9.1030347347259521e-01
    phi[6,7]  R2356     -2.5765165686607361e-01
    phi[6,7]  R2357     -8.2332092523574829e-01
    phi[6,7]  R2358     6.0597646236419678e-01
    phi[6,7]  R2359     2.8944343328475952e-01
    phi[6,7]  R2360     8.9632856845855713e-01
    phi[6,7]  R2361     4.7483021020889282e-01
    phi[6,7]  R2362     -2.7093849182128906e+00
    phi[6,7]  R2363     1.3204421997070312e+00
    phi[6,7]  R2364     1.0030152797698975e+00
    phi[6,7]  R2365     5.5096292495727539e-01
    phi[6,7]  R2366     5.7313877344131470e-01
    phi[6,7]  R2367     -1.8256443738937378e-01
    phi[6,7]  R2368     -1.1110488176345825e+00
    phi[6,7]  R2369     8.3825695514678955e-01
    phi[6,7]  R2370     1.0442655086517334e+00
    phi[6,7]  R2371     4.6041089296340942e-01
    phi[6,7]  R2372     -7.7624785900115967e-01
    phi[6,7]  R2373     0.286338746547699
    phi[6,7]  R2374     1.1432054042816162e+00
    phi[6,7]  R2375     9.4262385368347168e-01
    phi[6,7]  R2376     -4.5222994685173035e-01
    phi[6,7]  R2377     7.4979829788208008e-01
    phi[6,7]  R2378     1.1047372817993164e+00
    phi[6,7]  R2379     0.621229350566864
    phi[6,7]  R2380     1.7755998373031616e+00
    phi[6,7]  R2381     1.0287989377975464e+00
    phi[6,7]  R2382     -3.1104570627212524e-01
    phi[6,7]  R2383     -2.2868425846099854e+00
    phi[6,7]  R2384     -1.2517036199569702e+00
    phi[6,7]  R2385     -2.5400383472442627e+00
    phi[6,7]  R2386     1.1652899980545044e+00
    phi[6,7]  R2387     4.2673242092132568e-01
    phi[6,7]  R2388     1.6328843832015991e+00
    phi[6,7]  R2389     1.0937812328338623e+00
    phi[6,7]  R2390     1.2881648540496826e+00
    phi[6,7]  R2391     5.8761775493621826e-01
    phi[6,7]  R2392     -1.5248589515686035e+00
    phi[6,7]  R2393     -8.3783918619155884e-01
    phi[6,7]  R2394     5.5841177701950073e-01
    phi[6,7]  R2395     -2.5075094699859619e+00
    phi[6,7]  R2396     9.7332602739334106e-01
    phi[6,7]  R2397     7.4454230070114136e-01
    phi[6,7]  R2398     1.9657289981842041e-01
    phi[6,7]  R2399     0.0837339535355568
    phi[6,7]  R2400     2.0328288078308105e+00
    phi[6,7]  R2401     1.1393010616302490e+00
    phi[7,6]  R54       -1
    phi[7,6]  R63       1
    phi[7,6]  R64       1
    phi[7,6]  R2402     -3.0999999046325684e+00
    phi[7,6]  R2403     -3.0999999046325684e+00
    phi[7,6]  R2404     -2.2400000095367432e+00
    phi[7,6]  R2405     -2.2400000095367432e+00
    phi[7,6]  R2406     -3.0999999046325684e+00
    phi[7,6]  R2407     -3.0999999046325684e+00
    phi[7,6]  R2408     -2.5699999332427979e+00
    phi[7,6]  R2409     -2.5699999332427979e+00
    phi[7,6]  R2410     -3.0999999046325684e+00
    phi[7,6]  R2411     -3.0999999046325684e+00
    phi[7,6]  R2412     -2.0899999141693115e+00
    phi[7,6]  R2413     -2.0899999141693115e+00
    phi[7,6]  R2414     -3.0999999046325684e+00
    phi[7,6]  R2415     -3.0999999046325684e+00
    phi[7,6]  R2416     -7.7624785900115967e-01
    phi[7,6]  R2417     0.286338746547699
    phi[7,6]  R2418     1.1432054042816162e+00
    phi[7,6]  R2419     9.4262385368347168e-01
    phi[7,6]  R2420     -4.5222994685173035e-01
    phi[7,6]  R2421     7.4979829788208008e-01
    phi[7,6]  R2422     1.1047372817993164e+00
    phi[7,6]  R2423     0.621229350566864
    phi[7,6]  R2424     1.7755998373031616e+00
    phi[7,6]  R2425     1.0287989377975464e+00
    phi[7,6]  R2426     -3.1104570627212524e-01
    phi[7,6]  R2427     -2.2868425846099854e+00
    phi[7,6]  R2428     -1.2517036199569702e+00
    phi[7,6]  R2429     -2.5400383472442627e+00
    phi[7,6]  R2430     1.1652899980545044e+00
    phi[7,6]  R2431     4.2673242092132568e-01
    phi[7,6]  R2432     1.6328843832015991e+00
    phi[7,6]  R2433     1.0937812328338623e+00
    phi[7,6]  R2434     1.2881648540496826e+00
    phi[7,6]  R2435     5.8761775493621826e-01
    phi[7,6]  R2436     -1.5248589515686035e+00
    phi[7,6]  R2437     -8.3783918619155884e-01
    phi[7,6]  R2438     5.5841177701950073e-01
    phi[7,6]  R2439     -2.5075094699859619e+00
    phi[7,6]  R2440     9.7332602739334106e-01
    phi[7,6]  R2441     7.4454230070114136e-01
    phi[7,6]  R2442     1.9657289981842041e-01
    phi[7,6]  R2443     0.0837339535355568
    phi[7,6]  R2444     2.0328288078308105e+00
    phi[7,6]  R2445     1.1393010616302490e+00
    phi[7,6]  R2446     -1.1736383438110352e+00
    phi[7,6]  R2447     6.4546424150466919e-01
    phi[7,6]  R2448     7.9511034488677979e-01
    phi[7,6]  R2449     -9.1030347347259521e-01
    phi[7,6]  R2450     -2.5765165686607361e-01
    phi[7,6]  R2451     -8.2332092523574829e-01
    phi[7,6]  R2452     6.0597646236419678e-01
    phi[7,6]  R2453     2.8944343328475952e-01
    phi[7,6]  R2454     8.9632856845855713e-01
    phi[7,6]  R2455     4.7483021020889282e-01
    phi[7,6]  R2456     -2.7093849182128906e+00
    phi[7,6]  R2457     1.3204421997070312e+00
    phi[7,6]  R2458     1.0030152797698975e+00
    phi[7,6]  R2459     5.5096292495727539e-01
    phi[7,6]  R2460     5.7313877344131470e-01
    phi[7,6]  R2461     -1.8256443738937378e-01
    phi[7,6]  R2462     -1.1110488176345825e+00
    phi[7,6]  R2463     8.3825695514678955e-01
    phi[7,6]  R2464     1.0442655086517334e+00
    phi[7,6]  R2465     4.6041089296340942e-01
    phi[7,9]  R63       1
    phi[7,9]  R64       1
    phi[7,9]  R65       2.4873720137694155e-01
    phi[7,9]  R66       -1.7292262623421930e+00
    phi[7,9]  R67       2.7207785497190908e+00
    phi[7,9]  R68       -8.9157918352655541e-01
    phi[7,9]  R69       -1.9594099882948943e+00
    phi[7,9]  R70       -1.6241265206712572e+00
    phi[7,9]  R71       1.3997847368650440e-01
    phi[7,9]  R73       -1
    phi[7,9]  R2466     -2.8512627032556268e+00
    phi[7,9]  R2467     -3.34873710600951
    phi[7,9]  R2468     -3.9692262718789362e+00
    phi[7,9]  R2469     -5.1077374719455015e-01
    phi[7,9]  R2470     -3.7922135491347753e-01
    phi[7,9]  R2471     -5.8207784543516592e+00
    phi[7,9]  R2472     -3.4615791167693533e+00
    phi[7,9]  R2473     -1.6784207497162424e+00
    phi[7,9]  R2474     -5.0594098929274622e+00
    phi[7,9]  R2475     -1.1405899163376740e+00
    phi[7,9]  R2476     -3.7141264348405687e+00
    phi[7,9]  R2477     -4.6587339349805434e-01
    phi[7,9]  R2478     -2.9600214309460640e+00
    phi[7,9]  R2479     -3.2399783783190728e+00
    phi[7,9]  R2480     -7.7700096584033873e-02
    phi[7,9]  R2481     -1.2665905166022756e-01
    phi[7,9]  R2482     -1.2956183277224742e-01
    phi[7,9]  R2483     -1.3067361649531239e-01
    phi[7,9]  R2484     -1.3330488679126684e-01
    phi[7,9]  R2485     -1.3334922051945730e-01
    phi[7,9]  R2486     -1.3568236624963492e-01
    phi[7,9]  R2487     -1.3862495457937229e-01
    phi[7,9]  R2488     -1.5130227399470519e-01
    phi[7,9]  R2489     -1.5212294284426564e-01
    phi[7,9]  R2490     -0.102816629365751
    phi[7,9]  R2491     -0.595029351208388
    phi[7,9]  R2492     -0.836453410800329
    phi[7,9]  R2493     -1.5967879901850646e-01
    phi[7,9]  R2494     -7.3460906173629059e-01
    phi[7,9]  R2495     -8.7360076558736255e-01
    phi[7,9]  R2496     -6.0689000228600642e-01
    phi[7,9]  R2497     -6.1486781462185625e-01
    phi[7,9]  R2498     -3.7594812540651978e-01
    phi[7,9]  R2499     -5.0031566139288630e-01
    phi[7,9]  R2500     -3.6910215336780405e-02
    phi[7,9]  R2501     -0.0374686386675559
    phi[7,9]  R2502     -4.7330924089635129e-02
    phi[7,9]  R2503     -7.2371032078058839e-02
    phi[7,9]  R2504     -3.0183798223959313e-01
    phi[7,9]  R2505     -9.7409687601214046e-01
    phi[7,9]  R2506     -5.9542138655027366e-01
    phi[7,9]  R2507     -1.9972264005689866e-01
    phi[7,9]  R2508     -8.5973372279935045e-01
    phi[7,9]  R2509     -7.8598303393536240e-01
    MARKER    'MARKER'                 'INTEND'
    z[0,1,0]  R2        -1
    z[0,1,0]  R11       1
    z[0,1,0]  R74       -1
    z[0,1,0]  R75       1
    z[0,1,0]  R88       2.6066619157791138e-01
    z[0,1,0]  R89       6.8736499547958374e-01
    z[0,1,0]  R90       -0.263374388217926
    z[0,1,0]  R91       -3.5421472787857056e-01
    z[0,1,0]  R92       -7.9832553863525391e-02
    z[0,1,0]  R93       -1.8112431466579437e-01
    z[0,1,0]  R94       -4.8229244351387024e-01
    z[0,1,0]  R95       -3.9737311005592346e-01
    z[0,1,0]  R96       -3.8635954260826111e-01
    z[0,1,0]  R97       -2.6415404677391052e-01
    z[0,1,0]  R98       -0.52254319190979
    z[0,1,0]  R99       -1.6679821908473969e-01
    z[0,1,0]  R100      -5.2074825763702393e-01
    z[0,1,0]  R101      -3.2534840703010559e-01
    z[0,1,0]  R102      -6.1319935321807861e-01
    z[0,1,0]  R103      -6.7678910493850708e-01
    z[0,1,0]  R104      -4.2548552155494690e-01
    z[0,1,0]  R105      -4.3196880817413330e-01
    z[0,1,0]  R106      -5.6378740072250366e-01
    z[0,1,0]  R107      -2.3224976658821106e-01
    z[0,1,0]  R108      -4.8676493763923645e-01
    z[0,1,0]  R109      -6.3810366392135620e-01
    z[0,1,0]  R110      -5.1050257682800293e-01
    z[0,1,0]  R111      -4.1413670778274536e-01
    z[0,1,0]  R112      -3.9808002114295959e-01
    z[0,1,0]  R113      -2.7420192956924438e-01
    z[0,1,0]  R114      -0.250662624835968
    z[0,1,0]  R115      -4.4196444749832153e-01
    z[0,1,0]  R116      -0.415751576423645
    z[0,1,0]  R117      4.9911633133888245e-01
    z[0,1,0]  R118      -7.5694888830184937e-02
    z[0,1,0]  R119      -6.8983119726181030e-01
    z[0,1,0]  R120      -1.5377275645732880e-01
    z[0,1,0]  R121      -5.7229089736938477e-01
    z[0,1,0]  R122      1.7609516158699989e-02
    z[0,1,0]  R123      -7.9494613409042358e-01
    z[0,1,0]  R124      -4.1513875126838684e-01
    z[0,1,0]  R125      -2.5649663805961609e-01
    z[0,1,0]  R126      -2.4282118678092957e-01
    z[0,1,0]  R127      1.9869744777679443e-01
    z[0,1,0]  R128      3.8046124577522278e-01
    z[0,1,0]  R129      -6.0589760541915894e-01
    z[0,1,0]  R130      -7.2114330530166626e-01
    z[0,1,0]  R131      -2.8105261921882629e-01
    z[0,1,0]  R132      -4.4869899749755859e-01
    z[0,1,0]  R133      -7.7343314886093140e-01
    z[0,1,0]  R134      -5.3159594535827637e-01
    z[0,1,0]  R135      -6.0012131929397583e-01
    z[0,1,0]  R136      -4.9606877565383911e-01
    z[0,1,0]  R137      -0.329940527677536
    z[0,1,0]  R138      -6.3231301307678223e-01
    z[0,1,0]  R139      -7.1913182735443115e-01
    z[0,1,0]  R140      -6.6646450757980347e-01
    z[0,1,0]  R141      -4.4938430190086365e-01
    z[0,1,0]  R142      -3.7860605120658875e-01
    z[0,1,0]  R143      -5.9573411941528320e-01
    z[0,1,0]  R144      -2.6482513546943665e-01
    z[0,1,0]  R145      6.5551483631134033e-01
    z[0,1,0]  R146      5.2602589130401611e-01
    z[0,1,0]  R147      4.7809746861457825e-01
    z[0,1,0]  R148      7.4860262870788574e-01
    z[0,1,0]  R149      3.6833679676055908e-01
    z[0,1,0]  R150      -2.2596074640750885e-01
    z[0,1,0]  R151      -3.0306759476661682e-01
    z[0,1,0]  R152      -1.4573006331920624e-01
    z[0,1,0]  R153      -0.50286865234375
    z[0,1,0]  R154      -8.5654549300670624e-02
    z[0,1,0]  R155      1.5423680841922760e-01
    z[0,1,0]  R156      -3.0090352892875671e-01
    z[0,1,0]  R157      -3.6334908008575439e-01
    z[0,1,0]  R158      -3.2288312911987305e-01
    z[0,1,0]  R159      4.0381222963333130e-01
    z[0,1,0]  R160      -8.3608108758926392e-01
    z[0,1,0]  R161      -5.0338220596313477e-01
    z[0,1,0]  R162      -6.4310878515243530e-01
    z[0,1,0]  R163      6.7158448696136475e-01
    z[0,1,0]  R164      -2.9885500669479370e-01
    z[0,1,0]  R165      -6.3888782262802124e-01
    z[0,1,0]  R166      3.1097555160522461e-01
    z[0,1,0]  R167      -5.0072693824768066e-01
    z[0,1,0]  R168      -1.9979985058307648e-01
    z[0,1,0]  R169      -5.3643178939819336e-01
    z[0,1,0]  R170      0.607283890247345
    z[0,1,0]  R171      -7.1195596456527710e-01
    z[0,1,0]  R172      -6.0410439968109131e-01
    z[0,1,0]  R173      -8.3872246742248535e-01
    z[0,1,0]  R174      -4.6909371018409729e-01
    z[0,1,0]  R175      6.2660795450210571e-01
    z[0,1,0]  R176      -3.5793432593345642e-01
    z[0,1,0]  R177      4.1159999370574951e-01
    z[0,1,0]  R178      7.6862829923629761e-01
    z[0,1,0]  R179      7.8859555721282959e-01
    z[0,1,0]  R180      0.763009250164032
    z[0,1,0]  R181      -7.1807646751403809e-01
    z[0,1,0]  R182      5.9774047136306763e-01
    z[0,1,0]  R183      -1.5244425833225250e-01
    z[0,1,0]  R184      7.3239183425903320e-01
    z[0,1,0]  R185      2.9017889499664307e-01
    z[0,1,0]  R186      2.7914133667945862e-01
    z[0,1,0]  R187      -4.0742442011833191e-02
    z[0,1,1]  R3        -1
    z[0,1,1]  R12       1
    z[0,1,1]  R76       -1
    z[0,1,1]  R77       1
    z[0,1,1]  R88       -3.8004130125045776e-01
    z[0,1,1]  R89       1.2914985418319702e-01
    z[0,1,1]  R90       -6.0805189609527588e-01
    z[0,1,1]  R91       4.6549469232559204e-01
    z[0,1,1]  R92       3.6320638656616211e-01
    z[0,1,1]  R93       -3.6114744842052460e-02
    z[0,1,1]  R94       1.7353674769401550e-01
    z[0,1,1]  R95       -9.5659092068672180e-02
    z[0,1,1]  R96       2.6273140311241150e-01
    z[0,1,1]  R97       3.4583482146263123e-01
    z[0,1,1]  R98       0.436414510011673
    z[0,1,1]  R99       5.1943540573120117e-01
    z[0,1,1]  R100      3.0021563172340393e-01
    z[0,1,1]  R101      -1.1087644845247269e-02
    z[0,1,1]  R102      -4.4893079996109009e-01
    z[0,1,1]  R103      2.4222756922245026e-01
    z[0,1,1]  R104      7.0605480670928955e-01
    z[0,1,1]  R105      2.8052747249603271e-01
    z[0,1,1]  R106      0.141468808054924
    z[0,1,1]  R107      5.7313489913940430e-01
    z[0,1,1]  R108      0.757927417755127
    z[0,1,1]  R109      1.2237020581960678e-01
    z[0,1,1]  R110      -4.8806208372116089e-01
    z[0,1,1]  R111      -3.4369107335805893e-02
    z[0,1,1]  R112      -2.7779793739318848e-01
    z[0,1,1]  R113      3.0863738059997559e-01
    z[0,1,1]  R114      1.4711010456085205e-01
    z[0,1,1]  R115      3.1626126170158386e-01
    z[0,1,1]  R116      -2.4398358166217804e-01
    z[0,1,1]  R117      -6.4226680994033813e-01
    z[0,1,1]  R118      1.4490969479084015e-01
    z[0,1,1]  R119      -0.508252739906311
    z[0,1,1]  R120      3.9389175176620483e-01
    z[0,1,1]  R121      -3.8466867804527283e-01
    z[0,1,1]  R122      3.8059738278388977e-01
    z[0,1,1]  R123      5.1676928997039795e-03
    z[0,1,1]  R124      3.6710596084594727e-01
    z[0,1,1]  R125      2.5813370943069458e-01
    z[0,1,1]  R126      -1.7019649967551231e-02
    z[0,1,1]  R127      -9.6564933657646179e-02
    z[0,1,1]  R128      3.7928631901741028e-01
    z[0,1,1]  R129      -1.8180562555789948e-01
    z[0,1,1]  R130      5.2720570564270020e-01
    z[0,1,1]  R131      -1.1440214514732361e-01
    z[0,1,1]  R132      -1.3806633651256561e-01
    z[0,1,1]  R133      1.2277326732873917e-01
    z[0,1,1]  R134      3.2525521516799927e-01
    z[0,1,1]  R135      5.1913678646087646e-01
    z[0,1,1]  R136      2.8732863068580627e-01
    z[0,1,1]  R137      1.3171996176242828e-01
    z[0,1,1]  R138      -4.1761600971221924e-01
    z[0,1,1]  R139      -0.0854039341211319
    z[0,1,1]  R140      5.4671216756105423e-02
    z[0,1,1]  R141      2.5702759623527527e-01
    z[0,1,1]  R142      -1.1032313853502274e-01
    z[0,1,1]  R143      2.2009618580341339e-01
    z[0,1,1]  R144      -5.0603024661540985e-02
    z[0,1,1]  R145      1.2957285344600677e-01
    z[0,1,1]  R146      -5.9226787090301514e-01
    z[0,1,1]  R147      -5.5985063314437866e-01
    z[0,1,1]  R148      3.9658987522125244e-01
    z[0,1,1]  R149      3.3228096365928650e-01
    z[0,1,1]  R150      2.4429461359977722e-01
    z[0,1,1]  R151      4.4257181882858276e-01
    z[0,1,1]  R152      2.6678934693336487e-01
    z[0,1,1]  R153      2.8248181939125061e-01
    z[0,1,1]  R154      3.1439480185508728e-01
    z[0,1,1]  R155      3.0521667003631592e-01
    z[0,1,1]  R156      2.9148623347282410e-01
    z[0,1,1]  R157      4.8344865441322327e-01
    z[0,1,1]  R158      7.9831188917160034e-01
    z[0,1,1]  R159      3.5552966594696045e-01
    z[0,1,1]  R160      -5.0519472360610962e-01
    z[0,1,1]  R161      -7.0010378956794739e-02
    z[0,1,1]  R162      -3.7174528837203979e-01
    z[0,1,1]  R163      -5.6620782613754272e-01
    z[0,1,1]  R164      3.1890600919723511e-01
    z[0,1,1]  R165      -9.6032015979290009e-02
    z[0,1,1]  R166      -8.3104193210601807e-01
    z[0,1,1]  R167      -2.6378947496414185e-01
    z[0,1,1]  R168      7.5350910425186157e-01
    z[0,1,1]  R169      1.5285126864910126e-01
    z[0,1,1]  R170      2.2692620754241943e-02
    z[0,1,1]  R171      -1.4521090686321259e-01
    z[0,1,1]  R172      -9.3496374785900116e-02
    z[0,1,1]  R173      -4.4312536716461182e-02
    z[0,1,1]  R174      -9.4921454787254333e-02
    z[0,1,1]  R175      -4.1695181280374527e-02
    z[0,1,1]  R176      -2.3240816593170166e-01
    z[0,1,1]  R177      -0.521371066570282
    z[0,1,1]  R178      5.1249540410935879e-03
    z[0,1,1]  R179      -5.0348155200481415e-02
    z[0,1,1]  R180      -1.5467119216918945e-01
    z[0,1,1]  R181      1.0522312484681606e-02
    z[0,1,1]  R182      -3.1535571813583374e-01
    z[0,1,1]  R183      2.9513699933886528e-02
    z[0,1,1]  R184      -3.4852899610996246e-02
    z[0,1,1]  R185      -4.8090791702270508e-01
    z[0,1,1]  R186      -4.9988901615142822e-01
    z[0,1,1]  R187      -6.3789361715316772e-01
    z[0,1,2]  R4        -1
    z[0,1,2]  R13       1
    z[0,1,2]  R78       -1
    z[0,1,2]  R79       1
    z[0,1,2]  R88       -7.5717502832412720e-01
    z[0,1,2]  R89       -5.6900328397750854e-01
    z[0,1,2]  R90       -3.2385990023612976e-01
    z[0,1,2]  R91       3.2324889302253723e-01
    z[0,1,2]  R92       -2.2880828380584717e-01
    z[0,1,2]  R93       2.3817861452698708e-02
    z[0,1,2]  R94       -5.9765762090682983e-01
    z[0,1,2]  R95       9.3544498085975647e-02
    z[0,1,2]  R96       1.4512469060719013e-02
    z[0,1,2]  R97       -5.7201376184821129e-03
    z[0,1,2]  R98       -2.1587004885077477e-03
    z[0,1,2]  R99       1.3724106363952160e-02
    z[0,1,2]  R100      -1.7262664437294006e-01
    z[0,1,2]  R101      2.0977419614791870e-01
    z[0,1,2]  R102      6.6898196935653687e-02
    z[0,1,2]  R103      2.9794535040855408e-01
    z[0,1,2]  R104      -1.7164038121700287e-01
    z[0,1,2]  R105      -3.8066305220127106e-02
    z[0,1,2]  R106      3.0879396200180054e-01
    z[0,1,2]  R107      6.9130671024322510e-01
    z[0,1,2]  R108      3.0642521381378174e-01
    z[0,1,2]  R109      7.1892279386520386e-01
    z[0,1,2]  R110      -7.8089058399200439e-02
    z[0,1,2]  R111      4.7867175936698914e-01
    z[0,1,2]  R112      -2.0526094734668732e-01
    z[0,1,2]  R113      8.8499084115028381e-02
    z[0,1,2]  R114      1.3336643576622009e-01
    z[0,1,2]  R115      9.0247161686420441e-02
    z[0,1,2]  R116      -3.9138570427894592e-01
    z[0,1,2]  R117      7.0476770401000977e-02
    z[0,1,2]  R118      -1.7431662976741791e-01
    z[0,1,2]  R119      -1.4511856436729431e-01
    z[0,1,2]  R120      -4.9307456612586975e-01
    z[0,1,2]  R121      -1.3726910948753357e-01
    z[0,1,2]  R122      -2.3731899261474609e-01
    z[0,1,2]  R123      1.1613065004348755e-01
    z[0,1,2]  R124      2.5074377655982971e-01
    z[0,1,2]  R125      -1.1884884536266327e-01
    z[0,1,2]  R126      -2.7144595980644226e-02
    z[0,1,2]  R127      1.6922371461987495e-02
    z[0,1,2]  R128      -0.386527419090271
    z[0,1,2]  R129      -4.6282148361206055e-01
    z[0,1,2]  R130      3.1402400135993958e-01
    z[0,1,2]  R131      -9.9856235086917877e-02
    z[0,1,2]  R132      4.0449555963277817e-02
    z[0,1,2]  R133      3.7255486845970154e-01
    z[0,1,2]  R134      3.8669133186340332e-01
    z[0,1,2]  R135      4.9616372585296631e-01
    z[0,1,2]  R136      2.7691638469696045e-01
    z[0,1,2]  R137      3.2598786056041718e-02
    z[0,1,2]  R138      -2.6528376340866089e-01
    z[0,1,2]  R139      -3.4190118312835693e-01
    z[0,1,2]  R140      3.9620009064674377e-01
    z[0,1,2]  R141      -2.5621235370635986e-01
    z[0,1,2]  R142      2.4623025953769684e-01
    z[0,1,2]  R143      -4.5212548971176147e-01
    z[0,1,2]  R144      0.541815459728241
    z[0,1,2]  R145      2.0388497412204742e-01
    z[0,1,2]  R146      0.115140900015831
    z[0,1,2]  R147      1.3454304635524750e-01
    z[0,1,2]  R148      1.2885268032550812e-01
    z[0,1,2]  R149      1.4797152578830719e-01
    z[0,1,2]  R150      7.6367869973182678e-02
    z[0,1,2]  R151      1.0282432287931442e-01
    z[0,1,2]  R152      4.6960480511188507e-02
    z[0,1,2]  R153      -1.8596945703029633e-01
    z[0,1,2]  R154      1.6917736828327179e-01
    z[0,1,2]  R155      1.0263492166996002e-01
    z[0,1,2]  R156      -1.2520714104175568e-01
    z[0,1,2]  R157      0.291836678981781
    z[0,1,2]  R158      0.0642719641327858
    z[0,1,2]  R159      -6.8011187016963959e-02
    z[0,1,2]  R160      -1.1339828372001648e-01
    z[0,1,2]  R161      -7.1803522109985352e-01
    z[0,1,2]  R162      -9.6472300589084625e-02
    z[0,1,2]  R163      8.3359532058238983e-02
    z[0,1,2]  R164      4.7368472814559937e-01
    z[0,1,2]  R165      -1.4865960180759430e-01
    z[0,1,2]  R166      -3.7821326404809952e-03
    z[0,1,2]  R167      -9.9031753838062286e-02
    z[0,1,2]  R168      3.6033112555742264e-02
    z[0,1,2]  R169      4.8918455839157104e-01
    z[0,1,2]  R170      2.5622749328613281e-01
    z[0,1,2]  R171      1.3521020114421844e-01
    z[0,1,2]  R172      4.4283643364906311e-01
    z[0,1,2]  R173      -1.9770139455795288e-01
    z[0,1,2]  R174      7.4132215976715088e-01
    z[0,1,2]  R175      2.6134006679058075e-02
    z[0,1,2]  R176      2.2976528108119965e-01
    z[0,1,2]  R177      2.9996795579791069e-02
    z[0,1,2]  R178      1.0451861470937729e-01
    z[0,1,2]  R179      5.2703902125358582e-02
    z[0,1,2]  R180      1.2970089912414551e-01
    z[0,1,2]  R181      -1.4823801815509796e-01
    z[0,1,2]  R182      7.5197708792984486e-03
    z[0,1,2]  R183      3.6111307144165039e-01
    z[0,1,2]  R184      1.5699344873428345e-01
    z[0,1,2]  R185      7.2317175567150116e-02
    z[0,1,2]  R186      2.7384883165359497e-01
    z[0,1,2]  R187      4.4822001457214355e-01
    z[0,1,3]  R5        -1
    z[0,1,3]  R14       1
    z[0,1,3]  R80       -1
    z[0,1,3]  R81       1
    z[0,1,3]  R88       4.4498935341835022e-01
    z[0,1,3]  R89       1.3671043515205383e-01
    z[0,1,3]  R90       3.5809266567230225e-01
    z[0,1,3]  R91       -6.9943493604660034e-01
    z[0,1,3]  R92       7.0330011844635010e-01
    z[0,1,3]  R93       -7.9711538553237915e-01
    z[0,1,3]  R94       -5.2426481246948242e-01
    z[0,1,3]  R95       2.8820842504501343e-01
    z[0,1,3]  R96       -7.1607358753681183e-02
    z[0,1,3]  R97       1.1428820900619030e-02
    z[0,1,3]  R98       7.1843981742858887e-01
    z[0,1,3]  R99       0.767024576663971
    z[0,1,3]  R100      5.2506107091903687e-01
    z[0,1,3]  R101      7.8709018230438232e-01
    z[0,1,3]  R102      3.2510581612586975e-01
    z[0,1,3]  R103      -2.4433358013629913e-01
    z[0,1,3]  R104      -2.2244943678379059e-01
    z[0,1,3]  R105      -2.4872237443923950e-01
    z[0,1,3]  R106      -4.7648698091506958e-02
    z[0,1,3]  R107      -2.8952676802873611e-02
    z[0,1,3]  R108      -1.7613938450813293e-01
    z[0,1,3]  R109      -1.9964993000030518e-01
    z[0,1,3]  R110      0.169372096657753
    z[0,1,3]  R111      -5.0430363416671753e-01
    z[0,1,3]  R112      1.3047042489051819e-01
    z[0,1,3]  R113      -3.4408786892890930e-01
    z[0,1,3]  R114      -5.6352108716964722e-01
    z[0,1,3]  R115      -6.3955657184123993e-02
    z[0,1,3]  R116      -1.8583008646965027e-01
    z[0,1,3]  R117      -4.5038792490959167e-01
    z[0,1,3]  R118      6.7879599332809448e-01
    z[0,1,3]  R119      4.0666261315345764e-01
    z[0,1,3]  R120      3.0813366174697876e-01
    z[0,1,3]  R121      1.2624089419841766e-01
    z[0,1,3]  R122      3.4994545578956604e-01
    z[0,1,3]  R123      -3.4447062015533447e-01
    z[0,1,3]  R124      -2.2915521264076233e-01
    z[0,1,3]  R125      -7.4665099382400513e-01
    z[0,1,3]  R126      -6.8823331594467163e-01
    z[0,1,3]  R127      3.6833325028419495e-01
    z[0,1,3]  R128      2.7590623497962952e-01
    z[0,1,3]  R129      3.2269775867462158e-01
    z[0,1,3]  R130      0.033777866512537
    z[0,1,3]  R131      4.5802673697471619e-01
    z[0,1,3]  R132      5.2076929807662964e-01
    z[0,1,3]  R133      -4.4654447585344315e-02
    z[0,1,3]  R134      -1.7903535068035126e-01
    z[0,1,3]  R135      -8.9750796556472778e-02
    z[0,1,3]  R136      -2.9387819766998291e-01
    z[0,1,3]  R137      -8.5171580314636230e-01
    z[0,1,3]  R138      5.4771190881729126e-01
    z[0,1,3]  R139      3.6372488737106323e-01
    z[0,1,3]  R140      -4.1303125023841858e-01
    z[0,1,3]  R141      -5.3499639034271240e-01
    z[0,1,3]  R142      -5.0670784711837769e-01
    z[0,1,3]  R143      -5.1254862546920776e-01
    z[0,1,3]  R144      -4.2260074615478516e-01
    z[0,1,3]  R145      2.6115423440933228e-01
    z[0,1,3]  R146      -3.1107750535011292e-01
    z[0,1,3]  R147      -4.1094040870666504e-01
    z[0,1,3]  R148      3.0141115188598633e-01
    z[0,1,3]  R149      2.4837906658649445e-01
    z[0,1,3]  R150      4.5430219173431396e-01
    z[0,1,3]  R151      1.1281071603298187e-01
    z[0,1,3]  R152      -6.9318228960037231e-01
    z[0,1,3]  R153      7.7586674690246582e-01
    z[0,1,3]  R154      1.8007653951644897e-01
    z[0,1,3]  R155      1.1757089197635651e-01
    z[0,1,3]  R156      8.4759509563446045e-01
    z[0,1,3]  R157      -0.662113606929779
    z[0,1,3]  R158      -1.7191989719867706e-01
    z[0,1,3]  R159      1.4346306025981903e-01
    z[0,1,3]  R160      -1.5986124053597450e-03
    z[0,1,3]  R161      -7.7496804296970367e-02
    z[0,1,3]  R162      -3.5832509398460388e-01
    z[0,1,3]  R163      -4.2696484923362732e-01
    z[0,1,3]  R164      -4.8628427088260651e-02
    z[0,1,3]  R165      -4.4954848289489746e-01
    z[0,1,3]  R166      4.5265042781829834e-01
    z[0,1,3]  R167      -2.2668300569057465e-01
    z[0,1,3]  R168      3.5406373441219330e-02
    z[0,1,3]  R169      -5.3441369533538818e-01
    z[0,1,3]  R170      -6.8717229366302490e-01
    z[0,1,3]  R171      -2.2073395550251007e-01
    z[0,1,3]  R172      -3.3366686105728149e-01
    z[0,1,3]  R173      1.7880079150199890e-01
    z[0,1,3]  R174      -8.5172258317470551e-02
    z[0,1,3]  R175      -1.1860412359237671e-01
    z[0,1,3]  R176      -7.0354276895523071e-01
    z[0,1,3]  R177      6.8548142910003662e-01
    z[0,1,3]  R178      -1.5521142631769180e-02
    z[0,1,3]  R179      3.5324998199939728e-02
    z[0,1,3]  R180      -3.2179304957389832e-01
    z[0,1,3]  R181      -1.7192016541957855e-01
    z[0,1,3]  R182      -4.1844853758811951e-01
    z[0,1,3]  R183      -5.6576901674270630e-01
    z[0,1,3]  R184      -4.7636792063713074e-01
    z[0,1,3]  R185      7.9875022172927856e-01
    z[0,1,3]  R186      0.661388099193573
    z[0,1,3]  R187      5.9479230642318726e-01
    z[0,1,4]  R6        -1
    z[0,1,4]  R15       1
    z[0,1,4]  R82       -1
    z[0,1,4]  R83       1
    z[0,1,4]  R88       5.4954297840595245e-02
    z[0,1,4]  R89       -0.292703777551651
    z[0,1,4]  R90       -5.3515750169754028e-01
    z[0,1,4]  R91       1.4074082672595978e-01
    z[0,1,4]  R92       -3.4535288810729980e-01
    z[0,1,4]  R93       2.1173091232776642e-01
    z[0,1,4]  R94       3.1077867746353149e-01
    z[0,1,4]  R95       -9.2578649520874023e-02
    z[0,1,4]  R96       -1.6210518777370453e-01
    z[0,1,4]  R97       1.8958781659603119e-01
    z[0,1,4]  R98       0.085997074842453
    z[0,1,4]  R99       2.2456325590610504e-01
    z[0,1,4]  R100      -5.9939321363344789e-04
    z[0,1,4]  R101      -5.8068487793207169e-02
    z[0,1,4]  R102      3.3228802680969238e-01
    z[0,1,4]  R103      -3.1062791123986244e-02
    z[0,1,4]  R104      2.4182732403278351e-01
    z[0,1,4]  R105      5.8144098520278931e-01
    z[0,1,4]  R106      5.7347220182418823e-01
    z[0,1,4]  R107      -4.6587616205215454e-02
    z[0,1,4]  R108      -2.3897903040051460e-02
    z[0,1,4]  R109      9.1737970709800720e-02
    z[0,1,4]  R110      3.5825878381729126e-02
    z[0,1,4]  R111      0.216657355427742
    z[0,1,4]  R112      2.2498093545436859e-01
    z[0,1,4]  R113      5.3508430719375610e-01
    z[0,1,4]  R114      -1.2030213326215744e-01
    z[0,1,4]  R115      -1.2941746413707733e-01
    z[0,1,4]  R116      1.9787830114364624e-01
    z[0,1,4]  R117      -3.0504795908927917e-01
    z[0,1,4]  R118      -6.3864976167678833e-01
    z[0,1,4]  R119      1.7508701980113983e-01
    z[0,1,4]  R120      5.2330672740936279e-02
    z[0,1,4]  R121      6.1832553148269653e-01
    z[0,1,4]  R122      2.3572294414043427e-01
    z[0,1,4]  R123      5.8638691902160645e-02
    z[0,1,4]  R124      6.9978588819503784e-01
    z[0,1,4]  R125      1.9350986927747726e-02
    z[0,1,4]  R126      6.7504072189331055e-01
    z[0,1,4]  R127      -3.2833638787269592e-01
    z[0,1,4]  R128      3.6444410681724548e-01
    z[0,1,4]  R129      4.1179046034812927e-01
    z[0,1,4]  R130      1.9429470598697662e-01
    z[0,1,4]  R131      4.8103532195091248e-01
    z[0,1,4]  R132      4.8666661977767944e-01
    z[0,1,4]  R133      4.8793444037437439e-01
    z[0,1,4]  R134      6.0222244262695312e-01
    z[0,1,4]  R135      2.1910466253757477e-01
    z[0,1,4]  R136      6.6941720247268677e-01
    z[0,1,4]  R137      1.2802883982658386e-02
    z[0,1,4]  R138      -2.1214410662651062e-01
    z[0,1,4]  R139      3.2606017589569092e-01
    z[0,1,4]  R140      4.3784341216087341e-01
    z[0,1,4]  R141      4.1435211896896362e-01
    z[0,1,4]  R142      0.459890216588974
    z[0,1,4]  R143      1.0586746037006378e-01
    z[0,1,4]  R144      9.8830088973045349e-02
    z[0,1,4]  R145      2.2619621828198433e-02
    z[0,1,4]  R146      1.8653546273708344e-01
    z[0,1,4]  R147      1.4439335465431213e-01
    z[0,1,4]  R148      -2.9206001758575439e-01
    z[0,1,4]  R149      -7.0369493961334229e-01
    z[0,1,4]  R150      -8.2094132900238037e-01
    z[0,1,4]  R151      -4.4653770327568054e-01
    z[0,1,4]  R152      4.6243643760681152e-01
    z[0,1,4]  R153      9.2762112617492676e-02
    z[0,1,4]  R154      -6.5023016929626465e-01
    z[0,1,4]  R155      -1.6071267426013947e-01
    z[0,1,4]  R156      -1.6083371639251709e-01
    z[0,1,4]  R157      -3.4067001193761826e-02
    z[0,1,4]  R158      -5.6334905326366425e-02
    z[0,1,4]  R159      3.6259177327156067e-01
    z[0,1,4]  R160      -1.3728362321853638e-01
    z[0,1,4]  R161      -1.4447632431983948e-01
    z[0,1,4]  R162      -3.4708479046821594e-01
    z[0,1,4]  R163      1.3537852466106415e-01
    z[0,1,4]  R164      0.483398973941803
    z[0,1,4]  R165      0.0651547759771347
    z[0,1,4]  R166      8.4052875638008118e-02
    z[0,1,4]  R167      -3.0271375179290771e-01
    z[0,1,4]  R168      1.9041784107685089e-01
    z[0,1,4]  R169      2.8257763385772705e-01
    z[0,1,4]  R170      -1.8381620943546295e-01
    z[0,1,4]  R171      0.564232587814331
    z[0,1,4]  R172      3.5421684384346008e-02
    z[0,1,4]  R173      1.3294674456119537e-01
    z[0,1,4]  R174      0.234371617436409
    z[0,1,4]  R175      0.568893551826477
    z[0,1,4]  R176      0.133975088596344
    z[0,1,4]  R177      1.1157119274139404e-01
    z[0,1,4]  R178      1.0607088357210159e-01
    z[0,1,4]  R179      3.3143392205238342e-01
    z[0,1,4]  R180      2.0969532430171967e-01
    z[0,1,4]  R181      5.9639763832092285e-01
    z[0,1,4]  R182      3.5192811489105225e-01
    z[0,1,4]  R183      2.6111885905265808e-01
    z[0,1,4]  R184      -1.3108791410923004e-01
    z[0,1,4]  R185      -6.9482550024986267e-02
    z[0,1,4]  R186      -0.196515291929245
    z[0,1,4]  R187      -1.0311304032802582e-01
    z[0,1,5]  R7        -1
    z[0,1,5]  R16       1
    z[0,1,5]  R84       -1
    z[0,1,5]  R85       1
    z[0,1,5]  R88       9.3472130596637726e-02
    z[0,1,5]  R89       -2.8760486841201782e-01
    z[0,1,5]  R90       -1.0530462861061096e-01
    z[0,1,5]  R91       -0.210502028465271
    z[0,1,5]  R92       -2.9261013865470886e-01
    z[0,1,5]  R93       1.0185271501541138e-01
    z[0,1,5]  R94       -7.6998159289360046e-02
    z[0,1,5]  R95       0.0739939957857132
    z[0,1,5]  R96       1.3512995839118958e-01
    z[0,1,5]  R97       -2.1873018145561218e-01
    z[0,1,5]  R98       -1.1372113227844238e-01
    z[0,1,5]  R99       1.7365668714046478e-01
    z[0,1,5]  R100      -3.2546716928482056e-01
    z[0,1,5]  R101      4.6810904145240784e-01
    z[0,1,5]  R102      4.4914358854293823e-01
    z[0,1,5]  R103      5.4180693626403809e-01
    z[0,1,5]  R104      3.6623695492744446e-01
    z[0,1,5]  R105      5.0960993766784668e-01
    z[0,1,5]  R106      4.5797964930534363e-01
    z[0,1,5]  R107      2.2607523202896118e-01
    z[0,1,5]  R108      8.1245154142379761e-02
    z[0,1,5]  R109      9.6389196813106537e-02
    z[0,1,5]  R110      1.4512623846530914e-01
    z[0,1,5]  R111      2.5685855746269226e-01
    z[0,1,5]  R112      -0.00919504277408123
    z[0,1,5]  R113      -2.5343004614114761e-02
    z[0,1,5]  R114      5.7502931356430054e-01
    z[0,1,5]  R115      5.5157393217086792e-01
    z[0,1,5]  R116      -7.3285329341888428e-01
    z[0,1,5]  R117      1.9364964962005615e-01
    z[0,1,5]  R118      -2.7174144983291626e-01
    z[0,1,5]  R119      2.1307614445686340e-01
    z[0,1,5]  R120      -5.9353464841842651e-01
    z[0,1,5]  R121      3.0460536479949951e-01
    z[0,1,5]  R122      -1.2907807528972626e-01
    z[0,1,5]  R123      3.7310361862182617e-01
    z[0,1,5]  R124      1.1365479789674282e-02
    z[0,1,5]  R125      5.0871992111206055e-01
    z[0,1,5]  R126      1.0228655487298965e-01
    z[0,1,5]  R127      2.0482501387596130e-01
    z[0,1,5]  R128      -5.4149203933775425e-03
    z[0,1,5]  R129      -1.4895612001419067e-01
    z[0,1,5]  R130      2.4774929881095886e-01
    z[0,1,5]  R131      0.414351224899292
    z[0,1,5]  R132      5.1882648468017578e-01
    z[0,1,5]  R133      6.0031764209270477e-02
    z[0,1,5]  R134      4.5026890933513641e-02
    z[0,1,5]  R135      -2.1462911367416382e-01
    z[0,1,5]  R136      -1.7139786854386330e-02
    z[0,1,5]  R137      3.8179942965507507e-01
    z[0,1,5]  R138      -8.0481000244617462e-02
    z[0,1,5]  R139      -2.2721394896507263e-01
    z[0,1,5]  R140      -7.8569419682025909e-02
    z[0,1,5]  R141      4.0004798769950867e-01
    z[0,1,5]  R142      5.0161701440811157e-01
    z[0,1,5]  R143      -3.4265366196632385e-01
    z[0,1,5]  R144      5.0114601850509644e-01
    z[0,1,5]  R145      6.5542924404144287e-01
    z[0,1,5]  R146      -3.7773460149765015e-01
    z[0,1,5]  R147      -6.4229391515254974e-02
    z[0,1,5]  R148      -0.16961570084095
    z[0,1,5]  R149      -3.6109413951635361e-02
    z[0,1,5]  R150      -5.2790228277444839e-02
    z[0,1,5]  R151      -6.3004577159881592e-01
    z[0,1,5]  R152      -2.7320614457130432e-01
    z[0,1,5]  R153      -1.2381795793771744e-01
    z[0,1,5]  R154      -5.9111952781677246e-01
    z[0,1,5]  R155      7.3343284428119659e-02
    z[0,1,5]  R156      -1.9130037724971771e-01
    z[0,1,5]  R157      -1.9146957993507385e-01
    z[0,1,5]  R158      4.3890848755836487e-01
    z[0,1,5]  R159      7.4039161205291748e-01
    z[0,1,5]  R160      -1.0637371987104416e-01
    z[0,1,5]  R161      -1.7951239645481110e-01
    z[0,1,5]  R162      1.9836017489433289e-01
    z[0,1,5]  R163      -3.6952443420886993e-02
    z[0,1,5]  R164      -4.4627869129180908e-01
    z[0,1,5]  R165      -1.9919851422309875e-01
    z[0,1,5]  R166      -5.9514995664358139e-03
    z[0,1,5]  R167      4.3356409668922424e-01
    z[0,1,5]  R168      -5.4642057418823242e-01
    z[0,1,5]  R169      -1.7104054987430573e-01
    z[0,1,5]  R170      -2.1577434241771698e-01
    z[0,1,5]  R171      -9.4331823289394379e-02
    z[0,1,5]  R172      -2.9091143608093262e-01
    z[0,1,5]  R173      1.9863104820251465e-01
    z[0,1,5]  R174      -2.0626686513423920e-02
    z[0,1,5]  R175      -3.2981079816818237e-01
    z[0,1,5]  R176      -7.5890876352787018e-02
    z[0,1,5]  R177      -2.1043565869331360e-01
    z[0,1,5]  R178      0.0350484624505043
    z[0,1,5]  R179      -1.2076556682586670e-01
    z[0,1,5]  R180      -4.7361978888511658e-01
    z[0,1,5]  R181      -6.5594747662544250e-02
    z[0,1,5]  R182      2.2551345825195312e-01
    z[0,1,5]  R183      -1.9245958328247070e-01
    z[0,1,5]  R184      3.8899150490760803e-01
    z[0,1,5]  R185      9.7562968730926514e-02
    z[0,1,5]  R186      3.4499558806419373e-01
    z[0,1,5]  R187      -1.3019940257072449e-01
    z[0,1,6]  R8        -1
    z[0,1,6]  R17       1
    z[0,1,6]  R86       -1
    z[0,1,6]  R87       1
    z[0,1,6]  R88       -0.0673435777425766
    z[0,1,6]  R89       -1.7936335643753409e-03
    z[0,1,6]  R90       1.7409424483776093e-01
    z[0,1,6]  R91       -5.3414665162563324e-03
    z[0,1,6]  R92       3.3141264319419861e-01
    z[0,1,6]  R93       -5.2414262294769287e-01
    z[0,1,6]  R94       -5.2139669656753540e-02
    z[0,1,6]  R95       -8.5269182920455933e-01
    z[0,1,6]  R96       8.5546606779098511e-01
    z[0,1,6]  R97       -8.5245013236999512e-01
    z[0,1,6]  R98       1.6156622441485524e-03
    z[0,1,6]  R99       -1.8238635361194611e-01
    z[0,1,6]  R100      -4.7673216462135315e-01
    z[0,1,6]  R101      8.9506246149539948e-02
    z[0,1,6]  R102      1.1546920053660870e-02
    z[0,1,6]  R103      2.0072972774505615e-01
    z[0,1,6]  R104      2.2112131118774414e-01
    z[0,1,6]  R105      -2.7132892608642578e-01
    z[0,1,6]  R106      -1.6090519726276398e-01
    z[0,1,6]  R107      2.9249426722526550e-01
    z[0,1,6]  R108      2.3772367835044861e-01
    z[0,1,6]  R109      -5.8585498481988907e-02
    z[0,1,6]  R110      -6.6637277603149414e-01
    z[0,1,6]  R111      4.8056635260581970e-01
    z[0,1,6]  R112      8.0901491641998291e-01
    z[0,1,6]  R113      6.4526760578155518e-01
    z[0,1,6]  R114      -4.8482260107994080e-01
    z[0,1,6]  R115      -6.0944944620132446e-01
    z[0,1,6]  R116      6.0640677809715271e-02
    z[0,1,6]  R117      2.3719212040305138e-03
    z[0,1,6]  R118      -2.0107524469494820e-02
    z[0,1,6]  R119      5.7631272822618484e-02
    z[0,1,6]  R120      3.5792794823646545e-01
    z[0,1,6]  R121      -1.2092448025941849e-01
    z[0,1,6]  R122      7.7706307172775269e-01
    z[0,1,6]  R123      -3.0535668134689331e-01
    z[0,1,6]  R124      -2.9610633850097656e-01
    z[0,1,6]  R125      -1.9181586802005768e-01
    z[0,1,6]  R126      -1.4269690960645676e-02
    z[0,1,6]  R127      8.1576997041702271e-01
    z[0,1,6]  R128      5.9415036439895630e-01
    z[0,1,6]  R129      -0.299562931060791
    z[0,1,6]  R130      5.5895466357469559e-02
    z[0,1,6]  R131      5.3392875194549561e-01
    z[0,1,6]  R132      -2.7288362383842468e-02
    z[0,1,6]  R133      0.0652148649096489
    z[0,1,6]  R134      2.5560066103935242e-01
    z[0,1,6]  R135      -1.4847627282142639e-01
    z[0,1,6]  R136      -2.4474053084850311e-01
    z[0,1,6]  R137      3.7038065493106842e-02
    z[0,1,6]  R138      0.062696672976017
    z[0,1,6]  R139      2.6157614588737488e-01
    z[0,1,6]  R140      1.6548979282379150e-01
    z[0,1,6]  R141      2.1999673545360565e-01
    z[0,1,6]  R142      -2.5295352935791016e-01
    z[0,1,6]  R143      -3.0259797349572182e-02
    z[0,1,6]  R144      -4.4072309136390686e-01
    z[0,1,6]  R145      -1.1679602414369583e-01
    z[0,1,6]  R146      2.9156479239463806e-01
    z[0,1,6]  R147      4.9602559208869934e-01
    z[0,1,6]  R148      -2.4655713140964508e-01
    z[0,1,6]  R149      -4.1694027185440063e-01
    z[0,1,6]  R150      -1.7547542229294777e-02
    z[0,1,6]  R151      -3.0434769392013550e-01
    z[0,1,6]  R152      -3.6931043863296509e-01
    z[0,1,6]  R153      -8.2689769566059113e-02
    z[0,1,6]  R154      2.4606725573539734e-01
    z[0,1,6]  R155      9.0966427326202393e-01
    z[0,1,6]  R156      -1.6713818907737732e-01
    z[0,1,6]  R157      -2.6994574069976807e-01
    z[0,1,6]  R158      1.7012619972229004e-01
    z[0,1,6]  R159      -7.5329937040805817e-02
    z[0,1,6]  R160      5.2180871367454529e-02
    z[0,1,6]  R161      -4.0868866443634033e-01
    z[0,1,6]  R162      3.8819864392280579e-01
    z[0,1,6]  R163      1.3943642377853394e-01
    z[0,1,6]  R164      3.8652750849723816e-01
    z[0,1,6]  R165      5.6078654527664185e-01
    z[0,1,6]  R166      2.5621561333537102e-02
    z[0,1,6]  R167      -5.8213543891906738e-01
    z[0,1,6]  R168      -2.3434561491012573e-01
    z[0,1,6]  R169      -2.3424968123435974e-01
    z[0,1,6]  R170      1.1174045503139496e-01
    z[0,1,6]  R171      2.7887317538261414e-01
    z[0,1,6]  R172      4.8269498348236084e-01
    z[0,1,6]  R173      -4.0791699290275574e-01
    z[0,1,6]  R174      3.9846265316009521e-01
    z[0,1,6]  R175      3.9806911349296570e-01
    z[0,1,6]  R176      4.9638313055038452e-01
    z[0,1,6]  R177      1.7675362527370453e-01
    z[0,1,6]  R178      6.2091845273971558e-01
    z[0,1,6]  R179      4.9711546301841736e-01
    z[0,1,6]  R180      7.2336748242378235e-02
    z[0,1,6]  R181      2.6968801021575928e-01
    z[0,1,6]  R182      -4.3976327776908875e-01
    z[0,1,6]  R183      6.4820420742034912e-01
    z[0,1,6]  R184      -2.0570772886276245e-01
    z[0,1,6]  R185      -1.6415183246135712e-01
    z[0,1,6]  R186      -0.0460810661315918
    z[0,1,6]  R187      9.5752745866775513e-02
    z[1,0,0]  R2        1
    z[1,0,0]  R11       -1
    z[1,0,0]  R188      -1
    z[1,0,0]  R189      1
    z[1,0,0]  R202      7.4860262870788574e-01
    z[1,0,0]  R203      3.6833679676055908e-01
    z[1,0,0]  R204      -2.2596074640750885e-01
    z[1,0,0]  R205      -3.0306759476661682e-01
    z[1,0,0]  R206      -1.4573006331920624e-01
    z[1,0,0]  R207      -0.50286865234375
    z[1,0,0]  R208      -8.5654549300670624e-02
    z[1,0,0]  R209      1.5423680841922760e-01
    z[1,0,0]  R210      -3.0090352892875671e-01
    z[1,0,0]  R211      -3.6334908008575439e-01
    z[1,0,0]  R212      -3.2288312911987305e-01
    z[1,0,0]  R213      4.0381222963333130e-01
    z[1,0,0]  R214      -8.3608108758926392e-01
    z[1,0,0]  R215      -5.0338220596313477e-01
    z[1,0,0]  R216      -6.4310878515243530e-01
    z[1,0,0]  R217      6.7158448696136475e-01
    z[1,0,0]  R218      -2.9885500669479370e-01
    z[1,0,0]  R219      -6.3888782262802124e-01
    z[1,0,0]  R220      3.1097555160522461e-01
    z[1,0,0]  R221      -5.0072693824768066e-01
    z[1,0,0]  R222      -1.9979985058307648e-01
    z[1,0,0]  R223      -5.3643178939819336e-01
    z[1,0,0]  R224      0.607283890247345
    z[1,0,0]  R225      -7.1195596456527710e-01
    z[1,0,0]  R226      -6.0410439968109131e-01
    z[1,0,0]  R227      -8.3872246742248535e-01
    z[1,0,0]  R228      -4.6909371018409729e-01
    z[1,0,0]  R229      6.2660795450210571e-01
    z[1,0,0]  R230      -3.5793432593345642e-01
    z[1,0,0]  R231      4.1159999370574951e-01
    z[1,0,0]  R232      7.6862829923629761e-01
    z[1,0,0]  R233      7.8859555721282959e-01
    z[1,0,0]  R234      0.763009250164032
    z[1,0,0]  R235      -7.1807646751403809e-01
    z[1,0,0]  R236      5.9774047136306763e-01
    z[1,0,0]  R237      -1.5244425833225250e-01
    z[1,0,0]  R238      7.3239183425903320e-01
    z[1,0,0]  R239      2.9017889499664307e-01
    z[1,0,0]  R240      2.7914133667945862e-01
    z[1,0,0]  R241      -4.0742442011833191e-02
    z[1,0,0]  R242      2.6066619157791138e-01
    z[1,0,0]  R243      6.8736499547958374e-01
    z[1,0,0]  R244      -0.263374388217926
    z[1,0,0]  R245      -3.5421472787857056e-01
    z[1,0,0]  R246      -7.9832553863525391e-02
    z[1,0,0]  R247      -1.8112431466579437e-01
    z[1,0,0]  R248      -4.8229244351387024e-01
    z[1,0,0]  R249      -3.9737311005592346e-01
    z[1,0,0]  R250      -3.8635954260826111e-01
    z[1,0,0]  R251      -2.6415404677391052e-01
    z[1,0,0]  R252      -0.52254319190979
    z[1,0,0]  R253      -1.6679821908473969e-01
    z[1,0,0]  R254      -5.2074825763702393e-01
    z[1,0,0]  R255      -3.2534840703010559e-01
    z[1,0,0]  R256      -6.1319935321807861e-01
    z[1,0,0]  R257      -6.7678910493850708e-01
    z[1,0,0]  R258      -4.2548552155494690e-01
    z[1,0,0]  R259      -4.3196880817413330e-01
    z[1,0,0]  R260      -5.6378740072250366e-01
    z[1,0,0]  R261      -2.3224976658821106e-01
    z[1,0,0]  R262      -4.8676493763923645e-01
    z[1,0,0]  R263      -6.3810366392135620e-01
    z[1,0,0]  R264      -5.1050257682800293e-01
    z[1,0,0]  R265      -4.1413670778274536e-01
    z[1,0,0]  R266      -3.9808002114295959e-01
    z[1,0,0]  R267      -2.7420192956924438e-01
    z[1,0,0]  R268      -0.250662624835968
    z[1,0,0]  R269      -4.4196444749832153e-01
    z[1,0,0]  R270      -0.415751576423645
    z[1,0,0]  R271      4.9911633133888245e-01
    z[1,0,0]  R272      -7.5694888830184937e-02
    z[1,0,0]  R273      -6.8983119726181030e-01
    z[1,0,0]  R274      -1.5377275645732880e-01
    z[1,0,0]  R275      -5.7229089736938477e-01
    z[1,0,0]  R276      1.7609516158699989e-02
    z[1,0,0]  R277      -7.9494613409042358e-01
    z[1,0,0]  R278      -4.1513875126838684e-01
    z[1,0,0]  R279      -2.5649663805961609e-01
    z[1,0,0]  R280      -2.4282118678092957e-01
    z[1,0,0]  R281      1.9869744777679443e-01
    z[1,0,0]  R282      3.8046124577522278e-01
    z[1,0,0]  R283      -6.0589760541915894e-01
    z[1,0,0]  R284      -7.2114330530166626e-01
    z[1,0,0]  R285      -2.8105261921882629e-01
    z[1,0,0]  R286      -4.4869899749755859e-01
    z[1,0,0]  R287      -7.7343314886093140e-01
    z[1,0,0]  R288      -5.3159594535827637e-01
    z[1,0,0]  R289      -6.0012131929397583e-01
    z[1,0,0]  R290      -4.9606877565383911e-01
    z[1,0,0]  R291      -0.329940527677536
    z[1,0,0]  R292      -6.3231301307678223e-01
    z[1,0,0]  R293      -7.1913182735443115e-01
    z[1,0,0]  R294      -6.6646450757980347e-01
    z[1,0,0]  R295      -4.4938430190086365e-01
    z[1,0,0]  R296      -3.7860605120658875e-01
    z[1,0,0]  R297      -5.9573411941528320e-01
    z[1,0,0]  R298      -2.6482513546943665e-01
    z[1,0,0]  R299      6.5551483631134033e-01
    z[1,0,0]  R300      5.2602589130401611e-01
    z[1,0,0]  R301      4.7809746861457825e-01
    z[1,0,1]  R3        1
    z[1,0,1]  R12       -1
    z[1,0,1]  R190      -1
    z[1,0,1]  R191      1
    z[1,0,1]  R202      3.9658987522125244e-01
    z[1,0,1]  R203      3.3228096365928650e-01
    z[1,0,1]  R204      2.4429461359977722e-01
    z[1,0,1]  R205      4.4257181882858276e-01
    z[1,0,1]  R206      2.6678934693336487e-01
    z[1,0,1]  R207      2.8248181939125061e-01
    z[1,0,1]  R208      3.1439480185508728e-01
    z[1,0,1]  R209      3.0521667003631592e-01
    z[1,0,1]  R210      2.9148623347282410e-01
    z[1,0,1]  R211      4.8344865441322327e-01
    z[1,0,1]  R212      7.9831188917160034e-01
    z[1,0,1]  R213      3.5552966594696045e-01
    z[1,0,1]  R214      -5.0519472360610962e-01
    z[1,0,1]  R215      -7.0010378956794739e-02
    z[1,0,1]  R216      -3.7174528837203979e-01
    z[1,0,1]  R217      -5.6620782613754272e-01
    z[1,0,1]  R218      3.1890600919723511e-01
    z[1,0,1]  R219      -9.6032015979290009e-02
    z[1,0,1]  R220      -8.3104193210601807e-01
    z[1,0,1]  R221      -2.6378947496414185e-01
    z[1,0,1]  R222      7.5350910425186157e-01
    z[1,0,1]  R223      1.5285126864910126e-01
    z[1,0,1]  R224      2.2692620754241943e-02
    z[1,0,1]  R225      -1.4521090686321259e-01
    z[1,0,1]  R226      -9.3496374785900116e-02
    z[1,0,1]  R227      -4.4312536716461182e-02
    z[1,0,1]  R228      -9.4921454787254333e-02
    z[1,0,1]  R229      -4.1695181280374527e-02
    z[1,0,1]  R230      -2.3240816593170166e-01
    z[1,0,1]  R231      -0.521371066570282
    z[1,0,1]  R232      5.1249540410935879e-03
    z[1,0,1]  R233      -5.0348155200481415e-02
    z[1,0,1]  R234      -1.5467119216918945e-01
    z[1,0,1]  R235      1.0522312484681606e-02
    z[1,0,1]  R236      -3.1535571813583374e-01
    z[1,0,1]  R237      2.9513699933886528e-02
    z[1,0,1]  R238      -3.4852899610996246e-02
    z[1,0,1]  R239      -4.8090791702270508e-01
    z[1,0,1]  R240      -4.9988901615142822e-01
    z[1,0,1]  R241      -6.3789361715316772e-01
    z[1,0,1]  R242      -3.8004130125045776e-01
    z[1,0,1]  R243      1.2914985418319702e-01
    z[1,0,1]  R244      -6.0805189609527588e-01
    z[1,0,1]  R245      4.6549469232559204e-01
    z[1,0,1]  R246      3.6320638656616211e-01
    z[1,0,1]  R247      -3.6114744842052460e-02
    z[1,0,1]  R248      1.7353674769401550e-01
    z[1,0,1]  R249      -9.5659092068672180e-02
    z[1,0,1]  R250      2.6273140311241150e-01
    z[1,0,1]  R251      3.4583482146263123e-01
    z[1,0,1]  R252      0.436414510011673
    z[1,0,1]  R253      5.1943540573120117e-01
    z[1,0,1]  R254      3.0021563172340393e-01
    z[1,0,1]  R255      -1.1087644845247269e-02
    z[1,0,1]  R256      -4.4893079996109009e-01
    z[1,0,1]  R257      2.4222756922245026e-01
    z[1,0,1]  R258      7.0605480670928955e-01
    z[1,0,1]  R259      2.8052747249603271e-01
    z[1,0,1]  R260      0.141468808054924
    z[1,0,1]  R261      5.7313489913940430e-01
    z[1,0,1]  R262      0.757927417755127
    z[1,0,1]  R263      1.2237020581960678e-01
    z[1,0,1]  R264      -4.8806208372116089e-01
    z[1,0,1]  R265      -3.4369107335805893e-02
    z[1,0,1]  R266      -2.7779793739318848e-01
    z[1,0,1]  R267      3.0863738059997559e-01
    z[1,0,1]  R268      1.4711010456085205e-01
    z[1,0,1]  R269      3.1626126170158386e-01
    z[1,0,1]  R270      -2.4398358166217804e-01
    z[1,0,1]  R271      -6.4226680994033813e-01
    z[1,0,1]  R272      1.4490969479084015e-01
    z[1,0,1]  R273      -0.508252739906311
    z[1,0,1]  R274      3.9389175176620483e-01
    z[1,0,1]  R275      -3.8466867804527283e-01
    z[1,0,1]  R276      3.8059738278388977e-01
    z[1,0,1]  R277      5.1676928997039795e-03
    z[1,0,1]  R278      3.6710596084594727e-01
    z[1,0,1]  R279      2.5813370943069458e-01
    z[1,0,1]  R280      -1.7019649967551231e-02
    z[1,0,1]  R281      -9.6564933657646179e-02
    z[1,0,1]  R282      3.7928631901741028e-01
    z[1,0,1]  R283      -1.8180562555789948e-01
    z[1,0,1]  R284      5.2720570564270020e-01
    z[1,0,1]  R285      -1.1440214514732361e-01
    z[1,0,1]  R286      -1.3806633651256561e-01
    z[1,0,1]  R287      1.2277326732873917e-01
    z[1,0,1]  R288      3.2525521516799927e-01
    z[1,0,1]  R289      5.1913678646087646e-01
    z[1,0,1]  R290      2.8732863068580627e-01
    z[1,0,1]  R291      1.3171996176242828e-01
    z[1,0,1]  R292      -4.1761600971221924e-01
    z[1,0,1]  R293      -0.0854039341211319
    z[1,0,1]  R294      5.4671216756105423e-02
    z[1,0,1]  R295      2.5702759623527527e-01
    z[1,0,1]  R296      -1.1032313853502274e-01
    z[1,0,1]  R297      2.2009618580341339e-01
    z[1,0,1]  R298      -5.0603024661540985e-02
    z[1,0,1]  R299      1.2957285344600677e-01
    z[1,0,1]  R300      -5.9226787090301514e-01
    z[1,0,1]  R301      -5.5985063314437866e-01
    z[1,0,2]  R4        1
    z[1,0,2]  R13       -1
    z[1,0,2]  R192      -1
    z[1,0,2]  R193      1
    z[1,0,2]  R202      1.2885268032550812e-01
    z[1,0,2]  R203      1.4797152578830719e-01
    z[1,0,2]  R204      7.6367869973182678e-02
    z[1,0,2]  R205      1.0282432287931442e-01
    z[1,0,2]  R206      4.6960480511188507e-02
    z[1,0,2]  R207      -1.8596945703029633e-01
    z[1,0,2]  R208      1.6917736828327179e-01
    z[1,0,2]  R209      1.0263492166996002e-01
    z[1,0,2]  R210      -1.2520714104175568e-01
    z[1,0,2]  R211      0.291836678981781
    z[1,0,2]  R212      0.0642719641327858
    z[1,0,2]  R213      -6.8011187016963959e-02
    z[1,0,2]  R214      -1.1339828372001648e-01
    z[1,0,2]  R215      -7.1803522109985352e-01
    z[1,0,2]  R216      -9.6472300589084625e-02
    z[1,0,2]  R217      8.3359532058238983e-02
    z[1,0,2]  R218      4.7368472814559937e-01
    z[1,0,2]  R219      -1.4865960180759430e-01
    z[1,0,2]  R220      -3.7821326404809952e-03
    z[1,0,2]  R221      -9.9031753838062286e-02
    z[1,0,2]  R222      3.6033112555742264e-02
    z[1,0,2]  R223      4.8918455839157104e-01
    z[1,0,2]  R224      2.5622749328613281e-01
    z[1,0,2]  R225      1.3521020114421844e-01
    z[1,0,2]  R226      4.4283643364906311e-01
    z[1,0,2]  R227      -1.9770139455795288e-01
    z[1,0,2]  R228      7.4132215976715088e-01
    z[1,0,2]  R229      2.6134006679058075e-02
    z[1,0,2]  R230      2.2976528108119965e-01
    z[1,0,2]  R231      2.9996795579791069e-02
    z[1,0,2]  R232      1.0451861470937729e-01
    z[1,0,2]  R233      5.2703902125358582e-02
    z[1,0,2]  R234      1.2970089912414551e-01
    z[1,0,2]  R235      -1.4823801815509796e-01
    z[1,0,2]  R236      7.5197708792984486e-03
    z[1,0,2]  R237      3.6111307144165039e-01
    z[1,0,2]  R238      1.5699344873428345e-01
    z[1,0,2]  R239      7.2317175567150116e-02
    z[1,0,2]  R240      2.7384883165359497e-01
    z[1,0,2]  R241      4.4822001457214355e-01
    z[1,0,2]  R242      -7.5717502832412720e-01
    z[1,0,2]  R243      -5.6900328397750854e-01
    z[1,0,2]  R244      -3.2385990023612976e-01
    z[1,0,2]  R245      3.2324889302253723e-01
    z[1,0,2]  R246      -2.2880828380584717e-01
    z[1,0,2]  R247      2.3817861452698708e-02
    z[1,0,2]  R248      -5.9765762090682983e-01
    z[1,0,2]  R249      9.3544498085975647e-02
    z[1,0,2]  R250      1.4512469060719013e-02
    z[1,0,2]  R251      -5.7201376184821129e-03
    z[1,0,2]  R252      -2.1587004885077477e-03
    z[1,0,2]  R253      1.3724106363952160e-02
    z[1,0,2]  R254      -1.7262664437294006e-01
    z[1,0,2]  R255      2.0977419614791870e-01
    z[1,0,2]  R256      6.6898196935653687e-02
    z[1,0,2]  R257      2.9794535040855408e-01
    z[1,0,2]  R258      -1.7164038121700287e-01
    z[1,0,2]  R259      -3.8066305220127106e-02
    z[1,0,2]  R260      3.0879396200180054e-01
    z[1,0,2]  R261      6.9130671024322510e-01
    z[1,0,2]  R262      3.0642521381378174e-01
    z[1,0,2]  R263      7.1892279386520386e-01
    z[1,0,2]  R264      -7.8089058399200439e-02
    z[1,0,2]  R265      4.7867175936698914e-01
    z[1,0,2]  R266      -2.0526094734668732e-01
    z[1,0,2]  R267      8.8499084115028381e-02
    z[1,0,2]  R268      1.3336643576622009e-01
    z[1,0,2]  R269      9.0247161686420441e-02
    z[1,0,2]  R270      -3.9138570427894592e-01
    z[1,0,2]  R271      7.0476770401000977e-02
    z[1,0,2]  R272      -1.7431662976741791e-01
    z[1,0,2]  R273      -1.4511856436729431e-01
    z[1,0,2]  R274      -4.9307456612586975e-01
    z[1,0,2]  R275      -1.3726910948753357e-01
    z[1,0,2]  R276      -2.3731899261474609e-01
    z[1,0,2]  R277      1.1613065004348755e-01
    z[1,0,2]  R278      2.5074377655982971e-01
    z[1,0,2]  R279      -1.1884884536266327e-01
    z[1,0,2]  R280      -2.7144595980644226e-02
    z[1,0,2]  R281      1.6922371461987495e-02
    z[1,0,2]  R282      -0.386527419090271
    z[1,0,2]  R283      -4.6282148361206055e-01
    z[1,0,2]  R284      3.1402400135993958e-01
    z[1,0,2]  R285      -9.9856235086917877e-02
    z[1,0,2]  R286      4.0449555963277817e-02
    z[1,0,2]  R287      3.7255486845970154e-01
    z[1,0,2]  R288      3.8669133186340332e-01
    z[1,0,2]  R289      4.9616372585296631e-01
    z[1,0,2]  R290      2.7691638469696045e-01
    z[1,0,2]  R291      3.2598786056041718e-02
    z[1,0,2]  R292      -2.6528376340866089e-01
    z[1,0,2]  R293      -3.4190118312835693e-01
    z[1,0,2]  R294      3.9620009064674377e-01
    z[1,0,2]  R295      -2.5621235370635986e-01
    z[1,0,2]  R296      2.4623025953769684e-01
    z[1,0,2]  R297      -4.5212548971176147e-01
    z[1,0,2]  R298      0.541815459728241
    z[1,0,2]  R299      2.0388497412204742e-01
    z[1,0,2]  R300      0.115140900015831
    z[1,0,2]  R301      1.3454304635524750e-01
    z[1,0,3]  R5        1
    z[1,0,3]  R14       -1
    z[1,0,3]  R194      -1
    z[1,0,3]  R195      1
    z[1,0,3]  R202      3.0141115188598633e-01
    z[1,0,3]  R203      2.4837906658649445e-01
    z[1,0,3]  R204      4.5430219173431396e-01
    z[1,0,3]  R205      1.1281071603298187e-01
    z[1,0,3]  R206      -6.9318228960037231e-01
    z[1,0,3]  R207      7.7586674690246582e-01
    z[1,0,3]  R208      1.8007653951644897e-01
    z[1,0,3]  R209      1.1757089197635651e-01
    z[1,0,3]  R210      8.4759509563446045e-01
    z[1,0,3]  R211      -0.662113606929779
    z[1,0,3]  R212      -1.7191989719867706e-01
    z[1,0,3]  R213      1.4346306025981903e-01
    z[1,0,3]  R214      -1.5986124053597450e-03
    z[1,0,3]  R215      -7.7496804296970367e-02
    z[1,0,3]  R216      -3.5832509398460388e-01
    z[1,0,3]  R217      -4.2696484923362732e-01
    z[1,0,3]  R218      -4.8628427088260651e-02
    z[1,0,3]  R219      -4.4954848289489746e-01
    z[1,0,3]  R220      4.5265042781829834e-01
    z[1,0,3]  R221      -2.2668300569057465e-01
    z[1,0,3]  R222      3.5406373441219330e-02
    z[1,0,3]  R223      -5.3441369533538818e-01
    z[1,0,3]  R224      -6.8717229366302490e-01
    z[1,0,3]  R225      -2.2073395550251007e-01
    z[1,0,3]  R226      -3.3366686105728149e-01
    z[1,0,3]  R227      1.7880079150199890e-01
    z[1,0,3]  R228      -8.5172258317470551e-02
    z[1,0,3]  R229      -1.1860412359237671e-01
    z[1,0,3]  R230      -7.0354276895523071e-01
    z[1,0,3]  R231      6.8548142910003662e-01
    z[1,0,3]  R232      -1.5521142631769180e-02
    z[1,0,3]  R233      3.5324998199939728e-02
    z[1,0,3]  R234      -3.2179304957389832e-01
    z[1,0,3]  R235      -1.7192016541957855e-01
    z[1,0,3]  R236      -4.1844853758811951e-01
    z[1,0,3]  R237      -5.6576901674270630e-01
    z[1,0,3]  R238      -4.7636792063713074e-01
    z[1,0,3]  R239      7.9875022172927856e-01
    z[1,0,3]  R240      0.661388099193573
    z[1,0,3]  R241      5.9479230642318726e-01
    z[1,0,3]  R242      4.4498935341835022e-01
    z[1,0,3]  R243      1.3671043515205383e-01
    z[1,0,3]  R244      3.5809266567230225e-01
    z[1,0,3]  R245      -6.9943493604660034e-01
    z[1,0,3]  R246      7.0330011844635010e-01
    z[1,0,3]  R247      -7.9711538553237915e-01
    z[1,0,3]  R248      -5.2426481246948242e-01
    z[1,0,3]  R249      2.8820842504501343e-01
    z[1,0,3]  R250      -7.1607358753681183e-02
    z[1,0,3]  R251      1.1428820900619030e-02
    z[1,0,3]  R252      7.1843981742858887e-01
    z[1,0,3]  R253      0.767024576663971
    z[1,0,3]  R254      5.2506107091903687e-01
    z[1,0,3]  R255      7.8709018230438232e-01
    z[1,0,3]  R256      3.2510581612586975e-01
    z[1,0,3]  R257      -2.4433358013629913e-01
    z[1,0,3]  R258      -2.2244943678379059e-01
    z[1,0,3]  R259      -2.4872237443923950e-01
    z[1,0,3]  R260      -4.7648698091506958e-02
    z[1,0,3]  R261      -2.8952676802873611e-02
    z[1,0,3]  R262      -1.7613938450813293e-01
    z[1,0,3]  R263      -1.9964993000030518e-01
    z[1,0,3]  R264      0.169372096657753
    z[1,0,3]  R265      -5.0430363416671753e-01
    z[1,0,3]  R266      1.3047042489051819e-01
    z[1,0,3]  R267      -3.4408786892890930e-01
    z[1,0,3]  R268      -5.6352108716964722e-01
    z[1,0,3]  R269      -6.3955657184123993e-02
    z[1,0,3]  R270      -1.8583008646965027e-01
    z[1,0,3]  R271      -4.5038792490959167e-01
    z[1,0,3]  R272      6.7879599332809448e-01
    z[1,0,3]  R273      4.0666261315345764e-01
    z[1,0,3]  R274      3.0813366174697876e-01
    z[1,0,3]  R275      1.2624089419841766e-01
    z[1,0,3]  R276      3.4994545578956604e-01
    z[1,0,3]  R277      -3.4447062015533447e-01
    z[1,0,3]  R278      -2.2915521264076233e-01
    z[1,0,3]  R279      -7.4665099382400513e-01
    z[1,0,3]  R280      -6.8823331594467163e-01
    z[1,0,3]  R281      3.6833325028419495e-01
    z[1,0,3]  R282      2.7590623497962952e-01
    z[1,0,3]  R283      3.2269775867462158e-01
    z[1,0,3]  R284      0.033777866512537
    z[1,0,3]  R285      4.5802673697471619e-01
    z[1,0,3]  R286      5.2076929807662964e-01
    z[1,0,3]  R287      -4.4654447585344315e-02
    z[1,0,3]  R288      -1.7903535068035126e-01
    z[1,0,3]  R289      -8.9750796556472778e-02
    z[1,0,3]  R290      -2.9387819766998291e-01
    z[1,0,3]  R291      -8.5171580314636230e-01
    z[1,0,3]  R292      5.4771190881729126e-01
    z[1,0,3]  R293      3.6372488737106323e-01
    z[1,0,3]  R294      -4.1303125023841858e-01
    z[1,0,3]  R295      -5.3499639034271240e-01
    z[1,0,3]  R296      -5.0670784711837769e-01
    z[1,0,3]  R297      -5.1254862546920776e-01
    z[1,0,3]  R298      -4.2260074615478516e-01
    z[1,0,3]  R299      2.6115423440933228e-01
    z[1,0,3]  R300      -3.1107750535011292e-01
    z[1,0,3]  R301      -4.1094040870666504e-01
    z[1,0,4]  R6        1
    z[1,0,4]  R15       -1
    z[1,0,4]  R196      -1
    z[1,0,4]  R197      1
    z[1,0,4]  R202      -2.9206001758575439e-01
    z[1,0,4]  R203      -7.0369493961334229e-01
    z[1,0,4]  R204      -8.2094132900238037e-01
    z[1,0,4]  R205      -4.4653770327568054e-01
    z[1,0,4]  R206      4.6243643760681152e-01
    z[1,0,4]  R207      9.2762112617492676e-02
    z[1,0,4]  R208      -6.5023016929626465e-01
    z[1,0,4]  R209      -1.6071267426013947e-01
    z[1,0,4]  R210      -1.6083371639251709e-01
    z[1,0,4]  R211      -3.4067001193761826e-02
    z[1,0,4]  R212      -5.6334905326366425e-02
    z[1,0,4]  R213      3.6259177327156067e-01
    z[1,0,4]  R214      -1.3728362321853638e-01
    z[1,0,4]  R215      -1.4447632431983948e-01
    z[1,0,4]  R216      -3.4708479046821594e-01
    z[1,0,4]  R217      1.3537852466106415e-01
    z[1,0,4]  R218      0.483398973941803
    z[1,0,4]  R219      0.0651547759771347
    z[1,0,4]  R220      8.4052875638008118e-02
    z[1,0,4]  R221      -3.0271375179290771e-01
    z[1,0,4]  R222      1.9041784107685089e-01
    z[1,0,4]  R223      2.8257763385772705e-01
    z[1,0,4]  R224      -1.8381620943546295e-01
    z[1,0,4]  R225      0.564232587814331
    z[1,0,4]  R226      3.5421684384346008e-02
    z[1,0,4]  R227      1.3294674456119537e-01
    z[1,0,4]  R228      0.234371617436409
    z[1,0,4]  R229      0.568893551826477
    z[1,0,4]  R230      0.133975088596344
    z[1,0,4]  R231      1.1157119274139404e-01
    z[1,0,4]  R232      1.0607088357210159e-01
    z[1,0,4]  R233      3.3143392205238342e-01
    z[1,0,4]  R234      2.0969532430171967e-01
    z[1,0,4]  R235      5.9639763832092285e-01
    z[1,0,4]  R236      3.5192811489105225e-01
    z[1,0,4]  R237      2.6111885905265808e-01
    z[1,0,4]  R238      -1.3108791410923004e-01
    z[1,0,4]  R239      -6.9482550024986267e-02
    z[1,0,4]  R240      -0.196515291929245
    z[1,0,4]  R241      -1.0311304032802582e-01
    z[1,0,4]  R242      5.4954297840595245e-02
    z[1,0,4]  R243      -0.292703777551651
    z[1,0,4]  R244      -5.3515750169754028e-01
    z[1,0,4]  R245      1.4074082672595978e-01
    z[1,0,4]  R246      -3.4535288810729980e-01
    z[1,0,4]  R247      2.1173091232776642e-01
    z[1,0,4]  R248      3.1077867746353149e-01
    z[1,0,4]  R249      -9.2578649520874023e-02
    z[1,0,4]  R250      -1.6210518777370453e-01
    z[1,0,4]  R251      1.8958781659603119e-01
    z[1,0,4]  R252      0.085997074842453
    z[1,0,4]  R253      2.2456325590610504e-01
    z[1,0,4]  R254      -5.9939321363344789e-04
    z[1,0,4]  R255      -5.8068487793207169e-02
    z[1,0,4]  R256      3.3228802680969238e-01
    z[1,0,4]  R257      -3.1062791123986244e-02
    z[1,0,4]  R258      2.4182732403278351e-01
    z[1,0,4]  R259      5.8144098520278931e-01
    z[1,0,4]  R260      5.7347220182418823e-01
    z[1,0,4]  R261      -4.6587616205215454e-02
    z[1,0,4]  R262      -2.3897903040051460e-02
    z[1,0,4]  R263      9.1737970709800720e-02
    z[1,0,4]  R264      3.5825878381729126e-02
    z[1,0,4]  R265      0.216657355427742
    z[1,0,4]  R266      2.2498093545436859e-01
    z[1,0,4]  R267      5.3508430719375610e-01
    z[1,0,4]  R268      -1.2030213326215744e-01
    z[1,0,4]  R269      -1.2941746413707733e-01
    z[1,0,4]  R270      1.9787830114364624e-01
    z[1,0,4]  R271      -3.0504795908927917e-01
    z[1,0,4]  R272      -6.3864976167678833e-01
    z[1,0,4]  R273      1.7508701980113983e-01
    z[1,0,4]  R274      5.2330672740936279e-02
    z[1,0,4]  R275      6.1832553148269653e-01
    z[1,0,4]  R276      2.3572294414043427e-01
    z[1,0,4]  R277      5.8638691902160645e-02
    z[1,0,4]  R278      6.9978588819503784e-01
    z[1,0,4]  R279      1.9350986927747726e-02
    z[1,0,4]  R280      6.7504072189331055e-01
    z[1,0,4]  R281      -3.2833638787269592e-01
    z[1,0,4]  R282      3.6444410681724548e-01
    z[1,0,4]  R283      4.1179046034812927e-01
    z[1,0,4]  R284      1.9429470598697662e-01
    z[1,0,4]  R285      4.8103532195091248e-01
    z[1,0,4]  R286      4.8666661977767944e-01
    z[1,0,4]  R287      4.8793444037437439e-01
    z[1,0,4]  R288      6.0222244262695312e-01
    z[1,0,4]  R289      2.1910466253757477e-01
    z[1,0,4]  R290      6.6941720247268677e-01
    z[1,0,4]  R291      1.2802883982658386e-02
    z[1,0,4]  R292      -2.1214410662651062e-01
    z[1,0,4]  R293      3.2606017589569092e-01
    z[1,0,4]  R294      4.3784341216087341e-01
    z[1,0,4]  R295      4.1435211896896362e-01
    z[1,0,4]  R296      0.459890216588974
    z[1,0,4]  R297      1.0586746037006378e-01
    z[1,0,4]  R298      9.8830088973045349e-02
    z[1,0,4]  R299      2.2619621828198433e-02
    z[1,0,4]  R300      1.8653546273708344e-01
    z[1,0,4]  R301      1.4439335465431213e-01
    z[1,0,5]  R7        1
    z[1,0,5]  R16       -1
    z[1,0,5]  R198      -1
    z[1,0,5]  R199      1
    z[1,0,5]  R202      -0.16961570084095
    z[1,0,5]  R203      -3.6109413951635361e-02
    z[1,0,5]  R204      -5.2790228277444839e-02
    z[1,0,5]  R205      -6.3004577159881592e-01
    z[1,0,5]  R206      -2.7320614457130432e-01
    z[1,0,5]  R207      -1.2381795793771744e-01
    z[1,0,5]  R208      -5.9111952781677246e-01
    z[1,0,5]  R209      7.3343284428119659e-02
    z[1,0,5]  R210      -1.9130037724971771e-01
    z[1,0,5]  R211      -1.9146957993507385e-01
    z[1,0,5]  R212      4.3890848755836487e-01
    z[1,0,5]  R213      7.4039161205291748e-01
    z[1,0,5]  R214      -1.0637371987104416e-01
    z[1,0,5]  R215      -1.7951239645481110e-01
    z[1,0,5]  R216      1.9836017489433289e-01
    z[1,0,5]  R217      -3.6952443420886993e-02
    z[1,0,5]  R218      -4.4627869129180908e-01
    z[1,0,5]  R219      -1.9919851422309875e-01
    z[1,0,5]  R220      -5.9514995664358139e-03
    z[1,0,5]  R221      4.3356409668922424e-01
    z[1,0,5]  R222      -5.4642057418823242e-01
    z[1,0,5]  R223      -1.7104054987430573e-01
    z[1,0,5]  R224      -2.1577434241771698e-01
    z[1,0,5]  R225      -9.4331823289394379e-02
    z[1,0,5]  R226      -2.9091143608093262e-01
    z[1,0,5]  R227      1.9863104820251465e-01
    z[1,0,5]  R228      -2.0626686513423920e-02
    z[1,0,5]  R229      -3.2981079816818237e-01
    z[1,0,5]  R230      -7.5890876352787018e-02
    z[1,0,5]  R231      -2.1043565869331360e-01
    z[1,0,5]  R232      0.0350484624505043
    z[1,0,5]  R233      -1.2076556682586670e-01
    z[1,0,5]  R234      -4.7361978888511658e-01
    z[1,0,5]  R235      -6.5594747662544250e-02
    z[1,0,5]  R236      2.2551345825195312e-01
    z[1,0,5]  R237      -1.9245958328247070e-01
    z[1,0,5]  R238      3.8899150490760803e-01
    z[1,0,5]  R239      9.7562968730926514e-02
    z[1,0,5]  R240      3.4499558806419373e-01
    z[1,0,5]  R241      -1.3019940257072449e-01
    z[1,0,5]  R242      9.3472130596637726e-02
    z[1,0,5]  R243      -2.8760486841201782e-01
    z[1,0,5]  R244      -1.0530462861061096e-01
    z[1,0,5]  R245      -0.210502028465271
    z[1,0,5]  R246      -2.9261013865470886e-01
    z[1,0,5]  R247      1.0185271501541138e-01
    z[1,0,5]  R248      -7.6998159289360046e-02
    z[1,0,5]  R249      0.0739939957857132
    z[1,0,5]  R250      1.3512995839118958e-01
    z[1,0,5]  R251      -2.1873018145561218e-01
    z[1,0,5]  R252      -1.1372113227844238e-01
    z[1,0,5]  R253      1.7365668714046478e-01
    z[1,0,5]  R254      -3.2546716928482056e-01
    z[1,0,5]  R255      4.6810904145240784e-01
    z[1,0,5]  R256      4.4914358854293823e-01
    z[1,0,5]  R257      5.4180693626403809e-01
    z[1,0,5]  R258      3.6623695492744446e-01
    z[1,0,5]  R259      5.0960993766784668e-01
    z[1,0,5]  R260      4.5797964930534363e-01
    z[1,0,5]  R261      2.2607523202896118e-01
    z[1,0,5]  R262      8.1245154142379761e-02
    z[1,0,5]  R263      9.6389196813106537e-02
    z[1,0,5]  R264      1.4512623846530914e-01
    z[1,0,5]  R265      2.5685855746269226e-01
    z[1,0,5]  R266      -0.00919504277408123
    z[1,0,5]  R267      -2.5343004614114761e-02
    z[1,0,5]  R268      5.7502931356430054e-01
    z[1,0,5]  R269      5.5157393217086792e-01
    z[1,0,5]  R270      -7.3285329341888428e-01
    z[1,0,5]  R271      1.9364964962005615e-01
    z[1,0,5]  R272      -2.7174144983291626e-01
    z[1,0,5]  R273      2.1307614445686340e-01
    z[1,0,5]  R274      -5.9353464841842651e-01
    z[1,0,5]  R275      3.0460536479949951e-01
    z[1,0,5]  R276      -1.2907807528972626e-01
    z[1,0,5]  R277      3.7310361862182617e-01
    z[1,0,5]  R278      1.1365479789674282e-02
    z[1,0,5]  R279      5.0871992111206055e-01
    z[1,0,5]  R280      1.0228655487298965e-01
    z[1,0,5]  R281      2.0482501387596130e-01
    z[1,0,5]  R282      -5.4149203933775425e-03
    z[1,0,5]  R283      -1.4895612001419067e-01
    z[1,0,5]  R284      2.4774929881095886e-01
    z[1,0,5]  R285      0.414351224899292
    z[1,0,5]  R286      5.1882648468017578e-01
    z[1,0,5]  R287      6.0031764209270477e-02
    z[1,0,5]  R288      4.5026890933513641e-02
    z[1,0,5]  R289      -2.1462911367416382e-01
    z[1,0,5]  R290      -1.7139786854386330e-02
    z[1,0,5]  R291      3.8179942965507507e-01
    z[1,0,5]  R292      -8.0481000244617462e-02
    z[1,0,5]  R293      -2.2721394896507263e-01
    z[1,0,5]  R294      -7.8569419682025909e-02
    z[1,0,5]  R295      4.0004798769950867e-01
    z[1,0,5]  R296      5.0161701440811157e-01
    z[1,0,5]  R297      -3.4265366196632385e-01
    z[1,0,5]  R298      5.0114601850509644e-01
    z[1,0,5]  R299      6.5542924404144287e-01
    z[1,0,5]  R300      -3.7773460149765015e-01
    z[1,0,5]  R301      -6.4229391515254974e-02
    z[1,0,6]  R8        1
    z[1,0,6]  R17       -1
    z[1,0,6]  R200      -1
    z[1,0,6]  R201      1
    z[1,0,6]  R202      -2.4655713140964508e-01
    z[1,0,6]  R203      -4.1694027185440063e-01
    z[1,0,6]  R204      -1.7547542229294777e-02
    z[1,0,6]  R205      -3.0434769392013550e-01
    z[1,0,6]  R206      -3.6931043863296509e-01
    z[1,0,6]  R207      -8.2689769566059113e-02
    z[1,0,6]  R208      2.4606725573539734e-01
    z[1,0,6]  R209      9.0966427326202393e-01
    z[1,0,6]  R210      -1.6713818907737732e-01
    z[1,0,6]  R211      -2.6994574069976807e-01
    z[1,0,6]  R212      1.7012619972229004e-01
    z[1,0,6]  R213      -7.5329937040805817e-02
    z[1,0,6]  R214      5.2180871367454529e-02
    z[1,0,6]  R215      -4.0868866443634033e-01
    z[1,0,6]  R216      3.8819864392280579e-01
    z[1,0,6]  R217      1.3943642377853394e-01
    z[1,0,6]  R218      3.8652750849723816e-01
    z[1,0,6]  R219      5.6078654527664185e-01
    z[1,0,6]  R220      2.5621561333537102e-02
    z[1,0,6]  R221      -5.8213543891906738e-01
    z[1,0,6]  R222      -2.3434561491012573e-01
    z[1,0,6]  R223      -2.3424968123435974e-01
    z[1,0,6]  R224      1.1174045503139496e-01
    z[1,0,6]  R225      2.7887317538261414e-01
    z[1,0,6]  R226      4.8269498348236084e-01
    z[1,0,6]  R227      -4.0791699290275574e-01
    z[1,0,6]  R228      3.9846265316009521e-01
    z[1,0,6]  R229      3.9806911349296570e-01
    z[1,0,6]  R230      4.9638313055038452e-01
    z[1,0,6]  R231      1.7675362527370453e-01
    z[1,0,6]  R232      6.2091845273971558e-01
    z[1,0,6]  R233      4.9711546301841736e-01
    z[1,0,6]  R234      7.2336748242378235e-02
    z[1,0,6]  R235      2.6968801021575928e-01
    z[1,0,6]  R236      -4.3976327776908875e-01
    z[1,0,6]  R237      6.4820420742034912e-01
    z[1,0,6]  R238      -2.0570772886276245e-01
    z[1,0,6]  R239      -1.6415183246135712e-01
    z[1,0,6]  R240      -0.0460810661315918
    z[1,0,6]  R241      9.5752745866775513e-02
    z[1,0,6]  R242      -0.0673435777425766
    z[1,0,6]  R243      -1.7936335643753409e-03
    z[1,0,6]  R244      1.7409424483776093e-01
    z[1,0,6]  R245      -5.3414665162563324e-03
    z[1,0,6]  R246      3.3141264319419861e-01
    z[1,0,6]  R247      -5.2414262294769287e-01
    z[1,0,6]  R248      -5.2139669656753540e-02
    z[1,0,6]  R249      -8.5269182920455933e-01
    z[1,0,6]  R250      8.5546606779098511e-01
    z[1,0,6]  R251      -8.5245013236999512e-01
    z[1,0,6]  R252      1.6156622441485524e-03
    z[1,0,6]  R253      -1.8238635361194611e-01
    z[1,0,6]  R254      -4.7673216462135315e-01
    z[1,0,6]  R255      8.9506246149539948e-02
    z[1,0,6]  R256      1.1546920053660870e-02
    z[1,0,6]  R257      2.0072972774505615e-01
    z[1,0,6]  R258      2.2112131118774414e-01
    z[1,0,6]  R259      -2.7132892608642578e-01
    z[1,0,6]  R260      -1.6090519726276398e-01
    z[1,0,6]  R261      2.9249426722526550e-01
    z[1,0,6]  R262      2.3772367835044861e-01
    z[1,0,6]  R263      -5.8585498481988907e-02
    z[1,0,6]  R264      -6.6637277603149414e-01
    z[1,0,6]  R265      4.8056635260581970e-01
    z[1,0,6]  R266      8.0901491641998291e-01
    z[1,0,6]  R267      6.4526760578155518e-01
    z[1,0,6]  R268      -4.8482260107994080e-01
    z[1,0,6]  R269      -6.0944944620132446e-01
    z[1,0,6]  R270      6.0640677809715271e-02
    z[1,0,6]  R271      2.3719212040305138e-03
    z[1,0,6]  R272      -2.0107524469494820e-02
    z[1,0,6]  R273      5.7631272822618484e-02
    z[1,0,6]  R274      3.5792794823646545e-01
    z[1,0,6]  R275      -1.2092448025941849e-01
    z[1,0,6]  R276      7.7706307172775269e-01
    z[1,0,6]  R277      -3.0535668134689331e-01
    z[1,0,6]  R278      -2.9610633850097656e-01
    z[1,0,6]  R279      -1.9181586802005768e-01
    z[1,0,6]  R280      -1.4269690960645676e-02
    z[1,0,6]  R281      8.1576997041702271e-01
    z[1,0,6]  R282      5.9415036439895630e-01
    z[1,0,6]  R283      -0.299562931060791
    z[1,0,6]  R284      5.5895466357469559e-02
    z[1,0,6]  R285      5.3392875194549561e-01
    z[1,0,6]  R286      -2.7288362383842468e-02
    z[1,0,6]  R287      0.0652148649096489
    z[1,0,6]  R288      2.5560066103935242e-01
    z[1,0,6]  R289      -1.4847627282142639e-01
    z[1,0,6]  R290      -2.4474053084850311e-01
    z[1,0,6]  R291      3.7038065493106842e-02
    z[1,0,6]  R292      0.062696672976017
    z[1,0,6]  R293      2.6157614588737488e-01
    z[1,0,6]  R294      1.6548979282379150e-01
    z[1,0,6]  R295      2.1999673545360565e-01
    z[1,0,6]  R296      -2.5295352935791016e-01
    z[1,0,6]  R297      -3.0259797349572182e-02
    z[1,0,6]  R298      -4.4072309136390686e-01
    z[1,0,6]  R299      -1.1679602414369583e-01
    z[1,0,6]  R300      2.9156479239463806e-01
    z[1,0,6]  R301      4.9602559208869934e-01
    z[0,4,0]  R2        -1
    z[0,4,0]  R38       1
    z[0,4,0]  R302      -1
    z[0,4,0]  R303      1
    z[0,4,0]  R316      2.6066619157791138e-01
    z[0,4,0]  R317      6.8736499547958374e-01
    z[0,4,0]  R318      -0.263374388217926
    z[0,4,0]  R319      -3.5421472787857056e-01
    z[0,4,0]  R320      -7.9832553863525391e-02
    z[0,4,0]  R321      -1.8112431466579437e-01
    z[0,4,0]  R322      -4.8229244351387024e-01
    z[0,4,0]  R323      -3.9737311005592346e-01
    z[0,4,0]  R324      -3.8635954260826111e-01
    z[0,4,0]  R325      -2.6415404677391052e-01
    z[0,4,0]  R326      -0.52254319190979
    z[0,4,0]  R327      -1.6679821908473969e-01
    z[0,4,0]  R328      -5.2074825763702393e-01
    z[0,4,0]  R329      -3.2534840703010559e-01
    z[0,4,0]  R330      -6.1319935321807861e-01
    z[0,4,0]  R331      -6.7678910493850708e-01
    z[0,4,0]  R332      -4.2548552155494690e-01
    z[0,4,0]  R333      -4.3196880817413330e-01
    z[0,4,0]  R334      -5.6378740072250366e-01
    z[0,4,0]  R335      -2.3224976658821106e-01
    z[0,4,0]  R336      -4.8676493763923645e-01
    z[0,4,0]  R337      -6.3810366392135620e-01
    z[0,4,0]  R338      -5.1050257682800293e-01
    z[0,4,0]  R339      -4.1413670778274536e-01
    z[0,4,0]  R340      -3.9808002114295959e-01
    z[0,4,0]  R341      -2.7420192956924438e-01
    z[0,4,0]  R342      -0.250662624835968
    z[0,4,0]  R343      -4.4196444749832153e-01
    z[0,4,0]  R344      -0.415751576423645
    z[0,4,0]  R345      4.9911633133888245e-01
    z[0,4,0]  R346      -7.5694888830184937e-02
    z[0,4,0]  R347      -6.8983119726181030e-01
    z[0,4,0]  R348      -1.5377275645732880e-01
    z[0,4,0]  R349      -5.7229089736938477e-01
    z[0,4,0]  R350      1.7609516158699989e-02
    z[0,4,0]  R351      -7.9494613409042358e-01
    z[0,4,0]  R352      -4.1513875126838684e-01
    z[0,4,0]  R353      -2.5649663805961609e-01
    z[0,4,0]  R354      -2.4282118678092957e-01
    z[0,4,0]  R355      1.9869744777679443e-01
    z[0,4,0]  R356      3.8046124577522278e-01
    z[0,4,0]  R357      -6.0589760541915894e-01
    z[0,4,0]  R358      -7.2114330530166626e-01
    z[0,4,0]  R359      -2.8105261921882629e-01
    z[0,4,0]  R360      -4.4869899749755859e-01
    z[0,4,0]  R361      -7.7343314886093140e-01
    z[0,4,0]  R362      -5.3159594535827637e-01
    z[0,4,0]  R363      -6.0012131929397583e-01
    z[0,4,0]  R364      -4.9606877565383911e-01
    z[0,4,0]  R365      -0.329940527677536
    z[0,4,0]  R366      -6.3231301307678223e-01
    z[0,4,0]  R367      -7.1913182735443115e-01
    z[0,4,0]  R368      -6.6646450757980347e-01
    z[0,4,0]  R369      -4.4938430190086365e-01
    z[0,4,0]  R370      -3.7860605120658875e-01
    z[0,4,0]  R371      -5.9573411941528320e-01
    z[0,4,0]  R372      -2.6482513546943665e-01
    z[0,4,0]  R373      6.5551483631134033e-01
    z[0,4,0]  R374      5.2602589130401611e-01
    z[0,4,0]  R375      4.7809746861457825e-01
    z[0,4,0]  R376      7.7755272388458252e-01
    z[0,4,0]  R377      6.3734090328216553e-01
    z[0,4,0]  R378      5.8479756116867065e-01
    z[0,4,0]  R379      6.0710543394088745e-01
    z[0,4,0]  R380      3.8329303264617920e-01
    z[0,4,0]  R381      2.1687658131122589e-01
    z[0,4,0]  R382      2.1503403782844543e-02
    z[0,4,0]  R383      3.1548026204109192e-01
    z[0,4,0]  R384      0.434079110622406
    z[0,4,0]  R385      0.626015841960907
    z[0,4,0]  R386      5.6098586320877075e-01
    z[0,4,0]  R387      3.3980640769004822e-01
    z[0,4,0]  R388      2.1491794288158417e-01
    z[0,4,0]  R389      -6.8108814954757690e-01
    z[0,4,0]  R390      -3.8750776648521423e-01
    z[0,4,0]  R391      -4.7351148724555969e-01
    z[0,4,0]  R392      -5.8315277099609375e-01
    z[0,4,0]  R393      -6.1338418722152710e-01
    z[0,4,0]  R394      -8.8346785306930542e-01
    z[0,4,0]  R395      -8.1260401010513306e-01
    z[0,4,0]  R396      2.0011156797409058e-01
    z[0,4,0]  R397      -3.7151196599006653e-01
    z[0,4,0]  R398      -0.533784031867981
    z[0,4,0]  R399      -7.4237263202667236e-01
    z[0,4,0]  R400      -2.9535919427871704e-01
    z[0,4,0]  R401      -2.5586044788360596e-01
    z[0,4,0]  R402      -3.4152883291244507e-01
    z[0,4,0]  R403      -4.1218620538711548e-01
    z[0,4,0]  R404      -3.6068147420883179e-01
    z[0,4,0]  R405      -1.7500633001327515e-01
    z[0,4,0]  R406      4.9794915318489075e-01
    z[0,4,0]  R407      1.9511704146862030e-01
    z[0,4,0]  R408      3.2752478122711182e-01
    z[0,4,0]  R409      -5.1430463790893555e-02
    z[0,4,0]  R410      -5.2251976728439331e-01
    z[0,4,0]  R411      -6.1259114742279053e-01
    z[0,4,0]  R412      -3.8758561015129089e-01
    z[0,4,0]  R413      -8.7527495622634888e-01
    z[0,4,0]  R414      -6.8857854604721069e-01
    z[0,4,0]  R415      -6.6475450992584229e-01
    z[0,4,1]  R3        -1
    z[0,4,1]  R39       1
    z[0,4,1]  R304      -1
    z[0,4,1]  R305      1
    z[0,4,1]  R316      -3.8004130125045776e-01
    z[0,4,1]  R317      1.2914985418319702e-01
    z[0,4,1]  R318      -6.0805189609527588e-01
    z[0,4,1]  R319      4.6549469232559204e-01
    z[0,4,1]  R320      3.6320638656616211e-01
    z[0,4,1]  R321      -3.6114744842052460e-02
    z[0,4,1]  R322      1.7353674769401550e-01
    z[0,4,1]  R323      -9.5659092068672180e-02
    z[0,4,1]  R324      2.6273140311241150e-01
    z[0,4,1]  R325      3.4583482146263123e-01
    z[0,4,1]  R326      0.436414510011673
    z[0,4,1]  R327      5.1943540573120117e-01
    z[0,4,1]  R328      3.0021563172340393e-01
    z[0,4,1]  R329      -1.1087644845247269e-02
    z[0,4,1]  R330      -4.4893079996109009e-01
    z[0,4,1]  R331      2.4222756922245026e-01
    z[0,4,1]  R332      7.0605480670928955e-01
    z[0,4,1]  R333      2.8052747249603271e-01
    z[0,4,1]  R334      0.141468808054924
    z[0,4,1]  R335      5.7313489913940430e-01
    z[0,4,1]  R336      0.757927417755127
    z[0,4,1]  R337      1.2237020581960678e-01
    z[0,4,1]  R338      -4.8806208372116089e-01
    z[0,4,1]  R339      -3.4369107335805893e-02
    z[0,4,1]  R340      -2.7779793739318848e-01
    z[0,4,1]  R341      3.0863738059997559e-01
    z[0,4,1]  R342      1.4711010456085205e-01
    z[0,4,1]  R343      3.1626126170158386e-01
    z[0,4,1]  R344      -2.4398358166217804e-01
    z[0,4,1]  R345      -6.4226680994033813e-01
    z[0,4,1]  R346      1.4490969479084015e-01
    z[0,4,1]  R347      -0.508252739906311
    z[0,4,1]  R348      3.9389175176620483e-01
    z[0,4,1]  R349      -3.8466867804527283e-01
    z[0,4,1]  R350      3.8059738278388977e-01
    z[0,4,1]  R351      5.1676928997039795e-03
    z[0,4,1]  R352      3.6710596084594727e-01
    z[0,4,1]  R353      2.5813370943069458e-01
    z[0,4,1]  R354      -1.7019649967551231e-02
    z[0,4,1]  R355      -9.6564933657646179e-02
    z[0,4,1]  R356      3.7928631901741028e-01
    z[0,4,1]  R357      -1.8180562555789948e-01
    z[0,4,1]  R358      5.2720570564270020e-01
    z[0,4,1]  R359      -1.1440214514732361e-01
    z[0,4,1]  R360      -1.3806633651256561e-01
    z[0,4,1]  R361      1.2277326732873917e-01
    z[0,4,1]  R362      3.2525521516799927e-01
    z[0,4,1]  R363      5.1913678646087646e-01
    z[0,4,1]  R364      2.8732863068580627e-01
    z[0,4,1]  R365      1.3171996176242828e-01
    z[0,4,1]  R366      -4.1761600971221924e-01
    z[0,4,1]  R367      -0.0854039341211319
    z[0,4,1]  R368      5.4671216756105423e-02
    z[0,4,1]  R369      2.5702759623527527e-01
    z[0,4,1]  R370      -1.1032313853502274e-01
    z[0,4,1]  R371      2.2009618580341339e-01
    z[0,4,1]  R372      -5.0603024661540985e-02
    z[0,4,1]  R373      1.2957285344600677e-01
    z[0,4,1]  R374      -5.9226787090301514e-01
    z[0,4,1]  R375      -5.5985063314437866e-01
    z[0,4,1]  R376      -3.9053717255592346e-01
    z[0,4,1]  R377      -2.3057553172111511e-01
    z[0,4,1]  R378      -3.9834627509117126e-01
    z[0,4,1]  R379      -3.2214903831481934e-01
    z[0,4,1]  R380      -3.1685826182365417e-01
    z[0,4,1]  R381      0.18353371322155
    z[0,4,1]  R382      1.6331650316715240e-01
    z[0,4,1]  R383      -2.2192259784787893e-03
    z[0,4,1]  R384      -1.6745314002037048e-02
    z[0,4,1]  R385      1.4434356987476349e-01
    z[0,4,1]  R386      4.1506272554397583e-01
    z[0,4,1]  R387      4.3609973788261414e-01
    z[0,4,1]  R388      6.3473701477050781e-01
    z[0,4,1]  R389      3.7802930921316147e-02
    z[0,4,1]  R390      3.8586241006851196e-01
    z[0,4,1]  R391      8.1718474626541138e-02
    z[0,4,1]  R392      7.6087392866611481e-02
    z[0,4,1]  R393      6.9843932986259460e-02
    z[0,4,1]  R394      1.9197058677673340e-01
    z[0,4,1]  R395      -1.7714096605777740e-01
    z[0,4,1]  R396      -8.3324313163757324e-02
    z[0,4,1]  R397      2.2697913646697998e-01
    z[0,4,1]  R398      7.6907515525817871e-02
    z[0,4,1]  R399      9.3378983438014984e-02
    z[0,4,1]  R400      -2.8235715627670288e-01
    z[0,4,1]  R401      6.9965416193008423e-01
    z[0,4,1]  R402      6.3529521226882935e-01
    z[0,4,1]  R403      6.1751806735992432e-01
    z[0,4,1]  R404      5.3761011362075806e-01
    z[0,4,1]  R405      4.2723336815834045e-01
    z[0,4,1]  R406      -9.8839856684207916e-02
    z[0,4,1]  R407      -2.4453786015510559e-01
    z[0,4,1]  R408      6.5430924296379089e-02
    z[0,4,1]  R409      4.4217151403427124e-01
    z[0,4,1]  R410      2.1262690424919128e-01
    z[0,4,1]  R411      -4.7013565897941589e-01
    z[0,4,1]  R412      -5.2967935800552368e-01
    z[0,4,1]  R413      -0.095587819814682
    z[0,4,1]  R414      -3.5056486725807190e-01
    z[0,4,1]  R415      -0.279590904712677
    z[0,4,2]  R4        -1
    z[0,4,2]  R40       1
    z[0,4,2]  R306      -1
    z[0,4,2]  R307      1
    z[0,4,2]  R316      -7.5717502832412720e-01
    z[0,4,2]  R317      -5.6900328397750854e-01
    z[0,4,2]  R318      -3.2385990023612976e-01
    z[0,4,2]  R319      3.2324889302253723e-01
    z[0,4,2]  R320      -2.2880828380584717e-01
    z[0,4,2]  R321      2.3817861452698708e-02
    z[0,4,2]  R322      -5.9765762090682983e-01
    z[0,4,2]  R323      9.3544498085975647e-02
    z[0,4,2]  R324      1.4512469060719013e-02
    z[0,4,2]  R325      -5.7201376184821129e-03
    z[0,4,2]  R326      -2.1587004885077477e-03
    z[0,4,2]  R327      1.3724106363952160e-02
    z[0,4,2]  R328      -1.7262664437294006e-01
    z[0,4,2]  R329      2.0977419614791870e-01
    z[0,4,2]  R330      6.6898196935653687e-02
    z[0,4,2]  R331      2.9794535040855408e-01
    z[0,4,2]  R332      -1.7164038121700287e-01
    z[0,4,2]  R333      -3.8066305220127106e-02
    z[0,4,2]  R334      3.0879396200180054e-01
    z[0,4,2]  R335      6.9130671024322510e-01
    z[0,4,2]  R336      3.0642521381378174e-01
    z[0,4,2]  R337      7.1892279386520386e-01
    z[0,4,2]  R338      -7.8089058399200439e-02
    z[0,4,2]  R339      4.7867175936698914e-01
    z[0,4,2]  R340      -2.0526094734668732e-01
    z[0,4,2]  R341      8.8499084115028381e-02
    z[0,4,2]  R342      1.3336643576622009e-01
    z[0,4,2]  R343      9.0247161686420441e-02
    z[0,4,2]  R344      -3.9138570427894592e-01
    z[0,4,2]  R345      7.0476770401000977e-02
    z[0,4,2]  R346      -1.7431662976741791e-01
    z[0,4,2]  R347      -1.4511856436729431e-01
    z[0,4,2]  R348      -4.9307456612586975e-01
    z[0,4,2]  R349      -1.3726910948753357e-01
    z[0,4,2]  R350      -2.3731899261474609e-01
    z[0,4,2]  R351      1.1613065004348755e-01
    z[0,4,2]  R352      2.5074377655982971e-01
    z[0,4,2]  R353      -1.1884884536266327e-01
    z[0,4,2]  R354      -2.7144595980644226e-02
    z[0,4,2]  R355      1.6922371461987495e-02
    z[0,4,2]  R356      -0.386527419090271
    z[0,4,2]  R357      -4.6282148361206055e-01
    z[0,4,2]  R358      3.1402400135993958e-01
    z[0,4,2]  R359      -9.9856235086917877e-02
    z[0,4,2]  R360      4.0449555963277817e-02
    z[0,4,2]  R361      3.7255486845970154e-01
    z[0,4,2]  R362      3.8669133186340332e-01
    z[0,4,2]  R363      4.9616372585296631e-01
    z[0,4,2]  R364      2.7691638469696045e-01
    z[0,4,2]  R365      3.2598786056041718e-02
    z[0,4,2]  R366      -2.6528376340866089e-01
    z[0,4,2]  R367      -3.4190118312835693e-01
    z[0,4,2]  R368      3.9620009064674377e-01
    z[0,4,2]  R369      -2.5621235370635986e-01
    z[0,4,2]  R370      2.4623025953769684e-01
    z[0,4,2]  R371      -4.5212548971176147e-01
    z[0,4,2]  R372      0.541815459728241
    z[0,4,2]  R373      2.0388497412204742e-01
    z[0,4,2]  R374      0.115140900015831
    z[0,4,2]  R375      1.3454304635524750e-01
    z[0,4,2]  R376      9.6842184662818909e-02
    z[0,4,2]  R377      -0.262206107378006
    z[0,4,2]  R378      9.9797770380973816e-02
    z[0,4,2]  R379      -4.1073697805404663e-01
    z[0,4,2]  R380      -7.5050640106201172e-01
    z[0,4,2]  R381      -7.6529151201248169e-01
    z[0,4,2]  R382      -7.0444834232330322e-01
    z[0,4,2]  R383      -6.2899458408355713e-01
    z[0,4,2]  R384      -5.4802465438842773e-01
    z[0,4,2]  R385      -3.5592085123062134e-01
    z[0,4,2]  R386      -1.5294665098190308e-01
    z[0,4,2]  R387      4.0598326921463013e-01
    z[0,4,2]  R388      6.5435290336608887e-02
    z[0,4,2]  R389      -4.0175712108612061e-01
    z[0,4,2]  R390      -5.4046612977981567e-01
    z[0,4,2]  R391      -7.4267548322677612e-01
    z[0,4,2]  R392      -5.4421937465667725e-01
    z[0,4,2]  R393      -3.9016574621200562e-01
    z[0,4,2]  R394      -1.6744016110897064e-01
    z[0,4,2]  R395      -4.2687937617301941e-01
    z[0,4,2]  R396      -5.4102480411529541e-01
    z[0,4,2]  R397      -0.502291738986969
    z[0,4,2]  R398      -4.4189968705177307e-01
    z[0,4,2]  R399      -4.9744647741317749e-01
    z[0,4,2]  R400      -8.1178158521652222e-01
    z[0,4,2]  R401      2.6623749732971191e-01
    z[0,4,2]  R402      3.9537829160690308e-01
    z[0,4,2]  R403      6.1859405832365155e-04
    z[0,4,2]  R404      1.4093835838139057e-02
    z[0,4,2]  R405      3.3906945586204529e-01
    z[0,4,2]  R406      -3.6892163753509521e-01
    z[0,4,2]  R407      -5.6913815438747406e-02
    z[0,4,2]  R408      -2.8455594182014465e-01
    z[0,4,2]  R409      9.5352604985237122e-02
    z[0,4,2]  R410      -7.0583587884902954e-01
    z[0,4,2]  R411      -1.8528589606285095e-01
    z[0,4,2]  R412      -5.0818198919296265e-01
    z[0,4,2]  R413      1.8494956195354462e-01
    z[0,4,2]  R414      -8.1987380981445312e-02
    z[0,4,2]  R415      5.7027824223041534e-02
    z[0,4,3]  R5        -1
    z[0,4,3]  R41       1
    z[0,4,3]  R308      -1
    z[0,4,3]  R309      1
    z[0,4,3]  R316      4.4498935341835022e-01
    z[0,4,3]  R317      1.3671043515205383e-01
    z[0,4,3]  R318      3.5809266567230225e-01
    z[0,4,3]  R319      -6.9943493604660034e-01
    z[0,4,3]  R320      7.0330011844635010e-01
    z[0,4,3]  R321      -7.9711538553237915e-01
    z[0,4,3]  R322      -5.2426481246948242e-01
    z[0,4,3]  R323      2.8820842504501343e-01
    z[0,4,3]  R324      -7.1607358753681183e-02
    z[0,4,3]  R325      1.1428820900619030e-02
    z[0,4,3]  R326      7.1843981742858887e-01
    z[0,4,3]  R327      0.767024576663971
    z[0,4,3]  R328      5.2506107091903687e-01
    z[0,4,3]  R329      7.8709018230438232e-01
    z[0,4,3]  R330      3.2510581612586975e-01
    z[0,4,3]  R331      -2.4433358013629913e-01
    z[0,4,3]  R332      -2.2244943678379059e-01
    z[0,4,3]  R333      -2.4872237443923950e-01
    z[0,4,3]  R334      -4.7648698091506958e-02
    z[0,4,3]  R335      -2.8952676802873611e-02
    z[0,4,3]  R336      -1.7613938450813293e-01
    z[0,4,3]  R337      -1.9964993000030518e-01
    z[0,4,3]  R338      0.169372096657753
    z[0,4,3]  R339      -5.0430363416671753e-01
    z[0,4,3]  R340      1.3047042489051819e-01
    z[0,4,3]  R341      -3.4408786892890930e-01
    z[0,4,3]  R342      -5.6352108716964722e-01
    z[0,4,3]  R343      -6.3955657184123993e-02
    z[0,4,3]  R344      -1.8583008646965027e-01
    z[0,4,3]  R345      -4.5038792490959167e-01
    z[0,4,3]  R346      6.7879599332809448e-01
    z[0,4,3]  R347      4.0666261315345764e-01
    z[0,4,3]  R348      3.0813366174697876e-01
    z[0,4,3]  R349      1.2624089419841766e-01
    z[0,4,3]  R350      3.4994545578956604e-01
    z[0,4,3]  R351      -3.4447062015533447e-01
    z[0,4,3]  R352      -2.2915521264076233e-01
    z[0,4,3]  R353      -7.4665099382400513e-01
    z[0,4,3]  R354      -6.8823331594467163e-01
    z[0,4,3]  R355      3.6833325028419495e-01
    z[0,4,3]  R356      2.7590623497962952e-01
    z[0,4,3]  R357      3.2269775867462158e-01
    z[0,4,3]  R358      0.033777866512537
    z[0,4,3]  R359      4.5802673697471619e-01
    z[0,4,3]  R360      5.2076929807662964e-01
    z[0,4,3]  R361      -4.4654447585344315e-02
    z[0,4,3]  R362      -1.7903535068035126e-01
    z[0,4,3]  R363      -8.9750796556472778e-02
    z[0,4,3]  R364      -2.9387819766998291e-01
    z[0,4,3]  R365      -8.5171580314636230e-01
    z[0,4,3]  R366      5.4771190881729126e-01
    z[0,4,3]  R367      3.6372488737106323e-01
    z[0,4,3]  R368      -4.1303125023841858e-01
    z[0,4,3]  R369      -5.3499639034271240e-01
    z[0,4,3]  R370      -5.0670784711837769e-01
    z[0,4,3]  R371      -5.1254862546920776e-01
    z[0,4,3]  R372      -4.2260074615478516e-01
    z[0,4,3]  R373      2.6115423440933228e-01
    z[0,4,3]  R374      -3.1107750535011292e-01
    z[0,4,3]  R375      -4.1094040870666504e-01
    z[0,4,3]  R376      -0.414764404296875
    z[0,4,3]  R377      -2.5034227967262268e-01
    z[0,4,3]  R378      -3.9581304788589478e-01
    z[0,4,3]  R379      -3.9183524250984192e-01
    z[0,4,3]  R380      -2.0016261935234070e-01
    z[0,4,3]  R381      -1.9974724948406219e-01
    z[0,4,3]  R382      1.7060551047325134e-01
    z[0,4,3]  R383      1.6670159995555878e-01
    z[0,4,3]  R384      1.4519914984703064e-01
    z[0,4,3]  R385      4.4855013489723206e-01
    z[0,4,3]  R386      3.5233241319656372e-01
    z[0,4,3]  R387      3.2735961675643921e-01
    z[0,4,3]  R388      0.160980224609375
    z[0,4,3]  R389      4.2600056529045105e-01
    z[0,4,3]  R390      4.6237173676490784e-01
    z[0,4,3]  R391      3.0387637019157410e-01
    z[0,4,3]  R392      2.2216325998306274e-01
    z[0,4,3]  R393      5.8633047342300415e-01
    z[0,4,3]  R394      3.7895858287811279e-01
    z[0,4,3]  R395      3.3695170283317566e-01
    z[0,4,3]  R396      4.5463311672210693e-01
    z[0,4,3]  R397      4.7110924124717712e-01
    z[0,4,3]  R398      3.7987053394317627e-01
    z[0,4,3]  R399      2.6640614867210388e-01
    z[0,4,3]  R400      1.8347172439098358e-01
    z[0,4,3]  R401      -3.3782243728637695e-01
    z[0,4,3]  R402      -5.2226340770721436e-01
    z[0,4,3]  R403      -0.650968074798584
    z[0,4,3]  R404      -6.5431934595108032e-01
    z[0,4,3]  R405      -7.9564833641052246e-01
    z[0,4,3]  R406      1.7952050268650055e-01
    z[0,4,3]  R407      1.1064269393682480e-01
    z[0,4,3]  R408      4.6490901708602905e-01
    z[0,4,3]  R409      5.7867074012756348e-01
    z[0,4,3]  R410      3.6209985613822937e-01
    z[0,4,3]  R411      -2.6049536466598511e-01
    z[0,4,3]  R412      -3.7754493951797485e-01
    z[0,4,3]  R413      -3.9802354574203491e-01
    z[0,4,3]  R414      -5.6722772121429443e-01
    z[0,4,3]  R415      -5.1404041051864624e-01
    z[0,4,4]  R6        -1
    z[0,4,4]  R42       1
    z[0,4,4]  R310      -1
    z[0,4,4]  R311      1
    z[0,4,4]  R316      5.4954297840595245e-02
    z[0,4,4]  R317      -0.292703777551651
    z[0,4,4]  R318      -5.3515750169754028e-01
    z[0,4,4]  R319      1.4074082672595978e-01
    z[0,4,4]  R320      -3.4535288810729980e-01
    z[0,4,4]  R321      2.1173091232776642e-01
    z[0,4,4]  R322      3.1077867746353149e-01
    z[0,4,4]  R323      -9.2578649520874023e-02
    z[0,4,4]  R324      -1.6210518777370453e-01
    z[0,4,4]  R325      1.8958781659603119e-01
    z[0,4,4]  R326      0.085997074842453
    z[0,4,4]  R327      2.2456325590610504e-01
    z[0,4,4]  R328      -5.9939321363344789e-04
    z[0,4,4]  R329      -5.8068487793207169e-02
    z[0,4,4]  R330      3.3228802680969238e-01
    z[0,4,4]  R331      -3.1062791123986244e-02
    z[0,4,4]  R332      2.4182732403278351e-01
    z[0,4,4]  R333      5.8144098520278931e-01
    z[0,4,4]  R334      5.7347220182418823e-01
    z[0,4,4]  R335      -4.6587616205215454e-02
    z[0,4,4]  R336      -2.3897903040051460e-02
    z[0,4,4]  R337      9.1737970709800720e-02
    z[0,4,4]  R338      3.5825878381729126e-02
    z[0,4,4]  R339      0.216657355427742
    z[0,4,4]  R340      2.2498093545436859e-01
    z[0,4,4]  R341      5.3508430719375610e-01
    z[0,4,4]  R342      -1.2030213326215744e-01
    z[0,4,4]  R343      -1.2941746413707733e-01
    z[0,4,4]  R344      1.9787830114364624e-01
    z[0,4,4]  R345      -3.0504795908927917e-01
    z[0,4,4]  R346      -6.3864976167678833e-01
    z[0,4,4]  R347      1.7508701980113983e-01
    z[0,4,4]  R348      5.2330672740936279e-02
    z[0,4,4]  R349      6.1832553148269653e-01
    z[0,4,4]  R350      2.3572294414043427e-01
    z[0,4,4]  R351      5.8638691902160645e-02
    z[0,4,4]  R352      6.9978588819503784e-01
    z[0,4,4]  R353      1.9350986927747726e-02
    z[0,4,4]  R354      6.7504072189331055e-01
    z[0,4,4]  R355      -3.2833638787269592e-01
    z[0,4,4]  R356      3.6444410681724548e-01
    z[0,4,4]  R357      4.1179046034812927e-01
    z[0,4,4]  R358      1.9429470598697662e-01
    z[0,4,4]  R359      4.8103532195091248e-01
    z[0,4,4]  R360      4.8666661977767944e-01
    z[0,4,4]  R361      4.8793444037437439e-01
    z[0,4,4]  R362      6.0222244262695312e-01
    z[0,4,4]  R363      2.1910466253757477e-01
    z[0,4,4]  R364      6.6941720247268677e-01
    z[0,4,4]  R365      1.2802883982658386e-02
    z[0,4,4]  R366      -2.1214410662651062e-01
    z[0,4,4]  R367      3.2606017589569092e-01
    z[0,4,4]  R368      4.3784341216087341e-01
    z[0,4,4]  R369      4.1435211896896362e-01
    z[0,4,4]  R370      0.459890216588974
    z[0,4,4]  R371      1.0586746037006378e-01
    z[0,4,4]  R372      9.8830088973045349e-02
    z[0,4,4]  R373      2.2619621828198433e-02
    z[0,4,4]  R374      1.8653546273708344e-01
    z[0,4,4]  R375      1.4439335465431213e-01
    z[0,4,4]  R376      -7.0972524583339691e-02
    z[0,4,4]  R377      -6.0671043395996094e-01
    z[0,4,4]  R378      -3.4394067525863647e-01
    z[0,4,4]  R379      -6.2061451375484467e-02
    z[0,4,4]  R380      -1.9149589538574219e-01
    z[0,4,4]  R381      1.1042827740311623e-02
    z[0,4,4]  R382      -3.8129106163978577e-01
    z[0,4,4]  R383      -0.532794713973999
    z[0,4,4]  R384      -5.5903512239456177e-01
    z[0,4,4]  R385      -4.4526490569114685e-01
    z[0,4,4]  R386      -2.2568744421005249e-01
    z[0,4,4]  R387      -7.9875849187374115e-02
    z[0,4,4]  R388      5.6935474276542664e-02
    z[0,4,4]  R389      -1.4888532459735870e-01
    z[0,4,4]  R390      4.9446769990026951e-03
    z[0,4,4]  R391      -1.5995962917804718e-01
    z[0,4,4]  R392      1.6281167045235634e-02
    z[0,4,4]  R393      -2.4922268092632294e-01
    z[0,4,4]  R394      -6.6522851586341858e-02
    z[0,4,4]  R395      8.7339393794536591e-02
    z[0,4,4]  R396      1.0043712705373764e-01
    z[0,4,4]  R397      2.3559153079986572e-01
    z[0,4,4]  R398      2.6856338977813721e-01
    z[0,4,4]  R399      1.4533202350139618e-01
    z[0,4,4]  R400      1.9444513320922852e-01
    z[0,4,4]  R401      1.0865075886249542e-01
    z[0,4,4]  R402      6.4610771369189024e-04
    z[0,4,4]  R403      -7.4865229427814484e-02
    z[0,4,4]  R404      -3.4858337603509426e-03
    z[0,4,4]  R405      9.5011197030544281e-02
    z[0,4,4]  R406      1.8711134791374207e-01
    z[0,4,4]  R407      -0.078458271920681
    z[0,4,4]  R408      -2.7974864840507507e-01
    z[0,4,4]  R409      3.2017588615417480e-01
    z[0,4,4]  R410      1.6883562505245209e-01
    z[0,4,4]  R411      -4.8497796058654785e-01
    z[0,4,4]  R412      -0.257993221282959
    z[0,4,4]  R413      -2.0148554816842079e-02
    z[0,4,4]  R414      1.1473413556814194e-02
    z[0,4,4]  R415      -4.0419352054595947e-01
    z[0,4,5]  R7        -1
    z[0,4,5]  R43       1
    z[0,4,5]  R312      -1
    z[0,4,5]  R313      1
    z[0,4,5]  R316      9.3472130596637726e-02
    z[0,4,5]  R317      -2.8760486841201782e-01
    z[0,4,5]  R318      -1.0530462861061096e-01
    z[0,4,5]  R319      -0.210502028465271
    z[0,4,5]  R320      -2.9261013865470886e-01
    z[0,4,5]  R321      1.0185271501541138e-01
    z[0,4,5]  R322      -7.6998159289360046e-02
    z[0,4,5]  R323      0.0739939957857132
    z[0,4,5]  R324      1.3512995839118958e-01
    z[0,4,5]  R325      -2.1873018145561218e-01
    z[0,4,5]  R326      -1.1372113227844238e-01
    z[0,4,5]  R327      1.7365668714046478e-01
    z[0,4,5]  R328      -3.2546716928482056e-01
    z[0,4,5]  R329      4.6810904145240784e-01
    z[0,4,5]  R330      4.4914358854293823e-01
    z[0,4,5]  R331      5.4180693626403809e-01
    z[0,4,5]  R332      3.6623695492744446e-01
    z[0,4,5]  R333      5.0960993766784668e-01
    z[0,4,5]  R334      4.5797964930534363e-01
    z[0,4,5]  R335      2.2607523202896118e-01
    z[0,4,5]  R336      8.1245154142379761e-02
    z[0,4,5]  R337      9.6389196813106537e-02
    z[0,4,5]  R338      1.4512623846530914e-01
    z[0,4,5]  R339      2.5685855746269226e-01
    z[0,4,5]  R340      -0.00919504277408123
    z[0,4,5]  R341      -2.5343004614114761e-02
    z[0,4,5]  R342      5.7502931356430054e-01
    z[0,4,5]  R343      5.5157393217086792e-01
    z[0,4,5]  R344      -7.3285329341888428e-01
    z[0,4,5]  R345      1.9364964962005615e-01
    z[0,4,5]  R346      -2.7174144983291626e-01
    z[0,4,5]  R347      2.1307614445686340e-01
    z[0,4,5]  R348      -5.9353464841842651e-01
    z[0,4,5]  R349      3.0460536479949951e-01
    z[0,4,5]  R350      -1.2907807528972626e-01
    z[0,4,5]  R351      3.7310361862182617e-01
    z[0,4,5]  R352      1.1365479789674282e-02
    z[0,4,5]  R353      5.0871992111206055e-01
    z[0,4,5]  R354      1.0228655487298965e-01
    z[0,4,5]  R355      2.0482501387596130e-01
    z[0,4,5]  R356      -5.4149203933775425e-03
    z[0,4,5]  R357      -1.4895612001419067e-01
    z[0,4,5]  R358      2.4774929881095886e-01
    z[0,4,5]  R359      0.414351224899292
    z[0,4,5]  R360      5.1882648468017578e-01
    z[0,4,5]  R361      6.0031764209270477e-02
    z[0,4,5]  R362      4.5026890933513641e-02
    z[0,4,5]  R363      -2.1462911367416382e-01
    z[0,4,5]  R364      -1.7139786854386330e-02
    z[0,4,5]  R365      3.8179942965507507e-01
    z[0,4,5]  R366      -8.0481000244617462e-02
    z[0,4,5]  R367      -2.2721394896507263e-01
    z[0,4,5]  R368      -7.8569419682025909e-02
    z[0,4,5]  R369      4.0004798769950867e-01
    z[0,4,5]  R370      5.0161701440811157e-01
    z[0,4,5]  R371      -3.4265366196632385e-01
    z[0,4,5]  R372      5.0114601850509644e-01
    z[0,4,5]  R373      6.5542924404144287e-01
    z[0,4,5]  R374      -3.7773460149765015e-01
    z[0,4,5]  R375      -6.4229391515254974e-02
    z[0,4,5]  R376      1.0589842498302460e-01
    z[0,4,5]  R377      1.9910521805286407e-01
    z[0,4,5]  R378      -4.3603006005287170e-01
    z[0,4,5]  R379      -7.7005207538604736e-02
    z[0,4,5]  R380      -1.8238103389739990e-01
    z[0,4,5]  R381      -5.3781938552856445e-01
    z[0,4,5]  R382      -5.3805822134017944e-01
    z[0,4,5]  R383      -2.5099441409111023e-01
    z[0,4,5]  R384      1.6526119410991669e-01
    z[0,4,5]  R385      -2.2789016366004944e-01
    z[0,4,5]  R386      -3.2468929886817932e-01
    z[0,4,5]  R387      5.9007006883621216e-01
    z[0,4,5]  R388      2.2747208178043365e-01
    z[0,4,5]  R389      3.8374658674001694e-02
    z[0,4,5]  R390      4.2450428009033203e-01
    z[0,4,5]  R391      3.1561350822448730e-01
    z[0,4,5]  R392      5.3853505849838257e-01
    z[0,4,5]  R393      1.8006195127964020e-01
    z[0,4,5]  R394      -2.6605721563100815e-02
    z[0,4,5]  R395      -1.6208153218030930e-02
    z[0,4,5]  R396      4.7667166590690613e-01
    z[0,4,5]  R397      -0.448431134223938
    z[0,4,5]  R398      2.6421904563903809e-01
    z[0,4,5]  R399      -1.2603420019149780e-01
    z[0,4,5]  R400      -1.8004243075847626e-01
    z[0,4,5]  R401      2.6888146996498108e-01
    z[0,4,5]  R402      0.0771268755197525
    z[0,4,5]  R403      -1.2749271094799042e-01
    z[0,4,5]  R404      3.5987859964370728e-01
    z[0,4,5]  R405      -2.9945179820060730e-02
    z[0,4,5]  R406      7.1670997142791748e-01
    z[0,4,5]  R407      -6.7529237270355225e-01
    z[0,4,5]  R408      5.5308806896209717e-01
    z[0,4,5]  R409      -2.6985979080200195e-01
    z[0,4,5]  R410      -1.2557722628116608e-01
    z[0,4,5]  R411      -7.6149078086018562e-03
    z[0,4,5]  R412      1.1959961801767349e-01
    z[0,4,5]  R413      1.7496833205223083e-01
    z[0,4,5]  R414      0.0494014136493206
    z[0,4,5]  R415      1.8870449066162109e-01
    z[0,4,6]  R8        -1
    z[0,4,6]  R44       1
    z[0,4,6]  R314      -1
    z[0,4,6]  R315      1
    z[0,4,6]  R316      -0.0673435777425766
    z[0,4,6]  R317      -1.7936335643753409e-03
    z[0,4,6]  R318      1.7409424483776093e-01
    z[0,4,6]  R319      -5.3414665162563324e-03
    z[0,4,6]  R320      3.3141264319419861e-01
    z[0,4,6]  R321      -5.2414262294769287e-01
    z[0,4,6]  R322      -5.2139669656753540e-02
    z[0,4,6]  R323      -8.5269182920455933e-01
    z[0,4,6]  R324      8.5546606779098511e-01
    z[0,4,6]  R325      -8.5245013236999512e-01
    z[0,4,6]  R326      1.6156622441485524e-03
    z[0,4,6]  R327      -1.8238635361194611e-01
    z[0,4,6]  R328      -4.7673216462135315e-01
    z[0,4,6]  R329      8.9506246149539948e-02
    z[0,4,6]  R330      1.1546920053660870e-02
    z[0,4,6]  R331      2.0072972774505615e-01
    z[0,4,6]  R332      2.2112131118774414e-01
    z[0,4,6]  R333      -2.7132892608642578e-01
    z[0,4,6]  R334      -1.6090519726276398e-01
    z[0,4,6]  R335      2.9249426722526550e-01
    z[0,4,6]  R336      2.3772367835044861e-01
    z[0,4,6]  R337      -5.8585498481988907e-02
    z[0,4,6]  R338      -6.6637277603149414e-01
    z[0,4,6]  R339      4.8056635260581970e-01
    z[0,4,6]  R340      8.0901491641998291e-01
    z[0,4,6]  R341      6.4526760578155518e-01
    z[0,4,6]  R342      -4.8482260107994080e-01
    z[0,4,6]  R343      -6.0944944620132446e-01
    z[0,4,6]  R344      6.0640677809715271e-02
    z[0,4,6]  R345      2.3719212040305138e-03
    z[0,4,6]  R346      -2.0107524469494820e-02
    z[0,4,6]  R347      5.7631272822618484e-02
    z[0,4,6]  R348      3.5792794823646545e-01
    z[0,4,6]  R349      -1.2092448025941849e-01
    z[0,4,6]  R350      7.7706307172775269e-01
    z[0,4,6]  R351      -3.0535668134689331e-01
    z[0,4,6]  R352      -2.9610633850097656e-01
    z[0,4,6]  R353      -1.9181586802005768e-01
    z[0,4,6]  R354      -1.4269690960645676e-02
    z[0,4,6]  R355      8.1576997041702271e-01
    z[0,4,6]  R356      5.9415036439895630e-01
    z[0,4,6]  R357      -0.299562931060791
    z[0,4,6]  R358      5.5895466357469559e-02
    z[0,4,6]  R359      5.3392875194549561e-01
    z[0,4,6]  R360      -2.7288362383842468e-02
    z[0,4,6]  R361      0.0652148649096489
    z[0,4,6]  R362      2.5560066103935242e-01
    z[0,4,6]  R363      -1.4847627282142639e-01
    z[0,4,6]  R364      -2.4474053084850311e-01
    z[0,4,6]  R365      3.7038065493106842e-02
    z[0,4,6]  R366      0.062696672976017
    z[0,4,6]  R367      2.6157614588737488e-01
    z[0,4,6]  R368      1.6548979282379150e-01
    z[0,4,6]  R369      2.1999673545360565e-01
    z[0,4,6]  R370      -2.5295352935791016e-01
    z[0,4,6]  R371      -3.0259797349572182e-02
    z[0,4,6]  R372      -4.4072309136390686e-01
    z[0,4,6]  R373      -1.1679602414369583e-01
    z[0,4,6]  R374      2.9156479239463806e-01
    z[0,4,6]  R375      4.9602559208869934e-01
    z[0,4,6]  R376      -2.1268017590045929e-01
    z[0,4,6]  R377      -3.8311373442411423e-02
    z[0,4,6]  R378      1.5584291517734528e-01
    z[0,4,6]  R379      4.4229146838188171e-01
    z[0,4,6]  R380      -2.8183114528656006e-01
    z[0,4,6]  R381      -0.0658646747469902
    z[0,4,6]  R382      1.1234815418720245e-01
    z[0,4,6]  R383      3.6079812049865723e-01
    z[0,4,6]  R384      3.8736215233802795e-01
    z[0,4,6]  R385      -0.0959039181470871
    z[0,4,6]  R386      4.5730617642402649e-01
    z[0,4,6]  R387      -2.6038253307342529e-01
    z[0,4,6]  R388      -6.8244969844818115e-01
    z[0,4,6]  R389      4.1007933020591736e-01
    z[0,4,6]  R390      1.2177149206399918e-01
    z[0,4,6]  R391      -1.5467011835426092e-03
    z[0,4,6]  R392      1.3537776470184326e-01
    z[0,4,6]  R393      -1.6832861304283142e-01
    z[0,4,6]  R394      -7.6504252851009369e-02
    z[0,4,6]  R395      6.8134978413581848e-02
    z[0,4,6]  R396      -4.6509113907814026e-01
    z[0,4,6]  R397      -2.8217834234237671e-01
    z[0,4,6]  R398      -4.7712126374244690e-01
    z[0,4,6]  R399      -2.9108732938766479e-01
    z[0,4,6]  R400      -2.6488119363784790e-01
    z[0,4,6]  R401      4.1941741108894348e-01
    z[0,4,6]  R402      2.1148538589477539e-01
    z[0,4,6]  R403      -5.6169737130403519e-02
    z[0,4,6]  R404      1.5174710750579834e-01
    z[0,4,6]  R405      -1.6998873651027679e-01
    z[0,4,6]  R406      1.5894284844398499e-01
    z[0,4,6]  R407      -6.5151679515838623e-01
    z[0,4,6]  R408      -4.5515727996826172e-01
    z[0,4,6]  R409      -5.3155469894409180e-01
    z[0,4,6]  R410      9.0372376143932343e-02
    z[0,4,6]  R411      -2.5739893317222595e-01
    z[0,4,6]  R412      2.9591116309165955e-01
    z[0,4,6]  R413      3.3283557742834091e-02
    z[0,4,6]  R414      2.6818379759788513e-01
    z[0,4,6]  R415      1.1601234972476959e-01
    z[4,0,0]  R2        1
    z[4,0,0]  R38       -1
    z[4,0,0]  R416      -1
    z[4,0,0]  R417      1
    z[4,0,0]  R430      7.7755272388458252e-01
    z[4,0,0]  R431      6.3734090328216553e-01
    z[4,0,0]  R432      5.8479756116867065e-01
    z[4,0,0]  R433      6.0710543394088745e-01
    z[4,0,0]  R434      3.8329303264617920e-01
    z[4,0,0]  R435      2.1687658131122589e-01
    z[4,0,0]  R436      2.1503403782844543e-02
    z[4,0,0]  R437      3.1548026204109192e-01
    z[4,0,0]  R438      0.434079110622406
    z[4,0,0]  R439      0.626015841960907
    z[4,0,0]  R440      5.6098586320877075e-01
    z[4,0,0]  R441      3.3980640769004822e-01
    z[4,0,0]  R442      2.1491794288158417e-01
    z[4,0,0]  R443      -6.8108814954757690e-01
    z[4,0,0]  R444      -3.8750776648521423e-01
    z[4,0,0]  R445      -4.7351148724555969e-01
    z[4,0,0]  R446      -5.8315277099609375e-01
    z[4,0,0]  R447      -6.1338418722152710e-01
    z[4,0,0]  R448      -8.8346785306930542e-01
    z[4,0,0]  R449      -8.1260401010513306e-01
    z[4,0,0]  R450      2.0011156797409058e-01
    z[4,0,0]  R451      -3.7151196599006653e-01
    z[4,0,0]  R452      -0.533784031867981
    z[4,0,0]  R453      -7.4237263202667236e-01
    z[4,0,0]  R454      -2.9535919427871704e-01
    z[4,0,0]  R455      -2.5586044788360596e-01
    z[4,0,0]  R456      -3.4152883291244507e-01
    z[4,0,0]  R457      -4.1218620538711548e-01
    z[4,0,0]  R458      -3.6068147420883179e-01
    z[4,0,0]  R459      -1.7500633001327515e-01
    z[4,0,0]  R460      4.9794915318489075e-01
    z[4,0,0]  R461      1.9511704146862030e-01
    z[4,0,0]  R462      3.2752478122711182e-01
    z[4,0,0]  R463      -5.1430463790893555e-02
    z[4,0,0]  R464      -5.2251976728439331e-01
    z[4,0,0]  R465      -6.1259114742279053e-01
    z[4,0,0]  R466      -3.8758561015129089e-01
    z[4,0,0]  R467      -8.7527495622634888e-01
    z[4,0,0]  R468      -6.8857854604721069e-01
    z[4,0,0]  R469      -6.6475450992584229e-01
    z[4,0,0]  R470      2.6066619157791138e-01
    z[4,0,0]  R471      6.8736499547958374e-01
    z[4,0,0]  R472      -0.263374388217926
    z[4,0,0]  R473      -3.5421472787857056e-01
    z[4,0,0]  R474      -7.9832553863525391e-02
    z[4,0,0]  R475      -1.8112431466579437e-01
    z[4,0,0]  R476      -4.8229244351387024e-01
    z[4,0,0]  R477      -3.9737311005592346e-01
    z[4,0,0]  R478      -3.8635954260826111e-01
    z[4,0,0]  R479      -2.6415404677391052e-01
    z[4,0,0]  R480      -0.52254319190979
    z[4,0,0]  R481      -1.6679821908473969e-01
    z[4,0,0]  R482      -5.2074825763702393e-01
    z[4,0,0]  R483      -3.2534840703010559e-01
    z[4,0,0]  R484      -6.1319935321807861e-01
    z[4,0,0]  R485      -6.7678910493850708e-01
    z[4,0,0]  R486      -4.2548552155494690e-01
    z[4,0,0]  R487      -4.3196880817413330e-01
    z[4,0,0]  R488      -5.6378740072250366e-01
    z[4,0,0]  R489      -2.3224976658821106e-01
    z[4,0,0]  R490      -4.8676493763923645e-01
    z[4,0,0]  R491      -6.3810366392135620e-01
    z[4,0,0]  R492      -5.1050257682800293e-01
    z[4,0,0]  R493      -4.1413670778274536e-01
    z[4,0,0]  R494      -3.9808002114295959e-01
    z[4,0,0]  R495      -2.7420192956924438e-01
    z[4,0,0]  R496      -0.250662624835968
    z[4,0,0]  R497      -4.4196444749832153e-01
    z[4,0,0]  R498      -0.415751576423645
    z[4,0,0]  R499      4.9911633133888245e-01
    z[4,0,0]  R500      -7.5694888830184937e-02
    z[4,0,0]  R501      -6.8983119726181030e-01
    z[4,0,0]  R502      -1.5377275645732880e-01
    z[4,0,0]  R503      -5.7229089736938477e-01
    z[4,0,0]  R504      1.7609516158699989e-02
    z[4,0,0]  R505      -7.9494613409042358e-01
    z[4,0,0]  R506      -4.1513875126838684e-01
    z[4,0,0]  R507      -2.5649663805961609e-01
    z[4,0,0]  R508      -2.4282118678092957e-01
    z[4,0,0]  R509      1.9869744777679443e-01
    z[4,0,0]  R510      3.8046124577522278e-01
    z[4,0,0]  R511      -6.0589760541915894e-01
    z[4,0,0]  R512      -7.2114330530166626e-01
    z[4,0,0]  R513      -2.8105261921882629e-01
    z[4,0,0]  R514      -4.4869899749755859e-01
    z[4,0,0]  R515      -7.7343314886093140e-01
    z[4,0,0]  R516      -5.3159594535827637e-01
    z[4,0,0]  R517      -6.0012131929397583e-01
    z[4,0,0]  R518      -4.9606877565383911e-01
    z[4,0,0]  R519      -0.329940527677536
    z[4,0,0]  R520      -6.3231301307678223e-01
    z[4,0,0]  R521      -7.1913182735443115e-01
    z[4,0,0]  R522      -6.6646450757980347e-01
    z[4,0,0]  R523      -4.4938430190086365e-01
    z[4,0,0]  R524      -3.7860605120658875e-01
    z[4,0,0]  R525      -5.9573411941528320e-01
    z[4,0,0]  R526      -2.6482513546943665e-01
    z[4,0,0]  R527      6.5551483631134033e-01
    z[4,0,0]  R528      5.2602589130401611e-01
    z[4,0,0]  R529      4.7809746861457825e-01
    z[4,0,1]  R3        1
    z[4,0,1]  R39       -1
    z[4,0,1]  R418      -1
    z[4,0,1]  R419      1
    z[4,0,1]  R430      -3.9053717255592346e-01
    z[4,0,1]  R431      -2.3057553172111511e-01
    z[4,0,1]  R432      -3.9834627509117126e-01
    z[4,0,1]  R433      -3.2214903831481934e-01
    z[4,0,1]  R434      -3.1685826182365417e-01
    z[4,0,1]  R435      0.18353371322155
    z[4,0,1]  R436      1.6331650316715240e-01
    z[4,0,1]  R437      -2.2192259784787893e-03
    z[4,0,1]  R438      -1.6745314002037048e-02
    z[4,0,1]  R439      1.4434356987476349e-01
    z[4,0,1]  R440      4.1506272554397583e-01
    z[4,0,1]  R441      4.3609973788261414e-01
    z[4,0,1]  R442      6.3473701477050781e-01
    z[4,0,1]  R443      3.7802930921316147e-02
    z[4,0,1]  R444      3.8586241006851196e-01
    z[4,0,1]  R445      8.1718474626541138e-02
    z[4,0,1]  R446      7.6087392866611481e-02
    z[4,0,1]  R447      6.9843932986259460e-02
    z[4,0,1]  R448      1.9197058677673340e-01
    z[4,0,1]  R449      -1.7714096605777740e-01
    z[4,0,1]  R450      -8.3324313163757324e-02
    z[4,0,1]  R451      2.2697913646697998e-01
    z[4,0,1]  R452      7.6907515525817871e-02
    z[4,0,1]  R453      9.3378983438014984e-02
    z[4,0,1]  R454      -2.8235715627670288e-01
    z[4,0,1]  R455      6.9965416193008423e-01
    z[4,0,1]  R456      6.3529521226882935e-01
    z[4,0,1]  R457      6.1751806735992432e-01
    z[4,0,1]  R458      5.3761011362075806e-01
    z[4,0,1]  R459      4.2723336815834045e-01
    z[4,0,1]  R460      -9.8839856684207916e-02
    z[4,0,1]  R461      -2.4453786015510559e-01
    z[4,0,1]  R462      6.5430924296379089e-02
    z[4,0,1]  R463      4.4217151403427124e-01
    z[4,0,1]  R464      2.1262690424919128e-01
    z[4,0,1]  R465      -4.7013565897941589e-01
    z[4,0,1]  R466      -5.2967935800552368e-01
    z[4,0,1]  R467      -0.095587819814682
    z[4,0,1]  R468      -3.5056486725807190e-01
    z[4,0,1]  R469      -0.279590904712677
    z[4,0,1]  R470      -3.8004130125045776e-01
    z[4,0,1]  R471      1.2914985418319702e-01
    z[4,0,1]  R472      -6.0805189609527588e-01
    z[4,0,1]  R473      4.6549469232559204e-01
    z[4,0,1]  R474      3.6320638656616211e-01
    z[4,0,1]  R475      -3.6114744842052460e-02
    z[4,0,1]  R476      1.7353674769401550e-01
    z[4,0,1]  R477      -9.5659092068672180e-02
    z[4,0,1]  R478      2.6273140311241150e-01
    z[4,0,1]  R479      3.4583482146263123e-01
    z[4,0,1]  R480      0.436414510011673
    z[4,0,1]  R481      5.1943540573120117e-01
    z[4,0,1]  R482      3.0021563172340393e-01
    z[4,0,1]  R483      -1.1087644845247269e-02
    z[4,0,1]  R484      -4.4893079996109009e-01
    z[4,0,1]  R485      2.4222756922245026e-01
    z[4,0,1]  R486      7.0605480670928955e-01
    z[4,0,1]  R487      2.8052747249603271e-01
    z[4,0,1]  R488      0.141468808054924
    z[4,0,1]  R489      5.7313489913940430e-01
    z[4,0,1]  R490      0.757927417755127
    z[4,0,1]  R491      1.2237020581960678e-01
    z[4,0,1]  R492      -4.8806208372116089e-01
    z[4,0,1]  R493      -3.4369107335805893e-02
    z[4,0,1]  R494      -2.7779793739318848e-01
    z[4,0,1]  R495      3.0863738059997559e-01
    z[4,0,1]  R496      1.4711010456085205e-01
    z[4,0,1]  R497      3.1626126170158386e-01
    z[4,0,1]  R498      -2.4398358166217804e-01
    z[4,0,1]  R499      -6.4226680994033813e-01
    z[4,0,1]  R500      1.4490969479084015e-01
    z[4,0,1]  R501      -0.508252739906311
    z[4,0,1]  R502      3.9389175176620483e-01
    z[4,0,1]  R503      -3.8466867804527283e-01
    z[4,0,1]  R504      3.8059738278388977e-01
    z[4,0,1]  R505      5.1676928997039795e-03
    z[4,0,1]  R506      3.6710596084594727e-01
    z[4,0,1]  R507      2.5813370943069458e-01
    z[4,0,1]  R508      -1.7019649967551231e-02
    z[4,0,1]  R509      -9.6564933657646179e-02
    z[4,0,1]  R510      3.7928631901741028e-01
    z[4,0,1]  R511      -1.8180562555789948e-01
    z[4,0,1]  R512      5.2720570564270020e-01
    z[4,0,1]  R513      -1.1440214514732361e-01
    z[4,0,1]  R514      -1.3806633651256561e-01
    z[4,0,1]  R515      1.2277326732873917e-01
    z[4,0,1]  R516      3.2525521516799927e-01
    z[4,0,1]  R517      5.1913678646087646e-01
    z[4,0,1]  R518      2.8732863068580627e-01
    z[4,0,1]  R519      1.3171996176242828e-01
    z[4,0,1]  R520      -4.1761600971221924e-01
    z[4,0,1]  R521      -0.0854039341211319
    z[4,0,1]  R522      5.4671216756105423e-02
    z[4,0,1]  R523      2.5702759623527527e-01
    z[4,0,1]  R524      -1.1032313853502274e-01
    z[4,0,1]  R525      2.2009618580341339e-01
    z[4,0,1]  R526      -5.0603024661540985e-02
    z[4,0,1]  R527      1.2957285344600677e-01
    z[4,0,1]  R528      -5.9226787090301514e-01
    z[4,0,1]  R529      -5.5985063314437866e-01
    z[4,0,2]  R4        1
    z[4,0,2]  R40       -1
    z[4,0,2]  R420      -1
    z[4,0,2]  R421      1
    z[4,0,2]  R430      9.6842184662818909e-02
    z[4,0,2]  R431      -0.262206107378006
    z[4,0,2]  R432      9.9797770380973816e-02
    z[4,0,2]  R433      -4.1073697805404663e-01
    z[4,0,2]  R434      -7.5050640106201172e-01
    z[4,0,2]  R435      -7.6529151201248169e-01
    z[4,0,2]  R436      -7.0444834232330322e-01
    z[4,0,2]  R437      -6.2899458408355713e-01
    z[4,0,2]  R438      -5.4802465438842773e-01
    z[4,0,2]  R439      -3.5592085123062134e-01
    z[4,0,2]  R440      -1.5294665098190308e-01
    z[4,0,2]  R441      4.0598326921463013e-01
    z[4,0,2]  R442      6.5435290336608887e-02
    z[4,0,2]  R443      -4.0175712108612061e-01
    z[4,0,2]  R444      -5.4046612977981567e-01
    z[4,0,2]  R445      -7.4267548322677612e-01
    z[4,0,2]  R446      -5.4421937465667725e-01
    z[4,0,2]  R447      -3.9016574621200562e-01
    z[4,0,2]  R448      -1.6744016110897064e-01
    z[4,0,2]  R449      -4.2687937617301941e-01
    z[4,0,2]  R450      -5.4102480411529541e-01
    z[4,0,2]  R451      -0.502291738986969
    z[4,0,2]  R452      -4.4189968705177307e-01
    z[4,0,2]  R453      -4.9744647741317749e-01
    z[4,0,2]  R454      -8.1178158521652222e-01
    z[4,0,2]  R455      2.6623749732971191e-01
    z[4,0,2]  R456      3.9537829160690308e-01
    z[4,0,2]  R457      6.1859405832365155e-04
    z[4,0,2]  R458      1.4093835838139057e-02
    z[4,0,2]  R459      3.3906945586204529e-01
    z[4,0,2]  R460      -3.6892163753509521e-01
    z[4,0,2]  R461      -5.6913815438747406e-02
    z[4,0,2]  R462      -2.8455594182014465e-01
    z[4,0,2]  R463      9.5352604985237122e-02
    z[4,0,2]  R464      -7.0583587884902954e-01
    z[4,0,2]  R465      -1.8528589606285095e-01
    z[4,0,2]  R466      -5.0818198919296265e-01
    z[4,0,2]  R467      1.8494956195354462e-01
    z[4,0,2]  R468      -8.1987380981445312e-02
    z[4,0,2]  R469      5.7027824223041534e-02
    z[4,0,2]  R470      -7.5717502832412720e-01
    z[4,0,2]  R471      -5.6900328397750854e-01
    z[4,0,2]  R472      -3.2385990023612976e-01
    z[4,0,2]  R473      3.2324889302253723e-01
    z[4,0,2]  R474      -2.2880828380584717e-01
    z[4,0,2]  R475      2.3817861452698708e-02
    z[4,0,2]  R476      -5.9765762090682983e-01
    z[4,0,2]  R477      9.3544498085975647e-02
    z[4,0,2]  R478      1.4512469060719013e-02
    z[4,0,2]  R479      -5.7201376184821129e-03
    z[4,0,2]  R480      -2.1587004885077477e-03
    z[4,0,2]  R481      1.3724106363952160e-02
    z[4,0,2]  R482      -1.7262664437294006e-01
    z[4,0,2]  R483      2.0977419614791870e-01
    z[4,0,2]  R484      6.6898196935653687e-02
    z[4,0,2]  R485      2.9794535040855408e-01
    z[4,0,2]  R486      -1.7164038121700287e-01
    z[4,0,2]  R487      -3.8066305220127106e-02
    z[4,0,2]  R488      3.0879396200180054e-01
    z[4,0,2]  R489      6.9130671024322510e-01
    z[4,0,2]  R490      3.0642521381378174e-01
    z[4,0,2]  R491      7.1892279386520386e-01
    z[4,0,2]  R492      -7.8089058399200439e-02
    z[4,0,2]  R493      4.7867175936698914e-01
    z[4,0,2]  R494      -2.0526094734668732e-01
    z[4,0,2]  R495      8.8499084115028381e-02
    z[4,0,2]  R496      1.3336643576622009e-01
    z[4,0,2]  R497      9.0247161686420441e-02
    z[4,0,2]  R498      -3.9138570427894592e-01
    z[4,0,2]  R499      7.0476770401000977e-02
    z[4,0,2]  R500      -1.7431662976741791e-01
    z[4,0,2]  R501      -1.4511856436729431e-01
    z[4,0,2]  R502      -4.9307456612586975e-01
    z[4,0,2]  R503      -1.3726910948753357e-01
    z[4,0,2]  R504      -2.3731899261474609e-01
    z[4,0,2]  R505      1.1613065004348755e-01
    z[4,0,2]  R506      2.5074377655982971e-01
    z[4,0,2]  R507      -1.1884884536266327e-01
    z[4,0,2]  R508      -2.7144595980644226e-02
    z[4,0,2]  R509      1.6922371461987495e-02
    z[4,0,2]  R510      -0.386527419090271
    z[4,0,2]  R511      -4.6282148361206055e-01
    z[4,0,2]  R512      3.1402400135993958e-01
    z[4,0,2]  R513      -9.9856235086917877e-02
    z[4,0,2]  R514      4.0449555963277817e-02
    z[4,0,2]  R515      3.7255486845970154e-01
    z[4,0,2]  R516      3.8669133186340332e-01
    z[4,0,2]  R517      4.9616372585296631e-01
    z[4,0,2]  R518      2.7691638469696045e-01
    z[4,0,2]  R519      3.2598786056041718e-02
    z[4,0,2]  R520      -2.6528376340866089e-01
    z[4,0,2]  R521      -3.4190118312835693e-01
    z[4,0,2]  R522      3.9620009064674377e-01
    z[4,0,2]  R523      -2.5621235370635986e-01
    z[4,0,2]  R524      2.4623025953769684e-01
    z[4,0,2]  R525      -4.5212548971176147e-01
    z[4,0,2]  R526      0.541815459728241
    z[4,0,2]  R527      2.0388497412204742e-01
    z[4,0,2]  R528      0.115140900015831
    z[4,0,2]  R529      1.3454304635524750e-01
    z[4,0,3]  R5        1
    z[4,0,3]  R41       -1
    z[4,0,3]  R422      -1
    z[4,0,3]  R423      1
    z[4,0,3]  R430      -0.414764404296875
    z[4,0,3]  R431      -2.5034227967262268e-01
    z[4,0,3]  R432      -3.9581304788589478e-01
    z[4,0,3]  R433      -3.9183524250984192e-01
    z[4,0,3]  R434      -2.0016261935234070e-01
    z[4,0,3]  R435      -1.9974724948406219e-01
    z[4,0,3]  R436      1.7060551047325134e-01
    z[4,0,3]  R437      1.6670159995555878e-01
    z[4,0,3]  R438      1.4519914984703064e-01
    z[4,0,3]  R439      4.4855013489723206e-01
    z[4,0,3]  R440      3.5233241319656372e-01
    z[4,0,3]  R441      3.2735961675643921e-01
    z[4,0,3]  R442      0.160980224609375
    z[4,0,3]  R443      4.2600056529045105e-01
    z[4,0,3]  R444      4.6237173676490784e-01
    z[4,0,3]  R445      3.0387637019157410e-01
    z[4,0,3]  R446      2.2216325998306274e-01
    z[4,0,3]  R447      5.8633047342300415e-01
    z[4,0,3]  R448      3.7895858287811279e-01
    z[4,0,3]  R449      3.3695170283317566e-01
    z[4,0,3]  R450      4.5463311672210693e-01
    z[4,0,3]  R451      4.7110924124717712e-01
    z[4,0,3]  R452      3.7987053394317627e-01
    z[4,0,3]  R453      2.6640614867210388e-01
    z[4,0,3]  R454      1.8347172439098358e-01
    z[4,0,3]  R455      -3.3782243728637695e-01
    z[4,0,3]  R456      -5.2226340770721436e-01
    z[4,0,3]  R457      -0.650968074798584
    z[4,0,3]  R458      -6.5431934595108032e-01
    z[4,0,3]  R459      -7.9564833641052246e-01
    z[4,0,3]  R460      1.7952050268650055e-01
    z[4,0,3]  R461      1.1064269393682480e-01
    z[4,0,3]  R462      4.6490901708602905e-01
    z[4,0,3]  R463      5.7867074012756348e-01
    z[4,0,3]  R464      3.6209985613822937e-01
    z[4,0,3]  R465      -2.6049536466598511e-01
    z[4,0,3]  R466      -3.7754493951797485e-01
    z[4,0,3]  R467      -3.9802354574203491e-01
    z[4,0,3]  R468      -5.6722772121429443e-01
    z[4,0,3]  R469      -5.1404041051864624e-01
    z[4,0,3]  R470      4.4498935341835022e-01
    z[4,0,3]  R471      1.3671043515205383e-01
    z[4,0,3]  R472      3.5809266567230225e-01
    z[4,0,3]  R473      -6.9943493604660034e-01
    z[4,0,3]  R474      7.0330011844635010e-01
    z[4,0,3]  R475      -7.9711538553237915e-01
    z[4,0,3]  R476      -5.2426481246948242e-01
    z[4,0,3]  R477      2.8820842504501343e-01
    z[4,0,3]  R478      -7.1607358753681183e-02
    z[4,0,3]  R479      1.1428820900619030e-02
    z[4,0,3]  R480      7.1843981742858887e-01
    z[4,0,3]  R481      0.767024576663971
    z[4,0,3]  R482      5.2506107091903687e-01
    z[4,0,3]  R483      7.8709018230438232e-01
    z[4,0,3]  R484      3.2510581612586975e-01
    z[4,0,3]  R485      -2.4433358013629913e-01
    z[4,0,3]  R486      -2.2244943678379059e-01
    z[4,0,3]  R487      -2.4872237443923950e-01
    z[4,0,3]  R488      -4.7648698091506958e-02
    z[4,0,3]  R489      -2.8952676802873611e-02
    z[4,0,3]  R490      -1.7613938450813293e-01
    z[4,0,3]  R491      -1.9964993000030518e-01
    z[4,0,3]  R492      0.169372096657753
    z[4,0,3]  R493      -5.0430363416671753e-01
    z[4,0,3]  R494      1.3047042489051819e-01
    z[4,0,3]  R495      -3.4408786892890930e-01
    z[4,0,3]  R496      -5.6352108716964722e-01
    z[4,0,3]  R497      -6.3955657184123993e-02
    z[4,0,3]  R498      -1.8583008646965027e-01
    z[4,0,3]  R499      -4.5038792490959167e-01
    z[4,0,3]  R500      6.7879599332809448e-01
    z[4,0,3]  R501      4.0666261315345764e-01
    z[4,0,3]  R502      3.0813366174697876e-01
    z[4,0,3]  R503      1.2624089419841766e-01
    z[4,0,3]  R504      3.4994545578956604e-01
    z[4,0,3]  R505      -3.4447062015533447e-01
    z[4,0,3]  R506      -2.2915521264076233e-01
    z[4,0,3]  R507      -7.4665099382400513e-01
    z[4,0,3]  R508      -6.8823331594467163e-01
    z[4,0,3]  R509      3.6833325028419495e-01
    z[4,0,3]  R510      2.7590623497962952e-01
    z[4,0,3]  R511      3.2269775867462158e-01
    z[4,0,3]  R512      0.033777866512537
    z[4,0,3]  R513      4.5802673697471619e-01
    z[4,0,3]  R514      5.2076929807662964e-01
    z[4,0,3]  R515      -4.4654447585344315e-02
    z[4,0,3]  R516      -1.7903535068035126e-01
    z[4,0,3]  R517      -8.9750796556472778e-02
    z[4,0,3]  R518      -2.9387819766998291e-01
    z[4,0,3]  R519      -8.5171580314636230e-01
    z[4,0,3]  R520      5.4771190881729126e-01
    z[4,0,3]  R521      3.6372488737106323e-01
    z[4,0,3]  R522      -4.1303125023841858e-01
    z[4,0,3]  R523      -5.3499639034271240e-01
    z[4,0,3]  R524      -5.0670784711837769e-01
    z[4,0,3]  R525      -5.1254862546920776e-01
    z[4,0,3]  R526      -4.2260074615478516e-01
    z[4,0,3]  R527      2.6115423440933228e-01
    z[4,0,3]  R528      -3.1107750535011292e-01
    z[4,0,3]  R529      -4.1094040870666504e-01
    z[4,0,4]  R6        1
    z[4,0,4]  R42       -1
    z[4,0,4]  R424      -1
    z[4,0,4]  R425      1
    z[4,0,4]  R430      -7.0972524583339691e-02
    z[4,0,4]  R431      -6.0671043395996094e-01
    z[4,0,4]  R432      -3.4394067525863647e-01
    z[4,0,4]  R433      -6.2061451375484467e-02
    z[4,0,4]  R434      -1.9149589538574219e-01
    z[4,0,4]  R435      1.1042827740311623e-02
    z[4,0,4]  R436      -3.8129106163978577e-01
    z[4,0,4]  R437      -0.532794713973999
    z[4,0,4]  R438      -5.5903512239456177e-01
    z[4,0,4]  R439      -4.4526490569114685e-01
    z[4,0,4]  R440      -2.2568744421005249e-01
    z[4,0,4]  R441      -7.9875849187374115e-02
    z[4,0,4]  R442      5.6935474276542664e-02
    z[4,0,4]  R443      -1.4888532459735870e-01
    z[4,0,4]  R444      4.9446769990026951e-03
    z[4,0,4]  R445      -1.5995962917804718e-01
    z[4,0,4]  R446      1.6281167045235634e-02
    z[4,0,4]  R447      -2.4922268092632294e-01
    z[4,0,4]  R448      -6.6522851586341858e-02
    z[4,0,4]  R449      8.7339393794536591e-02
    z[4,0,4]  R450      1.0043712705373764e-01
    z[4,0,4]  R451      2.3559153079986572e-01
    z[4,0,4]  R452      2.6856338977813721e-01
    z[4,0,4]  R453      1.4533202350139618e-01
    z[4,0,4]  R454      1.9444513320922852e-01
    z[4,0,4]  R455      1.0865075886249542e-01
    z[4,0,4]  R456      6.4610771369189024e-04
    z[4,0,4]  R457      -7.4865229427814484e-02
    z[4,0,4]  R458      -3.4858337603509426e-03
    z[4,0,4]  R459      9.5011197030544281e-02
    z[4,0,4]  R460      1.8711134791374207e-01
    z[4,0,4]  R461      -0.078458271920681
    z[4,0,4]  R462      -2.7974864840507507e-01
    z[4,0,4]  R463      3.2017588615417480e-01
    z[4,0,4]  R464      1.6883562505245209e-01
    z[4,0,4]  R465      -4.8497796058654785e-01
    z[4,0,4]  R466      -0.257993221282959
    z[4,0,4]  R467      -2.0148554816842079e-02
    z[4,0,4]  R468      1.1473413556814194e-02
    z[4,0,4]  R469      -4.0419352054595947e-01
    z[4,0,4]  R470      5.4954297840595245e-02
    z[4,0,4]  R471      -0.292703777551651
    z[4,0,4]  R472      -5.3515750169754028e-01
    z[4,0,4]  R473      1.4074082672595978e-01
    z[4,0,4]  R474      -3.4535288810729980e-01
    z[4,0,4]  R475      2.1173091232776642e-01
    z[4,0,4]  R476      3.1077867746353149e-01
    z[4,0,4]  R477      -9.2578649520874023e-02
    z[4,0,4]  R478      -1.6210518777370453e-01
    z[4,0,4]  R479      1.8958781659603119e-01
    z[4,0,4]  R480      0.085997074842453
    z[4,0,4]  R481      2.2456325590610504e-01
    z[4,0,4]  R482      -5.9939321363344789e-04
    z[4,0,4]  R483      -5.8068487793207169e-02
    z[4,0,4]  R484      3.3228802680969238e-01
    z[4,0,4]  R485      -3.1062791123986244e-02
    z[4,0,4]  R486      2.4182732403278351e-01
    z[4,0,4]  R487      5.8144098520278931e-01
    z[4,0,4]  R488      5.7347220182418823e-01
    z[4,0,4]  R489      -4.6587616205215454e-02
    z[4,0,4]  R490      -2.3897903040051460e-02
    z[4,0,4]  R491      9.1737970709800720e-02
    z[4,0,4]  R492      3.5825878381729126e-02
    z[4,0,4]  R493      0.216657355427742
    z[4,0,4]  R494      2.2498093545436859e-01
    z[4,0,4]  R495      5.3508430719375610e-01
    z[4,0,4]  R496      -1.2030213326215744e-01
    z[4,0,4]  R497      -1.2941746413707733e-01
    z[4,0,4]  R498      1.9787830114364624e-01
    z[4,0,4]  R499      -3.0504795908927917e-01
    z[4,0,4]  R500      -6.3864976167678833e-01
    z[4,0,4]  R501      1.7508701980113983e-01
    z[4,0,4]  R502      5.2330672740936279e-02
    z[4,0,4]  R503      6.1832553148269653e-01
    z[4,0,4]  R504      2.3572294414043427e-01
    z[4,0,4]  R505      5.8638691902160645e-02
    z[4,0,4]  R506      6.9978588819503784e-01
    z[4,0,4]  R507      1.9350986927747726e-02
    z[4,0,4]  R508      6.7504072189331055e-01
    z[4,0,4]  R509      -3.2833638787269592e-01
    z[4,0,4]  R510      3.6444410681724548e-01
    z[4,0,4]  R511      4.1179046034812927e-01
    z[4,0,4]  R512      1.9429470598697662e-01
    z[4,0,4]  R513      4.8103532195091248e-01
    z[4,0,4]  R514      4.8666661977767944e-01
    z[4,0,4]  R515      4.8793444037437439e-01
    z[4,0,4]  R516      6.0222244262695312e-01
    z[4,0,4]  R517      2.1910466253757477e-01
    z[4,0,4]  R518      6.6941720247268677e-01
    z[4,0,4]  R519      1.2802883982658386e-02
    z[4,0,4]  R520      -2.1214410662651062e-01
    z[4,0,4]  R521      3.2606017589569092e-01
    z[4,0,4]  R522      4.3784341216087341e-01
    z[4,0,4]  R523      4.1435211896896362e-01
    z[4,0,4]  R524      0.459890216588974
    z[4,0,4]  R525      1.0586746037006378e-01
    z[4,0,4]  R526      9.8830088973045349e-02
    z[4,0,4]  R527      2.2619621828198433e-02
    z[4,0,4]  R528      1.8653546273708344e-01
    z[4,0,4]  R529      1.4439335465431213e-01
    z[4,0,5]  R7        1
    z[4,0,5]  R43       -1
    z[4,0,5]  R426      -1
    z[4,0,5]  R427      1
    z[4,0,5]  R430      1.0589842498302460e-01
    z[4,0,5]  R431      1.9910521805286407e-01
    z[4,0,5]  R432      -4.3603006005287170e-01
    z[4,0,5]  R433      -7.7005207538604736e-02
    z[4,0,5]  R434      -1.8238103389739990e-01
    z[4,0,5]  R435      -5.3781938552856445e-01
    z[4,0,5]  R436      -5.3805822134017944e-01
    z[4,0,5]  R437      -2.5099441409111023e-01
    z[4,0,5]  R438      1.6526119410991669e-01
    z[4,0,5]  R439      -2.2789016366004944e-01
    z[4,0,5]  R440      -3.2468929886817932e-01
    z[4,0,5]  R441      5.9007006883621216e-01
    z[4,0,5]  R442      2.2747208178043365e-01
    z[4,0,5]  R443      3.8374658674001694e-02
    z[4,0,5]  R444      4.2450428009033203e-01
    z[4,0,5]  R445      3.1561350822448730e-01
    z[4,0,5]  R446      5.3853505849838257e-01
    z[4,0,5]  R447      1.8006195127964020e-01
    z[4,0,5]  R448      -2.6605721563100815e-02
    z[4,0,5]  R449      -1.6208153218030930e-02
    z[4,0,5]  R450      4.7667166590690613e-01
    z[4,0,5]  R451      -0.448431134223938
    z[4,0,5]  R452      2.6421904563903809e-01
    z[4,0,5]  R453      -1.2603420019149780e-01
    z[4,0,5]  R454      -1.8004243075847626e-01
    z[4,0,5]  R455      2.6888146996498108e-01
    z[4,0,5]  R456      0.0771268755197525
    z[4,0,5]  R457      -1.2749271094799042e-01
    z[4,0,5]  R458      3.5987859964370728e-01
    z[4,0,5]  R459      -2.9945179820060730e-02
    z[4,0,5]  R460      7.1670997142791748e-01
    z[4,0,5]  R461      -6.7529237270355225e-01
    z[4,0,5]  R462      5.5308806896209717e-01
    z[4,0,5]  R463      -2.6985979080200195e-01
    z[4,0,5]  R464      -1.2557722628116608e-01
    z[4,0,5]  R465      -7.6149078086018562e-03
    z[4,0,5]  R466      1.1959961801767349e-01
    z[4,0,5]  R467      1.7496833205223083e-01
    z[4,0,5]  R468      0.0494014136493206
    z[4,0,5]  R469      1.8870449066162109e-01
    z[4,0,5]  R470      9.3472130596637726e-02
    z[4,0,5]  R471      -2.8760486841201782e-01
    z[4,0,5]  R472      -1.0530462861061096e-01
    z[4,0,5]  R473      -0.210502028465271
    z[4,0,5]  R474      -2.9261013865470886e-01
    z[4,0,5]  R475      1.0185271501541138e-01
    z[4,0,5]  R476      -7.6998159289360046e-02
    z[4,0,5]  R477      0.0739939957857132
    z[4,0,5]  R478      1.3512995839118958e-01
    z[4,0,5]  R479      -2.1873018145561218e-01
    z[4,0,5]  R480      -1.1372113227844238e-01
    z[4,0,5]  R481      1.7365668714046478e-01
    z[4,0,5]  R482      -3.2546716928482056e-01
    z[4,0,5]  R483      4.6810904145240784e-01
    z[4,0,5]  R484      4.4914358854293823e-01
    z[4,0,5]  R485      5.4180693626403809e-01
    z[4,0,5]  R486      3.6623695492744446e-01
    z[4,0,5]  R487      5.0960993766784668e-01
    z[4,0,5]  R488      4.5797964930534363e-01
    z[4,0,5]  R489      2.2607523202896118e-01
    z[4,0,5]  R490      8.1245154142379761e-02
    z[4,0,5]  R491      9.6389196813106537e-02
    z[4,0,5]  R492      1.4512623846530914e-01
    z[4,0,5]  R493      2.5685855746269226e-01
    z[4,0,5]  R494      -0.00919504277408123
    z[4,0,5]  R495      -2.5343004614114761e-02
    z[4,0,5]  R496      5.7502931356430054e-01
    z[4,0,5]  R497      5.5157393217086792e-01
    z[4,0,5]  R498      -7.3285329341888428e-01
    z[4,0,5]  R499      1.9364964962005615e-01
    z[4,0,5]  R500      -2.7174144983291626e-01
    z[4,0,5]  R501      2.1307614445686340e-01
    z[4,0,5]  R502      -5.9353464841842651e-01
    z[4,0,5]  R503      3.0460536479949951e-01
    z[4,0,5]  R504      -1.2907807528972626e-01
    z[4,0,5]  R505      3.7310361862182617e-01
    z[4,0,5]  R506      1.1365479789674282e-02
    z[4,0,5]  R507      5.0871992111206055e-01
    z[4,0,5]  R508      1.0228655487298965e-01
    z[4,0,5]  R509      2.0482501387596130e-01
    z[4,0,5]  R510      -5.4149203933775425e-03
    z[4,0,5]  R511      -1.4895612001419067e-01
    z[4,0,5]  R512      2.4774929881095886e-01
    z[4,0,5]  R513      0.414351224899292
    z[4,0,5]  R514      5.1882648468017578e-01
    z[4,0,5]  R515      6.0031764209270477e-02
    z[4,0,5]  R516      4.5026890933513641e-02
    z[4,0,5]  R517      -2.1462911367416382e-01
    z[4,0,5]  R518      -1.7139786854386330e-02
    z[4,0,5]  R519      3.8179942965507507e-01
    z[4,0,5]  R520      -8.0481000244617462e-02
    z[4,0,5]  R521      -2.2721394896507263e-01
    z[4,0,5]  R522      -7.8569419682025909e-02
    z[4,0,5]  R523      4.0004798769950867e-01
    z[4,0,5]  R524      5.0161701440811157e-01
    z[4,0,5]  R525      -3.4265366196632385e-01
    z[4,0,5]  R526      5.0114601850509644e-01
    z[4,0,5]  R527      6.5542924404144287e-01
    z[4,0,5]  R528      -3.7773460149765015e-01
    z[4,0,5]  R529      -6.4229391515254974e-02
    z[4,0,6]  R8        1
    z[4,0,6]  R44       -1
    z[4,0,6]  R428      -1
    z[4,0,6]  R429      1
    z[4,0,6]  R430      -2.1268017590045929e-01
    z[4,0,6]  R431      -3.8311373442411423e-02
    z[4,0,6]  R432      1.5584291517734528e-01
    z[4,0,6]  R433      4.4229146838188171e-01
    z[4,0,6]  R434      -2.8183114528656006e-01
    z[4,0,6]  R435      -0.0658646747469902
    z[4,0,6]  R436      1.1234815418720245e-01
    z[4,0,6]  R437      3.6079812049865723e-01
    z[4,0,6]  R438      3.8736215233802795e-01
    z[4,0,6]  R439      -0.0959039181470871
    z[4,0,6]  R440      4.5730617642402649e-01
    z[4,0,6]  R441      -2.6038253307342529e-01
    z[4,0,6]  R442      -6.8244969844818115e-01
    z[4,0,6]  R443      4.1007933020591736e-01
    z[4,0,6]  R444      1.2177149206399918e-01
    z[4,0,6]  R445      -1.5467011835426092e-03
    z[4,0,6]  R446      1.3537776470184326e-01
    z[4,0,6]  R447      -1.6832861304283142e-01
    z[4,0,6]  R448      -7.6504252851009369e-02
    z[4,0,6]  R449      6.8134978413581848e-02
    z[4,0,6]  R450      -4.6509113907814026e-01
    z[4,0,6]  R451      -2.8217834234237671e-01
    z[4,0,6]  R452      -4.7712126374244690e-01
    z[4,0,6]  R453      -2.9108732938766479e-01
    z[4,0,6]  R454      -2.6488119363784790e-01
    z[4,0,6]  R455      4.1941741108894348e-01
    z[4,0,6]  R456      2.1148538589477539e-01
    z[4,0,6]  R457      -5.6169737130403519e-02
    z[4,0,6]  R458      1.5174710750579834e-01
    z[4,0,6]  R459      -1.6998873651027679e-01
    z[4,0,6]  R460      1.5894284844398499e-01
    z[4,0,6]  R461      -6.5151679515838623e-01
    z[4,0,6]  R462      -4.5515727996826172e-01
    z[4,0,6]  R463      -5.3155469894409180e-01
    z[4,0,6]  R464      9.0372376143932343e-02
    z[4,0,6]  R465      -2.5739893317222595e-01
    z[4,0,6]  R466      2.9591116309165955e-01
    z[4,0,6]  R467      3.3283557742834091e-02
    z[4,0,6]  R468      2.6818379759788513e-01
    z[4,0,6]  R469      1.1601234972476959e-01
    z[4,0,6]  R470      -0.0673435777425766
    z[4,0,6]  R471      -1.7936335643753409e-03
    z[4,0,6]  R472      1.7409424483776093e-01
    z[4,0,6]  R473      -5.3414665162563324e-03
    z[4,0,6]  R474      3.3141264319419861e-01
    z[4,0,6]  R475      -5.2414262294769287e-01
    z[4,0,6]  R476      -5.2139669656753540e-02
    z[4,0,6]  R477      -8.5269182920455933e-01
    z[4,0,6]  R478      8.5546606779098511e-01
    z[4,0,6]  R479      -8.5245013236999512e-01
    z[4,0,6]  R480      1.6156622441485524e-03
    z[4,0,6]  R481      -1.8238635361194611e-01
    z[4,0,6]  R482      -4.7673216462135315e-01
    z[4,0,6]  R483      8.9506246149539948e-02
    z[4,0,6]  R484      1.1546920053660870e-02
    z[4,0,6]  R485      2.0072972774505615e-01
    z[4,0,6]  R486      2.2112131118774414e-01
    z[4,0,6]  R487      -2.7132892608642578e-01
    z[4,0,6]  R488      -1.6090519726276398e-01
    z[4,0,6]  R489      2.9249426722526550e-01
    z[4,0,6]  R490      2.3772367835044861e-01
    z[4,0,6]  R491      -5.8585498481988907e-02
    z[4,0,6]  R492      -6.6637277603149414e-01
    z[4,0,6]  R493      4.8056635260581970e-01
    z[4,0,6]  R494      8.0901491641998291e-01
    z[4,0,6]  R495      6.4526760578155518e-01
    z[4,0,6]  R496      -4.8482260107994080e-01
    z[4,0,6]  R497      -6.0944944620132446e-01
    z[4,0,6]  R498      6.0640677809715271e-02
    z[4,0,6]  R499      2.3719212040305138e-03
    z[4,0,6]  R500      -2.0107524469494820e-02
    z[4,0,6]  R501      5.7631272822618484e-02
    z[4,0,6]  R502      3.5792794823646545e-01
    z[4,0,6]  R503      -1.2092448025941849e-01
    z[4,0,6]  R504      7.7706307172775269e-01
    z[4,0,6]  R505      -3.0535668134689331e-01
    z[4,0,6]  R506      -2.9610633850097656e-01
    z[4,0,6]  R507      -1.9181586802005768e-01
    z[4,0,6]  R508      -1.4269690960645676e-02
    z[4,0,6]  R509      8.1576997041702271e-01
    z[4,0,6]  R510      5.9415036439895630e-01
    z[4,0,6]  R511      -0.299562931060791
    z[4,0,6]  R512      5.5895466357469559e-02
    z[4,0,6]  R513      5.3392875194549561e-01
    z[4,0,6]  R514      -2.7288362383842468e-02
    z[4,0,6]  R515      0.0652148649096489
    z[4,0,6]  R516      2.5560066103935242e-01
    z[4,0,6]  R517      -1.4847627282142639e-01
    z[4,0,6]  R518      -2.4474053084850311e-01
    z[4,0,6]  R519      3.7038065493106842e-02
    z[4,0,6]  R520      0.062696672976017
    z[4,0,6]  R521      2.6157614588737488e-01
    z[4,0,6]  R522      1.6548979282379150e-01
    z[4,0,6]  R523      2.1999673545360565e-01
    z[4,0,6]  R524      -2.5295352935791016e-01
    z[4,0,6]  R525      -3.0259797349572182e-02
    z[4,0,6]  R526      -4.4072309136390686e-01
    z[4,0,6]  R527      -1.1679602414369583e-01
    z[4,0,6]  R528      2.9156479239463806e-01
    z[4,0,6]  R529      4.9602559208869934e-01
    z[0,5,0]  R2        -1
    z[0,5,0]  R47       1
    z[0,5,0]  R530      -1
    z[0,5,0]  R531      1
    z[0,5,0]  R544      2.6066619157791138e-01
    z[0,5,0]  R545      6.8736499547958374e-01
    z[0,5,0]  R546      -0.263374388217926
    z[0,5,0]  R547      -3.5421472787857056e-01
    z[0,5,0]  R548      -7.9832553863525391e-02
    z[0,5,0]  R549      -1.8112431466579437e-01
    z[0,5,0]  R550      -4.8229244351387024e-01
    z[0,5,0]  R551      -3.9737311005592346e-01
    z[0,5,0]  R552      -3.8635954260826111e-01
    z[0,5,0]  R553      -2.6415404677391052e-01
    z[0,5,0]  R554      -0.52254319190979
    z[0,5,0]  R555      -1.6679821908473969e-01
    z[0,5,0]  R556      -5.2074825763702393e-01
    z[0,5,0]  R557      -3.2534840703010559e-01
    z[0,5,0]  R558      -6.1319935321807861e-01
    z[0,5,0]  R559      -6.7678910493850708e-01
    z[0,5,0]  R560      -4.2548552155494690e-01
    z[0,5,0]  R561      -4.3196880817413330e-01
    z[0,5,0]  R562      -5.6378740072250366e-01
    z[0,5,0]  R563      -2.3224976658821106e-01
    z[0,5,0]  R564      -4.8676493763923645e-01
    z[0,5,0]  R565      -6.3810366392135620e-01
    z[0,5,0]  R566      -5.1050257682800293e-01
    z[0,5,0]  R567      -4.1413670778274536e-01
    z[0,5,0]  R568      -3.9808002114295959e-01
    z[0,5,0]  R569      -2.7420192956924438e-01
    z[0,5,0]  R570      -0.250662624835968
    z[0,5,0]  R571      -4.4196444749832153e-01
    z[0,5,0]  R572      -0.415751576423645
    z[0,5,0]  R573      4.9911633133888245e-01
    z[0,5,0]  R574      -7.5694888830184937e-02
    z[0,5,0]  R575      -6.8983119726181030e-01
    z[0,5,0]  R576      -1.5377275645732880e-01
    z[0,5,0]  R577      -5.7229089736938477e-01
    z[0,5,0]  R578      1.7609516158699989e-02
    z[0,5,0]  R579      -7.9494613409042358e-01
    z[0,5,0]  R580      -4.1513875126838684e-01
    z[0,5,0]  R581      -2.5649663805961609e-01
    z[0,5,0]  R582      -2.4282118678092957e-01
    z[0,5,0]  R583      1.9869744777679443e-01
    z[0,5,0]  R584      3.8046124577522278e-01
    z[0,5,0]  R585      -6.0589760541915894e-01
    z[0,5,0]  R586      -7.2114330530166626e-01
    z[0,5,0]  R587      -2.8105261921882629e-01
    z[0,5,0]  R588      -4.4869899749755859e-01
    z[0,5,0]  R589      -7.7343314886093140e-01
    z[0,5,0]  R590      -5.3159594535827637e-01
    z[0,5,0]  R591      -6.0012131929397583e-01
    z[0,5,0]  R592      -4.9606877565383911e-01
    z[0,5,0]  R593      -0.329940527677536
    z[0,5,0]  R594      -6.3231301307678223e-01
    z[0,5,0]  R595      -7.1913182735443115e-01
    z[0,5,0]  R596      -6.6646450757980347e-01
    z[0,5,0]  R597      -4.4938430190086365e-01
    z[0,5,0]  R598      -3.7860605120658875e-01
    z[0,5,0]  R599      -5.9573411941528320e-01
    z[0,5,0]  R600      -2.6482513546943665e-01
    z[0,5,0]  R601      6.5551483631134033e-01
    z[0,5,0]  R602      5.2602589130401611e-01
    z[0,5,0]  R603      4.7809746861457825e-01
    z[0,5,0]  R604      2.7077559381723404e-02
    z[0,5,0]  R605      -1.4716574549674988e-01
    z[0,5,0]  R606      6.6157186031341553e-01
    z[0,5,0]  R607      3.2766574621200562e-01
    z[0,5,0]  R608      3.5326221585273743e-01
    z[0,5,0]  R609      -4.8980057239532471e-02
    z[0,5,0]  R610      4.2251950502395630e-01
    z[0,5,0]  R611      -7.9604452848434448e-01
    z[0,5,0]  R612      3.9534687995910645e-01
    z[0,5,0]  R613      -4.4654479622840881e-01
    z[0,5,0]  R614      -1.4632028341293335e-01
    z[0,5,0]  R615      -0.420944482088089
    z[0,5,0]  R616      -2.4442516267299652e-01
    z[0,5,0]  R617      -9.0486049652099609e-01
    z[0,5,0]  R618      -8.8210612535476685e-01
    z[0,5,0]  R619      -8.8734483718872070e-01
    z[0,5,0]  R620      -0.904356837272644
    z[0,5,0]  R621      -8.9519476890563965e-01
    z[0,5,1]  R3        -1
    z[0,5,1]  R48       1
    z[0,5,1]  R532      -1
    z[0,5,1]  R533      1
    z[0,5,1]  R544      -3.8004130125045776e-01
    z[0,5,1]  R545      1.2914985418319702e-01
    z[0,5,1]  R546      -6.0805189609527588e-01
    z[0,5,1]  R547      4.6549469232559204e-01
    z[0,5,1]  R548      3.6320638656616211e-01
    z[0,5,1]  R549      -3.6114744842052460e-02
    z[0,5,1]  R550      1.7353674769401550e-01
    z[0,5,1]  R551      -9.5659092068672180e-02
    z[0,5,1]  R552      2.6273140311241150e-01
    z[0,5,1]  R553      3.4583482146263123e-01
    z[0,5,1]  R554      0.436414510011673
    z[0,5,1]  R555      5.1943540573120117e-01
    z[0,5,1]  R556      3.0021563172340393e-01
    z[0,5,1]  R557      -1.1087644845247269e-02
    z[0,5,1]  R558      -4.4893079996109009e-01
    z[0,5,1]  R559      2.4222756922245026e-01
    z[0,5,1]  R560      7.0605480670928955e-01
    z[0,5,1]  R561      2.8052747249603271e-01
    z[0,5,1]  R562      0.141468808054924
    z[0,5,1]  R563      5.7313489913940430e-01
    z[0,5,1]  R564      0.757927417755127
    z[0,5,1]  R565      1.2237020581960678e-01
    z[0,5,1]  R566      -4.8806208372116089e-01
    z[0,5,1]  R567      -3.4369107335805893e-02
    z[0,5,1]  R568      -2.7779793739318848e-01
    z[0,5,1]  R569      3.0863738059997559e-01
    z[0,5,1]  R570      1.4711010456085205e-01
    z[0,5,1]  R571      3.1626126170158386e-01
    z[0,5,1]  R572      -2.4398358166217804e-01
    z[0,5,1]  R573      -6.4226680994033813e-01
    z[0,5,1]  R574      1.4490969479084015e-01
    z[0,5,1]  R575      -0.508252739906311
    z[0,5,1]  R576      3.9389175176620483e-01
    z[0,5,1]  R577      -3.8466867804527283e-01
    z[0,5,1]  R578      3.8059738278388977e-01
    z[0,5,1]  R579      5.1676928997039795e-03
    z[0,5,1]  R580      3.6710596084594727e-01
    z[0,5,1]  R581      2.5813370943069458e-01
    z[0,5,1]  R582      -1.7019649967551231e-02
    z[0,5,1]  R583      -9.6564933657646179e-02
    z[0,5,1]  R584      3.7928631901741028e-01
    z[0,5,1]  R585      -1.8180562555789948e-01
    z[0,5,1]  R586      5.2720570564270020e-01
    z[0,5,1]  R587      -1.1440214514732361e-01
    z[0,5,1]  R588      -1.3806633651256561e-01
    z[0,5,1]  R589      1.2277326732873917e-01
    z[0,5,1]  R590      3.2525521516799927e-01
    z[0,5,1]  R591      5.1913678646087646e-01
    z[0,5,1]  R592      2.8732863068580627e-01
    z[0,5,1]  R593      1.3171996176242828e-01
    z[0,5,1]  R594      -4.1761600971221924e-01
    z[0,5,1]  R595      -0.0854039341211319
    z[0,5,1]  R596      5.4671216756105423e-02
    z[0,5,1]  R597      2.5702759623527527e-01
    z[0,5,1]  R598      -1.1032313853502274e-01
    z[0,5,1]  R599      2.2009618580341339e-01
    z[0,5,1]  R600      -5.0603024661540985e-02
    z[0,5,1]  R601      1.2957285344600677e-01
    z[0,5,1]  R602      -5.9226787090301514e-01
    z[0,5,1]  R603      -5.5985063314437866e-01
    z[0,5,1]  R604      2.1032528579235077e-01
    z[0,5,1]  R605      1.4855297282338142e-02
    z[0,5,1]  R606      -4.6718326210975647e-01
    z[0,5,1]  R607      4.1429869830608368e-02
    z[0,5,1]  R608      -1.5066677331924438e-01
    z[0,5,1]  R609      3.8200950622558594e-01
    z[0,5,1]  R610      -5.6179088354110718e-01
    z[0,5,1]  R611      -2.5091665983200073e-01
    z[0,5,1]  R612      0.735697329044342
    z[0,5,1]  R613      5.1107460260391235e-01
    z[0,5,1]  R614      3.1154605746269226e-01
    z[0,5,1]  R615      4.4397643208503723e-01
    z[0,5,1]  R616      -2.0141474902629852e-01
    z[0,5,1]  R617      -1.1928041279315948e-01
    z[0,5,1]  R618      1.0443801991641521e-02
    z[0,5,1]  R619      -1.9972890615463257e-01
    z[0,5,1]  R620      -2.3908819258213043e-01
    z[0,5,1]  R621      -0.086459219455719
    z[0,5,2]  R4        -1
    z[0,5,2]  R49       1
    z[0,5,2]  R534      -1
    z[0,5,2]  R535      1
    z[0,5,2]  R544      -7.5717502832412720e-01
    z[0,5,2]  R545      -5.6900328397750854e-01
    z[0,5,2]  R546      -3.2385990023612976e-01
    z[0,5,2]  R547      3.2324889302253723e-01
    z[0,5,2]  R548      -2.2880828380584717e-01
    z[0,5,2]  R549      2.3817861452698708e-02
    z[0,5,2]  R550      -5.9765762090682983e-01
    z[0,5,2]  R551      9.3544498085975647e-02
    z[0,5,2]  R552      1.4512469060719013e-02
    z[0,5,2]  R553      -5.7201376184821129e-03
    z[0,5,2]  R554      -2.1587004885077477e-03
    z[0,5,2]  R555      1.3724106363952160e-02
    z[0,5,2]  R556      -1.7262664437294006e-01
    z[0,5,2]  R557      2.0977419614791870e-01
    z[0,5,2]  R558      6.6898196935653687e-02
    z[0,5,2]  R559      2.9794535040855408e-01
    z[0,5,2]  R560      -1.7164038121700287e-01
    z[0,5,2]  R561      -3.8066305220127106e-02
    z[0,5,2]  R562      3.0879396200180054e-01
    z[0,5,2]  R563      6.9130671024322510e-01
    z[0,5,2]  R564      3.0642521381378174e-01
    z[0,5,2]  R565      7.1892279386520386e-01
    z[0,5,2]  R566      -7.8089058399200439e-02
    z[0,5,2]  R567      4.7867175936698914e-01
    z[0,5,2]  R568      -2.0526094734668732e-01
    z[0,5,2]  R569      8.8499084115028381e-02
    z[0,5,2]  R570      1.3336643576622009e-01
    z[0,5,2]  R571      9.0247161686420441e-02
    z[0,5,2]  R572      -3.9138570427894592e-01
    z[0,5,2]  R573      7.0476770401000977e-02
    z[0,5,2]  R574      -1.7431662976741791e-01
    z[0,5,2]  R575      -1.4511856436729431e-01
    z[0,5,2]  R576      -4.9307456612586975e-01
    z[0,5,2]  R577      -1.3726910948753357e-01
    z[0,5,2]  R578      -2.3731899261474609e-01
    z[0,5,2]  R579      1.1613065004348755e-01
    z[0,5,2]  R580      2.5074377655982971e-01
    z[0,5,2]  R581      -1.1884884536266327e-01
    z[0,5,2]  R582      -2.7144595980644226e-02
    z[0,5,2]  R583      1.6922371461987495e-02
    z[0,5,2]  R584      -0.386527419090271
    z[0,5,2]  R585      -4.6282148361206055e-01
    z[0,5,2]  R586      3.1402400135993958e-01
    z[0,5,2]  R587      -9.9856235086917877e-02
    z[0,5,2]  R588      4.0449555963277817e-02
    z[0,5,2]  R589      3.7255486845970154e-01
    z[0,5,2]  R590      3.8669133186340332e-01
    z[0,5,2]  R591      4.9616372585296631e-01
    z[0,5,2]  R592      2.7691638469696045e-01
    z[0,5,2]  R593      3.2598786056041718e-02
    z[0,5,2]  R594      -2.6528376340866089e-01
    z[0,5,2]  R595      -3.4190118312835693e-01
    z[0,5,2]  R596      3.9620009064674377e-01
    z[0,5,2]  R597      -2.5621235370635986e-01
    z[0,5,2]  R598      2.4623025953769684e-01
    z[0,5,2]  R599      -4.5212548971176147e-01
    z[0,5,2]  R600      0.541815459728241
    z[0,5,2]  R601      2.0388497412204742e-01
    z[0,5,2]  R602      0.115140900015831
    z[0,5,2]  R603      1.3454304635524750e-01
    z[0,5,2]  R604      -3.7991592288017273e-01
    z[0,5,2]  R605      -2.9864221811294556e-01
    z[0,5,2]  R606      2.2859716415405273e-01
    z[0,5,2]  R607      5.4286282509565353e-02
    z[0,5,2]  R608      3.1203457713127136e-01
    z[0,5,2]  R609      3.1310686469078064e-01
    z[0,5,2]  R610      -2.7816560864448547e-01
    z[0,5,2]  R611      2.3640289902687073e-01
    z[0,5,2]  R612      -2.6094261556863785e-02
    z[0,5,2]  R613      1.8322923779487610e-01
    z[0,5,2]  R614      5.8794164657592773e-01
    z[0,5,2]  R615      4.9670797586441040e-01
    z[0,5,2]  R616      -4.6606090664863586e-01
    z[0,5,2]  R617      -4.8526491969823837e-02
    z[0,5,2]  R618      -1.6023044288158417e-01
    z[0,5,2]  R619      -1.6508170962333679e-01
    z[0,5,2]  R620      3.1460151076316833e-02
    z[0,5,2]  R621      -3.8388580083847046e-02
    z[0,5,3]  R5        -1
    z[0,5,3]  R50       1
    z[0,5,3]  R536      -1
    z[0,5,3]  R537      1
    z[0,5,3]  R544      4.4498935341835022e-01
    z[0,5,3]  R545      1.3671043515205383e-01
    z[0,5,3]  R546      3.5809266567230225e-01
    z[0,5,3]  R547      -6.9943493604660034e-01
    z[0,5,3]  R548      7.0330011844635010e-01
    z[0,5,3]  R549      -7.9711538553237915e-01
    z[0,5,3]  R550      -5.2426481246948242e-01
    z[0,5,3]  R551      2.8820842504501343e-01
    z[0,5,3]  R552      -7.1607358753681183e-02
    z[0,5,3]  R553      1.1428820900619030e-02
    z[0,5,3]  R554      7.1843981742858887e-01
    z[0,5,3]  R555      0.767024576663971
    z[0,5,3]  R556      5.2506107091903687e-01
    z[0,5,3]  R557      7.8709018230438232e-01
    z[0,5,3]  R558      3.2510581612586975e-01
    z[0,5,3]  R559      -2.4433358013629913e-01
    z[0,5,3]  R560      -2.2244943678379059e-01
    z[0,5,3]  R561      -2.4872237443923950e-01
    z[0,5,3]  R562      -4.7648698091506958e-02
    z[0,5,3]  R563      -2.8952676802873611e-02
    z[0,5,3]  R564      -1.7613938450813293e-01
    z[0,5,3]  R565      -1.9964993000030518e-01
    z[0,5,3]  R566      0.169372096657753
    z[0,5,3]  R567      -5.0430363416671753e-01
    z[0,5,3]  R568      1.3047042489051819e-01
    z[0,5,3]  R569      -3.4408786892890930e-01
    z[0,5,3]  R570      -5.6352108716964722e-01
    z[0,5,3]  R571      -6.3955657184123993e-02
    z[0,5,3]  R572      -1.8583008646965027e-01
    z[0,5,3]  R573      -4.5038792490959167e-01
    z[0,5,3]  R574      6.7879599332809448e-01
    z[0,5,3]  R575      4.0666261315345764e-01
    z[0,5,3]  R576      3.0813366174697876e-01
    z[0,5,3]  R577      1.2624089419841766e-01
    z[0,5,3]  R578      3.4994545578956604e-01
    z[0,5,3]  R579      -3.4447062015533447e-01
    z[0,5,3]  R580      -2.2915521264076233e-01
    z[0,5,3]  R581      -7.4665099382400513e-01
    z[0,5,3]  R582      -6.8823331594467163e-01
    z[0,5,3]  R583      3.6833325028419495e-01
    z[0,5,3]  R584      2.7590623497962952e-01
    z[0,5,3]  R585      3.2269775867462158e-01
    z[0,5,3]  R586      0.033777866512537
    z[0,5,3]  R587      4.5802673697471619e-01
    z[0,5,3]  R588      5.2076929807662964e-01
    z[0,5,3]  R589      -4.4654447585344315e-02
    z[0,5,3]  R590      -1.7903535068035126e-01
    z[0,5,3]  R591      -8.9750796556472778e-02
    z[0,5,3]  R592      -2.9387819766998291e-01
    z[0,5,3]  R593      -8.5171580314636230e-01
    z[0,5,3]  R594      5.4771190881729126e-01
    z[0,5,3]  R595      3.6372488737106323e-01
    z[0,5,3]  R596      -4.1303125023841858e-01
    z[0,5,3]  R597      -5.3499639034271240e-01
    z[0,5,3]  R598      -5.0670784711837769e-01
    z[0,5,3]  R599      -5.1254862546920776e-01
    z[0,5,3]  R600      -4.2260074615478516e-01
    z[0,5,3]  R601      2.6115423440933228e-01
    z[0,5,3]  R602      -3.1107750535011292e-01
    z[0,5,3]  R603      -4.1094040870666504e-01
    z[0,5,3]  R604      1.4298340678215027e-01
    z[0,5,3]  R605      3.0610656738281250e-01
    z[0,5,3]  R606      -4.5985820889472961e-01
    z[0,5,3]  R607      -5.7009279727935791e-01
    z[0,5,3]  R608      -2.6410719752311707e-01
    z[0,5,3]  R609      4.0180769562721252e-01
    z[0,5,3]  R610      5.2533990144729614e-01
    z[0,5,3]  R611      -2.3259180784225464e-01
    z[0,5,3]  R612      3.7807571887969971e-01
    z[0,5,3]  R613      -6.2137925624847412e-01
    z[0,5,3]  R614      -5.2404171228408813e-01
    z[0,5,3]  R615      -2.4119694530963898e-01
    z[0,5,3]  R616      -6.6314691305160522e-01
    z[0,5,3]  R617      -3.0422553420066833e-01
    z[0,5,3]  R618      -4.0116128325462341e-01
    z[0,5,3]  R619      -3.2623365521430969e-01
    z[0,5,3]  R620      -2.2785899043083191e-01
    z[0,5,3]  R621      -1.5573722124099731e-01
    z[0,5,4]  R6        -1
    z[0,5,4]  R51       1
    z[0,5,4]  R538      -1
    z[0,5,4]  R539      1
    z[0,5,4]  R544      5.4954297840595245e-02
    z[0,5,4]  R545      -0.292703777551651
    z[0,5,4]  R546      -5.3515750169754028e-01
    z[0,5,4]  R547      1.4074082672595978e-01
    z[0,5,4]  R548      -3.4535288810729980e-01
    z[0,5,4]  R549      2.1173091232776642e-01
    z[0,5,4]  R550      3.1077867746353149e-01
    z[0,5,4]  R551      -9.2578649520874023e-02
    z[0,5,4]  R552      -1.6210518777370453e-01
    z[0,5,4]  R553      1.8958781659603119e-01
    z[0,5,4]  R554      0.085997074842453
    z[0,5,4]  R555      2.2456325590610504e-01
    z[0,5,4]  R556      -5.9939321363344789e-04
    z[0,5,4]  R557      -5.8068487793207169e-02
    z[0,5,4]  R558      3.3228802680969238e-01
    z[0,5,4]  R559      -3.1062791123986244e-02
    z[0,5,4]  R560      2.4182732403278351e-01
    z[0,5,4]  R561      5.8144098520278931e-01
    z[0,5,4]  R562      5.7347220182418823e-01
    z[0,5,4]  R563      -4.6587616205215454e-02
    z[0,5,4]  R564      -2.3897903040051460e-02
    z[0,5,4]  R565      9.1737970709800720e-02
    z[0,5,4]  R566      3.5825878381729126e-02
    z[0,5,4]  R567      0.216657355427742
    z[0,5,4]  R568      2.2498093545436859e-01
    z[0,5,4]  R569      5.3508430719375610e-01
    z[0,5,4]  R570      -1.2030213326215744e-01
    z[0,5,4]  R571      -1.2941746413707733e-01
    z[0,5,4]  R572      1.9787830114364624e-01
    z[0,5,4]  R573      -3.0504795908927917e-01
    z[0,5,4]  R574      -6.3864976167678833e-01
    z[0,5,4]  R575      1.7508701980113983e-01
    z[0,5,4]  R576      5.2330672740936279e-02
    z[0,5,4]  R577      6.1832553148269653e-01
    z[0,5,4]  R578      2.3572294414043427e-01
    z[0,5,4]  R579      5.8638691902160645e-02
    z[0,5,4]  R580      6.9978588819503784e-01
    z[0,5,4]  R581      1.9350986927747726e-02
    z[0,5,4]  R582      6.7504072189331055e-01
    z[0,5,4]  R583      -3.2833638787269592e-01
    z[0,5,4]  R584      3.6444410681724548e-01
    z[0,5,4]  R585      4.1179046034812927e-01
    z[0,5,4]  R586      1.9429470598697662e-01
    z[0,5,4]  R587      4.8103532195091248e-01
    z[0,5,4]  R588      4.8666661977767944e-01
    z[0,5,4]  R589      4.8793444037437439e-01
    z[0,5,4]  R590      6.0222244262695312e-01
    z[0,5,4]  R591      2.1910466253757477e-01
    z[0,5,4]  R592      6.6941720247268677e-01
    z[0,5,4]  R593      1.2802883982658386e-02
    z[0,5,4]  R594      -2.1214410662651062e-01
    z[0,5,4]  R595      3.2606017589569092e-01
    z[0,5,4]  R596      4.3784341216087341e-01
    z[0,5,4]  R597      4.1435211896896362e-01
    z[0,5,4]  R598      0.459890216588974
    z[0,5,4]  R599      1.0586746037006378e-01
    z[0,5,4]  R600      9.8830088973045349e-02
    z[0,5,4]  R601      2.2619621828198433e-02
    z[0,5,4]  R602      1.8653546273708344e-01
    z[0,5,4]  R603      1.4439335465431213e-01
    z[0,5,4]  R604      -2.6978400349617004e-01
    z[0,5,4]  R605      -1.9433347880840302e-01
    z[0,5,4]  R606      -6.5487218089401722e-03
    z[0,5,4]  R607      -2.4164788424968719e-01
    z[0,5,4]  R608      -5.3179544210433960e-01
    z[0,5,4]  R609      -0.715399980545044
    z[0,5,4]  R610      2.4729570746421814e-01
    z[0,5,4]  R611      -2.6987606287002563e-01
    z[0,5,4]  R612      2.1347737312316895e-01
    z[0,5,4]  R613      6.6397614777088165e-02
    z[0,5,4]  R614      -0.0682741329073906
    z[0,5,4]  R615      1.9729943946003914e-02
    z[0,5,4]  R616      1.2859743833541870e-01
    z[0,5,4]  R617      3.1697552651166916e-02
    z[0,5,4]  R618      -4.4534732587635517e-03
    z[0,5,4]  R619      1.1686767637729645e-01
    z[0,5,4]  R620      -2.5458750128746033e-01
    z[0,5,4]  R621      -3.8164101541042328e-02
    z[0,5,5]  R7        -1
    z[0,5,5]  R52       1
    z[0,5,5]  R540      -1
    z[0,5,5]  R541      1
    z[0,5,5]  R544      9.3472130596637726e-02
    z[0,5,5]  R545      -2.8760486841201782e-01
    z[0,5,5]  R546      -1.0530462861061096e-01
    z[0,5,5]  R547      -0.210502028465271
    z[0,5,5]  R548      -2.9261013865470886e-01
    z[0,5,5]  R549      1.0185271501541138e-01
    z[0,5,5]  R550      -7.6998159289360046e-02
    z[0,5,5]  R551      0.0739939957857132
    z[0,5,5]  R552      1.3512995839118958e-01
    z[0,5,5]  R553      -2.1873018145561218e-01
    z[0,5,5]  R554      -1.1372113227844238e-01
    z[0,5,5]  R555      1.7365668714046478e-01
    z[0,5,5]  R556      -3.2546716928482056e-01
    z[0,5,5]  R557      4.6810904145240784e-01
    z[0,5,5]  R558      4.4914358854293823e-01
    z[0,5,5]  R559      5.4180693626403809e-01
    z[0,5,5]  R560      3.6623695492744446e-01
    z[0,5,5]  R561      5.0960993766784668e-01
    z[0,5,5]  R562      4.5797964930534363e-01
    z[0,5,5]  R563      2.2607523202896118e-01
    z[0,5,5]  R564      8.1245154142379761e-02
    z[0,5,5]  R565      9.6389196813106537e-02
    z[0,5,5]  R566      1.4512623846530914e-01
    z[0,5,5]  R567      2.5685855746269226e-01
    z[0,5,5]  R568      -0.00919504277408123
    z[0,5,5]  R569      -2.5343004614114761e-02
    z[0,5,5]  R570      5.7502931356430054e-01
    z[0,5,5]  R571      5.5157393217086792e-01
    z[0,5,5]  R572      -7.3285329341888428e-01
    z[0,5,5]  R573      1.9364964962005615e-01
    z[0,5,5]  R574      -2.7174144983291626e-01
    z[0,5,5]  R575      2.1307614445686340e-01
    z[0,5,5]  R576      -5.9353464841842651e-01
    z[0,5,5]  R577      3.0460536479949951e-01
    z[0,5,5]  R578      -1.2907807528972626e-01
    z[0,5,5]  R579      3.7310361862182617e-01
    z[0,5,5]  R580      1.1365479789674282e-02
    z[0,5,5]  R581      5.0871992111206055e-01
    z[0,5,5]  R582      1.0228655487298965e-01
    z[0,5,5]  R583      2.0482501387596130e-01
    z[0,5,5]  R584      -5.4149203933775425e-03
    z[0,5,5]  R585      -1.4895612001419067e-01
    z[0,5,5]  R586      2.4774929881095886e-01
    z[0,5,5]  R587      0.414351224899292
    z[0,5,5]  R588      5.1882648468017578e-01
    z[0,5,5]  R589      6.0031764209270477e-02
    z[0,5,5]  R590      4.5026890933513641e-02
    z[0,5,5]  R591      -2.1462911367416382e-01
    z[0,5,5]  R592      -1.7139786854386330e-02
    z[0,5,5]  R593      3.8179942965507507e-01
    z[0,5,5]  R594      -8.0481000244617462e-02
    z[0,5,5]  R595      -2.2721394896507263e-01
    z[0,5,5]  R596      -7.8569419682025909e-02
    z[0,5,5]  R597      4.0004798769950867e-01
    z[0,5,5]  R598      5.0161701440811157e-01
    z[0,5,5]  R599      -3.4265366196632385e-01
    z[0,5,5]  R600      5.0114601850509644e-01
    z[0,5,5]  R601      6.5542924404144287e-01
    z[0,5,5]  R602      -3.7773460149765015e-01
    z[0,5,5]  R603      -6.4229391515254974e-02
    z[0,5,5]  R604      -8.4242987632751465e-01
    z[0,5,5]  R605      -4.9546590447425842e-01
    z[0,5,5]  R606      -1.6400189697742462e-01
    z[0,5,5]  R607      -5.3578341007232666e-01
    z[0,5,5]  R608      -1.5329921245574951e-01
    z[0,5,5]  R609      2.3713913559913635e-01
    z[0,5,5]  R610      1.9079077243804932e-01
    z[0,5,5]  R611      3.3418321609497070e-01
    z[0,5,5]  R612      1.5212121605873108e-01
    z[0,5,5]  R613      3.3937299251556396e-01
    z[0,5,5]  R614      4.7862115502357483e-01
    z[0,5,5]  R615      3.7534487247467041e-01
    z[0,5,5]  R616      4.4864749908447266e-01
    z[0,5,5]  R617      2.3144076764583588e-01
    z[0,5,5]  R618      -4.6014860272407532e-02
    z[0,5,5]  R619      6.8947292864322662e-02
    z[0,5,5]  R620      3.8678757846355438e-02
    z[0,5,5]  R621      2.7021130919456482e-01
    z[0,5,6]  R8        -1
    z[0,5,6]  R53       1
    z[0,5,6]  R542      -1
    z[0,5,6]  R543      1
    z[0,5,6]  R544      -0.0673435777425766
    z[0,5,6]  R545      -1.7936335643753409e-03
    z[0,5,6]  R546      1.7409424483776093e-01
    z[0,5,6]  R547      -5.3414665162563324e-03
    z[0,5,6]  R548      3.3141264319419861e-01
    z[0,5,6]  R549      -5.2414262294769287e-01
    z[0,5,6]  R550      -5.2139669656753540e-02
    z[0,5,6]  R551      -8.5269182920455933e-01
    z[0,5,6]  R552      8.5546606779098511e-01
    z[0,5,6]  R553      -8.5245013236999512e-01
    z[0,5,6]  R554      1.6156622441485524e-03
    z[0,5,6]  R555      -1.8238635361194611e-01
    z[0,5,6]  R556      -4.7673216462135315e-01
    z[0,5,6]  R557      8.9506246149539948e-02
    z[0,5,6]  R558      1.1546920053660870e-02
    z[0,5,6]  R559      2.0072972774505615e-01
    z[0,5,6]  R560      2.2112131118774414e-01
    z[0,5,6]  R561      -2.7132892608642578e-01
    z[0,5,6]  R562      -1.6090519726276398e-01
    z[0,5,6]  R563      2.9249426722526550e-01
    z[0,5,6]  R564      2.3772367835044861e-01
    z[0,5,6]  R565      -5.8585498481988907e-02
    z[0,5,6]  R566      -6.6637277603149414e-01
    z[0,5,6]  R567      4.8056635260581970e-01
    z[0,5,6]  R568      8.0901491641998291e-01
    z[0,5,6]  R569      6.4526760578155518e-01
    z[0,5,6]  R570      -4.8482260107994080e-01
    z[0,5,6]  R571      -6.0944944620132446e-01
    z[0,5,6]  R572      6.0640677809715271e-02
    z[0,5,6]  R573      2.3719212040305138e-03
    z[0,5,6]  R574      -2.0107524469494820e-02
    z[0,5,6]  R575      5.7631272822618484e-02
    z[0,5,6]  R576      3.5792794823646545e-01
    z[0,5,6]  R577      -1.2092448025941849e-01
    z[0,5,6]  R578      7.7706307172775269e-01
    z[0,5,6]  R579      -3.0535668134689331e-01
    z[0,5,6]  R580      -2.9610633850097656e-01
    z[0,5,6]  R581      -1.9181586802005768e-01
    z[0,5,6]  R582      -1.4269690960645676e-02
    z[0,5,6]  R583      8.1576997041702271e-01
    z[0,5,6]  R584      5.9415036439895630e-01
    z[0,5,6]  R585      -0.299562931060791
    z[0,5,6]  R586      5.5895466357469559e-02
    z[0,5,6]  R587      5.3392875194549561e-01
    z[0,5,6]  R588      -2.7288362383842468e-02
    z[0,5,6]  R589      0.0652148649096489
    z[0,5,6]  R590      2.5560066103935242e-01
    z[0,5,6]  R591      -1.4847627282142639e-01
    z[0,5,6]  R592      -2.4474053084850311e-01
    z[0,5,6]  R593      3.7038065493106842e-02
    z[0,5,6]  R594      0.062696672976017
    z[0,5,6]  R595      2.6157614588737488e-01
    z[0,5,6]  R596      1.6548979282379150e-01
    z[0,5,6]  R597      2.1999673545360565e-01
    z[0,5,6]  R598      -2.5295352935791016e-01
    z[0,5,6]  R599      -3.0259797349572182e-02
    z[0,5,6]  R600      -4.4072309136390686e-01
    z[0,5,6]  R601      -1.1679602414369583e-01
    z[0,5,6]  R602      2.9156479239463806e-01
    z[0,5,6]  R603      4.9602559208869934e-01
    z[0,5,6]  R604      8.8194563984870911e-02
    z[0,5,6]  R605      -7.1552854776382446e-01
    z[0,5,6]  R606      -2.3107738792896271e-01
    z[0,5,6]  R607      -4.6637782454490662e-01
    z[0,5,6]  R608      6.1569482088088989e-01
    z[0,5,6]  R609      1.5540994703769684e-01
    z[0,5,6]  R610      2.3442228138446808e-01
    z[0,5,6]  R611      -9.4112023711204529e-02
    z[0,5,6]  R612      3.0019092559814453e-01
    z[0,5,6]  R613      -0.0115215377882123
    z[0,5,6]  R614      -1.6581559181213379e-01
    z[0,5,6]  R615      -4.2370134592056274e-01
    z[0,5,6]  R616      1.5776583552360535e-01
    z[0,5,6]  R617      -1.3237112760543823e-01
    z[0,5,6]  R618      1.8176500499248505e-01
    z[0,5,6]  R619      1.4365004003047943e-01
    z[0,5,6]  R620      7.5863234698772430e-02
    z[0,5,6]  R621      3.0158379673957825e-01
    z[5,0,0]  R2        1
    z[5,0,0]  R47       -1
    z[5,0,0]  R622      -1
    z[5,0,0]  R623      1
    z[5,0,0]  R636      2.7077559381723404e-02
    z[5,0,0]  R637      -1.4716574549674988e-01
    z[5,0,0]  R638      6.6157186031341553e-01
    z[5,0,0]  R639      3.2766574621200562e-01
    z[5,0,0]  R640      3.5326221585273743e-01
    z[5,0,0]  R641      -4.8980057239532471e-02
    z[5,0,0]  R642      4.2251950502395630e-01
    z[5,0,0]  R643      -7.9604452848434448e-01
    z[5,0,0]  R644      3.9534687995910645e-01
    z[5,0,0]  R645      -4.4654479622840881e-01
    z[5,0,0]  R646      -1.4632028341293335e-01
    z[5,0,0]  R647      -0.420944482088089
    z[5,0,0]  R648      -2.4442516267299652e-01
    z[5,0,0]  R649      -9.0486049652099609e-01
    z[5,0,0]  R650      -8.8210612535476685e-01
    z[5,0,0]  R651      -8.8734483718872070e-01
    z[5,0,0]  R652      -0.904356837272644
    z[5,0,0]  R653      -8.9519476890563965e-01
    z[5,0,0]  R654      2.6066619157791138e-01
    z[5,0,0]  R655      6.8736499547958374e-01
    z[5,0,0]  R656      -0.263374388217926
    z[5,0,0]  R657      -3.5421472787857056e-01
    z[5,0,0]  R658      -7.9832553863525391e-02
    z[5,0,0]  R659      -1.8112431466579437e-01
    z[5,0,0]  R660      -4.8229244351387024e-01
    z[5,0,0]  R661      -3.9737311005592346e-01
    z[5,0,0]  R662      -3.8635954260826111e-01
    z[5,0,0]  R663      -2.6415404677391052e-01
    z[5,0,0]  R664      -0.52254319190979
    z[5,0,0]  R665      -1.6679821908473969e-01
    z[5,0,0]  R666      -5.2074825763702393e-01
    z[5,0,0]  R667      -3.2534840703010559e-01
    z[5,0,0]  R668      -6.1319935321807861e-01
    z[5,0,0]  R669      -6.7678910493850708e-01
    z[5,0,0]  R670      -4.2548552155494690e-01
    z[5,0,0]  R671      -4.3196880817413330e-01
    z[5,0,0]  R672      -5.6378740072250366e-01
    z[5,0,0]  R673      -2.3224976658821106e-01
    z[5,0,0]  R674      -4.8676493763923645e-01
    z[5,0,0]  R675      -6.3810366392135620e-01
    z[5,0,0]  R676      -5.1050257682800293e-01
    z[5,0,0]  R677      -4.1413670778274536e-01
    z[5,0,0]  R678      -3.9808002114295959e-01
    z[5,0,0]  R679      -2.7420192956924438e-01
    z[5,0,0]  R680      -0.250662624835968
    z[5,0,0]  R681      -4.4196444749832153e-01
    z[5,0,0]  R682      -0.415751576423645
    z[5,0,0]  R683      4.9911633133888245e-01
    z[5,0,0]  R684      -7.5694888830184937e-02
    z[5,0,0]  R685      -6.8983119726181030e-01
    z[5,0,0]  R686      -1.5377275645732880e-01
    z[5,0,0]  R687      -5.7229089736938477e-01
    z[5,0,0]  R688      1.7609516158699989e-02
    z[5,0,0]  R689      -7.9494613409042358e-01
    z[5,0,0]  R690      -4.1513875126838684e-01
    z[5,0,0]  R691      -2.5649663805961609e-01
    z[5,0,0]  R692      -2.4282118678092957e-01
    z[5,0,0]  R693      1.9869744777679443e-01
    z[5,0,0]  R694      3.8046124577522278e-01
    z[5,0,0]  R695      -6.0589760541915894e-01
    z[5,0,0]  R696      -7.2114330530166626e-01
    z[5,0,0]  R697      -2.8105261921882629e-01
    z[5,0,0]  R698      -4.4869899749755859e-01
    z[5,0,0]  R699      -7.7343314886093140e-01
    z[5,0,0]  R700      -5.3159594535827637e-01
    z[5,0,0]  R701      -6.0012131929397583e-01
    z[5,0,0]  R702      -4.9606877565383911e-01
    z[5,0,0]  R703      -0.329940527677536
    z[5,0,0]  R704      -6.3231301307678223e-01
    z[5,0,0]  R705      -7.1913182735443115e-01
    z[5,0,0]  R706      -6.6646450757980347e-01
    z[5,0,0]  R707      -4.4938430190086365e-01
    z[5,0,0]  R708      -3.7860605120658875e-01
    z[5,0,0]  R709      -5.9573411941528320e-01
    z[5,0,0]  R710      -2.6482513546943665e-01
    z[5,0,0]  R711      6.5551483631134033e-01
    z[5,0,0]  R712      5.2602589130401611e-01
    z[5,0,0]  R713      4.7809746861457825e-01
    z[5,0,1]  R3        1
    z[5,0,1]  R48       -1
    z[5,0,1]  R624      -1
    z[5,0,1]  R625      1
    z[5,0,1]  R636      2.1032528579235077e-01
    z[5,0,1]  R637      1.4855297282338142e-02
    z[5,0,1]  R638      -4.6718326210975647e-01
    z[5,0,1]  R639      4.1429869830608368e-02
    z[5,0,1]  R640      -1.5066677331924438e-01
    z[5,0,1]  R641      3.8200950622558594e-01
    z[5,0,1]  R642      -5.6179088354110718e-01
    z[5,0,1]  R643      -2.5091665983200073e-01
    z[5,0,1]  R644      0.735697329044342
    z[5,0,1]  R645      5.1107460260391235e-01
    z[5,0,1]  R646      3.1154605746269226e-01
    z[5,0,1]  R647      4.4397643208503723e-01
    z[5,0,1]  R648      -2.0141474902629852e-01
    z[5,0,1]  R649      -1.1928041279315948e-01
    z[5,0,1]  R650      1.0443801991641521e-02
    z[5,0,1]  R651      -1.9972890615463257e-01
    z[5,0,1]  R652      -2.3908819258213043e-01
    z[5,0,1]  R653      -0.086459219455719
    z[5,0,1]  R654      -3.8004130125045776e-01
    z[5,0,1]  R655      1.2914985418319702e-01
    z[5,0,1]  R656      -6.0805189609527588e-01
    z[5,0,1]  R657      4.6549469232559204e-01
    z[5,0,1]  R658      3.6320638656616211e-01
    z[5,0,1]  R659      -3.6114744842052460e-02
    z[5,0,1]  R660      1.7353674769401550e-01
    z[5,0,1]  R661      -9.5659092068672180e-02
    z[5,0,1]  R662      2.6273140311241150e-01
    z[5,0,1]  R663      3.4583482146263123e-01
    z[5,0,1]  R664      0.436414510011673
    z[5,0,1]  R665      5.1943540573120117e-01
    z[5,0,1]  R666      3.0021563172340393e-01
    z[5,0,1]  R667      -1.1087644845247269e-02
    z[5,0,1]  R668      -4.4893079996109009e-01
    z[5,0,1]  R669      2.4222756922245026e-01
    z[5,0,1]  R670      7.0605480670928955e-01
    z[5,0,1]  R671      2.8052747249603271e-01
    z[5,0,1]  R672      0.141468808054924
    z[5,0,1]  R673      5.7313489913940430e-01
    z[5,0,1]  R674      0.757927417755127
    z[5,0,1]  R675      1.2237020581960678e-01
    z[5,0,1]  R676      -4.8806208372116089e-01
    z[5,0,1]  R677      -3.4369107335805893e-02
    z[5,0,1]  R678      -2.7779793739318848e-01
    z[5,0,1]  R679      3.0863738059997559e-01
    z[5,0,1]  R680      1.4711010456085205e-01
    z[5,0,1]  R681      3.1626126170158386e-01
    z[5,0,1]  R682      -2.4398358166217804e-01
    z[5,0,1]  R683      -6.4226680994033813e-01
    z[5,0,1]  R684      1.4490969479084015e-01
    z[5,0,1]  R685      -0.508252739906311
    z[5,0,1]  R686      3.9389175176620483e-01
    z[5,0,1]  R687      -3.8466867804527283e-01
    z[5,0,1]  R688      3.8059738278388977e-01
    z[5,0,1]  R689      5.1676928997039795e-03
    z[5,0,1]  R690      3.6710596084594727e-01
    z[5,0,1]  R691      2.5813370943069458e-01
    z[5,0,1]  R692      -1.7019649967551231e-02
    z[5,0,1]  R693      -9.6564933657646179e-02
    z[5,0,1]  R694      3.7928631901741028e-01
    z[5,0,1]  R695      -1.8180562555789948e-01
    z[5,0,1]  R696      5.2720570564270020e-01
    z[5,0,1]  R697      -1.1440214514732361e-01
    z[5,0,1]  R698      -1.3806633651256561e-01
    z[5,0,1]  R699      1.2277326732873917e-01
    z[5,0,1]  R700      3.2525521516799927e-01
    z[5,0,1]  R701      5.1913678646087646e-01
    z[5,0,1]  R702      2.8732863068580627e-01
    z[5,0,1]  R703      1.3171996176242828e-01
    z[5,0,1]  R704      -4.1761600971221924e-01
    z[5,0,1]  R705      -0.0854039341211319
    z[5,0,1]  R706      5.4671216756105423e-02
    z[5,0,1]  R707      2.5702759623527527e-01
    z[5,0,1]  R708      -1.1032313853502274e-01
    z[5,0,1]  R709      2.2009618580341339e-01
    z[5,0,1]  R710      -5.0603024661540985e-02
    z[5,0,1]  R711      1.2957285344600677e-01
    z[5,0,1]  R712      -5.9226787090301514e-01
    z[5,0,1]  R713      -5.5985063314437866e-01
    z[5,0,2]  R4        1
    z[5,0,2]  R49       -1
    z[5,0,2]  R626      -1
    z[5,0,2]  R627      1
    z[5,0,2]  R636      -3.7991592288017273e-01
    z[5,0,2]  R637      -2.9864221811294556e-01
    z[5,0,2]  R638      2.2859716415405273e-01
    z[5,0,2]  R639      5.4286282509565353e-02
    z[5,0,2]  R640      3.1203457713127136e-01
    z[5,0,2]  R641      3.1310686469078064e-01
    z[5,0,2]  R642      -2.7816560864448547e-01
    z[5,0,2]  R643      2.3640289902687073e-01
    z[5,0,2]  R644      -2.6094261556863785e-02
    z[5,0,2]  R645      1.8322923779487610e-01
    z[5,0,2]  R646      5.8794164657592773e-01
    z[5,0,2]  R647      4.9670797586441040e-01
    z[5,0,2]  R648      -4.6606090664863586e-01
    z[5,0,2]  R649      -4.8526491969823837e-02
    z[5,0,2]  R650      -1.6023044288158417e-01
    z[5,0,2]  R651      -1.6508170962333679e-01
    z[5,0,2]  R652      3.1460151076316833e-02
    z[5,0,2]  R653      -3.8388580083847046e-02
    z[5,0,2]  R654      -7.5717502832412720e-01
    z[5,0,2]  R655      -5.6900328397750854e-01
    z[5,0,2]  R656      -3.2385990023612976e-01
    z[5,0,2]  R657      3.2324889302253723e-01
    z[5,0,2]  R658      -2.2880828380584717e-01
    z[5,0,2]  R659      2.3817861452698708e-02
    z[5,0,2]  R660      -5.9765762090682983e-01
    z[5,0,2]  R661      9.3544498085975647e-02
    z[5,0,2]  R662      1.4512469060719013e-02
    z[5,0,2]  R663      -5.7201376184821129e-03
    z[5,0,2]  R664      -2.1587004885077477e-03
    z[5,0,2]  R665      1.3724106363952160e-02
    z[5,0,2]  R666      -1.7262664437294006e-01
    z[5,0,2]  R667      2.0977419614791870e-01
    z[5,0,2]  R668      6.6898196935653687e-02
    z[5,0,2]  R669      2.9794535040855408e-01
    z[5,0,2]  R670      -1.7164038121700287e-01
    z[5,0,2]  R671      -3.8066305220127106e-02
    z[5,0,2]  R672      3.0879396200180054e-01
    z[5,0,2]  R673      6.9130671024322510e-01
    z[5,0,2]  R674      3.0642521381378174e-01
    z[5,0,2]  R675      7.1892279386520386e-01
    z[5,0,2]  R676      -7.8089058399200439e-02
    z[5,0,2]  R677      4.7867175936698914e-01
    z[5,0,2]  R678      -2.0526094734668732e-01
    z[5,0,2]  R679      8.8499084115028381e-02
    z[5,0,2]  R680      1.3336643576622009e-01
    z[5,0,2]  R681      9.0247161686420441e-02
    z[5,0,2]  R682      -3.9138570427894592e-01
    z[5,0,2]  R683      7.0476770401000977e-02
    z[5,0,2]  R684      -1.7431662976741791e-01
    z[5,0,2]  R685      -1.4511856436729431e-01
    z[5,0,2]  R686      -4.9307456612586975e-01
    z[5,0,2]  R687      -1.3726910948753357e-01
    z[5,0,2]  R688      -2.3731899261474609e-01
    z[5,0,2]  R689      1.1613065004348755e-01
    z[5,0,2]  R690      2.5074377655982971e-01
    z[5,0,2]  R691      -1.1884884536266327e-01
    z[5,0,2]  R692      -2.7144595980644226e-02
    z[5,0,2]  R693      1.6922371461987495e-02
    z[5,0,2]  R694      -0.386527419090271
    z[5,0,2]  R695      -4.6282148361206055e-01
    z[5,0,2]  R696      3.1402400135993958e-01
    z[5,0,2]  R697      -9.9856235086917877e-02
    z[5,0,2]  R698      4.0449555963277817e-02
    z[5,0,2]  R699      3.7255486845970154e-01
    z[5,0,2]  R700      3.8669133186340332e-01
    z[5,0,2]  R701      4.9616372585296631e-01
    z[5,0,2]  R702      2.7691638469696045e-01
    z[5,0,2]  R703      3.2598786056041718e-02
    z[5,0,2]  R704      -2.6528376340866089e-01
    z[5,0,2]  R705      -3.4190118312835693e-01
    z[5,0,2]  R706      3.9620009064674377e-01
    z[5,0,2]  R707      -2.5621235370635986e-01
    z[5,0,2]  R708      2.4623025953769684e-01
    z[5,0,2]  R709      -4.5212548971176147e-01
    z[5,0,2]  R710      0.541815459728241
    z[5,0,2]  R711      2.0388497412204742e-01
    z[5,0,2]  R712      0.115140900015831
    z[5,0,2]  R713      1.3454304635524750e-01
    z[5,0,3]  R5        1
    z[5,0,3]  R50       -1
    z[5,0,3]  R628      -1
    z[5,0,3]  R629      1
    z[5,0,3]  R636      1.4298340678215027e-01
    z[5,0,3]  R637      3.0610656738281250e-01
    z[5,0,3]  R638      -4.5985820889472961e-01
    z[5,0,3]  R639      -5.7009279727935791e-01
    z[5,0,3]  R640      -2.6410719752311707e-01
    z[5,0,3]  R641      4.0180769562721252e-01
    z[5,0,3]  R642      5.2533990144729614e-01
    z[5,0,3]  R643      -2.3259180784225464e-01
    z[5,0,3]  R644      3.7807571887969971e-01
    z[5,0,3]  R645      -6.2137925624847412e-01
    z[5,0,3]  R646      -5.2404171228408813e-01
    z[5,0,3]  R647      -2.4119694530963898e-01
    z[5,0,3]  R648      -6.6314691305160522e-01
    z[5,0,3]  R649      -3.0422553420066833e-01
    z[5,0,3]  R650      -4.0116128325462341e-01
    z[5,0,3]  R651      -3.2623365521430969e-01
    z[5,0,3]  R652      -2.2785899043083191e-01
    z[5,0,3]  R653      -1.5573722124099731e-01
    z[5,0,3]  R654      4.4498935341835022e-01
    z[5,0,3]  R655      1.3671043515205383e-01
    z[5,0,3]  R656      3.5809266567230225e-01
    z[5,0,3]  R657      -6.9943493604660034e-01
    z[5,0,3]  R658      7.0330011844635010e-01
    z[5,0,3]  R659      -7.9711538553237915e-01
    z[5,0,3]  R660      -5.2426481246948242e-01
    z[5,0,3]  R661      2.8820842504501343e-01
    z[5,0,3]  R662      -7.1607358753681183e-02
    z[5,0,3]  R663      1.1428820900619030e-02
    z[5,0,3]  R664      7.1843981742858887e-01
    z[5,0,3]  R665      0.767024576663971
    z[5,0,3]  R666      5.2506107091903687e-01
    z[5,0,3]  R667      7.8709018230438232e-01
    z[5,0,3]  R668      3.2510581612586975e-01
    z[5,0,3]  R669      -2.4433358013629913e-01
    z[5,0,3]  R670      -2.2244943678379059e-01
    z[5,0,3]  R671      -2.4872237443923950e-01
    z[5,0,3]  R672      -4.7648698091506958e-02
    z[5,0,3]  R673      -2.8952676802873611e-02
    z[5,0,3]  R674      -1.7613938450813293e-01
    z[5,0,3]  R675      -1.9964993000030518e-01
    z[5,0,3]  R676      0.169372096657753
    z[5,0,3]  R677      -5.0430363416671753e-01
    z[5,0,3]  R678      1.3047042489051819e-01
    z[5,0,3]  R679      -3.4408786892890930e-01
    z[5,0,3]  R680      -5.6352108716964722e-01
    z[5,0,3]  R681      -6.3955657184123993e-02
    z[5,0,3]  R682      -1.8583008646965027e-01
    z[5,0,3]  R683      -4.5038792490959167e-01
    z[5,0,3]  R684      6.7879599332809448e-01
    z[5,0,3]  R685      4.0666261315345764e-01
    z[5,0,3]  R686      3.0813366174697876e-01
    z[5,0,3]  R687      1.2624089419841766e-01
    z[5,0,3]  R688      3.4994545578956604e-01
    z[5,0,3]  R689      -3.4447062015533447e-01
    z[5,0,3]  R690      -2.2915521264076233e-01
    z[5,0,3]  R691      -7.4665099382400513e-01
    z[5,0,3]  R692      -6.8823331594467163e-01
    z[5,0,3]  R693      3.6833325028419495e-01
    z[5,0,3]  R694      2.7590623497962952e-01
    z[5,0,3]  R695      3.2269775867462158e-01
    z[5,0,3]  R696      0.033777866512537
    z[5,0,3]  R697      4.5802673697471619e-01
    z[5,0,3]  R698      5.2076929807662964e-01
    z[5,0,3]  R699      -4.4654447585344315e-02
    z[5,0,3]  R700      -1.7903535068035126e-01
    z[5,0,3]  R701      -8.9750796556472778e-02
    z[5,0,3]  R702      -2.9387819766998291e-01
    z[5,0,3]  R703      -8.5171580314636230e-01
    z[5,0,3]  R704      5.4771190881729126e-01
    z[5,0,3]  R705      3.6372488737106323e-01
    z[5,0,3]  R706      -4.1303125023841858e-01
    z[5,0,3]  R707      -5.3499639034271240e-01
    z[5,0,3]  R708      -5.0670784711837769e-01
    z[5,0,3]  R709      -5.1254862546920776e-01
    z[5,0,3]  R710      -4.2260074615478516e-01
    z[5,0,3]  R711      2.6115423440933228e-01
    z[5,0,3]  R712      -3.1107750535011292e-01
    z[5,0,3]  R713      -4.1094040870666504e-01
    z[5,0,4]  R6        1
    z[5,0,4]  R51       -1
    z[5,0,4]  R630      -1
    z[5,0,4]  R631      1
    z[5,0,4]  R636      -2.6978400349617004e-01
    z[5,0,4]  R637      -1.9433347880840302e-01
    z[5,0,4]  R638      -6.5487218089401722e-03
    z[5,0,4]  R639      -2.4164788424968719e-01
    z[5,0,4]  R640      -5.3179544210433960e-01
    z[5,0,4]  R641      -0.715399980545044
    z[5,0,4]  R642      2.4729570746421814e-01
    z[5,0,4]  R643      -2.6987606287002563e-01
    z[5,0,4]  R644      2.1347737312316895e-01
    z[5,0,4]  R645      6.6397614777088165e-02
    z[5,0,4]  R646      -0.0682741329073906
    z[5,0,4]  R647      1.9729943946003914e-02
    z[5,0,4]  R648      1.2859743833541870e-01
    z[5,0,4]  R649      3.1697552651166916e-02
    z[5,0,4]  R650      -4.4534732587635517e-03
    z[5,0,4]  R651      1.1686767637729645e-01
    z[5,0,4]  R652      -2.5458750128746033e-01
    z[5,0,4]  R653      -3.8164101541042328e-02
    z[5,0,4]  R654      5.4954297840595245e-02
    z[5,0,4]  R655      -0.292703777551651
    z[5,0,4]  R656      -5.3515750169754028e-01
    z[5,0,4]  R657      1.4074082672595978e-01
    z[5,0,4]  R658      -3.4535288810729980e-01
    z[5,0,4]  R659      2.1173091232776642e-01
    z[5,0,4]  R660      3.1077867746353149e-01
    z[5,0,4]  R661      -9.2578649520874023e-02
    z[5,0,4]  R662      -1.6210518777370453e-01
    z[5,0,4]  R663      1.8958781659603119e-01
    z[5,0,4]  R664      0.085997074842453
    z[5,0,4]  R665      2.2456325590610504e-01
    z[5,0,4]  R666      -5.9939321363344789e-04
    z[5,0,4]  R667      -5.8068487793207169e-02
    z[5,0,4]  R668      3.3228802680969238e-01
    z[5,0,4]  R669      -3.1062791123986244e-02
    z[5,0,4]  R670      2.4182732403278351e-01
    z[5,0,4]  R671      5.8144098520278931e-01
    z[5,0,4]  R672      5.7347220182418823e-01
    z[5,0,4]  R673      -4.6587616205215454e-02
    z[5,0,4]  R674      -2.3897903040051460e-02
    z[5,0,4]  R675      9.1737970709800720e-02
    z[5,0,4]  R676      3.5825878381729126e-02
    z[5,0,4]  R677      0.216657355427742
    z[5,0,4]  R678      2.2498093545436859e-01
    z[5,0,4]  R679      5.3508430719375610e-01
    z[5,0,4]  R680      -1.2030213326215744e-01
    z[5,0,4]  R681      -1.2941746413707733e-01
    z[5,0,4]  R682      1.9787830114364624e-01
    z[5,0,4]  R683      -3.0504795908927917e-01
    z[5,0,4]  R684      -6.3864976167678833e-01
    z[5,0,4]  R685      1.7508701980113983e-01
    z[5,0,4]  R686      5.2330672740936279e-02
    z[5,0,4]  R687      6.1832553148269653e-01
    z[5,0,4]  R688      2.3572294414043427e-01
    z[5,0,4]  R689      5.8638691902160645e-02
    z[5,0,4]  R690      6.9978588819503784e-01
    z[5,0,4]  R691      1.9350986927747726e-02
    z[5,0,4]  R692      6.7504072189331055e-01
    z[5,0,4]  R693      -3.2833638787269592e-01
    z[5,0,4]  R694      3.6444410681724548e-01
    z[5,0,4]  R695      4.1179046034812927e-01
    z[5,0,4]  R696      1.9429470598697662e-01
    z[5,0,4]  R697      4.8103532195091248e-01
    z[5,0,4]  R698      4.8666661977767944e-01
    z[5,0,4]  R699      4.8793444037437439e-01
    z[5,0,4]  R700      6.0222244262695312e-01
    z[5,0,4]  R701      2.1910466253757477e-01
    z[5,0,4]  R702      6.6941720247268677e-01
    z[5,0,4]  R703      1.2802883982658386e-02
    z[5,0,4]  R704      -2.1214410662651062e-01
    z[5,0,4]  R705      3.2606017589569092e-01
    z[5,0,4]  R706      4.3784341216087341e-01
    z[5,0,4]  R707      4.1435211896896362e-01
    z[5,0,4]  R708      0.459890216588974
    z[5,0,4]  R709      1.0586746037006378e-01
    z[5,0,4]  R710      9.8830088973045349e-02
    z[5,0,4]  R711      2.2619621828198433e-02
    z[5,0,4]  R712      1.8653546273708344e-01
    z[5,0,4]  R713      1.4439335465431213e-01
    z[5,0,5]  R7        1
    z[5,0,5]  R52       -1
    z[5,0,5]  R632      -1
    z[5,0,5]  R633      1
    z[5,0,5]  R636      -8.4242987632751465e-01
    z[5,0,5]  R637      -4.9546590447425842e-01
    z[5,0,5]  R638      -1.6400189697742462e-01
    z[5,0,5]  R639      -5.3578341007232666e-01
    z[5,0,5]  R640      -1.5329921245574951e-01
    z[5,0,5]  R641      2.3713913559913635e-01
    z[5,0,5]  R642      1.9079077243804932e-01
    z[5,0,5]  R643      3.3418321609497070e-01
    z[5,0,5]  R644      1.5212121605873108e-01
    z[5,0,5]  R645      3.3937299251556396e-01
    z[5,0,5]  R646      4.7862115502357483e-01
    z[5,0,5]  R647      3.7534487247467041e-01
    z[5,0,5]  R648      4.4864749908447266e-01
    z[5,0,5]  R649      2.3144076764583588e-01
    z[5,0,5]  R650      -4.6014860272407532e-02
    z[5,0,5]  R651      6.8947292864322662e-02
    z[5,0,5]  R652      3.8678757846355438e-02
    z[5,0,5]  R653      2.7021130919456482e-01
    z[5,0,5]  R654      9.3472130596637726e-02
    z[5,0,5]  R655      -2.8760486841201782e-01
    z[5,0,5]  R656      -1.0530462861061096e-01
    z[5,0,5]  R657      -0.210502028465271
    z[5,0,5]  R658      -2.9261013865470886e-01
    z[5,0,5]  R659      1.0185271501541138e-01
    z[5,0,5]  R660      -7.6998159289360046e-02
    z[5,0,5]  R661      0.0739939957857132
    z[5,0,5]  R662      1.3512995839118958e-01
    z[5,0,5]  R663      -2.1873018145561218e-01
    z[5,0,5]  R664      -1.1372113227844238e-01
    z[5,0,5]  R665      1.7365668714046478e-01
    z[5,0,5]  R666      -3.2546716928482056e-01
    z[5,0,5]  R667      4.6810904145240784e-01
    z[5,0,5]  R668      4.4914358854293823e-01
    z[5,0,5]  R669      5.4180693626403809e-01
    z[5,0,5]  R670      3.6623695492744446e-01
    z[5,0,5]  R671      5.0960993766784668e-01
    z[5,0,5]  R672      4.5797964930534363e-01
    z[5,0,5]  R673      2.2607523202896118e-01
    z[5,0,5]  R674      8.1245154142379761e-02
    z[5,0,5]  R675      9.6389196813106537e-02
    z[5,0,5]  R676      1.4512623846530914e-01
    z[5,0,5]  R677      2.5685855746269226e-01
    z[5,0,5]  R678      -0.00919504277408123
    z[5,0,5]  R679      -2.5343004614114761e-02
    z[5,0,5]  R680      5.7502931356430054e-01
    z[5,0,5]  R681      5.5157393217086792e-01
    z[5,0,5]  R682      -7.3285329341888428e-01
    z[5,0,5]  R683      1.9364964962005615e-01
    z[5,0,5]  R684      -2.7174144983291626e-01
    z[5,0,5]  R685      2.1307614445686340e-01
    z[5,0,5]  R686      -5.9353464841842651e-01
    z[5,0,5]  R687      3.0460536479949951e-01
    z[5,0,5]  R688      -1.2907807528972626e-01
    z[5,0,5]  R689      3.7310361862182617e-01
    z[5,0,5]  R690      1.1365479789674282e-02
    z[5,0,5]  R691      5.0871992111206055e-01
    z[5,0,5]  R692      1.0228655487298965e-01
    z[5,0,5]  R693      2.0482501387596130e-01
    z[5,0,5]  R694      -5.4149203933775425e-03
    z[5,0,5]  R695      -1.4895612001419067e-01
    z[5,0,5]  R696      2.4774929881095886e-01
    z[5,0,5]  R697      0.414351224899292
    z[5,0,5]  R698      5.1882648468017578e-01
    z[5,0,5]  R699      6.0031764209270477e-02
    z[5,0,5]  R700      4.5026890933513641e-02
    z[5,0,5]  R701      -2.1462911367416382e-01
    z[5,0,5]  R702      -1.7139786854386330e-02
    z[5,0,5]  R703      3.8179942965507507e-01
    z[5,0,5]  R704      -8.0481000244617462e-02
    z[5,0,5]  R705      -2.2721394896507263e-01
    z[5,0,5]  R706      -7.8569419682025909e-02
    z[5,0,5]  R707      4.0004798769950867e-01
    z[5,0,5]  R708      5.0161701440811157e-01
    z[5,0,5]  R709      -3.4265366196632385e-01
    z[5,0,5]  R710      5.0114601850509644e-01
    z[5,0,5]  R711      6.5542924404144287e-01
    z[5,0,5]  R712      -3.7773460149765015e-01
    z[5,0,5]  R713      -6.4229391515254974e-02
    z[5,0,6]  R8        1
    z[5,0,6]  R53       -1
    z[5,0,6]  R634      -1
    z[5,0,6]  R635      1
    z[5,0,6]  R636      8.8194563984870911e-02
    z[5,0,6]  R637      -7.1552854776382446e-01
    z[5,0,6]  R638      -2.3107738792896271e-01
    z[5,0,6]  R639      -4.6637782454490662e-01
    z[5,0,6]  R640      6.1569482088088989e-01
    z[5,0,6]  R641      1.5540994703769684e-01
    z[5,0,6]  R642      2.3442228138446808e-01
    z[5,0,6]  R643      -9.4112023711204529e-02
    z[5,0,6]  R644      3.0019092559814453e-01
    z[5,0,6]  R645      -0.0115215377882123
    z[5,0,6]  R646      -1.6581559181213379e-01
    z[5,0,6]  R647      -4.2370134592056274e-01
    z[5,0,6]  R648      1.5776583552360535e-01
    z[5,0,6]  R649      -1.3237112760543823e-01
    z[5,0,6]  R650      1.8176500499248505e-01
    z[5,0,6]  R651      1.4365004003047943e-01
    z[5,0,6]  R652      7.5863234698772430e-02
    z[5,0,6]  R653      3.0158379673957825e-01
    z[5,0,6]  R654      -0.0673435777425766
    z[5,0,6]  R655      -1.7936335643753409e-03
    z[5,0,6]  R656      1.7409424483776093e-01
    z[5,0,6]  R657      -5.3414665162563324e-03
    z[5,0,6]  R658      3.3141264319419861e-01
    z[5,0,6]  R659      -5.2414262294769287e-01
    z[5,0,6]  R660      -5.2139669656753540e-02
    z[5,0,6]  R661      -8.5269182920455933e-01
    z[5,0,6]  R662      8.5546606779098511e-01
    z[5,0,6]  R663      -8.5245013236999512e-01
    z[5,0,6]  R664      1.6156622441485524e-03
    z[5,0,6]  R665      -1.8238635361194611e-01
    z[5,0,6]  R666      -4.7673216462135315e-01
    z[5,0,6]  R667      8.9506246149539948e-02
    z[5,0,6]  R668      1.1546920053660870e-02
    z[5,0,6]  R669      2.0072972774505615e-01
    z[5,0,6]  R670      2.2112131118774414e-01
    z[5,0,6]  R671      -2.7132892608642578e-01
    z[5,0,6]  R672      -1.6090519726276398e-01
    z[5,0,6]  R673      2.9249426722526550e-01
    z[5,0,6]  R674      2.3772367835044861e-01
    z[5,0,6]  R675      -5.8585498481988907e-02
    z[5,0,6]  R676      -6.6637277603149414e-01
    z[5,0,6]  R677      4.8056635260581970e-01
    z[5,0,6]  R678      8.0901491641998291e-01
    z[5,0,6]  R679      6.4526760578155518e-01
    z[5,0,6]  R680      -4.8482260107994080e-01
    z[5,0,6]  R681      -6.0944944620132446e-01
    z[5,0,6]  R682      6.0640677809715271e-02
    z[5,0,6]  R683      2.3719212040305138e-03
    z[5,0,6]  R684      -2.0107524469494820e-02
    z[5,0,6]  R685      5.7631272822618484e-02
    z[5,0,6]  R686      3.5792794823646545e-01
    z[5,0,6]  R687      -1.2092448025941849e-01
    z[5,0,6]  R688      7.7706307172775269e-01
    z[5,0,6]  R689      -3.0535668134689331e-01
    z[5,0,6]  R690      -2.9610633850097656e-01
    z[5,0,6]  R691      -1.9181586802005768e-01
    z[5,0,6]  R692      -1.4269690960645676e-02
    z[5,0,6]  R693      8.1576997041702271e-01
    z[5,0,6]  R694      5.9415036439895630e-01
    z[5,0,6]  R695      -0.299562931060791
    z[5,0,6]  R696      5.5895466357469559e-02
    z[5,0,6]  R697      5.3392875194549561e-01
    z[5,0,6]  R698      -2.7288362383842468e-02
    z[5,0,6]  R699      0.0652148649096489
    z[5,0,6]  R700      2.5560066103935242e-01
    z[5,0,6]  R701      -1.4847627282142639e-01
    z[5,0,6]  R702      -2.4474053084850311e-01
    z[5,0,6]  R703      3.7038065493106842e-02
    z[5,0,6]  R704      0.062696672976017
    z[5,0,6]  R705      2.6157614588737488e-01
    z[5,0,6]  R706      1.6548979282379150e-01
    z[5,0,6]  R707      2.1999673545360565e-01
    z[5,0,6]  R708      -2.5295352935791016e-01
    z[5,0,6]  R709      -3.0259797349572182e-02
    z[5,0,6]  R710      -4.4072309136390686e-01
    z[5,0,6]  R711      -1.1679602414369583e-01
    z[5,0,6]  R712      2.9156479239463806e-01
    z[5,0,6]  R713      4.9602559208869934e-01
    z[1,2,0]  R11       -1
    z[1,2,0]  R20       1
    z[1,2,0]  R788      -1
    z[1,2,0]  R789      1
    z[1,2,0]  R802      7.4860262870788574e-01
    z[1,2,0]  R803      3.6833679676055908e-01
    z[1,2,0]  R804      -2.2596074640750885e-01
    z[1,2,0]  R805      -3.0306759476661682e-01
    z[1,2,0]  R806      -1.4573006331920624e-01
    z[1,2,0]  R807      -0.50286865234375
    z[1,2,0]  R808      -8.5654549300670624e-02
    z[1,2,0]  R809      1.5423680841922760e-01
    z[1,2,0]  R810      -3.0090352892875671e-01
    z[1,2,0]  R811      -3.6334908008575439e-01
    z[1,2,0]  R812      -3.2288312911987305e-01
    z[1,2,0]  R813      4.0381222963333130e-01
    z[1,2,0]  R814      -8.3608108758926392e-01
    z[1,2,0]  R815      -5.0338220596313477e-01
    z[1,2,0]  R816      -6.4310878515243530e-01
    z[1,2,0]  R817      6.7158448696136475e-01
    z[1,2,0]  R818      -2.9885500669479370e-01
    z[1,2,0]  R819      -6.3888782262802124e-01
    z[1,2,0]  R820      3.1097555160522461e-01
    z[1,2,0]  R821      -5.0072693824768066e-01
    z[1,2,0]  R822      -1.9979985058307648e-01
    z[1,2,0]  R823      -5.3643178939819336e-01
    z[1,2,0]  R824      0.607283890247345
    z[1,2,0]  R825      -7.1195596456527710e-01
    z[1,2,0]  R826      -6.0410439968109131e-01
    z[1,2,0]  R827      -8.3872246742248535e-01
    z[1,2,0]  R828      -4.6909371018409729e-01
    z[1,2,0]  R829      6.2660795450210571e-01
    z[1,2,0]  R830      -3.5793432593345642e-01
    z[1,2,0]  R831      4.1159999370574951e-01
    z[1,2,0]  R832      7.6862829923629761e-01
    z[1,2,0]  R833      7.8859555721282959e-01
    z[1,2,0]  R834      0.763009250164032
    z[1,2,0]  R835      -7.1807646751403809e-01
    z[1,2,0]  R836      5.9774047136306763e-01
    z[1,2,0]  R837      -1.5244425833225250e-01
    z[1,2,0]  R838      7.3239183425903320e-01
    z[1,2,0]  R839      2.9017889499664307e-01
    z[1,2,0]  R840      2.7914133667945862e-01
    z[1,2,0]  R841      -4.0742442011833191e-02
    z[1,2,0]  R842      5.1106750965118408e-02
    z[1,2,0]  R843      5.9056133031845093e-01
    z[1,2,0]  R844      3.8707137107849121e-01
    z[1,2,0]  R845      4.8208811879158020e-01
    z[1,2,0]  R846      3.9119637012481689e-01
    z[1,2,0]  R847      1.4780405163764954e-01
    z[1,2,0]  R848      3.7821340560913086e-01
    z[1,2,0]  R849      3.1116208434104919e-01
    z[1,2,0]  R850      -7.1673743426799774e-02
    z[1,2,0]  R851      1.2954111397266388e-01
    z[1,2,0]  R852      -8.0445349216461182e-01
    z[1,2,0]  R853      -9.1631394624710083e-01
    z[1,2,0]  R854      -7.8195226192474365e-01
    z[1,2,0]  R855      -7.6881724596023560e-01
    z[1,2,0]  R856      -8.5561519861221313e-01
    z[1,2,0]  R857      -6.1567348241806030e-01
    z[1,2,0]  R858      -6.8078100681304932e-01
    z[1,2,0]  R859      -8.9947152137756348e-01
    z[1,2,0]  R860      -5.7025265693664551e-01
    z[1,2,0]  R861      -9.3417984247207642e-01
    z[1,2,0]  R862      2.1477112174034119e-01
    z[1,2,0]  R863      -3.8141974806785583e-01
    z[1,2,0]  R864      -2.7105388045310974e-01
    z[1,2,0]  R865      -5.6051395833492279e-02
    z[1,2,0]  R866      -1.5068499743938446e-01
    z[1,2,0]  R867      -3.0338394641876221e-01
    z[1,2,0]  R868      -2.7596482634544373e-01
    z[1,2,0]  R869      2.4456791579723358e-01
    z[1,2,0]  R870      -1.6306860744953156e-01
    z[1,2,0]  R871      -1.7163069546222687e-01
    z[1,2,0]  R872      -1.7435763031244278e-02
    z[1,2,0]  R873      -7.4469387531280518e-02
    z[1,2,0]  R874      4.6104887127876282e-01
    z[1,2,0]  R875      -1.5043017454445362e-02
    z[1,2,0]  R876      1.4565181732177734e-01
    z[1,2,0]  R877      4.1971042752265930e-01
    z[1,2,0]  R878      2.8397732973098755e-01
    z[1,2,0]  R879      3.6843919754028320e-01
    z[1,2,0]  R880      2.2394387423992157e-01
    z[1,2,0]  R881      -2.4747861921787262e-01
    z[1,2,0]  R882      4.6400707960128784e-01
    z[1,2,0]  R883      3.8031637668609619e-01
    z[1,2,0]  R884      -1.2748220562934875e-01
    z[1,2,0]  R885      1.2794123589992523e-01
    z[1,2,0]  R886      -0.0471976064145565
    z[1,2,0]  R887      3.4939879179000854e-01
    z[1,2,0]  R888      2.6777082681655884e-01
    z[1,2,0]  R889      2.1898530423641205e-01
    z[1,2,0]  R890      -7.4936193227767944e-01
    z[1,2,0]  R891      4.3602046370506287e-01
    z[1,2,0]  R892      2.5317353010177612e-01
    z[1,2,0]  R893      -1.3065354526042938e-01
    z[1,2,0]  R894      -2.0609799027442932e-01
    z[1,2,0]  R895      4.5509546995162964e-01
    z[1,2,0]  R896      5.4032748937606812e-01
    z[1,2,0]  R897      -2.6457160711288452e-02
    z[1,2,0]  R898      5.5485457181930542e-01
    z[1,2,0]  R899      3.8495638966560364e-01
    z[1,2,0]  R900      2.2407768666744232e-01
    z[1,2,0]  R901      1.2110158801078796e-01
    z[1,2,0]  R902      -1.7774407565593719e-01
    z[1,2,0]  R903      -1.3188990950584412e-01
    z[1,2,0]  R904      4.3774825334548950e-01
    z[1,2,0]  R905      5.7331051677465439e-02
    z[1,2,0]  R906      2.8909498453140259e-01
    z[1,2,0]  R907      2.2211559116840363e-01
    z[1,2,0]  R908      -8.4896892309188843e-01
    z[1,2,0]  R909      -9.0700966119766235e-01
    z[1,2,0]  R910      -6.8083697557449341e-01
    z[1,2,0]  R911      -7.2370398044586182e-01
    z[1,2,1]  R12       -1
    z[1,2,1]  R21       1
    z[1,2,1]  R790      -1
    z[1,2,1]  R791      1
    z[1,2,1]  R802      3.9658987522125244e-01
    z[1,2,1]  R803      3.3228096365928650e-01
    z[1,2,1]  R804      2.4429461359977722e-01
    z[1,2,1]  R805      4.4257181882858276e-01
    z[1,2,1]  R806      2.6678934693336487e-01
    z[1,2,1]  R807      2.8248181939125061e-01
    z[1,2,1]  R808      3.1439480185508728e-01
    z[1,2,1]  R809      3.0521667003631592e-01
    z[1,2,1]  R810      2.9148623347282410e-01
    z[1,2,1]  R811      4.8344865441322327e-01
    z[1,2,1]  R812      7.9831188917160034e-01
    z[1,2,1]  R813      3.5552966594696045e-01
    z[1,2,1]  R814      -5.0519472360610962e-01
    z[1,2,1]  R815      -7.0010378956794739e-02
    z[1,2,1]  R816      -3.7174528837203979e-01
    z[1,2,1]  R817      -5.6620782613754272e-01
    z[1,2,1]  R818      3.1890600919723511e-01
    z[1,2,1]  R819      -9.6032015979290009e-02
    z[1,2,1]  R820      -8.3104193210601807e-01
    z[1,2,1]  R821      -2.6378947496414185e-01
    z[1,2,1]  R822      7.5350910425186157e-01
    z[1,2,1]  R823      1.5285126864910126e-01
    z[1,2,1]  R824      2.2692620754241943e-02
    z[1,2,1]  R825      -1.4521090686321259e-01
    z[1,2,1]  R826      -9.3496374785900116e-02
    z[1,2,1]  R827      -4.4312536716461182e-02
    z[1,2,1]  R828      -9.4921454787254333e-02
    z[1,2,1]  R829      -4.1695181280374527e-02
    z[1,2,1]  R830      -2.3240816593170166e-01
    z[1,2,1]  R831      -0.521371066570282
    z[1,2,1]  R832      5.1249540410935879e-03
    z[1,2,1]  R833      -5.0348155200481415e-02
    z[1,2,1]  R834      -1.5467119216918945e-01
    z[1,2,1]  R835      1.0522312484681606e-02
    z[1,2,1]  R836      -3.1535571813583374e-01
    z[1,2,1]  R837      2.9513699933886528e-02
    z[1,2,1]  R838      -3.4852899610996246e-02
    z[1,2,1]  R839      -4.8090791702270508e-01
    z[1,2,1]  R840      -4.9988901615142822e-01
    z[1,2,1]  R841      -6.3789361715316772e-01
    z[1,2,1]  R842      2.6183715462684631e-01
    z[1,2,1]  R843      1.2515960633754730e-01
    z[1,2,1]  R844      1.2852229177951813e-01
    z[1,2,1]  R845      1.3192021846771240e-01
    z[1,2,1]  R846      1.3427737355232239e-01
    z[1,2,1]  R847      2.9381850361824036e-01
    z[1,2,1]  R848      2.6272362470626831e-01
    z[1,2,1]  R849      2.7838566899299622e-01
    z[1,2,1]  R850      0.0289725624024868
    z[1,2,1]  R851      1.6979511082172394e-01
    z[1,2,1]  R852      -1.5205812454223633e-01
    z[1,2,1]  R853      -7.9524502158164978e-02
    z[1,2,1]  R854      -1.6653977334499359e-01
    z[1,2,1]  R855      1.5908463299274445e-01
    z[1,2,1]  R856      2.7467915788292885e-02
    z[1,2,1]  R857      5.4951891303062439e-02
    z[1,2,1]  R858      -1.2749743461608887e-01
    z[1,2,1]  R859      2.0110078155994415e-01
    z[1,2,1]  R860      5.5249649286270142e-01
    z[1,2,1]  R861      2.2371090948581696e-01
    z[1,2,1]  R862      6.5280801057815552e-01
    z[1,2,1]  R863      7.8022551536560059e-01
    z[1,2,1]  R864      7.9881119728088379e-01
    z[1,2,1]  R865      7.9810267686843872e-01
    z[1,2,1]  R866      7.5457632541656494e-01
    z[1,2,1]  R867      4.2455622553825378e-01
    z[1,2,1]  R868      0.75604248046875
    z[1,2,1]  R869      -6.7479032278060913e-01
    z[1,2,1]  R870      6.9095867872238159e-01
    z[1,2,1]  R871      6.1447185277938843e-01
    z[1,2,1]  R872      8.6421352624893188e-01
    z[1,2,1]  R873      4.7324925661087036e-01
    z[1,2,1]  R874      2.4629727005958557e-01
    z[1,2,1]  R875      7.4058568477630615e-01
    z[1,2,1]  R876      4.1735228896141052e-01
    z[1,2,1]  R877      6.4956108108162880e-03
    z[1,2,1]  R878      5.5962300300598145e-01
    z[1,2,1]  R879      3.7149465084075928e-01
    z[1,2,1]  R880      1.1038370430469513e-01
    z[1,2,1]  R881      1.7028903961181641e-01
    z[1,2,1]  R882      2.2072924673557281e-01
    z[1,2,1]  R883      -3.6806592345237732e-01
    z[1,2,1]  R884      3.4903371334075928e-01
    z[1,2,1]  R885      1.3836197555065155e-01
    z[1,2,1]  R886      2.5078263878822327e-01
    z[1,2,1]  R887      -2.9295665025711060e-01
    z[1,2,1]  R888      7.8041791915893555e-02
    z[1,2,1]  R889      -1.7975407838821411e-01
    z[1,2,1]  R890      6.8886220455169678e-02
    z[1,2,1]  R891      -5.4082065820693970e-01
    z[1,2,1]  R892      5.5137449502944946e-01
    z[1,2,1]  R893      6.7315852642059326e-01
    z[1,2,1]  R894      0.659210205078125
    z[1,2,1]  R895      -5.2719074487686157e-01
    z[1,2,1]  R896      2.4181348085403442e-01
    z[1,2,1]  R897      5.4068428277969360e-01
    z[1,2,1]  R898      -2.0332334935665131e-01
    z[1,2,1]  R899      -3.8963535428047180e-01
    z[1,2,1]  R900      2.2602890431880951e-01
    z[1,2,1]  R901      4.3761026114225388e-02
    z[1,2,1]  R902      7.8564041852951050e-01
    z[1,2,1]  R903      9.6119928359985352e-01
    z[1,2,1]  R904      -1.9524261355400085e-01
    z[1,2,1]  R905      3.3782741427421570e-01
    z[1,2,1]  R906      2.0614726468920708e-02
    z[1,2,1]  R907      1.4211824536323547e-01
    z[1,2,1]  R908      1.4025595784187317e-01
    z[1,2,1]  R909      1.0417796671390533e-02
    z[1,2,1]  R910      6.0442048124969006e-03
    z[1,2,1]  R911      5.0666470080614090e-02
    z[1,2,2]  R13       -1
    z[1,2,2]  R22       1
    z[1,2,2]  R792      -1
    z[1,2,2]  R793      1
    z[1,2,2]  R802      1.2885268032550812e-01
    z[1,2,2]  R803      1.4797152578830719e-01
    z[1,2,2]  R804      7.6367869973182678e-02
    z[1,2,2]  R805      1.0282432287931442e-01
    z[1,2,2]  R806      4.6960480511188507e-02
    z[1,2,2]  R807      -1.8596945703029633e-01
    z[1,2,2]  R808      1.6917736828327179e-01
    z[1,2,2]  R809      1.0263492166996002e-01
    z[1,2,2]  R810      -1.2520714104175568e-01
    z[1,2,2]  R811      0.291836678981781
    z[1,2,2]  R812      0.0642719641327858
    z[1,2,2]  R813      -6.8011187016963959e-02
    z[1,2,2]  R814      -1.1339828372001648e-01
    z[1,2,2]  R815      -7.1803522109985352e-01
    z[1,2,2]  R816      -9.6472300589084625e-02
    z[1,2,2]  R817      8.3359532058238983e-02
    z[1,2,2]  R818      4.7368472814559937e-01
    z[1,2,2]  R819      -1.4865960180759430e-01
    z[1,2,2]  R820      -3.7821326404809952e-03
    z[1,2,2]  R821      -9.9031753838062286e-02
    z[1,2,2]  R822      3.6033112555742264e-02
    z[1,2,2]  R823      4.8918455839157104e-01
    z[1,2,2]  R824      2.5622749328613281e-01
    z[1,2,2]  R825      1.3521020114421844e-01
    z[1,2,2]  R826      4.4283643364906311e-01
    z[1,2,2]  R827      -1.9770139455795288e-01
    z[1,2,2]  R828      7.4132215976715088e-01
    z[1,2,2]  R829      2.6134006679058075e-02
    z[1,2,2]  R830      2.2976528108119965e-01
    z[1,2,2]  R831      2.9996795579791069e-02
    z[1,2,2]  R832      1.0451861470937729e-01
    z[1,2,2]  R833      5.2703902125358582e-02
    z[1,2,2]  R834      1.2970089912414551e-01
    z[1,2,2]  R835      -1.4823801815509796e-01
    z[1,2,2]  R836      7.5197708792984486e-03
    z[1,2,2]  R837      3.6111307144165039e-01
    z[1,2,2]  R838      1.5699344873428345e-01
    z[1,2,2]  R839      7.2317175567150116e-02
    z[1,2,2]  R840      2.7384883165359497e-01
    z[1,2,2]  R841      4.4822001457214355e-01
    z[1,2,2]  R842      3.6763572692871094e-01
    z[1,2,2]  R843      5.0276148319244385e-01
    z[1,2,2]  R844      4.0322843194007874e-01
    z[1,2,2]  R845      7.4868232011795044e-01
    z[1,2,2]  R846      3.0692771077156067e-01
    z[1,2,2]  R847      5.9499907493591309e-01
    z[1,2,2]  R848      2.4867615103721619e-01
    z[1,2,2]  R849      1.8500684201717377e-01
    z[1,2,2]  R850      2.3874540627002716e-01
    z[1,2,2]  R851      1.6469387337565422e-02
    z[1,2,2]  R852      -1.2445499747991562e-01
    z[1,2,2]  R853      -5.9227406978607178e-02
    z[1,2,2]  R854      -2.6088374853134155e-01
    z[1,2,2]  R855      -2.1865636110305786e-01
    z[1,2,2]  R856      -1.8037162721157074e-01
    z[1,2,2]  R857      -1.7247246205806732e-01
    z[1,2,2]  R858      -1.3899783790111542e-01
    z[1,2,2]  R859      -1.1080551892518997e-01
    z[1,2,2]  R860      3.9775538444519043e-01
    z[1,2,2]  R861      1.1231323704123497e-02
    z[1,2,2]  R862      6.5868055820465088e-01
    z[1,2,2]  R863      -3.1474792957305908e-01
    z[1,2,2]  R864      -1.2175311893224716e-01
    z[1,2,2]  R865      3.3148422837257385e-01
    z[1,2,2]  R866      5.1093317568302155e-02
    z[1,2,2]  R867      1.1504931002855301e-01
    z[1,2,2]  R868      2.0345918834209442e-01
    z[1,2,2]  R869      -3.6418372392654419e-01
    z[1,2,2]  R870      4.0174335241317749e-02
    z[1,2,2]  R871      3.8252830505371094e-01
    z[1,2,2]  R872      7.0580348372459412e-02
    z[1,2,2]  R873      4.1537332534790039e-01
    z[1,2,2]  R874      2.3485516011714935e-01
    z[1,2,2]  R875      2.5643357634544373e-01
    z[1,2,2]  R876      1.4694970101118088e-02
    z[1,2,2]  R877      5.9880863875150681e-02
    z[1,2,2]  R878      4.0238484740257263e-01
    z[1,2,2]  R879      2.3903700709342957e-01
    z[1,2,2]  R880      5.0364041328430176e-01
    z[1,2,2]  R881      0.0140965785831213
    z[1,2,2]  R882      2.2510248422622681e-01
    z[1,2,2]  R883      3.5488355159759521e-01
    z[1,2,2]  R884      4.5670631527900696e-01
    z[1,2,2]  R885      2.7176254987716675e-01
    z[1,2,2]  R886      -1.1318792402744293e-01
    z[1,2,2]  R887      0.557110071182251
    z[1,2,2]  R888      -2.2380405664443970e-01
    z[1,2,2]  R889      -3.2381752133369446e-01
    z[1,2,2]  R890      -5.3149497509002686e-01
    z[1,2,2]  R891      2.5458261370658875e-01
    z[1,2,2]  R892      4.8929756879806519e-01
    z[1,2,2]  R893      2.9072421789169312e-01
    z[1,2,2]  R894      3.0683067440986633e-01
    z[1,2,2]  R895      2.2289778292179108e-01
    z[1,2,2]  R896      3.3935952186584473e-01
    z[1,2,2]  R897      -1.2604791671037674e-02
    z[1,2,2]  R898      6.5620934963226318e-01
    z[1,2,2]  R899      1.1383425444364548e-01
    z[1,2,2]  R900      -3.6569130420684814e-01
    z[1,2,2]  R901      -5.3163391351699829e-01
    z[1,2,2]  R902      6.4521101303398609e-03
    z[1,2,2]  R903      2.0284524559974670e-01
    z[1,2,2]  R904      1.3467849232256413e-02
    z[1,2,2]  R905      -1.1188992857933044e-01
    z[1,2,2]  R906      -1.0982112586498260e-01
    z[1,2,2]  R907      -3.9222124218940735e-01
    z[1,2,2]  R908      -1.0817139595746994e-01
    z[1,2,2]  R909      -2.4090123176574707e-01
    z[1,2,2]  R910      -3.3334711194038391e-01
    z[1,2,2]  R911      -1.6649633646011353e-01
    z[1,2,3]  R14       -1
    z[1,2,3]  R23       1
    z[1,2,3]  R794      -1
    z[1,2,3]  R795      1
    z[1,2,3]  R802      3.0141115188598633e-01
    z[1,2,3]  R803      2.4837906658649445e-01
    z[1,2,3]  R804      4.5430219173431396e-01
    z[1,2,3]  R805      1.1281071603298187e-01
    z[1,2,3]  R806      -6.9318228960037231e-01
    z[1,2,3]  R807      7.7586674690246582e-01
    z[1,2,3]  R808      1.8007653951644897e-01
    z[1,2,3]  R809      1.1757089197635651e-01
    z[1,2,3]  R810      8.4759509563446045e-01
    z[1,2,3]  R811      -0.662113606929779
    z[1,2,3]  R812      -1.7191989719867706e-01
    z[1,2,3]  R813      1.4346306025981903e-01
    z[1,2,3]  R814      -1.5986124053597450e-03
    z[1,2,3]  R815      -7.7496804296970367e-02
    z[1,2,3]  R816      -3.5832509398460388e-01
    z[1,2,3]  R817      -4.2696484923362732e-01
    z[1,2,3]  R818      -4.8628427088260651e-02
    z[1,2,3]  R819      -4.4954848289489746e-01
    z[1,2,3]  R820      4.5265042781829834e-01
    z[1,2,3]  R821      -2.2668300569057465e-01
    z[1,2,3]  R822      3.5406373441219330e-02
    z[1,2,3]  R823      -5.3441369533538818e-01
    z[1,2,3]  R824      -6.8717229366302490e-01
    z[1,2,3]  R825      -2.2073395550251007e-01
    z[1,2,3]  R826      -3.3366686105728149e-01
    z[1,2,3]  R827      1.7880079150199890e-01
    z[1,2,3]  R828      -8.5172258317470551e-02
    z[1,2,3]  R829      -1.1860412359237671e-01
    z[1,2,3]  R830      -7.0354276895523071e-01
    z[1,2,3]  R831      6.8548142910003662e-01
    z[1,2,3]  R832      -1.5521142631769180e-02
    z[1,2,3]  R833      3.5324998199939728e-02
    z[1,2,3]  R834      -3.2179304957389832e-01
    z[1,2,3]  R835      -1.7192016541957855e-01
    z[1,2,3]  R836      -4.1844853758811951e-01
    z[1,2,3]  R837      -5.6576901674270630e-01
    z[1,2,3]  R838      -4.7636792063713074e-01
    z[1,2,3]  R839      7.9875022172927856e-01
    z[1,2,3]  R840      0.661388099193573
    z[1,2,3]  R841      5.9479230642318726e-01
    z[1,2,3]  R842      -4.3263632059097290e-01
    z[1,2,3]  R843      2.5042481720447540e-02
    z[1,2,3]  R844      -4.2622995376586914e-01
    z[1,2,3]  R845      -5.7466577738523483e-02
    z[1,2,3]  R846      -5.3164166212081909e-01
    z[1,2,3]  R847      3.1246626377105713e-01
    z[1,2,3]  R848      -5.5094385147094727e-01
    z[1,2,3]  R849      -0.40092933177948
    z[1,2,3]  R850      -6.2547224760055542e-01
    z[1,2,3]  R851      -7.6631426811218262e-01
    z[1,2,3]  R852      2.3308290541172028e-01
    z[1,2,3]  R853      2.9692972078919411e-02
    z[1,2,3]  R854      2.6940426230430603e-01
    z[1,2,3]  R855      1.7415495216846466e-01
    z[1,2,3]  R856      3.1819683313369751e-01
    z[1,2,3]  R857      5.3033941984176636e-01
    z[1,2,3]  R858      3.8401737809181213e-01
    z[1,2,3]  R859      -1.0256312042474747e-01
    z[1,2,3]  R860      -5.0864759832620621e-02
    z[1,2,3]  R861      -0.0514921173453331
    z[1,2,3]  R862      -9.6945770084857941e-02
    z[1,2,3]  R863      -3.2277530431747437e-01
    z[1,2,3]  R864      -4.6569815278053284e-01
    z[1,2,3]  R865      -0.0725424587726593
    z[1,2,3]  R866      -3.9748242497444153e-01
    z[1,2,3]  R867      -5.6378829479217529e-01
    z[1,2,3]  R868      -1.6360698640346527e-01
    z[1,2,3]  R869      0.019247991964221
    z[1,2,3]  R870      3.5277467966079712e-01
    z[1,2,3]  R871      -2.1244628727436066e-01
    z[1,2,3]  R872      2.7281701564788818e-01
    z[1,2,3]  R873      -5.0979810953140259e-01
    z[1,2,3]  R874      -1.8456967175006866e-01
    z[1,2,3]  R875      -5.4723761975765228e-02
    z[1,2,3]  R876      1.6110248863697052e-01
    z[1,2,3]  R877      7.1737951040267944e-01
    z[1,2,3]  R878      -1.8594120442867279e-01
    z[1,2,3]  R879      -3.9094543457031250e-01
    z[1,2,3]  R880      -7.6074379682540894e-01
    z[1,2,3]  R881      -2.7185940742492676e-01
    z[1,2,3]  R882      -0.0397600419819355
    z[1,2,3]  R883      2.2943362593650818e-01
    z[1,2,3]  R884      0.170019268989563
    z[1,2,3]  R885      -3.5385897755622864e-01
    z[1,2,3]  R886      -7.9710179567337036e-01
    z[1,2,3]  R887      -8.9688166975975037e-02
    z[1,2,3]  R888      2.5888478755950928e-01
    z[1,2,3]  R889      -3.3545407652854919e-01
    z[1,2,3]  R890      3.4856066107749939e-01
    z[1,2,3]  R891      -3.1090533733367920e-01
    z[1,2,3]  R892      -4.2504701018333435e-01
    z[1,2,3]  R893      2.8435248136520386e-01
    z[1,2,3]  R894      7.5182348489761353e-02
    z[1,2,3]  R895      -0.473027765750885
    z[1,2,3]  R896      1.7170520126819611e-01
    z[1,2,3]  R897      -4.4786918163299561e-01
    z[1,2,3]  R898      -3.2597610354423523e-01
    z[1,2,3]  R899      2.5695970654487610e-01
    z[1,2,3]  R900      2.4426120519638062e-01
    z[1,2,3]  R901      -1.5772333741188049e-01
    z[1,2,3]  R902      -5.2296411991119385e-01
    z[1,2,3]  R903      -2.4884739890694618e-02
    z[1,2,3]  R904      -2.5975972414016724e-02
    z[1,2,3]  R905      -0.484904021024704
    z[1,2,3]  R906      -1.0325936228036880e-01
    z[1,2,3]  R907      1.7387378215789795e-01
    z[1,2,3]  R908      4.1590014100074768e-01
    z[1,2,3]  R909      1.8978017568588257e-01
    z[1,2,3]  R910      5.8795613050460815e-01
    z[1,2,3]  R911      3.6701145768165588e-01
    z[1,2,4]  R15       -1
    z[1,2,4]  R24       1
    z[1,2,4]  R796      -1
    z[1,2,4]  R797      1
    z[1,2,4]  R802      -2.9206001758575439e-01
    z[1,2,4]  R803      -7.0369493961334229e-01
    z[1,2,4]  R804      -8.2094132900238037e-01
    z[1,2,4]  R805      -4.4653770327568054e-01
    z[1,2,4]  R806      4.6243643760681152e-01
    z[1,2,4]  R807      9.2762112617492676e-02
    z[1,2,4]  R808      -6.5023016929626465e-01
    z[1,2,4]  R809      -1.6071267426013947e-01
    z[1,2,4]  R810      -1.6083371639251709e-01
    z[1,2,4]  R811      -3.4067001193761826e-02
    z[1,2,4]  R812      -5.6334905326366425e-02
    z[1,2,4]  R813      3.6259177327156067e-01
    z[1,2,4]  R814      -1.3728362321853638e-01
    z[1,2,4]  R815      -1.4447632431983948e-01
    z[1,2,4]  R816      -3.4708479046821594e-01
    z[1,2,4]  R817      1.3537852466106415e-01
    z[1,2,4]  R818      0.483398973941803
    z[1,2,4]  R819      0.0651547759771347
    z[1,2,4]  R820      8.4052875638008118e-02
    z[1,2,4]  R821      -3.0271375179290771e-01
    z[1,2,4]  R822      1.9041784107685089e-01
    z[1,2,4]  R823      2.8257763385772705e-01
    z[1,2,4]  R824      -1.8381620943546295e-01
    z[1,2,4]  R825      0.564232587814331
    z[1,2,4]  R826      3.5421684384346008e-02
    z[1,2,4]  R827      1.3294674456119537e-01
    z[1,2,4]  R828      0.234371617436409
    z[1,2,4]  R829      0.568893551826477
    z[1,2,4]  R830      0.133975088596344
    z[1,2,4]  R831      1.1157119274139404e-01
    z[1,2,4]  R832      1.0607088357210159e-01
    z[1,2,4]  R833      3.3143392205238342e-01
    z[1,2,4]  R834      2.0969532430171967e-01
    z[1,2,4]  R835      5.9639763832092285e-01
    z[1,2,4]  R836      3.5192811489105225e-01
    z[1,2,4]  R837      2.6111885905265808e-01
    z[1,2,4]  R838      -1.3108791410923004e-01
    z[1,2,4]  R839      -6.9482550024986267e-02
    z[1,2,4]  R840      -0.196515291929245
    z[1,2,4]  R841      -1.0311304032802582e-01
    z[1,2,4]  R842      5.4722440242767334e-01
    z[1,2,4]  R843      1.4803525805473328e-01
    z[1,2,4]  R844      3.9918571710586548e-01
    z[1,2,4]  R845      1.5126839280128479e-01
    z[1,2,4]  R846      1.6763398051261902e-01
    z[1,2,4]  R847      0.407213419675827
    z[1,2,4]  R848      1.0990818589925766e-01
    z[1,2,4]  R849      4.3967992067337036e-01
    z[1,2,4]  R850      3.0011904239654541e-01
    z[1,2,4]  R851      2.4865177273750305e-01
    z[1,2,4]  R852      -4.3187049031257629e-01
    z[1,2,4]  R853      -2.8873729705810547e-01
    z[1,2,4]  R854      -2.5547134876251221e-01
    z[1,2,4]  R855      -4.5111125707626343e-01
    z[1,2,4]  R856      1.2408773601055145e-01
    z[1,2,4]  R857      -5.2206343412399292e-01
    z[1,2,4]  R858      -5.4761254787445068e-01
    z[1,2,4]  R859      -3.4461638331413269e-01
    z[1,2,4]  R860      -4.5211181044578552e-01
    z[1,2,4]  R861      -0.165044367313385
    z[1,2,4]  R862      1.5875680744647980e-01
    z[1,2,4]  R863      1.3715524971485138e-01
    z[1,2,4]  R864      -2.2346515953540802e-01
    z[1,2,4]  R865      -4.1759216785430908e-01
    z[1,2,4]  R866      -3.9751854538917542e-01
    z[1,2,4]  R867      1.7852714657783508e-01
    z[1,2,4]  R868      -1.8352989852428436e-01
    z[1,2,4]  R869      -0.0141184376552701
    z[1,2,4]  R870      4.5318210124969482e-01
    z[1,2,4]  R871      -1.0221090167760849e-01
    z[1,2,4]  R872      3.0856120586395264e-01
    z[1,2,4]  R873      1.4820776879787445e-01
    z[1,2,4]  R874      -3.0214396119117737e-01
    z[1,2,4]  R875      -2.6687222719192505e-01
    z[1,2,4]  R876      7.0675933361053467e-01
    z[1,2,4]  R877      1.2677582912147045e-02
    z[1,2,4]  R878      -4.4618183746933937e-03
    z[1,2,4]  R879      1.7956745624542236e-01
    z[1,2,4]  R880      2.4438561499118805e-01
    z[1,2,4]  R881      9.0185302495956421e-01
    z[1,2,4]  R882      2.7694925665855408e-01
    z[1,2,4]  R883      2.9913464188575745e-01
    z[1,2,4]  R884      0.59245765209198
    z[1,2,4]  R885      8.3373981714248657e-01
    z[1,2,4]  R886      3.6104089021682739e-01
    z[1,2,4]  R887      6.1061972379684448e-01
    z[1,2,4]  R888      -5.5673813819885254e-01
    z[1,2,4]  R889      -2.3355101048946381e-01
    z[1,2,4]  R890      -1.0546758770942688e-01
    z[1,2,4]  R891      -4.9160704016685486e-01
    z[1,2,4]  R892      1.6739736497402191e-01
    z[1,2,4]  R893      5.1879614591598511e-01
    z[1,2,4]  R894      4.8258817195892334e-01
    z[1,2,4]  R895      2.2869048640131950e-02
    z[1,2,4]  R896      -2.2212823852896690e-02
    z[1,2,4]  R897      3.4187096357345581e-01
    z[1,2,4]  R898      -2.4101753532886505e-01
    z[1,2,4]  R899      -3.0958282947540283e-01
    z[1,2,4]  R900      -4.0877389907836914e-01
    z[1,2,4]  R901      -1.7188343405723572e-01
    z[1,2,4]  R902      1.6331204771995544e-01
    z[1,2,4]  R903      -1.7008937895298004e-02
    z[1,2,4]  R904      -6.5068101882934570e-01
    z[1,2,4]  R905      5.6897652149200439e-01
    z[1,2,4]  R906      2.3531997203826904e-01
    z[1,2,4]  R907      -2.8548237681388855e-01
    z[1,2,4]  R908      -2.5689691305160522e-01
    z[1,2,4]  R909      -1.4262603223323822e-01
    z[1,2,4]  R910      -8.4751576185226440e-02
    z[1,2,4]  R911      -1.4050680398941040e-01
    z[1,2,5]  R16       -1
    z[1,2,5]  R25       1
    z[1,2,5]  R798      -1
    z[1,2,5]  R799      1
    z[1,2,5]  R802      -0.16961570084095
    z[1,2,5]  R803      -3.6109413951635361e-02
    z[1,2,5]  R804      -5.2790228277444839e-02
    z[1,2,5]  R805      -6.3004577159881592e-01
    z[1,2,5]  R806      -2.7320614457130432e-01
    z[1,2,5]  R807      -1.2381795793771744e-01
    z[1,2,5]  R808      -5.9111952781677246e-01
    z[1,2,5]  R809      7.3343284428119659e-02
    z[1,2,5]  R810      -1.9130037724971771e-01
    z[1,2,5]  R811      -1.9146957993507385e-01
    z[1,2,5]  R812      4.3890848755836487e-01
    z[1,2,5]  R813      7.4039161205291748e-01
    z[1,2,5]  R814      -1.0637371987104416e-01
    z[1,2,5]  R815      -1.7951239645481110e-01
    z[1,2,5]  R816      1.9836017489433289e-01
    z[1,2,5]  R817      -3.6952443420886993e-02
    z[1,2,5]  R818      -4.4627869129180908e-01
    z[1,2,5]  R819      -1.9919851422309875e-01
    z[1,2,5]  R820      -5.9514995664358139e-03
    z[1,2,5]  R821      4.3356409668922424e-01
    z[1,2,5]  R822      -5.4642057418823242e-01
    z[1,2,5]  R823      -1.7104054987430573e-01
    z[1,2,5]  R824      -2.1577434241771698e-01
    z[1,2,5]  R825      -9.4331823289394379e-02
    z[1,2,5]  R826      -2.9091143608093262e-01
    z[1,2,5]  R827      1.9863104820251465e-01
    z[1,2,5]  R828      -2.0626686513423920e-02
    z[1,2,5]  R829      -3.2981079816818237e-01
    z[1,2,5]  R830      -7.5890876352787018e-02
    z[1,2,5]  R831      -2.1043565869331360e-01
    z[1,2,5]  R832      0.0350484624505043
    z[1,2,5]  R833      -1.2076556682586670e-01
    z[1,2,5]  R834      -4.7361978888511658e-01
    z[1,2,5]  R835      -6.5594747662544250e-02
    z[1,2,5]  R836      2.2551345825195312e-01
    z[1,2,5]  R837      -1.9245958328247070e-01
    z[1,2,5]  R838      3.8899150490760803e-01
    z[1,2,5]  R839      9.7562968730926514e-02
    z[1,2,5]  R840      3.4499558806419373e-01
    z[1,2,5]  R841      -1.3019940257072449e-01
    z[1,2,5]  R842      0.0833800733089447
    z[1,2,5]  R843      -5.6501626968383789e-01
    z[1,2,5]  R844      -3.9174145460128784e-01
    z[1,2,5]  R845      -2.2922298312187195e-01
    z[1,2,5]  R846      -4.8700946569442749e-01
    z[1,2,5]  R847      2.9084333777427673e-01
    z[1,2,5]  R848      -6.4033287763595581e-01
    z[1,2,5]  R849      -6.5542846918106079e-01
    z[1,2,5]  R850      0.0578635148704052
    z[1,2,5]  R851      -5.1316618919372559e-01
    z[1,2,5]  R852      1.7781247198581696e-01
    z[1,2,5]  R853      2.4892254173755646e-01
    z[1,2,5]  R854      3.1144040822982788e-01
    z[1,2,5]  R855      2.7869430184364319e-01
    z[1,2,5]  R856      0.282055526971817
    z[1,2,5]  R857      -5.0505995750427246e-02
    z[1,2,5]  R858      -3.7204194813966751e-02
    z[1,2,5]  R859      -8.1756219267845154e-02
    z[1,2,5]  R860      0.0612642765045166
    z[1,2,5]  R861      9.9795535206794739e-02
    z[1,2,5]  R862      -2.7276474982500076e-02
    z[1,2,5]  R863      -4.8238925635814667e-02
    z[1,2,5]  R864      4.6981833875179291e-02
    z[1,2,5]  R865      2.1955677866935730e-01
    z[1,2,5]  R866      1.8834892660379410e-02
    z[1,2,5]  R867      2.6265913248062134e-01
    z[1,2,5]  R868      4.7365966439247131e-01
    z[1,2,5]  R869      -5.8403289318084717e-01
    z[1,2,5]  R870      -2.8355203568935394e-02
    z[1,2,5]  R871      3.8093358278274536e-01
    z[1,2,5]  R872      -1.9037359952926636e-01
    z[1,2,5]  R873      3.4328180551528931e-01
    z[1,2,5]  R874      -6.7727595567703247e-01
    z[1,2,5]  R875      0.176070898771286
    z[1,2,5]  R876      -5.2785944938659668e-01
    z[1,2,5]  R877      -5.5261558294296265e-01
    z[1,2,5]  R878      -2.1267484128475189e-01
    z[1,2,5]  R879      -5.8950096368789673e-01
    z[1,2,5]  R880      -7.9023383557796478e-02
    z[1,2,5]  R881      1.3754327595233917e-01
    z[1,2,5]  R882      -7.6670008897781372e-01
    z[1,2,5]  R883      -3.0801013112068176e-01
    z[1,2,5]  R884      4.9699175357818604e-01
    z[1,2,5]  R885      -2.6377269625663757e-01
    z[1,2,5]  R886      -3.1842306256294250e-01
    z[1,2,5]  R887      -1.4775237441062927e-01
    z[1,2,5]  R888      -4.6165534853935242e-01
    z[1,2,5]  R889      -5.6931990385055542e-01
    z[1,2,5]  R890      1.3387784361839294e-01
    z[1,2,5]  R891      -2.1085444092750549e-01
    z[1,2,5]  R892      -1.8902689218521118e-01
    z[1,2,5]  R893      1.8010181188583374e-01
    z[1,2,5]  R894      3.8541790843009949e-01
    z[1,2,5]  R895      -4.8934942483901978e-01
    z[1,2,5]  R896      -5.8389580249786377e-01
    z[1,2,5]  R897      -4.0831071138381958e-01
    z[1,2,5]  R898      -2.3585020005702972e-01
    z[1,2,5]  R899      -4.0940853953361511e-01
    z[1,2,5]  R900      -6.5990430116653442e-01
    z[1,2,5]  R901      -7.9477471113204956e-01
    z[1,2,5]  R902      -5.6973181664943695e-02
    z[1,2,5]  R903      8.4464959800243378e-02
    z[1,2,5]  R904      -4.8492497205734253e-01
    z[1,2,5]  R905      -5.4549610614776611e-01
    z[1,2,5]  R906      -5.8714795112609863e-01
    z[1,2,5]  R907      -0.671748161315918
    z[1,2,5]  R908      -2.1288812160491943e-02
    z[1,2,5]  R909      -2.4835960566997528e-01
    z[1,2,5]  R910      -1.7103852331638336e-01
    z[1,2,5]  R911      4.2648389935493469e-02
    z[1,2,6]  R17       -1
    z[1,2,6]  R26       1
    z[1,2,6]  R800      -1
    z[1,2,6]  R801      1
    z[1,2,6]  R802      -2.4655713140964508e-01
    z[1,2,6]  R803      -4.1694027185440063e-01
    z[1,2,6]  R804      -1.7547542229294777e-02
    z[1,2,6]  R805      -3.0434769392013550e-01
    z[1,2,6]  R806      -3.6931043863296509e-01
    z[1,2,6]  R807      -8.2689769566059113e-02
    z[1,2,6]  R808      2.4606725573539734e-01
    z[1,2,6]  R809      9.0966427326202393e-01
    z[1,2,6]  R810      -1.6713818907737732e-01
    z[1,2,6]  R811      -2.6994574069976807e-01
    z[1,2,6]  R812      1.7012619972229004e-01
    z[1,2,6]  R813      -7.5329937040805817e-02
    z[1,2,6]  R814      5.2180871367454529e-02
    z[1,2,6]  R815      -4.0868866443634033e-01
    z[1,2,6]  R816      3.8819864392280579e-01
    z[1,2,6]  R817      1.3943642377853394e-01
    z[1,2,6]  R818      3.8652750849723816e-01
    z[1,2,6]  R819      5.6078654527664185e-01
    z[1,2,6]  R820      2.5621561333537102e-02
    z[1,2,6]  R821      -5.8213543891906738e-01
    z[1,2,6]  R822      -2.3434561491012573e-01
    z[1,2,6]  R823      -2.3424968123435974e-01
    z[1,2,6]  R824      1.1174045503139496e-01
    z[1,2,6]  R825      2.7887317538261414e-01
    z[1,2,6]  R826      4.8269498348236084e-01
    z[1,2,6]  R827      -4.0791699290275574e-01
    z[1,2,6]  R828      3.9846265316009521e-01
    z[1,2,6]  R829      3.9806911349296570e-01
    z[1,2,6]  R830      4.9638313055038452e-01
    z[1,2,6]  R831      1.7675362527370453e-01
    z[1,2,6]  R832      6.2091845273971558e-01
    z[1,2,6]  R833      4.9711546301841736e-01
    z[1,2,6]  R834      7.2336748242378235e-02
    z[1,2,6]  R835      2.6968801021575928e-01
    z[1,2,6]  R836      -4.3976327776908875e-01
    z[1,2,6]  R837      6.4820420742034912e-01
    z[1,2,6]  R838      -2.0570772886276245e-01
    z[1,2,6]  R839      -1.6415183246135712e-01
    z[1,2,6]  R840      -0.0460810661315918
    z[1,2,6]  R841      9.5752745866775513e-02
    z[1,2,6]  R842      5.4780679941177368e-01
    z[1,2,6]  R843      2.0252996683120728e-01
    z[1,2,6]  R844      -4.2021661996841431e-01
    z[1,2,6]  R845      -0.333069384098053
    z[1,2,6]  R846      4.3221309781074524e-01
    z[1,2,6]  R847      4.3560647964477539e-01
    z[1,2,6]  R848      -0.0211162306368351
    z[1,2,6]  R849      -8.8334038853645325e-02
    z[1,2,6]  R850      -0.672598659992218
    z[1,2,6]  R851      -2.0423695445060730e-01
    z[1,2,6]  R852      2.0441854000091553e-01
    z[1,2,6]  R853      0.065752312541008
    z[1,2,6]  R854      -2.4065662920475006e-01
    z[1,2,6]  R855      -1.5588358044624329e-01
    z[1,2,6]  R856      -1.9604048132896423e-01
    z[1,2,6]  R857      1.7837767302989960e-01
    z[1,2,6]  R858      -0.228534996509552
    z[1,2,6]  R859      4.7620676457881927e-02
    z[1,2,6]  R860      2.4584442377090454e-02
    z[1,2,6]  R861      -1.9309307634830475e-01
    z[1,2,6]  R862      -2.4188582599163055e-01
    z[1,2,6]  R863      -1.4621366560459137e-01
    z[1,2,6]  R864      6.7733906209468842e-02
    z[1,2,6]  R865      -1.4885485172271729e-01
    z[1,2,6]  R866      -2.9821133613586426e-01
    z[1,2,6]  R867      -5.4383349418640137e-01
    z[1,2,6]  R868      1.6138026118278503e-01
    z[1,2,6]  R869      -1.0271550714969635e-01
    z[1,2,6]  R870      -4.0465155243873596e-01
    z[1,2,6]  R871      -4.9593195319175720e-01
    z[1,2,6]  R872      2.0486150681972504e-01
    z[1,2,6]  R873      4.4525536894798279e-01
    z[1,2,6]  R874      -2.9589691758155823e-01
    z[1,2,6]  R875      5.2946376800537109e-01
    z[1,2,6]  R876      1.6983704641461372e-02
    z[1,2,6]  R877      0.00609292509034276
    z[1,2,6]  R878      6.0368931293487549e-01
    z[1,2,6]  R879      3.6947453022003174e-01
    z[1,2,6]  R880      1.9826957583427429e-01
    z[1,2,6]  R881      5.8247018605470657e-02
    z[1,2,6]  R882      -1.3854290544986725e-01
    z[1,2,6]  R883      -5.9745550155639648e-01
    z[1,2,6]  R884      1.6257208585739136e-01
    z[1,2,6]  R885      -2.6792740449309349e-02
    z[1,2,6]  R886      2.3442240059375763e-01
    z[1,2,6]  R887      -2.8105893731117249e-01
    z[1,2,6]  R888      5.3105145692825317e-01
    z[1,2,6]  R889      5.6892484426498413e-01
    z[1,2,6]  R890      2.6140075176954269e-02
    z[1,2,6]  R891      2.6417341828346252e-01
    z[1,2,6]  R892      3.8478469848632812e-01
    z[1,2,6]  R893      -2.5064751505851746e-01
    z[1,2,6]  R894      2.0427854359149933e-01
    z[1,2,6]  R895      -3.9159689098596573e-02
    z[1,2,6]  R896      4.0434777736663818e-01
    z[1,2,6]  R897      -4.7182762622833252e-01
    z[1,2,6]  R898      -1.4492989517748356e-02
    z[1,2,6]  R899      -5.9795439243316650e-01
    z[1,2,6]  R900      3.2052555680274963e-01
    z[1,2,6]  R901      -1.2123268842697144e-01
    z[1,2,6]  R902      2.1846349537372589e-01
    z[1,2,6]  R903      -0.0975298061966896
    z[1,2,6]  R904      3.3296042680740356e-01
    z[1,2,6]  R905      1.1676558107137680e-01
    z[1,2,6]  R906      7.0225185155868530e-01
    z[1,2,6]  R907      4.6222487092018127e-01
    z[1,2,6]  R908      -9.1960892081260681e-02
    z[1,2,6]  R909      3.3916354179382324e-02
    z[1,2,6]  R910      2.0778512954711914e-01
    z[1,2,6]  R911      5.3824341297149658e-01
    z[2,1,0]  R11       1
    z[2,1,0]  R20       -1
    z[2,1,0]  R912      -1
    z[2,1,0]  R913      1
    z[2,1,0]  R926      5.1106750965118408e-02
    z[2,1,0]  R927      5.9056133031845093e-01
    z[2,1,0]  R928      3.8707137107849121e-01
    z[2,1,0]  R929      4.8208811879158020e-01
    z[2,1,0]  R930      3.9119637012481689e-01
    z[2,1,0]  R931      1.4780405163764954e-01
    z[2,1,0]  R932      3.7821340560913086e-01
    z[2,1,0]  R933      3.1116208434104919e-01
    z[2,1,0]  R934      -7.1673743426799774e-02
    z[2,1,0]  R935      1.2954111397266388e-01
    z[2,1,0]  R936      -8.0445349216461182e-01
    z[2,1,0]  R937      -9.1631394624710083e-01
    z[2,1,0]  R938      -7.8195226192474365e-01
    z[2,1,0]  R939      -7.6881724596023560e-01
    z[2,1,0]  R940      -8.5561519861221313e-01
    z[2,1,0]  R941      -6.1567348241806030e-01
    z[2,1,0]  R942      -6.8078100681304932e-01
    z[2,1,0]  R943      -8.9947152137756348e-01
    z[2,1,0]  R944      -5.7025265693664551e-01
    z[2,1,0]  R945      -9.3417984247207642e-01
    z[2,1,0]  R946      2.1477112174034119e-01
    z[2,1,0]  R947      -3.8141974806785583e-01
    z[2,1,0]  R948      -2.7105388045310974e-01
    z[2,1,0]  R949      -5.6051395833492279e-02
    z[2,1,0]  R950      -1.5068499743938446e-01
    z[2,1,0]  R951      -3.0338394641876221e-01
    z[2,1,0]  R952      -2.7596482634544373e-01
    z[2,1,0]  R953      2.4456791579723358e-01
    z[2,1,0]  R954      -1.6306860744953156e-01
    z[2,1,0]  R955      -1.7163069546222687e-01
    z[2,1,0]  R956      -1.7435763031244278e-02
    z[2,1,0]  R957      -7.4469387531280518e-02
    z[2,1,0]  R958      4.6104887127876282e-01
    z[2,1,0]  R959      -1.5043017454445362e-02
    z[2,1,0]  R960      1.4565181732177734e-01
    z[2,1,0]  R961      4.1971042752265930e-01
    z[2,1,0]  R962      2.8397732973098755e-01
    z[2,1,0]  R963      3.6843919754028320e-01
    z[2,1,0]  R964      2.2394387423992157e-01
    z[2,1,0]  R965      -2.4747861921787262e-01
    z[2,1,0]  R966      4.6400707960128784e-01
    z[2,1,0]  R967      3.8031637668609619e-01
    z[2,1,0]  R968      -1.2748220562934875e-01
    z[2,1,0]  R969      1.2794123589992523e-01
    z[2,1,0]  R970      -0.0471976064145565
    z[2,1,0]  R971      3.4939879179000854e-01
    z[2,1,0]  R972      2.6777082681655884e-01
    z[2,1,0]  R973      2.1898530423641205e-01
    z[2,1,0]  R974      -7.4936193227767944e-01
    z[2,1,0]  R975      4.3602046370506287e-01
    z[2,1,0]  R976      2.5317353010177612e-01
    z[2,1,0]  R977      -1.3065354526042938e-01
    z[2,1,0]  R978      -2.0609799027442932e-01
    z[2,1,0]  R979      4.5509546995162964e-01
    z[2,1,0]  R980      5.4032748937606812e-01
    z[2,1,0]  R981      -2.6457160711288452e-02
    z[2,1,0]  R982      5.5485457181930542e-01
    z[2,1,0]  R983      3.8495638966560364e-01
    z[2,1,0]  R984      2.2407768666744232e-01
    z[2,1,0]  R985      1.2110158801078796e-01
    z[2,1,0]  R986      -1.7774407565593719e-01
    z[2,1,0]  R987      -1.3188990950584412e-01
    z[2,1,0]  R988      4.3774825334548950e-01
    z[2,1,0]  R989      5.7331051677465439e-02
    z[2,1,0]  R990      2.8909498453140259e-01
    z[2,1,0]  R991      2.2211559116840363e-01
    z[2,1,0]  R992      -8.4896892309188843e-01
    z[2,1,0]  R993      -9.0700966119766235e-01
    z[2,1,0]  R994      -6.8083697557449341e-01
    z[2,1,0]  R995      -7.2370398044586182e-01
    z[2,1,0]  R996      7.4860262870788574e-01
    z[2,1,0]  R997      3.6833679676055908e-01
    z[2,1,0]  R998      -2.2596074640750885e-01
    z[2,1,0]  R999      -3.0306759476661682e-01
    z[2,1,0]  R1000     -1.4573006331920624e-01
    z[2,1,0]  R1001     -0.50286865234375
    z[2,1,0]  R1002     -8.5654549300670624e-02
    z[2,1,0]  R1003     1.5423680841922760e-01
    z[2,1,0]  R1004     -3.0090352892875671e-01
    z[2,1,0]  R1005     -3.6334908008575439e-01
    z[2,1,0]  R1006     -3.2288312911987305e-01
    z[2,1,0]  R1007     4.0381222963333130e-01
    z[2,1,0]  R1008     -8.3608108758926392e-01
    z[2,1,0]  R1009     -5.0338220596313477e-01
    z[2,1,0]  R1010     -6.4310878515243530e-01
    z[2,1,0]  R1011     6.7158448696136475e-01
    z[2,1,0]  R1012     -2.9885500669479370e-01
    z[2,1,0]  R1013     -6.3888782262802124e-01
    z[2,1,0]  R1014     3.1097555160522461e-01
    z[2,1,0]  R1015     -5.0072693824768066e-01
    z[2,1,0]  R1016     -1.9979985058307648e-01
    z[2,1,0]  R1017     -5.3643178939819336e-01
    z[2,1,0]  R1018     0.607283890247345
    z[2,1,0]  R1019     -7.1195596456527710e-01
    z[2,1,0]  R1020     -6.0410439968109131e-01
    z[2,1,0]  R1021     -8.3872246742248535e-01
    z[2,1,0]  R1022     -4.6909371018409729e-01
    z[2,1,0]  R1023     6.2660795450210571e-01
    z[2,1,0]  R1024     -3.5793432593345642e-01
    z[2,1,0]  R1025     4.1159999370574951e-01
    z[2,1,0]  R1026     7.6862829923629761e-01
    z[2,1,0]  R1027     7.8859555721282959e-01
    z[2,1,0]  R1028     0.763009250164032
    z[2,1,0]  R1029     -7.1807646751403809e-01
    z[2,1,0]  R1030     5.9774047136306763e-01
    z[2,1,0]  R1031     -1.5244425833225250e-01
    z[2,1,0]  R1032     7.3239183425903320e-01
    z[2,1,0]  R1033     2.9017889499664307e-01
    z[2,1,0]  R1034     2.7914133667945862e-01
    z[2,1,0]  R1035     -4.0742442011833191e-02
    z[2,1,1]  R12       1
    z[2,1,1]  R21       -1
    z[2,1,1]  R914      -1
    z[2,1,1]  R915      1
    z[2,1,1]  R926      2.6183715462684631e-01
    z[2,1,1]  R927      1.2515960633754730e-01
    z[2,1,1]  R928      1.2852229177951813e-01
    z[2,1,1]  R929      1.3192021846771240e-01
    z[2,1,1]  R930      1.3427737355232239e-01
    z[2,1,1]  R931      2.9381850361824036e-01
    z[2,1,1]  R932      2.6272362470626831e-01
    z[2,1,1]  R933      2.7838566899299622e-01
    z[2,1,1]  R934      0.0289725624024868
    z[2,1,1]  R935      1.6979511082172394e-01
    z[2,1,1]  R936      -1.5205812454223633e-01
    z[2,1,1]  R937      -7.9524502158164978e-02
    z[2,1,1]  R938      -1.6653977334499359e-01
    z[2,1,1]  R939      1.5908463299274445e-01
    z[2,1,1]  R940      2.7467915788292885e-02
    z[2,1,1]  R941      5.4951891303062439e-02
    z[2,1,1]  R942      -1.2749743461608887e-01
    z[2,1,1]  R943      2.0110078155994415e-01
    z[2,1,1]  R944      5.5249649286270142e-01
    z[2,1,1]  R945      2.2371090948581696e-01
    z[2,1,1]  R946      6.5280801057815552e-01
    z[2,1,1]  R947      7.8022551536560059e-01
    z[2,1,1]  R948      7.9881119728088379e-01
    z[2,1,1]  R949      7.9810267686843872e-01
    z[2,1,1]  R950      7.5457632541656494e-01
    z[2,1,1]  R951      4.2455622553825378e-01
    z[2,1,1]  R952      0.75604248046875
    z[2,1,1]  R953      -6.7479032278060913e-01
    z[2,1,1]  R954      6.9095867872238159e-01
    z[2,1,1]  R955      6.1447185277938843e-01
    z[2,1,1]  R956      8.6421352624893188e-01
    z[2,1,1]  R957      4.7324925661087036e-01
    z[2,1,1]  R958      2.4629727005958557e-01
    z[2,1,1]  R959      7.4058568477630615e-01
    z[2,1,1]  R960      4.1735228896141052e-01
    z[2,1,1]  R961      6.4956108108162880e-03
    z[2,1,1]  R962      5.5962300300598145e-01
    z[2,1,1]  R963      3.7149465084075928e-01
    z[2,1,1]  R964      1.1038370430469513e-01
    z[2,1,1]  R965      1.7028903961181641e-01
    z[2,1,1]  R966      2.2072924673557281e-01
    z[2,1,1]  R967      -3.6806592345237732e-01
    z[2,1,1]  R968      3.4903371334075928e-01
    z[2,1,1]  R969      1.3836197555065155e-01
    z[2,1,1]  R970      2.5078263878822327e-01
    z[2,1,1]  R971      -2.9295665025711060e-01
    z[2,1,1]  R972      7.8041791915893555e-02
    z[2,1,1]  R973      -1.7975407838821411e-01
    z[2,1,1]  R974      6.8886220455169678e-02
    z[2,1,1]  R975      -5.4082065820693970e-01
    z[2,1,1]  R976      5.5137449502944946e-01
    z[2,1,1]  R977      6.7315852642059326e-01
    z[2,1,1]  R978      0.659210205078125
    z[2,1,1]  R979      -5.2719074487686157e-01
    z[2,1,1]  R980      2.4181348085403442e-01
    z[2,1,1]  R981      5.4068428277969360e-01
    z[2,1,1]  R982      -2.0332334935665131e-01
    z[2,1,1]  R983      -3.8963535428047180e-01
    z[2,1,1]  R984      2.2602890431880951e-01
    z[2,1,1]  R985      4.3761026114225388e-02
    z[2,1,1]  R986      7.8564041852951050e-01
    z[2,1,1]  R987      9.6119928359985352e-01
    z[2,1,1]  R988      -1.9524261355400085e-01
    z[2,1,1]  R989      3.3782741427421570e-01
    z[2,1,1]  R990      2.0614726468920708e-02
    z[2,1,1]  R991      1.4211824536323547e-01
    z[2,1,1]  R992      1.4025595784187317e-01
    z[2,1,1]  R993      1.0417796671390533e-02
    z[2,1,1]  R994      6.0442048124969006e-03
    z[2,1,1]  R995      5.0666470080614090e-02
    z[2,1,1]  R996      3.9658987522125244e-01
    z[2,1,1]  R997      3.3228096365928650e-01
    z[2,1,1]  R998      2.4429461359977722e-01
    z[2,1,1]  R999      4.4257181882858276e-01
    z[2,1,1]  R1000     2.6678934693336487e-01
    z[2,1,1]  R1001     2.8248181939125061e-01
    z[2,1,1]  R1002     3.1439480185508728e-01
    z[2,1,1]  R1003     3.0521667003631592e-01
    z[2,1,1]  R1004     2.9148623347282410e-01
    z[2,1,1]  R1005     4.8344865441322327e-01
    z[2,1,1]  R1006     7.9831188917160034e-01
    z[2,1,1]  R1007     3.5552966594696045e-01
    z[2,1,1]  R1008     -5.0519472360610962e-01
    z[2,1,1]  R1009     -7.0010378956794739e-02
    z[2,1,1]  R1010     -3.7174528837203979e-01
    z[2,1,1]  R1011     -5.6620782613754272e-01
    z[2,1,1]  R1012     3.1890600919723511e-01
    z[2,1,1]  R1013     -9.6032015979290009e-02
    z[2,1,1]  R1014     -8.3104193210601807e-01
    z[2,1,1]  R1015     -2.6378947496414185e-01
    z[2,1,1]  R1016     7.5350910425186157e-01
    z[2,1,1]  R1017     1.5285126864910126e-01
    z[2,1,1]  R1018     2.2692620754241943e-02
    z[2,1,1]  R1019     -1.4521090686321259e-01
    z[2,1,1]  R1020     -9.3496374785900116e-02
    z[2,1,1]  R1021     -4.4312536716461182e-02
    z[2,1,1]  R1022     -9.4921454787254333e-02
    z[2,1,1]  R1023     -4.1695181280374527e-02
    z[2,1,1]  R1024     -2.3240816593170166e-01
    z[2,1,1]  R1025     -0.521371066570282
    z[2,1,1]  R1026     5.1249540410935879e-03
    z[2,1,1]  R1027     -5.0348155200481415e-02
    z[2,1,1]  R1028     -1.5467119216918945e-01
    z[2,1,1]  R1029     1.0522312484681606e-02
    z[2,1,1]  R1030     -3.1535571813583374e-01
    z[2,1,1]  R1031     2.9513699933886528e-02
    z[2,1,1]  R1032     -3.4852899610996246e-02
    z[2,1,1]  R1033     -4.8090791702270508e-01
    z[2,1,1]  R1034     -4.9988901615142822e-01
    z[2,1,1]  R1035     -6.3789361715316772e-01
    z[2,1,2]  R13       1
    z[2,1,2]  R22       -1
    z[2,1,2]  R916      -1
    z[2,1,2]  R917      1
    z[2,1,2]  R926      3.6763572692871094e-01
    z[2,1,2]  R927      5.0276148319244385e-01
    z[2,1,2]  R928      4.0322843194007874e-01
    z[2,1,2]  R929      7.4868232011795044e-01
    z[2,1,2]  R930      3.0692771077156067e-01
    z[2,1,2]  R931      5.9499907493591309e-01
    z[2,1,2]  R932      2.4867615103721619e-01
    z[2,1,2]  R933      1.8500684201717377e-01
    z[2,1,2]  R934      2.3874540627002716e-01
    z[2,1,2]  R935      1.6469387337565422e-02
    z[2,1,2]  R936      -1.2445499747991562e-01
    z[2,1,2]  R937      -5.9227406978607178e-02
    z[2,1,2]  R938      -2.6088374853134155e-01
    z[2,1,2]  R939      -2.1865636110305786e-01
    z[2,1,2]  R940      -1.8037162721157074e-01
    z[2,1,2]  R941      -1.7247246205806732e-01
    z[2,1,2]  R942      -1.3899783790111542e-01
    z[2,1,2]  R943      -1.1080551892518997e-01
    z[2,1,2]  R944      3.9775538444519043e-01
    z[2,1,2]  R945      1.1231323704123497e-02
    z[2,1,2]  R946      6.5868055820465088e-01
    z[2,1,2]  R947      -3.1474792957305908e-01
    z[2,1,2]  R948      -1.2175311893224716e-01
    z[2,1,2]  R949      3.3148422837257385e-01
    z[2,1,2]  R950      5.1093317568302155e-02
    z[2,1,2]  R951      1.1504931002855301e-01
    z[2,1,2]  R952      2.0345918834209442e-01
    z[2,1,2]  R953      -3.6418372392654419e-01
    z[2,1,2]  R954      4.0174335241317749e-02
    z[2,1,2]  R955      3.8252830505371094e-01
    z[2,1,2]  R956      7.0580348372459412e-02
    z[2,1,2]  R957      4.1537332534790039e-01
    z[2,1,2]  R958      2.3485516011714935e-01
    z[2,1,2]  R959      2.5643357634544373e-01
    z[2,1,2]  R960      1.4694970101118088e-02
    z[2,1,2]  R961      5.9880863875150681e-02
    z[2,1,2]  R962      4.0238484740257263e-01
    z[2,1,2]  R963      2.3903700709342957e-01
    z[2,1,2]  R964      5.0364041328430176e-01
    z[2,1,2]  R965      0.0140965785831213
    z[2,1,2]  R966      2.2510248422622681e-01
    z[2,1,2]  R967      3.5488355159759521e-01
    z[2,1,2]  R968      4.5670631527900696e-01
    z[2,1,2]  R969      2.7176254987716675e-01
    z[2,1,2]  R970      -1.1318792402744293e-01
    z[2,1,2]  R971      0.557110071182251
    z[2,1,2]  R972      -2.2380405664443970e-01
    z[2,1,2]  R973      -3.2381752133369446e-01
    z[2,1,2]  R974      -5.3149497509002686e-01
    z[2,1,2]  R975      2.5458261370658875e-01
    z[2,1,2]  R976      4.8929756879806519e-01
    z[2,1,2]  R977      2.9072421789169312e-01
    z[2,1,2]  R978      3.0683067440986633e-01
    z[2,1,2]  R979      2.2289778292179108e-01
    z[2,1,2]  R980      3.3935952186584473e-01
    z[2,1,2]  R981      -1.2604791671037674e-02
    z[2,1,2]  R982      6.5620934963226318e-01
    z[2,1,2]  R983      1.1383425444364548e-01
    z[2,1,2]  R984      -3.6569130420684814e-01
    z[2,1,2]  R985      -5.3163391351699829e-01
    z[2,1,2]  R986      6.4521101303398609e-03
    z[2,1,2]  R987      2.0284524559974670e-01
    z[2,1,2]  R988      1.3467849232256413e-02
    z[2,1,2]  R989      -1.1188992857933044e-01
    z[2,1,2]  R990      -1.0982112586498260e-01
    z[2,1,2]  R991      -3.9222124218940735e-01
    z[2,1,2]  R992      -1.0817139595746994e-01
    z[2,1,2]  R993      -2.4090123176574707e-01
    z[2,1,2]  R994      -3.3334711194038391e-01
    z[2,1,2]  R995      -1.6649633646011353e-01
    z[2,1,2]  R996      1.2885268032550812e-01
    z[2,1,2]  R997      1.4797152578830719e-01
    z[2,1,2]  R998      7.6367869973182678e-02
    z[2,1,2]  R999      1.0282432287931442e-01
    z[2,1,2]  R1000     4.6960480511188507e-02
    z[2,1,2]  R1001     -1.8596945703029633e-01
    z[2,1,2]  R1002     1.6917736828327179e-01
    z[2,1,2]  R1003     1.0263492166996002e-01
    z[2,1,2]  R1004     -1.2520714104175568e-01
    z[2,1,2]  R1005     0.291836678981781
    z[2,1,2]  R1006     0.0642719641327858
    z[2,1,2]  R1007     -6.8011187016963959e-02
    z[2,1,2]  R1008     -1.1339828372001648e-01
    z[2,1,2]  R1009     -7.1803522109985352e-01
    z[2,1,2]  R1010     -9.6472300589084625e-02
    z[2,1,2]  R1011     8.3359532058238983e-02
    z[2,1,2]  R1012     4.7368472814559937e-01
    z[2,1,2]  R1013     -1.4865960180759430e-01
    z[2,1,2]  R1014     -3.7821326404809952e-03
    z[2,1,2]  R1015     -9.9031753838062286e-02
    z[2,1,2]  R1016     3.6033112555742264e-02
    z[2,1,2]  R1017     4.8918455839157104e-01
    z[2,1,2]  R1018     2.5622749328613281e-01
    z[2,1,2]  R1019     1.3521020114421844e-01
    z[2,1,2]  R1020     4.4283643364906311e-01
    z[2,1,2]  R1021     -1.9770139455795288e-01
    z[2,1,2]  R1022     7.4132215976715088e-01
    z[2,1,2]  R1023     2.6134006679058075e-02
    z[2,1,2]  R1024     2.2976528108119965e-01
    z[2,1,2]  R1025     2.9996795579791069e-02
    z[2,1,2]  R1026     1.0451861470937729e-01
    z[2,1,2]  R1027     5.2703902125358582e-02
    z[2,1,2]  R1028     1.2970089912414551e-01
    z[2,1,2]  R1029     -1.4823801815509796e-01
    z[2,1,2]  R1030     7.5197708792984486e-03
    z[2,1,2]  R1031     3.6111307144165039e-01
    z[2,1,2]  R1032     1.5699344873428345e-01
    z[2,1,2]  R1033     7.2317175567150116e-02
    z[2,1,2]  R1034     2.7384883165359497e-01
    z[2,1,2]  R1035     4.4822001457214355e-01
    z[2,1,3]  R14       1
    z[2,1,3]  R23       -1
    z[2,1,3]  R918      -1
    z[2,1,3]  R919      1
    z[2,1,3]  R926      -4.3263632059097290e-01
    z[2,1,3]  R927      2.5042481720447540e-02
    z[2,1,3]  R928      -4.2622995376586914e-01
    z[2,1,3]  R929      -5.7466577738523483e-02
    z[2,1,3]  R930      -5.3164166212081909e-01
    z[2,1,3]  R931      3.1246626377105713e-01
    z[2,1,3]  R932      -5.5094385147094727e-01
    z[2,1,3]  R933      -0.40092933177948
    z[2,1,3]  R934      -6.2547224760055542e-01
    z[2,1,3]  R935      -7.6631426811218262e-01
    z[2,1,3]  R936      2.3308290541172028e-01
    z[2,1,3]  R937      2.9692972078919411e-02
    z[2,1,3]  R938      2.6940426230430603e-01
    z[2,1,3]  R939      1.7415495216846466e-01
    z[2,1,3]  R940      3.1819683313369751e-01
    z[2,1,3]  R941      5.3033941984176636e-01
    z[2,1,3]  R942      3.8401737809181213e-01
    z[2,1,3]  R943      -1.0256312042474747e-01
    z[2,1,3]  R944      -5.0864759832620621e-02
    z[2,1,3]  R945      -0.0514921173453331
    z[2,1,3]  R946      -9.6945770084857941e-02
    z[2,1,3]  R947      -3.2277530431747437e-01
    z[2,1,3]  R948      -4.6569815278053284e-01
    z[2,1,3]  R949      -0.0725424587726593
    z[2,1,3]  R950      -3.9748242497444153e-01
    z[2,1,3]  R951      -5.6378829479217529e-01
    z[2,1,3]  R952      -1.6360698640346527e-01
    z[2,1,3]  R953      0.019247991964221
    z[2,1,3]  R954      3.5277467966079712e-01
    z[2,1,3]  R955      -2.1244628727436066e-01
    z[2,1,3]  R956      2.7281701564788818e-01
    z[2,1,3]  R957      -5.0979810953140259e-01
    z[2,1,3]  R958      -1.8456967175006866e-01
    z[2,1,3]  R959      -5.4723761975765228e-02
    z[2,1,3]  R960      1.6110248863697052e-01
    z[2,1,3]  R961      7.1737951040267944e-01
    z[2,1,3]  R962      -1.8594120442867279e-01
    z[2,1,3]  R963      -3.9094543457031250e-01
    z[2,1,3]  R964      -7.6074379682540894e-01
    z[2,1,3]  R965      -2.7185940742492676e-01
    z[2,1,3]  R966      -0.0397600419819355
    z[2,1,3]  R967      2.2943362593650818e-01
    z[2,1,3]  R968      0.170019268989563
    z[2,1,3]  R969      -3.5385897755622864e-01
    z[2,1,3]  R970      -7.9710179567337036e-01
    z[2,1,3]  R971      -8.9688166975975037e-02
    z[2,1,3]  R972      2.5888478755950928e-01
    z[2,1,3]  R973      -3.3545407652854919e-01
    z[2,1,3]  R974      3.4856066107749939e-01
    z[2,1,3]  R975      -3.1090533733367920e-01
    z[2,1,3]  R976      -4.2504701018333435e-01
    z[2,1,3]  R977      2.8435248136520386e-01
    z[2,1,3]  R978      7.5182348489761353e-02
    z[2,1,3]  R979      -0.473027765750885
    z[2,1,3]  R980      1.7170520126819611e-01
    z[2,1,3]  R981      -4.4786918163299561e-01
    z[2,1,3]  R982      -3.2597610354423523e-01
    z[2,1,3]  R983      2.5695970654487610e-01
    z[2,1,3]  R984      2.4426120519638062e-01
    z[2,1,3]  R985      -1.5772333741188049e-01
    z[2,1,3]  R986      -5.2296411991119385e-01
    z[2,1,3]  R987      -2.4884739890694618e-02
    z[2,1,3]  R988      -2.5975972414016724e-02
    z[2,1,3]  R989      -0.484904021024704
    z[2,1,3]  R990      -1.0325936228036880e-01
    z[2,1,3]  R991      1.7387378215789795e-01
    z[2,1,3]  R992      4.1590014100074768e-01
    z[2,1,3]  R993      1.8978017568588257e-01
    z[2,1,3]  R994      5.8795613050460815e-01
    z[2,1,3]  R995      3.6701145768165588e-01
    z[2,1,3]  R996      3.0141115188598633e-01
    z[2,1,3]  R997      2.4837906658649445e-01
    z[2,1,3]  R998      4.5430219173431396e-01
    z[2,1,3]  R999      1.1281071603298187e-01
    z[2,1,3]  R1000     -6.9318228960037231e-01
    z[2,1,3]  R1001     7.7586674690246582e-01
    z[2,1,3]  R1002     1.8007653951644897e-01
    z[2,1,3]  R1003     1.1757089197635651e-01
    z[2,1,3]  R1004     8.4759509563446045e-01
    z[2,1,3]  R1005     -0.662113606929779
    z[2,1,3]  R1006     -1.7191989719867706e-01
    z[2,1,3]  R1007     1.4346306025981903e-01
    z[2,1,3]  R1008     -1.5986124053597450e-03
    z[2,1,3]  R1009     -7.7496804296970367e-02
    z[2,1,3]  R1010     -3.5832509398460388e-01
    z[2,1,3]  R1011     -4.2696484923362732e-01
    z[2,1,3]  R1012     -4.8628427088260651e-02
    z[2,1,3]  R1013     -4.4954848289489746e-01
    z[2,1,3]  R1014     4.5265042781829834e-01
    z[2,1,3]  R1015     -2.2668300569057465e-01
    z[2,1,3]  R1016     3.5406373441219330e-02
    z[2,1,3]  R1017     -5.3441369533538818e-01
    z[2,1,3]  R1018     -6.8717229366302490e-01
    z[2,1,3]  R1019     -2.2073395550251007e-01
    z[2,1,3]  R1020     -3.3366686105728149e-01
    z[2,1,3]  R1021     1.7880079150199890e-01
    z[2,1,3]  R1022     -8.5172258317470551e-02
    z[2,1,3]  R1023     -1.1860412359237671e-01
    z[2,1,3]  R1024     -7.0354276895523071e-01
    z[2,1,3]  R1025     6.8548142910003662e-01
    z[2,1,3]  R1026     -1.5521142631769180e-02
    z[2,1,3]  R1027     3.5324998199939728e-02
    z[2,1,3]  R1028     -3.2179304957389832e-01
    z[2,1,3]  R1029     -1.7192016541957855e-01
    z[2,1,3]  R1030     -4.1844853758811951e-01
    z[2,1,3]  R1031     -5.6576901674270630e-01
    z[2,1,3]  R1032     -4.7636792063713074e-01
    z[2,1,3]  R1033     7.9875022172927856e-01
    z[2,1,3]  R1034     0.661388099193573
    z[2,1,3]  R1035     5.9479230642318726e-01
    z[2,1,4]  R15       1
    z[2,1,4]  R24       -1
    z[2,1,4]  R920      -1
    z[2,1,4]  R921      1
    z[2,1,4]  R926      5.4722440242767334e-01
    z[2,1,4]  R927      1.4803525805473328e-01
    z[2,1,4]  R928      3.9918571710586548e-01
    z[2,1,4]  R929      1.5126839280128479e-01
    z[2,1,4]  R930      1.6763398051261902e-01
    z[2,1,4]  R931      0.407213419675827
    z[2,1,4]  R932      1.0990818589925766e-01
    z[2,1,4]  R933      4.3967992067337036e-01
    z[2,1,4]  R934      3.0011904239654541e-01
    z[2,1,4]  R935      2.4865177273750305e-01
    z[2,1,4]  R936      -4.3187049031257629e-01
    z[2,1,4]  R937      -2.8873729705810547e-01
    z[2,1,4]  R938      -2.5547134876251221e-01
    z[2,1,4]  R939      -4.5111125707626343e-01
    z[2,1,4]  R940      1.2408773601055145e-01
    z[2,1,4]  R941      -5.2206343412399292e-01
    z[2,1,4]  R942      -5.4761254787445068e-01
    z[2,1,4]  R943      -3.4461638331413269e-01
    z[2,1,4]  R944      -4.5211181044578552e-01
    z[2,1,4]  R945      -0.165044367313385
    z[2,1,4]  R946      1.5875680744647980e-01
    z[2,1,4]  R947      1.3715524971485138e-01
    z[2,1,4]  R948      -2.2346515953540802e-01
    z[2,1,4]  R949      -4.1759216785430908e-01
    z[2,1,4]  R950      -3.9751854538917542e-01
    z[2,1,4]  R951      1.7852714657783508e-01
    z[2,1,4]  R952      -1.8352989852428436e-01
    z[2,1,4]  R953      -0.0141184376552701
    z[2,1,4]  R954      4.5318210124969482e-01
    z[2,1,4]  R955      -1.0221090167760849e-01
    z[2,1,4]  R956      3.0856120586395264e-01
    z[2,1,4]  R957      1.4820776879787445e-01
    z[2,1,4]  R958      -3.0214396119117737e-01
    z[2,1,4]  R959      -2.6687222719192505e-01
    z[2,1,4]  R960      7.0675933361053467e-01
    z[2,1,4]  R961      1.2677582912147045e-02
    z[2,1,4]  R962      -4.4618183746933937e-03
    z[2,1,4]  R963      1.7956745624542236e-01
    z[2,1,4]  R964      2.4438561499118805e-01
    z[2,1,4]  R965      9.0185302495956421e-01
    z[2,1,4]  R966      2.7694925665855408e-01
    z[2,1,4]  R967      2.9913464188575745e-01
    z[2,1,4]  R968      0.59245765209198
    z[2,1,4]  R969      8.3373981714248657e-01
    z[2,1,4]  R970      3.6104089021682739e-01
    z[2,1,4]  R971      6.1061972379684448e-01
    z[2,1,4]  R972      -5.5673813819885254e-01
    z[2,1,4]  R973      -2.3355101048946381e-01
    z[2,1,4]  R974      -1.0546758770942688e-01
    z[2,1,4]  R975      -4.9160704016685486e-01
    z[2,1,4]  R976      1.6739736497402191e-01
    z[2,1,4]  R977      5.1879614591598511e-01
    z[2,1,4]  R978      4.8258817195892334e-01
    z[2,1,4]  R979      2.2869048640131950e-02
    z[2,1,4]  R980      -2.2212823852896690e-02
    z[2,1,4]  R981      3.4187096357345581e-01
    z[2,1,4]  R982      -2.4101753532886505e-01
    z[2,1,4]  R983      -3.0958282947540283e-01
    z[2,1,4]  R984      -4.0877389907836914e-01
    z[2,1,4]  R985      -1.7188343405723572e-01
    z[2,1,4]  R986      1.6331204771995544e-01
    z[2,1,4]  R987      -1.7008937895298004e-02
    z[2,1,4]  R988      -6.5068101882934570e-01
    z[2,1,4]  R989      5.6897652149200439e-01
    z[2,1,4]  R990      2.3531997203826904e-01
    z[2,1,4]  R991      -2.8548237681388855e-01
    z[2,1,4]  R992      -2.5689691305160522e-01
    z[2,1,4]  R993      -1.4262603223323822e-01
    z[2,1,4]  R994      -8.4751576185226440e-02
    z[2,1,4]  R995      -1.4050680398941040e-01
    z[2,1,4]  R996      -2.9206001758575439e-01
    z[2,1,4]  R997      -7.0369493961334229e-01
    z[2,1,4]  R998      -8.2094132900238037e-01
    z[2,1,4]  R999      -4.4653770327568054e-01
    z[2,1,4]  R1000     4.6243643760681152e-01
    z[2,1,4]  R1001     9.2762112617492676e-02
    z[2,1,4]  R1002     -6.5023016929626465e-01
    z[2,1,4]  R1003     -1.6071267426013947e-01
    z[2,1,4]  R1004     -1.6083371639251709e-01
    z[2,1,4]  R1005     -3.4067001193761826e-02
    z[2,1,4]  R1006     -5.6334905326366425e-02
    z[2,1,4]  R1007     3.6259177327156067e-01
    z[2,1,4]  R1008     -1.3728362321853638e-01
    z[2,1,4]  R1009     -1.4447632431983948e-01
    z[2,1,4]  R1010     -3.4708479046821594e-01
    z[2,1,4]  R1011     1.3537852466106415e-01
    z[2,1,4]  R1012     0.483398973941803
    z[2,1,4]  R1013     0.0651547759771347
    z[2,1,4]  R1014     8.4052875638008118e-02
    z[2,1,4]  R1015     -3.0271375179290771e-01
    z[2,1,4]  R1016     1.9041784107685089e-01
    z[2,1,4]  R1017     2.8257763385772705e-01
    z[2,1,4]  R1018     -1.8381620943546295e-01
    z[2,1,4]  R1019     0.564232587814331
    z[2,1,4]  R1020     3.5421684384346008e-02
    z[2,1,4]  R1021     1.3294674456119537e-01
    z[2,1,4]  R1022     0.234371617436409
    z[2,1,4]  R1023     0.568893551826477
    z[2,1,4]  R1024     0.133975088596344
    z[2,1,4]  R1025     1.1157119274139404e-01
    z[2,1,4]  R1026     1.0607088357210159e-01
    z[2,1,4]  R1027     3.3143392205238342e-01
    z[2,1,4]  R1028     2.0969532430171967e-01
    z[2,1,4]  R1029     5.9639763832092285e-01
    z[2,1,4]  R1030     3.5192811489105225e-01
    z[2,1,4]  R1031     2.6111885905265808e-01
    z[2,1,4]  R1032     -1.3108791410923004e-01
    z[2,1,4]  R1033     -6.9482550024986267e-02
    z[2,1,4]  R1034     -0.196515291929245
    z[2,1,4]  R1035     -1.0311304032802582e-01
    z[2,1,5]  R16       1
    z[2,1,5]  R25       -1
    z[2,1,5]  R922      -1
    z[2,1,5]  R923      1
    z[2,1,5]  R926      0.0833800733089447
    z[2,1,5]  R927      -5.6501626968383789e-01
    z[2,1,5]  R928      -3.9174145460128784e-01
    z[2,1,5]  R929      -2.2922298312187195e-01
    z[2,1,5]  R930      -4.8700946569442749e-01
    z[2,1,5]  R931      2.9084333777427673e-01
    z[2,1,5]  R932      -6.4033287763595581e-01
    z[2,1,5]  R933      -6.5542846918106079e-01
    z[2,1,5]  R934      0.0578635148704052
    z[2,1,5]  R935      -5.1316618919372559e-01
    z[2,1,5]  R936      1.7781247198581696e-01
    z[2,1,5]  R937      2.4892254173755646e-01
    z[2,1,5]  R938      3.1144040822982788e-01
    z[2,1,5]  R939      2.7869430184364319e-01
    z[2,1,5]  R940      0.282055526971817
    z[2,1,5]  R941      -5.0505995750427246e-02
    z[2,1,5]  R942      -3.7204194813966751e-02
    z[2,1,5]  R943      -8.1756219267845154e-02
    z[2,1,5]  R944      0.0612642765045166
    z[2,1,5]  R945      9.9795535206794739e-02
    z[2,1,5]  R946      -2.7276474982500076e-02
    z[2,1,5]  R947      -4.8238925635814667e-02
    z[2,1,5]  R948      4.6981833875179291e-02
    z[2,1,5]  R949      2.1955677866935730e-01
    z[2,1,5]  R950      1.8834892660379410e-02
    z[2,1,5]  R951      2.6265913248062134e-01
    z[2,1,5]  R952      4.7365966439247131e-01
    z[2,1,5]  R953      -5.8403289318084717e-01
    z[2,1,5]  R954      -2.8355203568935394e-02
    z[2,1,5]  R955      3.8093358278274536e-01
    z[2,1,5]  R956      -1.9037359952926636e-01
    z[2,1,5]  R957      3.4328180551528931e-01
    z[2,1,5]  R958      -6.7727595567703247e-01
    z[2,1,5]  R959      0.176070898771286
    z[2,1,5]  R960      -5.2785944938659668e-01
    z[2,1,5]  R961      -5.5261558294296265e-01
    z[2,1,5]  R962      -2.1267484128475189e-01
    z[2,1,5]  R963      -5.8950096368789673e-01
    z[2,1,5]  R964      -7.9023383557796478e-02
    z[2,1,5]  R965      1.3754327595233917e-01
    z[2,1,5]  R966      -7.6670008897781372e-01
    z[2,1,5]  R967      -3.0801013112068176e-01
    z[2,1,5]  R968      4.9699175357818604e-01
    z[2,1,5]  R969      -2.6377269625663757e-01
    z[2,1,5]  R970      -3.1842306256294250e-01
    z[2,1,5]  R971      -1.4775237441062927e-01
    z[2,1,5]  R972      -4.6165534853935242e-01
    z[2,1,5]  R973      -5.6931990385055542e-01
    z[2,1,5]  R974      1.3387784361839294e-01
    z[2,1,5]  R975      -2.1085444092750549e-01
    z[2,1,5]  R976      -1.8902689218521118e-01
    z[2,1,5]  R977      1.8010181188583374e-01
    z[2,1,5]  R978      3.8541790843009949e-01
    z[2,1,5]  R979      -4.8934942483901978e-01
    z[2,1,5]  R980      -5.8389580249786377e-01
    z[2,1,5]  R981      -4.0831071138381958e-01
    z[2,1,5]  R982      -2.3585020005702972e-01
    z[2,1,5]  R983      -4.0940853953361511e-01
    z[2,1,5]  R984      -6.5990430116653442e-01
    z[2,1,5]  R985      -7.9477471113204956e-01
    z[2,1,5]  R986      -5.6973181664943695e-02
    z[2,1,5]  R987      8.4464959800243378e-02
    z[2,1,5]  R988      -4.8492497205734253e-01
    z[2,1,5]  R989      -5.4549610614776611e-01
    z[2,1,5]  R990      -5.8714795112609863e-01
    z[2,1,5]  R991      -0.671748161315918
    z[2,1,5]  R992      -2.1288812160491943e-02
    z[2,1,5]  R993      -2.4835960566997528e-01
    z[2,1,5]  R994      -1.7103852331638336e-01
    z[2,1,5]  R995      4.2648389935493469e-02
    z[2,1,5]  R996      -0.16961570084095
    z[2,1,5]  R997      -3.6109413951635361e-02
    z[2,1,5]  R998      -5.2790228277444839e-02
    z[2,1,5]  R999      -6.3004577159881592e-01
    z[2,1,5]  R1000     -2.7320614457130432e-01
    z[2,1,5]  R1001     -1.2381795793771744e-01
    z[2,1,5]  R1002     -5.9111952781677246e-01
    z[2,1,5]  R1003     7.3343284428119659e-02
    z[2,1,5]  R1004     -1.9130037724971771e-01
    z[2,1,5]  R1005     -1.9146957993507385e-01
    z[2,1,5]  R1006     4.3890848755836487e-01
    z[2,1,5]  R1007     7.4039161205291748e-01
    z[2,1,5]  R1008     -1.0637371987104416e-01
    z[2,1,5]  R1009     -1.7951239645481110e-01
    z[2,1,5]  R1010     1.9836017489433289e-01
    z[2,1,5]  R1011     -3.6952443420886993e-02
    z[2,1,5]  R1012     -4.4627869129180908e-01
    z[2,1,5]  R1013     -1.9919851422309875e-01
    z[2,1,5]  R1014     -5.9514995664358139e-03
    z[2,1,5]  R1015     4.3356409668922424e-01
    z[2,1,5]  R1016     -5.4642057418823242e-01
    z[2,1,5]  R1017     -1.7104054987430573e-01
    z[2,1,5]  R1018     -2.1577434241771698e-01
    z[2,1,5]  R1019     -9.4331823289394379e-02
    z[2,1,5]  R1020     -2.9091143608093262e-01
    z[2,1,5]  R1021     1.9863104820251465e-01
    z[2,1,5]  R1022     -2.0626686513423920e-02
    z[2,1,5]  R1023     -3.2981079816818237e-01
    z[2,1,5]  R1024     -7.5890876352787018e-02
    z[2,1,5]  R1025     -2.1043565869331360e-01
    z[2,1,5]  R1026     0.0350484624505043
    z[2,1,5]  R1027     -1.2076556682586670e-01
    z[2,1,5]  R1028     -4.7361978888511658e-01
    z[2,1,5]  R1029     -6.5594747662544250e-02
    z[2,1,5]  R1030     2.2551345825195312e-01
    z[2,1,5]  R1031     -1.9245958328247070e-01
    z[2,1,5]  R1032     3.8899150490760803e-01
    z[2,1,5]  R1033     9.7562968730926514e-02
    z[2,1,5]  R1034     3.4499558806419373e-01
    z[2,1,5]  R1035     -1.3019940257072449e-01
    z[2,1,6]  R17       1
    z[2,1,6]  R26       -1
    z[2,1,6]  R924      -1
    z[2,1,6]  R925      1
    z[2,1,6]  R926      5.4780679941177368e-01
    z[2,1,6]  R927      2.0252996683120728e-01
    z[2,1,6]  R928      -4.2021661996841431e-01
    z[2,1,6]  R929      -0.333069384098053
    z[2,1,6]  R930      4.3221309781074524e-01
    z[2,1,6]  R931      4.3560647964477539e-01
    z[2,1,6]  R932      -0.0211162306368351
    z[2,1,6]  R933      -8.8334038853645325e-02
    z[2,1,6]  R934      -0.672598659992218
    z[2,1,6]  R935      -2.0423695445060730e-01
    z[2,1,6]  R936      2.0441854000091553e-01
    z[2,1,6]  R937      0.065752312541008
    z[2,1,6]  R938      -2.4065662920475006e-01
    z[2,1,6]  R939      -1.5588358044624329e-01
    z[2,1,6]  R940      -1.9604048132896423e-01
    z[2,1,6]  R941      1.7837767302989960e-01
    z[2,1,6]  R942      -0.228534996509552
    z[2,1,6]  R943      4.7620676457881927e-02
    z[2,1,6]  R944      2.4584442377090454e-02
    z[2,1,6]  R945      -1.9309307634830475e-01
    z[2,1,6]  R946      -2.4188582599163055e-01
    z[2,1,6]  R947      -1.4621366560459137e-01
    z[2,1,6]  R948      6.7733906209468842e-02
    z[2,1,6]  R949      -1.4885485172271729e-01
    z[2,1,6]  R950      -2.9821133613586426e-01
    z[2,1,6]  R951      -5.4383349418640137e-01
    z[2,1,6]  R952      1.6138026118278503e-01
    z[2,1,6]  R953      -1.0271550714969635e-01
    z[2,1,6]  R954      -4.0465155243873596e-01
    z[2,1,6]  R955      -4.9593195319175720e-01
    z[2,1,6]  R956      2.0486150681972504e-01
    z[2,1,6]  R957      4.4525536894798279e-01
    z[2,1,6]  R958      -2.9589691758155823e-01
    z[2,1,6]  R959      5.2946376800537109e-01
    z[2,1,6]  R960      1.6983704641461372e-02
    z[2,1,6]  R961      0.00609292509034276
    z[2,1,6]  R962      6.0368931293487549e-01
    z[2,1,6]  R963      3.6947453022003174e-01
    z[2,1,6]  R964      1.9826957583427429e-01
    z[2,1,6]  R965      5.8247018605470657e-02
    z[2,1,6]  R966      -1.3854290544986725e-01
    z[2,1,6]  R967      -5.9745550155639648e-01
    z[2,1,6]  R968      1.6257208585739136e-01
    z[2,1,6]  R969      -2.6792740449309349e-02
    z[2,1,6]  R970      2.3442240059375763e-01
    z[2,1,6]  R971      -2.8105893731117249e-01
    z[2,1,6]  R972      5.3105145692825317e-01
    z[2,1,6]  R973      5.6892484426498413e-01
    z[2,1,6]  R974      2.6140075176954269e-02
    z[2,1,6]  R975      2.6417341828346252e-01
    z[2,1,6]  R976      3.8478469848632812e-01
    z[2,1,6]  R977      -2.5064751505851746e-01
    z[2,1,6]  R978      2.0427854359149933e-01
    z[2,1,6]  R979      -3.9159689098596573e-02
    z[2,1,6]  R980      4.0434777736663818e-01
    z[2,1,6]  R981      -4.7182762622833252e-01
    z[2,1,6]  R982      -1.4492989517748356e-02
    z[2,1,6]  R983      -5.9795439243316650e-01
    z[2,1,6]  R984      3.2052555680274963e-01
    z[2,1,6]  R985      -1.2123268842697144e-01
    z[2,1,6]  R986      2.1846349537372589e-01
    z[2,1,6]  R987      -0.0975298061966896
    z[2,1,6]  R988      3.3296042680740356e-01
    z[2,1,6]  R989      1.1676558107137680e-01
    z[2,1,6]  R990      7.0225185155868530e-01
    z[2,1,6]  R991      4.6222487092018127e-01
    z[2,1,6]  R992      -9.1960892081260681e-02
    z[2,1,6]  R993      3.3916354179382324e-02
    z[2,1,6]  R994      2.0778512954711914e-01
    z[2,1,6]  R995      5.3824341297149658e-01
    z[2,1,6]  R996      -2.4655713140964508e-01
    z[2,1,6]  R997      -4.1694027185440063e-01
    z[2,1,6]  R998      -1.7547542229294777e-02
    z[2,1,6]  R999      -3.0434769392013550e-01
    z[2,1,6]  R1000     -3.6931043863296509e-01
    z[2,1,6]  R1001     -8.2689769566059113e-02
    z[2,1,6]  R1002     2.4606725573539734e-01
    z[2,1,6]  R1003     9.0966427326202393e-01
    z[2,1,6]  R1004     -1.6713818907737732e-01
    z[2,1,6]  R1005     -2.6994574069976807e-01
    z[2,1,6]  R1006     1.7012619972229004e-01
    z[2,1,6]  R1007     -7.5329937040805817e-02
    z[2,1,6]  R1008     5.2180871367454529e-02
    z[2,1,6]  R1009     -4.0868866443634033e-01
    z[2,1,6]  R1010     3.8819864392280579e-01
    z[2,1,6]  R1011     1.3943642377853394e-01
    z[2,1,6]  R1012     3.8652750849723816e-01
    z[2,1,6]  R1013     5.6078654527664185e-01
    z[2,1,6]  R1014     2.5621561333537102e-02
    z[2,1,6]  R1015     -5.8213543891906738e-01
    z[2,1,6]  R1016     -2.3434561491012573e-01
    z[2,1,6]  R1017     -2.3424968123435974e-01
    z[2,1,6]  R1018     1.1174045503139496e-01
    z[2,1,6]  R1019     2.7887317538261414e-01
    z[2,1,6]  R1020     4.8269498348236084e-01
    z[2,1,6]  R1021     -4.0791699290275574e-01
    z[2,1,6]  R1022     3.9846265316009521e-01
    z[2,1,6]  R1023     3.9806911349296570e-01
    z[2,1,6]  R1024     4.9638313055038452e-01
    z[2,1,6]  R1025     1.7675362527370453e-01
    z[2,1,6]  R1026     6.2091845273971558e-01
    z[2,1,6]  R1027     4.9711546301841736e-01
    z[2,1,6]  R1028     7.2336748242378235e-02
    z[2,1,6]  R1029     2.6968801021575928e-01
    z[2,1,6]  R1030     -4.3976327776908875e-01
    z[2,1,6]  R1031     6.4820420742034912e-01
    z[2,1,6]  R1032     -2.0570772886276245e-01
    z[2,1,6]  R1033     -1.6415183246135712e-01
    z[2,1,6]  R1034     -0.0460810661315918
    z[2,1,6]  R1035     9.5752745866775513e-02
    z[1,4,0]  R11       -1
    z[1,4,0]  R38       1
    z[1,4,0]  R1036     -1
    z[1,4,0]  R1037     1
    z[1,4,0]  R1050     7.4860262870788574e-01
    z[1,4,0]  R1051     3.6833679676055908e-01
    z[1,4,0]  R1052     -2.2596074640750885e-01
    z[1,4,0]  R1053     -3.0306759476661682e-01
    z[1,4,0]  R1054     -1.4573006331920624e-01
    z[1,4,0]  R1055     -0.50286865234375
    z[1,4,0]  R1056     -8.5654549300670624e-02
    z[1,4,0]  R1057     1.5423680841922760e-01
    z[1,4,0]  R1058     -3.0090352892875671e-01
    z[1,4,0]  R1059     -3.6334908008575439e-01
    z[1,4,0]  R1060     -3.2288312911987305e-01
    z[1,4,0]  R1061     4.0381222963333130e-01
    z[1,4,0]  R1062     -8.3608108758926392e-01
    z[1,4,0]  R1063     -5.0338220596313477e-01
    z[1,4,0]  R1064     -6.4310878515243530e-01
    z[1,4,0]  R1065     6.7158448696136475e-01
    z[1,4,0]  R1066     -2.9885500669479370e-01
    z[1,4,0]  R1067     -6.3888782262802124e-01
    z[1,4,0]  R1068     3.1097555160522461e-01
    z[1,4,0]  R1069     -5.0072693824768066e-01
    z[1,4,0]  R1070     -1.9979985058307648e-01
    z[1,4,0]  R1071     -5.3643178939819336e-01
    z[1,4,0]  R1072     0.607283890247345
    z[1,4,0]  R1073     -7.1195596456527710e-01
    z[1,4,0]  R1074     -6.0410439968109131e-01
    z[1,4,0]  R1075     -8.3872246742248535e-01
    z[1,4,0]  R1076     -4.6909371018409729e-01
    z[1,4,0]  R1077     6.2660795450210571e-01
    z[1,4,0]  R1078     -3.5793432593345642e-01
    z[1,4,0]  R1079     4.1159999370574951e-01
    z[1,4,0]  R1080     7.6862829923629761e-01
    z[1,4,0]  R1081     7.8859555721282959e-01
    z[1,4,0]  R1082     0.763009250164032
    z[1,4,0]  R1083     -7.1807646751403809e-01
    z[1,4,0]  R1084     5.9774047136306763e-01
    z[1,4,0]  R1085     -1.5244425833225250e-01
    z[1,4,0]  R1086     7.3239183425903320e-01
    z[1,4,0]  R1087     2.9017889499664307e-01
    z[1,4,0]  R1088     2.7914133667945862e-01
    z[1,4,0]  R1089     -4.0742442011833191e-02
    z[1,4,0]  R1090     7.7755272388458252e-01
    z[1,4,0]  R1091     6.3734090328216553e-01
    z[1,4,0]  R1092     5.8479756116867065e-01
    z[1,4,0]  R1093     6.0710543394088745e-01
    z[1,4,0]  R1094     3.8329303264617920e-01
    z[1,4,0]  R1095     2.1687658131122589e-01
    z[1,4,0]  R1096     2.1503403782844543e-02
    z[1,4,0]  R1097     3.1548026204109192e-01
    z[1,4,0]  R1098     0.434079110622406
    z[1,4,0]  R1099     0.626015841960907
    z[1,4,0]  R1100     5.6098586320877075e-01
    z[1,4,0]  R1101     3.3980640769004822e-01
    z[1,4,0]  R1102     2.1491794288158417e-01
    z[1,4,0]  R1103     -6.8108814954757690e-01
    z[1,4,0]  R1104     -3.8750776648521423e-01
    z[1,4,0]  R1105     -4.7351148724555969e-01
    z[1,4,0]  R1106     -5.8315277099609375e-01
    z[1,4,0]  R1107     -6.1338418722152710e-01
    z[1,4,0]  R1108     -8.8346785306930542e-01
    z[1,4,0]  R1109     -8.1260401010513306e-01
    z[1,4,0]  R1110     2.0011156797409058e-01
    z[1,4,0]  R1111     -3.7151196599006653e-01
    z[1,4,0]  R1112     -0.533784031867981
    z[1,4,0]  R1113     -7.4237263202667236e-01
    z[1,4,0]  R1114     -2.9535919427871704e-01
    z[1,4,0]  R1115     -2.5586044788360596e-01
    z[1,4,0]  R1116     -3.4152883291244507e-01
    z[1,4,0]  R1117     -4.1218620538711548e-01
    z[1,4,0]  R1118     -3.6068147420883179e-01
    z[1,4,0]  R1119     -1.7500633001327515e-01
    z[1,4,0]  R1120     4.9794915318489075e-01
    z[1,4,0]  R1121     1.9511704146862030e-01
    z[1,4,0]  R1122     3.2752478122711182e-01
    z[1,4,0]  R1123     -5.1430463790893555e-02
    z[1,4,0]  R1124     -5.2251976728439331e-01
    z[1,4,0]  R1125     -6.1259114742279053e-01
    z[1,4,0]  R1126     -3.8758561015129089e-01
    z[1,4,0]  R1127     -8.7527495622634888e-01
    z[1,4,0]  R1128     -6.8857854604721069e-01
    z[1,4,0]  R1129     -6.6475450992584229e-01
    z[1,4,1]  R12       -1
    z[1,4,1]  R39       1
    z[1,4,1]  R1038     -1
    z[1,4,1]  R1039     1
    z[1,4,1]  R1050     3.9658987522125244e-01
    z[1,4,1]  R1051     3.3228096365928650e-01
    z[1,4,1]  R1052     2.4429461359977722e-01
    z[1,4,1]  R1053     4.4257181882858276e-01
    z[1,4,1]  R1054     2.6678934693336487e-01
    z[1,4,1]  R1055     2.8248181939125061e-01
    z[1,4,1]  R1056     3.1439480185508728e-01
    z[1,4,1]  R1057     3.0521667003631592e-01
    z[1,4,1]  R1058     2.9148623347282410e-01
    z[1,4,1]  R1059     4.8344865441322327e-01
    z[1,4,1]  R1060     7.9831188917160034e-01
    z[1,4,1]  R1061     3.5552966594696045e-01
    z[1,4,1]  R1062     -5.0519472360610962e-01
    z[1,4,1]  R1063     -7.0010378956794739e-02
    z[1,4,1]  R1064     -3.7174528837203979e-01
    z[1,4,1]  R1065     -5.6620782613754272e-01
    z[1,4,1]  R1066     3.1890600919723511e-01
    z[1,4,1]  R1067     -9.6032015979290009e-02
    z[1,4,1]  R1068     -8.3104193210601807e-01
    z[1,4,1]  R1069     -2.6378947496414185e-01
    z[1,4,1]  R1070     7.5350910425186157e-01
    z[1,4,1]  R1071     1.5285126864910126e-01
    z[1,4,1]  R1072     2.2692620754241943e-02
    z[1,4,1]  R1073     -1.4521090686321259e-01
    z[1,4,1]  R1074     -9.3496374785900116e-02
    z[1,4,1]  R1075     -4.4312536716461182e-02
    z[1,4,1]  R1076     -9.4921454787254333e-02
    z[1,4,1]  R1077     -4.1695181280374527e-02
    z[1,4,1]  R1078     -2.3240816593170166e-01
    z[1,4,1]  R1079     -0.521371066570282
    z[1,4,1]  R1080     5.1249540410935879e-03
    z[1,4,1]  R1081     -5.0348155200481415e-02
    z[1,4,1]  R1082     -1.5467119216918945e-01
    z[1,4,1]  R1083     1.0522312484681606e-02
    z[1,4,1]  R1084     -3.1535571813583374e-01
    z[1,4,1]  R1085     2.9513699933886528e-02
    z[1,4,1]  R1086     -3.4852899610996246e-02
    z[1,4,1]  R1087     -4.8090791702270508e-01
    z[1,4,1]  R1088     -4.9988901615142822e-01
    z[1,4,1]  R1089     -6.3789361715316772e-01
    z[1,4,1]  R1090     -3.9053717255592346e-01
    z[1,4,1]  R1091     -2.3057553172111511e-01
    z[1,4,1]  R1092     -3.9834627509117126e-01
    z[1,4,1]  R1093     -3.2214903831481934e-01
    z[1,4,1]  R1094     -3.1685826182365417e-01
    z[1,4,1]  R1095     0.18353371322155
    z[1,4,1]  R1096     1.6331650316715240e-01
    z[1,4,1]  R1097     -2.2192259784787893e-03
    z[1,4,1]  R1098     -1.6745314002037048e-02
    z[1,4,1]  R1099     1.4434356987476349e-01
    z[1,4,1]  R1100     4.1506272554397583e-01
    z[1,4,1]  R1101     4.3609973788261414e-01
    z[1,4,1]  R1102     6.3473701477050781e-01
    z[1,4,1]  R1103     3.7802930921316147e-02
    z[1,4,1]  R1104     3.8586241006851196e-01
    z[1,4,1]  R1105     8.1718474626541138e-02
    z[1,4,1]  R1106     7.6087392866611481e-02
    z[1,4,1]  R1107     6.9843932986259460e-02
    z[1,4,1]  R1108     1.9197058677673340e-01
    z[1,4,1]  R1109     -1.7714096605777740e-01
    z[1,4,1]  R1110     -8.3324313163757324e-02
    z[1,4,1]  R1111     2.2697913646697998e-01
    z[1,4,1]  R1112     7.6907515525817871e-02
    z[1,4,1]  R1113     9.3378983438014984e-02
    z[1,4,1]  R1114     -2.8235715627670288e-01
    z[1,4,1]  R1115     6.9965416193008423e-01
    z[1,4,1]  R1116     6.3529521226882935e-01
    z[1,4,1]  R1117     6.1751806735992432e-01
    z[1,4,1]  R1118     5.3761011362075806e-01
    z[1,4,1]  R1119     4.2723336815834045e-01
    z[1,4,1]  R1120     -9.8839856684207916e-02
    z[1,4,1]  R1121     -2.4453786015510559e-01
    z[1,4,1]  R1122     6.5430924296379089e-02
    z[1,4,1]  R1123     4.4217151403427124e-01
    z[1,4,1]  R1124     2.1262690424919128e-01
    z[1,4,1]  R1125     -4.7013565897941589e-01
    z[1,4,1]  R1126     -5.2967935800552368e-01
    z[1,4,1]  R1127     -0.095587819814682
    z[1,4,1]  R1128     -3.5056486725807190e-01
    z[1,4,1]  R1129     -0.279590904712677
    z[1,4,2]  R13       -1
    z[1,4,2]  R40       1
    z[1,4,2]  R1040     -1
    z[1,4,2]  R1041     1
    z[1,4,2]  R1050     1.2885268032550812e-01
    z[1,4,2]  R1051     1.4797152578830719e-01
    z[1,4,2]  R1052     7.6367869973182678e-02
    z[1,4,2]  R1053     1.0282432287931442e-01
    z[1,4,2]  R1054     4.6960480511188507e-02
    z[1,4,2]  R1055     -1.8596945703029633e-01
    z[1,4,2]  R1056     1.6917736828327179e-01
    z[1,4,2]  R1057     1.0263492166996002e-01
    z[1,4,2]  R1058     -1.2520714104175568e-01
    z[1,4,2]  R1059     0.291836678981781
    z[1,4,2]  R1060     0.0642719641327858
    z[1,4,2]  R1061     -6.8011187016963959e-02
    z[1,4,2]  R1062     -1.1339828372001648e-01
    z[1,4,2]  R1063     -7.1803522109985352e-01
    z[1,4,2]  R1064     -9.6472300589084625e-02
    z[1,4,2]  R1065     8.3359532058238983e-02
    z[1,4,2]  R1066     4.7368472814559937e-01
    z[1,4,2]  R1067     -1.4865960180759430e-01
    z[1,4,2]  R1068     -3.7821326404809952e-03
    z[1,4,2]  R1069     -9.9031753838062286e-02
    z[1,4,2]  R1070     3.6033112555742264e-02
    z[1,4,2]  R1071     4.8918455839157104e-01
    z[1,4,2]  R1072     2.5622749328613281e-01
    z[1,4,2]  R1073     1.3521020114421844e-01
    z[1,4,2]  R1074     4.4283643364906311e-01
    z[1,4,2]  R1075     -1.9770139455795288e-01
    z[1,4,2]  R1076     7.4132215976715088e-01
    z[1,4,2]  R1077     2.6134006679058075e-02
    z[1,4,2]  R1078     2.2976528108119965e-01
    z[1,4,2]  R1079     2.9996795579791069e-02
    z[1,4,2]  R1080     1.0451861470937729e-01
    z[1,4,2]  R1081     5.2703902125358582e-02
    z[1,4,2]  R1082     1.2970089912414551e-01
    z[1,4,2]  R1083     -1.4823801815509796e-01
    z[1,4,2]  R1084     7.5197708792984486e-03
    z[1,4,2]  R1085     3.6111307144165039e-01
    z[1,4,2]  R1086     1.5699344873428345e-01
    z[1,4,2]  R1087     7.2317175567150116e-02
    z[1,4,2]  R1088     2.7384883165359497e-01
    z[1,4,2]  R1089     4.4822001457214355e-01
    z[1,4,2]  R1090     9.6842184662818909e-02
    z[1,4,2]  R1091     -0.262206107378006
    z[1,4,2]  R1092     9.9797770380973816e-02
    z[1,4,2]  R1093     -4.1073697805404663e-01
    z[1,4,2]  R1094     -7.5050640106201172e-01
    z[1,4,2]  R1095     -7.6529151201248169e-01
    z[1,4,2]  R1096     -7.0444834232330322e-01
    z[1,4,2]  R1097     -6.2899458408355713e-01
    z[1,4,2]  R1098     -5.4802465438842773e-01
    z[1,4,2]  R1099     -3.5592085123062134e-01
    z[1,4,2]  R1100     -1.5294665098190308e-01
    z[1,4,2]  R1101     4.0598326921463013e-01
    z[1,4,2]  R1102     6.5435290336608887e-02
    z[1,4,2]  R1103     -4.0175712108612061e-01
    z[1,4,2]  R1104     -5.4046612977981567e-01
    z[1,4,2]  R1105     -7.4267548322677612e-01
    z[1,4,2]  R1106     -5.4421937465667725e-01
    z[1,4,2]  R1107     -3.9016574621200562e-01
    z[1,4,2]  R1108     -1.6744016110897064e-01
    z[1,4,2]  R1109     -4.2687937617301941e-01
    z[1,4,2]  R1110     -5.4102480411529541e-01
    z[1,4,2]  R1111     -0.502291738986969
    z[1,4,2]  R1112     -4.4189968705177307e-01
    z[1,4,2]  R1113     -4.9744647741317749e-01
    z[1,4,2]  R1114     -8.1178158521652222e-01
    z[1,4,2]  R1115     2.6623749732971191e-01
    z[1,4,2]  R1116     3.9537829160690308e-01
    z[1,4,2]  R1117     6.1859405832365155e-04
    z[1,4,2]  R1118     1.4093835838139057e-02
    z[1,4,2]  R1119     3.3906945586204529e-01
    z[1,4,2]  R1120     -3.6892163753509521e-01
    z[1,4,2]  R1121     -5.6913815438747406e-02
    z[1,4,2]  R1122     -2.8455594182014465e-01
    z[1,4,2]  R1123     9.5352604985237122e-02
    z[1,4,2]  R1124     -7.0583587884902954e-01
    z[1,4,2]  R1125     -1.8528589606285095e-01
    z[1,4,2]  R1126     -5.0818198919296265e-01
    z[1,4,2]  R1127     1.8494956195354462e-01
    z[1,4,2]  R1128     -8.1987380981445312e-02
    z[1,4,2]  R1129     5.7027824223041534e-02
    z[1,4,3]  R14       -1
    z[1,4,3]  R41       1
    z[1,4,3]  R1042     -1
    z[1,4,3]  R1043     1
    z[1,4,3]  R1050     3.0141115188598633e-01
    z[1,4,3]  R1051     2.4837906658649445e-01
    z[1,4,3]  R1052     4.5430219173431396e-01
    z[1,4,3]  R1053     1.1281071603298187e-01
    z[1,4,3]  R1054     -6.9318228960037231e-01
    z[1,4,3]  R1055     7.7586674690246582e-01
    z[1,4,3]  R1056     1.8007653951644897e-01
    z[1,4,3]  R1057     1.1757089197635651e-01
    z[1,4,3]  R1058     8.4759509563446045e-01
    z[1,4,3]  R1059     -0.662113606929779
    z[1,4,3]  R1060     -1.7191989719867706e-01
    z[1,4,3]  R1061     1.4346306025981903e-01
    z[1,4,3]  R1062     -1.5986124053597450e-03
    z[1,4,3]  R1063     -7.7496804296970367e-02
    z[1,4,3]  R1064     -3.5832509398460388e-01
    z[1,4,3]  R1065     -4.2696484923362732e-01
    z[1,4,3]  R1066     -4.8628427088260651e-02
    z[1,4,3]  R1067     -4.4954848289489746e-01
    z[1,4,3]  R1068     4.5265042781829834e-01
    z[1,4,3]  R1069     -2.2668300569057465e-01
    z[1,4,3]  R1070     3.5406373441219330e-02
    z[1,4,3]  R1071     -5.3441369533538818e-01
    z[1,4,3]  R1072     -6.8717229366302490e-01
    z[1,4,3]  R1073     -2.2073395550251007e-01
    z[1,4,3]  R1074     -3.3366686105728149e-01
    z[1,4,3]  R1075     1.7880079150199890e-01
    z[1,4,3]  R1076     -8.5172258317470551e-02
    z[1,4,3]  R1077     -1.1860412359237671e-01
    z[1,4,3]  R1078     -7.0354276895523071e-01
    z[1,4,3]  R1079     6.8548142910003662e-01
    z[1,4,3]  R1080     -1.5521142631769180e-02
    z[1,4,3]  R1081     3.5324998199939728e-02
    z[1,4,3]  R1082     -3.2179304957389832e-01
    z[1,4,3]  R1083     -1.7192016541957855e-01
    z[1,4,3]  R1084     -4.1844853758811951e-01
    z[1,4,3]  R1085     -5.6576901674270630e-01
    z[1,4,3]  R1086     -4.7636792063713074e-01
    z[1,4,3]  R1087     7.9875022172927856e-01
    z[1,4,3]  R1088     0.661388099193573
    z[1,4,3]  R1089     5.9479230642318726e-01
    z[1,4,3]  R1090     -0.414764404296875
    z[1,4,3]  R1091     -2.5034227967262268e-01
    z[1,4,3]  R1092     -3.9581304788589478e-01
    z[1,4,3]  R1093     -3.9183524250984192e-01
    z[1,4,3]  R1094     -2.0016261935234070e-01
    z[1,4,3]  R1095     -1.9974724948406219e-01
    z[1,4,3]  R1096     1.7060551047325134e-01
    z[1,4,3]  R1097     1.6670159995555878e-01
    z[1,4,3]  R1098     1.4519914984703064e-01
    z[1,4,3]  R1099     4.4855013489723206e-01
    z[1,4,3]  R1100     3.5233241319656372e-01
    z[1,4,3]  R1101     3.2735961675643921e-01
    z[1,4,3]  R1102     0.160980224609375
    z[1,4,3]  R1103     4.2600056529045105e-01
    z[1,4,3]  R1104     4.6237173676490784e-01
    z[1,4,3]  R1105     3.0387637019157410e-01
    z[1,4,3]  R1106     2.2216325998306274e-01
    z[1,4,3]  R1107     5.8633047342300415e-01
    z[1,4,3]  R1108     3.7895858287811279e-01
    z[1,4,3]  R1109     3.3695170283317566e-01
    z[1,4,3]  R1110     4.5463311672210693e-01
    z[1,4,3]  R1111     4.7110924124717712e-01
    z[1,4,3]  R1112     3.7987053394317627e-01
    z[1,4,3]  R1113     2.6640614867210388e-01
    z[1,4,3]  R1114     1.8347172439098358e-01
    z[1,4,3]  R1115     -3.3782243728637695e-01
    z[1,4,3]  R1116     -5.2226340770721436e-01
    z[1,4,3]  R1117     -0.650968074798584
    z[1,4,3]  R1118     -6.5431934595108032e-01
    z[1,4,3]  R1119     -7.9564833641052246e-01
    z[1,4,3]  R1120     1.7952050268650055e-01
    z[1,4,3]  R1121     1.1064269393682480e-01
    z[1,4,3]  R1122     4.6490901708602905e-01
    z[1,4,3]  R1123     5.7867074012756348e-01
    z[1,4,3]  R1124     3.6209985613822937e-01
    z[1,4,3]  R1125     -2.6049536466598511e-01
    z[1,4,3]  R1126     -3.7754493951797485e-01
    z[1,4,3]  R1127     -3.9802354574203491e-01
    z[1,4,3]  R1128     -5.6722772121429443e-01
    z[1,4,3]  R1129     -5.1404041051864624e-01
    z[1,4,4]  R15       -1
    z[1,4,4]  R42       1
    z[1,4,4]  R1044     -1
    z[1,4,4]  R1045     1
    z[1,4,4]  R1050     -2.9206001758575439e-01
    z[1,4,4]  R1051     -7.0369493961334229e-01
    z[1,4,4]  R1052     -8.2094132900238037e-01
    z[1,4,4]  R1053     -4.4653770327568054e-01
    z[1,4,4]  R1054     4.6243643760681152e-01
    z[1,4,4]  R1055     9.2762112617492676e-02
    z[1,4,4]  R1056     -6.5023016929626465e-01
    z[1,4,4]  R1057     -1.6071267426013947e-01
    z[1,4,4]  R1058     -1.6083371639251709e-01
    z[1,4,4]  R1059     -3.4067001193761826e-02
    z[1,4,4]  R1060     -5.6334905326366425e-02
    z[1,4,4]  R1061     3.6259177327156067e-01
    z[1,4,4]  R1062     -1.3728362321853638e-01
    z[1,4,4]  R1063     -1.4447632431983948e-01
    z[1,4,4]  R1064     -3.4708479046821594e-01
    z[1,4,4]  R1065     1.3537852466106415e-01
    z[1,4,4]  R1066     0.483398973941803
    z[1,4,4]  R1067     0.0651547759771347
    z[1,4,4]  R1068     8.4052875638008118e-02
    z[1,4,4]  R1069     -3.0271375179290771e-01
    z[1,4,4]  R1070     1.9041784107685089e-01
    z[1,4,4]  R1071     2.8257763385772705e-01
    z[1,4,4]  R1072     -1.8381620943546295e-01
    z[1,4,4]  R1073     0.564232587814331
    z[1,4,4]  R1074     3.5421684384346008e-02
    z[1,4,4]  R1075     1.3294674456119537e-01
    z[1,4,4]  R1076     0.234371617436409
    z[1,4,4]  R1077     0.568893551826477
    z[1,4,4]  R1078     0.133975088596344
    z[1,4,4]  R1079     1.1157119274139404e-01
    z[1,4,4]  R1080     1.0607088357210159e-01
    z[1,4,4]  R1081     3.3143392205238342e-01
    z[1,4,4]  R1082     2.0969532430171967e-01
    z[1,4,4]  R1083     5.9639763832092285e-01
    z[1,4,4]  R1084     3.5192811489105225e-01
    z[1,4,4]  R1085     2.6111885905265808e-01
    z[1,4,4]  R1086     -1.3108791410923004e-01
    z[1,4,4]  R1087     -6.9482550024986267e-02
    z[1,4,4]  R1088     -0.196515291929245
    z[1,4,4]  R1089     -1.0311304032802582e-01
    z[1,4,4]  R1090     -7.0972524583339691e-02
    z[1,4,4]  R1091     -6.0671043395996094e-01
    z[1,4,4]  R1092     -3.4394067525863647e-01
    z[1,4,4]  R1093     -6.2061451375484467e-02
    z[1,4,4]  R1094     -1.9149589538574219e-01
    z[1,4,4]  R1095     1.1042827740311623e-02
    z[1,4,4]  R1096     -3.8129106163978577e-01
    z[1,4,4]  R1097     -0.532794713973999
    z[1,4,4]  R1098     -5.5903512239456177e-01
    z[1,4,4]  R1099     -4.4526490569114685e-01
    z[1,4,4]  R1100     -2.2568744421005249e-01
    z[1,4,4]  R1101     -7.9875849187374115e-02
    z[1,4,4]  R1102     5.6935474276542664e-02
    z[1,4,4]  R1103     -1.4888532459735870e-01
    z[1,4,4]  R1104     4.9446769990026951e-03
    z[1,4,4]  R1105     -1.5995962917804718e-01
    z[1,4,4]  R1106     1.6281167045235634e-02
    z[1,4,4]  R1107     -2.4922268092632294e-01
    z[1,4,4]  R1108     -6.6522851586341858e-02
    z[1,4,4]  R1109     8.7339393794536591e-02
    z[1,4,4]  R1110     1.0043712705373764e-01
    z[1,4,4]  R1111     2.3559153079986572e-01
    z[1,4,4]  R1112     2.6856338977813721e-01
    z[1,4,4]  R1113     1.4533202350139618e-01
    z[1,4,4]  R1114     1.9444513320922852e-01
    z[1,4,4]  R1115     1.0865075886249542e-01
    z[1,4,4]  R1116     6.4610771369189024e-04
    z[1,4,4]  R1117     -7.4865229427814484e-02
    z[1,4,4]  R1118     -3.4858337603509426e-03
    z[1,4,4]  R1119     9.5011197030544281e-02
    z[1,4,4]  R1120     1.8711134791374207e-01
    z[1,4,4]  R1121     -0.078458271920681
    z[1,4,4]  R1122     -2.7974864840507507e-01
    z[1,4,4]  R1123     3.2017588615417480e-01
    z[1,4,4]  R1124     1.6883562505245209e-01
    z[1,4,4]  R1125     -4.8497796058654785e-01
    z[1,4,4]  R1126     -0.257993221282959
    z[1,4,4]  R1127     -2.0148554816842079e-02
    z[1,4,4]  R1128     1.1473413556814194e-02
    z[1,4,4]  R1129     -4.0419352054595947e-01
    z[1,4,5]  R16       -1
    z[1,4,5]  R43       1
    z[1,4,5]  R1046     -1
    z[1,4,5]  R1047     1
    z[1,4,5]  R1050     -0.16961570084095
    z[1,4,5]  R1051     -3.6109413951635361e-02
    z[1,4,5]  R1052     -5.2790228277444839e-02
    z[1,4,5]  R1053     -6.3004577159881592e-01
    z[1,4,5]  R1054     -2.7320614457130432e-01
    z[1,4,5]  R1055     -1.2381795793771744e-01
    z[1,4,5]  R1056     -5.9111952781677246e-01
    z[1,4,5]  R1057     7.3343284428119659e-02
    z[1,4,5]  R1058     -1.9130037724971771e-01
    z[1,4,5]  R1059     -1.9146957993507385e-01
    z[1,4,5]  R1060     4.3890848755836487e-01
    z[1,4,5]  R1061     7.4039161205291748e-01
    z[1,4,5]  R1062     -1.0637371987104416e-01
    z[1,4,5]  R1063     -1.7951239645481110e-01
    z[1,4,5]  R1064     1.9836017489433289e-01
    z[1,4,5]  R1065     -3.6952443420886993e-02
    z[1,4,5]  R1066     -4.4627869129180908e-01
    z[1,4,5]  R1067     -1.9919851422309875e-01
    z[1,4,5]  R1068     -5.9514995664358139e-03
    z[1,4,5]  R1069     4.3356409668922424e-01
    z[1,4,5]  R1070     -5.4642057418823242e-01
    z[1,4,5]  R1071     -1.7104054987430573e-01
    z[1,4,5]  R1072     -2.1577434241771698e-01
    z[1,4,5]  R1073     -9.4331823289394379e-02
    z[1,4,5]  R1074     -2.9091143608093262e-01
    z[1,4,5]  R1075     1.9863104820251465e-01
    z[1,4,5]  R1076     -2.0626686513423920e-02
    z[1,4,5]  R1077     -3.2981079816818237e-01
    z[1,4,5]  R1078     -7.5890876352787018e-02
    z[1,4,5]  R1079     -2.1043565869331360e-01
    z[1,4,5]  R1080     0.0350484624505043
    z[1,4,5]  R1081     -1.2076556682586670e-01
    z[1,4,5]  R1082     -4.7361978888511658e-01
    z[1,4,5]  R1083     -6.5594747662544250e-02
    z[1,4,5]  R1084     2.2551345825195312e-01
    z[1,4,5]  R1085     -1.9245958328247070e-01
    z[1,4,5]  R1086     3.8899150490760803e-01
    z[1,4,5]  R1087     9.7562968730926514e-02
    z[1,4,5]  R1088     3.4499558806419373e-01
    z[1,4,5]  R1089     -1.3019940257072449e-01
    z[1,4,5]  R1090     1.0589842498302460e-01
    z[1,4,5]  R1091     1.9910521805286407e-01
    z[1,4,5]  R1092     -4.3603006005287170e-01
    z[1,4,5]  R1093     -7.7005207538604736e-02
    z[1,4,5]  R1094     -1.8238103389739990e-01
    z[1,4,5]  R1095     -5.3781938552856445e-01
    z[1,4,5]  R1096     -5.3805822134017944e-01
    z[1,4,5]  R1097     -2.5099441409111023e-01
    z[1,4,5]  R1098     1.6526119410991669e-01
    z[1,4,5]  R1099     -2.2789016366004944e-01
    z[1,4,5]  R1100     -3.2468929886817932e-01
    z[1,4,5]  R1101     5.9007006883621216e-01
    z[1,4,5]  R1102     2.2747208178043365e-01
    z[1,4,5]  R1103     3.8374658674001694e-02
    z[1,4,5]  R1104     4.2450428009033203e-01
    z[1,4,5]  R1105     3.1561350822448730e-01
    z[1,4,5]  R1106     5.3853505849838257e-01
    z[1,4,5]  R1107     1.8006195127964020e-01
    z[1,4,5]  R1108     -2.6605721563100815e-02
    z[1,4,5]  R1109     -1.6208153218030930e-02
    z[1,4,5]  R1110     4.7667166590690613e-01
    z[1,4,5]  R1111     -0.448431134223938
    z[1,4,5]  R1112     2.6421904563903809e-01
    z[1,4,5]  R1113     -1.2603420019149780e-01
    z[1,4,5]  R1114     -1.8004243075847626e-01
    z[1,4,5]  R1115     2.6888146996498108e-01
    z[1,4,5]  R1116     0.0771268755197525
    z[1,4,5]  R1117     -1.2749271094799042e-01
    z[1,4,5]  R1118     3.5987859964370728e-01
    z[1,4,5]  R1119     -2.9945179820060730e-02
    z[1,4,5]  R1120     7.1670997142791748e-01
    z[1,4,5]  R1121     -6.7529237270355225e-01
    z[1,4,5]  R1122     5.5308806896209717e-01
    z[1,4,5]  R1123     -2.6985979080200195e-01
    z[1,4,5]  R1124     -1.2557722628116608e-01
    z[1,4,5]  R1125     -7.6149078086018562e-03
    z[1,4,5]  R1126     1.1959961801767349e-01
    z[1,4,5]  R1127     1.7496833205223083e-01
    z[1,4,5]  R1128     0.0494014136493206
    z[1,4,5]  R1129     1.8870449066162109e-01
    z[1,4,6]  R17       -1
    z[1,4,6]  R44       1
    z[1,4,6]  R1048     -1
    z[1,4,6]  R1049     1
    z[1,4,6]  R1050     -2.4655713140964508e-01
    z[1,4,6]  R1051     -4.1694027185440063e-01
    z[1,4,6]  R1052     -1.7547542229294777e-02
    z[1,4,6]  R1053     -3.0434769392013550e-01
    z[1,4,6]  R1054     -3.6931043863296509e-01
    z[1,4,6]  R1055     -8.2689769566059113e-02
    z[1,4,6]  R1056     2.4606725573539734e-01
    z[1,4,6]  R1057     9.0966427326202393e-01
    z[1,4,6]  R1058     -1.6713818907737732e-01
    z[1,4,6]  R1059     -2.6994574069976807e-01
    z[1,4,6]  R1060     1.7012619972229004e-01
    z[1,4,6]  R1061     -7.5329937040805817e-02
    z[1,4,6]  R1062     5.2180871367454529e-02
    z[1,4,6]  R1063     -4.0868866443634033e-01
    z[1,4,6]  R1064     3.8819864392280579e-01
    z[1,4,6]  R1065     1.3943642377853394e-01
    z[1,4,6]  R1066     3.8652750849723816e-01
    z[1,4,6]  R1067     5.6078654527664185e-01
    z[1,4,6]  R1068     2.5621561333537102e-02
    z[1,4,6]  R1069     -5.8213543891906738e-01
    z[1,4,6]  R1070     -2.3434561491012573e-01
    z[1,4,6]  R1071     -2.3424968123435974e-01
    z[1,4,6]  R1072     1.1174045503139496e-01
    z[1,4,6]  R1073     2.7887317538261414e-01
    z[1,4,6]  R1074     4.8269498348236084e-01
    z[1,4,6]  R1075     -4.0791699290275574e-01
    z[1,4,6]  R1076     3.9846265316009521e-01
    z[1,4,6]  R1077     3.9806911349296570e-01
    z[1,4,6]  R1078     4.9638313055038452e-01
    z[1,4,6]  R1079     1.7675362527370453e-01
    z[1,4,6]  R1080     6.2091845273971558e-01
    z[1,4,6]  R1081     4.9711546301841736e-01
    z[1,4,6]  R1082     7.2336748242378235e-02
    z[1,4,6]  R1083     2.6968801021575928e-01
    z[1,4,6]  R1084     -4.3976327776908875e-01
    z[1,4,6]  R1085     6.4820420742034912e-01
    z[1,4,6]  R1086     -2.0570772886276245e-01
    z[1,4,6]  R1087     -1.6415183246135712e-01
    z[1,4,6]  R1088     -0.0460810661315918
    z[1,4,6]  R1089     9.5752745866775513e-02
    z[1,4,6]  R1090     -2.1268017590045929e-01
    z[1,4,6]  R1091     -3.8311373442411423e-02
    z[1,4,6]  R1092     1.5584291517734528e-01
    z[1,4,6]  R1093     4.4229146838188171e-01
    z[1,4,6]  R1094     -2.8183114528656006e-01
    z[1,4,6]  R1095     -0.0658646747469902
    z[1,4,6]  R1096     1.1234815418720245e-01
    z[1,4,6]  R1097     3.6079812049865723e-01
    z[1,4,6]  R1098     3.8736215233802795e-01
    z[1,4,6]  R1099     -0.0959039181470871
    z[1,4,6]  R1100     4.5730617642402649e-01
    z[1,4,6]  R1101     -2.6038253307342529e-01
    z[1,4,6]  R1102     -6.8244969844818115e-01
    z[1,4,6]  R1103     4.1007933020591736e-01
    z[1,4,6]  R1104     1.2177149206399918e-01
    z[1,4,6]  R1105     -1.5467011835426092e-03
    z[1,4,6]  R1106     1.3537776470184326e-01
    z[1,4,6]  R1107     -1.6832861304283142e-01
    z[1,4,6]  R1108     -7.6504252851009369e-02
    z[1,4,6]  R1109     6.8134978413581848e-02
    z[1,4,6]  R1110     -4.6509113907814026e-01
    z[1,4,6]  R1111     -2.8217834234237671e-01
    z[1,4,6]  R1112     -4.7712126374244690e-01
    z[1,4,6]  R1113     -2.9108732938766479e-01
    z[1,4,6]  R1114     -2.6488119363784790e-01
    z[1,4,6]  R1115     4.1941741108894348e-01
    z[1,4,6]  R1116     2.1148538589477539e-01
    z[1,4,6]  R1117     -5.6169737130403519e-02
    z[1,4,6]  R1118     1.5174710750579834e-01
    z[1,4,6]  R1119     -1.6998873651027679e-01
    z[1,4,6]  R1120     1.5894284844398499e-01
    z[1,4,6]  R1121     -6.5151679515838623e-01
    z[1,4,6]  R1122     -4.5515727996826172e-01
    z[1,4,6]  R1123     -5.3155469894409180e-01
    z[1,4,6]  R1124     9.0372376143932343e-02
    z[1,4,6]  R1125     -2.5739893317222595e-01
    z[1,4,6]  R1126     2.9591116309165955e-01
    z[1,4,6]  R1127     3.3283557742834091e-02
    z[1,4,6]  R1128     2.6818379759788513e-01
    z[1,4,6]  R1129     1.1601234972476959e-01
    z[4,1,0]  R11       1
    z[4,1,0]  R38       -1
    z[4,1,0]  R1130     -1
    z[4,1,0]  R1131     1
    z[4,1,0]  R1144     7.7755272388458252e-01
    z[4,1,0]  R1145     6.3734090328216553e-01
    z[4,1,0]  R1146     5.8479756116867065e-01
    z[4,1,0]  R1147     6.0710543394088745e-01
    z[4,1,0]  R1148     3.8329303264617920e-01
    z[4,1,0]  R1149     2.1687658131122589e-01
    z[4,1,0]  R1150     2.1503403782844543e-02
    z[4,1,0]  R1151     3.1548026204109192e-01
    z[4,1,0]  R1152     0.434079110622406
    z[4,1,0]  R1153     0.626015841960907
    z[4,1,0]  R1154     5.6098586320877075e-01
    z[4,1,0]  R1155     3.3980640769004822e-01
    z[4,1,0]  R1156     2.1491794288158417e-01
    z[4,1,0]  R1157     -6.8108814954757690e-01
    z[4,1,0]  R1158     -3.8750776648521423e-01
    z[4,1,0]  R1159     -4.7351148724555969e-01
    z[4,1,0]  R1160     -5.8315277099609375e-01
    z[4,1,0]  R1161     -6.1338418722152710e-01
    z[4,1,0]  R1162     -8.8346785306930542e-01
    z[4,1,0]  R1163     -8.1260401010513306e-01
    z[4,1,0]  R1164     2.0011156797409058e-01
    z[4,1,0]  R1165     -3.7151196599006653e-01
    z[4,1,0]  R1166     -0.533784031867981
    z[4,1,0]  R1167     -7.4237263202667236e-01
    z[4,1,0]  R1168     -2.9535919427871704e-01
    z[4,1,0]  R1169     -2.5586044788360596e-01
    z[4,1,0]  R1170     -3.4152883291244507e-01
    z[4,1,0]  R1171     -4.1218620538711548e-01
    z[4,1,0]  R1172     -3.6068147420883179e-01
    z[4,1,0]  R1173     -1.7500633001327515e-01
    z[4,1,0]  R1174     4.9794915318489075e-01
    z[4,1,0]  R1175     1.9511704146862030e-01
    z[4,1,0]  R1176     3.2752478122711182e-01
    z[4,1,0]  R1177     -5.1430463790893555e-02
    z[4,1,0]  R1178     -5.2251976728439331e-01
    z[4,1,0]  R1179     -6.1259114742279053e-01
    z[4,1,0]  R1180     -3.8758561015129089e-01
    z[4,1,0]  R1181     -8.7527495622634888e-01
    z[4,1,0]  R1182     -6.8857854604721069e-01
    z[4,1,0]  R1183     -6.6475450992584229e-01
    z[4,1,0]  R1184     7.4860262870788574e-01
    z[4,1,0]  R1185     3.6833679676055908e-01
    z[4,1,0]  R1186     -2.2596074640750885e-01
    z[4,1,0]  R1187     -3.0306759476661682e-01
    z[4,1,0]  R1188     -1.4573006331920624e-01
    z[4,1,0]  R1189     -0.50286865234375
    z[4,1,0]  R1190     -8.5654549300670624e-02
    z[4,1,0]  R1191     1.5423680841922760e-01
    z[4,1,0]  R1192     -3.0090352892875671e-01
    z[4,1,0]  R1193     -3.6334908008575439e-01
    z[4,1,0]  R1194     -3.2288312911987305e-01
    z[4,1,0]  R1195     4.0381222963333130e-01
    z[4,1,0]  R1196     -8.3608108758926392e-01
    z[4,1,0]  R1197     -5.0338220596313477e-01
    z[4,1,0]  R1198     -6.4310878515243530e-01
    z[4,1,0]  R1199     6.7158448696136475e-01
    z[4,1,0]  R1200     -2.9885500669479370e-01
    z[4,1,0]  R1201     -6.3888782262802124e-01
    z[4,1,0]  R1202     3.1097555160522461e-01
    z[4,1,0]  R1203     -5.0072693824768066e-01
    z[4,1,0]  R1204     -1.9979985058307648e-01
    z[4,1,0]  R1205     -5.3643178939819336e-01
    z[4,1,0]  R1206     0.607283890247345
    z[4,1,0]  R1207     -7.1195596456527710e-01
    z[4,1,0]  R1208     -6.0410439968109131e-01
    z[4,1,0]  R1209     -8.3872246742248535e-01
    z[4,1,0]  R1210     -4.6909371018409729e-01
    z[4,1,0]  R1211     6.2660795450210571e-01
    z[4,1,0]  R1212     -3.5793432593345642e-01
    z[4,1,0]  R1213     4.1159999370574951e-01
    z[4,1,0]  R1214     7.6862829923629761e-01
    z[4,1,0]  R1215     7.8859555721282959e-01
    z[4,1,0]  R1216     0.763009250164032
    z[4,1,0]  R1217     -7.1807646751403809e-01
    z[4,1,0]  R1218     5.9774047136306763e-01
    z[4,1,0]  R1219     -1.5244425833225250e-01
    z[4,1,0]  R1220     7.3239183425903320e-01
    z[4,1,0]  R1221     2.9017889499664307e-01
    z[4,1,0]  R1222     2.7914133667945862e-01
    z[4,1,0]  R1223     -4.0742442011833191e-02
    z[4,1,1]  R12       1
    z[4,1,1]  R39       -1
    z[4,1,1]  R1132     -1
    z[4,1,1]  R1133     1
    z[4,1,1]  R1144     -3.9053717255592346e-01
    z[4,1,1]  R1145     -2.3057553172111511e-01
    z[4,1,1]  R1146     -3.9834627509117126e-01
    z[4,1,1]  R1147     -3.2214903831481934e-01
    z[4,1,1]  R1148     -3.1685826182365417e-01
    z[4,1,1]  R1149     0.18353371322155
    z[4,1,1]  R1150     1.6331650316715240e-01
    z[4,1,1]  R1151     -2.2192259784787893e-03
    z[4,1,1]  R1152     -1.6745314002037048e-02
    z[4,1,1]  R1153     1.4434356987476349e-01
    z[4,1,1]  R1154     4.1506272554397583e-01
    z[4,1,1]  R1155     4.3609973788261414e-01
    z[4,1,1]  R1156     6.3473701477050781e-01
    z[4,1,1]  R1157     3.7802930921316147e-02
    z[4,1,1]  R1158     3.8586241006851196e-01
    z[4,1,1]  R1159     8.1718474626541138e-02
    z[4,1,1]  R1160     7.6087392866611481e-02
    z[4,1,1]  R1161     6.9843932986259460e-02
    z[4,1,1]  R1162     1.9197058677673340e-01
    z[4,1,1]  R1163     -1.7714096605777740e-01
    z[4,1,1]  R1164     -8.3324313163757324e-02
    z[4,1,1]  R1165     2.2697913646697998e-01
    z[4,1,1]  R1166     7.6907515525817871e-02
    z[4,1,1]  R1167     9.3378983438014984e-02
    z[4,1,1]  R1168     -2.8235715627670288e-01
    z[4,1,1]  R1169     6.9965416193008423e-01
    z[4,1,1]  R1170     6.3529521226882935e-01
    z[4,1,1]  R1171     6.1751806735992432e-01
    z[4,1,1]  R1172     5.3761011362075806e-01
    z[4,1,1]  R1173     4.2723336815834045e-01
    z[4,1,1]  R1174     -9.8839856684207916e-02
    z[4,1,1]  R1175     -2.4453786015510559e-01
    z[4,1,1]  R1176     6.5430924296379089e-02
    z[4,1,1]  R1177     4.4217151403427124e-01
    z[4,1,1]  R1178     2.1262690424919128e-01
    z[4,1,1]  R1179     -4.7013565897941589e-01
    z[4,1,1]  R1180     -5.2967935800552368e-01
    z[4,1,1]  R1181     -0.095587819814682
    z[4,1,1]  R1182     -3.5056486725807190e-01
    z[4,1,1]  R1183     -0.279590904712677
    z[4,1,1]  R1184     3.9658987522125244e-01
    z[4,1,1]  R1185     3.3228096365928650e-01
    z[4,1,1]  R1186     2.4429461359977722e-01
    z[4,1,1]  R1187     4.4257181882858276e-01
    z[4,1,1]  R1188     2.6678934693336487e-01
    z[4,1,1]  R1189     2.8248181939125061e-01
    z[4,1,1]  R1190     3.1439480185508728e-01
    z[4,1,1]  R1191     3.0521667003631592e-01
    z[4,1,1]  R1192     2.9148623347282410e-01
    z[4,1,1]  R1193     4.8344865441322327e-01
    z[4,1,1]  R1194     7.9831188917160034e-01
    z[4,1,1]  R1195     3.5552966594696045e-01
    z[4,1,1]  R1196     -5.0519472360610962e-01
    z[4,1,1]  R1197     -7.0010378956794739e-02
    z[4,1,1]  R1198     -3.7174528837203979e-01
    z[4,1,1]  R1199     -5.6620782613754272e-01
    z[4,1,1]  R1200     3.1890600919723511e-01
    z[4,1,1]  R1201     -9.6032015979290009e-02
    z[4,1,1]  R1202     -8.3104193210601807e-01
    z[4,1,1]  R1203     -2.6378947496414185e-01
    z[4,1,1]  R1204     7.5350910425186157e-01
    z[4,1,1]  R1205     1.5285126864910126e-01
    z[4,1,1]  R1206     2.2692620754241943e-02
    z[4,1,1]  R1207     -1.4521090686321259e-01
    z[4,1,1]  R1208     -9.3496374785900116e-02
    z[4,1,1]  R1209     -4.4312536716461182e-02
    z[4,1,1]  R1210     -9.4921454787254333e-02
    z[4,1,1]  R1211     -4.1695181280374527e-02
    z[4,1,1]  R1212     -2.3240816593170166e-01
    z[4,1,1]  R1213     -0.521371066570282
    z[4,1,1]  R1214     5.1249540410935879e-03
    z[4,1,1]  R1215     -5.0348155200481415e-02
    z[4,1,1]  R1216     -1.5467119216918945e-01
    z[4,1,1]  R1217     1.0522312484681606e-02
    z[4,1,1]  R1218     -3.1535571813583374e-01
    z[4,1,1]  R1219     2.9513699933886528e-02
    z[4,1,1]  R1220     -3.4852899610996246e-02
    z[4,1,1]  R1221     -4.8090791702270508e-01
    z[4,1,1]  R1222     -4.9988901615142822e-01
    z[4,1,1]  R1223     -6.3789361715316772e-01
    z[4,1,2]  R13       1
    z[4,1,2]  R40       -1
    z[4,1,2]  R1134     -1
    z[4,1,2]  R1135     1
    z[4,1,2]  R1144     9.6842184662818909e-02
    z[4,1,2]  R1145     -0.262206107378006
    z[4,1,2]  R1146     9.9797770380973816e-02
    z[4,1,2]  R1147     -4.1073697805404663e-01
    z[4,1,2]  R1148     -7.5050640106201172e-01
    z[4,1,2]  R1149     -7.6529151201248169e-01
    z[4,1,2]  R1150     -7.0444834232330322e-01
    z[4,1,2]  R1151     -6.2899458408355713e-01
    z[4,1,2]  R1152     -5.4802465438842773e-01
    z[4,1,2]  R1153     -3.5592085123062134e-01
    z[4,1,2]  R1154     -1.5294665098190308e-01
    z[4,1,2]  R1155     4.0598326921463013e-01
    z[4,1,2]  R1156     6.5435290336608887e-02
    z[4,1,2]  R1157     -4.0175712108612061e-01
    z[4,1,2]  R1158     -5.4046612977981567e-01
    z[4,1,2]  R1159     -7.4267548322677612e-01
    z[4,1,2]  R1160     -5.4421937465667725e-01
    z[4,1,2]  R1161     -3.9016574621200562e-01
    z[4,1,2]  R1162     -1.6744016110897064e-01
    z[4,1,2]  R1163     -4.2687937617301941e-01
    z[4,1,2]  R1164     -5.4102480411529541e-01
    z[4,1,2]  R1165     -0.502291738986969
    z[4,1,2]  R1166     -4.4189968705177307e-01
    z[4,1,2]  R1167     -4.9744647741317749e-01
    z[4,1,2]  R1168     -8.1178158521652222e-01
    z[4,1,2]  R1169     2.6623749732971191e-01
    z[4,1,2]  R1170     3.9537829160690308e-01
    z[4,1,2]  R1171     6.1859405832365155e-04
    z[4,1,2]  R1172     1.4093835838139057e-02
    z[4,1,2]  R1173     3.3906945586204529e-01
    z[4,1,2]  R1174     -3.6892163753509521e-01
    z[4,1,2]  R1175     -5.6913815438747406e-02
    z[4,1,2]  R1176     -2.8455594182014465e-01
    z[4,1,2]  R1177     9.5352604985237122e-02
    z[4,1,2]  R1178     -7.0583587884902954e-01
    z[4,1,2]  R1179     -1.8528589606285095e-01
    z[4,1,2]  R1180     -5.0818198919296265e-01
    z[4,1,2]  R1181     1.8494956195354462e-01
    z[4,1,2]  R1182     -8.1987380981445312e-02
    z[4,1,2]  R1183     5.7027824223041534e-02
    z[4,1,2]  R1184     1.2885268032550812e-01
    z[4,1,2]  R1185     1.4797152578830719e-01
    z[4,1,2]  R1186     7.6367869973182678e-02
    z[4,1,2]  R1187     1.0282432287931442e-01
    z[4,1,2]  R1188     4.6960480511188507e-02
    z[4,1,2]  R1189     -1.8596945703029633e-01
    z[4,1,2]  R1190     1.6917736828327179e-01
    z[4,1,2]  R1191     1.0263492166996002e-01
    z[4,1,2]  R1192     -1.2520714104175568e-01
    z[4,1,2]  R1193     0.291836678981781
    z[4,1,2]  R1194     0.0642719641327858
    z[4,1,2]  R1195     -6.8011187016963959e-02
    z[4,1,2]  R1196     -1.1339828372001648e-01
    z[4,1,2]  R1197     -7.1803522109985352e-01
    z[4,1,2]  R1198     -9.6472300589084625e-02
    z[4,1,2]  R1199     8.3359532058238983e-02
    z[4,1,2]  R1200     4.7368472814559937e-01
    z[4,1,2]  R1201     -1.4865960180759430e-01
    z[4,1,2]  R1202     -3.7821326404809952e-03
    z[4,1,2]  R1203     -9.9031753838062286e-02
    z[4,1,2]  R1204     3.6033112555742264e-02
    z[4,1,2]  R1205     4.8918455839157104e-01
    z[4,1,2]  R1206     2.5622749328613281e-01
    z[4,1,2]  R1207     1.3521020114421844e-01
    z[4,1,2]  R1208     4.4283643364906311e-01
    z[4,1,2]  R1209     -1.9770139455795288e-01
    z[4,1,2]  R1210     7.4132215976715088e-01
    z[4,1,2]  R1211     2.6134006679058075e-02
    z[4,1,2]  R1212     2.2976528108119965e-01
    z[4,1,2]  R1213     2.9996795579791069e-02
    z[4,1,2]  R1214     1.0451861470937729e-01
    z[4,1,2]  R1215     5.2703902125358582e-02
    z[4,1,2]  R1216     1.2970089912414551e-01
    z[4,1,2]  R1217     -1.4823801815509796e-01
    z[4,1,2]  R1218     7.5197708792984486e-03
    z[4,1,2]  R1219     3.6111307144165039e-01
    z[4,1,2]  R1220     1.5699344873428345e-01
    z[4,1,2]  R1221     7.2317175567150116e-02
    z[4,1,2]  R1222     2.7384883165359497e-01
    z[4,1,2]  R1223     4.4822001457214355e-01
    z[4,1,3]  R14       1
    z[4,1,3]  R41       -1
    z[4,1,3]  R1136     -1
    z[4,1,3]  R1137     1
    z[4,1,3]  R1144     -0.414764404296875
    z[4,1,3]  R1145     -2.5034227967262268e-01
    z[4,1,3]  R1146     -3.9581304788589478e-01
    z[4,1,3]  R1147     -3.9183524250984192e-01
    z[4,1,3]  R1148     -2.0016261935234070e-01
    z[4,1,3]  R1149     -1.9974724948406219e-01
    z[4,1,3]  R1150     1.7060551047325134e-01
    z[4,1,3]  R1151     1.6670159995555878e-01
    z[4,1,3]  R1152     1.4519914984703064e-01
    z[4,1,3]  R1153     4.4855013489723206e-01
    z[4,1,3]  R1154     3.5233241319656372e-01
    z[4,1,3]  R1155     3.2735961675643921e-01
    z[4,1,3]  R1156     0.160980224609375
    z[4,1,3]  R1157     4.2600056529045105e-01
    z[4,1,3]  R1158     4.6237173676490784e-01
    z[4,1,3]  R1159     3.0387637019157410e-01
    z[4,1,3]  R1160     2.2216325998306274e-01
    z[4,1,3]  R1161     5.8633047342300415e-01
    z[4,1,3]  R1162     3.7895858287811279e-01
    z[4,1,3]  R1163     3.3695170283317566e-01
    z[4,1,3]  R1164     4.5463311672210693e-01
    z[4,1,3]  R1165     4.7110924124717712e-01
    z[4,1,3]  R1166     3.7987053394317627e-01
    z[4,1,3]  R1167     2.6640614867210388e-01
    z[4,1,3]  R1168     1.8347172439098358e-01
    z[4,1,3]  R1169     -3.3782243728637695e-01
    z[4,1,3]  R1170     -5.2226340770721436e-01
    z[4,1,3]  R1171     -0.650968074798584
    z[4,1,3]  R1172     -6.5431934595108032e-01
    z[4,1,3]  R1173     -7.9564833641052246e-01
    z[4,1,3]  R1174     1.7952050268650055e-01
    z[4,1,3]  R1175     1.1064269393682480e-01
    z[4,1,3]  R1176     4.6490901708602905e-01
    z[4,1,3]  R1177     5.7867074012756348e-01
    z[4,1,3]  R1178     3.6209985613822937e-01
    z[4,1,3]  R1179     -2.6049536466598511e-01
    z[4,1,3]  R1180     -3.7754493951797485e-01
    z[4,1,3]  R1181     -3.9802354574203491e-01
    z[4,1,3]  R1182     -5.6722772121429443e-01
    z[4,1,3]  R1183     -5.1404041051864624e-01
    z[4,1,3]  R1184     3.0141115188598633e-01
    z[4,1,3]  R1185     2.4837906658649445e-01
    z[4,1,3]  R1186     4.5430219173431396e-01
    z[4,1,3]  R1187     1.1281071603298187e-01
    z[4,1,3]  R1188     -6.9318228960037231e-01
    z[4,1,3]  R1189     7.7586674690246582e-01
    z[4,1,3]  R1190     1.8007653951644897e-01
    z[4,1,3]  R1191     1.1757089197635651e-01
    z[4,1,3]  R1192     8.4759509563446045e-01
    z[4,1,3]  R1193     -0.662113606929779
    z[4,1,3]  R1194     -1.7191989719867706e-01
    z[4,1,3]  R1195     1.4346306025981903e-01
    z[4,1,3]  R1196     -1.5986124053597450e-03
    z[4,1,3]  R1197     -7.7496804296970367e-02
    z[4,1,3]  R1198     -3.5832509398460388e-01
    z[4,1,3]  R1199     -4.2696484923362732e-01
    z[4,1,3]  R1200     -4.8628427088260651e-02
    z[4,1,3]  R1201     -4.4954848289489746e-01
    z[4,1,3]  R1202     4.5265042781829834e-01
    z[4,1,3]  R1203     -2.2668300569057465e-01
    z[4,1,3]  R1204     3.5406373441219330e-02
    z[4,1,3]  R1205     -5.3441369533538818e-01
    z[4,1,3]  R1206     -6.8717229366302490e-01
    z[4,1,3]  R1207     -2.2073395550251007e-01
    z[4,1,3]  R1208     -3.3366686105728149e-01
    z[4,1,3]  R1209     1.7880079150199890e-01
    z[4,1,3]  R1210     -8.5172258317470551e-02
    z[4,1,3]  R1211     -1.1860412359237671e-01
    z[4,1,3]  R1212     -7.0354276895523071e-01
    z[4,1,3]  R1213     6.8548142910003662e-01
    z[4,1,3]  R1214     -1.5521142631769180e-02
    z[4,1,3]  R1215     3.5324998199939728e-02
    z[4,1,3]  R1216     -3.2179304957389832e-01
    z[4,1,3]  R1217     -1.7192016541957855e-01
    z[4,1,3]  R1218     -4.1844853758811951e-01
    z[4,1,3]  R1219     -5.6576901674270630e-01
    z[4,1,3]  R1220     -4.7636792063713074e-01
    z[4,1,3]  R1221     7.9875022172927856e-01
    z[4,1,3]  R1222     0.661388099193573
    z[4,1,3]  R1223     5.9479230642318726e-01
    z[4,1,4]  R15       1
    z[4,1,4]  R42       -1
    z[4,1,4]  R1138     -1
    z[4,1,4]  R1139     1
    z[4,1,4]  R1144     -7.0972524583339691e-02
    z[4,1,4]  R1145     -6.0671043395996094e-01
    z[4,1,4]  R1146     -3.4394067525863647e-01
    z[4,1,4]  R1147     -6.2061451375484467e-02
    z[4,1,4]  R1148     -1.9149589538574219e-01
    z[4,1,4]  R1149     1.1042827740311623e-02
    z[4,1,4]  R1150     -3.8129106163978577e-01
    z[4,1,4]  R1151     -0.532794713973999
    z[4,1,4]  R1152     -5.5903512239456177e-01
    z[4,1,4]  R1153     -4.4526490569114685e-01
    z[4,1,4]  R1154     -2.2568744421005249e-01
    z[4,1,4]  R1155     -7.9875849187374115e-02
    z[4,1,4]  R1156     5.6935474276542664e-02
    z[4,1,4]  R1157     -1.4888532459735870e-01
    z[4,1,4]  R1158     4.9446769990026951e-03
    z[4,1,4]  R1159     -1.5995962917804718e-01
    z[4,1,4]  R1160     1.6281167045235634e-02
    z[4,1,4]  R1161     -2.4922268092632294e-01
    z[4,1,4]  R1162     -6.6522851586341858e-02
    z[4,1,4]  R1163     8.7339393794536591e-02
    z[4,1,4]  R1164     1.0043712705373764e-01
    z[4,1,4]  R1165     2.3559153079986572e-01
    z[4,1,4]  R1166     2.6856338977813721e-01
    z[4,1,4]  R1167     1.4533202350139618e-01
    z[4,1,4]  R1168     1.9444513320922852e-01
    z[4,1,4]  R1169     1.0865075886249542e-01
    z[4,1,4]  R1170     6.4610771369189024e-04
    z[4,1,4]  R1171     -7.4865229427814484e-02
    z[4,1,4]  R1172     -3.4858337603509426e-03
    z[4,1,4]  R1173     9.5011197030544281e-02
    z[4,1,4]  R1174     1.8711134791374207e-01
    z[4,1,4]  R1175     -0.078458271920681
    z[4,1,4]  R1176     -2.7974864840507507e-01
    z[4,1,4]  R1177     3.2017588615417480e-01
    z[4,1,4]  R1178     1.6883562505245209e-01
    z[4,1,4]  R1179     -4.8497796058654785e-01
    z[4,1,4]  R1180     -0.257993221282959
    z[4,1,4]  R1181     -2.0148554816842079e-02
    z[4,1,4]  R1182     1.1473413556814194e-02
    z[4,1,4]  R1183     -4.0419352054595947e-01
    z[4,1,4]  R1184     -2.9206001758575439e-01
    z[4,1,4]  R1185     -7.0369493961334229e-01
    z[4,1,4]  R1186     -8.2094132900238037e-01
    z[4,1,4]  R1187     -4.4653770327568054e-01
    z[4,1,4]  R1188     4.6243643760681152e-01
    z[4,1,4]  R1189     9.2762112617492676e-02
    z[4,1,4]  R1190     -6.5023016929626465e-01
    z[4,1,4]  R1191     -1.6071267426013947e-01
    z[4,1,4]  R1192     -1.6083371639251709e-01
    z[4,1,4]  R1193     -3.4067001193761826e-02
    z[4,1,4]  R1194     -5.6334905326366425e-02
    z[4,1,4]  R1195     3.6259177327156067e-01
    z[4,1,4]  R1196     -1.3728362321853638e-01
    z[4,1,4]  R1197     -1.4447632431983948e-01
    z[4,1,4]  R1198     -3.4708479046821594e-01
    z[4,1,4]  R1199     1.3537852466106415e-01
    z[4,1,4]  R1200     0.483398973941803
    z[4,1,4]  R1201     0.0651547759771347
    z[4,1,4]  R1202     8.4052875638008118e-02
    z[4,1,4]  R1203     -3.0271375179290771e-01
    z[4,1,4]  R1204     1.9041784107685089e-01
    z[4,1,4]  R1205     2.8257763385772705e-01
    z[4,1,4]  R1206     -1.8381620943546295e-01
    z[4,1,4]  R1207     0.564232587814331
    z[4,1,4]  R1208     3.5421684384346008e-02
    z[4,1,4]  R1209     1.3294674456119537e-01
    z[4,1,4]  R1210     0.234371617436409
    z[4,1,4]  R1211     0.568893551826477
    z[4,1,4]  R1212     0.133975088596344
    z[4,1,4]  R1213     1.1157119274139404e-01
    z[4,1,4]  R1214     1.0607088357210159e-01
    z[4,1,4]  R1215     3.3143392205238342e-01
    z[4,1,4]  R1216     2.0969532430171967e-01
    z[4,1,4]  R1217     5.9639763832092285e-01
    z[4,1,4]  R1218     3.5192811489105225e-01
    z[4,1,4]  R1219     2.6111885905265808e-01
    z[4,1,4]  R1220     -1.3108791410923004e-01
    z[4,1,4]  R1221     -6.9482550024986267e-02
    z[4,1,4]  R1222     -0.196515291929245
    z[4,1,4]  R1223     -1.0311304032802582e-01
    z[4,1,5]  R16       1
    z[4,1,5]  R43       -1
    z[4,1,5]  R1140     -1
    z[4,1,5]  R1141     1
    z[4,1,5]  R1144     1.0589842498302460e-01
    z[4,1,5]  R1145     1.9910521805286407e-01
    z[4,1,5]  R1146     -4.3603006005287170e-01
    z[4,1,5]  R1147     -7.7005207538604736e-02
    z[4,1,5]  R1148     -1.8238103389739990e-01
    z[4,1,5]  R1149     -5.3781938552856445e-01
    z[4,1,5]  R1150     -5.3805822134017944e-01
    z[4,1,5]  R1151     -2.5099441409111023e-01
    z[4,1,5]  R1152     1.6526119410991669e-01
    z[4,1,5]  R1153     -2.2789016366004944e-01
    z[4,1,5]  R1154     -3.2468929886817932e-01
    z[4,1,5]  R1155     5.9007006883621216e-01
    z[4,1,5]  R1156     2.2747208178043365e-01
    z[4,1,5]  R1157     3.8374658674001694e-02
    z[4,1,5]  R1158     4.2450428009033203e-01
    z[4,1,5]  R1159     3.1561350822448730e-01
    z[4,1,5]  R1160     5.3853505849838257e-01
    z[4,1,5]  R1161     1.8006195127964020e-01
    z[4,1,5]  R1162     -2.6605721563100815e-02
    z[4,1,5]  R1163     -1.6208153218030930e-02
    z[4,1,5]  R1164     4.7667166590690613e-01
    z[4,1,5]  R1165     -0.448431134223938
    z[4,1,5]  R1166     2.6421904563903809e-01
    z[4,1,5]  R1167     -1.2603420019149780e-01
    z[4,1,5]  R1168     -1.8004243075847626e-01
    z[4,1,5]  R1169     2.6888146996498108e-01
    z[4,1,5]  R1170     0.0771268755197525
    z[4,1,5]  R1171     -1.2749271094799042e-01
    z[4,1,5]  R1172     3.5987859964370728e-01
    z[4,1,5]  R1173     -2.9945179820060730e-02
    z[4,1,5]  R1174     7.1670997142791748e-01
    z[4,1,5]  R1175     -6.7529237270355225e-01
    z[4,1,5]  R1176     5.5308806896209717e-01
    z[4,1,5]  R1177     -2.6985979080200195e-01
    z[4,1,5]  R1178     -1.2557722628116608e-01
    z[4,1,5]  R1179     -7.6149078086018562e-03
    z[4,1,5]  R1180     1.1959961801767349e-01
    z[4,1,5]  R1181     1.7496833205223083e-01
    z[4,1,5]  R1182     0.0494014136493206
    z[4,1,5]  R1183     1.8870449066162109e-01
    z[4,1,5]  R1184     -0.16961570084095
    z[4,1,5]  R1185     -3.6109413951635361e-02
    z[4,1,5]  R1186     -5.2790228277444839e-02
    z[4,1,5]  R1187     -6.3004577159881592e-01
    z[4,1,5]  R1188     -2.7320614457130432e-01
    z[4,1,5]  R1189     -1.2381795793771744e-01
    z[4,1,5]  R1190     -5.9111952781677246e-01
    z[4,1,5]  R1191     7.3343284428119659e-02
    z[4,1,5]  R1192     -1.9130037724971771e-01
    z[4,1,5]  R1193     -1.9146957993507385e-01
    z[4,1,5]  R1194     4.3890848755836487e-01
    z[4,1,5]  R1195     7.4039161205291748e-01
    z[4,1,5]  R1196     -1.0637371987104416e-01
    z[4,1,5]  R1197     -1.7951239645481110e-01
    z[4,1,5]  R1198     1.9836017489433289e-01
    z[4,1,5]  R1199     -3.6952443420886993e-02
    z[4,1,5]  R1200     -4.4627869129180908e-01
    z[4,1,5]  R1201     -1.9919851422309875e-01
    z[4,1,5]  R1202     -5.9514995664358139e-03
    z[4,1,5]  R1203     4.3356409668922424e-01
    z[4,1,5]  R1204     -5.4642057418823242e-01
    z[4,1,5]  R1205     -1.7104054987430573e-01
    z[4,1,5]  R1206     -2.1577434241771698e-01
    z[4,1,5]  R1207     -9.4331823289394379e-02
    z[4,1,5]  R1208     -2.9091143608093262e-01
    z[4,1,5]  R1209     1.9863104820251465e-01
    z[4,1,5]  R1210     -2.0626686513423920e-02
    z[4,1,5]  R1211     -3.2981079816818237e-01
    z[4,1,5]  R1212     -7.5890876352787018e-02
    z[4,1,5]  R1213     -2.1043565869331360e-01
    z[4,1,5]  R1214     0.0350484624505043
    z[4,1,5]  R1215     -1.2076556682586670e-01
    z[4,1,5]  R1216     -4.7361978888511658e-01
    z[4,1,5]  R1217     -6.5594747662544250e-02
    z[4,1,5]  R1218     2.2551345825195312e-01
    z[4,1,5]  R1219     -1.9245958328247070e-01
    z[4,1,5]  R1220     3.8899150490760803e-01
    z[4,1,5]  R1221     9.7562968730926514e-02
    z[4,1,5]  R1222     3.4499558806419373e-01
    z[4,1,5]  R1223     -1.3019940257072449e-01
    z[4,1,6]  R17       1
    z[4,1,6]  R44       -1
    z[4,1,6]  R1142     -1
    z[4,1,6]  R1143     1
    z[4,1,6]  R1144     -2.1268017590045929e-01
    z[4,1,6]  R1145     -3.8311373442411423e-02
    z[4,1,6]  R1146     1.5584291517734528e-01
    z[4,1,6]  R1147     4.4229146838188171e-01
    z[4,1,6]  R1148     -2.8183114528656006e-01
    z[4,1,6]  R1149     -0.0658646747469902
    z[4,1,6]  R1150     1.1234815418720245e-01
    z[4,1,6]  R1151     3.6079812049865723e-01
    z[4,1,6]  R1152     3.8736215233802795e-01
    z[4,1,6]  R1153     -0.0959039181470871
    z[4,1,6]  R1154     4.5730617642402649e-01
    z[4,1,6]  R1155     -2.6038253307342529e-01
    z[4,1,6]  R1156     -6.8244969844818115e-01
    z[4,1,6]  R1157     4.1007933020591736e-01
    z[4,1,6]  R1158     1.2177149206399918e-01
    z[4,1,6]  R1159     -1.5467011835426092e-03
    z[4,1,6]  R1160     1.3537776470184326e-01
    z[4,1,6]  R1161     -1.6832861304283142e-01
    z[4,1,6]  R1162     -7.6504252851009369e-02
    z[4,1,6]  R1163     6.8134978413581848e-02
    z[4,1,6]  R1164     -4.6509113907814026e-01
    z[4,1,6]  R1165     -2.8217834234237671e-01
    z[4,1,6]  R1166     -4.7712126374244690e-01
    z[4,1,6]  R1167     -2.9108732938766479e-01
    z[4,1,6]  R1168     -2.6488119363784790e-01
    z[4,1,6]  R1169     4.1941741108894348e-01
    z[4,1,6]  R1170     2.1148538589477539e-01
    z[4,1,6]  R1171     -5.6169737130403519e-02
    z[4,1,6]  R1172     1.5174710750579834e-01
    z[4,1,6]  R1173     -1.6998873651027679e-01
    z[4,1,6]  R1174     1.5894284844398499e-01
    z[4,1,6]  R1175     -6.5151679515838623e-01
    z[4,1,6]  R1176     -4.5515727996826172e-01
    z[4,1,6]  R1177     -5.3155469894409180e-01
    z[4,1,6]  R1178     9.0372376143932343e-02
    z[4,1,6]  R1179     -2.5739893317222595e-01
    z[4,1,6]  R1180     2.9591116309165955e-01
    z[4,1,6]  R1181     3.3283557742834091e-02
    z[4,1,6]  R1182     2.6818379759788513e-01
    z[4,1,6]  R1183     1.1601234972476959e-01
    z[4,1,6]  R1184     -2.4655713140964508e-01
    z[4,1,6]  R1185     -4.1694027185440063e-01
    z[4,1,6]  R1186     -1.7547542229294777e-02
    z[4,1,6]  R1187     -3.0434769392013550e-01
    z[4,1,6]  R1188     -3.6931043863296509e-01
    z[4,1,6]  R1189     -8.2689769566059113e-02
    z[4,1,6]  R1190     2.4606725573539734e-01
    z[4,1,6]  R1191     9.0966427326202393e-01
    z[4,1,6]  R1192     -1.6713818907737732e-01
    z[4,1,6]  R1193     -2.6994574069976807e-01
    z[4,1,6]  R1194     1.7012619972229004e-01
    z[4,1,6]  R1195     -7.5329937040805817e-02
    z[4,1,6]  R1196     5.2180871367454529e-02
    z[4,1,6]  R1197     -4.0868866443634033e-01
    z[4,1,6]  R1198     3.8819864392280579e-01
    z[4,1,6]  R1199     1.3943642377853394e-01
    z[4,1,6]  R1200     3.8652750849723816e-01
    z[4,1,6]  R1201     5.6078654527664185e-01
    z[4,1,6]  R1202     2.5621561333537102e-02
    z[4,1,6]  R1203     -5.8213543891906738e-01
    z[4,1,6]  R1204     -2.3434561491012573e-01
    z[4,1,6]  R1205     -2.3424968123435974e-01
    z[4,1,6]  R1206     1.1174045503139496e-01
    z[4,1,6]  R1207     2.7887317538261414e-01
    z[4,1,6]  R1208     4.8269498348236084e-01
    z[4,1,6]  R1209     -4.0791699290275574e-01
    z[4,1,6]  R1210     3.9846265316009521e-01
    z[4,1,6]  R1211     3.9806911349296570e-01
    z[4,1,6]  R1212     4.9638313055038452e-01
    z[4,1,6]  R1213     1.7675362527370453e-01
    z[4,1,6]  R1214     6.2091845273971558e-01
    z[4,1,6]  R1215     4.9711546301841736e-01
    z[4,1,6]  R1216     7.2336748242378235e-02
    z[4,1,6]  R1217     2.6968801021575928e-01
    z[4,1,6]  R1218     -4.3976327776908875e-01
    z[4,1,6]  R1219     6.4820420742034912e-01
    z[4,1,6]  R1220     -2.0570772886276245e-01
    z[4,1,6]  R1221     -1.6415183246135712e-01
    z[4,1,6]  R1222     -0.0460810661315918
    z[4,1,6]  R1223     9.5752745866775513e-02
    z[1,5,0]  R11       -1
    z[1,5,0]  R47       1
    z[1,5,0]  R1224     -1
    z[1,5,0]  R1225     1
    z[1,5,0]  R1238     7.4860262870788574e-01
    z[1,5,0]  R1239     3.6833679676055908e-01
    z[1,5,0]  R1240     -2.2596074640750885e-01
    z[1,5,0]  R1241     -3.0306759476661682e-01
    z[1,5,0]  R1242     -1.4573006331920624e-01
    z[1,5,0]  R1243     -0.50286865234375
    z[1,5,0]  R1244     -8.5654549300670624e-02
    z[1,5,0]  R1245     1.5423680841922760e-01
    z[1,5,0]  R1246     -3.0090352892875671e-01
    z[1,5,0]  R1247     -3.6334908008575439e-01
    z[1,5,0]  R1248     -3.2288312911987305e-01
    z[1,5,0]  R1249     4.0381222963333130e-01
    z[1,5,0]  R1250     -8.3608108758926392e-01
    z[1,5,0]  R1251     -5.0338220596313477e-01
    z[1,5,0]  R1252     -6.4310878515243530e-01
    z[1,5,0]  R1253     6.7158448696136475e-01
    z[1,5,0]  R1254     -2.9885500669479370e-01
    z[1,5,0]  R1255     -6.3888782262802124e-01
    z[1,5,0]  R1256     3.1097555160522461e-01
    z[1,5,0]  R1257     -5.0072693824768066e-01
    z[1,5,0]  R1258     -1.9979985058307648e-01
    z[1,5,0]  R1259     -5.3643178939819336e-01
    z[1,5,0]  R1260     0.607283890247345
    z[1,5,0]  R1261     -7.1195596456527710e-01
    z[1,5,0]  R1262     -6.0410439968109131e-01
    z[1,5,0]  R1263     -8.3872246742248535e-01
    z[1,5,0]  R1264     -4.6909371018409729e-01
    z[1,5,0]  R1265     6.2660795450210571e-01
    z[1,5,0]  R1266     -3.5793432593345642e-01
    z[1,5,0]  R1267     4.1159999370574951e-01
    z[1,5,0]  R1268     7.6862829923629761e-01
    z[1,5,0]  R1269     7.8859555721282959e-01
    z[1,5,0]  R1270     0.763009250164032
    z[1,5,0]  R1271     -7.1807646751403809e-01
    z[1,5,0]  R1272     5.9774047136306763e-01
    z[1,5,0]  R1273     -1.5244425833225250e-01
    z[1,5,0]  R1274     7.3239183425903320e-01
    z[1,5,0]  R1275     2.9017889499664307e-01
    z[1,5,0]  R1276     2.7914133667945862e-01
    z[1,5,0]  R1277     -4.0742442011833191e-02
    z[1,5,0]  R1278     2.7077559381723404e-02
    z[1,5,0]  R1279     -1.4716574549674988e-01
    z[1,5,0]  R1280     6.6157186031341553e-01
    z[1,5,0]  R1281     3.2766574621200562e-01
    z[1,5,0]  R1282     3.5326221585273743e-01
    z[1,5,0]  R1283     -4.8980057239532471e-02
    z[1,5,0]  R1284     4.2251950502395630e-01
    z[1,5,0]  R1285     -7.9604452848434448e-01
    z[1,5,0]  R1286     3.9534687995910645e-01
    z[1,5,0]  R1287     -4.4654479622840881e-01
    z[1,5,0]  R1288     -1.4632028341293335e-01
    z[1,5,0]  R1289     -0.420944482088089
    z[1,5,0]  R1290     -2.4442516267299652e-01
    z[1,5,0]  R1291     -9.0486049652099609e-01
    z[1,5,0]  R1292     -8.8210612535476685e-01
    z[1,5,0]  R1293     -8.8734483718872070e-01
    z[1,5,0]  R1294     -0.904356837272644
    z[1,5,0]  R1295     -8.9519476890563965e-01
    z[1,5,1]  R12       -1
    z[1,5,1]  R48       1
    z[1,5,1]  R1226     -1
    z[1,5,1]  R1227     1
    z[1,5,1]  R1238     3.9658987522125244e-01
    z[1,5,1]  R1239     3.3228096365928650e-01
    z[1,5,1]  R1240     2.4429461359977722e-01
    z[1,5,1]  R1241     4.4257181882858276e-01
    z[1,5,1]  R1242     2.6678934693336487e-01
    z[1,5,1]  R1243     2.8248181939125061e-01
    z[1,5,1]  R1244     3.1439480185508728e-01
    z[1,5,1]  R1245     3.0521667003631592e-01
    z[1,5,1]  R1246     2.9148623347282410e-01
    z[1,5,1]  R1247     4.8344865441322327e-01
    z[1,5,1]  R1248     7.9831188917160034e-01
    z[1,5,1]  R1249     3.5552966594696045e-01
    z[1,5,1]  R1250     -5.0519472360610962e-01
    z[1,5,1]  R1251     -7.0010378956794739e-02
    z[1,5,1]  R1252     -3.7174528837203979e-01
    z[1,5,1]  R1253     -5.6620782613754272e-01
    z[1,5,1]  R1254     3.1890600919723511e-01
    z[1,5,1]  R1255     -9.6032015979290009e-02
    z[1,5,1]  R1256     -8.3104193210601807e-01
    z[1,5,1]  R1257     -2.6378947496414185e-01
    z[1,5,1]  R1258     7.5350910425186157e-01
    z[1,5,1]  R1259     1.5285126864910126e-01
    z[1,5,1]  R1260     2.2692620754241943e-02
    z[1,5,1]  R1261     -1.4521090686321259e-01
    z[1,5,1]  R1262     -9.3496374785900116e-02
    z[1,5,1]  R1263     -4.4312536716461182e-02
    z[1,5,1]  R1264     -9.4921454787254333e-02
    z[1,5,1]  R1265     -4.1695181280374527e-02
    z[1,5,1]  R1266     -2.3240816593170166e-01
    z[1,5,1]  R1267     -0.521371066570282
    z[1,5,1]  R1268     5.1249540410935879e-03
    z[1,5,1]  R1269     -5.0348155200481415e-02
    z[1,5,1]  R1270     -1.5467119216918945e-01
    z[1,5,1]  R1271     1.0522312484681606e-02
    z[1,5,1]  R1272     -3.1535571813583374e-01
    z[1,5,1]  R1273     2.9513699933886528e-02
    z[1,5,1]  R1274     -3.4852899610996246e-02
    z[1,5,1]  R1275     -4.8090791702270508e-01
    z[1,5,1]  R1276     -4.9988901615142822e-01
    z[1,5,1]  R1277     -6.3789361715316772e-01
    z[1,5,1]  R1278     2.1032528579235077e-01
    z[1,5,1]  R1279     1.4855297282338142e-02
    z[1,5,1]  R1280     -4.6718326210975647e-01
    z[1,5,1]  R1281     4.1429869830608368e-02
    z[1,5,1]  R1282     -1.5066677331924438e-01
    z[1,5,1]  R1283     3.8200950622558594e-01
    z[1,5,1]  R1284     -5.6179088354110718e-01
    z[1,5,1]  R1285     -2.5091665983200073e-01
    z[1,5,1]  R1286     0.735697329044342
    z[1,5,1]  R1287     5.1107460260391235e-01
    z[1,5,1]  R1288     3.1154605746269226e-01
    z[1,5,1]  R1289     4.4397643208503723e-01
    z[1,5,1]  R1290     -2.0141474902629852e-01
    z[1,5,1]  R1291     -1.1928041279315948e-01
    z[1,5,1]  R1292     1.0443801991641521e-02
    z[1,5,1]  R1293     -1.9972890615463257e-01
    z[1,5,1]  R1294     -2.3908819258213043e-01
    z[1,5,1]  R1295     -0.086459219455719
    z[1,5,2]  R13       -1
    z[1,5,2]  R49       1
    z[1,5,2]  R1228     -1
    z[1,5,2]  R1229     1
    z[1,5,2]  R1238     1.2885268032550812e-01
    z[1,5,2]  R1239     1.4797152578830719e-01
    z[1,5,2]  R1240     7.6367869973182678e-02
    z[1,5,2]  R1241     1.0282432287931442e-01
    z[1,5,2]  R1242     4.6960480511188507e-02
    z[1,5,2]  R1243     -1.8596945703029633e-01
    z[1,5,2]  R1244     1.6917736828327179e-01
    z[1,5,2]  R1245     1.0263492166996002e-01
    z[1,5,2]  R1246     -1.2520714104175568e-01
    z[1,5,2]  R1247     0.291836678981781
    z[1,5,2]  R1248     0.0642719641327858
    z[1,5,2]  R1249     -6.8011187016963959e-02
    z[1,5,2]  R1250     -1.1339828372001648e-01
    z[1,5,2]  R1251     -7.1803522109985352e-01
    z[1,5,2]  R1252     -9.6472300589084625e-02
    z[1,5,2]  R1253     8.3359532058238983e-02
    z[1,5,2]  R1254     4.7368472814559937e-01
    z[1,5,2]  R1255     -1.4865960180759430e-01
    z[1,5,2]  R1256     -3.7821326404809952e-03
    z[1,5,2]  R1257     -9.9031753838062286e-02
    z[1,5,2]  R1258     3.6033112555742264e-02
    z[1,5,2]  R1259     4.8918455839157104e-01
    z[1,5,2]  R1260     2.5622749328613281e-01
    z[1,5,2]  R1261     1.3521020114421844e-01
    z[1,5,2]  R1262     4.4283643364906311e-01
    z[1,5,2]  R1263     -1.9770139455795288e-01
    z[1,5,2]  R1264     7.4132215976715088e-01
    z[1,5,2]  R1265     2.6134006679058075e-02
    z[1,5,2]  R1266     2.2976528108119965e-01
    z[1,5,2]  R1267     2.9996795579791069e-02
    z[1,5,2]  R1268     1.0451861470937729e-01
    z[1,5,2]  R1269     5.2703902125358582e-02
    z[1,5,2]  R1270     1.2970089912414551e-01
    z[1,5,2]  R1271     -1.4823801815509796e-01
    z[1,5,2]  R1272     7.5197708792984486e-03
    z[1,5,2]  R1273     3.6111307144165039e-01
    z[1,5,2]  R1274     1.5699344873428345e-01
    z[1,5,2]  R1275     7.2317175567150116e-02
    z[1,5,2]  R1276     2.7384883165359497e-01
    z[1,5,2]  R1277     4.4822001457214355e-01
    z[1,5,2]  R1278     -3.7991592288017273e-01
    z[1,5,2]  R1279     -2.9864221811294556e-01
    z[1,5,2]  R1280     2.2859716415405273e-01
    z[1,5,2]  R1281     5.4286282509565353e-02
    z[1,5,2]  R1282     3.1203457713127136e-01
    z[1,5,2]  R1283     3.1310686469078064e-01
    z[1,5,2]  R1284     -2.7816560864448547e-01
    z[1,5,2]  R1285     2.3640289902687073e-01
    z[1,5,2]  R1286     -2.6094261556863785e-02
    z[1,5,2]  R1287     1.8322923779487610e-01
    z[1,5,2]  R1288     5.8794164657592773e-01
    z[1,5,2]  R1289     4.9670797586441040e-01
    z[1,5,2]  R1290     -4.6606090664863586e-01
    z[1,5,2]  R1291     -4.8526491969823837e-02
    z[1,5,2]  R1292     -1.6023044288158417e-01
    z[1,5,2]  R1293     -1.6508170962333679e-01
    z[1,5,2]  R1294     3.1460151076316833e-02
    z[1,5,2]  R1295     -3.8388580083847046e-02
    z[1,5,3]  R14       -1
    z[1,5,3]  R50       1
    z[1,5,3]  R1230     -1
    z[1,5,3]  R1231     1
    z[1,5,3]  R1238     3.0141115188598633e-01
    z[1,5,3]  R1239     2.4837906658649445e-01
    z[1,5,3]  R1240     4.5430219173431396e-01
    z[1,5,3]  R1241     1.1281071603298187e-01
    z[1,5,3]  R1242     -6.9318228960037231e-01
    z[1,5,3]  R1243     7.7586674690246582e-01
    z[1,5,3]  R1244     1.8007653951644897e-01
    z[1,5,3]  R1245     1.1757089197635651e-01
    z[1,5,3]  R1246     8.4759509563446045e-01
    z[1,5,3]  R1247     -0.662113606929779
    z[1,5,3]  R1248     -1.7191989719867706e-01
    z[1,5,3]  R1249     1.4346306025981903e-01
    z[1,5,3]  R1250     -1.5986124053597450e-03
    z[1,5,3]  R1251     -7.7496804296970367e-02
    z[1,5,3]  R1252     -3.5832509398460388e-01
    z[1,5,3]  R1253     -4.2696484923362732e-01
    z[1,5,3]  R1254     -4.8628427088260651e-02
    z[1,5,3]  R1255     -4.4954848289489746e-01
    z[1,5,3]  R1256     4.5265042781829834e-01
    z[1,5,3]  R1257     -2.2668300569057465e-01
    z[1,5,3]  R1258     3.5406373441219330e-02
    z[1,5,3]  R1259     -5.3441369533538818e-01
    z[1,5,3]  R1260     -6.8717229366302490e-01
    z[1,5,3]  R1261     -2.2073395550251007e-01
    z[1,5,3]  R1262     -3.3366686105728149e-01
    z[1,5,3]  R1263     1.7880079150199890e-01
    z[1,5,3]  R1264     -8.5172258317470551e-02
    z[1,5,3]  R1265     -1.1860412359237671e-01
    z[1,5,3]  R1266     -7.0354276895523071e-01
    z[1,5,3]  R1267     6.8548142910003662e-01
    z[1,5,3]  R1268     -1.5521142631769180e-02
    z[1,5,3]  R1269     3.5324998199939728e-02
    z[1,5,3]  R1270     -3.2179304957389832e-01
    z[1,5,3]  R1271     -1.7192016541957855e-01
    z[1,5,3]  R1272     -4.1844853758811951e-01
    z[1,5,3]  R1273     -5.6576901674270630e-01
    z[1,5,3]  R1274     -4.7636792063713074e-01
    z[1,5,3]  R1275     7.9875022172927856e-01
    z[1,5,3]  R1276     0.661388099193573
    z[1,5,3]  R1277     5.9479230642318726e-01
    z[1,5,3]  R1278     1.4298340678215027e-01
    z[1,5,3]  R1279     3.0610656738281250e-01
    z[1,5,3]  R1280     -4.5985820889472961e-01
    z[1,5,3]  R1281     -5.7009279727935791e-01
    z[1,5,3]  R1282     -2.6410719752311707e-01
    z[1,5,3]  R1283     4.0180769562721252e-01
    z[1,5,3]  R1284     5.2533990144729614e-01
    z[1,5,3]  R1285     -2.3259180784225464e-01
    z[1,5,3]  R1286     3.7807571887969971e-01
    z[1,5,3]  R1287     -6.2137925624847412e-01
    z[1,5,3]  R1288     -5.2404171228408813e-01
    z[1,5,3]  R1289     -2.4119694530963898e-01
    z[1,5,3]  R1290     -6.6314691305160522e-01
    z[1,5,3]  R1291     -3.0422553420066833e-01
    z[1,5,3]  R1292     -4.0116128325462341e-01
    z[1,5,3]  R1293     -3.2623365521430969e-01
    z[1,5,3]  R1294     -2.2785899043083191e-01
    z[1,5,3]  R1295     -1.5573722124099731e-01
    z[1,5,4]  R15       -1
    z[1,5,4]  R51       1
    z[1,5,4]  R1232     -1
    z[1,5,4]  R1233     1
    z[1,5,4]  R1238     -2.9206001758575439e-01
    z[1,5,4]  R1239     -7.0369493961334229e-01
    z[1,5,4]  R1240     -8.2094132900238037e-01
    z[1,5,4]  R1241     -4.4653770327568054e-01
    z[1,5,4]  R1242     4.6243643760681152e-01
    z[1,5,4]  R1243     9.2762112617492676e-02
    z[1,5,4]  R1244     -6.5023016929626465e-01
    z[1,5,4]  R1245     -1.6071267426013947e-01
    z[1,5,4]  R1246     -1.6083371639251709e-01
    z[1,5,4]  R1247     -3.4067001193761826e-02
    z[1,5,4]  R1248     -5.6334905326366425e-02
    z[1,5,4]  R1249     3.6259177327156067e-01
    z[1,5,4]  R1250     -1.3728362321853638e-01
    z[1,5,4]  R1251     -1.4447632431983948e-01
    z[1,5,4]  R1252     -3.4708479046821594e-01
    z[1,5,4]  R1253     1.3537852466106415e-01
    z[1,5,4]  R1254     0.483398973941803
    z[1,5,4]  R1255     0.0651547759771347
    z[1,5,4]  R1256     8.4052875638008118e-02
    z[1,5,4]  R1257     -3.0271375179290771e-01
    z[1,5,4]  R1258     1.9041784107685089e-01
    z[1,5,4]  R1259     2.8257763385772705e-01
    z[1,5,4]  R1260     -1.8381620943546295e-01
    z[1,5,4]  R1261     0.564232587814331
    z[1,5,4]  R1262     3.5421684384346008e-02
    z[1,5,4]  R1263     1.3294674456119537e-01
    z[1,5,4]  R1264     0.234371617436409
    z[1,5,4]  R1265     0.568893551826477
    z[1,5,4]  R1266     0.133975088596344
    z[1,5,4]  R1267     1.1157119274139404e-01
    z[1,5,4]  R1268     1.0607088357210159e-01
    z[1,5,4]  R1269     3.3143392205238342e-01
    z[1,5,4]  R1270     2.0969532430171967e-01
    z[1,5,4]  R1271     5.9639763832092285e-01
    z[1,5,4]  R1272     3.5192811489105225e-01
    z[1,5,4]  R1273     2.6111885905265808e-01
    z[1,5,4]  R1274     -1.3108791410923004e-01
    z[1,5,4]  R1275     -6.9482550024986267e-02
    z[1,5,4]  R1276     -0.196515291929245
    z[1,5,4]  R1277     -1.0311304032802582e-01
    z[1,5,4]  R1278     -2.6978400349617004e-01
    z[1,5,4]  R1279     -1.9433347880840302e-01
    z[1,5,4]  R1280     -6.5487218089401722e-03
    z[1,5,4]  R1281     -2.4164788424968719e-01
    z[1,5,4]  R1282     -5.3179544210433960e-01
    z[1,5,4]  R1283     -0.715399980545044
    z[1,5,4]  R1284     2.4729570746421814e-01
    z[1,5,4]  R1285     -2.6987606287002563e-01
    z[1,5,4]  R1286     2.1347737312316895e-01
    z[1,5,4]  R1287     6.6397614777088165e-02
    z[1,5,4]  R1288     -0.0682741329073906
    z[1,5,4]  R1289     1.9729943946003914e-02
    z[1,5,4]  R1290     1.2859743833541870e-01
    z[1,5,4]  R1291     3.1697552651166916e-02
    z[1,5,4]  R1292     -4.4534732587635517e-03
    z[1,5,4]  R1293     1.1686767637729645e-01
    z[1,5,4]  R1294     -2.5458750128746033e-01
    z[1,5,4]  R1295     -3.8164101541042328e-02
    z[1,5,5]  R16       -1
    z[1,5,5]  R52       1
    z[1,5,5]  R1234     -1
    z[1,5,5]  R1235     1
    z[1,5,5]  R1238     -0.16961570084095
    z[1,5,5]  R1239     -3.6109413951635361e-02
    z[1,5,5]  R1240     -5.2790228277444839e-02
    z[1,5,5]  R1241     -6.3004577159881592e-01
    z[1,5,5]  R1242     -2.7320614457130432e-01
    z[1,5,5]  R1243     -1.2381795793771744e-01
    z[1,5,5]  R1244     -5.9111952781677246e-01
    z[1,5,5]  R1245     7.3343284428119659e-02
    z[1,5,5]  R1246     -1.9130037724971771e-01
    z[1,5,5]  R1247     -1.9146957993507385e-01
    z[1,5,5]  R1248     4.3890848755836487e-01
    z[1,5,5]  R1249     7.4039161205291748e-01
    z[1,5,5]  R1250     -1.0637371987104416e-01
    z[1,5,5]  R1251     -1.7951239645481110e-01
    z[1,5,5]  R1252     1.9836017489433289e-01
    z[1,5,5]  R1253     -3.6952443420886993e-02
    z[1,5,5]  R1254     -4.4627869129180908e-01
    z[1,5,5]  R1255     -1.9919851422309875e-01
    z[1,5,5]  R1256     -5.9514995664358139e-03
    z[1,5,5]  R1257     4.3356409668922424e-01
    z[1,5,5]  R1258     -5.4642057418823242e-01
    z[1,5,5]  R1259     -1.7104054987430573e-01
    z[1,5,5]  R1260     -2.1577434241771698e-01
    z[1,5,5]  R1261     -9.4331823289394379e-02
    z[1,5,5]  R1262     -2.9091143608093262e-01
    z[1,5,5]  R1263     1.9863104820251465e-01
    z[1,5,5]  R1264     -2.0626686513423920e-02
    z[1,5,5]  R1265     -3.2981079816818237e-01
    z[1,5,5]  R1266     -7.5890876352787018e-02
    z[1,5,5]  R1267     -2.1043565869331360e-01
    z[1,5,5]  R1268     0.0350484624505043
    z[1,5,5]  R1269     -1.2076556682586670e-01
    z[1,5,5]  R1270     -4.7361978888511658e-01
    z[1,5,5]  R1271     -6.5594747662544250e-02
    z[1,5,5]  R1272     2.2551345825195312e-01
    z[1,5,5]  R1273     -1.9245958328247070e-01
    z[1,5,5]  R1274     3.8899150490760803e-01
    z[1,5,5]  R1275     9.7562968730926514e-02
    z[1,5,5]  R1276     3.4499558806419373e-01
    z[1,5,5]  R1277     -1.3019940257072449e-01
    z[1,5,5]  R1278     -8.4242987632751465e-01
    z[1,5,5]  R1279     -4.9546590447425842e-01
    z[1,5,5]  R1280     -1.6400189697742462e-01
    z[1,5,5]  R1281     -5.3578341007232666e-01
    z[1,5,5]  R1282     -1.5329921245574951e-01
    z[1,5,5]  R1283     2.3713913559913635e-01
    z[1,5,5]  R1284     1.9079077243804932e-01
    z[1,5,5]  R1285     3.3418321609497070e-01
    z[1,5,5]  R1286     1.5212121605873108e-01
    z[1,5,5]  R1287     3.3937299251556396e-01
    z[1,5,5]  R1288     4.7862115502357483e-01
    z[1,5,5]  R1289     3.7534487247467041e-01
    z[1,5,5]  R1290     4.4864749908447266e-01
    z[1,5,5]  R1291     2.3144076764583588e-01
    z[1,5,5]  R1292     -4.6014860272407532e-02
    z[1,5,5]  R1293     6.8947292864322662e-02
    z[1,5,5]  R1294     3.8678757846355438e-02
    z[1,5,5]  R1295     2.7021130919456482e-01
    z[1,5,6]  R17       -1
    z[1,5,6]  R53       1
    z[1,5,6]  R1236     -1
    z[1,5,6]  R1237     1
    z[1,5,6]  R1238     -2.4655713140964508e-01
    z[1,5,6]  R1239     -4.1694027185440063e-01
    z[1,5,6]  R1240     -1.7547542229294777e-02
    z[1,5,6]  R1241     -3.0434769392013550e-01
    z[1,5,6]  R1242     -3.6931043863296509e-01
    z[1,5,6]  R1243     -8.2689769566059113e-02
    z[1,5,6]  R1244     2.4606725573539734e-01
    z[1,5,6]  R1245     9.0966427326202393e-01
    z[1,5,6]  R1246     -1.6713818907737732e-01
    z[1,5,6]  R1247     -2.6994574069976807e-01
    z[1,5,6]  R1248     1.7012619972229004e-01
    z[1,5,6]  R1249     -7.5329937040805817e-02
    z[1,5,6]  R1250     5.2180871367454529e-02
    z[1,5,6]  R1251     -4.0868866443634033e-01
    z[1,5,6]  R1252     3.8819864392280579e-01
    z[1,5,6]  R1253     1.3943642377853394e-01
    z[1,5,6]  R1254     3.8652750849723816e-01
    z[1,5,6]  R1255     5.6078654527664185e-01
    z[1,5,6]  R1256     2.5621561333537102e-02
    z[1,5,6]  R1257     -5.8213543891906738e-01
    z[1,5,6]  R1258     -2.3434561491012573e-01
    z[1,5,6]  R1259     -2.3424968123435974e-01
    z[1,5,6]  R1260     1.1174045503139496e-01
    z[1,5,6]  R1261     2.7887317538261414e-01
    z[1,5,6]  R1262     4.8269498348236084e-01
    z[1,5,6]  R1263     -4.0791699290275574e-01
    z[1,5,6]  R1264     3.9846265316009521e-01
    z[1,5,6]  R1265     3.9806911349296570e-01
    z[1,5,6]  R1266     4.9638313055038452e-01
    z[1,5,6]  R1267     1.7675362527370453e-01
    z[1,5,6]  R1268     6.2091845273971558e-01
    z[1,5,6]  R1269     4.9711546301841736e-01
    z[1,5,6]  R1270     7.2336748242378235e-02
    z[1,5,6]  R1271     2.6968801021575928e-01
    z[1,5,6]  R1272     -4.3976327776908875e-01
    z[1,5,6]  R1273     6.4820420742034912e-01
    z[1,5,6]  R1274     -2.0570772886276245e-01
    z[1,5,6]  R1275     -1.6415183246135712e-01
    z[1,5,6]  R1276     -0.0460810661315918
    z[1,5,6]  R1277     9.5752745866775513e-02
    z[1,5,6]  R1278     8.8194563984870911e-02
    z[1,5,6]  R1279     -7.1552854776382446e-01
    z[1,5,6]  R1280     -2.3107738792896271e-01
    z[1,5,6]  R1281     -4.6637782454490662e-01
    z[1,5,6]  R1282     6.1569482088088989e-01
    z[1,5,6]  R1283     1.5540994703769684e-01
    z[1,5,6]  R1284     2.3442228138446808e-01
    z[1,5,6]  R1285     -9.4112023711204529e-02
    z[1,5,6]  R1286     3.0019092559814453e-01
    z[1,5,6]  R1287     -0.0115215377882123
    z[1,5,6]  R1288     -1.6581559181213379e-01
    z[1,5,6]  R1289     -4.2370134592056274e-01
    z[1,5,6]  R1290     1.5776583552360535e-01
    z[1,5,6]  R1291     -1.3237112760543823e-01
    z[1,5,6]  R1292     1.8176500499248505e-01
    z[1,5,6]  R1293     1.4365004003047943e-01
    z[1,5,6]  R1294     7.5863234698772430e-02
    z[1,5,6]  R1295     3.0158379673957825e-01
    z[5,1,0]  R11       1
    z[5,1,0]  R47       -1
    z[5,1,0]  R1296     -1
    z[5,1,0]  R1297     1
    z[5,1,0]  R1310     2.7077559381723404e-02
    z[5,1,0]  R1311     -1.4716574549674988e-01
    z[5,1,0]  R1312     6.6157186031341553e-01
    z[5,1,0]  R1313     3.2766574621200562e-01
    z[5,1,0]  R1314     3.5326221585273743e-01
    z[5,1,0]  R1315     -4.8980057239532471e-02
    z[5,1,0]  R1316     4.2251950502395630e-01
    z[5,1,0]  R1317     -7.9604452848434448e-01
    z[5,1,0]  R1318     3.9534687995910645e-01
    z[5,1,0]  R1319     -4.4654479622840881e-01
    z[5,1,0]  R1320     -1.4632028341293335e-01
    z[5,1,0]  R1321     -0.420944482088089
    z[5,1,0]  R1322     -2.4442516267299652e-01
    z[5,1,0]  R1323     -9.0486049652099609e-01
    z[5,1,0]  R1324     -8.8210612535476685e-01
    z[5,1,0]  R1325     -8.8734483718872070e-01
    z[5,1,0]  R1326     -0.904356837272644
    z[5,1,0]  R1327     -8.9519476890563965e-01
    z[5,1,0]  R1328     7.4860262870788574e-01
    z[5,1,0]  R1329     3.6833679676055908e-01
    z[5,1,0]  R1330     -2.2596074640750885e-01
    z[5,1,0]  R1331     -3.0306759476661682e-01
    z[5,1,0]  R1332     -1.4573006331920624e-01
    z[5,1,0]  R1333     -0.50286865234375
    z[5,1,0]  R1334     -8.5654549300670624e-02
    z[5,1,0]  R1335     1.5423680841922760e-01
    z[5,1,0]  R1336     -3.0090352892875671e-01
    z[5,1,0]  R1337     -3.6334908008575439e-01
    z[5,1,0]  R1338     -3.2288312911987305e-01
    z[5,1,0]  R1339     4.0381222963333130e-01
    z[5,1,0]  R1340     -8.3608108758926392e-01
    z[5,1,0]  R1341     -5.0338220596313477e-01
    z[5,1,0]  R1342     -6.4310878515243530e-01
    z[5,1,0]  R1343     6.7158448696136475e-01
    z[5,1,0]  R1344     -2.9885500669479370e-01
    z[5,1,0]  R1345     -6.3888782262802124e-01
    z[5,1,0]  R1346     3.1097555160522461e-01
    z[5,1,0]  R1347     -5.0072693824768066e-01
    z[5,1,0]  R1348     -1.9979985058307648e-01
    z[5,1,0]  R1349     -5.3643178939819336e-01
    z[5,1,0]  R1350     0.607283890247345
    z[5,1,0]  R1351     -7.1195596456527710e-01
    z[5,1,0]  R1352     -6.0410439968109131e-01
    z[5,1,0]  R1353     -8.3872246742248535e-01
    z[5,1,0]  R1354     -4.6909371018409729e-01
    z[5,1,0]  R1355     6.2660795450210571e-01
    z[5,1,0]  R1356     -3.5793432593345642e-01
    z[5,1,0]  R1357     4.1159999370574951e-01
    z[5,1,0]  R1358     7.6862829923629761e-01
    z[5,1,0]  R1359     7.8859555721282959e-01
    z[5,1,0]  R1360     0.763009250164032
    z[5,1,0]  R1361     -7.1807646751403809e-01
    z[5,1,0]  R1362     5.9774047136306763e-01
    z[5,1,0]  R1363     -1.5244425833225250e-01
    z[5,1,0]  R1364     7.3239183425903320e-01
    z[5,1,0]  R1365     2.9017889499664307e-01
    z[5,1,0]  R1366     2.7914133667945862e-01
    z[5,1,0]  R1367     -4.0742442011833191e-02
    z[5,1,1]  R12       1
    z[5,1,1]  R48       -1
    z[5,1,1]  R1298     -1
    z[5,1,1]  R1299     1
    z[5,1,1]  R1310     2.1032528579235077e-01
    z[5,1,1]  R1311     1.4855297282338142e-02
    z[5,1,1]  R1312     -4.6718326210975647e-01
    z[5,1,1]  R1313     4.1429869830608368e-02
    z[5,1,1]  R1314     -1.5066677331924438e-01
    z[5,1,1]  R1315     3.8200950622558594e-01
    z[5,1,1]  R1316     -5.6179088354110718e-01
    z[5,1,1]  R1317     -2.5091665983200073e-01
    z[5,1,1]  R1318     0.735697329044342
    z[5,1,1]  R1319     5.1107460260391235e-01
    z[5,1,1]  R1320     3.1154605746269226e-01
    z[5,1,1]  R1321     4.4397643208503723e-01
    z[5,1,1]  R1322     -2.0141474902629852e-01
    z[5,1,1]  R1323     -1.1928041279315948e-01
    z[5,1,1]  R1324     1.0443801991641521e-02
    z[5,1,1]  R1325     -1.9972890615463257e-01
    z[5,1,1]  R1326     -2.3908819258213043e-01
    z[5,1,1]  R1327     -0.086459219455719
    z[5,1,1]  R1328     3.9658987522125244e-01
    z[5,1,1]  R1329     3.3228096365928650e-01
    z[5,1,1]  R1330     2.4429461359977722e-01
    z[5,1,1]  R1331     4.4257181882858276e-01
    z[5,1,1]  R1332     2.6678934693336487e-01
    z[5,1,1]  R1333     2.8248181939125061e-01
    z[5,1,1]  R1334     3.1439480185508728e-01
    z[5,1,1]  R1335     3.0521667003631592e-01
    z[5,1,1]  R1336     2.9148623347282410e-01
    z[5,1,1]  R1337     4.8344865441322327e-01
    z[5,1,1]  R1338     7.9831188917160034e-01
    z[5,1,1]  R1339     3.5552966594696045e-01
    z[5,1,1]  R1340     -5.0519472360610962e-01
    z[5,1,1]  R1341     -7.0010378956794739e-02
    z[5,1,1]  R1342     -3.7174528837203979e-01
    z[5,1,1]  R1343     -5.6620782613754272e-01
    z[5,1,1]  R1344     3.1890600919723511e-01
    z[5,1,1]  R1345     -9.6032015979290009e-02
    z[5,1,1]  R1346     -8.3104193210601807e-01
    z[5,1,1]  R1347     -2.6378947496414185e-01
    z[5,1,1]  R1348     7.5350910425186157e-01
    z[5,1,1]  R1349     1.5285126864910126e-01
    z[5,1,1]  R1350     2.2692620754241943e-02
    z[5,1,1]  R1351     -1.4521090686321259e-01
    z[5,1,1]  R1352     -9.3496374785900116e-02
    z[5,1,1]  R1353     -4.4312536716461182e-02
    z[5,1,1]  R1354     -9.4921454787254333e-02
    z[5,1,1]  R1355     -4.1695181280374527e-02
    z[5,1,1]  R1356     -2.3240816593170166e-01
    z[5,1,1]  R1357     -0.521371066570282
    z[5,1,1]  R1358     5.1249540410935879e-03
    z[5,1,1]  R1359     -5.0348155200481415e-02
    z[5,1,1]  R1360     -1.5467119216918945e-01
    z[5,1,1]  R1361     1.0522312484681606e-02
    z[5,1,1]  R1362     -3.1535571813583374e-01
    z[5,1,1]  R1363     2.9513699933886528e-02
    z[5,1,1]  R1364     -3.4852899610996246e-02
    z[5,1,1]  R1365     -4.8090791702270508e-01
    z[5,1,1]  R1366     -4.9988901615142822e-01
    z[5,1,1]  R1367     -6.3789361715316772e-01
    z[5,1,2]  R13       1
    z[5,1,2]  R49       -1
    z[5,1,2]  R1300     -1
    z[5,1,2]  R1301     1
    z[5,1,2]  R1310     -3.7991592288017273e-01
    z[5,1,2]  R1311     -2.9864221811294556e-01
    z[5,1,2]  R1312     2.2859716415405273e-01
    z[5,1,2]  R1313     5.4286282509565353e-02
    z[5,1,2]  R1314     3.1203457713127136e-01
    z[5,1,2]  R1315     3.1310686469078064e-01
    z[5,1,2]  R1316     -2.7816560864448547e-01
    z[5,1,2]  R1317     2.3640289902687073e-01
    z[5,1,2]  R1318     -2.6094261556863785e-02
    z[5,1,2]  R1319     1.8322923779487610e-01
    z[5,1,2]  R1320     5.8794164657592773e-01
    z[5,1,2]  R1321     4.9670797586441040e-01
    z[5,1,2]  R1322     -4.6606090664863586e-01
    z[5,1,2]  R1323     -4.8526491969823837e-02
    z[5,1,2]  R1324     -1.6023044288158417e-01
    z[5,1,2]  R1325     -1.6508170962333679e-01
    z[5,1,2]  R1326     3.1460151076316833e-02
    z[5,1,2]  R1327     -3.8388580083847046e-02
    z[5,1,2]  R1328     1.2885268032550812e-01
    z[5,1,2]  R1329     1.4797152578830719e-01
    z[5,1,2]  R1330     7.6367869973182678e-02
    z[5,1,2]  R1331     1.0282432287931442e-01
    z[5,1,2]  R1332     4.6960480511188507e-02
    z[5,1,2]  R1333     -1.8596945703029633e-01
    z[5,1,2]  R1334     1.6917736828327179e-01
    z[5,1,2]  R1335     1.0263492166996002e-01
    z[5,1,2]  R1336     -1.2520714104175568e-01
    z[5,1,2]  R1337     0.291836678981781
    z[5,1,2]  R1338     0.0642719641327858
    z[5,1,2]  R1339     -6.8011187016963959e-02
    z[5,1,2]  R1340     -1.1339828372001648e-01
    z[5,1,2]  R1341     -7.1803522109985352e-01
    z[5,1,2]  R1342     -9.6472300589084625e-02
    z[5,1,2]  R1343     8.3359532058238983e-02
    z[5,1,2]  R1344     4.7368472814559937e-01
    z[5,1,2]  R1345     -1.4865960180759430e-01
    z[5,1,2]  R1346     -3.7821326404809952e-03
    z[5,1,2]  R1347     -9.9031753838062286e-02
    z[5,1,2]  R1348     3.6033112555742264e-02
    z[5,1,2]  R1349     4.8918455839157104e-01
    z[5,1,2]  R1350     2.5622749328613281e-01
    z[5,1,2]  R1351     1.3521020114421844e-01
    z[5,1,2]  R1352     4.4283643364906311e-01
    z[5,1,2]  R1353     -1.9770139455795288e-01
    z[5,1,2]  R1354     7.4132215976715088e-01
    z[5,1,2]  R1355     2.6134006679058075e-02
    z[5,1,2]  R1356     2.2976528108119965e-01
    z[5,1,2]  R1357     2.9996795579791069e-02
    z[5,1,2]  R1358     1.0451861470937729e-01
    z[5,1,2]  R1359     5.2703902125358582e-02
    z[5,1,2]  R1360     1.2970089912414551e-01
    z[5,1,2]  R1361     -1.4823801815509796e-01
    z[5,1,2]  R1362     7.5197708792984486e-03
    z[5,1,2]  R1363     3.6111307144165039e-01
    z[5,1,2]  R1364     1.5699344873428345e-01
    z[5,1,2]  R1365     7.2317175567150116e-02
    z[5,1,2]  R1366     2.7384883165359497e-01
    z[5,1,2]  R1367     4.4822001457214355e-01
    z[5,1,3]  R14       1
    z[5,1,3]  R50       -1
    z[5,1,3]  R1302     -1
    z[5,1,3]  R1303     1
    z[5,1,3]  R1310     1.4298340678215027e-01
    z[5,1,3]  R1311     3.0610656738281250e-01
    z[5,1,3]  R1312     -4.5985820889472961e-01
    z[5,1,3]  R1313     -5.7009279727935791e-01
    z[5,1,3]  R1314     -2.6410719752311707e-01
    z[5,1,3]  R1315     4.0180769562721252e-01
    z[5,1,3]  R1316     5.2533990144729614e-01
    z[5,1,3]  R1317     -2.3259180784225464e-01
    z[5,1,3]  R1318     3.7807571887969971e-01
    z[5,1,3]  R1319     -6.2137925624847412e-01
    z[5,1,3]  R1320     -5.2404171228408813e-01
    z[5,1,3]  R1321     -2.4119694530963898e-01
    z[5,1,3]  R1322     -6.6314691305160522e-01
    z[5,1,3]  R1323     -3.0422553420066833e-01
    z[5,1,3]  R1324     -4.0116128325462341e-01
    z[5,1,3]  R1325     -3.2623365521430969e-01
    z[5,1,3]  R1326     -2.2785899043083191e-01
    z[5,1,3]  R1327     -1.5573722124099731e-01
    z[5,1,3]  R1328     3.0141115188598633e-01
    z[5,1,3]  R1329     2.4837906658649445e-01
    z[5,1,3]  R1330     4.5430219173431396e-01
    z[5,1,3]  R1331     1.1281071603298187e-01
    z[5,1,3]  R1332     -6.9318228960037231e-01
    z[5,1,3]  R1333     7.7586674690246582e-01
    z[5,1,3]  R1334     1.8007653951644897e-01
    z[5,1,3]  R1335     1.1757089197635651e-01
    z[5,1,3]  R1336     8.4759509563446045e-01
    z[5,1,3]  R1337     -0.662113606929779
    z[5,1,3]  R1338     -1.7191989719867706e-01
    z[5,1,3]  R1339     1.4346306025981903e-01
    z[5,1,3]  R1340     -1.5986124053597450e-03
    z[5,1,3]  R1341     -7.7496804296970367e-02
    z[5,1,3]  R1342     -3.5832509398460388e-01
    z[5,1,3]  R1343     -4.2696484923362732e-01
    z[5,1,3]  R1344     -4.8628427088260651e-02
    z[5,1,3]  R1345     -4.4954848289489746e-01
    z[5,1,3]  R1346     4.5265042781829834e-01
    z[5,1,3]  R1347     -2.2668300569057465e-01
    z[5,1,3]  R1348     3.5406373441219330e-02
    z[5,1,3]  R1349     -5.3441369533538818e-01
    z[5,1,3]  R1350     -6.8717229366302490e-01
    z[5,1,3]  R1351     -2.2073395550251007e-01
    z[5,1,3]  R1352     -3.3366686105728149e-01
    z[5,1,3]  R1353     1.7880079150199890e-01
    z[5,1,3]  R1354     -8.5172258317470551e-02
    z[5,1,3]  R1355     -1.1860412359237671e-01
    z[5,1,3]  R1356     -7.0354276895523071e-01
    z[5,1,3]  R1357     6.8548142910003662e-01
    z[5,1,3]  R1358     -1.5521142631769180e-02
    z[5,1,3]  R1359     3.5324998199939728e-02
    z[5,1,3]  R1360     -3.2179304957389832e-01
    z[5,1,3]  R1361     -1.7192016541957855e-01
    z[5,1,3]  R1362     -4.1844853758811951e-01
    z[5,1,3]  R1363     -5.6576901674270630e-01
    z[5,1,3]  R1364     -4.7636792063713074e-01
    z[5,1,3]  R1365     7.9875022172927856e-01
    z[5,1,3]  R1366     0.661388099193573
    z[5,1,3]  R1367     5.9479230642318726e-01
    z[5,1,4]  R15       1
    z[5,1,4]  R51       -1
    z[5,1,4]  R1304     -1
    z[5,1,4]  R1305     1
    z[5,1,4]  R1310     -2.6978400349617004e-01
    z[5,1,4]  R1311     -1.9433347880840302e-01
    z[5,1,4]  R1312     -6.5487218089401722e-03
    z[5,1,4]  R1313     -2.4164788424968719e-01
    z[5,1,4]  R1314     -5.3179544210433960e-01
    z[5,1,4]  R1315     -0.715399980545044
    z[5,1,4]  R1316     2.4729570746421814e-01
    z[5,1,4]  R1317     -2.6987606287002563e-01
    z[5,1,4]  R1318     2.1347737312316895e-01
    z[5,1,4]  R1319     6.6397614777088165e-02
    z[5,1,4]  R1320     -0.0682741329073906
    z[5,1,4]  R1321     1.9729943946003914e-02
    z[5,1,4]  R1322     1.2859743833541870e-01
    z[5,1,4]  R1323     3.1697552651166916e-02
    z[5,1,4]  R1324     -4.4534732587635517e-03
    z[5,1,4]  R1325     1.1686767637729645e-01
    z[5,1,4]  R1326     -2.5458750128746033e-01
    z[5,1,4]  R1327     -3.8164101541042328e-02
    z[5,1,4]  R1328     -2.9206001758575439e-01
    z[5,1,4]  R1329     -7.0369493961334229e-01
    z[5,1,4]  R1330     -8.2094132900238037e-01
    z[5,1,4]  R1331     -4.4653770327568054e-01
    z[5,1,4]  R1332     4.6243643760681152e-01
    z[5,1,4]  R1333     9.2762112617492676e-02
    z[5,1,4]  R1334     -6.5023016929626465e-01
    z[5,1,4]  R1335     -1.6071267426013947e-01
    z[5,1,4]  R1336     -1.6083371639251709e-01
    z[5,1,4]  R1337     -3.4067001193761826e-02
    z[5,1,4]  R1338     -5.6334905326366425e-02
    z[5,1,4]  R1339     3.6259177327156067e-01
    z[5,1,4]  R1340     -1.3728362321853638e-01
    z[5,1,4]  R1341     -1.4447632431983948e-01
    z[5,1,4]  R1342     -3.4708479046821594e-01
    z[5,1,4]  R1343     1.3537852466106415e-01
    z[5,1,4]  R1344     0.483398973941803
    z[5,1,4]  R1345     0.0651547759771347
    z[5,1,4]  R1346     8.4052875638008118e-02
    z[5,1,4]  R1347     -3.0271375179290771e-01
    z[5,1,4]  R1348     1.9041784107685089e-01
    z[5,1,4]  R1349     2.8257763385772705e-01
    z[5,1,4]  R1350     -1.8381620943546295e-01
    z[5,1,4]  R1351     0.564232587814331
    z[5,1,4]  R1352     3.5421684384346008e-02
    z[5,1,4]  R1353     1.3294674456119537e-01
    z[5,1,4]  R1354     0.234371617436409
    z[5,1,4]  R1355     0.568893551826477
    z[5,1,4]  R1356     0.133975088596344
    z[5,1,4]  R1357     1.1157119274139404e-01
    z[5,1,4]  R1358     1.0607088357210159e-01
    z[5,1,4]  R1359     3.3143392205238342e-01
    z[5,1,4]  R1360     2.0969532430171967e-01
    z[5,1,4]  R1361     5.9639763832092285e-01
    z[5,1,4]  R1362     3.5192811489105225e-01
    z[5,1,4]  R1363     2.6111885905265808e-01
    z[5,1,4]  R1364     -1.3108791410923004e-01
    z[5,1,4]  R1365     -6.9482550024986267e-02
    z[5,1,4]  R1366     -0.196515291929245
    z[5,1,4]  R1367     -1.0311304032802582e-01
    z[5,1,5]  R16       1
    z[5,1,5]  R52       -1
    z[5,1,5]  R1306     -1
    z[5,1,5]  R1307     1
    z[5,1,5]  R1310     -8.4242987632751465e-01
    z[5,1,5]  R1311     -4.9546590447425842e-01
    z[5,1,5]  R1312     -1.6400189697742462e-01
    z[5,1,5]  R1313     -5.3578341007232666e-01
    z[5,1,5]  R1314     -1.5329921245574951e-01
    z[5,1,5]  R1315     2.3713913559913635e-01
    z[5,1,5]  R1316     1.9079077243804932e-01
    z[5,1,5]  R1317     3.3418321609497070e-01
    z[5,1,5]  R1318     1.5212121605873108e-01
    z[5,1,5]  R1319     3.3937299251556396e-01
    z[5,1,5]  R1320     4.7862115502357483e-01
    z[5,1,5]  R1321     3.7534487247467041e-01
    z[5,1,5]  R1322     4.4864749908447266e-01
    z[5,1,5]  R1323     2.3144076764583588e-01
    z[5,1,5]  R1324     -4.6014860272407532e-02
    z[5,1,5]  R1325     6.8947292864322662e-02
    z[5,1,5]  R1326     3.8678757846355438e-02
    z[5,1,5]  R1327     2.7021130919456482e-01
    z[5,1,5]  R1328     -0.16961570084095
    z[5,1,5]  R1329     -3.6109413951635361e-02
    z[5,1,5]  R1330     -5.2790228277444839e-02
    z[5,1,5]  R1331     -6.3004577159881592e-01
    z[5,1,5]  R1332     -2.7320614457130432e-01
    z[5,1,5]  R1333     -1.2381795793771744e-01
    z[5,1,5]  R1334     -5.9111952781677246e-01
    z[5,1,5]  R1335     7.3343284428119659e-02
    z[5,1,5]  R1336     -1.9130037724971771e-01
    z[5,1,5]  R1337     -1.9146957993507385e-01
    z[5,1,5]  R1338     4.3890848755836487e-01
    z[5,1,5]  R1339     7.4039161205291748e-01
    z[5,1,5]  R1340     -1.0637371987104416e-01
    z[5,1,5]  R1341     -1.7951239645481110e-01
    z[5,1,5]  R1342     1.9836017489433289e-01
    z[5,1,5]  R1343     -3.6952443420886993e-02
    z[5,1,5]  R1344     -4.4627869129180908e-01
    z[5,1,5]  R1345     -1.9919851422309875e-01
    z[5,1,5]  R1346     -5.9514995664358139e-03
    z[5,1,5]  R1347     4.3356409668922424e-01
    z[5,1,5]  R1348     -5.4642057418823242e-01
    z[5,1,5]  R1349     -1.7104054987430573e-01
    z[5,1,5]  R1350     -2.1577434241771698e-01
    z[5,1,5]  R1351     -9.4331823289394379e-02
    z[5,1,5]  R1352     -2.9091143608093262e-01
    z[5,1,5]  R1353     1.9863104820251465e-01
    z[5,1,5]  R1354     -2.0626686513423920e-02
    z[5,1,5]  R1355     -3.2981079816818237e-01
    z[5,1,5]  R1356     -7.5890876352787018e-02
    z[5,1,5]  R1357     -2.1043565869331360e-01
    z[5,1,5]  R1358     0.0350484624505043
    z[5,1,5]  R1359     -1.2076556682586670e-01
    z[5,1,5]  R1360     -4.7361978888511658e-01
    z[5,1,5]  R1361     -6.5594747662544250e-02
    z[5,1,5]  R1362     2.2551345825195312e-01
    z[5,1,5]  R1363     -1.9245958328247070e-01
    z[5,1,5]  R1364     3.8899150490760803e-01
    z[5,1,5]  R1365     9.7562968730926514e-02
    z[5,1,5]  R1366     3.4499558806419373e-01
    z[5,1,5]  R1367     -1.3019940257072449e-01
    z[5,1,6]  R17       1
    z[5,1,6]  R53       -1
    z[5,1,6]  R1308     -1
    z[5,1,6]  R1309     1
    z[5,1,6]  R1310     8.8194563984870911e-02
    z[5,1,6]  R1311     -7.1552854776382446e-01
    z[5,1,6]  R1312     -2.3107738792896271e-01
    z[5,1,6]  R1313     -4.6637782454490662e-01
    z[5,1,6]  R1314     6.1569482088088989e-01
    z[5,1,6]  R1315     1.5540994703769684e-01
    z[5,1,6]  R1316     2.3442228138446808e-01
    z[5,1,6]  R1317     -9.4112023711204529e-02
    z[5,1,6]  R1318     3.0019092559814453e-01
    z[5,1,6]  R1319     -0.0115215377882123
    z[5,1,6]  R1320     -1.6581559181213379e-01
    z[5,1,6]  R1321     -4.2370134592056274e-01
    z[5,1,6]  R1322     1.5776583552360535e-01
    z[5,1,6]  R1323     -1.3237112760543823e-01
    z[5,1,6]  R1324     1.8176500499248505e-01
    z[5,1,6]  R1325     1.4365004003047943e-01
    z[5,1,6]  R1326     7.5863234698772430e-02
    z[5,1,6]  R1327     3.0158379673957825e-01
    z[5,1,6]  R1328     -2.4655713140964508e-01
    z[5,1,6]  R1329     -4.1694027185440063e-01
    z[5,1,6]  R1330     -1.7547542229294777e-02
    z[5,1,6]  R1331     -3.0434769392013550e-01
    z[5,1,6]  R1332     -3.6931043863296509e-01
    z[5,1,6]  R1333     -8.2689769566059113e-02
    z[5,1,6]  R1334     2.4606725573539734e-01
    z[5,1,6]  R1335     9.0966427326202393e-01
    z[5,1,6]  R1336     -1.6713818907737732e-01
    z[5,1,6]  R1337     -2.6994574069976807e-01
    z[5,1,6]  R1338     1.7012619972229004e-01
    z[5,1,6]  R1339     -7.5329937040805817e-02
    z[5,1,6]  R1340     5.2180871367454529e-02
    z[5,1,6]  R1341     -4.0868866443634033e-01
    z[5,1,6]  R1342     3.8819864392280579e-01
    z[5,1,6]  R1343     1.3943642377853394e-01
    z[5,1,6]  R1344     3.8652750849723816e-01
    z[5,1,6]  R1345     5.6078654527664185e-01
    z[5,1,6]  R1346     2.5621561333537102e-02
    z[5,1,6]  R1347     -5.8213543891906738e-01
    z[5,1,6]  R1348     -2.3434561491012573e-01
    z[5,1,6]  R1349     -2.3424968123435974e-01
    z[5,1,6]  R1350     1.1174045503139496e-01
    z[5,1,6]  R1351     2.7887317538261414e-01
    z[5,1,6]  R1352     4.8269498348236084e-01
    z[5,1,6]  R1353     -4.0791699290275574e-01
    z[5,1,6]  R1354     3.9846265316009521e-01
    z[5,1,6]  R1355     3.9806911349296570e-01
    z[5,1,6]  R1356     4.9638313055038452e-01
    z[5,1,6]  R1357     1.7675362527370453e-01
    z[5,1,6]  R1358     6.2091845273971558e-01
    z[5,1,6]  R1359     4.9711546301841736e-01
    z[5,1,6]  R1360     7.2336748242378235e-02
    z[5,1,6]  R1361     2.6968801021575928e-01
    z[5,1,6]  R1362     -4.3976327776908875e-01
    z[5,1,6]  R1363     6.4820420742034912e-01
    z[5,1,6]  R1364     -2.0570772886276245e-01
    z[5,1,6]  R1365     -1.6415183246135712e-01
    z[5,1,6]  R1366     -0.0460810661315918
    z[5,1,6]  R1367     9.5752745866775513e-02
    z[2,3,0]  R20       -1
    z[2,3,0]  R29       1
    z[2,3,0]  R1368     -1
    z[2,3,0]  R1369     1
    z[2,3,0]  R1382     5.1106750965118408e-02
    z[2,3,0]  R1383     5.9056133031845093e-01
    z[2,3,0]  R1384     3.8707137107849121e-01
    z[2,3,0]  R1385     4.8208811879158020e-01
    z[2,3,0]  R1386     3.9119637012481689e-01
    z[2,3,0]  R1387     1.4780405163764954e-01
    z[2,3,0]  R1388     3.7821340560913086e-01
    z[2,3,0]  R1389     3.1116208434104919e-01
    z[2,3,0]  R1390     -7.1673743426799774e-02
    z[2,3,0]  R1391     1.2954111397266388e-01
    z[2,3,0]  R1392     -8.0445349216461182e-01
    z[2,3,0]  R1393     -9.1631394624710083e-01
    z[2,3,0]  R1394     -7.8195226192474365e-01
    z[2,3,0]  R1395     -7.6881724596023560e-01
    z[2,3,0]  R1396     -8.5561519861221313e-01
    z[2,3,0]  R1397     -6.1567348241806030e-01
    z[2,3,0]  R1398     -6.8078100681304932e-01
    z[2,3,0]  R1399     -8.9947152137756348e-01
    z[2,3,0]  R1400     -5.7025265693664551e-01
    z[2,3,0]  R1401     -9.3417984247207642e-01
    z[2,3,0]  R1402     2.1477112174034119e-01
    z[2,3,0]  R1403     -3.8141974806785583e-01
    z[2,3,0]  R1404     -2.7105388045310974e-01
    z[2,3,0]  R1405     -5.6051395833492279e-02
    z[2,3,0]  R1406     -1.5068499743938446e-01
    z[2,3,0]  R1407     -3.0338394641876221e-01
    z[2,3,0]  R1408     -2.7596482634544373e-01
    z[2,3,0]  R1409     2.4456791579723358e-01
    z[2,3,0]  R1410     -1.6306860744953156e-01
    z[2,3,0]  R1411     -1.7163069546222687e-01
    z[2,3,0]  R1412     -1.7435763031244278e-02
    z[2,3,0]  R1413     -7.4469387531280518e-02
    z[2,3,0]  R1414     4.6104887127876282e-01
    z[2,3,0]  R1415     -1.5043017454445362e-02
    z[2,3,0]  R1416     1.4565181732177734e-01
    z[2,3,0]  R1417     4.1971042752265930e-01
    z[2,3,0]  R1418     2.8397732973098755e-01
    z[2,3,0]  R1419     3.6843919754028320e-01
    z[2,3,0]  R1420     2.2394387423992157e-01
    z[2,3,0]  R1421     -2.4747861921787262e-01
    z[2,3,0]  R1422     4.6400707960128784e-01
    z[2,3,0]  R1423     3.8031637668609619e-01
    z[2,3,0]  R1424     -1.2748220562934875e-01
    z[2,3,0]  R1425     1.2794123589992523e-01
    z[2,3,0]  R1426     -0.0471976064145565
    z[2,3,0]  R1427     3.4939879179000854e-01
    z[2,3,0]  R1428     2.6777082681655884e-01
    z[2,3,0]  R1429     2.1898530423641205e-01
    z[2,3,0]  R1430     -7.4936193227767944e-01
    z[2,3,0]  R1431     4.3602046370506287e-01
    z[2,3,0]  R1432     2.5317353010177612e-01
    z[2,3,0]  R1433     -1.3065354526042938e-01
    z[2,3,0]  R1434     -2.0609799027442932e-01
    z[2,3,0]  R1435     4.5509546995162964e-01
    z[2,3,0]  R1436     5.4032748937606812e-01
    z[2,3,0]  R1437     -2.6457160711288452e-02
    z[2,3,0]  R1438     5.5485457181930542e-01
    z[2,3,0]  R1439     3.8495638966560364e-01
    z[2,3,0]  R1440     2.2407768666744232e-01
    z[2,3,0]  R1441     1.2110158801078796e-01
    z[2,3,0]  R1442     -1.7774407565593719e-01
    z[2,3,0]  R1443     -1.3188990950584412e-01
    z[2,3,0]  R1444     4.3774825334548950e-01
    z[2,3,0]  R1445     5.7331051677465439e-02
    z[2,3,0]  R1446     2.8909498453140259e-01
    z[2,3,0]  R1447     2.2211559116840363e-01
    z[2,3,0]  R1448     -8.4896892309188843e-01
    z[2,3,0]  R1449     -9.0700966119766235e-01
    z[2,3,0]  R1450     -6.8083697557449341e-01
    z[2,3,0]  R1451     -7.2370398044586182e-01
    z[2,3,0]  R1452     -4.6666866540908813e-01
    z[2,3,0]  R1453     -4.8101916909217834e-01
    z[2,3,0]  R1454     3.6464604735374451e-01
    z[2,3,0]  R1455     -1.2343242764472961e-01
    z[2,3,0]  R1456     2.0137287676334381e-01
    z[2,3,0]  R1457     -6.6487483680248260e-02
    z[2,3,0]  R1458     2.2912968695163727e-01
    z[2,3,0]  R1459     7.0204377174377441e-01
    z[2,3,0]  R1460     4.2641815543174744e-01
    z[2,3,0]  R1461     4.2145749926567078e-01
    z[2,3,0]  R1462     -1.7454244196414948e-01
    z[2,3,0]  R1463     -2.9542219638824463e-01
    z[2,3,0]  R1464     1.9577080011367798e-01
    z[2,3,0]  R1465     2.2097186744213104e-01
    z[2,3,0]  R1466     -9.4610609114170074e-02
    z[2,3,0]  R1467     1.8257792294025421e-01
    z[2,3,0]  R1468     2.8745627403259277e-01
    z[2,3,0]  R1469     2.7835810184478760e-01
    z[2,3,0]  R1470     4.2069977521896362e-01
    z[2,3,0]  R1471     3.8969895243644714e-01
    z[2,3,0]  R1472     1.0651419311761856e-01
    z[2,3,0]  R1473     -4.2810398340225220e-01
    z[2,3,0]  R1474     -4.7908496856689453e-01
    z[2,3,0]  R1475     -3.6253309249877930e-01
    z[2,3,0]  R1476     -3.5436081886291504e-01
    z[2,3,0]  R1477     -2.2043451666831970e-01
    z[2,3,0]  R1478     -4.7179442644119263e-01
    z[2,3,0]  R1479     -2.6763233542442322e-01
    z[2,3,0]  R1480     -2.1600507199764252e-02
    z[2,3,0]  R1481     1.0049605742096901e-02
    z[2,3,0]  R1482     -4.8620569705963135e-01
    z[2,3,0]  R1483     -3.5388594865798950e-01
    z[2,3,0]  R1484     1.8312826752662659e-01
    z[2,3,0]  R1485     6.4531099796295166e-01
    z[2,3,0]  R1486     4.6570557355880737e-01
    z[2,3,0]  R1487     -5.4465222358703613e-01
    z[2,3,0]  R1488     -5.0433743000030518e-01
    z[2,3,0]  R1489     -0.31179279088974
    z[2,3,0]  R1490     -3.4698817133903503e-01
    z[2,3,0]  R1491     -6.0455256700515747e-01
    z[2,3,0]  R1492     -6.4668697118759155e-01
    z[2,3,0]  R1493     1.3400086760520935e-01
    z[2,3,0]  R1494     3.2247900962829590e-02
    z[2,3,0]  R1495     -0.482546329498291
    z[2,3,0]  R1496     2.4447478353977203e-01
    z[2,3,0]  R1497     -6.1319309473037720e-01
    z[2,3,0]  R1498     -5.8756017684936523e-01
    z[2,3,0]  R1499     2.8414359688758850e-01
    z[2,3,0]  R1500     7.3682749271392822e-01
    z[2,3,0]  R1501     6.2679886817932129e-01
    z[2,3,1]  R21       -1
    z[2,3,1]  R30       1
    z[2,3,1]  R1370     -1
    z[2,3,1]  R1371     1
    z[2,3,1]  R1382     2.6183715462684631e-01
    z[2,3,1]  R1383     1.2515960633754730e-01
    z[2,3,1]  R1384     1.2852229177951813e-01
    z[2,3,1]  R1385     1.3192021846771240e-01
    z[2,3,1]  R1386     1.3427737355232239e-01
    z[2,3,1]  R1387     2.9381850361824036e-01
    z[2,3,1]  R1388     2.6272362470626831e-01
    z[2,3,1]  R1389     2.7838566899299622e-01
    z[2,3,1]  R1390     0.0289725624024868
    z[2,3,1]  R1391     1.6979511082172394e-01
    z[2,3,1]  R1392     -1.5205812454223633e-01
    z[2,3,1]  R1393     -7.9524502158164978e-02
    z[2,3,1]  R1394     -1.6653977334499359e-01
    z[2,3,1]  R1395     1.5908463299274445e-01
    z[2,3,1]  R1396     2.7467915788292885e-02
    z[2,3,1]  R1397     5.4951891303062439e-02
    z[2,3,1]  R1398     -1.2749743461608887e-01
    z[2,3,1]  R1399     2.0110078155994415e-01
    z[2,3,1]  R1400     5.5249649286270142e-01
    z[2,3,1]  R1401     2.2371090948581696e-01
    z[2,3,1]  R1402     6.5280801057815552e-01
    z[2,3,1]  R1403     7.8022551536560059e-01
    z[2,3,1]  R1404     7.9881119728088379e-01
    z[2,3,1]  R1405     7.9810267686843872e-01
    z[2,3,1]  R1406     7.5457632541656494e-01
    z[2,3,1]  R1407     4.2455622553825378e-01
    z[2,3,1]  R1408     0.75604248046875
    z[2,3,1]  R1409     -6.7479032278060913e-01
    z[2,3,1]  R1410     6.9095867872238159e-01
    z[2,3,1]  R1411     6.1447185277938843e-01
    z[2,3,1]  R1412     8.6421352624893188e-01
    z[2,3,1]  R1413     4.7324925661087036e-01
    z[2,3,1]  R1414     2.4629727005958557e-01
    z[2,3,1]  R1415     7.4058568477630615e-01
    z[2,3,1]  R1416     4.1735228896141052e-01
    z[2,3,1]  R1417     6.4956108108162880e-03
    z[2,3,1]  R1418     5.5962300300598145e-01
    z[2,3,1]  R1419     3.7149465084075928e-01
    z[2,3,1]  R1420     1.1038370430469513e-01
    z[2,3,1]  R1421     1.7028903961181641e-01
    z[2,3,1]  R1422     2.2072924673557281e-01
    z[2,3,1]  R1423     -3.6806592345237732e-01
    z[2,3,1]  R1424     3.4903371334075928e-01
    z[2,3,1]  R1425     1.3836197555065155e-01
    z[2,3,1]  R1426     2.5078263878822327e-01
    z[2,3,1]  R1427     -2.9295665025711060e-01
    z[2,3,1]  R1428     7.8041791915893555e-02
    z[2,3,1]  R1429     -1.7975407838821411e-01
    z[2,3,1]  R1430     6.8886220455169678e-02
    z[2,3,1]  R1431     -5.4082065820693970e-01
    z[2,3,1]  R1432     5.5137449502944946e-01
    z[2,3,1]  R1433     6.7315852642059326e-01
    z[2,3,1]  R1434     0.659210205078125
    z[2,3,1]  R1435     -5.2719074487686157e-01
    z[2,3,1]  R1436     2.4181348085403442e-01
    z[2,3,1]  R1437     5.4068428277969360e-01
    z[2,3,1]  R1438     -2.0332334935665131e-01
    z[2,3,1]  R1439     -3.8963535428047180e-01
    z[2,3,1]  R1440     2.2602890431880951e-01
    z[2,3,1]  R1441     4.3761026114225388e-02
    z[2,3,1]  R1442     7.8564041852951050e-01
    z[2,3,1]  R1443     9.6119928359985352e-01
    z[2,3,1]  R1444     -1.9524261355400085e-01
    z[2,3,1]  R1445     3.3782741427421570e-01
    z[2,3,1]  R1446     2.0614726468920708e-02
    z[2,3,1]  R1447     1.4211824536323547e-01
    z[2,3,1]  R1448     1.4025595784187317e-01
    z[2,3,1]  R1449     1.0417796671390533e-02
    z[2,3,1]  R1450     6.0442048124969006e-03
    z[2,3,1]  R1451     5.0666470080614090e-02
    z[2,3,1]  R1452     0.0879151001572609
    z[2,3,1]  R1453     4.7405455261468887e-02
    z[2,3,1]  R1454     2.3100873827934265e-01
    z[2,3,1]  R1455     1.0602278262376785e-01
    z[2,3,1]  R1456     9.6101880073547363e-02
    z[2,3,1]  R1457     1.1773117631673813e-01
    z[2,3,1]  R1458     5.3617566823959351e-02
    z[2,3,1]  R1459     1.5947191417217255e-01
    z[2,3,1]  R1460     4.5623715966939926e-02
    z[2,3,1]  R1461     -6.5066802501678467e-01
    z[2,3,1]  R1462     7.0715248584747314e-01
    z[2,3,1]  R1463     8.7995690107345581e-01
    z[2,3,1]  R1464     7.9140859842300415e-01
    z[2,3,1]  R1465     4.6913805603981018e-01
    z[2,3,1]  R1466     5.2681702375411987e-01
    z[2,3,1]  R1467     9.0098321437835693e-01
    z[2,3,1]  R1468     7.3397314548492432e-01
    z[2,3,1]  R1469     7.5054299831390381e-01
    z[2,3,1]  R1470     7.6440131664276123e-01
    z[2,3,1]  R1471     8.0900526046752930e-01
    z[2,3,1]  R1472     4.8665517568588257e-01
    z[2,3,1]  R1473     -1.1594901233911514e-01
    z[2,3,1]  R1474     -3.6921274662017822e-01
    z[2,3,1]  R1475     -0.436531662940979
    z[2,3,1]  R1476     -4.1139650344848633e-01
    z[2,3,1]  R1477     -4.8866763710975647e-01
    z[2,3,1]  R1478     -3.8169285655021667e-01
    z[2,3,1]  R1479     -1.2255111709237099e-02
    z[2,3,1]  R1480     -9.8495864868164062e-01
    z[2,3,1]  R1481     -9.8363023996353149e-01
    z[2,3,1]  R1482     1.2871147692203522e-01
    z[2,3,1]  R1483     -4.5887687802314758e-01
    z[2,3,1]  R1484     3.2750344276428223e-01
    z[2,3,1]  R1485     4.6589708328247070e-01
    z[2,3,1]  R1486     2.6285877823829651e-01
    z[2,3,1]  R1487     -6.7508494853973389e-01
    z[2,3,1]  R1488     1.6986043751239777e-01
    z[2,3,1]  R1489     2.1678008139133453e-01
    z[2,3,1]  R1490     3.9897006750106812e-01
    z[2,3,1]  R1491     -5.8968192338943481e-01
    z[2,3,1]  R1492     -3.4183096885681152e-01
    z[2,3,1]  R1493     4.7175630927085876e-01
    z[2,3,1]  R1494     3.5226395726203918e-01
    z[2,3,1]  R1495     -5.9667944908142090e-01
    z[2,3,1]  R1496     7.0538794994354248e-01
    z[2,3,1]  R1497     4.2998516000807285e-03
    z[2,3,1]  R1498     2.9723146557807922e-01
    z[2,3,1]  R1499     -7.9067003726959229e-01
    z[2,3,1]  R1500     -6.1674386262893677e-01
    z[2,3,1]  R1501     -7.6167237758636475e-01
    z[2,3,2]  R22       -1
    z[2,3,2]  R31       1
    z[2,3,2]  R1372     -1
    z[2,3,2]  R1373     1
    z[2,3,2]  R1382     3.6763572692871094e-01
    z[2,3,2]  R1383     5.0276148319244385e-01
    z[2,3,2]  R1384     4.0322843194007874e-01
    z[2,3,2]  R1385     7.4868232011795044e-01
    z[2,3,2]  R1386     3.0692771077156067e-01
    z[2,3,2]  R1387     5.9499907493591309e-01
    z[2,3,2]  R1388     2.4867615103721619e-01
    z[2,3,2]  R1389     1.8500684201717377e-01
    z[2,3,2]  R1390     2.3874540627002716e-01
    z[2,3,2]  R1391     1.6469387337565422e-02
    z[2,3,2]  R1392     -1.2445499747991562e-01
    z[2,3,2]  R1393     -5.9227406978607178e-02
    z[2,3,2]  R1394     -2.6088374853134155e-01
    z[2,3,2]  R1395     -2.1865636110305786e-01
    z[2,3,2]  R1396     -1.8037162721157074e-01
    z[2,3,2]  R1397     -1.7247246205806732e-01
    z[2,3,2]  R1398     -1.3899783790111542e-01
    z[2,3,2]  R1399     -1.1080551892518997e-01
    z[2,3,2]  R1400     3.9775538444519043e-01
    z[2,3,2]  R1401     1.1231323704123497e-02
    z[2,3,2]  R1402     6.5868055820465088e-01
    z[2,3,2]  R1403     -3.1474792957305908e-01
    z[2,3,2]  R1404     -1.2175311893224716e-01
    z[2,3,2]  R1405     3.3148422837257385e-01
    z[2,3,2]  R1406     5.1093317568302155e-02
    z[2,3,2]  R1407     1.1504931002855301e-01
    z[2,3,2]  R1408     2.0345918834209442e-01
    z[2,3,2]  R1409     -3.6418372392654419e-01
    z[2,3,2]  R1410     4.0174335241317749e-02
    z[2,3,2]  R1411     3.8252830505371094e-01
    z[2,3,2]  R1412     7.0580348372459412e-02
    z[2,3,2]  R1413     4.1537332534790039e-01
    z[2,3,2]  R1414     2.3485516011714935e-01
    z[2,3,2]  R1415     2.5643357634544373e-01
    z[2,3,2]  R1416     1.4694970101118088e-02
    z[2,3,2]  R1417     5.9880863875150681e-02
    z[2,3,2]  R1418     4.0238484740257263e-01
    z[2,3,2]  R1419     2.3903700709342957e-01
    z[2,3,2]  R1420     5.0364041328430176e-01
    z[2,3,2]  R1421     0.0140965785831213
    z[2,3,2]  R1422     2.2510248422622681e-01
    z[2,3,2]  R1423     3.5488355159759521e-01
    z[2,3,2]  R1424     4.5670631527900696e-01
    z[2,3,2]  R1425     2.7176254987716675e-01
    z[2,3,2]  R1426     -1.1318792402744293e-01
    z[2,3,2]  R1427     0.557110071182251
    z[2,3,2]  R1428     -2.2380405664443970e-01
    z[2,3,2]  R1429     -3.2381752133369446e-01
    z[2,3,2]  R1430     -5.3149497509002686e-01
    z[2,3,2]  R1431     2.5458261370658875e-01
    z[2,3,2]  R1432     4.8929756879806519e-01
    z[2,3,2]  R1433     2.9072421789169312e-01
    z[2,3,2]  R1434     3.0683067440986633e-01
    z[2,3,2]  R1435     2.2289778292179108e-01
    z[2,3,2]  R1436     3.3935952186584473e-01
    z[2,3,2]  R1437     -1.2604791671037674e-02
    z[2,3,2]  R1438     6.5620934963226318e-01
    z[2,3,2]  R1439     1.1383425444364548e-01
    z[2,3,2]  R1440     -3.6569130420684814e-01
    z[2,3,2]  R1441     -5.3163391351699829e-01
    z[2,3,2]  R1442     6.4521101303398609e-03
    z[2,3,2]  R1443     2.0284524559974670e-01
    z[2,3,2]  R1444     1.3467849232256413e-02
    z[2,3,2]  R1445     -1.1188992857933044e-01
    z[2,3,2]  R1446     -1.0982112586498260e-01
    z[2,3,2]  R1447     -3.9222124218940735e-01
    z[2,3,2]  R1448     -1.0817139595746994e-01
    z[2,3,2]  R1449     -2.4090123176574707e-01
    z[2,3,2]  R1450     -3.3334711194038391e-01
    z[2,3,2]  R1451     -1.6649633646011353e-01
    z[2,3,2]  R1452     4.5610967278480530e-01
    z[2,3,2]  R1453     7.2723752260208130e-01
    z[2,3,2]  R1454     6.2211388349533081e-01
    z[2,3,2]  R1455     5.7556253671646118e-01
    z[2,3,2]  R1456     8.0174314975738525e-01
    z[2,3,2]  R1457     8.3931821584701538e-01
    z[2,3,2]  R1458     5.7860833406448364e-01
    z[2,3,2]  R1459     0.478883296251297
    z[2,3,2]  R1460     8.1344491243362427e-01
    z[2,3,2]  R1461     -1.3029029965400696e-01
    z[2,3,2]  R1462     3.6529386043548584e-01
    z[2,3,2]  R1463     -7.3588892817497253e-02
    z[2,3,2]  R1464     -7.9887341707944870e-03
    z[2,3,2]  R1465     3.0230340361595154e-01
    z[2,3,2]  R1466     -8.7450090795755386e-03
    z[2,3,2]  R1467     1.2384080886840820e-01
    z[2,3,2]  R1468     -2.7143737673759460e-01
    z[2,3,2]  R1469     4.9015095829963684e-01
    z[2,3,2]  R1470     1.3233336806297302e-01
    z[2,3,2]  R1471     2.1167699992656708e-01
    z[2,3,2]  R1472     3.8264417648315430e-01
    z[2,3,2]  R1473     -4.5903384685516357e-01
    z[2,3,2]  R1474     -3.2446146011352539e-01
    z[2,3,2]  R1475     6.1088603734970093e-01
    z[2,3,2]  R1476     -2.3093193769454956e-01
    z[2,3,2]  R1477     -2.0680993795394897e-01
    z[2,3,2]  R1478     -2.2038353979587555e-01
    z[2,3,2]  R1479     -3.2932776212692261e-01
    z[2,3,2]  R1480     1.2431084178388119e-02
    z[2,3,2]  R1481     1.3812695443630219e-01
    z[2,3,2]  R1482     -1.7673003673553467e-01
    z[2,3,2]  R1483     -2.7781981974840164e-02
    z[2,3,2]  R1484     0.786723792552948
    z[2,3,2]  R1485     3.7132492661476135e-01
    z[2,3,2]  R1486     0.637035071849823
    z[2,3,2]  R1487     3.1422367691993713e-01
    z[2,3,2]  R1488     -6.4259529113769531e-01
    z[2,3,2]  R1489     -1.5603120438754559e-02
    z[2,3,2]  R1490     -7.8586585819721222e-02
    z[2,3,2]  R1491     4.0035453438758850e-01
    z[2,3,2]  R1492     3.4176030755043030e-01
    z[2,3,2]  R1493     0.506028950214386
    z[2,3,2]  R1494     7.6748108863830566e-01
    z[2,3,2]  R1495     4.5889499783515930e-01
    z[2,3,2]  R1496     3.6169582605361938e-01
    z[2,3,2]  R1497     -2.3964995145797729e-01
    z[2,3,2]  R1498     -2.5926128029823303e-01
    z[2,3,2]  R1499     -1.9634471833705902e-01
    z[2,3,2]  R1500     -8.9689306914806366e-02
    z[2,3,2]  R1501     -6.3595935702323914e-02
    z[2,3,3]  R23       -1
    z[2,3,3]  R32       1
    z[2,3,3]  R1374     -1
    z[2,3,3]  R1375     1
    z[2,3,3]  R1382     -4.3263632059097290e-01
    z[2,3,3]  R1383     2.5042481720447540e-02
    z[2,3,3]  R1384     -4.2622995376586914e-01
    z[2,3,3]  R1385     -5.7466577738523483e-02
    z[2,3,3]  R1386     -5.3164166212081909e-01
    z[2,3,3]  R1387     3.1246626377105713e-01
    z[2,3,3]  R1388     -5.5094385147094727e-01
    z[2,3,3]  R1389     -0.40092933177948
    z[2,3,3]  R1390     -6.2547224760055542e-01
    z[2,3,3]  R1391     -7.6631426811218262e-01
    z[2,3,3]  R1392     2.3308290541172028e-01
    z[2,3,3]  R1393     2.9692972078919411e-02
    z[2,3,3]  R1394     2.6940426230430603e-01
    z[2,3,3]  R1395     1.7415495216846466e-01
    z[2,3,3]  R1396     3.1819683313369751e-01
    z[2,3,3]  R1397     5.3033941984176636e-01
    z[2,3,3]  R1398     3.8401737809181213e-01
    z[2,3,3]  R1399     -1.0256312042474747e-01
    z[2,3,3]  R1400     -5.0864759832620621e-02
    z[2,3,3]  R1401     -0.0514921173453331
    z[2,3,3]  R1402     -9.6945770084857941e-02
    z[2,3,3]  R1403     -3.2277530431747437e-01
    z[2,3,3]  R1404     -4.6569815278053284e-01
    z[2,3,3]  R1405     -0.0725424587726593
    z[2,3,3]  R1406     -3.9748242497444153e-01
    z[2,3,3]  R1407     -5.6378829479217529e-01
    z[2,3,3]  R1408     -1.6360698640346527e-01
    z[2,3,3]  R1409     0.019247991964221
    z[2,3,3]  R1410     3.5277467966079712e-01
    z[2,3,3]  R1411     -2.1244628727436066e-01
    z[2,3,3]  R1412     2.7281701564788818e-01
    z[2,3,3]  R1413     -5.0979810953140259e-01
    z[2,3,3]  R1414     -1.8456967175006866e-01
    z[2,3,3]  R1415     -5.4723761975765228e-02
    z[2,3,3]  R1416     1.6110248863697052e-01
    z[2,3,3]  R1417     7.1737951040267944e-01
    z[2,3,3]  R1418     -1.8594120442867279e-01
    z[2,3,3]  R1419     -3.9094543457031250e-01
    z[2,3,3]  R1420     -7.6074379682540894e-01
    z[2,3,3]  R1421     -2.7185940742492676e-01
    z[2,3,3]  R1422     -0.0397600419819355
    z[2,3,3]  R1423     2.2943362593650818e-01
    z[2,3,3]  R1424     0.170019268989563
    z[2,3,3]  R1425     -3.5385897755622864e-01
    z[2,3,3]  R1426     -7.9710179567337036e-01
    z[2,3,3]  R1427     -8.9688166975975037e-02
    z[2,3,3]  R1428     2.5888478755950928e-01
    z[2,3,3]  R1429     -3.3545407652854919e-01
    z[2,3,3]  R1430     3.4856066107749939e-01
    z[2,3,3]  R1431     -3.1090533733367920e-01
    z[2,3,3]  R1432     -4.2504701018333435e-01
    z[2,3,3]  R1433     2.8435248136520386e-01
    z[2,3,3]  R1434     7.5182348489761353e-02
    z[2,3,3]  R1435     -0.473027765750885
    z[2,3,3]  R1436     1.7170520126819611e-01
    z[2,3,3]  R1437     -4.4786918163299561e-01
    z[2,3,3]  R1438     -3.2597610354423523e-01
    z[2,3,3]  R1439     2.5695970654487610e-01
    z[2,3,3]  R1440     2.4426120519638062e-01
    z[2,3,3]  R1441     -1.5772333741188049e-01
    z[2,3,3]  R1442     -5.2296411991119385e-01
    z[2,3,3]  R1443     -2.4884739890694618e-02
    z[2,3,3]  R1444     -2.5975972414016724e-02
    z[2,3,3]  R1445     -0.484904021024704
    z[2,3,3]  R1446     -1.0325936228036880e-01
    z[2,3,3]  R1447     1.7387378215789795e-01
    z[2,3,3]  R1448     4.1590014100074768e-01
    z[2,3,3]  R1449     1.8978017568588257e-01
    z[2,3,3]  R1450     5.8795613050460815e-01
    z[2,3,3]  R1451     3.6701145768165588e-01
    z[2,3,3]  R1452     -4.4812297821044922e-01
    z[2,3,3]  R1453     -4.4923420995473862e-02
    z[2,3,3]  R1454     -4.2484471201896667e-01
    z[2,3,3]  R1455     -4.7857820987701416e-01
    z[2,3,3]  R1456     -2.6240247488021851e-01
    z[2,3,3]  R1457     -3.1512993574142456e-01
    z[2,3,3]  R1458     -1.4631706476211548e-01
    z[2,3,3]  R1459     7.6103769242763519e-02
    z[2,3,3]  R1460     2.7971621602773666e-02
    z[2,3,3]  R1461     5.8904254436492920e-01
    z[2,3,3]  R1462     -1.5220357477664948e-01
    z[2,3,3]  R1463     -2.0829458534717560e-01
    z[2,3,3]  R1464     -1.7938715219497681e-01
    z[2,3,3]  R1465     -1.8934619426727295e-01
    z[2,3,3]  R1466     -1.1781907081604004e-01
    z[2,3,3]  R1467     -1.9135364890098572e-01
    z[2,3,3]  R1468     -1.6161556541919708e-01
    z[2,3,3]  R1469     1.6730929911136627e-01
    z[2,3,3]  R1470     -8.9101351797580719e-02
    z[2,3,3]  R1471     1.0480973869562149e-01
    z[2,3,3]  R1472     -4.8682615160942078e-01
    z[2,3,3]  R1473     1.2215206027030945e-01
    z[2,3,3]  R1474     8.9465126395225525e-02
    z[2,3,3]  R1475     4.0796884894371033e-01
    z[2,3,3]  R1476     5.4777670651674271e-02
    z[2,3,3]  R1477     1.8457730114459991e-01
    z[2,3,3]  R1478     -2.2198373079299927e-01
    z[2,3,3]  R1479     4.9443040043115616e-02
    z[2,3,3]  R1480     -2.6664443314075470e-02
    z[2,3,3]  R1481     -1.3641602359712124e-02
    z[2,3,3]  R1482     2.0883357524871826e-01
    z[2,3,3]  R1483     5.9276979416608810e-02
    z[2,3,3]  R1484     -3.7302502989768982e-01
    z[2,3,3]  R1485     -2.2553491592407227e-01
    z[2,3,3]  R1486     -2.6345416903495789e-01
    z[2,3,3]  R1487     -5.7021226733922958e-02
    z[2,3,3]  R1488     -1.4604070782661438e-01
    z[2,3,3]  R1489     7.3949128389358521e-01
    z[2,3,3]  R1490     -7.7378368377685547e-01
    z[2,3,3]  R1491     -3.0501747131347656e-01
    z[2,3,3]  R1492     1.3053485751152039e-01
    z[2,3,3]  R1493     -4.6720156073570251e-01
    z[2,3,3]  R1494     -3.7617179751396179e-01
    z[2,3,3]  R1495     -2.5443825125694275e-01
    z[2,3,3]  R1496     1.4944136142730713e-01
    z[2,3,3]  R1497     -2.1485966444015503e-01
    z[2,3,3]  R1498     -0.361503541469574
    z[2,3,3]  R1499     4.0918534994125366e-01
    z[2,3,3]  R1500     2.1533244848251343e-01
    z[2,3,3]  R1501     9.3500562012195587e-02
    z[2,3,4]  R24       -1
    z[2,3,4]  R33       1
    z[2,3,4]  R1376     -1
    z[2,3,4]  R1377     1
    z[2,3,4]  R1382     5.4722440242767334e-01
    z[2,3,4]  R1383     1.4803525805473328e-01
    z[2,3,4]  R1384     3.9918571710586548e-01
    z[2,3,4]  R1385     1.5126839280128479e-01
    z[2,3,4]  R1386     1.6763398051261902e-01
    z[2,3,4]  R1387     0.407213419675827
    z[2,3,4]  R1388     1.0990818589925766e-01
    z[2,3,4]  R1389     4.3967992067337036e-01
    z[2,3,4]  R1390     3.0011904239654541e-01
    z[2,3,4]  R1391     2.4865177273750305e-01
    z[2,3,4]  R1392     -4.3187049031257629e-01
    z[2,3,4]  R1393     -2.8873729705810547e-01
    z[2,3,4]  R1394     -2.5547134876251221e-01
    z[2,3,4]  R1395     -4.5111125707626343e-01
    z[2,3,4]  R1396     1.2408773601055145e-01
    z[2,3,4]  R1397     -5.2206343412399292e-01
    z[2,3,4]  R1398     -5.4761254787445068e-01
    z[2,3,4]  R1399     -3.4461638331413269e-01
    z[2,3,4]  R1400     -4.5211181044578552e-01
    z[2,3,4]  R1401     -0.165044367313385
    z[2,3,4]  R1402     1.5875680744647980e-01
    z[2,3,4]  R1403     1.3715524971485138e-01
    z[2,3,4]  R1404     -2.2346515953540802e-01
    z[2,3,4]  R1405     -4.1759216785430908e-01
    z[2,3,4]  R1406     -3.9751854538917542e-01
    z[2,3,4]  R1407     1.7852714657783508e-01
    z[2,3,4]  R1408     -1.8352989852428436e-01
    z[2,3,4]  R1409     -0.0141184376552701
    z[2,3,4]  R1410     4.5318210124969482e-01
    z[2,3,4]  R1411     -1.0221090167760849e-01
    z[2,3,4]  R1412     3.0856120586395264e-01
    z[2,3,4]  R1413     1.4820776879787445e-01
    z[2,3,4]  R1414     -3.0214396119117737e-01
    z[2,3,4]  R1415     -2.6687222719192505e-01
    z[2,3,4]  R1416     7.0675933361053467e-01
    z[2,3,4]  R1417     1.2677582912147045e-02
    z[2,3,4]  R1418     -4.4618183746933937e-03
    z[2,3,4]  R1419     1.7956745624542236e-01
    z[2,3,4]  R1420     2.4438561499118805e-01
    z[2,3,4]  R1421     9.0185302495956421e-01
    z[2,3,4]  R1422     2.7694925665855408e-01
    z[2,3,4]  R1423     2.9913464188575745e-01
    z[2,3,4]  R1424     0.59245765209198
    z[2,3,4]  R1425     8.3373981714248657e-01
    z[2,3,4]  R1426     3.6104089021682739e-01
    z[2,3,4]  R1427     6.1061972379684448e-01
    z[2,3,4]  R1428     -5.5673813819885254e-01
    z[2,3,4]  R1429     -2.3355101048946381e-01
    z[2,3,4]  R1430     -1.0546758770942688e-01
    z[2,3,4]  R1431     -4.9160704016685486e-01
    z[2,3,4]  R1432     1.6739736497402191e-01
    z[2,3,4]  R1433     5.1879614591598511e-01
    z[2,3,4]  R1434     4.8258817195892334e-01
    z[2,3,4]  R1435     2.2869048640131950e-02
    z[2,3,4]  R1436     -2.2212823852896690e-02
    z[2,3,4]  R1437     3.4187096357345581e-01
    z[2,3,4]  R1438     -2.4101753532886505e-01
    z[2,3,4]  R1439     -3.0958282947540283e-01
    z[2,3,4]  R1440     -4.0877389907836914e-01
    z[2,3,4]  R1441     -1.7188343405723572e-01
    z[2,3,4]  R1442     1.6331204771995544e-01
    z[2,3,4]  R1443     -1.7008937895298004e-02
    z[2,3,4]  R1444     -6.5068101882934570e-01
    z[2,3,4]  R1445     5.6897652149200439e-01
    z[2,3,4]  R1446     2.3531997203826904e-01
    z[2,3,4]  R1447     -2.8548237681388855e-01
    z[2,3,4]  R1448     -2.5689691305160522e-01
    z[2,3,4]  R1449     -1.4262603223323822e-01
    z[2,3,4]  R1450     -8.4751576185226440e-02
    z[2,3,4]  R1451     -1.4050680398941040e-01
    z[2,3,4]  R1452     -1.6152805089950562e-01
    z[2,3,4]  R1453     4.1991356760263443e-02
    z[2,3,4]  R1454     3.3569493889808655e-01
    z[2,3,4]  R1455     1.6924628615379333e-01
    z[2,3,4]  R1456     5.1765460520982742e-03
    z[2,3,4]  R1457     -1.7421782016754150e-02
    z[2,3,4]  R1458     2.0205074548721313e-01
    z[2,3,4]  R1459     1.7253243923187256e-01
    z[2,3,4]  R1460     -6.7176230251789093e-02
    z[2,3,4]  R1461     5.7344906032085419e-02
    z[2,3,4]  R1462     3.2965913414955139e-01
    z[2,3,4]  R1463     2.4692562222480774e-01
    z[2,3,4]  R1464     3.2463434338569641e-01
    z[2,3,4]  R1465     5.8428615331649780e-01
    z[2,3,4]  R1466     6.2384980916976929e-01
    z[2,3,4]  R1467     -1.5458887815475464e-01
    z[2,3,4]  R1468     4.6523067355155945e-01
    z[2,3,4]  R1469     -2.9821535944938660e-01
    z[2,3,4]  R1470     -2.2359816730022430e-01
    z[2,3,4]  R1471     -2.7855536341667175e-01
    z[2,3,4]  R1472     -1.0852883569896221e-02
    z[2,3,4]  R1473     2.2692683339118958e-01
    z[2,3,4]  R1474     5.1973837614059448e-01
    z[2,3,4]  R1475     2.7637824416160583e-01
    z[2,3,4]  R1476     3.6246275901794434e-01
    z[2,3,4]  R1477     -1.7918980121612549e-01
    z[2,3,4]  R1478     5.1530379056930542e-01
    z[2,3,4]  R1479     -0.562545120716095
    z[2,3,4]  R1480     -3.1120110303163528e-02
    z[2,3,4]  R1481     1.0847674310207367e-01
    z[2,3,4]  R1482     2.0253743231296539e-01
    z[2,3,4]  R1483     -2.9733717441558838e-01
    z[2,3,4]  R1484     4.4139493256807327e-03
    z[2,3,4]  R1485     2.4505078792572021e-01
    z[2,3,4]  R1486     4.6307435631752014e-01
    z[2,3,4]  R1487     3.7557664513587952e-01
    z[2,3,4]  R1488     -1.9396117329597473e-01
    z[2,3,4]  R1489     3.1712433695793152e-01
    z[2,3,4]  R1490     -3.1650328636169434e-01
    z[2,3,4]  R1491     -5.8611828833818436e-02
    z[2,3,4]  R1492     4.7082599997520447e-01
    z[2,3,4]  R1493     2.4481488764286041e-01
    z[2,3,4]  R1494     1.4100854098796844e-01
    z[2,3,4]  R1495     -1.5714994072914124e-01
    z[2,3,4]  R1496     -3.3327883481979370e-01
    z[2,3,4]  R1497     7.1202528476715088e-01
    z[2,3,4]  R1498     1.9729733467102051e-01
    z[2,3,4]  R1499     -0.0475076325237751
    z[2,3,4]  R1500     5.0383579218760133e-04
    z[2,3,4]  R1501     -6.9557175040245056e-02
    z[2,3,5]  R25       -1
    z[2,3,5]  R34       1
    z[2,3,5]  R1378     -1
    z[2,3,5]  R1379     1
    z[2,3,5]  R1382     0.0833800733089447
    z[2,3,5]  R1383     -5.6501626968383789e-01
    z[2,3,5]  R1384     -3.9174145460128784e-01
    z[2,3,5]  R1385     -2.2922298312187195e-01
    z[2,3,5]  R1386     -4.8700946569442749e-01
    z[2,3,5]  R1387     2.9084333777427673e-01
    z[2,3,5]  R1388     -6.4033287763595581e-01
    z[2,3,5]  R1389     -6.5542846918106079e-01
    z[2,3,5]  R1390     0.0578635148704052
    z[2,3,5]  R1391     -5.1316618919372559e-01
    z[2,3,5]  R1392     1.7781247198581696e-01
    z[2,3,5]  R1393     2.4892254173755646e-01
    z[2,3,5]  R1394     3.1144040822982788e-01
    z[2,3,5]  R1395     2.7869430184364319e-01
    z[2,3,5]  R1396     0.282055526971817
    z[2,3,5]  R1397     -5.0505995750427246e-02
    z[2,3,5]  R1398     -3.7204194813966751e-02
    z[2,3,5]  R1399     -8.1756219267845154e-02
    z[2,3,5]  R1400     0.0612642765045166
    z[2,3,5]  R1401     9.9795535206794739e-02
    z[2,3,5]  R1402     -2.7276474982500076e-02
    z[2,3,5]  R1403     -4.8238925635814667e-02
    z[2,3,5]  R1404     4.6981833875179291e-02
    z[2,3,5]  R1405     2.1955677866935730e-01
    z[2,3,5]  R1406     1.8834892660379410e-02
    z[2,3,5]  R1407     2.6265913248062134e-01
    z[2,3,5]  R1408     4.7365966439247131e-01
    z[2,3,5]  R1409     -5.8403289318084717e-01
    z[2,3,5]  R1410     -2.8355203568935394e-02
    z[2,3,5]  R1411     3.8093358278274536e-01
    z[2,3,5]  R1412     -1.9037359952926636e-01
    z[2,3,5]  R1413     3.4328180551528931e-01
    z[2,3,5]  R1414     -6.7727595567703247e-01
    z[2,3,5]  R1415     0.176070898771286
    z[2,3,5]  R1416     -5.2785944938659668e-01
    z[2,3,5]  R1417     -5.5261558294296265e-01
    z[2,3,5]  R1418     -2.1267484128475189e-01
    z[2,3,5]  R1419     -5.8950096368789673e-01
    z[2,3,5]  R1420     -7.9023383557796478e-02
    z[2,3,5]  R1421     1.3754327595233917e-01
    z[2,3,5]  R1422     -7.6670008897781372e-01
    z[2,3,5]  R1423     -3.0801013112068176e-01
    z[2,3,5]  R1424     4.9699175357818604e-01
    z[2,3,5]  R1425     -2.6377269625663757e-01
    z[2,3,5]  R1426     -3.1842306256294250e-01
    z[2,3,5]  R1427     -1.4775237441062927e-01
    z[2,3,5]  R1428     -4.6165534853935242e-01
    z[2,3,5]  R1429     -5.6931990385055542e-01
    z[2,3,5]  R1430     1.3387784361839294e-01
    z[2,3,5]  R1431     -2.1085444092750549e-01
    z[2,3,5]  R1432     -1.8902689218521118e-01
    z[2,3,5]  R1433     1.8010181188583374e-01
    z[2,3,5]  R1434     3.8541790843009949e-01
    z[2,3,5]  R1435     -4.8934942483901978e-01
    z[2,3,5]  R1436     -5.8389580249786377e-01
    z[2,3,5]  R1437     -4.0831071138381958e-01
    z[2,3,5]  R1438     -2.3585020005702972e-01
    z[2,3,5]  R1439     -4.0940853953361511e-01
    z[2,3,5]  R1440     -6.5990430116653442e-01
    z[2,3,5]  R1441     -7.9477471113204956e-01
    z[2,3,5]  R1442     -5.6973181664943695e-02
    z[2,3,5]  R1443     8.4464959800243378e-02
    z[2,3,5]  R1444     -4.8492497205734253e-01
    z[2,3,5]  R1445     -5.4549610614776611e-01
    z[2,3,5]  R1446     -5.8714795112609863e-01
    z[2,3,5]  R1447     -0.671748161315918
    z[2,3,5]  R1448     -2.1288812160491943e-02
    z[2,3,5]  R1449     -2.4835960566997528e-01
    z[2,3,5]  R1450     -1.7103852331638336e-01
    z[2,3,5]  R1451     4.2648389935493469e-02
    z[2,3,5]  R1452     -5.7792407274246216e-01
    z[2,3,5]  R1453     -4.2808058857917786e-01
    z[2,3,5]  R1454     -2.9734271764755249e-01
    z[2,3,5]  R1455     -2.8148514032363892e-01
    z[2,3,5]  R1456     -2.7915477752685547e-02
    z[2,3,5]  R1457     -7.9293444752693176e-02
    z[2,3,5]  R1458     -8.4606327116489410e-02
    z[2,3,5]  R1459     9.9117174744606018e-02
    z[2,3,5]  R1460     1.6980433836579323e-02
    z[2,3,5]  R1461     1.7489799857139587e-01
    z[2,3,5]  R1462     2.8112211823463440e-01
    z[2,3,5]  R1463     5.8897435665130615e-02
    z[2,3,5]  R1464     -1.9705721735954285e-01
    z[2,3,5]  R1465     2.7261313796043396e-01
    z[2,3,5]  R1466     4.2434221506118774e-01
    z[2,3,5]  R1467     -1.7677873373031616e-01
    z[2,3,5]  R1468     -1.4201782643795013e-01
    z[2,3,5]  R1469     2.5592403486371040e-02
    z[2,3,5]  R1470     -3.0416905879974365e-01
    z[2,3,5]  R1471     -0.000569283205550164
    z[2,3,5]  R1472     -1.0047782957553864e-01
    z[2,3,5]  R1473     -4.3988370895385742e-01
    z[2,3,5]  R1474     -2.9304248094558716e-01
    z[2,3,5]  R1475     2.9010564088821411e-02
    z[2,3,5]  R1476     -2.3519793152809143e-01
    z[2,3,5]  R1477     -7.7569890022277832e-01
    z[2,3,5]  R1478     -1.2172938138246536e-01
    z[2,3,5]  R1479     -4.7232115268707275e-01
    z[2,3,5]  R1480     -9.4048053026199341e-02
    z[2,3,5]  R1481     -3.5687930881977081e-02
    z[2,3,5]  R1482     -0.637411892414093
    z[2,3,5]  R1483     -6.6606724262237549e-01
    z[2,3,5]  R1484     -3.1793776154518127e-01
    z[2,3,5]  R1485     -2.8903603553771973e-01
    z[2,3,5]  R1486     -5.9671834111213684e-02
    z[2,3,5]  R1487     5.5829092860221863e-02
    z[2,3,5]  R1488     -4.8054376244544983e-01
    z[2,3,5]  R1489     -3.7372562289237976e-01
    z[2,3,5]  R1490     -5.1018174737691879e-02
    z[2,3,5]  R1491     -0.16500224173069
    z[2,3,5]  R1492     -2.6149508357048035e-01
    z[2,3,5]  R1493     -3.9062270522117615e-01
    z[2,3,5]  R1494     -7.5355544686317444e-02
    z[2,3,5]  R1495     -1.0918852686882019e-01
    z[2,3,5]  R1496     3.1797841191291809e-01
    z[2,3,5]  R1497     6.7660994827747345e-02
    z[2,3,5]  R1498     -4.4406184554100037e-01
    z[2,3,5]  R1499     0.28211510181427
    z[2,3,5]  R1500     -3.8971409201622009e-02
    z[2,3,5]  R1501     -0.0712960958480835
    z[2,3,6]  R26       -1
    z[2,3,6]  R35       1
    z[2,3,6]  R1380     -1
    z[2,3,6]  R1381     1
    z[2,3,6]  R1382     5.4780679941177368e-01
    z[2,3,6]  R1383     2.0252996683120728e-01
    z[2,3,6]  R1384     -4.2021661996841431e-01
    z[2,3,6]  R1385     -0.333069384098053
    z[2,3,6]  R1386     4.3221309781074524e-01
    z[2,3,6]  R1387     4.3560647964477539e-01
    z[2,3,6]  R1388     -0.0211162306368351
    z[2,3,6]  R1389     -8.8334038853645325e-02
    z[2,3,6]  R1390     -0.672598659992218
    z[2,3,6]  R1391     -2.0423695445060730e-01
    z[2,3,6]  R1392     2.0441854000091553e-01
    z[2,3,6]  R1393     0.065752312541008
    z[2,3,6]  R1394     -2.4065662920475006e-01
    z[2,3,6]  R1395     -1.5588358044624329e-01
    z[2,3,6]  R1396     -1.9604048132896423e-01
    z[2,3,6]  R1397     1.7837767302989960e-01
    z[2,3,6]  R1398     -0.228534996509552
    z[2,3,6]  R1399     4.7620676457881927e-02
    z[2,3,6]  R1400     2.4584442377090454e-02
    z[2,3,6]  R1401     -1.9309307634830475e-01
    z[2,3,6]  R1402     -2.4188582599163055e-01
    z[2,3,6]  R1403     -1.4621366560459137e-01
    z[2,3,6]  R1404     6.7733906209468842e-02
    z[2,3,6]  R1405     -1.4885485172271729e-01
    z[2,3,6]  R1406     -2.9821133613586426e-01
    z[2,3,6]  R1407     -5.4383349418640137e-01
    z[2,3,6]  R1408     1.6138026118278503e-01
    z[2,3,6]  R1409     -1.0271550714969635e-01
    z[2,3,6]  R1410     -4.0465155243873596e-01
    z[2,3,6]  R1411     -4.9593195319175720e-01
    z[2,3,6]  R1412     2.0486150681972504e-01
    z[2,3,6]  R1413     4.4525536894798279e-01
    z[2,3,6]  R1414     -2.9589691758155823e-01
    z[2,3,6]  R1415     5.2946376800537109e-01
    z[2,3,6]  R1416     1.6983704641461372e-02
    z[2,3,6]  R1417     0.00609292509034276
    z[2,3,6]  R1418     6.0368931293487549e-01
    z[2,3,6]  R1419     3.6947453022003174e-01
    z[2,3,6]  R1420     1.9826957583427429e-01
    z[2,3,6]  R1421     5.8247018605470657e-02
    z[2,3,6]  R1422     -1.3854290544986725e-01
    z[2,3,6]  R1423     -5.9745550155639648e-01
    z[2,3,6]  R1424     1.6257208585739136e-01
    z[2,3,6]  R1425     -2.6792740449309349e-02
    z[2,3,6]  R1426     2.3442240059375763e-01
    z[2,3,6]  R1427     -2.8105893731117249e-01
    z[2,3,6]  R1428     5.3105145692825317e-01
    z[2,3,6]  R1429     5.6892484426498413e-01
    z[2,3,6]  R1430     2.6140075176954269e-02
    z[2,3,6]  R1431     2.6417341828346252e-01
    z[2,3,6]  R1432     3.8478469848632812e-01
    z[2,3,6]  R1433     -2.5064751505851746e-01
    z[2,3,6]  R1434     2.0427854359149933e-01
    z[2,3,6]  R1435     -3.9159689098596573e-02
    z[2,3,6]  R1436     4.0434777736663818e-01
    z[2,3,6]  R1437     -4.7182762622833252e-01
    z[2,3,6]  R1438     -1.4492989517748356e-02
    z[2,3,6]  R1439     -5.9795439243316650e-01
    z[2,3,6]  R1440     3.2052555680274963e-01
    z[2,3,6]  R1441     -1.2123268842697144e-01
    z[2,3,6]  R1442     2.1846349537372589e-01
    z[2,3,6]  R1443     -0.0975298061966896
    z[2,3,6]  R1444     3.3296042680740356e-01
    z[2,3,6]  R1445     1.1676558107137680e-01
    z[2,3,6]  R1446     7.0225185155868530e-01
    z[2,3,6]  R1447     4.6222487092018127e-01
    z[2,3,6]  R1448     -9.1960892081260681e-02
    z[2,3,6]  R1449     3.3916354179382324e-02
    z[2,3,6]  R1450     2.0778512954711914e-01
    z[2,3,6]  R1451     5.3824341297149658e-01
    z[2,3,6]  R1452     7.4521891772747040e-02
    z[2,3,6]  R1453     -2.2464311122894287e-01
    z[2,3,6]  R1454     -2.1223948895931244e-01
    z[2,3,6]  R1455     -5.5257236957550049e-01
    z[2,3,6]  R1456     -4.8760646581649780e-01
    z[2,3,6]  R1457     0.41396364569664
    z[2,3,6]  R1458     7.3515009880065918e-01
    z[2,3,6]  R1459     4.5496222376823425e-01
    z[2,3,6]  R1460     3.8575893640518188e-01
    z[2,3,6]  R1461     -3.4354977309703827e-02
    z[2,3,6]  R1462     0.353779673576355
    z[2,3,6]  R1463     -1.5861421823501587e-01
    z[2,3,6]  R1464     0.398602157831192
    z[2,3,6]  R1465     -4.3374350666999817e-01
    z[2,3,6]  R1466     -3.6097073554992676e-01
    z[2,3,6]  R1467     2.1861669421195984e-01
    z[2,3,6]  R1468     -2.0553785562515259e-01
    z[2,3,6]  R1469     0.0370715856552124
    z[2,3,6]  R1470     -2.6596274971961975e-01
    z[2,3,6]  R1471     2.4547803401947021e-01
    z[2,3,6]  R1472     -5.9849119186401367e-01
    z[2,3,6]  R1473     -5.7676357030868530e-01
    z[2,3,6]  R1474     -4.0605217218399048e-01
    z[2,3,6]  R1475     0.247311532497406
    z[2,3,6]  R1476     6.7981898784637451e-01
    z[2,3,6]  R1477     -4.4222317636013031e-02
    z[2,3,6]  R1478     0.503506600856781
    z[2,3,6]  R1479     5.2704554796218872e-01
    z[2,3,6]  R1480     -1.3678748905658722e-01
    z[2,3,6]  R1481     8.0298632383346558e-03
    z[2,3,6]  R1482     4.7421202063560486e-01
    z[2,3,6]  R1483     3.5756975412368774e-01
    z[2,3,6]  R1484     -4.4253780506551266e-03
    z[2,3,6]  R1485     -1.8486125767230988e-01
    z[2,3,6]  R1486     1.4423312246799469e-01
    z[2,3,6]  R1487     -3.8099639117717743e-02
    z[2,3,6]  R1488     -0.118285171687603
    z[2,3,6]  R1489     -2.6165261864662170e-01
    z[2,3,6]  R1490     1.1281788349151611e-01
    z[2,3,6]  R1491     -5.3018681704998016e-02
    z[2,3,6]  R1492     -2.0261111855506897e-01
    z[2,3,6]  R1493     -2.6949328184127808e-01
    z[2,3,6]  R1494     -0.344638854265213
    z[2,3,6]  R1495     -0.314930260181427
    z[2,3,6]  R1496     -2.7806192636489868e-01
    z[2,3,6]  R1497     9.3920424580574036e-02
    z[2,3,6]  R1498     3.6387926340103149e-01
    z[2,3,6]  R1499     7.9205565154552460e-02
    z[2,3,6]  R1500     -1.4415609836578369e-01
    z[2,3,6]  R1501     -0.0653463751077652
    z[3,2,0]  R20       1
    z[3,2,0]  R29       -1
    z[3,2,0]  R1502     -1
    z[3,2,0]  R1503     1
    z[3,2,0]  R1516     -4.6666866540908813e-01
    z[3,2,0]  R1517     -4.8101916909217834e-01
    z[3,2,0]  R1518     3.6464604735374451e-01
    z[3,2,0]  R1519     -1.2343242764472961e-01
    z[3,2,0]  R1520     2.0137287676334381e-01
    z[3,2,0]  R1521     -6.6487483680248260e-02
    z[3,2,0]  R1522     2.2912968695163727e-01
    z[3,2,0]  R1523     7.0204377174377441e-01
    z[3,2,0]  R1524     4.2641815543174744e-01
    z[3,2,0]  R1525     4.2145749926567078e-01
    z[3,2,0]  R1526     -1.7454244196414948e-01
    z[3,2,0]  R1527     -2.9542219638824463e-01
    z[3,2,0]  R1528     1.9577080011367798e-01
    z[3,2,0]  R1529     2.2097186744213104e-01
    z[3,2,0]  R1530     -9.4610609114170074e-02
    z[3,2,0]  R1531     1.8257792294025421e-01
    z[3,2,0]  R1532     2.8745627403259277e-01
    z[3,2,0]  R1533     2.7835810184478760e-01
    z[3,2,0]  R1534     4.2069977521896362e-01
    z[3,2,0]  R1535     3.8969895243644714e-01
    z[3,2,0]  R1536     1.0651419311761856e-01
    z[3,2,0]  R1537     -4.2810398340225220e-01
    z[3,2,0]  R1538     -4.7908496856689453e-01
    z[3,2,0]  R1539     -3.6253309249877930e-01
    z[3,2,0]  R1540     -3.5436081886291504e-01
    z[3,2,0]  R1541     -2.2043451666831970e-01
    z[3,2,0]  R1542     -4.7179442644119263e-01
    z[3,2,0]  R1543     -2.6763233542442322e-01
    z[3,2,0]  R1544     -2.1600507199764252e-02
    z[3,2,0]  R1545     1.0049605742096901e-02
    z[3,2,0]  R1546     -4.8620569705963135e-01
    z[3,2,0]  R1547     -3.5388594865798950e-01
    z[3,2,0]  R1548     1.8312826752662659e-01
    z[3,2,0]  R1549     6.4531099796295166e-01
    z[3,2,0]  R1550     4.6570557355880737e-01
    z[3,2,0]  R1551     -5.4465222358703613e-01
    z[3,2,0]  R1552     -5.0433743000030518e-01
    z[3,2,0]  R1553     -0.31179279088974
    z[3,2,0]  R1554     -3.4698817133903503e-01
    z[3,2,0]  R1555     -6.0455256700515747e-01
    z[3,2,0]  R1556     -6.4668697118759155e-01
    z[3,2,0]  R1557     1.3400086760520935e-01
    z[3,2,0]  R1558     3.2247900962829590e-02
    z[3,2,0]  R1559     -0.482546329498291
    z[3,2,0]  R1560     2.4447478353977203e-01
    z[3,2,0]  R1561     -6.1319309473037720e-01
    z[3,2,0]  R1562     -5.8756017684936523e-01
    z[3,2,0]  R1563     2.8414359688758850e-01
    z[3,2,0]  R1564     7.3682749271392822e-01
    z[3,2,0]  R1565     6.2679886817932129e-01
    z[3,2,0]  R1566     5.1106750965118408e-02
    z[3,2,0]  R1567     5.9056133031845093e-01
    z[3,2,0]  R1568     3.8707137107849121e-01
    z[3,2,0]  R1569     4.8208811879158020e-01
    z[3,2,0]  R1570     3.9119637012481689e-01
    z[3,2,0]  R1571     1.4780405163764954e-01
    z[3,2,0]  R1572     3.7821340560913086e-01
    z[3,2,0]  R1573     3.1116208434104919e-01
    z[3,2,0]  R1574     -7.1673743426799774e-02
    z[3,2,0]  R1575     1.2954111397266388e-01
    z[3,2,0]  R1576     -8.0445349216461182e-01
    z[3,2,0]  R1577     -9.1631394624710083e-01
    z[3,2,0]  R1578     -7.8195226192474365e-01
    z[3,2,0]  R1579     -7.6881724596023560e-01
    z[3,2,0]  R1580     -8.5561519861221313e-01
    z[3,2,0]  R1581     -6.1567348241806030e-01
    z[3,2,0]  R1582     -6.8078100681304932e-01
    z[3,2,0]  R1583     -8.9947152137756348e-01
    z[3,2,0]  R1584     -5.7025265693664551e-01
    z[3,2,0]  R1585     -9.3417984247207642e-01
    z[3,2,0]  R1586     2.1477112174034119e-01
    z[3,2,0]  R1587     -3.8141974806785583e-01
    z[3,2,0]  R1588     -2.7105388045310974e-01
    z[3,2,0]  R1589     -5.6051395833492279e-02
    z[3,2,0]  R1590     -1.5068499743938446e-01
    z[3,2,0]  R1591     -3.0338394641876221e-01
    z[3,2,0]  R1592     -2.7596482634544373e-01
    z[3,2,0]  R1593     2.4456791579723358e-01
    z[3,2,0]  R1594     -1.6306860744953156e-01
    z[3,2,0]  R1595     -1.7163069546222687e-01
    z[3,2,0]  R1596     -1.7435763031244278e-02
    z[3,2,0]  R1597     -7.4469387531280518e-02
    z[3,2,0]  R1598     4.6104887127876282e-01
    z[3,2,0]  R1599     -1.5043017454445362e-02
    z[3,2,0]  R1600     1.4565181732177734e-01
    z[3,2,0]  R1601     4.1971042752265930e-01
    z[3,2,0]  R1602     2.8397732973098755e-01
    z[3,2,0]  R1603     3.6843919754028320e-01
    z[3,2,0]  R1604     2.2394387423992157e-01
    z[3,2,0]  R1605     -2.4747861921787262e-01
    z[3,2,0]  R1606     4.6400707960128784e-01
    z[3,2,0]  R1607     3.8031637668609619e-01
    z[3,2,0]  R1608     -1.2748220562934875e-01
    z[3,2,0]  R1609     1.2794123589992523e-01
    z[3,2,0]  R1610     -0.0471976064145565
    z[3,2,0]  R1611     3.4939879179000854e-01
    z[3,2,0]  R1612     2.6777082681655884e-01
    z[3,2,0]  R1613     2.1898530423641205e-01
    z[3,2,0]  R1614     -7.4936193227767944e-01
    z[3,2,0]  R1615     4.3602046370506287e-01
    z[3,2,0]  R1616     2.5317353010177612e-01
    z[3,2,0]  R1617     -1.3065354526042938e-01
    z[3,2,0]  R1618     -2.0609799027442932e-01
    z[3,2,0]  R1619     4.5509546995162964e-01
    z[3,2,0]  R1620     5.4032748937606812e-01
    z[3,2,0]  R1621     -2.6457160711288452e-02
    z[3,2,0]  R1622     5.5485457181930542e-01
    z[3,2,0]  R1623     3.8495638966560364e-01
    z[3,2,0]  R1624     2.2407768666744232e-01
    z[3,2,0]  R1625     1.2110158801078796e-01
    z[3,2,0]  R1626     -1.7774407565593719e-01
    z[3,2,0]  R1627     -1.3188990950584412e-01
    z[3,2,0]  R1628     4.3774825334548950e-01
    z[3,2,0]  R1629     5.7331051677465439e-02
    z[3,2,0]  R1630     2.8909498453140259e-01
    z[3,2,0]  R1631     2.2211559116840363e-01
    z[3,2,0]  R1632     -8.4896892309188843e-01
    z[3,2,0]  R1633     -9.0700966119766235e-01
    z[3,2,0]  R1634     -6.8083697557449341e-01
    z[3,2,0]  R1635     -7.2370398044586182e-01
    z[3,2,1]  R21       1
    z[3,2,1]  R30       -1
    z[3,2,1]  R1504     -1
    z[3,2,1]  R1505     1
    z[3,2,1]  R1516     0.0879151001572609
    z[3,2,1]  R1517     4.7405455261468887e-02
    z[3,2,1]  R1518     2.3100873827934265e-01
    z[3,2,1]  R1519     1.0602278262376785e-01
    z[3,2,1]  R1520     9.6101880073547363e-02
    z[3,2,1]  R1521     1.1773117631673813e-01
    z[3,2,1]  R1522     5.3617566823959351e-02
    z[3,2,1]  R1523     1.5947191417217255e-01
    z[3,2,1]  R1524     4.5623715966939926e-02
    z[3,2,1]  R1525     -6.5066802501678467e-01
    z[3,2,1]  R1526     7.0715248584747314e-01
    z[3,2,1]  R1527     8.7995690107345581e-01
    z[3,2,1]  R1528     7.9140859842300415e-01
    z[3,2,1]  R1529     4.6913805603981018e-01
    z[3,2,1]  R1530     5.2681702375411987e-01
    z[3,2,1]  R1531     9.0098321437835693e-01
    z[3,2,1]  R1532     7.3397314548492432e-01
    z[3,2,1]  R1533     7.5054299831390381e-01
    z[3,2,1]  R1534     7.6440131664276123e-01
    z[3,2,1]  R1535     8.0900526046752930e-01
    z[3,2,1]  R1536     4.8665517568588257e-01
    z[3,2,1]  R1537     -1.1594901233911514e-01
    z[3,2,1]  R1538     -3.6921274662017822e-01
    z[3,2,1]  R1539     -0.436531662940979
    z[3,2,1]  R1540     -4.1139650344848633e-01
    z[3,2,1]  R1541     -4.8866763710975647e-01
    z[3,2,1]  R1542     -3.8169285655021667e-01
    z[3,2,1]  R1543     -1.2255111709237099e-02
    z[3,2,1]  R1544     -9.8495864868164062e-01
    z[3,2,1]  R1545     -9.8363023996353149e-01
    z[3,2,1]  R1546     1.2871147692203522e-01
    z[3,2,1]  R1547     -4.5887687802314758e-01
    z[3,2,1]  R1548     3.2750344276428223e-01
    z[3,2,1]  R1549     4.6589708328247070e-01
    z[3,2,1]  R1550     2.6285877823829651e-01
    z[3,2,1]  R1551     -6.7508494853973389e-01
    z[3,2,1]  R1552     1.6986043751239777e-01
    z[3,2,1]  R1553     2.1678008139133453e-01
    z[3,2,1]  R1554     3.9897006750106812e-01
    z[3,2,1]  R1555     -5.8968192338943481e-01
    z[3,2,1]  R1556     -3.4183096885681152e-01
    z[3,2,1]  R1557     4.7175630927085876e-01
    z[3,2,1]  R1558     3.5226395726203918e-01
    z[3,2,1]  R1559     -5.9667944908142090e-01
    z[3,2,1]  R1560     7.0538794994354248e-01
    z[3,2,1]  R1561     4.2998516000807285e-03
    z[3,2,1]  R1562     2.9723146557807922e-01
    z[3,2,1]  R1563     -7.9067003726959229e-01
    z[3,2,1]  R1564     -6.1674386262893677e-01
    z[3,2,1]  R1565     -7.6167237758636475e-01
    z[3,2,1]  R1566     2.6183715462684631e-01
    z[3,2,1]  R1567     1.2515960633754730e-01
    z[3,2,1]  R1568     1.2852229177951813e-01
    z[3,2,1]  R1569     1.3192021846771240e-01
    z[3,2,1]  R1570     1.3427737355232239e-01
    z[3,2,1]  R1571     2.9381850361824036e-01
    z[3,2,1]  R1572     2.6272362470626831e-01
    z[3,2,1]  R1573     2.7838566899299622e-01
    z[3,2,1]  R1574     0.0289725624024868
    z[3,2,1]  R1575     1.6979511082172394e-01
    z[3,2,1]  R1576     -1.5205812454223633e-01
    z[3,2,1]  R1577     -7.9524502158164978e-02
    z[3,2,1]  R1578     -1.6653977334499359e-01
    z[3,2,1]  R1579     1.5908463299274445e-01
    z[3,2,1]  R1580     2.7467915788292885e-02
    z[3,2,1]  R1581     5.4951891303062439e-02
    z[3,2,1]  R1582     -1.2749743461608887e-01
    z[3,2,1]  R1583     2.0110078155994415e-01
    z[3,2,1]  R1584     5.5249649286270142e-01
    z[3,2,1]  R1585     2.2371090948581696e-01
    z[3,2,1]  R1586     6.5280801057815552e-01
    z[3,2,1]  R1587     7.8022551536560059e-01
    z[3,2,1]  R1588     7.9881119728088379e-01
    z[3,2,1]  R1589     7.9810267686843872e-01
    z[3,2,1]  R1590     7.5457632541656494e-01
    z[3,2,1]  R1591     4.2455622553825378e-01
    z[3,2,1]  R1592     0.75604248046875
    z[3,2,1]  R1593     -6.7479032278060913e-01
    z[3,2,1]  R1594     6.9095867872238159e-01
    z[3,2,1]  R1595     6.1447185277938843e-01
    z[3,2,1]  R1596     8.6421352624893188e-01
    z[3,2,1]  R1597     4.7324925661087036e-01
    z[3,2,1]  R1598     2.4629727005958557e-01
    z[3,2,1]  R1599     7.4058568477630615e-01
    z[3,2,1]  R1600     4.1735228896141052e-01
    z[3,2,1]  R1601     6.4956108108162880e-03
    z[3,2,1]  R1602     5.5962300300598145e-01
    z[3,2,1]  R1603     3.7149465084075928e-01
    z[3,2,1]  R1604     1.1038370430469513e-01
    z[3,2,1]  R1605     1.7028903961181641e-01
    z[3,2,1]  R1606     2.2072924673557281e-01
    z[3,2,1]  R1607     -3.6806592345237732e-01
    z[3,2,1]  R1608     3.4903371334075928e-01
    z[3,2,1]  R1609     1.3836197555065155e-01
    z[3,2,1]  R1610     2.5078263878822327e-01
    z[3,2,1]  R1611     -2.9295665025711060e-01
    z[3,2,1]  R1612     7.8041791915893555e-02
    z[3,2,1]  R1613     -1.7975407838821411e-01
    z[3,2,1]  R1614     6.8886220455169678e-02
    z[3,2,1]  R1615     -5.4082065820693970e-01
    z[3,2,1]  R1616     5.5137449502944946e-01
    z[3,2,1]  R1617     6.7315852642059326e-01
    z[3,2,1]  R1618     0.659210205078125
    z[3,2,1]  R1619     -5.2719074487686157e-01
    z[3,2,1]  R1620     2.4181348085403442e-01
    z[3,2,1]  R1621     5.4068428277969360e-01
    z[3,2,1]  R1622     -2.0332334935665131e-01
    z[3,2,1]  R1623     -3.8963535428047180e-01
    z[3,2,1]  R1624     2.2602890431880951e-01
    z[3,2,1]  R1625     4.3761026114225388e-02
    z[3,2,1]  R1626     7.8564041852951050e-01
    z[3,2,1]  R1627     9.6119928359985352e-01
    z[3,2,1]  R1628     -1.9524261355400085e-01
    z[3,2,1]  R1629     3.3782741427421570e-01
    z[3,2,1]  R1630     2.0614726468920708e-02
    z[3,2,1]  R1631     1.4211824536323547e-01
    z[3,2,1]  R1632     1.4025595784187317e-01
    z[3,2,1]  R1633     1.0417796671390533e-02
    z[3,2,1]  R1634     6.0442048124969006e-03
    z[3,2,1]  R1635     5.0666470080614090e-02
    z[3,2,2]  R22       1
    z[3,2,2]  R31       -1
    z[3,2,2]  R1506     -1
    z[3,2,2]  R1507     1
    z[3,2,2]  R1516     4.5610967278480530e-01
    z[3,2,2]  R1517     7.2723752260208130e-01
    z[3,2,2]  R1518     6.2211388349533081e-01
    z[3,2,2]  R1519     5.7556253671646118e-01
    z[3,2,2]  R1520     8.0174314975738525e-01
    z[3,2,2]  R1521     8.3931821584701538e-01
    z[3,2,2]  R1522     5.7860833406448364e-01
    z[3,2,2]  R1523     0.478883296251297
    z[3,2,2]  R1524     8.1344491243362427e-01
    z[3,2,2]  R1525     -1.3029029965400696e-01
    z[3,2,2]  R1526     3.6529386043548584e-01
    z[3,2,2]  R1527     -7.3588892817497253e-02
    z[3,2,2]  R1528     -7.9887341707944870e-03
    z[3,2,2]  R1529     3.0230340361595154e-01
    z[3,2,2]  R1530     -8.7450090795755386e-03
    z[3,2,2]  R1531     1.2384080886840820e-01
    z[3,2,2]  R1532     -2.7143737673759460e-01
    z[3,2,2]  R1533     4.9015095829963684e-01
    z[3,2,2]  R1534     1.3233336806297302e-01
    z[3,2,2]  R1535     2.1167699992656708e-01
    z[3,2,2]  R1536     3.8264417648315430e-01
    z[3,2,2]  R1537     -4.5903384685516357e-01
    z[3,2,2]  R1538     -3.2446146011352539e-01
    z[3,2,2]  R1539     6.1088603734970093e-01
    z[3,2,2]  R1540     -2.3093193769454956e-01
    z[3,2,2]  R1541     -2.0680993795394897e-01
    z[3,2,2]  R1542     -2.2038353979587555e-01
    z[3,2,2]  R1543     -3.2932776212692261e-01
    z[3,2,2]  R1544     1.2431084178388119e-02
    z[3,2,2]  R1545     1.3812695443630219e-01
    z[3,2,2]  R1546     -1.7673003673553467e-01
    z[3,2,2]  R1547     -2.7781981974840164e-02
    z[3,2,2]  R1548     0.786723792552948
    z[3,2,2]  R1549     3.7132492661476135e-01
    z[3,2,2]  R1550     0.637035071849823
    z[3,2,2]  R1551     3.1422367691993713e-01
    z[3,2,2]  R1552     -6.4259529113769531e-01
    z[3,2,2]  R1553     -1.5603120438754559e-02
    z[3,2,2]  R1554     -7.8586585819721222e-02
    z[3,2,2]  R1555     4.0035453438758850e-01
    z[3,2,2]  R1556     3.4176030755043030e-01
    z[3,2,2]  R1557     0.506028950214386
    z[3,2,2]  R1558     7.6748108863830566e-01
    z[3,2,2]  R1559     4.5889499783515930e-01
    z[3,2,2]  R1560     3.6169582605361938e-01
    z[3,2,2]  R1561     -2.3964995145797729e-01
    z[3,2,2]  R1562     -2.5926128029823303e-01
    z[3,2,2]  R1563     -1.9634471833705902e-01
    z[3,2,2]  R1564     -8.9689306914806366e-02
    z[3,2,2]  R1565     -6.3595935702323914e-02
    z[3,2,2]  R1566     3.6763572692871094e-01
    z[3,2,2]  R1567     5.0276148319244385e-01
    z[3,2,2]  R1568     4.0322843194007874e-01
    z[3,2,2]  R1569     7.4868232011795044e-01
    z[3,2,2]  R1570     3.0692771077156067e-01
    z[3,2,2]  R1571     5.9499907493591309e-01
    z[3,2,2]  R1572     2.4867615103721619e-01
    z[3,2,2]  R1573     1.8500684201717377e-01
    z[3,2,2]  R1574     2.3874540627002716e-01
    z[3,2,2]  R1575     1.6469387337565422e-02
    z[3,2,2]  R1576     -1.2445499747991562e-01
    z[3,2,2]  R1577     -5.9227406978607178e-02
    z[3,2,2]  R1578     -2.6088374853134155e-01
    z[3,2,2]  R1579     -2.1865636110305786e-01
    z[3,2,2]  R1580     -1.8037162721157074e-01
    z[3,2,2]  R1581     -1.7247246205806732e-01
    z[3,2,2]  R1582     -1.3899783790111542e-01
    z[3,2,2]  R1583     -1.1080551892518997e-01
    z[3,2,2]  R1584     3.9775538444519043e-01
    z[3,2,2]  R1585     1.1231323704123497e-02
    z[3,2,2]  R1586     6.5868055820465088e-01
    z[3,2,2]  R1587     -3.1474792957305908e-01
    z[3,2,2]  R1588     -1.2175311893224716e-01
    z[3,2,2]  R1589     3.3148422837257385e-01
    z[3,2,2]  R1590     5.1093317568302155e-02
    z[3,2,2]  R1591     1.1504931002855301e-01
    z[3,2,2]  R1592     2.0345918834209442e-01
    z[3,2,2]  R1593     -3.6418372392654419e-01
    z[3,2,2]  R1594     4.0174335241317749e-02
    z[3,2,2]  R1595     3.8252830505371094e-01
    z[3,2,2]  R1596     7.0580348372459412e-02
    z[3,2,2]  R1597     4.1537332534790039e-01
    z[3,2,2]  R1598     2.3485516011714935e-01
    z[3,2,2]  R1599     2.5643357634544373e-01
    z[3,2,2]  R1600     1.4694970101118088e-02
    z[3,2,2]  R1601     5.9880863875150681e-02
    z[3,2,2]  R1602     4.0238484740257263e-01
    z[3,2,2]  R1603     2.3903700709342957e-01
    z[3,2,2]  R1604     5.0364041328430176e-01
    z[3,2,2]  R1605     0.0140965785831213
    z[3,2,2]  R1606     2.2510248422622681e-01
    z[3,2,2]  R1607     3.5488355159759521e-01
    z[3,2,2]  R1608     4.5670631527900696e-01
    z[3,2,2]  R1609     2.7176254987716675e-01
    z[3,2,2]  R1610     -1.1318792402744293e-01
    z[3,2,2]  R1611     0.557110071182251
    z[3,2,2]  R1612     -2.2380405664443970e-01
    z[3,2,2]  R1613     -3.2381752133369446e-01
    z[3,2,2]  R1614     -5.3149497509002686e-01
    z[3,2,2]  R1615     2.5458261370658875e-01
    z[3,2,2]  R1616     4.8929756879806519e-01
    z[3,2,2]  R1617     2.9072421789169312e-01
    z[3,2,2]  R1618     3.0683067440986633e-01
    z[3,2,2]  R1619     2.2289778292179108e-01
    z[3,2,2]  R1620     3.3935952186584473e-01
    z[3,2,2]  R1621     -1.2604791671037674e-02
    z[3,2,2]  R1622     6.5620934963226318e-01
    z[3,2,2]  R1623     1.1383425444364548e-01
    z[3,2,2]  R1624     -3.6569130420684814e-01
    z[3,2,2]  R1625     -5.3163391351699829e-01
    z[3,2,2]  R1626     6.4521101303398609e-03
    z[3,2,2]  R1627     2.0284524559974670e-01
    z[3,2,2]  R1628     1.3467849232256413e-02
    z[3,2,2]  R1629     -1.1188992857933044e-01
    z[3,2,2]  R1630     -1.0982112586498260e-01
    z[3,2,2]  R1631     -3.9222124218940735e-01
    z[3,2,2]  R1632     -1.0817139595746994e-01
    z[3,2,2]  R1633     -2.4090123176574707e-01
    z[3,2,2]  R1634     -3.3334711194038391e-01
    z[3,2,2]  R1635     -1.6649633646011353e-01
    z[3,2,3]  R23       1
    z[3,2,3]  R32       -1
    z[3,2,3]  R1508     -1
    z[3,2,3]  R1509     1
    z[3,2,3]  R1516     -4.4812297821044922e-01
    z[3,2,3]  R1517     -4.4923420995473862e-02
    z[3,2,3]  R1518     -4.2484471201896667e-01
    z[3,2,3]  R1519     -4.7857820987701416e-01
    z[3,2,3]  R1520     -2.6240247488021851e-01
    z[3,2,3]  R1521     -3.1512993574142456e-01
    z[3,2,3]  R1522     -1.4631706476211548e-01
    z[3,2,3]  R1523     7.6103769242763519e-02
    z[3,2,3]  R1524     2.7971621602773666e-02
    z[3,2,3]  R1525     5.8904254436492920e-01
    z[3,2,3]  R1526     -1.5220357477664948e-01
    z[3,2,3]  R1527     -2.0829458534717560e-01
    z[3,2,3]  R1528     -1.7938715219497681e-01
    z[3,2,3]  R1529     -1.8934619426727295e-01
    z[3,2,3]  R1530     -1.1781907081604004e-01
    z[3,2,3]  R1531     -1.9135364890098572e-01
    z[3,2,3]  R1532     -1.6161556541919708e-01
    z[3,2,3]  R1533     1.6730929911136627e-01
    z[3,2,3]  R1534     -8.9101351797580719e-02
    z[3,2,3]  R1535     1.0480973869562149e-01
    z[3,2,3]  R1536     -4.8682615160942078e-01
    z[3,2,3]  R1537     1.2215206027030945e-01
    z[3,2,3]  R1538     8.9465126395225525e-02
    z[3,2,3]  R1539     4.0796884894371033e-01
    z[3,2,3]  R1540     5.4777670651674271e-02
    z[3,2,3]  R1541     1.8457730114459991e-01
    z[3,2,3]  R1542     -2.2198373079299927e-01
    z[3,2,3]  R1543     4.9443040043115616e-02
    z[3,2,3]  R1544     -2.6664443314075470e-02
    z[3,2,3]  R1545     -1.3641602359712124e-02
    z[3,2,3]  R1546     2.0883357524871826e-01
    z[3,2,3]  R1547     5.9276979416608810e-02
    z[3,2,3]  R1548     -3.7302502989768982e-01
    z[3,2,3]  R1549     -2.2553491592407227e-01
    z[3,2,3]  R1550     -2.6345416903495789e-01
    z[3,2,3]  R1551     -5.7021226733922958e-02
    z[3,2,3]  R1552     -1.4604070782661438e-01
    z[3,2,3]  R1553     7.3949128389358521e-01
    z[3,2,3]  R1554     -7.7378368377685547e-01
    z[3,2,3]  R1555     -3.0501747131347656e-01
    z[3,2,3]  R1556     1.3053485751152039e-01
    z[3,2,3]  R1557     -4.6720156073570251e-01
    z[3,2,3]  R1558     -3.7617179751396179e-01
    z[3,2,3]  R1559     -2.5443825125694275e-01
    z[3,2,3]  R1560     1.4944136142730713e-01
    z[3,2,3]  R1561     -2.1485966444015503e-01
    z[3,2,3]  R1562     -0.361503541469574
    z[3,2,3]  R1563     4.0918534994125366e-01
    z[3,2,3]  R1564     2.1533244848251343e-01
    z[3,2,3]  R1565     9.3500562012195587e-02
    z[3,2,3]  R1566     -4.3263632059097290e-01
    z[3,2,3]  R1567     2.5042481720447540e-02
    z[3,2,3]  R1568     -4.2622995376586914e-01
    z[3,2,3]  R1569     -5.7466577738523483e-02
    z[3,2,3]  R1570     -5.3164166212081909e-01
    z[3,2,3]  R1571     3.1246626377105713e-01
    z[3,2,3]  R1572     -5.5094385147094727e-01
    z[3,2,3]  R1573     -0.40092933177948
    z[3,2,3]  R1574     -6.2547224760055542e-01
    z[3,2,3]  R1575     -7.6631426811218262e-01
    z[3,2,3]  R1576     2.3308290541172028e-01
    z[3,2,3]  R1577     2.9692972078919411e-02
    z[3,2,3]  R1578     2.6940426230430603e-01
    z[3,2,3]  R1579     1.7415495216846466e-01
    z[3,2,3]  R1580     3.1819683313369751e-01
    z[3,2,3]  R1581     5.3033941984176636e-01
    z[3,2,3]  R1582     3.8401737809181213e-01
    z[3,2,3]  R1583     -1.0256312042474747e-01
    z[3,2,3]  R1584     -5.0864759832620621e-02
    z[3,2,3]  R1585     -0.0514921173453331
    z[3,2,3]  R1586     -9.6945770084857941e-02
    z[3,2,3]  R1587     -3.2277530431747437e-01
    z[3,2,3]  R1588     -4.6569815278053284e-01
    z[3,2,3]  R1589     -0.0725424587726593
    z[3,2,3]  R1590     -3.9748242497444153e-01
    z[3,2,3]  R1591     -5.6378829479217529e-01
    z[3,2,3]  R1592     -1.6360698640346527e-01
    z[3,2,3]  R1593     0.019247991964221
    z[3,2,3]  R1594     3.5277467966079712e-01
    z[3,2,3]  R1595     -2.1244628727436066e-01
    z[3,2,3]  R1596     2.7281701564788818e-01
    z[3,2,3]  R1597     -5.0979810953140259e-01
    z[3,2,3]  R1598     -1.8456967175006866e-01
    z[3,2,3]  R1599     -5.4723761975765228e-02
    z[3,2,3]  R1600     1.6110248863697052e-01
    z[3,2,3]  R1601     7.1737951040267944e-01
    z[3,2,3]  R1602     -1.8594120442867279e-01
    z[3,2,3]  R1603     -3.9094543457031250e-01
    z[3,2,3]  R1604     -7.6074379682540894e-01
    z[3,2,3]  R1605     -2.7185940742492676e-01
    z[3,2,3]  R1606     -0.0397600419819355
    z[3,2,3]  R1607     2.2943362593650818e-01
    z[3,2,3]  R1608     0.170019268989563
    z[3,2,3]  R1609     -3.5385897755622864e-01
    z[3,2,3]  R1610     -7.9710179567337036e-01
    z[3,2,3]  R1611     -8.9688166975975037e-02
    z[3,2,3]  R1612     2.5888478755950928e-01
    z[3,2,3]  R1613     -3.3545407652854919e-01
    z[3,2,3]  R1614     3.4856066107749939e-01
    z[3,2,3]  R1615     -3.1090533733367920e-01
    z[3,2,3]  R1616     -4.2504701018333435e-01
    z[3,2,3]  R1617     2.8435248136520386e-01
    z[3,2,3]  R1618     7.5182348489761353e-02
    z[3,2,3]  R1619     -0.473027765750885
    z[3,2,3]  R1620     1.7170520126819611e-01
    z[3,2,3]  R1621     -4.4786918163299561e-01
    z[3,2,3]  R1622     -3.2597610354423523e-01
    z[3,2,3]  R1623     2.5695970654487610e-01
    z[3,2,3]  R1624     2.4426120519638062e-01
    z[3,2,3]  R1625     -1.5772333741188049e-01
    z[3,2,3]  R1626     -5.2296411991119385e-01
    z[3,2,3]  R1627     -2.4884739890694618e-02
    z[3,2,3]  R1628     -2.5975972414016724e-02
    z[3,2,3]  R1629     -0.484904021024704
    z[3,2,3]  R1630     -1.0325936228036880e-01
    z[3,2,3]  R1631     1.7387378215789795e-01
    z[3,2,3]  R1632     4.1590014100074768e-01
    z[3,2,3]  R1633     1.8978017568588257e-01
    z[3,2,3]  R1634     5.8795613050460815e-01
    z[3,2,3]  R1635     3.6701145768165588e-01
    z[3,2,4]  R24       1
    z[3,2,4]  R33       -1
    z[3,2,4]  R1510     -1
    z[3,2,4]  R1511     1
    z[3,2,4]  R1516     -1.6152805089950562e-01
    z[3,2,4]  R1517     4.1991356760263443e-02
    z[3,2,4]  R1518     3.3569493889808655e-01
    z[3,2,4]  R1519     1.6924628615379333e-01
    z[3,2,4]  R1520     5.1765460520982742e-03
    z[3,2,4]  R1521     -1.7421782016754150e-02
    z[3,2,4]  R1522     2.0205074548721313e-01
    z[3,2,4]  R1523     1.7253243923187256e-01
    z[3,2,4]  R1524     -6.7176230251789093e-02
    z[3,2,4]  R1525     5.7344906032085419e-02
    z[3,2,4]  R1526     3.2965913414955139e-01
    z[3,2,4]  R1527     2.4692562222480774e-01
    z[3,2,4]  R1528     3.2463434338569641e-01
    z[3,2,4]  R1529     5.8428615331649780e-01
    z[3,2,4]  R1530     6.2384980916976929e-01
    z[3,2,4]  R1531     -1.5458887815475464e-01
    z[3,2,4]  R1532     4.6523067355155945e-01
    z[3,2,4]  R1533     -2.9821535944938660e-01
    z[3,2,4]  R1534     -2.2359816730022430e-01
    z[3,2,4]  R1535     -2.7855536341667175e-01
    z[3,2,4]  R1536     -1.0852883569896221e-02
    z[3,2,4]  R1537     2.2692683339118958e-01
    z[3,2,4]  R1538     5.1973837614059448e-01
    z[3,2,4]  R1539     2.7637824416160583e-01
    z[3,2,4]  R1540     3.6246275901794434e-01
    z[3,2,4]  R1541     -1.7918980121612549e-01
    z[3,2,4]  R1542     5.1530379056930542e-01
    z[3,2,4]  R1543     -0.562545120716095
    z[3,2,4]  R1544     -3.1120110303163528e-02
    z[3,2,4]  R1545     1.0847674310207367e-01
    z[3,2,4]  R1546     2.0253743231296539e-01
    z[3,2,4]  R1547     -2.9733717441558838e-01
    z[3,2,4]  R1548     4.4139493256807327e-03
    z[3,2,4]  R1549     2.4505078792572021e-01
    z[3,2,4]  R1550     4.6307435631752014e-01
    z[3,2,4]  R1551     3.7557664513587952e-01
    z[3,2,4]  R1552     -1.9396117329597473e-01
    z[3,2,4]  R1553     3.1712433695793152e-01
    z[3,2,4]  R1554     -3.1650328636169434e-01
    z[3,2,4]  R1555     -5.8611828833818436e-02
    z[3,2,4]  R1556     4.7082599997520447e-01
    z[3,2,4]  R1557     2.4481488764286041e-01
    z[3,2,4]  R1558     1.4100854098796844e-01
    z[3,2,4]  R1559     -1.5714994072914124e-01
    z[3,2,4]  R1560     -3.3327883481979370e-01
    z[3,2,4]  R1561     7.1202528476715088e-01
    z[3,2,4]  R1562     1.9729733467102051e-01
    z[3,2,4]  R1563     -0.0475076325237751
    z[3,2,4]  R1564     5.0383579218760133e-04
    z[3,2,4]  R1565     -6.9557175040245056e-02
    z[3,2,4]  R1566     5.4722440242767334e-01
    z[3,2,4]  R1567     1.4803525805473328e-01
    z[3,2,4]  R1568     3.9918571710586548e-01
    z[3,2,4]  R1569     1.5126839280128479e-01
    z[3,2,4]  R1570     1.6763398051261902e-01
    z[3,2,4]  R1571     0.407213419675827
    z[3,2,4]  R1572     1.0990818589925766e-01
    z[3,2,4]  R1573     4.3967992067337036e-01
    z[3,2,4]  R1574     3.0011904239654541e-01
    z[3,2,4]  R1575     2.4865177273750305e-01
    z[3,2,4]  R1576     -4.3187049031257629e-01
    z[3,2,4]  R1577     -2.8873729705810547e-01
    z[3,2,4]  R1578     -2.5547134876251221e-01
    z[3,2,4]  R1579     -4.5111125707626343e-01
    z[3,2,4]  R1580     1.2408773601055145e-01
    z[3,2,4]  R1581     -5.2206343412399292e-01
    z[3,2,4]  R1582     -5.4761254787445068e-01
    z[3,2,4]  R1583     -3.4461638331413269e-01
    z[3,2,4]  R1584     -4.5211181044578552e-01
    z[3,2,4]  R1585     -0.165044367313385
    z[3,2,4]  R1586     1.5875680744647980e-01
    z[3,2,4]  R1587     1.3715524971485138e-01
    z[3,2,4]  R1588     -2.2346515953540802e-01
    z[3,2,4]  R1589     -4.1759216785430908e-01
    z[3,2,4]  R1590     -3.9751854538917542e-01
    z[3,2,4]  R1591     1.7852714657783508e-01
    z[3,2,4]  R1592     -1.8352989852428436e-01
    z[3,2,4]  R1593     -0.0141184376552701
    z[3,2,4]  R1594     4.5318210124969482e-01
    z[3,2,4]  R1595     -1.0221090167760849e-01
    z[3,2,4]  R1596     3.0856120586395264e-01
    z[3,2,4]  R1597     1.4820776879787445e-01
    z[3,2,4]  R1598     -3.0214396119117737e-01
    z[3,2,4]  R1599     -2.6687222719192505e-01
    z[3,2,4]  R1600     7.0675933361053467e-01
    z[3,2,4]  R1601     1.2677582912147045e-02
    z[3,2,4]  R1602     -4.4618183746933937e-03
    z[3,2,4]  R1603     1.7956745624542236e-01
    z[3,2,4]  R1604     2.4438561499118805e-01
    z[3,2,4]  R1605     9.0185302495956421e-01
    z[3,2,4]  R1606     2.7694925665855408e-01
    z[3,2,4]  R1607     2.9913464188575745e-01
    z[3,2,4]  R1608     0.59245765209198
    z[3,2,4]  R1609     8.3373981714248657e-01
    z[3,2,4]  R1610     3.6104089021682739e-01
    z[3,2,4]  R1611     6.1061972379684448e-01
    z[3,2,4]  R1612     -5.5673813819885254e-01
    z[3,2,4]  R1613     -2.3355101048946381e-01
    z[3,2,4]  R1614     -1.0546758770942688e-01
    z[3,2,4]  R1615     -4.9160704016685486e-01
    z[3,2,4]  R1616     1.6739736497402191e-01
    z[3,2,4]  R1617     5.1879614591598511e-01
    z[3,2,4]  R1618     4.8258817195892334e-01
    z[3,2,4]  R1619     2.2869048640131950e-02
    z[3,2,4]  R1620     -2.2212823852896690e-02
    z[3,2,4]  R1621     3.4187096357345581e-01
    z[3,2,4]  R1622     -2.4101753532886505e-01
    z[3,2,4]  R1623     -3.0958282947540283e-01
    z[3,2,4]  R1624     -4.0877389907836914e-01
    z[3,2,4]  R1625     -1.7188343405723572e-01
    z[3,2,4]  R1626     1.6331204771995544e-01
    z[3,2,4]  R1627     -1.7008937895298004e-02
    z[3,2,4]  R1628     -6.5068101882934570e-01
    z[3,2,4]  R1629     5.6897652149200439e-01
    z[3,2,4]  R1630     2.3531997203826904e-01
    z[3,2,4]  R1631     -2.8548237681388855e-01
    z[3,2,4]  R1632     -2.5689691305160522e-01
    z[3,2,4]  R1633     -1.4262603223323822e-01
    z[3,2,4]  R1634     -8.4751576185226440e-02
    z[3,2,4]  R1635     -1.4050680398941040e-01
    z[3,2,5]  R25       1
    z[3,2,5]  R34       -1
    z[3,2,5]  R1512     -1
    z[3,2,5]  R1513     1
    z[3,2,5]  R1516     -5.7792407274246216e-01
    z[3,2,5]  R1517     -4.2808058857917786e-01
    z[3,2,5]  R1518     -2.9734271764755249e-01
    z[3,2,5]  R1519     -2.8148514032363892e-01
    z[3,2,5]  R1520     -2.7915477752685547e-02
    z[3,2,5]  R1521     -7.9293444752693176e-02
    z[3,2,5]  R1522     -8.4606327116489410e-02
    z[3,2,5]  R1523     9.9117174744606018e-02
    z[3,2,5]  R1524     1.6980433836579323e-02
    z[3,2,5]  R1525     1.7489799857139587e-01
    z[3,2,5]  R1526     2.8112211823463440e-01
    z[3,2,5]  R1527     5.8897435665130615e-02
    z[3,2,5]  R1528     -1.9705721735954285e-01
    z[3,2,5]  R1529     2.7261313796043396e-01
    z[3,2,5]  R1530     4.2434221506118774e-01
    z[3,2,5]  R1531     -1.7677873373031616e-01
    z[3,2,5]  R1532     -1.4201782643795013e-01
    z[3,2,5]  R1533     2.5592403486371040e-02
    z[3,2,5]  R1534     -3.0416905879974365e-01
    z[3,2,5]  R1535     -0.000569283205550164
    z[3,2,5]  R1536     -1.0047782957553864e-01
    z[3,2,5]  R1537     -4.3988370895385742e-01
    z[3,2,5]  R1538     -2.9304248094558716e-01
    z[3,2,5]  R1539     2.9010564088821411e-02
    z[3,2,5]  R1540     -2.3519793152809143e-01
    z[3,2,5]  R1541     -7.7569890022277832e-01
    z[3,2,5]  R1542     -1.2172938138246536e-01
    z[3,2,5]  R1543     -4.7232115268707275e-01
    z[3,2,5]  R1544     -9.4048053026199341e-02
    z[3,2,5]  R1545     -3.5687930881977081e-02
    z[3,2,5]  R1546     -0.637411892414093
    z[3,2,5]  R1547     -6.6606724262237549e-01
    z[3,2,5]  R1548     -3.1793776154518127e-01
    z[3,2,5]  R1549     -2.8903603553771973e-01
    z[3,2,5]  R1550     -5.9671834111213684e-02
    z[3,2,5]  R1551     5.5829092860221863e-02
    z[3,2,5]  R1552     -4.8054376244544983e-01
    z[3,2,5]  R1553     -3.7372562289237976e-01
    z[3,2,5]  R1554     -5.1018174737691879e-02
    z[3,2,5]  R1555     -0.16500224173069
    z[3,2,5]  R1556     -2.6149508357048035e-01
    z[3,2,5]  R1557     -3.9062270522117615e-01
    z[3,2,5]  R1558     -7.5355544686317444e-02
    z[3,2,5]  R1559     -1.0918852686882019e-01
    z[3,2,5]  R1560     3.1797841191291809e-01
    z[3,2,5]  R1561     6.7660994827747345e-02
    z[3,2,5]  R1562     -4.4406184554100037e-01
    z[3,2,5]  R1563     0.28211510181427
    z[3,2,5]  R1564     -3.8971409201622009e-02
    z[3,2,5]  R1565     -0.0712960958480835
    z[3,2,5]  R1566     0.0833800733089447
    z[3,2,5]  R1567     -5.6501626968383789e-01
    z[3,2,5]  R1568     -3.9174145460128784e-01
    z[3,2,5]  R1569     -2.2922298312187195e-01
    z[3,2,5]  R1570     -4.8700946569442749e-01
    z[3,2,5]  R1571     2.9084333777427673e-01
    z[3,2,5]  R1572     -6.4033287763595581e-01
    z[3,2,5]  R1573     -6.5542846918106079e-01
    z[3,2,5]  R1574     0.0578635148704052
    z[3,2,5]  R1575     -5.1316618919372559e-01
    z[3,2,5]  R1576     1.7781247198581696e-01
    z[3,2,5]  R1577     2.4892254173755646e-01
    z[3,2,5]  R1578     3.1144040822982788e-01
    z[3,2,5]  R1579     2.7869430184364319e-01
    z[3,2,5]  R1580     0.282055526971817
    z[3,2,5]  R1581     -5.0505995750427246e-02
    z[3,2,5]  R1582     -3.7204194813966751e-02
    z[3,2,5]  R1583     -8.1756219267845154e-02
    z[3,2,5]  R1584     0.0612642765045166
    z[3,2,5]  R1585     9.9795535206794739e-02
    z[3,2,5]  R1586     -2.7276474982500076e-02
    z[3,2,5]  R1587     -4.8238925635814667e-02
    z[3,2,5]  R1588     4.6981833875179291e-02
    z[3,2,5]  R1589     2.1955677866935730e-01
    z[3,2,5]  R1590     1.8834892660379410e-02
    z[3,2,5]  R1591     2.6265913248062134e-01
    z[3,2,5]  R1592     4.7365966439247131e-01
    z[3,2,5]  R1593     -5.8403289318084717e-01
    z[3,2,5]  R1594     -2.8355203568935394e-02
    z[3,2,5]  R1595     3.8093358278274536e-01
    z[3,2,5]  R1596     -1.9037359952926636e-01
    z[3,2,5]  R1597     3.4328180551528931e-01
    z[3,2,5]  R1598     -6.7727595567703247e-01
    z[3,2,5]  R1599     0.176070898771286
    z[3,2,5]  R1600     -5.2785944938659668e-01
    z[3,2,5]  R1601     -5.5261558294296265e-01
    z[3,2,5]  R1602     -2.1267484128475189e-01
    z[3,2,5]  R1603     -5.8950096368789673e-01
    z[3,2,5]  R1604     -7.9023383557796478e-02
    z[3,2,5]  R1605     1.3754327595233917e-01
    z[3,2,5]  R1606     -7.6670008897781372e-01
    z[3,2,5]  R1607     -3.0801013112068176e-01
    z[3,2,5]  R1608     4.9699175357818604e-01
    z[3,2,5]  R1609     -2.6377269625663757e-01
    z[3,2,5]  R1610     -3.1842306256294250e-01
    z[3,2,5]  R1611     -1.4775237441062927e-01
    z[3,2,5]  R1612     -4.6165534853935242e-01
    z[3,2,5]  R1613     -5.6931990385055542e-01
    z[3,2,5]  R1614     1.3387784361839294e-01
    z[3,2,5]  R1615     -2.1085444092750549e-01
    z[3,2,5]  R1616     -1.8902689218521118e-01
    z[3,2,5]  R1617     1.8010181188583374e-01
    z[3,2,5]  R1618     3.8541790843009949e-01
    z[3,2,5]  R1619     -4.8934942483901978e-01
    z[3,2,5]  R1620     -5.8389580249786377e-01
    z[3,2,5]  R1621     -4.0831071138381958e-01
    z[3,2,5]  R1622     -2.3585020005702972e-01
    z[3,2,5]  R1623     -4.0940853953361511e-01
    z[3,2,5]  R1624     -6.5990430116653442e-01
    z[3,2,5]  R1625     -7.9477471113204956e-01
    z[3,2,5]  R1626     -5.6973181664943695e-02
    z[3,2,5]  R1627     8.4464959800243378e-02
    z[3,2,5]  R1628     -4.8492497205734253e-01
    z[3,2,5]  R1629     -5.4549610614776611e-01
    z[3,2,5]  R1630     -5.8714795112609863e-01
    z[3,2,5]  R1631     -0.671748161315918
    z[3,2,5]  R1632     -2.1288812160491943e-02
    z[3,2,5]  R1633     -2.4835960566997528e-01
    z[3,2,5]  R1634     -1.7103852331638336e-01
    z[3,2,5]  R1635     4.2648389935493469e-02
    z[3,2,6]  R26       1
    z[3,2,6]  R35       -1
    z[3,2,6]  R1514     -1
    z[3,2,6]  R1515     1
    z[3,2,6]  R1516     7.4521891772747040e-02
    z[3,2,6]  R1517     -2.2464311122894287e-01
    z[3,2,6]  R1518     -2.1223948895931244e-01
    z[3,2,6]  R1519     -5.5257236957550049e-01
    z[3,2,6]  R1520     -4.8760646581649780e-01
    z[3,2,6]  R1521     0.41396364569664
    z[3,2,6]  R1522     7.3515009880065918e-01
    z[3,2,6]  R1523     4.5496222376823425e-01
    z[3,2,6]  R1524     3.8575893640518188e-01
    z[3,2,6]  R1525     -3.4354977309703827e-02
    z[3,2,6]  R1526     0.353779673576355
    z[3,2,6]  R1527     -1.5861421823501587e-01
    z[3,2,6]  R1528     0.398602157831192
    z[3,2,6]  R1529     -4.3374350666999817e-01
    z[3,2,6]  R1530     -3.6097073554992676e-01
    z[3,2,6]  R1531     2.1861669421195984e-01
    z[3,2,6]  R1532     -2.0553785562515259e-01
    z[3,2,6]  R1533     0.0370715856552124
    z[3,2,6]  R1534     -2.6596274971961975e-01
    z[3,2,6]  R1535     2.4547803401947021e-01
    z[3,2,6]  R1536     -5.9849119186401367e-01
    z[3,2,6]  R1537     -5.7676357030868530e-01
    z[3,2,6]  R1538     -4.0605217218399048e-01
    z[3,2,6]  R1539     0.247311532497406
    z[3,2,6]  R1540     6.7981898784637451e-01
    z[3,2,6]  R1541     -4.4222317636013031e-02
    z[3,2,6]  R1542     0.503506600856781
    z[3,2,6]  R1543     5.2704554796218872e-01
    z[3,2,6]  R1544     -1.3678748905658722e-01
    z[3,2,6]  R1545     8.0298632383346558e-03
    z[3,2,6]  R1546     4.7421202063560486e-01
    z[3,2,6]  R1547     3.5756975412368774e-01
    z[3,2,6]  R1548     -4.4253780506551266e-03
    z[3,2,6]  R1549     -1.8486125767230988e-01
    z[3,2,6]  R1550     1.4423312246799469e-01
    z[3,2,6]  R1551     -3.8099639117717743e-02
    z[3,2,6]  R1552     -0.118285171687603
    z[3,2,6]  R1553     -2.6165261864662170e-01
    z[3,2,6]  R1554     1.1281788349151611e-01
    z[3,2,6]  R1555     -5.3018681704998016e-02
    z[3,2,6]  R1556     -2.0261111855506897e-01
    z[3,2,6]  R1557     -2.6949328184127808e-01
    z[3,2,6]  R1558     -0.344638854265213
    z[3,2,6]  R1559     -0.314930260181427
    z[3,2,6]  R1560     -2.7806192636489868e-01
    z[3,2,6]  R1561     9.3920424580574036e-02
    z[3,2,6]  R1562     3.6387926340103149e-01
    z[3,2,6]  R1563     7.9205565154552460e-02
    z[3,2,6]  R1564     -1.4415609836578369e-01
    z[3,2,6]  R1565     -0.0653463751077652
    z[3,2,6]  R1566     5.4780679941177368e-01
    z[3,2,6]  R1567     2.0252996683120728e-01
    z[3,2,6]  R1568     -4.2021661996841431e-01
    z[3,2,6]  R1569     -0.333069384098053
    z[3,2,6]  R1570     4.3221309781074524e-01
    z[3,2,6]  R1571     4.3560647964477539e-01
    z[3,2,6]  R1572     -0.0211162306368351
    z[3,2,6]  R1573     -8.8334038853645325e-02
    z[3,2,6]  R1574     -0.672598659992218
    z[3,2,6]  R1575     -2.0423695445060730e-01
    z[3,2,6]  R1576     2.0441854000091553e-01
    z[3,2,6]  R1577     0.065752312541008
    z[3,2,6]  R1578     -2.4065662920475006e-01
    z[3,2,6]  R1579     -1.5588358044624329e-01
    z[3,2,6]  R1580     -1.9604048132896423e-01
    z[3,2,6]  R1581     1.7837767302989960e-01
    z[3,2,6]  R1582     -0.228534996509552
    z[3,2,6]  R1583     4.7620676457881927e-02
    z[3,2,6]  R1584     2.4584442377090454e-02
    z[3,2,6]  R1585     -1.9309307634830475e-01
    z[3,2,6]  R1586     -2.4188582599163055e-01
    z[3,2,6]  R1587     -1.4621366560459137e-01
    z[3,2,6]  R1588     6.7733906209468842e-02
    z[3,2,6]  R1589     -1.4885485172271729e-01
    z[3,2,6]  R1590     -2.9821133613586426e-01
    z[3,2,6]  R1591     -5.4383349418640137e-01
    z[3,2,6]  R1592     1.6138026118278503e-01
    z[3,2,6]  R1593     -1.0271550714969635e-01
    z[3,2,6]  R1594     -4.0465155243873596e-01
    z[3,2,6]  R1595     -4.9593195319175720e-01
    z[3,2,6]  R1596     2.0486150681972504e-01
    z[3,2,6]  R1597     4.4525536894798279e-01
    z[3,2,6]  R1598     -2.9589691758155823e-01
    z[3,2,6]  R1599     5.2946376800537109e-01
    z[3,2,6]  R1600     1.6983704641461372e-02
    z[3,2,6]  R1601     0.00609292509034276
    z[3,2,6]  R1602     6.0368931293487549e-01
    z[3,2,6]  R1603     3.6947453022003174e-01
    z[3,2,6]  R1604     1.9826957583427429e-01
    z[3,2,6]  R1605     5.8247018605470657e-02
    z[3,2,6]  R1606     -1.3854290544986725e-01
    z[3,2,6]  R1607     -5.9745550155639648e-01
    z[3,2,6]  R1608     1.6257208585739136e-01
    z[3,2,6]  R1609     -2.6792740449309349e-02
    z[3,2,6]  R1610     2.3442240059375763e-01
    z[3,2,6]  R1611     -2.8105893731117249e-01
    z[3,2,6]  R1612     5.3105145692825317e-01
    z[3,2,6]  R1613     5.6892484426498413e-01
    z[3,2,6]  R1614     2.6140075176954269e-02
    z[3,2,6]  R1615     2.6417341828346252e-01
    z[3,2,6]  R1616     3.8478469848632812e-01
    z[3,2,6]  R1617     -2.5064751505851746e-01
    z[3,2,6]  R1618     2.0427854359149933e-01
    z[3,2,6]  R1619     -3.9159689098596573e-02
    z[3,2,6]  R1620     4.0434777736663818e-01
    z[3,2,6]  R1621     -4.7182762622833252e-01
    z[3,2,6]  R1622     -1.4492989517748356e-02
    z[3,2,6]  R1623     -5.9795439243316650e-01
    z[3,2,6]  R1624     3.2052555680274963e-01
    z[3,2,6]  R1625     -1.2123268842697144e-01
    z[3,2,6]  R1626     2.1846349537372589e-01
    z[3,2,6]  R1627     -0.0975298061966896
    z[3,2,6]  R1628     3.3296042680740356e-01
    z[3,2,6]  R1629     1.1676558107137680e-01
    z[3,2,6]  R1630     7.0225185155868530e-01
    z[3,2,6]  R1631     4.6222487092018127e-01
    z[3,2,6]  R1632     -9.1960892081260681e-02
    z[3,2,6]  R1633     3.3916354179382324e-02
    z[3,2,6]  R1634     2.0778512954711914e-01
    z[3,2,6]  R1635     5.3824341297149658e-01
    z[3,7,0]  R29       -1
    z[3,7,0]  R65       1
    z[3,7,0]  R1636     -1
    z[3,7,0]  R1637     1
    z[3,7,0]  R1650     -4.6666866540908813e-01
    z[3,7,0]  R1651     -4.8101916909217834e-01
    z[3,7,0]  R1652     3.6464604735374451e-01
    z[3,7,0]  R1653     -1.2343242764472961e-01
    z[3,7,0]  R1654     2.0137287676334381e-01
    z[3,7,0]  R1655     -6.6487483680248260e-02
    z[3,7,0]  R1656     2.2912968695163727e-01
    z[3,7,0]  R1657     7.0204377174377441e-01
    z[3,7,0]  R1658     4.2641815543174744e-01
    z[3,7,0]  R1659     4.2145749926567078e-01
    z[3,7,0]  R1660     -1.7454244196414948e-01
    z[3,7,0]  R1661     -2.9542219638824463e-01
    z[3,7,0]  R1662     1.9577080011367798e-01
    z[3,7,0]  R1663     2.2097186744213104e-01
    z[3,7,0]  R1664     -9.4610609114170074e-02
    z[3,7,0]  R1665     1.8257792294025421e-01
    z[3,7,0]  R1666     2.8745627403259277e-01
    z[3,7,0]  R1667     2.7835810184478760e-01
    z[3,7,0]  R1668     4.2069977521896362e-01
    z[3,7,0]  R1669     3.8969895243644714e-01
    z[3,7,0]  R1670     1.0651419311761856e-01
    z[3,7,0]  R1671     -4.2810398340225220e-01
    z[3,7,0]  R1672     -4.7908496856689453e-01
    z[3,7,0]  R1673     -3.6253309249877930e-01
    z[3,7,0]  R1674     -3.5436081886291504e-01
    z[3,7,0]  R1675     -2.2043451666831970e-01
    z[3,7,0]  R1676     -4.7179442644119263e-01
    z[3,7,0]  R1677     -2.6763233542442322e-01
    z[3,7,0]  R1678     -2.1600507199764252e-02
    z[3,7,0]  R1679     1.0049605742096901e-02
    z[3,7,0]  R1680     -4.8620569705963135e-01
    z[3,7,0]  R1681     -3.5388594865798950e-01
    z[3,7,0]  R1682     1.8312826752662659e-01
    z[3,7,0]  R1683     6.4531099796295166e-01
    z[3,7,0]  R1684     4.6570557355880737e-01
    z[3,7,0]  R1685     -5.4465222358703613e-01
    z[3,7,0]  R1686     -5.0433743000030518e-01
    z[3,7,0]  R1687     -0.31179279088974
    z[3,7,0]  R1688     -3.4698817133903503e-01
    z[3,7,0]  R1689     -6.0455256700515747e-01
    z[3,7,0]  R1690     -6.4668697118759155e-01
    z[3,7,0]  R1691     1.3400086760520935e-01
    z[3,7,0]  R1692     3.2247900962829590e-02
    z[3,7,0]  R1693     -0.482546329498291
    z[3,7,0]  R1694     2.4447478353977203e-01
    z[3,7,0]  R1695     -6.1319309473037720e-01
    z[3,7,0]  R1696     -5.8756017684936523e-01
    z[3,7,0]  R1697     2.8414359688758850e-01
    z[3,7,0]  R1698     7.3682749271392822e-01
    z[3,7,0]  R1699     6.2679886817932129e-01
    z[3,7,0]  R1700     -4.1262686252593994e-01
    z[3,7,0]  R1701     -4.4748997688293457e-01
    z[3,7,0]  R1702     -2.7702760696411133e-01
    z[3,7,0]  R1703     -5.8499222993850708e-01
    z[3,7,0]  R1704     0.296770840883255
    z[3,7,0]  R1705     1.1918853968381882e-01
    z[3,7,0]  R1706     -6.9707196950912476e-01
    z[3,7,0]  R1707     -0.392225980758667
    z[3,7,0]  R1708     -4.1511037945747375e-01
    z[3,7,0]  R1709     -7.8401017189025879e-01
    z[3,7,0]  R1710     0.421558678150177
    z[3,7,0]  R1711     6.6409957408905029e-01
    z[3,7,0]  R1712     8.1438052654266357e-01
    z[3,7,0]  R1713     6.5065771341323853e-01
    z[3,7,0]  R1714     -9.8521754145622253e-02
    z[3,7,0]  R1715     1.2888480722904205e-01
    z[3,7,0]  R1716     -5.4445322602987289e-02
    z[3,7,0]  R1717     -3.6244772374629974e-02
    z[3,7,0]  R1718     4.2444523423910141e-02
    z[3,7,0]  R1719     3.8722500205039978e-01
    z[3,7,0]  R1720     5.6427884846925735e-02
    z[3,7,0]  R1721     2.6662710309028625e-01
    z[3,7,0]  R1722     -1.4506371319293976e-01
    z[3,7,0]  R1723     2.8955054283142090e-01
    z[3,7,0]  R1724     1.9331602752208710e-01
    z[3,7,0]  R1725     4.3688774108886719e-01
    z[3,7,0]  R1726     5.1895231008529663e-01
    z[3,7,0]  R1727     1.0645905137062073e-01
    z[3,7,0]  R1728     0.0852186381816864
    z[3,7,0]  R1729     2.9223784804344177e-01
    z[3,7,1]  R30       -1
    z[3,7,1]  R66       1
    z[3,7,1]  R1638     -1
    z[3,7,1]  R1639     1
    z[3,7,1]  R1650     0.0879151001572609
    z[3,7,1]  R1651     4.7405455261468887e-02
    z[3,7,1]  R1652     2.3100873827934265e-01
    z[3,7,1]  R1653     1.0602278262376785e-01
    z[3,7,1]  R1654     9.6101880073547363e-02
    z[3,7,1]  R1655     1.1773117631673813e-01
    z[3,7,1]  R1656     5.3617566823959351e-02
    z[3,7,1]  R1657     1.5947191417217255e-01
    z[3,7,1]  R1658     4.5623715966939926e-02
    z[3,7,1]  R1659     -6.5066802501678467e-01
    z[3,7,1]  R1660     7.0715248584747314e-01
    z[3,7,1]  R1661     8.7995690107345581e-01
    z[3,7,1]  R1662     7.9140859842300415e-01
    z[3,7,1]  R1663     4.6913805603981018e-01
    z[3,7,1]  R1664     5.2681702375411987e-01
    z[3,7,1]  R1665     9.0098321437835693e-01
    z[3,7,1]  R1666     7.3397314548492432e-01
    z[3,7,1]  R1667     7.5054299831390381e-01
    z[3,7,1]  R1668     7.6440131664276123e-01
    z[3,7,1]  R1669     8.0900526046752930e-01
    z[3,7,1]  R1670     4.8665517568588257e-01
    z[3,7,1]  R1671     -1.1594901233911514e-01
    z[3,7,1]  R1672     -3.6921274662017822e-01
    z[3,7,1]  R1673     -0.436531662940979
    z[3,7,1]  R1674     -4.1139650344848633e-01
    z[3,7,1]  R1675     -4.8866763710975647e-01
    z[3,7,1]  R1676     -3.8169285655021667e-01
    z[3,7,1]  R1677     -1.2255111709237099e-02
    z[3,7,1]  R1678     -9.8495864868164062e-01
    z[3,7,1]  R1679     -9.8363023996353149e-01
    z[3,7,1]  R1680     1.2871147692203522e-01
    z[3,7,1]  R1681     -4.5887687802314758e-01
    z[3,7,1]  R1682     3.2750344276428223e-01
    z[3,7,1]  R1683     4.6589708328247070e-01
    z[3,7,1]  R1684     2.6285877823829651e-01
    z[3,7,1]  R1685     -6.7508494853973389e-01
    z[3,7,1]  R1686     1.6986043751239777e-01
    z[3,7,1]  R1687     2.1678008139133453e-01
    z[3,7,1]  R1688     3.9897006750106812e-01
    z[3,7,1]  R1689     -5.8968192338943481e-01
    z[3,7,1]  R1690     -3.4183096885681152e-01
    z[3,7,1]  R1691     4.7175630927085876e-01
    z[3,7,1]  R1692     3.5226395726203918e-01
    z[3,7,1]  R1693     -5.9667944908142090e-01
    z[3,7,1]  R1694     7.0538794994354248e-01
    z[3,7,1]  R1695     4.2998516000807285e-03
    z[3,7,1]  R1696     2.9723146557807922e-01
    z[3,7,1]  R1697     -7.9067003726959229e-01
    z[3,7,1]  R1698     -6.1674386262893677e-01
    z[3,7,1]  R1699     -7.6167237758636475e-01
    z[3,7,1]  R1700     2.6827645301818848e-01
    z[3,7,1]  R1701     2.2240860760211945e-01
    z[3,7,1]  R1702     1.9253897666931152e-01
    z[3,7,1]  R1703     1.9086334109306335e-01
    z[3,7,1]  R1704     1.9250404834747314e-01
    z[3,7,1]  R1705     1.8883405625820160e-01
    z[3,7,1]  R1706     1.2418291717767715e-01
    z[3,7,1]  R1707     1.6557477414608002e-01
    z[3,7,1]  R1708     1.1393685638904572e-01
    z[3,7,1]  R1709     1.8629537522792816e-01
    z[3,7,1]  R1710     0.584402859210968
    z[3,7,1]  R1711     4.0262556076049805e-01
    z[3,7,1]  R1712     4.1548383235931396e-01
    z[3,7,1]  R1713     3.6769053339958191e-01
    z[3,7,1]  R1714     -9.5285606384277344e-01
    z[3,7,1]  R1715     -8.7817096710205078e-01
    z[3,7,1]  R1716     -9.2872285842895508e-01
    z[3,7,1]  R1717     -8.9981520175933838e-01
    z[3,7,1]  R1718     -8.2558405399322510e-01
    z[3,7,1]  R1719     -7.1877020597457886e-01
    z[3,7,1]  R1720     8.5633313655853271e-01
    z[3,7,1]  R1721     8.2666528224945068e-01
    z[3,7,1]  R1722     0.729005753993988
    z[3,7,1]  R1723     5.1801115274429321e-01
    z[3,7,1]  R1724     -9.2085808515548706e-01
    z[3,7,1]  R1725     -8.6790871620178223e-01
    z[3,7,1]  R1726     -8.1607604026794434e-01
    z[3,7,1]  R1727     -8.9879059791564941e-01
    z[3,7,1]  R1728     -9.2608416080474854e-01
    z[3,7,1]  R1729     -7.4814999103546143e-01
    z[3,7,2]  R31       -1
    z[3,7,2]  R67       1
    z[3,7,2]  R1640     -1
    z[3,7,2]  R1641     1
    z[3,7,2]  R1650     4.5610967278480530e-01
    z[3,7,2]  R1651     7.2723752260208130e-01
    z[3,7,2]  R1652     6.2211388349533081e-01
    z[3,7,2]  R1653     5.7556253671646118e-01
    z[3,7,2]  R1654     8.0174314975738525e-01
    z[3,7,2]  R1655     8.3931821584701538e-01
    z[3,7,2]  R1656     5.7860833406448364e-01
    z[3,7,2]  R1657     0.478883296251297
    z[3,7,2]  R1658     8.1344491243362427e-01
    z[3,7,2]  R1659     -1.3029029965400696e-01
    z[3,7,2]  R1660     3.6529386043548584e-01
    z[3,7,2]  R1661     -7.3588892817497253e-02
    z[3,7,2]  R1662     -7.9887341707944870e-03
    z[3,7,2]  R1663     3.0230340361595154e-01
    z[3,7,2]  R1664     -8.7450090795755386e-03
    z[3,7,2]  R1665     1.2384080886840820e-01
    z[3,7,2]  R1666     -2.7143737673759460e-01
    z[3,7,2]  R1667     4.9015095829963684e-01
    z[3,7,2]  R1668     1.3233336806297302e-01
    z[3,7,2]  R1669     2.1167699992656708e-01
    z[3,7,2]  R1670     3.8264417648315430e-01
    z[3,7,2]  R1671     -4.5903384685516357e-01
    z[3,7,2]  R1672     -3.2446146011352539e-01
    z[3,7,2]  R1673     6.1088603734970093e-01
    z[3,7,2]  R1674     -2.3093193769454956e-01
    z[3,7,2]  R1675     -2.0680993795394897e-01
    z[3,7,2]  R1676     -2.2038353979587555e-01
    z[3,7,2]  R1677     -3.2932776212692261e-01
    z[3,7,2]  R1678     1.2431084178388119e-02
    z[3,7,2]  R1679     1.3812695443630219e-01
    z[3,7,2]  R1680     -1.7673003673553467e-01
    z[3,7,2]  R1681     -2.7781981974840164e-02
    z[3,7,2]  R1682     0.786723792552948
    z[3,7,2]  R1683     3.7132492661476135e-01
    z[3,7,2]  R1684     0.637035071849823
    z[3,7,2]  R1685     3.1422367691993713e-01
    z[3,7,2]  R1686     -6.4259529113769531e-01
    z[3,7,2]  R1687     -1.5603120438754559e-02
    z[3,7,2]  R1688     -7.8586585819721222e-02
    z[3,7,2]  R1689     4.0035453438758850e-01
    z[3,7,2]  R1690     3.4176030755043030e-01
    z[3,7,2]  R1691     0.506028950214386
    z[3,7,2]  R1692     7.6748108863830566e-01
    z[3,7,2]  R1693     4.5889499783515930e-01
    z[3,7,2]  R1694     3.6169582605361938e-01
    z[3,7,2]  R1695     -2.3964995145797729e-01
    z[3,7,2]  R1696     -2.5926128029823303e-01
    z[3,7,2]  R1697     -1.9634471833705902e-01
    z[3,7,2]  R1698     -8.9689306914806366e-02
    z[3,7,2]  R1699     -6.3595935702323914e-02
    z[3,7,2]  R1700     3.9148885011672974e-01
    z[3,7,2]  R1701     2.5419646501541138e-01
    z[3,7,2]  R1702     2.5696179270744324e-01
    z[3,7,2]  R1703     2.0326870679855347e-01
    z[3,7,2]  R1704     2.8714475035667419e-01
    z[3,7,2]  R1705     7.0061689615249634e-01
    z[3,7,2]  R1706     5.8284962177276611e-01
    z[3,7,2]  R1707     6.5757888555526733e-01
    z[3,7,2]  R1708     7.7169144153594971e-01
    z[3,7,2]  R1709     2.8874278068542480e-01
    z[3,7,2]  R1710     -2.5980761647224426e-01
    z[3,7,2]  R1711     -3.2109084725379944e-01
    z[3,7,2]  R1712     -1.5883018076419830e-01
    z[3,7,2]  R1713     -5.0474941730499268e-01
    z[3,7,2]  R1714     0.051239013671875
    z[3,7,2]  R1715     -6.3232593238353729e-03
    z[3,7,2]  R1716     2.3463173210620880e-01
    z[3,7,2]  R1717     -0.0435776486992836
    z[3,7,2]  R1718     -2.7200752496719360e-01
    z[3,7,2]  R1719     -3.2253436744213104e-02
    z[3,7,2]  R1720     5.7582195848226547e-02
    z[3,7,2]  R1721     3.6205121874809265e-01
    z[3,7,2]  R1722     3.9077621698379517e-01
    z[3,7,2]  R1723     -4.3866109848022461e-01
    z[3,7,2]  R1724     -1.2892891466617584e-01
    z[3,7,2]  R1725     -2.5552364066243172e-02
    z[3,7,2]  R1726     -1.3978378474712372e-01
    z[3,7,2]  R1727     -0.405248761177063
    z[3,7,2]  R1728     1.7147357761859894e-01
    z[3,7,2]  R1729     4.5713827013969421e-01
    z[3,7,3]  R32       -1
    z[3,7,3]  R68       1
    z[3,7,3]  R1642     -1
    z[3,7,3]  R1643     1
    z[3,7,3]  R1650     -4.4812297821044922e-01
    z[3,7,3]  R1651     -4.4923420995473862e-02
    z[3,7,3]  R1652     -4.2484471201896667e-01
    z[3,7,3]  R1653     -4.7857820987701416e-01
    z[3,7,3]  R1654     -2.6240247488021851e-01
    z[3,7,3]  R1655     -3.1512993574142456e-01
    z[3,7,3]  R1656     -1.4631706476211548e-01
    z[3,7,3]  R1657     7.6103769242763519e-02
    z[3,7,3]  R1658     2.7971621602773666e-02
    z[3,7,3]  R1659     5.8904254436492920e-01
    z[3,7,3]  R1660     -1.5220357477664948e-01
    z[3,7,3]  R1661     -2.0829458534717560e-01
    z[3,7,3]  R1662     -1.7938715219497681e-01
    z[3,7,3]  R1663     -1.8934619426727295e-01
    z[3,7,3]  R1664     -1.1781907081604004e-01
    z[3,7,3]  R1665     -1.9135364890098572e-01
    z[3,7,3]  R1666     -1.6161556541919708e-01
    z[3,7,3]  R1667     1.6730929911136627e-01
    z[3,7,3]  R1668     -8.9101351797580719e-02
    z[3,7,3]  R1669     1.0480973869562149e-01
    z[3,7,3]  R1670     -4.8682615160942078e-01
    z[3,7,3]  R1671     1.2215206027030945e-01
    z[3,7,3]  R1672     8.9465126395225525e-02
    z[3,7,3]  R1673     4.0796884894371033e-01
    z[3,7,3]  R1674     5.4777670651674271e-02
    z[3,7,3]  R1675     1.8457730114459991e-01
    z[3,7,3]  R1676     -2.2198373079299927e-01
    z[3,7,3]  R1677     4.9443040043115616e-02
    z[3,7,3]  R1678     -2.6664443314075470e-02
    z[3,7,3]  R1679     -1.3641602359712124e-02
    z[3,7,3]  R1680     2.0883357524871826e-01
    z[3,7,3]  R1681     5.9276979416608810e-02
    z[3,7,3]  R1682     -3.7302502989768982e-01
    z[3,7,3]  R1683     -2.2553491592407227e-01
    z[3,7,3]  R1684     -2.6345416903495789e-01
    z[3,7,3]  R1685     -5.7021226733922958e-02
    z[3,7,3]  R1686     -1.4604070782661438e-01
    z[3,7,3]  R1687     7.3949128389358521e-01
    z[3,7,3]  R1688     -7.7378368377685547e-01
    z[3,7,3]  R1689     -3.0501747131347656e-01
    z[3,7,3]  R1690     1.3053485751152039e-01
    z[3,7,3]  R1691     -4.6720156073570251e-01
    z[3,7,3]  R1692     -3.7617179751396179e-01
    z[3,7,3]  R1693     -2.5443825125694275e-01
    z[3,7,3]  R1694     1.4944136142730713e-01
    z[3,7,3]  R1695     -2.1485966444015503e-01
    z[3,7,3]  R1696     -0.361503541469574
    z[3,7,3]  R1697     4.0918534994125366e-01
    z[3,7,3]  R1698     2.1533244848251343e-01
    z[3,7,3]  R1699     9.3500562012195587e-02
    z[3,7,3]  R1700     -4.0317773818969727e-01
    z[3,7,3]  R1701     -7.7090424019843340e-04
    z[3,7,3]  R1702     -2.3817038536071777e-01
    z[3,7,3]  R1703     -3.1208419799804688e-01
    z[3,7,3]  R1704     0.0873216912150383
    z[3,7,3]  R1705     5.0227856636047363e-01
    z[3,7,3]  R1706     -3.8150079548358917e-02
    z[3,7,3]  R1707     2.5135505199432373e-01
    z[3,7,3]  R1708     2.6715794205665588e-01
    z[3,7,3]  R1709     -3.7401530146598816e-01
    z[3,7,3]  R1710     1.3493514060974121e-01
    z[3,7,3]  R1711     -3.6330097913742065e-01
    z[3,7,3]  R1712     -2.3994803428649902e-01
    z[3,7,3]  R1713     6.6571375355124474e-03
    z[3,7,3]  R1714     -2.3104372620582581e-01
    z[3,7,3]  R1715     -3.0128198862075806e-01
    z[3,7,3]  R1716     9.7351469099521637e-02
    z[3,7,3]  R1717     -2.3369999229907990e-01
    z[3,7,3]  R1718     1.1244335025548935e-01
    z[3,7,3]  R1719     4.2713305354118347e-01
    z[3,7,3]  R1720     -9.7382143139839172e-02
    z[3,7,3]  R1721     1.3974194228649139e-01
    z[3,7,3]  R1722     6.3815057277679443e-02
    z[3,7,3]  R1723     -5.1278185844421387e-01
    z[3,7,3]  R1724     2.9160696268081665e-01
    z[3,7,3]  R1725     -1.0779995471239090e-01
    z[3,7,3]  R1726     1.3958472013473511e-01
    z[3,7,3]  R1727     -1.3942248187959194e-03
    z[3,7,3]  R1728     -7.4596926569938660e-02
    z[3,7,3]  R1729     3.2925301790237427e-01
    z[3,7,4]  R33       -1
    z[3,7,4]  R69       1
    z[3,7,4]  R1644     -1
    z[3,7,4]  R1645     1
    z[3,7,4]  R1650     -1.6152805089950562e-01
    z[3,7,4]  R1651     4.1991356760263443e-02
    z[3,7,4]  R1652     3.3569493889808655e-01
    z[3,7,4]  R1653     1.6924628615379333e-01
    z[3,7,4]  R1654     5.1765460520982742e-03
    z[3,7,4]  R1655     -1.7421782016754150e-02
    z[3,7,4]  R1656     2.0205074548721313e-01
    z[3,7,4]  R1657     1.7253243923187256e-01
    z[3,7,4]  R1658     -6.7176230251789093e-02
    z[3,7,4]  R1659     5.7344906032085419e-02
    z[3,7,4]  R1660     3.2965913414955139e-01
    z[3,7,4]  R1661     2.4692562222480774e-01
    z[3,7,4]  R1662     3.2463434338569641e-01
    z[3,7,4]  R1663     5.8428615331649780e-01
    z[3,7,4]  R1664     6.2384980916976929e-01
    z[3,7,4]  R1665     -1.5458887815475464e-01
    z[3,7,4]  R1666     4.6523067355155945e-01
    z[3,7,4]  R1667     -2.9821535944938660e-01
    z[3,7,4]  R1668     -2.2359816730022430e-01
    z[3,7,4]  R1669     -2.7855536341667175e-01
    z[3,7,4]  R1670     -1.0852883569896221e-02
    z[3,7,4]  R1671     2.2692683339118958e-01
    z[3,7,4]  R1672     5.1973837614059448e-01
    z[3,7,4]  R1673     2.7637824416160583e-01
    z[3,7,4]  R1674     3.6246275901794434e-01
    z[3,7,4]  R1675     -1.7918980121612549e-01
    z[3,7,4]  R1676     5.1530379056930542e-01
    z[3,7,4]  R1677     -0.562545120716095
    z[3,7,4]  R1678     -3.1120110303163528e-02
    z[3,7,4]  R1679     1.0847674310207367e-01
    z[3,7,4]  R1680     2.0253743231296539e-01
    z[3,7,4]  R1681     -2.9733717441558838e-01
    z[3,7,4]  R1682     4.4139493256807327e-03
    z[3,7,4]  R1683     2.4505078792572021e-01
    z[3,7,4]  R1684     4.6307435631752014e-01
    z[3,7,4]  R1685     3.7557664513587952e-01
    z[3,7,4]  R1686     -1.9396117329597473e-01
    z[3,7,4]  R1687     3.1712433695793152e-01
    z[3,7,4]  R1688     -3.1650328636169434e-01
    z[3,7,4]  R1689     -5.8611828833818436e-02
    z[3,7,4]  R1690     4.7082599997520447e-01
    z[3,7,4]  R1691     2.4481488764286041e-01
    z[3,7,4]  R1692     1.4100854098796844e-01
    z[3,7,4]  R1693     -1.5714994072914124e-01
    z[3,7,4]  R1694     -3.3327883481979370e-01
    z[3,7,4]  R1695     7.1202528476715088e-01
    z[3,7,4]  R1696     1.9729733467102051e-01
    z[3,7,4]  R1697     -0.0475076325237751
    z[3,7,4]  R1698     5.0383579218760133e-04
    z[3,7,4]  R1699     -6.9557175040245056e-02
    z[3,7,4]  R1700     0.60483717918396
    z[3,7,4]  R1701     -6.4296253025531769e-02
    z[3,7,4]  R1702     1.0830979794263840e-01
    z[3,7,4]  R1703     1.2754504382610321e-01
    z[3,7,4]  R1704     5.1302719116210938e-01
    z[3,7,4]  R1705     2.7713507413864136e-01
    z[3,7,4]  R1706     2.7354445308446884e-02
    z[3,7,4]  R1707     2.0819666981697083e-01
    z[3,7,4]  R1708     1.1473132669925690e-01
    z[3,7,4]  R1709     -3.4995445609092712e-01
    z[3,7,4]  R1710     -5.6651449203491211e-01
    z[3,7,4]  R1711     2.1771334111690521e-01
    z[3,7,4]  R1712     -5.0821971148252487e-02
    z[3,7,4]  R1713     1.8033283948898315e-01
    z[3,7,4]  R1714     -6.3421934843063354e-02
    z[3,7,4]  R1715     1.9550846517086029e-01
    z[3,7,4]  R1716     -1.7913454771041870e-01
    z[3,7,4]  R1717     -1.1474343389272690e-01
    z[3,7,4]  R1718     -4.7085419297218323e-01
    z[3,7,4]  R1719     -2.8207856416702271e-01
    z[3,7,4]  R1720     -5.1008272916078568e-02
    z[3,7,4]  R1721     2.4283653497695923e-01
    z[3,7,4]  R1722     -4.7067850828170776e-01
    z[3,7,4]  R1723     2.1497736871242523e-01
    z[3,7,4]  R1724     -6.2021367251873016e-02
    z[3,7,4]  R1725     -1.5125301480293274e-01
    z[3,7,4]  R1726     1.5340529382228851e-01
    z[3,7,4]  R1727     9.9574409425258636e-02
    z[3,7,4]  R1728     -2.3859688639640808e-01
    z[3,7,4]  R1729     1.2870885431766510e-01
    z[3,7,5]  R34       -1
    z[3,7,5]  R70       1
    z[3,7,5]  R1646     -1
    z[3,7,5]  R1647     1
    z[3,7,5]  R1650     -5.7792407274246216e-01
    z[3,7,5]  R1651     -4.2808058857917786e-01
    z[3,7,5]  R1652     -2.9734271764755249e-01
    z[3,7,5]  R1653     -2.8148514032363892e-01
    z[3,7,5]  R1654     -2.7915477752685547e-02
    z[3,7,5]  R1655     -7.9293444752693176e-02
    z[3,7,5]  R1656     -8.4606327116489410e-02
    z[3,7,5]  R1657     9.9117174744606018e-02
    z[3,7,5]  R1658     1.6980433836579323e-02
    z[3,7,5]  R1659     1.7489799857139587e-01
    z[3,7,5]  R1660     2.8112211823463440e-01
    z[3,7,5]  R1661     5.8897435665130615e-02
    z[3,7,5]  R1662     -1.9705721735954285e-01
    z[3,7,5]  R1663     2.7261313796043396e-01
    z[3,7,5]  R1664     4.2434221506118774e-01
    z[3,7,5]  R1665     -1.7677873373031616e-01
    z[3,7,5]  R1666     -1.4201782643795013e-01
    z[3,7,5]  R1667     2.5592403486371040e-02
    z[3,7,5]  R1668     -3.0416905879974365e-01
    z[3,7,5]  R1669     -0.000569283205550164
    z[3,7,5]  R1670     -1.0047782957553864e-01
    z[3,7,5]  R1671     -4.3988370895385742e-01
    z[3,7,5]  R1672     -2.9304248094558716e-01
    z[3,7,5]  R1673     2.9010564088821411e-02
    z[3,7,5]  R1674     -2.3519793152809143e-01
    z[3,7,5]  R1675     -7.7569890022277832e-01
    z[3,7,5]  R1676     -1.2172938138246536e-01
    z[3,7,5]  R1677     -4.7232115268707275e-01
    z[3,7,5]  R1678     -9.4048053026199341e-02
    z[3,7,5]  R1679     -3.5687930881977081e-02
    z[3,7,5]  R1680     -0.637411892414093
    z[3,7,5]  R1681     -6.6606724262237549e-01
    z[3,7,5]  R1682     -3.1793776154518127e-01
    z[3,7,5]  R1683     -2.8903603553771973e-01
    z[3,7,5]  R1684     -5.9671834111213684e-02
    z[3,7,5]  R1685     5.5829092860221863e-02
    z[3,7,5]  R1686     -4.8054376244544983e-01
    z[3,7,5]  R1687     -3.7372562289237976e-01
    z[3,7,5]  R1688     -5.1018174737691879e-02
    z[3,7,5]  R1689     -0.16500224173069
    z[3,7,5]  R1690     -2.6149508357048035e-01
    z[3,7,5]  R1691     -3.9062270522117615e-01
    z[3,7,5]  R1692     -7.5355544686317444e-02
    z[3,7,5]  R1693     -1.0918852686882019e-01
    z[3,7,5]  R1694     3.1797841191291809e-01
    z[3,7,5]  R1695     6.7660994827747345e-02
    z[3,7,5]  R1696     -4.4406184554100037e-01
    z[3,7,5]  R1697     0.28211510181427
    z[3,7,5]  R1698     -3.8971409201622009e-02
    z[3,7,5]  R1699     -0.0712960958480835
    z[3,7,5]  R1700     2.1369495987892151e-01
    z[3,7,5]  R1701     1.5344811603426933e-02
    z[3,7,5]  R1702     -6.4999371767044067e-01
    z[3,7,5]  R1703     -5.6228202581405640e-01
    z[3,7,5]  R1704     -2.0857641100883484e-01
    z[3,7,5]  R1705     -1.8942032754421234e-01
    z[3,7,5]  R1706     -4.2550815269351006e-03
    z[3,7,5]  R1707     5.3575128316879272e-02
    z[3,7,5]  R1708     -3.6595806479454041e-01
    z[3,7,5]  R1709     6.7329391837120056e-02
    z[3,7,5]  R1710     -2.6174557209014893e-01
    z[3,7,5]  R1711     1.4011247456073761e-01
    z[3,7,5]  R1712     -1.1286448687314987e-01
    z[3,7,5]  R1713     1.3865859806537628e-01
    z[3,7,5]  R1714     1.2577064335346222e-01
    z[3,7,5]  R1715     9.6456006169319153e-02
    z[3,7,5]  R1716     1.4606384932994843e-01
    z[3,7,5]  R1717     6.4928233623504639e-02
    z[3,7,5]  R1718     -8.9737243950366974e-02
    z[3,7,5]  R1719     2.1938440203666687e-01
    z[3,7,5]  R1720     2.6106894016265869e-01
    z[3,7,5]  R1721     -1.2218544632196426e-01
    z[3,7,5]  R1722     -6.5748314373195171e-03
    z[3,7,5]  R1723     2.5487670302391052e-01
    z[3,7,5]  R1724     -8.0740720033645630e-02
    z[3,7,5]  R1725     1.3575650751590729e-01
    z[3,7,5]  R1726     -3.7502128630876541e-02
    z[3,7,5]  R1727     -6.5509853884577751e-03
    z[3,7,5]  R1728     -1.7547595500946045e-01
    z[3,7,5]  R1729     0.0950714573264122
    z[3,7,6]  R35       -1
    z[3,7,6]  R71       1
    z[3,7,6]  R1648     -1
    z[3,7,6]  R1649     1
    z[3,7,6]  R1650     7.4521891772747040e-02
    z[3,7,6]  R1651     -2.2464311122894287e-01
    z[3,7,6]  R1652     -2.1223948895931244e-01
    z[3,7,6]  R1653     -5.5257236957550049e-01
    z[3,7,6]  R1654     -4.8760646581649780e-01
    z[3,7,6]  R1655     0.41396364569664
    z[3,7,6]  R1656     7.3515009880065918e-01
    z[3,7,6]  R1657     4.5496222376823425e-01
    z[3,7,6]  R1658     3.8575893640518188e-01
    z[3,7,6]  R1659     -3.4354977309703827e-02
    z[3,7,6]  R1660     0.353779673576355
    z[3,7,6]  R1661     -1.5861421823501587e-01
    z[3,7,6]  R1662     0.398602157831192
    z[3,7,6]  R1663     -4.3374350666999817e-01
    z[3,7,6]  R1664     -3.6097073554992676e-01
    z[3,7,6]  R1665     2.1861669421195984e-01
    z[3,7,6]  R1666     -2.0553785562515259e-01
    z[3,7,6]  R1667     0.0370715856552124
    z[3,7,6]  R1668     -2.6596274971961975e-01
    z[3,7,6]  R1669     2.4547803401947021e-01
    z[3,7,6]  R1670     -5.9849119186401367e-01
    z[3,7,6]  R1671     -5.7676357030868530e-01
    z[3,7,6]  R1672     -4.0605217218399048e-01
    z[3,7,6]  R1673     0.247311532497406
    z[3,7,6]  R1674     6.7981898784637451e-01
    z[3,7,6]  R1675     -4.4222317636013031e-02
    z[3,7,6]  R1676     0.503506600856781
    z[3,7,6]  R1677     5.2704554796218872e-01
    z[3,7,6]  R1678     -1.3678748905658722e-01
    z[3,7,6]  R1679     8.0298632383346558e-03
    z[3,7,6]  R1680     4.7421202063560486e-01
    z[3,7,6]  R1681     3.5756975412368774e-01
    z[3,7,6]  R1682     -4.4253780506551266e-03
    z[3,7,6]  R1683     -1.8486125767230988e-01
    z[3,7,6]  R1684     1.4423312246799469e-01
    z[3,7,6]  R1685     -3.8099639117717743e-02
    z[3,7,6]  R1686     -0.118285171687603
    z[3,7,6]  R1687     -2.6165261864662170e-01
    z[3,7,6]  R1688     1.1281788349151611e-01
    z[3,7,6]  R1689     -5.3018681704998016e-02
    z[3,7,6]  R1690     -2.0261111855506897e-01
    z[3,7,6]  R1691     -2.6949328184127808e-01
    z[3,7,6]  R1692     -0.344638854265213
    z[3,7,6]  R1693     -0.314930260181427
    z[3,7,6]  R1694     -2.7806192636489868e-01
    z[3,7,6]  R1695     9.3920424580574036e-02
    z[3,7,6]  R1696     3.6387926340103149e-01
    z[3,7,6]  R1697     7.9205565154552460e-02
    z[3,7,6]  R1698     -1.4415609836578369e-01
    z[3,7,6]  R1699     -0.0653463751077652
    z[3,7,6]  R1700     -1.7452044785022736e-01
    z[3,7,6]  R1701     8.2540971040725708e-01
    z[3,7,6]  R1702     -5.7376581430435181e-01
    z[3,7,6]  R1703     3.8757154345512390e-01
    z[3,7,6]  R1704     -6.9144135713577271e-01
    z[3,7,6]  R1705     -3.0708971619606018e-01
    z[3,7,6]  R1706     3.9589628577232361e-01
    z[3,7,6]  R1707     5.2624928951263428e-01
    z[3,7,6]  R1708     -2.7057321742177010e-02
    z[3,7,6]  R1709     1.8995814025402069e-02
    z[3,7,6]  R1710     -7.4864067137241364e-02
    z[3,7,6]  R1711     0.307809978723526
    z[3,7,6]  R1712     2.5697097182273865e-01
    z[3,7,6]  R1713     3.6726808547973633e-01
    z[3,7,6]  R1714     8.0694079399108887e-02
    z[3,7,6]  R1715     2.7178376913070679e-01
    z[3,7,6]  R1716     -1.2867182493209839e-01
    z[3,7,6]  R1717     -3.3929708600044250e-01
    z[3,7,6]  R1718     -1.4879697002470493e-02
    z[3,7,6]  R1719     1.4914938807487488e-01
    z[3,7,6]  R1720     4.2420718073844910e-01
    z[3,7,6]  R1721     -1.4500647783279419e-01
    z[3,7,6]  R1722     -2.6295873522758484e-01
    z[3,7,6]  R1723     -2.8509417176246643e-01
    z[3,7,6]  R1724     -5.1247671246528625e-02
    z[3,7,6]  R1725     4.7775931656360626e-02
    z[3,7,6]  R1726     -2.7299644425511360e-02
    z[3,7,6]  R1727     -8.1580407917499542e-02
    z[3,7,6]  R1728     -1.1143527925014496e-01
    z[3,7,6]  R1729     1.0900022834539413e-01
    z[7,3,0]  R29       1
    z[7,3,0]  R65       -1
    z[7,3,0]  R1730     -1
    z[7,3,0]  R1731     1
    z[7,3,0]  R1744     -4.1262686252593994e-01
    z[7,3,0]  R1745     -4.4748997688293457e-01
    z[7,3,0]  R1746     -2.7702760696411133e-01
    z[7,3,0]  R1747     -5.8499222993850708e-01
    z[7,3,0]  R1748     0.296770840883255
    z[7,3,0]  R1749     1.1918853968381882e-01
    z[7,3,0]  R1750     -6.9707196950912476e-01
    z[7,3,0]  R1751     -0.392225980758667
    z[7,3,0]  R1752     -4.1511037945747375e-01
    z[7,3,0]  R1753     -7.8401017189025879e-01
    z[7,3,0]  R1754     0.421558678150177
    z[7,3,0]  R1755     6.6409957408905029e-01
    z[7,3,0]  R1756     8.1438052654266357e-01
    z[7,3,0]  R1757     6.5065771341323853e-01
    z[7,3,0]  R1758     -9.8521754145622253e-02
    z[7,3,0]  R1759     1.2888480722904205e-01
    z[7,3,0]  R1760     -5.4445322602987289e-02
    z[7,3,0]  R1761     -3.6244772374629974e-02
    z[7,3,0]  R1762     4.2444523423910141e-02
    z[7,3,0]  R1763     3.8722500205039978e-01
    z[7,3,0]  R1764     5.6427884846925735e-02
    z[7,3,0]  R1765     2.6662710309028625e-01
    z[7,3,0]  R1766     -1.4506371319293976e-01
    z[7,3,0]  R1767     2.8955054283142090e-01
    z[7,3,0]  R1768     1.9331602752208710e-01
    z[7,3,0]  R1769     4.3688774108886719e-01
    z[7,3,0]  R1770     5.1895231008529663e-01
    z[7,3,0]  R1771     1.0645905137062073e-01
    z[7,3,0]  R1772     0.0852186381816864
    z[7,3,0]  R1773     2.9223784804344177e-01
    z[7,3,0]  R1774     -4.6666866540908813e-01
    z[7,3,0]  R1775     -4.8101916909217834e-01
    z[7,3,0]  R1776     3.6464604735374451e-01
    z[7,3,0]  R1777     -1.2343242764472961e-01
    z[7,3,0]  R1778     2.0137287676334381e-01
    z[7,3,0]  R1779     -6.6487483680248260e-02
    z[7,3,0]  R1780     2.2912968695163727e-01
    z[7,3,0]  R1781     7.0204377174377441e-01
    z[7,3,0]  R1782     4.2641815543174744e-01
    z[7,3,0]  R1783     4.2145749926567078e-01
    z[7,3,0]  R1784     -1.7454244196414948e-01
    z[7,3,0]  R1785     -2.9542219638824463e-01
    z[7,3,0]  R1786     1.9577080011367798e-01
    z[7,3,0]  R1787     2.2097186744213104e-01
    z[7,3,0]  R1788     -9.4610609114170074e-02
    z[7,3,0]  R1789     1.8257792294025421e-01
    z[7,3,0]  R1790     2.8745627403259277e-01
    z[7,3,0]  R1791     2.7835810184478760e-01
    z[7,3,0]  R1792     4.2069977521896362e-01
    z[7,3,0]  R1793     3.8969895243644714e-01
    z[7,3,0]  R1794     1.0651419311761856e-01
    z[7,3,0]  R1795     -4.2810398340225220e-01
    z[7,3,0]  R1796     -4.7908496856689453e-01
    z[7,3,0]  R1797     -3.6253309249877930e-01
    z[7,3,0]  R1798     -3.5436081886291504e-01
    z[7,3,0]  R1799     -2.2043451666831970e-01
    z[7,3,0]  R1800     -4.7179442644119263e-01
    z[7,3,0]  R1801     -2.6763233542442322e-01
    z[7,3,0]  R1802     -2.1600507199764252e-02
    z[7,3,0]  R1803     1.0049605742096901e-02
    z[7,3,0]  R1804     -4.8620569705963135e-01
    z[7,3,0]  R1805     -3.5388594865798950e-01
    z[7,3,0]  R1806     1.8312826752662659e-01
    z[7,3,0]  R1807     6.4531099796295166e-01
    z[7,3,0]  R1808     4.6570557355880737e-01
    z[7,3,0]  R1809     -5.4465222358703613e-01
    z[7,3,0]  R1810     -5.0433743000030518e-01
    z[7,3,0]  R1811     -0.31179279088974
    z[7,3,0]  R1812     -3.4698817133903503e-01
    z[7,3,0]  R1813     -6.0455256700515747e-01
    z[7,3,0]  R1814     -6.4668697118759155e-01
    z[7,3,0]  R1815     1.3400086760520935e-01
    z[7,3,0]  R1816     3.2247900962829590e-02
    z[7,3,0]  R1817     -0.482546329498291
    z[7,3,0]  R1818     2.4447478353977203e-01
    z[7,3,0]  R1819     -6.1319309473037720e-01
    z[7,3,0]  R1820     -5.8756017684936523e-01
    z[7,3,0]  R1821     2.8414359688758850e-01
    z[7,3,0]  R1822     7.3682749271392822e-01
    z[7,3,0]  R1823     6.2679886817932129e-01
    z[7,3,1]  R30       1
    z[7,3,1]  R66       -1
    z[7,3,1]  R1732     -1
    z[7,3,1]  R1733     1
    z[7,3,1]  R1744     2.6827645301818848e-01
    z[7,3,1]  R1745     2.2240860760211945e-01
    z[7,3,1]  R1746     1.9253897666931152e-01
    z[7,3,1]  R1747     1.9086334109306335e-01
    z[7,3,1]  R1748     1.9250404834747314e-01
    z[7,3,1]  R1749     1.8883405625820160e-01
    z[7,3,1]  R1750     1.2418291717767715e-01
    z[7,3,1]  R1751     1.6557477414608002e-01
    z[7,3,1]  R1752     1.1393685638904572e-01
    z[7,3,1]  R1753     1.8629537522792816e-01
    z[7,3,1]  R1754     0.584402859210968
    z[7,3,1]  R1755     4.0262556076049805e-01
    z[7,3,1]  R1756     4.1548383235931396e-01
    z[7,3,1]  R1757     3.6769053339958191e-01
    z[7,3,1]  R1758     -9.5285606384277344e-01
    z[7,3,1]  R1759     -8.7817096710205078e-01
    z[7,3,1]  R1760     -9.2872285842895508e-01
    z[7,3,1]  R1761     -8.9981520175933838e-01
    z[7,3,1]  R1762     -8.2558405399322510e-01
    z[7,3,1]  R1763     -7.1877020597457886e-01
    z[7,3,1]  R1764     8.5633313655853271e-01
    z[7,3,1]  R1765     8.2666528224945068e-01
    z[7,3,1]  R1766     0.729005753993988
    z[7,3,1]  R1767     5.1801115274429321e-01
    z[7,3,1]  R1768     -9.2085808515548706e-01
    z[7,3,1]  R1769     -8.6790871620178223e-01
    z[7,3,1]  R1770     -8.1607604026794434e-01
    z[7,3,1]  R1771     -8.9879059791564941e-01
    z[7,3,1]  R1772     -9.2608416080474854e-01
    z[7,3,1]  R1773     -7.4814999103546143e-01
    z[7,3,1]  R1774     0.0879151001572609
    z[7,3,1]  R1775     4.7405455261468887e-02
    z[7,3,1]  R1776     2.3100873827934265e-01
    z[7,3,1]  R1777     1.0602278262376785e-01
    z[7,3,1]  R1778     9.6101880073547363e-02
    z[7,3,1]  R1779     1.1773117631673813e-01
    z[7,3,1]  R1780     5.3617566823959351e-02
    z[7,3,1]  R1781     1.5947191417217255e-01
    z[7,3,1]  R1782     4.5623715966939926e-02
    z[7,3,1]  R1783     -6.5066802501678467e-01
    z[7,3,1]  R1784     7.0715248584747314e-01
    z[7,3,1]  R1785     8.7995690107345581e-01
    z[7,3,1]  R1786     7.9140859842300415e-01
    z[7,3,1]  R1787     4.6913805603981018e-01
    z[7,3,1]  R1788     5.2681702375411987e-01
    z[7,3,1]  R1789     9.0098321437835693e-01
    z[7,3,1]  R1790     7.3397314548492432e-01
    z[7,3,1]  R1791     7.5054299831390381e-01
    z[7,3,1]  R1792     7.6440131664276123e-01
    z[7,3,1]  R1793     8.0900526046752930e-01
    z[7,3,1]  R1794     4.8665517568588257e-01
    z[7,3,1]  R1795     -1.1594901233911514e-01
    z[7,3,1]  R1796     -3.6921274662017822e-01
    z[7,3,1]  R1797     -0.436531662940979
    z[7,3,1]  R1798     -4.1139650344848633e-01
    z[7,3,1]  R1799     -4.8866763710975647e-01
    z[7,3,1]  R1800     -3.8169285655021667e-01
    z[7,3,1]  R1801     -1.2255111709237099e-02
    z[7,3,1]  R1802     -9.8495864868164062e-01
    z[7,3,1]  R1803     -9.8363023996353149e-01
    z[7,3,1]  R1804     1.2871147692203522e-01
    z[7,3,1]  R1805     -4.5887687802314758e-01
    z[7,3,1]  R1806     3.2750344276428223e-01
    z[7,3,1]  R1807     4.6589708328247070e-01
    z[7,3,1]  R1808     2.6285877823829651e-01
    z[7,3,1]  R1809     -6.7508494853973389e-01
    z[7,3,1]  R1810     1.6986043751239777e-01
    z[7,3,1]  R1811     2.1678008139133453e-01
    z[7,3,1]  R1812     3.9897006750106812e-01
    z[7,3,1]  R1813     -5.8968192338943481e-01
    z[7,3,1]  R1814     -3.4183096885681152e-01
    z[7,3,1]  R1815     4.7175630927085876e-01
    z[7,3,1]  R1816     3.5226395726203918e-01
    z[7,3,1]  R1817     -5.9667944908142090e-01
    z[7,3,1]  R1818     7.0538794994354248e-01
    z[7,3,1]  R1819     4.2998516000807285e-03
    z[7,3,1]  R1820     2.9723146557807922e-01
    z[7,3,1]  R1821     -7.9067003726959229e-01
    z[7,3,1]  R1822     -6.1674386262893677e-01
    z[7,3,1]  R1823     -7.6167237758636475e-01
    z[7,3,2]  R31       1
    z[7,3,2]  R67       -1
    z[7,3,2]  R1734     -1
    z[7,3,2]  R1735     1
    z[7,3,2]  R1744     3.9148885011672974e-01
    z[7,3,2]  R1745     2.5419646501541138e-01
    z[7,3,2]  R1746     2.5696179270744324e-01
    z[7,3,2]  R1747     2.0326870679855347e-01
    z[7,3,2]  R1748     2.8714475035667419e-01
    z[7,3,2]  R1749     7.0061689615249634e-01
    z[7,3,2]  R1750     5.8284962177276611e-01
    z[7,3,2]  R1751     6.5757888555526733e-01
    z[7,3,2]  R1752     7.7169144153594971e-01
    z[7,3,2]  R1753     2.8874278068542480e-01
    z[7,3,2]  R1754     -2.5980761647224426e-01
    z[7,3,2]  R1755     -3.2109084725379944e-01
    z[7,3,2]  R1756     -1.5883018076419830e-01
    z[7,3,2]  R1757     -5.0474941730499268e-01
    z[7,3,2]  R1758     0.051239013671875
    z[7,3,2]  R1759     -6.3232593238353729e-03
    z[7,3,2]  R1760     2.3463173210620880e-01
    z[7,3,2]  R1761     -0.0435776486992836
    z[7,3,2]  R1762     -2.7200752496719360e-01
    z[7,3,2]  R1763     -3.2253436744213104e-02
    z[7,3,2]  R1764     5.7582195848226547e-02
    z[7,3,2]  R1765     3.6205121874809265e-01
    z[7,3,2]  R1766     3.9077621698379517e-01
    z[7,3,2]  R1767     -4.3866109848022461e-01
    z[7,3,2]  R1768     -1.2892891466617584e-01
    z[7,3,2]  R1769     -2.5552364066243172e-02
    z[7,3,2]  R1770     -1.3978378474712372e-01
    z[7,3,2]  R1771     -0.405248761177063
    z[7,3,2]  R1772     1.7147357761859894e-01
    z[7,3,2]  R1773     4.5713827013969421e-01
    z[7,3,2]  R1774     4.5610967278480530e-01
    z[7,3,2]  R1775     7.2723752260208130e-01
    z[7,3,2]  R1776     6.2211388349533081e-01
    z[7,3,2]  R1777     5.7556253671646118e-01
    z[7,3,2]  R1778     8.0174314975738525e-01
    z[7,3,2]  R1779     8.3931821584701538e-01
    z[7,3,2]  R1780     5.7860833406448364e-01
    z[7,3,2]  R1781     0.478883296251297
    z[7,3,2]  R1782     8.1344491243362427e-01
    z[7,3,2]  R1783     -1.3029029965400696e-01
    z[7,3,2]  R1784     3.6529386043548584e-01
    z[7,3,2]  R1785     -7.3588892817497253e-02
    z[7,3,2]  R1786     -7.9887341707944870e-03
    z[7,3,2]  R1787     3.0230340361595154e-01
    z[7,3,2]  R1788     -8.7450090795755386e-03
    z[7,3,2]  R1789     1.2384080886840820e-01
    z[7,3,2]  R1790     -2.7143737673759460e-01
    z[7,3,2]  R1791     4.9015095829963684e-01
    z[7,3,2]  R1792     1.3233336806297302e-01
    z[7,3,2]  R1793     2.1167699992656708e-01
    z[7,3,2]  R1794     3.8264417648315430e-01
    z[7,3,2]  R1795     -4.5903384685516357e-01
    z[7,3,2]  R1796     -3.2446146011352539e-01
    z[7,3,2]  R1797     6.1088603734970093e-01
    z[7,3,2]  R1798     -2.3093193769454956e-01
    z[7,3,2]  R1799     -2.0680993795394897e-01
    z[7,3,2]  R1800     -2.2038353979587555e-01
    z[7,3,2]  R1801     -3.2932776212692261e-01
    z[7,3,2]  R1802     1.2431084178388119e-02
    z[7,3,2]  R1803     1.3812695443630219e-01
    z[7,3,2]  R1804     -1.7673003673553467e-01
    z[7,3,2]  R1805     -2.7781981974840164e-02
    z[7,3,2]  R1806     0.786723792552948
    z[7,3,2]  R1807     3.7132492661476135e-01
    z[7,3,2]  R1808     0.637035071849823
    z[7,3,2]  R1809     3.1422367691993713e-01
    z[7,3,2]  R1810     -6.4259529113769531e-01
    z[7,3,2]  R1811     -1.5603120438754559e-02
    z[7,3,2]  R1812     -7.8586585819721222e-02
    z[7,3,2]  R1813     4.0035453438758850e-01
    z[7,3,2]  R1814     3.4176030755043030e-01
    z[7,3,2]  R1815     0.506028950214386
    z[7,3,2]  R1816     7.6748108863830566e-01
    z[7,3,2]  R1817     4.5889499783515930e-01
    z[7,3,2]  R1818     3.6169582605361938e-01
    z[7,3,2]  R1819     -2.3964995145797729e-01
    z[7,3,2]  R1820     -2.5926128029823303e-01
    z[7,3,2]  R1821     -1.9634471833705902e-01
    z[7,3,2]  R1822     -8.9689306914806366e-02
    z[7,3,2]  R1823     -6.3595935702323914e-02
    z[7,3,3]  R32       1
    z[7,3,3]  R68       -1
    z[7,3,3]  R1736     -1
    z[7,3,3]  R1737     1
    z[7,3,3]  R1744     -4.0317773818969727e-01
    z[7,3,3]  R1745     -7.7090424019843340e-04
    z[7,3,3]  R1746     -2.3817038536071777e-01
    z[7,3,3]  R1747     -3.1208419799804688e-01
    z[7,3,3]  R1748     0.0873216912150383
    z[7,3,3]  R1749     5.0227856636047363e-01
    z[7,3,3]  R1750     -3.8150079548358917e-02
    z[7,3,3]  R1751     2.5135505199432373e-01
    z[7,3,3]  R1752     2.6715794205665588e-01
    z[7,3,3]  R1753     -3.7401530146598816e-01
    z[7,3,3]  R1754     1.3493514060974121e-01
    z[7,3,3]  R1755     -3.6330097913742065e-01
    z[7,3,3]  R1756     -2.3994803428649902e-01
    z[7,3,3]  R1757     6.6571375355124474e-03
    z[7,3,3]  R1758     -2.3104372620582581e-01
    z[7,3,3]  R1759     -3.0128198862075806e-01
    z[7,3,3]  R1760     9.7351469099521637e-02
    z[7,3,3]  R1761     -2.3369999229907990e-01
    z[7,3,3]  R1762     1.1244335025548935e-01
    z[7,3,3]  R1763     4.2713305354118347e-01
    z[7,3,3]  R1764     -9.7382143139839172e-02
    z[7,3,3]  R1765     1.3974194228649139e-01
    z[7,3,3]  R1766     6.3815057277679443e-02
    z[7,3,3]  R1767     -5.1278185844421387e-01
    z[7,3,3]  R1768     2.9160696268081665e-01
    z[7,3,3]  R1769     -1.0779995471239090e-01
    z[7,3,3]  R1770     1.3958472013473511e-01
    z[7,3,3]  R1771     -1.3942248187959194e-03
    z[7,3,3]  R1772     -7.4596926569938660e-02
    z[7,3,3]  R1773     3.2925301790237427e-01
    z[7,3,3]  R1774     -4.4812297821044922e-01
    z[7,3,3]  R1775     -4.4923420995473862e-02
    z[7,3,3]  R1776     -4.2484471201896667e-01
    z[7,3,3]  R1777     -4.7857820987701416e-01
    z[7,3,3]  R1778     -2.6240247488021851e-01
    z[7,3,3]  R1779     -3.1512993574142456e-01
    z[7,3,3]  R1780     -1.4631706476211548e-01
    z[7,3,3]  R1781     7.6103769242763519e-02
    z[7,3,3]  R1782     2.7971621602773666e-02
    z[7,3,3]  R1783     5.8904254436492920e-01
    z[7,3,3]  R1784     -1.5220357477664948e-01
    z[7,3,3]  R1785     -2.0829458534717560e-01
    z[7,3,3]  R1786     -1.7938715219497681e-01
    z[7,3,3]  R1787     -1.8934619426727295e-01
    z[7,3,3]  R1788     -1.1781907081604004e-01
    z[7,3,3]  R1789     -1.9135364890098572e-01
    z[7,3,3]  R1790     -1.6161556541919708e-01
    z[7,3,3]  R1791     1.6730929911136627e-01
    z[7,3,3]  R1792     -8.9101351797580719e-02
    z[7,3,3]  R1793     1.0480973869562149e-01
    z[7,3,3]  R1794     -4.8682615160942078e-01
    z[7,3,3]  R1795     1.2215206027030945e-01
    z[7,3,3]  R1796     8.9465126395225525e-02
    z[7,3,3]  R1797     4.0796884894371033e-01
    z[7,3,3]  R1798     5.4777670651674271e-02
    z[7,3,3]  R1799     1.8457730114459991e-01
    z[7,3,3]  R1800     -2.2198373079299927e-01
    z[7,3,3]  R1801     4.9443040043115616e-02
    z[7,3,3]  R1802     -2.6664443314075470e-02
    z[7,3,3]  R1803     -1.3641602359712124e-02
    z[7,3,3]  R1804     2.0883357524871826e-01
    z[7,3,3]  R1805     5.9276979416608810e-02
    z[7,3,3]  R1806     -3.7302502989768982e-01
    z[7,3,3]  R1807     -2.2553491592407227e-01
    z[7,3,3]  R1808     -2.6345416903495789e-01
    z[7,3,3]  R1809     -5.7021226733922958e-02
    z[7,3,3]  R1810     -1.4604070782661438e-01
    z[7,3,3]  R1811     7.3949128389358521e-01
    z[7,3,3]  R1812     -7.7378368377685547e-01
    z[7,3,3]  R1813     -3.0501747131347656e-01
    z[7,3,3]  R1814     1.3053485751152039e-01
    z[7,3,3]  R1815     -4.6720156073570251e-01
    z[7,3,3]  R1816     -3.7617179751396179e-01
    z[7,3,3]  R1817     -2.5443825125694275e-01
    z[7,3,3]  R1818     1.4944136142730713e-01
    z[7,3,3]  R1819     -2.1485966444015503e-01
    z[7,3,3]  R1820     -0.361503541469574
    z[7,3,3]  R1821     4.0918534994125366e-01
    z[7,3,3]  R1822     2.1533244848251343e-01
    z[7,3,3]  R1823     9.3500562012195587e-02
    z[7,3,4]  R33       1
    z[7,3,4]  R69       -1
    z[7,3,4]  R1738     -1
    z[7,3,4]  R1739     1
    z[7,3,4]  R1744     0.60483717918396
    z[7,3,4]  R1745     -6.4296253025531769e-02
    z[7,3,4]  R1746     1.0830979794263840e-01
    z[7,3,4]  R1747     1.2754504382610321e-01
    z[7,3,4]  R1748     5.1302719116210938e-01
    z[7,3,4]  R1749     2.7713507413864136e-01
    z[7,3,4]  R1750     2.7354445308446884e-02
    z[7,3,4]  R1751     2.0819666981697083e-01
    z[7,3,4]  R1752     1.1473132669925690e-01
    z[7,3,4]  R1753     -3.4995445609092712e-01
    z[7,3,4]  R1754     -5.6651449203491211e-01
    z[7,3,4]  R1755     2.1771334111690521e-01
    z[7,3,4]  R1756     -5.0821971148252487e-02
    z[7,3,4]  R1757     1.8033283948898315e-01
    z[7,3,4]  R1758     -6.3421934843063354e-02
    z[7,3,4]  R1759     1.9550846517086029e-01
    z[7,3,4]  R1760     -1.7913454771041870e-01
    z[7,3,4]  R1761     -1.1474343389272690e-01
    z[7,3,4]  R1762     -4.7085419297218323e-01
    z[7,3,4]  R1763     -2.8207856416702271e-01
    z[7,3,4]  R1764     -5.1008272916078568e-02
    z[7,3,4]  R1765     2.4283653497695923e-01
    z[7,3,4]  R1766     -4.7067850828170776e-01
    z[7,3,4]  R1767     2.1497736871242523e-01
    z[7,3,4]  R1768     -6.2021367251873016e-02
    z[7,3,4]  R1769     -1.5125301480293274e-01
    z[7,3,4]  R1770     1.5340529382228851e-01
    z[7,3,4]  R1771     9.9574409425258636e-02
    z[7,3,4]  R1772     -2.3859688639640808e-01
    z[7,3,4]  R1773     1.2870885431766510e-01
    z[7,3,4]  R1774     -1.6152805089950562e-01
    z[7,3,4]  R1775     4.1991356760263443e-02
    z[7,3,4]  R1776     3.3569493889808655e-01
    z[7,3,4]  R1777     1.6924628615379333e-01
    z[7,3,4]  R1778     5.1765460520982742e-03
    z[7,3,4]  R1779     -1.7421782016754150e-02
    z[7,3,4]  R1780     2.0205074548721313e-01
    z[7,3,4]  R1781     1.7253243923187256e-01
    z[7,3,4]  R1782     -6.7176230251789093e-02
    z[7,3,4]  R1783     5.7344906032085419e-02
    z[7,3,4]  R1784     3.2965913414955139e-01
    z[7,3,4]  R1785     2.4692562222480774e-01
    z[7,3,4]  R1786     3.2463434338569641e-01
    z[7,3,4]  R1787     5.8428615331649780e-01
    z[7,3,4]  R1788     6.2384980916976929e-01
    z[7,3,4]  R1789     -1.5458887815475464e-01
    z[7,3,4]  R1790     4.6523067355155945e-01
    z[7,3,4]  R1791     -2.9821535944938660e-01
    z[7,3,4]  R1792     -2.2359816730022430e-01
    z[7,3,4]  R1793     -2.7855536341667175e-01
    z[7,3,4]  R1794     -1.0852883569896221e-02
    z[7,3,4]  R1795     2.2692683339118958e-01
    z[7,3,4]  R1796     5.1973837614059448e-01
    z[7,3,4]  R1797     2.7637824416160583e-01
    z[7,3,4]  R1798     3.6246275901794434e-01
    z[7,3,4]  R1799     -1.7918980121612549e-01
    z[7,3,4]  R1800     5.1530379056930542e-01
    z[7,3,4]  R1801     -0.562545120716095
    z[7,3,4]  R1802     -3.1120110303163528e-02
    z[7,3,4]  R1803     1.0847674310207367e-01
    z[7,3,4]  R1804     2.0253743231296539e-01
    z[7,3,4]  R1805     -2.9733717441558838e-01
    z[7,3,4]  R1806     4.4139493256807327e-03
    z[7,3,4]  R1807     2.4505078792572021e-01
    z[7,3,4]  R1808     4.6307435631752014e-01
    z[7,3,4]  R1809     3.7557664513587952e-01
    z[7,3,4]  R1810     -1.9396117329597473e-01
    z[7,3,4]  R1811     3.1712433695793152e-01
    z[7,3,4]  R1812     -3.1650328636169434e-01
    z[7,3,4]  R1813     -5.8611828833818436e-02
    z[7,3,4]  R1814     4.7082599997520447e-01
    z[7,3,4]  R1815     2.4481488764286041e-01
    z[7,3,4]  R1816     1.4100854098796844e-01
    z[7,3,4]  R1817     -1.5714994072914124e-01
    z[7,3,4]  R1818     -3.3327883481979370e-01
    z[7,3,4]  R1819     7.1202528476715088e-01
    z[7,3,4]  R1820     1.9729733467102051e-01
    z[7,3,4]  R1821     -0.0475076325237751
    z[7,3,4]  R1822     5.0383579218760133e-04
    z[7,3,4]  R1823     -6.9557175040245056e-02
    z[7,3,5]  R34       1
    z[7,3,5]  R70       -1
    z[7,3,5]  R1740     -1
    z[7,3,5]  R1741     1
    z[7,3,5]  R1744     2.1369495987892151e-01
    z[7,3,5]  R1745     1.5344811603426933e-02
    z[7,3,5]  R1746     -6.4999371767044067e-01
    z[7,3,5]  R1747     -5.6228202581405640e-01
    z[7,3,5]  R1748     -2.0857641100883484e-01
    z[7,3,5]  R1749     -1.8942032754421234e-01
    z[7,3,5]  R1750     -4.2550815269351006e-03
    z[7,3,5]  R1751     5.3575128316879272e-02
    z[7,3,5]  R1752     -3.6595806479454041e-01
    z[7,3,5]  R1753     6.7329391837120056e-02
    z[7,3,5]  R1754     -2.6174557209014893e-01
    z[7,3,5]  R1755     1.4011247456073761e-01
    z[7,3,5]  R1756     -1.1286448687314987e-01
    z[7,3,5]  R1757     1.3865859806537628e-01
    z[7,3,5]  R1758     1.2577064335346222e-01
    z[7,3,5]  R1759     9.6456006169319153e-02
    z[7,3,5]  R1760     1.4606384932994843e-01
    z[7,3,5]  R1761     6.4928233623504639e-02
    z[7,3,5]  R1762     -8.9737243950366974e-02
    z[7,3,5]  R1763     2.1938440203666687e-01
    z[7,3,5]  R1764     2.6106894016265869e-01
    z[7,3,5]  R1765     -1.2218544632196426e-01
    z[7,3,5]  R1766     -6.5748314373195171e-03
    z[7,3,5]  R1767     2.5487670302391052e-01
    z[7,3,5]  R1768     -8.0740720033645630e-02
    z[7,3,5]  R1769     1.3575650751590729e-01
    z[7,3,5]  R1770     -3.7502128630876541e-02
    z[7,3,5]  R1771     -6.5509853884577751e-03
    z[7,3,5]  R1772     -1.7547595500946045e-01
    z[7,3,5]  R1773     0.0950714573264122
    z[7,3,5]  R1774     -5.7792407274246216e-01
    z[7,3,5]  R1775     -4.2808058857917786e-01
    z[7,3,5]  R1776     -2.9734271764755249e-01
    z[7,3,5]  R1777     -2.8148514032363892e-01
    z[7,3,5]  R1778     -2.7915477752685547e-02
    z[7,3,5]  R1779     -7.9293444752693176e-02
    z[7,3,5]  R1780     -8.4606327116489410e-02
    z[7,3,5]  R1781     9.9117174744606018e-02
    z[7,3,5]  R1782     1.6980433836579323e-02
    z[7,3,5]  R1783     1.7489799857139587e-01
    z[7,3,5]  R1784     2.8112211823463440e-01
    z[7,3,5]  R1785     5.8897435665130615e-02
    z[7,3,5]  R1786     -1.9705721735954285e-01
    z[7,3,5]  R1787     2.7261313796043396e-01
    z[7,3,5]  R1788     4.2434221506118774e-01
    z[7,3,5]  R1789     -1.7677873373031616e-01
    z[7,3,5]  R1790     -1.4201782643795013e-01
    z[7,3,5]  R1791     2.5592403486371040e-02
    z[7,3,5]  R1792     -3.0416905879974365e-01
    z[7,3,5]  R1793     -0.000569283205550164
    z[7,3,5]  R1794     -1.0047782957553864e-01
    z[7,3,5]  R1795     -4.3988370895385742e-01
    z[7,3,5]  R1796     -2.9304248094558716e-01
    z[7,3,5]  R1797     2.9010564088821411e-02
    z[7,3,5]  R1798     -2.3519793152809143e-01
    z[7,3,5]  R1799     -7.7569890022277832e-01
    z[7,3,5]  R1800     -1.2172938138246536e-01
    z[7,3,5]  R1801     -4.7232115268707275e-01
    z[7,3,5]  R1802     -9.4048053026199341e-02
    z[7,3,5]  R1803     -3.5687930881977081e-02
    z[7,3,5]  R1804     -0.637411892414093
    z[7,3,5]  R1805     -6.6606724262237549e-01
    z[7,3,5]  R1806     -3.1793776154518127e-01
    z[7,3,5]  R1807     -2.8903603553771973e-01
    z[7,3,5]  R1808     -5.9671834111213684e-02
    z[7,3,5]  R1809     5.5829092860221863e-02
    z[7,3,5]  R1810     -4.8054376244544983e-01
    z[7,3,5]  R1811     -3.7372562289237976e-01
    z[7,3,5]  R1812     -5.1018174737691879e-02
    z[7,3,5]  R1813     -0.16500224173069
    z[7,3,5]  R1814     -2.6149508357048035e-01
    z[7,3,5]  R1815     -3.9062270522117615e-01
    z[7,3,5]  R1816     -7.5355544686317444e-02
    z[7,3,5]  R1817     -1.0918852686882019e-01
    z[7,3,5]  R1818     3.1797841191291809e-01
    z[7,3,5]  R1819     6.7660994827747345e-02
    z[7,3,5]  R1820     -4.4406184554100037e-01
    z[7,3,5]  R1821     0.28211510181427
    z[7,3,5]  R1822     -3.8971409201622009e-02
    z[7,3,5]  R1823     -0.0712960958480835
    z[7,3,6]  R35       1
    z[7,3,6]  R71       -1
    z[7,3,6]  R1742     -1
    z[7,3,6]  R1743     1
    z[7,3,6]  R1744     -1.7452044785022736e-01
    z[7,3,6]  R1745     8.2540971040725708e-01
    z[7,3,6]  R1746     -5.7376581430435181e-01
    z[7,3,6]  R1747     3.8757154345512390e-01
    z[7,3,6]  R1748     -6.9144135713577271e-01
    z[7,3,6]  R1749     -3.0708971619606018e-01
    z[7,3,6]  R1750     3.9589628577232361e-01
    z[7,3,6]  R1751     5.2624928951263428e-01
    z[7,3,6]  R1752     -2.7057321742177010e-02
    z[7,3,6]  R1753     1.8995814025402069e-02
    z[7,3,6]  R1754     -7.4864067137241364e-02
    z[7,3,6]  R1755     0.307809978723526
    z[7,3,6]  R1756     2.5697097182273865e-01
    z[7,3,6]  R1757     3.6726808547973633e-01
    z[7,3,6]  R1758     8.0694079399108887e-02
    z[7,3,6]  R1759     2.7178376913070679e-01
    z[7,3,6]  R1760     -1.2867182493209839e-01
    z[7,3,6]  R1761     -3.3929708600044250e-01
    z[7,3,6]  R1762     -1.4879697002470493e-02
    z[7,3,6]  R1763     1.4914938807487488e-01
    z[7,3,6]  R1764     4.2420718073844910e-01
    z[7,3,6]  R1765     -1.4500647783279419e-01
    z[7,3,6]  R1766     -2.6295873522758484e-01
    z[7,3,6]  R1767     -2.8509417176246643e-01
    z[7,3,6]  R1768     -5.1247671246528625e-02
    z[7,3,6]  R1769     4.7775931656360626e-02
    z[7,3,6]  R1770     -2.7299644425511360e-02
    z[7,3,6]  R1771     -8.1580407917499542e-02
    z[7,3,6]  R1772     -1.1143527925014496e-01
    z[7,3,6]  R1773     1.0900022834539413e-01
    z[7,3,6]  R1774     7.4521891772747040e-02
    z[7,3,6]  R1775     -2.2464311122894287e-01
    z[7,3,6]  R1776     -2.1223948895931244e-01
    z[7,3,6]  R1777     -5.5257236957550049e-01
    z[7,3,6]  R1778     -4.8760646581649780e-01
    z[7,3,6]  R1779     0.41396364569664
    z[7,3,6]  R1780     7.3515009880065918e-01
    z[7,3,6]  R1781     4.5496222376823425e-01
    z[7,3,6]  R1782     3.8575893640518188e-01
    z[7,3,6]  R1783     -3.4354977309703827e-02
    z[7,3,6]  R1784     0.353779673576355
    z[7,3,6]  R1785     -1.5861421823501587e-01
    z[7,3,6]  R1786     0.398602157831192
    z[7,3,6]  R1787     -4.3374350666999817e-01
    z[7,3,6]  R1788     -3.6097073554992676e-01
    z[7,3,6]  R1789     2.1861669421195984e-01
    z[7,3,6]  R1790     -2.0553785562515259e-01
    z[7,3,6]  R1791     0.0370715856552124
    z[7,3,6]  R1792     -2.6596274971961975e-01
    z[7,3,6]  R1793     2.4547803401947021e-01
    z[7,3,6]  R1794     -5.9849119186401367e-01
    z[7,3,6]  R1795     -5.7676357030868530e-01
    z[7,3,6]  R1796     -4.0605217218399048e-01
    z[7,3,6]  R1797     0.247311532497406
    z[7,3,6]  R1798     6.7981898784637451e-01
    z[7,3,6]  R1799     -4.4222317636013031e-02
    z[7,3,6]  R1800     0.503506600856781
    z[7,3,6]  R1801     5.2704554796218872e-01
    z[7,3,6]  R1802     -1.3678748905658722e-01
    z[7,3,6]  R1803     8.0298632383346558e-03
    z[7,3,6]  R1804     4.7421202063560486e-01
    z[7,3,6]  R1805     3.5756975412368774e-01
    z[7,3,6]  R1806     -4.4253780506551266e-03
    z[7,3,6]  R1807     -1.8486125767230988e-01
    z[7,3,6]  R1808     1.4423312246799469e-01
    z[7,3,6]  R1809     -3.8099639117717743e-02
    z[7,3,6]  R1810     -0.118285171687603
    z[7,3,6]  R1811     -2.6165261864662170e-01
    z[7,3,6]  R1812     1.1281788349151611e-01
    z[7,3,6]  R1813     -5.3018681704998016e-02
    z[7,3,6]  R1814     -2.0261111855506897e-01
    z[7,3,6]  R1815     -2.6949328184127808e-01
    z[7,3,6]  R1816     -0.344638854265213
    z[7,3,6]  R1817     -0.314930260181427
    z[7,3,6]  R1818     -2.7806192636489868e-01
    z[7,3,6]  R1819     9.3920424580574036e-02
    z[7,3,6]  R1820     3.6387926340103149e-01
    z[7,3,6]  R1821     7.9205565154552460e-02
    z[7,3,6]  R1822     -1.4415609836578369e-01
    z[7,3,6]  R1823     -0.0653463751077652
    z[4,5,0]  R38       -1
    z[4,5,0]  R47       1
    z[4,5,0]  R1888     -1
    z[4,5,0]  R1889     1
    z[4,5,0]  R1902     7.7755272388458252e-01
    z[4,5,0]  R1903     6.3734090328216553e-01
    z[4,5,0]  R1904     5.8479756116867065e-01
    z[4,5,0]  R1905     6.0710543394088745e-01
    z[4,5,0]  R1906     3.8329303264617920e-01
    z[4,5,0]  R1907     2.1687658131122589e-01
    z[4,5,0]  R1908     2.1503403782844543e-02
    z[4,5,0]  R1909     3.1548026204109192e-01
    z[4,5,0]  R1910     0.434079110622406
    z[4,5,0]  R1911     0.626015841960907
    z[4,5,0]  R1912     5.6098586320877075e-01
    z[4,5,0]  R1913     3.3980640769004822e-01
    z[4,5,0]  R1914     2.1491794288158417e-01
    z[4,5,0]  R1915     -6.8108814954757690e-01
    z[4,5,0]  R1916     -3.8750776648521423e-01
    z[4,5,0]  R1917     -4.7351148724555969e-01
    z[4,5,0]  R1918     -5.8315277099609375e-01
    z[4,5,0]  R1919     -6.1338418722152710e-01
    z[4,5,0]  R1920     -8.8346785306930542e-01
    z[4,5,0]  R1921     -8.1260401010513306e-01
    z[4,5,0]  R1922     2.0011156797409058e-01
    z[4,5,0]  R1923     -3.7151196599006653e-01
    z[4,5,0]  R1924     -0.533784031867981
    z[4,5,0]  R1925     -7.4237263202667236e-01
    z[4,5,0]  R1926     -2.9535919427871704e-01
    z[4,5,0]  R1927     -2.5586044788360596e-01
    z[4,5,0]  R1928     -3.4152883291244507e-01
    z[4,5,0]  R1929     -4.1218620538711548e-01
    z[4,5,0]  R1930     -3.6068147420883179e-01
    z[4,5,0]  R1931     -1.7500633001327515e-01
    z[4,5,0]  R1932     4.9794915318489075e-01
    z[4,5,0]  R1933     1.9511704146862030e-01
    z[4,5,0]  R1934     3.2752478122711182e-01
    z[4,5,0]  R1935     -5.1430463790893555e-02
    z[4,5,0]  R1936     -5.2251976728439331e-01
    z[4,5,0]  R1937     -6.1259114742279053e-01
    z[4,5,0]  R1938     -3.8758561015129089e-01
    z[4,5,0]  R1939     -8.7527495622634888e-01
    z[4,5,0]  R1940     -6.8857854604721069e-01
    z[4,5,0]  R1941     -6.6475450992584229e-01
    z[4,5,0]  R1942     2.7077559381723404e-02
    z[4,5,0]  R1943     -1.4716574549674988e-01
    z[4,5,0]  R1944     6.6157186031341553e-01
    z[4,5,0]  R1945     3.2766574621200562e-01
    z[4,5,0]  R1946     3.5326221585273743e-01
    z[4,5,0]  R1947     -4.8980057239532471e-02
    z[4,5,0]  R1948     4.2251950502395630e-01
    z[4,5,0]  R1949     -7.9604452848434448e-01
    z[4,5,0]  R1950     3.9534687995910645e-01
    z[4,5,0]  R1951     -4.4654479622840881e-01
    z[4,5,0]  R1952     -1.4632028341293335e-01
    z[4,5,0]  R1953     -0.420944482088089
    z[4,5,0]  R1954     -2.4442516267299652e-01
    z[4,5,0]  R1955     -9.0486049652099609e-01
    z[4,5,0]  R1956     -8.8210612535476685e-01
    z[4,5,0]  R1957     -8.8734483718872070e-01
    z[4,5,0]  R1958     -0.904356837272644
    z[4,5,0]  R1959     -8.9519476890563965e-01
    z[4,5,1]  R39       -1
    z[4,5,1]  R48       1
    z[4,5,1]  R1890     -1
    z[4,5,1]  R1891     1
    z[4,5,1]  R1902     -3.9053717255592346e-01
    z[4,5,1]  R1903     -2.3057553172111511e-01
    z[4,5,1]  R1904     -3.9834627509117126e-01
    z[4,5,1]  R1905     -3.2214903831481934e-01
    z[4,5,1]  R1906     -3.1685826182365417e-01
    z[4,5,1]  R1907     0.18353371322155
    z[4,5,1]  R1908     1.6331650316715240e-01
    z[4,5,1]  R1909     -2.2192259784787893e-03
    z[4,5,1]  R1910     -1.6745314002037048e-02
    z[4,5,1]  R1911     1.4434356987476349e-01
    z[4,5,1]  R1912     4.1506272554397583e-01
    z[4,5,1]  R1913     4.3609973788261414e-01
    z[4,5,1]  R1914     6.3473701477050781e-01
    z[4,5,1]  R1915     3.7802930921316147e-02
    z[4,5,1]  R1916     3.8586241006851196e-01
    z[4,5,1]  R1917     8.1718474626541138e-02
    z[4,5,1]  R1918     7.6087392866611481e-02
    z[4,5,1]  R1919     6.9843932986259460e-02
    z[4,5,1]  R1920     1.9197058677673340e-01
    z[4,5,1]  R1921     -1.7714096605777740e-01
    z[4,5,1]  R1922     -8.3324313163757324e-02
    z[4,5,1]  R1923     2.2697913646697998e-01
    z[4,5,1]  R1924     7.6907515525817871e-02
    z[4,5,1]  R1925     9.3378983438014984e-02
    z[4,5,1]  R1926     -2.8235715627670288e-01
    z[4,5,1]  R1927     6.9965416193008423e-01
    z[4,5,1]  R1928     6.3529521226882935e-01
    z[4,5,1]  R1929     6.1751806735992432e-01
    z[4,5,1]  R1930     5.3761011362075806e-01
    z[4,5,1]  R1931     4.2723336815834045e-01
    z[4,5,1]  R1932     -9.8839856684207916e-02
    z[4,5,1]  R1933     -2.4453786015510559e-01
    z[4,5,1]  R1934     6.5430924296379089e-02
    z[4,5,1]  R1935     4.4217151403427124e-01
    z[4,5,1]  R1936     2.1262690424919128e-01
    z[4,5,1]  R1937     -4.7013565897941589e-01
    z[4,5,1]  R1938     -5.2967935800552368e-01
    z[4,5,1]  R1939     -0.095587819814682
    z[4,5,1]  R1940     -3.5056486725807190e-01
    z[4,5,1]  R1941     -0.279590904712677
    z[4,5,1]  R1942     2.1032528579235077e-01
    z[4,5,1]  R1943     1.4855297282338142e-02
    z[4,5,1]  R1944     -4.6718326210975647e-01
    z[4,5,1]  R1945     4.1429869830608368e-02
    z[4,5,1]  R1946     -1.5066677331924438e-01
    z[4,5,1]  R1947     3.8200950622558594e-01
    z[4,5,1]  R1948     -5.6179088354110718e-01
    z[4,5,1]  R1949     -2.5091665983200073e-01
    z[4,5,1]  R1950     0.735697329044342
    z[4,5,1]  R1951     5.1107460260391235e-01
    z[4,5,1]  R1952     3.1154605746269226e-01
    z[4,5,1]  R1953     4.4397643208503723e-01
    z[4,5,1]  R1954     -2.0141474902629852e-01
    z[4,5,1]  R1955     -1.1928041279315948e-01
    z[4,5,1]  R1956     1.0443801991641521e-02
    z[4,5,1]  R1957     -1.9972890615463257e-01
    z[4,5,1]  R1958     -2.3908819258213043e-01
    z[4,5,1]  R1959     -0.086459219455719
    z[4,5,2]  R40       -1
    z[4,5,2]  R49       1
    z[4,5,2]  R1892     -1
    z[4,5,2]  R1893     1
    z[4,5,2]  R1902     9.6842184662818909e-02
    z[4,5,2]  R1903     -0.262206107378006
    z[4,5,2]  R1904     9.9797770380973816e-02
    z[4,5,2]  R1905     -4.1073697805404663e-01
    z[4,5,2]  R1906     -7.5050640106201172e-01
    z[4,5,2]  R1907     -7.6529151201248169e-01
    z[4,5,2]  R1908     -7.0444834232330322e-01
    z[4,5,2]  R1909     -6.2899458408355713e-01
    z[4,5,2]  R1910     -5.4802465438842773e-01
    z[4,5,2]  R1911     -3.5592085123062134e-01
    z[4,5,2]  R1912     -1.5294665098190308e-01
    z[4,5,2]  R1913     4.0598326921463013e-01
    z[4,5,2]  R1914     6.5435290336608887e-02
    z[4,5,2]  R1915     -4.0175712108612061e-01
    z[4,5,2]  R1916     -5.4046612977981567e-01
    z[4,5,2]  R1917     -7.4267548322677612e-01
    z[4,5,2]  R1918     -5.4421937465667725e-01
    z[4,5,2]  R1919     -3.9016574621200562e-01
    z[4,5,2]  R1920     -1.6744016110897064e-01
    z[4,5,2]  R1921     -4.2687937617301941e-01
    z[4,5,2]  R1922     -5.4102480411529541e-01
    z[4,5,2]  R1923     -0.502291738986969
    z[4,5,2]  R1924     -4.4189968705177307e-01
    z[4,5,2]  R1925     -4.9744647741317749e-01
    z[4,5,2]  R1926     -8.1178158521652222e-01
    z[4,5,2]  R1927     2.6623749732971191e-01
    z[4,5,2]  R1928     3.9537829160690308e-01
    z[4,5,2]  R1929     6.1859405832365155e-04
    z[4,5,2]  R1930     1.4093835838139057e-02
    z[4,5,2]  R1931     3.3906945586204529e-01
    z[4,5,2]  R1932     -3.6892163753509521e-01
    z[4,5,2]  R1933     -5.6913815438747406e-02
    z[4,5,2]  R1934     -2.8455594182014465e-01
    z[4,5,2]  R1935     9.5352604985237122e-02
    z[4,5,2]  R1936     -7.0583587884902954e-01
    z[4,5,2]  R1937     -1.8528589606285095e-01
    z[4,5,2]  R1938     -5.0818198919296265e-01
    z[4,5,2]  R1939     1.8494956195354462e-01
    z[4,5,2]  R1940     -8.1987380981445312e-02
    z[4,5,2]  R1941     5.7027824223041534e-02
    z[4,5,2]  R1942     -3.7991592288017273e-01
    z[4,5,2]  R1943     -2.9864221811294556e-01
    z[4,5,2]  R1944     2.2859716415405273e-01
    z[4,5,2]  R1945     5.4286282509565353e-02
    z[4,5,2]  R1946     3.1203457713127136e-01
    z[4,5,2]  R1947     3.1310686469078064e-01
    z[4,5,2]  R1948     -2.7816560864448547e-01
    z[4,5,2]  R1949     2.3640289902687073e-01
    z[4,5,2]  R1950     -2.6094261556863785e-02
    z[4,5,2]  R1951     1.8322923779487610e-01
    z[4,5,2]  R1952     5.8794164657592773e-01
    z[4,5,2]  R1953     4.9670797586441040e-01
    z[4,5,2]  R1954     -4.6606090664863586e-01
    z[4,5,2]  R1955     -4.8526491969823837e-02
    z[4,5,2]  R1956     -1.6023044288158417e-01
    z[4,5,2]  R1957     -1.6508170962333679e-01
    z[4,5,2]  R1958     3.1460151076316833e-02
    z[4,5,2]  R1959     -3.8388580083847046e-02
    z[4,5,3]  R41       -1
    z[4,5,3]  R50       1
    z[4,5,3]  R1894     -1
    z[4,5,3]  R1895     1
    z[4,5,3]  R1902     -0.414764404296875
    z[4,5,3]  R1903     -2.5034227967262268e-01
    z[4,5,3]  R1904     -3.9581304788589478e-01
    z[4,5,3]  R1905     -3.9183524250984192e-01
    z[4,5,3]  R1906     -2.0016261935234070e-01
    z[4,5,3]  R1907     -1.9974724948406219e-01
    z[4,5,3]  R1908     1.7060551047325134e-01
    z[4,5,3]  R1909     1.6670159995555878e-01
    z[4,5,3]  R1910     1.4519914984703064e-01
    z[4,5,3]  R1911     4.4855013489723206e-01
    z[4,5,3]  R1912     3.5233241319656372e-01
    z[4,5,3]  R1913     3.2735961675643921e-01
    z[4,5,3]  R1914     0.160980224609375
    z[4,5,3]  R1915     4.2600056529045105e-01
    z[4,5,3]  R1916     4.6237173676490784e-01
    z[4,5,3]  R1917     3.0387637019157410e-01
    z[4,5,3]  R1918     2.2216325998306274e-01
    z[4,5,3]  R1919     5.8633047342300415e-01
    z[4,5,3]  R1920     3.7895858287811279e-01
    z[4,5,3]  R1921     3.3695170283317566e-01
    z[4,5,3]  R1922     4.5463311672210693e-01
    z[4,5,3]  R1923     4.7110924124717712e-01
    z[4,5,3]  R1924     3.7987053394317627e-01
    z[4,5,3]  R1925     2.6640614867210388e-01
    z[4,5,3]  R1926     1.8347172439098358e-01
    z[4,5,3]  R1927     -3.3782243728637695e-01
    z[4,5,3]  R1928     -5.2226340770721436e-01
    z[4,5,3]  R1929     -0.650968074798584
    z[4,5,3]  R1930     -6.5431934595108032e-01
    z[4,5,3]  R1931     -7.9564833641052246e-01
    z[4,5,3]  R1932     1.7952050268650055e-01
    z[4,5,3]  R1933     1.1064269393682480e-01
    z[4,5,3]  R1934     4.6490901708602905e-01
    z[4,5,3]  R1935     5.7867074012756348e-01
    z[4,5,3]  R1936     3.6209985613822937e-01
    z[4,5,3]  R1937     -2.6049536466598511e-01
    z[4,5,3]  R1938     -3.7754493951797485e-01
    z[4,5,3]  R1939     -3.9802354574203491e-01
    z[4,5,3]  R1940     -5.6722772121429443e-01
    z[4,5,3]  R1941     -5.1404041051864624e-01
    z[4,5,3]  R1942     1.4298340678215027e-01
    z[4,5,3]  R1943     3.0610656738281250e-01
    z[4,5,3]  R1944     -4.5985820889472961e-01
    z[4,5,3]  R1945     -5.7009279727935791e-01
    z[4,5,3]  R1946     -2.6410719752311707e-01
    z[4,5,3]  R1947     4.0180769562721252e-01
    z[4,5,3]  R1948     5.2533990144729614e-01
    z[4,5,3]  R1949     -2.3259180784225464e-01
    z[4,5,3]  R1950     3.7807571887969971e-01
    z[4,5,3]  R1951     -6.2137925624847412e-01
    z[4,5,3]  R1952     -5.2404171228408813e-01
    z[4,5,3]  R1953     -2.4119694530963898e-01
    z[4,5,3]  R1954     -6.6314691305160522e-01
    z[4,5,3]  R1955     -3.0422553420066833e-01
    z[4,5,3]  R1956     -4.0116128325462341e-01
    z[4,5,3]  R1957     -3.2623365521430969e-01
    z[4,5,3]  R1958     -2.2785899043083191e-01
    z[4,5,3]  R1959     -1.5573722124099731e-01
    z[4,5,4]  R42       -1
    z[4,5,4]  R51       1
    z[4,5,4]  R1896     -1
    z[4,5,4]  R1897     1
    z[4,5,4]  R1902     -7.0972524583339691e-02
    z[4,5,4]  R1903     -6.0671043395996094e-01
    z[4,5,4]  R1904     -3.4394067525863647e-01
    z[4,5,4]  R1905     -6.2061451375484467e-02
    z[4,5,4]  R1906     -1.9149589538574219e-01
    z[4,5,4]  R1907     1.1042827740311623e-02
    z[4,5,4]  R1908     -3.8129106163978577e-01
    z[4,5,4]  R1909     -0.532794713973999
    z[4,5,4]  R1910     -5.5903512239456177e-01
    z[4,5,4]  R1911     -4.4526490569114685e-01
    z[4,5,4]  R1912     -2.2568744421005249e-01
    z[4,5,4]  R1913     -7.9875849187374115e-02
    z[4,5,4]  R1914     5.6935474276542664e-02
    z[4,5,4]  R1915     -1.4888532459735870e-01
    z[4,5,4]  R1916     4.9446769990026951e-03
    z[4,5,4]  R1917     -1.5995962917804718e-01
    z[4,5,4]  R1918     1.6281167045235634e-02
    z[4,5,4]  R1919     -2.4922268092632294e-01
    z[4,5,4]  R1920     -6.6522851586341858e-02
    z[4,5,4]  R1921     8.7339393794536591e-02
    z[4,5,4]  R1922     1.0043712705373764e-01
    z[4,5,4]  R1923     2.3559153079986572e-01
    z[4,5,4]  R1924     2.6856338977813721e-01
    z[4,5,4]  R1925     1.4533202350139618e-01
    z[4,5,4]  R1926     1.9444513320922852e-01
    z[4,5,4]  R1927     1.0865075886249542e-01
    z[4,5,4]  R1928     6.4610771369189024e-04
    z[4,5,4]  R1929     -7.4865229427814484e-02
    z[4,5,4]  R1930     -3.4858337603509426e-03
    z[4,5,4]  R1931     9.5011197030544281e-02
    z[4,5,4]  R1932     1.8711134791374207e-01
    z[4,5,4]  R1933     -0.078458271920681
    z[4,5,4]  R1934     -2.7974864840507507e-01
    z[4,5,4]  R1935     3.2017588615417480e-01
    z[4,5,4]  R1936     1.6883562505245209e-01
    z[4,5,4]  R1937     -4.8497796058654785e-01
    z[4,5,4]  R1938     -0.257993221282959
    z[4,5,4]  R1939     -2.0148554816842079e-02
    z[4,5,4]  R1940     1.1473413556814194e-02
    z[4,5,4]  R1941     -4.0419352054595947e-01
    z[4,5,4]  R1942     -2.6978400349617004e-01
    z[4,5,4]  R1943     -1.9433347880840302e-01
    z[4,5,4]  R1944     -6.5487218089401722e-03
    z[4,5,4]  R1945     -2.4164788424968719e-01
    z[4,5,4]  R1946     -5.3179544210433960e-01
    z[4,5,4]  R1947     -0.715399980545044
    z[4,5,4]  R1948     2.4729570746421814e-01
    z[4,5,4]  R1949     -2.6987606287002563e-01
    z[4,5,4]  R1950     2.1347737312316895e-01
    z[4,5,4]  R1951     6.6397614777088165e-02
    z[4,5,4]  R1952     -0.0682741329073906
    z[4,5,4]  R1953     1.9729943946003914e-02
    z[4,5,4]  R1954     1.2859743833541870e-01
    z[4,5,4]  R1955     3.1697552651166916e-02
    z[4,5,4]  R1956     -4.4534732587635517e-03
    z[4,5,4]  R1957     1.1686767637729645e-01
    z[4,5,4]  R1958     -2.5458750128746033e-01
    z[4,5,4]  R1959     -3.8164101541042328e-02
    z[4,5,5]  R43       -1
    z[4,5,5]  R52       1
    z[4,5,5]  R1898     -1
    z[4,5,5]  R1899     1
    z[4,5,5]  R1902     1.0589842498302460e-01
    z[4,5,5]  R1903     1.9910521805286407e-01
    z[4,5,5]  R1904     -4.3603006005287170e-01
    z[4,5,5]  R1905     -7.7005207538604736e-02
    z[4,5,5]  R1906     -1.8238103389739990e-01
    z[4,5,5]  R1907     -5.3781938552856445e-01
    z[4,5,5]  R1908     -5.3805822134017944e-01
    z[4,5,5]  R1909     -2.5099441409111023e-01
    z[4,5,5]  R1910     1.6526119410991669e-01
    z[4,5,5]  R1911     -2.2789016366004944e-01
    z[4,5,5]  R1912     -3.2468929886817932e-01
    z[4,5,5]  R1913     5.9007006883621216e-01
    z[4,5,5]  R1914     2.2747208178043365e-01
    z[4,5,5]  R1915     3.8374658674001694e-02
    z[4,5,5]  R1916     4.2450428009033203e-01
    z[4,5,5]  R1917     3.1561350822448730e-01
    z[4,5,5]  R1918     5.3853505849838257e-01
    z[4,5,5]  R1919     1.8006195127964020e-01
    z[4,5,5]  R1920     -2.6605721563100815e-02
    z[4,5,5]  R1921     -1.6208153218030930e-02
    z[4,5,5]  R1922     4.7667166590690613e-01
    z[4,5,5]  R1923     -0.448431134223938
    z[4,5,5]  R1924     2.6421904563903809e-01
    z[4,5,5]  R1925     -1.2603420019149780e-01
    z[4,5,5]  R1926     -1.8004243075847626e-01
    z[4,5,5]  R1927     2.6888146996498108e-01
    z[4,5,5]  R1928     0.0771268755197525
    z[4,5,5]  R1929     -1.2749271094799042e-01
    z[4,5,5]  R1930     3.5987859964370728e-01
    z[4,5,5]  R1931     -2.9945179820060730e-02
    z[4,5,5]  R1932     7.1670997142791748e-01
    z[4,5,5]  R1933     -6.7529237270355225e-01
    z[4,5,5]  R1934     5.5308806896209717e-01
    z[4,5,5]  R1935     -2.6985979080200195e-01
    z[4,5,5]  R1936     -1.2557722628116608e-01
    z[4,5,5]  R1937     -7.6149078086018562e-03
    z[4,5,5]  R1938     1.1959961801767349e-01
    z[4,5,5]  R1939     1.7496833205223083e-01
    z[4,5,5]  R1940     0.0494014136493206
    z[4,5,5]  R1941     1.8870449066162109e-01
    z[4,5,5]  R1942     -8.4242987632751465e-01
    z[4,5,5]  R1943     -4.9546590447425842e-01
    z[4,5,5]  R1944     -1.6400189697742462e-01
    z[4,5,5]  R1945     -5.3578341007232666e-01
    z[4,5,5]  R1946     -1.5329921245574951e-01
    z[4,5,5]  R1947     2.3713913559913635e-01
    z[4,5,5]  R1948     1.9079077243804932e-01
    z[4,5,5]  R1949     3.3418321609497070e-01
    z[4,5,5]  R1950     1.5212121605873108e-01
    z[4,5,5]  R1951     3.3937299251556396e-01
    z[4,5,5]  R1952     4.7862115502357483e-01
    z[4,5,5]  R1953     3.7534487247467041e-01
    z[4,5,5]  R1954     4.4864749908447266e-01
    z[4,5,5]  R1955     2.3144076764583588e-01
    z[4,5,5]  R1956     -4.6014860272407532e-02
    z[4,5,5]  R1957     6.8947292864322662e-02
    z[4,5,5]  R1958     3.8678757846355438e-02
    z[4,5,5]  R1959     2.7021130919456482e-01
    z[4,5,6]  R44       -1
    z[4,5,6]  R53       1
    z[4,5,6]  R1900     -1
    z[4,5,6]  R1901     1
    z[4,5,6]  R1902     -2.1268017590045929e-01
    z[4,5,6]  R1903     -3.8311373442411423e-02
    z[4,5,6]  R1904     1.5584291517734528e-01
    z[4,5,6]  R1905     4.4229146838188171e-01
    z[4,5,6]  R1906     -2.8183114528656006e-01
    z[4,5,6]  R1907     -0.0658646747469902
    z[4,5,6]  R1908     1.1234815418720245e-01
    z[4,5,6]  R1909     3.6079812049865723e-01
    z[4,5,6]  R1910     3.8736215233802795e-01
    z[4,5,6]  R1911     -0.0959039181470871
    z[4,5,6]  R1912     4.5730617642402649e-01
    z[4,5,6]  R1913     -2.6038253307342529e-01
    z[4,5,6]  R1914     -6.8244969844818115e-01
    z[4,5,6]  R1915     4.1007933020591736e-01
    z[4,5,6]  R1916     1.2177149206399918e-01
    z[4,5,6]  R1917     -1.5467011835426092e-03
    z[4,5,6]  R1918     1.3537776470184326e-01
    z[4,5,6]  R1919     -1.6832861304283142e-01
    z[4,5,6]  R1920     -7.6504252851009369e-02
    z[4,5,6]  R1921     6.8134978413581848e-02
    z[4,5,6]  R1922     -4.6509113907814026e-01
    z[4,5,6]  R1923     -2.8217834234237671e-01
    z[4,5,6]  R1924     -4.7712126374244690e-01
    z[4,5,6]  R1925     -2.9108732938766479e-01
    z[4,5,6]  R1926     -2.6488119363784790e-01
    z[4,5,6]  R1927     4.1941741108894348e-01
    z[4,5,6]  R1928     2.1148538589477539e-01
    z[4,5,6]  R1929     -5.6169737130403519e-02
    z[4,5,6]  R1930     1.5174710750579834e-01
    z[4,5,6]  R1931     -1.6998873651027679e-01
    z[4,5,6]  R1932     1.5894284844398499e-01
    z[4,5,6]  R1933     -6.5151679515838623e-01
    z[4,5,6]  R1934     -4.5515727996826172e-01
    z[4,5,6]  R1935     -5.3155469894409180e-01
    z[4,5,6]  R1936     9.0372376143932343e-02
    z[4,5,6]  R1937     -2.5739893317222595e-01
    z[4,5,6]  R1938     2.9591116309165955e-01
    z[4,5,6]  R1939     3.3283557742834091e-02
    z[4,5,6]  R1940     2.6818379759788513e-01
    z[4,5,6]  R1941     1.1601234972476959e-01
    z[4,5,6]  R1942     8.8194563984870911e-02
    z[4,5,6]  R1943     -7.1552854776382446e-01
    z[4,5,6]  R1944     -2.3107738792896271e-01
    z[4,5,6]  R1945     -4.6637782454490662e-01
    z[4,5,6]  R1946     6.1569482088088989e-01
    z[4,5,6]  R1947     1.5540994703769684e-01
    z[4,5,6]  R1948     2.3442228138446808e-01
    z[4,5,6]  R1949     -9.4112023711204529e-02
    z[4,5,6]  R1950     3.0019092559814453e-01
    z[4,5,6]  R1951     -0.0115215377882123
    z[4,5,6]  R1952     -1.6581559181213379e-01
    z[4,5,6]  R1953     -4.2370134592056274e-01
    z[4,5,6]  R1954     1.5776583552360535e-01
    z[4,5,6]  R1955     -1.3237112760543823e-01
    z[4,5,6]  R1956     1.8176500499248505e-01
    z[4,5,6]  R1957     1.4365004003047943e-01
    z[4,5,6]  R1958     7.5863234698772430e-02
    z[4,5,6]  R1959     3.0158379673957825e-01
    z[5,4,0]  R38       1
    z[5,4,0]  R47       -1
    z[5,4,0]  R1960     -1
    z[5,4,0]  R1961     1
    z[5,4,0]  R1974     2.7077559381723404e-02
    z[5,4,0]  R1975     -1.4716574549674988e-01
    z[5,4,0]  R1976     6.6157186031341553e-01
    z[5,4,0]  R1977     3.2766574621200562e-01
    z[5,4,0]  R1978     3.5326221585273743e-01
    z[5,4,0]  R1979     -4.8980057239532471e-02
    z[5,4,0]  R1980     4.2251950502395630e-01
    z[5,4,0]  R1981     -7.9604452848434448e-01
    z[5,4,0]  R1982     3.9534687995910645e-01
    z[5,4,0]  R1983     -4.4654479622840881e-01
    z[5,4,0]  R1984     -1.4632028341293335e-01
    z[5,4,0]  R1985     -0.420944482088089
    z[5,4,0]  R1986     -2.4442516267299652e-01
    z[5,4,0]  R1987     -9.0486049652099609e-01
    z[5,4,0]  R1988     -8.8210612535476685e-01
    z[5,4,0]  R1989     -8.8734483718872070e-01
    z[5,4,0]  R1990     -0.904356837272644
    z[5,4,0]  R1991     -8.9519476890563965e-01
    z[5,4,0]  R1992     7.7755272388458252e-01
    z[5,4,0]  R1993     6.3734090328216553e-01
    z[5,4,0]  R1994     5.8479756116867065e-01
    z[5,4,0]  R1995     6.0710543394088745e-01
    z[5,4,0]  R1996     3.8329303264617920e-01
    z[5,4,0]  R1997     2.1687658131122589e-01
    z[5,4,0]  R1998     2.1503403782844543e-02
    z[5,4,0]  R1999     3.1548026204109192e-01
    z[5,4,0]  R2000     0.434079110622406
    z[5,4,0]  R2001     0.626015841960907
    z[5,4,0]  R2002     5.6098586320877075e-01
    z[5,4,0]  R2003     3.3980640769004822e-01
    z[5,4,0]  R2004     2.1491794288158417e-01
    z[5,4,0]  R2005     -6.8108814954757690e-01
    z[5,4,0]  R2006     -3.8750776648521423e-01
    z[5,4,0]  R2007     -4.7351148724555969e-01
    z[5,4,0]  R2008     -5.8315277099609375e-01
    z[5,4,0]  R2009     -6.1338418722152710e-01
    z[5,4,0]  R2010     -8.8346785306930542e-01
    z[5,4,0]  R2011     -8.1260401010513306e-01
    z[5,4,0]  R2012     2.0011156797409058e-01
    z[5,4,0]  R2013     -3.7151196599006653e-01
    z[5,4,0]  R2014     -0.533784031867981
    z[5,4,0]  R2015     -7.4237263202667236e-01
    z[5,4,0]  R2016     -2.9535919427871704e-01
    z[5,4,0]  R2017     -2.5586044788360596e-01
    z[5,4,0]  R2018     -3.4152883291244507e-01
    z[5,4,0]  R2019     -4.1218620538711548e-01
    z[5,4,0]  R2020     -3.6068147420883179e-01
    z[5,4,0]  R2021     -1.7500633001327515e-01
    z[5,4,0]  R2022     4.9794915318489075e-01
    z[5,4,0]  R2023     1.9511704146862030e-01
    z[5,4,0]  R2024     3.2752478122711182e-01
    z[5,4,0]  R2025     -5.1430463790893555e-02
    z[5,4,0]  R2026     -5.2251976728439331e-01
    z[5,4,0]  R2027     -6.1259114742279053e-01
    z[5,4,0]  R2028     -3.8758561015129089e-01
    z[5,4,0]  R2029     -8.7527495622634888e-01
    z[5,4,0]  R2030     -6.8857854604721069e-01
    z[5,4,0]  R2031     -6.6475450992584229e-01
    z[5,4,1]  R39       1
    z[5,4,1]  R48       -1
    z[5,4,1]  R1962     -1
    z[5,4,1]  R1963     1
    z[5,4,1]  R1974     2.1032528579235077e-01
    z[5,4,1]  R1975     1.4855297282338142e-02
    z[5,4,1]  R1976     -4.6718326210975647e-01
    z[5,4,1]  R1977     4.1429869830608368e-02
    z[5,4,1]  R1978     -1.5066677331924438e-01
    z[5,4,1]  R1979     3.8200950622558594e-01
    z[5,4,1]  R1980     -5.6179088354110718e-01
    z[5,4,1]  R1981     -2.5091665983200073e-01
    z[5,4,1]  R1982     0.735697329044342
    z[5,4,1]  R1983     5.1107460260391235e-01
    z[5,4,1]  R1984     3.1154605746269226e-01
    z[5,4,1]  R1985     4.4397643208503723e-01
    z[5,4,1]  R1986     -2.0141474902629852e-01
    z[5,4,1]  R1987     -1.1928041279315948e-01
    z[5,4,1]  R1988     1.0443801991641521e-02
    z[5,4,1]  R1989     -1.9972890615463257e-01
    z[5,4,1]  R1990     -2.3908819258213043e-01
    z[5,4,1]  R1991     -0.086459219455719
    z[5,4,1]  R1992     -3.9053717255592346e-01
    z[5,4,1]  R1993     -2.3057553172111511e-01
    z[5,4,1]  R1994     -3.9834627509117126e-01
    z[5,4,1]  R1995     -3.2214903831481934e-01
    z[5,4,1]  R1996     -3.1685826182365417e-01
    z[5,4,1]  R1997     0.18353371322155
    z[5,4,1]  R1998     1.6331650316715240e-01
    z[5,4,1]  R1999     -2.2192259784787893e-03
    z[5,4,1]  R2000     -1.6745314002037048e-02
    z[5,4,1]  R2001     1.4434356987476349e-01
    z[5,4,1]  R2002     4.1506272554397583e-01
    z[5,4,1]  R2003     4.3609973788261414e-01
    z[5,4,1]  R2004     6.3473701477050781e-01
    z[5,4,1]  R2005     3.7802930921316147e-02
    z[5,4,1]  R2006     3.8586241006851196e-01
    z[5,4,1]  R2007     8.1718474626541138e-02
    z[5,4,1]  R2008     7.6087392866611481e-02
    z[5,4,1]  R2009     6.9843932986259460e-02
    z[5,4,1]  R2010     1.9197058677673340e-01
    z[5,4,1]  R2011     -1.7714096605777740e-01
    z[5,4,1]  R2012     -8.3324313163757324e-02
    z[5,4,1]  R2013     2.2697913646697998e-01
    z[5,4,1]  R2014     7.6907515525817871e-02
    z[5,4,1]  R2015     9.3378983438014984e-02
    z[5,4,1]  R2016     -2.8235715627670288e-01
    z[5,4,1]  R2017     6.9965416193008423e-01
    z[5,4,1]  R2018     6.3529521226882935e-01
    z[5,4,1]  R2019     6.1751806735992432e-01
    z[5,4,1]  R2020     5.3761011362075806e-01
    z[5,4,1]  R2021     4.2723336815834045e-01
    z[5,4,1]  R2022     -9.8839856684207916e-02
    z[5,4,1]  R2023     -2.4453786015510559e-01
    z[5,4,1]  R2024     6.5430924296379089e-02
    z[5,4,1]  R2025     4.4217151403427124e-01
    z[5,4,1]  R2026     2.1262690424919128e-01
    z[5,4,1]  R2027     -4.7013565897941589e-01
    z[5,4,1]  R2028     -5.2967935800552368e-01
    z[5,4,1]  R2029     -0.095587819814682
    z[5,4,1]  R2030     -3.5056486725807190e-01
    z[5,4,1]  R2031     -0.279590904712677
    z[5,4,2]  R40       1
    z[5,4,2]  R49       -1
    z[5,4,2]  R1964     -1
    z[5,4,2]  R1965     1
    z[5,4,2]  R1974     -3.7991592288017273e-01
    z[5,4,2]  R1975     -2.9864221811294556e-01
    z[5,4,2]  R1976     2.2859716415405273e-01
    z[5,4,2]  R1977     5.4286282509565353e-02
    z[5,4,2]  R1978     3.1203457713127136e-01
    z[5,4,2]  R1979     3.1310686469078064e-01
    z[5,4,2]  R1980     -2.7816560864448547e-01
    z[5,4,2]  R1981     2.3640289902687073e-01
    z[5,4,2]  R1982     -2.6094261556863785e-02
    z[5,4,2]  R1983     1.8322923779487610e-01
    z[5,4,2]  R1984     5.8794164657592773e-01
    z[5,4,2]  R1985     4.9670797586441040e-01
    z[5,4,2]  R1986     -4.6606090664863586e-01
    z[5,4,2]  R1987     -4.8526491969823837e-02
    z[5,4,2]  R1988     -1.6023044288158417e-01
    z[5,4,2]  R1989     -1.6508170962333679e-01
    z[5,4,2]  R1990     3.1460151076316833e-02
    z[5,4,2]  R1991     -3.8388580083847046e-02
    z[5,4,2]  R1992     9.6842184662818909e-02
    z[5,4,2]  R1993     -0.262206107378006
    z[5,4,2]  R1994     9.9797770380973816e-02
    z[5,4,2]  R1995     -4.1073697805404663e-01
    z[5,4,2]  R1996     -7.5050640106201172e-01
    z[5,4,2]  R1997     -7.6529151201248169e-01
    z[5,4,2]  R1998     -7.0444834232330322e-01
    z[5,4,2]  R1999     -6.2899458408355713e-01
    z[5,4,2]  R2000     -5.4802465438842773e-01
    z[5,4,2]  R2001     -3.5592085123062134e-01
    z[5,4,2]  R2002     -1.5294665098190308e-01
    z[5,4,2]  R2003     4.0598326921463013e-01
    z[5,4,2]  R2004     6.5435290336608887e-02
    z[5,4,2]  R2005     -4.0175712108612061e-01
    z[5,4,2]  R2006     -5.4046612977981567e-01
    z[5,4,2]  R2007     -7.4267548322677612e-01
    z[5,4,2]  R2008     -5.4421937465667725e-01
    z[5,4,2]  R2009     -3.9016574621200562e-01
    z[5,4,2]  R2010     -1.6744016110897064e-01
    z[5,4,2]  R2011     -4.2687937617301941e-01
    z[5,4,2]  R2012     -5.4102480411529541e-01
    z[5,4,2]  R2013     -0.502291738986969
    z[5,4,2]  R2014     -4.4189968705177307e-01
    z[5,4,2]  R2015     -4.9744647741317749e-01
    z[5,4,2]  R2016     -8.1178158521652222e-01
    z[5,4,2]  R2017     2.6623749732971191e-01
    z[5,4,2]  R2018     3.9537829160690308e-01
    z[5,4,2]  R2019     6.1859405832365155e-04
    z[5,4,2]  R2020     1.4093835838139057e-02
    z[5,4,2]  R2021     3.3906945586204529e-01
    z[5,4,2]  R2022     -3.6892163753509521e-01
    z[5,4,2]  R2023     -5.6913815438747406e-02
    z[5,4,2]  R2024     -2.8455594182014465e-01
    z[5,4,2]  R2025     9.5352604985237122e-02
    z[5,4,2]  R2026     -7.0583587884902954e-01
    z[5,4,2]  R2027     -1.8528589606285095e-01
    z[5,4,2]  R2028     -5.0818198919296265e-01
    z[5,4,2]  R2029     1.8494956195354462e-01
    z[5,4,2]  R2030     -8.1987380981445312e-02
    z[5,4,2]  R2031     5.7027824223041534e-02
    z[5,4,3]  R41       1
    z[5,4,3]  R50       -1
    z[5,4,3]  R1966     -1
    z[5,4,3]  R1967     1
    z[5,4,3]  R1974     1.4298340678215027e-01
    z[5,4,3]  R1975     3.0610656738281250e-01
    z[5,4,3]  R1976     -4.5985820889472961e-01
    z[5,4,3]  R1977     -5.7009279727935791e-01
    z[5,4,3]  R1978     -2.6410719752311707e-01
    z[5,4,3]  R1979     4.0180769562721252e-01
    z[5,4,3]  R1980     5.2533990144729614e-01
    z[5,4,3]  R1981     -2.3259180784225464e-01
    z[5,4,3]  R1982     3.7807571887969971e-01
    z[5,4,3]  R1983     -6.2137925624847412e-01
    z[5,4,3]  R1984     -5.2404171228408813e-01
    z[5,4,3]  R1985     -2.4119694530963898e-01
    z[5,4,3]  R1986     -6.6314691305160522e-01
    z[5,4,3]  R1987     -3.0422553420066833e-01
    z[5,4,3]  R1988     -4.0116128325462341e-01
    z[5,4,3]  R1989     -3.2623365521430969e-01
    z[5,4,3]  R1990     -2.2785899043083191e-01
    z[5,4,3]  R1991     -1.5573722124099731e-01
    z[5,4,3]  R1992     -0.414764404296875
    z[5,4,3]  R1993     -2.5034227967262268e-01
    z[5,4,3]  R1994     -3.9581304788589478e-01
    z[5,4,3]  R1995     -3.9183524250984192e-01
    z[5,4,3]  R1996     -2.0016261935234070e-01
    z[5,4,3]  R1997     -1.9974724948406219e-01
    z[5,4,3]  R1998     1.7060551047325134e-01
    z[5,4,3]  R1999     1.6670159995555878e-01
    z[5,4,3]  R2000     1.4519914984703064e-01
    z[5,4,3]  R2001     4.4855013489723206e-01
    z[5,4,3]  R2002     3.5233241319656372e-01
    z[5,4,3]  R2003     3.2735961675643921e-01
    z[5,4,3]  R2004     0.160980224609375
    z[5,4,3]  R2005     4.2600056529045105e-01
    z[5,4,3]  R2006     4.6237173676490784e-01
    z[5,4,3]  R2007     3.0387637019157410e-01
    z[5,4,3]  R2008     2.2216325998306274e-01
    z[5,4,3]  R2009     5.8633047342300415e-01
    z[5,4,3]  R2010     3.7895858287811279e-01
    z[5,4,3]  R2011     3.3695170283317566e-01
    z[5,4,3]  R2012     4.5463311672210693e-01
    z[5,4,3]  R2013     4.7110924124717712e-01
    z[5,4,3]  R2014     3.7987053394317627e-01
    z[5,4,3]  R2015     2.6640614867210388e-01
    z[5,4,3]  R2016     1.8347172439098358e-01
    z[5,4,3]  R2017     -3.3782243728637695e-01
    z[5,4,3]  R2018     -5.2226340770721436e-01
    z[5,4,3]  R2019     -0.650968074798584
    z[5,4,3]  R2020     -6.5431934595108032e-01
    z[5,4,3]  R2021     -7.9564833641052246e-01
    z[5,4,3]  R2022     1.7952050268650055e-01
    z[5,4,3]  R2023     1.1064269393682480e-01
    z[5,4,3]  R2024     4.6490901708602905e-01
    z[5,4,3]  R2025     5.7867074012756348e-01
    z[5,4,3]  R2026     3.6209985613822937e-01
    z[5,4,3]  R2027     -2.6049536466598511e-01
    z[5,4,3]  R2028     -3.7754493951797485e-01
    z[5,4,3]  R2029     -3.9802354574203491e-01
    z[5,4,3]  R2030     -5.6722772121429443e-01
    z[5,4,3]  R2031     -5.1404041051864624e-01
    z[5,4,4]  R42       1
    z[5,4,4]  R51       -1
    z[5,4,4]  R1968     -1
    z[5,4,4]  R1969     1
    z[5,4,4]  R1974     -2.6978400349617004e-01
    z[5,4,4]  R1975     -1.9433347880840302e-01
    z[5,4,4]  R1976     -6.5487218089401722e-03
    z[5,4,4]  R1977     -2.4164788424968719e-01
    z[5,4,4]  R1978     -5.3179544210433960e-01
    z[5,4,4]  R1979     -0.715399980545044
    z[5,4,4]  R1980     2.4729570746421814e-01
    z[5,4,4]  R1981     -2.6987606287002563e-01
    z[5,4,4]  R1982     2.1347737312316895e-01
    z[5,4,4]  R1983     6.6397614777088165e-02
    z[5,4,4]  R1984     -0.0682741329073906
    z[5,4,4]  R1985     1.9729943946003914e-02
    z[5,4,4]  R1986     1.2859743833541870e-01
    z[5,4,4]  R1987     3.1697552651166916e-02
    z[5,4,4]  R1988     -4.4534732587635517e-03
    z[5,4,4]  R1989     1.1686767637729645e-01
    z[5,4,4]  R1990     -2.5458750128746033e-01
    z[5,4,4]  R1991     -3.8164101541042328e-02
    z[5,4,4]  R1992     -7.0972524583339691e-02
    z[5,4,4]  R1993     -6.0671043395996094e-01
    z[5,4,4]  R1994     -3.4394067525863647e-01
    z[5,4,4]  R1995     -6.2061451375484467e-02
    z[5,4,4]  R1996     -1.9149589538574219e-01
    z[5,4,4]  R1997     1.1042827740311623e-02
    z[5,4,4]  R1998     -3.8129106163978577e-01
    z[5,4,4]  R1999     -0.532794713973999
    z[5,4,4]  R2000     -5.5903512239456177e-01
    z[5,4,4]  R2001     -4.4526490569114685e-01
    z[5,4,4]  R2002     -2.2568744421005249e-01
    z[5,4,4]  R2003     -7.9875849187374115e-02
    z[5,4,4]  R2004     5.6935474276542664e-02
    z[5,4,4]  R2005     -1.4888532459735870e-01
    z[5,4,4]  R2006     4.9446769990026951e-03
    z[5,4,4]  R2007     -1.5995962917804718e-01
    z[5,4,4]  R2008     1.6281167045235634e-02
    z[5,4,4]  R2009     -2.4922268092632294e-01
    z[5,4,4]  R2010     -6.6522851586341858e-02
    z[5,4,4]  R2011     8.7339393794536591e-02
    z[5,4,4]  R2012     1.0043712705373764e-01
    z[5,4,4]  R2013     2.3559153079986572e-01
    z[5,4,4]  R2014     2.6856338977813721e-01
    z[5,4,4]  R2015     1.4533202350139618e-01
    z[5,4,4]  R2016     1.9444513320922852e-01
    z[5,4,4]  R2017     1.0865075886249542e-01
    z[5,4,4]  R2018     6.4610771369189024e-04
    z[5,4,4]  R2019     -7.4865229427814484e-02
    z[5,4,4]  R2020     -3.4858337603509426e-03
    z[5,4,4]  R2021     9.5011197030544281e-02
    z[5,4,4]  R2022     1.8711134791374207e-01
    z[5,4,4]  R2023     -0.078458271920681
    z[5,4,4]  R2024     -2.7974864840507507e-01
    z[5,4,4]  R2025     3.2017588615417480e-01
    z[5,4,4]  R2026     1.6883562505245209e-01
    z[5,4,4]  R2027     -4.8497796058654785e-01
    z[5,4,4]  R2028     -0.257993221282959
    z[5,4,4]  R2029     -2.0148554816842079e-02
    z[5,4,4]  R2030     1.1473413556814194e-02
    z[5,4,4]  R2031     -4.0419352054595947e-01
    z[5,4,5]  R43       1
    z[5,4,5]  R52       -1
    z[5,4,5]  R1970     -1
    z[5,4,5]  R1971     1
    z[5,4,5]  R1974     -8.4242987632751465e-01
    z[5,4,5]  R1975     -4.9546590447425842e-01
    z[5,4,5]  R1976     -1.6400189697742462e-01
    z[5,4,5]  R1977     -5.3578341007232666e-01
    z[5,4,5]  R1978     -1.5329921245574951e-01
    z[5,4,5]  R1979     2.3713913559913635e-01
    z[5,4,5]  R1980     1.9079077243804932e-01
    z[5,4,5]  R1981     3.3418321609497070e-01
    z[5,4,5]  R1982     1.5212121605873108e-01
    z[5,4,5]  R1983     3.3937299251556396e-01
    z[5,4,5]  R1984     4.7862115502357483e-01
    z[5,4,5]  R1985     3.7534487247467041e-01
    z[5,4,5]  R1986     4.4864749908447266e-01
    z[5,4,5]  R1987     2.3144076764583588e-01
    z[5,4,5]  R1988     -4.6014860272407532e-02
    z[5,4,5]  R1989     6.8947292864322662e-02
    z[5,4,5]  R1990     3.8678757846355438e-02
    z[5,4,5]  R1991     2.7021130919456482e-01
    z[5,4,5]  R1992     1.0589842498302460e-01
    z[5,4,5]  R1993     1.9910521805286407e-01
    z[5,4,5]  R1994     -4.3603006005287170e-01
    z[5,4,5]  R1995     -7.7005207538604736e-02
    z[5,4,5]  R1996     -1.8238103389739990e-01
    z[5,4,5]  R1997     -5.3781938552856445e-01
    z[5,4,5]  R1998     -5.3805822134017944e-01
    z[5,4,5]  R1999     -2.5099441409111023e-01
    z[5,4,5]  R2000     1.6526119410991669e-01
    z[5,4,5]  R2001     -2.2789016366004944e-01
    z[5,4,5]  R2002     -3.2468929886817932e-01
    z[5,4,5]  R2003     5.9007006883621216e-01
    z[5,4,5]  R2004     2.2747208178043365e-01
    z[5,4,5]  R2005     3.8374658674001694e-02
    z[5,4,5]  R2006     4.2450428009033203e-01
    z[5,4,5]  R2007     3.1561350822448730e-01
    z[5,4,5]  R2008     5.3853505849838257e-01
    z[5,4,5]  R2009     1.8006195127964020e-01
    z[5,4,5]  R2010     -2.6605721563100815e-02
    z[5,4,5]  R2011     -1.6208153218030930e-02
    z[5,4,5]  R2012     4.7667166590690613e-01
    z[5,4,5]  R2013     -0.448431134223938
    z[5,4,5]  R2014     2.6421904563903809e-01
    z[5,4,5]  R2015     -1.2603420019149780e-01
    z[5,4,5]  R2016     -1.8004243075847626e-01
    z[5,4,5]  R2017     2.6888146996498108e-01
    z[5,4,5]  R2018     0.0771268755197525
    z[5,4,5]  R2019     -1.2749271094799042e-01
    z[5,4,5]  R2020     3.5987859964370728e-01
    z[5,4,5]  R2021     -2.9945179820060730e-02
    z[5,4,5]  R2022     7.1670997142791748e-01
    z[5,4,5]  R2023     -6.7529237270355225e-01
    z[5,4,5]  R2024     5.5308806896209717e-01
    z[5,4,5]  R2025     -2.6985979080200195e-01
    z[5,4,5]  R2026     -1.2557722628116608e-01
    z[5,4,5]  R2027     -7.6149078086018562e-03
    z[5,4,5]  R2028     1.1959961801767349e-01
    z[5,4,5]  R2029     1.7496833205223083e-01
    z[5,4,5]  R2030     0.0494014136493206
    z[5,4,5]  R2031     1.8870449066162109e-01
    z[5,4,6]  R44       1
    z[5,4,6]  R53       -1
    z[5,4,6]  R1972     -1
    z[5,4,6]  R1973     1
    z[5,4,6]  R1974     8.8194563984870911e-02
    z[5,4,6]  R1975     -7.1552854776382446e-01
    z[5,4,6]  R1976     -2.3107738792896271e-01
    z[5,4,6]  R1977     -4.6637782454490662e-01
    z[5,4,6]  R1978     6.1569482088088989e-01
    z[5,4,6]  R1979     1.5540994703769684e-01
    z[5,4,6]  R1980     2.3442228138446808e-01
    z[5,4,6]  R1981     -9.4112023711204529e-02
    z[5,4,6]  R1982     3.0019092559814453e-01
    z[5,4,6]  R1983     -0.0115215377882123
    z[5,4,6]  R1984     -1.6581559181213379e-01
    z[5,4,6]  R1985     -4.2370134592056274e-01
    z[5,4,6]  R1986     1.5776583552360535e-01
    z[5,4,6]  R1987     -1.3237112760543823e-01
    z[5,4,6]  R1988     1.8176500499248505e-01
    z[5,4,6]  R1989     1.4365004003047943e-01
    z[5,4,6]  R1990     7.5863234698772430e-02
    z[5,4,6]  R1991     3.0158379673957825e-01
    z[5,4,6]  R1992     -2.1268017590045929e-01
    z[5,4,6]  R1993     -3.8311373442411423e-02
    z[5,4,6]  R1994     1.5584291517734528e-01
    z[5,4,6]  R1995     4.4229146838188171e-01
    z[5,4,6]  R1996     -2.8183114528656006e-01
    z[5,4,6]  R1997     -0.0658646747469902
    z[5,4,6]  R1998     1.1234815418720245e-01
    z[5,4,6]  R1999     3.6079812049865723e-01
    z[5,4,6]  R2000     3.8736215233802795e-01
    z[5,4,6]  R2001     -0.0959039181470871
    z[5,4,6]  R2002     4.5730617642402649e-01
    z[5,4,6]  R2003     -2.6038253307342529e-01
    z[5,4,6]  R2004     -6.8244969844818115e-01
    z[5,4,6]  R2005     4.1007933020591736e-01
    z[5,4,6]  R2006     1.2177149206399918e-01
    z[5,4,6]  R2007     -1.5467011835426092e-03
    z[5,4,6]  R2008     1.3537776470184326e-01
    z[5,4,6]  R2009     -1.6832861304283142e-01
    z[5,4,6]  R2010     -7.6504252851009369e-02
    z[5,4,6]  R2011     6.8134978413581848e-02
    z[5,4,6]  R2012     -4.6509113907814026e-01
    z[5,4,6]  R2013     -2.8217834234237671e-01
    z[5,4,6]  R2014     -4.7712126374244690e-01
    z[5,4,6]  R2015     -2.9108732938766479e-01
    z[5,4,6]  R2016     -2.6488119363784790e-01
    z[5,4,6]  R2017     4.1941741108894348e-01
    z[5,4,6]  R2018     2.1148538589477539e-01
    z[5,4,6]  R2019     -5.6169737130403519e-02
    z[5,4,6]  R2020     1.5174710750579834e-01
    z[5,4,6]  R2021     -1.6998873651027679e-01
    z[5,4,6]  R2022     1.5894284844398499e-01
    z[5,4,6]  R2023     -6.5151679515838623e-01
    z[5,4,6]  R2024     -4.5515727996826172e-01
    z[5,4,6]  R2025     -5.3155469894409180e-01
    z[5,4,6]  R2026     9.0372376143932343e-02
    z[5,4,6]  R2027     -2.5739893317222595e-01
    z[5,4,6]  R2028     2.9591116309165955e-01
    z[5,4,6]  R2029     3.3283557742834091e-02
    z[5,4,6]  R2030     2.6818379759788513e-01
    z[5,4,6]  R2031     1.1601234972476959e-01
    z[4,6,0]  R38       -1
    z[4,6,0]  R56       1
    z[4,6,0]  R2032     -1
    z[4,6,0]  R2033     1
    z[4,6,0]  R2046     7.7755272388458252e-01
    z[4,6,0]  R2047     6.3734090328216553e-01
    z[4,6,0]  R2048     5.8479756116867065e-01
    z[4,6,0]  R2049     6.0710543394088745e-01
    z[4,6,0]  R2050     3.8329303264617920e-01
    z[4,6,0]  R2051     2.1687658131122589e-01
    z[4,6,0]  R2052     2.1503403782844543e-02
    z[4,6,0]  R2053     3.1548026204109192e-01
    z[4,6,0]  R2054     0.434079110622406
    z[4,6,0]  R2055     0.626015841960907
    z[4,6,0]  R2056     5.6098586320877075e-01
    z[4,6,0]  R2057     3.3980640769004822e-01
    z[4,6,0]  R2058     2.1491794288158417e-01
    z[4,6,0]  R2059     -6.8108814954757690e-01
    z[4,6,0]  R2060     -3.8750776648521423e-01
    z[4,6,0]  R2061     -4.7351148724555969e-01
    z[4,6,0]  R2062     -5.8315277099609375e-01
    z[4,6,0]  R2063     -6.1338418722152710e-01
    z[4,6,0]  R2064     -8.8346785306930542e-01
    z[4,6,0]  R2065     -8.1260401010513306e-01
    z[4,6,0]  R2066     2.0011156797409058e-01
    z[4,6,0]  R2067     -3.7151196599006653e-01
    z[4,6,0]  R2068     -0.533784031867981
    z[4,6,0]  R2069     -7.4237263202667236e-01
    z[4,6,0]  R2070     -2.9535919427871704e-01
    z[4,6,0]  R2071     -2.5586044788360596e-01
    z[4,6,0]  R2072     -3.4152883291244507e-01
    z[4,6,0]  R2073     -4.1218620538711548e-01
    z[4,6,0]  R2074     -3.6068147420883179e-01
    z[4,6,0]  R2075     -1.7500633001327515e-01
    z[4,6,0]  R2076     4.9794915318489075e-01
    z[4,6,0]  R2077     1.9511704146862030e-01
    z[4,6,0]  R2078     3.2752478122711182e-01
    z[4,6,0]  R2079     -5.1430463790893555e-02
    z[4,6,0]  R2080     -5.2251976728439331e-01
    z[4,6,0]  R2081     -6.1259114742279053e-01
    z[4,6,0]  R2082     -3.8758561015129089e-01
    z[4,6,0]  R2083     -8.7527495622634888e-01
    z[4,6,0]  R2084     -6.8857854604721069e-01
    z[4,6,0]  R2085     -6.6475450992584229e-01
    z[4,6,0]  R2086     3.5023579001426697e-01
    z[4,6,0]  R2087     -3.5215988755226135e-01
    z[4,6,0]  R2088     5.8928407728672028e-02
    z[4,6,0]  R2089     -0.773298442363739
    z[4,6,0]  R2090     -3.8151663541793823e-01
    z[4,6,0]  R2091     5.7362508773803711e-01
    z[4,6,0]  R2092     -2.8556972742080688e-01
    z[4,6,0]  R2093     -0.5153848528862
    z[4,6,0]  R2094     2.2055222094058990e-01
    z[4,6,0]  R2095     3.5775637626647949e-01
    z[4,6,0]  R2096     1.1200285702943802e-01
    z[4,6,0]  R2097     -2.4220466613769531e-01
    z[4,6,0]  R2098     5.1329302787780762e-01
    z[4,6,0]  R2099     -1.0053907753899693e-03
    z[4,6,0]  R2100     -3.1063526868820190e-01
    z[4,6,0]  R2101     4.3158743530511856e-02
    z[4,6,0]  R2102     4.0677827596664429e-01
    z[4,6,0]  R2103     4.8377943038940430e-01
    z[4,6,0]  R2104     -2.2401331365108490e-01
    z[4,6,0]  R2105     1.4266875386238098e-01
    z[4,6,1]  R39       -1
    z[4,6,1]  R57       1
    z[4,6,1]  R2034     -1
    z[4,6,1]  R2035     1
    z[4,6,1]  R2046     -3.9053717255592346e-01
    z[4,6,1]  R2047     -2.3057553172111511e-01
    z[4,6,1]  R2048     -3.9834627509117126e-01
    z[4,6,1]  R2049     -3.2214903831481934e-01
    z[4,6,1]  R2050     -3.1685826182365417e-01
    z[4,6,1]  R2051     0.18353371322155
    z[4,6,1]  R2052     1.6331650316715240e-01
    z[4,6,1]  R2053     -2.2192259784787893e-03
    z[4,6,1]  R2054     -1.6745314002037048e-02
    z[4,6,1]  R2055     1.4434356987476349e-01
    z[4,6,1]  R2056     4.1506272554397583e-01
    z[4,6,1]  R2057     4.3609973788261414e-01
    z[4,6,1]  R2058     6.3473701477050781e-01
    z[4,6,1]  R2059     3.7802930921316147e-02
    z[4,6,1]  R2060     3.8586241006851196e-01
    z[4,6,1]  R2061     8.1718474626541138e-02
    z[4,6,1]  R2062     7.6087392866611481e-02
    z[4,6,1]  R2063     6.9843932986259460e-02
    z[4,6,1]  R2064     1.9197058677673340e-01
    z[4,6,1]  R2065     -1.7714096605777740e-01
    z[4,6,1]  R2066     -8.3324313163757324e-02
    z[4,6,1]  R2067     2.2697913646697998e-01
    z[4,6,1]  R2068     7.6907515525817871e-02
    z[4,6,1]  R2069     9.3378983438014984e-02
    z[4,6,1]  R2070     -2.8235715627670288e-01
    z[4,6,1]  R2071     6.9965416193008423e-01
    z[4,6,1]  R2072     6.3529521226882935e-01
    z[4,6,1]  R2073     6.1751806735992432e-01
    z[4,6,1]  R2074     5.3761011362075806e-01
    z[4,6,1]  R2075     4.2723336815834045e-01
    z[4,6,1]  R2076     -9.8839856684207916e-02
    z[4,6,1]  R2077     -2.4453786015510559e-01
    z[4,6,1]  R2078     6.5430924296379089e-02
    z[4,6,1]  R2079     4.4217151403427124e-01
    z[4,6,1]  R2080     2.1262690424919128e-01
    z[4,6,1]  R2081     -4.7013565897941589e-01
    z[4,6,1]  R2082     -5.2967935800552368e-01
    z[4,6,1]  R2083     -0.095587819814682
    z[4,6,1]  R2084     -3.5056486725807190e-01
    z[4,6,1]  R2085     -0.279590904712677
    z[4,6,1]  R2086     4.7441938519477844e-01
    z[4,6,1]  R2087     4.3861860036849976e-01
    z[4,6,1]  R2088     3.1076440215110779e-01
    z[4,6,1]  R2089     4.0740135312080383e-01
    z[4,6,1]  R2090     2.6233211159706116e-01
    z[4,6,1]  R2091     2.3242391645908356e-01
    z[4,6,1]  R2092     2.7943196892738342e-01
    z[4,6,1]  R2093     2.7410915493965149e-01
    z[4,6,1]  R2094     3.2776123285293579e-01
    z[4,6,1]  R2095     -7.9866671562194824e-01
    z[4,6,1]  R2096     3.3498460054397583e-01
    z[4,6,1]  R2097     -0.811703085899353
    z[4,6,1]  R2098     -4.3734058737754822e-01
    z[4,6,1]  R2099     -6.0652697086334229e-01
    z[4,6,1]  R2100     -7.9911309480667114e-01
    z[4,6,1]  R2101     -7.3291552066802979e-01
    z[4,6,1]  R2102     -2.1982905268669128e-01
    z[4,6,1]  R2103     -0.44632488489151
    z[4,6,1]  R2104     -7.7259916067123413e-01
    z[4,6,1]  R2105     -5.1101601123809814e-01
    z[4,6,2]  R40       -1
    z[4,6,2]  R58       1
    z[4,6,2]  R2036     -1
    z[4,6,2]  R2037     1
    z[4,6,2]  R2046     9.6842184662818909e-02
    z[4,6,2]  R2047     -0.262206107378006
    z[4,6,2]  R2048     9.9797770380973816e-02
    z[4,6,2]  R2049     -4.1073697805404663e-01
    z[4,6,2]  R2050     -7.5050640106201172e-01
    z[4,6,2]  R2051     -7.6529151201248169e-01
    z[4,6,2]  R2052     -7.0444834232330322e-01
    z[4,6,2]  R2053     -6.2899458408355713e-01
    z[4,6,2]  R2054     -5.4802465438842773e-01
    z[4,6,2]  R2055     -3.5592085123062134e-01
    z[4,6,2]  R2056     -1.5294665098190308e-01
    z[4,6,2]  R2057     4.0598326921463013e-01
    z[4,6,2]  R2058     6.5435290336608887e-02
    z[4,6,2]  R2059     -4.0175712108612061e-01
    z[4,6,2]  R2060     -5.4046612977981567e-01
    z[4,6,2]  R2061     -7.4267548322677612e-01
    z[4,6,2]  R2062     -5.4421937465667725e-01
    z[4,6,2]  R2063     -3.9016574621200562e-01
    z[4,6,2]  R2064     -1.6744016110897064e-01
    z[4,6,2]  R2065     -4.2687937617301941e-01
    z[4,6,2]  R2066     -5.4102480411529541e-01
    z[4,6,2]  R2067     -0.502291738986969
    z[4,6,2]  R2068     -4.4189968705177307e-01
    z[4,6,2]  R2069     -4.9744647741317749e-01
    z[4,6,2]  R2070     -8.1178158521652222e-01
    z[4,6,2]  R2071     2.6623749732971191e-01
    z[4,6,2]  R2072     3.9537829160690308e-01
    z[4,6,2]  R2073     6.1859405832365155e-04
    z[4,6,2]  R2074     1.4093835838139057e-02
    z[4,6,2]  R2075     3.3906945586204529e-01
    z[4,6,2]  R2076     -3.6892163753509521e-01
    z[4,6,2]  R2077     -5.6913815438747406e-02
    z[4,6,2]  R2078     -2.8455594182014465e-01
    z[4,6,2]  R2079     9.5352604985237122e-02
    z[4,6,2]  R2080     -7.0583587884902954e-01
    z[4,6,2]  R2081     -1.8528589606285095e-01
    z[4,6,2]  R2082     -5.0818198919296265e-01
    z[4,6,2]  R2083     1.8494956195354462e-01
    z[4,6,2]  R2084     -8.1987380981445312e-02
    z[4,6,2]  R2085     5.7027824223041534e-02
    z[4,6,2]  R2086     -4.8853706568479538e-02
    z[4,6,2]  R2087     -8.8969990611076355e-02
    z[4,6,2]  R2088     1.0154622793197632e-01
    z[4,6,2]  R2089     -3.5632529854774475e-01
    z[4,6,2]  R2090     -1.1590354889631271e-01
    z[4,6,2]  R2091     -9.4508372247219086e-02
    z[4,6,2]  R2092     1.4536599814891815e-01
    z[4,6,2]  R2093     7.5959369540214539e-02
    z[4,6,2]  R2094     1.7877836525440216e-01
    z[4,6,2]  R2095     1.0002315044403076e-02
    z[4,6,2]  R2096     -1.0571443289518356e-01
    z[4,6,2]  R2097     -3.8934905081987381e-02
    z[4,6,2]  R2098     1.0225692391395569e-01
    z[4,6,2]  R2099     -6.9800354540348053e-02
    z[4,6,2]  R2100     3.7978102918714285e-03
    z[4,6,2]  R2101     -5.7435303926467896e-02
    z[4,6,2]  R2102     0.192092627286911
    z[4,6,2]  R2103     3.1447991728782654e-01
    z[4,6,2]  R2104     -2.2579286247491837e-02
    z[4,6,2]  R2105     1.8240837752819061e-01
    z[4,6,3]  R41       -1
    z[4,6,3]  R59       1
    z[4,6,3]  R2038     -1
    z[4,6,3]  R2039     1
    z[4,6,3]  R2046     -0.414764404296875
    z[4,6,3]  R2047     -2.5034227967262268e-01
    z[4,6,3]  R2048     -3.9581304788589478e-01
    z[4,6,3]  R2049     -3.9183524250984192e-01
    z[4,6,3]  R2050     -2.0016261935234070e-01
    z[4,6,3]  R2051     -1.9974724948406219e-01
    z[4,6,3]  R2052     1.7060551047325134e-01
    z[4,6,3]  R2053     1.6670159995555878e-01
    z[4,6,3]  R2054     1.4519914984703064e-01
    z[4,6,3]  R2055     4.4855013489723206e-01
    z[4,6,3]  R2056     3.5233241319656372e-01
    z[4,6,3]  R2057     3.2735961675643921e-01
    z[4,6,3]  R2058     0.160980224609375
    z[4,6,3]  R2059     4.2600056529045105e-01
    z[4,6,3]  R2060     4.6237173676490784e-01
    z[4,6,3]  R2061     3.0387637019157410e-01
    z[4,6,3]  R2062     2.2216325998306274e-01
    z[4,6,3]  R2063     5.8633047342300415e-01
    z[4,6,3]  R2064     3.7895858287811279e-01
    z[4,6,3]  R2065     3.3695170283317566e-01
    z[4,6,3]  R2066     4.5463311672210693e-01
    z[4,6,3]  R2067     4.7110924124717712e-01
    z[4,6,3]  R2068     3.7987053394317627e-01
    z[4,6,3]  R2069     2.6640614867210388e-01
    z[4,6,3]  R2070     1.8347172439098358e-01
    z[4,6,3]  R2071     -3.3782243728637695e-01
    z[4,6,3]  R2072     -5.2226340770721436e-01
    z[4,6,3]  R2073     -0.650968074798584
    z[4,6,3]  R2074     -6.5431934595108032e-01
    z[4,6,3]  R2075     -7.9564833641052246e-01
    z[4,6,3]  R2076     1.7952050268650055e-01
    z[4,6,3]  R2077     1.1064269393682480e-01
    z[4,6,3]  R2078     4.6490901708602905e-01
    z[4,6,3]  R2079     5.7867074012756348e-01
    z[4,6,3]  R2080     3.6209985613822937e-01
    z[4,6,3]  R2081     -2.6049536466598511e-01
    z[4,6,3]  R2082     -3.7754493951797485e-01
    z[4,6,3]  R2083     -3.9802354574203491e-01
    z[4,6,3]  R2084     -5.6722772121429443e-01
    z[4,6,3]  R2085     -5.1404041051864624e-01
    z[4,6,3]  R2086     4.5885568857192993e-01
    z[4,6,3]  R2087     3.6241078376770020e-01
    z[4,6,3]  R2088     -6.7626345157623291e-01
    z[4,6,3]  R2089     -2.9832044243812561e-01
    z[4,6,3]  R2090     -4.9292492866516113e-01
    z[4,6,3]  R2091     -6.4670413732528687e-01
    z[4,6,3]  R2092     -0.414843887090683
    z[4,6,3]  R2093     2.7501624822616577e-01
    z[4,6,3]  R2094     -3.6654850840568542e-01
    z[4,6,3]  R2095     -3.4762999415397644e-01
    z[4,6,3]  R2096     -9.0359747409820557e-02
    z[4,6,3]  R2097     0.455278217792511
    z[4,6,3]  R2098     5.8274453878402710e-01
    z[4,6,3]  R2099     5.9091097116470337e-01
    z[4,6,3]  R2100     7.6769270002841949e-02
    z[4,6,3]  R2101     5.2717792987823486e-01
    z[4,6,3]  R2102     -5.3998565673828125e-01
    z[4,6,3]  R2103     5.8625394105911255e-01
    z[4,6,3]  R2104     -1.8576428294181824e-01
    z[4,6,3]  R2105     7.0320683717727661e-01
    z[4,6,4]  R42       -1
    z[4,6,4]  R60       1
    z[4,6,4]  R2040     -1
    z[4,6,4]  R2041     1
    z[4,6,4]  R2046     -7.0972524583339691e-02
    z[4,6,4]  R2047     -6.0671043395996094e-01
    z[4,6,4]  R2048     -3.4394067525863647e-01
    z[4,6,4]  R2049     -6.2061451375484467e-02
    z[4,6,4]  R2050     -1.9149589538574219e-01
    z[4,6,4]  R2051     1.1042827740311623e-02
    z[4,6,4]  R2052     -3.8129106163978577e-01
    z[4,6,4]  R2053     -0.532794713973999
    z[4,6,4]  R2054     -5.5903512239456177e-01
    z[4,6,4]  R2055     -4.4526490569114685e-01
    z[4,6,4]  R2056     -2.2568744421005249e-01
    z[4,6,4]  R2057     -7.9875849187374115e-02
    z[4,6,4]  R2058     5.6935474276542664e-02
    z[4,6,4]  R2059     -1.4888532459735870e-01
    z[4,6,4]  R2060     4.9446769990026951e-03
    z[4,6,4]  R2061     -1.5995962917804718e-01
    z[4,6,4]  R2062     1.6281167045235634e-02
    z[4,6,4]  R2063     -2.4922268092632294e-01
    z[4,6,4]  R2064     -6.6522851586341858e-02
    z[4,6,4]  R2065     8.7339393794536591e-02
    z[4,6,4]  R2066     1.0043712705373764e-01
    z[4,6,4]  R2067     2.3559153079986572e-01
    z[4,6,4]  R2068     2.6856338977813721e-01
    z[4,6,4]  R2069     1.4533202350139618e-01
    z[4,6,4]  R2070     1.9444513320922852e-01
    z[4,6,4]  R2071     1.0865075886249542e-01
    z[4,6,4]  R2072     6.4610771369189024e-04
    z[4,6,4]  R2073     -7.4865229427814484e-02
    z[4,6,4]  R2074     -3.4858337603509426e-03
    z[4,6,4]  R2075     9.5011197030544281e-02
    z[4,6,4]  R2076     1.8711134791374207e-01
    z[4,6,4]  R2077     -0.078458271920681
    z[4,6,4]  R2078     -2.7974864840507507e-01
    z[4,6,4]  R2079     3.2017588615417480e-01
    z[4,6,4]  R2080     1.6883562505245209e-01
    z[4,6,4]  R2081     -4.8497796058654785e-01
    z[4,6,4]  R2082     -0.257993221282959
    z[4,6,4]  R2083     -2.0148554816842079e-02
    z[4,6,4]  R2084     1.1473413556814194e-02
    z[4,6,4]  R2085     -4.0419352054595947e-01
    z[4,6,4]  R2086     0.357509046792984
    z[4,6,4]  R2087     -6.0309016704559326e-01
    z[4,6,4]  R2088     -0.543997585773468
    z[4,6,4]  R2089     -1.0941015928983688e-01
    z[4,6,4]  R2090     3.4542571753263474e-02
    z[4,6,4]  R2091     1.6265991330146790e-01
    z[4,6,4]  R2092     -6.8174833059310913e-01
    z[4,6,4]  R2093     -1.1812223494052887e-01
    z[4,6,4]  R2094     -7.7611476182937622e-01
    z[4,6,4]  R2095     2.8842344880104065e-01
    z[4,6,4]  R2096     2.9466179013252258e-01
    z[4,6,4]  R2097     -5.8741912245750427e-02
    z[4,6,4]  R2098     -4.2761716246604919e-01
    z[4,6,4]  R2099     -2.2641818225383759e-01
    z[4,6,4]  R2100     -4.2552046477794647e-02
    z[4,6,4]  R2101     1.1397330462932587e-01
    z[4,6,4]  R2102     1.2061966955661774e-01
    z[4,6,4]  R2103     -3.0990007519721985e-01
    z[4,6,4]  R2104     -4.6752437949180603e-01
    z[4,6,4]  R2105     -2.5311350822448730e-01
    z[4,6,5]  R43       -1
    z[4,6,5]  R61       1
    z[4,6,5]  R2042     -1
    z[4,6,5]  R2043     1
    z[4,6,5]  R2046     1.0589842498302460e-01
    z[4,6,5]  R2047     1.9910521805286407e-01
    z[4,6,5]  R2048     -4.3603006005287170e-01
    z[4,6,5]  R2049     -7.7005207538604736e-02
    z[4,6,5]  R2050     -1.8238103389739990e-01
    z[4,6,5]  R2051     -5.3781938552856445e-01
    z[4,6,5]  R2052     -5.3805822134017944e-01
    z[4,6,5]  R2053     -2.5099441409111023e-01
    z[4,6,5]  R2054     1.6526119410991669e-01
    z[4,6,5]  R2055     -2.2789016366004944e-01
    z[4,6,5]  R2056     -3.2468929886817932e-01
    z[4,6,5]  R2057     5.9007006883621216e-01
    z[4,6,5]  R2058     2.2747208178043365e-01
    z[4,6,5]  R2059     3.8374658674001694e-02
    z[4,6,5]  R2060     4.2450428009033203e-01
    z[4,6,5]  R2061     3.1561350822448730e-01
    z[4,6,5]  R2062     5.3853505849838257e-01
    z[4,6,5]  R2063     1.8006195127964020e-01
    z[4,6,5]  R2064     -2.6605721563100815e-02
    z[4,6,5]  R2065     -1.6208153218030930e-02
    z[4,6,5]  R2066     4.7667166590690613e-01
    z[4,6,5]  R2067     -0.448431134223938
    z[4,6,5]  R2068     2.6421904563903809e-01
    z[4,6,5]  R2069     -1.2603420019149780e-01
    z[4,6,5]  R2070     -1.8004243075847626e-01
    z[4,6,5]  R2071     2.6888146996498108e-01
    z[4,6,5]  R2072     0.0771268755197525
    z[4,6,5]  R2073     -1.2749271094799042e-01
    z[4,6,5]  R2074     3.5987859964370728e-01
    z[4,6,5]  R2075     -2.9945179820060730e-02
    z[4,6,5]  R2076     7.1670997142791748e-01
    z[4,6,5]  R2077     -6.7529237270355225e-01
    z[4,6,5]  R2078     5.5308806896209717e-01
    z[4,6,5]  R2079     -2.6985979080200195e-01
    z[4,6,5]  R2080     -1.2557722628116608e-01
    z[4,6,5]  R2081     -7.6149078086018562e-03
    z[4,6,5]  R2082     1.1959961801767349e-01
    z[4,6,5]  R2083     1.7496833205223083e-01
    z[4,6,5]  R2084     0.0494014136493206
    z[4,6,5]  R2085     1.8870449066162109e-01
    z[4,6,5]  R2086     -2.6345381140708923e-01
    z[4,6,5]  R2087     -2.3830138146877289e-01
    z[4,6,5]  R2088     -2.6126924157142639e-01
    z[4,6,5]  R2089     6.8551085889339447e-02
    z[4,6,5]  R2090     -2.7362501621246338e-01
    z[4,6,5]  R2091     -3.1204009056091309e-01
    z[4,6,5]  R2092     1.8901422619819641e-01
    z[4,6,5]  R2093     -2.0798480510711670e-01
    z[4,6,5]  R2094     -4.4986773282289505e-02
    z[4,6,5]  R2095     -1.4680914580821991e-01
    z[4,6,5]  R2096     8.4582549333572388e-01
    z[4,6,5]  R2097     -2.3791438341140747e-01
    z[4,6,5]  R2098     -7.7955365180969238e-02
    z[4,6,5]  R2099     1.5660324692726135e-01
    z[4,6,5]  R2100     2.5693657994270325e-01
    z[4,6,5]  R2101     3.5654449462890625e-01
    z[4,6,5]  R2102     6.1161947250366211e-01
    z[4,6,5]  R2103     1.6179552674293518e-01
    z[4,6,5]  R2104     3.1513112783432007e-01
    z[4,6,5]  R2105     3.5332062840461731e-01
    z[4,6,6]  R44       -1
    z[4,6,6]  R62       1
    z[4,6,6]  R2044     -1
    z[4,6,6]  R2045     1
    z[4,6,6]  R2046     -2.1268017590045929e-01
    z[4,6,6]  R2047     -3.8311373442411423e-02
    z[4,6,6]  R2048     1.5584291517734528e-01
    z[4,6,6]  R2049     4.4229146838188171e-01
    z[4,6,6]  R2050     -2.8183114528656006e-01
    z[4,6,6]  R2051     -0.0658646747469902
    z[4,6,6]  R2052     1.1234815418720245e-01
    z[4,6,6]  R2053     3.6079812049865723e-01
    z[4,6,6]  R2054     3.8736215233802795e-01
    z[4,6,6]  R2055     -0.0959039181470871
    z[4,6,6]  R2056     4.5730617642402649e-01
    z[4,6,6]  R2057     -2.6038253307342529e-01
    z[4,6,6]  R2058     -6.8244969844818115e-01
    z[4,6,6]  R2059     4.1007933020591736e-01
    z[4,6,6]  R2060     1.2177149206399918e-01
    z[4,6,6]  R2061     -1.5467011835426092e-03
    z[4,6,6]  R2062     1.3537776470184326e-01
    z[4,6,6]  R2063     -1.6832861304283142e-01
    z[4,6,6]  R2064     -7.6504252851009369e-02
    z[4,6,6]  R2065     6.8134978413581848e-02
    z[4,6,6]  R2066     -4.6509113907814026e-01
    z[4,6,6]  R2067     -2.8217834234237671e-01
    z[4,6,6]  R2068     -4.7712126374244690e-01
    z[4,6,6]  R2069     -2.9108732938766479e-01
    z[4,6,6]  R2070     -2.6488119363784790e-01
    z[4,6,6]  R2071     4.1941741108894348e-01
    z[4,6,6]  R2072     2.1148538589477539e-01
    z[4,6,6]  R2073     -5.6169737130403519e-02
    z[4,6,6]  R2074     1.5174710750579834e-01
    z[4,6,6]  R2075     -1.6998873651027679e-01
    z[4,6,6]  R2076     1.5894284844398499e-01
    z[4,6,6]  R2077     -6.5151679515838623e-01
    z[4,6,6]  R2078     -4.5515727996826172e-01
    z[4,6,6]  R2079     -5.3155469894409180e-01
    z[4,6,6]  R2080     9.0372376143932343e-02
    z[4,6,6]  R2081     -2.5739893317222595e-01
    z[4,6,6]  R2082     2.9591116309165955e-01
    z[4,6,6]  R2083     3.3283557742834091e-02
    z[4,6,6]  R2084     2.6818379759788513e-01
    z[4,6,6]  R2085     1.1601234972476959e-01
    z[4,6,6]  R2086     -4.9204191565513611e-01
    z[4,6,6]  R2087     -3.5190141201019287e-01
    z[4,6,6]  R2088     2.6098656654357910e-01
    z[4,6,6]  R2089     -5.8317434042692184e-02
    z[4,6,6]  R2090     6.7316746711730957e-01
    z[4,6,6]  R2091     2.5680345296859741e-01
    z[4,6,6]  R2092     3.8292786478996277e-01
    z[4,6,6]  R2093     7.2154581546783447e-01
    z[4,6,6]  R2094     -2.7061384916305542e-01
    z[4,6,6]  R2095     -9.1947264969348907e-02
    z[4,6,6]  R2096     -2.3163300752639771e-01
    z[4,6,6]  R2097     1.1673419922590256e-01
    z[4,6,6]  R2098     -0.0792611688375473
    z[4,6,6]  R2099     -4.4976255297660828e-01
    z[4,6,6]  R2100     4.3725162744522095e-01
    z[4,6,6]  R2101     -1.9910500943660736e-01
    z[4,6,6]  R2102     2.6285931468009949e-01
    z[4,6,6]  R2103     -4.4094722718000412e-02
    z[4,6,6]  R2104     1.9140637014061213e-03
    z[4,6,6]  R2105     4.2821615934371948e-02
    z[6,4,0]  R38       1
    z[6,4,0]  R56       -1
    z[6,4,0]  R2106     -1
    z[6,4,0]  R2107     1
    z[6,4,0]  R2120     3.5023579001426697e-01
    z[6,4,0]  R2121     -3.5215988755226135e-01
    z[6,4,0]  R2122     5.8928407728672028e-02
    z[6,4,0]  R2123     -0.773298442363739
    z[6,4,0]  R2124     -3.8151663541793823e-01
    z[6,4,0]  R2125     5.7362508773803711e-01
    z[6,4,0]  R2126     -2.8556972742080688e-01
    z[6,4,0]  R2127     -0.5153848528862
    z[6,4,0]  R2128     2.2055222094058990e-01
    z[6,4,0]  R2129     3.5775637626647949e-01
    z[6,4,0]  R2130     1.1200285702943802e-01
    z[6,4,0]  R2131     -2.4220466613769531e-01
    z[6,4,0]  R2132     5.1329302787780762e-01
    z[6,4,0]  R2133     -1.0053907753899693e-03
    z[6,4,0]  R2134     -3.1063526868820190e-01
    z[6,4,0]  R2135     4.3158743530511856e-02
    z[6,4,0]  R2136     4.0677827596664429e-01
    z[6,4,0]  R2137     4.8377943038940430e-01
    z[6,4,0]  R2138     -2.2401331365108490e-01
    z[6,4,0]  R2139     1.4266875386238098e-01
    z[6,4,0]  R2140     7.7755272388458252e-01
    z[6,4,0]  R2141     6.3734090328216553e-01
    z[6,4,0]  R2142     5.8479756116867065e-01
    z[6,4,0]  R2143     6.0710543394088745e-01
    z[6,4,0]  R2144     3.8329303264617920e-01
    z[6,4,0]  R2145     2.1687658131122589e-01
    z[6,4,0]  R2146     2.1503403782844543e-02
    z[6,4,0]  R2147     3.1548026204109192e-01
    z[6,4,0]  R2148     0.434079110622406
    z[6,4,0]  R2149     0.626015841960907
    z[6,4,0]  R2150     5.6098586320877075e-01
    z[6,4,0]  R2151     3.3980640769004822e-01
    z[6,4,0]  R2152     2.1491794288158417e-01
    z[6,4,0]  R2153     -6.8108814954757690e-01
    z[6,4,0]  R2154     -3.8750776648521423e-01
    z[6,4,0]  R2155     -4.7351148724555969e-01
    z[6,4,0]  R2156     -5.8315277099609375e-01
    z[6,4,0]  R2157     -6.1338418722152710e-01
    z[6,4,0]  R2158     -8.8346785306930542e-01
    z[6,4,0]  R2159     -8.1260401010513306e-01
    z[6,4,0]  R2160     2.0011156797409058e-01
    z[6,4,0]  R2161     -3.7151196599006653e-01
    z[6,4,0]  R2162     -0.533784031867981
    z[6,4,0]  R2163     -7.4237263202667236e-01
    z[6,4,0]  R2164     -2.9535919427871704e-01
    z[6,4,0]  R2165     -2.5586044788360596e-01
    z[6,4,0]  R2166     -3.4152883291244507e-01
    z[6,4,0]  R2167     -4.1218620538711548e-01
    z[6,4,0]  R2168     -3.6068147420883179e-01
    z[6,4,0]  R2169     -1.7500633001327515e-01
    z[6,4,0]  R2170     4.9794915318489075e-01
    z[6,4,0]  R2171     1.9511704146862030e-01
    z[6,4,0]  R2172     3.2752478122711182e-01
    z[6,4,0]  R2173     -5.1430463790893555e-02
    z[6,4,0]  R2174     -5.2251976728439331e-01
    z[6,4,0]  R2175     -6.1259114742279053e-01
    z[6,4,0]  R2176     -3.8758561015129089e-01
    z[6,4,0]  R2177     -8.7527495622634888e-01
    z[6,4,0]  R2178     -6.8857854604721069e-01
    z[6,4,0]  R2179     -6.6475450992584229e-01
    z[6,4,1]  R39       1
    z[6,4,1]  R57       -1
    z[6,4,1]  R2108     -1
    z[6,4,1]  R2109     1
    z[6,4,1]  R2120     4.7441938519477844e-01
    z[6,4,1]  R2121     4.3861860036849976e-01
    z[6,4,1]  R2122     3.1076440215110779e-01
    z[6,4,1]  R2123     4.0740135312080383e-01
    z[6,4,1]  R2124     2.6233211159706116e-01
    z[6,4,1]  R2125     2.3242391645908356e-01
    z[6,4,1]  R2126     2.7943196892738342e-01
    z[6,4,1]  R2127     2.7410915493965149e-01
    z[6,4,1]  R2128     3.2776123285293579e-01
    z[6,4,1]  R2129     -7.9866671562194824e-01
    z[6,4,1]  R2130     3.3498460054397583e-01
    z[6,4,1]  R2131     -0.811703085899353
    z[6,4,1]  R2132     -4.3734058737754822e-01
    z[6,4,1]  R2133     -6.0652697086334229e-01
    z[6,4,1]  R2134     -7.9911309480667114e-01
    z[6,4,1]  R2135     -7.3291552066802979e-01
    z[6,4,1]  R2136     -2.1982905268669128e-01
    z[6,4,1]  R2137     -0.44632488489151
    z[6,4,1]  R2138     -7.7259916067123413e-01
    z[6,4,1]  R2139     -5.1101601123809814e-01
    z[6,4,1]  R2140     -3.9053717255592346e-01
    z[6,4,1]  R2141     -2.3057553172111511e-01
    z[6,4,1]  R2142     -3.9834627509117126e-01
    z[6,4,1]  R2143     -3.2214903831481934e-01
    z[6,4,1]  R2144     -3.1685826182365417e-01
    z[6,4,1]  R2145     0.18353371322155
    z[6,4,1]  R2146     1.6331650316715240e-01
    z[6,4,1]  R2147     -2.2192259784787893e-03
    z[6,4,1]  R2148     -1.6745314002037048e-02
    z[6,4,1]  R2149     1.4434356987476349e-01
    z[6,4,1]  R2150     4.1506272554397583e-01
    z[6,4,1]  R2151     4.3609973788261414e-01
    z[6,4,1]  R2152     6.3473701477050781e-01
    z[6,4,1]  R2153     3.7802930921316147e-02
    z[6,4,1]  R2154     3.8586241006851196e-01
    z[6,4,1]  R2155     8.1718474626541138e-02
    z[6,4,1]  R2156     7.6087392866611481e-02
    z[6,4,1]  R2157     6.9843932986259460e-02
    z[6,4,1]  R2158     1.9197058677673340e-01
    z[6,4,1]  R2159     -1.7714096605777740e-01
    z[6,4,1]  R2160     -8.3324313163757324e-02
    z[6,4,1]  R2161     2.2697913646697998e-01
    z[6,4,1]  R2162     7.6907515525817871e-02
    z[6,4,1]  R2163     9.3378983438014984e-02
    z[6,4,1]  R2164     -2.8235715627670288e-01
    z[6,4,1]  R2165     6.9965416193008423e-01
    z[6,4,1]  R2166     6.3529521226882935e-01
    z[6,4,1]  R2167     6.1751806735992432e-01
    z[6,4,1]  R2168     5.3761011362075806e-01
    z[6,4,1]  R2169     4.2723336815834045e-01
    z[6,4,1]  R2170     -9.8839856684207916e-02
    z[6,4,1]  R2171     -2.4453786015510559e-01
    z[6,4,1]  R2172     6.5430924296379089e-02
    z[6,4,1]  R2173     4.4217151403427124e-01
    z[6,4,1]  R2174     2.1262690424919128e-01
    z[6,4,1]  R2175     -4.7013565897941589e-01
    z[6,4,1]  R2176     -5.2967935800552368e-01
    z[6,4,1]  R2177     -0.095587819814682
    z[6,4,1]  R2178     -3.5056486725807190e-01
    z[6,4,1]  R2179     -0.279590904712677
    z[6,4,2]  R40       1
    z[6,4,2]  R58       -1
    z[6,4,2]  R2110     -1
    z[6,4,2]  R2111     1
    z[6,4,2]  R2120     -4.8853706568479538e-02
    z[6,4,2]  R2121     -8.8969990611076355e-02
    z[6,4,2]  R2122     1.0154622793197632e-01
    z[6,4,2]  R2123     -3.5632529854774475e-01
    z[6,4,2]  R2124     -1.1590354889631271e-01
    z[6,4,2]  R2125     -9.4508372247219086e-02
    z[6,4,2]  R2126     1.4536599814891815e-01
    z[6,4,2]  R2127     7.5959369540214539e-02
    z[6,4,2]  R2128     1.7877836525440216e-01
    z[6,4,2]  R2129     1.0002315044403076e-02
    z[6,4,2]  R2130     -1.0571443289518356e-01
    z[6,4,2]  R2131     -3.8934905081987381e-02
    z[6,4,2]  R2132     1.0225692391395569e-01
    z[6,4,2]  R2133     -6.9800354540348053e-02
    z[6,4,2]  R2134     3.7978102918714285e-03
    z[6,4,2]  R2135     -5.7435303926467896e-02
    z[6,4,2]  R2136     0.192092627286911
    z[6,4,2]  R2137     3.1447991728782654e-01
    z[6,4,2]  R2138     -2.2579286247491837e-02
    z[6,4,2]  R2139     1.8240837752819061e-01
    z[6,4,2]  R2140     9.6842184662818909e-02
    z[6,4,2]  R2141     -0.262206107378006
    z[6,4,2]  R2142     9.9797770380973816e-02
    z[6,4,2]  R2143     -4.1073697805404663e-01
    z[6,4,2]  R2144     -7.5050640106201172e-01
    z[6,4,2]  R2145     -7.6529151201248169e-01
    z[6,4,2]  R2146     -7.0444834232330322e-01
    z[6,4,2]  R2147     -6.2899458408355713e-01
    z[6,4,2]  R2148     -5.4802465438842773e-01
    z[6,4,2]  R2149     -3.5592085123062134e-01
    z[6,4,2]  R2150     -1.5294665098190308e-01
    z[6,4,2]  R2151     4.0598326921463013e-01
    z[6,4,2]  R2152     6.5435290336608887e-02
    z[6,4,2]  R2153     -4.0175712108612061e-01
    z[6,4,2]  R2154     -5.4046612977981567e-01
    z[6,4,2]  R2155     -7.4267548322677612e-01
    z[6,4,2]  R2156     -5.4421937465667725e-01
    z[6,4,2]  R2157     -3.9016574621200562e-01
    z[6,4,2]  R2158     -1.6744016110897064e-01
    z[6,4,2]  R2159     -4.2687937617301941e-01
    z[6,4,2]  R2160     -5.4102480411529541e-01
    z[6,4,2]  R2161     -0.502291738986969
    z[6,4,2]  R2162     -4.4189968705177307e-01
    z[6,4,2]  R2163     -4.9744647741317749e-01
    z[6,4,2]  R2164     -8.1178158521652222e-01
    z[6,4,2]  R2165     2.6623749732971191e-01
    z[6,4,2]  R2166     3.9537829160690308e-01
    z[6,4,2]  R2167     6.1859405832365155e-04
    z[6,4,2]  R2168     1.4093835838139057e-02
    z[6,4,2]  R2169     3.3906945586204529e-01
    z[6,4,2]  R2170     -3.6892163753509521e-01
    z[6,4,2]  R2171     -5.6913815438747406e-02
    z[6,4,2]  R2172     -2.8455594182014465e-01
    z[6,4,2]  R2173     9.5352604985237122e-02
    z[6,4,2]  R2174     -7.0583587884902954e-01
    z[6,4,2]  R2175     -1.8528589606285095e-01
    z[6,4,2]  R2176     -5.0818198919296265e-01
    z[6,4,2]  R2177     1.8494956195354462e-01
    z[6,4,2]  R2178     -8.1987380981445312e-02
    z[6,4,2]  R2179     5.7027824223041534e-02
    z[6,4,3]  R41       1
    z[6,4,3]  R59       -1
    z[6,4,3]  R2112     -1
    z[6,4,3]  R2113     1
    z[6,4,3]  R2120     4.5885568857192993e-01
    z[6,4,3]  R2121     3.6241078376770020e-01
    z[6,4,3]  R2122     -6.7626345157623291e-01
    z[6,4,3]  R2123     -2.9832044243812561e-01
    z[6,4,3]  R2124     -4.9292492866516113e-01
    z[6,4,3]  R2125     -6.4670413732528687e-01
    z[6,4,3]  R2126     -0.414843887090683
    z[6,4,3]  R2127     2.7501624822616577e-01
    z[6,4,3]  R2128     -3.6654850840568542e-01
    z[6,4,3]  R2129     -3.4762999415397644e-01
    z[6,4,3]  R2130     -9.0359747409820557e-02
    z[6,4,3]  R2131     0.455278217792511
    z[6,4,3]  R2132     5.8274453878402710e-01
    z[6,4,3]  R2133     5.9091097116470337e-01
    z[6,4,3]  R2134     7.6769270002841949e-02
    z[6,4,3]  R2135     5.2717792987823486e-01
    z[6,4,3]  R2136     -5.3998565673828125e-01
    z[6,4,3]  R2137     5.8625394105911255e-01
    z[6,4,3]  R2138     -1.8576428294181824e-01
    z[6,4,3]  R2139     7.0320683717727661e-01
    z[6,4,3]  R2140     -0.414764404296875
    z[6,4,3]  R2141     -2.5034227967262268e-01
    z[6,4,3]  R2142     -3.9581304788589478e-01
    z[6,4,3]  R2143     -3.9183524250984192e-01
    z[6,4,3]  R2144     -2.0016261935234070e-01
    z[6,4,3]  R2145     -1.9974724948406219e-01
    z[6,4,3]  R2146     1.7060551047325134e-01
    z[6,4,3]  R2147     1.6670159995555878e-01
    z[6,4,3]  R2148     1.4519914984703064e-01
    z[6,4,3]  R2149     4.4855013489723206e-01
    z[6,4,3]  R2150     3.5233241319656372e-01
    z[6,4,3]  R2151     3.2735961675643921e-01
    z[6,4,3]  R2152     0.160980224609375
    z[6,4,3]  R2153     4.2600056529045105e-01
    z[6,4,3]  R2154     4.6237173676490784e-01
    z[6,4,3]  R2155     3.0387637019157410e-01
    z[6,4,3]  R2156     2.2216325998306274e-01
    z[6,4,3]  R2157     5.8633047342300415e-01
    z[6,4,3]  R2158     3.7895858287811279e-01
    z[6,4,3]  R2159     3.3695170283317566e-01
    z[6,4,3]  R2160     4.5463311672210693e-01
    z[6,4,3]  R2161     4.7110924124717712e-01
    z[6,4,3]  R2162     3.7987053394317627e-01
    z[6,4,3]  R2163     2.6640614867210388e-01
    z[6,4,3]  R2164     1.8347172439098358e-01
    z[6,4,3]  R2165     -3.3782243728637695e-01
    z[6,4,3]  R2166     -5.2226340770721436e-01
    z[6,4,3]  R2167     -0.650968074798584
    z[6,4,3]  R2168     -6.5431934595108032e-01
    z[6,4,3]  R2169     -7.9564833641052246e-01
    z[6,4,3]  R2170     1.7952050268650055e-01
    z[6,4,3]  R2171     1.1064269393682480e-01
    z[6,4,3]  R2172     4.6490901708602905e-01
    z[6,4,3]  R2173     5.7867074012756348e-01
    z[6,4,3]  R2174     3.6209985613822937e-01
    z[6,4,3]  R2175     -2.6049536466598511e-01
    z[6,4,3]  R2176     -3.7754493951797485e-01
    z[6,4,3]  R2177     -3.9802354574203491e-01
    z[6,4,3]  R2178     -5.6722772121429443e-01
    z[6,4,3]  R2179     -5.1404041051864624e-01
    z[6,4,4]  R42       1
    z[6,4,4]  R60       -1
    z[6,4,4]  R2114     -1
    z[6,4,4]  R2115     1
    z[6,4,4]  R2120     0.357509046792984
    z[6,4,4]  R2121     -6.0309016704559326e-01
    z[6,4,4]  R2122     -0.543997585773468
    z[6,4,4]  R2123     -1.0941015928983688e-01
    z[6,4,4]  R2124     3.4542571753263474e-02
    z[6,4,4]  R2125     1.6265991330146790e-01
    z[6,4,4]  R2126     -6.8174833059310913e-01
    z[6,4,4]  R2127     -1.1812223494052887e-01
    z[6,4,4]  R2128     -7.7611476182937622e-01
    z[6,4,4]  R2129     2.8842344880104065e-01
    z[6,4,4]  R2130     2.9466179013252258e-01
    z[6,4,4]  R2131     -5.8741912245750427e-02
    z[6,4,4]  R2132     -4.2761716246604919e-01
    z[6,4,4]  R2133     -2.2641818225383759e-01
    z[6,4,4]  R2134     -4.2552046477794647e-02
    z[6,4,4]  R2135     1.1397330462932587e-01
    z[6,4,4]  R2136     1.2061966955661774e-01
    z[6,4,4]  R2137     -3.0990007519721985e-01
    z[6,4,4]  R2138     -4.6752437949180603e-01
    z[6,4,4]  R2139     -2.5311350822448730e-01
    z[6,4,4]  R2140     -7.0972524583339691e-02
    z[6,4,4]  R2141     -6.0671043395996094e-01
    z[6,4,4]  R2142     -3.4394067525863647e-01
    z[6,4,4]  R2143     -6.2061451375484467e-02
    z[6,4,4]  R2144     -1.9149589538574219e-01
    z[6,4,4]  R2145     1.1042827740311623e-02
    z[6,4,4]  R2146     -3.8129106163978577e-01
    z[6,4,4]  R2147     -0.532794713973999
    z[6,4,4]  R2148     -5.5903512239456177e-01
    z[6,4,4]  R2149     -4.4526490569114685e-01
    z[6,4,4]  R2150     -2.2568744421005249e-01
    z[6,4,4]  R2151     -7.9875849187374115e-02
    z[6,4,4]  R2152     5.6935474276542664e-02
    z[6,4,4]  R2153     -1.4888532459735870e-01
    z[6,4,4]  R2154     4.9446769990026951e-03
    z[6,4,4]  R2155     -1.5995962917804718e-01
    z[6,4,4]  R2156     1.6281167045235634e-02
    z[6,4,4]  R2157     -2.4922268092632294e-01
    z[6,4,4]  R2158     -6.6522851586341858e-02
    z[6,4,4]  R2159     8.7339393794536591e-02
    z[6,4,4]  R2160     1.0043712705373764e-01
    z[6,4,4]  R2161     2.3559153079986572e-01
    z[6,4,4]  R2162     2.6856338977813721e-01
    z[6,4,4]  R2163     1.4533202350139618e-01
    z[6,4,4]  R2164     1.9444513320922852e-01
    z[6,4,4]  R2165     1.0865075886249542e-01
    z[6,4,4]  R2166     6.4610771369189024e-04
    z[6,4,4]  R2167     -7.4865229427814484e-02
    z[6,4,4]  R2168     -3.4858337603509426e-03
    z[6,4,4]  R2169     9.5011197030544281e-02
    z[6,4,4]  R2170     1.8711134791374207e-01
    z[6,4,4]  R2171     -0.078458271920681
    z[6,4,4]  R2172     -2.7974864840507507e-01
    z[6,4,4]  R2173     3.2017588615417480e-01
    z[6,4,4]  R2174     1.6883562505245209e-01
    z[6,4,4]  R2175     -4.8497796058654785e-01
    z[6,4,4]  R2176     -0.257993221282959
    z[6,4,4]  R2177     -2.0148554816842079e-02
    z[6,4,4]  R2178     1.1473413556814194e-02
    z[6,4,4]  R2179     -4.0419352054595947e-01
    z[6,4,5]  R43       1
    z[6,4,5]  R61       -1
    z[6,4,5]  R2116     -1
    z[6,4,5]  R2117     1
    z[6,4,5]  R2120     -2.6345381140708923e-01
    z[6,4,5]  R2121     -2.3830138146877289e-01
    z[6,4,5]  R2122     -2.6126924157142639e-01
    z[6,4,5]  R2123     6.8551085889339447e-02
    z[6,4,5]  R2124     -2.7362501621246338e-01
    z[6,4,5]  R2125     -3.1204009056091309e-01
    z[6,4,5]  R2126     1.8901422619819641e-01
    z[6,4,5]  R2127     -2.0798480510711670e-01
    z[6,4,5]  R2128     -4.4986773282289505e-02
    z[6,4,5]  R2129     -1.4680914580821991e-01
    z[6,4,5]  R2130     8.4582549333572388e-01
    z[6,4,5]  R2131     -2.3791438341140747e-01
    z[6,4,5]  R2132     -7.7955365180969238e-02
    z[6,4,5]  R2133     1.5660324692726135e-01
    z[6,4,5]  R2134     2.5693657994270325e-01
    z[6,4,5]  R2135     3.5654449462890625e-01
    z[6,4,5]  R2136     6.1161947250366211e-01
    z[6,4,5]  R2137     1.6179552674293518e-01
    z[6,4,5]  R2138     3.1513112783432007e-01
    z[6,4,5]  R2139     3.5332062840461731e-01
    z[6,4,5]  R2140     1.0589842498302460e-01
    z[6,4,5]  R2141     1.9910521805286407e-01
    z[6,4,5]  R2142     -4.3603006005287170e-01
    z[6,4,5]  R2143     -7.7005207538604736e-02
    z[6,4,5]  R2144     -1.8238103389739990e-01
    z[6,4,5]  R2145     -5.3781938552856445e-01
    z[6,4,5]  R2146     -5.3805822134017944e-01
    z[6,4,5]  R2147     -2.5099441409111023e-01
    z[6,4,5]  R2148     1.6526119410991669e-01
    z[6,4,5]  R2149     -2.2789016366004944e-01
    z[6,4,5]  R2150     -3.2468929886817932e-01
    z[6,4,5]  R2151     5.9007006883621216e-01
    z[6,4,5]  R2152     2.2747208178043365e-01
    z[6,4,5]  R2153     3.8374658674001694e-02
    z[6,4,5]  R2154     4.2450428009033203e-01
    z[6,4,5]  R2155     3.1561350822448730e-01
    z[6,4,5]  R2156     5.3853505849838257e-01
    z[6,4,5]  R2157     1.8006195127964020e-01
    z[6,4,5]  R2158     -2.6605721563100815e-02
    z[6,4,5]  R2159     -1.6208153218030930e-02
    z[6,4,5]  R2160     4.7667166590690613e-01
    z[6,4,5]  R2161     -0.448431134223938
    z[6,4,5]  R2162     2.6421904563903809e-01
    z[6,4,5]  R2163     -1.2603420019149780e-01
    z[6,4,5]  R2164     -1.8004243075847626e-01
    z[6,4,5]  R2165     2.6888146996498108e-01
    z[6,4,5]  R2166     0.0771268755197525
    z[6,4,5]  R2167     -1.2749271094799042e-01
    z[6,4,5]  R2168     3.5987859964370728e-01
    z[6,4,5]  R2169     -2.9945179820060730e-02
    z[6,4,5]  R2170     7.1670997142791748e-01
    z[6,4,5]  R2171     -6.7529237270355225e-01
    z[6,4,5]  R2172     5.5308806896209717e-01
    z[6,4,5]  R2173     -2.6985979080200195e-01
    z[6,4,5]  R2174     -1.2557722628116608e-01
    z[6,4,5]  R2175     -7.6149078086018562e-03
    z[6,4,5]  R2176     1.1959961801767349e-01
    z[6,4,5]  R2177     1.7496833205223083e-01
    z[6,4,5]  R2178     0.0494014136493206
    z[6,4,5]  R2179     1.8870449066162109e-01
    z[6,4,6]  R44       1
    z[6,4,6]  R62       -1
    z[6,4,6]  R2118     -1
    z[6,4,6]  R2119     1
    z[6,4,6]  R2120     -4.9204191565513611e-01
    z[6,4,6]  R2121     -3.5190141201019287e-01
    z[6,4,6]  R2122     2.6098656654357910e-01
    z[6,4,6]  R2123     -5.8317434042692184e-02
    z[6,4,6]  R2124     6.7316746711730957e-01
    z[6,4,6]  R2125     2.5680345296859741e-01
    z[6,4,6]  R2126     3.8292786478996277e-01
    z[6,4,6]  R2127     7.2154581546783447e-01
    z[6,4,6]  R2128     -2.7061384916305542e-01
    z[6,4,6]  R2129     -9.1947264969348907e-02
    z[6,4,6]  R2130     -2.3163300752639771e-01
    z[6,4,6]  R2131     1.1673419922590256e-01
    z[6,4,6]  R2132     -0.0792611688375473
    z[6,4,6]  R2133     -4.4976255297660828e-01
    z[6,4,6]  R2134     4.3725162744522095e-01
    z[6,4,6]  R2135     -1.9910500943660736e-01
    z[6,4,6]  R2136     2.6285931468009949e-01
    z[6,4,6]  R2137     -4.4094722718000412e-02
    z[6,4,6]  R2138     1.9140637014061213e-03
    z[6,4,6]  R2139     4.2821615934371948e-02
    z[6,4,6]  R2140     -2.1268017590045929e-01
    z[6,4,6]  R2141     -3.8311373442411423e-02
    z[6,4,6]  R2142     1.5584291517734528e-01
    z[6,4,6]  R2143     4.4229146838188171e-01
    z[6,4,6]  R2144     -2.8183114528656006e-01
    z[6,4,6]  R2145     -0.0658646747469902
    z[6,4,6]  R2146     1.1234815418720245e-01
    z[6,4,6]  R2147     3.6079812049865723e-01
    z[6,4,6]  R2148     3.8736215233802795e-01
    z[6,4,6]  R2149     -0.0959039181470871
    z[6,4,6]  R2150     4.5730617642402649e-01
    z[6,4,6]  R2151     -2.6038253307342529e-01
    z[6,4,6]  R2152     -6.8244969844818115e-01
    z[6,4,6]  R2153     4.1007933020591736e-01
    z[6,4,6]  R2154     1.2177149206399918e-01
    z[6,4,6]  R2155     -1.5467011835426092e-03
    z[6,4,6]  R2156     1.3537776470184326e-01
    z[6,4,6]  R2157     -1.6832861304283142e-01
    z[6,4,6]  R2158     -7.6504252851009369e-02
    z[6,4,6]  R2159     6.8134978413581848e-02
    z[6,4,6]  R2160     -4.6509113907814026e-01
    z[6,4,6]  R2161     -2.8217834234237671e-01
    z[6,4,6]  R2162     -4.7712126374244690e-01
    z[6,4,6]  R2163     -2.9108732938766479e-01
    z[6,4,6]  R2164     -2.6488119363784790e-01
    z[6,4,6]  R2165     4.1941741108894348e-01
    z[6,4,6]  R2166     2.1148538589477539e-01
    z[6,4,6]  R2167     -5.6169737130403519e-02
    z[6,4,6]  R2168     1.5174710750579834e-01
    z[6,4,6]  R2169     -1.6998873651027679e-01
    z[6,4,6]  R2170     1.5894284844398499e-01
    z[6,4,6]  R2171     -6.5151679515838623e-01
    z[6,4,6]  R2172     -4.5515727996826172e-01
    z[6,4,6]  R2173     -5.3155469894409180e-01
    z[6,4,6]  R2174     9.0372376143932343e-02
    z[6,4,6]  R2175     -2.5739893317222595e-01
    z[6,4,6]  R2176     2.9591116309165955e-01
    z[6,4,6]  R2177     3.3283557742834091e-02
    z[6,4,6]  R2178     2.6818379759788513e-01
    z[6,4,6]  R2179     1.1601234972476959e-01
    z[5,6,0]  R47       -1
    z[5,6,0]  R56       1
    z[5,6,0]  R2234     -1
    z[5,6,0]  R2235     1
    z[5,6,0]  R2248     2.7077559381723404e-02
    z[5,6,0]  R2249     -1.4716574549674988e-01
    z[5,6,0]  R2250     6.6157186031341553e-01
    z[5,6,0]  R2251     3.2766574621200562e-01
    z[5,6,0]  R2252     3.5326221585273743e-01
    z[5,6,0]  R2253     -4.8980057239532471e-02
    z[5,6,0]  R2254     4.2251950502395630e-01
    z[5,6,0]  R2255     -7.9604452848434448e-01
    z[5,6,0]  R2256     3.9534687995910645e-01
    z[5,6,0]  R2257     -4.4654479622840881e-01
    z[5,6,0]  R2258     -1.4632028341293335e-01
    z[5,6,0]  R2259     -0.420944482088089
    z[5,6,0]  R2260     -2.4442516267299652e-01
    z[5,6,0]  R2261     -9.0486049652099609e-01
    z[5,6,0]  R2262     -8.8210612535476685e-01
    z[5,6,0]  R2263     -8.8734483718872070e-01
    z[5,6,0]  R2264     -0.904356837272644
    z[5,6,0]  R2265     -8.9519476890563965e-01
    z[5,6,0]  R2266     3.5023579001426697e-01
    z[5,6,0]  R2267     -3.5215988755226135e-01
    z[5,6,0]  R2268     5.8928407728672028e-02
    z[5,6,0]  R2269     -0.773298442363739
    z[5,6,0]  R2270     -3.8151663541793823e-01
    z[5,6,0]  R2271     5.7362508773803711e-01
    z[5,6,0]  R2272     -2.8556972742080688e-01
    z[5,6,0]  R2273     -0.5153848528862
    z[5,6,0]  R2274     2.2055222094058990e-01
    z[5,6,0]  R2275     3.5775637626647949e-01
    z[5,6,0]  R2276     1.1200285702943802e-01
    z[5,6,0]  R2277     -2.4220466613769531e-01
    z[5,6,0]  R2278     5.1329302787780762e-01
    z[5,6,0]  R2279     -1.0053907753899693e-03
    z[5,6,0]  R2280     -3.1063526868820190e-01
    z[5,6,0]  R2281     4.3158743530511856e-02
    z[5,6,0]  R2282     4.0677827596664429e-01
    z[5,6,0]  R2283     4.8377943038940430e-01
    z[5,6,0]  R2284     -2.2401331365108490e-01
    z[5,6,0]  R2285     1.4266875386238098e-01
    z[5,6,1]  R48       -1
    z[5,6,1]  R57       1
    z[5,6,1]  R2236     -1
    z[5,6,1]  R2237     1
    z[5,6,1]  R2248     2.1032528579235077e-01
    z[5,6,1]  R2249     1.4855297282338142e-02
    z[5,6,1]  R2250     -4.6718326210975647e-01
    z[5,6,1]  R2251     4.1429869830608368e-02
    z[5,6,1]  R2252     -1.5066677331924438e-01
    z[5,6,1]  R2253     3.8200950622558594e-01
    z[5,6,1]  R2254     -5.6179088354110718e-01
    z[5,6,1]  R2255     -2.5091665983200073e-01
    z[5,6,1]  R2256     0.735697329044342
    z[5,6,1]  R2257     5.1107460260391235e-01
    z[5,6,1]  R2258     3.1154605746269226e-01
    z[5,6,1]  R2259     4.4397643208503723e-01
    z[5,6,1]  R2260     -2.0141474902629852e-01
    z[5,6,1]  R2261     -1.1928041279315948e-01
    z[5,6,1]  R2262     1.0443801991641521e-02
    z[5,6,1]  R2263     -1.9972890615463257e-01
    z[5,6,1]  R2264     -2.3908819258213043e-01
    z[5,6,1]  R2265     -0.086459219455719
    z[5,6,1]  R2266     4.7441938519477844e-01
    z[5,6,1]  R2267     4.3861860036849976e-01
    z[5,6,1]  R2268     3.1076440215110779e-01
    z[5,6,1]  R2269     4.0740135312080383e-01
    z[5,6,1]  R2270     2.6233211159706116e-01
    z[5,6,1]  R2271     2.3242391645908356e-01
    z[5,6,1]  R2272     2.7943196892738342e-01
    z[5,6,1]  R2273     2.7410915493965149e-01
    z[5,6,1]  R2274     3.2776123285293579e-01
    z[5,6,1]  R2275     -7.9866671562194824e-01
    z[5,6,1]  R2276     3.3498460054397583e-01
    z[5,6,1]  R2277     -0.811703085899353
    z[5,6,1]  R2278     -4.3734058737754822e-01
    z[5,6,1]  R2279     -6.0652697086334229e-01
    z[5,6,1]  R2280     -7.9911309480667114e-01
    z[5,6,1]  R2281     -7.3291552066802979e-01
    z[5,6,1]  R2282     -2.1982905268669128e-01
    z[5,6,1]  R2283     -0.44632488489151
    z[5,6,1]  R2284     -7.7259916067123413e-01
    z[5,6,1]  R2285     -5.1101601123809814e-01
    z[5,6,2]  R49       -1
    z[5,6,2]  R58       1
    z[5,6,2]  R2238     -1
    z[5,6,2]  R2239     1
    z[5,6,2]  R2248     -3.7991592288017273e-01
    z[5,6,2]  R2249     -2.9864221811294556e-01
    z[5,6,2]  R2250     2.2859716415405273e-01
    z[5,6,2]  R2251     5.4286282509565353e-02
    z[5,6,2]  R2252     3.1203457713127136e-01
    z[5,6,2]  R2253     3.1310686469078064e-01
    z[5,6,2]  R2254     -2.7816560864448547e-01
    z[5,6,2]  R2255     2.3640289902687073e-01
    z[5,6,2]  R2256     -2.6094261556863785e-02
    z[5,6,2]  R2257     1.8322923779487610e-01
    z[5,6,2]  R2258     5.8794164657592773e-01
    z[5,6,2]  R2259     4.9670797586441040e-01
    z[5,6,2]  R2260     -4.6606090664863586e-01
    z[5,6,2]  R2261     -4.8526491969823837e-02
    z[5,6,2]  R2262     -1.6023044288158417e-01
    z[5,6,2]  R2263     -1.6508170962333679e-01
    z[5,6,2]  R2264     3.1460151076316833e-02
    z[5,6,2]  R2265     -3.8388580083847046e-02
    z[5,6,2]  R2266     -4.8853706568479538e-02
    z[5,6,2]  R2267     -8.8969990611076355e-02
    z[5,6,2]  R2268     1.0154622793197632e-01
    z[5,6,2]  R2269     -3.5632529854774475e-01
    z[5,6,2]  R2270     -1.1590354889631271e-01
    z[5,6,2]  R2271     -9.4508372247219086e-02
    z[5,6,2]  R2272     1.4536599814891815e-01
    z[5,6,2]  R2273     7.5959369540214539e-02
    z[5,6,2]  R2274     1.7877836525440216e-01
    z[5,6,2]  R2275     1.0002315044403076e-02
    z[5,6,2]  R2276     -1.0571443289518356e-01
    z[5,6,2]  R2277     -3.8934905081987381e-02
    z[5,6,2]  R2278     1.0225692391395569e-01
    z[5,6,2]  R2279     -6.9800354540348053e-02
    z[5,6,2]  R2280     3.7978102918714285e-03
    z[5,6,2]  R2281     -5.7435303926467896e-02
    z[5,6,2]  R2282     0.192092627286911
    z[5,6,2]  R2283     3.1447991728782654e-01
    z[5,6,2]  R2284     -2.2579286247491837e-02
    z[5,6,2]  R2285     1.8240837752819061e-01
    z[5,6,3]  R50       -1
    z[5,6,3]  R59       1
    z[5,6,3]  R2240     -1
    z[5,6,3]  R2241     1
    z[5,6,3]  R2248     1.4298340678215027e-01
    z[5,6,3]  R2249     3.0610656738281250e-01
    z[5,6,3]  R2250     -4.5985820889472961e-01
    z[5,6,3]  R2251     -5.7009279727935791e-01
    z[5,6,3]  R2252     -2.6410719752311707e-01
    z[5,6,3]  R2253     4.0180769562721252e-01
    z[5,6,3]  R2254     5.2533990144729614e-01
    z[5,6,3]  R2255     -2.3259180784225464e-01
    z[5,6,3]  R2256     3.7807571887969971e-01
    z[5,6,3]  R2257     -6.2137925624847412e-01
    z[5,6,3]  R2258     -5.2404171228408813e-01
    z[5,6,3]  R2259     -2.4119694530963898e-01
    z[5,6,3]  R2260     -6.6314691305160522e-01
    z[5,6,3]  R2261     -3.0422553420066833e-01
    z[5,6,3]  R2262     -4.0116128325462341e-01
    z[5,6,3]  R2263     -3.2623365521430969e-01
    z[5,6,3]  R2264     -2.2785899043083191e-01
    z[5,6,3]  R2265     -1.5573722124099731e-01
    z[5,6,3]  R2266     4.5885568857192993e-01
    z[5,6,3]  R2267     3.6241078376770020e-01
    z[5,6,3]  R2268     -6.7626345157623291e-01
    z[5,6,3]  R2269     -2.9832044243812561e-01
    z[5,6,3]  R2270     -4.9292492866516113e-01
    z[5,6,3]  R2271     -6.4670413732528687e-01
    z[5,6,3]  R2272     -0.414843887090683
    z[5,6,3]  R2273     2.7501624822616577e-01
    z[5,6,3]  R2274     -3.6654850840568542e-01
    z[5,6,3]  R2275     -3.4762999415397644e-01
    z[5,6,3]  R2276     -9.0359747409820557e-02
    z[5,6,3]  R2277     0.455278217792511
    z[5,6,3]  R2278     5.8274453878402710e-01
    z[5,6,3]  R2279     5.9091097116470337e-01
    z[5,6,3]  R2280     7.6769270002841949e-02
    z[5,6,3]  R2281     5.2717792987823486e-01
    z[5,6,3]  R2282     -5.3998565673828125e-01
    z[5,6,3]  R2283     5.8625394105911255e-01
    z[5,6,3]  R2284     -1.8576428294181824e-01
    z[5,6,3]  R2285     7.0320683717727661e-01
    z[5,6,4]  R51       -1
    z[5,6,4]  R60       1
    z[5,6,4]  R2242     -1
    z[5,6,4]  R2243     1
    z[5,6,4]  R2248     -2.6978400349617004e-01
    z[5,6,4]  R2249     -1.9433347880840302e-01
    z[5,6,4]  R2250     -6.5487218089401722e-03
    z[5,6,4]  R2251     -2.4164788424968719e-01
    z[5,6,4]  R2252     -5.3179544210433960e-01
    z[5,6,4]  R2253     -0.715399980545044
    z[5,6,4]  R2254     2.4729570746421814e-01
    z[5,6,4]  R2255     -2.6987606287002563e-01
    z[5,6,4]  R2256     2.1347737312316895e-01
    z[5,6,4]  R2257     6.6397614777088165e-02
    z[5,6,4]  R2258     -0.0682741329073906
    z[5,6,4]  R2259     1.9729943946003914e-02
    z[5,6,4]  R2260     1.2859743833541870e-01
    z[5,6,4]  R2261     3.1697552651166916e-02
    z[5,6,4]  R2262     -4.4534732587635517e-03
    z[5,6,4]  R2263     1.1686767637729645e-01
    z[5,6,4]  R2264     -2.5458750128746033e-01
    z[5,6,4]  R2265     -3.8164101541042328e-02
    z[5,6,4]  R2266     0.357509046792984
    z[5,6,4]  R2267     -6.0309016704559326e-01
    z[5,6,4]  R2268     -0.543997585773468
    z[5,6,4]  R2269     -1.0941015928983688e-01
    z[5,6,4]  R2270     3.4542571753263474e-02
    z[5,6,4]  R2271     1.6265991330146790e-01
    z[5,6,4]  R2272     -6.8174833059310913e-01
    z[5,6,4]  R2273     -1.1812223494052887e-01
    z[5,6,4]  R2274     -7.7611476182937622e-01
    z[5,6,4]  R2275     2.8842344880104065e-01
    z[5,6,4]  R2276     2.9466179013252258e-01
    z[5,6,4]  R2277     -5.8741912245750427e-02
    z[5,6,4]  R2278     -4.2761716246604919e-01
    z[5,6,4]  R2279     -2.2641818225383759e-01
    z[5,6,4]  R2280     -4.2552046477794647e-02
    z[5,6,4]  R2281     1.1397330462932587e-01
    z[5,6,4]  R2282     1.2061966955661774e-01
    z[5,6,4]  R2283     -3.0990007519721985e-01
    z[5,6,4]  R2284     -4.6752437949180603e-01
    z[5,6,4]  R2285     -2.5311350822448730e-01
    z[5,6,5]  R52       -1
    z[5,6,5]  R61       1
    z[5,6,5]  R2244     -1
    z[5,6,5]  R2245     1
    z[5,6,5]  R2248     -8.4242987632751465e-01
    z[5,6,5]  R2249     -4.9546590447425842e-01
    z[5,6,5]  R2250     -1.6400189697742462e-01
    z[5,6,5]  R2251     -5.3578341007232666e-01
    z[5,6,5]  R2252     -1.5329921245574951e-01
    z[5,6,5]  R2253     2.3713913559913635e-01
    z[5,6,5]  R2254     1.9079077243804932e-01
    z[5,6,5]  R2255     3.3418321609497070e-01
    z[5,6,5]  R2256     1.5212121605873108e-01
    z[5,6,5]  R2257     3.3937299251556396e-01
    z[5,6,5]  R2258     4.7862115502357483e-01
    z[5,6,5]  R2259     3.7534487247467041e-01
    z[5,6,5]  R2260     4.4864749908447266e-01
    z[5,6,5]  R2261     2.3144076764583588e-01
    z[5,6,5]  R2262     -4.6014860272407532e-02
    z[5,6,5]  R2263     6.8947292864322662e-02
    z[5,6,5]  R2264     3.8678757846355438e-02
    z[5,6,5]  R2265     2.7021130919456482e-01
    z[5,6,5]  R2266     -2.6345381140708923e-01
    z[5,6,5]  R2267     -2.3830138146877289e-01
    z[5,6,5]  R2268     -2.6126924157142639e-01
    z[5,6,5]  R2269     6.8551085889339447e-02
    z[5,6,5]  R2270     -2.7362501621246338e-01
    z[5,6,5]  R2271     -3.1204009056091309e-01
    z[5,6,5]  R2272     1.8901422619819641e-01
    z[5,6,5]  R2273     -2.0798480510711670e-01
    z[5,6,5]  R2274     -4.4986773282289505e-02
    z[5,6,5]  R2275     -1.4680914580821991e-01
    z[5,6,5]  R2276     8.4582549333572388e-01
    z[5,6,5]  R2277     -2.3791438341140747e-01
    z[5,6,5]  R2278     -7.7955365180969238e-02
    z[5,6,5]  R2279     1.5660324692726135e-01
    z[5,6,5]  R2280     2.5693657994270325e-01
    z[5,6,5]  R2281     3.5654449462890625e-01
    z[5,6,5]  R2282     6.1161947250366211e-01
    z[5,6,5]  R2283     1.6179552674293518e-01
    z[5,6,5]  R2284     3.1513112783432007e-01
    z[5,6,5]  R2285     3.5332062840461731e-01
    z[5,6,6]  R53       -1
    z[5,6,6]  R62       1
    z[5,6,6]  R2246     -1
    z[5,6,6]  R2247     1
    z[5,6,6]  R2248     8.8194563984870911e-02
    z[5,6,6]  R2249     -7.1552854776382446e-01
    z[5,6,6]  R2250     -2.3107738792896271e-01
    z[5,6,6]  R2251     -4.6637782454490662e-01
    z[5,6,6]  R2252     6.1569482088088989e-01
    z[5,6,6]  R2253     1.5540994703769684e-01
    z[5,6,6]  R2254     2.3442228138446808e-01
    z[5,6,6]  R2255     -9.4112023711204529e-02
    z[5,6,6]  R2256     3.0019092559814453e-01
    z[5,6,6]  R2257     -0.0115215377882123
    z[5,6,6]  R2258     -1.6581559181213379e-01
    z[5,6,6]  R2259     -4.2370134592056274e-01
    z[5,6,6]  R2260     1.5776583552360535e-01
    z[5,6,6]  R2261     -1.3237112760543823e-01
    z[5,6,6]  R2262     1.8176500499248505e-01
    z[5,6,6]  R2263     1.4365004003047943e-01
    z[5,6,6]  R2264     7.5863234698772430e-02
    z[5,6,6]  R2265     3.0158379673957825e-01
    z[5,6,6]  R2266     -4.9204191565513611e-01
    z[5,6,6]  R2267     -3.5190141201019287e-01
    z[5,6,6]  R2268     2.6098656654357910e-01
    z[5,6,6]  R2269     -5.8317434042692184e-02
    z[5,6,6]  R2270     6.7316746711730957e-01
    z[5,6,6]  R2271     2.5680345296859741e-01
    z[5,6,6]  R2272     3.8292786478996277e-01
    z[5,6,6]  R2273     7.2154581546783447e-01
    z[5,6,6]  R2274     -2.7061384916305542e-01
    z[5,6,6]  R2275     -9.1947264969348907e-02
    z[5,6,6]  R2276     -2.3163300752639771e-01
    z[5,6,6]  R2277     1.1673419922590256e-01
    z[5,6,6]  R2278     -0.0792611688375473
    z[5,6,6]  R2279     -4.4976255297660828e-01
    z[5,6,6]  R2280     4.3725162744522095e-01
    z[5,6,6]  R2281     -1.9910500943660736e-01
    z[5,6,6]  R2282     2.6285931468009949e-01
    z[5,6,6]  R2283     -4.4094722718000412e-02
    z[5,6,6]  R2284     1.9140637014061213e-03
    z[5,6,6]  R2285     4.2821615934371948e-02
    z[6,5,0]  R47       1
    z[6,5,0]  R56       -1
    z[6,5,0]  R2286     -1
    z[6,5,0]  R2287     1
    z[6,5,0]  R2300     3.5023579001426697e-01
    z[6,5,0]  R2301     -3.5215988755226135e-01
    z[6,5,0]  R2302     5.8928407728672028e-02
    z[6,5,0]  R2303     -0.773298442363739
    z[6,5,0]  R2304     -3.8151663541793823e-01
    z[6,5,0]  R2305     5.7362508773803711e-01
    z[6,5,0]  R2306     -2.8556972742080688e-01
    z[6,5,0]  R2307     -0.5153848528862
    z[6,5,0]  R2308     2.2055222094058990e-01
    z[6,5,0]  R2309     3.5775637626647949e-01
    z[6,5,0]  R2310     1.1200285702943802e-01
    z[6,5,0]  R2311     -2.4220466613769531e-01
    z[6,5,0]  R2312     5.1329302787780762e-01
    z[6,5,0]  R2313     -1.0053907753899693e-03
    z[6,5,0]  R2314     -3.1063526868820190e-01
    z[6,5,0]  R2315     4.3158743530511856e-02
    z[6,5,0]  R2316     4.0677827596664429e-01
    z[6,5,0]  R2317     4.8377943038940430e-01
    z[6,5,0]  R2318     -2.2401331365108490e-01
    z[6,5,0]  R2319     1.4266875386238098e-01
    z[6,5,0]  R2320     2.7077559381723404e-02
    z[6,5,0]  R2321     -1.4716574549674988e-01
    z[6,5,0]  R2322     6.6157186031341553e-01
    z[6,5,0]  R2323     3.2766574621200562e-01
    z[6,5,0]  R2324     3.5326221585273743e-01
    z[6,5,0]  R2325     -4.8980057239532471e-02
    z[6,5,0]  R2326     4.2251950502395630e-01
    z[6,5,0]  R2327     -7.9604452848434448e-01
    z[6,5,0]  R2328     3.9534687995910645e-01
    z[6,5,0]  R2329     -4.4654479622840881e-01
    z[6,5,0]  R2330     -1.4632028341293335e-01
    z[6,5,0]  R2331     -0.420944482088089
    z[6,5,0]  R2332     -2.4442516267299652e-01
    z[6,5,0]  R2333     -9.0486049652099609e-01
    z[6,5,0]  R2334     -8.8210612535476685e-01
    z[6,5,0]  R2335     -8.8734483718872070e-01
    z[6,5,0]  R2336     -0.904356837272644
    z[6,5,0]  R2337     -8.9519476890563965e-01
    z[6,5,1]  R48       1
    z[6,5,1]  R57       -1
    z[6,5,1]  R2288     -1
    z[6,5,1]  R2289     1
    z[6,5,1]  R2300     4.7441938519477844e-01
    z[6,5,1]  R2301     4.3861860036849976e-01
    z[6,5,1]  R2302     3.1076440215110779e-01
    z[6,5,1]  R2303     4.0740135312080383e-01
    z[6,5,1]  R2304     2.6233211159706116e-01
    z[6,5,1]  R2305     2.3242391645908356e-01
    z[6,5,1]  R2306     2.7943196892738342e-01
    z[6,5,1]  R2307     2.7410915493965149e-01
    z[6,5,1]  R2308     3.2776123285293579e-01
    z[6,5,1]  R2309     -7.9866671562194824e-01
    z[6,5,1]  R2310     3.3498460054397583e-01
    z[6,5,1]  R2311     -0.811703085899353
    z[6,5,1]  R2312     -4.3734058737754822e-01
    z[6,5,1]  R2313     -6.0652697086334229e-01
    z[6,5,1]  R2314     -7.9911309480667114e-01
    z[6,5,1]  R2315     -7.3291552066802979e-01
    z[6,5,1]  R2316     -2.1982905268669128e-01
    z[6,5,1]  R2317     -0.44632488489151
    z[6,5,1]  R2318     -7.7259916067123413e-01
    z[6,5,1]  R2319     -5.1101601123809814e-01
    z[6,5,1]  R2320     2.1032528579235077e-01
    z[6,5,1]  R2321     1.4855297282338142e-02
    z[6,5,1]  R2322     -4.6718326210975647e-01
    z[6,5,1]  R2323     4.1429869830608368e-02
    z[6,5,1]  R2324     -1.5066677331924438e-01
    z[6,5,1]  R2325     3.8200950622558594e-01
    z[6,5,1]  R2326     -5.6179088354110718e-01
    z[6,5,1]  R2327     -2.5091665983200073e-01
    z[6,5,1]  R2328     0.735697329044342
    z[6,5,1]  R2329     5.1107460260391235e-01
    z[6,5,1]  R2330     3.1154605746269226e-01
    z[6,5,1]  R2331     4.4397643208503723e-01
    z[6,5,1]  R2332     -2.0141474902629852e-01
    z[6,5,1]  R2333     -1.1928041279315948e-01
    z[6,5,1]  R2334     1.0443801991641521e-02
    z[6,5,1]  R2335     -1.9972890615463257e-01
    z[6,5,1]  R2336     -2.3908819258213043e-01
    z[6,5,1]  R2337     -0.086459219455719
    z[6,5,2]  R49       1
    z[6,5,2]  R58       -1
    z[6,5,2]  R2290     -1
    z[6,5,2]  R2291     1
    z[6,5,2]  R2300     -4.8853706568479538e-02
    z[6,5,2]  R2301     -8.8969990611076355e-02
    z[6,5,2]  R2302     1.0154622793197632e-01
    z[6,5,2]  R2303     -3.5632529854774475e-01
    z[6,5,2]  R2304     -1.1590354889631271e-01
    z[6,5,2]  R2305     -9.4508372247219086e-02
    z[6,5,2]  R2306     1.4536599814891815e-01
    z[6,5,2]  R2307     7.5959369540214539e-02
    z[6,5,2]  R2308     1.7877836525440216e-01
    z[6,5,2]  R2309     1.0002315044403076e-02
    z[6,5,2]  R2310     -1.0571443289518356e-01
    z[6,5,2]  R2311     -3.8934905081987381e-02
    z[6,5,2]  R2312     1.0225692391395569e-01
    z[6,5,2]  R2313     -6.9800354540348053e-02
    z[6,5,2]  R2314     3.7978102918714285e-03
    z[6,5,2]  R2315     -5.7435303926467896e-02
    z[6,5,2]  R2316     0.192092627286911
    z[6,5,2]  R2317     3.1447991728782654e-01
    z[6,5,2]  R2318     -2.2579286247491837e-02
    z[6,5,2]  R2319     1.8240837752819061e-01
    z[6,5,2]  R2320     -3.7991592288017273e-01
    z[6,5,2]  R2321     -2.9864221811294556e-01
    z[6,5,2]  R2322     2.2859716415405273e-01
    z[6,5,2]  R2323     5.4286282509565353e-02
    z[6,5,2]  R2324     3.1203457713127136e-01
    z[6,5,2]  R2325     3.1310686469078064e-01
    z[6,5,2]  R2326     -2.7816560864448547e-01
    z[6,5,2]  R2327     2.3640289902687073e-01
    z[6,5,2]  R2328     -2.6094261556863785e-02
    z[6,5,2]  R2329     1.8322923779487610e-01
    z[6,5,2]  R2330     5.8794164657592773e-01
    z[6,5,2]  R2331     4.9670797586441040e-01
    z[6,5,2]  R2332     -4.6606090664863586e-01
    z[6,5,2]  R2333     -4.8526491969823837e-02
    z[6,5,2]  R2334     -1.6023044288158417e-01
    z[6,5,2]  R2335     -1.6508170962333679e-01
    z[6,5,2]  R2336     3.1460151076316833e-02
    z[6,5,2]  R2337     -3.8388580083847046e-02
    z[6,5,3]  R50       1
    z[6,5,3]  R59       -1
    z[6,5,3]  R2292     -1
    z[6,5,3]  R2293     1
    z[6,5,3]  R2300     4.5885568857192993e-01
    z[6,5,3]  R2301     3.6241078376770020e-01
    z[6,5,3]  R2302     -6.7626345157623291e-01
    z[6,5,3]  R2303     -2.9832044243812561e-01
    z[6,5,3]  R2304     -4.9292492866516113e-01
    z[6,5,3]  R2305     -6.4670413732528687e-01
    z[6,5,3]  R2306     -0.414843887090683
    z[6,5,3]  R2307     2.7501624822616577e-01
    z[6,5,3]  R2308     -3.6654850840568542e-01
    z[6,5,3]  R2309     -3.4762999415397644e-01
    z[6,5,3]  R2310     -9.0359747409820557e-02
    z[6,5,3]  R2311     0.455278217792511
    z[6,5,3]  R2312     5.8274453878402710e-01
    z[6,5,3]  R2313     5.9091097116470337e-01
    z[6,5,3]  R2314     7.6769270002841949e-02
    z[6,5,3]  R2315     5.2717792987823486e-01
    z[6,5,3]  R2316     -5.3998565673828125e-01
    z[6,5,3]  R2317     5.8625394105911255e-01
    z[6,5,3]  R2318     -1.8576428294181824e-01
    z[6,5,3]  R2319     7.0320683717727661e-01
    z[6,5,3]  R2320     1.4298340678215027e-01
    z[6,5,3]  R2321     3.0610656738281250e-01
    z[6,5,3]  R2322     -4.5985820889472961e-01
    z[6,5,3]  R2323     -5.7009279727935791e-01
    z[6,5,3]  R2324     -2.6410719752311707e-01
    z[6,5,3]  R2325     4.0180769562721252e-01
    z[6,5,3]  R2326     5.2533990144729614e-01
    z[6,5,3]  R2327     -2.3259180784225464e-01
    z[6,5,3]  R2328     3.7807571887969971e-01
    z[6,5,3]  R2329     -6.2137925624847412e-01
    z[6,5,3]  R2330     -5.2404171228408813e-01
    z[6,5,3]  R2331     -2.4119694530963898e-01
    z[6,5,3]  R2332     -6.6314691305160522e-01
    z[6,5,3]  R2333     -3.0422553420066833e-01
    z[6,5,3]  R2334     -4.0116128325462341e-01
    z[6,5,3]  R2335     -3.2623365521430969e-01
    z[6,5,3]  R2336     -2.2785899043083191e-01
    z[6,5,3]  R2337     -1.5573722124099731e-01
    z[6,5,4]  R51       1
    z[6,5,4]  R60       -1
    z[6,5,4]  R2294     -1
    z[6,5,4]  R2295     1
    z[6,5,4]  R2300     0.357509046792984
    z[6,5,4]  R2301     -6.0309016704559326e-01
    z[6,5,4]  R2302     -0.543997585773468
    z[6,5,4]  R2303     -1.0941015928983688e-01
    z[6,5,4]  R2304     3.4542571753263474e-02
    z[6,5,4]  R2305     1.6265991330146790e-01
    z[6,5,4]  R2306     -6.8174833059310913e-01
    z[6,5,4]  R2307     -1.1812223494052887e-01
    z[6,5,4]  R2308     -7.7611476182937622e-01
    z[6,5,4]  R2309     2.8842344880104065e-01
    z[6,5,4]  R2310     2.9466179013252258e-01
    z[6,5,4]  R2311     -5.8741912245750427e-02
    z[6,5,4]  R2312     -4.2761716246604919e-01
    z[6,5,4]  R2313     -2.2641818225383759e-01
    z[6,5,4]  R2314     -4.2552046477794647e-02
    z[6,5,4]  R2315     1.1397330462932587e-01
    z[6,5,4]  R2316     1.2061966955661774e-01
    z[6,5,4]  R2317     -3.0990007519721985e-01
    z[6,5,4]  R2318     -4.6752437949180603e-01
    z[6,5,4]  R2319     -2.5311350822448730e-01
    z[6,5,4]  R2320     -2.6978400349617004e-01
    z[6,5,4]  R2321     -1.9433347880840302e-01
    z[6,5,4]  R2322     -6.5487218089401722e-03
    z[6,5,4]  R2323     -2.4164788424968719e-01
    z[6,5,4]  R2324     -5.3179544210433960e-01
    z[6,5,4]  R2325     -0.715399980545044
    z[6,5,4]  R2326     2.4729570746421814e-01
    z[6,5,4]  R2327     -2.6987606287002563e-01
    z[6,5,4]  R2328     2.1347737312316895e-01
    z[6,5,4]  R2329     6.6397614777088165e-02
    z[6,5,4]  R2330     -0.0682741329073906
    z[6,5,4]  R2331     1.9729943946003914e-02
    z[6,5,4]  R2332     1.2859743833541870e-01
    z[6,5,4]  R2333     3.1697552651166916e-02
    z[6,5,4]  R2334     -4.4534732587635517e-03
    z[6,5,4]  R2335     1.1686767637729645e-01
    z[6,5,4]  R2336     -2.5458750128746033e-01
    z[6,5,4]  R2337     -3.8164101541042328e-02
    z[6,5,5]  R52       1
    z[6,5,5]  R61       -1
    z[6,5,5]  R2296     -1
    z[6,5,5]  R2297     1
    z[6,5,5]  R2300     -2.6345381140708923e-01
    z[6,5,5]  R2301     -2.3830138146877289e-01
    z[6,5,5]  R2302     -2.6126924157142639e-01
    z[6,5,5]  R2303     6.8551085889339447e-02
    z[6,5,5]  R2304     -2.7362501621246338e-01
    z[6,5,5]  R2305     -3.1204009056091309e-01
    z[6,5,5]  R2306     1.8901422619819641e-01
    z[6,5,5]  R2307     -2.0798480510711670e-01
    z[6,5,5]  R2308     -4.4986773282289505e-02
    z[6,5,5]  R2309     -1.4680914580821991e-01
    z[6,5,5]  R2310     8.4582549333572388e-01
    z[6,5,5]  R2311     -2.3791438341140747e-01
    z[6,5,5]  R2312     -7.7955365180969238e-02
    z[6,5,5]  R2313     1.5660324692726135e-01
    z[6,5,5]  R2314     2.5693657994270325e-01
    z[6,5,5]  R2315     3.5654449462890625e-01
    z[6,5,5]  R2316     6.1161947250366211e-01
    z[6,5,5]  R2317     1.6179552674293518e-01
    z[6,5,5]  R2318     3.1513112783432007e-01
    z[6,5,5]  R2319     3.5332062840461731e-01
    z[6,5,5]  R2320     -8.4242987632751465e-01
    z[6,5,5]  R2321     -4.9546590447425842e-01
    z[6,5,5]  R2322     -1.6400189697742462e-01
    z[6,5,5]  R2323     -5.3578341007232666e-01
    z[6,5,5]  R2324     -1.5329921245574951e-01
    z[6,5,5]  R2325     2.3713913559913635e-01
    z[6,5,5]  R2326     1.9079077243804932e-01
    z[6,5,5]  R2327     3.3418321609497070e-01
    z[6,5,5]  R2328     1.5212121605873108e-01
    z[6,5,5]  R2329     3.3937299251556396e-01
    z[6,5,5]  R2330     4.7862115502357483e-01
    z[6,5,5]  R2331     3.7534487247467041e-01
    z[6,5,5]  R2332     4.4864749908447266e-01
    z[6,5,5]  R2333     2.3144076764583588e-01
    z[6,5,5]  R2334     -4.6014860272407532e-02
    z[6,5,5]  R2335     6.8947292864322662e-02
    z[6,5,5]  R2336     3.8678757846355438e-02
    z[6,5,5]  R2337     2.7021130919456482e-01
    z[6,5,6]  R53       1
    z[6,5,6]  R62       -1
    z[6,5,6]  R2298     -1
    z[6,5,6]  R2299     1
    z[6,5,6]  R2300     -4.9204191565513611e-01
    z[6,5,6]  R2301     -3.5190141201019287e-01
    z[6,5,6]  R2302     2.6098656654357910e-01
    z[6,5,6]  R2303     -5.8317434042692184e-02
    z[6,5,6]  R2304     6.7316746711730957e-01
    z[6,5,6]  R2305     2.5680345296859741e-01
    z[6,5,6]  R2306     3.8292786478996277e-01
    z[6,5,6]  R2307     7.2154581546783447e-01
    z[6,5,6]  R2308     -2.7061384916305542e-01
    z[6,5,6]  R2309     -9.1947264969348907e-02
    z[6,5,6]  R2310     -2.3163300752639771e-01
    z[6,5,6]  R2311     1.1673419922590256e-01
    z[6,5,6]  R2312     -0.0792611688375473
    z[6,5,6]  R2313     -4.4976255297660828e-01
    z[6,5,6]  R2314     4.3725162744522095e-01
    z[6,5,6]  R2315     -1.9910500943660736e-01
    z[6,5,6]  R2316     2.6285931468009949e-01
    z[6,5,6]  R2317     -4.4094722718000412e-02
    z[6,5,6]  R2318     1.9140637014061213e-03
    z[6,5,6]  R2319     4.2821615934371948e-02
    z[6,5,6]  R2320     8.8194563984870911e-02
    z[6,5,6]  R2321     -7.1552854776382446e-01
    z[6,5,6]  R2322     -2.3107738792896271e-01
    z[6,5,6]  R2323     -4.6637782454490662e-01
    z[6,5,6]  R2324     6.1569482088088989e-01
    z[6,5,6]  R2325     1.5540994703769684e-01
    z[6,5,6]  R2326     2.3442228138446808e-01
    z[6,5,6]  R2327     -9.4112023711204529e-02
    z[6,5,6]  R2328     3.0019092559814453e-01
    z[6,5,6]  R2329     -0.0115215377882123
    z[6,5,6]  R2330     -1.6581559181213379e-01
    z[6,5,6]  R2331     -4.2370134592056274e-01
    z[6,5,6]  R2332     1.5776583552360535e-01
    z[6,5,6]  R2333     -1.3237112760543823e-01
    z[6,5,6]  R2334     1.8176500499248505e-01
    z[6,5,6]  R2335     1.4365004003047943e-01
    z[6,5,6]  R2336     7.5863234698772430e-02
    z[6,5,6]  R2337     3.0158379673957825e-01
    z[6,7,0]  R56       -1
    z[6,7,0]  R65       1
    z[6,7,0]  R2338     -1
    z[6,7,0]  R2339     1
    z[6,7,0]  R2352     3.5023579001426697e-01
    z[6,7,0]  R2353     -3.5215988755226135e-01
    z[6,7,0]  R2354     5.8928407728672028e-02
    z[6,7,0]  R2355     -0.773298442363739
    z[6,7,0]  R2356     -3.8151663541793823e-01
    z[6,7,0]  R2357     5.7362508773803711e-01
    z[6,7,0]  R2358     -2.8556972742080688e-01
    z[6,7,0]  R2359     -0.5153848528862
    z[6,7,0]  R2360     2.2055222094058990e-01
    z[6,7,0]  R2361     3.5775637626647949e-01
    z[6,7,0]  R2362     1.1200285702943802e-01
    z[6,7,0]  R2363     -2.4220466613769531e-01
    z[6,7,0]  R2364     5.1329302787780762e-01
    z[6,7,0]  R2365     -1.0053907753899693e-03
    z[6,7,0]  R2366     -3.1063526868820190e-01
    z[6,7,0]  R2367     4.3158743530511856e-02
    z[6,7,0]  R2368     4.0677827596664429e-01
    z[6,7,0]  R2369     4.8377943038940430e-01
    z[6,7,0]  R2370     -2.2401331365108490e-01
    z[6,7,0]  R2371     1.4266875386238098e-01
    z[6,7,0]  R2372     -4.1262686252593994e-01
    z[6,7,0]  R2373     -4.4748997688293457e-01
    z[6,7,0]  R2374     -2.7702760696411133e-01
    z[6,7,0]  R2375     -5.8499222993850708e-01
    z[6,7,0]  R2376     0.296770840883255
    z[6,7,0]  R2377     1.1918853968381882e-01
    z[6,7,0]  R2378     -6.9707196950912476e-01
    z[6,7,0]  R2379     -0.392225980758667
    z[6,7,0]  R2380     -4.1511037945747375e-01
    z[6,7,0]  R2381     -7.8401017189025879e-01
    z[6,7,0]  R2382     0.421558678150177
    z[6,7,0]  R2383     6.6409957408905029e-01
    z[6,7,0]  R2384     8.1438052654266357e-01
    z[6,7,0]  R2385     6.5065771341323853e-01
    z[6,7,0]  R2386     -9.8521754145622253e-02
    z[6,7,0]  R2387     1.2888480722904205e-01
    z[6,7,0]  R2388     -5.4445322602987289e-02
    z[6,7,0]  R2389     -3.6244772374629974e-02
    z[6,7,0]  R2390     4.2444523423910141e-02
    z[6,7,0]  R2391     3.8722500205039978e-01
    z[6,7,0]  R2392     5.6427884846925735e-02
    z[6,7,0]  R2393     2.6662710309028625e-01
    z[6,7,0]  R2394     -1.4506371319293976e-01
    z[6,7,0]  R2395     2.8955054283142090e-01
    z[6,7,0]  R2396     1.9331602752208710e-01
    z[6,7,0]  R2397     4.3688774108886719e-01
    z[6,7,0]  R2398     5.1895231008529663e-01
    z[6,7,0]  R2399     1.0645905137062073e-01
    z[6,7,0]  R2400     0.0852186381816864
    z[6,7,0]  R2401     2.9223784804344177e-01
    z[6,7,1]  R57       -1
    z[6,7,1]  R66       1
    z[6,7,1]  R2340     -1
    z[6,7,1]  R2341     1
    z[6,7,1]  R2352     4.7441938519477844e-01
    z[6,7,1]  R2353     4.3861860036849976e-01
    z[6,7,1]  R2354     3.1076440215110779e-01
    z[6,7,1]  R2355     4.0740135312080383e-01
    z[6,7,1]  R2356     2.6233211159706116e-01
    z[6,7,1]  R2357     2.3242391645908356e-01
    z[6,7,1]  R2358     2.7943196892738342e-01
    z[6,7,1]  R2359     2.7410915493965149e-01
    z[6,7,1]  R2360     3.2776123285293579e-01
    z[6,7,1]  R2361     -7.9866671562194824e-01
    z[6,7,1]  R2362     3.3498460054397583e-01
    z[6,7,1]  R2363     -0.811703085899353
    z[6,7,1]  R2364     -4.3734058737754822e-01
    z[6,7,1]  R2365     -6.0652697086334229e-01
    z[6,7,1]  R2366     -7.9911309480667114e-01
    z[6,7,1]  R2367     -7.3291552066802979e-01
    z[6,7,1]  R2368     -2.1982905268669128e-01
    z[6,7,1]  R2369     -0.44632488489151
    z[6,7,1]  R2370     -7.7259916067123413e-01
    z[6,7,1]  R2371     -5.1101601123809814e-01
    z[6,7,1]  R2372     2.6827645301818848e-01
    z[6,7,1]  R2373     2.2240860760211945e-01
    z[6,7,1]  R2374     1.9253897666931152e-01
    z[6,7,1]  R2375     1.9086334109306335e-01
    z[6,7,1]  R2376     1.9250404834747314e-01
    z[6,7,1]  R2377     1.8883405625820160e-01
    z[6,7,1]  R2378     1.2418291717767715e-01
    z[6,7,1]  R2379     1.6557477414608002e-01
    z[6,7,1]  R2380     1.1393685638904572e-01
    z[6,7,1]  R2381     1.8629537522792816e-01
    z[6,7,1]  R2382     0.584402859210968
    z[6,7,1]  R2383     4.0262556076049805e-01
    z[6,7,1]  R2384     4.1548383235931396e-01
    z[6,7,1]  R2385     3.6769053339958191e-01
    z[6,7,1]  R2386     -9.5285606384277344e-01
    z[6,7,1]  R2387     -8.7817096710205078e-01
    z[6,7,1]  R2388     -9.2872285842895508e-01
    z[6,7,1]  R2389     -8.9981520175933838e-01
    z[6,7,1]  R2390     -8.2558405399322510e-01
    z[6,7,1]  R2391     -7.1877020597457886e-01
    z[6,7,1]  R2392     8.5633313655853271e-01
    z[6,7,1]  R2393     8.2666528224945068e-01
    z[6,7,1]  R2394     0.729005753993988
    z[6,7,1]  R2395     5.1801115274429321e-01
    z[6,7,1]  R2396     -9.2085808515548706e-01
    z[6,7,1]  R2397     -8.6790871620178223e-01
    z[6,7,1]  R2398     -8.1607604026794434e-01
    z[6,7,1]  R2399     -8.9879059791564941e-01
    z[6,7,1]  R2400     -9.2608416080474854e-01
    z[6,7,1]  R2401     -7.4814999103546143e-01
    z[6,7,2]  R58       -1
    z[6,7,2]  R67       1
    z[6,7,2]  R2342     -1
    z[6,7,2]  R2343     1
    z[6,7,2]  R2352     -4.8853706568479538e-02
    z[6,7,2]  R2353     -8.8969990611076355e-02
    z[6,7,2]  R2354     1.0154622793197632e-01
    z[6,7,2]  R2355     -3.5632529854774475e-01
    z[6,7,2]  R2356     -1.1590354889631271e-01
    z[6,7,2]  R2357     -9.4508372247219086e-02
    z[6,7,2]  R2358     1.4536599814891815e-01
    z[6,7,2]  R2359     7.5959369540214539e-02
    z[6,7,2]  R2360     1.7877836525440216e-01
    z[6,7,2]  R2361     1.0002315044403076e-02
    z[6,7,2]  R2362     -1.0571443289518356e-01
    z[6,7,2]  R2363     -3.8934905081987381e-02
    z[6,7,2]  R2364     1.0225692391395569e-01
    z[6,7,2]  R2365     -6.9800354540348053e-02
    z[6,7,2]  R2366     3.7978102918714285e-03
    z[6,7,2]  R2367     -5.7435303926467896e-02
    z[6,7,2]  R2368     0.192092627286911
    z[6,7,2]  R2369     3.1447991728782654e-01
    z[6,7,2]  R2370     -2.2579286247491837e-02
    z[6,7,2]  R2371     1.8240837752819061e-01
    z[6,7,2]  R2372     3.9148885011672974e-01
    z[6,7,2]  R2373     2.5419646501541138e-01
    z[6,7,2]  R2374     2.5696179270744324e-01
    z[6,7,2]  R2375     2.0326870679855347e-01
    z[6,7,2]  R2376     2.8714475035667419e-01
    z[6,7,2]  R2377     7.0061689615249634e-01
    z[6,7,2]  R2378     5.8284962177276611e-01
    z[6,7,2]  R2379     6.5757888555526733e-01
    z[6,7,2]  R2380     7.7169144153594971e-01
    z[6,7,2]  R2381     2.8874278068542480e-01
    z[6,7,2]  R2382     -2.5980761647224426e-01
    z[6,7,2]  R2383     -3.2109084725379944e-01
    z[6,7,2]  R2384     -1.5883018076419830e-01
    z[6,7,2]  R2385     -5.0474941730499268e-01
    z[6,7,2]  R2386     0.051239013671875
    z[6,7,2]  R2387     -6.3232593238353729e-03
    z[6,7,2]  R2388     2.3463173210620880e-01
    z[6,7,2]  R2389     -0.0435776486992836
    z[6,7,2]  R2390     -2.7200752496719360e-01
    z[6,7,2]  R2391     -3.2253436744213104e-02
    z[6,7,2]  R2392     5.7582195848226547e-02
    z[6,7,2]  R2393     3.6205121874809265e-01
    z[6,7,2]  R2394     3.9077621698379517e-01
    z[6,7,2]  R2395     -4.3866109848022461e-01
    z[6,7,2]  R2396     -1.2892891466617584e-01
    z[6,7,2]  R2397     -2.5552364066243172e-02
    z[6,7,2]  R2398     -1.3978378474712372e-01
    z[6,7,2]  R2399     -0.405248761177063
    z[6,7,2]  R2400     1.7147357761859894e-01
    z[6,7,2]  R2401     4.5713827013969421e-01
    z[6,7,3]  R59       -1
    z[6,7,3]  R68       1
    z[6,7,3]  R2344     -1
    z[6,7,3]  R2345     1
    z[6,7,3]  R2352     4.5885568857192993e-01
    z[6,7,3]  R2353     3.6241078376770020e-01
    z[6,7,3]  R2354     -6.7626345157623291e-01
    z[6,7,3]  R2355     -2.9832044243812561e-01
    z[6,7,3]  R2356     -4.9292492866516113e-01
    z[6,7,3]  R2357     -6.4670413732528687e-01
    z[6,7,3]  R2358     -0.414843887090683
    z[6,7,3]  R2359     2.7501624822616577e-01
    z[6,7,3]  R2360     -3.6654850840568542e-01
    z[6,7,3]  R2361     -3.4762999415397644e-01
    z[6,7,3]  R2362     -9.0359747409820557e-02
    z[6,7,3]  R2363     0.455278217792511
    z[6,7,3]  R2364     5.8274453878402710e-01
    z[6,7,3]  R2365     5.9091097116470337e-01
    z[6,7,3]  R2366     7.6769270002841949e-02
    z[6,7,3]  R2367     5.2717792987823486e-01
    z[6,7,3]  R2368     -5.3998565673828125e-01
    z[6,7,3]  R2369     5.8625394105911255e-01
    z[6,7,3]  R2370     -1.8576428294181824e-01
    z[6,7,3]  R2371     7.0320683717727661e-01
    z[6,7,3]  R2372     -4.0317773818969727e-01
    z[6,7,3]  R2373     -7.7090424019843340e-04
    z[6,7,3]  R2374     -2.3817038536071777e-01
    z[6,7,3]  R2375     -3.1208419799804688e-01
    z[6,7,3]  R2376     0.0873216912150383
    z[6,7,3]  R2377     5.0227856636047363e-01
    z[6,7,3]  R2378     -3.8150079548358917e-02
    z[6,7,3]  R2379     2.5135505199432373e-01
    z[6,7,3]  R2380     2.6715794205665588e-01
    z[6,7,3]  R2381     -3.7401530146598816e-01
    z[6,7,3]  R2382     1.3493514060974121e-01
    z[6,7,3]  R2383     -3.6330097913742065e-01
    z[6,7,3]  R2384     -2.3994803428649902e-01
    z[6,7,3]  R2385     6.6571375355124474e-03
    z[6,7,3]  R2386     -2.3104372620582581e-01
    z[6,7,3]  R2387     -3.0128198862075806e-01
    z[6,7,3]  R2388     9.7351469099521637e-02
    z[6,7,3]  R2389     -2.3369999229907990e-01
    z[6,7,3]  R2390     1.1244335025548935e-01
    z[6,7,3]  R2391     4.2713305354118347e-01
    z[6,7,3]  R2392     -9.7382143139839172e-02
    z[6,7,3]  R2393     1.3974194228649139e-01
    z[6,7,3]  R2394     6.3815057277679443e-02
    z[6,7,3]  R2395     -5.1278185844421387e-01
    z[6,7,3]  R2396     2.9160696268081665e-01
    z[6,7,3]  R2397     -1.0779995471239090e-01
    z[6,7,3]  R2398     1.3958472013473511e-01
    z[6,7,3]  R2399     -1.3942248187959194e-03
    z[6,7,3]  R2400     -7.4596926569938660e-02
    z[6,7,3]  R2401     3.2925301790237427e-01
    z[6,7,4]  R60       -1
    z[6,7,4]  R69       1
    z[6,7,4]  R2346     -1
    z[6,7,4]  R2347     1
    z[6,7,4]  R2352     0.357509046792984
    z[6,7,4]  R2353     -6.0309016704559326e-01
    z[6,7,4]  R2354     -0.543997585773468
    z[6,7,4]  R2355     -1.0941015928983688e-01
    z[6,7,4]  R2356     3.4542571753263474e-02
    z[6,7,4]  R2357     1.6265991330146790e-01
    z[6,7,4]  R2358     -6.8174833059310913e-01
    z[6,7,4]  R2359     -1.1812223494052887e-01
    z[6,7,4]  R2360     -7.7611476182937622e-01
    z[6,7,4]  R2361     2.8842344880104065e-01
    z[6,7,4]  R2362     2.9466179013252258e-01
    z[6,7,4]  R2363     -5.8741912245750427e-02
    z[6,7,4]  R2364     -4.2761716246604919e-01
    z[6,7,4]  R2365     -2.2641818225383759e-01
    z[6,7,4]  R2366     -4.2552046477794647e-02
    z[6,7,4]  R2367     1.1397330462932587e-01
    z[6,7,4]  R2368     1.2061966955661774e-01
    z[6,7,4]  R2369     -3.0990007519721985e-01
    z[6,7,4]  R2370     -4.6752437949180603e-01
    z[6,7,4]  R2371     -2.5311350822448730e-01
    z[6,7,4]  R2372     0.60483717918396
    z[6,7,4]  R2373     -6.4296253025531769e-02
    z[6,7,4]  R2374     1.0830979794263840e-01
    z[6,7,4]  R2375     1.2754504382610321e-01
    z[6,7,4]  R2376     5.1302719116210938e-01
    z[6,7,4]  R2377     2.7713507413864136e-01
    z[6,7,4]  R2378     2.7354445308446884e-02
    z[6,7,4]  R2379     2.0819666981697083e-01
    z[6,7,4]  R2380     1.1473132669925690e-01
    z[6,7,4]  R2381     -3.4995445609092712e-01
    z[6,7,4]  R2382     -5.6651449203491211e-01
    z[6,7,4]  R2383     2.1771334111690521e-01
    z[6,7,4]  R2384     -5.0821971148252487e-02
    z[6,7,4]  R2385     1.8033283948898315e-01
    z[6,7,4]  R2386     -6.3421934843063354e-02
    z[6,7,4]  R2387     1.9550846517086029e-01
    z[6,7,4]  R2388     -1.7913454771041870e-01
    z[6,7,4]  R2389     -1.1474343389272690e-01
    z[6,7,4]  R2390     -4.7085419297218323e-01
    z[6,7,4]  R2391     -2.8207856416702271e-01
    z[6,7,4]  R2392     -5.1008272916078568e-02
    z[6,7,4]  R2393     2.4283653497695923e-01
    z[6,7,4]  R2394     -4.7067850828170776e-01
    z[6,7,4]  R2395     2.1497736871242523e-01
    z[6,7,4]  R2396     -6.2021367251873016e-02
    z[6,7,4]  R2397     -1.5125301480293274e-01
    z[6,7,4]  R2398     1.5340529382228851e-01
    z[6,7,4]  R2399     9.9574409425258636e-02
    z[6,7,4]  R2400     -2.3859688639640808e-01
    z[6,7,4]  R2401     1.2870885431766510e-01
    z[6,7,5]  R61       -1
    z[6,7,5]  R70       1
    z[6,7,5]  R2348     -1
    z[6,7,5]  R2349     1
    z[6,7,5]  R2352     -2.6345381140708923e-01
    z[6,7,5]  R2353     -2.3830138146877289e-01
    z[6,7,5]  R2354     -2.6126924157142639e-01
    z[6,7,5]  R2355     6.8551085889339447e-02
    z[6,7,5]  R2356     -2.7362501621246338e-01
    z[6,7,5]  R2357     -3.1204009056091309e-01
    z[6,7,5]  R2358     1.8901422619819641e-01
    z[6,7,5]  R2359     -2.0798480510711670e-01
    z[6,7,5]  R2360     -4.4986773282289505e-02
    z[6,7,5]  R2361     -1.4680914580821991e-01
    z[6,7,5]  R2362     8.4582549333572388e-01
    z[6,7,5]  R2363     -2.3791438341140747e-01
    z[6,7,5]  R2364     -7.7955365180969238e-02
    z[6,7,5]  R2365     1.5660324692726135e-01
    z[6,7,5]  R2366     2.5693657994270325e-01
    z[6,7,5]  R2367     3.5654449462890625e-01
    z[6,7,5]  R2368     6.1161947250366211e-01
    z[6,7,5]  R2369     1.6179552674293518e-01
    z[6,7,5]  R2370     3.1513112783432007e-01
    z[6,7,5]  R2371     3.5332062840461731e-01
    z[6,7,5]  R2372     2.1369495987892151e-01
    z[6,7,5]  R2373     1.5344811603426933e-02
    z[6,7,5]  R2374     -6.4999371767044067e-01
    z[6,7,5]  R2375     -5.6228202581405640e-01
    z[6,7,5]  R2376     -2.0857641100883484e-01
    z[6,7,5]  R2377     -1.8942032754421234e-01
    z[6,7,5]  R2378     -4.2550815269351006e-03
    z[6,7,5]  R2379     5.3575128316879272e-02
    z[6,7,5]  R2380     -3.6595806479454041e-01
    z[6,7,5]  R2381     6.7329391837120056e-02
    z[6,7,5]  R2382     -2.6174557209014893e-01
    z[6,7,5]  R2383     1.4011247456073761e-01
    z[6,7,5]  R2384     -1.1286448687314987e-01
    z[6,7,5]  R2385     1.3865859806537628e-01
    z[6,7,5]  R2386     1.2577064335346222e-01
    z[6,7,5]  R2387     9.6456006169319153e-02
    z[6,7,5]  R2388     1.4606384932994843e-01
    z[6,7,5]  R2389     6.4928233623504639e-02
    z[6,7,5]  R2390     -8.9737243950366974e-02
    z[6,7,5]  R2391     2.1938440203666687e-01
    z[6,7,5]  R2392     2.6106894016265869e-01
    z[6,7,5]  R2393     -1.2218544632196426e-01
    z[6,7,5]  R2394     -6.5748314373195171e-03
    z[6,7,5]  R2395     2.5487670302391052e-01
    z[6,7,5]  R2396     -8.0740720033645630e-02
    z[6,7,5]  R2397     1.3575650751590729e-01
    z[6,7,5]  R2398     -3.7502128630876541e-02
    z[6,7,5]  R2399     -6.5509853884577751e-03
    z[6,7,5]  R2400     -1.7547595500946045e-01
    z[6,7,5]  R2401     0.0950714573264122
    z[6,7,6]  R62       -1
    z[6,7,6]  R71       1
    z[6,7,6]  R2350     -1
    z[6,7,6]  R2351     1
    z[6,7,6]  R2352     -4.9204191565513611e-01
    z[6,7,6]  R2353     -3.5190141201019287e-01
    z[6,7,6]  R2354     2.6098656654357910e-01
    z[6,7,6]  R2355     -5.8317434042692184e-02
    z[6,7,6]  R2356     6.7316746711730957e-01
    z[6,7,6]  R2357     2.5680345296859741e-01
    z[6,7,6]  R2358     3.8292786478996277e-01
    z[6,7,6]  R2359     7.2154581546783447e-01
    z[6,7,6]  R2360     -2.7061384916305542e-01
    z[6,7,6]  R2361     -9.1947264969348907e-02
    z[6,7,6]  R2362     -2.3163300752639771e-01
    z[6,7,6]  R2363     1.1673419922590256e-01
    z[6,7,6]  R2364     -0.0792611688375473
    z[6,7,6]  R2365     -4.4976255297660828e-01
    z[6,7,6]  R2366     4.3725162744522095e-01
    z[6,7,6]  R2367     -1.9910500943660736e-01
    z[6,7,6]  R2368     2.6285931468009949e-01
    z[6,7,6]  R2369     -4.4094722718000412e-02
    z[6,7,6]  R2370     1.9140637014061213e-03
    z[6,7,6]  R2371     4.2821615934371948e-02
    z[6,7,6]  R2372     -1.7452044785022736e-01
    z[6,7,6]  R2373     8.2540971040725708e-01
    z[6,7,6]  R2374     -5.7376581430435181e-01
    z[6,7,6]  R2375     3.8757154345512390e-01
    z[6,7,6]  R2376     -6.9144135713577271e-01
    z[6,7,6]  R2377     -3.0708971619606018e-01
    z[6,7,6]  R2378     3.9589628577232361e-01
    z[6,7,6]  R2379     5.2624928951263428e-01
    z[6,7,6]  R2380     -2.7057321742177010e-02
    z[6,7,6]  R2381     1.8995814025402069e-02
    z[6,7,6]  R2382     -7.4864067137241364e-02
    z[6,7,6]  R2383     0.307809978723526
    z[6,7,6]  R2384     2.5697097182273865e-01
    z[6,7,6]  R2385     3.6726808547973633e-01
    z[6,7,6]  R2386     8.0694079399108887e-02
    z[6,7,6]  R2387     2.7178376913070679e-01
    z[6,7,6]  R2388     -1.2867182493209839e-01
    z[6,7,6]  R2389     -3.3929708600044250e-01
    z[6,7,6]  R2390     -1.4879697002470493e-02
    z[6,7,6]  R2391     1.4914938807487488e-01
    z[6,7,6]  R2392     4.2420718073844910e-01
    z[6,7,6]  R2393     -1.4500647783279419e-01
    z[6,7,6]  R2394     -2.6295873522758484e-01
    z[6,7,6]  R2395     -2.8509417176246643e-01
    z[6,7,6]  R2396     -5.1247671246528625e-02
    z[6,7,6]  R2397     4.7775931656360626e-02
    z[6,7,6]  R2398     -2.7299644425511360e-02
    z[6,7,6]  R2399     -8.1580407917499542e-02
    z[6,7,6]  R2400     -1.1143527925014496e-01
    z[6,7,6]  R2401     1.0900022834539413e-01
    z[7,6,0]  R56       1
    z[7,6,0]  R65       -1
    z[7,6,0]  R2402     -1
    z[7,6,0]  R2403     1
    z[7,6,0]  R2416     -4.1262686252593994e-01
    z[7,6,0]  R2417     -4.4748997688293457e-01
    z[7,6,0]  R2418     -2.7702760696411133e-01
    z[7,6,0]  R2419     -5.8499222993850708e-01
    z[7,6,0]  R2420     0.296770840883255
    z[7,6,0]  R2421     1.1918853968381882e-01
    z[7,6,0]  R2422     -6.9707196950912476e-01
    z[7,6,0]  R2423     -0.392225980758667
    z[7,6,0]  R2424     -4.1511037945747375e-01
    z[7,6,0]  R2425     -7.8401017189025879e-01
    z[7,6,0]  R2426     0.421558678150177
    z[7,6,0]  R2427     6.6409957408905029e-01
    z[7,6,0]  R2428     8.1438052654266357e-01
    z[7,6,0]  R2429     6.5065771341323853e-01
    z[7,6,0]  R2430     -9.8521754145622253e-02
    z[7,6,0]  R2431     1.2888480722904205e-01
    z[7,6,0]  R2432     -5.4445322602987289e-02
    z[7,6,0]  R2433     -3.6244772374629974e-02
    z[7,6,0]  R2434     4.2444523423910141e-02
    z[7,6,0]  R2435     3.8722500205039978e-01
    z[7,6,0]  R2436     5.6427884846925735e-02
    z[7,6,0]  R2437     2.6662710309028625e-01
    z[7,6,0]  R2438     -1.4506371319293976e-01
    z[7,6,0]  R2439     2.8955054283142090e-01
    z[7,6,0]  R2440     1.9331602752208710e-01
    z[7,6,0]  R2441     4.3688774108886719e-01
    z[7,6,0]  R2442     5.1895231008529663e-01
    z[7,6,0]  R2443     1.0645905137062073e-01
    z[7,6,0]  R2444     0.0852186381816864
    z[7,6,0]  R2445     2.9223784804344177e-01
    z[7,6,0]  R2446     3.5023579001426697e-01
    z[7,6,0]  R2447     -3.5215988755226135e-01
    z[7,6,0]  R2448     5.8928407728672028e-02
    z[7,6,0]  R2449     -0.773298442363739
    z[7,6,0]  R2450     -3.8151663541793823e-01
    z[7,6,0]  R2451     5.7362508773803711e-01
    z[7,6,0]  R2452     -2.8556972742080688e-01
    z[7,6,0]  R2453     -0.5153848528862
    z[7,6,0]  R2454     2.2055222094058990e-01
    z[7,6,0]  R2455     3.5775637626647949e-01
    z[7,6,0]  R2456     1.1200285702943802e-01
    z[7,6,0]  R2457     -2.4220466613769531e-01
    z[7,6,0]  R2458     5.1329302787780762e-01
    z[7,6,0]  R2459     -1.0053907753899693e-03
    z[7,6,0]  R2460     -3.1063526868820190e-01
    z[7,6,0]  R2461     4.3158743530511856e-02
    z[7,6,0]  R2462     4.0677827596664429e-01
    z[7,6,0]  R2463     4.8377943038940430e-01
    z[7,6,0]  R2464     -2.2401331365108490e-01
    z[7,6,0]  R2465     1.4266875386238098e-01
    z[7,6,1]  R57       1
    z[7,6,1]  R66       -1
    z[7,6,1]  R2404     -1
    z[7,6,1]  R2405     1
    z[7,6,1]  R2416     2.6827645301818848e-01
    z[7,6,1]  R2417     2.2240860760211945e-01
    z[7,6,1]  R2418     1.9253897666931152e-01
    z[7,6,1]  R2419     1.9086334109306335e-01
    z[7,6,1]  R2420     1.9250404834747314e-01
    z[7,6,1]  R2421     1.8883405625820160e-01
    z[7,6,1]  R2422     1.2418291717767715e-01
    z[7,6,1]  R2423     1.6557477414608002e-01
    z[7,6,1]  R2424     1.1393685638904572e-01
    z[7,6,1]  R2425     1.8629537522792816e-01
    z[7,6,1]  R2426     0.584402859210968
    z[7,6,1]  R2427     4.0262556076049805e-01
    z[7,6,1]  R2428     4.1548383235931396e-01
    z[7,6,1]  R2429     3.6769053339958191e-01
    z[7,6,1]  R2430     -9.5285606384277344e-01
    z[7,6,1]  R2431     -8.7817096710205078e-01
    z[7,6,1]  R2432     -9.2872285842895508e-01
    z[7,6,1]  R2433     -8.9981520175933838e-01
    z[7,6,1]  R2434     -8.2558405399322510e-01
    z[7,6,1]  R2435     -7.1877020597457886e-01
    z[7,6,1]  R2436     8.5633313655853271e-01
    z[7,6,1]  R2437     8.2666528224945068e-01
    z[7,6,1]  R2438     0.729005753993988
    z[7,6,1]  R2439     5.1801115274429321e-01
    z[7,6,1]  R2440     -9.2085808515548706e-01
    z[7,6,1]  R2441     -8.6790871620178223e-01
    z[7,6,1]  R2442     -8.1607604026794434e-01
    z[7,6,1]  R2443     -8.9879059791564941e-01
    z[7,6,1]  R2444     -9.2608416080474854e-01
    z[7,6,1]  R2445     -7.4814999103546143e-01
    z[7,6,1]  R2446     4.7441938519477844e-01
    z[7,6,1]  R2447     4.3861860036849976e-01
    z[7,6,1]  R2448     3.1076440215110779e-01
    z[7,6,1]  R2449     4.0740135312080383e-01
    z[7,6,1]  R2450     2.6233211159706116e-01
    z[7,6,1]  R2451     2.3242391645908356e-01
    z[7,6,1]  R2452     2.7943196892738342e-01
    z[7,6,1]  R2453     2.7410915493965149e-01
    z[7,6,1]  R2454     3.2776123285293579e-01
    z[7,6,1]  R2455     -7.9866671562194824e-01
    z[7,6,1]  R2456     3.3498460054397583e-01
    z[7,6,1]  R2457     -0.811703085899353
    z[7,6,1]  R2458     -4.3734058737754822e-01
    z[7,6,1]  R2459     -6.0652697086334229e-01
    z[7,6,1]  R2460     -7.9911309480667114e-01
    z[7,6,1]  R2461     -7.3291552066802979e-01
    z[7,6,1]  R2462     -2.1982905268669128e-01
    z[7,6,1]  R2463     -0.44632488489151
    z[7,6,1]  R2464     -7.7259916067123413e-01
    z[7,6,1]  R2465     -5.1101601123809814e-01
    z[7,6,2]  R58       1
    z[7,6,2]  R67       -1
    z[7,6,2]  R2406     -1
    z[7,6,2]  R2407     1
    z[7,6,2]  R2416     3.9148885011672974e-01
    z[7,6,2]  R2417     2.5419646501541138e-01
    z[7,6,2]  R2418     2.5696179270744324e-01
    z[7,6,2]  R2419     2.0326870679855347e-01
    z[7,6,2]  R2420     2.8714475035667419e-01
    z[7,6,2]  R2421     7.0061689615249634e-01
    z[7,6,2]  R2422     5.8284962177276611e-01
    z[7,6,2]  R2423     6.5757888555526733e-01
    z[7,6,2]  R2424     7.7169144153594971e-01
    z[7,6,2]  R2425     2.8874278068542480e-01
    z[7,6,2]  R2426     -2.5980761647224426e-01
    z[7,6,2]  R2427     -3.2109084725379944e-01
    z[7,6,2]  R2428     -1.5883018076419830e-01
    z[7,6,2]  R2429     -5.0474941730499268e-01
    z[7,6,2]  R2430     0.051239013671875
    z[7,6,2]  R2431     -6.3232593238353729e-03
    z[7,6,2]  R2432     2.3463173210620880e-01
    z[7,6,2]  R2433     -0.0435776486992836
    z[7,6,2]  R2434     -2.7200752496719360e-01
    z[7,6,2]  R2435     -3.2253436744213104e-02
    z[7,6,2]  R2436     5.7582195848226547e-02
    z[7,6,2]  R2437     3.6205121874809265e-01
    z[7,6,2]  R2438     3.9077621698379517e-01
    z[7,6,2]  R2439     -4.3866109848022461e-01
    z[7,6,2]  R2440     -1.2892891466617584e-01
    z[7,6,2]  R2441     -2.5552364066243172e-02
    z[7,6,2]  R2442     -1.3978378474712372e-01
    z[7,6,2]  R2443     -0.405248761177063
    z[7,6,2]  R2444     1.7147357761859894e-01
    z[7,6,2]  R2445     4.5713827013969421e-01
    z[7,6,2]  R2446     -4.8853706568479538e-02
    z[7,6,2]  R2447     -8.8969990611076355e-02
    z[7,6,2]  R2448     1.0154622793197632e-01
    z[7,6,2]  R2449     -3.5632529854774475e-01
    z[7,6,2]  R2450     -1.1590354889631271e-01
    z[7,6,2]  R2451     -9.4508372247219086e-02
    z[7,6,2]  R2452     1.4536599814891815e-01
    z[7,6,2]  R2453     7.5959369540214539e-02
    z[7,6,2]  R2454     1.7877836525440216e-01
    z[7,6,2]  R2455     1.0002315044403076e-02
    z[7,6,2]  R2456     -1.0571443289518356e-01
    z[7,6,2]  R2457     -3.8934905081987381e-02
    z[7,6,2]  R2458     1.0225692391395569e-01
    z[7,6,2]  R2459     -6.9800354540348053e-02
    z[7,6,2]  R2460     3.7978102918714285e-03
    z[7,6,2]  R2461     -5.7435303926467896e-02
    z[7,6,2]  R2462     0.192092627286911
    z[7,6,2]  R2463     3.1447991728782654e-01
    z[7,6,2]  R2464     -2.2579286247491837e-02
    z[7,6,2]  R2465     1.8240837752819061e-01
    z[7,6,3]  R59       1
    z[7,6,3]  R68       -1
    z[7,6,3]  R2408     -1
    z[7,6,3]  R2409     1
    z[7,6,3]  R2416     -4.0317773818969727e-01
    z[7,6,3]  R2417     -7.7090424019843340e-04
    z[7,6,3]  R2418     -2.3817038536071777e-01
    z[7,6,3]  R2419     -3.1208419799804688e-01
    z[7,6,3]  R2420     0.0873216912150383
    z[7,6,3]  R2421     5.0227856636047363e-01
    z[7,6,3]  R2422     -3.8150079548358917e-02
    z[7,6,3]  R2423     2.5135505199432373e-01
    z[7,6,3]  R2424     2.6715794205665588e-01
    z[7,6,3]  R2425     -3.7401530146598816e-01
    z[7,6,3]  R2426     1.3493514060974121e-01
    z[7,6,3]  R2427     -3.6330097913742065e-01
    z[7,6,3]  R2428     -2.3994803428649902e-01
    z[7,6,3]  R2429     6.6571375355124474e-03
    z[7,6,3]  R2430     -2.3104372620582581e-01
    z[7,6,3]  R2431     -3.0128198862075806e-01
    z[7,6,3]  R2432     9.7351469099521637e-02
    z[7,6,3]  R2433     -2.3369999229907990e-01
    z[7,6,3]  R2434     1.1244335025548935e-01
    z[7,6,3]  R2435     4.2713305354118347e-01
    z[7,6,3]  R2436     -9.7382143139839172e-02
    z[7,6,3]  R2437     1.3974194228649139e-01
    z[7,6,3]  R2438     6.3815057277679443e-02
    z[7,6,3]  R2439     -5.1278185844421387e-01
    z[7,6,3]  R2440     2.9160696268081665e-01
    z[7,6,3]  R2441     -1.0779995471239090e-01
    z[7,6,3]  R2442     1.3958472013473511e-01
    z[7,6,3]  R2443     -1.3942248187959194e-03
    z[7,6,3]  R2444     -7.4596926569938660e-02
    z[7,6,3]  R2445     3.2925301790237427e-01
    z[7,6,3]  R2446     4.5885568857192993e-01
    z[7,6,3]  R2447     3.6241078376770020e-01
    z[7,6,3]  R2448     -6.7626345157623291e-01
    z[7,6,3]  R2449     -2.9832044243812561e-01
    z[7,6,3]  R2450     -4.9292492866516113e-01
    z[7,6,3]  R2451     -6.4670413732528687e-01
    z[7,6,3]  R2452     -0.414843887090683
    z[7,6,3]  R2453     2.7501624822616577e-01
    z[7,6,3]  R2454     -3.6654850840568542e-01
    z[7,6,3]  R2455     -3.4762999415397644e-01
    z[7,6,3]  R2456     -9.0359747409820557e-02
    z[7,6,3]  R2457     0.455278217792511
    z[7,6,3]  R2458     5.8274453878402710e-01
    z[7,6,3]  R2459     5.9091097116470337e-01
    z[7,6,3]  R2460     7.6769270002841949e-02
    z[7,6,3]  R2461     5.2717792987823486e-01
    z[7,6,3]  R2462     -5.3998565673828125e-01
    z[7,6,3]  R2463     5.8625394105911255e-01
    z[7,6,3]  R2464     -1.8576428294181824e-01
    z[7,6,3]  R2465     7.0320683717727661e-01
    z[7,6,4]  R60       1
    z[7,6,4]  R69       -1
    z[7,6,4]  R2410     -1
    z[7,6,4]  R2411     1
    z[7,6,4]  R2416     0.60483717918396
    z[7,6,4]  R2417     -6.4296253025531769e-02
    z[7,6,4]  R2418     1.0830979794263840e-01
    z[7,6,4]  R2419     1.2754504382610321e-01
    z[7,6,4]  R2420     5.1302719116210938e-01
    z[7,6,4]  R2421     2.7713507413864136e-01
    z[7,6,4]  R2422     2.7354445308446884e-02
    z[7,6,4]  R2423     2.0819666981697083e-01
    z[7,6,4]  R2424     1.1473132669925690e-01
    z[7,6,4]  R2425     -3.4995445609092712e-01
    z[7,6,4]  R2426     -5.6651449203491211e-01
    z[7,6,4]  R2427     2.1771334111690521e-01
    z[7,6,4]  R2428     -5.0821971148252487e-02
    z[7,6,4]  R2429     1.8033283948898315e-01
    z[7,6,4]  R2430     -6.3421934843063354e-02
    z[7,6,4]  R2431     1.9550846517086029e-01
    z[7,6,4]  R2432     -1.7913454771041870e-01
    z[7,6,4]  R2433     -1.1474343389272690e-01
    z[7,6,4]  R2434     -4.7085419297218323e-01
    z[7,6,4]  R2435     -2.8207856416702271e-01
    z[7,6,4]  R2436     -5.1008272916078568e-02
    z[7,6,4]  R2437     2.4283653497695923e-01
    z[7,6,4]  R2438     -4.7067850828170776e-01
    z[7,6,4]  R2439     2.1497736871242523e-01
    z[7,6,4]  R2440     -6.2021367251873016e-02
    z[7,6,4]  R2441     -1.5125301480293274e-01
    z[7,6,4]  R2442     1.5340529382228851e-01
    z[7,6,4]  R2443     9.9574409425258636e-02
    z[7,6,4]  R2444     -2.3859688639640808e-01
    z[7,6,4]  R2445     1.2870885431766510e-01
    z[7,6,4]  R2446     0.357509046792984
    z[7,6,4]  R2447     -6.0309016704559326e-01
    z[7,6,4]  R2448     -0.543997585773468
    z[7,6,4]  R2449     -1.0941015928983688e-01
    z[7,6,4]  R2450     3.4542571753263474e-02
    z[7,6,4]  R2451     1.6265991330146790e-01
    z[7,6,4]  R2452     -6.8174833059310913e-01
    z[7,6,4]  R2453     -1.1812223494052887e-01
    z[7,6,4]  R2454     -7.7611476182937622e-01
    z[7,6,4]  R2455     2.8842344880104065e-01
    z[7,6,4]  R2456     2.9466179013252258e-01
    z[7,6,4]  R2457     -5.8741912245750427e-02
    z[7,6,4]  R2458     -4.2761716246604919e-01
    z[7,6,4]  R2459     -2.2641818225383759e-01
    z[7,6,4]  R2460     -4.2552046477794647e-02
    z[7,6,4]  R2461     1.1397330462932587e-01
    z[7,6,4]  R2462     1.2061966955661774e-01
    z[7,6,4]  R2463     -3.0990007519721985e-01
    z[7,6,4]  R2464     -4.6752437949180603e-01
    z[7,6,4]  R2465     -2.5311350822448730e-01
    z[7,6,5]  R61       1
    z[7,6,5]  R70       -1
    z[7,6,5]  R2412     -1
    z[7,6,5]  R2413     1
    z[7,6,5]  R2416     2.1369495987892151e-01
    z[7,6,5]  R2417     1.5344811603426933e-02
    z[7,6,5]  R2418     -6.4999371767044067e-01
    z[7,6,5]  R2419     -5.6228202581405640e-01
    z[7,6,5]  R2420     -2.0857641100883484e-01
    z[7,6,5]  R2421     -1.8942032754421234e-01
    z[7,6,5]  R2422     -4.2550815269351006e-03
    z[7,6,5]  R2423     5.3575128316879272e-02
    z[7,6,5]  R2424     -3.6595806479454041e-01
    z[7,6,5]  R2425     6.7329391837120056e-02
    z[7,6,5]  R2426     -2.6174557209014893e-01
    z[7,6,5]  R2427     1.4011247456073761e-01
    z[7,6,5]  R2428     -1.1286448687314987e-01
    z[7,6,5]  R2429     1.3865859806537628e-01
    z[7,6,5]  R2430     1.2577064335346222e-01
    z[7,6,5]  R2431     9.6456006169319153e-02
    z[7,6,5]  R2432     1.4606384932994843e-01
    z[7,6,5]  R2433     6.4928233623504639e-02
    z[7,6,5]  R2434     -8.9737243950366974e-02
    z[7,6,5]  R2435     2.1938440203666687e-01
    z[7,6,5]  R2436     2.6106894016265869e-01
    z[7,6,5]  R2437     -1.2218544632196426e-01
    z[7,6,5]  R2438     -6.5748314373195171e-03
    z[7,6,5]  R2439     2.5487670302391052e-01
    z[7,6,5]  R2440     -8.0740720033645630e-02
    z[7,6,5]  R2441     1.3575650751590729e-01
    z[7,6,5]  R2442     -3.7502128630876541e-02
    z[7,6,5]  R2443     -6.5509853884577751e-03
    z[7,6,5]  R2444     -1.7547595500946045e-01
    z[7,6,5]  R2445     0.0950714573264122
    z[7,6,5]  R2446     -2.6345381140708923e-01
    z[7,6,5]  R2447     -2.3830138146877289e-01
    z[7,6,5]  R2448     -2.6126924157142639e-01
    z[7,6,5]  R2449     6.8551085889339447e-02
    z[7,6,5]  R2450     -2.7362501621246338e-01
    z[7,6,5]  R2451     -3.1204009056091309e-01
    z[7,6,5]  R2452     1.8901422619819641e-01
    z[7,6,5]  R2453     -2.0798480510711670e-01
    z[7,6,5]  R2454     -4.4986773282289505e-02
    z[7,6,5]  R2455     -1.4680914580821991e-01
    z[7,6,5]  R2456     8.4582549333572388e-01
    z[7,6,5]  R2457     -2.3791438341140747e-01
    z[7,6,5]  R2458     -7.7955365180969238e-02
    z[7,6,5]  R2459     1.5660324692726135e-01
    z[7,6,5]  R2460     2.5693657994270325e-01
    z[7,6,5]  R2461     3.5654449462890625e-01
    z[7,6,5]  R2462     6.1161947250366211e-01
    z[7,6,5]  R2463     1.6179552674293518e-01
    z[7,6,5]  R2464     3.1513112783432007e-01
    z[7,6,5]  R2465     3.5332062840461731e-01
    z[7,6,6]  R62       1
    z[7,6,6]  R71       -1
    z[7,6,6]  R2414     -1
    z[7,6,6]  R2415     1
    z[7,6,6]  R2416     -1.7452044785022736e-01
    z[7,6,6]  R2417     8.2540971040725708e-01
    z[7,6,6]  R2418     -5.7376581430435181e-01
    z[7,6,6]  R2419     3.8757154345512390e-01
    z[7,6,6]  R2420     -6.9144135713577271e-01
    z[7,6,6]  R2421     -3.0708971619606018e-01
    z[7,6,6]  R2422     3.9589628577232361e-01
    z[7,6,6]  R2423     5.2624928951263428e-01
    z[7,6,6]  R2424     -2.7057321742177010e-02
    z[7,6,6]  R2425     1.8995814025402069e-02
    z[7,6,6]  R2426     -7.4864067137241364e-02
    z[7,6,6]  R2427     0.307809978723526
    z[7,6,6]  R2428     2.5697097182273865e-01
    z[7,6,6]  R2429     3.6726808547973633e-01
    z[7,6,6]  R2430     8.0694079399108887e-02
    z[7,6,6]  R2431     2.7178376913070679e-01
    z[7,6,6]  R2432     -1.2867182493209839e-01
    z[7,6,6]  R2433     -3.3929708600044250e-01
    z[7,6,6]  R2434     -1.4879697002470493e-02
    z[7,6,6]  R2435     1.4914938807487488e-01
    z[7,6,6]  R2436     4.2420718073844910e-01
    z[7,6,6]  R2437     -1.4500647783279419e-01
    z[7,6,6]  R2438     -2.6295873522758484e-01
    z[7,6,6]  R2439     -2.8509417176246643e-01
    z[7,6,6]  R2440     -5.1247671246528625e-02
    z[7,6,6]  R2441     4.7775931656360626e-02
    z[7,6,6]  R2442     -2.7299644425511360e-02
    z[7,6,6]  R2443     -8.1580407917499542e-02
    z[7,6,6]  R2444     -1.1143527925014496e-01
    z[7,6,6]  R2445     1.0900022834539413e-01
    z[7,6,6]  R2446     -4.9204191565513611e-01
    z[7,6,6]  R2447     -3.5190141201019287e-01
    z[7,6,6]  R2448     2.6098656654357910e-01
    z[7,6,6]  R2449     -5.8317434042692184e-02
    z[7,6,6]  R2450     6.7316746711730957e-01
    z[7,6,6]  R2451     2.5680345296859741e-01
    z[7,6,6]  R2452     3.8292786478996277e-01
    z[7,6,6]  R2453     7.2154581546783447e-01
    z[7,6,6]  R2454     -2.7061384916305542e-01
    z[7,6,6]  R2455     -9.1947264969348907e-02
    z[7,6,6]  R2456     -2.3163300752639771e-01
    z[7,6,6]  R2457     1.1673419922590256e-01
    z[7,6,6]  R2458     -0.0792611688375473
    z[7,6,6]  R2459     -4.4976255297660828e-01
    z[7,6,6]  R2460     4.3725162744522095e-01
    z[7,6,6]  R2461     -1.9910500943660736e-01
    z[7,6,6]  R2462     2.6285931468009949e-01
    z[7,6,6]  R2463     -4.4094722718000412e-02
    z[7,6,6]  R2464     1.9140637014061213e-03
    z[7,6,6]  R2465     4.2821615934371948e-02
    length[0]  OBJ       1
    length[1]  OBJ       1
    length[2]  OBJ       1
    length[3]  OBJ       1
    length[4]  OBJ       1
    length[5]  OBJ       1
    length[6]  OBJ       1
    length[7]  OBJ       1
    delta[0,0]  R2        1
    delta[0,1]  R3        1
    delta[0,2]  R4        1
    delta[0,3]  R5        1
    delta[0,4]  R6        1
    delta[0,5]  R7        1
    delta[0,6]  R8        1
    delta[1,0]  R11       1
    delta[1,1]  R12       1
    delta[1,2]  R13       1
    delta[1,3]  R14       1
    delta[1,4]  R15       1
    delta[1,5]  R16       1
    delta[1,6]  R17       1
    delta[2,0]  R20       1
    delta[2,1]  R21       1
    delta[2,2]  R22       1
    delta[2,3]  R23       1
    delta[2,4]  R24       1
    delta[2,5]  R25       1
    delta[2,6]  R26       1
    delta[3,0]  R29       1
    delta[3,1]  R30       1
    delta[3,2]  R31       1
    delta[3,3]  R32       1
    delta[3,4]  R33       1
    delta[3,5]  R34       1
    delta[3,6]  R35       1
    delta[4,0]  R38       1
    delta[4,1]  R39       1
    delta[4,2]  R40       1
    delta[4,3]  R41       1
    delta[4,4]  R42       1
    delta[4,5]  R43       1
    delta[4,6]  R44       1
    delta[5,0]  R47       1
    delta[5,1]  R48       1
    delta[5,2]  R49       1
    delta[5,3]  R50       1
    delta[5,4]  R51       1
    delta[5,5]  R52       1
    delta[5,6]  R53       1
    delta[6,0]  R56       1
    delta[6,1]  R57       1
    delta[6,2]  R58       1
    delta[6,3]  R59       1
    delta[6,4]  R60       1
    delta[6,5]  R61       1
    delta[6,6]  R62       1
    delta[7,0]  R65       1
    delta[7,1]  R66       1
    delta[7,2]  R67       1
    delta[7,3]  R68       1
    delta[7,4]  R69       1
    delta[7,5]  R70       1
    delta[7,6]  R71       1
RHS
    RHS1      R1        1
    RHS1      R10       1
    RHS1      R19       1
    RHS1      R28       1
    RHS1      R37       1
    RHS1      R46       1
    RHS1      R55       1
    RHS1      R64       1
    RHS1      R72       1
    RHS1      R73       -1
BOUNDS
 BV BND1      phi[0,1]
 BV BND1      phi[1,0]
 BV BND1      phi[0,4]
 BV BND1      phi[4,0]
 BV BND1      phi[0,5]
 BV BND1      phi[5,0]
 BV BND1      phi[8,0]
 BV BND1      phi[1,2]
 BV BND1      phi[2,1]
 BV BND1      phi[1,4]
 BV BND1      phi[4,1]
 BV BND1      phi[1,5]
 BV BND1      phi[5,1]
 BV BND1      phi[2,3]
 BV BND1      phi[3,2]
 BV BND1      phi[3,7]
 BV BND1      phi[7,3]
 BV BND1      phi[3,9]
 BV BND1      phi[4,5]
 BV BND1      phi[5,4]
 BV BND1      phi[4,6]
 BV BND1      phi[6,4]
 BV BND1      phi[8,4]
 BV BND1      phi[5,6]
 BV BND1      phi[6,5]
 BV BND1      phi[6,7]
 BV BND1      phi[7,6]
 BV BND1      phi[7,9]
 FR BND1      z[0,1,0]
 FR BND1      z[0,1,1]
 FR BND1      z[0,1,2]
 FR BND1      z[0,1,3]
 FR BND1      z[0,1,4]
 FR BND1      z[0,1,5]
 FR BND1      z[0,1,6]
 FR BND1      z[1,0,0]
 FR BND1      z[1,0,1]
 FR BND1      z[1,0,2]
 FR BND1      z[1,0,3]
 FR BND1      z[1,0,4]
 FR BND1      z[1,0,5]
 FR BND1      z[1,0,6]
 FR BND1      z[0,4,0]
 FR BND1      z[0,4,1]
 FR BND1      z[0,4,2]
 FR BND1      z[0,4,3]
 FR BND1      z[0,4,4]
 FR BND1      z[0,4,5]
 FR BND1      z[0,4,6]
 FR BND1      z[4,0,0]
 FR BND1      z[4,0,1]
 FR BND1      z[4,0,2]
 FR BND1      z[4,0,3]
 FR BND1      z[4,0,4]
 FR BND1      z[4,0,5]
 FR BND1      z[4,0,6]
 FR BND1      z[0,5,0]
 FR BND1      z[0,5,1]
 FR BND1      z[0,5,2]
 FR BND1      z[0,5,3]
 FR BND1      z[0,5,4]
 FR BND1      z[0,5,5]
 FR BND1      z[0,5,6]
 FR BND1      z[5,0,0]
 FR BND1      z[5,0,1]
 FR BND1      z[5,0,2]
 FR BND1      z[5,0,3]
 FR BND1      z[5,0,4]
 FR BND1      z[5,0,5]
 FR BND1      z[5,0,6]
 FR BND1      z[1,2,0]
 FR BND1      z[1,2,1]
 FR BND1      z[1,2,2]
 FR BND1      z[1,2,3]
 FR BND1      z[1,2,4]
 FR BND1      z[1,2,5]
 FR BND1      z[1,2,6]
 FR BND1      z[2,1,0]
 FR BND1      z[2,1,1]
 FR BND1      z[2,1,2]
 FR BND1      z[2,1,3]
 FR BND1      z[2,1,4]
 FR BND1      z[2,1,5]
 FR BND1      z[2,1,6]
 FR BND1      z[1,4,0]
 FR BND1      z[1,4,1]
 FR BND1      z[1,4,2]
 FR BND1      z[1,4,3]
 FR BND1      z[1,4,4]
 FR BND1      z[1,4,5]
 FR BND1      z[1,4,6]
 FR BND1      z[4,1,0]
 FR BND1      z[4,1,1]
 FR BND1      z[4,1,2]
 FR BND1      z[4,1,3]
 FR BND1      z[4,1,4]
 FR BND1      z[4,1,5]
 FR BND1      z[4,1,6]
 FR BND1      z[1,5,0]
 FR BND1      z[1,5,1]
 FR BND1      z[1,5,2]
 FR BND1      z[1,5,3]
 FR BND1      z[1,5,4]
 FR BND1      z[1,5,5]
 FR BND1      z[1,5,6]
 FR BND1      z[5,1,0]
 FR BND1      z[5,1,1]
 FR BND1      z[5,1,2]
 FR BND1      z[5,1,3]
 FR BND1      z[5,1,4]
 FR BND1      z[5,1,5]
 FR BND1      z[5,1,6]
 FR BND1      z[2,3,0]
 FR BND1      z[2,3,1]
 FR BND1      z[2,3,2]
 FR BND1      z[2,3,3]
 FR BND1      z[2,3,4]
 FR BND1      z[2,3,5]
 FR BND1      z[2,3,6]
 FR BND1      z[3,2,0]
 FR BND1      z[3,2,1]
 FR BND1      z[3,2,2]
 FR BND1      z[3,2,3]
 FR BND1      z[3,2,4]
 FR BND1      z[3,2,5]
 FR BND1      z[3,2,6]
 FR BND1      z[3,7,0]
 FR BND1      z[3,7,1]
 FR BND1      z[3,7,2]
 FR BND1      z[3,7,3]
 FR BND1      z[3,7,4]
 FR BND1      z[3,7,5]
 FR BND1      z[3,7,6]
 FR BND1      z[7,3,0]
 FR BND1      z[7,3,1]
 FR BND1      z[7,3,2]
 FR BND1      z[7,3,3]
 FR BND1      z[7,3,4]
 FR BND1      z[7,3,5]
 FR BND1      z[7,3,6]
 FR BND1      z[4,5,0]
 FR BND1      z[4,5,1]
 FR BND1      z[4,5,2]
 FR BND1      z[4,5,3]
 FR BND1      z[4,5,4]
 FR BND1      z[4,5,5]
 FR BND1      z[4,5,6]
 FR BND1      z[5,4,0]
 FR BND1      z[5,4,1]
 FR BND1      z[5,4,2]
 FR BND1      z[5,4,3]
 FR BND1      z[5,4,4]
 FR BND1      z[5,4,5]
 FR BND1      z[5,4,6]
 FR BND1      z[4,6,0]
 FR BND1      z[4,6,1]
 FR BND1      z[4,6,2]
 FR BND1      z[4,6,3]
 FR BND1      z[4,6,4]
 FR BND1      z[4,6,5]
 FR BND1      z[4,6,6]
 FR BND1      z[6,4,0]
 FR BND1      z[6,4,1]
 FR BND1      z[6,4,2]
 FR BND1      z[6,4,3]
 FR BND1      z[6,4,4]
 FR BND1      z[6,4,5]
 FR BND1      z[6,4,6]
 FR BND1      z[5,6,0]
 FR BND1      z[5,6,1]
 FR BND1      z[5,6,2]
 FR BND1      z[5,6,3]
 FR BND1      z[5,6,4]
 FR BND1      z[5,6,5]
 FR BND1      z[5,6,6]
 FR BND1      z[6,5,0]
 FR BND1      z[6,5,1]
 FR BND1      z[6,5,2]
 FR BND1      z[6,5,3]
 FR BND1      z[6,5,4]
 FR BND1      z[6,5,5]
 FR BND1      z[6,5,6]
 FR BND1      z[6,7,0]
 FR BND1      z[6,7,1]
 FR BND1      z[6,7,2]
 FR BND1      z[6,7,3]
 FR BND1      z[6,7,4]
 FR BND1      z[6,7,5]
 FR BND1      z[6,7,6]
 FR BND1      z[7,6,0]
 FR BND1      z[7,6,1]
 FR BND1      z[7,6,2]
 FR BND1      z[7,6,3]
 FR BND1      z[7,6,4]
 FR BND1      z[7,6,5]
 FR BND1      z[7,6,6]
 FR BND1      delta[0,0]
 FR BND1      delta[0,1]
 FR BND1      delta[0,2]
 FR BND1      delta[0,3]
 FR BND1      delta[0,4]
 FR BND1      delta[0,5]
 FR BND1      delta[0,6]
 FR BND1      delta[1,0]
 FR BND1      delta[1,1]
 FR BND1      delta[1,2]
 FR BND1      delta[1,3]
 FR BND1      delta[1,4]
 FR BND1      delta[1,5]
 FR BND1      delta[1,6]
 FR BND1      delta[2,0]
 FR BND1      delta[2,1]
 FR BND1      delta[2,2]
 FR BND1      delta[2,3]
 FR BND1      delta[2,4]
 FR BND1      delta[2,5]
 FR BND1      delta[2,6]
 FR BND1      delta[3,0]
 FR BND1      delta[3,1]
 FR BND1      delta[3,2]
 FR BND1      delta[3,3]
 FR BND1      delta[3,4]
 FR BND1      delta[3,5]
 FR BND1      delta[3,6]
 FR BND1      delta[4,0]
 FR BND1      delta[4,1]
 FR BND1      delta[4,2]
 FR BND1      delta[4,3]
 FR BND1      delta[4,4]
 FR BND1      delta[4,5]
 FR BND1      delta[4,6]
 FR BND1      delta[5,0]
 FR BND1      delta[5,1]
 FR BND1      delta[5,2]
 FR BND1      delta[5,3]
 FR BND1      delta[5,4]
 FR BND1      delta[5,5]
 FR BND1      delta[5,6]
 FR BND1      delta[6,0]
 FR BND1      delta[6,1]
 FR BND1      delta[6,2]
 FR BND1      delta[6,3]
 FR BND1      delta[6,4]
 FR BND1      delta[6,5]
 FR BND1      delta[6,6]
 FR BND1      delta[7,0]
 FR BND1      delta[7,1]
 FR BND1      delta[7,2]
 FR BND1      delta[7,3]
 FR BND1      delta[7,4]
 FR BND1      delta[7,5]
 FR BND1      delta[7,6]
QCMATRIX   qc0     
    length[0]  length[0]  -1
    delta[0,0]  delta[0,0]  1
    delta[0,1]  delta[0,1]  1
    delta[0,2]  delta[0,2]  1
    delta[0,3]  delta[0,3]  1
    delta[0,4]  delta[0,4]  1
    delta[0,5]  delta[0,5]  1
    delta[0,6]  delta[0,6]  1
QCMATRIX   qc1     
    length[1]  length[1]  -1
    delta[1,0]  delta[1,0]  1
    delta[1,1]  delta[1,1]  1
    delta[1,2]  delta[1,2]  1
    delta[1,3]  delta[1,3]  1
    delta[1,4]  delta[1,4]  1
    delta[1,5]  delta[1,5]  1
    delta[1,6]  delta[1,6]  1
QCMATRIX   qc2     
    length[2]  length[2]  -1
    delta[2,0]  delta[2,0]  1
    delta[2,1]  delta[2,1]  1
    delta[2,2]  delta[2,2]  1
    delta[2,3]  delta[2,3]  1
    delta[2,4]  delta[2,4]  1
    delta[2,5]  delta[2,5]  1
    delta[2,6]  delta[2,6]  1
QCMATRIX   qc3     
    length[3]  length[3]  -1
    delta[3,0]  delta[3,0]  1
    delta[3,1]  delta[3,1]  1
    delta[3,2]  delta[3,2]  1
    delta[3,3]  delta[3,3]  1
    delta[3,4]  delta[3,4]  1
    delta[3,5]  delta[3,5]  1
    delta[3,6]  delta[3,6]  1
QCMATRIX   qc4     
    length[4]  length[4]  -1
    delta[4,0]  delta[4,0]  1
    delta[4,1]  delta[4,1]  1
    delta[4,2]  delta[4,2]  1
    delta[4,3]  delta[4,3]  1
    delta[4,4]  delta[4,4]  1
    delta[4,5]  delta[4,5]  1
    delta[4,6]  delta[4,6]  1
QCMATRIX   qc5     
    length[5]  length[5]  -1
    delta[5,0]  delta[5,0]  1
    delta[5,1]  delta[5,1]  1
    delta[5,2]  delta[5,2]  1
    delta[5,3]  delta[5,3]  1
    delta[5,4]  delta[5,4]  1
    delta[5,5]  delta[5,5]  1
    delta[5,6]  delta[5,6]  1
QCMATRIX   qc6     
    length[6]  length[6]  -1
    delta[6,0]  delta[6,0]  1
    delta[6,1]  delta[6,1]  1
    delta[6,2]  delta[6,2]  1
    delta[6,3]  delta[6,3]  1
    delta[6,4]  delta[6,4]  1
    delta[6,5]  delta[6,5]  1
    delta[6,6]  delta[6,6]  1
QCMATRIX   qc7     
    length[7]  length[7]  -1
    delta[7,0]  delta[7,0]  1
    delta[7,1]  delta[7,1]  1
    delta[7,2]  delta[7,2]  1
    delta[7,3]  delta[7,3]  1
    delta[7,4]  delta[7,4]  1
    delta[7,5]  delta[7,5]  1
    delta[7,6]  delta[7,6]  1
ENDATA
