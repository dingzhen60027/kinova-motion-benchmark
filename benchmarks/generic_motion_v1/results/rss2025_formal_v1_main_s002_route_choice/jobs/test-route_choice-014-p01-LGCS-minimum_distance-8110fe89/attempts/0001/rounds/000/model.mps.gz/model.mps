NAME LGCS_GCS_Eq5_5_projected
ROWS
 N  OBJ
 E  R0      
 L  R1      
 E  R2      
 E  R3      
 E  R4      
 E  R5      
 E  R6      
 E  R7      
 E  R8      
 E  R9      
 L  R10     
 E  R11     
 E  R12     
 E  R13     
 E  R14     
 E  R15     
 E  R16     
 E  R17     
 E  R18     
 L  R19     
 E  R20     
 E  R21     
 E  R22     
 E  R23     
 E  R24     
 E  R25     
 E  R26     
 E  R27     
 L  R28     
 E  R29     
 E  R30     
 E  R31     
 E  R32     
 E  R33     
 E  R34     
 E  R35     
 E  R36     
 L  R37     
 E  R38     
 E  R39     
 E  R40     
 E  R41     
 E  R42     
 E  R43     
 E  R44     
 E  R45     
 L  R46     
 E  R47     
 E  R48     
 E  R49     
 E  R50     
 E  R51     
 E  R52     
 E  R53     
 E  R54     
 E  R55     
 L  R56     
 L  R57     
 L  R58     
 L  R59     
 L  R60     
 L  R61     
 L  R62     
 L  R63     
 L  R64     
 L  R65     
 L  R66     
 L  R67     
 L  R68     
 L  R69     
 L  R70     
 L  R71     
 L  R72     
 L  R73     
 L  R74     
 L  R75     
 L  R76     
 L  R77     
 L  R78     
 L  R79     
 L  R80     
 L  R81     
 L  R82     
 L  R83     
 L  R84     
 L  R85     
 L  R86     
 L  R87     
 L  R88     
 L  R89     
 L  R90     
 L  R91     
 L  R92     
 L  R93     
 L  R94     
 L  R95     
 L  R96     
 L  R97     
 L  R98     
 L  R99     
 L  R100    
 L  R101    
 L  R102    
 L  R103    
 L  R104    
 L  R105    
 L  R106    
 L  R107    
 L  R108    
 L  R109    
 L  R110    
 L  R111    
 L  R112    
 L  R113    
 L  R114    
 L  R115    
 L  R116    
 L  R117    
 L  R118    
 L  R119    
 L  R120    
 L  R121    
 L  R122    
 L  R123    
 L  R124    
 L  R125    
 L  R126    
 L  R127    
 L  R128    
 L  R129    
 L  R130    
 L  R131    
 L  R132    
 L  R133    
 L  R134    
 L  R135    
 L  R136    
 L  R137    
 L  R138    
 L  R139    
 L  R140    
 L  R141    
 L  R142    
 L  R143    
 L  R144    
 L  R145    
 L  R146    
 L  R147    
 L  R148    
 L  R149    
 L  R150    
 L  R151    
 L  R152    
 L  R153    
 L  R154    
 L  R155    
 L  R156    
 L  R157    
 L  R158    
 L  R159    
 L  R160    
 L  R161    
 L  R162    
 L  R163    
 L  R164    
 L  R165    
 L  R166    
 L  R167    
 L  R168    
 L  R169    
 L  R170    
 L  R171    
 L  R172    
 L  R173    
 L  R174    
 L  R175    
 L  R176    
 L  R177    
 L  R178    
 L  R179    
 L  R180    
 L  R181    
 L  R182    
 L  R183    
 L  R184    
 L  R185    
 L  R186    
 L  R187    
 L  R188    
 L  R189    
 L  R190    
 L  R191    
 L  R192    
 L  R193    
 L  R194    
 L  R195    
 L  R196    
 L  R197    
 L  R198    
 L  R199    
 L  R200    
 L  R201    
 L  R202    
 L  R203    
 L  R204    
 L  R205    
 L  R206    
 L  R207    
 L  R208    
 L  R209    
 L  R210    
 L  R211    
 L  R212    
 L  R213    
 L  R214    
 L  R215    
 L  R216    
 L  R217    
 L  R218    
 L  R219    
 L  R220    
 L  R221    
 L  R222    
 L  R223    
 L  R224    
 L  R225    
 L  R226    
 L  R227    
 L  R228    
 L  R229    
 L  R230    
 L  R231    
 L  R232    
 L  R233    
 L  R234    
 L  R235    
 L  R236    
 L  R237    
 L  R238    
 L  R239    
 L  R240    
 L  R241    
 L  R242    
 L  R243    
 L  R244    
 L  R245    
 L  R246    
 L  R247    
 L  R248    
 L  R249    
 L  R250    
 L  R251    
 L  R252    
 L  R253    
 L  R254    
 L  R255    
 L  R256    
 L  R257    
 L  R258    
 L  R259    
 L  R260    
 L  R261    
 L  R262    
 L  R263    
 L  R264    
 L  R265    
 L  R266    
 L  R267    
 L  R268    
 L  R269    
 L  R270    
 L  R271    
 L  R272    
 L  R273    
 L  R274    
 L  R275    
 L  R276    
 L  R277    
 L  R278    
 L  R279    
 L  R280    
 L  R281    
 L  R282    
 L  R283    
 L  R284    
 L  R285    
 L  R286    
 L  R287    
 L  R288    
 L  R289    
 L  R290    
 L  R291    
 L  R292    
 L  R293    
 L  R294    
 L  R295    
 L  R296    
 L  R297    
 L  R298    
 L  R299    
 L  R300    
 L  R301    
 L  R302    
 L  R303    
 L  R304    
 L  R305    
 L  R306    
 L  R307    
 L  R308    
 L  R309    
 L  R310    
 L  R311    
 L  R312    
 L  R313    
 L  R314    
 L  R315    
 L  R316    
 L  R317    
 L  R318    
 L  R319    
 L  R320    
 L  R321    
 L  R322    
 L  R323    
 L  R324    
 L  R325    
 L  R326    
 L  R327    
 L  R328    
 L  R329    
 L  R330    
 L  R331    
 L  R332    
 L  R333    
 L  R334    
 L  R335    
 L  R336    
 L  R337    
 L  R338    
 L  R339    
 L  R340    
 L  R341    
 L  R342    
 L  R343    
 L  R344    
 L  R345    
 L  R346    
 L  R347    
 L  R348    
 L  R349    
 L  R350    
 L  R351    
 L  R352    
 L  R353    
 L  R354    
 L  R355    
 L  R356    
 L  R357    
 L  R358    
 L  R359    
 L  R360    
 L  R361    
 L  R362    
 L  R363    
 L  R364    
 L  R365    
 L  R366    
 L  R367    
 L  R368    
 L  R369    
 L  R370    
 L  R371    
 L  R372    
 L  R373    
 L  R374    
 L  R375    
 L  R376    
 L  R377    
 L  R378    
 L  R379    
 L  R380    
 L  R381    
 L  R382    
 L  R383    
 L  R384    
 L  R385    
 L  R386    
 L  R387    
 L  R388    
 L  R389    
 L  R390    
 L  R391    
 L  R392    
 L  R393    
 L  R394    
 L  R395    
 L  R396    
 L  R397    
 L  R398    
 L  R399    
 L  R400    
 L  R401    
 L  R402    
 L  R403    
 L  R404    
 L  R405    
 L  R406    
 L  R407    
 L  R408    
 L  R409    
 L  R410    
 L  R411    
 L  R412    
 L  R413    
 L  R414    
 L  R415    
 L  R416    
 L  R417    
 L  R418    
 L  R419    
 L  R420    
 L  R421    
 L  R422    
 L  R423    
 L  R424    
 L  R425    
 L  R426    
 L  R427    
 L  R428    
 L  R429    
 L  R430    
 L  R431    
 L  R432    
 L  R433    
 L  R434    
 L  R435    
 L  R436    
 L  R437    
 L  R438    
 L  R439    
 L  R440    
 L  R441    
 L  R442    
 L  R443    
 L  R444    
 L  R445    
 L  R446    
 L  R447    
 L  R448    
 L  R449    
 L  R450    
 L  R451    
 L  R452    
 L  R453    
 L  R454    
 L  R455    
 L  R456    
 L  R457    
 L  R458    
 L  R459    
 L  R460    
 L  R461    
 L  R462    
 L  R463    
 L  R464    
 L  R465    
 L  R466    
 L  R467    
 L  R468    
 L  R469    
 L  R470    
 L  R471    
 L  R472    
 L  R473    
 L  R474    
 L  R475    
 L  R476    
 L  R477    
 L  R478    
 L  R479    
 L  R480    
 L  R481    
 L  R482    
 L  R483    
 L  R484    
 L  R485    
 L  R486    
 L  R487    
 L  R488    
 L  R489    
 L  R490    
 L  R491    
 L  R492    
 L  R493    
 L  R494    
 L  R495    
 L  R496    
 L  R497    
 L  R498    
 L  R499    
 L  R500    
 L  R501    
 L  R502    
 L  R503    
 L  R504    
 L  R505    
 L  R506    
 L  R507    
 L  R508    
 L  R509    
 L  R510    
 L  R511    
 L  R512    
 L  R513    
 L  R514    
 L  R515    
 L  R516    
 L  R517    
 L  R518    
 L  R519    
 L  R520    
 L  R521    
 L  R522    
 L  R523    
 L  R524    
 L  R525    
 L  R526    
 L  R527    
 L  R528    
 L  R529    
 L  R530    
 L  R531    
 L  R532    
 L  R533    
 L  R534    
 L  R535    
 L  R536    
 L  R537    
 L  R538    
 L  R539    
 L  R540    
 L  R541    
 L  R542    
 L  R543    
 L  R544    
 L  R545    
 L  R546    
 L  R547    
 L  R548    
 L  R549    
 L  R550    
 L  R551    
 L  R552    
 L  R553    
 L  R554    
 L  R555    
 L  R556    
 L  R557    
 L  R558    
 L  R559    
 L  R560    
 L  R561    
 L  R562    
 L  R563    
 L  R564    
 L  R565    
 L  R566    
 L  R567    
 L  R568    
 L  R569    
 L  R570    
 L  R571    
 L  R572    
 L  R573    
 L  R574    
 L  R575    
 L  R576    
 L  R577    
 L  R578    
 L  R579    
 L  R580    
 L  R581    
 L  R582    
 L  R583    
 L  R584    
 L  R585    
 L  R586    
 L  R587    
 L  R588    
 L  R589    
 L  R590    
 L  R591    
 L  R592    
 L  R593    
 L  R594    
 L  R595    
 L  R596    
 L  R597    
 L  R598    
 L  R599    
 L  R600    
 L  R601    
 L  R602    
 L  R603    
 L  R604    
 L  R605    
 L  R606    
 L  R607    
 L  R608    
 L  R609    
 L  R610    
 L  R611    
 L  R612    
 L  R613    
 L  R614    
 L  R615    
 L  R616    
 L  R617    
 L  R618    
 L  R619    
 L  R620    
 L  R621    
 L  R622    
 L  R623    
 L  R624    
 L  R625    
 L  R626    
 L  R627    
 L  R628    
 L  R629    
 L  R630    
 L  R631    
 L  R632    
 L  R633    
 L  R634    
 L  R635    
 L  R636    
 L  R637    
 L  R638    
 L  R639    
 L  R640    
 L  R641    
 L  R642    
 L  R643    
 L  R644    
 L  R645    
 L  R646    
 L  R647    
 L  R648    
 L  R649    
 L  R650    
 L  R651    
 L  R652    
 L  R653    
 L  R654    
 L  R655    
 L  R656    
 L  R657    
 L  R658    
 L  R659    
 L  R660    
 L  R661    
 L  R662    
 L  R663    
 L  R664    
 L  R665    
 L  R666    
 L  R667    
 L  R668    
 L  R669    
 L  R670    
 L  R671    
 L  R672    
 L  R673    
 L  R674    
 L  R675    
 L  R676    
 L  R677    
 L  R678    
 L  R679    
 L  R680    
 L  R681    
 L  R682    
 L  R683    
 L  R684    
 L  R685    
 L  R686    
 L  R687    
 L  R688    
 L  R689    
 L  R690    
 L  R691    
 L  R692    
 L  R693    
 L  R694    
 L  R695    
 L  R696    
 L  R697    
 L  R698    
 L  R699    
 L  R700    
 L  R701    
 L  R702    
 L  R703    
 L  R704    
 L  R705    
 L  R706    
 L  R707    
 L  R708    
 L  R709    
 L  R710    
 L  R711    
 L  R712    
 L  R713    
 L  R714    
 L  R715    
 L  R716    
 L  R717    
 L  R718    
 L  R719    
 L  R720    
 L  R721    
 L  R722    
 L  R723    
 L  R724    
 L  R725    
 L  R726    
 L  R727    
 L  R728    
 L  R729    
 L  R730    
 L  R731    
 L  R732    
 L  R733    
 L  R734    
 L  R735    
 L  R736    
 L  R737    
 L  R738    
 L  R739    
 L  R740    
 L  R741    
 L  R742    
 L  R743    
 L  R744    
 L  R745    
 L  R746    
 L  R747    
 L  R748    
 L  R749    
 L  R750    
 L  R751    
 L  R752    
 L  R753    
 L  R754    
 L  R755    
 L  R756    
 L  R757    
 L  R758    
 L  R759    
 L  R760    
 L  R761    
 L  R762    
 L  R763    
 L  R764    
 L  R765    
 L  R766    
 L  R767    
 L  R768    
 L  R769    
 L  R770    
 L  R771    
 L  R772    
 L  R773    
 L  R774    
 L  R775    
 L  R776    
 L  R777    
 L  R778    
 L  R779    
 L  R780    
 L  R781    
 L  R782    
 L  R783    
 L  R784    
 L  R785    
 L  R786    
 L  R787    
 L  R788    
 L  R789    
 L  R790    
 L  R791    
 L  R792    
 L  R793    
 L  R794    
 L  R795    
 L  R796    
 L  R797    
 L  R798    
 L  R799    
 L  R800    
 L  R801    
 L  R802    
 L  R803    
 L  R804    
 L  R805    
 L  R806    
 L  R807    
 L  R808    
 L  R809    
 L  R810    
 L  R811    
 L  R812    
 L  R813    
 L  R814    
 L  R815    
 L  R816    
 L  R817    
 L  R818    
 L  R819    
 L  R820    
 L  R821    
 L  R822    
 L  R823    
 L  R824    
 L  R825    
 L  R826    
 L  R827    
 L  R828    
 L  R829    
 L  R830    
 L  R831    
 L  R832    
 L  R833    
 L  R834    
 L  R835    
 L  R836    
 L  R837    
 L  R838    
 L  R839    
 L  R840    
 L  R841    
 L  R842    
 L  R843    
 L  R844    
 L  R845    
 L  R846    
 L  R847    
 L  R848    
 L  R849    
 L  R850    
 L  R851    
 L  R852    
 L  R853    
 L  R854    
 L  R855    
 L  R856    
 L  R857    
 L  R858    
 L  R859    
 L  R860    
 L  R861    
 L  R862    
 L  R863    
 L  R864    
 L  R865    
 L  R866    
 L  R867    
 L  R868    
 L  R869    
 L  R870    
 L  R871    
 L  R872    
 L  R873    
 L  R874    
 L  R875    
 L  R876    
 L  R877    
 L  R878    
 L  R879    
 L  R880    
 L  R881    
 L  R882    
 L  R883    
 L  R884    
 L  R885    
 L  R886    
 L  R887    
 L  R888    
 L  R889    
 L  R890    
 L  R891    
 L  R892    
 L  R893    
 L  R894    
 L  R895    
 L  R896    
 L  R897    
 L  R898    
 L  R899    
 L  R900    
 L  R901    
 L  R902    
 L  R903    
 L  R904    
 L  R905    
 L  R906    
 L  R907    
 L  R908    
 L  R909    
 L  R910    
 L  R911    
 L  R912    
 L  R913    
 L  R914    
 L  R915    
 L  R916    
 L  R917    
 L  R918    
 L  R919    
 L  R920    
 L  R921    
 L  R922    
 L  R923    
 L  R924    
 L  R925    
 L  R926    
 L  R927    
 L  R928    
 L  R929    
 L  R930    
 L  R931    
 L  R932    
 L  R933    
 L  R934    
 L  R935    
 L  R936    
 L  R937    
 L  R938    
 L  R939    
 L  R940    
 L  R941    
 L  R942    
 L  R943    
 L  R944    
 L  R945    
 L  R946    
 L  R947    
 L  R948    
 L  R949    
 L  R950    
 L  R951    
 L  R952    
 L  R953    
 L  R954    
 L  R955    
 L  R956    
 L  R957    
 L  R958    
 L  R959    
 L  R960    
 L  R961    
 L  R962    
 L  R963    
 L  R964    
 L  R965    
 L  R966    
 L  R967    
 L  R968    
 L  R969    
 L  R970    
 L  R971    
 L  R972    
 L  R973    
 L  R974    
 L  R975    
 L  R976    
 L  R977    
 L  R978    
 L  R979    
 L  R980    
 L  R981    
 L  R982    
 L  R983    
 L  R984    
 L  R985    
 L  R986    
 L  R987    
 L  R988    
 L  R989    
 L  R990    
 L  R991    
 L  R992    
 L  R993    
 L  R994    
 L  R995    
 L  R996    
 L  R997    
 L  R998    
 L  R999    
 L  R1000   
 L  R1001   
 L  R1002   
 L  R1003   
 L  R1004   
 L  R1005   
 L  R1006   
 L  R1007   
 L  R1008   
 L  R1009   
 L  R1010   
 L  R1011   
 L  R1012   
 L  R1013   
 L  R1014   
 L  R1015   
 L  R1016   
 L  R1017   
 L  R1018   
 L  R1019   
 L  R1020   
 L  R1021   
 L  R1022   
 L  R1023   
 L  R1024   
 L  R1025   
 L  R1026   
 L  R1027   
 L  R1028   
 L  R1029   
 L  R1030   
 L  R1031   
 L  R1032   
 L  R1033   
 L  R1034   
 L  R1035   
 L  R1036   
 L  R1037   
 L  R1038   
 L  R1039   
 L  R1040   
 L  R1041   
 L  R1042   
 L  R1043   
 L  R1044   
 L  R1045   
 L  R1046   
 L  R1047   
 L  R1048   
 L  R1049   
 L  R1050   
 L  R1051   
 L  R1052   
 L  R1053   
 L  R1054   
 L  R1055   
 L  R1056   
 L  R1057   
 L  R1058   
 L  R1059   
 L  R1060   
 L  R1061   
 L  R1062   
 L  R1063   
 L  R1064   
 L  R1065   
 L  R1066   
 L  R1067   
 L  R1068   
 L  R1069   
 L  R1070   
 L  R1071   
 L  R1072   
 L  R1073   
 L  R1074   
 L  R1075   
 L  R1076   
 L  R1077   
 L  R1078   
 L  R1079   
 L  R1080   
 L  R1081   
 L  R1082   
 L  R1083   
 L  R1084   
 L  R1085   
 L  R1086   
 L  R1087   
 L  R1088   
 L  R1089   
 L  R1090   
 L  R1091   
 L  R1092   
 L  R1093   
 L  R1094   
 L  R1095   
 L  R1096   
 L  R1097   
 L  R1098   
 L  R1099   
 L  R1100   
 L  R1101   
 L  R1102   
 L  R1103   
 L  R1104   
 L  R1105   
 L  R1106   
 L  R1107   
 L  R1108   
 L  R1109   
 L  R1110   
 L  R1111   
 L  R1112   
 L  R1113   
 L  R1114   
 L  R1115   
 L  R1116   
 L  R1117   
 L  R1118   
 L  R1119   
 L  R1120   
 L  R1121   
 L  R1122   
 L  R1123   
 L  R1124   
 L  R1125   
 L  R1126   
 L  R1127   
 L  R1128   
 L  R1129   
 L  R1130   
 L  R1131   
 L  R1132   
 L  R1133   
 L  R1134   
 L  R1135   
 L  R1136   
 L  R1137   
 L  R1138   
 L  R1139   
 L  R1140   
 L  R1141   
 L  R1142   
 L  R1143   
 L  R1144   
 L  R1145   
 L  R1146   
 L  R1147   
 L  R1148   
 L  R1149   
 L  R1150   
 L  R1151   
 L  R1152   
 L  R1153   
 L  R1154   
 L  R1155   
 L  R1156   
 L  R1157   
 L  R1158   
 L  R1159   
 L  R1160   
 L  R1161   
 L  R1162   
 L  R1163   
 L  R1164   
 L  R1165   
 L  R1166   
 L  R1167   
 L  R1168   
 L  R1169   
 L  R1170   
 L  R1171   
 L  R1172   
 L  R1173   
 L  R1174   
 L  R1175   
 L  R1176   
 L  R1177   
 L  R1178   
 L  R1179   
 L  R1180   
 L  R1181   
 L  R1182   
 L  R1183   
 L  R1184   
 L  R1185   
 L  R1186   
 L  R1187   
 L  R1188   
 L  R1189   
 L  R1190   
 L  R1191   
 L  R1192   
 L  R1193   
 L  R1194   
 L  R1195   
 L  R1196   
 L  R1197   
 L  R1198   
 L  R1199   
 L  R1200   
 L  R1201   
 L  R1202   
 L  R1203   
 L  R1204   
 L  R1205   
 L  R1206   
 L  R1207   
 L  R1208   
 L  R1209   
 L  R1210   
 L  R1211   
 L  R1212   
 L  R1213   
 L  R1214   
 L  R1215   
 L  R1216   
 L  R1217   
 L  R1218   
 L  R1219   
 L  R1220   
 L  R1221   
 L  R1222   
 L  R1223   
 L  R1224   
 L  R1225   
 L  R1226   
 L  R1227   
 L  R1228   
 L  R1229   
 L  R1230   
 L  R1231   
 L  R1232   
 L  R1233   
 L  R1234   
 L  R1235   
 L  R1236   
 L  R1237   
 L  R1238   
 L  R1239   
 L  R1240   
 L  R1241   
 L  R1242   
 L  R1243   
 L  R1244   
 L  R1245   
 L  R1246   
 L  R1247   
 L  R1248   
 L  R1249   
 L  R1250   
 L  R1251   
 L  R1252   
 L  R1253   
 L  R1254   
 L  R1255   
 L  R1256   
 L  R1257   
 L  R1258   
 L  R1259   
 L  R1260   
 L  R1261   
 L  R1262   
 L  R1263   
 L  R1264   
 L  R1265   
 L  R1266   
 L  R1267   
 L  R1268   
 L  R1269   
 L  R1270   
 L  R1271   
 L  R1272   
 L  R1273   
 L  R1274   
 L  R1275   
 L  R1276   
 L  R1277   
 L  R1278   
 L  R1279   
 L  R1280   
 L  R1281   
 L  R1282   
 L  R1283   
 L  R1284   
 L  R1285   
 L  R1286   
 L  R1287   
 L  R1288   
 L  R1289   
 L  R1290   
 L  R1291   
 L  R1292   
 L  R1293   
 L  R1294   
 L  R1295   
 L  R1296   
 L  R1297   
 L  R1298   
 L  R1299   
 L  R1300   
 L  R1301   
 L  R1302   
 L  R1303   
 L  R1304   
 L  R1305   
 L  R1306   
 L  R1307   
 L  R1308   
 L  R1309   
 L  R1310   
 L  R1311   
 L  R1312   
 L  R1313   
 L  R1314   
 L  R1315   
 L  R1316   
 L  R1317   
 L  R1318   
 L  R1319   
 L  R1320   
 L  R1321   
 L  R1322   
 L  R1323   
 L  R1324   
 L  R1325   
 L  R1326   
 L  R1327   
 L  R1328   
 L  R1329   
 L  R1330   
 L  R1331   
 L  R1332   
 L  R1333   
 L  R1334   
 L  R1335   
 L  R1336   
 L  R1337   
 L  R1338   
 L  R1339   
 L  R1340   
 L  R1341   
 L  R1342   
 L  R1343   
 L  R1344   
 L  R1345   
 L  R1346   
 L  R1347   
 L  R1348   
 L  R1349   
 L  R1350   
 L  R1351   
 L  R1352   
 L  R1353   
 L  R1354   
 L  R1355   
 L  R1356   
 L  R1357   
 L  R1358   
 L  R1359   
 L  R1360   
 L  R1361   
 L  R1362   
 L  R1363   
 L  R1364   
 L  R1365   
 L  R1366   
 L  R1367   
 L  R1368   
 L  R1369   
 L  R1370   
 L  R1371   
 L  R1372   
 L  R1373   
 L  R1374   
 L  R1375   
 L  R1376   
 L  R1377   
 L  R1378   
 L  R1379   
 L  R1380   
 L  R1381   
 L  R1382   
 L  R1383   
 L  R1384   
 L  R1385   
 L  R1386   
 L  R1387   
 L  R1388   
 L  R1389   
 L  R1390   
 L  R1391   
 L  R1392   
 L  R1393   
 L  R1394   
 L  R1395   
 L  R1396   
 L  R1397   
 L  R1398   
 L  R1399   
 L  R1400   
 L  R1401   
 L  R1402   
 L  R1403   
 L  R1404   
 L  R1405   
 L  R1406   
 L  R1407   
 L  R1408   
 L  R1409   
 L  R1410   
 L  R1411   
 L  R1412   
 L  R1413   
 L  R1414   
 L  R1415   
 L  R1416   
 L  R1417   
 L  R1418   
 L  R1419   
 L  R1420   
 L  R1421   
 L  R1422   
 L  R1423   
 L  R1424   
 L  R1425   
 L  R1426   
 L  R1427   
 L  R1428   
 L  R1429   
 L  R1430   
 L  R1431   
 L  R1432   
 L  R1433   
 L  R1434   
 L  R1435   
 L  R1436   
 L  R1437   
 L  R1438   
 L  R1439   
 L  R1440   
 L  R1441   
 L  R1442   
 L  R1443   
 L  R1444   
 L  R1445   
 L  R1446   
 L  R1447   
 L  R1448   
 L  R1449   
 L  R1450   
 L  R1451   
 L  R1452   
 L  R1453   
 L  R1454   
 L  R1455   
 L  R1456   
 L  R1457   
 L  R1458   
 L  R1459   
 L  R1460   
 L  R1461   
 L  R1462   
 L  R1463   
 L  R1464   
 L  R1465   
 L  R1466   
 L  R1467   
 L  R1468   
 L  R1469   
 L  R1470   
 L  R1471   
 L  R1472   
 L  R1473   
 L  R1474   
 L  R1475   
 L  R1476   
 L  R1477   
 L  R1478   
 L  R1479   
 L  R1480   
 L  R1481   
 L  R1482   
 L  R1483   
 L  R1484   
 L  R1485   
 L  R1486   
 L  R1487   
 L  R1488   
 L  R1489   
 L  R1490   
 L  R1491   
 L  R1492   
 L  R1493   
 L  R1494   
 L  R1495   
 L  R1496   
 L  R1497   
 L  R1498   
 L  R1499   
 L  R1500   
 L  R1501   
 L  R1502   
 L  R1503   
 L  R1504   
 L  R1505   
 L  R1506   
 L  R1507   
 L  R1508   
 L  R1509   
 L  R1510   
 L  R1511   
 L  R1512   
 L  R1513   
 L  R1514   
 L  R1515   
 L  R1516   
 L  R1517   
 L  R1518   
 L  R1519   
 L  R1520   
 L  R1521   
 L  R1522   
 L  R1523   
 L  R1524   
 L  R1525   
 L  R1526   
 L  R1527   
 L  R1528   
 L  R1529   
 L  R1530   
 L  R1531   
 L  R1532   
 L  R1533   
 L  R1534   
 L  R1535   
 L  R1536   
 L  R1537   
 L  R1538   
 L  R1539   
 L  R1540   
 L  R1541   
 L  R1542   
 L  R1543   
 L  R1544   
 L  R1545   
 L  R1546   
 L  R1547   
 L  R1548   
 L  R1549   
 L  R1550   
 L  R1551   
 L  R1552   
 L  R1553   
 L  R1554   
 L  R1555   
 L  R1556   
 L  R1557   
 L  R1558   
 L  R1559   
 L  R1560   
 L  R1561   
 L  R1562   
 L  R1563   
 L  R1564   
 L  R1565   
 L  R1566   
 L  R1567   
 L  R1568   
 L  R1569   
 L  R1570   
 L  R1571   
 L  R1572   
 L  R1573   
 L  R1574   
 L  R1575   
 L  R1576   
 L  R1577   
 L  R1578   
 L  R1579   
 L  R1580   
 L  R1581   
 L  R1582   
 L  R1583   
 L  R1584   
 L  R1585   
 L  R1586   
 L  R1587   
 L  R1588   
 L  R1589   
 L  R1590   
 L  R1591   
 L  R1592   
 L  R1593   
 L  R1594   
 L  R1595   
 L  R1596   
 L  R1597   
 L  R1598   
 L  R1599   
 L  R1600   
 L  R1601   
 L  R1602   
 L  R1603   
 L  R1604   
 L  R1605   
 L  R1606   
 L  R1607   
 L  R1608   
 L  R1609   
 L  R1610   
 L  R1611   
 L  R1612   
 L  R1613   
 L  R1614   
 L  R1615   
 L  R1616   
 L  R1617   
 L  R1618   
 L  R1619   
 L  R1620   
 L  R1621   
 L  R1622   
 L  R1623   
 L  R1624   
 L  R1625   
 L  R1626   
 L  R1627   
 L  R1628   
 L  R1629   
 L  R1630   
 L  R1631   
 L  R1632   
 L  R1633   
 L  R1634   
 L  R1635   
 L  R1636   
 L  R1637   
 L  R1638   
 L  R1639   
 L  R1640   
 L  R1641   
 L  R1642   
 L  R1643   
 L  R1644   
 L  R1645   
 L  R1646   
 L  R1647   
 L  R1648   
 L  R1649   
 L  R1650   
 L  R1651   
 L  R1652   
 L  R1653   
 L  R1654   
 L  R1655   
 L  R1656   
 L  R1657   
 L  R1658   
 L  R1659   
 L  R1660   
 L  R1661   
 L  R1662   
 L  R1663   
 L  R1664   
 L  R1665   
 L  R1666   
 L  R1667   
 L  R1668   
 L  R1669   
 L  R1670   
 L  R1671   
 L  R1672   
 L  R1673   
 L  R1674   
 L  R1675   
 L  R1676   
 L  R1677   
 L  R1678   
 L  R1679   
 L  R1680   
 L  R1681   
 L  R1682   
 L  R1683   
 L  R1684   
 L  R1685   
 L  R1686   
 L  R1687   
 L  R1688   
 L  R1689   
 L  R1690   
 L  R1691   
 L  R1692   
 L  R1693   
 L  R1694   
 L  R1695   
 L  R1696   
 L  R1697   
 L  R1698   
 L  R1699   
 L  R1700   
 L  R1701   
 L  R1702   
 L  R1703   
 L  R1704   
 L  R1705   
 L  R1706   
 L  R1707   
 L  R1708   
 L  R1709   
 L  R1710   
 L  R1711   
 L  R1712   
 L  R1713   
 L  R1714   
 L  R1715   
 L  R1716   
 L  R1717   
 L  R1718   
 L  R1719   
 L  R1720   
 L  R1721   
 L  R1722   
 L  R1723   
 L  R1724   
 L  R1725   
 L  R1726   
 L  R1727   
 L  R1728   
 L  R1729   
 L  R1730   
 L  R1731   
 L  R1732   
 L  R1733   
 L  R1734   
 L  R1735   
 L  R1736   
 L  R1737   
 L  R1738   
 L  R1739   
 L  R1740   
 L  R1741   
 L  R1742   
 L  R1743   
 L  R1744   
 L  R1745   
 L  R1746   
 L  R1747   
 L  R1748   
 L  R1749   
 L  R1750   
 L  R1751   
 L  R1752   
 L  R1753   
 L  R1754   
 L  R1755   
 L  R1756   
 L  R1757   
 L  R1758   
 L  R1759   
 L  R1760   
 L  R1761   
 L  R1762   
 L  R1763   
 L  R1764   
 L  R1765   
 L  R1766   
 L  R1767   
 L  R1768   
 L  R1769   
 L  R1770   
 L  R1771   
 L  R1772   
 L  R1773   
 L  R1774   
 L  R1775   
 L  R1776   
 L  R1777   
 L  R1778   
 L  R1779   
 L  R1780   
 L  R1781   
 L  R1782   
 L  R1783   
 L  R1784   
 L  R1785   
 L  R1786   
 L  R1787   
 L  R1788   
 L  R1789   
 L  R1790   
 L  R1791   
 L  R1792   
 L  R1793   
 L  R1794   
 L  R1795   
 L  R1796   
 L  R1797   
 L  R1798   
 L  R1799   
 L  R1800   
 L  R1801   
 L  R1802   
 L  R1803   
 L  R1804   
 L  R1805   
 L  R1806   
 L  R1807   
 L  R1808   
 L  R1809   
 L  R1810   
 L  R1811   
 L  R1812   
 L  R1813   
 L  R1814   
 L  R1815   
 L  R1816   
 L  R1817   
 L  R1818   
 L  R1819   
 L  R1820   
 L  R1821   
 L  R1822   
 L  R1823   
 L  R1824   
 L  R1825   
 L  R1826   
 L  R1827   
 L  R1828   
 L  R1829   
 L  R1830   
 L  R1831   
 L  R1832   
 L  R1833   
 L  R1834   
 L  R1835   
 L  R1836   
 L  R1837   
 L  R1838   
 L  R1839   
 L  R1840   
 L  R1841   
 L  R1842   
 L  R1843   
 L  R1844   
 L  R1845   
 L  R1846   
 L  R1847   
 L  R1848   
 L  R1849   
 L  R1850   
 L  R1851   
 L  R1852   
 L  R1853   
 L  R1854   
 L  R1855   
 L  R1856   
 L  R1857   
 L  R1858   
 L  R1859   
 L  R1860   
 L  R1861   
 L  R1862   
 L  R1863   
 L  R1864   
 L  R1865   
 L  R1866   
 L  R1867   
 L  R1868   
 L  R1869   
 L  R1870   
 L  R1871   
 L  R1872   
 L  R1873   
 L  R1874   
 L  R1875   
 L  R1876   
 L  R1877   
 L  R1878   
 L  R1879   
 L  R1880   
 L  R1881   
 L  R1882   
 L  R1883   
 L  R1884   
 L  R1885   
 L  R1886   
 L  R1887   
 L  R1888   
 L  R1889   
 L  R1890   
 L  R1891   
 L  R1892   
 L  R1893   
 L  R1894   
 L  R1895   
 L  R1896   
 L  R1897   
 L  R1898   
 L  R1899   
 L  R1900   
 L  R1901   
 L  R1902   
 L  R1903   
 L  R1904   
 L  R1905   
 L  R1906   
 L  R1907   
 L  R1908   
 L  R1909   
 L  R1910   
 L  R1911   
 L  R1912   
 L  R1913   
 L  R1914   
 L  R1915   
 L  R1916   
 L  R1917   
 L  R1918   
 L  R1919   
 L  R1920   
 L  R1921   
 L  R1922   
 L  R1923   
 L  R1924   
 L  R1925   
 L  R1926   
 L  R1927   
 L  R1928   
 L  R1929   
 L  R1930   
 L  R1931   
 L  R1932   
 L  R1933   
 L  R1934   
 L  R1935   
 L  R1936   
 L  R1937   
 L  R1938   
 L  R1939   
 L  R1940   
 L  R1941   
 L  R1942   
 L  R1943   
 L  R1944   
 L  R1945   
 L  R1946   
 L  R1947   
 L  R1948   
 L  R1949   
 L  R1950   
 L  R1951   
 L  R1952   
 L  R1953   
 L  R1954   
 L  R1955   
 L  R1956   
 L  R1957   
 L  R1958   
 L  R1959   
 L  R1960   
 L  R1961   
 L  R1962   
 L  R1963   
 L  R1964   
 L  R1965   
 L  R1966   
 L  R1967   
 L  R1968   
 L  R1969   
 L  R1970   
 L  R1971   
 L  R1972   
 L  R1973   
 L  R1974   
 L  R1975   
 L  R1976   
 L  R1977   
 L  R1978   
 L  R1979   
 L  R1980   
 L  R1981   
 L  R1982   
 L  R1983   
 L  R1984   
 L  R1985   
 L  R1986   
 L  R1987   
 L  R1988   
 L  R1989   
 L  R1990   
 L  R1991   
 L  R1992   
 L  R1993   
 L  R1994   
 L  R1995   
 L  R1996   
 L  R1997   
 L  R1998   
 L  R1999   
 L  R2000   
 L  R2001   
 L  R2002   
 L  R2003   
 L  R2004   
 L  R2005   
 L  R2006   
 L  R2007   
 L  R2008   
 L  R2009   
 L  R2010   
 L  R2011   
 L  R2012   
 L  R2013   
 L  R2014   
 L  R2015   
 L  R2016   
 L  R2017   
 L  R2018   
 L  R2019   
 L  R2020   
 L  R2021   
 L  R2022   
 L  R2023   
 L  R2024   
 L  R2025   
 L  R2026   
 L  R2027   
 L  R2028   
 L  R2029   
 L  R2030   
 L  R2031   
 L  R2032   
 L  R2033   
 L  R2034   
 L  R2035   
 L  R2036   
 L  R2037   
 L  R2038   
 L  R2039   
 L  R2040   
 L  R2041   
 L  R2042   
 L  R2043   
 L  R2044   
 L  R2045   
 L  R2046   
 L  R2047   
 L  R2048   
 L  R2049   
 L  R2050   
 L  R2051   
 L  R2052   
 L  R2053   
 L  R2054   
 L  R2055   
 L  R2056   
 L  R2057   
 L  R2058   
 L  R2059   
 L  R2060   
 L  R2061   
 L  R2062   
 L  R2063   
 L  R2064   
 L  R2065   
 L  R2066   
 L  R2067   
 L  R2068   
 L  R2069   
 L  R2070   
 L  R2071   
 L  R2072   
 L  R2073   
 L  R2074   
 L  R2075   
 L  R2076   
 L  R2077   
 L  R2078   
 L  R2079   
 L  R2080   
 L  R2081   
 L  R2082   
 L  R2083   
 L  R2084   
 L  R2085   
 L  R2086   
 L  R2087   
 L  R2088   
 L  R2089   
 L  R2090   
 L  R2091   
 L  R2092   
 L  R2093   
 L  R2094   
 L  R2095   
 L  R2096   
 L  R2097   
 L  R2098   
 L  R2099   
 L  R2100   
 L  R2101   
 L  R2102   
 L  R2103   
 L  R2104   
 L  R2105   
 L  R2106   
 L  R2107   
 L  R2108   
 L  R2109   
 L  R2110   
 L  R2111   
 L  R2112   
 L  R2113   
 L  R2114   
 L  R2115   
 L  R2116   
 L  R2117   
 L  R2118   
 L  R2119   
 L  R2120   
 L  R2121   
 L  R2122   
 L  R2123   
 L  R2124   
 L  R2125   
 L  R2126   
 L  R2127   
 L  R2128   
 L  R2129   
 L  R2130   
 L  R2131   
 L  R2132   
 L  R2133   
 L  R2134   
 L  R2135   
 L  R2136   
 L  R2137   
 L  R2138   
 L  R2139   
 L  R2140   
 L  R2141   
 L  R2142   
 L  R2143   
 L  R2144   
 L  R2145   
 L  R2146   
 L  R2147   
 L  R2148   
 L  R2149   
 L  R2150   
 L  R2151   
 L  R2152   
 L  R2153   
 L  R2154   
 L  R2155   
 L  R2156   
 L  R2157   
 L  R2158   
 L  R2159   
 L  R2160   
 L  R2161   
 L  R2162   
 L  R2163   
 L  R2164   
 L  R2165   
 L  R2166   
 L  R2167   
 L  R2168   
 L  R2169   
 L  R2170   
 L  R2171   
 L  R2172   
 L  R2173   
 L  R2174   
 L  R2175   
 L  R2176   
 L  R2177   
 L  R2178   
 L  R2179   
 L  R2180   
 L  R2181   
 L  R2182   
 L  R2183   
 L  R2184   
 L  R2185   
 L  R2186   
 L  R2187   
 L  R2188   
 L  R2189   
 L  R2190   
 L  R2191   
 L  R2192   
 L  R2193   
 L  R2194   
 L  R2195   
 L  R2196   
 L  R2197   
 L  R2198   
 L  R2199   
 L  R2200   
 L  R2201   
 L  R2202   
 L  R2203   
 L  R2204   
 L  R2205   
 L  R2206   
 L  R2207   
 L  R2208   
 L  R2209   
 L  R2210   
 L  R2211   
 L  R2212   
 L  R2213   
 L  R2214   
 L  R2215   
 L  R2216   
 L  R2217   
 L  R2218   
 L  R2219   
 L  R2220   
 L  R2221   
 L  R2222   
 L  R2223   
 L  R2224   
 L  R2225   
 L  R2226   
 L  R2227   
 L  R2228   
 L  R2229   
 L  R2230   
 L  R2231   
 L  R2232   
 L  R2233   
 L  R2234   
 L  R2235   
 L  R2236   
 L  R2237   
 L  R2238   
 L  R2239   
 L  R2240   
 L  R2241   
 L  R2242   
 L  R2243   
 L  R2244   
 L  R2245   
 L  R2246   
 L  R2247   
 L  R2248   
 L  R2249   
 L  R2250   
 L  R2251   
 L  R2252   
 L  R2253   
 L  R2254   
 L  R2255   
 L  R2256   
 L  R2257   
 L  R2258   
 L  R2259   
 L  R2260   
 L  R2261   
 L  R2262   
 L  R2263   
 L  R2264   
 L  R2265   
 L  R2266   
 L  R2267   
 L  R2268   
 L  R2269   
 L  R2270   
 L  R2271   
 L  R2272   
 L  R2273   
 L  R2274   
 L  R2275   
 L  R2276   
 L  R2277   
 L  R2278   
 L  R2279   
 L  R2280   
 L  R2281   
 L  R2282   
 L  R2283   
 L  R2284   
 L  R2285   
 L  R2286   
 L  R2287   
 L  R2288   
 L  R2289   
 L  R2290   
 L  R2291   
 L  R2292   
 L  R2293   
 L  R2294   
 L  R2295   
 L  R2296   
 L  R2297   
 L  R2298   
 L  R2299   
 L  R2300   
 L  R2301   
 L  R2302   
 L  R2303   
 L  R2304   
 L  R2305   
 L  R2306   
 L  R2307   
 L  R2308   
 L  R2309   
 L  R2310   
 L  R2311   
 L  R2312   
 L  R2313   
 L  R2314   
 L  R2315   
 L  R2316   
 L  R2317   
 L  R2318   
 L  R2319   
 L  R2320   
 L  R2321   
 L  R2322   
 L  R2323   
 L  R2324   
 L  R2325   
 L  R2326   
 L  R2327   
 L  R2328   
 L  R2329   
 L  R2330   
 L  R2331   
 L  R2332   
 L  R2333   
 L  R2334   
 L  R2335   
 L  R2336   
 L  R2337   
 L  R2338   
 L  R2339   
 L  R2340   
 L  R2341   
 L  R2342   
 L  R2343   
 L  R2344   
 L  R2345   
 L  R2346   
 L  R2347   
 L  R2348   
 L  R2349   
 L  R2350   
 L  R2351   
 L  R2352   
 L  R2353   
 L  R2354   
 L  R2355   
 L  R2356   
 L  R2357   
 L  R2358   
 L  R2359   
 L  R2360   
 L  R2361   
 L  R2362   
 L  R2363   
 L  R2364   
 L  R2365   
 L  R2366   
 L  R2367   
 L  R2368   
 L  R2369   
 L  R2370   
 L  R2371   
 L  R2372   
 L  R2373   
 L  R2374   
 L  R2375   
 L  R2376   
 L  R2377   
 L  R2378   
 L  R2379   
 L  R2380   
 L  R2381   
 L  R2382   
 L  R2383   
 L  R2384   
 L  R2385   
 L  R2386   
 L  R2387   
 L  R2388   
 L  R2389   
 L  R2390   
 L  R2391   
 L  R2392   
 L  R2393   
 L  R2394   
 L  R2395   
 L  R2396   
 L  R2397   
 L  R2398   
 L  R2399   
 L  R2400   
 L  R2401   
 L  R2402   
 L  R2403   
 L  R2404   
 L  R2405   
 L  R2406   
 L  R2407   
 L  R2408   
 L  R2409   
 L  R2410   
 L  R2411   
 L  R2412   
 L  R2413   
 L  R2414   
 L  R2415   
 L  R2416   
 L  R2417   
 L  R2418   
 L  R2419   
 L  R2420   
 L  R2421   
 L  R2422   
 L  R2423   
 L  R2424   
 L  R2425   
 L  R2426   
 L  R2427   
 L  R2428   
 L  R2429   
 L  R2430   
 L  R2431   
 L  R2432   
 L  R2433   
 L  R2434   
 L  R2435   
 L  R2436   
 L  R2437   
 L  R2438   
 L  R2439   
 L  R2440   
 L  R2441   
 L  R2442   
 L  R2443   
 L  R2444   
 L  R2445   
 L  R2446   
 L  R2447   
 L  R2448   
 L  R2449   
 L  R2450   
 L  R2451   
 L  R2452   
 L  R2453   
 L  R2454   
 L  R2455   
 L  R2456   
 L  R2457   
 L  R2458   
 L  R2459   
 L  R2460   
 L  R2461   
 L  R2462   
 L  R2463   
 L  R2464   
 L  R2465   
 L  R2466   
 L  R2467   
 L  R2468   
 L  R2469   
 L  R2470   
 L  R2471   
 L  R2472   
 L  R2473   
 L  R2474   
 L  R2475   
 L  R2476   
 L  R2477   
 L  R2478   
 L  R2479   
 L  R2480   
 L  R2481   
 L  R2482   
 L  R2483   
 L  R2484   
 L  R2485   
 L  R2486   
 L  R2487   
 L  R2488   
 L  R2489   
 L  R2490   
 L  R2491   
 L  R2492   
 L  R2493   
 L  R2494   
 L  R2495   
 L  R2496   
 L  R2497   
 L  R2498   
 L  R2499   
 L  R2500   
 L  R2501   
 L  R2502   
 L  R2503   
 L  R2504   
 L  R2505   
 L  R2506   
 L  R2507   
 L  R2508   
 L  R2509   
 L  R2510   
 L  R2511   
 L  R2512   
 L  R2513   
 L  R2514   
 L  R2515   
 L  R2516   
 L  R2517   
 L  R2518   
 L  R2519   
 L  R2520   
 L  R2521   
 L  R2522   
 L  R2523   
 L  R2524   
 L  R2525   
 L  R2526   
 L  R2527   
 L  R2528   
 L  R2529   
 L  R2530   
 L  R2531   
 L  R2532   
 L  R2533   
 L  R2534   
 L  R2535   
 L  R2536   
 L  R2537   
 L  R2538   
 L  R2539   
 L  R2540   
 L  R2541   
 L  R2542   
 L  R2543   
 L  R2544   
 L  R2545   
 L  R2546   
 L  R2547   
 L  R2548   
 L  R2549   
 L  R2550   
 L  R2551   
 L  R2552   
 L  R2553   
 L  R2554   
 L  R2555   
 L  R2556   
 L  R2557   
 L  R2558   
 L  R2559   
 L  R2560   
 L  R2561   
 L  R2562   
 L  R2563   
 L  R2564   
 L  R2565   
 L  R2566   
 L  R2567   
 L  R2568   
 L  R2569   
 L  R2570   
 L  R2571   
 L  R2572   
 L  R2573   
 L  R2574   
 L  R2575   
 L  R2576   
 L  R2577   
 L  R2578   
 L  R2579   
 L  R2580   
 L  R2581   
 L  R2582   
 L  R2583   
 L  R2584   
 L  R2585   
 L  R2586   
 L  R2587   
 L  R2588   
 L  R2589   
 L  R2590   
 L  R2591   
 L  R2592   
 L  R2593   
 L  R2594   
 L  R2595   
 L  R2596   
 L  R2597   
 L  R2598   
 L  R2599   
 L  R2600   
 L  R2601   
 L  R2602   
 L  R2603   
 L  R2604   
 L  R2605   
 L  R2606   
 L  R2607   
 L  R2608   
 L  R2609   
 L  R2610   
 L  R2611   
 L  R2612   
 L  R2613   
 L  R2614   
 L  R2615   
 L  R2616   
 L  R2617   
 L  R2618   
 L  R2619   
 L  R2620   
 L  R2621   
 L  R2622   
 L  R2623   
 L  qc0     
 L  qc1     
 L  qc2     
 L  qc3     
 L  qc4     
 L  qc5     
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    phi[0,1]  R0        1
    phi[0,1]  R1        1
    phi[0,1]  R9        -1
    phi[0,1]  R56       -3.0999999046325684e+00
    phi[0,1]  R57       -3.0999999046325684e+00
    phi[0,1]  R58       -2.2400000095367432e+00
    phi[0,1]  R59       -2.2400000095367432e+00
    phi[0,1]  R60       -3.0999999046325684e+00
    phi[0,1]  R61       -3.0999999046325684e+00
    phi[0,1]  R62       -2.5699999332427979e+00
    phi[0,1]  R63       -2.5699999332427979e+00
    phi[0,1]  R64       -3.0999999046325684e+00
    phi[0,1]  R65       -3.0999999046325684e+00
    phi[0,1]  R66       -2.0899999141693115e+00
    phi[0,1]  R67       -2.0899999141693115e+00
    phi[0,1]  R68       -3.0999999046325684e+00
    phi[0,1]  R69       -3.0999999046325684e+00
    phi[0,1]  R70       -2.6892283558845520e-01
    phi[0,1]  R71       9.4179280102252960e-02
    phi[0,1]  R72       1.1996356397867203e-01
    phi[0,1]  R73       3.1644460558891296e-01
    phi[0,1]  R74       4.7326788306236267e-02
    phi[0,1]  R75       1.0687191039323807e-01
    phi[0,1]  R76       4.3213921785354614e-01
    phi[0,1]  R77       4.0144789218902588e-01
    phi[0,1]  R78       7.8688788414001465e-01
    phi[0,1]  R79       -6.4240795373916626e-01
    phi[0,1]  R80       2.3015065491199493e-01
    phi[0,1]  R81       -1.5868855640292168e-02
    phi[0,1]  R82       -2.7030691504478455e-01
    phi[0,1]  R83       -3.4411042928695679e-01
    phi[0,1]  R84       -6.6079616546630859e-02
    phi[0,1]  R85       -7.2866678237915039e-01
    phi[0,1]  R86       -1.9751334190368652e-01
    phi[0,1]  R87       -2.7590963244438171e-01
    phi[0,1]  R88       -1.0037581920623779e+00
    phi[0,1]  R89       3.5942593216896057e-01
    phi[0,1]  R90       -2.2275438308715820e+00
    phi[0,1]  R91       -3.0821361541748047e+00
    phi[0,1]  R92       -2.4403109550476074e+00
    phi[0,1]  R93       -2.1568632125854492e+00
    phi[0,1]  R94       -2.5912337303161621e+00
    phi[0,1]  R95       -2.6413395404815674e+00
    phi[0,1]  R96       -3.1899554729461670e+00
    phi[0,1]  R97       -2.5282959938049316e+00
    phi[0,1]  R98       -1.8788827657699585e+00
    phi[0,1]  R99       -2.0508601665496826e+00
    phi[0,1]  R100      -8.0012089014053345e-01
    phi[0,1]  R101      -6.0018397867679596e-02
    phi[0,1]  R102      -9.8672497272491455e-01
    phi[0,1]  R103      -2.7835340499877930e+00
    phi[0,1]  R104      -2.8045327663421631e+00
    phi[0,1]  R105      -9.6790528297424316e-01
    phi[0,1]  R106      -1.8067113161087036e+00
    phi[0,1]  R107      -7.7039480209350586e-01
    phi[0,1]  R108      -3.9311339855194092e+00
    phi[0,1]  R109      -3.7480993270874023e+00
    phi[0,1]  R110      -5.3848731517791748e-01
    phi[0,1]  R111      -5.6913875043392181e-02
    phi[0,1]  R112      -4.7335222363471985e-01
    phi[0,1]  R113      -7.0460289716720581e-02
    phi[0,1]  R114      -5.4341918230056763e-01
    phi[0,1]  R115      -2.0838913321495056e-01
    phi[0,1]  R116      -7.7236875891685486e-02
    phi[0,1]  R117      -1.0334223508834839e-01
    phi[0,1]  R118      -9.2117607593536377e-01
    phi[0,1]  R119      -9.6261298656463623e-01
    phi[0,1]  R120      -5.4849022626876831e-01
    phi[0,1]  R121      -4.4594958424568176e-01
    phi[0,1]  R122      5.7942576706409454e-02
    phi[0,1]  R123      -0.422661691904068
    phi[0,1]  R124      -6.2049329280853271e-01
    phi[0,1]  R125      -3.6150512099266052e-01
    phi[0,1]  R126      2.8013634681701660e-01
    phi[0,1]  R127      -3.7358406186103821e-01
    phi[0,1]  R128      -4.0827322006225586e-01
    phi[0,1]  R129      -1.0542370080947876e+00
    phi[0,1]  R130      -7.9945939779281616e-01
    phi[0,1]  R131      -4.1097530722618103e-01
    phi[0,1]  R132      0.0332217663526535
    phi[0,1]  R133      -1.7338870093226433e-02
    phi[0,1]  R134      -1.7940394580364227e-01
    phi[0,1]  R135      -2.0023712515830994e-01
    phi[0,1]  R136      -1.2310332059860229e+00
    phi[0,1]  R137      5.9351670742034912e-01
    phi[0,1]  R138      -6.3431960344314575e-01
    phi[0,1]  R139      -1.1345435380935669e+00
    phi[0,1]  R140      -1.0727311372756958e+00
    phi[0,1]  R141      -1.6438180208206177e-01
    phi[0,1]  R142      -4.7152754664421082e-01
    phi[0,1]  R143      -3.1429141759872437e-01
    phi[0,1]  R144      -2.3560506105422974e-01
    phi[0,1]  R145      -2.7584062889218330e-02
    phi[0,1]  R146      -3.6491242051124573e-01
    phi[0,1]  R147      -9.5044940710067749e-01
    phi[0,1]  R148      -1.2566862106323242e+00
    phi[0,1]  R149      -1.5598497390747070e+00
    phi[1,0]  R0        -1
    phi[1,0]  R9        1
    phi[1,0]  R10       1
    phi[1,0]  R150      -3.0999999046325684e+00
    phi[1,0]  R151      -3.0999999046325684e+00
    phi[1,0]  R152      -2.2400000095367432e+00
    phi[1,0]  R153      -2.2400000095367432e+00
    phi[1,0]  R154      -3.0999999046325684e+00
    phi[1,0]  R155      -3.0999999046325684e+00
    phi[1,0]  R156      -2.5699999332427979e+00
    phi[1,0]  R157      -2.5699999332427979e+00
    phi[1,0]  R158      -3.0999999046325684e+00
    phi[1,0]  R159      -3.0999999046325684e+00
    phi[1,0]  R160      -2.0899999141693115e+00
    phi[1,0]  R161      -2.0899999141693115e+00
    phi[1,0]  R162      -3.0999999046325684e+00
    phi[1,0]  R163      -3.0999999046325684e+00
    phi[1,0]  R164      -5.3848731517791748e-01
    phi[1,0]  R165      -5.6913875043392181e-02
    phi[1,0]  R166      -4.7335222363471985e-01
    phi[1,0]  R167      -7.0460289716720581e-02
    phi[1,0]  R168      -5.4341918230056763e-01
    phi[1,0]  R169      -2.0838913321495056e-01
    phi[1,0]  R170      -7.7236875891685486e-02
    phi[1,0]  R171      -1.0334223508834839e-01
    phi[1,0]  R172      -9.2117607593536377e-01
    phi[1,0]  R173      -9.6261298656463623e-01
    phi[1,0]  R174      -5.4849022626876831e-01
    phi[1,0]  R175      -4.4594958424568176e-01
    phi[1,0]  R176      5.7942576706409454e-02
    phi[1,0]  R177      -0.422661691904068
    phi[1,0]  R178      -6.2049329280853271e-01
    phi[1,0]  R179      -3.6150512099266052e-01
    phi[1,0]  R180      2.8013634681701660e-01
    phi[1,0]  R181      -3.7358406186103821e-01
    phi[1,0]  R182      -4.0827322006225586e-01
    phi[1,0]  R183      -1.0542370080947876e+00
    phi[1,0]  R184      -7.9945939779281616e-01
    phi[1,0]  R185      -4.1097530722618103e-01
    phi[1,0]  R186      0.0332217663526535
    phi[1,0]  R187      -1.7338870093226433e-02
    phi[1,0]  R188      -1.7940394580364227e-01
    phi[1,0]  R189      -2.0023712515830994e-01
    phi[1,0]  R190      -1.2310332059860229e+00
    phi[1,0]  R191      5.9351670742034912e-01
    phi[1,0]  R192      -6.3431960344314575e-01
    phi[1,0]  R193      -1.1345435380935669e+00
    phi[1,0]  R194      -1.0727311372756958e+00
    phi[1,0]  R195      -1.6438180208206177e-01
    phi[1,0]  R196      -4.7152754664421082e-01
    phi[1,0]  R197      -3.1429141759872437e-01
    phi[1,0]  R198      -2.3560506105422974e-01
    phi[1,0]  R199      -2.7584062889218330e-02
    phi[1,0]  R200      -3.6491242051124573e-01
    phi[1,0]  R201      -9.5044940710067749e-01
    phi[1,0]  R202      -1.2566862106323242e+00
    phi[1,0]  R203      -1.5598497390747070e+00
    phi[1,0]  R204      -2.6892283558845520e-01
    phi[1,0]  R205      9.4179280102252960e-02
    phi[1,0]  R206      1.1996356397867203e-01
    phi[1,0]  R207      3.1644460558891296e-01
    phi[1,0]  R208      4.7326788306236267e-02
    phi[1,0]  R209      1.0687191039323807e-01
    phi[1,0]  R210      4.3213921785354614e-01
    phi[1,0]  R211      4.0144789218902588e-01
    phi[1,0]  R212      7.8688788414001465e-01
    phi[1,0]  R213      -6.4240795373916626e-01
    phi[1,0]  R214      2.3015065491199493e-01
    phi[1,0]  R215      -1.5868855640292168e-02
    phi[1,0]  R216      -2.7030691504478455e-01
    phi[1,0]  R217      -3.4411042928695679e-01
    phi[1,0]  R218      -6.6079616546630859e-02
    phi[1,0]  R219      -7.2866678237915039e-01
    phi[1,0]  R220      -1.9751334190368652e-01
    phi[1,0]  R221      -2.7590963244438171e-01
    phi[1,0]  R222      -1.0037581920623779e+00
    phi[1,0]  R223      3.5942593216896057e-01
    phi[1,0]  R224      -2.2275438308715820e+00
    phi[1,0]  R225      -3.0821361541748047e+00
    phi[1,0]  R226      -2.4403109550476074e+00
    phi[1,0]  R227      -2.1568632125854492e+00
    phi[1,0]  R228      -2.5912337303161621e+00
    phi[1,0]  R229      -2.6413395404815674e+00
    phi[1,0]  R230      -3.1899554729461670e+00
    phi[1,0]  R231      -2.5282959938049316e+00
    phi[1,0]  R232      -1.8788827657699585e+00
    phi[1,0]  R233      -2.0508601665496826e+00
    phi[1,0]  R234      -8.0012089014053345e-01
    phi[1,0]  R235      -6.0018397867679596e-02
    phi[1,0]  R236      -9.8672497272491455e-01
    phi[1,0]  R237      -2.7835340499877930e+00
    phi[1,0]  R238      -2.8045327663421631e+00
    phi[1,0]  R239      -9.6790528297424316e-01
    phi[1,0]  R240      -1.8067113161087036e+00
    phi[1,0]  R241      -7.7039480209350586e-01
    phi[1,0]  R242      -3.9311339855194092e+00
    phi[1,0]  R243      -3.7480993270874023e+00
    phi[0,3]  R0        1
    phi[0,3]  R1        1
    phi[0,3]  R27       -1
    phi[0,3]  R244      -3.0999999046325684e+00
    phi[0,3]  R245      -3.0999999046325684e+00
    phi[0,3]  R246      -2.2400000095367432e+00
    phi[0,3]  R247      -2.2400000095367432e+00
    phi[0,3]  R248      -3.0999999046325684e+00
    phi[0,3]  R249      -3.0999999046325684e+00
    phi[0,3]  R250      -2.5699999332427979e+00
    phi[0,3]  R251      -2.5699999332427979e+00
    phi[0,3]  R252      -3.0999999046325684e+00
    phi[0,3]  R253      -3.0999999046325684e+00
    phi[0,3]  R254      -2.0899999141693115e+00
    phi[0,3]  R255      -2.0899999141693115e+00
    phi[0,3]  R256      -3.0999999046325684e+00
    phi[0,3]  R257      -3.0999999046325684e+00
    phi[0,3]  R258      -2.6892283558845520e-01
    phi[0,3]  R259      9.4179280102252960e-02
    phi[0,3]  R260      1.1996356397867203e-01
    phi[0,3]  R261      3.1644460558891296e-01
    phi[0,3]  R262      4.7326788306236267e-02
    phi[0,3]  R263      1.0687191039323807e-01
    phi[0,3]  R264      4.3213921785354614e-01
    phi[0,3]  R265      4.0144789218902588e-01
    phi[0,3]  R266      7.8688788414001465e-01
    phi[0,3]  R267      -6.4240795373916626e-01
    phi[0,3]  R268      2.3015065491199493e-01
    phi[0,3]  R269      -1.5868855640292168e-02
    phi[0,3]  R270      -2.7030691504478455e-01
    phi[0,3]  R271      -3.4411042928695679e-01
    phi[0,3]  R272      -6.6079616546630859e-02
    phi[0,3]  R273      -7.2866678237915039e-01
    phi[0,3]  R274      -1.9751334190368652e-01
    phi[0,3]  R275      -2.7590963244438171e-01
    phi[0,3]  R276      -1.0037581920623779e+00
    phi[0,3]  R277      3.5942593216896057e-01
    phi[0,3]  R278      -2.2275438308715820e+00
    phi[0,3]  R279      -3.0821361541748047e+00
    phi[0,3]  R280      -2.4403109550476074e+00
    phi[0,3]  R281      -2.1568632125854492e+00
    phi[0,3]  R282      -2.5912337303161621e+00
    phi[0,3]  R283      -2.6413395404815674e+00
    phi[0,3]  R284      -3.1899554729461670e+00
    phi[0,3]  R285      -2.5282959938049316e+00
    phi[0,3]  R286      -1.8788827657699585e+00
    phi[0,3]  R287      -2.0508601665496826e+00
    phi[0,3]  R288      -8.0012089014053345e-01
    phi[0,3]  R289      -6.0018397867679596e-02
    phi[0,3]  R290      -9.8672497272491455e-01
    phi[0,3]  R291      -2.7835340499877930e+00
    phi[0,3]  R292      -2.8045327663421631e+00
    phi[0,3]  R293      -9.6790528297424316e-01
    phi[0,3]  R294      -1.8067113161087036e+00
    phi[0,3]  R295      -7.7039480209350586e-01
    phi[0,3]  R296      -3.9311339855194092e+00
    phi[0,3]  R297      -3.7480993270874023e+00
    phi[0,3]  R298      7.4696838855743408e-01
    phi[0,3]  R299      5.9032940864562988e-01
    phi[0,3]  R300      1.2659519910812378e+00
    phi[0,3]  R301      1.8894494771957397e+00
    phi[0,3]  R302      3.6784321069717407e-01
    phi[0,3]  R303      -6.1327069997787476e-02
    phi[0,3]  R304      -3.8263463973999023e-01
    phi[0,3]  R305      4.9458020925521851e-01
    phi[0,3]  R306      -6.2288695573806763e-01
    phi[0,3]  R307      5.6835895776748657e-01
    phi[0,3]  R308      -2.6482255458831787e+00
    phi[0,3]  R309      2.6964244246482849e-01
    phi[0,3]  R310      8.2052677869796753e-02
    phi[0,3]  R311      1.2029384076595306e-01
    phi[0,3]  R312      -5.9737324714660645e-01
    phi[0,3]  R313      -0.561819314956665
    phi[0,3]  R314      -1.0686492174863815e-01
    phi[0,3]  R315      1.2331368923187256e+00
    phi[0,3]  R316      8.4604567289352417e-01
    phi[0,3]  R317      2.4319463968276978e-01
    phi[0,3]  R318      -3.3971695899963379e+00
    phi[0,3]  R319      -2.1615834236145020e+00
    phi[0,3]  R320      -6.9311982393264771e-01
    phi[0,3]  R321      -3.1848275661468506e+00
    phi[0,3]  R322      -3.0147583484649658e+00
    phi[0,3]  R323      -2.1126053333282471e+00
    phi[0,3]  R324      -1.6379393339157104e+00
    phi[0,3]  R325      -2.0082266330718994e+00
    phi[0,3]  R326      -1.2475862503051758e+00
    phi[0,3]  R327      -3.0648466944694519e-01
    phi[0,3]  R328      -0.82502281665802
    phi[0,3]  R329      -2.7735455036163330e+00
    phi[0,3]  R330      -3.0565261840820312e+00
    phi[0,3]  R331      -3.1282525062561035e+00
    phi[0,3]  R332      -2.9937264919281006e+00
    phi[0,3]  R333      -1.2714358568191528e+00
    phi[0,3]  R334      -7.7594143152236938e-01
    phi[0,3]  R335      -1.3108272552490234e+00
    phi[0,3]  R336      -1.5030174255371094e+00
    phi[0,3]  R337      -2.5247743129730225e+00
    phi[0,3]  R338      -2.2561569213867188e+00
    phi[0,3]  R339      -1.5610722303390503e+00
    phi[0,3]  R340      -1.6261727809906006e+00
    phi[0,3]  R341      -2.4040496349334717e+00
    phi[0,3]  R342      -8.6141097545623779e-01
    phi[0,3]  R343      -9.9069011211395264e-01
    phi[0,3]  R344      -3.8015681505203247e-01
    phi[0,3]  R345      -5.7802206277847290e-01
    phi[0,3]  R346      -2.8298065662384033e+00
    phi[0,3]  R347      -5.2950870990753174e-01
    phi[0,3]  R348      -1.1166453361511230e+00
    phi[0,3]  R349      -1.6335239410400391e+00
    phi[0,3]  R350      -2.5911579132080078e+00
    phi[0,3]  R351      -1.4804123640060425e+00
    phi[0,3]  R352      -8.8567268848419189e-01
    phi[0,3]  R353      -1.9468615055084229e+00
    phi[0,3]  R354      1.6119478940963745e+00
    phi[0,3]  R355      -3.8211114406585693e+00
    phi[0,3]  R356      -2.0437605381011963e+00
    phi[0,3]  R357      -9.3523842096328735e-01
    phi[0,3]  R358      -1.11148202419281
    phi[0,3]  R359      -1.6890485286712646e+00
    phi[0,3]  R360      2.7314907312393188e-01
    phi[0,3]  R361      -2.5762073993682861e+00
    phi[0,3]  R362      -1.0708166360855103e+00
    phi[0,3]  R363      -8.8867408037185669e-01
    phi[0,3]  R364      -1.3670606613159180e+00
    phi[0,3]  R365      -1.7170247435569763e-01
    phi[0,3]  R366      1.9423849582672119e+00
    phi[0,3]  R367      -3.5738561153411865e+00
    phi[0,3]  R368      -2.7719292640686035e+00
    phi[0,3]  R369      -3.2614150047302246e+00
    phi[0,3]  R370      -1.4663246870040894e+00
    phi[0,3]  R371      -2.1249735355377197e+00
    phi[0,3]  R372      -7.7318131923675537e-01
    phi[0,3]  R373      -2.6373436450958252e+00
    phi[0,3]  R374      -1.4350007772445679e+00
    phi[0,3]  R375      -2.9350249767303467e+00
    phi[0,3]  R376      -1.1410239934921265e+00
    phi[0,3]  R377      -2.2114701271057129e+00
    phi[0,3]  R378      3.8547596335411072e-01
    phi[0,3]  R379      1.1682614088058472e+00
    phi[0,3]  R380      -2.3844149112701416e+00
    phi[0,3]  R381      -2.4158637523651123e+00
    phi[0,3]  R382      -8.4346204996109009e-01
    phi[0,3]  R383      -1.2738980054855347e+00
    phi[0,3]  R384      -1.0496698617935181e+00
    phi[0,3]  R385      -1.8489879369735718e+00
    phi[0,3]  R386      -1.2628785371780396e+00
    phi[0,3]  R387      -1.6242331266403198e+00
    phi[3,0]  R0        -1
    phi[3,0]  R27       1
    phi[3,0]  R28       1
    phi[3,0]  R388      -3.0999999046325684e+00
    phi[3,0]  R389      -3.0999999046325684e+00
    phi[3,0]  R390      -2.2400000095367432e+00
    phi[3,0]  R391      -2.2400000095367432e+00
    phi[3,0]  R392      -3.0999999046325684e+00
    phi[3,0]  R393      -3.0999999046325684e+00
    phi[3,0]  R394      -2.5699999332427979e+00
    phi[3,0]  R395      -2.5699999332427979e+00
    phi[3,0]  R396      -3.0999999046325684e+00
    phi[3,0]  R397      -3.0999999046325684e+00
    phi[3,0]  R398      -2.0899999141693115e+00
    phi[3,0]  R399      -2.0899999141693115e+00
    phi[3,0]  R400      -3.0999999046325684e+00
    phi[3,0]  R401      -3.0999999046325684e+00
    phi[3,0]  R402      7.4696838855743408e-01
    phi[3,0]  R403      5.9032940864562988e-01
    phi[3,0]  R404      1.2659519910812378e+00
    phi[3,0]  R405      1.8894494771957397e+00
    phi[3,0]  R406      3.6784321069717407e-01
    phi[3,0]  R407      -6.1327069997787476e-02
    phi[3,0]  R408      -3.8263463973999023e-01
    phi[3,0]  R409      4.9458020925521851e-01
    phi[3,0]  R410      -6.2288695573806763e-01
    phi[3,0]  R411      5.6835895776748657e-01
    phi[3,0]  R412      -2.6482255458831787e+00
    phi[3,0]  R413      2.6964244246482849e-01
    phi[3,0]  R414      8.2052677869796753e-02
    phi[3,0]  R415      1.2029384076595306e-01
    phi[3,0]  R416      -5.9737324714660645e-01
    phi[3,0]  R417      -0.561819314956665
    phi[3,0]  R418      -1.0686492174863815e-01
    phi[3,0]  R419      1.2331368923187256e+00
    phi[3,0]  R420      8.4604567289352417e-01
    phi[3,0]  R421      2.4319463968276978e-01
    phi[3,0]  R422      -3.3971695899963379e+00
    phi[3,0]  R423      -2.1615834236145020e+00
    phi[3,0]  R424      -6.9311982393264771e-01
    phi[3,0]  R425      -3.1848275661468506e+00
    phi[3,0]  R426      -3.0147583484649658e+00
    phi[3,0]  R427      -2.1126053333282471e+00
    phi[3,0]  R428      -1.6379393339157104e+00
    phi[3,0]  R429      -2.0082266330718994e+00
    phi[3,0]  R430      -1.2475862503051758e+00
    phi[3,0]  R431      -3.0648466944694519e-01
    phi[3,0]  R432      -0.82502281665802
    phi[3,0]  R433      -2.7735455036163330e+00
    phi[3,0]  R434      -3.0565261840820312e+00
    phi[3,0]  R435      -3.1282525062561035e+00
    phi[3,0]  R436      -2.9937264919281006e+00
    phi[3,0]  R437      -1.2714358568191528e+00
    phi[3,0]  R438      -7.7594143152236938e-01
    phi[3,0]  R439      -1.3108272552490234e+00
    phi[3,0]  R440      -1.5030174255371094e+00
    phi[3,0]  R441      -2.5247743129730225e+00
    phi[3,0]  R442      -2.2561569213867188e+00
    phi[3,0]  R443      -1.5610722303390503e+00
    phi[3,0]  R444      -1.6261727809906006e+00
    phi[3,0]  R445      -2.4040496349334717e+00
    phi[3,0]  R446      -8.6141097545623779e-01
    phi[3,0]  R447      -9.9069011211395264e-01
    phi[3,0]  R448      -3.8015681505203247e-01
    phi[3,0]  R449      -5.7802206277847290e-01
    phi[3,0]  R450      -2.8298065662384033e+00
    phi[3,0]  R451      -5.2950870990753174e-01
    phi[3,0]  R452      -1.1166453361511230e+00
    phi[3,0]  R453      -1.6335239410400391e+00
    phi[3,0]  R454      -2.5911579132080078e+00
    phi[3,0]  R455      -1.4804123640060425e+00
    phi[3,0]  R456      -8.8567268848419189e-01
    phi[3,0]  R457      -1.9468615055084229e+00
    phi[3,0]  R458      1.6119478940963745e+00
    phi[3,0]  R459      -3.8211114406585693e+00
    phi[3,0]  R460      -2.0437605381011963e+00
    phi[3,0]  R461      -9.3523842096328735e-01
    phi[3,0]  R462      -1.11148202419281
    phi[3,0]  R463      -1.6890485286712646e+00
    phi[3,0]  R464      2.7314907312393188e-01
    phi[3,0]  R465      -2.5762073993682861e+00
    phi[3,0]  R466      -1.0708166360855103e+00
    phi[3,0]  R467      -8.8867408037185669e-01
    phi[3,0]  R468      -1.3670606613159180e+00
    phi[3,0]  R469      -1.7170247435569763e-01
    phi[3,0]  R470      1.9423849582672119e+00
    phi[3,0]  R471      -3.5738561153411865e+00
    phi[3,0]  R472      -2.7719292640686035e+00
    phi[3,0]  R473      -3.2614150047302246e+00
    phi[3,0]  R474      -1.4663246870040894e+00
    phi[3,0]  R475      -2.1249735355377197e+00
    phi[3,0]  R476      -7.7318131923675537e-01
    phi[3,0]  R477      -2.6373436450958252e+00
    phi[3,0]  R478      -1.4350007772445679e+00
    phi[3,0]  R479      -2.9350249767303467e+00
    phi[3,0]  R480      -1.1410239934921265e+00
    phi[3,0]  R481      -2.2114701271057129e+00
    phi[3,0]  R482      3.8547596335411072e-01
    phi[3,0]  R483      1.1682614088058472e+00
    phi[3,0]  R484      -2.3844149112701416e+00
    phi[3,0]  R485      -2.4158637523651123e+00
    phi[3,0]  R486      -8.4346204996109009e-01
    phi[3,0]  R487      -1.2738980054855347e+00
    phi[3,0]  R488      -1.0496698617935181e+00
    phi[3,0]  R489      -1.8489879369735718e+00
    phi[3,0]  R490      -1.2628785371780396e+00
    phi[3,0]  R491      -1.6242331266403198e+00
    phi[3,0]  R492      -2.6892283558845520e-01
    phi[3,0]  R493      9.4179280102252960e-02
    phi[3,0]  R494      1.1996356397867203e-01
    phi[3,0]  R495      3.1644460558891296e-01
    phi[3,0]  R496      4.7326788306236267e-02
    phi[3,0]  R497      1.0687191039323807e-01
    phi[3,0]  R498      4.3213921785354614e-01
    phi[3,0]  R499      4.0144789218902588e-01
    phi[3,0]  R500      7.8688788414001465e-01
    phi[3,0]  R501      -6.4240795373916626e-01
    phi[3,0]  R502      2.3015065491199493e-01
    phi[3,0]  R503      -1.5868855640292168e-02
    phi[3,0]  R504      -2.7030691504478455e-01
    phi[3,0]  R505      -3.4411042928695679e-01
    phi[3,0]  R506      -6.6079616546630859e-02
    phi[3,0]  R507      -7.2866678237915039e-01
    phi[3,0]  R508      -1.9751334190368652e-01
    phi[3,0]  R509      -2.7590963244438171e-01
    phi[3,0]  R510      -1.0037581920623779e+00
    phi[3,0]  R511      3.5942593216896057e-01
    phi[3,0]  R512      -2.2275438308715820e+00
    phi[3,0]  R513      -3.0821361541748047e+00
    phi[3,0]  R514      -2.4403109550476074e+00
    phi[3,0]  R515      -2.1568632125854492e+00
    phi[3,0]  R516      -2.5912337303161621e+00
    phi[3,0]  R517      -2.6413395404815674e+00
    phi[3,0]  R518      -3.1899554729461670e+00
    phi[3,0]  R519      -2.5282959938049316e+00
    phi[3,0]  R520      -1.8788827657699585e+00
    phi[3,0]  R521      -2.0508601665496826e+00
    phi[3,0]  R522      -8.0012089014053345e-01
    phi[3,0]  R523      -6.0018397867679596e-02
    phi[3,0]  R524      -9.8672497272491455e-01
    phi[3,0]  R525      -2.7835340499877930e+00
    phi[3,0]  R526      -2.8045327663421631e+00
    phi[3,0]  R527      -9.6790528297424316e-01
    phi[3,0]  R528      -1.8067113161087036e+00
    phi[3,0]  R529      -7.7039480209350586e-01
    phi[3,0]  R530      -3.9311339855194092e+00
    phi[3,0]  R531      -3.7480993270874023e+00
    phi[0,4]  R0        1
    phi[0,4]  R1        1
    phi[0,4]  R36       -1
    phi[0,4]  R532      -3.0999999046325684e+00
    phi[0,4]  R533      -3.0999999046325684e+00
    phi[0,4]  R534      -2.2400000095367432e+00
    phi[0,4]  R535      -2.2400000095367432e+00
    phi[0,4]  R536      -3.0999999046325684e+00
    phi[0,4]  R537      -3.0999999046325684e+00
    phi[0,4]  R538      -2.5699999332427979e+00
    phi[0,4]  R539      -2.5699999332427979e+00
    phi[0,4]  R540      -3.0999999046325684e+00
    phi[0,4]  R541      -3.0999999046325684e+00
    phi[0,4]  R542      -2.0899999141693115e+00
    phi[0,4]  R543      -2.0899999141693115e+00
    phi[0,4]  R544      -3.0999999046325684e+00
    phi[0,4]  R545      -3.0999999046325684e+00
    phi[0,4]  R546      -2.6892283558845520e-01
    phi[0,4]  R547      9.4179280102252960e-02
    phi[0,4]  R548      1.1996356397867203e-01
    phi[0,4]  R549      3.1644460558891296e-01
    phi[0,4]  R550      4.7326788306236267e-02
    phi[0,4]  R551      1.0687191039323807e-01
    phi[0,4]  R552      4.3213921785354614e-01
    phi[0,4]  R553      4.0144789218902588e-01
    phi[0,4]  R554      7.8688788414001465e-01
    phi[0,4]  R555      -6.4240795373916626e-01
    phi[0,4]  R556      2.3015065491199493e-01
    phi[0,4]  R557      -1.5868855640292168e-02
    phi[0,4]  R558      -2.7030691504478455e-01
    phi[0,4]  R559      -3.4411042928695679e-01
    phi[0,4]  R560      -6.6079616546630859e-02
    phi[0,4]  R561      -7.2866678237915039e-01
    phi[0,4]  R562      -1.9751334190368652e-01
    phi[0,4]  R563      -2.7590963244438171e-01
    phi[0,4]  R564      -1.0037581920623779e+00
    phi[0,4]  R565      3.5942593216896057e-01
    phi[0,4]  R566      -2.2275438308715820e+00
    phi[0,4]  R567      -3.0821361541748047e+00
    phi[0,4]  R568      -2.4403109550476074e+00
    phi[0,4]  R569      -2.1568632125854492e+00
    phi[0,4]  R570      -2.5912337303161621e+00
    phi[0,4]  R571      -2.6413395404815674e+00
    phi[0,4]  R572      -3.1899554729461670e+00
    phi[0,4]  R573      -2.5282959938049316e+00
    phi[0,4]  R574      -1.8788827657699585e+00
    phi[0,4]  R575      -2.0508601665496826e+00
    phi[0,4]  R576      -8.0012089014053345e-01
    phi[0,4]  R577      -6.0018397867679596e-02
    phi[0,4]  R578      -9.8672497272491455e-01
    phi[0,4]  R579      -2.7835340499877930e+00
    phi[0,4]  R580      -2.8045327663421631e+00
    phi[0,4]  R581      -9.6790528297424316e-01
    phi[0,4]  R582      -1.8067113161087036e+00
    phi[0,4]  R583      -7.7039480209350586e-01
    phi[0,4]  R584      -3.9311339855194092e+00
    phi[0,4]  R585      -3.7480993270874023e+00
    phi[0,4]  R586      5.3010648116469383e-03
    phi[0,4]  R587      -7.7004718780517578e-01
    phi[0,4]  R588      -4.4023880362510681e-01
    phi[0,4]  R589      4.4781726598739624e-01
    phi[0,4]  R590      -2.0931883156299591e-01
    phi[0,4]  R591      1.0946505069732666e+00
    phi[0,4]  R592      3.7301298975944519e-01
    phi[0,4]  R593      -7.7773980796337128e-02
    phi[0,4]  R594      -3.1244492530822754e-01
    phi[0,4]  R595      -9.1448360681533813e-01
    phi[0,4]  R596      3.2370540499687195e-01
    phi[0,4]  R597      -2.7513947486877441e+00
    phi[0,4]  R598      -3.9884489774703979e-01
    phi[0,4]  R599      -3.3851286768913269e-01
    phi[0,4]  R600      -1.2109183520078659e-01
    phi[0,4]  R601      -1.3731625080108643e+00
    phi[0,4]  R602      -9.2978693544864655e-02
    phi[0,4]  R603      3.0590891838073730e-01
    phi[0,4]  R604      -1.8442462682724
    phi[0,4]  R605      -2.0396001338958740e+00
    phi[0,4]  R606      -1.2676380574703217e-01
    phi[0,4]  R607      -1.1865367889404297e+00
    phi[0,4]  R608      -4.0671494603157043e-01
    phi[0,4]  R609      -1.9195091724395752e+00
    phi[0,4]  R610      -2.2505238056182861e+00
    phi[0,4]  R611      -2.84623384475708
    phi[0,4]  R612      1.3926053047180176e-01
    phi[0,4]  R613      -1.7129764556884766e+00
    phi[0,4]  R614      1.0084869861602783e+00
    phi[0,4]  R615      1.0873062610626221e+00
    phi[4,0]  R0        -1
    phi[4,0]  R36       1
    phi[4,0]  R37       1
    phi[4,0]  R616      -3.0999999046325684e+00
    phi[4,0]  R617      -3.0999999046325684e+00
    phi[4,0]  R618      -2.2400000095367432e+00
    phi[4,0]  R619      -2.2400000095367432e+00
    phi[4,0]  R620      -3.0999999046325684e+00
    phi[4,0]  R621      -3.0999999046325684e+00
    phi[4,0]  R622      -2.5699999332427979e+00
    phi[4,0]  R623      -2.5699999332427979e+00
    phi[4,0]  R624      -3.0999999046325684e+00
    phi[4,0]  R625      -3.0999999046325684e+00
    phi[4,0]  R626      -2.0899999141693115e+00
    phi[4,0]  R627      -2.0899999141693115e+00
    phi[4,0]  R628      -3.0999999046325684e+00
    phi[4,0]  R629      -3.0999999046325684e+00
    phi[4,0]  R630      5.3010648116469383e-03
    phi[4,0]  R631      -7.7004718780517578e-01
    phi[4,0]  R632      -4.4023880362510681e-01
    phi[4,0]  R633      4.4781726598739624e-01
    phi[4,0]  R634      -2.0931883156299591e-01
    phi[4,0]  R635      1.0946505069732666e+00
    phi[4,0]  R636      3.7301298975944519e-01
    phi[4,0]  R637      -7.7773980796337128e-02
    phi[4,0]  R638      -3.1244492530822754e-01
    phi[4,0]  R639      -9.1448360681533813e-01
    phi[4,0]  R640      3.2370540499687195e-01
    phi[4,0]  R641      -2.7513947486877441e+00
    phi[4,0]  R642      -3.9884489774703979e-01
    phi[4,0]  R643      -3.3851286768913269e-01
    phi[4,0]  R644      -1.2109183520078659e-01
    phi[4,0]  R645      -1.3731625080108643e+00
    phi[4,0]  R646      -9.2978693544864655e-02
    phi[4,0]  R647      3.0590891838073730e-01
    phi[4,0]  R648      -1.8442462682724
    phi[4,0]  R649      -2.0396001338958740e+00
    phi[4,0]  R650      -1.2676380574703217e-01
    phi[4,0]  R651      -1.1865367889404297e+00
    phi[4,0]  R652      -4.0671494603157043e-01
    phi[4,0]  R653      -1.9195091724395752e+00
    phi[4,0]  R654      -2.2505238056182861e+00
    phi[4,0]  R655      -2.84623384475708
    phi[4,0]  R656      1.3926053047180176e-01
    phi[4,0]  R657      -1.7129764556884766e+00
    phi[4,0]  R658      1.0084869861602783e+00
    phi[4,0]  R659      1.0873062610626221e+00
    phi[4,0]  R660      -2.6892283558845520e-01
    phi[4,0]  R661      9.4179280102252960e-02
    phi[4,0]  R662      1.1996356397867203e-01
    phi[4,0]  R663      3.1644460558891296e-01
    phi[4,0]  R664      4.7326788306236267e-02
    phi[4,0]  R665      1.0687191039323807e-01
    phi[4,0]  R666      4.3213921785354614e-01
    phi[4,0]  R667      4.0144789218902588e-01
    phi[4,0]  R668      7.8688788414001465e-01
    phi[4,0]  R669      -6.4240795373916626e-01
    phi[4,0]  R670      2.3015065491199493e-01
    phi[4,0]  R671      -1.5868855640292168e-02
    phi[4,0]  R672      -2.7030691504478455e-01
    phi[4,0]  R673      -3.4411042928695679e-01
    phi[4,0]  R674      -6.6079616546630859e-02
    phi[4,0]  R675      -7.2866678237915039e-01
    phi[4,0]  R676      -1.9751334190368652e-01
    phi[4,0]  R677      -2.7590963244438171e-01
    phi[4,0]  R678      -1.0037581920623779e+00
    phi[4,0]  R679      3.5942593216896057e-01
    phi[4,0]  R680      -2.2275438308715820e+00
    phi[4,0]  R681      -3.0821361541748047e+00
    phi[4,0]  R682      -2.4403109550476074e+00
    phi[4,0]  R683      -2.1568632125854492e+00
    phi[4,0]  R684      -2.5912337303161621e+00
    phi[4,0]  R685      -2.6413395404815674e+00
    phi[4,0]  R686      -3.1899554729461670e+00
    phi[4,0]  R687      -2.5282959938049316e+00
    phi[4,0]  R688      -1.8788827657699585e+00
    phi[4,0]  R689      -2.0508601665496826e+00
    phi[4,0]  R690      -8.0012089014053345e-01
    phi[4,0]  R691      -6.0018397867679596e-02
    phi[4,0]  R692      -9.8672497272491455e-01
    phi[4,0]  R693      -2.7835340499877930e+00
    phi[4,0]  R694      -2.8045327663421631e+00
    phi[4,0]  R695      -9.6790528297424316e-01
    phi[4,0]  R696      -1.8067113161087036e+00
    phi[4,0]  R697      -7.7039480209350586e-01
    phi[4,0]  R698      -3.9311339855194092e+00
    phi[4,0]  R699      -3.7480993270874023e+00
    phi[6,0]  R0        -1
    phi[6,0]  R2        0.436132660285212
    phi[6,0]  R3        -6.5293115906839816e-01
    phi[6,0]  R4        1.4403253088833403e+00
    phi[6,0]  R5        -1.6897541231401312e+00
    phi[6,0]  R6        -2.19870963770369
    phi[6,0]  R7        1.0017387778479798e+00
    phi[6,0]  R8        1.6473301255492978e+00
    phi[6,0]  R54       1
    phi[6,0]  R700      -3.5361325649177804e+00
    phi[6,0]  R701      -2.6638672443473563e+00
    phi[6,0]  R702      -1.5870688504683450e+00
    phi[6,0]  R703      -2.8929311686051413e+00
    phi[6,0]  R704      -4.5403252135159082e+00
    phi[6,0]  R705      -1.6596745957492280e+00
    phi[6,0]  R706      -8.8024581010266667e-01
    phi[6,0]  R707      -4.2597540563829295e+00
    phi[6,0]  R708      -9.0129026692887848e-01
    phi[6,0]  R709      -5.2987095423362582e+00
    phi[6,0]  R710      -3.0917386920172913e+00
    phi[6,0]  R711      -1.0882611363213317e+00
    phi[6,0]  R712      -4.7473300301818657e+00
    phi[6,0]  R713      -1.4526697790832706e+00
    phi[6,0]  R714      -2.3893522393245809e-01
    phi[6,0]  R715      -2.4008909596615730e-01
    phi[6,0]  R716      -2.4199292373170017e-01
    phi[6,0]  R717      -2.5104422143629135e-01
    phi[6,0]  R718      -2.6985970909211621e-01
    phi[6,0]  R719      -2.7913214556912835e-01
    phi[6,0]  R720      -2.8262388254208337e-01
    phi[6,0]  R721      -2.8809372659764221e-01
    phi[6,0]  R722      -2.9809705384574103e-01
    phi[6,0]  R723      -3.0203238137290062e-01
    phi[6,0]  R724      -7.4352093048412216e-01
    phi[6,0]  R725      -9.1466626336069368e-01
    phi[6,0]  R726      -0.719703612362762
    phi[6,0]  R727      -0.631420384706824
    phi[6,0]  R728      -1.2955723289176142e+00
    phi[6,0]  R729      -4.2122199072715627e-01
    phi[6,0]  R730      -1.1694315531923092e+00
    phi[6,0]  R731      -7.0533960632159642e-01
    phi[6,0]  R732      -6.7735721907427981e-01
    phi[6,0]  R733      -1.7985573016308631e+00
    phi[6,0]  R734      -4.9987549215256566e-01
    phi[6,0]  R735      -0.510109570235791
    phi[6,0]  R736      -5.2800899408742685e-01
    phi[6,0]  R737      -0.532989165219278
    phi[6,0]  R738      -5.5147558699842758e-01
    phi[6,0]  R739      -5.5214576361424550e-01
    phi[6,0]  R740      -0.553636783214102
    phi[6,0]  R741      -5.6780747650004715e-01
    phi[6,0]  R742      -5.6997168046517555e-01
    phi[6,0]  R743      -0.572524289876073
    phi[6,0]  R744      -4.7870286566231723e-01
    phi[6,0]  R745      -0.564022706223438
    phi[6,0]  R746      -6.6042947778199368e-01
    phi[6,0]  R747      -6.9230160118098238e-01
    phi[6,0]  R748      -6.9430284368966433e-01
    phi[6,0]  R749      -7.7527729856732919e-01
    phi[6,0]  R750      -8.3761364946701033e-01
    phi[6,0]  R751      -8.7402588532006120e-01
    phi[6,0]  R752      -8.9230876741266485e-01
    phi[6,0]  R753      -9.0339394736650114e-01
    phi[1,2]  R9        1
    phi[1,2]  R10       1
    phi[1,2]  R18       -1
    phi[1,2]  R754      -3.0999999046325684e+00
    phi[1,2]  R755      -3.0999999046325684e+00
    phi[1,2]  R756      -2.2400000095367432e+00
    phi[1,2]  R757      -2.2400000095367432e+00
    phi[1,2]  R758      -3.0999999046325684e+00
    phi[1,2]  R759      -3.0999999046325684e+00
    phi[1,2]  R760      -2.5699999332427979e+00
    phi[1,2]  R761      -2.5699999332427979e+00
    phi[1,2]  R762      -3.0999999046325684e+00
    phi[1,2]  R763      -3.0999999046325684e+00
    phi[1,2]  R764      -2.0899999141693115e+00
    phi[1,2]  R765      -2.0899999141693115e+00
    phi[1,2]  R766      -3.0999999046325684e+00
    phi[1,2]  R767      -3.0999999046325684e+00
    phi[1,2]  R768      -5.3848731517791748e-01
    phi[1,2]  R769      -5.6913875043392181e-02
    phi[1,2]  R770      -4.7335222363471985e-01
    phi[1,2]  R771      -7.0460289716720581e-02
    phi[1,2]  R772      -5.4341918230056763e-01
    phi[1,2]  R773      -2.0838913321495056e-01
    phi[1,2]  R774      -7.7236875891685486e-02
    phi[1,2]  R775      -1.0334223508834839e-01
    phi[1,2]  R776      -9.2117607593536377e-01
    phi[1,2]  R777      -9.6261298656463623e-01
    phi[1,2]  R778      -5.4849022626876831e-01
    phi[1,2]  R779      -4.4594958424568176e-01
    phi[1,2]  R780      5.7942576706409454e-02
    phi[1,2]  R781      -0.422661691904068
    phi[1,2]  R782      -6.2049329280853271e-01
    phi[1,2]  R783      -3.6150512099266052e-01
    phi[1,2]  R784      2.8013634681701660e-01
    phi[1,2]  R785      -3.7358406186103821e-01
    phi[1,2]  R786      -4.0827322006225586e-01
    phi[1,2]  R787      -1.0542370080947876e+00
    phi[1,2]  R788      -7.9945939779281616e-01
    phi[1,2]  R789      -4.1097530722618103e-01
    phi[1,2]  R790      0.0332217663526535
    phi[1,2]  R791      -1.7338870093226433e-02
    phi[1,2]  R792      -1.7940394580364227e-01
    phi[1,2]  R793      -2.0023712515830994e-01
    phi[1,2]  R794      -1.2310332059860229e+00
    phi[1,2]  R795      5.9351670742034912e-01
    phi[1,2]  R796      -6.3431960344314575e-01
    phi[1,2]  R797      -1.1345435380935669e+00
    phi[1,2]  R798      -1.0727311372756958e+00
    phi[1,2]  R799      -1.6438180208206177e-01
    phi[1,2]  R800      -4.7152754664421082e-01
    phi[1,2]  R801      -3.1429141759872437e-01
    phi[1,2]  R802      -2.3560506105422974e-01
    phi[1,2]  R803      -2.7584062889218330e-02
    phi[1,2]  R804      -3.6491242051124573e-01
    phi[1,2]  R805      -9.5044940710067749e-01
    phi[1,2]  R806      -1.2566862106323242e+00
    phi[1,2]  R807      -1.5598497390747070e+00
    phi[1,2]  R808      8.6888474225997925e-01
    phi[1,2]  R809      1.2631245851516724e+00
    phi[1,2]  R810      5.8422349393367767e-02
    phi[1,2]  R811      -5.3490829467773438e-01
    phi[1,2]  R812      -1.8546824157238007e-01
    phi[1,2]  R813      -1.0336734056472778e+00
    phi[1,2]  R814      1.2444587796926498e-01
    phi[1,2]  R815      0.0924357995390892
    phi[1,2]  R816      -9.4308412075042725e-01
    phi[1,2]  R817      8.8834607601165771e-01
    phi[1,2]  R818      1.8743423223495483e+00
    phi[1,2]  R819      1.3800209760665894e+00
    phi[1,2]  R820      7.9257005453109741e-01
    phi[1,2]  R821      1.0193324089050293e+00
    phi[1,2]  R822      1.2950372695922852e+00
    phi[1,2]  R823      -6.5510910749435425e-01
    phi[1,2]  R824      7.4543076753616333e-01
    phi[1,2]  R825      1.9147914648056030e+00
    phi[1,2]  R826      7.5920188426971436e-01
    phi[1,2]  R827      1.7236145734786987e+00
    phi[1,2]  R828      -2.7206065654754639e+00
    phi[1,2]  R829      -1.7157231569290161e+00
    phi[1,2]  R830      -2.1009018421173096e+00
    phi[1,2]  R831      -1.7083665132522583e+00
    phi[1,2]  R832      -7.9749459028244019e-01
    phi[1,2]  R833      -2.0797948837280273e+00
    phi[1,2]  R834      -7.3608511686325073e-01
    phi[1,2]  R835      -1.9498858451843262e+00
    phi[1,2]  R836      1.6095927357673645e-01
    phi[1,2]  R837      -1.0621354579925537e+00
    phi[1,2]  R838      -2.3725574016571045e+00
    phi[1,2]  R839      -1.5226991176605225e+00
    phi[1,2]  R840      -3.9799737930297852e-01
    phi[1,2]  R841      -1.7305209636688232e+00
    phi[1,2]  R842      -1.7774429321289062e+00
    phi[1,2]  R843      -2.5589108467102051e+00
    phi[1,2]  R844      -2.4984819889068604e+00
    phi[1,2]  R845      -8.4011447429656982e-01
    phi[1,2]  R846      -2.0023903846740723e+00
    phi[1,2]  R847      -1.9811100959777832e+00
    phi[1,2]  R848      -2.1344709396362305e+00
    phi[1,2]  R849      -2.4273073673248291e+00
    phi[1,2]  R850      -9.2546486854553223e-01
    phi[1,2]  R851      -9.6670711040496826e-01
    phi[1,2]  R852      -2.0022168159484863e+00
    phi[1,2]  R853      -1.8197969198226929e+00
    phi[1,2]  R854      -5.1182305812835693e-01
    phi[1,2]  R855      -2.3194580078125
    phi[1,2]  R856      -3.0017659068107605e-01
    phi[1,2]  R857      1.0696269273757935e+00
    phi[1,2]  R858      -2.4927549362182617e+00
    phi[1,2]  R859      -1.0444631576538086e+00
    phi[1,2]  R860      -3.7102723121643066e-01
    phi[1,2]  R861      -2.2414700984954834e+00
    phi[1,2]  R862      -1.4155066013336182e+00
    phi[1,2]  R863      -2.6036414504051208e-01
    phi[1,2]  R864      -2.6354405283927917e-01
    phi[1,2]  R865      1.3174796104431152e+00
    phi[1,2]  R866      -7.7785408496856689e-01
    phi[1,2]  R867      -4.1983652114868164e-01
    phi[1,2]  R868      -8.2193863391876221e-01
    phi[1,2]  R869      -1.5372793674468994e+00
    phi[1,2]  R870      -2.2401053905487061e+00
    phi[1,2]  R871      -5.4478609561920166e-01
    phi[1,2]  R872      5.8045393228530884e-01
    phi[1,2]  R873      -2.1973342895507812e+00
    phi[1,2]  R874      -6.3260859251022339e-01
    phi[1,2]  R875      -1.1133118867874146e+00
    phi[1,2]  R876      -3.2645177841186523e+00
    phi[1,2]  R877      -5.3573942184448242e-01
    phi[2,1]  R9        -1
    phi[2,1]  R18       1
    phi[2,1]  R19       1
    phi[2,1]  R878      -3.0999999046325684e+00
    phi[2,1]  R879      -3.0999999046325684e+00
    phi[2,1]  R880      -2.2400000095367432e+00
    phi[2,1]  R881      -2.2400000095367432e+00
    phi[2,1]  R882      -3.0999999046325684e+00
    phi[2,1]  R883      -3.0999999046325684e+00
    phi[2,1]  R884      -2.5699999332427979e+00
    phi[2,1]  R885      -2.5699999332427979e+00
    phi[2,1]  R886      -3.0999999046325684e+00
    phi[2,1]  R887      -3.0999999046325684e+00
    phi[2,1]  R888      -2.0899999141693115e+00
    phi[2,1]  R889      -2.0899999141693115e+00
    phi[2,1]  R890      -3.0999999046325684e+00
    phi[2,1]  R891      -3.0999999046325684e+00
    phi[2,1]  R892      8.6888474225997925e-01
    phi[2,1]  R893      1.2631245851516724e+00
    phi[2,1]  R894      5.8422349393367767e-02
    phi[2,1]  R895      -5.3490829467773438e-01
    phi[2,1]  R896      -1.8546824157238007e-01
    phi[2,1]  R897      -1.0336734056472778e+00
    phi[2,1]  R898      1.2444587796926498e-01
    phi[2,1]  R899      0.0924357995390892
    phi[2,1]  R900      -9.4308412075042725e-01
    phi[2,1]  R901      8.8834607601165771e-01
    phi[2,1]  R902      1.8743423223495483e+00
    phi[2,1]  R903      1.3800209760665894e+00
    phi[2,1]  R904      7.9257005453109741e-01
    phi[2,1]  R905      1.0193324089050293e+00
    phi[2,1]  R906      1.2950372695922852e+00
    phi[2,1]  R907      -6.5510910749435425e-01
    phi[2,1]  R908      7.4543076753616333e-01
    phi[2,1]  R909      1.9147914648056030e+00
    phi[2,1]  R910      7.5920188426971436e-01
    phi[2,1]  R911      1.7236145734786987e+00
    phi[2,1]  R912      -2.7206065654754639e+00
    phi[2,1]  R913      -1.7157231569290161e+00
    phi[2,1]  R914      -2.1009018421173096e+00
    phi[2,1]  R915      -1.7083665132522583e+00
    phi[2,1]  R916      -7.9749459028244019e-01
    phi[2,1]  R917      -2.0797948837280273e+00
    phi[2,1]  R918      -7.3608511686325073e-01
    phi[2,1]  R919      -1.9498858451843262e+00
    phi[2,1]  R920      1.6095927357673645e-01
    phi[2,1]  R921      -1.0621354579925537e+00
    phi[2,1]  R922      -2.3725574016571045e+00
    phi[2,1]  R923      -1.5226991176605225e+00
    phi[2,1]  R924      -3.9799737930297852e-01
    phi[2,1]  R925      -1.7305209636688232e+00
    phi[2,1]  R926      -1.7774429321289062e+00
    phi[2,1]  R927      -2.5589108467102051e+00
    phi[2,1]  R928      -2.4984819889068604e+00
    phi[2,1]  R929      -8.4011447429656982e-01
    phi[2,1]  R930      -2.0023903846740723e+00
    phi[2,1]  R931      -1.9811100959777832e+00
    phi[2,1]  R932      -2.1344709396362305e+00
    phi[2,1]  R933      -2.4273073673248291e+00
    phi[2,1]  R934      -9.2546486854553223e-01
    phi[2,1]  R935      -9.6670711040496826e-01
    phi[2,1]  R936      -2.0022168159484863e+00
    phi[2,1]  R937      -1.8197969198226929e+00
    phi[2,1]  R938      -5.1182305812835693e-01
    phi[2,1]  R939      -2.3194580078125
    phi[2,1]  R940      -3.0017659068107605e-01
    phi[2,1]  R941      1.0696269273757935e+00
    phi[2,1]  R942      -2.4927549362182617e+00
    phi[2,1]  R943      -1.0444631576538086e+00
    phi[2,1]  R944      -3.7102723121643066e-01
    phi[2,1]  R945      -2.2414700984954834e+00
    phi[2,1]  R946      -1.4155066013336182e+00
    phi[2,1]  R947      -2.6036414504051208e-01
    phi[2,1]  R948      -2.6354405283927917e-01
    phi[2,1]  R949      1.3174796104431152e+00
    phi[2,1]  R950      -7.7785408496856689e-01
    phi[2,1]  R951      -4.1983652114868164e-01
    phi[2,1]  R952      -8.2193863391876221e-01
    phi[2,1]  R953      -1.5372793674468994e+00
    phi[2,1]  R954      -2.2401053905487061e+00
    phi[2,1]  R955      -5.4478609561920166e-01
    phi[2,1]  R956      5.8045393228530884e-01
    phi[2,1]  R957      -2.1973342895507812e+00
    phi[2,1]  R958      -6.3260859251022339e-01
    phi[2,1]  R959      -1.1133118867874146e+00
    phi[2,1]  R960      -3.2645177841186523e+00
    phi[2,1]  R961      -5.3573942184448242e-01
    phi[2,1]  R962      -5.3848731517791748e-01
    phi[2,1]  R963      -5.6913875043392181e-02
    phi[2,1]  R964      -4.7335222363471985e-01
    phi[2,1]  R965      -7.0460289716720581e-02
    phi[2,1]  R966      -5.4341918230056763e-01
    phi[2,1]  R967      -2.0838913321495056e-01
    phi[2,1]  R968      -7.7236875891685486e-02
    phi[2,1]  R969      -1.0334223508834839e-01
    phi[2,1]  R970      -9.2117607593536377e-01
    phi[2,1]  R971      -9.6261298656463623e-01
    phi[2,1]  R972      -5.4849022626876831e-01
    phi[2,1]  R973      -4.4594958424568176e-01
    phi[2,1]  R974      5.7942576706409454e-02
    phi[2,1]  R975      -0.422661691904068
    phi[2,1]  R976      -6.2049329280853271e-01
    phi[2,1]  R977      -3.6150512099266052e-01
    phi[2,1]  R978      2.8013634681701660e-01
    phi[2,1]  R979      -3.7358406186103821e-01
    phi[2,1]  R980      -4.0827322006225586e-01
    phi[2,1]  R981      -1.0542370080947876e+00
    phi[2,1]  R982      -7.9945939779281616e-01
    phi[2,1]  R983      -4.1097530722618103e-01
    phi[2,1]  R984      0.0332217663526535
    phi[2,1]  R985      -1.7338870093226433e-02
    phi[2,1]  R986      -1.7940394580364227e-01
    phi[2,1]  R987      -2.0023712515830994e-01
    phi[2,1]  R988      -1.2310332059860229e+00
    phi[2,1]  R989      5.9351670742034912e-01
    phi[2,1]  R990      -6.3431960344314575e-01
    phi[2,1]  R991      -1.1345435380935669e+00
    phi[2,1]  R992      -1.0727311372756958e+00
    phi[2,1]  R993      -1.6438180208206177e-01
    phi[2,1]  R994      -4.7152754664421082e-01
    phi[2,1]  R995      -3.1429141759872437e-01
    phi[2,1]  R996      -2.3560506105422974e-01
    phi[2,1]  R997      -2.7584062889218330e-02
    phi[2,1]  R998      -3.6491242051124573e-01
    phi[2,1]  R999      -9.5044940710067749e-01
    phi[2,1]  R1000     -1.2566862106323242e+00
    phi[2,1]  R1001     -1.5598497390747070e+00
    phi[1,5]  R9        1
    phi[1,5]  R10       1
    phi[1,5]  R45       -1
    phi[1,5]  R1002     -3.0999999046325684e+00
    phi[1,5]  R1003     -3.0999999046325684e+00
    phi[1,5]  R1004     -2.2400000095367432e+00
    phi[1,5]  R1005     -2.2400000095367432e+00
    phi[1,5]  R1006     -3.0999999046325684e+00
    phi[1,5]  R1007     -3.0999999046325684e+00
    phi[1,5]  R1008     -2.5699999332427979e+00
    phi[1,5]  R1009     -2.5699999332427979e+00
    phi[1,5]  R1010     -3.0999999046325684e+00
    phi[1,5]  R1011     -3.0999999046325684e+00
    phi[1,5]  R1012     -2.0899999141693115e+00
    phi[1,5]  R1013     -2.0899999141693115e+00
    phi[1,5]  R1014     -3.0999999046325684e+00
    phi[1,5]  R1015     -3.0999999046325684e+00
    phi[1,5]  R1016     -5.3848731517791748e-01
    phi[1,5]  R1017     -5.6913875043392181e-02
    phi[1,5]  R1018     -4.7335222363471985e-01
    phi[1,5]  R1019     -7.0460289716720581e-02
    phi[1,5]  R1020     -5.4341918230056763e-01
    phi[1,5]  R1021     -2.0838913321495056e-01
    phi[1,5]  R1022     -7.7236875891685486e-02
    phi[1,5]  R1023     -1.0334223508834839e-01
    phi[1,5]  R1024     -9.2117607593536377e-01
    phi[1,5]  R1025     -9.6261298656463623e-01
    phi[1,5]  R1026     -5.4849022626876831e-01
    phi[1,5]  R1027     -4.4594958424568176e-01
    phi[1,5]  R1028     5.7942576706409454e-02
    phi[1,5]  R1029     -0.422661691904068
    phi[1,5]  R1030     -6.2049329280853271e-01
    phi[1,5]  R1031     -3.6150512099266052e-01
    phi[1,5]  R1032     2.8013634681701660e-01
    phi[1,5]  R1033     -3.7358406186103821e-01
    phi[1,5]  R1034     -4.0827322006225586e-01
    phi[1,5]  R1035     -1.0542370080947876e+00
    phi[1,5]  R1036     -7.9945939779281616e-01
    phi[1,5]  R1037     -4.1097530722618103e-01
    phi[1,5]  R1038     0.0332217663526535
    phi[1,5]  R1039     -1.7338870093226433e-02
    phi[1,5]  R1040     -1.7940394580364227e-01
    phi[1,5]  R1041     -2.0023712515830994e-01
    phi[1,5]  R1042     -1.2310332059860229e+00
    phi[1,5]  R1043     5.9351670742034912e-01
    phi[1,5]  R1044     -6.3431960344314575e-01
    phi[1,5]  R1045     -1.1345435380935669e+00
    phi[1,5]  R1046     -1.0727311372756958e+00
    phi[1,5]  R1047     -1.6438180208206177e-01
    phi[1,5]  R1048     -4.7152754664421082e-01
    phi[1,5]  R1049     -3.1429141759872437e-01
    phi[1,5]  R1050     -2.3560506105422974e-01
    phi[1,5]  R1051     -2.7584062889218330e-02
    phi[1,5]  R1052     -3.6491242051124573e-01
    phi[1,5]  R1053     -9.5044940710067749e-01
    phi[1,5]  R1054     -1.2566862106323242e+00
    phi[1,5]  R1055     -1.5598497390747070e+00
    phi[1,5]  R1056     2.8414392471313477e-01
    phi[1,5]  R1057     -8.0679035186767578e-01
    phi[1,5]  R1058     -1.1893633753061295e-01
    phi[1,5]  R1059     1.5230422019958496e+00
    phi[1,5]  R1060     7.2793298959732056e-01
    phi[1,5]  R1061     -1.4463989436626434e-01
    phi[1,5]  R1062     1.1948866844177246e+00
    phi[1,5]  R1063     9.0794456005096436e-01
    phi[1,5]  R1064     -1.2591454386711121e-01
    phi[1,5]  R1065     1.7452241182327271e+00
    phi[1,5]  R1066     -2.8261013031005859e+00
    phi[1,5]  R1067     -9.4937264919281006e-01
    phi[1,5]  R1068     -3.5499542951583862e-01
    phi[1,5]  R1069     -3.9355948567390442e-02
    phi[1,5]  R1070     -2.1837933063507080e+00
    phi[1,5]  R1071     3.4433159232139587e-01
    phi[1,5]  R1072     -9.2684447765350342e-01
    phi[1,5]  R1073     -4.4330008327960968e-02
    phi[1,5]  R1074     -6.8314790725708008e-01
    phi[1,5]  R1075     -2.8046682476997375e-01
    phi[1,5]  R1076     -1.0717215538024902e+00
    phi[1,5]  R1077     -2.1858029365539551e+00
    phi[1,5]  R1078     -2.9832825660705566e+00
    phi[1,5]  R1079     2.1295222640037537e-01
    phi[1,5]  R1080     -2.1082291603088379e+00
    phi[1,5]  R1081     -3.1869323253631592e+00
    phi[1,5]  R1082     -3.1646850109100342e+00
    phi[1,5]  R1083     1.4179245233535767e+00
    phi[1,5]  R1084     -2.3230087757110596e+00
    phi[1,5]  R1085     -3.3502440452575684e+00
    phi[1,5]  R1086     -1.4843820333480835e+00
    phi[1,5]  R1087     -2.95682430267334
    phi[1,5]  R1088     -1.2104443311691284e+00
    phi[1,5]  R1089     -1.9855084419250488e+00
    phi[1,5]  R1090     -1.9198642969131470e+00
    phi[1,5]  R1091     -2.7418620586395264e+00
    phi[1,5]  R1092     1.8515779972076416e+00
    phi[1,5]  R1093     -1.7986783981323242e+00
    phi[1,5]  R1094     -1.0878798961639404e+00
    phi[1,5]  R1095     4.8712402582168579e-01
    phi[1,5]  R1096     -2.8415971994400024e-01
    phi[1,5]  R1097     -1.2536016702651978e+00
    phi[1,5]  R1098     -2.3093726634979248e+00
    phi[1,5]  R1099     -1.4188036322593689e-01
    phi[1,5]  R1100     -1.7499494552612305e+00
    phi[1,5]  R1101     -1.4156135320663452e+00
    phi[1,5]  R1102     -1.7478259801864624e+00
    phi[1,5]  R1103     -1.1277546882629395e+00
    phi[1,5]  R1104     -2.4227716028690338e-01
    phi[1,5]  R1105     -2.7006061077117920e+00
    phi[1,5]  R1106     -4.3319725990295410e-01
    phi[1,5]  R1107     -3.1303146481513977e-01
    phi[1,5]  R1108     -1.4981080293655396e+00
    phi[1,5]  R1109     -1.0864914953708649e-01
    phi[1,5]  R1110     -2.4950990676879883e+00
    phi[1,5]  R1111     2.6497811079025269e-01
    phi[1,5]  R1112     -1.4847133159637451e+00
    phi[1,5]  R1113     -1.6127809286117554e+00
    phi[1,5]  R1114     -2.7393848896026611e+00
    phi[1,5]  R1115     -7.0934897661209106e-01
    phi[1,5]  R1116     -2.1147117614746094e+00
    phi[1,5]  R1117     -2.0120551586151123e+00
    phi[1,5]  R1118     -1.2092066556215286e-01
    phi[1,5]  R1119     1.9460766017436981e-01
    phi[1,5]  R1120     -1.5705695375800133e-02
    phi[1,5]  R1121     0.419849157333374
    phi[1,5]  R1122     -1.9804681539535522e+00
    phi[1,5]  R1123     8.6963987350463867e-01
    phi[1,5]  R1124     -2.4987779557704926e-01
    phi[1,5]  R1125     -9.9948549270629883e-01
    phi[1,5]  R1126     -3.9563268423080444e-01
    phi[1,5]  R1127     -3.3903102874755859e+00
    phi[1,5]  R1128     -1.3080577850341797e+00
    phi[1,5]  R1129     -1.3100939989089966e+00
    phi[1,5]  R1130     -2.9573016166687012e+00
    phi[1,5]  R1131     -3.5129386186599731e-01
    phi[1,5]  R1132     -1.6469752788543701e+00
    phi[1,5]  R1133     1.7266348004341125e-01
    phi[1,5]  R1134     -5.3757065534591675e-01
    phi[1,5]  R1135     -3.6933586001396179e-02
    phi[5,1]  R9        -1
    phi[5,1]  R45       1
    phi[5,1]  R46       1
    phi[5,1]  R1136     -3.0999999046325684e+00
    phi[5,1]  R1137     -3.0999999046325684e+00
    phi[5,1]  R1138     -2.2400000095367432e+00
    phi[5,1]  R1139     -2.2400000095367432e+00
    phi[5,1]  R1140     -3.0999999046325684e+00
    phi[5,1]  R1141     -3.0999999046325684e+00
    phi[5,1]  R1142     -2.5699999332427979e+00
    phi[5,1]  R1143     -2.5699999332427979e+00
    phi[5,1]  R1144     -3.0999999046325684e+00
    phi[5,1]  R1145     -3.0999999046325684e+00
    phi[5,1]  R1146     -2.0899999141693115e+00
    phi[5,1]  R1147     -2.0899999141693115e+00
    phi[5,1]  R1148     -3.0999999046325684e+00
    phi[5,1]  R1149     -3.0999999046325684e+00
    phi[5,1]  R1150     2.8414392471313477e-01
    phi[5,1]  R1151     -8.0679035186767578e-01
    phi[5,1]  R1152     -1.1893633753061295e-01
    phi[5,1]  R1153     1.5230422019958496e+00
    phi[5,1]  R1154     7.2793298959732056e-01
    phi[5,1]  R1155     -1.4463989436626434e-01
    phi[5,1]  R1156     1.1948866844177246e+00
    phi[5,1]  R1157     9.0794456005096436e-01
    phi[5,1]  R1158     -1.2591454386711121e-01
    phi[5,1]  R1159     1.7452241182327271e+00
    phi[5,1]  R1160     -2.8261013031005859e+00
    phi[5,1]  R1161     -9.4937264919281006e-01
    phi[5,1]  R1162     -3.5499542951583862e-01
    phi[5,1]  R1163     -3.9355948567390442e-02
    phi[5,1]  R1164     -2.1837933063507080e+00
    phi[5,1]  R1165     3.4433159232139587e-01
    phi[5,1]  R1166     -9.2684447765350342e-01
    phi[5,1]  R1167     -4.4330008327960968e-02
    phi[5,1]  R1168     -6.8314790725708008e-01
    phi[5,1]  R1169     -2.8046682476997375e-01
    phi[5,1]  R1170     -1.0717215538024902e+00
    phi[5,1]  R1171     -2.1858029365539551e+00
    phi[5,1]  R1172     -2.9832825660705566e+00
    phi[5,1]  R1173     2.1295222640037537e-01
    phi[5,1]  R1174     -2.1082291603088379e+00
    phi[5,1]  R1175     -3.1869323253631592e+00
    phi[5,1]  R1176     -3.1646850109100342e+00
    phi[5,1]  R1177     1.4179245233535767e+00
    phi[5,1]  R1178     -2.3230087757110596e+00
    phi[5,1]  R1179     -3.3502440452575684e+00
    phi[5,1]  R1180     -1.4843820333480835e+00
    phi[5,1]  R1181     -2.95682430267334
    phi[5,1]  R1182     -1.2104443311691284e+00
    phi[5,1]  R1183     -1.9855084419250488e+00
    phi[5,1]  R1184     -1.9198642969131470e+00
    phi[5,1]  R1185     -2.7418620586395264e+00
    phi[5,1]  R1186     1.8515779972076416e+00
    phi[5,1]  R1187     -1.7986783981323242e+00
    phi[5,1]  R1188     -1.0878798961639404e+00
    phi[5,1]  R1189     4.8712402582168579e-01
    phi[5,1]  R1190     -2.8415971994400024e-01
    phi[5,1]  R1191     -1.2536016702651978e+00
    phi[5,1]  R1192     -2.3093726634979248e+00
    phi[5,1]  R1193     -1.4188036322593689e-01
    phi[5,1]  R1194     -1.7499494552612305e+00
    phi[5,1]  R1195     -1.4156135320663452e+00
    phi[5,1]  R1196     -1.7478259801864624e+00
    phi[5,1]  R1197     -1.1277546882629395e+00
    phi[5,1]  R1198     -2.4227716028690338e-01
    phi[5,1]  R1199     -2.7006061077117920e+00
    phi[5,1]  R1200     -4.3319725990295410e-01
    phi[5,1]  R1201     -3.1303146481513977e-01
    phi[5,1]  R1202     -1.4981080293655396e+00
    phi[5,1]  R1203     -1.0864914953708649e-01
    phi[5,1]  R1204     -2.4950990676879883e+00
    phi[5,1]  R1205     2.6497811079025269e-01
    phi[5,1]  R1206     -1.4847133159637451e+00
    phi[5,1]  R1207     -1.6127809286117554e+00
    phi[5,1]  R1208     -2.7393848896026611e+00
    phi[5,1]  R1209     -7.0934897661209106e-01
    phi[5,1]  R1210     -2.1147117614746094e+00
    phi[5,1]  R1211     -2.0120551586151123e+00
    phi[5,1]  R1212     -1.2092066556215286e-01
    phi[5,1]  R1213     1.9460766017436981e-01
    phi[5,1]  R1214     -1.5705695375800133e-02
    phi[5,1]  R1215     0.419849157333374
    phi[5,1]  R1216     -1.9804681539535522e+00
    phi[5,1]  R1217     8.6963987350463867e-01
    phi[5,1]  R1218     -2.4987779557704926e-01
    phi[5,1]  R1219     -9.9948549270629883e-01
    phi[5,1]  R1220     -3.9563268423080444e-01
    phi[5,1]  R1221     -3.3903102874755859e+00
    phi[5,1]  R1222     -1.3080577850341797e+00
    phi[5,1]  R1223     -1.3100939989089966e+00
    phi[5,1]  R1224     -2.9573016166687012e+00
    phi[5,1]  R1225     -3.5129386186599731e-01
    phi[5,1]  R1226     -1.6469752788543701e+00
    phi[5,1]  R1227     1.7266348004341125e-01
    phi[5,1]  R1228     -5.3757065534591675e-01
    phi[5,1]  R1229     -3.6933586001396179e-02
    phi[5,1]  R1230     -5.3848731517791748e-01
    phi[5,1]  R1231     -5.6913875043392181e-02
    phi[5,1]  R1232     -4.7335222363471985e-01
    phi[5,1]  R1233     -7.0460289716720581e-02
    phi[5,1]  R1234     -5.4341918230056763e-01
    phi[5,1]  R1235     -2.0838913321495056e-01
    phi[5,1]  R1236     -7.7236875891685486e-02
    phi[5,1]  R1237     -1.0334223508834839e-01
    phi[5,1]  R1238     -9.2117607593536377e-01
    phi[5,1]  R1239     -9.6261298656463623e-01
    phi[5,1]  R1240     -5.4849022626876831e-01
    phi[5,1]  R1241     -4.4594958424568176e-01
    phi[5,1]  R1242     5.7942576706409454e-02
    phi[5,1]  R1243     -0.422661691904068
    phi[5,1]  R1244     -6.2049329280853271e-01
    phi[5,1]  R1245     -3.6150512099266052e-01
    phi[5,1]  R1246     2.8013634681701660e-01
    phi[5,1]  R1247     -3.7358406186103821e-01
    phi[5,1]  R1248     -4.0827322006225586e-01
    phi[5,1]  R1249     -1.0542370080947876e+00
    phi[5,1]  R1250     -7.9945939779281616e-01
    phi[5,1]  R1251     -4.1097530722618103e-01
    phi[5,1]  R1252     0.0332217663526535
    phi[5,1]  R1253     -1.7338870093226433e-02
    phi[5,1]  R1254     -1.7940394580364227e-01
    phi[5,1]  R1255     -2.0023712515830994e-01
    phi[5,1]  R1256     -1.2310332059860229e+00
    phi[5,1]  R1257     5.9351670742034912e-01
    phi[5,1]  R1258     -6.3431960344314575e-01
    phi[5,1]  R1259     -1.1345435380935669e+00
    phi[5,1]  R1260     -1.0727311372756958e+00
    phi[5,1]  R1261     -1.6438180208206177e-01
    phi[5,1]  R1262     -4.7152754664421082e-01
    phi[5,1]  R1263     -3.1429141759872437e-01
    phi[5,1]  R1264     -2.3560506105422974e-01
    phi[5,1]  R1265     -2.7584062889218330e-02
    phi[5,1]  R1266     -3.6491242051124573e-01
    phi[5,1]  R1267     -9.5044940710067749e-01
    phi[5,1]  R1268     -1.2566862106323242e+00
    phi[5,1]  R1269     -1.5598497390747070e+00
    phi[2,4]  R18       1
    phi[2,4]  R19       1
    phi[2,4]  R36       -1
    phi[2,4]  R1270     -3.0999999046325684e+00
    phi[2,4]  R1271     -3.0999999046325684e+00
    phi[2,4]  R1272     -2.2400000095367432e+00
    phi[2,4]  R1273     -2.2400000095367432e+00
    phi[2,4]  R1274     -3.0999999046325684e+00
    phi[2,4]  R1275     -3.0999999046325684e+00
    phi[2,4]  R1276     -2.5699999332427979e+00
    phi[2,4]  R1277     -2.5699999332427979e+00
    phi[2,4]  R1278     -3.0999999046325684e+00
    phi[2,4]  R1279     -3.0999999046325684e+00
    phi[2,4]  R1280     -2.0899999141693115e+00
    phi[2,4]  R1281     -2.0899999141693115e+00
    phi[2,4]  R1282     -3.0999999046325684e+00
    phi[2,4]  R1283     -3.0999999046325684e+00
    phi[2,4]  R1284     8.6888474225997925e-01
    phi[2,4]  R1285     1.2631245851516724e+00
    phi[2,4]  R1286     5.8422349393367767e-02
    phi[2,4]  R1287     -5.3490829467773438e-01
    phi[2,4]  R1288     -1.8546824157238007e-01
    phi[2,4]  R1289     -1.0336734056472778e+00
    phi[2,4]  R1290     1.2444587796926498e-01
    phi[2,4]  R1291     0.0924357995390892
    phi[2,4]  R1292     -9.4308412075042725e-01
    phi[2,4]  R1293     8.8834607601165771e-01
    phi[2,4]  R1294     1.8743423223495483e+00
    phi[2,4]  R1295     1.3800209760665894e+00
    phi[2,4]  R1296     7.9257005453109741e-01
    phi[2,4]  R1297     1.0193324089050293e+00
    phi[2,4]  R1298     1.2950372695922852e+00
    phi[2,4]  R1299     -6.5510910749435425e-01
    phi[2,4]  R1300     7.4543076753616333e-01
    phi[2,4]  R1301     1.9147914648056030e+00
    phi[2,4]  R1302     7.5920188426971436e-01
    phi[2,4]  R1303     1.7236145734786987e+00
    phi[2,4]  R1304     -2.7206065654754639e+00
    phi[2,4]  R1305     -1.7157231569290161e+00
    phi[2,4]  R1306     -2.1009018421173096e+00
    phi[2,4]  R1307     -1.7083665132522583e+00
    phi[2,4]  R1308     -7.9749459028244019e-01
    phi[2,4]  R1309     -2.0797948837280273e+00
    phi[2,4]  R1310     -7.3608511686325073e-01
    phi[2,4]  R1311     -1.9498858451843262e+00
    phi[2,4]  R1312     1.6095927357673645e-01
    phi[2,4]  R1313     -1.0621354579925537e+00
    phi[2,4]  R1314     -2.3725574016571045e+00
    phi[2,4]  R1315     -1.5226991176605225e+00
    phi[2,4]  R1316     -3.9799737930297852e-01
    phi[2,4]  R1317     -1.7305209636688232e+00
    phi[2,4]  R1318     -1.7774429321289062e+00
    phi[2,4]  R1319     -2.5589108467102051e+00
    phi[2,4]  R1320     -2.4984819889068604e+00
    phi[2,4]  R1321     -8.4011447429656982e-01
    phi[2,4]  R1322     -2.0023903846740723e+00
    phi[2,4]  R1323     -1.9811100959777832e+00
    phi[2,4]  R1324     -2.1344709396362305e+00
    phi[2,4]  R1325     -2.4273073673248291e+00
    phi[2,4]  R1326     -9.2546486854553223e-01
    phi[2,4]  R1327     -9.6670711040496826e-01
    phi[2,4]  R1328     -2.0022168159484863e+00
    phi[2,4]  R1329     -1.8197969198226929e+00
    phi[2,4]  R1330     -5.1182305812835693e-01
    phi[2,4]  R1331     -2.3194580078125
    phi[2,4]  R1332     -3.0017659068107605e-01
    phi[2,4]  R1333     1.0696269273757935e+00
    phi[2,4]  R1334     -2.4927549362182617e+00
    phi[2,4]  R1335     -1.0444631576538086e+00
    phi[2,4]  R1336     -3.7102723121643066e-01
    phi[2,4]  R1337     -2.2414700984954834e+00
    phi[2,4]  R1338     -1.4155066013336182e+00
    phi[2,4]  R1339     -2.6036414504051208e-01
    phi[2,4]  R1340     -2.6354405283927917e-01
    phi[2,4]  R1341     1.3174796104431152e+00
    phi[2,4]  R1342     -7.7785408496856689e-01
    phi[2,4]  R1343     -4.1983652114868164e-01
    phi[2,4]  R1344     -8.2193863391876221e-01
    phi[2,4]  R1345     -1.5372793674468994e+00
    phi[2,4]  R1346     -2.2401053905487061e+00
    phi[2,4]  R1347     -5.4478609561920166e-01
    phi[2,4]  R1348     5.8045393228530884e-01
    phi[2,4]  R1349     -2.1973342895507812e+00
    phi[2,4]  R1350     -6.3260859251022339e-01
    phi[2,4]  R1351     -1.1133118867874146e+00
    phi[2,4]  R1352     -3.2645177841186523e+00
    phi[2,4]  R1353     -5.3573942184448242e-01
    phi[2,4]  R1354     5.3010648116469383e-03
    phi[2,4]  R1355     -7.7004718780517578e-01
    phi[2,4]  R1356     -4.4023880362510681e-01
    phi[2,4]  R1357     4.4781726598739624e-01
    phi[2,4]  R1358     -2.0931883156299591e-01
    phi[2,4]  R1359     1.0946505069732666e+00
    phi[2,4]  R1360     3.7301298975944519e-01
    phi[2,4]  R1361     -7.7773980796337128e-02
    phi[2,4]  R1362     -3.1244492530822754e-01
    phi[2,4]  R1363     -9.1448360681533813e-01
    phi[2,4]  R1364     3.2370540499687195e-01
    phi[2,4]  R1365     -2.7513947486877441e+00
    phi[2,4]  R1366     -3.9884489774703979e-01
    phi[2,4]  R1367     -3.3851286768913269e-01
    phi[2,4]  R1368     -1.2109183520078659e-01
    phi[2,4]  R1369     -1.3731625080108643e+00
    phi[2,4]  R1370     -9.2978693544864655e-02
    phi[2,4]  R1371     3.0590891838073730e-01
    phi[2,4]  R1372     -1.8442462682724
    phi[2,4]  R1373     -2.0396001338958740e+00
    phi[2,4]  R1374     -1.2676380574703217e-01
    phi[2,4]  R1375     -1.1865367889404297e+00
    phi[2,4]  R1376     -4.0671494603157043e-01
    phi[2,4]  R1377     -1.9195091724395752e+00
    phi[2,4]  R1378     -2.2505238056182861e+00
    phi[2,4]  R1379     -2.84623384475708
    phi[2,4]  R1380     1.3926053047180176e-01
    phi[2,4]  R1381     -1.7129764556884766e+00
    phi[2,4]  R1382     1.0084869861602783e+00
    phi[2,4]  R1383     1.0873062610626221e+00
    phi[4,2]  R18       -1
    phi[4,2]  R36       1
    phi[4,2]  R37       1
    phi[4,2]  R1384     -3.0999999046325684e+00
    phi[4,2]  R1385     -3.0999999046325684e+00
    phi[4,2]  R1386     -2.2400000095367432e+00
    phi[4,2]  R1387     -2.2400000095367432e+00
    phi[4,2]  R1388     -3.0999999046325684e+00
    phi[4,2]  R1389     -3.0999999046325684e+00
    phi[4,2]  R1390     -2.5699999332427979e+00
    phi[4,2]  R1391     -2.5699999332427979e+00
    phi[4,2]  R1392     -3.0999999046325684e+00
    phi[4,2]  R1393     -3.0999999046325684e+00
    phi[4,2]  R1394     -2.0899999141693115e+00
    phi[4,2]  R1395     -2.0899999141693115e+00
    phi[4,2]  R1396     -3.0999999046325684e+00
    phi[4,2]  R1397     -3.0999999046325684e+00
    phi[4,2]  R1398     5.3010648116469383e-03
    phi[4,2]  R1399     -7.7004718780517578e-01
    phi[4,2]  R1400     -4.4023880362510681e-01
    phi[4,2]  R1401     4.4781726598739624e-01
    phi[4,2]  R1402     -2.0931883156299591e-01
    phi[4,2]  R1403     1.0946505069732666e+00
    phi[4,2]  R1404     3.7301298975944519e-01
    phi[4,2]  R1405     -7.7773980796337128e-02
    phi[4,2]  R1406     -3.1244492530822754e-01
    phi[4,2]  R1407     -9.1448360681533813e-01
    phi[4,2]  R1408     3.2370540499687195e-01
    phi[4,2]  R1409     -2.7513947486877441e+00
    phi[4,2]  R1410     -3.9884489774703979e-01
    phi[4,2]  R1411     -3.3851286768913269e-01
    phi[4,2]  R1412     -1.2109183520078659e-01
    phi[4,2]  R1413     -1.3731625080108643e+00
    phi[4,2]  R1414     -9.2978693544864655e-02
    phi[4,2]  R1415     3.0590891838073730e-01
    phi[4,2]  R1416     -1.8442462682724
    phi[4,2]  R1417     -2.0396001338958740e+00
    phi[4,2]  R1418     -1.2676380574703217e-01
    phi[4,2]  R1419     -1.1865367889404297e+00
    phi[4,2]  R1420     -4.0671494603157043e-01
    phi[4,2]  R1421     -1.9195091724395752e+00
    phi[4,2]  R1422     -2.2505238056182861e+00
    phi[4,2]  R1423     -2.84623384475708
    phi[4,2]  R1424     1.3926053047180176e-01
    phi[4,2]  R1425     -1.7129764556884766e+00
    phi[4,2]  R1426     1.0084869861602783e+00
    phi[4,2]  R1427     1.0873062610626221e+00
    phi[4,2]  R1428     8.6888474225997925e-01
    phi[4,2]  R1429     1.2631245851516724e+00
    phi[4,2]  R1430     5.8422349393367767e-02
    phi[4,2]  R1431     -5.3490829467773438e-01
    phi[4,2]  R1432     -1.8546824157238007e-01
    phi[4,2]  R1433     -1.0336734056472778e+00
    phi[4,2]  R1434     1.2444587796926498e-01
    phi[4,2]  R1435     0.0924357995390892
    phi[4,2]  R1436     -9.4308412075042725e-01
    phi[4,2]  R1437     8.8834607601165771e-01
    phi[4,2]  R1438     1.8743423223495483e+00
    phi[4,2]  R1439     1.3800209760665894e+00
    phi[4,2]  R1440     7.9257005453109741e-01
    phi[4,2]  R1441     1.0193324089050293e+00
    phi[4,2]  R1442     1.2950372695922852e+00
    phi[4,2]  R1443     -6.5510910749435425e-01
    phi[4,2]  R1444     7.4543076753616333e-01
    phi[4,2]  R1445     1.9147914648056030e+00
    phi[4,2]  R1446     7.5920188426971436e-01
    phi[4,2]  R1447     1.7236145734786987e+00
    phi[4,2]  R1448     -2.7206065654754639e+00
    phi[4,2]  R1449     -1.7157231569290161e+00
    phi[4,2]  R1450     -2.1009018421173096e+00
    phi[4,2]  R1451     -1.7083665132522583e+00
    phi[4,2]  R1452     -7.9749459028244019e-01
    phi[4,2]  R1453     -2.0797948837280273e+00
    phi[4,2]  R1454     -7.3608511686325073e-01
    phi[4,2]  R1455     -1.9498858451843262e+00
    phi[4,2]  R1456     1.6095927357673645e-01
    phi[4,2]  R1457     -1.0621354579925537e+00
    phi[4,2]  R1458     -2.3725574016571045e+00
    phi[4,2]  R1459     -1.5226991176605225e+00
    phi[4,2]  R1460     -3.9799737930297852e-01
    phi[4,2]  R1461     -1.7305209636688232e+00
    phi[4,2]  R1462     -1.7774429321289062e+00
    phi[4,2]  R1463     -2.5589108467102051e+00
    phi[4,2]  R1464     -2.4984819889068604e+00
    phi[4,2]  R1465     -8.4011447429656982e-01
    phi[4,2]  R1466     -2.0023903846740723e+00
    phi[4,2]  R1467     -1.9811100959777832e+00
    phi[4,2]  R1468     -2.1344709396362305e+00
    phi[4,2]  R1469     -2.4273073673248291e+00
    phi[4,2]  R1470     -9.2546486854553223e-01
    phi[4,2]  R1471     -9.6670711040496826e-01
    phi[4,2]  R1472     -2.0022168159484863e+00
    phi[4,2]  R1473     -1.8197969198226929e+00
    phi[4,2]  R1474     -5.1182305812835693e-01
    phi[4,2]  R1475     -2.3194580078125
    phi[4,2]  R1476     -3.0017659068107605e-01
    phi[4,2]  R1477     1.0696269273757935e+00
    phi[4,2]  R1478     -2.4927549362182617e+00
    phi[4,2]  R1479     -1.0444631576538086e+00
    phi[4,2]  R1480     -3.7102723121643066e-01
    phi[4,2]  R1481     -2.2414700984954834e+00
    phi[4,2]  R1482     -1.4155066013336182e+00
    phi[4,2]  R1483     -2.6036414504051208e-01
    phi[4,2]  R1484     -2.6354405283927917e-01
    phi[4,2]  R1485     1.3174796104431152e+00
    phi[4,2]  R1486     -7.7785408496856689e-01
    phi[4,2]  R1487     -4.1983652114868164e-01
    phi[4,2]  R1488     -8.2193863391876221e-01
    phi[4,2]  R1489     -1.5372793674468994e+00
    phi[4,2]  R1490     -2.2401053905487061e+00
    phi[4,2]  R1491     -5.4478609561920166e-01
    phi[4,2]  R1492     5.8045393228530884e-01
    phi[4,2]  R1493     -2.1973342895507812e+00
    phi[4,2]  R1494     -6.3260859251022339e-01
    phi[4,2]  R1495     -1.1133118867874146e+00
    phi[4,2]  R1496     -3.2645177841186523e+00
    phi[4,2]  R1497     -5.3573942184448242e-01
    phi[2,5]  R18       1
    phi[2,5]  R19       1
    phi[2,5]  R45       -1
    phi[2,5]  R1498     -3.0999999046325684e+00
    phi[2,5]  R1499     -3.0999999046325684e+00
    phi[2,5]  R1500     -2.2400000095367432e+00
    phi[2,5]  R1501     -2.2400000095367432e+00
    phi[2,5]  R1502     -3.0999999046325684e+00
    phi[2,5]  R1503     -3.0999999046325684e+00
    phi[2,5]  R1504     -2.5699999332427979e+00
    phi[2,5]  R1505     -2.5699999332427979e+00
    phi[2,5]  R1506     -3.0999999046325684e+00
    phi[2,5]  R1507     -3.0999999046325684e+00
    phi[2,5]  R1508     -2.0899999141693115e+00
    phi[2,5]  R1509     -2.0899999141693115e+00
    phi[2,5]  R1510     -3.0999999046325684e+00
    phi[2,5]  R1511     -3.0999999046325684e+00
    phi[2,5]  R1512     8.6888474225997925e-01
    phi[2,5]  R1513     1.2631245851516724e+00
    phi[2,5]  R1514     5.8422349393367767e-02
    phi[2,5]  R1515     -5.3490829467773438e-01
    phi[2,5]  R1516     -1.8546824157238007e-01
    phi[2,5]  R1517     -1.0336734056472778e+00
    phi[2,5]  R1518     1.2444587796926498e-01
    phi[2,5]  R1519     0.0924357995390892
    phi[2,5]  R1520     -9.4308412075042725e-01
    phi[2,5]  R1521     8.8834607601165771e-01
    phi[2,5]  R1522     1.8743423223495483e+00
    phi[2,5]  R1523     1.3800209760665894e+00
    phi[2,5]  R1524     7.9257005453109741e-01
    phi[2,5]  R1525     1.0193324089050293e+00
    phi[2,5]  R1526     1.2950372695922852e+00
    phi[2,5]  R1527     -6.5510910749435425e-01
    phi[2,5]  R1528     7.4543076753616333e-01
    phi[2,5]  R1529     1.9147914648056030e+00
    phi[2,5]  R1530     7.5920188426971436e-01
    phi[2,5]  R1531     1.7236145734786987e+00
    phi[2,5]  R1532     -2.7206065654754639e+00
    phi[2,5]  R1533     -1.7157231569290161e+00
    phi[2,5]  R1534     -2.1009018421173096e+00
    phi[2,5]  R1535     -1.7083665132522583e+00
    phi[2,5]  R1536     -7.9749459028244019e-01
    phi[2,5]  R1537     -2.0797948837280273e+00
    phi[2,5]  R1538     -7.3608511686325073e-01
    phi[2,5]  R1539     -1.9498858451843262e+00
    phi[2,5]  R1540     1.6095927357673645e-01
    phi[2,5]  R1541     -1.0621354579925537e+00
    phi[2,5]  R1542     -2.3725574016571045e+00
    phi[2,5]  R1543     -1.5226991176605225e+00
    phi[2,5]  R1544     -3.9799737930297852e-01
    phi[2,5]  R1545     -1.7305209636688232e+00
    phi[2,5]  R1546     -1.7774429321289062e+00
    phi[2,5]  R1547     -2.5589108467102051e+00
    phi[2,5]  R1548     -2.4984819889068604e+00
    phi[2,5]  R1549     -8.4011447429656982e-01
    phi[2,5]  R1550     -2.0023903846740723e+00
    phi[2,5]  R1551     -1.9811100959777832e+00
    phi[2,5]  R1552     -2.1344709396362305e+00
    phi[2,5]  R1553     -2.4273073673248291e+00
    phi[2,5]  R1554     -9.2546486854553223e-01
    phi[2,5]  R1555     -9.6670711040496826e-01
    phi[2,5]  R1556     -2.0022168159484863e+00
    phi[2,5]  R1557     -1.8197969198226929e+00
    phi[2,5]  R1558     -5.1182305812835693e-01
    phi[2,5]  R1559     -2.3194580078125
    phi[2,5]  R1560     -3.0017659068107605e-01
    phi[2,5]  R1561     1.0696269273757935e+00
    phi[2,5]  R1562     -2.4927549362182617e+00
    phi[2,5]  R1563     -1.0444631576538086e+00
    phi[2,5]  R1564     -3.7102723121643066e-01
    phi[2,5]  R1565     -2.2414700984954834e+00
    phi[2,5]  R1566     -1.4155066013336182e+00
    phi[2,5]  R1567     -2.6036414504051208e-01
    phi[2,5]  R1568     -2.6354405283927917e-01
    phi[2,5]  R1569     1.3174796104431152e+00
    phi[2,5]  R1570     -7.7785408496856689e-01
    phi[2,5]  R1571     -4.1983652114868164e-01
    phi[2,5]  R1572     -8.2193863391876221e-01
    phi[2,5]  R1573     -1.5372793674468994e+00
    phi[2,5]  R1574     -2.2401053905487061e+00
    phi[2,5]  R1575     -5.4478609561920166e-01
    phi[2,5]  R1576     5.8045393228530884e-01
    phi[2,5]  R1577     -2.1973342895507812e+00
    phi[2,5]  R1578     -6.3260859251022339e-01
    phi[2,5]  R1579     -1.1133118867874146e+00
    phi[2,5]  R1580     -3.2645177841186523e+00
    phi[2,5]  R1581     -5.3573942184448242e-01
    phi[2,5]  R1582     2.8414392471313477e-01
    phi[2,5]  R1583     -8.0679035186767578e-01
    phi[2,5]  R1584     -1.1893633753061295e-01
    phi[2,5]  R1585     1.5230422019958496e+00
    phi[2,5]  R1586     7.2793298959732056e-01
    phi[2,5]  R1587     -1.4463989436626434e-01
    phi[2,5]  R1588     1.1948866844177246e+00
    phi[2,5]  R1589     9.0794456005096436e-01
    phi[2,5]  R1590     -1.2591454386711121e-01
    phi[2,5]  R1591     1.7452241182327271e+00
    phi[2,5]  R1592     -2.8261013031005859e+00
    phi[2,5]  R1593     -9.4937264919281006e-01
    phi[2,5]  R1594     -3.5499542951583862e-01
    phi[2,5]  R1595     -3.9355948567390442e-02
    phi[2,5]  R1596     -2.1837933063507080e+00
    phi[2,5]  R1597     3.4433159232139587e-01
    phi[2,5]  R1598     -9.2684447765350342e-01
    phi[2,5]  R1599     -4.4330008327960968e-02
    phi[2,5]  R1600     -6.8314790725708008e-01
    phi[2,5]  R1601     -2.8046682476997375e-01
    phi[2,5]  R1602     -1.0717215538024902e+00
    phi[2,5]  R1603     -2.1858029365539551e+00
    phi[2,5]  R1604     -2.9832825660705566e+00
    phi[2,5]  R1605     2.1295222640037537e-01
    phi[2,5]  R1606     -2.1082291603088379e+00
    phi[2,5]  R1607     -3.1869323253631592e+00
    phi[2,5]  R1608     -3.1646850109100342e+00
    phi[2,5]  R1609     1.4179245233535767e+00
    phi[2,5]  R1610     -2.3230087757110596e+00
    phi[2,5]  R1611     -3.3502440452575684e+00
    phi[2,5]  R1612     -1.4843820333480835e+00
    phi[2,5]  R1613     -2.95682430267334
    phi[2,5]  R1614     -1.2104443311691284e+00
    phi[2,5]  R1615     -1.9855084419250488e+00
    phi[2,5]  R1616     -1.9198642969131470e+00
    phi[2,5]  R1617     -2.7418620586395264e+00
    phi[2,5]  R1618     1.8515779972076416e+00
    phi[2,5]  R1619     -1.7986783981323242e+00
    phi[2,5]  R1620     -1.0878798961639404e+00
    phi[2,5]  R1621     4.8712402582168579e-01
    phi[2,5]  R1622     -2.8415971994400024e-01
    phi[2,5]  R1623     -1.2536016702651978e+00
    phi[2,5]  R1624     -2.3093726634979248e+00
    phi[2,5]  R1625     -1.4188036322593689e-01
    phi[2,5]  R1626     -1.7499494552612305e+00
    phi[2,5]  R1627     -1.4156135320663452e+00
    phi[2,5]  R1628     -1.7478259801864624e+00
    phi[2,5]  R1629     -1.1277546882629395e+00
    phi[2,5]  R1630     -2.4227716028690338e-01
    phi[2,5]  R1631     -2.7006061077117920e+00
    phi[2,5]  R1632     -4.3319725990295410e-01
    phi[2,5]  R1633     -3.1303146481513977e-01
    phi[2,5]  R1634     -1.4981080293655396e+00
    phi[2,5]  R1635     -1.0864914953708649e-01
    phi[2,5]  R1636     -2.4950990676879883e+00
    phi[2,5]  R1637     2.6497811079025269e-01
    phi[2,5]  R1638     -1.4847133159637451e+00
    phi[2,5]  R1639     -1.6127809286117554e+00
    phi[2,5]  R1640     -2.7393848896026611e+00
    phi[2,5]  R1641     -7.0934897661209106e-01
    phi[2,5]  R1642     -2.1147117614746094e+00
    phi[2,5]  R1643     -2.0120551586151123e+00
    phi[2,5]  R1644     -1.2092066556215286e-01
    phi[2,5]  R1645     1.9460766017436981e-01
    phi[2,5]  R1646     -1.5705695375800133e-02
    phi[2,5]  R1647     0.419849157333374
    phi[2,5]  R1648     -1.9804681539535522e+00
    phi[2,5]  R1649     8.6963987350463867e-01
    phi[2,5]  R1650     -2.4987779557704926e-01
    phi[2,5]  R1651     -9.9948549270629883e-01
    phi[2,5]  R1652     -3.9563268423080444e-01
    phi[2,5]  R1653     -3.3903102874755859e+00
    phi[2,5]  R1654     -1.3080577850341797e+00
    phi[2,5]  R1655     -1.3100939989089966e+00
    phi[2,5]  R1656     -2.9573016166687012e+00
    phi[2,5]  R1657     -3.5129386186599731e-01
    phi[2,5]  R1658     -1.6469752788543701e+00
    phi[2,5]  R1659     1.7266348004341125e-01
    phi[2,5]  R1660     -5.3757065534591675e-01
    phi[2,5]  R1661     -3.6933586001396179e-02
    phi[5,2]  R18       -1
    phi[5,2]  R45       1
    phi[5,2]  R46       1
    phi[5,2]  R1662     -3.0999999046325684e+00
    phi[5,2]  R1663     -3.0999999046325684e+00
    phi[5,2]  R1664     -2.2400000095367432e+00
    phi[5,2]  R1665     -2.2400000095367432e+00
    phi[5,2]  R1666     -3.0999999046325684e+00
    phi[5,2]  R1667     -3.0999999046325684e+00
    phi[5,2]  R1668     -2.5699999332427979e+00
    phi[5,2]  R1669     -2.5699999332427979e+00
    phi[5,2]  R1670     -3.0999999046325684e+00
    phi[5,2]  R1671     -3.0999999046325684e+00
    phi[5,2]  R1672     -2.0899999141693115e+00
    phi[5,2]  R1673     -2.0899999141693115e+00
    phi[5,2]  R1674     -3.0999999046325684e+00
    phi[5,2]  R1675     -3.0999999046325684e+00
    phi[5,2]  R1676     2.8414392471313477e-01
    phi[5,2]  R1677     -8.0679035186767578e-01
    phi[5,2]  R1678     -1.1893633753061295e-01
    phi[5,2]  R1679     1.5230422019958496e+00
    phi[5,2]  R1680     7.2793298959732056e-01
    phi[5,2]  R1681     -1.4463989436626434e-01
    phi[5,2]  R1682     1.1948866844177246e+00
    phi[5,2]  R1683     9.0794456005096436e-01
    phi[5,2]  R1684     -1.2591454386711121e-01
    phi[5,2]  R1685     1.7452241182327271e+00
    phi[5,2]  R1686     -2.8261013031005859e+00
    phi[5,2]  R1687     -9.4937264919281006e-01
    phi[5,2]  R1688     -3.5499542951583862e-01
    phi[5,2]  R1689     -3.9355948567390442e-02
    phi[5,2]  R1690     -2.1837933063507080e+00
    phi[5,2]  R1691     3.4433159232139587e-01
    phi[5,2]  R1692     -9.2684447765350342e-01
    phi[5,2]  R1693     -4.4330008327960968e-02
    phi[5,2]  R1694     -6.8314790725708008e-01
    phi[5,2]  R1695     -2.8046682476997375e-01
    phi[5,2]  R1696     -1.0717215538024902e+00
    phi[5,2]  R1697     -2.1858029365539551e+00
    phi[5,2]  R1698     -2.9832825660705566e+00
    phi[5,2]  R1699     2.1295222640037537e-01
    phi[5,2]  R1700     -2.1082291603088379e+00
    phi[5,2]  R1701     -3.1869323253631592e+00
    phi[5,2]  R1702     -3.1646850109100342e+00
    phi[5,2]  R1703     1.4179245233535767e+00
    phi[5,2]  R1704     -2.3230087757110596e+00
    phi[5,2]  R1705     -3.3502440452575684e+00
    phi[5,2]  R1706     -1.4843820333480835e+00
    phi[5,2]  R1707     -2.95682430267334
    phi[5,2]  R1708     -1.2104443311691284e+00
    phi[5,2]  R1709     -1.9855084419250488e+00
    phi[5,2]  R1710     -1.9198642969131470e+00
    phi[5,2]  R1711     -2.7418620586395264e+00
    phi[5,2]  R1712     1.8515779972076416e+00
    phi[5,2]  R1713     -1.7986783981323242e+00
    phi[5,2]  R1714     -1.0878798961639404e+00
    phi[5,2]  R1715     4.8712402582168579e-01
    phi[5,2]  R1716     -2.8415971994400024e-01
    phi[5,2]  R1717     -1.2536016702651978e+00
    phi[5,2]  R1718     -2.3093726634979248e+00
    phi[5,2]  R1719     -1.4188036322593689e-01
    phi[5,2]  R1720     -1.7499494552612305e+00
    phi[5,2]  R1721     -1.4156135320663452e+00
    phi[5,2]  R1722     -1.7478259801864624e+00
    phi[5,2]  R1723     -1.1277546882629395e+00
    phi[5,2]  R1724     -2.4227716028690338e-01
    phi[5,2]  R1725     -2.7006061077117920e+00
    phi[5,2]  R1726     -4.3319725990295410e-01
    phi[5,2]  R1727     -3.1303146481513977e-01
    phi[5,2]  R1728     -1.4981080293655396e+00
    phi[5,2]  R1729     -1.0864914953708649e-01
    phi[5,2]  R1730     -2.4950990676879883e+00
    phi[5,2]  R1731     2.6497811079025269e-01
    phi[5,2]  R1732     -1.4847133159637451e+00
    phi[5,2]  R1733     -1.6127809286117554e+00
    phi[5,2]  R1734     -2.7393848896026611e+00
    phi[5,2]  R1735     -7.0934897661209106e-01
    phi[5,2]  R1736     -2.1147117614746094e+00
    phi[5,2]  R1737     -2.0120551586151123e+00
    phi[5,2]  R1738     -1.2092066556215286e-01
    phi[5,2]  R1739     1.9460766017436981e-01
    phi[5,2]  R1740     -1.5705695375800133e-02
    phi[5,2]  R1741     0.419849157333374
    phi[5,2]  R1742     -1.9804681539535522e+00
    phi[5,2]  R1743     8.6963987350463867e-01
    phi[5,2]  R1744     -2.4987779557704926e-01
    phi[5,2]  R1745     -9.9948549270629883e-01
    phi[5,2]  R1746     -3.9563268423080444e-01
    phi[5,2]  R1747     -3.3903102874755859e+00
    phi[5,2]  R1748     -1.3080577850341797e+00
    phi[5,2]  R1749     -1.3100939989089966e+00
    phi[5,2]  R1750     -2.9573016166687012e+00
    phi[5,2]  R1751     -3.5129386186599731e-01
    phi[5,2]  R1752     -1.6469752788543701e+00
    phi[5,2]  R1753     1.7266348004341125e-01
    phi[5,2]  R1754     -5.3757065534591675e-01
    phi[5,2]  R1755     -3.6933586001396179e-02
    phi[5,2]  R1756     8.6888474225997925e-01
    phi[5,2]  R1757     1.2631245851516724e+00
    phi[5,2]  R1758     5.8422349393367767e-02
    phi[5,2]  R1759     -5.3490829467773438e-01
    phi[5,2]  R1760     -1.8546824157238007e-01
    phi[5,2]  R1761     -1.0336734056472778e+00
    phi[5,2]  R1762     1.2444587796926498e-01
    phi[5,2]  R1763     0.0924357995390892
    phi[5,2]  R1764     -9.4308412075042725e-01
    phi[5,2]  R1765     8.8834607601165771e-01
    phi[5,2]  R1766     1.8743423223495483e+00
    phi[5,2]  R1767     1.3800209760665894e+00
    phi[5,2]  R1768     7.9257005453109741e-01
    phi[5,2]  R1769     1.0193324089050293e+00
    phi[5,2]  R1770     1.2950372695922852e+00
    phi[5,2]  R1771     -6.5510910749435425e-01
    phi[5,2]  R1772     7.4543076753616333e-01
    phi[5,2]  R1773     1.9147914648056030e+00
    phi[5,2]  R1774     7.5920188426971436e-01
    phi[5,2]  R1775     1.7236145734786987e+00
    phi[5,2]  R1776     -2.7206065654754639e+00
    phi[5,2]  R1777     -1.7157231569290161e+00
    phi[5,2]  R1778     -2.1009018421173096e+00
    phi[5,2]  R1779     -1.7083665132522583e+00
    phi[5,2]  R1780     -7.9749459028244019e-01
    phi[5,2]  R1781     -2.0797948837280273e+00
    phi[5,2]  R1782     -7.3608511686325073e-01
    phi[5,2]  R1783     -1.9498858451843262e+00
    phi[5,2]  R1784     1.6095927357673645e-01
    phi[5,2]  R1785     -1.0621354579925537e+00
    phi[5,2]  R1786     -2.3725574016571045e+00
    phi[5,2]  R1787     -1.5226991176605225e+00
    phi[5,2]  R1788     -3.9799737930297852e-01
    phi[5,2]  R1789     -1.7305209636688232e+00
    phi[5,2]  R1790     -1.7774429321289062e+00
    phi[5,2]  R1791     -2.5589108467102051e+00
    phi[5,2]  R1792     -2.4984819889068604e+00
    phi[5,2]  R1793     -8.4011447429656982e-01
    phi[5,2]  R1794     -2.0023903846740723e+00
    phi[5,2]  R1795     -1.9811100959777832e+00
    phi[5,2]  R1796     -2.1344709396362305e+00
    phi[5,2]  R1797     -2.4273073673248291e+00
    phi[5,2]  R1798     -9.2546486854553223e-01
    phi[5,2]  R1799     -9.6670711040496826e-01
    phi[5,2]  R1800     -2.0022168159484863e+00
    phi[5,2]  R1801     -1.8197969198226929e+00
    phi[5,2]  R1802     -5.1182305812835693e-01
    phi[5,2]  R1803     -2.3194580078125
    phi[5,2]  R1804     -3.0017659068107605e-01
    phi[5,2]  R1805     1.0696269273757935e+00
    phi[5,2]  R1806     -2.4927549362182617e+00
    phi[5,2]  R1807     -1.0444631576538086e+00
    phi[5,2]  R1808     -3.7102723121643066e-01
    phi[5,2]  R1809     -2.2414700984954834e+00
    phi[5,2]  R1810     -1.4155066013336182e+00
    phi[5,2]  R1811     -2.6036414504051208e-01
    phi[5,2]  R1812     -2.6354405283927917e-01
    phi[5,2]  R1813     1.3174796104431152e+00
    phi[5,2]  R1814     -7.7785408496856689e-01
    phi[5,2]  R1815     -4.1983652114868164e-01
    phi[5,2]  R1816     -8.2193863391876221e-01
    phi[5,2]  R1817     -1.5372793674468994e+00
    phi[5,2]  R1818     -2.2401053905487061e+00
    phi[5,2]  R1819     -5.4478609561920166e-01
    phi[5,2]  R1820     5.8045393228530884e-01
    phi[5,2]  R1821     -2.1973342895507812e+00
    phi[5,2]  R1822     -6.3260859251022339e-01
    phi[5,2]  R1823     -1.1133118867874146e+00
    phi[5,2]  R1824     -3.2645177841186523e+00
    phi[5,2]  R1825     -5.3573942184448242e-01
    phi[2,7]  R18       1
    phi[2,7]  R19       1
    phi[2,7]  R20       1.3628997693946137e+00
    phi[2,7]  R21       1.01924182184423
    phi[2,7]  R22       2.1038569914873366e+00
    phi[2,7]  R23       4.7779016334331015e-02
    phi[2,7]  R24       1.6636994450194549e+00
    phi[2,7]  R25       -1.2054864416783269e+00
    phi[2,7]  R26       2.0638702292383542e+00
    phi[2,7]  R55       -1
    phi[2,7]  R1826     -1.7371001352379547e+00
    phi[2,7]  R1827     -4.4628996740271818e+00
    phi[2,7]  R1828     -1.2207581876925131e+00
    phi[2,7]  R1829     -3.2592418313809732e+00
    phi[2,7]  R1830     -9.9614291314523173e-01
    phi[2,7]  R1831     -5.2038568961199054e+00
    phi[2,7]  R1832     -2.5222209169084668e+00
    phi[2,7]  R1833     -2.6177789495771289e+00
    phi[2,7]  R1834     -1.4363004596131135e+00
    phi[2,7]  R1835     -4.7636993496520237e+00
    phi[2,7]  R1836     -3.2954863558476384e+00
    phi[2,7]  R1837     -8.8451347249098466e-01
    phi[2,7]  R1838     -1.0361296753942142e+00
    phi[2,7]  R1839     -5.1638701338709225e+00
    phi[2,7]  R1840     -1.4011555693803897e+00
    phi[2,7]  R1841     -1.0747587755316266e+00
    phi[2,7]  R1842     -1.5845550465587419e+00
    phi[2,7]  R1843     -2.0282357798272139e+00
    phi[2,7]  R1844     -1.2093618605428351e+00
    phi[2,7]  R1845     -8.0592565183358966e-01
    phi[2,7]  R1846     -1.0304402120520151e+00
    phi[2,7]  R1847     -1.4137480327828917e+00
    phi[2,7]  R1848     -4.4919716708011237e-01
    phi[2,7]  R1849     -1.1876872040254742e+00
    phi[2,7]  R1850     -4.2466178998230930e-01
    phi[2,7]  R1851     -4.4256786661528635e-01
    phi[2,7]  R1852     -4.4397152613305169e-01
    phi[2,7]  R1853     -4.5327781012553681e-01
    phi[2,7]  R1854     -4.7343071274165149e-01
    phi[2,7]  R1855     -4.7583573551700664e-01
    phi[2,7]  R1856     -4.7960047706287057e-01
    phi[2,7]  R1857     -4.8482452893746419e-01
    phi[2,7]  R1858     -0.486066208030729
    phi[2,7]  R1859     -4.8696639912450523e-01
    phi[2,7]  R1860     -5.6081065489589976e-01
    phi[2,7]  R1861     -5.7014525146782224e-01
    phi[2,7]  R1862     -6.0549739823720472e-01
    phi[2,7]  R1863     -6.0677591352070737e-01
    phi[2,7]  R1864     -6.1218075165854313e-01
    phi[2,7]  R1865     -0.620107980902417
    phi[2,7]  R1866     -6.3690775638202624e-01
    phi[2,7]  R1867     -0.638851673895745
    phi[2,7]  R1868     -6.4175920798316510e-01
    phi[2,7]  R1869     -6.5780591145925948e-01
    phi[2,7]  R1870     -0.793949547124293
    phi[2,7]  R1871     -8.8810222345005718e-01
    phi[2,7]  R1872     -9.2524336385598249e-01
    phi[2,7]  R1873     -9.4713802980283290e-01
    phi[2,7]  R1874     -9.7891836912042951e-01
    phi[2,7]  R1875     -1.0010514145609974e+00
    phi[2,7]  R1876     -1.0595972255974404e+00
    phi[2,7]  R1877     -1.0719278183421530e+00
    phi[2,7]  R1878     -1.0766881164534463e+00
    phi[2,7]  R1879     -1.0833488741777746e+00
    phi[2,7]  R1880     -1.2263242604359972e+00
    phi[2,7]  R1881     -5.6659552097771870e-01
    phi[2,7]  R1882     -0.586638780920342
    phi[2,7]  R1883     -6.6866012004473929e-01
    phi[2,7]  R1884     -7.7462413736338043e-01
    phi[2,7]  R1885     -7.7729345694428931e-01
    phi[2,7]  R1886     -0.794805478715552
    phi[2,7]  R1887     -0.81730630251581
    phi[2,7]  R1888     -1.0688411232828665e+00
    phi[2,7]  R1889     -8.4330826932168468e-01
    phi[2,7]  R1890     -9.6462451234695212e-01
    phi[2,7]  R1891     -5.9287928539988477e-01
    phi[2,7]  R1892     -6.1985055651767229e-01
    phi[2,7]  R1893     -6.6806000112007546e-01
    phi[2,7]  R1894     -7.0569413500216460e-01
    phi[2,7]  R1895     -7.0943155924530421e-01
    phi[2,7]  R1896     -8.8997554671471257e-01
    phi[2,7]  R1897     -0.896814667613647
    phi[2,7]  R1898     -9.6601218362013164e-01
    phi[2,7]  R1899     -9.9777650079165159e-01
    phi[2,7]  R1900     -4.0136866779138414e-01
    phi[2,7]  R1901     -0.604227817655524
    phi[2,7]  R1902     -6.2125391115706630e-01
    phi[2,7]  R1903     -6.3342113114535192e-01
    phi[2,7]  R1904     -7.5139339145345918e-01
    phi[2,7]  R1905     -9.8926292246938874e-01
    phi[2,7]  R1906     -1.1352432130902095e+00
    phi[2,7]  R1907     -1.2354063213537698e+00
    phi[2,7]  R1908     -1.5202640561909422e+00
    phi[2,7]  R1909     -1.6840217079692377e+00
    phi[3,4]  R27       1
    phi[3,4]  R28       1
    phi[3,4]  R36       -1
    phi[3,4]  R1910     -3.0999999046325684e+00
    phi[3,4]  R1911     -3.0999999046325684e+00
    phi[3,4]  R1912     -2.2400000095367432e+00
    phi[3,4]  R1913     -2.2400000095367432e+00
    phi[3,4]  R1914     -3.0999999046325684e+00
    phi[3,4]  R1915     -3.0999999046325684e+00
    phi[3,4]  R1916     -2.5699999332427979e+00
    phi[3,4]  R1917     -2.5699999332427979e+00
    phi[3,4]  R1918     -3.0999999046325684e+00
    phi[3,4]  R1919     -3.0999999046325684e+00
    phi[3,4]  R1920     -2.0899999141693115e+00
    phi[3,4]  R1921     -2.0899999141693115e+00
    phi[3,4]  R1922     -3.0999999046325684e+00
    phi[3,4]  R1923     -3.0999999046325684e+00
    phi[3,4]  R1924     7.4696838855743408e-01
    phi[3,4]  R1925     5.9032940864562988e-01
    phi[3,4]  R1926     1.2659519910812378e+00
    phi[3,4]  R1927     1.8894494771957397e+00
    phi[3,4]  R1928     3.6784321069717407e-01
    phi[3,4]  R1929     -6.1327069997787476e-02
    phi[3,4]  R1930     -3.8263463973999023e-01
    phi[3,4]  R1931     4.9458020925521851e-01
    phi[3,4]  R1932     -6.2288695573806763e-01
    phi[3,4]  R1933     5.6835895776748657e-01
    phi[3,4]  R1934     -2.6482255458831787e+00
    phi[3,4]  R1935     2.6964244246482849e-01
    phi[3,4]  R1936     8.2052677869796753e-02
    phi[3,4]  R1937     1.2029384076595306e-01
    phi[3,4]  R1938     -5.9737324714660645e-01
    phi[3,4]  R1939     -0.561819314956665
    phi[3,4]  R1940     -1.0686492174863815e-01
    phi[3,4]  R1941     1.2331368923187256e+00
    phi[3,4]  R1942     8.4604567289352417e-01
    phi[3,4]  R1943     2.4319463968276978e-01
    phi[3,4]  R1944     -3.3971695899963379e+00
    phi[3,4]  R1945     -2.1615834236145020e+00
    phi[3,4]  R1946     -6.9311982393264771e-01
    phi[3,4]  R1947     -3.1848275661468506e+00
    phi[3,4]  R1948     -3.0147583484649658e+00
    phi[3,4]  R1949     -2.1126053333282471e+00
    phi[3,4]  R1950     -1.6379393339157104e+00
    phi[3,4]  R1951     -2.0082266330718994e+00
    phi[3,4]  R1952     -1.2475862503051758e+00
    phi[3,4]  R1953     -3.0648466944694519e-01
    phi[3,4]  R1954     -0.82502281665802
    phi[3,4]  R1955     -2.7735455036163330e+00
    phi[3,4]  R1956     -3.0565261840820312e+00
    phi[3,4]  R1957     -3.1282525062561035e+00
    phi[3,4]  R1958     -2.9937264919281006e+00
    phi[3,4]  R1959     -1.2714358568191528e+00
    phi[3,4]  R1960     -7.7594143152236938e-01
    phi[3,4]  R1961     -1.3108272552490234e+00
    phi[3,4]  R1962     -1.5030174255371094e+00
    phi[3,4]  R1963     -2.5247743129730225e+00
    phi[3,4]  R1964     -2.2561569213867188e+00
    phi[3,4]  R1965     -1.5610722303390503e+00
    phi[3,4]  R1966     -1.6261727809906006e+00
    phi[3,4]  R1967     -2.4040496349334717e+00
    phi[3,4]  R1968     -8.6141097545623779e-01
    phi[3,4]  R1969     -9.9069011211395264e-01
    phi[3,4]  R1970     -3.8015681505203247e-01
    phi[3,4]  R1971     -5.7802206277847290e-01
    phi[3,4]  R1972     -2.8298065662384033e+00
    phi[3,4]  R1973     -5.2950870990753174e-01
    phi[3,4]  R1974     -1.1166453361511230e+00
    phi[3,4]  R1975     -1.6335239410400391e+00
    phi[3,4]  R1976     -2.5911579132080078e+00
    phi[3,4]  R1977     -1.4804123640060425e+00
    phi[3,4]  R1978     -8.8567268848419189e-01
    phi[3,4]  R1979     -1.9468615055084229e+00
    phi[3,4]  R1980     1.6119478940963745e+00
    phi[3,4]  R1981     -3.8211114406585693e+00
    phi[3,4]  R1982     -2.0437605381011963e+00
    phi[3,4]  R1983     -9.3523842096328735e-01
    phi[3,4]  R1984     -1.11148202419281
    phi[3,4]  R1985     -1.6890485286712646e+00
    phi[3,4]  R1986     2.7314907312393188e-01
    phi[3,4]  R1987     -2.5762073993682861e+00
    phi[3,4]  R1988     -1.0708166360855103e+00
    phi[3,4]  R1989     -8.8867408037185669e-01
    phi[3,4]  R1990     -1.3670606613159180e+00
    phi[3,4]  R1991     -1.7170247435569763e-01
    phi[3,4]  R1992     1.9423849582672119e+00
    phi[3,4]  R1993     -3.5738561153411865e+00
    phi[3,4]  R1994     -2.7719292640686035e+00
    phi[3,4]  R1995     -3.2614150047302246e+00
    phi[3,4]  R1996     -1.4663246870040894e+00
    phi[3,4]  R1997     -2.1249735355377197e+00
    phi[3,4]  R1998     -7.7318131923675537e-01
    phi[3,4]  R1999     -2.6373436450958252e+00
    phi[3,4]  R2000     -1.4350007772445679e+00
    phi[3,4]  R2001     -2.9350249767303467e+00
    phi[3,4]  R2002     -1.1410239934921265e+00
    phi[3,4]  R2003     -2.2114701271057129e+00
    phi[3,4]  R2004     3.8547596335411072e-01
    phi[3,4]  R2005     1.1682614088058472e+00
    phi[3,4]  R2006     -2.3844149112701416e+00
    phi[3,4]  R2007     -2.4158637523651123e+00
    phi[3,4]  R2008     -8.4346204996109009e-01
    phi[3,4]  R2009     -1.2738980054855347e+00
    phi[3,4]  R2010     -1.0496698617935181e+00
    phi[3,4]  R2011     -1.8489879369735718e+00
    phi[3,4]  R2012     -1.2628785371780396e+00
    phi[3,4]  R2013     -1.6242331266403198e+00
    phi[3,4]  R2014     5.3010648116469383e-03
    phi[3,4]  R2015     -7.7004718780517578e-01
    phi[3,4]  R2016     -4.4023880362510681e-01
    phi[3,4]  R2017     4.4781726598739624e-01
    phi[3,4]  R2018     -2.0931883156299591e-01
    phi[3,4]  R2019     1.0946505069732666e+00
    phi[3,4]  R2020     3.7301298975944519e-01
    phi[3,4]  R2021     -7.7773980796337128e-02
    phi[3,4]  R2022     -3.1244492530822754e-01
    phi[3,4]  R2023     -9.1448360681533813e-01
    phi[3,4]  R2024     3.2370540499687195e-01
    phi[3,4]  R2025     -2.7513947486877441e+00
    phi[3,4]  R2026     -3.9884489774703979e-01
    phi[3,4]  R2027     -3.3851286768913269e-01
    phi[3,4]  R2028     -1.2109183520078659e-01
    phi[3,4]  R2029     -1.3731625080108643e+00
    phi[3,4]  R2030     -9.2978693544864655e-02
    phi[3,4]  R2031     3.0590891838073730e-01
    phi[3,4]  R2032     -1.8442462682724
    phi[3,4]  R2033     -2.0396001338958740e+00
    phi[3,4]  R2034     -1.2676380574703217e-01
    phi[3,4]  R2035     -1.1865367889404297e+00
    phi[3,4]  R2036     -4.0671494603157043e-01
    phi[3,4]  R2037     -1.9195091724395752e+00
    phi[3,4]  R2038     -2.2505238056182861e+00
    phi[3,4]  R2039     -2.84623384475708
    phi[3,4]  R2040     1.3926053047180176e-01
    phi[3,4]  R2041     -1.7129764556884766e+00
    phi[3,4]  R2042     1.0084869861602783e+00
    phi[3,4]  R2043     1.0873062610626221e+00
    phi[4,3]  R27       -1
    phi[4,3]  R36       1
    phi[4,3]  R37       1
    phi[4,3]  R2044     -3.0999999046325684e+00
    phi[4,3]  R2045     -3.0999999046325684e+00
    phi[4,3]  R2046     -2.2400000095367432e+00
    phi[4,3]  R2047     -2.2400000095367432e+00
    phi[4,3]  R2048     -3.0999999046325684e+00
    phi[4,3]  R2049     -3.0999999046325684e+00
    phi[4,3]  R2050     -2.5699999332427979e+00
    phi[4,3]  R2051     -2.5699999332427979e+00
    phi[4,3]  R2052     -3.0999999046325684e+00
    phi[4,3]  R2053     -3.0999999046325684e+00
    phi[4,3]  R2054     -2.0899999141693115e+00
    phi[4,3]  R2055     -2.0899999141693115e+00
    phi[4,3]  R2056     -3.0999999046325684e+00
    phi[4,3]  R2057     -3.0999999046325684e+00
    phi[4,3]  R2058     5.3010648116469383e-03
    phi[4,3]  R2059     -7.7004718780517578e-01
    phi[4,3]  R2060     -4.4023880362510681e-01
    phi[4,3]  R2061     4.4781726598739624e-01
    phi[4,3]  R2062     -2.0931883156299591e-01
    phi[4,3]  R2063     1.0946505069732666e+00
    phi[4,3]  R2064     3.7301298975944519e-01
    phi[4,3]  R2065     -7.7773980796337128e-02
    phi[4,3]  R2066     -3.1244492530822754e-01
    phi[4,3]  R2067     -9.1448360681533813e-01
    phi[4,3]  R2068     3.2370540499687195e-01
    phi[4,3]  R2069     -2.7513947486877441e+00
    phi[4,3]  R2070     -3.9884489774703979e-01
    phi[4,3]  R2071     -3.3851286768913269e-01
    phi[4,3]  R2072     -1.2109183520078659e-01
    phi[4,3]  R2073     -1.3731625080108643e+00
    phi[4,3]  R2074     -9.2978693544864655e-02
    phi[4,3]  R2075     3.0590891838073730e-01
    phi[4,3]  R2076     -1.8442462682724
    phi[4,3]  R2077     -2.0396001338958740e+00
    phi[4,3]  R2078     -1.2676380574703217e-01
    phi[4,3]  R2079     -1.1865367889404297e+00
    phi[4,3]  R2080     -4.0671494603157043e-01
    phi[4,3]  R2081     -1.9195091724395752e+00
    phi[4,3]  R2082     -2.2505238056182861e+00
    phi[4,3]  R2083     -2.84623384475708
    phi[4,3]  R2084     1.3926053047180176e-01
    phi[4,3]  R2085     -1.7129764556884766e+00
    phi[4,3]  R2086     1.0084869861602783e+00
    phi[4,3]  R2087     1.0873062610626221e+00
    phi[4,3]  R2088     7.4696838855743408e-01
    phi[4,3]  R2089     5.9032940864562988e-01
    phi[4,3]  R2090     1.2659519910812378e+00
    phi[4,3]  R2091     1.8894494771957397e+00
    phi[4,3]  R2092     3.6784321069717407e-01
    phi[4,3]  R2093     -6.1327069997787476e-02
    phi[4,3]  R2094     -3.8263463973999023e-01
    phi[4,3]  R2095     4.9458020925521851e-01
    phi[4,3]  R2096     -6.2288695573806763e-01
    phi[4,3]  R2097     5.6835895776748657e-01
    phi[4,3]  R2098     -2.6482255458831787e+00
    phi[4,3]  R2099     2.6964244246482849e-01
    phi[4,3]  R2100     8.2052677869796753e-02
    phi[4,3]  R2101     1.2029384076595306e-01
    phi[4,3]  R2102     -5.9737324714660645e-01
    phi[4,3]  R2103     -0.561819314956665
    phi[4,3]  R2104     -1.0686492174863815e-01
    phi[4,3]  R2105     1.2331368923187256e+00
    phi[4,3]  R2106     8.4604567289352417e-01
    phi[4,3]  R2107     2.4319463968276978e-01
    phi[4,3]  R2108     -3.3971695899963379e+00
    phi[4,3]  R2109     -2.1615834236145020e+00
    phi[4,3]  R2110     -6.9311982393264771e-01
    phi[4,3]  R2111     -3.1848275661468506e+00
    phi[4,3]  R2112     -3.0147583484649658e+00
    phi[4,3]  R2113     -2.1126053333282471e+00
    phi[4,3]  R2114     -1.6379393339157104e+00
    phi[4,3]  R2115     -2.0082266330718994e+00
    phi[4,3]  R2116     -1.2475862503051758e+00
    phi[4,3]  R2117     -3.0648466944694519e-01
    phi[4,3]  R2118     -0.82502281665802
    phi[4,3]  R2119     -2.7735455036163330e+00
    phi[4,3]  R2120     -3.0565261840820312e+00
    phi[4,3]  R2121     -3.1282525062561035e+00
    phi[4,3]  R2122     -2.9937264919281006e+00
    phi[4,3]  R2123     -1.2714358568191528e+00
    phi[4,3]  R2124     -7.7594143152236938e-01
    phi[4,3]  R2125     -1.3108272552490234e+00
    phi[4,3]  R2126     -1.5030174255371094e+00
    phi[4,3]  R2127     -2.5247743129730225e+00
    phi[4,3]  R2128     -2.2561569213867188e+00
    phi[4,3]  R2129     -1.5610722303390503e+00
    phi[4,3]  R2130     -1.6261727809906006e+00
    phi[4,3]  R2131     -2.4040496349334717e+00
    phi[4,3]  R2132     -8.6141097545623779e-01
    phi[4,3]  R2133     -9.9069011211395264e-01
    phi[4,3]  R2134     -3.8015681505203247e-01
    phi[4,3]  R2135     -5.7802206277847290e-01
    phi[4,3]  R2136     -2.8298065662384033e+00
    phi[4,3]  R2137     -5.2950870990753174e-01
    phi[4,3]  R2138     -1.1166453361511230e+00
    phi[4,3]  R2139     -1.6335239410400391e+00
    phi[4,3]  R2140     -2.5911579132080078e+00
    phi[4,3]  R2141     -1.4804123640060425e+00
    phi[4,3]  R2142     -8.8567268848419189e-01
    phi[4,3]  R2143     -1.9468615055084229e+00
    phi[4,3]  R2144     1.6119478940963745e+00
    phi[4,3]  R2145     -3.8211114406585693e+00
    phi[4,3]  R2146     -2.0437605381011963e+00
    phi[4,3]  R2147     -9.3523842096328735e-01
    phi[4,3]  R2148     -1.11148202419281
    phi[4,3]  R2149     -1.6890485286712646e+00
    phi[4,3]  R2150     2.7314907312393188e-01
    phi[4,3]  R2151     -2.5762073993682861e+00
    phi[4,3]  R2152     -1.0708166360855103e+00
    phi[4,3]  R2153     -8.8867408037185669e-01
    phi[4,3]  R2154     -1.3670606613159180e+00
    phi[4,3]  R2155     -1.7170247435569763e-01
    phi[4,3]  R2156     1.9423849582672119e+00
    phi[4,3]  R2157     -3.5738561153411865e+00
    phi[4,3]  R2158     -2.7719292640686035e+00
    phi[4,3]  R2159     -3.2614150047302246e+00
    phi[4,3]  R2160     -1.4663246870040894e+00
    phi[4,3]  R2161     -2.1249735355377197e+00
    phi[4,3]  R2162     -7.7318131923675537e-01
    phi[4,3]  R2163     -2.6373436450958252e+00
    phi[4,3]  R2164     -1.4350007772445679e+00
    phi[4,3]  R2165     -2.9350249767303467e+00
    phi[4,3]  R2166     -1.1410239934921265e+00
    phi[4,3]  R2167     -2.2114701271057129e+00
    phi[4,3]  R2168     3.8547596335411072e-01
    phi[4,3]  R2169     1.1682614088058472e+00
    phi[4,3]  R2170     -2.3844149112701416e+00
    phi[4,3]  R2171     -2.4158637523651123e+00
    phi[4,3]  R2172     -8.4346204996109009e-01
    phi[4,3]  R2173     -1.2738980054855347e+00
    phi[4,3]  R2174     -1.0496698617935181e+00
    phi[4,3]  R2175     -1.8489879369735718e+00
    phi[4,3]  R2176     -1.2628785371780396e+00
    phi[4,3]  R2177     -1.6242331266403198e+00
    phi[6,3]  R27       -1
    phi[6,3]  R29       0.436132660285212
    phi[6,3]  R30       -6.5293115906839816e-01
    phi[6,3]  R31       1.4403253088833403e+00
    phi[6,3]  R32       -1.6897541231401312e+00
    phi[6,3]  R33       -2.19870963770369
    phi[6,3]  R34       1.0017387778479798e+00
    phi[6,3]  R35       1.6473301255492978e+00
    phi[6,3]  R54       1
    phi[6,3]  R2178     -3.5361325649177804e+00
    phi[6,3]  R2179     -2.6638672443473563e+00
    phi[6,3]  R2180     -1.5870688504683450e+00
    phi[6,3]  R2181     -2.8929311686051413e+00
    phi[6,3]  R2182     -4.5403252135159082e+00
    phi[6,3]  R2183     -1.6596745957492280e+00
    phi[6,3]  R2184     -8.8024581010266667e-01
    phi[6,3]  R2185     -4.2597540563829295e+00
    phi[6,3]  R2186     -9.0129026692887848e-01
    phi[6,3]  R2187     -5.2987095423362582e+00
    phi[6,3]  R2188     -3.0917386920172913e+00
    phi[6,3]  R2189     -1.0882611363213317e+00
    phi[6,3]  R2190     -4.7473300301818657e+00
    phi[6,3]  R2191     -1.4526697790832706e+00
    phi[6,3]  R2192     -9.5769826281224080e-01
    phi[6,3]  R2193     -3.1295461098373833e-01
    phi[6,3]  R2194     -4.8909097853940020e-01
    phi[6,3]  R2195     -1.0485531962396077e+00
    phi[6,3]  R2196     -7.8318295139099781e-01
    phi[6,3]  R2197     -1.7544934939845274e+00
    phi[6,3]  R2198     -7.4166753962320831e-01
    phi[6,3]  R2199     -1.3864936122795739e+00
    phi[6,3]  R2200     -0.908976187775107
    phi[6,3]  R2201     -0.73507874955247
    phi[6,3]  R2202     -5.0685399417493437e-01
    phi[6,3]  R2203     -5.1760906858119826e-01
    phi[6,3]  R2204     -5.2402271453585292e-01
    phi[6,3]  R2205     -5.3481243176386628e-01
    phi[6,3]  R2206     -0.536856860803576
    phi[6,3]  R2207     -5.3747095737033823e-01
    phi[6,3]  R2208     -5.3977141934719675e-01
    phi[6,3]  R2209     -5.4705207497222808e-01
    phi[6,3]  R2210     -5.4777039922040283e-01
    phi[6,3]  R2211     -0.548457422725979
    phi[6,3]  R2212     -6.9423840160409966e-01
    phi[6,3]  R2213     -7.0975076162885387e-01
    phi[6,3]  R2214     -7.7594881564164486e-01
    phi[6,3]  R2215     -8.0794438226515020e-01
    phi[6,3]  R2216     -0.830202852545225
    phi[6,3]  R2217     -2.1304739037779163e+00
    phi[6,3]  R2218     -2.4927534994084715e+00
    phi[6,3]  R2219     -1.9169722975326442e+00
    phi[6,3]  R2220     -2.2387414675760278e+00
    phi[6,3]  R2221     -8.8046344293450129e-01
    phi[6,3]  R2222     -1.2837409594697036e+00
    phi[6,3]  R2223     -7.2145082560262974e-01
    phi[6,3]  R2224     -7.4772594665793646e-01
    phi[6,3]  R2225     -7.4967246906350082e-01
    phi[6,3]  R2226     -7.6493827663728586e-01
    phi[6,3]  R2227     -7.6799270646073159e-01
    phi[6,3]  R2228     -0.77539693235634
    phi[6,3]  R2229     -7.7765737476564722e-01
    phi[6,3]  R2230     -0.779063010215032
    phi[6,3]  R2231     -8.0254227949195434e-01
    phi[6,3]  R2232     -0.56651871173456
    phi[6,3]  R2233     -6.2521487976510381e-01
    phi[6,3]  R2234     -6.7199710286855951e-01
    phi[6,3]  R2235     -6.8601377355661053e-01
    phi[6,3]  R2236     -6.9075466580276723e-01
    phi[6,3]  R2237     -6.9076197695717512e-01
    phi[6,3]  R2238     -6.9974405796350392e-01
    phi[6,3]  R2239     -7.0593185511638734e-01
    phi[6,3]  R2240     -7.1644972385753736e-01
    phi[6,3]  R2241     -7.2343226076107991e-01
    phi[6,3]  R2242     -5.0277872982284222e-01
    phi[6,3]  R2243     -6.0477695826303735e-01
    phi[6,3]  R2244     -6.1348506812135728e-01
    phi[6,3]  R2245     -6.2723075353534574e-01
    phi[6,3]  R2246     -6.3388659788925938e-01
    phi[6,3]  R2247     -7.2921215719736110e-01
    phi[6,3]  R2248     -7.2928310398741036e-01
    phi[6,3]  R2249     -7.8543687200693224e-01
    phi[6,3]  R2250     -8.0364053415034720e-01
    phi[6,3]  R2251     -8.0441269542458826e-01
    phi[6,3]  R2252     -7.9126036397572830e-01
    phi[6,3]  R2253     -5.9816523310144420e-01
    phi[6,3]  R2254     -6.8425678790398425e-01
    phi[6,3]  R2255     -7.2832759489899468e-01
    phi[6,3]  R2256     -0.768916459111994
    phi[6,3]  R2257     -7.6925374160858517e-01
    phi[6,3]  R2258     -8.5684536819409829e-01
    phi[6,3]  R2259     -8.6427183553555975e-01
    phi[6,3]  R2260     -0.92130253125901
    phi[6,3]  R2261     -9.2424407920752838e-01
    phi[6,3]  R2262     -5.3499719783089850e-01
    phi[6,3]  R2263     -6.1243755347175188e-01
    phi[6,3]  R2264     -9.4495290668597010e-01
    phi[6,3]  R2265     -6.6187086902491732e-01
    phi[6,3]  R2266     -6.7078959076327882e-01
    phi[6,3]  R2267     -6.7505290183283750e-01
    phi[6,3]  R2268     -0.680157973544531
    phi[6,3]  R2269     -6.9051378360953031e-01
    phi[6,3]  R2270     -7.3120305184658108e-01
    phi[6,3]  R2271     -7.4036005849496833e-01
    phi[6,3]  R2272     -6.0876452763165390e-01
    phi[6,3]  R2273     -6.2465260312795134e-01
    phi[6,3]  R2274     -6.5619249526606649e-01
    phi[6,3]  R2275     -6.5654371816950707e-01
    phi[6,3]  R2276     -6.6466394638288750e-01
    phi[6,3]  R2277     -6.6895604736530712e-01
    phi[6,3]  R2278     -0.673702319174972
    phi[6,3]  R2279     -6.9809443955093986e-01
    phi[6,3]  R2280     -7.2223495393026538e-01
    phi[6,3]  R2281     -0.728886456420954
    phi[4,5]  R36       1
    phi[4,5]  R37       1
    phi[4,5]  R45       -1
    phi[4,5]  R2282     -3.0999999046325684e+00
    phi[4,5]  R2283     -3.0999999046325684e+00
    phi[4,5]  R2284     -2.2400000095367432e+00
    phi[4,5]  R2285     -2.2400000095367432e+00
    phi[4,5]  R2286     -3.0999999046325684e+00
    phi[4,5]  R2287     -3.0999999046325684e+00
    phi[4,5]  R2288     -2.5699999332427979e+00
    phi[4,5]  R2289     -2.5699999332427979e+00
    phi[4,5]  R2290     -3.0999999046325684e+00
    phi[4,5]  R2291     -3.0999999046325684e+00
    phi[4,5]  R2292     -2.0899999141693115e+00
    phi[4,5]  R2293     -2.0899999141693115e+00
    phi[4,5]  R2294     -3.0999999046325684e+00
    phi[4,5]  R2295     -3.0999999046325684e+00
    phi[4,5]  R2296     5.3010648116469383e-03
    phi[4,5]  R2297     -7.7004718780517578e-01
    phi[4,5]  R2298     -4.4023880362510681e-01
    phi[4,5]  R2299     4.4781726598739624e-01
    phi[4,5]  R2300     -2.0931883156299591e-01
    phi[4,5]  R2301     1.0946505069732666e+00
    phi[4,5]  R2302     3.7301298975944519e-01
    phi[4,5]  R2303     -7.7773980796337128e-02
    phi[4,5]  R2304     -3.1244492530822754e-01
    phi[4,5]  R2305     -9.1448360681533813e-01
    phi[4,5]  R2306     3.2370540499687195e-01
    phi[4,5]  R2307     -2.7513947486877441e+00
    phi[4,5]  R2308     -3.9884489774703979e-01
    phi[4,5]  R2309     -3.3851286768913269e-01
    phi[4,5]  R2310     -1.2109183520078659e-01
    phi[4,5]  R2311     -1.3731625080108643e+00
    phi[4,5]  R2312     -9.2978693544864655e-02
    phi[4,5]  R2313     3.0590891838073730e-01
    phi[4,5]  R2314     -1.8442462682724
    phi[4,5]  R2315     -2.0396001338958740e+00
    phi[4,5]  R2316     -1.2676380574703217e-01
    phi[4,5]  R2317     -1.1865367889404297e+00
    phi[4,5]  R2318     -4.0671494603157043e-01
    phi[4,5]  R2319     -1.9195091724395752e+00
    phi[4,5]  R2320     -2.2505238056182861e+00
    phi[4,5]  R2321     -2.84623384475708
    phi[4,5]  R2322     1.3926053047180176e-01
    phi[4,5]  R2323     -1.7129764556884766e+00
    phi[4,5]  R2324     1.0084869861602783e+00
    phi[4,5]  R2325     1.0873062610626221e+00
    phi[4,5]  R2326     2.8414392471313477e-01
    phi[4,5]  R2327     -8.0679035186767578e-01
    phi[4,5]  R2328     -1.1893633753061295e-01
    phi[4,5]  R2329     1.5230422019958496e+00
    phi[4,5]  R2330     7.2793298959732056e-01
    phi[4,5]  R2331     -1.4463989436626434e-01
    phi[4,5]  R2332     1.1948866844177246e+00
    phi[4,5]  R2333     9.0794456005096436e-01
    phi[4,5]  R2334     -1.2591454386711121e-01
    phi[4,5]  R2335     1.7452241182327271e+00
    phi[4,5]  R2336     -2.8261013031005859e+00
    phi[4,5]  R2337     -9.4937264919281006e-01
    phi[4,5]  R2338     -3.5499542951583862e-01
    phi[4,5]  R2339     -3.9355948567390442e-02
    phi[4,5]  R2340     -2.1837933063507080e+00
    phi[4,5]  R2341     3.4433159232139587e-01
    phi[4,5]  R2342     -9.2684447765350342e-01
    phi[4,5]  R2343     -4.4330008327960968e-02
    phi[4,5]  R2344     -6.8314790725708008e-01
    phi[4,5]  R2345     -2.8046682476997375e-01
    phi[4,5]  R2346     -1.0717215538024902e+00
    phi[4,5]  R2347     -2.1858029365539551e+00
    phi[4,5]  R2348     -2.9832825660705566e+00
    phi[4,5]  R2349     2.1295222640037537e-01
    phi[4,5]  R2350     -2.1082291603088379e+00
    phi[4,5]  R2351     -3.1869323253631592e+00
    phi[4,5]  R2352     -3.1646850109100342e+00
    phi[4,5]  R2353     1.4179245233535767e+00
    phi[4,5]  R2354     -2.3230087757110596e+00
    phi[4,5]  R2355     -3.3502440452575684e+00
    phi[4,5]  R2356     -1.4843820333480835e+00
    phi[4,5]  R2357     -2.95682430267334
    phi[4,5]  R2358     -1.2104443311691284e+00
    phi[4,5]  R2359     -1.9855084419250488e+00
    phi[4,5]  R2360     -1.9198642969131470e+00
    phi[4,5]  R2361     -2.7418620586395264e+00
    phi[4,5]  R2362     1.8515779972076416e+00
    phi[4,5]  R2363     -1.7986783981323242e+00
    phi[4,5]  R2364     -1.0878798961639404e+00
    phi[4,5]  R2365     4.8712402582168579e-01
    phi[4,5]  R2366     -2.8415971994400024e-01
    phi[4,5]  R2367     -1.2536016702651978e+00
    phi[4,5]  R2368     -2.3093726634979248e+00
    phi[4,5]  R2369     -1.4188036322593689e-01
    phi[4,5]  R2370     -1.7499494552612305e+00
    phi[4,5]  R2371     -1.4156135320663452e+00
    phi[4,5]  R2372     -1.7478259801864624e+00
    phi[4,5]  R2373     -1.1277546882629395e+00
    phi[4,5]  R2374     -2.4227716028690338e-01
    phi[4,5]  R2375     -2.7006061077117920e+00
    phi[4,5]  R2376     -4.3319725990295410e-01
    phi[4,5]  R2377     -3.1303146481513977e-01
    phi[4,5]  R2378     -1.4981080293655396e+00
    phi[4,5]  R2379     -1.0864914953708649e-01
    phi[4,5]  R2380     -2.4950990676879883e+00
    phi[4,5]  R2381     2.6497811079025269e-01
    phi[4,5]  R2382     -1.4847133159637451e+00
    phi[4,5]  R2383     -1.6127809286117554e+00
    phi[4,5]  R2384     -2.7393848896026611e+00
    phi[4,5]  R2385     -7.0934897661209106e-01
    phi[4,5]  R2386     -2.1147117614746094e+00
    phi[4,5]  R2387     -2.0120551586151123e+00
    phi[4,5]  R2388     -1.2092066556215286e-01
    phi[4,5]  R2389     1.9460766017436981e-01
    phi[4,5]  R2390     -1.5705695375800133e-02
    phi[4,5]  R2391     0.419849157333374
    phi[4,5]  R2392     -1.9804681539535522e+00
    phi[4,5]  R2393     8.6963987350463867e-01
    phi[4,5]  R2394     -2.4987779557704926e-01
    phi[4,5]  R2395     -9.9948549270629883e-01
    phi[4,5]  R2396     -3.9563268423080444e-01
    phi[4,5]  R2397     -3.3903102874755859e+00
    phi[4,5]  R2398     -1.3080577850341797e+00
    phi[4,5]  R2399     -1.3100939989089966e+00
    phi[4,5]  R2400     -2.9573016166687012e+00
    phi[4,5]  R2401     -3.5129386186599731e-01
    phi[4,5]  R2402     -1.6469752788543701e+00
    phi[4,5]  R2403     1.7266348004341125e-01
    phi[4,5]  R2404     -5.3757065534591675e-01
    phi[4,5]  R2405     -3.6933586001396179e-02
    phi[5,4]  R36       -1
    phi[5,4]  R45       1
    phi[5,4]  R46       1
    phi[5,4]  R2406     -3.0999999046325684e+00
    phi[5,4]  R2407     -3.0999999046325684e+00
    phi[5,4]  R2408     -2.2400000095367432e+00
    phi[5,4]  R2409     -2.2400000095367432e+00
    phi[5,4]  R2410     -3.0999999046325684e+00
    phi[5,4]  R2411     -3.0999999046325684e+00
    phi[5,4]  R2412     -2.5699999332427979e+00
    phi[5,4]  R2413     -2.5699999332427979e+00
    phi[5,4]  R2414     -3.0999999046325684e+00
    phi[5,4]  R2415     -3.0999999046325684e+00
    phi[5,4]  R2416     -2.0899999141693115e+00
    phi[5,4]  R2417     -2.0899999141693115e+00
    phi[5,4]  R2418     -3.0999999046325684e+00
    phi[5,4]  R2419     -3.0999999046325684e+00
    phi[5,4]  R2420     2.8414392471313477e-01
    phi[5,4]  R2421     -8.0679035186767578e-01
    phi[5,4]  R2422     -1.1893633753061295e-01
    phi[5,4]  R2423     1.5230422019958496e+00
    phi[5,4]  R2424     7.2793298959732056e-01
    phi[5,4]  R2425     -1.4463989436626434e-01
    phi[5,4]  R2426     1.1948866844177246e+00
    phi[5,4]  R2427     9.0794456005096436e-01
    phi[5,4]  R2428     -1.2591454386711121e-01
    phi[5,4]  R2429     1.7452241182327271e+00
    phi[5,4]  R2430     -2.8261013031005859e+00
    phi[5,4]  R2431     -9.4937264919281006e-01
    phi[5,4]  R2432     -3.5499542951583862e-01
    phi[5,4]  R2433     -3.9355948567390442e-02
    phi[5,4]  R2434     -2.1837933063507080e+00
    phi[5,4]  R2435     3.4433159232139587e-01
    phi[5,4]  R2436     -9.2684447765350342e-01
    phi[5,4]  R2437     -4.4330008327960968e-02
    phi[5,4]  R2438     -6.8314790725708008e-01
    phi[5,4]  R2439     -2.8046682476997375e-01
    phi[5,4]  R2440     -1.0717215538024902e+00
    phi[5,4]  R2441     -2.1858029365539551e+00
    phi[5,4]  R2442     -2.9832825660705566e+00
    phi[5,4]  R2443     2.1295222640037537e-01
    phi[5,4]  R2444     -2.1082291603088379e+00
    phi[5,4]  R2445     -3.1869323253631592e+00
    phi[5,4]  R2446     -3.1646850109100342e+00
    phi[5,4]  R2447     1.4179245233535767e+00
    phi[5,4]  R2448     -2.3230087757110596e+00
    phi[5,4]  R2449     -3.3502440452575684e+00
    phi[5,4]  R2450     -1.4843820333480835e+00
    phi[5,4]  R2451     -2.95682430267334
    phi[5,4]  R2452     -1.2104443311691284e+00
    phi[5,4]  R2453     -1.9855084419250488e+00
    phi[5,4]  R2454     -1.9198642969131470e+00
    phi[5,4]  R2455     -2.7418620586395264e+00
    phi[5,4]  R2456     1.8515779972076416e+00
    phi[5,4]  R2457     -1.7986783981323242e+00
    phi[5,4]  R2458     -1.0878798961639404e+00
    phi[5,4]  R2459     4.8712402582168579e-01
    phi[5,4]  R2460     -2.8415971994400024e-01
    phi[5,4]  R2461     -1.2536016702651978e+00
    phi[5,4]  R2462     -2.3093726634979248e+00
    phi[5,4]  R2463     -1.4188036322593689e-01
    phi[5,4]  R2464     -1.7499494552612305e+00
    phi[5,4]  R2465     -1.4156135320663452e+00
    phi[5,4]  R2466     -1.7478259801864624e+00
    phi[5,4]  R2467     -1.1277546882629395e+00
    phi[5,4]  R2468     -2.4227716028690338e-01
    phi[5,4]  R2469     -2.7006061077117920e+00
    phi[5,4]  R2470     -4.3319725990295410e-01
    phi[5,4]  R2471     -3.1303146481513977e-01
    phi[5,4]  R2472     -1.4981080293655396e+00
    phi[5,4]  R2473     -1.0864914953708649e-01
    phi[5,4]  R2474     -2.4950990676879883e+00
    phi[5,4]  R2475     2.6497811079025269e-01
    phi[5,4]  R2476     -1.4847133159637451e+00
    phi[5,4]  R2477     -1.6127809286117554e+00
    phi[5,4]  R2478     -2.7393848896026611e+00
    phi[5,4]  R2479     -7.0934897661209106e-01
    phi[5,4]  R2480     -2.1147117614746094e+00
    phi[5,4]  R2481     -2.0120551586151123e+00
    phi[5,4]  R2482     -1.2092066556215286e-01
    phi[5,4]  R2483     1.9460766017436981e-01
    phi[5,4]  R2484     -1.5705695375800133e-02
    phi[5,4]  R2485     0.419849157333374
    phi[5,4]  R2486     -1.9804681539535522e+00
    phi[5,4]  R2487     8.6963987350463867e-01
    phi[5,4]  R2488     -2.4987779557704926e-01
    phi[5,4]  R2489     -9.9948549270629883e-01
    phi[5,4]  R2490     -3.9563268423080444e-01
    phi[5,4]  R2491     -3.3903102874755859e+00
    phi[5,4]  R2492     -1.3080577850341797e+00
    phi[5,4]  R2493     -1.3100939989089966e+00
    phi[5,4]  R2494     -2.9573016166687012e+00
    phi[5,4]  R2495     -3.5129386186599731e-01
    phi[5,4]  R2496     -1.6469752788543701e+00
    phi[5,4]  R2497     1.7266348004341125e-01
    phi[5,4]  R2498     -5.3757065534591675e-01
    phi[5,4]  R2499     -3.6933586001396179e-02
    phi[5,4]  R2500     5.3010648116469383e-03
    phi[5,4]  R2501     -7.7004718780517578e-01
    phi[5,4]  R2502     -4.4023880362510681e-01
    phi[5,4]  R2503     4.4781726598739624e-01
    phi[5,4]  R2504     -2.0931883156299591e-01
    phi[5,4]  R2505     1.0946505069732666e+00
    phi[5,4]  R2506     3.7301298975944519e-01
    phi[5,4]  R2507     -7.7773980796337128e-02
    phi[5,4]  R2508     -3.1244492530822754e-01
    phi[5,4]  R2509     -9.1448360681533813e-01
    phi[5,4]  R2510     3.2370540499687195e-01
    phi[5,4]  R2511     -2.7513947486877441e+00
    phi[5,4]  R2512     -3.9884489774703979e-01
    phi[5,4]  R2513     -3.3851286768913269e-01
    phi[5,4]  R2514     -1.2109183520078659e-01
    phi[5,4]  R2515     -1.3731625080108643e+00
    phi[5,4]  R2516     -9.2978693544864655e-02
    phi[5,4]  R2517     3.0590891838073730e-01
    phi[5,4]  R2518     -1.8442462682724
    phi[5,4]  R2519     -2.0396001338958740e+00
    phi[5,4]  R2520     -1.2676380574703217e-01
    phi[5,4]  R2521     -1.1865367889404297e+00
    phi[5,4]  R2522     -4.0671494603157043e-01
    phi[5,4]  R2523     -1.9195091724395752e+00
    phi[5,4]  R2524     -2.2505238056182861e+00
    phi[5,4]  R2525     -2.84623384475708
    phi[5,4]  R2526     1.3926053047180176e-01
    phi[5,4]  R2527     -1.7129764556884766e+00
    phi[5,4]  R2528     1.0084869861602783e+00
    phi[5,4]  R2529     1.0873062610626221e+00
    phi[5,7]  R45       1
    phi[5,7]  R46       1
    phi[5,7]  R47       1.3628997693946137e+00
    phi[5,7]  R48       1.01924182184423
    phi[5,7]  R49       2.1038569914873366e+00
    phi[5,7]  R50       4.7779016334331015e-02
    phi[5,7]  R51       1.6636994450194549e+00
    phi[5,7]  R52       -1.2054864416783269e+00
    phi[5,7]  R53       2.0638702292383542e+00
    phi[5,7]  R55       -1
    phi[5,7]  R2530     -1.7371001352379547e+00
    phi[5,7]  R2531     -4.4628996740271818e+00
    phi[5,7]  R2532     -1.2207581876925131e+00
    phi[5,7]  R2533     -3.2592418313809732e+00
    phi[5,7]  R2534     -9.9614291314523173e-01
    phi[5,7]  R2535     -5.2038568961199054e+00
    phi[5,7]  R2536     -2.5222209169084668e+00
    phi[5,7]  R2537     -2.6177789495771289e+00
    phi[5,7]  R2538     -1.4363004596131135e+00
    phi[5,7]  R2539     -4.7636993496520237e+00
    phi[5,7]  R2540     -3.2954863558476384e+00
    phi[5,7]  R2541     -8.8451347249098466e-01
    phi[5,7]  R2542     -1.0361296753942142e+00
    phi[5,7]  R2543     -5.1638701338709225e+00
    phi[5,7]  R2544     -6.1025064065659329e-01
    phi[5,7]  R2545     -0.277677278526099
    phi[5,7]  R2546     -2.4748333077803797e-01
    phi[5,7]  R2547     -2.5060222366850904e-01
    phi[5,7]  R2548     -2.5425807027744751e-01
    phi[5,7]  R2549     -2.5566822403791628e-01
    phi[5,7]  R2550     -2.6206076763927633e-01
    phi[5,7]  R2551     -2.7038306032194126e-01
    phi[5,7]  R2552     -2.7200427936641391e-01
    phi[5,7]  R2553     -2.7683301039695252e-01
    phi[5,7]  R2554     -8.2371043369040509e-01
    phi[5,7]  R2555     -1.4007587947358275e+00
    phi[5,7]  R2556     -1.2747820575598063e+00
    phi[5,7]  R2557     -1.6587900934559219e+00
    phi[5,7]  R2558     -8.5851553030315864e-01
    phi[5,7]  R2559     -1.3691928559243363e+00
    phi[5,7]  R2560     -1.5338474064928973e+00
    phi[5,7]  R2561     -1.6043298602190912e+00
    phi[5,7]  R2562     -1.5191275992871351e+00
    phi[5,7]  R2563     -1.6321081683496594e+00
    phi[5,7]  R2564     -8.7459949953212857e-01
    phi[5,7]  R2565     -9.1849630900244428e-01
    phi[5,7]  R2566     -9.6327651174846718e-01
    phi[5,7]  R2567     -9.8123568598456123e-01
    phi[5,7]  R2568     -9.8458755833683931e-01
    phi[5,7]  R2569     -9.9922223430020551e-01
    phi[5,7]  R2570     -1.0084309008863213e+00
    phi[5,7]  R2571     -1.0157186322368723e+00
    phi[5,7]  R2572     -1.0253118115308621e+00
    phi[5,7]  R2573     -1.03310021124918
    phi[5,7]  R2574     -1.2606693115381835e+00
    phi[5,7]  R2575     -1.0642901349968843e+00
    phi[5,7]  R2576     -7.0984672349977429e-01
    phi[5,7]  R2577     -1.7632285769014411e+00
    phi[5,7]  R2578     -0.801902994879208
    phi[5,7]  R2579     -8.1193897802677140e-01
    phi[5,7]  R2580     -8.2820847900799555e-01
    phi[5,7]  R2581     -8.5215744383070646e-01
    phi[5,7]  R2582     -9.0788453985731088e-01
    phi[5,7]  R2583     -1.3449041493022083e+00
    phi[5,7]  R2584     -8.7316789521474913e-01
    phi[5,7]  R2585     -1.51614024359863
    phi[5,7]  R2586     -6.9124890635952441e-01
    phi[5,7]  R2587     -1.5233686993982480e+00
    phi[5,7]  R2588     -9.6978820420657930e-01
    phi[5,7]  R2589     -2.2055334979521324e+00
    phi[5,7]  R2590     -1.1154057915431019e+00
    phi[5,7]  R2591     -1.1415550869265083e+00
    phi[5,7]  R2592     -1.1491979901626381e+00
    phi[5,7]  R2593     -1.1519096408291116e+00
    phi[5,7]  R2594     -8.3910530551365481e-01
    phi[5,7]  R2595     -8.9288155851726769e-01
    phi[5,7]  R2596     -0.895200841533194
    phi[5,7]  R2597     -2.03795867555516
    phi[5,7]  R2598     -9.5268093873343185e-01
    phi[5,7]  R2599     -1.4575457690550577e+00
    phi[5,7]  R2600     -1.0407027813393572e+00
    phi[5,7]  R2601     -1.0884975119728661e+00
    phi[5,7]  R2602     -1.1072074579855278e+00
    phi[5,7]  R2603     -1.1078712799360075e+00
    phi[5,7]  R2604     -3.1736796399760525e-01
    phi[5,7]  R2605     -9.2065564164503710e-01
    phi[5,7]  R2606     -7.7551643760356070e-01
    phi[5,7]  R2607     -8.5440338050531373e-01
    phi[5,7]  R2608     -1.7551298153612975e+00
    phi[5,7]  R2609     -1.0855257600418271e+00
    phi[5,7]  R2610     -1.1460984405961132e+00
    phi[5,7]  R2611     -1.1581226523030290e+00
    phi[5,7]  R2612     -1.1774175140662655e+00
    phi[5,7]  R2613     -1.2401785610409852e+00
    phi[5,7]  R2614     -8.1621589029444341e-01
    phi[5,7]  R2615     -1.0749868588951892e+00
    phi[5,7]  R2616     -1.2151460097248608e+00
    phi[5,7]  R2617     -1.1075376385373867e+00
    phi[5,7]  R2618     -1.1436730965968793e+00
    phi[5,7]  R2619     -1.1545594051951027e+00
    phi[5,7]  R2620     -1.7295011178757873e+00
    phi[5,7]  R2621     -1.2262519552237270e+00
    phi[5,7]  R2622     -1.2663527681581070e+00
    phi[5,7]  R2623     -1.2889728292884741e+00
    MARKER    'MARKER'                 'INTEND'
    z[0,1,0]  R2        -1
    z[0,1,0]  R11       1
    z[0,1,0]  R56       -1
    z[0,1,0]  R57       1
    z[0,1,0]  R70       -0.595670759677887
    z[0,1,0]  R71       -3.7485894560813904e-01
    z[0,1,0]  R72       -1.8457423150539398e-01
    z[0,1,0]  R73       -5.7814240455627441e-01
    z[0,1,0]  R74       -3.1091922521591187e-01
    z[0,1,0]  R75       -4.4319561123847961e-01
    z[0,1,0]  R76       -2.9543972015380859e-01
    z[0,1,0]  R77       -4.4200652837753296e-01
    z[0,1,0]  R78       6.2063220888376236e-02
    z[0,1,0]  R79       -1.3802291452884674e-01
    z[0,1,0]  R80       1.2147828191518784e-01
    z[0,1,0]  R81       -2.9867494106292725e-01
    z[0,1,0]  R82       -3.1643894314765930e-01
    z[0,1,0]  R83       3.2006077468395233e-02
    z[0,1,0]  R84       5.8187246322631836e-02
    z[0,1,0]  R85       -2.0086118951439857e-02
    z[0,1,0]  R86       2.5060039758682251e-01
    z[0,1,0]  R87       -1.2390428036451340e-01
    z[0,1,0]  R88       -1.4783337712287903e-01
    z[0,1,0]  R89       -1.3143141567707062e-01
    z[0,1,0]  R90       5.4461634159088135e-01
    z[0,1,0]  R91       3.9418607950210571e-01
    z[0,1,0]  R92       6.1878937482833862e-01
    z[0,1,0]  R93       0.476563036441803
    z[0,1,0]  R94       7.4172264337539673e-01
    z[0,1,0]  R95       6.7241811752319336e-01
    z[0,1,0]  R96       6.4190948009490967e-01
    z[0,1,0]  R97       6.5134871006011963e-01
    z[0,1,0]  R98       1.1419311165809631e-01
    z[0,1,0]  R99       5.9473598003387451e-01
    z[0,1,0]  R100      -9.8668999969959259e-02
    z[0,1,0]  R101      6.1946451663970947e-01
    z[0,1,0]  R102      0.542599081993103
    z[0,1,0]  R103      -1.0434793680906296e-01
    z[0,1,0]  R104      3.2040235400199890e-01
    z[0,1,0]  R105      7.2470021247863770e-01
    z[0,1,0]  R106      -3.1749375630170107e-03
    z[0,1,0]  R107      3.7793529033660889e-01
    z[0,1,0]  R108      -2.0786963403224945e-01
    z[0,1,0]  R109      -1.8122604489326477e-01
    z[0,1,0]  R110      1.0424977540969849e-01
    z[0,1,0]  R111      4.5252549648284912e-01
    z[0,1,0]  R112      0.0661509558558464
    z[0,1,0]  R113      2.8299051523208618e-01
    z[0,1,0]  R114      1.2149226665496826e-01
    z[0,1,0]  R115      0.612120509147644
    z[0,1,0]  R116      6.7033219337463379e-01
    z[0,1,0]  R117      1.5490005910396576e-01
    z[0,1,0]  R118      2.8226104378700256e-01
    z[0,1,0]  R119      -2.4477690458297729e-01
    z[0,1,0]  R120      -3.3862102031707764e-01
    z[0,1,0]  R121      -2.5495833158493042e-01
    z[0,1,0]  R122      -8.7855964899063110e-02
    z[0,1,0]  R123      -3.8494125008583069e-01
    z[0,1,0]  R124      9.0316146612167358e-02
    z[0,1,0]  R125      -1.0013429075479507e-01
    z[0,1,0]  R126      -2.1069069206714630e-01
    z[0,1,0]  R127      -2.3835390806198120e-01
    z[0,1,0]  R128      -8.9270561933517456e-02
    z[0,1,0]  R129      -1.3217581808567047e-01
    z[0,1,0]  R130      -5.6992095708847046e-01
    z[0,1,0]  R131      2.1340602636337280e-01
    z[0,1,0]  R132      3.7517610192298889e-01
    z[0,1,0]  R133      -7.1401357650756836e-02
    z[0,1,0]  R134      -1.5552681684494019e-01
    z[0,1,0]  R135      -3.3658319711685181e-01
    z[0,1,0]  R136      -3.7117803096771240e-01
    z[0,1,0]  R137      2.5435557961463928e-01
    z[0,1,0]  R138      -1.4337022602558136e-01
    z[0,1,0]  R139      3.9398744702339172e-02
    z[0,1,0]  R140      1.0379552096128464e-01
    z[0,1,0]  R141      -6.4998644590377808e-01
    z[0,1,0]  R142      -7.4237370491027832e-01
    z[0,1,0]  R143      -0.0773012712597847
    z[0,1,0]  R144      -0.246307834982872
    z[0,1,0]  R145      -1.4701296389102936e-01
    z[0,1,0]  R146      4.7910723835229874e-02
    z[0,1,0]  R147      -1.6824087128043175e-02
    z[0,1,0]  R148      3.1259888410568237e-01
    z[0,1,0]  R149      1.6191582381725311e-01
    z[0,1,1]  R3        -1
    z[0,1,1]  R12       1
    z[0,1,1]  R58       -1
    z[0,1,1]  R59       1
    z[0,1,1]  R70       -4.4385874271392822e-01
    z[0,1,1]  R71       -4.2086270451545715e-01
    z[0,1,1]  R72       -0.529179573059082
    z[0,1,1]  R73       -4.1710504889488220e-01
    z[0,1,1]  R74       -8.6575299501419067e-01
    z[0,1,1]  R75       -0.421099990606308
    z[0,1,1]  R76       -3.9300060272216797e-01
    z[0,1,1]  R77       -3.5395517945289612e-01
    z[0,1,1]  R78       -4.0363934636116028e-01
    z[0,1,1]  R79       -7.0809775590896606e-01
    z[0,1,1]  R80       0.897419273853302
    z[0,1,1]  R81       0.900534987449646
    z[0,1,1]  R82       0.902877151966095
    z[0,1,1]  R83       9.1613984107971191e-01
    z[0,1,1]  R84       8.9577335119247437e-01
    z[0,1,1]  R85       9.3991589546203613e-01
    z[0,1,1]  R86       8.9128780364990234e-01
    z[0,1,1]  R87       8.3712917566299438e-01
    z[0,1,1]  R88       8.4881031513214111e-01
    z[0,1,1]  R89       0.816559374332428
    z[0,1,1]  R90       5.4552732035517693e-03
    z[0,1,1]  R91       2.3812660947442055e-02
    z[0,1,1]  R92       0.0827384814620018
    z[0,1,1]  R93       3.1028954312205315e-02
    z[0,1,1]  R94       5.4847251623868942e-02
    z[0,1,1]  R95       9.2687368392944336e-02
    z[0,1,1]  R96       -6.5321475267410278e-02
    z[0,1,1]  R97       1.5127401053905487e-01
    z[0,1,1]  R98       1.9041022285819054e-02
    z[0,1,1]  R99       1.1130225658416748e-01
    z[0,1,1]  R100      -5.5492192506790161e-01
    z[0,1,1]  R101      -6.6467088460922241e-01
    z[0,1,1]  R102      -5.6200414896011353e-01
    z[0,1,1]  R103      -1.8602198362350464e-01
    z[0,1,1]  R104      -2.4653628468513489e-01
    z[0,1,1]  R105      3.1718581914901733e-01
    z[0,1,1]  R106      2.8134384751319885e-01
    z[0,1,1]  R107      -4.3276441097259521e-01
    z[0,1,1]  R108      -9.6648633480072021e-02
    z[0,1,1]  R109      6.7415893077850342e-02
    z[0,1,1]  R110      -0.696075439453125
    z[0,1,1]  R111      -7.3556423187255859e-01
    z[0,1,1]  R112      -9.5174181461334229e-01
    z[0,1,1]  R113      -0.581727147102356
    z[0,1,1]  R114      -5.2499836683273315e-01
    z[0,1,1]  R115      -6.1543524265289307e-01
    z[0,1,1]  R116      4.6398368477821350e-01
    z[0,1,1]  R117      -4.8562464118003845e-01
    z[0,1,1]  R118      -6.1472445726394653e-01
    z[0,1,1]  R119      -5.4373896121978760e-01
    z[0,1,1]  R120      8.3149868249893188e-01
    z[0,1,1]  R121      8.1795817613601685e-01
    z[0,1,1]  R122      0.6903116106987
    z[0,1,1]  R123      0.792568564414978
    z[0,1,1]  R124      0.64494389295578
    z[0,1,1]  R125      7.9558509588241577e-01
    z[0,1,1]  R126      6.4291751384735107e-01
    z[0,1,1]  R127      0.771367609500885
    z[0,1,1]  R128      7.0715421438217163e-01
    z[0,1,1]  R129      7.5815582275390625e-01
    z[0,1,1]  R130      -5.4785811901092529e-01
    z[0,1,1]  R131      8.1614577770233154e-01
    z[0,1,1]  R132      7.5626271963119507e-01
    z[0,1,1]  R133      8.7774705886840820e-01
    z[0,1,1]  R134      8.7240421772003174e-01
    z[0,1,1]  R135      0.694605827331543
    z[0,1,1]  R136      6.6287875175476074e-01
    z[0,1,1]  R137      6.1518836021423340e-01
    z[0,1,1]  R138      7.2351044416427612e-01
    z[0,1,1]  R139      5.7182258367538452e-01
    z[0,1,1]  R140      -2.3990131914615631e-01
    z[0,1,1]  R141      -5.1171648502349854e-01
    z[0,1,1]  R142      -4.2025437951087952e-01
    z[0,1,1]  R143      8.1895691156387329e-01
    z[0,1,1]  R144      9.4919794797897339e-01
    z[0,1,1]  R145      7.5719106197357178e-01
    z[0,1,1]  R146      9.1465157270431519e-01
    z[0,1,1]  R147      8.3162802457809448e-01
    z[0,1,1]  R148      -2.9651984572410583e-01
    z[0,1,1]  R149      -3.0413705110549927e-01
    z[0,1,2]  R4        -1
    z[0,1,2]  R13       1
    z[0,1,2]  R60       -1
    z[0,1,2]  R61       1
    z[0,1,2]  R70       -2.8671988844871521e-01
    z[0,1,2]  R71       -5.0583446025848389e-01
    z[0,1,2]  R72       -3.8096874952316284e-01
    z[0,1,2]  R73       -5.9246593713760376e-01
    z[0,1,2]  R74       -1.7986467480659485e-01
    z[0,1,2]  R75       -6.2425899505615234e-01
    z[0,1,2]  R76       -6.4657533168792725e-01
    z[0,1,2]  R77       -7.8528332710266113e-01
    z[0,1,2]  R78       -8.7665939331054688e-01
    z[0,1,2]  R79       -2.3562364280223846e-02
    z[0,1,2]  R80       -4.1183501482009888e-01
    z[0,1,2]  R81       -2.5626808404922485e-01
    z[0,1,2]  R82       2.5473069399595261e-02
    z[0,1,2]  R83       1.6784700751304626e-01
    z[0,1,2]  R84       -1.3380204141139984e-01
    z[0,1,2]  R85       1.6160102188587189e-01
    z[0,1,2]  R86       5.1723778247833252e-02
    z[0,1,2]  R87       -2.8242358565330505e-01
    z[0,1,2]  R88       4.5180737972259521e-01
    z[0,1,2]  R89       -1.1835354566574097e-01
    z[0,1,2]  R90       5.9386283159255981e-01
    z[0,1,2]  R91       6.9971585273742676e-01
    z[0,1,2]  R92       3.7243339419364929e-01
    z[0,1,2]  R93       6.2867981195449829e-01
    z[0,1,2]  R94       3.7749308347702026e-01
    z[0,1,2]  R95       2.9669496417045593e-01
    z[0,1,2]  R96       5.3719258308410645e-01
    z[0,1,2]  R97       6.7282044887542725e-01
    z[0,1,2]  R98       5.3101140260696411e-01
    z[0,1,2]  R99       2.5265955924987793e-01
    z[0,1,2]  R100      2.2434255480766296e-01
    z[0,1,2]  R101      -2.5789499282836914e-01
    z[0,1,2]  R102      4.0086638927459717e-01
    z[0,1,2]  R103      8.4713113307952881e-01
    z[0,1,2]  R104      2.7665188908576965e-01
    z[0,1,2]  R105      0.373761922121048
    z[0,1,2]  R106      9.2212641239166260e-01
    z[0,1,2]  R107      2.0049897953867912e-02
    z[0,1,2]  R108      1.0363273322582245e-01
    z[0,1,2]  R109      -5.5132254958152771e-02
    z[0,1,2]  R110      1.7765846848487854e-01
    z[0,1,2]  R111      -1.4813593029975891e-01
    z[0,1,2]  R112      -6.0631740838289261e-02
    z[0,1,2]  R113      7.0911563932895660e-02
    z[0,1,2]  R114      -2.7264159917831421e-01
    z[0,1,2]  R115      -2.3721061646938324e-01
    z[0,1,2]  R116      -1.1788218468427658e-01
    z[0,1,2]  R117      -3.7549829483032227e-01
    z[0,1,2]  R118      -1.2550555169582367e-01
    z[0,1,2]  R119      -1.3326528668403625e-01
    z[0,1,2]  R120      -6.1995391733944416e-03
    z[0,1,2]  R121      3.1355914473533630e-01
    z[0,1,2]  R122      -4.0524119138717651e-01
    z[0,1,2]  R123      1.9952647387981415e-01
    z[0,1,2]  R124      2.5198289752006531e-01
    z[0,1,2]  R125      -6.6592156887054443e-02
    z[0,1,2]  R126      -2.0460438728332520e-01
    z[0,1,2]  R127      1.0704782605171204e-01
    z[0,1,2]  R128      1.3273303396999836e-02
    z[0,1,2]  R129      1.6280081868171692e-01
    z[0,1,2]  R130      1.9041393697261810e-01
    z[0,1,2]  R131      7.0002920925617218e-02
    z[0,1,2]  R132      -2.6101595163345337e-01
    z[0,1,2]  R133      7.1109563112258911e-02
    z[0,1,2]  R134      1.5195743739604950e-01
    z[0,1,2]  R135      -9.9591560661792755e-02
    z[0,1,2]  R136      4.1462087631225586e-01
    z[0,1,2]  R137      -3.3298179507255554e-01
    z[0,1,2]  R138      4.3960276991128922e-02
    z[0,1,2]  R139      -4.0967562235891819e-03
    z[0,1,2]  R140      1.4690834283828735e-01
    z[0,1,2]  R141      7.8408278524875641e-02
    z[0,1,2]  R142      9.3858368694782257e-02
    z[0,1,2]  R143      1.6618616878986359e-01
    z[0,1,2]  R144      2.0638216286897659e-02
    z[0,1,2]  R145      1.9519396126270294e-01
    z[0,1,2]  R146      9.6629597246646881e-02
    z[0,1,2]  R147      2.1174415946006775e-01
    z[0,1,2]  R148      5.1338362693786621e-01
    z[0,1,2]  R149      7.7930486202239990e-01
    z[0,1,3]  R5        -1
    z[0,1,3]  R14       1
    z[0,1,3]  R62       -1
    z[0,1,3]  R63       1
    z[0,1,3]  R70       4.4222053140401840e-02
    z[0,1,3]  R71       -1.3470019400119781e-01
    z[0,1,3]  R72       -2.8704026341438293e-01
    z[0,1,3]  R73       -2.4648956954479218e-01
    z[0,1,3]  R74       -1.8796291947364807e-01
    z[0,1,3]  R75       1.4601151645183563e-01
    z[0,1,3]  R76       -9.7074195742607117e-02
    z[0,1,3]  R77       1.0145763307809830e-01
    z[0,1,3]  R78       -1.6864429414272308e-01
    z[0,1,3]  R79       0.300178587436676
    z[0,1,3]  R80       -7.0722915232181549e-02
    z[0,1,3]  R81       1.2170047499239445e-02
    z[0,1,3]  R82       -1.6872355341911316e-01
    z[0,1,3]  R83       -3.0889034271240234e-01
    z[0,1,3]  R84       3.1220692396163940e-01
    z[0,1,3]  R85       7.3165573179721832e-02
    z[0,1,3]  R86       2.8877484798431396e-01
    z[0,1,3]  R87       1.8450444936752319e-01
    z[0,1,3]  R88       8.5690997540950775e-02
    z[0,1,3]  R89       1.0713714361190796e-01
    z[0,1,3]  R90       -3.2739424705505371e-01
    z[0,1,3]  R91       -2.7972236275672913e-01
    z[0,1,3]  R92       -3.1490191817283630e-01
    z[0,1,3]  R93       -3.8572177290916443e-01
    z[0,1,3]  R94       -2.3742128908634186e-01
    z[0,1,3]  R95       -2.8748938441276550e-01
    z[0,1,3]  R96       -2.8587976098060608e-01
    z[0,1,3]  R97       -2.6113662123680115e-01
    z[0,1,3]  R98       -5.4309302568435669e-01
    z[0,1,3]  R99       -4.2717960476875305e-01
    z[0,1,3]  R100      4.9050047993659973e-01
    z[0,1,3]  R101      1.6774599254131317e-01
    z[0,1,3]  R102      3.5282951593399048e-01
    z[0,1,3]  R103      -4.4394549727439880e-01
    z[0,1,3]  R104      -8.7034332752227783e-01
    z[0,1,3]  R105      1.5707907080650330e-01
    z[0,1,3]  R106      7.1136265993118286e-02
    z[0,1,3]  R107      3.0250164866447449e-01
    z[0,1,3]  R108      -7.5055903196334839e-01
    z[0,1,3]  R109      -6.7583733797073364e-01
    z[0,1,3]  R110      -5.2714014053344727e-01
    z[0,1,3]  R111      -1.7141684889793396e-01
    z[0,1,3]  R112      -2.4051589891314507e-02
    z[0,1,3]  R113      -5.9793466329574585e-01
    z[0,1,3]  R114      -4.6273627877235413e-01
    z[0,1,3]  R115      -2.2545909881591797e-01
    z[0,1,3]  R116      -3.8147419691085815e-01
    z[0,1,3]  R117      -5.8227157592773438e-01
    z[0,1,3]  R118      -2.6461067795753479e-01
    z[0,1,3]  R119      -3.9880636334419250e-01
    z[0,1,3]  R120      -1.2796452641487122e-01
    z[0,1,3]  R121      2.8310397267341614e-01
    z[0,1,3]  R122      2.4331583082675934e-01
    z[0,1,3]  R123      7.2456523776054382e-02
    z[0,1,3]  R124      4.0017911791801453e-01
    z[0,1,3]  R125      3.2510197162628174e-01
    z[0,1,3]  R126      1.0274247825145721e-01
    z[0,1,3]  R127      4.3138790130615234e-01
    z[0,1,3]  R128      6.0794878005981445e-01
    z[0,1,3]  R129      2.7000385522842407e-01
    z[0,1,3]  R130      -2.2122806310653687e-01
    z[0,1,3]  R131      -2.4943706393241882e-01
    z[0,1,3]  R132      3.1544142961502075e-01
    z[0,1,3]  R133      2.4635457992553711e-01
    z[0,1,3]  R134      -4.2376585304737091e-02
    z[0,1,3]  R135      5.2524778991937637e-02
    z[0,1,3]  R136      -1.5484818816184998e-01
    z[0,1,3]  R137      1.7375695705413818e-01
    z[0,1,3]  R138      2.9080143570899963e-01
    z[0,1,3]  R139      2.5139921903610229e-01
    z[0,1,3]  R140      -5.9669923782348633e-01
    z[0,1,3]  R141      -0.152748703956604
    z[0,1,3]  R142      -3.1927478313446045e-01
    z[0,1,3]  R143      7.5129017233848572e-02
    z[0,1,3]  R144      -6.4138539135456085e-02
    z[0,1,3]  R145      -3.1122544407844543e-01
    z[0,1,3]  R146      3.1744691729545593e-01
    z[0,1,3]  R147      -4.7472648322582245e-02
    z[0,1,3]  R148      0.641027569770813
    z[0,1,3]  R149      4.1837012767791748e-01
    z[0,1,4]  R6        -1
    z[0,1,4]  R15       1
    z[0,1,4]  R64       -1
    z[0,1,4]  R65       1
    z[0,1,4]  R70       -3.7564572691917419e-01
    z[0,1,4]  R71       -1.7045332491397858e-01
    z[0,1,4]  R72       -6.6091604530811310e-02
    z[0,1,4]  R73       -3.8730047643184662e-02
    z[0,1,4]  R74       2.7339997887611389e-01
    z[0,1,4]  R75       -0.0617363266646862
    z[0,1,4]  R76       -3.4131160378456116e-01
    z[0,1,4]  R77       -7.2167210280895233e-02
    z[0,1,4]  R78       1.7700275778770447e-01
    z[0,1,4]  R79       -2.1491970121860504e-01
    z[0,1,4]  R80       1.4138107188045979e-02
    z[0,1,4]  R81       5.8108780533075333e-02
    z[0,1,4]  R82       1.3009758293628693e-01
    z[0,1,4]  R83       1.8706850707530975e-01
    z[0,1,4]  R84       1.4939698576927185e-01
    z[0,1,4]  R85       -2.4596697092056274e-01
    z[0,1,4]  R86       4.8291280865669250e-02
    z[0,1,4]  R87       -4.0485617518424988e-01
    z[0,1,4]  R88       -4.5830491930246353e-02
    z[0,1,4]  R89       2.7651217579841614e-01
    z[0,1,4]  R90       2.0069877803325653e-01
    z[0,1,4]  R91       -2.8072007000446320e-02
    z[0,1,4]  R92       1.8341344594955444e-01
    z[0,1,4]  R93       -1.0104627162218094e-01
    z[0,1,4]  R94       -2.2576268017292023e-01
    z[0,1,4]  R95       -1.6243544220924377e-01
    z[0,1,4]  R96       -2.6549813151359558e-01
    z[0,1,4]  R97       -1.7620180547237396e-01
    z[0,1,4]  R98       3.9468744397163391e-01
    z[0,1,4]  R99       -2.5569441914558411e-01
    z[0,1,4]  R100      -2.0987190306186676e-01
    z[0,1,4]  R101      8.1804707646369934e-02
    z[0,1,4]  R102      1.6349682211875916e-01
    z[0,1,4]  R103      -5.3939230740070343e-02
    z[0,1,4]  R104      6.1589833348989487e-03
    z[0,1,4]  R105      -4.9056809395551682e-02
    z[0,1,4]  R106      1.0225493460893631e-01
    z[0,1,4]  R107      4.8647204041481018e-01
    z[0,1,4]  R108      -4.6438881754875183e-01
    z[0,1,4]  R109      -4.9762633442878723e-01
    z[0,1,4]  R110      -7.4473358690738678e-02
    z[0,1,4]  R111      3.5818558186292648e-02
    z[0,1,4]  R112      -1.9742001593112946e-01
    z[0,1,4]  R113      3.3438715338706970e-01
    z[0,1,4]  R114      -0.207333505153656
    z[0,1,4]  R115      -1.1061331629753113e-01
    z[0,1,4]  R116      -0.0686548575758934
    z[0,1,4]  R117      2.1860344707965851e-01
    z[0,1,4]  R118      -6.0606843233108521e-01
    z[0,1,4]  R119      -4.0920057892799377e-01
    z[0,1,4]  R120      -2.6890264824032784e-02
    z[0,1,4]  R121      -2.5274107232689857e-02
    z[0,1,4]  R122      2.0200443267822266e-01
    z[0,1,4]  R123      1.1528035998344421e-01
    z[0,1,4]  R124      -3.2284778356552124e-01
    z[0,1,4]  R125      -7.9762347042560577e-02
    z[0,1,4]  R126      6.1005318164825439e-01
    z[0,1,4]  R127      1.2749303877353668e-01
    z[0,1,4]  R128      -1.8790359795093536e-01
    z[0,1,4]  R129      -5.0215828418731689e-01
    z[0,1,4]  R130      -1.1892067268490791e-02
    z[0,1,4]  R131      -6.9857522845268250e-02
    z[0,1,4]  R132      -2.5380348786711693e-02
    z[0,1,4]  R133      2.1475711464881897e-01
    z[0,1,4]  R134      3.8521581888198853e-01
    z[0,1,4]  R135      1.9272805750370026e-01
    z[0,1,4]  R136      -4.7011303901672363e-01
    z[0,1,4]  R137      6.4100092649459839e-01
    z[0,1,4]  R138      -2.9409998655319214e-01
    z[0,1,4]  R139      -7.3312622308731079e-01
    z[0,1,4]  R140      -3.9989843964576721e-01
    z[0,1,4]  R141      5.2233719825744629e-01
    z[0,1,4]  R142      0.336622953414917
    z[0,1,4]  R143      2.9592399951070547e-03
    z[0,1,4]  R144      1.1275199800729752e-01
    z[0,1,4]  R145      4.6267968416213989e-01
    z[0,1,4]  R146      -1.8894420564174652e-01
    z[0,1,4]  R147      -0.502036452293396
    z[0,1,4]  R148      0.291445255279541
    z[0,1,4]  R149      2.7686533331871033e-01
    z[0,1,5]  R7        -1
    z[0,1,5]  R16       1
    z[0,1,5]  R66       -1
    z[0,1,5]  R67       1
    z[0,1,5]  R70       -4.6565684676170349e-01
    z[0,1,5]  R71       -5.9288865327835083e-01
    z[0,1,5]  R72       -6.7348307371139526e-01
    z[0,1,5]  R73       -2.7893880009651184e-01
    z[0,1,5]  R74       -6.5360978245735168e-02
    z[0,1,5]  R75       -1.6454692184925079e-01
    z[0,1,5]  R76       -7.2398573160171509e-02
    z[0,1,5]  R77       0.0906539037823677
    z[0,1,5]  R78       -6.2161255627870560e-02
    z[0,1,5]  R79       -4.9832555651664734e-01
    z[0,1,5]  R80       7.1085587143898010e-02
    z[0,1,5]  R81       9.9303878843784332e-02
    z[0,1,5]  R82       1.9442611932754517e-01
    z[0,1,5]  R83       -1.3173783663660288e-03
    z[0,1,5]  R84       -1.2290755286812782e-02
    z[0,1,5]  R85       1.2302239984273911e-01
    z[0,1,5]  R86       2.0458373427391052e-01
    z[0,1,5]  R87       -0.0671120211482048
    z[0,1,5]  R88       -7.3197772726416588e-03
    z[0,1,5]  R89       1.2532912194728851e-01
    z[0,1,5]  R90       4.4835552573204041e-01
    z[0,1,5]  R91       4.6172514557838440e-01
    z[0,1,5]  R92       4.7400042414665222e-01
    z[0,1,5]  R93       2.7603101730346680e-01
    z[0,1,5]  R94       4.3709456920623779e-01
    z[0,1,5]  R95       5.8497828245162964e-01
    z[0,1,5]  R96       3.7317070364952087e-01
    z[0,1,5]  R97       1.8044155091047287e-02
    z[0,1,5]  R98       5.0306838750839233e-01
    z[0,1,5]  R99       3.6254772543907166e-01
    z[0,1,5]  R100      5.1565271615982056e-01
    z[0,1,5]  R101      6.0653075575828552e-02
    z[0,1,5]  R102      2.6133623719215393e-01
    z[0,1,5]  R103      1.4096808433532715e-01
    z[0,1,5]  R104      2.5017103180289268e-02
    z[0,1,5]  R105      2.8611651062965393e-01
    z[0,1,5]  R106      2.3158925771713257e-01
    z[0,1,5]  R107      4.9871876835823059e-01
    z[0,1,5]  R108      3.6343118548393250e-01
    z[0,1,5]  R109      4.5754191279411316e-01
    z[0,1,5]  R110      -4.2726588249206543e-01
    z[0,1,5]  R111      -4.4893521070480347e-01
    z[0,1,5]  R112      -1.9430667161941528e-01
    z[0,1,5]  R113      1.8883095681667328e-01
    z[0,1,5]  R114      -3.1816062331199646e-01
    z[0,1,5]  R115      3.5657492280006409e-01
    z[0,1,5]  R116      -0.413128525018692
    z[0,1,5]  R117      0.0798230916261673
    z[0,1,5]  R118      -5.1094375550746918e-02
    z[0,1,5]  R119      1.0263931751251221e-01
    z[0,1,5]  R120      3.4040069580078125e-01
    z[0,1,5]  R121      9.6004633232951164e-03
    z[0,1,5]  R122      2.4548135697841644e-01
    z[0,1,5]  R123      3.8709971308708191e-01
    z[0,1,5]  R124      3.2117941975593567e-01
    z[0,1,5]  R125      4.8737379908561707e-01
    z[0,1,5]  R126      3.2575258612632751e-01
    z[0,1,5]  R127      3.6358457803726196e-01
    z[0,1,5]  R128      2.8527006506919861e-01
    z[0,1,5]  R129      1.6940513253211975e-01
    z[0,1,5]  R130      5.3804576396942139e-01
    z[0,1,5]  R131      4.4933566451072693e-01
    z[0,1,5]  R132      3.4121209383010864e-01
    z[0,1,5]  R133      2.7260869741439819e-01
    z[0,1,5]  R134      -1.8417501449584961e-01
    z[0,1,5]  R135      -4.8523122072219849e-01
    z[0,1,5]  R136      -5.0318732857704163e-02
    z[0,1,5]  R137      -5.4362822324037552e-02
    z[0,1,5]  R138      -5.0268638134002686e-01
    z[0,1,5]  R139      -9.4509720802307129e-02
    z[0,1,5]  R140      6.2728708982467651e-01
    z[0,1,5]  R141      -8.9115977287292480e-02
    z[0,1,5]  R142      -1.9698626419994980e-04
    z[0,1,5]  R143      4.9155500531196594e-01
    z[0,1,5]  R144      1.5471910126507282e-02
    z[0,1,5]  R145      7.5048275291919708e-02
    z[0,1,5]  R146      -6.8633213639259338e-02
    z[0,1,5]  R147      -9.3955181539058685e-02
    z[0,1,5]  R148      2.3310044407844543e-01
    z[0,1,5]  R149      9.1374032199382782e-02
    z[0,1,6]  R8        -1
    z[0,1,6]  R17       1
    z[0,1,6]  R68       -1
    z[0,1,6]  R69       1
    z[0,1,6]  R70       7.7819757163524628e-02
    z[0,1,6]  R71       1.6664761304855347e-01
    z[0,1,6]  R72       -2.0606763660907745e-02
    z[0,1,6]  R73       2.6358818635344505e-02
    z[0,1,6]  R74       -0.084261953830719
    z[0,1,6]  R75       4.2935600876808167e-01
    z[0,1,6]  R76       -4.5721733570098877e-01
    z[0,1,6]  R77       1.9737339019775391e-01
    z[0,1,6]  R78       3.2508898526430130e-02
    z[0,1,6]  R79       3.0719056725502014e-01
    z[0,1,6]  R80       -4.3408204801380634e-03
    z[0,1,6]  R81       1.4412012696266174e-01
    z[0,1,6]  R82       2.8908040374517441e-02
    z[0,1,6]  R83       -3.2881464809179306e-02
    z[0,1,6]  R84       0.237397700548172
    z[0,1,6]  R85       9.5143593847751617e-02
    z[0,1,6]  R86       -1.1203897744417191e-01
    z[0,1,6]  R87       0.0405583456158638
    z[0,1,6]  R88       2.0985612273216248e-01
    z[0,1,6]  R89       -4.4531369209289551e-01
    z[0,1,6]  R90       4.6910487115383148e-02
    z[0,1,6]  R91       2.4945002794265747e-01
    z[0,1,6]  R92       3.3773830533027649e-01
    z[0,1,6]  R93       -3.7616726756095886e-01
    z[0,1,6]  R94       -0.0771293193101883
    z[0,1,6]  R95       1.1005973647115752e-04
    z[0,1,6]  R96       6.0303110629320145e-02
    z[0,1,6]  R97       -2.4672379717230797e-02
    z[0,1,6]  R98       -2.8605468571186066e-02
    z[0,1,6]  R99       -4.3676221370697021e-01
    z[0,1,6]  R100      -2.8541502356529236e-01
    z[0,1,6]  R101      -2.6354700326919556e-01
    z[0,1,6]  R102      -9.7607143223285675e-02
    z[0,1,6]  R103      -1.3041138648986816e-01
    z[0,1,6]  R104      -4.3180756270885468e-02
    z[0,1,6]  R105      -3.5434693098068237e-01
    z[0,1,6]  R106      -3.6994233727455139e-02
    z[0,1,6]  R107      3.0429449677467346e-01
    z[0,1,6]  R108      1.6009826958179474e-01
    z[0,1,6]  R109      2.1410284936428070e-01
    z[0,1,6]  R110      -8.4079019725322723e-02
    z[0,1,6]  R111      3.4917865414172411e-03
    z[0,1,6]  R112      9.3952931463718414e-02
    z[0,1,6]  R113      -2.6736435294151306e-01
    z[0,1,6]  R114      5.2625524997711182e-01
    z[0,1,6]  R115      -8.1423139199614525e-03
    z[0,1,6]  R116      2.3798566311597824e-02
    z[0,1,6]  R117      4.5384612679481506e-01
    z[0,1,6]  R118      2.9452082514762878e-01
    z[0,1,6]  R119      5.3818774223327637e-01
    z[0,1,6]  R120      2.4685344099998474e-01
    z[0,1,6]  R121      -2.9452103376388550e-01
    z[0,1,6]  R122      4.3733417987823486e-01
    z[0,1,6]  R123      -1.2433338165283203e-01
    z[0,1,6]  R124      -3.8061115145683289e-01
    z[0,1,6]  R125      0.0547383613884449
    z[0,1,6]  R126      1.0755355656147003e-01
    z[0,1,6]  R127      0.0466521717607975
    z[0,1,6]  R128      -0.074155293405056
    z[0,1,6]  R129      1.6571673750877380e-01
    z[0,1,6]  R130      1.4408499002456665e-02
    z[0,1,6]  R131      -1.2025839835405350e-01
    z[0,1,6]  R132      5.1061216741800308e-02
    z[0,1,6]  R133      -1.9564969837665558e-01
    z[0,1,6]  R134      8.6739897727966309e-02
    z[0,1,6]  R135      3.4491127729415894e-01
    z[0,1,6]  R136      -5.8239664882421494e-02
    z[0,1,6]  R137      4.4052168726921082e-02
    z[0,1,6]  R138      1.7404365539550781e-01
    z[0,1,6]  R139      2.4868105351924896e-01
    z[0,1,6]  R140      -2.5180861353874207e-02
    z[0,1,6]  R141      7.3525518178939819e-02
    z[0,1,6]  R142      2.1956019103527069e-01
    z[0,1,6]  R143      -2.2008366882801056e-01
    z[0,1,6]  R144      1.4444258809089661e-01
    z[0,1,6]  R145      -2.2445949912071228e-01
    z[0,1,6]  R146      -1.0294097661972046e-01
    z[0,1,6]  R147      1.2430543079972267e-02
    z[0,1,6]  R148      -2.4548610672354698e-02
    z[0,1,6]  R149      -1.1802790313959122e-01
    z[1,0,0]  R2        1
    z[1,0,0]  R11       -1
    z[1,0,0]  R150      -1
    z[1,0,0]  R151      1
    z[1,0,0]  R164      1.0424977540969849e-01
    z[1,0,0]  R165      4.5252549648284912e-01
    z[1,0,0]  R166      0.0661509558558464
    z[1,0,0]  R167      2.8299051523208618e-01
    z[1,0,0]  R168      1.2149226665496826e-01
    z[1,0,0]  R169      0.612120509147644
    z[1,0,0]  R170      6.7033219337463379e-01
    z[1,0,0]  R171      1.5490005910396576e-01
    z[1,0,0]  R172      2.8226104378700256e-01
    z[1,0,0]  R173      -2.4477690458297729e-01
    z[1,0,0]  R174      -3.3862102031707764e-01
    z[1,0,0]  R175      -2.5495833158493042e-01
    z[1,0,0]  R176      -8.7855964899063110e-02
    z[1,0,0]  R177      -3.8494125008583069e-01
    z[1,0,0]  R178      9.0316146612167358e-02
    z[1,0,0]  R179      -1.0013429075479507e-01
    z[1,0,0]  R180      -2.1069069206714630e-01
    z[1,0,0]  R181      -2.3835390806198120e-01
    z[1,0,0]  R182      -8.9270561933517456e-02
    z[1,0,0]  R183      -1.3217581808567047e-01
    z[1,0,0]  R184      -5.6992095708847046e-01
    z[1,0,0]  R185      2.1340602636337280e-01
    z[1,0,0]  R186      3.7517610192298889e-01
    z[1,0,0]  R187      -7.1401357650756836e-02
    z[1,0,0]  R188      -1.5552681684494019e-01
    z[1,0,0]  R189      -3.3658319711685181e-01
    z[1,0,0]  R190      -3.7117803096771240e-01
    z[1,0,0]  R191      2.5435557961463928e-01
    z[1,0,0]  R192      -1.4337022602558136e-01
    z[1,0,0]  R193      3.9398744702339172e-02
    z[1,0,0]  R194      1.0379552096128464e-01
    z[1,0,0]  R195      -6.4998644590377808e-01
    z[1,0,0]  R196      -7.4237370491027832e-01
    z[1,0,0]  R197      -0.0773012712597847
    z[1,0,0]  R198      -0.246307834982872
    z[1,0,0]  R199      -1.4701296389102936e-01
    z[1,0,0]  R200      4.7910723835229874e-02
    z[1,0,0]  R201      -1.6824087128043175e-02
    z[1,0,0]  R202      3.1259888410568237e-01
    z[1,0,0]  R203      1.6191582381725311e-01
    z[1,0,0]  R204      -0.595670759677887
    z[1,0,0]  R205      -3.7485894560813904e-01
    z[1,0,0]  R206      -1.8457423150539398e-01
    z[1,0,0]  R207      -5.7814240455627441e-01
    z[1,0,0]  R208      -3.1091922521591187e-01
    z[1,0,0]  R209      -4.4319561123847961e-01
    z[1,0,0]  R210      -2.9543972015380859e-01
    z[1,0,0]  R211      -4.4200652837753296e-01
    z[1,0,0]  R212      6.2063220888376236e-02
    z[1,0,0]  R213      -1.3802291452884674e-01
    z[1,0,0]  R214      1.2147828191518784e-01
    z[1,0,0]  R215      -2.9867494106292725e-01
    z[1,0,0]  R216      -3.1643894314765930e-01
    z[1,0,0]  R217      3.2006077468395233e-02
    z[1,0,0]  R218      5.8187246322631836e-02
    z[1,0,0]  R219      -2.0086118951439857e-02
    z[1,0,0]  R220      2.5060039758682251e-01
    z[1,0,0]  R221      -1.2390428036451340e-01
    z[1,0,0]  R222      -1.4783337712287903e-01
    z[1,0,0]  R223      -1.3143141567707062e-01
    z[1,0,0]  R224      5.4461634159088135e-01
    z[1,0,0]  R225      3.9418607950210571e-01
    z[1,0,0]  R226      6.1878937482833862e-01
    z[1,0,0]  R227      0.476563036441803
    z[1,0,0]  R228      7.4172264337539673e-01
    z[1,0,0]  R229      6.7241811752319336e-01
    z[1,0,0]  R230      6.4190948009490967e-01
    z[1,0,0]  R231      6.5134871006011963e-01
    z[1,0,0]  R232      1.1419311165809631e-01
    z[1,0,0]  R233      5.9473598003387451e-01
    z[1,0,0]  R234      -9.8668999969959259e-02
    z[1,0,0]  R235      6.1946451663970947e-01
    z[1,0,0]  R236      0.542599081993103
    z[1,0,0]  R237      -1.0434793680906296e-01
    z[1,0,0]  R238      3.2040235400199890e-01
    z[1,0,0]  R239      7.2470021247863770e-01
    z[1,0,0]  R240      -3.1749375630170107e-03
    z[1,0,0]  R241      3.7793529033660889e-01
    z[1,0,0]  R242      -2.0786963403224945e-01
    z[1,0,0]  R243      -1.8122604489326477e-01
    z[1,0,1]  R3        1
    z[1,0,1]  R12       -1
    z[1,0,1]  R152      -1
    z[1,0,1]  R153      1
    z[1,0,1]  R164      -0.696075439453125
    z[1,0,1]  R165      -7.3556423187255859e-01
    z[1,0,1]  R166      -9.5174181461334229e-01
    z[1,0,1]  R167      -0.581727147102356
    z[1,0,1]  R168      -5.2499836683273315e-01
    z[1,0,1]  R169      -6.1543524265289307e-01
    z[1,0,1]  R170      4.6398368477821350e-01
    z[1,0,1]  R171      -4.8562464118003845e-01
    z[1,0,1]  R172      -6.1472445726394653e-01
    z[1,0,1]  R173      -5.4373896121978760e-01
    z[1,0,1]  R174      8.3149868249893188e-01
    z[1,0,1]  R175      8.1795817613601685e-01
    z[1,0,1]  R176      0.6903116106987
    z[1,0,1]  R177      0.792568564414978
    z[1,0,1]  R178      0.64494389295578
    z[1,0,1]  R179      7.9558509588241577e-01
    z[1,0,1]  R180      6.4291751384735107e-01
    z[1,0,1]  R181      0.771367609500885
    z[1,0,1]  R182      7.0715421438217163e-01
    z[1,0,1]  R183      7.5815582275390625e-01
    z[1,0,1]  R184      -5.4785811901092529e-01
    z[1,0,1]  R185      8.1614577770233154e-01
    z[1,0,1]  R186      7.5626271963119507e-01
    z[1,0,1]  R187      8.7774705886840820e-01
    z[1,0,1]  R188      8.7240421772003174e-01
    z[1,0,1]  R189      0.694605827331543
    z[1,0,1]  R190      6.6287875175476074e-01
    z[1,0,1]  R191      6.1518836021423340e-01
    z[1,0,1]  R192      7.2351044416427612e-01
    z[1,0,1]  R193      5.7182258367538452e-01
    z[1,0,1]  R194      -2.3990131914615631e-01
    z[1,0,1]  R195      -5.1171648502349854e-01
    z[1,0,1]  R196      -4.2025437951087952e-01
    z[1,0,1]  R197      8.1895691156387329e-01
    z[1,0,1]  R198      9.4919794797897339e-01
    z[1,0,1]  R199      7.5719106197357178e-01
    z[1,0,1]  R200      9.1465157270431519e-01
    z[1,0,1]  R201      8.3162802457809448e-01
    z[1,0,1]  R202      -2.9651984572410583e-01
    z[1,0,1]  R203      -3.0413705110549927e-01
    z[1,0,1]  R204      -4.4385874271392822e-01
    z[1,0,1]  R205      -4.2086270451545715e-01
    z[1,0,1]  R206      -0.529179573059082
    z[1,0,1]  R207      -4.1710504889488220e-01
    z[1,0,1]  R208      -8.6575299501419067e-01
    z[1,0,1]  R209      -0.421099990606308
    z[1,0,1]  R210      -3.9300060272216797e-01
    z[1,0,1]  R211      -3.5395517945289612e-01
    z[1,0,1]  R212      -4.0363934636116028e-01
    z[1,0,1]  R213      -7.0809775590896606e-01
    z[1,0,1]  R214      0.897419273853302
    z[1,0,1]  R215      0.900534987449646
    z[1,0,1]  R216      0.902877151966095
    z[1,0,1]  R217      9.1613984107971191e-01
    z[1,0,1]  R218      8.9577335119247437e-01
    z[1,0,1]  R219      9.3991589546203613e-01
    z[1,0,1]  R220      8.9128780364990234e-01
    z[1,0,1]  R221      8.3712917566299438e-01
    z[1,0,1]  R222      8.4881031513214111e-01
    z[1,0,1]  R223      0.816559374332428
    z[1,0,1]  R224      5.4552732035517693e-03
    z[1,0,1]  R225      2.3812660947442055e-02
    z[1,0,1]  R226      0.0827384814620018
    z[1,0,1]  R227      3.1028954312205315e-02
    z[1,0,1]  R228      5.4847251623868942e-02
    z[1,0,1]  R229      9.2687368392944336e-02
    z[1,0,1]  R230      -6.5321475267410278e-02
    z[1,0,1]  R231      1.5127401053905487e-01
    z[1,0,1]  R232      1.9041022285819054e-02
    z[1,0,1]  R233      1.1130225658416748e-01
    z[1,0,1]  R234      -5.5492192506790161e-01
    z[1,0,1]  R235      -6.6467088460922241e-01
    z[1,0,1]  R236      -5.6200414896011353e-01
    z[1,0,1]  R237      -1.8602198362350464e-01
    z[1,0,1]  R238      -2.4653628468513489e-01
    z[1,0,1]  R239      3.1718581914901733e-01
    z[1,0,1]  R240      2.8134384751319885e-01
    z[1,0,1]  R241      -4.3276441097259521e-01
    z[1,0,1]  R242      -9.6648633480072021e-02
    z[1,0,1]  R243      6.7415893077850342e-02
    z[1,0,2]  R4        1
    z[1,0,2]  R13       -1
    z[1,0,2]  R154      -1
    z[1,0,2]  R155      1
    z[1,0,2]  R164      1.7765846848487854e-01
    z[1,0,2]  R165      -1.4813593029975891e-01
    z[1,0,2]  R166      -6.0631740838289261e-02
    z[1,0,2]  R167      7.0911563932895660e-02
    z[1,0,2]  R168      -2.7264159917831421e-01
    z[1,0,2]  R169      -2.3721061646938324e-01
    z[1,0,2]  R170      -1.1788218468427658e-01
    z[1,0,2]  R171      -3.7549829483032227e-01
    z[1,0,2]  R172      -1.2550555169582367e-01
    z[1,0,2]  R173      -1.3326528668403625e-01
    z[1,0,2]  R174      -6.1995391733944416e-03
    z[1,0,2]  R175      3.1355914473533630e-01
    z[1,0,2]  R176      -4.0524119138717651e-01
    z[1,0,2]  R177      1.9952647387981415e-01
    z[1,0,2]  R178      2.5198289752006531e-01
    z[1,0,2]  R179      -6.6592156887054443e-02
    z[1,0,2]  R180      -2.0460438728332520e-01
    z[1,0,2]  R181      1.0704782605171204e-01
    z[1,0,2]  R182      1.3273303396999836e-02
    z[1,0,2]  R183      1.6280081868171692e-01
    z[1,0,2]  R184      1.9041393697261810e-01
    z[1,0,2]  R185      7.0002920925617218e-02
    z[1,0,2]  R186      -2.6101595163345337e-01
    z[1,0,2]  R187      7.1109563112258911e-02
    z[1,0,2]  R188      1.5195743739604950e-01
    z[1,0,2]  R189      -9.9591560661792755e-02
    z[1,0,2]  R190      4.1462087631225586e-01
    z[1,0,2]  R191      -3.3298179507255554e-01
    z[1,0,2]  R192      4.3960276991128922e-02
    z[1,0,2]  R193      -4.0967562235891819e-03
    z[1,0,2]  R194      1.4690834283828735e-01
    z[1,0,2]  R195      7.8408278524875641e-02
    z[1,0,2]  R196      9.3858368694782257e-02
    z[1,0,2]  R197      1.6618616878986359e-01
    z[1,0,2]  R198      2.0638216286897659e-02
    z[1,0,2]  R199      1.9519396126270294e-01
    z[1,0,2]  R200      9.6629597246646881e-02
    z[1,0,2]  R201      2.1174415946006775e-01
    z[1,0,2]  R202      5.1338362693786621e-01
    z[1,0,2]  R203      7.7930486202239990e-01
    z[1,0,2]  R204      -2.8671988844871521e-01
    z[1,0,2]  R205      -5.0583446025848389e-01
    z[1,0,2]  R206      -3.8096874952316284e-01
    z[1,0,2]  R207      -5.9246593713760376e-01
    z[1,0,2]  R208      -1.7986467480659485e-01
    z[1,0,2]  R209      -6.2425899505615234e-01
    z[1,0,2]  R210      -6.4657533168792725e-01
    z[1,0,2]  R211      -7.8528332710266113e-01
    z[1,0,2]  R212      -8.7665939331054688e-01
    z[1,0,2]  R213      -2.3562364280223846e-02
    z[1,0,2]  R214      -4.1183501482009888e-01
    z[1,0,2]  R215      -2.5626808404922485e-01
    z[1,0,2]  R216      2.5473069399595261e-02
    z[1,0,2]  R217      1.6784700751304626e-01
    z[1,0,2]  R218      -1.3380204141139984e-01
    z[1,0,2]  R219      1.6160102188587189e-01
    z[1,0,2]  R220      5.1723778247833252e-02
    z[1,0,2]  R221      -2.8242358565330505e-01
    z[1,0,2]  R222      4.5180737972259521e-01
    z[1,0,2]  R223      -1.1835354566574097e-01
    z[1,0,2]  R224      5.9386283159255981e-01
    z[1,0,2]  R225      6.9971585273742676e-01
    z[1,0,2]  R226      3.7243339419364929e-01
    z[1,0,2]  R227      6.2867981195449829e-01
    z[1,0,2]  R228      3.7749308347702026e-01
    z[1,0,2]  R229      2.9669496417045593e-01
    z[1,0,2]  R230      5.3719258308410645e-01
    z[1,0,2]  R231      6.7282044887542725e-01
    z[1,0,2]  R232      5.3101140260696411e-01
    z[1,0,2]  R233      2.5265955924987793e-01
    z[1,0,2]  R234      2.2434255480766296e-01
    z[1,0,2]  R235      -2.5789499282836914e-01
    z[1,0,2]  R236      4.0086638927459717e-01
    z[1,0,2]  R237      8.4713113307952881e-01
    z[1,0,2]  R238      2.7665188908576965e-01
    z[1,0,2]  R239      0.373761922121048
    z[1,0,2]  R240      9.2212641239166260e-01
    z[1,0,2]  R241      2.0049897953867912e-02
    z[1,0,2]  R242      1.0363273322582245e-01
    z[1,0,2]  R243      -5.5132254958152771e-02
    z[1,0,3]  R5        1
    z[1,0,3]  R14       -1
    z[1,0,3]  R156      -1
    z[1,0,3]  R157      1
    z[1,0,3]  R164      -5.2714014053344727e-01
    z[1,0,3]  R165      -1.7141684889793396e-01
    z[1,0,3]  R166      -2.4051589891314507e-02
    z[1,0,3]  R167      -5.9793466329574585e-01
    z[1,0,3]  R168      -4.6273627877235413e-01
    z[1,0,3]  R169      -2.2545909881591797e-01
    z[1,0,3]  R170      -3.8147419691085815e-01
    z[1,0,3]  R171      -5.8227157592773438e-01
    z[1,0,3]  R172      -2.6461067795753479e-01
    z[1,0,3]  R173      -3.9880636334419250e-01
    z[1,0,3]  R174      -1.2796452641487122e-01
    z[1,0,3]  R175      2.8310397267341614e-01
    z[1,0,3]  R176      2.4331583082675934e-01
    z[1,0,3]  R177      7.2456523776054382e-02
    z[1,0,3]  R178      4.0017911791801453e-01
    z[1,0,3]  R179      3.2510197162628174e-01
    z[1,0,3]  R180      1.0274247825145721e-01
    z[1,0,3]  R181      4.3138790130615234e-01
    z[1,0,3]  R182      6.0794878005981445e-01
    z[1,0,3]  R183      2.7000385522842407e-01
    z[1,0,3]  R184      -2.2122806310653687e-01
    z[1,0,3]  R185      -2.4943706393241882e-01
    z[1,0,3]  R186      3.1544142961502075e-01
    z[1,0,3]  R187      2.4635457992553711e-01
    z[1,0,3]  R188      -4.2376585304737091e-02
    z[1,0,3]  R189      5.2524778991937637e-02
    z[1,0,3]  R190      -1.5484818816184998e-01
    z[1,0,3]  R191      1.7375695705413818e-01
    z[1,0,3]  R192      2.9080143570899963e-01
    z[1,0,3]  R193      2.5139921903610229e-01
    z[1,0,3]  R194      -5.9669923782348633e-01
    z[1,0,3]  R195      -0.152748703956604
    z[1,0,3]  R196      -3.1927478313446045e-01
    z[1,0,3]  R197      7.5129017233848572e-02
    z[1,0,3]  R198      -6.4138539135456085e-02
    z[1,0,3]  R199      -3.1122544407844543e-01
    z[1,0,3]  R200      3.1744691729545593e-01
    z[1,0,3]  R201      -4.7472648322582245e-02
    z[1,0,3]  R202      0.641027569770813
    z[1,0,3]  R203      4.1837012767791748e-01
    z[1,0,3]  R204      4.4222053140401840e-02
    z[1,0,3]  R205      -1.3470019400119781e-01
    z[1,0,3]  R206      -2.8704026341438293e-01
    z[1,0,3]  R207      -2.4648956954479218e-01
    z[1,0,3]  R208      -1.8796291947364807e-01
    z[1,0,3]  R209      1.4601151645183563e-01
    z[1,0,3]  R210      -9.7074195742607117e-02
    z[1,0,3]  R211      1.0145763307809830e-01
    z[1,0,3]  R212      -1.6864429414272308e-01
    z[1,0,3]  R213      0.300178587436676
    z[1,0,3]  R214      -7.0722915232181549e-02
    z[1,0,3]  R215      1.2170047499239445e-02
    z[1,0,3]  R216      -1.6872355341911316e-01
    z[1,0,3]  R217      -3.0889034271240234e-01
    z[1,0,3]  R218      3.1220692396163940e-01
    z[1,0,3]  R219      7.3165573179721832e-02
    z[1,0,3]  R220      2.8877484798431396e-01
    z[1,0,3]  R221      1.8450444936752319e-01
    z[1,0,3]  R222      8.5690997540950775e-02
    z[1,0,3]  R223      1.0713714361190796e-01
    z[1,0,3]  R224      -3.2739424705505371e-01
    z[1,0,3]  R225      -2.7972236275672913e-01
    z[1,0,3]  R226      -3.1490191817283630e-01
    z[1,0,3]  R227      -3.8572177290916443e-01
    z[1,0,3]  R228      -2.3742128908634186e-01
    z[1,0,3]  R229      -2.8748938441276550e-01
    z[1,0,3]  R230      -2.8587976098060608e-01
    z[1,0,3]  R231      -2.6113662123680115e-01
    z[1,0,3]  R232      -5.4309302568435669e-01
    z[1,0,3]  R233      -4.2717960476875305e-01
    z[1,0,3]  R234      4.9050047993659973e-01
    z[1,0,3]  R235      1.6774599254131317e-01
    z[1,0,3]  R236      3.5282951593399048e-01
    z[1,0,3]  R237      -4.4394549727439880e-01
    z[1,0,3]  R238      -8.7034332752227783e-01
    z[1,0,3]  R239      1.5707907080650330e-01
    z[1,0,3]  R240      7.1136265993118286e-02
    z[1,0,3]  R241      3.0250164866447449e-01
    z[1,0,3]  R242      -7.5055903196334839e-01
    z[1,0,3]  R243      -6.7583733797073364e-01
    z[1,0,4]  R6        1
    z[1,0,4]  R15       -1
    z[1,0,4]  R158      -1
    z[1,0,4]  R159      1
    z[1,0,4]  R164      -7.4473358690738678e-02
    z[1,0,4]  R165      3.5818558186292648e-02
    z[1,0,4]  R166      -1.9742001593112946e-01
    z[1,0,4]  R167      3.3438715338706970e-01
    z[1,0,4]  R168      -0.207333505153656
    z[1,0,4]  R169      -1.1061331629753113e-01
    z[1,0,4]  R170      -0.0686548575758934
    z[1,0,4]  R171      2.1860344707965851e-01
    z[1,0,4]  R172      -6.0606843233108521e-01
    z[1,0,4]  R173      -4.0920057892799377e-01
    z[1,0,4]  R174      -2.6890264824032784e-02
    z[1,0,4]  R175      -2.5274107232689857e-02
    z[1,0,4]  R176      2.0200443267822266e-01
    z[1,0,4]  R177      1.1528035998344421e-01
    z[1,0,4]  R178      -3.2284778356552124e-01
    z[1,0,4]  R179      -7.9762347042560577e-02
    z[1,0,4]  R180      6.1005318164825439e-01
    z[1,0,4]  R181      1.2749303877353668e-01
    z[1,0,4]  R182      -1.8790359795093536e-01
    z[1,0,4]  R183      -5.0215828418731689e-01
    z[1,0,4]  R184      -1.1892067268490791e-02
    z[1,0,4]  R185      -6.9857522845268250e-02
    z[1,0,4]  R186      -2.5380348786711693e-02
    z[1,0,4]  R187      2.1475711464881897e-01
    z[1,0,4]  R188      3.8521581888198853e-01
    z[1,0,4]  R189      1.9272805750370026e-01
    z[1,0,4]  R190      -4.7011303901672363e-01
    z[1,0,4]  R191      6.4100092649459839e-01
    z[1,0,4]  R192      -2.9409998655319214e-01
    z[1,0,4]  R193      -7.3312622308731079e-01
    z[1,0,4]  R194      -3.9989843964576721e-01
    z[1,0,4]  R195      5.2233719825744629e-01
    z[1,0,4]  R196      0.336622953414917
    z[1,0,4]  R197      2.9592399951070547e-03
    z[1,0,4]  R198      1.1275199800729752e-01
    z[1,0,4]  R199      4.6267968416213989e-01
    z[1,0,4]  R200      -1.8894420564174652e-01
    z[1,0,4]  R201      -0.502036452293396
    z[1,0,4]  R202      0.291445255279541
    z[1,0,4]  R203      2.7686533331871033e-01
    z[1,0,4]  R204      -3.7564572691917419e-01
    z[1,0,4]  R205      -1.7045332491397858e-01
    z[1,0,4]  R206      -6.6091604530811310e-02
    z[1,0,4]  R207      -3.8730047643184662e-02
    z[1,0,4]  R208      2.7339997887611389e-01
    z[1,0,4]  R209      -0.0617363266646862
    z[1,0,4]  R210      -3.4131160378456116e-01
    z[1,0,4]  R211      -7.2167210280895233e-02
    z[1,0,4]  R212      1.7700275778770447e-01
    z[1,0,4]  R213      -2.1491970121860504e-01
    z[1,0,4]  R214      1.4138107188045979e-02
    z[1,0,4]  R215      5.8108780533075333e-02
    z[1,0,4]  R216      1.3009758293628693e-01
    z[1,0,4]  R217      1.8706850707530975e-01
    z[1,0,4]  R218      1.4939698576927185e-01
    z[1,0,4]  R219      -2.4596697092056274e-01
    z[1,0,4]  R220      4.8291280865669250e-02
    z[1,0,4]  R221      -4.0485617518424988e-01
    z[1,0,4]  R222      -4.5830491930246353e-02
    z[1,0,4]  R223      2.7651217579841614e-01
    z[1,0,4]  R224      2.0069877803325653e-01
    z[1,0,4]  R225      -2.8072007000446320e-02
    z[1,0,4]  R226      1.8341344594955444e-01
    z[1,0,4]  R227      -1.0104627162218094e-01
    z[1,0,4]  R228      -2.2576268017292023e-01
    z[1,0,4]  R229      -1.6243544220924377e-01
    z[1,0,4]  R230      -2.6549813151359558e-01
    z[1,0,4]  R231      -1.7620180547237396e-01
    z[1,0,4]  R232      3.9468744397163391e-01
    z[1,0,4]  R233      -2.5569441914558411e-01
    z[1,0,4]  R234      -2.0987190306186676e-01
    z[1,0,4]  R235      8.1804707646369934e-02
    z[1,0,4]  R236      1.6349682211875916e-01
    z[1,0,4]  R237      -5.3939230740070343e-02
    z[1,0,4]  R238      6.1589833348989487e-03
    z[1,0,4]  R239      -4.9056809395551682e-02
    z[1,0,4]  R240      1.0225493460893631e-01
    z[1,0,4]  R241      4.8647204041481018e-01
    z[1,0,4]  R242      -4.6438881754875183e-01
    z[1,0,4]  R243      -4.9762633442878723e-01
    z[1,0,5]  R7        1
    z[1,0,5]  R16       -1
    z[1,0,5]  R160      -1
    z[1,0,5]  R161      1
    z[1,0,5]  R164      -4.2726588249206543e-01
    z[1,0,5]  R165      -4.4893521070480347e-01
    z[1,0,5]  R166      -1.9430667161941528e-01
    z[1,0,5]  R167      1.8883095681667328e-01
    z[1,0,5]  R168      -3.1816062331199646e-01
    z[1,0,5]  R169      3.5657492280006409e-01
    z[1,0,5]  R170      -0.413128525018692
    z[1,0,5]  R171      0.0798230916261673
    z[1,0,5]  R172      -5.1094375550746918e-02
    z[1,0,5]  R173      1.0263931751251221e-01
    z[1,0,5]  R174      3.4040069580078125e-01
    z[1,0,5]  R175      9.6004633232951164e-03
    z[1,0,5]  R176      2.4548135697841644e-01
    z[1,0,5]  R177      3.8709971308708191e-01
    z[1,0,5]  R178      3.2117941975593567e-01
    z[1,0,5]  R179      4.8737379908561707e-01
    z[1,0,5]  R180      3.2575258612632751e-01
    z[1,0,5]  R181      3.6358457803726196e-01
    z[1,0,5]  R182      2.8527006506919861e-01
    z[1,0,5]  R183      1.6940513253211975e-01
    z[1,0,5]  R184      5.3804576396942139e-01
    z[1,0,5]  R185      4.4933566451072693e-01
    z[1,0,5]  R186      3.4121209383010864e-01
    z[1,0,5]  R187      2.7260869741439819e-01
    z[1,0,5]  R188      -1.8417501449584961e-01
    z[1,0,5]  R189      -4.8523122072219849e-01
    z[1,0,5]  R190      -5.0318732857704163e-02
    z[1,0,5]  R191      -5.4362822324037552e-02
    z[1,0,5]  R192      -5.0268638134002686e-01
    z[1,0,5]  R193      -9.4509720802307129e-02
    z[1,0,5]  R194      6.2728708982467651e-01
    z[1,0,5]  R195      -8.9115977287292480e-02
    z[1,0,5]  R196      -1.9698626419994980e-04
    z[1,0,5]  R197      4.9155500531196594e-01
    z[1,0,5]  R198      1.5471910126507282e-02
    z[1,0,5]  R199      7.5048275291919708e-02
    z[1,0,5]  R200      -6.8633213639259338e-02
    z[1,0,5]  R201      -9.3955181539058685e-02
    z[1,0,5]  R202      2.3310044407844543e-01
    z[1,0,5]  R203      9.1374032199382782e-02
    z[1,0,5]  R204      -4.6565684676170349e-01
    z[1,0,5]  R205      -5.9288865327835083e-01
    z[1,0,5]  R206      -6.7348307371139526e-01
    z[1,0,5]  R207      -2.7893880009651184e-01
    z[1,0,5]  R208      -6.5360978245735168e-02
    z[1,0,5]  R209      -1.6454692184925079e-01
    z[1,0,5]  R210      -7.2398573160171509e-02
    z[1,0,5]  R211      0.0906539037823677
    z[1,0,5]  R212      -6.2161255627870560e-02
    z[1,0,5]  R213      -4.9832555651664734e-01
    z[1,0,5]  R214      7.1085587143898010e-02
    z[1,0,5]  R215      9.9303878843784332e-02
    z[1,0,5]  R216      1.9442611932754517e-01
    z[1,0,5]  R217      -1.3173783663660288e-03
    z[1,0,5]  R218      -1.2290755286812782e-02
    z[1,0,5]  R219      1.2302239984273911e-01
    z[1,0,5]  R220      2.0458373427391052e-01
    z[1,0,5]  R221      -0.0671120211482048
    z[1,0,5]  R222      -7.3197772726416588e-03
    z[1,0,5]  R223      1.2532912194728851e-01
    z[1,0,5]  R224      4.4835552573204041e-01
    z[1,0,5]  R225      4.6172514557838440e-01
    z[1,0,5]  R226      4.7400042414665222e-01
    z[1,0,5]  R227      2.7603101730346680e-01
    z[1,0,5]  R228      4.3709456920623779e-01
    z[1,0,5]  R229      5.8497828245162964e-01
    z[1,0,5]  R230      3.7317070364952087e-01
    z[1,0,5]  R231      1.8044155091047287e-02
    z[1,0,5]  R232      5.0306838750839233e-01
    z[1,0,5]  R233      3.6254772543907166e-01
    z[1,0,5]  R234      5.1565271615982056e-01
    z[1,0,5]  R235      6.0653075575828552e-02
    z[1,0,5]  R236      2.6133623719215393e-01
    z[1,0,5]  R237      1.4096808433532715e-01
    z[1,0,5]  R238      2.5017103180289268e-02
    z[1,0,5]  R239      2.8611651062965393e-01
    z[1,0,5]  R240      2.3158925771713257e-01
    z[1,0,5]  R241      4.9871876835823059e-01
    z[1,0,5]  R242      3.6343118548393250e-01
    z[1,0,5]  R243      4.5754191279411316e-01
    z[1,0,6]  R8        1
    z[1,0,6]  R17       -1
    z[1,0,6]  R162      -1
    z[1,0,6]  R163      1
    z[1,0,6]  R164      -8.4079019725322723e-02
    z[1,0,6]  R165      3.4917865414172411e-03
    z[1,0,6]  R166      9.3952931463718414e-02
    z[1,0,6]  R167      -2.6736435294151306e-01
    z[1,0,6]  R168      5.2625524997711182e-01
    z[1,0,6]  R169      -8.1423139199614525e-03
    z[1,0,6]  R170      2.3798566311597824e-02
    z[1,0,6]  R171      4.5384612679481506e-01
    z[1,0,6]  R172      2.9452082514762878e-01
    z[1,0,6]  R173      5.3818774223327637e-01
    z[1,0,6]  R174      2.4685344099998474e-01
    z[1,0,6]  R175      -2.9452103376388550e-01
    z[1,0,6]  R176      4.3733417987823486e-01
    z[1,0,6]  R177      -1.2433338165283203e-01
    z[1,0,6]  R178      -3.8061115145683289e-01
    z[1,0,6]  R179      0.0547383613884449
    z[1,0,6]  R180      1.0755355656147003e-01
    z[1,0,6]  R181      0.0466521717607975
    z[1,0,6]  R182      -0.074155293405056
    z[1,0,6]  R183      1.6571673750877380e-01
    z[1,0,6]  R184      1.4408499002456665e-02
    z[1,0,6]  R185      -1.2025839835405350e-01
    z[1,0,6]  R186      5.1061216741800308e-02
    z[1,0,6]  R187      -1.9564969837665558e-01
    z[1,0,6]  R188      8.6739897727966309e-02
    z[1,0,6]  R189      3.4491127729415894e-01
    z[1,0,6]  R190      -5.8239664882421494e-02
    z[1,0,6]  R191      4.4052168726921082e-02
    z[1,0,6]  R192      1.7404365539550781e-01
    z[1,0,6]  R193      2.4868105351924896e-01
    z[1,0,6]  R194      -2.5180861353874207e-02
    z[1,0,6]  R195      7.3525518178939819e-02
    z[1,0,6]  R196      2.1956019103527069e-01
    z[1,0,6]  R197      -2.2008366882801056e-01
    z[1,0,6]  R198      1.4444258809089661e-01
    z[1,0,6]  R199      -2.2445949912071228e-01
    z[1,0,6]  R200      -1.0294097661972046e-01
    z[1,0,6]  R201      1.2430543079972267e-02
    z[1,0,6]  R202      -2.4548610672354698e-02
    z[1,0,6]  R203      -1.1802790313959122e-01
    z[1,0,6]  R204      7.7819757163524628e-02
    z[1,0,6]  R205      1.6664761304855347e-01
    z[1,0,6]  R206      -2.0606763660907745e-02
    z[1,0,6]  R207      2.6358818635344505e-02
    z[1,0,6]  R208      -0.084261953830719
    z[1,0,6]  R209      4.2935600876808167e-01
    z[1,0,6]  R210      -4.5721733570098877e-01
    z[1,0,6]  R211      1.9737339019775391e-01
    z[1,0,6]  R212      3.2508898526430130e-02
    z[1,0,6]  R213      3.0719056725502014e-01
    z[1,0,6]  R214      -4.3408204801380634e-03
    z[1,0,6]  R215      1.4412012696266174e-01
    z[1,0,6]  R216      2.8908040374517441e-02
    z[1,0,6]  R217      -3.2881464809179306e-02
    z[1,0,6]  R218      0.237397700548172
    z[1,0,6]  R219      9.5143593847751617e-02
    z[1,0,6]  R220      -1.1203897744417191e-01
    z[1,0,6]  R221      0.0405583456158638
    z[1,0,6]  R222      2.0985612273216248e-01
    z[1,0,6]  R223      -4.4531369209289551e-01
    z[1,0,6]  R224      4.6910487115383148e-02
    z[1,0,6]  R225      2.4945002794265747e-01
    z[1,0,6]  R226      3.3773830533027649e-01
    z[1,0,6]  R227      -3.7616726756095886e-01
    z[1,0,6]  R228      -0.0771293193101883
    z[1,0,6]  R229      1.1005973647115752e-04
    z[1,0,6]  R230      6.0303110629320145e-02
    z[1,0,6]  R231      -2.4672379717230797e-02
    z[1,0,6]  R232      -2.8605468571186066e-02
    z[1,0,6]  R233      -4.3676221370697021e-01
    z[1,0,6]  R234      -2.8541502356529236e-01
    z[1,0,6]  R235      -2.6354700326919556e-01
    z[1,0,6]  R236      -9.7607143223285675e-02
    z[1,0,6]  R237      -1.3041138648986816e-01
    z[1,0,6]  R238      -4.3180756270885468e-02
    z[1,0,6]  R239      -3.5434693098068237e-01
    z[1,0,6]  R240      -3.6994233727455139e-02
    z[1,0,6]  R241      3.0429449677467346e-01
    z[1,0,6]  R242      1.6009826958179474e-01
    z[1,0,6]  R243      2.1410284936428070e-01
    z[0,3,0]  R2        -1
    z[0,3,0]  R29       1
    z[0,3,0]  R244      -1
    z[0,3,0]  R245      1
    z[0,3,0]  R258      -0.595670759677887
    z[0,3,0]  R259      -3.7485894560813904e-01
    z[0,3,0]  R260      -1.8457423150539398e-01
    z[0,3,0]  R261      -5.7814240455627441e-01
    z[0,3,0]  R262      -3.1091922521591187e-01
    z[0,3,0]  R263      -4.4319561123847961e-01
    z[0,3,0]  R264      -2.9543972015380859e-01
    z[0,3,0]  R265      -4.4200652837753296e-01
    z[0,3,0]  R266      6.2063220888376236e-02
    z[0,3,0]  R267      -1.3802291452884674e-01
    z[0,3,0]  R268      1.2147828191518784e-01
    z[0,3,0]  R269      -2.9867494106292725e-01
    z[0,3,0]  R270      -3.1643894314765930e-01
    z[0,3,0]  R271      3.2006077468395233e-02
    z[0,3,0]  R272      5.8187246322631836e-02
    z[0,3,0]  R273      -2.0086118951439857e-02
    z[0,3,0]  R274      2.5060039758682251e-01
    z[0,3,0]  R275      -1.2390428036451340e-01
    z[0,3,0]  R276      -1.4783337712287903e-01
    z[0,3,0]  R277      -1.3143141567707062e-01
    z[0,3,0]  R278      5.4461634159088135e-01
    z[0,3,0]  R279      3.9418607950210571e-01
    z[0,3,0]  R280      6.1878937482833862e-01
    z[0,3,0]  R281      0.476563036441803
    z[0,3,0]  R282      7.4172264337539673e-01
    z[0,3,0]  R283      6.7241811752319336e-01
    z[0,3,0]  R284      6.4190948009490967e-01
    z[0,3,0]  R285      6.5134871006011963e-01
    z[0,3,0]  R286      1.1419311165809631e-01
    z[0,3,0]  R287      5.9473598003387451e-01
    z[0,3,0]  R288      -9.8668999969959259e-02
    z[0,3,0]  R289      6.1946451663970947e-01
    z[0,3,0]  R290      0.542599081993103
    z[0,3,0]  R291      -1.0434793680906296e-01
    z[0,3,0]  R292      3.2040235400199890e-01
    z[0,3,0]  R293      7.2470021247863770e-01
    z[0,3,0]  R294      -3.1749375630170107e-03
    z[0,3,0]  R295      3.7793529033660889e-01
    z[0,3,0]  R296      -2.0786963403224945e-01
    z[0,3,0]  R297      -1.8122604489326477e-01
    z[0,3,0]  R298      -2.3660942912101746e-02
    z[0,3,0]  R299      -6.7642802000045776e-01
    z[0,3,0]  R300      -4.9517515301704407e-01
    z[0,3,0]  R301      -2.8080910444259644e-01
    z[0,3,0]  R302      -3.0979430675506592e-01
    z[0,3,0]  R303      -4.3818223476409912e-01
    z[0,3,0]  R304      -3.4521660208702087e-01
    z[0,3,0]  R305      2.8427250217646360e-03
    z[0,3,0]  R306      -6.6371224820613861e-02
    z[0,3,0]  R307      -2.6585647463798523e-01
    z[0,3,0]  R308      4.7867482900619507e-01
    z[0,3,0]  R309      -5.8776414394378662e-01
    z[0,3,0]  R310      -3.5246106982231140e-01
    z[0,3,0]  R311      -6.1804109811782837e-01
    z[0,3,0]  R312      -2.4182218313217163e-01
    z[0,3,0]  R313      -0.525830864906311
    z[0,3,0]  R314      -5.7502126693725586e-01
    z[0,3,0]  R315      -4.0891861915588379e-01
    z[0,3,0]  R316      -4.4103786349296570e-01
    z[0,3,0]  R317      -0.522939145565033
    z[0,3,0]  R318      2.4460309743881226e-01
    z[0,3,0]  R319      4.2715522646903992e-01
    z[0,3,0]  R320      3.2835906744003296e-01
    z[0,3,0]  R321      5.5589717626571655e-01
    z[0,3,0]  R322      -1.1993542313575745e-01
    z[0,3,0]  R323      5.2645742893218994e-01
    z[0,3,0]  R324      4.1524934768676758e-01
    z[0,3,0]  R325      4.1558876633644104e-01
    z[0,3,0]  R326      5.9942883253097534e-01
    z[0,3,0]  R327      2.7454838156700134e-02
    z[0,3,0]  R328      1.4633931219577789e-01
    z[0,3,0]  R329      3.0731040239334106e-01
    z[0,3,0]  R330      5.2321493625640869e-01
    z[0,3,0]  R331      2.3162433505058289e-01
    z[0,3,0]  R332      0.352159321308136
    z[0,3,0]  R333      4.1018098592758179e-01
    z[0,3,0]  R334      6.8061405420303345e-01
    z[0,3,0]  R335      0.587196409702301
    z[0,3,0]  R336      4.5920401811599731e-01
    z[0,3,0]  R337      4.8823356628417969e-01
    z[0,3,0]  R338      2.1337687969207764e-01
    z[0,3,0]  R339      0.702157199382782
    z[0,3,0]  R340      4.9267145991325378e-01
    z[0,3,0]  R341      1.6420282423496246e-01
    z[0,3,0]  R342      3.8145303726196289e-01
    z[0,3,0]  R343      6.1188286542892456e-01
    z[0,3,0]  R344      4.6825012564659119e-01
    z[0,3,0]  R345      4.9199223518371582e-01
    z[0,3,0]  R346      1.8281713128089905e-02
    z[0,3,0]  R347      0.5074462890625
    z[0,3,0]  R348      2.9385295510292053e-01
    z[0,3,0]  R349      4.3124410510063171e-01
    z[0,3,0]  R350      -5.7759042829275131e-02
    z[0,3,0]  R351      5.1795196533203125e-01
    z[0,3,0]  R352      6.3703131675720215e-01
    z[0,3,0]  R353      0.357229620218277
    z[0,3,0]  R354      -5.2753275632858276e-01
    z[0,3,0]  R355      2.2294804453849792e-01
    z[0,3,0]  R356      0.316459059715271
    z[0,3,0]  R357      2.4885358288884163e-02
    z[0,3,0]  R358      3.5174342989921570e-01
    z[0,3,0]  R359      3.0526661872863770e-01
    z[0,3,0]  R360      -2.0106610655784607e-01
    z[0,3,0]  R361      2.3342198133468628e-01
    z[0,3,0]  R362      3.5342502593994141e-01
    z[0,3,0]  R363      1.2162110209465027e-01
    z[0,3,0]  R364      9.8546624183654785e-02
    z[0,3,0]  R365      5.0777590274810791e-01
    z[0,3,0]  R366      -2.1205723285675049e-01
    z[0,3,0]  R367      -2.2117216885089874e-01
    z[0,3,0]  R368      6.5122477710247040e-02
    z[0,3,0]  R369      3.5603755712509155e-01
    z[0,3,0]  R370      0.0617666058242321
    z[0,3,0]  R371      5.4670524597167969e-01
    z[0,3,0]  R372      2.3764832317829132e-01
    z[0,3,0]  R373      4.9069947004318237e-01
    z[0,3,0]  R374      2.6874250173568726e-01
    z[0,3,0]  R375      3.3461397886276245e-01
    z[0,3,0]  R376      5.8027577400207520e-01
    z[0,3,0]  R377      9.4387523829936981e-02
    z[0,3,0]  R378      -5.5177497863769531e-01
    z[0,3,0]  R379      -4.0907946228981018e-01
    z[0,3,0]  R380      3.0622461438179016e-01
    z[0,3,0]  R381      2.8966364264488220e-01
    z[0,3,0]  R382      1.6090807318687439e-01
    z[0,3,0]  R383      4.8265120387077332e-01
    z[0,3,0]  R384      3.9025691151618958e-01
    z[0,3,0]  R385      2.1352705359458923e-01
    z[0,3,0]  R386      -0.0727607011795044
    z[0,3,0]  R387      -3.2407945394515991e-01
    z[0,3,1]  R3        -1
    z[0,3,1]  R30       1
    z[0,3,1]  R246      -1
    z[0,3,1]  R247      1
    z[0,3,1]  R258      -4.4385874271392822e-01
    z[0,3,1]  R259      -4.2086270451545715e-01
    z[0,3,1]  R260      -0.529179573059082
    z[0,3,1]  R261      -4.1710504889488220e-01
    z[0,3,1]  R262      -8.6575299501419067e-01
    z[0,3,1]  R263      -0.421099990606308
    z[0,3,1]  R264      -3.9300060272216797e-01
    z[0,3,1]  R265      -3.5395517945289612e-01
    z[0,3,1]  R266      -4.0363934636116028e-01
    z[0,3,1]  R267      -7.0809775590896606e-01
    z[0,3,1]  R268      0.897419273853302
    z[0,3,1]  R269      0.900534987449646
    z[0,3,1]  R270      0.902877151966095
    z[0,3,1]  R271      9.1613984107971191e-01
    z[0,3,1]  R272      8.9577335119247437e-01
    z[0,3,1]  R273      9.3991589546203613e-01
    z[0,3,1]  R274      8.9128780364990234e-01
    z[0,3,1]  R275      8.3712917566299438e-01
    z[0,3,1]  R276      8.4881031513214111e-01
    z[0,3,1]  R277      0.816559374332428
    z[0,3,1]  R278      5.4552732035517693e-03
    z[0,3,1]  R279      2.3812660947442055e-02
    z[0,3,1]  R280      0.0827384814620018
    z[0,3,1]  R281      3.1028954312205315e-02
    z[0,3,1]  R282      5.4847251623868942e-02
    z[0,3,1]  R283      9.2687368392944336e-02
    z[0,3,1]  R284      -6.5321475267410278e-02
    z[0,3,1]  R285      1.5127401053905487e-01
    z[0,3,1]  R286      1.9041022285819054e-02
    z[0,3,1]  R287      1.1130225658416748e-01
    z[0,3,1]  R288      -5.5492192506790161e-01
    z[0,3,1]  R289      -6.6467088460922241e-01
    z[0,3,1]  R290      -5.6200414896011353e-01
    z[0,3,1]  R291      -1.8602198362350464e-01
    z[0,3,1]  R292      -2.4653628468513489e-01
    z[0,3,1]  R293      3.1718581914901733e-01
    z[0,3,1]  R294      2.8134384751319885e-01
    z[0,3,1]  R295      -4.3276441097259521e-01
    z[0,3,1]  R296      -9.6648633480072021e-02
    z[0,3,1]  R297      6.7415893077850342e-02
    z[0,3,1]  R298      0.842336893081665
    z[0,3,1]  R299      6.8349009752273560e-01
    z[0,3,1]  R300      6.7841392755508423e-01
    z[0,3,1]  R301      6.7690467834472656e-01
    z[0,3,1]  R302      6.4372408390045166e-01
    z[0,3,1]  R303      5.6303697824478149e-01
    z[0,3,1]  R304      5.4218709468841553e-01
    z[0,3,1]  R305      5.9074205160140991e-01
    z[0,3,1]  R306      5.7622200250625610e-01
    z[0,3,1]  R307      5.2282029390335083e-01
    z[0,3,1]  R308      2.6429495215415955e-01
    z[0,3,1]  R309      -6.3401788473129272e-01
    z[0,3,1]  R310      -8.5421293973922729e-01
    z[0,3,1]  R311      -0.698803186416626
    z[0,3,1]  R312      -8.3294248580932617e-01
    z[0,3,1]  R313      -6.6108095645904541e-01
    z[0,3,1]  R314      -5.9603250026702881e-01
    z[0,3,1]  R315      -5.2921229600906372e-01
    z[0,3,1]  R316      -5.1782667636871338e-01
    z[0,3,1]  R317      -5.2858549356460571e-01
    z[0,3,1]  R318      4.1859099268913269e-01
    z[0,3,1]  R319      4.9714335799217224e-01
    z[0,3,1]  R320      -0.0708140879869461
    z[0,3,1]  R321      -4.7793912887573242e-01
    z[0,3,1]  R322      -3.9171531796455383e-01
    z[0,3,1]  R323      -3.1207174062728882e-01
    z[0,3,1]  R324      -2.1651053428649902e-01
    z[0,3,1]  R325      -3.1970804929733276e-01
    z[0,3,1]  R326      -2.5623393058776855e-01
    z[0,3,1]  R327      2.4614408612251282e-01
    z[0,3,1]  R328      -7.6266628503799438e-01
    z[0,3,1]  R329      -3.6327430605888367e-01
    z[0,3,1]  R330      2.2373306751251221e-01
    z[0,3,1]  R331      -4.9296915531158447e-01
    z[0,3,1]  R332      5.6185829639434814e-01
    z[0,3,1]  R333      7.7729612588882446e-01
    z[0,3,1]  R334      5.1344454288482666e-01
    z[0,3,1]  R335      -1.8832521140575409e-01
    z[0,3,1]  R336      2.5979763269424438e-01
    z[0,3,1]  R337      -3.6433655023574829e-01
    z[0,3,1]  R338      2.9991710186004639e-01
    z[0,3,1]  R339      -1.8482691049575806e-01
    z[0,3,1]  R340      5.1216334104537964e-01
    z[0,3,1]  R341      5.9576076269149780e-01
    z[0,3,1]  R342      0.552386999130249
    z[0,3,1]  R343      4.9788832664489746e-01
    z[0,3,1]  R344      6.2892836332321167e-01
    z[0,3,1]  R345      7.0189118385314941e-01
    z[0,3,1]  R346      -2.1042430400848389e-01
    z[0,3,1]  R347      7.1531242132186890e-01
    z[0,3,1]  R348      7.3811477422714233e-01
    z[0,3,1]  R349      4.6012678742408752e-01
    z[0,3,1]  R350      -2.3309087753295898e-01
    z[0,3,1]  R351      6.7887884378433228e-01
    z[0,3,1]  R352      6.1221557855606079e-01
    z[0,3,1]  R353      7.4682730436325073e-01
    z[0,3,1]  R354      -2.3578248918056488e-01
    z[0,3,1]  R355      -3.9649134874343872e-01
    z[0,3,1]  R356      -1.2682583928108215e-01
    z[0,3,1]  R357      1.2493968755006790e-01
    z[0,3,1]  R358      2.9076436161994934e-01
    z[0,3,1]  R359      7.1940815448760986e-01
    z[0,3,1]  R360      -5.1374858617782593e-01
    z[0,3,1]  R361      -3.2952564954757690e-01
    z[0,3,1]  R362      1.0562562942504883e-01
    z[0,3,1]  R363      -5.8447830379009247e-03
    z[0,3,1]  R364      -6.7971736192703247e-01
    z[0,3,1]  R365      0.0712711289525032
    z[0,3,1]  R366      -2.0662029087543488e-01
    z[0,3,1]  R367      1.6451099514961243e-01
    z[0,3,1]  R368      4.7735238075256348e-01
    z[0,3,1]  R369      -4.0121245384216309e-01
    z[0,3,1]  R370      -7.5811302661895752e-01
    z[0,3,1]  R371      -6.5737382101360708e-05
    z[0,3,1]  R372      -8.6188906431198120e-01
    z[0,3,1]  R373      -1.1684004217386246e-01
    z[0,3,1]  R374      3.5133507847785950e-01
    z[0,3,1]  R375      -8.4839671850204468e-02
    z[0,3,1]  R376      9.1011054813861847e-02
    z[0,3,1]  R377      -1.2946946918964386e-01
    z[0,3,1]  R378      -4.4211155176162720e-01
    z[0,3,1]  R379      -4.5028707385063171e-01
    z[0,3,1]  R380      -8.7053716182708740e-02
    z[0,3,1]  R381      2.7605205774307251e-01
    z[0,3,1]  R382      1.8752078711986542e-01
    z[0,3,1]  R383      8.2377985119819641e-02
    z[0,3,1]  R384      8.8901974260807037e-02
    z[0,3,1]  R385      1.4832818508148193e-01
    z[0,3,1]  R386      -7.2970294952392578e-01
    z[0,3,1]  R387      -7.9550343751907349e-01
    z[0,3,2]  R4        -1
    z[0,3,2]  R31       1
    z[0,3,2]  R248      -1
    z[0,3,2]  R249      1
    z[0,3,2]  R258      -2.8671988844871521e-01
    z[0,3,2]  R259      -5.0583446025848389e-01
    z[0,3,2]  R260      -3.8096874952316284e-01
    z[0,3,2]  R261      -5.9246593713760376e-01
    z[0,3,2]  R262      -1.7986467480659485e-01
    z[0,3,2]  R263      -6.2425899505615234e-01
    z[0,3,2]  R264      -6.4657533168792725e-01
    z[0,3,2]  R265      -7.8528332710266113e-01
    z[0,3,2]  R266      -8.7665939331054688e-01
    z[0,3,2]  R267      -2.3562364280223846e-02
    z[0,3,2]  R268      -4.1183501482009888e-01
    z[0,3,2]  R269      -2.5626808404922485e-01
    z[0,3,2]  R270      2.5473069399595261e-02
    z[0,3,2]  R271      1.6784700751304626e-01
    z[0,3,2]  R272      -1.3380204141139984e-01
    z[0,3,2]  R273      1.6160102188587189e-01
    z[0,3,2]  R274      5.1723778247833252e-02
    z[0,3,2]  R275      -2.8242358565330505e-01
    z[0,3,2]  R276      4.5180737972259521e-01
    z[0,3,2]  R277      -1.1835354566574097e-01
    z[0,3,2]  R278      5.9386283159255981e-01
    z[0,3,2]  R279      6.9971585273742676e-01
    z[0,3,2]  R280      3.7243339419364929e-01
    z[0,3,2]  R281      6.2867981195449829e-01
    z[0,3,2]  R282      3.7749308347702026e-01
    z[0,3,2]  R283      2.9669496417045593e-01
    z[0,3,2]  R284      5.3719258308410645e-01
    z[0,3,2]  R285      6.7282044887542725e-01
    z[0,3,2]  R286      5.3101140260696411e-01
    z[0,3,2]  R287      2.5265955924987793e-01
    z[0,3,2]  R288      2.2434255480766296e-01
    z[0,3,2]  R289      -2.5789499282836914e-01
    z[0,3,2]  R290      4.0086638927459717e-01
    z[0,3,2]  R291      8.4713113307952881e-01
    z[0,3,2]  R292      2.7665188908576965e-01
    z[0,3,2]  R293      0.373761922121048
    z[0,3,2]  R294      9.2212641239166260e-01
    z[0,3,2]  R295      2.0049897953867912e-02
    z[0,3,2]  R296      1.0363273322582245e-01
    z[0,3,2]  R297      -5.5132254958152771e-02
    z[0,3,2]  R298      1.4451944828033447e-01
    z[0,3,2]  R299      -6.6902157850563526e-03
    z[0,3,2]  R300      -2.3741452395915985e-01
    z[0,3,2]  R301      -3.3453068137168884e-01
    z[0,3,2]  R302      -1.7780803143978119e-01
    z[0,3,2]  R303      3.5348970443010330e-02
    z[0,3,2]  R304      4.5870873332023621e-01
    z[0,3,2]  R305      1.5734094381332397e-01
    z[0,3,2]  R306      -0.425411194562912
    z[0,3,2]  R307      3.5178694128990173e-01
    z[0,3,2]  R308      6.6110062599182129e-01
    z[0,3,2]  R309      -2.9593446850776672e-01
    z[0,3,2]  R310      -7.1088381111621857e-02
    z[0,3,2]  R311      -0.0973065197467804
    z[0,3,2]  R312      -2.5544852018356323e-01
    z[0,3,2]  R313      -2.9635587334632874e-01
    z[0,3,2]  R314      -2.8497090935707092e-01
    z[0,3,2]  R315      -6.3906210660934448e-01
    z[0,3,2]  R316      -0.667457103729248
    z[0,3,2]  R317      -5.7527345418930054e-01
    z[0,3,2]  R318      5.1331037282943726e-01
    z[0,3,2]  R319      1.8045547604560852e-01
    z[0,3,2]  R320      3.1240659952163696e-01
    z[0,3,2]  R321      1.0660746693611145e-01
    z[0,3,2]  R322      4.5155549049377441e-01
    z[0,3,2]  R323      2.7448868751525879e-01
    z[0,3,2]  R324      -5.2570984698832035e-03
    z[0,3,2]  R325      5.1050531864166260e-01
    z[0,3,2]  R326      3.7498977035284042e-02
    z[0,3,2]  R327      4.7652056813240051e-01
    z[0,3,2]  R328      2.1068260073661804e-01
    z[0,3,2]  R329      3.4870314598083496e-01
    z[0,3,2]  R330      6.9835472106933594e-01
    z[0,3,2]  R331      7.1132189035415649e-01
    z[0,3,2]  R332      1.3834661245346069e-01
    z[0,3,2]  R333      2.4175962433218956e-02
    z[0,3,2]  R334      1.1042704433202744e-01
    z[0,3,2]  R335      1.0658313333988190e-01
    z[0,3,2]  R336      1.4647732675075531e-01
    z[0,3,2]  R337      4.9737501144409180e-01
    z[0,3,2]  R338      6.2148753553628922e-02
    z[0,3,2]  R339      2.6213395595550537e-01
    z[0,3,2]  R340      -9.8603196442127228e-02
    z[0,3,2]  R341      -1.4586040377616882e-01
    z[0,3,2]  R342      -1.4332130551338196e-01
    z[0,3,2]  R343      1.5385118126869202e-01
    z[0,3,2]  R344      2.2596241533756256e-01
    z[0,3,2]  R345      7.3518723249435425e-02
    z[0,3,2]  R346      2.5252890586853027e-01
    z[0,3,2]  R347      1.7043286561965942e-01
    z[0,3,2]  R348      2.5744667649269104e-01
    z[0,3,2]  R349      6.8309265375137329e-01
    z[0,3,2]  R350      5.0319695472717285e-01
    z[0,3,2]  R351      3.5586360096931458e-01
    z[0,3,2]  R352      3.0896160006523132e-01
    z[0,3,2]  R353      -0.069015271961689
    z[0,3,2]  R354      -2.5801885128021240e-01
    z[0,3,2]  R355      4.8450362682342529e-01
    z[0,3,2]  R356      6.9639271497726440e-01
    z[0,3,2]  R357      2.9191273450851440e-01
    z[0,3,2]  R358      -4.8016417026519775e-01
    z[0,3,2]  R359      -1.0359817743301392e-01
    z[0,3,2]  R360      -4.5071166753768921e-01
    z[0,3,2]  R361      8.4194815158843994e-01
    z[0,3,2]  R362      -9.0492151677608490e-02
    z[0,3,2]  R363      6.8993037939071655e-01
    z[0,3,2]  R364      2.0763725042343140e-01
    z[0,3,2]  R365      3.7901934981346130e-01
    z[0,3,2]  R366      -4.2340385913848877e-01
    z[0,3,2]  R367      -5.7228218764066696e-02
    z[0,3,2]  R368      1.8733383715152740e-01
    z[0,3,2]  R369      6.4164972305297852e-01
    z[0,3,2]  R370      2.5032129883766174e-01
    z[0,3,2]  R371      3.3896341919898987e-01
    z[0,3,2]  R372      0.0697273463010788
    z[0,3,2]  R373      -1.9183041527867317e-02
    z[0,3,2]  R374      1.4869990944862366e-01
    z[0,3,2]  R375      6.1271142959594727e-01
    z[0,3,2]  R376      -4.8083987087011337e-02
    z[0,3,2]  R377      8.8728785514831543e-01
    z[0,3,2]  R378      -3.7146055698394775e-01
    z[0,3,2]  R379      -3.4338730573654175e-01
    z[0,3,2]  R380      7.0441210269927979e-01
    z[0,3,2]  R381      3.3388638496398926e-01
    z[0,3,2]  R382      6.1313128471374512e-01
    z[0,3,2]  R383      2.8575578331947327e-01
    z[0,3,2]  R384      2.8835749626159668e-01
    z[0,3,2]  R385      2.1216154098510742e-01
    z[0,3,2]  R386      5.5589151382446289e-01
    z[0,3,2]  R387      9.2491582036018372e-02
    z[0,3,3]  R5        -1
    z[0,3,3]  R32       1
    z[0,3,3]  R250      -1
    z[0,3,3]  R251      1
    z[0,3,3]  R258      4.4222053140401840e-02
    z[0,3,3]  R259      -1.3470019400119781e-01
    z[0,3,3]  R260      -2.8704026341438293e-01
    z[0,3,3]  R261      -2.4648956954479218e-01
    z[0,3,3]  R262      -1.8796291947364807e-01
    z[0,3,3]  R263      1.4601151645183563e-01
    z[0,3,3]  R264      -9.7074195742607117e-02
    z[0,3,3]  R265      1.0145763307809830e-01
    z[0,3,3]  R266      -1.6864429414272308e-01
    z[0,3,3]  R267      0.300178587436676
    z[0,3,3]  R268      -7.0722915232181549e-02
    z[0,3,3]  R269      1.2170047499239445e-02
    z[0,3,3]  R270      -1.6872355341911316e-01
    z[0,3,3]  R271      -3.0889034271240234e-01
    z[0,3,3]  R272      3.1220692396163940e-01
    z[0,3,3]  R273      7.3165573179721832e-02
    z[0,3,3]  R274      2.8877484798431396e-01
    z[0,3,3]  R275      1.8450444936752319e-01
    z[0,3,3]  R276      8.5690997540950775e-02
    z[0,3,3]  R277      1.0713714361190796e-01
    z[0,3,3]  R278      -3.2739424705505371e-01
    z[0,3,3]  R279      -2.7972236275672913e-01
    z[0,3,3]  R280      -3.1490191817283630e-01
    z[0,3,3]  R281      -3.8572177290916443e-01
    z[0,3,3]  R282      -2.3742128908634186e-01
    z[0,3,3]  R283      -2.8748938441276550e-01
    z[0,3,3]  R284      -2.8587976098060608e-01
    z[0,3,3]  R285      -2.6113662123680115e-01
    z[0,3,3]  R286      -5.4309302568435669e-01
    z[0,3,3]  R287      -4.2717960476875305e-01
    z[0,3,3]  R288      4.9050047993659973e-01
    z[0,3,3]  R289      1.6774599254131317e-01
    z[0,3,3]  R290      3.5282951593399048e-01
    z[0,3,3]  R291      -4.4394549727439880e-01
    z[0,3,3]  R292      -8.7034332752227783e-01
    z[0,3,3]  R293      1.5707907080650330e-01
    z[0,3,3]  R294      7.1136265993118286e-02
    z[0,3,3]  R295      3.0250164866447449e-01
    z[0,3,3]  R296      -7.5055903196334839e-01
    z[0,3,3]  R297      -6.7583733797073364e-01
    z[0,3,3]  R298      1.5452498197555542e-01
    z[0,3,3]  R299      -1.3995146751403809e-01
    z[0,3,3]  R300      -1.5703247487545013e-01
    z[0,3,3]  R301      1.2292017787694931e-01
    z[0,3,3]  R302      3.3047699928283691e-01
    z[0,3,3]  R303      4.2566198110580444e-01
    z[0,3,3]  R304      -2.5924065709114075e-01
    z[0,3,3]  R305      -5.1565170288085938e-02
    z[0,3,3]  R306      9.4079270958900452e-02
    z[0,3,3]  R307      4.1670314967632294e-02
    z[0,3,3]  R308      -3.4154820442199707e-01
    z[0,3,3]  R309      3.8465496897697449e-01
    z[0,3,3]  R310      1.9840165972709656e-01
    z[0,3,3]  R311      1.9946859776973724e-01
    z[0,3,3]  R312      1.9778101146221161e-01
    z[0,3,3]  R313      3.0093595385551453e-01
    z[0,3,3]  R314      6.8186283111572266e-02
    z[0,3,3]  R315      1.7986796796321869e-01
    z[0,3,3]  R316      2.6327994465827942e-01
    z[0,3,3]  R317      1.6986837983131409e-01
    z[0,3,3]  R318      -1.1933231353759766e-01
    z[0,3,3]  R319      -4.5953401923179626e-01
    z[0,3,3]  R320      -4.9614539742469788e-01
    z[0,3,3]  R321      -5.9462565183639526e-01
    z[0,3,3]  R322      -7.8989648818969727e-01
    z[0,3,3]  R323      7.1969664096832275e-01
    z[0,3,3]  R324      7.7174967527389526e-01
    z[0,3,3]  R325      6.5546214580535889e-01
    z[0,3,3]  R326      7.4106442928314209e-01
    z[0,3,3]  R327      2.0021730661392212e-01
    z[0,3,3]  R328      5.5433970689773560e-01
    z[0,3,3]  R329      -0.52590012550354
    z[0,3,3]  R330      -2.0495519042015076e-01
    z[0,3,3]  R331      -4.1875174641609192e-01
    z[0,3,3]  R332      -1.0279170423746109e-01
    z[0,3,3]  R333      -2.3706091940402985e-01
    z[0,3,3]  R334      -3.3714500069618225e-01
    z[0,3,3]  R335      -5.2882552146911621e-01
    z[0,3,3]  R336      -6.9368675351142883e-02
    z[0,3,3]  R337      -4.7914066910743713e-01
    z[0,3,3]  R338      -9.9878363311290741e-02
    z[0,3,3]  R339      -5.1860916614532471e-01
    z[0,3,3]  R340      -3.5057091712951660e-01
    z[0,3,3]  R341      -2.8914105892181396e-01
    z[0,3,3]  R342      -5.3530967235565186e-01
    z[0,3,3]  R343      -4.6962723135948181e-01
    z[0,3,3]  R344      -1.1298985779285431e-01
    z[0,3,3]  R345      -4.1704189777374268e-01
    z[0,3,3]  R346      -6.3620281219482422e-01
    z[0,3,3]  R347      -1.1998195201158524e-01
    z[0,3,3]  R348      -4.4902548193931580e-01
    z[0,3,3]  R349      -3.3522203564643860e-01
    z[0,3,3]  R350      -7.0099848508834839e-01
    z[0,3,3]  R351      -1.5192590653896332e-01
    z[0,3,3]  R352      -1.7222185432910919e-01
    z[0,3,3]  R353      -1.0414893925189972e-01
    z[0,3,3]  R354      3.5653609037399292e-01
    z[0,3,3]  R355      -3.4274348616600037e-01
    z[0,3,3]  R356      -2.7085381746292114e-01
    z[0,3,3]  R357      -4.7200977802276611e-01
    z[0,3,3]  R358      2.4483743309974670e-01
    z[0,3,3]  R359      -1.5734506770968437e-02
    z[0,3,3]  R360      4.1942241787910461e-01
    z[0,3,3]  R361      -2.6084804534912109e-01
    z[0,3,3]  R362      -4.4614812731742859e-01
    z[0,3,3]  R363      -1.6034652292728424e-01
    z[0,3,3]  R364      5.3146493434906006e-01
    z[0,3,3]  R365      -1.1219819635152817e-01
    z[0,3,3]  R366      3.1958571076393127e-01
    z[0,3,3]  R367      -7.0361125469207764e-01
    z[0,3,3]  R368      -1.9121690420433879e-03
    z[0,3,3]  R369      -4.7457507252693176e-01
    z[0,3,3]  R370      5.5143153667449951e-01
    z[0,3,3]  R371      -4.7516596317291260e-01
    z[0,3,3]  R372      1.0443050414323807e-01
    z[0,3,3]  R373      -6.0496044158935547e-01
    z[0,3,3]  R374      -6.7006343603134155e-01
    z[0,3,3]  R375      -0.553982675075531
    z[0,3,3]  R376      -2.4072326719760895e-01
    z[0,3,3]  R377      -3.7531527876853943e-01
    z[0,3,3]  R378      2.7557075023651123e-01
    z[0,3,3]  R379      4.3271756172180176e-01
    z[0,3,3]  R380      -4.4720742106437683e-01
    z[0,3,3]  R381      -4.1746154427528381e-01
    z[0,3,3]  R382      -2.7875733375549316e-01
    z[0,3,3]  R383      -1.6073594987392426e-01
    z[0,3,3]  R384      -6.6731703281402588e-01
    z[0,3,3]  R385      -1.9253656268119812e-01
    z[0,3,3]  R386      2.6407274603843689e-01
    z[0,3,3]  R387      -0.37900310754776
    z[0,3,4]  R6        -1
    z[0,3,4]  R33       1
    z[0,3,4]  R252      -1
    z[0,3,4]  R253      1
    z[0,3,4]  R258      -3.7564572691917419e-01
    z[0,3,4]  R259      -1.7045332491397858e-01
    z[0,3,4]  R260      -6.6091604530811310e-02
    z[0,3,4]  R261      -3.8730047643184662e-02
    z[0,3,4]  R262      2.7339997887611389e-01
    z[0,3,4]  R263      -0.0617363266646862
    z[0,3,4]  R264      -3.4131160378456116e-01
    z[0,3,4]  R265      -7.2167210280895233e-02
    z[0,3,4]  R266      1.7700275778770447e-01
    z[0,3,4]  R267      -2.1491970121860504e-01
    z[0,3,4]  R268      1.4138107188045979e-02
    z[0,3,4]  R269      5.8108780533075333e-02
    z[0,3,4]  R270      1.3009758293628693e-01
    z[0,3,4]  R271      1.8706850707530975e-01
    z[0,3,4]  R272      1.4939698576927185e-01
    z[0,3,4]  R273      -2.4596697092056274e-01
    z[0,3,4]  R274      4.8291280865669250e-02
    z[0,3,4]  R275      -4.0485617518424988e-01
    z[0,3,4]  R276      -4.5830491930246353e-02
    z[0,3,4]  R277      2.7651217579841614e-01
    z[0,3,4]  R278      2.0069877803325653e-01
    z[0,3,4]  R279      -2.8072007000446320e-02
    z[0,3,4]  R280      1.8341344594955444e-01
    z[0,3,4]  R281      -1.0104627162218094e-01
    z[0,3,4]  R282      -2.2576268017292023e-01
    z[0,3,4]  R283      -1.6243544220924377e-01
    z[0,3,4]  R284      -2.6549813151359558e-01
    z[0,3,4]  R285      -1.7620180547237396e-01
    z[0,3,4]  R286      3.9468744397163391e-01
    z[0,3,4]  R287      -2.5569441914558411e-01
    z[0,3,4]  R288      -2.0987190306186676e-01
    z[0,3,4]  R289      8.1804707646369934e-02
    z[0,3,4]  R290      1.6349682211875916e-01
    z[0,3,4]  R291      -5.3939230740070343e-02
    z[0,3,4]  R292      6.1589833348989487e-03
    z[0,3,4]  R293      -4.9056809395551682e-02
    z[0,3,4]  R294      1.0225493460893631e-01
    z[0,3,4]  R295      4.8647204041481018e-01
    z[0,3,4]  R296      -4.6438881754875183e-01
    z[0,3,4]  R297      -4.9762633442878723e-01
    z[0,3,4]  R298      3.2380679249763489e-01
    z[0,3,4]  R299      9.2603355646133423e-02
    z[0,3,4]  R300      1.0480130463838577e-01
    z[0,3,4]  R301      0.422298789024353
    z[0,3,4]  R302      3.1663909554481506e-01
    z[0,3,4]  R303      1.7822766304016113e-01
    z[0,3,4]  R304      2.3400390148162842e-01
    z[0,3,4]  R305      1.9942112267017365e-01
    z[0,3,4]  R306      -1.5445487201213837e-01
    z[0,3,4]  R307      6.5681242942810059e-01
    z[0,3,4]  R308      -6.2510512769222260e-02
    z[0,3,4]  R309      -3.9069067686796188e-02
    z[0,3,4]  R310      7.4388369917869568e-02
    z[0,3,4]  R311      9.9086299538612366e-02
    z[0,3,4]  R312      -2.6848608255386353e-01
    z[0,3,4]  R313      -2.0704948902130127e-01
    z[0,3,4]  R314      -6.2490370124578476e-02
    z[0,3,4]  R315      0.140402153134346
    z[0,3,4]  R316      5.8145960792899132e-03
    z[0,3,4]  R317      -1.9544173777103424e-01
    z[0,3,4]  R318      -3.7760642170906067e-01
    z[0,3,4]  R319      -4.9730348587036133e-01
    z[0,3,4]  R320      5.8268254995346069e-01
    z[0,3,4]  R321      -4.0152069181203842e-02
    z[0,3,4]  R322      -3.4616544842720032e-02
    z[0,3,4]  R323      -1.6403122246265411e-01
    z[0,3,4]  R324      -3.1539592146873474e-01
    z[0,3,4]  R325      8.5781447589397430e-02
    z[0,3,4]  R326      6.1869039200246334e-04
    z[0,3,4]  R327      4.2012521624565125e-01
    z[0,3,4]  R328      7.2348825633525848e-02
    z[0,3,4]  R329      -3.6747512221336365e-01
    z[0,3,4]  R330      -3.5000881552696228e-01
    z[0,3,4]  R331      -1.2563988566398621e-01
    z[0,3,4]  R332      -5.7842051982879639e-01
    z[0,3,4]  R333      1.1661750078201294e-01
    z[0,3,4]  R334      2.6517572999000549e-01
    z[0,3,4]  R335      3.7823032587766647e-02
    z[0,3,4]  R336      4.4682011008262634e-01
    z[0,3,4]  R337      1.3806016743183136e-01
    z[0,3,4]  R338      -7.6068562269210815e-01
    z[0,3,4]  R339      2.7139365673065186e-01
    z[0,3,4]  R340      -5.1270890235900879e-01
    z[0,3,4]  R341      -7.0833325386047363e-01
    z[0,3,4]  R342      -1.5885916352272034e-01
    z[0,3,4]  R343      0.0097271129488945
    z[0,3,4]  R344      2.0710526406764984e-01
    z[0,3,4]  R345      0.0722404271364212
    z[0,3,4]  R346      2.7952590584754944e-01
    z[0,3,4]  R347      3.5081812739372253e-01
    z[0,3,4]  R348      1.0469100624322891e-01
    z[0,3,4]  R349      9.6361495554447174e-02
    z[0,3,4]  R350      2.0615534484386444e-01
    z[0,3,4]  R351      1.3375785201787949e-02
    z[0,3,4]  R352      2.4304132163524628e-01
    z[0,3,4]  R353      -2.3866172134876251e-01
    z[0,3,4]  R354      6.7363011837005615e-01
    z[0,3,4]  R355      -6.3374914228916168e-02
    z[0,3,4]  R356      -2.2365452349185944e-01
    z[0,3,4]  R357      1.0546257346868515e-01
    z[0,3,4]  R358      -5.7577687501907349e-01
    z[0,3,4]  R359      -3.2119274139404297e-01
    z[0,3,4]  R360      2.7220621705055237e-01
    z[0,3,4]  R361      1.6834603250026703e-01
    z[0,3,4]  R362      3.4747067093849182e-01
    z[0,3,4]  R363      1.0901419818401337e-01
    z[0,3,4]  R364      7.6294101774692535e-02
    z[0,3,4]  R365      2.7761319279670715e-01
    z[0,3,4]  R366      0.539633572101593
    z[0,3,4]  R367      -0.404040664434433
    z[0,3,4]  R368      -7.8968626260757446e-01
    z[0,3,4]  R369      -1.5451841056346893e-01
    z[0,3,4]  R370      -1.2596817314624786e-01
    z[0,3,4]  R371      3.7993314862251282e-01
    z[0,3,4]  R372      -1.3228172063827515e-01
    z[0,3,4]  R373      8.5183707997202873e-03
    z[0,3,4]  R374      0.3465596139431
    z[0,3,4]  R375      1.1181795597076416e-01
    z[0,3,4]  R376      3.1304755806922913e-01
    z[0,3,4]  R377      1.1650119721889496e-01
    z[0,3,4]  R378      2.4950966238975525e-01
    z[0,3,4]  R379      5.1488459110260010e-01
    z[0,3,4]  R380      2.8550243377685547e-01
    z[0,3,4]  R381      3.0487564206123352e-01
    z[0,3,4]  R382      6.2902212142944336e-01
    z[0,3,4]  R383      -1.4626890420913696e-01
    z[0,3,4]  R384      0.437857985496521
    z[0,3,4]  R385      -1.9519197940826416e-01
    z[0,3,4]  R386      2.3031803965568542e-01
    z[0,3,4]  R387      2.6669876649975777e-02
    z[0,3,5]  R7        -1
    z[0,3,5]  R34       1
    z[0,3,5]  R254      -1
    z[0,3,5]  R255      1
    z[0,3,5]  R258      -4.6565684676170349e-01
    z[0,3,5]  R259      -5.9288865327835083e-01
    z[0,3,5]  R260      -6.7348307371139526e-01
    z[0,3,5]  R261      -2.7893880009651184e-01
    z[0,3,5]  R262      -6.5360978245735168e-02
    z[0,3,5]  R263      -1.6454692184925079e-01
    z[0,3,5]  R264      -7.2398573160171509e-02
    z[0,3,5]  R265      0.0906539037823677
    z[0,3,5]  R266      -6.2161255627870560e-02
    z[0,3,5]  R267      -4.9832555651664734e-01
    z[0,3,5]  R268      7.1085587143898010e-02
    z[0,3,5]  R269      9.9303878843784332e-02
    z[0,3,5]  R270      1.9442611932754517e-01
    z[0,3,5]  R271      -1.3173783663660288e-03
    z[0,3,5]  R272      -1.2290755286812782e-02
    z[0,3,5]  R273      1.2302239984273911e-01
    z[0,3,5]  R274      2.0458373427391052e-01
    z[0,3,5]  R275      -0.0671120211482048
    z[0,3,5]  R276      -7.3197772726416588e-03
    z[0,3,5]  R277      1.2532912194728851e-01
    z[0,3,5]  R278      4.4835552573204041e-01
    z[0,3,5]  R279      4.6172514557838440e-01
    z[0,3,5]  R280      4.7400042414665222e-01
    z[0,3,5]  R281      2.7603101730346680e-01
    z[0,3,5]  R282      4.3709456920623779e-01
    z[0,3,5]  R283      5.8497828245162964e-01
    z[0,3,5]  R284      3.7317070364952087e-01
    z[0,3,5]  R285      1.8044155091047287e-02
    z[0,3,5]  R286      5.0306838750839233e-01
    z[0,3,5]  R287      3.6254772543907166e-01
    z[0,3,5]  R288      5.1565271615982056e-01
    z[0,3,5]  R289      6.0653075575828552e-02
    z[0,3,5]  R290      2.6133623719215393e-01
    z[0,3,5]  R291      1.4096808433532715e-01
    z[0,3,5]  R292      2.5017103180289268e-02
    z[0,3,5]  R293      2.8611651062965393e-01
    z[0,3,5]  R294      2.3158925771713257e-01
    z[0,3,5]  R295      4.9871876835823059e-01
    z[0,3,5]  R296      3.6343118548393250e-01
    z[0,3,5]  R297      4.5754191279411316e-01
    z[0,3,5]  R298      1.7003534734249115e-01
    z[0,3,5]  R299      1.1630651354789734e-01
    z[0,3,5]  R300      -5.2712593227624893e-02
    z[0,3,5]  R301      -2.5786796212196350e-01
    z[0,3,5]  R302      1.1628390848636627e-01
    z[0,3,5]  R303      -4.6830984950065613e-01
    z[0,3,5]  R304      -5.0291174650192261e-01
    z[0,3,5]  R305      -0.607593297958374
    z[0,3,5]  R306      -3.6988526582717896e-01
    z[0,3,5]  R307      -2.1564084291458130e-01
    z[0,3,5]  R308      3.7687757611274719e-01
    z[0,3,5]  R309      1.1666663736104965e-01
    z[0,3,5]  R310      -3.0345454812049866e-01
    z[0,3,5]  R311      -2.5710278749465942e-01
    z[0,3,5]  R312      -2.6696819067001343e-01
    z[0,3,5]  R313      -0.0908493921160698
    z[0,3,5]  R314      -4.4579851627349854e-01
    z[0,3,5]  R315      -2.9506006836891174e-01
    z[0,3,5]  R316      -1.4896060526371002e-01
    z[0,3,5]  R317      -2.2167436778545380e-01
    z[0,3,5]  R318      1.7484763264656067e-01
    z[0,3,5]  R319      -1.1869736760854721e-01
    z[0,3,5]  R320      2.9007965326309204e-01
    z[0,3,5]  R321      2.2567853331565857e-01
    z[0,3,5]  R322      1.0491573251783848e-02
    z[0,3,5]  R323      -5.9337094426155090e-02
    z[0,3,5]  R324      -1.8370407819747925e-01
    z[0,3,5]  R325      -1.0330832563340664e-02
    z[0,3,5]  R326      -1.5055145323276520e-01
    z[0,3,5]  R327      6.3797837495803833e-01
    z[0,3,5]  R328      -1.9927389919757843e-01
    z[0,3,5]  R329      2.1083581447601318e-01
    z[0,3,5]  R330      1.5214255452156067e-01
    z[0,3,5]  R331      4.8982560634613037e-02
    z[0,3,5]  R332      3.4996861219406128e-01
    z[0,3,5]  R333      -1.7084781575249508e-05
    z[0,3,5]  R334      -2.6103073358535767e-01
    z[0,3,5]  R335      1.1362256854772568e-01
    z[0,3,5]  R336      4.3569797277450562e-01
    z[0,3,5]  R337      -2.9749885201454163e-01
    z[0,3,5]  R338      4.0410479903221130e-01
    z[0,3,5]  R339      1.6149044036865234e-01
    z[0,3,5]  R340      1.4994250610470772e-02
    z[0,3,5]  R341      7.7708929777145386e-02
    z[0,3,5]  R342      -4.4270315766334534e-01
    z[0,3,5]  R343      -0.305593341588974
    z[0,3,5]  R344      3.9728847146034241e-01
    z[0,3,5]  R345      -0.0940985307097435
    z[0,3,5]  R346      5.1179504394531250e-01
    z[0,3,5]  R347      2.4010887742042542e-01
    z[0,3,5]  R348      -2.3609678447246552e-01
    z[0,3,5]  R349      -2.2068510297685862e-03
    z[0,3,5]  R350      3.9398795366287231e-01
    z[0,3,5]  R351      0.347615510225296
    z[0,3,5]  R352      1.8736734986305237e-01
    z[0,3,5]  R353      2.6821252703666687e-01
    z[0,3,5]  R354      1.3194820284843445e-01
    z[0,3,5]  R355      2.6607644557952881e-01
    z[0,3,5]  R356      -7.8134588897228241e-02
    z[0,3,5]  R357      0.392145037651062
    z[0,3,5]  R358      3.9392352104187012e-01
    z[0,3,5]  R359      4.7437033057212830e-01
    z[0,3,5]  R360      -5.4812286049127579e-02
    z[0,3,5]  R361      -3.8520131260156631e-02
    z[0,3,5]  R362      7.0141452550888062e-01
    z[0,3,5]  R363      1.4357431232929230e-01
    z[0,3,5]  R364      3.5824459791183472e-01
    z[0,3,5]  R365      1.4996562898159027e-01
    z[0,3,5]  R366      2.7571621537208557e-01
    z[0,3,5]  R367      4.4770732522010803e-01
    z[0,3,5]  R368      3.0636849999427795e-01
    z[0,3,5]  R369      2.2403483092784882e-01
    z[0,3,5]  R370      1.8599498271942139e-01
    z[0,3,5]  R371      3.1060692854225636e-03
    z[0,3,5]  R372      -2.6541724801063538e-01
    z[0,3,5]  R373      0.613767147064209
    z[0,3,5]  R374      4.5021235942840576e-01
    z[0,3,5]  R375      -1.7709356546401978e-01
    z[0,3,5]  R376      7.0006436109542847e-01
    z[0,3,5]  R377      -1.5343381464481354e-01
    z[0,3,5]  R378      -1.9948348402976990e-01
    z[0,3,5]  R379      5.8829028159379959e-02
    z[0,3,5]  R380      -1.3347668945789337e-01
    z[0,3,5]  R381      2.7100238204002380e-01
    z[0,3,5]  R382      2.9846087098121643e-01
    z[0,3,5]  R383      4.8254373669624329e-01
    z[0,3,5]  R384      1.7485502362251282e-01
    z[0,3,5]  R385      7.9436957836151123e-01
    z[0,3,5]  R386      -3.3977828919887543e-02
    z[0,3,5]  R387      2.1517501771450043e-01
    z[0,3,6]  R8        -1
    z[0,3,6]  R35       1
    z[0,3,6]  R256      -1
    z[0,3,6]  R257      1
    z[0,3,6]  R258      7.7819757163524628e-02
    z[0,3,6]  R259      1.6664761304855347e-01
    z[0,3,6]  R260      -2.0606763660907745e-02
    z[0,3,6]  R261      2.6358818635344505e-02
    z[0,3,6]  R262      -0.084261953830719
    z[0,3,6]  R263      4.2935600876808167e-01
    z[0,3,6]  R264      -4.5721733570098877e-01
    z[0,3,6]  R265      1.9737339019775391e-01
    z[0,3,6]  R266      3.2508898526430130e-02
    z[0,3,6]  R267      3.0719056725502014e-01
    z[0,3,6]  R268      -4.3408204801380634e-03
    z[0,3,6]  R269      1.4412012696266174e-01
    z[0,3,6]  R270      2.8908040374517441e-02
    z[0,3,6]  R271      -3.2881464809179306e-02
    z[0,3,6]  R272      0.237397700548172
    z[0,3,6]  R273      9.5143593847751617e-02
    z[0,3,6]  R274      -1.1203897744417191e-01
    z[0,3,6]  R275      0.0405583456158638
    z[0,3,6]  R276      2.0985612273216248e-01
    z[0,3,6]  R277      -4.4531369209289551e-01
    z[0,3,6]  R278      4.6910487115383148e-02
    z[0,3,6]  R279      2.4945002794265747e-01
    z[0,3,6]  R280      3.3773830533027649e-01
    z[0,3,6]  R281      -3.7616726756095886e-01
    z[0,3,6]  R282      -0.0771293193101883
    z[0,3,6]  R283      1.1005973647115752e-04
    z[0,3,6]  R284      6.0303110629320145e-02
    z[0,3,6]  R285      -2.4672379717230797e-02
    z[0,3,6]  R286      -2.8605468571186066e-02
    z[0,3,6]  R287      -4.3676221370697021e-01
    z[0,3,6]  R288      -2.8541502356529236e-01
    z[0,3,6]  R289      -2.6354700326919556e-01
    z[0,3,6]  R290      -9.7607143223285675e-02
    z[0,3,6]  R291      -1.3041138648986816e-01
    z[0,3,6]  R292      -4.3180756270885468e-02
    z[0,3,6]  R293      -3.5434693098068237e-01
    z[0,3,6]  R294      -3.6994233727455139e-02
    z[0,3,6]  R295      3.0429449677467346e-01
    z[0,3,6]  R296      1.6009826958179474e-01
    z[0,3,6]  R297      2.1410284936428070e-01
    z[0,3,6]  R298      -3.3373942971229553e-01
    z[0,3,6]  R299      -1.8317398428916931e-01
    z[0,3,6]  R300      -4.4695568084716797e-01
    z[0,3,6]  R301      -3.0181798338890076e-01
    z[0,3,6]  R302      4.8480287194252014e-01
    z[0,3,6]  R303      2.3972646892070770e-01
    z[0,3,6]  R304      3.9511356502771378e-02
    z[0,3,6]  R305      -4.6331661939620972e-01
    z[0,3,6]  R306      5.5952298641204834e-01
    z[0,3,6]  R307      2.2931481897830963e-01
    z[0,3,6]  R308      3.6947321146726608e-02
    z[0,3,6]  R309      -4.3364234268665314e-02
    z[0,3,6]  R310      -6.3689008355140686e-02
    z[0,3,6]  R311      6.7253686487674713e-02
    z[0,3,6]  R312      8.3075987640768290e-04
    z[0,3,6]  R313      0.238666370511055
    z[0,3,6]  R314      1.5998931229114532e-01
    z[0,3,6]  R315      -7.2067372500896454e-02
    z[0,3,6]  R316      1.7402539029717445e-02
    z[0,3,6]  R317      -4.5787545968778431e-04
    z[0,3,6]  R318      5.6041479110717773e-01
    z[0,3,6]  R319      -2.5544339418411255e-01
    z[0,3,6]  R320      -3.4603810310363770e-01
    z[0,3,6]  R321      2.1228450536727905e-01
    z[0,3,6]  R322      -5.5021807551383972e-02
    z[0,3,6]  R323      4.1464298963546753e-02
    z[0,3,6]  R324      -2.2769320011138916e-01
    z[0,3,6]  R325      1.6541224718093872e-01
    z[0,3,6]  R326      -4.2195141315460205e-02
    z[0,3,6]  R327      -2.9661238193511963e-01
    z[0,3,6]  R328      -1.7342790961265564e-02
    z[0,3,6]  R329      -0.442648321390152
    z[0,3,6]  R330      -2.8813473880290985e-02
    z[0,3,6]  R331      -0.0617663636803627
    z[0,3,6]  R332      2.7119159698486328e-01
    z[0,3,6]  R333      3.9645963907241821e-01
    z[0,3,6]  R334      0.0939316526055336
    z[0,3,6]  R335      -5.6069320440292358e-01
    z[0,3,6]  R336      5.5307167768478394e-01
    z[0,3,6]  R337      2.1062527596950531e-01
    z[0,3,6]  R338      -3.2975524663925171e-01
    z[0,3,6]  R339      -1.8817789852619171e-01
    z[0,3,6]  R340      -3.1503298878669739e-01
    z[0,3,6]  R341      7.3851831257343292e-02
    z[0,3,6]  R342      -1.4506006240844727e-01
    z[0,3,6]  R343      -2.0001192390918732e-01
    z[0,3,6]  R344      -3.4732496738433838e-01
    z[0,3,6]  R345      -2.6812374591827393e-01
    z[0,3,6]  R346      3.8313648104667664e-01
    z[0,3,6]  R347      0.0815952867269516
    z[0,3,6]  R348      1.8501979112625122e-01
    z[0,3,6]  R349      -1.1845734715461731e-01
    z[0,3,6]  R350      -5.1623537729028612e-06
    z[0,3,6]  R351      -1.0647686198353767e-02
    z[0,3,6]  R352      -9.4960257411003113e-03
    z[0,3,6]  R353      4.1246637701988220e-01
    z[0,3,6]  R354      3.5161346197128296e-02
    z[0,3,6]  R355      6.0502803325653076e-01
    z[0,3,6]  R356      -5.1895850896835327e-01
    z[0,3,6]  R357      -7.1474784612655640e-01
    z[0,3,6]  R358      -1.2056052684783936e-01
    z[0,3,6]  R359      2.2381272912025452e-01
    z[0,3,6]  R360      4.8936480283737183e-01
    z[0,3,6]  R361      1.7373697459697723e-01
    z[0,3,6]  R362      -2.0971101522445679e-01
    z[0,3,6]  R363      -6.7153668403625488e-01
    z[0,3,6]  R364      2.6181042194366455e-01
    z[0,3,6]  R365      -6.9374436140060425e-01
    z[0,3,6]  R366      -5.1352715492248535e-01
    z[0,3,6]  R367      2.4896657466888428e-01
    z[0,3,6]  R368      1.2381459027528763e-01
    z[0,3,6]  R369      -3.5530999302864075e-02
    z[0,3,6]  R370      6.5191254019737244e-02
    z[0,3,6]  R371      4.6483924984931946e-01
    z[0,3,6]  R372      -3.1138095259666443e-01
    z[0,3,6]  R373      4.9342062324285507e-02
    z[0,3,6]  R374      -1.0222411900758743e-01
    z[0,3,6]  R375      3.9326608180999756e-01
    z[0,3,6]  R376      -0.0815378800034523
    z[0,3,6]  R377      -9.5251612365245819e-02
    z[0,3,6]  R378      4.2908138036727905e-01
    z[0,3,6]  R379      2.3700079321861267e-01
    z[0,3,6]  R380      3.2113802433013916e-01
    z[0,3,6]  R381      6.2269139289855957e-01
    z[0,3,6]  R382      -2.3689050227403641e-02
    z[0,3,6]  R383      -6.3128936290740967e-01
    z[0,3,6]  R384      -2.9839566349983215e-01
    z[0,3,6]  R385      -4.2567479610443115e-01
    z[0,3,6]  R386      1.7113989591598511e-01
    z[0,3,6]  R387      -0.250872939825058
    z[3,0,0]  R2        1
    z[3,0,0]  R29       -1
    z[3,0,0]  R388      -1
    z[3,0,0]  R389      1
    z[3,0,0]  R402      -2.3660942912101746e-02
    z[3,0,0]  R403      -6.7642802000045776e-01
    z[3,0,0]  R404      -4.9517515301704407e-01
    z[3,0,0]  R405      -2.8080910444259644e-01
    z[3,0,0]  R406      -3.0979430675506592e-01
    z[3,0,0]  R407      -4.3818223476409912e-01
    z[3,0,0]  R408      -3.4521660208702087e-01
    z[3,0,0]  R409      2.8427250217646360e-03
    z[3,0,0]  R410      -6.6371224820613861e-02
    z[3,0,0]  R411      -2.6585647463798523e-01
    z[3,0,0]  R412      4.7867482900619507e-01
    z[3,0,0]  R413      -5.8776414394378662e-01
    z[3,0,0]  R414      -3.5246106982231140e-01
    z[3,0,0]  R415      -6.1804109811782837e-01
    z[3,0,0]  R416      -2.4182218313217163e-01
    z[3,0,0]  R417      -0.525830864906311
    z[3,0,0]  R418      -5.7502126693725586e-01
    z[3,0,0]  R419      -4.0891861915588379e-01
    z[3,0,0]  R420      -4.4103786349296570e-01
    z[3,0,0]  R421      -0.522939145565033
    z[3,0,0]  R422      2.4460309743881226e-01
    z[3,0,0]  R423      4.2715522646903992e-01
    z[3,0,0]  R424      3.2835906744003296e-01
    z[3,0,0]  R425      5.5589717626571655e-01
    z[3,0,0]  R426      -1.1993542313575745e-01
    z[3,0,0]  R427      5.2645742893218994e-01
    z[3,0,0]  R428      4.1524934768676758e-01
    z[3,0,0]  R429      4.1558876633644104e-01
    z[3,0,0]  R430      5.9942883253097534e-01
    z[3,0,0]  R431      2.7454838156700134e-02
    z[3,0,0]  R432      1.4633931219577789e-01
    z[3,0,0]  R433      3.0731040239334106e-01
    z[3,0,0]  R434      5.2321493625640869e-01
    z[3,0,0]  R435      2.3162433505058289e-01
    z[3,0,0]  R436      0.352159321308136
    z[3,0,0]  R437      4.1018098592758179e-01
    z[3,0,0]  R438      6.8061405420303345e-01
    z[3,0,0]  R439      0.587196409702301
    z[3,0,0]  R440      4.5920401811599731e-01
    z[3,0,0]  R441      4.8823356628417969e-01
    z[3,0,0]  R442      2.1337687969207764e-01
    z[3,0,0]  R443      0.702157199382782
    z[3,0,0]  R444      4.9267145991325378e-01
    z[3,0,0]  R445      1.6420282423496246e-01
    z[3,0,0]  R446      3.8145303726196289e-01
    z[3,0,0]  R447      6.1188286542892456e-01
    z[3,0,0]  R448      4.6825012564659119e-01
    z[3,0,0]  R449      4.9199223518371582e-01
    z[3,0,0]  R450      1.8281713128089905e-02
    z[3,0,0]  R451      0.5074462890625
    z[3,0,0]  R452      2.9385295510292053e-01
    z[3,0,0]  R453      4.3124410510063171e-01
    z[3,0,0]  R454      -5.7759042829275131e-02
    z[3,0,0]  R455      5.1795196533203125e-01
    z[3,0,0]  R456      6.3703131675720215e-01
    z[3,0,0]  R457      0.357229620218277
    z[3,0,0]  R458      -5.2753275632858276e-01
    z[3,0,0]  R459      2.2294804453849792e-01
    z[3,0,0]  R460      0.316459059715271
    z[3,0,0]  R461      2.4885358288884163e-02
    z[3,0,0]  R462      3.5174342989921570e-01
    z[3,0,0]  R463      3.0526661872863770e-01
    z[3,0,0]  R464      -2.0106610655784607e-01
    z[3,0,0]  R465      2.3342198133468628e-01
    z[3,0,0]  R466      3.5342502593994141e-01
    z[3,0,0]  R467      1.2162110209465027e-01
    z[3,0,0]  R468      9.8546624183654785e-02
    z[3,0,0]  R469      5.0777590274810791e-01
    z[3,0,0]  R470      -2.1205723285675049e-01
    z[3,0,0]  R471      -2.2117216885089874e-01
    z[3,0,0]  R472      6.5122477710247040e-02
    z[3,0,0]  R473      3.5603755712509155e-01
    z[3,0,0]  R474      0.0617666058242321
    z[3,0,0]  R475      5.4670524597167969e-01
    z[3,0,0]  R476      2.3764832317829132e-01
    z[3,0,0]  R477      4.9069947004318237e-01
    z[3,0,0]  R478      2.6874250173568726e-01
    z[3,0,0]  R479      3.3461397886276245e-01
    z[3,0,0]  R480      5.8027577400207520e-01
    z[3,0,0]  R481      9.4387523829936981e-02
    z[3,0,0]  R482      -5.5177497863769531e-01
    z[3,0,0]  R483      -4.0907946228981018e-01
    z[3,0,0]  R484      3.0622461438179016e-01
    z[3,0,0]  R485      2.8966364264488220e-01
    z[3,0,0]  R486      1.6090807318687439e-01
    z[3,0,0]  R487      4.8265120387077332e-01
    z[3,0,0]  R488      3.9025691151618958e-01
    z[3,0,0]  R489      2.1352705359458923e-01
    z[3,0,0]  R490      -0.0727607011795044
    z[3,0,0]  R491      -3.2407945394515991e-01
    z[3,0,0]  R492      -0.595670759677887
    z[3,0,0]  R493      -3.7485894560813904e-01
    z[3,0,0]  R494      -1.8457423150539398e-01
    z[3,0,0]  R495      -5.7814240455627441e-01
    z[3,0,0]  R496      -3.1091922521591187e-01
    z[3,0,0]  R497      -4.4319561123847961e-01
    z[3,0,0]  R498      -2.9543972015380859e-01
    z[3,0,0]  R499      -4.4200652837753296e-01
    z[3,0,0]  R500      6.2063220888376236e-02
    z[3,0,0]  R501      -1.3802291452884674e-01
    z[3,0,0]  R502      1.2147828191518784e-01
    z[3,0,0]  R503      -2.9867494106292725e-01
    z[3,0,0]  R504      -3.1643894314765930e-01
    z[3,0,0]  R505      3.2006077468395233e-02
    z[3,0,0]  R506      5.8187246322631836e-02
    z[3,0,0]  R507      -2.0086118951439857e-02
    z[3,0,0]  R508      2.5060039758682251e-01
    z[3,0,0]  R509      -1.2390428036451340e-01
    z[3,0,0]  R510      -1.4783337712287903e-01
    z[3,0,0]  R511      -1.3143141567707062e-01
    z[3,0,0]  R512      5.4461634159088135e-01
    z[3,0,0]  R513      3.9418607950210571e-01
    z[3,0,0]  R514      6.1878937482833862e-01
    z[3,0,0]  R515      0.476563036441803
    z[3,0,0]  R516      7.4172264337539673e-01
    z[3,0,0]  R517      6.7241811752319336e-01
    z[3,0,0]  R518      6.4190948009490967e-01
    z[3,0,0]  R519      6.5134871006011963e-01
    z[3,0,0]  R520      1.1419311165809631e-01
    z[3,0,0]  R521      5.9473598003387451e-01
    z[3,0,0]  R522      -9.8668999969959259e-02
    z[3,0,0]  R523      6.1946451663970947e-01
    z[3,0,0]  R524      0.542599081993103
    z[3,0,0]  R525      -1.0434793680906296e-01
    z[3,0,0]  R526      3.2040235400199890e-01
    z[3,0,0]  R527      7.2470021247863770e-01
    z[3,0,0]  R528      -3.1749375630170107e-03
    z[3,0,0]  R529      3.7793529033660889e-01
    z[3,0,0]  R530      -2.0786963403224945e-01
    z[3,0,0]  R531      -1.8122604489326477e-01
    z[3,0,1]  R3        1
    z[3,0,1]  R30       -1
    z[3,0,1]  R390      -1
    z[3,0,1]  R391      1
    z[3,0,1]  R402      0.842336893081665
    z[3,0,1]  R403      6.8349009752273560e-01
    z[3,0,1]  R404      6.7841392755508423e-01
    z[3,0,1]  R405      6.7690467834472656e-01
    z[3,0,1]  R406      6.4372408390045166e-01
    z[3,0,1]  R407      5.6303697824478149e-01
    z[3,0,1]  R408      5.4218709468841553e-01
    z[3,0,1]  R409      5.9074205160140991e-01
    z[3,0,1]  R410      5.7622200250625610e-01
    z[3,0,1]  R411      5.2282029390335083e-01
    z[3,0,1]  R412      2.6429495215415955e-01
    z[3,0,1]  R413      -6.3401788473129272e-01
    z[3,0,1]  R414      -8.5421293973922729e-01
    z[3,0,1]  R415      -0.698803186416626
    z[3,0,1]  R416      -8.3294248580932617e-01
    z[3,0,1]  R417      -6.6108095645904541e-01
    z[3,0,1]  R418      -5.9603250026702881e-01
    z[3,0,1]  R419      -5.2921229600906372e-01
    z[3,0,1]  R420      -5.1782667636871338e-01
    z[3,0,1]  R421      -5.2858549356460571e-01
    z[3,0,1]  R422      4.1859099268913269e-01
    z[3,0,1]  R423      4.9714335799217224e-01
    z[3,0,1]  R424      -0.0708140879869461
    z[3,0,1]  R425      -4.7793912887573242e-01
    z[3,0,1]  R426      -3.9171531796455383e-01
    z[3,0,1]  R427      -3.1207174062728882e-01
    z[3,0,1]  R428      -2.1651053428649902e-01
    z[3,0,1]  R429      -3.1970804929733276e-01
    z[3,0,1]  R430      -2.5623393058776855e-01
    z[3,0,1]  R431      2.4614408612251282e-01
    z[3,0,1]  R432      -7.6266628503799438e-01
    z[3,0,1]  R433      -3.6327430605888367e-01
    z[3,0,1]  R434      2.2373306751251221e-01
    z[3,0,1]  R435      -4.9296915531158447e-01
    z[3,0,1]  R436      5.6185829639434814e-01
    z[3,0,1]  R437      7.7729612588882446e-01
    z[3,0,1]  R438      5.1344454288482666e-01
    z[3,0,1]  R439      -1.8832521140575409e-01
    z[3,0,1]  R440      2.5979763269424438e-01
    z[3,0,1]  R441      -3.6433655023574829e-01
    z[3,0,1]  R442      2.9991710186004639e-01
    z[3,0,1]  R443      -1.8482691049575806e-01
    z[3,0,1]  R444      5.1216334104537964e-01
    z[3,0,1]  R445      5.9576076269149780e-01
    z[3,0,1]  R446      0.552386999130249
    z[3,0,1]  R447      4.9788832664489746e-01
    z[3,0,1]  R448      6.2892836332321167e-01
    z[3,0,1]  R449      7.0189118385314941e-01
    z[3,0,1]  R450      -2.1042430400848389e-01
    z[3,0,1]  R451      7.1531242132186890e-01
    z[3,0,1]  R452      7.3811477422714233e-01
    z[3,0,1]  R453      4.6012678742408752e-01
    z[3,0,1]  R454      -2.3309087753295898e-01
    z[3,0,1]  R455      6.7887884378433228e-01
    z[3,0,1]  R456      6.1221557855606079e-01
    z[3,0,1]  R457      7.4682730436325073e-01
    z[3,0,1]  R458      -2.3578248918056488e-01
    z[3,0,1]  R459      -3.9649134874343872e-01
    z[3,0,1]  R460      -1.2682583928108215e-01
    z[3,0,1]  R461      1.2493968755006790e-01
    z[3,0,1]  R462      2.9076436161994934e-01
    z[3,0,1]  R463      7.1940815448760986e-01
    z[3,0,1]  R464      -5.1374858617782593e-01
    z[3,0,1]  R465      -3.2952564954757690e-01
    z[3,0,1]  R466      1.0562562942504883e-01
    z[3,0,1]  R467      -5.8447830379009247e-03
    z[3,0,1]  R468      -6.7971736192703247e-01
    z[3,0,1]  R469      0.0712711289525032
    z[3,0,1]  R470      -2.0662029087543488e-01
    z[3,0,1]  R471      1.6451099514961243e-01
    z[3,0,1]  R472      4.7735238075256348e-01
    z[3,0,1]  R473      -4.0121245384216309e-01
    z[3,0,1]  R474      -7.5811302661895752e-01
    z[3,0,1]  R475      -6.5737382101360708e-05
    z[3,0,1]  R476      -8.6188906431198120e-01
    z[3,0,1]  R477      -1.1684004217386246e-01
    z[3,0,1]  R478      3.5133507847785950e-01
    z[3,0,1]  R479      -8.4839671850204468e-02
    z[3,0,1]  R480      9.1011054813861847e-02
    z[3,0,1]  R481      -1.2946946918964386e-01
    z[3,0,1]  R482      -4.4211155176162720e-01
    z[3,0,1]  R483      -4.5028707385063171e-01
    z[3,0,1]  R484      -8.7053716182708740e-02
    z[3,0,1]  R485      2.7605205774307251e-01
    z[3,0,1]  R486      1.8752078711986542e-01
    z[3,0,1]  R487      8.2377985119819641e-02
    z[3,0,1]  R488      8.8901974260807037e-02
    z[3,0,1]  R489      1.4832818508148193e-01
    z[3,0,1]  R490      -7.2970294952392578e-01
    z[3,0,1]  R491      -7.9550343751907349e-01
    z[3,0,1]  R492      -4.4385874271392822e-01
    z[3,0,1]  R493      -4.2086270451545715e-01
    z[3,0,1]  R494      -0.529179573059082
    z[3,0,1]  R495      -4.1710504889488220e-01
    z[3,0,1]  R496      -8.6575299501419067e-01
    z[3,0,1]  R497      -0.421099990606308
    z[3,0,1]  R498      -3.9300060272216797e-01
    z[3,0,1]  R499      -3.5395517945289612e-01
    z[3,0,1]  R500      -4.0363934636116028e-01
    z[3,0,1]  R501      -7.0809775590896606e-01
    z[3,0,1]  R502      0.897419273853302
    z[3,0,1]  R503      0.900534987449646
    z[3,0,1]  R504      0.902877151966095
    z[3,0,1]  R505      9.1613984107971191e-01
    z[3,0,1]  R506      8.9577335119247437e-01
    z[3,0,1]  R507      9.3991589546203613e-01
    z[3,0,1]  R508      8.9128780364990234e-01
    z[3,0,1]  R509      8.3712917566299438e-01
    z[3,0,1]  R510      8.4881031513214111e-01
    z[3,0,1]  R511      0.816559374332428
    z[3,0,1]  R512      5.4552732035517693e-03
    z[3,0,1]  R513      2.3812660947442055e-02
    z[3,0,1]  R514      0.0827384814620018
    z[3,0,1]  R515      3.1028954312205315e-02
    z[3,0,1]  R516      5.4847251623868942e-02
    z[3,0,1]  R517      9.2687368392944336e-02
    z[3,0,1]  R518      -6.5321475267410278e-02
    z[3,0,1]  R519      1.5127401053905487e-01
    z[3,0,1]  R520      1.9041022285819054e-02
    z[3,0,1]  R521      1.1130225658416748e-01
    z[3,0,1]  R522      -5.5492192506790161e-01
    z[3,0,1]  R523      -6.6467088460922241e-01
    z[3,0,1]  R524      -5.6200414896011353e-01
    z[3,0,1]  R525      -1.8602198362350464e-01
    z[3,0,1]  R526      -2.4653628468513489e-01
    z[3,0,1]  R527      3.1718581914901733e-01
    z[3,0,1]  R528      2.8134384751319885e-01
    z[3,0,1]  R529      -4.3276441097259521e-01
    z[3,0,1]  R530      -9.6648633480072021e-02
    z[3,0,1]  R531      6.7415893077850342e-02
    z[3,0,2]  R4        1
    z[3,0,2]  R31       -1
    z[3,0,2]  R392      -1
    z[3,0,2]  R393      1
    z[3,0,2]  R402      1.4451944828033447e-01
    z[3,0,2]  R403      -6.6902157850563526e-03
    z[3,0,2]  R404      -2.3741452395915985e-01
    z[3,0,2]  R405      -3.3453068137168884e-01
    z[3,0,2]  R406      -1.7780803143978119e-01
    z[3,0,2]  R407      3.5348970443010330e-02
    z[3,0,2]  R408      4.5870873332023621e-01
    z[3,0,2]  R409      1.5734094381332397e-01
    z[3,0,2]  R410      -0.425411194562912
    z[3,0,2]  R411      3.5178694128990173e-01
    z[3,0,2]  R412      6.6110062599182129e-01
    z[3,0,2]  R413      -2.9593446850776672e-01
    z[3,0,2]  R414      -7.1088381111621857e-02
    z[3,0,2]  R415      -0.0973065197467804
    z[3,0,2]  R416      -2.5544852018356323e-01
    z[3,0,2]  R417      -2.9635587334632874e-01
    z[3,0,2]  R418      -2.8497090935707092e-01
    z[3,0,2]  R419      -6.3906210660934448e-01
    z[3,0,2]  R420      -0.667457103729248
    z[3,0,2]  R421      -5.7527345418930054e-01
    z[3,0,2]  R422      5.1331037282943726e-01
    z[3,0,2]  R423      1.8045547604560852e-01
    z[3,0,2]  R424      3.1240659952163696e-01
    z[3,0,2]  R425      1.0660746693611145e-01
    z[3,0,2]  R426      4.5155549049377441e-01
    z[3,0,2]  R427      2.7448868751525879e-01
    z[3,0,2]  R428      -5.2570984698832035e-03
    z[3,0,2]  R429      5.1050531864166260e-01
    z[3,0,2]  R430      3.7498977035284042e-02
    z[3,0,2]  R431      4.7652056813240051e-01
    z[3,0,2]  R432      2.1068260073661804e-01
    z[3,0,2]  R433      3.4870314598083496e-01
    z[3,0,2]  R434      6.9835472106933594e-01
    z[3,0,2]  R435      7.1132189035415649e-01
    z[3,0,2]  R436      1.3834661245346069e-01
    z[3,0,2]  R437      2.4175962433218956e-02
    z[3,0,2]  R438      1.1042704433202744e-01
    z[3,0,2]  R439      1.0658313333988190e-01
    z[3,0,2]  R440      1.4647732675075531e-01
    z[3,0,2]  R441      4.9737501144409180e-01
    z[3,0,2]  R442      6.2148753553628922e-02
    z[3,0,2]  R443      2.6213395595550537e-01
    z[3,0,2]  R444      -9.8603196442127228e-02
    z[3,0,2]  R445      -1.4586040377616882e-01
    z[3,0,2]  R446      -1.4332130551338196e-01
    z[3,0,2]  R447      1.5385118126869202e-01
    z[3,0,2]  R448      2.2596241533756256e-01
    z[3,0,2]  R449      7.3518723249435425e-02
    z[3,0,2]  R450      2.5252890586853027e-01
    z[3,0,2]  R451      1.7043286561965942e-01
    z[3,0,2]  R452      2.5744667649269104e-01
    z[3,0,2]  R453      6.8309265375137329e-01
    z[3,0,2]  R454      5.0319695472717285e-01
    z[3,0,2]  R455      3.5586360096931458e-01
    z[3,0,2]  R456      3.0896160006523132e-01
    z[3,0,2]  R457      -0.069015271961689
    z[3,0,2]  R458      -2.5801885128021240e-01
    z[3,0,2]  R459      4.8450362682342529e-01
    z[3,0,2]  R460      6.9639271497726440e-01
    z[3,0,2]  R461      2.9191273450851440e-01
    z[3,0,2]  R462      -4.8016417026519775e-01
    z[3,0,2]  R463      -1.0359817743301392e-01
    z[3,0,2]  R464      -4.5071166753768921e-01
    z[3,0,2]  R465      8.4194815158843994e-01
    z[3,0,2]  R466      -9.0492151677608490e-02
    z[3,0,2]  R467      6.8993037939071655e-01
    z[3,0,2]  R468      2.0763725042343140e-01
    z[3,0,2]  R469      3.7901934981346130e-01
    z[3,0,2]  R470      -4.2340385913848877e-01
    z[3,0,2]  R471      -5.7228218764066696e-02
    z[3,0,2]  R472      1.8733383715152740e-01
    z[3,0,2]  R473      6.4164972305297852e-01
    z[3,0,2]  R474      2.5032129883766174e-01
    z[3,0,2]  R475      3.3896341919898987e-01
    z[3,0,2]  R476      0.0697273463010788
    z[3,0,2]  R477      -1.9183041527867317e-02
    z[3,0,2]  R478      1.4869990944862366e-01
    z[3,0,2]  R479      6.1271142959594727e-01
    z[3,0,2]  R480      -4.8083987087011337e-02
    z[3,0,2]  R481      8.8728785514831543e-01
    z[3,0,2]  R482      -3.7146055698394775e-01
    z[3,0,2]  R483      -3.4338730573654175e-01
    z[3,0,2]  R484      7.0441210269927979e-01
    z[3,0,2]  R485      3.3388638496398926e-01
    z[3,0,2]  R486      6.1313128471374512e-01
    z[3,0,2]  R487      2.8575578331947327e-01
    z[3,0,2]  R488      2.8835749626159668e-01
    z[3,0,2]  R489      2.1216154098510742e-01
    z[3,0,2]  R490      5.5589151382446289e-01
    z[3,0,2]  R491      9.2491582036018372e-02
    z[3,0,2]  R492      -2.8671988844871521e-01
    z[3,0,2]  R493      -5.0583446025848389e-01
    z[3,0,2]  R494      -3.8096874952316284e-01
    z[3,0,2]  R495      -5.9246593713760376e-01
    z[3,0,2]  R496      -1.7986467480659485e-01
    z[3,0,2]  R497      -6.2425899505615234e-01
    z[3,0,2]  R498      -6.4657533168792725e-01
    z[3,0,2]  R499      -7.8528332710266113e-01
    z[3,0,2]  R500      -8.7665939331054688e-01
    z[3,0,2]  R501      -2.3562364280223846e-02
    z[3,0,2]  R502      -4.1183501482009888e-01
    z[3,0,2]  R503      -2.5626808404922485e-01
    z[3,0,2]  R504      2.5473069399595261e-02
    z[3,0,2]  R505      1.6784700751304626e-01
    z[3,0,2]  R506      -1.3380204141139984e-01
    z[3,0,2]  R507      1.6160102188587189e-01
    z[3,0,2]  R508      5.1723778247833252e-02
    z[3,0,2]  R509      -2.8242358565330505e-01
    z[3,0,2]  R510      4.5180737972259521e-01
    z[3,0,2]  R511      -1.1835354566574097e-01
    z[3,0,2]  R512      5.9386283159255981e-01
    z[3,0,2]  R513      6.9971585273742676e-01
    z[3,0,2]  R514      3.7243339419364929e-01
    z[3,0,2]  R515      6.2867981195449829e-01
    z[3,0,2]  R516      3.7749308347702026e-01
    z[3,0,2]  R517      2.9669496417045593e-01
    z[3,0,2]  R518      5.3719258308410645e-01
    z[3,0,2]  R519      6.7282044887542725e-01
    z[3,0,2]  R520      5.3101140260696411e-01
    z[3,0,2]  R521      2.5265955924987793e-01
    z[3,0,2]  R522      2.2434255480766296e-01
    z[3,0,2]  R523      -2.5789499282836914e-01
    z[3,0,2]  R524      4.0086638927459717e-01
    z[3,0,2]  R525      8.4713113307952881e-01
    z[3,0,2]  R526      2.7665188908576965e-01
    z[3,0,2]  R527      0.373761922121048
    z[3,0,2]  R528      9.2212641239166260e-01
    z[3,0,2]  R529      2.0049897953867912e-02
    z[3,0,2]  R530      1.0363273322582245e-01
    z[3,0,2]  R531      -5.5132254958152771e-02
    z[3,0,3]  R5        1
    z[3,0,3]  R32       -1
    z[3,0,3]  R394      -1
    z[3,0,3]  R395      1
    z[3,0,3]  R402      1.5452498197555542e-01
    z[3,0,3]  R403      -1.3995146751403809e-01
    z[3,0,3]  R404      -1.5703247487545013e-01
    z[3,0,3]  R405      1.2292017787694931e-01
    z[3,0,3]  R406      3.3047699928283691e-01
    z[3,0,3]  R407      4.2566198110580444e-01
    z[3,0,3]  R408      -2.5924065709114075e-01
    z[3,0,3]  R409      -5.1565170288085938e-02
    z[3,0,3]  R410      9.4079270958900452e-02
    z[3,0,3]  R411      4.1670314967632294e-02
    z[3,0,3]  R412      -3.4154820442199707e-01
    z[3,0,3]  R413      3.8465496897697449e-01
    z[3,0,3]  R414      1.9840165972709656e-01
    z[3,0,3]  R415      1.9946859776973724e-01
    z[3,0,3]  R416      1.9778101146221161e-01
    z[3,0,3]  R417      3.0093595385551453e-01
    z[3,0,3]  R418      6.8186283111572266e-02
    z[3,0,3]  R419      1.7986796796321869e-01
    z[3,0,3]  R420      2.6327994465827942e-01
    z[3,0,3]  R421      1.6986837983131409e-01
    z[3,0,3]  R422      -1.1933231353759766e-01
    z[3,0,3]  R423      -4.5953401923179626e-01
    z[3,0,3]  R424      -4.9614539742469788e-01
    z[3,0,3]  R425      -5.9462565183639526e-01
    z[3,0,3]  R426      -7.8989648818969727e-01
    z[3,0,3]  R427      7.1969664096832275e-01
    z[3,0,3]  R428      7.7174967527389526e-01
    z[3,0,3]  R429      6.5546214580535889e-01
    z[3,0,3]  R430      7.4106442928314209e-01
    z[3,0,3]  R431      2.0021730661392212e-01
    z[3,0,3]  R432      5.5433970689773560e-01
    z[3,0,3]  R433      -0.52590012550354
    z[3,0,3]  R434      -2.0495519042015076e-01
    z[3,0,3]  R435      -4.1875174641609192e-01
    z[3,0,3]  R436      -1.0279170423746109e-01
    z[3,0,3]  R437      -2.3706091940402985e-01
    z[3,0,3]  R438      -3.3714500069618225e-01
    z[3,0,3]  R439      -5.2882552146911621e-01
    z[3,0,3]  R440      -6.9368675351142883e-02
    z[3,0,3]  R441      -4.7914066910743713e-01
    z[3,0,3]  R442      -9.9878363311290741e-02
    z[3,0,3]  R443      -5.1860916614532471e-01
    z[3,0,3]  R444      -3.5057091712951660e-01
    z[3,0,3]  R445      -2.8914105892181396e-01
    z[3,0,3]  R446      -5.3530967235565186e-01
    z[3,0,3]  R447      -4.6962723135948181e-01
    z[3,0,3]  R448      -1.1298985779285431e-01
    z[3,0,3]  R449      -4.1704189777374268e-01
    z[3,0,3]  R450      -6.3620281219482422e-01
    z[3,0,3]  R451      -1.1998195201158524e-01
    z[3,0,3]  R452      -4.4902548193931580e-01
    z[3,0,3]  R453      -3.3522203564643860e-01
    z[3,0,3]  R454      -7.0099848508834839e-01
    z[3,0,3]  R455      -1.5192590653896332e-01
    z[3,0,3]  R456      -1.7222185432910919e-01
    z[3,0,3]  R457      -1.0414893925189972e-01
    z[3,0,3]  R458      3.5653609037399292e-01
    z[3,0,3]  R459      -3.4274348616600037e-01
    z[3,0,3]  R460      -2.7085381746292114e-01
    z[3,0,3]  R461      -4.7200977802276611e-01
    z[3,0,3]  R462      2.4483743309974670e-01
    z[3,0,3]  R463      -1.5734506770968437e-02
    z[3,0,3]  R464      4.1942241787910461e-01
    z[3,0,3]  R465      -2.6084804534912109e-01
    z[3,0,3]  R466      -4.4614812731742859e-01
    z[3,0,3]  R467      -1.6034652292728424e-01
    z[3,0,3]  R468      5.3146493434906006e-01
    z[3,0,3]  R469      -1.1219819635152817e-01
    z[3,0,3]  R470      3.1958571076393127e-01
    z[3,0,3]  R471      -7.0361125469207764e-01
    z[3,0,3]  R472      -1.9121690420433879e-03
    z[3,0,3]  R473      -4.7457507252693176e-01
    z[3,0,3]  R474      5.5143153667449951e-01
    z[3,0,3]  R475      -4.7516596317291260e-01
    z[3,0,3]  R476      1.0443050414323807e-01
    z[3,0,3]  R477      -6.0496044158935547e-01
    z[3,0,3]  R478      -6.7006343603134155e-01
    z[3,0,3]  R479      -0.553982675075531
    z[3,0,3]  R480      -2.4072326719760895e-01
    z[3,0,3]  R481      -3.7531527876853943e-01
    z[3,0,3]  R482      2.7557075023651123e-01
    z[3,0,3]  R483      4.3271756172180176e-01
    z[3,0,3]  R484      -4.4720742106437683e-01
    z[3,0,3]  R485      -4.1746154427528381e-01
    z[3,0,3]  R486      -2.7875733375549316e-01
    z[3,0,3]  R487      -1.6073594987392426e-01
    z[3,0,3]  R488      -6.6731703281402588e-01
    z[3,0,3]  R489      -1.9253656268119812e-01
    z[3,0,3]  R490      2.6407274603843689e-01
    z[3,0,3]  R491      -0.37900310754776
    z[3,0,3]  R492      4.4222053140401840e-02
    z[3,0,3]  R493      -1.3470019400119781e-01
    z[3,0,3]  R494      -2.8704026341438293e-01
    z[3,0,3]  R495      -2.4648956954479218e-01
    z[3,0,3]  R496      -1.8796291947364807e-01
    z[3,0,3]  R497      1.4601151645183563e-01
    z[3,0,3]  R498      -9.7074195742607117e-02
    z[3,0,3]  R499      1.0145763307809830e-01
    z[3,0,3]  R500      -1.6864429414272308e-01
    z[3,0,3]  R501      0.300178587436676
    z[3,0,3]  R502      -7.0722915232181549e-02
    z[3,0,3]  R503      1.2170047499239445e-02
    z[3,0,3]  R504      -1.6872355341911316e-01
    z[3,0,3]  R505      -3.0889034271240234e-01
    z[3,0,3]  R506      3.1220692396163940e-01
    z[3,0,3]  R507      7.3165573179721832e-02
    z[3,0,3]  R508      2.8877484798431396e-01
    z[3,0,3]  R509      1.8450444936752319e-01
    z[3,0,3]  R510      8.5690997540950775e-02
    z[3,0,3]  R511      1.0713714361190796e-01
    z[3,0,3]  R512      -3.2739424705505371e-01
    z[3,0,3]  R513      -2.7972236275672913e-01
    z[3,0,3]  R514      -3.1490191817283630e-01
    z[3,0,3]  R515      -3.8572177290916443e-01
    z[3,0,3]  R516      -2.3742128908634186e-01
    z[3,0,3]  R517      -2.8748938441276550e-01
    z[3,0,3]  R518      -2.8587976098060608e-01
    z[3,0,3]  R519      -2.6113662123680115e-01
    z[3,0,3]  R520      -5.4309302568435669e-01
    z[3,0,3]  R521      -4.2717960476875305e-01
    z[3,0,3]  R522      4.9050047993659973e-01
    z[3,0,3]  R523      1.6774599254131317e-01
    z[3,0,3]  R524      3.5282951593399048e-01
    z[3,0,3]  R525      -4.4394549727439880e-01
    z[3,0,3]  R526      -8.7034332752227783e-01
    z[3,0,3]  R527      1.5707907080650330e-01
    z[3,0,3]  R528      7.1136265993118286e-02
    z[3,0,3]  R529      3.0250164866447449e-01
    z[3,0,3]  R530      -7.5055903196334839e-01
    z[3,0,3]  R531      -6.7583733797073364e-01
    z[3,0,4]  R6        1
    z[3,0,4]  R33       -1
    z[3,0,4]  R396      -1
    z[3,0,4]  R397      1
    z[3,0,4]  R402      3.2380679249763489e-01
    z[3,0,4]  R403      9.2603355646133423e-02
    z[3,0,4]  R404      1.0480130463838577e-01
    z[3,0,4]  R405      0.422298789024353
    z[3,0,4]  R406      3.1663909554481506e-01
    z[3,0,4]  R407      1.7822766304016113e-01
    z[3,0,4]  R408      2.3400390148162842e-01
    z[3,0,4]  R409      1.9942112267017365e-01
    z[3,0,4]  R410      -1.5445487201213837e-01
    z[3,0,4]  R411      6.5681242942810059e-01
    z[3,0,4]  R412      -6.2510512769222260e-02
    z[3,0,4]  R413      -3.9069067686796188e-02
    z[3,0,4]  R414      7.4388369917869568e-02
    z[3,0,4]  R415      9.9086299538612366e-02
    z[3,0,4]  R416      -2.6848608255386353e-01
    z[3,0,4]  R417      -2.0704948902130127e-01
    z[3,0,4]  R418      -6.2490370124578476e-02
    z[3,0,4]  R419      0.140402153134346
    z[3,0,4]  R420      5.8145960792899132e-03
    z[3,0,4]  R421      -1.9544173777103424e-01
    z[3,0,4]  R422      -3.7760642170906067e-01
    z[3,0,4]  R423      -4.9730348587036133e-01
    z[3,0,4]  R424      5.8268254995346069e-01
    z[3,0,4]  R425      -4.0152069181203842e-02
    z[3,0,4]  R426      -3.4616544842720032e-02
    z[3,0,4]  R427      -1.6403122246265411e-01
    z[3,0,4]  R428      -3.1539592146873474e-01
    z[3,0,4]  R429      8.5781447589397430e-02
    z[3,0,4]  R430      6.1869039200246334e-04
    z[3,0,4]  R431      4.2012521624565125e-01
    z[3,0,4]  R432      7.2348825633525848e-02
    z[3,0,4]  R433      -3.6747512221336365e-01
    z[3,0,4]  R434      -3.5000881552696228e-01
    z[3,0,4]  R435      -1.2563988566398621e-01
    z[3,0,4]  R436      -5.7842051982879639e-01
    z[3,0,4]  R437      1.1661750078201294e-01
    z[3,0,4]  R438      2.6517572999000549e-01
    z[3,0,4]  R439      3.7823032587766647e-02
    z[3,0,4]  R440      4.4682011008262634e-01
    z[3,0,4]  R441      1.3806016743183136e-01
    z[3,0,4]  R442      -7.6068562269210815e-01
    z[3,0,4]  R443      2.7139365673065186e-01
    z[3,0,4]  R444      -5.1270890235900879e-01
    z[3,0,4]  R445      -7.0833325386047363e-01
    z[3,0,4]  R446      -1.5885916352272034e-01
    z[3,0,4]  R447      0.0097271129488945
    z[3,0,4]  R448      2.0710526406764984e-01
    z[3,0,4]  R449      0.0722404271364212
    z[3,0,4]  R450      2.7952590584754944e-01
    z[3,0,4]  R451      3.5081812739372253e-01
    z[3,0,4]  R452      1.0469100624322891e-01
    z[3,0,4]  R453      9.6361495554447174e-02
    z[3,0,4]  R454      2.0615534484386444e-01
    z[3,0,4]  R455      1.3375785201787949e-02
    z[3,0,4]  R456      2.4304132163524628e-01
    z[3,0,4]  R457      -2.3866172134876251e-01
    z[3,0,4]  R458      6.7363011837005615e-01
    z[3,0,4]  R459      -6.3374914228916168e-02
    z[3,0,4]  R460      -2.2365452349185944e-01
    z[3,0,4]  R461      1.0546257346868515e-01
    z[3,0,4]  R462      -5.7577687501907349e-01
    z[3,0,4]  R463      -3.2119274139404297e-01
    z[3,0,4]  R464      2.7220621705055237e-01
    z[3,0,4]  R465      1.6834603250026703e-01
    z[3,0,4]  R466      3.4747067093849182e-01
    z[3,0,4]  R467      1.0901419818401337e-01
    z[3,0,4]  R468      7.6294101774692535e-02
    z[3,0,4]  R469      2.7761319279670715e-01
    z[3,0,4]  R470      0.539633572101593
    z[3,0,4]  R471      -0.404040664434433
    z[3,0,4]  R472      -7.8968626260757446e-01
    z[3,0,4]  R473      -1.5451841056346893e-01
    z[3,0,4]  R474      -1.2596817314624786e-01
    z[3,0,4]  R475      3.7993314862251282e-01
    z[3,0,4]  R476      -1.3228172063827515e-01
    z[3,0,4]  R477      8.5183707997202873e-03
    z[3,0,4]  R478      0.3465596139431
    z[3,0,4]  R479      1.1181795597076416e-01
    z[3,0,4]  R480      3.1304755806922913e-01
    z[3,0,4]  R481      1.1650119721889496e-01
    z[3,0,4]  R482      2.4950966238975525e-01
    z[3,0,4]  R483      5.1488459110260010e-01
    z[3,0,4]  R484      2.8550243377685547e-01
    z[3,0,4]  R485      3.0487564206123352e-01
    z[3,0,4]  R486      6.2902212142944336e-01
    z[3,0,4]  R487      -1.4626890420913696e-01
    z[3,0,4]  R488      0.437857985496521
    z[3,0,4]  R489      -1.9519197940826416e-01
    z[3,0,4]  R490      2.3031803965568542e-01
    z[3,0,4]  R491      2.6669876649975777e-02
    z[3,0,4]  R492      -3.7564572691917419e-01
    z[3,0,4]  R493      -1.7045332491397858e-01
    z[3,0,4]  R494      -6.6091604530811310e-02
    z[3,0,4]  R495      -3.8730047643184662e-02
    z[3,0,4]  R496      2.7339997887611389e-01
    z[3,0,4]  R497      -0.0617363266646862
    z[3,0,4]  R498      -3.4131160378456116e-01
    z[3,0,4]  R499      -7.2167210280895233e-02
    z[3,0,4]  R500      1.7700275778770447e-01
    z[3,0,4]  R501      -2.1491970121860504e-01
    z[3,0,4]  R502      1.4138107188045979e-02
    z[3,0,4]  R503      5.8108780533075333e-02
    z[3,0,4]  R504      1.3009758293628693e-01
    z[3,0,4]  R505      1.8706850707530975e-01
    z[3,0,4]  R506      1.4939698576927185e-01
    z[3,0,4]  R507      -2.4596697092056274e-01
    z[3,0,4]  R508      4.8291280865669250e-02
    z[3,0,4]  R509      -4.0485617518424988e-01
    z[3,0,4]  R510      -4.5830491930246353e-02
    z[3,0,4]  R511      2.7651217579841614e-01
    z[3,0,4]  R512      2.0069877803325653e-01
    z[3,0,4]  R513      -2.8072007000446320e-02
    z[3,0,4]  R514      1.8341344594955444e-01
    z[3,0,4]  R515      -1.0104627162218094e-01
    z[3,0,4]  R516      -2.2576268017292023e-01
    z[3,0,4]  R517      -1.6243544220924377e-01
    z[3,0,4]  R518      -2.6549813151359558e-01
    z[3,0,4]  R519      -1.7620180547237396e-01
    z[3,0,4]  R520      3.9468744397163391e-01
    z[3,0,4]  R521      -2.5569441914558411e-01
    z[3,0,4]  R522      -2.0987190306186676e-01
    z[3,0,4]  R523      8.1804707646369934e-02
    z[3,0,4]  R524      1.6349682211875916e-01
    z[3,0,4]  R525      -5.3939230740070343e-02
    z[3,0,4]  R526      6.1589833348989487e-03
    z[3,0,4]  R527      -4.9056809395551682e-02
    z[3,0,4]  R528      1.0225493460893631e-01
    z[3,0,4]  R529      4.8647204041481018e-01
    z[3,0,4]  R530      -4.6438881754875183e-01
    z[3,0,4]  R531      -4.9762633442878723e-01
    z[3,0,5]  R7        1
    z[3,0,5]  R34       -1
    z[3,0,5]  R398      -1
    z[3,0,5]  R399      1
    z[3,0,5]  R402      1.7003534734249115e-01
    z[3,0,5]  R403      1.1630651354789734e-01
    z[3,0,5]  R404      -5.2712593227624893e-02
    z[3,0,5]  R405      -2.5786796212196350e-01
    z[3,0,5]  R406      1.1628390848636627e-01
    z[3,0,5]  R407      -4.6830984950065613e-01
    z[3,0,5]  R408      -5.0291174650192261e-01
    z[3,0,5]  R409      -0.607593297958374
    z[3,0,5]  R410      -3.6988526582717896e-01
    z[3,0,5]  R411      -2.1564084291458130e-01
    z[3,0,5]  R412      3.7687757611274719e-01
    z[3,0,5]  R413      1.1666663736104965e-01
    z[3,0,5]  R414      -3.0345454812049866e-01
    z[3,0,5]  R415      -2.5710278749465942e-01
    z[3,0,5]  R416      -2.6696819067001343e-01
    z[3,0,5]  R417      -0.0908493921160698
    z[3,0,5]  R418      -4.4579851627349854e-01
    z[3,0,5]  R419      -2.9506006836891174e-01
    z[3,0,5]  R420      -1.4896060526371002e-01
    z[3,0,5]  R421      -2.2167436778545380e-01
    z[3,0,5]  R422      1.7484763264656067e-01
    z[3,0,5]  R423      -1.1869736760854721e-01
    z[3,0,5]  R424      2.9007965326309204e-01
    z[3,0,5]  R425      2.2567853331565857e-01
    z[3,0,5]  R426      1.0491573251783848e-02
    z[3,0,5]  R427      -5.9337094426155090e-02
    z[3,0,5]  R428      -1.8370407819747925e-01
    z[3,0,5]  R429      -1.0330832563340664e-02
    z[3,0,5]  R430      -1.5055145323276520e-01
    z[3,0,5]  R431      6.3797837495803833e-01
    z[3,0,5]  R432      -1.9927389919757843e-01
    z[3,0,5]  R433      2.1083581447601318e-01
    z[3,0,5]  R434      1.5214255452156067e-01
    z[3,0,5]  R435      4.8982560634613037e-02
    z[3,0,5]  R436      3.4996861219406128e-01
    z[3,0,5]  R437      -1.7084781575249508e-05
    z[3,0,5]  R438      -2.6103073358535767e-01
    z[3,0,5]  R439      1.1362256854772568e-01
    z[3,0,5]  R440      4.3569797277450562e-01
    z[3,0,5]  R441      -2.9749885201454163e-01
    z[3,0,5]  R442      4.0410479903221130e-01
    z[3,0,5]  R443      1.6149044036865234e-01
    z[3,0,5]  R444      1.4994250610470772e-02
    z[3,0,5]  R445      7.7708929777145386e-02
    z[3,0,5]  R446      -4.4270315766334534e-01
    z[3,0,5]  R447      -0.305593341588974
    z[3,0,5]  R448      3.9728847146034241e-01
    z[3,0,5]  R449      -0.0940985307097435
    z[3,0,5]  R450      5.1179504394531250e-01
    z[3,0,5]  R451      2.4010887742042542e-01
    z[3,0,5]  R452      -2.3609678447246552e-01
    z[3,0,5]  R453      -2.2068510297685862e-03
    z[3,0,5]  R454      3.9398795366287231e-01
    z[3,0,5]  R455      0.347615510225296
    z[3,0,5]  R456      1.8736734986305237e-01
    z[3,0,5]  R457      2.6821252703666687e-01
    z[3,0,5]  R458      1.3194820284843445e-01
    z[3,0,5]  R459      2.6607644557952881e-01
    z[3,0,5]  R460      -7.8134588897228241e-02
    z[3,0,5]  R461      0.392145037651062
    z[3,0,5]  R462      3.9392352104187012e-01
    z[3,0,5]  R463      4.7437033057212830e-01
    z[3,0,5]  R464      -5.4812286049127579e-02
    z[3,0,5]  R465      -3.8520131260156631e-02
    z[3,0,5]  R466      7.0141452550888062e-01
    z[3,0,5]  R467      1.4357431232929230e-01
    z[3,0,5]  R468      3.5824459791183472e-01
    z[3,0,5]  R469      1.4996562898159027e-01
    z[3,0,5]  R470      2.7571621537208557e-01
    z[3,0,5]  R471      4.4770732522010803e-01
    z[3,0,5]  R472      3.0636849999427795e-01
    z[3,0,5]  R473      2.2403483092784882e-01
    z[3,0,5]  R474      1.8599498271942139e-01
    z[3,0,5]  R475      3.1060692854225636e-03
    z[3,0,5]  R476      -2.6541724801063538e-01
    z[3,0,5]  R477      0.613767147064209
    z[3,0,5]  R478      4.5021235942840576e-01
    z[3,0,5]  R479      -1.7709356546401978e-01
    z[3,0,5]  R480      7.0006436109542847e-01
    z[3,0,5]  R481      -1.5343381464481354e-01
    z[3,0,5]  R482      -1.9948348402976990e-01
    z[3,0,5]  R483      5.8829028159379959e-02
    z[3,0,5]  R484      -1.3347668945789337e-01
    z[3,0,5]  R485      2.7100238204002380e-01
    z[3,0,5]  R486      2.9846087098121643e-01
    z[3,0,5]  R487      4.8254373669624329e-01
    z[3,0,5]  R488      1.7485502362251282e-01
    z[3,0,5]  R489      7.9436957836151123e-01
    z[3,0,5]  R490      -3.3977828919887543e-02
    z[3,0,5]  R491      2.1517501771450043e-01
    z[3,0,5]  R492      -4.6565684676170349e-01
    z[3,0,5]  R493      -5.9288865327835083e-01
    z[3,0,5]  R494      -6.7348307371139526e-01
    z[3,0,5]  R495      -2.7893880009651184e-01
    z[3,0,5]  R496      -6.5360978245735168e-02
    z[3,0,5]  R497      -1.6454692184925079e-01
    z[3,0,5]  R498      -7.2398573160171509e-02
    z[3,0,5]  R499      0.0906539037823677
    z[3,0,5]  R500      -6.2161255627870560e-02
    z[3,0,5]  R501      -4.9832555651664734e-01
    z[3,0,5]  R502      7.1085587143898010e-02
    z[3,0,5]  R503      9.9303878843784332e-02
    z[3,0,5]  R504      1.9442611932754517e-01
    z[3,0,5]  R505      -1.3173783663660288e-03
    z[3,0,5]  R506      -1.2290755286812782e-02
    z[3,0,5]  R507      1.2302239984273911e-01
    z[3,0,5]  R508      2.0458373427391052e-01
    z[3,0,5]  R509      -0.0671120211482048
    z[3,0,5]  R510      -7.3197772726416588e-03
    z[3,0,5]  R511      1.2532912194728851e-01
    z[3,0,5]  R512      4.4835552573204041e-01
    z[3,0,5]  R513      4.6172514557838440e-01
    z[3,0,5]  R514      4.7400042414665222e-01
    z[3,0,5]  R515      2.7603101730346680e-01
    z[3,0,5]  R516      4.3709456920623779e-01
    z[3,0,5]  R517      5.8497828245162964e-01
    z[3,0,5]  R518      3.7317070364952087e-01
    z[3,0,5]  R519      1.8044155091047287e-02
    z[3,0,5]  R520      5.0306838750839233e-01
    z[3,0,5]  R521      3.6254772543907166e-01
    z[3,0,5]  R522      5.1565271615982056e-01
    z[3,0,5]  R523      6.0653075575828552e-02
    z[3,0,5]  R524      2.6133623719215393e-01
    z[3,0,5]  R525      1.4096808433532715e-01
    z[3,0,5]  R526      2.5017103180289268e-02
    z[3,0,5]  R527      2.8611651062965393e-01
    z[3,0,5]  R528      2.3158925771713257e-01
    z[3,0,5]  R529      4.9871876835823059e-01
    z[3,0,5]  R530      3.6343118548393250e-01
    z[3,0,5]  R531      4.5754191279411316e-01
    z[3,0,6]  R8        1
    z[3,0,6]  R35       -1
    z[3,0,6]  R400      -1
    z[3,0,6]  R401      1
    z[3,0,6]  R402      -3.3373942971229553e-01
    z[3,0,6]  R403      -1.8317398428916931e-01
    z[3,0,6]  R404      -4.4695568084716797e-01
    z[3,0,6]  R405      -3.0181798338890076e-01
    z[3,0,6]  R406      4.8480287194252014e-01
    z[3,0,6]  R407      2.3972646892070770e-01
    z[3,0,6]  R408      3.9511356502771378e-02
    z[3,0,6]  R409      -4.6331661939620972e-01
    z[3,0,6]  R410      5.5952298641204834e-01
    z[3,0,6]  R411      2.2931481897830963e-01
    z[3,0,6]  R412      3.6947321146726608e-02
    z[3,0,6]  R413      -4.3364234268665314e-02
    z[3,0,6]  R414      -6.3689008355140686e-02
    z[3,0,6]  R415      6.7253686487674713e-02
    z[3,0,6]  R416      8.3075987640768290e-04
    z[3,0,6]  R417      0.238666370511055
    z[3,0,6]  R418      1.5998931229114532e-01
    z[3,0,6]  R419      -7.2067372500896454e-02
    z[3,0,6]  R420      1.7402539029717445e-02
    z[3,0,6]  R421      -4.5787545968778431e-04
    z[3,0,6]  R422      5.6041479110717773e-01
    z[3,0,6]  R423      -2.5544339418411255e-01
    z[3,0,6]  R424      -3.4603810310363770e-01
    z[3,0,6]  R425      2.1228450536727905e-01
    z[3,0,6]  R426      -5.5021807551383972e-02
    z[3,0,6]  R427      4.1464298963546753e-02
    z[3,0,6]  R428      -2.2769320011138916e-01
    z[3,0,6]  R429      1.6541224718093872e-01
    z[3,0,6]  R430      -4.2195141315460205e-02
    z[3,0,6]  R431      -2.9661238193511963e-01
    z[3,0,6]  R432      -1.7342790961265564e-02
    z[3,0,6]  R433      -0.442648321390152
    z[3,0,6]  R434      -2.8813473880290985e-02
    z[3,0,6]  R435      -0.0617663636803627
    z[3,0,6]  R436      2.7119159698486328e-01
    z[3,0,6]  R437      3.9645963907241821e-01
    z[3,0,6]  R438      0.0939316526055336
    z[3,0,6]  R439      -5.6069320440292358e-01
    z[3,0,6]  R440      5.5307167768478394e-01
    z[3,0,6]  R441      2.1062527596950531e-01
    z[3,0,6]  R442      -3.2975524663925171e-01
    z[3,0,6]  R443      -1.8817789852619171e-01
    z[3,0,6]  R444      -3.1503298878669739e-01
    z[3,0,6]  R445      7.3851831257343292e-02
    z[3,0,6]  R446      -1.4506006240844727e-01
    z[3,0,6]  R447      -2.0001192390918732e-01
    z[3,0,6]  R448      -3.4732496738433838e-01
    z[3,0,6]  R449      -2.6812374591827393e-01
    z[3,0,6]  R450      3.8313648104667664e-01
    z[3,0,6]  R451      0.0815952867269516
    z[3,0,6]  R452      1.8501979112625122e-01
    z[3,0,6]  R453      -1.1845734715461731e-01
    z[3,0,6]  R454      -5.1623537729028612e-06
    z[3,0,6]  R455      -1.0647686198353767e-02
    z[3,0,6]  R456      -9.4960257411003113e-03
    z[3,0,6]  R457      4.1246637701988220e-01
    z[3,0,6]  R458      3.5161346197128296e-02
    z[3,0,6]  R459      6.0502803325653076e-01
    z[3,0,6]  R460      -5.1895850896835327e-01
    z[3,0,6]  R461      -7.1474784612655640e-01
    z[3,0,6]  R462      -1.2056052684783936e-01
    z[3,0,6]  R463      2.2381272912025452e-01
    z[3,0,6]  R464      4.8936480283737183e-01
    z[3,0,6]  R465      1.7373697459697723e-01
    z[3,0,6]  R466      -2.0971101522445679e-01
    z[3,0,6]  R467      -6.7153668403625488e-01
    z[3,0,6]  R468      2.6181042194366455e-01
    z[3,0,6]  R469      -6.9374436140060425e-01
    z[3,0,6]  R470      -5.1352715492248535e-01
    z[3,0,6]  R471      2.4896657466888428e-01
    z[3,0,6]  R472      1.2381459027528763e-01
    z[3,0,6]  R473      -3.5530999302864075e-02
    z[3,0,6]  R474      6.5191254019737244e-02
    z[3,0,6]  R475      4.6483924984931946e-01
    z[3,0,6]  R476      -3.1138095259666443e-01
    z[3,0,6]  R477      4.9342062324285507e-02
    z[3,0,6]  R478      -1.0222411900758743e-01
    z[3,0,6]  R479      3.9326608180999756e-01
    z[3,0,6]  R480      -0.0815378800034523
    z[3,0,6]  R481      -9.5251612365245819e-02
    z[3,0,6]  R482      4.2908138036727905e-01
    z[3,0,6]  R483      2.3700079321861267e-01
    z[3,0,6]  R484      3.2113802433013916e-01
    z[3,0,6]  R485      6.2269139289855957e-01
    z[3,0,6]  R486      -2.3689050227403641e-02
    z[3,0,6]  R487      -6.3128936290740967e-01
    z[3,0,6]  R488      -2.9839566349983215e-01
    z[3,0,6]  R489      -4.2567479610443115e-01
    z[3,0,6]  R490      1.7113989591598511e-01
    z[3,0,6]  R491      -0.250872939825058
    z[3,0,6]  R492      7.7819757163524628e-02
    z[3,0,6]  R493      1.6664761304855347e-01
    z[3,0,6]  R494      -2.0606763660907745e-02
    z[3,0,6]  R495      2.6358818635344505e-02
    z[3,0,6]  R496      -0.084261953830719
    z[3,0,6]  R497      4.2935600876808167e-01
    z[3,0,6]  R498      -4.5721733570098877e-01
    z[3,0,6]  R499      1.9737339019775391e-01
    z[3,0,6]  R500      3.2508898526430130e-02
    z[3,0,6]  R501      3.0719056725502014e-01
    z[3,0,6]  R502      -4.3408204801380634e-03
    z[3,0,6]  R503      1.4412012696266174e-01
    z[3,0,6]  R504      2.8908040374517441e-02
    z[3,0,6]  R505      -3.2881464809179306e-02
    z[3,0,6]  R506      0.237397700548172
    z[3,0,6]  R507      9.5143593847751617e-02
    z[3,0,6]  R508      -1.1203897744417191e-01
    z[3,0,6]  R509      0.0405583456158638
    z[3,0,6]  R510      2.0985612273216248e-01
    z[3,0,6]  R511      -4.4531369209289551e-01
    z[3,0,6]  R512      4.6910487115383148e-02
    z[3,0,6]  R513      2.4945002794265747e-01
    z[3,0,6]  R514      3.3773830533027649e-01
    z[3,0,6]  R515      -3.7616726756095886e-01
    z[3,0,6]  R516      -0.0771293193101883
    z[3,0,6]  R517      1.1005973647115752e-04
    z[3,0,6]  R518      6.0303110629320145e-02
    z[3,0,6]  R519      -2.4672379717230797e-02
    z[3,0,6]  R520      -2.8605468571186066e-02
    z[3,0,6]  R521      -4.3676221370697021e-01
    z[3,0,6]  R522      -2.8541502356529236e-01
    z[3,0,6]  R523      -2.6354700326919556e-01
    z[3,0,6]  R524      -9.7607143223285675e-02
    z[3,0,6]  R525      -1.3041138648986816e-01
    z[3,0,6]  R526      -4.3180756270885468e-02
    z[3,0,6]  R527      -3.5434693098068237e-01
    z[3,0,6]  R528      -3.6994233727455139e-02
    z[3,0,6]  R529      3.0429449677467346e-01
    z[3,0,6]  R530      1.6009826958179474e-01
    z[3,0,6]  R531      2.1410284936428070e-01
    z[0,4,0]  R2        -1
    z[0,4,0]  R38       1
    z[0,4,0]  R532      -1
    z[0,4,0]  R533      1
    z[0,4,0]  R546      -0.595670759677887
    z[0,4,0]  R547      -3.7485894560813904e-01
    z[0,4,0]  R548      -1.8457423150539398e-01
    z[0,4,0]  R549      -5.7814240455627441e-01
    z[0,4,0]  R550      -3.1091922521591187e-01
    z[0,4,0]  R551      -4.4319561123847961e-01
    z[0,4,0]  R552      -2.9543972015380859e-01
    z[0,4,0]  R553      -4.4200652837753296e-01
    z[0,4,0]  R554      6.2063220888376236e-02
    z[0,4,0]  R555      -1.3802291452884674e-01
    z[0,4,0]  R556      1.2147828191518784e-01
    z[0,4,0]  R557      -2.9867494106292725e-01
    z[0,4,0]  R558      -3.1643894314765930e-01
    z[0,4,0]  R559      3.2006077468395233e-02
    z[0,4,0]  R560      5.8187246322631836e-02
    z[0,4,0]  R561      -2.0086118951439857e-02
    z[0,4,0]  R562      2.5060039758682251e-01
    z[0,4,0]  R563      -1.2390428036451340e-01
    z[0,4,0]  R564      -1.4783337712287903e-01
    z[0,4,0]  R565      -1.3143141567707062e-01
    z[0,4,0]  R566      5.4461634159088135e-01
    z[0,4,0]  R567      3.9418607950210571e-01
    z[0,4,0]  R568      6.1878937482833862e-01
    z[0,4,0]  R569      0.476563036441803
    z[0,4,0]  R570      7.4172264337539673e-01
    z[0,4,0]  R571      6.7241811752319336e-01
    z[0,4,0]  R572      6.4190948009490967e-01
    z[0,4,0]  R573      6.5134871006011963e-01
    z[0,4,0]  R574      1.1419311165809631e-01
    z[0,4,0]  R575      5.9473598003387451e-01
    z[0,4,0]  R576      -9.8668999969959259e-02
    z[0,4,0]  R577      6.1946451663970947e-01
    z[0,4,0]  R578      0.542599081993103
    z[0,4,0]  R579      -1.0434793680906296e-01
    z[0,4,0]  R580      3.2040235400199890e-01
    z[0,4,0]  R581      7.2470021247863770e-01
    z[0,4,0]  R582      -3.1749375630170107e-03
    z[0,4,0]  R583      3.7793529033660889e-01
    z[0,4,0]  R584      -2.0786963403224945e-01
    z[0,4,0]  R585      -1.8122604489326477e-01
    z[0,4,0]  R586      -4.3566304445266724e-01
    z[0,4,0]  R587      1.1860569566488266e-01
    z[0,4,0]  R588      -3.3444091677665710e-01
    z[0,4,0]  R589      -4.9569246172904968e-01
    z[0,4,0]  R590      -4.7821506857872009e-01
    z[0,4,0]  R591      -2.5301378965377808e-01
    z[0,4,0]  R592      0.00965464673936367
    z[0,4,0]  R593      -7.8255213797092438e-02
    z[0,4,0]  R594      1.2590855360031128e-01
    z[0,4,0]  R595      -1.0428953170776367e-01
    z[0,4,0]  R596      0.323359876871109
    z[0,4,0]  R597      3.7382391095161438e-01
    z[0,4,0]  R598      7.9257696866989136e-02
    z[0,4,0]  R599      3.5170421004295349e-01
    z[0,4,0]  R600      3.0049356818199158e-01
    z[0,4,0]  R601      7.3320543766021729e-01
    z[0,4,0]  R602      1.4527393877506256e-01
    z[0,4,0]  R603      6.4717435836791992e-01
    z[0,4,0]  R604      -1.5803582966327667e-01
    z[0,4,0]  R605      -3.5336855053901672e-01
    z[0,4,0]  R606      2.2044897079467773e-01
    z[0,4,0]  R607      0.0868205651640892
    z[0,4,0]  R608      -8.1602618098258972e-02
    z[0,4,0]  R609      2.1975185722112656e-02
    z[0,4,0]  R610      7.1332126855850220e-02
    z[0,4,0]  R611      1.3148538768291473e-01
    z[0,4,0]  R612      -5.4136735200881958e-01
    z[0,4,0]  R613      5.0642073154449463e-01
    z[0,4,0]  R614      1.5650652348995209e-01
    z[0,4,0]  R615      -1.3747981190681458e-01
    z[0,4,1]  R3        -1
    z[0,4,1]  R39       1
    z[0,4,1]  R534      -1
    z[0,4,1]  R535      1
    z[0,4,1]  R546      -4.4385874271392822e-01
    z[0,4,1]  R547      -4.2086270451545715e-01
    z[0,4,1]  R548      -0.529179573059082
    z[0,4,1]  R549      -4.1710504889488220e-01
    z[0,4,1]  R550      -8.6575299501419067e-01
    z[0,4,1]  R551      -0.421099990606308
    z[0,4,1]  R552      -3.9300060272216797e-01
    z[0,4,1]  R553      -3.5395517945289612e-01
    z[0,4,1]  R554      -4.0363934636116028e-01
    z[0,4,1]  R555      -7.0809775590896606e-01
    z[0,4,1]  R556      0.897419273853302
    z[0,4,1]  R557      0.900534987449646
    z[0,4,1]  R558      0.902877151966095
    z[0,4,1]  R559      9.1613984107971191e-01
    z[0,4,1]  R560      8.9577335119247437e-01
    z[0,4,1]  R561      9.3991589546203613e-01
    z[0,4,1]  R562      8.9128780364990234e-01
    z[0,4,1]  R563      8.3712917566299438e-01
    z[0,4,1]  R564      8.4881031513214111e-01
    z[0,4,1]  R565      0.816559374332428
    z[0,4,1]  R566      5.4552732035517693e-03
    z[0,4,1]  R567      2.3812660947442055e-02
    z[0,4,1]  R568      0.0827384814620018
    z[0,4,1]  R569      3.1028954312205315e-02
    z[0,4,1]  R570      5.4847251623868942e-02
    z[0,4,1]  R571      9.2687368392944336e-02
    z[0,4,1]  R572      -6.5321475267410278e-02
    z[0,4,1]  R573      1.5127401053905487e-01
    z[0,4,1]  R574      1.9041022285819054e-02
    z[0,4,1]  R575      1.1130225658416748e-01
    z[0,4,1]  R576      -5.5492192506790161e-01
    z[0,4,1]  R577      -6.6467088460922241e-01
    z[0,4,1]  R578      -5.6200414896011353e-01
    z[0,4,1]  R579      -1.8602198362350464e-01
    z[0,4,1]  R580      -2.4653628468513489e-01
    z[0,4,1]  R581      3.1718581914901733e-01
    z[0,4,1]  R582      2.8134384751319885e-01
    z[0,4,1]  R583      -4.3276441097259521e-01
    z[0,4,1]  R584      -9.6648633480072021e-02
    z[0,4,1]  R585      6.7415893077850342e-02
    z[0,4,1]  R586      7.5889408588409424e-01
    z[0,4,1]  R587      7.5472515821456909e-01
    z[0,4,1]  R588      8.6888861656188965e-01
    z[0,4,1]  R589      0.603097140789032
    z[0,4,1]  R590      5.7544064521789551e-01
    z[0,4,1]  R591      0.612223744392395
    z[0,4,1]  R592      6.5207844972610474e-01
    z[0,4,1]  R593      6.4350157976150513e-01
    z[0,4,1]  R594      -8.4987187385559082e-01
    z[0,4,1]  R595      -8.2063728570938110e-01
    z[0,4,1]  R596      7.5189995765686035e-01
    z[0,4,1]  R597      4.3783202767372131e-01
    z[0,4,1]  R598      -3.8606387376785278e-01
    z[0,4,1]  R599      -2.4214853346347809e-01
    z[0,4,1]  R600      -3.1058117747306824e-01
    z[0,4,1]  R601      -2.2177360951900482e-01
    z[0,4,1]  R602      -1.5315692871809006e-02
    z[0,4,1]  R603      -3.2986709475517273e-01
    z[0,4,1]  R604      2.3476628959178925e-01
    z[0,4,1]  R605      1.9111397862434387e-01
    z[0,4,1]  R606      7.2244065999984741e-01
    z[0,4,1]  R607      5.5984967947006226e-01
    z[0,4,1]  R608      4.1613170504570007e-01
    z[0,4,1]  R609      4.0391734242439270e-01
    z[0,4,1]  R610      4.3273970484733582e-01
    z[0,4,1]  R611      3.8729482889175415e-01
    z[0,4,1]  R612      -2.0500813424587250e-01
    z[0,4,1]  R613      -6.2468174844980240e-02
    z[0,4,1]  R614      -5.0921678543090820e-02
    z[0,4,1]  R615      -3.5752475261688232e-01
    z[0,4,2]  R4        -1
    z[0,4,2]  R40       1
    z[0,4,2]  R536      -1
    z[0,4,2]  R537      1
    z[0,4,2]  R546      -2.8671988844871521e-01
    z[0,4,2]  R547      -5.0583446025848389e-01
    z[0,4,2]  R548      -3.8096874952316284e-01
    z[0,4,2]  R549      -5.9246593713760376e-01
    z[0,4,2]  R550      -1.7986467480659485e-01
    z[0,4,2]  R551      -6.2425899505615234e-01
    z[0,4,2]  R552      -6.4657533168792725e-01
    z[0,4,2]  R553      -7.8528332710266113e-01
    z[0,4,2]  R554      -8.7665939331054688e-01
    z[0,4,2]  R555      -2.3562364280223846e-02
    z[0,4,2]  R556      -4.1183501482009888e-01
    z[0,4,2]  R557      -2.5626808404922485e-01
    z[0,4,2]  R558      2.5473069399595261e-02
    z[0,4,2]  R559      1.6784700751304626e-01
    z[0,4,2]  R560      -1.3380204141139984e-01
    z[0,4,2]  R561      1.6160102188587189e-01
    z[0,4,2]  R562      5.1723778247833252e-02
    z[0,4,2]  R563      -2.8242358565330505e-01
    z[0,4,2]  R564      4.5180737972259521e-01
    z[0,4,2]  R565      -1.1835354566574097e-01
    z[0,4,2]  R566      5.9386283159255981e-01
    z[0,4,2]  R567      6.9971585273742676e-01
    z[0,4,2]  R568      3.7243339419364929e-01
    z[0,4,2]  R569      6.2867981195449829e-01
    z[0,4,2]  R570      3.7749308347702026e-01
    z[0,4,2]  R571      2.9669496417045593e-01
    z[0,4,2]  R572      5.3719258308410645e-01
    z[0,4,2]  R573      6.7282044887542725e-01
    z[0,4,2]  R574      5.3101140260696411e-01
    z[0,4,2]  R575      2.5265955924987793e-01
    z[0,4,2]  R576      2.2434255480766296e-01
    z[0,4,2]  R577      -2.5789499282836914e-01
    z[0,4,2]  R578      4.0086638927459717e-01
    z[0,4,2]  R579      8.4713113307952881e-01
    z[0,4,2]  R580      2.7665188908576965e-01
    z[0,4,2]  R581      0.373761922121048
    z[0,4,2]  R582      9.2212641239166260e-01
    z[0,4,2]  R583      2.0049897953867912e-02
    z[0,4,2]  R584      1.0363273322582245e-01
    z[0,4,2]  R585      -5.5132254958152771e-02
    z[0,4,2]  R586      1.1177688837051392e-01
    z[0,4,2]  R587      -4.3407250195741653e-02
    z[0,4,2]  R588      3.0480053275823593e-02
    z[0,4,2]  R589      3.0818262696266174e-01
    z[0,4,2]  R590      4.3888410925865173e-01
    z[0,4,2]  R591      -6.2086533755064011e-02
    z[0,4,2]  R592      1.2212823331356049e-01
    z[0,4,2]  R593      -7.3171287775039673e-02
    z[0,4,2]  R594      3.2754510641098022e-01
    z[0,4,2]  R595      -2.2392237558960915e-02
    z[0,4,2]  R596      3.8310687988996506e-02
    z[0,4,2]  R597      3.6883878707885742e-01
    z[0,4,2]  R598      -1.6428200900554657e-01
    z[0,4,2]  R599      -2.7812442183494568e-01
    z[0,4,2]  R600      -2.9574507474899292e-01
    z[0,4,2]  R601      -2.9847124218940735e-01
    z[0,4,2]  R602      2.7253448963165283e-01
    z[0,4,2]  R603      -2.4370205402374268e-01
    z[0,4,2]  R604      -0.265984445810318
    z[0,4,2]  R605      -6.4389117062091827e-02
    z[0,4,2]  R606      -4.4989919662475586e-01
    z[0,4,2]  R607      -7.8759752213954926e-02
    z[0,4,2]  R608      -1.0610629618167877e-01
    z[0,4,2]  R609      0.192478746175766
    z[0,4,2]  R610      -1.1112035065889359e-01
    z[0,4,2]  R611      5.6924498081207275e-01
    z[0,4,2]  R612      3.7033399939537048e-01
    z[0,4,2]  R613      8.6332149803638458e-03
    z[0,4,2]  R614      1.4917572028934956e-02
    z[0,4,2]  R615      -4.1301719844341278e-02
    z[0,4,3]  R5        -1
    z[0,4,3]  R41       1
    z[0,4,3]  R538      -1
    z[0,4,3]  R539      1
    z[0,4,3]  R546      4.4222053140401840e-02
    z[0,4,3]  R547      -1.3470019400119781e-01
    z[0,4,3]  R548      -2.8704026341438293e-01
    z[0,4,3]  R549      -2.4648956954479218e-01
    z[0,4,3]  R550      -1.8796291947364807e-01
    z[0,4,3]  R551      1.4601151645183563e-01
    z[0,4,3]  R552      -9.7074195742607117e-02
    z[0,4,3]  R553      1.0145763307809830e-01
    z[0,4,3]  R554      -1.6864429414272308e-01
    z[0,4,3]  R555      0.300178587436676
    z[0,4,3]  R556      -7.0722915232181549e-02
    z[0,4,3]  R557      1.2170047499239445e-02
    z[0,4,3]  R558      -1.6872355341911316e-01
    z[0,4,3]  R559      -3.0889034271240234e-01
    z[0,4,3]  R560      3.1220692396163940e-01
    z[0,4,3]  R561      7.3165573179721832e-02
    z[0,4,3]  R562      2.8877484798431396e-01
    z[0,4,3]  R563      1.8450444936752319e-01
    z[0,4,3]  R564      8.5690997540950775e-02
    z[0,4,3]  R565      1.0713714361190796e-01
    z[0,4,3]  R566      -3.2739424705505371e-01
    z[0,4,3]  R567      -2.7972236275672913e-01
    z[0,4,3]  R568      -3.1490191817283630e-01
    z[0,4,3]  R569      -3.8572177290916443e-01
    z[0,4,3]  R570      -2.3742128908634186e-01
    z[0,4,3]  R571      -2.8748938441276550e-01
    z[0,4,3]  R572      -2.8587976098060608e-01
    z[0,4,3]  R573      -2.6113662123680115e-01
    z[0,4,3]  R574      -5.4309302568435669e-01
    z[0,4,3]  R575      -4.2717960476875305e-01
    z[0,4,3]  R576      4.9050047993659973e-01
    z[0,4,3]  R577      1.6774599254131317e-01
    z[0,4,3]  R578      3.5282951593399048e-01
    z[0,4,3]  R579      -4.4394549727439880e-01
    z[0,4,3]  R580      -8.7034332752227783e-01
    z[0,4,3]  R581      1.5707907080650330e-01
    z[0,4,3]  R582      7.1136265993118286e-02
    z[0,4,3]  R583      3.0250164866447449e-01
    z[0,4,3]  R584      -7.5055903196334839e-01
    z[0,4,3]  R585      -6.7583733797073364e-01
    z[0,4,3]  R586      -4.1165980696678162e-01
    z[0,4,3]  R587      -0.512349009513855
    z[0,4,3]  R588      -2.7854391932487488e-01
    z[0,4,3]  R589      5.7831909507513046e-02
    z[0,4,3]  R590      2.8801107406616211e-01
    z[0,4,3]  R591      3.1249490380287170e-01
    z[0,4,3]  R592      1.3719774782657623e-01
    z[0,4,3]  R593      4.3428402394056320e-02
    z[0,4,3]  R594      -6.6395789384841919e-02
    z[0,4,3]  R595      -3.9228478074073792e-01
    z[0,4,3]  R596      3.4189349412918091e-01
    z[0,4,3]  R597      4.8163211345672607e-01
    z[0,4,3]  R598      8.0897784233093262e-01
    z[0,4,3]  R599      8.2589679956436157e-01
    z[0,4,3]  R600      5.5961722135543823e-01
    z[0,4,3]  R601      3.9866998791694641e-01
    z[0,4,3]  R602      -7.4746638536453247e-01
    z[0,4,3]  R603      2.6748523116111755e-01
    z[0,4,3]  R604      0.646652102470398
    z[0,4,3]  R605      5.6053936481475830e-01
    z[0,4,3]  R606      5.5258788168430328e-02
    z[0,4,3]  R607      4.0571206808090210e-01
    z[0,4,3]  R608      8.2479590177536011e-01
    z[0,4,3]  R609      7.6130068302154541e-01
    z[0,4,3]  R610      1.5137337148189545e-01
    z[0,4,3]  R611      2.9105362296104431e-01
    z[0,4,3]  R612      -6.1816269159317017e-01
    z[0,4,3]  R613      -6.7544937133789062e-01
    z[0,4,3]  R614      -6.6152596473693848e-01
    z[0,4,3]  R615      4.3023351579904556e-02
    z[0,4,4]  R6        -1
    z[0,4,4]  R42       1
    z[0,4,4]  R540      -1
    z[0,4,4]  R541      1
    z[0,4,4]  R546      -3.7564572691917419e-01
    z[0,4,4]  R547      -1.7045332491397858e-01
    z[0,4,4]  R548      -6.6091604530811310e-02
    z[0,4,4]  R549      -3.8730047643184662e-02
    z[0,4,4]  R550      2.7339997887611389e-01
    z[0,4,4]  R551      -0.0617363266646862
    z[0,4,4]  R552      -3.4131160378456116e-01
    z[0,4,4]  R553      -7.2167210280895233e-02
    z[0,4,4]  R554      1.7700275778770447e-01
    z[0,4,4]  R555      -2.1491970121860504e-01
    z[0,4,4]  R556      1.4138107188045979e-02
    z[0,4,4]  R557      5.8108780533075333e-02
    z[0,4,4]  R558      1.3009758293628693e-01
    z[0,4,4]  R559      1.8706850707530975e-01
    z[0,4,4]  R560      1.4939698576927185e-01
    z[0,4,4]  R561      -2.4596697092056274e-01
    z[0,4,4]  R562      4.8291280865669250e-02
    z[0,4,4]  R563      -4.0485617518424988e-01
    z[0,4,4]  R564      -4.5830491930246353e-02
    z[0,4,4]  R565      2.7651217579841614e-01
    z[0,4,4]  R566      2.0069877803325653e-01
    z[0,4,4]  R567      -2.8072007000446320e-02
    z[0,4,4]  R568      1.8341344594955444e-01
    z[0,4,4]  R569      -1.0104627162218094e-01
    z[0,4,4]  R570      -2.2576268017292023e-01
    z[0,4,4]  R571      -1.6243544220924377e-01
    z[0,4,4]  R572      -2.6549813151359558e-01
    z[0,4,4]  R573      -1.7620180547237396e-01
    z[0,4,4]  R574      3.9468744397163391e-01
    z[0,4,4]  R575      -2.5569441914558411e-01
    z[0,4,4]  R576      -2.0987190306186676e-01
    z[0,4,4]  R577      8.1804707646369934e-02
    z[0,4,4]  R578      1.6349682211875916e-01
    z[0,4,4]  R579      -5.3939230740070343e-02
    z[0,4,4]  R580      6.1589833348989487e-03
    z[0,4,4]  R581      -4.9056809395551682e-02
    z[0,4,4]  R582      1.0225493460893631e-01
    z[0,4,4]  R583      4.8647204041481018e-01
    z[0,4,4]  R584      -4.6438881754875183e-01
    z[0,4,4]  R585      -4.9762633442878723e-01
    z[0,4,4]  R586      1.5016369521617889e-01
    z[0,4,4]  R587      -2.0167241990566254e-01
    z[0,4,4]  R588      -1.8209861218929291e-01
    z[0,4,4]  R589      2.4066562950611115e-01
    z[0,4,4]  R590      3.5273811221122742e-01
    z[0,4,4]  R591      5.6484955549240112e-01
    z[0,4,4]  R592      3.1264483928680420e-01
    z[0,4,4]  R593      2.9566618800163269e-01
    z[0,4,4]  R594      -2.4209970608353615e-02
    z[0,4,4]  R595      -2.0483043789863586e-01
    z[0,4,4]  R596      1.2161655724048615e-01
    z[0,4,4]  R597      -0.506409227848053
    z[0,4,4]  R598      -9.3269376084208488e-03
    z[0,4,4]  R599      1.2939088977873325e-02
    z[0,4,4]  R600      1.3160282373428345e-01
    z[0,4,4]  R601      -3.7997606396675110e-01
    z[0,4,4]  R602      1.3030199706554413e-01
    z[0,4,4]  R603      3.5595762729644775e-01
    z[0,4,4]  R604      -5.6280148029327393e-01
    z[0,4,4]  R605      -6.5569287538528442e-01
    z[0,4,4]  R606      1.7943548038601875e-02
    z[0,4,4]  R607      -4.4281604886054993e-01
    z[0,4,4]  R608      -9.5948047935962677e-02
    z[0,4,4]  R609      -4.3679103255271912e-01
    z[0,4,4]  R610      -8.6402416229248047e-01
    z[0,4,4]  R611      -5.1386451721191406e-01
    z[0,4,4]  R612      2.8345569968223572e-01
    z[0,4,4]  R613      -4.8353210091590881e-01
    z[0,4,4]  R614      6.9809418916702271e-01
    z[0,4,4]  R615      0.84651118516922
    z[0,4,5]  R7        -1
    z[0,4,5]  R43       1
    z[0,4,5]  R542      -1
    z[0,4,5]  R543      1
    z[0,4,5]  R546      -4.6565684676170349e-01
    z[0,4,5]  R547      -5.9288865327835083e-01
    z[0,4,5]  R548      -6.7348307371139526e-01
    z[0,4,5]  R549      -2.7893880009651184e-01
    z[0,4,5]  R550      -6.5360978245735168e-02
    z[0,4,5]  R551      -1.6454692184925079e-01
    z[0,4,5]  R552      -7.2398573160171509e-02
    z[0,4,5]  R553      0.0906539037823677
    z[0,4,5]  R554      -6.2161255627870560e-02
    z[0,4,5]  R555      -4.9832555651664734e-01
    z[0,4,5]  R556      7.1085587143898010e-02
    z[0,4,5]  R557      9.9303878843784332e-02
    z[0,4,5]  R558      1.9442611932754517e-01
    z[0,4,5]  R559      -1.3173783663660288e-03
    z[0,4,5]  R560      -1.2290755286812782e-02
    z[0,4,5]  R561      1.2302239984273911e-01
    z[0,4,5]  R562      2.0458373427391052e-01
    z[0,4,5]  R563      -0.0671120211482048
    z[0,4,5]  R564      -7.3197772726416588e-03
    z[0,4,5]  R565      1.2532912194728851e-01
    z[0,4,5]  R566      4.4835552573204041e-01
    z[0,4,5]  R567      4.6172514557838440e-01
    z[0,4,5]  R568      4.7400042414665222e-01
    z[0,4,5]  R569      2.7603101730346680e-01
    z[0,4,5]  R570      4.3709456920623779e-01
    z[0,4,5]  R571      5.8497828245162964e-01
    z[0,4,5]  R572      3.7317070364952087e-01
    z[0,4,5]  R573      1.8044155091047287e-02
    z[0,4,5]  R574      5.0306838750839233e-01
    z[0,4,5]  R575      3.6254772543907166e-01
    z[0,4,5]  R576      5.1565271615982056e-01
    z[0,4,5]  R577      6.0653075575828552e-02
    z[0,4,5]  R578      2.6133623719215393e-01
    z[0,4,5]  R579      1.4096808433532715e-01
    z[0,4,5]  R580      2.5017103180289268e-02
    z[0,4,5]  R581      2.8611651062965393e-01
    z[0,4,5]  R582      2.3158925771713257e-01
    z[0,4,5]  R583      4.9871876835823059e-01
    z[0,4,5]  R584      3.6343118548393250e-01
    z[0,4,5]  R585      4.5754191279411316e-01
    z[0,4,5]  R586      4.9972828477621078e-02
    z[0,4,5]  R587      -3.2711166143417358e-01
    z[0,4,5]  R588      1.0573945939540863e-01
    z[0,4,5]  R589      0.384998619556427
    z[0,4,5]  R590      -2.5444485247135162e-02
    z[0,4,5]  R591      -3.2719689607620239e-01
    z[0,4,5]  R592      6.6548407077789307e-01
    z[0,4,5]  R593      3.5918089747428894e-01
    z[0,4,5]  R594      -8.1948794424533844e-02
    z[0,4,5]  R595      1.1423498392105103e-02
    z[0,4,5]  R596      1.6303362324833870e-02
    z[0,4,5]  R597      0.0700659304857254
    z[0,4,5]  R598      3.2645413279533386e-01
    z[0,4,5]  R599      2.0752148702740669e-03
    z[0,4,5]  R600      -5.4658412933349609e-01
    z[0,4,5]  R601      2.6304228231310844e-02
    z[0,4,5]  R602      4.7758507728576660e-01
    z[0,4,5]  R603      3.8313046097755432e-01
    z[0,4,5]  R604      -2.2911007702350616e-01
    z[0,4,5]  R605      -3.0044120550155640e-01
    z[0,4,5]  R606      5.3282942622900009e-02
    z[0,4,5]  R607      0.546783983707428
    z[0,4,5]  R608      3.4522768855094910e-01
    z[0,4,5]  R609      -1.6942660510540009e-01
    z[0,4,5]  R610      -1.2802666425704956e-01
    z[0,4,5]  R611      -3.9604511857032776e-01
    z[0,4,5]  R612      1.8112035095691681e-01
    z[0,4,5]  R613      1.8203233182430267e-01
    z[0,4,5]  R614      -1.9573500752449036e-01
    z[0,4,5]  R615      1.5885604918003082e-01
    z[0,4,6]  R8        -1
    z[0,4,6]  R44       1
    z[0,4,6]  R544      -1
    z[0,4,6]  R545      1
    z[0,4,6]  R546      7.7819757163524628e-02
    z[0,4,6]  R547      1.6664761304855347e-01
    z[0,4,6]  R548      -2.0606763660907745e-02
    z[0,4,6]  R549      2.6358818635344505e-02
    z[0,4,6]  R550      -0.084261953830719
    z[0,4,6]  R551      4.2935600876808167e-01
    z[0,4,6]  R552      -4.5721733570098877e-01
    z[0,4,6]  R553      1.9737339019775391e-01
    z[0,4,6]  R554      3.2508898526430130e-02
    z[0,4,6]  R555      3.0719056725502014e-01
    z[0,4,6]  R556      -4.3408204801380634e-03
    z[0,4,6]  R557      1.4412012696266174e-01
    z[0,4,6]  R558      2.8908040374517441e-02
    z[0,4,6]  R559      -3.2881464809179306e-02
    z[0,4,6]  R560      0.237397700548172
    z[0,4,6]  R561      9.5143593847751617e-02
    z[0,4,6]  R562      -1.1203897744417191e-01
    z[0,4,6]  R563      0.0405583456158638
    z[0,4,6]  R564      2.0985612273216248e-01
    z[0,4,6]  R565      -4.4531369209289551e-01
    z[0,4,6]  R566      4.6910487115383148e-02
    z[0,4,6]  R567      2.4945002794265747e-01
    z[0,4,6]  R568      3.3773830533027649e-01
    z[0,4,6]  R569      -3.7616726756095886e-01
    z[0,4,6]  R570      -0.0771293193101883
    z[0,4,6]  R571      1.1005973647115752e-04
    z[0,4,6]  R572      6.0303110629320145e-02
    z[0,4,6]  R573      -2.4672379717230797e-02
    z[0,4,6]  R574      -2.8605468571186066e-02
    z[0,4,6]  R575      -4.3676221370697021e-01
    z[0,4,6]  R576      -2.8541502356529236e-01
    z[0,4,6]  R577      -2.6354700326919556e-01
    z[0,4,6]  R578      -9.7607143223285675e-02
    z[0,4,6]  R579      -1.3041138648986816e-01
    z[0,4,6]  R580      -4.3180756270885468e-02
    z[0,4,6]  R581      -3.5434693098068237e-01
    z[0,4,6]  R582      -3.6994233727455139e-02
    z[0,4,6]  R583      3.0429449677467346e-01
    z[0,4,6]  R584      1.6009826958179474e-01
    z[0,4,6]  R585      2.1410284936428070e-01
    z[0,4,6]  R586      1.6514627635478973e-01
    z[0,4,6]  R587      6.5292038023471832e-02
    z[0,4,6]  R588      -1.0161355137825012e-01
    z[0,4,6]  R589      -2.9342442750930786e-01
    z[0,4,6]  R590      1.9883975386619568e-01
    z[0,4,6]  R591      1.8315419554710388e-01
    z[0,4,6]  R592      -1.8604686483740807e-02
    z[0,4,6]  R593      5.9675145149230957e-01
    z[0,4,6]  R594      -3.7798005342483521e-01
    z[0,4,6]  R595      3.4525832533836365e-01
    z[0,4,6]  R596      -4.4347429275512695e-01
    z[0,4,6]  R597      1.9795902073383331e-01
    z[0,4,6]  R598      2.3786519467830658e-01
    z[0,4,6]  R599      2.4091006815433502e-01
    z[0,4,6]  R600      3.1069728732109070e-01
    z[0,4,6]  R601      1.4187897741794586e-01
    z[0,4,6]  R602      -3.1719669699668884e-01
    z[0,4,6]  R603      2.6061311364173889e-01
    z[0,4,6]  R604      2.4852724373340607e-01
    z[0,4,6]  R605      7.5940592214465141e-03
    z[0,4,6]  R606      4.6995532512664795e-01
    z[0,4,6]  R607      -1.1474460363388062e-01
    z[0,4,6]  R608      -1.5504789538681507e-02
    z[0,4,6]  R609      1.5785694122314453e-02
    z[0,4,6]  R610      -9.7251825034618378e-02
    z[0,4,6]  R611      5.5259648710489273e-02
    z[0,4,6]  R612      -1.8019108474254608e-01
    z[0,4,6]  R613      -1.2802480161190033e-01
    z[0,4,6]  R614      9.7086921334266663e-02
    z[0,4,6]  R615      0.328484445810318
    z[4,0,0]  R2        1
    z[4,0,0]  R38       -1
    z[4,0,0]  R616      -1
    z[4,0,0]  R617      1
    z[4,0,0]  R630      -4.3566304445266724e-01
    z[4,0,0]  R631      1.1860569566488266e-01
    z[4,0,0]  R632      -3.3444091677665710e-01
    z[4,0,0]  R633      -4.9569246172904968e-01
    z[4,0,0]  R634      -4.7821506857872009e-01
    z[4,0,0]  R635      -2.5301378965377808e-01
    z[4,0,0]  R636      0.00965464673936367
    z[4,0,0]  R637      -7.8255213797092438e-02
    z[4,0,0]  R638      1.2590855360031128e-01
    z[4,0,0]  R639      -1.0428953170776367e-01
    z[4,0,0]  R640      0.323359876871109
    z[4,0,0]  R641      3.7382391095161438e-01
    z[4,0,0]  R642      7.9257696866989136e-02
    z[4,0,0]  R643      3.5170421004295349e-01
    z[4,0,0]  R644      3.0049356818199158e-01
    z[4,0,0]  R645      7.3320543766021729e-01
    z[4,0,0]  R646      1.4527393877506256e-01
    z[4,0,0]  R647      6.4717435836791992e-01
    z[4,0,0]  R648      -1.5803582966327667e-01
    z[4,0,0]  R649      -3.5336855053901672e-01
    z[4,0,0]  R650      2.2044897079467773e-01
    z[4,0,0]  R651      0.0868205651640892
    z[4,0,0]  R652      -8.1602618098258972e-02
    z[4,0,0]  R653      2.1975185722112656e-02
    z[4,0,0]  R654      7.1332126855850220e-02
    z[4,0,0]  R655      1.3148538768291473e-01
    z[4,0,0]  R656      -5.4136735200881958e-01
    z[4,0,0]  R657      5.0642073154449463e-01
    z[4,0,0]  R658      1.5650652348995209e-01
    z[4,0,0]  R659      -1.3747981190681458e-01
    z[4,0,0]  R660      -0.595670759677887
    z[4,0,0]  R661      -3.7485894560813904e-01
    z[4,0,0]  R662      -1.8457423150539398e-01
    z[4,0,0]  R663      -5.7814240455627441e-01
    z[4,0,0]  R664      -3.1091922521591187e-01
    z[4,0,0]  R665      -4.4319561123847961e-01
    z[4,0,0]  R666      -2.9543972015380859e-01
    z[4,0,0]  R667      -4.4200652837753296e-01
    z[4,0,0]  R668      6.2063220888376236e-02
    z[4,0,0]  R669      -1.3802291452884674e-01
    z[4,0,0]  R670      1.2147828191518784e-01
    z[4,0,0]  R671      -2.9867494106292725e-01
    z[4,0,0]  R672      -3.1643894314765930e-01
    z[4,0,0]  R673      3.2006077468395233e-02
    z[4,0,0]  R674      5.8187246322631836e-02
    z[4,0,0]  R675      -2.0086118951439857e-02
    z[4,0,0]  R676      2.5060039758682251e-01
    z[4,0,0]  R677      -1.2390428036451340e-01
    z[4,0,0]  R678      -1.4783337712287903e-01
    z[4,0,0]  R679      -1.3143141567707062e-01
    z[4,0,0]  R680      5.4461634159088135e-01
    z[4,0,0]  R681      3.9418607950210571e-01
    z[4,0,0]  R682      6.1878937482833862e-01
    z[4,0,0]  R683      0.476563036441803
    z[4,0,0]  R684      7.4172264337539673e-01
    z[4,0,0]  R685      6.7241811752319336e-01
    z[4,0,0]  R686      6.4190948009490967e-01
    z[4,0,0]  R687      6.5134871006011963e-01
    z[4,0,0]  R688      1.1419311165809631e-01
    z[4,0,0]  R689      5.9473598003387451e-01
    z[4,0,0]  R690      -9.8668999969959259e-02
    z[4,0,0]  R691      6.1946451663970947e-01
    z[4,0,0]  R692      0.542599081993103
    z[4,0,0]  R693      -1.0434793680906296e-01
    z[4,0,0]  R694      3.2040235400199890e-01
    z[4,0,0]  R695      7.2470021247863770e-01
    z[4,0,0]  R696      -3.1749375630170107e-03
    z[4,0,0]  R697      3.7793529033660889e-01
    z[4,0,0]  R698      -2.0786963403224945e-01
    z[4,0,0]  R699      -1.8122604489326477e-01
    z[4,0,1]  R3        1
    z[4,0,1]  R39       -1
    z[4,0,1]  R618      -1
    z[4,0,1]  R619      1
    z[4,0,1]  R630      7.5889408588409424e-01
    z[4,0,1]  R631      7.5472515821456909e-01
    z[4,0,1]  R632      8.6888861656188965e-01
    z[4,0,1]  R633      0.603097140789032
    z[4,0,1]  R634      5.7544064521789551e-01
    z[4,0,1]  R635      0.612223744392395
    z[4,0,1]  R636      6.5207844972610474e-01
    z[4,0,1]  R637      6.4350157976150513e-01
    z[4,0,1]  R638      -8.4987187385559082e-01
    z[4,0,1]  R639      -8.2063728570938110e-01
    z[4,0,1]  R640      7.5189995765686035e-01
    z[4,0,1]  R641      4.3783202767372131e-01
    z[4,0,1]  R642      -3.8606387376785278e-01
    z[4,0,1]  R643      -2.4214853346347809e-01
    z[4,0,1]  R644      -3.1058117747306824e-01
    z[4,0,1]  R645      -2.2177360951900482e-01
    z[4,0,1]  R646      -1.5315692871809006e-02
    z[4,0,1]  R647      -3.2986709475517273e-01
    z[4,0,1]  R648      2.3476628959178925e-01
    z[4,0,1]  R649      1.9111397862434387e-01
    z[4,0,1]  R650      7.2244065999984741e-01
    z[4,0,1]  R651      5.5984967947006226e-01
    z[4,0,1]  R652      4.1613170504570007e-01
    z[4,0,1]  R653      4.0391734242439270e-01
    z[4,0,1]  R654      4.3273970484733582e-01
    z[4,0,1]  R655      3.8729482889175415e-01
    z[4,0,1]  R656      -2.0500813424587250e-01
    z[4,0,1]  R657      -6.2468174844980240e-02
    z[4,0,1]  R658      -5.0921678543090820e-02
    z[4,0,1]  R659      -3.5752475261688232e-01
    z[4,0,1]  R660      -4.4385874271392822e-01
    z[4,0,1]  R661      -4.2086270451545715e-01
    z[4,0,1]  R662      -0.529179573059082
    z[4,0,1]  R663      -4.1710504889488220e-01
    z[4,0,1]  R664      -8.6575299501419067e-01
    z[4,0,1]  R665      -0.421099990606308
    z[4,0,1]  R666      -3.9300060272216797e-01
    z[4,0,1]  R667      -3.5395517945289612e-01
    z[4,0,1]  R668      -4.0363934636116028e-01
    z[4,0,1]  R669      -7.0809775590896606e-01
    z[4,0,1]  R670      0.897419273853302
    z[4,0,1]  R671      0.900534987449646
    z[4,0,1]  R672      0.902877151966095
    z[4,0,1]  R673      9.1613984107971191e-01
    z[4,0,1]  R674      8.9577335119247437e-01
    z[4,0,1]  R675      9.3991589546203613e-01
    z[4,0,1]  R676      8.9128780364990234e-01
    z[4,0,1]  R677      8.3712917566299438e-01
    z[4,0,1]  R678      8.4881031513214111e-01
    z[4,0,1]  R679      0.816559374332428
    z[4,0,1]  R680      5.4552732035517693e-03
    z[4,0,1]  R681      2.3812660947442055e-02
    z[4,0,1]  R682      0.0827384814620018
    z[4,0,1]  R683      3.1028954312205315e-02
    z[4,0,1]  R684      5.4847251623868942e-02
    z[4,0,1]  R685      9.2687368392944336e-02
    z[4,0,1]  R686      -6.5321475267410278e-02
    z[4,0,1]  R687      1.5127401053905487e-01
    z[4,0,1]  R688      1.9041022285819054e-02
    z[4,0,1]  R689      1.1130225658416748e-01
    z[4,0,1]  R690      -5.5492192506790161e-01
    z[4,0,1]  R691      -6.6467088460922241e-01
    z[4,0,1]  R692      -5.6200414896011353e-01
    z[4,0,1]  R693      -1.8602198362350464e-01
    z[4,0,1]  R694      -2.4653628468513489e-01
    z[4,0,1]  R695      3.1718581914901733e-01
    z[4,0,1]  R696      2.8134384751319885e-01
    z[4,0,1]  R697      -4.3276441097259521e-01
    z[4,0,1]  R698      -9.6648633480072021e-02
    z[4,0,1]  R699      6.7415893077850342e-02
    z[4,0,2]  R4        1
    z[4,0,2]  R40       -1
    z[4,0,2]  R620      -1
    z[4,0,2]  R621      1
    z[4,0,2]  R630      1.1177688837051392e-01
    z[4,0,2]  R631      -4.3407250195741653e-02
    z[4,0,2]  R632      3.0480053275823593e-02
    z[4,0,2]  R633      3.0818262696266174e-01
    z[4,0,2]  R634      4.3888410925865173e-01
    z[4,0,2]  R635      -6.2086533755064011e-02
    z[4,0,2]  R636      1.2212823331356049e-01
    z[4,0,2]  R637      -7.3171287775039673e-02
    z[4,0,2]  R638      3.2754510641098022e-01
    z[4,0,2]  R639      -2.2392237558960915e-02
    z[4,0,2]  R640      3.8310687988996506e-02
    z[4,0,2]  R641      3.6883878707885742e-01
    z[4,0,2]  R642      -1.6428200900554657e-01
    z[4,0,2]  R643      -2.7812442183494568e-01
    z[4,0,2]  R644      -2.9574507474899292e-01
    z[4,0,2]  R645      -2.9847124218940735e-01
    z[4,0,2]  R646      2.7253448963165283e-01
    z[4,0,2]  R647      -2.4370205402374268e-01
    z[4,0,2]  R648      -0.265984445810318
    z[4,0,2]  R649      -6.4389117062091827e-02
    z[4,0,2]  R650      -4.4989919662475586e-01
    z[4,0,2]  R651      -7.8759752213954926e-02
    z[4,0,2]  R652      -1.0610629618167877e-01
    z[4,0,2]  R653      0.192478746175766
    z[4,0,2]  R654      -1.1112035065889359e-01
    z[4,0,2]  R655      5.6924498081207275e-01
    z[4,0,2]  R656      3.7033399939537048e-01
    z[4,0,2]  R657      8.6332149803638458e-03
    z[4,0,2]  R658      1.4917572028934956e-02
    z[4,0,2]  R659      -4.1301719844341278e-02
    z[4,0,2]  R660      -2.8671988844871521e-01
    z[4,0,2]  R661      -5.0583446025848389e-01
    z[4,0,2]  R662      -3.8096874952316284e-01
    z[4,0,2]  R663      -5.9246593713760376e-01
    z[4,0,2]  R664      -1.7986467480659485e-01
    z[4,0,2]  R665      -6.2425899505615234e-01
    z[4,0,2]  R666      -6.4657533168792725e-01
    z[4,0,2]  R667      -7.8528332710266113e-01
    z[4,0,2]  R668      -8.7665939331054688e-01
    z[4,0,2]  R669      -2.3562364280223846e-02
    z[4,0,2]  R670      -4.1183501482009888e-01
    z[4,0,2]  R671      -2.5626808404922485e-01
    z[4,0,2]  R672      2.5473069399595261e-02
    z[4,0,2]  R673      1.6784700751304626e-01
    z[4,0,2]  R674      -1.3380204141139984e-01
    z[4,0,2]  R675      1.6160102188587189e-01
    z[4,0,2]  R676      5.1723778247833252e-02
    z[4,0,2]  R677      -2.8242358565330505e-01
    z[4,0,2]  R678      4.5180737972259521e-01
    z[4,0,2]  R679      -1.1835354566574097e-01
    z[4,0,2]  R680      5.9386283159255981e-01
    z[4,0,2]  R681      6.9971585273742676e-01
    z[4,0,2]  R682      3.7243339419364929e-01
    z[4,0,2]  R683      6.2867981195449829e-01
    z[4,0,2]  R684      3.7749308347702026e-01
    z[4,0,2]  R685      2.9669496417045593e-01
    z[4,0,2]  R686      5.3719258308410645e-01
    z[4,0,2]  R687      6.7282044887542725e-01
    z[4,0,2]  R688      5.3101140260696411e-01
    z[4,0,2]  R689      2.5265955924987793e-01
    z[4,0,2]  R690      2.2434255480766296e-01
    z[4,0,2]  R691      -2.5789499282836914e-01
    z[4,0,2]  R692      4.0086638927459717e-01
    z[4,0,2]  R693      8.4713113307952881e-01
    z[4,0,2]  R694      2.7665188908576965e-01
    z[4,0,2]  R695      0.373761922121048
    z[4,0,2]  R696      9.2212641239166260e-01
    z[4,0,2]  R697      2.0049897953867912e-02
    z[4,0,2]  R698      1.0363273322582245e-01
    z[4,0,2]  R699      -5.5132254958152771e-02
    z[4,0,3]  R5        1
    z[4,0,3]  R41       -1
    z[4,0,3]  R622      -1
    z[4,0,3]  R623      1
    z[4,0,3]  R630      -4.1165980696678162e-01
    z[4,0,3]  R631      -0.512349009513855
    z[4,0,3]  R632      -2.7854391932487488e-01
    z[4,0,3]  R633      5.7831909507513046e-02
    z[4,0,3]  R634      2.8801107406616211e-01
    z[4,0,3]  R635      3.1249490380287170e-01
    z[4,0,3]  R636      1.3719774782657623e-01
    z[4,0,3]  R637      4.3428402394056320e-02
    z[4,0,3]  R638      -6.6395789384841919e-02
    z[4,0,3]  R639      -3.9228478074073792e-01
    z[4,0,3]  R640      3.4189349412918091e-01
    z[4,0,3]  R641      4.8163211345672607e-01
    z[4,0,3]  R642      8.0897784233093262e-01
    z[4,0,3]  R643      8.2589679956436157e-01
    z[4,0,3]  R644      5.5961722135543823e-01
    z[4,0,3]  R645      3.9866998791694641e-01
    z[4,0,3]  R646      -7.4746638536453247e-01
    z[4,0,3]  R647      2.6748523116111755e-01
    z[4,0,3]  R648      0.646652102470398
    z[4,0,3]  R649      5.6053936481475830e-01
    z[4,0,3]  R650      5.5258788168430328e-02
    z[4,0,3]  R651      4.0571206808090210e-01
    z[4,0,3]  R652      8.2479590177536011e-01
    z[4,0,3]  R653      7.6130068302154541e-01
    z[4,0,3]  R654      1.5137337148189545e-01
    z[4,0,3]  R655      2.9105362296104431e-01
    z[4,0,3]  R656      -6.1816269159317017e-01
    z[4,0,3]  R657      -6.7544937133789062e-01
    z[4,0,3]  R658      -6.6152596473693848e-01
    z[4,0,3]  R659      4.3023351579904556e-02
    z[4,0,3]  R660      4.4222053140401840e-02
    z[4,0,3]  R661      -1.3470019400119781e-01
    z[4,0,3]  R662      -2.8704026341438293e-01
    z[4,0,3]  R663      -2.4648956954479218e-01
    z[4,0,3]  R664      -1.8796291947364807e-01
    z[4,0,3]  R665      1.4601151645183563e-01
    z[4,0,3]  R666      -9.7074195742607117e-02
    z[4,0,3]  R667      1.0145763307809830e-01
    z[4,0,3]  R668      -1.6864429414272308e-01
    z[4,0,3]  R669      0.300178587436676
    z[4,0,3]  R670      -7.0722915232181549e-02
    z[4,0,3]  R671      1.2170047499239445e-02
    z[4,0,3]  R672      -1.6872355341911316e-01
    z[4,0,3]  R673      -3.0889034271240234e-01
    z[4,0,3]  R674      3.1220692396163940e-01
    z[4,0,3]  R675      7.3165573179721832e-02
    z[4,0,3]  R676      2.8877484798431396e-01
    z[4,0,3]  R677      1.8450444936752319e-01
    z[4,0,3]  R678      8.5690997540950775e-02
    z[4,0,3]  R679      1.0713714361190796e-01
    z[4,0,3]  R680      -3.2739424705505371e-01
    z[4,0,3]  R681      -2.7972236275672913e-01
    z[4,0,3]  R682      -3.1490191817283630e-01
    z[4,0,3]  R683      -3.8572177290916443e-01
    z[4,0,3]  R684      -2.3742128908634186e-01
    z[4,0,3]  R685      -2.8748938441276550e-01
    z[4,0,3]  R686      -2.8587976098060608e-01
    z[4,0,3]  R687      -2.6113662123680115e-01
    z[4,0,3]  R688      -5.4309302568435669e-01
    z[4,0,3]  R689      -4.2717960476875305e-01
    z[4,0,3]  R690      4.9050047993659973e-01
    z[4,0,3]  R691      1.6774599254131317e-01
    z[4,0,3]  R692      3.5282951593399048e-01
    z[4,0,3]  R693      -4.4394549727439880e-01
    z[4,0,3]  R694      -8.7034332752227783e-01
    z[4,0,3]  R695      1.5707907080650330e-01
    z[4,0,3]  R696      7.1136265993118286e-02
    z[4,0,3]  R697      3.0250164866447449e-01
    z[4,0,3]  R698      -7.5055903196334839e-01
    z[4,0,3]  R699      -6.7583733797073364e-01
    z[4,0,4]  R6        1
    z[4,0,4]  R42       -1
    z[4,0,4]  R624      -1
    z[4,0,4]  R625      1
    z[4,0,4]  R630      1.5016369521617889e-01
    z[4,0,4]  R631      -2.0167241990566254e-01
    z[4,0,4]  R632      -1.8209861218929291e-01
    z[4,0,4]  R633      2.4066562950611115e-01
    z[4,0,4]  R634      3.5273811221122742e-01
    z[4,0,4]  R635      5.6484955549240112e-01
    z[4,0,4]  R636      3.1264483928680420e-01
    z[4,0,4]  R637      2.9566618800163269e-01
    z[4,0,4]  R638      -2.4209970608353615e-02
    z[4,0,4]  R639      -2.0483043789863586e-01
    z[4,0,4]  R640      1.2161655724048615e-01
    z[4,0,4]  R641      -0.506409227848053
    z[4,0,4]  R642      -9.3269376084208488e-03
    z[4,0,4]  R643      1.2939088977873325e-02
    z[4,0,4]  R644      1.3160282373428345e-01
    z[4,0,4]  R645      -3.7997606396675110e-01
    z[4,0,4]  R646      1.3030199706554413e-01
    z[4,0,4]  R647      3.5595762729644775e-01
    z[4,0,4]  R648      -5.6280148029327393e-01
    z[4,0,4]  R649      -6.5569287538528442e-01
    z[4,0,4]  R650      1.7943548038601875e-02
    z[4,0,4]  R651      -4.4281604886054993e-01
    z[4,0,4]  R652      -9.5948047935962677e-02
    z[4,0,4]  R653      -4.3679103255271912e-01
    z[4,0,4]  R654      -8.6402416229248047e-01
    z[4,0,4]  R655      -5.1386451721191406e-01
    z[4,0,4]  R656      2.8345569968223572e-01
    z[4,0,4]  R657      -4.8353210091590881e-01
    z[4,0,4]  R658      6.9809418916702271e-01
    z[4,0,4]  R659      0.84651118516922
    z[4,0,4]  R660      -3.7564572691917419e-01
    z[4,0,4]  R661      -1.7045332491397858e-01
    z[4,0,4]  R662      -6.6091604530811310e-02
    z[4,0,4]  R663      -3.8730047643184662e-02
    z[4,0,4]  R664      2.7339997887611389e-01
    z[4,0,4]  R665      -0.0617363266646862
    z[4,0,4]  R666      -3.4131160378456116e-01
    z[4,0,4]  R667      -7.2167210280895233e-02
    z[4,0,4]  R668      1.7700275778770447e-01
    z[4,0,4]  R669      -2.1491970121860504e-01
    z[4,0,4]  R670      1.4138107188045979e-02
    z[4,0,4]  R671      5.8108780533075333e-02
    z[4,0,4]  R672      1.3009758293628693e-01
    z[4,0,4]  R673      1.8706850707530975e-01
    z[4,0,4]  R674      1.4939698576927185e-01
    z[4,0,4]  R675      -2.4596697092056274e-01
    z[4,0,4]  R676      4.8291280865669250e-02
    z[4,0,4]  R677      -4.0485617518424988e-01
    z[4,0,4]  R678      -4.5830491930246353e-02
    z[4,0,4]  R679      2.7651217579841614e-01
    z[4,0,4]  R680      2.0069877803325653e-01
    z[4,0,4]  R681      -2.8072007000446320e-02
    z[4,0,4]  R682      1.8341344594955444e-01
    z[4,0,4]  R683      -1.0104627162218094e-01
    z[4,0,4]  R684      -2.2576268017292023e-01
    z[4,0,4]  R685      -1.6243544220924377e-01
    z[4,0,4]  R686      -2.6549813151359558e-01
    z[4,0,4]  R687      -1.7620180547237396e-01
    z[4,0,4]  R688      3.9468744397163391e-01
    z[4,0,4]  R689      -2.5569441914558411e-01
    z[4,0,4]  R690      -2.0987190306186676e-01
    z[4,0,4]  R691      8.1804707646369934e-02
    z[4,0,4]  R692      1.6349682211875916e-01
    z[4,0,4]  R693      -5.3939230740070343e-02
    z[4,0,4]  R694      6.1589833348989487e-03
    z[4,0,4]  R695      -4.9056809395551682e-02
    z[4,0,4]  R696      1.0225493460893631e-01
    z[4,0,4]  R697      4.8647204041481018e-01
    z[4,0,4]  R698      -4.6438881754875183e-01
    z[4,0,4]  R699      -4.9762633442878723e-01
    z[4,0,5]  R7        1
    z[4,0,5]  R43       -1
    z[4,0,5]  R626      -1
    z[4,0,5]  R627      1
    z[4,0,5]  R630      4.9972828477621078e-02
    z[4,0,5]  R631      -3.2711166143417358e-01
    z[4,0,5]  R632      1.0573945939540863e-01
    z[4,0,5]  R633      0.384998619556427
    z[4,0,5]  R634      -2.5444485247135162e-02
    z[4,0,5]  R635      -3.2719689607620239e-01
    z[4,0,5]  R636      6.6548407077789307e-01
    z[4,0,5]  R637      3.5918089747428894e-01
    z[4,0,5]  R638      -8.1948794424533844e-02
    z[4,0,5]  R639      1.1423498392105103e-02
    z[4,0,5]  R640      1.6303362324833870e-02
    z[4,0,5]  R641      0.0700659304857254
    z[4,0,5]  R642      3.2645413279533386e-01
    z[4,0,5]  R643      2.0752148702740669e-03
    z[4,0,5]  R644      -5.4658412933349609e-01
    z[4,0,5]  R645      2.6304228231310844e-02
    z[4,0,5]  R646      4.7758507728576660e-01
    z[4,0,5]  R647      3.8313046097755432e-01
    z[4,0,5]  R648      -2.2911007702350616e-01
    z[4,0,5]  R649      -3.0044120550155640e-01
    z[4,0,5]  R650      5.3282942622900009e-02
    z[4,0,5]  R651      0.546783983707428
    z[4,0,5]  R652      3.4522768855094910e-01
    z[4,0,5]  R653      -1.6942660510540009e-01
    z[4,0,5]  R654      -1.2802666425704956e-01
    z[4,0,5]  R655      -3.9604511857032776e-01
    z[4,0,5]  R656      1.8112035095691681e-01
    z[4,0,5]  R657      1.8203233182430267e-01
    z[4,0,5]  R658      -1.9573500752449036e-01
    z[4,0,5]  R659      1.5885604918003082e-01
    z[4,0,5]  R660      -4.6565684676170349e-01
    z[4,0,5]  R661      -5.9288865327835083e-01
    z[4,0,5]  R662      -6.7348307371139526e-01
    z[4,0,5]  R663      -2.7893880009651184e-01
    z[4,0,5]  R664      -6.5360978245735168e-02
    z[4,0,5]  R665      -1.6454692184925079e-01
    z[4,0,5]  R666      -7.2398573160171509e-02
    z[4,0,5]  R667      0.0906539037823677
    z[4,0,5]  R668      -6.2161255627870560e-02
    z[4,0,5]  R669      -4.9832555651664734e-01
    z[4,0,5]  R670      7.1085587143898010e-02
    z[4,0,5]  R671      9.9303878843784332e-02
    z[4,0,5]  R672      1.9442611932754517e-01
    z[4,0,5]  R673      -1.3173783663660288e-03
    z[4,0,5]  R674      -1.2290755286812782e-02
    z[4,0,5]  R675      1.2302239984273911e-01
    z[4,0,5]  R676      2.0458373427391052e-01
    z[4,0,5]  R677      -0.0671120211482048
    z[4,0,5]  R678      -7.3197772726416588e-03
    z[4,0,5]  R679      1.2532912194728851e-01
    z[4,0,5]  R680      4.4835552573204041e-01
    z[4,0,5]  R681      4.6172514557838440e-01
    z[4,0,5]  R682      4.7400042414665222e-01
    z[4,0,5]  R683      2.7603101730346680e-01
    z[4,0,5]  R684      4.3709456920623779e-01
    z[4,0,5]  R685      5.8497828245162964e-01
    z[4,0,5]  R686      3.7317070364952087e-01
    z[4,0,5]  R687      1.8044155091047287e-02
    z[4,0,5]  R688      5.0306838750839233e-01
    z[4,0,5]  R689      3.6254772543907166e-01
    z[4,0,5]  R690      5.1565271615982056e-01
    z[4,0,5]  R691      6.0653075575828552e-02
    z[4,0,5]  R692      2.6133623719215393e-01
    z[4,0,5]  R693      1.4096808433532715e-01
    z[4,0,5]  R694      2.5017103180289268e-02
    z[4,0,5]  R695      2.8611651062965393e-01
    z[4,0,5]  R696      2.3158925771713257e-01
    z[4,0,5]  R697      4.9871876835823059e-01
    z[4,0,5]  R698      3.6343118548393250e-01
    z[4,0,5]  R699      4.5754191279411316e-01
    z[4,0,6]  R8        1
    z[4,0,6]  R44       -1
    z[4,0,6]  R628      -1
    z[4,0,6]  R629      1
    z[4,0,6]  R630      1.6514627635478973e-01
    z[4,0,6]  R631      6.5292038023471832e-02
    z[4,0,6]  R632      -1.0161355137825012e-01
    z[4,0,6]  R633      -2.9342442750930786e-01
    z[4,0,6]  R634      1.9883975386619568e-01
    z[4,0,6]  R635      1.8315419554710388e-01
    z[4,0,6]  R636      -1.8604686483740807e-02
    z[4,0,6]  R637      5.9675145149230957e-01
    z[4,0,6]  R638      -3.7798005342483521e-01
    z[4,0,6]  R639      3.4525832533836365e-01
    z[4,0,6]  R640      -4.4347429275512695e-01
    z[4,0,6]  R641      1.9795902073383331e-01
    z[4,0,6]  R642      2.3786519467830658e-01
    z[4,0,6]  R643      2.4091006815433502e-01
    z[4,0,6]  R644      3.1069728732109070e-01
    z[4,0,6]  R645      1.4187897741794586e-01
    z[4,0,6]  R646      -3.1719669699668884e-01
    z[4,0,6]  R647      2.6061311364173889e-01
    z[4,0,6]  R648      2.4852724373340607e-01
    z[4,0,6]  R649      7.5940592214465141e-03
    z[4,0,6]  R650      4.6995532512664795e-01
    z[4,0,6]  R651      -1.1474460363388062e-01
    z[4,0,6]  R652      -1.5504789538681507e-02
    z[4,0,6]  R653      1.5785694122314453e-02
    z[4,0,6]  R654      -9.7251825034618378e-02
    z[4,0,6]  R655      5.5259648710489273e-02
    z[4,0,6]  R656      -1.8019108474254608e-01
    z[4,0,6]  R657      -1.2802480161190033e-01
    z[4,0,6]  R658      9.7086921334266663e-02
    z[4,0,6]  R659      0.328484445810318
    z[4,0,6]  R660      7.7819757163524628e-02
    z[4,0,6]  R661      1.6664761304855347e-01
    z[4,0,6]  R662      -2.0606763660907745e-02
    z[4,0,6]  R663      2.6358818635344505e-02
    z[4,0,6]  R664      -0.084261953830719
    z[4,0,6]  R665      4.2935600876808167e-01
    z[4,0,6]  R666      -4.5721733570098877e-01
    z[4,0,6]  R667      1.9737339019775391e-01
    z[4,0,6]  R668      3.2508898526430130e-02
    z[4,0,6]  R669      3.0719056725502014e-01
    z[4,0,6]  R670      -4.3408204801380634e-03
    z[4,0,6]  R671      1.4412012696266174e-01
    z[4,0,6]  R672      2.8908040374517441e-02
    z[4,0,6]  R673      -3.2881464809179306e-02
    z[4,0,6]  R674      0.237397700548172
    z[4,0,6]  R675      9.5143593847751617e-02
    z[4,0,6]  R676      -1.1203897744417191e-01
    z[4,0,6]  R677      0.0405583456158638
    z[4,0,6]  R678      2.0985612273216248e-01
    z[4,0,6]  R679      -4.4531369209289551e-01
    z[4,0,6]  R680      4.6910487115383148e-02
    z[4,0,6]  R681      2.4945002794265747e-01
    z[4,0,6]  R682      3.3773830533027649e-01
    z[4,0,6]  R683      -3.7616726756095886e-01
    z[4,0,6]  R684      -0.0771293193101883
    z[4,0,6]  R685      1.1005973647115752e-04
    z[4,0,6]  R686      6.0303110629320145e-02
    z[4,0,6]  R687      -2.4672379717230797e-02
    z[4,0,6]  R688      -2.8605468571186066e-02
    z[4,0,6]  R689      -4.3676221370697021e-01
    z[4,0,6]  R690      -2.8541502356529236e-01
    z[4,0,6]  R691      -2.6354700326919556e-01
    z[4,0,6]  R692      -9.7607143223285675e-02
    z[4,0,6]  R693      -1.3041138648986816e-01
    z[4,0,6]  R694      -4.3180756270885468e-02
    z[4,0,6]  R695      -3.5434693098068237e-01
    z[4,0,6]  R696      -3.6994233727455139e-02
    z[4,0,6]  R697      3.0429449677467346e-01
    z[4,0,6]  R698      1.6009826958179474e-01
    z[4,0,6]  R699      2.1410284936428070e-01
    z[1,2,0]  R11       -1
    z[1,2,0]  R20       1
    z[1,2,0]  R754      -1
    z[1,2,0]  R755      1
    z[1,2,0]  R768      1.0424977540969849e-01
    z[1,2,0]  R769      4.5252549648284912e-01
    z[1,2,0]  R770      0.0661509558558464
    z[1,2,0]  R771      2.8299051523208618e-01
    z[1,2,0]  R772      1.2149226665496826e-01
    z[1,2,0]  R773      0.612120509147644
    z[1,2,0]  R774      6.7033219337463379e-01
    z[1,2,0]  R775      1.5490005910396576e-01
    z[1,2,0]  R776      2.8226104378700256e-01
    z[1,2,0]  R777      -2.4477690458297729e-01
    z[1,2,0]  R778      -3.3862102031707764e-01
    z[1,2,0]  R779      -2.5495833158493042e-01
    z[1,2,0]  R780      -8.7855964899063110e-02
    z[1,2,0]  R781      -3.8494125008583069e-01
    z[1,2,0]  R782      9.0316146612167358e-02
    z[1,2,0]  R783      -1.0013429075479507e-01
    z[1,2,0]  R784      -2.1069069206714630e-01
    z[1,2,0]  R785      -2.3835390806198120e-01
    z[1,2,0]  R786      -8.9270561933517456e-02
    z[1,2,0]  R787      -1.3217581808567047e-01
    z[1,2,0]  R788      -5.6992095708847046e-01
    z[1,2,0]  R789      2.1340602636337280e-01
    z[1,2,0]  R790      3.7517610192298889e-01
    z[1,2,0]  R791      -7.1401357650756836e-02
    z[1,2,0]  R792      -1.5552681684494019e-01
    z[1,2,0]  R793      -3.3658319711685181e-01
    z[1,2,0]  R794      -3.7117803096771240e-01
    z[1,2,0]  R795      2.5435557961463928e-01
    z[1,2,0]  R796      -1.4337022602558136e-01
    z[1,2,0]  R797      3.9398744702339172e-02
    z[1,2,0]  R798      1.0379552096128464e-01
    z[1,2,0]  R799      -6.4998644590377808e-01
    z[1,2,0]  R800      -7.4237370491027832e-01
    z[1,2,0]  R801      -0.0773012712597847
    z[1,2,0]  R802      -0.246307834982872
    z[1,2,0]  R803      -1.4701296389102936e-01
    z[1,2,0]  R804      4.7910723835229874e-02
    z[1,2,0]  R805      -1.6824087128043175e-02
    z[1,2,0]  R806      3.1259888410568237e-01
    z[1,2,0]  R807      1.6191582381725311e-01
    z[1,2,0]  R808      3.7873715162277222e-01
    z[1,2,0]  R809      5.3333443403244019e-01
    z[1,2,0]  R810      6.8667048215866089e-01
    z[1,2,0]  R811      -1.4450901746749878e-01
    z[1,2,0]  R812      6.8553018569946289e-01
    z[1,2,0]  R813      6.5093624591827393e-01
    z[1,2,0]  R814      7.6829367876052856e-01
    z[1,2,0]  R815      5.8579719066619873e-01
    z[1,2,0]  R816      -0.367805153131485
    z[1,2,0]  R817      1.2440484762191772e-01
    z[1,2,0]  R818      7.8678119182586670e-01
    z[1,2,0]  R819      6.4782553911209106e-01
    z[1,2,0]  R820      7.5260007381439209e-01
    z[1,2,0]  R821      6.2868463993072510e-01
    z[1,2,0]  R822      6.5628039836883545e-01
    z[1,2,0]  R823      7.3745173215866089e-01
    z[1,2,0]  R824      7.6738870143890381e-01
    z[1,2,0]  R825      5.6793701648712158e-01
    z[1,2,0]  R826      7.0700442790985107e-01
    z[1,2,0]  R827      5.2821296453475952e-01
    z[1,2,0]  R828      -5.5435019731521606e-01
    z[1,2,0]  R829      -1.3739745318889618e-01
    z[1,2,0]  R830      -2.4997992813587189e-01
    z[1,2,0]  R831      -9.3141689896583557e-02
    z[1,2,0]  R832      -3.6504247784614563e-01
    z[1,2,0]  R833      -1.8392980098724365e-01
    z[1,2,0]  R834      -2.9985910654067993e-01
    z[1,2,0]  R835      -1.4240592718124390e-01
    z[1,2,0]  R836      -1.1798799037933350e-01
    z[1,2,0]  R837      -8.4018073976039886e-02
    z[1,2,0]  R838      2.7113190293312073e-01
    z[1,2,0]  R839      7.4907368421554565e-01
    z[1,2,0]  R840      -6.4337062835693359e-01
    z[1,2,0]  R841      5.5352133512496948e-01
    z[1,2,0]  R842      -8.7810635566711426e-01
    z[1,2,0]  R843      -8.5123598575592041e-01
    z[1,2,0]  R844      -7.8212362527847290e-01
    z[1,2,0]  R845      -7.1261632442474365e-01
    z[1,2,0]  R846      -8.3282917737960815e-01
    z[1,2,0]  R847      -8.2556849718093872e-01
    z[1,2,0]  R848      -8.3808355033397675e-02
    z[1,2,0]  R849      -6.3356541097164154e-02
    z[1,2,0]  R850      1.9311730563640594e-01
    z[1,2,0]  R851      1.9144977629184723e-01
    z[1,2,0]  R852      -9.8120421171188354e-02
    z[1,2,0]  R853      -6.7651188373565674e-01
    z[1,2,0]  R854      7.1136116981506348e-01
    z[1,2,0]  R855      5.4982852935791016e-01
    z[1,2,0]  R856      -0.673531174659729
    z[1,2,0]  R857      5.1509976387023926e-01
    z[1,2,0]  R858      -5.5446839332580566e-01
    z[1,2,0]  R859      -6.9315418601036072e-02
    z[1,2,0]  R860      3.8593227509409189e-03
    z[1,2,0]  R861      3.5450258851051331e-01
    z[1,2,0]  R862      -1.2340407073497772e-01
    z[1,2,0]  R863      -4.0811732411384583e-02
    z[1,2,0]  R864      -2.8628918528556824e-01
    z[1,2,0]  R865      4.2757335305213928e-01
    z[1,2,0]  R866      -2.9277181625366211e-01
    z[1,2,0]  R867      6.0205173492431641e-01
    z[1,2,0]  R868      -4.4183117151260376e-01
    z[1,2,0]  R869      3.0860555171966553e-01
    z[1,2,0]  R870      -1.1031243205070496e-01
    z[1,2,0]  R871      -1.3681454956531525e-01
    z[1,2,0]  R872      5.8535623550415039e-01
    z[1,2,0]  R873      -8.4071463346481323e-01
    z[1,2,0]  R874      -7.9630863666534424e-01
    z[1,2,0]  R875      -7.1491372585296631e-01
    z[1,2,0]  R876      6.0217022895812988e-02
    z[1,2,0]  R877      -1.7587128281593323e-01
    z[1,2,1]  R12       -1
    z[1,2,1]  R21       1
    z[1,2,1]  R756      -1
    z[1,2,1]  R757      1
    z[1,2,1]  R768      -0.696075439453125
    z[1,2,1]  R769      -7.3556423187255859e-01
    z[1,2,1]  R770      -9.5174181461334229e-01
    z[1,2,1]  R771      -0.581727147102356
    z[1,2,1]  R772      -5.2499836683273315e-01
    z[1,2,1]  R773      -6.1543524265289307e-01
    z[1,2,1]  R774      4.6398368477821350e-01
    z[1,2,1]  R775      -4.8562464118003845e-01
    z[1,2,1]  R776      -6.1472445726394653e-01
    z[1,2,1]  R777      -5.4373896121978760e-01
    z[1,2,1]  R778      8.3149868249893188e-01
    z[1,2,1]  R779      8.1795817613601685e-01
    z[1,2,1]  R780      0.6903116106987
    z[1,2,1]  R781      0.792568564414978
    z[1,2,1]  R782      0.64494389295578
    z[1,2,1]  R783      7.9558509588241577e-01
    z[1,2,1]  R784      6.4291751384735107e-01
    z[1,2,1]  R785      0.771367609500885
    z[1,2,1]  R786      7.0715421438217163e-01
    z[1,2,1]  R787      7.5815582275390625e-01
    z[1,2,1]  R788      -5.4785811901092529e-01
    z[1,2,1]  R789      8.1614577770233154e-01
    z[1,2,1]  R790      7.5626271963119507e-01
    z[1,2,1]  R791      8.7774705886840820e-01
    z[1,2,1]  R792      8.7240421772003174e-01
    z[1,2,1]  R793      0.694605827331543
    z[1,2,1]  R794      6.6287875175476074e-01
    z[1,2,1]  R795      6.1518836021423340e-01
    z[1,2,1]  R796      7.2351044416427612e-01
    z[1,2,1]  R797      5.7182258367538452e-01
    z[1,2,1]  R798      -2.3990131914615631e-01
    z[1,2,1]  R799      -5.1171648502349854e-01
    z[1,2,1]  R800      -4.2025437951087952e-01
    z[1,2,1]  R801      8.1895691156387329e-01
    z[1,2,1]  R802      9.4919794797897339e-01
    z[1,2,1]  R803      7.5719106197357178e-01
    z[1,2,1]  R804      9.1465157270431519e-01
    z[1,2,1]  R805      8.3162802457809448e-01
    z[1,2,1]  R806      -2.9651984572410583e-01
    z[1,2,1]  R807      -3.0413705110549927e-01
    z[1,2,1]  R808      5.2845132350921631e-01
    z[1,2,1]  R809      4.2615747451782227e-01
    z[1,2,1]  R810      4.8639130592346191e-01
    z[1,2,1]  R811      3.4531673789024353e-01
    z[1,2,1]  R812      5.2249819040298462e-01
    z[1,2,1]  R813      4.6735259890556335e-01
    z[1,2,1]  R814      3.0830904841423035e-01
    z[1,2,1]  R815      4.4670420885086060e-01
    z[1,2,1]  R816      1.5149046480655670e-01
    z[1,2,1]  R817      4.2348146438598633e-01
    z[1,2,1]  R818      -3.6520402878522873e-02
    z[1,2,1]  R819      -0.224799245595932
    z[1,2,1]  R820      -1.0453260689973831e-01
    z[1,2,1]  R821      -3.3511823415756226e-01
    z[1,2,1]  R822      -4.3470478057861328e-01
    z[1,2,1]  R823      -3.2897549867630005e-01
    z[1,2,1]  R824      -2.3882986605167389e-01
    z[1,2,1]  R825      -1.6404964029788971e-01
    z[1,2,1]  R826      -1.0996983945369720e-01
    z[1,2,1]  R827      -2.9862865805625916e-01
    z[1,2,1]  R828      -5.4568356275558472e-01
    z[1,2,1]  R829      -8.4708386659622192e-01
    z[1,2,1]  R830      -8.1526309251785278e-01
    z[1,2,1]  R831      -0.789399266242981
    z[1,2,1]  R832      -7.7593863010406494e-01
    z[1,2,1]  R833      -7.4482750892639160e-01
    z[1,2,1]  R834      -8.4712529182434082e-01
    z[1,2,1]  R835      -9.3157833814620972e-01
    z[1,2,1]  R836      -7.7176654338836670e-01
    z[1,2,1]  R837      -6.6648370027542114e-01
    z[1,2,1]  R838      -6.1783152818679810e-01
    z[1,2,1]  R839      -2.4491614103317261e-01
    z[1,2,1]  R840      -1.6888128221035004e-01
    z[1,2,1]  R841      -1.6578610241413116e-01
    z[1,2,1]  R842      2.6889970898628235e-01
    z[1,2,1]  R843      2.4984259903430939e-01
    z[1,2,1]  R844      3.6712694168090820e-01
    z[1,2,1]  R845      -1.5047702193260193e-01
    z[1,2,1]  R846      1.4627382159233093e-01
    z[1,2,1]  R847      3.1788122653961182e-01
    z[1,2,1]  R848      -0.197486013174057
    z[1,2,1]  R849      -3.3985349535942078e-01
    z[1,2,1]  R850      -7.9830235242843628e-01
    z[1,2,1]  R851      -6.9575464725494385e-01
    z[1,2,1]  R852      -5.6621932983398438e-01
    z[1,2,1]  R853      -1.0993305593729019e-01
    z[1,2,1]  R854      -4.2058369517326355e-01
    z[1,2,1]  R855      -3.0809995532035828e-01
    z[1,2,1]  R856      -3.2287931442260742e-01
    z[1,2,1]  R857      9.9301591515541077e-02
    z[1,2,1]  R858      -1.1832910031080246e-01
    z[1,2,1]  R859      -8.4441047906875610e-01
    z[1,2,1]  R860      -7.1961444616317749e-01
    z[1,2,1]  R861      -7.5381666421890259e-01
    z[1,2,1]  R862      -6.3448148965835571e-01
    z[1,2,1]  R863      -7.9383903741836548e-01
    z[1,2,1]  R864      -5.0873693078756332e-02
    z[1,2,1]  R865      -1.2915693223476410e-01
    z[1,2,1]  R866      -2.4370776116847992e-01
    z[1,2,1]  R867      6.2591084279119968e-03
    z[1,2,1]  R868      7.5826406478881836e-02
    z[1,2,1]  R869      -7.9278451204299927e-01
    z[1,2,1]  R870      -8.7493056058883667e-01
    z[1,2,1]  R871      -6.6701400279998779e-01
    z[1,2,1]  R872      -1.5493483841419220e-01
    z[1,2,1]  R873      4.1146323084831238e-01
    z[1,2,1]  R874      1.9942082464694977e-01
    z[1,2,1]  R875      4.1929177939891815e-02
    z[1,2,1]  R876      -3.8080174475908279e-02
    z[1,2,1]  R877      0.551843523979187
    z[1,2,2]  R13       -1
    z[1,2,2]  R22       1
    z[1,2,2]  R758      -1
    z[1,2,2]  R759      1
    z[1,2,2]  R768      1.7765846848487854e-01
    z[1,2,2]  R769      -1.4813593029975891e-01
    z[1,2,2]  R770      -6.0631740838289261e-02
    z[1,2,2]  R771      7.0911563932895660e-02
    z[1,2,2]  R772      -2.7264159917831421e-01
    z[1,2,2]  R773      -2.3721061646938324e-01
    z[1,2,2]  R774      -1.1788218468427658e-01
    z[1,2,2]  R775      -3.7549829483032227e-01
    z[1,2,2]  R776      -1.2550555169582367e-01
    z[1,2,2]  R777      -1.3326528668403625e-01
    z[1,2,2]  R778      -6.1995391733944416e-03
    z[1,2,2]  R779      3.1355914473533630e-01
    z[1,2,2]  R780      -4.0524119138717651e-01
    z[1,2,2]  R781      1.9952647387981415e-01
    z[1,2,2]  R782      2.5198289752006531e-01
    z[1,2,2]  R783      -6.6592156887054443e-02
    z[1,2,2]  R784      -2.0460438728332520e-01
    z[1,2,2]  R785      1.0704782605171204e-01
    z[1,2,2]  R786      1.3273303396999836e-02
    z[1,2,2]  R787      1.6280081868171692e-01
    z[1,2,2]  R788      1.9041393697261810e-01
    z[1,2,2]  R789      7.0002920925617218e-02
    z[1,2,2]  R790      -2.6101595163345337e-01
    z[1,2,2]  R791      7.1109563112258911e-02
    z[1,2,2]  R792      1.5195743739604950e-01
    z[1,2,2]  R793      -9.9591560661792755e-02
    z[1,2,2]  R794      4.1462087631225586e-01
    z[1,2,2]  R795      -3.3298179507255554e-01
    z[1,2,2]  R796      4.3960276991128922e-02
    z[1,2,2]  R797      -4.0967562235891819e-03
    z[1,2,2]  R798      1.4690834283828735e-01
    z[1,2,2]  R799      7.8408278524875641e-02
    z[1,2,2]  R800      9.3858368694782257e-02
    z[1,2,2]  R801      1.6618616878986359e-01
    z[1,2,2]  R802      2.0638216286897659e-02
    z[1,2,2]  R803      1.9519396126270294e-01
    z[1,2,2]  R804      9.6629597246646881e-02
    z[1,2,2]  R805      2.1174415946006775e-01
    z[1,2,2]  R806      5.1338362693786621e-01
    z[1,2,2]  R807      7.7930486202239990e-01
    z[1,2,2]  R808      5.6660646200180054e-01
    z[1,2,2]  R809      1.5669887885451317e-02
    z[1,2,2]  R810      -1.3559582829475403e-01
    z[1,2,2]  R811      3.2131153345108032e-01
    z[1,2,2]  R812      1.6175954043865204e-01
    z[1,2,2]  R813      -2.2412294149398804e-01
    z[1,2,2]  R814      -2.1871482953429222e-02
    z[1,2,2]  R815      -1.3139431178569794e-01
    z[1,2,2]  R816      3.3440402150154114e-01
    z[1,2,2]  R817      2.8118276596069336e-01
    z[1,2,2]  R818      2.7220770716667175e-01
    z[1,2,2]  R819      3.5450032353401184e-01
    z[1,2,2]  R820      1.0474268347024918e-02
    z[1,2,2]  R821      9.4537794589996338e-02
    z[1,2,2]  R822      2.2170089185237885e-01
    z[1,2,2]  R823      -1.0814710706472397e-01
    z[1,2,2]  R824      -2.5182211399078369e-01
    z[1,2,2]  R825      3.7095537781715393e-01
    z[1,2,2]  R826      4.8485729098320007e-01
    z[1,2,2]  R827      0.391141802072525
    z[1,2,2]  R828      -2.6335790753364563e-01
    z[1,2,2]  R829      4.1815541684627533e-02
    z[1,2,2]  R830      2.2154621779918671e-02
    z[1,2,2]  R831      3.6627537012100220e-01
    z[1,2,2]  R832      4.9212306737899780e-01
    z[1,2,2]  R833      3.5707566142082214e-01
    z[1,2,2]  R834      2.6747745275497437e-01
    z[1,2,2]  R835      -1.8532557412981987e-02
    z[1,2,2]  R836      1.9488810002803802e-01
    z[1,2,2]  R837      1.8859108909964561e-02
    z[1,2,2]  R838      -5.3550285100936890e-01
    z[1,2,2]  R839      -2.4048466980457306e-01
    z[1,2,2]  R840      0.082611583173275
    z[1,2,2]  R841      -8.9654371142387390e-02
    z[1,2,2]  R842      -2.1137490868568420e-01
    z[1,2,2]  R843      -1.7876550555229187e-01
    z[1,2,2]  R844      -2.6982340216636658e-01
    z[1,2,2]  R845      -1.9752517342567444e-01
    z[1,2,2]  R846      -1.1177732609212399e-02
    z[1,2,2]  R847      -1.0844890773296356e-01
    z[1,2,2]  R848      -5.7923197746276855e-01
    z[1,2,2]  R849      -5.9258836507797241e-01
    z[1,2,2]  R850      1.4884649217128754e-01
    z[1,2,2]  R851      -4.0928909182548523e-01
    z[1,2,2]  R852      -4.7487002611160278e-01
    z[1,2,2]  R853      1.0943194478750229e-01
    z[1,2,2]  R854      8.5958667099475861e-02
    z[1,2,2]  R855      -0.606873631477356
    z[1,2,2]  R856      1.0186557471752167e-01
    z[1,2,2]  R857      0.625761091709137
    z[1,2,2]  R858      -4.5682549476623535e-01
    z[1,2,2]  R859      -8.2836419343948364e-02
    z[1,2,2]  R860      -5.4207291454076767e-02
    z[1,2,2]  R861      2.7874214574694633e-02
    z[1,2,2]  R862      -4.2019593715667725e-01
    z[1,2,2]  R863      -1.3303663581609726e-02
    z[1,2,2]  R864      2.0317737758159637e-01
    z[1,2,2]  R865      8.1217640638351440e-01
    z[1,2,2]  R866      -3.9600688964128494e-02
    z[1,2,2]  R867      -3.3364436030387878e-01
    z[1,2,2]  R868      -7.4472390115261078e-02
    z[1,2,2]  R869      -2.9672920703887939e-01
    z[1,2,2]  R870      -4.3127492070198059e-01
    z[1,2,2]  R871      1.4311423897743225e-01
    z[1,2,2]  R872      -1.0728116333484650e-01
    z[1,2,2]  R873      -2.1686401963233948e-01
    z[1,2,2]  R874      3.9321917295455933e-01
    z[1,2,2]  R875      4.4646185636520386e-01
    z[1,2,2]  R876      -3.7101346254348755e-01
    z[1,2,2]  R877      1.4247593283653259e-01
    z[1,2,3]  R14       -1
    z[1,2,3]  R23       1
    z[1,2,3]  R760      -1
    z[1,2,3]  R761      1
    z[1,2,3]  R768      -5.2714014053344727e-01
    z[1,2,3]  R769      -1.7141684889793396e-01
    z[1,2,3]  R770      -2.4051589891314507e-02
    z[1,2,3]  R771      -5.9793466329574585e-01
    z[1,2,3]  R772      -4.6273627877235413e-01
    z[1,2,3]  R773      -2.2545909881591797e-01
    z[1,2,3]  R774      -3.8147419691085815e-01
    z[1,2,3]  R775      -5.8227157592773438e-01
    z[1,2,3]  R776      -2.6461067795753479e-01
    z[1,2,3]  R777      -3.9880636334419250e-01
    z[1,2,3]  R778      -1.2796452641487122e-01
    z[1,2,3]  R779      2.8310397267341614e-01
    z[1,2,3]  R780      2.4331583082675934e-01
    z[1,2,3]  R781      7.2456523776054382e-02
    z[1,2,3]  R782      4.0017911791801453e-01
    z[1,2,3]  R783      3.2510197162628174e-01
    z[1,2,3]  R784      1.0274247825145721e-01
    z[1,2,3]  R785      4.3138790130615234e-01
    z[1,2,3]  R786      6.0794878005981445e-01
    z[1,2,3]  R787      2.7000385522842407e-01
    z[1,2,3]  R788      -2.2122806310653687e-01
    z[1,2,3]  R789      -2.4943706393241882e-01
    z[1,2,3]  R790      3.1544142961502075e-01
    z[1,2,3]  R791      2.4635457992553711e-01
    z[1,2,3]  R792      -4.2376585304737091e-02
    z[1,2,3]  R793      5.2524778991937637e-02
    z[1,2,3]  R794      -1.5484818816184998e-01
    z[1,2,3]  R795      1.7375695705413818e-01
    z[1,2,3]  R796      2.9080143570899963e-01
    z[1,2,3]  R797      2.5139921903610229e-01
    z[1,2,3]  R798      -5.9669923782348633e-01
    z[1,2,3]  R799      -0.152748703956604
    z[1,2,3]  R800      -3.1927478313446045e-01
    z[1,2,3]  R801      7.5129017233848572e-02
    z[1,2,3]  R802      -6.4138539135456085e-02
    z[1,2,3]  R803      -3.1122544407844543e-01
    z[1,2,3]  R804      3.1744691729545593e-01
    z[1,2,3]  R805      -4.7472648322582245e-02
    z[1,2,3]  R806      0.641027569770813
    z[1,2,3]  R807      4.1837012767791748e-01
    z[1,2,3]  R808      -4.9738347530364990e-01
    z[1,2,3]  R809      -4.9407455325126648e-01
    z[1,2,3]  R810      -3.8313293457031250e-01
    z[1,2,3]  R811      -6.3725954294204712e-01
    z[1,2,3]  R812      -3.1108251214027405e-01
    z[1,2,3]  R813      -3.7824982404708862e-01
    z[1,2,3]  R814      -3.9815476536750793e-01
    z[1,2,3]  R815      -3.7539014220237732e-01
    z[1,2,3]  R816      -6.8444848060607910e-01
    z[1,2,3]  R817      -4.8272785544395447e-01
    z[1,2,3]  R818      4.8311153054237366e-01
    z[1,2,3]  R819      5.9779763221740723e-01
    z[1,2,3]  R820      6.4269524812698364e-01
    z[1,2,3]  R821      6.1657619476318359e-01
    z[1,2,3]  R822      3.2699123024940491e-01
    z[1,2,3]  R823      5.1298719644546509e-01
    z[1,2,3]  R824      4.0008780360221863e-01
    z[1,2,3]  R825      6.0585594177246094e-01
    z[1,2,3]  R826      3.9594307541847229e-01
    z[1,2,3]  R827      4.2353931069374084e-01
    z[1,2,3]  R828      -4.3787723779678345e-01
    z[1,2,3]  R829      5.4378788918256760e-02
    z[1,2,3]  R830      4.1932079195976257e-01
    z[1,2,3]  R831      -2.0981330424547195e-02
    z[1,2,3]  R832      -1.5364332357421517e-03
    z[1,2,3]  R833      1.3689659535884857e-01
    z[1,2,3]  R834      -9.2429459095001221e-02
    z[1,2,3]  R835      -3.2372960448265076e-01
    z[1,2,3]  R836      -1.2386822700500488e-01
    z[1,2,3]  R837      3.1529575586318970e-01
    z[1,2,3]  R838      2.3897531628608704e-01
    z[1,2,3]  R839      -3.3361229300498962e-01
    z[1,2,3]  R840      -0.145788311958313
    z[1,2,3]  R841      -1.4089332520961761e-01
    z[1,2,3]  R842      2.6580068469047546e-01
    z[1,2,3]  R843      2.7467063069343567e-01
    z[1,2,3]  R844      3.5498273372650146e-01
    z[1,2,3]  R845      -3.6747679114341736e-02
    z[1,2,3]  R846      4.0764799714088440e-01
    z[1,2,3]  R847      5.6897927075624466e-02
    z[1,2,3]  R848      -4.8815658688545227e-01
    z[1,2,3]  R849      -7.2577714920043945e-01
    z[1,2,3]  R850      2.6660218834877014e-01
    z[1,2,3]  R851      2.3126375675201416e-01
    z[1,2,3]  R852      5.9364604949951172e-01
    z[1,2,3]  R853      -1.8681989610195160e-01
    z[1,2,3]  R854      -4.3784928321838379e-01
    z[1,2,3]  R855      -1.2139679491519928e-01
    z[1,2,3]  R856      -2.9585435986518860e-02
    z[1,2,3]  R857      -3.0198785662651062e-01
    z[1,2,3]  R858      -5.2362877130508423e-01
    z[1,2,3]  R859      9.5383845269680023e-02
    z[1,2,3]  R860      1.9987209141254425e-01
    z[1,2,3]  R861      1.3164575397968292e-01
    z[1,2,3]  R862      4.9316713213920593e-01
    z[1,2,3]  R863      1.6954675316810608e-02
    z[1,2,3]  R864      -2.6575639843940735e-01
    z[1,2,3]  R865      -1.7028152942657471e-01
    z[1,2,3]  R866      -5.0227010250091553e-01
    z[1,2,3]  R867      -2.0487660169601440e-01
    z[1,2,3]  R868      -5.2006644010543823e-01
    z[1,2,3]  R869      0.206911101937294
    z[1,2,3]  R870      8.8795311748981476e-02
    z[1,2,3]  R871      3.2202258706092834e-01
    z[1,2,3]  R872      -0.298666775226593
    z[1,2,3]  R873      1.9712407886981964e-01
    z[1,2,3]  R874      3.5539147257804871e-01
    z[1,2,3]  R875      4.5797824859619141e-01
    z[1,2,3]  R876      4.5064017176628113e-01
    z[1,2,3]  R877      0.621365487575531
    z[1,2,4]  R15       -1
    z[1,2,4]  R24       1
    z[1,2,4]  R762      -1
    z[1,2,4]  R763      1
    z[1,2,4]  R768      -7.4473358690738678e-02
    z[1,2,4]  R769      3.5818558186292648e-02
    z[1,2,4]  R770      -1.9742001593112946e-01
    z[1,2,4]  R771      3.3438715338706970e-01
    z[1,2,4]  R772      -0.207333505153656
    z[1,2,4]  R773      -1.1061331629753113e-01
    z[1,2,4]  R774      -0.0686548575758934
    z[1,2,4]  R775      2.1860344707965851e-01
    z[1,2,4]  R776      -6.0606843233108521e-01
    z[1,2,4]  R777      -4.0920057892799377e-01
    z[1,2,4]  R778      -2.6890264824032784e-02
    z[1,2,4]  R779      -2.5274107232689857e-02
    z[1,2,4]  R780      2.0200443267822266e-01
    z[1,2,4]  R781      1.1528035998344421e-01
    z[1,2,4]  R782      -3.2284778356552124e-01
    z[1,2,4]  R783      -7.9762347042560577e-02
    z[1,2,4]  R784      6.1005318164825439e-01
    z[1,2,4]  R785      1.2749303877353668e-01
    z[1,2,4]  R786      -1.8790359795093536e-01
    z[1,2,4]  R787      -5.0215828418731689e-01
    z[1,2,4]  R788      -1.1892067268490791e-02
    z[1,2,4]  R789      -6.9857522845268250e-02
    z[1,2,4]  R790      -2.5380348786711693e-02
    z[1,2,4]  R791      2.1475711464881897e-01
    z[1,2,4]  R792      3.8521581888198853e-01
    z[1,2,4]  R793      1.9272805750370026e-01
    z[1,2,4]  R794      -4.7011303901672363e-01
    z[1,2,4]  R795      6.4100092649459839e-01
    z[1,2,4]  R796      -2.9409998655319214e-01
    z[1,2,4]  R797      -7.3312622308731079e-01
    z[1,2,4]  R798      -3.9989843964576721e-01
    z[1,2,4]  R799      5.2233719825744629e-01
    z[1,2,4]  R800      0.336622953414917
    z[1,2,4]  R801      2.9592399951070547e-03
    z[1,2,4]  R802      1.1275199800729752e-01
    z[1,2,4]  R803      4.6267968416213989e-01
    z[1,2,4]  R804      -1.8894420564174652e-01
    z[1,2,4]  R805      -0.502036452293396
    z[1,2,4]  R806      0.291445255279541
    z[1,2,4]  R807      2.7686533331871033e-01
    z[1,2,4]  R808      7.4108898639678955e-02
    z[1,2,4]  R809      4.5411086082458496e-01
    z[1,2,4]  R810      -7.7939257025718689e-02
    z[1,2,4]  R811      2.5241702795028687e-02
    z[1,2,4]  R812      -3.1280061602592468e-01
    z[1,2,4]  R813      -0.197514608502388
    z[1,2,4]  R814      1.8651725351810455e-01
    z[1,2,4]  R815      3.4524840116500854e-01
    z[1,2,4]  R816      -2.2133202850818634e-01
    z[1,2,4]  R817      -9.4200141727924347e-02
    z[1,2,4]  R818      2.0341378450393677e-01
    z[1,2,4]  R819      8.9632213115692139e-02
    z[1,2,4]  R820      2.4004580453038216e-02
    z[1,2,4]  R821      2.9950913786888123e-01
    z[1,2,4]  R822      2.2722056508064270e-01
    z[1,2,4]  R823      -2.3124359548091888e-01
    z[1,2,4]  R824      4.8136554658412933e-02
    z[1,2,4]  R825      5.7331800460815430e-02
    z[1,2,4]  R826      -2.1913222968578339e-01
    z[1,2,4]  R827      5.3543031215667725e-01
    z[1,2,4]  R828      -2.0215612649917603e-01
    z[1,2,4]  R829      3.6794430017471313e-01
    z[1,2,4]  R830      -2.8205132484436035e-01
    z[1,2,4]  R831      -8.9348025619983673e-02
    z[1,2,4]  R832      2.6865644380450249e-02
    z[1,2,4]  R833      -1.1009267531335354e-02
    z[1,2,4]  R834      3.2222609966993332e-02
    z[1,2,4]  R835      -8.0519765615463257e-02
    z[1,2,4]  R836      3.7069308757781982e-01
    z[1,2,4]  R837      1.7405509948730469e-01
    z[1,2,4]  R838      3.0431419610977173e-01
    z[1,2,4]  R839      -8.5079200565814972e-02
    z[1,2,4]  R840      7.2199290990829468e-01
    z[1,2,4]  R841      3.3194559812545776e-01
    z[1,2,4]  R842      1.6605427861213684e-01
    z[1,2,4]  R843      1.8416607752442360e-02
    z[1,2,4]  R844      -2.2175459563732147e-01
    z[1,2,4]  R845      4.2684939503669739e-01
    z[1,2,4]  R846      -2.6789689064025879e-01
    z[1,2,4]  R847      3.8038060069084167e-01
    z[1,2,4]  R848      -3.3481433987617493e-01
    z[1,2,4]  R849      -2.6730507612228394e-02
    z[1,2,4]  R850      -7.6060421764850616e-02
    z[1,2,4]  R851      4.3052637577056885e-01
    z[1,2,4]  R852      3.3167313784360886e-02
    z[1,2,4]  R853      3.9344325661659241e-01
    z[1,2,4]  R854      1.6735710203647614e-01
    z[1,2,4]  R855      1.4674863219261169e-01
    z[1,2,4]  R856      1.9643607735633850e-01
    z[1,2,4]  R857      2.4451376497745514e-01
    z[1,2,4]  R858      -2.8217095136642456e-01
    z[1,2,4]  R859      4.3291813135147095e-01
    z[1,2,4]  R860      6.5028005838394165e-01
    z[1,2,4]  R861      -6.1785720288753510e-02
    z[1,2,4]  R862      2.3512113094329834e-01
    z[1,2,4]  R863      -6.0237981379032135e-02
    z[1,2,4]  R864      8.2637047767639160e-01
    z[1,2,4]  R865      6.9821491837501526e-02
    z[1,2,4]  R866      7.6107615232467651e-01
    z[1,2,4]  R867      6.2636291980743408e-01
    z[1,2,4]  R868      6.4324772357940674e-01
    z[1,2,4]  R869      3.2327157258987427e-01
    z[1,2,4]  R870      1.6144491732120514e-01
    z[1,2,4]  R871      5.3124237060546875e-01
    z[1,2,4]  R872      7.2016930580139160e-01
    z[1,2,4]  R873      -1.0330962389707565e-01
    z[1,2,4]  R874      1.6766072809696198e-01
    z[1,2,4]  R875      5.5407159030437469e-02
    z[1,2,4]  R876      -4.9126887321472168e-01
    z[1,2,4]  R877      4.8064431548118591e-01
    z[1,2,5]  R16       -1
    z[1,2,5]  R25       1
    z[1,2,5]  R764      -1
    z[1,2,5]  R765      1
    z[1,2,5]  R768      -4.2726588249206543e-01
    z[1,2,5]  R769      -4.4893521070480347e-01
    z[1,2,5]  R770      -1.9430667161941528e-01
    z[1,2,5]  R771      1.8883095681667328e-01
    z[1,2,5]  R772      -3.1816062331199646e-01
    z[1,2,5]  R773      3.5657492280006409e-01
    z[1,2,5]  R774      -0.413128525018692
    z[1,2,5]  R775      0.0798230916261673
    z[1,2,5]  R776      -5.1094375550746918e-02
    z[1,2,5]  R777      1.0263931751251221e-01
    z[1,2,5]  R778      3.4040069580078125e-01
    z[1,2,5]  R779      9.6004633232951164e-03
    z[1,2,5]  R780      2.4548135697841644e-01
    z[1,2,5]  R781      3.8709971308708191e-01
    z[1,2,5]  R782      3.2117941975593567e-01
    z[1,2,5]  R783      4.8737379908561707e-01
    z[1,2,5]  R784      3.2575258612632751e-01
    z[1,2,5]  R785      3.6358457803726196e-01
    z[1,2,5]  R786      2.8527006506919861e-01
    z[1,2,5]  R787      1.6940513253211975e-01
    z[1,2,5]  R788      5.3804576396942139e-01
    z[1,2,5]  R789      4.4933566451072693e-01
    z[1,2,5]  R790      3.4121209383010864e-01
    z[1,2,5]  R791      2.7260869741439819e-01
    z[1,2,5]  R792      -1.8417501449584961e-01
    z[1,2,5]  R793      -4.8523122072219849e-01
    z[1,2,5]  R794      -5.0318732857704163e-02
    z[1,2,5]  R795      -5.4362822324037552e-02
    z[1,2,5]  R796      -5.0268638134002686e-01
    z[1,2,5]  R797      -9.4509720802307129e-02
    z[1,2,5]  R798      6.2728708982467651e-01
    z[1,2,5]  R799      -8.9115977287292480e-02
    z[1,2,5]  R800      -1.9698626419994980e-04
    z[1,2,5]  R801      4.9155500531196594e-01
    z[1,2,5]  R802      1.5471910126507282e-02
    z[1,2,5]  R803      7.5048275291919708e-02
    z[1,2,5]  R804      -6.8633213639259338e-02
    z[1,2,5]  R805      -9.3955181539058685e-02
    z[1,2,5]  R806      2.3310044407844543e-01
    z[1,2,5]  R807      9.1374032199382782e-02
    z[1,2,5]  R808      -2.5763321667909622e-02
    z[1,2,5]  R809      1.1319072544574738e-01
    z[1,2,5]  R810      -3.2504707574844360e-01
    z[1,2,5]  R811      -5.9077125787734985e-01
    z[1,2,5]  R812      -8.5536353290081024e-02
    z[1,2,5]  R813      3.8181871175765991e-02
    z[1,2,5]  R814      -1.5665654838085175e-01
    z[1,2,5]  R815      -3.6032482981681824e-01
    z[1,2,5]  R816      4.5826286077499390e-01
    z[1,2,5]  R817      2.3778598010540009e-01
    z[1,2,5]  R818      2.3975865915417671e-02
    z[1,2,5]  R819      -1.9673697650432587e-01
    z[1,2,5]  R820      -3.9418466389179230e-02
    z[1,2,5]  R821      -1.0547454655170441e-01
    z[1,2,5]  R822      -4.1495278477668762e-01
    z[1,2,5]  R823      1.3072626292705536e-01
    z[1,2,5]  R824      -2.0526649057865143e-01
    z[1,2,5]  R825      -2.4558408558368683e-01
    z[1,2,5]  R826      -1.0090753436088562e-01
    z[1,2,5]  R827      -1.0786123573780060e-01
    z[1,2,5]  R828      -2.7562916278839111e-01
    z[1,2,5]  R829      0.073304183781147
    z[1,2,5]  R830      0.0922246053814888
    z[1,2,5]  R831      4.6109721064567566e-01
    z[1,2,5]  R832      1.2221264094114304e-01
    z[1,2,5]  R833      3.6499887704849243e-01
    z[1,2,5]  R834      -3.2317012548446655e-01
    z[1,2,5]  R835      7.0836436934769154e-03
    z[1,2,5]  R836      1.2804001569747925e-01
    z[1,2,5]  R837      5.4895699024200439e-01
    z[1,2,5]  R838      2.7236780524253845e-01
    z[1,2,5]  R839      -1.2452408671379089e-01
    z[1,2,5]  R840      -6.5301053225994110e-02
    z[1,2,5]  R841      4.3510493636131287e-01
    z[1,2,5]  R842      -5.7376161217689514e-02
    z[1,2,5]  R843      -1.8761390447616577e-01
    z[1,2,5]  R844      -5.1306881010532379e-02
    z[1,2,5]  R845      -3.3381082117557526e-02
    z[1,2,5]  R846      -1.3989751040935516e-01
    z[1,2,5]  R847      7.0005212910473347e-03
    z[1,2,5]  R848      -3.5425817966461182e-01
    z[1,2,5]  R849      2.6494054123759270e-02
    z[1,2,5]  R850      4.0824812650680542e-01
    z[1,2,5]  R851      1.4948236942291260e-01
    z[1,2,5]  R852      -3.0073684453964233e-01
    z[1,2,5]  R853      -1.9144824147224426e-01
    z[1,2,5]  R854      2.0868784189224243e-01
    z[1,2,5]  R855      -1.5906600281596184e-02
    z[1,2,5]  R856      -2.2126603126525879e-01
    z[1,2,5]  R857      4.2481872439384460e-01
    z[1,2,5]  R858      -2.1682459115982056e-01
    z[1,2,5]  R859      -2.3186743259429932e-01
    z[1,2,5]  R860      1.1061707139015198e-01
    z[1,2,5]  R861      1.7542797327041626e-01
    z[1,2,5]  R862      -3.1311661005020142e-01
    z[1,2,5]  R863      -2.8522959351539612e-01
    z[1,2,5]  R864      3.5395030863583088e-03
    z[1,2,5]  R865      2.9308724403381348e-01
    z[1,2,5]  R866      1.7048075795173645e-02
    z[1,2,5]  R867      -3.4903664141893387e-02
    z[1,2,5]  R868      1.9971325993537903e-01
    z[1,2,5]  R869      0.141094371676445
    z[1,2,5]  R870      2.4412022903561592e-02
    z[1,2,5]  R871      3.5019564628601074e-01
    z[1,2,5]  R872      2.1683631464838982e-02
    z[1,2,5]  R873      1.0498115420341492e-01
    z[1,2,5]  R874      6.6231940872967243e-03
    z[1,2,5]  R875      -2.3655049502849579e-01
    z[1,2,5]  R876      -0.504997730255127
    z[1,2,5]  R877      -2.6477809995412827e-02
    z[1,2,6]  R17       -1
    z[1,2,6]  R26       1
    z[1,2,6]  R766      -1
    z[1,2,6]  R767      1
    z[1,2,6]  R768      -8.4079019725322723e-02
    z[1,2,6]  R769      3.4917865414172411e-03
    z[1,2,6]  R770      9.3952931463718414e-02
    z[1,2,6]  R771      -2.6736435294151306e-01
    z[1,2,6]  R772      5.2625524997711182e-01
    z[1,2,6]  R773      -8.1423139199614525e-03
    z[1,2,6]  R774      2.3798566311597824e-02
    z[1,2,6]  R775      4.5384612679481506e-01
    z[1,2,6]  R776      2.9452082514762878e-01
    z[1,2,6]  R777      5.3818774223327637e-01
    z[1,2,6]  R778      2.4685344099998474e-01
    z[1,2,6]  R779      -2.9452103376388550e-01
    z[1,2,6]  R780      4.3733417987823486e-01
    z[1,2,6]  R781      -1.2433338165283203e-01
    z[1,2,6]  R782      -3.8061115145683289e-01
    z[1,2,6]  R783      0.0547383613884449
    z[1,2,6]  R784      1.0755355656147003e-01
    z[1,2,6]  R785      0.0466521717607975
    z[1,2,6]  R786      -0.074155293405056
    z[1,2,6]  R787      1.6571673750877380e-01
    z[1,2,6]  R788      1.4408499002456665e-02
    z[1,2,6]  R789      -1.2025839835405350e-01
    z[1,2,6]  R790      5.1061216741800308e-02
    z[1,2,6]  R791      -1.9564969837665558e-01
    z[1,2,6]  R792      8.6739897727966309e-02
    z[1,2,6]  R793      3.4491127729415894e-01
    z[1,2,6]  R794      -5.8239664882421494e-02
    z[1,2,6]  R795      4.4052168726921082e-02
    z[1,2,6]  R796      1.7404365539550781e-01
    z[1,2,6]  R797      2.4868105351924896e-01
    z[1,2,6]  R798      -2.5180861353874207e-02
    z[1,2,6]  R799      7.3525518178939819e-02
    z[1,2,6]  R800      2.1956019103527069e-01
    z[1,2,6]  R801      -2.2008366882801056e-01
    z[1,2,6]  R802      1.4444258809089661e-01
    z[1,2,6]  R803      -2.2445949912071228e-01
    z[1,2,6]  R804      -1.0294097661972046e-01
    z[1,2,6]  R805      1.2430543079972267e-02
    z[1,2,6]  R806      -2.4548610672354698e-02
    z[1,2,6]  R807      -1.1802790313959122e-01
    z[1,2,6]  R808      -5.2041497081518173e-02
    z[1,2,6]  R809      2.6563179492950439e-01
    z[1,2,6]  R810      1.2247455865144730e-01
    z[1,2,6]  R811      -2.9744941741228104e-02
    z[1,2,6]  R812      -1.7013169825077057e-01
    z[1,2,6]  R813      -3.5226354002952576e-01
    z[1,2,6]  R814      -3.1037840247154236e-01
    z[1,2,6]  R815      -2.2379522025585175e-01
    z[1,2,6]  R816      4.9815565347671509e-02
    z[1,2,6]  R817      6.5397346019744873e-01
    z[1,2,6]  R818      1.7376956343650818e-01
    z[1,2,6]  R819      3.9379266090691090e-03
    z[1,2,6]  R820      8.5842885076999664e-02
    z[1,2,6]  R821      5.0171691924333572e-02
    z[1,2,6]  R822      -2.0933536812663078e-02
    z[1,2,6]  R823      -5.0253149121999741e-02
    z[1,2,6]  R824      2.9349419474601746e-01
    z[1,2,6]  R825      2.8682306408882141e-01
    z[1,2,6]  R826      -1.9491675496101379e-01
    z[1,2,6]  R827      -3.3388055860996246e-02
    z[1,2,6]  R828      -1.3035708665847778e-01
    z[1,2,6]  R829      -3.4366950392723083e-01
    z[1,2,6]  R830      9.2071019113063812e-02
    z[1,2,6]  R831      -1.1393783241510391e-01
    z[1,2,6]  R832      8.2571931183338165e-02
    z[1,2,6]  R833      -3.6306026577949524e-01
    z[1,2,6]  R834      8.3058521151542664e-02
    z[1,2,6]  R835      1.4299200847744942e-02
    z[1,2,6]  R836      4.2816221714019775e-01
    z[1,2,6]  R837      3.4252646565437317e-01
    z[1,2,6]  R838      -1.8468311429023743e-01
    z[1,2,6]  R839      -4.3246969580650330e-01
    z[1,2,6]  R840      6.2741570174694061e-02
    z[1,2,6]  R841      -5.8201032876968384e-01
    z[1,2,6]  R842      1.0211148113012314e-01
    z[1,2,6]  R843      -2.6464468240737915e-01
    z[1,2,6]  R844      5.3623810410499573e-02
    z[1,2,6]  R845      4.9583610892295837e-01
    z[1,2,6]  R846      1.6540125012397766e-01
    z[1,2,6]  R847      -2.4010688066482544e-01
    z[1,2,6]  R848      3.7758362293243408e-01
    z[1,2,6]  R849      -3.3995591104030609e-02
    z[1,2,6]  R850      2.4440832436084747e-01
    z[1,2,6]  R851      2.2488673031330109e-01
    z[1,2,6]  R852      1.7554501071572304e-02
    z[1,2,6]  R853      -5.4029554128646851e-01
    z[1,2,6]  R854      -2.1544055640697479e-01
    z[1,2,6]  R855      -4.4490674138069153e-01
    z[1,2,6]  R856      5.8592408895492554e-01
    z[1,2,6]  R857      -4.2189598083496094e-02
    z[1,2,6]  R858      0.26277956366539
    z[1,2,6]  R859      -1.5819574892520905e-01
    z[1,2,6]  R860      6.4440146088600159e-02
    z[1,2,6]  R861      -0.503376841545105
    z[1,2,6]  R862      9.5405891537666321e-02
    z[1,2,6]  R863      5.3170013427734375e-01
    z[1,2,6]  R864      -3.4733593463897705e-01
    z[1,2,6]  R865      1.4525157213211060e-01
    z[1,2,6]  R866      -1.4669755101203918e-01
    z[1,2,6]  R867      -3.0108600854873657e-01
    z[1,2,6]  R868      -2.6337680220603943e-01
    z[1,2,6]  R869      -1.4485427737236023e-01
    z[1,2,6]  R870      4.2245812714099884e-02
    z[1,2,6]  R871      8.5663706064224243e-02
    z[1,2,6]  R872      -1.1631070822477341e-01
    z[1,2,6]  R873      1.2773084640502930e-01
    z[1,2,6]  R874      1.3055829703807831e-01
    z[1,2,6]  R875      -1.3799254596233368e-01
    z[1,2,6]  R876      -3.9727625250816345e-01
    z[1,2,6]  R877      -1.6255301237106323e-01
    z[2,1,0]  R11       1
    z[2,1,0]  R20       -1
    z[2,1,0]  R878      -1
    z[2,1,0]  R879      1
    z[2,1,0]  R892      3.7873715162277222e-01
    z[2,1,0]  R893      5.3333443403244019e-01
    z[2,1,0]  R894      6.8667048215866089e-01
    z[2,1,0]  R895      -1.4450901746749878e-01
    z[2,1,0]  R896      6.8553018569946289e-01
    z[2,1,0]  R897      6.5093624591827393e-01
    z[2,1,0]  R898      7.6829367876052856e-01
    z[2,1,0]  R899      5.8579719066619873e-01
    z[2,1,0]  R900      -0.367805153131485
    z[2,1,0]  R901      1.2440484762191772e-01
    z[2,1,0]  R902      7.8678119182586670e-01
    z[2,1,0]  R903      6.4782553911209106e-01
    z[2,1,0]  R904      7.5260007381439209e-01
    z[2,1,0]  R905      6.2868463993072510e-01
    z[2,1,0]  R906      6.5628039836883545e-01
    z[2,1,0]  R907      7.3745173215866089e-01
    z[2,1,0]  R908      7.6738870143890381e-01
    z[2,1,0]  R909      5.6793701648712158e-01
    z[2,1,0]  R910      7.0700442790985107e-01
    z[2,1,0]  R911      5.2821296453475952e-01
    z[2,1,0]  R912      -5.5435019731521606e-01
    z[2,1,0]  R913      -1.3739745318889618e-01
    z[2,1,0]  R914      -2.4997992813587189e-01
    z[2,1,0]  R915      -9.3141689896583557e-02
    z[2,1,0]  R916      -3.6504247784614563e-01
    z[2,1,0]  R917      -1.8392980098724365e-01
    z[2,1,0]  R918      -2.9985910654067993e-01
    z[2,1,0]  R919      -1.4240592718124390e-01
    z[2,1,0]  R920      -1.1798799037933350e-01
    z[2,1,0]  R921      -8.4018073976039886e-02
    z[2,1,0]  R922      2.7113190293312073e-01
    z[2,1,0]  R923      7.4907368421554565e-01
    z[2,1,0]  R924      -6.4337062835693359e-01
    z[2,1,0]  R925      5.5352133512496948e-01
    z[2,1,0]  R926      -8.7810635566711426e-01
    z[2,1,0]  R927      -8.5123598575592041e-01
    z[2,1,0]  R928      -7.8212362527847290e-01
    z[2,1,0]  R929      -7.1261632442474365e-01
    z[2,1,0]  R930      -8.3282917737960815e-01
    z[2,1,0]  R931      -8.2556849718093872e-01
    z[2,1,0]  R932      -8.3808355033397675e-02
    z[2,1,0]  R933      -6.3356541097164154e-02
    z[2,1,0]  R934      1.9311730563640594e-01
    z[2,1,0]  R935      1.9144977629184723e-01
    z[2,1,0]  R936      -9.8120421171188354e-02
    z[2,1,0]  R937      -6.7651188373565674e-01
    z[2,1,0]  R938      7.1136116981506348e-01
    z[2,1,0]  R939      5.4982852935791016e-01
    z[2,1,0]  R940      -0.673531174659729
    z[2,1,0]  R941      5.1509976387023926e-01
    z[2,1,0]  R942      -5.5446839332580566e-01
    z[2,1,0]  R943      -6.9315418601036072e-02
    z[2,1,0]  R944      3.8593227509409189e-03
    z[2,1,0]  R945      3.5450258851051331e-01
    z[2,1,0]  R946      -1.2340407073497772e-01
    z[2,1,0]  R947      -4.0811732411384583e-02
    z[2,1,0]  R948      -2.8628918528556824e-01
    z[2,1,0]  R949      4.2757335305213928e-01
    z[2,1,0]  R950      -2.9277181625366211e-01
    z[2,1,0]  R951      6.0205173492431641e-01
    z[2,1,0]  R952      -4.4183117151260376e-01
    z[2,1,0]  R953      3.0860555171966553e-01
    z[2,1,0]  R954      -1.1031243205070496e-01
    z[2,1,0]  R955      -1.3681454956531525e-01
    z[2,1,0]  R956      5.8535623550415039e-01
    z[2,1,0]  R957      -8.4071463346481323e-01
    z[2,1,0]  R958      -7.9630863666534424e-01
    z[2,1,0]  R959      -7.1491372585296631e-01
    z[2,1,0]  R960      6.0217022895812988e-02
    z[2,1,0]  R961      -1.7587128281593323e-01
    z[2,1,0]  R962      1.0424977540969849e-01
    z[2,1,0]  R963      4.5252549648284912e-01
    z[2,1,0]  R964      0.0661509558558464
    z[2,1,0]  R965      2.8299051523208618e-01
    z[2,1,0]  R966      1.2149226665496826e-01
    z[2,1,0]  R967      0.612120509147644
    z[2,1,0]  R968      6.7033219337463379e-01
    z[2,1,0]  R969      1.5490005910396576e-01
    z[2,1,0]  R970      2.8226104378700256e-01
    z[2,1,0]  R971      -2.4477690458297729e-01
    z[2,1,0]  R972      -3.3862102031707764e-01
    z[2,1,0]  R973      -2.5495833158493042e-01
    z[2,1,0]  R974      -8.7855964899063110e-02
    z[2,1,0]  R975      -3.8494125008583069e-01
    z[2,1,0]  R976      9.0316146612167358e-02
    z[2,1,0]  R977      -1.0013429075479507e-01
    z[2,1,0]  R978      -2.1069069206714630e-01
    z[2,1,0]  R979      -2.3835390806198120e-01
    z[2,1,0]  R980      -8.9270561933517456e-02
    z[2,1,0]  R981      -1.3217581808567047e-01
    z[2,1,0]  R982      -5.6992095708847046e-01
    z[2,1,0]  R983      2.1340602636337280e-01
    z[2,1,0]  R984      3.7517610192298889e-01
    z[2,1,0]  R985      -7.1401357650756836e-02
    z[2,1,0]  R986      -1.5552681684494019e-01
    z[2,1,0]  R987      -3.3658319711685181e-01
    z[2,1,0]  R988      -3.7117803096771240e-01
    z[2,1,0]  R989      2.5435557961463928e-01
    z[2,1,0]  R990      -1.4337022602558136e-01
    z[2,1,0]  R991      3.9398744702339172e-02
    z[2,1,0]  R992      1.0379552096128464e-01
    z[2,1,0]  R993      -6.4998644590377808e-01
    z[2,1,0]  R994      -7.4237370491027832e-01
    z[2,1,0]  R995      -0.0773012712597847
    z[2,1,0]  R996      -0.246307834982872
    z[2,1,0]  R997      -1.4701296389102936e-01
    z[2,1,0]  R998      4.7910723835229874e-02
    z[2,1,0]  R999      -1.6824087128043175e-02
    z[2,1,0]  R1000     3.1259888410568237e-01
    z[2,1,0]  R1001     1.6191582381725311e-01
    z[2,1,1]  R12       1
    z[2,1,1]  R21       -1
    z[2,1,1]  R880      -1
    z[2,1,1]  R881      1
    z[2,1,1]  R892      5.2845132350921631e-01
    z[2,1,1]  R893      4.2615747451782227e-01
    z[2,1,1]  R894      4.8639130592346191e-01
    z[2,1,1]  R895      3.4531673789024353e-01
    z[2,1,1]  R896      5.2249819040298462e-01
    z[2,1,1]  R897      4.6735259890556335e-01
    z[2,1,1]  R898      3.0830904841423035e-01
    z[2,1,1]  R899      4.4670420885086060e-01
    z[2,1,1]  R900      1.5149046480655670e-01
    z[2,1,1]  R901      4.2348146438598633e-01
    z[2,1,1]  R902      -3.6520402878522873e-02
    z[2,1,1]  R903      -0.224799245595932
    z[2,1,1]  R904      -1.0453260689973831e-01
    z[2,1,1]  R905      -3.3511823415756226e-01
    z[2,1,1]  R906      -4.3470478057861328e-01
    z[2,1,1]  R907      -3.2897549867630005e-01
    z[2,1,1]  R908      -2.3882986605167389e-01
    z[2,1,1]  R909      -1.6404964029788971e-01
    z[2,1,1]  R910      -1.0996983945369720e-01
    z[2,1,1]  R911      -2.9862865805625916e-01
    z[2,1,1]  R912      -5.4568356275558472e-01
    z[2,1,1]  R913      -8.4708386659622192e-01
    z[2,1,1]  R914      -8.1526309251785278e-01
    z[2,1,1]  R915      -0.789399266242981
    z[2,1,1]  R916      -7.7593863010406494e-01
    z[2,1,1]  R917      -7.4482750892639160e-01
    z[2,1,1]  R918      -8.4712529182434082e-01
    z[2,1,1]  R919      -9.3157833814620972e-01
    z[2,1,1]  R920      -7.7176654338836670e-01
    z[2,1,1]  R921      -6.6648370027542114e-01
    z[2,1,1]  R922      -6.1783152818679810e-01
    z[2,1,1]  R923      -2.4491614103317261e-01
    z[2,1,1]  R924      -1.6888128221035004e-01
    z[2,1,1]  R925      -1.6578610241413116e-01
    z[2,1,1]  R926      2.6889970898628235e-01
    z[2,1,1]  R927      2.4984259903430939e-01
    z[2,1,1]  R928      3.6712694168090820e-01
    z[2,1,1]  R929      -1.5047702193260193e-01
    z[2,1,1]  R930      1.4627382159233093e-01
    z[2,1,1]  R931      3.1788122653961182e-01
    z[2,1,1]  R932      -0.197486013174057
    z[2,1,1]  R933      -3.3985349535942078e-01
    z[2,1,1]  R934      -7.9830235242843628e-01
    z[2,1,1]  R935      -6.9575464725494385e-01
    z[2,1,1]  R936      -5.6621932983398438e-01
    z[2,1,1]  R937      -1.0993305593729019e-01
    z[2,1,1]  R938      -4.2058369517326355e-01
    z[2,1,1]  R939      -3.0809995532035828e-01
    z[2,1,1]  R940      -3.2287931442260742e-01
    z[2,1,1]  R941      9.9301591515541077e-02
    z[2,1,1]  R942      -1.1832910031080246e-01
    z[2,1,1]  R943      -8.4441047906875610e-01
    z[2,1,1]  R944      -7.1961444616317749e-01
    z[2,1,1]  R945      -7.5381666421890259e-01
    z[2,1,1]  R946      -6.3448148965835571e-01
    z[2,1,1]  R947      -7.9383903741836548e-01
    z[2,1,1]  R948      -5.0873693078756332e-02
    z[2,1,1]  R949      -1.2915693223476410e-01
    z[2,1,1]  R950      -2.4370776116847992e-01
    z[2,1,1]  R951      6.2591084279119968e-03
    z[2,1,1]  R952      7.5826406478881836e-02
    z[2,1,1]  R953      -7.9278451204299927e-01
    z[2,1,1]  R954      -8.7493056058883667e-01
    z[2,1,1]  R955      -6.6701400279998779e-01
    z[2,1,1]  R956      -1.5493483841419220e-01
    z[2,1,1]  R957      4.1146323084831238e-01
    z[2,1,1]  R958      1.9942082464694977e-01
    z[2,1,1]  R959      4.1929177939891815e-02
    z[2,1,1]  R960      -3.8080174475908279e-02
    z[2,1,1]  R961      0.551843523979187
    z[2,1,1]  R962      -0.696075439453125
    z[2,1,1]  R963      -7.3556423187255859e-01
    z[2,1,1]  R964      -9.5174181461334229e-01
    z[2,1,1]  R965      -0.581727147102356
    z[2,1,1]  R966      -5.2499836683273315e-01
    z[2,1,1]  R967      -6.1543524265289307e-01
    z[2,1,1]  R968      4.6398368477821350e-01
    z[2,1,1]  R969      -4.8562464118003845e-01
    z[2,1,1]  R970      -6.1472445726394653e-01
    z[2,1,1]  R971      -5.4373896121978760e-01
    z[2,1,1]  R972      8.3149868249893188e-01
    z[2,1,1]  R973      8.1795817613601685e-01
    z[2,1,1]  R974      0.6903116106987
    z[2,1,1]  R975      0.792568564414978
    z[2,1,1]  R976      0.64494389295578
    z[2,1,1]  R977      7.9558509588241577e-01
    z[2,1,1]  R978      6.4291751384735107e-01
    z[2,1,1]  R979      0.771367609500885
    z[2,1,1]  R980      7.0715421438217163e-01
    z[2,1,1]  R981      7.5815582275390625e-01
    z[2,1,1]  R982      -5.4785811901092529e-01
    z[2,1,1]  R983      8.1614577770233154e-01
    z[2,1,1]  R984      7.5626271963119507e-01
    z[2,1,1]  R985      8.7774705886840820e-01
    z[2,1,1]  R986      8.7240421772003174e-01
    z[2,1,1]  R987      0.694605827331543
    z[2,1,1]  R988      6.6287875175476074e-01
    z[2,1,1]  R989      6.1518836021423340e-01
    z[2,1,1]  R990      7.2351044416427612e-01
    z[2,1,1]  R991      5.7182258367538452e-01
    z[2,1,1]  R992      -2.3990131914615631e-01
    z[2,1,1]  R993      -5.1171648502349854e-01
    z[2,1,1]  R994      -4.2025437951087952e-01
    z[2,1,1]  R995      8.1895691156387329e-01
    z[2,1,1]  R996      9.4919794797897339e-01
    z[2,1,1]  R997      7.5719106197357178e-01
    z[2,1,1]  R998      9.1465157270431519e-01
    z[2,1,1]  R999      8.3162802457809448e-01
    z[2,1,1]  R1000     -2.9651984572410583e-01
    z[2,1,1]  R1001     -3.0413705110549927e-01
    z[2,1,2]  R13       1
    z[2,1,2]  R22       -1
    z[2,1,2]  R882      -1
    z[2,1,2]  R883      1
    z[2,1,2]  R892      5.6660646200180054e-01
    z[2,1,2]  R893      1.5669887885451317e-02
    z[2,1,2]  R894      -1.3559582829475403e-01
    z[2,1,2]  R895      3.2131153345108032e-01
    z[2,1,2]  R896      1.6175954043865204e-01
    z[2,1,2]  R897      -2.2412294149398804e-01
    z[2,1,2]  R898      -2.1871482953429222e-02
    z[2,1,2]  R899      -1.3139431178569794e-01
    z[2,1,2]  R900      3.3440402150154114e-01
    z[2,1,2]  R901      2.8118276596069336e-01
    z[2,1,2]  R902      2.7220770716667175e-01
    z[2,1,2]  R903      3.5450032353401184e-01
    z[2,1,2]  R904      1.0474268347024918e-02
    z[2,1,2]  R905      9.4537794589996338e-02
    z[2,1,2]  R906      2.2170089185237885e-01
    z[2,1,2]  R907      -1.0814710706472397e-01
    z[2,1,2]  R908      -2.5182211399078369e-01
    z[2,1,2]  R909      3.7095537781715393e-01
    z[2,1,2]  R910      4.8485729098320007e-01
    z[2,1,2]  R911      0.391141802072525
    z[2,1,2]  R912      -2.6335790753364563e-01
    z[2,1,2]  R913      4.1815541684627533e-02
    z[2,1,2]  R914      2.2154621779918671e-02
    z[2,1,2]  R915      3.6627537012100220e-01
    z[2,1,2]  R916      4.9212306737899780e-01
    z[2,1,2]  R917      3.5707566142082214e-01
    z[2,1,2]  R918      2.6747745275497437e-01
    z[2,1,2]  R919      -1.8532557412981987e-02
    z[2,1,2]  R920      1.9488810002803802e-01
    z[2,1,2]  R921      1.8859108909964561e-02
    z[2,1,2]  R922      -5.3550285100936890e-01
    z[2,1,2]  R923      -2.4048466980457306e-01
    z[2,1,2]  R924      0.082611583173275
    z[2,1,2]  R925      -8.9654371142387390e-02
    z[2,1,2]  R926      -2.1137490868568420e-01
    z[2,1,2]  R927      -1.7876550555229187e-01
    z[2,1,2]  R928      -2.6982340216636658e-01
    z[2,1,2]  R929      -1.9752517342567444e-01
    z[2,1,2]  R930      -1.1177732609212399e-02
    z[2,1,2]  R931      -1.0844890773296356e-01
    z[2,1,2]  R932      -5.7923197746276855e-01
    z[2,1,2]  R933      -5.9258836507797241e-01
    z[2,1,2]  R934      1.4884649217128754e-01
    z[2,1,2]  R935      -4.0928909182548523e-01
    z[2,1,2]  R936      -4.7487002611160278e-01
    z[2,1,2]  R937      1.0943194478750229e-01
    z[2,1,2]  R938      8.5958667099475861e-02
    z[2,1,2]  R939      -0.606873631477356
    z[2,1,2]  R940      1.0186557471752167e-01
    z[2,1,2]  R941      0.625761091709137
    z[2,1,2]  R942      -4.5682549476623535e-01
    z[2,1,2]  R943      -8.2836419343948364e-02
    z[2,1,2]  R944      -5.4207291454076767e-02
    z[2,1,2]  R945      2.7874214574694633e-02
    z[2,1,2]  R946      -4.2019593715667725e-01
    z[2,1,2]  R947      -1.3303663581609726e-02
    z[2,1,2]  R948      2.0317737758159637e-01
    z[2,1,2]  R949      8.1217640638351440e-01
    z[2,1,2]  R950      -3.9600688964128494e-02
    z[2,1,2]  R951      -3.3364436030387878e-01
    z[2,1,2]  R952      -7.4472390115261078e-02
    z[2,1,2]  R953      -2.9672920703887939e-01
    z[2,1,2]  R954      -4.3127492070198059e-01
    z[2,1,2]  R955      1.4311423897743225e-01
    z[2,1,2]  R956      -1.0728116333484650e-01
    z[2,1,2]  R957      -2.1686401963233948e-01
    z[2,1,2]  R958      3.9321917295455933e-01
    z[2,1,2]  R959      4.4646185636520386e-01
    z[2,1,2]  R960      -3.7101346254348755e-01
    z[2,1,2]  R961      1.4247593283653259e-01
    z[2,1,2]  R962      1.7765846848487854e-01
    z[2,1,2]  R963      -1.4813593029975891e-01
    z[2,1,2]  R964      -6.0631740838289261e-02
    z[2,1,2]  R965      7.0911563932895660e-02
    z[2,1,2]  R966      -2.7264159917831421e-01
    z[2,1,2]  R967      -2.3721061646938324e-01
    z[2,1,2]  R968      -1.1788218468427658e-01
    z[2,1,2]  R969      -3.7549829483032227e-01
    z[2,1,2]  R970      -1.2550555169582367e-01
    z[2,1,2]  R971      -1.3326528668403625e-01
    z[2,1,2]  R972      -6.1995391733944416e-03
    z[2,1,2]  R973      3.1355914473533630e-01
    z[2,1,2]  R974      -4.0524119138717651e-01
    z[2,1,2]  R975      1.9952647387981415e-01
    z[2,1,2]  R976      2.5198289752006531e-01
    z[2,1,2]  R977      -6.6592156887054443e-02
    z[2,1,2]  R978      -2.0460438728332520e-01
    z[2,1,2]  R979      1.0704782605171204e-01
    z[2,1,2]  R980      1.3273303396999836e-02
    z[2,1,2]  R981      1.6280081868171692e-01
    z[2,1,2]  R982      1.9041393697261810e-01
    z[2,1,2]  R983      7.0002920925617218e-02
    z[2,1,2]  R984      -2.6101595163345337e-01
    z[2,1,2]  R985      7.1109563112258911e-02
    z[2,1,2]  R986      1.5195743739604950e-01
    z[2,1,2]  R987      -9.9591560661792755e-02
    z[2,1,2]  R988      4.1462087631225586e-01
    z[2,1,2]  R989      -3.3298179507255554e-01
    z[2,1,2]  R990      4.3960276991128922e-02
    z[2,1,2]  R991      -4.0967562235891819e-03
    z[2,1,2]  R992      1.4690834283828735e-01
    z[2,1,2]  R993      7.8408278524875641e-02
    z[2,1,2]  R994      9.3858368694782257e-02
    z[2,1,2]  R995      1.6618616878986359e-01
    z[2,1,2]  R996      2.0638216286897659e-02
    z[2,1,2]  R997      1.9519396126270294e-01
    z[2,1,2]  R998      9.6629597246646881e-02
    z[2,1,2]  R999      2.1174415946006775e-01
    z[2,1,2]  R1000     5.1338362693786621e-01
    z[2,1,2]  R1001     7.7930486202239990e-01
    z[2,1,3]  R14       1
    z[2,1,3]  R23       -1
    z[2,1,3]  R884      -1
    z[2,1,3]  R885      1
    z[2,1,3]  R892      -4.9738347530364990e-01
    z[2,1,3]  R893      -4.9407455325126648e-01
    z[2,1,3]  R894      -3.8313293457031250e-01
    z[2,1,3]  R895      -6.3725954294204712e-01
    z[2,1,3]  R896      -3.1108251214027405e-01
    z[2,1,3]  R897      -3.7824982404708862e-01
    z[2,1,3]  R898      -3.9815476536750793e-01
    z[2,1,3]  R899      -3.7539014220237732e-01
    z[2,1,3]  R900      -6.8444848060607910e-01
    z[2,1,3]  R901      -4.8272785544395447e-01
    z[2,1,3]  R902      4.8311153054237366e-01
    z[2,1,3]  R903      5.9779763221740723e-01
    z[2,1,3]  R904      6.4269524812698364e-01
    z[2,1,3]  R905      6.1657619476318359e-01
    z[2,1,3]  R906      3.2699123024940491e-01
    z[2,1,3]  R907      5.1298719644546509e-01
    z[2,1,3]  R908      4.0008780360221863e-01
    z[2,1,3]  R909      6.0585594177246094e-01
    z[2,1,3]  R910      3.9594307541847229e-01
    z[2,1,3]  R911      4.2353931069374084e-01
    z[2,1,3]  R912      -4.3787723779678345e-01
    z[2,1,3]  R913      5.4378788918256760e-02
    z[2,1,3]  R914      4.1932079195976257e-01
    z[2,1,3]  R915      -2.0981330424547195e-02
    z[2,1,3]  R916      -1.5364332357421517e-03
    z[2,1,3]  R917      1.3689659535884857e-01
    z[2,1,3]  R918      -9.2429459095001221e-02
    z[2,1,3]  R919      -3.2372960448265076e-01
    z[2,1,3]  R920      -1.2386822700500488e-01
    z[2,1,3]  R921      3.1529575586318970e-01
    z[2,1,3]  R922      2.3897531628608704e-01
    z[2,1,3]  R923      -3.3361229300498962e-01
    z[2,1,3]  R924      -0.145788311958313
    z[2,1,3]  R925      -1.4089332520961761e-01
    z[2,1,3]  R926      2.6580068469047546e-01
    z[2,1,3]  R927      2.7467063069343567e-01
    z[2,1,3]  R928      3.5498273372650146e-01
    z[2,1,3]  R929      -3.6747679114341736e-02
    z[2,1,3]  R930      4.0764799714088440e-01
    z[2,1,3]  R931      5.6897927075624466e-02
    z[2,1,3]  R932      -4.8815658688545227e-01
    z[2,1,3]  R933      -7.2577714920043945e-01
    z[2,1,3]  R934      2.6660218834877014e-01
    z[2,1,3]  R935      2.3126375675201416e-01
    z[2,1,3]  R936      5.9364604949951172e-01
    z[2,1,3]  R937      -1.8681989610195160e-01
    z[2,1,3]  R938      -4.3784928321838379e-01
    z[2,1,3]  R939      -1.2139679491519928e-01
    z[2,1,3]  R940      -2.9585435986518860e-02
    z[2,1,3]  R941      -3.0198785662651062e-01
    z[2,1,3]  R942      -5.2362877130508423e-01
    z[2,1,3]  R943      9.5383845269680023e-02
    z[2,1,3]  R944      1.9987209141254425e-01
    z[2,1,3]  R945      1.3164575397968292e-01
    z[2,1,3]  R946      4.9316713213920593e-01
    z[2,1,3]  R947      1.6954675316810608e-02
    z[2,1,3]  R948      -2.6575639843940735e-01
    z[2,1,3]  R949      -1.7028152942657471e-01
    z[2,1,3]  R950      -5.0227010250091553e-01
    z[2,1,3]  R951      -2.0487660169601440e-01
    z[2,1,3]  R952      -5.2006644010543823e-01
    z[2,1,3]  R953      0.206911101937294
    z[2,1,3]  R954      8.8795311748981476e-02
    z[2,1,3]  R955      3.2202258706092834e-01
    z[2,1,3]  R956      -0.298666775226593
    z[2,1,3]  R957      1.9712407886981964e-01
    z[2,1,3]  R958      3.5539147257804871e-01
    z[2,1,3]  R959      4.5797824859619141e-01
    z[2,1,3]  R960      4.5064017176628113e-01
    z[2,1,3]  R961      0.621365487575531
    z[2,1,3]  R962      -5.2714014053344727e-01
    z[2,1,3]  R963      -1.7141684889793396e-01
    z[2,1,3]  R964      -2.4051589891314507e-02
    z[2,1,3]  R965      -5.9793466329574585e-01
    z[2,1,3]  R966      -4.6273627877235413e-01
    z[2,1,3]  R967      -2.2545909881591797e-01
    z[2,1,3]  R968      -3.8147419691085815e-01
    z[2,1,3]  R969      -5.8227157592773438e-01
    z[2,1,3]  R970      -2.6461067795753479e-01
    z[2,1,3]  R971      -3.9880636334419250e-01
    z[2,1,3]  R972      -1.2796452641487122e-01
    z[2,1,3]  R973      2.8310397267341614e-01
    z[2,1,3]  R974      2.4331583082675934e-01
    z[2,1,3]  R975      7.2456523776054382e-02
    z[2,1,3]  R976      4.0017911791801453e-01
    z[2,1,3]  R977      3.2510197162628174e-01
    z[2,1,3]  R978      1.0274247825145721e-01
    z[2,1,3]  R979      4.3138790130615234e-01
    z[2,1,3]  R980      6.0794878005981445e-01
    z[2,1,3]  R981      2.7000385522842407e-01
    z[2,1,3]  R982      -2.2122806310653687e-01
    z[2,1,3]  R983      -2.4943706393241882e-01
    z[2,1,3]  R984      3.1544142961502075e-01
    z[2,1,3]  R985      2.4635457992553711e-01
    z[2,1,3]  R986      -4.2376585304737091e-02
    z[2,1,3]  R987      5.2524778991937637e-02
    z[2,1,3]  R988      -1.5484818816184998e-01
    z[2,1,3]  R989      1.7375695705413818e-01
    z[2,1,3]  R990      2.9080143570899963e-01
    z[2,1,3]  R991      2.5139921903610229e-01
    z[2,1,3]  R992      -5.9669923782348633e-01
    z[2,1,3]  R993      -0.152748703956604
    z[2,1,3]  R994      -3.1927478313446045e-01
    z[2,1,3]  R995      7.5129017233848572e-02
    z[2,1,3]  R996      -6.4138539135456085e-02
    z[2,1,3]  R997      -3.1122544407844543e-01
    z[2,1,3]  R998      3.1744691729545593e-01
    z[2,1,3]  R999      -4.7472648322582245e-02
    z[2,1,3]  R1000     0.641027569770813
    z[2,1,3]  R1001     4.1837012767791748e-01
    z[2,1,4]  R15       1
    z[2,1,4]  R24       -1
    z[2,1,4]  R886      -1
    z[2,1,4]  R887      1
    z[2,1,4]  R892      7.4108898639678955e-02
    z[2,1,4]  R893      4.5411086082458496e-01
    z[2,1,4]  R894      -7.7939257025718689e-02
    z[2,1,4]  R895      2.5241702795028687e-02
    z[2,1,4]  R896      -3.1280061602592468e-01
    z[2,1,4]  R897      -0.197514608502388
    z[2,1,4]  R898      1.8651725351810455e-01
    z[2,1,4]  R899      3.4524840116500854e-01
    z[2,1,4]  R900      -2.2133202850818634e-01
    z[2,1,4]  R901      -9.4200141727924347e-02
    z[2,1,4]  R902      2.0341378450393677e-01
    z[2,1,4]  R903      8.9632213115692139e-02
    z[2,1,4]  R904      2.4004580453038216e-02
    z[2,1,4]  R905      2.9950913786888123e-01
    z[2,1,4]  R906      2.2722056508064270e-01
    z[2,1,4]  R907      -2.3124359548091888e-01
    z[2,1,4]  R908      4.8136554658412933e-02
    z[2,1,4]  R909      5.7331800460815430e-02
    z[2,1,4]  R910      -2.1913222968578339e-01
    z[2,1,4]  R911      5.3543031215667725e-01
    z[2,1,4]  R912      -2.0215612649917603e-01
    z[2,1,4]  R913      3.6794430017471313e-01
    z[2,1,4]  R914      -2.8205132484436035e-01
    z[2,1,4]  R915      -8.9348025619983673e-02
    z[2,1,4]  R916      2.6865644380450249e-02
    z[2,1,4]  R917      -1.1009267531335354e-02
    z[2,1,4]  R918      3.2222609966993332e-02
    z[2,1,4]  R919      -8.0519765615463257e-02
    z[2,1,4]  R920      3.7069308757781982e-01
    z[2,1,4]  R921      1.7405509948730469e-01
    z[2,1,4]  R922      3.0431419610977173e-01
    z[2,1,4]  R923      -8.5079200565814972e-02
    z[2,1,4]  R924      7.2199290990829468e-01
    z[2,1,4]  R925      3.3194559812545776e-01
    z[2,1,4]  R926      1.6605427861213684e-01
    z[2,1,4]  R927      1.8416607752442360e-02
    z[2,1,4]  R928      -2.2175459563732147e-01
    z[2,1,4]  R929      4.2684939503669739e-01
    z[2,1,4]  R930      -2.6789689064025879e-01
    z[2,1,4]  R931      3.8038060069084167e-01
    z[2,1,4]  R932      -3.3481433987617493e-01
    z[2,1,4]  R933      -2.6730507612228394e-02
    z[2,1,4]  R934      -7.6060421764850616e-02
    z[2,1,4]  R935      4.3052637577056885e-01
    z[2,1,4]  R936      3.3167313784360886e-02
    z[2,1,4]  R937      3.9344325661659241e-01
    z[2,1,4]  R938      1.6735710203647614e-01
    z[2,1,4]  R939      1.4674863219261169e-01
    z[2,1,4]  R940      1.9643607735633850e-01
    z[2,1,4]  R941      2.4451376497745514e-01
    z[2,1,4]  R942      -2.8217095136642456e-01
    z[2,1,4]  R943      4.3291813135147095e-01
    z[2,1,4]  R944      6.5028005838394165e-01
    z[2,1,4]  R945      -6.1785720288753510e-02
    z[2,1,4]  R946      2.3512113094329834e-01
    z[2,1,4]  R947      -6.0237981379032135e-02
    z[2,1,4]  R948      8.2637047767639160e-01
    z[2,1,4]  R949      6.9821491837501526e-02
    z[2,1,4]  R950      7.6107615232467651e-01
    z[2,1,4]  R951      6.2636291980743408e-01
    z[2,1,4]  R952      6.4324772357940674e-01
    z[2,1,4]  R953      3.2327157258987427e-01
    z[2,1,4]  R954      1.6144491732120514e-01
    z[2,1,4]  R955      5.3124237060546875e-01
    z[2,1,4]  R956      7.2016930580139160e-01
    z[2,1,4]  R957      -1.0330962389707565e-01
    z[2,1,4]  R958      1.6766072809696198e-01
    z[2,1,4]  R959      5.5407159030437469e-02
    z[2,1,4]  R960      -4.9126887321472168e-01
    z[2,1,4]  R961      4.8064431548118591e-01
    z[2,1,4]  R962      -7.4473358690738678e-02
    z[2,1,4]  R963      3.5818558186292648e-02
    z[2,1,4]  R964      -1.9742001593112946e-01
    z[2,1,4]  R965      3.3438715338706970e-01
    z[2,1,4]  R966      -0.207333505153656
    z[2,1,4]  R967      -1.1061331629753113e-01
    z[2,1,4]  R968      -0.0686548575758934
    z[2,1,4]  R969      2.1860344707965851e-01
    z[2,1,4]  R970      -6.0606843233108521e-01
    z[2,1,4]  R971      -4.0920057892799377e-01
    z[2,1,4]  R972      -2.6890264824032784e-02
    z[2,1,4]  R973      -2.5274107232689857e-02
    z[2,1,4]  R974      2.0200443267822266e-01
    z[2,1,4]  R975      1.1528035998344421e-01
    z[2,1,4]  R976      -3.2284778356552124e-01
    z[2,1,4]  R977      -7.9762347042560577e-02
    z[2,1,4]  R978      6.1005318164825439e-01
    z[2,1,4]  R979      1.2749303877353668e-01
    z[2,1,4]  R980      -1.8790359795093536e-01
    z[2,1,4]  R981      -5.0215828418731689e-01
    z[2,1,4]  R982      -1.1892067268490791e-02
    z[2,1,4]  R983      -6.9857522845268250e-02
    z[2,1,4]  R984      -2.5380348786711693e-02
    z[2,1,4]  R985      2.1475711464881897e-01
    z[2,1,4]  R986      3.8521581888198853e-01
    z[2,1,4]  R987      1.9272805750370026e-01
    z[2,1,4]  R988      -4.7011303901672363e-01
    z[2,1,4]  R989      6.4100092649459839e-01
    z[2,1,4]  R990      -2.9409998655319214e-01
    z[2,1,4]  R991      -7.3312622308731079e-01
    z[2,1,4]  R992      -3.9989843964576721e-01
    z[2,1,4]  R993      5.2233719825744629e-01
    z[2,1,4]  R994      0.336622953414917
    z[2,1,4]  R995      2.9592399951070547e-03
    z[2,1,4]  R996      1.1275199800729752e-01
    z[2,1,4]  R997      4.6267968416213989e-01
    z[2,1,4]  R998      -1.8894420564174652e-01
    z[2,1,4]  R999      -0.502036452293396
    z[2,1,4]  R1000     0.291445255279541
    z[2,1,4]  R1001     2.7686533331871033e-01
    z[2,1,5]  R16       1
    z[2,1,5]  R25       -1
    z[2,1,5]  R888      -1
    z[2,1,5]  R889      1
    z[2,1,5]  R892      -2.5763321667909622e-02
    z[2,1,5]  R893      1.1319072544574738e-01
    z[2,1,5]  R894      -3.2504707574844360e-01
    z[2,1,5]  R895      -5.9077125787734985e-01
    z[2,1,5]  R896      -8.5536353290081024e-02
    z[2,1,5]  R897      3.8181871175765991e-02
    z[2,1,5]  R898      -1.5665654838085175e-01
    z[2,1,5]  R899      -3.6032482981681824e-01
    z[2,1,5]  R900      4.5826286077499390e-01
    z[2,1,5]  R901      2.3778598010540009e-01
    z[2,1,5]  R902      2.3975865915417671e-02
    z[2,1,5]  R903      -1.9673697650432587e-01
    z[2,1,5]  R904      -3.9418466389179230e-02
    z[2,1,5]  R905      -1.0547454655170441e-01
    z[2,1,5]  R906      -4.1495278477668762e-01
    z[2,1,5]  R907      1.3072626292705536e-01
    z[2,1,5]  R908      -2.0526649057865143e-01
    z[2,1,5]  R909      -2.4558408558368683e-01
    z[2,1,5]  R910      -1.0090753436088562e-01
    z[2,1,5]  R911      -1.0786123573780060e-01
    z[2,1,5]  R912      -2.7562916278839111e-01
    z[2,1,5]  R913      0.073304183781147
    z[2,1,5]  R914      0.0922246053814888
    z[2,1,5]  R915      4.6109721064567566e-01
    z[2,1,5]  R916      1.2221264094114304e-01
    z[2,1,5]  R917      3.6499887704849243e-01
    z[2,1,5]  R918      -3.2317012548446655e-01
    z[2,1,5]  R919      7.0836436934769154e-03
    z[2,1,5]  R920      1.2804001569747925e-01
    z[2,1,5]  R921      5.4895699024200439e-01
    z[2,1,5]  R922      2.7236780524253845e-01
    z[2,1,5]  R923      -1.2452408671379089e-01
    z[2,1,5]  R924      -6.5301053225994110e-02
    z[2,1,5]  R925      4.3510493636131287e-01
    z[2,1,5]  R926      -5.7376161217689514e-02
    z[2,1,5]  R927      -1.8761390447616577e-01
    z[2,1,5]  R928      -5.1306881010532379e-02
    z[2,1,5]  R929      -3.3381082117557526e-02
    z[2,1,5]  R930      -1.3989751040935516e-01
    z[2,1,5]  R931      7.0005212910473347e-03
    z[2,1,5]  R932      -3.5425817966461182e-01
    z[2,1,5]  R933      2.6494054123759270e-02
    z[2,1,5]  R934      4.0824812650680542e-01
    z[2,1,5]  R935      1.4948236942291260e-01
    z[2,1,5]  R936      -3.0073684453964233e-01
    z[2,1,5]  R937      -1.9144824147224426e-01
    z[2,1,5]  R938      2.0868784189224243e-01
    z[2,1,5]  R939      -1.5906600281596184e-02
    z[2,1,5]  R940      -2.2126603126525879e-01
    z[2,1,5]  R941      4.2481872439384460e-01
    z[2,1,5]  R942      -2.1682459115982056e-01
    z[2,1,5]  R943      -2.3186743259429932e-01
    z[2,1,5]  R944      1.1061707139015198e-01
    z[2,1,5]  R945      1.7542797327041626e-01
    z[2,1,5]  R946      -3.1311661005020142e-01
    z[2,1,5]  R947      -2.8522959351539612e-01
    z[2,1,5]  R948      3.5395030863583088e-03
    z[2,1,5]  R949      2.9308724403381348e-01
    z[2,1,5]  R950      1.7048075795173645e-02
    z[2,1,5]  R951      -3.4903664141893387e-02
    z[2,1,5]  R952      1.9971325993537903e-01
    z[2,1,5]  R953      0.141094371676445
    z[2,1,5]  R954      2.4412022903561592e-02
    z[2,1,5]  R955      3.5019564628601074e-01
    z[2,1,5]  R956      2.1683631464838982e-02
    z[2,1,5]  R957      1.0498115420341492e-01
    z[2,1,5]  R958      6.6231940872967243e-03
    z[2,1,5]  R959      -2.3655049502849579e-01
    z[2,1,5]  R960      -0.504997730255127
    z[2,1,5]  R961      -2.6477809995412827e-02
    z[2,1,5]  R962      -4.2726588249206543e-01
    z[2,1,5]  R963      -4.4893521070480347e-01
    z[2,1,5]  R964      -1.9430667161941528e-01
    z[2,1,5]  R965      1.8883095681667328e-01
    z[2,1,5]  R966      -3.1816062331199646e-01
    z[2,1,5]  R967      3.5657492280006409e-01
    z[2,1,5]  R968      -0.413128525018692
    z[2,1,5]  R969      0.0798230916261673
    z[2,1,5]  R970      -5.1094375550746918e-02
    z[2,1,5]  R971      1.0263931751251221e-01
    z[2,1,5]  R972      3.4040069580078125e-01
    z[2,1,5]  R973      9.6004633232951164e-03
    z[2,1,5]  R974      2.4548135697841644e-01
    z[2,1,5]  R975      3.8709971308708191e-01
    z[2,1,5]  R976      3.2117941975593567e-01
    z[2,1,5]  R977      4.8737379908561707e-01
    z[2,1,5]  R978      3.2575258612632751e-01
    z[2,1,5]  R979      3.6358457803726196e-01
    z[2,1,5]  R980      2.8527006506919861e-01
    z[2,1,5]  R981      1.6940513253211975e-01
    z[2,1,5]  R982      5.3804576396942139e-01
    z[2,1,5]  R983      4.4933566451072693e-01
    z[2,1,5]  R984      3.4121209383010864e-01
    z[2,1,5]  R985      2.7260869741439819e-01
    z[2,1,5]  R986      -1.8417501449584961e-01
    z[2,1,5]  R987      -4.8523122072219849e-01
    z[2,1,5]  R988      -5.0318732857704163e-02
    z[2,1,5]  R989      -5.4362822324037552e-02
    z[2,1,5]  R990      -5.0268638134002686e-01
    z[2,1,5]  R991      -9.4509720802307129e-02
    z[2,1,5]  R992      6.2728708982467651e-01
    z[2,1,5]  R993      -8.9115977287292480e-02
    z[2,1,5]  R994      -1.9698626419994980e-04
    z[2,1,5]  R995      4.9155500531196594e-01
    z[2,1,5]  R996      1.5471910126507282e-02
    z[2,1,5]  R997      7.5048275291919708e-02
    z[2,1,5]  R998      -6.8633213639259338e-02
    z[2,1,5]  R999      -9.3955181539058685e-02
    z[2,1,5]  R1000     2.3310044407844543e-01
    z[2,1,5]  R1001     9.1374032199382782e-02
    z[2,1,6]  R17       1
    z[2,1,6]  R26       -1
    z[2,1,6]  R890      -1
    z[2,1,6]  R891      1
    z[2,1,6]  R892      -5.2041497081518173e-02
    z[2,1,6]  R893      2.6563179492950439e-01
    z[2,1,6]  R894      1.2247455865144730e-01
    z[2,1,6]  R895      -2.9744941741228104e-02
    z[2,1,6]  R896      -1.7013169825077057e-01
    z[2,1,6]  R897      -3.5226354002952576e-01
    z[2,1,6]  R898      -3.1037840247154236e-01
    z[2,1,6]  R899      -2.2379522025585175e-01
    z[2,1,6]  R900      4.9815565347671509e-02
    z[2,1,6]  R901      6.5397346019744873e-01
    z[2,1,6]  R902      1.7376956343650818e-01
    z[2,1,6]  R903      3.9379266090691090e-03
    z[2,1,6]  R904      8.5842885076999664e-02
    z[2,1,6]  R905      5.0171691924333572e-02
    z[2,1,6]  R906      -2.0933536812663078e-02
    z[2,1,6]  R907      -5.0253149121999741e-02
    z[2,1,6]  R908      2.9349419474601746e-01
    z[2,1,6]  R909      2.8682306408882141e-01
    z[2,1,6]  R910      -1.9491675496101379e-01
    z[2,1,6]  R911      -3.3388055860996246e-02
    z[2,1,6]  R912      -1.3035708665847778e-01
    z[2,1,6]  R913      -3.4366950392723083e-01
    z[2,1,6]  R914      9.2071019113063812e-02
    z[2,1,6]  R915      -1.1393783241510391e-01
    z[2,1,6]  R916      8.2571931183338165e-02
    z[2,1,6]  R917      -3.6306026577949524e-01
    z[2,1,6]  R918      8.3058521151542664e-02
    z[2,1,6]  R919      1.4299200847744942e-02
    z[2,1,6]  R920      4.2816221714019775e-01
    z[2,1,6]  R921      3.4252646565437317e-01
    z[2,1,6]  R922      -1.8468311429023743e-01
    z[2,1,6]  R923      -4.3246969580650330e-01
    z[2,1,6]  R924      6.2741570174694061e-02
    z[2,1,6]  R925      -5.8201032876968384e-01
    z[2,1,6]  R926      1.0211148113012314e-01
    z[2,1,6]  R927      -2.6464468240737915e-01
    z[2,1,6]  R928      5.3623810410499573e-02
    z[2,1,6]  R929      4.9583610892295837e-01
    z[2,1,6]  R930      1.6540125012397766e-01
    z[2,1,6]  R931      -2.4010688066482544e-01
    z[2,1,6]  R932      3.7758362293243408e-01
    z[2,1,6]  R933      -3.3995591104030609e-02
    z[2,1,6]  R934      2.4440832436084747e-01
    z[2,1,6]  R935      2.2488673031330109e-01
    z[2,1,6]  R936      1.7554501071572304e-02
    z[2,1,6]  R937      -5.4029554128646851e-01
    z[2,1,6]  R938      -2.1544055640697479e-01
    z[2,1,6]  R939      -4.4490674138069153e-01
    z[2,1,6]  R940      5.8592408895492554e-01
    z[2,1,6]  R941      -4.2189598083496094e-02
    z[2,1,6]  R942      0.26277956366539
    z[2,1,6]  R943      -1.5819574892520905e-01
    z[2,1,6]  R944      6.4440146088600159e-02
    z[2,1,6]  R945      -0.503376841545105
    z[2,1,6]  R946      9.5405891537666321e-02
    z[2,1,6]  R947      5.3170013427734375e-01
    z[2,1,6]  R948      -3.4733593463897705e-01
    z[2,1,6]  R949      1.4525157213211060e-01
    z[2,1,6]  R950      -1.4669755101203918e-01
    z[2,1,6]  R951      -3.0108600854873657e-01
    z[2,1,6]  R952      -2.6337680220603943e-01
    z[2,1,6]  R953      -1.4485427737236023e-01
    z[2,1,6]  R954      4.2245812714099884e-02
    z[2,1,6]  R955      8.5663706064224243e-02
    z[2,1,6]  R956      -1.1631070822477341e-01
    z[2,1,6]  R957      1.2773084640502930e-01
    z[2,1,6]  R958      1.3055829703807831e-01
    z[2,1,6]  R959      -1.3799254596233368e-01
    z[2,1,6]  R960      -3.9727625250816345e-01
    z[2,1,6]  R961      -1.6255301237106323e-01
    z[2,1,6]  R962      -8.4079019725322723e-02
    z[2,1,6]  R963      3.4917865414172411e-03
    z[2,1,6]  R964      9.3952931463718414e-02
    z[2,1,6]  R965      -2.6736435294151306e-01
    z[2,1,6]  R966      5.2625524997711182e-01
    z[2,1,6]  R967      -8.1423139199614525e-03
    z[2,1,6]  R968      2.3798566311597824e-02
    z[2,1,6]  R969      4.5384612679481506e-01
    z[2,1,6]  R970      2.9452082514762878e-01
    z[2,1,6]  R971      5.3818774223327637e-01
    z[2,1,6]  R972      2.4685344099998474e-01
    z[2,1,6]  R973      -2.9452103376388550e-01
    z[2,1,6]  R974      4.3733417987823486e-01
    z[2,1,6]  R975      -1.2433338165283203e-01
    z[2,1,6]  R976      -3.8061115145683289e-01
    z[2,1,6]  R977      0.0547383613884449
    z[2,1,6]  R978      1.0755355656147003e-01
    z[2,1,6]  R979      0.0466521717607975
    z[2,1,6]  R980      -0.074155293405056
    z[2,1,6]  R981      1.6571673750877380e-01
    z[2,1,6]  R982      1.4408499002456665e-02
    z[2,1,6]  R983      -1.2025839835405350e-01
    z[2,1,6]  R984      5.1061216741800308e-02
    z[2,1,6]  R985      -1.9564969837665558e-01
    z[2,1,6]  R986      8.6739897727966309e-02
    z[2,1,6]  R987      3.4491127729415894e-01
    z[2,1,6]  R988      -5.8239664882421494e-02
    z[2,1,6]  R989      4.4052168726921082e-02
    z[2,1,6]  R990      1.7404365539550781e-01
    z[2,1,6]  R991      2.4868105351924896e-01
    z[2,1,6]  R992      -2.5180861353874207e-02
    z[2,1,6]  R993      7.3525518178939819e-02
    z[2,1,6]  R994      2.1956019103527069e-01
    z[2,1,6]  R995      -2.2008366882801056e-01
    z[2,1,6]  R996      1.4444258809089661e-01
    z[2,1,6]  R997      -2.2445949912071228e-01
    z[2,1,6]  R998      -1.0294097661972046e-01
    z[2,1,6]  R999      1.2430543079972267e-02
    z[2,1,6]  R1000     -2.4548610672354698e-02
    z[2,1,6]  R1001     -1.1802790313959122e-01
    z[1,5,0]  R11       -1
    z[1,5,0]  R47       1
    z[1,5,0]  R1002     -1
    z[1,5,0]  R1003     1
    z[1,5,0]  R1016     1.0424977540969849e-01
    z[1,5,0]  R1017     4.5252549648284912e-01
    z[1,5,0]  R1018     0.0661509558558464
    z[1,5,0]  R1019     2.8299051523208618e-01
    z[1,5,0]  R1020     1.2149226665496826e-01
    z[1,5,0]  R1021     0.612120509147644
    z[1,5,0]  R1022     6.7033219337463379e-01
    z[1,5,0]  R1023     1.5490005910396576e-01
    z[1,5,0]  R1024     2.8226104378700256e-01
    z[1,5,0]  R1025     -2.4477690458297729e-01
    z[1,5,0]  R1026     -3.3862102031707764e-01
    z[1,5,0]  R1027     -2.5495833158493042e-01
    z[1,5,0]  R1028     -8.7855964899063110e-02
    z[1,5,0]  R1029     -3.8494125008583069e-01
    z[1,5,0]  R1030     9.0316146612167358e-02
    z[1,5,0]  R1031     -1.0013429075479507e-01
    z[1,5,0]  R1032     -2.1069069206714630e-01
    z[1,5,0]  R1033     -2.3835390806198120e-01
    z[1,5,0]  R1034     -8.9270561933517456e-02
    z[1,5,0]  R1035     -1.3217581808567047e-01
    z[1,5,0]  R1036     -5.6992095708847046e-01
    z[1,5,0]  R1037     2.1340602636337280e-01
    z[1,5,0]  R1038     3.7517610192298889e-01
    z[1,5,0]  R1039     -7.1401357650756836e-02
    z[1,5,0]  R1040     -1.5552681684494019e-01
    z[1,5,0]  R1041     -3.3658319711685181e-01
    z[1,5,0]  R1042     -3.7117803096771240e-01
    z[1,5,0]  R1043     2.5435557961463928e-01
    z[1,5,0]  R1044     -1.4337022602558136e-01
    z[1,5,0]  R1045     3.9398744702339172e-02
    z[1,5,0]  R1046     1.0379552096128464e-01
    z[1,5,0]  R1047     -6.4998644590377808e-01
    z[1,5,0]  R1048     -7.4237370491027832e-01
    z[1,5,0]  R1049     -0.0773012712597847
    z[1,5,0]  R1050     -0.246307834982872
    z[1,5,0]  R1051     -1.4701296389102936e-01
    z[1,5,0]  R1052     4.7910723835229874e-02
    z[1,5,0]  R1053     -1.6824087128043175e-02
    z[1,5,0]  R1054     3.1259888410568237e-01
    z[1,5,0]  R1055     1.6191582381725311e-01
    z[1,5,0]  R1056     6.4572030305862427e-01
    z[1,5,0]  R1057     5.9248942136764526e-01
    z[1,5,0]  R1058     7.7949911355972290e-01
    z[1,5,0]  R1059     4.3592220544815063e-01
    z[1,5,0]  R1060     7.5880461931228638e-01
    z[1,5,0]  R1061     0.639691948890686
    z[1,5,0]  R1062     5.3148925304412842e-01
    z[1,5,0]  R1063     2.0234270393848419e-01
    z[1,5,0]  R1064     4.5358395576477051e-01
    z[1,5,0]  R1065     1.1968953907489777e-01
    z[1,5,0]  R1066     -4.3323707580566406e-01
    z[1,5,0]  R1067     2.5212273001670837e-01
    z[1,5,0]  R1068     2.6298072934150696e-01
    z[1,5,0]  R1069     1.1024408787488937e-01
    z[1,5,0]  R1070     -5.2712941169738770e-01
    z[1,5,0]  R1071     0.0764106810092926
    z[1,5,0]  R1072     1.2938044965267181e-01
    z[1,5,0]  R1073     1.4818756282329559e-01
    z[1,5,0]  R1074     1.3261912763118744e-01
    z[1,5,0]  R1075     0.0923101156949997
    z[1,5,0]  R1076     2.6949477195739746e-01
    z[1,5,0]  R1077     -6.9175457954406738e-01
    z[1,5,0]  R1078     -8.6974817514419556e-01
    z[1,5,0]  R1079     2.7312484383583069e-01
    z[1,5,0]  R1080     -8.7619078159332275e-01
    z[1,5,0]  R1081     -0.76837557554245
    z[1,5,0]  R1082     -8.9575308561325073e-01
    z[1,5,0]  R1083     3.4537902474403381e-01
    z[1,5,0]  R1084     -8.8181060552597046e-01
    z[1,5,0]  R1085     -7.6651340723037720e-01
    z[1,5,0]  R1086     2.6273876428604126e-01
    z[1,5,0]  R1087     2.1442225202918053e-02
    z[1,5,0]  R1088     -5.0709646940231323e-01
    z[1,5,0]  R1089     -6.8957008421421051e-02
    z[1,5,0]  R1090     -6.5651647746562958e-02
    z[1,5,0]  R1091     -0.276305615901947
    z[1,5,0]  R1092     4.8680922389030457e-01
    z[1,5,0]  R1093     -1.8024887144565582e-01
    z[1,5,0]  R1094     -9.4130545854568481e-02
    z[1,5,0]  R1095     3.1457754969596863e-01
    z[1,5,0]  R1096     4.1230636835098267e-01
    z[1,5,0]  R1097     -2.1953971683979034e-01
    z[1,5,0]  R1098     -6.0983443260192871e-01
    z[1,5,0]  R1099     1.5954670310020447e-01
    z[1,5,0]  R1100     -8.1131941080093384e-01
    z[1,5,0]  R1101     6.5042026340961456e-02
    z[1,5,0]  R1102     -8.1532442569732666e-01
    z[1,5,0]  R1103     -7.0960956811904907e-01
    z[1,5,0]  R1104     0.0046690390445292
    z[1,5,0]  R1105     -7.8674578666687012e-01
    z[1,5,0]  R1106     3.9653930068016052e-01
    z[1,5,0]  R1107     -2.1907810121774673e-02
    z[1,5,0]  R1108     -2.9042005538940430e-01
    z[1,5,0]  R1109     2.8162726759910583e-01
    z[1,5,0]  R1110     -8.9192312955856323e-01
    z[1,5,0]  R1111     -3.7026621401309967e-02
    z[1,5,0]  R1112     -8.2801800966262817e-01
    z[1,5,0]  R1113     -8.0668920278549194e-01
    z[1,5,0]  R1114     -0.774544894695282
    z[1,5,0]  R1115     -1.6462604701519012e-01
    z[1,5,0]  R1116     1.5975052118301392e-01
    z[1,5,0]  R1117     -1.0059801489114761e-01
    z[1,5,0]  R1118     -1.3567447662353516e-01
    z[1,5,0]  R1119     2.2019736468791962e-01
    z[1,5,0]  R1120     3.0585357546806335e-01
    z[1,5,0]  R1121     -8.1261835992336273e-02
    z[1,5,0]  R1122     -4.8062843084335327e-01
    z[1,5,0]  R1123     0.339558869600296
    z[1,5,0]  R1124     4.1992641985416412e-02
    z[1,5,0]  R1125     9.0691335499286652e-02
    z[1,5,0]  R1126     2.0195426046848297e-01
    z[1,5,0]  R1127     -4.5795783400535583e-01
    z[1,5,0]  R1128     -5.0490312278270721e-02
    z[1,5,0]  R1129     -8.3322483301162720e-01
    z[1,5,0]  R1130     -3.7403514981269836e-01
    z[1,5,0]  R1131     -4.0900033712387085e-01
    z[1,5,0]  R1132     8.3096392452716827e-02
    z[1,5,0]  R1133     -2.1625292301177979e-01
    z[1,5,0]  R1134     -7.3570340871810913e-01
    z[1,5,0]  R1135     -6.4198029041290283e-01
    z[1,5,1]  R12       -1
    z[1,5,1]  R48       1
    z[1,5,1]  R1004     -1
    z[1,5,1]  R1005     1
    z[1,5,1]  R1016     -0.696075439453125
    z[1,5,1]  R1017     -7.3556423187255859e-01
    z[1,5,1]  R1018     -9.5174181461334229e-01
    z[1,5,1]  R1019     -0.581727147102356
    z[1,5,1]  R1020     -5.2499836683273315e-01
    z[1,5,1]  R1021     -6.1543524265289307e-01
    z[1,5,1]  R1022     4.6398368477821350e-01
    z[1,5,1]  R1023     -4.8562464118003845e-01
    z[1,5,1]  R1024     -6.1472445726394653e-01
    z[1,5,1]  R1025     -5.4373896121978760e-01
    z[1,5,1]  R1026     8.3149868249893188e-01
    z[1,5,1]  R1027     8.1795817613601685e-01
    z[1,5,1]  R1028     0.6903116106987
    z[1,5,1]  R1029     0.792568564414978
    z[1,5,1]  R1030     0.64494389295578
    z[1,5,1]  R1031     7.9558509588241577e-01
    z[1,5,1]  R1032     6.4291751384735107e-01
    z[1,5,1]  R1033     0.771367609500885
    z[1,5,1]  R1034     7.0715421438217163e-01
    z[1,5,1]  R1035     7.5815582275390625e-01
    z[1,5,1]  R1036     -5.4785811901092529e-01
    z[1,5,1]  R1037     8.1614577770233154e-01
    z[1,5,1]  R1038     7.5626271963119507e-01
    z[1,5,1]  R1039     8.7774705886840820e-01
    z[1,5,1]  R1040     8.7240421772003174e-01
    z[1,5,1]  R1041     0.694605827331543
    z[1,5,1]  R1042     6.6287875175476074e-01
    z[1,5,1]  R1043     6.1518836021423340e-01
    z[1,5,1]  R1044     7.2351044416427612e-01
    z[1,5,1]  R1045     5.7182258367538452e-01
    z[1,5,1]  R1046     -2.3990131914615631e-01
    z[1,5,1]  R1047     -5.1171648502349854e-01
    z[1,5,1]  R1048     -4.2025437951087952e-01
    z[1,5,1]  R1049     8.1895691156387329e-01
    z[1,5,1]  R1050     9.4919794797897339e-01
    z[1,5,1]  R1051     7.5719106197357178e-01
    z[1,5,1]  R1052     9.1465157270431519e-01
    z[1,5,1]  R1053     8.3162802457809448e-01
    z[1,5,1]  R1054     -2.9651984572410583e-01
    z[1,5,1]  R1055     -3.0413705110549927e-01
    z[1,5,1]  R1056     -0.438917875289917
    z[1,5,1]  R1057     -3.9163279533386230e-01
    z[1,5,1]  R1058     -2.6016622781753540e-01
    z[1,5,1]  R1059     -3.7669035792350769e-01
    z[1,5,1]  R1060     -2.9924064874649048e-01
    z[1,5,1]  R1061     -5.9318101406097412e-01
    z[1,5,1]  R1062     -3.3125856518745422e-01
    z[1,5,1]  R1063     -3.1194382905960083e-01
    z[1,5,1]  R1064     -3.7661054730415344e-01
    z[1,5,1]  R1065     -4.1943570971488953e-01
    z[1,5,1]  R1066     -6.0823440551757812e-01
    z[1,5,1]  R1067     9.3426233530044556e-01
    z[1,5,1]  R1068     9.0262013673782349e-01
    z[1,5,1]  R1069     8.4135597944259644e-01
    z[1,5,1]  R1070     -6.0268962383270264e-01
    z[1,5,1]  R1071     9.1193181276321411e-01
    z[1,5,1]  R1072     8.6812484264373779e-01
    z[1,5,1]  R1073     0.893491804599762
    z[1,5,1]  R1074     8.6231881380081177e-01
    z[1,5,1]  R1075     8.3279460668563843e-01
    z[1,5,1]  R1076     -5.1101475954055786e-01
    z[1,5,1]  R1077     1.4255075156688690e-01
    z[1,5,1]  R1078     1.4731350541114807e-01
    z[1,5,1]  R1079     -4.5945802330970764e-01
    z[1,5,1]  R1080     1.0036489367485046e-01
    z[1,5,1]  R1081     1.6679603606462479e-02
    z[1,5,1]  R1082     1.0234550572931767e-02
    z[1,5,1]  R1083     3.0713167786598206e-01
    z[1,5,1]  R1084     1.4513903856277466e-01
    z[1,5,1]  R1085     5.6686513125896454e-02
    z[1,5,1]  R1086     -0.594928503036499
    z[1,5,1]  R1087     -0.537834644317627
    z[1,5,1]  R1088     -7.6466858386993408e-01
    z[1,5,1]  R1089     -4.1257899999618530e-01
    z[1,5,1]  R1090     -0.819805920124054
    z[1,5,1]  R1091     -7.8827476501464844e-01
    z[1,5,1]  R1092     2.5197806954383850e-01
    z[1,5,1]  R1093     -5.6327307224273682e-01
    z[1,5,1]  R1094     -5.7580155134201050e-01
    z[1,5,1]  R1095     0.877967894077301
    z[1,5,1]  R1096     -5.0431424379348755e-01
    z[1,5,1]  R1097     -2.3633006215095520e-01
    z[1,5,1]  R1098     -0.75218665599823
    z[1,5,1]  R1099     0.841509222984314
    z[1,5,1]  R1100     1.3649652898311615e-01
    z[1,5,1]  R1101     7.4180859327316284e-01
    z[1,5,1]  R1102     3.7573236227035522e-01
    z[1,5,1]  R1103     4.6993693709373474e-01
    z[1,5,1]  R1104     7.5818246603012085e-01
    z[1,5,1]  R1105     3.6967658996582031e-01
    z[1,5,1]  R1106     -4.1390848159790039e-01
    z[1,5,1]  R1107     -5.5232656002044678e-01
    z[1,5,1]  R1108     -5.8645367622375488e-01
    z[1,5,1]  R1109     0.853574812412262
    z[1,5,1]  R1110     1.4161099493503571e-01
    z[1,5,1]  R1111     8.7833267450332642e-01
    z[1,5,1]  R1112     4.6460762619972229e-01
    z[1,5,1]  R1113     4.2761087417602539e-01
    z[1,5,1]  R1114     4.3448188900947571e-01
    z[1,5,1]  R1115     3.3101415634155273e-01
    z[1,5,1]  R1116     -7.2734969854354858e-01
    z[1,5,1]  R1117     -4.8096224665641785e-01
    z[1,5,1]  R1118     -6.3518542051315308e-01
    z[1,5,1]  R1119     -0.549447774887085
    z[1,5,1]  R1120     8.0458915233612061e-01
    z[1,5,1]  R1121     7.3582708835601807e-01
    z[1,5,1]  R1122     -3.4479122608900070e-02
    z[1,5,1]  R1123     6.7354500293731689e-01
    z[1,5,1]  R1124     4.5692536234855652e-01
    z[1,5,1]  R1125     5.0765895843505859e-01
    z[1,5,1]  R1126     -6.1409157514572144e-01
    z[1,5,1]  R1127     -1.2565791606903076e-01
    z[1,5,1]  R1128     4.1230061650276184e-01
    z[1,5,1]  R1129     3.9774590730667114e-01
    z[1,5,1]  R1130     2.1396382153034210e-01
    z[1,5,1]  R1131     3.3984705805778503e-01
    z[1,5,1]  R1132     2.2719369828701019e-01
    z[1,5,1]  R1133     3.8789638876914978e-01
    z[1,5,1]  R1134     3.6635231971740723e-01
    z[1,5,1]  R1135     5.1319259405136108e-01
    z[1,5,2]  R13       -1
    z[1,5,2]  R49       1
    z[1,5,2]  R1006     -1
    z[1,5,2]  R1007     1
    z[1,5,2]  R1016     1.7765846848487854e-01
    z[1,5,2]  R1017     -1.4813593029975891e-01
    z[1,5,2]  R1018     -6.0631740838289261e-02
    z[1,5,2]  R1019     7.0911563932895660e-02
    z[1,5,2]  R1020     -2.7264159917831421e-01
    z[1,5,2]  R1021     -2.3721061646938324e-01
    z[1,5,2]  R1022     -1.1788218468427658e-01
    z[1,5,2]  R1023     -3.7549829483032227e-01
    z[1,5,2]  R1024     -1.2550555169582367e-01
    z[1,5,2]  R1025     -1.3326528668403625e-01
    z[1,5,2]  R1026     -6.1995391733944416e-03
    z[1,5,2]  R1027     3.1355914473533630e-01
    z[1,5,2]  R1028     -4.0524119138717651e-01
    z[1,5,2]  R1029     1.9952647387981415e-01
    z[1,5,2]  R1030     2.5198289752006531e-01
    z[1,5,2]  R1031     -6.6592156887054443e-02
    z[1,5,2]  R1032     -2.0460438728332520e-01
    z[1,5,2]  R1033     1.0704782605171204e-01
    z[1,5,2]  R1034     1.3273303396999836e-02
    z[1,5,2]  R1035     1.6280081868171692e-01
    z[1,5,2]  R1036     1.9041393697261810e-01
    z[1,5,2]  R1037     7.0002920925617218e-02
    z[1,5,2]  R1038     -2.6101595163345337e-01
    z[1,5,2]  R1039     7.1109563112258911e-02
    z[1,5,2]  R1040     1.5195743739604950e-01
    z[1,5,2]  R1041     -9.9591560661792755e-02
    z[1,5,2]  R1042     4.1462087631225586e-01
    z[1,5,2]  R1043     -3.3298179507255554e-01
    z[1,5,2]  R1044     4.3960276991128922e-02
    z[1,5,2]  R1045     -4.0967562235891819e-03
    z[1,5,2]  R1046     1.4690834283828735e-01
    z[1,5,2]  R1047     7.8408278524875641e-02
    z[1,5,2]  R1048     9.3858368694782257e-02
    z[1,5,2]  R1049     1.6618616878986359e-01
    z[1,5,2]  R1050     2.0638216286897659e-02
    z[1,5,2]  R1051     1.9519396126270294e-01
    z[1,5,2]  R1052     9.6629597246646881e-02
    z[1,5,2]  R1053     2.1174415946006775e-01
    z[1,5,2]  R1054     5.1338362693786621e-01
    z[1,5,2]  R1055     7.7930486202239990e-01
    z[1,5,2]  R1056     2.5509269908070564e-02
    z[1,5,2]  R1057     -1.2994299829006195e-01
    z[1,5,2]  R1058     0.00855214148759842
    z[1,5,2]  R1059     -8.2567613571882248e-03
    z[1,5,2]  R1060     -0.0819530263543129
    z[1,5,2]  R1061     -2.4621009826660156e-01
    z[1,5,2]  R1062     2.4352274835109711e-01
    z[1,5,2]  R1063     2.8601571917533875e-01
    z[1,5,2]  R1064     -2.8663319349288940e-01
    z[1,5,2]  R1065     4.8929706215858459e-01
    z[1,5,2]  R1066     3.5377609729766846e-01
    z[1,5,2]  R1067     -1.2487702071666718e-01
    z[1,5,2]  R1068     7.2028875350952148e-02
    z[1,5,2]  R1069     3.4526497125625610e-02
    z[1,5,2]  R1070     0.312128484249115
    z[1,5,2]  R1071     2.1002875640988350e-02
    z[1,5,2]  R1072     0.0805911272764206
    z[1,5,2]  R1073     -7.9114206135272980e-02
    z[1,5,2]  R1074     6.0015637427568436e-02
    z[1,5,2]  R1075     1.1777395755052567e-01
    z[1,5,2]  R1076     4.2093533277511597e-01
    z[1,5,2]  R1077     -1.8737387657165527e-01
    z[1,5,2]  R1078     -1.9083991646766663e-01
    z[1,5,2]  R1079     5.4359138011932373e-01
    z[1,5,2]  R1080     1.6755944490432739e-01
    z[1,5,2]  R1081     -4.0088900923728943e-01
    z[1,5,2]  R1082     -2.7087965607643127e-01
    z[1,5,2]  R1083     8.4773671627044678e-01
    z[1,5,2]  R1084     -5.3328428417444229e-02
    z[1,5,2]  R1085     -9.1249540448188782e-02
    z[1,5,2]  R1086     -2.6642715558409691e-02
    z[1,5,2]  R1087     -1.4002242684364319e-01
    z[1,5,2]  R1088     1.8087702989578247e-01
    z[1,5,2]  R1089     -1.3100315630435944e-01
    z[1,5,2]  R1090     6.3425756990909576e-02
    z[1,5,2]  R1091     0.0672854483127594
    z[1,5,2]  R1092     7.9600483179092407e-01
    z[1,5,2]  R1093     0.364924818277359
    z[1,5,2]  R1094     0.312404990196228
    z[1,5,2]  R1095     2.9581832885742188e-01
    z[1,5,2]  R1096     4.8731550574302673e-01
    z[1,5,2]  R1097     -4.9703961610794067e-01
    z[1,5,2]  R1098     -7.6577968895435333e-02
    z[1,5,2]  R1099     -2.5888085365295410e-01
    z[1,5,2]  R1100     2.3808078840374947e-02
    z[1,5,2]  R1101     -1.9698525965213776e-01
    z[1,5,2]  R1102     -8.8015489280223846e-02
    z[1,5,2]  R1103     -2.1856112778186798e-01
    z[1,5,2]  R1104     1.3577975332736969e-01
    z[1,5,2]  R1105     3.0285622924566269e-02
    z[1,5,2]  R1106     0.414943665266037
    z[1,5,2]  R1107     5.8672297000885010e-01
    z[1,5,2]  R1108     2.3136354982852936e-01
    z[1,5,2]  R1109     1.4333082363009453e-02
    z[1,5,2]  R1110     -6.9514997303485870e-02
    z[1,5,2]  R1111     6.2856063246726990e-02
    z[1,5,2]  R1112     -1.0920436121523380e-02
    z[1,5,2]  R1113     -1.6482889652252197e-01
    z[1,5,2]  R1114     -2.2052787244319916e-01
    z[1,5,2]  R1115     2.8026327490806580e-01
    z[1,5,2]  R1116     -5.4155772924423218e-01
    z[1,5,2]  R1117     -7.0680916309356689e-02
    z[1,5,2]  R1118     5.5067712068557739e-01
    z[1,5,2]  R1119     5.8514326810836792e-01
    z[1,5,2]  R1120     -1.2060177326202393e-01
    z[1,5,2]  R1121     2.7306309342384338e-01
    z[1,5,2]  R1122     1.7790491878986359e-01
    z[1,5,2]  R1123     1.7285411059856415e-01
    z[1,5,2]  R1124     0.066475510597229
    z[1,5,2]  R1125     -7.4864178895950317e-02
    z[1,5,2]  R1126     4.6833685040473938e-01
    z[1,5,2]  R1127     -1.3634940981864929e-01
    z[1,5,2]  R1128     1.3863706588745117e-01
    z[1,5,2]  R1129     1.1819404549896717e-02
    z[1,5,2]  R1130     0.0176091231405735
    z[1,5,2]  R1131     3.2341757416725159e-01
    z[1,5,2]  R1132     -1.7685323953628540e-01
    z[1,5,2]  R1133     1.3034267723560333e-01
    z[1,5,2]  R1134     -0.084355928003788
    z[1,5,2]  R1135     4.3649849295616150e-01
    z[1,5,3]  R14       -1
    z[1,5,3]  R50       1
    z[1,5,3]  R1008     -1
    z[1,5,3]  R1009     1
    z[1,5,3]  R1016     -5.2714014053344727e-01
    z[1,5,3]  R1017     -1.7141684889793396e-01
    z[1,5,3]  R1018     -2.4051589891314507e-02
    z[1,5,3]  R1019     -5.9793466329574585e-01
    z[1,5,3]  R1020     -4.6273627877235413e-01
    z[1,5,3]  R1021     -2.2545909881591797e-01
    z[1,5,3]  R1022     -3.8147419691085815e-01
    z[1,5,3]  R1023     -5.8227157592773438e-01
    z[1,5,3]  R1024     -2.6461067795753479e-01
    z[1,5,3]  R1025     -3.9880636334419250e-01
    z[1,5,3]  R1026     -1.2796452641487122e-01
    z[1,5,3]  R1027     2.8310397267341614e-01
    z[1,5,3]  R1028     2.4331583082675934e-01
    z[1,5,3]  R1029     7.2456523776054382e-02
    z[1,5,3]  R1030     4.0017911791801453e-01
    z[1,5,3]  R1031     3.2510197162628174e-01
    z[1,5,3]  R1032     1.0274247825145721e-01
    z[1,5,3]  R1033     4.3138790130615234e-01
    z[1,5,3]  R1034     6.0794878005981445e-01
    z[1,5,3]  R1035     2.7000385522842407e-01
    z[1,5,3]  R1036     -2.2122806310653687e-01
    z[1,5,3]  R1037     -2.4943706393241882e-01
    z[1,5,3]  R1038     3.1544142961502075e-01
    z[1,5,3]  R1039     2.4635457992553711e-01
    z[1,5,3]  R1040     -4.2376585304737091e-02
    z[1,5,3]  R1041     5.2524778991937637e-02
    z[1,5,3]  R1042     -1.5484818816184998e-01
    z[1,5,3]  R1043     1.7375695705413818e-01
    z[1,5,3]  R1044     2.9080143570899963e-01
    z[1,5,3]  R1045     2.5139921903610229e-01
    z[1,5,3]  R1046     -5.9669923782348633e-01
    z[1,5,3]  R1047     -0.152748703956604
    z[1,5,3]  R1048     -3.1927478313446045e-01
    z[1,5,3]  R1049     7.5129017233848572e-02
    z[1,5,3]  R1050     -6.4138539135456085e-02
    z[1,5,3]  R1051     -3.1122544407844543e-01
    z[1,5,3]  R1052     3.1744691729545593e-01
    z[1,5,3]  R1053     -4.7472648322582245e-02
    z[1,5,3]  R1054     0.641027569770813
    z[1,5,3]  R1055     4.1837012767791748e-01
    z[1,5,3]  R1056     0.560824453830719
    z[1,5,3]  R1057     6.2672692537307739e-01
    z[1,5,3]  R1058     4.7803124785423279e-01
    z[1,5,3]  R1059     5.6229436397552490e-01
    z[1,5,3]  R1060     4.3165174126625061e-01
    z[1,5,3]  R1061     7.4449107050895691e-02
    z[1,5,3]  R1062     6.2117725610733032e-01
    z[1,5,3]  R1063     0.626302182674408
    z[1,5,3]  R1064     5.6914603710174561e-01
    z[1,5,3]  R1065     5.6571489572525024e-01
    z[1,5,3]  R1066     -1.4441484212875366e-01
    z[1,5,3]  R1067     -7.7496908605098724e-02
    z[1,5,3]  R1068     -2.6442435383796692e-01
    z[1,5,3]  R1069     -4.8002207279205322e-01
    z[1,5,3]  R1070     -4.4360291957855225e-01
    z[1,5,3]  R1071     -2.1171808242797852e-01
    z[1,5,3]  R1072     -3.5463970899581909e-01
    z[1,5,3]  R1073     -2.1362021565437317e-01
    z[1,5,3]  R1074     -3.4828168153762817e-01
    z[1,5,3]  R1075     -4.6822601556777954e-01
    z[1,5,3]  R1076     -3.6039733886718750e-01
    z[1,5,3]  R1077     -4.6259489655494690e-01
    z[1,5,3]  R1078     -3.3161154389381409e-01
    z[1,5,3]  R1079     -4.0480870008468628e-01
    z[1,5,3]  R1080     -3.9341679215431213e-01
    z[1,5,3]  R1081     -4.7615250945091248e-01
    z[1,5,3]  R1082     -5.3505256772041321e-02
    z[1,5,3]  R1083     -1.6752177476882935e-01
    z[1,5,3]  R1084     -1.6175325214862823e-01
    z[1,5,3]  R1085     -1.7537190020084381e-01
    z[1,5,3]  R1086     -3.8207793235778809e-01
    z[1,5,3]  R1087     -3.5980913043022156e-01
    z[1,5,3]  R1088     -2.4678030610084534e-01
    z[1,5,3]  R1089     -2.0257394015789032e-01
    z[1,5,3]  R1090     -2.3464618623256683e-01
    z[1,5,3]  R1091     -2.1929797530174255e-01
    z[1,5,3]  R1092     -2.0114910602569580e-01
    z[1,5,3]  R1093     -8.3379305899143219e-02
    z[1,5,3]  R1094     -2.5607371330261230e-01
    z[1,5,3]  R1095     1.4335356652736664e-01
    z[1,5,3]  R1096     -4.4107311964035034e-01
    z[1,5,3]  R1097     1.2474588304758072e-01
    z[1,5,3]  R1098     1.5756097435951233e-01
    z[1,5,3]  R1099     3.0503696203231812e-01
    z[1,5,3]  R1100     -5.3937506675720215e-01
    z[1,5,3]  R1101     2.5046974420547485e-01
    z[1,5,3]  R1102     2.8962868452072144e-01
    z[1,5,3]  R1103     -6.2990888953208923e-02
    z[1,5,3]  R1104     3.1556281447410583e-01
    z[1,5,3]  R1105     3.2318988442420959e-01
    z[1,5,3]  R1106     -3.2534915208816528e-01
    z[1,5,3]  R1107     -5.1158469915390015e-01
    z[1,5,3]  R1108     -5.4444450139999390e-01
    z[1,5,3]  R1109     1.1107818782329559e-01
    z[1,5,3]  R1110     -3.8976454734802246e-01
    z[1,5,3]  R1111     3.8681519031524658e-01
    z[1,5,3]  R1112     2.7715355157852173e-01
    z[1,5,3]  R1113     -4.7014206647872925e-02
    z[1,5,3]  R1114     1.9265557825565338e-01
    z[1,5,3]  R1115     -8.7753236293792725e-01
    z[1,5,3]  R1116     1.5672484040260315e-01
    z[1,5,3]  R1117     2.4916955828666687e-01
    z[1,5,3]  R1118     -3.6101886630058289e-01
    z[1,5,3]  R1119     -5.2012687921524048e-01
    z[1,5,3]  R1120     7.0098556578159332e-02
    z[1,5,3]  R1121     -5.2916455268859863e-01
    z[1,5,3]  R1122     -7.9334115982055664e-01
    z[1,5,3]  R1123     -9.6878513693809509e-02
    z[1,5,3]  R1124     -7.8511595726013184e-01
    z[1,5,3]  R1125     -6.5803134441375732e-01
    z[1,5,3]  R1126     -5.4513007402420044e-01
    z[1,5,3]  R1127     -0.655022382736206
    z[1,5,3]  R1128     -8.1561261415481567e-01
    z[1,5,3]  R1129     -1.9730459153652191e-01
    z[1,5,3]  R1130     -7.1871173381805420e-01
    z[1,5,3]  R1131     -7.6846402883529663e-01
    z[1,5,3]  R1132     -9.5163661241531372e-01
    z[1,5,3]  R1133     -7.2710955142974854e-01
    z[1,5,3]  R1134     -2.7952216565608978e-02
    z[1,5,3]  R1135     -2.4547162652015686e-01
    z[1,5,4]  R15       -1
    z[1,5,4]  R51       1
    z[1,5,4]  R1010     -1
    z[1,5,4]  R1011     1
    z[1,5,4]  R1016     -7.4473358690738678e-02
    z[1,5,4]  R1017     3.5818558186292648e-02
    z[1,5,4]  R1018     -1.9742001593112946e-01
    z[1,5,4]  R1019     3.3438715338706970e-01
    z[1,5,4]  R1020     -0.207333505153656
    z[1,5,4]  R1021     -1.1061331629753113e-01
    z[1,5,4]  R1022     -0.0686548575758934
    z[1,5,4]  R1023     2.1860344707965851e-01
    z[1,5,4]  R1024     -6.0606843233108521e-01
    z[1,5,4]  R1025     -4.0920057892799377e-01
    z[1,5,4]  R1026     -2.6890264824032784e-02
    z[1,5,4]  R1027     -2.5274107232689857e-02
    z[1,5,4]  R1028     2.0200443267822266e-01
    z[1,5,4]  R1029     1.1528035998344421e-01
    z[1,5,4]  R1030     -3.2284778356552124e-01
    z[1,5,4]  R1031     -7.9762347042560577e-02
    z[1,5,4]  R1032     6.1005318164825439e-01
    z[1,5,4]  R1033     1.2749303877353668e-01
    z[1,5,4]  R1034     -1.8790359795093536e-01
    z[1,5,4]  R1035     -5.0215828418731689e-01
    z[1,5,4]  R1036     -1.1892067268490791e-02
    z[1,5,4]  R1037     -6.9857522845268250e-02
    z[1,5,4]  R1038     -2.5380348786711693e-02
    z[1,5,4]  R1039     2.1475711464881897e-01
    z[1,5,4]  R1040     3.8521581888198853e-01
    z[1,5,4]  R1041     1.9272805750370026e-01
    z[1,5,4]  R1042     -4.7011303901672363e-01
    z[1,5,4]  R1043     6.4100092649459839e-01
    z[1,5,4]  R1044     -2.9409998655319214e-01
    z[1,5,4]  R1045     -7.3312622308731079e-01
    z[1,5,4]  R1046     -3.9989843964576721e-01
    z[1,5,4]  R1047     5.2233719825744629e-01
    z[1,5,4]  R1048     0.336622953414917
    z[1,5,4]  R1049     2.9592399951070547e-03
    z[1,5,4]  R1050     1.1275199800729752e-01
    z[1,5,4]  R1051     4.6267968416213989e-01
    z[1,5,4]  R1052     -1.8894420564174652e-01
    z[1,5,4]  R1053     -0.502036452293396
    z[1,5,4]  R1054     0.291445255279541
    z[1,5,4]  R1055     2.7686533331871033e-01
    z[1,5,4]  R1056     1.5356155112385750e-02
    z[1,5,4]  R1057     -0.0917850136756897
    z[1,5,4]  R1058     7.6447036117315292e-03
    z[1,5,4]  R1059     4.8172643780708313e-01
    z[1,5,4]  R1060     3.1640896201133728e-01
    z[1,5,4]  R1061     3.9022436738014221e-01
    z[1,5,4]  R1062     2.5093179941177368e-01
    z[1,5,4]  R1063     1.8925313651561737e-01
    z[1,5,4]  R1064     1.0541664063930511e-01
    z[1,5,4]  R1065     1.1602368950843811e-01
    z[1,5,4]  R1066     -1.9468156993389130e-01
    z[1,5,4]  R1067     -1.3204167783260345e-01
    z[1,5,4]  R1068     -1.7216181382536888e-02
    z[1,5,4]  R1069     3.7903830409049988e-02
    z[1,5,4]  R1070     -0.0446300208568573
    z[1,5,4]  R1071     2.8981253504753113e-01
    z[1,5,4]  R1072     -3.0714502930641174e-01
    z[1,5,4]  R1073     2.1726517379283905e-01
    z[1,5,4]  R1074     -8.0811433494091034e-02
    z[1,5,4]  R1075     -6.2830984592437744e-02
    z[1,5,4]  R1076     -5.6887006759643555e-01
    z[1,5,4]  R1077     -2.6850342750549316e-01
    z[1,5,4]  R1078     -2.6796698570251465e-01
    z[1,5,4]  R1079     -1.0614439845085144e-01
    z[1,5,4]  R1080     -1.9418950378894806e-01
    z[1,5,4]  R1081     1.1833731085062027e-02
    z[1,5,4]  R1082     -2.5105470418930054e-01
    z[1,5,4]  R1083     6.4505837857723236e-02
    z[1,5,4]  R1084     -1.9274080172181129e-02
    z[1,5,4]  R1085     -0.585271418094635
    z[1,5,4]  R1086     -5.0353991985321045e-01
    z[1,5,4]  R1087     -0.446170449256897
    z[1,5,4]  R1088     1.9488246738910675e-01
    z[1,5,4]  R1089     -5.4727095365524292e-01
    z[1,5,4]  R1090     -4.5689767599105835e-01
    z[1,5,4]  R1091     -4.6750482916831970e-01
    z[1,5,4]  R1092     2.2813653573393822e-02
    z[1,5,4]  R1093     -6.5138608217239380e-02
    z[1,5,4]  R1094     -3.0799213051795959e-01
    z[1,5,4]  R1095     -4.4952924363315105e-03
    z[1,5,4]  R1096     -3.4286966919898987e-01
    z[1,5,4]  R1097     1.4899596571922302e-01
    z[1,5,4]  R1098     1.6764806583523750e-02
    z[1,5,4]  R1099     2.8918796777725220e-01
    z[1,5,4]  R1100     1.6099166125059128e-02
    z[1,5,4]  R1101     -2.2511529922485352e-01
    z[1,5,4]  R1102     -1.0972981899976730e-01
    z[1,5,4]  R1103     3.7542146444320679e-01
    z[1,5,4]  R1104     -1.4024865627288818e-01
    z[1,5,4]  R1105     -3.3937383443117142e-02
    z[1,5,4]  R1106     -4.1775226593017578e-01
    z[1,5,4]  R1107     1.7556536197662354e-01
    z[1,5,4]  R1108     0.0706513300538063
    z[1,5,4]  R1109     -1.0516929626464844e-01
    z[1,5,4]  R1110     8.2739852368831635e-03
    z[1,5,4]  R1111     0.0567634291946888
    z[1,5,4]  R1112     1.4633840322494507e-01
    z[1,5,4]  R1113     3.4421750903129578e-01
    z[1,5,4]  R1114     0.0528845377266407
    z[1,5,4]  R1115     -3.5412866622209549e-02
    z[1,5,4]  R1116     -1.4077021181583405e-01
    z[1,5,4]  R1117     -7.4031746387481689e-01
    z[1,5,4]  R1118     3.5037645697593689e-01
    z[1,5,4]  R1119     3.5571921616792679e-02
    z[1,5,4]  R1120     5.6037232279777527e-03
    z[1,5,4]  R1121     2.2409898042678833e-01
    z[1,5,4]  R1122     -2.8389078378677368e-01
    z[1,5,4]  R1123     3.2641181349754333e-01
    z[1,5,4]  R1124     3.6762478947639465e-01
    z[1,5,4]  R1125     1.1520207673311234e-01
    z[1,5,4]  R1126     -1.6303323209285736e-01
    z[1,5,4]  R1127     -0.534935474395752
    z[1,5,4]  R1128     -1.7534036189317703e-02
    z[1,5,4]  R1129     1.9538573920726776e-02
    z[1,5,4]  R1130     -2.8727620840072632e-01
    z[1,5,4]  R1131     7.8169278800487518e-02
    z[1,5,4]  R1132     2.9616493731737137e-02
    z[1,5,4]  R1133     4.9636635184288025e-01
    z[1,5,4]  R1134     2.3595626652240753e-01
    z[1,5,4]  R1135     2.0990064740180969e-01
    z[1,5,5]  R16       -1
    z[1,5,5]  R52       1
    z[1,5,5]  R1012     -1
    z[1,5,5]  R1013     1
    z[1,5,5]  R1016     -4.2726588249206543e-01
    z[1,5,5]  R1017     -4.4893521070480347e-01
    z[1,5,5]  R1018     -1.9430667161941528e-01
    z[1,5,5]  R1019     1.8883095681667328e-01
    z[1,5,5]  R1020     -3.1816062331199646e-01
    z[1,5,5]  R1021     3.5657492280006409e-01
    z[1,5,5]  R1022     -0.413128525018692
    z[1,5,5]  R1023     0.0798230916261673
    z[1,5,5]  R1024     -5.1094375550746918e-02
    z[1,5,5]  R1025     1.0263931751251221e-01
    z[1,5,5]  R1026     3.4040069580078125e-01
    z[1,5,5]  R1027     9.6004633232951164e-03
    z[1,5,5]  R1028     2.4548135697841644e-01
    z[1,5,5]  R1029     3.8709971308708191e-01
    z[1,5,5]  R1030     3.2117941975593567e-01
    z[1,5,5]  R1031     4.8737379908561707e-01
    z[1,5,5]  R1032     3.2575258612632751e-01
    z[1,5,5]  R1033     3.6358457803726196e-01
    z[1,5,5]  R1034     2.8527006506919861e-01
    z[1,5,5]  R1035     1.6940513253211975e-01
    z[1,5,5]  R1036     5.3804576396942139e-01
    z[1,5,5]  R1037     4.4933566451072693e-01
    z[1,5,5]  R1038     3.4121209383010864e-01
    z[1,5,5]  R1039     2.7260869741439819e-01
    z[1,5,5]  R1040     -1.8417501449584961e-01
    z[1,5,5]  R1041     -4.8523122072219849e-01
    z[1,5,5]  R1042     -5.0318732857704163e-02
    z[1,5,5]  R1043     -5.4362822324037552e-02
    z[1,5,5]  R1044     -5.0268638134002686e-01
    z[1,5,5]  R1045     -9.4509720802307129e-02
    z[1,5,5]  R1046     6.2728708982467651e-01
    z[1,5,5]  R1047     -8.9115977287292480e-02
    z[1,5,5]  R1048     -1.9698626419994980e-04
    z[1,5,5]  R1049     4.9155500531196594e-01
    z[1,5,5]  R1050     1.5471910126507282e-02
    z[1,5,5]  R1051     7.5048275291919708e-02
    z[1,5,5]  R1052     -6.8633213639259338e-02
    z[1,5,5]  R1053     -9.3955181539058685e-02
    z[1,5,5]  R1054     2.3310044407844543e-01
    z[1,5,5]  R1055     9.1374032199382782e-02
    z[1,5,5]  R1056     -0.27354696393013
    z[1,5,5]  R1057     -2.5523068383336067e-02
    z[1,5,5]  R1058     9.2905461788177490e-02
    z[1,5,5]  R1059     -3.4722540527582169e-02
    z[1,5,5]  R1060     1.9602908194065094e-01
    z[1,5,5]  R1061     -3.6198985762894154e-03
    z[1,5,5]  R1062     -2.9300352931022644e-01
    z[1,5,5]  R1063     -5.6037425994873047e-01
    z[1,5,5]  R1064     3.3743798732757568e-01
    z[1,5,5]  R1065     -4.0920349955558777e-01
    z[1,5,5]  R1066     1.9935664534568787e-01
    z[1,5,5]  R1067     1.1492899060249329e-01
    z[1,5,5]  R1068     5.8168604969978333e-02
    z[1,5,5]  R1069     -1.5526196360588074e-01
    z[1,5,5]  R1070     1.9884844124317169e-01
    z[1,5,5]  R1071     -1.8055659532546997e-01
    z[1,5,5]  R1072     -1.2239484116435051e-02
    z[1,5,5]  R1073     -2.8148156404495239e-01
    z[1,5,5]  R1074     -2.3173154890537262e-01
    z[1,5,5]  R1075     -2.4595829844474792e-01
    z[1,5,5]  R1076     1.5505455434322357e-01
    z[1,5,5]  R1077     2.5466531515121460e-01
    z[1,5,5]  R1078     -2.3919600062072277e-03
    z[1,5,5]  R1079     3.3560761809349060e-01
    z[1,5,5]  R1080     4.0550000965595245e-02
    z[1,5,5]  R1081     1.2554794549942017e-01
    z[1,5,5]  R1082     1.9845777750015259e-01
    z[1,5,5]  R1083     0.188396617770195
    z[1,5,5]  R1084     3.7591537833213806e-01
    z[1,5,5]  R1085     1.6490317881107330e-01
    z[1,5,5]  R1086     -6.6061496734619141e-02
    z[1,5,5]  R1087     -4.3922942876815796e-01
    z[1,5,5]  R1088     -1.5732270479202271e-01
    z[1,5,5]  R1089     -5.5782753229141235e-01
    z[1,5,5]  R1090     3.1543437391519547e-02
    z[1,5,5]  R1091     1.6941666603088379e-01
    z[1,5,5]  R1092     1.2285882979631424e-01
    z[1,5,5]  R1093     7.1033620834350586e-01
    z[1,5,5]  R1094     4.4255855679512024e-01
    z[1,5,5]  R1095     -9.7863718867301941e-02
    z[1,5,5]  R1096     -1.5662544965744019e-01
    z[1,5,5]  R1097     -6.8838918209075928e-01
    z[1,5,5]  R1098     -1.7030051350593567e-01
    z[1,5,5]  R1099     -9.6369504928588867e-02
    z[1,5,5]  R1100     1.1636684834957123e-01
    z[1,5,5]  R1101     -5.4046493768692017e-01
    z[1,5,5]  R1102     -0.29739910364151
    z[1,5,5]  R1103     -2.8796562552452087e-01
    z[1,5,5]  R1104     0.449703186750412
    z[1,5,5]  R1105     2.3624885082244873e-01
    z[1,5,5]  R1106     3.7510338425636292e-01
    z[1,5,5]  R1107     -1.0032492876052856e-01
    z[1,5,5]  R1108     4.3588620424270630e-01
    z[1,5,5]  R1109     -3.6930760741233826e-01
    z[1,5,5]  R1110     0.152458056807518
    z[1,5,5]  R1111     -1.1823111772537231e-01
    z[1,5,5]  R1112     -3.2327221706509590e-03
    z[1,5,5]  R1113     1.3134506344795227e-01
    z[1,5,5]  R1114     -5.1871605217456818e-02
    z[1,5,5]  R1115     1.1105019599199295e-01
    z[1,5,5]  R1116     2.6202493906021118e-01
    z[1,5,5]  R1117     -1.7771621048450470e-01
    z[1,5,5]  R1118     0.144393190741539
    z[1,5,5]  R1119     1.5258552134037018e-01
    z[1,5,5]  R1120     1.6942301392555237e-01
    z[1,5,5]  R1121     1.9821600615978241e-01
    z[1,5,5]  R1122     -1.3792443275451660e-01
    z[1,5,5]  R1123     4.6606764197349548e-01
    z[1,5,5]  R1124     1.7696402966976166e-01
    z[1,5,5]  R1125     5.2001518011093140e-01
    z[1,5,5]  R1126     1.5033917129039764e-01
    z[1,5,5]  R1127     1.9275434315204620e-01
    z[1,5,5]  R1128     -7.8589223325252533e-02
    z[1,5,5]  R1129     -3.2607099413871765e-01
    z[1,5,5]  R1130     8.9479319751262665e-02
    z[1,5,5]  R1131     -1.1679124087095261e-01
    z[1,5,5]  R1132     1.3712685555219650e-02
    z[1,5,5]  R1133     -7.9214125871658325e-02
    z[1,5,5]  R1134     -8.7641589343547821e-02
    z[1,5,5]  R1135     -1.5276958048343658e-01
    z[1,5,6]  R17       -1
    z[1,5,6]  R53       1
    z[1,5,6]  R1014     -1
    z[1,5,6]  R1015     1
    z[1,5,6]  R1016     -8.4079019725322723e-02
    z[1,5,6]  R1017     3.4917865414172411e-03
    z[1,5,6]  R1018     9.3952931463718414e-02
    z[1,5,6]  R1019     -2.6736435294151306e-01
    z[1,5,6]  R1020     5.2625524997711182e-01
    z[1,5,6]  R1021     -8.1423139199614525e-03
    z[1,5,6]  R1022     2.3798566311597824e-02
    z[1,5,6]  R1023     4.5384612679481506e-01
    z[1,5,6]  R1024     2.9452082514762878e-01
    z[1,5,6]  R1025     5.3818774223327637e-01
    z[1,5,6]  R1026     2.4685344099998474e-01
    z[1,5,6]  R1027     -2.9452103376388550e-01
    z[1,5,6]  R1028     4.3733417987823486e-01
    z[1,5,6]  R1029     -1.2433338165283203e-01
    z[1,5,6]  R1030     -3.8061115145683289e-01
    z[1,5,6]  R1031     0.0547383613884449
    z[1,5,6]  R1032     1.0755355656147003e-01
    z[1,5,6]  R1033     0.0466521717607975
    z[1,5,6]  R1034     -0.074155293405056
    z[1,5,6]  R1035     1.6571673750877380e-01
    z[1,5,6]  R1036     1.4408499002456665e-02
    z[1,5,6]  R1037     -1.2025839835405350e-01
    z[1,5,6]  R1038     5.1061216741800308e-02
    z[1,5,6]  R1039     -1.9564969837665558e-01
    z[1,5,6]  R1040     8.6739897727966309e-02
    z[1,5,6]  R1041     3.4491127729415894e-01
    z[1,5,6]  R1042     -5.8239664882421494e-02
    z[1,5,6]  R1043     4.4052168726921082e-02
    z[1,5,6]  R1044     1.7404365539550781e-01
    z[1,5,6]  R1045     2.4868105351924896e-01
    z[1,5,6]  R1046     -2.5180861353874207e-02
    z[1,5,6]  R1047     7.3525518178939819e-02
    z[1,5,6]  R1048     2.1956019103527069e-01
    z[1,5,6]  R1049     -2.2008366882801056e-01
    z[1,5,6]  R1050     1.4444258809089661e-01
    z[1,5,6]  R1051     -2.2445949912071228e-01
    z[1,5,6]  R1052     -1.0294097661972046e-01
    z[1,5,6]  R1053     1.2430543079972267e-02
    z[1,5,6]  R1054     -2.4548610672354698e-02
    z[1,5,6]  R1055     -1.1802790313959122e-01
    z[1,5,6]  R1056     1.2567305937409401e-02
    z[1,5,6]  R1057     -2.7718612551689148e-01
    z[1,5,6]  R1058     -2.9566511511802673e-01
    z[1,5,6]  R1059     3.4433576464653015e-01
    z[1,5,6]  R1060     5.5579822510480881e-02
    z[1,5,6]  R1061     -1.4310921728610992e-01
    z[1,5,6]  R1062     -1.1749270558357239e-01
    z[1,5,6]  R1063     -1.9455835223197937e-01
    z[1,5,6]  R1064     3.4837210178375244e-01
    z[1,5,6]  R1065     2.6342767477035522e-01
    z[1,5,6]  R1066     -4.6765303611755371e-01
    z[1,5,6]  R1067     -1.0650959610939026e-01
    z[1,5,6]  R1068     -1.9320906698703766e-01
    z[1,5,6]  R1069     1.5103018283843994e-01
    z[1,5,6]  R1070     -1.5218277275562286e-01
    z[1,5,6]  R1071     -2.6157429441809654e-02
    z[1,5,6]  R1072     -5.3551908582448959e-02
    z[1,5,6]  R1073     -3.7203781306743622e-02
    z[1,5,6]  R1074     -2.3170320689678192e-01
    z[1,5,6]  R1075     -1.9556893035769463e-02
    z[1,5,6]  R1076     1.0727799683809280e-01
    z[1,5,6]  R1077     3.3926871418952942e-01
    z[1,5,6]  R1078     -6.0322366654872894e-02
    z[1,5,6]  R1079     3.6199495196342468e-01
    z[1,5,6]  R1080     0.00312709528952837
    z[1,5,6]  R1081     -7.7364325523376465e-02
    z[1,5,6]  R1082     1.3736440241336823e-01
    z[1,5,6]  R1083     -2.8281034901738167e-03
    z[1,5,6]  R1084     1.7507965862751007e-01
    z[1,5,6]  R1085     2.0650139078497887e-02
    z[1,5,6]  R1086     4.1523313522338867e-01
    z[1,5,6]  R1087     -4.1135692596435547e-01
    z[1,5,6]  R1088     4.2290221899747849e-02
    z[1,5,6]  R1089     3.9515611529350281e-01
    z[1,5,6]  R1090     2.3404273390769958e-01
    z[1,5,6]  R1091     4.8952829092741013e-02
    z[1,5,6]  R1092     9.9118478596210480e-02
    z[1,5,6]  R1093     0.0359313040971756
    z[1,5,6]  R1094     4.5354613661766052e-01
    z[1,5,6]  R1095     -1.1205860227346420e-01
    z[1,5,6]  R1096     -3.9465554058551788e-02
    z[1,5,6]  R1097     3.7048763036727905e-01
    z[1,5,6]  R1098     -4.8416815698146820e-02
    z[1,5,6]  R1099     1.1586034297943115e-01
    z[1,5,6]  R1100     1.3355457782745361e-01
    z[1,5,6]  R1101     3.4233994781970978e-02
    z[1,5,6]  R1102     4.4190678745508194e-02
    z[1,5,6]  R1103     -3.3666866365820169e-03
    z[1,5,6]  R1104     2.9192259907722473e-01
    z[1,5,6]  R1105     -2.8641945123672485e-01
    z[1,5,6]  R1106     2.7961862087249756e-01
    z[1,5,6]  R1107     -2.1818424761295319e-01
    z[1,5,6]  R1108     1.6367980837821960e-01
    z[1,5,6]  R1109     1.7917476594448090e-01
    z[1,5,6]  R1110     -6.6021241247653961e-02
    z[1,5,6]  R1111     0.237451434135437
    z[1,5,6]  R1112     -1.2927031144499779e-02
    z[1,5,6]  R1113     3.5853590816259384e-02
    z[1,5,6]  R1114     -3.4651052951812744e-01
    z[1,5,6]  R1115     -0.0336323045194149
    z[1,5,6]  R1116     1.9779159128665924e-01
    z[1,5,6]  R1117     3.3439654111862183e-01
    z[1,5,6]  R1118     -3.0641382560133934e-02
    z[1,5,6]  R1119     1.1021838337182999e-01
    z[1,5,6]  R1120     4.5923396944999695e-01
    z[1,5,6]  R1121     8.8693335652351379e-02
    z[1,5,6]  R1122     -8.4558278322219849e-02
    z[1,5,6]  R1123     2.6078581809997559e-01
    z[1,5,6]  R1124     -4.6534806489944458e-02
    z[1,5,6]  R1125     1.0844473540782928e-01
    z[1,5,6]  R1126     1.2813293933868408e-01
    z[1,5,6]  R1127     -5.9406068176031113e-02
    z[1,5,6]  R1128     -3.6950135231018066e-01
    z[1,5,6]  R1129     4.1972849518060684e-02
    z[1,5,6]  R1130     -4.5489165186882019e-01
    z[1,5,6]  R1131     4.8335094004869461e-02
    z[1,5,6]  R1132     5.9358462691307068e-02
    z[1,5,6]  R1133     6.6626533865928650e-02
    z[1,5,6]  R1134     5.0326216220855713e-01
    z[1,5,6]  R1135     7.9438820481300354e-02
    z[5,1,0]  R11       1
    z[5,1,0]  R47       -1
    z[5,1,0]  R1136     -1
    z[5,1,0]  R1137     1
    z[5,1,0]  R1150     6.4572030305862427e-01
    z[5,1,0]  R1151     5.9248942136764526e-01
    z[5,1,0]  R1152     7.7949911355972290e-01
    z[5,1,0]  R1153     4.3592220544815063e-01
    z[5,1,0]  R1154     7.5880461931228638e-01
    z[5,1,0]  R1155     0.639691948890686
    z[5,1,0]  R1156     5.3148925304412842e-01
    z[5,1,0]  R1157     2.0234270393848419e-01
    z[5,1,0]  R1158     4.5358395576477051e-01
    z[5,1,0]  R1159     1.1968953907489777e-01
    z[5,1,0]  R1160     -4.3323707580566406e-01
    z[5,1,0]  R1161     2.5212273001670837e-01
    z[5,1,0]  R1162     2.6298072934150696e-01
    z[5,1,0]  R1163     1.1024408787488937e-01
    z[5,1,0]  R1164     -5.2712941169738770e-01
    z[5,1,0]  R1165     0.0764106810092926
    z[5,1,0]  R1166     1.2938044965267181e-01
    z[5,1,0]  R1167     1.4818756282329559e-01
    z[5,1,0]  R1168     1.3261912763118744e-01
    z[5,1,0]  R1169     0.0923101156949997
    z[5,1,0]  R1170     2.6949477195739746e-01
    z[5,1,0]  R1171     -6.9175457954406738e-01
    z[5,1,0]  R1172     -8.6974817514419556e-01
    z[5,1,0]  R1173     2.7312484383583069e-01
    z[5,1,0]  R1174     -8.7619078159332275e-01
    z[5,1,0]  R1175     -0.76837557554245
    z[5,1,0]  R1176     -8.9575308561325073e-01
    z[5,1,0]  R1177     3.4537902474403381e-01
    z[5,1,0]  R1178     -8.8181060552597046e-01
    z[5,1,0]  R1179     -7.6651340723037720e-01
    z[5,1,0]  R1180     2.6273876428604126e-01
    z[5,1,0]  R1181     2.1442225202918053e-02
    z[5,1,0]  R1182     -5.0709646940231323e-01
    z[5,1,0]  R1183     -6.8957008421421051e-02
    z[5,1,0]  R1184     -6.5651647746562958e-02
    z[5,1,0]  R1185     -0.276305615901947
    z[5,1,0]  R1186     4.8680922389030457e-01
    z[5,1,0]  R1187     -1.8024887144565582e-01
    z[5,1,0]  R1188     -9.4130545854568481e-02
    z[5,1,0]  R1189     3.1457754969596863e-01
    z[5,1,0]  R1190     4.1230636835098267e-01
    z[5,1,0]  R1191     -2.1953971683979034e-01
    z[5,1,0]  R1192     -6.0983443260192871e-01
    z[5,1,0]  R1193     1.5954670310020447e-01
    z[5,1,0]  R1194     -8.1131941080093384e-01
    z[5,1,0]  R1195     6.5042026340961456e-02
    z[5,1,0]  R1196     -8.1532442569732666e-01
    z[5,1,0]  R1197     -7.0960956811904907e-01
    z[5,1,0]  R1198     0.0046690390445292
    z[5,1,0]  R1199     -7.8674578666687012e-01
    z[5,1,0]  R1200     3.9653930068016052e-01
    z[5,1,0]  R1201     -2.1907810121774673e-02
    z[5,1,0]  R1202     -2.9042005538940430e-01
    z[5,1,0]  R1203     2.8162726759910583e-01
    z[5,1,0]  R1204     -8.9192312955856323e-01
    z[5,1,0]  R1205     -3.7026621401309967e-02
    z[5,1,0]  R1206     -8.2801800966262817e-01
    z[5,1,0]  R1207     -8.0668920278549194e-01
    z[5,1,0]  R1208     -0.774544894695282
    z[5,1,0]  R1209     -1.6462604701519012e-01
    z[5,1,0]  R1210     1.5975052118301392e-01
    z[5,1,0]  R1211     -1.0059801489114761e-01
    z[5,1,0]  R1212     -1.3567447662353516e-01
    z[5,1,0]  R1213     2.2019736468791962e-01
    z[5,1,0]  R1214     3.0585357546806335e-01
    z[5,1,0]  R1215     -8.1261835992336273e-02
    z[5,1,0]  R1216     -4.8062843084335327e-01
    z[5,1,0]  R1217     0.339558869600296
    z[5,1,0]  R1218     4.1992641985416412e-02
    z[5,1,0]  R1219     9.0691335499286652e-02
    z[5,1,0]  R1220     2.0195426046848297e-01
    z[5,1,0]  R1221     -4.5795783400535583e-01
    z[5,1,0]  R1222     -5.0490312278270721e-02
    z[5,1,0]  R1223     -8.3322483301162720e-01
    z[5,1,0]  R1224     -3.7403514981269836e-01
    z[5,1,0]  R1225     -4.0900033712387085e-01
    z[5,1,0]  R1226     8.3096392452716827e-02
    z[5,1,0]  R1227     -2.1625292301177979e-01
    z[5,1,0]  R1228     -7.3570340871810913e-01
    z[5,1,0]  R1229     -6.4198029041290283e-01
    z[5,1,0]  R1230     1.0424977540969849e-01
    z[5,1,0]  R1231     4.5252549648284912e-01
    z[5,1,0]  R1232     0.0661509558558464
    z[5,1,0]  R1233     2.8299051523208618e-01
    z[5,1,0]  R1234     1.2149226665496826e-01
    z[5,1,0]  R1235     0.612120509147644
    z[5,1,0]  R1236     6.7033219337463379e-01
    z[5,1,0]  R1237     1.5490005910396576e-01
    z[5,1,0]  R1238     2.8226104378700256e-01
    z[5,1,0]  R1239     -2.4477690458297729e-01
    z[5,1,0]  R1240     -3.3862102031707764e-01
    z[5,1,0]  R1241     -2.5495833158493042e-01
    z[5,1,0]  R1242     -8.7855964899063110e-02
    z[5,1,0]  R1243     -3.8494125008583069e-01
    z[5,1,0]  R1244     9.0316146612167358e-02
    z[5,1,0]  R1245     -1.0013429075479507e-01
    z[5,1,0]  R1246     -2.1069069206714630e-01
    z[5,1,0]  R1247     -2.3835390806198120e-01
    z[5,1,0]  R1248     -8.9270561933517456e-02
    z[5,1,0]  R1249     -1.3217581808567047e-01
    z[5,1,0]  R1250     -5.6992095708847046e-01
    z[5,1,0]  R1251     2.1340602636337280e-01
    z[5,1,0]  R1252     3.7517610192298889e-01
    z[5,1,0]  R1253     -7.1401357650756836e-02
    z[5,1,0]  R1254     -1.5552681684494019e-01
    z[5,1,0]  R1255     -3.3658319711685181e-01
    z[5,1,0]  R1256     -3.7117803096771240e-01
    z[5,1,0]  R1257     2.5435557961463928e-01
    z[5,1,0]  R1258     -1.4337022602558136e-01
    z[5,1,0]  R1259     3.9398744702339172e-02
    z[5,1,0]  R1260     1.0379552096128464e-01
    z[5,1,0]  R1261     -6.4998644590377808e-01
    z[5,1,0]  R1262     -7.4237370491027832e-01
    z[5,1,0]  R1263     -0.0773012712597847
    z[5,1,0]  R1264     -0.246307834982872
    z[5,1,0]  R1265     -1.4701296389102936e-01
    z[5,1,0]  R1266     4.7910723835229874e-02
    z[5,1,0]  R1267     -1.6824087128043175e-02
    z[5,1,0]  R1268     3.1259888410568237e-01
    z[5,1,0]  R1269     1.6191582381725311e-01
    z[5,1,1]  R12       1
    z[5,1,1]  R48       -1
    z[5,1,1]  R1138     -1
    z[5,1,1]  R1139     1
    z[5,1,1]  R1150     -0.438917875289917
    z[5,1,1]  R1151     -3.9163279533386230e-01
    z[5,1,1]  R1152     -2.6016622781753540e-01
    z[5,1,1]  R1153     -3.7669035792350769e-01
    z[5,1,1]  R1154     -2.9924064874649048e-01
    z[5,1,1]  R1155     -5.9318101406097412e-01
    z[5,1,1]  R1156     -3.3125856518745422e-01
    z[5,1,1]  R1157     -3.1194382905960083e-01
    z[5,1,1]  R1158     -3.7661054730415344e-01
    z[5,1,1]  R1159     -4.1943570971488953e-01
    z[5,1,1]  R1160     -6.0823440551757812e-01
    z[5,1,1]  R1161     9.3426233530044556e-01
    z[5,1,1]  R1162     9.0262013673782349e-01
    z[5,1,1]  R1163     8.4135597944259644e-01
    z[5,1,1]  R1164     -6.0268962383270264e-01
    z[5,1,1]  R1165     9.1193181276321411e-01
    z[5,1,1]  R1166     8.6812484264373779e-01
    z[5,1,1]  R1167     0.893491804599762
    z[5,1,1]  R1168     8.6231881380081177e-01
    z[5,1,1]  R1169     8.3279460668563843e-01
    z[5,1,1]  R1170     -5.1101475954055786e-01
    z[5,1,1]  R1171     1.4255075156688690e-01
    z[5,1,1]  R1172     1.4731350541114807e-01
    z[5,1,1]  R1173     -4.5945802330970764e-01
    z[5,1,1]  R1174     1.0036489367485046e-01
    z[5,1,1]  R1175     1.6679603606462479e-02
    z[5,1,1]  R1176     1.0234550572931767e-02
    z[5,1,1]  R1177     3.0713167786598206e-01
    z[5,1,1]  R1178     1.4513903856277466e-01
    z[5,1,1]  R1179     5.6686513125896454e-02
    z[5,1,1]  R1180     -0.594928503036499
    z[5,1,1]  R1181     -0.537834644317627
    z[5,1,1]  R1182     -7.6466858386993408e-01
    z[5,1,1]  R1183     -4.1257899999618530e-01
    z[5,1,1]  R1184     -0.819805920124054
    z[5,1,1]  R1185     -7.8827476501464844e-01
    z[5,1,1]  R1186     2.5197806954383850e-01
    z[5,1,1]  R1187     -5.6327307224273682e-01
    z[5,1,1]  R1188     -5.7580155134201050e-01
    z[5,1,1]  R1189     0.877967894077301
    z[5,1,1]  R1190     -5.0431424379348755e-01
    z[5,1,1]  R1191     -2.3633006215095520e-01
    z[5,1,1]  R1192     -0.75218665599823
    z[5,1,1]  R1193     0.841509222984314
    z[5,1,1]  R1194     1.3649652898311615e-01
    z[5,1,1]  R1195     7.4180859327316284e-01
    z[5,1,1]  R1196     3.7573236227035522e-01
    z[5,1,1]  R1197     4.6993693709373474e-01
    z[5,1,1]  R1198     7.5818246603012085e-01
    z[5,1,1]  R1199     3.6967658996582031e-01
    z[5,1,1]  R1200     -4.1390848159790039e-01
    z[5,1,1]  R1201     -5.5232656002044678e-01
    z[5,1,1]  R1202     -5.8645367622375488e-01
    z[5,1,1]  R1203     0.853574812412262
    z[5,1,1]  R1204     1.4161099493503571e-01
    z[5,1,1]  R1205     8.7833267450332642e-01
    z[5,1,1]  R1206     4.6460762619972229e-01
    z[5,1,1]  R1207     4.2761087417602539e-01
    z[5,1,1]  R1208     4.3448188900947571e-01
    z[5,1,1]  R1209     3.3101415634155273e-01
    z[5,1,1]  R1210     -7.2734969854354858e-01
    z[5,1,1]  R1211     -4.8096224665641785e-01
    z[5,1,1]  R1212     -6.3518542051315308e-01
    z[5,1,1]  R1213     -0.549447774887085
    z[5,1,1]  R1214     8.0458915233612061e-01
    z[5,1,1]  R1215     7.3582708835601807e-01
    z[5,1,1]  R1216     -3.4479122608900070e-02
    z[5,1,1]  R1217     6.7354500293731689e-01
    z[5,1,1]  R1218     4.5692536234855652e-01
    z[5,1,1]  R1219     5.0765895843505859e-01
    z[5,1,1]  R1220     -6.1409157514572144e-01
    z[5,1,1]  R1221     -1.2565791606903076e-01
    z[5,1,1]  R1222     4.1230061650276184e-01
    z[5,1,1]  R1223     3.9774590730667114e-01
    z[5,1,1]  R1224     2.1396382153034210e-01
    z[5,1,1]  R1225     3.3984705805778503e-01
    z[5,1,1]  R1226     2.2719369828701019e-01
    z[5,1,1]  R1227     3.8789638876914978e-01
    z[5,1,1]  R1228     3.6635231971740723e-01
    z[5,1,1]  R1229     5.1319259405136108e-01
    z[5,1,1]  R1230     -0.696075439453125
    z[5,1,1]  R1231     -7.3556423187255859e-01
    z[5,1,1]  R1232     -9.5174181461334229e-01
    z[5,1,1]  R1233     -0.581727147102356
    z[5,1,1]  R1234     -5.2499836683273315e-01
    z[5,1,1]  R1235     -6.1543524265289307e-01
    z[5,1,1]  R1236     4.6398368477821350e-01
    z[5,1,1]  R1237     -4.8562464118003845e-01
    z[5,1,1]  R1238     -6.1472445726394653e-01
    z[5,1,1]  R1239     -5.4373896121978760e-01
    z[5,1,1]  R1240     8.3149868249893188e-01
    z[5,1,1]  R1241     8.1795817613601685e-01
    z[5,1,1]  R1242     0.6903116106987
    z[5,1,1]  R1243     0.792568564414978
    z[5,1,1]  R1244     0.64494389295578
    z[5,1,1]  R1245     7.9558509588241577e-01
    z[5,1,1]  R1246     6.4291751384735107e-01
    z[5,1,1]  R1247     0.771367609500885
    z[5,1,1]  R1248     7.0715421438217163e-01
    z[5,1,1]  R1249     7.5815582275390625e-01
    z[5,1,1]  R1250     -5.4785811901092529e-01
    z[5,1,1]  R1251     8.1614577770233154e-01
    z[5,1,1]  R1252     7.5626271963119507e-01
    z[5,1,1]  R1253     8.7774705886840820e-01
    z[5,1,1]  R1254     8.7240421772003174e-01
    z[5,1,1]  R1255     0.694605827331543
    z[5,1,1]  R1256     6.6287875175476074e-01
    z[5,1,1]  R1257     6.1518836021423340e-01
    z[5,1,1]  R1258     7.2351044416427612e-01
    z[5,1,1]  R1259     5.7182258367538452e-01
    z[5,1,1]  R1260     -2.3990131914615631e-01
    z[5,1,1]  R1261     -5.1171648502349854e-01
    z[5,1,1]  R1262     -4.2025437951087952e-01
    z[5,1,1]  R1263     8.1895691156387329e-01
    z[5,1,1]  R1264     9.4919794797897339e-01
    z[5,1,1]  R1265     7.5719106197357178e-01
    z[5,1,1]  R1266     9.1465157270431519e-01
    z[5,1,1]  R1267     8.3162802457809448e-01
    z[5,1,1]  R1268     -2.9651984572410583e-01
    z[5,1,1]  R1269     -3.0413705110549927e-01
    z[5,1,2]  R13       1
    z[5,1,2]  R49       -1
    z[5,1,2]  R1140     -1
    z[5,1,2]  R1141     1
    z[5,1,2]  R1150     2.5509269908070564e-02
    z[5,1,2]  R1151     -1.2994299829006195e-01
    z[5,1,2]  R1152     0.00855214148759842
    z[5,1,2]  R1153     -8.2567613571882248e-03
    z[5,1,2]  R1154     -0.0819530263543129
    z[5,1,2]  R1155     -2.4621009826660156e-01
    z[5,1,2]  R1156     2.4352274835109711e-01
    z[5,1,2]  R1157     2.8601571917533875e-01
    z[5,1,2]  R1158     -2.8663319349288940e-01
    z[5,1,2]  R1159     4.8929706215858459e-01
    z[5,1,2]  R1160     3.5377609729766846e-01
    z[5,1,2]  R1161     -1.2487702071666718e-01
    z[5,1,2]  R1162     7.2028875350952148e-02
    z[5,1,2]  R1163     3.4526497125625610e-02
    z[5,1,2]  R1164     0.312128484249115
    z[5,1,2]  R1165     2.1002875640988350e-02
    z[5,1,2]  R1166     0.0805911272764206
    z[5,1,2]  R1167     -7.9114206135272980e-02
    z[5,1,2]  R1168     6.0015637427568436e-02
    z[5,1,2]  R1169     1.1777395755052567e-01
    z[5,1,2]  R1170     4.2093533277511597e-01
    z[5,1,2]  R1171     -1.8737387657165527e-01
    z[5,1,2]  R1172     -1.9083991646766663e-01
    z[5,1,2]  R1173     5.4359138011932373e-01
    z[5,1,2]  R1174     1.6755944490432739e-01
    z[5,1,2]  R1175     -4.0088900923728943e-01
    z[5,1,2]  R1176     -2.7087965607643127e-01
    z[5,1,2]  R1177     8.4773671627044678e-01
    z[5,1,2]  R1178     -5.3328428417444229e-02
    z[5,1,2]  R1179     -9.1249540448188782e-02
    z[5,1,2]  R1180     -2.6642715558409691e-02
    z[5,1,2]  R1181     -1.4002242684364319e-01
    z[5,1,2]  R1182     1.8087702989578247e-01
    z[5,1,2]  R1183     -1.3100315630435944e-01
    z[5,1,2]  R1184     6.3425756990909576e-02
    z[5,1,2]  R1185     0.0672854483127594
    z[5,1,2]  R1186     7.9600483179092407e-01
    z[5,1,2]  R1187     0.364924818277359
    z[5,1,2]  R1188     0.312404990196228
    z[5,1,2]  R1189     2.9581832885742188e-01
    z[5,1,2]  R1190     4.8731550574302673e-01
    z[5,1,2]  R1191     -4.9703961610794067e-01
    z[5,1,2]  R1192     -7.6577968895435333e-02
    z[5,1,2]  R1193     -2.5888085365295410e-01
    z[5,1,2]  R1194     2.3808078840374947e-02
    z[5,1,2]  R1195     -1.9698525965213776e-01
    z[5,1,2]  R1196     -8.8015489280223846e-02
    z[5,1,2]  R1197     -2.1856112778186798e-01
    z[5,1,2]  R1198     1.3577975332736969e-01
    z[5,1,2]  R1199     3.0285622924566269e-02
    z[5,1,2]  R1200     0.414943665266037
    z[5,1,2]  R1201     5.8672297000885010e-01
    z[5,1,2]  R1202     2.3136354982852936e-01
    z[5,1,2]  R1203     1.4333082363009453e-02
    z[5,1,2]  R1204     -6.9514997303485870e-02
    z[5,1,2]  R1205     6.2856063246726990e-02
    z[5,1,2]  R1206     -1.0920436121523380e-02
    z[5,1,2]  R1207     -1.6482889652252197e-01
    z[5,1,2]  R1208     -2.2052787244319916e-01
    z[5,1,2]  R1209     2.8026327490806580e-01
    z[5,1,2]  R1210     -5.4155772924423218e-01
    z[5,1,2]  R1211     -7.0680916309356689e-02
    z[5,1,2]  R1212     5.5067712068557739e-01
    z[5,1,2]  R1213     5.8514326810836792e-01
    z[5,1,2]  R1214     -1.2060177326202393e-01
    z[5,1,2]  R1215     2.7306309342384338e-01
    z[5,1,2]  R1216     1.7790491878986359e-01
    z[5,1,2]  R1217     1.7285411059856415e-01
    z[5,1,2]  R1218     0.066475510597229
    z[5,1,2]  R1219     -7.4864178895950317e-02
    z[5,1,2]  R1220     4.6833685040473938e-01
    z[5,1,2]  R1221     -1.3634940981864929e-01
    z[5,1,2]  R1222     1.3863706588745117e-01
    z[5,1,2]  R1223     1.1819404549896717e-02
    z[5,1,2]  R1224     0.0176091231405735
    z[5,1,2]  R1225     3.2341757416725159e-01
    z[5,1,2]  R1226     -1.7685323953628540e-01
    z[5,1,2]  R1227     1.3034267723560333e-01
    z[5,1,2]  R1228     -0.084355928003788
    z[5,1,2]  R1229     4.3649849295616150e-01
    z[5,1,2]  R1230     1.7765846848487854e-01
    z[5,1,2]  R1231     -1.4813593029975891e-01
    z[5,1,2]  R1232     -6.0631740838289261e-02
    z[5,1,2]  R1233     7.0911563932895660e-02
    z[5,1,2]  R1234     -2.7264159917831421e-01
    z[5,1,2]  R1235     -2.3721061646938324e-01
    z[5,1,2]  R1236     -1.1788218468427658e-01
    z[5,1,2]  R1237     -3.7549829483032227e-01
    z[5,1,2]  R1238     -1.2550555169582367e-01
    z[5,1,2]  R1239     -1.3326528668403625e-01
    z[5,1,2]  R1240     -6.1995391733944416e-03
    z[5,1,2]  R1241     3.1355914473533630e-01
    z[5,1,2]  R1242     -4.0524119138717651e-01
    z[5,1,2]  R1243     1.9952647387981415e-01
    z[5,1,2]  R1244     2.5198289752006531e-01
    z[5,1,2]  R1245     -6.6592156887054443e-02
    z[5,1,2]  R1246     -2.0460438728332520e-01
    z[5,1,2]  R1247     1.0704782605171204e-01
    z[5,1,2]  R1248     1.3273303396999836e-02
    z[5,1,2]  R1249     1.6280081868171692e-01
    z[5,1,2]  R1250     1.9041393697261810e-01
    z[5,1,2]  R1251     7.0002920925617218e-02
    z[5,1,2]  R1252     -2.6101595163345337e-01
    z[5,1,2]  R1253     7.1109563112258911e-02
    z[5,1,2]  R1254     1.5195743739604950e-01
    z[5,1,2]  R1255     -9.9591560661792755e-02
    z[5,1,2]  R1256     4.1462087631225586e-01
    z[5,1,2]  R1257     -3.3298179507255554e-01
    z[5,1,2]  R1258     4.3960276991128922e-02
    z[5,1,2]  R1259     -4.0967562235891819e-03
    z[5,1,2]  R1260     1.4690834283828735e-01
    z[5,1,2]  R1261     7.8408278524875641e-02
    z[5,1,2]  R1262     9.3858368694782257e-02
    z[5,1,2]  R1263     1.6618616878986359e-01
    z[5,1,2]  R1264     2.0638216286897659e-02
    z[5,1,2]  R1265     1.9519396126270294e-01
    z[5,1,2]  R1266     9.6629597246646881e-02
    z[5,1,2]  R1267     2.1174415946006775e-01
    z[5,1,2]  R1268     5.1338362693786621e-01
    z[5,1,2]  R1269     7.7930486202239990e-01
    z[5,1,3]  R14       1
    z[5,1,3]  R50       -1
    z[5,1,3]  R1142     -1
    z[5,1,3]  R1143     1
    z[5,1,3]  R1150     0.560824453830719
    z[5,1,3]  R1151     6.2672692537307739e-01
    z[5,1,3]  R1152     4.7803124785423279e-01
    z[5,1,3]  R1153     5.6229436397552490e-01
    z[5,1,3]  R1154     4.3165174126625061e-01
    z[5,1,3]  R1155     7.4449107050895691e-02
    z[5,1,3]  R1156     6.2117725610733032e-01
    z[5,1,3]  R1157     0.626302182674408
    z[5,1,3]  R1158     5.6914603710174561e-01
    z[5,1,3]  R1159     5.6571489572525024e-01
    z[5,1,3]  R1160     -1.4441484212875366e-01
    z[5,1,3]  R1161     -7.7496908605098724e-02
    z[5,1,3]  R1162     -2.6442435383796692e-01
    z[5,1,3]  R1163     -4.8002207279205322e-01
    z[5,1,3]  R1164     -4.4360291957855225e-01
    z[5,1,3]  R1165     -2.1171808242797852e-01
    z[5,1,3]  R1166     -3.5463970899581909e-01
    z[5,1,3]  R1167     -2.1362021565437317e-01
    z[5,1,3]  R1168     -3.4828168153762817e-01
    z[5,1,3]  R1169     -4.6822601556777954e-01
    z[5,1,3]  R1170     -3.6039733886718750e-01
    z[5,1,3]  R1171     -4.6259489655494690e-01
    z[5,1,3]  R1172     -3.3161154389381409e-01
    z[5,1,3]  R1173     -4.0480870008468628e-01
    z[5,1,3]  R1174     -3.9341679215431213e-01
    z[5,1,3]  R1175     -4.7615250945091248e-01
    z[5,1,3]  R1176     -5.3505256772041321e-02
    z[5,1,3]  R1177     -1.6752177476882935e-01
    z[5,1,3]  R1178     -1.6175325214862823e-01
    z[5,1,3]  R1179     -1.7537190020084381e-01
    z[5,1,3]  R1180     -3.8207793235778809e-01
    z[5,1,3]  R1181     -3.5980913043022156e-01
    z[5,1,3]  R1182     -2.4678030610084534e-01
    z[5,1,3]  R1183     -2.0257394015789032e-01
    z[5,1,3]  R1184     -2.3464618623256683e-01
    z[5,1,3]  R1185     -2.1929797530174255e-01
    z[5,1,3]  R1186     -2.0114910602569580e-01
    z[5,1,3]  R1187     -8.3379305899143219e-02
    z[5,1,3]  R1188     -2.5607371330261230e-01
    z[5,1,3]  R1189     1.4335356652736664e-01
    z[5,1,3]  R1190     -4.4107311964035034e-01
    z[5,1,3]  R1191     1.2474588304758072e-01
    z[5,1,3]  R1192     1.5756097435951233e-01
    z[5,1,3]  R1193     3.0503696203231812e-01
    z[5,1,3]  R1194     -5.3937506675720215e-01
    z[5,1,3]  R1195     2.5046974420547485e-01
    z[5,1,3]  R1196     2.8962868452072144e-01
    z[5,1,3]  R1197     -6.2990888953208923e-02
    z[5,1,3]  R1198     3.1556281447410583e-01
    z[5,1,3]  R1199     3.2318988442420959e-01
    z[5,1,3]  R1200     -3.2534915208816528e-01
    z[5,1,3]  R1201     -5.1158469915390015e-01
    z[5,1,3]  R1202     -5.4444450139999390e-01
    z[5,1,3]  R1203     1.1107818782329559e-01
    z[5,1,3]  R1204     -3.8976454734802246e-01
    z[5,1,3]  R1205     3.8681519031524658e-01
    z[5,1,3]  R1206     2.7715355157852173e-01
    z[5,1,3]  R1207     -4.7014206647872925e-02
    z[5,1,3]  R1208     1.9265557825565338e-01
    z[5,1,3]  R1209     -8.7753236293792725e-01
    z[5,1,3]  R1210     1.5672484040260315e-01
    z[5,1,3]  R1211     2.4916955828666687e-01
    z[5,1,3]  R1212     -3.6101886630058289e-01
    z[5,1,3]  R1213     -5.2012687921524048e-01
    z[5,1,3]  R1214     7.0098556578159332e-02
    z[5,1,3]  R1215     -5.2916455268859863e-01
    z[5,1,3]  R1216     -7.9334115982055664e-01
    z[5,1,3]  R1217     -9.6878513693809509e-02
    z[5,1,3]  R1218     -7.8511595726013184e-01
    z[5,1,3]  R1219     -6.5803134441375732e-01
    z[5,1,3]  R1220     -5.4513007402420044e-01
    z[5,1,3]  R1221     -0.655022382736206
    z[5,1,3]  R1222     -8.1561261415481567e-01
    z[5,1,3]  R1223     -1.9730459153652191e-01
    z[5,1,3]  R1224     -7.1871173381805420e-01
    z[5,1,3]  R1225     -7.6846402883529663e-01
    z[5,1,3]  R1226     -9.5163661241531372e-01
    z[5,1,3]  R1227     -7.2710955142974854e-01
    z[5,1,3]  R1228     -2.7952216565608978e-02
    z[5,1,3]  R1229     -2.4547162652015686e-01
    z[5,1,3]  R1230     -5.2714014053344727e-01
    z[5,1,3]  R1231     -1.7141684889793396e-01
    z[5,1,3]  R1232     -2.4051589891314507e-02
    z[5,1,3]  R1233     -5.9793466329574585e-01
    z[5,1,3]  R1234     -4.6273627877235413e-01
    z[5,1,3]  R1235     -2.2545909881591797e-01
    z[5,1,3]  R1236     -3.8147419691085815e-01
    z[5,1,3]  R1237     -5.8227157592773438e-01
    z[5,1,3]  R1238     -2.6461067795753479e-01
    z[5,1,3]  R1239     -3.9880636334419250e-01
    z[5,1,3]  R1240     -1.2796452641487122e-01
    z[5,1,3]  R1241     2.8310397267341614e-01
    z[5,1,3]  R1242     2.4331583082675934e-01
    z[5,1,3]  R1243     7.2456523776054382e-02
    z[5,1,3]  R1244     4.0017911791801453e-01
    z[5,1,3]  R1245     3.2510197162628174e-01
    z[5,1,3]  R1246     1.0274247825145721e-01
    z[5,1,3]  R1247     4.3138790130615234e-01
    z[5,1,3]  R1248     6.0794878005981445e-01
    z[5,1,3]  R1249     2.7000385522842407e-01
    z[5,1,3]  R1250     -2.2122806310653687e-01
    z[5,1,3]  R1251     -2.4943706393241882e-01
    z[5,1,3]  R1252     3.1544142961502075e-01
    z[5,1,3]  R1253     2.4635457992553711e-01
    z[5,1,3]  R1254     -4.2376585304737091e-02
    z[5,1,3]  R1255     5.2524778991937637e-02
    z[5,1,3]  R1256     -1.5484818816184998e-01
    z[5,1,3]  R1257     1.7375695705413818e-01
    z[5,1,3]  R1258     2.9080143570899963e-01
    z[5,1,3]  R1259     2.5139921903610229e-01
    z[5,1,3]  R1260     -5.9669923782348633e-01
    z[5,1,3]  R1261     -0.152748703956604
    z[5,1,3]  R1262     -3.1927478313446045e-01
    z[5,1,3]  R1263     7.5129017233848572e-02
    z[5,1,3]  R1264     -6.4138539135456085e-02
    z[5,1,3]  R1265     -3.1122544407844543e-01
    z[5,1,3]  R1266     3.1744691729545593e-01
    z[5,1,3]  R1267     -4.7472648322582245e-02
    z[5,1,3]  R1268     0.641027569770813
    z[5,1,3]  R1269     4.1837012767791748e-01
    z[5,1,4]  R15       1
    z[5,1,4]  R51       -1
    z[5,1,4]  R1144     -1
    z[5,1,4]  R1145     1
    z[5,1,4]  R1150     1.5356155112385750e-02
    z[5,1,4]  R1151     -0.0917850136756897
    z[5,1,4]  R1152     7.6447036117315292e-03
    z[5,1,4]  R1153     4.8172643780708313e-01
    z[5,1,4]  R1154     3.1640896201133728e-01
    z[5,1,4]  R1155     3.9022436738014221e-01
    z[5,1,4]  R1156     2.5093179941177368e-01
    z[5,1,4]  R1157     1.8925313651561737e-01
    z[5,1,4]  R1158     1.0541664063930511e-01
    z[5,1,4]  R1159     1.1602368950843811e-01
    z[5,1,4]  R1160     -1.9468156993389130e-01
    z[5,1,4]  R1161     -1.3204167783260345e-01
    z[5,1,4]  R1162     -1.7216181382536888e-02
    z[5,1,4]  R1163     3.7903830409049988e-02
    z[5,1,4]  R1164     -0.0446300208568573
    z[5,1,4]  R1165     2.8981253504753113e-01
    z[5,1,4]  R1166     -3.0714502930641174e-01
    z[5,1,4]  R1167     2.1726517379283905e-01
    z[5,1,4]  R1168     -8.0811433494091034e-02
    z[5,1,4]  R1169     -6.2830984592437744e-02
    z[5,1,4]  R1170     -5.6887006759643555e-01
    z[5,1,4]  R1171     -2.6850342750549316e-01
    z[5,1,4]  R1172     -2.6796698570251465e-01
    z[5,1,4]  R1173     -1.0614439845085144e-01
    z[5,1,4]  R1174     -1.9418950378894806e-01
    z[5,1,4]  R1175     1.1833731085062027e-02
    z[5,1,4]  R1176     -2.5105470418930054e-01
    z[5,1,4]  R1177     6.4505837857723236e-02
    z[5,1,4]  R1178     -1.9274080172181129e-02
    z[5,1,4]  R1179     -0.585271418094635
    z[5,1,4]  R1180     -5.0353991985321045e-01
    z[5,1,4]  R1181     -0.446170449256897
    z[5,1,4]  R1182     1.9488246738910675e-01
    z[5,1,4]  R1183     -5.4727095365524292e-01
    z[5,1,4]  R1184     -4.5689767599105835e-01
    z[5,1,4]  R1185     -4.6750482916831970e-01
    z[5,1,4]  R1186     2.2813653573393822e-02
    z[5,1,4]  R1187     -6.5138608217239380e-02
    z[5,1,4]  R1188     -3.0799213051795959e-01
    z[5,1,4]  R1189     -4.4952924363315105e-03
    z[5,1,4]  R1190     -3.4286966919898987e-01
    z[5,1,4]  R1191     1.4899596571922302e-01
    z[5,1,4]  R1192     1.6764806583523750e-02
    z[5,1,4]  R1193     2.8918796777725220e-01
    z[5,1,4]  R1194     1.6099166125059128e-02
    z[5,1,4]  R1195     -2.2511529922485352e-01
    z[5,1,4]  R1196     -1.0972981899976730e-01
    z[5,1,4]  R1197     3.7542146444320679e-01
    z[5,1,4]  R1198     -1.4024865627288818e-01
    z[5,1,4]  R1199     -3.3937383443117142e-02
    z[5,1,4]  R1200     -4.1775226593017578e-01
    z[5,1,4]  R1201     1.7556536197662354e-01
    z[5,1,4]  R1202     0.0706513300538063
    z[5,1,4]  R1203     -1.0516929626464844e-01
    z[5,1,4]  R1204     8.2739852368831635e-03
    z[5,1,4]  R1205     0.0567634291946888
    z[5,1,4]  R1206     1.4633840322494507e-01
    z[5,1,4]  R1207     3.4421750903129578e-01
    z[5,1,4]  R1208     0.0528845377266407
    z[5,1,4]  R1209     -3.5412866622209549e-02
    z[5,1,4]  R1210     -1.4077021181583405e-01
    z[5,1,4]  R1211     -7.4031746387481689e-01
    z[5,1,4]  R1212     3.5037645697593689e-01
    z[5,1,4]  R1213     3.5571921616792679e-02
    z[5,1,4]  R1214     5.6037232279777527e-03
    z[5,1,4]  R1215     2.2409898042678833e-01
    z[5,1,4]  R1216     -2.8389078378677368e-01
    z[5,1,4]  R1217     3.2641181349754333e-01
    z[5,1,4]  R1218     3.6762478947639465e-01
    z[5,1,4]  R1219     1.1520207673311234e-01
    z[5,1,4]  R1220     -1.6303323209285736e-01
    z[5,1,4]  R1221     -0.534935474395752
    z[5,1,4]  R1222     -1.7534036189317703e-02
    z[5,1,4]  R1223     1.9538573920726776e-02
    z[5,1,4]  R1224     -2.8727620840072632e-01
    z[5,1,4]  R1225     7.8169278800487518e-02
    z[5,1,4]  R1226     2.9616493731737137e-02
    z[5,1,4]  R1227     4.9636635184288025e-01
    z[5,1,4]  R1228     2.3595626652240753e-01
    z[5,1,4]  R1229     2.0990064740180969e-01
    z[5,1,4]  R1230     -7.4473358690738678e-02
    z[5,1,4]  R1231     3.5818558186292648e-02
    z[5,1,4]  R1232     -1.9742001593112946e-01
    z[5,1,4]  R1233     3.3438715338706970e-01
    z[5,1,4]  R1234     -0.207333505153656
    z[5,1,4]  R1235     -1.1061331629753113e-01
    z[5,1,4]  R1236     -0.0686548575758934
    z[5,1,4]  R1237     2.1860344707965851e-01
    z[5,1,4]  R1238     -6.0606843233108521e-01
    z[5,1,4]  R1239     -4.0920057892799377e-01
    z[5,1,4]  R1240     -2.6890264824032784e-02
    z[5,1,4]  R1241     -2.5274107232689857e-02
    z[5,1,4]  R1242     2.0200443267822266e-01
    z[5,1,4]  R1243     1.1528035998344421e-01
    z[5,1,4]  R1244     -3.2284778356552124e-01
    z[5,1,4]  R1245     -7.9762347042560577e-02
    z[5,1,4]  R1246     6.1005318164825439e-01
    z[5,1,4]  R1247     1.2749303877353668e-01
    z[5,1,4]  R1248     -1.8790359795093536e-01
    z[5,1,4]  R1249     -5.0215828418731689e-01
    z[5,1,4]  R1250     -1.1892067268490791e-02
    z[5,1,4]  R1251     -6.9857522845268250e-02
    z[5,1,4]  R1252     -2.5380348786711693e-02
    z[5,1,4]  R1253     2.1475711464881897e-01
    z[5,1,4]  R1254     3.8521581888198853e-01
    z[5,1,4]  R1255     1.9272805750370026e-01
    z[5,1,4]  R1256     -4.7011303901672363e-01
    z[5,1,4]  R1257     6.4100092649459839e-01
    z[5,1,4]  R1258     -2.9409998655319214e-01
    z[5,1,4]  R1259     -7.3312622308731079e-01
    z[5,1,4]  R1260     -3.9989843964576721e-01
    z[5,1,4]  R1261     5.2233719825744629e-01
    z[5,1,4]  R1262     0.336622953414917
    z[5,1,4]  R1263     2.9592399951070547e-03
    z[5,1,4]  R1264     1.1275199800729752e-01
    z[5,1,4]  R1265     4.6267968416213989e-01
    z[5,1,4]  R1266     -1.8894420564174652e-01
    z[5,1,4]  R1267     -0.502036452293396
    z[5,1,4]  R1268     0.291445255279541
    z[5,1,4]  R1269     2.7686533331871033e-01
    z[5,1,5]  R16       1
    z[5,1,5]  R52       -1
    z[5,1,5]  R1146     -1
    z[5,1,5]  R1147     1
    z[5,1,5]  R1150     -0.27354696393013
    z[5,1,5]  R1151     -2.5523068383336067e-02
    z[5,1,5]  R1152     9.2905461788177490e-02
    z[5,1,5]  R1153     -3.4722540527582169e-02
    z[5,1,5]  R1154     1.9602908194065094e-01
    z[5,1,5]  R1155     -3.6198985762894154e-03
    z[5,1,5]  R1156     -2.9300352931022644e-01
    z[5,1,5]  R1157     -5.6037425994873047e-01
    z[5,1,5]  R1158     3.3743798732757568e-01
    z[5,1,5]  R1159     -4.0920349955558777e-01
    z[5,1,5]  R1160     1.9935664534568787e-01
    z[5,1,5]  R1161     1.1492899060249329e-01
    z[5,1,5]  R1162     5.8168604969978333e-02
    z[5,1,5]  R1163     -1.5526196360588074e-01
    z[5,1,5]  R1164     1.9884844124317169e-01
    z[5,1,5]  R1165     -1.8055659532546997e-01
    z[5,1,5]  R1166     -1.2239484116435051e-02
    z[5,1,5]  R1167     -2.8148156404495239e-01
    z[5,1,5]  R1168     -2.3173154890537262e-01
    z[5,1,5]  R1169     -2.4595829844474792e-01
    z[5,1,5]  R1170     1.5505455434322357e-01
    z[5,1,5]  R1171     2.5466531515121460e-01
    z[5,1,5]  R1172     -2.3919600062072277e-03
    z[5,1,5]  R1173     3.3560761809349060e-01
    z[5,1,5]  R1174     4.0550000965595245e-02
    z[5,1,5]  R1175     1.2554794549942017e-01
    z[5,1,5]  R1176     1.9845777750015259e-01
    z[5,1,5]  R1177     0.188396617770195
    z[5,1,5]  R1178     3.7591537833213806e-01
    z[5,1,5]  R1179     1.6490317881107330e-01
    z[5,1,5]  R1180     -6.6061496734619141e-02
    z[5,1,5]  R1181     -4.3922942876815796e-01
    z[5,1,5]  R1182     -1.5732270479202271e-01
    z[5,1,5]  R1183     -5.5782753229141235e-01
    z[5,1,5]  R1184     3.1543437391519547e-02
    z[5,1,5]  R1185     1.6941666603088379e-01
    z[5,1,5]  R1186     1.2285882979631424e-01
    z[5,1,5]  R1187     7.1033620834350586e-01
    z[5,1,5]  R1188     4.4255855679512024e-01
    z[5,1,5]  R1189     -9.7863718867301941e-02
    z[5,1,5]  R1190     -1.5662544965744019e-01
    z[5,1,5]  R1191     -6.8838918209075928e-01
    z[5,1,5]  R1192     -1.7030051350593567e-01
    z[5,1,5]  R1193     -9.6369504928588867e-02
    z[5,1,5]  R1194     1.1636684834957123e-01
    z[5,1,5]  R1195     -5.4046493768692017e-01
    z[5,1,5]  R1196     -0.29739910364151
    z[5,1,5]  R1197     -2.8796562552452087e-01
    z[5,1,5]  R1198     0.449703186750412
    z[5,1,5]  R1199     2.3624885082244873e-01
    z[5,1,5]  R1200     3.7510338425636292e-01
    z[5,1,5]  R1201     -1.0032492876052856e-01
    z[5,1,5]  R1202     4.3588620424270630e-01
    z[5,1,5]  R1203     -3.6930760741233826e-01
    z[5,1,5]  R1204     0.152458056807518
    z[5,1,5]  R1205     -1.1823111772537231e-01
    z[5,1,5]  R1206     -3.2327221706509590e-03
    z[5,1,5]  R1207     1.3134506344795227e-01
    z[5,1,5]  R1208     -5.1871605217456818e-02
    z[5,1,5]  R1209     1.1105019599199295e-01
    z[5,1,5]  R1210     2.6202493906021118e-01
    z[5,1,5]  R1211     -1.7771621048450470e-01
    z[5,1,5]  R1212     0.144393190741539
    z[5,1,5]  R1213     1.5258552134037018e-01
    z[5,1,5]  R1214     1.6942301392555237e-01
    z[5,1,5]  R1215     1.9821600615978241e-01
    z[5,1,5]  R1216     -1.3792443275451660e-01
    z[5,1,5]  R1217     4.6606764197349548e-01
    z[5,1,5]  R1218     1.7696402966976166e-01
    z[5,1,5]  R1219     5.2001518011093140e-01
    z[5,1,5]  R1220     1.5033917129039764e-01
    z[5,1,5]  R1221     1.9275434315204620e-01
    z[5,1,5]  R1222     -7.8589223325252533e-02
    z[5,1,5]  R1223     -3.2607099413871765e-01
    z[5,1,5]  R1224     8.9479319751262665e-02
    z[5,1,5]  R1225     -1.1679124087095261e-01
    z[5,1,5]  R1226     1.3712685555219650e-02
    z[5,1,5]  R1227     -7.9214125871658325e-02
    z[5,1,5]  R1228     -8.7641589343547821e-02
    z[5,1,5]  R1229     -1.5276958048343658e-01
    z[5,1,5]  R1230     -4.2726588249206543e-01
    z[5,1,5]  R1231     -4.4893521070480347e-01
    z[5,1,5]  R1232     -1.9430667161941528e-01
    z[5,1,5]  R1233     1.8883095681667328e-01
    z[5,1,5]  R1234     -3.1816062331199646e-01
    z[5,1,5]  R1235     3.5657492280006409e-01
    z[5,1,5]  R1236     -0.413128525018692
    z[5,1,5]  R1237     0.0798230916261673
    z[5,1,5]  R1238     -5.1094375550746918e-02
    z[5,1,5]  R1239     1.0263931751251221e-01
    z[5,1,5]  R1240     3.4040069580078125e-01
    z[5,1,5]  R1241     9.6004633232951164e-03
    z[5,1,5]  R1242     2.4548135697841644e-01
    z[5,1,5]  R1243     3.8709971308708191e-01
    z[5,1,5]  R1244     3.2117941975593567e-01
    z[5,1,5]  R1245     4.8737379908561707e-01
    z[5,1,5]  R1246     3.2575258612632751e-01
    z[5,1,5]  R1247     3.6358457803726196e-01
    z[5,1,5]  R1248     2.8527006506919861e-01
    z[5,1,5]  R1249     1.6940513253211975e-01
    z[5,1,5]  R1250     5.3804576396942139e-01
    z[5,1,5]  R1251     4.4933566451072693e-01
    z[5,1,5]  R1252     3.4121209383010864e-01
    z[5,1,5]  R1253     2.7260869741439819e-01
    z[5,1,5]  R1254     -1.8417501449584961e-01
    z[5,1,5]  R1255     -4.8523122072219849e-01
    z[5,1,5]  R1256     -5.0318732857704163e-02
    z[5,1,5]  R1257     -5.4362822324037552e-02
    z[5,1,5]  R1258     -5.0268638134002686e-01
    z[5,1,5]  R1259     -9.4509720802307129e-02
    z[5,1,5]  R1260     6.2728708982467651e-01
    z[5,1,5]  R1261     -8.9115977287292480e-02
    z[5,1,5]  R1262     -1.9698626419994980e-04
    z[5,1,5]  R1263     4.9155500531196594e-01
    z[5,1,5]  R1264     1.5471910126507282e-02
    z[5,1,5]  R1265     7.5048275291919708e-02
    z[5,1,5]  R1266     -6.8633213639259338e-02
    z[5,1,5]  R1267     -9.3955181539058685e-02
    z[5,1,5]  R1268     2.3310044407844543e-01
    z[5,1,5]  R1269     9.1374032199382782e-02
    z[5,1,6]  R17       1
    z[5,1,6]  R53       -1
    z[5,1,6]  R1148     -1
    z[5,1,6]  R1149     1
    z[5,1,6]  R1150     1.2567305937409401e-02
    z[5,1,6]  R1151     -2.7718612551689148e-01
    z[5,1,6]  R1152     -2.9566511511802673e-01
    z[5,1,6]  R1153     3.4433576464653015e-01
    z[5,1,6]  R1154     5.5579822510480881e-02
    z[5,1,6]  R1155     -1.4310921728610992e-01
    z[5,1,6]  R1156     -1.1749270558357239e-01
    z[5,1,6]  R1157     -1.9455835223197937e-01
    z[5,1,6]  R1158     3.4837210178375244e-01
    z[5,1,6]  R1159     2.6342767477035522e-01
    z[5,1,6]  R1160     -4.6765303611755371e-01
    z[5,1,6]  R1161     -1.0650959610939026e-01
    z[5,1,6]  R1162     -1.9320906698703766e-01
    z[5,1,6]  R1163     1.5103018283843994e-01
    z[5,1,6]  R1164     -1.5218277275562286e-01
    z[5,1,6]  R1165     -2.6157429441809654e-02
    z[5,1,6]  R1166     -5.3551908582448959e-02
    z[5,1,6]  R1167     -3.7203781306743622e-02
    z[5,1,6]  R1168     -2.3170320689678192e-01
    z[5,1,6]  R1169     -1.9556893035769463e-02
    z[5,1,6]  R1170     1.0727799683809280e-01
    z[5,1,6]  R1171     3.3926871418952942e-01
    z[5,1,6]  R1172     -6.0322366654872894e-02
    z[5,1,6]  R1173     3.6199495196342468e-01
    z[5,1,6]  R1174     0.00312709528952837
    z[5,1,6]  R1175     -7.7364325523376465e-02
    z[5,1,6]  R1176     1.3736440241336823e-01
    z[5,1,6]  R1177     -2.8281034901738167e-03
    z[5,1,6]  R1178     1.7507965862751007e-01
    z[5,1,6]  R1179     2.0650139078497887e-02
    z[5,1,6]  R1180     4.1523313522338867e-01
    z[5,1,6]  R1181     -4.1135692596435547e-01
    z[5,1,6]  R1182     4.2290221899747849e-02
    z[5,1,6]  R1183     3.9515611529350281e-01
    z[5,1,6]  R1184     2.3404273390769958e-01
    z[5,1,6]  R1185     4.8952829092741013e-02
    z[5,1,6]  R1186     9.9118478596210480e-02
    z[5,1,6]  R1187     0.0359313040971756
    z[5,1,6]  R1188     4.5354613661766052e-01
    z[5,1,6]  R1189     -1.1205860227346420e-01
    z[5,1,6]  R1190     -3.9465554058551788e-02
    z[5,1,6]  R1191     3.7048763036727905e-01
    z[5,1,6]  R1192     -4.8416815698146820e-02
    z[5,1,6]  R1193     1.1586034297943115e-01
    z[5,1,6]  R1194     1.3355457782745361e-01
    z[5,1,6]  R1195     3.4233994781970978e-02
    z[5,1,6]  R1196     4.4190678745508194e-02
    z[5,1,6]  R1197     -3.3666866365820169e-03
    z[5,1,6]  R1198     2.9192259907722473e-01
    z[5,1,6]  R1199     -2.8641945123672485e-01
    z[5,1,6]  R1200     2.7961862087249756e-01
    z[5,1,6]  R1201     -2.1818424761295319e-01
    z[5,1,6]  R1202     1.6367980837821960e-01
    z[5,1,6]  R1203     1.7917476594448090e-01
    z[5,1,6]  R1204     -6.6021241247653961e-02
    z[5,1,6]  R1205     0.237451434135437
    z[5,1,6]  R1206     -1.2927031144499779e-02
    z[5,1,6]  R1207     3.5853590816259384e-02
    z[5,1,6]  R1208     -3.4651052951812744e-01
    z[5,1,6]  R1209     -0.0336323045194149
    z[5,1,6]  R1210     1.9779159128665924e-01
    z[5,1,6]  R1211     3.3439654111862183e-01
    z[5,1,6]  R1212     -3.0641382560133934e-02
    z[5,1,6]  R1213     1.1021838337182999e-01
    z[5,1,6]  R1214     4.5923396944999695e-01
    z[5,1,6]  R1215     8.8693335652351379e-02
    z[5,1,6]  R1216     -8.4558278322219849e-02
    z[5,1,6]  R1217     2.6078581809997559e-01
    z[5,1,6]  R1218     -4.6534806489944458e-02
    z[5,1,6]  R1219     1.0844473540782928e-01
    z[5,1,6]  R1220     1.2813293933868408e-01
    z[5,1,6]  R1221     -5.9406068176031113e-02
    z[5,1,6]  R1222     -3.6950135231018066e-01
    z[5,1,6]  R1223     4.1972849518060684e-02
    z[5,1,6]  R1224     -4.5489165186882019e-01
    z[5,1,6]  R1225     4.8335094004869461e-02
    z[5,1,6]  R1226     5.9358462691307068e-02
    z[5,1,6]  R1227     6.6626533865928650e-02
    z[5,1,6]  R1228     5.0326216220855713e-01
    z[5,1,6]  R1229     7.9438820481300354e-02
    z[5,1,6]  R1230     -8.4079019725322723e-02
    z[5,1,6]  R1231     3.4917865414172411e-03
    z[5,1,6]  R1232     9.3952931463718414e-02
    z[5,1,6]  R1233     -2.6736435294151306e-01
    z[5,1,6]  R1234     5.2625524997711182e-01
    z[5,1,6]  R1235     -8.1423139199614525e-03
    z[5,1,6]  R1236     2.3798566311597824e-02
    z[5,1,6]  R1237     4.5384612679481506e-01
    z[5,1,6]  R1238     2.9452082514762878e-01
    z[5,1,6]  R1239     5.3818774223327637e-01
    z[5,1,6]  R1240     2.4685344099998474e-01
    z[5,1,6]  R1241     -2.9452103376388550e-01
    z[5,1,6]  R1242     4.3733417987823486e-01
    z[5,1,6]  R1243     -1.2433338165283203e-01
    z[5,1,6]  R1244     -3.8061115145683289e-01
    z[5,1,6]  R1245     0.0547383613884449
    z[5,1,6]  R1246     1.0755355656147003e-01
    z[5,1,6]  R1247     0.0466521717607975
    z[5,1,6]  R1248     -0.074155293405056
    z[5,1,6]  R1249     1.6571673750877380e-01
    z[5,1,6]  R1250     1.4408499002456665e-02
    z[5,1,6]  R1251     -1.2025839835405350e-01
    z[5,1,6]  R1252     5.1061216741800308e-02
    z[5,1,6]  R1253     -1.9564969837665558e-01
    z[5,1,6]  R1254     8.6739897727966309e-02
    z[5,1,6]  R1255     3.4491127729415894e-01
    z[5,1,6]  R1256     -5.8239664882421494e-02
    z[5,1,6]  R1257     4.4052168726921082e-02
    z[5,1,6]  R1258     1.7404365539550781e-01
    z[5,1,6]  R1259     2.4868105351924896e-01
    z[5,1,6]  R1260     -2.5180861353874207e-02
    z[5,1,6]  R1261     7.3525518178939819e-02
    z[5,1,6]  R1262     2.1956019103527069e-01
    z[5,1,6]  R1263     -2.2008366882801056e-01
    z[5,1,6]  R1264     1.4444258809089661e-01
    z[5,1,6]  R1265     -2.2445949912071228e-01
    z[5,1,6]  R1266     -1.0294097661972046e-01
    z[5,1,6]  R1267     1.2430543079972267e-02
    z[5,1,6]  R1268     -2.4548610672354698e-02
    z[5,1,6]  R1269     -1.1802790313959122e-01
    z[2,4,0]  R20       -1
    z[2,4,0]  R38       1
    z[2,4,0]  R1270     -1
    z[2,4,0]  R1271     1
    z[2,4,0]  R1284     3.7873715162277222e-01
    z[2,4,0]  R1285     5.3333443403244019e-01
    z[2,4,0]  R1286     6.8667048215866089e-01
    z[2,4,0]  R1287     -1.4450901746749878e-01
    z[2,4,0]  R1288     6.8553018569946289e-01
    z[2,4,0]  R1289     6.5093624591827393e-01
    z[2,4,0]  R1290     7.6829367876052856e-01
    z[2,4,0]  R1291     5.8579719066619873e-01
    z[2,4,0]  R1292     -0.367805153131485
    z[2,4,0]  R1293     1.2440484762191772e-01
    z[2,4,0]  R1294     7.8678119182586670e-01
    z[2,4,0]  R1295     6.4782553911209106e-01
    z[2,4,0]  R1296     7.5260007381439209e-01
    z[2,4,0]  R1297     6.2868463993072510e-01
    z[2,4,0]  R1298     6.5628039836883545e-01
    z[2,4,0]  R1299     7.3745173215866089e-01
    z[2,4,0]  R1300     7.6738870143890381e-01
    z[2,4,0]  R1301     5.6793701648712158e-01
    z[2,4,0]  R1302     7.0700442790985107e-01
    z[2,4,0]  R1303     5.2821296453475952e-01
    z[2,4,0]  R1304     -5.5435019731521606e-01
    z[2,4,0]  R1305     -1.3739745318889618e-01
    z[2,4,0]  R1306     -2.4997992813587189e-01
    z[2,4,0]  R1307     -9.3141689896583557e-02
    z[2,4,0]  R1308     -3.6504247784614563e-01
    z[2,4,0]  R1309     -1.8392980098724365e-01
    z[2,4,0]  R1310     -2.9985910654067993e-01
    z[2,4,0]  R1311     -1.4240592718124390e-01
    z[2,4,0]  R1312     -1.1798799037933350e-01
    z[2,4,0]  R1313     -8.4018073976039886e-02
    z[2,4,0]  R1314     2.7113190293312073e-01
    z[2,4,0]  R1315     7.4907368421554565e-01
    z[2,4,0]  R1316     -6.4337062835693359e-01
    z[2,4,0]  R1317     5.5352133512496948e-01
    z[2,4,0]  R1318     -8.7810635566711426e-01
    z[2,4,0]  R1319     -8.5123598575592041e-01
    z[2,4,0]  R1320     -7.8212362527847290e-01
    z[2,4,0]  R1321     -7.1261632442474365e-01
    z[2,4,0]  R1322     -8.3282917737960815e-01
    z[2,4,0]  R1323     -8.2556849718093872e-01
    z[2,4,0]  R1324     -8.3808355033397675e-02
    z[2,4,0]  R1325     -6.3356541097164154e-02
    z[2,4,0]  R1326     1.9311730563640594e-01
    z[2,4,0]  R1327     1.9144977629184723e-01
    z[2,4,0]  R1328     -9.8120421171188354e-02
    z[2,4,0]  R1329     -6.7651188373565674e-01
    z[2,4,0]  R1330     7.1136116981506348e-01
    z[2,4,0]  R1331     5.4982852935791016e-01
    z[2,4,0]  R1332     -0.673531174659729
    z[2,4,0]  R1333     5.1509976387023926e-01
    z[2,4,0]  R1334     -5.5446839332580566e-01
    z[2,4,0]  R1335     -6.9315418601036072e-02
    z[2,4,0]  R1336     3.8593227509409189e-03
    z[2,4,0]  R1337     3.5450258851051331e-01
    z[2,4,0]  R1338     -1.2340407073497772e-01
    z[2,4,0]  R1339     -4.0811732411384583e-02
    z[2,4,0]  R1340     -2.8628918528556824e-01
    z[2,4,0]  R1341     4.2757335305213928e-01
    z[2,4,0]  R1342     -2.9277181625366211e-01
    z[2,4,0]  R1343     6.0205173492431641e-01
    z[2,4,0]  R1344     -4.4183117151260376e-01
    z[2,4,0]  R1345     3.0860555171966553e-01
    z[2,4,0]  R1346     -1.1031243205070496e-01
    z[2,4,0]  R1347     -1.3681454956531525e-01
    z[2,4,0]  R1348     5.8535623550415039e-01
    z[2,4,0]  R1349     -8.4071463346481323e-01
    z[2,4,0]  R1350     -7.9630863666534424e-01
    z[2,4,0]  R1351     -7.1491372585296631e-01
    z[2,4,0]  R1352     6.0217022895812988e-02
    z[2,4,0]  R1353     -1.7587128281593323e-01
    z[2,4,0]  R1354     -4.3566304445266724e-01
    z[2,4,0]  R1355     1.1860569566488266e-01
    z[2,4,0]  R1356     -3.3444091677665710e-01
    z[2,4,0]  R1357     -4.9569246172904968e-01
    z[2,4,0]  R1358     -4.7821506857872009e-01
    z[2,4,0]  R1359     -2.5301378965377808e-01
    z[2,4,0]  R1360     0.00965464673936367
    z[2,4,0]  R1361     -7.8255213797092438e-02
    z[2,4,0]  R1362     1.2590855360031128e-01
    z[2,4,0]  R1363     -1.0428953170776367e-01
    z[2,4,0]  R1364     0.323359876871109
    z[2,4,0]  R1365     3.7382391095161438e-01
    z[2,4,0]  R1366     7.9257696866989136e-02
    z[2,4,0]  R1367     3.5170421004295349e-01
    z[2,4,0]  R1368     3.0049356818199158e-01
    z[2,4,0]  R1369     7.3320543766021729e-01
    z[2,4,0]  R1370     1.4527393877506256e-01
    z[2,4,0]  R1371     6.4717435836791992e-01
    z[2,4,0]  R1372     -1.5803582966327667e-01
    z[2,4,0]  R1373     -3.5336855053901672e-01
    z[2,4,0]  R1374     2.2044897079467773e-01
    z[2,4,0]  R1375     0.0868205651640892
    z[2,4,0]  R1376     -8.1602618098258972e-02
    z[2,4,0]  R1377     2.1975185722112656e-02
    z[2,4,0]  R1378     7.1332126855850220e-02
    z[2,4,0]  R1379     1.3148538768291473e-01
    z[2,4,0]  R1380     -5.4136735200881958e-01
    z[2,4,0]  R1381     5.0642073154449463e-01
    z[2,4,0]  R1382     1.5650652348995209e-01
    z[2,4,0]  R1383     -1.3747981190681458e-01
    z[2,4,1]  R21       -1
    z[2,4,1]  R39       1
    z[2,4,1]  R1272     -1
    z[2,4,1]  R1273     1
    z[2,4,1]  R1284     5.2845132350921631e-01
    z[2,4,1]  R1285     4.2615747451782227e-01
    z[2,4,1]  R1286     4.8639130592346191e-01
    z[2,4,1]  R1287     3.4531673789024353e-01
    z[2,4,1]  R1288     5.2249819040298462e-01
    z[2,4,1]  R1289     4.6735259890556335e-01
    z[2,4,1]  R1290     3.0830904841423035e-01
    z[2,4,1]  R1291     4.4670420885086060e-01
    z[2,4,1]  R1292     1.5149046480655670e-01
    z[2,4,1]  R1293     4.2348146438598633e-01
    z[2,4,1]  R1294     -3.6520402878522873e-02
    z[2,4,1]  R1295     -0.224799245595932
    z[2,4,1]  R1296     -1.0453260689973831e-01
    z[2,4,1]  R1297     -3.3511823415756226e-01
    z[2,4,1]  R1298     -4.3470478057861328e-01
    z[2,4,1]  R1299     -3.2897549867630005e-01
    z[2,4,1]  R1300     -2.3882986605167389e-01
    z[2,4,1]  R1301     -1.6404964029788971e-01
    z[2,4,1]  R1302     -1.0996983945369720e-01
    z[2,4,1]  R1303     -2.9862865805625916e-01
    z[2,4,1]  R1304     -5.4568356275558472e-01
    z[2,4,1]  R1305     -8.4708386659622192e-01
    z[2,4,1]  R1306     -8.1526309251785278e-01
    z[2,4,1]  R1307     -0.789399266242981
    z[2,4,1]  R1308     -7.7593863010406494e-01
    z[2,4,1]  R1309     -7.4482750892639160e-01
    z[2,4,1]  R1310     -8.4712529182434082e-01
    z[2,4,1]  R1311     -9.3157833814620972e-01
    z[2,4,1]  R1312     -7.7176654338836670e-01
    z[2,4,1]  R1313     -6.6648370027542114e-01
    z[2,4,1]  R1314     -6.1783152818679810e-01
    z[2,4,1]  R1315     -2.4491614103317261e-01
    z[2,4,1]  R1316     -1.6888128221035004e-01
    z[2,4,1]  R1317     -1.6578610241413116e-01
    z[2,4,1]  R1318     2.6889970898628235e-01
    z[2,4,1]  R1319     2.4984259903430939e-01
    z[2,4,1]  R1320     3.6712694168090820e-01
    z[2,4,1]  R1321     -1.5047702193260193e-01
    z[2,4,1]  R1322     1.4627382159233093e-01
    z[2,4,1]  R1323     3.1788122653961182e-01
    z[2,4,1]  R1324     -0.197486013174057
    z[2,4,1]  R1325     -3.3985349535942078e-01
    z[2,4,1]  R1326     -7.9830235242843628e-01
    z[2,4,1]  R1327     -6.9575464725494385e-01
    z[2,4,1]  R1328     -5.6621932983398438e-01
    z[2,4,1]  R1329     -1.0993305593729019e-01
    z[2,4,1]  R1330     -4.2058369517326355e-01
    z[2,4,1]  R1331     -3.0809995532035828e-01
    z[2,4,1]  R1332     -3.2287931442260742e-01
    z[2,4,1]  R1333     9.9301591515541077e-02
    z[2,4,1]  R1334     -1.1832910031080246e-01
    z[2,4,1]  R1335     -8.4441047906875610e-01
    z[2,4,1]  R1336     -7.1961444616317749e-01
    z[2,4,1]  R1337     -7.5381666421890259e-01
    z[2,4,1]  R1338     -6.3448148965835571e-01
    z[2,4,1]  R1339     -7.9383903741836548e-01
    z[2,4,1]  R1340     -5.0873693078756332e-02
    z[2,4,1]  R1341     -1.2915693223476410e-01
    z[2,4,1]  R1342     -2.4370776116847992e-01
    z[2,4,1]  R1343     6.2591084279119968e-03
    z[2,4,1]  R1344     7.5826406478881836e-02
    z[2,4,1]  R1345     -7.9278451204299927e-01
    z[2,4,1]  R1346     -8.7493056058883667e-01
    z[2,4,1]  R1347     -6.6701400279998779e-01
    z[2,4,1]  R1348     -1.5493483841419220e-01
    z[2,4,1]  R1349     4.1146323084831238e-01
    z[2,4,1]  R1350     1.9942082464694977e-01
    z[2,4,1]  R1351     4.1929177939891815e-02
    z[2,4,1]  R1352     -3.8080174475908279e-02
    z[2,4,1]  R1353     0.551843523979187
    z[2,4,1]  R1354     7.5889408588409424e-01
    z[2,4,1]  R1355     7.5472515821456909e-01
    z[2,4,1]  R1356     8.6888861656188965e-01
    z[2,4,1]  R1357     0.603097140789032
    z[2,4,1]  R1358     5.7544064521789551e-01
    z[2,4,1]  R1359     0.612223744392395
    z[2,4,1]  R1360     6.5207844972610474e-01
    z[2,4,1]  R1361     6.4350157976150513e-01
    z[2,4,1]  R1362     -8.4987187385559082e-01
    z[2,4,1]  R1363     -8.2063728570938110e-01
    z[2,4,1]  R1364     7.5189995765686035e-01
    z[2,4,1]  R1365     4.3783202767372131e-01
    z[2,4,1]  R1366     -3.8606387376785278e-01
    z[2,4,1]  R1367     -2.4214853346347809e-01
    z[2,4,1]  R1368     -3.1058117747306824e-01
    z[2,4,1]  R1369     -2.2177360951900482e-01
    z[2,4,1]  R1370     -1.5315692871809006e-02
    z[2,4,1]  R1371     -3.2986709475517273e-01
    z[2,4,1]  R1372     2.3476628959178925e-01
    z[2,4,1]  R1373     1.9111397862434387e-01
    z[2,4,1]  R1374     7.2244065999984741e-01
    z[2,4,1]  R1375     5.5984967947006226e-01
    z[2,4,1]  R1376     4.1613170504570007e-01
    z[2,4,1]  R1377     4.0391734242439270e-01
    z[2,4,1]  R1378     4.3273970484733582e-01
    z[2,4,1]  R1379     3.8729482889175415e-01
    z[2,4,1]  R1380     -2.0500813424587250e-01
    z[2,4,1]  R1381     -6.2468174844980240e-02
    z[2,4,1]  R1382     -5.0921678543090820e-02
    z[2,4,1]  R1383     -3.5752475261688232e-01
    z[2,4,2]  R22       -1
    z[2,4,2]  R40       1
    z[2,4,2]  R1274     -1
    z[2,4,2]  R1275     1
    z[2,4,2]  R1284     5.6660646200180054e-01
    z[2,4,2]  R1285     1.5669887885451317e-02
    z[2,4,2]  R1286     -1.3559582829475403e-01
    z[2,4,2]  R1287     3.2131153345108032e-01
    z[2,4,2]  R1288     1.6175954043865204e-01
    z[2,4,2]  R1289     -2.2412294149398804e-01
    z[2,4,2]  R1290     -2.1871482953429222e-02
    z[2,4,2]  R1291     -1.3139431178569794e-01
    z[2,4,2]  R1292     3.3440402150154114e-01
    z[2,4,2]  R1293     2.8118276596069336e-01
    z[2,4,2]  R1294     2.7220770716667175e-01
    z[2,4,2]  R1295     3.5450032353401184e-01
    z[2,4,2]  R1296     1.0474268347024918e-02
    z[2,4,2]  R1297     9.4537794589996338e-02
    z[2,4,2]  R1298     2.2170089185237885e-01
    z[2,4,2]  R1299     -1.0814710706472397e-01
    z[2,4,2]  R1300     -2.5182211399078369e-01
    z[2,4,2]  R1301     3.7095537781715393e-01
    z[2,4,2]  R1302     4.8485729098320007e-01
    z[2,4,2]  R1303     0.391141802072525
    z[2,4,2]  R1304     -2.6335790753364563e-01
    z[2,4,2]  R1305     4.1815541684627533e-02
    z[2,4,2]  R1306     2.2154621779918671e-02
    z[2,4,2]  R1307     3.6627537012100220e-01
    z[2,4,2]  R1308     4.9212306737899780e-01
    z[2,4,2]  R1309     3.5707566142082214e-01
    z[2,4,2]  R1310     2.6747745275497437e-01
    z[2,4,2]  R1311     -1.8532557412981987e-02
    z[2,4,2]  R1312     1.9488810002803802e-01
    z[2,4,2]  R1313     1.8859108909964561e-02
    z[2,4,2]  R1314     -5.3550285100936890e-01
    z[2,4,2]  R1315     -2.4048466980457306e-01
    z[2,4,2]  R1316     0.082611583173275
    z[2,4,2]  R1317     -8.9654371142387390e-02
    z[2,4,2]  R1318     -2.1137490868568420e-01
    z[2,4,2]  R1319     -1.7876550555229187e-01
    z[2,4,2]  R1320     -2.6982340216636658e-01
    z[2,4,2]  R1321     -1.9752517342567444e-01
    z[2,4,2]  R1322     -1.1177732609212399e-02
    z[2,4,2]  R1323     -1.0844890773296356e-01
    z[2,4,2]  R1324     -5.7923197746276855e-01
    z[2,4,2]  R1325     -5.9258836507797241e-01
    z[2,4,2]  R1326     1.4884649217128754e-01
    z[2,4,2]  R1327     -4.0928909182548523e-01
    z[2,4,2]  R1328     -4.7487002611160278e-01
    z[2,4,2]  R1329     1.0943194478750229e-01
    z[2,4,2]  R1330     8.5958667099475861e-02
    z[2,4,2]  R1331     -0.606873631477356
    z[2,4,2]  R1332     1.0186557471752167e-01
    z[2,4,2]  R1333     0.625761091709137
    z[2,4,2]  R1334     -4.5682549476623535e-01
    z[2,4,2]  R1335     -8.2836419343948364e-02
    z[2,4,2]  R1336     -5.4207291454076767e-02
    z[2,4,2]  R1337     2.7874214574694633e-02
    z[2,4,2]  R1338     -4.2019593715667725e-01
    z[2,4,2]  R1339     -1.3303663581609726e-02
    z[2,4,2]  R1340     2.0317737758159637e-01
    z[2,4,2]  R1341     8.1217640638351440e-01
    z[2,4,2]  R1342     -3.9600688964128494e-02
    z[2,4,2]  R1343     -3.3364436030387878e-01
    z[2,4,2]  R1344     -7.4472390115261078e-02
    z[2,4,2]  R1345     -2.9672920703887939e-01
    z[2,4,2]  R1346     -4.3127492070198059e-01
    z[2,4,2]  R1347     1.4311423897743225e-01
    z[2,4,2]  R1348     -1.0728116333484650e-01
    z[2,4,2]  R1349     -2.1686401963233948e-01
    z[2,4,2]  R1350     3.9321917295455933e-01
    z[2,4,2]  R1351     4.4646185636520386e-01
    z[2,4,2]  R1352     -3.7101346254348755e-01
    z[2,4,2]  R1353     1.4247593283653259e-01
    z[2,4,2]  R1354     1.1177688837051392e-01
    z[2,4,2]  R1355     -4.3407250195741653e-02
    z[2,4,2]  R1356     3.0480053275823593e-02
    z[2,4,2]  R1357     3.0818262696266174e-01
    z[2,4,2]  R1358     4.3888410925865173e-01
    z[2,4,2]  R1359     -6.2086533755064011e-02
    z[2,4,2]  R1360     1.2212823331356049e-01
    z[2,4,2]  R1361     -7.3171287775039673e-02
    z[2,4,2]  R1362     3.2754510641098022e-01
    z[2,4,2]  R1363     -2.2392237558960915e-02
    z[2,4,2]  R1364     3.8310687988996506e-02
    z[2,4,2]  R1365     3.6883878707885742e-01
    z[2,4,2]  R1366     -1.6428200900554657e-01
    z[2,4,2]  R1367     -2.7812442183494568e-01
    z[2,4,2]  R1368     -2.9574507474899292e-01
    z[2,4,2]  R1369     -2.9847124218940735e-01
    z[2,4,2]  R1370     2.7253448963165283e-01
    z[2,4,2]  R1371     -2.4370205402374268e-01
    z[2,4,2]  R1372     -0.265984445810318
    z[2,4,2]  R1373     -6.4389117062091827e-02
    z[2,4,2]  R1374     -4.4989919662475586e-01
    z[2,4,2]  R1375     -7.8759752213954926e-02
    z[2,4,2]  R1376     -1.0610629618167877e-01
    z[2,4,2]  R1377     0.192478746175766
    z[2,4,2]  R1378     -1.1112035065889359e-01
    z[2,4,2]  R1379     5.6924498081207275e-01
    z[2,4,2]  R1380     3.7033399939537048e-01
    z[2,4,2]  R1381     8.6332149803638458e-03
    z[2,4,2]  R1382     1.4917572028934956e-02
    z[2,4,2]  R1383     -4.1301719844341278e-02
    z[2,4,3]  R23       -1
    z[2,4,3]  R41       1
    z[2,4,3]  R1276     -1
    z[2,4,3]  R1277     1
    z[2,4,3]  R1284     -4.9738347530364990e-01
    z[2,4,3]  R1285     -4.9407455325126648e-01
    z[2,4,3]  R1286     -3.8313293457031250e-01
    z[2,4,3]  R1287     -6.3725954294204712e-01
    z[2,4,3]  R1288     -3.1108251214027405e-01
    z[2,4,3]  R1289     -3.7824982404708862e-01
    z[2,4,3]  R1290     -3.9815476536750793e-01
    z[2,4,3]  R1291     -3.7539014220237732e-01
    z[2,4,3]  R1292     -6.8444848060607910e-01
    z[2,4,3]  R1293     -4.8272785544395447e-01
    z[2,4,3]  R1294     4.8311153054237366e-01
    z[2,4,3]  R1295     5.9779763221740723e-01
    z[2,4,3]  R1296     6.4269524812698364e-01
    z[2,4,3]  R1297     6.1657619476318359e-01
    z[2,4,3]  R1298     3.2699123024940491e-01
    z[2,4,3]  R1299     5.1298719644546509e-01
    z[2,4,3]  R1300     4.0008780360221863e-01
    z[2,4,3]  R1301     6.0585594177246094e-01
    z[2,4,3]  R1302     3.9594307541847229e-01
    z[2,4,3]  R1303     4.2353931069374084e-01
    z[2,4,3]  R1304     -4.3787723779678345e-01
    z[2,4,3]  R1305     5.4378788918256760e-02
    z[2,4,3]  R1306     4.1932079195976257e-01
    z[2,4,3]  R1307     -2.0981330424547195e-02
    z[2,4,3]  R1308     -1.5364332357421517e-03
    z[2,4,3]  R1309     1.3689659535884857e-01
    z[2,4,3]  R1310     -9.2429459095001221e-02
    z[2,4,3]  R1311     -3.2372960448265076e-01
    z[2,4,3]  R1312     -1.2386822700500488e-01
    z[2,4,3]  R1313     3.1529575586318970e-01
    z[2,4,3]  R1314     2.3897531628608704e-01
    z[2,4,3]  R1315     -3.3361229300498962e-01
    z[2,4,3]  R1316     -0.145788311958313
    z[2,4,3]  R1317     -1.4089332520961761e-01
    z[2,4,3]  R1318     2.6580068469047546e-01
    z[2,4,3]  R1319     2.7467063069343567e-01
    z[2,4,3]  R1320     3.5498273372650146e-01
    z[2,4,3]  R1321     -3.6747679114341736e-02
    z[2,4,3]  R1322     4.0764799714088440e-01
    z[2,4,3]  R1323     5.6897927075624466e-02
    z[2,4,3]  R1324     -4.8815658688545227e-01
    z[2,4,3]  R1325     -7.2577714920043945e-01
    z[2,4,3]  R1326     2.6660218834877014e-01
    z[2,4,3]  R1327     2.3126375675201416e-01
    z[2,4,3]  R1328     5.9364604949951172e-01
    z[2,4,3]  R1329     -1.8681989610195160e-01
    z[2,4,3]  R1330     -4.3784928321838379e-01
    z[2,4,3]  R1331     -1.2139679491519928e-01
    z[2,4,3]  R1332     -2.9585435986518860e-02
    z[2,4,3]  R1333     -3.0198785662651062e-01
    z[2,4,3]  R1334     -5.2362877130508423e-01
    z[2,4,3]  R1335     9.5383845269680023e-02
    z[2,4,3]  R1336     1.9987209141254425e-01
    z[2,4,3]  R1337     1.3164575397968292e-01
    z[2,4,3]  R1338     4.9316713213920593e-01
    z[2,4,3]  R1339     1.6954675316810608e-02
    z[2,4,3]  R1340     -2.6575639843940735e-01
    z[2,4,3]  R1341     -1.7028152942657471e-01
    z[2,4,3]  R1342     -5.0227010250091553e-01
    z[2,4,3]  R1343     -2.0487660169601440e-01
    z[2,4,3]  R1344     -5.2006644010543823e-01
    z[2,4,3]  R1345     0.206911101937294
    z[2,4,3]  R1346     8.8795311748981476e-02
    z[2,4,3]  R1347     3.2202258706092834e-01
    z[2,4,3]  R1348     -0.298666775226593
    z[2,4,3]  R1349     1.9712407886981964e-01
    z[2,4,3]  R1350     3.5539147257804871e-01
    z[2,4,3]  R1351     4.5797824859619141e-01
    z[2,4,3]  R1352     4.5064017176628113e-01
    z[2,4,3]  R1353     0.621365487575531
    z[2,4,3]  R1354     -4.1165980696678162e-01
    z[2,4,3]  R1355     -0.512349009513855
    z[2,4,3]  R1356     -2.7854391932487488e-01
    z[2,4,3]  R1357     5.7831909507513046e-02
    z[2,4,3]  R1358     2.8801107406616211e-01
    z[2,4,3]  R1359     3.1249490380287170e-01
    z[2,4,3]  R1360     1.3719774782657623e-01
    z[2,4,3]  R1361     4.3428402394056320e-02
    z[2,4,3]  R1362     -6.6395789384841919e-02
    z[2,4,3]  R1363     -3.9228478074073792e-01
    z[2,4,3]  R1364     3.4189349412918091e-01
    z[2,4,3]  R1365     4.8163211345672607e-01
    z[2,4,3]  R1366     8.0897784233093262e-01
    z[2,4,3]  R1367     8.2589679956436157e-01
    z[2,4,3]  R1368     5.5961722135543823e-01
    z[2,4,3]  R1369     3.9866998791694641e-01
    z[2,4,3]  R1370     -7.4746638536453247e-01
    z[2,4,3]  R1371     2.6748523116111755e-01
    z[2,4,3]  R1372     0.646652102470398
    z[2,4,3]  R1373     5.6053936481475830e-01
    z[2,4,3]  R1374     5.5258788168430328e-02
    z[2,4,3]  R1375     4.0571206808090210e-01
    z[2,4,3]  R1376     8.2479590177536011e-01
    z[2,4,3]  R1377     7.6130068302154541e-01
    z[2,4,3]  R1378     1.5137337148189545e-01
    z[2,4,3]  R1379     2.9105362296104431e-01
    z[2,4,3]  R1380     -6.1816269159317017e-01
    z[2,4,3]  R1381     -6.7544937133789062e-01
    z[2,4,3]  R1382     -6.6152596473693848e-01
    z[2,4,3]  R1383     4.3023351579904556e-02
    z[2,4,4]  R24       -1
    z[2,4,4]  R42       1
    z[2,4,4]  R1278     -1
    z[2,4,4]  R1279     1
    z[2,4,4]  R1284     7.4108898639678955e-02
    z[2,4,4]  R1285     4.5411086082458496e-01
    z[2,4,4]  R1286     -7.7939257025718689e-02
    z[2,4,4]  R1287     2.5241702795028687e-02
    z[2,4,4]  R1288     -3.1280061602592468e-01
    z[2,4,4]  R1289     -0.197514608502388
    z[2,4,4]  R1290     1.8651725351810455e-01
    z[2,4,4]  R1291     3.4524840116500854e-01
    z[2,4,4]  R1292     -2.2133202850818634e-01
    z[2,4,4]  R1293     -9.4200141727924347e-02
    z[2,4,4]  R1294     2.0341378450393677e-01
    z[2,4,4]  R1295     8.9632213115692139e-02
    z[2,4,4]  R1296     2.4004580453038216e-02
    z[2,4,4]  R1297     2.9950913786888123e-01
    z[2,4,4]  R1298     2.2722056508064270e-01
    z[2,4,4]  R1299     -2.3124359548091888e-01
    z[2,4,4]  R1300     4.8136554658412933e-02
    z[2,4,4]  R1301     5.7331800460815430e-02
    z[2,4,4]  R1302     -2.1913222968578339e-01
    z[2,4,4]  R1303     5.3543031215667725e-01
    z[2,4,4]  R1304     -2.0215612649917603e-01
    z[2,4,4]  R1305     3.6794430017471313e-01
    z[2,4,4]  R1306     -2.8205132484436035e-01
    z[2,4,4]  R1307     -8.9348025619983673e-02
    z[2,4,4]  R1308     2.6865644380450249e-02
    z[2,4,4]  R1309     -1.1009267531335354e-02
    z[2,4,4]  R1310     3.2222609966993332e-02
    z[2,4,4]  R1311     -8.0519765615463257e-02
    z[2,4,4]  R1312     3.7069308757781982e-01
    z[2,4,4]  R1313     1.7405509948730469e-01
    z[2,4,4]  R1314     3.0431419610977173e-01
    z[2,4,4]  R1315     -8.5079200565814972e-02
    z[2,4,4]  R1316     7.2199290990829468e-01
    z[2,4,4]  R1317     3.3194559812545776e-01
    z[2,4,4]  R1318     1.6605427861213684e-01
    z[2,4,4]  R1319     1.8416607752442360e-02
    z[2,4,4]  R1320     -2.2175459563732147e-01
    z[2,4,4]  R1321     4.2684939503669739e-01
    z[2,4,4]  R1322     -2.6789689064025879e-01
    z[2,4,4]  R1323     3.8038060069084167e-01
    z[2,4,4]  R1324     -3.3481433987617493e-01
    z[2,4,4]  R1325     -2.6730507612228394e-02
    z[2,4,4]  R1326     -7.6060421764850616e-02
    z[2,4,4]  R1327     4.3052637577056885e-01
    z[2,4,4]  R1328     3.3167313784360886e-02
    z[2,4,4]  R1329     3.9344325661659241e-01
    z[2,4,4]  R1330     1.6735710203647614e-01
    z[2,4,4]  R1331     1.4674863219261169e-01
    z[2,4,4]  R1332     1.9643607735633850e-01
    z[2,4,4]  R1333     2.4451376497745514e-01
    z[2,4,4]  R1334     -2.8217095136642456e-01
    z[2,4,4]  R1335     4.3291813135147095e-01
    z[2,4,4]  R1336     6.5028005838394165e-01
    z[2,4,4]  R1337     -6.1785720288753510e-02
    z[2,4,4]  R1338     2.3512113094329834e-01
    z[2,4,4]  R1339     -6.0237981379032135e-02
    z[2,4,4]  R1340     8.2637047767639160e-01
    z[2,4,4]  R1341     6.9821491837501526e-02
    z[2,4,4]  R1342     7.6107615232467651e-01
    z[2,4,4]  R1343     6.2636291980743408e-01
    z[2,4,4]  R1344     6.4324772357940674e-01
    z[2,4,4]  R1345     3.2327157258987427e-01
    z[2,4,4]  R1346     1.6144491732120514e-01
    z[2,4,4]  R1347     5.3124237060546875e-01
    z[2,4,4]  R1348     7.2016930580139160e-01
    z[2,4,4]  R1349     -1.0330962389707565e-01
    z[2,4,4]  R1350     1.6766072809696198e-01
    z[2,4,4]  R1351     5.5407159030437469e-02
    z[2,4,4]  R1352     -4.9126887321472168e-01
    z[2,4,4]  R1353     4.8064431548118591e-01
    z[2,4,4]  R1354     1.5016369521617889e-01
    z[2,4,4]  R1355     -2.0167241990566254e-01
    z[2,4,4]  R1356     -1.8209861218929291e-01
    z[2,4,4]  R1357     2.4066562950611115e-01
    z[2,4,4]  R1358     3.5273811221122742e-01
    z[2,4,4]  R1359     5.6484955549240112e-01
    z[2,4,4]  R1360     3.1264483928680420e-01
    z[2,4,4]  R1361     2.9566618800163269e-01
    z[2,4,4]  R1362     -2.4209970608353615e-02
    z[2,4,4]  R1363     -2.0483043789863586e-01
    z[2,4,4]  R1364     1.2161655724048615e-01
    z[2,4,4]  R1365     -0.506409227848053
    z[2,4,4]  R1366     -9.3269376084208488e-03
    z[2,4,4]  R1367     1.2939088977873325e-02
    z[2,4,4]  R1368     1.3160282373428345e-01
    z[2,4,4]  R1369     -3.7997606396675110e-01
    z[2,4,4]  R1370     1.3030199706554413e-01
    z[2,4,4]  R1371     3.5595762729644775e-01
    z[2,4,4]  R1372     -5.6280148029327393e-01
    z[2,4,4]  R1373     -6.5569287538528442e-01
    z[2,4,4]  R1374     1.7943548038601875e-02
    z[2,4,4]  R1375     -4.4281604886054993e-01
    z[2,4,4]  R1376     -9.5948047935962677e-02
    z[2,4,4]  R1377     -4.3679103255271912e-01
    z[2,4,4]  R1378     -8.6402416229248047e-01
    z[2,4,4]  R1379     -5.1386451721191406e-01
    z[2,4,4]  R1380     2.8345569968223572e-01
    z[2,4,4]  R1381     -4.8353210091590881e-01
    z[2,4,4]  R1382     6.9809418916702271e-01
    z[2,4,4]  R1383     0.84651118516922
    z[2,4,5]  R25       -1
    z[2,4,5]  R43       1
    z[2,4,5]  R1280     -1
    z[2,4,5]  R1281     1
    z[2,4,5]  R1284     -2.5763321667909622e-02
    z[2,4,5]  R1285     1.1319072544574738e-01
    z[2,4,5]  R1286     -3.2504707574844360e-01
    z[2,4,5]  R1287     -5.9077125787734985e-01
    z[2,4,5]  R1288     -8.5536353290081024e-02
    z[2,4,5]  R1289     3.8181871175765991e-02
    z[2,4,5]  R1290     -1.5665654838085175e-01
    z[2,4,5]  R1291     -3.6032482981681824e-01
    z[2,4,5]  R1292     4.5826286077499390e-01
    z[2,4,5]  R1293     2.3778598010540009e-01
    z[2,4,5]  R1294     2.3975865915417671e-02
    z[2,4,5]  R1295     -1.9673697650432587e-01
    z[2,4,5]  R1296     -3.9418466389179230e-02
    z[2,4,5]  R1297     -1.0547454655170441e-01
    z[2,4,5]  R1298     -4.1495278477668762e-01
    z[2,4,5]  R1299     1.3072626292705536e-01
    z[2,4,5]  R1300     -2.0526649057865143e-01
    z[2,4,5]  R1301     -2.4558408558368683e-01
    z[2,4,5]  R1302     -1.0090753436088562e-01
    z[2,4,5]  R1303     -1.0786123573780060e-01
    z[2,4,5]  R1304     -2.7562916278839111e-01
    z[2,4,5]  R1305     0.073304183781147
    z[2,4,5]  R1306     0.0922246053814888
    z[2,4,5]  R1307     4.6109721064567566e-01
    z[2,4,5]  R1308     1.2221264094114304e-01
    z[2,4,5]  R1309     3.6499887704849243e-01
    z[2,4,5]  R1310     -3.2317012548446655e-01
    z[2,4,5]  R1311     7.0836436934769154e-03
    z[2,4,5]  R1312     1.2804001569747925e-01
    z[2,4,5]  R1313     5.4895699024200439e-01
    z[2,4,5]  R1314     2.7236780524253845e-01
    z[2,4,5]  R1315     -1.2452408671379089e-01
    z[2,4,5]  R1316     -6.5301053225994110e-02
    z[2,4,5]  R1317     4.3510493636131287e-01
    z[2,4,5]  R1318     -5.7376161217689514e-02
    z[2,4,5]  R1319     -1.8761390447616577e-01
    z[2,4,5]  R1320     -5.1306881010532379e-02
    z[2,4,5]  R1321     -3.3381082117557526e-02
    z[2,4,5]  R1322     -1.3989751040935516e-01
    z[2,4,5]  R1323     7.0005212910473347e-03
    z[2,4,5]  R1324     -3.5425817966461182e-01
    z[2,4,5]  R1325     2.6494054123759270e-02
    z[2,4,5]  R1326     4.0824812650680542e-01
    z[2,4,5]  R1327     1.4948236942291260e-01
    z[2,4,5]  R1328     -3.0073684453964233e-01
    z[2,4,5]  R1329     -1.9144824147224426e-01
    z[2,4,5]  R1330     2.0868784189224243e-01
    z[2,4,5]  R1331     -1.5906600281596184e-02
    z[2,4,5]  R1332     -2.2126603126525879e-01
    z[2,4,5]  R1333     4.2481872439384460e-01
    z[2,4,5]  R1334     -2.1682459115982056e-01
    z[2,4,5]  R1335     -2.3186743259429932e-01
    z[2,4,5]  R1336     1.1061707139015198e-01
    z[2,4,5]  R1337     1.7542797327041626e-01
    z[2,4,5]  R1338     -3.1311661005020142e-01
    z[2,4,5]  R1339     -2.8522959351539612e-01
    z[2,4,5]  R1340     3.5395030863583088e-03
    z[2,4,5]  R1341     2.9308724403381348e-01
    z[2,4,5]  R1342     1.7048075795173645e-02
    z[2,4,5]  R1343     -3.4903664141893387e-02
    z[2,4,5]  R1344     1.9971325993537903e-01
    z[2,4,5]  R1345     0.141094371676445
    z[2,4,5]  R1346     2.4412022903561592e-02
    z[2,4,5]  R1347     3.5019564628601074e-01
    z[2,4,5]  R1348     2.1683631464838982e-02
    z[2,4,5]  R1349     1.0498115420341492e-01
    z[2,4,5]  R1350     6.6231940872967243e-03
    z[2,4,5]  R1351     -2.3655049502849579e-01
    z[2,4,5]  R1352     -0.504997730255127
    z[2,4,5]  R1353     -2.6477809995412827e-02
    z[2,4,5]  R1354     4.9972828477621078e-02
    z[2,4,5]  R1355     -3.2711166143417358e-01
    z[2,4,5]  R1356     1.0573945939540863e-01
    z[2,4,5]  R1357     0.384998619556427
    z[2,4,5]  R1358     -2.5444485247135162e-02
    z[2,4,5]  R1359     -3.2719689607620239e-01
    z[2,4,5]  R1360     6.6548407077789307e-01
    z[2,4,5]  R1361     3.5918089747428894e-01
    z[2,4,5]  R1362     -8.1948794424533844e-02
    z[2,4,5]  R1363     1.1423498392105103e-02
    z[2,4,5]  R1364     1.6303362324833870e-02
    z[2,4,5]  R1365     0.0700659304857254
    z[2,4,5]  R1366     3.2645413279533386e-01
    z[2,4,5]  R1367     2.0752148702740669e-03
    z[2,4,5]  R1368     -5.4658412933349609e-01
    z[2,4,5]  R1369     2.6304228231310844e-02
    z[2,4,5]  R1370     4.7758507728576660e-01
    z[2,4,5]  R1371     3.8313046097755432e-01
    z[2,4,5]  R1372     -2.2911007702350616e-01
    z[2,4,5]  R1373     -3.0044120550155640e-01
    z[2,4,5]  R1374     5.3282942622900009e-02
    z[2,4,5]  R1375     0.546783983707428
    z[2,4,5]  R1376     3.4522768855094910e-01
    z[2,4,5]  R1377     -1.6942660510540009e-01
    z[2,4,5]  R1378     -1.2802666425704956e-01
    z[2,4,5]  R1379     -3.9604511857032776e-01
    z[2,4,5]  R1380     1.8112035095691681e-01
    z[2,4,5]  R1381     1.8203233182430267e-01
    z[2,4,5]  R1382     -1.9573500752449036e-01
    z[2,4,5]  R1383     1.5885604918003082e-01
    z[2,4,6]  R26       -1
    z[2,4,6]  R44       1
    z[2,4,6]  R1282     -1
    z[2,4,6]  R1283     1
    z[2,4,6]  R1284     -5.2041497081518173e-02
    z[2,4,6]  R1285     2.6563179492950439e-01
    z[2,4,6]  R1286     1.2247455865144730e-01
    z[2,4,6]  R1287     -2.9744941741228104e-02
    z[2,4,6]  R1288     -1.7013169825077057e-01
    z[2,4,6]  R1289     -3.5226354002952576e-01
    z[2,4,6]  R1290     -3.1037840247154236e-01
    z[2,4,6]  R1291     -2.2379522025585175e-01
    z[2,4,6]  R1292     4.9815565347671509e-02
    z[2,4,6]  R1293     6.5397346019744873e-01
    z[2,4,6]  R1294     1.7376956343650818e-01
    z[2,4,6]  R1295     3.9379266090691090e-03
    z[2,4,6]  R1296     8.5842885076999664e-02
    z[2,4,6]  R1297     5.0171691924333572e-02
    z[2,4,6]  R1298     -2.0933536812663078e-02
    z[2,4,6]  R1299     -5.0253149121999741e-02
    z[2,4,6]  R1300     2.9349419474601746e-01
    z[2,4,6]  R1301     2.8682306408882141e-01
    z[2,4,6]  R1302     -1.9491675496101379e-01
    z[2,4,6]  R1303     -3.3388055860996246e-02
    z[2,4,6]  R1304     -1.3035708665847778e-01
    z[2,4,6]  R1305     -3.4366950392723083e-01
    z[2,4,6]  R1306     9.2071019113063812e-02
    z[2,4,6]  R1307     -1.1393783241510391e-01
    z[2,4,6]  R1308     8.2571931183338165e-02
    z[2,4,6]  R1309     -3.6306026577949524e-01
    z[2,4,6]  R1310     8.3058521151542664e-02
    z[2,4,6]  R1311     1.4299200847744942e-02
    z[2,4,6]  R1312     4.2816221714019775e-01
    z[2,4,6]  R1313     3.4252646565437317e-01
    z[2,4,6]  R1314     -1.8468311429023743e-01
    z[2,4,6]  R1315     -4.3246969580650330e-01
    z[2,4,6]  R1316     6.2741570174694061e-02
    z[2,4,6]  R1317     -5.8201032876968384e-01
    z[2,4,6]  R1318     1.0211148113012314e-01
    z[2,4,6]  R1319     -2.6464468240737915e-01
    z[2,4,6]  R1320     5.3623810410499573e-02
    z[2,4,6]  R1321     4.9583610892295837e-01
    z[2,4,6]  R1322     1.6540125012397766e-01
    z[2,4,6]  R1323     -2.4010688066482544e-01
    z[2,4,6]  R1324     3.7758362293243408e-01
    z[2,4,6]  R1325     -3.3995591104030609e-02
    z[2,4,6]  R1326     2.4440832436084747e-01
    z[2,4,6]  R1327     2.2488673031330109e-01
    z[2,4,6]  R1328     1.7554501071572304e-02
    z[2,4,6]  R1329     -5.4029554128646851e-01
    z[2,4,6]  R1330     -2.1544055640697479e-01
    z[2,4,6]  R1331     -4.4490674138069153e-01
    z[2,4,6]  R1332     5.8592408895492554e-01
    z[2,4,6]  R1333     -4.2189598083496094e-02
    z[2,4,6]  R1334     0.26277956366539
    z[2,4,6]  R1335     -1.5819574892520905e-01
    z[2,4,6]  R1336     6.4440146088600159e-02
    z[2,4,6]  R1337     -0.503376841545105
    z[2,4,6]  R1338     9.5405891537666321e-02
    z[2,4,6]  R1339     5.3170013427734375e-01
    z[2,4,6]  R1340     -3.4733593463897705e-01
    z[2,4,6]  R1341     1.4525157213211060e-01
    z[2,4,6]  R1342     -1.4669755101203918e-01
    z[2,4,6]  R1343     -3.0108600854873657e-01
    z[2,4,6]  R1344     -2.6337680220603943e-01
    z[2,4,6]  R1345     -1.4485427737236023e-01
    z[2,4,6]  R1346     4.2245812714099884e-02
    z[2,4,6]  R1347     8.5663706064224243e-02
    z[2,4,6]  R1348     -1.1631070822477341e-01
    z[2,4,6]  R1349     1.2773084640502930e-01
    z[2,4,6]  R1350     1.3055829703807831e-01
    z[2,4,6]  R1351     -1.3799254596233368e-01
    z[2,4,6]  R1352     -3.9727625250816345e-01
    z[2,4,6]  R1353     -1.6255301237106323e-01
    z[2,4,6]  R1354     1.6514627635478973e-01
    z[2,4,6]  R1355     6.5292038023471832e-02
    z[2,4,6]  R1356     -1.0161355137825012e-01
    z[2,4,6]  R1357     -2.9342442750930786e-01
    z[2,4,6]  R1358     1.9883975386619568e-01
    z[2,4,6]  R1359     1.8315419554710388e-01
    z[2,4,6]  R1360     -1.8604686483740807e-02
    z[2,4,6]  R1361     5.9675145149230957e-01
    z[2,4,6]  R1362     -3.7798005342483521e-01
    z[2,4,6]  R1363     3.4525832533836365e-01
    z[2,4,6]  R1364     -4.4347429275512695e-01
    z[2,4,6]  R1365     1.9795902073383331e-01
    z[2,4,6]  R1366     2.3786519467830658e-01
    z[2,4,6]  R1367     2.4091006815433502e-01
    z[2,4,6]  R1368     3.1069728732109070e-01
    z[2,4,6]  R1369     1.4187897741794586e-01
    z[2,4,6]  R1370     -3.1719669699668884e-01
    z[2,4,6]  R1371     2.6061311364173889e-01
    z[2,4,6]  R1372     2.4852724373340607e-01
    z[2,4,6]  R1373     7.5940592214465141e-03
    z[2,4,6]  R1374     4.6995532512664795e-01
    z[2,4,6]  R1375     -1.1474460363388062e-01
    z[2,4,6]  R1376     -1.5504789538681507e-02
    z[2,4,6]  R1377     1.5785694122314453e-02
    z[2,4,6]  R1378     -9.7251825034618378e-02
    z[2,4,6]  R1379     5.5259648710489273e-02
    z[2,4,6]  R1380     -1.8019108474254608e-01
    z[2,4,6]  R1381     -1.2802480161190033e-01
    z[2,4,6]  R1382     9.7086921334266663e-02
    z[2,4,6]  R1383     0.328484445810318
    z[4,2,0]  R20       1
    z[4,2,0]  R38       -1
    z[4,2,0]  R1384     -1
    z[4,2,0]  R1385     1
    z[4,2,0]  R1398     -4.3566304445266724e-01
    z[4,2,0]  R1399     1.1860569566488266e-01
    z[4,2,0]  R1400     -3.3444091677665710e-01
    z[4,2,0]  R1401     -4.9569246172904968e-01
    z[4,2,0]  R1402     -4.7821506857872009e-01
    z[4,2,0]  R1403     -2.5301378965377808e-01
    z[4,2,0]  R1404     0.00965464673936367
    z[4,2,0]  R1405     -7.8255213797092438e-02
    z[4,2,0]  R1406     1.2590855360031128e-01
    z[4,2,0]  R1407     -1.0428953170776367e-01
    z[4,2,0]  R1408     0.323359876871109
    z[4,2,0]  R1409     3.7382391095161438e-01
    z[4,2,0]  R1410     7.9257696866989136e-02
    z[4,2,0]  R1411     3.5170421004295349e-01
    z[4,2,0]  R1412     3.0049356818199158e-01
    z[4,2,0]  R1413     7.3320543766021729e-01
    z[4,2,0]  R1414     1.4527393877506256e-01
    z[4,2,0]  R1415     6.4717435836791992e-01
    z[4,2,0]  R1416     -1.5803582966327667e-01
    z[4,2,0]  R1417     -3.5336855053901672e-01
    z[4,2,0]  R1418     2.2044897079467773e-01
    z[4,2,0]  R1419     0.0868205651640892
    z[4,2,0]  R1420     -8.1602618098258972e-02
    z[4,2,0]  R1421     2.1975185722112656e-02
    z[4,2,0]  R1422     7.1332126855850220e-02
    z[4,2,0]  R1423     1.3148538768291473e-01
    z[4,2,0]  R1424     -5.4136735200881958e-01
    z[4,2,0]  R1425     5.0642073154449463e-01
    z[4,2,0]  R1426     1.5650652348995209e-01
    z[4,2,0]  R1427     -1.3747981190681458e-01
    z[4,2,0]  R1428     3.7873715162277222e-01
    z[4,2,0]  R1429     5.3333443403244019e-01
    z[4,2,0]  R1430     6.8667048215866089e-01
    z[4,2,0]  R1431     -1.4450901746749878e-01
    z[4,2,0]  R1432     6.8553018569946289e-01
    z[4,2,0]  R1433     6.5093624591827393e-01
    z[4,2,0]  R1434     7.6829367876052856e-01
    z[4,2,0]  R1435     5.8579719066619873e-01
    z[4,2,0]  R1436     -0.367805153131485
    z[4,2,0]  R1437     1.2440484762191772e-01
    z[4,2,0]  R1438     7.8678119182586670e-01
    z[4,2,0]  R1439     6.4782553911209106e-01
    z[4,2,0]  R1440     7.5260007381439209e-01
    z[4,2,0]  R1441     6.2868463993072510e-01
    z[4,2,0]  R1442     6.5628039836883545e-01
    z[4,2,0]  R1443     7.3745173215866089e-01
    z[4,2,0]  R1444     7.6738870143890381e-01
    z[4,2,0]  R1445     5.6793701648712158e-01
    z[4,2,0]  R1446     7.0700442790985107e-01
    z[4,2,0]  R1447     5.2821296453475952e-01
    z[4,2,0]  R1448     -5.5435019731521606e-01
    z[4,2,0]  R1449     -1.3739745318889618e-01
    z[4,2,0]  R1450     -2.4997992813587189e-01
    z[4,2,0]  R1451     -9.3141689896583557e-02
    z[4,2,0]  R1452     -3.6504247784614563e-01
    z[4,2,0]  R1453     -1.8392980098724365e-01
    z[4,2,0]  R1454     -2.9985910654067993e-01
    z[4,2,0]  R1455     -1.4240592718124390e-01
    z[4,2,0]  R1456     -1.1798799037933350e-01
    z[4,2,0]  R1457     -8.4018073976039886e-02
    z[4,2,0]  R1458     2.7113190293312073e-01
    z[4,2,0]  R1459     7.4907368421554565e-01
    z[4,2,0]  R1460     -6.4337062835693359e-01
    z[4,2,0]  R1461     5.5352133512496948e-01
    z[4,2,0]  R1462     -8.7810635566711426e-01
    z[4,2,0]  R1463     -8.5123598575592041e-01
    z[4,2,0]  R1464     -7.8212362527847290e-01
    z[4,2,0]  R1465     -7.1261632442474365e-01
    z[4,2,0]  R1466     -8.3282917737960815e-01
    z[4,2,0]  R1467     -8.2556849718093872e-01
    z[4,2,0]  R1468     -8.3808355033397675e-02
    z[4,2,0]  R1469     -6.3356541097164154e-02
    z[4,2,0]  R1470     1.9311730563640594e-01
    z[4,2,0]  R1471     1.9144977629184723e-01
    z[4,2,0]  R1472     -9.8120421171188354e-02
    z[4,2,0]  R1473     -6.7651188373565674e-01
    z[4,2,0]  R1474     7.1136116981506348e-01
    z[4,2,0]  R1475     5.4982852935791016e-01
    z[4,2,0]  R1476     -0.673531174659729
    z[4,2,0]  R1477     5.1509976387023926e-01
    z[4,2,0]  R1478     -5.5446839332580566e-01
    z[4,2,0]  R1479     -6.9315418601036072e-02
    z[4,2,0]  R1480     3.8593227509409189e-03
    z[4,2,0]  R1481     3.5450258851051331e-01
    z[4,2,0]  R1482     -1.2340407073497772e-01
    z[4,2,0]  R1483     -4.0811732411384583e-02
    z[4,2,0]  R1484     -2.8628918528556824e-01
    z[4,2,0]  R1485     4.2757335305213928e-01
    z[4,2,0]  R1486     -2.9277181625366211e-01
    z[4,2,0]  R1487     6.0205173492431641e-01
    z[4,2,0]  R1488     -4.4183117151260376e-01
    z[4,2,0]  R1489     3.0860555171966553e-01
    z[4,2,0]  R1490     -1.1031243205070496e-01
    z[4,2,0]  R1491     -1.3681454956531525e-01
    z[4,2,0]  R1492     5.8535623550415039e-01
    z[4,2,0]  R1493     -8.4071463346481323e-01
    z[4,2,0]  R1494     -7.9630863666534424e-01
    z[4,2,0]  R1495     -7.1491372585296631e-01
    z[4,2,0]  R1496     6.0217022895812988e-02
    z[4,2,0]  R1497     -1.7587128281593323e-01
    z[4,2,1]  R21       1
    z[4,2,1]  R39       -1
    z[4,2,1]  R1386     -1
    z[4,2,1]  R1387     1
    z[4,2,1]  R1398     7.5889408588409424e-01
    z[4,2,1]  R1399     7.5472515821456909e-01
    z[4,2,1]  R1400     8.6888861656188965e-01
    z[4,2,1]  R1401     0.603097140789032
    z[4,2,1]  R1402     5.7544064521789551e-01
    z[4,2,1]  R1403     0.612223744392395
    z[4,2,1]  R1404     6.5207844972610474e-01
    z[4,2,1]  R1405     6.4350157976150513e-01
    z[4,2,1]  R1406     -8.4987187385559082e-01
    z[4,2,1]  R1407     -8.2063728570938110e-01
    z[4,2,1]  R1408     7.5189995765686035e-01
    z[4,2,1]  R1409     4.3783202767372131e-01
    z[4,2,1]  R1410     -3.8606387376785278e-01
    z[4,2,1]  R1411     -2.4214853346347809e-01
    z[4,2,1]  R1412     -3.1058117747306824e-01
    z[4,2,1]  R1413     -2.2177360951900482e-01
    z[4,2,1]  R1414     -1.5315692871809006e-02
    z[4,2,1]  R1415     -3.2986709475517273e-01
    z[4,2,1]  R1416     2.3476628959178925e-01
    z[4,2,1]  R1417     1.9111397862434387e-01
    z[4,2,1]  R1418     7.2244065999984741e-01
    z[4,2,1]  R1419     5.5984967947006226e-01
    z[4,2,1]  R1420     4.1613170504570007e-01
    z[4,2,1]  R1421     4.0391734242439270e-01
    z[4,2,1]  R1422     4.3273970484733582e-01
    z[4,2,1]  R1423     3.8729482889175415e-01
    z[4,2,1]  R1424     -2.0500813424587250e-01
    z[4,2,1]  R1425     -6.2468174844980240e-02
    z[4,2,1]  R1426     -5.0921678543090820e-02
    z[4,2,1]  R1427     -3.5752475261688232e-01
    z[4,2,1]  R1428     5.2845132350921631e-01
    z[4,2,1]  R1429     4.2615747451782227e-01
    z[4,2,1]  R1430     4.8639130592346191e-01
    z[4,2,1]  R1431     3.4531673789024353e-01
    z[4,2,1]  R1432     5.2249819040298462e-01
    z[4,2,1]  R1433     4.6735259890556335e-01
    z[4,2,1]  R1434     3.0830904841423035e-01
    z[4,2,1]  R1435     4.4670420885086060e-01
    z[4,2,1]  R1436     1.5149046480655670e-01
    z[4,2,1]  R1437     4.2348146438598633e-01
    z[4,2,1]  R1438     -3.6520402878522873e-02
    z[4,2,1]  R1439     -0.224799245595932
    z[4,2,1]  R1440     -1.0453260689973831e-01
    z[4,2,1]  R1441     -3.3511823415756226e-01
    z[4,2,1]  R1442     -4.3470478057861328e-01
    z[4,2,1]  R1443     -3.2897549867630005e-01
    z[4,2,1]  R1444     -2.3882986605167389e-01
    z[4,2,1]  R1445     -1.6404964029788971e-01
    z[4,2,1]  R1446     -1.0996983945369720e-01
    z[4,2,1]  R1447     -2.9862865805625916e-01
    z[4,2,1]  R1448     -5.4568356275558472e-01
    z[4,2,1]  R1449     -8.4708386659622192e-01
    z[4,2,1]  R1450     -8.1526309251785278e-01
    z[4,2,1]  R1451     -0.789399266242981
    z[4,2,1]  R1452     -7.7593863010406494e-01
    z[4,2,1]  R1453     -7.4482750892639160e-01
    z[4,2,1]  R1454     -8.4712529182434082e-01
    z[4,2,1]  R1455     -9.3157833814620972e-01
    z[4,2,1]  R1456     -7.7176654338836670e-01
    z[4,2,1]  R1457     -6.6648370027542114e-01
    z[4,2,1]  R1458     -6.1783152818679810e-01
    z[4,2,1]  R1459     -2.4491614103317261e-01
    z[4,2,1]  R1460     -1.6888128221035004e-01
    z[4,2,1]  R1461     -1.6578610241413116e-01
    z[4,2,1]  R1462     2.6889970898628235e-01
    z[4,2,1]  R1463     2.4984259903430939e-01
    z[4,2,1]  R1464     3.6712694168090820e-01
    z[4,2,1]  R1465     -1.5047702193260193e-01
    z[4,2,1]  R1466     1.4627382159233093e-01
    z[4,2,1]  R1467     3.1788122653961182e-01
    z[4,2,1]  R1468     -0.197486013174057
    z[4,2,1]  R1469     -3.3985349535942078e-01
    z[4,2,1]  R1470     -7.9830235242843628e-01
    z[4,2,1]  R1471     -6.9575464725494385e-01
    z[4,2,1]  R1472     -5.6621932983398438e-01
    z[4,2,1]  R1473     -1.0993305593729019e-01
    z[4,2,1]  R1474     -4.2058369517326355e-01
    z[4,2,1]  R1475     -3.0809995532035828e-01
    z[4,2,1]  R1476     -3.2287931442260742e-01
    z[4,2,1]  R1477     9.9301591515541077e-02
    z[4,2,1]  R1478     -1.1832910031080246e-01
    z[4,2,1]  R1479     -8.4441047906875610e-01
    z[4,2,1]  R1480     -7.1961444616317749e-01
    z[4,2,1]  R1481     -7.5381666421890259e-01
    z[4,2,1]  R1482     -6.3448148965835571e-01
    z[4,2,1]  R1483     -7.9383903741836548e-01
    z[4,2,1]  R1484     -5.0873693078756332e-02
    z[4,2,1]  R1485     -1.2915693223476410e-01
    z[4,2,1]  R1486     -2.4370776116847992e-01
    z[4,2,1]  R1487     6.2591084279119968e-03
    z[4,2,1]  R1488     7.5826406478881836e-02
    z[4,2,1]  R1489     -7.9278451204299927e-01
    z[4,2,1]  R1490     -8.7493056058883667e-01
    z[4,2,1]  R1491     -6.6701400279998779e-01
    z[4,2,1]  R1492     -1.5493483841419220e-01
    z[4,2,1]  R1493     4.1146323084831238e-01
    z[4,2,1]  R1494     1.9942082464694977e-01
    z[4,2,1]  R1495     4.1929177939891815e-02
    z[4,2,1]  R1496     -3.8080174475908279e-02
    z[4,2,1]  R1497     0.551843523979187
    z[4,2,2]  R22       1
    z[4,2,2]  R40       -1
    z[4,2,2]  R1388     -1
    z[4,2,2]  R1389     1
    z[4,2,2]  R1398     1.1177688837051392e-01
    z[4,2,2]  R1399     -4.3407250195741653e-02
    z[4,2,2]  R1400     3.0480053275823593e-02
    z[4,2,2]  R1401     3.0818262696266174e-01
    z[4,2,2]  R1402     4.3888410925865173e-01
    z[4,2,2]  R1403     -6.2086533755064011e-02
    z[4,2,2]  R1404     1.2212823331356049e-01
    z[4,2,2]  R1405     -7.3171287775039673e-02
    z[4,2,2]  R1406     3.2754510641098022e-01
    z[4,2,2]  R1407     -2.2392237558960915e-02
    z[4,2,2]  R1408     3.8310687988996506e-02
    z[4,2,2]  R1409     3.6883878707885742e-01
    z[4,2,2]  R1410     -1.6428200900554657e-01
    z[4,2,2]  R1411     -2.7812442183494568e-01
    z[4,2,2]  R1412     -2.9574507474899292e-01
    z[4,2,2]  R1413     -2.9847124218940735e-01
    z[4,2,2]  R1414     2.7253448963165283e-01
    z[4,2,2]  R1415     -2.4370205402374268e-01
    z[4,2,2]  R1416     -0.265984445810318
    z[4,2,2]  R1417     -6.4389117062091827e-02
    z[4,2,2]  R1418     -4.4989919662475586e-01
    z[4,2,2]  R1419     -7.8759752213954926e-02
    z[4,2,2]  R1420     -1.0610629618167877e-01
    z[4,2,2]  R1421     0.192478746175766
    z[4,2,2]  R1422     -1.1112035065889359e-01
    z[4,2,2]  R1423     5.6924498081207275e-01
    z[4,2,2]  R1424     3.7033399939537048e-01
    z[4,2,2]  R1425     8.6332149803638458e-03
    z[4,2,2]  R1426     1.4917572028934956e-02
    z[4,2,2]  R1427     -4.1301719844341278e-02
    z[4,2,2]  R1428     5.6660646200180054e-01
    z[4,2,2]  R1429     1.5669887885451317e-02
    z[4,2,2]  R1430     -1.3559582829475403e-01
    z[4,2,2]  R1431     3.2131153345108032e-01
    z[4,2,2]  R1432     1.6175954043865204e-01
    z[4,2,2]  R1433     -2.2412294149398804e-01
    z[4,2,2]  R1434     -2.1871482953429222e-02
    z[4,2,2]  R1435     -1.3139431178569794e-01
    z[4,2,2]  R1436     3.3440402150154114e-01
    z[4,2,2]  R1437     2.8118276596069336e-01
    z[4,2,2]  R1438     2.7220770716667175e-01
    z[4,2,2]  R1439     3.5450032353401184e-01
    z[4,2,2]  R1440     1.0474268347024918e-02
    z[4,2,2]  R1441     9.4537794589996338e-02
    z[4,2,2]  R1442     2.2170089185237885e-01
    z[4,2,2]  R1443     -1.0814710706472397e-01
    z[4,2,2]  R1444     -2.5182211399078369e-01
    z[4,2,2]  R1445     3.7095537781715393e-01
    z[4,2,2]  R1446     4.8485729098320007e-01
    z[4,2,2]  R1447     0.391141802072525
    z[4,2,2]  R1448     -2.6335790753364563e-01
    z[4,2,2]  R1449     4.1815541684627533e-02
    z[4,2,2]  R1450     2.2154621779918671e-02
    z[4,2,2]  R1451     3.6627537012100220e-01
    z[4,2,2]  R1452     4.9212306737899780e-01
    z[4,2,2]  R1453     3.5707566142082214e-01
    z[4,2,2]  R1454     2.6747745275497437e-01
    z[4,2,2]  R1455     -1.8532557412981987e-02
    z[4,2,2]  R1456     1.9488810002803802e-01
    z[4,2,2]  R1457     1.8859108909964561e-02
    z[4,2,2]  R1458     -5.3550285100936890e-01
    z[4,2,2]  R1459     -2.4048466980457306e-01
    z[4,2,2]  R1460     0.082611583173275
    z[4,2,2]  R1461     -8.9654371142387390e-02
    z[4,2,2]  R1462     -2.1137490868568420e-01
    z[4,2,2]  R1463     -1.7876550555229187e-01
    z[4,2,2]  R1464     -2.6982340216636658e-01
    z[4,2,2]  R1465     -1.9752517342567444e-01
    z[4,2,2]  R1466     -1.1177732609212399e-02
    z[4,2,2]  R1467     -1.0844890773296356e-01
    z[4,2,2]  R1468     -5.7923197746276855e-01
    z[4,2,2]  R1469     -5.9258836507797241e-01
    z[4,2,2]  R1470     1.4884649217128754e-01
    z[4,2,2]  R1471     -4.0928909182548523e-01
    z[4,2,2]  R1472     -4.7487002611160278e-01
    z[4,2,2]  R1473     1.0943194478750229e-01
    z[4,2,2]  R1474     8.5958667099475861e-02
    z[4,2,2]  R1475     -0.606873631477356
    z[4,2,2]  R1476     1.0186557471752167e-01
    z[4,2,2]  R1477     0.625761091709137
    z[4,2,2]  R1478     -4.5682549476623535e-01
    z[4,2,2]  R1479     -8.2836419343948364e-02
    z[4,2,2]  R1480     -5.4207291454076767e-02
    z[4,2,2]  R1481     2.7874214574694633e-02
    z[4,2,2]  R1482     -4.2019593715667725e-01
    z[4,2,2]  R1483     -1.3303663581609726e-02
    z[4,2,2]  R1484     2.0317737758159637e-01
    z[4,2,2]  R1485     8.1217640638351440e-01
    z[4,2,2]  R1486     -3.9600688964128494e-02
    z[4,2,2]  R1487     -3.3364436030387878e-01
    z[4,2,2]  R1488     -7.4472390115261078e-02
    z[4,2,2]  R1489     -2.9672920703887939e-01
    z[4,2,2]  R1490     -4.3127492070198059e-01
    z[4,2,2]  R1491     1.4311423897743225e-01
    z[4,2,2]  R1492     -1.0728116333484650e-01
    z[4,2,2]  R1493     -2.1686401963233948e-01
    z[4,2,2]  R1494     3.9321917295455933e-01
    z[4,2,2]  R1495     4.4646185636520386e-01
    z[4,2,2]  R1496     -3.7101346254348755e-01
    z[4,2,2]  R1497     1.4247593283653259e-01
    z[4,2,3]  R23       1
    z[4,2,3]  R41       -1
    z[4,2,3]  R1390     -1
    z[4,2,3]  R1391     1
    z[4,2,3]  R1398     -4.1165980696678162e-01
    z[4,2,3]  R1399     -0.512349009513855
    z[4,2,3]  R1400     -2.7854391932487488e-01
    z[4,2,3]  R1401     5.7831909507513046e-02
    z[4,2,3]  R1402     2.8801107406616211e-01
    z[4,2,3]  R1403     3.1249490380287170e-01
    z[4,2,3]  R1404     1.3719774782657623e-01
    z[4,2,3]  R1405     4.3428402394056320e-02
    z[4,2,3]  R1406     -6.6395789384841919e-02
    z[4,2,3]  R1407     -3.9228478074073792e-01
    z[4,2,3]  R1408     3.4189349412918091e-01
    z[4,2,3]  R1409     4.8163211345672607e-01
    z[4,2,3]  R1410     8.0897784233093262e-01
    z[4,2,3]  R1411     8.2589679956436157e-01
    z[4,2,3]  R1412     5.5961722135543823e-01
    z[4,2,3]  R1413     3.9866998791694641e-01
    z[4,2,3]  R1414     -7.4746638536453247e-01
    z[4,2,3]  R1415     2.6748523116111755e-01
    z[4,2,3]  R1416     0.646652102470398
    z[4,2,3]  R1417     5.6053936481475830e-01
    z[4,2,3]  R1418     5.5258788168430328e-02
    z[4,2,3]  R1419     4.0571206808090210e-01
    z[4,2,3]  R1420     8.2479590177536011e-01
    z[4,2,3]  R1421     7.6130068302154541e-01
    z[4,2,3]  R1422     1.5137337148189545e-01
    z[4,2,3]  R1423     2.9105362296104431e-01
    z[4,2,3]  R1424     -6.1816269159317017e-01
    z[4,2,3]  R1425     -6.7544937133789062e-01
    z[4,2,3]  R1426     -6.6152596473693848e-01
    z[4,2,3]  R1427     4.3023351579904556e-02
    z[4,2,3]  R1428     -4.9738347530364990e-01
    z[4,2,3]  R1429     -4.9407455325126648e-01
    z[4,2,3]  R1430     -3.8313293457031250e-01
    z[4,2,3]  R1431     -6.3725954294204712e-01
    z[4,2,3]  R1432     -3.1108251214027405e-01
    z[4,2,3]  R1433     -3.7824982404708862e-01
    z[4,2,3]  R1434     -3.9815476536750793e-01
    z[4,2,3]  R1435     -3.7539014220237732e-01
    z[4,2,3]  R1436     -6.8444848060607910e-01
    z[4,2,3]  R1437     -4.8272785544395447e-01
    z[4,2,3]  R1438     4.8311153054237366e-01
    z[4,2,3]  R1439     5.9779763221740723e-01
    z[4,2,3]  R1440     6.4269524812698364e-01
    z[4,2,3]  R1441     6.1657619476318359e-01
    z[4,2,3]  R1442     3.2699123024940491e-01
    z[4,2,3]  R1443     5.1298719644546509e-01
    z[4,2,3]  R1444     4.0008780360221863e-01
    z[4,2,3]  R1445     6.0585594177246094e-01
    z[4,2,3]  R1446     3.9594307541847229e-01
    z[4,2,3]  R1447     4.2353931069374084e-01
    z[4,2,3]  R1448     -4.3787723779678345e-01
    z[4,2,3]  R1449     5.4378788918256760e-02
    z[4,2,3]  R1450     4.1932079195976257e-01
    z[4,2,3]  R1451     -2.0981330424547195e-02
    z[4,2,3]  R1452     -1.5364332357421517e-03
    z[4,2,3]  R1453     1.3689659535884857e-01
    z[4,2,3]  R1454     -9.2429459095001221e-02
    z[4,2,3]  R1455     -3.2372960448265076e-01
    z[4,2,3]  R1456     -1.2386822700500488e-01
    z[4,2,3]  R1457     3.1529575586318970e-01
    z[4,2,3]  R1458     2.3897531628608704e-01
    z[4,2,3]  R1459     -3.3361229300498962e-01
    z[4,2,3]  R1460     -0.145788311958313
    z[4,2,3]  R1461     -1.4089332520961761e-01
    z[4,2,3]  R1462     2.6580068469047546e-01
    z[4,2,3]  R1463     2.7467063069343567e-01
    z[4,2,3]  R1464     3.5498273372650146e-01
    z[4,2,3]  R1465     -3.6747679114341736e-02
    z[4,2,3]  R1466     4.0764799714088440e-01
    z[4,2,3]  R1467     5.6897927075624466e-02
    z[4,2,3]  R1468     -4.8815658688545227e-01
    z[4,2,3]  R1469     -7.2577714920043945e-01
    z[4,2,3]  R1470     2.6660218834877014e-01
    z[4,2,3]  R1471     2.3126375675201416e-01
    z[4,2,3]  R1472     5.9364604949951172e-01
    z[4,2,3]  R1473     -1.8681989610195160e-01
    z[4,2,3]  R1474     -4.3784928321838379e-01
    z[4,2,3]  R1475     -1.2139679491519928e-01
    z[4,2,3]  R1476     -2.9585435986518860e-02
    z[4,2,3]  R1477     -3.0198785662651062e-01
    z[4,2,3]  R1478     -5.2362877130508423e-01
    z[4,2,3]  R1479     9.5383845269680023e-02
    z[4,2,3]  R1480     1.9987209141254425e-01
    z[4,2,3]  R1481     1.3164575397968292e-01
    z[4,2,3]  R1482     4.9316713213920593e-01
    z[4,2,3]  R1483     1.6954675316810608e-02
    z[4,2,3]  R1484     -2.6575639843940735e-01
    z[4,2,3]  R1485     -1.7028152942657471e-01
    z[4,2,3]  R1486     -5.0227010250091553e-01
    z[4,2,3]  R1487     -2.0487660169601440e-01
    z[4,2,3]  R1488     -5.2006644010543823e-01
    z[4,2,3]  R1489     0.206911101937294
    z[4,2,3]  R1490     8.8795311748981476e-02
    z[4,2,3]  R1491     3.2202258706092834e-01
    z[4,2,3]  R1492     -0.298666775226593
    z[4,2,3]  R1493     1.9712407886981964e-01
    z[4,2,3]  R1494     3.5539147257804871e-01
    z[4,2,3]  R1495     4.5797824859619141e-01
    z[4,2,3]  R1496     4.5064017176628113e-01
    z[4,2,3]  R1497     0.621365487575531
    z[4,2,4]  R24       1
    z[4,2,4]  R42       -1
    z[4,2,4]  R1392     -1
    z[4,2,4]  R1393     1
    z[4,2,4]  R1398     1.5016369521617889e-01
    z[4,2,4]  R1399     -2.0167241990566254e-01
    z[4,2,4]  R1400     -1.8209861218929291e-01
    z[4,2,4]  R1401     2.4066562950611115e-01
    z[4,2,4]  R1402     3.5273811221122742e-01
    z[4,2,4]  R1403     5.6484955549240112e-01
    z[4,2,4]  R1404     3.1264483928680420e-01
    z[4,2,4]  R1405     2.9566618800163269e-01
    z[4,2,4]  R1406     -2.4209970608353615e-02
    z[4,2,4]  R1407     -2.0483043789863586e-01
    z[4,2,4]  R1408     1.2161655724048615e-01
    z[4,2,4]  R1409     -0.506409227848053
    z[4,2,4]  R1410     -9.3269376084208488e-03
    z[4,2,4]  R1411     1.2939088977873325e-02
    z[4,2,4]  R1412     1.3160282373428345e-01
    z[4,2,4]  R1413     -3.7997606396675110e-01
    z[4,2,4]  R1414     1.3030199706554413e-01
    z[4,2,4]  R1415     3.5595762729644775e-01
    z[4,2,4]  R1416     -5.6280148029327393e-01
    z[4,2,4]  R1417     -6.5569287538528442e-01
    z[4,2,4]  R1418     1.7943548038601875e-02
    z[4,2,4]  R1419     -4.4281604886054993e-01
    z[4,2,4]  R1420     -9.5948047935962677e-02
    z[4,2,4]  R1421     -4.3679103255271912e-01
    z[4,2,4]  R1422     -8.6402416229248047e-01
    z[4,2,4]  R1423     -5.1386451721191406e-01
    z[4,2,4]  R1424     2.8345569968223572e-01
    z[4,2,4]  R1425     -4.8353210091590881e-01
    z[4,2,4]  R1426     6.9809418916702271e-01
    z[4,2,4]  R1427     0.84651118516922
    z[4,2,4]  R1428     7.4108898639678955e-02
    z[4,2,4]  R1429     4.5411086082458496e-01
    z[4,2,4]  R1430     -7.7939257025718689e-02
    z[4,2,4]  R1431     2.5241702795028687e-02
    z[4,2,4]  R1432     -3.1280061602592468e-01
    z[4,2,4]  R1433     -0.197514608502388
    z[4,2,4]  R1434     1.8651725351810455e-01
    z[4,2,4]  R1435     3.4524840116500854e-01
    z[4,2,4]  R1436     -2.2133202850818634e-01
    z[4,2,4]  R1437     -9.4200141727924347e-02
    z[4,2,4]  R1438     2.0341378450393677e-01
    z[4,2,4]  R1439     8.9632213115692139e-02
    z[4,2,4]  R1440     2.4004580453038216e-02
    z[4,2,4]  R1441     2.9950913786888123e-01
    z[4,2,4]  R1442     2.2722056508064270e-01
    z[4,2,4]  R1443     -2.3124359548091888e-01
    z[4,2,4]  R1444     4.8136554658412933e-02
    z[4,2,4]  R1445     5.7331800460815430e-02
    z[4,2,4]  R1446     -2.1913222968578339e-01
    z[4,2,4]  R1447     5.3543031215667725e-01
    z[4,2,4]  R1448     -2.0215612649917603e-01
    z[4,2,4]  R1449     3.6794430017471313e-01
    z[4,2,4]  R1450     -2.8205132484436035e-01
    z[4,2,4]  R1451     -8.9348025619983673e-02
    z[4,2,4]  R1452     2.6865644380450249e-02
    z[4,2,4]  R1453     -1.1009267531335354e-02
    z[4,2,4]  R1454     3.2222609966993332e-02
    z[4,2,4]  R1455     -8.0519765615463257e-02
    z[4,2,4]  R1456     3.7069308757781982e-01
    z[4,2,4]  R1457     1.7405509948730469e-01
    z[4,2,4]  R1458     3.0431419610977173e-01
    z[4,2,4]  R1459     -8.5079200565814972e-02
    z[4,2,4]  R1460     7.2199290990829468e-01
    z[4,2,4]  R1461     3.3194559812545776e-01
    z[4,2,4]  R1462     1.6605427861213684e-01
    z[4,2,4]  R1463     1.8416607752442360e-02
    z[4,2,4]  R1464     -2.2175459563732147e-01
    z[4,2,4]  R1465     4.2684939503669739e-01
    z[4,2,4]  R1466     -2.6789689064025879e-01
    z[4,2,4]  R1467     3.8038060069084167e-01
    z[4,2,4]  R1468     -3.3481433987617493e-01
    z[4,2,4]  R1469     -2.6730507612228394e-02
    z[4,2,4]  R1470     -7.6060421764850616e-02
    z[4,2,4]  R1471     4.3052637577056885e-01
    z[4,2,4]  R1472     3.3167313784360886e-02
    z[4,2,4]  R1473     3.9344325661659241e-01
    z[4,2,4]  R1474     1.6735710203647614e-01
    z[4,2,4]  R1475     1.4674863219261169e-01
    z[4,2,4]  R1476     1.9643607735633850e-01
    z[4,2,4]  R1477     2.4451376497745514e-01
    z[4,2,4]  R1478     -2.8217095136642456e-01
    z[4,2,4]  R1479     4.3291813135147095e-01
    z[4,2,4]  R1480     6.5028005838394165e-01
    z[4,2,4]  R1481     -6.1785720288753510e-02
    z[4,2,4]  R1482     2.3512113094329834e-01
    z[4,2,4]  R1483     -6.0237981379032135e-02
    z[4,2,4]  R1484     8.2637047767639160e-01
    z[4,2,4]  R1485     6.9821491837501526e-02
    z[4,2,4]  R1486     7.6107615232467651e-01
    z[4,2,4]  R1487     6.2636291980743408e-01
    z[4,2,4]  R1488     6.4324772357940674e-01
    z[4,2,4]  R1489     3.2327157258987427e-01
    z[4,2,4]  R1490     1.6144491732120514e-01
    z[4,2,4]  R1491     5.3124237060546875e-01
    z[4,2,4]  R1492     7.2016930580139160e-01
    z[4,2,4]  R1493     -1.0330962389707565e-01
    z[4,2,4]  R1494     1.6766072809696198e-01
    z[4,2,4]  R1495     5.5407159030437469e-02
    z[4,2,4]  R1496     -4.9126887321472168e-01
    z[4,2,4]  R1497     4.8064431548118591e-01
    z[4,2,5]  R25       1
    z[4,2,5]  R43       -1
    z[4,2,5]  R1394     -1
    z[4,2,5]  R1395     1
    z[4,2,5]  R1398     4.9972828477621078e-02
    z[4,2,5]  R1399     -3.2711166143417358e-01
    z[4,2,5]  R1400     1.0573945939540863e-01
    z[4,2,5]  R1401     0.384998619556427
    z[4,2,5]  R1402     -2.5444485247135162e-02
    z[4,2,5]  R1403     -3.2719689607620239e-01
    z[4,2,5]  R1404     6.6548407077789307e-01
    z[4,2,5]  R1405     3.5918089747428894e-01
    z[4,2,5]  R1406     -8.1948794424533844e-02
    z[4,2,5]  R1407     1.1423498392105103e-02
    z[4,2,5]  R1408     1.6303362324833870e-02
    z[4,2,5]  R1409     0.0700659304857254
    z[4,2,5]  R1410     3.2645413279533386e-01
    z[4,2,5]  R1411     2.0752148702740669e-03
    z[4,2,5]  R1412     -5.4658412933349609e-01
    z[4,2,5]  R1413     2.6304228231310844e-02
    z[4,2,5]  R1414     4.7758507728576660e-01
    z[4,2,5]  R1415     3.8313046097755432e-01
    z[4,2,5]  R1416     -2.2911007702350616e-01
    z[4,2,5]  R1417     -3.0044120550155640e-01
    z[4,2,5]  R1418     5.3282942622900009e-02
    z[4,2,5]  R1419     0.546783983707428
    z[4,2,5]  R1420     3.4522768855094910e-01
    z[4,2,5]  R1421     -1.6942660510540009e-01
    z[4,2,5]  R1422     -1.2802666425704956e-01
    z[4,2,5]  R1423     -3.9604511857032776e-01
    z[4,2,5]  R1424     1.8112035095691681e-01
    z[4,2,5]  R1425     1.8203233182430267e-01
    z[4,2,5]  R1426     -1.9573500752449036e-01
    z[4,2,5]  R1427     1.5885604918003082e-01
    z[4,2,5]  R1428     -2.5763321667909622e-02
    z[4,2,5]  R1429     1.1319072544574738e-01
    z[4,2,5]  R1430     -3.2504707574844360e-01
    z[4,2,5]  R1431     -5.9077125787734985e-01
    z[4,2,5]  R1432     -8.5536353290081024e-02
    z[4,2,5]  R1433     3.8181871175765991e-02
    z[4,2,5]  R1434     -1.5665654838085175e-01
    z[4,2,5]  R1435     -3.6032482981681824e-01
    z[4,2,5]  R1436     4.5826286077499390e-01
    z[4,2,5]  R1437     2.3778598010540009e-01
    z[4,2,5]  R1438     2.3975865915417671e-02
    z[4,2,5]  R1439     -1.9673697650432587e-01
    z[4,2,5]  R1440     -3.9418466389179230e-02
    z[4,2,5]  R1441     -1.0547454655170441e-01
    z[4,2,5]  R1442     -4.1495278477668762e-01
    z[4,2,5]  R1443     1.3072626292705536e-01
    z[4,2,5]  R1444     -2.0526649057865143e-01
    z[4,2,5]  R1445     -2.4558408558368683e-01
    z[4,2,5]  R1446     -1.0090753436088562e-01
    z[4,2,5]  R1447     -1.0786123573780060e-01
    z[4,2,5]  R1448     -2.7562916278839111e-01
    z[4,2,5]  R1449     0.073304183781147
    z[4,2,5]  R1450     0.0922246053814888
    z[4,2,5]  R1451     4.6109721064567566e-01
    z[4,2,5]  R1452     1.2221264094114304e-01
    z[4,2,5]  R1453     3.6499887704849243e-01
    z[4,2,5]  R1454     -3.2317012548446655e-01
    z[4,2,5]  R1455     7.0836436934769154e-03
    z[4,2,5]  R1456     1.2804001569747925e-01
    z[4,2,5]  R1457     5.4895699024200439e-01
    z[4,2,5]  R1458     2.7236780524253845e-01
    z[4,2,5]  R1459     -1.2452408671379089e-01
    z[4,2,5]  R1460     -6.5301053225994110e-02
    z[4,2,5]  R1461     4.3510493636131287e-01
    z[4,2,5]  R1462     -5.7376161217689514e-02
    z[4,2,5]  R1463     -1.8761390447616577e-01
    z[4,2,5]  R1464     -5.1306881010532379e-02
    z[4,2,5]  R1465     -3.3381082117557526e-02
    z[4,2,5]  R1466     -1.3989751040935516e-01
    z[4,2,5]  R1467     7.0005212910473347e-03
    z[4,2,5]  R1468     -3.5425817966461182e-01
    z[4,2,5]  R1469     2.6494054123759270e-02
    z[4,2,5]  R1470     4.0824812650680542e-01
    z[4,2,5]  R1471     1.4948236942291260e-01
    z[4,2,5]  R1472     -3.0073684453964233e-01
    z[4,2,5]  R1473     -1.9144824147224426e-01
    z[4,2,5]  R1474     2.0868784189224243e-01
    z[4,2,5]  R1475     -1.5906600281596184e-02
    z[4,2,5]  R1476     -2.2126603126525879e-01
    z[4,2,5]  R1477     4.2481872439384460e-01
    z[4,2,5]  R1478     -2.1682459115982056e-01
    z[4,2,5]  R1479     -2.3186743259429932e-01
    z[4,2,5]  R1480     1.1061707139015198e-01
    z[4,2,5]  R1481     1.7542797327041626e-01
    z[4,2,5]  R1482     -3.1311661005020142e-01
    z[4,2,5]  R1483     -2.8522959351539612e-01
    z[4,2,5]  R1484     3.5395030863583088e-03
    z[4,2,5]  R1485     2.9308724403381348e-01
    z[4,2,5]  R1486     1.7048075795173645e-02
    z[4,2,5]  R1487     -3.4903664141893387e-02
    z[4,2,5]  R1488     1.9971325993537903e-01
    z[4,2,5]  R1489     0.141094371676445
    z[4,2,5]  R1490     2.4412022903561592e-02
    z[4,2,5]  R1491     3.5019564628601074e-01
    z[4,2,5]  R1492     2.1683631464838982e-02
    z[4,2,5]  R1493     1.0498115420341492e-01
    z[4,2,5]  R1494     6.6231940872967243e-03
    z[4,2,5]  R1495     -2.3655049502849579e-01
    z[4,2,5]  R1496     -0.504997730255127
    z[4,2,5]  R1497     -2.6477809995412827e-02
    z[4,2,6]  R26       1
    z[4,2,6]  R44       -1
    z[4,2,6]  R1396     -1
    z[4,2,6]  R1397     1
    z[4,2,6]  R1398     1.6514627635478973e-01
    z[4,2,6]  R1399     6.5292038023471832e-02
    z[4,2,6]  R1400     -1.0161355137825012e-01
    z[4,2,6]  R1401     -2.9342442750930786e-01
    z[4,2,6]  R1402     1.9883975386619568e-01
    z[4,2,6]  R1403     1.8315419554710388e-01
    z[4,2,6]  R1404     -1.8604686483740807e-02
    z[4,2,6]  R1405     5.9675145149230957e-01
    z[4,2,6]  R1406     -3.7798005342483521e-01
    z[4,2,6]  R1407     3.4525832533836365e-01
    z[4,2,6]  R1408     -4.4347429275512695e-01
    z[4,2,6]  R1409     1.9795902073383331e-01
    z[4,2,6]  R1410     2.3786519467830658e-01
    z[4,2,6]  R1411     2.4091006815433502e-01
    z[4,2,6]  R1412     3.1069728732109070e-01
    z[4,2,6]  R1413     1.4187897741794586e-01
    z[4,2,6]  R1414     -3.1719669699668884e-01
    z[4,2,6]  R1415     2.6061311364173889e-01
    z[4,2,6]  R1416     2.4852724373340607e-01
    z[4,2,6]  R1417     7.5940592214465141e-03
    z[4,2,6]  R1418     4.6995532512664795e-01
    z[4,2,6]  R1419     -1.1474460363388062e-01
    z[4,2,6]  R1420     -1.5504789538681507e-02
    z[4,2,6]  R1421     1.5785694122314453e-02
    z[4,2,6]  R1422     -9.7251825034618378e-02
    z[4,2,6]  R1423     5.5259648710489273e-02
    z[4,2,6]  R1424     -1.8019108474254608e-01
    z[4,2,6]  R1425     -1.2802480161190033e-01
    z[4,2,6]  R1426     9.7086921334266663e-02
    z[4,2,6]  R1427     0.328484445810318
    z[4,2,6]  R1428     -5.2041497081518173e-02
    z[4,2,6]  R1429     2.6563179492950439e-01
    z[4,2,6]  R1430     1.2247455865144730e-01
    z[4,2,6]  R1431     -2.9744941741228104e-02
    z[4,2,6]  R1432     -1.7013169825077057e-01
    z[4,2,6]  R1433     -3.5226354002952576e-01
    z[4,2,6]  R1434     -3.1037840247154236e-01
    z[4,2,6]  R1435     -2.2379522025585175e-01
    z[4,2,6]  R1436     4.9815565347671509e-02
    z[4,2,6]  R1437     6.5397346019744873e-01
    z[4,2,6]  R1438     1.7376956343650818e-01
    z[4,2,6]  R1439     3.9379266090691090e-03
    z[4,2,6]  R1440     8.5842885076999664e-02
    z[4,2,6]  R1441     5.0171691924333572e-02
    z[4,2,6]  R1442     -2.0933536812663078e-02
    z[4,2,6]  R1443     -5.0253149121999741e-02
    z[4,2,6]  R1444     2.9349419474601746e-01
    z[4,2,6]  R1445     2.8682306408882141e-01
    z[4,2,6]  R1446     -1.9491675496101379e-01
    z[4,2,6]  R1447     -3.3388055860996246e-02
    z[4,2,6]  R1448     -1.3035708665847778e-01
    z[4,2,6]  R1449     -3.4366950392723083e-01
    z[4,2,6]  R1450     9.2071019113063812e-02
    z[4,2,6]  R1451     -1.1393783241510391e-01
    z[4,2,6]  R1452     8.2571931183338165e-02
    z[4,2,6]  R1453     -3.6306026577949524e-01
    z[4,2,6]  R1454     8.3058521151542664e-02
    z[4,2,6]  R1455     1.4299200847744942e-02
    z[4,2,6]  R1456     4.2816221714019775e-01
    z[4,2,6]  R1457     3.4252646565437317e-01
    z[4,2,6]  R1458     -1.8468311429023743e-01
    z[4,2,6]  R1459     -4.3246969580650330e-01
    z[4,2,6]  R1460     6.2741570174694061e-02
    z[4,2,6]  R1461     -5.8201032876968384e-01
    z[4,2,6]  R1462     1.0211148113012314e-01
    z[4,2,6]  R1463     -2.6464468240737915e-01
    z[4,2,6]  R1464     5.3623810410499573e-02
    z[4,2,6]  R1465     4.9583610892295837e-01
    z[4,2,6]  R1466     1.6540125012397766e-01
    z[4,2,6]  R1467     -2.4010688066482544e-01
    z[4,2,6]  R1468     3.7758362293243408e-01
    z[4,2,6]  R1469     -3.3995591104030609e-02
    z[4,2,6]  R1470     2.4440832436084747e-01
    z[4,2,6]  R1471     2.2488673031330109e-01
    z[4,2,6]  R1472     1.7554501071572304e-02
    z[4,2,6]  R1473     -5.4029554128646851e-01
    z[4,2,6]  R1474     -2.1544055640697479e-01
    z[4,2,6]  R1475     -4.4490674138069153e-01
    z[4,2,6]  R1476     5.8592408895492554e-01
    z[4,2,6]  R1477     -4.2189598083496094e-02
    z[4,2,6]  R1478     0.26277956366539
    z[4,2,6]  R1479     -1.5819574892520905e-01
    z[4,2,6]  R1480     6.4440146088600159e-02
    z[4,2,6]  R1481     -0.503376841545105
    z[4,2,6]  R1482     9.5405891537666321e-02
    z[4,2,6]  R1483     5.3170013427734375e-01
    z[4,2,6]  R1484     -3.4733593463897705e-01
    z[4,2,6]  R1485     1.4525157213211060e-01
    z[4,2,6]  R1486     -1.4669755101203918e-01
    z[4,2,6]  R1487     -3.0108600854873657e-01
    z[4,2,6]  R1488     -2.6337680220603943e-01
    z[4,2,6]  R1489     -1.4485427737236023e-01
    z[4,2,6]  R1490     4.2245812714099884e-02
    z[4,2,6]  R1491     8.5663706064224243e-02
    z[4,2,6]  R1492     -1.1631070822477341e-01
    z[4,2,6]  R1493     1.2773084640502930e-01
    z[4,2,6]  R1494     1.3055829703807831e-01
    z[4,2,6]  R1495     -1.3799254596233368e-01
    z[4,2,6]  R1496     -3.9727625250816345e-01
    z[4,2,6]  R1497     -1.6255301237106323e-01
    z[2,5,0]  R20       -1
    z[2,5,0]  R47       1
    z[2,5,0]  R1498     -1
    z[2,5,0]  R1499     1
    z[2,5,0]  R1512     3.7873715162277222e-01
    z[2,5,0]  R1513     5.3333443403244019e-01
    z[2,5,0]  R1514     6.8667048215866089e-01
    z[2,5,0]  R1515     -1.4450901746749878e-01
    z[2,5,0]  R1516     6.8553018569946289e-01
    z[2,5,0]  R1517     6.5093624591827393e-01
    z[2,5,0]  R1518     7.6829367876052856e-01
    z[2,5,0]  R1519     5.8579719066619873e-01
    z[2,5,0]  R1520     -0.367805153131485
    z[2,5,0]  R1521     1.2440484762191772e-01
    z[2,5,0]  R1522     7.8678119182586670e-01
    z[2,5,0]  R1523     6.4782553911209106e-01
    z[2,5,0]  R1524     7.5260007381439209e-01
    z[2,5,0]  R1525     6.2868463993072510e-01
    z[2,5,0]  R1526     6.5628039836883545e-01
    z[2,5,0]  R1527     7.3745173215866089e-01
    z[2,5,0]  R1528     7.6738870143890381e-01
    z[2,5,0]  R1529     5.6793701648712158e-01
    z[2,5,0]  R1530     7.0700442790985107e-01
    z[2,5,0]  R1531     5.2821296453475952e-01
    z[2,5,0]  R1532     -5.5435019731521606e-01
    z[2,5,0]  R1533     -1.3739745318889618e-01
    z[2,5,0]  R1534     -2.4997992813587189e-01
    z[2,5,0]  R1535     -9.3141689896583557e-02
    z[2,5,0]  R1536     -3.6504247784614563e-01
    z[2,5,0]  R1537     -1.8392980098724365e-01
    z[2,5,0]  R1538     -2.9985910654067993e-01
    z[2,5,0]  R1539     -1.4240592718124390e-01
    z[2,5,0]  R1540     -1.1798799037933350e-01
    z[2,5,0]  R1541     -8.4018073976039886e-02
    z[2,5,0]  R1542     2.7113190293312073e-01
    z[2,5,0]  R1543     7.4907368421554565e-01
    z[2,5,0]  R1544     -6.4337062835693359e-01
    z[2,5,0]  R1545     5.5352133512496948e-01
    z[2,5,0]  R1546     -8.7810635566711426e-01
    z[2,5,0]  R1547     -8.5123598575592041e-01
    z[2,5,0]  R1548     -7.8212362527847290e-01
    z[2,5,0]  R1549     -7.1261632442474365e-01
    z[2,5,0]  R1550     -8.3282917737960815e-01
    z[2,5,0]  R1551     -8.2556849718093872e-01
    z[2,5,0]  R1552     -8.3808355033397675e-02
    z[2,5,0]  R1553     -6.3356541097164154e-02
    z[2,5,0]  R1554     1.9311730563640594e-01
    z[2,5,0]  R1555     1.9144977629184723e-01
    z[2,5,0]  R1556     -9.8120421171188354e-02
    z[2,5,0]  R1557     -6.7651188373565674e-01
    z[2,5,0]  R1558     7.1136116981506348e-01
    z[2,5,0]  R1559     5.4982852935791016e-01
    z[2,5,0]  R1560     -0.673531174659729
    z[2,5,0]  R1561     5.1509976387023926e-01
    z[2,5,0]  R1562     -5.5446839332580566e-01
    z[2,5,0]  R1563     -6.9315418601036072e-02
    z[2,5,0]  R1564     3.8593227509409189e-03
    z[2,5,0]  R1565     3.5450258851051331e-01
    z[2,5,0]  R1566     -1.2340407073497772e-01
    z[2,5,0]  R1567     -4.0811732411384583e-02
    z[2,5,0]  R1568     -2.8628918528556824e-01
    z[2,5,0]  R1569     4.2757335305213928e-01
    z[2,5,0]  R1570     -2.9277181625366211e-01
    z[2,5,0]  R1571     6.0205173492431641e-01
    z[2,5,0]  R1572     -4.4183117151260376e-01
    z[2,5,0]  R1573     3.0860555171966553e-01
    z[2,5,0]  R1574     -1.1031243205070496e-01
    z[2,5,0]  R1575     -1.3681454956531525e-01
    z[2,5,0]  R1576     5.8535623550415039e-01
    z[2,5,0]  R1577     -8.4071463346481323e-01
    z[2,5,0]  R1578     -7.9630863666534424e-01
    z[2,5,0]  R1579     -7.1491372585296631e-01
    z[2,5,0]  R1580     6.0217022895812988e-02
    z[2,5,0]  R1581     -1.7587128281593323e-01
    z[2,5,0]  R1582     6.4572030305862427e-01
    z[2,5,0]  R1583     5.9248942136764526e-01
    z[2,5,0]  R1584     7.7949911355972290e-01
    z[2,5,0]  R1585     4.3592220544815063e-01
    z[2,5,0]  R1586     7.5880461931228638e-01
    z[2,5,0]  R1587     0.639691948890686
    z[2,5,0]  R1588     5.3148925304412842e-01
    z[2,5,0]  R1589     2.0234270393848419e-01
    z[2,5,0]  R1590     4.5358395576477051e-01
    z[2,5,0]  R1591     1.1968953907489777e-01
    z[2,5,0]  R1592     -4.3323707580566406e-01
    z[2,5,0]  R1593     2.5212273001670837e-01
    z[2,5,0]  R1594     2.6298072934150696e-01
    z[2,5,0]  R1595     1.1024408787488937e-01
    z[2,5,0]  R1596     -5.2712941169738770e-01
    z[2,5,0]  R1597     0.0764106810092926
    z[2,5,0]  R1598     1.2938044965267181e-01
    z[2,5,0]  R1599     1.4818756282329559e-01
    z[2,5,0]  R1600     1.3261912763118744e-01
    z[2,5,0]  R1601     0.0923101156949997
    z[2,5,0]  R1602     2.6949477195739746e-01
    z[2,5,0]  R1603     -6.9175457954406738e-01
    z[2,5,0]  R1604     -8.6974817514419556e-01
    z[2,5,0]  R1605     2.7312484383583069e-01
    z[2,5,0]  R1606     -8.7619078159332275e-01
    z[2,5,0]  R1607     -0.76837557554245
    z[2,5,0]  R1608     -8.9575308561325073e-01
    z[2,5,0]  R1609     3.4537902474403381e-01
    z[2,5,0]  R1610     -8.8181060552597046e-01
    z[2,5,0]  R1611     -7.6651340723037720e-01
    z[2,5,0]  R1612     2.6273876428604126e-01
    z[2,5,0]  R1613     2.1442225202918053e-02
    z[2,5,0]  R1614     -5.0709646940231323e-01
    z[2,5,0]  R1615     -6.8957008421421051e-02
    z[2,5,0]  R1616     -6.5651647746562958e-02
    z[2,5,0]  R1617     -0.276305615901947
    z[2,5,0]  R1618     4.8680922389030457e-01
    z[2,5,0]  R1619     -1.8024887144565582e-01
    z[2,5,0]  R1620     -9.4130545854568481e-02
    z[2,5,0]  R1621     3.1457754969596863e-01
    z[2,5,0]  R1622     4.1230636835098267e-01
    z[2,5,0]  R1623     -2.1953971683979034e-01
    z[2,5,0]  R1624     -6.0983443260192871e-01
    z[2,5,0]  R1625     1.5954670310020447e-01
    z[2,5,0]  R1626     -8.1131941080093384e-01
    z[2,5,0]  R1627     6.5042026340961456e-02
    z[2,5,0]  R1628     -8.1532442569732666e-01
    z[2,5,0]  R1629     -7.0960956811904907e-01
    z[2,5,0]  R1630     0.0046690390445292
    z[2,5,0]  R1631     -7.8674578666687012e-01
    z[2,5,0]  R1632     3.9653930068016052e-01
    z[2,5,0]  R1633     -2.1907810121774673e-02
    z[2,5,0]  R1634     -2.9042005538940430e-01
    z[2,5,0]  R1635     2.8162726759910583e-01
    z[2,5,0]  R1636     -8.9192312955856323e-01
    z[2,5,0]  R1637     -3.7026621401309967e-02
    z[2,5,0]  R1638     -8.2801800966262817e-01
    z[2,5,0]  R1639     -8.0668920278549194e-01
    z[2,5,0]  R1640     -0.774544894695282
    z[2,5,0]  R1641     -1.6462604701519012e-01
    z[2,5,0]  R1642     1.5975052118301392e-01
    z[2,5,0]  R1643     -1.0059801489114761e-01
    z[2,5,0]  R1644     -1.3567447662353516e-01
    z[2,5,0]  R1645     2.2019736468791962e-01
    z[2,5,0]  R1646     3.0585357546806335e-01
    z[2,5,0]  R1647     -8.1261835992336273e-02
    z[2,5,0]  R1648     -4.8062843084335327e-01
    z[2,5,0]  R1649     0.339558869600296
    z[2,5,0]  R1650     4.1992641985416412e-02
    z[2,5,0]  R1651     9.0691335499286652e-02
    z[2,5,0]  R1652     2.0195426046848297e-01
    z[2,5,0]  R1653     -4.5795783400535583e-01
    z[2,5,0]  R1654     -5.0490312278270721e-02
    z[2,5,0]  R1655     -8.3322483301162720e-01
    z[2,5,0]  R1656     -3.7403514981269836e-01
    z[2,5,0]  R1657     -4.0900033712387085e-01
    z[2,5,0]  R1658     8.3096392452716827e-02
    z[2,5,0]  R1659     -2.1625292301177979e-01
    z[2,5,0]  R1660     -7.3570340871810913e-01
    z[2,5,0]  R1661     -6.4198029041290283e-01
    z[2,5,1]  R21       -1
    z[2,5,1]  R48       1
    z[2,5,1]  R1500     -1
    z[2,5,1]  R1501     1
    z[2,5,1]  R1512     5.2845132350921631e-01
    z[2,5,1]  R1513     4.2615747451782227e-01
    z[2,5,1]  R1514     4.8639130592346191e-01
    z[2,5,1]  R1515     3.4531673789024353e-01
    z[2,5,1]  R1516     5.2249819040298462e-01
    z[2,5,1]  R1517     4.6735259890556335e-01
    z[2,5,1]  R1518     3.0830904841423035e-01
    z[2,5,1]  R1519     4.4670420885086060e-01
    z[2,5,1]  R1520     1.5149046480655670e-01
    z[2,5,1]  R1521     4.2348146438598633e-01
    z[2,5,1]  R1522     -3.6520402878522873e-02
    z[2,5,1]  R1523     -0.224799245595932
    z[2,5,1]  R1524     -1.0453260689973831e-01
    z[2,5,1]  R1525     -3.3511823415756226e-01
    z[2,5,1]  R1526     -4.3470478057861328e-01
    z[2,5,1]  R1527     -3.2897549867630005e-01
    z[2,5,1]  R1528     -2.3882986605167389e-01
    z[2,5,1]  R1529     -1.6404964029788971e-01
    z[2,5,1]  R1530     -1.0996983945369720e-01
    z[2,5,1]  R1531     -2.9862865805625916e-01
    z[2,5,1]  R1532     -5.4568356275558472e-01
    z[2,5,1]  R1533     -8.4708386659622192e-01
    z[2,5,1]  R1534     -8.1526309251785278e-01
    z[2,5,1]  R1535     -0.789399266242981
    z[2,5,1]  R1536     -7.7593863010406494e-01
    z[2,5,1]  R1537     -7.4482750892639160e-01
    z[2,5,1]  R1538     -8.4712529182434082e-01
    z[2,5,1]  R1539     -9.3157833814620972e-01
    z[2,5,1]  R1540     -7.7176654338836670e-01
    z[2,5,1]  R1541     -6.6648370027542114e-01
    z[2,5,1]  R1542     -6.1783152818679810e-01
    z[2,5,1]  R1543     -2.4491614103317261e-01
    z[2,5,1]  R1544     -1.6888128221035004e-01
    z[2,5,1]  R1545     -1.6578610241413116e-01
    z[2,5,1]  R1546     2.6889970898628235e-01
    z[2,5,1]  R1547     2.4984259903430939e-01
    z[2,5,1]  R1548     3.6712694168090820e-01
    z[2,5,1]  R1549     -1.5047702193260193e-01
    z[2,5,1]  R1550     1.4627382159233093e-01
    z[2,5,1]  R1551     3.1788122653961182e-01
    z[2,5,1]  R1552     -0.197486013174057
    z[2,5,1]  R1553     -3.3985349535942078e-01
    z[2,5,1]  R1554     -7.9830235242843628e-01
    z[2,5,1]  R1555     -6.9575464725494385e-01
    z[2,5,1]  R1556     -5.6621932983398438e-01
    z[2,5,1]  R1557     -1.0993305593729019e-01
    z[2,5,1]  R1558     -4.2058369517326355e-01
    z[2,5,1]  R1559     -3.0809995532035828e-01
    z[2,5,1]  R1560     -3.2287931442260742e-01
    z[2,5,1]  R1561     9.9301591515541077e-02
    z[2,5,1]  R1562     -1.1832910031080246e-01
    z[2,5,1]  R1563     -8.4441047906875610e-01
    z[2,5,1]  R1564     -7.1961444616317749e-01
    z[2,5,1]  R1565     -7.5381666421890259e-01
    z[2,5,1]  R1566     -6.3448148965835571e-01
    z[2,5,1]  R1567     -7.9383903741836548e-01
    z[2,5,1]  R1568     -5.0873693078756332e-02
    z[2,5,1]  R1569     -1.2915693223476410e-01
    z[2,5,1]  R1570     -2.4370776116847992e-01
    z[2,5,1]  R1571     6.2591084279119968e-03
    z[2,5,1]  R1572     7.5826406478881836e-02
    z[2,5,1]  R1573     -7.9278451204299927e-01
    z[2,5,1]  R1574     -8.7493056058883667e-01
    z[2,5,1]  R1575     -6.6701400279998779e-01
    z[2,5,1]  R1576     -1.5493483841419220e-01
    z[2,5,1]  R1577     4.1146323084831238e-01
    z[2,5,1]  R1578     1.9942082464694977e-01
    z[2,5,1]  R1579     4.1929177939891815e-02
    z[2,5,1]  R1580     -3.8080174475908279e-02
    z[2,5,1]  R1581     0.551843523979187
    z[2,5,1]  R1582     -0.438917875289917
    z[2,5,1]  R1583     -3.9163279533386230e-01
    z[2,5,1]  R1584     -2.6016622781753540e-01
    z[2,5,1]  R1585     -3.7669035792350769e-01
    z[2,5,1]  R1586     -2.9924064874649048e-01
    z[2,5,1]  R1587     -5.9318101406097412e-01
    z[2,5,1]  R1588     -3.3125856518745422e-01
    z[2,5,1]  R1589     -3.1194382905960083e-01
    z[2,5,1]  R1590     -3.7661054730415344e-01
    z[2,5,1]  R1591     -4.1943570971488953e-01
    z[2,5,1]  R1592     -6.0823440551757812e-01
    z[2,5,1]  R1593     9.3426233530044556e-01
    z[2,5,1]  R1594     9.0262013673782349e-01
    z[2,5,1]  R1595     8.4135597944259644e-01
    z[2,5,1]  R1596     -6.0268962383270264e-01
    z[2,5,1]  R1597     9.1193181276321411e-01
    z[2,5,1]  R1598     8.6812484264373779e-01
    z[2,5,1]  R1599     0.893491804599762
    z[2,5,1]  R1600     8.6231881380081177e-01
    z[2,5,1]  R1601     8.3279460668563843e-01
    z[2,5,1]  R1602     -5.1101475954055786e-01
    z[2,5,1]  R1603     1.4255075156688690e-01
    z[2,5,1]  R1604     1.4731350541114807e-01
    z[2,5,1]  R1605     -4.5945802330970764e-01
    z[2,5,1]  R1606     1.0036489367485046e-01
    z[2,5,1]  R1607     1.6679603606462479e-02
    z[2,5,1]  R1608     1.0234550572931767e-02
    z[2,5,1]  R1609     3.0713167786598206e-01
    z[2,5,1]  R1610     1.4513903856277466e-01
    z[2,5,1]  R1611     5.6686513125896454e-02
    z[2,5,1]  R1612     -0.594928503036499
    z[2,5,1]  R1613     -0.537834644317627
    z[2,5,1]  R1614     -7.6466858386993408e-01
    z[2,5,1]  R1615     -4.1257899999618530e-01
    z[2,5,1]  R1616     -0.819805920124054
    z[2,5,1]  R1617     -7.8827476501464844e-01
    z[2,5,1]  R1618     2.5197806954383850e-01
    z[2,5,1]  R1619     -5.6327307224273682e-01
    z[2,5,1]  R1620     -5.7580155134201050e-01
    z[2,5,1]  R1621     0.877967894077301
    z[2,5,1]  R1622     -5.0431424379348755e-01
    z[2,5,1]  R1623     -2.3633006215095520e-01
    z[2,5,1]  R1624     -0.75218665599823
    z[2,5,1]  R1625     0.841509222984314
    z[2,5,1]  R1626     1.3649652898311615e-01
    z[2,5,1]  R1627     7.4180859327316284e-01
    z[2,5,1]  R1628     3.7573236227035522e-01
    z[2,5,1]  R1629     4.6993693709373474e-01
    z[2,5,1]  R1630     7.5818246603012085e-01
    z[2,5,1]  R1631     3.6967658996582031e-01
    z[2,5,1]  R1632     -4.1390848159790039e-01
    z[2,5,1]  R1633     -5.5232656002044678e-01
    z[2,5,1]  R1634     -5.8645367622375488e-01
    z[2,5,1]  R1635     0.853574812412262
    z[2,5,1]  R1636     1.4161099493503571e-01
    z[2,5,1]  R1637     8.7833267450332642e-01
    z[2,5,1]  R1638     4.6460762619972229e-01
    z[2,5,1]  R1639     4.2761087417602539e-01
    z[2,5,1]  R1640     4.3448188900947571e-01
    z[2,5,1]  R1641     3.3101415634155273e-01
    z[2,5,1]  R1642     -7.2734969854354858e-01
    z[2,5,1]  R1643     -4.8096224665641785e-01
    z[2,5,1]  R1644     -6.3518542051315308e-01
    z[2,5,1]  R1645     -0.549447774887085
    z[2,5,1]  R1646     8.0458915233612061e-01
    z[2,5,1]  R1647     7.3582708835601807e-01
    z[2,5,1]  R1648     -3.4479122608900070e-02
    z[2,5,1]  R1649     6.7354500293731689e-01
    z[2,5,1]  R1650     4.5692536234855652e-01
    z[2,5,1]  R1651     5.0765895843505859e-01
    z[2,5,1]  R1652     -6.1409157514572144e-01
    z[2,5,1]  R1653     -1.2565791606903076e-01
    z[2,5,1]  R1654     4.1230061650276184e-01
    z[2,5,1]  R1655     3.9774590730667114e-01
    z[2,5,1]  R1656     2.1396382153034210e-01
    z[2,5,1]  R1657     3.3984705805778503e-01
    z[2,5,1]  R1658     2.2719369828701019e-01
    z[2,5,1]  R1659     3.8789638876914978e-01
    z[2,5,1]  R1660     3.6635231971740723e-01
    z[2,5,1]  R1661     5.1319259405136108e-01
    z[2,5,2]  R22       -1
    z[2,5,2]  R49       1
    z[2,5,2]  R1502     -1
    z[2,5,2]  R1503     1
    z[2,5,2]  R1512     5.6660646200180054e-01
    z[2,5,2]  R1513     1.5669887885451317e-02
    z[2,5,2]  R1514     -1.3559582829475403e-01
    z[2,5,2]  R1515     3.2131153345108032e-01
    z[2,5,2]  R1516     1.6175954043865204e-01
    z[2,5,2]  R1517     -2.2412294149398804e-01
    z[2,5,2]  R1518     -2.1871482953429222e-02
    z[2,5,2]  R1519     -1.3139431178569794e-01
    z[2,5,2]  R1520     3.3440402150154114e-01
    z[2,5,2]  R1521     2.8118276596069336e-01
    z[2,5,2]  R1522     2.7220770716667175e-01
    z[2,5,2]  R1523     3.5450032353401184e-01
    z[2,5,2]  R1524     1.0474268347024918e-02
    z[2,5,2]  R1525     9.4537794589996338e-02
    z[2,5,2]  R1526     2.2170089185237885e-01
    z[2,5,2]  R1527     -1.0814710706472397e-01
    z[2,5,2]  R1528     -2.5182211399078369e-01
    z[2,5,2]  R1529     3.7095537781715393e-01
    z[2,5,2]  R1530     4.8485729098320007e-01
    z[2,5,2]  R1531     0.391141802072525
    z[2,5,2]  R1532     -2.6335790753364563e-01
    z[2,5,2]  R1533     4.1815541684627533e-02
    z[2,5,2]  R1534     2.2154621779918671e-02
    z[2,5,2]  R1535     3.6627537012100220e-01
    z[2,5,2]  R1536     4.9212306737899780e-01
    z[2,5,2]  R1537     3.5707566142082214e-01
    z[2,5,2]  R1538     2.6747745275497437e-01
    z[2,5,2]  R1539     -1.8532557412981987e-02
    z[2,5,2]  R1540     1.9488810002803802e-01
    z[2,5,2]  R1541     1.8859108909964561e-02
    z[2,5,2]  R1542     -5.3550285100936890e-01
    z[2,5,2]  R1543     -2.4048466980457306e-01
    z[2,5,2]  R1544     0.082611583173275
    z[2,5,2]  R1545     -8.9654371142387390e-02
    z[2,5,2]  R1546     -2.1137490868568420e-01
    z[2,5,2]  R1547     -1.7876550555229187e-01
    z[2,5,2]  R1548     -2.6982340216636658e-01
    z[2,5,2]  R1549     -1.9752517342567444e-01
    z[2,5,2]  R1550     -1.1177732609212399e-02
    z[2,5,2]  R1551     -1.0844890773296356e-01
    z[2,5,2]  R1552     -5.7923197746276855e-01
    z[2,5,2]  R1553     -5.9258836507797241e-01
    z[2,5,2]  R1554     1.4884649217128754e-01
    z[2,5,2]  R1555     -4.0928909182548523e-01
    z[2,5,2]  R1556     -4.7487002611160278e-01
    z[2,5,2]  R1557     1.0943194478750229e-01
    z[2,5,2]  R1558     8.5958667099475861e-02
    z[2,5,2]  R1559     -0.606873631477356
    z[2,5,2]  R1560     1.0186557471752167e-01
    z[2,5,2]  R1561     0.625761091709137
    z[2,5,2]  R1562     -4.5682549476623535e-01
    z[2,5,2]  R1563     -8.2836419343948364e-02
    z[2,5,2]  R1564     -5.4207291454076767e-02
    z[2,5,2]  R1565     2.7874214574694633e-02
    z[2,5,2]  R1566     -4.2019593715667725e-01
    z[2,5,2]  R1567     -1.3303663581609726e-02
    z[2,5,2]  R1568     2.0317737758159637e-01
    z[2,5,2]  R1569     8.1217640638351440e-01
    z[2,5,2]  R1570     -3.9600688964128494e-02
    z[2,5,2]  R1571     -3.3364436030387878e-01
    z[2,5,2]  R1572     -7.4472390115261078e-02
    z[2,5,2]  R1573     -2.9672920703887939e-01
    z[2,5,2]  R1574     -4.3127492070198059e-01
    z[2,5,2]  R1575     1.4311423897743225e-01
    z[2,5,2]  R1576     -1.0728116333484650e-01
    z[2,5,2]  R1577     -2.1686401963233948e-01
    z[2,5,2]  R1578     3.9321917295455933e-01
    z[2,5,2]  R1579     4.4646185636520386e-01
    z[2,5,2]  R1580     -3.7101346254348755e-01
    z[2,5,2]  R1581     1.4247593283653259e-01
    z[2,5,2]  R1582     2.5509269908070564e-02
    z[2,5,2]  R1583     -1.2994299829006195e-01
    z[2,5,2]  R1584     0.00855214148759842
    z[2,5,2]  R1585     -8.2567613571882248e-03
    z[2,5,2]  R1586     -0.0819530263543129
    z[2,5,2]  R1587     -2.4621009826660156e-01
    z[2,5,2]  R1588     2.4352274835109711e-01
    z[2,5,2]  R1589     2.8601571917533875e-01
    z[2,5,2]  R1590     -2.8663319349288940e-01
    z[2,5,2]  R1591     4.8929706215858459e-01
    z[2,5,2]  R1592     3.5377609729766846e-01
    z[2,5,2]  R1593     -1.2487702071666718e-01
    z[2,5,2]  R1594     7.2028875350952148e-02
    z[2,5,2]  R1595     3.4526497125625610e-02
    z[2,5,2]  R1596     0.312128484249115
    z[2,5,2]  R1597     2.1002875640988350e-02
    z[2,5,2]  R1598     0.0805911272764206
    z[2,5,2]  R1599     -7.9114206135272980e-02
    z[2,5,2]  R1600     6.0015637427568436e-02
    z[2,5,2]  R1601     1.1777395755052567e-01
    z[2,5,2]  R1602     4.2093533277511597e-01
    z[2,5,2]  R1603     -1.8737387657165527e-01
    z[2,5,2]  R1604     -1.9083991646766663e-01
    z[2,5,2]  R1605     5.4359138011932373e-01
    z[2,5,2]  R1606     1.6755944490432739e-01
    z[2,5,2]  R1607     -4.0088900923728943e-01
    z[2,5,2]  R1608     -2.7087965607643127e-01
    z[2,5,2]  R1609     8.4773671627044678e-01
    z[2,5,2]  R1610     -5.3328428417444229e-02
    z[2,5,2]  R1611     -9.1249540448188782e-02
    z[2,5,2]  R1612     -2.6642715558409691e-02
    z[2,5,2]  R1613     -1.4002242684364319e-01
    z[2,5,2]  R1614     1.8087702989578247e-01
    z[2,5,2]  R1615     -1.3100315630435944e-01
    z[2,5,2]  R1616     6.3425756990909576e-02
    z[2,5,2]  R1617     0.0672854483127594
    z[2,5,2]  R1618     7.9600483179092407e-01
    z[2,5,2]  R1619     0.364924818277359
    z[2,5,2]  R1620     0.312404990196228
    z[2,5,2]  R1621     2.9581832885742188e-01
    z[2,5,2]  R1622     4.8731550574302673e-01
    z[2,5,2]  R1623     -4.9703961610794067e-01
    z[2,5,2]  R1624     -7.6577968895435333e-02
    z[2,5,2]  R1625     -2.5888085365295410e-01
    z[2,5,2]  R1626     2.3808078840374947e-02
    z[2,5,2]  R1627     -1.9698525965213776e-01
    z[2,5,2]  R1628     -8.8015489280223846e-02
    z[2,5,2]  R1629     -2.1856112778186798e-01
    z[2,5,2]  R1630     1.3577975332736969e-01
    z[2,5,2]  R1631     3.0285622924566269e-02
    z[2,5,2]  R1632     0.414943665266037
    z[2,5,2]  R1633     5.8672297000885010e-01
    z[2,5,2]  R1634     2.3136354982852936e-01
    z[2,5,2]  R1635     1.4333082363009453e-02
    z[2,5,2]  R1636     -6.9514997303485870e-02
    z[2,5,2]  R1637     6.2856063246726990e-02
    z[2,5,2]  R1638     -1.0920436121523380e-02
    z[2,5,2]  R1639     -1.6482889652252197e-01
    z[2,5,2]  R1640     -2.2052787244319916e-01
    z[2,5,2]  R1641     2.8026327490806580e-01
    z[2,5,2]  R1642     -5.4155772924423218e-01
    z[2,5,2]  R1643     -7.0680916309356689e-02
    z[2,5,2]  R1644     5.5067712068557739e-01
    z[2,5,2]  R1645     5.8514326810836792e-01
    z[2,5,2]  R1646     -1.2060177326202393e-01
    z[2,5,2]  R1647     2.7306309342384338e-01
    z[2,5,2]  R1648     1.7790491878986359e-01
    z[2,5,2]  R1649     1.7285411059856415e-01
    z[2,5,2]  R1650     0.066475510597229
    z[2,5,2]  R1651     -7.4864178895950317e-02
    z[2,5,2]  R1652     4.6833685040473938e-01
    z[2,5,2]  R1653     -1.3634940981864929e-01
    z[2,5,2]  R1654     1.3863706588745117e-01
    z[2,5,2]  R1655     1.1819404549896717e-02
    z[2,5,2]  R1656     0.0176091231405735
    z[2,5,2]  R1657     3.2341757416725159e-01
    z[2,5,2]  R1658     -1.7685323953628540e-01
    z[2,5,2]  R1659     1.3034267723560333e-01
    z[2,5,2]  R1660     -0.084355928003788
    z[2,5,2]  R1661     4.3649849295616150e-01
    z[2,5,3]  R23       -1
    z[2,5,3]  R50       1
    z[2,5,3]  R1504     -1
    z[2,5,3]  R1505     1
    z[2,5,3]  R1512     -4.9738347530364990e-01
    z[2,5,3]  R1513     -4.9407455325126648e-01
    z[2,5,3]  R1514     -3.8313293457031250e-01
    z[2,5,3]  R1515     -6.3725954294204712e-01
    z[2,5,3]  R1516     -3.1108251214027405e-01
    z[2,5,3]  R1517     -3.7824982404708862e-01
    z[2,5,3]  R1518     -3.9815476536750793e-01
    z[2,5,3]  R1519     -3.7539014220237732e-01
    z[2,5,3]  R1520     -6.8444848060607910e-01
    z[2,5,3]  R1521     -4.8272785544395447e-01
    z[2,5,3]  R1522     4.8311153054237366e-01
    z[2,5,3]  R1523     5.9779763221740723e-01
    z[2,5,3]  R1524     6.4269524812698364e-01
    z[2,5,3]  R1525     6.1657619476318359e-01
    z[2,5,3]  R1526     3.2699123024940491e-01
    z[2,5,3]  R1527     5.1298719644546509e-01
    z[2,5,3]  R1528     4.0008780360221863e-01
    z[2,5,3]  R1529     6.0585594177246094e-01
    z[2,5,3]  R1530     3.9594307541847229e-01
    z[2,5,3]  R1531     4.2353931069374084e-01
    z[2,5,3]  R1532     -4.3787723779678345e-01
    z[2,5,3]  R1533     5.4378788918256760e-02
    z[2,5,3]  R1534     4.1932079195976257e-01
    z[2,5,3]  R1535     -2.0981330424547195e-02
    z[2,5,3]  R1536     -1.5364332357421517e-03
    z[2,5,3]  R1537     1.3689659535884857e-01
    z[2,5,3]  R1538     -9.2429459095001221e-02
    z[2,5,3]  R1539     -3.2372960448265076e-01
    z[2,5,3]  R1540     -1.2386822700500488e-01
    z[2,5,3]  R1541     3.1529575586318970e-01
    z[2,5,3]  R1542     2.3897531628608704e-01
    z[2,5,3]  R1543     -3.3361229300498962e-01
    z[2,5,3]  R1544     -0.145788311958313
    z[2,5,3]  R1545     -1.4089332520961761e-01
    z[2,5,3]  R1546     2.6580068469047546e-01
    z[2,5,3]  R1547     2.7467063069343567e-01
    z[2,5,3]  R1548     3.5498273372650146e-01
    z[2,5,3]  R1549     -3.6747679114341736e-02
    z[2,5,3]  R1550     4.0764799714088440e-01
    z[2,5,3]  R1551     5.6897927075624466e-02
    z[2,5,3]  R1552     -4.8815658688545227e-01
    z[2,5,3]  R1553     -7.2577714920043945e-01
    z[2,5,3]  R1554     2.6660218834877014e-01
    z[2,5,3]  R1555     2.3126375675201416e-01
    z[2,5,3]  R1556     5.9364604949951172e-01
    z[2,5,3]  R1557     -1.8681989610195160e-01
    z[2,5,3]  R1558     -4.3784928321838379e-01
    z[2,5,3]  R1559     -1.2139679491519928e-01
    z[2,5,3]  R1560     -2.9585435986518860e-02
    z[2,5,3]  R1561     -3.0198785662651062e-01
    z[2,5,3]  R1562     -5.2362877130508423e-01
    z[2,5,3]  R1563     9.5383845269680023e-02
    z[2,5,3]  R1564     1.9987209141254425e-01
    z[2,5,3]  R1565     1.3164575397968292e-01
    z[2,5,3]  R1566     4.9316713213920593e-01
    z[2,5,3]  R1567     1.6954675316810608e-02
    z[2,5,3]  R1568     -2.6575639843940735e-01
    z[2,5,3]  R1569     -1.7028152942657471e-01
    z[2,5,3]  R1570     -5.0227010250091553e-01
    z[2,5,3]  R1571     -2.0487660169601440e-01
    z[2,5,3]  R1572     -5.2006644010543823e-01
    z[2,5,3]  R1573     0.206911101937294
    z[2,5,3]  R1574     8.8795311748981476e-02
    z[2,5,3]  R1575     3.2202258706092834e-01
    z[2,5,3]  R1576     -0.298666775226593
    z[2,5,3]  R1577     1.9712407886981964e-01
    z[2,5,3]  R1578     3.5539147257804871e-01
    z[2,5,3]  R1579     4.5797824859619141e-01
    z[2,5,3]  R1580     4.5064017176628113e-01
    z[2,5,3]  R1581     0.621365487575531
    z[2,5,3]  R1582     0.560824453830719
    z[2,5,3]  R1583     6.2672692537307739e-01
    z[2,5,3]  R1584     4.7803124785423279e-01
    z[2,5,3]  R1585     5.6229436397552490e-01
    z[2,5,3]  R1586     4.3165174126625061e-01
    z[2,5,3]  R1587     7.4449107050895691e-02
    z[2,5,3]  R1588     6.2117725610733032e-01
    z[2,5,3]  R1589     0.626302182674408
    z[2,5,3]  R1590     5.6914603710174561e-01
    z[2,5,3]  R1591     5.6571489572525024e-01
    z[2,5,3]  R1592     -1.4441484212875366e-01
    z[2,5,3]  R1593     -7.7496908605098724e-02
    z[2,5,3]  R1594     -2.6442435383796692e-01
    z[2,5,3]  R1595     -4.8002207279205322e-01
    z[2,5,3]  R1596     -4.4360291957855225e-01
    z[2,5,3]  R1597     -2.1171808242797852e-01
    z[2,5,3]  R1598     -3.5463970899581909e-01
    z[2,5,3]  R1599     -2.1362021565437317e-01
    z[2,5,3]  R1600     -3.4828168153762817e-01
    z[2,5,3]  R1601     -4.6822601556777954e-01
    z[2,5,3]  R1602     -3.6039733886718750e-01
    z[2,5,3]  R1603     -4.6259489655494690e-01
    z[2,5,3]  R1604     -3.3161154389381409e-01
    z[2,5,3]  R1605     -4.0480870008468628e-01
    z[2,5,3]  R1606     -3.9341679215431213e-01
    z[2,5,3]  R1607     -4.7615250945091248e-01
    z[2,5,3]  R1608     -5.3505256772041321e-02
    z[2,5,3]  R1609     -1.6752177476882935e-01
    z[2,5,3]  R1610     -1.6175325214862823e-01
    z[2,5,3]  R1611     -1.7537190020084381e-01
    z[2,5,3]  R1612     -3.8207793235778809e-01
    z[2,5,3]  R1613     -3.5980913043022156e-01
    z[2,5,3]  R1614     -2.4678030610084534e-01
    z[2,5,3]  R1615     -2.0257394015789032e-01
    z[2,5,3]  R1616     -2.3464618623256683e-01
    z[2,5,3]  R1617     -2.1929797530174255e-01
    z[2,5,3]  R1618     -2.0114910602569580e-01
    z[2,5,3]  R1619     -8.3379305899143219e-02
    z[2,5,3]  R1620     -2.5607371330261230e-01
    z[2,5,3]  R1621     1.4335356652736664e-01
    z[2,5,3]  R1622     -4.4107311964035034e-01
    z[2,5,3]  R1623     1.2474588304758072e-01
    z[2,5,3]  R1624     1.5756097435951233e-01
    z[2,5,3]  R1625     3.0503696203231812e-01
    z[2,5,3]  R1626     -5.3937506675720215e-01
    z[2,5,3]  R1627     2.5046974420547485e-01
    z[2,5,3]  R1628     2.8962868452072144e-01
    z[2,5,3]  R1629     -6.2990888953208923e-02
    z[2,5,3]  R1630     3.1556281447410583e-01
    z[2,5,3]  R1631     3.2318988442420959e-01
    z[2,5,3]  R1632     -3.2534915208816528e-01
    z[2,5,3]  R1633     -5.1158469915390015e-01
    z[2,5,3]  R1634     -5.4444450139999390e-01
    z[2,5,3]  R1635     1.1107818782329559e-01
    z[2,5,3]  R1636     -3.8976454734802246e-01
    z[2,5,3]  R1637     3.8681519031524658e-01
    z[2,5,3]  R1638     2.7715355157852173e-01
    z[2,5,3]  R1639     -4.7014206647872925e-02
    z[2,5,3]  R1640     1.9265557825565338e-01
    z[2,5,3]  R1641     -8.7753236293792725e-01
    z[2,5,3]  R1642     1.5672484040260315e-01
    z[2,5,3]  R1643     2.4916955828666687e-01
    z[2,5,3]  R1644     -3.6101886630058289e-01
    z[2,5,3]  R1645     -5.2012687921524048e-01
    z[2,5,3]  R1646     7.0098556578159332e-02
    z[2,5,3]  R1647     -5.2916455268859863e-01
    z[2,5,3]  R1648     -7.9334115982055664e-01
    z[2,5,3]  R1649     -9.6878513693809509e-02
    z[2,5,3]  R1650     -7.8511595726013184e-01
    z[2,5,3]  R1651     -6.5803134441375732e-01
    z[2,5,3]  R1652     -5.4513007402420044e-01
    z[2,5,3]  R1653     -0.655022382736206
    z[2,5,3]  R1654     -8.1561261415481567e-01
    z[2,5,3]  R1655     -1.9730459153652191e-01
    z[2,5,3]  R1656     -7.1871173381805420e-01
    z[2,5,3]  R1657     -7.6846402883529663e-01
    z[2,5,3]  R1658     -9.5163661241531372e-01
    z[2,5,3]  R1659     -7.2710955142974854e-01
    z[2,5,3]  R1660     -2.7952216565608978e-02
    z[2,5,3]  R1661     -2.4547162652015686e-01
    z[2,5,4]  R24       -1
    z[2,5,4]  R51       1
    z[2,5,4]  R1506     -1
    z[2,5,4]  R1507     1
    z[2,5,4]  R1512     7.4108898639678955e-02
    z[2,5,4]  R1513     4.5411086082458496e-01
    z[2,5,4]  R1514     -7.7939257025718689e-02
    z[2,5,4]  R1515     2.5241702795028687e-02
    z[2,5,4]  R1516     -3.1280061602592468e-01
    z[2,5,4]  R1517     -0.197514608502388
    z[2,5,4]  R1518     1.8651725351810455e-01
    z[2,5,4]  R1519     3.4524840116500854e-01
    z[2,5,4]  R1520     -2.2133202850818634e-01
    z[2,5,4]  R1521     -9.4200141727924347e-02
    z[2,5,4]  R1522     2.0341378450393677e-01
    z[2,5,4]  R1523     8.9632213115692139e-02
    z[2,5,4]  R1524     2.4004580453038216e-02
    z[2,5,4]  R1525     2.9950913786888123e-01
    z[2,5,4]  R1526     2.2722056508064270e-01
    z[2,5,4]  R1527     -2.3124359548091888e-01
    z[2,5,4]  R1528     4.8136554658412933e-02
    z[2,5,4]  R1529     5.7331800460815430e-02
    z[2,5,4]  R1530     -2.1913222968578339e-01
    z[2,5,4]  R1531     5.3543031215667725e-01
    z[2,5,4]  R1532     -2.0215612649917603e-01
    z[2,5,4]  R1533     3.6794430017471313e-01
    z[2,5,4]  R1534     -2.8205132484436035e-01
    z[2,5,4]  R1535     -8.9348025619983673e-02
    z[2,5,4]  R1536     2.6865644380450249e-02
    z[2,5,4]  R1537     -1.1009267531335354e-02
    z[2,5,4]  R1538     3.2222609966993332e-02
    z[2,5,4]  R1539     -8.0519765615463257e-02
    z[2,5,4]  R1540     3.7069308757781982e-01
    z[2,5,4]  R1541     1.7405509948730469e-01
    z[2,5,4]  R1542     3.0431419610977173e-01
    z[2,5,4]  R1543     -8.5079200565814972e-02
    z[2,5,4]  R1544     7.2199290990829468e-01
    z[2,5,4]  R1545     3.3194559812545776e-01
    z[2,5,4]  R1546     1.6605427861213684e-01
    z[2,5,4]  R1547     1.8416607752442360e-02
    z[2,5,4]  R1548     -2.2175459563732147e-01
    z[2,5,4]  R1549     4.2684939503669739e-01
    z[2,5,4]  R1550     -2.6789689064025879e-01
    z[2,5,4]  R1551     3.8038060069084167e-01
    z[2,5,4]  R1552     -3.3481433987617493e-01
    z[2,5,4]  R1553     -2.6730507612228394e-02
    z[2,5,4]  R1554     -7.6060421764850616e-02
    z[2,5,4]  R1555     4.3052637577056885e-01
    z[2,5,4]  R1556     3.3167313784360886e-02
    z[2,5,4]  R1557     3.9344325661659241e-01
    z[2,5,4]  R1558     1.6735710203647614e-01
    z[2,5,4]  R1559     1.4674863219261169e-01
    z[2,5,4]  R1560     1.9643607735633850e-01
    z[2,5,4]  R1561     2.4451376497745514e-01
    z[2,5,4]  R1562     -2.8217095136642456e-01
    z[2,5,4]  R1563     4.3291813135147095e-01
    z[2,5,4]  R1564     6.5028005838394165e-01
    z[2,5,4]  R1565     -6.1785720288753510e-02
    z[2,5,4]  R1566     2.3512113094329834e-01
    z[2,5,4]  R1567     -6.0237981379032135e-02
    z[2,5,4]  R1568     8.2637047767639160e-01
    z[2,5,4]  R1569     6.9821491837501526e-02
    z[2,5,4]  R1570     7.6107615232467651e-01
    z[2,5,4]  R1571     6.2636291980743408e-01
    z[2,5,4]  R1572     6.4324772357940674e-01
    z[2,5,4]  R1573     3.2327157258987427e-01
    z[2,5,4]  R1574     1.6144491732120514e-01
    z[2,5,4]  R1575     5.3124237060546875e-01
    z[2,5,4]  R1576     7.2016930580139160e-01
    z[2,5,4]  R1577     -1.0330962389707565e-01
    z[2,5,4]  R1578     1.6766072809696198e-01
    z[2,5,4]  R1579     5.5407159030437469e-02
    z[2,5,4]  R1580     -4.9126887321472168e-01
    z[2,5,4]  R1581     4.8064431548118591e-01
    z[2,5,4]  R1582     1.5356155112385750e-02
    z[2,5,4]  R1583     -0.0917850136756897
    z[2,5,4]  R1584     7.6447036117315292e-03
    z[2,5,4]  R1585     4.8172643780708313e-01
    z[2,5,4]  R1586     3.1640896201133728e-01
    z[2,5,4]  R1587     3.9022436738014221e-01
    z[2,5,4]  R1588     2.5093179941177368e-01
    z[2,5,4]  R1589     1.8925313651561737e-01
    z[2,5,4]  R1590     1.0541664063930511e-01
    z[2,5,4]  R1591     1.1602368950843811e-01
    z[2,5,4]  R1592     -1.9468156993389130e-01
    z[2,5,4]  R1593     -1.3204167783260345e-01
    z[2,5,4]  R1594     -1.7216181382536888e-02
    z[2,5,4]  R1595     3.7903830409049988e-02
    z[2,5,4]  R1596     -0.0446300208568573
    z[2,5,4]  R1597     2.8981253504753113e-01
    z[2,5,4]  R1598     -3.0714502930641174e-01
    z[2,5,4]  R1599     2.1726517379283905e-01
    z[2,5,4]  R1600     -8.0811433494091034e-02
    z[2,5,4]  R1601     -6.2830984592437744e-02
    z[2,5,4]  R1602     -5.6887006759643555e-01
    z[2,5,4]  R1603     -2.6850342750549316e-01
    z[2,5,4]  R1604     -2.6796698570251465e-01
    z[2,5,4]  R1605     -1.0614439845085144e-01
    z[2,5,4]  R1606     -1.9418950378894806e-01
    z[2,5,4]  R1607     1.1833731085062027e-02
    z[2,5,4]  R1608     -2.5105470418930054e-01
    z[2,5,4]  R1609     6.4505837857723236e-02
    z[2,5,4]  R1610     -1.9274080172181129e-02
    z[2,5,4]  R1611     -0.585271418094635
    z[2,5,4]  R1612     -5.0353991985321045e-01
    z[2,5,4]  R1613     -0.446170449256897
    z[2,5,4]  R1614     1.9488246738910675e-01
    z[2,5,4]  R1615     -5.4727095365524292e-01
    z[2,5,4]  R1616     -4.5689767599105835e-01
    z[2,5,4]  R1617     -4.6750482916831970e-01
    z[2,5,4]  R1618     2.2813653573393822e-02
    z[2,5,4]  R1619     -6.5138608217239380e-02
    z[2,5,4]  R1620     -3.0799213051795959e-01
    z[2,5,4]  R1621     -4.4952924363315105e-03
    z[2,5,4]  R1622     -3.4286966919898987e-01
    z[2,5,4]  R1623     1.4899596571922302e-01
    z[2,5,4]  R1624     1.6764806583523750e-02
    z[2,5,4]  R1625     2.8918796777725220e-01
    z[2,5,4]  R1626     1.6099166125059128e-02
    z[2,5,4]  R1627     -2.2511529922485352e-01
    z[2,5,4]  R1628     -1.0972981899976730e-01
    z[2,5,4]  R1629     3.7542146444320679e-01
    z[2,5,4]  R1630     -1.4024865627288818e-01
    z[2,5,4]  R1631     -3.3937383443117142e-02
    z[2,5,4]  R1632     -4.1775226593017578e-01
    z[2,5,4]  R1633     1.7556536197662354e-01
    z[2,5,4]  R1634     0.0706513300538063
    z[2,5,4]  R1635     -1.0516929626464844e-01
    z[2,5,4]  R1636     8.2739852368831635e-03
    z[2,5,4]  R1637     0.0567634291946888
    z[2,5,4]  R1638     1.4633840322494507e-01
    z[2,5,4]  R1639     3.4421750903129578e-01
    z[2,5,4]  R1640     0.0528845377266407
    z[2,5,4]  R1641     -3.5412866622209549e-02
    z[2,5,4]  R1642     -1.4077021181583405e-01
    z[2,5,4]  R1643     -7.4031746387481689e-01
    z[2,5,4]  R1644     3.5037645697593689e-01
    z[2,5,4]  R1645     3.5571921616792679e-02
    z[2,5,4]  R1646     5.6037232279777527e-03
    z[2,5,4]  R1647     2.2409898042678833e-01
    z[2,5,4]  R1648     -2.8389078378677368e-01
    z[2,5,4]  R1649     3.2641181349754333e-01
    z[2,5,4]  R1650     3.6762478947639465e-01
    z[2,5,4]  R1651     1.1520207673311234e-01
    z[2,5,4]  R1652     -1.6303323209285736e-01
    z[2,5,4]  R1653     -0.534935474395752
    z[2,5,4]  R1654     -1.7534036189317703e-02
    z[2,5,4]  R1655     1.9538573920726776e-02
    z[2,5,4]  R1656     -2.8727620840072632e-01
    z[2,5,4]  R1657     7.8169278800487518e-02
    z[2,5,4]  R1658     2.9616493731737137e-02
    z[2,5,4]  R1659     4.9636635184288025e-01
    z[2,5,4]  R1660     2.3595626652240753e-01
    z[2,5,4]  R1661     2.0990064740180969e-01
    z[2,5,5]  R25       -1
    z[2,5,5]  R52       1
    z[2,5,5]  R1508     -1
    z[2,5,5]  R1509     1
    z[2,5,5]  R1512     -2.5763321667909622e-02
    z[2,5,5]  R1513     1.1319072544574738e-01
    z[2,5,5]  R1514     -3.2504707574844360e-01
    z[2,5,5]  R1515     -5.9077125787734985e-01
    z[2,5,5]  R1516     -8.5536353290081024e-02
    z[2,5,5]  R1517     3.8181871175765991e-02
    z[2,5,5]  R1518     -1.5665654838085175e-01
    z[2,5,5]  R1519     -3.6032482981681824e-01
    z[2,5,5]  R1520     4.5826286077499390e-01
    z[2,5,5]  R1521     2.3778598010540009e-01
    z[2,5,5]  R1522     2.3975865915417671e-02
    z[2,5,5]  R1523     -1.9673697650432587e-01
    z[2,5,5]  R1524     -3.9418466389179230e-02
    z[2,5,5]  R1525     -1.0547454655170441e-01
    z[2,5,5]  R1526     -4.1495278477668762e-01
    z[2,5,5]  R1527     1.3072626292705536e-01
    z[2,5,5]  R1528     -2.0526649057865143e-01
    z[2,5,5]  R1529     -2.4558408558368683e-01
    z[2,5,5]  R1530     -1.0090753436088562e-01
    z[2,5,5]  R1531     -1.0786123573780060e-01
    z[2,5,5]  R1532     -2.7562916278839111e-01
    z[2,5,5]  R1533     0.073304183781147
    z[2,5,5]  R1534     0.0922246053814888
    z[2,5,5]  R1535     4.6109721064567566e-01
    z[2,5,5]  R1536     1.2221264094114304e-01
    z[2,5,5]  R1537     3.6499887704849243e-01
    z[2,5,5]  R1538     -3.2317012548446655e-01
    z[2,5,5]  R1539     7.0836436934769154e-03
    z[2,5,5]  R1540     1.2804001569747925e-01
    z[2,5,5]  R1541     5.4895699024200439e-01
    z[2,5,5]  R1542     2.7236780524253845e-01
    z[2,5,5]  R1543     -1.2452408671379089e-01
    z[2,5,5]  R1544     -6.5301053225994110e-02
    z[2,5,5]  R1545     4.3510493636131287e-01
    z[2,5,5]  R1546     -5.7376161217689514e-02
    z[2,5,5]  R1547     -1.8761390447616577e-01
    z[2,5,5]  R1548     -5.1306881010532379e-02
    z[2,5,5]  R1549     -3.3381082117557526e-02
    z[2,5,5]  R1550     -1.3989751040935516e-01
    z[2,5,5]  R1551     7.0005212910473347e-03
    z[2,5,5]  R1552     -3.5425817966461182e-01
    z[2,5,5]  R1553     2.6494054123759270e-02
    z[2,5,5]  R1554     4.0824812650680542e-01
    z[2,5,5]  R1555     1.4948236942291260e-01
    z[2,5,5]  R1556     -3.0073684453964233e-01
    z[2,5,5]  R1557     -1.9144824147224426e-01
    z[2,5,5]  R1558     2.0868784189224243e-01
    z[2,5,5]  R1559     -1.5906600281596184e-02
    z[2,5,5]  R1560     -2.2126603126525879e-01
    z[2,5,5]  R1561     4.2481872439384460e-01
    z[2,5,5]  R1562     -2.1682459115982056e-01
    z[2,5,5]  R1563     -2.3186743259429932e-01
    z[2,5,5]  R1564     1.1061707139015198e-01
    z[2,5,5]  R1565     1.7542797327041626e-01
    z[2,5,5]  R1566     -3.1311661005020142e-01
    z[2,5,5]  R1567     -2.8522959351539612e-01
    z[2,5,5]  R1568     3.5395030863583088e-03
    z[2,5,5]  R1569     2.9308724403381348e-01
    z[2,5,5]  R1570     1.7048075795173645e-02
    z[2,5,5]  R1571     -3.4903664141893387e-02
    z[2,5,5]  R1572     1.9971325993537903e-01
    z[2,5,5]  R1573     0.141094371676445
    z[2,5,5]  R1574     2.4412022903561592e-02
    z[2,5,5]  R1575     3.5019564628601074e-01
    z[2,5,5]  R1576     2.1683631464838982e-02
    z[2,5,5]  R1577     1.0498115420341492e-01
    z[2,5,5]  R1578     6.6231940872967243e-03
    z[2,5,5]  R1579     -2.3655049502849579e-01
    z[2,5,5]  R1580     -0.504997730255127
    z[2,5,5]  R1581     -2.6477809995412827e-02
    z[2,5,5]  R1582     -0.27354696393013
    z[2,5,5]  R1583     -2.5523068383336067e-02
    z[2,5,5]  R1584     9.2905461788177490e-02
    z[2,5,5]  R1585     -3.4722540527582169e-02
    z[2,5,5]  R1586     1.9602908194065094e-01
    z[2,5,5]  R1587     -3.6198985762894154e-03
    z[2,5,5]  R1588     -2.9300352931022644e-01
    z[2,5,5]  R1589     -5.6037425994873047e-01
    z[2,5,5]  R1590     3.3743798732757568e-01
    z[2,5,5]  R1591     -4.0920349955558777e-01
    z[2,5,5]  R1592     1.9935664534568787e-01
    z[2,5,5]  R1593     1.1492899060249329e-01
    z[2,5,5]  R1594     5.8168604969978333e-02
    z[2,5,5]  R1595     -1.5526196360588074e-01
    z[2,5,5]  R1596     1.9884844124317169e-01
    z[2,5,5]  R1597     -1.8055659532546997e-01
    z[2,5,5]  R1598     -1.2239484116435051e-02
    z[2,5,5]  R1599     -2.8148156404495239e-01
    z[2,5,5]  R1600     -2.3173154890537262e-01
    z[2,5,5]  R1601     -2.4595829844474792e-01
    z[2,5,5]  R1602     1.5505455434322357e-01
    z[2,5,5]  R1603     2.5466531515121460e-01
    z[2,5,5]  R1604     -2.3919600062072277e-03
    z[2,5,5]  R1605     3.3560761809349060e-01
    z[2,5,5]  R1606     4.0550000965595245e-02
    z[2,5,5]  R1607     1.2554794549942017e-01
    z[2,5,5]  R1608     1.9845777750015259e-01
    z[2,5,5]  R1609     0.188396617770195
    z[2,5,5]  R1610     3.7591537833213806e-01
    z[2,5,5]  R1611     1.6490317881107330e-01
    z[2,5,5]  R1612     -6.6061496734619141e-02
    z[2,5,5]  R1613     -4.3922942876815796e-01
    z[2,5,5]  R1614     -1.5732270479202271e-01
    z[2,5,5]  R1615     -5.5782753229141235e-01
    z[2,5,5]  R1616     3.1543437391519547e-02
    z[2,5,5]  R1617     1.6941666603088379e-01
    z[2,5,5]  R1618     1.2285882979631424e-01
    z[2,5,5]  R1619     7.1033620834350586e-01
    z[2,5,5]  R1620     4.4255855679512024e-01
    z[2,5,5]  R1621     -9.7863718867301941e-02
    z[2,5,5]  R1622     -1.5662544965744019e-01
    z[2,5,5]  R1623     -6.8838918209075928e-01
    z[2,5,5]  R1624     -1.7030051350593567e-01
    z[2,5,5]  R1625     -9.6369504928588867e-02
    z[2,5,5]  R1626     1.1636684834957123e-01
    z[2,5,5]  R1627     -5.4046493768692017e-01
    z[2,5,5]  R1628     -0.29739910364151
    z[2,5,5]  R1629     -2.8796562552452087e-01
    z[2,5,5]  R1630     0.449703186750412
    z[2,5,5]  R1631     2.3624885082244873e-01
    z[2,5,5]  R1632     3.7510338425636292e-01
    z[2,5,5]  R1633     -1.0032492876052856e-01
    z[2,5,5]  R1634     4.3588620424270630e-01
    z[2,5,5]  R1635     -3.6930760741233826e-01
    z[2,5,5]  R1636     0.152458056807518
    z[2,5,5]  R1637     -1.1823111772537231e-01
    z[2,5,5]  R1638     -3.2327221706509590e-03
    z[2,5,5]  R1639     1.3134506344795227e-01
    z[2,5,5]  R1640     -5.1871605217456818e-02
    z[2,5,5]  R1641     1.1105019599199295e-01
    z[2,5,5]  R1642     2.6202493906021118e-01
    z[2,5,5]  R1643     -1.7771621048450470e-01
    z[2,5,5]  R1644     0.144393190741539
    z[2,5,5]  R1645     1.5258552134037018e-01
    z[2,5,5]  R1646     1.6942301392555237e-01
    z[2,5,5]  R1647     1.9821600615978241e-01
    z[2,5,5]  R1648     -1.3792443275451660e-01
    z[2,5,5]  R1649     4.6606764197349548e-01
    z[2,5,5]  R1650     1.7696402966976166e-01
    z[2,5,5]  R1651     5.2001518011093140e-01
    z[2,5,5]  R1652     1.5033917129039764e-01
    z[2,5,5]  R1653     1.9275434315204620e-01
    z[2,5,5]  R1654     -7.8589223325252533e-02
    z[2,5,5]  R1655     -3.2607099413871765e-01
    z[2,5,5]  R1656     8.9479319751262665e-02
    z[2,5,5]  R1657     -1.1679124087095261e-01
    z[2,5,5]  R1658     1.3712685555219650e-02
    z[2,5,5]  R1659     -7.9214125871658325e-02
    z[2,5,5]  R1660     -8.7641589343547821e-02
    z[2,5,5]  R1661     -1.5276958048343658e-01
    z[2,5,6]  R26       -1
    z[2,5,6]  R53       1
    z[2,5,6]  R1510     -1
    z[2,5,6]  R1511     1
    z[2,5,6]  R1512     -5.2041497081518173e-02
    z[2,5,6]  R1513     2.6563179492950439e-01
    z[2,5,6]  R1514     1.2247455865144730e-01
    z[2,5,6]  R1515     -2.9744941741228104e-02
    z[2,5,6]  R1516     -1.7013169825077057e-01
    z[2,5,6]  R1517     -3.5226354002952576e-01
    z[2,5,6]  R1518     -3.1037840247154236e-01
    z[2,5,6]  R1519     -2.2379522025585175e-01
    z[2,5,6]  R1520     4.9815565347671509e-02
    z[2,5,6]  R1521     6.5397346019744873e-01
    z[2,5,6]  R1522     1.7376956343650818e-01
    z[2,5,6]  R1523     3.9379266090691090e-03
    z[2,5,6]  R1524     8.5842885076999664e-02
    z[2,5,6]  R1525     5.0171691924333572e-02
    z[2,5,6]  R1526     -2.0933536812663078e-02
    z[2,5,6]  R1527     -5.0253149121999741e-02
    z[2,5,6]  R1528     2.9349419474601746e-01
    z[2,5,6]  R1529     2.8682306408882141e-01
    z[2,5,6]  R1530     -1.9491675496101379e-01
    z[2,5,6]  R1531     -3.3388055860996246e-02
    z[2,5,6]  R1532     -1.3035708665847778e-01
    z[2,5,6]  R1533     -3.4366950392723083e-01
    z[2,5,6]  R1534     9.2071019113063812e-02
    z[2,5,6]  R1535     -1.1393783241510391e-01
    z[2,5,6]  R1536     8.2571931183338165e-02
    z[2,5,6]  R1537     -3.6306026577949524e-01
    z[2,5,6]  R1538     8.3058521151542664e-02
    z[2,5,6]  R1539     1.4299200847744942e-02
    z[2,5,6]  R1540     4.2816221714019775e-01
    z[2,5,6]  R1541     3.4252646565437317e-01
    z[2,5,6]  R1542     -1.8468311429023743e-01
    z[2,5,6]  R1543     -4.3246969580650330e-01
    z[2,5,6]  R1544     6.2741570174694061e-02
    z[2,5,6]  R1545     -5.8201032876968384e-01
    z[2,5,6]  R1546     1.0211148113012314e-01
    z[2,5,6]  R1547     -2.6464468240737915e-01
    z[2,5,6]  R1548     5.3623810410499573e-02
    z[2,5,6]  R1549     4.9583610892295837e-01
    z[2,5,6]  R1550     1.6540125012397766e-01
    z[2,5,6]  R1551     -2.4010688066482544e-01
    z[2,5,6]  R1552     3.7758362293243408e-01
    z[2,5,6]  R1553     -3.3995591104030609e-02
    z[2,5,6]  R1554     2.4440832436084747e-01
    z[2,5,6]  R1555     2.2488673031330109e-01
    z[2,5,6]  R1556     1.7554501071572304e-02
    z[2,5,6]  R1557     -5.4029554128646851e-01
    z[2,5,6]  R1558     -2.1544055640697479e-01
    z[2,5,6]  R1559     -4.4490674138069153e-01
    z[2,5,6]  R1560     5.8592408895492554e-01
    z[2,5,6]  R1561     -4.2189598083496094e-02
    z[2,5,6]  R1562     0.26277956366539
    z[2,5,6]  R1563     -1.5819574892520905e-01
    z[2,5,6]  R1564     6.4440146088600159e-02
    z[2,5,6]  R1565     -0.503376841545105
    z[2,5,6]  R1566     9.5405891537666321e-02
    z[2,5,6]  R1567     5.3170013427734375e-01
    z[2,5,6]  R1568     -3.4733593463897705e-01
    z[2,5,6]  R1569     1.4525157213211060e-01
    z[2,5,6]  R1570     -1.4669755101203918e-01
    z[2,5,6]  R1571     -3.0108600854873657e-01
    z[2,5,6]  R1572     -2.6337680220603943e-01
    z[2,5,6]  R1573     -1.4485427737236023e-01
    z[2,5,6]  R1574     4.2245812714099884e-02
    z[2,5,6]  R1575     8.5663706064224243e-02
    z[2,5,6]  R1576     -1.1631070822477341e-01
    z[2,5,6]  R1577     1.2773084640502930e-01
    z[2,5,6]  R1578     1.3055829703807831e-01
    z[2,5,6]  R1579     -1.3799254596233368e-01
    z[2,5,6]  R1580     -3.9727625250816345e-01
    z[2,5,6]  R1581     -1.6255301237106323e-01
    z[2,5,6]  R1582     1.2567305937409401e-02
    z[2,5,6]  R1583     -2.7718612551689148e-01
    z[2,5,6]  R1584     -2.9566511511802673e-01
    z[2,5,6]  R1585     3.4433576464653015e-01
    z[2,5,6]  R1586     5.5579822510480881e-02
    z[2,5,6]  R1587     -1.4310921728610992e-01
    z[2,5,6]  R1588     -1.1749270558357239e-01
    z[2,5,6]  R1589     -1.9455835223197937e-01
    z[2,5,6]  R1590     3.4837210178375244e-01
    z[2,5,6]  R1591     2.6342767477035522e-01
    z[2,5,6]  R1592     -4.6765303611755371e-01
    z[2,5,6]  R1593     -1.0650959610939026e-01
    z[2,5,6]  R1594     -1.9320906698703766e-01
    z[2,5,6]  R1595     1.5103018283843994e-01
    z[2,5,6]  R1596     -1.5218277275562286e-01
    z[2,5,6]  R1597     -2.6157429441809654e-02
    z[2,5,6]  R1598     -5.3551908582448959e-02
    z[2,5,6]  R1599     -3.7203781306743622e-02
    z[2,5,6]  R1600     -2.3170320689678192e-01
    z[2,5,6]  R1601     -1.9556893035769463e-02
    z[2,5,6]  R1602     1.0727799683809280e-01
    z[2,5,6]  R1603     3.3926871418952942e-01
    z[2,5,6]  R1604     -6.0322366654872894e-02
    z[2,5,6]  R1605     3.6199495196342468e-01
    z[2,5,6]  R1606     0.00312709528952837
    z[2,5,6]  R1607     -7.7364325523376465e-02
    z[2,5,6]  R1608     1.3736440241336823e-01
    z[2,5,6]  R1609     -2.8281034901738167e-03
    z[2,5,6]  R1610     1.7507965862751007e-01
    z[2,5,6]  R1611     2.0650139078497887e-02
    z[2,5,6]  R1612     4.1523313522338867e-01
    z[2,5,6]  R1613     -4.1135692596435547e-01
    z[2,5,6]  R1614     4.2290221899747849e-02
    z[2,5,6]  R1615     3.9515611529350281e-01
    z[2,5,6]  R1616     2.3404273390769958e-01
    z[2,5,6]  R1617     4.8952829092741013e-02
    z[2,5,6]  R1618     9.9118478596210480e-02
    z[2,5,6]  R1619     0.0359313040971756
    z[2,5,6]  R1620     4.5354613661766052e-01
    z[2,5,6]  R1621     -1.1205860227346420e-01
    z[2,5,6]  R1622     -3.9465554058551788e-02
    z[2,5,6]  R1623     3.7048763036727905e-01
    z[2,5,6]  R1624     -4.8416815698146820e-02
    z[2,5,6]  R1625     1.1586034297943115e-01
    z[2,5,6]  R1626     1.3355457782745361e-01
    z[2,5,6]  R1627     3.4233994781970978e-02
    z[2,5,6]  R1628     4.4190678745508194e-02
    z[2,5,6]  R1629     -3.3666866365820169e-03
    z[2,5,6]  R1630     2.9192259907722473e-01
    z[2,5,6]  R1631     -2.8641945123672485e-01
    z[2,5,6]  R1632     2.7961862087249756e-01
    z[2,5,6]  R1633     -2.1818424761295319e-01
    z[2,5,6]  R1634     1.6367980837821960e-01
    z[2,5,6]  R1635     1.7917476594448090e-01
    z[2,5,6]  R1636     -6.6021241247653961e-02
    z[2,5,6]  R1637     0.237451434135437
    z[2,5,6]  R1638     -1.2927031144499779e-02
    z[2,5,6]  R1639     3.5853590816259384e-02
    z[2,5,6]  R1640     -3.4651052951812744e-01
    z[2,5,6]  R1641     -0.0336323045194149
    z[2,5,6]  R1642     1.9779159128665924e-01
    z[2,5,6]  R1643     3.3439654111862183e-01
    z[2,5,6]  R1644     -3.0641382560133934e-02
    z[2,5,6]  R1645     1.1021838337182999e-01
    z[2,5,6]  R1646     4.5923396944999695e-01
    z[2,5,6]  R1647     8.8693335652351379e-02
    z[2,5,6]  R1648     -8.4558278322219849e-02
    z[2,5,6]  R1649     2.6078581809997559e-01
    z[2,5,6]  R1650     -4.6534806489944458e-02
    z[2,5,6]  R1651     1.0844473540782928e-01
    z[2,5,6]  R1652     1.2813293933868408e-01
    z[2,5,6]  R1653     -5.9406068176031113e-02
    z[2,5,6]  R1654     -3.6950135231018066e-01
    z[2,5,6]  R1655     4.1972849518060684e-02
    z[2,5,6]  R1656     -4.5489165186882019e-01
    z[2,5,6]  R1657     4.8335094004869461e-02
    z[2,5,6]  R1658     5.9358462691307068e-02
    z[2,5,6]  R1659     6.6626533865928650e-02
    z[2,5,6]  R1660     5.0326216220855713e-01
    z[2,5,6]  R1661     7.9438820481300354e-02
    z[5,2,0]  R20       1
    z[5,2,0]  R47       -1
    z[5,2,0]  R1662     -1
    z[5,2,0]  R1663     1
    z[5,2,0]  R1676     6.4572030305862427e-01
    z[5,2,0]  R1677     5.9248942136764526e-01
    z[5,2,0]  R1678     7.7949911355972290e-01
    z[5,2,0]  R1679     4.3592220544815063e-01
    z[5,2,0]  R1680     7.5880461931228638e-01
    z[5,2,0]  R1681     0.639691948890686
    z[5,2,0]  R1682     5.3148925304412842e-01
    z[5,2,0]  R1683     2.0234270393848419e-01
    z[5,2,0]  R1684     4.5358395576477051e-01
    z[5,2,0]  R1685     1.1968953907489777e-01
    z[5,2,0]  R1686     -4.3323707580566406e-01
    z[5,2,0]  R1687     2.5212273001670837e-01
    z[5,2,0]  R1688     2.6298072934150696e-01
    z[5,2,0]  R1689     1.1024408787488937e-01
    z[5,2,0]  R1690     -5.2712941169738770e-01
    z[5,2,0]  R1691     0.0764106810092926
    z[5,2,0]  R1692     1.2938044965267181e-01
    z[5,2,0]  R1693     1.4818756282329559e-01
    z[5,2,0]  R1694     1.3261912763118744e-01
    z[5,2,0]  R1695     0.0923101156949997
    z[5,2,0]  R1696     2.6949477195739746e-01
    z[5,2,0]  R1697     -6.9175457954406738e-01
    z[5,2,0]  R1698     -8.6974817514419556e-01
    z[5,2,0]  R1699     2.7312484383583069e-01
    z[5,2,0]  R1700     -8.7619078159332275e-01
    z[5,2,0]  R1701     -0.76837557554245
    z[5,2,0]  R1702     -8.9575308561325073e-01
    z[5,2,0]  R1703     3.4537902474403381e-01
    z[5,2,0]  R1704     -8.8181060552597046e-01
    z[5,2,0]  R1705     -7.6651340723037720e-01
    z[5,2,0]  R1706     2.6273876428604126e-01
    z[5,2,0]  R1707     2.1442225202918053e-02
    z[5,2,0]  R1708     -5.0709646940231323e-01
    z[5,2,0]  R1709     -6.8957008421421051e-02
    z[5,2,0]  R1710     -6.5651647746562958e-02
    z[5,2,0]  R1711     -0.276305615901947
    z[5,2,0]  R1712     4.8680922389030457e-01
    z[5,2,0]  R1713     -1.8024887144565582e-01
    z[5,2,0]  R1714     -9.4130545854568481e-02
    z[5,2,0]  R1715     3.1457754969596863e-01
    z[5,2,0]  R1716     4.1230636835098267e-01
    z[5,2,0]  R1717     -2.1953971683979034e-01
    z[5,2,0]  R1718     -6.0983443260192871e-01
    z[5,2,0]  R1719     1.5954670310020447e-01
    z[5,2,0]  R1720     -8.1131941080093384e-01
    z[5,2,0]  R1721     6.5042026340961456e-02
    z[5,2,0]  R1722     -8.1532442569732666e-01
    z[5,2,0]  R1723     -7.0960956811904907e-01
    z[5,2,0]  R1724     0.0046690390445292
    z[5,2,0]  R1725     -7.8674578666687012e-01
    z[5,2,0]  R1726     3.9653930068016052e-01
    z[5,2,0]  R1727     -2.1907810121774673e-02
    z[5,2,0]  R1728     -2.9042005538940430e-01
    z[5,2,0]  R1729     2.8162726759910583e-01
    z[5,2,0]  R1730     -8.9192312955856323e-01
    z[5,2,0]  R1731     -3.7026621401309967e-02
    z[5,2,0]  R1732     -8.2801800966262817e-01
    z[5,2,0]  R1733     -8.0668920278549194e-01
    z[5,2,0]  R1734     -0.774544894695282
    z[5,2,0]  R1735     -1.6462604701519012e-01
    z[5,2,0]  R1736     1.5975052118301392e-01
    z[5,2,0]  R1737     -1.0059801489114761e-01
    z[5,2,0]  R1738     -1.3567447662353516e-01
    z[5,2,0]  R1739     2.2019736468791962e-01
    z[5,2,0]  R1740     3.0585357546806335e-01
    z[5,2,0]  R1741     -8.1261835992336273e-02
    z[5,2,0]  R1742     -4.8062843084335327e-01
    z[5,2,0]  R1743     0.339558869600296
    z[5,2,0]  R1744     4.1992641985416412e-02
    z[5,2,0]  R1745     9.0691335499286652e-02
    z[5,2,0]  R1746     2.0195426046848297e-01
    z[5,2,0]  R1747     -4.5795783400535583e-01
    z[5,2,0]  R1748     -5.0490312278270721e-02
    z[5,2,0]  R1749     -8.3322483301162720e-01
    z[5,2,0]  R1750     -3.7403514981269836e-01
    z[5,2,0]  R1751     -4.0900033712387085e-01
    z[5,2,0]  R1752     8.3096392452716827e-02
    z[5,2,0]  R1753     -2.1625292301177979e-01
    z[5,2,0]  R1754     -7.3570340871810913e-01
    z[5,2,0]  R1755     -6.4198029041290283e-01
    z[5,2,0]  R1756     3.7873715162277222e-01
    z[5,2,0]  R1757     5.3333443403244019e-01
    z[5,2,0]  R1758     6.8667048215866089e-01
    z[5,2,0]  R1759     -1.4450901746749878e-01
    z[5,2,0]  R1760     6.8553018569946289e-01
    z[5,2,0]  R1761     6.5093624591827393e-01
    z[5,2,0]  R1762     7.6829367876052856e-01
    z[5,2,0]  R1763     5.8579719066619873e-01
    z[5,2,0]  R1764     -0.367805153131485
    z[5,2,0]  R1765     1.2440484762191772e-01
    z[5,2,0]  R1766     7.8678119182586670e-01
    z[5,2,0]  R1767     6.4782553911209106e-01
    z[5,2,0]  R1768     7.5260007381439209e-01
    z[5,2,0]  R1769     6.2868463993072510e-01
    z[5,2,0]  R1770     6.5628039836883545e-01
    z[5,2,0]  R1771     7.3745173215866089e-01
    z[5,2,0]  R1772     7.6738870143890381e-01
    z[5,2,0]  R1773     5.6793701648712158e-01
    z[5,2,0]  R1774     7.0700442790985107e-01
    z[5,2,0]  R1775     5.2821296453475952e-01
    z[5,2,0]  R1776     -5.5435019731521606e-01
    z[5,2,0]  R1777     -1.3739745318889618e-01
    z[5,2,0]  R1778     -2.4997992813587189e-01
    z[5,2,0]  R1779     -9.3141689896583557e-02
    z[5,2,0]  R1780     -3.6504247784614563e-01
    z[5,2,0]  R1781     -1.8392980098724365e-01
    z[5,2,0]  R1782     -2.9985910654067993e-01
    z[5,2,0]  R1783     -1.4240592718124390e-01
    z[5,2,0]  R1784     -1.1798799037933350e-01
    z[5,2,0]  R1785     -8.4018073976039886e-02
    z[5,2,0]  R1786     2.7113190293312073e-01
    z[5,2,0]  R1787     7.4907368421554565e-01
    z[5,2,0]  R1788     -6.4337062835693359e-01
    z[5,2,0]  R1789     5.5352133512496948e-01
    z[5,2,0]  R1790     -8.7810635566711426e-01
    z[5,2,0]  R1791     -8.5123598575592041e-01
    z[5,2,0]  R1792     -7.8212362527847290e-01
    z[5,2,0]  R1793     -7.1261632442474365e-01
    z[5,2,0]  R1794     -8.3282917737960815e-01
    z[5,2,0]  R1795     -8.2556849718093872e-01
    z[5,2,0]  R1796     -8.3808355033397675e-02
    z[5,2,0]  R1797     -6.3356541097164154e-02
    z[5,2,0]  R1798     1.9311730563640594e-01
    z[5,2,0]  R1799     1.9144977629184723e-01
    z[5,2,0]  R1800     -9.8120421171188354e-02
    z[5,2,0]  R1801     -6.7651188373565674e-01
    z[5,2,0]  R1802     7.1136116981506348e-01
    z[5,2,0]  R1803     5.4982852935791016e-01
    z[5,2,0]  R1804     -0.673531174659729
    z[5,2,0]  R1805     5.1509976387023926e-01
    z[5,2,0]  R1806     -5.5446839332580566e-01
    z[5,2,0]  R1807     -6.9315418601036072e-02
    z[5,2,0]  R1808     3.8593227509409189e-03
    z[5,2,0]  R1809     3.5450258851051331e-01
    z[5,2,0]  R1810     -1.2340407073497772e-01
    z[5,2,0]  R1811     -4.0811732411384583e-02
    z[5,2,0]  R1812     -2.8628918528556824e-01
    z[5,2,0]  R1813     4.2757335305213928e-01
    z[5,2,0]  R1814     -2.9277181625366211e-01
    z[5,2,0]  R1815     6.0205173492431641e-01
    z[5,2,0]  R1816     -4.4183117151260376e-01
    z[5,2,0]  R1817     3.0860555171966553e-01
    z[5,2,0]  R1818     -1.1031243205070496e-01
    z[5,2,0]  R1819     -1.3681454956531525e-01
    z[5,2,0]  R1820     5.8535623550415039e-01
    z[5,2,0]  R1821     -8.4071463346481323e-01
    z[5,2,0]  R1822     -7.9630863666534424e-01
    z[5,2,0]  R1823     -7.1491372585296631e-01
    z[5,2,0]  R1824     6.0217022895812988e-02
    z[5,2,0]  R1825     -1.7587128281593323e-01
    z[5,2,1]  R21       1
    z[5,2,1]  R48       -1
    z[5,2,1]  R1664     -1
    z[5,2,1]  R1665     1
    z[5,2,1]  R1676     -0.438917875289917
    z[5,2,1]  R1677     -3.9163279533386230e-01
    z[5,2,1]  R1678     -2.6016622781753540e-01
    z[5,2,1]  R1679     -3.7669035792350769e-01
    z[5,2,1]  R1680     -2.9924064874649048e-01
    z[5,2,1]  R1681     -5.9318101406097412e-01
    z[5,2,1]  R1682     -3.3125856518745422e-01
    z[5,2,1]  R1683     -3.1194382905960083e-01
    z[5,2,1]  R1684     -3.7661054730415344e-01
    z[5,2,1]  R1685     -4.1943570971488953e-01
    z[5,2,1]  R1686     -6.0823440551757812e-01
    z[5,2,1]  R1687     9.3426233530044556e-01
    z[5,2,1]  R1688     9.0262013673782349e-01
    z[5,2,1]  R1689     8.4135597944259644e-01
    z[5,2,1]  R1690     -6.0268962383270264e-01
    z[5,2,1]  R1691     9.1193181276321411e-01
    z[5,2,1]  R1692     8.6812484264373779e-01
    z[5,2,1]  R1693     0.893491804599762
    z[5,2,1]  R1694     8.6231881380081177e-01
    z[5,2,1]  R1695     8.3279460668563843e-01
    z[5,2,1]  R1696     -5.1101475954055786e-01
    z[5,2,1]  R1697     1.4255075156688690e-01
    z[5,2,1]  R1698     1.4731350541114807e-01
    z[5,2,1]  R1699     -4.5945802330970764e-01
    z[5,2,1]  R1700     1.0036489367485046e-01
    z[5,2,1]  R1701     1.6679603606462479e-02
    z[5,2,1]  R1702     1.0234550572931767e-02
    z[5,2,1]  R1703     3.0713167786598206e-01
    z[5,2,1]  R1704     1.4513903856277466e-01
    z[5,2,1]  R1705     5.6686513125896454e-02
    z[5,2,1]  R1706     -0.594928503036499
    z[5,2,1]  R1707     -0.537834644317627
    z[5,2,1]  R1708     -7.6466858386993408e-01
    z[5,2,1]  R1709     -4.1257899999618530e-01
    z[5,2,1]  R1710     -0.819805920124054
    z[5,2,1]  R1711     -7.8827476501464844e-01
    z[5,2,1]  R1712     2.5197806954383850e-01
    z[5,2,1]  R1713     -5.6327307224273682e-01
    z[5,2,1]  R1714     -5.7580155134201050e-01
    z[5,2,1]  R1715     0.877967894077301
    z[5,2,1]  R1716     -5.0431424379348755e-01
    z[5,2,1]  R1717     -2.3633006215095520e-01
    z[5,2,1]  R1718     -0.75218665599823
    z[5,2,1]  R1719     0.841509222984314
    z[5,2,1]  R1720     1.3649652898311615e-01
    z[5,2,1]  R1721     7.4180859327316284e-01
    z[5,2,1]  R1722     3.7573236227035522e-01
    z[5,2,1]  R1723     4.6993693709373474e-01
    z[5,2,1]  R1724     7.5818246603012085e-01
    z[5,2,1]  R1725     3.6967658996582031e-01
    z[5,2,1]  R1726     -4.1390848159790039e-01
    z[5,2,1]  R1727     -5.5232656002044678e-01
    z[5,2,1]  R1728     -5.8645367622375488e-01
    z[5,2,1]  R1729     0.853574812412262
    z[5,2,1]  R1730     1.4161099493503571e-01
    z[5,2,1]  R1731     8.7833267450332642e-01
    z[5,2,1]  R1732     4.6460762619972229e-01
    z[5,2,1]  R1733     4.2761087417602539e-01
    z[5,2,1]  R1734     4.3448188900947571e-01
    z[5,2,1]  R1735     3.3101415634155273e-01
    z[5,2,1]  R1736     -7.2734969854354858e-01
    z[5,2,1]  R1737     -4.8096224665641785e-01
    z[5,2,1]  R1738     -6.3518542051315308e-01
    z[5,2,1]  R1739     -0.549447774887085
    z[5,2,1]  R1740     8.0458915233612061e-01
    z[5,2,1]  R1741     7.3582708835601807e-01
    z[5,2,1]  R1742     -3.4479122608900070e-02
    z[5,2,1]  R1743     6.7354500293731689e-01
    z[5,2,1]  R1744     4.5692536234855652e-01
    z[5,2,1]  R1745     5.0765895843505859e-01
    z[5,2,1]  R1746     -6.1409157514572144e-01
    z[5,2,1]  R1747     -1.2565791606903076e-01
    z[5,2,1]  R1748     4.1230061650276184e-01
    z[5,2,1]  R1749     3.9774590730667114e-01
    z[5,2,1]  R1750     2.1396382153034210e-01
    z[5,2,1]  R1751     3.3984705805778503e-01
    z[5,2,1]  R1752     2.2719369828701019e-01
    z[5,2,1]  R1753     3.8789638876914978e-01
    z[5,2,1]  R1754     3.6635231971740723e-01
    z[5,2,1]  R1755     5.1319259405136108e-01
    z[5,2,1]  R1756     5.2845132350921631e-01
    z[5,2,1]  R1757     4.2615747451782227e-01
    z[5,2,1]  R1758     4.8639130592346191e-01
    z[5,2,1]  R1759     3.4531673789024353e-01
    z[5,2,1]  R1760     5.2249819040298462e-01
    z[5,2,1]  R1761     4.6735259890556335e-01
    z[5,2,1]  R1762     3.0830904841423035e-01
    z[5,2,1]  R1763     4.4670420885086060e-01
    z[5,2,1]  R1764     1.5149046480655670e-01
    z[5,2,1]  R1765     4.2348146438598633e-01
    z[5,2,1]  R1766     -3.6520402878522873e-02
    z[5,2,1]  R1767     -0.224799245595932
    z[5,2,1]  R1768     -1.0453260689973831e-01
    z[5,2,1]  R1769     -3.3511823415756226e-01
    z[5,2,1]  R1770     -4.3470478057861328e-01
    z[5,2,1]  R1771     -3.2897549867630005e-01
    z[5,2,1]  R1772     -2.3882986605167389e-01
    z[5,2,1]  R1773     -1.6404964029788971e-01
    z[5,2,1]  R1774     -1.0996983945369720e-01
    z[5,2,1]  R1775     -2.9862865805625916e-01
    z[5,2,1]  R1776     -5.4568356275558472e-01
    z[5,2,1]  R1777     -8.4708386659622192e-01
    z[5,2,1]  R1778     -8.1526309251785278e-01
    z[5,2,1]  R1779     -0.789399266242981
    z[5,2,1]  R1780     -7.7593863010406494e-01
    z[5,2,1]  R1781     -7.4482750892639160e-01
    z[5,2,1]  R1782     -8.4712529182434082e-01
    z[5,2,1]  R1783     -9.3157833814620972e-01
    z[5,2,1]  R1784     -7.7176654338836670e-01
    z[5,2,1]  R1785     -6.6648370027542114e-01
    z[5,2,1]  R1786     -6.1783152818679810e-01
    z[5,2,1]  R1787     -2.4491614103317261e-01
    z[5,2,1]  R1788     -1.6888128221035004e-01
    z[5,2,1]  R1789     -1.6578610241413116e-01
    z[5,2,1]  R1790     2.6889970898628235e-01
    z[5,2,1]  R1791     2.4984259903430939e-01
    z[5,2,1]  R1792     3.6712694168090820e-01
    z[5,2,1]  R1793     -1.5047702193260193e-01
    z[5,2,1]  R1794     1.4627382159233093e-01
    z[5,2,1]  R1795     3.1788122653961182e-01
    z[5,2,1]  R1796     -0.197486013174057
    z[5,2,1]  R1797     -3.3985349535942078e-01
    z[5,2,1]  R1798     -7.9830235242843628e-01
    z[5,2,1]  R1799     -6.9575464725494385e-01
    z[5,2,1]  R1800     -5.6621932983398438e-01
    z[5,2,1]  R1801     -1.0993305593729019e-01
    z[5,2,1]  R1802     -4.2058369517326355e-01
    z[5,2,1]  R1803     -3.0809995532035828e-01
    z[5,2,1]  R1804     -3.2287931442260742e-01
    z[5,2,1]  R1805     9.9301591515541077e-02
    z[5,2,1]  R1806     -1.1832910031080246e-01
    z[5,2,1]  R1807     -8.4441047906875610e-01
    z[5,2,1]  R1808     -7.1961444616317749e-01
    z[5,2,1]  R1809     -7.5381666421890259e-01
    z[5,2,1]  R1810     -6.3448148965835571e-01
    z[5,2,1]  R1811     -7.9383903741836548e-01
    z[5,2,1]  R1812     -5.0873693078756332e-02
    z[5,2,1]  R1813     -1.2915693223476410e-01
    z[5,2,1]  R1814     -2.4370776116847992e-01
    z[5,2,1]  R1815     6.2591084279119968e-03
    z[5,2,1]  R1816     7.5826406478881836e-02
    z[5,2,1]  R1817     -7.9278451204299927e-01
    z[5,2,1]  R1818     -8.7493056058883667e-01
    z[5,2,1]  R1819     -6.6701400279998779e-01
    z[5,2,1]  R1820     -1.5493483841419220e-01
    z[5,2,1]  R1821     4.1146323084831238e-01
    z[5,2,1]  R1822     1.9942082464694977e-01
    z[5,2,1]  R1823     4.1929177939891815e-02
    z[5,2,1]  R1824     -3.8080174475908279e-02
    z[5,2,1]  R1825     0.551843523979187
    z[5,2,2]  R22       1
    z[5,2,2]  R49       -1
    z[5,2,2]  R1666     -1
    z[5,2,2]  R1667     1
    z[5,2,2]  R1676     2.5509269908070564e-02
    z[5,2,2]  R1677     -1.2994299829006195e-01
    z[5,2,2]  R1678     0.00855214148759842
    z[5,2,2]  R1679     -8.2567613571882248e-03
    z[5,2,2]  R1680     -0.0819530263543129
    z[5,2,2]  R1681     -2.4621009826660156e-01
    z[5,2,2]  R1682     2.4352274835109711e-01
    z[5,2,2]  R1683     2.8601571917533875e-01
    z[5,2,2]  R1684     -2.8663319349288940e-01
    z[5,2,2]  R1685     4.8929706215858459e-01
    z[5,2,2]  R1686     3.5377609729766846e-01
    z[5,2,2]  R1687     -1.2487702071666718e-01
    z[5,2,2]  R1688     7.2028875350952148e-02
    z[5,2,2]  R1689     3.4526497125625610e-02
    z[5,2,2]  R1690     0.312128484249115
    z[5,2,2]  R1691     2.1002875640988350e-02
    z[5,2,2]  R1692     0.0805911272764206
    z[5,2,2]  R1693     -7.9114206135272980e-02
    z[5,2,2]  R1694     6.0015637427568436e-02
    z[5,2,2]  R1695     1.1777395755052567e-01
    z[5,2,2]  R1696     4.2093533277511597e-01
    z[5,2,2]  R1697     -1.8737387657165527e-01
    z[5,2,2]  R1698     -1.9083991646766663e-01
    z[5,2,2]  R1699     5.4359138011932373e-01
    z[5,2,2]  R1700     1.6755944490432739e-01
    z[5,2,2]  R1701     -4.0088900923728943e-01
    z[5,2,2]  R1702     -2.7087965607643127e-01
    z[5,2,2]  R1703     8.4773671627044678e-01
    z[5,2,2]  R1704     -5.3328428417444229e-02
    z[5,2,2]  R1705     -9.1249540448188782e-02
    z[5,2,2]  R1706     -2.6642715558409691e-02
    z[5,2,2]  R1707     -1.4002242684364319e-01
    z[5,2,2]  R1708     1.8087702989578247e-01
    z[5,2,2]  R1709     -1.3100315630435944e-01
    z[5,2,2]  R1710     6.3425756990909576e-02
    z[5,2,2]  R1711     0.0672854483127594
    z[5,2,2]  R1712     7.9600483179092407e-01
    z[5,2,2]  R1713     0.364924818277359
    z[5,2,2]  R1714     0.312404990196228
    z[5,2,2]  R1715     2.9581832885742188e-01
    z[5,2,2]  R1716     4.8731550574302673e-01
    z[5,2,2]  R1717     -4.9703961610794067e-01
    z[5,2,2]  R1718     -7.6577968895435333e-02
    z[5,2,2]  R1719     -2.5888085365295410e-01
    z[5,2,2]  R1720     2.3808078840374947e-02
    z[5,2,2]  R1721     -1.9698525965213776e-01
    z[5,2,2]  R1722     -8.8015489280223846e-02
    z[5,2,2]  R1723     -2.1856112778186798e-01
    z[5,2,2]  R1724     1.3577975332736969e-01
    z[5,2,2]  R1725     3.0285622924566269e-02
    z[5,2,2]  R1726     0.414943665266037
    z[5,2,2]  R1727     5.8672297000885010e-01
    z[5,2,2]  R1728     2.3136354982852936e-01
    z[5,2,2]  R1729     1.4333082363009453e-02
    z[5,2,2]  R1730     -6.9514997303485870e-02
    z[5,2,2]  R1731     6.2856063246726990e-02
    z[5,2,2]  R1732     -1.0920436121523380e-02
    z[5,2,2]  R1733     -1.6482889652252197e-01
    z[5,2,2]  R1734     -2.2052787244319916e-01
    z[5,2,2]  R1735     2.8026327490806580e-01
    z[5,2,2]  R1736     -5.4155772924423218e-01
    z[5,2,2]  R1737     -7.0680916309356689e-02
    z[5,2,2]  R1738     5.5067712068557739e-01
    z[5,2,2]  R1739     5.8514326810836792e-01
    z[5,2,2]  R1740     -1.2060177326202393e-01
    z[5,2,2]  R1741     2.7306309342384338e-01
    z[5,2,2]  R1742     1.7790491878986359e-01
    z[5,2,2]  R1743     1.7285411059856415e-01
    z[5,2,2]  R1744     0.066475510597229
    z[5,2,2]  R1745     -7.4864178895950317e-02
    z[5,2,2]  R1746     4.6833685040473938e-01
    z[5,2,2]  R1747     -1.3634940981864929e-01
    z[5,2,2]  R1748     1.3863706588745117e-01
    z[5,2,2]  R1749     1.1819404549896717e-02
    z[5,2,2]  R1750     0.0176091231405735
    z[5,2,2]  R1751     3.2341757416725159e-01
    z[5,2,2]  R1752     -1.7685323953628540e-01
    z[5,2,2]  R1753     1.3034267723560333e-01
    z[5,2,2]  R1754     -0.084355928003788
    z[5,2,2]  R1755     4.3649849295616150e-01
    z[5,2,2]  R1756     5.6660646200180054e-01
    z[5,2,2]  R1757     1.5669887885451317e-02
    z[5,2,2]  R1758     -1.3559582829475403e-01
    z[5,2,2]  R1759     3.2131153345108032e-01
    z[5,2,2]  R1760     1.6175954043865204e-01
    z[5,2,2]  R1761     -2.2412294149398804e-01
    z[5,2,2]  R1762     -2.1871482953429222e-02
    z[5,2,2]  R1763     -1.3139431178569794e-01
    z[5,2,2]  R1764     3.3440402150154114e-01
    z[5,2,2]  R1765     2.8118276596069336e-01
    z[5,2,2]  R1766     2.7220770716667175e-01
    z[5,2,2]  R1767     3.5450032353401184e-01
    z[5,2,2]  R1768     1.0474268347024918e-02
    z[5,2,2]  R1769     9.4537794589996338e-02
    z[5,2,2]  R1770     2.2170089185237885e-01
    z[5,2,2]  R1771     -1.0814710706472397e-01
    z[5,2,2]  R1772     -2.5182211399078369e-01
    z[5,2,2]  R1773     3.7095537781715393e-01
    z[5,2,2]  R1774     4.8485729098320007e-01
    z[5,2,2]  R1775     0.391141802072525
    z[5,2,2]  R1776     -2.6335790753364563e-01
    z[5,2,2]  R1777     4.1815541684627533e-02
    z[5,2,2]  R1778     2.2154621779918671e-02
    z[5,2,2]  R1779     3.6627537012100220e-01
    z[5,2,2]  R1780     4.9212306737899780e-01
    z[5,2,2]  R1781     3.5707566142082214e-01
    z[5,2,2]  R1782     2.6747745275497437e-01
    z[5,2,2]  R1783     -1.8532557412981987e-02
    z[5,2,2]  R1784     1.9488810002803802e-01
    z[5,2,2]  R1785     1.8859108909964561e-02
    z[5,2,2]  R1786     -5.3550285100936890e-01
    z[5,2,2]  R1787     -2.4048466980457306e-01
    z[5,2,2]  R1788     0.082611583173275
    z[5,2,2]  R1789     -8.9654371142387390e-02
    z[5,2,2]  R1790     -2.1137490868568420e-01
    z[5,2,2]  R1791     -1.7876550555229187e-01
    z[5,2,2]  R1792     -2.6982340216636658e-01
    z[5,2,2]  R1793     -1.9752517342567444e-01
    z[5,2,2]  R1794     -1.1177732609212399e-02
    z[5,2,2]  R1795     -1.0844890773296356e-01
    z[5,2,2]  R1796     -5.7923197746276855e-01
    z[5,2,2]  R1797     -5.9258836507797241e-01
    z[5,2,2]  R1798     1.4884649217128754e-01
    z[5,2,2]  R1799     -4.0928909182548523e-01
    z[5,2,2]  R1800     -4.7487002611160278e-01
    z[5,2,2]  R1801     1.0943194478750229e-01
    z[5,2,2]  R1802     8.5958667099475861e-02
    z[5,2,2]  R1803     -0.606873631477356
    z[5,2,2]  R1804     1.0186557471752167e-01
    z[5,2,2]  R1805     0.625761091709137
    z[5,2,2]  R1806     -4.5682549476623535e-01
    z[5,2,2]  R1807     -8.2836419343948364e-02
    z[5,2,2]  R1808     -5.4207291454076767e-02
    z[5,2,2]  R1809     2.7874214574694633e-02
    z[5,2,2]  R1810     -4.2019593715667725e-01
    z[5,2,2]  R1811     -1.3303663581609726e-02
    z[5,2,2]  R1812     2.0317737758159637e-01
    z[5,2,2]  R1813     8.1217640638351440e-01
    z[5,2,2]  R1814     -3.9600688964128494e-02
    z[5,2,2]  R1815     -3.3364436030387878e-01
    z[5,2,2]  R1816     -7.4472390115261078e-02
    z[5,2,2]  R1817     -2.9672920703887939e-01
    z[5,2,2]  R1818     -4.3127492070198059e-01
    z[5,2,2]  R1819     1.4311423897743225e-01
    z[5,2,2]  R1820     -1.0728116333484650e-01
    z[5,2,2]  R1821     -2.1686401963233948e-01
    z[5,2,2]  R1822     3.9321917295455933e-01
    z[5,2,2]  R1823     4.4646185636520386e-01
    z[5,2,2]  R1824     -3.7101346254348755e-01
    z[5,2,2]  R1825     1.4247593283653259e-01
    z[5,2,3]  R23       1
    z[5,2,3]  R50       -1
    z[5,2,3]  R1668     -1
    z[5,2,3]  R1669     1
    z[5,2,3]  R1676     0.560824453830719
    z[5,2,3]  R1677     6.2672692537307739e-01
    z[5,2,3]  R1678     4.7803124785423279e-01
    z[5,2,3]  R1679     5.6229436397552490e-01
    z[5,2,3]  R1680     4.3165174126625061e-01
    z[5,2,3]  R1681     7.4449107050895691e-02
    z[5,2,3]  R1682     6.2117725610733032e-01
    z[5,2,3]  R1683     0.626302182674408
    z[5,2,3]  R1684     5.6914603710174561e-01
    z[5,2,3]  R1685     5.6571489572525024e-01
    z[5,2,3]  R1686     -1.4441484212875366e-01
    z[5,2,3]  R1687     -7.7496908605098724e-02
    z[5,2,3]  R1688     -2.6442435383796692e-01
    z[5,2,3]  R1689     -4.8002207279205322e-01
    z[5,2,3]  R1690     -4.4360291957855225e-01
    z[5,2,3]  R1691     -2.1171808242797852e-01
    z[5,2,3]  R1692     -3.5463970899581909e-01
    z[5,2,3]  R1693     -2.1362021565437317e-01
    z[5,2,3]  R1694     -3.4828168153762817e-01
    z[5,2,3]  R1695     -4.6822601556777954e-01
    z[5,2,3]  R1696     -3.6039733886718750e-01
    z[5,2,3]  R1697     -4.6259489655494690e-01
    z[5,2,3]  R1698     -3.3161154389381409e-01
    z[5,2,3]  R1699     -4.0480870008468628e-01
    z[5,2,3]  R1700     -3.9341679215431213e-01
    z[5,2,3]  R1701     -4.7615250945091248e-01
    z[5,2,3]  R1702     -5.3505256772041321e-02
    z[5,2,3]  R1703     -1.6752177476882935e-01
    z[5,2,3]  R1704     -1.6175325214862823e-01
    z[5,2,3]  R1705     -1.7537190020084381e-01
    z[5,2,3]  R1706     -3.8207793235778809e-01
    z[5,2,3]  R1707     -3.5980913043022156e-01
    z[5,2,3]  R1708     -2.4678030610084534e-01
    z[5,2,3]  R1709     -2.0257394015789032e-01
    z[5,2,3]  R1710     -2.3464618623256683e-01
    z[5,2,3]  R1711     -2.1929797530174255e-01
    z[5,2,3]  R1712     -2.0114910602569580e-01
    z[5,2,3]  R1713     -8.3379305899143219e-02
    z[5,2,3]  R1714     -2.5607371330261230e-01
    z[5,2,3]  R1715     1.4335356652736664e-01
    z[5,2,3]  R1716     -4.4107311964035034e-01
    z[5,2,3]  R1717     1.2474588304758072e-01
    z[5,2,3]  R1718     1.5756097435951233e-01
    z[5,2,3]  R1719     3.0503696203231812e-01
    z[5,2,3]  R1720     -5.3937506675720215e-01
    z[5,2,3]  R1721     2.5046974420547485e-01
    z[5,2,3]  R1722     2.8962868452072144e-01
    z[5,2,3]  R1723     -6.2990888953208923e-02
    z[5,2,3]  R1724     3.1556281447410583e-01
    z[5,2,3]  R1725     3.2318988442420959e-01
    z[5,2,3]  R1726     -3.2534915208816528e-01
    z[5,2,3]  R1727     -5.1158469915390015e-01
    z[5,2,3]  R1728     -5.4444450139999390e-01
    z[5,2,3]  R1729     1.1107818782329559e-01
    z[5,2,3]  R1730     -3.8976454734802246e-01
    z[5,2,3]  R1731     3.8681519031524658e-01
    z[5,2,3]  R1732     2.7715355157852173e-01
    z[5,2,3]  R1733     -4.7014206647872925e-02
    z[5,2,3]  R1734     1.9265557825565338e-01
    z[5,2,3]  R1735     -8.7753236293792725e-01
    z[5,2,3]  R1736     1.5672484040260315e-01
    z[5,2,3]  R1737     2.4916955828666687e-01
    z[5,2,3]  R1738     -3.6101886630058289e-01
    z[5,2,3]  R1739     -5.2012687921524048e-01
    z[5,2,3]  R1740     7.0098556578159332e-02
    z[5,2,3]  R1741     -5.2916455268859863e-01
    z[5,2,3]  R1742     -7.9334115982055664e-01
    z[5,2,3]  R1743     -9.6878513693809509e-02
    z[5,2,3]  R1744     -7.8511595726013184e-01
    z[5,2,3]  R1745     -6.5803134441375732e-01
    z[5,2,3]  R1746     -5.4513007402420044e-01
    z[5,2,3]  R1747     -0.655022382736206
    z[5,2,3]  R1748     -8.1561261415481567e-01
    z[5,2,3]  R1749     -1.9730459153652191e-01
    z[5,2,3]  R1750     -7.1871173381805420e-01
    z[5,2,3]  R1751     -7.6846402883529663e-01
    z[5,2,3]  R1752     -9.5163661241531372e-01
    z[5,2,3]  R1753     -7.2710955142974854e-01
    z[5,2,3]  R1754     -2.7952216565608978e-02
    z[5,2,3]  R1755     -2.4547162652015686e-01
    z[5,2,3]  R1756     -4.9738347530364990e-01
    z[5,2,3]  R1757     -4.9407455325126648e-01
    z[5,2,3]  R1758     -3.8313293457031250e-01
    z[5,2,3]  R1759     -6.3725954294204712e-01
    z[5,2,3]  R1760     -3.1108251214027405e-01
    z[5,2,3]  R1761     -3.7824982404708862e-01
    z[5,2,3]  R1762     -3.9815476536750793e-01
    z[5,2,3]  R1763     -3.7539014220237732e-01
    z[5,2,3]  R1764     -6.8444848060607910e-01
    z[5,2,3]  R1765     -4.8272785544395447e-01
    z[5,2,3]  R1766     4.8311153054237366e-01
    z[5,2,3]  R1767     5.9779763221740723e-01
    z[5,2,3]  R1768     6.4269524812698364e-01
    z[5,2,3]  R1769     6.1657619476318359e-01
    z[5,2,3]  R1770     3.2699123024940491e-01
    z[5,2,3]  R1771     5.1298719644546509e-01
    z[5,2,3]  R1772     4.0008780360221863e-01
    z[5,2,3]  R1773     6.0585594177246094e-01
    z[5,2,3]  R1774     3.9594307541847229e-01
    z[5,2,3]  R1775     4.2353931069374084e-01
    z[5,2,3]  R1776     -4.3787723779678345e-01
    z[5,2,3]  R1777     5.4378788918256760e-02
    z[5,2,3]  R1778     4.1932079195976257e-01
    z[5,2,3]  R1779     -2.0981330424547195e-02
    z[5,2,3]  R1780     -1.5364332357421517e-03
    z[5,2,3]  R1781     1.3689659535884857e-01
    z[5,2,3]  R1782     -9.2429459095001221e-02
    z[5,2,3]  R1783     -3.2372960448265076e-01
    z[5,2,3]  R1784     -1.2386822700500488e-01
    z[5,2,3]  R1785     3.1529575586318970e-01
    z[5,2,3]  R1786     2.3897531628608704e-01
    z[5,2,3]  R1787     -3.3361229300498962e-01
    z[5,2,3]  R1788     -0.145788311958313
    z[5,2,3]  R1789     -1.4089332520961761e-01
    z[5,2,3]  R1790     2.6580068469047546e-01
    z[5,2,3]  R1791     2.7467063069343567e-01
    z[5,2,3]  R1792     3.5498273372650146e-01
    z[5,2,3]  R1793     -3.6747679114341736e-02
    z[5,2,3]  R1794     4.0764799714088440e-01
    z[5,2,3]  R1795     5.6897927075624466e-02
    z[5,2,3]  R1796     -4.8815658688545227e-01
    z[5,2,3]  R1797     -7.2577714920043945e-01
    z[5,2,3]  R1798     2.6660218834877014e-01
    z[5,2,3]  R1799     2.3126375675201416e-01
    z[5,2,3]  R1800     5.9364604949951172e-01
    z[5,2,3]  R1801     -1.8681989610195160e-01
    z[5,2,3]  R1802     -4.3784928321838379e-01
    z[5,2,3]  R1803     -1.2139679491519928e-01
    z[5,2,3]  R1804     -2.9585435986518860e-02
    z[5,2,3]  R1805     -3.0198785662651062e-01
    z[5,2,3]  R1806     -5.2362877130508423e-01
    z[5,2,3]  R1807     9.5383845269680023e-02
    z[5,2,3]  R1808     1.9987209141254425e-01
    z[5,2,3]  R1809     1.3164575397968292e-01
    z[5,2,3]  R1810     4.9316713213920593e-01
    z[5,2,3]  R1811     1.6954675316810608e-02
    z[5,2,3]  R1812     -2.6575639843940735e-01
    z[5,2,3]  R1813     -1.7028152942657471e-01
    z[5,2,3]  R1814     -5.0227010250091553e-01
    z[5,2,3]  R1815     -2.0487660169601440e-01
    z[5,2,3]  R1816     -5.2006644010543823e-01
    z[5,2,3]  R1817     0.206911101937294
    z[5,2,3]  R1818     8.8795311748981476e-02
    z[5,2,3]  R1819     3.2202258706092834e-01
    z[5,2,3]  R1820     -0.298666775226593
    z[5,2,3]  R1821     1.9712407886981964e-01
    z[5,2,3]  R1822     3.5539147257804871e-01
    z[5,2,3]  R1823     4.5797824859619141e-01
    z[5,2,3]  R1824     4.5064017176628113e-01
    z[5,2,3]  R1825     0.621365487575531
    z[5,2,4]  R24       1
    z[5,2,4]  R51       -1
    z[5,2,4]  R1670     -1
    z[5,2,4]  R1671     1
    z[5,2,4]  R1676     1.5356155112385750e-02
    z[5,2,4]  R1677     -0.0917850136756897
    z[5,2,4]  R1678     7.6447036117315292e-03
    z[5,2,4]  R1679     4.8172643780708313e-01
    z[5,2,4]  R1680     3.1640896201133728e-01
    z[5,2,4]  R1681     3.9022436738014221e-01
    z[5,2,4]  R1682     2.5093179941177368e-01
    z[5,2,4]  R1683     1.8925313651561737e-01
    z[5,2,4]  R1684     1.0541664063930511e-01
    z[5,2,4]  R1685     1.1602368950843811e-01
    z[5,2,4]  R1686     -1.9468156993389130e-01
    z[5,2,4]  R1687     -1.3204167783260345e-01
    z[5,2,4]  R1688     -1.7216181382536888e-02
    z[5,2,4]  R1689     3.7903830409049988e-02
    z[5,2,4]  R1690     -0.0446300208568573
    z[5,2,4]  R1691     2.8981253504753113e-01
    z[5,2,4]  R1692     -3.0714502930641174e-01
    z[5,2,4]  R1693     2.1726517379283905e-01
    z[5,2,4]  R1694     -8.0811433494091034e-02
    z[5,2,4]  R1695     -6.2830984592437744e-02
    z[5,2,4]  R1696     -5.6887006759643555e-01
    z[5,2,4]  R1697     -2.6850342750549316e-01
    z[5,2,4]  R1698     -2.6796698570251465e-01
    z[5,2,4]  R1699     -1.0614439845085144e-01
    z[5,2,4]  R1700     -1.9418950378894806e-01
    z[5,2,4]  R1701     1.1833731085062027e-02
    z[5,2,4]  R1702     -2.5105470418930054e-01
    z[5,2,4]  R1703     6.4505837857723236e-02
    z[5,2,4]  R1704     -1.9274080172181129e-02
    z[5,2,4]  R1705     -0.585271418094635
    z[5,2,4]  R1706     -5.0353991985321045e-01
    z[5,2,4]  R1707     -0.446170449256897
    z[5,2,4]  R1708     1.9488246738910675e-01
    z[5,2,4]  R1709     -5.4727095365524292e-01
    z[5,2,4]  R1710     -4.5689767599105835e-01
    z[5,2,4]  R1711     -4.6750482916831970e-01
    z[5,2,4]  R1712     2.2813653573393822e-02
    z[5,2,4]  R1713     -6.5138608217239380e-02
    z[5,2,4]  R1714     -3.0799213051795959e-01
    z[5,2,4]  R1715     -4.4952924363315105e-03
    z[5,2,4]  R1716     -3.4286966919898987e-01
    z[5,2,4]  R1717     1.4899596571922302e-01
    z[5,2,4]  R1718     1.6764806583523750e-02
    z[5,2,4]  R1719     2.8918796777725220e-01
    z[5,2,4]  R1720     1.6099166125059128e-02
    z[5,2,4]  R1721     -2.2511529922485352e-01
    z[5,2,4]  R1722     -1.0972981899976730e-01
    z[5,2,4]  R1723     3.7542146444320679e-01
    z[5,2,4]  R1724     -1.4024865627288818e-01
    z[5,2,4]  R1725     -3.3937383443117142e-02
    z[5,2,4]  R1726     -4.1775226593017578e-01
    z[5,2,4]  R1727     1.7556536197662354e-01
    z[5,2,4]  R1728     0.0706513300538063
    z[5,2,4]  R1729     -1.0516929626464844e-01
    z[5,2,4]  R1730     8.2739852368831635e-03
    z[5,2,4]  R1731     0.0567634291946888
    z[5,2,4]  R1732     1.4633840322494507e-01
    z[5,2,4]  R1733     3.4421750903129578e-01
    z[5,2,4]  R1734     0.0528845377266407
    z[5,2,4]  R1735     -3.5412866622209549e-02
    z[5,2,4]  R1736     -1.4077021181583405e-01
    z[5,2,4]  R1737     -7.4031746387481689e-01
    z[5,2,4]  R1738     3.5037645697593689e-01
    z[5,2,4]  R1739     3.5571921616792679e-02
    z[5,2,4]  R1740     5.6037232279777527e-03
    z[5,2,4]  R1741     2.2409898042678833e-01
    z[5,2,4]  R1742     -2.8389078378677368e-01
    z[5,2,4]  R1743     3.2641181349754333e-01
    z[5,2,4]  R1744     3.6762478947639465e-01
    z[5,2,4]  R1745     1.1520207673311234e-01
    z[5,2,4]  R1746     -1.6303323209285736e-01
    z[5,2,4]  R1747     -0.534935474395752
    z[5,2,4]  R1748     -1.7534036189317703e-02
    z[5,2,4]  R1749     1.9538573920726776e-02
    z[5,2,4]  R1750     -2.8727620840072632e-01
    z[5,2,4]  R1751     7.8169278800487518e-02
    z[5,2,4]  R1752     2.9616493731737137e-02
    z[5,2,4]  R1753     4.9636635184288025e-01
    z[5,2,4]  R1754     2.3595626652240753e-01
    z[5,2,4]  R1755     2.0990064740180969e-01
    z[5,2,4]  R1756     7.4108898639678955e-02
    z[5,2,4]  R1757     4.5411086082458496e-01
    z[5,2,4]  R1758     -7.7939257025718689e-02
    z[5,2,4]  R1759     2.5241702795028687e-02
    z[5,2,4]  R1760     -3.1280061602592468e-01
    z[5,2,4]  R1761     -0.197514608502388
    z[5,2,4]  R1762     1.8651725351810455e-01
    z[5,2,4]  R1763     3.4524840116500854e-01
    z[5,2,4]  R1764     -2.2133202850818634e-01
    z[5,2,4]  R1765     -9.4200141727924347e-02
    z[5,2,4]  R1766     2.0341378450393677e-01
    z[5,2,4]  R1767     8.9632213115692139e-02
    z[5,2,4]  R1768     2.4004580453038216e-02
    z[5,2,4]  R1769     2.9950913786888123e-01
    z[5,2,4]  R1770     2.2722056508064270e-01
    z[5,2,4]  R1771     -2.3124359548091888e-01
    z[5,2,4]  R1772     4.8136554658412933e-02
    z[5,2,4]  R1773     5.7331800460815430e-02
    z[5,2,4]  R1774     -2.1913222968578339e-01
    z[5,2,4]  R1775     5.3543031215667725e-01
    z[5,2,4]  R1776     -2.0215612649917603e-01
    z[5,2,4]  R1777     3.6794430017471313e-01
    z[5,2,4]  R1778     -2.8205132484436035e-01
    z[5,2,4]  R1779     -8.9348025619983673e-02
    z[5,2,4]  R1780     2.6865644380450249e-02
    z[5,2,4]  R1781     -1.1009267531335354e-02
    z[5,2,4]  R1782     3.2222609966993332e-02
    z[5,2,4]  R1783     -8.0519765615463257e-02
    z[5,2,4]  R1784     3.7069308757781982e-01
    z[5,2,4]  R1785     1.7405509948730469e-01
    z[5,2,4]  R1786     3.0431419610977173e-01
    z[5,2,4]  R1787     -8.5079200565814972e-02
    z[5,2,4]  R1788     7.2199290990829468e-01
    z[5,2,4]  R1789     3.3194559812545776e-01
    z[5,2,4]  R1790     1.6605427861213684e-01
    z[5,2,4]  R1791     1.8416607752442360e-02
    z[5,2,4]  R1792     -2.2175459563732147e-01
    z[5,2,4]  R1793     4.2684939503669739e-01
    z[5,2,4]  R1794     -2.6789689064025879e-01
    z[5,2,4]  R1795     3.8038060069084167e-01
    z[5,2,4]  R1796     -3.3481433987617493e-01
    z[5,2,4]  R1797     -2.6730507612228394e-02
    z[5,2,4]  R1798     -7.6060421764850616e-02
    z[5,2,4]  R1799     4.3052637577056885e-01
    z[5,2,4]  R1800     3.3167313784360886e-02
    z[5,2,4]  R1801     3.9344325661659241e-01
    z[5,2,4]  R1802     1.6735710203647614e-01
    z[5,2,4]  R1803     1.4674863219261169e-01
    z[5,2,4]  R1804     1.9643607735633850e-01
    z[5,2,4]  R1805     2.4451376497745514e-01
    z[5,2,4]  R1806     -2.8217095136642456e-01
    z[5,2,4]  R1807     4.3291813135147095e-01
    z[5,2,4]  R1808     6.5028005838394165e-01
    z[5,2,4]  R1809     -6.1785720288753510e-02
    z[5,2,4]  R1810     2.3512113094329834e-01
    z[5,2,4]  R1811     -6.0237981379032135e-02
    z[5,2,4]  R1812     8.2637047767639160e-01
    z[5,2,4]  R1813     6.9821491837501526e-02
    z[5,2,4]  R1814     7.6107615232467651e-01
    z[5,2,4]  R1815     6.2636291980743408e-01
    z[5,2,4]  R1816     6.4324772357940674e-01
    z[5,2,4]  R1817     3.2327157258987427e-01
    z[5,2,4]  R1818     1.6144491732120514e-01
    z[5,2,4]  R1819     5.3124237060546875e-01
    z[5,2,4]  R1820     7.2016930580139160e-01
    z[5,2,4]  R1821     -1.0330962389707565e-01
    z[5,2,4]  R1822     1.6766072809696198e-01
    z[5,2,4]  R1823     5.5407159030437469e-02
    z[5,2,4]  R1824     -4.9126887321472168e-01
    z[5,2,4]  R1825     4.8064431548118591e-01
    z[5,2,5]  R25       1
    z[5,2,5]  R52       -1
    z[5,2,5]  R1672     -1
    z[5,2,5]  R1673     1
    z[5,2,5]  R1676     -0.27354696393013
    z[5,2,5]  R1677     -2.5523068383336067e-02
    z[5,2,5]  R1678     9.2905461788177490e-02
    z[5,2,5]  R1679     -3.4722540527582169e-02
    z[5,2,5]  R1680     1.9602908194065094e-01
    z[5,2,5]  R1681     -3.6198985762894154e-03
    z[5,2,5]  R1682     -2.9300352931022644e-01
    z[5,2,5]  R1683     -5.6037425994873047e-01
    z[5,2,5]  R1684     3.3743798732757568e-01
    z[5,2,5]  R1685     -4.0920349955558777e-01
    z[5,2,5]  R1686     1.9935664534568787e-01
    z[5,2,5]  R1687     1.1492899060249329e-01
    z[5,2,5]  R1688     5.8168604969978333e-02
    z[5,2,5]  R1689     -1.5526196360588074e-01
    z[5,2,5]  R1690     1.9884844124317169e-01
    z[5,2,5]  R1691     -1.8055659532546997e-01
    z[5,2,5]  R1692     -1.2239484116435051e-02
    z[5,2,5]  R1693     -2.8148156404495239e-01
    z[5,2,5]  R1694     -2.3173154890537262e-01
    z[5,2,5]  R1695     -2.4595829844474792e-01
    z[5,2,5]  R1696     1.5505455434322357e-01
    z[5,2,5]  R1697     2.5466531515121460e-01
    z[5,2,5]  R1698     -2.3919600062072277e-03
    z[5,2,5]  R1699     3.3560761809349060e-01
    z[5,2,5]  R1700     4.0550000965595245e-02
    z[5,2,5]  R1701     1.2554794549942017e-01
    z[5,2,5]  R1702     1.9845777750015259e-01
    z[5,2,5]  R1703     0.188396617770195
    z[5,2,5]  R1704     3.7591537833213806e-01
    z[5,2,5]  R1705     1.6490317881107330e-01
    z[5,2,5]  R1706     -6.6061496734619141e-02
    z[5,2,5]  R1707     -4.3922942876815796e-01
    z[5,2,5]  R1708     -1.5732270479202271e-01
    z[5,2,5]  R1709     -5.5782753229141235e-01
    z[5,2,5]  R1710     3.1543437391519547e-02
    z[5,2,5]  R1711     1.6941666603088379e-01
    z[5,2,5]  R1712     1.2285882979631424e-01
    z[5,2,5]  R1713     7.1033620834350586e-01
    z[5,2,5]  R1714     4.4255855679512024e-01
    z[5,2,5]  R1715     -9.7863718867301941e-02
    z[5,2,5]  R1716     -1.5662544965744019e-01
    z[5,2,5]  R1717     -6.8838918209075928e-01
    z[5,2,5]  R1718     -1.7030051350593567e-01
    z[5,2,5]  R1719     -9.6369504928588867e-02
    z[5,2,5]  R1720     1.1636684834957123e-01
    z[5,2,5]  R1721     -5.4046493768692017e-01
    z[5,2,5]  R1722     -0.29739910364151
    z[5,2,5]  R1723     -2.8796562552452087e-01
    z[5,2,5]  R1724     0.449703186750412
    z[5,2,5]  R1725     2.3624885082244873e-01
    z[5,2,5]  R1726     3.7510338425636292e-01
    z[5,2,5]  R1727     -1.0032492876052856e-01
    z[5,2,5]  R1728     4.3588620424270630e-01
    z[5,2,5]  R1729     -3.6930760741233826e-01
    z[5,2,5]  R1730     0.152458056807518
    z[5,2,5]  R1731     -1.1823111772537231e-01
    z[5,2,5]  R1732     -3.2327221706509590e-03
    z[5,2,5]  R1733     1.3134506344795227e-01
    z[5,2,5]  R1734     -5.1871605217456818e-02
    z[5,2,5]  R1735     1.1105019599199295e-01
    z[5,2,5]  R1736     2.6202493906021118e-01
    z[5,2,5]  R1737     -1.7771621048450470e-01
    z[5,2,5]  R1738     0.144393190741539
    z[5,2,5]  R1739     1.5258552134037018e-01
    z[5,2,5]  R1740     1.6942301392555237e-01
    z[5,2,5]  R1741     1.9821600615978241e-01
    z[5,2,5]  R1742     -1.3792443275451660e-01
    z[5,2,5]  R1743     4.6606764197349548e-01
    z[5,2,5]  R1744     1.7696402966976166e-01
    z[5,2,5]  R1745     5.2001518011093140e-01
    z[5,2,5]  R1746     1.5033917129039764e-01
    z[5,2,5]  R1747     1.9275434315204620e-01
    z[5,2,5]  R1748     -7.8589223325252533e-02
    z[5,2,5]  R1749     -3.2607099413871765e-01
    z[5,2,5]  R1750     8.9479319751262665e-02
    z[5,2,5]  R1751     -1.1679124087095261e-01
    z[5,2,5]  R1752     1.3712685555219650e-02
    z[5,2,5]  R1753     -7.9214125871658325e-02
    z[5,2,5]  R1754     -8.7641589343547821e-02
    z[5,2,5]  R1755     -1.5276958048343658e-01
    z[5,2,5]  R1756     -2.5763321667909622e-02
    z[5,2,5]  R1757     1.1319072544574738e-01
    z[5,2,5]  R1758     -3.2504707574844360e-01
    z[5,2,5]  R1759     -5.9077125787734985e-01
    z[5,2,5]  R1760     -8.5536353290081024e-02
    z[5,2,5]  R1761     3.8181871175765991e-02
    z[5,2,5]  R1762     -1.5665654838085175e-01
    z[5,2,5]  R1763     -3.6032482981681824e-01
    z[5,2,5]  R1764     4.5826286077499390e-01
    z[5,2,5]  R1765     2.3778598010540009e-01
    z[5,2,5]  R1766     2.3975865915417671e-02
    z[5,2,5]  R1767     -1.9673697650432587e-01
    z[5,2,5]  R1768     -3.9418466389179230e-02
    z[5,2,5]  R1769     -1.0547454655170441e-01
    z[5,2,5]  R1770     -4.1495278477668762e-01
    z[5,2,5]  R1771     1.3072626292705536e-01
    z[5,2,5]  R1772     -2.0526649057865143e-01
    z[5,2,5]  R1773     -2.4558408558368683e-01
    z[5,2,5]  R1774     -1.0090753436088562e-01
    z[5,2,5]  R1775     -1.0786123573780060e-01
    z[5,2,5]  R1776     -2.7562916278839111e-01
    z[5,2,5]  R1777     0.073304183781147
    z[5,2,5]  R1778     0.0922246053814888
    z[5,2,5]  R1779     4.6109721064567566e-01
    z[5,2,5]  R1780     1.2221264094114304e-01
    z[5,2,5]  R1781     3.6499887704849243e-01
    z[5,2,5]  R1782     -3.2317012548446655e-01
    z[5,2,5]  R1783     7.0836436934769154e-03
    z[5,2,5]  R1784     1.2804001569747925e-01
    z[5,2,5]  R1785     5.4895699024200439e-01
    z[5,2,5]  R1786     2.7236780524253845e-01
    z[5,2,5]  R1787     -1.2452408671379089e-01
    z[5,2,5]  R1788     -6.5301053225994110e-02
    z[5,2,5]  R1789     4.3510493636131287e-01
    z[5,2,5]  R1790     -5.7376161217689514e-02
    z[5,2,5]  R1791     -1.8761390447616577e-01
    z[5,2,5]  R1792     -5.1306881010532379e-02
    z[5,2,5]  R1793     -3.3381082117557526e-02
    z[5,2,5]  R1794     -1.3989751040935516e-01
    z[5,2,5]  R1795     7.0005212910473347e-03
    z[5,2,5]  R1796     -3.5425817966461182e-01
    z[5,2,5]  R1797     2.6494054123759270e-02
    z[5,2,5]  R1798     4.0824812650680542e-01
    z[5,2,5]  R1799     1.4948236942291260e-01
    z[5,2,5]  R1800     -3.0073684453964233e-01
    z[5,2,5]  R1801     -1.9144824147224426e-01
    z[5,2,5]  R1802     2.0868784189224243e-01
    z[5,2,5]  R1803     -1.5906600281596184e-02
    z[5,2,5]  R1804     -2.2126603126525879e-01
    z[5,2,5]  R1805     4.2481872439384460e-01
    z[5,2,5]  R1806     -2.1682459115982056e-01
    z[5,2,5]  R1807     -2.3186743259429932e-01
    z[5,2,5]  R1808     1.1061707139015198e-01
    z[5,2,5]  R1809     1.7542797327041626e-01
    z[5,2,5]  R1810     -3.1311661005020142e-01
    z[5,2,5]  R1811     -2.8522959351539612e-01
    z[5,2,5]  R1812     3.5395030863583088e-03
    z[5,2,5]  R1813     2.9308724403381348e-01
    z[5,2,5]  R1814     1.7048075795173645e-02
    z[5,2,5]  R1815     -3.4903664141893387e-02
    z[5,2,5]  R1816     1.9971325993537903e-01
    z[5,2,5]  R1817     0.141094371676445
    z[5,2,5]  R1818     2.4412022903561592e-02
    z[5,2,5]  R1819     3.5019564628601074e-01
    z[5,2,5]  R1820     2.1683631464838982e-02
    z[5,2,5]  R1821     1.0498115420341492e-01
    z[5,2,5]  R1822     6.6231940872967243e-03
    z[5,2,5]  R1823     -2.3655049502849579e-01
    z[5,2,5]  R1824     -0.504997730255127
    z[5,2,5]  R1825     -2.6477809995412827e-02
    z[5,2,6]  R26       1
    z[5,2,6]  R53       -1
    z[5,2,6]  R1674     -1
    z[5,2,6]  R1675     1
    z[5,2,6]  R1676     1.2567305937409401e-02
    z[5,2,6]  R1677     -2.7718612551689148e-01
    z[5,2,6]  R1678     -2.9566511511802673e-01
    z[5,2,6]  R1679     3.4433576464653015e-01
    z[5,2,6]  R1680     5.5579822510480881e-02
    z[5,2,6]  R1681     -1.4310921728610992e-01
    z[5,2,6]  R1682     -1.1749270558357239e-01
    z[5,2,6]  R1683     -1.9455835223197937e-01
    z[5,2,6]  R1684     3.4837210178375244e-01
    z[5,2,6]  R1685     2.6342767477035522e-01
    z[5,2,6]  R1686     -4.6765303611755371e-01
    z[5,2,6]  R1687     -1.0650959610939026e-01
    z[5,2,6]  R1688     -1.9320906698703766e-01
    z[5,2,6]  R1689     1.5103018283843994e-01
    z[5,2,6]  R1690     -1.5218277275562286e-01
    z[5,2,6]  R1691     -2.6157429441809654e-02
    z[5,2,6]  R1692     -5.3551908582448959e-02
    z[5,2,6]  R1693     -3.7203781306743622e-02
    z[5,2,6]  R1694     -2.3170320689678192e-01
    z[5,2,6]  R1695     -1.9556893035769463e-02
    z[5,2,6]  R1696     1.0727799683809280e-01
    z[5,2,6]  R1697     3.3926871418952942e-01
    z[5,2,6]  R1698     -6.0322366654872894e-02
    z[5,2,6]  R1699     3.6199495196342468e-01
    z[5,2,6]  R1700     0.00312709528952837
    z[5,2,6]  R1701     -7.7364325523376465e-02
    z[5,2,6]  R1702     1.3736440241336823e-01
    z[5,2,6]  R1703     -2.8281034901738167e-03
    z[5,2,6]  R1704     1.7507965862751007e-01
    z[5,2,6]  R1705     2.0650139078497887e-02
    z[5,2,6]  R1706     4.1523313522338867e-01
    z[5,2,6]  R1707     -4.1135692596435547e-01
    z[5,2,6]  R1708     4.2290221899747849e-02
    z[5,2,6]  R1709     3.9515611529350281e-01
    z[5,2,6]  R1710     2.3404273390769958e-01
    z[5,2,6]  R1711     4.8952829092741013e-02
    z[5,2,6]  R1712     9.9118478596210480e-02
    z[5,2,6]  R1713     0.0359313040971756
    z[5,2,6]  R1714     4.5354613661766052e-01
    z[5,2,6]  R1715     -1.1205860227346420e-01
    z[5,2,6]  R1716     -3.9465554058551788e-02
    z[5,2,6]  R1717     3.7048763036727905e-01
    z[5,2,6]  R1718     -4.8416815698146820e-02
    z[5,2,6]  R1719     1.1586034297943115e-01
    z[5,2,6]  R1720     1.3355457782745361e-01
    z[5,2,6]  R1721     3.4233994781970978e-02
    z[5,2,6]  R1722     4.4190678745508194e-02
    z[5,2,6]  R1723     -3.3666866365820169e-03
    z[5,2,6]  R1724     2.9192259907722473e-01
    z[5,2,6]  R1725     -2.8641945123672485e-01
    z[5,2,6]  R1726     2.7961862087249756e-01
    z[5,2,6]  R1727     -2.1818424761295319e-01
    z[5,2,6]  R1728     1.6367980837821960e-01
    z[5,2,6]  R1729     1.7917476594448090e-01
    z[5,2,6]  R1730     -6.6021241247653961e-02
    z[5,2,6]  R1731     0.237451434135437
    z[5,2,6]  R1732     -1.2927031144499779e-02
    z[5,2,6]  R1733     3.5853590816259384e-02
    z[5,2,6]  R1734     -3.4651052951812744e-01
    z[5,2,6]  R1735     -0.0336323045194149
    z[5,2,6]  R1736     1.9779159128665924e-01
    z[5,2,6]  R1737     3.3439654111862183e-01
    z[5,2,6]  R1738     -3.0641382560133934e-02
    z[5,2,6]  R1739     1.1021838337182999e-01
    z[5,2,6]  R1740     4.5923396944999695e-01
    z[5,2,6]  R1741     8.8693335652351379e-02
    z[5,2,6]  R1742     -8.4558278322219849e-02
    z[5,2,6]  R1743     2.6078581809997559e-01
    z[5,2,6]  R1744     -4.6534806489944458e-02
    z[5,2,6]  R1745     1.0844473540782928e-01
    z[5,2,6]  R1746     1.2813293933868408e-01
    z[5,2,6]  R1747     -5.9406068176031113e-02
    z[5,2,6]  R1748     -3.6950135231018066e-01
    z[5,2,6]  R1749     4.1972849518060684e-02
    z[5,2,6]  R1750     -4.5489165186882019e-01
    z[5,2,6]  R1751     4.8335094004869461e-02
    z[5,2,6]  R1752     5.9358462691307068e-02
    z[5,2,6]  R1753     6.6626533865928650e-02
    z[5,2,6]  R1754     5.0326216220855713e-01
    z[5,2,6]  R1755     7.9438820481300354e-02
    z[5,2,6]  R1756     -5.2041497081518173e-02
    z[5,2,6]  R1757     2.6563179492950439e-01
    z[5,2,6]  R1758     1.2247455865144730e-01
    z[5,2,6]  R1759     -2.9744941741228104e-02
    z[5,2,6]  R1760     -1.7013169825077057e-01
    z[5,2,6]  R1761     -3.5226354002952576e-01
    z[5,2,6]  R1762     -3.1037840247154236e-01
    z[5,2,6]  R1763     -2.2379522025585175e-01
    z[5,2,6]  R1764     4.9815565347671509e-02
    z[5,2,6]  R1765     6.5397346019744873e-01
    z[5,2,6]  R1766     1.7376956343650818e-01
    z[5,2,6]  R1767     3.9379266090691090e-03
    z[5,2,6]  R1768     8.5842885076999664e-02
    z[5,2,6]  R1769     5.0171691924333572e-02
    z[5,2,6]  R1770     -2.0933536812663078e-02
    z[5,2,6]  R1771     -5.0253149121999741e-02
    z[5,2,6]  R1772     2.9349419474601746e-01
    z[5,2,6]  R1773     2.8682306408882141e-01
    z[5,2,6]  R1774     -1.9491675496101379e-01
    z[5,2,6]  R1775     -3.3388055860996246e-02
    z[5,2,6]  R1776     -1.3035708665847778e-01
    z[5,2,6]  R1777     -3.4366950392723083e-01
    z[5,2,6]  R1778     9.2071019113063812e-02
    z[5,2,6]  R1779     -1.1393783241510391e-01
    z[5,2,6]  R1780     8.2571931183338165e-02
    z[5,2,6]  R1781     -3.6306026577949524e-01
    z[5,2,6]  R1782     8.3058521151542664e-02
    z[5,2,6]  R1783     1.4299200847744942e-02
    z[5,2,6]  R1784     4.2816221714019775e-01
    z[5,2,6]  R1785     3.4252646565437317e-01
    z[5,2,6]  R1786     -1.8468311429023743e-01
    z[5,2,6]  R1787     -4.3246969580650330e-01
    z[5,2,6]  R1788     6.2741570174694061e-02
    z[5,2,6]  R1789     -5.8201032876968384e-01
    z[5,2,6]  R1790     1.0211148113012314e-01
    z[5,2,6]  R1791     -2.6464468240737915e-01
    z[5,2,6]  R1792     5.3623810410499573e-02
    z[5,2,6]  R1793     4.9583610892295837e-01
    z[5,2,6]  R1794     1.6540125012397766e-01
    z[5,2,6]  R1795     -2.4010688066482544e-01
    z[5,2,6]  R1796     3.7758362293243408e-01
    z[5,2,6]  R1797     -3.3995591104030609e-02
    z[5,2,6]  R1798     2.4440832436084747e-01
    z[5,2,6]  R1799     2.2488673031330109e-01
    z[5,2,6]  R1800     1.7554501071572304e-02
    z[5,2,6]  R1801     -5.4029554128646851e-01
    z[5,2,6]  R1802     -2.1544055640697479e-01
    z[5,2,6]  R1803     -4.4490674138069153e-01
    z[5,2,6]  R1804     5.8592408895492554e-01
    z[5,2,6]  R1805     -4.2189598083496094e-02
    z[5,2,6]  R1806     0.26277956366539
    z[5,2,6]  R1807     -1.5819574892520905e-01
    z[5,2,6]  R1808     6.4440146088600159e-02
    z[5,2,6]  R1809     -0.503376841545105
    z[5,2,6]  R1810     9.5405891537666321e-02
    z[5,2,6]  R1811     5.3170013427734375e-01
    z[5,2,6]  R1812     -3.4733593463897705e-01
    z[5,2,6]  R1813     1.4525157213211060e-01
    z[5,2,6]  R1814     -1.4669755101203918e-01
    z[5,2,6]  R1815     -3.0108600854873657e-01
    z[5,2,6]  R1816     -2.6337680220603943e-01
    z[5,2,6]  R1817     -1.4485427737236023e-01
    z[5,2,6]  R1818     4.2245812714099884e-02
    z[5,2,6]  R1819     8.5663706064224243e-02
    z[5,2,6]  R1820     -1.1631070822477341e-01
    z[5,2,6]  R1821     1.2773084640502930e-01
    z[5,2,6]  R1822     1.3055829703807831e-01
    z[5,2,6]  R1823     -1.3799254596233368e-01
    z[5,2,6]  R1824     -3.9727625250816345e-01
    z[5,2,6]  R1825     -1.6255301237106323e-01
    z[3,4,0]  R29       -1
    z[3,4,0]  R38       1
    z[3,4,0]  R1910     -1
    z[3,4,0]  R1911     1
    z[3,4,0]  R1924     -2.3660942912101746e-02
    z[3,4,0]  R1925     -6.7642802000045776e-01
    z[3,4,0]  R1926     -4.9517515301704407e-01
    z[3,4,0]  R1927     -2.8080910444259644e-01
    z[3,4,0]  R1928     -3.0979430675506592e-01
    z[3,4,0]  R1929     -4.3818223476409912e-01
    z[3,4,0]  R1930     -3.4521660208702087e-01
    z[3,4,0]  R1931     2.8427250217646360e-03
    z[3,4,0]  R1932     -6.6371224820613861e-02
    z[3,4,0]  R1933     -2.6585647463798523e-01
    z[3,4,0]  R1934     4.7867482900619507e-01
    z[3,4,0]  R1935     -5.8776414394378662e-01
    z[3,4,0]  R1936     -3.5246106982231140e-01
    z[3,4,0]  R1937     -6.1804109811782837e-01
    z[3,4,0]  R1938     -2.4182218313217163e-01
    z[3,4,0]  R1939     -0.525830864906311
    z[3,4,0]  R1940     -5.7502126693725586e-01
    z[3,4,0]  R1941     -4.0891861915588379e-01
    z[3,4,0]  R1942     -4.4103786349296570e-01
    z[3,4,0]  R1943     -0.522939145565033
    z[3,4,0]  R1944     2.4460309743881226e-01
    z[3,4,0]  R1945     4.2715522646903992e-01
    z[3,4,0]  R1946     3.2835906744003296e-01
    z[3,4,0]  R1947     5.5589717626571655e-01
    z[3,4,0]  R1948     -1.1993542313575745e-01
    z[3,4,0]  R1949     5.2645742893218994e-01
    z[3,4,0]  R1950     4.1524934768676758e-01
    z[3,4,0]  R1951     4.1558876633644104e-01
    z[3,4,0]  R1952     5.9942883253097534e-01
    z[3,4,0]  R1953     2.7454838156700134e-02
    z[3,4,0]  R1954     1.4633931219577789e-01
    z[3,4,0]  R1955     3.0731040239334106e-01
    z[3,4,0]  R1956     5.2321493625640869e-01
    z[3,4,0]  R1957     2.3162433505058289e-01
    z[3,4,0]  R1958     0.352159321308136
    z[3,4,0]  R1959     4.1018098592758179e-01
    z[3,4,0]  R1960     6.8061405420303345e-01
    z[3,4,0]  R1961     0.587196409702301
    z[3,4,0]  R1962     4.5920401811599731e-01
    z[3,4,0]  R1963     4.8823356628417969e-01
    z[3,4,0]  R1964     2.1337687969207764e-01
    z[3,4,0]  R1965     0.702157199382782
    z[3,4,0]  R1966     4.9267145991325378e-01
    z[3,4,0]  R1967     1.6420282423496246e-01
    z[3,4,0]  R1968     3.8145303726196289e-01
    z[3,4,0]  R1969     6.1188286542892456e-01
    z[3,4,0]  R1970     4.6825012564659119e-01
    z[3,4,0]  R1971     4.9199223518371582e-01
    z[3,4,0]  R1972     1.8281713128089905e-02
    z[3,4,0]  R1973     0.5074462890625
    z[3,4,0]  R1974     2.9385295510292053e-01
    z[3,4,0]  R1975     4.3124410510063171e-01
    z[3,4,0]  R1976     -5.7759042829275131e-02
    z[3,4,0]  R1977     5.1795196533203125e-01
    z[3,4,0]  R1978     6.3703131675720215e-01
    z[3,4,0]  R1979     0.357229620218277
    z[3,4,0]  R1980     -5.2753275632858276e-01
    z[3,4,0]  R1981     2.2294804453849792e-01
    z[3,4,0]  R1982     0.316459059715271
    z[3,4,0]  R1983     2.4885358288884163e-02
    z[3,4,0]  R1984     3.5174342989921570e-01
    z[3,4,0]  R1985     3.0526661872863770e-01
    z[3,4,0]  R1986     -2.0106610655784607e-01
    z[3,4,0]  R1987     2.3342198133468628e-01
    z[3,4,0]  R1988     3.5342502593994141e-01
    z[3,4,0]  R1989     1.2162110209465027e-01
    z[3,4,0]  R1990     9.8546624183654785e-02
    z[3,4,0]  R1991     5.0777590274810791e-01
    z[3,4,0]  R1992     -2.1205723285675049e-01
    z[3,4,0]  R1993     -2.2117216885089874e-01
    z[3,4,0]  R1994     6.5122477710247040e-02
    z[3,4,0]  R1995     3.5603755712509155e-01
    z[3,4,0]  R1996     0.0617666058242321
    z[3,4,0]  R1997     5.4670524597167969e-01
    z[3,4,0]  R1998     2.3764832317829132e-01
    z[3,4,0]  R1999     4.9069947004318237e-01
    z[3,4,0]  R2000     2.6874250173568726e-01
    z[3,4,0]  R2001     3.3461397886276245e-01
    z[3,4,0]  R2002     5.8027577400207520e-01
    z[3,4,0]  R2003     9.4387523829936981e-02
    z[3,4,0]  R2004     -5.5177497863769531e-01
    z[3,4,0]  R2005     -4.0907946228981018e-01
    z[3,4,0]  R2006     3.0622461438179016e-01
    z[3,4,0]  R2007     2.8966364264488220e-01
    z[3,4,0]  R2008     1.6090807318687439e-01
    z[3,4,0]  R2009     4.8265120387077332e-01
    z[3,4,0]  R2010     3.9025691151618958e-01
    z[3,4,0]  R2011     2.1352705359458923e-01
    z[3,4,0]  R2012     -0.0727607011795044
    z[3,4,0]  R2013     -3.2407945394515991e-01
    z[3,4,0]  R2014     -4.3566304445266724e-01
    z[3,4,0]  R2015     1.1860569566488266e-01
    z[3,4,0]  R2016     -3.3444091677665710e-01
    z[3,4,0]  R2017     -4.9569246172904968e-01
    z[3,4,0]  R2018     -4.7821506857872009e-01
    z[3,4,0]  R2019     -2.5301378965377808e-01
    z[3,4,0]  R2020     0.00965464673936367
    z[3,4,0]  R2021     -7.8255213797092438e-02
    z[3,4,0]  R2022     1.2590855360031128e-01
    z[3,4,0]  R2023     -1.0428953170776367e-01
    z[3,4,0]  R2024     0.323359876871109
    z[3,4,0]  R2025     3.7382391095161438e-01
    z[3,4,0]  R2026     7.9257696866989136e-02
    z[3,4,0]  R2027     3.5170421004295349e-01
    z[3,4,0]  R2028     3.0049356818199158e-01
    z[3,4,0]  R2029     7.3320543766021729e-01
    z[3,4,0]  R2030     1.4527393877506256e-01
    z[3,4,0]  R2031     6.4717435836791992e-01
    z[3,4,0]  R2032     -1.5803582966327667e-01
    z[3,4,0]  R2033     -3.5336855053901672e-01
    z[3,4,0]  R2034     2.2044897079467773e-01
    z[3,4,0]  R2035     0.0868205651640892
    z[3,4,0]  R2036     -8.1602618098258972e-02
    z[3,4,0]  R2037     2.1975185722112656e-02
    z[3,4,0]  R2038     7.1332126855850220e-02
    z[3,4,0]  R2039     1.3148538768291473e-01
    z[3,4,0]  R2040     -5.4136735200881958e-01
    z[3,4,0]  R2041     5.0642073154449463e-01
    z[3,4,0]  R2042     1.5650652348995209e-01
    z[3,4,0]  R2043     -1.3747981190681458e-01
    z[3,4,1]  R30       -1
    z[3,4,1]  R39       1
    z[3,4,1]  R1912     -1
    z[3,4,1]  R1913     1
    z[3,4,1]  R1924     0.842336893081665
    z[3,4,1]  R1925     6.8349009752273560e-01
    z[3,4,1]  R1926     6.7841392755508423e-01
    z[3,4,1]  R1927     6.7690467834472656e-01
    z[3,4,1]  R1928     6.4372408390045166e-01
    z[3,4,1]  R1929     5.6303697824478149e-01
    z[3,4,1]  R1930     5.4218709468841553e-01
    z[3,4,1]  R1931     5.9074205160140991e-01
    z[3,4,1]  R1932     5.7622200250625610e-01
    z[3,4,1]  R1933     5.2282029390335083e-01
    z[3,4,1]  R1934     2.6429495215415955e-01
    z[3,4,1]  R1935     -6.3401788473129272e-01
    z[3,4,1]  R1936     -8.5421293973922729e-01
    z[3,4,1]  R1937     -0.698803186416626
    z[3,4,1]  R1938     -8.3294248580932617e-01
    z[3,4,1]  R1939     -6.6108095645904541e-01
    z[3,4,1]  R1940     -5.9603250026702881e-01
    z[3,4,1]  R1941     -5.2921229600906372e-01
    z[3,4,1]  R1942     -5.1782667636871338e-01
    z[3,4,1]  R1943     -5.2858549356460571e-01
    z[3,4,1]  R1944     4.1859099268913269e-01
    z[3,4,1]  R1945     4.9714335799217224e-01
    z[3,4,1]  R1946     -0.0708140879869461
    z[3,4,1]  R1947     -4.7793912887573242e-01
    z[3,4,1]  R1948     -3.9171531796455383e-01
    z[3,4,1]  R1949     -3.1207174062728882e-01
    z[3,4,1]  R1950     -2.1651053428649902e-01
    z[3,4,1]  R1951     -3.1970804929733276e-01
    z[3,4,1]  R1952     -2.5623393058776855e-01
    z[3,4,1]  R1953     2.4614408612251282e-01
    z[3,4,1]  R1954     -7.6266628503799438e-01
    z[3,4,1]  R1955     -3.6327430605888367e-01
    z[3,4,1]  R1956     2.2373306751251221e-01
    z[3,4,1]  R1957     -4.9296915531158447e-01
    z[3,4,1]  R1958     5.6185829639434814e-01
    z[3,4,1]  R1959     7.7729612588882446e-01
    z[3,4,1]  R1960     5.1344454288482666e-01
    z[3,4,1]  R1961     -1.8832521140575409e-01
    z[3,4,1]  R1962     2.5979763269424438e-01
    z[3,4,1]  R1963     -3.6433655023574829e-01
    z[3,4,1]  R1964     2.9991710186004639e-01
    z[3,4,1]  R1965     -1.8482691049575806e-01
    z[3,4,1]  R1966     5.1216334104537964e-01
    z[3,4,1]  R1967     5.9576076269149780e-01
    z[3,4,1]  R1968     0.552386999130249
    z[3,4,1]  R1969     4.9788832664489746e-01
    z[3,4,1]  R1970     6.2892836332321167e-01
    z[3,4,1]  R1971     7.0189118385314941e-01
    z[3,4,1]  R1972     -2.1042430400848389e-01
    z[3,4,1]  R1973     7.1531242132186890e-01
    z[3,4,1]  R1974     7.3811477422714233e-01
    z[3,4,1]  R1975     4.6012678742408752e-01
    z[3,4,1]  R1976     -2.3309087753295898e-01
    z[3,4,1]  R1977     6.7887884378433228e-01
    z[3,4,1]  R1978     6.1221557855606079e-01
    z[3,4,1]  R1979     7.4682730436325073e-01
    z[3,4,1]  R1980     -2.3578248918056488e-01
    z[3,4,1]  R1981     -3.9649134874343872e-01
    z[3,4,1]  R1982     -1.2682583928108215e-01
    z[3,4,1]  R1983     1.2493968755006790e-01
    z[3,4,1]  R1984     2.9076436161994934e-01
    z[3,4,1]  R1985     7.1940815448760986e-01
    z[3,4,1]  R1986     -5.1374858617782593e-01
    z[3,4,1]  R1987     -3.2952564954757690e-01
    z[3,4,1]  R1988     1.0562562942504883e-01
    z[3,4,1]  R1989     -5.8447830379009247e-03
    z[3,4,1]  R1990     -6.7971736192703247e-01
    z[3,4,1]  R1991     0.0712711289525032
    z[3,4,1]  R1992     -2.0662029087543488e-01
    z[3,4,1]  R1993     1.6451099514961243e-01
    z[3,4,1]  R1994     4.7735238075256348e-01
    z[3,4,1]  R1995     -4.0121245384216309e-01
    z[3,4,1]  R1996     -7.5811302661895752e-01
    z[3,4,1]  R1997     -6.5737382101360708e-05
    z[3,4,1]  R1998     -8.6188906431198120e-01
    z[3,4,1]  R1999     -1.1684004217386246e-01
    z[3,4,1]  R2000     3.5133507847785950e-01
    z[3,4,1]  R2001     -8.4839671850204468e-02
    z[3,4,1]  R2002     9.1011054813861847e-02
    z[3,4,1]  R2003     -1.2946946918964386e-01
    z[3,4,1]  R2004     -4.4211155176162720e-01
    z[3,4,1]  R2005     -4.5028707385063171e-01
    z[3,4,1]  R2006     -8.7053716182708740e-02
    z[3,4,1]  R2007     2.7605205774307251e-01
    z[3,4,1]  R2008     1.8752078711986542e-01
    z[3,4,1]  R2009     8.2377985119819641e-02
    z[3,4,1]  R2010     8.8901974260807037e-02
    z[3,4,1]  R2011     1.4832818508148193e-01
    z[3,4,1]  R2012     -7.2970294952392578e-01
    z[3,4,1]  R2013     -7.9550343751907349e-01
    z[3,4,1]  R2014     7.5889408588409424e-01
    z[3,4,1]  R2015     7.5472515821456909e-01
    z[3,4,1]  R2016     8.6888861656188965e-01
    z[3,4,1]  R2017     0.603097140789032
    z[3,4,1]  R2018     5.7544064521789551e-01
    z[3,4,1]  R2019     0.612223744392395
    z[3,4,1]  R2020     6.5207844972610474e-01
    z[3,4,1]  R2021     6.4350157976150513e-01
    z[3,4,1]  R2022     -8.4987187385559082e-01
    z[3,4,1]  R2023     -8.2063728570938110e-01
    z[3,4,1]  R2024     7.5189995765686035e-01
    z[3,4,1]  R2025     4.3783202767372131e-01
    z[3,4,1]  R2026     -3.8606387376785278e-01
    z[3,4,1]  R2027     -2.4214853346347809e-01
    z[3,4,1]  R2028     -3.1058117747306824e-01
    z[3,4,1]  R2029     -2.2177360951900482e-01
    z[3,4,1]  R2030     -1.5315692871809006e-02
    z[3,4,1]  R2031     -3.2986709475517273e-01
    z[3,4,1]  R2032     2.3476628959178925e-01
    z[3,4,1]  R2033     1.9111397862434387e-01
    z[3,4,1]  R2034     7.2244065999984741e-01
    z[3,4,1]  R2035     5.5984967947006226e-01
    z[3,4,1]  R2036     4.1613170504570007e-01
    z[3,4,1]  R2037     4.0391734242439270e-01
    z[3,4,1]  R2038     4.3273970484733582e-01
    z[3,4,1]  R2039     3.8729482889175415e-01
    z[3,4,1]  R2040     -2.0500813424587250e-01
    z[3,4,1]  R2041     -6.2468174844980240e-02
    z[3,4,1]  R2042     -5.0921678543090820e-02
    z[3,4,1]  R2043     -3.5752475261688232e-01
    z[3,4,2]  R31       -1
    z[3,4,2]  R40       1
    z[3,4,2]  R1914     -1
    z[3,4,2]  R1915     1
    z[3,4,2]  R1924     1.4451944828033447e-01
    z[3,4,2]  R1925     -6.6902157850563526e-03
    z[3,4,2]  R1926     -2.3741452395915985e-01
    z[3,4,2]  R1927     -3.3453068137168884e-01
    z[3,4,2]  R1928     -1.7780803143978119e-01
    z[3,4,2]  R1929     3.5348970443010330e-02
    z[3,4,2]  R1930     4.5870873332023621e-01
    z[3,4,2]  R1931     1.5734094381332397e-01
    z[3,4,2]  R1932     -0.425411194562912
    z[3,4,2]  R1933     3.5178694128990173e-01
    z[3,4,2]  R1934     6.6110062599182129e-01
    z[3,4,2]  R1935     -2.9593446850776672e-01
    z[3,4,2]  R1936     -7.1088381111621857e-02
    z[3,4,2]  R1937     -0.0973065197467804
    z[3,4,2]  R1938     -2.5544852018356323e-01
    z[3,4,2]  R1939     -2.9635587334632874e-01
    z[3,4,2]  R1940     -2.8497090935707092e-01
    z[3,4,2]  R1941     -6.3906210660934448e-01
    z[3,4,2]  R1942     -0.667457103729248
    z[3,4,2]  R1943     -5.7527345418930054e-01
    z[3,4,2]  R1944     5.1331037282943726e-01
    z[3,4,2]  R1945     1.8045547604560852e-01
    z[3,4,2]  R1946     3.1240659952163696e-01
    z[3,4,2]  R1947     1.0660746693611145e-01
    z[3,4,2]  R1948     4.5155549049377441e-01
    z[3,4,2]  R1949     2.7448868751525879e-01
    z[3,4,2]  R1950     -5.2570984698832035e-03
    z[3,4,2]  R1951     5.1050531864166260e-01
    z[3,4,2]  R1952     3.7498977035284042e-02
    z[3,4,2]  R1953     4.7652056813240051e-01
    z[3,4,2]  R1954     2.1068260073661804e-01
    z[3,4,2]  R1955     3.4870314598083496e-01
    z[3,4,2]  R1956     6.9835472106933594e-01
    z[3,4,2]  R1957     7.1132189035415649e-01
    z[3,4,2]  R1958     1.3834661245346069e-01
    z[3,4,2]  R1959     2.4175962433218956e-02
    z[3,4,2]  R1960     1.1042704433202744e-01
    z[3,4,2]  R1961     1.0658313333988190e-01
    z[3,4,2]  R1962     1.4647732675075531e-01
    z[3,4,2]  R1963     4.9737501144409180e-01
    z[3,4,2]  R1964     6.2148753553628922e-02
    z[3,4,2]  R1965     2.6213395595550537e-01
    z[3,4,2]  R1966     -9.8603196442127228e-02
    z[3,4,2]  R1967     -1.4586040377616882e-01
    z[3,4,2]  R1968     -1.4332130551338196e-01
    z[3,4,2]  R1969     1.5385118126869202e-01
    z[3,4,2]  R1970     2.2596241533756256e-01
    z[3,4,2]  R1971     7.3518723249435425e-02
    z[3,4,2]  R1972     2.5252890586853027e-01
    z[3,4,2]  R1973     1.7043286561965942e-01
    z[3,4,2]  R1974     2.5744667649269104e-01
    z[3,4,2]  R1975     6.8309265375137329e-01
    z[3,4,2]  R1976     5.0319695472717285e-01
    z[3,4,2]  R1977     3.5586360096931458e-01
    z[3,4,2]  R1978     3.0896160006523132e-01
    z[3,4,2]  R1979     -0.069015271961689
    z[3,4,2]  R1980     -2.5801885128021240e-01
    z[3,4,2]  R1981     4.8450362682342529e-01
    z[3,4,2]  R1982     6.9639271497726440e-01
    z[3,4,2]  R1983     2.9191273450851440e-01
    z[3,4,2]  R1984     -4.8016417026519775e-01
    z[3,4,2]  R1985     -1.0359817743301392e-01
    z[3,4,2]  R1986     -4.5071166753768921e-01
    z[3,4,2]  R1987     8.4194815158843994e-01
    z[3,4,2]  R1988     -9.0492151677608490e-02
    z[3,4,2]  R1989     6.8993037939071655e-01
    z[3,4,2]  R1990     2.0763725042343140e-01
    z[3,4,2]  R1991     3.7901934981346130e-01
    z[3,4,2]  R1992     -4.2340385913848877e-01
    z[3,4,2]  R1993     -5.7228218764066696e-02
    z[3,4,2]  R1994     1.8733383715152740e-01
    z[3,4,2]  R1995     6.4164972305297852e-01
    z[3,4,2]  R1996     2.5032129883766174e-01
    z[3,4,2]  R1997     3.3896341919898987e-01
    z[3,4,2]  R1998     0.0697273463010788
    z[3,4,2]  R1999     -1.9183041527867317e-02
    z[3,4,2]  R2000     1.4869990944862366e-01
    z[3,4,2]  R2001     6.1271142959594727e-01
    z[3,4,2]  R2002     -4.8083987087011337e-02
    z[3,4,2]  R2003     8.8728785514831543e-01
    z[3,4,2]  R2004     -3.7146055698394775e-01
    z[3,4,2]  R2005     -3.4338730573654175e-01
    z[3,4,2]  R2006     7.0441210269927979e-01
    z[3,4,2]  R2007     3.3388638496398926e-01
    z[3,4,2]  R2008     6.1313128471374512e-01
    z[3,4,2]  R2009     2.8575578331947327e-01
    z[3,4,2]  R2010     2.8835749626159668e-01
    z[3,4,2]  R2011     2.1216154098510742e-01
    z[3,4,2]  R2012     5.5589151382446289e-01
    z[3,4,2]  R2013     9.2491582036018372e-02
    z[3,4,2]  R2014     1.1177688837051392e-01
    z[3,4,2]  R2015     -4.3407250195741653e-02
    z[3,4,2]  R2016     3.0480053275823593e-02
    z[3,4,2]  R2017     3.0818262696266174e-01
    z[3,4,2]  R2018     4.3888410925865173e-01
    z[3,4,2]  R2019     -6.2086533755064011e-02
    z[3,4,2]  R2020     1.2212823331356049e-01
    z[3,4,2]  R2021     -7.3171287775039673e-02
    z[3,4,2]  R2022     3.2754510641098022e-01
    z[3,4,2]  R2023     -2.2392237558960915e-02
    z[3,4,2]  R2024     3.8310687988996506e-02
    z[3,4,2]  R2025     3.6883878707885742e-01
    z[3,4,2]  R2026     -1.6428200900554657e-01
    z[3,4,2]  R2027     -2.7812442183494568e-01
    z[3,4,2]  R2028     -2.9574507474899292e-01
    z[3,4,2]  R2029     -2.9847124218940735e-01
    z[3,4,2]  R2030     2.7253448963165283e-01
    z[3,4,2]  R2031     -2.4370205402374268e-01
    z[3,4,2]  R2032     -0.265984445810318
    z[3,4,2]  R2033     -6.4389117062091827e-02
    z[3,4,2]  R2034     -4.4989919662475586e-01
    z[3,4,2]  R2035     -7.8759752213954926e-02
    z[3,4,2]  R2036     -1.0610629618167877e-01
    z[3,4,2]  R2037     0.192478746175766
    z[3,4,2]  R2038     -1.1112035065889359e-01
    z[3,4,2]  R2039     5.6924498081207275e-01
    z[3,4,2]  R2040     3.7033399939537048e-01
    z[3,4,2]  R2041     8.6332149803638458e-03
    z[3,4,2]  R2042     1.4917572028934956e-02
    z[3,4,2]  R2043     -4.1301719844341278e-02
    z[3,4,3]  R32       -1
    z[3,4,3]  R41       1
    z[3,4,3]  R1916     -1
    z[3,4,3]  R1917     1
    z[3,4,3]  R1924     1.5452498197555542e-01
    z[3,4,3]  R1925     -1.3995146751403809e-01
    z[3,4,3]  R1926     -1.5703247487545013e-01
    z[3,4,3]  R1927     1.2292017787694931e-01
    z[3,4,3]  R1928     3.3047699928283691e-01
    z[3,4,3]  R1929     4.2566198110580444e-01
    z[3,4,3]  R1930     -2.5924065709114075e-01
    z[3,4,3]  R1931     -5.1565170288085938e-02
    z[3,4,3]  R1932     9.4079270958900452e-02
    z[3,4,3]  R1933     4.1670314967632294e-02
    z[3,4,3]  R1934     -3.4154820442199707e-01
    z[3,4,3]  R1935     3.8465496897697449e-01
    z[3,4,3]  R1936     1.9840165972709656e-01
    z[3,4,3]  R1937     1.9946859776973724e-01
    z[3,4,3]  R1938     1.9778101146221161e-01
    z[3,4,3]  R1939     3.0093595385551453e-01
    z[3,4,3]  R1940     6.8186283111572266e-02
    z[3,4,3]  R1941     1.7986796796321869e-01
    z[3,4,3]  R1942     2.6327994465827942e-01
    z[3,4,3]  R1943     1.6986837983131409e-01
    z[3,4,3]  R1944     -1.1933231353759766e-01
    z[3,4,3]  R1945     -4.5953401923179626e-01
    z[3,4,3]  R1946     -4.9614539742469788e-01
    z[3,4,3]  R1947     -5.9462565183639526e-01
    z[3,4,3]  R1948     -7.8989648818969727e-01
    z[3,4,3]  R1949     7.1969664096832275e-01
    z[3,4,3]  R1950     7.7174967527389526e-01
    z[3,4,3]  R1951     6.5546214580535889e-01
    z[3,4,3]  R1952     7.4106442928314209e-01
    z[3,4,3]  R1953     2.0021730661392212e-01
    z[3,4,3]  R1954     5.5433970689773560e-01
    z[3,4,3]  R1955     -0.52590012550354
    z[3,4,3]  R1956     -2.0495519042015076e-01
    z[3,4,3]  R1957     -4.1875174641609192e-01
    z[3,4,3]  R1958     -1.0279170423746109e-01
    z[3,4,3]  R1959     -2.3706091940402985e-01
    z[3,4,3]  R1960     -3.3714500069618225e-01
    z[3,4,3]  R1961     -5.2882552146911621e-01
    z[3,4,3]  R1962     -6.9368675351142883e-02
    z[3,4,3]  R1963     -4.7914066910743713e-01
    z[3,4,3]  R1964     -9.9878363311290741e-02
    z[3,4,3]  R1965     -5.1860916614532471e-01
    z[3,4,3]  R1966     -3.5057091712951660e-01
    z[3,4,3]  R1967     -2.8914105892181396e-01
    z[3,4,3]  R1968     -5.3530967235565186e-01
    z[3,4,3]  R1969     -4.6962723135948181e-01
    z[3,4,3]  R1970     -1.1298985779285431e-01
    z[3,4,3]  R1971     -4.1704189777374268e-01
    z[3,4,3]  R1972     -6.3620281219482422e-01
    z[3,4,3]  R1973     -1.1998195201158524e-01
    z[3,4,3]  R1974     -4.4902548193931580e-01
    z[3,4,3]  R1975     -3.3522203564643860e-01
    z[3,4,3]  R1976     -7.0099848508834839e-01
    z[3,4,3]  R1977     -1.5192590653896332e-01
    z[3,4,3]  R1978     -1.7222185432910919e-01
    z[3,4,3]  R1979     -1.0414893925189972e-01
    z[3,4,3]  R1980     3.5653609037399292e-01
    z[3,4,3]  R1981     -3.4274348616600037e-01
    z[3,4,3]  R1982     -2.7085381746292114e-01
    z[3,4,3]  R1983     -4.7200977802276611e-01
    z[3,4,3]  R1984     2.4483743309974670e-01
    z[3,4,3]  R1985     -1.5734506770968437e-02
    z[3,4,3]  R1986     4.1942241787910461e-01
    z[3,4,3]  R1987     -2.6084804534912109e-01
    z[3,4,3]  R1988     -4.4614812731742859e-01
    z[3,4,3]  R1989     -1.6034652292728424e-01
    z[3,4,3]  R1990     5.3146493434906006e-01
    z[3,4,3]  R1991     -1.1219819635152817e-01
    z[3,4,3]  R1992     3.1958571076393127e-01
    z[3,4,3]  R1993     -7.0361125469207764e-01
    z[3,4,3]  R1994     -1.9121690420433879e-03
    z[3,4,3]  R1995     -4.7457507252693176e-01
    z[3,4,3]  R1996     5.5143153667449951e-01
    z[3,4,3]  R1997     -4.7516596317291260e-01
    z[3,4,3]  R1998     1.0443050414323807e-01
    z[3,4,3]  R1999     -6.0496044158935547e-01
    z[3,4,3]  R2000     -6.7006343603134155e-01
    z[3,4,3]  R2001     -0.553982675075531
    z[3,4,3]  R2002     -2.4072326719760895e-01
    z[3,4,3]  R2003     -3.7531527876853943e-01
    z[3,4,3]  R2004     2.7557075023651123e-01
    z[3,4,3]  R2005     4.3271756172180176e-01
    z[3,4,3]  R2006     -4.4720742106437683e-01
    z[3,4,3]  R2007     -4.1746154427528381e-01
    z[3,4,3]  R2008     -2.7875733375549316e-01
    z[3,4,3]  R2009     -1.6073594987392426e-01
    z[3,4,3]  R2010     -6.6731703281402588e-01
    z[3,4,3]  R2011     -1.9253656268119812e-01
    z[3,4,3]  R2012     2.6407274603843689e-01
    z[3,4,3]  R2013     -0.37900310754776
    z[3,4,3]  R2014     -4.1165980696678162e-01
    z[3,4,3]  R2015     -0.512349009513855
    z[3,4,3]  R2016     -2.7854391932487488e-01
    z[3,4,3]  R2017     5.7831909507513046e-02
    z[3,4,3]  R2018     2.8801107406616211e-01
    z[3,4,3]  R2019     3.1249490380287170e-01
    z[3,4,3]  R2020     1.3719774782657623e-01
    z[3,4,3]  R2021     4.3428402394056320e-02
    z[3,4,3]  R2022     -6.6395789384841919e-02
    z[3,4,3]  R2023     -3.9228478074073792e-01
    z[3,4,3]  R2024     3.4189349412918091e-01
    z[3,4,3]  R2025     4.8163211345672607e-01
    z[3,4,3]  R2026     8.0897784233093262e-01
    z[3,4,3]  R2027     8.2589679956436157e-01
    z[3,4,3]  R2028     5.5961722135543823e-01
    z[3,4,3]  R2029     3.9866998791694641e-01
    z[3,4,3]  R2030     -7.4746638536453247e-01
    z[3,4,3]  R2031     2.6748523116111755e-01
    z[3,4,3]  R2032     0.646652102470398
    z[3,4,3]  R2033     5.6053936481475830e-01
    z[3,4,3]  R2034     5.5258788168430328e-02
    z[3,4,3]  R2035     4.0571206808090210e-01
    z[3,4,3]  R2036     8.2479590177536011e-01
    z[3,4,3]  R2037     7.6130068302154541e-01
    z[3,4,3]  R2038     1.5137337148189545e-01
    z[3,4,3]  R2039     2.9105362296104431e-01
    z[3,4,3]  R2040     -6.1816269159317017e-01
    z[3,4,3]  R2041     -6.7544937133789062e-01
    z[3,4,3]  R2042     -6.6152596473693848e-01
    z[3,4,3]  R2043     4.3023351579904556e-02
    z[3,4,4]  R33       -1
    z[3,4,4]  R42       1
    z[3,4,4]  R1918     -1
    z[3,4,4]  R1919     1
    z[3,4,4]  R1924     3.2380679249763489e-01
    z[3,4,4]  R1925     9.2603355646133423e-02
    z[3,4,4]  R1926     1.0480130463838577e-01
    z[3,4,4]  R1927     0.422298789024353
    z[3,4,4]  R1928     3.1663909554481506e-01
    z[3,4,4]  R1929     1.7822766304016113e-01
    z[3,4,4]  R1930     2.3400390148162842e-01
    z[3,4,4]  R1931     1.9942112267017365e-01
    z[3,4,4]  R1932     -1.5445487201213837e-01
    z[3,4,4]  R1933     6.5681242942810059e-01
    z[3,4,4]  R1934     -6.2510512769222260e-02
    z[3,4,4]  R1935     -3.9069067686796188e-02
    z[3,4,4]  R1936     7.4388369917869568e-02
    z[3,4,4]  R1937     9.9086299538612366e-02
    z[3,4,4]  R1938     -2.6848608255386353e-01
    z[3,4,4]  R1939     -2.0704948902130127e-01
    z[3,4,4]  R1940     -6.2490370124578476e-02
    z[3,4,4]  R1941     0.140402153134346
    z[3,4,4]  R1942     5.8145960792899132e-03
    z[3,4,4]  R1943     -1.9544173777103424e-01
    z[3,4,4]  R1944     -3.7760642170906067e-01
    z[3,4,4]  R1945     -4.9730348587036133e-01
    z[3,4,4]  R1946     5.8268254995346069e-01
    z[3,4,4]  R1947     -4.0152069181203842e-02
    z[3,4,4]  R1948     -3.4616544842720032e-02
    z[3,4,4]  R1949     -1.6403122246265411e-01
    z[3,4,4]  R1950     -3.1539592146873474e-01
    z[3,4,4]  R1951     8.5781447589397430e-02
    z[3,4,4]  R1952     6.1869039200246334e-04
    z[3,4,4]  R1953     4.2012521624565125e-01
    z[3,4,4]  R1954     7.2348825633525848e-02
    z[3,4,4]  R1955     -3.6747512221336365e-01
    z[3,4,4]  R1956     -3.5000881552696228e-01
    z[3,4,4]  R1957     -1.2563988566398621e-01
    z[3,4,4]  R1958     -5.7842051982879639e-01
    z[3,4,4]  R1959     1.1661750078201294e-01
    z[3,4,4]  R1960     2.6517572999000549e-01
    z[3,4,4]  R1961     3.7823032587766647e-02
    z[3,4,4]  R1962     4.4682011008262634e-01
    z[3,4,4]  R1963     1.3806016743183136e-01
    z[3,4,4]  R1964     -7.6068562269210815e-01
    z[3,4,4]  R1965     2.7139365673065186e-01
    z[3,4,4]  R1966     -5.1270890235900879e-01
    z[3,4,4]  R1967     -7.0833325386047363e-01
    z[3,4,4]  R1968     -1.5885916352272034e-01
    z[3,4,4]  R1969     0.0097271129488945
    z[3,4,4]  R1970     2.0710526406764984e-01
    z[3,4,4]  R1971     0.0722404271364212
    z[3,4,4]  R1972     2.7952590584754944e-01
    z[3,4,4]  R1973     3.5081812739372253e-01
    z[3,4,4]  R1974     1.0469100624322891e-01
    z[3,4,4]  R1975     9.6361495554447174e-02
    z[3,4,4]  R1976     2.0615534484386444e-01
    z[3,4,4]  R1977     1.3375785201787949e-02
    z[3,4,4]  R1978     2.4304132163524628e-01
    z[3,4,4]  R1979     -2.3866172134876251e-01
    z[3,4,4]  R1980     6.7363011837005615e-01
    z[3,4,4]  R1981     -6.3374914228916168e-02
    z[3,4,4]  R1982     -2.2365452349185944e-01
    z[3,4,4]  R1983     1.0546257346868515e-01
    z[3,4,4]  R1984     -5.7577687501907349e-01
    z[3,4,4]  R1985     -3.2119274139404297e-01
    z[3,4,4]  R1986     2.7220621705055237e-01
    z[3,4,4]  R1987     1.6834603250026703e-01
    z[3,4,4]  R1988     3.4747067093849182e-01
    z[3,4,4]  R1989     1.0901419818401337e-01
    z[3,4,4]  R1990     7.6294101774692535e-02
    z[3,4,4]  R1991     2.7761319279670715e-01
    z[3,4,4]  R1992     0.539633572101593
    z[3,4,4]  R1993     -0.404040664434433
    z[3,4,4]  R1994     -7.8968626260757446e-01
    z[3,4,4]  R1995     -1.5451841056346893e-01
    z[3,4,4]  R1996     -1.2596817314624786e-01
    z[3,4,4]  R1997     3.7993314862251282e-01
    z[3,4,4]  R1998     -1.3228172063827515e-01
    z[3,4,4]  R1999     8.5183707997202873e-03
    z[3,4,4]  R2000     0.3465596139431
    z[3,4,4]  R2001     1.1181795597076416e-01
    z[3,4,4]  R2002     3.1304755806922913e-01
    z[3,4,4]  R2003     1.1650119721889496e-01
    z[3,4,4]  R2004     2.4950966238975525e-01
    z[3,4,4]  R2005     5.1488459110260010e-01
    z[3,4,4]  R2006     2.8550243377685547e-01
    z[3,4,4]  R2007     3.0487564206123352e-01
    z[3,4,4]  R2008     6.2902212142944336e-01
    z[3,4,4]  R2009     -1.4626890420913696e-01
    z[3,4,4]  R2010     0.437857985496521
    z[3,4,4]  R2011     -1.9519197940826416e-01
    z[3,4,4]  R2012     2.3031803965568542e-01
    z[3,4,4]  R2013     2.6669876649975777e-02
    z[3,4,4]  R2014     1.5016369521617889e-01
    z[3,4,4]  R2015     -2.0167241990566254e-01
    z[3,4,4]  R2016     -1.8209861218929291e-01
    z[3,4,4]  R2017     2.4066562950611115e-01
    z[3,4,4]  R2018     3.5273811221122742e-01
    z[3,4,4]  R2019     5.6484955549240112e-01
    z[3,4,4]  R2020     3.1264483928680420e-01
    z[3,4,4]  R2021     2.9566618800163269e-01
    z[3,4,4]  R2022     -2.4209970608353615e-02
    z[3,4,4]  R2023     -2.0483043789863586e-01
    z[3,4,4]  R2024     1.2161655724048615e-01
    z[3,4,4]  R2025     -0.506409227848053
    z[3,4,4]  R2026     -9.3269376084208488e-03
    z[3,4,4]  R2027     1.2939088977873325e-02
    z[3,4,4]  R2028     1.3160282373428345e-01
    z[3,4,4]  R2029     -3.7997606396675110e-01
    z[3,4,4]  R2030     1.3030199706554413e-01
    z[3,4,4]  R2031     3.5595762729644775e-01
    z[3,4,4]  R2032     -5.6280148029327393e-01
    z[3,4,4]  R2033     -6.5569287538528442e-01
    z[3,4,4]  R2034     1.7943548038601875e-02
    z[3,4,4]  R2035     -4.4281604886054993e-01
    z[3,4,4]  R2036     -9.5948047935962677e-02
    z[3,4,4]  R2037     -4.3679103255271912e-01
    z[3,4,4]  R2038     -8.6402416229248047e-01
    z[3,4,4]  R2039     -5.1386451721191406e-01
    z[3,4,4]  R2040     2.8345569968223572e-01
    z[3,4,4]  R2041     -4.8353210091590881e-01
    z[3,4,4]  R2042     6.9809418916702271e-01
    z[3,4,4]  R2043     0.84651118516922
    z[3,4,5]  R34       -1
    z[3,4,5]  R43       1
    z[3,4,5]  R1920     -1
    z[3,4,5]  R1921     1
    z[3,4,5]  R1924     1.7003534734249115e-01
    z[3,4,5]  R1925     1.1630651354789734e-01
    z[3,4,5]  R1926     -5.2712593227624893e-02
    z[3,4,5]  R1927     -2.5786796212196350e-01
    z[3,4,5]  R1928     1.1628390848636627e-01
    z[3,4,5]  R1929     -4.6830984950065613e-01
    z[3,4,5]  R1930     -5.0291174650192261e-01
    z[3,4,5]  R1931     -0.607593297958374
    z[3,4,5]  R1932     -3.6988526582717896e-01
    z[3,4,5]  R1933     -2.1564084291458130e-01
    z[3,4,5]  R1934     3.7687757611274719e-01
    z[3,4,5]  R1935     1.1666663736104965e-01
    z[3,4,5]  R1936     -3.0345454812049866e-01
    z[3,4,5]  R1937     -2.5710278749465942e-01
    z[3,4,5]  R1938     -2.6696819067001343e-01
    z[3,4,5]  R1939     -0.0908493921160698
    z[3,4,5]  R1940     -4.4579851627349854e-01
    z[3,4,5]  R1941     -2.9506006836891174e-01
    z[3,4,5]  R1942     -1.4896060526371002e-01
    z[3,4,5]  R1943     -2.2167436778545380e-01
    z[3,4,5]  R1944     1.7484763264656067e-01
    z[3,4,5]  R1945     -1.1869736760854721e-01
    z[3,4,5]  R1946     2.9007965326309204e-01
    z[3,4,5]  R1947     2.2567853331565857e-01
    z[3,4,5]  R1948     1.0491573251783848e-02
    z[3,4,5]  R1949     -5.9337094426155090e-02
    z[3,4,5]  R1950     -1.8370407819747925e-01
    z[3,4,5]  R1951     -1.0330832563340664e-02
    z[3,4,5]  R1952     -1.5055145323276520e-01
    z[3,4,5]  R1953     6.3797837495803833e-01
    z[3,4,5]  R1954     -1.9927389919757843e-01
    z[3,4,5]  R1955     2.1083581447601318e-01
    z[3,4,5]  R1956     1.5214255452156067e-01
    z[3,4,5]  R1957     4.8982560634613037e-02
    z[3,4,5]  R1958     3.4996861219406128e-01
    z[3,4,5]  R1959     -1.7084781575249508e-05
    z[3,4,5]  R1960     -2.6103073358535767e-01
    z[3,4,5]  R1961     1.1362256854772568e-01
    z[3,4,5]  R1962     4.3569797277450562e-01
    z[3,4,5]  R1963     -2.9749885201454163e-01
    z[3,4,5]  R1964     4.0410479903221130e-01
    z[3,4,5]  R1965     1.6149044036865234e-01
    z[3,4,5]  R1966     1.4994250610470772e-02
    z[3,4,5]  R1967     7.7708929777145386e-02
    z[3,4,5]  R1968     -4.4270315766334534e-01
    z[3,4,5]  R1969     -0.305593341588974
    z[3,4,5]  R1970     3.9728847146034241e-01
    z[3,4,5]  R1971     -0.0940985307097435
    z[3,4,5]  R1972     5.1179504394531250e-01
    z[3,4,5]  R1973     2.4010887742042542e-01
    z[3,4,5]  R1974     -2.3609678447246552e-01
    z[3,4,5]  R1975     -2.2068510297685862e-03
    z[3,4,5]  R1976     3.9398795366287231e-01
    z[3,4,5]  R1977     0.347615510225296
    z[3,4,5]  R1978     1.8736734986305237e-01
    z[3,4,5]  R1979     2.6821252703666687e-01
    z[3,4,5]  R1980     1.3194820284843445e-01
    z[3,4,5]  R1981     2.6607644557952881e-01
    z[3,4,5]  R1982     -7.8134588897228241e-02
    z[3,4,5]  R1983     0.392145037651062
    z[3,4,5]  R1984     3.9392352104187012e-01
    z[3,4,5]  R1985     4.7437033057212830e-01
    z[3,4,5]  R1986     -5.4812286049127579e-02
    z[3,4,5]  R1987     -3.8520131260156631e-02
    z[3,4,5]  R1988     7.0141452550888062e-01
    z[3,4,5]  R1989     1.4357431232929230e-01
    z[3,4,5]  R1990     3.5824459791183472e-01
    z[3,4,5]  R1991     1.4996562898159027e-01
    z[3,4,5]  R1992     2.7571621537208557e-01
    z[3,4,5]  R1993     4.4770732522010803e-01
    z[3,4,5]  R1994     3.0636849999427795e-01
    z[3,4,5]  R1995     2.2403483092784882e-01
    z[3,4,5]  R1996     1.8599498271942139e-01
    z[3,4,5]  R1997     3.1060692854225636e-03
    z[3,4,5]  R1998     -2.6541724801063538e-01
    z[3,4,5]  R1999     0.613767147064209
    z[3,4,5]  R2000     4.5021235942840576e-01
    z[3,4,5]  R2001     -1.7709356546401978e-01
    z[3,4,5]  R2002     7.0006436109542847e-01
    z[3,4,5]  R2003     -1.5343381464481354e-01
    z[3,4,5]  R2004     -1.9948348402976990e-01
    z[3,4,5]  R2005     5.8829028159379959e-02
    z[3,4,5]  R2006     -1.3347668945789337e-01
    z[3,4,5]  R2007     2.7100238204002380e-01
    z[3,4,5]  R2008     2.9846087098121643e-01
    z[3,4,5]  R2009     4.8254373669624329e-01
    z[3,4,5]  R2010     1.7485502362251282e-01
    z[3,4,5]  R2011     7.9436957836151123e-01
    z[3,4,5]  R2012     -3.3977828919887543e-02
    z[3,4,5]  R2013     2.1517501771450043e-01
    z[3,4,5]  R2014     4.9972828477621078e-02
    z[3,4,5]  R2015     -3.2711166143417358e-01
    z[3,4,5]  R2016     1.0573945939540863e-01
    z[3,4,5]  R2017     0.384998619556427
    z[3,4,5]  R2018     -2.5444485247135162e-02
    z[3,4,5]  R2019     -3.2719689607620239e-01
    z[3,4,5]  R2020     6.6548407077789307e-01
    z[3,4,5]  R2021     3.5918089747428894e-01
    z[3,4,5]  R2022     -8.1948794424533844e-02
    z[3,4,5]  R2023     1.1423498392105103e-02
    z[3,4,5]  R2024     1.6303362324833870e-02
    z[3,4,5]  R2025     0.0700659304857254
    z[3,4,5]  R2026     3.2645413279533386e-01
    z[3,4,5]  R2027     2.0752148702740669e-03
    z[3,4,5]  R2028     -5.4658412933349609e-01
    z[3,4,5]  R2029     2.6304228231310844e-02
    z[3,4,5]  R2030     4.7758507728576660e-01
    z[3,4,5]  R2031     3.8313046097755432e-01
    z[3,4,5]  R2032     -2.2911007702350616e-01
    z[3,4,5]  R2033     -3.0044120550155640e-01
    z[3,4,5]  R2034     5.3282942622900009e-02
    z[3,4,5]  R2035     0.546783983707428
    z[3,4,5]  R2036     3.4522768855094910e-01
    z[3,4,5]  R2037     -1.6942660510540009e-01
    z[3,4,5]  R2038     -1.2802666425704956e-01
    z[3,4,5]  R2039     -3.9604511857032776e-01
    z[3,4,5]  R2040     1.8112035095691681e-01
    z[3,4,5]  R2041     1.8203233182430267e-01
    z[3,4,5]  R2042     -1.9573500752449036e-01
    z[3,4,5]  R2043     1.5885604918003082e-01
    z[3,4,6]  R35       -1
    z[3,4,6]  R44       1
    z[3,4,6]  R1922     -1
    z[3,4,6]  R1923     1
    z[3,4,6]  R1924     -3.3373942971229553e-01
    z[3,4,6]  R1925     -1.8317398428916931e-01
    z[3,4,6]  R1926     -4.4695568084716797e-01
    z[3,4,6]  R1927     -3.0181798338890076e-01
    z[3,4,6]  R1928     4.8480287194252014e-01
    z[3,4,6]  R1929     2.3972646892070770e-01
    z[3,4,6]  R1930     3.9511356502771378e-02
    z[3,4,6]  R1931     -4.6331661939620972e-01
    z[3,4,6]  R1932     5.5952298641204834e-01
    z[3,4,6]  R1933     2.2931481897830963e-01
    z[3,4,6]  R1934     3.6947321146726608e-02
    z[3,4,6]  R1935     -4.3364234268665314e-02
    z[3,4,6]  R1936     -6.3689008355140686e-02
    z[3,4,6]  R1937     6.7253686487674713e-02
    z[3,4,6]  R1938     8.3075987640768290e-04
    z[3,4,6]  R1939     0.238666370511055
    z[3,4,6]  R1940     1.5998931229114532e-01
    z[3,4,6]  R1941     -7.2067372500896454e-02
    z[3,4,6]  R1942     1.7402539029717445e-02
    z[3,4,6]  R1943     -4.5787545968778431e-04
    z[3,4,6]  R1944     5.6041479110717773e-01
    z[3,4,6]  R1945     -2.5544339418411255e-01
    z[3,4,6]  R1946     -3.4603810310363770e-01
    z[3,4,6]  R1947     2.1228450536727905e-01
    z[3,4,6]  R1948     -5.5021807551383972e-02
    z[3,4,6]  R1949     4.1464298963546753e-02
    z[3,4,6]  R1950     -2.2769320011138916e-01
    z[3,4,6]  R1951     1.6541224718093872e-01
    z[3,4,6]  R1952     -4.2195141315460205e-02
    z[3,4,6]  R1953     -2.9661238193511963e-01
    z[3,4,6]  R1954     -1.7342790961265564e-02
    z[3,4,6]  R1955     -0.442648321390152
    z[3,4,6]  R1956     -2.8813473880290985e-02
    z[3,4,6]  R1957     -0.0617663636803627
    z[3,4,6]  R1958     2.7119159698486328e-01
    z[3,4,6]  R1959     3.9645963907241821e-01
    z[3,4,6]  R1960     0.0939316526055336
    z[3,4,6]  R1961     -5.6069320440292358e-01
    z[3,4,6]  R1962     5.5307167768478394e-01
    z[3,4,6]  R1963     2.1062527596950531e-01
    z[3,4,6]  R1964     -3.2975524663925171e-01
    z[3,4,6]  R1965     -1.8817789852619171e-01
    z[3,4,6]  R1966     -3.1503298878669739e-01
    z[3,4,6]  R1967     7.3851831257343292e-02
    z[3,4,6]  R1968     -1.4506006240844727e-01
    z[3,4,6]  R1969     -2.0001192390918732e-01
    z[3,4,6]  R1970     -3.4732496738433838e-01
    z[3,4,6]  R1971     -2.6812374591827393e-01
    z[3,4,6]  R1972     3.8313648104667664e-01
    z[3,4,6]  R1973     0.0815952867269516
    z[3,4,6]  R1974     1.8501979112625122e-01
    z[3,4,6]  R1975     -1.1845734715461731e-01
    z[3,4,6]  R1976     -5.1623537729028612e-06
    z[3,4,6]  R1977     -1.0647686198353767e-02
    z[3,4,6]  R1978     -9.4960257411003113e-03
    z[3,4,6]  R1979     4.1246637701988220e-01
    z[3,4,6]  R1980     3.5161346197128296e-02
    z[3,4,6]  R1981     6.0502803325653076e-01
    z[3,4,6]  R1982     -5.1895850896835327e-01
    z[3,4,6]  R1983     -7.1474784612655640e-01
    z[3,4,6]  R1984     -1.2056052684783936e-01
    z[3,4,6]  R1985     2.2381272912025452e-01
    z[3,4,6]  R1986     4.8936480283737183e-01
    z[3,4,6]  R1987     1.7373697459697723e-01
    z[3,4,6]  R1988     -2.0971101522445679e-01
    z[3,4,6]  R1989     -6.7153668403625488e-01
    z[3,4,6]  R1990     2.6181042194366455e-01
    z[3,4,6]  R1991     -6.9374436140060425e-01
    z[3,4,6]  R1992     -5.1352715492248535e-01
    z[3,4,6]  R1993     2.4896657466888428e-01
    z[3,4,6]  R1994     1.2381459027528763e-01
    z[3,4,6]  R1995     -3.5530999302864075e-02
    z[3,4,6]  R1996     6.5191254019737244e-02
    z[3,4,6]  R1997     4.6483924984931946e-01
    z[3,4,6]  R1998     -3.1138095259666443e-01
    z[3,4,6]  R1999     4.9342062324285507e-02
    z[3,4,6]  R2000     -1.0222411900758743e-01
    z[3,4,6]  R2001     3.9326608180999756e-01
    z[3,4,6]  R2002     -0.0815378800034523
    z[3,4,6]  R2003     -9.5251612365245819e-02
    z[3,4,6]  R2004     4.2908138036727905e-01
    z[3,4,6]  R2005     2.3700079321861267e-01
    z[3,4,6]  R2006     3.2113802433013916e-01
    z[3,4,6]  R2007     6.2269139289855957e-01
    z[3,4,6]  R2008     -2.3689050227403641e-02
    z[3,4,6]  R2009     -6.3128936290740967e-01
    z[3,4,6]  R2010     -2.9839566349983215e-01
    z[3,4,6]  R2011     -4.2567479610443115e-01
    z[3,4,6]  R2012     1.7113989591598511e-01
    z[3,4,6]  R2013     -0.250872939825058
    z[3,4,6]  R2014     1.6514627635478973e-01
    z[3,4,6]  R2015     6.5292038023471832e-02
    z[3,4,6]  R2016     -1.0161355137825012e-01
    z[3,4,6]  R2017     -2.9342442750930786e-01
    z[3,4,6]  R2018     1.9883975386619568e-01
    z[3,4,6]  R2019     1.8315419554710388e-01
    z[3,4,6]  R2020     -1.8604686483740807e-02
    z[3,4,6]  R2021     5.9675145149230957e-01
    z[3,4,6]  R2022     -3.7798005342483521e-01
    z[3,4,6]  R2023     3.4525832533836365e-01
    z[3,4,6]  R2024     -4.4347429275512695e-01
    z[3,4,6]  R2025     1.9795902073383331e-01
    z[3,4,6]  R2026     2.3786519467830658e-01
    z[3,4,6]  R2027     2.4091006815433502e-01
    z[3,4,6]  R2028     3.1069728732109070e-01
    z[3,4,6]  R2029     1.4187897741794586e-01
    z[3,4,6]  R2030     -3.1719669699668884e-01
    z[3,4,6]  R2031     2.6061311364173889e-01
    z[3,4,6]  R2032     2.4852724373340607e-01
    z[3,4,6]  R2033     7.5940592214465141e-03
    z[3,4,6]  R2034     4.6995532512664795e-01
    z[3,4,6]  R2035     -1.1474460363388062e-01
    z[3,4,6]  R2036     -1.5504789538681507e-02
    z[3,4,6]  R2037     1.5785694122314453e-02
    z[3,4,6]  R2038     -9.7251825034618378e-02
    z[3,4,6]  R2039     5.5259648710489273e-02
    z[3,4,6]  R2040     -1.8019108474254608e-01
    z[3,4,6]  R2041     -1.2802480161190033e-01
    z[3,4,6]  R2042     9.7086921334266663e-02
    z[3,4,6]  R2043     0.328484445810318
    z[4,3,0]  R29       1
    z[4,3,0]  R38       -1
    z[4,3,0]  R2044     -1
    z[4,3,0]  R2045     1
    z[4,3,0]  R2058     -4.3566304445266724e-01
    z[4,3,0]  R2059     1.1860569566488266e-01
    z[4,3,0]  R2060     -3.3444091677665710e-01
    z[4,3,0]  R2061     -4.9569246172904968e-01
    z[4,3,0]  R2062     -4.7821506857872009e-01
    z[4,3,0]  R2063     -2.5301378965377808e-01
    z[4,3,0]  R2064     0.00965464673936367
    z[4,3,0]  R2065     -7.8255213797092438e-02
    z[4,3,0]  R2066     1.2590855360031128e-01
    z[4,3,0]  R2067     -1.0428953170776367e-01
    z[4,3,0]  R2068     0.323359876871109
    z[4,3,0]  R2069     3.7382391095161438e-01
    z[4,3,0]  R2070     7.9257696866989136e-02
    z[4,3,0]  R2071     3.5170421004295349e-01
    z[4,3,0]  R2072     3.0049356818199158e-01
    z[4,3,0]  R2073     7.3320543766021729e-01
    z[4,3,0]  R2074     1.4527393877506256e-01
    z[4,3,0]  R2075     6.4717435836791992e-01
    z[4,3,0]  R2076     -1.5803582966327667e-01
    z[4,3,0]  R2077     -3.5336855053901672e-01
    z[4,3,0]  R2078     2.2044897079467773e-01
    z[4,3,0]  R2079     0.0868205651640892
    z[4,3,0]  R2080     -8.1602618098258972e-02
    z[4,3,0]  R2081     2.1975185722112656e-02
    z[4,3,0]  R2082     7.1332126855850220e-02
    z[4,3,0]  R2083     1.3148538768291473e-01
    z[4,3,0]  R2084     -5.4136735200881958e-01
    z[4,3,0]  R2085     5.0642073154449463e-01
    z[4,3,0]  R2086     1.5650652348995209e-01
    z[4,3,0]  R2087     -1.3747981190681458e-01
    z[4,3,0]  R2088     -2.3660942912101746e-02
    z[4,3,0]  R2089     -6.7642802000045776e-01
    z[4,3,0]  R2090     -4.9517515301704407e-01
    z[4,3,0]  R2091     -2.8080910444259644e-01
    z[4,3,0]  R2092     -3.0979430675506592e-01
    z[4,3,0]  R2093     -4.3818223476409912e-01
    z[4,3,0]  R2094     -3.4521660208702087e-01
    z[4,3,0]  R2095     2.8427250217646360e-03
    z[4,3,0]  R2096     -6.6371224820613861e-02
    z[4,3,0]  R2097     -2.6585647463798523e-01
    z[4,3,0]  R2098     4.7867482900619507e-01
    z[4,3,0]  R2099     -5.8776414394378662e-01
    z[4,3,0]  R2100     -3.5246106982231140e-01
    z[4,3,0]  R2101     -6.1804109811782837e-01
    z[4,3,0]  R2102     -2.4182218313217163e-01
    z[4,3,0]  R2103     -0.525830864906311
    z[4,3,0]  R2104     -5.7502126693725586e-01
    z[4,3,0]  R2105     -4.0891861915588379e-01
    z[4,3,0]  R2106     -4.4103786349296570e-01
    z[4,3,0]  R2107     -0.522939145565033
    z[4,3,0]  R2108     2.4460309743881226e-01
    z[4,3,0]  R2109     4.2715522646903992e-01
    z[4,3,0]  R2110     3.2835906744003296e-01
    z[4,3,0]  R2111     5.5589717626571655e-01
    z[4,3,0]  R2112     -1.1993542313575745e-01
    z[4,3,0]  R2113     5.2645742893218994e-01
    z[4,3,0]  R2114     4.1524934768676758e-01
    z[4,3,0]  R2115     4.1558876633644104e-01
    z[4,3,0]  R2116     5.9942883253097534e-01
    z[4,3,0]  R2117     2.7454838156700134e-02
    z[4,3,0]  R2118     1.4633931219577789e-01
    z[4,3,0]  R2119     3.0731040239334106e-01
    z[4,3,0]  R2120     5.2321493625640869e-01
    z[4,3,0]  R2121     2.3162433505058289e-01
    z[4,3,0]  R2122     0.352159321308136
    z[4,3,0]  R2123     4.1018098592758179e-01
    z[4,3,0]  R2124     6.8061405420303345e-01
    z[4,3,0]  R2125     0.587196409702301
    z[4,3,0]  R2126     4.5920401811599731e-01
    z[4,3,0]  R2127     4.8823356628417969e-01
    z[4,3,0]  R2128     2.1337687969207764e-01
    z[4,3,0]  R2129     0.702157199382782
    z[4,3,0]  R2130     4.9267145991325378e-01
    z[4,3,0]  R2131     1.6420282423496246e-01
    z[4,3,0]  R2132     3.8145303726196289e-01
    z[4,3,0]  R2133     6.1188286542892456e-01
    z[4,3,0]  R2134     4.6825012564659119e-01
    z[4,3,0]  R2135     4.9199223518371582e-01
    z[4,3,0]  R2136     1.8281713128089905e-02
    z[4,3,0]  R2137     0.5074462890625
    z[4,3,0]  R2138     2.9385295510292053e-01
    z[4,3,0]  R2139     4.3124410510063171e-01
    z[4,3,0]  R2140     -5.7759042829275131e-02
    z[4,3,0]  R2141     5.1795196533203125e-01
    z[4,3,0]  R2142     6.3703131675720215e-01
    z[4,3,0]  R2143     0.357229620218277
    z[4,3,0]  R2144     -5.2753275632858276e-01
    z[4,3,0]  R2145     2.2294804453849792e-01
    z[4,3,0]  R2146     0.316459059715271
    z[4,3,0]  R2147     2.4885358288884163e-02
    z[4,3,0]  R2148     3.5174342989921570e-01
    z[4,3,0]  R2149     3.0526661872863770e-01
    z[4,3,0]  R2150     -2.0106610655784607e-01
    z[4,3,0]  R2151     2.3342198133468628e-01
    z[4,3,0]  R2152     3.5342502593994141e-01
    z[4,3,0]  R2153     1.2162110209465027e-01
    z[4,3,0]  R2154     9.8546624183654785e-02
    z[4,3,0]  R2155     5.0777590274810791e-01
    z[4,3,0]  R2156     -2.1205723285675049e-01
    z[4,3,0]  R2157     -2.2117216885089874e-01
    z[4,3,0]  R2158     6.5122477710247040e-02
    z[4,3,0]  R2159     3.5603755712509155e-01
    z[4,3,0]  R2160     0.0617666058242321
    z[4,3,0]  R2161     5.4670524597167969e-01
    z[4,3,0]  R2162     2.3764832317829132e-01
    z[4,3,0]  R2163     4.9069947004318237e-01
    z[4,3,0]  R2164     2.6874250173568726e-01
    z[4,3,0]  R2165     3.3461397886276245e-01
    z[4,3,0]  R2166     5.8027577400207520e-01
    z[4,3,0]  R2167     9.4387523829936981e-02
    z[4,3,0]  R2168     -5.5177497863769531e-01
    z[4,3,0]  R2169     -4.0907946228981018e-01
    z[4,3,0]  R2170     3.0622461438179016e-01
    z[4,3,0]  R2171     2.8966364264488220e-01
    z[4,3,0]  R2172     1.6090807318687439e-01
    z[4,3,0]  R2173     4.8265120387077332e-01
    z[4,3,0]  R2174     3.9025691151618958e-01
    z[4,3,0]  R2175     2.1352705359458923e-01
    z[4,3,0]  R2176     -0.0727607011795044
    z[4,3,0]  R2177     -3.2407945394515991e-01
    z[4,3,1]  R30       1
    z[4,3,1]  R39       -1
    z[4,3,1]  R2046     -1
    z[4,3,1]  R2047     1
    z[4,3,1]  R2058     7.5889408588409424e-01
    z[4,3,1]  R2059     7.5472515821456909e-01
    z[4,3,1]  R2060     8.6888861656188965e-01
    z[4,3,1]  R2061     0.603097140789032
    z[4,3,1]  R2062     5.7544064521789551e-01
    z[4,3,1]  R2063     0.612223744392395
    z[4,3,1]  R2064     6.5207844972610474e-01
    z[4,3,1]  R2065     6.4350157976150513e-01
    z[4,3,1]  R2066     -8.4987187385559082e-01
    z[4,3,1]  R2067     -8.2063728570938110e-01
    z[4,3,1]  R2068     7.5189995765686035e-01
    z[4,3,1]  R2069     4.3783202767372131e-01
    z[4,3,1]  R2070     -3.8606387376785278e-01
    z[4,3,1]  R2071     -2.4214853346347809e-01
    z[4,3,1]  R2072     -3.1058117747306824e-01
    z[4,3,1]  R2073     -2.2177360951900482e-01
    z[4,3,1]  R2074     -1.5315692871809006e-02
    z[4,3,1]  R2075     -3.2986709475517273e-01
    z[4,3,1]  R2076     2.3476628959178925e-01
    z[4,3,1]  R2077     1.9111397862434387e-01
    z[4,3,1]  R2078     7.2244065999984741e-01
    z[4,3,1]  R2079     5.5984967947006226e-01
    z[4,3,1]  R2080     4.1613170504570007e-01
    z[4,3,1]  R2081     4.0391734242439270e-01
    z[4,3,1]  R2082     4.3273970484733582e-01
    z[4,3,1]  R2083     3.8729482889175415e-01
    z[4,3,1]  R2084     -2.0500813424587250e-01
    z[4,3,1]  R2085     -6.2468174844980240e-02
    z[4,3,1]  R2086     -5.0921678543090820e-02
    z[4,3,1]  R2087     -3.5752475261688232e-01
    z[4,3,1]  R2088     0.842336893081665
    z[4,3,1]  R2089     6.8349009752273560e-01
    z[4,3,1]  R2090     6.7841392755508423e-01
    z[4,3,1]  R2091     6.7690467834472656e-01
    z[4,3,1]  R2092     6.4372408390045166e-01
    z[4,3,1]  R2093     5.6303697824478149e-01
    z[4,3,1]  R2094     5.4218709468841553e-01
    z[4,3,1]  R2095     5.9074205160140991e-01
    z[4,3,1]  R2096     5.7622200250625610e-01
    z[4,3,1]  R2097     5.2282029390335083e-01
    z[4,3,1]  R2098     2.6429495215415955e-01
    z[4,3,1]  R2099     -6.3401788473129272e-01
    z[4,3,1]  R2100     -8.5421293973922729e-01
    z[4,3,1]  R2101     -0.698803186416626
    z[4,3,1]  R2102     -8.3294248580932617e-01
    z[4,3,1]  R2103     -6.6108095645904541e-01
    z[4,3,1]  R2104     -5.9603250026702881e-01
    z[4,3,1]  R2105     -5.2921229600906372e-01
    z[4,3,1]  R2106     -5.1782667636871338e-01
    z[4,3,1]  R2107     -5.2858549356460571e-01
    z[4,3,1]  R2108     4.1859099268913269e-01
    z[4,3,1]  R2109     4.9714335799217224e-01
    z[4,3,1]  R2110     -0.0708140879869461
    z[4,3,1]  R2111     -4.7793912887573242e-01
    z[4,3,1]  R2112     -3.9171531796455383e-01
    z[4,3,1]  R2113     -3.1207174062728882e-01
    z[4,3,1]  R2114     -2.1651053428649902e-01
    z[4,3,1]  R2115     -3.1970804929733276e-01
    z[4,3,1]  R2116     -2.5623393058776855e-01
    z[4,3,1]  R2117     2.4614408612251282e-01
    z[4,3,1]  R2118     -7.6266628503799438e-01
    z[4,3,1]  R2119     -3.6327430605888367e-01
    z[4,3,1]  R2120     2.2373306751251221e-01
    z[4,3,1]  R2121     -4.9296915531158447e-01
    z[4,3,1]  R2122     5.6185829639434814e-01
    z[4,3,1]  R2123     7.7729612588882446e-01
    z[4,3,1]  R2124     5.1344454288482666e-01
    z[4,3,1]  R2125     -1.8832521140575409e-01
    z[4,3,1]  R2126     2.5979763269424438e-01
    z[4,3,1]  R2127     -3.6433655023574829e-01
    z[4,3,1]  R2128     2.9991710186004639e-01
    z[4,3,1]  R2129     -1.8482691049575806e-01
    z[4,3,1]  R2130     5.1216334104537964e-01
    z[4,3,1]  R2131     5.9576076269149780e-01
    z[4,3,1]  R2132     0.552386999130249
    z[4,3,1]  R2133     4.9788832664489746e-01
    z[4,3,1]  R2134     6.2892836332321167e-01
    z[4,3,1]  R2135     7.0189118385314941e-01
    z[4,3,1]  R2136     -2.1042430400848389e-01
    z[4,3,1]  R2137     7.1531242132186890e-01
    z[4,3,1]  R2138     7.3811477422714233e-01
    z[4,3,1]  R2139     4.6012678742408752e-01
    z[4,3,1]  R2140     -2.3309087753295898e-01
    z[4,3,1]  R2141     6.7887884378433228e-01
    z[4,3,1]  R2142     6.1221557855606079e-01
    z[4,3,1]  R2143     7.4682730436325073e-01
    z[4,3,1]  R2144     -2.3578248918056488e-01
    z[4,3,1]  R2145     -3.9649134874343872e-01
    z[4,3,1]  R2146     -1.2682583928108215e-01
    z[4,3,1]  R2147     1.2493968755006790e-01
    z[4,3,1]  R2148     2.9076436161994934e-01
    z[4,3,1]  R2149     7.1940815448760986e-01
    z[4,3,1]  R2150     -5.1374858617782593e-01
    z[4,3,1]  R2151     -3.2952564954757690e-01
    z[4,3,1]  R2152     1.0562562942504883e-01
    z[4,3,1]  R2153     -5.8447830379009247e-03
    z[4,3,1]  R2154     -6.7971736192703247e-01
    z[4,3,1]  R2155     0.0712711289525032
    z[4,3,1]  R2156     -2.0662029087543488e-01
    z[4,3,1]  R2157     1.6451099514961243e-01
    z[4,3,1]  R2158     4.7735238075256348e-01
    z[4,3,1]  R2159     -4.0121245384216309e-01
    z[4,3,1]  R2160     -7.5811302661895752e-01
    z[4,3,1]  R2161     -6.5737382101360708e-05
    z[4,3,1]  R2162     -8.6188906431198120e-01
    z[4,3,1]  R2163     -1.1684004217386246e-01
    z[4,3,1]  R2164     3.5133507847785950e-01
    z[4,3,1]  R2165     -8.4839671850204468e-02
    z[4,3,1]  R2166     9.1011054813861847e-02
    z[4,3,1]  R2167     -1.2946946918964386e-01
    z[4,3,1]  R2168     -4.4211155176162720e-01
    z[4,3,1]  R2169     -4.5028707385063171e-01
    z[4,3,1]  R2170     -8.7053716182708740e-02
    z[4,3,1]  R2171     2.7605205774307251e-01
    z[4,3,1]  R2172     1.8752078711986542e-01
    z[4,3,1]  R2173     8.2377985119819641e-02
    z[4,3,1]  R2174     8.8901974260807037e-02
    z[4,3,1]  R2175     1.4832818508148193e-01
    z[4,3,1]  R2176     -7.2970294952392578e-01
    z[4,3,1]  R2177     -7.9550343751907349e-01
    z[4,3,2]  R31       1
    z[4,3,2]  R40       -1
    z[4,3,2]  R2048     -1
    z[4,3,2]  R2049     1
    z[4,3,2]  R2058     1.1177688837051392e-01
    z[4,3,2]  R2059     -4.3407250195741653e-02
    z[4,3,2]  R2060     3.0480053275823593e-02
    z[4,3,2]  R2061     3.0818262696266174e-01
    z[4,3,2]  R2062     4.3888410925865173e-01
    z[4,3,2]  R2063     -6.2086533755064011e-02
    z[4,3,2]  R2064     1.2212823331356049e-01
    z[4,3,2]  R2065     -7.3171287775039673e-02
    z[4,3,2]  R2066     3.2754510641098022e-01
    z[4,3,2]  R2067     -2.2392237558960915e-02
    z[4,3,2]  R2068     3.8310687988996506e-02
    z[4,3,2]  R2069     3.6883878707885742e-01
    z[4,3,2]  R2070     -1.6428200900554657e-01
    z[4,3,2]  R2071     -2.7812442183494568e-01
    z[4,3,2]  R2072     -2.9574507474899292e-01
    z[4,3,2]  R2073     -2.9847124218940735e-01
    z[4,3,2]  R2074     2.7253448963165283e-01
    z[4,3,2]  R2075     -2.4370205402374268e-01
    z[4,3,2]  R2076     -0.265984445810318
    z[4,3,2]  R2077     -6.4389117062091827e-02
    z[4,3,2]  R2078     -4.4989919662475586e-01
    z[4,3,2]  R2079     -7.8759752213954926e-02
    z[4,3,2]  R2080     -1.0610629618167877e-01
    z[4,3,2]  R2081     0.192478746175766
    z[4,3,2]  R2082     -1.1112035065889359e-01
    z[4,3,2]  R2083     5.6924498081207275e-01
    z[4,3,2]  R2084     3.7033399939537048e-01
    z[4,3,2]  R2085     8.6332149803638458e-03
    z[4,3,2]  R2086     1.4917572028934956e-02
    z[4,3,2]  R2087     -4.1301719844341278e-02
    z[4,3,2]  R2088     1.4451944828033447e-01
    z[4,3,2]  R2089     -6.6902157850563526e-03
    z[4,3,2]  R2090     -2.3741452395915985e-01
    z[4,3,2]  R2091     -3.3453068137168884e-01
    z[4,3,2]  R2092     -1.7780803143978119e-01
    z[4,3,2]  R2093     3.5348970443010330e-02
    z[4,3,2]  R2094     4.5870873332023621e-01
    z[4,3,2]  R2095     1.5734094381332397e-01
    z[4,3,2]  R2096     -0.425411194562912
    z[4,3,2]  R2097     3.5178694128990173e-01
    z[4,3,2]  R2098     6.6110062599182129e-01
    z[4,3,2]  R2099     -2.9593446850776672e-01
    z[4,3,2]  R2100     -7.1088381111621857e-02
    z[4,3,2]  R2101     -0.0973065197467804
    z[4,3,2]  R2102     -2.5544852018356323e-01
    z[4,3,2]  R2103     -2.9635587334632874e-01
    z[4,3,2]  R2104     -2.8497090935707092e-01
    z[4,3,2]  R2105     -6.3906210660934448e-01
    z[4,3,2]  R2106     -0.667457103729248
    z[4,3,2]  R2107     -5.7527345418930054e-01
    z[4,3,2]  R2108     5.1331037282943726e-01
    z[4,3,2]  R2109     1.8045547604560852e-01
    z[4,3,2]  R2110     3.1240659952163696e-01
    z[4,3,2]  R2111     1.0660746693611145e-01
    z[4,3,2]  R2112     4.5155549049377441e-01
    z[4,3,2]  R2113     2.7448868751525879e-01
    z[4,3,2]  R2114     -5.2570984698832035e-03
    z[4,3,2]  R2115     5.1050531864166260e-01
    z[4,3,2]  R2116     3.7498977035284042e-02
    z[4,3,2]  R2117     4.7652056813240051e-01
    z[4,3,2]  R2118     2.1068260073661804e-01
    z[4,3,2]  R2119     3.4870314598083496e-01
    z[4,3,2]  R2120     6.9835472106933594e-01
    z[4,3,2]  R2121     7.1132189035415649e-01
    z[4,3,2]  R2122     1.3834661245346069e-01
    z[4,3,2]  R2123     2.4175962433218956e-02
    z[4,3,2]  R2124     1.1042704433202744e-01
    z[4,3,2]  R2125     1.0658313333988190e-01
    z[4,3,2]  R2126     1.4647732675075531e-01
    z[4,3,2]  R2127     4.9737501144409180e-01
    z[4,3,2]  R2128     6.2148753553628922e-02
    z[4,3,2]  R2129     2.6213395595550537e-01
    z[4,3,2]  R2130     -9.8603196442127228e-02
    z[4,3,2]  R2131     -1.4586040377616882e-01
    z[4,3,2]  R2132     -1.4332130551338196e-01
    z[4,3,2]  R2133     1.5385118126869202e-01
    z[4,3,2]  R2134     2.2596241533756256e-01
    z[4,3,2]  R2135     7.3518723249435425e-02
    z[4,3,2]  R2136     2.5252890586853027e-01
    z[4,3,2]  R2137     1.7043286561965942e-01
    z[4,3,2]  R2138     2.5744667649269104e-01
    z[4,3,2]  R2139     6.8309265375137329e-01
    z[4,3,2]  R2140     5.0319695472717285e-01
    z[4,3,2]  R2141     3.5586360096931458e-01
    z[4,3,2]  R2142     3.0896160006523132e-01
    z[4,3,2]  R2143     -0.069015271961689
    z[4,3,2]  R2144     -2.5801885128021240e-01
    z[4,3,2]  R2145     4.8450362682342529e-01
    z[4,3,2]  R2146     6.9639271497726440e-01
    z[4,3,2]  R2147     2.9191273450851440e-01
    z[4,3,2]  R2148     -4.8016417026519775e-01
    z[4,3,2]  R2149     -1.0359817743301392e-01
    z[4,3,2]  R2150     -4.5071166753768921e-01
    z[4,3,2]  R2151     8.4194815158843994e-01
    z[4,3,2]  R2152     -9.0492151677608490e-02
    z[4,3,2]  R2153     6.8993037939071655e-01
    z[4,3,2]  R2154     2.0763725042343140e-01
    z[4,3,2]  R2155     3.7901934981346130e-01
    z[4,3,2]  R2156     -4.2340385913848877e-01
    z[4,3,2]  R2157     -5.7228218764066696e-02
    z[4,3,2]  R2158     1.8733383715152740e-01
    z[4,3,2]  R2159     6.4164972305297852e-01
    z[4,3,2]  R2160     2.5032129883766174e-01
    z[4,3,2]  R2161     3.3896341919898987e-01
    z[4,3,2]  R2162     0.0697273463010788
    z[4,3,2]  R2163     -1.9183041527867317e-02
    z[4,3,2]  R2164     1.4869990944862366e-01
    z[4,3,2]  R2165     6.1271142959594727e-01
    z[4,3,2]  R2166     -4.8083987087011337e-02
    z[4,3,2]  R2167     8.8728785514831543e-01
    z[4,3,2]  R2168     -3.7146055698394775e-01
    z[4,3,2]  R2169     -3.4338730573654175e-01
    z[4,3,2]  R2170     7.0441210269927979e-01
    z[4,3,2]  R2171     3.3388638496398926e-01
    z[4,3,2]  R2172     6.1313128471374512e-01
    z[4,3,2]  R2173     2.8575578331947327e-01
    z[4,3,2]  R2174     2.8835749626159668e-01
    z[4,3,2]  R2175     2.1216154098510742e-01
    z[4,3,2]  R2176     5.5589151382446289e-01
    z[4,3,2]  R2177     9.2491582036018372e-02
    z[4,3,3]  R32       1
    z[4,3,3]  R41       -1
    z[4,3,3]  R2050     -1
    z[4,3,3]  R2051     1
    z[4,3,3]  R2058     -4.1165980696678162e-01
    z[4,3,3]  R2059     -0.512349009513855
    z[4,3,3]  R2060     -2.7854391932487488e-01
    z[4,3,3]  R2061     5.7831909507513046e-02
    z[4,3,3]  R2062     2.8801107406616211e-01
    z[4,3,3]  R2063     3.1249490380287170e-01
    z[4,3,3]  R2064     1.3719774782657623e-01
    z[4,3,3]  R2065     4.3428402394056320e-02
    z[4,3,3]  R2066     -6.6395789384841919e-02
    z[4,3,3]  R2067     -3.9228478074073792e-01
    z[4,3,3]  R2068     3.4189349412918091e-01
    z[4,3,3]  R2069     4.8163211345672607e-01
    z[4,3,3]  R2070     8.0897784233093262e-01
    z[4,3,3]  R2071     8.2589679956436157e-01
    z[4,3,3]  R2072     5.5961722135543823e-01
    z[4,3,3]  R2073     3.9866998791694641e-01
    z[4,3,3]  R2074     -7.4746638536453247e-01
    z[4,3,3]  R2075     2.6748523116111755e-01
    z[4,3,3]  R2076     0.646652102470398
    z[4,3,3]  R2077     5.6053936481475830e-01
    z[4,3,3]  R2078     5.5258788168430328e-02
    z[4,3,3]  R2079     4.0571206808090210e-01
    z[4,3,3]  R2080     8.2479590177536011e-01
    z[4,3,3]  R2081     7.6130068302154541e-01
    z[4,3,3]  R2082     1.5137337148189545e-01
    z[4,3,3]  R2083     2.9105362296104431e-01
    z[4,3,3]  R2084     -6.1816269159317017e-01
    z[4,3,3]  R2085     -6.7544937133789062e-01
    z[4,3,3]  R2086     -6.6152596473693848e-01
    z[4,3,3]  R2087     4.3023351579904556e-02
    z[4,3,3]  R2088     1.5452498197555542e-01
    z[4,3,3]  R2089     -1.3995146751403809e-01
    z[4,3,3]  R2090     -1.5703247487545013e-01
    z[4,3,3]  R2091     1.2292017787694931e-01
    z[4,3,3]  R2092     3.3047699928283691e-01
    z[4,3,3]  R2093     4.2566198110580444e-01
    z[4,3,3]  R2094     -2.5924065709114075e-01
    z[4,3,3]  R2095     -5.1565170288085938e-02
    z[4,3,3]  R2096     9.4079270958900452e-02
    z[4,3,3]  R2097     4.1670314967632294e-02
    z[4,3,3]  R2098     -3.4154820442199707e-01
    z[4,3,3]  R2099     3.8465496897697449e-01
    z[4,3,3]  R2100     1.9840165972709656e-01
    z[4,3,3]  R2101     1.9946859776973724e-01
    z[4,3,3]  R2102     1.9778101146221161e-01
    z[4,3,3]  R2103     3.0093595385551453e-01
    z[4,3,3]  R2104     6.8186283111572266e-02
    z[4,3,3]  R2105     1.7986796796321869e-01
    z[4,3,3]  R2106     2.6327994465827942e-01
    z[4,3,3]  R2107     1.6986837983131409e-01
    z[4,3,3]  R2108     -1.1933231353759766e-01
    z[4,3,3]  R2109     -4.5953401923179626e-01
    z[4,3,3]  R2110     -4.9614539742469788e-01
    z[4,3,3]  R2111     -5.9462565183639526e-01
    z[4,3,3]  R2112     -7.8989648818969727e-01
    z[4,3,3]  R2113     7.1969664096832275e-01
    z[4,3,3]  R2114     7.7174967527389526e-01
    z[4,3,3]  R2115     6.5546214580535889e-01
    z[4,3,3]  R2116     7.4106442928314209e-01
    z[4,3,3]  R2117     2.0021730661392212e-01
    z[4,3,3]  R2118     5.5433970689773560e-01
    z[4,3,3]  R2119     -0.52590012550354
    z[4,3,3]  R2120     -2.0495519042015076e-01
    z[4,3,3]  R2121     -4.1875174641609192e-01
    z[4,3,3]  R2122     -1.0279170423746109e-01
    z[4,3,3]  R2123     -2.3706091940402985e-01
    z[4,3,3]  R2124     -3.3714500069618225e-01
    z[4,3,3]  R2125     -5.2882552146911621e-01
    z[4,3,3]  R2126     -6.9368675351142883e-02
    z[4,3,3]  R2127     -4.7914066910743713e-01
    z[4,3,3]  R2128     -9.9878363311290741e-02
    z[4,3,3]  R2129     -5.1860916614532471e-01
    z[4,3,3]  R2130     -3.5057091712951660e-01
    z[4,3,3]  R2131     -2.8914105892181396e-01
    z[4,3,3]  R2132     -5.3530967235565186e-01
    z[4,3,3]  R2133     -4.6962723135948181e-01
    z[4,3,3]  R2134     -1.1298985779285431e-01
    z[4,3,3]  R2135     -4.1704189777374268e-01
    z[4,3,3]  R2136     -6.3620281219482422e-01
    z[4,3,3]  R2137     -1.1998195201158524e-01
    z[4,3,3]  R2138     -4.4902548193931580e-01
    z[4,3,3]  R2139     -3.3522203564643860e-01
    z[4,3,3]  R2140     -7.0099848508834839e-01
    z[4,3,3]  R2141     -1.5192590653896332e-01
    z[4,3,3]  R2142     -1.7222185432910919e-01
    z[4,3,3]  R2143     -1.0414893925189972e-01
    z[4,3,3]  R2144     3.5653609037399292e-01
    z[4,3,3]  R2145     -3.4274348616600037e-01
    z[4,3,3]  R2146     -2.7085381746292114e-01
    z[4,3,3]  R2147     -4.7200977802276611e-01
    z[4,3,3]  R2148     2.4483743309974670e-01
    z[4,3,3]  R2149     -1.5734506770968437e-02
    z[4,3,3]  R2150     4.1942241787910461e-01
    z[4,3,3]  R2151     -2.6084804534912109e-01
    z[4,3,3]  R2152     -4.4614812731742859e-01
    z[4,3,3]  R2153     -1.6034652292728424e-01
    z[4,3,3]  R2154     5.3146493434906006e-01
    z[4,3,3]  R2155     -1.1219819635152817e-01
    z[4,3,3]  R2156     3.1958571076393127e-01
    z[4,3,3]  R2157     -7.0361125469207764e-01
    z[4,3,3]  R2158     -1.9121690420433879e-03
    z[4,3,3]  R2159     -4.7457507252693176e-01
    z[4,3,3]  R2160     5.5143153667449951e-01
    z[4,3,3]  R2161     -4.7516596317291260e-01
    z[4,3,3]  R2162     1.0443050414323807e-01
    z[4,3,3]  R2163     -6.0496044158935547e-01
    z[4,3,3]  R2164     -6.7006343603134155e-01
    z[4,3,3]  R2165     -0.553982675075531
    z[4,3,3]  R2166     -2.4072326719760895e-01
    z[4,3,3]  R2167     -3.7531527876853943e-01
    z[4,3,3]  R2168     2.7557075023651123e-01
    z[4,3,3]  R2169     4.3271756172180176e-01
    z[4,3,3]  R2170     -4.4720742106437683e-01
    z[4,3,3]  R2171     -4.1746154427528381e-01
    z[4,3,3]  R2172     -2.7875733375549316e-01
    z[4,3,3]  R2173     -1.6073594987392426e-01
    z[4,3,3]  R2174     -6.6731703281402588e-01
    z[4,3,3]  R2175     -1.9253656268119812e-01
    z[4,3,3]  R2176     2.6407274603843689e-01
    z[4,3,3]  R2177     -0.37900310754776
    z[4,3,4]  R33       1
    z[4,3,4]  R42       -1
    z[4,3,4]  R2052     -1
    z[4,3,4]  R2053     1
    z[4,3,4]  R2058     1.5016369521617889e-01
    z[4,3,4]  R2059     -2.0167241990566254e-01
    z[4,3,4]  R2060     -1.8209861218929291e-01
    z[4,3,4]  R2061     2.4066562950611115e-01
    z[4,3,4]  R2062     3.5273811221122742e-01
    z[4,3,4]  R2063     5.6484955549240112e-01
    z[4,3,4]  R2064     3.1264483928680420e-01
    z[4,3,4]  R2065     2.9566618800163269e-01
    z[4,3,4]  R2066     -2.4209970608353615e-02
    z[4,3,4]  R2067     -2.0483043789863586e-01
    z[4,3,4]  R2068     1.2161655724048615e-01
    z[4,3,4]  R2069     -0.506409227848053
    z[4,3,4]  R2070     -9.3269376084208488e-03
    z[4,3,4]  R2071     1.2939088977873325e-02
    z[4,3,4]  R2072     1.3160282373428345e-01
    z[4,3,4]  R2073     -3.7997606396675110e-01
    z[4,3,4]  R2074     1.3030199706554413e-01
    z[4,3,4]  R2075     3.5595762729644775e-01
    z[4,3,4]  R2076     -5.6280148029327393e-01
    z[4,3,4]  R2077     -6.5569287538528442e-01
    z[4,3,4]  R2078     1.7943548038601875e-02
    z[4,3,4]  R2079     -4.4281604886054993e-01
    z[4,3,4]  R2080     -9.5948047935962677e-02
    z[4,3,4]  R2081     -4.3679103255271912e-01
    z[4,3,4]  R2082     -8.6402416229248047e-01
    z[4,3,4]  R2083     -5.1386451721191406e-01
    z[4,3,4]  R2084     2.8345569968223572e-01
    z[4,3,4]  R2085     -4.8353210091590881e-01
    z[4,3,4]  R2086     6.9809418916702271e-01
    z[4,3,4]  R2087     0.84651118516922
    z[4,3,4]  R2088     3.2380679249763489e-01
    z[4,3,4]  R2089     9.2603355646133423e-02
    z[4,3,4]  R2090     1.0480130463838577e-01
    z[4,3,4]  R2091     0.422298789024353
    z[4,3,4]  R2092     3.1663909554481506e-01
    z[4,3,4]  R2093     1.7822766304016113e-01
    z[4,3,4]  R2094     2.3400390148162842e-01
    z[4,3,4]  R2095     1.9942112267017365e-01
    z[4,3,4]  R2096     -1.5445487201213837e-01
    z[4,3,4]  R2097     6.5681242942810059e-01
    z[4,3,4]  R2098     -6.2510512769222260e-02
    z[4,3,4]  R2099     -3.9069067686796188e-02
    z[4,3,4]  R2100     7.4388369917869568e-02
    z[4,3,4]  R2101     9.9086299538612366e-02
    z[4,3,4]  R2102     -2.6848608255386353e-01
    z[4,3,4]  R2103     -2.0704948902130127e-01
    z[4,3,4]  R2104     -6.2490370124578476e-02
    z[4,3,4]  R2105     0.140402153134346
    z[4,3,4]  R2106     5.8145960792899132e-03
    z[4,3,4]  R2107     -1.9544173777103424e-01
    z[4,3,4]  R2108     -3.7760642170906067e-01
    z[4,3,4]  R2109     -4.9730348587036133e-01
    z[4,3,4]  R2110     5.8268254995346069e-01
    z[4,3,4]  R2111     -4.0152069181203842e-02
    z[4,3,4]  R2112     -3.4616544842720032e-02
    z[4,3,4]  R2113     -1.6403122246265411e-01
    z[4,3,4]  R2114     -3.1539592146873474e-01
    z[4,3,4]  R2115     8.5781447589397430e-02
    z[4,3,4]  R2116     6.1869039200246334e-04
    z[4,3,4]  R2117     4.2012521624565125e-01
    z[4,3,4]  R2118     7.2348825633525848e-02
    z[4,3,4]  R2119     -3.6747512221336365e-01
    z[4,3,4]  R2120     -3.5000881552696228e-01
    z[4,3,4]  R2121     -1.2563988566398621e-01
    z[4,3,4]  R2122     -5.7842051982879639e-01
    z[4,3,4]  R2123     1.1661750078201294e-01
    z[4,3,4]  R2124     2.6517572999000549e-01
    z[4,3,4]  R2125     3.7823032587766647e-02
    z[4,3,4]  R2126     4.4682011008262634e-01
    z[4,3,4]  R2127     1.3806016743183136e-01
    z[4,3,4]  R2128     -7.6068562269210815e-01
    z[4,3,4]  R2129     2.7139365673065186e-01
    z[4,3,4]  R2130     -5.1270890235900879e-01
    z[4,3,4]  R2131     -7.0833325386047363e-01
    z[4,3,4]  R2132     -1.5885916352272034e-01
    z[4,3,4]  R2133     0.0097271129488945
    z[4,3,4]  R2134     2.0710526406764984e-01
    z[4,3,4]  R2135     0.0722404271364212
    z[4,3,4]  R2136     2.7952590584754944e-01
    z[4,3,4]  R2137     3.5081812739372253e-01
    z[4,3,4]  R2138     1.0469100624322891e-01
    z[4,3,4]  R2139     9.6361495554447174e-02
    z[4,3,4]  R2140     2.0615534484386444e-01
    z[4,3,4]  R2141     1.3375785201787949e-02
    z[4,3,4]  R2142     2.4304132163524628e-01
    z[4,3,4]  R2143     -2.3866172134876251e-01
    z[4,3,4]  R2144     6.7363011837005615e-01
    z[4,3,4]  R2145     -6.3374914228916168e-02
    z[4,3,4]  R2146     -2.2365452349185944e-01
    z[4,3,4]  R2147     1.0546257346868515e-01
    z[4,3,4]  R2148     -5.7577687501907349e-01
    z[4,3,4]  R2149     -3.2119274139404297e-01
    z[4,3,4]  R2150     2.7220621705055237e-01
    z[4,3,4]  R2151     1.6834603250026703e-01
    z[4,3,4]  R2152     3.4747067093849182e-01
    z[4,3,4]  R2153     1.0901419818401337e-01
    z[4,3,4]  R2154     7.6294101774692535e-02
    z[4,3,4]  R2155     2.7761319279670715e-01
    z[4,3,4]  R2156     0.539633572101593
    z[4,3,4]  R2157     -0.404040664434433
    z[4,3,4]  R2158     -7.8968626260757446e-01
    z[4,3,4]  R2159     -1.5451841056346893e-01
    z[4,3,4]  R2160     -1.2596817314624786e-01
    z[4,3,4]  R2161     3.7993314862251282e-01
    z[4,3,4]  R2162     -1.3228172063827515e-01
    z[4,3,4]  R2163     8.5183707997202873e-03
    z[4,3,4]  R2164     0.3465596139431
    z[4,3,4]  R2165     1.1181795597076416e-01
    z[4,3,4]  R2166     3.1304755806922913e-01
    z[4,3,4]  R2167     1.1650119721889496e-01
    z[4,3,4]  R2168     2.4950966238975525e-01
    z[4,3,4]  R2169     5.1488459110260010e-01
    z[4,3,4]  R2170     2.8550243377685547e-01
    z[4,3,4]  R2171     3.0487564206123352e-01
    z[4,3,4]  R2172     6.2902212142944336e-01
    z[4,3,4]  R2173     -1.4626890420913696e-01
    z[4,3,4]  R2174     0.437857985496521
    z[4,3,4]  R2175     -1.9519197940826416e-01
    z[4,3,4]  R2176     2.3031803965568542e-01
    z[4,3,4]  R2177     2.6669876649975777e-02
    z[4,3,5]  R34       1
    z[4,3,5]  R43       -1
    z[4,3,5]  R2054     -1
    z[4,3,5]  R2055     1
    z[4,3,5]  R2058     4.9972828477621078e-02
    z[4,3,5]  R2059     -3.2711166143417358e-01
    z[4,3,5]  R2060     1.0573945939540863e-01
    z[4,3,5]  R2061     0.384998619556427
    z[4,3,5]  R2062     -2.5444485247135162e-02
    z[4,3,5]  R2063     -3.2719689607620239e-01
    z[4,3,5]  R2064     6.6548407077789307e-01
    z[4,3,5]  R2065     3.5918089747428894e-01
    z[4,3,5]  R2066     -8.1948794424533844e-02
    z[4,3,5]  R2067     1.1423498392105103e-02
    z[4,3,5]  R2068     1.6303362324833870e-02
    z[4,3,5]  R2069     0.0700659304857254
    z[4,3,5]  R2070     3.2645413279533386e-01
    z[4,3,5]  R2071     2.0752148702740669e-03
    z[4,3,5]  R2072     -5.4658412933349609e-01
    z[4,3,5]  R2073     2.6304228231310844e-02
    z[4,3,5]  R2074     4.7758507728576660e-01
    z[4,3,5]  R2075     3.8313046097755432e-01
    z[4,3,5]  R2076     -2.2911007702350616e-01
    z[4,3,5]  R2077     -3.0044120550155640e-01
    z[4,3,5]  R2078     5.3282942622900009e-02
    z[4,3,5]  R2079     0.546783983707428
    z[4,3,5]  R2080     3.4522768855094910e-01
    z[4,3,5]  R2081     -1.6942660510540009e-01
    z[4,3,5]  R2082     -1.2802666425704956e-01
    z[4,3,5]  R2083     -3.9604511857032776e-01
    z[4,3,5]  R2084     1.8112035095691681e-01
    z[4,3,5]  R2085     1.8203233182430267e-01
    z[4,3,5]  R2086     -1.9573500752449036e-01
    z[4,3,5]  R2087     1.5885604918003082e-01
    z[4,3,5]  R2088     1.7003534734249115e-01
    z[4,3,5]  R2089     1.1630651354789734e-01
    z[4,3,5]  R2090     -5.2712593227624893e-02
    z[4,3,5]  R2091     -2.5786796212196350e-01
    z[4,3,5]  R2092     1.1628390848636627e-01
    z[4,3,5]  R2093     -4.6830984950065613e-01
    z[4,3,5]  R2094     -5.0291174650192261e-01
    z[4,3,5]  R2095     -0.607593297958374
    z[4,3,5]  R2096     -3.6988526582717896e-01
    z[4,3,5]  R2097     -2.1564084291458130e-01
    z[4,3,5]  R2098     3.7687757611274719e-01
    z[4,3,5]  R2099     1.1666663736104965e-01
    z[4,3,5]  R2100     -3.0345454812049866e-01
    z[4,3,5]  R2101     -2.5710278749465942e-01
    z[4,3,5]  R2102     -2.6696819067001343e-01
    z[4,3,5]  R2103     -0.0908493921160698
    z[4,3,5]  R2104     -4.4579851627349854e-01
    z[4,3,5]  R2105     -2.9506006836891174e-01
    z[4,3,5]  R2106     -1.4896060526371002e-01
    z[4,3,5]  R2107     -2.2167436778545380e-01
    z[4,3,5]  R2108     1.7484763264656067e-01
    z[4,3,5]  R2109     -1.1869736760854721e-01
    z[4,3,5]  R2110     2.9007965326309204e-01
    z[4,3,5]  R2111     2.2567853331565857e-01
    z[4,3,5]  R2112     1.0491573251783848e-02
    z[4,3,5]  R2113     -5.9337094426155090e-02
    z[4,3,5]  R2114     -1.8370407819747925e-01
    z[4,3,5]  R2115     -1.0330832563340664e-02
    z[4,3,5]  R2116     -1.5055145323276520e-01
    z[4,3,5]  R2117     6.3797837495803833e-01
    z[4,3,5]  R2118     -1.9927389919757843e-01
    z[4,3,5]  R2119     2.1083581447601318e-01
    z[4,3,5]  R2120     1.5214255452156067e-01
    z[4,3,5]  R2121     4.8982560634613037e-02
    z[4,3,5]  R2122     3.4996861219406128e-01
    z[4,3,5]  R2123     -1.7084781575249508e-05
    z[4,3,5]  R2124     -2.6103073358535767e-01
    z[4,3,5]  R2125     1.1362256854772568e-01
    z[4,3,5]  R2126     4.3569797277450562e-01
    z[4,3,5]  R2127     -2.9749885201454163e-01
    z[4,3,5]  R2128     4.0410479903221130e-01
    z[4,3,5]  R2129     1.6149044036865234e-01
    z[4,3,5]  R2130     1.4994250610470772e-02
    z[4,3,5]  R2131     7.7708929777145386e-02
    z[4,3,5]  R2132     -4.4270315766334534e-01
    z[4,3,5]  R2133     -0.305593341588974
    z[4,3,5]  R2134     3.9728847146034241e-01
    z[4,3,5]  R2135     -0.0940985307097435
    z[4,3,5]  R2136     5.1179504394531250e-01
    z[4,3,5]  R2137     2.4010887742042542e-01
    z[4,3,5]  R2138     -2.3609678447246552e-01
    z[4,3,5]  R2139     -2.2068510297685862e-03
    z[4,3,5]  R2140     3.9398795366287231e-01
    z[4,3,5]  R2141     0.347615510225296
    z[4,3,5]  R2142     1.8736734986305237e-01
    z[4,3,5]  R2143     2.6821252703666687e-01
    z[4,3,5]  R2144     1.3194820284843445e-01
    z[4,3,5]  R2145     2.6607644557952881e-01
    z[4,3,5]  R2146     -7.8134588897228241e-02
    z[4,3,5]  R2147     0.392145037651062
    z[4,3,5]  R2148     3.9392352104187012e-01
    z[4,3,5]  R2149     4.7437033057212830e-01
    z[4,3,5]  R2150     -5.4812286049127579e-02
    z[4,3,5]  R2151     -3.8520131260156631e-02
    z[4,3,5]  R2152     7.0141452550888062e-01
    z[4,3,5]  R2153     1.4357431232929230e-01
    z[4,3,5]  R2154     3.5824459791183472e-01
    z[4,3,5]  R2155     1.4996562898159027e-01
    z[4,3,5]  R2156     2.7571621537208557e-01
    z[4,3,5]  R2157     4.4770732522010803e-01
    z[4,3,5]  R2158     3.0636849999427795e-01
    z[4,3,5]  R2159     2.2403483092784882e-01
    z[4,3,5]  R2160     1.8599498271942139e-01
    z[4,3,5]  R2161     3.1060692854225636e-03
    z[4,3,5]  R2162     -2.6541724801063538e-01
    z[4,3,5]  R2163     0.613767147064209
    z[4,3,5]  R2164     4.5021235942840576e-01
    z[4,3,5]  R2165     -1.7709356546401978e-01
    z[4,3,5]  R2166     7.0006436109542847e-01
    z[4,3,5]  R2167     -1.5343381464481354e-01
    z[4,3,5]  R2168     -1.9948348402976990e-01
    z[4,3,5]  R2169     5.8829028159379959e-02
    z[4,3,5]  R2170     -1.3347668945789337e-01
    z[4,3,5]  R2171     2.7100238204002380e-01
    z[4,3,5]  R2172     2.9846087098121643e-01
    z[4,3,5]  R2173     4.8254373669624329e-01
    z[4,3,5]  R2174     1.7485502362251282e-01
    z[4,3,5]  R2175     7.9436957836151123e-01
    z[4,3,5]  R2176     -3.3977828919887543e-02
    z[4,3,5]  R2177     2.1517501771450043e-01
    z[4,3,6]  R35       1
    z[4,3,6]  R44       -1
    z[4,3,6]  R2056     -1
    z[4,3,6]  R2057     1
    z[4,3,6]  R2058     1.6514627635478973e-01
    z[4,3,6]  R2059     6.5292038023471832e-02
    z[4,3,6]  R2060     -1.0161355137825012e-01
    z[4,3,6]  R2061     -2.9342442750930786e-01
    z[4,3,6]  R2062     1.9883975386619568e-01
    z[4,3,6]  R2063     1.8315419554710388e-01
    z[4,3,6]  R2064     -1.8604686483740807e-02
    z[4,3,6]  R2065     5.9675145149230957e-01
    z[4,3,6]  R2066     -3.7798005342483521e-01
    z[4,3,6]  R2067     3.4525832533836365e-01
    z[4,3,6]  R2068     -4.4347429275512695e-01
    z[4,3,6]  R2069     1.9795902073383331e-01
    z[4,3,6]  R2070     2.3786519467830658e-01
    z[4,3,6]  R2071     2.4091006815433502e-01
    z[4,3,6]  R2072     3.1069728732109070e-01
    z[4,3,6]  R2073     1.4187897741794586e-01
    z[4,3,6]  R2074     -3.1719669699668884e-01
    z[4,3,6]  R2075     2.6061311364173889e-01
    z[4,3,6]  R2076     2.4852724373340607e-01
    z[4,3,6]  R2077     7.5940592214465141e-03
    z[4,3,6]  R2078     4.6995532512664795e-01
    z[4,3,6]  R2079     -1.1474460363388062e-01
    z[4,3,6]  R2080     -1.5504789538681507e-02
    z[4,3,6]  R2081     1.5785694122314453e-02
    z[4,3,6]  R2082     -9.7251825034618378e-02
    z[4,3,6]  R2083     5.5259648710489273e-02
    z[4,3,6]  R2084     -1.8019108474254608e-01
    z[4,3,6]  R2085     -1.2802480161190033e-01
    z[4,3,6]  R2086     9.7086921334266663e-02
    z[4,3,6]  R2087     0.328484445810318
    z[4,3,6]  R2088     -3.3373942971229553e-01
    z[4,3,6]  R2089     -1.8317398428916931e-01
    z[4,3,6]  R2090     -4.4695568084716797e-01
    z[4,3,6]  R2091     -3.0181798338890076e-01
    z[4,3,6]  R2092     4.8480287194252014e-01
    z[4,3,6]  R2093     2.3972646892070770e-01
    z[4,3,6]  R2094     3.9511356502771378e-02
    z[4,3,6]  R2095     -4.6331661939620972e-01
    z[4,3,6]  R2096     5.5952298641204834e-01
    z[4,3,6]  R2097     2.2931481897830963e-01
    z[4,3,6]  R2098     3.6947321146726608e-02
    z[4,3,6]  R2099     -4.3364234268665314e-02
    z[4,3,6]  R2100     -6.3689008355140686e-02
    z[4,3,6]  R2101     6.7253686487674713e-02
    z[4,3,6]  R2102     8.3075987640768290e-04
    z[4,3,6]  R2103     0.238666370511055
    z[4,3,6]  R2104     1.5998931229114532e-01
    z[4,3,6]  R2105     -7.2067372500896454e-02
    z[4,3,6]  R2106     1.7402539029717445e-02
    z[4,3,6]  R2107     -4.5787545968778431e-04
    z[4,3,6]  R2108     5.6041479110717773e-01
    z[4,3,6]  R2109     -2.5544339418411255e-01
    z[4,3,6]  R2110     -3.4603810310363770e-01
    z[4,3,6]  R2111     2.1228450536727905e-01
    z[4,3,6]  R2112     -5.5021807551383972e-02
    z[4,3,6]  R2113     4.1464298963546753e-02
    z[4,3,6]  R2114     -2.2769320011138916e-01
    z[4,3,6]  R2115     1.6541224718093872e-01
    z[4,3,6]  R2116     -4.2195141315460205e-02
    z[4,3,6]  R2117     -2.9661238193511963e-01
    z[4,3,6]  R2118     -1.7342790961265564e-02
    z[4,3,6]  R2119     -0.442648321390152
    z[4,3,6]  R2120     -2.8813473880290985e-02
    z[4,3,6]  R2121     -0.0617663636803627
    z[4,3,6]  R2122     2.7119159698486328e-01
    z[4,3,6]  R2123     3.9645963907241821e-01
    z[4,3,6]  R2124     0.0939316526055336
    z[4,3,6]  R2125     -5.6069320440292358e-01
    z[4,3,6]  R2126     5.5307167768478394e-01
    z[4,3,6]  R2127     2.1062527596950531e-01
    z[4,3,6]  R2128     -3.2975524663925171e-01
    z[4,3,6]  R2129     -1.8817789852619171e-01
    z[4,3,6]  R2130     -3.1503298878669739e-01
    z[4,3,6]  R2131     7.3851831257343292e-02
    z[4,3,6]  R2132     -1.4506006240844727e-01
    z[4,3,6]  R2133     -2.0001192390918732e-01
    z[4,3,6]  R2134     -3.4732496738433838e-01
    z[4,3,6]  R2135     -2.6812374591827393e-01
    z[4,3,6]  R2136     3.8313648104667664e-01
    z[4,3,6]  R2137     0.0815952867269516
    z[4,3,6]  R2138     1.8501979112625122e-01
    z[4,3,6]  R2139     -1.1845734715461731e-01
    z[4,3,6]  R2140     -5.1623537729028612e-06
    z[4,3,6]  R2141     -1.0647686198353767e-02
    z[4,3,6]  R2142     -9.4960257411003113e-03
    z[4,3,6]  R2143     4.1246637701988220e-01
    z[4,3,6]  R2144     3.5161346197128296e-02
    z[4,3,6]  R2145     6.0502803325653076e-01
    z[4,3,6]  R2146     -5.1895850896835327e-01
    z[4,3,6]  R2147     -7.1474784612655640e-01
    z[4,3,6]  R2148     -1.2056052684783936e-01
    z[4,3,6]  R2149     2.2381272912025452e-01
    z[4,3,6]  R2150     4.8936480283737183e-01
    z[4,3,6]  R2151     1.7373697459697723e-01
    z[4,3,6]  R2152     -2.0971101522445679e-01
    z[4,3,6]  R2153     -6.7153668403625488e-01
    z[4,3,6]  R2154     2.6181042194366455e-01
    z[4,3,6]  R2155     -6.9374436140060425e-01
    z[4,3,6]  R2156     -5.1352715492248535e-01
    z[4,3,6]  R2157     2.4896657466888428e-01
    z[4,3,6]  R2158     1.2381459027528763e-01
    z[4,3,6]  R2159     -3.5530999302864075e-02
    z[4,3,6]  R2160     6.5191254019737244e-02
    z[4,3,6]  R2161     4.6483924984931946e-01
    z[4,3,6]  R2162     -3.1138095259666443e-01
    z[4,3,6]  R2163     4.9342062324285507e-02
    z[4,3,6]  R2164     -1.0222411900758743e-01
    z[4,3,6]  R2165     3.9326608180999756e-01
    z[4,3,6]  R2166     -0.0815378800034523
    z[4,3,6]  R2167     -9.5251612365245819e-02
    z[4,3,6]  R2168     4.2908138036727905e-01
    z[4,3,6]  R2169     2.3700079321861267e-01
    z[4,3,6]  R2170     3.2113802433013916e-01
    z[4,3,6]  R2171     6.2269139289855957e-01
    z[4,3,6]  R2172     -2.3689050227403641e-02
    z[4,3,6]  R2173     -6.3128936290740967e-01
    z[4,3,6]  R2174     -2.9839566349983215e-01
    z[4,3,6]  R2175     -4.2567479610443115e-01
    z[4,3,6]  R2176     1.7113989591598511e-01
    z[4,3,6]  R2177     -0.250872939825058
    z[4,5,0]  R38       -1
    z[4,5,0]  R47       1
    z[4,5,0]  R2282     -1
    z[4,5,0]  R2283     1
    z[4,5,0]  R2296     -4.3566304445266724e-01
    z[4,5,0]  R2297     1.1860569566488266e-01
    z[4,5,0]  R2298     -3.3444091677665710e-01
    z[4,5,0]  R2299     -4.9569246172904968e-01
    z[4,5,0]  R2300     -4.7821506857872009e-01
    z[4,5,0]  R2301     -2.5301378965377808e-01
    z[4,5,0]  R2302     0.00965464673936367
    z[4,5,0]  R2303     -7.8255213797092438e-02
    z[4,5,0]  R2304     1.2590855360031128e-01
    z[4,5,0]  R2305     -1.0428953170776367e-01
    z[4,5,0]  R2306     0.323359876871109
    z[4,5,0]  R2307     3.7382391095161438e-01
    z[4,5,0]  R2308     7.9257696866989136e-02
    z[4,5,0]  R2309     3.5170421004295349e-01
    z[4,5,0]  R2310     3.0049356818199158e-01
    z[4,5,0]  R2311     7.3320543766021729e-01
    z[4,5,0]  R2312     1.4527393877506256e-01
    z[4,5,0]  R2313     6.4717435836791992e-01
    z[4,5,0]  R2314     -1.5803582966327667e-01
    z[4,5,0]  R2315     -3.5336855053901672e-01
    z[4,5,0]  R2316     2.2044897079467773e-01
    z[4,5,0]  R2317     0.0868205651640892
    z[4,5,0]  R2318     -8.1602618098258972e-02
    z[4,5,0]  R2319     2.1975185722112656e-02
    z[4,5,0]  R2320     7.1332126855850220e-02
    z[4,5,0]  R2321     1.3148538768291473e-01
    z[4,5,0]  R2322     -5.4136735200881958e-01
    z[4,5,0]  R2323     5.0642073154449463e-01
    z[4,5,0]  R2324     1.5650652348995209e-01
    z[4,5,0]  R2325     -1.3747981190681458e-01
    z[4,5,0]  R2326     6.4572030305862427e-01
    z[4,5,0]  R2327     5.9248942136764526e-01
    z[4,5,0]  R2328     7.7949911355972290e-01
    z[4,5,0]  R2329     4.3592220544815063e-01
    z[4,5,0]  R2330     7.5880461931228638e-01
    z[4,5,0]  R2331     0.639691948890686
    z[4,5,0]  R2332     5.3148925304412842e-01
    z[4,5,0]  R2333     2.0234270393848419e-01
    z[4,5,0]  R2334     4.5358395576477051e-01
    z[4,5,0]  R2335     1.1968953907489777e-01
    z[4,5,0]  R2336     -4.3323707580566406e-01
    z[4,5,0]  R2337     2.5212273001670837e-01
    z[4,5,0]  R2338     2.6298072934150696e-01
    z[4,5,0]  R2339     1.1024408787488937e-01
    z[4,5,0]  R2340     -5.2712941169738770e-01
    z[4,5,0]  R2341     0.0764106810092926
    z[4,5,0]  R2342     1.2938044965267181e-01
    z[4,5,0]  R2343     1.4818756282329559e-01
    z[4,5,0]  R2344     1.3261912763118744e-01
    z[4,5,0]  R2345     0.0923101156949997
    z[4,5,0]  R2346     2.6949477195739746e-01
    z[4,5,0]  R2347     -6.9175457954406738e-01
    z[4,5,0]  R2348     -8.6974817514419556e-01
    z[4,5,0]  R2349     2.7312484383583069e-01
    z[4,5,0]  R2350     -8.7619078159332275e-01
    z[4,5,0]  R2351     -0.76837557554245
    z[4,5,0]  R2352     -8.9575308561325073e-01
    z[4,5,0]  R2353     3.4537902474403381e-01
    z[4,5,0]  R2354     -8.8181060552597046e-01
    z[4,5,0]  R2355     -7.6651340723037720e-01
    z[4,5,0]  R2356     2.6273876428604126e-01
    z[4,5,0]  R2357     2.1442225202918053e-02
    z[4,5,0]  R2358     -5.0709646940231323e-01
    z[4,5,0]  R2359     -6.8957008421421051e-02
    z[4,5,0]  R2360     -6.5651647746562958e-02
    z[4,5,0]  R2361     -0.276305615901947
    z[4,5,0]  R2362     4.8680922389030457e-01
    z[4,5,0]  R2363     -1.8024887144565582e-01
    z[4,5,0]  R2364     -9.4130545854568481e-02
    z[4,5,0]  R2365     3.1457754969596863e-01
    z[4,5,0]  R2366     4.1230636835098267e-01
    z[4,5,0]  R2367     -2.1953971683979034e-01
    z[4,5,0]  R2368     -6.0983443260192871e-01
    z[4,5,0]  R2369     1.5954670310020447e-01
    z[4,5,0]  R2370     -8.1131941080093384e-01
    z[4,5,0]  R2371     6.5042026340961456e-02
    z[4,5,0]  R2372     -8.1532442569732666e-01
    z[4,5,0]  R2373     -7.0960956811904907e-01
    z[4,5,0]  R2374     0.0046690390445292
    z[4,5,0]  R2375     -7.8674578666687012e-01
    z[4,5,0]  R2376     3.9653930068016052e-01
    z[4,5,0]  R2377     -2.1907810121774673e-02
    z[4,5,0]  R2378     -2.9042005538940430e-01
    z[4,5,0]  R2379     2.8162726759910583e-01
    z[4,5,0]  R2380     -8.9192312955856323e-01
    z[4,5,0]  R2381     -3.7026621401309967e-02
    z[4,5,0]  R2382     -8.2801800966262817e-01
    z[4,5,0]  R2383     -8.0668920278549194e-01
    z[4,5,0]  R2384     -0.774544894695282
    z[4,5,0]  R2385     -1.6462604701519012e-01
    z[4,5,0]  R2386     1.5975052118301392e-01
    z[4,5,0]  R2387     -1.0059801489114761e-01
    z[4,5,0]  R2388     -1.3567447662353516e-01
    z[4,5,0]  R2389     2.2019736468791962e-01
    z[4,5,0]  R2390     3.0585357546806335e-01
    z[4,5,0]  R2391     -8.1261835992336273e-02
    z[4,5,0]  R2392     -4.8062843084335327e-01
    z[4,5,0]  R2393     0.339558869600296
    z[4,5,0]  R2394     4.1992641985416412e-02
    z[4,5,0]  R2395     9.0691335499286652e-02
    z[4,5,0]  R2396     2.0195426046848297e-01
    z[4,5,0]  R2397     -4.5795783400535583e-01
    z[4,5,0]  R2398     -5.0490312278270721e-02
    z[4,5,0]  R2399     -8.3322483301162720e-01
    z[4,5,0]  R2400     -3.7403514981269836e-01
    z[4,5,0]  R2401     -4.0900033712387085e-01
    z[4,5,0]  R2402     8.3096392452716827e-02
    z[4,5,0]  R2403     -2.1625292301177979e-01
    z[4,5,0]  R2404     -7.3570340871810913e-01
    z[4,5,0]  R2405     -6.4198029041290283e-01
    z[4,5,1]  R39       -1
    z[4,5,1]  R48       1
    z[4,5,1]  R2284     -1
    z[4,5,1]  R2285     1
    z[4,5,1]  R2296     7.5889408588409424e-01
    z[4,5,1]  R2297     7.5472515821456909e-01
    z[4,5,1]  R2298     8.6888861656188965e-01
    z[4,5,1]  R2299     0.603097140789032
    z[4,5,1]  R2300     5.7544064521789551e-01
    z[4,5,1]  R2301     0.612223744392395
    z[4,5,1]  R2302     6.5207844972610474e-01
    z[4,5,1]  R2303     6.4350157976150513e-01
    z[4,5,1]  R2304     -8.4987187385559082e-01
    z[4,5,1]  R2305     -8.2063728570938110e-01
    z[4,5,1]  R2306     7.5189995765686035e-01
    z[4,5,1]  R2307     4.3783202767372131e-01
    z[4,5,1]  R2308     -3.8606387376785278e-01
    z[4,5,1]  R2309     -2.4214853346347809e-01
    z[4,5,1]  R2310     -3.1058117747306824e-01
    z[4,5,1]  R2311     -2.2177360951900482e-01
    z[4,5,1]  R2312     -1.5315692871809006e-02
    z[4,5,1]  R2313     -3.2986709475517273e-01
    z[4,5,1]  R2314     2.3476628959178925e-01
    z[4,5,1]  R2315     1.9111397862434387e-01
    z[4,5,1]  R2316     7.2244065999984741e-01
    z[4,5,1]  R2317     5.5984967947006226e-01
    z[4,5,1]  R2318     4.1613170504570007e-01
    z[4,5,1]  R2319     4.0391734242439270e-01
    z[4,5,1]  R2320     4.3273970484733582e-01
    z[4,5,1]  R2321     3.8729482889175415e-01
    z[4,5,1]  R2322     -2.0500813424587250e-01
    z[4,5,1]  R2323     -6.2468174844980240e-02
    z[4,5,1]  R2324     -5.0921678543090820e-02
    z[4,5,1]  R2325     -3.5752475261688232e-01
    z[4,5,1]  R2326     -0.438917875289917
    z[4,5,1]  R2327     -3.9163279533386230e-01
    z[4,5,1]  R2328     -2.6016622781753540e-01
    z[4,5,1]  R2329     -3.7669035792350769e-01
    z[4,5,1]  R2330     -2.9924064874649048e-01
    z[4,5,1]  R2331     -5.9318101406097412e-01
    z[4,5,1]  R2332     -3.3125856518745422e-01
    z[4,5,1]  R2333     -3.1194382905960083e-01
    z[4,5,1]  R2334     -3.7661054730415344e-01
    z[4,5,1]  R2335     -4.1943570971488953e-01
    z[4,5,1]  R2336     -6.0823440551757812e-01
    z[4,5,1]  R2337     9.3426233530044556e-01
    z[4,5,1]  R2338     9.0262013673782349e-01
    z[4,5,1]  R2339     8.4135597944259644e-01
    z[4,5,1]  R2340     -6.0268962383270264e-01
    z[4,5,1]  R2341     9.1193181276321411e-01
    z[4,5,1]  R2342     8.6812484264373779e-01
    z[4,5,1]  R2343     0.893491804599762
    z[4,5,1]  R2344     8.6231881380081177e-01
    z[4,5,1]  R2345     8.3279460668563843e-01
    z[4,5,1]  R2346     -5.1101475954055786e-01
    z[4,5,1]  R2347     1.4255075156688690e-01
    z[4,5,1]  R2348     1.4731350541114807e-01
    z[4,5,1]  R2349     -4.5945802330970764e-01
    z[4,5,1]  R2350     1.0036489367485046e-01
    z[4,5,1]  R2351     1.6679603606462479e-02
    z[4,5,1]  R2352     1.0234550572931767e-02
    z[4,5,1]  R2353     3.0713167786598206e-01
    z[4,5,1]  R2354     1.4513903856277466e-01
    z[4,5,1]  R2355     5.6686513125896454e-02
    z[4,5,1]  R2356     -0.594928503036499
    z[4,5,1]  R2357     -0.537834644317627
    z[4,5,1]  R2358     -7.6466858386993408e-01
    z[4,5,1]  R2359     -4.1257899999618530e-01
    z[4,5,1]  R2360     -0.819805920124054
    z[4,5,1]  R2361     -7.8827476501464844e-01
    z[4,5,1]  R2362     2.5197806954383850e-01
    z[4,5,1]  R2363     -5.6327307224273682e-01
    z[4,5,1]  R2364     -5.7580155134201050e-01
    z[4,5,1]  R2365     0.877967894077301
    z[4,5,1]  R2366     -5.0431424379348755e-01
    z[4,5,1]  R2367     -2.3633006215095520e-01
    z[4,5,1]  R2368     -0.75218665599823
    z[4,5,1]  R2369     0.841509222984314
    z[4,5,1]  R2370     1.3649652898311615e-01
    z[4,5,1]  R2371     7.4180859327316284e-01
    z[4,5,1]  R2372     3.7573236227035522e-01
    z[4,5,1]  R2373     4.6993693709373474e-01
    z[4,5,1]  R2374     7.5818246603012085e-01
    z[4,5,1]  R2375     3.6967658996582031e-01
    z[4,5,1]  R2376     -4.1390848159790039e-01
    z[4,5,1]  R2377     -5.5232656002044678e-01
    z[4,5,1]  R2378     -5.8645367622375488e-01
    z[4,5,1]  R2379     0.853574812412262
    z[4,5,1]  R2380     1.4161099493503571e-01
    z[4,5,1]  R2381     8.7833267450332642e-01
    z[4,5,1]  R2382     4.6460762619972229e-01
    z[4,5,1]  R2383     4.2761087417602539e-01
    z[4,5,1]  R2384     4.3448188900947571e-01
    z[4,5,1]  R2385     3.3101415634155273e-01
    z[4,5,1]  R2386     -7.2734969854354858e-01
    z[4,5,1]  R2387     -4.8096224665641785e-01
    z[4,5,1]  R2388     -6.3518542051315308e-01
    z[4,5,1]  R2389     -0.549447774887085
    z[4,5,1]  R2390     8.0458915233612061e-01
    z[4,5,1]  R2391     7.3582708835601807e-01
    z[4,5,1]  R2392     -3.4479122608900070e-02
    z[4,5,1]  R2393     6.7354500293731689e-01
    z[4,5,1]  R2394     4.5692536234855652e-01
    z[4,5,1]  R2395     5.0765895843505859e-01
    z[4,5,1]  R2396     -6.1409157514572144e-01
    z[4,5,1]  R2397     -1.2565791606903076e-01
    z[4,5,1]  R2398     4.1230061650276184e-01
    z[4,5,1]  R2399     3.9774590730667114e-01
    z[4,5,1]  R2400     2.1396382153034210e-01
    z[4,5,1]  R2401     3.3984705805778503e-01
    z[4,5,1]  R2402     2.2719369828701019e-01
    z[4,5,1]  R2403     3.8789638876914978e-01
    z[4,5,1]  R2404     3.6635231971740723e-01
    z[4,5,1]  R2405     5.1319259405136108e-01
    z[4,5,2]  R40       -1
    z[4,5,2]  R49       1
    z[4,5,2]  R2286     -1
    z[4,5,2]  R2287     1
    z[4,5,2]  R2296     1.1177688837051392e-01
    z[4,5,2]  R2297     -4.3407250195741653e-02
    z[4,5,2]  R2298     3.0480053275823593e-02
    z[4,5,2]  R2299     3.0818262696266174e-01
    z[4,5,2]  R2300     4.3888410925865173e-01
    z[4,5,2]  R2301     -6.2086533755064011e-02
    z[4,5,2]  R2302     1.2212823331356049e-01
    z[4,5,2]  R2303     -7.3171287775039673e-02
    z[4,5,2]  R2304     3.2754510641098022e-01
    z[4,5,2]  R2305     -2.2392237558960915e-02
    z[4,5,2]  R2306     3.8310687988996506e-02
    z[4,5,2]  R2307     3.6883878707885742e-01
    z[4,5,2]  R2308     -1.6428200900554657e-01
    z[4,5,2]  R2309     -2.7812442183494568e-01
    z[4,5,2]  R2310     -2.9574507474899292e-01
    z[4,5,2]  R2311     -2.9847124218940735e-01
    z[4,5,2]  R2312     2.7253448963165283e-01
    z[4,5,2]  R2313     -2.4370205402374268e-01
    z[4,5,2]  R2314     -0.265984445810318
    z[4,5,2]  R2315     -6.4389117062091827e-02
    z[4,5,2]  R2316     -4.4989919662475586e-01
    z[4,5,2]  R2317     -7.8759752213954926e-02
    z[4,5,2]  R2318     -1.0610629618167877e-01
    z[4,5,2]  R2319     0.192478746175766
    z[4,5,2]  R2320     -1.1112035065889359e-01
    z[4,5,2]  R2321     5.6924498081207275e-01
    z[4,5,2]  R2322     3.7033399939537048e-01
    z[4,5,2]  R2323     8.6332149803638458e-03
    z[4,5,2]  R2324     1.4917572028934956e-02
    z[4,5,2]  R2325     -4.1301719844341278e-02
    z[4,5,2]  R2326     2.5509269908070564e-02
    z[4,5,2]  R2327     -1.2994299829006195e-01
    z[4,5,2]  R2328     0.00855214148759842
    z[4,5,2]  R2329     -8.2567613571882248e-03
    z[4,5,2]  R2330     -0.0819530263543129
    z[4,5,2]  R2331     -2.4621009826660156e-01
    z[4,5,2]  R2332     2.4352274835109711e-01
    z[4,5,2]  R2333     2.8601571917533875e-01
    z[4,5,2]  R2334     -2.8663319349288940e-01
    z[4,5,2]  R2335     4.8929706215858459e-01
    z[4,5,2]  R2336     3.5377609729766846e-01
    z[4,5,2]  R2337     -1.2487702071666718e-01
    z[4,5,2]  R2338     7.2028875350952148e-02
    z[4,5,2]  R2339     3.4526497125625610e-02
    z[4,5,2]  R2340     0.312128484249115
    z[4,5,2]  R2341     2.1002875640988350e-02
    z[4,5,2]  R2342     0.0805911272764206
    z[4,5,2]  R2343     -7.9114206135272980e-02
    z[4,5,2]  R2344     6.0015637427568436e-02
    z[4,5,2]  R2345     1.1777395755052567e-01
    z[4,5,2]  R2346     4.2093533277511597e-01
    z[4,5,2]  R2347     -1.8737387657165527e-01
    z[4,5,2]  R2348     -1.9083991646766663e-01
    z[4,5,2]  R2349     5.4359138011932373e-01
    z[4,5,2]  R2350     1.6755944490432739e-01
    z[4,5,2]  R2351     -4.0088900923728943e-01
    z[4,5,2]  R2352     -2.7087965607643127e-01
    z[4,5,2]  R2353     8.4773671627044678e-01
    z[4,5,2]  R2354     -5.3328428417444229e-02
    z[4,5,2]  R2355     -9.1249540448188782e-02
    z[4,5,2]  R2356     -2.6642715558409691e-02
    z[4,5,2]  R2357     -1.4002242684364319e-01
    z[4,5,2]  R2358     1.8087702989578247e-01
    z[4,5,2]  R2359     -1.3100315630435944e-01
    z[4,5,2]  R2360     6.3425756990909576e-02
    z[4,5,2]  R2361     0.0672854483127594
    z[4,5,2]  R2362     7.9600483179092407e-01
    z[4,5,2]  R2363     0.364924818277359
    z[4,5,2]  R2364     0.312404990196228
    z[4,5,2]  R2365     2.9581832885742188e-01
    z[4,5,2]  R2366     4.8731550574302673e-01
    z[4,5,2]  R2367     -4.9703961610794067e-01
    z[4,5,2]  R2368     -7.6577968895435333e-02
    z[4,5,2]  R2369     -2.5888085365295410e-01
    z[4,5,2]  R2370     2.3808078840374947e-02
    z[4,5,2]  R2371     -1.9698525965213776e-01
    z[4,5,2]  R2372     -8.8015489280223846e-02
    z[4,5,2]  R2373     -2.1856112778186798e-01
    z[4,5,2]  R2374     1.3577975332736969e-01
    z[4,5,2]  R2375     3.0285622924566269e-02
    z[4,5,2]  R2376     0.414943665266037
    z[4,5,2]  R2377     5.8672297000885010e-01
    z[4,5,2]  R2378     2.3136354982852936e-01
    z[4,5,2]  R2379     1.4333082363009453e-02
    z[4,5,2]  R2380     -6.9514997303485870e-02
    z[4,5,2]  R2381     6.2856063246726990e-02
    z[4,5,2]  R2382     -1.0920436121523380e-02
    z[4,5,2]  R2383     -1.6482889652252197e-01
    z[4,5,2]  R2384     -2.2052787244319916e-01
    z[4,5,2]  R2385     2.8026327490806580e-01
    z[4,5,2]  R2386     -5.4155772924423218e-01
    z[4,5,2]  R2387     -7.0680916309356689e-02
    z[4,5,2]  R2388     5.5067712068557739e-01
    z[4,5,2]  R2389     5.8514326810836792e-01
    z[4,5,2]  R2390     -1.2060177326202393e-01
    z[4,5,2]  R2391     2.7306309342384338e-01
    z[4,5,2]  R2392     1.7790491878986359e-01
    z[4,5,2]  R2393     1.7285411059856415e-01
    z[4,5,2]  R2394     0.066475510597229
    z[4,5,2]  R2395     -7.4864178895950317e-02
    z[4,5,2]  R2396     4.6833685040473938e-01
    z[4,5,2]  R2397     -1.3634940981864929e-01
    z[4,5,2]  R2398     1.3863706588745117e-01
    z[4,5,2]  R2399     1.1819404549896717e-02
    z[4,5,2]  R2400     0.0176091231405735
    z[4,5,2]  R2401     3.2341757416725159e-01
    z[4,5,2]  R2402     -1.7685323953628540e-01
    z[4,5,2]  R2403     1.3034267723560333e-01
    z[4,5,2]  R2404     -0.084355928003788
    z[4,5,2]  R2405     4.3649849295616150e-01
    z[4,5,3]  R41       -1
    z[4,5,3]  R50       1
    z[4,5,3]  R2288     -1
    z[4,5,3]  R2289     1
    z[4,5,3]  R2296     -4.1165980696678162e-01
    z[4,5,3]  R2297     -0.512349009513855
    z[4,5,3]  R2298     -2.7854391932487488e-01
    z[4,5,3]  R2299     5.7831909507513046e-02
    z[4,5,3]  R2300     2.8801107406616211e-01
    z[4,5,3]  R2301     3.1249490380287170e-01
    z[4,5,3]  R2302     1.3719774782657623e-01
    z[4,5,3]  R2303     4.3428402394056320e-02
    z[4,5,3]  R2304     -6.6395789384841919e-02
    z[4,5,3]  R2305     -3.9228478074073792e-01
    z[4,5,3]  R2306     3.4189349412918091e-01
    z[4,5,3]  R2307     4.8163211345672607e-01
    z[4,5,3]  R2308     8.0897784233093262e-01
    z[4,5,3]  R2309     8.2589679956436157e-01
    z[4,5,3]  R2310     5.5961722135543823e-01
    z[4,5,3]  R2311     3.9866998791694641e-01
    z[4,5,3]  R2312     -7.4746638536453247e-01
    z[4,5,3]  R2313     2.6748523116111755e-01
    z[4,5,3]  R2314     0.646652102470398
    z[4,5,3]  R2315     5.6053936481475830e-01
    z[4,5,3]  R2316     5.5258788168430328e-02
    z[4,5,3]  R2317     4.0571206808090210e-01
    z[4,5,3]  R2318     8.2479590177536011e-01
    z[4,5,3]  R2319     7.6130068302154541e-01
    z[4,5,3]  R2320     1.5137337148189545e-01
    z[4,5,3]  R2321     2.9105362296104431e-01
    z[4,5,3]  R2322     -6.1816269159317017e-01
    z[4,5,3]  R2323     -6.7544937133789062e-01
    z[4,5,3]  R2324     -6.6152596473693848e-01
    z[4,5,3]  R2325     4.3023351579904556e-02
    z[4,5,3]  R2326     0.560824453830719
    z[4,5,3]  R2327     6.2672692537307739e-01
    z[4,5,3]  R2328     4.7803124785423279e-01
    z[4,5,3]  R2329     5.6229436397552490e-01
    z[4,5,3]  R2330     4.3165174126625061e-01
    z[4,5,3]  R2331     7.4449107050895691e-02
    z[4,5,3]  R2332     6.2117725610733032e-01
    z[4,5,3]  R2333     0.626302182674408
    z[4,5,3]  R2334     5.6914603710174561e-01
    z[4,5,3]  R2335     5.6571489572525024e-01
    z[4,5,3]  R2336     -1.4441484212875366e-01
    z[4,5,3]  R2337     -7.7496908605098724e-02
    z[4,5,3]  R2338     -2.6442435383796692e-01
    z[4,5,3]  R2339     -4.8002207279205322e-01
    z[4,5,3]  R2340     -4.4360291957855225e-01
    z[4,5,3]  R2341     -2.1171808242797852e-01
    z[4,5,3]  R2342     -3.5463970899581909e-01
    z[4,5,3]  R2343     -2.1362021565437317e-01
    z[4,5,3]  R2344     -3.4828168153762817e-01
    z[4,5,3]  R2345     -4.6822601556777954e-01
    z[4,5,3]  R2346     -3.6039733886718750e-01
    z[4,5,3]  R2347     -4.6259489655494690e-01
    z[4,5,3]  R2348     -3.3161154389381409e-01
    z[4,5,3]  R2349     -4.0480870008468628e-01
    z[4,5,3]  R2350     -3.9341679215431213e-01
    z[4,5,3]  R2351     -4.7615250945091248e-01
    z[4,5,3]  R2352     -5.3505256772041321e-02
    z[4,5,3]  R2353     -1.6752177476882935e-01
    z[4,5,3]  R2354     -1.6175325214862823e-01
    z[4,5,3]  R2355     -1.7537190020084381e-01
    z[4,5,3]  R2356     -3.8207793235778809e-01
    z[4,5,3]  R2357     -3.5980913043022156e-01
    z[4,5,3]  R2358     -2.4678030610084534e-01
    z[4,5,3]  R2359     -2.0257394015789032e-01
    z[4,5,3]  R2360     -2.3464618623256683e-01
    z[4,5,3]  R2361     -2.1929797530174255e-01
    z[4,5,3]  R2362     -2.0114910602569580e-01
    z[4,5,3]  R2363     -8.3379305899143219e-02
    z[4,5,3]  R2364     -2.5607371330261230e-01
    z[4,5,3]  R2365     1.4335356652736664e-01
    z[4,5,3]  R2366     -4.4107311964035034e-01
    z[4,5,3]  R2367     1.2474588304758072e-01
    z[4,5,3]  R2368     1.5756097435951233e-01
    z[4,5,3]  R2369     3.0503696203231812e-01
    z[4,5,3]  R2370     -5.3937506675720215e-01
    z[4,5,3]  R2371     2.5046974420547485e-01
    z[4,5,3]  R2372     2.8962868452072144e-01
    z[4,5,3]  R2373     -6.2990888953208923e-02
    z[4,5,3]  R2374     3.1556281447410583e-01
    z[4,5,3]  R2375     3.2318988442420959e-01
    z[4,5,3]  R2376     -3.2534915208816528e-01
    z[4,5,3]  R2377     -5.1158469915390015e-01
    z[4,5,3]  R2378     -5.4444450139999390e-01
    z[4,5,3]  R2379     1.1107818782329559e-01
    z[4,5,3]  R2380     -3.8976454734802246e-01
    z[4,5,3]  R2381     3.8681519031524658e-01
    z[4,5,3]  R2382     2.7715355157852173e-01
    z[4,5,3]  R2383     -4.7014206647872925e-02
    z[4,5,3]  R2384     1.9265557825565338e-01
    z[4,5,3]  R2385     -8.7753236293792725e-01
    z[4,5,3]  R2386     1.5672484040260315e-01
    z[4,5,3]  R2387     2.4916955828666687e-01
    z[4,5,3]  R2388     -3.6101886630058289e-01
    z[4,5,3]  R2389     -5.2012687921524048e-01
    z[4,5,3]  R2390     7.0098556578159332e-02
    z[4,5,3]  R2391     -5.2916455268859863e-01
    z[4,5,3]  R2392     -7.9334115982055664e-01
    z[4,5,3]  R2393     -9.6878513693809509e-02
    z[4,5,3]  R2394     -7.8511595726013184e-01
    z[4,5,3]  R2395     -6.5803134441375732e-01
    z[4,5,3]  R2396     -5.4513007402420044e-01
    z[4,5,3]  R2397     -0.655022382736206
    z[4,5,3]  R2398     -8.1561261415481567e-01
    z[4,5,3]  R2399     -1.9730459153652191e-01
    z[4,5,3]  R2400     -7.1871173381805420e-01
    z[4,5,3]  R2401     -7.6846402883529663e-01
    z[4,5,3]  R2402     -9.5163661241531372e-01
    z[4,5,3]  R2403     -7.2710955142974854e-01
    z[4,5,3]  R2404     -2.7952216565608978e-02
    z[4,5,3]  R2405     -2.4547162652015686e-01
    z[4,5,4]  R42       -1
    z[4,5,4]  R51       1
    z[4,5,4]  R2290     -1
    z[4,5,4]  R2291     1
    z[4,5,4]  R2296     1.5016369521617889e-01
    z[4,5,4]  R2297     -2.0167241990566254e-01
    z[4,5,4]  R2298     -1.8209861218929291e-01
    z[4,5,4]  R2299     2.4066562950611115e-01
    z[4,5,4]  R2300     3.5273811221122742e-01
    z[4,5,4]  R2301     5.6484955549240112e-01
    z[4,5,4]  R2302     3.1264483928680420e-01
    z[4,5,4]  R2303     2.9566618800163269e-01
    z[4,5,4]  R2304     -2.4209970608353615e-02
    z[4,5,4]  R2305     -2.0483043789863586e-01
    z[4,5,4]  R2306     1.2161655724048615e-01
    z[4,5,4]  R2307     -0.506409227848053
    z[4,5,4]  R2308     -9.3269376084208488e-03
    z[4,5,4]  R2309     1.2939088977873325e-02
    z[4,5,4]  R2310     1.3160282373428345e-01
    z[4,5,4]  R2311     -3.7997606396675110e-01
    z[4,5,4]  R2312     1.3030199706554413e-01
    z[4,5,4]  R2313     3.5595762729644775e-01
    z[4,5,4]  R2314     -5.6280148029327393e-01
    z[4,5,4]  R2315     -6.5569287538528442e-01
    z[4,5,4]  R2316     1.7943548038601875e-02
    z[4,5,4]  R2317     -4.4281604886054993e-01
    z[4,5,4]  R2318     -9.5948047935962677e-02
    z[4,5,4]  R2319     -4.3679103255271912e-01
    z[4,5,4]  R2320     -8.6402416229248047e-01
    z[4,5,4]  R2321     -5.1386451721191406e-01
    z[4,5,4]  R2322     2.8345569968223572e-01
    z[4,5,4]  R2323     -4.8353210091590881e-01
    z[4,5,4]  R2324     6.9809418916702271e-01
    z[4,5,4]  R2325     0.84651118516922
    z[4,5,4]  R2326     1.5356155112385750e-02
    z[4,5,4]  R2327     -0.0917850136756897
    z[4,5,4]  R2328     7.6447036117315292e-03
    z[4,5,4]  R2329     4.8172643780708313e-01
    z[4,5,4]  R2330     3.1640896201133728e-01
    z[4,5,4]  R2331     3.9022436738014221e-01
    z[4,5,4]  R2332     2.5093179941177368e-01
    z[4,5,4]  R2333     1.8925313651561737e-01
    z[4,5,4]  R2334     1.0541664063930511e-01
    z[4,5,4]  R2335     1.1602368950843811e-01
    z[4,5,4]  R2336     -1.9468156993389130e-01
    z[4,5,4]  R2337     -1.3204167783260345e-01
    z[4,5,4]  R2338     -1.7216181382536888e-02
    z[4,5,4]  R2339     3.7903830409049988e-02
    z[4,5,4]  R2340     -0.0446300208568573
    z[4,5,4]  R2341     2.8981253504753113e-01
    z[4,5,4]  R2342     -3.0714502930641174e-01
    z[4,5,4]  R2343     2.1726517379283905e-01
    z[4,5,4]  R2344     -8.0811433494091034e-02
    z[4,5,4]  R2345     -6.2830984592437744e-02
    z[4,5,4]  R2346     -5.6887006759643555e-01
    z[4,5,4]  R2347     -2.6850342750549316e-01
    z[4,5,4]  R2348     -2.6796698570251465e-01
    z[4,5,4]  R2349     -1.0614439845085144e-01
    z[4,5,4]  R2350     -1.9418950378894806e-01
    z[4,5,4]  R2351     1.1833731085062027e-02
    z[4,5,4]  R2352     -2.5105470418930054e-01
    z[4,5,4]  R2353     6.4505837857723236e-02
    z[4,5,4]  R2354     -1.9274080172181129e-02
    z[4,5,4]  R2355     -0.585271418094635
    z[4,5,4]  R2356     -5.0353991985321045e-01
    z[4,5,4]  R2357     -0.446170449256897
    z[4,5,4]  R2358     1.9488246738910675e-01
    z[4,5,4]  R2359     -5.4727095365524292e-01
    z[4,5,4]  R2360     -4.5689767599105835e-01
    z[4,5,4]  R2361     -4.6750482916831970e-01
    z[4,5,4]  R2362     2.2813653573393822e-02
    z[4,5,4]  R2363     -6.5138608217239380e-02
    z[4,5,4]  R2364     -3.0799213051795959e-01
    z[4,5,4]  R2365     -4.4952924363315105e-03
    z[4,5,4]  R2366     -3.4286966919898987e-01
    z[4,5,4]  R2367     1.4899596571922302e-01
    z[4,5,4]  R2368     1.6764806583523750e-02
    z[4,5,4]  R2369     2.8918796777725220e-01
    z[4,5,4]  R2370     1.6099166125059128e-02
    z[4,5,4]  R2371     -2.2511529922485352e-01
    z[4,5,4]  R2372     -1.0972981899976730e-01
    z[4,5,4]  R2373     3.7542146444320679e-01
    z[4,5,4]  R2374     -1.4024865627288818e-01
    z[4,5,4]  R2375     -3.3937383443117142e-02
    z[4,5,4]  R2376     -4.1775226593017578e-01
    z[4,5,4]  R2377     1.7556536197662354e-01
    z[4,5,4]  R2378     0.0706513300538063
    z[4,5,4]  R2379     -1.0516929626464844e-01
    z[4,5,4]  R2380     8.2739852368831635e-03
    z[4,5,4]  R2381     0.0567634291946888
    z[4,5,4]  R2382     1.4633840322494507e-01
    z[4,5,4]  R2383     3.4421750903129578e-01
    z[4,5,4]  R2384     0.0528845377266407
    z[4,5,4]  R2385     -3.5412866622209549e-02
    z[4,5,4]  R2386     -1.4077021181583405e-01
    z[4,5,4]  R2387     -7.4031746387481689e-01
    z[4,5,4]  R2388     3.5037645697593689e-01
    z[4,5,4]  R2389     3.5571921616792679e-02
    z[4,5,4]  R2390     5.6037232279777527e-03
    z[4,5,4]  R2391     2.2409898042678833e-01
    z[4,5,4]  R2392     -2.8389078378677368e-01
    z[4,5,4]  R2393     3.2641181349754333e-01
    z[4,5,4]  R2394     3.6762478947639465e-01
    z[4,5,4]  R2395     1.1520207673311234e-01
    z[4,5,4]  R2396     -1.6303323209285736e-01
    z[4,5,4]  R2397     -0.534935474395752
    z[4,5,4]  R2398     -1.7534036189317703e-02
    z[4,5,4]  R2399     1.9538573920726776e-02
    z[4,5,4]  R2400     -2.8727620840072632e-01
    z[4,5,4]  R2401     7.8169278800487518e-02
    z[4,5,4]  R2402     2.9616493731737137e-02
    z[4,5,4]  R2403     4.9636635184288025e-01
    z[4,5,4]  R2404     2.3595626652240753e-01
    z[4,5,4]  R2405     2.0990064740180969e-01
    z[4,5,5]  R43       -1
    z[4,5,5]  R52       1
    z[4,5,5]  R2292     -1
    z[4,5,5]  R2293     1
    z[4,5,5]  R2296     4.9972828477621078e-02
    z[4,5,5]  R2297     -3.2711166143417358e-01
    z[4,5,5]  R2298     1.0573945939540863e-01
    z[4,5,5]  R2299     0.384998619556427
    z[4,5,5]  R2300     -2.5444485247135162e-02
    z[4,5,5]  R2301     -3.2719689607620239e-01
    z[4,5,5]  R2302     6.6548407077789307e-01
    z[4,5,5]  R2303     3.5918089747428894e-01
    z[4,5,5]  R2304     -8.1948794424533844e-02
    z[4,5,5]  R2305     1.1423498392105103e-02
    z[4,5,5]  R2306     1.6303362324833870e-02
    z[4,5,5]  R2307     0.0700659304857254
    z[4,5,5]  R2308     3.2645413279533386e-01
    z[4,5,5]  R2309     2.0752148702740669e-03
    z[4,5,5]  R2310     -5.4658412933349609e-01
    z[4,5,5]  R2311     2.6304228231310844e-02
    z[4,5,5]  R2312     4.7758507728576660e-01
    z[4,5,5]  R2313     3.8313046097755432e-01
    z[4,5,5]  R2314     -2.2911007702350616e-01
    z[4,5,5]  R2315     -3.0044120550155640e-01
    z[4,5,5]  R2316     5.3282942622900009e-02
    z[4,5,5]  R2317     0.546783983707428
    z[4,5,5]  R2318     3.4522768855094910e-01
    z[4,5,5]  R2319     -1.6942660510540009e-01
    z[4,5,5]  R2320     -1.2802666425704956e-01
    z[4,5,5]  R2321     -3.9604511857032776e-01
    z[4,5,5]  R2322     1.8112035095691681e-01
    z[4,5,5]  R2323     1.8203233182430267e-01
    z[4,5,5]  R2324     -1.9573500752449036e-01
    z[4,5,5]  R2325     1.5885604918003082e-01
    z[4,5,5]  R2326     -0.27354696393013
    z[4,5,5]  R2327     -2.5523068383336067e-02
    z[4,5,5]  R2328     9.2905461788177490e-02
    z[4,5,5]  R2329     -3.4722540527582169e-02
    z[4,5,5]  R2330     1.9602908194065094e-01
    z[4,5,5]  R2331     -3.6198985762894154e-03
    z[4,5,5]  R2332     -2.9300352931022644e-01
    z[4,5,5]  R2333     -5.6037425994873047e-01
    z[4,5,5]  R2334     3.3743798732757568e-01
    z[4,5,5]  R2335     -4.0920349955558777e-01
    z[4,5,5]  R2336     1.9935664534568787e-01
    z[4,5,5]  R2337     1.1492899060249329e-01
    z[4,5,5]  R2338     5.8168604969978333e-02
    z[4,5,5]  R2339     -1.5526196360588074e-01
    z[4,5,5]  R2340     1.9884844124317169e-01
    z[4,5,5]  R2341     -1.8055659532546997e-01
    z[4,5,5]  R2342     -1.2239484116435051e-02
    z[4,5,5]  R2343     -2.8148156404495239e-01
    z[4,5,5]  R2344     -2.3173154890537262e-01
    z[4,5,5]  R2345     -2.4595829844474792e-01
    z[4,5,5]  R2346     1.5505455434322357e-01
    z[4,5,5]  R2347     2.5466531515121460e-01
    z[4,5,5]  R2348     -2.3919600062072277e-03
    z[4,5,5]  R2349     3.3560761809349060e-01
    z[4,5,5]  R2350     4.0550000965595245e-02
    z[4,5,5]  R2351     1.2554794549942017e-01
    z[4,5,5]  R2352     1.9845777750015259e-01
    z[4,5,5]  R2353     0.188396617770195
    z[4,5,5]  R2354     3.7591537833213806e-01
    z[4,5,5]  R2355     1.6490317881107330e-01
    z[4,5,5]  R2356     -6.6061496734619141e-02
    z[4,5,5]  R2357     -4.3922942876815796e-01
    z[4,5,5]  R2358     -1.5732270479202271e-01
    z[4,5,5]  R2359     -5.5782753229141235e-01
    z[4,5,5]  R2360     3.1543437391519547e-02
    z[4,5,5]  R2361     1.6941666603088379e-01
    z[4,5,5]  R2362     1.2285882979631424e-01
    z[4,5,5]  R2363     7.1033620834350586e-01
    z[4,5,5]  R2364     4.4255855679512024e-01
    z[4,5,5]  R2365     -9.7863718867301941e-02
    z[4,5,5]  R2366     -1.5662544965744019e-01
    z[4,5,5]  R2367     -6.8838918209075928e-01
    z[4,5,5]  R2368     -1.7030051350593567e-01
    z[4,5,5]  R2369     -9.6369504928588867e-02
    z[4,5,5]  R2370     1.1636684834957123e-01
    z[4,5,5]  R2371     -5.4046493768692017e-01
    z[4,5,5]  R2372     -0.29739910364151
    z[4,5,5]  R2373     -2.8796562552452087e-01
    z[4,5,5]  R2374     0.449703186750412
    z[4,5,5]  R2375     2.3624885082244873e-01
    z[4,5,5]  R2376     3.7510338425636292e-01
    z[4,5,5]  R2377     -1.0032492876052856e-01
    z[4,5,5]  R2378     4.3588620424270630e-01
    z[4,5,5]  R2379     -3.6930760741233826e-01
    z[4,5,5]  R2380     0.152458056807518
    z[4,5,5]  R2381     -1.1823111772537231e-01
    z[4,5,5]  R2382     -3.2327221706509590e-03
    z[4,5,5]  R2383     1.3134506344795227e-01
    z[4,5,5]  R2384     -5.1871605217456818e-02
    z[4,5,5]  R2385     1.1105019599199295e-01
    z[4,5,5]  R2386     2.6202493906021118e-01
    z[4,5,5]  R2387     -1.7771621048450470e-01
    z[4,5,5]  R2388     0.144393190741539
    z[4,5,5]  R2389     1.5258552134037018e-01
    z[4,5,5]  R2390     1.6942301392555237e-01
    z[4,5,5]  R2391     1.9821600615978241e-01
    z[4,5,5]  R2392     -1.3792443275451660e-01
    z[4,5,5]  R2393     4.6606764197349548e-01
    z[4,5,5]  R2394     1.7696402966976166e-01
    z[4,5,5]  R2395     5.2001518011093140e-01
    z[4,5,5]  R2396     1.5033917129039764e-01
    z[4,5,5]  R2397     1.9275434315204620e-01
    z[4,5,5]  R2398     -7.8589223325252533e-02
    z[4,5,5]  R2399     -3.2607099413871765e-01
    z[4,5,5]  R2400     8.9479319751262665e-02
    z[4,5,5]  R2401     -1.1679124087095261e-01
    z[4,5,5]  R2402     1.3712685555219650e-02
    z[4,5,5]  R2403     -7.9214125871658325e-02
    z[4,5,5]  R2404     -8.7641589343547821e-02
    z[4,5,5]  R2405     -1.5276958048343658e-01
    z[4,5,6]  R44       -1
    z[4,5,6]  R53       1
    z[4,5,6]  R2294     -1
    z[4,5,6]  R2295     1
    z[4,5,6]  R2296     1.6514627635478973e-01
    z[4,5,6]  R2297     6.5292038023471832e-02
    z[4,5,6]  R2298     -1.0161355137825012e-01
    z[4,5,6]  R2299     -2.9342442750930786e-01
    z[4,5,6]  R2300     1.9883975386619568e-01
    z[4,5,6]  R2301     1.8315419554710388e-01
    z[4,5,6]  R2302     -1.8604686483740807e-02
    z[4,5,6]  R2303     5.9675145149230957e-01
    z[4,5,6]  R2304     -3.7798005342483521e-01
    z[4,5,6]  R2305     3.4525832533836365e-01
    z[4,5,6]  R2306     -4.4347429275512695e-01
    z[4,5,6]  R2307     1.9795902073383331e-01
    z[4,5,6]  R2308     2.3786519467830658e-01
    z[4,5,6]  R2309     2.4091006815433502e-01
    z[4,5,6]  R2310     3.1069728732109070e-01
    z[4,5,6]  R2311     1.4187897741794586e-01
    z[4,5,6]  R2312     -3.1719669699668884e-01
    z[4,5,6]  R2313     2.6061311364173889e-01
    z[4,5,6]  R2314     2.4852724373340607e-01
    z[4,5,6]  R2315     7.5940592214465141e-03
    z[4,5,6]  R2316     4.6995532512664795e-01
    z[4,5,6]  R2317     -1.1474460363388062e-01
    z[4,5,6]  R2318     -1.5504789538681507e-02
    z[4,5,6]  R2319     1.5785694122314453e-02
    z[4,5,6]  R2320     -9.7251825034618378e-02
    z[4,5,6]  R2321     5.5259648710489273e-02
    z[4,5,6]  R2322     -1.8019108474254608e-01
    z[4,5,6]  R2323     -1.2802480161190033e-01
    z[4,5,6]  R2324     9.7086921334266663e-02
    z[4,5,6]  R2325     0.328484445810318
    z[4,5,6]  R2326     1.2567305937409401e-02
    z[4,5,6]  R2327     -2.7718612551689148e-01
    z[4,5,6]  R2328     -2.9566511511802673e-01
    z[4,5,6]  R2329     3.4433576464653015e-01
    z[4,5,6]  R2330     5.5579822510480881e-02
    z[4,5,6]  R2331     -1.4310921728610992e-01
    z[4,5,6]  R2332     -1.1749270558357239e-01
    z[4,5,6]  R2333     -1.9455835223197937e-01
    z[4,5,6]  R2334     3.4837210178375244e-01
    z[4,5,6]  R2335     2.6342767477035522e-01
    z[4,5,6]  R2336     -4.6765303611755371e-01
    z[4,5,6]  R2337     -1.0650959610939026e-01
    z[4,5,6]  R2338     -1.9320906698703766e-01
    z[4,5,6]  R2339     1.5103018283843994e-01
    z[4,5,6]  R2340     -1.5218277275562286e-01
    z[4,5,6]  R2341     -2.6157429441809654e-02
    z[4,5,6]  R2342     -5.3551908582448959e-02
    z[4,5,6]  R2343     -3.7203781306743622e-02
    z[4,5,6]  R2344     -2.3170320689678192e-01
    z[4,5,6]  R2345     -1.9556893035769463e-02
    z[4,5,6]  R2346     1.0727799683809280e-01
    z[4,5,6]  R2347     3.3926871418952942e-01
    z[4,5,6]  R2348     -6.0322366654872894e-02
    z[4,5,6]  R2349     3.6199495196342468e-01
    z[4,5,6]  R2350     0.00312709528952837
    z[4,5,6]  R2351     -7.7364325523376465e-02
    z[4,5,6]  R2352     1.3736440241336823e-01
    z[4,5,6]  R2353     -2.8281034901738167e-03
    z[4,5,6]  R2354     1.7507965862751007e-01
    z[4,5,6]  R2355     2.0650139078497887e-02
    z[4,5,6]  R2356     4.1523313522338867e-01
    z[4,5,6]  R2357     -4.1135692596435547e-01
    z[4,5,6]  R2358     4.2290221899747849e-02
    z[4,5,6]  R2359     3.9515611529350281e-01
    z[4,5,6]  R2360     2.3404273390769958e-01
    z[4,5,6]  R2361     4.8952829092741013e-02
    z[4,5,6]  R2362     9.9118478596210480e-02
    z[4,5,6]  R2363     0.0359313040971756
    z[4,5,6]  R2364     4.5354613661766052e-01
    z[4,5,6]  R2365     -1.1205860227346420e-01
    z[4,5,6]  R2366     -3.9465554058551788e-02
    z[4,5,6]  R2367     3.7048763036727905e-01
    z[4,5,6]  R2368     -4.8416815698146820e-02
    z[4,5,6]  R2369     1.1586034297943115e-01
    z[4,5,6]  R2370     1.3355457782745361e-01
    z[4,5,6]  R2371     3.4233994781970978e-02
    z[4,5,6]  R2372     4.4190678745508194e-02
    z[4,5,6]  R2373     -3.3666866365820169e-03
    z[4,5,6]  R2374     2.9192259907722473e-01
    z[4,5,6]  R2375     -2.8641945123672485e-01
    z[4,5,6]  R2376     2.7961862087249756e-01
    z[4,5,6]  R2377     -2.1818424761295319e-01
    z[4,5,6]  R2378     1.6367980837821960e-01
    z[4,5,6]  R2379     1.7917476594448090e-01
    z[4,5,6]  R2380     -6.6021241247653961e-02
    z[4,5,6]  R2381     0.237451434135437
    z[4,5,6]  R2382     -1.2927031144499779e-02
    z[4,5,6]  R2383     3.5853590816259384e-02
    z[4,5,6]  R2384     -3.4651052951812744e-01
    z[4,5,6]  R2385     -0.0336323045194149
    z[4,5,6]  R2386     1.9779159128665924e-01
    z[4,5,6]  R2387     3.3439654111862183e-01
    z[4,5,6]  R2388     -3.0641382560133934e-02
    z[4,5,6]  R2389     1.1021838337182999e-01
    z[4,5,6]  R2390     4.5923396944999695e-01
    z[4,5,6]  R2391     8.8693335652351379e-02
    z[4,5,6]  R2392     -8.4558278322219849e-02
    z[4,5,6]  R2393     2.6078581809997559e-01
    z[4,5,6]  R2394     -4.6534806489944458e-02
    z[4,5,6]  R2395     1.0844473540782928e-01
    z[4,5,6]  R2396     1.2813293933868408e-01
    z[4,5,6]  R2397     -5.9406068176031113e-02
    z[4,5,6]  R2398     -3.6950135231018066e-01
    z[4,5,6]  R2399     4.1972849518060684e-02
    z[4,5,6]  R2400     -4.5489165186882019e-01
    z[4,5,6]  R2401     4.8335094004869461e-02
    z[4,5,6]  R2402     5.9358462691307068e-02
    z[4,5,6]  R2403     6.6626533865928650e-02
    z[4,5,6]  R2404     5.0326216220855713e-01
    z[4,5,6]  R2405     7.9438820481300354e-02
    z[5,4,0]  R38       1
    z[5,4,0]  R47       -1
    z[5,4,0]  R2406     -1
    z[5,4,0]  R2407     1
    z[5,4,0]  R2420     6.4572030305862427e-01
    z[5,4,0]  R2421     5.9248942136764526e-01
    z[5,4,0]  R2422     7.7949911355972290e-01
    z[5,4,0]  R2423     4.3592220544815063e-01
    z[5,4,0]  R2424     7.5880461931228638e-01
    z[5,4,0]  R2425     0.639691948890686
    z[5,4,0]  R2426     5.3148925304412842e-01
    z[5,4,0]  R2427     2.0234270393848419e-01
    z[5,4,0]  R2428     4.5358395576477051e-01
    z[5,4,0]  R2429     1.1968953907489777e-01
    z[5,4,0]  R2430     -4.3323707580566406e-01
    z[5,4,0]  R2431     2.5212273001670837e-01
    z[5,4,0]  R2432     2.6298072934150696e-01
    z[5,4,0]  R2433     1.1024408787488937e-01
    z[5,4,0]  R2434     -5.2712941169738770e-01
    z[5,4,0]  R2435     0.0764106810092926
    z[5,4,0]  R2436     1.2938044965267181e-01
    z[5,4,0]  R2437     1.4818756282329559e-01
    z[5,4,0]  R2438     1.3261912763118744e-01
    z[5,4,0]  R2439     0.0923101156949997
    z[5,4,0]  R2440     2.6949477195739746e-01
    z[5,4,0]  R2441     -6.9175457954406738e-01
    z[5,4,0]  R2442     -8.6974817514419556e-01
    z[5,4,0]  R2443     2.7312484383583069e-01
    z[5,4,0]  R2444     -8.7619078159332275e-01
    z[5,4,0]  R2445     -0.76837557554245
    z[5,4,0]  R2446     -8.9575308561325073e-01
    z[5,4,0]  R2447     3.4537902474403381e-01
    z[5,4,0]  R2448     -8.8181060552597046e-01
    z[5,4,0]  R2449     -7.6651340723037720e-01
    z[5,4,0]  R2450     2.6273876428604126e-01
    z[5,4,0]  R2451     2.1442225202918053e-02
    z[5,4,0]  R2452     -5.0709646940231323e-01
    z[5,4,0]  R2453     -6.8957008421421051e-02
    z[5,4,0]  R2454     -6.5651647746562958e-02
    z[5,4,0]  R2455     -0.276305615901947
    z[5,4,0]  R2456     4.8680922389030457e-01
    z[5,4,0]  R2457     -1.8024887144565582e-01
    z[5,4,0]  R2458     -9.4130545854568481e-02
    z[5,4,0]  R2459     3.1457754969596863e-01
    z[5,4,0]  R2460     4.1230636835098267e-01
    z[5,4,0]  R2461     -2.1953971683979034e-01
    z[5,4,0]  R2462     -6.0983443260192871e-01
    z[5,4,0]  R2463     1.5954670310020447e-01
    z[5,4,0]  R2464     -8.1131941080093384e-01
    z[5,4,0]  R2465     6.5042026340961456e-02
    z[5,4,0]  R2466     -8.1532442569732666e-01
    z[5,4,0]  R2467     -7.0960956811904907e-01
    z[5,4,0]  R2468     0.0046690390445292
    z[5,4,0]  R2469     -7.8674578666687012e-01
    z[5,4,0]  R2470     3.9653930068016052e-01
    z[5,4,0]  R2471     -2.1907810121774673e-02
    z[5,4,0]  R2472     -2.9042005538940430e-01
    z[5,4,0]  R2473     2.8162726759910583e-01
    z[5,4,0]  R2474     -8.9192312955856323e-01
    z[5,4,0]  R2475     -3.7026621401309967e-02
    z[5,4,0]  R2476     -8.2801800966262817e-01
    z[5,4,0]  R2477     -8.0668920278549194e-01
    z[5,4,0]  R2478     -0.774544894695282
    z[5,4,0]  R2479     -1.6462604701519012e-01
    z[5,4,0]  R2480     1.5975052118301392e-01
    z[5,4,0]  R2481     -1.0059801489114761e-01
    z[5,4,0]  R2482     -1.3567447662353516e-01
    z[5,4,0]  R2483     2.2019736468791962e-01
    z[5,4,0]  R2484     3.0585357546806335e-01
    z[5,4,0]  R2485     -8.1261835992336273e-02
    z[5,4,0]  R2486     -4.8062843084335327e-01
    z[5,4,0]  R2487     0.339558869600296
    z[5,4,0]  R2488     4.1992641985416412e-02
    z[5,4,0]  R2489     9.0691335499286652e-02
    z[5,4,0]  R2490     2.0195426046848297e-01
    z[5,4,0]  R2491     -4.5795783400535583e-01
    z[5,4,0]  R2492     -5.0490312278270721e-02
    z[5,4,0]  R2493     -8.3322483301162720e-01
    z[5,4,0]  R2494     -3.7403514981269836e-01
    z[5,4,0]  R2495     -4.0900033712387085e-01
    z[5,4,0]  R2496     8.3096392452716827e-02
    z[5,4,0]  R2497     -2.1625292301177979e-01
    z[5,4,0]  R2498     -7.3570340871810913e-01
    z[5,4,0]  R2499     -6.4198029041290283e-01
    z[5,4,0]  R2500     -4.3566304445266724e-01
    z[5,4,0]  R2501     1.1860569566488266e-01
    z[5,4,0]  R2502     -3.3444091677665710e-01
    z[5,4,0]  R2503     -4.9569246172904968e-01
    z[5,4,0]  R2504     -4.7821506857872009e-01
    z[5,4,0]  R2505     -2.5301378965377808e-01
    z[5,4,0]  R2506     0.00965464673936367
    z[5,4,0]  R2507     -7.8255213797092438e-02
    z[5,4,0]  R2508     1.2590855360031128e-01
    z[5,4,0]  R2509     -1.0428953170776367e-01
    z[5,4,0]  R2510     0.323359876871109
    z[5,4,0]  R2511     3.7382391095161438e-01
    z[5,4,0]  R2512     7.9257696866989136e-02
    z[5,4,0]  R2513     3.5170421004295349e-01
    z[5,4,0]  R2514     3.0049356818199158e-01
    z[5,4,0]  R2515     7.3320543766021729e-01
    z[5,4,0]  R2516     1.4527393877506256e-01
    z[5,4,0]  R2517     6.4717435836791992e-01
    z[5,4,0]  R2518     -1.5803582966327667e-01
    z[5,4,0]  R2519     -3.5336855053901672e-01
    z[5,4,0]  R2520     2.2044897079467773e-01
    z[5,4,0]  R2521     0.0868205651640892
    z[5,4,0]  R2522     -8.1602618098258972e-02
    z[5,4,0]  R2523     2.1975185722112656e-02
    z[5,4,0]  R2524     7.1332126855850220e-02
    z[5,4,0]  R2525     1.3148538768291473e-01
    z[5,4,0]  R2526     -5.4136735200881958e-01
    z[5,4,0]  R2527     5.0642073154449463e-01
    z[5,4,0]  R2528     1.5650652348995209e-01
    z[5,4,0]  R2529     -1.3747981190681458e-01
    z[5,4,1]  R39       1
    z[5,4,1]  R48       -1
    z[5,4,1]  R2408     -1
    z[5,4,1]  R2409     1
    z[5,4,1]  R2420     -0.438917875289917
    z[5,4,1]  R2421     -3.9163279533386230e-01
    z[5,4,1]  R2422     -2.6016622781753540e-01
    z[5,4,1]  R2423     -3.7669035792350769e-01
    z[5,4,1]  R2424     -2.9924064874649048e-01
    z[5,4,1]  R2425     -5.9318101406097412e-01
    z[5,4,1]  R2426     -3.3125856518745422e-01
    z[5,4,1]  R2427     -3.1194382905960083e-01
    z[5,4,1]  R2428     -3.7661054730415344e-01
    z[5,4,1]  R2429     -4.1943570971488953e-01
    z[5,4,1]  R2430     -6.0823440551757812e-01
    z[5,4,1]  R2431     9.3426233530044556e-01
    z[5,4,1]  R2432     9.0262013673782349e-01
    z[5,4,1]  R2433     8.4135597944259644e-01
    z[5,4,1]  R2434     -6.0268962383270264e-01
    z[5,4,1]  R2435     9.1193181276321411e-01
    z[5,4,1]  R2436     8.6812484264373779e-01
    z[5,4,1]  R2437     0.893491804599762
    z[5,4,1]  R2438     8.6231881380081177e-01
    z[5,4,1]  R2439     8.3279460668563843e-01
    z[5,4,1]  R2440     -5.1101475954055786e-01
    z[5,4,1]  R2441     1.4255075156688690e-01
    z[5,4,1]  R2442     1.4731350541114807e-01
    z[5,4,1]  R2443     -4.5945802330970764e-01
    z[5,4,1]  R2444     1.0036489367485046e-01
    z[5,4,1]  R2445     1.6679603606462479e-02
    z[5,4,1]  R2446     1.0234550572931767e-02
    z[5,4,1]  R2447     3.0713167786598206e-01
    z[5,4,1]  R2448     1.4513903856277466e-01
    z[5,4,1]  R2449     5.6686513125896454e-02
    z[5,4,1]  R2450     -0.594928503036499
    z[5,4,1]  R2451     -0.537834644317627
    z[5,4,1]  R2452     -7.6466858386993408e-01
    z[5,4,1]  R2453     -4.1257899999618530e-01
    z[5,4,1]  R2454     -0.819805920124054
    z[5,4,1]  R2455     -7.8827476501464844e-01
    z[5,4,1]  R2456     2.5197806954383850e-01
    z[5,4,1]  R2457     -5.6327307224273682e-01
    z[5,4,1]  R2458     -5.7580155134201050e-01
    z[5,4,1]  R2459     0.877967894077301
    z[5,4,1]  R2460     -5.0431424379348755e-01
    z[5,4,1]  R2461     -2.3633006215095520e-01
    z[5,4,1]  R2462     -0.75218665599823
    z[5,4,1]  R2463     0.841509222984314
    z[5,4,1]  R2464     1.3649652898311615e-01
    z[5,4,1]  R2465     7.4180859327316284e-01
    z[5,4,1]  R2466     3.7573236227035522e-01
    z[5,4,1]  R2467     4.6993693709373474e-01
    z[5,4,1]  R2468     7.5818246603012085e-01
    z[5,4,1]  R2469     3.6967658996582031e-01
    z[5,4,1]  R2470     -4.1390848159790039e-01
    z[5,4,1]  R2471     -5.5232656002044678e-01
    z[5,4,1]  R2472     -5.8645367622375488e-01
    z[5,4,1]  R2473     0.853574812412262
    z[5,4,1]  R2474     1.4161099493503571e-01
    z[5,4,1]  R2475     8.7833267450332642e-01
    z[5,4,1]  R2476     4.6460762619972229e-01
    z[5,4,1]  R2477     4.2761087417602539e-01
    z[5,4,1]  R2478     4.3448188900947571e-01
    z[5,4,1]  R2479     3.3101415634155273e-01
    z[5,4,1]  R2480     -7.2734969854354858e-01
    z[5,4,1]  R2481     -4.8096224665641785e-01
    z[5,4,1]  R2482     -6.3518542051315308e-01
    z[5,4,1]  R2483     -0.549447774887085
    z[5,4,1]  R2484     8.0458915233612061e-01
    z[5,4,1]  R2485     7.3582708835601807e-01
    z[5,4,1]  R2486     -3.4479122608900070e-02
    z[5,4,1]  R2487     6.7354500293731689e-01
    z[5,4,1]  R2488     4.5692536234855652e-01
    z[5,4,1]  R2489     5.0765895843505859e-01
    z[5,4,1]  R2490     -6.1409157514572144e-01
    z[5,4,1]  R2491     -1.2565791606903076e-01
    z[5,4,1]  R2492     4.1230061650276184e-01
    z[5,4,1]  R2493     3.9774590730667114e-01
    z[5,4,1]  R2494     2.1396382153034210e-01
    z[5,4,1]  R2495     3.3984705805778503e-01
    z[5,4,1]  R2496     2.2719369828701019e-01
    z[5,4,1]  R2497     3.8789638876914978e-01
    z[5,4,1]  R2498     3.6635231971740723e-01
    z[5,4,1]  R2499     5.1319259405136108e-01
    z[5,4,1]  R2500     7.5889408588409424e-01
    z[5,4,1]  R2501     7.5472515821456909e-01
    z[5,4,1]  R2502     8.6888861656188965e-01
    z[5,4,1]  R2503     0.603097140789032
    z[5,4,1]  R2504     5.7544064521789551e-01
    z[5,4,1]  R2505     0.612223744392395
    z[5,4,1]  R2506     6.5207844972610474e-01
    z[5,4,1]  R2507     6.4350157976150513e-01
    z[5,4,1]  R2508     -8.4987187385559082e-01
    z[5,4,1]  R2509     -8.2063728570938110e-01
    z[5,4,1]  R2510     7.5189995765686035e-01
    z[5,4,1]  R2511     4.3783202767372131e-01
    z[5,4,1]  R2512     -3.8606387376785278e-01
    z[5,4,1]  R2513     -2.4214853346347809e-01
    z[5,4,1]  R2514     -3.1058117747306824e-01
    z[5,4,1]  R2515     -2.2177360951900482e-01
    z[5,4,1]  R2516     -1.5315692871809006e-02
    z[5,4,1]  R2517     -3.2986709475517273e-01
    z[5,4,1]  R2518     2.3476628959178925e-01
    z[5,4,1]  R2519     1.9111397862434387e-01
    z[5,4,1]  R2520     7.2244065999984741e-01
    z[5,4,1]  R2521     5.5984967947006226e-01
    z[5,4,1]  R2522     4.1613170504570007e-01
    z[5,4,1]  R2523     4.0391734242439270e-01
    z[5,4,1]  R2524     4.3273970484733582e-01
    z[5,4,1]  R2525     3.8729482889175415e-01
    z[5,4,1]  R2526     -2.0500813424587250e-01
    z[5,4,1]  R2527     -6.2468174844980240e-02
    z[5,4,1]  R2528     -5.0921678543090820e-02
    z[5,4,1]  R2529     -3.5752475261688232e-01
    z[5,4,2]  R40       1
    z[5,4,2]  R49       -1
    z[5,4,2]  R2410     -1
    z[5,4,2]  R2411     1
    z[5,4,2]  R2420     2.5509269908070564e-02
    z[5,4,2]  R2421     -1.2994299829006195e-01
    z[5,4,2]  R2422     0.00855214148759842
    z[5,4,2]  R2423     -8.2567613571882248e-03
    z[5,4,2]  R2424     -0.0819530263543129
    z[5,4,2]  R2425     -2.4621009826660156e-01
    z[5,4,2]  R2426     2.4352274835109711e-01
    z[5,4,2]  R2427     2.8601571917533875e-01
    z[5,4,2]  R2428     -2.8663319349288940e-01
    z[5,4,2]  R2429     4.8929706215858459e-01
    z[5,4,2]  R2430     3.5377609729766846e-01
    z[5,4,2]  R2431     -1.2487702071666718e-01
    z[5,4,2]  R2432     7.2028875350952148e-02
    z[5,4,2]  R2433     3.4526497125625610e-02
    z[5,4,2]  R2434     0.312128484249115
    z[5,4,2]  R2435     2.1002875640988350e-02
    z[5,4,2]  R2436     0.0805911272764206
    z[5,4,2]  R2437     -7.9114206135272980e-02
    z[5,4,2]  R2438     6.0015637427568436e-02
    z[5,4,2]  R2439     1.1777395755052567e-01
    z[5,4,2]  R2440     4.2093533277511597e-01
    z[5,4,2]  R2441     -1.8737387657165527e-01
    z[5,4,2]  R2442     -1.9083991646766663e-01
    z[5,4,2]  R2443     5.4359138011932373e-01
    z[5,4,2]  R2444     1.6755944490432739e-01
    z[5,4,2]  R2445     -4.0088900923728943e-01
    z[5,4,2]  R2446     -2.7087965607643127e-01
    z[5,4,2]  R2447     8.4773671627044678e-01
    z[5,4,2]  R2448     -5.3328428417444229e-02
    z[5,4,2]  R2449     -9.1249540448188782e-02
    z[5,4,2]  R2450     -2.6642715558409691e-02
    z[5,4,2]  R2451     -1.4002242684364319e-01
    z[5,4,2]  R2452     1.8087702989578247e-01
    z[5,4,2]  R2453     -1.3100315630435944e-01
    z[5,4,2]  R2454     6.3425756990909576e-02
    z[5,4,2]  R2455     0.0672854483127594
    z[5,4,2]  R2456     7.9600483179092407e-01
    z[5,4,2]  R2457     0.364924818277359
    z[5,4,2]  R2458     0.312404990196228
    z[5,4,2]  R2459     2.9581832885742188e-01
    z[5,4,2]  R2460     4.8731550574302673e-01
    z[5,4,2]  R2461     -4.9703961610794067e-01
    z[5,4,2]  R2462     -7.6577968895435333e-02
    z[5,4,2]  R2463     -2.5888085365295410e-01
    z[5,4,2]  R2464     2.3808078840374947e-02
    z[5,4,2]  R2465     -1.9698525965213776e-01
    z[5,4,2]  R2466     -8.8015489280223846e-02
    z[5,4,2]  R2467     -2.1856112778186798e-01
    z[5,4,2]  R2468     1.3577975332736969e-01
    z[5,4,2]  R2469     3.0285622924566269e-02
    z[5,4,2]  R2470     0.414943665266037
    z[5,4,2]  R2471     5.8672297000885010e-01
    z[5,4,2]  R2472     2.3136354982852936e-01
    z[5,4,2]  R2473     1.4333082363009453e-02
    z[5,4,2]  R2474     -6.9514997303485870e-02
    z[5,4,2]  R2475     6.2856063246726990e-02
    z[5,4,2]  R2476     -1.0920436121523380e-02
    z[5,4,2]  R2477     -1.6482889652252197e-01
    z[5,4,2]  R2478     -2.2052787244319916e-01
    z[5,4,2]  R2479     2.8026327490806580e-01
    z[5,4,2]  R2480     -5.4155772924423218e-01
    z[5,4,2]  R2481     -7.0680916309356689e-02
    z[5,4,2]  R2482     5.5067712068557739e-01
    z[5,4,2]  R2483     5.8514326810836792e-01
    z[5,4,2]  R2484     -1.2060177326202393e-01
    z[5,4,2]  R2485     2.7306309342384338e-01
    z[5,4,2]  R2486     1.7790491878986359e-01
    z[5,4,2]  R2487     1.7285411059856415e-01
    z[5,4,2]  R2488     0.066475510597229
    z[5,4,2]  R2489     -7.4864178895950317e-02
    z[5,4,2]  R2490     4.6833685040473938e-01
    z[5,4,2]  R2491     -1.3634940981864929e-01
    z[5,4,2]  R2492     1.3863706588745117e-01
    z[5,4,2]  R2493     1.1819404549896717e-02
    z[5,4,2]  R2494     0.0176091231405735
    z[5,4,2]  R2495     3.2341757416725159e-01
    z[5,4,2]  R2496     -1.7685323953628540e-01
    z[5,4,2]  R2497     1.3034267723560333e-01
    z[5,4,2]  R2498     -0.084355928003788
    z[5,4,2]  R2499     4.3649849295616150e-01
    z[5,4,2]  R2500     1.1177688837051392e-01
    z[5,4,2]  R2501     -4.3407250195741653e-02
    z[5,4,2]  R2502     3.0480053275823593e-02
    z[5,4,2]  R2503     3.0818262696266174e-01
    z[5,4,2]  R2504     4.3888410925865173e-01
    z[5,4,2]  R2505     -6.2086533755064011e-02
    z[5,4,2]  R2506     1.2212823331356049e-01
    z[5,4,2]  R2507     -7.3171287775039673e-02
    z[5,4,2]  R2508     3.2754510641098022e-01
    z[5,4,2]  R2509     -2.2392237558960915e-02
    z[5,4,2]  R2510     3.8310687988996506e-02
    z[5,4,2]  R2511     3.6883878707885742e-01
    z[5,4,2]  R2512     -1.6428200900554657e-01
    z[5,4,2]  R2513     -2.7812442183494568e-01
    z[5,4,2]  R2514     -2.9574507474899292e-01
    z[5,4,2]  R2515     -2.9847124218940735e-01
    z[5,4,2]  R2516     2.7253448963165283e-01
    z[5,4,2]  R2517     -2.4370205402374268e-01
    z[5,4,2]  R2518     -0.265984445810318
    z[5,4,2]  R2519     -6.4389117062091827e-02
    z[5,4,2]  R2520     -4.4989919662475586e-01
    z[5,4,2]  R2521     -7.8759752213954926e-02
    z[5,4,2]  R2522     -1.0610629618167877e-01
    z[5,4,2]  R2523     0.192478746175766
    z[5,4,2]  R2524     -1.1112035065889359e-01
    z[5,4,2]  R2525     5.6924498081207275e-01
    z[5,4,2]  R2526     3.7033399939537048e-01
    z[5,4,2]  R2527     8.6332149803638458e-03
    z[5,4,2]  R2528     1.4917572028934956e-02
    z[5,4,2]  R2529     -4.1301719844341278e-02
    z[5,4,3]  R41       1
    z[5,4,3]  R50       -1
    z[5,4,3]  R2412     -1
    z[5,4,3]  R2413     1
    z[5,4,3]  R2420     0.560824453830719
    z[5,4,3]  R2421     6.2672692537307739e-01
    z[5,4,3]  R2422     4.7803124785423279e-01
    z[5,4,3]  R2423     5.6229436397552490e-01
    z[5,4,3]  R2424     4.3165174126625061e-01
    z[5,4,3]  R2425     7.4449107050895691e-02
    z[5,4,3]  R2426     6.2117725610733032e-01
    z[5,4,3]  R2427     0.626302182674408
    z[5,4,3]  R2428     5.6914603710174561e-01
    z[5,4,3]  R2429     5.6571489572525024e-01
    z[5,4,3]  R2430     -1.4441484212875366e-01
    z[5,4,3]  R2431     -7.7496908605098724e-02
    z[5,4,3]  R2432     -2.6442435383796692e-01
    z[5,4,3]  R2433     -4.8002207279205322e-01
    z[5,4,3]  R2434     -4.4360291957855225e-01
    z[5,4,3]  R2435     -2.1171808242797852e-01
    z[5,4,3]  R2436     -3.5463970899581909e-01
    z[5,4,3]  R2437     -2.1362021565437317e-01
    z[5,4,3]  R2438     -3.4828168153762817e-01
    z[5,4,3]  R2439     -4.6822601556777954e-01
    z[5,4,3]  R2440     -3.6039733886718750e-01
    z[5,4,3]  R2441     -4.6259489655494690e-01
    z[5,4,3]  R2442     -3.3161154389381409e-01
    z[5,4,3]  R2443     -4.0480870008468628e-01
    z[5,4,3]  R2444     -3.9341679215431213e-01
    z[5,4,3]  R2445     -4.7615250945091248e-01
    z[5,4,3]  R2446     -5.3505256772041321e-02
    z[5,4,3]  R2447     -1.6752177476882935e-01
    z[5,4,3]  R2448     -1.6175325214862823e-01
    z[5,4,3]  R2449     -1.7537190020084381e-01
    z[5,4,3]  R2450     -3.8207793235778809e-01
    z[5,4,3]  R2451     -3.5980913043022156e-01
    z[5,4,3]  R2452     -2.4678030610084534e-01
    z[5,4,3]  R2453     -2.0257394015789032e-01
    z[5,4,3]  R2454     -2.3464618623256683e-01
    z[5,4,3]  R2455     -2.1929797530174255e-01
    z[5,4,3]  R2456     -2.0114910602569580e-01
    z[5,4,3]  R2457     -8.3379305899143219e-02
    z[5,4,3]  R2458     -2.5607371330261230e-01
    z[5,4,3]  R2459     1.4335356652736664e-01
    z[5,4,3]  R2460     -4.4107311964035034e-01
    z[5,4,3]  R2461     1.2474588304758072e-01
    z[5,4,3]  R2462     1.5756097435951233e-01
    z[5,4,3]  R2463     3.0503696203231812e-01
    z[5,4,3]  R2464     -5.3937506675720215e-01
    z[5,4,3]  R2465     2.5046974420547485e-01
    z[5,4,3]  R2466     2.8962868452072144e-01
    z[5,4,3]  R2467     -6.2990888953208923e-02
    z[5,4,3]  R2468     3.1556281447410583e-01
    z[5,4,3]  R2469     3.2318988442420959e-01
    z[5,4,3]  R2470     -3.2534915208816528e-01
    z[5,4,3]  R2471     -5.1158469915390015e-01
    z[5,4,3]  R2472     -5.4444450139999390e-01
    z[5,4,3]  R2473     1.1107818782329559e-01
    z[5,4,3]  R2474     -3.8976454734802246e-01
    z[5,4,3]  R2475     3.8681519031524658e-01
    z[5,4,3]  R2476     2.7715355157852173e-01
    z[5,4,3]  R2477     -4.7014206647872925e-02
    z[5,4,3]  R2478     1.9265557825565338e-01
    z[5,4,3]  R2479     -8.7753236293792725e-01
    z[5,4,3]  R2480     1.5672484040260315e-01
    z[5,4,3]  R2481     2.4916955828666687e-01
    z[5,4,3]  R2482     -3.6101886630058289e-01
    z[5,4,3]  R2483     -5.2012687921524048e-01
    z[5,4,3]  R2484     7.0098556578159332e-02
    z[5,4,3]  R2485     -5.2916455268859863e-01
    z[5,4,3]  R2486     -7.9334115982055664e-01
    z[5,4,3]  R2487     -9.6878513693809509e-02
    z[5,4,3]  R2488     -7.8511595726013184e-01
    z[5,4,3]  R2489     -6.5803134441375732e-01
    z[5,4,3]  R2490     -5.4513007402420044e-01
    z[5,4,3]  R2491     -0.655022382736206
    z[5,4,3]  R2492     -8.1561261415481567e-01
    z[5,4,3]  R2493     -1.9730459153652191e-01
    z[5,4,3]  R2494     -7.1871173381805420e-01
    z[5,4,3]  R2495     -7.6846402883529663e-01
    z[5,4,3]  R2496     -9.5163661241531372e-01
    z[5,4,3]  R2497     -7.2710955142974854e-01
    z[5,4,3]  R2498     -2.7952216565608978e-02
    z[5,4,3]  R2499     -2.4547162652015686e-01
    z[5,4,3]  R2500     -4.1165980696678162e-01
    z[5,4,3]  R2501     -0.512349009513855
    z[5,4,3]  R2502     -2.7854391932487488e-01
    z[5,4,3]  R2503     5.7831909507513046e-02
    z[5,4,3]  R2504     2.8801107406616211e-01
    z[5,4,3]  R2505     3.1249490380287170e-01
    z[5,4,3]  R2506     1.3719774782657623e-01
    z[5,4,3]  R2507     4.3428402394056320e-02
    z[5,4,3]  R2508     -6.6395789384841919e-02
    z[5,4,3]  R2509     -3.9228478074073792e-01
    z[5,4,3]  R2510     3.4189349412918091e-01
    z[5,4,3]  R2511     4.8163211345672607e-01
    z[5,4,3]  R2512     8.0897784233093262e-01
    z[5,4,3]  R2513     8.2589679956436157e-01
    z[5,4,3]  R2514     5.5961722135543823e-01
    z[5,4,3]  R2515     3.9866998791694641e-01
    z[5,4,3]  R2516     -7.4746638536453247e-01
    z[5,4,3]  R2517     2.6748523116111755e-01
    z[5,4,3]  R2518     0.646652102470398
    z[5,4,3]  R2519     5.6053936481475830e-01
    z[5,4,3]  R2520     5.5258788168430328e-02
    z[5,4,3]  R2521     4.0571206808090210e-01
    z[5,4,3]  R2522     8.2479590177536011e-01
    z[5,4,3]  R2523     7.6130068302154541e-01
    z[5,4,3]  R2524     1.5137337148189545e-01
    z[5,4,3]  R2525     2.9105362296104431e-01
    z[5,4,3]  R2526     -6.1816269159317017e-01
    z[5,4,3]  R2527     -6.7544937133789062e-01
    z[5,4,3]  R2528     -6.6152596473693848e-01
    z[5,4,3]  R2529     4.3023351579904556e-02
    z[5,4,4]  R42       1
    z[5,4,4]  R51       -1
    z[5,4,4]  R2414     -1
    z[5,4,4]  R2415     1
    z[5,4,4]  R2420     1.5356155112385750e-02
    z[5,4,4]  R2421     -0.0917850136756897
    z[5,4,4]  R2422     7.6447036117315292e-03
    z[5,4,4]  R2423     4.8172643780708313e-01
    z[5,4,4]  R2424     3.1640896201133728e-01
    z[5,4,4]  R2425     3.9022436738014221e-01
    z[5,4,4]  R2426     2.5093179941177368e-01
    z[5,4,4]  R2427     1.8925313651561737e-01
    z[5,4,4]  R2428     1.0541664063930511e-01
    z[5,4,4]  R2429     1.1602368950843811e-01
    z[5,4,4]  R2430     -1.9468156993389130e-01
    z[5,4,4]  R2431     -1.3204167783260345e-01
    z[5,4,4]  R2432     -1.7216181382536888e-02
    z[5,4,4]  R2433     3.7903830409049988e-02
    z[5,4,4]  R2434     -0.0446300208568573
    z[5,4,4]  R2435     2.8981253504753113e-01
    z[5,4,4]  R2436     -3.0714502930641174e-01
    z[5,4,4]  R2437     2.1726517379283905e-01
    z[5,4,4]  R2438     -8.0811433494091034e-02
    z[5,4,4]  R2439     -6.2830984592437744e-02
    z[5,4,4]  R2440     -5.6887006759643555e-01
    z[5,4,4]  R2441     -2.6850342750549316e-01
    z[5,4,4]  R2442     -2.6796698570251465e-01
    z[5,4,4]  R2443     -1.0614439845085144e-01
    z[5,4,4]  R2444     -1.9418950378894806e-01
    z[5,4,4]  R2445     1.1833731085062027e-02
    z[5,4,4]  R2446     -2.5105470418930054e-01
    z[5,4,4]  R2447     6.4505837857723236e-02
    z[5,4,4]  R2448     -1.9274080172181129e-02
    z[5,4,4]  R2449     -0.585271418094635
    z[5,4,4]  R2450     -5.0353991985321045e-01
    z[5,4,4]  R2451     -0.446170449256897
    z[5,4,4]  R2452     1.9488246738910675e-01
    z[5,4,4]  R2453     -5.4727095365524292e-01
    z[5,4,4]  R2454     -4.5689767599105835e-01
    z[5,4,4]  R2455     -4.6750482916831970e-01
    z[5,4,4]  R2456     2.2813653573393822e-02
    z[5,4,4]  R2457     -6.5138608217239380e-02
    z[5,4,4]  R2458     -3.0799213051795959e-01
    z[5,4,4]  R2459     -4.4952924363315105e-03
    z[5,4,4]  R2460     -3.4286966919898987e-01
    z[5,4,4]  R2461     1.4899596571922302e-01
    z[5,4,4]  R2462     1.6764806583523750e-02
    z[5,4,4]  R2463     2.8918796777725220e-01
    z[5,4,4]  R2464     1.6099166125059128e-02
    z[5,4,4]  R2465     -2.2511529922485352e-01
    z[5,4,4]  R2466     -1.0972981899976730e-01
    z[5,4,4]  R2467     3.7542146444320679e-01
    z[5,4,4]  R2468     -1.4024865627288818e-01
    z[5,4,4]  R2469     -3.3937383443117142e-02
    z[5,4,4]  R2470     -4.1775226593017578e-01
    z[5,4,4]  R2471     1.7556536197662354e-01
    z[5,4,4]  R2472     0.0706513300538063
    z[5,4,4]  R2473     -1.0516929626464844e-01
    z[5,4,4]  R2474     8.2739852368831635e-03
    z[5,4,4]  R2475     0.0567634291946888
    z[5,4,4]  R2476     1.4633840322494507e-01
    z[5,4,4]  R2477     3.4421750903129578e-01
    z[5,4,4]  R2478     0.0528845377266407
    z[5,4,4]  R2479     -3.5412866622209549e-02
    z[5,4,4]  R2480     -1.4077021181583405e-01
    z[5,4,4]  R2481     -7.4031746387481689e-01
    z[5,4,4]  R2482     3.5037645697593689e-01
    z[5,4,4]  R2483     3.5571921616792679e-02
    z[5,4,4]  R2484     5.6037232279777527e-03
    z[5,4,4]  R2485     2.2409898042678833e-01
    z[5,4,4]  R2486     -2.8389078378677368e-01
    z[5,4,4]  R2487     3.2641181349754333e-01
    z[5,4,4]  R2488     3.6762478947639465e-01
    z[5,4,4]  R2489     1.1520207673311234e-01
    z[5,4,4]  R2490     -1.6303323209285736e-01
    z[5,4,4]  R2491     -0.534935474395752
    z[5,4,4]  R2492     -1.7534036189317703e-02
    z[5,4,4]  R2493     1.9538573920726776e-02
    z[5,4,4]  R2494     -2.8727620840072632e-01
    z[5,4,4]  R2495     7.8169278800487518e-02
    z[5,4,4]  R2496     2.9616493731737137e-02
    z[5,4,4]  R2497     4.9636635184288025e-01
    z[5,4,4]  R2498     2.3595626652240753e-01
    z[5,4,4]  R2499     2.0990064740180969e-01
    z[5,4,4]  R2500     1.5016369521617889e-01
    z[5,4,4]  R2501     -2.0167241990566254e-01
    z[5,4,4]  R2502     -1.8209861218929291e-01
    z[5,4,4]  R2503     2.4066562950611115e-01
    z[5,4,4]  R2504     3.5273811221122742e-01
    z[5,4,4]  R2505     5.6484955549240112e-01
    z[5,4,4]  R2506     3.1264483928680420e-01
    z[5,4,4]  R2507     2.9566618800163269e-01
    z[5,4,4]  R2508     -2.4209970608353615e-02
    z[5,4,4]  R2509     -2.0483043789863586e-01
    z[5,4,4]  R2510     1.2161655724048615e-01
    z[5,4,4]  R2511     -0.506409227848053
    z[5,4,4]  R2512     -9.3269376084208488e-03
    z[5,4,4]  R2513     1.2939088977873325e-02
    z[5,4,4]  R2514     1.3160282373428345e-01
    z[5,4,4]  R2515     -3.7997606396675110e-01
    z[5,4,4]  R2516     1.3030199706554413e-01
    z[5,4,4]  R2517     3.5595762729644775e-01
    z[5,4,4]  R2518     -5.6280148029327393e-01
    z[5,4,4]  R2519     -6.5569287538528442e-01
    z[5,4,4]  R2520     1.7943548038601875e-02
    z[5,4,4]  R2521     -4.4281604886054993e-01
    z[5,4,4]  R2522     -9.5948047935962677e-02
    z[5,4,4]  R2523     -4.3679103255271912e-01
    z[5,4,4]  R2524     -8.6402416229248047e-01
    z[5,4,4]  R2525     -5.1386451721191406e-01
    z[5,4,4]  R2526     2.8345569968223572e-01
    z[5,4,4]  R2527     -4.8353210091590881e-01
    z[5,4,4]  R2528     6.9809418916702271e-01
    z[5,4,4]  R2529     0.84651118516922
    z[5,4,5]  R43       1
    z[5,4,5]  R52       -1
    z[5,4,5]  R2416     -1
    z[5,4,5]  R2417     1
    z[5,4,5]  R2420     -0.27354696393013
    z[5,4,5]  R2421     -2.5523068383336067e-02
    z[5,4,5]  R2422     9.2905461788177490e-02
    z[5,4,5]  R2423     -3.4722540527582169e-02
    z[5,4,5]  R2424     1.9602908194065094e-01
    z[5,4,5]  R2425     -3.6198985762894154e-03
    z[5,4,5]  R2426     -2.9300352931022644e-01
    z[5,4,5]  R2427     -5.6037425994873047e-01
    z[5,4,5]  R2428     3.3743798732757568e-01
    z[5,4,5]  R2429     -4.0920349955558777e-01
    z[5,4,5]  R2430     1.9935664534568787e-01
    z[5,4,5]  R2431     1.1492899060249329e-01
    z[5,4,5]  R2432     5.8168604969978333e-02
    z[5,4,5]  R2433     -1.5526196360588074e-01
    z[5,4,5]  R2434     1.9884844124317169e-01
    z[5,4,5]  R2435     -1.8055659532546997e-01
    z[5,4,5]  R2436     -1.2239484116435051e-02
    z[5,4,5]  R2437     -2.8148156404495239e-01
    z[5,4,5]  R2438     -2.3173154890537262e-01
    z[5,4,5]  R2439     -2.4595829844474792e-01
    z[5,4,5]  R2440     1.5505455434322357e-01
    z[5,4,5]  R2441     2.5466531515121460e-01
    z[5,4,5]  R2442     -2.3919600062072277e-03
    z[5,4,5]  R2443     3.3560761809349060e-01
    z[5,4,5]  R2444     4.0550000965595245e-02
    z[5,4,5]  R2445     1.2554794549942017e-01
    z[5,4,5]  R2446     1.9845777750015259e-01
    z[5,4,5]  R2447     0.188396617770195
    z[5,4,5]  R2448     3.7591537833213806e-01
    z[5,4,5]  R2449     1.6490317881107330e-01
    z[5,4,5]  R2450     -6.6061496734619141e-02
    z[5,4,5]  R2451     -4.3922942876815796e-01
    z[5,4,5]  R2452     -1.5732270479202271e-01
    z[5,4,5]  R2453     -5.5782753229141235e-01
    z[5,4,5]  R2454     3.1543437391519547e-02
    z[5,4,5]  R2455     1.6941666603088379e-01
    z[5,4,5]  R2456     1.2285882979631424e-01
    z[5,4,5]  R2457     7.1033620834350586e-01
    z[5,4,5]  R2458     4.4255855679512024e-01
    z[5,4,5]  R2459     -9.7863718867301941e-02
    z[5,4,5]  R2460     -1.5662544965744019e-01
    z[5,4,5]  R2461     -6.8838918209075928e-01
    z[5,4,5]  R2462     -1.7030051350593567e-01
    z[5,4,5]  R2463     -9.6369504928588867e-02
    z[5,4,5]  R2464     1.1636684834957123e-01
    z[5,4,5]  R2465     -5.4046493768692017e-01
    z[5,4,5]  R2466     -0.29739910364151
    z[5,4,5]  R2467     -2.8796562552452087e-01
    z[5,4,5]  R2468     0.449703186750412
    z[5,4,5]  R2469     2.3624885082244873e-01
    z[5,4,5]  R2470     3.7510338425636292e-01
    z[5,4,5]  R2471     -1.0032492876052856e-01
    z[5,4,5]  R2472     4.3588620424270630e-01
    z[5,4,5]  R2473     -3.6930760741233826e-01
    z[5,4,5]  R2474     0.152458056807518
    z[5,4,5]  R2475     -1.1823111772537231e-01
    z[5,4,5]  R2476     -3.2327221706509590e-03
    z[5,4,5]  R2477     1.3134506344795227e-01
    z[5,4,5]  R2478     -5.1871605217456818e-02
    z[5,4,5]  R2479     1.1105019599199295e-01
    z[5,4,5]  R2480     2.6202493906021118e-01
    z[5,4,5]  R2481     -1.7771621048450470e-01
    z[5,4,5]  R2482     0.144393190741539
    z[5,4,5]  R2483     1.5258552134037018e-01
    z[5,4,5]  R2484     1.6942301392555237e-01
    z[5,4,5]  R2485     1.9821600615978241e-01
    z[5,4,5]  R2486     -1.3792443275451660e-01
    z[5,4,5]  R2487     4.6606764197349548e-01
    z[5,4,5]  R2488     1.7696402966976166e-01
    z[5,4,5]  R2489     5.2001518011093140e-01
    z[5,4,5]  R2490     1.5033917129039764e-01
    z[5,4,5]  R2491     1.9275434315204620e-01
    z[5,4,5]  R2492     -7.8589223325252533e-02
    z[5,4,5]  R2493     -3.2607099413871765e-01
    z[5,4,5]  R2494     8.9479319751262665e-02
    z[5,4,5]  R2495     -1.1679124087095261e-01
    z[5,4,5]  R2496     1.3712685555219650e-02
    z[5,4,5]  R2497     -7.9214125871658325e-02
    z[5,4,5]  R2498     -8.7641589343547821e-02
    z[5,4,5]  R2499     -1.5276958048343658e-01
    z[5,4,5]  R2500     4.9972828477621078e-02
    z[5,4,5]  R2501     -3.2711166143417358e-01
    z[5,4,5]  R2502     1.0573945939540863e-01
    z[5,4,5]  R2503     0.384998619556427
    z[5,4,5]  R2504     -2.5444485247135162e-02
    z[5,4,5]  R2505     -3.2719689607620239e-01
    z[5,4,5]  R2506     6.6548407077789307e-01
    z[5,4,5]  R2507     3.5918089747428894e-01
    z[5,4,5]  R2508     -8.1948794424533844e-02
    z[5,4,5]  R2509     1.1423498392105103e-02
    z[5,4,5]  R2510     1.6303362324833870e-02
    z[5,4,5]  R2511     0.0700659304857254
    z[5,4,5]  R2512     3.2645413279533386e-01
    z[5,4,5]  R2513     2.0752148702740669e-03
    z[5,4,5]  R2514     -5.4658412933349609e-01
    z[5,4,5]  R2515     2.6304228231310844e-02
    z[5,4,5]  R2516     4.7758507728576660e-01
    z[5,4,5]  R2517     3.8313046097755432e-01
    z[5,4,5]  R2518     -2.2911007702350616e-01
    z[5,4,5]  R2519     -3.0044120550155640e-01
    z[5,4,5]  R2520     5.3282942622900009e-02
    z[5,4,5]  R2521     0.546783983707428
    z[5,4,5]  R2522     3.4522768855094910e-01
    z[5,4,5]  R2523     -1.6942660510540009e-01
    z[5,4,5]  R2524     -1.2802666425704956e-01
    z[5,4,5]  R2525     -3.9604511857032776e-01
    z[5,4,5]  R2526     1.8112035095691681e-01
    z[5,4,5]  R2527     1.8203233182430267e-01
    z[5,4,5]  R2528     -1.9573500752449036e-01
    z[5,4,5]  R2529     1.5885604918003082e-01
    z[5,4,6]  R44       1
    z[5,4,6]  R53       -1
    z[5,4,6]  R2418     -1
    z[5,4,6]  R2419     1
    z[5,4,6]  R2420     1.2567305937409401e-02
    z[5,4,6]  R2421     -2.7718612551689148e-01
    z[5,4,6]  R2422     -2.9566511511802673e-01
    z[5,4,6]  R2423     3.4433576464653015e-01
    z[5,4,6]  R2424     5.5579822510480881e-02
    z[5,4,6]  R2425     -1.4310921728610992e-01
    z[5,4,6]  R2426     -1.1749270558357239e-01
    z[5,4,6]  R2427     -1.9455835223197937e-01
    z[5,4,6]  R2428     3.4837210178375244e-01
    z[5,4,6]  R2429     2.6342767477035522e-01
    z[5,4,6]  R2430     -4.6765303611755371e-01
    z[5,4,6]  R2431     -1.0650959610939026e-01
    z[5,4,6]  R2432     -1.9320906698703766e-01
    z[5,4,6]  R2433     1.5103018283843994e-01
    z[5,4,6]  R2434     -1.5218277275562286e-01
    z[5,4,6]  R2435     -2.6157429441809654e-02
    z[5,4,6]  R2436     -5.3551908582448959e-02
    z[5,4,6]  R2437     -3.7203781306743622e-02
    z[5,4,6]  R2438     -2.3170320689678192e-01
    z[5,4,6]  R2439     -1.9556893035769463e-02
    z[5,4,6]  R2440     1.0727799683809280e-01
    z[5,4,6]  R2441     3.3926871418952942e-01
    z[5,4,6]  R2442     -6.0322366654872894e-02
    z[5,4,6]  R2443     3.6199495196342468e-01
    z[5,4,6]  R2444     0.00312709528952837
    z[5,4,6]  R2445     -7.7364325523376465e-02
    z[5,4,6]  R2446     1.3736440241336823e-01
    z[5,4,6]  R2447     -2.8281034901738167e-03
    z[5,4,6]  R2448     1.7507965862751007e-01
    z[5,4,6]  R2449     2.0650139078497887e-02
    z[5,4,6]  R2450     4.1523313522338867e-01
    z[5,4,6]  R2451     -4.1135692596435547e-01
    z[5,4,6]  R2452     4.2290221899747849e-02
    z[5,4,6]  R2453     3.9515611529350281e-01
    z[5,4,6]  R2454     2.3404273390769958e-01
    z[5,4,6]  R2455     4.8952829092741013e-02
    z[5,4,6]  R2456     9.9118478596210480e-02
    z[5,4,6]  R2457     0.0359313040971756
    z[5,4,6]  R2458     4.5354613661766052e-01
    z[5,4,6]  R2459     -1.1205860227346420e-01
    z[5,4,6]  R2460     -3.9465554058551788e-02
    z[5,4,6]  R2461     3.7048763036727905e-01
    z[5,4,6]  R2462     -4.8416815698146820e-02
    z[5,4,6]  R2463     1.1586034297943115e-01
    z[5,4,6]  R2464     1.3355457782745361e-01
    z[5,4,6]  R2465     3.4233994781970978e-02
    z[5,4,6]  R2466     4.4190678745508194e-02
    z[5,4,6]  R2467     -3.3666866365820169e-03
    z[5,4,6]  R2468     2.9192259907722473e-01
    z[5,4,6]  R2469     -2.8641945123672485e-01
    z[5,4,6]  R2470     2.7961862087249756e-01
    z[5,4,6]  R2471     -2.1818424761295319e-01
    z[5,4,6]  R2472     1.6367980837821960e-01
    z[5,4,6]  R2473     1.7917476594448090e-01
    z[5,4,6]  R2474     -6.6021241247653961e-02
    z[5,4,6]  R2475     0.237451434135437
    z[5,4,6]  R2476     -1.2927031144499779e-02
    z[5,4,6]  R2477     3.5853590816259384e-02
    z[5,4,6]  R2478     -3.4651052951812744e-01
    z[5,4,6]  R2479     -0.0336323045194149
    z[5,4,6]  R2480     1.9779159128665924e-01
    z[5,4,6]  R2481     3.3439654111862183e-01
    z[5,4,6]  R2482     -3.0641382560133934e-02
    z[5,4,6]  R2483     1.1021838337182999e-01
    z[5,4,6]  R2484     4.5923396944999695e-01
    z[5,4,6]  R2485     8.8693335652351379e-02
    z[5,4,6]  R2486     -8.4558278322219849e-02
    z[5,4,6]  R2487     2.6078581809997559e-01
    z[5,4,6]  R2488     -4.6534806489944458e-02
    z[5,4,6]  R2489     1.0844473540782928e-01
    z[5,4,6]  R2490     1.2813293933868408e-01
    z[5,4,6]  R2491     -5.9406068176031113e-02
    z[5,4,6]  R2492     -3.6950135231018066e-01
    z[5,4,6]  R2493     4.1972849518060684e-02
    z[5,4,6]  R2494     -4.5489165186882019e-01
    z[5,4,6]  R2495     4.8335094004869461e-02
    z[5,4,6]  R2496     5.9358462691307068e-02
    z[5,4,6]  R2497     6.6626533865928650e-02
    z[5,4,6]  R2498     5.0326216220855713e-01
    z[5,4,6]  R2499     7.9438820481300354e-02
    z[5,4,6]  R2500     1.6514627635478973e-01
    z[5,4,6]  R2501     6.5292038023471832e-02
    z[5,4,6]  R2502     -1.0161355137825012e-01
    z[5,4,6]  R2503     -2.9342442750930786e-01
    z[5,4,6]  R2504     1.9883975386619568e-01
    z[5,4,6]  R2505     1.8315419554710388e-01
    z[5,4,6]  R2506     -1.8604686483740807e-02
    z[5,4,6]  R2507     5.9675145149230957e-01
    z[5,4,6]  R2508     -3.7798005342483521e-01
    z[5,4,6]  R2509     3.4525832533836365e-01
    z[5,4,6]  R2510     -4.4347429275512695e-01
    z[5,4,6]  R2511     1.9795902073383331e-01
    z[5,4,6]  R2512     2.3786519467830658e-01
    z[5,4,6]  R2513     2.4091006815433502e-01
    z[5,4,6]  R2514     3.1069728732109070e-01
    z[5,4,6]  R2515     1.4187897741794586e-01
    z[5,4,6]  R2516     -3.1719669699668884e-01
    z[5,4,6]  R2517     2.6061311364173889e-01
    z[5,4,6]  R2518     2.4852724373340607e-01
    z[5,4,6]  R2519     7.5940592214465141e-03
    z[5,4,6]  R2520     4.6995532512664795e-01
    z[5,4,6]  R2521     -1.1474460363388062e-01
    z[5,4,6]  R2522     -1.5504789538681507e-02
    z[5,4,6]  R2523     1.5785694122314453e-02
    z[5,4,6]  R2524     -9.7251825034618378e-02
    z[5,4,6]  R2525     5.5259648710489273e-02
    z[5,4,6]  R2526     -1.8019108474254608e-01
    z[5,4,6]  R2527     -1.2802480161190033e-01
    z[5,4,6]  R2528     9.7086921334266663e-02
    z[5,4,6]  R2529     0.328484445810318
    length[0]  OBJ       1
    length[1]  OBJ       1
    length[2]  OBJ       1
    length[3]  OBJ       1
    length[4]  OBJ       1
    length[5]  OBJ       1
    delta[0,0]  R2        1
    delta[0,1]  R3        1
    delta[0,2]  R4        1
    delta[0,3]  R5        1
    delta[0,4]  R6        1
    delta[0,5]  R7        1
    delta[0,6]  R8        1
    delta[1,0]  R11       1
    delta[1,1]  R12       1
    delta[1,2]  R13       1
    delta[1,3]  R14       1
    delta[1,4]  R15       1
    delta[1,5]  R16       1
    delta[1,6]  R17       1
    delta[2,0]  R20       1
    delta[2,1]  R21       1
    delta[2,2]  R22       1
    delta[2,3]  R23       1
    delta[2,4]  R24       1
    delta[2,5]  R25       1
    delta[2,6]  R26       1
    delta[3,0]  R29       1
    delta[3,1]  R30       1
    delta[3,2]  R31       1
    delta[3,3]  R32       1
    delta[3,4]  R33       1
    delta[3,5]  R34       1
    delta[3,6]  R35       1
    delta[4,0]  R38       1
    delta[4,1]  R39       1
    delta[4,2]  R40       1
    delta[4,3]  R41       1
    delta[4,4]  R42       1
    delta[4,5]  R43       1
    delta[4,6]  R44       1
    delta[5,0]  R47       1
    delta[5,1]  R48       1
    delta[5,2]  R49       1
    delta[5,3]  R50       1
    delta[5,4]  R51       1
    delta[5,5]  R52       1
    delta[5,6]  R53       1
RHS
    RHS1      R1        1
    RHS1      R10       1
    RHS1      R19       1
    RHS1      R28       1
    RHS1      R37       1
    RHS1      R46       1
    RHS1      R54       1
    RHS1      R55       -1
BOUNDS
 BV BND1      phi[0,1]
 BV BND1      phi[1,0]
 BV BND1      phi[0,3]
 BV BND1      phi[3,0]
 BV BND1      phi[0,4]
 BV BND1      phi[4,0]
 BV BND1      phi[6,0]
 BV BND1      phi[1,2]
 BV BND1      phi[2,1]
 BV BND1      phi[1,5]
 BV BND1      phi[5,1]
 BV BND1      phi[2,4]
 BV BND1      phi[4,2]
 BV BND1      phi[2,5]
 BV BND1      phi[5,2]
 BV BND1      phi[2,7]
 BV BND1      phi[3,4]
 BV BND1      phi[4,3]
 BV BND1      phi[6,3]
 BV BND1      phi[4,5]
 BV BND1      phi[5,4]
 BV BND1      phi[5,7]
 FR BND1      z[0,1,0]
 FR BND1      z[0,1,1]
 FR BND1      z[0,1,2]
 FR BND1      z[0,1,3]
 FR BND1      z[0,1,4]
 FR BND1      z[0,1,5]
 FR BND1      z[0,1,6]
 FR BND1      z[1,0,0]
 FR BND1      z[1,0,1]
 FR BND1      z[1,0,2]
 FR BND1      z[1,0,3]
 FR BND1      z[1,0,4]
 FR BND1      z[1,0,5]
 FR BND1      z[1,0,6]
 FR BND1      z[0,3,0]
 FR BND1      z[0,3,1]
 FR BND1      z[0,3,2]
 FR BND1      z[0,3,3]
 FR BND1      z[0,3,4]
 FR BND1      z[0,3,5]
 FR BND1      z[0,3,6]
 FR BND1      z[3,0,0]
 FR BND1      z[3,0,1]
 FR BND1      z[3,0,2]
 FR BND1      z[3,0,3]
 FR BND1      z[3,0,4]
 FR BND1      z[3,0,5]
 FR BND1      z[3,0,6]
 FR BND1      z[0,4,0]
 FR BND1      z[0,4,1]
 FR BND1      z[0,4,2]
 FR BND1      z[0,4,3]
 FR BND1      z[0,4,4]
 FR BND1      z[0,4,5]
 FR BND1      z[0,4,6]
 FR BND1      z[4,0,0]
 FR BND1      z[4,0,1]
 FR BND1      z[4,0,2]
 FR BND1      z[4,0,3]
 FR BND1      z[4,0,4]
 FR BND1      z[4,0,5]
 FR BND1      z[4,0,6]
 FR BND1      z[1,2,0]
 FR BND1      z[1,2,1]
 FR BND1      z[1,2,2]
 FR BND1      z[1,2,3]
 FR BND1      z[1,2,4]
 FR BND1      z[1,2,5]
 FR BND1      z[1,2,6]
 FR BND1      z[2,1,0]
 FR BND1      z[2,1,1]
 FR BND1      z[2,1,2]
 FR BND1      z[2,1,3]
 FR BND1      z[2,1,4]
 FR BND1      z[2,1,5]
 FR BND1      z[2,1,6]
 FR BND1      z[1,5,0]
 FR BND1      z[1,5,1]
 FR BND1      z[1,5,2]
 FR BND1      z[1,5,3]
 FR BND1      z[1,5,4]
 FR BND1      z[1,5,5]
 FR BND1      z[1,5,6]
 FR BND1      z[5,1,0]
 FR BND1      z[5,1,1]
 FR BND1      z[5,1,2]
 FR BND1      z[5,1,3]
 FR BND1      z[5,1,4]
 FR BND1      z[5,1,5]
 FR BND1      z[5,1,6]
 FR BND1      z[2,4,0]
 FR BND1      z[2,4,1]
 FR BND1      z[2,4,2]
 FR BND1      z[2,4,3]
 FR BND1      z[2,4,4]
 FR BND1      z[2,4,5]
 FR BND1      z[2,4,6]
 FR BND1      z[4,2,0]
 FR BND1      z[4,2,1]
 FR BND1      z[4,2,2]
 FR BND1      z[4,2,3]
 FR BND1      z[4,2,4]
 FR BND1      z[4,2,5]
 FR BND1      z[4,2,6]
 FR BND1      z[2,5,0]
 FR BND1      z[2,5,1]
 FR BND1      z[2,5,2]
 FR BND1      z[2,5,3]
 FR BND1      z[2,5,4]
 FR BND1      z[2,5,5]
 FR BND1      z[2,5,6]
 FR BND1      z[5,2,0]
 FR BND1      z[5,2,1]
 FR BND1      z[5,2,2]
 FR BND1      z[5,2,3]
 FR BND1      z[5,2,4]
 FR BND1      z[5,2,5]
 FR BND1      z[5,2,6]
 FR BND1      z[3,4,0]
 FR BND1      z[3,4,1]
 FR BND1      z[3,4,2]
 FR BND1      z[3,4,3]
 FR BND1      z[3,4,4]
 FR BND1      z[3,4,5]
 FR BND1      z[3,4,6]
 FR BND1      z[4,3,0]
 FR BND1      z[4,3,1]
 FR BND1      z[4,3,2]
 FR BND1      z[4,3,3]
 FR BND1      z[4,3,4]
 FR BND1      z[4,3,5]
 FR BND1      z[4,3,6]
 FR BND1      z[4,5,0]
 FR BND1      z[4,5,1]
 FR BND1      z[4,5,2]
 FR BND1      z[4,5,3]
 FR BND1      z[4,5,4]
 FR BND1      z[4,5,5]
 FR BND1      z[4,5,6]
 FR BND1      z[5,4,0]
 FR BND1      z[5,4,1]
 FR BND1      z[5,4,2]
 FR BND1      z[5,4,3]
 FR BND1      z[5,4,4]
 FR BND1      z[5,4,5]
 FR BND1      z[5,4,6]
 FR BND1      delta[0,0]
 FR BND1      delta[0,1]
 FR BND1      delta[0,2]
 FR BND1      delta[0,3]
 FR BND1      delta[0,4]
 FR BND1      delta[0,5]
 FR BND1      delta[0,6]
 FR BND1      delta[1,0]
 FR BND1      delta[1,1]
 FR BND1      delta[1,2]
 FR BND1      delta[1,3]
 FR BND1      delta[1,4]
 FR BND1      delta[1,5]
 FR BND1      delta[1,6]
 FR BND1      delta[2,0]
 FR BND1      delta[2,1]
 FR BND1      delta[2,2]
 FR BND1      delta[2,3]
 FR BND1      delta[2,4]
 FR BND1      delta[2,5]
 FR BND1      delta[2,6]
 FR BND1      delta[3,0]
 FR BND1      delta[3,1]
 FR BND1      delta[3,2]
 FR BND1      delta[3,3]
 FR BND1      delta[3,4]
 FR BND1      delta[3,5]
 FR BND1      delta[3,6]
 FR BND1      delta[4,0]
 FR BND1      delta[4,1]
 FR BND1      delta[4,2]
 FR BND1      delta[4,3]
 FR BND1      delta[4,4]
 FR BND1      delta[4,5]
 FR BND1      delta[4,6]
 FR BND1      delta[5,0]
 FR BND1      delta[5,1]
 FR BND1      delta[5,2]
 FR BND1      delta[5,3]
 FR BND1      delta[5,4]
 FR BND1      delta[5,5]
 FR BND1      delta[5,6]
QCMATRIX   qc0     
    length[0]  length[0]  -1
    delta[0,0]  delta[0,0]  1
    delta[0,1]  delta[0,1]  1
    delta[0,2]  delta[0,2]  1
    delta[0,3]  delta[0,3]  1
    delta[0,4]  delta[0,4]  1
    delta[0,5]  delta[0,5]  1
    delta[0,6]  delta[0,6]  1
QCMATRIX   qc1     
    length[1]  length[1]  -1
    delta[1,0]  delta[1,0]  1
    delta[1,1]  delta[1,1]  1
    delta[1,2]  delta[1,2]  1
    delta[1,3]  delta[1,3]  1
    delta[1,4]  delta[1,4]  1
    delta[1,5]  delta[1,5]  1
    delta[1,6]  delta[1,6]  1
QCMATRIX   qc2     
    length[2]  length[2]  -1
    delta[2,0]  delta[2,0]  1
    delta[2,1]  delta[2,1]  1
    delta[2,2]  delta[2,2]  1
    delta[2,3]  delta[2,3]  1
    delta[2,4]  delta[2,4]  1
    delta[2,5]  delta[2,5]  1
    delta[2,6]  delta[2,6]  1
QCMATRIX   qc3     
    length[3]  length[3]  -1
    delta[3,0]  delta[3,0]  1
    delta[3,1]  delta[3,1]  1
    delta[3,2]  delta[3,2]  1
    delta[3,3]  delta[3,3]  1
    delta[3,4]  delta[3,4]  1
    delta[3,5]  delta[3,5]  1
    delta[3,6]  delta[3,6]  1
QCMATRIX   qc4     
    length[4]  length[4]  -1
    delta[4,0]  delta[4,0]  1
    delta[4,1]  delta[4,1]  1
    delta[4,2]  delta[4,2]  1
    delta[4,3]  delta[4,3]  1
    delta[4,4]  delta[4,4]  1
    delta[4,5]  delta[4,5]  1
    delta[4,6]  delta[4,6]  1
QCMATRIX   qc5     
    length[5]  length[5]  -1
    delta[5,0]  delta[5,0]  1
    delta[5,1]  delta[5,1]  1
    delta[5,2]  delta[5,2]  1
    delta[5,3]  delta[5,3]  1
    delta[5,4]  delta[5,4]  1
    delta[5,5]  delta[5,5]  1
    delta[5,6]  delta[5,6]  1
ENDATA
